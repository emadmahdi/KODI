# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
#
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭则")
#l111lllll1ll_l1_ = [ l11lll_l1_ (u"ࠫࡲࡿࡳࡵࡴࡨࡥࡲ࠭刚"),l11lll_l1_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬ创"),l11lll_l1_ (u"࠭ࡶࡪࡦࡥࡳࡲ࠭刜"),l11lll_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ初") ]
l111lllll1ll_l1_ = []
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ刞"):l11lll_l1_ (u"ࠩࠪ刟")}
def l11_l1_(l1lllll1_l1_,source,type,url):
	#DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ีฬฮืࠡษ็้๋อำษࠩ删"),l1lllll1_l1_)
	if not l1lllll1_l1_:
		LOG_THIS(l11lll_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ刡"),LOGGING(script_name)+l11lll_l1_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡨ࡬ࡲࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࡹࠠࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬ刢")+source+l11lll_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࠥࡹࡱࡧ࠽ࠤࡠࠦࠧ刣")+type+l11lll_l1_ (u"ࠧࠡ࡟ࠪ判"))
		l11l1l111111_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭別"),l11lll_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ刦"),l11lll_l1_ (u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ刧"))
		datetime = time.strftime(l11lll_l1_ (u"ࠫࠪ࡟࠮ࠦ࡯࠱ࠩࡩࠦࠥࡉ࠼ࠨࡑࠬ刨"),time.gmtime(now))
		line = datetime,url
		key = source+l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠪ利")+l11ll111l11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࠣࠫ刪")+str(kodi_version)
		message = l11lll_l1_ (u"ࠧࠨ别")
		if key not in list(l11l1l111111_l1_.keys()): l11l1l111111_l1_[key] = [line]
		else:
			if url not in str(l11l1l111111_l1_[key]): l11l1l111111_l1_[key].append(line)
			else: message = l11lll_l1_ (u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭刬")
		total = 0
		for key in list(l11l1l111111_l1_.keys()):
			l11l1l111111_l1_[key] = list(set(l11l1l111111_l1_[key]))
			total += len(l11l1l111111_l1_[key])
		DIALOG_OK(l11lll_l1_ (u"ࠩࠪ刭"),l11lll_l1_ (u"ࠪࠫ刮"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ刯"),l11lll_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํ࠭到")+message+l11lll_l1_ (u"࠭࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠷ࠣๅ๏ี๊้้สฮࠬ刱")+l11lll_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ刲")+l11lll_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢไ๎ࠥอไใษษ้ฮࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠫ刳")+str(total))
		if total>=5:
			l1ll111ll1_l1_ = DIALOG_YESNO(l11lll_l1_ (u"ࠩࠪ刴"),l11lll_l1_ (u"ࠪࠫ刵"),l11lll_l1_ (u"ࠫࠬ制"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ刷"),l11lll_l1_ (u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧ券"))
			if l1ll111ll1_l1_==1:
				l11l1l1111l1_l1_ = l11lll_l1_ (u"ࠧࠨ刹")
				for key in list(l11l1l111111_l1_.keys()):
					l11l1l1111l1_l1_ += l11lll_l1_ (u"ࠨ࡞ࡱࠫ刺")+key
					l1111l1lllll_l1_ = sorted(l11l1l111111_l1_[key],reverse=False,key=lambda l111ll1ll111_l1_: l111ll1ll111_l1_[0])
					for datetime,url in l1111l1lllll_l1_:
						l11l1l1111l1_l1_ += l11lll_l1_ (u"ࠩ࡟ࡲࠬ刻")+datetime+l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ刼")+l111l_l1_(url)
					l11l1l1111l1_l1_ += l11lll_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ刽")
				import l11ll1lllll_l1_
				succeeded = l11ll1lllll_l1_.l1111ll11l1_l1_(l11lll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࡷࠬ刾"),l11lll_l1_ (u"࠭ࠧ刿"),False,l11lll_l1_ (u"ࠧࠨ剀"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ剁"),l11lll_l1_ (u"ࠩࠪ剂"),l11l1l1111l1_l1_)
				if succeeded: DIALOG_OK(l11lll_l1_ (u"ࠪࠫ剃"),l11lll_l1_ (u"ࠫࠬ剄"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ剅"),l11lll_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ剆"))
				else: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ則"),l11lll_l1_ (u"ࠨࠩ剈"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ剉"),l11lll_l1_ (u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨ削"))
			if l1ll111ll1_l1_!=-1:
				l11l1l111111_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ剋"),l11lll_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ剌"))
		if l11l1l111111_l1_: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ前"),l11lll_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭剎"),l11l1l111111_l1_,PERMANENT_CACHE)
		return
	l1lllll1_l1_ = list(set(l1lllll1_l1_))
	l1lll1ll_l1_,l1111_l1_ = l1111lll1ll1_l1_(l1lllll1_l1_,source)
	l1111l1lll1l_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ剏"))
	l1111llll1ll_l1_ = str(l1111_l1_).count(l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭剐"))
	l1111ll1111l_l1_ = len(l1111_l1_)-l1111l1lll1l_l1_-l1111llll1ll_l1_
	l111l1111l11_l1_ = l11lll_l1_ (u"ู้ࠪอ็ะห࠽ࠫ剑")+str(l1111l1lll1l_l1_)+l11lll_l1_ (u"ࠫࠥࠦࠠࠡฬะ้๏๊࠺ࠨ剒")+str(l1111llll1ll_l1_)+l11lll_l1_ (u"ࠬࠦࠠࠡࠢฦาึ๏࠺ࠨ剓")+str(l1111ll1111l_l1_)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ剔"),l11lll_l1_ (u"ࠧࠨ剕"),str(l1111l1lll1l_l1_),str(l1111llll1ll_l1_))
	#l1l_l1_ = DIALOG_SELECT(l111l1111l11_l1_, l1111_l1_)
	if not l1111_l1_: result,l11ll1111lll_l1_ = l11lll_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ剖"),l11lll_l1_ (u"ࠩࠪ剗")
	else:
		while True:
			l11ll1111lll_l1_ = l11lll_l1_ (u"ࠪࠫ剘")
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l111l1111l11_l1_,l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ剙")
			else:
				title = l1lll1ll_l1_[l1l_l1_]
				link = l1111_l1_[l1l_l1_]
				#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭剚"),l11lll_l1_ (u"࠭ࠧ剛"),title,link)
				if l11lll_l1_ (u"ࠧิ์ิๅึ࠭剜") in title and l11lll_l1_ (u"ࠨ࠴่ะ์๎ไ࠳ࠩ剝") in title:
					LOG_THIS(l11lll_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ剞"),LOGGING(script_name)+l11lll_l1_ (u"ࠪࠤࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ剟")+title+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ剠")+link+l11lll_l1_ (u"ࠬࠦ࡝ࠨ剡"))
					import l11ll1lllll_l1_
					l11ll1lllll_l1_.MAIN(156)
					result = l11lll_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ剢")
				else:
					LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ剣"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭剤")+title+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ剥")+link+l11lll_l1_ (u"ࠪࠤࡢ࠭剦"))
					result,l11ll1111lll_l1_,l11lllll11l1_l1_ = l111l11l1111_l1_(link,source,type)
					#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ剧"),l11lll_l1_ (u"ࠬ࠭剨"),result,l11ll1111lll_l1_)
			if l11lll_l1_ (u"࠭࡜࡯ࠩ剩") not in l11ll1111lll_l1_: l11l1lll1111_l1_,l111l1lllll_l1_ = l11ll1111lll_l1_,l11lll_l1_ (u"ࠧࠨ剪")
			else: l11l1lll1111_l1_,l111l1lllll_l1_ = l11ll1111lll_l1_.split(l11lll_l1_ (u"ࠨ࡞ࡱࠫ剫"),1)
			if result in [l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ剬"),l11lll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ剭"),l11lll_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ剮"),l11lll_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ副")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭剰"),l11lll_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ剱"),l11lll_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ割")]: break
			elif result not in [l11lll_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭剳"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ剴")]: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ創"),l11lll_l1_ (u"ࠬ࠭剶"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ剷"),l11lll_l1_ (u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪ剸")+l11lll_l1_ (u"ࠨ࡞ࡱࠫ剹")+l11l1lll1111_l1_+l11lll_l1_ (u"ࠩ࡟ࡲࠬ剺")+l111l1lllll_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ剻"),l11lll_l1_ (u"ࠫࠬ剼"),l11lll_l1_ (u"ࠬ࠭剽"),str(l11lllll11l1_l1_))
	if result==l11lll_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ剾") and len(l1lll1ll_l1_)>0: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ剿"),l11lll_l1_ (u"ࠨࠩ劀"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ劁"),l11lll_l1_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ劂")+l11lll_l1_ (u"ࠫࡡࡴࠧ劃")+l11ll1111lll_l1_)
	elif result in [l11lll_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ劄"),l11lll_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ劅")] and l11ll1111lll_l1_!=l11lll_l1_ (u"ࠧࠨ劆"): DIALOG_OK(l11lll_l1_ (u"ࠨࠩ劇"),l11lll_l1_ (u"ࠩࠪ劈"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭劉"),l11ll1111lll_l1_)
	#elif l11ll1111lll_l1_==l11lll_l1_ (u"ࠫࡗࡋࡔࡖࡔࡑࡣ࡙ࡕ࡟࡚ࡑࡘࡘ࡚ࡈࡅࠨ劊"): result = l11lllll11l1_l1_
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰ࡮࡬ࠠࡳࡧࡶࡹࡱࡺࠠࡪࡰࠣ࡟ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ࠯ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ࡟࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡖࡨࡷࡹࡀࠠࠡࠢࠪ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠰࡞࠭ࡶࡽࡸ࠴ࡡࡳࡩࡹ࡟࠷ࡣࠩࠋࠋࠌࡼࡧࡳࡣࡱ࡮ࡸ࡫࡮ࡴ࠮ࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࡣࡧࡨࡴࡴ࡟ࡩࡣࡱࡨࡱ࡫ࠬࠡࡈࡤࡰࡸ࡫ࠬࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬ࠮࠯ࠊࠊࠋࡳࡰࡦࡿ࡟ࡪࡶࡨࡱࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡎ࡬ࡷࡹࡏࡴࡦ࡯ࠫࡴࡦࡺࡨ࠾ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠱ࡂࡱࡴࡪࡥ࠾࠳࠷࠷ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࠩ࠸ࡌࡶࠦ࠵ࡇ࡫ࡼࡨ࠱ࡱࡺ࡙ࡸࡼ࠿ࡑࠨࠫࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡶ࡬ࡢࡻࠫࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࡬ࡷ࠳࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳ࠯ࡪࡲ࡫ࡳࡳ࡫࠯࠲࠴࠶࠸࠹࠽࠮࡮ࡲ࠷ࠫ࠱ࡶ࡬ࡢࡻࡢ࡭ࡹ࡫࡭ࠪࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨฬ่ࠤฬ๊วๅ฼สลࠬ࠲ࠧࠨࠫࠍࠍࠧࠨࠢ劋")
	return result
	#if source==l11lll_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ劌"): l111ll_l1_ = l11lll_l1_ (u"ࠧࡉࡎࡄࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭劍")
	#elif source==l11lll_l1_ (u"ࠨ࠶ࡋࡉࡑࡇࡌࠨ劎"): l111ll_l1_ = l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡍࡋࡌࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ劏")
	#elif source==l11lll_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ劐"): l111ll_l1_ = l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡁࡌࡏࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ劑")
	#elif source==l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ劒"): l111ll_l1_ = l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡕࡋ࠸ࠥ࠭劓")
	#size = len(l1ll1ll1l1_l1_)
	#for i in range(0,size):
	#	title = l11ll1111l1l_l1_[i]
	#	link = l1ll1ll1l1_l1_[i]
	#	addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭劔"),l111ll_l1_+title,link,160,l11lll_l1_ (u"ࠨࠩ劕"),l11lll_l1_ (u"ࠩࠪ劖"),source)
def l111l11l1111_l1_(url,source,type=l11lll_l1_ (u"ࠪࠫ劗")):
	url = url.strip(l11lll_l1_ (u"ࠫࠥ࠭劘")).strip(l11lll_l1_ (u"ࠬࠬࠧ劙")).strip(l11lll_l1_ (u"࠭࠿ࠨ劚")).strip(l11lll_l1_ (u"ࠧ࠰ࠩ力"))
	l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11ll1l_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ劜"),l11lll_l1_ (u"ࠩࠪ劝"),url,l11ll1111lll_l1_)
	if l11ll1111lll_l1_==l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ办"): return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_:
		while True:
			if len(l1111_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ功"), l1lll1ll_l1_)
			if l1l_l1_==-1: result = l11lll_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ加")
			else:
				l111ll11lll1_l1_ = l1111_l1_[l1l_l1_]
				title = l1lll1ll_l1_[l1l_l1_]
				LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭务"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸ࡫࡬ࡦࡥࡷࡩࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭劢")+title+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ劣")+str(l111ll11lll1_l1_)+l11lll_l1_ (u"ࠩࠣࡡࠬ劤"))
				if l11lll_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭劥") in l111ll11lll1_l1_ and l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ劦") in l111ll11lll1_l1_:
					l111lll1lll1_l1_,l11llll1l1l1_l1_,l11lllll11l1_l1_ = l11l1l1l1111_l1_(l111ll11lll1_l1_)
					if l11lllll11l1_l1_: l111ll11lll1_l1_ = l11lllll11l1_l1_[0]
					else: l111ll11lll1_l1_ = l11lll_l1_ (u"ࠬ࠭劧")
				if not l111ll11lll1_l1_: result = l11lll_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ动")
				else: result = PLAY_VIDEO(l111ll11lll1_l1_,source,type)
			if result in [l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ助"),l11lll_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ努")] or len(l1111_l1_)==1: break
			elif result in [l11lll_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ劫"),l11lll_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ劬"),l11lll_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ劭")]: break
			else: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭劮"),l11lll_l1_ (u"࠭ࠧ劯"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ劰"),l11lll_l1_ (u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧ励"))
	else:
		result = l11lll_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭劲")
		l111lll11l_l1_ = l11l1ll1ll_l1_(url)
		if l111lll11l_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l11ll1111lll_l1_,l1111_l1_
	#title = xbmc.getInfoLabel( l11lll_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ劳") )
	#if l11lll_l1_ (u"ุࠫ๐ัโำࠣ฽ฬ๋ࠠๆฮ๊์้࠭労") in title:
	#	import l11ll1lllll_l1_
	#	l11ll1lllll_l1_.MAIN(156)
	#	return l11lll_l1_ (u"ࠬ࠭劵")
def l11111ll1l1l_l1_(url,source):
	# url = url+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ劶")+name+l11lll_l1_ (u"ࠧࡠࡡࠪ劷")+type+l11lll_l1_ (u"ࠨࡡࡢࠫ劸")+l1l1111_l1_+l11lll_l1_ (u"ࠩࡢࡣࠬ効")+l11l111l_l1_
	# url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹࡅ࡮ࡢ࡯ࡨࡨࡂࡧ࡫ࡸࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳࡰ࠵ࡡࡢ࠻࠷࠶ࠧ劺")
	l11l11l_l1_,l11l1l1lll11_l1_,server,l111ll1ll11l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = url,l11lll_l1_ (u"ࠫࠬ劻"),l11lll_l1_ (u"ࠬ࠭劼"),l11lll_l1_ (u"࠭ࠧ劽"),l11lll_l1_ (u"ࠧࠨ劾"),l11lll_l1_ (u"ࠨࠩ势"),l11lll_l1_ (u"ࠩࠪ勀"),l11lll_l1_ (u"ࠪࠫ勁")
	#source = source.lower()
	if l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ勂") in url:
		l11l11l_l1_,l11l1l1lll11_l1_ = url.split(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭勃"),1)
		l11l1l1lll11_l1_ = l11l1l1lll11_l1_+l11lll_l1_ (u"࠭࡟ࡠࠩ勄")+l11lll_l1_ (u"ࠧࡠࡡࠪ勅")+l11lll_l1_ (u"ࠨࡡࡢࠫ勆")+l11lll_l1_ (u"ࠩࡢࡣࠬ勇")
		l11l1l1lll11_l1_ = l11l1l1lll11_l1_.lower()
		name,type,l1l1111_l1_,l11l111l_l1_,l1lll1l11l11_l1_ = l11l1l1lll11_l1_.split(l11lll_l1_ (u"ࠪࡣࡤ࠭勈"))[:5]
	if l11l111l_l1_==l11lll_l1_ (u"ࠫࠬ勉"): l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠶ࠧ勊")
	else: l11l111l_l1_ = l11l111l_l1_.replace(l11lll_l1_ (u"࠭ࡰࠨ勋"),l11lll_l1_ (u"ࠧࠨ勌")).replace(l11lll_l1_ (u"ࠨࠢࠪ勍"),l11lll_l1_ (u"ࠩࠪ勎"))
	l11l11l_l1_ = l11l11l_l1_.strip(l11lll_l1_ (u"ࠪࡃࠬ勏")).strip(l11lll_l1_ (u"ࠫ࠴࠭勐")).strip(l11lll_l1_ (u"ࠬࠬࠧ勑"))
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"࠭ࡨࡰࡵࡷࠫ勒"))
	if name: l111ll1ll11l_l1_ = name
	#elif source: l111ll1ll11l_l1_ = source
	else: l111ll1ll11l_l1_ = server
	l111ll1ll11l_l1_ = SERVER(l111ll1ll11l_l1_,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ勓"))
	name = name.replace(l11lll_l1_ (u"ࠨ็หหูืࠧ勔"),l11lll_l1_ (u"ࠩࠪ動")).replace(l11lll_l1_ (u"ࠪื๏ืแาࠩ勖"),l11lll_l1_ (u"ࠫࠬ勗")).replace(l11lll_l1_ (u"ࠬอไࠡࠩ勘"),l11lll_l1_ (u"࠭ࠠࠨ務")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ勚"),l11lll_l1_ (u"ࠨࠢࠪ勛"))
	l11l1l1lll11_l1_ = l11l1l1lll11_l1_.replace(l11lll_l1_ (u"่ࠩฬฬฺัࠨ勜"),l11lll_l1_ (u"ࠪࠫ勝")).replace(l11lll_l1_ (u"ุࠫ๐ัโำࠪ勞"),l11lll_l1_ (u"ࠬ࠭募")).replace(l11lll_l1_ (u"࠭วๅࠢࠪ勠"),l11lll_l1_ (u"ࠧࠡࠩ勡")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫ勢"),l11lll_l1_ (u"ࠩࠣࠫ勣"))
	l111ll1ll11l_l1_ = l111ll1ll11l_l1_.replace(l11lll_l1_ (u"้ࠪออิาࠩ勤"),l11lll_l1_ (u"ࠫࠬ勥")).replace(l11lll_l1_ (u"ู๊ࠬาใิࠫ勦"),l11lll_l1_ (u"࠭ࠧ勧")).replace(l11lll_l1_ (u"ࠧศๆࠣࠫ勨"),l11lll_l1_ (u"ࠨࠢࠪ勩")).replace(l11lll_l1_ (u"ࠩࠣࠤࠬ勪"),l11lll_l1_ (u"ࠪࠤࠬ勫"))
	return l11l11l_l1_,l11l1l1lll11_l1_,server,l111ll1ll11l_l1_,name,type,l1l1111_l1_,l11l111l_l1_
def l11l1lllllll_l1_(url,source):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ勬"),l11lll_l1_ (u"ࠬ࠭勭"),url,l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇࠪ勮"))
	# l1lll1ll1_l1_	: سيرفر خاص
	# l11l1ll1l11l_l1_		: سيرفر محدد
	# l11l1l1ll1l1_l1_		: سيرفر عام معروف
	# l1ll1ll11_l1_	: سيرفر عام خارجي
	# l1111ll11l1l_l1_	: سيرفر عام خارجي
	l111ll111ll1_l1_,name,l1lll1ll1_l1_,l11l1l1ll1l1_l1_,l1ll1ll11_l1_,l11l1ll1l11l_l1_,l1111ll11l1l_l1_ = l11lll_l1_ (u"ࠧࠨ勯"),l11lll_l1_ (u"ࠨࠩ勰"),None,None,None,None,None
	l11l11l_l1_,l11l1l1lll11_l1_,server,l111ll1ll11l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11111ll1l1l_l1_(url,source)
	if l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ勱") in url:
		if   type==l11lll_l1_ (u"ࠪࡩࡲࡨࡥࡥࠩ勲"): type = l11lll_l1_ (u"ࠫࠥ࠭勳")+l11lll_l1_ (u"๋ࠬแืๆࠪ勴")
		elif type==l11lll_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ勵"): type = l11lll_l1_ (u"ࠧࠡࠩ勶")+l11lll_l1_ (u"ࠨุ่ࠧฬํฯสࠩ勷")
		elif type==l11lll_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ勸"): type = l11lll_l1_ (u"ࠪࠤࠬ勹")+l11lll_l1_ (u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭勺")
		elif type==l11lll_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ勻"): type = l11lll_l1_ (u"࠭ࠠࠨ勼")+l11lll_l1_ (u"ࠧࠦࠧࠨฮา๋๊ๅࠩ勽")
		elif type==l11lll_l1_ (u"ࠨࠩ勾"): type = l11lll_l1_ (u"ࠩࠣࠫ勿")+l11lll_l1_ (u"ࠪࠩࠪࠫࠥࠨ匀")
		if l1l1111_l1_!=l11lll_l1_ (u"ࠫࠬ匁"):
			if l11lll_l1_ (u"ࠬࡳࡰ࠵ࠩ匂") not in l1l1111_l1_: l1l1111_l1_ = l11lll_l1_ (u"࠭ࠥࠨ匃")+l1l1111_l1_
			l1l1111_l1_ = l11lll_l1_ (u"ࠧࠡࠩ匄")+l1l1111_l1_
		if l11l111l_l1_!=l11lll_l1_ (u"ࠨࠩ包"):
			l11l111l_l1_ = l11lll_l1_ (u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬ匆")+l11l111l_l1_
			l11l111l_l1_ = l11lll_l1_ (u"ࠪࠤࠬ匇")+l11l111l_l1_[-9:]
	#if any(value in server for value in l111lllll1ll_l1_): return l11lll_l1_ (u"ࠫࠬ匈")
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭匉"),l11lll_l1_ (u"࠭ࠧ匊"),name,l111ll1ll11l_l1_)
	if   l11lll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭匋")		in source: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ匌")		in source: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ匍")
	elif l11lll_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ匎")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭匏")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫ匐")	in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭匑")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ匒")
	#elif l11lll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡴࡶࡤࡸ࡮ࡵ࡮ࠨ匓") in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ匔")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ匕")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	#elif l11lll_l1_ (u"ࠫࡵࡩࡲࡦࡸ࡬ࡩࡼ࠭化")	in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭北")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭匘")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ匙")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ匚")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ匛")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮ࡥ࡯ࡹࡧ࠭匜")	in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡵ࠭匝")
	elif l11lll_l1_ (u"ࠬ็ฬาࠩ匞")			in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ匟")
	elif l11lll_l1_ (u"ࠧโๆึ฻๏์ࠧ匠")		in name:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨࡲࡤࡰࡪࡹࡴࡪࡰࡨࠫ匡")
	elif l11lll_l1_ (u"ࠩࡪࡨࡷ࡯ࡶࡦࠩ匢")		in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪ匣")
	elif l11lll_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ匤")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ匥")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ匦")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠧ࡯ࡧࡺࡧ࡮ࡳࡡࠨ匧")		in name:   l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭匨")	in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠩࡥࡳࡰࡸࡡࠨ匩")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠪࡸࡻ࡬ࡵ࡯ࠩ匪")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠫࡹࡼ࡫ࡴࡣࠪ匫")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠬࡧ࡮ࡢࡸ࡬ࡨࡿ࠭匬")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"࠭ࡳࡩࡱࡲࡪࡵࡸ࡯ࠨ匭")		in server: l1lll1ll1_l1_	= l111ll1ll11l_l1_
	#elif l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷ࠯ࡰࡨࡸࠬ匮")	in l11l11l_l1_:   l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨࠢࠪ匯")
	elif l11lll_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ匰")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡦࡦ࠷ࡹࠬ匱")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫ匲")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ匳")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ匴")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠧࡤ࡫ࡰࡥࡦࡨࡤࡰࠩ匵")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠨࡻࡲࡹࡹࡻࠧ匶")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ匷")
	elif l11lll_l1_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ匸")	 	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ匹")
	elif l11lll_l1_ (u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪ区")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪ医")
	elif l11lll_l1_ (u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ匼")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪ匽")
	elif l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ匾")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠷ࠬ匿")
	#elif l11lll_l1_ (u"ࠫࡪ࡭ࡹ࠯ࡤࡨࡷࡹ࠭區")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭十")
	elif l11lll_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ卂")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ千")
	elif l11lll_l1_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ卄")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ卅")
	elif l11lll_l1_ (u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭卆")	in server: l1lll1ll1_l1_	= l11lll_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ升")
	elif l11lll_l1_ (u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭午")		in server: l1lll1ll1_l1_	= l11lll_l1_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ卉")
	elif l11lll_l1_ (u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ半")	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ卋")
	elif l11lll_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ卌")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ卍")
	elif l11lll_l1_ (u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭华")	 	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠬࡩࡡࡵࡥ࡫ࠫ协")
	elif l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ卐")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ卑")
	elif l11lll_l1_ (u"ࠨࡸ࡬ࡨࡧࡳࠧ卒")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ卓")
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ協")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠫࡲࡿࡶࡪࡦࠪ单")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ卖")		in server: l11l1ll1l11l_l1_	= l111ll1ll11l_l1_
	elif l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ南")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ単")
	elif l11lll_l1_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ卙")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠩࡪࡳࡻ࡯ࡤࠨ博")
	elif l11lll_l1_ (u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ卛") 	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭卜")
	elif l11lll_l1_ (u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ卝")	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ卞")
	elif l11lll_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ卟")	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭占")
	elif l11lll_l1_ (u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭卡") 	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ卢")
	elif l11lll_l1_ (u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ卣")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭卤")
	elif l11lll_l1_ (u"࠭ࡵࡱࡲࠪ卥") 			in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠧࡶࡲࡥࡳࡲ࠭卦")
	elif l11lll_l1_ (u"ࠨࡷࡳࡦࠬ卧") 			in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ卨")
	elif l11lll_l1_ (u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ卩") 		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ卪")
	elif l11lll_l1_ (u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ卫") 	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ卬")
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ卭")		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠨࡸ࡬ࡨࡧࡵࡢࠨ卮")
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩࡵࡺࡢࠩ卯") 		in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ印")
	elif l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ危") 	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩ卲")
	elif l11lll_l1_ (u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪ即")	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ却")
	elif l11lll_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ卵")	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭卶")
	#elif l11lll_l1_ (u"ࠪࡹࡵࡺ࡯ࡣࡱࡻࠫ卷") 	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"ࠫࡺࡶࡴࡰࡤࡲࡼࠬ卸")
	#elif l11lll_l1_ (u"ࠬࡻࡰࡵࡱࡶࡸࡷ࡫ࡡ࡮ࠩ卹")	in server: l11l1l1ll1l1_l1_	= l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ卺")
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࡹࡷࡲࠫࠨ࠿ࡀࡁࠬ࠱ࡵࡳ࡮࠵࠭ࠏࠏࠉࡵࡴࡼ࠾ࠏࠏࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠏࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭࠰ࡋࡳࡸࡺࡥࡥࡏࡨࡨ࡮ࡧࡆࡪ࡮ࡨࠬࡺࡸ࡬࠳ࠫ࠱ࡺࡦࡲࡩࡥࡡࡸࡶࡱ࠮ࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࠍ࡮࡬ࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࡷࡀࠊࠊࠋࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠴࠵࠶࠷ࠠ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭ࠩࠋࠋࠌࠍࡷ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠽ࠡࡈࡤࡰࡸ࡫ࠊࠊࠋࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡰࡷࡷࡹࡧ࡫࠭ࡥ࡮࠱ࡳࡷ࡭ࠊࠊࠋࠌࡰ࡮ࡹࡴࡠࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡼࡸࡩࡲ࠭ࡰࡴࡪ࠲࡬࡯ࡴࡩࡷࡥ࠲࡮ࡵ࠯ࡺࡱࡸࡸࡺࡨࡥ࠮ࡦ࡯࠳ࡸࡻࡰࡱࡱࡵࡸࡪࡪࡳࡪࡶࡨࡷ࠳࡮ࡴ࡮࡮ࠪࠎࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉ࠱ࡲࡩࡴࡶࡢࡹࡷࡲࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇ࠰࠵ࡸࡺࠧࠪࠌࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀࡺࡲ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌ࡭࡫ࠦࡨࡵ࡯࡯࠾ࠏࠏࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢ࡫ࡸࡲࡲ࡛࠱࡟࠱ࡰࡴࡽࡥࡳࠪࠬࠎࠎࠏࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࡯࡭ࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼ࡣࡀࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡮ࡴ࡮࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡂ࠯࡭࡫ࡁࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁ࠵ࡢ࠿ࠩ࠯ࠫࠬ࠯ࠊࠊࠋࠌࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡐࡒࡘࡎࡉࡅࠨ࠮ࠪ࠶࠷࠸࠲ࠡ࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠧࠪࠌࠌࠍࠎࠏࡰࡢࡴࡷࡷࠥࡃࠠࡴࡧࡵࡺࡪࡸ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠯ࠩࠬࠎࠎࠏࠉࠊࡨࡲࡶࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡰࡢࡴࡷࡷ࠿ࠐࠉࠊࠋࠌࠍ࡮࡬ࠠ࡭ࡧࡱࠬࡵࡧࡲࡵࠫ࠿࠸࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࠏࡥ࡭࡫ࡩࠤࡵࡧࡲࡵࠢ࡬ࡲࠥ࡮ࡴ࡮࡮࠽ࠎࠎࠏࠉࠊࠋࠌࡶࡪࡹ࡯࡭ࡸࡨࡶࠥࡃࠠࡕࡴࡸࡩࠏࠏࠉࠊࠋࠌࠍࡧࡸࡥࡢ࡭ࠍࠍࠧࠨࠢ卻")
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ卼"),l11lll_l1_ (u"ࠩࠪ卽"),url,l11l11l_l1_)
	if   l1lll1ll1_l1_:	l111ll111ll1_l1_,name = l11lll_l1_ (u"ࠪาฬ฻ࠧ卾"),l1lll1ll1_l1_
	elif l11l1ll1l11l_l1_:		l111ll111ll1_l1_,name = l11lll_l1_ (u"๋ࠫࠪอะัࠪ卿"),l11l1ll1l11l_l1_
	elif l11l1l1ll1l1_l1_:		l111ll111ll1_l1_,name = l11lll_l1_ (u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪ厀"),l11l1l1ll1l1_l1_
	elif l1ll1ll11_l1_:	l111ll111ll1_l1_,name = l11lll_l1_ (u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬ厁"),l1ll1ll11_l1_
	elif l1111ll11l1l_l1_:	l111ll111ll1_l1_,name = l11lll_l1_ (u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧ厂"),l111ll1ll11l_l1_
	else:			l111ll111ll1_l1_,name = l11lll_l1_ (u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩ厃"),l111ll1ll11l_l1_
	return l111ll111ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭࡫ࡩࠤࠬࡶ࡬ࡢࡻࡵ࠲࠹࡮ࡥ࡭ࡣ࡯ࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌࡴࡷ࡯ࡶࡢࡶࡨࠤࡂࠦࠧࡩࡧ࡯ࡥࡱ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡦࡵࡷࡶࡪࡧ࡭ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡪࡹࡴࡳࡧࡤࡱࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡧࡰࡷࡱࡰ࡮ࡳࡩࡵࡧࡧࠫࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪࠎࠎ࡫࡬ࡪࡨࠣࠫ࡮ࡴࡴࡰࡷࡳࡰࡴࡧࡤࠨࠢࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷ࠸࠺ࠊ࡭ࡱࡳࡼࡴࠠ࠾ࠢࠪ࡭ࡳࡺ࡯ࡶࡲ࡯ࡳࡦࡪࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡸࡨࡺ࠳࡯࡯ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡫ࡶࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡨ࡯࡮ࠩࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡪࡧࠫࠥࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡷ࡭ࡧࡲࡦࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠲࠻ࠋ࡮ࡲࡴࡽ࡮ࠡ࠿ࠣࠫࡻ࡯ࡤࡴࡪࡤࡶࡪ࠭ࠊࠊࠤࠥࠦ厄")
def l111l11llll1_l1_(url,source):
	l11l11l_l1_,l11l1l1lll11_l1_,server,l111ll1ll11l_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11111ll1l1l_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ厅"),l11lll_l1_ (u"ࠫࠬ历"),l11l1ll1l11l_l1_,server)
	#if l11lll_l1_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ厇")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭厈"),l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭厉"))
	#if any(value in server for value in l111lllll1ll_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ厊")],[]
	if   l11lll_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ压")		in source: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l111l_l1_(l11l11l_l1_,name)
	elif l11lll_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ厌")		in source: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111_l1_(l11l11l_l1_,type,l11l111l_l1_)
	elif l11lll_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭厍")		in source: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lllll11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ厎")		in source: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ厏")		in source: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll1l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ厐")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡣ࡮ࡳࡦࡳ࠮ࡤࡣࡰࠫ厑")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ厒")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1lll1ll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ厓")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11ll111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭厔")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11ll111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬ࡫ࡧࡺࡰࡲࡻࠬ厕")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1ll111l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡴࡷࡨࡸࡲࠬ厖")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡵࡸ࡮ࡷࡦ࠭厗")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡶࡹ࠱࡫࠴ࡣࡰ࡯ࠪ厘")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll11ll11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫ厙")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11l11l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ厚")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1llll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭厛")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l11lll11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧ厜")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l1l1ll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡶࡴ࠶ࡸࠫ厝")			in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1ll11l1l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭厞")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1llllll1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ原")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪ厠")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧ厡")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧ厢")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll1l1lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ厣")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1ll111l1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭厤")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1l11lllll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭厥")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11l1_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭厦")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1l11_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ厧")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ厨")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡸࡪࡩࡨࠨ厩")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠬ࡭ࡵ࡭ࡨࡷࡩࡨ࡮ࠧ厪")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"࠭ࡲࡦࡸ࡬ࡩࡼࡸࡡࡵࡧࠪ厫")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠧࡱࡥࡵࡩࡻ࡯ࡥࡸࠩ厬")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࠨ厭")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫ厮")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11l1l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨ厯")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠫࠬ厰"),[l11lll_l1_ (u"ࠬ࠭厱")],[l11l11l_l1_]
	#elif l11lll_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ厲")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111l1l1_l1_(url)
	elif l11lll_l1_ (u"ࠧࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ厳")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lllll111l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ厴")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1lll1l111l_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨ厵")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111111lll_l1_(l11l11l_l1_)
	elif l11lll_l1_ (u"ࠪࡹࡵࡨࡡ࡮ࠩ厶") 		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠫࠬ厷"),[l11lll_l1_ (u"ࠬ࠭厸")],[l11l11l_l1_]
	else: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ厹"),[l11lll_l1_ (u"ࠧࠨ厺")],[l11l11l_l1_]
	return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
def l11l1l1ll111_l1_(url,source):
	server = SERVER(url,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭去"))
	#if l11lll_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ厼")	in server: l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ厽"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ厾"))
	#if any(value in server for value in l111lllll1ll_l1_): l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡅࡔࡑࡏ࡚ࡊࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡴࡨࡷࡴࡲࡶࡦࠢࡷ࡬࡮ࡹࠠࡴࡧࡵࡺࡪࡸࠧ县")],[]
	l111l11lll1l_l1_ = False
	if   l11lll_l1_ (u"࠭ࡹࡰࡷࡷࡹࠬ叀")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lllll1l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧ叁")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lllll1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸࠬ参") in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll1lll1l_l1_(url)
	elif l11lll_l1_ (u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨ參")	in url: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llllll1l_l1_(url)
	elif l11lll_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ叄")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(url)
	elif l11lll_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡶࡦࡺࡥࠨ叅")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11ll1111_l1_(url)
	elif l11lll_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ叆")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll1l11_l1_(url)
	elif l11lll_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ叇")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1l1111_l1_(url)
	elif l11lll_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ又")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1l1lllll11_l1_(url)
	elif l11lll_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ叉")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1ll11l1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ及")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111lll11_l1_(url)
	elif l11lll_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ友")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll1111l1_l1_(url)
	elif l11lll_l1_ (u"ࠫࡪ࠻ࡴࡴࡣࡵࠫ双")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11ll1l11_l1_(url)
	elif l11lll_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ反")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11lll11l_l1_(url)
	elif l11lll_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ収")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l11lll11l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ叏")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ叐")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ发")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ叒")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭叓")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	elif l11lll_l1_ (u"ࠬࡲࡩࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ叔")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	elif l11lll_l1_ (u"࠭ࡶࡪࡦࡲࡦࡦ࠭叕")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll11l1_l1_(url)
	elif l11lll_l1_ (u"ࠧࡷ࡫ࡧࡷࡵ࡫ࡥࡥࠩ取")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111ll11l1_l1_(url)
	elif l11lll_l1_ (u"ࠨࡷࡳࡦࡦࡳࠧ受") 		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࠪ变"),[l11lll_l1_ (u"ࠪࠫ叙")],[url]
	#elif l11lll_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ叚")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111ll1ll_l1_(url)
	elif l11lll_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ叛") 	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111lllll111_l1_(url)
	elif l11lll_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ叜")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l111ll11l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳ࡭ࡵࠧ叝")in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll1l11ll_l1_(url)
	elif l11lll_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ叞") 	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l111ll1_l1_(url)
	elif l11lll_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ叟")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1l11lll_l1_(url)
	elif l11lll_l1_ (u"ࠪࡹࡵࡨࠧ叠") 			in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111l111l_l1_(url)
	elif l11lll_l1_ (u"ࠫࡺࡶࡰࠨ叡") 			in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111111l111l_l1_(url)
	#elif l11lll_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭叢") 	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1llll1l_l1_(url)
	#elif l11lll_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ口")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l1llll1l_l1_(url)
	elif l11lll_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ古") 		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111lll1l1l_l1_(url)
	elif l11lll_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ句") 	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111llll111l_l1_(url)
	elif l11lll_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ另")		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11ll111_l1_(url)
	elif l11lll_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ叧") 		in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l111l11l_l1_(url)
	elif l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ叨") 	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l111l1111_l1_(url)
	elif l11lll_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ叩")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111llll11l_l1_(url)
	elif l11lll_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ只")	in server: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111ll11111l_l1_(url)
	else: l111l11lll1l_l1_ = True
	if l111l11lll1l_l1_ or l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠩ叫") in l11ll1111lll_l1_:
		l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠠࡇࡣ࡬ࡰࡪࡪࠧ召"),[],[]
	return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
	l11lll_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭࡫ࡩࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇࡖࡘࡗࡋࡁࡎࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡍࡏࡖࡐࡏࡍࡒࡏࡔࡆࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡉࡏࡖࡒ࡙ࡕࡒࡏࡂࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡙ࡎࡅࡗࡋࡇࡉࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡫ࡶ࠯࡫ࡲࠫࠎࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡆࡘࡌࡓ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡴࡱࡧࡹࡳ࠰࠷࡬ࡪࡲࡡ࡭ࠩࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡋࡉࡑࡇࡌࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡆࡔࡓࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡪࡧࠫࠥࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡋࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡳࡩࡣࡵࡩࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡖࡌࡆࡘࡅࠩࡷࡵࡰ࠮ࠐࠉࠣࠤࠥ叭")
def l111lll1l1l1_l1_(l11llllll1l1_l1_):
	if l11lll_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ叮") in str(type(l11llllll1l1_l1_)):
		links = []
		for link in l11llllll1l1_l1_:
			if l11lll_l1_ (u"ࠫࡸࡺࡲࠨ可") in str(type(link)):
				link = link.replace(l11lll_l1_ (u"ࠬࡢࡲࠨ台"),l11lll_l1_ (u"࠭ࠧ叱")).replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ史"),l11lll_l1_ (u"ࠨࠩ右")).strip(l11lll_l1_ (u"ࠩࠣࠫ叴"))
			links.append(link)
	else: links = l11llllll1l1_l1_.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭叵"),l11lll_l1_ (u"ࠫࠬ叶")).replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ号"),l11lll_l1_ (u"࠭ࠧ司")).strip(l11lll_l1_ (u"ࠧࠡࠩ叹"))
	return links
def l1111l11ll1l_l1_(url,source):
	LOG_THIS(l11lll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ叺"),LOGGING(script_name)+l11lll_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ叻")+url+l11lll_l1_ (u"ࠪࠤࡢ࠭叼"))
	l1111ll11l1l_l1_,link,l111lll1l1ll_l1_ = l11lll_l1_ (u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨ叽"),l11lll_l1_ (u"ࠬ࠭叾"),l11lll_l1_ (u"࠭ࠧ叿")
	l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l111l11llll1_l1_(url,source)
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ吀"),l11lll_l1_ (u"ࠨࠩ吁"),l11lll_l1_ (u"ࠩࠪ吂"),l11ll1111lll_l1_)
	l1111_l1_ = l111lll1l1l1_l1_(l1111_l1_)
	if l11ll1111lll_l1_==l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ吃"): return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
	elif l1111_l1_: link = l1111_l1_[0]
	if l11ll1111lll_l1_==l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ各"):
		#l11ll1111lll_l1_ = l11ll1111lll_l1_.replace(l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ吅"),l11lll_l1_ (u"࠭ࠧ吆"))
		l1111ll11l1l_l1_ = l11lll_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶࠭吇")
		l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1ll111_l1_(link,source)
		l1111_l1_ = l111lll1l1l1_l1_(l1111_l1_)
		if l11ll1111lll_l1_==l11lll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭合"): return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
		elif l11lll_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ吉") in l11ll1111lll_l1_:
			l111lll1l1ll_l1_ += l11lll_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠫ吊")+l11ll1111lll_l1_
			l1111ll11l1l_l1_ = l11lll_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ吋")
			l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1l1lll_l1_(link,source)
			l1111_l1_ = l111lll1l1l1_l1_(l1111_l1_)
			if l11ll1111lll_l1_==l11lll_l1_ (u"ࠬࡋࡘࡊࡖࠪ同"): return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
			elif l11lll_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ名") in l11ll1111lll_l1_:
				l111lll1l1ll_l1_ += l11lll_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠨ后")+l11ll1111lll_l1_
				l1111ll11l1l_l1_ = l11lll_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧ吏")
				l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11l1l1l1ll1_l1_(link,source)
				l1111_l1_ = l111lll1l1l1_l1_(l1111_l1_)
				if l11ll1111lll_l1_==l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ吐"): return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
				elif l11lll_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ向") in l11ll1111lll_l1_:
					l111lll1l1ll_l1_ += l11lll_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵࠽ࠤࠬ吒")+l11ll1111lll_l1_
	elif l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ吓") in l11ll1111lll_l1_: l111lll1l1ll_l1_ = l11lll_l1_ (u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠲࠽ࠤࠬ吔")+l11ll1111lll_l1_
	if l1111_l1_: LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ吕"),LOGGING(script_name)+l11lll_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫ吖")+l1111ll11l1l_l1_+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭吗")+url+l11lll_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ吘")+link+l11lll_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡸࡻ࡬ࡵࡵ࠽ࠤࡠࠦࠧ吙")+str(l1111_l1_)+l11lll_l1_ (u"ࠬࠦ࡝ࠨ吚"))
	else: LOG_THIS(l11lll_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ君"),LOGGING(script_name)+l11lll_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ吜")+url+l11lll_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ吝")+link+l11lll_l1_ (u"ࠩࠣࡡࠥࠦࠠࡆࡴࡵࡳࡷࡹ࠺ࠡ࡝ࠣࠫ吞")+l111lll1l1ll_l1_+l11lll_l1_ (u"ࠪࠤࡢ࠭吟"))
	l111lll1l1ll_l1_ = l111l_l1_(l111lll1l1ll_l1_)
	return l111lll1l1ll_l1_,l1lll1ll_l1_,l1111_l1_
def l1111lll1ll1_l1_(l11lllll11l1_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ吠"),l11lllll11l1_l1_)
	l11llll1111_l1_ = l11111l_l1_
	data = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠬࡲࡩࡴࡶࠪ吡"),l11lll_l1_ (u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧ吢"),l11lllll11l1_l1_)
	if data:
		l1lll1ll_l1_,l1111_l1_ = list(zip(*data))
		return l1lll1ll_l1_,l1111_l1_
	l1lll1ll_l1_,l1111_l1_,l11ll1111l1l_l1_ = [],[],[]
	for link in l11lllll11l1_l1_:
		if l11lll_l1_ (u"ࠧ࠰࠱ࠪ吣") not in link: continue
		l111ll111ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_ = l11l1lllllll_l1_(link,source)
		l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡞ࡧ࠯ࠬ吤"),l11l111l_l1_,re.DOTALL)
		if l11l111l_l1_: l11l111l_l1_ = int(l11l111l_l1_[0])
		else: l11l111l_l1_ = 0
		#if l11l111l_l1_:
		#	l11l1l11ll1l_l1_ = sorted(l11l111l_l1_,reverse=True,key=lambda key: int(key))
		#	l11l111l_l1_ = int(l11l1l11ll1l_l1_[0])
		#else: l11l111l_l1_ = 0
		server = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ吥"))
		l11ll1111l1l_l1_.append([l111ll111ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server])
	if l11ll1111l1l_l1_:
		#l111ll111ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link = zip(*l11ll1111l1l_l1_)
		#name = reversed(name)
		#l11ll1111l1l_l1_ = zip(l111ll111ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link)
		l1lll11lllll_l1_ = sorted(l11ll1111l1l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l111lll11l11_l1_ = []
		for line in l1lll11lllll_l1_:
			if line not in l111lll11l11_l1_:
				l111lll11l11_l1_.append(line)
				#LOG_THIS(l11lll_l1_ (u"ࠪࠫ否"),str(line))
		for l111ll111ll1_l1_,name,type,l1l1111_l1_,l11l111l_l1_,link,server in l111lll11l11_l1_:
			if l11l111l_l1_: l11l111l_l1_ = str(l11l111l_l1_)
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠫࠬ吧")
			#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭吨"),l11lll_l1_ (u"࠭ࠧ吩"),name,link)
			title = l11lll_l1_ (u"ࠧิ์ิๅึ࠭吪")+l11lll_l1_ (u"ࠨࠢࠪ含")+type+l11lll_l1_ (u"ࠩࠣࠫ听")+l111ll111ll1_l1_+l11lll_l1_ (u"ࠪࠤࠬ吭")+l11l111l_l1_+l11lll_l1_ (u"ࠫࠥ࠭吮")+l1l1111_l1_+l11lll_l1_ (u"ࠬࠦࠧ启")+name
			if server not in title: title = title+l11lll_l1_ (u"࠭ࠠࠨ吰")+server
			title = title.replace(l11lll_l1_ (u"ࠧࠦࠩ吱"),l11lll_l1_ (u"ࠨࠩ吲")).strip(l11lll_l1_ (u"ࠩࠣࠫ吳")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭吴"),l11lll_l1_ (u"ࠫࠥ࠭吵")).replace(l11lll_l1_ (u"ࠬࠦࠠࠨ吶"),l11lll_l1_ (u"࠭ࠠࠨ吷")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪ吸"),l11lll_l1_ (u"ࠨࠢࠪ吹"))
			if link not in l1111_l1_:
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		if l1111_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ吺"),l1111_l1_)
			data = list(zip(l1lll1ll_l1_,l1111_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ吻"),l11lllll11l1_l1_,data,l11llll1111_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ吼"),l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠽࠶࠿ࠦࠠࠡࠩ吽")+str(data))
	return l1lll1ll_l1_,l1111_l1_
def l11l1l1l1lll_l1_(url,source):
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡅࡥ࡜ࡥࡪࡦࡰࡲࡾࡐࡩࠧ吾")
	l1llll1111l1_l1_ = l11lll_l1_ (u"ࠧࠨ吿")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l11l1ll1l1l1_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1llll1111l1_l1_ = str(error)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ呀"),l11lll_l1_ (u"ࠩࠪ呁"),l11lll_l1_ (u"ࠪࠫ呂"),str(results))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ呃"),l11lll_l1_ (u"ࠬ࠭呄"),l11lll_l1_ (u"࠭ࠧ呅"),str(l1llll1111l1_l1_))
	# resolveurl l1111l1l11_l1_ l1ll1l11l1l_l1_ l1111ll11111_l1_ with l11111l1l11l_l1_ error or l111llll1111_l1_ value False
	if not results:
		if l1llll1111l1_l1_==l11lll_l1_ (u"ࠧࠨ呆"):
			l1llll1111l1_l1_ = traceback.format_exc()
			sys.stderr.write(l1llll1111l1_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ呇"),l11lll_l1_ (u"ࠩࠪ呈"),l11lll_l1_ (u"ࠪࠫ呉"),str(l1llll1111l1_l1_))
		l11ll1111lll_l1_ = l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠣࡊࡦ࡯࡬ࡦࡦࠪ告")
		l11ll1111lll_l1_ += l11lll_l1_ (u"ࠬࠦࠧ呋")+l1llll1111l1_l1_.splitlines()[-1]
		return l11ll1111lll_l1_,[],[]
	return l11lll_l1_ (u"࠭ࠧ呌"),[l11lll_l1_ (u"ࠧࠨ呍")],[results]
def l11l1l1l1ll1_l1_(url,source):
	#url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡇࡧࡗࡠ࡬ࡨࡲࡴࢀࡋࡤࠩ呎")
	#url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮࠱ࡹ࡭ࡩ࡫࡯࠰ࡺ࠺ࡽࡾ࠺࠱ࡴࠩ呏")
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ呐"),l11lll_l1_ (u"ࠫࠬ呑"),url,l11lll_l1_ (u"ࠬ࠭呒"))
	#return l11lll_l1_ (u"࠭ࠧ呓"),[],[]
	l1llll1111l1_l1_ = l11lll_l1_ (u"ࠧࠨ呔")
	results = False
	try:
		import youtube_dl
		l11l1llll111_l1_ = youtube_dl.YoutubeDL({l11lll_l1_ (u"ࠨࡰࡲࡣࡨࡵ࡬ࡰࡴࠪ呕"): True})
		results = l11l1llll111_l1_.extract_info(url,download=False)
	except Exception as error: l1llll1111l1_l1_ = str(error)
	# youtube_dl l1111l1l11_l1_ l1ll1l11l1l_l1_ l1111ll11111_l1_ with l11111l1l11l_l1_ error or l111llll1111_l1_ value False
	if not results or l11lll_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ呖") not in list(results.keys()):
		if l1llll1111l1_l1_==l11lll_l1_ (u"ࠪࠫ呗"):
			l1llll1111l1_l1_ = traceback.format_exc()
			sys.stderr.write(l1llll1111l1_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ员"),l11lll_l1_ (u"ࠬ࠭呙"),l11lll_l1_ (u"࠭ࠧ呚"),l1llll1111l1_l1_)
		l11ll1111lll_l1_ = l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸ࠦࡆࡢ࡫࡯ࡩࡩ࠭呛")
		l11ll1111lll_l1_ += l11lll_l1_ (u"ࠨࠢࠪ呜")+l1llll1111l1_l1_.splitlines()[-1]
		return l11ll1111lll_l1_,[],[]
	else:
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link in results[l11lll_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ呝")]:
			l1lll1ll_l1_.append(link[l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࠪ呞")])
			l1111_l1_.append(link[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ呟")])
		return l11lll_l1_ (u"ࠬ࠭呠"),l1lll1ll_l1_,l1111_l1_
def l11l1lll1ll1_l1_(url):
	if l11lll_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ呡") in url:
		l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(url)
		if l1111_l1_: return l11lll_l1_ (u"ࠧࠨ呢"),l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡑࡇࡒࡂࡄࠪ呣"),[],[]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ呤"),[l11lll_l1_ (u"ࠪࠫ呥")],[url]
def l1l11l1l111_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ呦"),l11lll_l1_ (u"ࠬ࠭呧"),l11lll_l1_ (u"࠭ࠧ周"),url)
	l1lllll1_l1_,l1lllll11l1_l1_ = [],[]
	if l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪ呩") in url:
		# l11l111l1ll1_l1_:
		# https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1111ll11lll_l1_.html
		# https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l11ll11l1l_l1_.l1111lll_l1_?l1l11l1ll11_l1_=49e3a27b4
		# l111l1ll1ll1_l1_: https://l111llll1l11_l1_.l1ll1ll1l11_l1_.l11111l111l1_l1_.l1ll1lll111_l1_/15/items/40animeHD/l111lll1ll11_l1_.l1111lll_l1_
		# l11l111l1ll1_l1_:
		# https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l111l111l1l1_l1_-l11l11111l11_l1_.html
		# https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l11ll11l1l_l1_.l1111lll_l1_?l1l11l1ll11_l1_=l11111llllll_l1_
		# l111l1ll1ll1_l1_: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l11ll11l1l_l1_/l111ll1lllll_l1_%20.l1111lll_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ呪"),url,l11lll_l1_ (u"ࠩࠪ呫"),l11lll_l1_ (u"ࠪࠫ呬"),False,l11lll_l1_ (u"ࠫࠬ呭"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧ呮"))
		if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ呯") in response.headers:
			link = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ呰")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠨࡰࡤࡱࡪ࠭呱"))
			l1lllll11l1_l1_.append(server)
	elif l11lll_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨ呲") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l11l111l1ll1_l1_:
		# url: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_11l1ll1llll_l1_.html
		# link: https://www.l1l11l1l1l1_l1_.com/l11111lllll1_l1_/l11l1llll1ll_l1_/?link=https://drive.google.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l11l1l1lllll_l1_&l11111lll111_l1_=
		# l11l111l1ll1_l1_:
		# url: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# link: https://www.l1l11l1l1l1_l1_.com/l11111lllll1_l1_/l1l11llll_l1_.l1ll1lll1l_l1_?url=l11111l1ll11_l1_==&sub=https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l11l111lll11_l1_/l11111l1l1l1_l1_.l1111l111l1l_l1_&l11111lll111_l1_=https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l1111lll1111_l1_/l111111l1l1l_l1_-1.l111l1111ll1_l1_
		# l11l111l1ll1_l1_:
		# url: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111ll1ll1ll_l1_.html
		# link: https://www.l1l11l1l1l1_l1_.com/l11111lllll1_l1_/l111ll1111ll_l1_/?url=https://photos.l111l1l1l11_l1_.l11l111l11l1_l1_.l11ll11ll1ll_l1_/l111llll11ll_l1_&sub=&l11111lll111_l1_=http://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l1111lll1111_l1_/4723b8ebe-1.l111l1111ll1_l1_
		# l11l111l1ll1_l1_:
		# https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l11l1lll1l11_l1_.html
		# https://www.l1l11l1l1l1_l1_.com/l11111lllll1_l1_/l11l1llll1ll_l1_/?link=https://l1l11111ll1_l1_.google.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l11l1l1lllll_l1_&sub=&l11111lll111_l1_=https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l1111lll1111_l1_/2e8bc4c34-1.l111l1111ll1_l1_
		# l11l111l1ll1_l1_:
		# https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_111l11ll1l1_l1_.html
		# https://www.l1l11l1l1l1_l1_.com/l11111lllll1_l1_/l11l1llll1ll_l1_/?link=https://drive.google.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l11l1ll1111l_l1_=l11l1l1llll1_l1_&l11111lll111_l1_=https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l1111lll1111_l1_/l11l111l1l1l_l1_-1.l111l1111ll1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ味"),url,l11lll_l1_ (u"ࠫࠬ呴"),l11lll_l1_ (u"ࠬ࠭呵"),l11lll_l1_ (u"࠭ࠧ呶"),l11lll_l1_ (u"ࠧࠨ呷"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪ呸"))
		html = response.content
		l1ll11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ呹"),html,re.DOTALL)
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ呺"),str(l1ll11ll11ll_l1_))
		if l1ll11ll11ll_l1_:
			l1ll11ll11ll_l1_ = l1ll11ll11ll_l1_[0]
			l1l1l1lll11l_l1_ = l1l1lll111l1_l1_(l1ll11ll11ll_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠫࠬ呻"),str(l1l1l1lll11l_l1_))
			l1l1l1l11lll_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪ࠮ࠪ呼"),l1l1l1lll11l_l1_,re.DOTALL)
			if l1l1l1l11lll_l1_:
				l1l1l1l11lll_l1_ = l1l1l1l11lll_l1_[0]
				l1l1l1l11lll_l1_ = EVAL(l11lll_l1_ (u"࠭࡬ࡪࡵࡷࠫ命"),l1l1l1l11lll_l1_)
				for dict in l1l1l1l11lll_l1_:
					link = dict[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࠬ呾")]
					l11l111l_l1_ = dict[l11lll_l1_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ呿")]
					#link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࡢࡣࠬ咀")+l11l111l_l1_
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠪࡲࡦࡳࡥࠨ咁"))
					l1lllll11l1_l1_.append(l11l111l_l1_+l11lll_l1_ (u"ࠫࠥ࠭咂")+server)
		elif l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ咃") in response.headers:
			link = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ咄")]
			l1lllll1_l1_.append(link)
			server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ咅"))
			l1lllll11l1_l1_.append(server)
		# l11l111l1ll1_l1_: 5
		# url: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_111ll1ll1ll_l1_.html
		# link: https://www.l1l11l1l1l1_l1_.com/l11111lllll1_l1_/l111ll1111ll_l1_/?url=https://photos.l111l1l1l11_l1_.l11l111l11l1_l1_.l11ll11ll1ll_l1_/l111llll11ll_l1_&sub=&l11111lll111_l1_=http://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l1111l11llll_l1_/l1111lll1111_l1_/4723b8ebe-1.l111l1111ll1_l1_
		if l11lll_l1_ (u"ࠨࡁࡸࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬ࡵ࡯ࠨ咆") in url:
			link = url.split(l11lll_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࠨ咇"))[1]
			link = link.split(l11lll_l1_ (u"ࠪࠪࠬ咈"))[0]
			if link:
				l1lllll1_l1_.append(link)
				l1lllll11l1_l1_.append(l11lll_l1_ (u"ࠫࡵ࡮࡯ࡵࡱࡶࠤ࡬ࡵ࡯ࡨ࡮ࡨࠫ咉"))
	else:
		# l11l111l1ll1_l1_:
		# url: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_11111ll1ll1_l1_.html
		# link: http://ok.l11l111l11ll_l1_/l11l11ll1111_l1_/1676019108395
		# l11l111l1ll1_l1_:
		# url: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_11111llll1l_l1_.html
		# link: https://drive.google.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l11l1l1lllll_l1_
		l1lllll1_l1_.append(url)
		server = SERVER(url,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ咊"))
		l1lllll11l1_l1_.append(server)
	if not l1lllll1_l1_: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡍࡄࡘࡐࡕࡕࡕࡇࠪ咋"),[],[]
	elif len(l1lllll1_l1_)==1: link = l1lllll1_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ和"),l1lllll11l1_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭咍"),[],[]
		link = l1lllll1_l1_[l1l_l1_]
	return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ咎"),[l11lll_l1_ (u"ࠪࠫ咏")],[link]
def l111ll1lll1l_l1_(url):
	# test from: https://www.l1l11l1l1l1_l1_.com/l11ll1l1l_l1_/l11l1ll111ll_l1_-l111lll11111_l1_-l111l1ll1lll_l1_-l1111llllll1_l1_-l111l1111l1l_l1_-l11ll11l1l_l1_-1-date.html
	# url = https://l11l1l1111ll_l1_.l111111l1ll1_l1_.com/l111l1ll111l_l1_=l11l1111111l_l1_
	headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ咐"):l11lll_l1_ (u"ࠬࡑ࡯ࡥ࡫࠲ࠫ咑")+str(kodi_version)}
	for l11l1lllll_l1_ in range(50):
		time.sleep(0.100)
		response = l11lll1l111_l1_(l11lll_l1_ (u"࠭ࡇࡆࡖࠪ咒"),url,l11lll_l1_ (u"ࠧࠨ咓"),headers,False,l11lll_l1_ (u"ࠨࠩ咔"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭咕"))
		if l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ咖") in list(response.headers.keys()):
			link = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭咗")]
			link = link+l11lll_l1_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ咘")+headers[l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ咙")]
			return l11lll_l1_ (u"ࠧࠨ咚"),[l11lll_l1_ (u"ࠨࠩ咛")],[link]
		if response.code!=429: break
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔࠨ咜"),[],[]
def l111llllll1l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ咝"),l11lll_l1_ (u"ࠫࠬ咞"),l11lll_l1_ (u"ࠬ࠭咟"),url)
	# https://photos.l111l1l1l11_l1_.l11l111l11l1_l1_.l11ll11ll1ll_l1_/l111llll11ll_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ咠"),url,l11lll_l1_ (u"ࠧࠨ咡"),l11lll_l1_ (u"ࠨࠩ咢"),l11lll_l1_ (u"ࠩࠪ咣"),l11lll_l1_ (u"ࠪࠫ咤"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠳࠱ࡴࡶࠪ咥"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱࠮ࡄ࠯ࠢ࠭࠰࠭ࡃ࠱࠴ࠪࡀ࠮ࠫ࠲࠯ࡅࠩ࠭ࠩ咦"),html,re.DOTALL)
	if link:
		link,l11l111l_l1_ = link[0]
		return l11lll_l1_ (u"࠭ࠧ咧"),[l11l111l_l1_],[link]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨ咨"),[],[]
def l1l1lllll11_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ咩"),l11lll_l1_ (u"ࠩࠪ咪"),l11lll_l1_ (u"ࠪࠫ咫"),url)
	#url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡳࡳ࡫࠯ࡷ࡫ࡧࡩࡴࡥࡰ࡭ࡣࡼࡩࡷࡅࡵࡪࡦࡀ࠴ࠫࡼࡩࡥ࠿ࡩࡪࡧ࠽࠰࠹ࡥ࠴࠽࠷ࡩ࠲࠹ࡦ࠴࠵࠷࠶࠲ࡢࡦ࠴࠼ࡩࡪ࠱࠳ࡥ࠹࠼࠵࠼ࠧ咬")
	#url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡵࡨࡰ࡭ࡪ࠭ࡦ࡯ࡥࡩࡩ࠴ࡳࡤࡦࡱ࠲ࡹࡵ࠯ࡷ࡫ࡧࡩࡴࡥࡰ࡭ࡣࡼࡩࡷࡅࡵࡪࡦࡀ࠴ࠫࡼࡩࡥ࠿ࡥ࠴࠶࠻࠹࠱࠶ࡤ࠼ࡦࡩࡦ࠸࠻࠸࠺ࡩ࠷ࡥ࠸࠸࠶࠴ࡧ࡫࠱࠸࠸࠸࠼࠼࠹ࠧ咭")
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ咮"),url,l11lll_l1_ (u"ࠧࠨ咯"),l11lll_l1_ (u"ࠨࠩ咰"),l11lll_l1_ (u"ࠩࠪ咱"),l11lll_l1_ (u"ࠪࠫ咲"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡖࡉࡑࡎࡄ࠲࠯࠴ࡷࡹ࠭咳"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"ࠬ࠭咴"),html)
	link = re.findall(l11lll_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ咵"),html,re.DOTALL)
	if link: return l11lll_l1_ (u"ࠧࠨ咶"),[l11lll_l1_ (u"ࠨࠩ咷")],[link[0]]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠶࠭咸"),[],[]
def l1111l11l_l1_(url):
	if l11lll_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ咹") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ咺"),url,l11lll_l1_ (u"ࠬ࠭咻"),l11lll_l1_ (u"࠭ࠧ咼"),l11lll_l1_ (u"ࠧࠨ咽"),l11lll_l1_ (u"ࠨࠩ咾"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩ咿"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ哀"),html,re.DOTALL)
		link = link[0]
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ品") in link: return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ哂"),[l11lll_l1_ (u"࠭ࠧ哃")],[link]
		return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇ࠴ࡖࠩ哄"),[],[]
	else: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ哅"),[l11lll_l1_ (u"ࠩࠪ哆")],[url]
def l1ll1ll111l_l1_(url):
	l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭哇"):l11lll_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ哈"),l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ哉"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭哊")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ哋"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ哌"),l11lll_l1_ (u"ࠩࠪ响"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪ哎"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哏"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ哐"),[],[]
	link = link[0]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ哑"),[l11lll_l1_ (u"ࠧࠨ哒")],[link]
def l1l11lll11l1_l1_(url):
	headers = {l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ哓"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ哔")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ哕"),url,l11lll_l1_ (u"ࠫࠬ哖"),headers,l11lll_l1_ (u"ࠬ࠭哗"),l11lll_l1_ (u"࠭ࠧ哘"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡏࡇࡒࡕࡓ࠲࠷ࡳࡵࠩ哙"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭哚"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡏࡐࡈࡓࡖࡔ࠭哛"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭哜"),[l11lll_l1_ (u"ࠫࠬ哝")],[link]
def l1l1l11l11l_l1_(url):
	l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ哞"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭哟")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ哠"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ員"),l11lll_l1_ (u"ࠩࠪ哢"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ哣"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ哤"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩ哥"),[],[]
	link = link[0]
	if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ哦") not in link: link = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭哧")+link
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ哨"),l11lll_l1_ (u"ࠩࠪ哩"),l11lll_l1_ (u"ࠪࠫ哪"),link)
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ哫"),[l11lll_l1_ (u"ࠬ࠭哬")],[link]
def l1llll1111_l1_(url):
	l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ哭"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ哮")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭哯"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠩࠪ哰"),l11lll_l1_ (u"ࠪࠫ哱"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡆࡈࡄࡐ࠯࠴ࡷࡹ࠭哲"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ哳"),html,re.DOTALL|re.IGNORECASE)
	if not link: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡇࡂࡅࡑࠪ哴"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ哵"),[l11lll_l1_ (u"ࠨࠩ哶")],[link]
def l1lll11ll11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ哷"),l11lll_l1_ (u"ࠪࠫ哸"),l11lll_l1_ (u"ࠫࠬ哹"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ哺"),url,l11lll_l1_ (u"࠭ࠧ哻"),l11lll_l1_ (u"ࠧࠨ哼"),l11lll_l1_ (u"ࠨࠩ哽"),l11lll_l1_ (u"ࠩࠪ哾"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩ哿"))
	html = response.content
	l11111ll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ唀"),html,re.DOTALL|re.IGNORECASE)
	if l11111ll1lll_l1_:
		l11111ll1lll_l1_ = l11111ll1lll_l1_[0][2:]
		#l11111ll1lll_l1_ = l11111ll1lll_l1_.decode(l11lll_l1_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬ唁"))
		l11111ll1lll_l1_ = base64.b64decode(l11111ll1lll_l1_)
		if kodi_version>18.99: l11111ll1lll_l1_ = l11111ll1lll_l1_.decode(l11lll_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ唂"))
		link = re.findall(l11lll_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ唃"),l11111ll1lll_l1_,re.DOTALL)
	else: link = l11lll_l1_ (u"ࠨࠩ唄")
	if not link: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡙࡜ࡆࡖࡐࠪ唅"),[],[]
	link = link[0]
	if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ唆") not in link: link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ唇")+link
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ唈"),[l11lll_l1_ (u"࠭ࠧ唉")],[link]
def l1111l1l1ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ唊"),url,l11lll_l1_ (u"ࠨࠩ唋"),l11lll_l1_ (u"ࠩࠪ唌"),l11lll_l1_ (u"ࠪࠫ唍"),l11lll_l1_ (u"ࠫࠬ唎"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧ唏"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ唐"),html,re.DOTALL)
	if not link: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠫ唑"),[],[]
	link = link[0]
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ唒"),[l11lll_l1_ (u"ࠩࠪ唓")],[link]
def l11lll1l11_l1_(url):
	id = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ唔"))[-1]
	if l11lll_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧࠫ唕") in url: url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨࠬ唖"),l11lll_l1_ (u"࠭ࠧ唗"))
	url = url.replace(l11lll_l1_ (u"ࠧ࠯ࡥࡲࡱ࠴࠭唘"),l11lll_l1_ (u"ࠨ࠰ࡦࡳࡲ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡭ࡦࡶࡤࡨࡦࡺࡡ࠰ࠩ唙"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭唚"),url,l11lll_l1_ (u"ࠪࠫ唛"),l11lll_l1_ (u"ࠫࠬ唜"),l11lll_l1_ (u"ࠬ࠭唝"),l11lll_l1_ (u"࠭ࠧ唞"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ唟"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ唠"),url)
	l11ll1111lll_l1_ = l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ唡")
	error = re.findall(l11lll_l1_ (u"ࠪࠦࡪࡸࡲࡰࡴࠥ࠲࠯ࡅࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ唢"),html,re.DOTALL)
	if error: l11ll1111lll_l1_ = error[0]
	url = re.findall(l11lll_l1_ (u"ࠫࡽ࠳࡭ࡱࡧࡪ࡙ࡗࡒࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ唣"),html,re.DOTALL)
	if not url and l11ll1111lll_l1_:
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭唤"),l11lll_l1_ (u"࠭ࠧ唥"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠩ唦"),l11ll1111lll_l1_)
		return l11ll1111lll_l1_,[],[]
	link = url[0].replace(l11lll_l1_ (u"ࠨ࡞࡟ࠫ唧"),l11lll_l1_ (u"ࠩࠪ唨"))
	l11llll1l1l1_l1_,l11lllll11l1_l1_ = l11ll11l11_l1_(link)
	owner = re.findall(l11lll_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡹࡣࡳࡧࡨࡲࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ唩"),html,re.DOTALL)
	if owner: l111l1l1llll_l1_,l11l1lll1lll_l1_,l11l11l1l111_l1_ = owner[0]
	else: l111l1l1llll_l1_,l11l1lll1lll_l1_,l11l11l1l111_l1_ = l11lll_l1_ (u"ࠫࠬ唪"),l11lll_l1_ (u"ࠬ࠭唫"),l11lll_l1_ (u"࠭ࠧ唬")
	l11l11l1l111_l1_ = l11l11l1l111_l1_.replace(l11lll_l1_ (u"ࠧ࡝࠱ࠪ唭"),l11lll_l1_ (u"ࠨ࠱ࠪ售"))
	l11l1lll1lll_l1_ = escapeUNICODE(l11l1lll1lll_l1_)
	l1lll1ll_l1_ = [l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭唯")+l11l1lll1lll_l1_+l11lll_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ唰")]+l11llll1l1l1_l1_
	l1111_l1_ = [l11l11l1l111_l1_]+l11lllll11l1_l1_
	l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬ唱")+str(len(l1111_l1_)-1)+l11lll_l1_ (u"ࠬࠦๅๅใࠬࠫ唲"),l1lll1ll_l1_)
	if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ唳"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11lll_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠹࠶࠲ࠧࡷࡵࡰࡂ࠭唴")+l11l11l1l111_l1_+l11lll_l1_ (u"ࠨࠨࡷࡩࡽࡺ࠽ࠨ唵")+l11l1lll1lll_l1_
		xbmc.executebuiltin(l11lll_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ唶")+new_path+l11lll_l1_ (u"ࠥ࠭ࠧ唷"))
		return l11lll_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ唸"),[],[]
	link =  l1111_l1_[l1l_l1_]
	return l11lll_l1_ (u"ࠬ࠭唹"),[l11lll_l1_ (u"࠭ࠧ唺")],[link]
def l111l11l1_l1_(link):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ唻"),link,l11lll_l1_ (u"ࠨࠩ唼"),l11lll_l1_ (u"ࠩࠪ唽"),l11lll_l1_ (u"ࠪࠫ唾"),l11lll_l1_ (u"ࠫࠬ唿"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄࡒࡏࡗࡇ࠭࠲ࡵࡷࠫ啀"))
	html = response.content
	if l11lll_l1_ (u"࠭࠮࡫ࡵࡲࡲࠬ啁") in link: url = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ啂"),html,re.DOTALL)
	else: url = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭啃"),html,re.DOTALL)
	if not url: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇࡕࡋࡓࡃࠪ啄"),[],[]
	url = url[0]
	if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ啅") not in url: url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ商")+url
	return l11lll_l1_ (u"ࠬ࠭啇"),[l11lll_l1_ (u"࠭ࠧ啈")],[url]
def l11l1l1l1111_l1_(url):
	# http://l111l1l11111_l1_.l1lll1111l1l_l1_/l11l1llllll1_l1_.html?l11l1ll1l11l_l1_=l111lll111l1_l1_
	# http://l111l1l11111_l1_.l1lll1111l1l_l1_/l11l1l11llll_l1_?op=l11111l11l1l_l1_&id=l11l1llllll1_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ啉") : l11lll_l1_ (u"ࠨࠩ啊") }
	if l11lll_l1_ (u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ啋") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ啌"),headers,l11lll_l1_ (u"ࠫࠬ啍"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠵ࡸࡺࠧ啎"))
		#xbmc.log(html)
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ問"),l11lll_l1_ (u"ࠧࠨ啐"),url,html)
		items = re.findall(l11lll_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠡ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ啑"),html,re.DOTALL)
		if items: return l11lll_l1_ (u"ࠩࠪ啒"),[l11lll_l1_ (u"ࠪࠫ啓")],[items[0]]
		else:
			message = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡸࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ啔"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11lll_l1_ (u"ࠬ࠭啕"),l11lll_l1_ (u"࠭ࠧ啖"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩ啗"),message[0])
				return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩ啘")+message[0],[],[]
	else:
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ啙"),l11lll_l1_ (u"ࠪࠫ啚"),link,l11lll_l1_ (u"ࠫࠬ啛"))
		#url,l1ll111lll1_l1_ = url.split(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭啜"))
		#l1ll111lll1_l1_ = l1ll111lll1_l1_.lower()
		l1ll111lll1_l1_ = l11lll_l1_ (u"࠭࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥࠩ啝")
		# l11ll1l1l_l1_ links
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ啞"),headers,l11lll_l1_ (u"ࠨࠩ啟"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠳ࡰࡧࠫ啠"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡊࡴࡸ࡭ࠡ࡯ࡨࡸ࡭ࡵࡤ࠾ࠤࡓࡓࡘ࡚ࠢࠡࡣࡦࡸ࡮ࡵ࡮࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ啡"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ啢"),[],[]
		l1lllllll1_l1_ = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		if l11lll_l1_ (u"ࠬ࠴ࡲࡢࡴࠪ啣") in block or l11lll_l1_ (u"࠭࠮ࡻ࡫ࡳࠫ啤") in block: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡎࡑࡖࡌࡆࡎࡄࡂࠢࡑࡳࡹࠦࡡࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠬ啥"),[],[]
		items = re.findall(l11lll_l1_ (u"ࠨࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ啦"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll1l1ll_l1_(payload)
		html = OPENURL_CACHED(l1lll1111_l1_,l1lllllll1_l1_,data,headers,l11lll_l1_ (u"ࠩࠪ啧"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨࠬ啨"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩ啩"),html,re.DOTALL)
		if not l1l1ll1_l1_: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ啪"),[],[]
		download = l1l1ll1_l1_[0][0]
		block = l1l1ll1_l1_[0][1]
		items = re.findall(l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭啫"),block,re.DOTALL)
		l11l11ll1lll_l1_,l1lll1ll_l1_,l11l1l1lll1l_l1_,l1111_l1_,l111l111ll1l_l1_ = [],[],[],[],[]
		for link,title in items:
			if l11lll_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭啬") in link:
				l11l11ll1lll_l1_,l11l1l1lll1l_l1_ = l11ll11l11_l1_(link)
				l1111_l1_ = l1111_l1_ + l11l1l1lll1l_l1_
				if l11l11ll1lll_l1_[0]==l11lll_l1_ (u"ࠨ࠯࠴ࠫ啭"): l1lll1ll_l1_.append(l11lll_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ啮")+l11lll_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ啯")+l1ll111lll1_l1_)
				else:
					for title in l11l11ll1lll_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ู๊ࠫࠥาใิࠤำอีࠡࠩ啰")+l11lll_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠫ啱")+l1ll111lll1_l1_+l11lll_l1_ (u"࠭ࠠࠨ啲")+title)
			else:
				title = title.replace(l11lll_l1_ (u"ࠧ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠩ啳"),l11lll_l1_ (u"ࠨࠩ啴"))
				title = title.strip(l11lll_l1_ (u"ࠩࠥࠫ啵"))
				#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ啶"),l11lll_l1_ (u"ࠫࠬ啷"),title,str(l111l111ll1l_l1_))
				title = l11lll_l1_ (u"ࠬࠦำ๋ำไีࠥࠦฮศืࠣࠫ啸")+l11lll_l1_ (u"࠭ࠠ࡮ࡲ࠷ࠤࠬ啹")+l1ll111lll1_l1_+l11lll_l1_ (u"ࠧࠡࠩ啺")+title
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		# download links
		link = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧࠪ啻") + download
		html = OPENURL_CACHED(l1lll1111_l1_,link,l11lll_l1_ (u"ࠩࠪ啼"),headers,l11lll_l1_ (u"ࠪࠫ啽"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠸ࡸ࡭࠭啾"))
		items = re.findall(l11lll_l1_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭ࠤ啿"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11lll_l1_ (u"࠭ࠠิ์ิๅึࠦสฮ็ํ่ࠥิวึࠢࠪ喀")+l11lll_l1_ (u"ࠧࠡ࡯ࡳ࠸ࠥ࠭喁")+l1ll111lll1_l1_+l11lll_l1_ (u"ࠨࠢࠪ喂")+resolution.split(l11lll_l1_ (u"ࠩࡻࠫ喃"))[1]
			link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡪ࡬ࡀࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠪ࡮ࡪ࠽ࠨ善")+id+l11lll_l1_ (u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ喅")+mode+l11lll_l1_ (u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ喆")+hash
			l111l111ll1l_l1_.append(resolution)
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		l111l111ll1l_l1_ = set(l111l111ll1l_l1_)
		l111l1l11l11_l1_,l11l11l1ll11_l1_ = [],[]
		for title in l1lll1ll_l1_:
			#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ喇"),l11lll_l1_ (u"ࠧࠨ喈"),title,l11lll_l1_ (u"ࠨࠩ喉"))
			res = re.findall(l11lll_l1_ (u"ࠤࠣࠬࡡࡪࠪࡹࡾ࡟ࡨ࠯࠯ࠦࠧࠤ喊"),title+l11lll_l1_ (u"ࠪࠪࠫ࠭喋"),re.DOTALL)
			for resolution in l111l111ll1l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11lll_l1_ (u"ࠫࡽ࠭喌"))[1])
			l111l1l11l11_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1111_l1_)):
			items = re.findall(l11lll_l1_ (u"ࠧࠬࠦࠩ࠰࠭ࡃ࠮࠮࡜ࡥࠬࠬࠪࠫࠨ喍"),l11lll_l1_ (u"࠭ࠦࠧࠩ喎")+l111l1l11l11_l1_[i]+l11lll_l1_ (u"ࠧࠧࠨࠪ喏"),re.DOTALL)
			l11l11l1ll11_l1_.append( [l111l1l11l11_l1_[i],l1111_l1_[i],items[0][0],items[0][1]] )
		l11l11l1ll11_l1_ = sorted(l11l11l1ll11_l1_, key=lambda x: x[3], reverse=True)
		l11l11l1ll11_l1_ = sorted(l11l11l1ll11_l1_, key=lambda x: x[2], reverse=False)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for i in range(len(l11l11l1ll11_l1_)):
			l1lll1ll_l1_.append(l11l11l1ll11_l1_[i][0])
			l1111_l1_.append(l11l11l1ll11_l1_[i][1])
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠬ喐"),[],[]
	return l11lll_l1_ (u"ࠩࠪ喑"),l1lll1ll_l1_,l1111_l1_
def l11l11ll1l11_l1_(url):
	# http://l11111l11l11_l1_.com/717254
	parts = url.split(l11lll_l1_ (u"ࠪࡃࠬ喒"))
	l11l11l_l1_ = parts[0]
	headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ喓") : l11lll_l1_ (u"ࠬ࠭喔") }
	html = OPENURL_CACHED(l1lll1111_l1_,l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ喕"),headers,l11lll_l1_ (u"ࠧࠨ喖"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࠻ࡔࡔࡃࡕ࠱࠶ࡹࡴࠨ喗"))
	items = re.findall(l11lll_l1_ (u"ࠩࡓࡰࡪࡧࡳࡦࠢࡺࡥ࡮ࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ喘"),html,re.DOTALL)
	url = items[0]
	#l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l1l11ll_l1_(url)
	#return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭喙"),[l11lll_l1_ (u"ࠫࠬ喚")],[url]
def l111ll1111l1_l1_(url):
	# https://l1lll111l1l_l1_.l1ll1lll111_l1_/l1lll11l111_l1_
	# https://l1ll1lll11l_l1_.cc/l1lll11l111_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ喛") : l11lll_l1_ (u"࠭ࠧ喜") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠧࠨ喝"),headers,l11lll_l1_ (u"ࠨࠩ喞"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ喟"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡤࡻࡲ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ喠"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"ࠫࠬ喡"),[l11lll_l1_ (u"ࠬ࠭喢")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍࠩ喣"),[],[]
def l11l11lll11l_l1_(url):
	# https://l1lll111l1l_l1_.l1ll1lll111_l1_/l1lll11l111_l1_
	# https://l1ll1lll11l_l1_.cc/l1lll11l111_l1_
	l1lll1ll_l1_,l1111_l1_ = [],[]
	headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ喤") : l11lll_l1_ (u"ࠨࠩ喥") }
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ喦"),headers,l11lll_l1_ (u"ࠪࠫ喧"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪ喨"))
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࠥ࠰ࠧ࠮ࡨࡵࡶ࠱࠮ࡄ࠯ࠢࠨ喩"),html,re.DOTALL)
	if l11l11l_l1_: return l11lll_l1_ (u"࠭ࠧ喪"),[l11lll_l1_ (u"ࠧࠨ喫")],[l11l11l_l1_[0]]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔࠩ喬"),[],[]
def l1l1llllll1_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ喭"),l11lll_l1_ (u"ࠪࠫ單"),l11lll_l1_ (u"ࠫࠬ喯"),url)
	# l11ll1l1l_l1_    https://show.l111l1ll11ll_l1_.com/l111l1l1l11l_l1_-l111l1l11l1l_l1_/l111l1l11l1l_l1_-l11l11111ll1_l1_.l1ll1lll1l_l1_?action=l111l111lll1_l1_&post=32513&l1l1lllllll_l1_=1&type=l1lll111ll1_l1_
	# download https://show.l111l1ll11ll_l1_.com/links/l1111l1l1111_l1_
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"ࠬ࠭喰")
	# l11ll1l1l_l1_
	if l11lll_l1_ (u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࠪ喱") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭喲"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ喳")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ喴"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ喵"),l11lll_l1_ (u"ࠫࠬ営"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨ喷"))
		l11lll1l_l1_ = response.content
		if l11lll1l_l1_.startswith(l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫ喸")): l11l11l_l1_ = l11lll1l_l1_
		else:
			l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨ喹"),l11lll1l_l1_,re.DOTALL)
			if l11l1l1_l1_:
				l11l11l_l1_ = l11l1l1_l1_[0]
				l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ喺"),l11l11l_l1_,re.DOTALL)
				if l11l1l1_l1_:
					l11l11l_l1_ = l111l_l1_(l11l1l1_l1_[0])
					return l11lll_l1_ (u"ࠩࠪ喻"),[l11lll_l1_ (u"ࠪࠫ喼")],[l11l11l_l1_]
	# download
	elif l11lll_l1_ (u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬ喽") in url:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ喾"),url,l11lll_l1_ (u"࠭ࠧ喿"),l11lll_l1_ (u"ࠧࠨ嗀"),True,l11lll_l1_ (u"ࠨࠩ嗁"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠳ࡶࡸࠬ嗂"))
		l11lll1l_l1_ = response.content
		if l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ嗃") in list(response.headers.keys()): l11l11l_l1_ = response.headers[l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭嗄")]
		else: l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗅"),l11lll1l_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ嗆"),l11lll_l1_ (u"ࠧࠨ嗇"),l11l11l_l1_,str(2222))
	if l11lll_l1_ (u"ࠨ࠱ࡹ࠳ࠬ嗈") in l11l11l_l1_ or l11lll_l1_ (u"ࠩ࠲ࡪ࠴࠭嗉") in l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠪ࠳࡫࠵ࠧ嗊"),l11lll_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ嗋"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠬ࠵ࡶ࠰ࠩ嗌"),l11lll_l1_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ嗍"))
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ嗎"),l11lll_l1_ (u"ࠨࠩ嗏"),l11l11l_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ嗐"),l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ嗑"),l11lll_l1_ (u"ࠫࠬ嗒"),l11lll_l1_ (u"ࠬ࠭嗓"),l11lll_l1_ (u"࠭ࠧ嗔"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠳ࡳࡦࠪ嗕"))
		l11lll1l_l1_ = response.content
		items = re.findall(l11lll_l1_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ嗖"),l11lll1l_l1_,re.DOTALL)
		if items:
			for link,title in items:
				link = link.replace(l11lll_l1_ (u"ࠩ࡟ࡠࠬ嗗"),l11lll_l1_ (u"ࠪࠫ嗘"))
				l1lll1ll_l1_.append(title)
				l1111_l1_.append(link)
		else:
			items = re.findall(l11lll_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嗙"),l11lll1l_l1_,re.DOTALL)
			if items:
				link = items[0]
				link = link.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ嗚"),l11lll_l1_ (u"࠭ࠧ嗛"))
				l1lll1ll_l1_.append(l11lll_l1_ (u"ࠧࠨ嗜"))
				l1111_l1_.append(link)
	else: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嗝"),[l11lll_l1_ (u"ࠩࠪ嗞")],[l11l11l_l1_]
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嗟"),l11lll_l1_ (u"ࠫࠬ嗠"),str(l11llll11_l1_),l11l11l_l1_)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ嗡"),[],[]
	return l11lll_l1_ (u"࠭ࠧ嗢"),l1lll1ll_l1_,l1111_l1_
def l1l1ll11l1l1_l1_(url):
	# l11ll1l1l_l1_ l1111lll_l1_  https://l111ll1l1lll_l1_.l11l1l1ll1ll_l1_.l1ll1lll111_l1_/l11ll111lll_l1_/l111111l11l1_l1_.l1ll1lll1l_l1_?s=07&id=l11ll111l1l1_l1_,&l1llll_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l111l1111ll1_l1_&l11l11l111l1_l1_=l11111ll1l11_l1_&l111l1llll11_l1_=l111111lll1l_l1_
	# l11ll1l1l_l1_ l1llll1l1_l1_ https://l11l1ll11111_l1_.l11l1l1ll1ll_l1_.l1ll1lll111_l1_/l11ll111lll_l1_/l1111l1111l1_l1_.l1ll1lll1l_l1_?l11l1l11111l_l1_=l111l1l1111l_l1_&l111lll1ll1l_l1_=8a26a6cc61a884e89076504130c71626&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l111l1111ll1_l1_&l11l11l111l1_l1_=l11111ll1l11_l1_&l1llll_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l111l1111ll1_l1_&l11l11l111l1_l1_=l11111ll1l11_l1_&l111l1llll11_l1_=l111l1l111l1_l1_
	# download https://www.l11l1l11lll1_l1_.l111l1l1l1l1_l1_/l11l11l1l11l_l1_?server=l1111l111111_l1_&id=l111llllllll_l1_,,
	# l1l11llll_l1_ https://l11l1l11lll1_l1_.l1lll1111l_l1_/l1l11llll_l1_/l11l111ll1ll_l1_
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ嗣"),url,l11lll_l1_ (u"ࠨࠩ嗤"),l11lll_l1_ (u"ࠩࠪ嗥"),l11lll_l1_ (u"ࠪࠫ嗦"),l11lll_l1_ (u"ࠫࠬ嗧"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬ嗨"))
	html = response.content
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"࠭ࠧ嗩")
	if l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ嗪") in url or l11lll_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ嗫") in url:
		if l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ嗬") in url:
			l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嗭"),html,re.DOTALL)
			l11l11l_l1_ = l11l11l_l1_[0]
		else: l11l11l_l1_ = url
		if l11lll_l1_ (u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ嗮") not in l11l11l_l1_: return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嗯"),[l11lll_l1_ (u"࠭ࠧ嗰")],[l11l11l_l1_]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ嗱"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ嗲"),l11lll_l1_ (u"ࠩࠪ嗳"),l11lll_l1_ (u"ࠪࠫ嗴"),l11lll_l1_ (u"ࠫࠬ嗵"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠴ࡱࡨࠬ嗶"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠬ࠳࠰࠿ࠪࡸ࡬ࡨࡪࡵࡪࡴࠩ嗷"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嗸"),block,re.DOTALL)
		if items:
			for link,l1ll11l1ll1l_l1_ in items:
				l1lll1ll_l1_.append(l1ll11l1ll1l_l1_)
				l1111_l1_.append(link)
	elif l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࠪ嗹") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡸࡶࡱࡃࠨ࠯ࠬࡂ࠭ࠧ࠭嗺"),html,re.DOTALL)
		l11l11l_l1_ = l11l11l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嗻"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ嗼"),l11lll_l1_ (u"ࠬ࠭嗽"),l11lll_l1_ (u"࠭ࠧ嗾"),l11lll_l1_ (u"ࠧࠨ嗿"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠸ࡸࡤࠨ嘀"))
		html = response.content
		l11l1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ嘁"),html,re.DOTALL)
		l11l1l1_l1_ = l11l1l1_l1_[0]
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪࠫ嘂"))
		l1111_l1_.append(l11l1l1_l1_)
	elif l11lll_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡬ࡪࡰ࡮ࠫ嘃") in url:
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡣࡦࡰࡷࡩࡷࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嘄"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ嘅"),[l11lll_l1_ (u"ࠧࠨ嘆")],[l11l11l_l1_]
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡑࡔ࡜ࡓ࠵ࡗࠪ嘇"),[],[]
	return l11lll_l1_ (u"ࠩࠪ嘈"),l1lll1ll_l1_,l1111_l1_
def l1lll1l11l_l1_(url):
	l1l1ll11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ嘉")][0]
	headers = {l11lll_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ嘊"):l1l1ll11_l1_}
	if l11lll_l1_ (u"ࠬࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࠩ嘋") in url:
		l1l1ll1ll_l1_ = headers.copy()
		l1l1ll1ll_l1_[l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ嘌")] = l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ嘍")
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ嘎"),url,l11lll_l1_ (u"ࠩࠪ嘏"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠪࠫ嘐"),l11lll_l1_ (u"ࠫࠬ嘑"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡄ࠰࠵ࡸࡺࠧ嘒"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠦࠪ嘓"),html,re.DOTALL)
		if link: url = link[0]
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ嘔"),url,l11lll_l1_ (u"ࠨࠩ嘕"),headers,l11lll_l1_ (u"ࠩࠪ嘖"),l11lll_l1_ (u"ࠪࠫ嘗"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡃ࠯࠵ࡲࡩ࠭嘘"))
	html = response.content
	server = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ嘙"))
	link = re.findall(l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ嘚"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠢࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠬ࠮࠮ࠫࡁࠬࠫࠧ嘛"),html,re.DOTALL)
	if link:
		url = link[0]+l11lll_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ嘜")+l1l1ll11_l1_
		return l11lll_l1_ (u"ࠩࠪ嘝"),[l11lll_l1_ (u"ࠪࠫ嘞")],[url]
	link = re.findall(l11lll_l1_ (u"ࠦ࡫࡯࡬ࡦ࠼ࠪࠬ࠳࠰࠿ࠪࠩࠥ嘟"),html,re.DOTALL)
	if link: url = server+link[0]
	return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ嘠"),[l11lll_l1_ (u"࠭ࠧ嘡")],[url]
	#return l11lll_l1_ (u"ࠧࠨ嘢"),l1lllll11l1_l1_,l1lllll1_l1_
	#return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ嘣"),[],[]
	#return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ嘤"),[l11lll_l1_ (u"ࠪࠫ嘥")],[url]
	#return l11lll_l1_ (u"ࠫࠬ嘦"),[l11lll_l1_ (u"ࠬ࠭嘧")],[url]
def l1lllll111l_l1_(url):
	l1lllll11l1_l1_,l1lllll1_l1_ = [],[]
	if l11lll_l1_ (u"࠭࠯࠲࠱ࠪ嘨") in url:
		link = url.replace(l11lll_l1_ (u"ࠧ࠰࠳࠲ࠫ嘩"),l11lll_l1_ (u"ࠨ࠱࠷࠳ࠬ嘪"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭嘫"),link,l11lll_l1_ (u"ࠪࠫ嘬"),l11lll_l1_ (u"ࠫࠬ嘭"),False,l11lll_l1_ (u"ࠬ࠭嘮"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠶ࡹࡴࠨ嘯"))
		l11lll1l_l1_ = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡦࡨࡳࡃ࠭嘰"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嘱"),block,re.DOTALL)
			for link,l11l111l_l1_ in items:
				if link not in l1lllll1_l1_:
					l1lllll1_l1_.append(link)
					server = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ嘲"))
					l1lllll11l1_l1_.append(server+l11lll_l1_ (u"ࠪࠤࠥ࠭嘳")+l11l111l_l1_)
			return l11lll_l1_ (u"ࠫࠬ嘴"),l1lllll11l1_l1_,l1lllll1_l1_
	elif l11lll_l1_ (u"ࠬ࠵ࡤ࠰ࠩ嘵") in url:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ嘶"),url,l11lll_l1_ (u"ࠧࠨ嘷"),l11lll_l1_ (u"ࠨࠩ嘸"),l11lll_l1_ (u"ࠩࠪ嘹"),l11lll_l1_ (u"ࠪࠫ嘺"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠵ࡲࡩ࠭嘻"))
		l11lll1l_l1_ = response.content
		link = re.findall(l11lll_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭嘼"),l11lll1l_l1_,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"࠭࠯࠲࠱ࠪ嘽"),l11lll_l1_ (u"ࠧ࠰࠶࠲ࠫ嘾"))
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ嘿"),link,l11lll_l1_ (u"ࠩࠪ噀"),l11lll_l1_ (u"ࠪࠫ噁"),False,l11lll_l1_ (u"ࠫࠬ噂"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠷ࡷࡪࠧ噃"))
			l11lll1l_l1_ = response.content
			link = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噄"),l11lll1l_l1_,re.DOTALL)
			if link: return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ噅"),[l11lll_l1_ (u"ࠨࠩ噆")],[link[0]]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭噇"),[],[]
def l1lll1l111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ噈"),l11lll_l1_ (u"ࠫࠬ噉"),l11lll_l1_ (u"ࠬ࠭噊"),url)
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ噋"),url,l11lll_l1_ (u"ࠧࠨ噌"),l11lll_l1_ (u"ࠨࠩ噍"),l11lll_l1_ (u"ࠩࠪ噎"),l11lll_l1_ (u"ࠪࠫ噏"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠴࠯࠴ࡷࡹ࠭噐"))
	html = response.content
	data = re.findall(l11lll_l1_ (u"ࠬࠨࡡࡤࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭噑"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l11lll_l1_ (u"࠭࡯ࡱ࠿ࠪ噒")+op+l11lll_l1_ (u"ࠧࠧ࡫ࡧࡁࠬ噓")+id+l11lll_l1_ (u"ࠨࠨࡩࡲࡦࡳࡥ࠾ࠩ噔")+fname
		headers = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ噕"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ噖")}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ噗"),url,data,headers,l11lll_l1_ (u"ࠬ࠭噘"),l11lll_l1_ (u"࠭ࠧ噙"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠸࡮ࡥࠩ噚"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠨࠤࡵࡩ࡫࡫ࡲࡦࡴࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ噛"),html,re.DOTALL)
		if link: return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ噜"),[l11lll_l1_ (u"ࠪࠫ噝")],[link[0]]
	return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ噞"),[],[]
def l11111l1l1_l1_(url):
	# https://l1lllll1l11_l1_.l1lllll1111_l1_/l11lll11111_l1_?call=l11l111llll1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l1ll1l11l_l1_=l111ll1llll1_l1_
	# https://l1lllll1l11_l1_.l1lllll1111_l1_/l11lll11111_l1_?call=l11l111llll1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l11l1ll1l11l_l1_=l111l1l1l111_l1_
	l11l11l_l1_ = url.split(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭噟"),1)[0].strip(l11lll_l1_ (u"࠭࠿ࠨ噠")).strip(l11lll_l1_ (u"ࠧ࠰ࠩ噡")).strip(l11lll_l1_ (u"ࠨࠨࠪ噢"))
	l1lll1ll_l1_,l1111_l1_,items,l11l1l1_l1_ = [],[],[],l11lll_l1_ (u"ࠩࠪ噣")
	headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ噤"):l11lll_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠫ噥") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ噦"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ噧"),headers,True,l11lll_l1_ (u"ࠧࠨ器"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠷ࡳࡵࠩ噩"))
	if l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ噪") in list(response.headers.keys()): l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ噫")]
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ噬"),l11l1l1_l1_,l11lll_l1_ (u"ࠬ࠭噭"),headers,False,l11lll_l1_ (u"࠭ࠧ噮"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠷ࡴࡤࠨ噯"))
	#if l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ噰") in response.headers: l11l1l1_l1_ = response.headers[l11lll_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ噱")]
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ噲"),l11lll_l1_ (u"ࠫࠬ噳"),l11l1l1_l1_,response.content)
	if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ噴") in l11l1l1_l1_:
		# https://l1111l1111_l1_.top/f/l11l1111l1ll_l1_/?l111l1llll_l1_=l11ll11l1ll1_l1_
		# https://l1111l1111_l1_.top/v/l11l1111l1ll_l1_/?l111l1llll_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ噵") in url: l11l1l1_l1_ = l11l1l1_l1_.replace(l11lll_l1_ (u"ࠧ࠰ࡨ࠲ࠫ噶"),l11lll_l1_ (u"ࠨ࠱ࡹ࠳ࠬ噷"))
		l11l1ll1lll1_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠩࡂࡔࡍࡖࡓࡊࡆࡀࠫ噸"))[1]
		headers = { l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ噹"):headers[l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ噺")] , l11lll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ噻"):l11lll_l1_ (u"࠭ࡐࡉࡒࡖࡍࡉࡃࠧ噼")+l11l1ll1lll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ噽"),l11l1l1_l1_,l11lll_l1_ (u"ࠨࠩ噾"),headers,False,l11lll_l1_ (u"ࠩࠪ噿"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭嚀"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1lll1111_l1_,l11l1l1_l1_,l11lll_l1_ (u"ࠫࠬ嚁"),headers,l11lll_l1_ (u"ࠬ࠭嚂"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠰࠷ࡷࡪࠧ嚃"))
		if l11lll_l1_ (u"ࠧ࠰ࡨ࠲ࠫ嚄") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"ࠨ࠾࡫࠶ࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚅"),html,re.DOTALL)
		elif l11lll_l1_ (u"ࠩ࠲ࡺ࠴࠭嚆") in l11l1l1_l1_: items = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚇"),html,re.DOTALL)
		if items: return [],[l11lll_l1_ (u"ࠫࠬ嚈")],[ items[0] ]
		elif l11lll_l1_ (u"ࠬࡂࡨ࠲ࡀ࠷࠴࠹ࡂ࠯ࡩ࠳ࡁࠫ嚉") in html:
			return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦำ๋ำไีࠥอไโ์า๎ํࠦแ๋้ࠣััฮࠠืัࠣ็ํีู๊๊่ࠡิื็ࠡ็้ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูฮࠦศไࠩ嚊"),[],[]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡋ࡞ࡈࡅࡔࡖࠪ嚋"),[],[]
	#xbmc.log(html)
def l1111111lll_l1_(link):
	# https://l11ll11ll11l_l1_.net/?l11llll1_l1_=147043&l1l11111_l1_=5
	parts = re.findall(l11lll_l1_ (u"ࠨࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ嚌"),link+l11lll_l1_ (u"ࠩࠩࠪࠬ嚍"),re.DOTALL|re.IGNORECASE)
	l11llll1_l1_,l1l11111_l1_ = parts[0]
	url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪ࠱ࡲࡪࡺ࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫ嚎")+l11llll1_l1_+l11lll_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ嚏")+l1l11111_l1_
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ嚐"):l11lll_l1_ (u"࠭ࠧ嚑") , l11lll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ嚒"):l11lll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ嚓") }
	l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ嚔"),headers,l11lll_l1_ (u"ࠪࠫ嚕"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪ嚖"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭嚗"),l11lll_l1_ (u"࠭ࠧ嚘"),url,l11l11l_l1_)
	#l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l1l11ll_l1_(l11l11l_l1_)
	#return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
	return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ嚙"),[l11lll_l1_ (u"ࠨࠩ嚚")],[l11l11l_l1_]
def l1ll111l1111_l1_(url):
	# https://l11111l1111l_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l11l1111l1l1_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l11ll11l1_l1_=1608181746
	server = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭嚛"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ嚜"):server,l11lll_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭嚝"):l11lll_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ嚞")}
	response = OPENURL_REQUESTS_CACHED(l1ll1111l111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ嚟"),url,l11lll_l1_ (u"ࠧࠨ嚠"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ嚡"),l11lll_l1_ (u"ࠩࠪ嚢"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ嚣"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ嚤"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠬ࠭嚥")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ嚦"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ嚧"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"ࠨࠩ嚨"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ嚩"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡄࡋࡐࡅࠬ嚪"),[],[]
	return l11lll_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ嚫"),[l11lll_l1_ (u"ࠬ࠭嚬")],[l11l11l_l1_]
def l1l1l11lllll_l1_(url):
	# https://l11ll11ll1l1_l1_.l1111l1l1l1l_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l11l1111l1l1_l1_=0GfHI4TukZPPkW7vi8eP8Q&l11l11ll11l1_l1_=1608181746
	# https://l11ll11ll1l1_l1_.l1lllll1111_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l11l1111l1l1_l1_=l11ll111111l_l1_&l11l11ll11l1_l1_=1684182121
	server = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ嚭"))
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ嚮"):server,l11lll_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ嚯"):l11lll_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ嚰")}
	response = OPENURL_REQUESTS_CACHED(l1ll1111l111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ嚱"),url,l11lll_l1_ (u"ࠫࠬ嚲"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭嚳"),l11lll_l1_ (u"࠭ࠧ嚴"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ嚵"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ嚶"),html,re.DOTALL)
	l11l11l_l1_ = l11lll_l1_ (u"ࠩࠪ嚷")
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ嚸"),block,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for title,link in items:
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		if len(l1111_l1_)==1: l11l11l_l1_ = l1111_l1_[0]
		elif len(l1111_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ嚹"), l1lll1ll_l1_)
			if l1l_l1_==-1: return l11lll_l1_ (u"ࠬ࠭嚺"),[],[]
			l11l11l_l1_ = l1111_l1_[l1l_l1_]
	if not l11l11l_l1_:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嚻"),html,re.DOTALL)
		if l1l1ll1_l1_: l11l11l_l1_ = l1l1ll1_l1_[0]
	if not l11l11l_l1_: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩ嚼"),[],[]
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ嚽"),[l11lll_l1_ (u"ࠩࠪ嚾")],[l11l11l_l1_]
def l1l1l111_l1_(link):
	# https://w.l111l11ll11l_l1_.l1llll111l1_l1_/l111l1l1l11l_l1_-content/l11ll111l11l_l1_/l111l11l1l11_l1_/l11l1l1l11l1_l1_/l111l11l11ll_l1_/l111ll1l1ll1_l1_/l111l1l1ll11_l1_.l1ll1lll1l_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ嚿"),l11lll_l1_ (u"ࠫࠬ囀"),link,html)
	parts = re.findall(l11lll_l1_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ囁"),link+l11lll_l1_ (u"࠭ࠦࠧࠩ囂"),re.DOTALL)
	url,l11llll1_l1_,l1l11111_l1_ = parts[0]
	data = {l11lll_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤࠨ囃"):l11llll1_l1_,l11lll_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ囄"):l1l11111_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ囅"),url,data,l11lll_l1_ (u"ࠪࠫ囆"),l11lll_l1_ (u"ࠫࠬ囇"),l11lll_l1_ (u"ࠬ࠭囈"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍࡄࡃࡐ࠱࠶ࡹࡴࠨ囉"))
	html = response.content
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ囊"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ囋"),[l11lll_l1_ (u"ࠩࠪ囌")],[l11l11l_l1_]
def l1ll1l1lll_l1_(url):
	# https://l11l11l1lll1_l1_.l1lll11111_l1_-l11l11lll1l1_l1_.com/l1l11llll_l1_.l1ll1lll1l_l1_?l1l11l1ll11_l1_=l111l1lllll1_l1_
	# https://l.l111l1l1ll1l_l1_.l111l1l1l1l1_l1_/l1l11llll_l1_.l1ll1lll1l_l1_?l1l11l1ll11_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ囍"),url,l11lll_l1_ (u"ࠫࠬ囎"),l11lll_l1_ (u"ࠬ࠭囏"),l11lll_l1_ (u"࠭ࠧ囐"),l11lll_l1_ (u"ࠧࠨ囑"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭࠲ࡵࡷࠫ囒"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ囓"),html,re.DOTALL)
	if link:
		link = link[0]
		if link: return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭囔"),[l11lll_l1_ (u"ࠫࠬ囕")],[link]
	return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ囖"),[],[]
def l1lll111ll_l1_(url):
	# https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/l111l1l1l11l_l1_-content/l11ll111l11l_l1_/old/l1llll1_l1_/server.l1ll1lll1l_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ囗"),url,l11lll_l1_ (u"ࠧࠨ囘"),l11lll_l1_ (u"ࠨࠩ囙"),l11lll_l1_ (u"ࠩࠪ囚"),l11lll_l1_ (u"ࠪࠫ四"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡑ࠯࠴ࡷࡹ࠭囜"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"ࠬࡂࡉࡇࡔࡄࡑࡊࠦࡓࡓࡅࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ囝"),html,re.DOTALL)[0]
	return l11lll_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ回"),[l11lll_l1_ (u"ࠧࠨ囟")],[link]
def l1ll1l1l1l_l1_(url):
	# https://l11lllll1l1_l1_.l1l11l1111l1_l1_.cc/l111l1l1l11l_l1_-content/l11ll111l11l_l1_/l1111ll1l11l_l1_%20Now%20New/l1111l11lll1_l1_.l1ll1lll1l_l1_?action=l11l11ll1l1l_l1_&index=00&id=58504
	# https://l11l1111l11l_l1_.l1l11l1111l1_l1_.net/l1111l11llll_l1_/2021/04/05/_111ll111111_l1_-l11ll11l1l11_l1_.l111111l1l11_l1_ 200.l1111l111ll1_l1_.2020.l1111l1ll11l_l1_/[l1111ll1l11l_l1_-l11ll11l1l11_l1_.l1111llll111_l1_] 200.l1111l111ll1_l1_.2020.l1111l1ll11l_l1_-360p.l1111lll_l1_
	l1llllll1l_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ因"))
	if l11lll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ囡") in url:
		headers = {l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ团"):l1llllll1l_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ団"),url,l11lll_l1_ (u"ࠬ࠭囤"),headers,l11lll_l1_ (u"࠭ࠧ囥"),l11lll_l1_ (u"ࠧࠨ囦"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ囧"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ囨"),html,re.DOTALL)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			if l11lll_l1_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ囩") in l11l11l_l1_:
				l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭囪"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭囫"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ囬"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ园"),headers,l11lll_l1_ (u"ࠨࠩ囮"),l11lll_l1_ (u"ࠩࠪ囯"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ困"))
				l11lll1l_l1_ = response.content
				items = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ囱"),l11lll1l_l1_,re.DOTALL)
				l1lll1ll_l1_,l1111_l1_ = [],[]
				l1llllll11_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ囲"))
				for link,l11l111l_l1_ in reversed(items):
					link = l1llllll11_l1_+link+l11lll_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ図")+l1llllll11_l1_
					l1lll1ll_l1_.append(l11l111l_l1_)
					l1111_l1_.append(link)
				return l11lll_l1_ (u"ࠧࠨ围"),l1lll1ll_l1_,l1111_l1_
			else: return l11lll_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ囵"),[l11lll_l1_ (u"ࠩࠪ囶")],[l11l11l_l1_]
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭囷")+l1llllll1l_l1_
	return l11lll_l1_ (u"ࠫࠬ囸"),[l11lll_l1_ (u"ࠬ࠭囹")],[l11l11l_l1_]
def l111lll1l11l_l1_(link):
	# https://l1l11l1111l1_l1_.l1llll111l1_l1_/l111l1l1l11l_l1_-content/l11ll111l11l_l1_/l11l11ll11ll_l1_/l1111l1l111l_l1_/server.l1ll1lll1l_l1_?l11llll1_l1_=42869&l1l11111_l1_=4
	# https://l11l1ll111l1_l1_.l1l11l1111l1_l1_.net/l1111l11llll_l1_/2020/08/14/_111ll111111_l1_-l11ll11l1l11_l1_.l111111l1l11_l1_ l1111ll11ll1_l1_.l111lll1111l_l1_.2020.l111ll11l11l_l1_-l111lll11ll1_l1_/[l1111ll1l11l_l1_-l11ll11l1l11_l1_.l1111llll111_l1_] l1111ll11ll1_l1_.l111lll1111l_l1_.2020.l111ll11l11l_l1_-l111lll11ll1_l1_-1080p.l1111lll_l1_
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ固"),l11lll_l1_ (u"ࠧࠨ囻"),url,html)
	l1llllll1l_l1_ = SERVER(link,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ囼"))
	if l11lll_l1_ (u"ࠩࡳࡳࡸࡺࡩࡥࠩ国") in link:
		parts = re.findall(l11lll_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ图"),link+l11lll_l1_ (u"ࠫࠫࠬࠧ囿"),re.DOTALL)
		url,l11llll1_l1_,l1l11111_l1_ = parts[0]
		data = {l11lll_l1_ (u"ࠬ࡯ࡤࠨ圀"):l11llll1_l1_,l11lll_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭圁"):l1l11111_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ圂"),url,data,l11lll_l1_ (u"ࠨࠩ圃"),l11lll_l1_ (u"ࠩࠪ圄"),l11lll_l1_ (u"ࠪࠫ圅"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ圆"))
		html = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ圇"),html,re.DOTALL)[0]
		if l11lll_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ圈") in l11l11l_l1_:
			headers = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ圉"):l1llllll1l_l1_,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ圊"):l11lll_l1_ (u"ࠩࠪ國")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ圌"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ圍"),headers,l11lll_l1_ (u"ࠬ࠭圎"),l11lll_l1_ (u"࠭ࠧ圏"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠷ࡴࡤࠨ圐"))
			l11lll1l_l1_ = response.content
			items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ圑"),l11lll1l_l1_,re.DOTALL)
			l1lll1ll_l1_,l1111_l1_ = [],[]
			l1llllll11_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭園"))
			for link,l11l111l_l1_ in reversed(items):
				link = l1llllll11_l1_+link+l11lll_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭圓")+l1llllll11_l1_
				l1lll1ll_l1_.append(l11l111l_l1_)
				l1111_l1_.append(link)
			return l11lll_l1_ (u"ࠫࠬ圔"),l1lll1ll_l1_,l1111_l1_
		else: return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ圕"),[l11lll_l1_ (u"࠭ࠧ圖")],[l11l11l_l1_]
	else:
		link = link+l11lll_l1_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ圗")+l1llllll1l_l1_
		return l11lll_l1_ (u"ࠨࠩ團"),[l11lll_l1_ (u"ࠩࠪ圙")],[link]
def l11l11l1l_l1_(link):
	# http://l11l1lllll1l_l1_.tv/?l11llll1_l1_=159485&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࠪ圚") in link:
		parts = re.findall(l11lll_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭圛"),link+l11lll_l1_ (u"ࠬࠬࠦࠨ圜"),re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		host = SERVER(link,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ圝"))
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ圞"),l11lll_l1_ (u"ࠨࠩ土"),link,host)
		url = host+l11lll_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ圠")+l11llll1_l1_+l11lll_l1_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ圡")+l1l11111_l1_
		headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ圢"):l11lll_l1_ (u"ࠬ࠭圣") , l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ圤"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ圥") }
		l11l11l_l1_ = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ圦"),headers,l11lll_l1_ (u"ࠩࠪ圧"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠳ࡶࡸࠬ在"))
		l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠫࡡࡴࠧ圩"),l11lll_l1_ (u"ࠬ࠭圪")).replace(l11lll_l1_ (u"࠭࡜ࡳࠩ圫"),l11lll_l1_ (u"ࠧࠨ圬"))
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ圭"),l11lll_l1_ (u"ࠩࠪ圮"),url,l11l11l_l1_)
		#l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l1111l1l11ll_l1_(l11l11l_l1_)
		#return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
		return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭圯"),[l11lll_l1_ (u"ࠫࠬ地")],[l11l11l_l1_]
	elif l11lll_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ圱") in link:
		counts = 0
		while l11lll_l1_ (u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪ圲") in link and counts<5:
			response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ圳"),link,l11lll_l1_ (u"ࠨࠩ圴"),l11lll_l1_ (u"ࠩࠪ圵"),l11lll_l1_ (u"ࠪࠫ圶"),l11lll_l1_ (u"ࠫࠬ圷"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠶ࡳࡪࠧ圸"))
			if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ圹") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ场")]
			counts += 1
		return l11lll_l1_ (u"ࠨࠩ圻"),[l11lll_l1_ (u"ࠩࠪ圼")],[link]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡃࡎࡌࡓࡓࡠࠧ圽"),[],[]
def l11ll1111_l1_(url):
	# https://l111l1ll1l1l_l1_.l1111lll1l11_l1_.me/l/l11ll1111l11_l1_=
	# https://l11l11l11111_l1_.l1111l1ll1ll_l1_.net/l1l11llll_l1_-l1l11llll_l1_-l1111ll111l1_l1_.html
	# https://m.l1111l1ll1ll_l1_.net/l1111ll111l1_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ圾"),l11lll_l1_ (u"ࠬ࠭圿"),l11lll_l1_ (u"࠭ࠧ址"),url)
	server = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ坁"))
	if l11lll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡳࡣࡷࡩࠬ坂") in url and l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ坃") not in url: url = server+l11lll_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ坄")+url.split(l11lll_l1_ (u"ࠫ࠴࠭坅"))[-1]+l11lll_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ坆")
	headers = {l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ均"):server,l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ坈"):l1l11l11l_l1_()}
	if l11lll_l1_ (u"ࠨ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭坉") in url:
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ坊"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ坋")}
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ坌"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,True,l11lll_l1_ (u"ࠬ࠭坍"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠶ࡹࡴࠨ坎"))
		html = response.content
		link = re.findall(l11lll_l1_ (u"ࠧࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ坏"),html,re.DOTALL|re.IGNORECASE)
		if link: return l11lll_l1_ (u"ࠨࠩ坐"),[l11lll_l1_ (u"ࠩࠪ坑")],[link[0]]
	elif l11lll_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ坒") in url:
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ坓"),headers,l11lll_l1_ (u"ࠬ࠭坔"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨ坕"))
		link = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭坖"),html,re.DOTALL)
		if link:
			link = link[0].replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ块"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ坘"))
			return l11lll_l1_ (u"ࠪࠫ坙"),[l11lll_l1_ (u"ࠫࠬ坚")],[link]
	else:
		l111l1lll111_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ坛"),url,l11lll_l1_ (u"࠭ࠧ坜"),headers,l11lll_l1_ (u"ࠧࠨ坝"),l11lll_l1_ (u"ࠨࠩ坞"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫ坟"))
		html = l111l1lll111_l1_.content
		link = re.findall(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭坠"),html,re.DOTALL)
		if link:
			link = l111l_l1_(link[0])+l11lll_l1_ (u"ࠫࠫࡪ࠽࠲ࠩ坡")
			l1ll111ll_l1_ = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ坢"),link,l11lll_l1_ (u"࠭ࠧ坣"),headers,l11lll_l1_ (u"ࠧࠨ坤"),l11lll_l1_ (u"ࠨࠩ坥"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫ坦"))
			html = l1ll111ll_l1_.content
			link = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭坧"),html,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠫࠬ坨"),[l11lll_l1_ (u"ࠬ࠭坩")],[link]
		if l11lll_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ坪") in list(l111l1lll111_l1_.headers.keys()):
			cookies = l111l1lll111_l1_.headers[l11lll_l1_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫ坫")]
			link = re.findall(l11lll_l1_ (u"ࠨࡡ࡯ࡲࡰࡥ࠮ࠫࡁࡀࠬ࠳࠰࠿ࠪ࠽ࠪ坬"),cookies,re.DOTALL)
			if link:
				link = l111l_l1_(link[0])
				return l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ坭"),[l11lll_l1_ (u"ࠪࠫ坮")],[link]
	return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ坯"),[],[]
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࠥࡴ࡯ࡵࠢࡺࡳࡷࡱࡩ࡯ࡩࠍࠍࠎࠩࠠࡪࡶࠣࡲࡪ࡫ࡤࡴࠢࡦࡳࡴࡱࡩࡦࠢࡩࡶࡴࡳࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠎࠎࠏࠣࠡࡅࡲࡳࡰ࡯ࡥ࠻ࠢࡦࡪࡤࡩ࡬ࡦࡣࡵࡥࡳࡩࡥ࠾ࡅࡐࡩ࠳ࡎࡋࡈࡓ࡮ࡱࡼࡴࡓࡗࡷࡱࡾ࡛ࡏࡰࡲࡱࡺࡵࡘࡇ࡚ࡤࡲࡱࡊ࠼ࡰࡂࡑࡗࡒࡕࡧ࡟ࡂࡇ࠲࠰࠵࠻࠼࠳࠲࠳࠵࠴࠵࠼࠭࠱࠯࠵࠹࠵ࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࠫࡹࡷࡲࠬࠨࡷࡵࡰࠬ࠯ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠿ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠩࠫ࠯ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࡳࡦࡴࡹࡩࡷࢃࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨࠫࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࡿࡶࡪ࠴ࡉࡈࡐࡒࡖࡊࡉࡁࡔࡇࠬࠎࠎࠏࡩࡧࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡦ࡯ࡥࡩࡩ࠳ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࠩ࠯࡟ࠬ࠭࡝࠭࡝࡯࡭ࡳࡱ࡝ࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪ࠮࡫ࡸࡲࡲࠩࠋࠋࠌࠧࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠉࠤ࡫ࡩࠤࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠦࠍࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠥࠌࡶࡪࡺࡵࡳࡰࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࠎࠩࡥ࡭ࡵࡨ࠾ࠥࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࠌࠌࠦࠧࠨ坰")
	#if l11lll_l1_ (u"࠭࠮࡮ࡲ࠷࠲࡭ࡺ࡭࡭ࠩ坱") in url:
	#	l1ll11ll1ll1_l1_ = url.split(l11lll_l1_ (u"ࠧ࠰ࠩ坲"))
	#	url = l11lll_l1_ (u"ࠨ࠱ࠪ坳").join(l1ll11ll1ll1_l1_[:4])
	#	tmp = re.findall(l11lll_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠳࠴࠴ࠪࡀ࠱ࠬࠬ࠳࠰࠿ࠪࠦࠪ坴"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11lll_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ坵")+tmp[0][1]+l11lll_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ坶")
	#	#return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ坷"),[l11lll_l1_ (u"࠭ࠧ坸")],[url]
	#	#l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11111lll1l1_l1_(url)
	#	#return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
	# l1l11llll_l1_ link
	#return l11lll_l1_ (u"ࠧࠨ坹"),[l11lll_l1_ (u"ࠨࠩ坺")],[link]
def l1l1l11ll111_l1_(link):
	# https://l111ll1l1111_l1_.l111lll1l111_l1_/l1111111llll_l1_?_1111lllll11_l1_=l11111l1l1ll_l1_&_111l11l111l_l1_=86046&l1l11111_l1_=0
	if l11lll_l1_ (u"ࠩࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷ࠭坻") in link:
		headers = {l11lll_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭坼"):l11lll_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ坽")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ坾"),link,l11lll_l1_ (u"࠭ࠧ坿"),headers,l11lll_l1_ (u"ࠧࠨ垀"),l11lll_l1_ (u"ࠨࠩ垁"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ垂"))
		url = response.content
		if url: return l11lll_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭垃"),[l11lll_l1_ (u"ࠫࠬ垄")],[url]
	else:
		# https://l1111l1lll11_l1_.net/?l11llll1_l1_=142302&l1l11111_l1_=4
		parts = re.findall(l11lll_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭垅"),link,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11lll_l1_ (u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ垆"),link,re.DOTALL|re.IGNORECASE)
		l11llll1_l1_,l1l11111_l1_ = parts[0]
		server = SERVER(link,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ垇"))
		#url = server+l11lll_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ垈")
		url = server+l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ垉")
		#url = server+l11lll_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ垊")+l11llll1_l1_+l11lll_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ型")+l1l11111_l1_
		#data = {l11lll_l1_ (u"ࠬ࡯ࡤࠨ垌"):l11llll1_l1_,l11lll_l1_ (u"࠭ࡩࠨ垍"):l1l11111_l1_,l11lll_l1_ (u"ࠧ࡮ࡧࡷࡥࠬ垎"):l11lll_l1_ (u"ࠨࡱ࡯ࡨࡤࡹࡥࡳࡸࡨࡶࡸ࠭垏"),l11lll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ垐"):l11lll_l1_ (u"ࠪࡳࡱࡪࠧ垑")}
		data = {l11lll_l1_ (u"ࠫ࡮ࡪࠧ垒"):l11llll1_l1_,l11lll_l1_ (u"ࠬ࡯ࠧ垓"):l1l11111_l1_}
		headers = {l11lll_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ垔"):l11lll_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ垕"),l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ垖"):link}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ垗"),url,data,headers,l11lll_l1_ (u"ࠪࠫ垘"),l11lll_l1_ (u"ࠫࠬ垙"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠶ࡳࡪࠧ垚"))
		l11lll1l_l1_ = response.content
		l11l11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ垛"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l11l11l_l1_:
			l11l11l_l1_ = l11l11l_l1_[0]
			return l11lll_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ垜"),[l11lll_l1_ (u"ࠨࠩ垝")],[l11l11l_l1_]
	return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭垞"),[],[]
def l111llll1ll1_l1_(l1111l111l11_l1_):
	l11ll11l1_l1_ = READ_FROM_SQL3(main_dbfile,l11lll_l1_ (u"ࠪࡷࡹࡸࠧ垟"),l11lll_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ垠"),l11lll_l1_ (u"ࠬࡇࡋࡘࡃࡐࡣ࡛ࡋࡒࡊࡈࡌࡇࡆ࡚ࡉࡐࡐࠪ垡"))
	headers = {l11lll_l1_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭垢"):l11ll11l1_l1_} if l11ll11l1_l1_ else l11lll_l1_ (u"ࠧࠨ垣")
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ垤"),l1111l111l11_l1_,l11lll_l1_ (u"ࠩࠪ垥"),headers,l11lll_l1_ (u"ࠪࠫ垦"),l11lll_l1_ (u"ࠫࠬ垧"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠳ࡶࡸࠬ垨"))
	l1111l11l11l_l1_ = response.content
	l1111ll11l11_l1_ = str(response.headers)
	l1111llll1l1_l1_ = l1111ll11l11_l1_+l1111l11l11l_l1_
	if l11lll_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ垩") in l1111llll1l1_l1_: l1ll1ll1l_l1_ = True
	else:
		l11111l1lll1_l1_,token,l11l11lll111_l1_,l111l111ll11_l1_,l1ll1ll1l_l1_ = l11lll_l1_ (u"ࠧࠨ垪"),l11lll_l1_ (u"ࠨࠩ垫"),l11lll_l1_ (u"ࠩࠪ垬"),l11lll_l1_ (u"ࠪࠫ垭"),False
		l11l1l11ll11_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ垮"),l1111l11l11l_l1_,re.DOTALL)
		if l11l1l11ll11_l1_: l11l11lll111_l1_,l111l111ll11_l1_ = l11l1l11ll11_l1_[0]
		l111ll11l111_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ垯")][7]
		user = l11llll1l1l_l1_(32)
		if 0:
			data = {l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ垰"):user,l11lll_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ垱"):l11ll111l11_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ垲"):l1111l111l11_l1_,l11lll_l1_ (u"ࠩ࡮ࡩࡾ࠭垳"):l111l111ll11_l1_,l11lll_l1_ (u"ࠪ࡭ࡩ࠭垴"):l11lll_l1_ (u"ࠫࠬ垵"),l11lll_l1_ (u"ࠬࡰ࡯ࡣࠩ垶"):l11lll_l1_ (u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧ垷")}
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ垸"),l111ll11l111_l1_,data,l11lll_l1_ (u"ࠨࠩ垹"),l11lll_l1_ (u"ࠩࠪ垺"),l11lll_l1_ (u"ࠪࠫ垻"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠳ࡰࡧࠫ垼"))
			html = response.content
		html = l11lll_l1_ (u"ࠬ࠭垽")
		if html.startswith(l11lll_l1_ (u"࠭ࡕࡓࡎࡖࡁࠬ垾")):
			l11llllll1l1_l1_ = EVAL(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ垿"),html.split(l11lll_l1_ (u"ࠨࡗࡕࡐࡘࡃࠧ埀"),1)[1])
			for request in l11llllll1l1_l1_:
				url = request[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭埁")]
				method = request[l11lll_l1_ (u"ࠪࡱࡪࡺࡨࡰࡦࠪ埂")]
				data = request[l11lll_l1_ (u"ࠫࡩࡧࡴࡢࠩ埃")]
				headers = request[l11lll_l1_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭埄")]
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,l11lll_l1_ (u"࠭ࠧ埅"),l11lll_l1_ (u"ࠧࠨ埆"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨ埇"))
				l1111l11l11l_l1_ = response.content
				if l11lll_l1_ (u"ࠩ࠱ࡱࡵ࠺ࠧ埈") in l1111l11l11l_l1_:
					l1ll1ll1l_l1_ = True
					break
				l1111ll11l11_l1_ = str(response.headers)
				l1111llll1l1_l1_ = l1111ll11l11_l1_+l1111l11l11l_l1_
				l11111l1lll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࡝ࡹ࠮࠭࠳࠰࠿ࠣࠪࡨࡽࡏ࠴ࠪࡀࠫࠥࠫ埉"),l1111llll1l1_l1_,re.DOTALL)
				token = re.findall(l11lll_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠴ࠪࡀࠤࠫ࠴࠸ࡇ࠮ࠫࡁࠬࠦࠬ埊"),l1111llll1l1_l1_,re.DOTALL)
				if token: token = token[0]
				if l11111l1lll1_l1_ or token: break
		if not l1ll1ll1l_l1_:
			if not l11111l1lll1_l1_:
				if not token and l11l1l11ll11_l1_:
					if 1 and not html.startswith(l11lll_l1_ (u"ࠬࡏࡄ࠾ࠩ埋")):
						data = {l11lll_l1_ (u"࠭ࡵࡴࡧࡵࠫ埌"):user,l11lll_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ埍"):l11ll111l11_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ城"):l1111l111l11_l1_,l11lll_l1_ (u"ࠩ࡮ࡩࡾ࠭埏"):l111l111ll11_l1_,l11lll_l1_ (u"ࠪ࡭ࡩ࠭埐"):l11lll_l1_ (u"ࠫࠬ埑"),l11lll_l1_ (u"ࠬࡰ࡯ࡣࠩ埒"):l11lll_l1_ (u"࠭ࡧࡦࡶ࡬ࡨࠬ埓")}
						response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ埔"),l111ll11l111_l1_,data,l11lll_l1_ (u"ࠨࠩ埕"),l11lll_l1_ (u"ࠩࠪ埖"),l11lll_l1_ (u"ࠪࠫ埗"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠵ࡶ࡫ࠫ埘"))
						html = response.content
					else: html = l11lll_l1_ (u"ࠬࡏࡄ࠾࠳࠵࠷࠹ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀ࠸࠺࠭埙")
					if html.startswith(l11lll_l1_ (u"࠭ࡉࡅ࠿ࠪ埚")):
						l1111lllll1l_l1_ = re.findall(l11lll_l1_ (u"ࠧࡊࡆࡀࠬ࠳࠰࠿ࠪ࠼࠽࠾࠿࡚ࡉࡎࡇࡒ࡙࡙ࡃࠨ࠯ࠬࡂ࠭ࠩ࠭埛"),html,re.DOTALL)
						l111l111llll_l1_,timeout = l1111lllll1l_l1_[0]
						message = l11lll_l1_ (u"ࠨ้ำ๋ࠥอไฺ็็๎ฮࠦสฮฬสะࠥ๎โห่๊ࠢࠥ࠷࠰ࠡว็ํࠥ࠭埜")+timeout+l11lll_l1_ (u"ࠩࠣฯฬ์๊สࠩ埝")
						l11l1l1ll1_l1_ = DIALOG_PROGRESS()
						l11l1l1ll1_l1_.create(l11lll_l1_ (u"้ࠪาอ่ๅหࠣฮัอ่ำࠢไัฺࠦร็ษࠣวู๋ว็ุ๋่ࠢะࠠษำ้ห๊าࠠไ๊่ฬ๏๎สาࠩ埞"),message)
						t1 = time.time()
						l11l1ll11l11_l1_,l11l1l111l11_l1_ = 0,0
						while l11l1ll11l11_l1_<int(timeout):
							PROGRESS_UPDATE(l11l1l1ll1_l1_,int(l11l1ll11l11_l1_/int(timeout)*100),message,l11lll_l1_ (u"ࠫࠬ域"),timeout+l11lll_l1_ (u"ࠬࠦ࠯ࠡࠩ埠")+str(int(l11l1ll11l11_l1_))+l11lll_l1_ (u"࠭ࠠࠡอส๊๏ฯࠧ埡"))
							#if l11l1l1ll1_l1_.iscanceled(): break
							if l11l1ll11l11_l1_>l11l1l111l11_l1_+10:
								data = {l11lll_l1_ (u"ࠧࡶࡵࡨࡶࠬ埢"):user,l11lll_l1_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ埣"):l11ll111l11_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭埤"):l1111l111l11_l1_,l11lll_l1_ (u"ࠪ࡯ࡪࡿࠧ埥"):l111l111ll11_l1_,l11lll_l1_ (u"ࠫ࡮ࡪࠧ埦"):l111l111llll_l1_,l11lll_l1_ (u"ࠬࡰ࡯ࡣࠩ埧"):l11lll_l1_ (u"࠭ࡧࡦࡶࡷࡳࡰ࡫࡮ࠨ埨")}
								response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ埩"),l111ll11l111_l1_,data,l11lll_l1_ (u"ࠨࠩ埪"),l11lll_l1_ (u"ࠩࠪ埫"),l11lll_l1_ (u"ࠪࠫ埬"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫ埭"))
								html = response.content
								if html.startswith(l11lll_l1_ (u"࡚ࠬࡏࡌࡇࡑࡁࠬ埮")):
									token = html.split(l11lll_l1_ (u"࠭ࡔࡐࡍࡈࡒࡂ࠭埯"),1)[1]
									break
								l11l1l111l11_l1_ = l11l1ll11l11_l1_
							else: time.sleep(1)
							l11l1ll11l11_l1_ = time.time()-t1
						l11l1l1ll1_l1_.close()
				if token:
					l11l11lll1ll_l1_ = response.cookies
					l1l1111l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧ埰"),l1111llll1l1_l1_,re.DOTALL)
					if l11lll_l1_ (u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ埱") in list(l11l11lll1ll_l1_.keys()): l1l1111l1lll_l1_ = l11l11lll1ll_l1_[l11lll_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ埲")]
					elif l1l1111l1lll_l1_: l1l1111l1lll_l1_ = l1l1111l1lll_l1_[0]
					l11l1l11ll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ埳"),l1111l11l11l_l1_,re.DOTALL)
					if l11l1l11ll11_l1_: l11l11lll111_l1_,l111l111ll11_l1_ = l11l1l11ll11_l1_[0]
					if l1l1111l1lll_l1_ and l11l1l11ll11_l1_:
						headers = {l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ埴"):l11lll_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠭埵")+l1l1111l1lll_l1_,l11lll_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ埶"):l1111l111l11_l1_,l11lll_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭執"):l11lll_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ埸")}
						data = l11lll_l1_ (u"ࠩࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦ࠿ࠪ培")+token
						response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ基"),l11l11lll111_l1_,data,headers,False,l11lll_l1_ (u"ࠫࠬ埻"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠸ࡷ࡬ࠬ埼"))
						l1111l11l11l_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l11111l1lll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠳࠰࠿ࠪࠩ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ埽"),str(cookies),re.DOTALL)
			if l11111l1lll1_l1_:
				name,l11111l1lll1_l1_ = l11111l1lll1_l1_[0]
				l11ll11l1_l1_ = name+l11lll_l1_ (u"ࠧ࠾ࠩ埾")+l11111l1lll1_l1_
				WRITE_TO_SQL3(main_dbfile,l11lll_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ埿"),l11lll_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࡠࡘࡈࡖࡎࡌࡉࡄࡃࡗࡍࡔࡔࠧ堀"),l11ll11l1_l1_,PERMANENT_CACHE)
				DIALOG_OK(l11lll_l1_ (u"ࠪࠫ堁"),l11lll_l1_ (u"ࠫࠬ堂"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ堃"),l11lll_l1_ (u"࠭ๆอฯอࠤ฾๋ไ๋หࠣๅา฻ࠠฤ่สࠤส์ำศ่ࠣ࠲࠳่ࠦใษ่ࠤฬ๊ศา่ส้ัࠦศฯิ้ࠤ๋ะววฮ๋ࠣีอࠠศๆไัฺࠦไไ์ࠣ๎ุะฮะ็๊ห๊ࠥวฮไสࠤ࠳࠴้ࠠๆสࠤฯ๎ฬะࠢะหัฯࠠๅว฼หิฯ่ࠠาสࠤฬ๊แฮื่ࠣ฾ีษࠡลื๋ึࠦ࡜࡯࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่ๆำีࠡี๋ๅࠥ๐สไำิࠤๆ๐ࠠฮษ็อࠥะฺ๋ำࠣีอ฽ࠠศๆฯ๋ฬุࠠษษ็ษ๋ะั็ฬࠣ࠲࠳ࠦร้ࠢศ฻ๆอมࠡำส์ฯืࠠศๆศ๊ฯืๆหࠢ࠱࠲ࠥษ่ࠡใุู่ࠥไไࠢส่ึอ่หำࠣ࠲࠳ࠦร้ࠢสืฯิฯศ็࡚ࠣࡕࡔࠠฤ๊ࠣฬึ๎ใิ์ࠪ堄"))
				if l11lll_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ堅") not in l1111l11l11l_l1_:
					headers = {l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ堆"):l11ll11l1_l1_}
					response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭堇"),l1111l111l11_l1_,l11lll_l1_ (u"ࠪࠫ堈"),headers,l11lll_l1_ (u"ࠫࠬ堉"),l11lll_l1_ (u"ࠬ࠭堊"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭堋"))
					l1111l11l11l_l1_ = response.content
	if not l1ll1ll1l_l1_ and not l11ll11l1_l1_: DIALOG_OK(l11lll_l1_ (u"ࠧࠨ堌"),l11lll_l1_ (u"ࠨࠩ堍"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ堎"),l11lll_l1_ (u"ࠪ฽๊๊๊สࠢไัฺࠦร็ษࠣวู๋ว็ࠢไุ้ะࠠ࠯࠰ࠣัฬ๎ไࠡว฼หิฯࠠศๆ฼้้๐ษࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัส้ࠥ์แิࠢส่ๆ๐ฯ๋๊ࠣวํࠦแ๋ัํ์ࠥเ๊า้้๋ࠣࠦๆโีࠣห้๋่ใ฻ࠪ堏"))
	return l1111l11l11l_l1_
def l111111_l1_(url,type,l11l111l_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ堐"),l11lll_l1_ (u"ࠬ࠭堑"),url,type)
	# http://l111l1ll1l11_l1_.l11l1ll1ll1l_l1_.io/link/136530
	l1lllll1_l1_,l1lllll11l1_l1_ = [],[]
	#l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"࠭ࠧ堒"),l11lll_l1_ (u"ࠧࠨ堓"),True,l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠵ࡸࡺࠧ堔"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭堕"),url,l11lll_l1_ (u"ࠪࠫ堖"),l11lll_l1_ (u"ࠫࠬ堗"),l11lll_l1_ (u"ࠬ࠭堘"),l11lll_l1_ (u"࠭ࠧ堙"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭堚"))
	l11lll1l_l1_ = response.content
	l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ堛"),l11lll1l_l1_,re.DOTALL)
	for block in l111l11_l1_:
		links = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭堜"),block,re.DOTALL)
		for link,title in links:
			if link in l1lllll1_l1_: continue
			if l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ堝") not in link and l11lll_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ堞") not in link: continue
			title = title.replace(l11lll_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭堟"),l11lll_l1_ (u"࠭ࠧ堠")).replace(l11lll_l1_ (u"ࠧࠡ࠯ࠣࠫ堡"),l11lll_l1_ (u"ࠨࠩ堢")).strip(l11lll_l1_ (u"ࠩࠣࠫ堣")).replace(l11lll_l1_ (u"ࠪࠤࠥ࠭堤"),l11lll_l1_ (u"ࠫࠥ࠭堥"))
			l1lllll1_l1_.append(link)
			l1lllll11l1_l1_.append(title)
	if len(l1lllll1_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬฮูื้สࠤ๏ำสศฮࠣ࠺࠵ࠦหศ่ํอࠬ堦"),l1lllll11l1_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡅࡤࡲࡨ࡫࡬ࡦࡦࠣࡅࡐ࡝ࡁࡎࠩ堧"),[],[]
	elif len(l1lllll1_l1_)==1: l1l_l1_ = 0
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ堨"),[],[]
	l1111l111l11_l1_ = l1lllll1_l1_[l1l_l1_]
	l1111l11l11l_l1_ = l111llll1ll1_l1_(l1111l111l11_l1_)
	l1111_l1_,l1lll1ll_l1_ = [],[]
	if type==l11lll_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ堩"):
		l111l1ll1111_l1_ = re.findall(l11lll_l1_ (u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堪"),l1111l11l11l_l1_,re.DOTALL)
		if l111l1ll1111_l1_:
			link = l111l_l1_(l111l1ll1111_l1_[0])
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(l11l111l_l1_)
	elif type==l11lll_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ堫"):
		links = re.findall(l11lll_l1_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭堬"),l1111l11l11l_l1_,re.DOTALL)
		for link,size in links:
			if not link: continue
			if l11l111l_l1_ in size:
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
				break
		if not l1111_l1_:
			for link,size in links:
				if not link: continue
				l1lll1ll_l1_.append(size)
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࡚ࠬࡅࡔࡖࠪ堭"),l1111_l1_)
	if not l1111_l1_: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ堮"),[],[]
	return l11lll_l1_ (u"ࠧࠨ堯"),l1lll1ll_l1_,l1111_l1_
def l1l111l_l1_(url,name):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ堰"),l11lll_l1_ (u"ࠩࠪ報"),url,l11l1ll1l11l_l1_)
	# http://l11l1l11l11_l1_.l111l11ll11l_l1_.net/5cf68c23e6e79			?l11l1ll1l11l_l1_=			__11ll11l111l_l1_
	# http://w.l11ll1l1_l1_.l1ll1lll111_l1_/5e14fd0a2806e			?l11l1ll1l11l_l1_=			ok.l111l1lll1ll_l1_
	#l11l1ll1l11l_l1_ = l11l1ll1l11l_l1_.replace(l11lll_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࡡࡢࠫ堲"),l11lll_l1_ (u"ࠫࠬ堳")).split(l11lll_l1_ (u"ࠬࡥ࡟ࠨ場"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ堵"),url,l11lll_l1_ (u"ࠧࠨ堶"),l11lll_l1_ (u"ࠨࠩ堷"),True,l11lll_l1_ (u"ࠩࠪ堸"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩ堹"))
	html = response.content
	cookies = response.cookies
	if l11lll_l1_ (u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫ堺") in list(cookies.keys()):
		l11ll11l1_l1_ = cookies[l11lll_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ堻")]
		l11ll11l1_l1_ = l111l_l1_(escapeUNICODE(l11ll11l1_l1_))
		items = re.findall(l11lll_l1_ (u"࠭ࡲࡰࡷࡷࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堼"),l11ll11l1_l1_,re.DOTALL)
		l11l11l_l1_ = items[0].replace(l11lll_l1_ (u"ࠧ࡝࠱ࠪ堽"),l11lll_l1_ (u"ࠨ࠱ࠪ堾"))
		l11l11l_l1_ = escapeUNICODE(l11l11l_l1_)
	else: l11l11l_l1_ = url
	if l11lll_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ堿") in l11l11l_l1_:
		id = l11l11l_l1_.split(l11lll_l1_ (u"ࠪࠩ࠷ࡌࠧ塀"))[-1]
		l11l11l_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡧࡴࡤࡪ࠱࡭ࡸ࠵ࠧ塁")+id
		return l11lll_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ塂"),[l11lll_l1_ (u"࠭ࠧ塃")],[l11l11l_l1_]
	else:
		l1l1ll11_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭塄")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ塅"),l1l1ll11_l1_,l11lll_l1_ (u"ࠩࠪ塆"),l11lll_l1_ (u"ࠪࠫ塇"),True,l11lll_l1_ (u"ࠫࠬ塈"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫ塉"))
		l11l1ll11lll_l1_ = response.url
		#l11l1ll11lll_l1_ = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ塊")]
		#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ塋"),l11lll_l1_ (u"ࠨࠩ塌"),response.url,l1l1ll11_l1_)
		l111ll11l1l1_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠩ࠲ࠫ塍"))[2]#.encode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ塎"))
		l11ll11lll11_l1_ = l11l1ll11lll_l1_.split(l11lll_l1_ (u"ࠫ࠴࠭塏"))[2]#.encode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ塐"))
		l11l1l1_l1_ = l11l11l_l1_.replace(l111ll11l1l1_l1_,l11ll11lll11_l1_)
		headers = { l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ塑"):l11lll_l1_ (u"ࠧࠨ塒") , l11lll_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ塓"):l11lll_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ塔") , l11lll_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ塕"):l11l1l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ塖"), l11l1l1_l1_, l11lll_l1_ (u"ࠬ࠭塗"), headers, False,l11lll_l1_ (u"࠭ࠧ塘"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ࠭塙"))
		html = response.content
		#xbmc.log(str(l11l1l1_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11lll_l1_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ塚"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11lll_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ塛"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11lll_l1_ (u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ塜"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ塝"),l11lll_l1_ (u"ࠬ࠭塞"),str(items),html)
		if items:
			link = items[0].replace(l11lll_l1_ (u"࠭࡜࠰ࠩ塟"),l11lll_l1_ (u"ࠧ࠰ࠩ塠"))
			link = link.rstrip(l11lll_l1_ (u"ࠨ࠱ࠪ塡"))
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ塢") not in link: link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ塣") + link
			link = link.replace(l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ塤"),l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ塥"))
			if name==l11lll_l1_ (u"࠭ࠧ塦"): l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠧࠨ塧"),[l11lll_l1_ (u"ࠨࠩ塨")],[link]
			else: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ塩"),[l11lll_l1_ (u"ࠪࠫ塪")],[link]
		else: l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_ = l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬ填"),[],[]
		return l11ll1111lll_l1_,l1lll1ll_l1_,l1111_l1_
def l11l1l111ll1_l1_(url):
	# https://www.l11l1l1l1l1l_l1_.com/e/l1111ll111ll_l1_
	headers = { l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ塬") : l11lll_l1_ (u"࠭ࠧ塭") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠧࠨ塮"),headers,l11lll_l1_ (u"ࠨࠩ塯"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭塰"))
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ塱"),l11lll_l1_ (u"ࠫࠬ塲"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭塳"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_,errno = [],[],l11lll_l1_ (u"࠭ࠧ塴")
	if items:
		for link,l1ll11l1ll1l_l1_ in items:
			l1lll1ll_l1_.append(l1ll11l1ll1l_l1_)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠭塵"),[],[]
	return l11lll_l1_ (u"ࠨࠩ塶"),l1lll1ll_l1_,l1111_l1_
def l1111lll1l1l_l1_(url):
	# https://l111l1l111ll_l1_.io/l1l11llll_l1_-l1111lll1lll_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ塷"),l11lll_l1_ (u"ࠪࠫ塸"))
	headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ塹"):l11lll_l1_ (u"ࠬ࠭塺")}
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ塻"),headers,l11lll_l1_ (u"ࠧࠨ塼"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡗࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ塽"))
	items = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ塾"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ塿"),l11lll_l1_ (u"ࠫࠬ墀"),url,items[0])
	if items:
		url = items[0]+l11lll_l1_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨ墁")+url
		return l11lll_l1_ (u"࠭ࠧ墂"),[l11lll_l1_ (u"ࠧࠨ境")],[url]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡖࡒࡏࡂࡆࠪ墄"),[],[]
def l111llll111l_l1_(url):
	# https://l111111l1111_l1_.to/l1l11llll_l1_/5c83f14297d62
	url = url.strip(l11lll_l1_ (u"ࠩ࠲ࠫ墅"))
	if l11lll_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ墆") in url: id = url.split(l11lll_l1_ (u"ࠫ࠴࠭墇"))[4]
	else: id = url.split(l11lll_l1_ (u"ࠬ࠵ࠧ墈"))[-1]
	url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡥࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡳ࠴ࡶ࡬ࡢࡻࡨࡶࡄ࡬ࡩࡥ࠿ࠪ墉") + id
	headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ墊") : l11lll_l1_ (u"ࠨࠩ墋") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ墌"),headers,l11lll_l1_ (u"ࠪࠫ墍"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡅࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭墎"))
	html = html.replace(l11lll_l1_ (u"ࠬࡢ࡜ࠨ墏"),l11lll_l1_ (u"࠭ࠧ墐"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ墑"),l11lll_l1_ (u"ࠨࠩ墒"),url,html)
	items = re.findall(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ墓"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠪࠫ墔"),[l11lll_l1_ (u"ࠫࠬ墕")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡅࡖࡘࡗࡋࡁࡎࠩ墖"),[],[]
def l111l111l11l_l1_(url):
	# https://l11l1llll1l1_l1_.net/l1l11llll_l1_-l11l11ll111l_l1_.html
	url = url.replace(l11lll_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭増"),l11lll_l1_ (u"ࠧࠨ墘"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ墙"),l11lll_l1_ (u"ࠩࠪ墚"),l11lll_l1_ (u"ࠪࠫ墛"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡓ࡟ࡇ࠭࠲ࡵࡷࠫ墜"))
	items = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࡳࡧࡶ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ墝"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for link,l1ll11l1ll1l_l1_,res in items:
		l1lll1ll_l1_.append(l1ll11l1ll1l_l1_+l11lll_l1_ (u"࠭ࠠࠨ增")+res)
		l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡕ࡚ࡂࠩ墟"),[],[]
	return l11lll_l1_ (u"ࠨࠩ墠"),l1lll1ll_l1_,l1111_l1_
def l11l111l1111_l1_(url):
	# https://l11ll111l111_l1_.l1ll1ll1l11_l1_/l1l11llll_l1_-l111l11l1lll_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠩࡨࡱࡧ࡫ࡤ࠮ࠩ墡"),l11lll_l1_ (u"ࠪࠫ墢"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ墣"),l11lll_l1_ (u"ࠬ࠭墤"),l11lll_l1_ (u"࠭ࠧ墥"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ墦"))
	items = re.findall(l11lll_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨ墧"),html,re.DOTALL)
	items = set(items)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	for id,mode,hash,l1ll11l1ll1l_l1_,res in items:
		url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭墨")+id+l11lll_l1_ (u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ墩")+mode+l11lll_l1_ (u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ墪")+hash
		html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭墫"),l11lll_l1_ (u"࠭ࠧ墬"),l11lll_l1_ (u"ࠧࠨ墭"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠴ࡱࡨࠬ墮"))
		items = re.findall(l11lll_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠢ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ墯"),html,re.DOTALL)
		for link in items:
			l1lll1ll_l1_.append(l1ll11l1ll1l_l1_+l11lll_l1_ (u"ࠪࠤࠬ墰")+res)
			l1111_l1_.append(link)
	if len(l1111_l1_)==0: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡂࡖࡆࡌ࡛ࡏࡄࡆࡑࠪ墱"),[],[]
	return l11lll_l1_ (u"ࠬ࠭墲"),l1lll1ll_l1_,l1111_l1_
def l111111l111l_l1_(url):
	# https://l11111l1ll1l_l1_.com:2053/l11111ll111l_l1_/l111l11l11l1_l1_.l11l111lll1l_l1_.l11ll11l1lll_l1_.1080p.l11ll111llll_l1_.l11l1ll1l111_l1_.l11111l11111_l1_.l1111lll_l1_.html?l11l1111l1l1_l1_=2jpqzvpT8BbNUifWZO4QLQ&l11l11ll11l1_l1_=1624070560
	# http://l1111l11l1ll_l1_.l111l1111ll_l1_/l11l111l1lll_l1_/l11l11l1111l_l1_.l111ll1ll1l1_l1_.l11l11l1ll1l_l1_.2018.1080p.l111ll11l11l_l1_-l111lll11ll1_l1_.l1111l11l111_l1_.l1111lll_l1_.html
	link = l11lll_l1_ (u"࠭ࠧ墳")
	if 1 or l11lll_l1_ (u"ࠧࡌࡧࡼࡁࠬ墴") not in url:
		l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ墵"),l11lll_l1_ (u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭墶"))
		l11l11l_l1_ = l11l11l_l1_.split(l11lll_l1_ (u"ࠪ࠳ࠬ墷"))
		id = l11l11l_l1_[3]
		l11l11l_l1_ = l11lll_l1_ (u"ࠫ࠴࠭墸").join(l11l11l_l1_[0:4])
		#headers = {l11lll_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ墹"):l1l11l11l_l1_(),l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ墺"):l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭墻")}
		payload = {l11lll_l1_ (u"ࠨ࡫ࡧࠫ墼"):id,l11lll_l1_ (u"ࠩࡲࡴࠬ墽"):l11lll_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭墾"),l11lll_l1_ (u"ࠫࡲ࡫ࡴࡩࡱࡧࡣ࡫ࡸࡥࡦࠩ墿"):l11lll_l1_ (u"ࠬࡌࡲࡦࡧ࠮ࡈࡴࡽ࡮࡭ࡱࡤࡨ࠰ࠫ࠳ࡆࠧ࠶ࡉࠬ壀")}
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ壁"),l11l11l_l1_,payload,l11lll_l1_ (u"ࠧࠨ壂"),l11lll_l1_ (u"ࠨࠩ壃"),l11lll_l1_ (u"ࠩࠪ壄"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ壅"))
		if l11lll_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭壆") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ壇")]
		if not link and response.succeeded:
			html = response.content
			link = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ壈"),html,re.DOTALL)
			if link: link = link[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ壉"),url,l11lll_l1_ (u"ࠨࠩ壊"),l11lll_l1_ (u"ࠩࠪ壋"),l11lll_l1_ (u"ࠪࠫ壌"),l11lll_l1_ (u"ࠫࠬ壍"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠳ࡰࡧࠫ壎"))
		if l11lll_l1_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨ壏") in list(response.headers.keys()): link = response.headers[l11lll_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ壐")]
	if link: return l11lll_l1_ (u"ࠨࠩ壑"),[l11lll_l1_ (u"ࠩࠪ壒")],[link]
	return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡛ࠥࡐࡃࡑࡐࠫ壓"),[],[]
def l111lllll111_l1_(url):
	# https://www.l111ll1l11l1_l1_.com/012ocyw9li6g.html
	headers = { l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ壔") : l11lll_l1_ (u"ࠬ࠭壕") }
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ壖"),headers,l11lll_l1_ (u"ࠧࠨ壗"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪ壘"))
	items = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨ壙"),html,re.DOTALL)
	l1lll1ll_l1_,l1111_l1_ = [],[]
	if items:
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪࡱࡵ࠺ࠧ壚"))
		l1111_l1_.append(items[0][1])
		l1lll1ll_l1_.append(l11lll_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠩ壛"))
		l1111_l1_.append(items[0][0])
		return l11lll_l1_ (u"ࠬ࠭壜"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪ壝"),[],[]
def l111lllll1l_l1_(url):
	# l11l111lll11_l1_ l11l1l1l11ll_l1_			url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡞࠽ࡗ࠵࠳࡙ࡑࡽࡿࡑࡆࠩ壞")
	# l11111lll1ll_l1_ .l11ll11l11l1_l1_ l11l1l1l11ll_l1_		url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡞ࡶ࡮ࡕࡑࡅࡾ࡫ࡹࡇࡋࠪ壟")
	# l11l111ll111_l1_ l11l1l1l11_l1_ .l1llll1l1_l1_ l11l1l1l11ll_l1_		url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡇࡧ࠴࠰ࡒࡘࡺࡓࡴࡐࡺࠫ壠")
	# l111lllllll1_l1_ l11l1l1l11ll_l1_			url = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡦࡡࡖ࠽࡛ࡼࡊࡎ࠳ࡓࡍࠬ壡")
	# l111l11l11_l1_ files have l111llll11l1_l1_ l1l111ll11ll_l1_		url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࠳ࡺࡈࡗ࡛ࡖࡤࡕࡼࡣࡖ࠭壢")
	# url = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࡧࡇࡰ࡟࠻ࡶࡂࡐࡔ࡙࡬࠭壣")
	# url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹ࠳ࡷ࠱ࡦࡪ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ壤")
	# url = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡩࡲࡨࡥࡥ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ壥")
	# url = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪ壦")
	# url = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡰࡇࡇ࡯࡯࡮ࡥࡊ࠲࡛࡮ࠪࡦࡨ࡟ࡤࡪࡤࡲࡳ࡫࡬࠾ࡉࡲࡰࡩ࡫࡮ࡍ࡫ࡱࡩ࡫ࡵࡲࡕࡘࡓࡶࡴࡪࡵࡤࡶ࡬ࡳࡳࡧ࡮ࡥࡆ࡬ࡷࡹࡸࡩࡣࡷࡷ࡭ࡴࡴ࠿ࡴࡻࡱࡨ࡮ࡩࡡࡵ࡫ࡲࡲࡂ࠸࠷࠸࠷࠺࠹ࠬ壧")
	# l1ll1llll_l1_ l1111lll111l_l1_ details   https://l111l11l1ll1_l1_.me/l11111l1l111_l1_/l111111ll11l_l1_-l11111l11lll_l1_-l1111ll1lll1_l1_
	id = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ壨"))[-1]
	id = id.split(l11lll_l1_ (u"ࠫࠫ࠭壩"))[0]
	id = id.replace(l11lll_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ壪"),l11lll_l1_ (u"࠭ࠧ士"))
	#id = l11lll_l1_ (u"ࠧࡦࡡࡖ࠽࡛ࡼࡊࡎ࠳ࡓࡍࠬ壬")
	#url = l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲ࡴࡱࡧࡹ࠰ࡁࡹ࡭ࡩ࡫࡯ࡠ࡫ࡧࡁࠬ壭")+id
	#return l11lll_l1_ (u"ࠩࠪ壮"),[l11lll_l1_ (u"ࠪࠫ壯")],[url]
	l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ声")][0]+l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ壱")+id
	l111111l11ll_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩ売")+id
	l111ll1lll11_l1_,l11111ll1111_l1_,l11ll11ll111_l1_,l1111l11111l_l1_ = l11lll_l1_ (u"ࠧࠨ壳"),l11lll_l1_ (u"ࠨࠩ壴"),l11lll_l1_ (u"ࠩࠪ壵"),l11lll_l1_ (u"ࠪࠫ壶")
	l11lll_l1_ (u"ࠦࠧࠨࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠫ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡡ࠭ࠬࠨࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠨ࠯ࠬࡂ࠭ࡩ࡫ࡦࡢࡷ࡯ࡸࡆࡻࡤࡪࡱࡗࡶࡦࡩ࡫ࡊࡰࡧࡩࡽ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠦࠨࠫࠍࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࢀࠨ࡬ࡢࡰࡪࡹࡦ࡭ࡥࡄࡱࡧࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂ࡛ࠦࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬࡣࠬ࡜ࠩࠪࡡࠏࠏࠉࠊࡨࡲࡶࠥࡲࡡ࡯ࡩ࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱࡧ࡮ࡨࠫࠍࠍࠎࠏࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้ะัอ็ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ࠭ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡࡰࡲࡸࠥ࡯࡮ࠡ࡝࠳࠰࠲࠷࡝࠻ࠌࠌࠍࠎࠏࡳࡶࡤࡷ࡭ࡹࡲࡥࡖࡔࡏࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡧࡧࡳࡦࡗࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࠦ࠽ࠡࡵࡸࡦࡹ࡯ࡴ࡭ࡧࡘࡖࡑࡡ࠰࡞࠭ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠫࡺࡹࡱࡧࡀࡸࡷࡧࡣ࡬ࠨࡷࡰࡦࡴࡧ࠾ࠩ࠮ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡠࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮࡞ࠌࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡩࡧࠢࠪ࠳ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠯ࠨࠢ࡬ࡲࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࡀࠠࡥࡣࡶ࡬࡚ࡘࡌࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡪࡡࡴࡪࡘࡖࡑࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡹ࠯ࠨ࠮ࠪ࠳ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠯ࠨࠫࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡨ࡭ࡵࡘࡖࡑࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠨ࡮ࡴ࡮࡮࠵ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࡮࡬ࡴࡗࡕࡐ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠸࡮ࡥࠩࠬࠎࠎࠏࠣࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡘ࠮ࡏࡈࡈࡎࡇ࠺ࡖࡔࡌࡁࠧ࠮࠮ࠫࡁࠬࠦ࠱࡚࡙ࡑࡇࡀࡗ࡚ࡈࡔࡊࡖࡏࡉࡘ࠲ࡇࡓࡑࡘࡔ࠲ࡏࡄ࠾ࠤࡹࡸࡹ࠭ࠬࡩࡶࡰࡰ࠷࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠩࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠢࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠧ࠰࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠧࡶࡼࡴࡪࡃࡴࡳࡣࡦ࡯ࠫࡺ࡬ࡢࡰࡪࡁࠬࠐࠉࡣ࡮ࡲࡧࡰࡹࠬࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠬࡧ࡯ࡷࡣࡸ࡯ࡺࡦࡡࡧ࡭ࡨࡺࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝࠭ࡽࢀࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡹࡷࡲ࡟ࡦࡰࡦࡳࡩ࡫ࡤࡠࡨࡰࡸࡤࡹࡴࡳࡧࡤࡱࡤࡳࡡࡱࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠣࡦࡱࡵࡣ࡬ࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡦࡪࡡࡱࡶ࡬ࡺࡪࡥࡦ࡮ࡶࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊ࡫ࡩࠤࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡬࡭ࡵࡡ࡯࡭ࡸࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡࡣࡱࡨࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠤࡁࡠ࠭ࠧ࡞࠼ࠍࠍࠎࠏࡦ࡮ࡶࡢࡰ࡮ࡹࡴࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࠉࡧ࡯ࡷࡣ࡮ࡺࡡࡨࡵࠣࡁࠥ࡬࡭ࡵࡡ࡯࡭ࡸࡺ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠭ࠩࠬࠎࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥ࡬࡭ࡵࡡ࡬ࡸࡦ࡭ࡳ࠻ࠌࠌࠍࠎࠏࡩࡵࡣࡪ࠰ࡸ࡯ࡺࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠲ࠫ࠮ࠐࠉࠊࠋࠌࡪࡲࡺ࡟ࡴ࡫ࡽࡩࡤࡪࡩࡤࡶ࡞࡭ࡹࡧࡧ࡞ࠢࡀࠤࡸ࡯ࡺࡦࠌࠌࡪࡴࡸࠠࡣ࡮ࡲࡧࡰࠦࡩ࡯ࠢࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡨ࡬ࡰࡥ࡮࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋ࡯࡭ࡳ࡫ࡳࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠯ࠫ࠮ࠐࠉࠊࡨࡲࡶࠥࡲࡩ࡯ࡧࠣ࡭ࡳࠦ࡬ࡪࡰࡨࡷ࠿ࠐࠉࠊࠋࠦࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨ࠮࡯ࡩࡻ࡫࡬࠾ࡺࡥࡱࡨ࠴ࡌࡐࡉࡑࡓ࡙ࡏࡃࡆࠫࠍࠍࠎࠏࠣࡹࡤࡰࡧ࠳ࡲ࡯ࡨࠪ࡯࡭ࡳ࡫ࠬ࡭ࡧࡹࡩࡱࡃࡸࡣ࡯ࡦ࠲ࡑࡕࡇࡏࡑࡗࡍࡈࡋࠩࠋࠋࠌࠍࡱ࡯࡮ࡦࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࠭ࡲࡩ࡯ࡧࠬࠎࠎࠏࠉࡥ࡫ࡦࡸࠥࡃࠠࡼࡿࠍࠍࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠ࡭࡫ࡱࡩ࠳ࡹࡰ࡭࡫ࡷࠬࠬࠬࠦࠨࠫࠍࠍࠎࠏࡦࡰࡴࠣ࡭ࡹ࡫࡭ࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠊ࡭ࡨࡽ࠱ࡼࡡ࡭ࡷࡨࠤࡂࠦࡩࡵࡧࡰ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡂ࠭ࠬ࠲ࠫࠍࠍࠎࠏࠉࡥ࡫ࡦࡸࡠࡱࡥࡺ࡟ࠣࡁࠥࡼࡡ࡭ࡷࡨࠎࠎࠏࠉࡪࡨࠣࠫࡸ࡯ࡺࡦࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯ࠠࡢࡰࡧࠤࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࠣ࡭ࡳࠦ࡬ࡪࡵࡷࠬ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠐࠉࠊࠋࠌࡨ࡮ࡩࡴ࡜ࠩࡶ࡭ࡿ࡫ࠧ࡞ࠢࡀࠤ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࡟ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡹࡧࡧࠨ࡟ࡠࠎࠎࠏࠉࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷࠮ࡢࡲࡳࡩࡳࡪࠨࡥ࡫ࡦࡸ࠮ࠐࠉࡣ࡮ࡲࡧࡰࡹࠬࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸ࠠ࠾ࠢ࡞ࡡ࠱ࡡ࡝ࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡨࡲࡶࡲࡧࡴࡴࠤ࠽ࡠࡠ࠮࠮ࠫࡁࠬࡠࡢ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠤ࠽ࡠࡠ࠮࠮ࠫࡁࠬࡠࡢ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠥࡨ࡬ࡰࡥ࡮ࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢ࠯ࠊࠊࡨࡲࡶࠥࡨ࡬ࡰࡥ࡮ࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠬࠦࠨ࠮ࠪࠪࠬ࠯ࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣࡦࡱࡵࡣ࡬࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡂࠨࠧ࠭ࠩࡀࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠤࠥࠫ࠱࠭ࠢࠨࠫࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡢ࡭ࡱࡦ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠻ࡶࡵࡹࡪ࠭ࠬࠨ࠼ࡗࡶࡺ࡫ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠿࡬ࡡ࡭ࡵࡨࠫ࠱࠭࠺ࡇࡣ࡯ࡷࡪ࠭ࠩࠋࠋࠌ࡭࡫ࠦࠧ࡜ࠩࠣࡲࡴࡺࠠࡪࡰࠣࡦࡱࡵࡣ࡬࠼ࠣࡦࡱࡵࡣ࡬ࠢࡀࠤࠬࡡࠧࠬࡤ࡯ࡳࡨࡱࠫࠨ࡟ࠪࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡆࡘࡄࡐ࠭࠭࡬ࡪࡵࡷࠫ࠱ࡨ࡬ࡰࡥ࡮࠭ࠏࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵࠢ࡬ࡲࠥࡨ࡬ࡰࡥ࡮࠾ࠏࠏࠉࠊࡦ࡬ࡧࡹࡡࠧࡪࡶࡤ࡫ࠬࡣࠠ࠾ࠢࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡯ࡴࡢࡩࠪࡡ࠮ࠐࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨࡶࡼࡴࡪ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠿ࠪ࠰ࠬࡃࠢࠨࠫ࠮ࠫࠧ࠭ࠊࠊࠋࠌ࡭࡫ࠦࠧࡧࡲࡶࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬ࡬ࡰࡴࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡩࡴࡸ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫࡢ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩ࠻ࠢࡧ࡭ࡨࡺ࡛ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩࡠࠤࡂࠦࡳࡵࡴࠫࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩࡠ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡽࡩࡥࡶ࡫ࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡹࡩࡻࡧࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡻ࡮ࡪࡴࡩࠩࡠ࠭࠰࠭ࡸࠨ࠭ࡶࡸࡷ࠮ࡤࡪࡥࡷ࡟ࠬ࡮ࡥࡪࡩ࡫ࡸࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡪࡶࠪࡡࠥࡃࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩࡠ࡟ࠬࡹࡴࡢࡴࡷࠫࡢ࠱ࠧ࠮ࠩ࠮ࡨ࡮ࡩࡴ࡜ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡧࡱࡨࠬࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫࡢࡡࠧࡴࡶࡤࡶࡹ࠭࡝ࠬࠩ࠰ࠫ࠰ࡪࡩࡤࡶ࡞ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ࡟࡞ࠫࡪࡴࡤࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡝ࠡ࠿ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪࡡࠏࠏࠉࠊ࡫ࡩࠤࠬࡨࡩࡵࡴࡤࡸࡪ࠭ࠠࡪࡰࠣࡰ࡮ࡹࡴࠩࡦ࡬ࡧࡹ࠴࡫ࡦࡻࡶࠬ࠮࠯ࠠࡢࡰࡧࠤࡩ࡯ࡣࡵ࡝ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫࡢࡄ࠱࠲࠳࠵࠶࠷࠹࠳࠴࠼ࠣࡨࡪࡲࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠌࠌࠍࠎ࡯ࡦࠡࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠐࠉࠊࠋࠌࡧ࡮ࡶࡨࡦࡴࠣࡁࠥࡪࡩࡤࡶ࡞ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭࡝࠯ࡵࡳࡰ࡮ࡺࠨࠨࠨࠪ࠭ࠏࠏࠉࠊࠋࡩࡳࡷࠦࡩࡵࡧࡰࠤ࡮ࡴࠠࡤ࡫ࡳ࡬ࡪࡸ࠺ࠋࠋࠌࠍࠎࠏ࡫ࡦࡻ࠯ࡺࡦࡲࡵࡦࠢࡀࠤ࡮ࡺࡥ࡮࠰ࡶࡴࡱ࡯ࡴࠩࠩࡀࠫ࠱࠷ࠩࠋࠋࠌࠍࠎࠏࡤࡪࡥࡷ࡟ࡰ࡫ࡹ࡞ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࠭ࡼࡡ࡭ࡷࡨ࠭ࠏࠏࠉࠊࠥ࡬ࡪࠥ࠭ࡵࡳ࡮ࠪࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭ࡪࡩࡤࡶ࠱࡯ࡪࡿࡳࠩࠫࠬ࠾ࠥࡪࡩࡤࡶ࡞ࠫࡺࡸ࡬ࠨ࡟ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡤࡪࡥࡷ࡟ࠬࡻࡲ࡭ࠩࡠ࠭ࠏࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠯ࠊࠊࡷࡵࡰࡤࡲࡩࡴࡶ࠯ࡷࡹࡸࡥࡢ࡯ࡶ࠴࠱ࡹࡴࡳࡧࡤࡱࡸ࠷ࠬࡴࡶࡵࡩࡦࡳࡳ࠳ࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢ࠲࡛࡞ࠌࠌ࡭࡫ࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶ࠦࡡ࡯ࡦࠣࡷࡹࡸࡥࡢ࡯ࡶࡣࡹࡿࡰࡦ࠴࠽ࠎࠎࠏࡦࡰࡴࠣࡨ࡮ࡩࡴ࠲ࠢ࡬ࡲࠥࡹࡴࡳࡧࡤࡱࡸࡥࡴࡺࡲࡨ࠵࠿ࠐࠉࠊࠋࡸࡶࡱ࠷ࠠ࠾ࠢࡧ࡭ࡨࡺ࠱࡜ࠩࡸࡶࡱ࠭࡝࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࠧࡺࡸ࡬࠲ࠢࡀࠤ࡚ࡔࡑࡖࡑࡗࡉ࡛࠭ࡎࡒࡗࡒࡘࡊ࠮ࡤࡪࡥࡷ࠵ࡠ࠭ࡵࡳ࡮ࠪࡡ࠮࠯࡛࠻࠵࠳࠴ࡢࠐࠉࠊࠋࡩࡳࡷࠦࡤࡪࡥࡷ࠶ࠥ࡯࡮ࠡࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲࠻ࠌࠌࠍࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡤࡪࡥࡷ࠶ࡠ࠭ࡵࡳ࡮ࠪࡡࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࠊࠥࡸࡶࡱ࠸ࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇ࡙ࠫࡓࡗࡕࡐࡖࡈࠬࡩ࡯ࡣࡵ࠴࡞ࠫࡺࡸ࡬ࠨ࡟ࠬ࠭ࡠࡀ࠳࠱࠲ࡠࠎࠎࠏࠉࠊ࡫ࡩࠤࡺࡸ࡬࠲࠿ࡀࡹࡷࡲ࠲ࠡࡣࡱࡨࠥࡻࡲ࡭࠳ࠣࡲࡴࡺࠠࡪࡰࠣࡹࡷࡲ࡟࡭࡫ࡶࡸ࠿ࠐࠉࠊࠋࠌࠍࡺࡸ࡬ࡠ࡮࡬ࡷࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡵࡳ࡮࠴࠭ࠏࠏࠉࠊࠋࠌࡨ࡮ࡩࡴ࠲࠰ࡸࡴࡩࡧࡴࡦࠪࡧ࡭ࡨࡺ࠲ࠪࠌࠌࠍࠎࠏࠉࡴࡶࡵࡩࡦࡳࡳ࠱࠰ࡤࡴࡵ࡫࡮ࡥࠪࡧ࡭ࡨࡺ࠱ࠪࠌࠌࡩࡱࡹࡥ࠻ࠢࡶࡸࡷ࡫ࡡ࡮ࡵ࠳ࠤࡂࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶࠱ࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠷ࠐࠉࠣࠤࠥ壷")
	# l1111l111lll_l1_ json data
	# l1l11llll_l1_ url l11l1l1l11ll_l1_:    https://www.l1ll1llll_l1_.com/l1l11llll_l1_/l11l11l1l1ll_l1_
	# list of l11l1l1l1l11_l1_ & l1l111lll11l_l1_
	# https://github.com/l1111ll1ll1l_l1_-l111ll11ll1l_l1_/l1111ll1ll1l_l1_-l111ll11ll1l_l1_/blob/master/l11l1l111lll_l1_/l111ll1l1l11_l1_/l1ll1llll_l1_.py
	# all the below l111l1111lll_l1_ were l111llll1lll_l1_ using:	https://www.l1ll1llll_l1_.com/l11l1lll111l_l1_/l1l1ll111111_l1_/l11ll111lll_l1_?l111111ll111_l1_=l11111ll1l11_l1_	&	l11l11llll1l_l1_ = l11l11l1l1ll_l1_
	# 3 l1ll111l1l1l_l1_:	13KB:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ壸"): l11lll_l1_ (u"࠭ࡉࡐࡕࡢࡇࡗࡋࡁࡕࡑࡕࠫ壹"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ壺"): l11lll_l1_ (u"ࠨ࠴࠵࠲࠸࠹࠮࠲࠲࠴ࠫ壻")
	# 7 l1ll111l1l1l_l1_		44KB:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭壼"): l11lll_l1_ (u"ࠪࡍࡔ࡙࡟ࡎࡇࡖࡗࡆࡍࡅࡔࡡࡈ࡜࡙ࡋࡎࡔࡋࡒࡒࠬ壽"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ壾"): l11lll_l1_ (u"ࠬ࠷࠷࠯࠵࠶࠲࠷࠭壿")
	# 7 l1ll111l1l1l_l1_		58KB:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ夀"): l11lll_l1_ (u"ࠧࡊࡑࡖࠫ夁"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ夂"): l11lll_l1_ (u"ࠩ࠴࠻࠳࠹࠳࠯࠴ࠪ夃")
	# 9 l1ll111l1l1l_l1_		24KB:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ处"): l11lll_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡉࡒࡆࡃࡗࡓࡗ࠭夅"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ夆"): l11lll_l1_ (u"࠭࠲࠳࠰࠶࠴࠳࠷࠰࠱ࠩ备")
	# no json file:		21 l1ll111l1l1l_l1_	95KB:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ夈"): l11lll_l1_ (u"ࠨ࡙ࡈࡆࡤࡉࡒࡆࡃࡗࡓࡗ࠭変"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ夊"): l11lll_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠷࠼࠮࠱࠲࠱࠴࠵࠭夋")
	# no json file:		21 l1ll111l1l1l_l1_	121KB:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ夌"): l11lll_l1_ (u"ࠬ࡝ࡅࡃࠩ复"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭夎"): l11lll_l1_ (u"ࠧ࠳࠰࠵࠴࠷࠸࠰࠹࠲࠴࠲࠵࠶࠮࠱࠲ࠪ夏")
	# no json file: 	26 l1ll111l1l1l_l1_	115KB:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ夐"): l11lll_l1_ (u"ࠩࡐ࡛ࡊࡈࠧ夑"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ夒"): l11lll_l1_ (u"ࠫ࠷࠴࠲࠱࠴࠵࠴࠽࠶࠱࠯࠲࠳࠲࠵࠶ࠧ夓")
	# l11lll11l111_l1_:	l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ夔"): l11lll_l1_ (u"࠭ࡁࡏࡆࡕࡓࡎࡊࠧ夕"),l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ外"): l11lll_l1_ (u"ࠨ࠳࠺࠲࠸࠷࠮࠴࠷ࠪ夗")
	# l11lll11l111_l1_:	l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭夘"): l11lll_l1_ (u"࡛ࠪࡊࡈ࡟ࡓࡇࡐࡍ࡝࠭夙"),l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ多"): l11lll_l1_ (u"ࠬ࠷࠮࠳࠲࠵࠶࠵࠽࠲࠸࠰࠳࠵࠳࠶࠰ࠨ夛")
	# l11lll11l111_l1_:	l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ夜"): l11lll_l1_ (u"ࠧࡘࡇࡅࡣࡊࡓࡂࡆࡆࡇࡉࡉࡥࡐࡍࡃ࡜ࡉࡗ࠭夝"),l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ夞"): l11lll_l1_ (u"ࠩ࠴࠲࠷࠶࠲࠳࠲࠺࠷࠶࠴࠰࠱࠰࠳࠴ࠬ够")
	# l11lll11l111_l1_:	l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ夠"): l11lll_l1_ (u"ࠫࡆࡔࡄࡓࡑࡌࡈࡤࡋࡍࡃࡇࡇࡈࡊࡊ࡟ࡑࡎࡄ࡝ࡊࡘࠧ夡"),l11lll_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ夢"): l11lll_l1_ (u"࠭࠱࠸࠰࠶࠵࠳࠹࠵ࠨ夣")
	# l11lll11l111_l1_:	l11lll_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ夤"): l11lll_l1_ (u"ࠨࡃࡑࡈࡗࡕࡉࡅࡡࡐ࡙ࡘࡏࡃࠨ夥"),l11lll_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ夦"): l11lll_l1_ (u"ࠪ࠹࠳࠷࠶࠯࠷࠴ࠫ大")
	# l11lll11l111_l1_:	l11lll_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ夨"): l11lll_l1_ (u"࡚ࠬࡖࡉࡖࡐࡐ࠺ࡥࡓࡊࡏࡓࡐ࡞ࡥࡅࡎࡄࡈࡈࡉࡋࡄࡠࡒࡏࡅ࡞ࡋࡒࠨ天"),l11lll_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭太"): l11lll_l1_ (u"ࠧ࠳࠰࠳ࠫ夫")
	# l11lll11l111_l1_:	l11lll_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ夬"): l11lll_l1_ (u"ࠩࡌࡓࡘࡥࡍࡖࡕࡌࡇࠬ夭"),l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ央"): l11lll_l1_ (u"ࠫ࠺࠴࠲࠲ࠩ夯")
	# l11l11l_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭夰")][0]+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡶ࡬ࡢࡻࡨࡶࡄࡶࡲࡦࡶࡷࡽࡕࡸࡩ࡯ࡶࡀࡸࡷࡻࡥࠨ失")  # l11111ll1l11_l1_ l1ll1l1ll1ll_l1_ l11111ll11ll_l1_ and l1111lll11ll_l1_ l1ll11ll111l_l1_ l1l1l1ll1l_l1_ l1111l1ll1l1_l1_ file size
	#l11llll11_l1_ = l11lll_l1_ (u"ࠧࡼࠩ夲")l111111l1lll_l1_ (u"ࠨ࠼࡬ࡨ࠱࠭夳")l111ll11l1ll_l1_ (u"ࠩ࠽ࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࡻࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠢࡂࡐࡇࡖࡔࡏࡄࠣ࠮ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠧ࠷࠷࠯࠵࠴࠲࠸࠻ࠢࡾࡿࢀࠫ头")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ夵"),l11l11l_l1_,l11llll11_l1_,l11lll_l1_ (u"ࠫࠬ夶"),l11lll_l1_ (u"ࠬ࠭夷"),l11lll_l1_ (u"࠭ࠧ夸"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨ夹"))
	#html = response.content
	for l11l1lllll_l1_ in range(5):
		#DIALOG_NOTIFICATION(l11lll_l1_ (u"ࠨษ็้าอ่ๅหࠣี็๋࠺ࠡࠢࠪ夺")+str(l11l1lllll_l1_+1),l11lll_l1_ (u"ࠩࠪ夻"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ夼"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ夽"),l11lll_l1_ (u"ࠬ࠭夾"),l11lll_l1_ (u"࠭ࠧ夿"),l11lll_l1_ (u"ࠧࠨ奀"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩ奁"))
		html = response.content
		if l11lll_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ奂") in html: break
		time.sleep(2)
	#WRITE_THIS(l11lll_l1_ (u"ࠪࠫ奃"),html)
	l11lll111l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ奄"),html,re.DOTALL)
	if l11lll111l_l1_: l11lll111l_l1_ = l11lll111l_l1_[0]
	else: l11lll111l_l1_ = html
	l11lll111l_l1_ = l11lll111l_l1_.replace(l11lll_l1_ (u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭奅"),l11lll_l1_ (u"࠭ࠦࠨ奆"))
	l1111ll1l1l1_l1_ = EVAL(l11lll_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ奇"),l11lll111l_l1_)
	#WRITE_THIS(l11lll_l1_ (u"ࠨࠩ奈"),str(l1111ll1l1l1_l1_))
	# l1111l111lll_l1_ l11l11l1llll_l1_ & l11ll111ll1l_l1_
	# l1ll1llll_l1_ l11l111lll11_l1_ link l1l111l1l_l1_ l11lll_l1_ (u"ࠩࠩࡪࡲࡺ࠽ࡷࡶࡷࠫ奉") to l111l11lll_l1_ on l1111ll1l1l_l1_
	l1lll1ll_l1_,l1111_l1_ = [l11lll_l1_ (u"ࠪฬิ๎ๆࠡฬิะ๊ฯ๋๊ࠠอ๎ํฮࠧ奊")],[l11lll_l1_ (u"ࠫࠬ奋")]
	try:
		l11l11l1llll_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠬࡩࡡࡱࡶ࡬ࡳࡳࡹࠧ奌")][l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡉࡡࡱࡶ࡬ࡳࡳࡹࡔࡳࡣࡦ࡯ࡱ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ奍")][l11lll_l1_ (u"ࠧࡤࡣࡳࡸ࡮ࡵ࡮ࡕࡴࡤࡧࡰࡹࠧ奎")]
		for l11l11111111_l1_ in l11l11l1llll_l1_:
			link = l11l11111111_l1_[l11lll_l1_ (u"ࠨࡤࡤࡷࡪ࡛ࡲ࡭ࠩ奏")]
			try: title = l11l11111111_l1_[l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ奐")][l11lll_l1_ (u"ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ契")]
			except: title = l11l11111111_l1_[l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ奒")][l11lll_l1_ (u"ࠬࡸࡵ࡯ࡵࠪ奓")][0][l11lll_l1_ (u"࠭ࡴࡦࡺࡷࠫ奔")]
			l1111_l1_.append(link)
			l1lll1ll_l1_.append(title)
	except: pass
	if len(l1lll1ll_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥอไหำฯ้ฮࠦวๅ็้หุฮษ࠻ࠩ奕"), l1lll1ll_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭奖"),[],[]
		elif l1l_l1_!=0:
			link = l1111_l1_[l1l_l1_]+l11lll_l1_ (u"ࠩࠩࠫ套")
			l111l11lllll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠪ࠭࡬࡭ࡵ࠿࠱࠮ࡄ࠯ࠦࠨ奘"),link)
			if l111l11lllll_l1_: link = link.replace(l111l11lllll_l1_[0],l11lll_l1_ (u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬ奙"))
			else: link = link+l11lll_l1_ (u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭奚")
			l111ll1lll11_l1_ = link.strip(l11lll_l1_ (u"࠭ࠦࠨ奛"))
	formats,l11ll111l1ll_l1_,l11l1l11l11l_l1_,l11l1l11l1l1_l1_,l11l1l11l111_l1_ = [],[],[],[],[]
	# l1111l111lll_l1_ l111lll111ll_l1_ l1ll111l1l1l_l1_
	try: l11111ll1111_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ奜")][l11lll_l1_ (u"ࠨࡦࡤࡷ࡭ࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪ奝")]
	except: pass
	# l1111l111lll_l1_ l11l111ll111_l1_ stream
	try: l11ll11ll111_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ奞")][l11lll_l1_ (u"ࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ奟")]
	except: pass
	# l1111l111lll_l1_ l1ll1l11ll_l1_ l1111lll_l1_ l1ll111l1l1l_l1_
	try: formats = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫ奠")][l11lll_l1_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭奡")]
	except: pass
	# l1111l111lll_l1_ l1ll1l11ll_l1_ l11ll11l11l1_l1_ l1ll111l1l1l_l1_
	try: l11ll111l1ll_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭奢")][l11lll_l1_ (u"ࠧࡢࡦࡤࡴࡹ࡯ࡶࡦࡈࡲࡶࡲࡧࡴࡴࠩ奣")]
	except: pass
	l11l111l1l11_l1_ = formats+l11ll111l1ll_l1_
	for dict in l11l111l1l11_l1_:
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ奤"),str(dict))
		if l11lll_l1_ (u"ࠩ࡬ࡸࡦ࡭ࠧ奥") in list(dict.keys()): dict[l11lll_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ奦")] = str(dict[l11lll_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ奧")])
		if l11lll_l1_ (u"ࠬ࡬ࡰࡴࠩ奨") in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡦࡱࡵࠪ奩")] = str(dict[l11lll_l1_ (u"ࠧࡧࡲࡶࠫ奪")])
		if l11lll_l1_ (u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪ奫") in list(dict.keys()): dict[l11lll_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ奬")] = dict[l11lll_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ奭")]		#.replace(l11lll_l1_ (u"ࠫࡂ࠭奮"),l11lll_l1_ (u"ࠬࡃࠧ奯"))+l11lll_l1_ (u"࠭ࠢࠨ奰")
		if l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࡙ࡡ࡮ࡲ࡯ࡩࡗࡧࡴࡦࠩ奱") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩࠬ奲")] = str(dict[l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ女")])
		if l11lll_l1_ (u"ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ奴") in list(dict.keys()): dict[l11lll_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ奵")] = str(dict[l11lll_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ奶")])
		if l11lll_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ奷") in list(dict.keys()): dict[l11lll_l1_ (u"ࠧࡴ࡫ࡽࡩࠬ奸")] = str(dict[l11lll_l1_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ她")])+l11lll_l1_ (u"ࠩࡻࠫ奺")+str(dict[l11lll_l1_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ奻")])
		if l11lll_l1_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ奼") in list(dict.keys()): dict[l11lll_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ好")] = dict[l11lll_l1_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ奾")][l11lll_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭奿")]+l11lll_l1_ (u"ࠨ࠯ࠪ妀")+dict[l11lll_l1_ (u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ妁")][l11lll_l1_ (u"ࠪࡩࡳࡪࠧ如")]
		if l11lll_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ妃") in list(dict.keys()): dict[l11lll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࠫ妄")] = dict[l11lll_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ妅")][l11lll_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭妆")]+l11lll_l1_ (u"ࠨ࠯ࠪ妇")+dict[l11lll_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭妈")][l11lll_l1_ (u"ࠪࡩࡳࡪࠧ妉")]
		if l11lll_l1_ (u"ࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬ妊") in list(dict.keys()): dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭妋")] = dict[l11lll_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ妌")]
		if l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ妍") in list(dict.keys()) and int(dict[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ妎")])>111222333: del dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ妏")]
		if l11lll_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬ妐") in list(dict.keys()):
			cipher = dict[l11lll_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭妑")].split(l11lll_l1_ (u"ࠬࠬࠧ妒"))
			for item in cipher:
				key,value = item.split(l11lll_l1_ (u"࠭࠽ࠨ妓"),1)
				dict[key] = l111l_l1_(value)
		if l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ妔") in list(dict.keys()): dict[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ妕")] = l111l_l1_(dict[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭妖")])
		#if l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࡀࠫ妗") in dict[l11lll_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭妘")]: dict[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ妙")] = dict[l11lll_l1_ (u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨ妚")].split(l11lll_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹ࠽࡝ࠤࠪ妛"))[1].strip(l11lll_l1_ (u"ࠨ࡞ࠥࠫ妜"))
		#LOG_THIS(l11lll_l1_ (u"ࠩࠪ妝"),dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥࠨ妞")]+l11lll_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤࠬ妟")+dict[l11lll_l1_ (u"ࠬࡺࡹࡱࡧࠪ妠")])
		l11l1l11l11l_l1_.append(dict)
	l11ll1ll1_l1_ = l11lll_l1_ (u"࠭ࠧ妡")
	if l11lll_l1_ (u"ࠧࡴࡲࡀࡷ࡮࡭ࠧ妢") in l11lll111l_l1_:
		#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠰ࡻࡷࡷ࠴ࡰࡳࡣ࡫ࡱ࠳ࡵࡲࡡࡺࡧࡵࡣ࠳࠰࠿ࠪࠤࠪ妣"),html,re.DOTALL)
		# l11l1l1l11ll_l1_:	/s/l11ll111lll_l1_/6dde7fb4/l1111l1ll111_l1_.l111ll111l1l_l1_/l111lll11lll_l1_/base.l1111l1l1l11_l1_
		#l1111l1llll1_l1_ = [l11lll_l1_ (u"ࠩ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡪ࠸࠸ࡦ࠸࠼࠶࡬࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟ࡖࡕ࠲ࡦࡦࡹࡥ࠯࡬ࡶࠫ妤")]
		l1111l1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠲ࡷ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡢࡷࠫࡁ࠲ࡴࡱࡧࡹࡦࡴࡢ࡭ࡦࡹ࠮ࡷࡨ࡯ࡷࡪࡺ࠯ࡦࡰࡢ࠲࠳࠵ࡢࡢࡵࡨ࠲࡯ࡹࠩࠣࠩ妥"),html,re.DOTALL)
		if l1111l1llll1_l1_:
			l1111l1llll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ妦")][0]+l1111l1llll1_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ妧"),l1111l1llll1_l1_,l11lll_l1_ (u"࠭ࠧ妨"),l11lll_l1_ (u"ࠧࠨ妩"),l11lll_l1_ (u"ࠨࠩ妪"),l11lll_l1_ (u"ࠩࠪ妫"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠳ࡰࡧࠫ妬"))
			l11ll1ll1_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1111l11ll11_l1_ = cipher._load_javascript(l11ll1ll1_l1_)
			l11111l1llll_l1_ = EVAL(l11lll_l1_ (u"ࠫࡸࡺࡲࠨ妭"),str(l1111l11ll11_l1_))
			l111l11111l1_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l11111l1llll_l1_)
	for dict in l11l1l11l11l_l1_:
		url = dict[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ妮")]
		if l11lll_l1_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠿ࠪ妯") in url or url.count(l11lll_l1_ (u"ࠧࡴ࡫ࡪࡁࠬ妰"))>1:
			l11l1l11l1l1_l1_.append(dict)
		elif l11ll1ll1_l1_ and l11lll_l1_ (u"ࠨࡵࠪ妱") in list(dict.keys()) and l11lll_l1_ (u"ࠩࡶࡴࠬ妲") in list(dict.keys()):
			l111lllllll1_l1_ = l111l11111l1_l1_.execute(dict[l11lll_l1_ (u"ࠪࡷࠬ妳")])
			if l111lllllll1_l1_!=dict[l11lll_l1_ (u"ࠫࡸ࠭妴")]:
				dict[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ妵")] = url+l11lll_l1_ (u"࠭ࠦࠨ妶")+dict[l11lll_l1_ (u"ࠧࡴࡲࠪ妷")]+l11lll_l1_ (u"ࠨ࠿ࠪ妸")+l111lllllll1_l1_
				l11l1l11l1l1_l1_.append(dict)
	for dict in l11l1l11l1l1_l1_:
		l1l1111_l1_,l1111ll1l1ll_l1_,l1111ll1llll_l1_,l11lllll1_l1_,codecs,l111ll111ll_l1_ = l11lll_l1_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ妹"),l11lll_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ妺"),l11lll_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ妻"),l11lll_l1_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭妼"),l11lll_l1_ (u"࠭ࠧ妽"),l11lll_l1_ (u"ࠧ࠱ࠩ妾")
		try:
			l11l1l11l1ll_l1_ = dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠭妿")]
			l11l1l11l1ll_l1_ = l11l1l11l1ll_l1_.replace(l11lll_l1_ (u"ࠩ࠮ࠫ姀"),l11lll_l1_ (u"ࠪࠫ姁"))
			items = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪ࠽࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭姂"),l11l1l11l1ll_l1_,re.DOTALL)
			l11lllll1_l1_,l1l1111_l1_,codecs = items[0]
			l11ll11111l1_l1_ = codecs.split(l11lll_l1_ (u"ࠬ࠲ࠧ姃"))
			l1111ll1l1ll_l1_ = l11lll_l1_ (u"࠭ࠧ姄")
			for item in l11ll11111l1_l1_: l1111ll1l1ll_l1_ += item.split(l11lll_l1_ (u"ࠧ࠯ࠩ姅"))[0]+l11lll_l1_ (u"ࠨ࠮ࠪ姆")
			l1111ll1l1ll_l1_ = l1111ll1l1ll_l1_.strip(l11lll_l1_ (u"ࠩ࠯ࠫ姇"))
			if l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ姈") in list(dict.keys()): l111ll111ll_l1_ = str(float(dict[l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ姉")]*10)//1024/10)+l11lll_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ姊")
			else: l111ll111ll_l1_ = l11lll_l1_ (u"࠭ࠧ始")
			if l11lllll1_l1_==l11lll_l1_ (u"ࠧࡵࡧࡻࡸࠬ姌"): continue
			elif l11lll_l1_ (u"ࠨ࠮ࠪ姍") in l11l1l11l1ll_l1_:
				l11lllll1_l1_ = l11lll_l1_ (u"ࠩࡄ࠯࡛࠭姎")
				l1111ll1llll_l1_ = l1l1111_l1_+l11lll_l1_ (u"ࠪࠤࠥ࠭姏")+l111ll111ll_l1_+dict[l11lll_l1_ (u"ࠫࡸ࡯ࡺࡦࠩ姐")].split(l11lll_l1_ (u"ࠬࡾࠧ姑"))[1]
			elif l11lllll1_l1_==l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ姒"):
				l11lllll1_l1_ = l11lll_l1_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭姓")
				l1111ll1llll_l1_ = l111ll111ll_l1_+dict[l11lll_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭委")].split(l11lll_l1_ (u"ࠩࡻࠫ姕"))[1]+l11lll_l1_ (u"ࠪࠤࠥ࠭姖")+dict[l11lll_l1_ (u"ࠫ࡫ࡶࡳࠨ姗")]+l11lll_l1_ (u"ࠬ࡬ࡰࡴࠩ姘")+l11lll_l1_ (u"࠭ࠠࠡࠩ姙")+l1l1111_l1_
			elif l11lllll1_l1_==l11lll_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭姚"):
				l11lllll1_l1_ = l11lll_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ姛")
				l1111ll1llll_l1_ = l111ll111ll_l1_+str(int(dict[l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭姜")])/1000)+l11lll_l1_ (u"ࠪ࡯࡭ࢀࠠࠡࠩ姝")+dict[l11lll_l1_ (u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ姞")]+l11lll_l1_ (u"ࠬࡩࡨࠨ姟")+l11lll_l1_ (u"࠭ࠠࠡࠩ姠")+l1l1111_l1_
		except:
			l1llll1111l1_l1_ = traceback.format_exc()
			sys.stderr.write(l1llll1111l1_l1_)
		if l11lll_l1_ (u"ࠧࡥࡷࡵࡁࠬ姡") in dict[l11lll_l1_ (u"ࠨࡷࡵࡰࠬ姢")]: l1l111l1ll_l1_ = round(0.5+float(dict[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭姣")].split(l11lll_l1_ (u"ࠪࡨࡺࡸ࠽ࠨ姤"),1)[1].split(l11lll_l1_ (u"ࠫࠫ࠭姥"),1)[0]))
		elif l11lll_l1_ (u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨ姦") in list(dict.keys()): l1l111l1ll_l1_ = round(0.5+float(dict[l11lll_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ姧")])/1000)
		else: l1l111l1ll_l1_ = l11lll_l1_ (u"ࠧ࠱ࠩ姨")
		if l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ姩") not in list(dict.keys()): l111ll111ll_l1_ = dict[l11lll_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ姪")].split(l11lll_l1_ (u"ࠪࡼࠬ姫"))[1]
		else: l111ll111ll_l1_ = dict[l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ姬")]
		if l11lll_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ姭") not in list(dict.keys()): dict[l11lll_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ姮")] = l11lll_l1_ (u"ࠧ࠱࠯࠳ࠫ姯")
		dict[l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ姰")] = l11lllll1_l1_+l11lll_l1_ (u"ࠩ࠽ࠤࠥ࠭姱")+l1111ll1llll_l1_+l11lll_l1_ (u"ࠪࠤࠥ࠮ࠧ姲")+l1111ll1l1ll_l1_+l11lll_l1_ (u"ࠫ࠱࠭姳")+dict[l11lll_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ姴")]+l11lll_l1_ (u"࠭ࠩࠨ姵")
		dict[l11lll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ姶")] = l1111ll1llll_l1_.split(l11lll_l1_ (u"ࠨࠢࠣࠫ姷"))[0].split(l11lll_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ姸"))[0]
		dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ姹")] = l11lllll1_l1_
		dict[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭姺")] = l1l1111_l1_
		dict[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ姻")] = codecs
		dict[l11lll_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ姼")] = l1l111l1ll_l1_
		dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ姽")] = l111ll111ll_l1_
		l11l1l11l111_l1_.append(dict)
	l11l111l111l_l1_,l11l1ll11l1l_l1_,l11ll11l11ll_l1_,l111ll11ll11_l1_,l11l11ll1ll1_l1_ = [],[],[],[],[]
	l111l1lll1l1_l1_,l11l1l1l111l_l1_,l111l1l11ll1_l1_,l11ll1111111_l1_,l11ll111lll1_l1_ = [],[],[],[],[]
	if l11111ll1111_l1_:
		dict = {}
		dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ姾")] = l11lll_l1_ (u"ࠩࡄ࠯࡛࠭姿")
		dict[l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ娀")] = l11lll_l1_ (u"ࠫࡲࡶࡤࠨ威")
		dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ娂")] = dict[l11lll_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ娃")]+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ娄")+dict[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ娅")]+l11lll_l1_ (u"ࠩࠣࠤࠬ娆")+l11lll_l1_ (u"ࠪะํีษࠡาๆ๎ฮ࠭娇")
		dict[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ娈")] = l11111ll1111_l1_
		dict[l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭娉")] = l11lll_l1_ (u"࠭࠰ࠨ娊") # for l11l1l111l_l1_ l11111ll1111_l1_ any l1l1l111l_l1_ will l11l11llll11_l1_ l1llll111ll_l1_ sort l1l11l1llll_l1_
		dict[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ娋")] = l11lll_l1_ (u"ࠨ࠻࠻࠻࠻࠻࠴࠴࠴࠴࠴ࠬ娌") # 20
		l11l1l11l111_l1_.append(dict)
	if l11ll11ll111_l1_:
		l11l11ll1lll_l1_,l11l1l1lll1l_l1_ = l11ll11l11_l1_(l11ll11ll111_l1_)
		l11l1lll11l1_l1_ = list(zip(l11l11ll1lll_l1_,l11l1l1lll1l_l1_))
		for title,link in l11l1lll11l1_l1_:
			dict = {}
			dict[l11lll_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ娍")] = l11lll_l1_ (u"ࠪࡅ࠰࡜ࠧ娎")
			dict[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭娏")] = l11lll_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ娐")
			dict[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ娑")] = link
			#if l11lll_l1_ (u"ࠧࡃ࡙࠽ࠤࠬ娒") in title: dict[l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ娓")] = title.split(l11lll_l1_ (u"ࠩࠣࠤࠬ娔"))[1].split(l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ娕"))[0]
			#if l11lll_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ娖") in title: dict[l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭娗")] = title.split(l11lll_l1_ (u"࠭ࡒࡦࡵ࠽ࠤࠬ娘"))[1]
			# title = l11lll_l1_ (u"ࠢ࠵࠴࠹࠻ࡰࡨࡰࡴࠢࠣ࠻࠷࠶ࠠࠡ࠰ࡰ࠷ࡺ࠾ࠢ娙")
			if l11lll_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭娚") in title: dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ娛")] = title.split(l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ娜"))[0].rsplit(l11lll_l1_ (u"ࠫࠥࠦࠧ娝"))[-1]
			else: dict[l11lll_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭娞")] = l11lll_l1_ (u"࠭࠱࠱ࠩ娟")
			if title.count(l11lll_l1_ (u"ࠧࠡࠢࠪ娠"))>1:
				l11l111l_l1_ = title.rsplit(l11lll_l1_ (u"ࠨࠢࠣࠫ娡"))[-3]
				if l11l111l_l1_.isdigit(): dict[l11lll_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ娢")] = l11l111l_l1_
				else: dict[l11lll_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ娣")] = l11lll_l1_ (u"ࠫ࠵࠶࠰࠱ࠩ娤")
			#dict[l11lll_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭娥")] = title
			if title==l11lll_l1_ (u"࠭࠭࠲ࠩ娦"): dict[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭娧")] = dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ娨")]+l11lll_l1_ (u"ࠩ࠽ࠤࠥ࠭娩")+dict[l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ娪")]+l11lll_l1_ (u"ࠫࠥࠦࠧ娫")+l11lll_l1_ (u"ࠬา่ะหࠣิ่๐ษࠨ娬")
			else: dict[l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ娭")] = dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭娮")]+l11lll_l1_ (u"ࠨ࠼ࠣࠤࠬ娯")+dict[l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ娰")]+l11lll_l1_ (u"ࠪࠤࠥ࠭娱")+dict[l11lll_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ娲")]+l11lll_l1_ (u"ࠬࡱࡢࡱࡵࠣࠤࠬ娳")+dict[l11lll_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ娴")]
			l11l1l11l111_l1_.append(dict)
	l11l1l11l111_l1_ = sorted(l11l1l11l111_l1_,reverse=True,key=lambda key: float(key[l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ娵")]))
	if not l11l1l11l111_l1_:
		l1l1ll11ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ娶"),html,re.DOTALL)
		l1l1ll11lll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ娷"),html,re.DOTALL)
		l11l1111ll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ娸"),html,re.DOTALL)
		l11l1111ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭娹"),html,re.DOTALL)
		try: l11l1111lll1_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ娺")][l11lll_l1_ (u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ娻")][l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ娼")][l11lll_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ娽")][l11lll_l1_ (u"ࠩࡵࡹࡳࡹࠧ娾")][0][l11lll_l1_ (u"ࠪࡸࡪࡾࡴࠨ娿")]
		except: l11l1111lll1_l1_ = l11lll_l1_ (u"ࠫࠬ婀")
		try: l11l1111llll_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ婁")][l11lll_l1_ (u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫ婂")][l11lll_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ婃")][l11lll_l1_ (u"ࠨࡦ࡬ࡥࡱࡵࡧࡎࡧࡶࡷࡦ࡭ࡥࡴࠩ婄")][0][l11lll_l1_ (u"ࠩࡵࡹࡳࡹࠧ婅")][0][l11lll_l1_ (u"ࠪࡸࡪࡾࡴࠨ婆")]
		except: l11l1111llll_l1_ = l11lll_l1_ (u"ࠫࠬ婇")
		try: l111l111111l_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ婈")][l11lll_l1_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭婉")]
		except: l111l111111l_l1_ = l11lll_l1_ (u"ࠧࠨ婊")
		if l1l1ll11ll1_l1_ or l1l1ll11lll_l1_ or l11l1111ll11_l1_ or l11l1111ll1l_l1_ or l11l1111lll1_l1_ or l11l1111llll_l1_ or l111l111111l_l1_:
			if   l1l1ll11ll1_l1_: message = l1l1ll11ll1_l1_[0]
			elif l1l1ll11lll_l1_: message = l1l1ll11lll_l1_[0]
			elif l11l1111ll11_l1_: message = l11l1111ll11_l1_[0]
			elif l11l1111ll1l_l1_: message = l11l1111ll1l_l1_[0]
			elif l11l1111lll1_l1_: message = l11l1111lll1_l1_
			elif l11l1111llll_l1_: message = l11l1111llll_l1_
			elif l111l111111l_l1_: message = l111l111111l_l1_
			l111l11ll1ll_l1_ = message.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫ婋"),l11lll_l1_ (u"ࠩࠪ婌")).strip(l11lll_l1_ (u"ࠪࠤࠬ婍"))
			l11l11l1l1l1_l1_ = l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ัษࠣห้็๊ะ์๋ࠤๆ๐็ࠡ็ื็้ฯ้ࠠไาࠤ๏้่็ࠢ฽๎ึࠦๅๅษษ้๊ࠥศฺุࠣห้๋ำหะา้๏์ࠠฤ๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้࡟࠴ࡉࡏࡍࡑࡕࡡࠬ婎")
			DIALOG_OK(l11lll_l1_ (u"ࠬ࠭婏"),l11lll_l1_ (u"࠭ࠧ婐"),l11lll_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺ๋ࠢห้๋ศา็ฯࠫ婑"),l11l11l1l1l1_l1_+l11lll_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭婒")+l111l11ll1ll_l1_)
			return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠫ婓")+l111l11ll1ll_l1_,[],[]
		else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ婔"),[],[]
	l111l11111ll_l1_,l111111llll1_l1_,l111lllll1l1_l1_ = [],[],[]
	for dict in l11l1l11l111_l1_:
		if dict[l11lll_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ婕")]==l11lll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ婖"):
			l11l111l111l_l1_.append(dict[l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ婗")])
			l111l1lll1l1_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭婘")]==l11lll_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ婙"):
			l11l1ll11l1l_l1_.append(dict[l11lll_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ婚")])
			l11l1l1l111l_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ婛")]==l11lll_l1_ (u"ࠫࡲࡶࡤࠨ婜"):
			title = dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ婝")].replace(l11lll_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭婞"),l11lll_l1_ (u"ࠧࠨ婟"))
			if l11lll_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ婠") not in list(dict.keys()): l111ll111ll_l1_ = l11lll_l1_ (u"ࠩ࠳ࠫ婡")
			else: l111ll111ll_l1_ = dict[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ婢")]
			l111l11111ll_l1_.append([dict,{},title,l111ll111ll_l1_])
		else:
			title = dict[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ婣")].replace(l11lll_l1_ (u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ婤"),l11lll_l1_ (u"࠭ࠧ婥"))
			if l11lll_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ婦") not in list(dict.keys()): l111ll111ll_l1_ = l11lll_l1_ (u"ࠨ࠲ࠪ婧")
			else: l111ll111ll_l1_ = dict[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ婨")]
			l111l11111ll_l1_.append([dict,{},title,l111ll111ll_l1_])
			l11ll11l11ll_l1_.append(title)
			l111l1l11ll1_l1_.append(dict)
		l11l1lll1l1l_l1_ = True
		if l11lll_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ婩") in list(dict.keys()):
			if l11lll_l1_ (u"ࠫࡦࡼ࠰ࠨ婪") in dict[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ婫")]: l11l1lll1l1l_l1_ = False
			elif kodi_version<18:
				if l11lll_l1_ (u"࠭ࡡࡷࡥࠪ婬") not in dict[l11lll_l1_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ婭")] and l11lll_l1_ (u"ࠨ࡯ࡳ࠸ࡦ࠭婮") not in dict[l11lll_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ婯")]: l11l1lll1l1l_l1_ = False
		if dict[l11lll_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ婰")]==l11lll_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ婱") and dict[l11lll_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ婲")]!=l11lll_l1_ (u"࠭࠰࠮࠲ࠪ婳") and l11l1lll1l1l_l1_==True:
			l11l11ll1ll1_l1_.append(dict[l11lll_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭婴")])
			l11ll111lll1_l1_.append(dict)
		elif dict[l11lll_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ婵")]==l11lll_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ婶") and dict[l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ婷")]!=l11lll_l1_ (u"ࠫ࠵࠳࠰ࠨ婸") and l11l1lll1l1l_l1_==True:
			l111ll11ll11_l1_.append(dict[l11lll_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ婹")])
			l11ll1111111_l1_.append(dict)
		#LOG_THIS(l11lll_l1_ (u"࠭ࠧ婺"),l11lll_l1_ (u"ࠧࠬ࠭࠮࠯࠰࠱ࠫࠡࠢࠣࠫ婻")+dict[l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ婼")])
	for l11l1ll1ll11_l1_ in l11ll1111111_l1_:
		l111ll11llll_l1_ = l11l1ll1ll11_l1_[l11lll_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ婽")]
		for l11l11111lll_l1_ in l11ll111lll1_l1_:
			l1111lll11l1_l1_ = l11l11111lll_l1_[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ婾")]
			l111ll111ll_l1_ = l1111lll11l1_l1_+l111ll11llll_l1_
			title = l11l11111lll_l1_[l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ婿")].replace(l11lll_l1_ (u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧ媀"),l11lll_l1_ (u"࠭࡭ࡱࡦࠣࠤࠬ媁"))
			title = title.replace(l11l11111lll_l1_[l11lll_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ媂")]+l11lll_l1_ (u"ࠨࠢࠣࠫ媃"),l11lll_l1_ (u"ࠩࠪ媄"))
			title = title.replace(str((float(l1111lll11l1_l1_*10)//1024/10))+l11lll_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ媅"),str((float(l111ll111ll_l1_*10)//1024/10))+l11lll_l1_ (u"ࠫࡰࡨࡰࡴࠩ媆"))
			title = title+l11lll_l1_ (u"ࠬ࠮ࠧ媇")+l11l1ll1ll11_l1_[l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ媈")].split(l11lll_l1_ (u"ࠧࠩࠩ媉"),1)[1]
			l111l11111ll_l1_.append([l11l11111lll_l1_,l11l1ll1ll11_l1_,title,l111ll111ll_l1_])
	l111l11111ll_l1_ = sorted(l111l11111ll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l11l11111lll_l1_,l11l1ll1ll11_l1_,title,l111ll111ll_l1_ in l111l11111ll_l1_:
		l11l1l111l1l_l1_ = l11l11111lll_l1_[l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ媊")]
		if l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ媋") in list(l11l1ll1ll11_l1_.keys()):
			l11l1l111l1l_l1_ = l11lll_l1_ (u"ࠪࡱࡵࡪࠧ媌")
			#l11l1l111l1l_l1_ = l11l1l111l1l_l1_+l11l1ll1ll11_l1_[l11lll_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭媍")]
		if l11l1l111l1l_l1_ not in l111lllll1l1_l1_:
			l111lllll1l1_l1_.append(l11l1l111l1l_l1_)
			l111111llll1_l1_.append([l11l11111lll_l1_,l11l1ll1ll11_l1_,title,l111ll111ll_l1_])
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭媎"),str(l111ll111ll_l1_)+l11lll_l1_ (u"࠭ࠠࠡࠢࠪ媏")+title)
	#l111111llll1_l1_ = sorted(l111111llll1_l1_, reverse=True, key=lambda key: int(key[3]))
	l111l1111111_l1_,l111ll111l11_l1_,shift = [],[],0
	l11lll_l1_ (u"ࠢࠣࠤࠍࠍࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣࡳࡼࡴࡥࡳ࠼ࠍࠍࠎࡹࡨࡪࡨࡷࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ࠯ࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠰࡞࠭ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡࡱࡺࡲࡪࡸ࡛࠱࡟࡞࠵ࡢࠐࠉࠊࡵࡨࡰࡪࡩࡴࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࡩࡵ࡮ࡨ࠭ࠏࠏࠉࡤࡪࡲ࡭ࡨ࡫ࡍࡦࡰࡸ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠧࠨࠢ媐")
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࡵࡷ࡯ࡧࡵࡣࡨ࡮ࡡ࡯ࡰࡨࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡣࡩࡣࡱࡲࡪࡲࡉࡥࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯ࡣ࡯ࡹ࡯࡯࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡧࡵࡵࡪࡲࡶࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲ࡟࡫ࡵࡲࡲ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡯ࡸࡰࡨࡶࡤࡴࡡ࡮ࡧ࠽ࠎࠎࠏࡩ࡮ࡣࡪࡩࡸࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠦ࠭࠴ࠪࡀࠫࠥࡥࡱࡲ࡯ࡸࡔࡤࡸ࡮ࡴࡧࡴࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡮ࡳࡡࡨࡧࡶࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࠊ࡫ࡰࡥ࡬࡫ࡳࡠࡷࡵࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌ࡭࡫ࠦࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮࠽ࠤ࡮ࡳࡡࡨࡧࠣࡁࠥ࡯࡭ࡢࡩࡨࡷࡤࡻࡲ࡭࡝࠰࠵ࡢࠐࠉࠊࡱࡺࡲࡪࡸࠠ࠾ࠢࡲࡻࡳ࡫ࡲࡠࡰࡤࡱࡪࡡ࠰࡞ࠌࠌࠍࡸ࡮ࡩࡧࡶࠣ࠯ࡂࠦ࠱ࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ࠮ࡳࡼࡴࡥࡳ࠭ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽࡙ࠡࡈࡆࡘࡏࡔࡆࡕ࡞ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬࡣ࡛࠱࡟࠮ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧࠬࡱࡺࡲࡪࡸ࡟ࡤࡪࡤࡲࡳ࡫࡬࡜࠲ࡠࠎࠎࠏࡳࡦ࡮ࡨࡧࡹࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡩࡨࡰ࡫ࡦࡩࡒ࡫࡮ࡶ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ媑")
	l11l1lll1lll_l1_,l11l11lllll1_l1_ = l11lll_l1_ (u"ࠩࠪ媒"),l11lll_l1_ (u"ࠪࠫ媓")
	try: l11l1lll1lll_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ媔")][l11lll_l1_ (u"ࠬࡧࡵࡵࡪࡲࡶࠬ媕")]
	except: l11l1lll1lll_l1_ = l11lll_l1_ (u"࠭ࠧ媖")
	try: l111l11lll11_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭媗")][l11lll_l1_ (u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫ媘")]
	except: l111l11lll11_l1_ = l11lll_l1_ (u"ࠩࠪ媙")
	if l11l1lll1lll_l1_ and l111l11lll11_l1_:
		shift += 1
		title = l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡕࡗࡏࡇࡕ࠾ࠥࠦࠧ媚")+l11l1lll1lll_l1_+l11lll_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭媛")
		link = l1ll11l_l1_[l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭媜")][0]+l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩ媝")+l111l11lll11_l1_
		l111l1111111_l1_.append(title)
		l111ll111l11_l1_.append(link)
		try: l11l11lllll1_l1_ = l1111ll1l1l1_l1_[l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭媞")][l11lll_l1_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ媟")][l11lll_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭媠")][-1][l11lll_l1_ (u"ࠪࡹࡷࡲࠧ媡")]
		except: pass
	#if l11111ll1111_l1_:
	#	shift += 1
	#	l111l1111111_l1_.append(l11lll_l1_ (u"ࠫࡲࡶࡤࠡฮ๋ำฮࠦะไ์ฬࠫ媢")) ; l111ll111l11_l1_.append(l11lll_l1_ (u"ࠬࡪࡡࡴࡪࠪ媣"))
	for l11l11111lll_l1_,l11l1ll1ll11_l1_,title,l111ll111ll_l1_ in l111111llll1_l1_:
		l111l1111111_l1_.append(title) ; l111ll111l11_l1_.append(l11lll_l1_ (u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧ媤"))
	if l11ll11l11ll_l1_: l111l1111111_l1_.append(l11lll_l1_ (u"ࠧึ๊ิอࠥ๎ี้ฬ้ࠣาีฯสࠩ媥")) ; l111ll111l11_l1_.append(l11lll_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ媦"))
	if l111l11111ll_l1_: l111l1111111_l1_.append(l11lll_l1_ (u"ุࠩ์ึฯ้ࠠื๋ฮࠥอไๆฬ๋ๅึ࠭媧")) ; l111ll111l11_l1_.append(l11lll_l1_ (u"ࠪࡥࡱࡲࠧ媨"))
	if l11l11ll1ll1_l1_: l111l1111111_l1_.append(l11lll_l1_ (u"ࠫࡲࡶࡤࠡษัฮึࠦวๅื๋ีฮ่ࠦศๆุ์ฯ࠭媩")) ; l111ll111l11_l1_.append(l11lll_l1_ (u"ࠬࡳࡰࡥࠩ媪"))
	if l11l111l111l_l1_: l111l1111111_l1_.append(l11lll_l1_ (u"࠭ี้ำฬࠤอี่็ุࠢ์ฯ࠭媫")) ; l111ll111l11_l1_.append(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭媬"))
	if l11l1ll11l1l_l1_: l111l1111111_l1_.append(l11lll_l1_ (u"ࠨื๋ฮࠥฮฯู้่ࠣํืษࠨ媭")) ; l111ll111l11_l1_.append(l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ媮"))
	l11ll11l1l1l_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l111111l11ll_l1_, l111l1111111_l1_)
		if l1l_l1_==-1: return l11lll_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ媯"),[],[]
		elif l1l_l1_==0 and l11l1lll1lll_l1_:
			link = l111ll111l11_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11lll_l1_ (u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠳࠷࠵ࠫࡴࡡ࡮ࡧࡀࠫ媰")+QUOTE(l11l1lll1lll_l1_)+l11lll_l1_ (u"ࠬࠬࡵࡳ࡮ࡀࠫ媱")+link
			if l11l11lllll1_l1_: new_path = new_path+l11lll_l1_ (u"࠭ࠦࡪ࡯ࡤ࡫ࡪࡃࠧ媲")+QUOTE(l11l11lllll1_l1_)
			xbmc.executebuiltin(l11lll_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ媳")+new_path+l11lll_l1_ (u"ࠣࠫࠥ媴"))
			return l11lll_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ媵"),[],[]
		choice = l111ll111l11_l1_[l1l_l1_]
		l1111l1l1lll_l1_ = l111l1111111_l1_[l1l_l1_]
		if choice==l11lll_l1_ (u"ࠪࡨࡦࡹࡨࠨ媶"):
			l1111l11111l_l1_ = l11111ll1111_l1_
			break
		elif choice in [l11lll_l1_ (u"ࠫࡦࡻࡤࡪࡱࠪ媷"),l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ媸"),l11lll_l1_ (u"࠭࡭ࡶࡺࡨࡨࠬ媹")]:
			if choice==l11lll_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭媺"): l1lll1ll_l1_,l111l1l1l1ll_l1_ = l11ll11l11ll_l1_,l111l1l11ll1_l1_
			elif choice==l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ媻"): l1lll1ll_l1_,l111l1l1l1ll_l1_ = l11l111l111l_l1_,l111l1lll1l1_l1_
			elif choice==l11lll_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ媼"): l1lll1ll_l1_,l111l1l1l1ll_l1_ = l11l1ll11l1l_l1_,l11l1l1l111l_l1_
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ媽"), l1lll1ll_l1_)
			if l1l_l1_!=-1:
				l1111l11111l_l1_ = l111l1l1l1ll_l1_[l1l_l1_][l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ媾")]
				l1111l1l1lll_l1_ = l1lll1ll_l1_[l1l_l1_]
				break
		elif choice==l11lll_l1_ (u"ࠬࡳࡰࡥࠩ媿"):
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎ัส࠼ࠪ嫀"), l11l11ll1ll1_l1_)
			if l1l_l1_!=-1:
				l1111l1l1lll_l1_ = l11l11ll1ll1_l1_[l1l_l1_]
				l11l11llllll_l1_ = l11ll111lll1_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่ห࠼ࠪ嫁"), l111ll11ll11_l1_)
				if l1l_l1_!=-1:
					l1111l1l1lll_l1_ += l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ嫂")+l111ll11ll11_l1_[l1l_l1_]
					l11l11111l1l_l1_ = l11ll1111111_l1_[l1l_l1_]
					l11ll11l1l1l_l1_ = True
					break
		elif choice==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭嫃"):
			l11l1l1ll11l_l1_,l111ll1l1l1l_l1_,l11111l111ll_l1_,l11l11l11ll1_l1_ = list(zip(*l111l11111ll_l1_))
			l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ嫄"), l11111l111ll_l1_)
			if l1l_l1_!=-1:
				l1111l1l1lll_l1_ = l11111l111ll_l1_[l1l_l1_]
				l11l11llllll_l1_ = l11l1l1ll11l_l1_[l1l_l1_]
				if l11lll_l1_ (u"ࠫࡲࡶࡤࠨ嫅") in l11111l111ll_l1_[l1l_l1_] and l11l11llllll_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ嫆")]!=l11111ll1111_l1_:
					l11l11111l1l_l1_ = l111ll1l1l1l_l1_[l1l_l1_]
					l11ll11l1l1l_l1_ = True
				else: l1111l11111l_l1_ = l11l11llllll_l1_[l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ嫇")]
				break
		elif choice==l11lll_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ嫈"):
			#shift += 1
			l11l1l1ll11l_l1_,l111ll1l1l1l_l1_,l11111l111ll_l1_,l11l11l11ll1_l1_ = list(zip(*l111111llll1_l1_))
			l11l11llllll_l1_ = l11l1l1ll11l_l1_[l1l_l1_-shift]
			if l11lll_l1_ (u"ࠨ࡯ࡳࡨࠬ嫉") in l11111l111ll_l1_[l1l_l1_-shift] and l11l11llllll_l1_[l11lll_l1_ (u"ࠩࡸࡶࡱ࠭嫊")]!=l11111ll1111_l1_:
				l11l11111l1l_l1_ = l111ll1l1l1l_l1_[l1l_l1_-shift]
				l11ll11l1l1l_l1_ = True
			else: l1111l11111l_l1_ = l11l11llllll_l1_[l11lll_l1_ (u"ࠪࡹࡷࡲࠧ嫋")]
			l1111l1l1lll_l1_ = l11111l111ll_l1_[l1l_l1_-shift]
			break
	if not l11ll11l1l1l_l1_: l11111llll11_l1_ = l1111l11111l_l1_
	else: l11111llll11_l1_ = l11lll_l1_ (u"࡛ࠫ࡯ࡤࡦࡱ࠽ࠤࠬ嫌")+l11l11llllll_l1_[l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ嫍")]+l11lll_l1_ (u"࠭ࠠࠬࠢࡄࡹࡩ࡯࡯࠻ࠢࠪ嫎")+l11l11111l1l_l1_[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ嫏")]
	if l11ll11l1l1l_l1_:
		#LOG_THIS(l11lll_l1_ (u"ࠨࠩ嫐"),l11lll_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬ࠭ࠣࠤࠥ࠭嫑")+str(l11l11llllll_l1_))
		#LOG_THIS(l11lll_l1_ (u"ࠪࠫ嫒"),l11lll_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮࠯ࠥࠦࠠࠨ嫓")+str(l11l11111l1l_l1_))
		#if l11ll111ll11_l1_>l111llll1l1l_l1_: l1l111l1ll_l1_ = str(l11ll111ll11_l1_)
		#else: l1l111l1ll_l1_ = str(l111llll1l1l_l1_)
		#l1l111l1ll_l1_ = str(l11ll111ll11_l1_) if l11ll111ll11_l1_>l111llll1l1l_l1_ else str(l111llll1l1l_l1_)
		l11ll111ll11_l1_ = int(l11l11llllll_l1_[l11lll_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ嫔")])
		l111llll1l1l_l1_ = int(l11l11111l1l_l1_[l11lll_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ嫕")])
		l1l111l1ll_l1_ = str(max(l11ll111ll11_l1_,l111llll1l1l_l1_))
		l111lll11l1l_l1_ = l11l11llllll_l1_[l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ嫖")].replace(l11lll_l1_ (u"ࠨࠨࠪ嫗"),l11lll_l1_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ嫘"))		# +l11lll_l1_ (u"ࠪࠪࡷࡧ࡮ࡨࡧࡀ࠴࠲࠷࠰࠱࠲࠳࠴࠵࠶ࠧ嫙")
		l11l1ll11ll1_l1_ = l11l11111l1l_l1_[l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ嫚")].replace(l11lll_l1_ (u"ࠬࠬࠧ嫛"),l11lll_l1_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ嫜"))		# +l11lll_l1_ (u"ࠧࠧࡴࡤࡲ࡬࡫࠽࠱࠯࠴࠴࠵࠶࠰࠱࠲࠳ࠫ嫝")
		l11ll11l11l1_l1_ = l11lll_l1_ (u"ࠨ࠾ࡂࡼࡲࡲࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤ࠴࠲࠵ࠨࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠿࡙࡙ࠥࡌ࠭࠹ࠤࡂࡂࡡࡴࠧ嫞")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡑࡕࡊࠠࡹ࡯࡯ࡲࡸࡀࡸࡴ࡫ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠴࠳࠴࠶࠵ࡘࡎࡎࡖࡧ࡭࡫࡭ࡢ࠯࡬ࡲࡸࡺࡡ࡯ࡥࡨࠦࠥࡾ࡭࡭ࡰࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠢࠡࡺࡰࡰࡳࡹ࠺ࡹ࡮࡬ࡲࡰࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠶࠿࠹࠺࠱ࡻࡰ࡮ࡴ࡫ࠣࠢࡻࡷ࡮ࡀࡳࡤࡪࡨࡱࡦࡒ࡯ࡤࡣࡷ࡭ࡴࡴ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠣ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧ࡮ࡥࡣࡵࡨࡸ࠴ࡩࡴࡱ࠱ࡳࡷ࡭࠯ࡪࡶࡷࡪ࠴ࡖࡵࡣ࡮࡬ࡧࡱࡿࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࡕࡷࡥࡳࡪࡡࡳࡦࡶ࠳ࡒࡖࡅࡈ࠯ࡇࡅࡘࡎ࡟ࡴࡥ࡫ࡩࡲࡧ࡟ࡧ࡫࡯ࡩࡸ࠵ࡄࡂࡕࡋ࠱ࡒࡖࡄ࠯ࡺࡶࡨࠧࠦ࡭ࡪࡰࡅࡹ࡫࡬ࡥࡳࡖ࡬ࡱࡪࡃࠢࡑࡖ࠴࠲࠺࡙ࠢࠡ࡯ࡨࡨ࡮ࡧࡐࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡉࡻࡲࡢࡶ࡬ࡳࡳࡃࠢࡑࡖࠪ嫟")+l1l111l1ll_l1_+l11lll_l1_ (u"ࠪࡗࠧࠦࡴࡺࡲࡨࡁࠧࡹࡴࡢࡶ࡬ࡧࠧࠦࡰࡳࡱࡩ࡭ࡱ࡫ࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡳࡶࡴ࡬ࡩ࡭ࡧ࠽࡭ࡸࡵࡦࡧ࠯ࡰࡥ࡮ࡴ࠺࠳࠲࠴࠵ࠧࡄ࡜࡯ࠩ嫠")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠫࡁࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨ嫡")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠬࡂࡁࡥࡣࡳࡸࡦࡺࡩࡰࡰࡖࡩࡹࠦࡩࡥ࠿ࠥ࠴ࠧࠦ࡭ࡪ࡯ࡨࡘࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰ࠩ嫢")+l11l11llllll_l1_[l11lll_l1_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ嫣")]+l11lll_l1_ (u"ࠧࠣࠢࡶࡹࡧࡹࡥࡨ࡯ࡨࡲࡹࡇ࡬ࡪࡩࡱࡱࡪࡴࡴ࠾ࠤࡷࡶࡺ࡫ࠢ࠿࡞ࡱࠫ嫤")		# l111llllll11_l1_=l11lll_l1_ (u"ࠣ࠳ࠥ嫥") l11ll11l1111_l1_=l11lll_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ嫦") default=l11lll_l1_ (u"ࠥࡸࡷࡻࡥࠣ嫧")>\n
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩ嫨")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬ嫩")+l11l11llllll_l1_[l11lll_l1_ (u"࠭ࡩࡵࡣࡪࠫ嫪")]+l11lll_l1_ (u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫ嫫")+l11l11llllll_l1_[l11lll_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ嫬")]+l11lll_l1_ (u"ࠩࠥࠤࡸࡺࡡࡳࡶ࡚࡭ࡹ࡮ࡓࡂࡒࡀࠦ࠶ࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦࠬ嫭")+str(l11l11llllll_l1_[l11lll_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ嫮")])+l11lll_l1_ (u"ࠫࠧࠦࡷࡪࡦࡷ࡬ࡂࠨࠧ嫯")+str(l11l11llllll_l1_[l11lll_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ嫰")])+l11lll_l1_ (u"࠭ࠢࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠪ嫱")+str(l11l11llllll_l1_[l11lll_l1_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ嫲")])+l11lll_l1_ (u"ࠨࠤࠣࡪࡷࡧ࡭ࡦࡔࡤࡸࡪࡃࠢࠨ嫳")+l11l11llllll_l1_[l11lll_l1_ (u"ࠩࡩࡴࡸ࠭嫴")]+l11lll_l1_ (u"ࠪࠦࡃࡢ࡮ࠨ嫵")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ嫶")+l111lll11l1l_l1_+l11lll_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ嫷")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ嫸")+l11l11llllll_l1_[l11lll_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭嫹")]+l11lll_l1_ (u"ࠨࠤࡁࡠࡳ࠭嫺")	# l111111lllll_l1_=l11lll_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ嫻")>\n
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭嫼")+l11l11llllll_l1_[l11lll_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ嫽")]+l11lll_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ嫾")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ嫿")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭嬀")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭嬁")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠲ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡡࡶࡦ࡬ࡳ࠴࠭嬂")+l11l11111l1l_l1_[l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ嬃")]+l11lll_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ嬄")		# l111llllll11_l1_=l11lll_l1_ (u"ࠧ࠷ࠢ嬅") l11ll11l1111_l1_=l11lll_l1_ (u"ࠨࡴࡳࡷࡨࠦ嬆") default=l11lll_l1_ (u"ࠢࡵࡴࡸࡩࠧ嬇")>\n
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠨ࠾ࡕࡳࡱ࡫ࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡱࡦ࡯࡮ࠣ࠱ࡁࡠࡳ࠭嬈")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࠩ嬉")+l11l11111l1l_l1_[l11lll_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ嬊")]+l11lll_l1_ (u"ࠫࠧࠦࡣࡰࡦࡨࡧࡸࡃࠢࠨ嬋")+l11l11111l1l_l1_[l11lll_l1_ (u"ࠬࡩ࡯ࡥࡧࡦࡷࠬ嬌")]+l11lll_l1_ (u"࠭ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠷࠳࠱࠶࠺࠹ࠧࡄ࡜࡯ࠩ嬍")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠧ࠽ࡃࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿࠸࠳࠱࠲࠶࠾࠸ࡀࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡥࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠭嬎")+l11l11111l1l_l1_[l11lll_l1_ (u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ嬏")]+l11lll_l1_ (u"ࠩࠥ࠳ࡃࡢ࡮ࠨ嬐")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭嬑")+l11l1ll11ll1_l1_+l11lll_l1_ (u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪ嬒")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪ嬓")+l11l11111l1l_l1_[l11lll_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ嬔")]+l11lll_l1_ (u"ࠧࠣࡀ࡟ࡲࠬ嬕")	# l111111lllll_l1_=l11lll_l1_ (u"ࠣࡶࡵࡹࡪࠨ嬖")>\n
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬ嬗")+l11l11111l1l_l1_[l11lll_l1_ (u"ࠪ࡭ࡳ࡯ࡴࠨ嬘")]+l11lll_l1_ (u"ࠫࠧࠦ࠯࠿࡞ࡱࠫ嬙")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ嬚")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ嬛")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ嬜")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠨ࠾࠲ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭嬝")
		l11ll11l11l1_l1_ += l11lll_l1_ (u"ࠩ࠿࠳ࡒࡖࡄ࠿࡞ࡱࠫ嬞")
		#open(l11lll_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡺࡱࡸࡸࡺࡨࡥ࠯࡯ࡳࡨࠬ嬟"),l11lll_l1_ (u"ࠫࡼࡨࠧ嬠")).write(l11ll11l11l1_l1_)
		#LOG_THIS(l11lll_l1_ (u"ࠬ࠭嬡"),l11ll11l11l1_l1_)
		#l11ll11l11l1_l1_ = OPENURL_CACHED(NO_CACHE,l11111ll1111_l1_,l11lll_l1_ (u"࠭ࠧ嬢"),l11lll_l1_ (u"ࠧࠨ嬣"),l11lll_l1_ (u"ࠨࠩ嬤"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠹ࡵࡪࠪ嬥"))
		if kodi_version>18.99:
			import http.server as l11l111ll1l1_l1_
			import http.client as l1111lllllll_l1_
		else:
			import BaseHTTPServer as l11l111ll1l1_l1_
			import httplib as l1111lllllll_l1_
		class l1111l1l11l1_l1_(l11l111ll1l1_l1_.HTTPServer):
			#l11ll11l11l1_l1_ = l11lll_l1_ (u"ࠪࡀࡃ࠭嬦")
			def __init__(self,l1l1ll1ll1ll_l1_=l11lll_l1_ (u"ࠫࡱࡵࡣࡢ࡮࡫ࡳࡸࡺࠧ嬧"),port=55055,l11ll11l11l1_l1_=l11lll_l1_ (u"ࠬࡂ࠾ࠨ嬨")):
				self.l1l1ll1ll1ll_l1_ = l1l1ll1ll1ll_l1_
				self.port = port
				self.l11ll11l11l1_l1_ = l11ll11l11l1_l1_
				l11l111ll1l1_l1_.HTTPServer.__init__(self,(self.l1l1ll1ll1ll_l1_,self.port),l111ll111lll_l1_)
				self.l1111l11l1l1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧ嬩")+l1l1ll1ll1ll_l1_+l11lll_l1_ (u"ࠧ࠻ࠩ嬪")+str(port)+l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ嬫")
				#print(l11lll_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡻࡰࠡࡰࡲࡻࠥࡲࡩࡴࡶࡨࡲ࡮ࡴࡧࠡࡱࡱࠤࡵࡵࡲࡵ࠼ࠣࠫ嬬")+str(port))
			def start(self):
				self.threads = l1111l111ll_l1_(False)
				self.threads.start_new_thread(1,self.l111lll1llll_l1_)
			def l111lll1llll_l1_(self):
				#print(l11lll_l1_ (u"ࠪࡷࡪࡸࡶࡪࡰࡪࠤࡷ࡫ࡱࡶࡧࡶࡸࡸࠦࡳࡵࡣࡵࡸࡪࡪࠧ嬭"))
				self.l111111ll1l1_l1_ = True
				#l1l11ll111l_l1_ = 0
				while self.l111111ll1l1_l1_:
					#l1l11ll111l_l1_ += 1
					#print(l11lll_l1_ (u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠥࡧࠠࡴ࡫ࡱ࡫ࡱ࡫ࠠࡩࡣࡱࡨࡱ࡫࡟ࡳࡧࡴࡹࡪࡹࡴࠩࠫࠣࡲࡴࡽ࠺ࠡࠩ嬮")+str(l1l11ll111l_l1_)+l11lll_l1_ (u"ࠬ࠭嬯"))
					#settimeout l1111ll1l1_l1_ not l111l11lll_l1_ l111l11l1l1l_l1_ to error message if it l1111ll1l111_l1_ l11111l1l11l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l111lll1llll_l1_ l111lllll11l_l1_ request l1111l1111ll_l1_ 60 seconds)
					self.handle_request()
				#print(l11lll_l1_ (u"࠭ࡳࡦࡴࡹ࡭ࡳ࡭ࠠࡳࡧࡴࡹࡪࡹࡴࡴࠢࡶࡸࡴࡶࡰࡦࡦ࡟ࡲࠬ嬰"))
			def stop(self):
				self.l111111ll1l1_l1_ = False
				self.l11l1111l111_l1_()	# needed to l11ll11111ll_l1_ self.handle_request() to l111lll1llll_l1_ l1llllllllll_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11lll_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡨࡴࡽ࡮ࠡࡰࡲࡻࡡࡴࠧ嬱"))
			def load(self,l11ll11l11l1_l1_):
				self.l11ll11l11l1_l1_ = l11ll11l11l1_l1_
			def l11l1111l111_l1_(self):
				conn = l1111lllllll_l1_.HTTPConnection(self.l1l1ll1ll1ll_l1_+l11lll_l1_ (u"ࠨ࠼ࠪ嬲")+str(self.port))
				conn.request(l11lll_l1_ (u"ࠤࡋࡉࡆࡊࠢ嬳"), l11lll_l1_ (u"ࠥ࠳ࠧ嬴"))
		class l111ll111lll_l1_(l11l111ll1l1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11lll_l1_ (u"ࠫࡩࡵࡩ࡯ࡩࠣࡋࡊ࡚ࠠࠡࠩ嬵")+self.path)
				self.send_response(200)
				self.send_header(l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫ嬶"),l11lll_l1_ (u"࠭ࡴࡦࡺࡷ࠳ࡵࡲࡡࡪࡰࠪ嬷"))
				self.end_headers()
				#self.wfile.write(self.path+l11lll_l1_ (u"ࠧ࡝ࡰࠪ嬸"))
				self.wfile.write(self.server.l11ll11l11l1_l1_.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭嬹")))
				time.sleep(1)
				if self.path==l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ嬺"): self.server.shutdown()
				if self.path==l11lll_l1_ (u"ࠪ࠳ࡸ࡮ࡵࡵࡦࡲࡻࡳ࠭嬻"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11lll_l1_ (u"ࠫࡩࡵࡩ࡯ࡩࠣࡌࡊࡇࡄࠡࠢࠪ嬼")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1111l1l11l1_l1_(l11lll_l1_ (u"ࠬ࠷࠲࠸࠰࠳࠲࠵࠴࠱ࠨ嬽"),55055,l11ll11l11l1_l1_)
		#httpd.load(l11ll11l11l1_l1_)
		l1111l11111l_l1_ = httpd.l1111l11l1l1_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1111l11111l_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭࡫ࡹࡩࡸ࡯࡭࠯ࡦࡤࡷ࡭࡯ࡦ࠯ࡱࡵ࡫࠴ࡲࡩࡷࡧࡶ࡭ࡲ࠵ࡣࡩࡷࡱ࡯ࡩࡻࡲࡠ࠳࠲ࡥࡹࡵ࡟࠸࠱ࡷࡩࡸࡺࡰࡪࡥ࠷ࡣ࠽ࡹ࠯ࡎࡣࡱ࡭࡫࡫ࡳࡵ࠰ࡰࡴࡩ࠭嬾")
		#l1111l11111l_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡤࡷ࡭࠴ࡡ࡬ࡣࡰࡥ࡮ࢀࡥࡥ࠰ࡱࡩࡹ࠵ࡤࡢࡵ࡫࠶࠻࠺࠯ࡕࡧࡶࡸࡈࡧࡳࡦࡵ࠲࠶ࡨ࠵ࡱࡶࡣ࡯ࡧࡴࡳ࡭࠰࠳࠲ࡑࡺࡲࡴࡪࡔࡨࡷࡒࡖࡅࡈ࠴࠱ࡱࡵࡪࠧ嬿")
		#l1111l11111l_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡸࡸ࡯࠮ࡵࡧ࡯ࡩࡨࡵ࡭࠮ࡲࡤࡶ࡮ࡹࡴࡦࡥ࡫࠲࡫ࡸ࠯ࡨࡲࡤࡧ࠴ࡊࡁࡔࡊࡢࡇࡔࡔࡆࡐࡔࡐࡅࡓࡉࡅ࠰ࡖࡨࡰࡪࡩ࡯࡮ࡒࡤࡶ࡮ࡹࡔࡦࡥ࡫࠳ࡲࡶ࠴࠮࡮࡬ࡺࡪ࠵࡭ࡱ࠶࠰ࡰ࡮ࡼࡥ࠮࡯ࡳࡨ࠲ࡇࡖ࠮ࡄࡖ࠲ࡲࡶࡤࠨ孀")
		#l1111l11111l_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡵࡨࡲ࡫ࡤࡪࡣ࠱ࡦࡧࡩ࠮ࡤࡱ࠱ࡹࡰ࠵ࡤࡢࡵ࡫࠳ࡴࡴࡤࡦ࡯ࡤࡲࡩ࠵ࡴࡦࡵࡷࡧࡦࡸࡤ࠰࠳࠲ࡧࡱ࡯ࡥ࡯ࡶࡢࡱࡦࡴࡩࡧࡧࡶࡸ࠲࡫ࡶࡦࡰࡷࡷ࠲ࡳࡵ࡭ࡶ࡬ࡰࡦࡴࡧ࠯࡯ࡳࡨࠬ孁")
		#l1111l11111l_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡴࡩࡡ࡭ࡪࡲࡷࡹࡀ࠵࠶࠲࠸࠹࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ孂")
	else: httpd = l11lll_l1_ (u"ࠫࠬ孃")
	if not l1111l11111l_l1_: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ孄"),[],[]
	return l11lll_l1_ (u"࠭ࠧ孅"),[l11lll_l1_ (u"ࠧࠨ孆")],[[l1111l11111l_l1_,l111ll1lll11_l1_,httpd]]
def l111l11ll111_l1_(url):
	# https://l11l1lllll11_l1_.com/l111l1lll11l_l1_
	headers = { l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ孇") : l11lll_l1_ (u"ࠩࠪ孈") }
	#url = url.replace(l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ孉"),l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ孊"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭孋"),headers,l11lll_l1_ (u"࠭ࠧ孌"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ孍"))
	items = re.findall(l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ孎"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l11l11ll1lll_l1_,l1lll1ll_l1_,l11l1l1lll1l_l1_,l1111_l1_ = [],[],[],[]
	if items:
		for link,dummy,l1ll11l1ll1l_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ孏"),l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ子"))
			if l11lll_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ孑") in link:
				l11l11ll1lll_l1_,l11l1l1lll1l_l1_ = l11ll11l11_l1_(link)
				#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭孒"),l11lll_l1_ (u"࠭ࠧ孓"),str(l1111_l1_),str(l11l1l1lll1l_l1_))
				l1111_l1_ = l1111_l1_ + l11l1l1lll1l_l1_
				if l11l11ll1lll_l1_[0]==l11lll_l1_ (u"ࠧ࠮࠳ࠪ孔"): l1lll1ll_l1_.append(l11lll_l1_ (u"ࠨีํีๆืࠠฯษุࠫ孕")+l11lll_l1_ (u"ࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ孖"))
				else:
					for title in l11l11ll1lll_l1_:
						l1lll1ll_l1_.append(l11lll_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭字")+l11lll_l1_ (u"ࠫࠥࠦࠠࠨ存")+title)
			else:
				title = l11lll_l1_ (u"ู๊ࠬาใิࠤำอีࠨ孙")+l11lll_l1_ (u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩ孚")+l1ll11l1ll1l_l1_
				l1111_l1_.append(link)
				l1lll1ll_l1_.append(title)
		return l11lll_l1_ (u"ࠧࠨ孛"),l1lll1ll_l1_,l1111_l1_
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪ孜"),[],[]
def l11111ll11l1_l1_(url):
	# https://l11ll1111ll1_l1_.cc/l1l11llll_l1_-1qrpoobdg7bu.html
	# https://l11l111111ll_l1_.cc//l1l11llll_l1_-l11l11l11lll_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭孝"),url,l11lll_l1_ (u"ࠪࠫ孞"),l11lll_l1_ (u"ࠫࠬ孟"),l11lll_l1_ (u"ࠬ࠭孠"),l11lll_l1_ (u"࠭ࠧ孡"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜࡛ࡏࡄࡆࡑࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ孢"))
	html = response.content
	links = re.findall(l11lll_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ季"),html,re.DOTALL)
	if links:
		link = links[0]
		return l11lll_l1_ (u"ࠩࠪ孤"),[l11lll_l1_ (u"ࠪࠫ孥")],[link]
	return l11lll_l1_ (u"ࠫࠬ学"),[],[]
def l11111lll1l1_l1_(url):
	# https://l11111lll11l_l1_.in/l1111ll1ll11_l1_
	# https://l11111lll11l_l1_.in/l1l11llll_l1_-l1111ll1ll11_l1_.html
	# https://l11l111lllll_l1_.l111l111l111_l1_/l11l1lll11ll_l1_
	# https://l11l111lllll_l1_.l111l111l111_l1_/l1l11llll_l1_-l11l1lll11ll_l1_.html
	# https://www.l11l1llll11l_l1_.com/l1l11llll_l1_-l111ll1l111l_l1_.html
	url = url.replace(l11lll_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ孧"),l11lll_l1_ (u"࠭ࠧ孨")).replace(l11lll_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭孩"),l11lll_l1_ (u"ࠨࠩ孪"))
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭孫"),url,l11lll_l1_ (u"ࠪࠫ孬"),l11lll_l1_ (u"ࠫࠬ孭"),l11lll_l1_ (u"ࠬ࠭孮"),l11lll_l1_ (u"࠭ࠧ孯"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭孰"))
	html = response.content
	l1ll11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࡥ࡞ࠬ࠲࠯ࡅ࡜ࠪ࡞ࠬࡠ࠮࠯ࠧ孱"),html,re.DOTALL)
	if l1ll11ll11ll_l1_:
		l1ll11ll11ll_l1_ = l1ll11ll11ll_l1_[0]
		l1l1l1lll11l_l1_ = l1l1lll111l1_l1_(l1ll11ll11ll_l1_)
		links = re.findall(l11lll_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ孲"),l1l1l1lll11l_l1_,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪࠬࢁࠬ孳"),l1l1l1lll11l_l1_,re.DOTALL)
		l1lll1ll_l1_,l1111_l1_ = [],[]
		for link,title in links:
			if not title: title = link.rsplit(l11lll_l1_ (u"ࠫ࠳࠭孴"),1)[1]
			l1lll1ll_l1_.append(title)
			l1111_l1_.append(link)
		return l11lll_l1_ (u"ࠬ࠭孵"),l1lll1ll_l1_,l1111_l1_
	id = url.split(l11lll_l1_ (u"࠭࠯ࠨ孶"))[3]
	headers = { l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ孷"):l11lll_l1_ (u"ࠨࠩ學") , l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ孹"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ孺") }
	payload = { l11lll_l1_ (u"ࠫ࡮ࡪࠧ孻"):id , l11lll_l1_ (u"ࠬࡵࡰࠨ孼"):l11lll_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ孽") }
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ孾"),url,payload,headers,l11lll_l1_ (u"ࠨࠩ孿"),l11lll_l1_ (u"ࠩࠪ宀"),l11lll_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡇࡋࡏࡉࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ宁"))
	html = response.content
	items = re.findall(l11lll_l1_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ宂"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠬ࠭它"),[l11lll_l1_ (u"࠭ࠧ宄")],[ items[0] ]
	return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡛ࠢࡊࡎࡒࡅࡔࡊࡄࡖࡎࡔࡇࠨ宅"),[],[]
l11lll_l1_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡࡉࡒ࡚ࡎࡊࠨࡶࡴ࡯࠭࠿ࠐࠉࠤࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡼࡩࡥࡧࡲ࠳ࡵࡲࡡࡺ࠱ࡄࡅ࡛ࡋࡎࡥࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠡࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࠠ࠻ࠢࠪࠫࠥࢃࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡔ࡜ࡉࡅ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮࡞ࡡࠏࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡩࠤࠬ࠴࡭࠴ࡷ࠻ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࡟࠵ࡣ࠽࠾ࠩ࠰࠵ࠬࡀࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦุࠫࠫ๐ัโำࠣาฬ฻ࠧࠬࠩࠣࠤࠥࡳ࠳ࡶ࠺ࠪ࠭ࠏࠏࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌࠍ࡫ࡵࡲࠡࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡺࡥ࡮ࡲ࠽ࠎࠎࠏࠉࠊࠋࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࠭ำ๋ำไีࠥิวึࠩ࠮ࠫࠥࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࠨีํีๆืࠠฯษุࠫ࠰࠭ࠠࠡࠢࡰࡴ࠹࠭ࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠥ࠭ࠧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠐࠉࡦ࡮ࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠦࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓ࡛ࡏࡄࠨ࠮࡞ࡡ࠱ࡡ࡝ࠋࠋࠦࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠱࡮࠰ࡪࡳࡻ࡯ࡤ࠯ࡥࡲ࠳ࡸࡺࡲࡦࡣࡰ࠳࠷࠸࠹࠯࡯࠶ࡹ࠽ࠐࠢࠣࠤ宆")
#####################################################
#    l11l1ll1l1ll_l1_ l111l1llllll_l1_ l111l111l1ll_l1_
#    16-06-2019
#####################################################
def l111l1ll11l1_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠩࠪ宇"),l11lll_l1_ (u"ࠪࠫ守"),l11lll_l1_ (u"ࠫࠬ安"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨ宊"))
	items = re.findall(l11lll_l1_ (u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ宋"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠧࠨ完"),[l11lll_l1_ (u"ࠨࠩ宍")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉ࡙ࠧ宎"),[],[]
def l111l1l11lll_l1_(url):
	return l11lll_l1_ (u"ࠪࠫ宏"),[l11lll_l1_ (u"ࠫࠬ宐")],[ url ]
def l111ll11111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭宑"),l11lll_l1_ (u"࠭ࠧ宒"),url,l11lll_l1_ (u"ࠧࠨ宓"))
	server = url.split(l11lll_l1_ (u"ࠨ࠱ࠪ宔"))
	basename = l11lll_l1_ (u"ࠩ࠲ࠫ宕").join(server[0:3])
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠪࠫ宖"),l11lll_l1_ (u"ࠫࠬ宗"),l11lll_l1_ (u"ࠬ࠭官"),l11lll_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠳࠱ࡴࡶࠪ宙"))
	items = re.findall(l11lll_l1_ (u"ࠧࡥ࡮ࡥࡹࡹࡺ࡯࡯࡞ࠪࡠ࠮࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠠ࡝࠭ࠣࡠ࠭࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠬࠢࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫ࡟࠭ࠥࡢࠫࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ定"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ宛"),l11lll_l1_ (u"ࠩࠪ宜"),url,str(var))
	if items:
		l11llll1ll11_l1_,l11llllll111_l1_,l11llllll11l_l1_,l11l11l11l11_l1_,l11l11l11l1l_l1_,l11l11l111ll_l1_ = items[0]
		var = int(l11llllll111_l1_) % int(l11llllll11l_l1_) + int(l11l11l11l11_l1_) % int(l11l11l11l1l_l1_)
		url = basename + l11llll1ll11_l1_ + str(var) + l11l11l111ll_l1_
		return l11lll_l1_ (u"ࠪࠫ宝"),[l11lll_l1_ (u"ࠫࠬ实")],[url]
	else: return l11lll_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡛ࠠࡋࡓࡔ࡞࡙ࡈࡂࡔࡈࠫ実"),[],[]
def l11l111ll11l_l1_(url):
	url = url.replace(l11lll_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭宠"),l11lll_l1_ (u"ࠧࠨ审"))
	url = url.replace(l11lll_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ客"),l11lll_l1_ (u"ࠩࠪ宣"))
	id = url.split(l11lll_l1_ (u"ࠪ࠳ࠬ室"))[-1]
	headers = { l11lll_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ宥") : l11lll_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ宦") }
	payload = { l11lll_l1_ (u"ࠨࡩࡥࠤ宧"):id , l11lll_l1_ (u"ࠢࡰࡲࠥ宨"):l11lll_l1_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠦ宩") }
	request = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ宪"), url, payload, headers, l11lll_l1_ (u"ࠪࠫ宫"),l11lll_l1_ (u"ࠫࠬ宬"),l11lll_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡓ࠸࡚ࡖࡌࡐࡃࡇ࠱࠶ࡹࡴࠨ宭"))
	if l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ宮") in list(request.headers.keys()): link = request.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ宯")]
	else: link = url
	if link: return l11lll_l1_ (u"ࠨࠩ宰"),[l11lll_l1_ (u"ࠩࠪ宱")],[link]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡐ࠵ࡗࡓࡐࡔࡇࡄࠨ宲"),[],[]
def l1111llll11l_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠫࠬ害"),l11lll_l1_ (u"ࠬ࠭宴"),l11lll_l1_ (u"࠭ࠧ宵"),l11lll_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡎࡔࡔࡗࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ家"))
	items = re.findall(l11lll_l1_ (u"ࠨ࡯ࡳ࠸࠿ࠦ࡜࡜࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ宷"),html,re.DOTALL)
	if items: return l11lll_l1_ (u"ࠩࠪ宸"),[l11lll_l1_ (u"ࠪࠫ容")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡗࡊࡐࡗ࡚ࡑࡏࡖࡆࠩ宺"),[],[]
def l111111lll11_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠬ࠭宻"),l11lll_l1_ (u"࠭ࠧ宼"),l11lll_l1_ (u"ࠧࠨ宽"),l11lll_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡃࡉࡋ࡙ࡉ࠲࠷ࡳࡵࠩ宾"))
	items = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ宿"),html,re.DOTALL)
	#l11l111111l1_l1_.l11111l11ll1_l1_(l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠳ࡵࡲࡨࠩ寀") + items[0])
	if items:
		url = url = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ寁") + items[0]
		return l11lll_l1_ (u"ࠬ࠭寂"),[l11lll_l1_ (u"࠭ࠧ寃")],[ url ]
	else: return l11lll_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪ寄"),[],[]
def l111ll1l11ll_l1_(url):
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"ࠨࠩ寅"),l11lll_l1_ (u"ࠩࠪ密"),l11lll_l1_ (u"ࠪࠫ寇"),l11lll_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡗࡅࡐࡎࡉࡖࡊࡆࡈࡓࡍࡕࡓࡕ࠯࠴ࡷࡹ࠭寈"))
	items = re.findall(l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ寉"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ寊"),l11lll_l1_ (u"ࠧࠨ寋"),str(items),html)
	if items: return l11lll_l1_ (u"ࠨࠩ富"),[l11lll_l1_ (u"ࠩࠪ寍")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚ࠧ寎"),[],[]
def l111l1l1lll1_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠫࡪࡳࡢࡦࡦ࠰ࠫ寏"),l11lll_l1_ (u"ࠬ࠭寐"))
	html = OPENURL_CACHED(l1lll1111_l1_,url,l11lll_l1_ (u"࠭ࠧ寑"),l11lll_l1_ (u"ࠧࠨ寒"),l11lll_l1_ (u"ࠨࠩ寓"),l11lll_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪ寔"))
	items = re.findall(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ寕"),html,re.DOTALL)
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ寖"),l11lll_l1_ (u"ࠬ࠭寗"),items[0],items[0])
	if items: return l11lll_l1_ (u"࠭ࠧ寘"),[l11lll_l1_ (u"ࠧࠨ寙")],[ items[0] ]
	else: return l11lll_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡘ࡚ࡒࡆࡃࡐࠫ寚"),[],[]
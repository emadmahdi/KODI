# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎࠨ暚")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣ࡙࡜ࡆࡠࠩ暛")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠫอัࠠๆสสุึ࠭暜")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l1111l_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1llllll_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ暝"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ暞"),l11lll_l1_ (u"ࠧࠨ暟"),l11lll_l1_ (u"ࠨࠩ暠"),l11lll_l1_ (u"ࠩࠪ暡"),l11lll_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ暢"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ暣"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ暤"),l11lll_l1_ (u"࠭ࠧ暥"),469,l11lll_l1_ (u"ࠧࠨ暦"),l11lll_l1_ (u"ࠨࠩ暧"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭暨"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ暩"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭暪")+l111ll_l1_+l11lll_l1_ (u"ࠬษฮาࠢส่า๊โศฬࠪ暫"),l11ll1_l1_,461,l11lll_l1_ (u"࠭ࠧ暬"),l11lll_l1_ (u"ࠧࠨ暭"),l11lll_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ暮"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ暯"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ暰"),l11lll_l1_ (u"ࠫࠬ暱"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡭ࡦࡰࡸ࠱ࡧࡺ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ暲"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ暳"),block,re.DOTALL)
		for link,title in items:
			#if link==l11lll_l1_ (u"ࠧࠤࠩ暴"): continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭暵") not in link: link = l11ll1_l1_+link
			if title==l11lll_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ暶"): title = l11lll_l1_ (u"ࠪะิ๐ฯࠡฯ็ๆฬะࠠห์ไ๎ࠥ็ว็ࠩ暷")
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ暸"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ暹")+l111ll_l1_+title,link,461)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡇࡱࡲࡸࡪࡸࡃࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ暺"),html,re.DOTALL)
	#if l1l1ll1_l1_:
	#	block = l1l1ll1_l1_[0]
	#	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭暻"),block,re.DOTALL)
	#	for link,title in items:
	#		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ暼"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ暽")+l111ll_l1_+title,link,461)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠪࠫ暾")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ暿"),l11lll_l1_ (u"ࠬ࠭曀"),l1111l111_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ曁"),url,l11lll_l1_ (u"ࠧࠨ曂"),l11lll_l1_ (u"ࠨࠩ曃"),l11lll_l1_ (u"ࠩࠪ曄"),l11lll_l1_ (u"ࠪࠫ曅"),l11lll_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ曆"))
	html = response.content
	#if l1111l111_l1_==l11lll_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ曇"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭รฯำࠣห้ำไใษอࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭曈"),html,re.DOTALL)
	#else:
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨ࠲ࡺࡩࡵ࡮ࡨࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ曉"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ曊"),block,re.DOTALL)
		l1l1_l1_ = []
		l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩ曋"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨ曌"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪ曍"),l11lll_l1_ (u"้ࠬไ๋สࠪ曎"),l11lll_l1_ (u"࠭วฺๆส๊ࠬ曏"),l11lll_l1_ (u"่ࠧัสๅࠬ曐"),l11lll_l1_ (u"ࠨ็หหึอษࠨ曑"),l11lll_l1_ (u"ࠩ฼ี฻࠭曒"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪ曓"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪ曔")]
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ曕") not in link: link = l11ll1_l1_+link
			link = l111l_l1_(link)	#.strip(l11lll_l1_ (u"࠭࠯ࠨ曖"))
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ曗"),title,re.DOTALL)
			if any(value in title for value in l1lll1_l1_):
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ曘"),l111ll_l1_+title,link,462,l1llll_l1_)
			elif l1lll11_l1_ and l11lll_l1_ (u"ࠩส่า๊โสࠩ曙") in title:
				title = l11lll_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ曚") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ曛"),l111ll_l1_+title,link,463,l1llll_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ曜"),l111ll_l1_+title,link,463,l1llll_l1_)
	if l1111l111_l1_!=l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭曝"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ曞"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭曟"),block,re.DOTALL)
			for link,title in items:
				link = link.strip(l11lll_l1_ (u"ࠩࠣࠫ曠"))
				if link==l11lll_l1_ (u"ࠥࠦ曡"): continue
				if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ曢") not in link: link = l11ll1_l1_+link
				#title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠬ࠭曣"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曤"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭曥")+title,link,461)
	return
def l1llllll_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ曦"),l11lll_l1_ (u"ࠩࠪ曧"),l11lll_l1_ (u"ࠪࡉࡕࡏࡓࡐࡆࡈࡗࠬ曨"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ曩"),url,l11lll_l1_ (u"ࠬ࠭曪"),l11lll_l1_ (u"࠭ࠧ曫"),l11lll_l1_ (u"ࠧࠨ曬"),l11lll_l1_ (u"ࠨࠩ曭"),l11lll_l1_ (u"ࠩࡗ࡚ࡋ࡛ࡎ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ曮"))
	html = response.content
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡬ࡪࡧࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠤࠪ曯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡵ࡮ࡤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ曰"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ曱") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ曲"),l111ll_l1_+title,link,462,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ曳"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ更"),block,re.DOTALL)
		for link,title in items:
			link = link.strip(l11lll_l1_ (u"ࠩࠣࠫ曵"))
			if link==l11lll_l1_ (u"ࠥࠦ曶"): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ曷") not in link: link = l11ll1_l1_+link
			#title = unescapeHTML(title)
			if title!=l11lll_l1_ (u"ࠬ࠭書"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曹"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭曺")+title,link,463)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ曻"),url,l11lll_l1_ (u"ࠩࠪ曼"),l11lll_l1_ (u"ࠪࠫ曽"),l11lll_l1_ (u"ࠫࠬ曾"),l11lll_l1_ (u"ࠬ࠭替"),l11lll_l1_ (u"࠭ࡔࡗࡈࡘࡒ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ最"))
	html = response.content
	# l1l11llll_l1_ link
	l1111l111l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡕࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭朁"),html,re.DOTALL)
	if l1111l111l_l1_:
		l1111l111l_l1_ = l1111l111l_l1_[0]
		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭朂") not in l1111l111l_l1_:
			if l11lll_l1_ (u"ࠩ࠲࠳ࠬ會") in l1111l111l_l1_: l1111l111l_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ朄")+l1111l111l_l1_
			else: l1111l111l_l1_ = l11ll1_l1_+l1111l111l_l1_
		l1111l111l_l1_ = l1111l111l_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡥ࡮ࡤࡨࡨࠬ朅")
		l1111_l1_.append(l1111l111l_l1_)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡨ࠱࠶࠼ࡥࡩ࡫ࡵࡲࡦࠪ࠱࠮ࡄ࠯ࡳ࡮ࡣ࡯ࡰ࠳࠰࠿ࠣࡘ࡬ࡨࡪࡵࡓࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡐ࡭ࡣࡼࠦࠬ朆"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lll11llll1l_l1_,l1lll11lllll1_l1_ = l1l1ll1_l1_[0]
		names = re.findall(l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ朇"),l1lll11llll1l_l1_,re.DOTALL)
		links = re.findall(l11lll_l1_ (u"ࠢࡴࡧࡷ࡚࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ月"),l1lll11lllll1_l1_,re.DOTALL)
		l1lll11llll11_l1_ = zip(names,links)
		for name,l11111ll1lll_l1_ in l1lll11llll11_l1_:
			l11111ll1lll_l1_ = l11111ll1lll_l1_[2:]
			if kodi_version<19: l11111ll1lll_l1_ = l11111ll1lll_l1_.decode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭有"))
			l11111ll1lll_l1_ = base64.b64decode(l11111ll1lll_l1_)
			if kodi_version>18.99: l11111ll1lll_l1_ = l11111ll1lll_l1_.decode(l11lll_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ朊"))
			link = re.findall(l11lll_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ朋"),l11111ll1lll_l1_,re.DOTALL)
			link = link[0]
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ朌") not in link:
				if l11lll_l1_ (u"ࠬ࠵࠯ࠨ服") in link: link = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ朎")+link
				else: link = l11ll1_l1_+link
			link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ朏")+name+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ朐")
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ朑"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ朒"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11lll_l1_ (u"ࠫࠥ࠭朓") in search:
		if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠬ࠭朔"),l11lll_l1_ (u"࠭ࠧ朕"),l11lll_l1_ (u"ࠧࡕࡘࡉ࡙ࡓࠦๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭朖"),l11lll_l1_ (u"ࠨๆ็วุ็ࠠศๆหัะࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศࠢํ฽ฺ๊๊่ࠠาࠤ฼๊ศࠡลๆฯึࠦๅ็ࠢๆ่๊ฯ้ࠠษะำฮࠦ࠮࠯࠰ࠣ๎ึา้ࠡษ็ฬาัฺ่ࠠࠣ็้๋ษ๊ࠡสัิฯࠠโไฺࠫ朗"))
		return
	#search = search.replace(l11lll_l1_ (u"ࠩࠣࠫ朘"),l11lll_l1_ (u"ࠪ࠱ࠬ朙"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ朚")+search
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡱ࠰ࠩ望")+search+l11lll_l1_ (u"࠭࠯ࠨ朜")
	l1111l_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
l11lll_l1_ (u"ࠢࠣࠤࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠴ࡣࡧࡶࡸ࠳ࡩ࡯࡮ࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠱࠯ࡤࡨࡷࡹ࠭ࠊࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠲࠰ࡦࡳࡲ࠭ࠊࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬࠐࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࠰ࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫࠏࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳ࡯ࡷ࡫ࡨࡷ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡳࡪࡶࡨࠫࠏࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡴࡷࠩࠍࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡦࡩ࡫࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡦࡳࠬࠐࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡦࡱࡵࡧࠨࠌࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱࡩࡦࡸ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯࡯ࡨࠫࠏࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺ࡯ࡰ࡮࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡱࡺࡤࠨࠌࠥࠦࠧ↛")
script_name = l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ↜")
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡉࡌࡈ࡟ࠨ↝")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ↞"):l11lll_l1_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠩ↟")}
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==120: results = MENU()
	elif mode==121: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==122: results = l1l11l_l1_(url)
	elif mode==123: results = PLAY(url)
	elif mode==124: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ↠")+text)
	elif mode==125: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ↡")+text)
	elif mode==129: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ↢"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ↣"),l11lll_l1_ (u"ࠩࠪ↤"),129,l11lll_l1_ (u"ࠪࠫ↥"),l11lll_l1_ (u"ࠫࠬ↦"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ↧"))
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ↨"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ↩"),l11lll_l1_ (u"ࠨࠩ↪"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭↫"),l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ↬"),headers,l11lll_l1_ (u"ࠫࠬ↭"),l11lll_l1_ (u"ࠬ࠭↮"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ↯"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࠢ࡬࠱࡭ࡵ࡭ࡦࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࠢ࡬࠱࡫ࡵ࡬ࡥࡧࡵࠦࠬ↰"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ↱"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠩส่๊฻วา฻ฬࠫ↲") in title: continue
			title = title.rsplit(l11lll_l1_ (u"ࠪࡂࠬ↳"),1)[1]
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭↴"))
			link = link.rstrip(l11lll_l1_ (u"ࠬ࠵ࠧ↵"))
			link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭↶"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ↷")+l111ll_l1_+title,link,122)
		addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭↸"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ↹"),l11lll_l1_ (u"ࠪࠫ↺"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡤ࡭ࡳࡒ࡯ࡢࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡇࡽࡳࡧ࡭ࡪࡥࠥࠫ↻"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡶࡤࡢࠢࡥࡨࡧࠨ࠾࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ↼"),html,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ↽"))
			link = link.rstrip(l11lll_l1_ (u"ࠧ࠰ࠩ↾"))
			link = l11ll1_l1_+link
			if l11lll_l1_ (u"ࠨษ็ฺ้อัฺหࠪ↿") in title: continue
			if l11lll_l1_ (u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫ⇀") in link: continue
			if not title and l11lll_l1_ (u"ࠪ࠳ࡹࡼ࠯ࡢࡴࡤࡦ࡮ࡩࠧ⇁") in link: title = l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥ฿ัษ์ฬࠫ⇂")
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⇃"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⇄")+l111ll_l1_+title,link,121)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⇅"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⇆"),l11lll_l1_ (u"ࠩࠪ⇇"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡦ࠮࠮ࠫࡁࠬࡂࡊ࡭ࡹࡃࡧࡶࡸࡁ࠵ࡡ࠿ࠩ⇈"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⇉"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ⇊"))
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇋"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⇌")+l111ll_l1_+title,link,121)
	return html
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⇍"),url,l11lll_l1_ (u"ࠩࠪ⇎"),headers,l11lll_l1_ (u"ࠪࠫ⇏"),l11lll_l1_ (u"ࠫࠬ⇐"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⇑"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡴࡡࡶࡧࡷࡵ࡬࡭ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⇒"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⇓"),block,re.DOTALL)
	if l11lll_l1_ (u"ࠨࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ⇔") not in url:
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇕"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭⇖"),url,125)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇗"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ⇘"),url,124)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⇙"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⇚"),l11lll_l1_ (u"ࠨࠩ⇛"),9999)
	for link,title in items:
		link = l11ll1_l1_+link
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⇜"),l111ll_l1_+title,link,121)
	return
def l1111l_l1_(url,l1l11l1_l1_=l11lll_l1_ (u"ࠪ࠵ࠬ⇝")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⇞"),l11lll_l1_ (u"ࠬ࠭⇟"),l11lll_l1_ (u"࠭ࡔࡊࡖࡏࡉࡘ࠭⇠"),url)
	if not l1l11l1_l1_: l1l11l1_l1_ = l11lll_l1_ (u"ࠧ࠲ࠩ⇡")
	#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⇢") not in url: url = l11ll1_l1_+url
	if l11lll_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࠬ⇣") in url or l11lll_l1_ (u"ࠪࡃࠬ⇤") in url: l11l11l_l1_ = url + l11lll_l1_ (u"ࠫࠫ࠭⇥")
	else: l11l11l_l1_ = url + l11lll_l1_ (u"ࠬࡅࠧ⇦")
	l11l11l_l1_ = l11l11l_l1_ + l11lll_l1_ (u"࠭࡯ࡶࡶࡳࡹࡹࡥࡦࡰࡴࡰࡥࡹࡃࡪࡴࡱࡱࠪࡴࡻࡴࡱࡷࡷࡣࡲࡵࡤࡦ࠿ࡰࡳࡻ࡯ࡥࡴࡡ࡯࡭ࡸࡺࠦࡱࡣࡪࡩࡂ࠭⇧")+l1l11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⇨"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩ⇩"),headers,l11lll_l1_ (u"ࠩࠪ⇪"),l11lll_l1_ (u"ࠪࠫ⇫"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ⇬"))
	html = response.content
	name,items = l11lll_l1_ (u"ࠬ࠭⇭"),[]
	if l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ⇮") in url:
		name = re.findall(l11lll_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⇯"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l11lll_l1_ (u"ࠨࠢࠪ⇰")) + l11lll_l1_ (u"ࠩࠣ࠱ࠥ࠭⇱")
		else: name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ⇲") ) + l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ⇳")
	if l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠭⇴") not in url: items = re.findall(l11lll_l1_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡝࡞࡟ࡠࠧ࠮࡜࡝࡞࡟ࡠ࠴ࡹࡥࡢࡵࡲࡲ࠳࠰࠿ࠪ࡞࡟ࡠࡡࠨ࠮ࠫࡁࡶࡶࡨࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧ࡟ࡠࡡࡢࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⇵"),html,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾࡞࡟ࡠࡡࠨࠨ࠯ࠬࡂ࠭ࡡࡢ࡜࡝ࠤ࠱࠮ࡄࡹࡲࡤ࠿࡟ࡠࡡࡢࠢࠩ࠰࠭ࡃ࠮ࡢ࡜࡝࡞ࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡡࡢ࡜࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⇶"),html,re.DOTALL)
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⇷") in url and l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࡟࠳ࠬ⇸") not in link: continue
		if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ⇹") in url and l11lll_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡢ࠯ࠨ⇺") not in link: continue
		title = name+escapeUNICODE(title).strip(l11lll_l1_ (u"ࠬࠦࠧ⇻"))
		link = link.replace(l11lll_l1_ (u"࠭࡜࠰ࠩ⇼"),l11lll_l1_ (u"ࠧ࠰ࠩ⇽"))
		l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠨ࡞࠲ࠫ⇾"),l11lll_l1_ (u"ࠩ࠲ࠫ⇿"))
		if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ∀") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ∁")+l1llll_l1_
		l11l11l_l1_ = l11ll1_l1_+link
		if l11lll_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠭∂") in l11l11l_l1_ or l11lll_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩ∃") in l11l11l_l1_ or l11lll_l1_ (u"ࠧ࠰࡯ࡤࡷࡷࡧࡨࡪࡻࡤࡸ࠴࠭∄") in url:
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ∅"),l111ll_l1_+title,l11l11l_l1_.rstrip(l11lll_l1_ (u"ࠩ࠲ࠫ∆")),123,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ∇"),l111ll_l1_+title,l11l11l_l1_,121,l1llll_l1_)
	if len(items)>=12:
		l1111ll111_l1_ = [l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷ࠴࠭∈"),l11lll_l1_ (u"ࠬ࠵ࡴࡷ࠱ࠪ∉"),l11lll_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࠩ∊"),l11lll_l1_ (u"ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩ࠲ࠫ∋"),l11lll_l1_ (u"ࠨ࠱ࡰࡥࡸࡸࡡࡩ࡫ࡼࡥࡹ࠵ࠧ∌")]
		l1l11l1_l1_ = int(l1l11l1_l1_)
		if any(value in url for value in l1111ll111_l1_):
			for n in range(0,1100,100):
				if int(l1l11l1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1l11l1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1l11l1_l1_==j and j!=0:
									addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ∍"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ∎")+str(j),url,121,l11lll_l1_ (u"ࠫࠬ∏"),str(j))
						elif i!=0: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ∐"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ∑")+str(i),url,121,l11lll_l1_ (u"ࠧࠨ−"),str(i))
						else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ∓"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ∔")+str(1),url,121,l11lll_l1_ (u"ࠪࠫ∕"),str(1))
				elif n!=0: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ∖"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ∗")+str(n),url,121,l11lll_l1_ (u"࠭ࠧ∘"),str(n))
				else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ∙"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ√")+str(1),url,121)
	return
def PLAY(url):
	headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭∛"):l11lll_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰ࠨ∜")}
	#url = url.replace(l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡴࡥࡵࠩ∝"),l11lll_l1_ (u"ࠬࡽ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ∞"))
	# cache l1111ll1l1_l1_ not l111l11lll_l1_ l11111l1ll_l1_ 3 minutes
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ∟"),url,l11lll_l1_ (u"ࠧࠨ∠"),headers,l11lll_l1_ (u"ࠨࠩ∡"),l11lll_l1_ (u"ࠩࠪ∢"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭∣"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁࡺࡤ࠿ษ็ฮฺ์๊โ࠾࠲ࡸࡩࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ∤"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1111l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡯ࡨ࠼ࡸࡶࡱࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ∥"),html,re.DOTALL)
	if l1111l11ll_l1_: server = SERVER(l1111l11ll_l1_[0],l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ∦"))
	else: server = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ∧"))
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡸࡧࡵࡤࡺࠪ࠱࠮ࡄ࠯ࡴࡣࡱࡧࡽࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥࡴ࡯ࡵࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠺ࠋࠋࠌࡈࡎࡇࡌࡐࡉࡢࡒࡔ࡚ࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠪࠪา฼ษࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ࠰๋ࠬไโࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆฬ๋ๅึ࠭ࠩࠋࠋࠌࡶࡪࡺࡵࡳࡰࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠣࠤࠥ∨")
	# l1111l111l_l1_ https://l111l11l1l_l1_.net/l11ll1l1l_l1_/?v=l11111l111_l1_&h=5de8bb072d336de05092297ec8b61643
	# l111ll1l11_l1_ https://l1111l1111_l1_.top/l1l11llll_l1_/l111ll111l_l1_/?l111l1llll_l1_=44711370a2655b3f2d23487cb74c05e5347648e8bb9571dfa7c5d5e4zlllsCGMDslElsMaYXobviuROhYfamfMOhlsEslsWQUlslElsMOcSbzMykqapaqlsEslsxMcGlslElsOGsabiZusOxySMgOpEaucSxiSVGEBOlOouQzsEslsxWdlslElsmmmlRPMMslnfpaqlsEslsCMcGlslElsOEOEEZlEMOuzslh
	l1lll1ll_l1_,l1111_l1_ = [],[]
	# l11ll1l1l_l1_ & download links
	#l1111l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ∩"),html,re.DOTALL)
	l1111l111l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡺࡺ࡯࠮ࡵ࡬ࡾࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ∪"),html,re.DOTALL)
	if l1111l111l_l1_:
		l1111l111l_l1_ = server+l1111l111l_l1_[0]		#+l11lll_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲࠻࠾࠴࠱࠷࠷࠱࠶࠹࠸࠮࠹࠶࠽࠸࠶࠺࠵ࠨ∫")
		#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭∬"),l11lll_l1_ (u"࠭ࠧ∭"),l11lll_l1_ (u"ࠧࠨ∮"),l1111l111l_l1_)
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ∯"),l1111l111l_l1_,l11lll_l1_ (u"ࠩࠪ∰"),headers,l11lll_l1_ (u"ࠪࠫ∱"),l11lll_l1_ (u"ࠫࠬ∲"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ∳"))
		l11lll1l_l1_ = response.content
		#WRITE_THIS(l11lll1l_l1_)
		if l11lll_l1_ (u"࠭ࡤࡰࡵࡷࡶࡪࡧ࡭ࠨ∴") not in l11lll1l_l1_:
			l1111lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡵࡦࡶ࡮ࡶࡴ࠯ࠬࡂࡂ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭∵"),l11lll1l_l1_,re.DOTALL)
			l1111lll11_l1_ = l1111lll11_l1_[0]
			result = l111111l11_l1_(l1111lll11_l1_)
			try: l1lllll1ll1_l1_,l1lllllll11_l1_,l111ll11ll_l1_ = result
			except:
				DIALOG_OK(l11lll_l1_ (u"ࠨࠩ∶"),l11lll_l1_ (u"ࠩࠪ∷"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭∸"),l11lll_l1_ (u"้๊ࠫริใࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ࠴ࠠใัࠣ๎่๎ๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡไส้ࠥฮสฮัํฯࠥ฻แฮษอ๋ࠥ๎วๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠใำสลฮࠦวๅืไัฬะࠠศๆฯำ๏ีษࠨ∹"))
				return
			l1lllllll11_l1_ = server+l1lllllll11_l1_
			l1lllll1ll1_l1_ = server+l1lllll1ll1_l1_
			cookies = response.cookies
			if l11lll_l1_ (u"ࠬࡖࡓࡔࡋࡇࠫ∺") in cookies.keys():
				l1llllll1ll_l1_ = cookies[l11lll_l1_ (u"࠭ࡐࡔࡕࡌࡈࠬ∻")]
				#headers = {l11lll_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ∼"):l1l11l11l_l1_(),l11lll_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ∽"):l11lll_l1_ (u"ࠩࡓࡗࡘࡏࡄ࠾ࠩ∾")+l1llllll1ll_l1_}
				headers[l11lll_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ∿")] = l11lll_l1_ (u"ࠫࡕ࡙ࡓࡊࡆࡀࠫ≀")+l1llllll1ll_l1_
				l11lll_l1_ (u"ࠧࠨࠢࠋࠋࠌࠍࠎࡧࡵࡵࡪࡸࡶࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࠋ࡬ࡪࠥࡧࡵࡵࡪࡸࡶࡱࡀࠊࠊࠋࠌࠍࠎࡧࡵࡵࡪࡸࡶࡱࠦ࠽ࠡࡵࡨࡶࡻ࡫ࡲࠬࡣࡸࡸ࡭ࡻࡲ࡭࡝࠳ࡡࠏࠏࠉࠊࠋࠌࠧࡦࡻࡴࡩࡷࡵࡰࠥࡃࠠࡢࡷࡷ࡬ࡺࡸ࡬ࠬࠩࠩࡺࡂ࠷ࠧࠋࠋࠌࠍࠎࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾ࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ࠼ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠭࠯ࡽࠋࠋࠌࠍࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡎࡐࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡢࡷࡷ࡬ࡺࡸ࡬࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨࠫࠍࠍࠎࠏࠉࠊࡪࡷࡱࡱ࠹ࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࠉࠊࠋࠌࡧࡴࡵ࡫ࡪࡧࡶࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡳࡰ࡯ࡥࡴࠌࠌࠍࠎࠏࠉࡪࡨࠣࠫࡕ࡙ࡓࡊࡆࠪࠤ࡮ࡴࠠࡤࡱࡲ࡯࡮࡫ࡳ࠯࡭ࡨࡽࡸ࠮ࠩ࠻ࠢࠍࠍࠎࠏࠉࠊࠋࡓࡗࡘࡏࡄࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡖࡓࡔࡋࡇࠫࡢࠐࠉࠊࠋࠌࠍࠎ࡮ࡥࡢࡦࡨࡶࡸࡡࠧࡄࡱࡲ࡯࡮࡫ࠧ࡞ࠢࡀࠤࠬࡖࡓࡔࡋࡇࡁࠬ࠱ࡐࡔࡕࡌࡈࠏࠏࠉࠊࠋࠌࠧ࡜ࡘࡉࡕࡇࡢࡘࡍࡏࡓࠩࡪࡷࡱࡱ࠹ࠩࠋࠋࠌࠍࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࡮ࡴ࡮࡮࠶࠭ࠏࠏࠉࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࡵࡷࡶ࠭࡮ࡴ࡮࡮࠶࠭࠮ࠐࠉࠊࠋࠌࠦࠧࠨ≁")
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ≂"),l1lllll1ll1_l1_,l11lll_l1_ (u"ࠧࠨ≃"),headers,l11lll_l1_ (u"ࠨࠩ≄"),l11lll_l1_ (u"ࠩࠪ≅"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭≆"))
				#headers = l11lll_l1_ (u"ࠫࠬ≇")
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ≈"),l1lllllll11_l1_,l111ll11ll_l1_,headers,l11lll_l1_ (u"࠭ࠧ≉"),l11lll_l1_ (u"ࠧࠨ≊"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ≋"))
				response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭≌"),l1111l111l_l1_,l11lll_l1_ (u"ࠪࠫ≍"),headers,l11lll_l1_ (u"ࠫࠬ≎"),l11lll_l1_ (u"ࠬ࠭≏"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠻ࡴࡩࠩ≐"))
				l11lll1l_l1_ = response.content
		l1llll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ≑"),l11lll1l_l1_,re.DOTALL)
		if l1llll1l1_l1_:
			l1llll1l1_l1_ = server+l1llll1l1_l1_[0]
			l1lll1ll_l1_,l1111_l1_ = l11ll11l11_l1_(l1llll1l1_l1_,headers)
			#LOG_THIS(l11lll_l1_ (u"ࠨࠩ≒"),str(l1lll1ll_l1_))
			zz = zip(l1lll1ll_l1_,l1111_l1_)
			l1lll1ll_l1_,l1111_l1_ = [],[]
			for title,link in zz:
				l11l111l_l1_ = title.split(l11lll_l1_ (u"ࠩࠣࠤࠬ≓"))[1]
				# l11ll1l1l_l1_ links
				l1111_l1_.append(link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡺ࡮ࡪࡳࡵࡴࡨࡥࡲࡥ࡟ࡸࡣࡷࡧ࡭ࡥ࡟࡮࠵ࡸ࠼ࡤࡥࠧ≔")+l11l111l_l1_)
				# download links
				l111ll11l1_l1_ = link.replace(l11lll_l1_ (u"ࠫ࠴ࡹࡴࡳࡧࡤࡱ࠴࠭≕"),l11lll_l1_ (u"ࠬ࠵ࡤ࡭࠱ࠪ≖")).replace(l11lll_l1_ (u"࠭࠯ࡴࡶࡵࡩࡦࡳ࠮࡮࠵ࡸ࠼ࠬ≗"),l11lll_l1_ (u"ࠧࠨ≘"))
				l1111_l1_.append(l111ll11l1_l1_+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡸ࡬ࡨࡸࡺࡲࡦࡣࡰࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠ࡯ࡳ࠸ࡤࡥࠧ≙")+l11l111l_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠩࠪ≚"),str(l1111_l1_))
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็ๅ๏ี๊้ࠢส่๊์วิส࠽ࠫ≛"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ≜"),url)
	return
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋࠦࠤࡳ࡫ࡥࡥࠢࡤࡧࡨࡵࡵ࡯ࡶࠣࡹࡸ࡫ࡲ࠰ࡲࡤࡷࡸࠐࠉࠤࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡼࡵࡲ࡬ࠢ࡬ࡲࠥࡧ࡬࡭ࠢࡦࡳࡺࡴࡴࡳ࡫ࡨࡷࠏࠏࠣࠡࡦࡲࡻࡳࡲ࡯ࡢࡦ࠮ࡻࡦࡺࡣࡩࠢ࡯࡭ࡳࡱࡳࠋࠋࠦࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴࡮ࡦࡶ࠲ࡥࡵ࡯࠿ࡤࡣ࡯ࡰࡂࡖࡅࡆࡇ࡭ࡧࡎࡷࡅ࡫ࡇࡹࡉ࡯ࡳࡔࡱ࡬ࡈ࡝࡙ࡋࡶࡓ࡛ࡈࡉ࡞࡚ࡅ࡮ࡇࡈ࡮ࡻࡰࡅ࡫ࡇࡊࡱࡊࡰࡅࡷࡇ࡭࡬ࡐࡧࡰࡆࡪࡄࡧࡨࡰࡣࡖࡅࡺ࡝ࡊࡴࡤࡦ࡬ࡹ࡮ࡊࡰࡸࡊࡣ࡭ࡉࡻࡋࡪࡧࡋࡤࡍࡽࡏࡥࡎࡪࡹ࡝ࡊࡰࡶ࡫ࡇ࡭ࡻ࡫ࡹࡢࡤࡋࡳࡻࡪࡰࡅࡷ࡯ࡗࡦࡲ࡚ࡅ࡮ࡸࡹࡒࡧࡳࡢ࡮ࡤࡰࡌ࡯ࡋࡪࡵࡣࡈ࡮ࡊࡼࡅ࡫࡯ࡗࡴࡧࡽࡦࡏࡤࡰࡘࡦࡰࡶ࡫ࡇ࡭ࡴࡐࡖࡅ࡫ࡇࡹࡉ࡯ࡩ࡭ࡊࡰࡧࡩࡨ࡟ࡰࡌࡪࡻࡈࡊࡰࡶ࡫ࡇ࡭ࡧࡎࡾࡅ࡫ࡇࡹࡉ࡯ࡳ࡙࡚ࡖࡗࡘࡦࡰࡅࡣࠨࡤࡹࡹ࡮࠽࠱࠻ࡥ࠹ࡨ࠸࠷࠳࠷࠺࠺࠶࡫࠱࠵࠻ࡩ࠺࠼࠷࠸࠳࠹ࡦ࠹࠽ࡩ࠴࠳࠷࠹ࡦࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡁ࠵ࡴࡩࡧࡤࡨࡃࠦ࠼ࡵࡤࡲࡨࡾࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠥࡂ࠯ࡴࡲࡤࡲࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡂ࠯ࡵࡦࡁࠤࡁࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡶࡻࡡ࡭࡫ࡷࡽ࠱ࡲࡩ࡯࡭࠴࠰ࡱ࡯࡮࡬࠴ࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࡳࡸࡥࡱ࡯ࡴࡺࠢࡀࠤࡶࡻࡡ࡭࡫ࡷࡽ࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪ࠰ࡶࡴࡱ࡯ࡴࠩࠩࠣࠫ࠮ࡡ࠭࠲࡟ࠍࠍࠎࡻࡲ࡭࠳ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬ࡮࡬ࡲࡰ࠷ࠠࠤࠢ࠮ࠤࠬࠬࡶ࠾࠳ࠪࠎࠎࠏࡵࡳ࡮࠵ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭࡯࡭ࡳࡱ࠲ࠡࠥࠣ࠯ࠥ࠭ࠦࡷ࠿࠴ࠫࠏࠏࠉࠤࡷࡵࡰࠥࡃࠠࡶࡴ࡯࠯ࠬࡅࡐࡉࡒࡖࡍࡉࡃࠧࠬࡒࡋࡔࡘࡏࡄࠋࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡻࡲ࡭࠳࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࡻ࡯ࡤࡴࡶࡵࡩࡦࡳ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡣࡲࡶ࠴ࡠࡡࠪ࠯ࡶࡻࡡ࡭࡫ࡷࡽ࠮ࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡹࡷࡲ࠲ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࡹ࡭ࡩࡹࡴࡳࡧࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣࠬ࠱ࡱࡶࡣ࡯࡭ࡹࡿࠩࠋࠋࠥࠦࠧ≝")
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠧࡨࡵ࡯࡬࡫ࡨࡷࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡴࡱࡩࡦࡵࠍࠍࠨࡖࡈࡑࡕࡌࡈࠥࡃࠠࡤࡱࡲ࡯࡮࡫ࡳ࡜ࠩࡓࡌࡕ࡙ࡉࡅࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸ࠸ࠠ࠾ࠢ࡫ࡩࡦࡪࡥࡳࡵ࠱ࡧࡴࡶࡹࠩࠫࠍࠍࠨ࡮ࡥࡢࡦࡨࡶࡸ࠸࡛ࠨࡅࡲࡳࡰ࡯ࡥࠨ࡟ࠣࡁࠥ࠭ࡐࡉࡒࡖࡍࡉࡃࠧࠬࡒࡋࡔࡘࡏࡄࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠵࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠳࠮ࡉࡥࡱࡹࡥ࠭ࠩࠪ࠰ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨࠫࠍࠍ࡭ࡺ࡭࡭࠴ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠷࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡸࡶࡱ࠹ࠠ࠾ࠢࡶࡩࡷࡼࡥࡳ࠭࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠭ࡻࡲ࡭࠵ࠬࠎࠎࠏࡺࠡ࠿ࠣࡾ࡮ࡶࠨࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࠐࠉࠊࡨࡲࡶࠥࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬ࠢ࡬ࡲࠥࢀ࠺ࠋࠋࠌࠍ࡮࡬ࠠࠨࡔࡨࡷ࠿ࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠤࡶࡻࡡ࡭࡫ࡷࡽࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࡒࡦࡵ࠽ࠤࠬ࠯࡛࠲࡟ࠍࠍࠎࠏࡥ࡭࡫ࡩࠤࠬࡈࡗ࠻ࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡲࡷࡤࡰ࡮ࡺࡹࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡶࡴࡱ࡯ࡴࠩࠩࡅ࡛࠿ࠦࠧࠪ࡝࠴ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡱࡢࡱࡵࠪ࠭ࡠ࠶࡝ࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡵࡺࡧ࡬ࡪࡶࡼࠤࡂࠦࠧࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠰࠭࠿࡯ࡣࡰࡩࡩࡃࡶࡪࡦࡶࡸࡷ࡫ࡡ࡮ࡡࡢࡻࡦࡺࡣࡩࡡࡢࡱ࠸ࡻ࠸ࡠࡡࠪ࠯ࡶࡻࡡ࡭࡫ࡷࡽ࠮ࠐࠉࠤࡧ࡯ࡷࡪࡀࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠸ࠫࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡸ࡬ࡨࡸࡺࡲࡦࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳ࠳ࡶ࠺ࠪ࠭ࠏࠏࠣࡪࡨࠣࡲࡴࡺࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠼ࠍࠍࠨࠏࡲࡦࡶࡸࡶࡳࠐࠉࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡡࡱ࡫ࡂࡧࡦࡲ࡬࠾ࠩࠣ࠯ࠥࡽࡡࡵࡥ࡫࡭ࡹ࡫࡭࡜࠲ࡠࠎࠎࡋࡇࡖࡆࡌ࠰ࠥࡋࡇࡖࡕࡌࡈ࠱ࠦࡅࡈࡗࡖࡗࠥࡃࠠࡈࡇࡗࡣࡕࡒࡁ࡚ࡡࡗࡓࡐࡋࡎࡔࠪࠬࠎࠎ࡯ࡦࠡࡇࡊ࡙ࡉࡏ࠽࠾ࠩࠪ࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࠽ࠫࡌࡵ࡯ࡨ࡮ࡨࡦࡴࡺ࠯࠳࠰࠴ࠤ࠭࠱ࡨࡵࡶࡳ࠭ࠬ࠲ࠠࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠠࠨࡅࡲࡳࡰ࡯ࡥࠨ࠼ࠪࡉࡌ࡛ࡄࡊ࠿ࠪ࠯ࡊࡍࡕࡅࡋ࠮ࠫࡀࠦࡅࡈࡗࡖࡍࡉࡃࠧࠬࡇࡊ࡙ࡘࡏࡄࠬࠩ࠾ࠤࡊࡍࡕࡔࡕࡀࠫ࠰ࡋࡇࡖࡕࡖࠤࢂࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࠥࡻࡲ࡭࠮ࠣࠫࠬ࠲ࠠࡩࡧࡤࡨࡪࡸࡳ࠭ࠢࡉࡥࡱࡹࡥ࠭ࠩࠪ࠰ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠤࡇ࡛ࡘ࠲࡞࠭ࡔࡖࡕࡉࡆࡓ࠮ࠫࡁࡕࡉࡘࡕࡌࡖࡖࡌࡓࡓࡃࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡦࡰࡴࠣࡵࡺࡧ࡬ࡵ࡫ࡼ࠰ࡺࡸ࡬ࠡ࡫ࡱࠤࡷ࡫ࡶࡦࡴࡶࡩࡩ࠮ࡩࡵࡧࡰࡷ࠮ࡀࠊࠊࠋࠌࡵࡺࡧ࡬ࡪࡶࡼࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠡࠪࠪࡱ࠸ࡻ࠸ࠡࠢࠣࠫ࠰ࡷࡵࡢ࡮ࡷ࡭ࡾ࠯ࠊࠊࠋࠌࡨࡦࡺࡡࡤࡣ࡯ࡰࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠢࠫࡹࡷࡲࠩࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ࠰ࠥࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩࠋࠋࠦ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࡁࠥ࠳࠱ࠡ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࠨࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡡࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࡟ࠍࠍ࡮࡬ࠠࠨࡪࡷࡸࡵ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡶࡴ࡯࠾ࠏࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡢࡲ࡬ࡃࡨࡧ࡬࡭࠿ࠪࠤ࠰ࠦ࡬ࡪࡰ࡮ࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࠽ࠫࡌࡵ࡯ࡨ࡮ࡨࡦࡴࡺ࠯࠳࠰࠴ࠤ࠭࠱ࡨࡵࡶࡳ࠭ࠬ࠲ࠠࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠠࠨࡅࡲࡳࡰ࡯ࡥࠨ࠼ࠪࡉࡌ࡛ࡄࡊ࠿ࠪ࠯ࡊࡍࡕࡅࡋ࠮ࠫࡀࠦࡅࡈࡗࡖࡍࡉࡃࠧࠬࡇࡊ࡙ࡘࡏࡄࠬࠩ࠾ࠤࡊࡍࡕࡔࡕࡀࠫ࠰ࡋࡇࡖࡕࡖࠤࢂࠐࠉࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࠦࡵࡳ࡮࠯ࠤࠬ࠭ࠬࠡࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠣࡊࡦࡲࡳࡦ࠮ࠪࠫ࠱࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩࠬࠎࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡯࡭ࡳࡱࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࠏࠣࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡡࡱ࡫ࡂࡧࡦࡲ࡬࠾ࠩࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠩࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤ࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࠽ࠫࡌࡵ࡯ࡨ࡮ࡨࡦࡴࡺ࠯࠳࠰࠴ࠤ࠭࠱ࡨࡵࡶࡳ࠭ࠬ࠲ࠠࠨࡔࡨࡪࡪࡸࡥࡳࠩ࠽ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠠࠨࡅࡲࡳࡰ࡯ࡥࠨ࠼ࠪࡉࡌ࡛ࡄࡊ࠿ࠪ࠯ࡊࡍࡕࡅࡋ࠮ࠫࡀࠦࡅࡈࡗࡖࡍࡉࡃࠧࠬࡇࡊ࡙ࡘࡏࡄࠬࠩ࠾ࠤࡊࡍࡕࡔࡕࡀࠫ࠰ࡋࡇࡖࡕࡖࠤࢂࠐࠉࠊࠥࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࠠࡶࡴ࡯࠰ࠥ࠭ࠧ࠭ࠢ࡫ࡩࡦࡪࡥࡳࡵ࠯ࠤࡋࡧ࡬ࡴࡧ࠯ࠫࠬ࠲ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ࠭ࠏࠏࠉࠤࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࠏࠣࡹࡤࡰࡧ࠳ࡲ࡯ࡨࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪ࡫ࡸࡲࡲࠩ࠭ࠢ࡯ࡩࡻ࡫࡬࠾ࡺࡥࡱࡨ࠴ࡌࡐࡉࡑࡓ࡙ࡏࡃࡆࠫࠍࠍࠎࠩࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡹࡷࡲࠠ࠾ࠢ࡬ࡸࡪࡳࡳ࡜࠲ࡠࠎࠎࠏࠣࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠨࡻࡲ࡭ࠢࡀࠤ࡮ࡺࡥ࡮ࡵ࡞࠴ࡢࠐࠉࡶࡴ࡯ࠤࡂࠦࡵࡳ࡮࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠥࡵࡩࡸࡻ࡬ࡵࠢࡀࠤࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏࠩࡷࡵࡰ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠯ࠫࡻ࡯ࡤࡦࡱࠪ࠭ࠏࠏࠢࠣࠤ≞")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨ≟"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩ≠"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠩࠣࠫ≡"),l11lll_l1_ (u"ࠪ࠯ࠬ≢"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࡲ࠿ࠪ≣") + l111l1l_l1_
	l1111l_l1_(url)
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
l1l11lll_l1_ = [l11lll_l1_ (u"ࠬอไ็๊฼ࠫ≤"),l11lll_l1_ (u"࠭วๅี้อࠬ≥"),l11lll_l1_ (u"ࠧศๆห่ิ࠭≦")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠨษ็ื๋ฯࠧ≧"),l11lll_l1_ (u"ࠩส่้เษࠨ≨"),l11lll_l1_ (u"ࠪห้ฮไะࠩ≩"),l11lll_l1_ (u"ࠫฬ๊ฯใหࠪ≪"),l11lll_l1_ (u"ࠬอไอ๊าอࠬ≫"),l11lll_l1_ (u"࠭วๅฬิะ๊ฯࠧ≬"),l11lll_l1_ (u"ࠧศๆ้์฾࠭≭"),l11lll_l1_ (u"ࠨษ็ฮฺ์๊โࠩ≮")]
l1l1l1_l1_ = []
def l11111ll1_l1_(url):		# should be l1llllllll1_l1_ to match l1l1ll11_l1_ l111l1ll1l_l1_
	url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭≯"))[0]
	#server = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ≰"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ≱"),url,l11lll_l1_ (u"ࠬ࠭≲"),headers,l11lll_l1_ (u"࠭ࠧ≳"),l11lll_l1_ (u"ࠧࠨ≴"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ≵"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡶࡴࡶࡤࡰࡹࡱࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸࠨࠧ≶"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	zz = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡺࡸࡲࡦࡰࡷࡣࡴࡶࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ≷"),block,re.DOTALL)
	l111l1l111_l1_,l111l111l1_l1_ = zip(*zz)
	l1lll11l_l1_ = zip(l111l1l111_l1_,l111l111l1_l1_,l111l1l111_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):		# should be l1llllllll1_l1_ to match l1l1ll11_l1_ l111l1ll1l_l1_
	# value + name
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ≸"),block,re.DOTALL)
	l1lllll1lll_l1_ = []
	for link,name in items:
		name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ≹"))
		value = link.rsplit(l11lll_l1_ (u"࠭࠯ࠨ≺"),1)[1]
		if name in l1l1l1_l1_: continue
		if l11lll_l1_ (u"ࠧๅๆๆฬฬืࠧ≻") in name: continue
		if l11lll_l1_ (u"ࠨࡖ࡙࠱ࡒࡇࠧ≼") in name: continue
		if l11lll_l1_ (u"ࠩࡗ࡚࠲࠷࠴ࠨ≽") in name: continue
		#if value==l11lll_l1_ (u"ࠪ࠵࠾࠼࠵࠴࠵ࠪ≾"): name = l11lll_l1_ (u"ࠫศ็ไศ็๊ࠣ๏ะแๅๅึࠫ≿")
		#elif value==l11lll_l1_ (u"ࠬ࠷࠹࠷࠷࠶࠵ࠬ⊀"): name = l11lll_l1_ (u"࠭ๅิๆึ่ฬะࠠ็์อๅ้้ำࠨ⊁")
		#if l11lll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭⊂") not in value: value = name
		#else: value = re.findall(l11lll_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩࠣࠩ⊃"),value,re.DOTALL)[0]
		l1lllll1lll_l1_.append((value,name))
	return l1lllll1lll_l1_
def l11111ll11_l1_(l1l1llll_l1_,url):		# should be l1llllllll1_l1_ to match l1l1ll11_l1_ l111l1ll1l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⊄"),l11lll_l1_ (u"ࠪࠫ⊅"),l11lll_l1_ (u"ࠫࡌࡋࡔࡠࡈࡌࡒࡆࡒ࡟ࡖࡔࡏࡣࡤࡥࡉࡏࠩ⊆"),l1l1llll_l1_+l11lll_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ⊇")+url)
	url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⊈"),1)[0]
	url = url.strip(l11lll_l1_ (u"ࠧ࠰ࠩ⊉"))
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ⊊"))		# l1llllll1l1_l1_ be l1llllllll1_l1_
	l1l1111l_l1_ = l1l1111l_l1_.replace(l11lll_l1_ (u"ࠩࠣ࠯ࠥ࠭⊋"),l11lll_l1_ (u"ࠪ࠱ࠬ⊌"))
	url = url+l11lll_l1_ (u"ࠫ࠴࠭⊍")+l1l1111l_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⊎"),l11lll_l1_ (u"࠭ࠧ⊏"),l11lll_l1_ (u"ࠧࡈࡇࡗࡣࡋࡏࡎࡂࡎࡢ࡙ࡗࡒ࡟ࡠࡡࡒ࡙࡙࠭⊐"),url)
	return url
def l1lll1l1_l1_(url,filter):		# l1111l1l11_l1_ l111111ll1_l1_ l111l11l11_l1_ minor l1llllll111_l1_ l1l1l1ll1l_l1_ it is l1111lll1l_l1_ not to l11l1111ll_l1_ l111l1ll11_l1_ all
	#filter = filter.replace(l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⊑"),l11lll_l1_ (u"ࠩࠪ⊒"))
	if l11lll_l1_ (u"ࠪࡃࠬ⊓") in url: url = url.split(l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⊔"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ⊕"),1)
	if filter==l11lll_l1_ (u"࠭ࠧ⊖"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠧࠨ⊗"),l11lll_l1_ (u"ࠨࠩ⊘")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭⊙"))
	if type==l11lll_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⊚"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠫࡂ࠭⊛") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠬࡃࠧ⊜") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ⊝")+category+l11lll_l1_ (u"ࠧ࠾࠲ࠪ⊞")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ⊟")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⊠")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠪࠪࠬ⊡"))+l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ⊢")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ⊣"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⊤")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⊥")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠨࡃࡏࡐࡤࡏࡔࡆࡏࡖࡣࡋࡏࡌࡕࡇࡕࠫ⊦"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ⊧")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_: l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⊨")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		if not l1l11l11_l1_: l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⊩")+l1l11l11_l1_
		l11l1l1_l1_ = l11111ll11_l1_(l1l11l11_l1_,l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⊪"),l111ll_l1_+l11lll_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩ⊫"),l11l1l1_l1_,121)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊬"),l111ll_l1_+l11lll_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ⊭")+l11lll11_l1_+l11lll_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ⊮"),l11l1l1_l1_,121)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⊯"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⊰"),l11lll_l1_ (u"ࠬ࠭⊱"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		l1ll1lll_l1_ = l1ll1lll_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ⊲"))
		name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ⊳"))
		name = name.replace(l11lll_l1_ (u"ࠨ࠯࠰ࠫ⊴"),l11lll_l1_ (u"ࠩࠪ⊵"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠪࡁࠬ⊶") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⊷"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					l11l1l1_l1_ = l11111ll11_l1_(l1l11l11_l1_,url)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⊸")+l1l1l11l_l1_)
				return
			else:
				l11l1l1_l1_ = l11111ll11_l1_(l1l11l11_l1_,l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊹"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ⊺"),l11l1l1_l1_,121)
				else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊻"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ⊼"),l11l11l_l1_,125,l11lll_l1_ (u"ࠪࠫ⊽"),l11lll_l1_ (u"ࠫࠬ⊾"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ⊿"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ⋀")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠲ࠪ⋁")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠨࠨࠪ⋂")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀ࠴ࠬ⋃")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠪࡣࡤࡥࠧ⋄")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋅"),l111ll_l1_+l11lll_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ⋆")+name,l11l11l_l1_,124,l11lll_l1_ (u"࠭ࠧ⋇"),l11lll_l1_ (u"ࠧࠨ⋈"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⋉"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⋊")+l1ll1lll_l1_+l11lll_l1_ (u"ࠪࡁࠬ⋋")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫ࠭⋌")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃࠧ⋍")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⋎")+l1l1llll_l1_
			#title = option+l11lll_l1_ (u"ࠧࠡ࠼ࠪ⋏")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠨ࠲ࠪ⋐")]
			title = option+l11lll_l1_ (u"ࠩࠣ࠾ࠬ⋑")+name
			if type==l11lll_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⋒"): addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋓"),l111ll_l1_+title,url,124,l11lll_l1_ (u"ࠬ࠭⋔"),l11lll_l1_ (u"࠭ࠧ⋕"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⋖"))
			elif type==l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⋗") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠩࡀࠫ⋘") in l1l11l1l_l1_:
				l11l1l1_l1_ = l11111ll11_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋙"),l111ll_l1_+title,l11l1l1_l1_,121)
			else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋚"),l111ll_l1_+title,url,125,l11lll_l1_ (u"ࠬ࠭⋛"),l11lll_l1_ (u"࠭ࠧ⋜"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):		# l1111l11l1_l1_ not l11l1111ll_l1_ l11111111l_l1_ here
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ⋝")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⋞")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ⋟")			all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠪࡁࠫ࠭⋠"),l11lll_l1_ (u"ࠫࡂ࠶ࠦࠨ⋡"))
	filters = filters.strip(l11lll_l1_ (u"ࠬࠬࠧ⋢"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"࠭࠽ࠨ⋣") in filters:
		items = filters.split(l11lll_l1_ (u"ࠧࠧࠩ⋤"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠨ࠿ࠪ⋥"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠩࠪ⋦")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠪ࠴ࠬ⋧")
		if l11lll_l1_ (u"ࠫࠪ࠭⋨") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ⋩") and value!=l11lll_l1_ (u"࠭࠰ࠨ⋪"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ⋫")+value
		elif mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⋬") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ⋭"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ⋮")+key+l11lll_l1_ (u"ࠫࡂ࠭⋯")+value
		elif mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⋰"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ⋱")+key+l11lll_l1_ (u"ࠧ࠾ࠩ⋲")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠢ࠮ࠤࠬ⋳"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫ⋴"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠪࡁ࠵࠭⋵"),l11lll_l1_ (u"ࠫࡂ࠭⋶"))
	return l1ll1l1l_l1_
l11lll_l1_ (u"ࠧࠨࠢࠋࡦࡨࡪࠥࡍࡅࡕࡡࡘࡗࡊࡘࡎࡂࡏࡈࡣࡕࡇࡓࡔ࡙ࡒࡖࡉ࠮ࠩ࠻ࠌࠌࡸࡪࡾࡴࠡ࠿ࠣࠫ์ึวࠡษ็้ํู่ࠡ์ะฮฬาࠠศี่ࠤิิ่ๅ๋ࠢ็้๋ษࠡษ็ืึࠦไไ์ࠣฮุะื๋฻ࠣฮูเ๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้࠰่้ࠣำี้ๆࠣ฽้๐็ๆࠢๅ้ࠥฮแหฯࠣัุอศࠡ็ฯห๋๐ࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪࠎࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨษ็้ํู่ࠡษ็หฺ๊๊ࠡࠢࠪ࠯ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࡵࡧࡻࡸ࠮ࠐࠉࡰ࡮ࡧࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠥࡃࠠࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡪࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡺࡹࡥࡳࠩࠬࠎࠎࡵ࡬ࡥࡲࡤࡷࡸࡽ࡯ࡳࡦࠣࡁࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡨࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡳࡥࡸࡹࠧࠪࠌࠌࡼࡧࡳࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࡤࡸ࡭ࡱࡺࡩ࡯ࠪࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠧࡶ࠭ࠬࠦࠥࡢࡦࡧࡳࡳࡥࡩࡥ࠮ࠣࡘࡷࡻࡥࠪࠌࠌࡲࡪࡽࡵࡴࡧࡵࡲࡦࡳࡥࠡ࠿ࠣࡷࡪࡺࡴࡪࡰࡪࡷ࠳࡭ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡶࡵࡨࡶࠬ࠯ࠊࠊࡰࡨࡻࡵࡧࡳࡴࡹࡲࡶࡩࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡶࡡࡴࡵࠪ࠭ࠏࠏࡩࡧࠢࡲࡰࡩࡻࡳࡦࡴࡱࡥࡲ࡫ࠡ࠾ࡰࡨࡻࡺࡹࡥࡳࡰࡤࡱࡪࠦ࡯ࡳࠢࡲࡰࡩࡶࡡࡴࡵࡺࡳࡷࡪࠡ࠾ࡰࡨࡻࡵࡧࡳࡴࡹࡲࡶࡩࡀࠊࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡇࡍࠬ࠲ࠧࠨࠫࠍࠍࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚࡙ࡉࡅࠩ࠯ࠫࠬ࠯ࠊࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡖࡗࠬ࠲ࠧࠨࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠏࡪࡥࡧࠢࡊࡉ࡙ࡥࡐࡍࡃ࡜ࡣ࡙ࡕࡋࡆࡐࡖࠬ࠮ࡀࠊࠊࡇࡊ࡙ࡉࡏࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡇࡍࠬ࠯ࠊࠊࡇࡊ࡙ࡘࡏࡄࠡ࠿ࠣࡷࡪࡺࡴࡪࡰࡪࡷ࠳࡭ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡥࡻ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡆࡉࡘࡗࡎࡊࠧࠪࠌࠌࡉࡌ࡛ࡓࡔࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡇࡊ࡙ࡘ࡙ࠧࠪࠌࠌࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠥࡃࠠࡎࡋ࡛ࡣࡆࡘࡁࡃࡋࡆࠬࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡷࡶࡩࡷ࠭ࠩࠪࠌࠌࡴࡦࡹࡳࡸࡱࡵࡨࠥࡃࠠࡎࡋ࡛ࡣࡆࡘࡁࡃࡋࡆࠬࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡲࡤࡷࡸ࠭ࠩࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡵࡴࡧࡵࡲࡦࡳࡥ࠭ࡲࡤࡷࡸࡽ࡯ࡳࡦࠬࠎࠎ࡯ࡦࠡࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࡁࠬ࠭ࠠࡰࡴࠣࡴࡦࡹࡳࡸࡱࡵࡨࡂࡃࠧࠨ࠼ࠍࠍࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚ࡊࡉࠨ࠮ࠪࠫ࠮ࠐࠉࠊࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡷࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡣࡹ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡋࡇࡖࡕࡌࡈࠬ࠲ࠧࠨࠫࠍࠍࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚࡙ࡓࠨ࠮ࠪࠫ࠮ࠐࠉࠊࡉࡈࡘࡤ࡛ࡓࡆࡔࡑࡅࡒࡋ࡟ࡑࡃࡖࡗ࡜ࡕࡒࡅࠪࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳ࡛ࠦࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࡟ࠍࠍ࡮࡬ࠠࡆࡉࡘࡈࡎࠧ࠽ࠨࠩ࠽ࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹࠠ࠾ࠢࡾࠤࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠧࡆࡉࡘࡈࡎࡃࠧࠬࡇࡊ࡙ࡉࡏࠫࠨ࠽ࠣࡉࡌ࡛ࡓࡊࡆࡀࠫ࠰ࡋࡇࡖࡕࡌࡈ࠰࠭࠻ࠡࡇࡊ࡙ࡘ࡙࠽ࠨ࠭ࡈࡋ࡚࡙ࡓࠡࡿࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠠࠨࠩ࠯ࠤ࡭࡫ࡡࡥࡧࡵࡷ࠱ࠦࡆࡢ࡮ࡶࡩ࠱࠭ࠧ࠭ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡋࡊ࡚࡟ࡑࡎࡄ࡝ࡤ࡚ࡏࡌࡇࡑࡗ࠲࠷ࡳࡵࠩࠬࠎࠎࠏࡲࡦࡩ࡬ࡷࡹ࡫ࡲࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡵࡶࡰ࠳࡫ࡧࡦࡺࡤ࠲ࡨࡵ࡭࡝࠱ࡵࡩ࡬࡯ࡳࡵࡧࡵࠫ࠱ࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡶࡪ࡭ࡩࡴࡶࡨࡶ࠿ࠐࠉࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩࡤࡺ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡅࡈࡗࡇࡍࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡡࡷ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡉࡌ࡛ࡓࡊࡆࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡳࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡇࡊ࡙ࡘ࡙ࠧ࠭ࠩࠪ࠭ࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱࠭࡮ࡰࠢࡱࡩࡼࠦ࡬ࡰࡩ࡬ࡲࠥࡴࡥࡦࡦࡨࡨ࠱ࠦࡹࡰࡷࠣࡻࡪࡸࡥࠡࡣ࡯ࡶࡪࡧࡤࡺࠢ࡯ࡳ࡬࡭ࡥࡥࠢ࡬ࡲࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࡲࡦࡶࡸࡶࡳ࡛ࠦࠡࡇࡊ࡙ࡉࡏࠬࠡࡇࡊ࡙ࡘࡏࡄ࠭ࠢࡈࡋ࡚࡙ࡓࠡ࡟ࠍࠍࡨ࡮ࡡࡳࡡࡶࡩࡹࠦ࠽ࠡࡵࡷࡶ࡮ࡴࡧ࠯ࡣࡶࡧ࡮࡯࡟ࡶࡲࡳࡩࡷࡩࡡࡴࡧࠣ࠯ࠥࡹࡴࡳ࡫ࡱ࡫࠳ࡪࡩࡨ࡫ࡷࡷࠥ࠱ࠠࡴࡶࡵ࡭ࡳ࡭࠮ࡢࡵࡦ࡭࡮ࡥ࡬ࡰࡹࡨࡶࡨࡧࡳࡦࠌࠌࡶࡦࡴࡤࡰ࡯ࡖࡸࡷ࡯࡮ࡨࠢࡀࠤࠬ࠭࠮࡫ࡱ࡬ࡲ࠭ࡸࡡ࡯ࡦࡲࡱ࠳ࡹࡡ࡮ࡲ࡯ࡩ࠭ࡩࡨࡢࡴࡢࡷࡪࡺࠪ࠲࠷࠯ࠤ࠶࠻ࠩࠪࠌࠌࡹࡷࡲࠠ࠾ࠢࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡹ࡬࠯ࡧࡪࡩࡽࡧ࠮ࡤࡱࡰ࠳ࡱࡵࡧࡪࡰ࠲ࠦࠏࠏࠣࡳࡧࡦࡥࡵࡺࡣࡩࡣࠣࡁࠥ࠭࠰࠴ࡃࡒࡐ࡙ࡈࡌࡒࡆࡷࡱࡪࡏࡣࡕ࠺ࡏ࠹࠾ࡊࡰࡻࡰࡊ࠴ࡵ࠷ࡗࡄ࡭࡫࡬ࡺࡳࡨࡦ࡭ࡤࡱ࡝ࡕࡤࡂ࠳࡮࠽ࡐ࠼ࡣࡔࡷࡢࡉ࡞ࡧࡴࡷ࡬ࡋ࠱ࡗࡶ࡫ࡉࡰࡔ࡬࠹࡚ࡋࡩࡌ࡯࠼ࡗ࡜ࡶࡴࡡ࡬ࡴࡽࡰࡣ࠷࡬ࡌࡩࡆ࡟ࡒࡥࡤࡪࡩࡤࡍࡲࡒࡦࡹࡘ࠹ࡽࡈࡘ࡯ࡢࡐࡻ࠼ࡌ࠳࠵࡝ࡉ࡬ࡌࡏ࡭ࡺ࡫ࡥࡻ࡜ࡨࡸࡪࡴ࠶ࡔ࡫ࡄࡈࡍ࠰ࡦࡴࡴࡓࡔࡕࡌ࡙࠹ࡷࡩࡉࡑࡷࡖ࡫ࡨࡷࡘ࠺ࡍࡪࡍࡔ࠭ࡊࡼࡻࡦ࠲࡚ࡸࡎ࠸ࡒ࡛࡟ࡒ࠲࡫ࡷࡋࡽ࡬ࡲࡪ࡮ࡈࡆ࡮ࡋ࡞࠵ࡆࡡࡷࡪ࡞࠸ࡘࡋࡸࡐࡵࡌ࡙ࡪࡩࡈࡤ࠹ࡽ࡟ࡷࡢࡶ࡛࠱ࡨࡳࡰ࡙࠹࡛࠴ࡒࡿ࠹ࡒ࠹ࡰ࡯ࡵࡻ࠸࠷ࡃ࠰ࡎࡲ࡞ࡴࡤࡱࡷࡧ࡝ࡵࡎ࠷࡙ࡄࡱ࡛ࡽࡕ࡚ࡱࡰࡐࡕࡖ࡙ࡹࡲࡩࡥࡵࡐ࡮ࡧ࡙࡛࠷ࡇࡽ࠸࠴࠵࡜ࡏࡉࡥࡂࡅ࡙ࡺࡺ࡙࡞ࡪࡧ࡙ࡢࡔࡪࡔࡕࡥࡌࡋ࠻ࡋࡽࡌ࠺ࡶࡱ࠹ࡤ࡭ࡨࡅࡳ࡙ࡩࡤࡲࡑ࡬ࡪࡳ࠺ࡴࡵࡘ࡮ࡘࡷ࡮ࡒࡇ࡮࠺ࡡࡐ࠸ࠬࠐࠉࠤࡴࡨࡧࡦࡶࡴࡤࡪࡤࠤࡂࠦࠧࠨࠌࠌࡴࡦࡿ࡬ࡰࡣࡧࠤࡂࠦࠢࠣࠌࠌࡴࡦࡿ࡬ࡰࡣࡧࠤ࠰ࡃࠠࠣ࠯࠰࠱࠲࠳࠭ࡘࡧࡥࡏ࡮ࡺࡆࡰࡴࡰࡆࡴࡻ࡮ࡥࡣࡵࡽࠧ࠱ࡲࡢࡰࡧࡳࡲ࡙ࡴࡳ࡫ࡱ࡫࠰ࠨ࡜࡯ࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡇ࡭ࡸࡶ࡯ࡴ࡫ࡷ࡭ࡴࡴ࠺ࠡࡨࡲࡶࡲ࠳ࡤࡢࡶࡤ࠿ࠥࡴࡡ࡮ࡧࡀࡠࠧࡧࡪࡢࡺ࡟ࠦࡡࡴ࡜࡯࠳࡟ࡲࠧࠐࠉࡱࡣࡼࡰࡴࡧࡤࠡ࠭ࡀࠤࠧ࠳࠭࠮࠯࠰࠱࡜࡫ࡢࡌ࡫ࡷࡊࡴࡸ࡭ࡃࡱࡸࡲࡩࡧࡲࡺࠤ࠮ࡶࡦࡴࡤࡰ࡯ࡖࡸࡷ࡯࡮ࡨ࠭ࠥࡠࡳࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡄࡪࡵࡳࡳࡸ࡯ࡴࡪࡱࡱ࠾ࠥ࡬࡯ࡳ࡯࠰ࡨࡦࡺࡡ࠼ࠢࡱࡥࡲ࡫࠽࡝ࠤࡧࡳࡡࠨ࡜࡯࡞ࡱࡰࡴ࡭ࡩ࡯࡞ࡱࠦࠏࠏࡰࡢࡻ࡯ࡳࡦࡪࠠࠬ࠿ࠣࠦ࠲࠳࠭࠮࠯࠰࡛ࡪࡨࡋࡪࡶࡉࡳࡷࡳࡂࡰࡷࡱࡨࡦࡸࡹࠣ࠭ࡵࡥࡳࡪ࡯࡮ࡕࡷࡶ࡮ࡴࡧࠬࠤ࡟ࡲࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡊࡩࡴࡲࡲࡷ࡮ࡺࡩࡰࡰ࠽ࠤ࡫ࡵࡲ࡮࠯ࡧࡥࡹࡧ࠻ࠡࡰࡤࡱࡪࡃ࡜ࠣࡧࡰࡥ࡮ࡲ࡜ࠣ࡞ࡱࡠࡳࠨࠫࡶࡵࡨࡶࡳࡧ࡭ࡦ࠭ࠥࡠࡳࠨࠊࠊࡲࡤࡽࡱࡵࡡࡥࠢ࠮ࡁࠥࠨ࠭࠮࠯࠰࠱࠲࡝ࡥࡣࡍ࡬ࡸࡋࡵࡲ࡮ࡄࡲࡹࡳࡪࡡࡳࡻࠥ࠯ࡷࡧ࡮ࡥࡱࡰࡗࡹࡸࡩ࡯ࡩ࠮ࠦࡡࡴࡃࡰࡰࡷࡩࡳࡺ࠭ࡅ࡫ࡶࡴࡴࡹࡩࡵ࡫ࡲࡲ࠿ࠦࡦࡰࡴࡰ࠱ࡩࡧࡴࡢ࠽ࠣࡲࡦࡳࡥ࠾࡞ࠥࡴࡦࡹࡳࡸࡱࡵࡨࡡࠨ࡜࡯࡞ࡱࠦ࠰ࡶࡡࡴࡵࡺࡳࡷࡪࠫࠣ࡞ࡱࠦࠏࠏࠣࡱࡣࡼࡰࡴࡧࡤࠡ࠭ࡀࠤࠧ࠳࠭࠮࠯࠰࠱࡜࡫ࡢࡌ࡫ࡷࡊࡴࡸ࡭ࡃࡱࡸࡲࡩࡧࡲࡺࠤ࠮ࡶࡦࡴࡤࡰ࡯ࡖࡸࡷ࡯࡮ࡨ࠭ࠥࡠࡳࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡄࡪࡵࡳࡳࡸ࡯ࡴࡪࡱࡱ࠾ࠥ࡬࡯ࡳ࡯࠰ࡨࡦࡺࡡ࠼ࠢࡱࡥࡲ࡫࠽࡝ࠤࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦ࡞ࠥࡠࡳࡢ࡮ࠣ࠭ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠰ࠨ࡜࡯ࠤࠍࠍࡵࡧࡹ࡭ࡱࡤࡨࠥ࠱࠽ࠡࠤ࠰࠱࠲࠳࠭࠮࡙ࡨࡦࡐ࡯ࡴࡇࡱࡵࡱࡇࡵࡵ࡯ࡦࡤࡶࡾࠨࠫࡳࡣࡱࡨࡴࡳࡓࡵࡴ࡬ࡲ࡬࠱ࠢ࡝ࡰࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡈ࡮ࡹࡰࡰࡵ࡬ࡸ࡮ࡵ࡮࠻ࠢࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦ࡮ࡢ࡯ࡨࡁࡡࠨࡶࡢ࡮ࡉࡳࡷࡳ࡜ࠣ࡞ࡱࡠࡳࡢ࡮ࠣࠌࠌࡴࡦࡿ࡬ࡰࡣࡧࠤ࠰ࡃࠠࠣ࠯࠰࠱࠲࠳࠭ࡘࡧࡥࡏ࡮ࡺࡆࡰࡴࡰࡆࡴࡻ࡮ࡥࡣࡵࡽࠧ࠱ࡲࡢࡰࡧࡳࡲ࡙ࡴࡳ࡫ࡱ࡫࠰ࠨ࠭࠮ࠤࠍࠍࠨࡾࡢ࡮ࡥ࠱ࡰࡴ࡭ࠨࡱࡣࡼࡰࡴࡧࡤ࠭ࠢ࡯ࡩࡻ࡫࡬࠾ࡺࡥࡱࡨ࠴ࡌࡐࡉࡑࡓ࡙ࡏࡃࡆࠫࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠌࠌࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࠾ࠥࠨ࡭ࡶ࡮ࡷ࡭ࡵࡧࡲࡵ࠱ࡩࡳࡷࡳ࠭ࡥࡣࡷࡥࡀࠦࡢࡰࡷࡱࡨࡦࡸࡹ࠾࠯࠰࠱࠲࡝ࡥࡣࡍ࡬ࡸࡋࡵࡲ࡮ࡄࡲࡹࡳࡪࡡࡳࡻࠥ࠯ࡷࡧ࡮ࡥࡱࡰࡗࡹࡸࡩ࡯ࡩ࠯ࠎࠎࠩࠧࡄࡱࡲ࡯࡮࡫ࠧ࠻ࠢࠥࡔࡘ࡙ࡉࡅ࠿ࠥ࠯ࡕ࡙ࡓࡊࡆ࠮ࠦࡀࠦࡊࡔࡡࡗࡍࡒࡋ࡚ࡐࡐࡈࡣࡔࡌࡆࡔࡇࡗࡁ࠶࠾࠰࠱࠲ࠥ࠰ࠏࠏࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ࠼ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡳ࡭࠰ࡨ࡫ࡪࡾࡡ࠯ࡥࡲࡱ࠴ࡲ࡯ࡨ࡫ࡱ࠳ࡄࡪ࡯࡮ࡣ࡬ࡲࡂ࠭ࠫࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠱ࡷࡵࡲࡩࡵࠪࠪ࠳࠴࠭ࠩ࡜࠳ࡠ࠯ࠬࠬࡵࡳ࡮ࡀࡶࡪ࡬ࠧࠋࠋࢀࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡕࡕࡓࡕࠩ࠯ࠤࡺࡸ࡬࠭ࠢࡳࡥࡾࡲ࡯ࡢࡦ࠯ࠤ࡭࡫ࡡࡥࡧࡵࡷ࠱ࠦࡆࡢ࡮ࡶࡩ࠱࠭ࠧ࠭ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡋࡊ࡚࡟ࡑࡎࡄ࡝ࡤ࡚ࡏࡌࡇࡑࡗ࠲࠸࡮ࡥࠩࠬࠎࠎࡩ࡯ࡰ࡭࡬ࡩࡸࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡵ࡫ࡪࡧࡶࠎࠎࠩࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷ࠰ࠥࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡔࡏࡕࡋࡆࡉ࠮ࠐࠉࡪࡨࠣࠫࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠢࡤࡣࡳࡸࡨ࡮ࡡࠣࠩࠣ࡭ࡳࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵ࠼ࠍࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨ็ื็้ฯࠠอัสࠤุู๊อหࠣฮำ฻ࠠอ้สึ่ࠦแใูࠪ࠰๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯ๊ࠦาใูࠤิิ่ๅๅࠣห้๐็ๆࠢหษุะฮะษ่ࠤ่๎ฯ๋ࠢ࠱࠲࠳ࠦอศ๊็ࠤๆ฻ไࠡษ็ห๋ะั็์อࠤํอูศัฬࠤึฮื่ษ่ࠣฯำีๅࠢ฼่๎ูࠦ็๊ส๊ࠥࡏࡐࠡฮา๎ิࠦ࠮࠯࠰ࠣหํࠦวฺัࠣห้๋อศ๊็อࠥฮูะࠢ฼ำฮࠦว๋ษ่ࠤฬ๎ฺࠠัฬࠤฬูวษ์฼ࠫ࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠡ࡝ࠪࠫ࠱࠭ࠧ࠭ࠩࠪࡡࠏࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡣࡰࡱ࡮࡭ࡪࡹࠩ࠽࠵࠽ࠎࠎࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱ุ่่๊࠭ࠧ࠭ࠩษࠡใํࠤฯูฬ๋ๆࠣห้ีฮ้ๆ่้๋่ࠣใ฻ࠪ࠰ࠬำว้ๆࠣหฺ๊วฮࠢสื๊ࠦวๅัั์้่ࠦไๆ่อࠥอไิำ่่ࠣ๐ࠠหฬ่็๋ࠦๅ็ࠢอุ฿๐ไࠡษ็ๅ๏ี๊้ࠢหูํืษࠡืะ๎าฯࠧࠪࠌࠌࠍࡌࡋࡔࡠࡗࡖࡉࡗࡔࡁࡎࡇࡢࡔࡆ࡙ࡓࡘࡑࡕࡈ࠭࠯ࠊࠊࠋࡵࡩࡹࡻࡲ࡯ࠢ࡞ࠫࠬ࠲ࠧࠨ࠮ࠪࠫࡢࠐࠉࡆࡉࡘࡈࡎࠦ࠽ࠡࡥࡲࡳࡰ࡯ࡥࡴ࡝ࠪࡉࡌ࡛ࡄࡊࠩࡠࠎࠎࡋࡇࡖࡕࡌࡈࠥࡃࠠࡤࡱࡲ࡯࡮࡫ࡳ࡜ࠩࡈࡋ࡚࡙ࡉࡅࠩࡠࠎࠎࡋࡇࡖࡕࡖࠤࡂࠦࡣࡰࡱ࡮࡭ࡪࡹ࡛ࠨࡇࡊ࡙ࡘ࡙ࠧ࡞ࠌࠌࡸ࡮ࡳࡥ࠯ࡵ࡯ࡩࡪࡶࠨ࠲ࠫࠍࠍࡺࡸ࡬ࠡ࠿ࠣࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡳ࡭࠰ࡨ࡫ࡪࡾࡡ࠯ࡥࡲࡱ࠴࡬ࡩ࡯࡫ࡶ࡬࠴ࠨࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀࠦࠧࡄࡱࡲ࡯࡮࡫ࠧ࠻ࠩࡈࡋ࡚ࡊࡉ࠾ࠩ࠮ࡉࡌ࡛ࡄࡊ࠭ࠪ࠿ࠥࡋࡇࡖࡕࡌࡈࡂ࠭ࠫࡆࡉࡘࡗࡎࡊࠫࠨ࠽ࠣࡉࡌ࡛ࡓࡔ࠿ࠪ࠯ࡊࡍࡕࡔࡕࠣࢁࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࠤࡺࡸ࡬࠭ࠢࠪࠫ࠱ࠦࡨࡦࡣࡧࡩࡷࡹࠬࠡࡖࡵࡹࡪ࠲ࠧࠨ࠮ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡌࡋࡔࡠࡒࡏࡅ࡞ࡥࡔࡐࡍࡈࡒࡘ࠳࠳ࡳࡦࠪ࠭ࠏࠏࡣࡰࡱ࡮࡭ࡪࡹࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡯࡬࡫ࡨࡷࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࠫࠬ࠲ࠧࠨ࠮ࡶࡸࡷ࠮ࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠫ࠯ࡷࡹࡸࠨࡤࡱࡲ࡯࡮࡫ࡳࠪࠫࠍࠍࡊࡍࡕࡅࡋࠣࡁࠥࡩ࡯ࡰ࡭࡬ࡩࡸࡡࠧࡆࡉࡘࡈࡎ࠭࡝ࠋࠋࡈࡋ࡚࡙ࡉࡅࠢࡀࠤࡨࡵ࡯࡬࡫ࡨࡷࡠ࠭ࡅࡈࡗࡖࡍࡉ࠭࡝ࠋࠋࡈࡋ࡚࡙ࡓࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡋࡇࡖࡕࡖࠫࡢࠐࠉࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡢࡸ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡊࡍࡕࡅࡋࠪ࠰ࡊࡍࡕࡅࡋࠬࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚࡙ࡉࡅࠩ࠯ࡉࡌ࡛ࡓࡊࡆࠬࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡈࡋ࡚࡙ࡓࠨ࠮ࡈࡋ࡚࡙ࡓࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࡴࡷࡦࡧࡪࡹࡳ࠭ࠢࡼࡳࡺࠦࡪࡶࡵࡷࠤࡱࡵࡧࡨࡧࡧࠤ࡮ࡴࠠ࡯ࡱࡺࠫ࠱࠭ࠧࠪࠌࠌࡶࡪࡺࡵࡳࡰࠣ࡟ࠥࡋࡇࡖࡆࡌ࠰ࠥࡋࡇࡖࡕࡌࡈ࠱ࠦࡅࡈࡗࡖࡗࠥࡣࠊࠣࠤࠥ⋷")
#===================================================================================================
# l11111l11l_l1_ of the below code l1lllllllll_l1_ added from:
# https://github.com/zombiB/zombi-addons/blob/master/plugin.video.matrix/resources/l111l11111_l1_/l111l11l1l_l1_.py
# https://gitlab.com/Rgysoft/iptv-host-e2iplayer/-/blob/master/IPTVPlayer/tsiplayer/l111111l1l_l1_/l1111l1l1l_l1_.py
#===================================================================================================
def l111l1l11l_l1_(l1lllllll1l_l1_):
	m = re.search(l11lll_l1_ (u"ࡸࠧ࡟ࠪ࡟ࡨ࠰࠯࡛࠯࠮ࡠࡃࡡࡪࠪࡀࠩ⋸"), str(l1lllllll1l_l1_))
	return int(m.groups()[-1]) if m and not callable(l1lllllll1l_l1_) else 0
def l111l1lll1_l1_(l11111ll1l_l1_):
	try:
		l1111lllll_l1_ = base64.b64decode(l11111ll1l_l1_)
	except:
		try:
			l1111lllll_l1_ = base64.b64decode(l11111ll1l_l1_+l11lll_l1_ (u"ࠧ࠾ࠩ⋹"))
		except:
			try:
				l1111lllll_l1_ = base64.b64decode(l11111ll1l_l1_+l11lll_l1_ (u"ࠨ࠿ࡀࠫ⋺"))
			except:
				l1111lllll_l1_ = l11lll_l1_ (u"ࠩࡈࡖࡗࡀࠠࡣࡣࡶࡩ࠻࠺ࠠࡥࡧࡦࡳࡩ࡫ࠠࡦࡴࡵࡳࡷ࠭⋻")
	if kodi_version>18.99: l1111lllll_l1_ = l1111lllll_l1_.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⋼"))
	return l1111lllll_l1_
def l1111111ll_l1_(l1111llll1_l1_,l1111ll11l_l1_,a):
	a = a - l1111ll11l_l1_
	if a<0:
		c = l11lll_l1_ (u"ࠫࡺࡴࡤࡦࡨ࡬ࡲࡪࡪࠧ⋽")
	else:
		c = l1111llll1_l1_[a]
	return c
def x(l1111llll1_l1_,l1111ll11l_l1_,a):
	return(l1111111ll_l1_(l1111llll1_l1_,l1111ll11l_l1_,a))
def l1111ll1ll_l1_(l111l1l1ll_l1_,step,l1111ll11l_l1_,l11111lll1_l1_):
	l11111lll1_l1_ = l11111lll1_l1_.replace(l11lll_l1_ (u"ࠬࡼࡡࡳࠢࠪ⋾"),l11lll_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡤ࠼ࠢࠪ⋿"))
	l11111lll1_l1_ = l11111lll1_l1_.replace(l11lll_l1_ (u"ࠧࡹࠪࠪ⌀"),l11lll_l1_ (u"ࠨࡺࠫࡸࡦࡨࠬࡴࡶࡨࡴ࠷࠲ࠧ⌁"))
	#exec(l11111lll1_l1_)
	l11111lll1_l1_ = l11111lll1_l1_.replace(l11lll_l1_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࠢࡧ࠿ࠥࡪ࠽ࠨ⌂"),l11lll_l1_ (u"ࠪࠫ⌃"))
	d = eval(l11111lll1_l1_,{l11lll_l1_ (u"ࠫࡵࡧࡲࡴࡧࡌࡲࡹ࠭⌄"):l111l1l11l_l1_,l11lll_l1_ (u"ࠬࡾࠧ⌅"):x,l11lll_l1_ (u"࠭ࡴࡢࡤࠪ⌆"):l111l1l1ll_l1_,l11lll_l1_ (u"ࠧࡴࡶࡨࡴ࠷࠭⌇"):l1111ll11l_l1_})
	l111ll1ll1_l1_=0
	while True:
		l111ll1ll1_l1_=l111ll1ll1_l1_+1
		l111l1l1ll_l1_.append(l111l1l1ll_l1_[0])
		del l111l1l1ll_l1_[0]
		#_print([i for i in l111l1l1ll_l1_[0:10]])
		#_print(str(l111ll1ll1_l1_)+l11lll_l1_ (u"ࠨ࠼ࠪ⌈")+str(c))
		#exec(l11111lll1_l1_)
		d = eval(l11111lll1_l1_,{l11lll_l1_ (u"ࠩࡳࡥࡷࡹࡥࡊࡰࡷࠫ⌉"):l111l1l11l_l1_,l11lll_l1_ (u"ࠪࡼࠬ⌊"):x,l11lll_l1_ (u"ࠫࡹࡧࡢࠨ⌋"):l111l1l1ll_l1_,l11lll_l1_ (u"ࠬࡹࡴࡦࡲ࠵ࠫ⌌"):l1111ll11l_l1_})
		if ((d == step) or (l111ll1ll1_l1_>10000)): break
	return
def l111111l11_l1_(l1111lll11_l1_):
	tmp = re.findall(l11lll_l1_ (u"࠭ࡶࡢࡴ࠱࠮ࡄࡃࠨ࠯ࡽ࠵࠰࠹ࢃࠩ࡝ࠪ࡟࠭ࠬ⌍"), l1111lll11_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠧࡆࡔࡕ࠾࡛ࡧࡲࡤࡱࡱࡷࡹࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ⌎")
	l111111111_l1_ = tmp[0].strip()
	_print(l11lll_l1_ (u"ࠨࡘࡤࡶࡨࡵ࡮ࡴࡶࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ⌏") % l111111111_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠩࢀࡠ࠭࠭⌐")+l111111111_l1_+l11lll_l1_ (u"ࠪࡃ࠱࠮࠰ࡹ࡝࠳࠱࠾ࡧ࠭ࡧ࡟ࡾ࠵࠱࠷࠰ࡾࠫ࡟࠭ࡡ࠯࠻ࠨ⌑"), l1111lll11_l1_)
	if not tmp: return l11lll_l1_ (u"ࠫࡊࡘࡒ࠻ࠢࡖࡸࡪࡶ࠱ࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫ⌒")
	step = eval(tmp[0])
	_print(l11lll_l1_ (u"࡙ࠬࡴࡦࡲ࠴ࠤࠥࠦࠠࠡࠢࠣࠤࡂࠦ࠰ࡹࠧࡶࠫ⌓") % l11lll_l1_ (u"࠭ࡻ࠻࠲࠵࡜ࢂ࠭⌔").format(step).lower())
	tmp = re.findall(l11lll_l1_ (u"ࠧࡥ࠿ࡧ࠱࠭࠶ࡸ࡜࠲࠰࠽ࡦ࠳ࡦ࡞ࡽ࠴࠰࠶࠶ࡽࠪ࠽ࠪ⌕"), l1111lll11_l1_)
	if not tmp: return l11lll_l1_ (u"ࠨࡇࡕࡖ࠿࡙ࡴࡦࡲ࠵ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧ⌖")
	l1111ll11l_l1_ = eval(tmp[0])
	_print(l11lll_l1_ (u"ࠩࡖࡸࡪࡶ࠲ࠡࠢࠣࠤࠥࠦࠠࠡ࠿ࠣ࠴ࡽࠫࡳࠨ⌗") % l11lll_l1_ (u"ࠪࡿ࠿࠶࠲࡙ࡿࠪ⌘").format(l1111ll11l_l1_).lower())
	tmp = re.findall(l11lll_l1_ (u"ࠦࡹࡸࡹࡼࠪࡹࡥࡷ࠴ࠪࡀࠫ࠾ࠦ⌙"), l1111lll11_l1_)
	if not tmp: return l11lll_l1_ (u"ࠬࡋࡒࡓ࠼ࡧࡩࡨࡧ࡬ࡠࡨࡱࡧࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨ⌚")
	l11111lll1_l1_ = tmp[0]
	_print(l11lll_l1_ (u"࠭ࡄࡦࡥࡤࡰࠥ࡬ࡵ࡯ࡥࠣࠤࠥࡃࠠࠣࠢࠨࡷ࠳࠴࠮ࠣࠩ⌛") % l11111lll1_l1_[0:135])
	tmp = re.findall(l11lll_l1_ (u"ࠢࠨࡦࡤࡸࡦ࠭࠺ࡼࠩࠫࡣࡠ࠶࠭࠺ࡣ࠰ࡾࡆ࠳࡚࡞ࡽ࠴࠴࠱࠸࠰ࡾࠫࠪ࠾ࠬࡵ࡫ࠨࠤ⌜"), l1111lll11_l1_)
	if not tmp: return l11lll_l1_ (u"ࠨࡇࡕࡖ࠿ࡖ࡯ࡴࡶࡎࡩࡾࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩ⌝")
	l111l11ll1_l1_ = tmp[0]
	_print(l11lll_l1_ (u"ࠩࡓࡳࡸࡺࡋࡦࡻࠣࠤࠥࠦࠠࠡ࠿ࠣࠩࡸ࠭⌞") % l111l11ll1_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠥࡪࡺࡴࡣࡵ࡫ࡲࡲࠥࠨ⌟")+l111111111_l1_+l11lll_l1_ (u"ࠦ࠳࠰࠿ࡷࡣࡵ࠲࠯ࡅ࠽ࠩ࡞࡞࠲࠯ࡅ࡝ࠪࠤ⌠"), l1111lll11_l1_)
	if not tmp: return l11lll_l1_ (u"ࠬࡋࡒࡓ࠼ࡗࡥࡧࡒࡩࡴࡶࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭⌡")
	l1111l1ll1_l1_ = tmp[0]
	l1111l1ll1_l1_ = l111111111_l1_ + l11lll_l1_ (u"ࠨ࠽ࠣ⌢") + l1111l1ll1_l1_
	exec(l1111l1ll1_l1_) in globals(), locals()
	l1111llll1_l1_ = locals()[l111111111_l1_]
	_print(l111111111_l1_+l11lll_l1_ (u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫ࠮࠺࠲ࡶ࠲࠳࠴ࠧ⌣")%str(l1111llll1_l1_))
	l1111ll1ll_l1_(l1111llll1_l1_,step,l1111ll11l_l1_,l11111lll1_l1_)
	_print(l111111111_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡂࠦࠥ࠯࠻࠳ࡷ࠳࠴࠮ࠨ⌤")%str(l1111llll1_l1_))
	tmp = re.findall(l11lll_l1_ (u"ࠤ࡟ࠬࡡ࠯࠻ࠩࡸࡤࡶࠥ࠴ࠪࡀࠫ࡟ࠨࡡ࠮ࠧ࡝ࠬࠪࡠ࠮ࠨ⌥"), l1111lll11_l1_, re.S)
	if not tmp:
		tmp = re.findall(l11lll_l1_ (u"ࠥࡥ࠵ࡧ࡜ࠩ࡞ࠬ࠿࠭࠴ࠪࡀࠫ࡟ࠨࡡ࠮ࠧ࡝ࠬࠪࡠ࠮ࠨ⌦"), l1111lll11_l1_, re.S)
		if not tmp:
			return l11lll_l1_ (u"ࠫࡊࡘࡒ࠻ࡎ࡬ࡷࡹࡥࡖࡢࡴࠣࡒࡴࡺࠠࡇࡱࡸࡲࡩ࠭⌧")
	l111ll1l1l_l1_ = tmp[0]
	l111ll1l1l_l1_ = re.sub(l11lll_l1_ (u"ࠧ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࠰࠭ࡃࢂ࠴ࠪࡀࡿࠬࠦ⌨"), l11lll_l1_ (u"ࠨࠢ〈"), l111ll1l1l_l1_)
	_print(l11lll_l1_ (u"ࠧࡍ࡫ࡶࡸࡤ࡜ࡡࡳࠢࠣࠤࠥࠦ࠽ࠡࠧ࠱࠽࠵ࡹ࠮࠯࠰ࠪ〉") % l111ll1l1l_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠣࠪࡢ࡟ࡦ࠳ࡺࡂ࠯ࡽ࠴࠲࠿࡝ࡼ࠶࠯࠼ࢂ࠯࠽࡝࡝࡟ࡡࠧ⌫") , l111ll1l1l_l1_)
	if not tmp: return l11lll_l1_ (u"ࠩࡈࡖࡗࡀ࠳ࡗࡣࡵࡷࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨ⌬")
	_1111l1lll_l1_ = tmp
	_print(l11lll_l1_ (u"ࠪ࠷࡛ࡧࡲࡴࠢࠣࠤࠥࠦࠠࠡࠢࡀࠤࠪࡹࠧ⌭")%str(_1111l1lll_l1_))
	l111l111ll_l1_ = _1111l1lll_l1_[1]
	_print(l11lll_l1_ (u"ࠫࡧ࡯ࡧࡠࡵࡷࡶࡤࡼࡡࡳࠢࠣࡁࠥࠫࡳࠨ⌮")%l111l111ll_l1_)
	l111ll1l1l_l1_ = l111ll1l1l_l1_.replace(l11lll_l1_ (u"ࠬ࠲ࠧ⌯"),l11lll_l1_ (u"࠭࠻ࠨ⌰")).split(l11lll_l1_ (u"ࠧ࠼ࠩ⌱"))
	for l11111ll1l_l1_ in l111ll1l1l_l1_:
		l11111ll1l_l1_ = l11111ll1l_l1_.strip()
		if l11lll_l1_ (u"ࠨ࡫ࡶࡱࡴࡨࠧ⌲") in l11111ll1l_l1_: l11111ll1l_l1_=l11lll_l1_ (u"ࠩࠪ⌳")
		if l11lll_l1_ (u"ࠪࡁࡠࡣࠧ⌴")   in l11111ll1l_l1_: l11111ll1l_l1_ = l11111ll1l_l1_.replace(l11lll_l1_ (u"ࠫࡂࡡ࡝ࠨ⌵"),l11lll_l1_ (u"ࠬࡃࡻࡾࠩ⌶"))
		l11111ll1l_l1_ = re.sub(l11lll_l1_ (u"ࠨࠨࡢ࠲࠱ࡠ࠭࠯ࠢ⌷"), l11lll_l1_ (u"ࠢࡢ࠲ࡧࠬࡲࡧࡩ࡯ࡡࡷࡥࡧ࠲ࡳࡵࡧࡳ࠶࠱ࠨ⌸"), l11111ll1l_l1_)
		#if l11lll_l1_ (u"ࠨࡣ࠳ࡋ࠭࠭⌹")  in l11111ll1l_l1_: l11111ll1l_l1_ = l11111ll1l_l1_.replace(l11lll_l1_ (u"ࠩࡤ࠴ࡌ࠮ࠧ⌺"),l11lll_l1_ (u"ࠪࡥ࠵ࡍࠨ࡮ࡣ࡬ࡲࡤࡺࡡࡣ࠮ࡶࡸࡪࡶ࠲࠭ࠩ⌻"))
		if l11111ll1l_l1_!=l11lll_l1_ (u"ࠫࠬ⌼"):
			#_print(l11lll_l1_ (u"ࠬ࡫࡬࡮ࠢࡀࠤࠪࡹࠧ⌽") % l11111ll1l_l1_)
			l11111ll1l_l1_ = l11111ll1l_l1_.replace(l11lll_l1_ (u"࠭ࠡࠢ࡝ࡠࠫ⌾"),l11lll_l1_ (u"ࠧࡕࡴࡸࡩࠬ⌿"));
			l11111ll1l_l1_ = l11111ll1l_l1_.replace(l11lll_l1_ (u"ࠨࠣ࡞ࡡࠬ⍀"),l11lll_l1_ (u"ࠩࡉࡥࡱࡹࡥࠨ⍁"));
			l11111ll1l_l1_ = l11111ll1l_l1_.replace(l11lll_l1_ (u"ࠪࡺࡦࡸࠠࠨ⍂"),l11lll_l1_ (u"ࠫࠬ⍃"));
			#_print(l11lll_l1_ (u"ࠬ࡫࡬࡮ࠢࡀࠤࠪࡹࠧ⍄") % l11111ll1l_l1_)
			try:
				exec(l11111ll1l_l1_,{l11lll_l1_ (u"࠭ࡰࡢࡴࡶࡩࡎࡴࡴࠨ⍅"):l111l1l11l_l1_,l11lll_l1_ (u"ࠧࡢࡶࡲࡦࠬ⍆"):l111l1lll1_l1_,l11lll_l1_ (u"ࠨࡣ࠳ࡨࠬ⍇"):l1111111ll_l1_,l11lll_l1_ (u"ࠩࡻࠫ⍈"):x,l11lll_l1_ (u"ࠪࡱࡦ࡯࡮ࡠࡶࡤࡦࠬ⍉"):l1111llll1_l1_,l11lll_l1_ (u"ࠫࡸࡺࡥࡱ࠴ࠪ⍊"):l1111ll11l_l1_},locals())
			except:
				#_print(l11lll_l1_ (u"ࠬ࡫࡬࡮ࠢࡀࠤࠪࡹࠧ⍋") % l11111ll1l_l1_)
				#_print(l11lll_l1_ (u"࠭ࡶࠡ࠿ࠣࠦࠪࡹࠢࠡࡧࡻࡩࡨࠦࡰࡳࡱࡥࡰࡪࡳࠡࠨ⍌") % l11111ll1l_l1_, sys.exc_info()[0])
				pass
	l111ll1111_l1_ = l11lll_l1_ (u"ࠧࠨ⍍")
	for i in range(0,len(locals()[_1111l1lll_l1_[2]])):
		if locals()[_1111l1lll_l1_[2]][i] in locals()[_1111l1lll_l1_[1]]:
			l111ll1111_l1_ = l111ll1111_l1_ + locals()[_1111l1lll_l1_[1]][locals()[_1111l1lll_l1_[2]][i]]
	_print(l11lll_l1_ (u"ࠨࡤ࡬࡫ࡘࡺࡲࡪࡰࡪࠤࠥࠦࠠ࠾ࠢࠨ࠲࠾࠶ࡳ࠯࠰࠱ࠫ⍎")%l111ll1111_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠩࡹࡥࡷࠦࡢ࠾࡞ࠪ࠳ࡡ࠭࡜ࠬࠪ࠱࠮ࡄ࠯ࠨࡀ࠼࠯ࢀࡀ࠯ࠧ⍏"), l1111lll11_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠪࡉࡗࡘ࠺ࠡࡉࡨࡸ࡚ࡸ࡬ࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫ⍐")
	l11111llll_l1_ = str(tmp[0])
	_print(l11lll_l1_ (u"ࠫࡌ࡫ࡴࡖࡴ࡯ࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨ⍑") % l11111llll_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠬ࠮࡟࠯ࠬࡂ࠭ࡡࡡࠧ⍒"), l11111llll_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡌ࡫ࡴࡗࡣࡵࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧ⍓")
	l111l1l1l1_l1_ = tmp[0]
	_print(l11lll_l1_ (u"ࠧࡈࡧࡷ࡚ࡦࡸࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫ⍔") % l111l1l1l1_l1_)
	l111l1111l_l1_ = locals()[l111l1l1l1_l1_][0]
	l111l1111l_l1_ = l111l1lll1_l1_(l111l1111l_l1_)
	_print(l11lll_l1_ (u"ࠨࡉࡨࡸ࡛ࡧ࡬ࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨࡷࠬ⍕") % l111l1111l_l1_)
	tmp = re.findall(l11lll_l1_ (u"ࠩࢀࡺࡦࡸࠠࠩࡨࡀ࠲࠯ࡅࠩ࠼ࠩ⍖"), l1111lll11_l1_, re.S)
	if not tmp: return l11lll_l1_ (u"ࠪࡉࡗࡘ࠺ࠡࡒࡲࡷࡹ࡛ࡲ࡭ࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬ⍗")
	l111111lll_l1_ = str(tmp[0])
	_print(l11lll_l1_ (u"ࠫࡕࡵࡳࡵࡗࡵࡰࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨ⍘") % l111111lll_l1_)
	l111111lll_l1_ = re.sub(l11lll_l1_ (u"ࠧ࠮ࡷࡪࡰࡧࡳࡼࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠢ⍙"), l11lll_l1_ (u"ࠨࡡࡵࡱࡥࠦ⍚"), l111111lll_l1_)
	l111111lll_l1_ = re.sub(l11lll_l1_ (u"ࠢࠩ࡝ࡄ࠱࡟ࡣࡻ࠲࠮࠵ࢁࡡ࠮ࠩࠣ⍛"), l11lll_l1_ (u"ࠣࡣ࠳ࡨ࠭ࡳࡡࡪࡰࡢࡸࡦࡨࠬࡴࡶࡨࡴ࠷࠲ࠢ⍜"), l111111lll_l1_)
	l111111lll_l1_ = l11lll_l1_ (u"ࠩࡪࡰࡴࡨࡡ࡭ࠢࡩ࠿ࠥ࠭⍝")+l111111lll_l1_
	verify = re.findall(l11lll_l1_ (u"ࠪࡠ࠰࠮࡟࠯ࠬࡂ࠭ࠩ࠭⍞"),l111111lll_l1_,re.DOTALL)[0]
	l1111111l1_l1_ = eval(verify)
	#exec(l111111lll_l1_)
	l111111lll_l1_ = l111111lll_l1_.replace(l11lll_l1_ (u"ࠫ࡬ࡲ࡯ࡣࡣ࡯ࠤ࡫ࡁࠠࡧ࠿ࠪ⍟"),l11lll_l1_ (u"ࠬ࠭⍠"))
	f = eval(l111111lll_l1_,{l11lll_l1_ (u"࠭ࡡࡵࡱࡥࠫ⍡"):l111l1lll1_l1_,l11lll_l1_ (u"ࠧࡢ࠲ࡧࠫ⍢"):l1111111ll_l1_,l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡴࡢࡤࠪ⍣"):l1111llll1_l1_,l11lll_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨ⍤"):l1111ll11l_l1_,verify:l1111111l1_l1_})
	_print(l11lll_l1_ (u"ࠪ࠳ࠬ⍥")+l111l1111l_l1_+l11lll_l1_ (u"ࠫࠥࠦࠠࠡࠩ⍦")+f+l111ll1111_l1_+l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠪ⍧")+l111l11ll1_l1_)
	return([l11lll_l1_ (u"࠭࠯ࠨ⍨")+l111l1111l_l1_,f+l111ll1111_l1_,{ l111l11ll1_l1_ : l11lll_l1_ (u"ࠧࡰ࡭ࠪ⍩")}])
def _print(text):
	#text = text.replace(l11lll_l1_ (u"ࠨࠢࠣࠤࠥ࠭⍪"),l11lll_l1_ (u"ࠩࠣࠤࠬ⍫")).replace(l11lll_l1_ (u"ࠪࠤࠥࠦࠠࠨ⍬"),l11lll_l1_ (u"ࠫࠥࠦࠧ⍭")).replace(l11lll_l1_ (u"ࠬࠦࠠࠡࠢࠪ⍮"),l11lll_l1_ (u"࠭ࠠࠡࠩ⍯"))
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ⍰"),str(text))
	return
l11lll_l1_ (u"ࠣࠤࠥࠎࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺ࡯ࡰ࡮࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡱࡺࡤ࠰࡯ࡲࡺ࡮࡫࠯࡭ࡣࡸ࡫࡭࠳࡫ࡪ࡮࡯ࡩࡷ࠳࡬ࡢࡷࡪ࡬࠲࠸࠰࠲࠷ࠪࠎࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺ࡯ࡰ࡮࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡱࡺࡤ࠰࡯ࡲࡺ࡮࡫࠯ࡢ࡮࡯࠱࡭ࡧ࡬࡭ࡱࡺࡷ࠲࡫ࡶࡦ࠯࠵࠱࠷࠶࠱࠶࠱ࡂࡶࡪ࡬࠽ࡴ࡫ࡰ࡭ࡱࡧࡲࠨࠌࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡴࡵ࡬࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰࡯ࡸࡩ࠵࡭ࡰࡸ࡬ࡩ࠴ࡧࡤࡷࡧࡵࡷࡪ࠳࠲࠱࠴࠳࠳ࡄࡸࡥࡧ࠿ࡰࡳࡻ࡯ࡥࡴ࠯ࡳ࠵ࠬࠐࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡎࡐࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡘࡊ࡙ࡔ࠲ࠩࠬࠎ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊ࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡧࡵࡵࡱ࠰ࡷ࡮ࢀࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺ࡯ࡰ࡮࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡱࡺࡤࠨ࠭࡯࡭ࡳࡱ࡛࠱࡟ࠍࠧࡱ࡯࡮࡬ࠢࡀࠤࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡰࡱ࡯࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡲࡴࡥ࠱ࡺࡥࡹࡩࡨ࠰ࡁࡹࡁ࡞࡮ࡨࡩࡧࡊ࡞࡮ࡠࡇࡥ࡚࡙ࡶࡪ࡮ࡑࡩࡪ࡫ࡩࡌࡲࡅࡩࡧ࡫ࡕ࡭࡫ࡦࡔࡍࡎ࡛ࡽࡓࡤࡥࡧࡧ࡯࡮ࡠࡦࡩࡍࡥࡪࡐ࡮ࡥࡒࡧ࡫ࡩࡈࡑࡤࡶࡧ࡫ࡕ࡭࡫ࡄ࡭ࡑࡧࡴࡎࡪࡥࡌࡨࡇ࡜ࡗࡊࡱࡕࡘ࡝ࡪ࡭࡮ࡥࡩ࡛ࡔࡩ࡭࡫ࡤࡔࡍ࡫ࡩ࡭ࡗࡨࡦࡦࡎ࡝ࡉ࡙࡮ࡆࡘࡧ࡬ࡩࡠࡗࡈࡪࡨࡕࡪ࡮ࡥ࡛ࡸࡲ࡝ࡩ࡙࡬࡛࡙ࡨ࡬ࡖࡊ࡮࡚ࡆࡱ࡬ࡉࡗࡄ࡮ࡅࡧࡈ࡫ࡗࡑࡦࡪࡨࡏࡘࡔࡥࡩࡓ࡫ࡩࡸࡪࡓࡌࡉࡩࡰࡵࡔ࡯ࡩࡦࡳࡳࡩࡠࡰࡌࡪࡨࡕࡪ࡮ࡥࡥࡕࡦ࡬ࡪ࡮ࡑࡩࡧࡇࡲࡱ࡫ࡨࡧࡰ࡫ࡕࡷ࡬ࡨࡩࡨࡱ࡬ࡉ࡮ࡨࡦࡪ࡜ࠪ࡭ࡃ࠵ࡥࡧ࠻ࡦࡧ࠶࠷࠳ࡦ࠶࠷࠻ࡪࡥ࠱࠷࠳࠽࠷࠸࠹࠸ࡧࡦ࠼ࡧ࠼࠱࠷࠶࠶ࠫࠏࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲࡬ࡪࡰ࡮࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡘࡊ࡙ࡔ࠳ࠩࠬࠎ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࡵࡴࡼ࠾ࠏࠏࡲࡦࡵࡸࡰࡹࠦ࠽ࠡࡘ࡬ࡨࡘࡺࡲࡦࡣࡰࠬ࡭ࡺ࡭࡭ࠫࠍࠍࡱࡴ࠱࠭࡮ࡱ࠶࠱ࡶࡲ࡮ࠢࡀࠤࡷ࡫ࡳࡶ࡮ࡷࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫࡊࡓࡁࡅࠢࡈࡑࡆࡊ࠺ࠡࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯ࡲ࠶࠯ࠩࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡇࡐࡅࡉࠦࡅࡎࡃࡇ࠾ࠥࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬࡯࠴ࠬ࠭ࠏࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬࡋࡍࡂࡆࠣࡉࡒࡇࡄ࠻ࠢࠣࠤࠬ࠱ࡳࡵࡴࠫࡴࡷࡳࠩࠪࠌࡨࡼࡨ࡫ࡰࡵ࠼ࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪࡉࡒࡇࡄࠡࡇࡐࡅࡉࡀࠠࠡࠢࠪ࠯ࡸࡺࡲࠩࡴࡨࡷࡺࡲࡴࠪࠫࠍࠦࠧࠨ⍱")
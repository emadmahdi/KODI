# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ⱃ")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡇࡄࡎࡣࠬⱄ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩⱅ"),l11lll_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩⱆ")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l1111l_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l11111_l1_(url,text)
	elif mode==624: results = l1l11l_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪⱇ"),l11lll_l1_ (u"ࠪๅอืใสࠢࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩⱈ"),l11lll_l1_ (u"ࠫࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠫⱉ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱊ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ⱋ"),l11lll_l1_ (u"ࠧࠨⱌ"),629,l11lll_l1_ (u"ࠨࠩⱍ"),l11lll_l1_ (u"ࠩࠪⱎ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧⱏ"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⱐ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⱑ"),l11lll_l1_ (u"࠭ࠧⱒ"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱓ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⱔ")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪⱕ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠪࠫⱖ"),l11lll_l1_ (u"ࠫࠬⱗ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧⱘ"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱙ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩⱚ")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧⱛ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠩࠪⱜ"),l11lll_l1_ (u"ࠪࠫⱝ"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪⱞ"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱟ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⱠ")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ⱡ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠨࠩⱢ"),l11lll_l1_ (u"ࠩࠪⱣ"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧⱤ"))
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱥ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧⱦ")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪⱧ"),l1ll1l1_l1_,621,l11lll_l1_ (u"ࠧࠨⱨ"),l11lll_l1_ (u"ࠨࠩⱩ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫⱪ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⱫ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⱬ"),l11lll_l1_ (u"ࠬ࠭Ɑ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫⱮ"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"ࠧࠨⱯ"),l11lll_l1_ (u"ࠨࠩⱰ"),l11lll_l1_ (u"่ࠩ์็฿ࠠโสิ็ฮ࠭ⱱ"),l11lll_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭Ⱳ"))
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬⱳ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱴ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨⱵ")+l111ll_l1_+title,link,624)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⱶ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨⱷ"),l11lll_l1_ (u"ࠩࠪⱸ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧⱹ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤⱺ"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠬ࠭ⱻ"))
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫⱼ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱽ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⱾ")+l111ll_l1_+title,link,624)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭Ɀ"),url,l11lll_l1_ (u"ࠪࠫⲀ"),l11lll_l1_ (u"ࠫࠬⲁ"),l11lll_l1_ (u"ࠬ࠭Ⲃ"),l11lll_l1_ (u"࠭ࠧⲃ"),l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭Ⲅ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬⲅ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪⲆ"),l11lll_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩⲇ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨⲈ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠬ࠭ⲉ"),block)]
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⲊ"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⲋ"),l11lll_l1_ (u"ࠨࠩⲌ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧⲍ"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠪ࠾ࠥ࠭Ⲏ")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲏ"),l111ll_l1_+title,link,621)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩⲐ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨⲑ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⲒ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨⲓ"),l11lll_l1_ (u"ࠩࠪⲔ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲕ"),l111ll_l1_+title,link,621)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠫࠬⲖ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ⲗ"),l11lll_l1_ (u"࠭ࠧⲘ"),request,url)
	if request==l11lll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬⲙ"):
		url,search = url.split(l11lll_l1_ (u"ࠨࡁࠪⲚ"),1)
		data = l11lll_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨⲛ")+search
		headers = {l11lll_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩⲜ"):l11lll_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫⲝ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪⲞ"),url,data,headers,l11lll_l1_ (u"࠭ࠧⲟ"),l11lll_l1_ (u"ࠧࠨⲠ"),l11lll_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ⲡ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭Ⲣ"),url,l11lll_l1_ (u"ࠪࠫⲣ"),l11lll_l1_ (u"ࠫࠬⲤ"),l11lll_l1_ (u"ࠬ࠭ⲥ"),l11lll_l1_ (u"࠭ࠧⲦ"),l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬⲧ"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠨࠩⲨ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ⲩ"))
	if request==l11lll_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨⲪ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ⲫ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠬ࠭Ⲭ"),link,title))
	elif request==l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨⲭ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨⲮ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧⲯ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩⲰ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧⲱ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫⲲ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧⲳ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨⲴ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩⲵ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠨࠩⲶ"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪⲷ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫⲸ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫⲹ"),l11lll_l1_ (u"ࠬ็๊ๅ็ࠪⲺ"),l11lll_l1_ (u"࠭ว฻่ํอࠬⲻ"),l11lll_l1_ (u"ࠧไๆํฬࠬⲼ"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧⲽ"),l11lll_l1_ (u"๊ࠩำฬ็ࠧⲾ"),l11lll_l1_ (u"้ࠪออัศหࠪⲿ"),l11lll_l1_ (u"ࠫ฾ืึࠨⳀ"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬⳁ"),l11lll_l1_ (u"࠭วๅส๋้ࠬⳂ"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧⳃ")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠨ࠱ࠪⳄ"))
		#if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧⳅ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬⳆ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ⳇ"))
		#if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪⳈ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨⳉ")+l1llll_l1_.strip(l11lll_l1_ (u"ࠧ࠰ࠩⳊ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠨࠢࠪⳋ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬⳌ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩⳍ"),l111ll_l1_+title,link,622,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪⳎ"):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫⳏ"),l111ll_l1_+title,link,622,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬⳐ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⳑ"),l111ll_l1_+title,link,623,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭Ⳓ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳓ"),l111ll_l1_+title,link,621,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳔ"),l111ll_l1_+title,link,623,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪⳕ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧⳖ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧⳗ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬⳘ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠨࠥࠪⳙ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫⳚ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬⳛ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳜ"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫⳝ")+title,link,621)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧⳞ"),l11lll_l1_ (u"ࠧࠨⳟ"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬⳠ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ⳡ"),url,l11lll_l1_ (u"ࠪࠫⳢ"),l11lll_l1_ (u"ࠫࠬⳣ"),l11lll_l1_ (u"ࠬ࠭ⳤ"),l11lll_l1_ (u"࠭ࠧ⳥"),l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ⳦"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ⳧"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⳨"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠪࠫ⳩")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࠬ࠭࡯࡯ࡥ࡯࡭ࡨࡱ࠽ࠣࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ⳪"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠬࠩࠧⳫ"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳬ"),l111ll_l1_+title,url,623,l1llll_l1_,l11lll_l1_ (u"ࠧࠨⳭ"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭ⳮ")+l1ll1_l1_+l11lll_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⳯"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠫࠬ࡮ࡲࡦࡨࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪࠫࠬ⳰"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⳱"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧⳲ")+link.strip(l11lll_l1_ (u"࠭࠯ࠨⳳ"))
			title = title.replace(l11lll_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ⳴"),l11lll_l1_ (u"ࠨࠢࠪ⳵"))
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⳶"),l111ll_l1_+title,link,622,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ⳷"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⳸") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ⳹")+link.strip(l11lll_l1_ (u"࠭࠯ࠨ⳺"))
		#		addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⳻"),l111ll_l1_+title,link,622,l1llll_l1_)
	return
def PLAY(url):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬ⳼"))
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⳽"),url,l11lll_l1_ (u"ࠪࠫ⳾"),l11lll_l1_ (u"ࠫࠬ⳿"),l11lll_l1_ (u"ࠬ࠭ⴀ"),l11lll_l1_ (u"࠭ࠧⴁ"),l11lll_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪⴂ"))
	html = response.content
	# l1llll1_l1_ l1l11l1_l1_
	link = re.findall(l11lll_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⴃ"),html,re.DOTALL)
	link = link[0]
	post = link.split(l11lll_l1_ (u"ࠩࡳࡳࡸࡺ࠽ࠨⴄ"))[1]
	post = base64.b64decode(post)
	if kodi_version>18.99: post = post.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨⴅ"))
	post = EVAL(l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩⴆ"),post)
	links = post[l11lll_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡸ࠭ⴇ")]
	l1l111_l1_ = list(links.keys())
	links = list(links.values())
	l111l1_l1_ = zip(l1l111_l1_,links)
	for title,link in l111l1_l1_:
		link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧⴈ")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨⴉ")
		l1111_l1_.append(link)
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࠩࡩࡧࠢ࡯࡭ࡳࡱࠠࡢࡰࡧࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪ࠯ࡱ࡯࡮࡬ࠌࠌ࡬ࡦࡹࡨࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨࡪࡤࡷ࡭ࡃࠧࠪ࡝࠴ࡡࠏࠏࡰࡢࡴࡷࡷࠥࡃࠠࡩࡣࡶ࡬࠳ࡹࡰ࡭࡫ࡷࠬࠬࡥ࡟ࠨࠫࠍࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡱࡣࡵࡸࠥࡃࠠࡣࡣࡶࡩ࠻࠺࠮ࡣ࠸࠷ࡨࡪࡩ࡯ࡥࡧࠫࡴࡦࡸࡴࠬࠩࡀࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡵࡧࡲࡵࠢࡀࠤࡵࡧࡲࡵ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࠏ࡮ࡦࡹࡢࡴࡦࡸࡴࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡳࡥࡷࡺࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࠬࡄࠧ࠯࡬ࡲ࡭ࡳ࠮࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠫࠍࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡲࡩ࡯࡭ࡶ࠲ࡸࡶ࡬ࡪࡶ࡯࡭ࡳ࡫ࡳࠩࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠸ࠠࡪࡰࠣࡾࡿࢀ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠲࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࡀࡂࠥ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨⴊ")
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧⴋ"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩⴌ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬⴍ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭ⴎ"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨⴏ"),l11lll_l1_ (u"ࠧࠬࠩⴐ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩⴑ")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪⴒ"),l11lll_l1_ (u"ࠪๅอืใสࠢࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩⴓ"),l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵࠧⴔ"))
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬⴕ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪⴖ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬⴗ"))
	return
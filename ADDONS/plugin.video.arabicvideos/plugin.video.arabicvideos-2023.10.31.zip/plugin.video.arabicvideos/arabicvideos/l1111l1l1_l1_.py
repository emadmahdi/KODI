# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬᓨ")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡃ࠵ࡊࡢࠫᓩ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨᓪ"),l11lll_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨᓫ"),l11lll_l1_ (u"ࠨษ็ห็ูวๆࠩᓬ"),l11lll_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭ᓭ"),l11lll_l1_ (u"ࠪࡇࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧᓮ"),l11lll_l1_ (u"ࠫࠬᓯ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l1111l_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l11111_l1_(url,text)
	elif mode==694: results = l1l11l_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩᓰ"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧᓱ"),l11lll_l1_ (u"ࠧࠨᓲ"),l11lll_l1_ (u"ࠨࠩᓳ"),l11lll_l1_ (u"ࠩࠪᓴ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᓵ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓶ"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᓷ"),l11lll_l1_ (u"࠭ࠧᓸ"),699,l11lll_l1_ (u"ࠧࠨᓹ"),l11lll_l1_ (u"ࠨࠩᓺ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᓻ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᓼ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᓽ"),l11lll_l1_ (u"ࠬ࠭ᓾ"),9999)
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓿ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔀ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้๊๐าสࠩᔁ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠩࠪᔂ"),l11lll_l1_ (u"ࠪࠫᔃ"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᔄ"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔅ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᔆ")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ᔇ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠨࠩᔈ"),l11lll_l1_ (u"ࠩࠪᔉ"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᔊ"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᔋ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᔌ")+l111ll_l1_+l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬᔍ"),l11ll1_l1_,691,l11lll_l1_ (u"ࠧࠨᔎ"),l11lll_l1_ (u"ࠨࠩᔏ"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᔐ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔑ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᔒ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬᔓ"),l11ll1_l1_,691,l11lll_l1_ (u"࠭ࠧᔔ"),l11lll_l1_ (u"ࠧࠨᔕ"),l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᔖ"))
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᔗ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔘ"),l11lll_l1_ (u"ࠫࠬᔙ"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡹࡵࡥࡵࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᔚ"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᔛ"),block,re.DOTALL)
	#for link,title in items:
	#	if title in l1l1l1_l1_: continue
	#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᔜ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᔝ")+l111ll_l1_+title,link,694)
	#addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᔞ"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔟ"),l11lll_l1_ (u"ࠫࠬᔠ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬᔡ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦᔢ"),html,re.DOTALL)
	#for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠧࠨᔣ"))
	#block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫᔤ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		title = title.replace(l11lll_l1_ (u"ࠩ࠿ࡦࡃ࠭ᔥ"),l11lll_l1_ (u"ࠪࠫᔦ")).strip(l11lll_l1_ (u"ࠫࠥ࠭ᔧ"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᔨ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᔩ")+l111ll_l1_+title,link,694)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᔪ"),url,l11lll_l1_ (u"ࠨࠩᔫ"),l11lll_l1_ (u"ࠩࠪᔬ"),l11lll_l1_ (u"ࠪࠫᔭ"),l11lll_l1_ (u"ࠫࠬᔮ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᔯ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᔰ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨᔱ"),l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧᔲ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᔳ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"ࠪࠫᔴ"),block)]
		addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᔵ"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᔶ"),l11lll_l1_ (u"࠭ࠧᔷ"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᔸ"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠨ࠼ࠣࠫᔹ")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔺ"),l111ll_l1_+title,link,691)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᔻ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᔼ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᔽ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᔾ"),l11lll_l1_ (u"ࠧࠨᔿ"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕀ"),l111ll_l1_+title,link,691)
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠩࠪᕁ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᕂ"),l11lll_l1_ (u"ࠫࠬᕃ"),request,url)
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᕄ"):
		url,search = url.split(l11lll_l1_ (u"࠭࠿ࠨᕅ"),1)
		data = l11lll_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ᕆ")+search
		headers = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᕇ"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᕈ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨᕉ"),url,data,headers,l11lll_l1_ (u"ࠫࠬᕊ"),l11lll_l1_ (u"ࠬ࠭ᕋ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᕌ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᕍ"),url,l11lll_l1_ (u"ࠨࠩᕎ"),l11lll_l1_ (u"ࠩࠪᕏ"),l11lll_l1_ (u"ࠪࠫᕐ"),l11lll_l1_ (u"ࠫࠬᕑ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪᕒ"))
	html = response.content
	block,items = l11lll_l1_ (u"࠭ࠧᕓ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫᕔ"))
	if request==l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᕕ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᕖ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"ࠪࠫᕗ"),link,title))
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᕘ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᕙ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᕚ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕛ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬᕜ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕝ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᕞ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡨࡡࠡ࡯ࡪࡦࠥࡺࡡࡣ࡮ࡨࠤ࡫ࡻ࡬࡭ࠤࠫ࠲࠯ࡅࠩࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࠫᕟ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᕠ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((l11lll_l1_ (u"࠭ࠧᕡ"),link,title))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᕢ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩᕣ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ุ่ࠩฬํฯสࠩᕤ"),l11lll_l1_ (u"ࠪๅ๏๊ๅࠨᕥ"),l11lll_l1_ (u"ࠫฬเๆ๋หࠪᕦ"),l11lll_l1_ (u"้ࠬไ๋สࠪᕧ"),l11lll_l1_ (u"࠭วฺๆส๊ࠬᕨ"),l11lll_l1_ (u"่ࠧัสๅࠬᕩ"),l11lll_l1_ (u"ࠨ็หหึอษࠨᕪ"),l11lll_l1_ (u"ࠩ฼ี฻࠭ᕫ"),l11lll_l1_ (u"้ࠪ์ืฬศ่ࠪᕬ"),l11lll_l1_ (u"ࠫฬ๊ศ้็ࠪᕭ"),l11lll_l1_ (u"๋ࠬำาฯํอࠬᕮ")]
	for l1llll_l1_,link,title in items:
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"࠭࠯ࠨᕯ"))
		#if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬᕰ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪᕱ")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫᕲ"))
		#if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᕳ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭ᕴ")+l1llll_l1_.strip(l11lll_l1_ (u"ࠬ࠵ࠧᕵ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨᕶ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪᕷ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᕸ"),l111ll_l1_+title,link,692,l1llll_l1_)
		elif request==l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᕹ"):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᕺ"),l111ll_l1_+title,link,692,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᕻ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᕼ"),l111ll_l1_+title,link,693,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫᕽ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᕾ"),l111ll_l1_+title,link,691,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕿ"),l111ll_l1_+title,link,693,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᖀ"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᖁ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᖂ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᖃ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"࠭ࠣࠨᖄ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩᖅ")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪᖆ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᖇ"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩᖈ")+title,link,691)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᖉ"),l11lll_l1_ (u"ࠬ࠭ᖊ"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪᖋ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᖌ"),url,l11lll_l1_ (u"ࠨࠩᖍ"),l11lll_l1_ (u"ࠩࠪᖎ"),l11lll_l1_ (u"ࠪࠫᖏ"),l11lll_l1_ (u"ࠫࠬᖐ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬᖑ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩᖒ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᖓ"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠨࠩᖔ")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࠪࠫࡴࡶࡥ࡯ࡅ࡬ࡸࡾࡢࠨࡦࡸࡨࡲࡹ࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧ࡝ࠫ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪᖕ"),block,re.DOTALL)
		if not items: items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ᖖ"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠫࠨ࠭ᖗ"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖘ"),l111ll_l1_+title,url,693,l1llll_l1_,l11lll_l1_ (u"࠭ࠧᖙ"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠨ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬ࠲ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫᖚ"),html,re.DOTALL)
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩᖛ"),str(l1l1ll1_l1_))
	block = l1l1ll1_l1_[0]
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࠧᖜ")+l1ll1_l1_+l11lll_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᖝ"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪᖞ")+l1ll1_l1_+l11lll_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᖟ"),block,re.DOTALL)
	if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡗࡪࡧࡳࡰࡰࠪᖠ")+l1ll1_l1_+l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᖡ"),block,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢᖢ"),block,re.DOTALL)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪᖣ"),l11lll_l1_ (u"ࠪࠫᖤ"),l11lll_l1_ (u"ࠫࠬᖥ"),l11lll_l1_ (u"ࠬ࠸࠲࠳࠴࠵ࠫᖦ"))
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪᖧ"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᖨ"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			link = link.strip(l11lll_l1_ (u"ࠨ࠰࠲ࠫᖩ"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫᖪ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᖫ"))
			title = title.replace(l11lll_l1_ (u"ࠫࡁ࠵ࡥ࡮ࡀ࠿ࡷࡵࡧ࡮࠿ࠩᖬ"),l11lll_l1_ (u"ࠬࠦࠧᖭ"))
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᖮ"),l111ll_l1_+title,link,692,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨᖯ"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᖰ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫᖱ")+link.strip(l11lll_l1_ (u"ࠪ࠳ࠬᖲ"))
		#		addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᖳ"),l111ll_l1_+title,link,692,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࠩᖴ"),l11lll_l1_ (u"࠭࠯ࡴࡧࡨ࠲ࡵ࡮ࡰࠨᖵ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᖶ"),l11l11l_l1_,l11lll_l1_ (u"ࠨࠩᖷ"),l11lll_l1_ (u"ࠩࠪᖸ"),l11lll_l1_ (u"ࠪࠫᖹ"),l11lll_l1_ (u"ࠫࠬᖺ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᖻ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭ࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨᖼ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l11llll_l1_ link
		link = re.findall(l11lll_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᖽ"),block,re.DOTALL)
		if link:
			link = link[0]
			l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩᖾ"))
			l1111_l1_.append(link)
		# l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩ࠳ࡵࡳ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡯࡯ࡥ࡯࡭ࡨࡱ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᖿ"),block,re.DOTALL)
		for link,title in links:
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬᗀ"))
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᗁ")+title+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᗂ"))
				l1111_l1_.append(link)
		# download links
		links = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᗃ"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				title = title.strip(l11lll_l1_ (u"ࠧ࡝ࡰࠪᗄ"))
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᗅ")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᗆ"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨᗇ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᗈ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭ᗉ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧᗊ"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩᗋ"),l11lll_l1_ (u"ࠨ࠭ࠪᗌ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪᗍ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪᗎ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࠨᗏ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᗐ"))
	return
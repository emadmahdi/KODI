# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬ捙")
l111ll_l1_ = l11lll_l1_ (u"ࠪࡣࡘࡎࡖࡠࠩ捚")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ捛"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l1111l_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l1lll1l11lll1_l1_(url)
	elif mode==314: results = l1lllll1l_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ捜"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭捝"),l11lll_l1_ (u"ࠧࠨ捞"),319,l11lll_l1_ (u"ࠨࠩ损"),l11lll_l1_ (u"ࠩࠪ捠"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ捡"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ换"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠪ捣"),l11lll_l1_ (u"࠭ࠧ捤"),114,l11ll1_l1_)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ捥"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ捦"),l11lll_l1_ (u"ࠩࠪ捧"),l11lll_l1_ (u"ࠪࠫ捨"),l11lll_l1_ (u"ࠫࠬ捩"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ捪"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࡱࡪࡴࡵ࡭࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ捫"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ捬"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ捭"),l11lll_l1_ (u"ࠩࠪ据"),9999)
	items = re.findall(l11lll_l1_ (u"ࠪࡀ࡭࠻࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠷ࡁࠫ捯"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11lll_l1_ (u"ࠫࠥ࠭捰"))
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ捱"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ捲")+l111ll_l1_+title,l11ll1_l1_,314,l11lll_l1_ (u"ࠧࠨ捳"),l11lll_l1_ (u"ࠨࠩ捴"),str(seq+1))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ捵"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ捶")+l111ll_l1_+l11lll_l1_ (u"๊่ࠫวุ฻ุࠣ์ืࠧ捷"),l11ll1_l1_,314,l11lll_l1_ (u"ࠬ࠭捸"),l11lll_l1_ (u"࠭ࠧ捹"),l11lll_l1_ (u"ࠧ࠱ࠩ捺"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭捻"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ捼"),l11lll_l1_ (u"ࠪࠫ捽"),9999)
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡂ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡄࡁࠫ捾"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ捿")+link
		#title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ掀"))
		#url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡉࡩ࡮ࡣࡑࡳࡼ࠵ࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠰ࡳ࡬ࡵ࠭掁")
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ掂"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ掃")+l111ll_l1_+title,link,311)
	return html
def l1lllll1l_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ掄"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ掅"),l11lll_l1_ (u"ࠬ࠭掆"),l11lll_l1_ (u"࠭ࠧ掇"),l11lll_l1_ (u"ࠧࠨ授"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ掉"))
	html = response.content
	if seq==l11lll_l1_ (u"ࠩ࠳ࠫ掊"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ掋"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ掌"),block,re.DOTALL)
		for link,name,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ掍")+link
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ掎"))
			name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ掏"))
			title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ掐")+name+l11lll_l1_ (u"ࠩࠬࠫ掑")
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ排"),l111ll_l1_+title,link,312)
	elif seq in [l11lll_l1_ (u"ࠫ࠶࠭掓"),l11lll_l1_ (u"ࠬ࠸ࠧ掔"),l11lll_l1_ (u"࠭࠳ࠨ掕")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠾࡫࠹ࡃ࠴ࠪࡀࠫ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡱ࡭ࠧ掖"),html,re.DOTALL)
		l1lll1l11llll_l1_ = int(seq)-1
		block = l1l1ll1_l1_[l1lll1l11llll_l1_]
		if seq==l11lll_l1_ (u"ࠨ࠳ࠪ掗"): items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ掘"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ掙"),block,re.DOTALL)
		for link,l1llll_l1_,title,name in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࠭掚")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ掛")+link
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ掜"))
			name = name.strip(l11lll_l1_ (u"ࠧࠡࠩ掝"))
			title = title+l11lll_l1_ (u"ࠨࠢࠫࠫ掞")+name+l11lll_l1_ (u"ࠩࠬࠫ掟")
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ掠"),l111ll_l1_+title,link,311,l1llll_l1_)
	elif seq in [l11lll_l1_ (u"ࠫ࠹࠭採"),l11lll_l1_ (u"ࠬ࠻ࠧ探"),l11lll_l1_ (u"࠭࠶ࠨ掣")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩ࠾࡫࠹ࡃ࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ掤"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l1ll1_l1_[seq]
		items = re.findall(l11lll_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃ࠲ࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ接"),block,re.DOTALL)
		for l1llll_l1_,link,l1l11ll11ll_l1_,title,l1ll111lll1_l1_ in items:
			l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ掦")+l1llll_l1_
			link = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬ控")+link
			title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭推"))
			l1l11ll11ll_l1_ = l1l11ll11ll_l1_.strip(l11lll_l1_ (u"ࠬࠦࠧ掩"))
			l1ll111lll1_l1_ = l1ll111lll1_l1_.strip(l11lll_l1_ (u"࠭ࠠࠨ措"))
			if l1l11ll11ll_l1_: name = l1l11ll11ll_l1_
			else: name = l1ll111lll1_l1_
			title = title+l11lll_l1_ (u"ࠧࠡࠪࠪ掫")+name+l11lll_l1_ (u"ࠨࠫࠪ掬")
			addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ掭"),l111ll_l1_+title,link,312,l1llll_l1_)
	return
def l1111l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ掮"),url,l11lll_l1_ (u"ࠫࠬ掯"),l11lll_l1_ (u"ࠬ࠭掰"),l11lll_l1_ (u"࠭ࠧ掱"),l11lll_l1_ (u"ࠧࠨ掲"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ掳"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡦࡴࡾ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡦ࡭ࡱࡤࡸ࠲ࡸࡩࡨࡪࡷࠫ掴"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	if l11lll_l1_ (u"ࠪࡧࡦࡺࡳࡶ࡯࠰ࡱࡴࡨࡩ࡭ࡧࠪ掵") in block:
		items = re.findall(l11lll_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࡦࡥࡹࡹࡵ࡮࠯ࡰࡳࡧ࡯࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ掶"),block,re.DOTALL)
		if items:
			for l1llll_l1_,link,title,count in items:
				l1llll_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ掷")+l1llll_l1_
				link = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࠨ掸")+link
				count = count.replace(l11lll_l1_ (u"ࠧࠡษ็ูํะ๊ส࠼ࠣࠫ掹"),l11lll_l1_ (u"ࠨ࠼ࠪ掺"))
				title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ掻"))
				title = title+l11lll_l1_ (u"ࠪࠤ࠭࠭掼")+count+l11lll_l1_ (u"ࠫ࠮࠭掽")
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ掾"),l111ll_l1_+title,link,311,l1llll_l1_)
	else:
		items = re.findall(l11lll_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭掿"),block,re.DOTALL)
		for link,title,l1lll1l1l1111_l1_,l1l111l1ll_l1_ in items:
			if title==l11lll_l1_ (u"ࠧࠨ揀") or l1lll1l1l1111_l1_==l11lll_l1_ (u"ࠨࠩ揁"): continue
			link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ揂")+link
			title = title+l11lll_l1_ (u"ࠪࠤ࠭࠭揃")+l1l111l1ll_l1_+l11lll_l1_ (u"ࠫ࠮࠭揄")
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ揅"),l111ll_l1_+title,link,312)
	if not items: l1llllll_l1_(html)
	return
def l1llllll_l1_(html):
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ揆"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡩࡥ࡭࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡣࡦ࡮࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ揇"),block,re.DOTALL)
	for link,title,name,count,l1l111l1ll_l1_ in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ揈")+link
		title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ揉"))
		name = name.strip(l11lll_l1_ (u"ࠪࠤࠬ揊"))
		title = title+l11lll_l1_ (u"ࠫࠥ࠮ࠧ揋")+name+l11lll_l1_ (u"ࠬ࠯ࠧ揌")
		addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ揍"),l111ll_l1_+title,link,312,l11lll_l1_ (u"ࠧࠨ揎"),l1l111l1ll_l1_)
	return
def l1lll1l11lll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ描"),url,l11lll_l1_ (u"ࠩࠪ提"),l11lll_l1_ (u"ࠪࠫ揑"),l11lll_l1_ (u"ࠫࠬ插"),l11lll_l1_ (u"ࠬ࠭揓"),l11lll_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉࡡࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ揔"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠦࡰ࠮࠳ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ揕"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		l1111l_l1_(url)
		return
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ揖"),block,re.DOTALL)
	for link,title in items:
		link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ揗")+link
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ揘"))
		if l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠰ࠫ揙") in link: addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ揚"),l111ll_l1_+title,link,312)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭換"),l111ll_l1_+title,link,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ揜"),url,l11lll_l1_ (u"ࠨࠩ揝"),l11lll_l1_ (u"ࠩࠪ揞"),l11lll_l1_ (u"ࠪࠫ揟"),l11lll_l1_ (u"ࠫࠬ揠"),l11lll_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ握"))
	html = response.content
	link = re.findall(l11lll_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭揢"),html,re.DOTALL)
	if not link: link = re.findall(l11lll_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ揣"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ揤"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪ揥"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫ揦"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭揧"),l11lll_l1_ (u"ࠬ࠱ࠧ揨"))
	l1lll1l1l111l_l1_ = [l11lll_l1_ (u"࠭ࠦࡵ࠿ࡤࠫ揩"),l11lll_l1_ (u"ࠧࠧࡶࡀࡧࠬ揪"),l11lll_l1_ (u"ࠨࠨࡷࡁࡸ࠭揫")]
	if l1ll_l1_:
		l1lll1l11ll1l_l1_ = [l11lll_l1_ (u"ࠩๅหึฬࠧ揬"),l11lll_l1_ (u"ࠪษฺีวาࠢ࠲ࠤ๊าไะࠩ揭"),l11lll_l1_ (u"๊่ࠫืฺࠢสฺ่๎ส๋ࠩ揮")]
		l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠ࠮ࠢฦาฯืࠠศๆหัะ࠭揯"), l1lll1l11ll1l_l1_)
		if l1l_l1_ == -1: return
	elif l11lll_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡔࡊࡘࡓࡐࡐࡖࡣࠬ揰") in options: l1l_l1_ = 0
	elif l11lll_l1_ (u"ࠧࡠࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡆࡒࡂࡖࡏࡖࡣࠬ揱") in options: l1l_l1_ = 1
	elif l11lll_l1_ (u"ࠨࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࡤ࠭揲") in options: l1l_l1_ = 2
	else: return
	type = l1lll1l1l111l_l1_[l1l_l1_]
	url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ揳")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ援"),url,l11lll_l1_ (u"ࠫࠬ揵"),l11lll_l1_ (u"ࠬ࠭揶"),l11lll_l1_ (u"࠭ࠧ揷"),l11lll_l1_ (u"ࠧࠨ揸"),l11lll_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ揹"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭揺"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ揻"),block,re.DOTALL)
			for link,l1llll_l1_,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭揼"))
				name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ揽"))
				title = title+l11lll_l1_ (u"࠭ࠠࠩࠩ揾")+name+l11lll_l1_ (u"ࠧࠪࠩ揿")
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ搀"),l111ll_l1_+title,link,313,l1llll_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ搁"),block,re.DOTALL)
			for link,title,name in items:
				title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ搂"))
				name = name.strip(l11lll_l1_ (u"ࠫࠥ࠭搃"))
				title = title+l11lll_l1_ (u"ࠬࠦࠨࠨ搄")+name+l11lll_l1_ (u"࠭ࠩࠨ搅")
				addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭搆"),l111ll_l1_+title,link,312)
	return
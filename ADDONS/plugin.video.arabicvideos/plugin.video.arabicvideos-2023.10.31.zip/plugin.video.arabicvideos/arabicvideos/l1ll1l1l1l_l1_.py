# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧᰢ")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡅࡐࡒࡤ࠭ᰣ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨไสส๊ะ๊ࠨᰤ")]
def MAIN(mode,url,text):
	if   mode==300: results = MENU()
	elif mode==301: results = l1l11l_l1_(url)
	elif mode==302: results = l1111l_l1_(url)
	elif mode==303: results = l1llll1l11_l1_(url)
	elif mode==304: results = l1llllll_l1_(url)
	elif mode==305: results = PLAY(url)
	elif mode==306: results = l1ll1l111l_l1_()
	elif mode==309: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᰥ"),l111ll_l1_+l11lll_l1_ (u"่๊ࠪอะศࠢส่๊๎โฺࠢห฻๏วࠧᰦ"),l11lll_l1_ (u"ࠫࠬᰧ"),306)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᰨ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᰩ"),l11lll_l1_ (u"ࠧࠨᰪ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰫ"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᰬ"),l11lll_l1_ (u"ࠪࠫᰭ"),309,l11lll_l1_ (u"ࠫࠬᰮ"),l11lll_l1_ (u"ࠬ࠭ᰯ"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᰰ"))
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᰱ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᰲ"),l11lll_l1_ (u"ࠩࠪᰳ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᰴ"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪᰵ"),l11lll_l1_ (u"ࠬ࠭ᰶ"),l11lll_l1_ (u"᰷࠭ࠧ"),l11lll_l1_ (u"ࠧࠨ᰸"),l11lll_l1_ (u"ࠨࠩ᰹"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ᰺"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"ࠪࠫ᰻"),html)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡁ࡮ࡥࡢࡦࡨࡶࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮ࡥࡢࡦࡨࡶࡃ࠭᰼"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᰽"),block,re.DOTALL)
	for link,title in items:
		#link = l11ll1_l1_+link
		title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ᰾"))
		#if title==l11lll_l1_ (u"ࠧา็ูห๋࠭᰿"): link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ึ๋ึศ่࠲ࠫ᱀")
		if not any(value in title for value in l1l1l1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᱁"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᱂")+l111ll_l1_+title,link,301)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᱃"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᱄"),l11lll_l1_ (u"࠭ࠧ᱅"),9999)
	l1l11l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡪࡲࡱࡪ࠭᱆"),html)
	return html
def l1ll1l111l_l1_():
	DIALOG_OK(l11lll_l1_ (u"ࠨࠩ᱇"),l11lll_l1_ (u"ࠩࠪ᱈"),l11lll_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᱉"),l11lll_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠ็ษ๋ࠤอ฽๊ย่๊ࠢࠥอไๆืาีࠥ࠴࠮ࠡสึฬอࠦโ๋ษ่ࠤศ฻อศสࠣห้๋่ใ฻ࠣฬฯฺแ๋ำ้ࠣาะ่๋ษอࠤัฺุ๋๊ࠢๅาอสࠡษ็้ํู่ࠡ࠰࠱ࠤํอไ้ไอࠤฬ๊ึศศ฼ࠤ๏ึ็ษࠢไ๎ู๋ࠥศๆฯอࠥะิโ์ิࠤฬ๊ีโฯสฮࠥอไๆึไีฮࠦโษๆࠣ฽ึ฼ࠠๆฯอ์๏อส่ษࠣๅ๏ࠦโ้ษษ้ࠥํะศࠢส่อืๆศ็ฯࠫ᱊"))
	return
def l1l11l_l1_(url,html=l11lll_l1_ (u"ࠬ࠭᱋")):
	if not html:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ᱌"),url,l11lll_l1_ (u"ࠧࠨᱍ"),l11lll_l1_ (u"ࠨࠩᱎ"),l11lll_l1_ (u"ࠩࠪᱏ"),l11lll_l1_ (u"ࠪࠫ᱐"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ᱑"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	seq = 0
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠭ࡃࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠪࠩ᱒"),html,re.DOTALL)
	if l1l1ll1_l1_:
		for block in l1l1ll1_l1_:
			seq += 1
			items = re.findall(l11lll_l1_ (u"࠭࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᱓"),block,re.DOTALL)
			for title,test,link in items:
				title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ᱔"))
				if title==l11lll_l1_ (u"ࠨࠩ᱕"): title = l11lll_l1_ (u"ࠩห์ํ๎่้ࠩ᱖")
				if l11lll_l1_ (u"ࠪࡩࡲࡄ࠼ࡢࠩ᱗") not in test:
					if block.count(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ᱘"))>0:
						l1ll1l1111_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᱙"),block,re.DOTALL)
						for link in l1ll1l1111_l1_:
							title = link.split(l11lll_l1_ (u"࠭࠯ࠨᱚ"))[-2]
							addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᱛ"),l111ll_l1_+title,link,301)
						continue
					else: link = url+l11lll_l1_ (u"ࠨࡁࡶࡩࡶࡻࡥ࡯ࡥࡨࡁࠬᱜ")+str(seq)
				#l111ll1l1_l1_ = [l11lll_l1_ (u"่ࠩืู้ไศฬࠣࠫᱝ"),l11lll_l1_ (u"ࠪหๆ๊วๆࠢࠪᱞ"),l11lll_l1_ (u"ࠫอืวๆฮࠪᱟ"),l11lll_l1_ (u"ࠬ฿ัุ้ࠪᱠ"),l11lll_l1_ (u"࠭ใๅ์หหฯ࠭ᱡ"),l11lll_l1_ (u"ࠧศ฼ส๊๎࠭ᱢ")]
				#if any(value in title for value in l111ll1l1_l1_):
				if not any(value in title for value in l1l1l1_l1_):
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱣ"),l111ll_l1_+title,link,302)
	else: l1111l_l1_(url,html)
	return
def l1111l_l1_(url,html=l11lll_l1_ (u"ࠩࠪᱤ")):
	if html==l11lll_l1_ (u"ࠪࠫᱥ"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᱦ"),url,l11lll_l1_ (u"ࠬ࠭ᱧ"),l11lll_l1_ (u"࠭ࠧᱨ"),l11lll_l1_ (u"ࠧࠨᱩ"),l11lll_l1_ (u"ࠨࠩᱪ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᱫ"))
		html = response.content
		#html = DECODE_ADILBO_HTML(html)
	if l11lll_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᱬ") in url:
		url,seq = url.split(l11lll_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨᱭ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠭ࡃࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠪࠩᱮ"),html,re.DOTALL)
		block = l1l1ll1_l1_[int(seq)-1]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡰࡦࡼࡂࠬᱯ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡣ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᱰ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,data,l1llll_l1_ in items:
		title = re.findall(l11lll_l1_ (u"ࠨ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠳࠰࠿࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࡪࡳ࠾ࠨᱱ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l11lll_l1_ (u"ࠩ࡟ࡲࠬᱲ"),l11lll_l1_ (u"ࠪࠫᱳ")).strip(l11lll_l1_ (u"ࠫࠥ࠭ᱴ"))
		if not title or title==l11lll_l1_ (u"ࠬ࠭ᱵ"):
			title = re.findall(l11lll_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠧࡄ࠮ࠫࡁ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᱶ"),data,re.DOTALL)
			if title: title = title[0].replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪᱷ"),l11lll_l1_ (u"ࠨࠩᱸ")).strip(l11lll_l1_ (u"ࠩࠣࠫᱹ"))
			if not title or title==l11lll_l1_ (u"ࠪࠫᱺ"):
				title = re.findall(l11lll_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᱻ"),data,re.DOTALL)
				title = title[0].replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨᱼ"),l11lll_l1_ (u"࠭ࠧᱽ")).strip(l11lll_l1_ (u"ࠧࠡࠩ᱾"))
		title = unescapeHTML(title)
		#if title==l11lll_l1_ (u"ࠨࠩ᱿"): continue
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l11l1_l1_ = link+data+l1llll_l1_
			if l11lll_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫᲀ") in l11l1_l1_ or l11lll_l1_ (u"ุ้๊ࠪำๅࠩᲁ") in l11l1_l1_ or l11lll_l1_ (u"ࠫࠧ࡫ࡰࡪࡵࡲࡨࡪࠨࠧᲂ") in l11l1_l1_:
				if l11lll_l1_ (u"ࠬฮัศ็ฯࠫᲃ") in data: title = l11lll_l1_ (u"࠭ศา่ส้ัࠦࠧᲄ")+title
				elif l11lll_l1_ (u"ࠧๆี็ื้࠭ᲅ") in data or l11lll_l1_ (u"ࠨ็๋ื๊࠭ᲆ") in data: title = l11lll_l1_ (u"่ࠩืู้ไࠡࠩᲇ")+title
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᲈ"),l111ll_l1_+title,link,303,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᲉ"),l111ll_l1_+title,link,305,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᲊ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ᲋"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᲌"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ᲍")+title,link,302)
	return
def l1llll1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭᲎"),url,l11lll_l1_ (u"ࠪࠫ᲏"),l11lll_l1_ (u"ࠫࠬᲐ"),l11lll_l1_ (u"ࠬ࠭Ბ"),l11lll_l1_ (u"࠭ࠧᲒ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡕࡈࡅࡘࡕࡎࡔ࠯࠴ࡷࡹ࠭Დ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	name = re.findall(l11lll_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶ࡬ࡸࡱ࡫࠾ࠨᲔ"),html,re.DOTALL)
	name = name[0].replace(l11lll_l1_ (u"ࠩࡿࠤุ๐ๅศ้ࠢหํ࠭Ვ"),l11lll_l1_ (u"ࠪࠫᲖ")).replace(l11lll_l1_ (u"ࠫࡈ࡯࡭ࡢࠢࡑࡳࡼ࠭Თ"),l11lll_l1_ (u"ࠬ࠭Ი")).strip(l11lll_l1_ (u"࠭ࠠࠨᲙ")).replace(l11lll_l1_ (u"ࠧࠡࠢࠪᲚ"),l11lll_l1_ (u"ࠨࠢࠪᲛ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡷࡪࡧࡳࡰࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫ࡣࡵ࡫ࡲࡲࡃ࠭Ნ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᲝ"),block,re.DOTALL)
		if len(items)>1:
			for link,title in items:
				#title = name+l11lll_l1_ (u"ࠫࠥ࠭Პ")+title.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨᲟ"),l11lll_l1_ (u"࠭ࠧᲠ")).strip(l11lll_l1_ (u"ࠧࠡࠩᲡ"))
				title = title.replace(l11lll_l1_ (u"ࠨ࡞ࡱࠫᲢ"),l11lll_l1_ (u"ࠩࠪᲣ")).strip(l11lll_l1_ (u"ࠪࠤࠬᲤ"))
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᲥ"),l111ll_l1_+title,link,304)
		else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	if l11lll_l1_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧᲦ") not in url: url = url.strip(l11lll_l1_ (u"࠭࠯ࠨᲧ"))+l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮ࡩ࡯ࡩࠪᲨ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᲩ"),url,l11lll_l1_ (u"ࠩࠪᲪ"),l11lll_l1_ (u"ࠪࠫᲫ"),l11lll_l1_ (u"ࠫࠬᲬ"),l11lll_l1_ (u"ࠬ࠭Ჭ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭Ხ"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11lll_l1_ (u"ࠧࠨᲯ"),html)
	if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡱࡧࡲࡺ࠱ࠪᲰ") not in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡩࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᲱ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᲲ"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠫࡡࡴࠧᲳ"),l11lll_l1_ (u"ࠬ࠭Ჴ")).strip(l11lll_l1_ (u"࠭ࠠࠨᲵ"))
			title = l11lll_l1_ (u"ࠧศๆะ่็ฯࠠࠨᲶ")+title
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᲷ"),l111ll_l1_+title,link,305)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡨࡪࡺࡡࡪ࡮ࡶࠦ࠭࠴ࠪࡀࠫࠥࡶࡪࡲࡡࡵࡧࡧࠦࠬᲸ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᲹ"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			title = title.replace(l11lll_l1_ (u"ࠫࡡࡴࠧᲺ"),l11lll_l1_ (u"ࠬ࠭᲻")).strip(l11lll_l1_ (u"࠭ࠠࠨ᲼"))
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ჽ"),l111ll_l1_+title,link,305,l1llll_l1_)
	return
def PLAY(url):
	l11lll_l1_ (u"ࠣࠤࠥࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠥ࡫ࡸࡲࡲࠠ࠾ࠢࡇࡉࡈࡕࡄࡆࡡࡄࡈࡎࡒࡂࡐࡡࡋࡘࡒࡒࠨࡩࡶࡰࡰ࠮ࠐࠉࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡪ࡬ࡲࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࡠ࠶࡝ࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨࠫࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌࡶࡪࡪࡩࡳࡧࡦࡸࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫࡶࡪࡪࡩࡳࡧࡦࡸࡤ࡮ࡴ࡮࡮ࠬࠎࠎࡩ࡯ࡰ࡭࡬ࡩࡸࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡵ࡫ࡪࡧࡶࠎࠎࡖࡈࡑࡕࡈࡗࡘࡏࡄࠡ࠿ࠣࡧࡴࡵ࡫ࡪࡧࡶ࡟ࠬࡖࡈࡑࡕࡈࡗࡘࡏࡄࠨ࡟ࠍࠍࡻ࡫ࡲࡪࡨࡼࡣࡱ࡯࡮࡬ࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠤ࡫ࡶࡪ࡬ࠠ࠾ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ࠰ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱࠠ࠾ࠢࡹࡩࡷ࡯ࡦࡺࡡ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠰ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡀࠧࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀࠫ࠰ࡖࡈࡑࡕࡈࡗࡘࡏࡄࡾࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ࠯ࠊࠊࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎࡼࡥࡳ࡫ࡩࡽࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡊࡅࡄࡑࡇࡉࡤࡇࡄࡊࡎࡅࡓࡤࡎࡔࡎࡎࠫࡺࡪࡸࡩࡧࡻࡢ࡬ࡹࡳ࡬ࠪࠌࠌࠧࡦࡪ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡤࡨࠧࠦࡴࡢࡴࡪࡩࡹࡃࠢࡠࡤ࡯ࡥࡳࡱࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡸࡨࡶ࡮࡬ࡹࡠࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡧࡤࡠ࡮࡬ࡲࡰࠦ࠽ࠡࡣࡧࡣࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠣࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡔࡊࡒࡖ࡙ࡥࡃࡂࡅࡋࡉ࠱࠭ࡇࡆࡖࠪ࠰ࡦࡪ࡟࡭࡫ࡱ࡯࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧࠪࠌࠌࠧࡦࡪ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࠨࡧࡤࡠࡪࡷࡱࡱࠦ࠽ࠡࡆࡈࡇࡔࡊࡅࡠࡃࡇࡍࡑࡈࡏࡠࡊࡗࡑࡑ࠮ࡡࡥࡡ࡫ࡸࡲࡲࠩࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡥࡸࡳࠨࠠࡴࡶࡼࡰࡪࡃࠢࡥ࡫ࡶࡴࡱࡧࡹ࠻ࠢࡱࡳࡳ࡫࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࡞࠴ࡢ࠱ࠧ࠰ࠩࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡤ࠱ࡧ࡮ࡳࡡࡷ࡫ࡧࡷ࠳ࡲࡩࡷࡧ࠲ࠫࢂࠐࠉࠣࠤࠥᲾ")
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠩࡺࡥࡹࡩࡨࡪࡰࡪ࠳ࠬᲿ")
	#server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ᳀"))
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᳁"):None,l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭᳂"):server}
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ᳃"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ᳄"),l11lll_l1_ (u"ࠨࠩ᳅"),l11lll_l1_ (u"ࠩࠪ᳆"),l11lll_l1_ (u"ࠪࠫ᳇"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧ᳈"))
	html = response.content
	#html = DECODE_ADILBO_HTML(html)
	#l11l11l_l1_ = l1ll1l1l11_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡲ࡯ࡸࡧࡵࠫ᳉"))
	#html = l1ll1l11l1_l1_(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ᳊"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ᳋"),l11lll_l1_ (u"ࠨࠩ᳌"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠸ࡷ࡬ࠬ᳍"))
	#if html and kodi_version>18.99: html = html.decode(l11lll_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ᳎"))
	#html = DECODE_ADILBO_HTML(html)
	l1111_l1_ = []
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᳏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᳐"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"࠭࡜࡯ࠩ᳑"),l11lll_l1_ (u"ࠧࠨ᳒")).strip(l11lll_l1_ (u"ࠨࠢࠪ᳓"))
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ᳔࠭ࠪ"),title,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ᳕")+l11l111l_l1_[0]
				#title = l11lll_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻ᳖ࠬ")
				title = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧ᳗ࠪ"))
			else: l11l111l_l1_ = l11lll_l1_ (u"᳘࠭ࠧ")
			l1lllllll1_l1_ = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᳙")+title+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ᳚")+l11l111l_l1_
			l1111_l1_.append(l1lllllll1_l1_)
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡻࡦࡺࡣࡩࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᳛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# l1l11llll_l1_ l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠪࠬ࠴࠵࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞᳜ࠩ"),block,re.DOTALL)
		for link in links:
			link = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼᳝ࠪ")+link
			title = SERVER(link,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧ᳞ࠪ"))
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ᳟ࠧ")+title+l11lll_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ᳠")
			l1111_l1_.append(link)
		# l1ll1l11ll_l1_ l11ll1l1l_l1_ links
		links = re.findall(l11lll_l1_ (u"ࠨࡣ࡭ࡥࡽࡢࠨࡼࡷࡵࡰ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᳡"),html,re.DOTALL)
		if links:
			items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡰࡧࡩࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁ᳢ࠫ"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l11lll_l1_ (u"ࠪࡠࡳ᳣࠭"),l11lll_l1_ (u"᳤ࠫࠬ")).strip(l11lll_l1_ (u"᳥ࠬࠦࠧ"))
				title = title.replace(l11lll_l1_ (u"࠭ࡃࡪ࡯ࡤࠤࡓࡵࡷࠨ᳦"),l11lll_l1_ (u"ࠧࡄ࡫ࡰࡥࡓࡵࡷࠨ᳧"))
				link = links[0]+l11lll_l1_ (u"ࠨࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡻ࡮ࡺࡣࡩࠨ࡬ࡲࡩ࡫ࡸ࠾᳨ࠩ")+index+l11lll_l1_ (u"ࠩࠩ࡭ࡩࡃࠧᳩ")+id+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᳪ")+title+l11lll_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᳫ")
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪᳬ"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ᳭ࠬ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠧࠨᳮ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠨࠩᳯ"): return
	search = search.replace(l11lll_l1_ (u"ࠩࠣࠫᳰ"),l11lll_l1_ (u"ࠪ࠯ࠬᳱ"))
	url = l11ll1_l1_ + l11lll_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩᳲ")+search
	l1111l_l1_(url)
	return
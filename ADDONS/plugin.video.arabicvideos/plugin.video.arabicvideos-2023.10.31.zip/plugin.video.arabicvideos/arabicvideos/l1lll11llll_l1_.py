# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭♨")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡅࡃ࠶ࡢࠫ♩")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
# l1l1ll11_l1_	https://l1lllll1l11_l1_-l1lllll1111_l1_.net
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/l111l11l1l_l1_.l1lll1l1111_l1_
# l1lll1ll111_l1_	https://t.me/l1lll11lll1_l1_
l1l1l1_l1_ = [l11lll_l1_ (u"࠭ว๋ฮํࠤอูสࠨ♪"),l11lll_l1_ (u"ࠧศฬุ่ࠥฮๆศࠩ♫"),l11lll_l1_ (u"ࠨษํะ๏ࠦศิฬࠣห้อีๅ์ࠪ♬"),l11lll_l1_ (u"ࠩส๎ั๐ࠠษีอࠤฬ๊ฬะ์าࠫ♭"),l11lll_l1_ (u"ࠪห๏า๊ࠡสึฮࠥอไษัํ่ࠬ♮"),l11lll_l1_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ♯"),l11lll_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสึฮࠬ♰")]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==800: results = MENU()
	elif mode==801: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==802: results = l1l11l_l1_(url)
	elif mode==803: results = PLAY(url)
	elif mode==804: results = l1lll1l11ll_l1_(url)
	elif mode==806: results = l1lll1l1l1_l1_(url,l1l11l1_l1_)
	elif mode==809: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭♱"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ♲"),l11lll_l1_ (u"ࠨࠩ♳"),809,l11lll_l1_ (u"ࠩࠪ♴"),l11lll_l1_ (u"ࠪࠫ♵"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ♶"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ♷"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠫ♸"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ♹"),804,l11lll_l1_ (u"ࠨࠩ♺"),l11lll_l1_ (u"ࠩࠪ♻"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ♼"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ♽"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ♾"),l11lll_l1_ (u"࠭ࠧ♿"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⚀"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩ⚁"),l11lll_l1_ (u"ࠩࠪ⚂"),l11lll_l1_ (u"ࠪࠫ⚃"),l11lll_l1_ (u"ࠫࠬ⚄"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⚅"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡮ࡢࡸ࠰ࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⚆"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⚇"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ⚈"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ⚉") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⚊"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⚋")+l111ll_l1_+title,link,801)
		addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⚌"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⚍"),l11lll_l1_ (u"ࠧࠨ⚎"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡉ࡯࡯ࡶࡨࡲࡹ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࡂࠬ⚏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴࡔࡪࡶ࡯ࡩ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⚐"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ⚑"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⚒") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⚓"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⚔")+l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠧࠨ⚕"),l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡳࡥ࡯ࡷࠪ⚖"))
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⚗"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⚘"),l11lll_l1_ (u"ࠫࠬ⚙"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⚚"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⚛"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ⚜"))
			if any(value in title for value in l1l1l1_l1_): continue
			if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭⚝") not in link: link = l11ll1_l1_+link
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⚞"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⚟")+l111ll_l1_+title,link,801)
	return html
def l1lll1l1l1_l1_(url,type=l11lll_l1_ (u"ࠫࠬ⚠")):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⚡"),l11lll_l1_ (u"࠭ࠧ⚢"),type,url)
	#if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⚣") in url: type = l11lll_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⚤")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⚥"),url,l11lll_l1_ (u"ࠪࠫ⚦"),l11lll_l1_ (u"ࠫࠬ⚧"),l11lll_l1_ (u"ࠬ࠭⚨"),l11lll_l1_ (u"࠭ࠧ⚩"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⚪"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࡚ࡩࡵ࡮ࡨ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡦࡅࡲࡲࡹ࡫࡮ࡵࠩ⚫"),html,re.DOTALL)
	if l1l1ll1_l1_:
		l1lllll_l1_,l1l1l_l1_,items = l11lll_l1_ (u"ࠩࠪ⚬"),l11lll_l1_ (u"ࠪࠫ⚭"),[]
		for name,block in l1l1ll1_l1_:
			if l11lll_l1_ (u"ࠫา๊โศฬࠪ⚮") in name: l1l1l_l1_ = block
			if l11lll_l1_ (u"๋่ࠬศี่ࠫ⚯") in name: l1lllll_l1_ = block
		if l1lllll_l1_ and not type:
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⚰"),l1lllll_l1_,re.DOTALL)
			if len(items)>1:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⚱"),l111ll_l1_+title,link,806,l1llll_l1_,l11lll_l1_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ⚲"))
		if l1l1l_l1_ and len(items)<2:
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⚳"),l1l1l_l1_,re.DOTALL)
			if items:
				for link,l1llll_l1_,title in items:
					addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⚴"),l111ll_l1_+title,link,803,l1llll_l1_)
			else:
				items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⚵"),l1l1l_l1_,re.DOTALL)
				for link,title in items:
					addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⚶"),l111ll_l1_+title,link,803)
	return
def l1111l_l1_(url,type=l11lll_l1_ (u"࠭ࠧ⚷")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ⚸"),l11lll_l1_ (u"ࠨࠩ⚹"),l11lll_l1_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠩ⚺"),url)
	limit,start,l11lllll1_l1_,select,l1lll1l1ll1_l1_ = 0,0,l11lll_l1_ (u"ࠪࠫ⚻"),l11lll_l1_ (u"ࠫࠬ⚼"),l11lll_l1_ (u"ࠬ࠭⚽")
	if l11lll_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ⚾") in type:
		# next l1l11l1_l1_
		l1lll1ll1l1_l1_,l11llll11_l1_ = url.split(l11lll_l1_ (u"ࠧࡀࡰࡨࡼࡹࡃࡰࡢࡩࡨࠪࠬ⚿"))
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ⛀"):l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ⛁")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ⛂"),l1lll1ll1l1_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠫࠬ⛃"),l11lll_l1_ (u"ࠬ࠭⛄"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⛅"))
		html = response.content
		l11lll1l_l1_ = l11lll_l1_ (u"ࠧࡴࡧࡦࡇࡴࡴࡴࡦࡰࡷࠫ⛆")+html+l11lll_l1_ (u"ࠨ࠾ࡩࡳࡴࡺࡥࡳࡀࠪ⛇")
	else:
		# l11ll11l1l_l1_ html
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭⛈"),url,l11lll_l1_ (u"ࠪࠫ⛉"),l11lll_l1_ (u"ࠫࠬ⛊"),l11lll_l1_ (u"ࠬ࠭⛋"),l11lll_l1_ (u"࠭ࠧ⛌"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭⛍"))
		html = response.content
		l11lll1l_l1_ = html
	items,l1lllll1l1l_l1_,filters = [],False,False
	if not type and l11lll_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡹࠧ⛎") not in url:
		# l1lllll1l1l_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡰࡥ࡮ࡴࡃࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⛏"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⛐"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l11lll_l1_ (u"ࠫࠥ࠭⛑"))
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛒"),l111ll_l1_+title,link,801,l11lll_l1_ (u"࠭ࠧ⛓"),l11lll_l1_ (u"ࠧࡴࡷࡥࡱࡪࡴࡵࠨ⛔"))
				l1lllll1l1l_l1_ = True
	if not l1lllll1l1l_l1_:
		# items
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡵࡨࡧࡈࡵ࡮ࡵࡧࡱࡸ࠭࠴ࠪࡀࠫࡰࡥ࡮ࡴࡃࡰࡰࡷࡩࡳࡺࠧ⛕"),l11lll1l_l1_,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲ࡭࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⛖"),block,re.DOTALL)
			for link,l1llll_l1_,title in items:
				link = l111l_l1_(link)
				l1llll_l1_ = l1llll_l1_.strip(l11lll_l1_ (u"ࠪࡠࡳ࠭⛗"))
				title = unescapeHTML(title)
				if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭⛘") in link and type==l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ⛙"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛚"),l111ll_l1_+title,link,806,l1llll_l1_,l11lll_l1_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ⛛"))
				elif l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⛜") in link: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⛝"),l111ll_l1_+title,link,806,l1llll_l1_)
				elif l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱࡷ࠴࠭⛞") in link: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⛟"),l111ll_l1_+title,link,801,l1llll_l1_,l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ⛠"))
				elif l11lll_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱࡷࠬ⛡") in url: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⛢"),l111ll_l1_+title,link,801,l1llll_l1_,l11lll_l1_ (u"ࠨࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲࡸ࠭⛣"))
				else: addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⛤"),l111ll_l1_+title,link,803,l1llll_l1_)
		# l1lll1lll1_l1_
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡰࡴࡧࡤࡎࡱࡵࡩࡕࡧࡲࡢ࡯ࡶࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀ࠭⛥"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			params = EVAL(l11lll_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ⛦"),block)
			l1lll1l1ll1_l1_ = params[l11lll_l1_ (u"ࠬࡧࡪࡢࡺࡸࡶࡱ࠭⛧")]
			l1lll11ll1l_l1_ = int(params[l11lll_l1_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡱࡣࡪࡩࠬ⛨")])+1
			l1lll11ll11_l1_ = int(params[l11lll_l1_ (u"ࠧ࡮ࡣࡻࡣࡵࡧࡧࡦࠩ⛩")])
			query = params[l11lll_l1_ (u"ࠨࡲࡲࡷࡹࡹࠧ⛪")].replace(l11lll_l1_ (u"ࠩࡉࡥࡱࡹࡥࠨ⛫"),l11lll_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ⛬")).replace(l11lll_l1_ (u"࡙ࠫࡸࡵࡦࠩ⛭"),l11lll_l1_ (u"ࠬࡺࡲࡶࡧࠪ⛮")).replace(l11lll_l1_ (u"࠭ࡎࡰࡰࡨࠫ⛯"),l11lll_l1_ (u"ࠧ࡯ࡷ࡯ࡰࠬ⛰"))
			if l1lll11ll1l_l1_<l1lll11ll11_l1_:
				l11llll11_l1_ = l11lll_l1_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮࠾࡮ࡲࡥࡩࡳ࡯ࡳࡧࠩࡵࡺ࡫ࡲࡺ࠿ࠪ⛱")+QUOTE(query,l11lll_l1_ (u"ࠩࠪ⛲"))+l11lll_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⛳")+str(l1lll11ll1l_l1_)
				l11l11l_l1_ = l1lll1l1ll1_l1_+l11lll_l1_ (u"ࠫࡄࡴࡥࡹࡶࡀࡴࡦ࡭ࡥࠧࠩ⛴")+l11llll11_l1_
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⛵"),l111ll_l1_+l11lll_l1_ (u"࠭ฬๅสࠣห้๋า๋ัࠪ⛶"),l11l11l_l1_,801,l11lll_l1_ (u"ࠧࠨ⛷"),l11lll_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࡤ࠭⛸")+type)
		elif l11lll_l1_ (u"ࠩࡂࡲࡪࡾࡴ࠾ࡲࡤ࡫ࡪࠬࠧ⛹") in url:
			l11llll11_l1_,l1ll11l1l_l1_ = l11llll11_l1_.rsplit(l11lll_l1_ (u"ࠪࡁࠬ⛺"),1)
			l1ll11l1l_l1_ = int(l1ll11l1l_l1_)+1
			l11l11l_l1_ = l1lll1ll1l1_l1_+l11lll_l1_ (u"ࠫࡄࡴࡥࡹࡶࡀࡴࡦ࡭ࡥࠧࠩ⛻")+l11llll11_l1_+l11lll_l1_ (u"ࠬࡃࠧ⛼")+str(l1ll11l1l_l1_)
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⛽"),l111ll_l1_+l11lll_l1_ (u"ࠧอๆหࠤฬ๊ๅำ์าࠫ⛾"),l11l11l_l1_,801,l11lll_l1_ (u"ࠨࠩ⛿"),l11lll_l1_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࡥࠧ✀")+type)
	return
def l1lll1l11ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ✁"),url,l11lll_l1_ (u"ࠫࠬ✂"),l11lll_l1_ (u"ࠬ࠭✃"),l11lll_l1_ (u"࠭ࠧ✄"),l11lll_l1_ (u"ࠧࠨ✅"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶࠰ࡊࡎࡒࡔࡆࡔࡖ࠱࠶ࡹࡴࠨ✆"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡹࡧࡥ࡮ࡢࡸࠫ࠲࠯ࡅࠩࡴࡧࡦࡇࡴࡴࡴࡦࡰࡷࠤࠬ✇"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & options block
		l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡻࡲࡳࡧࡱࡸࡤࡵࡰࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ✈"),block,re.DOTALL)
		for name,block in l111l11_l1_:
			if l11lll_l1_ (u"ࠫฬ๊สึ่ํๅࠬ✉") in name: continue
			name = name.strip(l11lll_l1_ (u"ࠬࠦࠧ✊"))
			# link & value
			items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ✋"),block,re.DOTALL)
			for link,value in items:
				title = name+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ✌")+value
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ✍"),l111ll_l1_+title,link,801,l11lll_l1_ (u"ࠩࠪ✎"),l11lll_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪ✏"))
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ✐"),url,l11lll_l1_ (u"ࠬ࠭✑"),l11lll_l1_ (u"࠭ࠧ✒"),l11lll_l1_ (u"ࠧࠨ✓"),l11lll_l1_ (u"ࠨࠩ✔"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭✕"))
	html = response.content
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡹࡪ࠾ศๆอู๋๐แ࠽࠱ࡷࡨࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ✖"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	l1lllll1_l1_,l1lll11ll1_l1_ = [],[]
	# l11ll1l1l_l1_ links
	l1lll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡵࡵࡳࡵࡇࡰࡦࡪࡪ࠮ࠫࡁࡳࡳࡸࡺ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ✗"),html,re.DOTALL)
	if l1lll1llll1_l1_:
		links = base64.b64decode(l1lll1llll1_l1_[0])
		if kodi_version>18.99: links = links.decode(l11lll_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ✘"))
		links = EVAL(l11lll_l1_ (u"࠭ࡤࡪࡥࡷࠫ✙"),links)
		links = list(links.values())
		for link in links:
			if link not in l1lll11ll1_l1_:
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ✚"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ✛")+server+l11lll_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ✜"))
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡴࡦ࡭ࡥࡄࡱࡱࡸࡪࡴࡴࡅࡱࡺࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ✝"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡁࡺࡲ࠿࠰࠭ࡃࡁࡺࡤ࠿࡝ࠣࡥ࠲ࢀࡁ࠮࡜ࡠ࠮࠭ࡢࡤࡼ࠵࠯࠸ࢂ࠯࡛ࠡࡣ࠰ࡾࡆ࠳࡚࡞ࠬ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ✞"),block,re.DOTALL)
		for l11l111l_l1_,link in items:
			if link not in l1lll11ll1_l1_:
				if l11lll_l1_ (u"ࠬ࠵࠿ࡶࡴ࡯ࡁࠬ✟") in link: link = link.split(l11lll_l1_ (u"࠭࠯ࡀࡷࡵࡰࡂ࠭✠"))[1]
				l1lll11ll1_l1_.append(link)
				server = SERVER(link,l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ✡"))
				l1lllll1_l1_.append(link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ✢")+server+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡟ࡠࡡࠪ✣")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠪหำะัࠡษ็ๅ๏ี๊้ࠢส่๊์วิส࠽ࠫ✤"), l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ✥"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠬࠦࠧ✦"),l11lll_l1_ (u"࠭ࠫࠨ✧"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ✨")+l111l1l_l1_
	l1111l_l1_(url,l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ✩"))
	return
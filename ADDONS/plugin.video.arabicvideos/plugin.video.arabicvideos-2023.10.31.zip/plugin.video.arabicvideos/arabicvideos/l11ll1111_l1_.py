# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧྡྷ")
#headers = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪྣ"):l11lll_l1_ (u"ࠧࠨྤ")}
headers = {l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬྥ"):l1l11l11l_l1_()}
l111ll_l1_ = l11lll_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨྦ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠪห้ืฦ๋ีํอࠬྦྷ"),l11lll_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษ๎ࠫྨ"),l11lll_l1_ (u"๋ࠬีศำ฼๋ࠬྩ"),l11lll_l1_ (u"࠭วฺๆ้ࠤ๊฿ๆศࠢ⠖ࠤࡋࡵࡲࠡࡣࡧࡷࠬྪ"),l11lll_l1_ (u"ࠧๆ๊หห๏๊วหࠩྫ"),l11lll_l1_ (u"ࠨสิห๊าࠠไ็ห๎ํะัࠨྫྷ"),l11lll_l1_ (u"ࠩส่฾อศࠡๅ่ฬ๏๎สาࠩྭ"),l11lll_l1_ (u"ࠪหุ๊วๆ์สฮࠬྮ"),l11lll_l1_ (u"ࠫฬิั๊ࠩྯ"),l11lll_l1_ (u"ࠬอโิษ่ࠤฬิั๋ࠩྰ"),l11lll_l1_ (u"࠭วีฬิห่อสࠨྱ")]
def MAIN(mode,url,text):
	if   mode==250: results = MENU()
	elif mode==251: results = l1111l_l1_(url,text)
	elif mode==252: results = PLAY(url)
	elif mode==253: results = l1llllll_l1_(url)
	elif mode==254: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧྲ")+text)
	elif mode==255: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬླ")+text)
	elif mode==256: results = l1l11l_l1_(url,text)
	elif mode==259: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ྴ"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡲࡧࡩ࡯ࠩྵ"),l11lll_l1_ (u"ࠫࠬྶ"),headers,l11lll_l1_ (u"ࠬ࠭ྷ"),l11lll_l1_ (u"࠭ࠧྸ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫྐྵ"))
	html = response.content
	#l11l1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧྺ"),html,re.DOTALL)
	#if l11l1l1l_l1_: l11l1l1l_l1_ = SERVER(l11l1l1l_l1_[0],l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ྻ"))
	#else: l11l1l1l_l1_ = l11ll1_l1_
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪྼ"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ྽"),l11lll_l1_ (u"ࠬ࠭྾"),259,l11lll_l1_ (u"࠭ࠧ྿"),l11lll_l1_ (u"ࠧࠨ࿀"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ࿁"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿂"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭࿃"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬ࿄"),254)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿅"),l111ll_l1_+l11lll_l1_ (u"࠭แๅฬิࠤ่อๅๅ࿆ࠩ"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲หำื้ࠨ࿇"),255)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭࿈"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࿉"),l11lll_l1_ (u"ࠪࠫ࿊"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿋"),l111ll_l1_+l11lll_l1_ (u"ࠬอไๆ็ํึฮ࠭࿌"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿍"),251,l11lll_l1_ (u"ࠧࠨ࿎"),l11lll_l1_ (u"ࠨࠩ࿏"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡧࡩ࡯ࠩ࿐"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿑"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿒")+l111ll_l1_+l11lll_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ࿓"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿔"),251,l11lll_l1_ (u"ࠧࠨ࿕"),l11lll_l1_ (u"ࠨࠩ࿖"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭࿗"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿘"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿙")+l111ll_l1_+l11lll_l1_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫ࿚"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ࿛"),251,l11lll_l1_ (u"ࠧࠨ࿜"),l11lll_l1_ (u"ࠨࠩ࿝"),l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࿞"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࿟"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࿠")+l111ll_l1_+l11lll_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏ࠬ࿡"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯࡭ࡣࡷࡩࡸࡺࠧ࿢"),251,l11lll_l1_ (u"ࠧࠨ࿣"),l11lll_l1_ (u"ࠨࠩ࿤"),l11lll_l1_ (u"ࠩ࡯ࡥࡸࡺࡥࡴࡶࠪ࿥"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ࿦"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࿧"),l11lll_l1_ (u"ࠬ࠭࿨"),9999)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡍࡦࡰࡸࡌࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࿩"),html,re.DOTALL)
	l11l1_l1_ = l1l11ll_l1_[0]
	l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࿪"),l11l1_l1_,re.DOTALL)
	for link,title in l1l1lll_l1_:
		title = unescapeHTML(title)
		if title not in l1l1l1_l1_ and title!=l11lll_l1_ (u"ࠨࠩ࿫"):
			if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ࿬") not in link: link = l11ll1_l1_+link
			#link = link.rstrip(l11lll_l1_ (u"ࠪ࠳ࠬ࿭")).replace(SERVER(link,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ࿮")),l11ll1_l1_)
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿯"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࿰")+l111ll_l1_+title,link,256)
	return html
def l1l11l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ࿱"),l11lll_l1_ (u"ࠨࠩ࿲"),l11lll_l1_ (u"ࠩࡖ࡙ࡇࡓࡅࡏࡗࠣࠤࠥࠦࠠࠨ࿳")+type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ࿴"),url,l11lll_l1_ (u"ࠫࠬ࿵"),headers,l11lll_l1_ (u"ࠬ࠭࿶"),l11lll_l1_ (u"࠭ࠧ࿷"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ࿸"))
	html = response.content
	if l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠪ࿹") in html: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿺"),l111ll_l1_+l11lll_l1_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪ࿻"),url,251,l11lll_l1_ (u"ࠫࠬ࿼"),l11lll_l1_ (u"ࠬ࠭࿽"),l11lll_l1_ (u"࠭࡭ࡰࡵࡷࠫ࿾"))
	if l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡶࠫ࿿") in html: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨက"),l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪခ"),url,251,l11lll_l1_ (u"ࠪࠫဂ"),l11lll_l1_ (u"ࠫࠬဃ"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧင"))
	if l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠩစ") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ဆ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			if len(l1l1ll1_l1_)>1 and type==l11lll_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧဇ"): block = l1l1ll1_l1_[1]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪဈ"),block,re.DOTALL)
			for link,title in items:
				l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫဉ"),title,re.DOTALL)
				try: l11ll1lll_l1_ = l1lll1lll_l1_[0][0]
				except: l11ll1lll_l1_ = l11lll_l1_ (u"ࠫࠬည")
				try: l11lll111_l1_ = l1lll1lll_l1_[0][1]
				except: l11lll111_l1_ = l11lll_l1_ (u"ࠬ࠭ဋ")
				l1lll1lll_l1_ = l11ll1lll_l1_+l11lll111_l1_
				l1lll1lll_l1_ = l1lll1lll_l1_.replace(l11lll_l1_ (u"࠭࡜࡯ࠩဌ"),l11lll_l1_ (u"ࠧࠨဍ"))
				#LOG_THIS(l11lll_l1_ (u"ࠨࠩဎ"),str(l1lll1lll_l1_))
				if l11lll_l1_ (u"ࠩ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠫဏ") in title:
					l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧတ"),title,re.DOTALL)
					if l11ll11ll_l1_: l1lll1lll_l1_ = l11ll11ll_l1_[0]
				if not l1lll1lll_l1_:
					l11ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩထ"),title,re.DOTALL)
					if l11ll11ll_l1_: l1lll1lll_l1_ = l11ll11ll_l1_[0]
				if l1lll1lll_l1_:
					if l11lll_l1_ (u"ࠬࡱࡥࡺ࠿ࠪဒ") in link: type = link.split(l11lll_l1_ (u"࠭࡫ࡦࡻࡀࠫဓ"))[1]
					else: type = l11lll_l1_ (u"ࠧ࡯ࡧࡺࡩࡸࡺࠧန")
					#link = link.rstrip(l11lll_l1_ (u"ࠨ࠱ࠪပ")).replace(SERVER(link,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭ဖ")),l11ll1_l1_)
					l1lll1lll_l1_ = l1lll1lll_l1_.strip(l11lll_l1_ (u"ࠪࠤࠬဗ"))
					addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫဘ"),l111ll_l1_+l1lll1lll_l1_,link,251,l11lll_l1_ (u"ࠬ࠭မ"),l11lll_l1_ (u"࠭ࠧယ"),type)
	return
def l1111l_l1_(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨရ"),l11lll_l1_ (u"ࠨࠩလ"),l11lll_l1_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠢࠣࠤࠥࠦࠧဝ")+type,url)
	method,data,items = l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧသ"),l11lll_l1_ (u"ࠫࠬဟ"),[]
	if type==l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ဠ"):
		if l11lll_l1_ (u"࠭࠿ࠨအ") in url:
			l11lll1ll_l1_,l11llll11_l1_ = l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬဢ"),{}
			l11l11l_l1_,l11llll1l_l1_ = url.split(l11lll_l1_ (u"ࠨࡁࠪဣ"))
			lines = l11llll1l_l1_.split(l11lll_l1_ (u"ࠩࠩࠫဤ"))
			for line in lines:
				key,value = line.split(l11lll_l1_ (u"ࠪࡁࠬဥ"))
				l11llll11_l1_[key] = value
			if lines: method,url,data = l11lll1ll_l1_,l11l11l_l1_,l11llll11_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,method,url,data,headers,l11lll_l1_ (u"ࠫࠬဦ"),l11lll_l1_ (u"ࠬ࠭ဧ"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬဨ"))
	html = response.content
	#html = html[99000:]
	if type==l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨဩ"): l1l1ll1_l1_ = [html]
	elif l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪဪ") in type: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡐࡥ࡮ࡴࡓ࡭࡫ࡧࡩࡸ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡐ࡮ࡴ࡫ࡴࡎ࡬ࡷࡹ࠭ါ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧာ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫัี๊ะࠢส่ฬ็ไศ็࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁ࡙ࠧ࡬ࡪࡦࡨࡶࡎࡴࡓࡦࡥࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫိ"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫီ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ฬะ์าࠤฬ๊อๅไสฮ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ု"),html,re.DOTALL)
	elif type==l11lll_l1_ (u"ࠧ࡮ࡱࡶࡸࠬူ"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲࡊࡰࡖࡩࡨࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡍ࡫ࡱ࡯ࡸࡒࡩࡴࡶࠪေ"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡅࡰࡴࡩ࡫ࡴ࠯ࡘࡐࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡅࡧࡵࡅ࡭ࡕࡨࡩࡩࠨࠧဲ"),html,re.DOTALL)
	if l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬဳ") in type:
		block = l1l1ll1_l1_[0]
		zz = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡰࡦࢀࡹ࠯ࠬࡂࠤ࠭ࡹࡲࡤࡾࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨဴ"),block,re.DOTALL)
		if zz:
			l1111_l1_,l1lll1ll_l1_,l1l1111ll_l1_,l1l11ll11_l1_ = zip(*zz)
			items = zip(l1111_l1_,l1l11ll11_l1_,l1lll1ll_l1_)
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࡇࡲࡦࡣ࠱࠮ࡄࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳࡜ࡸࡽ࠶࠰࠺ࢃ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩဵ"),block,re.DOTALL)
	l1l1_l1_ = []
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"࠭ࡗࡘࡇࠪံ") in title: continue
		#link = link.rstrip(l11lll_l1_ (u"ࠧ࠰့ࠩ")).replace(SERVER(link,l11lll_l1_ (u"ࠨࡷࡵࡰࠬး")),l11ll1_l1_)
		#l1llll_l1_ = l1llll_l1_.rstrip(l11lll_l1_ (u"ࠩ࠲္ࠫ")).replace(SERVER(l1llll_l1_,l11lll_l1_ (u"ࠪࡹࡷࡲ်ࠧ")),l11ll1_l1_)
		title = unescapeHTML(title)
		if l11lll_l1_ (u"ࠫฬ๊อๅไฬࠫျ") in title:
			l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨြ"),title,re.DOTALL)
			if l1lll11_l1_:
				title = l11lll_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬွ") + l1lll11_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧှ"),l111ll_l1_+title,link,253,l1llll_l1_)
			else: addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧဿ"),l111ll_l1_+title,link,252,l1llll_l1_)
		elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫ၀") in link or l11lll_l1_ (u"ุ้๊ࠪำๅࠩ၁") in title:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ၂"),l111ll_l1_+title,link,253,l1llll_l1_)
		else:
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ၃"),l111ll_l1_+title,link,252,l1llll_l1_)
	if type in [l11lll_l1_ (u"࠭࡮ࡦࡹࡨࡷࡹ࠭၄"),l11lll_l1_ (u"ࠧࡣࡧࡶࡸࠬ၅"),l11lll_l1_ (u"ࠨ࡯ࡲࡷࡹ࠭၆")]:
		items = re.findall(l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠭࡯ࡷࡰࡦࡪࡸࡳࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ၇"),html,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+link
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ၈"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ၉")+title,link,251,l11lll_l1_ (u"ࠬ࠭၊"),l11lll_l1_ (u"࠭ࠧ။"),type)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ၌"),url,l11lll_l1_ (u"ࠨࠩ၍"),headers,l11lll_l1_ (u"ࠩࠪ၎"),l11lll_l1_ (u"ࠪࠫ၏"),l11lll_l1_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬၐ"))
	html = response.content
	#items = re.findall(l11lll_l1_ (u"ࠬࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡘ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪၑ"),html,re.DOTALL)
	# the first 10000 character of the html file is l11lll11l_l1_ l1l111l11_l1_ in l1l111ll1_l1_ .. it l1l11111l_l1_ l11ll1ll1_l1_
	html = html[10000:]
	items = re.findall(l11lll_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩၒ"),html,re.DOTALL)
	if not items: return
	l1llll_l1_,name = items[0]
	if l11lll_l1_ (u"ࠧศๆะ่็ฯࠧၓ") in name: name = name.split(l11lll_l1_ (u"ࠨษ็ั้่ษࠨၔ"))[0].strip(l11lll_l1_ (u"ࠩࠣࠫၕ"))
	elif l11lll_l1_ (u"ࠪั้่ษࠨၖ") in name: name = name.split(l11lll_l1_ (u"ࠫา๊โสࠩၗ"))[0].strip(l11lll_l1_ (u"ࠬࠦࠧၘ"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳࡇࡳ࡭ࡸࡵࡤࡦࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬၙ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩၚ"),block,re.DOTALL)
		for link,l1lll11_l1_ in items:
			title = name+l11lll_l1_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤึ่ๅࠡࠩၛ")+l1lll11_l1_
			#link = link.rstrip(l11lll_l1_ (u"ࠩ࠲ࠫၜ")).replace(SERVER(link,l11lll_l1_ (u"ࠪࡹࡷࡲࠧၝ")),l11ll1_l1_)
			#l1llll_l1_ = l1llll_l1_.rstrip(l11lll_l1_ (u"ࠫ࠴࠭ၞ")).replace(SERVER(l1llll_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩၟ")),l11ll1_l1_)
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬၠ"),l111ll_l1_+title,link,252,l1llll_l1_)
	else: addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ၡ"),l111ll_l1_+l11lll_l1_ (u"ࠨ็็ๅࠥอไหึ฽๎้࠭ၢ"),url,252,l1llll_l1_)
	return
def l11l1lll1_l1_(title,link):
	l1lll1lll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡞ࡥ࠲ࢀࡁ࠮࡜࠰ࡡ࠰࠭ၣ"),title,re.DOTALL)
	if l1lll1lll_l1_: title = l1lll1lll_l1_[0]
	else: title = title+l11lll_l1_ (u"ࠪࠤࠬၤ")+SERVER(link,l11lll_l1_ (u"ࠫࡳࡧ࡭ࡦࠩၥ"))
	title = title.replace(l11lll_l1_ (u"ࠬ฿ัษࠢึ๎ิ࠭ၦ"),l11lll_l1_ (u"࠭ࠧၧ")).replace(l11lll_l1_ (u"ࠧๆสสุึ࠭ၨ"),l11lll_l1_ (u"ࠨࠩၩ")).replace(l11lll_l1_ (u"ุ่ࠩฬํฯสࠩၪ"),l11lll_l1_ (u"ࠪࠫၫ"))
	title = title.replace(l11lll_l1_ (u"ࠫ๒࠭ၬ"),l11lll_l1_ (u"ࠬ࠭ၭ"))
	title = title.replace(l11lll_l1_ (u"࠭ࠠࠡࠩၮ"),l11lll_l1_ (u"ࠧࠡࠩၯ")).replace(l11lll_l1_ (u"ࠨࠢࠣࠫၰ"),l11lll_l1_ (u"ࠩࠣࠫၱ"))
	return title
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧၲ"),url,l11lll_l1_ (u"ࠫࠬၳ"),headers,l11lll_l1_ (u"ࠬ࠭ၴ"),l11lll_l1_ (u"࠭ࠧၵ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫၶ"))
	html = response.content
	l11l11l_l1_ = response.url
	server = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠨࡷࡵࡰࠬၷ"))
	headers[l11lll_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪၸ")] = server+l11lll_l1_ (u"ࠪ࠳ࠬၹ")
	l11l1ll1l_l1_,l1l111111_l1_,l1111_l1_ = l11lll_l1_ (u"ࠫࠬၺ"),l11lll_l1_ (u"ࠬ࠭ၻ"),[]
	# l11ll1l1l_l1_ & download l11l1l11_l1_
	l1l11l1ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡇࡻࡴࡵࡱࡱࡷࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡹࡤࡸࡨ࡮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࠨࡥࡱࡺࡲࡱࡵࡡࡥ࠰࠭ࡃ࠮ࠨࠧၼ"),html,re.DOTALL)
	if l1l11l1ll_l1_: l11l1ll1l_l1_,l1l1111l1_l1_,l1l111111_l1_,l11lllll1_l1_ = l1l11l1ll_l1_[0]
	else:
		l1l11l1ll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭ࡈࡵࡵࡶࡲࡲࡸࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨၽ"),html,re.DOTALL)
		if l1l11l1ll_l1_:
			link,l1l1111l1_l1_ = l1l11l1ll_l1_[0]
			if l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠧၾ") in l1l1111l1_l1_: l11l1ll1l_l1_ = link
			else: l1l111111_l1_ = link
	if l11l1ll1l_l1_:
		# l11ll1l1l_l1_ links
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ၿ"),l11l1ll1l_l1_,l11lll_l1_ (u"ࠪࠫႀ"),headers,l11lll_l1_ (u"ࠫࠬႁ"),l11lll_l1_ (u"ࠬ࠭ႂ"),l11lll_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪႃ"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡘࡣࡷࡧ࡭࡫ࡲࡂࡴࡨࡥࠧ࠮࠮ࠫࡁ࠿࠳ࡺࡲ࠾ࠪࠩႄ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			l11l1l1l1_l1_ = l1l1ll1_l1_[0]
			l11l1l1l1_l1_ = l11l1l1l1_l1_.replace(l11lll_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧႅ"),l11lll_l1_ (u"ࠩ࠿࡬࠸ࡄࠧႆ"))
			l11l1l1l1_l1_ = l11l1l1l1_l1_.replace(l11lll_l1_ (u"ࠪࡀ࡭࠹࠾ࠨႇ"),l11lll_l1_ (u"ࠫࡁ࡮࠳࠿࠾࡫࠷ࡃ࠭ႈ"))
			l111l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࡂࡨ࠴ࡀ࠱࠮ࡄ࠮࡜ࡥ࠭ࠬࠬ࠳࠰࠿ࠪ࠾࡫࠷ࡃ࠭ႉ"),l11l1l1l1_l1_,re.DOTALL)
			if not l111l11_l1_: l111l11_l1_ = [(l11lll_l1_ (u"࠭ࠧႊ"),l11l1l1l1_l1_)]
			for l11l111l_l1_,block in l111l11_l1_:
				if l11l111l_l1_: l11l111l_l1_ = l11lll_l1_ (u"ࠧࡠࡡࡢࡣࠬႋ")+l11l111l_l1_
				items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬႌ"),block,re.DOTALL)
				for link,name in items:
					if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶႍࠧ") not in link: link = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩႎ")+link
					#name = SERVER(link,l11lll_l1_ (u"ࠫ࡭ࡵࡳࡵࠩႏ"))
					link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭႐")+name+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ႑")+l11l111l_l1_
					l1111_l1_.append(link)
		# l1l11llll_l1_ link
		links = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࡌࡪࡷࡧ࡭ࡦࠤ࠱࠮ࡄࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠠࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ႒"),html,re.DOTALL)
		if not links: links = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࡍ࡫ࡸࡡ࡮ࡧࠥ࠲࠯ࡅࠠࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡊࡈࡍࡌࡎࡔ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ႓"),html,re.DOTALL)
		if links:
			link,l11l111l_l1_ = links[0]
			name = SERVER(link,l11lll_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ႔"))
			if l11lll_l1_ (u"ࠪࠩࠬ႕") in l11l111l_l1_: link = link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ႖")+name+l11lll_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩࡥ࡟ࠨ႗")
			else: link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ႘")+name+l11lll_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࡢࡣࠬ႙")+l11l111l_l1_
			l1111_l1_.append(link)
	if l1l111111_l1_:
		# download links
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬႚ"),l1l111111_l1_,l11lll_l1_ (u"ࠩࠪႛ"),headers,l11lll_l1_ (u"ࠪࠫႜ"),l11lll_l1_ (u"ࠫࠬႝ"),l11lll_l1_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ႞"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡄࡰࡹࡱࡰࡴࡧࡤࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ႟"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧႠ"),block,re.DOTALL)
			for link,title,l11l111l_l1_ in items:
				if not link: continue
				# l11lll1l1_l1_ l11l1l1ll_l1_ by l11l1llll_l1_ .. it l1l111l1l_l1_ a l11ll11l1_l1_ from l11l1llll_l1_ l1l11ll1l_l1_
				if l11lll_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡴࡶࡤࡸ࡮ࡵ࡮ࠨႡ") in link: continue
				link = l111l_l1_(link)
				#title = l11l1lll1_l1_(title,link)
				link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪႢ")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫႣ")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩႤ"), l1111_l1_)
	l11ll111l_l1_ = str(l1111_l1_)
	l11l111_l1_ = [l11lll_l1_ (u"ࠬ࠴ࡺࡪࡲࡂࠫႥ"),l11lll_l1_ (u"࠭࠮ࡳࡣࡵࡃࠬႦ"),l11lll_l1_ (u"ࠧ࠯ࡶࡻࡸࡄ࠭Ⴇ"),l11lll_l1_ (u"ࠨ࠰ࡳࡨ࡫ࡅࠧႨ"),l11lll_l1_ (u"ࠩ࠱ࡸࡦࡸ࠿ࠨႩ"),l11lll_l1_ (u"ࠪ࠲࡮ࡹ࡯ࡀࠩႪ"),l11lll_l1_ (u"ࠫ࠳ࢀࡩࡱ࠰ࠪႫ"),l11lll_l1_ (u"ࠬ࠴ࡲࡢࡴ࠱ࠫႬ"),l11lll_l1_ (u"࠭࠮ࡵࡺࡷ࠲ࠬႭ"),l11lll_l1_ (u"ࠧ࠯ࡲࡧࡪ࠳࠭Ⴎ"),l11lll_l1_ (u"ࠨ࠰ࡷࡥࡷ࠴ࠧႯ"),l11lll_l1_ (u"ࠩ࠱࡭ࡸࡵ࠮ࠨႰ")]
	if any(value in l11ll111l_l1_ for value in l11l111_l1_):
		DIALOG_OK(l11lll_l1_ (u"ࠪࠫႱ"),l11lll_l1_ (u"ࠫࠬႲ"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨႳ"),l11lll_l1_ (u"࠭ฬาสࠣีฬฮืࠡ็ัฮ้็ࠠๅล้ࠤ์ึวࠡษ็ีฬฮืࠡๆํื๋ࠥๆ่๋ࠡ฽ࠥอไา๊สฬ฼ࠦวๅฬํࠤๆ๐็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰่ࠣศ์่ࠠาสࠤฬ๊ๅ้ไ฼ࠤๆ๐็ࠡะา้ฬะࠠฤะิํࠥเ๊า่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩႴ"))
		return
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭Ⴕ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪႶ"),l11lll_l1_ (u"ࠩ࠮ࠫႷ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳࡫࡯࡮ࡥ࠱ࡂࡪ࡮ࡴࡤ࠾ࠩႸ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫႹ"))
	return
def l1lll1l1_l1_(url,filter):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭Ⴚ"),l11lll_l1_ (u"࠭ࠧႻ"),filter,url)
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨႼ"):url,l11lll_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬႽ"):l11lll_l1_ (u"ࠩࠪႾ")}
	#l1l1ll1ll_l1_ = l11lll_l1_ (u"ࠪࠫႿ")
	#filter = filter.replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭Ⴠ"),l11lll_l1_ (u"ࠬ࠭Ⴡ"))
	if l11lll_l1_ (u"࠭࠿ࡀࠩჂ") in url: url = url.split(l11lll_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭Ⴣ"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠨࡡࡢࡣࠬჄ"),1)
	if filter==l11lll_l1_ (u"ࠩࠪჅ"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠪࠫ჆"),l11lll_l1_ (u"ࠫࠬჇ")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ჈"))
	if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ჉"):
		if l1l11lll1_l1_[0]+l11lll_l1_ (u"ࠧ࠾࠿ࠪ჊") not in l1l11l1l_l1_: category = l1l11lll1_l1_[0]
		for i in range(len(l1l11lll1_l1_[0:-1])):
			if l1l11lll1_l1_[i]+l11lll_l1_ (u"ࠨ࠿ࡀࠫ჋") in l1l11l1l_l1_: category = l1l11lll1_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠩࠩࠪࠬ჌")+category+l11lll_l1_ (u"ࠪࡁࡂ࠶ࠧჍ")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧ჎")+category+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩ჏")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"࠭ࠦࠧࠩა"))+l11lll_l1_ (u"ࠧࡠࡡࡢࠫბ")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠨࠨࠩࠫგ"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬდ"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩე")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬვ"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧზ"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"࠭ࠧთ"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪი"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠨࠩკ"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨლ")+l1l11l11_l1_
		l1111111_l1_ = l11llllll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪმ"),l111ll_l1_+l11lll_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧნ"),l1111111_l1_,251,l11lll_l1_ (u"ࠬ࠭ო"),l11lll_l1_ (u"࠭ࠧპ"),l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨჟ"))
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨრ"),l111ll_l1_+l11lll_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩს")+l11lll11_l1_+l11lll_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩტ"),l1111111_l1_,251,l11lll_l1_ (u"ࠫࠬუ"),l11lll_l1_ (u"ࠬ࠭ფ"),l11lll_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧქ"))
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬღ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨყ"),l11lll_l1_ (u"ࠩࠪშ"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠪࡔࡔ࡙ࡔࠨჩ"),url,l11lll_l1_ (u"ࠫࠬც"),headers,l11lll_l1_ (u"ࠬ࠭ძ"),l11lll_l1_ (u"࠭ࠧწ"),l11lll_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬჭ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡖࡤࡼࡕࡧࡧࡦࡈ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡔࡦࡴࡰࡆ࡙ࡔࡳࠣࠩხ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l11l111_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫჯ"),block,re.DOTALL)
	l1l111lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡖࡦࡺࡩ࡯ࡩࡉ࡭ࡱࡺࡥࡳࠤ࠱࠮ࡄࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠴ࠪࡀࠪ࠿ࡹࡱࡄࠩࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫჰ"),block,re.DOTALL)
	l1lll11l_l1_ = l1l11l111_l1_+l1l111lll_l1_
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		#if l11lll_l1_ (u"ࠫ࡮ࡴࡴࡦࡴࡨࡷࡹ࠭ჱ") in l1ll1lll_l1_: continue
		items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ჲ"),block,re.DOTALL)
		if name==l11lll_l1_ (u"࠭วฯำ์ࠫჳ"): name = l11lll_l1_ (u"ࠧศๆสๆุอๅࠨჴ")
		if not items:
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡲࡢࡶࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨჵ"),block,re.DOTALL)
			items = []
			for option,value in l1l1lll_l1_: items.append([option,l11lll_l1_ (u"ࠩࠪჶ"),value])
			l1ll1lll_l1_ = l11lll_l1_ (u"ࠪࡶࡦࡺࡥࠨჷ")
			name = l11lll_l1_ (u"ࠫฬ๊สใ์ํ้ࠬჸ")
		else: l1ll1lll_l1_ = items[0][1]
		if l11lll_l1_ (u"ࠬࡃ࠽ࠨჹ") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪჺ"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<=1:
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: l1111l_l1_(l11l11l_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ჻")+l1l1l11l_l1_)
				return
			else:
				l1111111_l1_ = l11llllll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll1_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨჼ"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪჽ"),l1111111_l1_,251,l11lll_l1_ (u"ࠪࠫჾ"),l11lll_l1_ (u"ࠫࠬჿ"),l11lll_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᄀ"))
				else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᄁ"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨᄂ"),l11l11l_l1_,254,l11lll_l1_ (u"ࠨࠩᄃ"),l11lll_l1_ (u"ࠩࠪᄄ"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᄅ"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧᄆ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽࠱ࠩᄇ")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩᄈ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿࠳ࠫᄉ")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬᄊ")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᄋ"),l111ll_l1_+l11lll_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬᄌ")+name,l11l11l_l1_,255,l11lll_l1_ (u"ࠫࠬᄍ"),l11lll_l1_ (u"ࠬ࠭ᄎ"),l1l1l11l_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᄏ"))
		dict[l1ll1lll_l1_] = {}
		for option,dummy,value in items:
			if option in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠧศๆๆ่ࠬᄐ") in option: continue
			option = unescapeHTML(option)
			#if l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᄑ") in option: continue
			#if l11lll_l1_ (u"ࠩࡱ࠱ࡦ࠭ᄒ") in value: continue
			l11ll1l11_l1_,l1lll1lll_l1_ = option,option
			l1lll1lll_l1_ = name+l11lll_l1_ (u"ࠪ࠾ࠥ࠭ᄓ")+l11ll1l11_l1_
			dict[l1ll1lll_l1_][value] = l1lll1lll_l1_
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧᄔ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠬࡃ࠽ࠨᄕ")+l11ll1l11_l1_
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"࠭ࠦࠧࠩᄖ")+l1ll1lll_l1_+l11lll_l1_ (u"ࠧ࠾࠿ࠪᄗ")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠨࡡࡢࡣࠬᄘ")+l1l1llll_l1_
			if type==l11lll_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪᄙ"):
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᄚ"),l111ll_l1_+l1lll1lll_l1_,url,255,l11lll_l1_ (u"ࠫࠬᄛ"),l11lll_l1_ (u"ࠬ࠭ᄜ"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᄝ"))
			elif type==l11lll_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫᄞ") and l1l11lll1_l1_[-2]+l11lll_l1_ (u"ࠨ࠿ࡀࠫᄟ") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬᄠ"))
				#DIALOG_OK(l11lll_l1_ (u"ࠪࠫᄡ"),l11lll_l1_ (u"ࠫࠬᄢ"),l1l1111l_l1_,l1l1llll_l1_)
				l11l1l1_l1_ = url+l11lll_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫᄣ")+l1l1111l_l1_
				l1111111_l1_ = l11llllll_l1_(l11l1l1_l1_)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᄤ"),l111ll_l1_+l1lll1lll_l1_,l1111111_l1_,251,l11lll_l1_ (u"ࠧࠨᄥ"),l11lll_l1_ (u"ࠨࠩᄦ"),l11lll_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪᄧ"))
			else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᄨ"),l111ll_l1_+l1lll1lll_l1_,url,254,l11lll_l1_ (u"ࠫࠬᄩ"),l11lll_l1_ (u"ࠬ࠭ᄪ"),l1ll1ll1_l1_)
	return
l1l11lll1_l1_ = [l11lll_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨᄫ"),l11lll_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᄬ"),l11lll_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧᄭ")]
l1l11l1l1_l1_ = [l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᄮ"),l11lll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᄯ"),l11lll_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪᄰ"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫᄱ"),l11lll_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨᄲ"),l11lll_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨᄳ"),l11lll_l1_ (u"ࠨࡴࡤࡸࡪ࠭ᄴ")]
def l11llllll_l1_(url):
	l11l1ll11_l1_ = l11lll_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠴࠳࠶࠶࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡈࡰ࡯ࡨ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡈࡰ࡯ࡨ࠲ࡵ࡮ࡰࠨᄵ")
	url = url.replace(l11lll_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧᄶ"),l11l1ll11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ศะิํࠬᄷ"),l11lll_l1_ (u"ࠬ࠭ᄸ"))
	if l11l1ll11_l1_ not in url: url = url+l11l1ll11_l1_
	url = url.replace(l11lll_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᄹ"),l11lll_l1_ (u"ࠧࡺࡧࡤࡶࠬᄺ"))
	url = url.replace(l11lll_l1_ (u"ࠨࡁࡂࠫᄻ"),l11lll_l1_ (u"ࠩࡂࠫᄼ"))
	url = url.replace(l11lll_l1_ (u"ࠪࠪࠫ࠭ᄽ"),l11lll_l1_ (u"ࠫࠫ࠭ᄾ"))
	url = url.replace(l11lll_l1_ (u"ࠬࡃ࠽ࠨᄿ"),l11lll_l1_ (u"࠭࠽ࠨᅀ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨᅁ"),l11lll_l1_ (u"ࠨࠩᅂ"),l11lll_l1_ (u"ࠩࠪᅃ"),l11lll_l1_ (u"ࠪࡔࡗࡋࡐࡂࡔࡈࡣࡋࡏࡌࡕࡇࡕࡣࡋࡏࡎࡂࡎࡢ࡙ࡗࡒࠧᅄ"))
	return url
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬᅅ"),l11lll_l1_ (u"ࠬ࠭ᅆ"),filters,l11lll_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭ᅇ")+mode)
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩᅈ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫᅉ")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠩࡤࡰࡱ࠭ᅊ")					all filters (l11lllll_l1_ l1l1ll1l_l1_ filter)
	filters = filters.strip(l11lll_l1_ (u"ࠪࠪࠫ࠭ᅋ"))
	l1l11ll1_l1_,l1ll1l1l_l1_ = {},l11lll_l1_ (u"ࠫࠬᅌ")
	if l11lll_l1_ (u"ࠬࡃ࠽ࠨᅍ") in filters:
		items = filters.split(l11lll_l1_ (u"࠭ࠦࠧࠩᅎ"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠧ࠾࠿ࠪᅏ"))
			l1l11ll1_l1_[var] = value
	for key in l1l11l1l1_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠨ࠲ࠪᅐ")
		if l11lll_l1_ (u"ࠩࠨࠫᅑ") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᅒ") and value!=l11lll_l1_ (u"ࠫ࠵࠭ᅓ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠦࠫࠡࠩᅔ")+value
		elif mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᅕ") and value!=l11lll_l1_ (u"ࠧ࠱ࠩᅖ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠨࠨࠩࠫᅗ")+key+l11lll_l1_ (u"ࠩࡀࡁࠬᅘ")+value
		elif mode==l11lll_l1_ (u"ࠪࡥࡱࡲࠧᅙ"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠫࠫࠬࠧᅚ")+key+l11lll_l1_ (u"ࠬࡃ࠽ࠨᅛ")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"࠭ࠠࠬࠢࠪᅜ"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠧࠨࠪᅝ"))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩᅞ"),l11lll_l1_ (u"ࠩࠪᅟ"),l1ll1l1l_l1_,l11lll_l1_ (u"ࠪࡓ࡚࡚ࠧᅠ"))
	return l1ll1l1l_l1_
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ㔯")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧ㔰")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
headers = {l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㔱"):l11lll_l1_ (u"ࠪࠫ㔲")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l1111l_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㔳"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ㔴"),l11lll_l1_ (u"࠭ࠧ㔵"),329,l11lll_l1_ (u"ࠧࠨ㔶"),l11lll_l1_ (u"ࠨࠩ㔷"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㔸"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㔹"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㔺"),l11lll_l1_ (u"ࠬ࠭㔻"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ㔼"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ㔽"),l11lll_l1_ (u"ࠨࠩ㔾"),headers,l11lll_l1_ (u"ࠩࠪ㔿"),l11lll_l1_ (u"ࠪࠫ㕀"),l11lll_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㕁"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰࡲ࠱ࡵࡲࡵࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㕂"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㕃"),block,re.DOTALL)
	for link,title in items:
		if title==l11lll_l1_ (u"ࠧศๆ่็ฯฮษࠡษ็้ึฬ๊สࠩ㕄"): continue
		link = l11ll1_l1_+link
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕅"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㕆")+l111ll_l1_+title,link,321)
	return html
def l1111l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ㕇"),l11lll_l1_ (u"ࠫࠬ㕈"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ㕉"),url,l11lll_l1_ (u"࠭ࠧ㕊"),headers,l11lll_l1_ (u"ࠧࠨ㕋"),l11lll_l1_ (u"ࠨࠩ㕌"),l11lll_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ㕍"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ㕎"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡰࡥ࠷ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㕏"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ㕐"),block,re.DOTALL)
	for link,l1llll_l1_,count,title in items:
		count = count.replace(l11lll_l1_ (u"ู࠭ะัࠣࠫ㕑"),l11lll_l1_ (u"ࠧࠨ㕒")).replace(l11lll_l1_ (u"ࠨࠢࠪ㕓"),l11lll_l1_ (u"ࠩࠪ㕔"))
		link = link.replace(l11lll_l1_ (u"ࠪ࠳ࠬ㕕"),l11lll_l1_ (u"ࠫࠬ㕖"))
		l1llll_l1_ = l1llll_l1_.replace(l11lll_l1_ (u"ࠧ࠭ࠢ㕗"),l11lll_l1_ (u"࠭ࠧ㕘"))
		if l11lll_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬ㕙") not in link: link = l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫ㕚")+link
		link = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࠫ㕛")+link
		l1llll_l1_ = l11ll1_l1_+l1llll_l1_
		title = title.strip(l11lll_l1_ (u"ࠪࠤࠬ㕜"))
		title = title+l11lll_l1_ (u"ࠫࠥ࠮ࠧ㕝")+count+l11lll_l1_ (u"ࠬ࠯ࠧ㕞")
		if l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㕟") in link: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕠"),l111ll_l1_+title,link,321,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫ㕡") in link: addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㕢"),l111ll_l1_+title,link,322,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫ㕣"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㕤"),block,re.DOTALL)
		for link,title in items:
			link = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩ㕥")+link
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㕦"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭㕧")+title,link,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ㕨"),url,l11lll_l1_ (u"ࠩࠪ㕩"),headers,l11lll_l1_ (u"ࠪࠫ㕪"),l11lll_l1_ (u"ࠫࠬ㕫"),l11lll_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㕬"))
	html = response.content
	#link = re.findall(l11lll_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㕭"),html,re.DOTALL)
	#if not link:
	link = re.findall(l11lll_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㕮"),html,re.DOTALL)
	link = l11ll1_l1_+link[0]#+l11lll_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ㕯")+l1l11l11l_l1_()+l11lll_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡵࡴࡸࡩࠬ㕰")
	PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㕱"))
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"๊ࠫิสศำࠪ㕲")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠬ࠭㕳"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"࠭ࠧ㕴"): return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ㕵"),l11lll_l1_ (u"ࠨ࠭ࠪ㕶"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪ㕷")+search
	l1111l_l1_(url)
	return
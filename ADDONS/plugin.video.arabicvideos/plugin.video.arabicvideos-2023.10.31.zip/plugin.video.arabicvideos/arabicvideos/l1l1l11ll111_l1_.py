# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ慴")
headers = l11lll_l1_ (u"ࠨࠩ慵") #{ l11lll_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭慶") : l11lll_l1_ (u"ࠪࠫ慷") }
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤ࡙ࡈ࠵ࡡࠪ慸")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ慹"),l11lll_l1_ (u"࠭วๅๅ็ࠫ慺"),l11lll_l1_ (u"ࠧศใ็ห๊࠭慻"),l11lll_l1_ (u"ࠨ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠬ慼"),l11lll_l1_ (u"ู่ࠩฬืูสࠢะีฮ࠭慽")]
# l1l1ll11_l1_	https://l1lll1l1ll111_l1_.l1llll111l1_l1_
# l1lllll11ll_l1_	https://www.l1lllll11ll_l1_.com/l1111l1lll11_l1_.net
# l1llll1l111_l1_	https://l1llll1l111_l1_.com/l1lll1l1l1lll_l1_
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l1111l_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1llllll_l1_(url,True)
	elif mode==114: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ慾")+text)
	elif mode==115: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ慿")+text)
	elif mode==116: results = l1llllll_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1ll1l1_l1_,url,response = l1ll11111l1_l1_(l11ll1_l1_,l11lll_l1_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ憀"),l11lll_l1_ (u"࠭ิศ้าࠤๆ๎ั๋๊ࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨࠥ࠺ࡵࠨ憁"),l11lll_l1_ (u"ࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧ憂"),headers)
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ憃"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ憄"),l11lll_l1_ (u"ࠪࠫ憅"),119,l11lll_l1_ (u"ࠫࠬ憆"),l11lll_l1_ (u"ࠬ࠭憇"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ憈"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ憉"),l111ll_l1_+l11lll_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ憊"),l1ll1l1_l1_,115)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ憋"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭憌"),l1ll1l1_l1_,114)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ憍"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ憎"),l11lll_l1_ (u"࠭ࠧ憏"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ憐"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็้๊๐าสࠩ憑"),l1ll1l1_l1_,111,l11lll_l1_ (u"ࠩࠪ憒"),l11lll_l1_ (u"ࠪࠫ憓"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭憔"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡹࡩ࡮ࡲ࡯ࡩ࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫࡤࡨࡻ࠳ࡦࡪ࡮ࡷࡩࡷ࠭憕"),html,re.DOTALL)
	if not l1l1ll1_l1_:
		DIALOG_OK(l11lll_l1_ (u"࠭ࠧ憖"),l11lll_l1_ (u"ࠧࠨ憗"),l11lll_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪ憘"),l11lll_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ์ฯหิูࠦ็๊ส๊ࠥอไๆ๊ๅ฽ࠥษ่ࠡฬุ้๏๋ࠠศๆ่์็฿ࠠห฼ํีࠬ憙"))
		return
	else:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠥࡃࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ憚"),block,re.DOTALL)
		for filter,l1llll_l1_,title in items:
			url = l1ll1l1_l1_+filter
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ憛"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ憜")+l111ll_l1_+title,url,111,l1llll_l1_,l11lll_l1_ (u"࠭ࠧ憝"),filter)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ憞"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ憟"),l11lll_l1_ (u"ࠩࠪ憠"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡷࡵࡰࡥࡱࡺࡲࠧ࠮࠮ࠫࡁࠬࡀࡸࡩࡲࡪࡲࡷࡂࠬ憡"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭憢"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l11lll_l1_ (u"ࠬࡢ࡮ࠨ憣"),l11lll_l1_ (u"࠭ࠧ憤")).replace(l11lll_l1_ (u"ࠧ࡝ࡴࠪ憥"),l11lll_l1_ (u"ࠨࠩ憦")).strip(l11lll_l1_ (u"ࠩࠣࠫ憧"))
			if title in l1l1l1_l1_: continue
			if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ憨") not in link: link = l1ll1l1_l1_+link
			if l11lll_l1_ (u"ࠫࡳ࡫ࡴࡧ࡮࡬ࡼࠬ憩") in link: title = l11lll_l1_ (u"ࠬ์๊หใ็็ุ࠭憪")
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭憫"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ憬")+l111ll_l1_+title,link,111)
	return html
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠨࠩ憭"),response=l11lll_l1_ (u"ࠩࠪ憮")):
	#l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭憯"):l11lll_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ憰")}
	if not response: response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ憱"),url,l11lll_l1_ (u"࠭ࠧ憲"),headers,l11lll_l1_ (u"ࠧࠨ憳"),l11lll_l1_ (u"ࠨࠩ憴"),l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ憵"))
	html = response.content
	l1l1ll1_l1_,items,l1l1_l1_ = [],[],[]
	if l1111l111_l1_==l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ憶"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࡬ࡲࡩࡥࡧࡢࡣࡸࡲࡩࡥࡧࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ憷"),html,re.DOTALL)
	#elif l1111l111_l1_==l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ憸"): l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡍࡦࡦ࡬ࡥࡌࡸࡩࡥࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ憹"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡪࡲࡻࡸ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠪ࠱࠮ࡄ࠯ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ憺"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	#if l1111l111_l1_==l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ憻"): items = re.findall(l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠰ࡦࡴࡾ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ憼"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠵ࡀࠪ憽"),block,re.DOTALL)
	l1lll1_l1_ = [l11lll_l1_ (u"ฺ๊ࠫว่ัฬࠫ憾"),l11lll_l1_ (u"ࠬ็๊ๅ็ࠪ憿"),l11lll_l1_ (u"࠭ว฻่ํอࠬ懀"),l11lll_l1_ (u"ࠧไๆํฬࠬ懁"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧ懂"),l11lll_l1_ (u"๊ࠩำฬ็ࠧ懃"),l11lll_l1_ (u"้ࠪออัศหࠪ懄"),l11lll_l1_ (u"ࠫ฾ืึࠨ懅"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬ懆"),l11lll_l1_ (u"࠭วๅส๋้ࠬ懇")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠧ࡫ࡣࡹࡥࡸࡩࡲࡪࡲࡷࠫ懈") in link: continue
		#if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ應") in link: continue
		#link = link.replace(l11lll_l1_ (u"ࠩࠩࠧ࠵࠹࠸࠼ࠩ懊"),l11lll_l1_ (u"ࠪࠪࠬ懋"))
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠫ࠴࠭懌"))
		title = unescapeHTML(title)
		title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ懍"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ懎"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠧโ์็้ࠬ懏") in link or any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ懐"),l111ll_l1_+title,link,112,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠩส่า๊โสࠩ懑") in title and l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ懒") not in url:
			title = l11lll_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ懓") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ懔"),l111ll_l1_+title,link,113,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"࠭࠯ࡢࡥࡷࡳࡷ࠵ࠧ懕") in link:
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ懖"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ懗") in link and l11lll_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ懘") not in url:
			link = link+l11lll_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ懙")
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ懚"),l111ll_l1_+title,link,111,l1llll_l1_)
		elif l11lll_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ懛") in url and l11lll_l1_ (u"࠭อๅไฬࠫ懜") in title:
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭懝"),l111ll_l1_+title,link,112,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ懞"),l111ll_l1_+title,link,113,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ懟"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		if l1111l111_l1_!=l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ懠"): items = re.findall(l11lll_l1_ (u"ࠫ࠭ࡻࡰࡥࡣࡷࡩࡖࡻࡥࡳࡻࠬ࠲࠯ࡅ࠾ࠩ࠰࠮ࡃ࠮ࡂࠧ懡"),block,re.DOTALL)
		else: items = re.findall(l11lll_l1_ (u"ࠬࡂ࡬ࡪࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ懢"),block,re.DOTALL)
		for link,title in items:
			if l1111l111_l1_!=l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭懣"):
				title = title.replace(l11lll_l1_ (u"ࠧ࡝ࡰࠪ懤"),l11lll_l1_ (u"ࠨࠩ懥")).replace(l11lll_l1_ (u"ࠩ࡟ࡶࠬ懦"),l11lll_l1_ (u"ࠪࠫ懧"))
				if l11lll_l1_ (u"ࠫࡄ࠭懨") in url: link = url+l11lll_l1_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ懩")+title
				else: link = url+l11lll_l1_ (u"࠭࠿ࡱࡣࡪࡩࡂ࠭懪")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ懫"),l111ll_l1_+l11lll_l1_ (u"ࠨืไัฮࠦࠧ懬")+title,link,111,l11lll_l1_ (u"ࠩࠪ懭"),l11lll_l1_ (u"ࠪࠫ懮"),l1111l111_l1_)
	return
def l1llllll_l1_(url,l1lll1l1l1ll1_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ懯"),url,l11lll_l1_ (u"ࠬ࠭懰"),headers,l11lll_l1_ (u"࠭ࠧ懱"),l11lll_l1_ (u"ࠧࠨ懲"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ懳"))
	html = response.content
	# l1lllll_l1_ & l1l1l_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠡࡦ࠰ࡪࡱ࡫ࡸࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ懴"),html,re.DOTALL)
	if len(l1l1ll1_l1_)>1:
		if l11lll_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ懵") in l1l1ll1_l1_[0]: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[1]
		else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[1],l1l1ll1_l1_[0]
	else: l1lllll_l1_,l1l1l_l1_ = l1l1ll1_l1_[0],l1l1ll1_l1_[0]
	for l11l1lllll_l1_ in range(2):
		if l1lll1l1l1ll1_l1_: mode,type,block = 116,l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ懶"),l1lllll_l1_
		else: mode,type,block = 112,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ懷"),l1l1l_l1_
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭懸"),block,re.DOTALL)
		if l1lll1l1l1ll1_l1_ and len(items)<2:
			l1lll1l1l1ll1_l1_ = False
			continue
		for link,l11ll1l11_l1_,l1lll1lll_l1_ in items:
			title = l11ll1l11_l1_+l11lll_l1_ (u"ࠧࠡࠩ懹")+l1lll1lll_l1_
			addMenuItem(type,l111ll_l1_+title,link,mode)
		break
	# l1l1l_l1_ l11l1ll1_l1_
	if not items and l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ懺") in html:
		l1llll1l1l_l1_ = re.findall(l11lll_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡥࡶࡪࡧࡤࡤࡴࡸࡱࡧࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ懻"),html,re.DOTALL)
		if l1llll1l1l_l1_:
			block = l1llll1l1l_l1_[0]
			links = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ懼"),block,re.DOTALL)
			if len(links)>2:
				link = links[2]+l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ懽")
				l1111l_l1_(link)
	return
def PLAY(url):
	l1111_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ懾"),url,l11lll_l1_ (u"࠭ࠧ懿"),headers,l11lll_l1_ (u"ࠧࠨ戀"),l11lll_l1_ (u"ࠨࠩ戁"),l11lll_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭戂"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡨࡺࡩࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ戃"),html,re.DOTALL)
	if not l1l1ll1_l1_: return
	block = l1l1ll1_l1_[0]
	links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ戄"),block,re.DOTALL)
	l11ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭戅") in block
	download = l11lll_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ戆") in block
	if   l11ll1l1l_l1_ and not download: l1lll1l1ll11l_l1_,l11l11l1l11l_l1_ = links[0],l11lll_l1_ (u"ࠧࠨ戇")
	elif not l11ll1l1l_l1_ and download: l1lll1l1ll11l_l1_,l11l11l1l11l_l1_ = l11lll_l1_ (u"ࠨࠩ戈"),links[0]
	elif l11ll1l1l_l1_ and download: l1lll1l1ll11l_l1_,l11l11l1l11l_l1_ = links[0],links[1]
	else: l1lll1l1ll11l_l1_,l11l11l1l11l_l1_ = l11lll_l1_ (u"ࠩࠪ戉"),l11lll_l1_ (u"ࠪࠫ戊")
	# l11ll1l1l_l1_
	if l11ll1l1l_l1_:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ戋"),l1lll1l1ll11l_l1_,l11lll_l1_ (u"ࠬ࠭戌"),headers,l11lll_l1_ (u"࠭ࠧ戍"),l11lll_l1_ (u"ࠧࠨ戎"),l11lll_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ戏"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡯ࡩࡹࠦࡳࡦࡴࡹࡩࡷࡹࠨ࠯ࠬࡂ࠭ࡵࡲࡡࡺࡧࡵࠫ成"),l11lll1l_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭我"),l11l1_l1_,re.DOTALL)
			for title,link in l1l1lll_l1_:
				link = link.replace(l11lll_l1_ (u"ࠫࡡࡢ࠯ࠨ戒"),l11lll_l1_ (u"ࠬ࠵ࠧ戓"))
				link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ戔")+title+l11lll_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ戕")
				l1111_l1_.append(link)
	# download
	if download:
		response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ或"),l11l11l1l11l_l1_,l11lll_l1_ (u"ࠩࠪ戗"),headers,l11lll_l1_ (u"ࠪࠫ战"),l11lll_l1_ (u"ࠫࠬ戙"),l11lll_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ戚"))
		l11lll1l_l1_ = response.content
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯ࡩ࡯ࡨࡲ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠧ戛"),l11lll1l_l1_,re.DOTALL)
		if l1l11ll_l1_:
			l11l1_l1_ = l1l11ll_l1_[0]
			l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࠳࡮ࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ戜"),l11l1_l1_,re.DOTALL)
			for link,title,l11l111l_l1_ in l1l1lll_l1_:
				link = link+l11lll_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ戝")+title+l11lll_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭戞")+l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ戟")+l11l111l_l1_
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ戠"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ戡"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ戢"),l11lll_l1_ (u"ࠧࠬࠩ戣"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ戤")+search
	l1ll1l1_l1_,l11l11l_l1_,l1ll111ll_l1_ = l1ll11111l1_l1_(url,l11lll_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ戥"),l11lll_l1_ (u"ุࠪฬํฯࠡใ๋ี๏๎ࠠ࠮ࠢࡖ࡬ࡦ࡮ࡩࡥࠢ࠷ࡹࠬ戦"),l11lll_l1_ (u"ࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ戧"),headers)
	l1111l_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ戨"),l1ll111ll_l1_)
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ戩"))[0]
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ截"),url,l11lll_l1_ (u"ࠨࠩ戫"),headers,l11lll_l1_ (u"ࠩࠪ戬"),l11lll_l1_ (u"ࠪࠫ戭"),l11lll_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡇࡆࡖࡢࡊࡎࡒࡔࡆࡔࡖࡣࡇࡒࡏࡄࡍࡖ࠱࠶ࡹࡴࠨ戮"))
	html = response.content
	l1lll11l_l1_ = []
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡧࡤࡷ࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡩࡱࡺࡷ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠨ戯"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		# name & category & options block
		l1lll11l_l1_ = re.findall(l11lll_l1_ (u"࠭ࡵࡱࡦࡤࡸࡪࡗࡵࡦࡴࡼࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࠫ戰"),block,re.DOTALL)
		l1lll1l111_l1_,names,l111l11_l1_ = zip(*l1lll11l_l1_)
		l1lll11l_l1_ = zip(names,l1lll1l111_l1_,l111l11_l1_)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# id & title
	items = re.findall(l11lll_l1_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࡠࡸ࠰ࠨ࠯ࠬࡂ࠭ࡡࡹࠪ࠽ࠩ戱"),block,re.DOTALL)
	return items
def l1lll11l1l_l1_(url):
	#url = url.replace(l11lll_l1_ (u"ࠨࡥࡤࡸࡂ࠭戲"),l11lll_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ戳"))
	if l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ戴") not in url: url = url+l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ戵")
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ戶"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ户"))
	url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	#url = url.replace(l11lll_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ戸"),l11lll_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬ戹"))
	url = url.replace(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭戺"),l11lll_l1_ (u"ࠪ࠳ࡄ࠭戻"))
	return url
l1lll11lll_l1_ = [l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ戼"),l11lll_l1_ (u"ࠬࡿࡥࡢࡴࠪ戽"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ戾"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ房")]
l1lll1ll11_l1_ = [l11lll_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ所"),l11lll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ扁"),l11lll_l1_ (u"ࠪࡽࡪࡧࡲࠨ扂")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭扃"),l11lll_l1_ (u"ࠬ࠭扄"))
	url = url.split(l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ扅"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠧࡠࡡࡢࠫ扆"),1)
	if filter==l11lll_l1_ (u"ࠨࠩ扇"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠩࠪ扈"),l11lll_l1_ (u"ࠪࠫ扉")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"ࠫࡤࡥ࡟ࠨ扊"))
	if type==l11lll_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭手"):
		if l1lll1ll11_l1_[0]+l11lll_l1_ (u"࠭࠽ࠨ扌") not in l1l11l1l_l1_: category = l1lll1ll11_l1_[0]
		for i in range(len(l1lll1ll11_l1_[0:-1])):
			if l1lll1ll11_l1_[i]+l11lll_l1_ (u"ࠧ࠾ࠩ才") in l1l11l1l_l1_: category = l1lll1ll11_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ扎")+category+l11lll_l1_ (u"ࠩࡀ࠴ࠬ扏")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ扐")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ扑")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ扒"))+l11lll_l1_ (u"࠭࡟ࡠࡡࠪ打")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ扔"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ払"))
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭扖")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ扗"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭托"))
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠬ࠭扙"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ扚"))
		if l1l11l11_l1_==l11lll_l1_ (u"ࠧࠨ扛"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ扜")+l1l11l11_l1_
		l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ扝"),l111ll_l1_+l11lll_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭扞"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ扟"),l111ll_l1_+l11lll_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬ扠")+l11lll11_l1_+l11lll_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬ扡"),l11l1l1_l1_,111)
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ扢"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ扣"),l11lll_l1_ (u"ࠩࠪ扤"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,l1ll1lll_l1_,block in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠪ็้ࠦࠧ扥"),l11lll_l1_ (u"ࠫࠬ扦"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠬࡃࠧ执") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ扨"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					l1111l_l1_(l11l1l1_l1_)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ扩")+l1l1l11l_l1_)
				return
			else:
				if l1ll1lll_l1_==l1lll1ll11_l1_[-1]:
					l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
					addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ扪"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ扫"),l11l1l1_l1_,111)
				else: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ扬"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ扭"),l11l11l_l1_,115,l11lll_l1_ (u"ࠬ࠭扮"),l11lll_l1_ (u"࠭ࠧ扯"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ扰"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠨࠨࠪ扱")+l1ll1lll_l1_+l11lll_l1_ (u"ࠩࡀ࠴ࠬ扲")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠪࠪࠬ扳")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠶ࠧ扴")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠬࡥ࡟ࡠࠩ扵")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭扶"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩ扷")+name,l11l11l_l1_,114,l11lll_l1_ (u"ࠨࠩ扸"),l11lll_l1_ (u"ࠩࠪ批"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ扺"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫ扻"): option = l11lll_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬ扼")
			elif value==l11lll_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭扽"): option = l11lll_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩ找")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ承") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ技"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ抁")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠭抂")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧ抃")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽ࠨ抄")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫ抅")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠨࠢ࠽ࠫ抆")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠩ࠳ࠫ抇")]
			title = option+l11lll_l1_ (u"ࠪࠤ࠿࠭抈")+name
			if type==l11lll_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ抉"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ把"),l111ll_l1_+title,url,114,l11lll_l1_ (u"࠭ࠧ抋"),l11lll_l1_ (u"ࠧࠨ抌"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ抍"))
			elif type==l11lll_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ抎") and l1lll1ll11_l1_[-2]+l11lll_l1_ (u"ࠪࡁࠬ抏") in l1l11l1l_l1_:
				l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ抐"))
				l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ抑")+l1l1111l_l1_
				l11l1l1_l1_ = l1lll11l1l_l1_(l11l11l_l1_)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭抒"),l111ll_l1_+title,l11l1l1_l1_,111)
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ抓"),l111ll_l1_+title,url,115,l11lll_l1_ (u"ࠨࠩ抔"),l11lll_l1_ (u"ࠩࠪ投"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	# mode==l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ抖")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ抗")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠬࡧ࡬࡭ࠩ折")					all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"࠭࠽ࠧࠩ抙"),l11lll_l1_ (u"ࠧ࠾࠲ࠩࠫ抚"))
	filters = filters.strip(l11lll_l1_ (u"ࠨࠨࠪ抛"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠩࡀࠫ抜") in filters:
		items = filters.split(l11lll_l1_ (u"ࠪࠪࠬ抝"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠫࡂ࠭択"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠬ࠭抟")
	for key in l1lll11lll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"࠭࠰ࠨ抠")
		if l11lll_l1_ (u"ࠧࠦࠩ抡") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ抢") and value!=l11lll_l1_ (u"ࠩ࠳ࠫ抣"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠪࠤ࠰ࠦࠧ护")+value
		elif mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ报") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ抦"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠦࠨ抧")+key+l11lll_l1_ (u"ࠧ࠾ࠩ抨")+value
		elif mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࠬ抩"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ抪")+key+l11lll_l1_ (u"ࠪࡁࠬ披")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠫࠥ࠱ࠠࠨ抬"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠬࠬࠧ抭"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"࠭࠽࠱ࠩ抮"),l11lll_l1_ (u"ࠧ࠾ࠩ抯"))
	return l1ll1l1l_l1_
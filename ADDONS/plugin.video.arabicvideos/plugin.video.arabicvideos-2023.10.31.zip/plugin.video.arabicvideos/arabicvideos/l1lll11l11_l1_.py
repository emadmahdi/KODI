# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨᤧ")
l111ll_l1_ = l11lll_l1_ (u"ࠧࡠࡅࡆࡆࡤ࠭ᤨ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪᤩ"),l11lll_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪᤪ"),l11lll_l1_ (u"ࠪฮุา๊ๅࠩᤫ"),l11lll_l1_ (u"ࠫ฾ื่ืู่ࠢฬืูสࠩ᤬")]
headers = {l11lll_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭᤭"):l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡦࡤࡦࡥࡨ࡮ࡥ࠯ࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮ࠩ᤮")}
def MAIN(mode,url,text):
	if   mode==630: results = MENU()
	elif mode==631: results = l1111l_l1_(url,text)
	elif mode==632: results = PLAY(url)
	elif mode==633: results = l11111_l1_(url,text)
	elif mode==634: results = l1l11l_l1_(url)
	elif mode==639: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ᤯"),l11ll1_l1_,l11lll_l1_ (u"ࠨࠩᤰ"),headers,l11lll_l1_ (u"ࠩࠪᤱ"),l11lll_l1_ (u"ࠪࠫᤲ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᤳ"))
	html = response.content
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᤴ"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᤵ"),l11lll_l1_ (u"ࠧࠨᤶ"),639,l11lll_l1_ (u"ࠨࠩᤷ"),l11lll_l1_ (u"ࠩࠪᤸ"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥ᤹ࠧ"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᤺"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡ᤻ࠬ"),l11lll_l1_ (u"࠭ࠧ᤼"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᤽"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᤾")+l111ll_l1_+l11lll_l1_ (u"ࠩส่๊๋๊ำหࠪ᤿"),l11ll1_l1_,631,l11lll_l1_ (u"ࠪࠫ᥀"),l11lll_l1_ (u"ࠫࠬ᥁"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ᥂"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᥃"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᥄")+l111ll_l1_+l11lll_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧ᥅"),l11ll1_l1_,631,l11lll_l1_ (u"ࠩࠪ᥆"),l11lll_l1_ (u"ࠪࠫ᥇"),l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ᥈"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᥉"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᥊")+l111ll_l1_+l11lll_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭᥋"),l11ll1_l1_,631,l11lll_l1_ (u"ࠨࠩ᥌"),l11lll_l1_ (u"ࠩࠪ᥍"),l11lll_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ᥎"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᥏"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᥐ")+l111ll_l1_+l11lll_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪᥑ"),l11ll1_l1_,631,l11lll_l1_ (u"ࠧࠨᥒ"),l11lll_l1_ (u"ࠨࠩᥓ"),l11lll_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᥔ"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᥕ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᥖ"),l11lll_l1_ (u"ࠬ࠭ᥗ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᥘ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᥙ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		if title==l11lll_l1_ (u"ࠨละำะࠦวๅฯ็ๆฬะࠧᥚ"): mode,request = 631,l11lll_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᥛ")
		else: mode,request = 634,l11lll_l1_ (u"ࠪࠫᥜ")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᥝ"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᥞ")+l111ll_l1_+title,link,mode,l11lll_l1_ (u"࠭ࠧᥟ"),l11lll_l1_ (u"ࠧࠨᥠ"),request)
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᥡ"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᥢ"),l11lll_l1_ (u"ࠪࠫᥣ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨᥤ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥᥥ"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_: block = block.replace(l11l1_l1_,l11lll_l1_ (u"࠭ࠧᥦ"))
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᥧ"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᥨ"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᥩ")+l111ll_l1_+title,link,634)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧᥪ"),url,l11lll_l1_ (u"ࠫࠬᥫ"),l11lll_l1_ (u"ࠬ࠭ᥬ"),l11lll_l1_ (u"࠭ࠧᥭ"),l11lll_l1_ (u"ࠧࠨ᥮"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ᥯"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᥰ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		block = block.replace(l11lll_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫᥱ"),l11lll_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪᥲ"))
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᥳ"),block,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = [(l11lll_l1_ (u"࠭ࠧᥴ"),block)]
		addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᥵"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᥶"),l11lll_l1_ (u"ࠩࠪ᥷"),9999)
		for l11l11_l1_,block in l1l1ll1_l1_:
			items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᥸"),block,re.DOTALL)
			if l11l11_l1_: l11l11_l1_ = l11l11_l1_+l11lll_l1_ (u"ࠫ࠿ࠦࠧ᥹")
			for link,title in items:
				title = l11l11_l1_+title
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᥺"),l111ll_l1_+title,link,631)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᥻"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᥼"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᥽"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᥾"),l11lll_l1_ (u"ࠪࠫ᥿"),9999)
			for link,title in items:
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦀ"),l111ll_l1_+title,link,631)
	l11lll_l1_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠳ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡳࡱ࠲ࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡨࡦࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠳࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠶࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤࡱ࡫࡮ࠩ࡫ࡷࡩࡲࡹࠩ࠽࠵࠳࠾ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧ࡭࡫ࡱ࡯ࠬ࠲ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠭ࠩࠪ࠰࠾࠿࠹࠺ࠫࠍࠍࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡲࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠻࠹࠱ࠪࠌࠌ࡭࡫ࠦ࡮ࡰࡶࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠲ࠢࡤࡲࡩࠦ࡮ࡰࡶࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠳ࠢࡤࡲࡩࠦ࡮ࡰࡶࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠴࠼ࠣࡘࡎ࡚ࡌࡆࡕࠫࡹࡷࡲࠩࠋࠋࠥࠦࠧᦁ")
	if not l1l1l11_l1_ and not l1l11ll_l1_: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"࠭ࠧᦂ")):
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨᦃ"),l11lll_l1_ (u"ࠨࠩᦄ"),request,url)
	if request==l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᦅ"):
		url,search = url.split(l11lll_l1_ (u"ࠪࡃࠬᦆ"),1)
		data = l11lll_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪᦇ")+search
		headers = {l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᦈ"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᦉ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬᦊ"),url,data,headers,l11lll_l1_ (u"ࠨࠩᦋ"),l11lll_l1_ (u"ࠩࠪᦌ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩᦍ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᦎ"),url,l11lll_l1_ (u"ࠬ࠭ᦏ"),l11lll_l1_ (u"࠭ࠧᦐ"),l11lll_l1_ (u"ࠧࠨᦑ"),l11lll_l1_ (u"ࠨࠩᦒ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨᦓ"))
	html = response.content
	block,items = l11lll_l1_ (u"ࠪࠫᦔ"),[]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨᦕ"))
	if request==l11lll_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᦖ"):
		block = html
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᦗ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((link,title,l11lll_l1_ (u"ࠧࠨᦘ")))
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᦙ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࡠࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᦚ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠪࠫࠬࠨࡰࡰࡵࡷࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮࠭ࠧࠨᦛ"),block,re.DOTALL)
	elif request==l11lll_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᦜ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᦝ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪᦞ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᦟ"),html,re.DOTALL)
		if len(l1l1ll1_l1_)>1: block = l1l1ll1_l1_[1]
	elif request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᦠ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫᦡ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᦢ"),block,re.DOTALL)
		for link,title in l1l1lll_l1_: items.append((link,title,l11lll_l1_ (u"ࠫࠬᦣ")))
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᦤ"),html,re.DOTALL)
		if l1l1ll1_l1_: block = l1l1ll1_l1_[0]
	if block and not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᦥ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠧๆึส๋ิฯࠧᦦ"),l11lll_l1_ (u"ࠨใํ่๊࠭ᦧ"),l11lll_l1_ (u"ࠩส฾๋๐ษࠨᦨ"),l11lll_l1_ (u"ࠪ็้๐ศࠨᦩ"),l11lll_l1_ (u"ࠫฬ฿ไศ่ࠪᦪ"),l11lll_l1_ (u"ࠬํฯศใࠪᦫ"),l11lll_l1_ (u"࠭ๅษษิหฮ࠭᦬"),l11lll_l1_ (u"ฺࠧำูࠫ᦭"),l11lll_l1_ (u"ࠨ็๊ีัอๆࠨ᦮"),l11lll_l1_ (u"ࠩส่อ๎ๅࠨ᦯"),l11lll_l1_ (u"ุ้ࠪือ๋หࠪᦰ")]
	for link,title,l1llll_l1_ in items:
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬᦱ"),link)
		#link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠬ࠵ࠧᦲ"))
		#if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫᦳ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩᦴ")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪᦵ"))
		#if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᦶ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᦷ")+l1llll_l1_.strip(l11lll_l1_ (u"ࠫ࠴࠭ᦸ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠬࠦࠧᦹ"))
		title = title.replace(l11lll_l1_ (u"࠭ࠠิ์่ห้ࠥไ้สࠪᦺ"),l11lll_l1_ (u"ࠧࠨᦻ"))
		title = title.replace(l11lll_l1_ (u"ࠨࠢส์๋ࠦไศ์้ࠫᦼ"),l11lll_l1_ (u"ࠩࠪᦽ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭ᦾ"),title,re.DOTALL)
		if l11lll_l1_ (u"ࠫ࡜࡝ࡅࠨᦿ") in title: continue
		elif any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᧀ"),l111ll_l1_+title,link,632,l1llll_l1_)
		elif request==l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᧁ"):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᧂ"),l111ll_l1_+title,link,632,l1llll_l1_)
		elif l1lll11_l1_:
			title = l11lll_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧᧃ") + l1lll11_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᧄ"),l111ll_l1_+title,link,633,l1llll_l1_)
				l1l1_l1_.append(title)
		#elif l11lll_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨᧅ") in link:
		#	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᧆ"),l111ll_l1_+title,link,631,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᧇ"),l111ll_l1_+title,link,633,l1llll_l1_)
	if 1: #if request not in [l11lll_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᧈ"),l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩᧉ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧊"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᧋"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠪࠧࠬ᧌"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴࠭᧍")+link.strip(l11lll_l1_ (u"ࠬ࠵ࠧ᧎"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᧏"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭᧐")+title,link,631)
	return
def l11111_l1_(url,l1ll1_l1_):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ᧑"),l11lll_l1_ (u"ࠩࠪ᧒"),l1ll1_l1_,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ᧓"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ᧔"),url,l11lll_l1_ (u"ࠬ࠭᧕"),l11lll_l1_ (u"࠭ࠧ᧖"),l11lll_l1_ (u"ࠧࠨ᧗"),l11lll_l1_ (u"ࠨࠩ᧘"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ᧙"))
	html = response.content
	l11l_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᧚"),html,re.DOTALL)
	if l11l_l1_: l1llll_l1_ = l11l_l1_[0]
	else: l1llll_l1_ = l11lll_l1_ (u"ࠫࠬ᧛")
	items = []
	# l1lllll_l1_
	l11ll_l1_ = False
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ᧜"),html,re.DOTALL)
	if l1l1l11_l1_ and not l1ll1_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࠧࠨࡱࡱࡧࡱ࡯ࡣ࡬࠿ࠥࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸ࠱࠴ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫࠬ࠭᧝"),block,re.DOTALL)
		for l1ll1_l1_,title in items:
			l1ll1_l1_ = l1ll1_l1_.strip(l11lll_l1_ (u"ࠧࠤࠩ᧞"))
			if len(items)>1: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧟"),l111ll_l1_+title,url,633,l1llll_l1_,l11lll_l1_ (u"ࠩࠪ᧠"),l1ll1_l1_)
			else: l11ll_l1_ = True
	else: l11ll_l1_ = True
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ᧡")+l1ll1_l1_+l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧢"),html,re.DOTALL)
	if l1l11ll_l1_ and l11ll_l1_:
		block = l1l11ll_l1_[0]
		l1l1lll_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᧣"),block,re.DOTALL)
		items = []
		for link,title in l1l1lll_l1_: items.append((link,title,l1llll_l1_))
		if not items: items = re.findall(l11lll_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᧤"),block,re.DOTALL)
		for link,title,l1llll_l1_ in items:
			#link = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࠩ᧥")+link.strip(l11lll_l1_ (u"ࠨ࠱ࠪ᧦"))
			link = link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ᧧"))
			title = title.replace(l11lll_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨ᧨"),l11lll_l1_ (u"ࠫࠥ࠭᧩"))
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᧪"),l111ll_l1_+title,link,632,l1llll_l1_)
		#else:
		#	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ᧫"),block,re.DOTALL)
		#	for link,title,l1llll_l1_ in items:
		#		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬ᧬") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪ᧭")+link.strip(l11lll_l1_ (u"ࠩ࠲ࠫ᧮"))
		#		addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᧯"),l111ll_l1_+title,link,632,l1llll_l1_)
	return
def PLAY(url):
	l1111_l1_,l1l1l11ll_l1_,l1lllll1_l1_ = [],[],[]
	# l11ll1l1l_l1_ links
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠲ࡵ࡮ࡰࠨ᧰"),l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼ࠲ࡵ࡮ࡰࠨ᧱"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ᧲"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ᧳"),l11lll_l1_ (u"ࠨࠩ᧴"),l11lll_l1_ (u"ࠩࠪ᧵"),l11lll_l1_ (u"ࠪࠫ᧶"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ᧷"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭᧸"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠨࡳࡳࡥࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠣ᧹"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᧺")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ᧻"))
				l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭᧼"),l11lll_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠮ࡱࡪࡳࠫ᧽"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ᧾"),l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭᧿"),l11lll_l1_ (u"࠭ࠧᨀ"),l11lll_l1_ (u"ࠧࠨᨁ"),l11lll_l1_ (u"ࠨࠩᨂ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ᨃ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᨄ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		links = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧᨅ"),block,re.DOTALL)
		for link,title in links:
			if link not in l1111_l1_:
				l1l1l11ll_l1_.append(l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᨆ")+title+l11lll_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᨇ"))
				l1111_l1_.append(link)
	l111l1_l1_ = zip(l1111_l1_,l1l1l11ll_l1_)
	for link,name in l111l1_l1_: l1lllll1_l1_.append(link+name)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬᨈ"),l1lllll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lllll1_l1_,script_name,l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᨉ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠩࠪᨊ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠪࠫᨋ"): return
	search = search.replace(l11lll_l1_ (u"ࠫࠥ࠭ᨌ"),l11lll_l1_ (u"ࠬ࠱ࠧᨍ"))
	url = l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧᨎ")+search
	l1111l_l1_(url,l11lll_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧᨏ"))
	#url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࠬᨐ")+search
	#l1111l_l1_(url,l11lll_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᨑ"))
	return
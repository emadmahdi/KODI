# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬᨒ")
l111ll_l1_ = l11lll_l1_ (u"ࠫࡤࡉࡍࡄࡡࠪᨓ")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"๋่ࠬใ฻๊ࠣฯ็ไ๋ๅึࠫᨔ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l1111l_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l1llllll_l1_(url)
	elif mode==494: results = l1l11l_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᨕ"),l11ll1_l1_,l11lll_l1_ (u"ࠧࠨᨖ"),l11lll_l1_ (u"ࠨࠩᨗ"),l11lll_l1_ (u"ᨘࠩࠪ"),l11lll_l1_ (u"ࠪࠫᨙ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᨚ"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᨛ"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"࠭࠯ࠨ᨜"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ᨝"))
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᨞"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ᨟"),l1ll1l1_l1_,499,l11lll_l1_ (u"ࠪࠫᨠ"),l11lll_l1_ (u"ࠫࠬᨡ"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᨢ"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨣ"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᨤ")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧᨥ"),l1ll1l1_l1_,491,l11lll_l1_ (u"ࠩࠪᨦ"),l11lll_l1_ (u"ࠪࠫᨧ"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᨨ"))
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨩ"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᨪ"),l11lll_l1_ (u"ࠧࠨᨫ"),9999)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠢࡄ࡮ࡦࡾࡩࡧࡻࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᨬ"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡧ࡫࡯ࡸࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᨭ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡱ࡯ࡨ࠴࡬ࡩ࡭ࡶࡨࡶ࠴࠭ᨮ")+link+l11lll_l1_ (u"ࠫ࠳ࡶࡨࡱࠩᨯ")
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᨰ"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᨱ")+l111ll_l1_+title,link,491)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨲ"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᨳ"),l11lll_l1_ (u"ࠩࠪᨴ"),9999)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨵ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᨶ")+l111ll_l1_+l11lll_l1_ (u"ࠬษแๅษ่ࠫᨷ"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱สๅ้อๅ࠮࡯ࡲࡺ࡮࡫ࡳ࠮ࡨ࡬ࡰࡲ࡫࠯ࡧࡱࡵࡩ࡮࡭࡮࠮ࡪࡧ࠱ฬ็ไศ็࠰หั์ศ๊࠯࠵ࠫᨸ"),494,l11lll_l1_ (u"ࠧࠨᨹ"),l11lll_l1_ (u"ࠨࠩᨺ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᨻ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨼ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᨽ")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯ࠭ᨾ"),l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱่ืู้ไศฬ࠲ุ้๊ำๅษอ࠱ฬาๆษ๋ࠪᨿ"),494,l11lll_l1_ (u"ࠧࠨᩀ"),l11lll_l1_ (u"ࠨࠩᩁ"),l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᩂ"))
	addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩃ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᩄ"),l11lll_l1_ (u"ࠬ࠭ᩅ"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᩆ"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᩇ"),block,re.DOTALL)
	for link,title in items:
		if link==l11lll_l1_ (u"ࠨ࠱ࠪᩈ"): continue
		if l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᩉ") not in link: link = l1ll1l1_l1_+link
		if title in l1l1l1_l1_: continue
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᩊ"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᩋ")+l111ll_l1_+title,link,491)
	return html
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭ᩌ"),l11lll_l1_ (u"࠭ࠧᩍ"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫᩎ"),url,l11lll_l1_ (u"ࠨࠩᩏ"),l11lll_l1_ (u"ࠩࠪᩐ"),l11lll_l1_ (u"ࠪࠫᩑ"),l11lll_l1_ (u"ࠫࠬᩒ"),l11lll_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᩓ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡧ࡫࡯ࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᩔ"),html,re.DOTALL)
	if l1l1l11_l1_:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᩕ"),block,re.DOTALL)
		for link,title in items:
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᩖ"),l111ll_l1_+title,link,491)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠩࠪᩗ")):
	items = []
	#l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧᩘ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡌࡋࡔࠨᩙ"),url,l11lll_l1_ (u"ࠬ࠭ᩚ"),l11lll_l1_ (u"࠭ࠧᩛ"),l11lll_l1_ (u"ࠧࠨᩜ"),l11lll_l1_ (u"ࠨࠩᩝ"),l11lll_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨᩞ"))
	html = response.content
	block = l11lll_l1_ (u"ࠪࠫ᩟")
	if l11lll_l1_ (u"ࠫ࠳ࡶࡨࡱ᩠ࠩ") in url: block = html
	elif l11lll_l1_ (u"ࠬࡅࡳ࠾ࠩᩡ") in url:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࠧࡳࡡ࡯࡫ࡩࡩࡸࡺࠢࠨᩢ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᩣ"),block,re.DOTALL)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࠢ࡮ࡣࡱ࡭࡫࡫ࡳࡵࠤࠪᩤ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
	if not block: return
	#if not items: items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࡞࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࠧࡨ࡯ࡹࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᩥ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪᩦ"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩᩧ"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫᩨ"),l11lll_l1_ (u"࠭ร฻่ํอࠬᩩ"),l11lll_l1_ (u"ࠧไๆํฬࠬᩪ"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧᩫ"),l11lll_l1_ (u"๊ࠩำฬ็ࠧᩬ"),l11lll_l1_ (u"้ࠪออัศหࠪᩭ"),l11lll_l1_ (u"ࠫ฾ืึࠨᩮ"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬᩯ"),l11lll_l1_ (u"࠭วๅส๋้ࠬᩰ"),l11lll_l1_ (u"ࠧๆีิั๏ฯࠧᩱ")]
	for link,l1llll_l1_,title in items:
		title = unescapeHTML(title)
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠฮๆๅอࠥࡢࡤࠬࠩᩲ"),title,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬᩳ"),title,re.DOTALL)
		if not l1lll11_l1_ or any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᩴ"),l111ll_l1_+title,link,492,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠫา๊โสࠩ᩵") in title:
			title = l11lll_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ᩶") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᩷"),l111ll_l1_+title,link,493,l1llll_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᩸"),l111ll_l1_+title,link,493,l1llll_l1_)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᩹"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ᩺"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11lll_l1_ (u"ࠪห้฻แฮหࠣࠫ᩻"),l11lll_l1_ (u"ࠫࠬ᩼"))
			if title!=l11lll_l1_ (u"ࠬ࠭᩽"): addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᩾"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอ᩿ࠥ࠭")+title,link,491)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ᪀"),url,l11lll_l1_ (u"ࠩࠪ᪁"),l11lll_l1_ (u"ࠪࠫ᪂"),l11lll_l1_ (u"ࠫࠬ᪃"),l11lll_l1_ (u"ࠬ࠭᪄"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ᪅"))
	html = response.content
	l11l11l_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡄࡸࡸࡹࡵ࡮ࡴࡄࡤࡶࡈࡵࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᪆"),html,re.DOTALL)
	if l11l11l_l1_:
		l11l11l_l1_ = l11l11l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ᪇"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪ᪈"),l11lll_l1_ (u"ࠪࠫ᪉"),l11lll_l1_ (u"ࠫࠬ᪊"),l11lll_l1_ (u"ࠬ࠭᪋"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ᪌"))
		html = response.content
	l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣ࡫ࡰ࡫࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᪍"),html,re.DOTALL)
	if l1llll_l1_: l1llll_l1_ = l1llll_l1_[0]
	else: l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ᪎"))
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡪ࡮ࡲࡴࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ᪏"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠭᪐"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_ and l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭᪑") not in url:
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᪒"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᪓"),l111ll_l1_+title,link,493,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࡜࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࠥࡦࡴࡾࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ᪔"),block,re.DOTALL)
		if items:
			for link,l1llll_l1_,title in items:
				title = title.strip(l11lll_l1_ (u"ࠨࠢࠪ᪕"))
				addMenuItem(l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᪖"),l111ll_l1_+title,link,492,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᪗"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᪘"),block,re.DOTALL)
			for link,title in items:
				title = unescapeHTML(title)
				title = title.replace(l11lll_l1_ (u"ࠬอไึใะอࠥ࠭᪙"),l11lll_l1_ (u"࠭ࠧ᪚"))
				if title!=l11lll_l1_ (u"ࠧࠨ᪛"): addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪜"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ᪝")+title,link,491)
	return
def PLAY(url):
	l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬ᪞"))+l11lll_l1_ (u"ࠫ࠴ࡅࡶࡪࡧࡺࡁ࠶࠭᪟")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ᪠"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ᪡"),l11lll_l1_ (u"ࠧࠨ᪢"),l11lll_l1_ (u"ࠨࠩ᪣"),l11lll_l1_ (u"ࠩࠪ᪤"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ᪥"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ᪦"))
	l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡡࡵࡣ࠽ࠤࠬࡷ࠽ࠩ࠰࠭ࡃ࠮ࠬࠢᪧ"),html,re.DOTALL)
	#if not l1ll1llll1_l1_: l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"࠭࡜ࠩࡶ࡫࡭ࡸࡢ࠮ࡪࡦ࡟࠰࠵ࡢࠬࠩ࠰࠭ࡃ࠮ࡢࠩࠨ᪨"),html,re.DOTALL)
	l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᪩"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ᪪"),block,re.DOTALL)
		for l1lll111l1_l1_,title in items:
			title = title.strip(l11lll_l1_ (u"ࠩࠣࠫ᪫"))
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡱ࡯ࡨ࠴ࡹࡥࡳࡸࡨࡶࡸ࠵ࡳࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࡂࡵࡂ࠭᪬")+l1ll1llll1_l1_+l11lll_l1_ (u"ࠫࠫ࡯࠽ࠨ᪭")+l1lll111l1_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᪮")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ᪯")
			l1111_l1_.append(link)
	# l1l11llll_l1_ l11ll1l1l_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡓࡦࡴࡹࡩࡷࠨ࠮ࠫࡁࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᪰"),html,re.DOTALL)
	if link:
		title = l11lll_l1_ (u"ࠨ็ไฺ้࠭᪱")
		link = link[0]+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࡢࡣࠬ᪲")+title
		l1111_l1_.append(link)
	# download links
	#l11l11l_l1_ = url.strip(l11lll_l1_ (u"ࠪ࠳ࠬ᪳"))+l11lll_l1_ (u"ࠫ࠴ࡅࡤࡰࡹࡱࡰࡴࡧࡤ࠾࠳ࠪ᪴")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕ᪵ࠩ"),l11l11l_l1_,l11lll_l1_ (u"᪶࠭ࠧ"),l11lll_l1_ (u"ࠧࠨ᪷"),l11lll_l1_ (u"ࠨ᪸ࠩ"),l11lll_l1_ (u"᪹ࠩࠪ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪ᪺ࠧ"))
	#html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ᪻"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᪼"),block,re.DOTALL)
		for title,link in items:
			title = title.strip(l11lll_l1_ (u"࠭ࠠࠨ᪽"))
			if l11lll_l1_ (u"ࠧࡢࡰࡤࡺ࡮ࡪࡺࠨ᪾") in link: l1lll1lll_l1_ = l11lll_l1_ (u"ࠨࡡࡢาฬ฻ᪿࠧ")
			else: l1lll1lll_l1_ = l11lll_l1_ (u"ᫀࠩࠪ")
			link = link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᫁")+title+l11lll_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ᫂")+l1lll1lll_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิส᫃ࠪ"), l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳ᫄ࠬ"),url)
	return
def SEARCH(search,l1ll1l1_l1_=l11lll_l1_ (u"ࠧࠨ᫅")):
	if not l1ll1l1_l1_: l1ll1l1_l1_ = l11ll1_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠨࠢࠪ᫆"),l11lll_l1_ (u"ࠩ࠮ࠫ᫇"))
	url = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶ࠿ࡴ࠿ࠪ᫈")+search
	l1111l_l1_(url)
	return
#   search is l11lll11l_l1_ l1l111l11_l1_ in l1111l_l1_()
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/?s=the+l1ll1lll11_l1_
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/search/the+l1ll1lll11_l1_/
#   https://l1ll1lllll_l1_.l1lll11111_l1_-l1lll1111l_l1_.l1lll1111l_l1_/index.l1ll1lll1l_l1_?s=the+l1ll1lll11_l1_
#	https://l1lll11111_l1_-l1lll1111l_l1_.io/index.l1ll1lll1l_l1_?s=the+l1ll1lll11_l1_
# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ榅")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ榆")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
#headers = l11lll_l1_ (u"ࠩࠪ榇")
#headers = {l11lll_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ榈"):l11lll_l1_ (u"ࠫࠬ榉")}
l1lll1111llll_l1_ = 0
def MAIN(mode,url,text,type,l1l11l1_l1_,name,l11l_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l1lll1111ll1l_l1_(url,name,l11l_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l1111l_l1_(url,l1l11l1_l1_,text)
	elif mode==145: results = l1lll11ll1ll1_l1_(url,l1l11l1_l1_)
	elif mode==147: results = l1lll11l111l1_l1_()
	elif mode==148: results = l1lll11l11l11_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ榊"),l111ll_l1_+l11lll_l1_ (u"࠭โศศ่อࠬ榋"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࡒࡏࡅ࡯࠻ࡇࡴ࠺ࡉࡌ࠽ࡠ࡮ࡖࡤࡉ࠴ࡗ࡜࠭࠸ࡉ࠶ࡆࡴࡷࡉࡺ࡜ࡄ࠸ࡺ࡙ࡁࠨ榌"),144)
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ榍"),l111ll_l1_+l11lll_l1_ (u"ࠩืาฺ࠭榎"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡺࡹࡥࡳ࠱ࡗࡇࡓࡵࡦࡧ࡫ࡦ࡭ࡦࡲࠧ榏"),144)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ榐"),l111ll_l1_+l11lll_l1_ (u"๋่ࠬใ฻ࠪ榑"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࡗࡆࡵ࠺࠿ࡡࡈࡐࡶࡵ࠾ࡨࡢࡩࡹ࡙ࡘࡶ࠷ࡕࡵࡸࡪࡻࠬ榒"),144)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ榓"),l111ll_l1_+l11lll_l1_ (u"ࠨฯึหอ࠭榔"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡄ࡙࡮ࡥࡔࡱࡦ࡭ࡦࡲࡃࡕࡘࠪ榕"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ榖"),l111ll_l1_+l11lll_l1_ (u"ࠫฬู๊ศสࠪ榗"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡧࡢ࡯࡬ࡲ࡬࠭榘"),144)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭榙"),l111ll_l1_+l11lll_l1_ (u"ࠧศใ็ห๊࠭榚"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡴࡶࡲࡶࡪ࡬ࡲࡰࡰࡷࠫ榛"),144)
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ榜"),l111ll_l1_+l11lll_l1_ (u"้ࠪำะวาษอࠫ榝"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ榞"),144)
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ榟"),l111ll_l1_+l11lll_l1_ (u"࠭โึ์ิอࠬ榠"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࠨ榡"),144,l11lll_l1_ (u"ࠨࠩ榢"),l11lll_l1_ (u"ࠩࠪ榣"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ榤"))
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ榥"),l111ll_l1_+l11lll_l1_ (u"ࠬะีโฯࠪ榦"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ榧"),144)
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ榨"),l111ll_l1_+l11lll_l1_ (u"ࠨำษ๎ุ๐ษࠨ榩"),l11ll1_l1_+l11lll_l1_ (u"ࠩࠪ榪"),144)
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ榫"),l111ll_l1_+l11lll_l1_ (u"ࠫึอฦอࠩ榬"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬ࡅࡢࡱ࠿ࠪ榭"),144)
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ榮"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ榯"),l11lll_l1_ (u"ࠨࠩ榰"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ榱"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ榲"),l11lll_l1_ (u"ࠫࠬ榳"),149,l11lll_l1_ (u"ࠬ࠭榴"),l11lll_l1_ (u"࠭ࠧ榵"),l11lll_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ榶"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭榷"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ榸"),l11lll_l1_ (u"ࠪࠫ榹"),9999)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ榺"),l111ll_l1_+l11lll_l1_ (u"ࠬอไาศํื๏ฯࠧ榻"),l11ll1_l1_+l11lll_l1_ (u"࠭ࠧ榼"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ榽"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ีฬฬฬสࠩ榾"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ榿"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ槀"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊สึใะࠫ槁"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ槂"),144)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭槃"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆๅู๏ืษࠨ槄"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ槅"),144,l11lll_l1_ (u"ࠩࠪ槆"),l11lll_l1_ (u"ࠪࠫ槇"),l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ槈"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ槉"),l111ll_l1_+l11lll_l1_ (u"࠭ๅฯฬสีฬะ๋๊ࠠอ๎ํฮࠧ槊"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭構"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ槌"),l111ll_l1_+l11lll_l1_ (u"่ࠩาฯอัศฬࠣห้ฮั็ษ่ะࠬ槍"),l11lll_l1_ (u"ࠪࠫ槎"),290)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ槏"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ槐"),l11lll_l1_ (u"࠭ࠧ槑"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ槒"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥ฿ัษ์ฬࠫ槓"),l11lll_l1_ (u"ࠩࠪ槔"),147)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ槕"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡลฯ๊อ๐ษࠨ槖"),l11lll_l1_ (u"ࠬ࠭槗"),148)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭様"),l111ll_l1_+l11lll_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ槙"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ槚"),144)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ槛"),l111ll_l1_+l11lll_l1_ (u"ࠪฬาั࠺ࠡษไ่ฬ๋ࠠศฮ้ฬ๏ฯࠧ槜"),l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡳ࡯ࡷ࡫ࡨࠫ槝"),144)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ槞"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ槟"),l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ槠"),144)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ槡"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡ฻ิฬ๏ฯࠧ槢"),l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁู๊ไิๆࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ槣"),144)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ槤"),l111ll_l1_+l11lll_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤฬาๆษ์ฬࠫ槥"),l11ll1_l1_+l11lll_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ࡴࡧࡵ࡭ࡪࡹࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࡀࡁࠬ槦"),144)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ槧"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯ࠿ࠦๅิๆึ่ฬะࠠไษิฮํ์ࠧ槨"),l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀ็ฬืส้่ࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࡃ࠽ࠨ槩"),144)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ槪"),l111ll_l1_+l11lll_l1_ (u"ࠫอำห࠻ࠢั฻อฯࠠศๆ่ีั฿๊สࠩ槫"),l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃโ็ษฬ࠯่ืศๅษฤ࠯ฬ๊แืษษ๎ฮ࠱ฮุสฬ࠯ฬ๊ฬๆ฻ฬࠪࡸࡶ࠽ࡄࡃࡌࡗࡆ࡮ࡁࡃࠩ槬"),144)
	return
def l1lll1111ll1l_l1_(url,name,l11l_l1_):
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭槭"),l111ll_l1_+l11lll_l1_ (u"ࠧࡄࡊࡑࡐ࠿ࠦࠠࠨ槮")+name,url,144,l11l_l1_)
	return
def l1lll11l111l1_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ槯"))
	return
def l1lll11l11l11_l1_():
	l1111l_l1_(l11ll1_l1_+l11lll_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ槰"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ槱"),l11lll_l1_ (u"ࠫࠬ槲"),l11lll_l1_ (u"ࠬ࠭槳"),url)
	#url = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀ࡫࡭ࡑ࠷ࡄ࡮࠶ࡸ࠹࠾ࡧࠨ槴")
	#items = re.findall(l11lll_l1_ (u"ࠧࡷ࠿ࠫ࠲࠯ࡅࠩࠥࠩ槵"),url,re.DOTALL)
	#id = items[0]
	#link = l11lll_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲ࡴࡱࡧࡹ࠰ࡁࡹ࡭ࡩ࡫࡯ࡠ࡫ࡧࡁࠬ槶")+id
	#PLAY_VIDEO(link,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ槷"))
	#return
	l11lll_l1_ (u"ࠥࠦࠧࠐࠉࡪ࡯ࡳࡳࡷࡺࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠍࠍࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠵ࠬࡺࡸ࡬ࠪࠌࠌࠧࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠤࠬ࠱ࡳࡵࡴࠫࡰ࡮ࡴ࡫ࡴࠫࠬࠎࠎ࡫ࡲࡳࡱࡵࡷ࠱ࡺࡩࡵ࡮ࡨࡷ࠱ࡲࡩ࡯࡭ࡶࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠳ࠩࡷࡵࡰ࠮ࠐࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࠬ࠲ࠧࠬ࠭࠮࠯࠰࠱ࠠࠡࠩ࠮ࡷࡹࡸࠨ࡭࡫ࡱ࡯ࡸ࠯ࠩࠋࠋࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠮࡬ࡪࡰ࡮ࡷࡠ࠶࡝࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠲ࡴࡺࡲࡨ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ槸")
	url = url.split(l11lll_l1_ (u"ࠫࠫ࠭槹"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],script_name,type,url)
	return
def l1lll111ll1l1_l1_(cc,url,index):
	level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = index.split(l11lll_l1_ (u"ࠬࡀ࠺ࠨ槺"))
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ槻"),l11lll_l1_ (u"ࠧࠨ槼"),index,l11lll_l1_ (u"ࠨࡈࡌࡖࡘ࡚ࠧ槽")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ槾")+url)
	l1lll1111l1l1_l1_,l1lll1111ll11_l1_ = [],[]
	# l11lll11111_l1_ l11l1ll111ll_l1_    should be the first item in the l1lll1111l1l1_l1_ list
	if l11lll_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ槿") in url: l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡇࡣࡵ࡫ࡲࡲࡸ࠭࡝ࠣ樀"))
	# l11lll11111_l1_ search l1lll11lll11l_l1_      should be the first item in the l1lll1111l1l1_l1_ list
	if l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ樁") in url: l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡣࡤ࡝ࠪࡳࡳࡘࡥࡴࡲࡲࡲࡸ࡫ࡒࡦࡥࡨ࡭ࡻ࡫ࡤࡄࡱࡰࡱࡦࡴࡤࡴࠩࡠࠦ樂"))
	# main l1l11l1_l1_
	if level==l11lll_l1_ (u"ࠧ࠲ࠩ樃"): l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࡠ࠭ࡦࡦࡧࡧࡊ࡮ࡲࡴࡦࡴࡆ࡬࡮ࡶࡂࡢࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ樄"))
	# search results
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ樅"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠࠦ樆"))
	# l1lll11l11ll1_l1_ l1lll11l1111l_l1_ & main l1l11l1_l1_ l1lll11l1111l_l1_ l1lll11lll11l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡨࡩ࡛ࠨࡧࡱࡸࡷ࡯ࡥࡴࠩࡠࠦ樇"))
	# l1lll111ll1ll_l1_ menu
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡩࡣ࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟࡞࠷ࡢࡡࠧࡨࡷ࡬ࡨࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ樈"))
	l1lll11l1l111_l1_,dd,l1lll11111l11_l1_ = l1lll1111l111_l1_(cc,l11lll_l1_ (u"࠭ࠧ樉"),l1lll1111l1l1_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ樊"),str(dd))
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ樋"),l11lll_l1_ (u"ࠩࠪ樌"),l11lll_l1_ (u"ࠪࠫ樍"),str(len(dd)))
	if level==l11lll_l1_ (u"ࠫ࠶࠭樎") and l1lll11l1l111_l1_:
		if len(dd)>1 and l11lll_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ樏") not in url:
			for zz in range(len(dd)):
				l1lll111l11ll_l1_ = str(zz)
				l1lll1111l1l1_l1_ = []
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝ࠥ樐")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ樑"))
				# l1lll11l11ll1_l1_ l1lll11l1111l_l1_
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡦࡧ࡟ࠧ樒")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠤࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩ࠭࡝ࠣ樓"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡࠢ樔")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠦࡢࠨ樕"))
				succeeded,item,l111ll1l_l1_ = l1lll1111l111_l1_(dd,l11lll_l1_ (u"ࠬ࠭樖"),l1lll1111l1l1_l1_)
				if succeeded: l1lll1111ll11_l1_.append([item,url,l11lll_l1_ (u"࠭࠲࠻࠼ࠪ樗")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ樘")])
				#l1l1l1111ll1_l1_ = l1lll11ll111l_l1_(item,url,l11lll_l1_ (u"ࠨ࠴࠽࠾ࠬ標")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠵ࡀ࠺࠱ࠩ樚"))
				#if l1l1l1111ll1_l1_: l1ll11l1l1_l1_ += 1
				#succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,token = l1lll11lll1l1_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ樛"),l111ll_l1_+title,link,144,l11lll_l1_ (u"ࠫࠬ樜"),l11lll_l1_ (u"ࠬ࠸࠺࠻ࠩ樝")+l1lll111l11ll_l1_+l11lll_l1_ (u"࠭࠺࠻࠲࠽࠾࠵࠭樞"))
				#l1ll11l1l1_l1_ += 1
			# main l1l11l1_l1_ l1lll11l1111l_l1_ l1lll11lll11l_l1_
			l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࠨ樟"))
			succeeded,item,l111ll1l_l1_ = l1lll1111l111_l1_(cc,l11lll_l1_ (u"ࠨࠩ樠"),l1lll1111l1l1_l1_)
			#LOG_THIS(l11lll_l1_ (u"ࠩࠪ模"),str(cc))
			if succeeded and l1lll1111ll11_l1_ and l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠩ樢") in list(item.keys()):
				link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ樣")
				l1lll1111ll11_l1_.append([item,link,l11lll_l1_ (u"ࠬ࠷࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ樤")])
	return dd,l1lll11l1l111_l1_,l1lll1111ll11_l1_,l1lll11111l11_l1_
def l1lll11111l1l_l1_(cc,dd,url,index):
	#DIALOG_OK(l11lll_l1_ (u"࠭ࠧ樥"),l11lll_l1_ (u"ࠧࠨ樦"),index,l11lll_l1_ (u"ࠨࡕࡈࡇࡔࡔࡄࠨ樧")+l11lll_l1_ (u"ࠩ࡟ࡲࠬ樨")+url)
	level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = index.split(l11lll_l1_ (u"ࠪ࠾࠿࠭権"))
	l1lll1111l1l1_l1_,l1lll111lll11_l1_ = [],[]
	# search results
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ横"))
	# main l1l11l1_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜ࠤ樫")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵࡩࡱࡵࡡࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ樬"))
	# l11lll1lllll_l1_ l1lll11l1111l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠵ࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ樭"))
	# l11lll11111_l1_ search & l11l1ll111ll_l1_ & l1lll11lll11l_l1_
	if l11lll_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ樮") in url: l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ樯"))
	elif l11lll_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ樰") in url: l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ樱"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜ࠤ樲")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ樳"))
	# l11lll1lllll_l1_ l11ll11l1l_l1_ & l1lll11l1111l_l1_ filters
	if l11lll_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ樴") in url or (l11lll_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ樵") in url and l11lll_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵ࠲ࠫ樶") not in url):
		l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡨࡩࡡࠢ樷")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࡡࠧࡧࡧࡨࡨࡋ࡯࡬ࡵࡧࡵࡇ࡭࡯ࡰࡃࡣࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ樸"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡪࡤ࡜ࠤ樹")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡌࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ樺"))
	# l1lll11l11ll1_l1_ search
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞ࠦ樻")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠣ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ樼"))
	# main l1l11l1_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡧࡨࡠࠨ樽")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡖ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ樾"))
	# l11lll11111_l1_ l11l1ll111ll_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡩࡪ࡛ࠣ樿")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠧࡣࠢ橀"))
	l1lll11l11l1l_l1_,ee,l1lll111ll111_l1_ = l1lll1111l111_l1_(dd,l11lll_l1_ (u"࠭ࠧ橁"),l1lll1111l1l1_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ橂"),str(ee))
	#DIALOG_OK()
	if level==l11lll_l1_ (u"ࠨ࠴ࠪ橃") and l1lll11l11l1l_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l1lll1111l1l1_l1_ = []
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ橄")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ橅"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ橆")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ橇"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ橈")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡤࡶࡩࡹࠧ࡞ࠤ橉"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ橊")+index2+l11lll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ橋"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡩࡪࡡࠢ橌")+index2+l11lll_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ橍"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ橎")+index2+l11lll_l1_ (u"ࠨ࡝ࠣ橏"))
				succeeded,item,l111ll1l_l1_ = l1lll1111l111_l1_(ee,l11lll_l1_ (u"ࠧࠨ橐"),l1lll1111l1l1_l1_)
				if succeeded: l1lll111lll11_l1_.append([item,url,l11lll_l1_ (u"ࠨ࠵࠽࠾ࠬ橑")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ橒")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠶ࠧ橓")])
				#l1l1l1111ll1_l1_ = l1lll11ll111l_l1_(item,url,l11lll_l1_ (u"ࠫ࠸ࡀ࠺ࠨ橔")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ橕")+index2+l11lll_l1_ (u"࠭࠺࠻࠲ࠪ橖"))
				#if l1l1l1111ll1_l1_: l1l1l11l11_l1_ += 1
				#LOG_THIS(l11lll_l1_ (u"ࠧࠨ橗"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ橘")+str(item))
				#l1l1l11l11_l1_ += 1
				#item = ee[zz]
				#succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,token = l1lll11lll1l1_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ橙"),l111ll_l1_+title,link,144,l1llll_l1_,l11lll_l1_ (u"ࠪ࠷࠿ࡀࠧ橚")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ橛")+index2+l11lll_l1_ (u"ࠬࡀ࠺࠱ࠩ橜"))
			# search l1lll11lll11l_l1_
			l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡤࡥ࡝࠳ࡡࡠ࠭ࡡࡱࡲࡨࡲࡩࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࡃࡦࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟࡞࠵ࡢࠨ橝"))
			# search l1lll11lll11l_l1_
			l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡥࡦ࡞࠵ࡢࠨ橞"))
			succeeded,item,l111ll1l_l1_ = l1lll1111l111_l1_(dd,l11lll_l1_ (u"ࠨࠩ機"),l1lll1111l1l1_l1_)
			if succeeded and l1lll111lll11_l1_ and l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭橠") in list(item.keys()):
				l1lll111lll11_l1_.append([item,url,l11lll_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ橡")])
			#l1l1l1111ll1_l1_ = l1lll11ll111l_l1_(item,url,l11lll_l1_ (u"ࠫ࠸ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ橢"))
			#if l1l1l1111ll1_l1_: l1l1l11l11_l1_ += 1
			#LOG_THIS(l11lll_l1_ (u"ࠬ࠭橣"),str(item))
			#LOG_THIS(l11lll_l1_ (u"࠭ࠧ橤"),link+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ橥")+token)
	return ee,l1lll11l11l1l_l1_,l1lll111lll11_l1_,l1lll111ll111_l1_
def l1lll1111lll1_l1_(cc,ee,url,index):
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ橦"),l11lll_l1_ (u"ࠩࠪ橧"),index,l11lll_l1_ (u"ࠪࡘࡍࡏࡒࡅࠩ橨")+l11lll_l1_ (u"ࠫࡡࡴࠧ橩")+url)
	level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = index.split(l11lll_l1_ (u"ࠬࡀ࠺ࠨ橪"))
	l1lll1111l1l1_l1_,l1lll111l111l_l1_ = [],[]
	# search results
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ橫")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡺࡪࡸࡴࡪࡥࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ橬"))
	# l11lll11111_l1_ l11l1ll111ll_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟ࠧ橭")+index2+l11lll_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ橮"))
	# l1lll11ll1111_l1_ menu l1lll11l1111l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡩࡪࡡࠢ橯")+index2+l11lll_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡶࡪ࡫࡬ࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ橰"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡫ࡥ࡜ࠤ橱")+index2+l11lll_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ橲"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡦࡧ࡞ࠦ橳")+index2+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ橴"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠࠨ橵")+index2+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡧࡧࡗ࡭࡫࡬ࡧࡅࡲࡲࡹ࡫࡮ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ橶"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ橷")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ橸"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ橹")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ橺"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ橻"))
	# l1lll11l11ll1_l1_ l1lll11lll1ll_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ橼"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ橽"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡪ࡫࡛ࠣ橾")+index2+l11lll_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ橿"))
	# main l1l11l1_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡥࡦ࡝ࠥ檀")+index2+l11lll_l1_ (u"ࠢ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ檁"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡧࡨࠦ檂"))
	l1lll11l1l1l1_l1_,ff,l1lll11lll111_l1_ = l1lll1111l111_l1_(ee,l11lll_l1_ (u"ࠩࠪ檃"),l1lll1111l1l1_l1_)
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ檄"),str(ff))
	if level==l11lll_l1_ (u"ࠫ࠸࠭檅") and l1lll11l1l1l1_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l1lll11l11111_l1_ = str(zz)
				#DIALOG_OK()
				l1lll1111l1l1_l1_ = []
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡬ࡦ࡜ࠤ檆")+l1lll11l11111_l1_+l11lll_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ檇"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡧࡨ࡞ࠦ檈")+l1lll11l11111_l1_+l11lll_l1_ (u"ࠣ࡟࡞ࠫ࡬ࡧ࡭ࡦࡅࡤࡶࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡫ࡦࡳࡥࠨ࡟ࠥ檉"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡩࡪࡠࠨ檊")+l1lll11l11111_l1_+l11lll_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝ࠣ檋"))
				l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦ࡫࡬࡛ࠣ檌")+l1lll11l11111_l1_+l11lll_l1_ (u"ࠧࡣࠢ檍"))
				succeeded,item,l111ll1l_l1_ = l1lll1111l111_l1_(ff,l11lll_l1_ (u"࠭ࠧ檎"),l1lll1111l1l1_l1_)
				#succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,token = l1lll11lll1l1_l1_(item)
				#addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭檏"),l111ll_l1_+link,link,143,l1llll_l1_)
				if succeeded: l1lll111l111l_l1_.append([item,url,l11lll_l1_ (u"ࠨ࠶࠽࠾ࠬ檐")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠩ࠽࠾ࠬ檑")+index2+l11lll_l1_ (u"ࠪ࠾࠿࠭檒")+l1lll11l11111_l1_])
				#l1l1l1111ll1_l1_ = l1lll11ll111l_l1_(item,url,l11lll_l1_ (u"ࠫ࠹ࡀ࠺ࠨ檓")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠬࡀ࠺ࠨ檔")+index2+l11lll_l1_ (u"࠭࠺࠻ࠩ檕")+l1lll11l11111_l1_)
				#if l1l1l1111ll1_l1_: l1l1l11l1l_l1_ += 1
	return ff,l1lll11l1l1l1_l1_,l1lll111l111l_l1_,l1lll11lll111_l1_
def l1lll1111l111_l1_(l11llll1ll11_l1_,l11llllll111_l1_,l1lll111l11l1_l1_):
	cc,l11llllll111_l1_ = l11llll1ll11_l1_,l11llllll111_l1_
	dd,l11llllll111_l1_ = l11llll1ll11_l1_,l11llllll111_l1_
	ee,l11llllll111_l1_ = l11llll1ll11_l1_,l11llllll111_l1_
	ff,l11llllll111_l1_ = l11llll1ll11_l1_,l11llllll111_l1_
	item,render = l11llll1ll11_l1_,l11llllll111_l1_
	count = len(l1lll111l11l1_l1_)
	for l11l1lllll_l1_ in range(count):
		try:
			out = eval(l1lll111l11l1_l1_[l11l1lllll_l1_])
			#if isinstance(out,dict): out = l11lll_l1_ (u"ࠧࠨ檖")
			return True,out,l11l1lllll_l1_+1
		except: pass
	return False,l11lll_l1_ (u"ࠨࠩ檗"),0
def l1111l_l1_(url,index=l11lll_l1_ (u"ࠩࠪ檘"),data=l11lll_l1_ (u"ࠪࠫ檙")):
	l1lll1111ll11_l1_,l1lll111lll11_l1_,l1lll111l111l_l1_ = [],[],[]
	if l11lll_l1_ (u"ࠫ࠿ࡀࠧ檚") not in index: index = l11lll_l1_ (u"ࠬ࠷࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ檛")
	level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = index.split(l11lll_l1_ (u"࠭࠺࠻ࠩ檜"))
	if level==l11lll_l1_ (u"ࠧ࠵ࠩ檝"): level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = l11lll_l1_ (u"ࠨ࠳ࠪ檞"),l1lll111l11ll_l1_,index2,l1lll11l11111_l1_
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ檟"),l11lll_l1_ (u"ࠪࠫ檠"),index,url)
	data = data.replace(l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ檡"),l11lll_l1_ (u"ࠬ࠭檢"))
	html,cc,l11llll11_l1_ = l1lll111lll1l_l1_(url,data)
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡭࡫ࠦࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪࠤ࡮ࡴࠠࡶࡴ࡯ࠤࡴࡸࠠࠨ࠱ࡸࡷࡪࡸ࠯ࠨࠢ࡬ࡲࠥࡻࡲ࡭࠼ࠍࠍࠎࠩ࡯ࡸࡰࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡴ࡯ࡵࠢࡲࡻࡳ࡫ࡲ࠻ࠢࠍࠍࠎࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡩࡨࡢࡰࡱࡩࡱࡓࡥࡵࡣࡧࡥࡹࡧࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡲࡻࡳ࡫ࡲࡖࡴ࡯ࡷࠧࡀ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠤ࡫ࡩࠤࡳࡵࡴࠡࡱࡺࡲࡪࡸ࠺ࠡࡱࡺࡲࡪࡸࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡸ࡬ࡨࡪࡵࡏࡸࡰࡨࡶࠧ࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥࡵࡷ࡯ࡧࡵ࠾ࠏࠏࠉࠊࡱࡺࡲࡪࡸࡎࡂࡏࡈࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮࡯ࡸࡰࡨࡶࡠ࠶࡝࡜࠲ࡠ࠭ࠏࠏࠉࠊࡱࡺࡲࡪࡸࡎࡂࡏࡈࠤࡂࠦࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ࠯ࡴࡽ࡮ࡦࡴࡑࡅࡒࡋࠫࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡰࡹࡱࡩࡷࡡ࠰࡞࡝࠴ࡡࠏࠏࠉࠊ࡫ࡩࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱࡬ࡪࡰ࡮ࠎࠎࠏࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡳࡼࡴࡥࡳࡐࡄࡑࡊ࠲࡬ࡪࡰ࡮࠰࠶࠺࠴ࠪࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡱ࡯࡮࡬ࠩ࠯ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠱࠭ࠧ࠭࠻࠼࠽࠾࠯ࠊࠊࠤࠥࠦ檣")
	index = level+l11lll_l1_ (u"ࠧ࠻࠼ࠪ檤")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ檥")+index2+l11lll_l1_ (u"ࠩ࠽࠾ࠬ檦")+l1lll11l11111_l1_
	if level in [l11lll_l1_ (u"ࠪ࠵ࠬ檧"),l11lll_l1_ (u"ࠫ࠷࠭檨"),l11lll_l1_ (u"ࠬ࠹ࠧ檩")]:
		dd,l1lll11l1l111_l1_,l1lll1111ll11_l1_,l1lll11111l11_l1_ = l1lll111ll1l1_l1_(cc,url,index)
		if not l1lll11l1l111_l1_: return
		l1ll11l1l1_l1_ = len(l1lll1111ll11_l1_)
		if l1ll11l1l1_l1_<2:
			if level==l11lll_l1_ (u"࠭࠱ࠨ檪"): level = l11lll_l1_ (u"ࠧ࠳ࠩ檫")
			l1lll1111ll11_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ檬"),l11lll_l1_ (u"ࠩࠪ檭"),index,l11lll_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠵ࡡࡴࠧ檮")+l11lll_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ檯")+str(l1lll11111l11_l1_)+l11lll_l1_ (u"ࠬࡢ࡮ࠨ檰")+l11lll_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ檱")+str(len(dd))+l11lll_l1_ (u"ࠧ࡝ࡰࠪ檲")+l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ檳")+str(l1ll11l1l1_l1_)+l11lll_l1_ (u"ࠩ࡟ࡲࠬ檴")+url)
	index = level+l11lll_l1_ (u"ࠪ࠾࠿࠭檵")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ檶")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ檷")+l1lll11l11111_l1_
	if level in [l11lll_l1_ (u"࠭࠲ࠨ檸"),l11lll_l1_ (u"ࠧ࠴ࠩ檹")]:
		ee,l1lll11l11l1l_l1_,l1lll111lll11_l1_,l1lll111ll111_l1_ = l1lll11111l1l_l1_(cc,dd,url,index)
		if not l1lll11l11l1l_l1_: return
		l1l1l11l11_l1_ = len(l1lll111lll11_l1_)
		if l1l1l11l11_l1_<2:
			if level==l11lll_l1_ (u"ࠨ࠴ࠪ檺"): level = l11lll_l1_ (u"ࠩ࠶ࠫ檻")
			l1lll111lll11_l1_ = []
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ檼"),l11lll_l1_ (u"ࠫࠬ檽"),index,l11lll_l1_ (u"ࠬࡲࡥࡷࡧ࡯࠾ࠥ࠸࡜࡯ࠩ檾")+l11lll_l1_ (u"࠭ࡳࡦࡳࡸࡩࡳࡩࡥ࠻ࠢࠪ檿")+str(l1lll111ll111_l1_)+l11lll_l1_ (u"ࠧ࡝ࡰࠪ櫀")+l11lll_l1_ (u"ࠨ࡮ࡨࡲ࡬ࡺࡨ࠻ࠢࠪ櫁")+str(len(ee))+l11lll_l1_ (u"ࠩ࡟ࡲࠬ櫂")+l11lll_l1_ (u"ࠪࡧࡴࡻ࡮ࡵ࠼ࠣࠫ櫃")+str(l1l1l11l11_l1_)+l11lll_l1_ (u"ࠫࡡࡴࠧ櫄")+url)
	index = level+l11lll_l1_ (u"ࠬࡀ࠺ࠨ櫅")+l1lll111l11ll_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ櫆")+index2+l11lll_l1_ (u"ࠧ࠻࠼ࠪ櫇")+l1lll11l11111_l1_
	if level in [l11lll_l1_ (u"ࠨ࠵ࠪ櫈")]:
		ff,l1lll11l1l1l1_l1_,l1lll111l111l_l1_,l1lll11lll111_l1_ = l1lll1111lll1_l1_(cc,ee,url,index)
		if not l1lll11l1l1l1_l1_: return
		l1l1l11l1l_l1_ = len(l1lll111l111l_l1_)
		#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ櫉"),l11lll_l1_ (u"ࠪࠫ櫊"),index,l11lll_l1_ (u"ࠫࡱ࡫ࡶࡦ࡮࠽ࠤ࠸ࡢ࡮ࠨ櫋")+l11lll_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫࠺ࠡࠩ櫌")+str(l1lll11lll111_l1_)+l11lll_l1_ (u"࠭࡜࡯ࠩ櫍")+l11lll_l1_ (u"ࠧ࡭ࡧࡱ࡫ࡹ࡮࠺ࠡࠩ櫎")+str(len(ff))+l11lll_l1_ (u"ࠨ࡞ࡱࠫ櫏")+l11lll_l1_ (u"ࠩࡦࡳࡺࡴࡴ࠻ࠢࠪ櫐")+str(l1l1l11l1l_l1_)+l11lll_l1_ (u"ࠪࡠࡳ࠭櫑")+url)
	for item,url,index in l1lll1111ll11_l1_+l1lll111lll11_l1_+l1lll111l111l_l1_:
		l1l1l1111ll1_l1_ = l1lll11ll111l_l1_(item,url,index)
	return
def l1lll11ll111l_l1_(item,url=l11lll_l1_ (u"ࠫࠬ櫒"),index=l11lll_l1_ (u"ࠬ࠭櫓")):
	if l11lll_l1_ (u"࠭࠺࠻ࠩ櫔") in index: level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = index.split(l11lll_l1_ (u"ࠧ࠻࠼ࠪ櫕"))
	else: level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = l11lll_l1_ (u"ࠨ࠳ࠪ櫖"),l11lll_l1_ (u"ࠩ࠳ࠫ櫗"),l11lll_l1_ (u"ࠪ࠴ࠬ櫘"),l11lll_l1_ (u"ࠫ࠵࠭櫙")
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,l1lll11ll1l11_l1_ = l1lll11lll1l1_l1_(item)
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭櫚"),url)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ櫛"),link)
	#LOG_THIS(l11lll_l1_ (u"ࠧࠨ櫜"),link+l11lll_l1_ (u"ࠨࠢࠣࠤࠬ櫝")+title)
	# needed for l1lll11l11ll1_l1_ l1lll11lll1ll_l1_ next l1l11l1_l1_
	# and needed for l1lll11l11ll1_l1_ l1lll11lll1ll_l1_ sub-menu
	#if (l11lll_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽࠶࠲ࠪ櫞") in link or l11lll_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾࠶࠼ࠫ櫟") in link) and (l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࡀࠩ櫠") in link or l11lll_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࡀࠩ櫡") in link): link = url
	l1ll1l111111_l1_ = l11lll_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹ࠿ࠨ櫢") in link or l11lll_l1_ (u"ࠧ࠰ࡵࡷࡶࡪࡧ࡭ࡴࡁࠪ櫣") in link or l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࡄ࠭櫤") in link
	l1ll11lllll1_l1_ = l11lll_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࡄ࠭櫥") in link or l11lll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࡃࠬ櫦") in link
	if l1ll1l111111_l1_ or l1ll11lllll1_l1_: link = url
	l1ll1l111111_l1_ = l11lll_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭櫧") not in link and l11lll_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ櫨") not in link
	l1ll11lllll1_l1_ = l11lll_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ櫩") not in link  and l11lll_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡳࡵࡱࡵࡩ࡫ࡸ࡯࡯ࡶࠪ櫪") not in link
	if index[0:5]==l11lll_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺ࠨ櫫") and l1ll1l111111_l1_ and l1ll11lllll1_l1_: link = url
	if l11lll_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ櫬") in url or l11lll_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ櫭") in link:
		level,l1lll111l11ll_l1_,index2,l1lll11l11111_l1_ = l11lll_l1_ (u"ࠫ࠶࠭櫮"),l11lll_l1_ (u"ࠬ࠶ࠧ櫯"),l11lll_l1_ (u"࠭࠰ࠨ櫰"),l11lll_l1_ (u"ࠧ࠱ࠩ櫱")
		index = l11lll_l1_ (u"ࠨࠩ櫲")
	l11llll11_l1_ = l11lll_l1_ (u"ࠩࠪ櫳")
	if l11lll_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡥࡶࡴࡽࡳࡦࠩ櫴") in link or l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡷࡪࡧࡲࡤࡪࠪ櫵") in link or l11lll_l1_ (u"ࠬ࠵࡭ࡺࡡࡰࡥ࡮ࡴ࡟ࡱࡣࡪࡩࡤࡹࡨࡰࡴࡷࡷࡤࡲࡩ࡯࡭ࠪ櫶") in url:
		data = settings.getSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ櫷"))
		if data.count(l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ櫸"))==4:
			l1lll11l1l11l_l1_,key,l1lll11l111ll_l1_,l1lll111l1l1l_l1_,token = data.split(l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ櫹"))
			l11llll11_l1_ = l1lll11l1l11l_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭櫺")+key+l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ櫻")+l1lll11l111ll_l1_+l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ櫼")+l1lll111l1l1l_l1_+l11lll_l1_ (u"ࠬࡀ࠺࠻ࠩ櫽")+l1lll11ll1l11_l1_
			if l11lll_l1_ (u"࠭࠯࡮ࡻࡢࡱࡦ࡯࡮ࡠࡲࡤ࡫ࡪࡥࡳࡩࡱࡵࡸࡸࡥ࡬ࡪࡰ࡮ࠫ櫾") in url and not link: link = url
			else: link = link+l11lll_l1_ (u"ࠧࡀ࡭ࡨࡽࡂ࠭櫿")+key
	if not title:
		global l1lll1111llll_l1_
		l1lll1111llll_l1_ += 1
		title = l11lll_l1_ (u"ࠨใํำ๏๎็ศฬࠣࠫ欀")+str(l1lll1111llll_l1_)
		index = l11lll_l1_ (u"ࠩ࠶ࠫ欁")+l11lll_l1_ (u"ࠪ࠾࠿࠭欂")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠧ欃")+index2+l11lll_l1_ (u"ࠬࡀ࠺ࠨ欄")+l1lll11l11111_l1_
	#if l11lll_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬ欅") in url: link = url
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ欆"),l11lll_l1_ (u"ࠨࠩ欇"),title,index+l11lll_l1_ (u"ࠩ࡟ࡲࠬ欈")+link)
	#if not link: link = url
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ欉"),l11lll_l1_ (u"ࠫࠬ權"),str(succeeded),title+l11lll_l1_ (u"ࠬࠦ࠺࠻࠼ࠣࠫ欋")+link)
	#if l11lll_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ欌") in url and index==l11lll_l1_ (u"ࠧ࠱ࠩ欍"):
	#	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ欎"),l111ll_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11lll_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭欏") in str(item): return False			# l1lll11l1llll_l1_ not items
	elif l11lll_l1_ (u"ࠪ࠳ࡦࡨ࡯ࡶࡶࠪ欐") in link: return False
	elif l11lll_l1_ (u"ࠫ࠴ࡩ࡯࡮࡯ࡸࡲ࡮ࡺࡹࠨ欑") in link: return False
	elif l11lll_l1_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩ欒") in list(item.keys()) or l11lll_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬ欓") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11lll_l1_ (u"ࠧ࠻࠼ࠪ欔")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠨ࠼࠽ࠫ欕")+index2+l11lll_l1_ (u"ࠩ࠽࠾ࠬ欖")+l1lll11l11111_l1_
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ欗"),l111ll_l1_+l11lll_l1_ (u"ࠫ࠿ࡀࠠࠨ欘")+l11lll_l1_ (u"ࠬ฻แฮหࠣวำื้ࠨ欙"),link,144,l1llll_l1_,index,l11llll11_l1_)
	elif l11lll_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ欚") in link:
		title = l11lll_l1_ (u"ࠧ࠻࠼ࠣࠫ欛")+title
		index = l11lll_l1_ (u"ࠨ࠵ࠪ欜")+l11lll_l1_ (u"ࠩ࠽࠾ࠬ欝")+l1lll111l11ll_l1_+l11lll_l1_ (u"ࠪ࠾࠿࠭欞")+index2+l11lll_l1_ (u"ࠫ࠿ࡀࠧ欟")+l1lll11l11111_l1_
		url = url.replace(l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭欠"),l11lll_l1_ (u"࠭ࠧ次"))
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ欢"),l111ll_l1_+title,url,145,l11lll_l1_ (u"ࠨࠩ欣"),index,l11lll_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭欤"))
	elif l11lll_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ欥") in url and not link:
		index = l11lll_l1_ (u"ࠫ࠸࠭欦")+l11lll_l1_ (u"ࠬࡀ࠺ࠨ欧")+l1lll111l11ll_l1_+l11lll_l1_ (u"࠭࠺࠻ࠩ欨")+index2+l11lll_l1_ (u"ࠧ࠻࠼ࠪ欩")+l1lll11l11111_l1_
		title = l11lll_l1_ (u"ࠨ࠼࠽ࠤࠬ欪")+title
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ欫"),l111ll_l1_+title,url,144,l1llll_l1_,index,l11llll11_l1_)
	#elif l11lll_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡡ࡬ࡨࡂ࠭欬") in link: return False
	elif l11lll_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࠬ欭") in link and url==l11ll1_l1_:
		title = l11lll_l1_ (u"ࠬࡀ࠺ࠡࠩ欮")+title
		index = l11lll_l1_ (u"࠭࠲࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ欯")
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ欰"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11llll11_l1_)
	elif not link and l11lll_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ欱") in str(item):
		title = l11lll_l1_ (u"ࠩ࠽࠾ࠥ࠭欲")+title
		index = l11lll_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ欳")
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ欴"),l111ll_l1_+title,url,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ欵") in str(item):
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ欶"),l111ll_l1_+title,l11lll_l1_ (u"ࠧࠨ欷"),9999)
	#elif l11lll_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ欸") in link and l11lll_l1_ (u"ࠩࡥࡴࡂ࠭欹") not in link:
	#	title = l11lll_l1_ (u"ࠪ࠾࠿ࠦࠧ欺")+title
	#	index = l11lll_l1_ (u"ࠫ࠷ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ欻")
	#	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ欼"),l111ll_l1_+title,link,144,l1llll_l1_,index)
	elif l111l1111ll_l1_:
		addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ欽"),l111ll_l1_+l111l1111ll_l1_+title,link,143,l1llll_l1_)
	elif l11lll_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ款") in link:
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ欿"),l111ll_l1_+l11lll_l1_ (u"ࠩࡏࡍࡘ࡚ࠧ歀")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ歁")+title,link,144,l1llll_l1_,index)
	#elif l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵ࠿ࠪ歂") in link and l11lll_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ歃") not in link and l11lll_l1_ (u"࠭ࡴ࠾࠲ࠪ歄") not in link:
	#	l1lll111lllll_l1_ = re.findall(l11lll_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠮࠮ࠫࡁࠬࠨࠬ歅"),link,re.DOTALL)
	#	link = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࠪ歆")+l1lll111lllll_l1_[0]
	#	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ歇"),l111ll_l1_+l11lll_l1_ (u"ࠪࡐࡎ࡙ࡔࠨ歈")+count+l11lll_l1_ (u"ࠫ࠿ࠦࠠࠨ歉")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ歊") in link:
		link = link.split(l11lll_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭歋"),1)[0]
		addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭歌"),l111ll_l1_+title,link,143,l1llll_l1_,l1l111l1ll_l1_)
	elif l11lll_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ歍") in link:
		if l11lll_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ歎") in link and count:
			l1lll111lllll_l1_ = link.split(l11lll_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ歏"),1)[1]
			link = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭歐")+l1lll111lllll_l1_
			index = l11lll_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ歑")
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭歒"),l111ll_l1_+l11lll_l1_ (u"ࠧࡍࡋࡖࡘࠬ歓")+count+l11lll_l1_ (u"ࠨ࠼ࠣࠤࠬ歔")+title,link,144,l1llll_l1_,index)
		else:
			link = link.split(l11lll_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ歕"),1)[0]
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ歖"),l111ll_l1_+title,link,143,l1llll_l1_,l1l111l1ll_l1_)
	elif l11lll_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ歗") in link or l11lll_l1_ (u"ࠬ࠵ࡣ࠰ࠩ歘") in link or (l11lll_l1_ (u"࠭࠯ࡁࠩ歙") in link and link.count(l11lll_l1_ (u"ࠧ࠰ࠩ歚"))==3):
		addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ歛"),l111ll_l1_+l11lll_l1_ (u"ࠩࡆࡌࡓࡒࠧ歜")+count+l11lll_l1_ (u"ࠪ࠾ࠥࠦࠧ歝")+title,link,144,l1llll_l1_,index)
	elif l11lll_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ歞") in link:
		addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ歟"),l111ll_l1_+l11lll_l1_ (u"࠭ࡕࡔࡇࡕࠫ歠")+count+l11lll_l1_ (u"ࠧ࠻ࠢࠣࠫ歡")+title,link,144,l1llll_l1_,index)
	else:
		if not link: link = url
		title = l11lll_l1_ (u"ࠨ࠼࠽ࠤࠬ止")+title
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ正"),l111ll_l1_+title,link,144,l1llll_l1_,index,l11llll11_l1_)
	return True
def l1lll11lll1l1_l1_(item):
	succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,token = False,l11lll_l1_ (u"ࠪࠫ此"),l11lll_l1_ (u"ࠫࠬ步"),l11lll_l1_ (u"ࠬ࠭武"),l11lll_l1_ (u"࠭ࠧ歧"),l11lll_l1_ (u"ࠧࠨ歨"),l11lll_l1_ (u"ࠨࠩ歩"),l11lll_l1_ (u"ࠩࠪ歪"),l11lll_l1_ (u"ࠪࠫ歫")
	#LOG_THIS(l11lll_l1_ (u"ࠫࠬ歬"),str(item))
	if not isinstance(item,dict): return succeeded,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,token
	for l1lll11l1ll1l_l1_ in list(item.keys()):
		render = item[l1lll11l1ll1l_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11lll_l1_ (u"ࠬ࠭歭"),str(render))
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ歮"),str(render))
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ歯"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬࡸࡩࡤࡪࡏ࡭ࡸࡺࡈࡦࡣࡧࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ歰"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪ࡬ࡪࡧࡤ࡭࡫ࡱࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ歱"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ歲"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ歳"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ歴"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ歵"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ歶"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ歷"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ歸"))
	# required for l11lll1lllll_l1_ l1lll111ll11l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ歹"))
	# l1lll11l11ll1_l1_ l1lll11l1111l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦ࡮ࡺࡥ࡮࡝ࠪࡶࡪ࡫࡬ࡘࡣࡷࡧ࡭ࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡺ࡮ࡪࡥࡰࡋࡧࠫࡢࠨ歺"))
	succeeded,title,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭死"),l11lll_l1_ (u"࠭ࠧ歼"),l11lll_l1_ (u"ࠧࠨ歽"),str(l111ll1l_l1_))
	#LOG_THIS(l11lll_l1_ (u"ࠨࠩ歾"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠩࠣࠤࠥ࠭歿")+str(title))
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ殀"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ殁"))
	# l1lll11lll11l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡣࡳ࡭࡚ࡸ࡬ࠨ࡟ࠥ殂"))
	# header feed
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡢࡲ࡬࡙ࡷࡲࠧ࡞ࠤ殃"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ殄"))
	# required for l11lll1lllll_l1_ l1lllll1l1l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ殅"))
	# l1lll11l11ll1_l1_ l1lll11l1111l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ殆"))
	succeeded,link,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ殇"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ殈"))
	# l1lll11l11ll1_l1_ l1lll11l1111l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡷ࡫ࡥ࡭࡙ࡤࡸࡨ࡮ࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ殉"))
	succeeded,l1llll_l1_,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	#LOG_THIS(l11lll_l1_ (u"࠭ࠧ殊"),str(l111ll1l_l1_)+l11lll_l1_ (u"ࠧࠡࠢࠣࠫ残")+l1llll_l1_)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ殌"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ殍"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ殎"))
	succeeded,count,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	l1lll1111l1l1_l1_ = []
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ殏"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ殐"))
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ殑"))
	# l1lll11l1ll11_l1_ l1lll11l11ll1_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡥࡲࡲࠬࡣ࡛ࠨ࡫ࡦࡳࡳ࡚ࡹࡱࡧࠪࡡࠧ殒"))
	# l1lll11l1ll11_l1_ l1lll11l11ll1_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡵࡷࡽࡱ࡫ࠧ࡞ࠤ殓"))
	succeeded,l1l111l1ll_l1_,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	#l1lll1111l1l1_l1_ = []
	# l1lll11lll11l_l1_
	#l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣ࡭࡫ࡦ࡯࡙ࡸࡡࡤ࡭࡬ࡲ࡬ࡖࡡࡳࡣࡰࡷࠬࡣࠢ殔"))
	# l11lll11111_l1_ l11l1ll111ll_l1_
	#l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡺࡲࡢࡥ࡮࡭ࡳ࡭ࡐࡢࡴࡤࡱࡸ࠭࡝ࠣ殕"))
	#succeeded,l1lll111l1111_l1_,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	l1lll1111l1l1_l1_ = []
	# l11lll11111_l1_ l11l1ll111ll_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡶࡲ࡯ࡪࡴࠧ࡞ࠤ殖"))
	# l1lll11lll11l_l1_
	l1lll1111l1l1_l1_.append(l11lll_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡹࡵ࡫ࡦࡰࠪࡡࠧ殗"))
	succeeded,token,l111ll1l_l1_ = l1lll1111l111_l1_(item,render,l1lll1111l1l1_l1_)
	if l11lll_l1_ (u"࠭ࡌࡊࡘࡈࠫ殘") in l1l111l1ll_l1_: l1l111l1ll_l1_,l111l1111ll_l1_ = l11lll_l1_ (u"ࠧࠨ殙"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ殚")
	if l11lll_l1_ (u"่ࠩฬฬฺัࠨ殛") in l1l111l1ll_l1_: l1l111l1ll_l1_,l111l1111ll_l1_ = l11lll_l1_ (u"ࠪࠫ殜"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ殝")
	if l11lll_l1_ (u"ࠬࡨࡡࡥࡩࡨࡷࠬ殞") in list(render.keys()):
		l1lll11ll11l1_l1_ = str(render[l11lll_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭殟")])
		if l11lll_l1_ (u"ࠧࡇࡴࡨࡩࠥࡽࡩࡵࡪࠣࡅࡩࡹࠧ殠") in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠨࠦ࠽ࠤࠥ࠭殡")
		if l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ殢") in l1lll11ll11l1_l1_: l111l1111ll_l1_ = l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅ࠻ࠢࠣࠫ殣")
		if l11lll_l1_ (u"ࠫࡇࡻࡹࠨ殤") in l1lll11ll11l1_l1_ or l11lll_l1_ (u"ࠬࡘࡥ࡯ࡶࠪ殥") in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ殦")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡵࠨ็หหูืࠧ殧")) in l1lll11ll11l1_l1_: l111l1111ll_l1_ = l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ殨")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡷุࠪึอมࠨ殩")) in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ殪")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡹࠬอำหศฯหึ࠭殫")) in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠬࠪࠤ࠻ࠢࠣࠫ殬")
		if l1l1l11111ll_l1_(l11lll_l1_ (u"ࡻࠧฦ฻็ห๋อสࠨ殭")) in l1lll11ll11l1_l1_: l1lll111llll1_l1_ = l11lll_l1_ (u"ࠧࠥ࠼ࠣࠤࠬ殮")
	link = escapeUNICODE(link)
	if link and l11lll_l1_ (u"ࠨࡪࡷࡸࡵ࠭殯") not in link: link = l11ll1_l1_+link
	l1llll_l1_ = l1llll_l1_.split(l11lll_l1_ (u"ࠩࡂࠫ殰"))[0]
	if  l1llll_l1_ and l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ殱") not in l1llll_l1_: l1llll_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ殲")+l1llll_l1_
	title = escapeUNICODE(title)
	if l1lll111llll1_l1_: title = l1lll111llll1_l1_+title
	#title = unescapeHTML(title)
	l1l111l1ll_l1_ = l1l111l1ll_l1_.replace(l11lll_l1_ (u"ࠬ࠲ࠧ殳"),l11lll_l1_ (u"࠭ࠧ殴"))
	count = count.replace(l11lll_l1_ (u"ࠧ࠭ࠩ段"),l11lll_l1_ (u"ࠨࠩ殶"))
	count = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨ࠰࠭殷"),count)
	if count: count = count[0]
	else: count = l11lll_l1_ (u"ࠪࠫ殸")
	return True,title,link,l1llll_l1_,count,l1l111l1ll_l1_,l111l1111ll_l1_,l1lll111llll1_l1_,token
def l1lll111lll1l_l1_(url,data=l11lll_l1_ (u"ࠫࠬ殹"),request=l11lll_l1_ (u"ࠬ࠭殺")):
	if request==l11lll_l1_ (u"࠭ࠧ殻"): request = l11lll_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ殼")
	#if l11lll_l1_ (u"ࠨࡡࡢࠫ殽") in l1lll11l11lll_l1_: l1lll11l11lll_l1_ = l11lll_l1_ (u"ࠩࠪ殾")
	#if l11lll_l1_ (u"ࠪࡷࡸࡃࠧ殿") in url: url = url.split(l11lll_l1_ (u"ࠫࡸࡹ࠽ࠨ毀"))[0]
	l111lll1l1_l1_ = l1l11l11l_l1_()
	#l111lll1l1_l1_ = l11lll_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠴࠴࠾࠴࠰࠯࠲࠱࠴࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠥࡋࡤࡨ࠱࠴࠴࠾࠴࠰࠯࠳࠸࠵࠽࠴࠷࠱ࠩ毁")
	l1l1ll1ll_l1_ = {l11lll_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ毂"):l111lll1l1_l1_,l11lll_l1_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ毃"):l11lll_l1_ (u"ࠨࡒࡕࡉࡋࡃࡨ࡭࠿ࡤࡶࠬ毄")}
	#l1l1ll1ll_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11lll_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ毅"))
	if data.count(l11lll_l1_ (u"ࠪ࠾࠿ࡀࠧ毆"))==4: l1lll11l1l11l_l1_,key,l1lll11l111ll_l1_,l1lll111l1l1l_l1_,token = data.split(l11lll_l1_ (u"ࠫ࠿ࡀ࠺ࠨ毇"))
	else: l1lll11l1l11l_l1_,key,l1lll11l111ll_l1_,l1lll111l1l1l_l1_,token = l11lll_l1_ (u"ࠬ࠭毈"),l11lll_l1_ (u"࠭ࠧ毉"),l11lll_l1_ (u"ࠧࠨ毊"),l11lll_l1_ (u"ࠨࠩ毋"),l11lll_l1_ (u"ࠩࠪ毌")
	l11llll11_l1_ = {l11lll_l1_ (u"ࠥࡧࡴࡴࡴࡦࡺࡷࠦ母"):{l11lll_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ毎"):{l11lll_l1_ (u"ࠧ࡮࡬ࠣ每"):l11lll_l1_ (u"ࠨࡡࡳࠤ毐"),l11lll_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ毑"):l11lll_l1_ (u"࡙ࠣࡈࡆࠧ毒"),l11lll_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ毓"):l1lll11l111ll_l1_}}}
	if url==l11ll1_l1_+l11lll_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ比") or l11lll_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ毕") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳ࡷ࡫ࡥ࡭࠱ࡵࡩࡪࡲ࡟ࡸࡣࡷࡧ࡭ࡥࡳࡦࡳࡸࡩࡳࡩࡥࠨ毖")+l11lll_l1_ (u"࠭࠿࡬ࡧࡼࡁࠬ毗")+key
		l11llll11_l1_[l11lll_l1_ (u"ࠧࡴࡧࡴࡹࡪࡴࡣࡦࡒࡤࡶࡦࡳࡳࠨ毘")] = l1lll11l1l11l_l1_
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭毙"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ毚"))
	elif l11lll_l1_ (u"ࠪ࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ毛") in url:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲࡫ࡺ࡯ࡤࡦࡁ࡮ࡩࡾࡃࠧ毜")+key
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ毝"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠴ࡴࡧࠫ毞"))
	elif l11lll_l1_ (u"ࠧ࡬ࡧࡼࡁࠬ毟") in url and l1lll11l1l11l_l1_:
		l11llll11_l1_[l11lll_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ毠")] = token
		l11llll11_l1_[l11lll_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ毡")][l11lll_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࠪ毢")][l11lll_l1_ (u"ࠫࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠩ毣")] = l1lll11l1l11l_l1_
		l11llll11_l1_ = str(l11llll11_l1_)
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ毤"),url,l11llll11_l1_,l1l1ll1ll_l1_,True,True,l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠵ࡶ࡫ࠫ毥"))
	elif l11lll_l1_ (u"ࠧࡤࡶࡲ࡯ࡪࡴ࠽ࠨ毦") in url and l1lll111l1l1l_l1_:
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱ࡓࡧ࡭ࡦࠩ毧"):l11lll_l1_ (u"ࠩ࠴ࠫ毨"),l11lll_l1_ (u"ࠪ࡜࠲࡟࡯ࡶࡖࡸࡦࡪ࠳ࡃ࡭࡫ࡨࡲࡹ࠳ࡖࡦࡴࡶ࡭ࡴࡴࠧ毩"):l1lll11l111ll_l1_})
		l1l1ll1ll_l1_.update({l11lll_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ毪"):l11lll_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࡀࠫ毫")+l1lll111l1l1l_l1_})
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ毬"),url,l11lll_l1_ (u"ࠧࠨ毭"),l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ毮"),l11lll_l1_ (u"ࠩࠪ毯"),l11lll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠺ࡺࡨࠨ毰"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ毱"),url,l11lll_l1_ (u"ࠬ࠭毲"),l1l1ll1ll_l1_,l11lll_l1_ (u"࠭ࠧ毳"),l11lll_l1_ (u"ࠧࠨ毴"),l11lll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠹ࡸ࡭࠭毵"))
	html = response.content
	tmp = re.findall(l11lll_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ毶"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡼࡥࡳࠤ࠱࠮ࡄࠨࡶࡢ࡮ࡸࡩࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ毷"),html,re.DOTALL|re.I)
	if tmp: l1lll11l111ll_l1_ = tmp[0]
	tmp = re.findall(l11lll_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ毸"),html,re.DOTALL|re.I)
	if tmp: l1lll11l1l11l_l1_ = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"ࠬࠨࡴࡰ࡭ࡨࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ毹"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ毺"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠢ࠻ࡽࠥࡸࡴࡱࡥ࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ毻"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ毼"),l11lll_l1_ (u"ࠩࠪ毽"),l11lll_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩ毾"),str(len(tmp)))
	#if tmp: l1lll11lll11l_l1_ = tmp[0]
	cookies = response.cookies
	if l11lll_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ毿") in list(cookies.keys()): l1lll111l1l1l_l1_ = cookies[l11lll_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ氀")]
	l11llll1l_l1_ = l1lll11l1l11l_l1_+l11lll_l1_ (u"࠭࠺࠻࠼ࠪ氁")+key+l11lll_l1_ (u"ࠧ࠻࠼࠽ࠫ氂")+l1lll11l111ll_l1_+l11lll_l1_ (u"ࠨ࠼࠽࠾ࠬ氃")+l1lll111l1l1l_l1_+l11lll_l1_ (u"ࠩ࠽࠾࠿࠭氄")+token
	if request==l11lll_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ氅") and l11lll_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠫ氆") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡡࡡࠢࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠢ࡝࡟ࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ氇"),html,re.DOTALL)
		if not l111ll1ll1_l1_: l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ氈"),html,re.DOTALL)
		l1lll1111l1ll_l1_ = EVAL(l11lll_l1_ (u"ࠧࡴࡶࡵࠫ氉"),l111ll1ll1_l1_[0])
	elif request==l11lll_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭氊") and l11lll_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠧ氋") in html:
		l111ll1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ氌"),html,re.DOTALL)
		l1lll1111l1ll_l1_ = EVAL(l11lll_l1_ (u"ࠫࡸࡺࡲࠨ氍"),l111ll1ll1_l1_[0])
	elif l11lll_l1_ (u"ࠬࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ氎") not in html: l1lll1111l1ll_l1_ = EVAL(l11lll_l1_ (u"࠭ࡳࡵࡴࠪ氏"),html)
	else: l1lll1111l1ll_l1_ = l11lll_l1_ (u"ࠧࠨ氐")
	if 0:
		cc = str(l1lll1111l1ll_l1_)
		if kodi_version>18.99: cc = cc.encode(l11lll_l1_ (u"ࠨࡷࡷࡪ࠽࠭民"))
		open(l11lll_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡦࡤࡸࠬ氒"),l11lll_l1_ (u"ࠪࡻࡧ࠭氓")).write(cc)
		#open(l11lll_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ气"),l11lll_l1_ (u"ࠬࡽࠧ氕")).write(html)
	settings.setSetting(l11lll_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ氖"),l11llll1l_l1_)
	return html,l1lll1111l1ll_l1_,l11llll1l_l1_
def l1lll11ll1ll1_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11lll_l1_ (u"ࠧࠡࠩ気"),l11lll_l1_ (u"ࠨ࠭ࠪ氘"))
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ氙")+search
	l1111l_l1_(l11l11l_l1_,index)
	return
def SEARCH(search):
	#search = l11lll_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ氚")+l11lll_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࠩ氛")+l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ氜")+l11lll_l1_ (u"࠭࡟ࠨ氝")+search
	#DIALOG_OK(l11lll_l1_ (u"ࠧࠨ氞"),l11lll_l1_ (u"ࠨࠩ氟"),l11lll_l1_ (u"ࠩࠪ氠"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ氡"),l11lll_l1_ (u"ࠫࠬ氢"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ氣"),l11lll_l1_ (u"࠭ࠫࠨ氤"))
	l11l11l_l1_ = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ氥")+search
	if not l1ll_l1_:
		if l11lll_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ氦") in options: l1lll111l1lll_l1_ = l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ氧")
		elif l11lll_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ氨") in options: l1lll111l1lll_l1_ = l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ氩")
		elif l11lll_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ氪") in options: l1lll111l1lll_l1_ = l11lll_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭氫")
		else: l1lll111l1lll_l1_ = l11lll_l1_ (u"ࠧࠨ氬")
		l11l1l1_l1_ = l11l11l_l1_+l1lll111l1lll_l1_
	else:
		l1lll111l1ll1_l1_,l1lll11111lll_l1_,l1lll1lll_l1_ = [],[],l11lll_l1_ (u"ࠨࠩ氭")
		l1lll1111l11l_l1_ = [l11lll_l1_ (u"ࠩหำํ์ࠠหำอ๎อ࠭氮"),l11lll_l1_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ氯"),l11lll_l1_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ氰"),l11lll_l1_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ氱"),l11lll_l1_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ氲")]
		l1lll11l1lll1_l1_ = [l11lll_l1_ (u"ࠧࠨ氳"),l11lll_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ水"),l11lll_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ氵"),l11lll_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ氶"),l11lll_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ氷")]
		l1lll11ll11ll_l1_ = DIALOG_SELECT(l11lll_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้ะัห์หࠫ永"),l1lll1111l11l_l1_)
		if l1lll11ll11ll_l1_ == -1: return
		l1lll111l1l11_l1_ = l1lll11l1lll1_l1_[l1lll11ll11ll_l1_]
		html,c,data = l1lll111lll1l_l1_(l11l11l_l1_+l1lll111l1l11_l1_)
		if c:
			try:
				d = c[l11lll_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ氹")][l11lll_l1_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ氺")][l11lll_l1_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ氻")][l11lll_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ氼")][l11lll_l1_ (u"ࠪࡷࡺࡨࡍࡦࡰࡸࠫ氽")][l11lll_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬ氾")][l11lll_l1_ (u"ࠬ࡭ࡲࡰࡷࡳࡷࠬ氿")]
				for l1lll11111ll1_l1_ in range(len(d)):
					group = d[l1lll11111ll1_l1_][l11lll_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡌࡸ࡯ࡶࡲࡕࡩࡳࡪࡥࡳࡧࡵࠫ汀")][l11lll_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ汁")]
					for l1lll11ll1lll_l1_ in range(len(group)):
						render = group[l1lll11ll1lll_l1_][l11lll_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ求")]
						if l11lll_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ汃") in list(render.keys()):
							link = render[l11lll_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ汄")][l11lll_l1_ (u"ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭汅")][l11lll_l1_ (u"ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ汆")][l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ汇")]
							link = link.replace(l11lll_l1_ (u"ࠧ࡝ࡷ࠳࠴࠷࠼ࠧ汈"),l11lll_l1_ (u"ࠨࠨࠪ汉"))
							title = render[l11lll_l1_ (u"ࠩࡷࡳࡴࡲࡴࡪࡲࠪ汊")]
							title = title.replace(l11lll_l1_ (u"ࠪห้ฮอฬࠢ฼๊ࠥ࠭汋"),l11lll_l1_ (u"ࠫࠬ汌"))
							if l11lll_l1_ (u"ࠬหาศๆฬࠤฬ๊แๅฬิࠫ汍") in title: continue
							if l11lll_l1_ (u"࠭โศศ่อࠥะิ฻์็ࠫ汎") in title:
								title = l11lll_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ汏")+title
								l1lll1lll_l1_ = title
								l1lllllll1_l1_ = link
							if l11lll_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠫ汐") in title: continue
							title = title.replace(l11lll_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࠦࠧ汑"),l11lll_l1_ (u"ࠪࠫ汒"))
							if l11lll_l1_ (u"ࠫࡗ࡫࡭ࡰࡸࡨࠫ汓") in title: continue
							if l11lll_l1_ (u"ࠬࡖ࡬ࡢࡻ࡯࡭ࡸࡺࠧ汔") in title:
								title = l11lll_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ汕")+title
								l1lll1lll_l1_ = title
								l1lllllll1_l1_ = link
							if l11lll_l1_ (u"ࠧࡔࡱࡵࡸࠥࡨࡹࠨ汖") in title: continue
							l1lll111l1ll1_l1_.append(escapeUNICODE(title))
							l1lll11111lll_l1_.append(link)
			except: pass
		if not l1lll1lll_l1_: l1lll11l1l1ll_l1_ = l11lll_l1_ (u"ࠨࠩ汗")
		else:
			l1lll111l1ll1_l1_ = [l11lll_l1_ (u"ࠩหำํ์ࠠโๆอีࠬ汘"),l1lll1lll_l1_]+l1lll111l1ll1_l1_
			l1lll11111lll_l1_ = [l11lll_l1_ (u"ࠪࠫ汙"),l1lllllll1_l1_]+l1lll11111lll_l1_
			l1lll11ll1l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ๆ๊สาࠩ汚"),l1lll111l1ll1_l1_)
			if l1lll11ll1l1l_l1_ == -1: return
			l1lll11l1l1ll_l1_ = l1lll11111lll_l1_[l1lll11ll1l1l_l1_]
		if l1lll11l1l1ll_l1_: l11l1l1_l1_ = l11ll1_l1_+l1lll11l1l1ll_l1_
		elif l1lll111l1l11_l1_: l11l1l1_l1_ = l11l11l_l1_+l1lll111l1l11_l1_
		else: l11l1l1_l1_ = l11l11l_l1_
		l11lll_l1_ (u"ࠧࠨࠢࠋࠋࠌࡩࡱࡹࡥ࠻ࠌࠌࠍࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡪ࡮ࡲࡴࡦࡴ࠰ࡨࡷࡵࡰࡥࡱࡺࡲ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡸࡪࡳ࠭ࡴࡧࡦࡸ࡮ࡵ࡮ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠍࠎ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࠏࡩࡧࠢࠪࡖࡪࡳ࡯ࡷࡧࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠬ࠲ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡲࡶࡹࠦࡢࡺࠩ࠯ࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠣࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭ࠫࡵ࡫ࡷࡰࡪࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠࡺ࠶࠰࠳࠸ࠪ࠰ࠬࠬࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸ࠺ࠡࠢࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡩࡷࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫࠬࠎࠎࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࠉࡪࡨࠣࠫࡘࡵࡲࡵࠢࡥࡽ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡲࡶࡹ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡴࡪࡶ࡯ࡩ࠮࠯ࠊࠊࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࠢࠣࠤ汛")
	#DIALOG_OK()
	l1111l_l1_(l11l1l1_l1_)
	return
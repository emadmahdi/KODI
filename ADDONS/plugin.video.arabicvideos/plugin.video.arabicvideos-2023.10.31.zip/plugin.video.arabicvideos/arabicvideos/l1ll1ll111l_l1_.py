# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ⡚")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡆࡉࡑࡣࠬ⡛")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ฺࠧำฺ๋๋ࠥีศำ฼อࠬ⡜"),l11lll_l1_ (u"ࠨษ็็้࠭⡝"),l11lll_l1_ (u"ࠩࡱ࠳ࡆ࠭⡞"),l11lll_l1_ (u"ࠪห้๋า๋ัࠪ⡟"),l11lll_l1_ (u"ࠫ็฻ษࠡ฻ืๆࠬ⡠")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l1111l_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l1llllll_l1_(url)
	elif mode==434: results = l1lll1l1_l1_(url,l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫ⡡")+text)
	elif mode==435: results = l1lll1l1_l1_(url,l11lll_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ⡢")+text)
	elif mode==436: results = l1l11l_l1_(url)
	elif mode==437: results = l111111l1_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⡣"),l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨ⡤"),l11lll_l1_ (u"ࠩࠪ⡥"),l11lll_l1_ (u"ࠪࠫ⡦"),l11lll_l1_ (u"ࠫࠬ⡧"),l11lll_l1_ (u"ࠬ࠭⡨"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⡩"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡲࡴࡴࡩࡤࡣ࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⡪"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠨ࠱ࠪ⡫"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭⡬"))
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡭"),l111ll_l1_+l11lll_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⡮"),l11lll_l1_ (u"ࠬ࠭⡯"),439,l11lll_l1_ (u"࠭ࠧ⡰"),l11lll_l1_ (u"ࠧࠨ⡱"),l11lll_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⡲"))
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⡳"),l111ll_l1_+l11lll_l1_ (u"ࠪๅ้ะัࠡ็ะำิ࠭⡴"),l1ll1l1_l1_,435)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⡵"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ⡶"),l1ll1l1_l1_,434)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⡷"),l11lll_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⡸"),l11lll_l1_ (u"ࠨࠩ⡹"),9999)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⡺"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⡻")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ๅืษไࠤาี๊ฬษࠪ⡼"),l1ll1l1_l1_,431)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⡽"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⡾")+l111ll_l1_+l11lll_l1_ (u"ࠧศใ็ห๊ࠦว้่่ࠣฬ๐ๆࠨ⡿"),l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳ࠲ࠩ⢀"),436)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⢁"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⢂")+l111ll_l1_+l11lll_l1_ (u"ู๊ࠫไิๆสฮࠥอ่็ࠢ็ห๏์ࠧ⢃"),l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠳ࡡ࡭࡮࠴ࠫ⢄"),436)
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢅"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⢆")+l111ll_l1_+l11lll_l1_ (u"ࠨไสส๊ฯࠠหใุ๎้๐ษࠨ⢇"),l1ll1l1_l1_,437)
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⢈"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⢉"),l11lll_l1_ (u"ࠫࠬ⢊"),9999)
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢋"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⢌")+l111ll_l1_+l11lll_l1_ (u"ࠧศๆ่้๏ุษࠨ⢍"),l1ll1l1_l1_,431,l11lll_l1_ (u"ࠨࠩ⢎"),l11lll_l1_ (u"ࠩࠪ⢏"),l11lll_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ⢐"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⢑"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⢒")+l111ll_l1_+l11lll_l1_ (u"࠭รโๆส้ࠬ⢓"),l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡹ࠯ࠨ⢔"),436)
	#addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⢕"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⢖")+l111ll_l1_+l11lll_l1_ (u"ุ้๊ࠪำๅษอࠫ⢗"),l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲࠷࠯ࠨ⢘"),436)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡪࡶࡨࡒࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡵࡧ࡭ࠨࠧ⢙"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⢚"),block,re.DOTALL)
	for link,title in items:
		#if title==l11lll_l1_ (u"ࠧศๆิส๏ู๊สࠩ⢛"): title = l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ⢜")
		if title in l1l1l1_l1_: continue
		if title==l11lll_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ⢝"): continue
		if l11lll_l1_ (u"ࠪหํ์ࠠๅษํ๊ࠬ⢞") in title: continue
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⢟"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⢠")+l111ll_l1_+title,link,431)
	return
def l111111l1_l1_(l1l1ll11_l1_=l11lll_l1_ (u"࠭ࠧ⢡")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⢢"),l1l1ll11_l1_+l11lll_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨ⢣"),l11lll_l1_ (u"ࠩࠪ⢤"),l11lll_l1_ (u"ࠪࠫ⢥"),l11lll_l1_ (u"ࠫࠬ⢦"),l11lll_l1_ (u"ࠬ࠭⢧"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⢨"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡥࡤࡲࡴࡴࡩࡤࡣ࡯ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⢩"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠨ࠱ࠪ⢪"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭⢫"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡑ࡯ࡳࡵࡆࡵࡳࡵ࡫ࡤࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡶࡨ࡮ࡩ࡯ࡩࡐࡥࡸࡺࡥࡳࠤࠪ⢬"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡥࡽࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⢭"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1l1l1_l1_: continue
		link = l1l1ll11_l1_+l11lll_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࠩ⢮")+category+l11lll_l1_ (u"࠭࠽ࠨ⢯")+value
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⢰"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⢱")+l111ll_l1_+title,link,431)
	return
def l1l11l_l1_(url):
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ⢲"),l11lll_l1_ (u"ࠪࠫ⢳"),l11lll_l1_ (u"ࠫࡘ࡛ࡂࡎࡇࡑ࡙ࠬ⢴"),url)
	#LOG_THIS(l11lll_l1_ (u"ࠬ࠭⢵"),link)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⢶"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ⢷"),url,l11lll_l1_ (u"ࠨࠩ⢸"),l11lll_l1_ (u"ࠩࠪ⢹"),l11lll_l1_ (u"ࠪࠫ⢺"),l11lll_l1_ (u"ࠫࠬ⢻"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⢼"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⢽"),l111ll_l1_+l11lll_l1_ (u"ࠧศๆฯ้๏฿ࠧ⢾"),url,431)
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡄࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨ⢿"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨ⣀"),block,re.DOTALL)
	for l1111l111_l1_,title in items:
		if title in l1l1l1_l1_: continue
		l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡑࡴࡼࡩࡦࡵ࠲ࡏࡪࡿࡳ࠯ࡲ࡫ࡴࡄࡱࡥࡺ࠿ࠪ⣁")+l1111l111_l1_
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⣂"),l111ll_l1_+title,l11l11l_l1_,431)
	#addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⣃"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⣄"),l11lll_l1_ (u"ࠧࠨ⣅"),9999)
	#l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡌࡲࡳ࡫ࡲࡑࡣࡪࡩࡋ࡯࡬ࡵࡧࡵࠦ࠭࠴ࠪࡀࠫࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠨ⣆"),html,re.DOTALL)
	#block = l1l1ll1_l1_[0]
	#items = re.findall(l11lll_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ⣇"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1l1l1_l1_: continue
	#	if l11lll_l1_ (u"ࠪ࠳࡫࡯࡬࡮ࡵ࠲ࠫ⣈") in url: l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡒࡵࡶࡪࡧࡶ࠳࡙࡫ࡲ࡮ࡵ࠱ࡴ࡭ࡶ࠿ࠨ⣉")+category+l11lll_l1_ (u"ࠬࡃࠧ⣊")+value
	#	elif l11lll_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠭ࠨ⣋") in url: l11l11l_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡋࡧࡺࡐࡲࡻࡇࡿࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠰ࡃ࡭ࡥࡽࡺ࠯ࡔࡧࡵ࡭ࡪࡹ࠯ࡈࡧࡷ࠲ࡵ࡮ࡰࡀࠩ⣌")+category+l11lll_l1_ (u"ࠨ࠿ࠪ⣍")+value
	#	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣎"),l111ll_l1_+title,l11l11l_l1_,431)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠪࠫ⣏")):
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⣐"),l11lll_l1_ (u"ࠬ࠭⣑"),request,url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"࠭ࡵࡳ࡮ࠪ⣒"))
	items = []
	if l11lll_l1_ (u"ࠧ࠰ࡖࡨࡶࡲࡹ࠮ࡱࡪࡳࠫ⣓") in url or l11lll_l1_ (u"ࠨ࠱ࡊࡩࡹ࠴ࡰࡩࡲࠪ⣔") in url or l11lll_l1_ (u"ࠩ࠲ࡏࡪࡿࡳ࠯ࡲ࡫ࡴࠬ⣕") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭⣖"):l11lll_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ⣗"),l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⣘"):l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭⣙")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠧࡑࡑࡖࡘࠬ⣚"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠨࠩ⣛"),l11lll_l1_ (u"ࠩࠪ⣜"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⣝"))
		html = response.content
		block = html
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⣞"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ⣟"),url,l11lll_l1_ (u"࠭ࠧ⣠"),l11lll_l1_ (u"ࠧࠨ⣡"),l11lll_l1_ (u"ࠨࠩ⣢"),l11lll_l1_ (u"ࠩࠪ⣣"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⣤"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡓࡡࡪࡰࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡏࡤࡸࡨ࡮ࡥࡴࡖࡤࡦࡱ࡫ࠢࠨ⣥"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࠢࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩࠨ⣦"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⣧"),url,l11lll_l1_ (u"ࠧࠨ⣨"),l11lll_l1_ (u"ࠨࠩ⣩"),l11lll_l1_ (u"ࠩࠪ⣪"),l11lll_l1_ (u"ࠪࠫ⣫"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ⣬"))
		html = response.content
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡂ࡭ࡱࡦ࡯ࡸࡒࡩࡴࡶࠥࠬ࠳࠰࠿ࠪࠤࡓࡥ࡬࡯࡮ࡢࡶࡨࠦࠬ⣭"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡃ࡮ࡲࡧࡰࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࡅࡲࡲࠧ࠭⣮"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡬ࡱࡦ࡭ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⣯"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ࠨ็ืห์ีษࠨ⣰"),l11lll_l1_ (u"ࠩไ๎้๋ࠧ⣱"),l11lll_l1_ (u"ࠪห฿์๊สࠩ⣲"),l11lll_l1_ (u"่๊๊ࠫษࠩ⣳"),l11lll_l1_ (u"ࠬอูๅษ้ࠫ⣴"),l11lll_l1_ (u"࠭็ะษไࠫ⣵"),l11lll_l1_ (u"ࠧๆสสีฬฯࠧ⣶"),l11lll_l1_ (u"ࠨ฻ิฺࠬ⣷"),l11lll_l1_ (u"่๋ࠩึาว็ࠩ⣸"),l11lll_l1_ (u"ࠪห้ฮ่ๆࠩ⣹")]
	for link,title,l1llll_l1_ in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠫ࠴࠭⣺"))
		#link = unescapeHTML(link)
		title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠬࠦࠧ⣻"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ⣼"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⣽"),l111ll_l1_+title,link,432,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠨษ็ั้่ษࠨ⣾") in title:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⣿") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⤀"),l111ll_l1_+title,link,433,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⤁") in link:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤂"),l111ll_l1_+title,link,431,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⤃"),l111ll_l1_+title,link,433,l1llll_l1_)
	if request!=l11lll_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ⤄"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡓࡥ࡬࡯࡮ࡢࡶࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⤅"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⤆"),block,re.DOTALL)
			for link,title in items:
				if l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⤇") not in link: link = l1ll1l1_l1_+link
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				if title!=l11lll_l1_ (u"ࠫࠬ⤈"): addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⤉"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ⤊")+title,link,431)
		l11111l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⤋"),html,re.DOTALL)
		if l11111l11_l1_:
			link = l11111l11_l1_[0]
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⤌"),l111ll_l1_+l11lll_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะࠩ⤍"),link,431)
	return
def l1llllll_l1_(url):
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫ⤎"),l11lll_l1_ (u"ࠫ࠶࠷࠱࠲ࠢࠣࠫ⤏")+url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ⤐"))
	l1l1l11_l1_,l1l11ll_l1_ = [],[]
	if l11lll_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠯ࡲ࡫ࡴࠬ⤑") in url:
		l11l11l_l1_,l11llll11_l1_ = l1llll11ll_l1_(url)
		l1l1ll1ll_l1_ = {l11lll_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ⤒"):l11lll_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ⤓"),l11lll_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⤔"):l11lll_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ⤕")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠫࡕࡕࡓࡕࠩ⤖"),l11l11l_l1_,l11llll11_l1_,l1l1ll1ll_l1_,l11lll_l1_ (u"ࠬ࠭⤗"),l11lll_l1_ (u"࠭ࠧ⤘"),l11lll_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⤙"))
		html = response.content
		l1l11ll_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ⤚"),url,l11lll_l1_ (u"ࠩࠪ⤛"),l11lll_l1_ (u"ࠪࠫ⤜"),l11lll_l1_ (u"ࠫࠬ⤝"),l11lll_l1_ (u"ࠬ࠭⤞"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ⤟"))
		html = response.content
		l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⤠"),html,re.DOTALL)
		l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⤡"),html,re.DOTALL)
	# l1lllll_l1_
	if l1l1l11_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡳ࡬ࡀࡩ࡮ࡣࡪࡩࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⤢"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡥࡢࡵࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭⤣"),block,re.DOTALL)
		for post,l1ll1l1llll_l1_,title in items:
			link = l1ll1l1_l1_+l11lll_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡈ࡫ࡾࡔ࡯ࡸࡄࡼࡉࡱࡹࡨࡢ࡫࡮࡬࠴ࡇࡪࡢࡺࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰࡩࡲࡂࠫ⤤")+l11lll_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࡂ࠭⤥")+l1ll1l1llll_l1_+l11lll_l1_ (u"࠭ࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ⤦")+post
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⤧"),l111ll_l1_+title,link,433,l1llll_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡭ࡻ࡭ࡣࠩ⤨"))
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭⤩"),block,re.DOTALL)
		for link,title,l1lll11_l1_ in items:
			title = title+l11lll_l1_ (u"ࠪࠤࠬ⤪")+l1lll11_l1_
			addMenuItem(l11lll_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⤫"),l111ll_l1_+title,link,432,l1llll_l1_)
	return
def PLAY(url):
	l11l11l_l1_ = url+l11lll_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭⤬")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ⤭"),l11l11l_l1_,l11lll_l1_ (u"ࠧࠨ⤮"),l11lll_l1_ (u"ࠨࠩ⤯"),l11lll_l1_ (u"ࠩࠪ⤰"),l11lll_l1_ (u"ࠪࠫ⤱"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⤲"))
	html = response.content
	l1111_l1_ = []
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩ⤳"))
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡷࡪࡸࡶࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⤴"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l1ll1llll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⤵"),block,re.DOTALL)
		if l1ll1llll1_l1_:
			l1ll1llll1_l1_ = l1ll1llll1_l1_[0]
			#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⤶"),l11lll_l1_ (u"ࠩࠪ⤷"),l11lll_l1_ (u"ࠪࠫ⤸"),l1ll1llll1_l1_)
			items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ⤹"),block,re.DOTALL)
			for server,title in items:
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡩ࡯ࡩ࡯ࡩ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࡁࡶࡩࡷࡼࡥࡳ࠿ࠪ⤺")+server+l11lll_l1_ (u"࠭ࠦࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ⤻")+l1ll1llll1_l1_+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⤼")+title+l11lll_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⤽")
				l1111_l1_.append(link)
	# l1l11llll_l1_ link
	l1l11llll_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡩࡧࡴࡤࡱࡪࠨ࠾࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⤾"),html,re.DOTALL)
	if l1l11llll_l1_:
		l1l11llll_l1_ = l1l11llll_l1_[0].replace(l11lll_l1_ (u"ࠪࡠࡳ࠭⤿"),l11lll_l1_ (u"ࠫࠬ⥀"))
		title = SERVER(l1l11llll_l1_,l11lll_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⥁"))
		link = l1l11llll_l1_+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⥂")+title+l11lll_l1_ (u"ࠧࡠࡡࡨࡱࡧ࡫ࡤࠨ⥃")
		l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⥄"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⥅"),block,re.DOTALL)
		for link,title,l11l111l_l1_ in items:
			link = link.replace(l11lll_l1_ (u"ࠪࡠࡳ࠭⥆"),l11lll_l1_ (u"ࠫࠬ⥇"))
			if l11l111l_l1_!=l11lll_l1_ (u"ࠬ࠭⥈"): l11l111l_l1_ = l11lll_l1_ (u"࠭࡟ࡠࡡࡢࠫ⥉")+l11l111l_l1_
			link = link+l11lll_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⥊")+title+l11lll_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ⥋")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⥌"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⥍"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠫࠬ⥎"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠬ࠭⥏"): return
	search = search.replace(l11lll_l1_ (u"࠭ࠠࠨ⥐"),l11lll_l1_ (u"ࠧࠦ࠴࠳ࠫ⥑"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⥒")+search
	l1111l_l1_(url)
	return
# ===========================================
#     l11111lll_l1_ l1lllll1l1_l1_ l1llll1lll_l1_
# ===========================================
def l11111ll1_l1_(url):
	url = url.split(l11lll_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⥓"))[0]
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠪࡹࡷࡲࠧ⥔"))
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠫࡌࡋࡔࠨ⥕"),l1ll1l1_l1_,l11lll_l1_ (u"ࠬ࠭⥖"),l11lll_l1_ (u"࠭ࠧ⥗"),l11lll_l1_ (u"ࠧࠨ⥘"),l11lll_l1_ (u"ࠨࠩ⥙"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ⥚"))
	html = response.content
	# all l111l11_l1_
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠬࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡣࡷࡷࡸࡴࡴࠢ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬࡮ࡴࡧࡎࡣࡶࡸࡪࡸࠢࠨ⥛"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	# name + options block + category
	l1lll11l_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡣࡷࡷࡸࡴࡴࠢ࠯ࠬࡂࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠬ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡥ࡫ࡹࡂ࠮࠭⥜"),block,re.DOTALL)
	return l1lll11l_l1_
def l1lllll1ll_l1_(block):
	# value + name
	items = re.findall(l11lll_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫࡠࡩ࠱ࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⥝"),block,re.DOTALL)
	return items
def l111111ll_l1_(url):
	#url = url.replace(l11lll_l1_ (u"࠭ࡣࡢࡶࡀࠫ⥞"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺ࠿ࠪ⥟"))
	l1llllll1l_l1_ = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⥠"))[0]
	l1llllll11_l1_ = SERVER(url,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭⥡"))
	url = url.replace(l1llllll1l_l1_,l1llllll11_l1_)
	url = url.replace(l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⥢"),l11lll_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࠨ⥣"))
	return url
def l1ll1ll1111_l1_(l1l1llll_l1_,url):
	l1l1111l_l1_ = l1l111l1_l1_(l1l1llll_l1_,l11lll_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⥤")) # l1llllll1l1_l1_ be l1llllllll1_l1_
	l11l1l1_l1_ = url+l11lll_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⥥")+l1l1111l_l1_
	l11l1l1_l1_ = l111111ll_l1_(l11l1l1_l1_)
	return l11l1l1_l1_
l1l11lll_l1_ = [l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⥦"),l11lll_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ⥧"),l11lll_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ⥨"),l11lll_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ⥩")]
l1ll11ll_l1_ = [l11lll_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ⥪"),l11lll_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ⥫"),l11lll_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ⥬"),l11lll_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⥭"),l11lll_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ⥮"),l11lll_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ⥯")]
def l1lll1l1_l1_(url,filter):
	#filter = filter.replace(l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⥰"),l11lll_l1_ (u"ࠫࠬ⥱"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⥲"),l11lll_l1_ (u"࠭ࠧ⥳"),filter,url)
	if l11lll_l1_ (u"ࠧࡀࠩ⥴") in url: url = url.split(l11lll_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⥵"))[0]
	type,filter = filter.split(l11lll_l1_ (u"ࠩࡢࡣࡤ࠭⥶"),1)
	if filter==l11lll_l1_ (u"ࠪࠫ⥷"): l1l11l1l_l1_,l1l11l11_l1_ = l11lll_l1_ (u"ࠫࠬ⥸"),l11lll_l1_ (u"ࠬ࠭⥹")
	else: l1l11l1l_l1_,l1l11l11_l1_ = filter.split(l11lll_l1_ (u"࠭࡟ࡠࡡࠪ⥺"))
	if type==l11lll_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࠪ⥻"):
		if l1l11lll_l1_[0]+l11lll_l1_ (u"ࠨ࠿ࠪ⥼") not in l1l11l1l_l1_: category = l1l11lll_l1_[0]
		for i in range(len(l1l11lll_l1_[0:-1])):
			if l1l11lll_l1_[i]+l11lll_l1_ (u"ࠩࡀࠫ⥽") in l1l11l1l_l1_: category = l1l11lll_l1_[i+1]
		l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ⥾")+category+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⥿")
		l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧ⦀")+category+l11lll_l1_ (u"࠭࠽࠱ࠩ⦁")
		l1l1l11l_l1_ = l1ll11l1_l1_.strip(l11lll_l1_ (u"ࠧࠧࠩ⦂"))+l11lll_l1_ (u"ࠨࡡࡢࡣࠬ⦃")+l1l1llll_l1_.strip(l11lll_l1_ (u"ࠩࠩࠫ⦄"))
		l1l1111l_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⦅")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11l11l_l1_ = url+l11lll_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⦆")+l1l1111l_l1_
	elif type==l11lll_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨ⦇"):
		l11lll11_l1_ = l1l111l1_l1_(l1l11l1l_l1_,l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ⦈")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		l11lll11_l1_ = l111l_l1_(l11lll11_l1_)
		if l1l11l11_l1_!=l11lll_l1_ (u"ࠧࠨ⦉"): l1l11l11_l1_ = l1l111l1_l1_(l1l11l11_l1_,l11lll_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⦊")) # l1llllll11l_l1_ l1111l11l1_l1_ not l11l1111ll_l1_
		if l1l11l11_l1_==l11lll_l1_ (u"ࠩࠪ⦋"): l11l11l_l1_ = url
		else: l11l11l_l1_ = url+l11lll_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ⦌")+l1l11l11_l1_
		l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
		addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⦍"),l111ll_l1_+l11lll_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ⦎"),l11l11l_l1_,431)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⦏"),l111ll_l1_+l11lll_l1_ (u"ࠧࠡ࡝࡞ࠤࠥࠦࠧ⦐")+l11lll11_l1_+l11lll_l1_ (u"ࠨࠢࠣࠤࡢࡣࠧ⦑"),l11l11l_l1_,431)
		addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⦒"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⦓"),l11lll_l1_ (u"ࠫࠬ⦔"),9999)
	l1lll11l_l1_ = l11111ll1_l1_(url)
	dict = {}
	for name,block,l1ll1lll_l1_ in l1lll11l_l1_:
		name = name.replace(l11lll_l1_ (u"ࠬ࠳࠭ࠨ⦕"),l11lll_l1_ (u"࠭ࠧ⦖"))
		items = l1lllll1ll_l1_(block)
		if l11lll_l1_ (u"ࠧ࠾ࠩ⦗") not in l11l11l_l1_: l11l11l_l1_ = url
		if type==l11lll_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ⦘"):
			if category!=l1ll1lll_l1_: continue
			elif len(items)<2:
				if l1ll1lll_l1_==l1l11lll_l1_[-1]:
					url = l111111ll_l1_(url)
					l1111l_l1_(url)
				else: l1lll1l1_l1_(l11l11l_l1_,l11lll_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨ⦙")+l1l1l11l_l1_)
				return
			else:
				l11l11l_l1_ = l111111ll_l1_(l11l11l_l1_)
				if l1ll1lll_l1_==l1l11lll_l1_[-1]: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦚"),l111ll_l1_+l11lll_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ⦛"),l11l11l_l1_,431)
				else: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⦜"),l111ll_l1_+l11lll_l1_ (u"࠭วๅฮ่๎฾ࠦࠧ⦝"),l11l11l_l1_,435,l11lll_l1_ (u"ࠧࠨ⦞"),l11lll_l1_ (u"ࠨࠩ⦟"),l1l1l11l_l1_)
		elif type==l11lll_l1_ (u"ࠩࡄࡐࡑࡥࡉࡕࡇࡐࡗࡤࡌࡉࡍࡖࡈࡖࠬ⦠"):
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠪࠪࠬ⦡")+l1ll1lll_l1_+l11lll_l1_ (u"ࠫࡂ࠶ࠧ⦢")
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠬࠬࠧ⦣")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽࠱ࠩ⦤")
			l1l1l11l_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠧࡠࡡࡢࠫ⦥")+l1l1llll_l1_
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⦦"),l111ll_l1_+l11lll_l1_ (u"ࠩส่ัฺ๋๊ࠢ࠽ࠫ⦧")+name,l11l11l_l1_,434,l11lll_l1_ (u"ࠪࠫ⦨"),l11lll_l1_ (u"ࠫࠬ⦩"),l1l1l11l_l1_)		# +l11lll_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ⦪"))
		dict[l1ll1lll_l1_] = {}
		for value,option in items:
			if value==l11lll_l1_ (u"࠭࠱࠺࠸࠸࠷࠸࠭⦫"): option = l11lll_l1_ (u"ࠧฤใ็ห๊ࠦๆ๋ฬไู่่ࠧ⦬")
			elif value==l11lll_l1_ (u"ࠨ࠳࠼࠺࠺࠹࠱ࠨ⦭"): option = l11lll_l1_ (u"่ࠩืู้ไศฬ๊ࠣ๏ะแๅๅึࠫ⦮")
			if option in l1l1l1_l1_: continue
			#if l11lll_l1_ (u"ࠪࡺࡦࡲࡵࡦࠩ⦯") not in value: value = option
			#else: value = re.findall(l11lll_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬ⦰"),value,re.DOTALL)[0]
			dict[l1ll1lll_l1_][value] = option
			l1ll11l1_l1_ = l1l11l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ⦱")+l1ll1lll_l1_+l11lll_l1_ (u"࠭࠽ࠨ⦲")+option
			l1l1llll_l1_ = l1l11l11_l1_+l11lll_l1_ (u"ࠧࠧࠩ⦳")+l1ll1lll_l1_+l11lll_l1_ (u"ࠨ࠿ࠪ⦴")+value
			l1ll1ll1_l1_ = l1ll11l1_l1_+l11lll_l1_ (u"ࠩࡢࡣࡤ࠭⦵")+l1l1llll_l1_
			title = option+l11lll_l1_ (u"ࠪࠤ࠿࠭⦶")#+dict[l1ll1lll_l1_][l11lll_l1_ (u"ࠫ࠵࠭⦷")]
			title = option+l11lll_l1_ (u"ࠬࠦ࠺ࠨ⦸")+name
			if type==l11lll_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩ⦹"): addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⦺"),l111ll_l1_+title,url,434,l11lll_l1_ (u"ࠨࠩ⦻"),l11lll_l1_ (u"ࠩࠪ⦼"),l1ll1ll1_l1_)		# +l11lll_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⦽"))
			elif type==l11lll_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘࠧ⦾") and l1l11lll_l1_[-2]+l11lll_l1_ (u"ࠬࡃࠧ⦿") in l1l11l1l_l1_:
				l11l1l1_l1_ = l1ll1ll1111_l1_(l1l1llll_l1_,url)
				addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧀"),l111ll_l1_+title,l11l1l1_l1_,431)
			else: addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧁"),l111ll_l1_+title,url,435,l11lll_l1_ (u"ࠨࠩ⧂"),l11lll_l1_ (u"ࠩࠪ⧃"),l1ll1ll1_l1_)
	return
def l1l111l1_l1_(filters,mode):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⧄"),l11lll_l1_ (u"ࠫࠬ⧅"),filters,l11lll_l1_ (u"ࠬࡘࡅࡄࡑࡑࡗ࡙ࡘࡕࡄࡖࡢࡊࡎࡒࡔࡆࡔࠣ࠵࠶࠭⧆"))
	# mode==l11lll_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ⧇")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ values
	# mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⧈")		l1ll1111_l1_ l1l1l1ll_l1_ l1l1ll1l_l1_ filters
	# mode==l11lll_l1_ (u"ࠨࡣ࡯ࡰࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⧉")			all l1l1ll1l_l1_ & l11111l1l_l1_ filters
	filters = filters.replace(l11lll_l1_ (u"ࠩࡀࠪࠬ⧊"),l11lll_l1_ (u"ࠪࡁ࠵ࠬࠧ⧋"))
	filters = filters.strip(l11lll_l1_ (u"ࠫࠫ࠭⧌"))
	l1l11ll1_l1_ = {}
	if l11lll_l1_ (u"ࠬࡃࠧ⧍") in filters:
		items = filters.split(l11lll_l1_ (u"࠭ࠦࠨ⧎"))
		for item in items:
			var,value = item.split(l11lll_l1_ (u"ࠧ࠾ࠩ⧏"))
			l1l11ll1_l1_[var] = value
	l1ll1l1l_l1_ = l11lll_l1_ (u"ࠨࠩ⧐")
	for key in l1ll11ll_l1_:
		if key in list(l1l11ll1_l1_.keys()): value = l1l11ll1_l1_[key]
		else: value = l11lll_l1_ (u"ࠩ࠳ࠫ⧑")
		if l11lll_l1_ (u"ࠪࠩࠬ⧒") not in value: value = QUOTE(value)
		if mode==l11lll_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⧓") and value!=l11lll_l1_ (u"ࠬ࠶ࠧ⧔"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"࠭ࠠࠬࠢࠪ⧕")+value
		elif mode==l11lll_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⧖") and value!=l11lll_l1_ (u"ࠨ࠲ࠪ⧗"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠩࠩࠫ⧘")+key+l11lll_l1_ (u"ࠪࡁࠬ⧙")+value
		elif mode==l11lll_l1_ (u"ࠫࡦࡲ࡬ࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⧚"): l1ll1l1l_l1_ = l1ll1l1l_l1_+l11lll_l1_ (u"ࠬࠬࠧ⧛")+key+l11lll_l1_ (u"࠭࠽ࠨ⧜")+value
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠧࠡ࠭ࠣࠫ⧝"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.strip(l11lll_l1_ (u"ࠨࠨࠪ⧞"))
	l1ll1l1l_l1_ = l1ll1l1l_l1_.replace(l11lll_l1_ (u"ࠩࡀ࠴ࠬ⧟"),l11lll_l1_ (u"ࠪࡁࠬ⧠"))
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ⧡"),l11lll_l1_ (u"ࠬ࠭⧢"),filters,l11lll_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧ⧣"))
	return l1ll1l1l_l1_
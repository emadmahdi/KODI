# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ᭑")
l111ll_l1_ = l11lll_l1_ (u"ࠨࡡࡆࡑࡑࡥࠧ᭒")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"ࠩๅ๊ํอสࠡใูหห๐ษࠨ᭓")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l1111l_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l1llllll_l1_(url,text)
	elif mode==474: results = l1l11l_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ᭔"),l11ll1_l1_,l11lll_l1_ (u"ࠫࠬ᭕"),l11lll_l1_ (u"ࠬ࠭᭖"),l11lll_l1_ (u"࠭ࠧ᭗"),l11lll_l1_ (u"ࠧࠨ᭘"),l11lll_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᭙"))
	html = response.content
	l1ll1l1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡹࡷࡲࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ᭚"),html,re.DOTALL)
	l1ll1l1_l1_ = l1ll1l1_l1_[0].strip(l11lll_l1_ (u"ࠪ࠳ࠬ᭛"))
	l1ll1l1_l1_ = SERVER(l1ll1l1_l1_,l11lll_l1_ (u"ࠫࡺࡸ࡬ࠨ᭜"))
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭝"),l111ll_l1_+l11lll_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭᭞"),l11lll_l1_ (u"ࠧࠨ᭟"),479,l11lll_l1_ (u"ࠨࠩ᭠"),l11lll_l1_ (u"ࠩࠪ᭡"),l11lll_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᭢"))
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᭣"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᭤"),l11lll_l1_ (u"࠭ࠧ᭥"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᭦"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᭧")+l111ll_l1_+l11lll_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧ᭨"),l1ll1l1_l1_,471,l11lll_l1_ (u"ࠪࠫ᭩"),l11lll_l1_ (u"ࠫࠬ᭪"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧ᭫"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ᭬࠭"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᭭")+l111ll_l1_+l11lll_l1_ (u"ࠨ็ึุ่๊วห่้ࠢ๏ุษࠨ᭮"),l1ll1l1_l1_,471,l11lll_l1_ (u"ࠩࠪ᭯"),l11lll_l1_ (u"ࠪࠫ᭰"),l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭᭱"))
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ᭲"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᭳"),block,re.DOTALL)
	for link,title in items:
		title = title.strip(l11lll_l1_ (u"ࠧࠡࠩ᭴"))
		#if title in l1l1l1_l1_: continue
		link = link.replace(l11lll_l1_ (u"ࠨࡥࡤࡸࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠶࠭᭵"),l11lll_l1_ (u"ࠩࡦࡥࡹࡃ࡯࡯࡮࡬ࡲࡪ࠳࡭ࡰࡸ࡬ࡩࡸ࠭᭶"))
		addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭷"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᭸")+l111ll_l1_+title,link,474)
	addMenuItem(l11lll_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ᭹"),l11lll_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᭺"),l11lll_l1_ (u"ࠧࠨ᭻"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ᭼"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ᭽"),html,re.DOTALL)
	for l11l1_l1_ in l1l1ll1_l1_:
		block = block.replace(l11l1_l1_,l11lll_l1_ (u"ࠪࠫ᭾"))
	items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᭿"),block,re.DOTALL)
	for link,title in items:
		if title in l1l1l1_l1_: continue
		#link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࡥࡹࡲ࡯ࡳࡷ࡫࠯ࡀࠩᮀ")+category+l11lll_l1_ (u"࠭࠽ࠨᮁ")+value
		addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᮂ"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᮃ")+l111ll_l1_+title,link,474)
	return
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᮄ"),url,l11lll_l1_ (u"ࠪࠫᮅ"),l11lll_l1_ (u"ࠫࠬᮆ"),l11lll_l1_ (u"ࠬ࠭ᮇ"),l11lll_l1_ (u"࠭ࠧᮈ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᮉ"))
	html = response.content
	if l11lll_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࠨᮊ") in url: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡵࡳ࠭ࡨࡴ࡬ࡨࠧ࠭ᮋ"),html,re.DOTALL)
	else: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᮌ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᮍ"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࠬᮎ") in link:
				if l11lll_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡧࡱ࡫ࡱ࡯ࡳࡩ࠯ࡰࡳࡻ࡯ࡥࡴࠩᮏ") in link: continue
				if l11lll_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡲࡲࡱ࡯࡮ࡦ࠯ࡰࡳࡻ࡯ࡥࡴ࠳ࠪᮐ") in link: continue
				if l11lll_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡱ࡮ࡹࡣࠨᮑ") in link: continue
				if l11lll_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࡁࡦࡁࡹࡼ࠭ࡤࡪࡤࡲࡳ࡫࡬ࠨᮒ") in link: continue
				if l11lll_l1_ (u"้๋ࠪึࠠศๆหำฬ๐ษࠨᮓ") in title and l11lll_l1_ (u"ࠫࡩࡵ࠽ࡳࡣࡷ࡭ࡳ࡭ࠧᮔ") not in link: continue
			else: title = l11lll_l1_ (u"ࠬะัห์หࠤออำหะาห๊ࡀࠠࠡࠩᮕ")+title
			addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮖ"),l111ll_l1_+title,link,471)
	else: l1111l_l1_(url)
	return
def l1111l_l1_(url,request=l11lll_l1_ (u"ࠧࠨᮗ")):
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰࠬᮘ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭ᮙ"),url,l11lll_l1_ (u"ࠪࠫᮚ"),l11lll_l1_ (u"ࠫࠬᮛ"),l11lll_l1_ (u"ࠬ࠭ᮜ"),l11lll_l1_ (u"࠭ࠧᮝ"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᮞ"))
	html = response.content
	items = []
	if request==l11lll_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪᮟ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡦ࡭ࡷ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᮠ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᮡ"),block,re.DOTALL)
		links,l1l111_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,links,l1l111_l1_)
	elif request==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᮢ"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬอไๆี็ื้อสࠡษ็้๊๐าสࠪ࠱࠮ࡄ࠯࠼ࡴࡶࡼࡰࡪࡄࠧᮣ"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠫᮤ"),block,re.DOTALL)
		links,l1l111_l1_,l1ll1ll11l_l1_ = zip(*items)
		items = zip(l1ll1ll11l_l1_,links,l1l111_l1_)
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᮥ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࡇࡴࡴࠢࠨᮦ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡪࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᮧ"),html,re.DOTALL)
		if not l1l1ll1_l1_: l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰ࡶࡪࡲࡡࡵࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᮨ"),html,re.DOTALL)
		if not l1l1ll1_l1_: return
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᮩ"),block,re.DOTALL)
	if not items: items = re.findall(l11lll_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ᮪ࠧ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"࠭ๅีษ๊ำฮ᮫࠭"),l11lll_l1_ (u"ࠧโ์็้ࠬᮬ"),l11lll_l1_ (u"ࠨษ฽๊๏ฯࠧᮭ"),l11lll_l1_ (u"ࠩๆ่๏ฮࠧᮮ"),l11lll_l1_ (u"ࠪห฾๊ว็ࠩᮯ"),l11lll_l1_ (u"ࠫ์ีวโࠩ᮰"),l11lll_l1_ (u"๋ࠬศศำสอࠬ᮱"),l11lll_l1_ (u"ู࠭าุࠪ᮲"),l11lll_l1_ (u"ࠧๆ้ิะฬ์ࠧ᮳"),l11lll_l1_ (u"ࠨษ็ฬํ๋ࠧ᮴"),l11lll_l1_ (u"่ࠩืึำ๊สࠩ᮵")]
	for l1llll_l1_,link,title in items:
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬ᮶"))
		if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᮷") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"ࠬ࠵ࠧ᮸")+link.strip(l11lll_l1_ (u"࠭࠯ࠨ᮹"))
		if l11lll_l1_ (u"ࠧࡩࡶࡷࡴࠬᮺ") not in l1llll_l1_: l1llll_l1_ = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪᮻ")+l1llll_l1_.strip(l11lll_l1_ (u"ࠩ࠲ࠫᮼ"))
		#link = unescapeHTML(link)
		#title = unescapeHTML(title)
		#title = title.strip(l11lll_l1_ (u"ࠪࠤࠬᮽ"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧᮾ"),title,re.DOTALL)
		if any(value in title for value in l1lll1_l1_):
			addMenuItem(l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᮿ"),l111ll_l1_+title,link,472,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"࠭วๅฯ็ๆฮ࠭ᯀ") in title:
			title = l11lll_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᯁ") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯂ"),l111ll_l1_+title,link,473,l1llll_l1_)
				l1l1_l1_.append(title)
		elif l11lll_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧᯃ") in link:
			addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᯄ"),l111ll_l1_+title,link,471,l1llll_l1_)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯅ"),l111ll_l1_+title,link,473,l1llll_l1_)
	if request not in [l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧᯆ"),l11lll_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᯇ")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᯈ"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᯉ"),block,re.DOTALL)
			for link,title in items:
				if link==l11lll_l1_ (u"ࠩࠦࠫᯊ"): continue
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠪ࠳ࠬᯋ")+link.strip(l11lll_l1_ (u"ࠫ࠴࠭ᯌ"))
				title = unescapeHTML(title)
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯍ"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬᯎ")+title,link,471)
		l11111l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᯏ"),html,re.DOTALL)
		if l11111l11_l1_:
			link = l11111l11_l1_[0]
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯐ"),l111ll_l1_+l11lll_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะࠩᯑ"),link,471)
	return
def l1llllll_l1_(url,l1ll1_l1_):
	#LOG_THIS(l11lll_l1_ (u"ࠪࠫᯒ"),l11lll_l1_ (u"ࠫ࠶࠷࠱࠲ࠢࠣࠫᯓ")+url)
	l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠬࡻࡲ࡭ࠩᯔ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪᯕ"),url,l11lll_l1_ (u"ࠧࠨᯖ"),l11lll_l1_ (u"ࠨࠩᯗ"),l11lll_l1_ (u"ࠩࠪᯘ"),l11lll_l1_ (u"ࠪࠫᯙ"),l11lll_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ᯚ"))
	html = response.content
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᯛ"),html,re.DOTALL)
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡩࡥ࠿ࠥࠫᯜ")+l1ll1_l1_+l11lll_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᯝ"),html,re.DOTALL)
	items = []
	# l1lllll_l1_
	if l1l1l11_l1_ and not l1ll1_l1_:
		l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᯞ"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠩࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷࡠ࠱ࠦ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ࠭ᯟ"),block,re.DOTALL)
		for l1ll1_l1_,title in items: addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᯠ"),l111ll_l1_+title,url,473,l1llll_l1_,l11lll_l1_ (u"ࠫࠬᯡ"),l1ll1_l1_)
	# l1l1l_l1_
	elif l1l11ll_l1_:
		#l1llll_l1_ = xbmc.getInfoLabel(l11lll_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕࡪࡸࡱࡧ࠭ᯢ"))
		l1llll_l1_ = re.findall(l11lll_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᯣ"),html,re.DOTALL)
		l1llll_l1_ = l1llll_l1_[0]
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠢࡵ࡫ࡷࡰࡪࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠠࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᯤ"),block,re.DOTALL)
		if items:
			for title,link in items:
				link = l1ll1l1_l1_+l11lll_l1_ (u"ࠨ࠱ࠪᯥ")+link.strip(l11lll_l1_ (u"ࠩ࠲᯦ࠫ"))
				addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᯧ"),l111ll_l1_+title,link,472,l1llll_l1_)
		else:
			items = re.findall(l11lll_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬᯨ"),block,re.DOTALL)
			for link,title,l1llll_l1_ in items:
				if l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࠪᯩ") not in link: link = l1ll1l1_l1_+l11lll_l1_ (u"࠭࠯ࠨᯪ")+link.strip(l11lll_l1_ (u"ࠧ࠰ࠩᯫ"))
				addMenuItem(l11lll_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᯬ"),l111ll_l1_+title,link,472,l1llll_l1_)
	if l11lll_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠫᯭ") in html:
		if items: addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᯮ"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᯯ"),l11lll_l1_ (u"ࠬ࠭ᯰ"),9999)
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᯱ"),l111ll_l1_+l11lll_l1_ (u"ࠧๆ๊สฺ๏฿ࠠัษอࠤฺ๊ษࠨ᯲"),url,471)
	#else: l1111l_l1_(url)
	return
def PLAY(url):
	#l1ll1l1_l1_ = SERVER(url,l11lll_l1_ (u"ࠨࡷࡵࡰ᯳ࠬ"))
	l1111_l1_ = []
	# l1ll1ll111_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭᯴"),url,l11lll_l1_ (u"ࠪࠫ᯵"),l11lll_l1_ (u"ࠫࠬ᯶"),l11lll_l1_ (u"ࠬ࠭᯷"),l11lll_l1_ (u"࠭ࠧ᯸"),l11lll_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ᯹"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ࠿ࠪ࠱࠮ࡄ࠯ࡨࡳࡧࡩࡁࠬ᯺"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ᯻"),block,re.DOTALL)
		if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_,True): return
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ᯼"),l11lll_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ᯽"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ᯾"),l11l11l_l1_,l11lll_l1_ (u"࠭ࠧ᯿"),l11lll_l1_ (u"ࠧࠨᰀ"),l11lll_l1_ (u"ࠨࠩᰁ"),l11lll_l1_ (u"ࠩࠪᰂ"),l11lll_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨᰃ"))
	html = response.content
	l1ll1l1ll1_l1_ = []
	# l1l11llll_l1_ link
	link = re.findall(l11lll_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧ࡙ࡗࡒࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᰄ"),html,re.DOTALL)
	if link:
		link = link[0]
		if link and link not in l1ll1l1ll1_l1_:
			l1ll1l1ll1_l1_.append(link)
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭ᰅ")
			if l11lll_l1_ (u"࠭ࡨࡵࡶࡳࠫᰆ") not in link: link = l11lll_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᰇ")+link
			l1111_l1_.append(link)
	# l11ll1l1l_l1_ links
	items = re.findall(l11lll_l1_ (u"ࠣ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠦᰈ"),html,re.DOTALL)
	for link,title in items:
		if link not in l1ll1l1ll1_l1_:
			l1ll1l1ll1_l1_.append(link)
			link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᰉ")+title+l11lll_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫᰊ")
			if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᰋ") not in link: link = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᰌ")+link
			l1111_l1_.append(link)
	# download links
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᰍ"),l11lll_l1_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࡶ࠲ࡵ࡮ࡰࠨᰎ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬᰏ"),l11l11l_l1_,l11lll_l1_ (u"ࠩࠪᰐ"),l11lll_l1_ (u"ࠪࠫᰑ"),l11lll_l1_ (u"ࠫࠬᰒ"),l11lll_l1_ (u"ࠬ࠭ᰓ"),l11lll_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫᰔ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᰕ"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫᰖ"),block,re.DOTALL)
		for link,title in items:
			if link not in l1ll1l1ll1_l1_:
				l1ll1l1ll1_l1_.append(link)
				link = link+l11lll_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᰗ")+title+l11lll_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᰘ")
				if l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᰙ") not in link: link = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᰚ")+link
				l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫᰛ"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᰜ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠨࠩᰝ"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠩࠪᰞ"): return
	search = search.replace(l11lll_l1_ (u"ࠪࠤࠬᰟ"),l11lll_l1_ (u"ࠫ࠰࠭ᰠ"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂ࡯ࡪࡿࡷࡰࡴࡧࡷࡂ࠭ᰡ")+search
	l1111l_l1_(url)
	return
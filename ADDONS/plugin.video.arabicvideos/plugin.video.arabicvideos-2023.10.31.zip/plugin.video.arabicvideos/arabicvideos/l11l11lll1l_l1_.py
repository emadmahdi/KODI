# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ䓂")
l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡌࡅࡐࡢࠫ䓃")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
l1l1l1_l1_ = [l11lll_l1_ (u"࠭วๅำษ๎ุ๐ษࠨ䓄"),l11lll_l1_ (u"ࠧศีอๅุอัหๅ่ࠤํࠦวๅู็ฬฬะࠧ䓅")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l1111l_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1llll1l11_l1_(url)
	elif mode==454: results = l1llllll_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠨࡉࡈࡘࠬ䓆"),l11ll1_l1_,l11lll_l1_ (u"ࠩࠪ䓇"),l11lll_l1_ (u"ࠪࠫ䓈"),l11lll_l1_ (u"ࠫࠬ䓉"),l11lll_l1_ (u"ࠬ࠭䓊"),l11lll_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䓋"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11ll1_l1_,l11lll_l1_ (u"ࠧࡶࡴ࡯ࠫ䓌"))
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓍"),l111ll_l1_+l11lll_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䓎"),l11lll_l1_ (u"ࠪࠫ䓏"),459,l11lll_l1_ (u"ࠫࠬ䓐"),l11lll_l1_ (u"ࠬ࠭䓑"),l11lll_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䓒"))
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓓"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䓔")+l111ll_l1_+l11lll_l1_ (u"่ࠩฯอะวหࠢ็์ิ๐ࠠ็ฬࠪ䓕"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠪࠫ䓖"),l11lll_l1_ (u"ࠫࠬ䓗"),l11lll_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䓘"))
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓙"),script_name+l11lll_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䓚")+l111ll_l1_+l11lll_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ䓛"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠩࠪ䓜"),l11lll_l1_ (u"ࠪࠫ䓝"),l11lll_l1_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫ䓞"))
	#addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䓟"),script_name+l11lll_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䓠")+l111ll_l1_+l11lll_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䓡"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠨࠩ䓢"),l11lll_l1_ (u"ࠩࠪ䓣"),l11lll_l1_ (u"ࠪࡥࡨࡺ࡯ࡳࡵࠪ䓤"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓥"),script_name+l11lll_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䓦")+l111ll_l1_+l11lll_l1_ (u"࠭ๅิๆึ่ฬะ่่ࠠา๎ฮ࠭䓧"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠧࠨ䓨"),l11lll_l1_ (u"ࠨࠩ䓩"),l11lll_l1_ (u"ࠩ࠳ࠫ䓪"))
	#addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䓫"),script_name+l11lll_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䓬")+l111ll_l1_+l11lll_l1_ (u"๋ࠬำๅี็หฯࠦ็็ัํอ๋ࠥฯษๆฯอࠬ䓭"),l1ll1l1_l1_,451,l11lll_l1_ (u"࠭ࠧ䓮"),l11lll_l1_ (u"ࠧࠨ䓯"),l11lll_l1_ (u"ࠨ࠳ࠪ䓰"))
	#addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䓱"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䓲")+l111ll_l1_+l11lll_l1_ (u"ࠫฬ็ไศ็๋๋ࠣี๊สࠩ䓳"),l1ll1l1_l1_,451,l11lll_l1_ (u"ࠬ࠭䓴"),l11lll_l1_ (u"࠭ࠧ䓵"),l11lll_l1_ (u"ࠧ࠳ࠩ䓶"))
	addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䓷"),l11lll_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䓸"),l11lll_l1_ (u"ࠪࠫ䓹"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡓࡡࡪࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠫ䓺"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䓻"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"࠭ࠣࠨ䓼"): continue
			if title in l1l1l1_l1_: continue
			addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓽"),script_name+l11lll_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䓾")+l111ll_l1_+title,link,451)
	return
def l1111l_l1_(url,l1111l111_l1_=l11lll_l1_ (u"ࠩࠪ䓿")):
	#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䔀"),l11lll_l1_ (u"ࠫࠬ䔁"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䔂"),url,l11lll_l1_ (u"࠭ࠧ䔃"),l11lll_l1_ (u"ࠧࠨ䔄"),l11lll_l1_ (u"ࠨࠩ䔅"),l11lll_l1_ (u"ࠩࠪ䔆"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ䔇"))
	html = response.content
	if l1111l111_l1_==l11lll_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䔈"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡓࡪࡶࡨࡗࡱ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡺࡥࡻ࡫ࡳࠣࠩ䔉"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l1111l111_l1_==l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䔊"):
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡔࡨࡧࡪࡴࡴࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠪ䔋"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	elif l11lll_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠧ䔌") in html:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠩࠥࡅࡨࡺ࡯ࡳࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡦࡺࡷ࠳࡯ࡧࡶࡢࡵࡦࡶ࡮ࡶࡴࠣࠩ䔍"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࠢࡂࡥࡷࡳࡷࡔࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䔎"),block,re.DOTALL)
	elif l1111l111_l1_ in [l11lll_l1_ (u"ࠫ࠵࠭䔏"),l11lll_l1_ (u"ࠬ࠷ࠧ䔐"),l11lll_l1_ (u"࠭࠲ࠨ䔑")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡕࡨࡧࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃࡂ࠯ࡶ࡮ࡁࠫ䔒"),html,re.DOTALL)
		block = l1l1ll1_l1_[int(l1111l111_l1_)]
	else:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ䔓"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	if not items: items = re.findall(l11lll_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ䔔"),block,re.DOTALL)
	l1l1_l1_ = []
	l1lll1_l1_ = [l11lll_l1_ (u"ู้ࠪอ็ะหࠪ䔕"),l11lll_l1_ (u"ࠫๆ๐ไๆࠩ䔖"),l11lll_l1_ (u"ࠬอฺ็์ฬࠫ䔗"),l11lll_l1_ (u"࠭ร฻่ํอࠬ䔘"),l11lll_l1_ (u"ࠧไๆํฬࠬ䔙"),l11lll_l1_ (u"ࠨษ฼่ฬ์ࠧ䔚"),l11lll_l1_ (u"๊ࠩำฬ็ࠧ䔛"),l11lll_l1_ (u"้ࠪออัศหࠪ䔜"),l11lll_l1_ (u"ࠫ฾ืึࠨ䔝"),l11lll_l1_ (u"๋ࠬ็าฮส๊ࠬ䔞"),l11lll_l1_ (u"࠭วๅส๋้ࠬ䔟")]
	for link,l1llll_l1_,title in items:
		if l11lll_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭䔠") in html and l11lll_l1_ (u"ࠨࡵࡵࡧࡂ࠭䔡") in l1llll_l1_:
			l1llll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䔢"),l1llll_l1_,re.DOTALL)
			l1llll_l1_ = l1llll_l1_[0]
		link = l111l_l1_(link).strip(l11lll_l1_ (u"ࠪ࠳ࠬ䔣"))
		l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣั้่ษࠡ࡞ࡧ࠯ࠬ䔤"),title,re.DOTALL)
		if not l1lll11_l1_: l1lll11_l1_ = re.findall(l11lll_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ䔥"),title,re.DOTALL)
		#if any(value in title for value in l1lll1_l1_):
		if set(title.split()) & set(l1lll1_l1_) and l11lll_l1_ (u"࠭ๅิๆึ่ࠬ䔦") not in title:
			addMenuItem(l11lll_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䔧"),l111ll_l1_+title,link,452,l1llll_l1_)
		elif l1lll11_l1_ and l11lll_l1_ (u"ࠨฯ็ๆฮ࠭䔨") in title:
			title = l11lll_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䔩") + l1lll11_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䔪"),l111ll_l1_+title,link,453,l1llll_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔫"),l111ll_l1_+title,link,453,l1llll_l1_)
	if l1111l111_l1_ in [l11lll_l1_ (u"ࠬ࠭䔬"),l11lll_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭䔭")]:
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䔮"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䔯"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠤࠥ䔰"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠪࠫ䔱"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔲"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ䔳")+title,link,451)
	return
def l1llll1l11_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"࠭ࡇࡆࡖࠪ䔴"),url,l11lll_l1_ (u"ࠧࠨ䔵"),l11lll_l1_ (u"ࠨࠩ䔶"),l11lll_l1_ (u"ࠩࠪ䔷"),l11lll_l1_ (u"ࠪࠫ䔸"),l11lll_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘ࠲࡙ࡅࡂࡕࡒࡒࡘ࠳࠱ࡴࡶࠪ䔹"))
	html = response.content
	# l1lllll_l1_
	l1l1l11_l1_ = re.findall(l11lll_l1_ (u"ࠬࠨࡃࡢࡶࡨ࡫ࡴࡸࡹࡔࡷࡥࡐ࡮ࡴ࡫ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䔺"),html,re.DOTALL)
	if l1l1l11_l1_ and l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬ䔻") in str(l1l1l11_l1_):
		title = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮࠳ࠧ䔼"),html,re.DOTALL)
		title = title[0].strip(l11lll_l1_ (u"ࠨࠢࠪ䔽"))
		addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䔾"),l111ll_l1_+title,url,454)
		block = l1l1l11_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䔿"),block,re.DOTALL)
		for link,title in items:
			addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕀"),l111ll_l1_+title,link,454)
	else: l1llllll_l1_(url)
	return
def l1llllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ䕁"),url,l11lll_l1_ (u"࠭ࠧ䕂"),l11lll_l1_ (u"ࠧࠨ䕃"),l11lll_l1_ (u"ࠨࠩ䕄"),l11lll_l1_ (u"ࠩࠪ䕅"),l11lll_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䕆"))
	html = response.content
	# l1l1l_l1_
	l1l11ll_l1_ = re.findall(l11lll_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡆࡸࡥࡢࠤࠫ࠲࠯ࡅࠩࠣࡶࡨࡼࡹ࠵ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠥࠫ䕇"),html,re.DOTALL)
	if l1l11ll_l1_:
		block = l1l11ll_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ䕈"),block,re.DOTALL)
		for link,l1llll_l1_,title in items:
			addMenuItem(l11lll_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䕉"),l111ll_l1_+title,link,452,l1llll_l1_)
		l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䕊"),html,re.DOTALL)
		if l1l1ll1_l1_:
			block = l1l1ll1_l1_[0]
			items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䕋"),block,re.DOTALL)
			for link,title in items:
				#if link==l11lll_l1_ (u"ࠤࠥ䕌"): continue
				title = unescapeHTML(title)
				#if title!=l11lll_l1_ (u"ࠪࠫ䕍"):
				addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕎"),l111ll_l1_+l11lll_l1_ (u"ࠬ฻แฮหࠣࠫ䕏")+title,link,454)
	return
def PLAY(url):
	l11l11l_l1_ = url.replace(l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ䕐"),l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࡟࡮ࡱࡹ࡭ࡪࡹ࠯ࠨ䕑"))
	l11l11l_l1_ = l11l11l_l1_.replace(l11lll_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䕒"),l11lll_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶ࠳ࠬ䕓"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䕔"),l11l11l_l1_,l11lll_l1_ (u"ࠫࠬ䕕"),l11lll_l1_ (u"ࠬ࠭䕖"),l11lll_l1_ (u"࠭ࠧ䕗"),l11lll_l1_ (u"ࠧࠨ䕘"),l11lll_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ䕙"))
	html = response.content
	l1ll1l1_l1_ = SERVER(l11l11l_l1_,l11lll_l1_ (u"ࠩࡸࡶࡱ࠭䕚"))
	l1111_l1_ = []
	# l11ll1l1l_l1_ links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠪࠦ࡜ࡧࡴࡤࡪࡗ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡶ࡭ࡩ࡫࠾ࠨ䕛"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭䕜"),block,re.DOTALL)
		for link,title in items:
			link = link+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䕝")+title+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䕞")
			l1111_l1_.append(link)
	# download links
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࡏ࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡴࡧ࡯ࡥࡷࡿࠢࠨ䕟"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ䕠"),block,re.DOTALL)
		for link,name in items:
			name = unescapeHTML(name)
			l11l111l_l1_ = re.findall(l11lll_l1_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ䕡"),name,re.DOTALL)
			if l11l111l_l1_:
				l11l111l_l1_ = l11lll_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ䕢")+l11l111l_l1_[0]
				name = l11lll_l1_ (u"ࠫࠬ䕣")
			else: l11l111l_l1_ = l11lll_l1_ (u"ࠬ࠭䕤")
			link = link+l11lll_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䕥")+name+l11lll_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䕦")+l11l111l_l1_
			l1111_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䕧"),l1111_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1111_l1_,script_name,l11lll_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䕨"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"ࠪࠫ䕩"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠫࠬ䕪"): return
	search = search.replace(l11lll_l1_ (u"ࠬࠦࠧ䕫"),l11lll_l1_ (u"࠭ࠫࠨ䕬"))
	url = l11ll1_l1_+l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩ䕭")+search
	l1111l_l1_(url)
	return
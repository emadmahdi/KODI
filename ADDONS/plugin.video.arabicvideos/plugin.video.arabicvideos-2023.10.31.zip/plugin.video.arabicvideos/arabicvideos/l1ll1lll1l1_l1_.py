# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
#l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ✪")
#l11ll1_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠲࠰ࡥࡩࡸࡺࠧ✫")
#l11ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠫ✬")
#l11ll1_l1_ = l11lll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ✭")
#l11ll1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠸ࡧ࡫ࡳࡵ࠰ࡦࡳࡲ࠭✮")
#l11ll1_l1_ = l11lll_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠯ࡹ࡭ࡵ࠴ࡳࡩࡱࡩࡨࡦ࠴ࡣࡰ࡯ࠪ✯")
#l11ll1_l1_ = l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡳࡲ࡫࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰ࡯ࠫ✰")
#l11ll1_l1_ = l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ✱")
#l11ll1_l1_ = l11lll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮࡫ࡧࡺࡤࡨࡷࡹ࠴ࡢࡪࡦࠪ✲")
#l11ll1_l1_ = l11lll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴ࠭ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ✳")
script_name = l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ✴")
l111ll_l1_ = l11lll_l1_ (u"࠭࡟ࡆࡉ࡙ࡣࠬ✵")
l11ll1_l1_ = l1ll11l_l1_[script_name][0]
def MAIN(mode,url,l1l11l1_l1_,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l1111l_l1_(url,l1l11l1_l1_)
	elif mode==222: results = l1l11l_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1lll1l1_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ✶"),l111ll_l1_+l11lll_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ✷"),l11lll_l1_ (u"ࠩࠪ✸"),229,l11lll_l1_ (u"ࠪࠫ✹"),l11lll_l1_ (u"ࠫࠬ✺"),l11lll_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ✻"))
	#addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭✼"),l111ll_l1_+l11lll_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ✽"),l11ll1_l1_,226,l11lll_l1_ (u"ࠨࠩ✾"),l11lll_l1_ (u"ࠩࠪ✿"),l11lll_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ❀"))
	#addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ❁"),l111ll_l1_+l11lll_l1_ (u"ࠬ็ไหำࠣ็ฬ๋ไࠨ❂"),l11ll1_l1_,226,l11lll_l1_ (u"࠭ࠧ❃"),l11lll_l1_ (u"ࠧࠨ❄"),l11lll_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ❅"))
	addMenuItem(l11lll_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ❆"),l11lll_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ❇"),l11lll_l1_ (u"ࠫࠬ❈"),9999)
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ❉"),l11ll1_l1_,l11lll_l1_ (u"࠭ࠧ❊"),l11lll_l1_ (u"ࠧࠨ❋"),l11lll_l1_ (u"ࠨࠩ❌"),l11lll_l1_ (u"ࠩࠪ❍"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭❎"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࠦࡩ࠮ࡪࡲࡱࡪࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ❏"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭❐"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"࠭࠼࠰࡫ࡁࠫ❑") in title: title = title.split(l11lll_l1_ (u"ࠧ࠽࠱࡬ࡂࠬ❒"))[1]
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❓"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ❔")+l111ll_l1_+title,link,222)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ❕"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ❖"),l11lll_l1_ (u"ࠬ࠭❗"),9999)
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡢࠪ࠱࠮ࡄ࠯࠼ࡴࡥࡵ࡭ࡵࡺࠧ❘"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠧࡱࡦࡤࠤࡧࡪࡢࠣࡀ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ❙"),html,re.DOTALL)
		for title,link in items:
			addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❚"),script_name+l11lll_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ❛")+l111ll_l1_+title,link,221)
		addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ❜"),l11lll_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ❝"),l11lll_l1_ (u"ࠬ࠭❞"),9999)
		items = re.findall(l11lll_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ❟"),block,re.DOTALL)
		for link,title in items:
			if l11lll_l1_ (u"ࠧࡩࡶࡰࡰࠬ❠") not in link: continue
			if not link.endswith(l11lll_l1_ (u"ࠨ࠱ࠪ❡")): addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ❢"),script_name+l11lll_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ❣")+l111ll_l1_+title,link,221)
	return html
	l11lll_l1_ (u"ࠦࠧࠨࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭วื฼ฺࠤ์์วࠡๆสฺฬ็ษࠡษึ้ࠥีฮ้ๆࠣ์่๊ๅสࠢสุ่ืࠧ࠭ࠩࠪ࠰࠷࠸࠵ࠪࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨฬะิ๏ืࠧ࠭ࠩࠪ࠰࠷࠸࠶ࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮ࠣ࡬ࡹࡳ࡬ࠪࠌࠌࠧ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲࡑࡵࡡࡥࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠣࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠰࡞ࠌࠌࠧ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࡟ࡲࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧ࡫ࡵࡲࠡࡷࡵࡰ࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠥࠌ࡭࡫ࠦࡵࡳ࡮ࠤࡁࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧ࠺ࠡࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡹࡷࡲࠬ࠳࠴࠷࠭ࠏࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ࠰ࠬ࠭ࠬ࠳࠴࠼࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้ษใฬำู้ࠣอ็ะหࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ࠱࠸࠲࠲ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࠪห้อแๅษ่ࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠬࠩ࠲ࡱࡴࡼࡩࡦࡵࠪ࠰࠷࠸࠴ࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠬࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩสู่๊ไิๆสฮࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠭ࠪ࠳ࡹࡼࠧ࠭࠴࠵࠸࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭࡬ࡪࡰ࡮ࠫ࠱࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬࠨࠩ࠯࠽࠾࠿࠹ࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡑࡕࡎࡈࡡࡆࡅࡈࡎࡅ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࠡ࡯ࡪࡦ࠭࠴ࠪࡀࠫࡁࡉ࡬ࡿࡂࡦࡵࡷࡀ࠴ࡧ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊ࡫ࡷࡩࡲࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠲࠳࠳ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠥ࡮ࡴ࡮࡮ࠍࠍࠨࠦࡥࡨࡻࡥࡩࡸࡺ࠱࠯ࡥࡲࡱࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡨࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠦ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡡ࠱࠰࡟࡞࡭ࠧࡣ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡩࡧࠢࠪࡸࡴࡸࡲࡦࡰࡷࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡴࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊ࡫ࡷࡩࡲࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊ࡫ࡩࠤࠬࡺ࡯ࡳࡴࡨࡲࡹ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠲࠳࠳ࠬࠎࠎࠨࠢࠣ❤")
def l1l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l11111l_l1_,l11lll_l1_ (u"ࠬࡍࡅࡕࠩ❥"),url,l11lll_l1_ (u"࠭ࠧ❦"),l11lll_l1_ (u"ࠧࠨ❧"),l11lll_l1_ (u"ࠨࠩ❨"),l11lll_l1_ (u"ࠩࠪ❩"),l11lll_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ❪"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡹ࡟ࡴࡥࡵࡳࡱࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ❫"),html,re.DOTALL)
	block = l1l1ll1_l1_[0]
	items = re.findall(l11lll_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭❬"),block,re.DOTALL)
	for link,title in items:
		addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭❭"),l111ll_l1_+title,link,224)
	return
def l1lll1l1_l1_(url):
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ❮"),l111ll_l1_+l11lll_l1_ (u"ࠨษ็ะ๊๐ูࠨ❯"),url,221)
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"ࠩࠪ❰"),l11lll_l1_ (u"ࠪࠫ❱"),l11lll_l1_ (u"ࠫࠬ❲"),l11lll_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ❳"))
	l11lll_l1_ (u"ࠨࠢࠣࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌࠦࠧࠨ❴")
	l1l1ll1_l1_ = re.findall(l11lll_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡷࡥࡣࡳࡧࡶࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡰࡳࡻ࡯ࡥࡴࠩ❵"),html,re.DOTALL)
	if l1l1ll1_l1_:
		block = l1l1ll1_l1_[0]
		items = re.findall(l11lll_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ❶"),block,re.DOTALL)
		for link,title in items:
			if link==l11lll_l1_ (u"ࠩࠦࠫ❷"): name = title
			else:
				title = title + l11lll_l1_ (u"ࠪࠤࠥࡀࠠࠡࠩ❸") + l11lll_l1_ (u"ࠫๆ๊สาࠢࠪ❹") + name
				addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ❺"),l111ll_l1_+title,link,221)
	else: l1111l_l1_(url)
	return
def l1111l_l1_(url,l1l11l1_l1_=l11lll_l1_ (u"࠭࠱ࠨ❻")):
	if l1l11l1_l1_==l11lll_l1_ (u"ࠧࠨ❼"): l1l11l1_l1_ = l11lll_l1_ (u"ࠨ࠳ࠪ❽")
	#DIALOG_OK(l11lll_l1_ (u"ࠩࠪ❾"),l11lll_l1_ (u"ࠪࠫ❿"),str(url), str(l1l11l1_l1_))
	if l11lll_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ➀") in url or l11lll_l1_ (u"ࠬࡅࠧ➁") in url: l11l11l_l1_ = url + l11lll_l1_ (u"࠭ࠦࠨ➂")
	else: l11l11l_l1_ = url + l11lll_l1_ (u"ࠧࡀࠩ➃")
	#l11l11l_l1_ = l11l11l_l1_ + l11lll_l1_ (u"ࠨࡱࡸࡸࡵࡻࡴࡠࡨࡲࡶࡲࡧࡴ࠾࡬ࡶࡳࡳࠬ࡯ࡶࡶࡳࡹࡹࡥ࡭ࡰࡦࡨࡁࡲࡵࡶࡪࡧࡶࡣࡱ࡯ࡳࡵࠨࡳࡥ࡬࡫࠽ࠨ➄")+l1l11l1_l1_
	l11l11l_l1_ = l11l11l_l1_ + l11lll_l1_ (u"ࠩࡳࡥ࡬࡫࠽ࠨ➅") + l1l11l1_l1_
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11l_l1_,l11lll_l1_ (u"ࠪࠫ➆"),l11lll_l1_ (u"ࠫࠬ➇"),l11lll_l1_ (u"ࠬ࠭➈"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ➉"))
	#name = l11lll_l1_ (u"ࠧࠨ➊")
	#if l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩ➋") in url:
	#	name = re.findall(l11lll_l1_ (u"ࠩ࠿࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭➌"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l11lll_l1_ (u"ࠪࠤࠬ➍")) + l11lll_l1_ (u"ࠫࠥ࠳ࠠࠨ➎")
	#	else: name = xbmc.getInfoLabel( l11lll_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱࠨ➏") ) + l11lll_l1_ (u"࠭ࠠ࠮ࠢࠪ➐")
	if l11lll_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࠨ➑") in url:
		l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡧࡥࠧ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ➒"),html,re.DOTALL)
		block = l1l1ll1_l1_[-1]
	# l1ll1ll1ll1_l1_ l1lllll_l1_
	elif l11lll_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ➓") in url:
		l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡳࡼࡲ࠭ࡤࡣࡵࡳࡺࡹࡥ࡭ࠢࡲࡻࡱ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ➔"),html,re.DOTALL)
		block = l1l1ll1_l1_[0]
	else:
		l1l1ll1_l1_=re.findall(l11lll_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡲࡺ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ➕"),html,re.DOTALL)
		block = l1l1ll1_l1_[-1]
	items = re.findall(l11lll_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ➖"),block,re.DOTALL)
	for link,l1llll_l1_,title in items:
		l11lll_l1_ (u"ࠨࠢࠣࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶࡩࡷ࡯ࡥࡴࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡥࡳࡪࠠࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡦࡳࡳࡺࡩ࡯ࡷࡨࠎࠎࠏࡩࡧࠢࠪ࠳ࡸ࡫ࡡࡴࡱࡱࠫࠥ࡯࡮ࠡࡷࡵࡰࠥࡧ࡮ࡥࠢࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡺࡩࡵ࡮ࡨ࠰ࠥࡹࡴࡳࠪ࡯࡭ࡳࡱࠩࠪࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡴࡡ࡮ࡧࠣ࠯ࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠧࠨࠢ➗")
		title = unescapeHTML(title)
		l11lll_l1_ (u"ࠢࠣࠤࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪ࡯ࡪࠤࡂࠦࡩ࡮ࡩ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࠋ࡬ࡪࠥ࠭ࡨࡵࡶࡳࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥ࡯࡭ࡨ࠼ࠣ࡭ࡲ࡭ࠠ࠾ࠢࠪ࡬ࡹࡺࡰ࠻ࠩࠣ࠯ࠥ࡯࡭ࡨࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡔࡏࡕࡋࡉࡍࡈࡇࡔࡊࡑࡑࠬ࡮ࡳࡧ࠭ࠩࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠨࠢࠣ➘")
		if l11lll_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰ࠩ➙") in link or l11lll_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࠫ➚") in link:
			addMenuItem(l11lll_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ➛"),l111ll_l1_+title,link.rstrip(l11lll_l1_ (u"ࠫ࠴࠭➜")),223,l1llll_l1_)
		else:
			addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ➝"),l111ll_l1_+title,link,221,l1llll_l1_)
	if len(items)>=16:
		l1111ll111_l1_ = [l11lll_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ➞"),l11lll_l1_ (u"ࠧ࠰ࡶࡹࠫ➟"),l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ➠"),l11lll_l1_ (u"ࠩ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ➡")]
		l1l11l1_l1_ = int(l1l11l1_l1_)
		if any(value in url for value in l1111ll111_l1_):
			for n in range(0,1000,100):
				if int(l1l11l1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1l11l1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1l11l1_l1_==j and j!=0:
									addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➢"),l111ll_l1_+l11lll_l1_ (u"ฺࠫ็อสࠢࠪ➣")+str(j),url,221,l11lll_l1_ (u"ࠬ࠭➤"),str(j))
						elif i!=0: addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➥"),l111ll_l1_+l11lll_l1_ (u"ࠧึใะอࠥ࠭➦")+str(i),url,221,l11lll_l1_ (u"ࠨࠩ➧"),str(i))
						else: addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➨"),l111ll_l1_+l11lll_l1_ (u"ูࠪๆำษࠡࠩ➩")+str(1),url,221,l11lll_l1_ (u"ࠫࠬ➪"),str(1))
				elif n!=0: addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ➫"),l111ll_l1_+l11lll_l1_ (u"࠭ีโฯฬࠤࠬ➬")+str(n),url,221,l11lll_l1_ (u"ࠧࠨ➭"),str(n))
				else: addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➮"),l111ll_l1_+l11lll_l1_ (u"ุࠩๅาฯࠠࠨ➯")+str(1),url,221)
	return
def PLAY(url):
	#global l11lll_l1_ (u"ࠪࠫ➰")
	l1lll1ll_l1_,l1111_l1_ = [],[]
	#DIALOG_OK(l11lll_l1_ (u"ࠫࠬ➱"),l11lll_l1_ (u"ࠬ࠭➲"),url, url[-45:])
	# https://l1lll11111l_l1_.com/l1lll111ll1_l1_/فيلم-the-l1lll11l1l1_l1_-l1ll1ll1lll_l1_-2019-مترجم
	html = OPENURL_CACHED(l11111l_l1_,url,l11lll_l1_ (u"࠭ࠧ➳"),l11lll_l1_ (u"ࠧࠨ➴"),l11lll_l1_ (u"ࠨࠩ➵"),l11lll_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ➶"))
	l11ll1l_l1_ = re.findall(l11lll_l1_ (u"ࠪࡀࡹࡪ࠾ศๆอู๋๐แ࠽࠱ࡷࡨࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ➷"),html,re.DOTALL)
	if l11ll1l_l1_ and l11ll11_l1_(script_name,url,l11ll1l_l1_): return
	# https://l111l11l1l_l1_.l1ll1ll1l1l_l1_/l1lll111ll1_l1_/فيلم-the-l1lll11l1l1_l1_-l1ll1ll1lll_l1_-2019-مترجم
	l11l1ll1l_l1_,l1l111111_l1_ = l11lll_l1_ (u"ࠫࠬ➸"),l11lll_l1_ (u"ࠬ࠭➹")
	l1lll11l1ll_l1_,l1ll1lllll1_l1_ = html,html
	l1lll1111ll_l1_ = re.findall(l11lll_l1_ (u"࠭ࡳࡩࡱࡺࡣࡩࡲࠠࡢࡲ࡬ࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ➺"),html,re.DOTALL)
	if l1lll1111ll_l1_:
		for link in l1lll1111ll_l1_:
			if l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨ➻") in link: l11l1ll1l_l1_ = link
			elif l11lll_l1_ (u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ➼") in link: l1l111111_l1_ = link
		if l11l1ll1l_l1_!=l11lll_l1_ (u"ࠩࠪ➽"): l1lll11l1ll_l1_ = OPENURL_CACHED(l11111l_l1_,l11l1ll1l_l1_,l11lll_l1_ (u"ࠪࠫ➾"),l11lll_l1_ (u"ࠫࠬ➿"),l11lll_l1_ (u"ࠬ࠭⟀"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ⟁"))
		if l1l111111_l1_!=l11lll_l1_ (u"ࠧࠨ⟂"): l1ll1lllll1_l1_ = OPENURL_CACHED(l11111l_l1_,l1l111111_l1_,l11lll_l1_ (u"ࠨࠩ⟃"),l11lll_l1_ (u"ࠩࠪ⟄"),l11lll_l1_ (u"ࠪࠫ⟅"),l11lll_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ⟆"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭⟇"),l11lll_l1_ (u"࠭ࠧ⟈"),l1l111111_l1_,l11l1ll1l_l1_)
	# https://l1ll1llll1l_l1_.l111l11l1l_l1_.download/?id=__1lll11l11l_l1_
	l1lll111l11_l1_ = re.findall(l11lll_l1_ (u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⟉"),l1lll11l1ll_l1_,re.DOTALL)
	if l1lll111l11_l1_:
		l11l11l_l1_ = l1lll111l11_l1_[0]#+l11lll_l1_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࡩࡶࡷࡴ࠿࠵࠯࠸࠻࠱࠵࠻࠻࠮࠳࠶࠵࠲࠽࠺࠺࠵࠳࠷࠹ࠬ⟊")
		if l11l11l_l1_!=l11lll_l1_ (u"ࠩࠪ⟋") and l11lll_l1_ (u"ࠪࡹࡵࡲ࡯ࡢࡦࡨࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࡰࡹࡱࡰࡴࡧࡤࠨ⟌") in l11l11l_l1_ and l11lll_l1_ (u"ࠫ࠴ࡅࡩࡥ࠿ࡢࠫ⟍") not in l11l11l_l1_:
			l11lll1l_l1_ = OPENURL_CACHED(l11111l_l1_,l11l11l_l1_,l11lll_l1_ (u"ࠬ࠭⟎"),l11lll_l1_ (u"࠭ࠧ⟏"),l11lll_l1_ (u"ࠧࠨ⟐"),l11lll_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ⟑"))
			l1ll1ll11ll_l1_ = re.findall(l11lll_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⟒"),l11lll1l_l1_,re.DOTALL)
			if l1ll1ll11ll_l1_:
				for link,l11l111l_l1_ in l1ll1ll11ll_l1_:
					l1111_l1_.append(link+l11lll_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡩࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࡱࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲࡶ࠴ࡠࡡࠪ⟓")+l11l111l_l1_)
			else:
				server = l11l11l_l1_.split(l11lll_l1_ (u"ࠫ࠴࠭⟔"))[2]
				l1111_l1_.append(l11l11l_l1_+l11lll_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⟕")+server+l11lll_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⟖"))
		elif l11l11l_l1_!=l11lll_l1_ (u"ࠧࠨ⟗"):
			#DIALOG_OK(l11lll_l1_ (u"ࠨࠩ⟘"),l11lll_l1_ (u"ࠩࠪ⟙"),l11l11l_l1_,str(l1lll111l11_l1_))
			server = l11l11l_l1_.split(l11lll_l1_ (u"ࠪ࠳ࠬ⟚"))[2]
			l1111_l1_.append(l11l11l_l1_+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⟛")+server+l11lll_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⟜"))
	# https://l1ll1lll11l_l1_.cc/l1lll11l111_l1_
	# https://l1lll111l1l_l1_.l1ll1lll111_l1_/l1lll11l111_l1_
	l1ll1llll11_l1_ = re.findall(l11lll_l1_ (u"࠭࠼ࡵࡣࡥࡰࡪࠦࡣ࡭ࡣࡶࡷࡂࠨࡤ࡭ࡵࡢࡸࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ⟝"),l1ll1lllll1_l1_,re.DOTALL)
	if l1ll1llll11_l1_:
		l1ll1llll11_l1_ = l1ll1llll11_l1_[0]
		l1lll1111l1_l1_ = re.findall(l11lll_l1_ (u"ࠧ࠽ࡶࡧࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⟞"),l1ll1llll11_l1_,re.DOTALL)
		if l1lll1111l1_l1_:
			for l11l111l_l1_,link in l1lll1111l1_l1_:
				if l11lll_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ⟟") not in link: continue
				if link.count(l11lll_l1_ (u"ࠩ࠲ࠫ⟠"))>=2:
					server = link.split(l11lll_l1_ (u"ࠪ࠳ࠬ⟡"))[2]
					l1111_l1_.append(link+l11lll_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⟢")+server+l11lll_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡢࡱࡵ࠺࡟ࡠࠩ⟣")+l11l111l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ⟤"), l1111_l1_)
	#if l1l_l1_ == -1 : return
	l1ll1lll1ll_l1_ = []
	for link in l1111_l1_:
		# faselhd	https://l1llll1ll1_l1_.l111l11l1l_l1_.l1ll1ll1l1l_l1_/l1lll111ll1_l1_/l11ll1l1l_l1_/فيلم-the-l1lll111lll_l1_-l1lll111111_l1_-l1ll1ll1l11_l1_-2017-مترجم/l1ll1llllll_l1_
		#if l11lll_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ⟥") in link: continue
		#if l11lll_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵࡅ࡮ࡢ࡯ࡨࠫ⟦") in link: continue
		#if l11lll_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ⟧") in link: continue
		#if l11lll_l1_ (u"ࠪࡱࡾ࡫ࡧࡺࡸ࡬ࡴࠬ⟨") not in link: continue
		l1ll1lll1ll_l1_.append(link)
	#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ⟩"), l1ll1lll1ll_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1ll1lll1ll_l1_,script_name,l11lll_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⟪"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11lll_l1_ (u"࠭ࠧ⟫"): search = OPEN_KEYBOARD()
	if search==l11lll_l1_ (u"ࠧࠨ⟬"): return
	l111l1l_l1_ = search.replace(l11lll_l1_ (u"ࠨࠢࠪ⟭"),l11lll_l1_ (u"ࠩ࠮ࠫ⟮"))
	html = OPENURL_CACHED(l1lll1111_l1_,l11ll1_l1_,l11lll_l1_ (u"ࠪࠫ⟯"),l11lll_l1_ (u"ࠫࠬ⟰"),l11lll_l1_ (u"ࠬ࠭⟱"),l11lll_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ⟲"))
	token = re.findall(l11lll_l1_ (u"ࠧ࡯ࡣࡰࡩࡂࠨ࡟ࡵࡱ࡮ࡩࡳࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⟳"),html,re.DOTALL)
	if token:
		url = l11ll1_l1_+l11lll_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡢࡸࡴࡱࡥ࡯࠿ࠪ⟴")+token[0]+l11lll_l1_ (u"ࠩࠩࡵࡂ࠭⟵")+l111l1l_l1_
		l1111l_l1_(url)
		#DIALOG_OK(l11lll_l1_ (u"ࠪࠫ⟶"),l11lll_l1_ (u"ࠫࠬ⟷"),l11lll_l1_ (u"ࠬ࠭⟸"), l11lll_l1_ (u"࠭ࠧ⟹"))
	return
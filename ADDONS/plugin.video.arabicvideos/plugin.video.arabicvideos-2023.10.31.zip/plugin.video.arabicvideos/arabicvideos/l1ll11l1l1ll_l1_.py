# -*- coding: utf-8 -*-
import sys
l1l1ll_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l1l11_l1_ = 7
def l11lll_l1_ (l1_l1_):
    global l1l1l1l_l1_
    l1ll111_l1_ = ord (l1_l1_ [-1])
    l1ll11_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1ll111_l1_ % len (l1ll11_l1_)
    l1lll1l_l1_ = l1ll11_l1_ [:l1lll_l1_] + l1ll11_l1_ [l1lll_l1_:]
    if l1l1ll_l1_:
        l11l1l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    else:
        l11l1l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1ll1l_l1_ + l1ll111_l1_) % l1l11_l1_) for l1ll1l_l1_, char in enumerate (l1lll1l_l1_)])
    return eval (l11l1l_l1_)
from LIBSTWO import *
script_name = l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠭䎥")
l11ll1_l1_ = l1ll11l_l1_[l11lll_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ䎦")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11lll_l1_ (u"ࠨ࠲ࠪ䎧"),True)
	elif mode==102: results = ITEMS(l11lll_l1_ (u"ࠩ࠴ࠫ䎨"),True)
	elif mode==103: results = ITEMS(l11lll_l1_ (u"ࠪ࠶ࠬ䎩"),True)
	elif mode==104: results = ITEMS(l11lll_l1_ (u"ࠫ࠸࠭䎪"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11lll_l1_ (u"ࠬ࠺ࠧ䎫"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11lll_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䎬"),l11lll_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭䎭")+l11lll_l1_ (u"ࠨไ๋หห๋ࠠโ์า๎ํํวหࠢࡐ࠷࡚࠭䎮"),l11lll_l1_ (u"ࠩࠪ䎯"),762)
	addMenuItem(l11lll_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎰"),l11lll_l1_ (u"ࠫࡤࡏࡐࡕࡡࠪ䎱")+l11lll_l1_ (u"่่ࠬศศ่ࠤๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠫ䎲"),l11lll_l1_ (u"࠭ࠧ䎳"),761)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䎴"),l11lll_l1_ (u"ࠨࡡࡗ࡚࠵ࡥࠧ䎵")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡ็้ࠤ๊๎วใ฻๊หࠥอไฤื็๎ฮ࠭䎶"),l11lll_l1_ (u"ࠪࠫ䎷"),101)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎸"),l11lll_l1_ (u"ࠬࡥࡔࡗ࠶ࡢࠫ䎹")+l11lll_l1_ (u"࠭โ็๊สฮ๋ࠥฮหษิอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ䎺"),l11lll_l1_ (u"ࠧࠨ䎻"),106)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎼"),l11lll_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ䎽")+l11lll_l1_ (u"ࠪๆ๋๎วหࠢ฼ีอ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ䎾"),l11lll_l1_ (u"ࠫࠬ䎿"),147)
	addMenuItem(l11lll_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䏀"),l11lll_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ䏁")+l11lll_l1_ (u"ࠧใ่๋หฯࠦรอ่ห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ䏂"),l11lll_l1_ (u"ࠨࠩ䏃"),148)
	addMenuItem(l11lll_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏄"),l11lll_l1_ (u"ࠪࡣࡎࡌࡌࡠࠩ䏅")+l11lll_l1_ (u"ࠫࠥࠦโ็ษฬࠤว๐ࠠโ์็้๋ࠥๆࠡ็๋ๆ฾ํๅࠡࠢࠪ䏆"),l11lll_l1_ (u"ࠬ࠭䏇"),28)
	addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䏈"),l11lll_l1_ (u"ࠧࡠࡏࡕࡊࡤ࠭䏉")+l11lll_l1_ (u"ࠨไ้หฮࠦวๅ็฼หึ็ࠠๆ่้ࠣํู่่็ࠪ䏊"),l11lll_l1_ (u"ࠩࠪ䏋"),41)
	#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䏌"),l11lll_l1_ (u"ࠫࡤࡑࡗࡕࡡࠪ䏍")+l11lll_l1_ (u"่ࠬๆศหࠣห้้่ฬำ้๋ࠣࠦๅ้ไ฼๋๊࠭䏎"),l11lll_l1_ (u"࠭ࠧ䏏"),135)
	addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䏐"),l11lll_l1_ (u"ࠨࡡࡓࡒ࡙ࡥࠧ䏑")+l11lll_l1_ (u"ࠩๅ๊ฬฯ่ࠠๆสࠤ๊์ࠠๆ๊ๅ฽ࠥฮว็์อࠫ䏒"),l11lll_l1_ (u"ࠪࠫ䏓"),38)
	addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䏔"),l11lll_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䏕"),l11lll_l1_ (u"࠭ࠧ䏖"),9999)
	addMenuItem(l11lll_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䏗"),l11lll_l1_ (u"ࠨࡡࡗ࡚࠶ࡥࠧ䏘")+l11lll_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ฾อๅสࠩ䏙"),l11lll_l1_ (u"ࠪࠫ䏚"),102)
	addMenuItem(l11lll_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䏛"),l11lll_l1_ (u"ࠬࡥࡔࡗ࠴ࡢࠫ䏜")+l11lll_l1_ (u"࠭โ็๊สฮࠥะไโิํ์๋๐ษࠡะสูฮ࠭䏝"),l11lll_l1_ (u"ࠧࠨ䏞"),103)
	addMenuItem(l11lll_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䏟"),l11lll_l1_ (u"ࠩࡢࡘ࡛࠹࡟ࠨ䏠")+l11lll_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ํอ๊ࠥไโฯุࠫ䏡"),l11lll_l1_ (u"ࠫࠬ䏢"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l111ll_l1_ = l11lll_l1_ (u"ࠬࡥࡔࡗࠩ䏣")+menu+l11lll_l1_ (u"࠭࡟ࠨ䏤")
	user = l11llll1l1l_l1_(32)
	payload = {l11lll_l1_ (u"ࠧࡪࡦࠪ䏥"):l11lll_l1_ (u"ࠨࠩ䏦"),l11lll_l1_ (u"ࠩࡸࡷࡪࡸࠧ䏧"):user,l11lll_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ䏨"):l11lll_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䏩"),l11lll_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ䏪"):menu}
	#data = l1ll1l1ll_l1_(payload)
	#LOG_THIS(l11lll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䏫"),str(payload))
	#LOG_THIS(l11lll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䏬"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䏭"), l11ll1_l1_, payload, l11lll_l1_ (u"ࠩࠪ䏮"), True,l11lll_l1_ (u"ࠪࠫ䏯"),l11lll_l1_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ䏰"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䏱"),l11ll1_l1_,payload,l11lll_l1_ (u"࠭ࠧ䏲"),l11lll_l1_ (u"ࠧࠨ䏳"),l11lll_l1_ (u"ࠨࠩ䏴"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䏵"))
	html = response.content
	#html = html.replace(l11lll_l1_ (u"ࠪࡠࡷ࠭䏶"),l11lll_l1_ (u"ࠫࠬ䏷"))
	#DIALOG_OK(l11lll_l1_ (u"ࠬ࠭䏸"),l11lll_l1_ (u"࠭ࠧ䏹"),html,html)
	#file = open(l11lll_l1_ (u"ࠧࡴ࠼࠲ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭䏺"), l11lll_l1_ (u"ࠨࡹࠪ䏻"))
	#file.write(html)
	#file.close()
	items = re.findall(l11lll_l1_ (u"ࠩࠫ࡟ࡣࡁ࡜ࡳ࡞ࡱࡡ࠰ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠪ䏼"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11lll_l1_ (u"ࠪࡥࡱ࠭䏽"),l11lll_l1_ (u"ࠫࡆࡲࠧ䏾"))
			start = start.replace(l11lll_l1_ (u"ࠬࡋ࡬ࠨ䏿"),l11lll_l1_ (u"࠭ࡁ࡭ࠩ䐀"))
			start = start.replace(l11lll_l1_ (u"ࠧࡂࡎࠪ䐁"),l11lll_l1_ (u"ࠨࡃ࡯ࠫ䐂"))
			start = start.replace(l11lll_l1_ (u"ࠩࡈࡐࠬ䐃"),l11lll_l1_ (u"ࠪࡅࡱ࠭䐄"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11lll_l1_ (u"ࠫࡆࡲ࠭ࠨ䐅"),l11lll_l1_ (u"ࠬࡇ࡬ࠨ䐆"))
			start = start.replace(l11lll_l1_ (u"࠭ࡁ࡭ࠢࠪ䐇"),l11lll_l1_ (u"ࠧࡂ࡮ࠪ䐈"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11lll11ll_l1_,name,l1llll_l1_ in items:
			if l11lll_l1_ (u"ࠨࠥࠪ䐉") in source: continue
			#if source in [l11lll_l1_ (u"ࠩࡑࡘࠬ䐊"),l11lll_l1_ (u"ࠪ࡝࡚࠭䐋"),l11lll_l1_ (u"ࠫ࡜࡙࠰ࠨ䐌"),l11lll_l1_ (u"ࠬࡘࡌ࠲ࠩ䐍"),l11lll_l1_ (u"࠭ࡒࡍ࠴ࠪ䐎")]: continue
			if source!=l11lll_l1_ (u"ࠧࡖࡔࡏࠫ䐏"): name = name+l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࠥࠦࠧ䐐")+source+l11lll_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䐑")
			url = source+l11lll_l1_ (u"ࠪ࠿ࡀ࠭䐒")+server+l11lll_l1_ (u"ࠫࡀࡁࠧ䐓")+l11lll11ll_l1_+l11lll_l1_ (u"ࠬࡁ࠻ࠨ䐔")+menu
			addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡸࡨࠫ䐕"),l111ll_l1_+l11lll_l1_ (u"ࠧࠨ䐖")+name,url,105,l1llll_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䐗"),l111ll_l1_+l11lll_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ䐘"),l11lll_l1_ (u"ࠪࠫ䐙"),9999)
		#if l1ll_l1_: DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䐚"),l11lll_l1_ (u"ࠬ࠭䐛"),l11lll_l1_ (u"࠭ࠧ䐜"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ䐝"))
		#addMenuItem(l11lll_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䐞"),l111ll_l1_+l11lll_l1_ (u"ࠩ็่ศูแࠡๆสࠤฯ๎ฬะࠢๅ๊ํอสࠡฬ็ๅื๎ๆ๋ห่่ࠣ࠭䐟"),l11lll_l1_ (u"ࠪࠫ䐠"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䐡"),l111ll_l1_+l11lll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็ห็ืศศรࠣ์ฬ๊วึัๅหฦࠦแใูࠪ䐢"),l11lll_l1_ (u"࠭ࠧ䐣"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䐤"),l11lll_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䐥"),l11lll_l1_ (u"ࠩࠪ䐦"),9999)
		#addMenuItem(l11lll_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䐧"),l111ll_l1_+l11lll_l1_ (u"࡚ࠫࡴࡦࡰࡴࡷࡹࡳࡧࡴࡦ࡮ࡼ࠰ࠥࡴ࡯ࠡࡖ࡙ࠤࡨ࡮ࡡ࡯ࡰࡨࡰࡸࠦࡦࡰࡴࠣࡽࡴࡻࠧ䐨"),l11lll_l1_ (u"ࠬ࠭䐩"),9999)
		#addMenuItem(l11lll_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䐪"),l111ll_l1_+l11lll_l1_ (u"ࠧࡊࡶࠣ࡭ࡸࠦࡦࡰࡴࠣࡶࡪࡲࡡࡵ࡫ࡹࡩࡸࠦࠦࠡࡨࡵ࡭ࡪࡴࡤࡴࠢࡲࡲࡱࡿࠧ䐫"),l11lll_l1_ (u"ࠨࠩ䐬"),9999)
	return
def PLAY(id):
	source,server,l11lll11ll_l1_,menu = id.split(l11lll_l1_ (u"ࠩ࠾࠿ࠬ䐭"))
	url = l11lll_l1_ (u"ࠪࠫ䐮")
	user = l11llll1l1l_l1_(32)
	if source==l11lll_l1_ (u"࡚ࠫࡘࡌࠨ䐯"): url = l11lll11ll_l1_
	elif source==l11lll_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䐰"):
		url = l1ll11l_l1_[l11lll_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䐱")][0]+l11lll_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ䐲")+l11lll11ll_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],script_name,l11lll_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭䐳"),url)
		return
	elif source==l11lll_l1_ (u"ࠩࡊࡅࠬ䐴"):
		payload = { l11lll_l1_ (u"ࠪ࡭ࡩ࠭䐵") : l11lll_l1_ (u"ࠫࠬ䐶"), l11lll_l1_ (u"ࠬࡻࡳࡦࡴࠪ䐷") : user , l11lll_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ䐸") : l11lll_l1_ (u"ࠧࡱ࡮ࡤࡽࡌࡇ࠱ࠨ䐹") , l11lll_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭䐺") : l11lll_l1_ (u"ࠩࠪ䐻") }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠪࡋࡊ࡚ࠧ䐼"),l11ll1_l1_,payload,l11lll_l1_ (u"ࠫࠬ䐽"),False,l11lll_l1_ (u"ࠬ࠭䐾"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䐿"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䑀"),l11lll_l1_ (u"ࠨࠩ䑁"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䑂"),l11lll_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ䑃"))
			return
		html = response.content
		cookies = response.cookies
		l1l1111l1lll_l1_ = cookies[l11lll_l1_ (u"ࠫࡆ࡙ࡐ࠯ࡐࡈࡘࡤ࡙ࡥࡴࡵ࡬ࡳࡳࡏࡤࠨ䑄")]
		url = response.headers[l11lll_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䑅")]
		payload = { l11lll_l1_ (u"࠭ࡩࡥࠩ䑆") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠧࡶࡵࡨࡶࠬ䑇") : user , l11lll_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ䑈") : l11lll_l1_ (u"ࠩࡳࡰࡦࡿࡇࡂ࠴ࠪ䑉") , l11lll_l1_ (u"ࠪࡱࡪࡴࡵࠨ䑊") : l11lll_l1_ (u"ࠫࠬ䑋") }
		headers = { l11lll_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䑌") : l11lll_l1_ (u"࠭ࡁࡔࡒ࠱ࡒࡊ࡚࡟ࡔࡧࡶࡷ࡮ࡵ࡮ࡊࡦࡀࠫ䑍")+l1l1111l1lll_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠧࡈࡇࡗࠫ䑎"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"ࠨࠩ䑏"),l11lll_l1_ (u"ࠩࠪ䑐"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ䑑"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䑒"),l11lll_l1_ (u"ࠬ࠭䑓"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䑔"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ䑕"))
			return
		html = response.content
		url = re.findall(l11lll_l1_ (u"ࠨࡴࡨࡷࡵࠨ࠺ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࡰ࠷ࡺ࠾ࠩࠩ࠰࠭ࡃ࠮ࠨࠧ䑖"),html,re.DOTALL)
		link = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11lll_l1_ (u"ࠩࠪ䑗"),l11lll_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭ࠣࠫ䑘")+link)
		#LOG_THIS(l11lll_l1_ (u"ࠫࠬ䑙"),l11lll_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯ࠥ࠭䑚")+params)
		l1l1111l1ll1_l1_ = l11lll_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠳࠹࠰ࠪ䑛")+server+l11lll_l1_ (u"ࠧ࠸࠹࠺࠳ࠬ䑜")+l11lll11ll_l1_+l11lll_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ䑝")+params
		l1l1111l1l1l_l1_ = l1l1111l1ll1_l1_.replace(l11lll_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ䑞"),l11lll_l1_ (u"ࠪ࠸࠵ࡀ࠷ࠨ䑟")).replace(l11lll_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭䑠"),l11lll_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䑡"))
		l1l1111ll111_l1_ = l1l1111l1ll1_l1_.replace(l11lll_l1_ (u"࠭࠳࠷࠼࠺ࠫ䑢"),l11lll_l1_ (u"ࠧ࠵࠴࠽࠻ࠬ䑣")).replace(l11lll_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ䑤"),l11lll_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ䑥"))
		l1lll1ll_l1_ = [l11lll_l1_ (u"ࠪࡌࡉ࠭䑦"),l11lll_l1_ (u"ࠫࡘࡊ࠱ࠨ䑧"),l11lll_l1_ (u"࡙ࠬࡄ࠳ࠩ䑨")]
		l1111_l1_ = [l1l1111l1ll1_l1_,l1l1111l1l1l_l1_,l1l1111ll111_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11lll_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䑩"), l1lll1ll_l1_)
		if l1l_l1_ == -1: return
		else: url = l1111_l1_[l1l_l1_]
	elif source==l11lll_l1_ (u"ࠧࡏࡖࠪ䑪"):
		headers = { l11lll_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䑫") : l11lll_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ䑬") }
		payload = { l11lll_l1_ (u"ࠪ࡭ࡩ࠭䑭") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠫࡺࡹࡥࡳࠩ䑮") : user , l11lll_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ䑯") : l11lll_l1_ (u"࠭ࡰ࡭ࡣࡼࡒ࡙࠭䑰") , l11lll_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ䑱") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠨࡒࡒࡗ࡙࠭䑲"), l11ll1_l1_, payload, headers, False,l11lll_l1_ (u"ࠩࠪ䑳"),l11lll_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ䑴"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠫࠬ䑵"),l11lll_l1_ (u"ࠬ࠭䑶"),l11lll_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䑷"),l11lll_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ䑸"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䑹")]
		url = url.replace(l11lll_l1_ (u"ࠩࠨ࠶࠵࠭䑺"),l11lll_l1_ (u"ࠪࠤࠬ䑻"))
		url = url.replace(l11lll_l1_ (u"ࠫࠪ࠹ࡄࠨ䑼"),l11lll_l1_ (u"ࠬࡃࠧ䑽"))
		if l11lll_l1_ (u"࠭ࡌࡦࡣࡵࡲࠬ䑾") in l11lll11ll_l1_:
			url = url.replace(l11lll_l1_ (u"ࠧࡏࡖࡑࡒ࡮ࡲࡥࠨ䑿"),l11lll_l1_ (u"ࠨࠩ䒀"))
			url = url.replace(l11lll_l1_ (u"ࠩ࡯ࡩࡦࡸ࡮ࡪࡰࡪ࠵ࠬ䒁"),l11lll_l1_ (u"ࠪࡐࡪࡧࡲ࡯࡫ࡱ࡫ࠬ䒂"))
	elif source==l11lll_l1_ (u"ࠫࡕࡒࠧ䒃"):
		#headers = { l11lll_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䒄") : l11lll_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䒅") }
		payload = { l11lll_l1_ (u"ࠧࡪࡦࠪ䒆") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠨࡷࡶࡩࡷ࠭䒇") : user , l11lll_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ䒈") : l11lll_l1_ (u"ࠪࡴࡱࡧࡹࡑࡎࠪ䒉") , l11lll_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ䒊") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"ࠬࡖࡏࡔࡖࠪ䒋"), l11ll1_l1_, payload, l11lll_l1_ (u"࠭ࠧ䒌"),False,l11lll_l1_ (u"ࠧࠨ䒍"),l11lll_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ䒎"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠩࠪ䒏"),l11lll_l1_ (u"ࠪࠫ䒐"),l11lll_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䒑"),l11lll_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭䒒"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䒓")]
		headers = {l11lll_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䒔"):response.headers[l11lll_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䒕")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䒖"),url, l11lll_l1_ (u"ࠪࠫ䒗"),headers , l11lll_l1_ (u"ࠫࠬ䒘"),l11lll_l1_ (u"ࠬ࠭䒙"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ䒚"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠧࠨ䒛"),l11lll_l1_ (u"ࠨࠩ䒜"),l11lll_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䒝"),l11lll_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ䒞"))
			return
		html = response.content
		items = re.findall(l11lll_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䒟"),html,re.DOTALL)
		url = items[0]
	elif source in [l11lll_l1_ (u"࡚ࠬࡁࠨ䒠"),l11lll_l1_ (u"࠭ࡆࡎࠩ䒡"),l11lll_l1_ (u"࡚ࠧࡗࠪ䒢"),l11lll_l1_ (u"ࠨ࡙ࡖ࠵ࠬ䒣"),l11lll_l1_ (u"࡚ࠩࡗ࠷࠭䒤"),l11lll_l1_ (u"ࠪࡖࡑ࠷ࠧ䒥"),l11lll_l1_ (u"ࠫࡗࡒ࠲ࠨ䒦")]:
		if source==l11lll_l1_ (u"࡚ࠬࡁࠨ䒧"): l11lll11ll_l1_ = id
		headers = { l11lll_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䒨") : l11lll_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭䒩") }
		payload = { l11lll_l1_ (u"ࠨ࡫ࡧࠫ䒪") : l11lll11ll_l1_ , l11lll_l1_ (u"ࠩࡸࡷࡪࡸࠧ䒫") : user , l11lll_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ䒬") : l11lll_l1_ (u"ࠫࡵࡲࡡࡺࠩ䒭")+source , l11lll_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ䒮") : menu }
		response = OPENURL_REQUESTS_CACHED(l1lll1111_l1_,l11lll_l1_ (u"࠭ࡐࡐࡕࡗࠫ䒯"),l11ll1_l1_,payload,headers,l11lll_l1_ (u"ࠧࠨ䒰"),l11lll_l1_ (u"ࠨࠩ䒱"),l11lll_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ䒲"))
		if not response.succeeded:
			DIALOG_OK(l11lll_l1_ (u"ࠪࠫ䒳"),l11lll_l1_ (u"ࠫࠬ䒴"),l11lll_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䒵"),l11lll_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ䒶"))
			return
		html = response.content
		url = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䒷")]
		if source==l11lll_l1_ (u"ࠨࡈࡐࠫ䒸"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11lll_l1_ (u"ࠩࡊࡉ࡙࠭䒹"), url, l11lll_l1_ (u"ࠪࠫ䒺"), l11lll_l1_ (u"ࠫࠬ䒻"), False,l11lll_l1_ (u"ࠬ࠭䒼"),l11lll_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠼ࡺࡨࠨ䒽"))
			url = response.headers[l11lll_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䒾")]
			url = url.replace(l11lll_l1_ (u"ࠨࡪࡷࡸࡵࡹࠧ䒿"),l11lll_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䓀"))
	PLAY_VIDEO(url,script_name,l11lll_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䓁"))
	return
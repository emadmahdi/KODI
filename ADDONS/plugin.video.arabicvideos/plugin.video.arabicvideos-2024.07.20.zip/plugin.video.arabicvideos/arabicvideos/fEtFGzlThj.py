# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from TEsNM9QVZc import *
X69Fkr1VNnf2pJQC8wl7YR4HmaKc(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࡙ࠫࡋࡓࡕࠩయ"),s0vAWcLSXEToH9Mik134q(u"࡚ࠬࡅࡔࡖࠪర"))
MAs8kRan5hr1xCVqbTLDY4 = Xr2aHOK0huQ5DTS(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡱࡸ࠷࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡴࡩ࡫ࡱ࡯ࡧࡸ࡯ࡢࡦࡥࡥࡳࡪ࠮ࡤࡱࡰ࠳࠶࠶ࡍࡃ࠰ࡽ࡭ࡵ࠭ఱ")
MAs8kRan5hr1xCVqbTLDY4 = JJu4MPClbTFpUwHiN(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲࡨࡩࡩࡺࡥࡴࡶ࠱ࡪࡹࡶ࠮ࡰࡶࡨࡲࡪࡺ࠮ࡨࡴ࠲ࡪ࡮ࡲࡥࡴ࠱ࡷࡩࡸࡺ࠱࠱࠲࡮࠲ࡩࡨࠧల")
HMm6TqGlgU75axyS(MAs8kRan5hr1xCVqbTLDY4,{},XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
XCapNbgw2xWQ5jRt = K7bLVaiRkx0lgU5SQM(u"ࠨࡅ࠽ࡠࡡ࡚ࡅࡎࡒ࡟ࡠࡹ࡫࡭ࡱ࡞࡟ࡥࡦࠦࡢࡣ࡞࡟ๅา฻࠮࡮ࡲ࠶ࠫళ")
XCapNbgw2xWQ5jRt = OOhnpQ8XvCVclGqdu(u"ࠩࡆ࠾ࡡࡢࡔࡆࡏࡓࡠࡡࡺࡥ࡮ࡲ࡟ࡠࡦࡧࠠࡣࡤ࡟ࡠ࡫࡯࡬ࡦࡡ࠷࠼࠸࠺࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧఴ")
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'SHOOFMAX'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_SHM_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
PTKgtGhwsW51oZ3uQImn6Czd0ERNyb = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][1]
LaxG4UKghdS8CeFO = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][2]
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==50: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==51: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	elif mode==52: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==53: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==55: W9lfsoMawqOzpQcXD = U2U1l9nrMbhDApcBPC()
	elif mode==56: W9lfsoMawqOzpQcXD = QKqiUPf8g9jVG3FR1o7()
	elif mode==57: W9lfsoMawqOzpQcXD = G5vmLAlwhJ(url,1)
	elif mode==58: W9lfsoMawqOzpQcXD = G5vmLAlwhJ(url,2)
	elif mode==59: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,59,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المسلسلات',QigevCplXxbPI1H,56)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الافلام',QigevCplXxbPI1H,55)
	return QigevCplXxbPI1H
def U2U1l9nrMbhDApcBPC():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أفلام مرتبة بسنة الإنتاج',vxQUXEuH9m+'/movie/1/yop',57)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أفلام مرتبة بالأفضل تقييم',vxQUXEuH9m+'/movie/1/review',57)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أفلام مرتبة بالأكثر مشاهدة',vxQUXEuH9m+'/movie/1/views',57)
	return
def QKqiUPf8g9jVG3FR1o7():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات مرتبة بسنة الإنتاج',vxQUXEuH9m+'/series/1/yop',57)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات مرتبة بالأفضل تقييم',vxQUXEuH9m+'/series/1/review',57)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات مرتبة بالأكثر مشاهدة',vxQUXEuH9m+'/series/1/views',57)
	return
def ddbEXhWzOnIaR(url):
	if '?' in url:
		WShVouXDRCGjeIFMYTHyimk5dlz = url.split('?')
		url = WShVouXDRCGjeIFMYTHyimk5dlz[0]
		filter = '?' + sqXK91rDldVAEcRTSQL4n2tbC(WShVouXDRCGjeIFMYTHyimk5dlz[1],'=&:/%')
	else: filter = QigevCplXxbPI1H
	type,JJM6TofH4g5n7SRwq,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': dbCzTyu4VLtwxoQvqnHjiGUK='فيلم'
		elif type=='series': dbCzTyu4VLtwxoQvqnHjiGUK='مسلسل'
		url = vxQUXEuH9m + '/genre/filter/' + sqXK91rDldVAEcRTSQL4n2tbC(dbCzTyu4VLtwxoQvqnHjiGUK) + '/' + JJM6TofH4g5n7SRwq + '/' + sort + filter
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHOOFMAX-TITLES-1st')
		items = sBvufaD6c9YHdOqTjCQ3.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		VVRDy0CmOdJ3rh=0
		for id,title,UUGTWX38MNznCsOLbt4Fy1w5ph,cXu4fN1moCypJqb72OZvd in items:
			VVRDy0CmOdJ3rh += 1
			cXu4fN1moCypJqb72OZvd = LaxG4UKghdS8CeFO + '/v2/img/program/main/' + cXu4fN1moCypJqb72OZvd + '-2.jpg'
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m + '/program/' + id
			if type=='movie': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,53,cXu4fN1moCypJqb72OZvd)
			if type=='series': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسل '+title,RMC6c2kL5hGOnFaIwAyb+'?ep='+UUGTWX38MNznCsOLbt4Fy1w5ph+'='+title+'='+cXu4fN1moCypJqb72OZvd,52,cXu4fN1moCypJqb72OZvd)
	else:
		if type=='movie': dbCzTyu4VLtwxoQvqnHjiGUK='movies'
		elif type=='series': dbCzTyu4VLtwxoQvqnHjiGUK='series'
		url = PTKgtGhwsW51oZ3uQImn6Czd0ERNyb + '/json/selected/' + sort + '-' + dbCzTyu4VLtwxoQvqnHjiGUK + '-WW.json'
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHOOFMAX-TITLES-2nd')
		items = sBvufaD6c9YHdOqTjCQ3.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		VVRDy0CmOdJ3rh=0
		for id,UUGTWX38MNznCsOLbt4Fy1w5ph,cXu4fN1moCypJqb72OZvd,title in items:
			VVRDy0CmOdJ3rh += 1
			cXu4fN1moCypJqb72OZvd = PTKgtGhwsW51oZ3uQImn6Czd0ERNyb + '/img/program/' + cXu4fN1moCypJqb72OZvd + '-2.jpg'
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m + '/program/' + id
			if type=='movie': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,53,cXu4fN1moCypJqb72OZvd)
			elif type=='series': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسل '+title,RMC6c2kL5hGOnFaIwAyb+'?ep='+UUGTWX38MNznCsOLbt4Fy1w5ph+'='+title+'='+cXu4fN1moCypJqb72OZvd,52,cXu4fN1moCypJqb72OZvd)
	title='صفحة '
	if VVRDy0CmOdJ3rh==16:
		for Ywybq20VuIGB6OKfiPZpR in range(1,13) :
			if not JJM6TofH4g5n7SRwq==str(Ywybq20VuIGB6OKfiPZpR):
				url = vxQUXEuH9m+'/genre/filter/'+type+'/'+str(Ywybq20VuIGB6OKfiPZpR)+'/'+sort+filter
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title+str(Ywybq20VuIGB6OKfiPZpR),url,51)
	return
def oB2rmVgqUND(url):
	WShVouXDRCGjeIFMYTHyimk5dlz = url.split('=')
	UUGTWX38MNznCsOLbt4Fy1w5ph = int(WShVouXDRCGjeIFMYTHyimk5dlz[1])
	name = MVkP7zfWlxUXj(WShVouXDRCGjeIFMYTHyimk5dlz[2])
	name = name.replace('_MOD_مسلسل ',QigevCplXxbPI1H)
	cXu4fN1moCypJqb72OZvd = WShVouXDRCGjeIFMYTHyimk5dlz[3]
	url = url.split('?')[0]
	if UUGTWX38MNznCsOLbt4Fy1w5ph==0:
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHOOFMAX-EPISODES-1st')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<select(.*?)</select>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('option value="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		UUGTWX38MNznCsOLbt4Fy1w5ph = int(items[-1])
	for V1nZX7O5WwEq8HmvkY in range(UUGTWX38MNznCsOLbt4Fy1w5ph,0,-1):
		RMC6c2kL5hGOnFaIwAyb = url + '?ep=' + str(V1nZX7O5WwEq8HmvkY)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(V1nZX7O5WwEq8HmvkY)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,53,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHOOFMAX-PLAY-1st')
	S1RbytKdcEiXU = sBvufaD6c9YHdOqTjCQ3.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if S1RbytKdcEiXU:
		B3TKLo71hAGRqYgV0 = S1RbytKdcEiXU[1].replace('T',f1p0IN8alhrDKHyvqWk9UZ)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+aSBkt4OU8JpWTEzVIHjAiv+B3TKLo71hAGRqYgV0)
		return
	OL9Z18DkqBnQJW4ehuT,A0AFmwCGoXbxr3Js4EgljhScQNDut = [],[]
	sYjQvxDnZGWT6uV4X5 = sBvufaD6c9YHdOqTjCQ3.findall('var origin_link = "(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	eDd3UgATK8WSMiZlyQrJN = sBvufaD6c9YHdOqTjCQ3.findall('var backup_origin_link = "(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('hls: (.*?)_link\+"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for bSrdN78jxURTvh9,RMC6c2kL5hGOnFaIwAyb in rsBojxT8UZwL:
		if 'backup' in bSrdN78jxURTvh9:
			bSrdN78jxURTvh9 = 'backup server'
			url = eDd3UgATK8WSMiZlyQrJN + RMC6c2kL5hGOnFaIwAyb
		else:
			bSrdN78jxURTvh9 = 'main server'
			url = sYjQvxDnZGWT6uV4X5 + RMC6c2kL5hGOnFaIwAyb
		if '.m3u8' in url:
			OL9Z18DkqBnQJW4ehuT.append(url)
			A0AFmwCGoXbxr3Js4EgljhScQNDut.append('m3u8  '+bSrdN78jxURTvh9)
	rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	rsBojxT8UZwL += sBvufaD6c9YHdOqTjCQ3.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for bSrdN78jxURTvh9,RMC6c2kL5hGOnFaIwAyb in rsBojxT8UZwL:
		filename = RMC6c2kL5hGOnFaIwAyb.split('/')[-1]
		filename = filename.replace('fallback',QigevCplXxbPI1H)
		filename = filename.replace('.mp4',QigevCplXxbPI1H)
		filename = filename.replace('-',QigevCplXxbPI1H)
		if 'backup' in bSrdN78jxURTvh9:
			bSrdN78jxURTvh9 = 'backup server'
			url = eDd3UgATK8WSMiZlyQrJN + RMC6c2kL5hGOnFaIwAyb
		else:
			bSrdN78jxURTvh9 = 'main server'
			url = sYjQvxDnZGWT6uV4X5 + RMC6c2kL5hGOnFaIwAyb
		OL9Z18DkqBnQJW4ehuT.append(url)
		A0AFmwCGoXbxr3Js4EgljhScQNDut.append('mp4  '+bSrdN78jxURTvh9+eZXCHufT9YW4bRErSBOLmI+filename)
	HHZ6579kAv8 = zYWJO03iISD('Select Video Quality:', A0AFmwCGoXbxr3Js4EgljhScQNDut)
	if HHZ6579kAv8 == -1 : return
	url = OL9Z18DkqBnQJW4ehuT[HHZ6579kAv8]
	B9BaTCd86Iwz1e3sRMXZylKpcHU(url,PuT0IphGNsketAQ,'video')
	return
def G5vmLAlwhJ(url,type):
	if 'series' in url: Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m + '/genre/مسلسل'
	else: Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m + '/genre/فيلم'
	Kj0TOU6BmSMlJHZYLd = sqXK91rDldVAEcRTSQL4n2tbC(Kj0TOU6BmSMlJHZYLd)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHOOFMAX-FILTERS-1st')
	if type==1: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('subgenre(.*?)div',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type==2: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('country(.*?)div',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('option value="(.*?)">(.*?)</option',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if type==1:
		for uulza3bWMcp2rvVN4TFU,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url+'?subgenre='+uulza3bWMcp2rvVN4TFU,58)
	elif type==2:
		url,uulza3bWMcp2rvVN4TFU = url.split('?')
		for cQW2wk0yK9LeChBnsoAOuVaF8,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url+'?country='+cQW2wk0yK9LeChBnsoAOuVaF8+'&'+uulza3bWMcp2rvVN4TFU,51)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search: search = XAfEvmh95VkgurjdiJ()
	if not search: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	url = vxQUXEuH9m+'/search?q='+VIo6FYRkx0MLP4wufEGsgnz9
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,True,QigevCplXxbPI1H,'SHOOFMAX-SEARCH-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('general-body(.*?)search-bottom-padding',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items:
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			url = vxQUXEuH9m + RMC6c2kL5hGOnFaIwAyb
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+sqXK91rDldVAEcRTSQL4n2tbC(title)+'='+cXu4fN1moCypJqb72OZvd
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,52,cXu4fN1moCypJqb72OZvd)
				else:
					title = '_MOD_فيلم '+title
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,53,cXu4fN1moCypJqb72OZvd)
	return
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'GLOBALSEARCH'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_GLS_'
def YnMSWTbKj1N8wuRJVF(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XCapNbgw2xWQ5jRt,d8kolNVuLsPAjQZ9ROpUHBgix,JJM6TofH4g5n7SRwq):
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==540: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==541: W9lfsoMawqOzpQcXD = AMBXS0OocamvkiPlC(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==542: W9lfsoMawqOzpQcXD = I1rJCWByhPcexmbzv2qkD8VgQEd(d8kolNVuLsPAjQZ9ROpUHBgix,XCapNbgw2xWQ5jRt,JJM6TofH4g5n7SRwq)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==549: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(d8kolNVuLsPAjQZ9ROpUHBgix)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','بحث جديد',QigevCplXxbPI1H,549)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]',QigevCplXxbPI1H,9999)
	h5F4d6SCMfg = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'dict','GLOBALSEARCH_SITES')
	if h5F4d6SCMfg:
		h5F4d6SCMfg = h5F4d6SCMfg['__SEQUENCED_COLUMNS__']
		for IghAzcTSrx1Wq6 in reversed(h5F4d6SCMfg):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',IghAzcTSrx1Wq6,QigevCplXxbPI1H,549,QigevCplXxbPI1H,QigevCplXxbPI1H,IghAzcTSrx1Wq6)
	return
def UJL7oB1rySs6ERpjGnhvz(IghAzcTSrx1Wq6):
	if not IghAzcTSrx1Wq6:
		IghAzcTSrx1Wq6 = XAfEvmh95VkgurjdiJ()
		if not IghAzcTSrx1Wq6: return
		IghAzcTSrx1Wq6 = IghAzcTSrx1Wq6.lower()
	gKMPH8ajYeX45Vz0yr = IghAzcTSrx1Wq6.replace(iiWOIMsq4w3zkHdyo0CEDm2vGhnB,QigevCplXxbPI1H)
	o7ndafyeqi9BjhUsDxNcEQuY(gKMPH8ajYeX45Vz0yr)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','عمل بحث جماعي - '+gKMPH8ajYeX45Vz0yr,'search_sites',542,QigevCplXxbPI1H,QigevCplXxbPI1H,gKMPH8ajYeX45Vz0yr)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','عمل بحث منفرد - '+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,541,QigevCplXxbPI1H,QigevCplXxbPI1H,gKMPH8ajYeX45Vz0yr)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','نتائج البحث مفصلة - '+gKMPH8ajYeX45Vz0yr,'opened_sites',542,QigevCplXxbPI1H,QigevCplXxbPI1H,gKMPH8ajYeX45Vz0yr)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','نتائج البحث مقسمة - '+gKMPH8ajYeX45Vz0yr,'listed_sites',542,QigevCplXxbPI1H,QigevCplXxbPI1H,gKMPH8ajYeX45Vz0yr)
	return
def o7ndafyeqi9BjhUsDxNcEQuY(NNIQlXHFBGRUhYmVyELcb82zO3):
	kWn5YPuO7aHgrGRx81eiKADb9L = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','GLOBALSEARCH_SITES',NNIQlXHFBGRUhYmVyELcb82zO3)
	XV3njU1vaYQ4DfJegIECo6cx = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','GLOBALSEARCH_SITES',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+NNIQlXHFBGRUhYmVyELcb82zO3)
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_SITES',NNIQlXHFBGRUhYmVyELcb82zO3)
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_SITES',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+NNIQlXHFBGRUhYmVyELcb82zO3)
	llHVwuFIG1PsQ89jvzBXCaZxi = kWn5YPuO7aHgrGRx81eiKADb9L+XV3njU1vaYQ4DfJegIECo6cx
	if llHVwuFIG1PsQ89jvzBXCaZxi: NNIQlXHFBGRUhYmVyELcb82zO3 = iiWOIMsq4w3zkHdyo0CEDm2vGhnB+NNIQlXHFBGRUhYmVyELcb82zO3
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_SITES',NNIQlXHFBGRUhYmVyELcb82zO3,llHVwuFIG1PsQ89jvzBXCaZxi,hWYVzubgexwTPIfq)
	return
def qiDXo79yf3xu():
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if nndcv6tehuoKPpI!=1: return
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_SITES')
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_OPENED')
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_CLOSED')
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def I1rJCWByhPcexmbzv2qkD8VgQEd(LE2mKrZwkevRqfgzMu3QiopnS,VVQBFhXJZK,c1Ifu0OGV2kyRwLPWlsho8Ct6nz=QigevCplXxbPI1H):
	hHtEqiBucN3sG4yVg5Tn8DXjLp,lnPfer48KEhOBV,adZlk0B4OpX,rxQ1bM5IDR7Wu6Xj,n2nXAVJqidoFN,AGJVpzSH6yBc,GXHzaVZiDOhY = [],[],[],{},{},{},{}
	if VVQBFhXJZK!='search_sites':
		if VVQBFhXJZK=='listed_sites': adZlk0B4OpX = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','GLOBALSEARCH_SITES',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+LE2mKrZwkevRqfgzMu3QiopnS)
		elif VVQBFhXJZK=='opened_sites': adZlk0B4OpX = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','GLOBALSEARCH_OPENED',LE2mKrZwkevRqfgzMu3QiopnS)
		elif VVQBFhXJZK=='closed_sites': adZlk0B4OpX = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','GLOBALSEARCH_CLOSED',(c1Ifu0OGV2kyRwLPWlsho8Ct6nz,LE2mKrZwkevRqfgzMu3QiopnS))
	if not adZlk0B4OpX:
		ZZ1G8ui05FrMvbkC = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		p9YD6iyZOzKubQgFMh3X = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+LE2mKrZwkevRqfgzMu3QiopnS+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if VVQBFhXJZK=='search_sites': nDRKguWex0iVN8 = p9YD6iyZOzKubQgFMh3X
		else: nDRKguWex0iVN8 = ZZ1G8ui05FrMvbkC+p9YD6iyZOzKubQgFMh3X
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج',nDRKguWex0iVN8)
		if nndcv6tehuoKPpI!=1: return
		Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(False,False,False)
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Search For: [ '+LE2mKrZwkevRqfgzMu3QiopnS+' ]')
		YX654GrbjDtJqB8EAgul = 1
		for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in FF2QXkGONJavimRyheSC4s5:
			rxQ1bM5IDR7Wu6Xj[c1Ifu0OGV2kyRwLPWlsho8Ct6nz] = []
			ccKJQrzh9DnNO3jx = '_NODIALOGS_'
			if '-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz: ccKJQrzh9DnNO3jx = ccKJQrzh9DnNO3jx+'_REMEMBERRESULTS__'+c1Ifu0OGV2kyRwLPWlsho8Ct6nz+'_'
			CNdL1jR9m2AWpBV4PKitDhnx5qw,srPjEeQn5UkWDfKm,Ej3yCdX0csTKgrwlvqm2nBPZz8If = nBYW0gcOpt7HyfU(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
			if YX654GrbjDtJqB8EAgul:
				B3TKLo71hAGRqYgV0.sleep(0.75)
				GXHzaVZiDOhY[c1Ifu0OGV2kyRwLPWlsho8Ct6nz] = VVGXMeyJq25S6tf.Thread(target=srPjEeQn5UkWDfKm,args=(LE2mKrZwkevRqfgzMu3QiopnS+ccKJQrzh9DnNO3jx,))
				GXHzaVZiDOhY[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].start()
			else: srPjEeQn5UkWDfKm(LE2mKrZwkevRqfgzMu3QiopnS+ccKJQrzh9DnNO3jx)
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc(aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(c1Ifu0OGV2kyRwLPWlsho8Ct6nz),QigevCplXxbPI1H,B3TKLo71hAGRqYgV0=1000)
		if YX654GrbjDtJqB8EAgul:
			B3TKLo71hAGRqYgV0.sleep(2)
			for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in FF2QXkGONJavimRyheSC4s5:
				GXHzaVZiDOhY[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].join(10)
			B3TKLo71hAGRqYgV0.sleep(2)
		for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in FF2QXkGONJavimRyheSC4s5:
			CNdL1jR9m2AWpBV4PKitDhnx5qw,srPjEeQn5UkWDfKm,Ej3yCdX0csTKgrwlvqm2nBPZz8If = nBYW0gcOpt7HyfU(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
			for dd9H4XLuJQGqki in lc0jJQ4zboeDI3tqTrpvm5gZO:
				pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = dd9H4XLuJQGqki
				if Ej3yCdX0csTKgrwlvqm2nBPZz8If in zsj5qOxnfaXmdEco3DK29HgYybUCM6:
					if 'IPTV-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz and (239>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=230 or 289>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=280):
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['IPTV-LIVE']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['IPTV-MOVIES']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['IPTV-SERIES']: continue
						if 'صفحة' not in zsj5qOxnfaXmdEco3DK29HgYybUCM6:
							if   pf6P4wckhgTa=='live': c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IPTV-LIVE'
							elif pf6P4wckhgTa=='video': c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IPTV-MOVIES'
							elif pf6P4wckhgTa=='folder': c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IPTV-SERIES'
						else:
							if   'LIVE' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IPTV-LIVE'
							elif 'MOVIES' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IPTV-MOVIES'
							elif 'SERIES' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IPTV-SERIES'
					elif 'M3U-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz and 729>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=710:
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['M3U-LIVE']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['M3U-MOVIES']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['M3U-SERIES']: continue
						if 'صفحة' not in zsj5qOxnfaXmdEco3DK29HgYybUCM6:
							if   pf6P4wckhgTa=='live': c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'M3U-LIVE'
							elif pf6P4wckhgTa=='video': c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'M3U-MOVIES'
							elif pf6P4wckhgTa=='folder': c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'M3U-SERIES'
						else:
							if   'LIVE' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'M3U-LIVE'
							elif 'MOVIES' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'M3U-MOVIES'
							elif 'SERIES' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'M3U-SERIES'
					elif 'YOUTUBE-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz and 149>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=140:
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['YOUTUBE-CHANNELS']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['YOUTUBE-PLAYLISTS']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 or ':: ' in zsj5qOxnfaXmdEco3DK29HgYybUCM6:
							continue
						else:
							if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==144 and 'USER' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'YOUTUBE-CHANNELS'
							elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==144 and 'CHNL' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'YOUTUBE-CHANNELS'
							elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==144 and 'LIST' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'YOUTUBE-PLAYLISTS'
							elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==143: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz and 419>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=400:
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['DAILYMOTION-PLAYLISTS']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['DAILYMOTION-CHANNELS']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['DAILYMOTION-VIDEOS']: continue
						if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [401,405]: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'DAILYMOTION-PLAYLISTS'
						elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [402,406]: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'DAILYMOTION-CHANNELS'
						elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [404]: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'DAILYMOTION-VIDEOS'
						elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [415]: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'DAILYMOTION-LIVES'
					elif 'PANET-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz and 39>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=30:
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['PANET-SERIES']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['PANET-MOVIES']: continue
						if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [32,39]: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'PANET-SERIES'
						elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [33,39]: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'PANET-MOVIES'
					elif 'IFILM-' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz and 29>=TsckNQJ6yLiaEeCRml98WwKfVP0dYv>=20:
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['IFILM-ARABIC']: continue
						if dd9H4XLuJQGqki in rxQ1bM5IDR7Wu6Xj['IFILM-ENGLISH']: continue
						if   '/ar.' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IFILM-ARABIC'
						elif '/en.' in XCapNbgw2xWQ5jRt: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = 'IFILM-ENGLISH'
					rxQ1bM5IDR7Wu6Xj[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].append(dd9H4XLuJQGqki)
		lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
		for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in list(rxQ1bM5IDR7Wu6Xj.keys()):
			n2nXAVJqidoFN[c1Ifu0OGV2kyRwLPWlsho8Ct6nz] = []
			AGJVpzSH6yBc[c1Ifu0OGV2kyRwLPWlsho8Ct6nz] = []
			for pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in rxQ1bM5IDR7Wu6Xj[c1Ifu0OGV2kyRwLPWlsho8Ct6nz]:
				dd9H4XLuJQGqki = (pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
				if 'صفحة' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 and pf6P4wckhgTa=='folder': AGJVpzSH6yBc[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].append(dd9H4XLuJQGqki)
				else: n2nXAVJqidoFN[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].append(dd9H4XLuJQGqki)
		ZQlar4hLN29GBItfD = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',QigevCplXxbPI1H,157,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)]
		for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in gc5QSV42Ev8eG:
			if c1Ifu0OGV2kyRwLPWlsho8Ct6nz==RrcfSpUW8N72hBCaMPkLyTQ0[0]: ZQlar4hLN29GBItfD = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]',QigevCplXxbPI1H,157,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)]
			elif c1Ifu0OGV2kyRwLPWlsho8Ct6nz==ANfX3Pb0xTVGJmzI594Z[0]: ZQlar4hLN29GBItfD = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]',QigevCplXxbPI1H,157,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)]
			elif c1Ifu0OGV2kyRwLPWlsho8Ct6nz==rrJ283nstCORiuGgUcxhSAKq[0]: ZQlar4hLN29GBItfD = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',QigevCplXxbPI1H,157,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)]
			if c1Ifu0OGV2kyRwLPWlsho8Ct6nz not in n2nXAVJqidoFN.keys(): continue
			if n2nXAVJqidoFN[c1Ifu0OGV2kyRwLPWlsho8Ct6nz]:
				CVSXGvoAswr8N = aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
				QQubs6gzLCh59eSjWa0 = [('link','[COLOR FFFFFF00]===== '+CVSXGvoAswr8N+' =====[/COLOR]',QigevCplXxbPI1H,9999,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)]
				if 0: AAHpBrIe12NzUdtmsRk7wnZPD = LE2mKrZwkevRqfgzMu3QiopnS+' - '+'بحث'+hT7zFDpEyUqf8sXuN+CVSXGvoAswr8N
				else: AAHpBrIe12NzUdtmsRk7wnZPD = 'بحث'+hT7zFDpEyUqf8sXuN+CVSXGvoAswr8N+' - '+LE2mKrZwkevRqfgzMu3QiopnS
				if len(n2nXAVJqidoFN[c1Ifu0OGV2kyRwLPWlsho8Ct6nz])<8: LX5nt87mv2ZB4Pes9UorDSCzKEjJ = []
				else:
					Bkhmb8inf4pDM = iVCLpNIM8BQs9PdSgKZvlFeo3a5+AAHpBrIe12NzUdtmsRk7wnZPD+jhAlCQ47ZgG
					LX5nt87mv2ZB4Pes9UorDSCzKEjJ = [('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+Bkhmb8inf4pDM,'closed_sites',542,QigevCplXxbPI1H,c1Ifu0OGV2kyRwLPWlsho8Ct6nz,LE2mKrZwkevRqfgzMu3QiopnS,QigevCplXxbPI1H,QigevCplXxbPI1H)]
				rkM0zb3RaWX = n2nXAVJqidoFN[c1Ifu0OGV2kyRwLPWlsho8Ct6nz]+AGJVpzSH6yBc[c1Ifu0OGV2kyRwLPWlsho8Ct6nz]
				lnPfer48KEhOBV += ZQlar4hLN29GBItfD+QQubs6gzLCh59eSjWa0+rkM0zb3RaWX[:7]+LX5nt87mv2ZB4Pes9UorDSCzKEjJ
				hPLIR85xzSNnmvWeOuGEgT = [('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+AAHpBrIe12NzUdtmsRk7wnZPD,'closed_sites',542,QigevCplXxbPI1H,c1Ifu0OGV2kyRwLPWlsho8Ct6nz,LE2mKrZwkevRqfgzMu3QiopnS,QigevCplXxbPI1H,QigevCplXxbPI1H)]
				hHtEqiBucN3sG4yVg5Tn8DXjLp += ZQlar4hLN29GBItfD+hPLIR85xzSNnmvWeOuGEgT
				ZQlar4hLN29GBItfD = []
				BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_CLOSED',(c1Ifu0OGV2kyRwLPWlsho8Ct6nz,LE2mKrZwkevRqfgzMu3QiopnS),rkM0zb3RaWX,hWYVzubgexwTPIfq)
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_OPENED',LE2mKrZwkevRqfgzMu3QiopnS,lnPfer48KEhOBV,hWYVzubgexwTPIfq)
		P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_SITES',LE2mKrZwkevRqfgzMu3QiopnS)
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'GLOBALSEARCH_SITES',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+LE2mKrZwkevRqfgzMu3QiopnS,hHtEqiBucN3sG4yVg5Tn8DXjLp,hWYVzubgexwTPIfq)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if VVQBFhXJZK=='listed_sites' and hHtEqiBucN3sG4yVg5Tn8DXjLp: adZlk0B4OpX = hHtEqiBucN3sG4yVg5Tn8DXjLp
		else: adZlk0B4OpX = lnPfer48KEhOBV
	if VVQBFhXJZK!='search_sites':
		for pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in adZlk0B4OpX:
			if VVQBFhXJZK in ['listed_sites','opened_sites'] and 'صفحة' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 and pf6P4wckhgTa=='folder': continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj(pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
	Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)
	return
def AMBXS0OocamvkiPlC(LE2mKrZwkevRqfgzMu3QiopnS=QigevCplXxbPI1H):
	IghAzcTSrx1Wq6,ccKJQrzh9DnNO3jx,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(LE2mKrZwkevRqfgzMu3QiopnS)
	if not IghAzcTSrx1Wq6:
		IghAzcTSrx1Wq6 = XAfEvmh95VkgurjdiJ()
		if not IghAzcTSrx1Wq6: return
		IghAzcTSrx1Wq6 = IghAzcTSrx1Wq6.lower()
	SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Search For: [ '+IghAzcTSrx1Wq6+' ]')
	VIo6FYRkx0MLP4wufEGsgnz9 = IghAzcTSrx1Wq6+ccKJQrzh9DnNO3jx
	if 0: neEQxFOd0XoVJ2b9L6B,gKMPH8ajYeX45Vz0yr = IghAzcTSrx1Wq6+' - ',QigevCplXxbPI1H
	else: neEQxFOd0XoVJ2b9L6B,gKMPH8ajYeX45Vz0yr = QigevCplXxbPI1H,' - '+IghAzcTSrx1Wq6
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',QigevCplXxbPI1H,157)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_M3U_'+neEQxFOd0XoVJ2b9L6B+'بحث M3U'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,719,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_IPT_'+neEQxFOd0XoVJ2b9L6B+'بحث IPTV'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,239,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_BKR_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع بكرا'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,379,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_ART_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع تونز عربية'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,739,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_KRB_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع قناة كربلاء'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,329,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_FH1_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع فاصل الأول'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,579,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_FH2_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع فاصل الثاني'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,599,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_KTV_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع كتكوت تيفي'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,819,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_EB1_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع ايجي بيست 1'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,779,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_EB2_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع ايجي بيست 2'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,789,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_IFL_'+neEQxFOd0XoVJ2b9L6B+'  بحث موقع قناة آي فيلم'+gKMPH8ajYeX45Vz0yr+eZXCHufT9YW4bRErSBOLmI,QigevCplXxbPI1H,29,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_AKO_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع أكوام القديم'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,79,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_AKW_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع أكوام الجديد'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,249,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_MRF_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع قناة المعارف'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,49,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_SHM_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع شوف ماكس'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,59,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]',QigevCplXxbPI1H,157)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_FJS_'+neEQxFOd0XoVJ2b9L6B+' بحث موقع فجر شو'+gKMPH8ajYeX45Vz0yr+hT7zFDpEyUqf8sXuN,QigevCplXxbPI1H,399,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_TVF_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع تيفي فان'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,469,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_LDN_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع لودي نت'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,459,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_CMN_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع سيما ناو'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,309,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_WCM_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع وي سيما'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,569,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_SHN_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع شاهد نيوز'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,589,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9+'_NODIALOGS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_ARS_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع عرب سييد'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,259,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_CCB_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع سيما كلوب'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,829,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_SH4_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع شاهد فوريو'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,119,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9+'_NODIALOGS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_SHT_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع شوفها تيفي'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,649,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]',QigevCplXxbPI1H,157)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_FST_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع فوستا'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,609,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_FBK_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع فبركة'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,629,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_YQT_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع ياقوت'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,669,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_BRS_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع برستيج'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,659,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_HLC_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع هلا سيما'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,89,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_DR7_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع دراما صح'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,689,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_CMF_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع سيما فانز'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,99,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_CML_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع سيما لايت'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,479,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_ABD_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع سيما عبدو'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,559,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_C4H_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع سيما 400'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,699,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_AHK_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع أهواك تيفي'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,619,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_EB4_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع ايجي بيست 4'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,809,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',QigevCplXxbPI1H,157)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_YUT_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع يوتيوب'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,149,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_DLM_'+neEQxFOd0XoVJ2b9L6B+'بحث موقع ديلي موشن'+gKMPH8ajYeX45Vz0yr,QigevCplXxbPI1H,409,QigevCplXxbPI1H,QigevCplXxbPI1H,VIo6FYRkx0MLP4wufEGsgnz9)
	return
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'CIMA400'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_C4H_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد','Categories',QigevCplXxbPI1H]
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==690: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==691: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==692: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==693: W9lfsoMawqOzpQcXD = LU7F3uNrm06e8OwTEcCJ(url,text)
	elif mode==694: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==699: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA400-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,699,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"navslide-divider"(.*?)"navslide-divider"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		title = title.replace('<b>',QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,694)
	return
def eR6YT8AbXwl(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA400-SUBMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"caret"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Z5CDQW96jye:
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('"presentation"','</ul>')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = [(QigevCplXxbPI1H,LKzFWsmvjUVGMDBapflx6H4NY)]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]',QigevCplXxbPI1H,9999)
		for EVZ0Dhsl5r8tHPq6GNS19I3ox,LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if EVZ0Dhsl5r8tHPq6GNS19I3ox: EVZ0Dhsl5r8tHPq6GNS19I3ox = EVZ0Dhsl5r8tHPq6GNS19I3ox+': '
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = EVZ0Dhsl5r8tHPq6GNS19I3ox+title
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,691)
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"pm-category-subcats"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if gQ5KvJ6G2lbWwYBOMiTr:
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(items)<30:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,691)
	if not Z5CDQW96jye and not gQ5KvJ6G2lbWwYBOMiTr: ddbEXhWzOnIaR(url)
	return
def ddbEXhWzOnIaR(url,x9Ahuz3FVWmJDaNp5=QigevCplXxbPI1H):
	if x9Ahuz3FVWmJDaNp5=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA400-TITLES-1st')
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA400-TITLES-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	LKzFWsmvjUVGMDBapflx6H4NY,items = QigevCplXxbPI1H,[]
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	if x9Ahuz3FVWmJDaNp5=='ajax-search':
		LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
		WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in WWcSoXlyFCIzMGpxr: items.append((QigevCplXxbPI1H,RMC6c2kL5hGOnFaIwAyb,title))
	elif x9Ahuz3FVWmJDaNp5=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pm-video-watch-featured"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif x9Ahuz3FVWmJDaNp5=='new_episodes':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"row pm-ul-browse-videos(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif x9Ahuz3FVWmJDaNp5=='new_movies':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"row pm-ul-browse-videos(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(fwSu6JsQZpEiv)>1: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[1]
	elif x9Ahuz3FVWmJDaNp5=='featured_series':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"ba mgb table full"(.*?)"clearfix"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in WWcSoXlyFCIzMGpxr: items.append((QigevCplXxbPI1H,RMC6c2kL5hGOnFaIwAyb,title))
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('(data-echo=".*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if LKzFWsmvjUVGMDBapflx6H4NY and not items: items = sBvufaD6c9YHdOqTjCQ3.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items: return
	wibHRCAFtsupIjx4ZTELeM = []
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|حلقة).\d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,692,cXu4fN1moCypJqb72OZvd)
		elif x9Ahuz3FVWmJDaNp5=='new_episodes':
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,692,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0][0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,693,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,693,cXu4fN1moCypJqb72OZvd)
	if 1:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				if RMC6c2kL5hGOnFaIwAyb=='#': continue
				RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,691)
	return
def LU7F3uNrm06e8OwTEcCJ(url,q0zc3k5wP7Qo9A):
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA400-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	XGjn5q2cy6mRYZ1hPaDslHMK = sBvufaD6c9YHdOqTjCQ3.findall('"series-header".*?src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if XGjn5q2cy6mRYZ1hPaDslHMK: cXu4fN1moCypJqb72OZvd = XGjn5q2cy6mRYZ1hPaDslHMK[0]
	else: cXu4fN1moCypJqb72OZvd = QigevCplXxbPI1H
	items = []
	wqxGIOhslR97ebNyYv = False
	if Z5CDQW96jye and not q0zc3k5wP7Qo9A:
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('data-serie="(.*?)".*?">(.*?)</',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for q0zc3k5wP7Qo9A,title in items:
			q0zc3k5wP7Qo9A = q0zc3k5wP7Qo9A.strip('#')
			if len(items)>1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,693,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,q0zc3k5wP7Qo9A)
			else: wqxGIOhslR97ebNyYv = True
	else: wqxGIOhslR97ebNyYv = True
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"SeasonsEpisodesMain(.*?</div>).</div>.</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('id="'+q0zc3k5wP7Qo9A+'"(.*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not gQ5KvJ6G2lbWwYBOMiTr: gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('data-serie="'+q0zc3k5wP7Qo9A+'"(.*?)</div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not gQ5KvJ6G2lbWwYBOMiTr: gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('id="Season'+q0zc3k5wP7Qo9A+'"(.*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if gQ5KvJ6G2lbWwYBOMiTr and wqxGIOhslR97ebNyYv:
			LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
			WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall("href='(.*?)'><li><em>(.*?)</span>",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if not WWcSoXlyFCIzMGpxr: WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<em>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			items = []
			for RMC6c2kL5hGOnFaIwAyb,title in WWcSoXlyFCIzMGpxr: items.append((RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd))
			if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.strip('./')
				RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
				title = title.replace('</em><span>',hT7zFDpEyUqf8sXuN)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,692,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m,It5BbEQNGcxzRK68,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = [],[],[]
	Kj0TOU6BmSMlJHZYLd = url.replace('/watch.php','/see.php')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA400-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"WatchList"(.*?)</div>.</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('<iframe src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RMC6c2kL5hGOnFaIwAyb:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0]
			It5BbEQNGcxzRK68.append('?named=__embed')
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('data-embed-url="(.*?)".*?onclick.*?">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in rsBojxT8UZwL:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if RMC6c2kL5hGOnFaIwAyb not in ldFqnNIsftrY43JBM6LPjzU8m:
				It5BbEQNGcxzRK68.append('?named='+title+'__watch')
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('href="(http.*?)".*?</i>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in rsBojxT8UZwL:
			if RMC6c2kL5hGOnFaIwAyb not in ldFqnNIsftrY43JBM6LPjzU8m:
				title = title.strip(aSBkt4OU8JpWTEzVIHjAiv)
				It5BbEQNGcxzRK68.append('?named='+title+'__download')
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf = zip(ldFqnNIsftrY43JBM6LPjzU8m,It5BbEQNGcxzRK68)
	for RMC6c2kL5hGOnFaIwAyb,name in w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf: vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+name)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/search.php?keywords='+search
	ddbEXhWzOnIaR(url,'search')
	return
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
headers = { 'User-Agent' : QigevCplXxbPI1H }
PuT0IphGNsketAQ = 'AKOAMCAM'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_AKC_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['مصارعة']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==350: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==351: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==352: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==353: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==354: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'FILTERS___'+text)
	elif mode==355: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'CATEGORIES___'+text)
	elif mode==356: W9lfsoMawqOzpQcXD = p6tBigas8JvRY4G3fWCXxzmd(url)
	elif mode==357: W9lfsoMawqOzpQcXD = YYEnLmrFyb1Clj(url)
	elif mode==359: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'[COLOR FFFFFF00]هذا الموقع مغلق[/COLOR]',QigevCplXxbPI1H,8)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,359,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',vxQUXEuH9m,356)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',vxQUXEuH9m,357)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKOAMCAM-MENU-1st')
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('recently-container.*?href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[0]
	else: Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'اضيف حديثا',Kj0TOU6BmSMlJHZYLd,351)
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('@id":"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[0]
	else: Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',Kj0TOU6BmSMlJHZYLd,351,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-categories-list(.*?)main-categories-list',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?class="font.*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title not in ef1pQcbEtPjMnXYrvOi: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,351)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="categories-box(.*?)<footer',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = i7gQvkPzZJm4jM3uYV2xfAqhs(RMC6c2kL5hGOnFaIwAyb)
			if title not in ef1pQcbEtPjMnXYrvOi: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,351)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def p6tBigas8JvRY4G3fWCXxzmd(website=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKOAMCAM-MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="menu(.*?)<nav',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?text">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title not in ef1pQcbEtPjMnXYrvOi:
				title = title+' مصنفة'
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,355)
		if website==QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def YYEnLmrFyb1Clj(website=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKOAMCAM-MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="menu(.*?)<nav',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?text">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title not in ef1pQcbEtPjMnXYrvOi:
				title = title+' مفلترة'
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,354)
		if website==QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,type=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(oL2eIiFEJnd7vxc,url,QigevCplXxbPI1H,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('swiper-container(.*?)swiper-button-prev',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="container"(.*?)main-footer',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		wibHRCAFtsupIjx4ZTELeM = []
		for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|الحلقه) \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if V1nZX7O5WwEq8HmvkY:
					title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0][0]
					if title not in wibHRCAFtsupIjx4ZTELeM:
						E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,352,cXu4fN1moCypJqb72OZvd)
						wibHRCAFtsupIjx4ZTELeM.append(title)
			elif 'مسلسل' in title:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,352,cXu4fN1moCypJqb72OZvd)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,353,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href=["\'](.*?)["\'].*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = i7gQvkPzZJm4jM3uYV2xfAqhs(RMC6c2kL5hGOnFaIwAyb)
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,351)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m + '/?s='+VIo6FYRkx0MLP4wufEGsgnz9
	W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	return
def oB2rmVgqUND(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,True,'AKOAMCAM-EPISODES-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('text-white">الحلقات(.*?)<header',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		yjHcgifXG1 = sBvufaD6c9YHdOqTjCQ3.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in yjHcgifXG1:
			if 'الحلقة' in title or 'الحلقه' in title: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,353,cXu4fN1moCypJqb72OZvd)
	else:
		cXu4fN1moCypJqb72OZvd = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel('ListItem.Icon')
		if aY63L2NhgvwJIxPAoDG4MKECmZXF1.count('<title>')>1: title = sBvufaD6c9YHdOqTjCQ3.findall('<title>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[1]
		else: title = 'رابط التشغيل'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,353,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6 = [],[]
	iayvKQ7PrA9NEVhDfIsqjmW = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'AKOAMCAM-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = iayvKQ7PrA9NEVhDfIsqjmW.content
	d8o4GfOLXIhV7b = sBvufaD6c9YHdOqTjCQ3.findall('post_id=(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if d8o4GfOLXIhV7b:
		d8o4GfOLXIhV7b = d8o4GfOLXIhV7b[0]
		headers = {'User-Agent':QigevCplXxbPI1H,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':d8o4GfOLXIhV7b}
		Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		QgF57C2lJIaTHztbivrVwR = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'POST',Kj0TOU6BmSMlJHZYLd,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'AKOAMCAM-PLAY-1st')
		BhxM1UVjtbEoSp640kIcag = QgF57C2lJIaTHztbivrVwR.content
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-server="(.*?)".*?class="text">(.*?)<',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for rYsGTvB7OdokCyS10MHXEPzhe,name in items:
			RMC6c2kL5hGOnFaIwAyb = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?postid='+d8o4GfOLXIhV7b+'&serverid='+rYsGTvB7OdokCyS10MHXEPzhe+'?named='+name+'__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			ttGBwQOv3K41hIkc6.append(name)
		Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		QgF57C2lJIaTHztbivrVwR = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'POST',Kj0TOU6BmSMlJHZYLd,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'AKOAMCAM-PLAY-1st')
		BhxM1UVjtbEoSp640kIcag = QgF57C2lJIaTHztbivrVwR.content
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?class="text">(.*?)<',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.strip(hT7zFDpEyUqf8sXuN)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			ttGBwQOv3K41hIkc6.append(title)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	XGiBxdyuLeSzpmvUCEwJI = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='CATEGORIES':
		if XGiBxdyuLeSzpmvUCEwJI[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XGiBxdyuLeSzpmvUCEwJI[0:-1])):
			if XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'all')
		Kj0TOU6BmSMlJHZYLd = url+'?'+IhG0UytMJko7
	elif type=='FILTERS':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'all')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها',Kj0TOU6BmSMlJHZYLd,351,QigevCplXxbPI1H,'1')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',Kj0TOU6BmSMlJHZYLd,351,QigevCplXxbPI1H,'1')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<form id(.*?)</form>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	dict = {}
	for Vjv2Okb6qhMRQgaDlu3JCir,name,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		items = sBvufaD6c9YHdOqTjCQ3.findall('<option(.*?)>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='CATEGORIES':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<=1:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'CATEGORIES___'+Vq4HIkij2ZLE)
				return
			else:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,351,QigevCplXxbPI1H,'1')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,355,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='FILTERS':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع : '+name,Kj0TOU6BmSMlJHZYLd,354,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			if 'value' not in nFdGHjceZzW: nFdGHjceZzW = C4kS0cewBJy8YOWtZxXNjfM2
			else: nFdGHjceZzW = sBvufaD6c9YHdOqTjCQ3.findall('"(.*?)"',nFdGHjceZzW,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			title = C4kS0cewBJy8YOWtZxXNjfM2+' : '#+dict[Vjv2Okb6qhMRQgaDlu3JCir]['0']
			title = C4kS0cewBJy8YOWtZxXNjfM2+' : '+name
			if type=='FILTERS': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,354,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='CATEGORIES' and XGiBxdyuLeSzpmvUCEwJI[-2]+'=' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'all')
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'?'+IhG0UytMJko7
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,351,QigevCplXxbPI1H,'1')
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,355,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	NBJvnaA2GkRo6SD79YsVjqd = ['cat','genre','release-year','quality','orderby']
	for key in NBJvnaA2GkRo6SD79YsVjqd:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	return bYlTrNXtvf0G7y
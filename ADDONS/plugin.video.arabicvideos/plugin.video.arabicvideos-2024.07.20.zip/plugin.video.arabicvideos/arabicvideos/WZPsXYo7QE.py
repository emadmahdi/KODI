# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from TEsNM9QVZc import *
PuT0IphGNsketAQ = K7bLVaiRkx0lgU5SQM(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࢚࠭")
def YnMSWTbKj1N8wuRJVF(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,d8kolNVuLsPAjQZ9ROpUHBgix=QigevCplXxbPI1H):
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  pGncXOodjKhJzLSqVP1r(u"࠱ங"): iMJS3wEYgzDx5Np8R1KHcntVf7h(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  s0vAWcLSXEToH9Mik134q(u"࠴ச"): U6KgbJ9ld3WHCYqFf4AV2Ikx(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠶஛"): Xlos2F9Vck6u()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  g4UCaNkHvLwGhjmW(u"࠸ஜ"): kkEM4GJSYRp(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠺஝"): h6OITjR7CZGQcU4WHJ8De()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  tOrSvd8QKNB(u"࠼ஞ"): lUaW7Box2uy1SNg93YGZ()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  DDHwpETQrAm0xMNXGfyhqsUi(u"࠷ட"): OXlgcotDer5zTQ1MFYva3nKxdNR(XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  fk8jc5uDLX16qrih3ZaPxsvO(u"࠹஠"): xH84fYWvX7yFw6Inb()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==  DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠻஡"): CnbjTQAGWyHhKeSzcw6RvFo5kILs()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠴࠹࠵஢"): kJcN5W08MGpbgYmzHRxUDu7CTisXEv()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠵࠺࠷ண"): RW3Pfe8oB4bwKg2CjimsarMlIJ5()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠶࠻࠲த"): I4CXHzwQldLBUrsZtJAg()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==tg9l25NH6WTacVSifLyAmY(u"࠷࠵࠴஥"): mP7G0io9dJDZSCbLhcutME6BWKqs4V()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠱࠶࠶஦"): ve3MUgW8LJYKkjhb()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==XWbHfI9B8swrOL(u"࠲࠷࠸஧"): XVpjAUls0KR5D3hOqrnBkWYvS()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠳࠸࠺ந"): DIE2YAwz0cBKdte6xS()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==OOhnpQ8XvCVclGqdu(u"࠴࠹࠼ன"): Pmqy34MVnCkZoQHIzYupW()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==vZL6j4tSClIGxzNE5DX(u"࠵࠺࠾ப"): o4VN0Kr8ix7ctYSukG3eATEdJj()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==O4ylJvVNwLztdiHqBWDU(u"࠶࠻࠹஫"): o48zDxkduZq0QrSBF7923pGwTLcIJb(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠷࠷࠱஬"): AAED4kxHIBjiaCcqWdSgYl()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==OOhnpQ8XvCVclGqdu(u"࠱࠸࠳஭"): kXhPH0nom9dJ()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠲࠹࠵ம"): RiTVrvtfgm9jOe81(d8kolNVuLsPAjQZ9ROpUHBgix,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==pGncXOodjKhJzLSqVP1r(u"࠳࠺࠷ய"): UU8FkvnySO(TCF8wLyDvgumfiXPSKRh(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࢛ࠬ"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==mmKqLr9RX0ACN384JMcsFHzd(u"࠴࠻࠹ர"): UU8FkvnySO(svULcgJ7jm(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ࢜"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==bDt7Ya1VEio3(u"࠵࠼࠻ற"): f4LGjOWou6()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Fg72JX6T5DkPy(u"࠶࠽࠶ல"): keqY7H5SjhxNcUDsFi3v0umPz()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷࠷࠸ள"): Xzo4bEuYR3(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ࢝"))
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠱࠸࠺ழ"): Xzo4bEuYR3(Xr2aHOK0huQ5DTS(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨ࢞"))
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==pTwKPmzMSZhil5d2RWonre(u"࠲࠹࠼வ"): Xzo4bEuYR3(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠩ࢟"))
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==tg9l25NH6WTacVSifLyAmY(u"࠳࠼࠴ஶ"): SGDXI38kxfjzqJQwu15FcHhv()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠴࠽࠶ஷ"): soEVUdbYQIgF()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==svULcgJ7jm(u"࠵࠾࠸ஸ"): DFq74bhyMgm()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==FF70emVxhWOngCty(u"࠶࠿࠳ஹ"): WJXeodp7w3lha1AO()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠷࠹࠵஺"): b0Sxth8EdUzaZ()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠱࠺࠷஻"): DH5BlEGcRMZgyUVWxw8nCjPNb()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==s0vAWcLSXEToH9Mik134q(u"࠲࠻࠹஼"): xxsNFRoajDTChAu0ln1()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠳࠼࠻஽"): HyWibNrAfm24Y5XTLtjGBd()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==TCF8wLyDvgumfiXPSKRh(u"࠴࠽࠽ா"): RRx6JG3ShkEL5VnZelig()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==DDHwpETQrAm0xMNXGfyhqsUi(u"࠵࠾࠿ி"): tEbmPrugyMO5ldSCH9qZ()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==JJu4MPClbTFpUwHiN(u"࠸࠺࠰ீ"): XLsBySdloIQcif3tzKvDJFrhTWHCGp(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==K7bLVaiRkx0lgU5SQM(u"࠹࠴࠲ு"): ITJQ4ncG6jVXhgvyP29Y1()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠳࠵࠴ூ"): U7XPIj3kxuEJdloZtnYT8QAb()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠴࠶࠶௃"): RkKsEQq7fvSOHI61NoAtw0GJpP()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==FF70emVxhWOngCty(u"࠵࠷࠸௄"): XIH9Pn7tdj8hsZMC4i(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==DDHwpETQrAm0xMNXGfyhqsUi(u"࠶࠸࠺௅"): iJ4Qm5MVC3ndzXfRWLouYOcyatsrPD()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠷࠹࠼ெ"): RnSBkihLmKDpvb(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==s0vAWcLSXEToH9Mik134q(u"࠸࠺࠷ே"): bqQv1mSPE2w0poVrxIKigNeTkL(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠹࠴࠹ை"): m6JAHwaQyKlbUXNpfW3e2vijgxzB()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==s0vAWcLSXEToH9Mik134q(u"࠳࠵࠻௉"): pass
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠶࠲࠳ொ"): Ig4PfGu1VSFY7()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==g4UCaNkHvLwGhjmW(u"࠷࠳࠵ோ"): Q1zaYlG7V2hsW6Si()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠸࠴࠷ௌ"): G3hVl67pIMOigeKa(pTwKPmzMSZhil5d2RWonre(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩࢠ"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==DDHwpETQrAm0xMNXGfyhqsUi(u"࠹࠵࠹்"): IIrTJbsVkRgUlKF(Nk7BzXcC5VbpSanw)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==y5yX4jh6kUEgWZQIc(u"࠺࠶࠴௎"): IIrTJbsVkRgUlKF(RpmwIQ5vaFkP8SuNW)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠻࠰࠶௏"): zeliCoPGyWwj7F1kbtBfsESKmxOHLN()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==bDt7Ya1VEio3(u"࠵࠱࠸ௐ"): MfFlidaIObTrEBK08eg(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==bDt7Ya1VEio3(u"࠶࠲࠺௑"): UUSQjR8qivYPgbkOlAEhadcr(d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠷࠳࠼௒"): OsgDqM27jLyWAT()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==JJu4MPClbTFpUwHiN(u"࠸࠴࠾௓"): llLgntcE4bs5HTd()
	return
def llLgntcE4bs5HTd():
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࢡ"),tg9l25NH6WTacVSifLyAmY(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦไไ์ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥะฬะ์าࠤฬ๊ศา่ส้ั่ࠦหืไ๎ึํู้๊ࠠ฽์ࠦศฮษ็อࠥอไๆื้฽ࠥอไห์ࠣ์฻฿็ศࠢส่๊ฮัๆฮࠣรࠦࠧࠧࢢ"))
	if nndcv6tehuoKPpI:
		XIH9Pn7tdj8hsZMC4i(YoAMfqm37GyFxbuKTt6e8CESHrhB)
		eB8jr3L1inmU6OzINJd(nZ5AkguavpEc7zWo8SOHRD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢣ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧห็ุ้ࠣำࠠอ็ํ฽ࠥอไๆๆไหฯࠦวๅไา๎๊ฯࠠๅๆหี๋อๅอࠢ࠱࠲ࠥ๎ูศัࠣห้ฮั็ษ่ะࠥหไฺ๊๋ࠢ฾๐ษࠡษ็ูๆืࠠ࠯࠰ࠣ์฻฿๊สࠢส่๊฻ๆฺࠩࢤ"))
	return
def UUSQjR8qivYPgbkOlAEhadcr(GTZC7rKJtPlueQ,tNVzI3BovxPMX6m,showDialogs):
	R2wuKSVBTLW4sAOQNob18UEdGf0hv = DZLbiWNFXwpM26.connect(h8oaOyKE9vx0F7sQUkumSGYCD5VZ)
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.text_factory = str
	B6xRu5lFyJ = R2wuKSVBTLW4sAOQNob18UEdGf0hv.cursor()
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: HLaB8TxFSsXYQhz = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫࢥ")
	else: HLaB8TxFSsXYQhz = g4UCaNkHvLwGhjmW(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨࢦ")
	B6xRu5lFyJ.execute(mpusoZBJ6V(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫࢧ")+HLaB8TxFSsXYQhz+v54ZuLY6dQ(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩࢨ")+GTZC7rKJtPlueQ+TCF8wLyDvgumfiXPSKRh(u"ࠬࠨࠠ࠼ࠩࢩ"))
	evn4M7hX8L2QKZHNEamVz5kw = B6xRu5lFyJ.fetchall()
	if evn4M7hX8L2QKZHNEamVz5kw and tNVzI3BovxPMX6m in [QigevCplXxbPI1H,svULcgJ7jm(u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭ࢪ")]:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࢫ"),mpusoZBJ6V(u"ࠨษ็ฮาี๊ฬࠢส่ศ๎ส้็สฮ๏้๊ࠡๆศฺฬ็ษࠡ࡞ࡱࠤࠬࢬ")+GTZC7rKJtPlueQ+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࠣࡠࡳࡢ࡮ࠡࠩࢭ")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࠤ๊ะ่ใใࠣ์้อ๋ࠠ฻่่ࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢอๅ฾๐ไ่ࠢส่ว์ࠠภࠣࠤࠤࠬࢮ")+jhAlCQ47ZgG+v54ZuLY6dQ(u"ࠫࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩࢯ"))
		if nndcv6tehuoKPpI!=DDHwpETQrAm0xMNXGfyhqsUi(u"࠵௔"): return
		B6xRu5lFyJ.execute(vZL6j4tSClIGxzNE5DX(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠫࢰ")+HLaB8TxFSsXYQhz+v54ZuLY6dQ(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫࢱ")+GTZC7rKJtPlueQ+OTRKI6LbrQnZEm(u"ࠧࠣࠢ࠾ࠫࢲ"))
	elif tNVzI3BovxPMX6m in [QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࠩࢳ")]:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,XWbHfI9B8swrOL(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࢴ"),svULcgJ7jm(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧࢵ")+GTZC7rKJtPlueQ+OTRKI6LbrQnZEm(u"ࠫࠥࡢ࡮࡝ࡰࠣࠫࢶ")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+v54ZuLY6dQ(u"ࠬࠦๅโ฻็ࠤํ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆํࠠศๆล๊ࠥลࠡࠢࠢࠪࢷ")+jhAlCQ47ZgG+K7bLVaiRkx0lgU5SQM(u"࠭ࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥะแฺ์็๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦศา่ส้ัูࠦๆษาࠫࢸ"))
		if nndcv6tehuoKPpI!=WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠶௕"): return
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: B6xRu5lFyJ.execute(OOhnpQ8XvCVclGqdu(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࡨ࡬ࡢࡥ࡮ࡰ࡮ࡹࡴࠡࠪࡤࡨࡩࡵ࡮ࡊࡆࠬࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࠨࠧࢹ")+GTZC7rKJtPlueQ+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࠤࠬࠤࡀ࠭ࢺ"))
		else: B6xRu5lFyJ.execute(JJu4MPClbTFpUwHiN(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸࠦࠨࡢࡦࡧࡳࡳࡏࡄ࠭ࡷࡳࡨࡦࡺࡥࡓࡷ࡯ࡩ࠮ࠦࡖࡂࡎࡘࡉࡘࠦࠨࠣࠩࢻ")+GTZC7rKJtPlueQ+TCF8wLyDvgumfiXPSKRh(u"ࠪࠦ࠱࠷ࠩࠡ࠽ࠪࢼ"))
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	B3TKLo71hAGRqYgV0.sleep(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠷௖"))
	qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(Xr2aHOK0huQ5DTS(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨࢽ"))
	B3TKLo71hAGRqYgV0.sleep(tg9l25NH6WTacVSifLyAmY(u"࠱ௗ"))
	if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࢾ"),mmKqLr9RX0ACN384JMcsFHzd(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪࢿ"))
	if tNVzI3BovxPMX6m in [QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠧࡦࡰࡤࡦࡱ࡫ࠧࣀ")]: o48zDxkduZq0QrSBF7923pGwTLcIJb(showDialogs)
	return
def zeliCoPGyWwj7F1kbtBfsESKmxOHLN():
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,mpusoZBJ6V(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫࣁ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬࣂ"))
	RulsXEM83VO0QKcCHza2TGSf4N9g = IIJimsEAhPdua8RFg4LvbMwV0rD5U6(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	F3yhcweANUmsl = aSBkt4OU8JpWTEzVIHjAiv
	mRfDz7hMcb9edn5stPgluC0QBYWN2 = r9rhtA5Tek8sIoLfqwF7JcEV+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦࠧࣃ")+jhAlCQ47ZgG
	hhA7HgbMB90ID = aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨࣄ")+jhAlCQ47ZgG+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡢ࡮࡝ࡰࠪࣅ")
	for id,PXVdZQYTNslvg7wF0159Akr,Qc9doRJK1CMgWzqTruGf,rr4e95RPASc,oVMaZ1qEyj6kLgTCUBNAbsHIpOK,reason in reversed(RulsXEM83VO0QKcCHza2TGSf4N9g):
		if id==fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࠰ࠨࣆ"):
			e9HQkYzB6bw7DEO2gsm,EhM4uxfISnO7kLKFoG5JPy2ql = rr4e95RPASc.split(Xr2aHOK0huQ5DTS(u"ࠧ࡝ࡰ࠾࠿ࠬࣇ"))
			continue
		if F3yhcweANUmsl!=aSBkt4OU8JpWTEzVIHjAiv: F3yhcweANUmsl += hhA7HgbMB90ID
		ZZ1G8ui05FrMvbkC = K7bLVaiRkx0lgU5SQM(u"ࠨ࡝ࡕࡘࡑࡣࠧࣈ")+r9rhtA5Tek8sIoLfqwF7JcEV+id+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࠣ࠾ࠥ࠭ࣉ")+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪหู้ฤศๆࠣ࠾ࠥ࠭࣊")+jhAlCQ47ZgG+Qc9doRJK1CMgWzqTruGf
		p9YD6iyZOzKubQgFMh3X = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡡࡴ࡛ࡓࡖࡏࡡࠬ࣋")+r9rhtA5Tek8sIoLfqwF7JcEV+mpusoZBJ6V(u"ࠬอไอ๊สฬࠥࡀࠠࠨ࣌")+jhAlCQ47ZgG+rr4e95RPASc
		uCyjMoXJUOq6eVP = pTwKPmzMSZhil5d2RWonre(u"࡛࠭ࡓࡖࡏࡡࠬ࣍")+r9rhtA5Tek8sIoLfqwF7JcEV+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧศๆั฻ศࠦ࠺ࠡࠩ࣎")+jhAlCQ47ZgG+oVMaZ1qEyj6kLgTCUBNAbsHIpOK
		S0ZwbUTgNQzXtM7OEJR1hDC8n2F = mmKqLr9RX0ACN384JMcsFHzd(u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࣏ࠩ")+r9rhtA5Tek8sIoLfqwF7JcEV+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩสุ่ฮศࠡ࠼࣐ࠣࠫ")+jhAlCQ47ZgG+reason
		F3yhcweANUmsl += ZZ1G8ui05FrMvbkC+p9YD6iyZOzKubQgFMh3X+aSBkt4OU8JpWTEzVIHjAiv+mRfDz7hMcb9edn5stPgluC0QBYWN2+aSBkt4OU8JpWTEzVIHjAiv+uCyjMoXJUOq6eVP+S0ZwbUTgNQzXtM7OEJR1hDC8n2F+aSBkt4OU8JpWTEzVIHjAiv
	XRZyfuiD8nLlKYPJ(Xr2aHOK0huQ5DTS(u"ࠪࡶ࡮࡭ࡨࡵ࣑ࠩ"),EhM4uxfISnO7kLKFoG5JPy2ql,F3yhcweANUmsl,svULcgJ7jm(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫࣒ࠬ"))
	return
def IIrTJbsVkRgUlKF(file):
	if file==RpmwIQ5vaFkP8SuNW: mHpaczX9ES7g = g4UCaNkHvLwGhjmW(u"่่ࠬศศ่ࠤฬ๊ๅโุ็อ࣓ࠬ")
	elif file==Nk7BzXcC5VbpSanw: mHpaczX9ES7g = aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭โ้ษษ้ࠥศฮาࠢส่ๆ๐ฯ๋๊๊หฯ࠭ࣔ")
	BBt5dqgsIEbFNDCioAl = L2Lu1MQVHhiTX0(FF70emVxhWOngCty(u"ࠧࡤࡧࡱࡸࡪࡸࠧࣕ"),O4ylJvVNwLztdiHqBWDU(u"ࠨ็ึัࠬࣖ"),FF70emVxhWOngCty(u"ࠩศู้ออࠨࣗ"),pTwKPmzMSZhil5d2RWonre(u"ࠪาึ๎ฬࠨࣘ"),bDt7Ya1VEio3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣙ"),pTwKPmzMSZhil5d2RWonre(u"ࠬํไࠡฬิ๎ิࠦลึๆสั๋ࠥไโࠢࠪࣚ")+mHpaczX9ES7g+aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࠠฤ็ࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไࠤฤ࠭ࣛ"))
	if BBt5dqgsIEbFNDCioAl==Xr2aHOK0huQ5DTS(u"࠱௘"):
		if KiTt9ZskMLjnCAUIJNXD7.path.exists(file):
			try: KiTt9ZskMLjnCAUIJNXD7.remove(file)
			except: pass
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪࣜ"),Xr2aHOK0huQ5DTS(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭ࣝ")+mHpaczX9ES7g)
	elif BBt5dqgsIEbFNDCioAl==mmKqLr9RX0ACN384JMcsFHzd(u"࠳௙"):
		data = obvQGmCVO8(file)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࣞ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪฮ๊ࠦลึๆสั๋ࠥไโࠢࠪࣟ")+mHpaczX9ES7g)
	return
def Q1zaYlG7V2hsW6Si():
	if aybmzWnDkuEcT3jpJClB2<DDHwpETQrAm0xMNXGfyhqsUi(u"࠴࠼௚"):
		nDRKguWex0iVN8 = vZL6j4tSClIGxzNE5DX(u"้๊ࠫริใࠣว๋ะࠠหีอาิ๋ࠠฦืาหึࠦใ้ัํࠤ็ี๊ๆࠢิๆ๊ࠦࠧ࣠")+str(aybmzWnDkuEcT3jpJClB2)+FF70emVxhWOngCty(u"่ࠬࠦๅ้ำหࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠๅษࠣฮ฾๋ไࠡ฻้ำ่ࠦ࠮้ࠡำ๋ࠥอไๆ์ีอࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤฬ๊แ๋ัํ์์อสࠡใํࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮࠦ࠮ࠡๆศู้ออࠡษ็ู้้ไสࠢๅ้ࠥฮสฮัํฯࠥฮั็ษ่ะ้่ࠥะ์ࠣษ้๏ࠠฦ์ࠣษฺีวาࠢิๆ๊ํࠠฤ฻็ํ๋ࠥๆࠡ࠳࠻࠲࠵࠭࣡")
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࣢"),nDRKguWex0iVN8)
		return
	Y8TnKMyWpslzubrkFR6tAOaDiSBg = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(mpusoZBJ6V(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࣣࠪ"))
	S5NRneCz4GQJoVWFxBM7c = ZMdfXcs4e1Y3qhuO7t6Fg0TwyaCpj([mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧࣤ")])
	EkxQ20jJyPDcu8Bh5w176sX4C,ZfXJQwcrk1eMqGhgpVNav53,ivqwpePJ647xGfkE9goQ2YlC8,Xf1kzciJ7lgA2,FZfkHLYg7OeEq,Pmdgn8FIZoxb1tcYO40MSXraK,zWpe3sDLXrJ = S5NRneCz4GQJoVWFxBM7c[pGncXOodjKhJzLSqVP1r(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨࣥ")]
	if EkxQ20jJyPDcu8Bh5w176sX4C or pGncXOodjKhJzLSqVP1r(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࣦࠩ") not in str(Y8TnKMyWpslzubrkFR6tAOaDiSBg):
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣧ"),JJu4MPClbTFpUwHiN(u"ࠬอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪࣨ"))
		AMu7aiqvPT6WcLOXDSkhFzdN = G3hVl67pIMOigeKa(TCF8wLyDvgumfiXPSKRh(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࣩࠬ"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		if not AMu7aiqvPT6WcLOXDSkhFzdN: return
	APcibD3ZNL4WlfrvVkY(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	return
def APcibD3ZNL4WlfrvVkY(showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	Y8TnKMyWpslzubrkFR6tAOaDiSBg = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(pGncXOodjKhJzLSqVP1r(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ࣪"))
	if y5yX4jh6kUEgWZQIc(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ࣫") not in str(Y8TnKMyWpslzubrkFR6tAOaDiSBg):
		if showDialogs:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࣬"),bDt7Ya1VEio3(u"่้ࠪษำโࠢฯ๋ฬุใࠡๆสࠤ๏ูสฯั่ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨ࣭"))
		return
	R4H0L7EGYlduVQFnCcB6pKSN = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,s0vAWcLSXEToH9Mik134q(u"ࠫࡦࡪࡤࡰࡰࡶ࣮ࠫ"),g4UCaNkHvLwGhjmW(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇ࣯ࠫ"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࠷࠳࠲ࡳࣰࠫ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡎࡻ࡙࡭ࡩ࡫࡯ࡏࡣࡹ࠲ࡽࡳ࡬ࠨࣱ"))
	if not KiTt9ZskMLjnCAUIJNXD7.path.exists(R4H0L7EGYlduVQFnCcB6pKSN): return
	MPuNKf0A87TUDJkxs15o = open(R4H0L7EGYlduVQFnCcB6pKSN,mpusoZBJ6V(u"ࠨࡴࡥࣲࠫ")).read()
	if b7sJAmSxlBvaMdHFz: MPuNKf0A87TUDJkxs15o = MPuNKf0A87TUDJkxs15o.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	bD2N4HQXnw = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠫࡠࡩ࠱ࠬ࡝ࡦ࠮࠰ࡡࡪࠫࠪ࠮ࠫ࠲࠯ࡅࠩ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩࣳ"),MPuNKf0A87TUDJkxs15o,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	lQV5m0jn4HwrFb9L,Cj96qXRT2fWvy = bD2N4HQXnw[h17Zb2ld4yLBrCP5tiw]
	g76jmyeoPKRdcBFpsbntGA = pGncXOodjKhJzLSqVP1r(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠫࣴ")+lQV5m0jn4HwrFb9L+mpusoZBJ6V(u"ࠫ࠱࠭ࣵ")+Cj96qXRT2fWvy+Xr2aHOK0huQ5DTS(u"ࠬࡂ࠯ࡷ࡫ࡨࡻࡸࡄࣶࠧ")
	if showDialogs:
		FQB1Kh7PeyzjNlsk = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(tg9l25NH6WTacVSifLyAmY(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࡙࡭ࡪࡽ࡭ࡰࡦࡨࠫࣷ"))
		if FQB1Kh7PeyzjNlsk==O4ylJvVNwLztdiHqBWDU(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪࣸ"): hLlK5NdGuWeZXqMU = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨࣹ")
		elif FQB1Kh7PeyzjNlsk==OOhnpQ8XvCVclGqdu(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨࣺ"): hLlK5NdGuWeZXqMU = OOhnpQ8XvCVclGqdu(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨࣻ")
		else: hLlK5NdGuWeZXqMU = tOrSvd8QKNB(u"ࠫ็๎วว็ࠣวำื้ࠨࣼ")
		BBt5dqgsIEbFNDCioAl = L2Lu1MQVHhiTX0(mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬࣽ"),tOrSvd8QKNB(u"࠭โ้ษษ้ࠥษฮา๋ࠪࣾ"),Xr2aHOK0huQ5DTS(u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧࣿ"),FF70emVxhWOngCty(u"ࠨไ๋หห๋ࠠศๆุ์ึ࠭ऀ"),FF70emVxhWOngCty(u"ࠩส๊ฯࠦอศๆํหࠥะำหะา้ࠥ࠭ँ")+hLlK5NdGuWeZXqMU,g4UCaNkHvLwGhjmW(u"ࠪห๋ะࠠศๆล๊ࠥะำหะา้ࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳่่ࠦาสࠤ๊฿ๆศ้ࠣห๋้ࠠหีอ฻๏฿ࠠศีอาิอๅࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฬิ๊วࠡ็้ࠤ็๎วว็ࠣห้้สศสฬࠤ࠳่ࠦฤ์ูหࠥะำหูํ฽ࠥห๊ใษไ๋ฬࠦแ๋ࠢฦ๎ࠥ๎โหࠢอุฬวࠠ࡝ࡰ࡟ࡲࠥ࠭ं")+r9rhtA5Tek8sIoLfqwF7JcEV+JJu4MPClbTFpUwHiN(u"ࠫࠥษฮหำࠣห้ศๆ่๋ࠡ฽ࠥอไใ๊สส๊ࠦวๅฬํࠤฯื๊ะࠢฦืฯิฯศ็๊หࠥลࠡࠨः")+jhAlCQ47ZgG)
		if BBt5dqgsIEbFNDCioAl==v54ZuLY6dQ(u"࠵௛"): er5CgA6Wtnj4RU = svULcgJ7jm(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨऄ")
		elif BBt5dqgsIEbFNDCioAl==K7bLVaiRkx0lgU5SQM(u"࠷௜"): er5CgA6Wtnj4RU = s0vAWcLSXEToH9Mik134q(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬअ")
		else: er5CgA6Wtnj4RU = QigevCplXxbPI1H
	else:
		FQB1Kh7PeyzjNlsk = uUTRHgAXJzm7pIDBjNt8.getSetting(O4ylJvVNwLztdiHqBWDU(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬआ"))
		if   FQB1Kh7PeyzjNlsk==QigevCplXxbPI1H: BBt5dqgsIEbFNDCioAl = tg9l25NH6WTacVSifLyAmY(u"࠶௝")
		elif FQB1Kh7PeyzjNlsk==y5yX4jh6kUEgWZQIc(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫइ"): BBt5dqgsIEbFNDCioAl = fk8jc5uDLX16qrih3ZaPxsvO(u"࠱௞")
		elif FQB1Kh7PeyzjNlsk==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨई"): BBt5dqgsIEbFNDCioAl = s0vAWcLSXEToH9Mik134q(u"࠳௟")
		er5CgA6Wtnj4RU = FQB1Kh7PeyzjNlsk
	if   BBt5dqgsIEbFNDCioAl==Xr2aHOK0huQ5DTS(u"࠲௠"): JfmdyzY1iALrGk7 = TCF8wLyDvgumfiXPSKRh(u"ࠪ࠹࠺࠲࠵࠵࠶࠯࠹࠺࠻ࠧउ")
	elif BBt5dqgsIEbFNDCioAl==FF70emVxhWOngCty(u"࠴௡"): JfmdyzY1iALrGk7 = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫ࠺࠺࠴࠭࠷࠸࠹࠱࠻࠵ࠨऊ")
	elif BBt5dqgsIEbFNDCioAl==svULcgJ7jm(u"࠶௢"): JfmdyzY1iALrGk7 = mpusoZBJ6V(u"ࠬ࠻࠵࠶࠮࠸࠹࠱࠻࠴࠵ࠩऋ")
	else: return
	uUTRHgAXJzm7pIDBjNt8.setSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫऌ"),er5CgA6Wtnj4RU)
	NDmGTCBFpVtPLqIn = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨऍ")+JfmdyzY1iALrGk7+FF70emVxhWOngCty(u"ࠨ࠮ࠪऎ")+Cj96qXRT2fWvy+pTwKPmzMSZhil5d2RWonre(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫए")
	OksXbHD6tZEGfzA = MPuNKf0A87TUDJkxs15o.replace(g76jmyeoPKRdcBFpsbntGA,NDmGTCBFpVtPLqIn)
	if b7sJAmSxlBvaMdHFz: OksXbHD6tZEGfzA = OksXbHD6tZEGfzA.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	open(R4H0L7EGYlduVQFnCcB6pKSN,tOrSvd8QKNB(u"ࠪࡻࡧ࠭ऐ")).write(OksXbHD6tZEGfzA)
	SQdRhwozVfv(AwKhgdpmBj0,JJu4MPClbTFpUwHiN(u"ࠫ࠳ࡢࡴࡔ࡭࡬ࡲࠥࡊࡥࡧࡣࡸࡰࡹࠦࡖࡪࡧࡺࡷ࠿࡛ࠦࠡࠩऑ")+JfmdyzY1iALrGk7+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࠦ࡝ࠨऒ"))
	if showDialogs: qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(svULcgJ7jm(u"࠭ࡒࡦ࡮ࡲࡥࡩ࡙࡫ࡪࡰࠫ࠭ࠬओ"))
	return
def Ig4PfGu1VSFY7():
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪऔ"),FF70emVxhWOngCty(u"ࠨสิ๊ฬ๋ฬࠡ฻่หิࠦแู๋้้้ࠣไสࠢ฼๊ิ้ࠠ࠯࠰࠱ࠤส๋วࠡล็ษฺีวาࠢๅำ๏๋ࠠ࠯࠰࠱ࠤศ๎ࠠศ่อࠤ๊๋ๆ้฻้๋ࠣࠦวิฬัำฬ๋ࠠศๆหี๋อๅอࠢ࠱࠲࠳ࠦร้ࠢ็ำ๏้ࠠๆึๆ่ฮࠦรฯำ์ࠤฯิีࠡฮ๊หื้ࠠฤ่อࠤํ๊วࠡฬัูࠥฮโ๋หࠣา้่ࠠศๆ็๋ࠥࡢ࡮࡝ࡰࠣัฬ๎ไࠡฬะำ๏ัࠠศๆหี๋อๅอࠢฦ์ࠥอสึๆࠣฬฬ๊ๅษำ่ะ๊ࠥๅฺำไอูࠥศษࠢสฺ่๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥํไࠡฬิ๎ิࠦแฮืࠣห้ะอะ์ฮหฯࠦวๅฤ้ࠤฤ࠭क"))
	if nndcv6tehuoKPpI==mmKqLr9RX0ACN384JMcsFHzd(u"࠶௣"): OXlgcotDer5zTQ1MFYva3nKxdNR(XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	return
def xH84fYWvX7yFw6Inb():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬख"),s0vAWcLSXEToH9Mik134q(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭ग"))
	return
def m6JAHwaQyKlbUXNpfW3e2vijgxzB():
	ZZ1G8ui05FrMvbkC = r9rhtA5Tek8sIoLfqwF7JcEV+y5yX4jh6kUEgWZQIc(u"ࠫฯ฿ฯศัุࠣ๏฿ษࠡฤ็ࠤ๊ำๅะࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥࡀࠠࠨघ")+jhAlCQ47ZgG
	ZZ1G8ui05FrMvbkC += K7bLVaiRkx0lgU5SQM(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫङ")
	ZZ1G8ui05FrMvbkC += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+pGncXOodjKhJzLSqVP1r(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷࠫच")+jhAlCQ47ZgG
	p9YD6iyZOzKubQgFMh3X = r9rhtA5Tek8sIoLfqwF7JcEV+tOrSvd8QKNB(u"ࠧษำ้ห๊าࠠีำํ฻ࠥอไๆี็้ࠥࡀࠠࠨछ")+jhAlCQ47ZgG
	p9YD6iyZOzKubQgFMh3X += aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬज")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+s0vAWcLSXEToH9Mik134q(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳࠩझ")+jhAlCQ47ZgG
	nDRKguWex0iVN8 = mpusoZBJ6V(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩञ")+ZZ1G8ui05FrMvbkC+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩट")+p9YD6iyZOzKubQgFMh3X
	XRZyfuiD8nLlKYPJ(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡸࡩࡨࡪࡷࠫठ"),QigevCplXxbPI1H,nDRKguWex0iVN8)
	return
def RnSBkihLmKDpvb(ouzBYNFqJn9fbP1y):
	otYUTIzA5Qwdy1ClJuKLas6r8(oL2eIiFEJnd7vxc)
	RulsXEM83VO0QKcCHza2TGSf4N9g = IIJimsEAhPdua8RFg4LvbMwV0rD5U6(ouzBYNFqJn9fbP1y)
	id,PXVdZQYTNslvg7wF0159Akr,Qc9doRJK1CMgWzqTruGf,rr4e95RPASc,oVMaZ1qEyj6kLgTCUBNAbsHIpOK,reason = RulsXEM83VO0QKcCHza2TGSf4N9g[h17Zb2ld4yLBrCP5tiw]
	e9HQkYzB6bw7DEO2gsm,EhM4uxfISnO7kLKFoG5JPy2ql = rr4e95RPASc.split(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭࡜࡯࠽࠾ࠫड"))
	p9YD6iyZOzKubQgFMh3X,uCyjMoXJUOq6eVP,S0ZwbUTgNQzXtM7OEJR1hDC8n2F = oVMaZ1qEyj6kLgTCUBNAbsHIpOK.split(svULcgJ7jm(u"ࠧ࡝ࡰ࠾࠿ࠬढ"))
	OIXFmkswBZPKJtH9zYvE = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	while OIXFmkswBZPKJtH9zYvE:
		l2TyBO9HKx8YnPGw6qfdz34pQvsFr = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,FF70emVxhWOngCty(u"ࠨะิ์ั࠭ण"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩศีุอไࠡำึห้ฯࠠๅๆ่ฬึ๋ฬࠨत"),Xr2aHOK0huQ5DTS(u"ࠪๆฬฬๅสࠢส่ฯฮัฺษอࠫथ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"้ࠫห๊ใษไࠤฬ๊ลฺๆส๊ฬะࠠ࠻ࠢࠣฮอืูࠡล๋ࠤฬ๋ำฮࠢส่อืๆศ็ฯࠫद"),p9YD6iyZOzKubQgFMh3X)
		if l2TyBO9HKx8YnPGw6qfdz34pQvsFr==XWbHfI9B8swrOL(u"࠸௤"): vGBHamEQeL9c8 = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠬ฿่ะหࠪध"),QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ๅษัฦࠤฬ๊สษำ฼ࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭न"),uCyjMoXJUOq6eVP,mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫऩ"))
		elif l2TyBO9HKx8YnPGw6qfdz34pQvsFr==pTwKPmzMSZhil5d2RWonre(u"࠱௥"): U6KgbJ9ld3WHCYqFf4AV2Ikx()
		else: OIXFmkswBZPKJtH9zYvE = YoAMfqm37GyFxbuKTt6e8CESHrhB
	ksV5ngvbcaS8ByMLYxlfXh(pTwKPmzMSZhil5d2RWonre(u"ࡇࡣ࡯ࡷࡪబ"))
	return
def XIH9Pn7tdj8hsZMC4i(showDialogs):
	nndcv6tehuoKPpI = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if showDialogs: nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨप"),QigevCplXxbPI1H,QigevCplXxbPI1H,vZL6j4tSClIGxzNE5DX(u"ࠩึศฬ๊ࠧफ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"๋้ࠪࠦร็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡ็ึัࠥ๎สึใํีࠥาๅ๋฻ࠣษ฾ีวะษอࠤอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢะ๎ะࠦสฺ๊าࠤัฺ๋๊ࠢส่ส฿ฯศัสฮࠥหไฺ๊๋ࠢ฾๐ษࠡฬฮฬ๏ะࠠศๆหี๋อๅอࠢยࠫब"))
	if nndcv6tehuoKPpI:
		AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if KiTt9ZskMLjnCAUIJNXD7.path.exists(UY4pdbX7slFWo0x3DaEJe6):
			try: KiTt9ZskMLjnCAUIJNXD7.remove(UY4pdbX7slFWo0x3DaEJe6)
			except: AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
		if showDialogs:
			if AMu7aiqvPT6WcLOXDSkhFzdN: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣ์ฯ฻แ๋ำ้้ࠣ็ࠠฦ฻าหิอสࠡสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫभ"))
			else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡ็ึั๋ࠥไโࠢส่ส฿ฯศัสฮࠬम"))
	return
def iJ4Qm5MVC3ndzXfRWLouYOcyatsrPD():
	SGDXI38kxfjzqJQwu15FcHhv()
	tbf7ejVMGCqEZ = uUTRHgAXJzm7pIDBjNt8.getSetting(Fg72JX6T5DkPy(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬय"))
	nDRKguWex0iVN8 = {}
	nDRKguWex0iVN8[pGncXOodjKhJzLSqVP1r(u"ࠧࡂࡗࡗࡓࠬर")] = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧऱ")
	nDRKguWex0iVN8[y5yX4jh6kUEgWZQIc(u"ࠩࡖࡘࡔࡖࠧल")] = O4ylJvVNwLztdiHqBWDU(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩळ")
	nDRKguWex0iVN8[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬऴ")] = tOrSvd8QKNB(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭व")+str(S8BEV2s9fbO14kaX/s0vAWcLSXEToH9Mik134q(u"࠷࠲௦"))+O4ylJvVNwLztdiHqBWDU(u"࠭ࠠะไํๆฮࠦแใูࠪश")
	LgfJRB2opz = nDRKguWex0iVN8[tbf7ejVMGCqEZ]
	BBt5dqgsIEbFNDCioAl = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠧไษืࠤࠬष")+str(S8BEV2s9fbO14kaX/pTwKPmzMSZhil5d2RWonre(u"࠸࠳௧"))+mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࠢาๆ๏่ษࠨस"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨह"),bDt7Ya1VEio3(u"ࠪษ๏่วโࠢๆห๊๊ࠧऺ"),LgfJRB2opz,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧऻ"))
	if BBt5dqgsIEbFNDCioAl==JJu4MPClbTFpUwHiN(u"࠳௨"): QX3uVKpiYv = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡒࡉࡎࡋࡗࡉࡉ़࠭")
	elif BBt5dqgsIEbFNDCioAl==XWbHfI9B8swrOL(u"࠵௩"): QX3uVKpiYv = XWbHfI9B8swrOL(u"࠭ࡁࡖࡖࡒࠫऽ")
	elif BBt5dqgsIEbFNDCioAl==y5yX4jh6kUEgWZQIc(u"࠷௪"): QX3uVKpiYv = mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡔࡖࡒࡔࠬा")
	else: QX3uVKpiYv = QigevCplXxbPI1H
	if QX3uVKpiYv:
		uUTRHgAXJzm7pIDBjNt8.setSetting(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧि"),QX3uVKpiYv)
		Pro1ihNvXHqye8In0sEmB = nDRKguWex0iVN8[QX3uVKpiYv]
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Pro1ihNvXHqye8In0sEmB)
	return
def RkKsEQq7fvSOHI61NoAtw0GJpP():
	nDRKguWex0iVN8 = {}
	nDRKguWex0iVN8[mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࡄ࡙࡙ࡕࠧी")] = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨु")
	nDRKguWex0iVN8[O4ylJvVNwLztdiHqBWDU(u"ࠫࡆ࡙ࡋࠨू")] = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩृ")
	nDRKguWex0iVN8[DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ࡓࡕࡑࡓࠫॄ")] = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪॅ")
	KDFHr4b0AhWOIJmUnvQ = uUTRHgAXJzm7pIDBjNt8.getSetting(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨॆ"))
	tbf7ejVMGCqEZ = uUTRHgAXJzm7pIDBjNt8.getSetting(v54ZuLY6dQ(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬे"))
	LgfJRB2opz = nDRKguWex0iVN8[tbf7ejVMGCqEZ]+KDFHr4b0AhWOIJmUnvQ
	BBt5dqgsIEbFNDCioAl = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨै"),JJu4MPClbTFpUwHiN(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪॉ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬห๊ใษไࠤ่อๅๅࠩॊ"),LgfJRB2opz,DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪो"))
	if BBt5dqgsIEbFNDCioAl==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠶௫"): QX3uVKpiYv = Fg72JX6T5DkPy(u"ࠧࡂࡕࡎࠫौ")
	elif BBt5dqgsIEbFNDCioAl==K7bLVaiRkx0lgU5SQM(u"࠱௬"): QX3uVKpiYv = JJu4MPClbTFpUwHiN(u"ࠨࡃࡘࡘࡔ्࠭")
	elif BBt5dqgsIEbFNDCioAl==fk8jc5uDLX16qrih3ZaPxsvO(u"࠳௭"): QX3uVKpiYv = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡖࡘࡔࡖࠧॎ")
	if BBt5dqgsIEbFNDCioAl in [fk8jc5uDLX16qrih3ZaPxsvO(u"࠳௯"),tg9l25NH6WTacVSifLyAmY(u"࠳௮")]:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡧࡪࡴࡴࡦࡴࠪॏ"),v54ZuLY6dQ(u"ุࠫ๐ัโำ࠽ࠤࠬॐ")+ye5VdS961JgscKZjAp0HXnT[nfC2im3NzUQk],v54ZuLY6dQ(u"ู๊ࠬาใิ࠾ࠥ࠭॑")+ye5VdS961JgscKZjAp0HXnT[h17Zb2ld4yLBrCP5tiw],QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็॒ࠬ"))
		if nndcv6tehuoKPpI==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠵௰"): yyVAGdCK5Pjhar8gpnbcIetUkMT = ye5VdS961JgscKZjAp0HXnT[h17Zb2ld4yLBrCP5tiw]
		else: yyVAGdCK5Pjhar8gpnbcIetUkMT = ye5VdS961JgscKZjAp0HXnT[nfC2im3NzUQk]
	elif BBt5dqgsIEbFNDCioAl==O4ylJvVNwLztdiHqBWDU(u"࠷௱"): yyVAGdCK5Pjhar8gpnbcIetUkMT = QigevCplXxbPI1H
	else: QX3uVKpiYv = QigevCplXxbPI1H
	if QX3uVKpiYv:
		uUTRHgAXJzm7pIDBjNt8.setSetting(FF70emVxhWOngCty(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ॓"),QX3uVKpiYv)
		uUTRHgAXJzm7pIDBjNt8.setSetting(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡣࡹ࠲ࡩࡴࡳࠨ॔"),yyVAGdCK5Pjhar8gpnbcIetUkMT)
		Pro1ihNvXHqye8In0sEmB = nDRKguWex0iVN8[QX3uVKpiYv]+yyVAGdCK5Pjhar8gpnbcIetUkMT
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Pro1ihNvXHqye8In0sEmB)
	return
def U7XPIj3kxuEJdloZtnYT8QAb():
	tbf7ejVMGCqEZ = uUTRHgAXJzm7pIDBjNt8.getSetting(pGncXOodjKhJzLSqVP1r(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧॕ"))
	nDRKguWex0iVN8 = {}
	nDRKguWex0iVN8[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡅ࡚࡚ࡏࠨॖ")] = tg9l25NH6WTacVSifLyAmY(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬॗ")
	nDRKguWex0iVN8[XWbHfI9B8swrOL(u"ࠬࡇࡓࡌࠩक़")] = JJu4MPClbTFpUwHiN(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧख़")
	nDRKguWex0iVN8[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡔࡖࡒࡔࠬग़")] = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪज़")
	LgfJRB2opz = nDRKguWex0iVN8[tbf7ejVMGCqEZ]
	BBt5dqgsIEbFNDCioAl = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,XWbHfI9B8swrOL(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧड़"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩढ़"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫส๐โศใࠣ็ฬ๋ไࠨफ़"),LgfJRB2opz,mpusoZBJ6V(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨय़"))
	if BBt5dqgsIEbFNDCioAl==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠶௲"): QX3uVKpiYv = JJu4MPClbTFpUwHiN(u"࠭ࡁࡔࡍࠪॠ")
	elif BBt5dqgsIEbFNDCioAl==mpusoZBJ6V(u"࠱௳"): QX3uVKpiYv = Xr2aHOK0huQ5DTS(u"ࠧࡂࡗࡗࡓࠬॡ")
	elif BBt5dqgsIEbFNDCioAl==mmKqLr9RX0ACN384JMcsFHzd(u"࠳௴"): QX3uVKpiYv = OOhnpQ8XvCVclGqdu(u"ࠨࡕࡗࡓࡕ࠭ॢ")
	else: QX3uVKpiYv = QigevCplXxbPI1H
	if QX3uVKpiYv:
		uUTRHgAXJzm7pIDBjNt8.setSetting(pGncXOodjKhJzLSqVP1r(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧॣ"),QX3uVKpiYv)
		Pro1ihNvXHqye8In0sEmB = nDRKguWex0iVN8[QX3uVKpiYv]
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Pro1ihNvXHqye8In0sEmB)
	return
def OsgDqM27jLyWAT():
	J3k7F4G6Rx = uUTRHgAXJzm7pIDBjNt8.getSetting(Xr2aHOK0huQ5DTS(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ।"))
	if J3k7F4G6Rx==OOhnpQ8XvCVclGqdu(u"ࠫࡘ࡚ࡏࡑࠩ॥"): header = y5yX4jh6kUEgWZQIc(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ०")
	else: header = bDt7Ya1VEio3(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ१")
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧฦ์ๅหๆ࠭२"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨฬไ฽๏๊ࠧ३"),header,svULcgJ7jm(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭४"))
	if nndcv6tehuoKPpI==-TCF8wLyDvgumfiXPSKRh(u"࠳௵"): return
	elif nndcv6tehuoKPpI:
		uUTRHgAXJzm7pIDBjNt8.setSetting(mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ५"),OOhnpQ8XvCVclGqdu(u"ࠫࡆ࡛ࡔࡐࠩ६"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ७"),OOhnpQ8XvCVclGqdu(u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ८"))
	else:
		uUTRHgAXJzm7pIDBjNt8.setSetting(y5yX4jh6kUEgWZQIc(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡱࡪࡴࡵࡴࡥࡤࡧ࡭࡫ࠧ९"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡕࡗࡓࡕ࠭॰"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬॱ"),pGncXOodjKhJzLSqVP1r(u"ࠪฮ๊ࠦล๋ไสๅࠥะฮำ์้ࠤฬ๊โ้ษษ้ࠬॲ"))
	return
def iMJS3wEYgzDx5Np8R1KHcntVf7h(d8kolNVuLsPAjQZ9ROpUHBgix):
	if d8kolNVuLsPAjQZ9ROpUHBgix!=QigevCplXxbPI1H:
		d8kolNVuLsPAjQZ9ROpUHBgix = Yrz5bs6eFPfiZQTpBSLx8nH2Kcl(d8kolNVuLsPAjQZ9ROpUHBgix)
		d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL).encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		nWQsOEmjVrxlh = fk8jc5uDLX16qrih3ZaPxsvO(u"࠴࠴࠶࠶࠳௶")
		qWa01nz35c9rEDUxLh = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.Window(nWQsOEmjVrxlh)
		qWa01nz35c9rEDUxLh.getControl(mpusoZBJ6V(u"࠷࠶࠷௷")).setLabel(d8kolNVuLsPAjQZ9ROpUHBgix)
	return
beVvD6iG19oB2x = [
			 Fg72JX6T5DkPy(u"ࠦࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࠠࡢࡸࡶࡴࡦࡩࡥࡴ࠲ࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡧࡺࡸࡲࡦࡰࡷࡰࡾࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠤॳ")
			,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡧࡱࡵࠤࡒࡧ࡬ࡪࡥ࡬ࡳࡺࡹࠠࡴࡥࡵ࡭ࡵࡺࡳࠨॴ")
			,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡐࡗࡔࠣࡍࡕ࡚ࡖࠡࡕ࡬ࡱࡵࡲࡥࠡࡅ࡯࡭ࡪࡴࡴࠨॵ")
			,O4ylJvVNwLztdiHqBWDU(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡘ࡬ࡨࡪࡵࠠࡊࡰࡩࡳࠥࡑࡥࡺࠩॶ")
			,Xr2aHOK0huQ5DTS(u"ࠨࡶ࡫࡭ࡸࠦࡨࡢࡵ࡫ࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࡩࡴࠢࡥࡶࡴࡱࡥ࡯ࠩॷ")
			,v54ZuLY6dQ(u"ࠩࡸࡷࡪࡹࠠࡱ࡮ࡤ࡭ࡳࠦࡈࡕࡖࡓࠤ࡫ࡵࡲࠡࡣࡧࡨ࠲ࡵ࡮ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡶࠫॸ")
			,O4ylJvVNwLztdiHqBWDU(u"ࠪࡥࡩࡼࡡ࡯ࡥࡨࡨ࠲ࡻࡳࡢࡩࡨ࠲࡭ࡺ࡭࡭ࠩॹ")+tOrSvd8QKNB(u"ࠫࠨ࠭ॺ")+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫॻ")
			,K7bLVaiRkx0lgU5SQM(u"࠭ࡉ࡯ࡵࡨࡧࡺࡸࡥࡓࡧࡴࡹࡪࡹࡴࡘࡣࡵࡲ࡮ࡴࡧ࠭ࠩॼ")
			,g4UCaNkHvLwGhjmW(u"ࠧࡆࡴࡵࡳࡷࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄ࠰ࡁࡰࡳࡩ࡫ࡥ࠾࠲ࠩࡸࡪࡾࡴࡵ࠿ࠪॽ")
			,OOhnpQ8XvCVclGqdu(u"ࠨࡹࡤࡶࡳ࡯࡮ࡨࡵ࠱ࡻࡦࡸ࡮ࠩࠩॾ")
			,Xr2aHOK0huQ5DTS(u"ࠩࡡࡢࡣࡤ࡞ࠨॿ")
			,g4UCaNkHvLwGhjmW(u"ࠪࡐࡴࡧࡤࡪࡰࡪࠤࡸࡱࡩ࡯ࠢࡩ࡭ࡱ࡫࠺ࠨঀ")
			]
def ILjERHZFktefB19uJCco7S(lP9YsOehk3r8HWpxC):
	if s0vAWcLSXEToH9Mik134q(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩঁ") in lP9YsOehk3r8HWpxC and y5yX4jh6kUEgWZQIc(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪং") in lP9YsOehk3r8HWpxC: return XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	for d8kolNVuLsPAjQZ9ROpUHBgix in beVvD6iG19oB2x:
		if d8kolNVuLsPAjQZ9ROpUHBgix in lP9YsOehk3r8HWpxC: return XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	return YoAMfqm37GyFxbuKTt6e8CESHrhB
def TkJzd5n3xL8SB(data):
	VDkbvLl2humG9rUYw = K7bLVaiRkx0lgU5SQM(u"࠽௹") if b7sJAmSxlBvaMdHFz else mmKqLr9RX0ACN384JMcsFHzd(u"࠶࠻௸")
	data = data.replace(tOrSvd8QKNB(u"࠳࠱௺")*hT7zFDpEyUqf8sXuN,VDkbvLl2humG9rUYw*hT7zFDpEyUqf8sXuN)
	data = data.replace(mpusoZBJ6V(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬঃ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠧ࠻ࠢࠪ঄"))
	tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = QigevCplXxbPI1H
	for lP9YsOehk3r8HWpxC in data.splitlines():
		f4zmtJZbCrOFKc3Y1W8Ld06GwAes = sBvufaD6c9YHdOqTjCQ3.findall(O4ylJvVNwLztdiHqBWDU(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧঅ"),lP9YsOehk3r8HWpxC,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if f4zmtJZbCrOFKc3Y1W8Ld06GwAes: lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(f4zmtJZbCrOFKc3Y1W8Ld06GwAes[h17Zb2ld4yLBrCP5tiw],QigevCplXxbPI1H)
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 += aSBkt4OU8JpWTEzVIHjAiv+lP9YsOehk3r8HWpxC
	return tNQDMKVydhBqgaUvJ7oeAkTHxsL1
def XLsBySdloIQcif3tzKvDJFrhTWHCGp(HwgWzp62IYynfjSrAUutxFq):
	if pGncXOodjKhJzLSqVP1r(u"ࠩࡒࡐࡉ࠭আ") in HwgWzp62IYynfjSrAUutxFq:
		qbBMIKkYDws6iZHaSXeW7N5n9APL = gpiHl9C7eKx
		header = svULcgJ7jm(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡมࠪই")
	else:
		qbBMIKkYDws6iZHaSXeW7N5n9APL = FcupZdBmjb4nReDCzs9wLKrV3lfx
		header = pGncXOodjKhJzLSqVP1r(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫঈ")
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,header,pGncXOodjKhJzLSqVP1r(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨউ"))
	if nndcv6tehuoKPpI!=QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠲௻"): return
	MePZdR6zgNn,d3nA2LsHai59 = [],Fg72JX6T5DkPy(u"࠲௼")
	size,count = dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(qbBMIKkYDws6iZHaSXeW7N5n9APL)
	file = open(qbBMIKkYDws6iZHaSXeW7N5n9APL,JJu4MPClbTFpUwHiN(u"࠭ࡲࡣࠩঊ"))
	if size>OTRKI6LbrQnZEm(u"࠵࠵࠶࠲࠱࠲௾"): file.seek(-bDt7Ya1VEio3(u"࠴࠴࠵࠷࠰࠱௽"),KiTt9ZskMLjnCAUIJNXD7.SEEK_END)
	data = file.read()
	file.close()
	if b7sJAmSxlBvaMdHFz: data = data.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	data = TkJzd5n3xL8SB(data)
	pS1FVtbXfLgZ0nxY3eTzqGd = data.split(aSBkt4OU8JpWTEzVIHjAiv)
	for lP9YsOehk3r8HWpxC in reversed(pS1FVtbXfLgZ0nxY3eTzqGd):
		VXySM62wGsKe8fz3QPNJxDh5dp = ILjERHZFktefB19uJCco7S(lP9YsOehk3r8HWpxC)
		if VXySM62wGsKe8fz3QPNJxDh5dp: continue
		lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(bDt7Ya1VEio3(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩঋ"),r9rhtA5Tek8sIoLfqwF7JcEV+pTwKPmzMSZhil5d2RWonre(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫঌ")+jhAlCQ47ZgG)
		lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(Xr2aHOK0huQ5DTS(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩ঍"),tg9l25NH6WTacVSifLyAmY(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭঎")+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫএ")+jhAlCQ47ZgG)
		LiY30J87UNFOIQ = QigevCplXxbPI1H
		IFMdmCaD1GZ9NQVHsk = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬঐ"),lP9YsOehk3r8HWpxC,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if IFMdmCaD1GZ9NQVHsk:
			lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw],IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk]).replace(IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][JxuTQLOD357o41evylqPmRdf],QigevCplXxbPI1H)
			LiY30J87UNFOIQ = IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk]
		else:
			IFMdmCaD1GZ9NQVHsk = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭঑"),lP9YsOehk3r8HWpxC,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if IFMdmCaD1GZ9NQVHsk:
				lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk],QigevCplXxbPI1H)
				LiY30J87UNFOIQ = IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw]
		if LiY30J87UNFOIQ: lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(LiY30J87UNFOIQ,iVCLpNIM8BQs9PdSgKZvlFeo3a5+LiY30J87UNFOIQ+jhAlCQ47ZgG)
		MePZdR6zgNn.append(lP9YsOehk3r8HWpxC)
		if len(str(MePZdR6zgNn))>pTwKPmzMSZhil5d2RWonre(u"࠺࠶࠱࠱࠲௿"): break
	MePZdR6zgNn = reversed(MePZdR6zgNn)
	w6zeWrUvdsiq4tBmKObEopX8HMS = aSBkt4OU8JpWTEzVIHjAiv.join(MePZdR6zgNn)
	XRZyfuiD8nLlKYPJ(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧ࡭ࡧࡩࡸࠬ঒"),pGncXOodjKhJzLSqVP1r(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬও"),w6zeWrUvdsiq4tBmKObEopX8HMS,pTwKPmzMSZhil5d2RWonre(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬঔ"))
	return
def tEbmPrugyMO5ldSCH9qZ():
	I50j1rakHnLCf7EQKztYhxAqwOJTv = open(bQiqIMtxKPkJUoEgvDawN7,XWbHfI9B8swrOL(u"ࠪࡶࡧ࠭ক")).read()
	if b7sJAmSxlBvaMdHFz: I50j1rakHnLCf7EQKztYhxAqwOJTv = I50j1rakHnLCf7EQKztYhxAqwOJTv.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	I50j1rakHnLCf7EQKztYhxAqwOJTv = I50j1rakHnLCf7EQKztYhxAqwOJTv.replace(mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡡࡺࠧখ"),OOhnpQ8XvCVclGqdu(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧগ"))
	S5NRneCz4GQJoVWFxBM7c = sBvufaD6c9YHdOqTjCQ3.findall(Fg72JX6T5DkPy(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧঘ"),I50j1rakHnLCf7EQKztYhxAqwOJTv,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for lP9YsOehk3r8HWpxC in S5NRneCz4GQJoVWFxBM7c:
		I50j1rakHnLCf7EQKztYhxAqwOJTv = I50j1rakHnLCf7EQKztYhxAqwOJTv.replace(lP9YsOehk3r8HWpxC,r9rhtA5Tek8sIoLfqwF7JcEV+lP9YsOehk3r8HWpxC+jhAlCQ47ZgG)
	vxHN6SWyDEMjBY2ksUl9n(svULcgJ7jm(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨঙ"),I50j1rakHnLCf7EQKztYhxAqwOJTv)
	return
def RRx6JG3ShkEL5VnZelig():
	ZZ1G8ui05FrMvbkC = g4UCaNkHvLwGhjmW(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪচ")
	p9YD6iyZOzKubQgFMh3X = Xr2aHOK0huQ5DTS(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ছ")
	uCyjMoXJUOq6eVP = Xr2aHOK0huQ5DTS(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭জ")
	nDRKguWex0iVN8 = ZZ1G8ui05FrMvbkC+O4ylJvVNwLztdiHqBWDU(u"ࠫ࠿ࠦࠧঝ")+p9YD6iyZOzKubQgFMh3X+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࠦ࠮ࠡࠩঞ")+uCyjMoXJUOq6eVP
	XRZyfuiD8nLlKYPJ(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ট"),pGncXOodjKhJzLSqVP1r(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪঠ"),nDRKguWex0iVN8,Fg72JX6T5DkPy(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫড"))
	return
def PZMEo96N8F50USez4(type,nDRKguWex0iVN8,showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,url=QigevCplXxbPI1H,m9TrBXjhwRgI=QigevCplXxbPI1H,d8kolNVuLsPAjQZ9ROpUHBgix=QigevCplXxbPI1H,ffSMj4UdbgVEZpvX8BwlFQ1q=QigevCplXxbPI1H):
	P7churO6tU2fxsvGaeSRmyZXI8TE = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if not nVIdjZ1ybeU8TB9tSpAQH(bDt7Ya1VEio3(u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪঢ")):
		if showDialogs:
			dcxBVKF5qIYJwsGeRyPA4vNaoZ = (VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪหู้ืา࠼ࠪণ") in nDRKguWex0iVN8 and hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫฬ๊ๅไษ้࠾ࠬত") in nDRKguWex0iVN8 and JJu4MPClbTFpUwHiN(u"ࠬอไๆๆไ࠾ࠬথ") in nDRKguWex0iVN8 and pTwKPmzMSZhil5d2RWonre(u"࠭วๅะฺวࠬদ") in nDRKguWex0iVN8 and bDt7Ya1VEio3(u"ࠧศๆู่ิื࠺ࠨধ") in nDRKguWex0iVN8)
			if not dcxBVKF5qIYJwsGeRyPA4vNaoZ: P7churO6tU2fxsvGaeSRmyZXI8TE = UJV3rPyElz5xRav0FD(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨন"),QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"๊่ࠩࠥะัิๆ๋ࠣีํࠠศๆิืฬ๊ษࠡว็ํࠥอไๆสิ้ั࠭঩"),nDRKguWex0iVN8.replace(XWbHfI9B8swrOL(u"ࠪࡠࡡࡴࠧপ"),aSBkt4OU8JpWTEzVIHjAiv))
	elif showDialogs:
		nDRKguWex0iVN8 = K7bLVaiRkx0lgU5SQM(u"ࠫࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษ࡝࡞ࡱฮ๊ࠦๅิฯࠣห้ืำศๆฬࠫফ")
		cqXv9RudmK8k6pMH57DGlC2wQsE = UJV3rPyElz5xRav0FD(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬব"),QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ভ")+s0vAWcLSXEToH9Mik134q(u"ࠧࠡࠢ࠴࠳࠺࠭ম"),K7bLVaiRkx0lgU5SQM(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭য"))
		ddgk7wApLCIER = UJV3rPyElz5xRav0FD(Xr2aHOK0huQ5DTS(u"ࠩࡦࡩࡳࡺࡥࡳࠩর"),QigevCplXxbPI1H,QigevCplXxbPI1H,FF70emVxhWOngCty(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ঱")+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࠥࠦ࠲࠰࠷ࠪল"),pTwKPmzMSZhil5d2RWonre(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ঳"))
		hKHtuvNDi7r = UJV3rPyElz5xRav0FD(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡣࡦࡰࡷࡩࡷ࠭঴"),QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ঵")+v54ZuLY6dQ(u"ࠨࠢࠣ࠷࠴࠻ࠧশ"),tOrSvd8QKNB(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧষ"))
		WWHrECvkx3Zf9GXNghnuFLmOwDqY0 = UJV3rPyElz5xRav0FD(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡧࡪࡴࡴࡦࡴࠪস"),QigevCplXxbPI1H,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫহ")+v54ZuLY6dQ(u"ࠬࠦࠠ࠵࠱࠸ࠫ঺"),K7bLVaiRkx0lgU5SQM(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ঻"))
		P7churO6tU2fxsvGaeSRmyZXI8TE = UJV3rPyElz5xRav0FD(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡤࡧࡱࡸࡪࡸ়ࠧ"),QigevCplXxbPI1H,QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨঽ")+Fg72JX6T5DkPy(u"ࠩࠣࠤ࠺࠵࠵ࠨা"),g4UCaNkHvLwGhjmW(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨি"))
	PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(v54ZuLY6dQ(u"࠹࠲ఀ"),YoAMfqm37GyFxbuKTt6e8CESHrhB)
	ZcY4p96wv8x0kLgTEumoi = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࡆ࡜࠺ࠡࠩী")+PXVdZQYTNslvg7wF0159Akr+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬ࠳ࠧু")+type
	BzoGPDXaKYU6wk9S = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if OOhnpQ8XvCVclGqdu(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩূ") in d8kolNVuLsPAjQZ9ROpUHBgix else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if not P7churO6tU2fxsvGaeSRmyZXI8TE:
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪৃ"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫৄ"))
		return YoAMfqm37GyFxbuKTt6e8CESHrhB
	DDPaAr7HFQ3j24CY9t = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(tg9l25NH6WTacVSifLyAmY(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨ৅"))
	nDRKguWex0iVN8 += K7bLVaiRkx0lgU5SQM(u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ৆")+GVmdqbtLu8lUXNxp13aHOvkscR+y5yX4jh6kUEgWZQIc(u"ࠫࠥࡀ࡜࡝ࡰࠪে")
	nDRKguWex0iVN8 += g4UCaNkHvLwGhjmW(u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭ৈ")+PXVdZQYTNslvg7wF0159Akr+pGncXOodjKhJzLSqVP1r(u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬ৉")+FwcH7quaG4m5vp2W9I+pTwKPmzMSZhil5d2RWonre(u"ࠧࠡ࠼࡟ࡠࡳ࠭৊")
	nDRKguWex0iVN8 += K7bLVaiRkx0lgU5SQM(u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭ো")+DDPaAr7HFQ3j24CY9t
	uZ9qIdr8OtN = WfKzkBJuTObrMa1eloxI()
	uZ9qIdr8OtN = sqXK91rDldVAEcRTSQL4n2tbC(uZ9qIdr8OtN)
	if uZ9qIdr8OtN: nDRKguWex0iVN8 += hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࠣ࠾ࡡࡢ࡮ࡍࡱࡦࡥࡹ࡯࡯࡯࠼ࠣࠫৌ")+uZ9qIdr8OtN
	if url: nDRKguWex0iVN8 += tOrSvd8QKNB(u"ࠪࠤ࠿ࡢ࡜࡯ࡗࡕࡐ࠿্ࠦࠧ")+url
	if m9TrBXjhwRgI: nDRKguWex0iVN8 += s0vAWcLSXEToH9Mik134q(u"ࠫࠥࡀ࡜࡝ࡰࡖࡳࡺࡸࡣࡦ࠼ࠣࠫৎ")+m9TrBXjhwRgI
	nDRKguWex0iVN8 += g4UCaNkHvLwGhjmW(u"ࠬࠦ࠺࡝࡞ࡱࠫ৏")
	if showDialogs: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(y5yX4jh6kUEgWZQIc(u"࠭ฬศำํࠤฬ๊ลาีส่ࠬ৐"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧศๆิะฬวࠠศๆส๊ฯ฾วาࠩ৑"))
	if ffSMj4UdbgVEZpvX8BwlFQ1q:
		w6zeWrUvdsiq4tBmKObEopX8HMS = ffSMj4UdbgVEZpvX8BwlFQ1q
		if b7sJAmSxlBvaMdHFz: w6zeWrUvdsiq4tBmKObEopX8HMS = w6zeWrUvdsiq4tBmKObEopX8HMS.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		w6zeWrUvdsiq4tBmKObEopX8HMS = akgfpLEN8Kn396XjFUut4QJVI.b64encode(w6zeWrUvdsiq4tBmKObEopX8HMS)
	elif BzoGPDXaKYU6wk9S:
		if hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ৒") in d8kolNVuLsPAjQZ9ROpUHBgix: jfrywbcQDZuhEiaWYkJ81Ntn36O = gpiHl9C7eKx
		else: jfrywbcQDZuhEiaWYkJ81Ntn36O = FcupZdBmjb4nReDCzs9wLKrV3lfx
		if not KiTt9ZskMLjnCAUIJNXD7.path.exists(jfrywbcQDZuhEiaWYkJ81Ntn36O):
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ৓"),pGncXOodjKhJzLSqVP1r(u"ࠪืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥเ๊า่ࠢ์ั๎ฯࠨ৔"))
			return YoAMfqm37GyFxbuKTt6e8CESHrhB
		SQdRhwozVfv(AwKhgdpmBj0,OOhnpQ8XvCVclGqdu(u"ࠫ࠳ࡢࡴࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡳࡦࡰࡧࠤࡹ࡮ࡥࠡ࡮ࡲ࡫࡫࡯࡬ࡦࠩ৕"))
		MePZdR6zgNn,d3nA2LsHai59 = [],OOhnpQ8XvCVclGqdu(u"࠰ఁ")
		file = open(jfrywbcQDZuhEiaWYkJ81Ntn36O,pGncXOodjKhJzLSqVP1r(u"ࠬࡸࡢࠨ৖"))
		size,count = dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(jfrywbcQDZuhEiaWYkJ81Ntn36O)
		if size>FF70emVxhWOngCty(u"࠴࠲࠴࠴࠵࠶ం"): file.seek(-FF70emVxhWOngCty(u"࠴࠲࠴࠴࠵࠶ం"),KiTt9ZskMLjnCAUIJNXD7.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		data = TkJzd5n3xL8SB(data)
		pS1FVtbXfLgZ0nxY3eTzqGd = data.splitlines()
		for lP9YsOehk3r8HWpxC in reversed(pS1FVtbXfLgZ0nxY3eTzqGd):
			VXySM62wGsKe8fz3QPNJxDh5dp = ILjERHZFktefB19uJCco7S(lP9YsOehk3r8HWpxC)
			if VXySM62wGsKe8fz3QPNJxDh5dp: continue
			IFMdmCaD1GZ9NQVHsk = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"࠭࡞ࠩ࡞ࡧ࠯࠲࠮࡜ࡥ࠭࠰ࡠࡩ࠱ࠠ࡝ࡦ࠮࠾ࡡࡪࠫ࠻࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭ࠬ࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ৗ"),lP9YsOehk3r8HWpxC,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if IFMdmCaD1GZ9NQVHsk:
				lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw],IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk]).replace(IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][JxuTQLOD357o41evylqPmRdf],QigevCplXxbPI1H)
			else:
				IFMdmCaD1GZ9NQVHsk = sBvufaD6c9YHdOqTjCQ3.findall(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ৘"),lP9YsOehk3r8HWpxC,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if IFMdmCaD1GZ9NQVHsk: lP9YsOehk3r8HWpxC = lP9YsOehk3r8HWpxC.replace(IFMdmCaD1GZ9NQVHsk[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk],QigevCplXxbPI1H)
			MePZdR6zgNn.append(lP9YsOehk3r8HWpxC)
			if len(str(MePZdR6zgNn))>g4UCaNkHvLwGhjmW(u"࠴࠸࠵࠵࠶࠰ః"): break
		MePZdR6zgNn = reversed(MePZdR6zgNn)
		w6zeWrUvdsiq4tBmKObEopX8HMS = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨ࡞ࡵࡠࡳ࠭৙").join(MePZdR6zgNn)
		w6zeWrUvdsiq4tBmKObEopX8HMS = w6zeWrUvdsiq4tBmKObEopX8HMS.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		w6zeWrUvdsiq4tBmKObEopX8HMS = akgfpLEN8Kn396XjFUut4QJVI.b64encode(w6zeWrUvdsiq4tBmKObEopX8HMS)
	else: w6zeWrUvdsiq4tBmKObEopX8HMS = QigevCplXxbPI1H
	url = OQv0iWIw5bFRATU2mxJjZK[v54ZuLY6dQ(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ৚")][JxuTQLOD357o41evylqPmRdf]
	A1AqSc2LNwW0ETgyaRl9 = {fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡷࡺࡨࡪࡦࡥࡷࠫ৛"):ZcY4p96wv8x0kLgTEumoi,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬড়"):nDRKguWex0iVN8,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡲ࡯ࡨࡨ࡬ࡰࡪ࠭ঢ়"):w6zeWrUvdsiq4tBmKObEopX8HMS}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,TCF8wLyDvgumfiXPSKRh(u"࠭ࡐࡐࡕࡗࠫ৞"),url,A1AqSc2LNwW0ETgyaRl9,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡖࡉࡓࡊ࡟ࡆࡏࡄࡍࡑ࠳࠱ࡴࡶࠪয়"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࠤࡶࡹࡨࡩࡥࡦࡦࡨࡨࠧࡀࠠ࠲࠮ࠪৠ") in aY63L2NhgvwJIxPAoDG4MKECmZXF1: AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	else: AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if showDialogs:
		if AMu7aiqvPT6WcLOXDSkhFzdN:
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc(K7bLVaiRkx0lgU5SQM(u"ࠩอ้ࠥอไฦำึห้ࠦศ็ฮสัࠬৡ"),FF70emVxhWOngCty(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫৢ"))
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥࡹࡥ࡯ࡶࠪৣ"),JJu4MPClbTFpUwHiN(u"ࠬะๅࠡวิืฬ๊ࠠศๆิืฬ๊ษࠡส้ะฬำࠧ৤"))
		else:
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc(OOhnpQ8XvCVclGqdu(u"࠭ไๅลึๅࠥ็ิๅࠢส่สืำศๆࠪ৥"),tOrSvd8QKNB(u"ࠧࡇࡣ࡬ࡰࡺࡸࡥࠨ০"))
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ১"),Fg72JX6T5DkPy(u"ࠩั฻ศ่ࠦโึ็ࠤๆ๐ࠠฦำึห้ࠦวๅำึห้ฯࠧ২"))
	return AMu7aiqvPT6WcLOXDSkhFzdN
def RW3Pfe8oB4bwKg2CjimsarMlIJ5():
	ZZ1G8ui05FrMvbkC = JJu4MPClbTFpUwHiN(u"ࠪ࠵࠳ࠦࠠࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡰࡳࡱࡥࡰࡪࡳࠠࡸ࡫ࡷ࡬ࠥࡇࡲࡢࡤ࡬ࡧࠥࡺࡥࡹࡶࡷࠤࡹ࡮ࡥ࡯ࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡧࡱࡱࡸࠥࡺ࡯ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ৩")
	p9YD6iyZOzKubQgFMh3X = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࠶࠴ࠠࠡࠢศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅละีๆࠦวๅ฻ิฬ๏ฯࠠโษำ๋อࠦลๅ๋ࠣษ฾ีวะษอࠤํอฬ่หࠣ็ํี๊ࠡอ่ࠤ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡว็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭৪")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"ࠬࡇࡲࡢࡤ࡬ࡧࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭৫"),ZZ1G8ui05FrMvbkC+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭࡜࡯࡞ࡱࠫ৬")+p9YD6iyZOzKubQgFMh3X)
	ZZ1G8ui05FrMvbkC = OTRKI6LbrQnZEm(u"ࠧ࠳࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥࡩࡡ࡯࡞ࠪࡸࠥ࡬ࡩ࡯ࡦࠣࠦࡆࡸࡩࡢ࡮ࠥࠤ࡫ࡵ࡮ࡵࠢࡷ࡬ࡪࡴࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤࡸࡱࡩ࡯ࠢࡤࡲࡩࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹ࠭৭")
	p9YD6iyZOzKubQgFMh3X = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨ࠴࠱ࠤࠥࠦลัษ่๊ࠣࠦสอัࠣห้ิืࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢไๆ๊ࠦศห฼ํ๎ึࠦวๅฮ็ำࠥัๅࠡไ่ࠤอะฺ๋ำࠣห้ิืࠡษ็ุ้ะฮะ็ࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠨ৮")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ৯"),ZZ1G8ui05FrMvbkC+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡠࡳࡢ࡮ࠨৰ")+p9YD6iyZOzKubQgFMh3X)
	ZZ1G8ui05FrMvbkC = pTwKPmzMSZhil5d2RWonre(u"ࠫ࠸࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢࡧࡳࡳࡢࠧࡵࠢ࡫ࡥࡻ࡫ࠠࡂࡴࡤࡦ࡮ࡩࠠࡌࡧࡼࡦࡴࡧࡲࡥࠢࡷ࡬ࡪࡴࠠࡨࡱࠣࡸࡴࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡸࡥࡨ࡫ࡲࡲࡦࡲࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠩৱ")
	p9YD6iyZOzKubQgFMh3X = mmKqLr9RX0ACN384JMcsFHzd(u"ࠬ࠹࠮ࠡࠢࠣษีอࠠๅ็ࠣ๎่์ࠠๅัํ็๊่ࠥฮห้ࠣๆอส๋ฯࠣ฽ึฮ๊สࠢไหีํศࠡว็ํࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣฯฺ๊๋ࠦำࠣษ฾ีวะษอࠤฬ๊ๅ็ูๅอࠥอไอ฼ิหๆ๐ษࠨ৲")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬ৳"),ZZ1G8ui05FrMvbkC+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧ࡝ࡰ࡟ࡲࠬ৴")+p9YD6iyZOzKubQgFMh3X)
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ৵"),QigevCplXxbPI1H,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"ࠩࡉࡳࡳࡺࠠࡴࡧࡷࡸ࡮ࡴࡧࡴࠩ৶"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡈࡴࠦࡹࡰࡷࠣࡻࡦࡴࡴࠡࡶࡲࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡰࡲࡻࠥࡅࠧ৷")+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡡࡴ࡜࡯ࠩ৸")+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬํไࠡฬิ๎ิࠦวๅา๊หอࠦลๅ๋่ࠣํำษࠡว฼ำฬีวห๋ࠢหัํษࠡๅ๋ำ๏ࠦรๅฤ้รࠬ৹"))
	if nndcv6tehuoKPpI==tg9l25NH6WTacVSifLyAmY(u"࠴ఄ"): lUaW7Box2uy1SNg93YGZ()
	return
def mP7G0io9dJDZSCbLhcutME6BWKqs4V():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ৺"),OOhnpQ8XvCVclGqdu(u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭৻"))
	return
def ve3MUgW8LJYKkjhb():
	nDRKguWex0iVN8 = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨৼ")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,vZL6j4tSClIGxzNE5DX(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ৽"),nDRKguWex0iVN8)
	return
def XVpjAUls0KR5D3hOqrnBkWYvS():
	nDRKguWex0iVN8 = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪห้ื่ศสฺࠤฬ๊ศุ์ษอ๊ࠥวࠡ฻็ห็ฯࠠๅ้สࠤออไษำ้ห๊า้ࠠ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊าࠧ৾")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ৿"),nDRKguWex0iVN8)
	return
def DIE2YAwz0cBKdte6xS():
	nDRKguWex0iVN8 = TCF8wLyDvgumfiXPSKRh(u"ࠬํ๊ࠡีํีๆืวหࠢ็หࠥ๐ำหูํ฽ࠥอไษำ้ห๊าࠠศีอาิอๅ่ษࠣฬุฮศࠡๅ๋๊์อࠠๆฯ่๎ฮࠦๅ็ࠢส่๊฻ฯาࠢฦ์ࠥฮอศฮฬࠤส๊้ࠡษืฮึอใࠡำึ้๏ࠦร้ࠢฯำ๏ีษࠡล๋ࠤ้อ๋ࠠ฻ิๅ์อࠠศๆหี๋อๅอࠩ਀")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਁ"),Xr2aHOK0huQ5DTS(u"ࠧิ์ิๅึอสࠡีํสฮࠦร้่ࠢะ์๎ไสࠩਂ"),nDRKguWex0iVN8)
	return
def Pmqy34MVnCkZoQHIzYupW():
	nDRKguWex0iVN8 = JJu4MPClbTFpUwHiN(u"ࠨษ็ื๏ืแาษอࠤฬู๊ศ็ฬࠤ์๐ࠠิ์ิๅึอสࠡะสีั๐ษ๊ࠡ฽๎ึࠦสศส฼อ๊ࠥไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ฬๆ์฼ࠤฬ๊ๅ้ษๅ฽ࠥะำหะา้์อ้ࠠ฻สำฮࠦสไ๊้ࠤ๊าว็์ฬࠤํ๋ิศๅ็๋ฬࠦใฬ์ิอ๊ࠥว็ࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋้สࠤส๋วࠡสฺ๎หฯࠠฤ๊้๊ࠣ์ฺ่หࠣวํࠦๅฮา๋ๅฮࠦร้ࠢไ๎์อࠠๆึๆ่ฮࠦอใ๊ๅࠤฬ๊ๅๅๅํอࡡࡴ࡜࡯࡞ࡱหู้๊าใิหฯࠦวๅะสูฮࠦ็๋ࠢึ๎ึ็ัศฬࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไุ๋๋้ࠢะฮะ็ฬࠤๆ๐ࠠๆ๊สๆ฾ࠦโๅ์็อࠥาฯศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅะใ๋฽ฮࠦวๅลฯีࠥษ่ࠡ์่่่ํวࠡษ็้ํู่ࠡษ็วฺ๊๊๊ࠡ็๋ีอࠠโ้ํࠤั๐ฯส้ࠢือ๐ว๊ࠡึี๏฿ษุ๊่ࠡฬ้ไ่ษࠣๆ้๐ไสࠢฯำฬ࠭ਃ")
	XRZyfuiD8nLlKYPJ(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡦࡩࡳࡺࡥࡳࠩ਄"),XWbHfI9B8swrOL(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ਅ"),nDRKguWex0iVN8,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧਆ"))
	return
def o4VN0Kr8ix7ctYSukG3eATEdJj():
	ZZ1G8ui05FrMvbkC = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦวๅัๅอࠥอไฺษ็๎ฮ࠭ਇ")
	p9YD6iyZOzKubQgFMh3X = bDt7Ya1VEio3(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠฤๆࠣࡱ࠸ࡻ࠸ࠨਈ")
	uCyjMoXJUOq6eVP = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡษ็ฮา๋๊ๅ๋ࠢห้ีว้่็์ิࠦࡤࡰࡹࡱࡰࡴࡧࡤࠨਉ")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫਊ"),ZZ1G8ui05FrMvbkC,p9YD6iyZOzKubQgFMh3X,uCyjMoXJUOq6eVP)
	return
def SGDXI38kxfjzqJQwu15FcHhv():
	p9YD6iyZOzKubQgFMh3X = g4UCaNkHvLwGhjmW(u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪ਋")
	p9YD6iyZOzKubQgFMh3X += Fg72JX6T5DkPy(u"ࠪࡠࡳࡢ࡮ࠨ਌") + Xr2aHOK0huQ5DTS(u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪ਍") + str(xfdjCmFwb0k8JAVegiL/OOhnpQ8XvCVclGqdu(u"࠺࠵అ")/OOhnpQ8XvCVclGqdu(u"࠺࠵అ")/TCF8wLyDvgumfiXPSKRh(u"࠷࠺ఆ")/TCF8wLyDvgumfiXPSKRh(u"࠹࠰ఇ")) + Fg72JX6T5DkPy(u"ࠬࠦิ่ำࠪ਎")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv + VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬਏ") + str(hWYVzubgexwTPIfq/JJu4MPClbTFpUwHiN(u"࠶࠱ఈ")/JJu4MPClbTFpUwHiN(u"࠶࠱ఈ")/fk8jc5uDLX16qrih3ZaPxsvO(u"࠳࠶ఉ")) + JJu4MPClbTFpUwHiN(u"ࠧࠡ์๋้ࠬਐ")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv + vZL6j4tSClIGxzNE5DX(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬ਑") + str(g6gNzml5rOsa8bBETxPCpnVj/Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠸࠳ఊ")/Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠸࠳ఊ")/v54ZuLY6dQ(u"࠵࠸ఋ")) + DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࠣ๎ํ๋ࠧ਒")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv + VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬਓ") + str(pETKl7xuH1f5yjdFAb6C8JzOLV/tg9l25NH6WTacVSifLyAmY(u"࠺࠵ఌ")/tg9l25NH6WTacVSifLyAmY(u"࠺࠵ఌ")) + tg9l25NH6WTacVSifLyAmY(u"ูࠫࠥวฺหࠪਔ")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv + VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩਕ") + str(vjPhaUE819opVQg7uRk4wG6cYBOTd/mmKqLr9RX0ACN384JMcsFHzd(u"࠻࠶఍")/mmKqLr9RX0ACN384JMcsFHzd(u"࠻࠶఍")) + pTwKPmzMSZhil5d2RWonre(u"࠭ࠠิษ฼อࠬਖ")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv + FF70emVxhWOngCty(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨਗ") + str(vMlT137PE8q4wiKpWIojraR29B/DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠼࠰ఎ")) + svULcgJ7jm(u"ࠨࠢาๆ๏่ษࠨਘ")
	p9YD6iyZOzKubQgFMh3X += aSBkt4OU8JpWTEzVIHjAiv + NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫਙ") + str(oL2eIiFEJnd7vxc) + g4UCaNkHvLwGhjmW(u"ࠪࠤิ่๊ใหࠪਚ")
	p9YD6iyZOzKubQgFMh3X += g4UCaNkHvLwGhjmW(u"ࠫࡡࡴ࡜࡯ࠩਛ") + O4ylJvVNwLztdiHqBWDU(u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩਜ") + str(pETKl7xuH1f5yjdFAb6C8JzOLV/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")) + OTRKI6LbrQnZEm(u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧਝ") + str(g6gNzml5rOsa8bBETxPCpnVj/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")/K7bLVaiRkx0lgU5SQM(u"࠳࠶ఐ")) + TCF8wLyDvgumfiXPSKRh(u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭ਞ") + str(vjPhaUE819opVQg7uRk4wG6cYBOTd/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")) + JJu4MPClbTFpUwHiN(u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬਟ") + str(vMlT137PE8q4wiKpWIojraR29B/vZL6j4tSClIGxzNE5DX(u"࠶࠱ఏ")) + Xr2aHOK0huQ5DTS(u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫਠ") + str(oL2eIiFEJnd7vxc) + OTRKI6LbrQnZEm(u"ࠪࠤิ่๊ใหࠪਡ")
	XRZyfuiD8nLlKYPJ(JJu4MPClbTFpUwHiN(u"ࠫࡷ࡯ࡧࡩࡶࠪਢ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪਣ"),p9YD6iyZOzKubQgFMh3X,bDt7Ya1VEio3(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩਤ"))
	return
def soEVUdbYQIgF():
	nDRKguWex0iVN8 = mmKqLr9RX0ACN384JMcsFHzd(u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪਥ")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,y5yX4jh6kUEgWZQIc(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫਦ"),nDRKguWex0iVN8)
	return
def DFq74bhyMgm():
	nDRKguWex0iVN8 = y5yX4jh6kUEgWZQIc(u"ࠩศิฬ่ࠦศฮ๊ฮ่ࠦๅีๅ็อࠥ็๊ࠡษ็ุอ้ษ๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠฤ๊ࠣห๋้ࠠหฺ้ࠤศ์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠไษ้ࠤๆ๐็ࠡ็ื็้ฯࠠๆฦๅฮ์่ࠦห็ࠣั้ํวࠡ࠰࠱࠲ࠥ็ลั่ࠣะึฮࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮ่่ࠣ๐๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษู็ฬࠥอไึใะอࠥอไึฯํัฮ่ࠦหะี๎๋ํวࠡสา่ฬࠦๅ็ࠢสฺ่็อสࠢส่็ี๊ๆหࠪਧ")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ਨ"),nDRKguWex0iVN8)
	return
def WJXeodp7w3lha1AO():
	nDRKguWex0iVN8 = s0vAWcLSXEToH9Mik134q(u"ࠫฬฺ๊าุ้๋ࠣࠦิ่ษาอࠥอไหึไ๎ึࠦ็ู้้ࠢฬ์ࠠึฯฬࠤํูั๋หࠣหู้๋ๅ๊่หฯࠦวๅ็อฬฬีไสࠢห๎๋ࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊๎โฺࠢสฺ่๊แา๋๋ࠢีอࠠศๆู้ฬ์ࠠ฻์ิࠤ๊฽ไ้สࠣ์้อࠠฮษฯอ๊ࠥ็ࠡ฻้ำࠥอไศฬุห้ࠦว้ࠢส่ึฮืࠡ็฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋๋ฬะࠠศๆุ่ๆืษࠨ਩")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨਪ"),nDRKguWex0iVN8)
	return
def b0Sxth8EdUzaZ():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,OOhnpQ8XvCVclGqdu(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਫ"),svULcgJ7jm(u"ࠧๅๅํࠤ๏฿ๅๅ๊ࠢิฬࠦวๅ่๋฽๋ࠥๆࠡษ็ๅ๏ี๊้้สฮࠥࡢ࡮ࠡ์ฯฬࠥะแฺ์็ࠤส฼วโหࠣหุ๋็ศࠢ࡟ࡲࠥ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬਬ"))
	UU8FkvnySO(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨਭ"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	return
def DH5BlEGcRMZgyUVWxw8nCjPNb():
	nDRKguWex0iVN8  = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"่ࠩศำืวࠡไส้ฯࠦศฺุุࠣึ้วหࠢส่ส์สา่อࠤฬ๊ฯ้ๆํࠤอ๎ึฺࠢ฼หห่ࠠืัࠣห้ฮัศ็ฯࠤ๊ัไࠡๅ๋ำ๏ࠦไหี่ัࠥ็โุࠢ็ฬ฾฼ࠠๆีอาิ๋๊ࠡษ็้ฯ฻แฮࠢหห้ีฮ้ๆ่๊ࠣ๎วใ฻ࠣห้็๊ะ์๋ࠫਮ")
	nDRKguWex0iVN8 += tg9l25NH6WTacVSifLyAmY(u"ࠪࠤํ์ส๋ฮฬࠤ้ํะศࠢส่฾อฦใࠢไห๋ํࠠหไิ๎ออࠠอ็ํ฽๋ࠥำหะา้๏ࠦศา่ส้ัࠦใ้ัํࠤ้อ๋ࠠีอ฻๏฿่็ࠢส่ิิ่ๅࠢ็ะ๊๐ูࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢะฮ๎ࠦๅฺࠢสืฯิฯศ็ࠪਯ")
	nDRKguWex0iVN8 += aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิัࠨਰ")+jhAlCQ47ZgG+aSBkt4OU8JpWTEzVIHjAiv
	nDRKguWex0iVN8 += WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡢ࡮ๅษ้ࠤ์ึวࠡๆ้ࠤ๏ำไࠡษ็ู้้ไส๋ࠢษ๋๋วࠡใๅ฻ู๊ࠥใ๊่ࠤอหีๅษะࠤอ฿ึࠡษ็้ํอโฺ๋ࠢษ฾อโส่ࠢ์ฬู่ࠡษัี๎ࠦใศ่อࠤฯ฿ๅๅࠢึหอ่วࠡสา์๋ࠦๅีษๆ่ࠬ਱")
	XRZyfuiD8nLlKYPJ(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡲࡪࡩ࡫ࡸࠬਲ"),Xr2aHOK0huQ5DTS(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਲ਼"),nDRKguWex0iVN8,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ਴"))
	nDRKguWex0iVN8 = K7bLVaiRkx0lgU5SQM(u"ࠩส่๊๎วใ฻ࠣห้ะ๊ࠡฬฦฯึะࠠษษ็฽ฬฬโࠡ฻้ำࠥฮูืࠢส่๋อำ้ࠡํ࠾ࠬਵ")
	nDRKguWex0iVN8 += aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+Xr2aHOK0huQ5DTS(u"ࠪࡥࡰࡵࡡ࡮ࠢࠣࡩ࡬ࡿࡢࡦࡵࡷࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠢࠣࡱࡴࡼࡩࡻ࡮ࡤࡲࡩࠦࠠࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭ࠦࠠࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩਸ਼")+jhAlCQ47ZgG
	nDRKguWex0iVN8 += v54ZuLY6dQ(u"ࠫࡡࡴ࡜࡯ࠩ਷")+TCF8wLyDvgumfiXPSKRh(u"ࠬอไะ๊็ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ਸ")
	nDRKguWex0iVN8 += aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+mmKqLr9RX0ACN384JMcsFHzd(u"࠭ๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีวࠨਹ")+jhAlCQ47ZgG
	nDRKguWex0iVN8 += JJu4MPClbTFpUwHiN(u"ࠧ࡝ࡰ࡟ࡲࠬ਺")+pTwKPmzMSZhil5d2RWonre(u"ࠨษ็้อืๅอ๋ࠢะิࠦืา์ๅอ๊ࠥสอษ๋ึࠥอไฺษษๆࠥ๎ไไ่๊หࠥะอหษฯࠤัํฯࠡๅห๎ึ่ࠦศๆ่ฬึ๋ฬࠡ์฻๊ࠥอไๆึๆ่ฮࠦี฻์ิอࠥ๎ไศࠢอืฯำโࠡษ็ฮ฾ฮࠠโวำห๊ࠥฯ๋ๅู้้ࠣไสࠢหห้ีฮ้ๆ่ࠣอ฿ึࠡษ็้ํอโฺ๋ࠢว๏฼วࠡๆๆ๎ࠥ๐สืฯࠣัั๋ࠠศๆุ่่๊ษࠡࠩ਻")
	nDRKguWex0iVN8 += iVCLpNIM8BQs9PdSgKZvlFeo3a5+K7bLVaiRkx0lgU5SQM(u"ࠩสีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้ส਼ࠫ")+jhAlCQ47ZgG
	XRZyfuiD8nLlKYPJ(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡶ࡮࡭ࡨࡵࠩ਽"),O4ylJvVNwLztdiHqBWDU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧਾ"),nDRKguWex0iVN8,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨਿ"))
	return
def xxsNFRoajDTChAu0ln1():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭ੀ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡะา้ฬะ่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥฮวิฬัำฬ๋ࠠศๆไ๎ุฮ่ไࠢฦำ๋อ็࡝ࡰࠪੁ")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+TCF8wLyDvgumfiXPSKRh(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡨࡤࡧࡪࡨ࡯ࡰ࡭࠱ࡧࡴࡳ࠯ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࠪੂ")+jhAlCQ47ZgG+mpusoZBJ6V(u"ࠩ࡟ࡲࡡࡴร้ࠢหหึูวๅࠢส๎๊๐ไࠡษ็ํࠥษฯ็ษ๊ࠤࠥࡢ࡮ࠡࠩ੃")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+s0vAWcLSXEToH9Mik134q(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡆࡧ࡮ࡣ࡬ࡰ࠳ࡩ࡯࡮ࠩ੄")+jhAlCQ47ZgG)
	return
def CnbjTQAGWyHhKeSzcw6RvFo5kILs():
	SGDXI38kxfjzqJQwu15FcHhv()
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(K7bLVaiRkx0lgU5SQM(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ੅"),QigevCplXxbPI1H,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡษ็็ฬฺࠠภࠩ੆"),Xr2aHOK0huQ5DTS(u"࠭วๅๅสุࠥ๐ำา฻ࠣ฽๊๊ࠠศๆหี๋อๅอุ๋้ࠢำ็ࠡ์฼๎ิࠦำฮสࠣห้฻แฮษอࠤ๊์ࠠศๆศ๊ฯืๆหࠢ฼๊ิࠦวๅฯสะฮࠦลๅ์๊หࠥ๎วๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ๎วๅ็ึั๊ࠥวࠡ์ูีࠥ๎ๅๆๅ้ࠤ๏ำไࠡส฼ฺࠥอไๆึส็้࠭ੇ"))
	if nndcv6tehuoKPpI==OTRKI6LbrQnZEm(u"࠳఑"):
		oYAuTVpsaSfg(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦศศๆๆห๊๊ࠧੈ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨวำห้ࠥว็ฬࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣหาีࠠศๆ่์ฬู่ࠡใฯีอࠦวๅ็๋ๆ฾ࠦวๅฤ้ࠤ࠳࠴࠮๊ࠡฦิฬࠦวๅ็ื็้ฯࠠๆีอ้ึฯࠠโวำ๊ࠥอัิๆࠣห้๋ิไๆฬࠤส๊้ࠡษ็้อืๅอࠩ੉"))
	return nndcv6tehuoKPpI
def kkEM4GJSYRp(showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	if not showDialogs: showDialogs = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡊࡉ࡙࠭੊"),y5yX4jh6kUEgWZQIc(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮ࠩੋ"),QigevCplXxbPI1H,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧੌ"))
	if not JJrhP4C6osGDFEKVSRBvX.succeeded:
		RNXY7c1ho9wsEO3GxbLnqpDiAeM2yr = YoAMfqm37GyFxbuKTt6e8CESHrhB
		kZINFVLcUObK8Wsxohq0 = RU3DWNPsrdXFHT7jB0lmC()
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+K7bLVaiRkx0lgU5SQM(u"ࠬࠦࠠࠡࡊࡗࡘࡕ࡙ࠠࡇࡣ࡬ࡰࡪࡪࠠࠡࠢࡏࡥࡧ࡫࡬࠻࡝੍ࠪ")+kZINFVLcUObK8Wsxohq0+mpusoZBJ6V(u"࠭࡝ࠨ੎"))
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ੏"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨใะูࠥอไศฬุห้ࠦวๅ็ืๅึࠦ࠮࠯࠰ู้้ࠣไสࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡๆสࠤ๏฿ๅๅࠢ฼๊ิฺ้ࠠๆ์ࠤ่๎ฯ๋ࠢ࠱࠲࠳ฺ่่ࠦา็้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬ੐"))
	else:
		RNXY7c1ho9wsEO3GxbLnqpDiAeM2yr = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬੑ"),mpusoZBJ6V(u"ࠪะ๏ีࠠอัสࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แาࠫࠣ๎฾๋ไࠡ฻้ำ่่ࠦศๆหี๋อๅอࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧ੒"))
	if not RNXY7c1ho9wsEO3GxbLnqpDiAeM2yr and showDialogs: I4CXHzwQldLBUrsZtJAg()
	return RNXY7c1ho9wsEO3GxbLnqpDiAeM2yr
def I4CXHzwQldLBUrsZtJAg():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ੓"),JJu4MPClbTFpUwHiN(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫ੔"))
	OdeoGRrusmET()
	return
def U6KgbJ9ld3WHCYqFf4AV2Ikx(d8kolNVuLsPAjQZ9ROpUHBgix=QigevCplXxbPI1H):
	BzoGPDXaKYU6wk9S = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if OOhnpQ8XvCVclGqdu(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ੕") not in d8kolNVuLsPAjQZ9ROpUHBgix:
		BzoGPDXaKYU6wk9S = YoAMfqm37GyFxbuKTt6e8CESHrhB
		BBt5dqgsIEbFNDCioAl = L2Lu1MQVHhiTX0(O4ylJvVNwLztdiHqBWDU(u"ࠧࡤࡧࡱࡸࡪࡸࠧ੖"),TCF8wLyDvgumfiXPSKRh(u"ࠨะิ์ั࠭੗"),mpusoZBJ6V(u"ࠩศีุอไࠡ็ื็้ฯࠧ੘"),g4UCaNkHvLwGhjmW(u"ࠪษึูวๅࠢิืฬ๊ษࠨਖ਼"),pGncXOodjKhJzLSqVP1r(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧਗ਼"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬํไࠡฬิ๎ิࠦร็ࠢอีุ๊ࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡล้ࠤฯืำๅุ่่๊ࠢษࠡ็๋ะํีษࠡใํࠤฬ๊ศา่ส้ัࠦฟࠨਜ਼"))
		if BBt5dqgsIEbFNDCioAl in [-mmKqLr9RX0ACN384JMcsFHzd(u"࠴ఒ"),pGncXOodjKhJzLSqVP1r(u"࠴ఓ")]: return
		elif BBt5dqgsIEbFNDCioAl==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠶ఔ"):
			BzoGPDXaKYU6wk9S = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			d8kolNVuLsPAjQZ9ROpUHBgix = aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩੜ")
	if BzoGPDXaKYU6wk9S:
		if OTRKI6LbrQnZEm(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࡒࡐࡉࡥࠧ੝") not in d8kolNVuLsPAjQZ9ROpUHBgix:
			nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(svULcgJ7jm(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨਫ਼"),QigevCplXxbPI1H,QigevCplXxbPI1H,FF70emVxhWOngCty(u"ฺ๋ࠩ฾ࠦวๅ็ื็้ฯࠠโ์ࠣหู้ฬๅࠩ੟"),g4UCaNkHvLwGhjmW(u"ࠪๆอ๊ࠠฦำึห้ࠦวๅีฯ่ࠥ฿ไ๋ๅࠣว๋ࠦสไำิࠤࠥ์แิࠢส่ๆ฿ไࠡษ็ิ๏ࠦรฺูส็ࠥอไๆึๆ่ฮࠦ࠮ࠡๆๆ๎ࠥ๐สๆࠢอืั๐ไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤ࠳่ࠦษั๋๊ࠥํะศࠢส่ฯูฬ๋ๆࠣืํ็ࠠหำึ่๋ࠥไโࠢ็หࠥ็ววัฬࠤ๊์็ࠡๆศ๊์ࠦไศࠢํัฯ๎๊ࠡ฻็ํࠥอไๆึๆ่ฮࠦวๅฬํࠤฯื๊ะࠢส๊ฯࠦวๅวห่ฬเฺ่๊ࠠหࠥ࠴่ࠠๆࠣๆ๊ะࠠษฬๆีฬืࠠศๆุ่่๊ษࠡมࠪ੠"))
			if nndcv6tehuoKPpI!=DDHwpETQrAm0xMNXGfyhqsUi(u"࠷క"):
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,y5yX4jh6kUEgWZQIc(u"ࠫฯ๋ࠠฦๆ฽หฦࠦวๅวิืฬ๊ࠧ੡"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"๊ࠬไฤีไࠤอี่็ࠢอืั๐ไࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠโษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์ึฮ฼๐ูࠡ็฼ีๆฯࠠศๆุ่่๊ษ๊ࠡ็หࠥำไ่ษ่ࠣฬ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ੢"))
				return
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ੣"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไฦ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ੤"))
	search = XAfEvmh95VkgurjdiJ(header=DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࡨࠤࠥࠦวไฬหࠤึูวๅหࠪ੥"),source=PuT0IphGNsketAQ)
	if not search: return
	nDRKguWex0iVN8 = search
	if BzoGPDXaKYU6wk9S: type = pTwKPmzMSZhil5d2RWonre(u"ࠩࡓࡶࡴࡨ࡬ࡦ࡯ࠪ੦")
	else: type = OTRKI6LbrQnZEm(u"ࠪࡑࡪࡹࡳࡢࡩࡨࠫ੧")
	AMu7aiqvPT6WcLOXDSkhFzdN = PZMEo96N8F50USez4(type,nDRKguWex0iVN8,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡗࡖࡉࡗ࡙ࠧ੨"),d8kolNVuLsPAjQZ9ROpUHBgix)
	return
def Xlos2F9Vck6u():
	d8kolNVuLsPAjQZ9ROpUHBgix = g4UCaNkHvLwGhjmW(u"ࠬํะศࠢส่อืๆศ็ฯࠤ้อ๋๊ࠠฯำ๊ࠥ็ࠡลํࠤุ๐ัโำࠣ๎ุะึ๋ใࠣว๏ࠦๅฮฬ๋๎ฬะ࠮ࠡษ็ฬึ์วๆฮࠣ๎ุะฮะ็ࠣีํอศุ๋ࠢฮ฻๋๊็ࠢ็้าะ่๋ษอࠤ๊ืแ้฻ฬࠤ฾๊้ࠡีํีๆืวหࠢัหึา๊ส࠰ࠣห้ฮั็ษ่ะࠥเ๊า่ࠢืษ๎ไࠡ฻้ࠤศ๐ࠠๆฯอ์๏อสࠡฬ่ࠤฯำๅ๋ๆ๊หࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣ์๊๎วใ฻ࠣาฬืฬ๋ห๊ࠣࠦ๎วใ฻ࠣ฻ึ็ࠠฬษ็ฯࠧ࠴ࠠอ็ํ฽ࠥอไฤี่หฦ่ࠦศๆ่หึ้วห๋ࠢห้฻่า๋ࠢห้๋ๆี๊ิหฯࠦ็๋ࠢัหฺฯࠠษษุัฬฮ็ศ࠰ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์้ฮ์้ࠠฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠠࡅࡏࡆࡅࠥหะศࠢๆห๋ࠦไะ์ๆࠤู้่๊ࠢัหฺฯࠠษษ็ีํอศุ๋ࠢห้ะึศ็ํ๊ࠥอไฯษิะ๏ฯࠠโษ็ีัอมࠡษ็ฮํอีๅ่ࠢ฽ࠥหฯศำฬࠤ์ึ็ࠡษ็ื๏ืแาษอࠤํอไๆ๊สๆ฾ࠦวๅะสีั๐ษ࠯๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ้๋ࠡࠤอฮำศูฬࠤ๊ะีโฯ่๊ࠣ๎วใ฻ࠣห้๎๊ษࠩ੩")
	XRZyfuiD8nLlKYPJ(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡲࡪࡩ࡫ࡸࠬ੪"),TCF8wLyDvgumfiXPSKRh(u"ࠧฮไ๋ๆࠥอไุส฼ࠤํอไ็ึิࠤํ่ว็๊้ࠤฬ๊รๅใํอ๊ࠥไๆๆๆ๎ฮࠦวๅำๅ้๏ฯࠧ੫"),d8kolNVuLsPAjQZ9ROpUHBgix,Xr2aHOK0huQ5DTS(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ੬"))
	d8kolNVuLsPAjQZ9ROpUHBgix = bDt7Ya1VEio3(u"ࠩࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡࡦࡲࡩࡸࠦ࡮ࡰࡶࠣ࡬ࡴࡹࡴࠡࡣࡱࡽࠥࡩ࡯࡯ࡶࡨࡲࡹࠦ࡯࡯ࠢࡤࡲࡾࠦࡳࡦࡴࡹࡩࡷ࠴ࠠࡊࡶࠣࡳࡳࡲࡹࠡࡷࡶࡩࡸࠦ࡬ࡪࡰ࡮ࡷࠥࡺ࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡧࡴࡴࡴࡦࡰࡷࠤࡹ࡮ࡡࡵࠢࡺࡥࡸࠦࡵࡱ࡮ࡲࡥࡩ࡫ࡤࠡࡶࡲࠤࡵࡵࡰࡶ࡮ࡤࡶࠥࡵ࡮࡭࡫ࡱࡩࠥࡼࡩࡥࡧࡲࠤ࡭ࡵࡳࡵ࡫ࡱ࡫ࠥࡹࡩࡵࡧࡶ࠲ࠥࡇ࡬࡭ࠢࡷࡶࡦࡪࡥ࡮ࡣࡵ࡯ࡸ࠲ࠠࡷ࡫ࡧࡩࡴࡹࠬࠡࡶࡵࡥࡩ࡫ࠠ࡯ࡣࡰࡩࡸ࠲ࠠࡴࡧࡵࡺ࡮ࡩࡥࠡ࡯ࡤࡶࡰࡹࠬࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࡩࡩࠦࡷࡰࡴ࡮࠰ࠥࡲ࡯ࡨࡱࡶࠤࡷ࡫ࡦࡦࡴࡨࡲࡨ࡫ࡤࠡࡪࡨࡶࡪ࡯࡮ࠡࡤࡨࡰࡴࡴࡧࠡࡶࡲࠤࡹ࡮ࡥࡪࡴࠣࡶࡪࡹࡰࡦࡥࡷ࡭ࡻ࡫ࠠࡰࡹࡱࡩࡷࡹࠠ࠰ࠢࡦࡳࡲࡶࡡ࡯࡫ࡨࡷ࠳ࠦࡔࡩࡧࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡨ࡬ࡦࠢࡩࡳࡷࠦࡷࡩࡣࡷࠤࡴࡺࡨࡦࡴࠣࡴࡪࡵࡰ࡭ࡧࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦ࠳ࡳࡦࠣࡴࡦࡸࡴࡺࠢࡶ࡭ࡹ࡫ࡳ࠯࡚ࠢࡩࠥࡻࡲࡨࡧࠣࡥࡱࡲࠠࡤࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡳࡼࡴࡥࡳࡵ࠯ࠤࡹࡵࠠࡳࡧࡦࡳ࡬ࡴࡩࡻࡧࠣࡸ࡭ࡧࡴࠡࡶ࡫ࡩࠥࡲࡩ࡯࡭ࡶࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡪࠠࡸ࡫ࡷ࡬࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡡࡳࡧࠣࡰࡴࡩࡡࡵࡧࡧࠤࡸࡵ࡭ࡦࡹ࡫ࡩࡷ࡫ࠠࡦ࡮ࡶࡩࠥࡵ࡮ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡲࡶࠥࡼࡩࡥࡧࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡡࡳࡧࠣࡪࡷࡵ࡭ࠡࡱࡷ࡬ࡪࡸࠠࡷࡣࡵ࡭ࡴࡻࡳࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡋࡩࠤࡾࡵࡵࠡࡪࡤࡺࡪࠦࡡ࡯ࡻࠣࡰࡪ࡭ࡡ࡭ࠢ࡬ࡷࡸࡻࡥࡴࠢࡳࡰࡪࡧࡳࡦࠢࡦࡳࡳࡺࡡࡤࡶࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡ࡯ࡨࡨ࡮ࡧࠠࡧ࡫࡯ࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡩࡱࡶࡸࡪࡸࡳ࠯ࠢࡗ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡸ࡯࡭ࡱ࡮ࡼࠤࡦࠦࡷࡦࡤࠣࡦࡷࡵࡷࡴࡧࡵ࠲ࠬ੭")
	XRZyfuiD8nLlKYPJ(O4ylJvVNwLztdiHqBWDU(u"ࠪࡰࡪ࡬ࡴࠨ੮"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡉ࡯ࡧࡪࡶࡤࡰࠥࡓࡩ࡭࡮ࡨࡲࡳ࡯ࡵ࡮ࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥࡇࡣࡵࠢࠫࡈࡒࡉࡁࠪࠩ੯"),d8kolNVuLsPAjQZ9ROpUHBgix,K7bLVaiRkx0lgU5SQM(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨੰ"))
	return
def LRdWIoO17BQ4iUHKruCFghsTc2yM(GTZC7rKJtPlueQ):
	RnGKqWfH2YOp0zDaA = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(g4UCaNkHvLwGhjmW(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩੱ")+GTZC7rKJtPlueQ+XWbHfI9B8swrOL(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡧࡶࡣࡱࡲࡰࡪࡧ࡮ࡧࡣ࡯ࡷࡪࢃࡽࠨੲ"))
	aeRHmPISMkDNA2vd7F6gzpB9C = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if aeRHmPISMkDNA2vd7F6gzpB9C:
		B3TKLo71hAGRqYgV0.sleep(mpusoZBJ6V(u"࠱ఖ"))
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(TCF8wLyDvgumfiXPSKRh(u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬੳ"))
		B3TKLo71hAGRqYgV0.sleep(pGncXOodjKhJzLSqVP1r(u"࠲గ"))
	return
def kXhPH0nom9dJ():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬੴ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪห้ฮั็ษ่ะ๊ࠥวࠡ์ไัฺࠦิ่ษาอࠥอไหึไ๎ึูࠦ็ัࠣห้อสึษ็ࠤออไๆ๊สๆ฾ࠦวๅ็ืๅึฯ้ࠠๆ๊ิฬࠦแ๋ࠢะห้่ࠦอ๊าࠤูํวะหࠣ฾๏ืࠠึฯํัฮࠦร้่๊ࠢฯํ๊สࠢสฺ่๊วฮ์ฬࠤศ๎ࠠๆิํๅฮࠦแศ่๋ࠣีอࠠๅ่ࠣ๎ํ่แࠡษ็ีอ฽ࠠศๆุ่ๆื้ࠠๆ้ࠤ๏๎โโࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠨੵ"))
	WJXeodp7w3lha1AO()
	return
def OdeoGRrusmET():
	url = vZL6j4tSClIGxzNE5DX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡯ࡲࡳࡱࡵࡷ࠳ࡱ࡯ࡥ࡫࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫ࡳ࠰ࡹ࡬ࡲࡩࡵࡷࡴ࠱ࡺ࡭ࡳ࠼࠴࠰ࠩ੶")
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡍࡅࡕࠩ੷"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡋࡓ࡜ࡥࡌࡂࡖࡈࡗ࡙ࡥࡋࡐࡆࡌࡣ࡛ࡋࡒࡔࡋࡒࡒ࠲࠷ࡳࡵࠩ੸"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	DYj2QGaVU1J7iSvgsX4BF5OAwH6P = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠧࡵ࡫ࡷࡰࡪࡃࠢ࡬ࡱࡧ࡭࠲࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫ࠮࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠭࠲࠭੹"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	DYj2QGaVU1J7iSvgsX4BF5OAwH6P = DYj2QGaVU1J7iSvgsX4BF5OAwH6P[h17Zb2ld4yLBrCP5tiw].split(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨ࠯ࠪ੺"))[h17Zb2ld4yLBrCP5tiw]
	xYQeAjkSBdacuylw9b6DGs = str(aybmzWnDkuEcT3jpJClB2)
	S0ZwbUTgNQzXtM7OEJR1hDC8n2F = mpusoZBJ6V(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊รฯ์ิࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫ੻")+r9rhtA5Tek8sIoLfqwF7JcEV+DYj2QGaVU1J7iSvgsX4BF5OAwH6P+jhAlCQ47ZgG
	S0ZwbUTgNQzXtM7OEJR1hDC8n2F += mpusoZBJ6V(u"ࠪࡠࡳࡢ࡮ࠨ੼")+tOrSvd8QKNB(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่๊ࠢ์ࠥࡀࠠࠡࠢࠪ੽")+r9rhtA5Tek8sIoLfqwF7JcEV+xYQeAjkSBdacuylw9b6DGs+jhAlCQ47ZgG
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ੾"),S0ZwbUTgNQzXtM7OEJR1hDC8n2F)
	return
def keqY7H5SjhxNcUDsFi3v0umPz():
	ZZ1G8ui05FrMvbkC,p9YD6iyZOzKubQgFMh3X,uCyjMoXJUOq6eVP,S0ZwbUTgNQzXtM7OEJR1hDC8n2F,RNLbgZKzhOTQ6j9uiGJtIV,P4THjSkemIcdpNDEF,OWELRD5N6p7xy3 = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	A1AqSc2LNwW0ETgyaRl9,RCVgeK0nyPJ4zGhXsqx8IAoQbTfYl,KCOYw2ySQRZ51ofVHjAcndLN,pp8aKmlVhktf9u = {vZL6j4tSClIGxzNE5DX(u"࠭ࡡࠨ੿"):K7bLVaiRkx0lgU5SQM(u"ࠧࡢࠩ઀")},{},[],{}
	url = OQv0iWIw5bFRATU2mxJjZK[vZL6j4tSClIGxzNE5DX(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨઁ")][nfC2im3NzUQk]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vMlT137PE8q4wiKpWIojraR29B,g4UCaNkHvLwGhjmW(u"ࠩࡓࡓࡘ࡚ࠧં"),url,A1AqSc2LNwW0ETgyaRl9,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨઃ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(tOrSvd8QKNB(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡘࡺࡡࡵࡧࡶࠫ઄"),TCF8wLyDvgumfiXPSKRh(u"࡛ࠬࡓࡂࠩઅ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(vZL6j4tSClIGxzNE5DX(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡋࡪࡰࡪࡨࡴࡳࠧઆ"),OOhnpQ8XvCVclGqdu(u"ࠧࡖࡍࠪઇ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(tOrSvd8QKNB(u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡃࡵࡥࡧࠦࡅ࡮࡫ࡵࡥࡹ࡫ࡳࠨઈ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡘࡅࡊ࠭ઉ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡗࡦࡻࡤࡪࠢࡄࡶࡦࡨࡩࡢࠩઊ"),tg9l25NH6WTacVSifLyAmY(u"ࠫࡐ࡙ࡁࠨઋ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(Fg72JX6T5DkPy(u"ࠬࡔ࡯ࡳࡶ࡫ࠤࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧઌ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡎ࠯ࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫઍ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡘࡧࡶࡸࡪࡸ࡮ࠡࡕࡤ࡬ࡦࡸࡡࠨ઎"),svULcgJ7jm(u"ࠨ࡙࠱ࡗࡦ࡮ࡡࡳࡣࠪએ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(mpusoZBJ6V(u"ࠩࡢࡣࡤ࠭ઐ"),eZXCHufT9YW4bRErSBOLmI)
	try: W65odYrPasZJiymxX1 = CH86N7xw4cyPt3TlIBJF(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡰ࡮ࡹࡴࠨઑ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	except:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ઒"),svULcgJ7jm(u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬઓ"))
		return
	kiNKYuz2AVLC3c,EwFPiShkXZul7YWNa1xsVjUmvo,No5Rwu09pUIsP6cijYa1GADOM = W65odYrPasZJiymxX1
	pp8aKmlVhktf9u = {}
	EorKpyBax7N9gAkQYMlw = [mpusoZBJ6V(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡉࡅࠩઔ"),bDt7Ya1VEio3(u"ࠧࡄࡃࡓࡘࡈࡎࡁࡕࡑࡎࡉࡓ࠭ક")]
	SLKbl2TOMCk86o0h7dIyDgZz14 = [XWbHfI9B8swrOL(u"ࠨࡃࡏࡐࠬખ"),pGncXOodjKhJzLSqVP1r(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩગ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫઘ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨઙ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡘࡅࡑࡑࡖࠫચ")]+EorKpyBax7N9gAkQYMlw+CCT0MdYxkDalqAE+BBCVh2mFqLjNZ5p6tfA1JPeS
	for c1Ifu0OGV2kyRwLPWlsho8Ct6nz,wTZMWnVrpmvXu4U9KjxGAeCbE3,CvmKFzk0nyguB9ZsJPdqrW2RI536Nt in EwFPiShkXZul7YWNa1xsVjUmvo:
		CvmKFzk0nyguB9ZsJPdqrW2RI536Nt = arFSQucmG9HxDody67JCI8pBMk4L(CvmKFzk0nyguB9ZsJPdqrW2RI536Nt)
		CvmKFzk0nyguB9ZsJPdqrW2RI536Nt = CvmKFzk0nyguB9ZsJPdqrW2RI536Nt.strip(hT7zFDpEyUqf8sXuN).strip(Xr2aHOK0huQ5DTS(u"࠭ࠠ࠯ࠩછ"))
		S0ZwbUTgNQzXtM7OEJR1hDC8n2F += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+c1Ifu0OGV2kyRwLPWlsho8Ct6nz+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧ࠻ࠢࠪજ")+jhAlCQ47ZgG+CvmKFzk0nyguB9ZsJPdqrW2RI536Nt+aSBkt4OU8JpWTEzVIHjAiv
		if wTZMWnVrpmvXu4U9KjxGAeCbE3.isdigit():
			pp8aKmlVhktf9u[c1Ifu0OGV2kyRwLPWlsho8Ct6nz] = int(wTZMWnVrpmvXu4U9KjxGAeCbE3)
			if int(wTZMWnVrpmvXu4U9KjxGAeCbE3)>DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠳࠳࠴ఘ"): wTZMWnVrpmvXu4U9KjxGAeCbE3 = FF70emVxhWOngCty(u"ࠨࡪ࡬࡫࡭ࡻࡳࡢࡩࡨࠫઝ")
			else: wTZMWnVrpmvXu4U9KjxGAeCbE3 = s0vAWcLSXEToH9Mik134q(u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫઞ")
		if c1Ifu0OGV2kyRwLPWlsho8Ct6nz not in SLKbl2TOMCk86o0h7dIyDgZz14:
			if   wTZMWnVrpmvXu4U9KjxGAeCbE3==s0vAWcLSXEToH9Mik134q(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭ટ"): ZZ1G8ui05FrMvbkC += eZXCHufT9YW4bRErSBOLmI+c1Ifu0OGV2kyRwLPWlsho8Ct6nz
			elif wTZMWnVrpmvXu4U9KjxGAeCbE3==DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭ઠ"): p9YD6iyZOzKubQgFMh3X += eZXCHufT9YW4bRErSBOLmI+c1Ifu0OGV2kyRwLPWlsho8Ct6nz
	POfmrSZIEvNF0KnuC,Od390b12QwPYvAjqLJxaSKXisc7V,KhqzRdwXIS7GZAnv9 = list(zip(*EwFPiShkXZul7YWNa1xsVjUmvo))
	for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in sorted(zfE9YjC6MTa8):
		if c1Ifu0OGV2kyRwLPWlsho8Ct6nz not in POfmrSZIEvNF0KnuC:
			S0ZwbUTgNQzXtM7OEJR1hDC8n2F += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+c1Ifu0OGV2kyRwLPWlsho8Ct6nz+tg9l25NH6WTacVSifLyAmY(u"ࠬࡀࠠࠨડ")+jhAlCQ47ZgG+OTRKI6LbrQnZEm(u"࠭ไศࠢํ์ัีࠧઢ")+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧ࡝ࡰ࡟ࡲࠬણ")
			if c1Ifu0OGV2kyRwLPWlsho8Ct6nz not in SLKbl2TOMCk86o0h7dIyDgZz14: uCyjMoXJUOq6eVP += eZXCHufT9YW4bRErSBOLmI+c1Ifu0OGV2kyRwLPWlsho8Ct6nz
	for CvmKFzk0nyguB9ZsJPdqrW2RI536Nt,d3nA2LsHai59 in kiNKYuz2AVLC3c:
		CvmKFzk0nyguB9ZsJPdqrW2RI536Nt = arFSQucmG9HxDody67JCI8pBMk4L(CvmKFzk0nyguB9ZsJPdqrW2RI536Nt)
		RNLbgZKzhOTQ6j9uiGJtIV += CvmKFzk0nyguB9ZsJPdqrW2RI536Nt+v54ZuLY6dQ(u"ࠨ࠼ࠣࠫત")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+str(d3nA2LsHai59)+jhAlCQ47ZgG+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࠣࠤࠥ࠭થ")
	ZZ1G8ui05FrMvbkC = ZZ1G8ui05FrMvbkC.strip(hT7zFDpEyUqf8sXuN)
	p9YD6iyZOzKubQgFMh3X = p9YD6iyZOzKubQgFMh3X.strip(hT7zFDpEyUqf8sXuN)
	uCyjMoXJUOq6eVP = uCyjMoXJUOq6eVP.strip(hT7zFDpEyUqf8sXuN)
	VT3DWmtrq1sgQRI = ZZ1G8ui05FrMvbkC+eZXCHufT9YW4bRErSBOLmI+p9YD6iyZOzKubQgFMh3X
	mmSXEfeMr8nG7s9j  = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"้ࠪํอโฺ้ࠢะาࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไࠡใํำ๏๎็ศฬࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠧદ")+aSBkt4OU8JpWTEzVIHjAiv+OOhnpQ8XvCVclGqdu(u"ࠫํํะศ่ࠢ฽๋อ็ࠡวำห๊ࠥฯ๋ๅู้้ࠣไสࠢไ๋๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠩધ")+aSBkt4OU8JpWTEzVIHjAiv
	mmSXEfeMr8nG7s9j += iVCLpNIM8BQs9PdSgKZvlFeo3a5+VT3DWmtrq1sgQRI+jhAlCQ47ZgG+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡢ࡮࡝ࡰࠪન")
	mmSXEfeMr8nG7s9j += pGncXOodjKhJzLSqVP1r(u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦแ๋ัํ์์อสࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠬ઩")+aSBkt4OU8JpWTEzVIHjAiv+tOrSvd8QKNB(u"้้ࠧำหู๋ࠥ็ษ๊ࠤฬำสๆษ็ࠤ่ฮ๊า๋ࠢะํีࠠๆึๆ่ฮࠦแ๋ࠢส่อืๆศ็ฯࠫપ")+aSBkt4OU8JpWTEzVIHjAiv
	mmSXEfeMr8nG7s9j += iVCLpNIM8BQs9PdSgKZvlFeo3a5+uCyjMoXJUOq6eVP+jhAlCQ47ZgG
	eRKAn8TcGQ2YXCm7sWtw,DaKlLWGZk5gI4tp0wsx9rMB2N1,hhYb2Onv0QGfIrW8tw,L8ek2zjqJIi9h7VcfgtD4RWuB = v54ZuLY6dQ(u"࠳ఙ"),v54ZuLY6dQ(u"࠳ఙ"),v54ZuLY6dQ(u"࠳ఙ"),v54ZuLY6dQ(u"࠳ఙ")
	all = pp8aKmlVhktf9u[K7bLVaiRkx0lgU5SQM(u"ࠨࡃࡏࡐࠬફ")]
	if TCF8wLyDvgumfiXPSKRh(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩબ") in list(pp8aKmlVhktf9u.keys()): eRKAn8TcGQ2YXCm7sWtw = pp8aKmlVhktf9u[tOrSvd8QKNB(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪભ")]
	if y5yX4jh6kUEgWZQIc(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬમ") in list(pp8aKmlVhktf9u.keys()): DaKlLWGZk5gI4tp0wsx9rMB2N1 = pp8aKmlVhktf9u[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡏࡎࡔࡖࡄࡐࡑ࠭ય")]
	if TCF8wLyDvgumfiXPSKRh(u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪર") in list(pp8aKmlVhktf9u.keys()): hhYb2Onv0QGfIrW8tw = pp8aKmlVhktf9u[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ઱")]
	if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡔࡈࡔࡔ࡙ࠧલ") in list(pp8aKmlVhktf9u.keys()): L8ek2zjqJIi9h7VcfgtD4RWuB = pp8aKmlVhktf9u[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡕࡉࡕࡕࡓࠨળ")]
	Y4Y8gLZXzAvGfKh5CQH = all-eRKAn8TcGQ2YXCm7sWtw-DaKlLWGZk5gI4tp0wsx9rMB2N1-hhYb2Onv0QGfIrW8tw-L8ek2zjqJIi9h7VcfgtD4RWuB
	tX1WYGPmux,TThOjrq2i3AYoxG6 = No5Rwu09pUIsP6cijYa1GADOM[h17Zb2ld4yLBrCP5tiw]
	tX1WYGPmux,Be6cvHdCSXunPxwI28kR0DtVK = No5Rwu09pUIsP6cijYa1GADOM[nfC2im3NzUQk]
	GGXv3MoDqctm9HANpiP5CgEFeV2r = TThOjrq2i3AYoxG6-Be6cvHdCSXunPxwI28kR0DtVK
	OWELRD5N6p7xy3 += r9rhtA5Tek8sIoLfqwF7JcEV+str(Be6cvHdCSXunPxwI28kR0DtVK)+jhAlCQ47ZgG+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪห้฿ฯะࠢส่า่๊ใ์่้ࠣษฬ่ิฬࠤ࠿ࠦࠧ઴")
	OWELRD5N6p7xy3 += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(GGXv3MoDqctm9HANpiP5CgEFeV2r)+jhAlCQ47ZgG+mpusoZBJ6V(u"ࠫออำหะาห๊ࠦࡰࡳࡱࡻࡽࠥษ่ࠡࡸࡳࡲࠥࡀࠠࠨવ")
	OWELRD5N6p7xy3 += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(TThOjrq2i3AYoxG6)+jhAlCQ47ZgG+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬอไฺัาࠤฬ๊ใๅ์่ࠣัฺ๋๊ࠢส่ศา็ำหࠣ࠾ࠥ࠭શ")
	OWELRD5N6p7xy3 += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(len(No5Rwu09pUIsP6cijYa1GADOM[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠶చ"):]))+jhAlCQ47ZgG+JJu4MPClbTFpUwHiN(u"ู࠭ะัࠣห้ี่ๅࠢส่ฯ๐ࠠโ์๊หࠥษฬ่ิฬࠤ࠿ࠦ࡜࡯࡞ࡱࠫષ")
	for cQW2wk0yK9LeChBnsoAOuVaF8,PXVdZQYTNslvg7wF0159Akr in No5Rwu09pUIsP6cijYa1GADOM[fk8jc5uDLX16qrih3ZaPxsvO(u"࠷ఛ"):]:
		cQW2wk0yK9LeChBnsoAOuVaF8 = arFSQucmG9HxDody67JCI8pBMk4L(cQW2wk0yK9LeChBnsoAOuVaF8)
		cQW2wk0yK9LeChBnsoAOuVaF8 = cQW2wk0yK9LeChBnsoAOuVaF8.strip(hT7zFDpEyUqf8sXuN).strip(FF70emVxhWOngCty(u"ࠧࠡ࠰ࠪસ"))
		OWELRD5N6p7xy3 += cQW2wk0yK9LeChBnsoAOuVaF8+OOhnpQ8XvCVclGqdu(u"ࠨ࠼ࠣࠫહ")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+str(PXVdZQYTNslvg7wF0159Akr)+jhAlCQ47ZgG+Xr2aHOK0huQ5DTS(u"ࠩࠣࠤࠥ࠭઺")
	P4THjSkemIcdpNDEF += r9rhtA5Tek8sIoLfqwF7JcEV+str(Y4Y8gLZXzAvGfKh5CQH)+jhAlCQ47ZgG+TCF8wLyDvgumfiXPSKRh(u"ࠪๅ๏ี๊้้สฮࠥอิห฼็ฮࠥࡀࠠࠨ઻")
	P4THjSkemIcdpNDEF += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(eRKAn8TcGQ2YXCm7sWtw)+jhAlCQ47ZgG+vZL6j4tSClIGxzNE5DX(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢหห๏ั่็ࠢ࠽ࠤ઼ࠬ")
	P4THjSkemIcdpNDEF += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(L8ek2zjqJIi9h7VcfgtD4RWuB)+jhAlCQ47ZgG+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬ฽ไษษอࠤุ๐ัโำࠣห้๋ำห๊า฽ࠥࡀࠠࠨઽ")
	P4THjSkemIcdpNDEF += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(DaKlLWGZk5gI4tp0wsx9rMB2N1)+jhAlCQ47ZgG+K7bLVaiRkx0lgU5SQM(u"࠭สฬสํฮࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬีࠠ࠻ࠢࠪા")
	P4THjSkemIcdpNDEF += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(hhYb2Onv0QGfIrW8tw)+jhAlCQ47ZgG+FF70emVxhWOngCty(u"ࠧหอห๎ฯࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠾ࠥ࠭િ")
	P4THjSkemIcdpNDEF += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+str(len(kiNKYuz2AVLC3c))+jhAlCQ47ZgG+XWbHfI9B8swrOL(u"ࠨัฺฺ๋่ࠥๅฬࠣๅ๏ี๊้้สฮࠥࡀࠠࠨી")
	P4THjSkemIcdpNDEF += mpusoZBJ6V(u"ࠩ࡟ࡲࡡࡴࠧુ")+RNLbgZKzhOTQ6j9uiGJtIV
	XRZyfuiD8nLlKYPJ(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡧࡪࡴࡴࡦࡴࠪૂ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠫ฾ีฯࠡษ็วัําสࠢส่ฯ๐ࠠศีอาิ๋ส้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫૃ"),OWELRD5N6p7xy3,Xr2aHOK0huQ5DTS(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨૄ"))
	XRZyfuiD8nLlKYPJ(vZL6j4tSClIGxzNE5DX(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ૅ"),K7bLVaiRkx0lgU5SQM(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨ૆"),P4THjSkemIcdpNDEF,vZL6j4tSClIGxzNE5DX(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫે"))
	XRZyfuiD8nLlKYPJ(FF70emVxhWOngCty(u"ࠩࡦࡩࡳࡺࡥࡳࠩૈ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"้ࠪํอโฺࠢสุฯเไหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ૉ"),mmSXEfeMr8nG7s9j,y5yX4jh6kUEgWZQIc(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ૊"))
	XRZyfuiD8nLlKYPJ(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡲࡥࡧࡶࠪો"),FF70emVxhWOngCty(u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥอำหะา้ฯࠦวๅสิ๊ฬ๋ฬࠨૌ"),S0ZwbUTgNQzXtM7OEJR1hDC8n2F,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ્"))
	return
def HyWibNrAfm24Y5XTLtjGBd():
	nDRKguWex0iVN8 = y5yX4jh6kUEgWZQIc(u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰࠪ૎")+r9rhtA5Tek8sIoLfqwF7JcEV+tg9l25NH6WTacVSifLyAmY(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ૏")+jhAlCQ47ZgG+mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲࠬૐ")+r9rhtA5Tek8sIoLfqwF7JcEV+Xr2aHOK0huQ5DTS(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࠬ૑")+jhAlCQ47ZgG+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤศา่ษหࠣห้ฮั็ษ่ะࠬ૒")
	XRZyfuiD8nLlKYPJ(bDt7Ya1VEio3(u"࠭ࡣࡦࡰࡷࡩࡷ࠭૓"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ૔"),nDRKguWex0iVN8,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ૕"))
	return
def ITJQ4ncG6jVXhgvyP29Y1():
	nDRKguWex0iVN8 = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ึฮํีูࠡ฻่หิ่ࠦโ์๊ࠤศ๐ึศࠢฯ้๏฿ࠠศ฻าหิะࠠไ๊า๎ࠥอไๆู็์อฯࠠๅ฻่่ࠥฮั็ษ่ะࠥ฿ๅศัࠣ์่๊็ศࠢอฮ๊ࠦว้ฬ๋้ฬะ๊ไ์สࠤํ๊วࠡฬะฮฬาࠠฤ์๊ࠣํ฿ࠠๆ่ࠣห้ิศาหࠣๅ๏ࠦใ้ัํࠤศ๎ࠠศๆัฬึฯࠠโ์ࠣฮะฮ๊หࠢฦฺฬ็วหࠢๆ์ิ๐ࠧ૖")+aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+OQv0iWIw5bFRATU2mxJjZK[svULcgJ7jm(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩ૗")][h17Zb2ld4yLBrCP5tiw]+jhAlCQ47ZgG+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࠥࠦࠠࠡࠢࠣวํࠦࠠࠡࠢࠣࠤࠬ૘")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+OQv0iWIw5bFRATU2mxJjZK[svULcgJ7jm(u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ૙")][nfC2im3NzUQk]+jhAlCQ47ZgG
	nDRKguWex0iVN8 += DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭࡜࡯࡞ࡱࡠࡳอไาษห฻ࠥษฯ็ษ๊ࠤ์๎ࠠศๆึ์ึูࠠศๆำ๎ࠥ๐อหษฯ๋๋ࠥฯ๋ำ้้ࠣ็วหࠢๆ์ิ๐ࠠๅฬฮฬ๏ะࠠษำ้ห๊าฺࠠ็สำࠥฮวๅูิ๎็ฯࠠศๆอๆ้๐ฯ๋หࠣห้่ฯ๋็ฬࡠࡳ࠭૚")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+OQv0iWIw5bFRATU2mxJjZK[Fg72JX6T5DkPy(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ૛")][nfC2im3NzUQk]+jhAlCQ47ZgG
	nDRKguWex0iVN8 += QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨ࡞ࡱࡠࡳࡢ࡮อ็ํ฽๋ࠥไโษอࠤ฾๋วะ่ࠢ์ั๎ฯสࠢไ๎ࠥอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠫ૜")+aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+OQv0iWIw5bFRATU2mxJjZK[tOrSvd8QKNB(u"ࠩࡖࡓ࡚ࡘࡃࡆࡕࠪ૝")][JxuTQLOD357o41evylqPmRdf]+jhAlCQ47ZgG
	XRZyfuiD8nLlKYPJ(FF70emVxhWOngCty(u"ࠪࡧࡪࡴࡴࡦࡴࠪ૞"),FF70emVxhWOngCty(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไาี่๎ฮࠦไษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠪ૟"),nDRKguWex0iVN8,tOrSvd8QKNB(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨૠ"))
	return
def Xzo4bEuYR3(C9eLiofbY5EgJdS230zcj1s):
	qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(tg9l25NH6WTacVSifLyAmY(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬࠬૡ")+C9eLiofbY5EgJdS230zcj1s+v54ZuLY6dQ(u"ࠧࠪࠩૢ"), XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	return
def lUaW7Box2uy1SNg93YGZ():
	SxKAmIcoHeQ1(pTwKPmzMSZhil5d2RWonre(u"ࠨࡵࡷࡳࡵ࠭ૣ"))
	qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(tOrSvd8QKNB(u"ࠤࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࡍࡳࡺࡥࡳࡨࡤࡧࡪ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠩࠣ૤"))
	return
def h6OITjR7CZGQcU4WHJ8De():
	qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(Xr2aHOK0huQ5DTS(u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠪࠩ૥"), XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	return
def o48zDxkduZq0QrSBF7923pGwTLcIJb(showDialogs):
	if not showDialogs: nndcv6tehuoKPpI = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	else: nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(O4ylJvVNwLztdiHqBWDU(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ૦"),QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ૧"),tg9l25NH6WTacVSifLyAmY(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦวๅฤ้ࠤฤ࠭૨"))
	if nndcv6tehuoKPpI==FF70emVxhWOngCty(u"࠷జ"):
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(OOhnpQ8XvCVclGqdu(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ૩"))
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ૪"),pTwKPmzMSZhil5d2RWonre(u"ࠩอ้ࠥหัิษ็ࠤ฼๊ศࠡว็ํࠥฮั็ษ่ะ้่ࠥะ์ࠣห้ึ๊ࠡใํࠤัํวำๅ่่ࠣ๐๋ࠠไ๋้ࠥฮสฮัํฯࠥาๅ๋฻ࠣษ฻อแศฬࠣ็ํี๊ࠡ࠰ࠣฬ๊อࠠโ์๊หࠥะอะ์ฮࠤ์ึวࠡษ็ฬึ์วๆฮࠣ์ฯำฯ๋อุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰ࠣ๎ึา้ࠡว฼฻ฬวࠠไ๊า๎ࠥ࠻ࠠะไสส็ࠦร้ࠢฦ็ะืࠠๅๅํࠤ๏์็๋ࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠩ૫"))
		#ksV5ngvbcaS8ByMLYxlfXh(mpusoZBJ6V(u"ࡈࡤࡰࡸ࡫భ"))
	return
def AAED4kxHIBjiaCcqWdSgYl():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭૬"),tOrSvd8QKNB(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫ૭"))
	return
def kJcN5W08MGpbgYmzHRxUDu7CTisXEv():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ૮"),pGncXOodjKhJzLSqVP1r(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ૯"))
	return
def bqQv1mSPE2w0poVrxIKigNeTkL(showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	w5uRq6BlApOF = [svULcgJ7jm(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡲࡸ࡭࡫ࡲࡴࠩ૰"),g4UCaNkHvLwGhjmW(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡥࡦࠩ૱"),K7bLVaiRkx0lgU5SQM(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩࠬ૲"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬ૳"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡧࡪࡶࡨࡥࠬ૴"),y5yX4jh6kUEgWZQIc(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡤࡱࡧࡩࡧ࡫ࡲࡨࠩ૵")]
	k74Zh6cGqy1bw0sDmKeIWi = w5uRq6BlApOF+[svULcgJ7jm(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ૶"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ૷"),FF70emVxhWOngCty(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ૸"),OOhnpQ8XvCVclGqdu(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨૹ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡷࡰ࡯࡮࠯ࡲ࡫ࡩࡳࡵ࡭ࡦࡰࡤࡰࡊࡓࡁࡅࠩૺ"),OTRKI6LbrQnZEm(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨૻ"),JJu4MPClbTFpUwHiN(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬૼ")]
	S5NRneCz4GQJoVWFxBM7c = ZMdfXcs4e1Y3qhuO7t6Fg0TwyaCpj([OTRKI6LbrQnZEm(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ૽")])
	cYPWQuFqrgm5DHCJNBKxOwpy0UzZ = []
	for GTZC7rKJtPlueQ in [WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩ૾")]:
		if GTZC7rKJtPlueQ not in list(S5NRneCz4GQJoVWFxBM7c.keys()): continue
		EkxQ20jJyPDcu8Bh5w176sX4C,peIwGURStOhP,ivqwpePJ647xGfkE9goQ2YlC8,Xf1kzciJ7lgA2,FZfkHLYg7OeEq,Pmdgn8FIZoxb1tcYO40MSXraK,zWpe3sDLXrJ = S5NRneCz4GQJoVWFxBM7c[GTZC7rKJtPlueQ]
		if not peIwGURStOhP or (peIwGURStOhP and EkxQ20jJyPDcu8Bh5w176sX4C): cYPWQuFqrgm5DHCJNBKxOwpy0UzZ.append(GTZC7rKJtPlueQ)
	fxc4oLZyYNVejvC1I8hGzBJt6wRO = len(cYPWQuFqrgm5DHCJNBKxOwpy0UzZ)>mmKqLr9RX0ACN384JMcsFHzd(u"࠰ఝ")
	R2wuKSVBTLW4sAOQNob18UEdGf0hv = DZLbiWNFXwpM26.connect(h8oaOyKE9vx0F7sQUkumSGYCD5VZ)
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.text_factory = str
	B6xRu5lFyJ = R2wuKSVBTLW4sAOQNob18UEdGf0hv.cursor()
	yIlCNx7iPJmbQ23OED8RFsg = []
	for GTZC7rKJtPlueQ in w5uRq6BlApOF:
		B6xRu5lFyJ.execute(O4ylJvVNwLztdiHqBWDU(u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦࠢ࠲ࠤࠣࡥࡳࡪࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ૿")+GTZC7rKJtPlueQ+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࠥࠤࡀ࠭଀"))
		evn4M7hX8L2QKZHNEamVz5kw = B6xRu5lFyJ.fetchall()
		if evn4M7hX8L2QKZHNEamVz5kw: yIlCNx7iPJmbQ23OED8RFsg.append(GTZC7rKJtPlueQ)
	L5MjF6duBxHP4zkp0fUQS3WXhrE = len(yIlCNx7iPJmbQ23OED8RFsg)>TCF8wLyDvgumfiXPSKRh(u"࠱ఞ")
	for GTZC7rKJtPlueQ in k74Zh6cGqy1bw0sDmKeIWi:
		B6xRu5lFyJ.execute(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨଁ")+GTZC7rKJtPlueQ+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࠧࠦ࠻ࠨଂ"))
		fXMuhnPolyUQi5taVcC36pk = B6xRu5lFyJ.fetchall()
		if fXMuhnPolyUQi5taVcC36pk and O4ylJvVNwLztdiHqBWDU(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧଃ") not in str(fXMuhnPolyUQi5taVcC36pk): cYPWQuFqrgm5DHCJNBKxOwpy0UzZ.append(GTZC7rKJtPlueQ)
	AcUIS7eZWh41HvwKlQgsk = len(cYPWQuFqrgm5DHCJNBKxOwpy0UzZ)>DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠲ట")
	cYPWQuFqrgm5DHCJNBKxOwpy0UzZ = list(set(cYPWQuFqrgm5DHCJNBKxOwpy0UzZ))
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	EkxQ20jJyPDcu8Bh5w176sX4C = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if L5MjF6duBxHP4zkp0fUQS3WXhrE or AcUIS7eZWh41HvwKlQgsk:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡣࡦࡰࡷࡩࡷ࠭଄"),QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪଅ"),O4ylJvVNwLztdiHqBWDU(u"ࠨษ็ฬึ์วๆฮࠣ์ัีࠠๆึๆ่ฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠฤู๊้้ࠣไสࠢไ๎ࠥอไหฯา๎ะࠦวๅฬ็ๆฬฬ๊ࠡๆศฺฬ็วหࠢหี๋อๅอࠢ฼้ฬีࠠ࡝ࡰ࡟ࡲࠥ࠭ଆ")+r9rhtA5Tek8sIoLfqwF7JcEV+tOrSvd8QKNB(u"๋้ࠩࠣࠦสา์าࠤส฻ไศฯ๋ࠣีํࠠศๆุ่่๊ษࠡษ็ฦ๋ࠦฟࠨଇ")+jhAlCQ47ZgG)
		if nndcv6tehuoKPpI==TCF8wLyDvgumfiXPSKRh(u"࠴ఠ"):
			og4hYxPw0tGLafE2OWQMU8vANHlFV6 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			if fxc4oLZyYNVejvC1I8hGzBJt6wRO:
				og4hYxPw0tGLafE2OWQMU8vANHlFV6 = RiTVrvtfgm9jOe81(s0vAWcLSXEToH9Mik134q(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬଈ"),YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
			gPLwKoAzmlCfFaTqBs9Rte0yrxWibN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			if L5MjF6duBxHP4zkp0fUQS3WXhrE:
				for GTZC7rKJtPlueQ in yIlCNx7iPJmbQ23OED8RFsg: LRdWIoO17BQ4iUHKruCFghsTc2yM(GTZC7rKJtPlueQ)
				gPLwKoAzmlCfFaTqBs9Rte0yrxWibN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			PouZXDpHWBhzAa9OETCij = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			if AcUIS7eZWh41HvwKlQgsk:
				R2wuKSVBTLW4sAOQNob18UEdGf0hv = DZLbiWNFXwpM26.connect(h8oaOyKE9vx0F7sQUkumSGYCD5VZ)
				R2wuKSVBTLW4sAOQNob18UEdGf0hv.text_factory = str
				B6xRu5lFyJ = R2wuKSVBTLW4sAOQNob18UEdGf0hv.cursor()
				for GTZC7rKJtPlueQ in cYPWQuFqrgm5DHCJNBKxOwpy0UzZ:
					if VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࠧଉ") in GTZC7rKJtPlueQ: fXMuhnPolyUQi5taVcC36pk = GTZC7rKJtPlueQ
					else: fXMuhnPolyUQi5taVcC36pk = pTwKPmzMSZhil5d2RWonre(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧଊ")
					try: B6xRu5lFyJ.execute(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡕࡑࡆࡄࡘࡊࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠢࡖࡉ࡙ࠦ࡯ࡳ࡫ࡪ࡭ࡳࠦ࠽ࠡࠤࠪଋ")+fXMuhnPolyUQi5taVcC36pk+XWbHfI9B8swrOL(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭ଌ")+GTZC7rKJtPlueQ+svULcgJ7jm(u"ࠨࠤࠣ࠿ࠬ଍"))
					except: PouZXDpHWBhzAa9OETCij = YoAMfqm37GyFxbuKTt6e8CESHrhB
				R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
				R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
			B3TKLo71hAGRqYgV0.sleep(JJu4MPClbTFpUwHiN(u"࠵డ"))
			qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(pGncXOodjKhJzLSqVP1r(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭଎"))
			B3TKLo71hAGRqYgV0.sleep(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶ఢ"))
			if og4hYxPw0tGLafE2OWQMU8vANHlFV6 or gPLwKoAzmlCfFaTqBs9Rte0yrxWibN or PouZXDpHWBhzAa9OETCij:
				EkxQ20jJyPDcu8Bh5w176sX4C = YoAMfqm37GyFxbuKTt6e8CESHrhB
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଏ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫั๐ฯࠡ࠰࠱ࠤฯ๋ࠠษ่ฯหาࠦสโ฻ํ่ࠥ๎ลึๆสัࠥอไๆีอ์ิ฿้ࠠษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้าๅ๋฻ࠣษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨଐ"))
			else:
				EkxQ20jJyPDcu8Bh5w176sX4C = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ଑"),Fg72JX6T5DkPy(u"࠭ไๅลึๅࠥ࠴࠮ࠡใื่ฯูࠦๆๆํอࠥหีๅษะࠤู๊ส้ั฼ࠤ฾๋วะ๋ࠢษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫ଒"))
	elif showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪଓ"),OOhnpQ8XvCVclGqdu(u"ࠨฮํำࠥาฯศࠢ࠱࠲ࠥอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠๆึๆ่ฮࠦแ๋่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠฤ๊ࠣๅ๏ࠦวๅฬะำ๏ัࠠศๆอ่็อฦ๋ࠢ็ษ฻อแศฬࠣฬึ์วๆฮࠣ฽๊อฯࠨଔ"))
	return EkxQ20jJyPDcu8Bh5w176sX4C
def EESB6QGVhWwL7KmoONFs5():
	V4zp7XDeGY,EZj98mpPMShOnl5vFAw,mxu0cj3lVMYknPyG8QWAqLUTvoN = YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,QigevCplXxbPI1H
	VUv43FRjiybnhW0Iq,aUWZ6F5i2Hh3wSx7yNT,ASo3rVMnT6O5Ws = YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,QigevCplXxbPI1H
	xxRFbaG53ph8Kd1lv = [OTRKI6LbrQnZEm(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧକ"),pTwKPmzMSZhil5d2RWonre(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩଖ"),mpusoZBJ6V(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ଗ"),mpusoZBJ6V(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫଘ")]
	S5NRneCz4GQJoVWFxBM7c = ZMdfXcs4e1Y3qhuO7t6Fg0TwyaCpj(xxRFbaG53ph8Kd1lv)
	for GTZC7rKJtPlueQ in xxRFbaG53ph8Kd1lv:
		if GTZC7rKJtPlueQ not in list(S5NRneCz4GQJoVWFxBM7c.keys()): continue
		EkxQ20jJyPDcu8Bh5w176sX4C,peIwGURStOhP,pMaVt5K0bOGFe2W,Ed0XW2sFHvea,ukqJwnOvXg,MMsvzfBQCL18ecy2W,Vfpave4EDnHi50WwsLXC2B = S5NRneCz4GQJoVWFxBM7c[GTZC7rKJtPlueQ]
		if GTZC7rKJtPlueQ==v54ZuLY6dQ(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫଙ"):
			VUv43FRjiybnhW0Iq = EkxQ20jJyPDcu8Bh5w176sX4C
			aUWZ6F5i2Hh3wSx7yNT = mpusoZBJ6V(u"ࠧࠩࠩଚ")+peIwGURStOhP+hT7zFDpEyUqf8sXuN+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(MMsvzfBQCL18ecy2W)+v54ZuLY6dQ(u"ࠨࠫࠪଛ")
			ASo3rVMnT6O5Ws = Ed0XW2sFHvea
		elif GTZC7rKJtPlueQ==mpusoZBJ6V(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫଜ"):
			V4zp7XDeGY = V4zp7XDeGY or EkxQ20jJyPDcu8Bh5w176sX4C
			EZj98mpPMShOnl5vFAw += OTRKI6LbrQnZEm(u"ࠪࠤࠥ࠲ࠠࠡࠪࠪଝ")+peIwGURStOhP+hT7zFDpEyUqf8sXuN+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(MMsvzfBQCL18ecy2W)+pTwKPmzMSZhil5d2RWonre(u"ࠫ࠮࠭ଞ")
			mxu0cj3lVMYknPyG8QWAqLUTvoN += aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࠦࠠ࠭ࠢࠣࠫଟ")+Ed0XW2sFHvea
		elif GTZC7rKJtPlueQ==vZL6j4tSClIGxzNE5DX(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬଠ"):
			LYHFcSbk5T8QMpPuJmr6ZB3Nfs2 = EkxQ20jJyPDcu8Bh5w176sX4C
			mbxT3rqEaUD8G7 = bDt7Ya1VEio3(u"ࠧࠩࠩଡ")+peIwGURStOhP+hT7zFDpEyUqf8sXuN+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(MMsvzfBQCL18ecy2W)+O4ylJvVNwLztdiHqBWDU(u"ࠨࠫࠪଢ")
			k7IhKumwq4cAHd08SPb9Oi = Ed0XW2sFHvea
	EZj98mpPMShOnl5vFAw = EZj98mpPMShOnl5vFAw.strip(pTwKPmzMSZhil5d2RWonre(u"ࠩࠣࠤ࠱ࠦࠠࠨଣ"))
	mxu0cj3lVMYknPyG8QWAqLUTvoN = mxu0cj3lVMYknPyG8QWAqLUTvoN.strip(pTwKPmzMSZhil5d2RWonre(u"ࠪࠤࠥ࠲ࠠࠡࠩତ"))
	p8pA2fGcZjvX  = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣอืๆศ็ฯࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩଥ")+r9rhtA5Tek8sIoLfqwF7JcEV+ASo3rVMnT6O5Ws+jhAlCQ47ZgG
	p8pA2fGcZjvX += aSBkt4OU8JpWTEzVIHjAiv+v54ZuLY6dQ(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧଦ")+r9rhtA5Tek8sIoLfqwF7JcEV+aUWZ6F5i2Hh3wSx7yNT+jhAlCQ47ZgG
	p8pA2fGcZjvX += DDHwpETQrAm0xMNXGfyhqsUi(u"࠭࡜࡯࡞ࡱࠫଧ")+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไๆีอ์ิ฿ฺࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬନ")+r9rhtA5Tek8sIoLfqwF7JcEV+mxu0cj3lVMYknPyG8QWAqLUTvoN+jhAlCQ47ZgG
	p8pA2fGcZjvX += aSBkt4OU8JpWTEzVIHjAiv+g4UCaNkHvLwGhjmW(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆำ๎ࠥอๆหࠢอืฯิฯๆู้่๊ࠣส้ั฼ࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪ଩")+r9rhtA5Tek8sIoLfqwF7JcEV+EZj98mpPMShOnl5vFAw+jhAlCQ47ZgG
	p8pA2fGcZjvX += DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࡟ࡲࡡࡴࠧପ")+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧଫ")+r9rhtA5Tek8sIoLfqwF7JcEV+k7IhKumwq4cAHd08SPb9Oi+jhAlCQ47ZgG
	p8pA2fGcZjvX += aSBkt4OU8JpWTEzVIHjAiv+Xr2aHOK0huQ5DTS(u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬବ")+r9rhtA5Tek8sIoLfqwF7JcEV+mbxT3rqEaUD8G7+jhAlCQ47ZgG
	EkxQ20jJyPDcu8Bh5w176sX4C = (VUv43FRjiybnhW0Iq or V4zp7XDeGY)
	if EkxQ20jJyPDcu8Bh5w176sX4C:
		header = bDt7Ya1VEio3(u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧଭ")
		rtZM5KYaGepo7F2 = svULcgJ7jm(u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠧମ")
	else:
		header = FF70emVxhWOngCty(u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤุ๊้ࠣะ่ะ฻ࠣ฽๊อฯࠨଯ")
		rtZM5KYaGepo7F2 = Xr2aHOK0huQ5DTS(u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪର")
	p0gLWY5oTqa = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱุ้ะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠪ଱")
	NUakojpPKfYR28rzDdBwVOIX63u0cT = p8pA2fGcZjvX+FF70emVxhWOngCty(u"ࠪࡠࡳࡢ࡮ࠨଲ")+rtZM5KYaGepo7F2+JJu4MPClbTFpUwHiN(u"ࠫࡡࡴ࡜࡯ࠩଳ")+p0gLWY5oTqa
	XRZyfuiD8nLlKYPJ(pGncXOodjKhJzLSqVP1r(u"ࠬࡸࡩࡨࡪࡷࠫ଴"),header,NUakojpPKfYR28rzDdBwVOIX63u0cT,vZL6j4tSClIGxzNE5DX(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩଵ"))
	return
def OXlgcotDer5zTQ1MFYva3nKxdNR(showDialogs,j7Mo5VGkpNXA6TR):
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,bDt7Ya1VEio3(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪଶ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩଷ"))
	if showDialogs:
		EESB6QGVhWwL7KmoONFs5()
		OdeoGRrusmET()
	if j7Mo5VGkpNXA6TR:
		bqQv1mSPE2w0poVrxIKigNeTkL(YoAMfqm37GyFxbuKTt6e8CESHrhB)
		rtxakJhnS65zwuieb0UEpXTqId = [hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧସ"),vZL6j4tSClIGxzNE5DX(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩହ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭଺"),y5yX4jh6kUEgWZQIc(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ଻"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡵ࠯ࡧࡰࡵ଼࠭")]
		for BBp7IMPf9gwKtx in rtxakJhnS65zwuieb0UEpXTqId:
			AMu7aiqvPT6WcLOXDSkhFzdN,qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp,peIwGURStOhP = RiTVrvtfgm9jOe81(BBp7IMPf9gwKtx,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		o48zDxkduZq0QrSBF7923pGwTLcIJb(showDialogs)
		ksV5ngvbcaS8ByMLYxlfXh(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࡉࡥࡱࡹࡥమ"))
	return
def G3hVl67pIMOigeKa(AOn9c0puKyl=FF70emVxhWOngCty(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ଽ"),showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	Y8TnKMyWpslzubrkFR6tAOaDiSBg = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(bDt7Ya1VEio3(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫା"))
	import json as hlKGtjPuCaeIWUwvgMxp9
	data = hlKGtjPuCaeIWUwvgMxp9.loads(Y8TnKMyWpslzubrkFR6tAOaDiSBg)
	ssoU17XKPFwq2 = data[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩି")][Fg72JX6T5DkPy(u"ࠪࡺࡦࡲࡵࡦࠩୀ")]
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: ssoU17XKPFwq2 = ssoU17XKPFwq2.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧୁ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪୂ")+ssoU17XKPFwq2+bDt7Ya1VEio3(u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨୃ")+AOn9c0puKyl+OTRKI6LbrQnZEm(u"ࠧࠡมࠤࠫୄ"))
		if nndcv6tehuoKPpI!=mpusoZBJ6V(u"࠷ణ"): return YoAMfqm37GyFxbuKTt6e8CESHrhB
	AMu7aiqvPT6WcLOXDSkhFzdN,qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp,ghKS2oUH8ZyFDJpMrzQ6 = RiTVrvtfgm9jOe81(AOn9c0puKyl,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	if AMu7aiqvPT6WcLOXDSkhFzdN:
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୅"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫ୆"))
		RnGKqWfH2YOp0zDaA = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(tg9l25NH6WTacVSifLyAmY(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧେ")+AOn9c0puKyl+TCF8wLyDvgumfiXPSKRh(u"ࠫࠧࢃࡽࠨୈ"))
		if fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡕࡋࠨ୉") in RnGKqWfH2YOp0zDaA: AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		B3TKLo71hAGRqYgV0.sleep(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠱త"))
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(s0vAWcLSXEToH9Mik134q(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭୊"))
	elif showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪୋ"),s0vAWcLSXEToH9Mik134q(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪୌ"))
	return AMu7aiqvPT6WcLOXDSkhFzdN
def UU8FkvnySO(GTZC7rKJtPlueQ,showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	if showDialogs==QigevCplXxbPI1H: showDialogs = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	tBozgl3i9Y8Hd = BOfcPywrJb([GTZC7rKJtPlueQ])
	mSthwc9F8In,QkzT3aHj84yZsrtPxIwf6pMD = tBozgl3i9Y8Hd[GTZC7rKJtPlueQ]
	if QkzT3aHj84yZsrtPxIwf6pMD:
		AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะ୍ࠬ"),OTRKI6LbrQnZEm(u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬ୎")+GTZC7rKJtPlueQ+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧ୏"))
	else:
		AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(tOrSvd8QKNB(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ୐"),QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ୑"),QigevCplXxbPI1H+GTZC7rKJtPlueQ+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ࠲ࠥ๐ฬษࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๊ࠥใ๋ࠢํ฽๊๊ࠠศๆหี๋อๅอࠢ฼๊ิ้ࠠษื๋ีฮࠦีฮ์ะอࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊่ࠠา๊ࠤฬ๊ลืษไอࠥอไร่ࠣรࠬ୒"))
		if nndcv6tehuoKPpI==mpusoZBJ6V(u"࠲థ"):
			qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(y5yX4jh6kUEgWZQIc(u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨ୓")+GTZC7rKJtPlueQ+v54ZuLY6dQ(u"ࠩࠬࠫ୔"))
			B3TKLo71hAGRqYgV0.sleep(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠳ద"))
			qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ୕"))
			B3TKLo71hAGRqYgV0.sleep(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠴ధ"))
			while qVuYLZTmSUhQe7rEwvFRfc.getCondVisibility(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨୖ")): B3TKLo71hAGRqYgV0.sleep(bDt7Ya1VEio3(u"࠵న"))
			RnGKqWfH2YOp0zDaA = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(v54ZuLY6dQ(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨୗ")+GTZC7rKJtPlueQ+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡙ࡸࡵࡦࡿࢀࠫ୘"))
			if K7bLVaiRkx0lgU5SQM(u"ࠧࡐࡍࠪ୙") in RnGKqWfH2YOp0zDaA:
				AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
				if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୚"),TCF8wLyDvgumfiXPSKRh(u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨ୛"))
			elif showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଡ଼"),XWbHfI9B8swrOL(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭ଢ଼"))
	return AMu7aiqvPT6WcLOXDSkhFzdN
def KJGzXSZjxmgOk9hHi1(GTZC7rKJtPlueQ,Vfpave4EDnHi50WwsLXC2B,showDialogs):
	AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ୞"),FF70emVxhWOngCty(u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฻เุ่ࠢ็่ส฼วโหࠣห้๋ืๅ๊หอ๊ࠥใ๋ࠢํฮ๊ࠦสฬสํฮ์ูࠦๅ๋ࠣ็ํี๊ࠡ࠰ࠣห้๋ไโࠢๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡษ็ฦ๋ࠦฟࠢࠩୟ"))
		if nndcv6tehuoKPpI!=hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠶఩"): return YoAMfqm37GyFxbuKTt6e8CESHrhB
	bAfrvOapP8 = HMm6TqGlgU75axyS(Vfpave4EDnHi50WwsLXC2B,{},showDialogs)
	if bAfrvOapP8:
		jmgxnfTeOPc = KiTt9ZskMLjnCAUIJNXD7.path.join(UhsM4xeGEpyW9tr31oCRf,GTZC7rKJtPlueQ)
		eB8jr3L1inmU6OzINJd(jmgxnfTeOPc,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		import zipfile as wdX85lEUTZoML2jax3VO49Brq,io as qqgatNTdCk8bQo3JPXUWz
		dy6rcbkApxI4378MQFXg1lOtSLov = qqgatNTdCk8bQo3JPXUWz.BytesIO(bAfrvOapP8)
		try:
			JqacltywpRbiC0I9uAoh2 = wdX85lEUTZoML2jax3VO49Brq.ZipFile(dy6rcbkApxI4378MQFXg1lOtSLov)
			JqacltywpRbiC0I9uAoh2.extractall(UhsM4xeGEpyW9tr31oCRf)
			B3TKLo71hAGRqYgV0.sleep(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷ప"))
			qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(v54ZuLY6dQ(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫୠ"))
			B3TKLo71hAGRqYgV0.sleep(pGncXOodjKhJzLSqVP1r(u"࠲ఫ"))
			RnGKqWfH2YOp0zDaA = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(K7bLVaiRkx0lgU5SQM(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥࠫୡ")+GTZC7rKJtPlueQ+Xr2aHOK0huQ5DTS(u"ࠩࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡕࡴࡸࡩࢂࢃࠧୢ"))
			if TCF8wLyDvgumfiXPSKRh(u"ࠪࡓࡐ࠭ୣ") in RnGKqWfH2YOp0zDaA: AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,TCF8wLyDvgumfiXPSKRh(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ୤"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡇࡄࡅࡑࡑࡗࡤࡊࡅࡕࡃࡌࡐࡘ࠭୥"))
		except: AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if showDialogs:
		if AMu7aiqvPT6WcLOXDSkhFzdN: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ୦"),tg9l25NH6WTacVSifLyAmY(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫ୧"))
		else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୨"),OTRKI6LbrQnZEm(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ลืษไอࠥอไๆู็์อฯࠧ୩"))
	return AMu7aiqvPT6WcLOXDSkhFzdN
def RiTVrvtfgm9jOe81(GTZC7rKJtPlueQ,showDialogs,WmnTs3Z9bO):
	nndcv6tehuoKPpI,AMu7aiqvPT6WcLOXDSkhFzdN,qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp,peIwGURStOhP = XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ୪"),QigevCplXxbPI1H
	S5NRneCz4GQJoVWFxBM7c = ZMdfXcs4e1Y3qhuO7t6Fg0TwyaCpj([GTZC7rKJtPlueQ])
	if GTZC7rKJtPlueQ in list(S5NRneCz4GQJoVWFxBM7c.keys()):
		EkxQ20jJyPDcu8Bh5w176sX4C,peIwGURStOhP,pMaVt5K0bOGFe2W,Ed0XW2sFHvea,ukqJwnOvXg,MMsvzfBQCL18ecy2W,Vfpave4EDnHi50WwsLXC2B = S5NRneCz4GQJoVWFxBM7c[GTZC7rKJtPlueQ]
		if MMsvzfBQCL18ecy2W==s0vAWcLSXEToH9Mik134q(u"ࠫ࡬ࡵ࡯ࡥࠩ୫"):
			AMu7aiqvPT6WcLOXDSkhFzdN,qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = XpREPf7d08GnIS6i4KNLMyZHmuQqxD,y5yX4jh6kUEgWZQIc(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭୬")
			if WmnTs3Z9bO:
				nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ୭"),y5yX4jh6kUEgWZQIc(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤ่๎ฯ๋ࠢํืฯิฯๆࠢฦาึࠦลึัสี๋ࠥส้ใิࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ้ํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧ୮")+GTZC7rKJtPlueQ+s0vAWcLSXEToH9Mik134q(u"ࠨ࡞ࡱࡠࡳํไࠡฬิ๎ิࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส่ࠢีฮࠦรฯำ์ࠫ୯"))
				if nndcv6tehuoKPpI:
					AMu7aiqvPT6WcLOXDSkhFzdN = KJGzXSZjxmgOk9hHi1(GTZC7rKJtPlueQ,Vfpave4EDnHi50WwsLXC2B,YoAMfqm37GyFxbuKTt6e8CESHrhB)
					if AMu7aiqvPT6WcLOXDSkhFzdN:
						qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = FF70emVxhWOngCty(u"ࠩࡵࡩ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧ୰")
						if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ୱ"),FF70emVxhWOngCty(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠๆ๊ฯ์ิฯࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬส฿วะหࠣฮะฮ๊ห้สࡠࡳࡢ࡮ࠨ୲")+GTZC7rKJtPlueQ)
					else:
						qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = K7bLVaiRkx0lgU5SQM(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ୳")
						lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ୴"),pGncXOodjKhJzLSqVP1r(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ฻สำฮࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧ୵")+GTZC7rKJtPlueQ)
		else:
			if showDialogs:
				if MMsvzfBQCL18ecy2W==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪ୶"): nDRKguWex0iVN8 = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"่ࠩฮํ่แสࠩ୷")
				elif MMsvzfBQCL18ecy2W==s0vAWcLSXEToH9Mik134q(u"ࠪࡳࡱࡪࠧ୸"): nDRKguWex0iVN8 = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ็ี๊ๆหࠪ୹")
				elif MMsvzfBQCL18ecy2W==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭୺"): nDRKguWex0iVN8 = pGncXOodjKhJzLSqVP1r(u"ฺ๋࠭ำ้ࠣะฮสสࠩ୻")
				nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,XWbHfI9B8swrOL(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ୼"),pGncXOodjKhJzLSqVP1r(u"ࠨ้ำ๋ࠥอไฦุสๅฮࠦࠧ୽")+nDRKguWex0iVN8+K7bLVaiRkx0lgU5SQM(u"ࠩࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦื็หาࠦ็ั้ࠣห้๋ิไๆฬࠤฤࠧ࡜࡯࡞ࡱࠫ୾")+GTZC7rKJtPlueQ)
			if not nndcv6tehuoKPpI: qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = pTwKPmzMSZhil5d2RWonre(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬ୿")
			else:
				if MMsvzfBQCL18ecy2W==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭஀"):
					W9lfsoMawqOzpQcXD = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ஁")+GTZC7rKJtPlueQ+XWbHfI9B8swrOL(u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡙ࡸࡵࡦࡿࢀࠫஂ"))
					if aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡐࡍࠪஃ") in W9lfsoMawqOzpQcXD:
						AMu7aiqvPT6WcLOXDSkhFzdN,qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = XpREPf7d08GnIS6i4KNLMyZHmuQqxD,tg9l25NH6WTacVSifLyAmY(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩ஄")
						if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬஅ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅห๊ๅๅฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨஆ")+GTZC7rKJtPlueQ)
					elif showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧஇ"),fk8jc5uDLX16qrih3ZaPxsvO(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆศฺฬ็ษࠡ็อ์็็ษࠡ࠰࠱ࠤํ๊ๅࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣฮูเ๊ๅ้สࡠࡳࡢ࡮ࠨஈ")+GTZC7rKJtPlueQ)
				elif MMsvzfBQCL18ecy2W in [svULcgJ7jm(u"࠭࡯࡭ࡦࠪஉ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨஊ")]:
					AMu7aiqvPT6WcLOXDSkhFzdN = KJGzXSZjxmgOk9hHi1(GTZC7rKJtPlueQ,Vfpave4EDnHi50WwsLXC2B,YoAMfqm37GyFxbuKTt6e8CESHrhB)
					if AMu7aiqvPT6WcLOXDSkhFzdN:
						if MMsvzfBQCL18ecy2W==DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡱ࡯ࡨࠬ஋"): qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡸࡴࡩࡧࡴࡦࡦࠪ஌")
						elif MMsvzfBQCL18ecy2W==O4ylJvVNwLztdiHqBWDU(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫ஍"): qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp = pGncXOodjKhJzLSqVP1r(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧஎ")
						peIwGURStOhP = Ed0XW2sFHvea
						if showDialogs:
							if qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp==y5yX4jh6kUEgWZQIc(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ஏ"): lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,XWbHfI9B8swrOL(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩஐ"),pTwKPmzMSZhil5d2RWonre(u"ࠧอ์าࠤัีวࠡ࠰࠱ࠤฬ๊ลืษไอ้ࠥว็ฬࠣๆิ๐ๅสࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฮัํฯ์อ࡜࡯࡞ࡱࠫ஑")+GTZC7rKJtPlueQ)
							elif qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠫஒ"): lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬஓ"),tg9l25NH6WTacVSifLyAmY(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๆ่ࠤฯ้ๆࠡ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎วๅสิ๊ฬ๋ฬࠡไส้ࠥฮสฬสํฮ์อ࡜࡯࡞ࡱࠫஔ")+GTZC7rKJtPlueQ)
					elif showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧக"),TCF8wLyDvgumfiXPSKRh(u"๊ࠬไฤีไࠤ࠳࠴ࠠศๆหี๋อๅอࠢ็้ࠥ๐ำหูํ฽ࠥะอะ์ฮࠤศ๎ࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࡠࡳࡢ࡮ࠨ஖")+GTZC7rKJtPlueQ)
	elif showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ஗"),pGncXOodjKhJzLSqVP1r(u"ࠧๅๆฦืๆࠦ࠮࠯๊ࠢิ์ࠦวๅวูหๆฯࠠ฻์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠๆ๊สๆ฾ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳࠴้ࠠๆ๊ิฬࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤศ์๋ࠠไ๋้ࠥฮสฬสํฮࠥํะ่ࠢส่ส฼วโหࠣวํࠦสฮัํฯ์อ࡜࡯࡞ࡱࠫ஘")+GTZC7rKJtPlueQ)
	return AMu7aiqvPT6WcLOXDSkhFzdN,qqjUSy4KeaOv6hsEYg5kX0RNdZQlwp,peIwGURStOhP
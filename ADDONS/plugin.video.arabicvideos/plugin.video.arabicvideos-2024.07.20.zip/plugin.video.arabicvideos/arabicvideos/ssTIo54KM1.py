# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'CIMANOW'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_CMN_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['قائمتي']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==300: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==301: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==302: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	elif mode==303: W9lfsoMawqOzpQcXD = Wy9QU4Ns8orXtliKZSjnJH3bVF(url)
	elif mode==304: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==305: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==306: W9lfsoMawqOzpQcXD = erS6TbWMBUjXnEKzkpP3hcGNZlH7Y()
	elif mode==309: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'لماذا الموقع بطيء',QigevCplXxbPI1H,306)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,309,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m+'/home',QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMANOW-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<header>(.*?)</header>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('<li><a href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,301)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	eR6YT8AbXwl(vxQUXEuH9m+'/home',aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def erS6TbWMBUjXnEKzkpP3hcGNZlH7Y():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def eR6YT8AbXwl(url,aY63L2NhgvwJIxPAoDG4MKECmZXF1=QigevCplXxbPI1H):
	if not aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMANOW-SUBMENU-1st')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	mOX6U4vRFfJ = 0
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('(<section>.*?</section>)',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		for LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
			mOX6U4vRFfJ += 1
			items = sBvufaD6c9YHdOqTjCQ3.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for title,muL1JT9HFXy0rlBN7a8f3Qep,RMC6c2kL5hGOnFaIwAyb in items:
				title = title.strip(hT7zFDpEyUqf8sXuN)
				if title==QigevCplXxbPI1H: title = 'بووووو'
				if 'em><a' not in muL1JT9HFXy0rlBN7a8f3Qep:
					if LKzFWsmvjUVGMDBapflx6H4NY.count('/category/')>0:
						Z8O95QXEfjdcWgp = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
						for RMC6c2kL5hGOnFaIwAyb in Z8O95QXEfjdcWgp:
							title = RMC6c2kL5hGOnFaIwAyb.split('/')[-2]
							E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,301)
						continue
					else: RMC6c2kL5hGOnFaIwAyb = url+'?sequence='+str(mOX6U4vRFfJ)
				if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,302)
	else: ddbEXhWzOnIaR(url,aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	return
def ddbEXhWzOnIaR(url,aY63L2NhgvwJIxPAoDG4MKECmZXF1=QigevCplXxbPI1H):
	if aY63L2NhgvwJIxPAoDG4MKECmZXF1==QigevCplXxbPI1H:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMANOW-TITLES-1st')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if '?sequence=' in url:
		url,mOX6U4vRFfJ = url.split('?sequence=')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('(<section>.*?</section>)',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[int(mOX6U4vRFfJ)-1]
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"posts"(.*?)</body>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	for RMC6c2kL5hGOnFaIwAyb,data,cXu4fN1moCypJqb72OZvd in items:
		title = sBvufaD6c9YHdOqTjCQ3.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if title: title = title[0][2].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		if not title or title==QigevCplXxbPI1H:
			title = sBvufaD6c9YHdOqTjCQ3.findall('title">.*?</em>(.*?)<',data,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if title: title = title[0].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			if not title or title==QigevCplXxbPI1H:
				title = sBvufaD6c9YHdOqTjCQ3.findall('title">(.*?)<',data,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				title = title[0].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		title = title.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
		if title not in wibHRCAFtsupIjx4ZTELeM:
			wibHRCAFtsupIjx4ZTELeM.append(title)
			Pk5h14WpxO3nAQFv0rYmNa8KDblSg = RMC6c2kL5hGOnFaIwAyb+data+cXu4fN1moCypJqb72OZvd
			if '/selary/' in Pk5h14WpxO3nAQFv0rYmNa8KDblSg or 'مسلسل' in Pk5h14WpxO3nAQFv0rYmNa8KDblSg or '"episode"' in Pk5h14WpxO3nAQFv0rYmNa8KDblSg:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,303,cXu4fN1moCypJqb72OZvd)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,305,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('<li><a href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,302)
	return
def Wy9QU4Ns8orXtliKZSjnJH3bVF(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMANOW-SEASONS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	name = sBvufaD6c9YHdOqTjCQ3.findall('<title>(.*?)</title>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	name = name[0].replace('| سيما ناو',QigevCplXxbPI1H).replace('Cima Now',QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	name = name.split('الحلقة')[0].strip(hT7zFDpEyUqf8sXuN)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<section(.*?)</section>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(items)>1:
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = name+' - '+title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,304)
		else: oB2rmVgqUND(url)
	return
def oB2rmVgqUND(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMANOW-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if '/selary/' not in url:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"episodes"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			title = 'الحلقة '+title
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,305)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"details"(.*?)"related"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,305,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	Kj0TOU6BmSMlJHZYLd = url+'watching/'
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMANOW-PLAY-5th')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"download"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			oI6LvXMf4VEPe8jOdpKC0hUmS = sBvufaD6c9YHdOqTjCQ3.findall('\d\d\d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if oI6LvXMf4VEPe8jOdpKC0hUmS:
				oI6LvXMf4VEPe8jOdpKC0hUmS = '____'+oI6LvXMf4VEPe8jOdpKC0hUmS[0]
				title = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,'name')
			else: oI6LvXMf4VEPe8jOdpKC0hUmS = QigevCplXxbPI1H
			Wdek0SptsHCKog19OBJDTRAX7m = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'+oI6LvXMf4VEPe8jOdpKC0hUmS
			ldFqnNIsftrY43JBM6LPjzU8m.append(Wdek0SptsHCKog19OBJDTRAX7m)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"watch"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('"embed".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb in rsBojxT8UZwL:
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
			title = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,'name')
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__embed'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		rsBojxT8UZwL = [vxQUXEuH9m+'/wp-content/themes/Cima%20Now%20New/core.php']
		if rsBojxT8UZwL:
			items = sBvufaD6c9YHdOqTjCQ3.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for nVWUleSBvsKaEhoCxNryf,id,title in items:
				title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
				RMC6c2kL5hGOnFaIwAyb = rsBojxT8UZwL[0]+'?action=switch&index='+nVWUleSBvsKaEhoCxNryf+'&id='+id+'?named='+title+'__watch'
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m + '/?s='+search
	ddbEXhWzOnIaR(url)
	return
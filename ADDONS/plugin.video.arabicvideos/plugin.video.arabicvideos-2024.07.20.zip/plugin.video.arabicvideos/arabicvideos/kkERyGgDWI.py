# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
headers = { 'User-Agent' : QigevCplXxbPI1H }
PuT0IphGNsketAQ = 'AKWAM'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_AKW_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ggOestC8qL5R = QigevCplXxbPI1H
ef1pQcbEtPjMnXYrvOi = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==240: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==241: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==242: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==243: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==244: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'FILTERS___'+text)
	elif mode==245: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'CATEGORIES___'+text)
	elif mode==246: W9lfsoMawqOzpQcXD = p6tBigas8JvRY4G3fWCXxzmd(url)
	elif mode==247: W9lfsoMawqOzpQcXD = YYEnLmrFyb1Clj(url)
	elif mode==248: W9lfsoMawqOzpQcXD = aKpANImV8YiotEgl2()
	elif mode==249: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def aKpANImV8YiotEgl2():
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'AKWAM-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	R8dFSajbyVIWr6tws4eQONvD3l = sBvufaD6c9YHdOqTjCQ3.findall('home-site-btn-container.*?href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if R8dFSajbyVIWr6tws4eQONvD3l: R8dFSajbyVIWr6tws4eQONvD3l = R8dFSajbyVIWr6tws4eQONvD3l[0]
	else: R8dFSajbyVIWr6tws4eQONvD3l = vxQUXEuH9m
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',R8dFSajbyVIWr6tws4eQONvD3l,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'AKWAM-MENU-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,249,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',vxQUXEuH9m,246)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',vxQUXEuH9m,247)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',R8dFSajbyVIWr6tws4eQONvD3l,241,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	recent = sBvufaD6c9YHdOqTjCQ3.findall('recently-container.*?href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	RMC6c2kL5hGOnFaIwAyb = recent[0]
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أضيف حديثا',RMC6c2kL5hGOnFaIwAyb,241)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,name,LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
		if name in ef1pQcbEtPjMnXYrvOi: continue
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,241)
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title in ef1pQcbEtPjMnXYrvOi: continue
			title = name+hT7zFDpEyUqf8sXuN+title
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,241)
	return
def p6tBigas8JvRY4G3fWCXxzmd(website=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKWAM-MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="menu(.*?)<nav',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?text">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title not in ef1pQcbEtPjMnXYrvOi:
				title = title+' مصنفة'
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,245)
		if website==QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def YYEnLmrFyb1Clj(website=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKWAM-MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="menu(.*?)<nav',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?text">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title not in ef1pQcbEtPjMnXYrvOi:
				title = title+' مفلترة'
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,244)
		if website==QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,type=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('swiper-container(.*?)swiper-button-prev',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="widget"(.*?)main-footer',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not items:
			items = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
			if '/series/' in RMC6c2kL5hGOnFaIwAyb or '/shows/' in RMC6c2kL5hGOnFaIwAyb:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,242,cXu4fN1moCypJqb72OZvd)
			elif '/movies/' in RMC6c2kL5hGOnFaIwAyb:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,243,cXu4fN1moCypJqb72OZvd)
			elif '/games/' not in RMC6c2kL5hGOnFaIwAyb:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,243,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			RMC6c2kL5hGOnFaIwAyb = i7gQvkPzZJm4jM3uYV2xfAqhs(RMC6c2kL5hGOnFaIwAyb)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,241)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	url = vxQUXEuH9m + '/search?q='+VIo6FYRkx0MLP4wufEGsgnz9
	W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	return
def oB2rmVgqUND(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		cXu4fN1moCypJqb72OZvd = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel('ListItem.Icon')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'رابط التشغيل',url,243,cXu4fN1moCypJqb72OZvd)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('-episodes">(.*?)<div class="widget-4',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		yjHcgifXG1 = sBvufaD6c9YHdOqTjCQ3.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in yjHcgifXG1:
			title = title.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,242,cXu4fN1moCypJqb72OZvd)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,243,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,True,'AKWAM-PLAY-1st')
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('badge-danger.*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz = sBvufaD6c9YHdOqTjCQ3.findall('li><a href="#(.*?)".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6,mfFwcWZHXVGvyU3B0ILburCoh,hel5y9tNYZo71DC4wMcOXjPTI6pd = [],[],[],[]
	if DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz:
		ain78FlYBCWD31qLKEgT2bvIy = 'mp4'
		for HPzXOoaMhvUySC0pcQgntFx,oI6LvXMf4VEPe8jOdpKC0hUmS in DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz:
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('tab-content quality" id="'+HPzXOoaMhvUySC0pcQgntFx+'".*?</div>.\s*</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			mfFwcWZHXVGvyU3B0ILburCoh.append(LKzFWsmvjUVGMDBapflx6H4NY)
			hel5y9tNYZo71DC4wMcOXjPTI6pd.append(oI6LvXMf4VEPe8jOdpKC0hUmS)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="qualities(.*?)<h3.*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			LKzFWsmvjUVGMDBapflx6H4NY,filename = fwSu6JsQZpEiv[0]
			XGAV7UMKQvPFWnB6ub9380 = ['zip','rar','txt','pdf','htm','tar','iso','html']
			ain78FlYBCWD31qLKEgT2bvIy = filename.rsplit('.',1)[1].strip(hT7zFDpEyUqf8sXuN)
			if ain78FlYBCWD31qLKEgT2bvIy in XGAV7UMKQvPFWnB6ub9380:
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		mfFwcWZHXVGvyU3B0ILburCoh.append(LKzFWsmvjUVGMDBapflx6H4NY)
		hel5y9tNYZo71DC4wMcOXjPTI6pd.append(QigevCplXxbPI1H)
	for A5SjhJUg37pNiMC4Eot6lOF in range(len(mfFwcWZHXVGvyU3B0ILburCoh)):
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?icon-(.*?)"',mfFwcWZHXVGvyU3B0ILburCoh[A5SjhJUg37pNiMC4Eot6lOF],sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,a82Fct5vLAkJBMxUnW4VombEPsI9lO in rsBojxT8UZwL:
			if 'torrent' in a82Fct5vLAkJBMxUnW4VombEPsI9lO: continue
			elif 'download' in a82Fct5vLAkJBMxUnW4VombEPsI9lO: type = 'download'
			elif 'play' in a82Fct5vLAkJBMxUnW4VombEPsI9lO: type = 'watch'
			else: type = 'unknown'
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named=__'+type+'____'+hel5y9tNYZo71DC4wMcOXjPTI6pd[A5SjhJUg37pNiMC4Eot6lOF]+'__akwam'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	XGiBxdyuLeSzpmvUCEwJI = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='CATEGORIES':
		if XGiBxdyuLeSzpmvUCEwJI[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XGiBxdyuLeSzpmvUCEwJI[0:-1])):
			if XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'all')
		Kj0TOU6BmSMlJHZYLd = url+'?'+IhG0UytMJko7
	elif type=='FILTERS':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'all')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها',Kj0TOU6BmSMlJHZYLd,241,QigevCplXxbPI1H,'1')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',Kj0TOU6BmSMlJHZYLd,241,QigevCplXxbPI1H,'1')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,True,'AKWAM-FILTERS_MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<form id(.*?)</form>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	dict = {}
	for Vjv2Okb6qhMRQgaDlu3JCir,name,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		items = sBvufaD6c9YHdOqTjCQ3.findall('<option(.*?)>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='CATEGORIES':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<=1:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'CATEGORIES___'+Vq4HIkij2ZLE)
				return
			else:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,241,QigevCplXxbPI1H,'1')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,245,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='FILTERS':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع : '+name,Kj0TOU6BmSMlJHZYLd,244,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			if 'value' not in nFdGHjceZzW: nFdGHjceZzW = C4kS0cewBJy8YOWtZxXNjfM2
			else: nFdGHjceZzW = sBvufaD6c9YHdOqTjCQ3.findall('"(.*?)"',nFdGHjceZzW,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			title = C4kS0cewBJy8YOWtZxXNjfM2+' : '#+dict[Vjv2Okb6qhMRQgaDlu3JCir]['0']
			title = C4kS0cewBJy8YOWtZxXNjfM2+' : '+name
			if type=='FILTERS': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,244,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='CATEGORIES' and XGiBxdyuLeSzpmvUCEwJI[-2]+'=' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'all')
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'?'+IhG0UytMJko7
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,241,QigevCplXxbPI1H,'1')
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,245,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	NBJvnaA2GkRo6SD79YsVjqd = ['section','category','rating','year','language','formats','quality']
	for key in NBJvnaA2GkRo6SD79YsVjqd:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	return bYlTrNXtvf0G7y
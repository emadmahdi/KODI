# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'MOVS4U'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_M4U_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['انواع افلام','جودات افلام']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==380: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==381: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==382: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==383: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==389: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,389,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',vxQUXEuH9m,381,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجانبية',vxQUXEuH9m,381,QigevCplXxbPI1H,QigevCplXxbPI1H,'sider')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'MOVS4U-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	items = sBvufaD6c9YHdOqTjCQ3.findall('<header>.*?<h2>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for mOX6U4vRFfJ in range(len(items)):
		title = items[mOX6U4vRFfJ]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,vxQUXEuH9m,381,QigevCplXxbPI1H,QigevCplXxbPI1H,'latest'+str(mOX6U4vRFfJ))
	LKzFWsmvjUVGMDBapflx6H4NY = QigevCplXxbPI1H
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="menu"(.*?)id="contenedor"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY += fwSu6JsQZpEiv[0]
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="sidebar(.*?)aside',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY += fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JwNdW5ulnaVBmKPCijI4tHFEf39R = True
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if title=='الأعلى مشاهدة':
			if JwNdW5ulnaVBmKPCijI4tHFEf39R:
				title = 'الافلام '+title
				JwNdW5ulnaVBmKPCijI4tHFEf39R = False
			else: title = 'المسلسلات '+title
		if title not in ef1pQcbEtPjMnXYrvOi:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,381)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,type):
	LKzFWsmvjUVGMDBapflx6H4NY,items = [],[]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'MOVS4U-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if type=='search':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="search-page"(.*?)class="sidebar',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='sider':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="widget(.*?)class="widget',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		zMf8K43aBXGxPjvNJL7k0 = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ldFqnNIsftrY43JBM6LPjzU8m,ccrXN0VUmvKdPZOI4n3GFEjiz,ttGBwQOv3K41hIkc6 = zip(*zMf8K43aBXGxPjvNJL7k0)
		items = zip(ccrXN0VUmvKdPZOI4n3GFEjiz,ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6)
	elif type=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="slider-movies-tvshows"(.*?)<header>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif 'latest' in type:
		mOX6U4vRFfJ = int(type[-1:])
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('<header>','<end><start>')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('<div class="sidebar','<end><div class="sidebar')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<start>(.*?)<end>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[mOX6U4vRFfJ]
		if mOX6U4vRFfJ==2: items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="content"(.*?)class="(pagination|sidebar)',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0][0]
			if '/collection/' in url:
				items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			elif '/quality/' in url:
				items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items and LKzFWsmvjUVGMDBapflx6H4NY:
		items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		if 'serie' in title:
			title = sBvufaD6c9YHdOqTjCQ3.findall('^(.*?)<.*?serie">(.*?)<',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			title = title[0][1]
			if title in wibHRCAFtsupIjx4ZTELeM: continue
			wibHRCAFtsupIjx4ZTELeM.append(title)
			title = '_MOD_'+title
		YIwQJyV0hAUR1EfKogObLzDMmx = sBvufaD6c9YHdOqTjCQ3.findall('^(.*?)<',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if YIwQJyV0hAUR1EfKogObLzDMmx: title = YIwQJyV0hAUR1EfKogObLzDMmx[0]
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if '/tvshows/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,383,cXu4fN1moCypJqb72OZvd)
		elif '/episodes/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,383,cXu4fN1moCypJqb72OZvd)
		elif '/seasons/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,383,cXu4fN1moCypJqb72OZvd)
		elif '/collection/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,381,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,382,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		UqxgVfTmzWcj2M3JIa = fwSu6JsQZpEiv[0][0]
		SZpKdHIyv3 = fwSu6JsQZpEiv[0][1]
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0][2]
		items = sBvufaD6c9YHdOqTjCQ3.findall("href='(.*?)'.*?>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title==QigevCplXxbPI1H or title==SZpKdHIyv3: continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,381,QigevCplXxbPI1H,QigevCplXxbPI1H,type)
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('/page/'+title+'/','/page/'+SZpKdHIyv3+'/')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'اخر صفحة '+SZpKdHIyv3,RMC6c2kL5hGOnFaIwAyb,381,QigevCplXxbPI1H,QigevCplXxbPI1H,type)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'MOVS4U-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('class="C rated".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl,False):
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المسلسل للكبار والمبرمج منعه',QigevCplXxbPI1H,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('''class='item'><a href="(.*?)"''',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if Kj0TOU6BmSMlJHZYLd:
			Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[1]
			oB2rmVgqUND(Kj0TOU6BmSMlJHZYLd)
			return
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('''class='episodios'(.*?)id="cast"''',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for cXu4fN1moCypJqb72OZvd,V1nZX7O5WwEq8HmvkY,RMC6c2kL5hGOnFaIwAyb,name in items:
			title = V1nZX7O5WwEq8HmvkY+' : '+name+' الحلقة'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,382)
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'MOVS4U-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('class="C rated".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0][0]
		items = sBvufaD6c9YHdOqTjCQ3.findall("data-url='(.*?)'.*?class='server'>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="remodal"(.*?)class="remodal-close"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/?s='+search
	ddbEXhWzOnIaR(url,'search')
	return
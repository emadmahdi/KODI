# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from r6mxE54yIg import *
import base64 as akgfpLEN8Kn396XjFUut4QJVI
PuT0IphGNsketAQ = K7bLVaiRkx0lgU5SQM(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪପ")
MGNnlD6YCcemWAuhkL = {}
lc0jJQ4zboeDI3tqTrpvm5gZO = []
if b7sJAmSxlBvaMdHFz:
	kjMow46qSfz58IZdWAYK1L3TJhl = YwzoJLlhkvf4a.translatePath(mpusoZBJ6V(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫଫ"))
	ydKHnhCfRwT0JgF9iD7WQSYlusGk5 = YwzoJLlhkvf4a.translatePath(tg9l25NH6WTacVSifLyAmY(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬବ"))
	zf48ESvsrIAxmFCuJD = YwzoJLlhkvf4a.translatePath(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩଭ"))
	h8oaOyKE9vx0F7sQUkumSGYCD5VZ = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨମ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩଯ"),tOrSvd8QKNB(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭ର"))
	rQpntlDIx38eSHkwObBXimcF6Za = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,O4ylJvVNwLztdiHqBWDU(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ଱"),vZL6j4tSClIGxzNE5DX(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬଲ"),JJu4MPClbTFpUwHiN(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫଳ"))
	XE4VUzrimwqb3RJTnjovLA = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,FF70emVxhWOngCty(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ଴"),s0vAWcLSXEToH9Mik134q(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨଵ"),OTRKI6LbrQnZEm(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧଶ"))
	bJ75YtchPxVNaSsn = JJu4MPClbTFpUwHiN(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩଷ")
	from urllib.parse import quote as _0NlhwdvYf2A3PituyUGemxDMJz9
else:
	kjMow46qSfz58IZdWAYK1L3TJhl = qVuYLZTmSUhQe7rEwvFRfc.translatePath(vZL6j4tSClIGxzNE5DX(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪସ"))
	ydKHnhCfRwT0JgF9iD7WQSYlusGk5 = qVuYLZTmSUhQe7rEwvFRfc.translatePath(y5yX4jh6kUEgWZQIc(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫହ"))
	zf48ESvsrIAxmFCuJD = qVuYLZTmSUhQe7rEwvFRfc.translatePath(K7bLVaiRkx0lgU5SQM(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ଺"))
	h8oaOyKE9vx0F7sQUkumSGYCD5VZ = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ଻"),JJu4MPClbTFpUwHiN(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ଼"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬଽ"))
	rQpntlDIx38eSHkwObBXimcF6Za = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,K7bLVaiRkx0lgU5SQM(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪା"),JJu4MPClbTFpUwHiN(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫି"),vZL6j4tSClIGxzNE5DX(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪୀ"))
	XE4VUzrimwqb3RJTnjovLA = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,mpusoZBJ6V(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ୁ"),g4UCaNkHvLwGhjmW(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧୂ"),OTRKI6LbrQnZEm(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ୃ"))
	bJ75YtchPxVNaSsn = tOrSvd8QKNB(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨୄ").encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	from urllib import quote as _0NlhwdvYf2A3PituyUGemxDMJz9
FcupZdBmjb4nReDCzs9wLKrV3lfx = KiTt9ZskMLjnCAUIJNXD7.path.join(zf48ESvsrIAxmFCuJD,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪ୅"))
gpiHl9C7eKx = KiTt9ZskMLjnCAUIJNXD7.path.join(zf48ESvsrIAxmFCuJD,s0vAWcLSXEToH9Mik134q(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨ୆"))
kjO1FxS6IiKhsVvQWnypUZP7X5N = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,OTRKI6LbrQnZEm(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬେ"))
hukpSr1C78LU0PHVYcMzGewmKtlNa = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭ୈ"))
K28yBvSdRwo = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,y5yX4jh6kUEgWZQIc(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ୉"))
RpmwIQ5vaFkP8SuNW = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,tOrSvd8QKNB(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ୊"))
wksa26iOAem0NqBJj = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩୋ"))
qOm1IJUYKPiroj59ZHnkXDVy6zMw = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,v54ZuLY6dQ(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩୌ"))
UE7QOpJtiYsfF8bTd4vVowZ = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,vZL6j4tSClIGxzNE5DX(u"ࠩ࡬ࡱࡦ࡭ࡥࡴ୍ࠩ"))
iwtPjs0DOlK3FIELRqvzm76k2Jncp = KiTt9ZskMLjnCAUIJNXD7.path.join(UE7QOpJtiYsfF8bTd4vVowZ,y5yX4jh6kUEgWZQIc(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡶࠫ୎"))
gCdTSQXzi4ua5AG6rO1YpnV = KiTt9ZskMLjnCAUIJNXD7.path.join(iwtPjs0DOlK3FIELRqvzm76k2Jncp,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡣ࠵࠶࠰࠱ࡡ࠱ࡴࡳ࡭ࠧ୏"))
XoeSNbWwLnKC8Q = rljJ8cEGHQtapvDK4LZb6wWMmId2N.Addon().getAddonInfo(K7bLVaiRkx0lgU5SQM(u"ࠬࡶࡡࡵࡪࠪ୐"))
MWy7BrpgaLJ9i2A4 = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ୑"))
emQS6fPDbLRpdANwOFGs5uqBxgZl = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,tOrSvd8QKNB(u"ࠧࡵࡪࡸࡱࡧ࠴ࡰ࡯ࡩࠪ୒"))
kzRKHE0xacV9Zr3fmA6vO = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,s0vAWcLSXEToH9Mik134q(u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬ୓"))
p24GwsHn8PAfNoyrSd35DWkMi1LC9 = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,v54ZuLY6dQ(u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭୔"))
Ru4wIvSjYW5DAVbK0plPo6z = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠴ࡰ࡯ࡩࠪ୕"))
llMDwxdqpBPIQ6ahiC = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡵࡵࡳࡵࡧࡵ࠲ࡵࡴࡧࠨୖ"))
UuDo3rH5zFewYRaqZdCbT0kxAyIS = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,g4UCaNkHvLwGhjmW(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯࠯ࡲࡱ࡫ࠬୗ"))
JaSegdGpjfTPh87lx1brQsK9mRUo = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,Xr2aHOK0huQ5DTS(u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴ࠯ࡲࡱ࡫ࠬ୘"))
jdasRuBy7t3JXE2g = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,XWbHfI9B8swrOL(u"ࠧ࡮ࡧࡱࡹࡤࡸࡥࡥࡡ࠵࠴࠵ࡾ࠲࠶࠲࠱ࡴࡳ࡭ࠧ୙"))
bQiqIMtxKPkJUoEgvDawN7 = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,O4ylJvVNwLztdiHqBWDU(u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨ୚"))
UhsM4xeGEpyW9tr31oCRf = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,XWbHfI9B8swrOL(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ୛"))
UY4pdbX7slFWo0x3DaEJe6 = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,TCF8wLyDvgumfiXPSKRh(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬଡ଼"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨଢ଼"),GTZC7rKJtPlueQ,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ୞"))
rizEfk7lRM9ZWtTLDNS2 = KiTt9ZskMLjnCAUIJNXD7.path.join(kjMow46qSfz58IZdWAYK1L3TJhl,fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࡭ࡦࡦ࡬ࡥࠬୟ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡇࡱࡱࡸࡸ࠭ୠ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫୡ"))
FNU9Shpblgo4mLkGQ3EOfyCJ0a = svULcgJ7jm(u"࠷ቍ")
qqfVzPxYZ5R = [DD7NjwespWyQJ4E6mXk0ZAufPg(u"ุࠩๅึ࠭ୢ"),vZL6j4tSClIGxzNE5DX(u"ࠪวํ๊ࠧୣ"),svULcgJ7jm(u"ࠫะอๆ๋ࠩ୤"),y5yX4jh6kUEgWZQIc(u"ࠬัวๅอࠪ୥"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ัศส฼ࠫ୦"),FF70emVxhWOngCty(u"ࠧฯษ่ืࠬ୧"),pTwKPmzMSZhil5d2RWonre(u"ࠨีสำุ࠭୨"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠩึหอ฿ࠧ୩"),g4UCaNkHvLwGhjmW(u"ࠪฯฬ๋ๆࠨ୪"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫฯอำฺࠩ୫"),tOrSvd8QKNB(u"ࠬ฿วีำࠪ୬")]
lWD8e5HiSXYUbx = DDHwpETQrAm0xMNXGfyhqsUi(u"࠭⸻ࠡ⼟ࠣ⸮ࠥ⹁ࠧ୭")
LN2MtDBowydsCVa64Qe7 = [OTRKI6LbrQnZEm(u"࡚ࠧࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭୮")]
HL39tFDlPerKn5Z6c7BosS8AO = [tg9l25NH6WTacVSifLyAmY(u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ୯"),OOhnpQ8XvCVclGqdu(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬ୰"),FF70emVxhWOngCty(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧୱ"),FF70emVxhWOngCty(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ୲"),tOrSvd8QKNB(u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄࠨ୳"),mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡍࡐࡘࡖ࠸࡚࠭୴"),OOhnpQ8XvCVclGqdu(u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ୵"),mpusoZBJ6V(u"ࠨࡎࡄࡖࡔࡠࡁࠨ୶"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫ୷"),FF70emVxhWOngCty(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ୸"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡆࡒࡁࡓࡃࡅࠫ୹")]
HL39tFDlPerKn5Z6c7BosS8AO += [hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡎࡅࡍࡃࡏࠫ୺"),tg9l25NH6WTacVSifLyAmY(u"࠭ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌࠬ୻"),tOrSvd8QKNB(u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ୼"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࠩ୽"),K7bLVaiRkx0lgU5SQM(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫ୾"),Fg72JX6T5DkPy(u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ୿"),bDt7Ya1VEio3(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭஀"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡖࡁࡏࡇࡗࠫ஁"),FF70emVxhWOngCty(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ஂ"),JJu4MPClbTFpUwHiN(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ஃ")]
w8SKBl6Qj2xk5yEsr0X34UfYmWp7h9 = [O4ylJvVNwLztdiHqBWDU(u"ࠨࡋࡓࡘ࡛࠭஄"),JJu4MPClbTFpUwHiN(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬஅ"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨஆ"),O4ylJvVNwLztdiHqBWDU(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩஇ")]
w8SKBl6Qj2xk5yEsr0X34UfYmWp7h9 += [Xr2aHOK0huQ5DTS(u"ࠬࡓ࠳ࡖࠩஈ"),DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨஉ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫஊ"),tg9l25NH6WTacVSifLyAmY(u"ࠨࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ஋")]
w8SKBl6Qj2xk5yEsr0X34UfYmWp7h9 += [tg9l25NH6WTacVSifLyAmY(u"ࠩࡌࡊࡎࡒࡍࠨ஌"),tg9l25NH6WTacVSifLyAmY(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ஍"),JJu4MPClbTFpUwHiN(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫஎ")]
w8SKBl6Qj2xk5yEsr0X34UfYmWp7h9 += [vZL6j4tSClIGxzNE5DX(u"ࠬࡇࡋࡘࡃࡐࠫஏ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨஐ"),Fg72JX6T5DkPy(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ஑"),mpusoZBJ6V(u"ࠨࡃࡎࡓࡆࡓࠧஒ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫஓ")]
w8SKBl6Qj2xk5yEsr0X34UfYmWp7h9 += [FF70emVxhWOngCty(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ஔ"),pGncXOodjKhJzLSqVP1r(u"ࠫࡇࡕࡋࡓࡃࠪக"),v54ZuLY6dQ(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ஖"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ஗"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ஘"),vZL6j4tSClIGxzNE5DX(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪங")]
rrJ283nstCORiuGgUcxhSAKq = [O4ylJvVNwLztdiHqBWDU(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪச"),g4UCaNkHvLwGhjmW(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱࡛ࡏࡄࡆࡑࡖࠫ஛"),JJu4MPClbTFpUwHiN(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨஜ"),TCF8wLyDvgumfiXPSKRh(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ஝")]
rrJ283nstCORiuGgUcxhSAKq += [WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫஞ"),pTwKPmzMSZhil5d2RWonre(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬட"),bDt7Ya1VEio3(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ஠"),v54ZuLY6dQ(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ஡"),XWbHfI9B8swrOL(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡎࡌ࡚ࡊ࡙ࠧ஢"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡋࡅࡘࡎࡔࡂࡉࡖࠫண")]
RrcfSpUW8N72hBCaMPkLyTQ0 = [aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨத"),g4UCaNkHvLwGhjmW(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ஥"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ஦"),XWbHfI9B8swrOL(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ஧"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ந")]
RrcfSpUW8N72hBCaMPkLyTQ0 += [s0vAWcLSXEToH9Mik134q(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬன"),fk8jc5uDLX16qrih3ZaPxsvO(u"࡙ࠫ࡜ࡆࡖࡐࠪப"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ஫"),s0vAWcLSXEToH9Mik134q(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ஬")]
ANfX3Pb0xTVGJmzI594Z = [WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ஭"),svULcgJ7jm(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪம"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬய"),FF70emVxhWOngCty(u"ࠪࡊࡔ࡙ࡔࡂࠩர"),bDt7Ya1VEio3(u"ࠫࡆࡎࡗࡂࡍࠪற"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ல"),OOhnpQ8XvCVclGqdu(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨள")]
ANfX3Pb0xTVGJmzI594Z += [tg9l25NH6WTacVSifLyAmY(u"ࠧࡔࡊࡒࡊࡍࡇࠧழ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨவ"),mpusoZBJ6V(u"ࠩ࡜ࡅࡖࡕࡔࠨஶ"),XWbHfI9B8swrOL(u"ࠪࡈࡗࡇࡍࡂࡕ࠺ࠫஷ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬஸ"),Fg72JX6T5DkPy(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧஹ"),K7bLVaiRkx0lgU5SQM(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ஺")]
chXsowNAf3g2K71LderDy6Rxt  = [hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡂࡍ࡚ࡅࡒ࠭஻"),svULcgJ7jm(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪ஼"),bDt7Ya1VEio3(u"ࠩࡅࡓࡐࡘࡁࠨ஽"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡅࡐࡕࡁࡎࠩா"),g4UCaNkHvLwGhjmW(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ி"),O4ylJvVNwLztdiHqBWDU(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧீ"),v54ZuLY6dQ(u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧு"),s0vAWcLSXEToH9Mik134q(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩூ")]
chXsowNAf3g2K71LderDy6Rxt += [FF70emVxhWOngCty(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ௃"),K7bLVaiRkx0lgU5SQM(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ௄"),tg9l25NH6WTacVSifLyAmY(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ௅"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࡜ࡋࡃࡊࡏࡄࠫெ"),fk8jc5uDLX16qrih3ZaPxsvO(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩே"),tOrSvd8QKNB(u"࠭ࡆࡐࡕࡗࡅࠬை"),s0vAWcLSXEToH9Mik134q(u"ࠧࡂࡊ࡚ࡅࡐ࠭௉")]
chXsowNAf3g2K71LderDy6Rxt += [vZL6j4tSClIGxzNE5DX(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫொ"),O4ylJvVNwLztdiHqBWDU(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬோ"),O4ylJvVNwLztdiHqBWDU(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬௌ"),g4UCaNkHvLwGhjmW(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷்࠭"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧ௎"),pTwKPmzMSZhil5d2RWonre(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ௏")]
chXsowNAf3g2K71LderDy6Rxt += [O4ylJvVNwLztdiHqBWDU(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨௐ"),OTRKI6LbrQnZEm(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ௑"),pGncXOodjKhJzLSqVP1r(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ௒"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡘ࡛ࡌࡕࡏࠩ௓"),s0vAWcLSXEToH9Mik134q(u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭௔"),TCF8wLyDvgumfiXPSKRh(u"࡙ࠬࡈࡐࡈࡋࡅࠬ௕")]
chXsowNAf3g2K71LderDy6Rxt += [mpusoZBJ6V(u"࠭ࡂࡓࡕࡗࡉࡏ࠭௖"),mpusoZBJ6V(u"࡚ࠧࡃࡔࡓ࡙࠭ௗ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ௘"),K7bLVaiRkx0lgU5SQM(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ௙"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡅࡗࡇࡂࡊࡅࡗࡓࡔࡔࡓࠨ௚"),XWbHfI9B8swrOL(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭௛"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ௜")]
Iiy6K8fcvkwPp  = [aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ௝"),Fg72JX6T5DkPy(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ௞"),bDt7Ya1VEio3(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ௟"),K7bLVaiRkx0lgU5SQM(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭௠"),tOrSvd8QKNB(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡊࡄࡗࡍ࡚ࡁࡈࡕࠪ௡")]
Iiy6K8fcvkwPp += [pGncXOodjKhJzLSqVP1r(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ௢"),tg9l25NH6WTacVSifLyAmY(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ௣")]
Iiy6K8fcvkwPp += [vZL6j4tSClIGxzNE5DX(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ௤"),v54ZuLY6dQ(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ௥"),OTRKI6LbrQnZEm(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ௦")]
Iiy6K8fcvkwPp += [QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ௧"),pGncXOodjKhJzLSqVP1r(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ௨"),vZL6j4tSClIGxzNE5DX(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ௩")]
Iiy6K8fcvkwPp += [aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ௪"),vZL6j4tSClIGxzNE5DX(u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ௫"),OOhnpQ8XvCVclGqdu(u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ௬")]
Iaqplwi0ZHcUukPDJR = [OTRKI6LbrQnZEm(u"ࠨࡏ࠶࡙ࠬ௭"),pGncXOodjKhJzLSqVP1r(u"ࠩࡌࡔ࡙࡜ࠧ௮"),O4ylJvVNwLztdiHqBWDU(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ௯"),TCF8wLyDvgumfiXPSKRh(u"ࠫࡎࡌࡉࡍࡏࠪ௰"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭௱")]
FF2QXkGONJavimRyheSC4s5 = chXsowNAf3g2K71LderDy6Rxt+Iiy6K8fcvkwPp
zfE9YjC6MTa8 = chXsowNAf3g2K71LderDy6Rxt+Iaqplwi0ZHcUukPDJR
uuHQdnTvybc9oEzaq81BLNFMhm = chXsowNAf3g2K71LderDy6Rxt+Iiy6K8fcvkwPp
gc5QSV42Ev8eG = w8SKBl6Qj2xk5yEsr0X34UfYmWp7h9+RrcfSpUW8N72hBCaMPkLyTQ0+ANfX3Pb0xTVGJmzI594Z+rrJ283nstCORiuGgUcxhSAKq
mB9ZMXEe6rJ1yicGOdAWL8Q = [
						OTRKI6LbrQnZEm(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ௲")
						,O4ylJvVNwLztdiHqBWDU(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩ௳")
						,O4ylJvVNwLztdiHqBWDU(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩ௴")
						]
bbaZdrlivfI6 = [
						TCF8wLyDvgumfiXPSKRh(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖ࠰࠵ࡸࡺࠧ௵")
						,OOhnpQ8XvCVclGqdu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧ௶")
						,pTwKPmzMSZhil5d2RWonre(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬ௷")
						,g4UCaNkHvLwGhjmW(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭௸")
						,OTRKI6LbrQnZEm(u"࠭ࡉࡑࡖ࡙࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨ௹")
						,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ௺")
						,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬ௻")
						,tOrSvd8QKNB(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭௼")
						,y5yX4jh6kUEgWZQIc(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ௽")
						,OTRKI6LbrQnZEm(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨ௾")
						,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬ௿")
						,mpusoZBJ6V(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠸ࡸ࡭࠭ఀ")
						,Xr2aHOK0huQ5DTS(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ఁ")
						,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪం")
						,K7bLVaiRkx0lgU5SQM(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠳ࡰࡧࠫః")
						]
AhnoyUqMCdFs1ijNKeQJuOrH = bbaZdrlivfI6+[
				 g4UCaNkHvLwGhjmW(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡕࡘࡏ࡙࡛ࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬఄ")
				,s0vAWcLSXEToH9Mik134q(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡈࡕࡖࡓࡗࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩఅ")
				,y5yX4jh6kUEgWZQIc(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨఆ")
				,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠸࡮ࡥࠩఇ")
				,bDt7Ya1VEio3(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠱ࡴࡶࠪఈ")
				,v54ZuLY6dQ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠳ࡰࡧࠫఉ")
				,mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠲ࡵࡷࠫఊ")
				,tOrSvd8QKNB(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠴ࡱࡨࠬఋ")
				,mpusoZBJ6V(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠶ࡶࡩ࠭ఌ")
				,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡃࡉࡇࡆࡏࡤࡎࡔࡕࡒࡖࡣࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ఍")
				,mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩఎ")
				,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠱ࡴࡶࠪఏ")
				,vZL6j4tSClIGxzNE5DX(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠳ࡰࡧࠫఐ")
				,JJu4MPClbTFpUwHiN(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡚࡙ࡁࡈࡇࡢࡖࡊࡖࡏࡓࡖ࠰࠵ࡸࡺࠧ఑")
				,TCF8wLyDvgumfiXPSKRh(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫఒ")
				,svULcgJ7jm(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ఓ")
				]
ye5VdS961JgscKZjAp0HXnT = [v54ZuLY6dQ(u"ࠬ࠾࠮࠹࠰࠻࠲࠽࠭ఔ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭࠱࠯࠳࠱࠵࠳࠷ࠧక"),Fg72JX6T5DkPy(u"ࠧ࠲࠰࠳࠲࠵࠴࠱ࠨఖ"),v54ZuLY6dQ(u"ࠨ࠺࠱࠼࠳࠺࠮࠵ࠩగ"),OTRKI6LbrQnZEm(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠷࠴࠲࠳࠴ࠪఘ"),pTwKPmzMSZhil5d2RWonre(u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠶࠮࠳࠴࠳ࠫఙ")]
OQv0iWIw5bFRATU2mxJjZK = {
			 OOhnpQ8XvCVclGqdu(u"ࠫࡆࡑࡏࡂࡏࠪచ")		:[O4ylJvVNwLztdiHqBWDU(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺ࠴ࡵ࡬ࡥࠩఛ")]
			,XWbHfI9B8swrOL(u"࠭ࡁࡉ࡙ࡄࡏࠬజ")		:[OOhnpQ8XvCVclGqdu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡦ࡮ࡷࡢ࡭ࡷࡺ࠳ࡴࡥࡵࠩఝ")]
			,tOrSvd8QKNB(u"ࠨࡃࡎ࡛ࡆࡓࠧఞ")		:[DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰ࠴ࡳࡷࠩట")]
			,Fg72JX6T5DkPy(u"ࠪࡅࡑࡇࡒࡂࡄࠪఠ")		:[mpusoZBJ6V(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼ࡯ࡥ࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠭డ")]
			,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧఢ")		:[OOhnpQ8XvCVclGqdu(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭ࡨࡤࡸ࡮ࡳࡩ࠯ࡶࡹࠫణ")]
			,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩత")		:[FF70emVxhWOngCty(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡰࡲࡧࡡࡳࡧࡩ࠲ࡨ࡮ࠧథ")]
			,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧద")	:[JJu4MPClbTFpUwHiN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯ࠪధ")]
			,bDt7Ya1VEio3(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭న")		:[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡣࡥࡷࡪ࡫ࡤ࠯ࡰࡨࡸࠬ఩")]
			,g4UCaNkHvLwGhjmW(u"࠭ࡂࡐࡍࡕࡅࠬప")		:[mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡼ࡯ࡥ࠰ࡦࡳࡲ࠭ఫ")]
			,tOrSvd8QKNB(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨబ")		:[pGncXOodjKhJzLSqVP1r(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡷࡹࡴࡦ࡬࠱ࡧࡴࡳࠧభ")]
			,O4ylJvVNwLztdiHqBWDU(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫమ")		:[DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠷࠴࠵࠴ࡣࡰ࡯ࠪయ")]
			,O4ylJvVNwLztdiHqBWDU(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬర")		:[JJu4MPClbTFpUwHiN(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠲ࡥ࡬ࡱࡦ࠺ࡵ࠯ࡥࡲࡱࠬఱ")]
			,v54ZuLY6dQ(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩల")		:[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠳ࡣࡦࡲ࠲ࡨࡵ࡭ࠨళ")]
			,v54ZuLY6dQ(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫఴ")		:[TCF8wLyDvgumfiXPSKRh(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠴ࡷࡢࡶࡦ࡬ࠬవ")]
			,XWbHfI9B8swrOL(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪశ")	:[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡷࡸ࠱ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡹࡨࡰࡲࠪష")]
			,K7bLVaiRkx0lgU5SQM(u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨస")		:[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫహ")]
			,K7bLVaiRkx0lgU5SQM(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ఺")	:[bDt7Ya1VEio3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠽࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸ࠴ࡳࡹࡤ࠳ࠪ఻")]
			,K7bLVaiRkx0lgU5SQM(u"ࠪࡇࡎࡓࡁࡏࡑ఼࡚ࠫ")		:[v54ZuLY6dQ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡱࡳࡼ࠴ࡣࡤࠩఽ")]
			,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪా")	:[mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭ి"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨీ")]
			,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩు")		:[Xr2aHOK0huQ5DTS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡨ࠴ࡤࡳࡣࡰࡥࡸ࠽࠮ࡤࡱࡰࠫూ")]
			,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬృ")		:[JJu4MPClbTFpUwHiN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡦࡶࡰࠪౄ")]
			,JJu4MPClbTFpUwHiN(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ౅")		:[K7bLVaiRkx0lgU5SQM(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡹࡨࡦࡨࡧ࡭ࠨె")]
			,tOrSvd8QKNB(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩే")		:[JJu4MPClbTFpUwHiN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨై")]
			,FF70emVxhWOngCty(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ౉")		:[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪొ")]
			,mpusoZBJ6V(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬో")		:[mpusoZBJ6V(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬౌ")]
			,v54ZuLY6dQ(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ్")		:[K7bLVaiRkx0lgU5SQM(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧ౎")]
			,OTRKI6LbrQnZEm(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ౏")		:[svULcgJ7jm(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧ౐")]
			,bDt7Ya1VEio3(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭౑")	:[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩ౒")]
			,mpusoZBJ6V(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ౓")		:[TCF8wLyDvgumfiXPSKRh(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨࡸ࠴ࡣࡢࡴࡨࠫ౔")]
			,OTRKI6LbrQnZEm(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ౕࠩ")		:[vZL6j4tSClIGxzNE5DX(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪౖࠧ")]
			,FF70emVxhWOngCty(u"ࠩࡉࡓࡘ࡚ࡁࠨ౗")		:[tg9l25NH6WTacVSifLyAmY(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧౘ")]
			,vZL6j4tSClIGxzNE5DX(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ౙ")		:[s0vAWcLSXEToH9Mik134q(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯࡯ࡨࡨ࡮ࡧࠧౚ")]
			,mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡉࡇࡋࡏࡑࠬ౛")		:[aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ౜"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩౝ"),JJu4MPClbTFpUwHiN(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ౞"),pTwKPmzMSZhil5d2RWonre(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ౟"),OOhnpQ8XvCVclGqdu(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫౠ")]
			,tOrSvd8QKNB(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨౡ")	:[tOrSvd8QKNB(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧౢ")]
			,g4UCaNkHvLwGhjmW(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩౣ")		:[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪࡳࡴ࠴࡫ࡪࡶ࡮ࡳࡹ࠴ࡴࡷࠩ౤")]
			,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ౥")	:[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ౦"),s0vAWcLSXEToH9Mik134q(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾࠮ࡧࡹࡶ࠲ࡸࡺ࡯ࡳࡧࠪ౧")]
			,JJu4MPClbTFpUwHiN(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭౨")		:[svULcgJ7jm(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭౩")]
			,Xr2aHOK0huQ5DTS(u"ࠧࡑࡃࡑࡉ࡙࠭౪")		:[v54ZuLY6dQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ౫")]
			,pTwKPmzMSZhil5d2RWonre(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ౬")		:[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡶࡪࡲ࠱ࡧࡦࡳࠧ౭")]
			,OOhnpQ8XvCVclGqdu(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ౮")	:[XWbHfI9B8swrOL(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫ౯")]
			,svULcgJ7jm(u"࠭ࡓࡉࡑࡉࡌࡆ࠭౰")		:[Xr2aHOK0huQ5DTS(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨ࠳ࡹࡨࡰࡨ࡫ࡥ࠳ࡺࡶࠨ౱")]
			,JJu4MPClbTFpUwHiN(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ౲")		:[FF70emVxhWOngCty(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ౳"),s0vAWcLSXEToH9Mik134q(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ౴"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ౵")]
			,DD7NjwespWyQJ4E6mXk0ZAufPg(u"࡚ࠬࡖࡇࡗࡑࠫ౶")		:[mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫ౷")]
			,vZL6j4tSClIGxzNE5DX(u"ࠧࡘࡇࡆࡍࡒࡇࠧ౸")		:[v54ZuLY6dQ(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡻࡲ࠲࠳࠭࠮࠯࠰ࡲࡿ࡫ࡢࡤࡣ࠸࡫ࡩ࠽࡯ࡥࡧ࠳ࡦ࡮࡭࡬ࡩ࠰ࡰࡽࡨ࡯ࡩ࡮ࡣ࠰ࡻࡪࡩࡩࡪ࡯ࡤ࠲ࡸ࡮࡯ࡱࠩ౹")]
			,tg9l25NH6WTacVSifLyAmY(u"ࠩ࡜ࡅࡖࡕࡔࠨ౺")		:[OOhnpQ8XvCVclGqdu(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ౻")]
			,pGncXOodjKhJzLSqVP1r(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ౼")		:[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ౽")]
			,vZL6j4tSClIGxzNE5DX(u"࠭ࡒࡆࡒࡒࡗࠬ౾")		:[tg9l25NH6WTacVSifLyAmY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ౿"),svULcgJ7jm(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬಀ"),O4ylJvVNwLztdiHqBWDU(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ಁ")]
			,pTwKPmzMSZhil5d2RWonre(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭ಂ")	:[Fg72JX6T5DkPy(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩಃ"),Xr2aHOK0huQ5DTS(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ಄"),tg9l25NH6WTacVSifLyAmY(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨಅ")]
			,g4UCaNkHvLwGhjmW(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨಆ")		:[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡯ࡴࡪࡩࠨಇ"),Xr2aHOK0huQ5DTS(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮ࠧಈ"),XWbHfI9B8swrOL(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠭ಉ")]
			}
if nfC2im3NzUQk:
	OQv0iWIw5bFRATU2mxJjZK[tg9l25NH6WTacVSifLyAmY(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫಊ")] = [QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧಋ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫಌ"),Fg72JX6T5DkPy(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ಍"),y5yX4jh6kUEgWZQIc(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ಎ"),s0vAWcLSXEToH9Mik134q(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ಏ"),v54ZuLY6dQ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩಐ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ಑"),vZL6j4tSClIGxzNE5DX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ಒ"),DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧಓ"),XWbHfI9B8swrOL(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬಔ")]
	OQv0iWIw5bFRATU2mxJjZK[aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬಕ")] = [bDt7Ya1VEio3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬಖ"),y5yX4jh6kUEgWZQIc(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩಗ"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨಘ"),g4UCaNkHvLwGhjmW(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫಙ"),svULcgJ7jm(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫಚ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧಛ"),TCF8wLyDvgumfiXPSKRh(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪಜ"),mpusoZBJ6V(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫಝ"),K7bLVaiRkx0lgU5SQM(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬಞ"),y5yX4jh6kUEgWZQIc(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪಟ")]
else:
	OQv0iWIw5bFRATU2mxJjZK[XWbHfI9B8swrOL(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬಠ")] = [y5yX4jh6kUEgWZQIc(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩಡ"),O4ylJvVNwLztdiHqBWDU(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭ಢ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬಣ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨತ"),svULcgJ7jm(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨಥ"),mpusoZBJ6V(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫದ"),TCF8wLyDvgumfiXPSKRh(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧಧ"),y5yX4jh6kUEgWZQIc(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨನ"),Fg72JX6T5DkPy(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ಩"),bDt7Ya1VEio3(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧಪ")]
	OQv0iWIw5bFRATU2mxJjZK[vZL6j4tSClIGxzNE5DX(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭ಫ")] = [DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ಬ"),TCF8wLyDvgumfiXPSKRh(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪಭ"),FF70emVxhWOngCty(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩಮ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬಯ"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬರ"),v54ZuLY6dQ(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨಱ"),y5yX4jh6kUEgWZQIc(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫಲ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬಳ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭಴"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫವ")]
CCT0MdYxkDalqAE = [QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨಶ"),JJu4MPClbTFpUwHiN(u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨಷ"),pTwKPmzMSZhil5d2RWonre(u"ࠨࡇࡐࡅࡎࡒࡓࠨಸ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫಹ"),vZL6j4tSClIGxzNE5DX(u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬ಺"),mpusoZBJ6V(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ಻"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕ಼ࠪ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧಽ"),vZL6j4tSClIGxzNE5DX(u"ࠧࡕࡇࡖࡘࡎࡔࡇࠨಾ"),pGncXOodjKhJzLSqVP1r(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪಿ")]
BBCVh2mFqLjNZ5p6tfA1JPeS = [O4ylJvVNwLztdiHqBWDU(u"ࠩࡄࡈࡉࡕࡎࡔࠩೀ"),vZL6j4tSClIGxzNE5DX(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬು"),OTRKI6LbrQnZEm(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭ೂ")]
class hNBzF7rYvtewoASZupJQV86qnH(Roa4WbzDQZ95UPFSwkBsujAMgLtpX2):
	def __init__(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,*aargs,**kkwargs):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.choiceID = -nfC2im3NzUQk
	def onClick(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,SNubWz1avXZcOgBxsDKwy):
		if SNubWz1avXZcOgBxsDKwy>=aqUlAdFto05NmG4Y6guEzTr8vK(u"࠼࠴࠶࠶቎"): WnaR8GmjVCwcob6tNeJQ3TS1XL9U.choiceID = SNubWz1avXZcOgBxsDKwy-aqUlAdFto05NmG4Y6guEzTr8vK(u"࠼࠴࠶࠶቎")
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.f4zmtJZbCrOFKc3Y1W8Ld06GwAes()
	def rPtOwMYezvn5dh6Qj2J9ysT(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,*aargs):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button0,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button1,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button2 = aargs[h17Zb2ld4yLBrCP5tiw],aargs[nfC2im3NzUQk],aargs[JxuTQLOD357o41evylqPmRdf]
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.header,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.text = aargs[mVjHAyIwzSNKLFcd],aargs[bWU9StnJOg6aIQiTMxh7sFZG8lPud]
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.profile,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.direction = aargs[mpusoZBJ6V(u"࠹቏")],aargs[O4ylJvVNwLztdiHqBWDU(u"࠻ቐ")]
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.buttonstimeout,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.closetimeout = aargs[K7bLVaiRkx0lgU5SQM(u"࠷ቒ")],aargs[vZL6j4tSClIGxzNE5DX(u"࠾ቑ")]
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.buttonstimeout>h17Zb2ld4yLBrCP5tiw or WnaR8GmjVCwcob6tNeJQ3TS1XL9U.closetimeout>OOhnpQ8XvCVclGqdu(u"࠱ቓ"): WnaR8GmjVCwcob6tNeJQ3TS1XL9U.enable_progressbar = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		else: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.enable_progressbar = YoAMfqm37GyFxbuKTt6e8CESHrhB
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename = gCdTSQXzi4ua5AG6rO1YpnV.replace(FF70emVxhWOngCty(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬೃ"),Xr2aHOK0huQ5DTS(u"࠭࡟ࠨೄ")+str(B3TKLo71hAGRqYgV0.time())+TCF8wLyDvgumfiXPSKRh(u"ࠧࡠࠩ೅"))
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename = WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename.replace(FF70emVxhWOngCty(u"ࠨ࡞࡟ࠫೆ"),Xr2aHOK0huQ5DTS(u"ࠩ࡟ࡠࡡࡢࠧೇ")).replace(g4UCaNkHvLwGhjmW(u"ࠪ࠳࠴࠭ೈ"),FF70emVxhWOngCty(u"ࠫ࠴࠵࠯࠰ࠩ೉"))
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_height = SYUGgKyAwVTOQs9nuxR04(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button0,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button1,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button2,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.header,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.text,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.profile,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.direction,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.enable_progressbar,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename)
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.show()
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠻࠳࠹࠵ቔ")).setImage(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename)
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(fk8jc5uDLX16qrih3ZaPxsvO(u"࠼࠴࠺࠶ቕ")).setHeight(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_height)
		if not WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button1 and WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button0 and WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button2: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠾࠶࠱࠳቗")).setPosition(-XWbHfI9B8swrOL(u"࠸࠲࠱ቘ"),K7bLVaiRkx0lgU5SQM(u"࠴ቖ"))
		return WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_height
	def z5wPiM7Fo2aVn3NgcUBl8ktyLhO4C(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.buttonstimeout:
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.th1 = VVGXMeyJq25S6tf.Thread(target=WnaR8GmjVCwcob6tNeJQ3TS1XL9U.OpfkPLMRmE6HZuain,args=())
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.th1.start()
		else: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.SWQws1lJtbGUzY6oeHATav7()
	def OpfkPLMRmE6HZuain(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(JJu4MPClbTFpUwHiN(u"࠹࠱࠴࠳቙")).setEnabled(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		for GzabfJx3T1 in range(nfC2im3NzUQk,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.buttonstimeout+nfC2im3NzUQk):
			B3TKLo71hAGRqYgV0.sleep(nfC2im3NzUQk)
			jnCdOaEJFtx504z2 = int(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠲࠲࠳ቚ")*GzabfJx3T1/WnaR8GmjVCwcob6tNeJQ3TS1XL9U.buttonstimeout)
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.grmJqQMKyjn1lks0dHpWtvwu82eZf(jnCdOaEJFtx504z2)
			if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.choiceID>pGncXOodjKhJzLSqVP1r(u"࠲ቛ"): break
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.SWQws1lJtbGUzY6oeHATav7()
	def LCKmuseZ7MEljVHG(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.closetimeout:
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.th2 = VVGXMeyJq25S6tf.Thread(target=WnaR8GmjVCwcob6tNeJQ3TS1XL9U.OIM2DAfqWhBC5yvtazn,args=())
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.th2.start()
		else: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.SWQws1lJtbGUzY6oeHATav7()
	def OIM2DAfqWhBC5yvtazn(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(tOrSvd8QKNB(u"࠼࠴࠷࠶ቜ")).setEnabled(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		B3TKLo71hAGRqYgV0.sleep(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.buttonstimeout)
		for GzabfJx3T1 in range(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.closetimeout-nfC2im3NzUQk,-nfC2im3NzUQk,-nfC2im3NzUQk):
			B3TKLo71hAGRqYgV0.sleep(nfC2im3NzUQk)
			jnCdOaEJFtx504z2 = int(s0vAWcLSXEToH9Mik134q(u"࠵࠵࠶ቝ")*GzabfJx3T1/WnaR8GmjVCwcob6tNeJQ3TS1XL9U.closetimeout)
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.grmJqQMKyjn1lks0dHpWtvwu82eZf(jnCdOaEJFtx504z2)
			if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.choiceID>h17Zb2ld4yLBrCP5tiw: break
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.closetimeout>h17Zb2ld4yLBrCP5tiw: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.choiceID = svULcgJ7jm(u"࠶࠶቞")
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.f4zmtJZbCrOFKc3Y1W8Ld06GwAes()
	def grmJqQMKyjn1lks0dHpWtvwu82eZf(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,jnCdOaEJFtx504z2):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.precent = jnCdOaEJFtx504z2
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠿࠰࠳࠲቟")).setPercent(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.precent)
	def SWQws1lJtbGUzY6oeHATav7(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button0: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠹࠱࠳࠳በ")).setEnabled(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button1: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(fk8jc5uDLX16qrih3ZaPxsvO(u"࠺࠲࠴࠵ቡ")).setEnabled(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.button2: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.getControl(mmKqLr9RX0ACN384JMcsFHzd(u"࠻࠳࠵࠷ቢ")).setEnabled(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	def f4zmtJZbCrOFKc3Y1W8Ld06GwAes(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.close()
		try: KiTt9ZskMLjnCAUIJNXD7.remove(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.image_filename)
		except: pass
class UZ28903VuMoInShOjv4zpYDFxliy():
	def __init__(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,showDialogs=YoAMfqm37GyFxbuKTt6e8CESHrhB,logErrors=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.showDialogs = showDialogs
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.logErrors = logErrors
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.finishedLIST,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.failedLIST = [],[]
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.statusDICT,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.resultsDICT = {},{}
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.processesLIST = []
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.starttimeDICT,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.finishtimeDICT,WnaR8GmjVCwcob6tNeJQ3TS1XL9U.elpasedtimeDICT = {},{},{}
	def pptBuEexdPhR9U1qwmToGV(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,jfRgOv7BWL9T8y,SKNZlHkIOiWz4,*aargs):
		jfRgOv7BWL9T8y = str(jfRgOv7BWL9T8y)
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.statusDICT[jfRgOv7BWL9T8y] = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭ೊ")
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.showDialogs: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(QigevCplXxbPI1H,jfRgOv7BWL9T8y)
		njhv9Z1ba8lVTGrSO6QkHA7dpLDm = VVGXMeyJq25S6tf.Thread(target=WnaR8GmjVCwcob6tNeJQ3TS1XL9U.fF3h01M2Ia,args=(jfRgOv7BWL9T8y,SKNZlHkIOiWz4,aargs))
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.processesLIST.append(njhv9Z1ba8lVTGrSO6QkHA7dpLDm)
		return njhv9Z1ba8lVTGrSO6QkHA7dpLDm
	def jxT7SROozva0I9(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,jfRgOv7BWL9T8y,SKNZlHkIOiWz4,*aargs):
		njhv9Z1ba8lVTGrSO6QkHA7dpLDm = WnaR8GmjVCwcob6tNeJQ3TS1XL9U.pptBuEexdPhR9U1qwmToGV(jfRgOv7BWL9T8y,SKNZlHkIOiWz4,*aargs)
		njhv9Z1ba8lVTGrSO6QkHA7dpLDm.start()
	def fF3h01M2Ia(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,jfRgOv7BWL9T8y,SKNZlHkIOiWz4,aargs):
		jfRgOv7BWL9T8y = str(jfRgOv7BWL9T8y)
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.starttimeDICT[jfRgOv7BWL9T8y] = B3TKLo71hAGRqYgV0.time()
		try:
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.resultsDICT[jfRgOv7BWL9T8y] = SKNZlHkIOiWz4(*aargs)
			if O4ylJvVNwLztdiHqBWDU(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧೋ") in str(SKNZlHkIOiWz4) and not WnaR8GmjVCwcob6tNeJQ3TS1XL9U.resultsDICT[jfRgOv7BWL9T8y].succeeded: ksV5ngvbcaS8ByMLYxlfXh()
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.finishedLIST.append(jfRgOv7BWL9T8y)
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.statusDICT[jfRgOv7BWL9T8y] = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩೌ")
		except Exception as HqIej1PzSpAEWZ8Y7buc:
			if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.logErrors:
				THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
				if THFfWLwt62MmUz!=bDt7Ya1VEio3(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱ್ࠫ"): KXhrv29CGR8QTDzJIWLY.stderr.write(THFfWLwt62MmUz)
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.failedLIST.append(jfRgOv7BWL9T8y)
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.statusDICT[jfRgOv7BWL9T8y] = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ೎")
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.finishtimeDICT[jfRgOv7BWL9T8y] = B3TKLo71hAGRqYgV0.time()
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.elpasedtimeDICT[jfRgOv7BWL9T8y] = WnaR8GmjVCwcob6tNeJQ3TS1XL9U.finishtimeDICT[jfRgOv7BWL9T8y] - WnaR8GmjVCwcob6tNeJQ3TS1XL9U.starttimeDICT[jfRgOv7BWL9T8y]
	def St3qKZg4fy(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		for WPR2Odv7lzr in WnaR8GmjVCwcob6tNeJQ3TS1XL9U.processesLIST:
			WPR2Odv7lzr.start()
	def TFq7x2bg1B4AD5aY0eVNrRI8niQ(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		while mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫ೏") in list(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.statusDICT.values()): B3TKLo71hAGRqYgV0.sleep(y5yX4jh6kUEgWZQIc(u"࠴ባ"))
def uOj2WFd75mCqEZInitvbpVw():
	if not enGPuSCj3A2R: return vZL6j4tSClIGxzNE5DX(u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧ೐")
	try: KiTt9ZskMLjnCAUIJNXD7.makedirs(nZ5AkguavpEc7zWo8SOHRD)
	except: pass
	d1dmuBvpigSD8VxHJORFy7nZQLXYo = g4UCaNkHvLwGhjmW(u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ೑")
	tBmezRwUQAKGj0 = [JJu4MPClbTFpUwHiN(u"࠭࠸࠯࠷࠱࠴ࠬ೒"),v54ZuLY6dQ(u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫ೓"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭೔"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭ೕ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧೖ"),y5yX4jh6kUEgWZQIc(u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨ೗"),vZL6j4tSClIGxzNE5DX(u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩ೘"),tOrSvd8QKNB(u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪ೙"),tOrSvd8QKNB(u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫ೚"),mpusoZBJ6V(u"ࠨ࠴࠳࠶࠸࠴࠱࠱࠰࠵࠼ࠬ೛"),svULcgJ7jm(u"ࠩ࠵࠴࠷࠺࠮࠱࠳࠱࠵࠹࠭೜"),y5yX4jh6kUEgWZQIc(u"ࠪ࠶࠵࠸࠴࠯࠲࠺࠲࠷࠶ࠧೝ")]
	oLmkVepb7Mjwf4iStcqd = tBmezRwUQAKGj0[-nfC2im3NzUQk]
	CCqg0mhiBX2wfuUnrI = Kc4bRz3g5WTV(oLmkVepb7Mjwf4iStcqd)
	ccQuEiWltvaUhfRL3K = Kc4bRz3g5WTV(GVmdqbtLu8lUXNxp13aHOvkscR)
	if ccQuEiWltvaUhfRL3K>CCqg0mhiBX2wfuUnrI:
		d1dmuBvpigSD8VxHJORFy7nZQLXYo = s0vAWcLSXEToH9Mik134q(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫೞ")
	return d1dmuBvpigSD8VxHJORFy7nZQLXYo
def LcgOjtmynC1HepZ4XSoEz8FMq0dw():
	if nfC2im3NzUQk:
		Z5d8jihHUEeDNg1aPFuRtw = h17Zb2ld4yLBrCP5tiw
		for dSZirVLRbpCDn3NUxtz,xGpYfljiqaH4TQo7DPzkR3AmNESU,ad6U8LEqbwI9t7PhKOkJBusX4en in KiTt9ZskMLjnCAUIJNXD7.walk(UE7QOpJtiYsfF8bTd4vVowZ,topdown=YoAMfqm37GyFxbuKTt6e8CESHrhB):
			Z5d8jihHUEeDNg1aPFuRtw += len(ad6U8LEqbwI9t7PhKOkJBusX4en)
	if Z5d8jihHUEeDNg1aPFuRtw>hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠵࠵࠶࠰࠱ቤ"): eB8jr3L1inmU6OzINJd(UE7QOpJtiYsfF8bTd4vVowZ,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	return
ior2buCJ0nlghKd7RFcHfp = YoAMfqm37GyFxbuKTt6e8CESHrhB
def e9UIQ7WhX4FViaptmR3(aeRHmPISMkDNA2vd7F6gzpB9C):
	global OQv0iWIw5bFRATU2mxJjZK,ior2buCJ0nlghKd7RFcHfp
	if not aeRHmPISMkDNA2vd7F6gzpB9C:
		fFpVQCR6xei = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,Fg72JX6T5DkPy(u"ࠬࡪࡩࡤࡶࠪ೟"),g4UCaNkHvLwGhjmW(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩೠ"),tOrSvd8QKNB(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕࠪೡ"))
		if fFpVQCR6xei:
			OQv0iWIw5bFRATU2mxJjZK = fFpVQCR6xei.copy()
			return
	if not ior2buCJ0nlghKd7RFcHfp:
		iCr0xsqwDZXLPaJK1W5YU24F6hp = OQv0iWIw5bFRATU2mxJjZK[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨೢ")][XWbHfI9B8swrOL(u"࠾ብ")]
		PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(Fg72JX6T5DkPy(u"࠹࠲ቦ"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		AlZkSOdj4PzhXQv = {Xr2aHOK0huQ5DTS(u"ࠩࡸࡷࡪࡸࠧೣ"):PXVdZQYTNslvg7wF0159Akr,mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫ೤"):GVmdqbtLu8lUXNxp13aHOvkscR}
		lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡕࡕࡓࡕࠩ೥"),iCr0xsqwDZXLPaJK1W5YU24F6hp,AlZkSOdj4PzhXQv,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡤࡖ࡙ࡕࡊࡒࡒࡤࡉࡏࡅࡇ࠰࠵ࡸࡺࠧ೦"))
		if lE7ZB0CTayhKItApFnYxz.succeeded:
			global NEW_SITESURLS
			exec(lE7ZB0CTayhKItApFnYxz.content,globals(),locals())
			OQv0iWIw5bFRATU2mxJjZK.update(NEW_SITESURLS)
			BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ೧"),g4UCaNkHvLwGhjmW(u"ࠧࡔࡋࡗࡉࡘ࡛ࡒࡍࡕࠪ೨"),OQv0iWIw5bFRATU2mxJjZK,xfdjCmFwb0k8JAVegiL)
			ior2buCJ0nlghKd7RFcHfp = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	return
def Gk8DKbQ2InVy7ipeL4S1XFgmAqOT():
	ikIbAalF5Wcd0g3q9Khot = uOj2WFd75mCqEZInitvbpVw()
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ೩"),Xr2aHOK0huQ5DTS(u"ࠩอ้ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦแ๋ࠢฯ๋ฬุใ࡝ࡰศ่๎ࠦวๅวุำฬืࠠาไ่࠾ࡡࡴ࡜࡯ࠩ೪")+GVmdqbtLu8lUXNxp13aHOvkscR)
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,TCF8wLyDvgumfiXPSKRh(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭೫"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ೬"))
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ೭"),bDt7Ya1VEio3(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ೮"))
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,vZL6j4tSClIGxzNE5DX(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ೯"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭೰"))
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬೱ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨೲ"))
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧೳ"),bDt7Ya1VEio3(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫ೴"))
	uUTRHgAXJzm7pIDBjNt8.setSetting(tOrSvd8QKNB(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭೵"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(K7bLVaiRkx0lgU5SQM(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡦࡷࡧ࡫ࡢࠩ೶"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(O4ylJvVNwLztdiHqBWDU(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ೷"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(tOrSvd8QKNB(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ೸"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(JJu4MPClbTFpUwHiN(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭೹"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(OOhnpQ8XvCVclGqdu(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧ೺"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ೻"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(vZL6j4tSClIGxzNE5DX(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ೼"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(JJu4MPClbTFpUwHiN(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧ೽"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(OTRKI6LbrQnZEm(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ೾"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(XWbHfI9B8swrOL(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ೿"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(OOhnpQ8XvCVclGqdu(u"ࠪࡥࡻ࠴ࡳࡤࡣࡵࡴࡪࡸࡳ࠯ࡨࡤ࡭ࡱࡻࡲࡦࡵࡦࡳࡺࡴࡴࡴࠩഀ"),QigevCplXxbPI1H)
	uUTRHgAXJzm7pIDBjNt8.setSetting(tOrSvd8QKNB(u"ࠫࡦࡼ࠮ࡴࡥࡤࡶࡵ࡫ࡲࡴ࠰࡯ࡥࡸࡺࡦࡢ࡫࡯ࡹࡷ࡫ࡳࡵ࡫ࡰࡩࡸ࠭ഁ"),QigevCplXxbPI1H)
	import WZPsXYo7QE
	if ikIbAalF5Wcd0g3q9Khot==XWbHfI9B8swrOL(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬം"):
		SQdRhwozVfv(AwKhgdpmBj0,XWbHfI9B8swrOL(u"࠭࠮࡝ࡶࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡕࡌࡑࡕࡒࡅࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬഃ")+MYIqLm4Nyhniu6QORWlrp+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࠡ࡟ࠪഄ"))
		P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩഅ"))
		P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,svULcgJ7jm(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࠩആ"))
		P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩഇ"))
		oYAuTVpsaSfg(XpREPf7d08GnIS6i4KNLMyZHmuQqxD,[qH5vZR0MhF97zt4PULV])
	else:
		SQdRhwozVfv(AwKhgdpmBj0,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨഈ")+MYIqLm4Nyhniu6QORWlrp+tg9l25NH6WTacVSifLyAmY(u"ࠬࠦ࡝ࠨഉ"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩഊ"),O4ylJvVNwLztdiHqBWDU(u"ࠧห็ࠣฮะฮ๊หࠢฦ์ࠥะอะ์ฮࠤฬ๊ลึัสีࠥอไอัํำ๊ࠥศา่ส้ัࠦวๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠤ࠳ࠦร้ࠢอ้๋ࠥำฮࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡ࡞ࡱࡠࡳࠦำ๋ไ๋้ࠥอไร่ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪഋ"))
		oYAuTVpsaSfg(YoAMfqm37GyFxbuKTt6e8CESHrhB,[])
		MfFlidaIObTrEBK08eg(YoAMfqm37GyFxbuKTt6e8CESHrhB)
		WZPsXYo7QE.ITJQ4ncG6jVXhgvyP29Y1()
		WZPsXYo7QE.UU8FkvnySO(Xr2aHOK0huQ5DTS(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨഌ"),YoAMfqm37GyFxbuKTt6e8CESHrhB)
		WZPsXYo7QE.UU8FkvnySO(FF70emVxhWOngCty(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ഍"),YoAMfqm37GyFxbuKTt6e8CESHrhB)
		WZPsXYo7QE.kkEM4GJSYRp(YoAMfqm37GyFxbuKTt6e8CESHrhB)
		WZPsXYo7QE.bqQv1mSPE2w0poVrxIKigNeTkL(YoAMfqm37GyFxbuKTt6e8CESHrhB)
		WZPsXYo7QE.UUSQjR8qivYPgbkOlAEhadcr(FF70emVxhWOngCty(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨഎ"),svULcgJ7jm(u"ࠫࡪࡴࡡࡣ࡮ࡨࠫഏ"),YoAMfqm37GyFxbuKTt6e8CESHrhB)
		try:
			Qt3P7kYhKvfdHp1ZOWXTBxA5suai8w = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧഐ"),vZL6j4tSClIGxzNE5DX(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ഑"),OTRKI6LbrQnZEm(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫഒ"),K7bLVaiRkx0lgU5SQM(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧഓ"))
			pZrhmfI459 = rljJ8cEGHQtapvDK4LZb6wWMmId2N.Addon(id=JJu4MPClbTFpUwHiN(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ഔ"))
			pZrhmfI459.setSetting(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩക"),vZL6j4tSClIGxzNE5DX(u"ࠫࡋࡧ࡬ࡴࡧࠪഖ"))
		except: pass
		try:
			Qt3P7kYhKvfdHp1ZOWXTBxA5suai8w = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,bDt7Ya1VEio3(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧഗ"),pGncXOodjKhJzLSqVP1r(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪഘ"),TCF8wLyDvgumfiXPSKRh(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧങ"),tOrSvd8QKNB(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧച"))
			pZrhmfI459 = rljJ8cEGHQtapvDK4LZb6wWMmId2N.Addon(id=g4UCaNkHvLwGhjmW(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩഛ"))
			pZrhmfI459.setSetting(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭ജ"),vZL6j4tSClIGxzNE5DX(u"ࠫ࠸࠭ഝ"))
		except: pass
		try:
			Qt3P7kYhKvfdHp1ZOWXTBxA5suai8w = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,O4ylJvVNwLztdiHqBWDU(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧഞ"),O4ylJvVNwLztdiHqBWDU(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪട"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧഠ"),s0vAWcLSXEToH9Mik134q(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧഡ"))
			pZrhmfI459 = rljJ8cEGHQtapvDK4LZb6wWMmId2N.Addon(id=fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩഢ"))
			pZrhmfI459.setSetting(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨണ"),pGncXOodjKhJzLSqVP1r(u"ࠫ࠷࠭ത"))
		except: pass
	VV4iSgTwskE6uyoBCl3ZDh7HQ = obvQGmCVO8(Nk7BzXcC5VbpSanw)
	VV4iSgTwskE6uyoBCl3ZDh7HQ = obvQGmCVO8(RpmwIQ5vaFkP8SuNW)
	uUTRHgAXJzm7pIDBjNt8.setSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩഥ"),GVmdqbtLu8lUXNxp13aHOvkscR)
	WZPsXYo7QE.APcibD3ZNL4WlfrvVkY(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	ksV5ngvbcaS8ByMLYxlfXh(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࡊࡦࡲࡳࡦᎭ"))
	return
def MXWfsAtURnioBlI4Va6vxrHFY8():
	Kc3BTA1MPDmdy8046G5Vb = uUTRHgAXJzm7pIDBjNt8.getSetting(tOrSvd8QKNB(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫദ"))
	Kc3BTA1MPDmdy8046G5Vb = h17Zb2ld4yLBrCP5tiw if not Kc3BTA1MPDmdy8046G5Vb else int(Kc3BTA1MPDmdy8046G5Vb)
	if not Kc3BTA1MPDmdy8046G5Vb or not h17Zb2ld4yLBrCP5tiw<=qyUPZBiAE3YkuOKrMnTFex92D-Kc3BTA1MPDmdy8046G5Vb<=vjPhaUE819opVQg7uRk4wG6cYBOTd:
		uUTRHgAXJzm7pIDBjNt8.setSetting(JJu4MPClbTFpUwHiN(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬധ"),str(qyUPZBiAE3YkuOKrMnTFex92D))
		otYUTIzA5Qwdy1ClJuKLas6r8(oL2eIiFEJnd7vxc)
		CfshtrZSviJRO3YjzHcM0N = uUTRHgAXJzm7pIDBjNt8.getSetting(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡳࡧࡪࡹࡱࡧࡲࠨന"))
		CfshtrZSviJRO3YjzHcM0N = h17Zb2ld4yLBrCP5tiw if not CfshtrZSviJRO3YjzHcM0N else int(CfshtrZSviJRO3YjzHcM0N)
		if not CfshtrZSviJRO3YjzHcM0N or not h17Zb2ld4yLBrCP5tiw<=qyUPZBiAE3YkuOKrMnTFex92D-CfshtrZSviJRO3YjzHcM0N<=pETKl7xuH1f5yjdFAb6C8JzOLV:
			uUTRHgAXJzm7pIDBjNt8.setSetting(OTRKI6LbrQnZEm(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩഩ"),str(qyUPZBiAE3YkuOKrMnTFex92D))
			e9UIQ7WhX4FViaptmR3(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
			njhv9Z1ba8lVTGrSO6QkHA7dpLDm = VVGXMeyJq25S6tf.Thread(target=LcgOjtmynC1HepZ4XSoEz8FMq0dw)
			njhv9Z1ba8lVTGrSO6QkHA7dpLDm.start()
		fuOD5zAISQGYqj = uUTRHgAXJzm7pIDBjNt8.getSetting(tOrSvd8QKNB(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧപ"))
		fuOD5zAISQGYqj = h17Zb2ld4yLBrCP5tiw if not fuOD5zAISQGYqj else int(fuOD5zAISQGYqj)
		if not fuOD5zAISQGYqj or not h17Zb2ld4yLBrCP5tiw<=qyUPZBiAE3YkuOKrMnTFex92D-fuOD5zAISQGYqj<=g6gNzml5rOsa8bBETxPCpnVj:
			uUTRHgAXJzm7pIDBjNt8.setSetting(mpusoZBJ6V(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨഫ"),str(qyUPZBiAE3YkuOKrMnTFex92D))
			import WZPsXYo7QE
			WZPsXYo7QE.OXlgcotDer5zTQ1MFYva3nKxdNR(YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	HEbLy5luN6qPw93YBrk = Z0njBFkw321oC9NItAmEX5O4S6ay(uUTRHgAXJzm7pIDBjNt8.getSetting(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧബ")))
	HEbLy5luN6qPw93YBrk = h17Zb2ld4yLBrCP5tiw if not HEbLy5luN6qPw93YBrk else int(HEbLy5luN6qPw93YBrk)
	Y1TBqg5r48ISMEuODfybX0ZHzsJ = Z0njBFkw321oC9NItAmEX5O4S6ay(uUTRHgAXJzm7pIDBjNt8.getSetting(OTRKI6LbrQnZEm(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨഭ")))
	Y1TBqg5r48ISMEuODfybX0ZHzsJ = h17Zb2ld4yLBrCP5tiw if not Y1TBqg5r48ISMEuODfybX0ZHzsJ else int(Y1TBqg5r48ISMEuODfybX0ZHzsJ)
	if not HEbLy5luN6qPw93YBrk or not Y1TBqg5r48ISMEuODfybX0ZHzsJ or not h17Zb2ld4yLBrCP5tiw<=qyUPZBiAE3YkuOKrMnTFex92D-Y1TBqg5r48ISMEuODfybX0ZHzsJ<=HEbLy5luN6qPw93YBrk:
		e3i5ZYtOFHPzfCEwj1Gdk0LB27RQa = nfC2im3NzUQk
		yyVD6sqczShI8MUv = YoAMfqm37GyFxbuKTt6e8CESHrhB if nVIdjZ1ybeU8TB9tSpAQH(bDt7Ya1VEio3(u"ࠧࡐࡖ࠴࠽ࡏ࡛࠰ࡹࡄࡗ࡙ࡱࡊࡘࠨമ")) else XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if yyVD6sqczShI8MUv:
			RulsXEM83VO0QKcCHza2TGSf4N9g = IIJimsEAhPdua8RFg4LvbMwV0rD5U6(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
			if len(RulsXEM83VO0QKcCHza2TGSf4N9g)>nfC2im3NzUQk:
				SQdRhwozVfv(AwKhgdpmBj0,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨ࠰࡟ࡸࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫയ")+MYIqLm4Nyhniu6QORWlrp+Xr2aHOK0huQ5DTS(u"ࠩࠣࡡࠬര"))
				jfRgOv7BWL9T8y,PXVdZQYTNslvg7wF0159Akr,Qc9doRJK1CMgWzqTruGf,rr4e95RPASc,oVMaZ1qEyj6kLgTCUBNAbsHIpOK,C4RUnz8IDZ15uXOqG96F2kSTNiygp = RulsXEM83VO0QKcCHza2TGSf4N9g[h17Zb2ld4yLBrCP5tiw]
				e9HQkYzB6bw7DEO2gsm,EhM4uxfISnO7kLKFoG5JPy2ql = rr4e95RPASc.split(vZL6j4tSClIGxzNE5DX(u"ࠪࡠࡳࡁ࠻ࠨറ"))
				del RulsXEM83VO0QKcCHza2TGSf4N9g[h17Zb2ld4yLBrCP5tiw]
				N9ymh5KfaqoLcwU2x = yarjPEMGV6m7fHRFeJXt.sample(RulsXEM83VO0QKcCHza2TGSf4N9g,nfC2im3NzUQk)
				jfRgOv7BWL9T8y,PXVdZQYTNslvg7wF0159Akr,Qc9doRJK1CMgWzqTruGf,rr4e95RPASc,oVMaZ1qEyj6kLgTCUBNAbsHIpOK,C4RUnz8IDZ15uXOqG96F2kSTNiygp = N9ymh5KfaqoLcwU2x[h17Zb2ld4yLBrCP5tiw]
				Qc9doRJK1CMgWzqTruGf = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫࡠࡘࡔࡍ࡟ࠪല")+r9rhtA5Tek8sIoLfqwF7JcEV+OTRKI6LbrQnZEm(u"ࠬࠦ࠺ࠡࠩള")+jfRgOv7BWL9T8y+jhAlCQ47ZgG+Qc9doRJK1CMgWzqTruGf
				oVMaZ1qEyj6kLgTCUBNAbsHIpOK = vZL6j4tSClIGxzNE5DX(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬഴ")
				lWD8e5HiSXYUbx = O4ylJvVNwLztdiHqBWDU(u"ࠧศๆอฬึ฿วหࠩവ")
				button0,button1 = rr4e95RPASc,oVMaZ1qEyj6kLgTCUBNAbsHIpOK
				DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz = [button0,button1,lWD8e5HiSXYUbx]
				uyfz2HBkUeKi1TC = nfC2im3NzUQk if nVIdjZ1ybeU8TB9tSpAQH(tg9l25NH6WTacVSifLyAmY(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩശ")) else OOhnpQ8XvCVclGqdu(u"࠱࠱ቧ")
				qqTR9xfSyG0j43H = -g4UCaNkHvLwGhjmW(u"࠺ቨ")
				while qqTR9xfSyG0j43H<h17Zb2ld4yLBrCP5tiw:
					wcZrPJjAlmfs2QNO7bMFH6 = yarjPEMGV6m7fHRFeJXt.sample(DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz,mVjHAyIwzSNKLFcd)
					qqTR9xfSyG0j43H = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,wcZrPJjAlmfs2QNO7bMFH6[h17Zb2ld4yLBrCP5tiw],wcZrPJjAlmfs2QNO7bMFH6[nfC2im3NzUQk],wcZrPJjAlmfs2QNO7bMFH6[JxuTQLOD357o41evylqPmRdf],e9HQkYzB6bw7DEO2gsm,Qc9doRJK1CMgWzqTruGf,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫഷ"),uyfz2HBkUeKi1TC,DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠸࠳ቩ"))
					if qqTR9xfSyG0j43H==mpusoZBJ6V(u"࠴࠴ቪ"): break
					from WZPsXYo7QE import U6KgbJ9ld3WHCYqFf4AV2Ikx,RnSBkihLmKDpvb
					if qqTR9xfSyG0j43H>=h17Zb2ld4yLBrCP5tiw and wcZrPJjAlmfs2QNO7bMFH6[qqTR9xfSyG0j43H]==DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz[nfC2im3NzUQk]:
						U6KgbJ9ld3WHCYqFf4AV2Ikx()
						if qqTR9xfSyG0j43H>=h17Zb2ld4yLBrCP5tiw: qqTR9xfSyG0j43H = -DDHwpETQrAm0xMNXGfyhqsUi(u"࠽ቫ")
					elif qqTR9xfSyG0j43H>=h17Zb2ld4yLBrCP5tiw and wcZrPJjAlmfs2QNO7bMFH6[qqTR9xfSyG0j43H]==DgwdKXNO7YBPE6fLyAbks3t8JQ0Fz[JxuTQLOD357o41evylqPmRdf]:
						RnSBkihLmKDpvb(YoAMfqm37GyFxbuKTt6e8CESHrhB)
					if qqTR9xfSyG0j43H==-nfC2im3NzUQk: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭സ"),r9rhtA5Tek8sIoLfqwF7JcEV+Xr2aHOK0huQ5DTS(u"ࠫำื่อࠢั฻ศ࠭ഹ")+jhAlCQ47ZgG+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡢ࡮ࠡๆ็าึ๎ฬࠡษ็ูา๐อࠡลัฮึ่ࠦศฯาࠤ๊์ࠠศๆฦะํฮษࠡษ็้ฯ๎แาหࠪഺ"))
				e3i5ZYtOFHPzfCEwj1Gdk0LB27RQa = nfC2im3NzUQk
			else: e3i5ZYtOFHPzfCEwj1Gdk0LB27RQa = h17Zb2ld4yLBrCP5tiw
		uUTRHgAXJzm7pIDBjNt8.setSetting(OTRKI6LbrQnZEm(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ഻"),lY3kWbFJCKMto68f(qyUPZBiAE3YkuOKrMnTFex92D))
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,y5yX4jh6kUEgWZQIc(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏ഼ࠪ"),pTwKPmzMSZhil5d2RWonre(u"ࠨࡕࡌࡘࡊ࡙࡟ࡏࡃࡐࡉࡘ࠭ഽ"),e3i5ZYtOFHPzfCEwj1Gdk0LB27RQa,xfdjCmFwb0k8JAVegiL)
	return
def GhbRlU9nBaHuDSZ6k(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,BhrLoijzPEQdMFf4G981Kl,zcl5RYhWSMKwDGqLjtgknbU,XXQM6ytjGOkW,RsTtrzxBK961JWwk4,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf,cGMR9nOxZFfiElhVj4zd,J4kSW2aUHYg6,AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L):
	S9asRTtyBDOJnwMZxHAhz6QiPepd8 = int(cGMR9nOxZFfiElhVj4zd%XWbHfI9B8swrOL(u"࠶࠶ቬ"))
	qLQisyBRkG5o1VxOnbCegD = int(cGMR9nOxZFfiElhVj4zd/O4ylJvVNwLztdiHqBWDU(u"࠷࠰ቭ"))
	KcLAzlMHtpbT9jUd7R = NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,BhrLoijzPEQdMFf4G981Kl,zcl5RYhWSMKwDGqLjtgknbU,XXQM6ytjGOkW,RsTtrzxBK961JWwk4,CyarqoiHxV2e80ScjAN,QigevCplXxbPI1H,zHTPjrSgp8Zcbf
	J3k7F4G6Rx = uUTRHgAXJzm7pIDBjNt8.getSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩാ"))
	if not J3k7F4G6Rx: uUTRHgAXJzm7pIDBjNt8.setSetting(tOrSvd8QKNB(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪി"),y5yX4jh6kUEgWZQIc(u"ࠫࡆ࡛ࡔࡐࠩീ"))
	aeRHmPISMkDNA2vd7F6gzpB9C = uUTRHgAXJzm7pIDBjNt8.getSetting(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩു"))
	kZINFVLcUObK8Wsxohq0 = rybze7NZwv(J4kSW2aUHYg6)
	kOq5EN8gWQfDjixe190tIJ = [h17Zb2ld4yLBrCP5tiw,K7bLVaiRkx0lgU5SQM(u"࠲࠷ቯ"),fk8jc5uDLX16qrih3ZaPxsvO(u"࠳࠺ተ"),vZL6j4tSClIGxzNE5DX(u"࠴࠽ቱ"),mpusoZBJ6V(u"࠲࠷ቮ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠹࠴ቴ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠹࠵ቲ"),tOrSvd8QKNB(u"࠺࠹ታ")]
	zo9DEhvtbrLc401KWTuaX7CxBw = qLQisyBRkG5o1VxOnbCegD not in kOq5EN8gWQfDjixe190tIJ
	X1wJAKrdcj6W = qLQisyBRkG5o1VxOnbCegD in [TCF8wLyDvgumfiXPSKRh(u"࠵࠷ቸ"),pTwKPmzMSZhil5d2RWonre(u"࠲࠹ት"),v54ZuLY6dQ(u"࠹࠴ቷ"),svULcgJ7jm(u"࠸࠴ቶ")]
	YDhqQH7ZM1T = cGMR9nOxZFfiElhVj4zd in [DDHwpETQrAm0xMNXGfyhqsUi(u"࠷࠼࠵ቺ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠶࠼࠶ቹ")]
	hh9xwt1Y5PTU = (zo9DEhvtbrLc401KWTuaX7CxBw or X1wJAKrdcj6W) and not YDhqQH7ZM1T
	zgTIwoPt0vR1FSX = aeRHmPISMkDNA2vd7F6gzpB9C!=hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ൂ") and (aeRHmPISMkDNA2vd7F6gzpB9C or not Jl1Za0IHxnshWC)
	hULJY46XBTNj1WPVwbuzQqsov = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡵࡻࡳࡩࡂ࠭ൃ") in aeRHmPISMkDNA2vd7F6gzpB9C
	vEkNgdKLzh = cGMR9nOxZFfiElhVj4zd in [XWbHfI9B8swrOL(u"࠳࠹࠵ኅ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠴࠺࠷ኆ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠵࠻࠹ኇ"),FF70emVxhWOngCty(u"࠶࠼࠴ኁ"),OOhnpQ8XvCVclGqdu(u"࠷࠶࠶ኂ"),JJu4MPClbTFpUwHiN(u"࠱࠷࠸ኃ"),g4UCaNkHvLwGhjmW(u"࠲࠸࠺ኄ"),g4UCaNkHvLwGhjmW(u"࠵࠻࠾ኀ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠸࠸࠴ች"),O4ylJvVNwLztdiHqBWDU(u"࠽࠶࠳ቻ"),O4ylJvVNwLztdiHqBWDU(u"࠷࠷࠵ቼ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠹࠹࠸ቾ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠺࠺࠺ቿ")]
	UJL7oB1rySs6ERpjGnhvz = S9asRTtyBDOJnwMZxHAhz6QiPepd8==pGncXOodjKhJzLSqVP1r(u"࠾ኈ") or cGMR9nOxZFfiElhVj4zd in [OOhnpQ8XvCVclGqdu(u"࠱࠵࠷ኊ"),tOrSvd8QKNB(u"࠷࠴࠺ኌ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠶࠴࠶ኋ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠺࠵኉")]
	lJNM9AGUOuXjvKp = not vEkNgdKLzh
	oWjPMzvgrTX9B4 = not UJL7oB1rySs6ERpjGnhvz
	IRhY4pMGxfWSXdqNV = kZINFVLcUObK8Wsxohq0 in [QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨ࠰࠱ࠫൄ")]
	jHzhbBLE5g9syA2KwMFIrV = IRhY4pMGxfWSXdqNV or lJNM9AGUOuXjvKp
	NIpTVawtB4uUfiEsG8nrx5A = IRhY4pMGxfWSXdqNV or oWjPMzvgrTX9B4 or hULJY46XBTNj1WPVwbuzQqsov
	woDksLVUyuGxS1n4v2MWebRQ8 = cGMR9nOxZFfiElhVj4zd not in [g4UCaNkHvLwGhjmW(u"࠲࠷࠲ኑ"),mmKqLr9RX0ACN384JMcsFHzd(u"࠵࠺࠶ኍ"),y5yX4jh6kUEgWZQIc(u"࠳࠸࠸ኒ"),pTwKPmzMSZhil5d2RWonre(u"࠷࠽࠰኏"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠷࠸࠶኎"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠻࠴࠱ነ")]
	if J3k7F4G6Rx==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡖࡘࡔࡖࠧ൅"): J5mZQvRXz9wti = UJL7oB1rySs6ERpjGnhvz or vEkNgdKLzh
	else: J5mZQvRXz9wti = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	Nb4swhIg0c = qLQisyBRkG5o1VxOnbCegD in [pTwKPmzMSZhil5d2RWonre(u"࠺࠸ኔ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠹࠸ና")]
	ipvfqanWocyuV5lODsLz93Mk1h = cGMR9nOxZFfiElhVj4zd in [pTwKPmzMSZhil5d2RWonre(u"࠶࠽࠶ን"),OOhnpQ8XvCVclGqdu(u"࠼࠸࠰ኖ")]
	pO804MrT5JLg3xmKu7 = not Nb4swhIg0c and not ipvfqanWocyuV5lODsLz93Mk1h
	VVGeEMpHJ1KzsangvA6Yj = jHzhbBLE5g9syA2KwMFIrV and NIpTVawtB4uUfiEsG8nrx5A and woDksLVUyuGxS1n4v2MWebRQ8 and J5mZQvRXz9wti and pO804MrT5JLg3xmKu7
	zX40UCyhpswfK = woDksLVUyuGxS1n4v2MWebRQ8 and J5mZQvRXz9wti and pO804MrT5JLg3xmKu7
	yRcKp4knx7mYAg59Dd = zX40UCyhpswfK
	BBTgJQbnwmAG7jkXNtYcElIZ = uUTRHgAXJzm7pIDBjNt8.getSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡲࡵࡳࡻ࡯ࡤࡦࡴࠪെ"))
	fFx2KuYlSbPde = uUTRHgAXJzm7pIDBjNt8.getSetting(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡦࡳࡩ࡫ࠧേ"))
	if zgTIwoPt0vR1FSX and VVGeEMpHJ1KzsangvA6Yj:
		ssRQzukpIhqO = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,tOrSvd8QKNB(u"ࠬࡲࡩࡴࡶࠪൈ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ൉")+BBTgJQbnwmAG7jkXNtYcElIZ+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡠࠩൊ")+fFx2KuYlSbPde,KcLAzlMHtpbT9jUd7R)
		if ssRQzukpIhqO:
			SQdRhwozVfv(QigevCplXxbPI1H,mpusoZBJ6V(u"ࠨ࠰࡟ࡸࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪോ")+BBTgJQbnwmAG7jkXNtYcElIZ+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡢࠫൌ")+fFx2KuYlSbPde+JJu4MPClbTFpUwHiN(u"ࠪࠤࠥࠦࡌࡰࡣࡧ࡭ࡳ࡭ࠠ࡮ࡧࡱࡹࠥ࡬ࡲࡰ࡯ࠣࡧࡦࡩࡨࡦ്ࠩ"))
			if hULJY46XBTNj1WPVwbuzQqsov:
				UUT9Q7J4dHEboDyLnuA = []
				from M82S6vNfCF import f4E8R1bcysFItm
				from T9PmfG7SQA import xCTgdOF20zM4U,WLjdqXog7ZQcPSb6
				HHoCstuDxI4PQLzF = f4E8R1bcysFItm
				CGaxp2SAlyKI = xCTgdOF20zM4U()
				rqawvlBKkRMzsVT5Gjht0N = aeRHmPISMkDNA2vd7F6gzpB9C
				DuVHF0w8RxvbdCp,Og6AdI7XrjLuQ5yDP2B91zsH,X6sJNAHy4Ufmi,dGqmxbfiZ9zQpY7RJtsVBhvcrow43,V4V8jnBKsRYHokezOMu5ly7ArxE,kY95zCuSeKQxBhiTaqDXO83G,HUhNyYpQIJtj4BSmdzE28PCr,mdJBQgciSPHpyFfoG8,Ask6Bnu9lzUSYbc7GKQFm1Zivx5 = c79RqAVuZjN1UaSOPB(rqawvlBKkRMzsVT5Gjht0N)
				NNJWEI0TOCQejUSHxag = DuVHF0w8RxvbdCp,Og6AdI7XrjLuQ5yDP2B91zsH,X6sJNAHy4Ufmi,dGqmxbfiZ9zQpY7RJtsVBhvcrow43,V4V8jnBKsRYHokezOMu5ly7ArxE,kY95zCuSeKQxBhiTaqDXO83G,HUhNyYpQIJtj4BSmdzE28PCr,QigevCplXxbPI1H,Ask6Bnu9lzUSYbc7GKQFm1Zivx5
				for wN5obDJ1gixmusIcRClT2rB in ssRQzukpIhqO:
					mLSrP3OMhiXadZ1T8U4IWevKb6xNF = wN5obDJ1gixmusIcRClT2rB[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡲ࡫࡮ࡶࡋࡷࡩࡲ࠭ൎ")]
					if mLSrP3OMhiXadZ1T8U4IWevKb6xNF==NNJWEI0TOCQejUSHxag or wN5obDJ1gixmusIcRClT2rB[mpusoZBJ6V(u"ࠬࡳ࡯ࡥࡧࠪ൏")] in [y5yX4jh6kUEgWZQIc(u"࠲࠷࠷ኘ"),O4ylJvVNwLztdiHqBWDU(u"࠸࠷࠱ኗ")]:
						wN5obDJ1gixmusIcRClT2rB = hhTVKzB6fi5b1M9RPxkJGgdtHIlqy(mLSrP3OMhiXadZ1T8U4IWevKb6xNF,HHoCstuDxI4PQLzF,CGaxp2SAlyKI)
						if wN5obDJ1gixmusIcRClT2rB[g4UCaNkHvLwGhjmW(u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࠩ൐")]:
							Sd4UpMebCFJxBIsrQihwnqX2NzKWt = WLjdqXog7ZQcPSb6(CGaxp2SAlyKI,mLSrP3OMhiXadZ1T8U4IWevKb6xNF,wN5obDJ1gixmusIcRClT2rB[g4UCaNkHvLwGhjmW(u"ࠧ࡯ࡧࡺࡴࡦࡺࡨࠨ൑")])
							wN5obDJ1gixmusIcRClT2rB[FF70emVxhWOngCty(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ൒")] = Sd4UpMebCFJxBIsrQihwnqX2NzKWt+wN5obDJ1gixmusIcRClT2rB[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ൓")]
					UUT9Q7J4dHEboDyLnuA.append(wN5obDJ1gixmusIcRClT2rB)
				uUTRHgAXJzm7pIDBjNt8.setSetting(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧൔ"),QigevCplXxbPI1H)
				if NWdTSkYP5E6wqsDogApZmLCcbu3j2I==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫൕ"): BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,OOhnpQ8XvCVclGqdu(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫൖ")+BBTgJQbnwmAG7jkXNtYcElIZ+DDHwpETQrAm0xMNXGfyhqsUi(u"࠭࡟ࠨൗ")+fFx2KuYlSbPde,KcLAzlMHtpbT9jUd7R,UUT9Q7J4dHEboDyLnuA,pETKl7xuH1f5yjdFAb6C8JzOLV)
			else: UUT9Q7J4dHEboDyLnuA = ssRQzukpIhqO
			if NWdTSkYP5E6wqsDogApZmLCcbu3j2I==s0vAWcLSXEToH9Mik134q(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ൘") and kZINFVLcUObK8Wsxohq0!=Fg72JX6T5DkPy(u"ࠨ࠰࠱ࠫ൙") and hh9xwt1Y5PTU: VKsQmdD8RBlM4pzPZUocJXH75bejI()
			osPYJZWgyfkBO2 = O4uqMjBo8zCZ(KcLAzlMHtpbT9jUd7R,UUT9Q7J4dHEboDyLnuA,AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L)
			if osPYJZWgyfkBO2: ksV5ngvbcaS8ByMLYxlfXh()
	elif NWdTSkYP5E6wqsDogApZmLCcbu3j2I==OTRKI6LbrQnZEm(u"ࠩࡩࡳࡱࡪࡥࡳࠩ൚") and aeRHmPISMkDNA2vd7F6gzpB9C==svULcgJ7jm(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ൛") and zX40UCyhpswfK:
		P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ൜")+BBTgJQbnwmAG7jkXNtYcElIZ+g4UCaNkHvLwGhjmW(u"ࠬࡥࠧ൝")+fFx2KuYlSbPde,KcLAzlMHtpbT9jUd7R)
	return aeRHmPISMkDNA2vd7F6gzpB9C,KcLAzlMHtpbT9jUd7R,kZINFVLcUObK8Wsxohq0,hh9xwt1Y5PTU,yRcKp4knx7mYAg59Dd,BBTgJQbnwmAG7jkXNtYcElIZ,fFx2KuYlSbPde
def MgnF3TUtGQD1(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf,AYvyVPneLu0gCIObkQRrKFNwqD9,cGMR9nOxZFfiElhVj4zd,CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1):
	if CisD6xT0rWmGnER7lI2Qqad1y in [Xr2aHOK0huQ5DTS(u"࠭࠱ࠨ൞"),FF70emVxhWOngCty(u"ࠧ࠳ࠩൟ"),pGncXOodjKhJzLSqVP1r(u"ࠨ࠵ࠪൠ"),K7bLVaiRkx0lgU5SQM(u"ࠩ࠷ࠫൡ"),FF70emVxhWOngCty(u"ࠪ࠹ࠬൢ")] and PnCEQ8xD3AI1:
		from T9PmfG7SQA import rLdIGxeRKphTWYJ
		rLdIGxeRKphTWYJ(Jl1Za0IHxnshWC,CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1)
		ksV5ngvbcaS8ByMLYxlfXh(OOhnpQ8XvCVclGqdu(u"ࡋࡧ࡬ࡴࡧᎮ"),MYIqLm4Nyhniu6QORWlrp)
	elif CisD6xT0rWmGnER7lI2Qqad1y==mpusoZBJ6V(u"ࠫ࠻࠭ൣ"):
		from TEsNM9QVZc import X69Fkr1VNnf2pJQC8wl7YR4HmaKc,tZd9HYuJBf0SUegwOcWbz8FoaipLQm
		if PnCEQ8xD3AI1==XWbHfI9B8swrOL(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ൤"): X69Fkr1VNnf2pJQC8wl7YR4HmaKc(mpusoZBJ6V(u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭൥"),K7bLVaiRkx0lgU5SQM(u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧ൦"),B3TKLo71hAGRqYgV0=Xr2aHOK0huQ5DTS(u"࠲࠷࠳࠴ኙ"))
		elif PnCEQ8xD3AI1==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡆࡈࡐࡊ࡚ࡅࠨ൧"): cGMR9nOxZFfiElhVj4zd = bDt7Ya1VEio3(u"࠵࠶࠸ኚ")
		W9lfsoMawqOzpQcXD = tZd9HYuJBf0SUegwOcWbz8FoaipLQm(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,AYvyVPneLu0gCIObkQRrKFNwqD9,iCr0xsqwDZXLPaJK1W5YU24F6hp,cGMR9nOxZFfiElhVj4zd,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
		if PnCEQ8xD3AI1==Xr2aHOK0huQ5DTS(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ൨"): ksV5ngvbcaS8ByMLYxlfXh()
		elif PnCEQ8xD3AI1==y5yX4jh6kUEgWZQIc(u"ࠪࡈࡊࡒࡅࡕࡇࠪ൩"): ksV5ngvbcaS8ByMLYxlfXh(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࡌࡡ࡭ࡵࡨᎯ"))
	elif Jl1Za0IHxnshWC==pGncXOodjKhJzLSqVP1r(u"ࠫ࠼࠭൪"):
		from x6evIlTMjh import qiDXo79yf3xu
		qiDXo79yf3xu()
		ksV5ngvbcaS8ByMLYxlfXh(s0vAWcLSXEToH9Mik134q(u"ࡆࡢ࡮ࡶࡩᎰ"))
	elif Jl1Za0IHxnshWC==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬ࠾ࠧ൫"):
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(O4ylJvVNwLztdiHqBWDU(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬ൬")+GTZC7rKJtPlueQ+Fg72JX6T5DkPy(u"ࠧࡀ࡯ࡲࡨࡪࡃࠧ൭")+str(zcl5RYhWSMKwDGqLjtgknbU)+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࠨࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠩࠨ൮"))
	elif Jl1Za0IHxnshWC==g4UCaNkHvLwGhjmW(u"ࠩ࠼ࠫ൯"):
		ksV5ngvbcaS8ByMLYxlfXh(OTRKI6LbrQnZEm(u"ࡕࡴࡸࡩᎱ"))
	return
def EMmSnW7KIz1aqZgxoDChJ(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf,AYvyVPneLu0gCIObkQRrKFNwqD9,cGMR9nOxZFfiElhVj4zd,CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1,J4kSW2aUHYg6):
	if Jl1Za0IHxnshWC: MgnF3TUtGQD1(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf,AYvyVPneLu0gCIObkQRrKFNwqD9,cGMR9nOxZFfiElhVj4zd,CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1)
	if enGPuSCj3A2R: Gk8DKbQ2InVy7ipeL4S1XFgmAqOT()
	e9UIQ7WhX4FViaptmR3(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	MXWfsAtURnioBlI4Va6vxrHFY8()
	AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L = XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB
	nn4eIOsVbfaoRjvZ8KLFJ1E = GhbRlU9nBaHuDSZ6k(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf,cGMR9nOxZFfiElhVj4zd,J4kSW2aUHYg6,AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L)
	aeRHmPISMkDNA2vd7F6gzpB9C,KcLAzlMHtpbT9jUd7R,kZINFVLcUObK8Wsxohq0,hh9xwt1Y5PTU,yRcKp4knx7mYAg59Dd,BBTgJQbnwmAG7jkXNtYcElIZ,fFx2KuYlSbPde = nn4eIOsVbfaoRjvZ8KLFJ1E
	if aeRHmPISMkDNA2vd7F6gzpB9C==vZL6j4tSClIGxzNE5DX(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ൰"): GGohatHrqeg3cKMJ6AZV(mpusoZBJ6V(u"ࡈࡤࡰࡸ࡫Ꮂ"))
	SxKAmIcoHeQ1(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡸࡺࡡࡳࡶࠪ൱"))
	if uUTRHgAXJzm7pIDBjNt8.getSetting(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ൲")) not in [g4UCaNkHvLwGhjmW(u"࠭ࡁࡖࡖࡒࠫ൳"),tg9l25NH6WTacVSifLyAmY(u"ࠧࡔࡖࡒࡔࠬ൴"),JJu4MPClbTFpUwHiN(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ൵")]:
		uUTRHgAXJzm7pIDBjNt8.setSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ൶"),OTRKI6LbrQnZEm(u"ࠪࡅ࡚࡚ࡏࠨ൷"))
	if not uUTRHgAXJzm7pIDBjNt8.getSetting(pTwKPmzMSZhil5d2RWonre(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫ൸")): uUTRHgAXJzm7pIDBjNt8.setSetting(y5yX4jh6kUEgWZQIc(u"ࠬࡧࡶ࠯ࡦࡱࡷࠬ൹"),ye5VdS961JgscKZjAp0HXnT[h17Zb2ld4yLBrCP5tiw])
	W9lfsoMawqOzpQcXD = tZd9HYuJBf0SUegwOcWbz8FoaipLQm(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,AYvyVPneLu0gCIObkQRrKFNwqD9,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
	if mpusoZBJ6V(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨൺ") in CyarqoiHxV2e80ScjAN: BFlrO18heutDTW309yopHdLgzIUJj = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if NWdTSkYP5E6wqsDogApZmLCcbu3j2I==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧൻ"):
		if kZINFVLcUObK8Wsxohq0!=FF70emVxhWOngCty(u"ࠨ࠰࠱ࠫർ") and hh9xwt1Y5PTU: VKsQmdD8RBlM4pzPZUocJXH75bejI()
		if NNZh0HbgakloGKdCOUYJ3W1SAnXPwi>-nfC2im3NzUQk:
			WsGrjTg1yp39HMZeqUPmALJ4Ca65EQ = [h17Zb2ld4yLBrCP5tiw,vZL6j4tSClIGxzNE5DX(u"࠵࠺ኜ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠽ኝ"),g4UCaNkHvLwGhjmW(u"࠷࠹ኞ"),K7bLVaiRkx0lgU5SQM(u"࠵࠺ኛ"),vZL6j4tSClIGxzNE5DX(u"࠵࠷ኡ"),O4ylJvVNwLztdiHqBWDU(u"࠵࠱ኟ"),bDt7Ya1VEio3(u"࠶࠵አ")]
			if (wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,g4UCaNkHvLwGhjmW(u"ࠩ࡬ࡲࡹ࠭ൽ"),Fg72JX6T5DkPy(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ൾ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩൿ")) or cGMR9nOxZFfiElhVj4zd not in WsGrjTg1yp39HMZeqUPmALJ4Ca65EQ) and not nVIdjZ1ybeU8TB9tSpAQH(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭඀")):
				from M82S6vNfCF import f4E8R1bcysFItm
				ssRQzukpIhqO = YIimk2Pfta65FTg7HrbwK1n9(f4E8R1bcysFItm)
				osPYJZWgyfkBO2 = O4uqMjBo8zCZ(KcLAzlMHtpbT9jUd7R,ssRQzukpIhqO,AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L)
				if ssRQzukpIhqO and yRcKp4knx7mYAg59Dd:
					BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,OTRKI6LbrQnZEm(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬඁ")+BBTgJQbnwmAG7jkXNtYcElIZ+TCF8wLyDvgumfiXPSKRh(u"ࠧࡠࠩං")+fFx2KuYlSbPde,KcLAzlMHtpbT9jUd7R,ssRQzukpIhqO,pETKl7xuH1f5yjdFAb6C8JzOLV)
			else:
				Z7ZstrGoNP3XSLYClzUm8TqV.addDirectoryItem(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫඃ")+GTZC7rKJtPlueQ+vZL6j4tSClIGxzNE5DX(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ඄"),Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ListItem(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไࠩඅ")))
				Z7ZstrGoNP3XSLYClzUm8TqV.addDirectoryItem(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,mpusoZBJ6V(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧආ")+GTZC7rKJtPlueQ+y5yX4jh6kUEgWZQIc(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬඇ"),Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ListItem(svULcgJ7jm(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬඈ")))
			Z7ZstrGoNP3XSLYClzUm8TqV.endOfDirectory(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L)
	return
def otYUTIzA5Qwdy1ClJuKLas6r8(eVyarF0ZAbtqsmg):
	irDxy3Njz6IAhpPeUEKXcVq20m = YoAMfqm37GyFxbuKTt6e8CESHrhB if eVyarF0ZAbtqsmg else XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if not irDxy3Njz6IAhpPeUEKXcVq20m:
		U0nxmp5ihS = Z0njBFkw321oC9NItAmEX5O4S6ay(uUTRHgAXJzm7pIDBjNt8.getSetting(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨඉ")))
		U0nxmp5ihS = h17Zb2ld4yLBrCP5tiw if not U0nxmp5ihS else int(U0nxmp5ihS)
		if not U0nxmp5ihS or not h17Zb2ld4yLBrCP5tiw<=qyUPZBiAE3YkuOKrMnTFex92D-U0nxmp5ihS<=eVyarF0ZAbtqsmg: irDxy3Njz6IAhpPeUEKXcVq20m = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if not irDxy3Njz6IAhpPeUEKXcVq20m:
		uUr9XmqxNagALBH = uUTRHgAXJzm7pIDBjNt8.getSetting(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ඊ"))
		if uUr9XmqxNagALBH in [QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨඋ"),s0vAWcLSXEToH9Mik134q(u"ࠪࡒࡊ࡝࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩඌ")]: irDxy3Njz6IAhpPeUEKXcVq20m = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if not irDxy3Njz6IAhpPeUEKXcVq20m:
		from hashlib import md5 as o2vzJrWZyOS0Dk73dNpubl
		tBGyoYKLc1Pk4QVnXd = uUTRHgAXJzm7pIDBjNt8.getSetting(pGncXOodjKhJzLSqVP1r(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧඍ"))
		Ym5LZU6FBqRW0a9My7lhDnEA = uUTRHgAXJzm7pIDBjNt8.getSetting(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠲ࠨඎ"))
		F7ES9WC5enarsMTjgRO = o2vzJrWZyOS0Dk73dNpubl(bDt7Ya1VEio3(u"࠸ኢ")*tBGyoYKLc1Pk4QVnXd.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()
		F7ES9WC5enarsMTjgRO = o2vzJrWZyOS0Dk73dNpubl(DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠵࠹ኣ")*F7ES9WC5enarsMTjgRO.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()
		F7ES9WC5enarsMTjgRO = o2vzJrWZyOS0Dk73dNpubl(g4UCaNkHvLwGhjmW(u"࠶࠿ኤ")*F7ES9WC5enarsMTjgRO.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()
		if F7ES9WC5enarsMTjgRO!=Ym5LZU6FBqRW0a9My7lhDnEA: irDxy3Njz6IAhpPeUEKXcVq20m = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if irDxy3Njz6IAhpPeUEKXcVq20m: arn6PsyHZOq4bX18 = GGohatHrqeg3cKMJ6AZV(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	return
def tZd9HYuJBf0SUegwOcWbz8FoaipLQm(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf):
	cGMR9nOxZFfiElhVj4zd = int(zcl5RYhWSMKwDGqLjtgknbU)
	qLQisyBRkG5o1VxOnbCegD = int(cGMR9nOxZFfiElhVj4zd//vZL6j4tSClIGxzNE5DX(u"࠷࠰እ"))
	if   qLQisyBRkG5o1VxOnbCegD==h17Zb2ld4yLBrCP5tiw:  from WZPsXYo7QE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==nfC2im3NzUQk:  from Ofe0and35Y 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==JxuTQLOD357o41evylqPmRdf:  from WespT4cdLO 			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==mVjHAyIwzSNKLFcd:  from BpNaEDFt9Z 			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==bWU9StnJOg6aIQiTMxh7sFZG8lPud:  from xRgEewDY5T 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,JJM6TofH4g5n7SRwq)
	elif qLQisyBRkG5o1VxOnbCegD==y5yX4jh6kUEgWZQIc(u"࠵ኦ"):  from ttgsXAMpEc 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==FF70emVxhWOngCty(u"࠷ኧ"):  from GbRwVnkQAe 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==OTRKI6LbrQnZEm(u"࠹ከ"):  from LgyfTlFJC3 			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==mmKqLr9RX0ACN384JMcsFHzd(u"࠻ኩ"):  from MMPgAmhWqX 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==Fg72JX6T5DkPy(u"࠽ኪ"):  from EGuw05DT4l		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==g4UCaNkHvLwGhjmW(u"࠶࠶ካ"): from FgsvjTqQ1h 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp)
	elif qLQisyBRkG5o1VxOnbCegD==mpusoZBJ6V(u"࠷࠱ኬ"): from Q8XUhOplV9 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠱࠳ክ"): from UOvqsPuVWh 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==FF70emVxhWOngCty(u"࠲࠵ኮ"): from G2GmZRAJL3		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==y5yX4jh6kUEgWZQIc(u"࠳࠷ኯ"): from ikY7SnFWRE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq,yBWPDAeJF1o2b,XGjn5q2cy6mRYZ1hPaDslHMK)
	elif qLQisyBRkG5o1VxOnbCegD==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠴࠹ኰ"): from WZPsXYo7QE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==vZL6j4tSClIGxzNE5DX(u"࠵࠻኱"): from vEkNgdKLzh		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf)
	elif qLQisyBRkG5o1VxOnbCegD==Xr2aHOK0huQ5DTS(u"࠶࠽ኲ"): from WZPsXYo7QE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==XWbHfI9B8swrOL(u"࠷࠸ኳ"): from lWR1tvkOgY		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==K7bLVaiRkx0lgU5SQM(u"࠱࠺ኴ"): from WZPsXYo7QE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠳࠲ኵ"): from UwKh83oDl1		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==OTRKI6LbrQnZEm(u"࠴࠴኶"): from v8ShNal6bj	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠵࠶኷"): from HyVGjh0xDU		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==tg9l25NH6WTacVSifLyAmY(u"࠶࠸ኸ"): from WnaUtzx70u			import WPjOcwA2E7GS4doDXyU3l9C; W9lfsoMawqOzpQcXD = WPjOcwA2E7GS4doDXyU3l9C(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf)
	elif qLQisyBRkG5o1VxOnbCegD==tOrSvd8QKNB(u"࠷࠺ኹ"): from kkERyGgDWI 			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==svULcgJ7jm(u"࠸࠵ኺ"): from ddwWLZ315h 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠲࠷ኻ"): from M82S6vNfCF 			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==y5yX4jh6kUEgWZQIc(u"࠳࠹ኼ"): from T9PmfG7SQA		import WPjOcwA2E7GS4doDXyU3l9C; W9lfsoMawqOzpQcXD = WPjOcwA2E7GS4doDXyU3l9C(cGMR9nOxZFfiElhVj4zd,Jl1Za0IHxnshWC)
	elif qLQisyBRkG5o1VxOnbCegD==v54ZuLY6dQ(u"࠴࠻ኽ"): from WnaUtzx70u			import WPjOcwA2E7GS4doDXyU3l9C; W9lfsoMawqOzpQcXD = WPjOcwA2E7GS4doDXyU3l9C(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf)
	elif qLQisyBRkG5o1VxOnbCegD==O4ylJvVNwLztdiHqBWDU(u"࠵࠽ኾ"): from jMRK5bBnDI	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠷࠵኿"): from ssTIo54KM1		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠸࠷ዀ"): from HDJbuwfOU1		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==bDt7Ya1VEio3(u"࠹࠲዁"): from RRDfn7qJAx		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠳࠴ዂ"): from HV54JYdbCX		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp)
	elif qLQisyBRkG5o1VxOnbCegD==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠴࠶ዃ"): from WZPsXYo7QE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==XWbHfI9B8swrOL(u"࠵࠸ዄ"): from on6lS1PVQD		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==XWbHfI9B8swrOL(u"࠶࠺ዅ"): from YgfswWlCO1			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==svULcgJ7jm(u"࠷࠼዆"): from gzhm8lLXR0			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==Fg72JX6T5DkPy(u"࠸࠾዇"): from LMRkxQV5j6 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠹࠹ወ"): from zVn5N1ujF0		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠴࠱ዉ"): from rYtXalHbju	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq)
	elif qLQisyBRkG5o1VxOnbCegD==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠵࠳ዊ"): from rYtXalHbju	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq)
	elif qLQisyBRkG5o1VxOnbCegD==bDt7Ya1VEio3(u"࠶࠵ዋ"): from Jv9dkHFNmq			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==O4ylJvVNwLztdiHqBWDU(u"࠷࠷ዌ"): from p4H1dtwvk9			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==FF70emVxhWOngCty(u"࠸࠹ው"): from zCnEmBKejJ		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==OTRKI6LbrQnZEm(u"࠹࠻ዎ"): from XycSan34st		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==g4UCaNkHvLwGhjmW(u"࠺࠶ዏ"): from ggl2cikBed			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠴࠸ዐ"): from MGUDSETYwn		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==TCF8wLyDvgumfiXPSKRh(u"࠵࠺ዑ"): from RflsiP2MmZ		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==JJu4MPClbTFpUwHiN(u"࠶࠼ዒ"): from dL4SBey7iu		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==tg9l25NH6WTacVSifLyAmY(u"࠸࠴ዓ"): from WZPsXYo7QE 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠹࠶ዔ"): from Q9pzMVs4PY 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠺࠸ዕ"): from Q9pzMVs4PY 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠻࠳ዖ"): from M82S6vNfCF 			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==Fg72JX6T5DkPy(u"࠵࠵዗"): from x6evIlTMjh	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,JJM6TofH4g5n7SRwq)
	elif qLQisyBRkG5o1VxOnbCegD==bDt7Ya1VEio3(u"࠶࠷ዘ"): from Pe1N9oEwBQ 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷࠹ዙ"): from FCjhbSetXr			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==mmKqLr9RX0ACN384JMcsFHzd(u"࠸࠻ዚ"): from tIuoSjwAEZ		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==tg9l25NH6WTacVSifLyAmY(u"࠹࠽ዛ"): from nOi2FhC05g		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==vZL6j4tSClIGxzNE5DX(u"࠺࠿ዜ"): from i0BW9X58Z6		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==s0vAWcLSXEToH9Mik134q(u"࠼࠰ዝ"): from ww0sOSEGjh			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠲ዞ"): from dSKVnvcC7j			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠷࠴ዟ"): from vPwrcKMf0q		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==s0vAWcLSXEToH9Mik134q(u"࠸࠶ዠ"): from YA9gyEk8nj	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==fk8jc5uDLX16qrih3ZaPxsvO(u"࠹࠸ዡ"): from bh6GSD1NJp			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠺࠺ዢ"): from G96qTLtC0D			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠻࠼ዣ"): from tPYFqaHhnB			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==Xr2aHOK0huQ5DTS(u"࠼࠷ዤ"): from zzwTfWEtBN		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==FF70emVxhWOngCty(u"࠶࠹ዥ"): from FGiYDtxzh6		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠷࠻ዦ"): from vzKntVZWid		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==DDHwpETQrAm0xMNXGfyhqsUi(u"࠹࠳ዧ"): from ew4SbOFp6g			import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==g4UCaNkHvLwGhjmW(u"࠺࠵የ"): from BGdPH3ey27			import WPjOcwA2E7GS4doDXyU3l9C; W9lfsoMawqOzpQcXD = WPjOcwA2E7GS4doDXyU3l9C(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf)
	elif qLQisyBRkG5o1VxOnbCegD==FF70emVxhWOngCty(u"࠻࠷ዩ"): from BGdPH3ey27			import WPjOcwA2E7GS4doDXyU3l9C; W9lfsoMawqOzpQcXD = WPjOcwA2E7GS4doDXyU3l9C(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,NWdTSkYP5E6wqsDogApZmLCcbu3j2I,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf)
	elif qLQisyBRkG5o1VxOnbCegD==Xr2aHOK0huQ5DTS(u"࠼࠹ዪ"): from ouRLGAy4mp	import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==OTRKI6LbrQnZEm(u"࠽࠴ያ"): from Nb4swhIg0c		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd)
	elif qLQisyBRkG5o1VxOnbCegD==y5yX4jh6kUEgWZQIc(u"࠷࠶ዬ"): from Nb4swhIg0c		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd)
	elif qLQisyBRkG5o1VxOnbCegD==tOrSvd8QKNB(u"࠸࠸ይ"): from vEkNgdKLzh		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf)
	elif qLQisyBRkG5o1VxOnbCegD==TCF8wLyDvgumfiXPSKRh(u"࠹࠺ዮ"): from yyrKVk7Tl8 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠺࠼ዯ"): from ijXgSh7lG3 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠻࠾ደ"): from ymHvX9woJW 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==JJu4MPClbTFpUwHiN(u"࠽࠶ዱ"): from B6keJXpbSa 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==pGncXOodjKhJzLSqVP1r(u"࠾࠱ዲ"): from KX7wHeEzrW 		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,CyarqoiHxV2e80ScjAN)
	elif qLQisyBRkG5o1VxOnbCegD==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠸࠳ዳ"): from xKNzwc5Jhp		import YnMSWTbKj1N8wuRJVF	; W9lfsoMawqOzpQcXD = YnMSWTbKj1N8wuRJVF(cGMR9nOxZFfiElhVj4zd,iCr0xsqwDZXLPaJK1W5YU24F6hp,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN)
	else: W9lfsoMawqOzpQcXD = None
	return W9lfsoMawqOzpQcXD
def Wk5ISuRlA7sVLf1j(kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp,m9TrBXjhwRgI,showDialogs):
	c1Ifu0OGV2kyRwLPWlsho8Ct6nz = m9TrBXjhwRgI.split(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࠭ࠨඏ"),nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw] if FF70emVxhWOngCty(u"ࠧ࠮ࠩඐ") in m9TrBXjhwRgI else m9TrBXjhwRgI
	if not showDialogs or m9TrBXjhwRgI in bbaZdrlivfI6: return YoAMfqm37GyFxbuKTt6e8CESHrhB
	ssGfCdzum4rMlEqaNkKDLR = uUTRHgAXJzm7pIDBjNt8.getSetting(JJu4MPClbTFpUwHiN(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩඑ"))
	uUTRHgAXJzm7pIDBjNt8.setSetting(bDt7Ya1VEio3(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪඒ"),QigevCplXxbPI1H)
	S9RrUMij7cmFkHx4oWJGsKCz = kQKmN8hHvzcC6PWtbJqr4aL9 in [OTRKI6LbrQnZEm(u"࠻ዷ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠳࠴࠴࠵࠷ድ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠲࠳࠳࠴࠷ዴ"),vZL6j4tSClIGxzNE5DX(u"࠴࠴࠵࠻࠴ዶ")]
	oFNr0BP3qW1VXEfwKnLZcp7kz = C4RUnz8IDZ15uXOqG96F2kSTNiygp.lower()
	Ky5HjAFiOchp8em4t03dRflv = kQKmN8hHvzcC6PWtbJqr4aL9 in [h17Zb2ld4yLBrCP5tiw,JJu4MPClbTFpUwHiN(u"࠱࠱࠶ዺ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠶࠰࠷࠳ዸ"),XWbHfI9B8swrOL(u"࠷࠱࠲ዹ")]
	XF05tTvJzGPBULHWKn6oRIQCAl = y5yX4jh6kUEgWZQIc(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫඓ") in oFNr0BP3qW1VXEfwKnLZcp7kz
	VQXrcHip7aKuq9zv5tMNo2CsLxwj = svULcgJ7jm(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫඔ") in oFNr0BP3qW1VXEfwKnLZcp7kz
	pkGcmve8X5aASBhEV4wIMP = mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬඕ") in oFNr0BP3qW1VXEfwKnLZcp7kz
	F0GSVUhgP4iNMqmYWXJQc8AoTnHk9 = s0vAWcLSXEToH9Mik134q(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨඖ") in oFNr0BP3qW1VXEfwKnLZcp7kz
	Zb0GKOIxPgts18Y6FlSouCV2QEhR = uUTRHgAXJzm7pIDBjNt8.getSetting(svULcgJ7jm(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ඗"))
	qqPWDhZlp2zOJ1xAmKXjne = uUTRHgAXJzm7pIDBjNt8.getSetting(bDt7Ya1VEio3(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫ඘"))
	LhjyMVSAaKbwvHR = bDt7Ya1VEio3(u"ࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ส์สา่อࠫ඙")
	T0LcFA5Gngs6eEDSIOh4 = svULcgJ7jm(u"ࠪࡉࡷࡸ࡯ࡳࠢࠪක")+str(kQKmN8hHvzcC6PWtbJqr4aL9)+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ࠿ࠦࠧඛ")+C4RUnz8IDZ15uXOqG96F2kSTNiygp
	T0LcFA5Gngs6eEDSIOh4 = MVkP7zfWlxUXj(T0LcFA5Gngs6eEDSIOh4)
	if Ky5HjAFiOchp8em4t03dRflv or XF05tTvJzGPBULHWKn6oRIQCAl or VQXrcHip7aKuq9zv5tMNo2CsLxwj or pkGcmve8X5aASBhEV4wIMP or F0GSVUhgP4iNMqmYWXJQc8AoTnHk9:
		LhjyMVSAaKbwvHR += O4ylJvVNwLztdiHqBWDU(u"ࠬࠦ࠮ࠡษ็้ํู่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ฺ้ࠣีั่ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦร้ࠢหห้๋่ใ฻࡟ࡲࠬග")
	if S9RrUMij7cmFkHx4oWJGsKCz: LhjyMVSAaKbwvHR += VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࠠ࠯ࠢ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࡠࡳ࠭ඝ")
	T0LcFA5Gngs6eEDSIOh4 = aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+T0LcFA5Gngs6eEDSIOh4+jhAlCQ47ZgG
	if Zb0GKOIxPgts18Y6FlSouCV2QEhR==XWbHfI9B8swrOL(u"ࠧࡂࡕࡎࠫඞ") or qqPWDhZlp2zOJ1xAmKXjne==bDt7Ya1VEio3(u"ࠨࡃࡖࡏࠬඟ"):
		LhjyMVSAaKbwvHR += aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+Xr2aHOK0huQ5DTS(u"๊่ࠩࠥะั๋ัࠣว๋๊ࠦฮษ๋่ࠥอไษำ้ห๊าࠠฦื็หาࠦวๅ็ื็้ฯࠠ࠯࠰ࠣว๊ࠦสา์าࠤสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠢศ่๎ࠦวๅ็หี๊าࠠภࠣࠤࠫච")+jhAlCQ47ZgG
	Vcud91q2i4Tm5zEvw = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if Zb0GKOIxPgts18Y6FlSouCV2QEhR==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡅࡘࡑࠧඡ") or qqPWDhZlp2zOJ1xAmKXjne==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࡆ࡙ࡋࠨජ"):
		qqTR9xfSyG0j43H = L2Lu1MQVHhiTX0(JJu4MPClbTFpUwHiN(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬඣ"),svULcgJ7jm(u"࠭ฮา๊ฯࠫඤ"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧฦำึห้ࠦไๅ็หี๊าࠧඥ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨฬุ่๏ำࠠศๆุ่่๊ษࠨඦ"),c1Ifu0OGV2kyRwLPWlsho8Ct6nz+Ec4QJmyAo3G7Vp2X6SY8UifnOh+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(c1Ifu0OGV2kyRwLPWlsho8Ct6nz),LhjyMVSAaKbwvHR+aSBkt4OU8JpWTEzVIHjAiv+T0LcFA5Gngs6eEDSIOh4)
		if qqTR9xfSyG0j43H==nfC2im3NzUQk:
			from WZPsXYo7QE import U6KgbJ9ld3WHCYqFf4AV2Ikx
			U6KgbJ9ld3WHCYqFf4AV2Ikx()
		elif qqTR9xfSyG0j43H==JxuTQLOD357o41evylqPmRdf: Vcud91q2i4Tm5zEvw = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,c1Ifu0OGV2kyRwLPWlsho8Ct6nz+Ec4QJmyAo3G7Vp2X6SY8UifnOh+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(c1Ifu0OGV2kyRwLPWlsho8Ct6nz),LhjyMVSAaKbwvHR,T0LcFA5Gngs6eEDSIOh4)
	uUTRHgAXJzm7pIDBjNt8.setSetting(vZL6j4tSClIGxzNE5DX(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪට"),ssGfCdzum4rMlEqaNkKDLR)
	return Vcud91q2i4Tm5zEvw
def oYAuTVpsaSfg(IONFszfY0y3ZLwVnJMAuSmTbQk=YoAMfqm37GyFxbuKTt6e8CESHrhB,FC5hPWRD4XNjaSdtK8AvEkVrpc3OHu=[]):
	DsMhlFwcHSn0z16A8Vi9t = [Nk7BzXcC5VbpSanw,RpmwIQ5vaFkP8SuNW]+FC5hPWRD4XNjaSdtK8AvEkVrpc3OHu
	for bkVfIexwAzsqrS9gj in KiTt9ZskMLjnCAUIJNXD7.listdir(nZ5AkguavpEc7zWo8SOHRD):
		if IONFszfY0y3ZLwVnJMAuSmTbQk and (bkVfIexwAzsqrS9gj.startswith(bDt7Ya1VEio3(u"ࠪ࡭ࡵࡺࡶࠨඨ")) or bkVfIexwAzsqrS9gj.startswith(OOhnpQ8XvCVclGqdu(u"ࠫࡲ࠹ࡵࠨඩ"))): continue
		if bkVfIexwAzsqrS9gj.startswith(svULcgJ7jm(u"ࠬ࡬ࡩ࡭ࡧࡢࠫඪ")): continue
		z7ofJtVb0LOrmgQHYNvcx2qRKdTXkW = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,bkVfIexwAzsqrS9gj)
		if z7ofJtVb0LOrmgQHYNvcx2qRKdTXkW in DsMhlFwcHSn0z16A8Vi9t: continue
		try: KiTt9ZskMLjnCAUIJNXD7.remove(z7ofJtVb0LOrmgQHYNvcx2qRKdTXkW)
		except: pass
	if UE7QOpJtiYsfF8bTd4vVowZ not in DsMhlFwcHSn0z16A8Vi9t: eB8jr3L1inmU6OzINJd(UE7QOpJtiYsfF8bTd4vVowZ,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	B3TKLo71hAGRqYgV0.sleep(pTwKPmzMSZhil5d2RWonre(u"࠲ዻ"))
	return
def maBukhsnrVxtlIOMec2zAd3o8HSfZG(M6XZb3oDHwxjndL9yAVv,vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,L7hdwV2QJmK8CtWEkGRanu=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp+aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ණ")+M6XZb3oDHwxjndL9yAVv
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2,L7hdwV2QJmK8CtWEkGRanu)
	if iCr0xsqwDZXLPaJK1W5YU24F6hp in lE7ZB0CTayhKItApFnYxz.content: lE7ZB0CTayhKItApFnYxz.succeeded = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if not lE7ZB0CTayhKItApFnYxz.succeeded:
		ksV5ngvbcaS8ByMLYxlfXh()
	return lE7ZB0CTayhKItApFnYxz
def DaeRfBAGPd741uT2Yy(iCr0xsqwDZXLPaJK1W5YU24F6hp):
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡈࡇࡗࠫඬ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,QigevCplXxbPI1H,QigevCplXxbPI1H,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩත"),XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	PPGanWTsDhwK15CEIF = []
	if lE7ZB0CTayhKItApFnYxz.succeeded:
		zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
		kYHlpfqILCyd3Kr2X6A = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠩࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡨࢀ࠷ࠬ࠴ࡿࡰࡷࠬථ"),zHrPxh0aevGnlKMTdjQsV)
		if kYHlpfqILCyd3Kr2X6A: zHrPxh0aevGnlKMTdjQsV = aSBkt4OU8JpWTEzVIHjAiv.join(kYHlpfqILCyd3Kr2X6A)
		mPJ5ulvnZQzNs = zHrPxh0aevGnlKMTdjQsV.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H).strip(aSBkt4OU8JpWTEzVIHjAiv).split(aSBkt4OU8JpWTEzVIHjAiv)
		PPGanWTsDhwK15CEIF = []
		for M6XZb3oDHwxjndL9yAVv in mPJ5ulvnZQzNs:
			if M6XZb3oDHwxjndL9yAVv.count(y5yX4jh6kUEgWZQIc(u"ࠪ࠲ࠬද"))==mVjHAyIwzSNKLFcd: PPGanWTsDhwK15CEIF.append(M6XZb3oDHwxjndL9yAVv)
	return PPGanWTsDhwK15CEIF
def chBoC51wvd(*aargs):
	vEZIsMJqNFu71Tzjm26dgnre = FF70emVxhWOngCty(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡰࡪ࠰ࡳࡶࡴࡾࡹࡴࡥࡵࡥࡵ࡫࠮ࡤࡱࡰ࠳ࡻ࠸࠯ࡀࡴࡨࡵࡺ࡫ࡳࡵ࠿ࡧ࡭ࡸࡶ࡬ࡢࡻࡳࡶࡴࡾࡩࡦࡵࠩࡴࡷࡵࡸࡺࡶࡼࡴࡪࡃࡨࡵࡶࡳࠪࡹ࡯࡭ࡦࡱࡸࡸࡂ࠷࠰࠱࠲࠳ࠪࡸࡹ࡬࠾ࡻࡨࡷࠫࡲࡩ࡮࡫ࡷࡁ࠶࠶ࠦࡤࡱࡸࡲࡹࡸࡹ࠾ࡐࡏ࠰ࡇࡋࠬࡅࡇ࠯ࡊࡗ࠲ࡇࡃ࠮ࡗࡖࠬධ")
	jOpQTc2blF3NW8awSvhCsmE7ozfg = O4ylJvVNwLztdiHqBWDU(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡵ࡯ࡴࡶࡨࡶࡰ࡯ࡤ࠰ࡱࡳࡩࡳࡶࡲࡰࡺࡼࡰ࡮ࡹࡴ࠰࡯ࡤ࡭ࡳ࠵ࡈࡕࡖࡓࡗ࠳ࡺࡸࡵࠩන")
	HlQZ6iS0XvPRYd5fUL = DaeRfBAGPd741uT2Yy(jOpQTc2blF3NW8awSvhCsmE7ozfg)
	PPGanWTsDhwK15CEIF = DaeRfBAGPd741uT2Yy(vEZIsMJqNFu71Tzjm26dgnre)
	akopD6zYySPIwh1Vq = HlQZ6iS0XvPRYd5fUL+PPGanWTsDhwK15CEIF
	SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+svULcgJ7jm(u"࠭ࠠࠡࠢࡊࡳࡹࠦࡰࡳࡱࡻ࡭ࡪࡹࠠ࡭࡫ࡶࡸࠥࠦࠠ࠲ࡵࡷ࠯࠷ࡴࡤ࠻ࠢ࡞ࠤࠬ඲")+str(len(HlQZ6iS0XvPRYd5fUL))+FF70emVxhWOngCty(u"ࠧࠬࠩඳ")+str(len(PPGanWTsDhwK15CEIF))+svULcgJ7jm(u"ࠨࠢࡠࠫප"))
	M6XZb3oDHwxjndL9yAVv = uUTRHgAXJzm7pIDBjNt8.getSetting(TCF8wLyDvgumfiXPSKRh(u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩඵ"))
	lE7ZB0CTayhKItApFnYxz = aTqvbmueLIYkRjSODlK8BCW()
	uUTRHgAXJzm7pIDBjNt8.setSetting(FF70emVxhWOngCty(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪබ"),QigevCplXxbPI1H)
	if M6XZb3oDHwxjndL9yAVv or akopD6zYySPIwh1Vq:
		jfRgOv7BWL9T8y,XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = h17Zb2ld4yLBrCP5tiw,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠳࠳ዼ")
		sOpTXuqz51ohe = len(akopD6zYySPIwh1Vq)
		ZZi1feDL7vRAaIQ0sto9z = XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc
		if sOpTXuqz51ohe>ZZi1feDL7vRAaIQ0sto9z: fHAlBD1Tj9PELecGvayit6JwWn87bd = ZZi1feDL7vRAaIQ0sto9z
		else: fHAlBD1Tj9PELecGvayit6JwWn87bd = sOpTXuqz51ohe
		EEHNp9qtKdRgmUfhYxnM8eQ7 = yarjPEMGV6m7fHRFeJXt.sample(akopD6zYySPIwh1Vq,fHAlBD1Tj9PELecGvayit6JwWn87bd)
		if M6XZb3oDHwxjndL9yAVv: EEHNp9qtKdRgmUfhYxnM8eQ7 = [M6XZb3oDHwxjndL9yAVv]+EEHNp9qtKdRgmUfhYxnM8eQ7
		DOFXfdljq9m3n5rVzWvQ2JE = UZ28903VuMoInShOjv4zpYDFxliy(YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		T9Ax7pUEP6Ilg4cC = B3TKLo71hAGRqYgV0.time()
		while B3TKLo71hAGRqYgV0.time()-T9Ax7pUEP6Ilg4cC<=XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc and not DOFXfdljq9m3n5rVzWvQ2JE.finishedLIST:
			if jfRgOv7BWL9T8y<fHAlBD1Tj9PELecGvayit6JwWn87bd:
				M6XZb3oDHwxjndL9yAVv = EEHNp9qtKdRgmUfhYxnM8eQ7[jfRgOv7BWL9T8y]
				DOFXfdljq9m3n5rVzWvQ2JE.jxT7SROozva0I9(jfRgOv7BWL9T8y,maBukhsnrVxtlIOMec2zAd3o8HSfZG,M6XZb3oDHwxjndL9yAVv,*aargs)
			B3TKLo71hAGRqYgV0.sleep(tOrSvd8QKNB(u"࠳࠲࠼࠻ዽ"))
			jfRgOv7BWL9T8y += nfC2im3NzUQk
			SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+g4UCaNkHvLwGhjmW(u"ࠫࠥࠦࠠࡕࡴࡼ࡭ࡳ࡭࠺ࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭භ")+M6XZb3oDHwxjndL9yAVv+s0vAWcLSXEToH9Mik134q(u"ࠬࠦ࡝ࠨම"))
		finishedLIST = DOFXfdljq9m3n5rVzWvQ2JE.finishedLIST
		if finishedLIST:
			resultsDICT = DOFXfdljq9m3n5rVzWvQ2JE.resultsDICT
			DvIMgS2fypeK49UiBZ = finishedLIST[h17Zb2ld4yLBrCP5tiw]
			lE7ZB0CTayhKItApFnYxz = resultsDICT[DvIMgS2fypeK49UiBZ]
			M6XZb3oDHwxjndL9yAVv = EEHNp9qtKdRgmUfhYxnM8eQ7[int(DvIMgS2fypeK49UiBZ)]
			uUTRHgAXJzm7pIDBjNt8.setSetting(y5yX4jh6kUEgWZQIc(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭ඹ"),M6XZb3oDHwxjndL9yAVv)
			if DvIMgS2fypeK49UiBZ!=h17Zb2ld4yLBrCP5tiw: SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+g4UCaNkHvLwGhjmW(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪය")+M6XZb3oDHwxjndL9yAVv+s0vAWcLSXEToH9Mik134q(u"ࠨࠢࡠࠫර"))
			else: SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+JJu4MPClbTFpUwHiN(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡖࡥࡻ࡫ࡤࠡࡲࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ඼")+M6XZb3oDHwxjndL9yAVv+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࠤࡢ࠭ල"))
	return lE7ZB0CTayhKItApFnYxz
def EcMoKBLhr0ZfdJP(N2CrvQs8jFGW5Z7E,aamzjlvJfDIsVxrOYLgnXMo49kN2Z):
	C2bMXu86VGNF04OEZ = N2CrvQs8jFGW5Z7E.create_connection
	def phRzlcJxLX4aWYUV8(k1hM0T3gGzLlywi,*aargs,**kkwargs):
		yZTHwRpAJvK0hSaN,WJTvd2IYiz5S = k1hM0T3gGzLlywi
		ip = u3uZaBnIvki0TFMzdbQo6VUjRgEL(yZTHwRpAJvK0hSaN,aamzjlvJfDIsVxrOYLgnXMo49kN2Z)
		if ip: yZTHwRpAJvK0hSaN = ip[h17Zb2ld4yLBrCP5tiw]
		else:
			if aamzjlvJfDIsVxrOYLgnXMo49kN2Z in ye5VdS961JgscKZjAp0HXnT: ye5VdS961JgscKZjAp0HXnT.remove(aamzjlvJfDIsVxrOYLgnXMo49kN2Z)
			if ye5VdS961JgscKZjAp0HXnT:
				vXW3H2169q = ye5VdS961JgscKZjAp0HXnT[h17Zb2ld4yLBrCP5tiw]
				ip = u3uZaBnIvki0TFMzdbQo6VUjRgEL(yZTHwRpAJvK0hSaN,vXW3H2169q)
				if ip: yZTHwRpAJvK0hSaN = ip[h17Zb2ld4yLBrCP5tiw]
		k1hM0T3gGzLlywi = (yZTHwRpAJvK0hSaN,WJTvd2IYiz5S)
		return C2bMXu86VGNF04OEZ(k1hM0T3gGzLlywi,*aargs,**kkwargs)
	N2CrvQs8jFGW5Z7E.create_connection = phRzlcJxLX4aWYUV8
	return C2bMXu86VGNF04OEZ
def eLxbTZMtnaDXoEqYz2pjIP0(iCr0xsqwDZXLPaJK1W5YU24F6hp):
	AavIb42HSOx8nT75wUYhmi,fnCu4I9pVkvAQyi1 = iCr0xsqwDZXLPaJK1W5YU24F6hp.split(pGncXOodjKhJzLSqVP1r(u"ࠫ࠴࠭඾"))[JxuTQLOD357o41evylqPmRdf],g4UCaNkHvLwGhjmW(u"࠼࠵ዾ")
	if VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡀࠧ඿") in AavIb42HSOx8nT75wUYhmi: AavIb42HSOx8nT75wUYhmi,fnCu4I9pVkvAQyi1 = AavIb42HSOx8nT75wUYhmi.split(mpusoZBJ6V(u"࠭࠺ࠨව"))
	HjCismAWZP4BukgvnSLf5V = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧ࠰ࠩශ")+s0vAWcLSXEToH9Mik134q(u"ࠨ࠱ࠪෂ").join(iCr0xsqwDZXLPaJK1W5YU24F6hp.split(pGncXOodjKhJzLSqVP1r(u"ࠩ࠲ࠫස"))[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠸ዿ"):])
	x9Ahuz3FVWmJDaNp5 = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡋࡊ࡚ࠠࠨහ")+HjCismAWZP4BukgvnSLf5V+mpusoZBJ6V(u"ࠫࠥࡎࡔࡕࡒ࠲࠵࠳࠷࡜ࡳ࡞ࡱࠫළ")
	x9Ahuz3FVWmJDaNp5 += TCF8wLyDvgumfiXPSKRh(u"ࠬࡎ࡯ࡴࡶ࠽ࠤࠬෆ")+AavIb42HSOx8nT75wUYhmi+pTwKPmzMSZhil5d2RWonre(u"࠭࡜ࡳ࡞ࡱࠫ෇")
	x9Ahuz3FVWmJDaNp5 += g4UCaNkHvLwGhjmW(u"ࠧ࡝ࡴ࡟ࡲࠬ෈")
	from socket import socket as LXYK9GkF5MnA,AF_INET as wLNAcp1EzHoU5q7t9hfTKGli0IOS,SOCK_STREAM as SYgdGcXQU74TrsHwfWz
	try:
		meIBKp2fjnJaQzCl7EigY = LXYK9GkF5MnA(wLNAcp1EzHoU5q7t9hfTKGli0IOS,SYgdGcXQU74TrsHwfWz)
		meIBKp2fjnJaQzCl7EigY.connect((AavIb42HSOx8nT75wUYhmi,fnCu4I9pVkvAQyi1))
		meIBKp2fjnJaQzCl7EigY.send(x9Ahuz3FVWmJDaNp5.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL))
		TTMIXfheV4t = meIBKp2fjnJaQzCl7EigY.recv(tOrSvd8QKNB(u"࠴࠱࠻࠹ጁ")*pGncXOodjKhJzLSqVP1r(u"࠷࠰࠳࠶ጀ"))
		zHrPxh0aevGnlKMTdjQsV = repr(TTMIXfheV4t)
	except: zHrPxh0aevGnlKMTdjQsV = QigevCplXxbPI1H
	return zHrPxh0aevGnlKMTdjQsV
def gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(g2JSOX0pTIYL6,NWdTSkYP5E6wqsDogApZmLCcbu3j2I):
	if vZL6j4tSClIGxzNE5DX(u"ࠨ࠰ࠪ෉") not in g2JSOX0pTIYL6: return g2JSOX0pTIYL6
	g2JSOX0pTIYL6 = g2JSOX0pTIYL6+Fg72JX6T5DkPy(u"ࠩ࠲්ࠫ")
	XcriNsJ0L9OAqZMCvP,kzC4uMJcZQDFv01ePgTVrbXnWB6Utp = g2JSOX0pTIYL6.split(y5yX4jh6kUEgWZQIc(u"ࠪ࠲ࠬ෋"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠲ጂ"))
	IJBCtbrk7yRYE5G1e,QySi4LFPgdWMul = kzC4uMJcZQDFv01ePgTVrbXnWB6Utp.split(pTwKPmzMSZhil5d2RWonre(u"ࠫ࠴࠭෌"),vZL6j4tSClIGxzNE5DX(u"࠳ጃ"))
	bsPadQfAGhzXtZWjR = XcriNsJ0L9OAqZMCvP+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬ࠴ࠧ෍")+IJBCtbrk7yRYE5G1e
	if NWdTSkYP5E6wqsDogApZmLCcbu3j2I in [O4ylJvVNwLztdiHqBWDU(u"࠭ࡨࡰࡵࡷࠫ෎"),TCF8wLyDvgumfiXPSKRh(u"ࠧ࡯ࡣࡰࡩࠬා")] and pTwKPmzMSZhil5d2RWonre(u"ࠨ࠱ࠪැ") in bsPadQfAGhzXtZWjR: bsPadQfAGhzXtZWjR = bsPadQfAGhzXtZWjR.rsplit(Xr2aHOK0huQ5DTS(u"ࠩ࠲ࠫෑ"),bDt7Ya1VEio3(u"࠴ጄ"))[nfC2im3NzUQk]
	if NWdTSkYP5E6wqsDogApZmLCcbu3j2I==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡲࡦࡳࡥࠨි") and WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫ࠳࠭ී") in bsPadQfAGhzXtZWjR:
		TjIfdNksbE = bsPadQfAGhzXtZWjR.split(pTwKPmzMSZhil5d2RWonre(u"ࠬ࠴ࠧු"))
		E1lpZAJBhUtv9Wnfsa8c3OL = len(TjIfdNksbE)
		if E1lpZAJBhUtv9Wnfsa8c3OL<=JxuTQLOD357o41evylqPmRdf or mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ෕") in bsPadQfAGhzXtZWjR: TjIfdNksbE = TjIfdNksbE[h17Zb2ld4yLBrCP5tiw]
		elif E1lpZAJBhUtv9Wnfsa8c3OL>=mVjHAyIwzSNKLFcd: TjIfdNksbE = TjIfdNksbE[nfC2im3NzUQk]
		if len(TjIfdNksbE)>nfC2im3NzUQk: bsPadQfAGhzXtZWjR = TjIfdNksbE
	return bsPadQfAGhzXtZWjR
def Sk3BJ4bvyposwt0mFuGnqZHg(XFbsIRACfWnrEvU1VOSmpcDZTy03):
	emIQDf0T17gon4E = repr(XFbsIRACfWnrEvU1VOSmpcDZTy03.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).replace(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠢࠨࠤූ"),QigevCplXxbPI1H)
	return emIQDf0T17gon4E
def Yrz5bs6eFPfiZQTpBSLx8nH2Kcl(GvlaiDxKhJZP):
	hGr8gjq1wpDEA = QigevCplXxbPI1H
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: GvlaiDxKhJZP = GvlaiDxKhJZP.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	from unicodedata import decomposition as GiYD6r9mKqCeP
	for S23nVld6GYQy in GvlaiDxKhJZP:
		if   S23nVld6GYQy==DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࡶࠩลࠫ෗"): LnEUshPigX2kc6Y = OTRKI6LbrQnZEm(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠴ࠪෘ")
		elif S23nVld6GYQy==TCF8wLyDvgumfiXPSKRh(u"ࡸࠫศ࠭ෙ"): LnEUshPigX2kc6Y = pGncXOodjKhJzLSqVP1r(u"ࠫࡡࡢࡵ࠱࠸࠵࠷ࠬේ")
		elif S23nVld6GYQy==mmKqLr9RX0ACN384JMcsFHzd(u"ࡺ࠭ฤࠨෛ"): LnEUshPigX2kc6Y = VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࡜࡝ࡷ࠳࠺࠷࠺ࠧො")
		elif S23nVld6GYQy==K7bLVaiRkx0lgU5SQM(u"ࡵࠨวࠪෝ"): LnEUshPigX2kc6Y = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠶ࠩෞ")
		elif S23nVld6GYQy==svULcgJ7jm(u"ࡷࠪสࠬෟ"): LnEUshPigX2kc6Y = bDt7Ya1VEio3(u"ࠪࡠࡡࡻ࠰࠷࠴࠹ࠫ෠")
		else:
			zPWNjoFyOb = GiYD6r9mKqCeP(S23nVld6GYQy)
			if hT7zFDpEyUqf8sXuN in zPWNjoFyOb: LnEUshPigX2kc6Y = OTRKI6LbrQnZEm(u"ࠫࡡࡢࡵࠨ෡")+zPWNjoFyOb.split(hT7zFDpEyUqf8sXuN,nfC2im3NzUQk)[nfC2im3NzUQk]
			else:
				LnEUshPigX2kc6Y = FF70emVxhWOngCty(u"ࠬ࠶࠰࠱࠲ࠪ෢")+hex(ord(S23nVld6GYQy)).replace(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭࠰ࡹࠩ෣"),QigevCplXxbPI1H)
				LnEUshPigX2kc6Y = pTwKPmzMSZhil5d2RWonre(u"ࠧ࡝࡞ࡸࠫ෤")+LnEUshPigX2kc6Y[-bWU9StnJOg6aIQiTMxh7sFZG8lPud:]
		hGr8gjq1wpDEA += LnEUshPigX2kc6Y
	hGr8gjq1wpDEA = hGr8gjq1wpDEA.replace(v54ZuLY6dQ(u"ࠨ࡞࡟ࡹ࠵࠼ࡃࡄࠩ෥"),TCF8wLyDvgumfiXPSKRh(u"ࠩ࡟ࡠࡺ࠶࠶࠵࠻ࠪ෦"))
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: hGr8gjq1wpDEA = hGr8gjq1wpDEA.decode(K7bLVaiRkx0lgU5SQM(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ෧")).encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	else: hGr8gjq1wpDEA = hGr8gjq1wpDEA.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL).decode(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ෨"))
	return hGr8gjq1wpDEA
def XAfEvmh95VkgurjdiJ(header=K7bLVaiRkx0lgU5SQM(u"๊่ࠬฮหࠣห้๋แศฬํัࠬ෩"),bZATrHylco1EOa03Iuw4BjF=QigevCplXxbPI1H,LowrcsSpbXjgqxvMDZ6hC8=YoAMfqm37GyFxbuKTt6e8CESHrhB,source=QigevCplXxbPI1H):
	CyarqoiHxV2e80ScjAN = uLwjTYQbBkfdV38Zq4CUrcm(header,bZATrHylco1EOa03Iuw4BjF,type=Q0BXbnOs1jr8afIyTUHZDw4lCAki7.INPUT_ALPHANUM)
	CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	if not CyarqoiHxV2e80ScjAN and not LowrcsSpbXjgqxvMDZ6hC8:
		SQdRhwozVfv(AwKhgdpmBj0,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡧࡦࡴࡣࡦ࡮ࡨࡨ࠿ࠦࠠࠡࠤࠪ෪")+CyarqoiHxV2e80ScjAN+Fg72JX6T5DkPy(u"ࠧࠣࠩ෫"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ෬"),v54ZuLY6dQ(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ละะส่ࠬ෭"))
		return QigevCplXxbPI1H
	if CyarqoiHxV2e80ScjAN not in [QigevCplXxbPI1H,hT7zFDpEyUqf8sXuN]:
		CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.strip(hT7zFDpEyUqf8sXuN)
		CyarqoiHxV2e80ScjAN = Yrz5bs6eFPfiZQTpBSLx8nH2Kcl(CyarqoiHxV2e80ScjAN)
	if source!=OOhnpQ8XvCVclGqdu(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ෮") and Q7YCG4unmP8HTL(v54ZuLY6dQ(u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭෯"),QigevCplXxbPI1H,[CyarqoiHxV2e80ScjAN],YoAMfqm37GyFxbuKTt6e8CESHrhB):
		SQdRhwozVfv(AwKhgdpmBj0,O4ylJvVNwLztdiHqBWDU(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡥࡰࡴࡩ࡫ࡦࡦ࠽ࠤࠥࠦࠢࠨ෰")+CyarqoiHxV2e80ScjAN+OTRKI6LbrQnZEm(u"࠭ࠢࠨ෱"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪෲ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨษ้ฮ้ࠥสษฬࠣ็้๋ษࠡล๋ࠤึ่ๅࠡๆ๊ࠤ฾๊วใหࠣฬศ็ไศ็่้้ࠣศศำࠣๅ็฽ࠠ࠯࠰ࠣ์์ึวࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦิ็ะࠤออำหะาห๊ࠦ็ไาสࠤ่๊ๅศฬࠪෳ"))
		return QigevCplXxbPI1H
	SQdRhwozVfv(AwKhgdpmBj0,v54ZuLY6dQ(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ෴")+CyarqoiHxV2e80ScjAN+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࠦࠬ෵"))
	return CyarqoiHxV2e80ScjAN
def HHSM1J4ofulwIPqTjnQA(Kj0TOU6BmSMlJHZYLd,T24Te3uDwBS5vLgUEAhF1O={}):
	iCr0xsqwDZXLPaJK1W5YU24F6hp,YmXhK3tODNd74z9iAUpc,IBsPJlUbjVW,mdaULEojZ4l1Cp = Kj0TOU6BmSMlJHZYLd,{},{},QigevCplXxbPI1H
	if OTRKI6LbrQnZEm(u"ࠫࢁ࠭෶") in Kj0TOU6BmSMlJHZYLd: iCr0xsqwDZXLPaJK1W5YU24F6hp,YmXhK3tODNd74z9iAUpc = b9PJzXFf4dYnGHm52NWsyA8(Kj0TOU6BmSMlJHZYLd,v54ZuLY6dQ(u"ࠬࢂࠧ෷"))
	aaZPAsgt6DFIVuWHNfBiK = list(set(list(T24Te3uDwBS5vLgUEAhF1O.keys())+list(YmXhK3tODNd74z9iAUpc.keys())))
	for QQPBwuOv2LeWXTnYygj in aaZPAsgt6DFIVuWHNfBiK:
		if QQPBwuOv2LeWXTnYygj in list(YmXhK3tODNd74z9iAUpc.keys()): IBsPJlUbjVW[QQPBwuOv2LeWXTnYygj] = YmXhK3tODNd74z9iAUpc[QQPBwuOv2LeWXTnYygj]
		else: IBsPJlUbjVW[QQPBwuOv2LeWXTnYygj] = T24Te3uDwBS5vLgUEAhF1O[QQPBwuOv2LeWXTnYygj]
	if TCF8wLyDvgumfiXPSKRh(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ෸") not in aaZPAsgt6DFIVuWHNfBiK: IBsPJlUbjVW[mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ෹")] = eUBL1rOR4ZfndJAWPsoN6pybT0()
	if VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ෺") not in aaZPAsgt6DFIVuWHNfBiK: IBsPJlUbjVW[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ෻")] = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(iCr0xsqwDZXLPaJK1W5YU24F6hp,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡹࡷࡲࠧ෼"))
	if FF70emVxhWOngCty(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭෽") not in aaZPAsgt6DFIVuWHNfBiK: IBsPJlUbjVW[y5yX4jh6kUEgWZQIc(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧ෾")] = tOrSvd8QKNB(u"࠭ࡥ࡯࠯ࡘࡗ࠱࡫࡮࠼ࡳࡀ࠴࠳࠿ࠧ෿")
	for QQPBwuOv2LeWXTnYygj in list(IBsPJlUbjVW.keys()): mdaULEojZ4l1Cp += TCF8wLyDvgumfiXPSKRh(u"ࠧࠧࠩ฀")+QQPBwuOv2LeWXTnYygj+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨ࠿ࠪก")+IBsPJlUbjVW[QQPBwuOv2LeWXTnYygj]
	if mdaULEojZ4l1Cp: mdaULEojZ4l1Cp = O4ylJvVNwLztdiHqBWDU(u"ࠩࡿࠫข")+mdaULEojZ4l1Cp[nfC2im3NzUQk:]
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(vMlT137PE8q4wiKpWIojraR29B,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡋࡊ࡚ࠧฃ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,QigevCplXxbPI1H,IBsPJlUbjVW,QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡕࡔࡄࡇ࡙ࡥࡍ࠴ࡗ࠻࠱࠶ࡹࡴࠨค"),YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
	if s0vAWcLSXEToH9Mik134q(u"࡙ࠬࡔࡓࡇࡄࡑ࠲ࡏࡎࡇࠩฅ") not in zHrPxh0aevGnlKMTdjQsV: return [tOrSvd8QKNB(u"࠭࠭࠲ࠩฆ")],[iCr0xsqwDZXLPaJK1W5YU24F6hp+mdaULEojZ4l1Cp]
	if NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫง") in zHrPxh0aevGnlKMTdjQsV: return [y5yX4jh6kUEgWZQIc(u"ࠨ࠯࠴ࠫจ")],[iCr0xsqwDZXLPaJK1W5YU24F6hp+mdaULEojZ4l1Cp]
	if FF70emVxhWOngCty(u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭ฉ") in zHrPxh0aevGnlKMTdjQsV: return [mpusoZBJ6V(u"ࠪ࠱࠶࠭ช")],[iCr0xsqwDZXLPaJK1W5YU24F6hp+mdaULEojZ4l1Cp]
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,rEnLiVCqW5T3YShDPJv7xsG14,ebmGtB4paUOD5YREflJsIoWLFM = [],[],[],[]
	pS1FVtbXfLgZ0nxY3eTzqGd = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠫࠨࡋࡘࡕ࠯࡛࠱ࡘ࡚ࡒࡆࡃࡐ࠱ࡎࡔࡆ࠻ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬซ"),zHrPxh0aevGnlKMTdjQsV+aSBkt4OU8JpWTEzVIHjAiv,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not pS1FVtbXfLgZ0nxY3eTzqGd: return [Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬ࠳࠱ࠨฌ")],[iCr0xsqwDZXLPaJK1W5YU24F6hp+mdaULEojZ4l1Cp]
	for U6ZM8BVcn1re7STQLsEgxk3oJK,g2JSOX0pTIYL6 in pS1FVtbXfLgZ0nxY3eTzqGd:
		cAqrWYQotbHGK74DT9xOJgsMNnP0hi,yQ0ebFuxaJkWsPS,oI6LvXMf4VEPe8jOdpKC0hUmS = {},-DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠵ጅ"),-DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠵ጅ")
		JhXbzan4NImVM3E = QigevCplXxbPI1H
		XQAwCuWTdbcq0tSfvmMOIE4pPiJ = U6ZM8BVcn1re7STQLsEgxk3oJK.split(vZL6j4tSClIGxzNE5DX(u"࠭ࠬࠨญ"))
		for a3m046bDiUGHgNtVKXMrpQCAcF in XQAwCuWTdbcq0tSfvmMOIE4pPiJ:
			if aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧ࠾ࠩฎ") in a3m046bDiUGHgNtVKXMrpQCAcF:
				QQPBwuOv2LeWXTnYygj,AWiQJuPfExS2ey3KM6cVNFv4Ypa = a3m046bDiUGHgNtVKXMrpQCAcF.split(Fg72JX6T5DkPy(u"ࠨ࠿ࠪฏ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠶ጆ"))
				cAqrWYQotbHGK74DT9xOJgsMNnP0hi[QQPBwuOv2LeWXTnYygj.lower()] = AWiQJuPfExS2ey3KM6cVNFv4Ypa
		if svULcgJ7jm(u"ࠩࡤࡺࡪࡸࡡࡨࡧ࠰ࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭ฐ") in U6ZM8BVcn1re7STQLsEgxk3oJK.lower():
			yQ0ebFuxaJkWsPS = int(cAqrWYQotbHGK74DT9xOJgsMNnP0hi[pTwKPmzMSZhil5d2RWonre(u"ࠪࡥࡻ࡫ࡲࡢࡩࡨ࠱ࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧฑ")])//svULcgJ7jm(u"࠷࠰࠳࠶ጇ")
			JhXbzan4NImVM3E += str(yQ0ebFuxaJkWsPS)+vZL6j4tSClIGxzNE5DX(u"ࠫࡰࡨࡰࡴࠢࠣࠫฒ")
		elif OOhnpQ8XvCVclGqdu(u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨณ") in U6ZM8BVcn1re7STQLsEgxk3oJK.lower():
			yQ0ebFuxaJkWsPS = int(cAqrWYQotbHGK74DT9xOJgsMNnP0hi[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩด")])//s0vAWcLSXEToH9Mik134q(u"࠱࠱࠴࠷ገ")
			JhXbzan4NImVM3E += str(yQ0ebFuxaJkWsPS)+O4ylJvVNwLztdiHqBWDU(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧต")
		if XWbHfI9B8swrOL(u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬถ") in U6ZM8BVcn1re7STQLsEgxk3oJK.lower():
			oI6LvXMf4VEPe8jOdpKC0hUmS = int(cAqrWYQotbHGK74DT9xOJgsMNnP0hi[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭ท")].split(vZL6j4tSClIGxzNE5DX(u"ࠪࡼࠬธ"))[nfC2im3NzUQk])
			JhXbzan4NImVM3E += str(oI6LvXMf4VEPe8jOdpKC0hUmS)+eZXCHufT9YW4bRErSBOLmI
		JhXbzan4NImVM3E = JhXbzan4NImVM3E.strip(eZXCHufT9YW4bRErSBOLmI)
		if not JhXbzan4NImVM3E: JhXbzan4NImVM3E = Xr2aHOK0huQ5DTS(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬน")
		if not g2JSOX0pTIYL6.startswith(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬ࡮ࡴࡵࡲࠪบ")):
			if g2JSOX0pTIYL6.startswith(Fg72JX6T5DkPy(u"࠭࠯࠰ࠩป")): g2JSOX0pTIYL6 = iCr0xsqwDZXLPaJK1W5YU24F6hp.split(mpusoZBJ6V(u"ࠧ࠻ࠩผ"),nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]+pTwKPmzMSZhil5d2RWonre(u"ࠨ࠼ࠪฝ")+g2JSOX0pTIYL6
			elif g2JSOX0pTIYL6.startswith(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩ࠲ࠫพ")): g2JSOX0pTIYL6 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(iCr0xsqwDZXLPaJK1W5YU24F6hp,v54ZuLY6dQ(u"ࠪࡹࡷࡲࠧฟ"))+g2JSOX0pTIYL6
			else: g2JSOX0pTIYL6 = iCr0xsqwDZXLPaJK1W5YU24F6hp.rsplit(mpusoZBJ6V(u"ࠫ࠴࠭ภ"),nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]+vZL6j4tSClIGxzNE5DX(u"ࠬ࠵ࠧม")+g2JSOX0pTIYL6
		if XWbHfI9B8swrOL(u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨย") in list(cAqrWYQotbHGK74DT9xOJgsMNnP0hi.keys()):
			Wdek0SptsHCKog19OBJDTRAX7m = cAqrWYQotbHGK74DT9xOJgsMNnP0hi[mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩร")]
			Wdek0SptsHCKog19OBJDTRAX7m = Wdek0SptsHCKog19OBJDTRAX7m.replace(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࠤࠪฤ"),QigevCplXxbPI1H).replace(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠤࠪࠦล"),QigevCplXxbPI1H).split(mpusoZBJ6V(u"ࠪࠧࠬฦ"),nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]
			denYhNEq72TZSD0psXick9tzg5 = z2dZ1anR6O(Wdek0SptsHCKog19OBJDTRAX7m)
			if denYhNEq72TZSD0psXick9tzg5: YIwQJyV0hAUR1EfKogObLzDMmx = JhXbzan4NImVM3E+eZXCHufT9YW4bRErSBOLmI+denYhNEq72TZSD0psXick9tzg5
			else: YIwQJyV0hAUR1EfKogObLzDMmx = JhXbzan4NImVM3E
			YIwQJyV0hAUR1EfKogObLzDMmx = YIwQJyV0hAUR1EfKogObLzDMmx+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࠥࠦࡐࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨࠫว")
			YIwQJyV0hAUR1EfKogObLzDMmx = YIwQJyV0hAUR1EfKogObLzDMmx+eZXCHufT9YW4bRErSBOLmI+gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Wdek0SptsHCKog19OBJDTRAX7m,vZL6j4tSClIGxzNE5DX(u"ࠬࡴࡡ࡮ࡧࠪศ"))
			ttGBwQOv3K41hIkc6.append(YIwQJyV0hAUR1EfKogObLzDMmx)
			ldFqnNIsftrY43JBM6LPjzU8m.append(Wdek0SptsHCKog19OBJDTRAX7m)
			rEnLiVCqW5T3YShDPJv7xsG14.append(oI6LvXMf4VEPe8jOdpKC0hUmS)
			ebmGtB4paUOD5YREflJsIoWLFM.append(yQ0ebFuxaJkWsPS)
		g2JSOX0pTIYL6 = g2JSOX0pTIYL6.split(pGncXOodjKhJzLSqVP1r(u"࠭ࠣࠨษ"),nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]
		denYhNEq72TZSD0psXick9tzg5 = z2dZ1anR6O(g2JSOX0pTIYL6)
		if denYhNEq72TZSD0psXick9tzg5: JhXbzan4NImVM3E = JhXbzan4NImVM3E+eZXCHufT9YW4bRErSBOLmI+denYhNEq72TZSD0psXick9tzg5
		JhXbzan4NImVM3E = JhXbzan4NImVM3E+eZXCHufT9YW4bRErSBOLmI+gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(g2JSOX0pTIYL6,OOhnpQ8XvCVclGqdu(u"ࠧ࡯ࡣࡰࡩࠬส"))
		ttGBwQOv3K41hIkc6.append(JhXbzan4NImVM3E)
		ldFqnNIsftrY43JBM6LPjzU8m.append(g2JSOX0pTIYL6)
		rEnLiVCqW5T3YShDPJv7xsG14.append(oI6LvXMf4VEPe8jOdpKC0hUmS)
		ebmGtB4paUOD5YREflJsIoWLFM.append(yQ0ebFuxaJkWsPS)
	w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf = list(zip(ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,rEnLiVCqW5T3YShDPJv7xsG14,ebmGtB4paUOD5YREflJsIoWLFM))
	w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf = sorted(w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf, reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD, key=lambda key: key[mVjHAyIwzSNKLFcd])
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,rEnLiVCqW5T3YShDPJv7xsG14,ebmGtB4paUOD5YREflJsIoWLFM = list(zip(*w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf))
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = list(ttGBwQOv3K41hIkc6),list(ldFqnNIsftrY43JBM6LPjzU8m)
	kQlGI4ouaPwteZq9XgKB02 = []
	for g2JSOX0pTIYL6 in ldFqnNIsftrY43JBM6LPjzU8m: kQlGI4ouaPwteZq9XgKB02.append(g2JSOX0pTIYL6+mdaULEojZ4l1Cp)
	return ttGBwQOv3K41hIkc6,kQlGI4ouaPwteZq9XgKB02
def u3uZaBnIvki0TFMzdbQo6VUjRgEL(yZTHwRpAJvK0hSaN,aamzjlvJfDIsVxrOYLgnXMo49kN2Z=QigevCplXxbPI1H):
	if not aamzjlvJfDIsVxrOYLgnXMo49kN2Z: aamzjlvJfDIsVxrOYLgnXMo49kN2Z = ye5VdS961JgscKZjAp0HXnT[h17Zb2ld4yLBrCP5tiw]
	if yZTHwRpAJvK0hSaN.replace(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨ࠰ࠪห"),QigevCplXxbPI1H).isdigit(): return [yZTHwRpAJvK0hSaN]
	from struct import pack as X8svUAeZWr,unpack_from as qZNutF5VQ7
	from socket import socket as LXYK9GkF5MnA,AF_INET as wLNAcp1EzHoU5q7t9hfTKGli0IOS,SOCK_DGRAM as Ox4TF7dJm6CzLafwpoq1t9U
	try:
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh = X8svUAeZWr(tOrSvd8QKNB(u"ࠤࡁࡌࠧฬ"), v54ZuLY6dQ(u"࠲࠴࠳࠸࠾ጉ"))
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠥࡂࡍࠨอ"), Fg72JX6T5DkPy(u"࠴࠸࠺ጊ"))
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(Fg72JX6T5DkPy(u"ࠦࡃࡎࠢฮ"), nfC2im3NzUQk)
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡄࡈࠣฯ"), h17Zb2ld4yLBrCP5tiw)
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࠾ࡉࠤะ"), h17Zb2ld4yLBrCP5tiw)
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(y5yX4jh6kUEgWZQIc(u"ࠢ࠿ࡊࠥั"), h17Zb2ld4yLBrCP5tiw)
		if b7sJAmSxlBvaMdHFz: cIXqK54Pu9je = yZTHwRpAJvK0hSaN.split(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࠰ࠪา"))
		else: cIXqK54Pu9je = yZTHwRpAJvK0hSaN.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL).split(vZL6j4tSClIGxzNE5DX(u"ࠩ࠱ࠫำ"))
		for F9sJPmAzXvWdtjS2b50p in cIXqK54Pu9je:
			OUg7Vni1RpwJ = F9sJPmAzXvWdtjS2b50p.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(Fg72JX6T5DkPy(u"ࠥࡆࠧิ"), len(F9sJPmAzXvWdtjS2b50p))
			for m0wquAX6hrVLF in F9sJPmAzXvWdtjS2b50p:
				iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(OTRKI6LbrQnZEm(u"ࠦࡨࠨี"), m0wquAX6hrVLF.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL))
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡈࠢึ"), h17Zb2ld4yLBrCP5tiw)
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨ࠾ࡉࠤื"), nfC2im3NzUQk)
		iIQsKNH53RPqSoEnFTfp64tJ87Ozh += X8svUAeZWr(K7bLVaiRkx0lgU5SQM(u"ࠢ࠿ࡊุࠥ"), nfC2im3NzUQk)
		Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM = LXYK9GkF5MnA(wLNAcp1EzHoU5q7t9hfTKGli0IOS,Ox4TF7dJm6CzLafwpoq1t9U)
		Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM.sendto(bytes(iIQsKNH53RPqSoEnFTfp64tJ87Ozh), (aamzjlvJfDIsVxrOYLgnXMo49kN2Z, bDt7Ya1VEio3(u"࠸࠷ጋ")))
		Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM.settimeout(OOhnpQ8XvCVclGqdu(u"࠺ጌ"))
		VV4iSgTwskE6uyoBCl3ZDh7HQ, k2yCvWVNDApni = Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM.recvfrom(v54ZuLY6dQ(u"࠶࠶࠲࠵ግ"))
		Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM.close()
		NYbMOQZnUu2Jzec = qZNutF5VQ7(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤู"), VV4iSgTwskE6uyoBCl3ZDh7HQ, h17Zb2ld4yLBrCP5tiw)
		VVI2FBv34hNA5MHp9 = NYbMOQZnUu2Jzec[mVjHAyIwzSNKLFcd]
		QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX = len(yZTHwRpAJvK0hSaN)+v54ZuLY6dQ(u"࠷࠸ጎ")
		rr4e95RPASc = []
		for _UA09Z7eIH2cxbin in range(VVI2FBv34hNA5MHp9):
			oVvb1TsM3Z0f = QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX
			R94U2G0rEgkqj = nfC2im3NzUQk
			y2yuNiHaFAJ6l9r8WRZ = YoAMfqm37GyFxbuKTt6e8CESHrhB
			while XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
				m0wquAX6hrVLF = qZNutF5VQ7(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠤࡁࡆฺࠧ"), VV4iSgTwskE6uyoBCl3ZDh7HQ, oVvb1TsM3Z0f)[h17Zb2ld4yLBrCP5tiw]
				if m0wquAX6hrVLF == h17Zb2ld4yLBrCP5tiw:
					oVvb1TsM3Z0f += nfC2im3NzUQk
					break
				if m0wquAX6hrVLF >= v54ZuLY6dQ(u"࠱࠺࠴ጏ"):
					swz1ZykVJSQv8WBPDbGXd4O = qZNutF5VQ7(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠥࡂࡇࠨ฻"), VV4iSgTwskE6uyoBCl3ZDh7HQ, oVvb1TsM3Z0f + nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]
					oVvb1TsM3Z0f = ((m0wquAX6hrVLF << O4ylJvVNwLztdiHqBWDU(u"࠹ጐ")) + swz1ZykVJSQv8WBPDbGXd4O - 0xc000) - nfC2im3NzUQk
					y2yuNiHaFAJ6l9r8WRZ = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
				oVvb1TsM3Z0f += nfC2im3NzUQk
				if y2yuNiHaFAJ6l9r8WRZ == YoAMfqm37GyFxbuKTt6e8CESHrhB: R94U2G0rEgkqj += nfC2im3NzUQk
			if y2yuNiHaFAJ6l9r8WRZ == XpREPf7d08GnIS6i4KNLMyZHmuQqxD: R94U2G0rEgkqj += nfC2im3NzUQk
			QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX = QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX + R94U2G0rEgkqj
			OxV9TvFr3PN82QlM7ocU4Gp5m0Wfj = qZNutF5VQ7(v54ZuLY6dQ(u"ࠦࡃࡎࡈࡊࡊࠥ฼"), VV4iSgTwskE6uyoBCl3ZDh7HQ, QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX)
			QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX = QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX + XWbHfI9B8swrOL(u"࠳࠳጑")
			AxFomydCEU9iMjgKQtqc7Je = OxV9TvFr3PN82QlM7ocU4Gp5m0Wfj[h17Zb2ld4yLBrCP5tiw]
			Yn3sIVAPBkCZX5twgqJad4 = OxV9TvFr3PN82QlM7ocU4Gp5m0Wfj[mVjHAyIwzSNKLFcd]
			if AxFomydCEU9iMjgKQtqc7Je == nfC2im3NzUQk:
				X9HWaMxeyjSs = qZNutF5VQ7(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡄࠢ฽")+TCF8wLyDvgumfiXPSKRh(u"ࠨࡂࠣ฾")*Yn3sIVAPBkCZX5twgqJad4, VV4iSgTwskE6uyoBCl3ZDh7HQ, QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX)
				ip = QigevCplXxbPI1H
				for m0wquAX6hrVLF in X9HWaMxeyjSs: ip += str(m0wquAX6hrVLF) + hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧ࠯ࠩ฿")
				ip = ip[h17Zb2ld4yLBrCP5tiw:-nfC2im3NzUQk]
				rr4e95RPASc.append(ip)
			if AxFomydCEU9iMjgKQtqc7Je in [nfC2im3NzUQk,JxuTQLOD357o41evylqPmRdf,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠺ጔ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠼ጕ"),Xr2aHOK0huQ5DTS(u"࠵࠺ጓ"),mpusoZBJ6V(u"࠵࠼ጒ")]: QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX = QRP1ezmaDTVhLJ9WfZOSt3c5Id2KX + Yn3sIVAPBkCZX5twgqJad4
	except: rr4e95RPASc = []
	if not rr4e95RPASc: SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OTRKI6LbrQnZEm(u"ࠨࠢࠣࠤࡉࡔࡓࡠࡔࡈࡗࡔࡒࡖࡆࡔࠣࡪࡦ࡯࡬ࡦࡦࠣࠤࠥࡎ࡯ࡴࡶ࠽ࠤࡠࠦࠧเ")+yZTHwRpAJvK0hSaN+mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࠣࡡࠬแ"))
	return rr4e95RPASc
def Q7YCG4unmP8HTL(PuT0IphGNsketAQ,iCr0xsqwDZXLPaJK1W5YU24F6hp,eFQorJTmf8xANMbKW9sl,showDialogs=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	if eFQorJTmf8xANMbKW9sl:
		HKhimsMWYdnUf5XlE7SgDPjxZyBu8O = [FF70emVxhWOngCty(u"ࠪ็ออัࠨโ"),mpusoZBJ6V(u"ࠫออไ฻ࠩใ"),tOrSvd8QKNB(u"ࠬࡧࡤࡶ࡮ࡷࠫไ"),tg9l25NH6WTacVSifLyAmY(u"࠭ࡸࡹࠩๅ"),v54ZuLY6dQ(u"ࠧࡴࡧࡻࠫๆ")]
		if PuT0IphGNsketAQ!=g4UCaNkHvLwGhjmW(u"ࠨࡄࡒࡏࡗࡇࠧ็"):
			HKhimsMWYdnUf5XlE7SgDPjxZyBu8O += [JJu4MPClbTFpUwHiN(u"ࠩࡵ࠾่ࠬ"),O4ylJvVNwLztdiHqBWDU(u"ࠪࡶ࠲้࠭"),bDt7Ya1VEio3(u"ࠫ࠲ࡳࡡࠨ๊")]
			HKhimsMWYdnUf5XlE7SgDPjxZyBu8O += [tg9l25NH6WTacVSifLyAmY(u"ࠬࡀࡲࠨ๋"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࠭ࡳࠩ์"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧ࡮ࡣ࠰ࠫํ")]
		for apu6oDVjmgIHPFKyNnUsA7O10G9t in eFQorJTmf8xANMbKW9sl:
			if y5yX4jh6kUEgWZQIc(u"ࠨࡩࡨࡸ࠳ࡶࡨࡱࡁࠪ๎") in apu6oDVjmgIHPFKyNnUsA7O10G9t: continue
			if TCF8wLyDvgumfiXPSKRh(u"ࠩะ่็ฯࠧ๏") in apu6oDVjmgIHPFKyNnUsA7O10G9t: continue
			apu6oDVjmgIHPFKyNnUsA7O10G9t = apu6oDVjmgIHPFKyNnUsA7O10G9t.lower()
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: apu6oDVjmgIHPFKyNnUsA7O10G9t = apu6oDVjmgIHPFKyNnUsA7O10G9t.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL).encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			apu6oDVjmgIHPFKyNnUsA7O10G9t = apu6oDVjmgIHPFKyNnUsA7O10G9t.replace(tg9l25NH6WTacVSifLyAmY(u"ࠪ࠾ࠬ๐"),QigevCplXxbPI1H)
			arpN2gRULw86Xce7Z = sBvufaD6c9YHdOqTjCQ3.findall(tg9l25NH6WTacVSifLyAmY(u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ๑"),apu6oDVjmgIHPFKyNnUsA7O10G9t,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			ufJ1c5Nesyxl = YoAMfqm37GyFxbuKTt6e8CESHrhB
			for AOjaIe3rhEQYsCzViJd45gt in arpN2gRULw86Xce7Z:
				if len(AOjaIe3rhEQYsCzViJd45gt)==JxuTQLOD357o41evylqPmRdf:
					ufJ1c5Nesyxl = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
					break
			if TCF8wLyDvgumfiXPSKRh(u"ࠬࡴ࡯ࡵࠢࡵࡥࡹ࡫ࡤࠨ๒") in apu6oDVjmgIHPFKyNnUsA7O10G9t: continue
			elif Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡵ࡯ࡴࡤࡸࡪࡪࠧ๓") in apu6oDVjmgIHPFKyNnUsA7O10G9t: continue
			elif y5yX4jh6kUEgWZQIc(u"ࠧ฻์ิࠤ๊฻ๆโࠩ๔") in apu6oDVjmgIHPFKyNnUsA7O10G9t: continue
			elif nVIdjZ1ybeU8TB9tSpAQH(mpusoZBJ6V(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡖࡖ࡛ࡔࡕࡖ࡮࡙ࡈ࡛ࡋࡖࡆ࡚ࠪ๕")): continue
			elif apu6oDVjmgIHPFKyNnUsA7O10G9t in [svULcgJ7jm(u"ࠩࡵࠫ๖")] or ufJ1c5Nesyxl or any(nFdGHjceZzW in apu6oDVjmgIHPFKyNnUsA7O10G9t for nFdGHjceZzW in HKhimsMWYdnUf5XlE7SgDPjxZyBu8O):
				SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+Fg72JX6T5DkPy(u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ๗")+iCr0xsqwDZXLPaJK1W5YU24F6hp+FF70emVxhWOngCty(u"ࠫࠥࡣࠧ๘"))
				if showDialogs: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(Fg72JX6T5DkPy(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ๙"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ๚"))
				return XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	return YoAMfqm37GyFxbuKTt6e8CESHrhB
def lKfIRYspw15BD8vgtoAP(*aargs,**kkwargs):
	if aargs:
		direction = aargs[h17Zb2ld4yLBrCP5tiw]
		HPzXOoaMhvUySC0pcQgntFx = aargs[nfC2im3NzUQk]
		if not direction: direction = tg9l25NH6WTacVSifLyAmY(u"ࠧࡤࡧࡱࡸࡪࡸࠧ๛")
		if not HPzXOoaMhvUySC0pcQgntFx: HPzXOoaMhvUySC0pcQgntFx = vZL6j4tSClIGxzNE5DX(u"ࠨษึฮ๊ืวาࠩ๜")
		V8VAj094OkMXUcYberdEDHLK = aargs[JxuTQLOD357o41evylqPmRdf]
		CyarqoiHxV2e80ScjAN = aSBkt4OU8JpWTEzVIHjAiv.join(aargs[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠳጖"):])
	else: direction,HPzXOoaMhvUySC0pcQgntFx,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN = QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡒࡏࠬ๝"),QigevCplXxbPI1H,QigevCplXxbPI1H
	L2Lu1MQVHhiTX0(direction,QigevCplXxbPI1H,HPzXOoaMhvUySC0pcQgntFx,QigevCplXxbPI1H,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,**kkwargs)
	return
def UJV3rPyElz5xRav0FD(*aargs,**kkwargs):
	direction = aargs[h17Zb2ld4yLBrCP5tiw]
	ppIOfg9nQ6hlmuV0TL1Js = aargs[nfC2im3NzUQk]
	PuzUSLVYgMW = aargs[JxuTQLOD357o41evylqPmRdf]
	if PuzUSLVYgMW or ppIOfg9nQ6hlmuV0TL1Js: pr9waW1JYueSVXcy6h = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	else: pr9waW1JYueSVXcy6h = YoAMfqm37GyFxbuKTt6e8CESHrhB
	V8VAj094OkMXUcYberdEDHLK = aargs[mVjHAyIwzSNKLFcd]
	CyarqoiHxV2e80ScjAN = aargs[bWU9StnJOg6aIQiTMxh7sFZG8lPud]
	if not direction: direction = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡧࡪࡴࡴࡦࡴࠪ๞")
	if not ppIOfg9nQ6hlmuV0TL1Js: ppIOfg9nQ6hlmuV0TL1Js = OOhnpQ8XvCVclGqdu(u"่๊ࠫวࠡࠢࡑࡳࠬ๟")
	if not PuzUSLVYgMW: PuzUSLVYgMW = bDt7Ya1VEio3(u"ࠬ์ูๆࠢࠣ࡝ࡪࡹࠧ๠")
	if len(aargs)>=v54ZuLY6dQ(u"࠸ጘ"): CyarqoiHxV2e80ScjAN += aSBkt4OU8JpWTEzVIHjAiv+aargs[svULcgJ7jm(u"࠶጗")]
	if len(aargs)>=fk8jc5uDLX16qrih3ZaPxsvO(u"࠺ጙ"): CyarqoiHxV2e80ScjAN += aSBkt4OU8JpWTEzVIHjAiv+aargs[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠺ጚ")]
	qqTR9xfSyG0j43H = L2Lu1MQVHhiTX0(direction,ppIOfg9nQ6hlmuV0TL1Js,QigevCplXxbPI1H,PuzUSLVYgMW,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,**kkwargs)
	if qqTR9xfSyG0j43H==-hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠶ጛ") and pr9waW1JYueSVXcy6h: qqTR9xfSyG0j43H = -nfC2im3NzUQk
	elif qqTR9xfSyG0j43H==-nfC2im3NzUQk and not pr9waW1JYueSVXcy6h: qqTR9xfSyG0j43H = YoAMfqm37GyFxbuKTt6e8CESHrhB
	elif qqTR9xfSyG0j43H==h17Zb2ld4yLBrCP5tiw: qqTR9xfSyG0j43H = YoAMfqm37GyFxbuKTt6e8CESHrhB
	elif qqTR9xfSyG0j43H==JxuTQLOD357o41evylqPmRdf: qqTR9xfSyG0j43H = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	return qqTR9xfSyG0j43H
def zYWJO03iISD(*aargs,**kkwargs):
	return Q0BXbnOs1jr8afIyTUHZDw4lCAki7.Dialog().select(*aargs,**kkwargs)
def X69Fkr1VNnf2pJQC8wl7YR4HmaKc(*aargs,**kkwargs):
	V8VAj094OkMXUcYberdEDHLK = aargs[h17Zb2ld4yLBrCP5tiw]
	CyarqoiHxV2e80ScjAN = aargs[nfC2im3NzUQk]
	if Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡴࡪ࡯ࡨࠫ๡") in list(kkwargs.keys()): YP6AILv85kKu = kkwargs[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡵ࡫ࡰࡩࠬ๢")]
	else: YP6AILv85kKu = y5yX4jh6kUEgWZQIc(u"࠷࠰࠱࠲ጜ")
	if len(aargs)>JxuTQLOD357o41evylqPmRdf and hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡶ࡬ࡱࡪ࠭๣") not in aargs[JxuTQLOD357o41evylqPmRdf]: profile = aargs[JxuTQLOD357o41evylqPmRdf]
	else: profile = s0vAWcLSXEToH9Mik134q(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ๤")
	M9BrCAtKSW2Egc = Roa4WbzDQZ95UPFSwkBsujAMgLtpX2(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡊ࡯ࡤ࡫ࡪ࠴ࡸ࡮࡮ࠪ๥"),XoeSNbWwLnKC8Q,tOrSvd8QKNB(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ๦"),pGncXOodjKhJzLSqVP1r(u"ࠬ࠽࠲࠱ࡲࠪ๧"))
	image_filename = gCdTSQXzi4ua5AG6rO1YpnV.replace(FF70emVxhWOngCty(u"࠭࡟࠱࠲࠳࠴ࡤ࠭๨"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡠࠩ๩")+str(B3TKLo71hAGRqYgV0.time())+bDt7Ya1VEio3(u"ࠨࡡࠪ๪"))
	image_filename = image_filename.replace(pTwKPmzMSZhil5d2RWonre(u"ࠩ࡟ࡠࠬ๫"),svULcgJ7jm(u"ࠪࡠࡡࡢ࡜ࠨ๬")).replace(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࠴࠵ࠧ๭"),OTRKI6LbrQnZEm(u"ࠬ࠵࠯࠰࠱ࠪ๮"))
	image_height = SYUGgKyAwVTOQs9nuxR04(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,profile,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࡬ࡦࡨࡷࠫ๯"),YoAMfqm37GyFxbuKTt6e8CESHrhB,image_filename)
	M9BrCAtKSW2Egc.show()
	if profile==g4UCaNkHvLwGhjmW(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ๰"):
		M9BrCAtKSW2Egc.getControl(mpusoZBJ6V(u"࠺࠲࠷࠴ጞ")).setHeight(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠲࠲࠷ጝ"))
		M9BrCAtKSW2Egc.getControl(g4UCaNkHvLwGhjmW(u"࠽࠵࠺࠰ጡ")).setPosition(JJu4MPClbTFpUwHiN(u"࠷࠸ጟ"),-hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠻࠴ጠ"))
		M9BrCAtKSW2Egc.getControl(OTRKI6LbrQnZEm(u"࠾࠶࠵࠱ጢ")).setPosition(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷࠲࠱ጣ"),-QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠱ጤ"))
		M9BrCAtKSW2Egc.getControl(pTwKPmzMSZhil5d2RWonre(u"࠷࠴࠵ጧ")).setPosition(tOrSvd8QKNB(u"࠺࠲ጥ"),-Fg72JX6T5DkPy(u"࠵࠸ጦ"))
	M9BrCAtKSW2Egc.getControl(v54ZuLY6dQ(u"࠸࠵࠷ጨ")).setVisible(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	M9BrCAtKSW2Egc.getControl(svULcgJ7jm(u"࠹࠶࠲ጩ")).setVisible(YoAMfqm37GyFxbuKTt6e8CESHrhB)
	M9BrCAtKSW2Egc.getControl(XWbHfI9B8swrOL(u"࠿࠰࠶࠲ጪ")).setImage(image_filename)
	M9BrCAtKSW2Egc.getControl(OOhnpQ8XvCVclGqdu(u"࠹࠱࠷࠳ጫ")).setHeight(image_height)
	njhv9Z1ba8lVTGrSO6QkHA7dpLDm = VVGXMeyJq25S6tf.Thread(target=avoNXi0Er8GeJYsjQRSbZHF,args=(M9BrCAtKSW2Egc,image_filename,YP6AILv85kKu))
	njhv9Z1ba8lVTGrSO6QkHA7dpLDm.start()
	return
def avoNXi0Er8GeJYsjQRSbZHF(M9BrCAtKSW2Egc,image_filename,YP6AILv85kKu):
	B3TKLo71hAGRqYgV0.sleep(YP6AILv85kKu//K7bLVaiRkx0lgU5SQM(u"࠲࠲࠳࠴࠳࠶ጬ"))
	B3TKLo71hAGRqYgV0.sleep(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠲࠱࠵࠵࠶ጭ"))
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(image_filename):
		try: KiTt9ZskMLjnCAUIJNXD7.remove(image_filename)
		except: pass
	return
def vxHN6SWyDEMjBY2ksUl9n(*aargs,**kkwargs):
	V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,profile,direction = QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ๱"),tOrSvd8QKNB(u"ࠩ࡯ࡩ࡫ࡺࠧ๲")
	if len(aargs)>=nfC2im3NzUQk: V8VAj094OkMXUcYberdEDHLK = aargs[h17Zb2ld4yLBrCP5tiw]
	if len(aargs)>=JxuTQLOD357o41evylqPmRdf: CyarqoiHxV2e80ScjAN = aargs[nfC2im3NzUQk]
	if len(aargs)>=mVjHAyIwzSNKLFcd: profile = aargs[JxuTQLOD357o41evylqPmRdf]
	if len(aargs)>=bWU9StnJOg6aIQiTMxh7sFZG8lPud: direction = aargs[mVjHAyIwzSNKLFcd]
	return XRZyfuiD8nLlKYPJ(direction,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,profile)
def j05zXdGbEn3MBCFHuvw(*aargs,**kkwargs):
	return Q0BXbnOs1jr8afIyTUHZDw4lCAki7.Dialog().contextmenu(*aargs,**kkwargs)
def Y3VgCSHRF6dtK0DX5AWGlqb7(*aargs,**kkwargs):
	return Q0BXbnOs1jr8afIyTUHZDw4lCAki7.Dialog().browseSingle(*aargs,**kkwargs)
def uLwjTYQbBkfdV38Zq4CUrcm(*aargs,**kkwargs):
	return Q0BXbnOs1jr8afIyTUHZDw4lCAki7.Dialog().input(*aargs,**kkwargs)
def EkO3SZvUhBmswzoC2cKRbfxyMYW7H(*aargs,**kkwargs):
	return Q0BXbnOs1jr8afIyTUHZDw4lCAki7.DialogProgress(*aargs,**kkwargs)
PgOBeqZ3yUrpASjmXfC = YoAMfqm37GyFxbuKTt6e8CESHrhB
def SxKAmIcoHeQ1(yy7gcbAwPEpIRUDmkoG9BK):
	global PgOBeqZ3yUrpASjmXfC
	Zn2yQOf6lWMt9pUeuvcCR51JNIwiB = yy7gcbAwPEpIRUDmkoG9BK==TCF8wLyDvgumfiXPSKRh(u"ࠪࡷࡹࡧࡲࡵࠩ๳") and not PgOBeqZ3yUrpASjmXfC
	K0ycsNJSEtzfUiAM8Bg92YblId = yy7gcbAwPEpIRUDmkoG9BK==DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡸࡺ࡯ࡱࠩ๴") and PgOBeqZ3yUrpASjmXfC
	if Zn2yQOf6lWMt9pUeuvcCR51JNIwiB:
		M9BrCAtKSW2Egc = FF70emVxhWOngCty(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪ๵") if aybmzWnDkuEcT3jpJClB2>OTRKI6LbrQnZEm(u"࠴࠻࠳࠿࠹ጮ") else aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪ๶")
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(y5yX4jh6kUEgWZQIc(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩ๷")+M9BrCAtKSW2Egc+s0vAWcLSXEToH9Mik134q(u"ࠨࠫࠪ๸"))
		PgOBeqZ3yUrpASjmXfC = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	elif K0ycsNJSEtzfUiAM8Bg92YblId:
		M9BrCAtKSW2Egc = bDt7Ya1VEio3(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬ࡴ࡯ࡤࡣࡱࡧࡪࡲࠧ๹") if aybmzWnDkuEcT3jpJClB2>aqUlAdFto05NmG4Y6guEzTr8vK(u"࠵࠼࠴࠹࠺ጯ") else QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭ࠧ๺")
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(vZL6j4tSClIGxzNE5DX(u"ࠫࡉ࡯ࡡ࡭ࡱࡪ࠲ࡈࡲ࡯ࡴࡧࠫࠫ๻")+M9BrCAtKSW2Egc+JJu4MPClbTFpUwHiN(u"ࠬ࠯ࠧ๼"))
		PgOBeqZ3yUrpASjmXfC = YoAMfqm37GyFxbuKTt6e8CESHrhB
	return
def L2Lu1MQVHhiTX0(direction,button0=QigevCplXxbPI1H,button1=QigevCplXxbPI1H,button2=QigevCplXxbPI1H,V8VAj094OkMXUcYberdEDHLK=QigevCplXxbPI1H,CyarqoiHxV2e80ScjAN=QigevCplXxbPI1H,profile=DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ๽"),bWlAqiwGVSfRK5vTBoUhZctQzCJH=h17Zb2ld4yLBrCP5tiw,ZYU1v2mugbzsLjRck=h17Zb2ld4yLBrCP5tiw):
	if not direction: direction = mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡤࡧࡱࡸࡪࡸࠧ๾")
	M9BrCAtKSW2Egc = hNBzF7rYvtewoASZupJQV86qnH(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡆ࡬ࡥࡱࡵࡧࡄࡱࡱࡪ࡮ࡸ࡭ࡕࡪࡵࡩࡪࡈࡵࡵࡶࡲࡲࡸ࠴ࡸ࡮࡮ࠪ๿"),XoeSNbWwLnKC8Q,mpusoZBJ6V(u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ຀"),s0vAWcLSXEToH9Mik134q(u"ࠪ࠻࠷࠶ࡰࠨກ"))
	M9BrCAtKSW2Egc.rPtOwMYezvn5dh6Qj2J9ysT(button0,button1,button2,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,profile,direction,bWlAqiwGVSfRK5vTBoUhZctQzCJH,ZYU1v2mugbzsLjRck)
	if bWlAqiwGVSfRK5vTBoUhZctQzCJH>h17Zb2ld4yLBrCP5tiw: M9BrCAtKSW2Egc.z5wPiM7Fo2aVn3NgcUBl8ktyLhO4C()
	if ZYU1v2mugbzsLjRck>h17Zb2ld4yLBrCP5tiw: M9BrCAtKSW2Egc.LCKmuseZ7MEljVHG()
	if bWlAqiwGVSfRK5vTBoUhZctQzCJH==h17Zb2ld4yLBrCP5tiw and ZYU1v2mugbzsLjRck==h17Zb2ld4yLBrCP5tiw: M9BrCAtKSW2Egc.SWQws1lJtbGUzY6oeHATav7()
	M9BrCAtKSW2Egc.doModal()
	qqTR9xfSyG0j43H = M9BrCAtKSW2Egc.choiceID
	return qqTR9xfSyG0j43H
def XRZyfuiD8nLlKYPJ(direction,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,profile=JJu4MPClbTFpUwHiN(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬຂ")):
	if not direction: direction = XWbHfI9B8swrOL(u"ࠬࡲࡥࡧࡶࠪ຃")
	M9BrCAtKSW2Egc = Roa4WbzDQZ95UPFSwkBsujAMgLtpX2(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡄࡪࡣ࡯ࡳ࡬࡚ࡥࡹࡶ࡙࡭ࡪࡽࡥࡳࡈࡸࡰࡱ࡙ࡣࡳࡧࡨࡲ࠳ࡾ࡭࡭ࠩຄ"),XoeSNbWwLnKC8Q,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ຅"),pTwKPmzMSZhil5d2RWonre(u"ࠨ࠹࠵࠴ࡵ࠭ຆ"))
	image_filename = gCdTSQXzi4ua5AG6rO1YpnV.replace(K7bLVaiRkx0lgU5SQM(u"ࠩࡢ࠴࠵࠶࠰ࡠࠩງ"),pGncXOodjKhJzLSqVP1r(u"ࠪࡣࠬຈ")+str(B3TKLo71hAGRqYgV0.time())+bDt7Ya1VEio3(u"ࠫࡤ࠭ຉ"))
	image_filename = image_filename.replace(y5yX4jh6kUEgWZQIc(u"ࠬࡢ࡜ࠨຊ"),g4UCaNkHvLwGhjmW(u"࠭࡜࡝࡞࡟ࠫ຋")).replace(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧ࠰࠱ࠪຌ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࠱࠲࠳࠴࠭ຍ"))
	image_height = SYUGgKyAwVTOQs9nuxR04(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,V8VAj094OkMXUcYberdEDHLK,CyarqoiHxV2e80ScjAN,profile,direction,YoAMfqm37GyFxbuKTt6e8CESHrhB,image_filename)
	M9BrCAtKSW2Egc.show()
	M9BrCAtKSW2Egc.getControl(bDt7Ya1VEio3(u"࠾࠶࠵࠱ጰ")).setHeight(image_height)
	M9BrCAtKSW2Egc.getControl(mmKqLr9RX0ACN384JMcsFHzd(u"࠿࠰࠶࠲ጱ")).setImage(image_filename)
	cL4pMx8ECUzgdQPelwohuFmnsK = M9BrCAtKSW2Egc.doModal()
	try: KiTt9ZskMLjnCAUIJNXD7.remove(image_filename)
	except: pass
	return cL4pMx8ECUzgdQPelwohuFmnsK
def eUBL1rOR4ZfndJAWPsoN6pybT0(zgpxUQDbrt5F1RJ4=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	if zgpxUQDbrt5F1RJ4:
		lfPqTpgMXhVcd = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,g4UCaNkHvLwGhjmW(u"ࠩࡶࡸࡷ࠭ຎ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ຏ"),DDHwpETQrAm0xMNXGfyhqsUi(u"࡚࡙ࠫࡅࡓࡃࡊࡉࡓ࡚ࠧຐ"))
		if lfPqTpgMXhVcd: return lfPqTpgMXhVcd
	CyarqoiHxV2e80ScjAN = QigevCplXxbPI1H
	if h17Zb2ld4yLBrCP5tiw and lE7ZB0CTayhKItApFnYxz.succeeded:
		zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
		S6bnmEiKxr0JUvHMt5pgsjV = zHrPxh0aevGnlKMTdjQsV.count(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠭ຑ"))
		if S6bnmEiKxr0JUvHMt5pgsjV>bDt7Ya1VEio3(u"࠸࠱ጲ"):
			CyarqoiHxV2e80ScjAN = sBvufaD6c9YHdOqTjCQ3.findall(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨຒ"),zHrPxh0aevGnlKMTdjQsV,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN[h17Zb2ld4yLBrCP5tiw]
	if not CyarqoiHxV2e80ScjAN:
		xx1M2mwbecQNAB4itEd5OVf0PSnKzs = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ຓ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡷࡶࡩࡷࡧࡧࡦࡰࡷࡷ࠳ࡺࡸࡵࠩດ"))
		CyarqoiHxV2e80ScjAN = open(xx1M2mwbecQNAB4itEd5OVf0PSnKzs,Fg72JX6T5DkPy(u"ࠩࡵࡦࠬຕ")).read()
		if b7sJAmSxlBvaMdHFz: CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
	aJ2VcY4X3o7vwGBLShMNut6nbgTmF8 = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠪࠬࡒࡵࡺࡪ࡮࡯ࡥ࠳࠰࠿ࠪ࡞ࡱࠫຖ"),CyarqoiHxV2e80ScjAN,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	pWv0is2yrcTbuo6lSJHZU1aX4 = []
	for U6ZM8BVcn1re7STQLsEgxk3oJK in aJ2VcY4X3o7vwGBLShMNut6nbgTmF8:
		AwbOiczgd7jX = U6ZM8BVcn1re7STQLsEgxk3oJK.lower()
		if XWbHfI9B8swrOL(u"ࠫࡦࡴࡤࡳࡱ࡬ࡨࠬທ") in AwbOiczgd7jX: continue
		if g4UCaNkHvLwGhjmW(u"ࠬࡻࡢࡶࡰࡷࡹࠬຘ") in AwbOiczgd7jX: continue
		if VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡩࡱࡪࡲࡲࡪ࠭ນ") in AwbOiczgd7jX: continue
		if FF70emVxhWOngCty(u"ࠧࡤࡴࡲࡷࠬບ") in AwbOiczgd7jX: continue
		pWv0is2yrcTbuo6lSJHZU1aX4.append(U6ZM8BVcn1re7STQLsEgxk3oJK)
	lfPqTpgMXhVcd = yarjPEMGV6m7fHRFeJXt.sample(pWv0is2yrcTbuo6lSJHZU1aX4,nfC2im3NzUQk)
	lfPqTpgMXhVcd = lfPqTpgMXhVcd[h17Zb2ld4yLBrCP5tiw]
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫປ"),pGncXOodjKhJzLSqVP1r(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬຜ"),lfPqTpgMXhVcd,pETKl7xuH1f5yjdFAb6C8JzOLV)
	return lfPqTpgMXhVcd
def L5C2adJcDkS0e(THFfWLwt62MmUz=QigevCplXxbPI1H):
	if not THFfWLwt62MmUz: THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
	if svULcgJ7jm(u"ࠪࡗࡾࡹࡴࡦ࡯ࡈࡼ࡮ࡺࠧຝ") in THFfWLwt62MmUz or FF70emVxhWOngCty(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧພ") in THFfWLwt62MmUz: return
	if THFfWLwt62MmUz!=mpusoZBJ6V(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨຟ"): KXhrv29CGR8QTDzJIWLY.stderr.write(THFfWLwt62MmUz)
	pS1FVtbXfLgZ0nxY3eTzqGd = THFfWLwt62MmUz.splitlines()
	f5fDJrRQGbEtTp07zHBKCua2 = pS1FVtbXfLgZ0nxY3eTzqGd[-v54ZuLY6dQ(u"࠲ጳ")]
	oRcYBkAwi0D6nL4FG1fmgleUuXqrJ = open(FcupZdBmjb4nReDCzs9wLKrV3lfx,g4UCaNkHvLwGhjmW(u"࠭ࡲࡣࠩຠ")).read()
	if b7sJAmSxlBvaMdHFz: oRcYBkAwi0D6nL4FG1fmgleUuXqrJ = oRcYBkAwi0D6nL4FG1fmgleUuXqrJ.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	oRcYBkAwi0D6nL4FG1fmgleUuXqrJ = oRcYBkAwi0D6nL4FG1fmgleUuXqrJ[-TCF8wLyDvgumfiXPSKRh(u"࠺࠳࠴࠵ጴ"):]
	JvHXPSz0mLOf2Tl = XWbHfI9B8swrOL(u"ࠧ࠾ࠩມ")*tg9l25NH6WTacVSifLyAmY(u"࠴࠴࠵ጵ")
	if JvHXPSz0mLOf2Tl in oRcYBkAwi0D6nL4FG1fmgleUuXqrJ: oRcYBkAwi0D6nL4FG1fmgleUuXqrJ = oRcYBkAwi0D6nL4FG1fmgleUuXqrJ.rsplit(JvHXPSz0mLOf2Tl,nfC2im3NzUQk)[nfC2im3NzUQk]
	if f5fDJrRQGbEtTp07zHBKCua2 in oRcYBkAwi0D6nL4FG1fmgleUuXqrJ: oRcYBkAwi0D6nL4FG1fmgleUuXqrJ = oRcYBkAwi0D6nL4FG1fmgleUuXqrJ.rsplit(f5fDJrRQGbEtTp07zHBKCua2,nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]
	zfljGLIQwP6U = sBvufaD6c9YHdOqTjCQ3.findall(g4UCaNkHvLwGhjmW(u"ࠨࠪࡖࡳࡺࡸࡣࡦࡾࡐࡳࡩ࡫ࠩ࠻ࠢ࡟࡟ࠥ࠮࠮ࠫࡁࠬࠤࡡࡣࠧຢ"),oRcYBkAwi0D6nL4FG1fmgleUuXqrJ,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for fvIZX4sy5mi,m9TrBXjhwRgI in reversed(zfljGLIQwP6U):
		if m9TrBXjhwRgI: break
	else: m9TrBXjhwRgI = OTRKI6LbrQnZEm(u"ࠩࡑࡓ࡙ࠦࡓࡑࡇࡆࡍࡋࡏࡅࡅࠩຣ")
	Hl7FmSYzejKpB1v8T0,U6ZM8BVcn1re7STQLsEgxk3oJK,SKNZlHkIOiWz4 = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	Rzyk0edgYtGJ4PlwWShTa6Lv = tg9l25NH6WTacVSifLyAmY(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ຤")+r9rhtA5Tek8sIoLfqwF7JcEV+pGncXOodjKhJzLSqVP1r(u"ࠫฬ๊ฮุล࠽ࠤࠥ࠭ລ")+jhAlCQ47ZgG+f5fDJrRQGbEtTp07zHBKCua2
	vmU4abqgc5ndeKHfCw7ETlXRNy = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡡࡒࡕࡎࡠࠫ຦")+r9rhtA5Tek8sIoLfqwF7JcEV+v54ZuLY6dQ(u"࠭วๅ็ุำึࡀࠠࠡࠩວ")+jhAlCQ47ZgG+m9TrBXjhwRgI
	for ylShpqVtRkQ5W2IP4gHJoDrwd in reversed(pS1FVtbXfLgZ0nxY3eTzqGd):
		if DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡇ࡫࡯ࡩࠥࠨࠧຨ") in ylShpqVtRkQ5W2IP4gHJoDrwd and vZL6j4tSClIGxzNE5DX(u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧຩ") in ylShpqVtRkQ5W2IP4gHJoDrwd: break
	ylShpqVtRkQ5W2IP4gHJoDrwd = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡉ࡭ࡱ࡫ࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࡝࠮ࠣࡰ࡮ࡴࡥࠡࠪ࠱࠮ࡄ࠯࡜࠭ࠢ࡬ࡲࠥ࠮࠮ࠫࡁࠬࠨࠬສ"),ylShpqVtRkQ5W2IP4gHJoDrwd,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if ylShpqVtRkQ5W2IP4gHJoDrwd:
		Hl7FmSYzejKpB1v8T0,U6ZM8BVcn1re7STQLsEgxk3oJK,SKNZlHkIOiWz4 = ylShpqVtRkQ5W2IP4gHJoDrwd[h17Zb2ld4yLBrCP5tiw]
		if pGncXOodjKhJzLSqVP1r(u"ࠪ࠳ࠬຫ") in Hl7FmSYzejKpB1v8T0: Hl7FmSYzejKpB1v8T0 = Hl7FmSYzejKpB1v8T0.rsplit(K7bLVaiRkx0lgU5SQM(u"ࠫ࠴࠭ຬ"),nfC2im3NzUQk)[nfC2im3NzUQk]
		else: Hl7FmSYzejKpB1v8T0 = Hl7FmSYzejKpB1v8T0.rsplit(Xr2aHOK0huQ5DTS(u"ࠬࡢ࡜ࠨອ"),nfC2im3NzUQk)[nfC2im3NzUQk]
		GjFfLJm8Eu9 = JJu4MPClbTFpUwHiN(u"࡛࠭ࡓࡖࡏࡡࠬຮ")+r9rhtA5Tek8sIoLfqwF7JcEV+vZL6j4tSClIGxzNE5DX(u"ࠧศๆ่่ๆࡀࠠࠡࠩຯ")+jhAlCQ47ZgG+Hl7FmSYzejKpB1v8T0
		Ng6Xu8T3nSxZAvd5I = s0vAWcLSXEToH9Mik134q(u"ࠨ࡝ࡕࡘࡑࡣࠧະ")+r9rhtA5Tek8sIoLfqwF7JcEV+pTwKPmzMSZhil5d2RWonre(u"ࠩสุ่฽ั࠻ࠢࠣࠫັ")+jhAlCQ47ZgG+U6ZM8BVcn1re7STQLsEgxk3oJK
		vfejO5rb9Eg1R = mmKqLr9RX0ACN384JMcsFHzd(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩາ")+r9rhtA5Tek8sIoLfqwF7JcEV+tg9l25NH6WTacVSifLyAmY(u"ࠫฬ๊ๅไษ้࠾ࠥࠦࠧຳ")+jhAlCQ47ZgG+SKNZlHkIOiWz4
		P6B430e21DUrHVRKG7LaXCsTinmf = GjFfLJm8Eu9+aSBkt4OU8JpWTEzVIHjAiv+Ng6Xu8T3nSxZAvd5I+aSBkt4OU8JpWTEzVIHjAiv+vfejO5rb9Eg1R+aSBkt4OU8JpWTEzVIHjAiv+vmU4abqgc5ndeKHfCw7ETlXRNy+aSBkt4OU8JpWTEzVIHjAiv+Rzyk0edgYtGJ4PlwWShTa6Lv
		rS4BJ0XO6xR = Ng6Xu8T3nSxZAvd5I+aSBkt4OU8JpWTEzVIHjAiv+vmU4abqgc5ndeKHfCw7ETlXRNy+aSBkt4OU8JpWTEzVIHjAiv+Rzyk0edgYtGJ4PlwWShTa6Lv+aSBkt4OU8JpWTEzVIHjAiv+GjFfLJm8Eu9+aSBkt4OU8JpWTEzVIHjAiv+vfejO5rb9Eg1R
		kObvMNLWq3s1yUhzoG5H6t = Ng6Xu8T3nSxZAvd5I+aSBkt4OU8JpWTEzVIHjAiv+Rzyk0edgYtGJ4PlwWShTa6Lv+aSBkt4OU8JpWTEzVIHjAiv+GjFfLJm8Eu9+aSBkt4OU8JpWTEzVIHjAiv+vfejO5rb9Eg1R
	else:
		GjFfLJm8Eu9,Ng6Xu8T3nSxZAvd5I,vfejO5rb9Eg1R = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
		P6B430e21DUrHVRKG7LaXCsTinmf = vmU4abqgc5ndeKHfCw7ETlXRNy+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡢ࡮࡝ࡰࠪິ")+Rzyk0edgYtGJ4PlwWShTa6Lv
		rS4BJ0XO6xR = vmU4abqgc5ndeKHfCw7ETlXRNy+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࡜࡯࡞ࡱࠫີ")+Rzyk0edgYtGJ4PlwWShTa6Lv
		kObvMNLWq3s1yUhzoG5H6t = Rzyk0edgYtGJ4PlwWShTa6Lv
	bbZRo6yGsJ0wTA = FF70emVxhWOngCty(u"ࠧฮัฮࠤำ฽รࠡ฼ํี๋ࠥโึ๊าࠫຶ")+aSBkt4OU8JpWTEzVIHjAiv
	OiIo5yEB7C0 = wsIhgL9rolkO41f()
	hUXCoZ5gzstbj3lvFdOQ1W4aRuJ79 = []
	W9lfsoMawqOzpQcXD = OiIo5yEB7C0[OTRKI6LbrQnZEm(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ື")]
	ccQuEiWltvaUhfRL3K = Kc4bRz3g5WTV(GVmdqbtLu8lUXNxp13aHOvkscR)
	if g4UCaNkHvLwGhjmW(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹຸࠧ") in list(OiIo5yEB7C0.keys()):
		for GGQExm1HXI7ChgaRL5dy,XX0eJwE4a9KixmNgRILFPOvTh,H6zQXw3EO4KkCTxaSjvbR in W9lfsoMawqOzpQcXD: hUXCoZ5gzstbj3lvFdOQ1W4aRuJ79 = max(hUXCoZ5gzstbj3lvFdOQ1W4aRuJ79,XX0eJwE4a9KixmNgRILFPOvTh)
		if ccQuEiWltvaUhfRL3K<hUXCoZ5gzstbj3lvFdOQ1W4aRuJ79:
			V8VAj094OkMXUcYberdEDHLK = Xr2aHOK0huQ5DTS(u"ࠪๆ๊ࠦศหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡไห่ࠥหัิษ็ࠤฬ๊รฯูสล๊ࠥไๆสิ้ัູ࠭")
			qqTR9xfSyG0j43H = L2Lu1MQVHhiTX0(s0vAWcLSXEToH9Mik134q(u"ࠫࡷ࡯ࡧࡩࡶ຺ࠪ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬหัิษ็ࠤส๊้ࠡษ็้อืๅอࠩົ"),O4ylJvVNwLztdiHqBWDU(u"࠭สฮัํฯࠬຼ"),JJu4MPClbTFpUwHiN(u"ࠧฯำ๋ะࠬຽ"),bbZRo6yGsJ0wTA+V8VAj094OkMXUcYberdEDHLK,P6B430e21DUrHVRKG7LaXCsTinmf)
			if qqTR9xfSyG0j43H==h17Zb2ld4yLBrCP5tiw:
				nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(JJu4MPClbTFpUwHiN(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ຾"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩัีําࠧ຿"),tOrSvd8QKNB(u"ࠪฮาี๊ฬࠩເ"),QigevCplXxbPI1H,V8VAj094OkMXUcYberdEDHLK)
				if nndcv6tehuoKPpI==nfC2im3NzUQk: qqTR9xfSyG0j43H = nfC2im3NzUQk
			if qqTR9xfSyG0j43H==nfC2im3NzUQk:
				import WZPsXYo7QE
				WZPsXYo7QE.OXlgcotDer5zTQ1MFYva3nKxdNR(XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
			return
	lERay7kNiW8GwKXDuchv0F2zP = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,Xr2aHOK0huQ5DTS(u"ࠫࡱ࡯ࡳࡵࠩແ"),TCF8wLyDvgumfiXPSKRh(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨໂ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨໃ"))
	if not lERay7kNiW8GwKXDuchv0F2zP: lERay7kNiW8GwKXDuchv0F2zP = []
	rS4BJ0XO6xR = rS4BJ0XO6xR.replace(aSBkt4OU8JpWTEzVIHjAiv,pGncXOodjKhJzLSqVP1r(u"ࠧ࡝࡞ࡱࠫໄ")).replace(OOhnpQ8XvCVclGqdu(u"ࠨ࡝ࡕࡘࡑࡣࠧ໅"),QigevCplXxbPI1H).replace(r9rhtA5Tek8sIoLfqwF7JcEV,QigevCplXxbPI1H).replace(jhAlCQ47ZgG,QigevCplXxbPI1H)
	kObvMNLWq3s1yUhzoG5H6t = kObvMNLWq3s1yUhzoG5H6t.replace(aSBkt4OU8JpWTEzVIHjAiv,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࡟ࡠࡳ࠭ໆ")).replace(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ໇"),QigevCplXxbPI1H).replace(r9rhtA5Tek8sIoLfqwF7JcEV,QigevCplXxbPI1H).replace(jhAlCQ47ZgG,QigevCplXxbPI1H)
	gG1P0D8Scw = GVmdqbtLu8lUXNxp13aHOvkscR+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࠿ࡀ່ࠧ")+kObvMNLWq3s1yUhzoG5H6t
	if gG1P0D8Scw in lERay7kNiW8GwKXDuchv0F2zP:
		V8VAj094OkMXUcYberdEDHLK = XWbHfI9B8swrOL(u"๊ࠬโะࠢๅ้ฯࠦว็ฬࠣืฬฮโศࠢหษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮ້ࠪ")
		lKfIRYspw15BD8vgtoAP(mpusoZBJ6V(u"࠭ࡲࡪࡩ࡫ࡸ໊ࠬ"),QigevCplXxbPI1H,bbZRo6yGsJ0wTA+V8VAj094OkMXUcYberdEDHLK,P6B430e21DUrHVRKG7LaXCsTinmf)
		return
	ooU84E52TDsAqy06hYS = str(aybmzWnDkuEcT3jpJClB2).split(Fg72JX6T5DkPy(u"ࠧ࠯໋ࠩ"))[h17Zb2ld4yLBrCP5tiw]
	iCr0xsqwDZXLPaJK1W5YU24F6hp = OQv0iWIw5bFRATU2mxJjZK[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ໌")][svULcgJ7jm(u"࠺ጶ")]
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,K7bLVaiRkx0lgU5SQM(u"ࠩࡓࡓࡘ࡚ࠧໍ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫ໎"),YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
	MBDbfYq1o3F7W = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫ໏"),zHrPxh0aevGnlKMTdjQsV,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for t7fJr4MkoWDpUa6l,YwLOgNAkX7m0zUTHBq1u6SGDcvEht,TF8UAd1bglKmu,Yr3sC28ZHiELpmBhU7okujqz in MBDbfYq1o3F7W:
		t7fJr4MkoWDpUa6l = t7fJr4MkoWDpUa6l.split(svULcgJ7jm(u"ࠬ࠱ࠧ໐"))
		TF8UAd1bglKmu = TF8UAd1bglKmu.split(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࠫࠨ໑"))
		Yr3sC28ZHiELpmBhU7okujqz = Yr3sC28ZHiELpmBhU7okujqz.split(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࠬࠩ໒"))
		if U6ZM8BVcn1re7STQLsEgxk3oJK in t7fJr4MkoWDpUa6l and f5fDJrRQGbEtTp07zHBKCua2==YwLOgNAkX7m0zUTHBq1u6SGDcvEht and GVmdqbtLu8lUXNxp13aHOvkscR in TF8UAd1bglKmu and ooU84E52TDsAqy06hYS in Yr3sC28ZHiELpmBhU7okujqz:
			V8VAj094OkMXUcYberdEDHLK = FF70emVxhWOngCty(u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭໓")
			nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡵ࡭࡬࡮ࡴࠨ໔"),Xr2aHOK0huQ5DTS(u"ࠪาึ๎ฬࠨ໕"),XWbHfI9B8swrOL(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ໖"),bbZRo6yGsJ0wTA+V8VAj094OkMXUcYberdEDHLK,P6B430e21DUrHVRKG7LaXCsTinmf)
			if nndcv6tehuoKPpI==nfC2im3NzUQk: lKfIRYspw15BD8vgtoAP(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ໗"),QigevCplXxbPI1H,QigevCplXxbPI1H,V8VAj094OkMXUcYberdEDHLK)
			return
	V8VAj094OkMXUcYberdEDHLK = VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭໘")
	IYL9aTSU4XJRiD1q8rHz2FGAEev = L2Lu1MQVHhiTX0(tOrSvd8QKNB(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭໙"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ໚"),y5yX4jh6kUEgWZQIc(u"ࠩอัิ๐หࠡฮีส๏࠭໛"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪฮาี๊ฬࠢส่อืๆศ็ฯࠫໜ"),bbZRo6yGsJ0wTA+V8VAj094OkMXUcYberdEDHLK,P6B430e21DUrHVRKG7LaXCsTinmf)
	if IYL9aTSU4XJRiD1q8rHz2FGAEev==nfC2im3NzUQk:
		if not ior2buCJ0nlghKd7RFcHfp:
			e9UIQ7WhX4FViaptmR3(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"๋ࠫาอหࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠢส่ัุฦ๋ࠩໝ"),K7bLVaiRkx0lgU5SQM(u"ࠬ๓ࡓࡶࡥࡦࡩࡸࡹࠧໞ"),B3TKLo71hAGRqYgV0=mpusoZBJ6V(u"࠼࠻࠰ጷ"))
		ksV5ngvbcaS8ByMLYxlfXh()
	elif IYL9aTSU4XJRiD1q8rHz2FGAEev==JxuTQLOD357o41evylqPmRdf:
		import WZPsXYo7QE
		WZPsXYo7QE.OXlgcotDer5zTQ1MFYva3nKxdNR(XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		ksV5ngvbcaS8ByMLYxlfXh()
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(O4ylJvVNwLztdiHqBWDU(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ໟ"),QigevCplXxbPI1H,QigevCplXxbPI1H,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ໠"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩ໡"))
	if nndcv6tehuoKPpI==nfC2im3NzUQk: BzoGPDXaKYU6wk9S = K7bLVaiRkx0lgU5SQM(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ໢")
	else:
		lKfIRYspw15BD8vgtoAP(y5yX4jh6kUEgWZQIc(u"ࠪࡧࡪࡴࡴࡦࡴࠪ໣"),QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ໤"),r9rhtA5Tek8sIoLfqwF7JcEV+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࠬ໥")+jhAlCQ47ZgG+JJu4MPClbTFpUwHiN(u"࠭࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ໦"))
		return
	LFtkv1dZI6QNUlAq0wX = rS4BJ0XO6xR
	from WZPsXYo7QE import PZMEo96N8F50USez4
	AMu7aiqvPT6WcLOXDSkhFzdN = PZMEo96N8F50USez4(Xr2aHOK0huQ5DTS(u"ࠧࡆࡴࡵࡳࡷࡹࠧ໧"),LFtkv1dZI6QNUlAq0wX,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨ໨"),BzoGPDXaKYU6wk9S)
	if AMu7aiqvPT6WcLOXDSkhFzdN and BzoGPDXaKYU6wk9S:
		lERay7kNiW8GwKXDuchv0F2zP.append(gG1P0D8Scw)
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ໩"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ໪"),lERay7kNiW8GwKXDuchv0F2zP,xfdjCmFwb0k8JAVegiL)
	return
def OTMKmIkx6yiWQZPpJ(VV4iSgTwskE6uyoBCl3ZDh7HQ,filename=None):
	if b7sJAmSxlBvaMdHFz: VV4iSgTwskE6uyoBCl3ZDh7HQ = VV4iSgTwskE6uyoBCl3ZDh7HQ.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	if not filename: bkVfIexwAzsqrS9gj = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ໫")+str(B3TKLo71hAGRqYgV0.time())+OOhnpQ8XvCVclGqdu(u"ࠬ࠴ࡤࡢࡶࠪ໬")
	else: bkVfIexwAzsqrS9gj = vZL6j4tSClIGxzNE5DX(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭໭")+filename+OTRKI6LbrQnZEm(u"ࠧ࠯ࡦࡤࡸࠬ໮")
	open(bkVfIexwAzsqrS9gj,FF70emVxhWOngCty(u"ࠨࡹࡥࠫ໯")).write(VV4iSgTwskE6uyoBCl3ZDh7HQ)
	return
def IIJimsEAhPdua8RFg4LvbMwV0rD5U6(ouzBYNFqJn9fbP1y):
	if ouzBYNFqJn9fbP1y:
		RulsXEM83VO0QKcCHza2TGSf4N9g = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ࡯࡭ࡸࡺࠧ໰"),tOrSvd8QKNB(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭໱"),TCF8wLyDvgumfiXPSKRh(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ໲"))
		if RulsXEM83VO0QKcCHza2TGSf4N9g: return RulsXEM83VO0QKcCHza2TGSf4N9g
	iCr0xsqwDZXLPaJK1W5YU24F6hp = OQv0iWIw5bFRATU2mxJjZK[FF70emVxhWOngCty(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ໳")][Fg72JX6T5DkPy(u"࠻ጸ")]
	PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠳࠳ጹ"),ouzBYNFqJn9fbP1y)
	uZ9qIdr8OtN = WfKzkBJuTObrMa1eloxI()
	cQW2wk0yK9LeChBnsoAOuVaF8 = uZ9qIdr8OtN.split(Fg72JX6T5DkPy(u"࠭ࠬࠨ໴"))[JxuTQLOD357o41evylqPmRdf]
	GfCWvOXloNe6iM0843zJIhqSscF = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭໵"))
	eUHmWgkBoKPaCtxYyMNDGwf5vhQb = FocL2iGhn9ZfV5sx()
	AlZkSOdj4PzhXQv = {Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡷࡶࡩࡷ࠭໶"):PXVdZQYTNslvg7wF0159Akr,y5yX4jh6kUEgWZQIc(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ໷"):GVmdqbtLu8lUXNxp13aHOvkscR,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ໸"):cQW2wk0yK9LeChBnsoAOuVaF8,mpusoZBJ6V(u"ࠫ࡮ࡪࡳࠨ໹"):lY3kWbFJCKMto68f(eUHmWgkBoKPaCtxYyMNDGwf5vhQb)}
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,bDt7Ya1VEio3(u"ࠬࡖࡏࡔࡖࠪ໺"),iCr0xsqwDZXLPaJK1W5YU24F6hp,AlZkSOdj4PzhXQv,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࠭࠲ࡵࡷࠫ໻"))
	RulsXEM83VO0QKcCHza2TGSf4N9g = []
	if lE7ZB0CTayhKItApFnYxz.succeeded:
		zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
		RulsXEM83VO0QKcCHza2TGSf4N9g = zHrPxh0aevGnlKMTdjQsV.replace(JJu4MPClbTFpUwHiN(u"ࠧ࡝࡞ࡵࠫ໼"),aSBkt4OU8JpWTEzVIHjAiv).replace(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨ࡞࡟ࡲࠬ໽"),aSBkt4OU8JpWTEzVIHjAiv).replace(Xr2aHOK0huQ5DTS(u"ࠩ࡟ࡶࡡࡴࠧ໾"),aSBkt4OU8JpWTEzVIHjAiv).replace(Ymkp8qFPsjovc57UT,aSBkt4OU8JpWTEzVIHjAiv)
		RulsXEM83VO0QKcCHza2TGSf4N9g = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭໿"),RulsXEM83VO0QKcCHza2TGSf4N9g,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RulsXEM83VO0QKcCHza2TGSf4N9g:
			RulsXEM83VO0QKcCHza2TGSf4N9g = sorted(RulsXEM83VO0QKcCHza2TGSf4N9g,reverse=YoAMfqm37GyFxbuKTt6e8CESHrhB,key=lambda key: int(key[h17Zb2ld4yLBrCP5tiw]))
			jfRgOv7BWL9T8y,PXVdZQYTNslvg7wF0159Akr,Qc9doRJK1CMgWzqTruGf,rr4e95RPASc,oVMaZ1qEyj6kLgTCUBNAbsHIpOK,C4RUnz8IDZ15uXOqG96F2kSTNiygp = RulsXEM83VO0QKcCHza2TGSf4N9g[h17Zb2ld4yLBrCP5tiw]
			goN5fKJjMs0D4dIW9q6c = C4RUnz8IDZ15uXOqG96F2kSTNiygp if nVIdjZ1ybeU8TB9tSpAQH(vZL6j4tSClIGxzNE5DX(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪༀ")) else Qc9doRJK1CMgWzqTruGf
			uUTRHgAXJzm7pIDBjNt8.setSetting(Fg72JX6T5DkPy(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ༁"),goN5fKJjMs0D4dIW9q6c)
			BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,v54ZuLY6dQ(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ༂"),Fg72JX6T5DkPy(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ༃"),RulsXEM83VO0QKcCHza2TGSf4N9g,pETKl7xuH1f5yjdFAb6C8JzOLV)
			uUTRHgAXJzm7pIDBjNt8.setSetting(tg9l25NH6WTacVSifLyAmY(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ༄"),lY3kWbFJCKMto68f(qyUPZBiAE3YkuOKrMnTFex92D))
	return RulsXEM83VO0QKcCHza2TGSf4N9g
def Web35Nz1LEIQvTrtK0U4HJ(XQAwCuWTdbcq0tSfvmMOIE4pPiJ,P6ausWBoDZlO=h17Zb2ld4yLBrCP5tiw,DMZYLoyu1RASegXp7fbsKcnl52G=h17Zb2ld4yLBrCP5tiw):
	if P6ausWBoDZlO and not DMZYLoyu1RASegXp7fbsKcnl52G: DMZYLoyu1RASegXp7fbsKcnl52G = len(XQAwCuWTdbcq0tSfvmMOIE4pPiJ)//P6ausWBoDZlO
	yJ0pH3hkfn4d9jRUDi6Vogv,GzabfJx3T1,UbThgLS9PfiE605FJHtqQDBR = [],-nfC2im3NzUQk,h17Zb2ld4yLBrCP5tiw
	for a3m046bDiUGHgNtVKXMrpQCAcF in XQAwCuWTdbcq0tSfvmMOIE4pPiJ:
		if UbThgLS9PfiE605FJHtqQDBR%DMZYLoyu1RASegXp7fbsKcnl52G==h17Zb2ld4yLBrCP5tiw:
			GzabfJx3T1 += nfC2im3NzUQk
			yJ0pH3hkfn4d9jRUDi6Vogv.append([])
		yJ0pH3hkfn4d9jRUDi6Vogv[GzabfJx3T1].append(a3m046bDiUGHgNtVKXMrpQCAcF)
		UbThgLS9PfiE605FJHtqQDBR += nfC2im3NzUQk
	return yJ0pH3hkfn4d9jRUDi6Vogv
def Lt2n4Fm7iP1uvrxyaRoEKXf(bkVfIexwAzsqrS9gj,VV4iSgTwskE6uyoBCl3ZDh7HQ):
	OOlAhT76nC = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,bkVfIexwAzsqrS9gj)
	if nfC2im3NzUQk or svULcgJ7jm(u"ࠩࡌࡔ࡙࡜࡟ࠨ༅") not in bkVfIexwAzsqrS9gj or O4ylJvVNwLztdiHqBWDU(u"ࠪࡑ࠸࡛࡟ࠨ༆") not in bkVfIexwAzsqrS9gj: CyarqoiHxV2e80ScjAN = str(VV4iSgTwskE6uyoBCl3ZDh7HQ)
	else:
		yJ0pH3hkfn4d9jRUDi6Vogv = Web35Nz1LEIQvTrtK0U4HJ(VV4iSgTwskE6uyoBCl3ZDh7HQ,tOrSvd8QKNB(u"࠹ጺ"))
		CyarqoiHxV2e80ScjAN = QigevCplXxbPI1H
		for Dq8ofrtEaeXRG2Iug3l in yJ0pH3hkfn4d9jRUDi6Vogv:
			CyarqoiHxV2e80ScjAN += str(Dq8ofrtEaeXRG2Iug3l)+pGncXOodjKhJzLSqVP1r(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ༇")
		CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.strip(y5yX4jh6kUEgWZQIc(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ༈"))
	jIzXQVS9lg6orD5vF = NitQwg0RoyESdkOU3D4pqu.compress(CyarqoiHxV2e80ScjAN)
	open(OOlAhT76nC,v54ZuLY6dQ(u"࠭ࡷࡣࠩ༉")).write(jIzXQVS9lg6orD5vF)
	return
def bWLs2k381lm7CRVoK5qMdOiwA4(xXg50B8W9Koq,bkVfIexwAzsqrS9gj):
	if xXg50B8W9Koq==JJu4MPClbTFpUwHiN(u"ࠧࡥ࡫ࡦࡸࠬ༊"): VV4iSgTwskE6uyoBCl3ZDh7HQ = {}
	elif xXg50B8W9Koq==v54ZuLY6dQ(u"ࠨ࡮࡬ࡷࡹ࠭་"): VV4iSgTwskE6uyoBCl3ZDh7HQ = []
	elif xXg50B8W9Koq==tOrSvd8QKNB(u"ࠩࡶࡸࡷ࠭༌"): VV4iSgTwskE6uyoBCl3ZDh7HQ = QigevCplXxbPI1H
	elif xXg50B8W9Koq==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪ࡭ࡳࡺࠧ།"): VV4iSgTwskE6uyoBCl3ZDh7HQ = h17Zb2ld4yLBrCP5tiw
	else: VV4iSgTwskE6uyoBCl3ZDh7HQ = None
	OOlAhT76nC = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,bkVfIexwAzsqrS9gj)
	jIzXQVS9lg6orD5vF = open(OOlAhT76nC,K7bLVaiRkx0lgU5SQM(u"ࠫࡷࡨࠧ༎")).read()
	CyarqoiHxV2e80ScjAN = NitQwg0RoyESdkOU3D4pqu.decompress(jIzXQVS9lg6orD5vF)
	if mpusoZBJ6V(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ༏") not in CyarqoiHxV2e80ScjAN: VV4iSgTwskE6uyoBCl3ZDh7HQ = eval(CyarqoiHxV2e80ScjAN)
	else:
		yJ0pH3hkfn4d9jRUDi6Vogv = CyarqoiHxV2e80ScjAN.split(OOhnpQ8XvCVclGqdu(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ༐"))
		del CyarqoiHxV2e80ScjAN
		VV4iSgTwskE6uyoBCl3ZDh7HQ = []
		PWxzXLv5IwQgoujNO3DAdE2FBc4 = UZ28903VuMoInShOjv4zpYDFxliy()
		jfRgOv7BWL9T8y = h17Zb2ld4yLBrCP5tiw
		for Dq8ofrtEaeXRG2Iug3l in yJ0pH3hkfn4d9jRUDi6Vogv:
			PWxzXLv5IwQgoujNO3DAdE2FBc4.pptBuEexdPhR9U1qwmToGV(str(jfRgOv7BWL9T8y),eval,Dq8ofrtEaeXRG2Iug3l)
			jfRgOv7BWL9T8y += nfC2im3NzUQk
		del yJ0pH3hkfn4d9jRUDi6Vogv
		PWxzXLv5IwQgoujNO3DAdE2FBc4.St3qKZg4fy()
		PWxzXLv5IwQgoujNO3DAdE2FBc4.TFq7x2bg1B4AD5aY0eVNrRI8niQ()
		O0saA45JcGKT7X = list(PWxzXLv5IwQgoujNO3DAdE2FBc4.resultsDICT.keys())
		xZy5cNb63pKj = sorted(O0saA45JcGKT7X,reverse=YoAMfqm37GyFxbuKTt6e8CESHrhB,key=lambda key: int(key))
		for jfRgOv7BWL9T8y in xZy5cNb63pKj:
			VV4iSgTwskE6uyoBCl3ZDh7HQ += PWxzXLv5IwQgoujNO3DAdE2FBc4.resultsDICT[jfRgOv7BWL9T8y]
	return VV4iSgTwskE6uyoBCl3ZDh7HQ
def QTpny8RsZK2rG4LwEiM5xgV(GTZC7rKJtPlueQ):
	wldq6ZILOox14kjE = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,OOhnpQ8XvCVclGqdu(u"ࠧࡢࡦࡧࡳࡳࡹࠧ༑"),GTZC7rKJtPlueQ,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ༒"))
	try: HIaTV3jRlcFvmAnN = open(wldq6ZILOox14kjE,s0vAWcLSXEToH9Mik134q(u"ࠩࡵࡦࠬ༓")).read()
	except:
		eA4a6JCXHBt78SOqvLRnw0DfuYZ = KiTt9ZskMLjnCAUIJNXD7.path.join(kjMow46qSfz58IZdWAYK1L3TJhl,v54ZuLY6dQ(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ༔"),GTZC7rKJtPlueQ,vZL6j4tSClIGxzNE5DX(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ༕"))
		try: HIaTV3jRlcFvmAnN = open(eA4a6JCXHBt78SOqvLRnw0DfuYZ,Xr2aHOK0huQ5DTS(u"ࠬࡸࡢࠨ༖")).read()
		except: return QigevCplXxbPI1H,[]
	if b7sJAmSxlBvaMdHFz: HIaTV3jRlcFvmAnN = HIaTV3jRlcFvmAnN.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	dqnC3F2VGJAkj84evDizcaUyTuB = sBvufaD6c9YHdOqTjCQ3.findall(y5yX4jh6kUEgWZQIc(u"࠭ࡩࡥ࠿࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃ࡛࡝ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡࠨ࡜ࠨ࡟ࠪ༗"),HIaTV3jRlcFvmAnN,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
	if not dqnC3F2VGJAkj84evDizcaUyTuB: return QigevCplXxbPI1H,[]
	xHM5T2Ogq1sliUuZYFaRWhPnXSj9,ttjUCQbRw8KTZSfYiG = dqnC3F2VGJAkj84evDizcaUyTuB[h17Zb2ld4yLBrCP5tiw],Kc4bRz3g5WTV(dqnC3F2VGJAkj84evDizcaUyTuB[h17Zb2ld4yLBrCP5tiw])
	return xHM5T2Ogq1sliUuZYFaRWhPnXSj9,ttjUCQbRw8KTZSfYiG
def wsIhgL9rolkO41f():
	i6KZ29SRfvzIksFyCOVDn4 = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,tOrSvd8QKNB(u"ࠧࡥ࡫ࡦࡸ༘ࠬ"),XWbHfI9B8swrOL(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓ༙ࠫ"),vZL6j4tSClIGxzNE5DX(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ༚"))
	if i6KZ29SRfvzIksFyCOVDn4: return i6KZ29SRfvzIksFyCOVDn4
	OiIo5yEB7C0,i6KZ29SRfvzIksFyCOVDn4 = {},{}
	zfljGLIQwP6U = [OQv0iWIw5bFRATU2mxJjZK[bDt7Ya1VEio3(u"ࠪࡖࡊࡖࡏࡔࠩ༛")][h17Zb2ld4yLBrCP5tiw]]
	if aybmzWnDkuEcT3jpJClB2>mpusoZBJ6V(u"࠳࠺࠲࠾࠿ጻ"): zfljGLIQwP6U.append(OQv0iWIw5bFRATU2mxJjZK[mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡗࡋࡐࡐࡕࠪ༜")][nfC2im3NzUQk])
	if b7sJAmSxlBvaMdHFz: zfljGLIQwP6U.append(OQv0iWIw5bFRATU2mxJjZK[FF70emVxhWOngCty(u"ࠬࡘࡅࡑࡑࡖࠫ༝")][JxuTQLOD357o41evylqPmRdf])
	for xNHKcvb29UDf5mRGdIrXzwZ in zfljGLIQwP6U:
		lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,pGncXOodjKhJzLSqVP1r(u"࠭ࡇࡆࡖࠪ༞"),xNHKcvb29UDf5mRGdIrXzwZ,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ༟"))
		if lE7ZB0CTayhKItApFnYxz.succeeded:
			zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
			n94QIFwGjNb = xNHKcvb29UDf5mRGdIrXzwZ.rsplit(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨ࠱ࠪ༠"),FF70emVxhWOngCty(u"࠴ጼ"))[h17Zb2ld4yLBrCP5tiw]
			ugvx25mkDNW = sBvufaD6c9YHdOqTjCQ3.findall(tOrSvd8QKNB(u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ༡"),zHrPxh0aevGnlKMTdjQsV,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
			for GTZC7rKJtPlueQ,ebTc92F7JdqvphzOR6UCQ in ugvx25mkDNW:
				E2hXLDvUf0cV81MqdbNeQ7y9lj = n94QIFwGjNb+v54ZuLY6dQ(u"ࠪ࠳ࠬ༢")+GTZC7rKJtPlueQ+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫ࠴࠭༣")+GTZC7rKJtPlueQ+OOhnpQ8XvCVclGqdu(u"ࠬ࠳ࠧ༤")+ebTc92F7JdqvphzOR6UCQ+mmKqLr9RX0ACN384JMcsFHzd(u"࠭࠮ࡻ࡫ࡳࠫ༥")
				if GTZC7rKJtPlueQ not in list(OiIo5yEB7C0.keys()):
					OiIo5yEB7C0[GTZC7rKJtPlueQ] = []
					i6KZ29SRfvzIksFyCOVDn4[GTZC7rKJtPlueQ] = []
				uAcTUr5t1og7MqENefjR8wHLSG = Kc4bRz3g5WTV(ebTc92F7JdqvphzOR6UCQ)
				OiIo5yEB7C0[GTZC7rKJtPlueQ].append((ebTc92F7JdqvphzOR6UCQ,uAcTUr5t1og7MqENefjR8wHLSG,E2hXLDvUf0cV81MqdbNeQ7y9lj))
	for GTZC7rKJtPlueQ in list(OiIo5yEB7C0.keys()):
		i6KZ29SRfvzIksFyCOVDn4[GTZC7rKJtPlueQ] = sorted(OiIo5yEB7C0[GTZC7rKJtPlueQ],reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,key=lambda key: key[nfC2im3NzUQk])
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ༦"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ༧"),i6KZ29SRfvzIksFyCOVDn4,pETKl7xuH1f5yjdFAb6C8JzOLV)
	return i6KZ29SRfvzIksFyCOVDn4
def Kc4bRz3g5WTV(ebTc92F7JdqvphzOR6UCQ):
	uAcTUr5t1og7MqENefjR8wHLSG = []
	ZvgdS8H36zbwMEYKaV4s = ebTc92F7JdqvphzOR6UCQ.split(JJu4MPClbTFpUwHiN(u"ࠩ࠱ࠫ༨"))
	for MGoAvuTzp67QP8K91xYOf in ZvgdS8H36zbwMEYKaV4s:
		OUg7Vni1RpwJ = sBvufaD6c9YHdOqTjCQ3.findall(v54ZuLY6dQ(u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧ༩"),MGoAvuTzp67QP8K91xYOf,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		b3E5ql14F2gvMQVcaBU0t = []
		for F9sJPmAzXvWdtjS2b50p in OUg7Vni1RpwJ:
			if F9sJPmAzXvWdtjS2b50p.isdigit(): F9sJPmAzXvWdtjS2b50p = int(F9sJPmAzXvWdtjS2b50p)
			b3E5ql14F2gvMQVcaBU0t.append(F9sJPmAzXvWdtjS2b50p)
		uAcTUr5t1og7MqENefjR8wHLSG.append(b3E5ql14F2gvMQVcaBU0t)
	return uAcTUr5t1og7MqENefjR8wHLSG
def bFu5sT4KA1MXwj(uAcTUr5t1og7MqENefjR8wHLSG):
	ebTc92F7JdqvphzOR6UCQ = QigevCplXxbPI1H
	for MGoAvuTzp67QP8K91xYOf in uAcTUr5t1og7MqENefjR8wHLSG:
		for F9sJPmAzXvWdtjS2b50p in MGoAvuTzp67QP8K91xYOf: ebTc92F7JdqvphzOR6UCQ += str(F9sJPmAzXvWdtjS2b50p)
		ebTc92F7JdqvphzOR6UCQ += bDt7Ya1VEio3(u"ࠫ࠳࠭༪")
	ebTc92F7JdqvphzOR6UCQ = ebTc92F7JdqvphzOR6UCQ.strip(tg9l25NH6WTacVSifLyAmY(u"ࠬ࠴ࠧ༫"))
	return ebTc92F7JdqvphzOR6UCQ
def ZMdfXcs4e1Y3qhuO7t6Fg0TwyaCpj(xxRFbaG53ph8Kd1lv):
	S5NRneCz4GQJoVWFxBM7c = {}
	OiIo5yEB7C0 = wsIhgL9rolkO41f()
	tBozgl3i9Y8Hd = BOfcPywrJb(xxRFbaG53ph8Kd1lv)
	for GTZC7rKJtPlueQ in xxRFbaG53ph8Kd1lv:
		if GTZC7rKJtPlueQ not in list(OiIo5yEB7C0.keys()): continue
		i6KZ29SRfvzIksFyCOVDn4 = OiIo5yEB7C0[GTZC7rKJtPlueQ]
		Ed0XW2sFHvea,ukqJwnOvXg,Vfpave4EDnHi50WwsLXC2B = i6KZ29SRfvzIksFyCOVDn4[h17Zb2ld4yLBrCP5tiw]
		peIwGURStOhP,pMaVt5K0bOGFe2W = QTpny8RsZK2rG4LwEiM5xgV(GTZC7rKJtPlueQ)
		mSthwc9F8In,QkzT3aHj84yZsrtPxIwf6pMD = tBozgl3i9Y8Hd[GTZC7rKJtPlueQ]
		PMT9dgp1W8 = ukqJwnOvXg>pMaVt5K0bOGFe2W and mSthwc9F8In
		EkxQ20jJyPDcu8Bh5w176sX4C = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if not mSthwc9F8In: MMsvzfBQCL18ecy2W = Fg72JX6T5DkPy(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧ༬")
		elif not QkzT3aHj84yZsrtPxIwf6pMD: MMsvzfBQCL18ecy2W = y5yX4jh6kUEgWZQIc(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ༭")
		elif PMT9dgp1W8: MMsvzfBQCL18ecy2W = tg9l25NH6WTacVSifLyAmY(u"ࠨࡱ࡯ࡨࠬ༮")
		else:
			MMsvzfBQCL18ecy2W = pGncXOodjKhJzLSqVP1r(u"ࠩࡪࡳࡴࡪࠧ༯")
			EkxQ20jJyPDcu8Bh5w176sX4C = YoAMfqm37GyFxbuKTt6e8CESHrhB
		S5NRneCz4GQJoVWFxBM7c[GTZC7rKJtPlueQ] = (EkxQ20jJyPDcu8Bh5w176sX4C,peIwGURStOhP,pMaVt5K0bOGFe2W,Ed0XW2sFHvea,ukqJwnOvXg,MMsvzfBQCL18ecy2W,Vfpave4EDnHi50WwsLXC2B)
	return S5NRneCz4GQJoVWFxBM7c
def flLzKUbZqpmX(KeUEGFHb0LfrZhCaqd3O4NuDTQ,PjUf0H7cdkSizM1,zIQnGf4pO1oiTbu=QigevCplXxbPI1H,Ng6Xu8T3nSxZAvd5I=QigevCplXxbPI1H,t7fJr4MkoWDpUa6l=QigevCplXxbPI1H):
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: KeUEGFHb0LfrZhCaqd3O4NuDTQ.update(PjUf0H7cdkSizM1,zIQnGf4pO1oiTbu,Ng6Xu8T3nSxZAvd5I,t7fJr4MkoWDpUa6l)
	else: KeUEGFHb0LfrZhCaqd3O4NuDTQ.update(PjUf0H7cdkSizM1,zIQnGf4pO1oiTbu+aSBkt4OU8JpWTEzVIHjAiv+Ng6Xu8T3nSxZAvd5I+aSBkt4OU8JpWTEzVIHjAiv+t7fJr4MkoWDpUa6l)
	return
def eCLWPXUqk9uo(ixUV6tokgq0K8a):
	def rokxU4GLlei6d2wyI(yX0iodevMHp4TfJmnS,whgSVN07RoY4js1Di8tlqLprK2kW,NlAj5fW7Y049ZSyXqEGeMKH8hst=tOrSvd8QKNB(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥ༰")):
		return ((yX0iodevMHp4TfJmnS == h17Zb2ld4yLBrCP5tiw) and NlAj5fW7Y049ZSyXqEGeMKH8hst[h17Zb2ld4yLBrCP5tiw]) or (rokxU4GLlei6d2wyI(yX0iodevMHp4TfJmnS // whgSVN07RoY4js1Di8tlqLprK2kW, whgSVN07RoY4js1Di8tlqLprK2kW, NlAj5fW7Y049ZSyXqEGeMKH8hst).lstrip(NlAj5fW7Y049ZSyXqEGeMKH8hst[h17Zb2ld4yLBrCP5tiw]) + NlAj5fW7Y049ZSyXqEGeMKH8hst[yX0iodevMHp4TfJmnS % whgSVN07RoY4js1Di8tlqLprK2kW])
	def qz0B6AUPVYd4Zj3SpF7mKr(TMmUrXFd1p3D26E, JTMk2hstqR, ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm, XFEvWL5n8U7gVOsfZeRbymCk61x, qsTlPZ7mYO4k8FUSLHV1WAxb9r0=None, lWpU8hve642Qdm9BJoKjVrIf=None, g9gcbO7phof8a10FnmGHktdCrRNAu=None):
		while (ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm):
			ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm-=mmKqLr9RX0ACN384JMcsFHzd(u"࠵ጽ")
			if (XFEvWL5n8U7gVOsfZeRbymCk61x[ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm]): TMmUrXFd1p3D26E = sBvufaD6c9YHdOqTjCQ3.sub(OOhnpQ8XvCVclGqdu(u"ࠦࡡࡢࡢࠣ༱") + rokxU4GLlei6d2wyI(ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm, JTMk2hstqR) + QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡢ࡜ࡣࠤ༲"),  XFEvWL5n8U7gVOsfZeRbymCk61x[ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm], TMmUrXFd1p3D26E)
		return TMmUrXFd1p3D26E
	ixUV6tokgq0K8a = ixUV6tokgq0K8a.split(bDt7Ya1VEio3(u"࠭ࡽࠩࠩ༳"))[nfC2im3NzUQk]
	ixUV6tokgq0K8a = ixUV6tokgq0K8a.rsplit(O4ylJvVNwLztdiHqBWDU(u"ࠧࡴࡲ࡯࡭ࡹ࠭༴"))[h17Zb2ld4yLBrCP5tiw]+tg9l25NH6WTacVSifLyAmY(u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨ༵")
	xu3Kmpia9Q0RvB5ZwnhLYNF = eval(XWbHfI9B8swrOL(u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪ༶")+ixUV6tokgq0K8a,{FF70emVxhWOngCty(u"ࠪࡦࡦࡹࡥࡏ༷ࠩ"):rokxU4GLlei6d2wyI,vZL6j4tSClIGxzNE5DX(u"ࠫࡺࡴࡰࡢࡥ࡮ࠫ༸"):qz0B6AUPVYd4Zj3SpF7mKr})
	return xu3Kmpia9Q0RvB5ZwnhLYNF
def jirDyBYxJNw(iCr0xsqwDZXLPaJK1W5YU24F6hp,XvMKdLp4nBmS78w5=QigevCplXxbPI1H):
	if XvMKdLp4nBmS78w5==JJu4MPClbTFpUwHiN(u"ࠬࡲ࡯ࡸࡧࡵ༹ࠫ"): iCr0xsqwDZXLPaJK1W5YU24F6hp = sBvufaD6c9YHdOqTjCQ3.sub(mmKqLr9RX0ACN384JMcsFHzd(u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭༺"),lambda OysAGK2SoqHCkRX3Bp: OysAGK2SoqHCkRX3Bp.group(h17Zb2ld4yLBrCP5tiw).lower(),iCr0xsqwDZXLPaJK1W5YU24F6hp)
	elif XvMKdLp4nBmS78w5==tOrSvd8QKNB(u"ࠧࡶࡲࡳࡩࡷ࠭༻"): iCr0xsqwDZXLPaJK1W5YU24F6hp = sBvufaD6c9YHdOqTjCQ3.sub(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨ༼"),lambda OysAGK2SoqHCkRX3Bp: OysAGK2SoqHCkRX3Bp.group(h17Zb2ld4yLBrCP5tiw).upper(),iCr0xsqwDZXLPaJK1W5YU24F6hp)
	return iCr0xsqwDZXLPaJK1W5YU24F6hp
def BOfcPywrJb(xxRFbaG53ph8Kd1lv):
	b2NlueaqrMgxD6c91QJThtGCiLm,rcDAWwxBH9dKtR1ojh = YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB
	R2wuKSVBTLW4sAOQNob18UEdGf0hv = DZLbiWNFXwpM26.connect(h8oaOyKE9vx0F7sQUkumSGYCD5VZ)
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.text_factory = str
	B6xRu5lFyJ = R2wuKSVBTLW4sAOQNob18UEdGf0hv.cursor()
	if len(xxRFbaG53ph8Kd1lv)==nfC2im3NzUQk: GGaKIJYM3xErVly64TN = tg9l25NH6WTacVSifLyAmY(u"ࠩࠫࠦࠬ༽")+xxRFbaG53ph8Kd1lv[h17Zb2ld4yLBrCP5tiw]+tg9l25NH6WTacVSifLyAmY(u"ࠪࠦ࠮࠭༾")
	else: GGaKIJYM3xErVly64TN = str(tuple(xxRFbaG53ph8Kd1lv))
	B6xRu5lFyJ.execute(JJu4MPClbTFpUwHiN(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫ༿")+GGaKIJYM3xErVly64TN+s0vAWcLSXEToH9Mik134q(u"ࠬࠦ࠻ࠨཀ"))
	evn4M7hX8L2QKZHNEamVz5kw = B6xRu5lFyJ.fetchall()
	tBozgl3i9Y8Hd = {}
	for GTZC7rKJtPlueQ in xxRFbaG53ph8Kd1lv: tBozgl3i9Y8Hd[GTZC7rKJtPlueQ] = (YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	for GTZC7rKJtPlueQ,rcDAWwxBH9dKtR1ojh in evn4M7hX8L2QKZHNEamVz5kw:
		b2NlueaqrMgxD6c91QJThtGCiLm = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		rcDAWwxBH9dKtR1ojh = rcDAWwxBH9dKtR1ojh==nfC2im3NzUQk
		tBozgl3i9Y8Hd[GTZC7rKJtPlueQ] = (b2NlueaqrMgxD6c91QJThtGCiLm,rcDAWwxBH9dKtR1ojh)
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	return tBozgl3i9Y8Hd
def obvQGmCVO8(Hl7FmSYzejKpB1v8T0):
	W9lfsoMawqOzpQcXD = QigevCplXxbPI1H
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(Hl7FmSYzejKpB1v8T0):
		MPuNKf0A87TUDJkxs15o = open(Hl7FmSYzejKpB1v8T0,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡲࡣࠩཁ")).read()
		if b7sJAmSxlBvaMdHFz: MPuNKf0A87TUDJkxs15o = MPuNKf0A87TUDJkxs15o.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		T1KgXNQCPHRx9nk6uWy08mqr = CH86N7xw4cyPt3TlIBJF(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡥ࡫ࡦࡸࠬག"),MPuNKf0A87TUDJkxs15o)
		if T1KgXNQCPHRx9nk6uWy08mqr:
			W9lfsoMawqOzpQcXD = {}
			for QQPBwuOv2LeWXTnYygj in T1KgXNQCPHRx9nk6uWy08mqr.keys():
				W9lfsoMawqOzpQcXD[QQPBwuOv2LeWXTnYygj] = []
				for z0JBqv6XsMa52 in T1KgXNQCPHRx9nk6uWy08mqr[QQPBwuOv2LeWXTnYygj]:
					NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
					NWdTSkYP5E6wqsDogApZmLCcbu3j2I = z0JBqv6XsMa52[h17Zb2ld4yLBrCP5tiw]
					yBWPDAeJF1o2b = z0JBqv6XsMa52[nfC2im3NzUQk]
					yBWPDAeJF1o2b = rybze7NZwv(yBWPDAeJF1o2b)
					iCr0xsqwDZXLPaJK1W5YU24F6hp = z0JBqv6XsMa52[JxuTQLOD357o41evylqPmRdf]
					zcl5RYhWSMKwDGqLjtgknbU = z0JBqv6XsMa52[mVjHAyIwzSNKLFcd]
					XGjn5q2cy6mRYZ1hPaDslHMK = z0JBqv6XsMa52[bWU9StnJOg6aIQiTMxh7sFZG8lPud]
					JJM6TofH4g5n7SRwq = z0JBqv6XsMa52[pGncXOodjKhJzLSqVP1r(u"࠺ጾ")]
					if len(z0JBqv6XsMa52)>g4UCaNkHvLwGhjmW(u"࠼ጿ"): CyarqoiHxV2e80ScjAN = z0JBqv6XsMa52[g4UCaNkHvLwGhjmW(u"࠼ጿ")]
					if len(z0JBqv6XsMa52)>g4UCaNkHvLwGhjmW(u"࠷ፀ"): Jl1Za0IHxnshWC = z0JBqv6XsMa52[g4UCaNkHvLwGhjmW(u"࠷ፀ")]
					if len(z0JBqv6XsMa52)>VvhRUZgko5Af1BIynMGOJSbpmK(u"࠹ፁ"): zHTPjrSgp8Zcbf = z0JBqv6XsMa52[VvhRUZgko5Af1BIynMGOJSbpmK(u"࠹ፁ")]
					if Hl7FmSYzejKpB1v8T0==RpmwIQ5vaFkP8SuNW: MH3JaSU9wAeXizlNIfsjtb6Yh = NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,QigevCplXxbPI1H,zHTPjrSgp8Zcbf
					else: MH3JaSU9wAeXizlNIfsjtb6Yh = NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf
					W9lfsoMawqOzpQcXD[QQPBwuOv2LeWXTnYygj].append(MH3JaSU9wAeXizlNIfsjtb6Yh)
		OksXbHD6tZEGfzA = str(W9lfsoMawqOzpQcXD)
		if b7sJAmSxlBvaMdHFz: OksXbHD6tZEGfzA = OksXbHD6tZEGfzA.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		open(Hl7FmSYzejKpB1v8T0,bDt7Ya1VEio3(u"ࠨࡹࡥࠫགྷ")).write(OksXbHD6tZEGfzA)
	return W9lfsoMawqOzpQcXD
def nBYW0gcOpt7HyfU(c1Ifu0OGV2kyRwLPWlsho8Ct6nz):
	Ra2yxXL9dS74v6pNekCDEf1 = c1Ifu0OGV2kyRwLPWlsho8Ct6nz.split(svULcgJ7jm(u"ࠩ࠰ࠫང"),nfC2im3NzUQk)[h17Zb2ld4yLBrCP5tiw]
	CNdL1jR9m2AWpBV4PKitDhnx5qw,srPjEeQn5UkWDfKm,Ej3yCdX0csTKgrwlvqm2nBPZz8If = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	if   Ra2yxXL9dS74v6pNekCDEf1==O4ylJvVNwLztdiHqBWDU(u"ࠪࡅࡍ࡝ࡁࡌࠩཅ")		:	from dSKVnvcC7j			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==Xr2aHOK0huQ5DTS(u"ࠫࡆࡑࡏࡂࡏࠪཆ")		:	from LgyfTlFJC3			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==pTwKPmzMSZhil5d2RWonre(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧཇ")	:	from on6lS1PVQD		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡁࡌ࡙ࡄࡑࠬ཈")		:	from kkERyGgDWI			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==O4ylJvVNwLztdiHqBWDU(u"ࠧࡂࡎࡄࡖࡆࡈࠧཉ")	:	from Ofe0and35Y			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==s0vAWcLSXEToH9Mik134q(u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋࠪཊ")	:	from GbRwVnkQAe		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==svULcgJ7jm(u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖࠬཋ")	: 	from G2GmZRAJL3		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬཌ")	:	from xRgEewDY5T		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩཌྷ"):	from ouRLGAy4mp	import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==O4ylJvVNwLztdiHqBWDU(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧཎ")	:	from ddwWLZ315h		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==g4UCaNkHvLwGhjmW(u"࠭ࡂࡐࡍࡕࡅࠬཏ")		:	from gzhm8lLXR0			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==v54ZuLY6dQ(u"ࠧࡃࡔࡖࡘࡊࡐࠧཐ")	:	from G96qTLtC0D			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩད")	:	from vzKntVZWid		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==mpusoZBJ6V(u"ࠩࡆࡍࡒࡇ࠴ࡖࠩདྷ")	:	from Jv9dkHFNmq			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==vZL6j4tSClIGxzNE5DX(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬན")	:	from Pe1N9oEwBQ		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪཔ"):	from YA9gyEk8nj	import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==Xr2aHOK0huQ5DTS(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧཕ"):		from xKNzwc5Jhp		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨབ")	:	from dL4SBey7iu		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==bDt7Ya1VEio3(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩབྷ")	:	from EGuw05DT4l		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫམ")	:	from MGUDSETYwn		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪཙ")	:	from ssTIo54KM1		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨཚ"):	from rYtXalHbju	import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OOhnpQ8XvCVclGqdu(u"ࠫࡉࡘࡁࡎࡃࡖ࠻ࠬཛ")	:	from FGiYDtxzh6		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==v54ZuLY6dQ(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠭ཛྷ")	:	from UOvqsPuVWh		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==tOrSvd8QKNB(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨཝ")	:	from yyrKVk7Tl8		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==v54ZuLY6dQ(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩཞ")	:	from ijXgSh7lG3		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪཟ")	:	from ymHvX9woJW		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==s0vAWcLSXEToH9Mik134q(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫའ")	:	from B6keJXpbSa		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OTRKI6LbrQnZEm(u"ࠪࡉࡌ࡟ࡄࡆࡃࡇࠫཡ")	:	from zCnEmBKejJ		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==bDt7Ya1VEio3(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫར")	:	from p4H1dtwvk9			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==tg9l25NH6WTacVSifLyAmY(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ལ")	:	from vPwrcKMf0q		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==O4ylJvVNwLztdiHqBWDU(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩཤ")	:	from zVn5N1ujF0		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩཥ")	:	from tIuoSjwAEZ		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪས")	:	from i0BW9X58Z6		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==tg9l25NH6WTacVSifLyAmY(u"ࠩࡉࡓࡘ࡚ࡁࠨཧ")		:	from ww0sOSEGjh			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬཨ")	:	from MMPgAmhWqX		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==v54ZuLY6dQ(u"ࠫࡎࡌࡉࡍࡏࠪཀྵ")		:	from WespT4cdLO			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==pTwKPmzMSZhil5d2RWonre(u"ࠬࡏࡐࡕࡘࠪཪ")		:	from WnaUtzx70u	import aARx6VJZyYimz8Ns as CNdL1jR9m2AWpBV4PKitDhnx5qw,xajb3VgNyPAo as srPjEeQn5UkWDfKm,KNY6Ao0Stysxc as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==g4UCaNkHvLwGhjmW(u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩཫ")	:	from RRDfn7qJAx		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩཬ")	:	from KX7wHeEzrW		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OTRKI6LbrQnZEm(u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ཭")	:	from zzwTfWEtBN		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==mpusoZBJ6V(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ཮")	:	from ew4SbOFp6g			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==pGncXOodjKhJzLSqVP1r(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ཯")	:	from XycSan34st		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==mpusoZBJ6V(u"ࠫࡒ࠹ࡕࠨ཰")		:	from BGdPH3ey27	import aARx6VJZyYimz8Ns as CNdL1jR9m2AWpBV4PKitDhnx5qw,xajb3VgNyPAo as srPjEeQn5UkWDfKm,KNY6Ao0Stysxc as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==bDt7Ya1VEio3(u"ࠬࡓࡏࡗࡕ࠷ཱ࡙ࠬ")	:	from LMRkxQV5j6			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==s0vAWcLSXEToH9Mik134q(u"࠭ࡍ࡚ࡅࡌࡑࡆི࠭")	:	from YgfswWlCO1			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OOhnpQ8XvCVclGqdu(u"ࠧࡑࡃࡑࡉཱི࡙࠭")		:	from BpNaEDFt9Z			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OOhnpQ8XvCVclGqdu(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗུࠪ")	:	from Q8XUhOplV9		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘཱུ࠭"):	from nOi2FhC05g		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==y5yX4jh6kUEgWZQIc(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭ྲྀ")	:	from HDJbuwfOU1		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==O4ylJvVNwLztdiHqBWDU(u"ࠫࡘࡎࡏࡇࡊࡄࠫཷ")	:	from bh6GSD1NJp			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==s0vAWcLSXEToH9Mik134q(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧླྀ")	:	from ttgsXAMpEc		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OTRKI6LbrQnZEm(u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨཹ")	:	from RflsiP2MmZ		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==g4UCaNkHvLwGhjmW(u"ࠧࡕࡘࡉ࡙ࡓེ࠭")		:	from ggl2cikBed			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==mmKqLr9RX0ACN384JMcsFHzd(u"ࠨ࡙ࡈࡇࡎࡓࡁࠨཻ")	:	from FCjhbSetXr			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==FF70emVxhWOngCty(u"ࠩ࡜ࡅࡖࡕࡔࠨོ")		:	from tPYFqaHhnB			import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==OOhnpQ8XvCVclGqdu(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈཽࠫ")	:	from ikY7SnFWRE		import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw,UJL7oB1rySs6ERpjGnhvz as srPjEeQn5UkWDfKm,iiWOIMsq4w3zkHdyo0CEDm2vGhnB as Ej3yCdX0csTKgrwlvqm2nBPZz8If
	elif Ra2yxXL9dS74v6pNekCDEf1==O4ylJvVNwLztdiHqBWDU(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪཾ"):	from jMRK5bBnDI	import vZR0cSd4X7seq as CNdL1jR9m2AWpBV4PKitDhnx5qw
	return CNdL1jR9m2AWpBV4PKitDhnx5qw,srPjEeQn5UkWDfKm,Ej3yCdX0csTKgrwlvqm2nBPZz8If
def HMm6TqGlgU75axyS(MAs8kRan5hr1xCVqbTLDY4,zXCVN4eIxRJTrUD,showDialogs):
	SQdRhwozVfv(AwKhgdpmBj0,pGncXOodjKhJzLSqVP1r(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬ࡀࠠ࡜ࠢࠪཿ")+MAs8kRan5hr1xCVqbTLDY4+fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠ࡞ࠢࠣࠤࡍ࡫ࡡࡥࡧࡵࡷ࠿ྀ࡛ࠦࠡࠩ")+str(zXCVN4eIxRJTrUD)+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࠡ࡟ཱྀࠪ"))
	KeUEGFHb0LfrZhCaqd3O4NuDTQ = EkO3SZvUhBmswzoC2cKRbfxyMYW7H()
	KeUEGFHb0LfrZhCaqd3O4NuDTQ.create(FF70emVxhWOngCty(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫྂ"),XWbHfI9B8swrOL(u"ࠩํะึ๐ࠠศๆล๊ࠥ็อึࠢส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่๋ࠢฬ฾ี็ศࠢึ์ๆࠦสษัฦࠤ฾๋ไ๋หࠣะ้ฮࠠศๆ่่ๆࠦๅ็ࠢส่ส์สา่อࠫྃ"))
	KmQftHqs6RuGLIg2lO7ndPUehX3DAJ = VvhRUZgko5Af1BIynMGOJSbpmK(u"࠳࠳࠶࠹ፂ")*VvhRUZgko5Af1BIynMGOJSbpmK(u"࠳࠳࠶࠹ፂ")
	uSeb5NCvDaqcfBEKskFOjoim16 = DDHwpETQrAm0xMNXGfyhqsUi(u"࠴ፃ")*KmQftHqs6RuGLIg2lO7ndPUehX3DAJ
	import requests as rBU6o8SmdykhQ
	lE7ZB0CTayhKItApFnYxz = rBU6o8SmdykhQ.get(MAs8kRan5hr1xCVqbTLDY4,stream=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,headers=zXCVN4eIxRJTrUD)
	jdbZyk16xNo7BQIcvaiHUp3KlE8W = lE7ZB0CTayhKItApFnYxz.headers
	lE7ZB0CTayhKItApFnYxz.close()
	IwtThn4Mqc7dROV5uUKap = bytes()
	if not jdbZyk16xNo7BQIcvaiHUp3KlE8W:
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั྄࠭"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํฮ๊้ๆࠡ็้ࠤฯำๅ๋ๆࠣห้๋ไโࠢส่๊฽ไ้สࠣ์ฬ๊ำษสࠣๆิ๊ࠦไ๊้ࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡ࠰ࠣะึฮࠠหฯ่๎้ࠦวๅ็็ๅ๋ࠥัสࠢฦาึ๏ࠧ྅"))
		KeUEGFHb0LfrZhCaqd3O4NuDTQ.close()
	else:
		if pGncXOodjKhJzLSqVP1r(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭྆") not in list(jdbZyk16xNo7BQIcvaiHUp3KlE8W.keys()): usrpQtbFTCq = h17Zb2ld4yLBrCP5tiw
		else: usrpQtbFTCq = int(jdbZyk16xNo7BQIcvaiHUp3KlE8W[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ྇")])
		g1gQfCpZG3ViFtl = str(int(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠶࠶࠰࠱ፅ")*usrpQtbFTCq/KmQftHqs6RuGLIg2lO7ndPUehX3DAJ)/NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠵࠵࠶࠰࠯࠲ፄ"))
		aaEGJYkv6tcRMso1hK0 = int(usrpQtbFTCq/uSeb5NCvDaqcfBEKskFOjoim16)+nfC2im3NzUQk
		if g4UCaNkHvLwGhjmW(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡔࡤࡲ࡬࡫ࠧྈ") in list(jdbZyk16xNo7BQIcvaiHUp3KlE8W.keys()) and usrpQtbFTCq>KmQftHqs6RuGLIg2lO7ndPUehX3DAJ:
			nbgpZETB9t4Uszwh7cCD5HPW = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			Ud4PLKmr8M = []
			bLjM0cQ9mTONiEasV = vZL6j4tSClIGxzNE5DX(u"࠷࠰ፆ")
			Ud4PLKmr8M.append(str(h17Zb2ld4yLBrCP5tiw*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+svULcgJ7jm(u"ࠨ࠯ࠪྉ")+str(nfC2im3NzUQk*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(nfC2im3NzUQk*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+Xr2aHOK0huQ5DTS(u"ࠩ࠰ࠫྊ")+str(JxuTQLOD357o41evylqPmRdf*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(JxuTQLOD357o41evylqPmRdf*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+s0vAWcLSXEToH9Mik134q(u"ࠪ࠱ࠬྋ")+str(mVjHAyIwzSNKLFcd*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(mVjHAyIwzSNKLFcd*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+FF70emVxhWOngCty(u"ࠫ࠲࠭ྌ")+str(bWU9StnJOg6aIQiTMxh7sFZG8lPud*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(bWU9StnJOg6aIQiTMxh7sFZG8lPud*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+pTwKPmzMSZhil5d2RWonre(u"ࠬ࠳ࠧྍ")+str(DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠵ፇ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(pGncXOodjKhJzLSqVP1r(u"࠶ፈ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+mpusoZBJ6V(u"࠭࠭ࠨྎ")+str(OOhnpQ8XvCVclGqdu(u"࠸ፉ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠺ፋ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+Fg72JX6T5DkPy(u"ࠧ࠮ࠩྏ")+str(tg9l25NH6WTacVSifLyAmY(u"࠺ፊ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠽ፍ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+y5yX4jh6kUEgWZQIc(u"ࠨ࠯ࠪྐ")+str(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠽ፌ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(pGncXOodjKhJzLSqVP1r(u"࠹ፏ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩ࠰ࠫྑ")+str(DDHwpETQrAm0xMNXGfyhqsUi(u"࠹ፎ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV-nfC2im3NzUQk))
			Ud4PLKmr8M.append(str(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠻ፐ")*usrpQtbFTCq//bLjM0cQ9mTONiEasV)+v54ZuLY6dQ(u"ࠪ࠱ࠬྒ"))
			OnXG5y2zBSANp17Kd0 = float(aaEGJYkv6tcRMso1hK0)/bLjM0cQ9mTONiEasV
			m5z7YfuGB9Pa0LHSrqpXx2k4ZcdK = OnXG5y2zBSANp17Kd0/int(nfC2im3NzUQk+OnXG5y2zBSANp17Kd0)
		else:
			nbgpZETB9t4Uszwh7cCD5HPW = YoAMfqm37GyFxbuKTt6e8CESHrhB
			bLjM0cQ9mTONiEasV = nfC2im3NzUQk
			m5z7YfuGB9Pa0LHSrqpXx2k4ZcdK = nfC2im3NzUQk
		SQdRhwozVfv(AwKhgdpmBj0,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡸࡷ࡮ࡴࡧࠡࡴࡤࡲ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬྒྷ")+str(nbgpZETB9t4Uszwh7cCD5HPW)+XWbHfI9B8swrOL(u"ࠬࠦ࡝ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧྔ")+str(usrpQtbFTCq)+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࠠ࡞ࠩྕ"))
		GzabfJx3T1,RCDTJLnfemc4upszPHa8lqK = h17Zb2ld4yLBrCP5tiw,h17Zb2ld4yLBrCP5tiw
		for UbThgLS9PfiE605FJHtqQDBR in range(bLjM0cQ9mTONiEasV):
			T24Te3uDwBS5vLgUEAhF1O = zXCVN4eIxRJTrUD.copy()
			if nbgpZETB9t4Uszwh7cCD5HPW: T24Te3uDwBS5vLgUEAhF1O[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡓࡣࡱ࡫ࡪ࠭ྖ")] = mpusoZBJ6V(u"ࠨࡤࡼࡸࡪࡹ࠽ࠨྗ")+Ud4PLKmr8M[UbThgLS9PfiE605FJHtqQDBR]
			lE7ZB0CTayhKItApFnYxz = rBU6o8SmdykhQ.get(MAs8kRan5hr1xCVqbTLDY4,stream=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,headers=T24Te3uDwBS5vLgUEAhF1O,timeout=O4ylJvVNwLztdiHqBWDU(u"࠶࠴࠵ፑ"))
			for VMKRvPbXNQtfHcIyT2e3o in lE7ZB0CTayhKItApFnYxz.iter_content(chunk_size=uSeb5NCvDaqcfBEKskFOjoim16):
				if KeUEGFHb0LfrZhCaqd3O4NuDTQ.iscanceled():
					SQdRhwozVfv(AwKhgdpmBj0,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡄࡣࡱࡧࡪࡲࡥࡥࠩ྘"))
					break
				GzabfJx3T1 += m5z7YfuGB9Pa0LHSrqpXx2k4ZcdK
				IwtThn4Mqc7dROV5uUKap += VMKRvPbXNQtfHcIyT2e3o
				if not RCDTJLnfemc4upszPHa8lqK: RCDTJLnfemc4upszPHa8lqK = len(VMKRvPbXNQtfHcIyT2e3o)
				if usrpQtbFTCq: flLzKUbZqpmX(KeUEGFHb0LfrZhCaqd3O4NuDTQ,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠵࠶ፒ")*GzabfJx3T1//aaEGJYkv6tcRMso1hK0,tOrSvd8QKNB(u"ࠪะ้ฮࠠศๆ่่ๆࡀ࠭ࠡษ็ะืวࠠาไ่ࠫྙ"),str(Xr2aHOK0huQ5DTS(u"࠶࠶࠰࠯࠲ፓ")*RCDTJLnfemc4upszPHa8lqK*GzabfJx3T1//uSeb5NCvDaqcfBEKskFOjoim16//Xr2aHOK0huQ5DTS(u"࠶࠶࠰࠯࠲ፓ"))+s0vAWcLSXEToH9Mik134q(u"ࠫࠥ࠵ࠠࠨྚ")+g1gQfCpZG3ViFtl+s0vAWcLSXEToH9Mik134q(u"ࠬࠦࡍࡃࠩྛ"))
				else: flLzKUbZqpmX(KeUEGFHb0LfrZhCaqd3O4NuDTQ,RCDTJLnfemc4upszPHa8lqK*GzabfJx3T1//uSeb5NCvDaqcfBEKskFOjoim16,XWbHfI9B8swrOL(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠫྜ"),str(g4UCaNkHvLwGhjmW(u"࠷࠰࠱࠰࠳ፔ")*RCDTJLnfemc4upszPHa8lqK*GzabfJx3T1//uSeb5NCvDaqcfBEKskFOjoim16//g4UCaNkHvLwGhjmW(u"࠷࠰࠱࠰࠳ፔ"))+pGncXOodjKhJzLSqVP1r(u"ࠧࠡࡏࡅࠫྜྷ"))
			lE7ZB0CTayhKItApFnYxz.close()
		KeUEGFHb0LfrZhCaqd3O4NuDTQ.close()
		if len(IwtThn4Mqc7dROV5uUKap)<usrpQtbFTCq and usrpQtbFTCq>h17Zb2ld4yLBrCP5tiw:
			SQdRhwozVfv(AwKhgdpmBj0,OOhnpQ8XvCVclGqdu(u"ࠨ࠰࡟ࡸࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡦࡢ࡫࡯ࡩࡩࠦ࡯ࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡦࡺ࠺ࠡ࡝ࠣࠫྞ")+str(len(IwtThn4Mqc7dROV5uUKap)//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ)+OOhnpQ8XvCVclGqdu(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊࡷࡵ࡭ࠡࡶࡲࡸࡦࡲࠠࡰࡨ࠽ࠤࡠࠦࠧྟ")+g1gQfCpZG3ViFtl+v54ZuLY6dQ(u"ࠪࠤࡒࡈࠠ࡞ࠩྠ"))
			qqTR9xfSyG0j43H = L2Lu1MQVHhiTX0(QigevCplXxbPI1H,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫสฺ๊ศรࠣ์ำื่อࠩྡ"),JJu4MPClbTFpUwHiN(u"ࠬอำหะาห๊ࠦวๅ็็ๅࠥอไ็ษๅูࠬྡྷ"),O4ylJvVNwLztdiHqBWDU(u"࠭ลฺษาอࠥาไษࠢส่๊๊แࠨྣ"),JJu4MPClbTFpUwHiN(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪྤ"),vZL6j4tSClIGxzNE5DX(u"ࠨใื่ࠥ็๊ࠡฮ็ฬࠥอไๆๆไࠤࡡࡴࠠๅๆฦืๆࠦอะอࠣา฼ษࠠโ์ࠣฮา๋๊ๅࠢส่๊๊แࠡ࡞ࡱࠤฯ๋ࠠอๆหࠤࠬྥ")+str(len(IwtThn4Mqc7dROV5uUKap)//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ)+mmKqLr9RX0ACN384JMcsFHzd(u"้ࠩࠣ๏เวษษํฮ๋ࠥๆࠡ็ฯ้ํ฿ࠠࠨྦ")+g1gQfCpZG3ViFtl+svULcgJ7jm(u"ࠪࠤ๊๐ฺศสส๎ฯࠦ࡜࡯ࠢฯีอࠦฬๅสࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠤࡡࡴ่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠡมࠤࠥࠬྦྷ"))
			if qqTR9xfSyG0j43H==JxuTQLOD357o41evylqPmRdf: IwtThn4Mqc7dROV5uUKap = HMm6TqGlgU75axyS(MAs8kRan5hr1xCVqbTLDY4,zXCVN4eIxRJTrUD,showDialogs)
			elif qqTR9xfSyG0j43H==nfC2im3NzUQk: SQdRhwozVfv(AwKhgdpmBj0,XWbHfI9B8swrOL(u"ࠫ࠳ࡢࡴࡏࡱࡷࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡥࡱࡺࡲࡱࡵࡡࡥࡧࡧࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡧࡣࡤࡧࡳࡸࡪࡪࠠࡢࡰࡧࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡦࠪྨ"))
			else: return QigevCplXxbPI1H
			if not IwtThn4Mqc7dROV5uUKap: return QigevCplXxbPI1H
		else: SQdRhwozVfv(AwKhgdpmBj0,OTRKI6LbrQnZEm(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩ࠴ࠠࠡࠢࡉ࡭ࡱ࡫ࠠࡔ࡫ࡽࡩ࠿࡛ࠦࠡࠩྩ")+g1gQfCpZG3ViFtl+g4UCaNkHvLwGhjmW(u"࠭ࠠࡎࡄࠣࡡࠬྪ"))
	return IwtThn4Mqc7dROV5uUKap
def WD6RBoGAHlTQXbpsgiS(PuT0IphGNsketAQ):
	return lE7ZB0CTayhKItApFnYxz
def WfKzkBJuTObrMa1eloxI(ip=QigevCplXxbPI1H):
	p2hIMHSmoTA0WYB7VZr,cQW2wk0yK9LeChBnsoAOuVaF8,tmkUHMEvSjh9uGyJlNKsBPZ48brg2O,olbE0RP437s6MzQnY1jrXuUm8ieHt,ndDkhC0A2YptSOUL,WPqK9tBNb6Vo7hRjZ = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	iCr0xsqwDZXLPaJK1W5YU24F6hp = vZL6j4tSClIGxzNE5DX(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࠴ࡩࡴ࠱ࠪྫ")+ip+XWbHfI9B8swrOL(u"ࠨࡁࡲࡹࡹࡶࡵࡵ࠿࡭ࡷࡴࡴࠦࡧ࡫ࡨࡰࡩࡹ࠽ࡪࡲ࠯ࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠲ࡣࡰࡷࡱࡸࡷࡿࠬࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠲ࡲࡦࡩ࡬ࡳࡳ࠲ࡣࡪࡶࡼ࠰ࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭ྫྷ")
	zXCVN4eIxRJTrUD = {DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ྭ"):QigevCplXxbPI1H}
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,Fg72JX6T5DkPy(u"ࠪࡋࡊ࡚ࠧྮ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,QigevCplXxbPI1H,zXCVN4eIxRJTrUD,QigevCplXxbPI1H,QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧྯ"))
	if not lE7ZB0CTayhKItApFnYxz.succeeded: uZ9qIdr8OtN = ip+mpusoZBJ6V(u"ࠬ࠲ࠧྰ")+p2hIMHSmoTA0WYB7VZr+y5yX4jh6kUEgWZQIc(u"࠭ࠬࠨྱ")+cQW2wk0yK9LeChBnsoAOuVaF8+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧ࠭ࠩྲ")+olbE0RP437s6MzQnY1jrXuUm8ieHt+s0vAWcLSXEToH9Mik134q(u"ࠨ࠮ࠪླ")+ndDkhC0A2YptSOUL+pTwKPmzMSZhil5d2RWonre(u"ࠩ࠯ࠫྴ")+WPqK9tBNb6Vo7hRjZ
	else:
		zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
		zHrPxh0aevGnlKMTdjQsV = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠪࡠࢀ࠴ࠪࡀ࡞ࢀࡠࢂ࠭ྵ"),zHrPxh0aevGnlKMTdjQsV,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if zHrPxh0aevGnlKMTdjQsV:
			zHrPxh0aevGnlKMTdjQsV = zHrPxh0aevGnlKMTdjQsV[h17Zb2ld4yLBrCP5tiw]
			LXCWtYwHc9MnrEDizs25UB0uV = CH86N7xw4cyPt3TlIBJF(Fg72JX6T5DkPy(u"ࠫࡩ࡯ࡣࡵࠩྶ"),zHrPxh0aevGnlKMTdjQsV)
			xdtIoD62Cw0frU9PJLS7YMWlynO = list(LXCWtYwHc9MnrEDizs25UB0uV.keys())
			if Xr2aHOK0huQ5DTS(u"ࠬ࡯ࡰࠨྷ") in xdtIoD62Cw0frU9PJLS7YMWlynO: ip = LXCWtYwHc9MnrEDizs25UB0uV[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡩࡱࠩྸ")]
			if g4UCaNkHvLwGhjmW(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪྐྵ") in xdtIoD62Cw0frU9PJLS7YMWlynO: p2hIMHSmoTA0WYB7VZr = LXCWtYwHc9MnrEDizs25UB0uV[OOhnpQ8XvCVclGqdu(u"ࠨࡥࡲࡲࡹ࡯࡮ࡦࡰࡷࠫྺ")]
			if s0vAWcLSXEToH9Mik134q(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪྻ") in xdtIoD62Cw0frU9PJLS7YMWlynO: cQW2wk0yK9LeChBnsoAOuVaF8 = LXCWtYwHc9MnrEDizs25UB0uV[JJu4MPClbTFpUwHiN(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫྼ")]
			if OOhnpQ8XvCVclGqdu(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ྽") in xdtIoD62Cw0frU9PJLS7YMWlynO: tmkUHMEvSjh9uGyJlNKsBPZ48brg2O = LXCWtYwHc9MnrEDizs25UB0uV[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨࠫ྾")]
			if s0vAWcLSXEToH9Mik134q(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭྿") in xdtIoD62Cw0frU9PJLS7YMWlynO: olbE0RP437s6MzQnY1jrXuUm8ieHt = LXCWtYwHc9MnrEDizs25UB0uV[K7bLVaiRkx0lgU5SQM(u"ࠧࡳࡧࡪ࡭ࡴࡴࠧ࿀")]
			if O4ylJvVNwLztdiHqBWDU(u"ࠨࡥ࡬ࡸࡾ࠭࿁") in xdtIoD62Cw0frU9PJLS7YMWlynO: ndDkhC0A2YptSOUL = LXCWtYwHc9MnrEDizs25UB0uV[pTwKPmzMSZhil5d2RWonre(u"ࠩࡦ࡭ࡹࡿࠧ࿂")]
			if pTwKPmzMSZhil5d2RWonre(u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ࿃") in xdtIoD62Cw0frU9PJLS7YMWlynO:
				WPqK9tBNb6Vo7hRjZ = LXCWtYwHc9MnrEDizs25UB0uV[vZL6j4tSClIGxzNE5DX(u"ࠫࡹ࡯࡭ࡦࡼࡲࡲࡪ࠭࿄")][v54ZuLY6dQ(u"ࠬࡻࡴࡤࠩ࿅")]
				if WPqK9tBNb6Vo7hRjZ[h17Zb2ld4yLBrCP5tiw] not in [vZL6j4tSClIGxzNE5DX(u"࠭࠭ࠨ࿆"),OTRKI6LbrQnZEm(u"ࠧࠬࠩ࿇")]: WPqK9tBNb6Vo7hRjZ = bDt7Ya1VEio3(u"ࠨ࠭ࠪ࿈")+WPqK9tBNb6Vo7hRjZ
			uZ9qIdr8OtN = ip+pGncXOodjKhJzLSqVP1r(u"ࠩ࠯ࠫ࿉")+p2hIMHSmoTA0WYB7VZr+pGncXOodjKhJzLSqVP1r(u"ࠪ࠰ࠬ࿊")+cQW2wk0yK9LeChBnsoAOuVaF8+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫ࠱࠭࿋")+olbE0RP437s6MzQnY1jrXuUm8ieHt+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬ࠲ࠧ࿌")+ndDkhC0A2YptSOUL+Fg72JX6T5DkPy(u"࠭ࠬࠨ࿍")+WPqK9tBNb6Vo7hRjZ
			if b7sJAmSxlBvaMdHFz: uZ9qIdr8OtN = uZ9qIdr8OtN.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL).decode(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ࿎"))
	uZ9qIdr8OtN = arFSQucmG9HxDody67JCI8pBMk4L(uZ9qIdr8OtN)
	return uZ9qIdr8OtN
def RPLdkDS2mf6rvjb8e5yQ1hCu4(R84t36KHbBlX2q):
	TQJLxXf0hCq46cK1dIMS3omOZy,showDialogs = QigevCplXxbPI1H,XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if R84t36KHbBlX2q.count(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡡࠪ࿏"))>=JxuTQLOD357o41evylqPmRdf:
		R84t36KHbBlX2q,TQJLxXf0hCq46cK1dIMS3omOZy = R84t36KHbBlX2q.split(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡢࠫ࿐"),nfC2im3NzUQk)
		TQJLxXf0hCq46cK1dIMS3omOZy = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡣࠬ࿑")+TQJLxXf0hCq46cK1dIMS3omOZy
		if FF70emVxhWOngCty(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ࿒") in TQJLxXf0hCq46cK1dIMS3omOZy: showDialogs = YoAMfqm37GyFxbuKTt6e8CESHrhB
		else: showDialogs = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	return R84t36KHbBlX2q,TQJLxXf0hCq46cK1dIMS3omOZy,showDialogs
def FocL2iGhn9ZfV5sx():
	GfCWvOXloNe6iM0843zJIhqSscF = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,g4UCaNkHvLwGhjmW(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ࿓"))
	eUHmWgkBoKPaCtxYyMNDGwf5vhQb = h17Zb2ld4yLBrCP5tiw
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(GfCWvOXloNe6iM0843zJIhqSscF):
		for bkVfIexwAzsqrS9gj in KiTt9ZskMLjnCAUIJNXD7.listdir(GfCWvOXloNe6iM0843zJIhqSscF):
			if OOhnpQ8XvCVclGqdu(u"࠭࠮ࡱࡻࡲࠫ࿔") in bkVfIexwAzsqrS9gj: continue
			if tg9l25NH6WTacVSifLyAmY(u"ࠧࡠࡡࡳࡽࡨࡧࡣࡩࡧࡢࡣࠬ࿕") in bkVfIexwAzsqrS9gj: continue
			CjJc2Zwn8TRA = KiTt9ZskMLjnCAUIJNXD7.path.join(GfCWvOXloNe6iM0843zJIhqSscF,bkVfIexwAzsqrS9gj)
			h2McBXGu6mEJVQPnZfDS0,S6bnmEiKxr0JUvHMt5pgsjV = dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(CjJc2Zwn8TRA)
			eUHmWgkBoKPaCtxYyMNDGwf5vhQb += h2McBXGu6mEJVQPnZfDS0
	return eUHmWgkBoKPaCtxYyMNDGwf5vhQb
def GGohatHrqeg3cKMJ6AZV(showDialogs):
	yALhM9NCizIfTwx6o20VPEj = uUTRHgAXJzm7pIDBjNt8.getSetting(tg9l25NH6WTacVSifLyAmY(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭࿖"))
	FrjbaoJ4d8n3T1QC9OqWDMYB = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,K7bLVaiRkx0lgU5SQM(u"ࠩࡶࡸࡷ࠭࿗"),O4ylJvVNwLztdiHqBWDU(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭࿘"),K7bLVaiRkx0lgU5SQM(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭࿙"))
	KWuDfYVjP9FyNOhgoH,pZRUOTXvjhfirEmdeH6MoI = yALhM9NCizIfTwx6o20VPEj,FrjbaoJ4d8n3T1QC9OqWDMYB
	ctQ4gTKxbMqDn3W5aOPkYwHfzXh,dBZUAEO7gpTkMjnc58IKl0xY = QigevCplXxbPI1H,QigevCplXxbPI1H
	if nfC2im3NzUQk:
		iCr0xsqwDZXLPaJK1W5YU24F6hp = OQv0iWIw5bFRATU2mxJjZK[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ࿚")][mVjHAyIwzSNKLFcd]
		PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠳࠳ፕ"))
		uZ9qIdr8OtN = WfKzkBJuTObrMa1eloxI()
		cQW2wk0yK9LeChBnsoAOuVaF8 = uZ9qIdr8OtN.split(svULcgJ7jm(u"࠭ࠬࠨ࿛"))[JxuTQLOD357o41evylqPmRdf]
		eUHmWgkBoKPaCtxYyMNDGwf5vhQb = FocL2iGhn9ZfV5sx()
		AlZkSOdj4PzhXQv = {QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡶࡵࡨࡶࠬ࿜"):PXVdZQYTNslvg7wF0159Akr,OTRKI6LbrQnZEm(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ࿝"):GVmdqbtLu8lUXNxp13aHOvkscR,pTwKPmzMSZhil5d2RWonre(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ࿞"):cQW2wk0yK9LeChBnsoAOuVaF8,pGncXOodjKhJzLSqVP1r(u"ࠪ࡭ࡩࡹࠧ࿟"):lY3kWbFJCKMto68f(eUHmWgkBoKPaCtxYyMNDGwf5vhQb)}
		lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡕࡕࡓࡕࠩ࿠"),iCr0xsqwDZXLPaJK1W5YU24F6hp,AlZkSOdj4PzhXQv,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡑࡊ࡙ࡓࡂࡉࡈࡗ࠲࠷ࡳࡵࠩ࿡"))
		if not lE7ZB0CTayhKItApFnYxz.succeeded:
			if yALhM9NCizIfTwx6o20VPEj in [QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"࠭ࡎࡆ࡙ࠪ࿢")]: KWuDfYVjP9FyNOhgoH = XWbHfI9B8swrOL(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭࿣")
			elif yALhM9NCizIfTwx6o20VPEj==XWbHfI9B8swrOL(u"ࠨࡑࡏࡈࠬ࿤"): KWuDfYVjP9FyNOhgoH = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡒࡐࡉࡥࡔࡐࡡࡈࡖࡗࡕࡒࠨ࿥")
		else:
			u5YFqXwGINS8beQyoi9PjhB = lE7ZB0CTayhKItApFnYxz.content
			u5YFqXwGINS8beQyoi9PjhB = CH86N7xw4cyPt3TlIBJF(OOhnpQ8XvCVclGqdu(u"ࠪࡰ࡮ࡹࡴࠨ࿦"),u5YFqXwGINS8beQyoi9PjhB)
			u5YFqXwGINS8beQyoi9PjhB = sorted(u5YFqXwGINS8beQyoi9PjhB,reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,key=lambda key: int(key[h17Zb2ld4yLBrCP5tiw]))
			dBZUAEO7gpTkMjnc58IKl0xY,pZRUOTXvjhfirEmdeH6MoI = QigevCplXxbPI1H,QigevCplXxbPI1H
			for a3SxD96iFlnOMmWg0E,owCdZmtD0aGJsKY4nr8IuVBeMQcAi,LFtkv1dZI6QNUlAq0wX in u5YFqXwGINS8beQyoi9PjhB:
				if a3SxD96iFlnOMmWg0E==FF70emVxhWOngCty(u"ࠫ࠵࠭࿧"):
					dBZUAEO7gpTkMjnc58IKl0xY += LFtkv1dZI6QNUlAq0wX+Xr2aHOK0huQ5DTS(u"ࠬࡀ࠺ࠨ࿨")
					continue
				if pZRUOTXvjhfirEmdeH6MoI: pZRUOTXvjhfirEmdeH6MoI += aSBkt4OU8JpWTEzVIHjAiv+iVCLpNIM8BQs9PdSgKZvlFeo3a5+mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ࿩")+jhAlCQ47ZgG+vZL6j4tSClIGxzNE5DX(u"ࠧ࡝ࡰ࡟ࡲࠬ࿪")
				OCLnYcVUvsTmg5I6adQx7Bk = LFtkv1dZI6QNUlAq0wX.split(aSBkt4OU8JpWTEzVIHjAiv)[h17Zb2ld4yLBrCP5tiw]
				eesC3oVv0zu = tg9l25NH6WTacVSifLyAmY(u"ࠨำึห้ฯࠠฯษุอ๊ࠥใࠡใๅ฻ࠬ࿫") if owCdZmtD0aGJsKY4nr8IuVBeMQcAi else QigevCplXxbPI1H
				pZRUOTXvjhfirEmdeH6MoI += LFtkv1dZI6QNUlAq0wX.replace(OCLnYcVUvsTmg5I6adQx7Bk,r9rhtA5Tek8sIoLfqwF7JcEV+OCLnYcVUvsTmg5I6adQx7Bk+eesC3oVv0zu+jhAlCQ47ZgG)+aSBkt4OU8JpWTEzVIHjAiv
			pZRUOTXvjhfirEmdeH6MoI = aSBkt4OU8JpWTEzVIHjAiv+pZRUOTXvjhfirEmdeH6MoI+O4ylJvVNwLztdiHqBWDU(u"ࠩ࡟ࡲࡡࡴࠧ࿬")
			dBZUAEO7gpTkMjnc58IKl0xY = dBZUAEO7gpTkMjnc58IKl0xY.strip(XWbHfI9B8swrOL(u"ࠪ࠾࠿࠭࿭"))
			ctQ4gTKxbMqDn3W5aOPkYwHfzXh = uUTRHgAXJzm7pIDBjNt8.getSetting(svULcgJ7jm(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧ࿮"))
			if pZRUOTXvjhfirEmdeH6MoI==FrjbaoJ4d8n3T1QC9OqWDMYB and yALhM9NCizIfTwx6o20VPEj in [v54ZuLY6dQ(u"ࠬࡕࡌࡅࠩ࿯"),mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ࿰")]: KWuDfYVjP9FyNOhgoH = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡐࡎࡇࠫ࿱")
			else: KWuDfYVjP9FyNOhgoH = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡐࡈ࡛ࠬ࿲")
			BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,TCF8wLyDvgumfiXPSKRh(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ࿳"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࠬ࿴"),pZRUOTXvjhfirEmdeH6MoI,xfdjCmFwb0k8JAVegiL)
			uUTRHgAXJzm7pIDBjNt8.setSetting(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬ࿵"),lY3kWbFJCKMto68f(qyUPZBiAE3YkuOKrMnTFex92D))
			uUTRHgAXJzm7pIDBjNt8.setSetting(pGncXOodjKhJzLSqVP1r(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ࿶"),dBZUAEO7gpTkMjnc58IKl0xY)
			from hashlib import md5 as o2vzJrWZyOS0Dk73dNpubl
			F7ES9WC5enarsMTjgRO = o2vzJrWZyOS0Dk73dNpubl(tOrSvd8QKNB(u"࠶ፖ")*dBZUAEO7gpTkMjnc58IKl0xY.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()
			F7ES9WC5enarsMTjgRO = o2vzJrWZyOS0Dk73dNpubl(K7bLVaiRkx0lgU5SQM(u"࠳࠷ፗ")*F7ES9WC5enarsMTjgRO.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()
			F7ES9WC5enarsMTjgRO = o2vzJrWZyOS0Dk73dNpubl(XWbHfI9B8swrOL(u"࠴࠽ፘ")*F7ES9WC5enarsMTjgRO.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()
			uUTRHgAXJzm7pIDBjNt8.setSetting(FF70emVxhWOngCty(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠳ࠩ࿷"),F7ES9WC5enarsMTjgRO)
	if showDialogs:
		if KWuDfYVjP9FyNOhgoH in [pGncXOodjKhJzLSqVP1r(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭࿸"),y5yX4jh6kUEgWZQIc(u"ࠨࡐࡈ࡛ࡤ࡚ࡏࡠࡇࡕࡖࡔࡘࠧ࿹")]:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࿺"),vZL6j4tSClIGxzNE5DX(u"๋๋ࠪอใࠡ็ื็้ฯࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࠦไ๋ีอࠤ๊์ࠠศๆหี๋อๅอࠢ࠱࠲ࠥํะ่ࠢสฺ่๊ใๅหࠣๆิ๊ࠦไ๊้ࠤุฮศ่ษࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠฤ๊ࠣห้ืว้ฬิࠤฬ๊ฮศืࠣฬ่ࠦรุ้่่๊ࠢษࠡใํࠤฬ๊ริๆส็ࠥ฿ๆะๅࠪ࿻"))
		else:
			XRZyfuiD8nLlKYPJ(FF70emVxhWOngCty(u"ࠫࡷ࡯ࡧࡩࡶࠪ࿼"),tOrSvd8QKNB(u"ࠬืำศศ็ࠤ๊์ࠠศๆ่ฬึ๋ฬࠡว็ํ๋ࠥำหะา้๏ࠦวๅสิ๊ฬ๋ฬࠨ࿽"),pZRUOTXvjhfirEmdeH6MoI,tOrSvd8QKNB(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ࿾"))
			KWuDfYVjP9FyNOhgoH = Fg72JX6T5DkPy(u"ࠧࡐࡎࡇࠫ࿿")
	if KWuDfYVjP9FyNOhgoH!=yALhM9NCizIfTwx6o20VPEj:
		uUTRHgAXJzm7pIDBjNt8.setSetting(XWbHfI9B8swrOL(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭က"),KWuDfYVjP9FyNOhgoH)
		ksV5ngvbcaS8ByMLYxlfXh(svULcgJ7jm(u"ࡉࡥࡱࡹࡥᎳ"))
	arn6PsyHZOq4bX18 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if dBZUAEO7gpTkMjnc58IKl0xY!=ctQ4gTKxbMqDn3W5aOPkYwHfzXh else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if arn6PsyHZOq4bX18:
		X69Fkr1VNnf2pJQC8wl7YR4HmaKc(bDt7Ya1VEio3(u"้ࠩะาะฺࠠ็็๎ฮࠦสฮัํฯࠥอไึๆสั๏อสࠨခ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡗࡺࡩࡣࡦࡵࡶࠫဂ"),B3TKLo71hAGRqYgV0=O4ylJvVNwLztdiHqBWDU(u"࠻࠺࠶ፙ"))
		ksV5ngvbcaS8ByMLYxlfXh(K7bLVaiRkx0lgU5SQM(u"ࡊࡦࡲࡳࡦᎴ"))
	return arn6PsyHZOq4bX18
def s6smWAehjkQv9nbw2JgSr(yZTHwRpAJvK0hSaN,WJTvd2IYiz5S):
	from socket import socket as LXYK9GkF5MnA,AF_INET as wLNAcp1EzHoU5q7t9hfTKGli0IOS,SOCK_STREAM as SYgdGcXQU74TrsHwfWz
	Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM = LXYK9GkF5MnA(wLNAcp1EzHoU5q7t9hfTKGli0IOS,SYgdGcXQU74TrsHwfWz)
	Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM.settimeout(nfC2im3NzUQk)
	nPjzT9ZKLxm40kNytH2WsQEI,tIE1b5qCAX8JsorLwxjW0ZQKO9yV = XpREPf7d08GnIS6i4KNLMyZHmuQqxD,h17Zb2ld4yLBrCP5tiw
	T9Ax7pUEP6Ilg4cC = B3TKLo71hAGRqYgV0.time()
	try: Nu5lIpUxKokRQfiV0bTAcOYEB8XhwM.connect((yZTHwRpAJvK0hSaN,WJTvd2IYiz5S))
	except: nPjzT9ZKLxm40kNytH2WsQEI = YoAMfqm37GyFxbuKTt6e8CESHrhB
	GSiF9DxgB2 = B3TKLo71hAGRqYgV0.time()
	if nPjzT9ZKLxm40kNytH2WsQEI: tIE1b5qCAX8JsorLwxjW0ZQKO9yV = GSiF9DxgB2-T9Ax7pUEP6Ilg4cC
	return tIE1b5qCAX8JsorLwxjW0ZQKO9yV
def MfFlidaIObTrEBK08eg(showDialogs):
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧဃ"),K7bLVaiRkx0lgU5SQM(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫင"))
	else: nndcv6tehuoKPpI = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if nndcv6tehuoKPpI==nfC2im3NzUQk:
		for bkVfIexwAzsqrS9gj in KiTt9ZskMLjnCAUIJNXD7.listdir(nZ5AkguavpEc7zWo8SOHRD):
			if bkVfIexwAzsqrS9gj.endswith(XWbHfI9B8swrOL(u"࠭࠮ࡥࡤࠪစ")) and DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡥࡣࡷࡥࠬဆ") in bkVfIexwAzsqrS9gj:
				aYXiUPQDVd7hjTsumgL = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,bkVfIexwAzsqrS9gj)
				try: R2wuKSVBTLW4sAOQNob18UEdGf0hv,B6xRu5lFyJ = gomHdCqRMikpnujeWJ2XSZL(aYXiUPQDVd7hjTsumgL)
				except: return
				B6xRu5lFyJ.execute(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡫ࡱࡸࡪ࡭ࡲࡪࡶࡼࡣࡨ࡮ࡥࡤ࡭࠾ࠫဇ"))
				B6xRu5lFyJ.execute(vZL6j4tSClIGxzNE5DX(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡲࡴࡹ࡯࡭ࡪࡼࡨ࠿ࠬဈ"))
				B6xRu5lFyJ.execute(O4ylJvVNwLztdiHqBWDU(u"࡚ࠪࡆࡉࡕࡖࡏ࠾ࠫဉ"))
				R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
				R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
		if showDialogs:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧည"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬะๅหࠢห๊ัออࠡ฻่่๏ฯࠠฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ั࠭ဋ"))
	return
def Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(qcKxumtY6FilI0Ld3rGV8zyvXf,U8mq1iIJz9,showDialogs):
	if qcKxumtY6FilI0Ld3rGV8zyvXf!=None:
		global FxVULPsJoWi2bQptMKDeyaY130Xn
		FxVULPsJoWi2bQptMKDeyaY130Xn = qcKxumtY6FilI0Ld3rGV8zyvXf
	if U8mq1iIJz9!=None:
		global dpgSUtsyb1cMoGVB
		dpgSUtsyb1cMoGVB = U8mq1iIJz9
	if showDialogs!=None:
		global RBdKiO2qYUfF17WmG3ClecIzbJtXDN
		RBdKiO2qYUfF17WmG3ClecIzbJtXDN = showDialogs
	return
FxVULPsJoWi2bQptMKDeyaY130Xn,dpgSUtsyb1cMoGVB,RBdKiO2qYUfF17WmG3ClecIzbJtXDN = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
def OoLhgXxKtYRvIb3Sc2TeJCW(vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,data,headers,allow_redirects,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2,L7hdwV2QJmK8CtWEkGRanu):
	if showDialogs==QigevCplXxbPI1H: xoAmWTH8vprhc = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if RBdKiO2qYUfF17WmG3ClecIzbJtXDN==QigevCplXxbPI1H else RBdKiO2qYUfF17WmG3ClecIzbJtXDN
	else: xoAmWTH8vprhc = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if showDialogs else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if L7hdwV2QJmK8CtWEkGRanu==QigevCplXxbPI1H: DBw0bSH2GWziLoMlmac1Tf59 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if dpgSUtsyb1cMoGVB==QigevCplXxbPI1H else dpgSUtsyb1cMoGVB
	else: DBw0bSH2GWziLoMlmac1Tf59 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if L7hdwV2QJmK8CtWEkGRanu else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if vw1Fb37ptGlaEVdDy2==QigevCplXxbPI1H: EEhZybv0NfRuH = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if FxVULPsJoWi2bQptMKDeyaY130Xn==QigevCplXxbPI1H else FxVULPsJoWi2bQptMKDeyaY130Xn
	else: EEhZybv0NfRuH = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if vw1Fb37ptGlaEVdDy2 else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if allow_redirects==QigevCplXxbPI1H: YbgdiQeolJWPRr0F = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	else: YbgdiQeolJWPRr0F = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if allow_redirects else YoAMfqm37GyFxbuKTt6e8CESHrhB
	T24Te3uDwBS5vLgUEAhF1O = {} if headers==QigevCplXxbPI1H else headers
	tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = {} if data==QigevCplXxbPI1H else data
	nxzNm6DVfGrd7Myalq1XPiOHu02 = list(T24Te3uDwBS5vLgUEAhF1O.keys())
	if bDt7Ya1VEio3(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧဌ") not in nxzNm6DVfGrd7Myalq1XPiOHu02: T24Te3uDwBS5vLgUEAhF1O[K7bLVaiRkx0lgU5SQM(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨဍ")] = y5yX4jh6kUEgWZQIc(u"ࠨࡪࡷࡸࡵ࠭ဎ")
	if K7bLVaiRkx0lgU5SQM(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ဏ") not in nxzNm6DVfGrd7Myalq1XPiOHu02: T24Te3uDwBS5vLgUEAhF1O[svULcgJ7jm(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧတ")] = eUBL1rOR4ZfndJAWPsoN6pybT0(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	return vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,EEhZybv0NfRuH,DBw0bSH2GWziLoMlmac1Tf59
def ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2=QigevCplXxbPI1H,L7hdwV2QJmK8CtWEkGRanu=QigevCplXxbPI1H):
	gg6KCcWVSQTO85LDf = OoLhgXxKtYRvIb3Sc2TeJCW(vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2,L7hdwV2QJmK8CtWEkGRanu)
	vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,EEhZybv0NfRuH,DBw0bSH2GWziLoMlmac1Tf59 = gg6KCcWVSQTO85LDf
	Kj0TOU6BmSMlJHZYLd,xUW6Rh7CXS,K6STmZrVO8bqYxz7IgjPh,owqUkQjRIrH7puTyOG = bnETX3l26rzAve7p0ci(iCr0xsqwDZXLPaJK1W5YU24F6hp)
	aamzjlvJfDIsVxrOYLgnXMo49kN2Z = uUTRHgAXJzm7pIDBjNt8.getSetting(XWbHfI9B8swrOL(u"ࠫࡦࡼ࠮ࡥࡰࡶࠫထ"))
	qqPWDhZlp2zOJ1xAmKXjne = uUTRHgAXJzm7pIDBjNt8.getSetting(JJu4MPClbTFpUwHiN(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨဒ"))
	Zb0GKOIxPgts18Y6FlSouCV2QEhR = uUTRHgAXJzm7pIDBjNt8.getSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫဓ"))
	LrAeZcIyR9duQTob1 = [fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪန"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬပ"),tOrSvd8QKNB(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠧဖ"),JJu4MPClbTFpUwHiN(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶࠪဗ"),pGncXOodjKhJzLSqVP1r(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭ဘ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯ࠨမ")]
	nxGRV5rKuDzvdNthMa4f = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if any(nFdGHjceZzW in iCr0xsqwDZXLPaJK1W5YU24F6hp for nFdGHjceZzW in LrAeZcIyR9duQTob1) else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if v54ZuLY6dQ(u"࠭ࠦࡶࡴ࡯ࡁࠬယ") in Kj0TOU6BmSMlJHZYLd and nxGRV5rKuDzvdNthMa4f: Fxt7KiXZ5jIvCU1PYk2fr = Kj0TOU6BmSMlJHZYLd.rsplit(XWbHfI9B8swrOL(u"ࠧࠧࡷࡵࡰࡂ࠭ရ"),DDHwpETQrAm0xMNXGfyhqsUi(u"࠶ፚ"))[nfC2im3NzUQk]
	else: Fxt7KiXZ5jIvCU1PYk2fr = QigevCplXxbPI1H
	hnIsrXbK7ilv1ZQG = OQv0iWIw5bFRATU2mxJjZK[tg9l25NH6WTacVSifLyAmY(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨလ")]
	RRVfz54vOShLuio = Kj0TOU6BmSMlJHZYLd in hnIsrXbK7ilv1ZQG or Fxt7KiXZ5jIvCU1PYk2fr in hnIsrXbK7ilv1ZQG
	sFS59xQb3vz1cMwYfU8oukTgGqDaC = OQv0iWIw5bFRATU2mxJjZK[OTRKI6LbrQnZEm(u"ࠩࡕࡉࡕࡕࡓࠨဝ")]
	zvl0RIeL7uBQV49brj3OkcKgwUnf = Kj0TOU6BmSMlJHZYLd in sFS59xQb3vz1cMwYfU8oukTgGqDaC or Fxt7KiXZ5jIvCU1PYk2fr in sFS59xQb3vz1cMwYfU8oukTgGqDaC
	DiTz8KGU6j = RRVfz54vOShLuio or zvl0RIeL7uBQV49brj3OkcKgwUnf
	kwxdOg3zPMHvYZ2tDGhTlIFNm = YoAMfqm37GyFxbuKTt6e8CESHrhB
	wJoY30TfNUk7GzbdIL = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	TQfykK63DroxZY74N = xUW6Rh7CXS==None and K6STmZrVO8bqYxz7IgjPh==None and not nxGRV5rKuDzvdNthMa4f
	if TQfykK63DroxZY74N and DiTz8KGU6j:
		if RRVfz54vOShLuio:
			sIqcCieT2DAxPRtWaH968 = hnIsrXbK7ilv1ZQG.index(Kj0TOU6BmSMlJHZYLd)
			RtgDZhJyA136QOfUxTprok7Cdl = OQv0iWIw5bFRATU2mxJjZK[aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧသ")][sIqcCieT2DAxPRtWaH968]
			v3lzXQkLZTStAp = CCT0MdYxkDalqAE[sIqcCieT2DAxPRtWaH968]
			if v3lzXQkLZTStAp==DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭ဟ"): EEhZybv0NfRuH,DBw0bSH2GWziLoMlmac1Tf59,wJoY30TfNUk7GzbdIL = YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB
			elif v3lzXQkLZTStAp==tOrSvd8QKNB(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭ဠ"): kwxdOg3zPMHvYZ2tDGhTlIFNm = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		elif zvl0RIeL7uBQV49brj3OkcKgwUnf:
			sIqcCieT2DAxPRtWaH968 = sFS59xQb3vz1cMwYfU8oukTgGqDaC.index(Kj0TOU6BmSMlJHZYLd)
			RtgDZhJyA136QOfUxTprok7Cdl = OQv0iWIw5bFRATU2mxJjZK[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩအ")][sIqcCieT2DAxPRtWaH968]
			v3lzXQkLZTStAp = BBCVh2mFqLjNZ5p6tfA1JPeS[sIqcCieT2DAxPRtWaH968]
	if K6STmZrVO8bqYxz7IgjPh==QigevCplXxbPI1H: K6STmZrVO8bqYxz7IgjPh = aamzjlvJfDIsVxrOYLgnXMo49kN2Z
	elif K6STmZrVO8bqYxz7IgjPh==None and qqPWDhZlp2zOJ1xAmKXjne in [Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡂࡗࡗࡓࠬဢ"),OTRKI6LbrQnZEm(u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪဣ")] and EEhZybv0NfRuH: K6STmZrVO8bqYxz7IgjPh = aamzjlvJfDIsVxrOYLgnXMo49kN2Z
	if RRVfz54vOShLuio or zvl0RIeL7uBQV49brj3OkcKgwUnf: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = aqUlAdFto05NmG4Y6guEzTr8vK(u"࠷࠵፛")
	elif nxGRV5rKuDzvdNthMa4f: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = mmKqLr9RX0ACN384JMcsFHzd(u"࠶࠱፜")
	elif m9TrBXjhwRgI in bbaZdrlivfI6: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = JJu4MPClbTFpUwHiN(u"࠲࠲፝")
	elif m9TrBXjhwRgI==g4UCaNkHvLwGhjmW(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊ࡜ࡅࡓࡕࡒࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫဤ"): XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = mmKqLr9RX0ACN384JMcsFHzd(u"࠴࠳፞")
	elif m9TrBXjhwRgI==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫဥ"): XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠵࠴፟")
	elif tg9l25NH6WTacVSifLyAmY(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠭ဦ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = svULcgJ7jm(u"࠻࠵፠")
	elif s0vAWcLSXEToH9Mik134q(u"࡙ࠬࡈࡐࡈࡋࡅࠬဧ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠼࠻፡")
	elif DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ࡃࡊࡏࡄ࠸࡚࠭ဨ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠸࠵።")
	elif fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡂࡊ࡚ࡅࡐ࠭ဩ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = pTwKPmzMSZhil5d2RWonre(u"࠲࠱፣")
	elif pTwKPmzMSZhil5d2RWonre(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫဪ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = svULcgJ7jm(u"࠳࠲፤")
	elif WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋࠨါ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = vZL6j4tSClIGxzNE5DX(u"࠵࠳፥")
	elif tg9l25NH6WTacVSifLyAmY(u"ࠪࡅࡐࡕࡁࡎࠩာ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠵࠹፦")
	elif DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡆࡑࡗࡂࡏࠪိ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠷࠵፧")
	elif y5yX4jh6kUEgWZQIc(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧီ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = y5yX4jh6kUEgWZQIc(u"࠷࠶፨")
	elif tOrSvd8QKNB(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨု") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = pTwKPmzMSZhil5d2RWonre(u"࠼࠰፩")
	elif mpusoZBJ6V(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩူ") in m9TrBXjhwRgI: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = v54ZuLY6dQ(u"࠴࠱፪")
	else: XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = O4ylJvVNwLztdiHqBWDU(u"࠲࠷፫")
	JdbTpoqEvhImzU = (xUW6Rh7CXS!=None)
	erYNbk2g9QfqLIP1XodvGs5Wup = (K6STmZrVO8bqYxz7IgjPh!=None and qqPWDhZlp2zOJ1xAmKXjne!=XWbHfI9B8swrOL(u"ࠨࡕࡗࡓࡕ࠭ေ"))
	if JdbTpoqEvhImzU and not nxGRV5rKuDzvdNthMa4f: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩอๅ฾๐ไࠡสิ์ู่๊ࠡำๅ้ࠬဲ"),xUW6Rh7CXS)
	elif erYNbk2g9QfqLIP1XodvGs5Wup: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(mmKqLr9RX0ACN384JMcsFHzd(u"ࠪฮๆ฿๊ๅࠢࡇࡒࡘࠦัใ็ࠪဳ"),K6STmZrVO8bqYxz7IgjPh)
	if JdbTpoqEvhImzU:
		mPJ5ulvnZQzNs = {fk8jc5uDLX16qrih3ZaPxsvO(u"ࠦ࡭ࡺࡴࡱࠤဴ"):xUW6Rh7CXS,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧ࡮ࡴࡵࡲࡶࠦဵ"):xUW6Rh7CXS}
		mQ09SwA5jMcvb3CEu = xUW6Rh7CXS
	else: mPJ5ulvnZQzNs,mQ09SwA5jMcvb3CEu = {},QigevCplXxbPI1H
	if erYNbk2g9QfqLIP1XodvGs5Wup:
		import urllib3.util.connection as N2CrvQs8jFGW5Z7E
		C2bMXu86VGNF04OEZ = EcMoKBLhr0ZfdJP(N2CrvQs8jFGW5Z7E,aamzjlvJfDIsVxrOYLgnXMo49kN2Z)
	ZhI7eoNjbcfz9iL,vmU4abqgc5ndeKHfCw7ETlXRNy,x1NOSq6wIZU9hnJuyfPgY0Q3G2,ZExWmkgovJuK4La0YTIH9M7epXUl6n,BDyYbWxlmRHJ903Nn6PEvQ,verify = YbgdiQeolJWPRr0F,m9TrBXjhwRgI,vBA4PehsH7aOQGDZi9zj2,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB,owqUkQjRIrH7puTyOG
	if kwxdOg3zPMHvYZ2tDGhTlIFNm: BDyYbWxlmRHJ903Nn6PEvQ = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if DiTz8KGU6j or YbgdiQeolJWPRr0F: ZhI7eoNjbcfz9iL = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if RRVfz54vOShLuio: x1NOSq6wIZU9hnJuyfPgY0Q3G2 = O4ylJvVNwLztdiHqBWDU(u"࠭ࡐࡐࡕࡗࠫံ")
	kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp = -nfC2im3NzUQk,s0vAWcLSXEToH9Mik134q(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡇࡵࡶࡴࡸ့ࠧ")
	import requests as rBU6o8SmdykhQ
	for GzabfJx3T1 in range(O4ylJvVNwLztdiHqBWDU(u"࠻፬")):
		BvG3RL7yr0k4ANpY = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
		try:
			if GzabfJx3T1: vmU4abqgc5ndeKHfCw7ETlXRNy = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠷ࡳࡵࠩး")
			if nxGRV5rKuDzvdNthMa4f or not JdbTpoqEvhImzU: OOIHQRsiD2(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒ္ࠧ"),Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,vmU4abqgc5ndeKHfCw7ETlXRNy,x1NOSq6wIZU9hnJuyfPgY0Q3G2)
			try: lE7ZB0CTayhKItApFnYxz.close()
			except: pass
			NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd
			lE7ZB0CTayhKItApFnYxz = rBU6o8SmdykhQ.request(x1NOSq6wIZU9hnJuyfPgY0Q3G2,Kj0TOU6BmSMlJHZYLd,data=tNQDMKVydhBqgaUvJ7oeAkTHxsL1,headers=T24Te3uDwBS5vLgUEAhF1O,verify=verify,allow_redirects=ZhI7eoNjbcfz9iL,timeout=XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc,proxies=mPJ5ulvnZQzNs)
			if TCF8wLyDvgumfiXPSKRh(u"࠶࠴࠵፭")<=lE7ZB0CTayhKItApFnYxz.status_code<=v54ZuLY6dQ(u"࠷࠾࠿፮"):
				if not ZExWmkgovJuK4La0YTIH9M7epXUl6n:
					hBWSlDZPbTm0ygNnR = list(lE7ZB0CTayhKItApFnYxz.headers.keys())
					if y5yX4jh6kUEgWZQIc(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲ်ࠬ") in hBWSlDZPbTm0ygNnR: Kj0TOU6BmSMlJHZYLd = lE7ZB0CTayhKItApFnYxz.headers[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ျ")]
					elif OOhnpQ8XvCVclGqdu(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧြ") in hBWSlDZPbTm0ygNnR: Kj0TOU6BmSMlJHZYLd = lE7ZB0CTayhKItApFnYxz.headers[svULcgJ7jm(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨွ")]
					else: ZExWmkgovJuK4La0YTIH9M7epXUl6n = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
					if not ZExWmkgovJuK4La0YTIH9M7epXUl6n: Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.encode(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧ࡭ࡣࡷ࡭ࡳ࠳࠱ࠨှ"),K7bLVaiRkx0lgU5SQM(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨဿ")).decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,O4ylJvVNwLztdiHqBWDU(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ၀"))
					if DiTz8KGU6j and lE7ZB0CTayhKItApFnYxz.status_code==mmKqLr9RX0ACN384JMcsFHzd(u"࠸࠶࠷፯"):
						ZhI7eoNjbcfz9iL = YbgdiQeolJWPRr0F
						x1NOSq6wIZU9hnJuyfPgY0Q3G2 = vBA4PehsH7aOQGDZi9zj2
						ZExWmkgovJuK4La0YTIH9M7epXUl6n = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
						tHNbul2BwKCP0aT8Ivzcqp
				if not ZExWmkgovJuK4La0YTIH9M7epXUl6n or YbgdiQeolJWPRr0F:
					if FF70emVxhWOngCty(u"ࠪ࡬ࡹࡺࡰࠨ၁") not in Kj0TOU6BmSMlJHZYLd:
						bsPadQfAGhzXtZWjR = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡺࡸ࡬ࠨ၂"))
						Kj0TOU6BmSMlJHZYLd = bsPadQfAGhzXtZWjR+mpusoZBJ6V(u"ࠬ࠵ࠧ၃")+Kj0TOU6BmSMlJHZYLd.lstrip(Xr2aHOK0huQ5DTS(u"࠭࠯ࠨ၄"))
				if not ZExWmkgovJuK4La0YTIH9M7epXUl6n and YbgdiQeolJWPRr0F and not z2dZ1anR6O(Kj0TOU6BmSMlJHZYLd): w8wxBgzImjZN2p
			elif OOhnpQ8XvCVclGqdu(u"࠵࠶࠲፱")<=lE7ZB0CTayhKItApFnYxz.status_code<=v54ZuLY6dQ(u"࠻࠹࠺፰"):
				lE7ZB0CTayhKItApFnYxz.reason = lE7ZB0CTayhKItApFnYxz.content
				BDyYbWxlmRHJ903Nn6PEvQ = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = lE7ZB0CTayhKItApFnYxz.url
			kQKmN8hHvzcC6PWtbJqr4aL9 = lE7ZB0CTayhKItApFnYxz.status_code
			C4RUnz8IDZ15uXOqG96F2kSTNiygp = lE7ZB0CTayhKItApFnYxz.reason
			lE7ZB0CTayhKItApFnYxz.raise_for_status()
			AMu7aiqvPT6WcLOXDSkhFzdN = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		except rBU6o8SmdykhQ.exceptions.HTTPError as HqIej1PzSpAEWZ8Y7buc:
			pass
		except rBU6o8SmdykhQ.exceptions.Timeout as HqIej1PzSpAEWZ8Y7buc:
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: C4RUnz8IDZ15uXOqG96F2kSTNiygp = str(HqIej1PzSpAEWZ8Y7buc.message).split(Xr2aHOK0huQ5DTS(u"ࠧ࠻ࠢࠪ၅"))[nfC2im3NzUQk]
			else: C4RUnz8IDZ15uXOqG96F2kSTNiygp = str(HqIej1PzSpAEWZ8Y7buc).split(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨ࠼ࠣࠫ၆"))[nfC2im3NzUQk]
		except rBU6o8SmdykhQ.exceptions.ConnectionError as HqIej1PzSpAEWZ8Y7buc:
			try: f5fDJrRQGbEtTp07zHBKCua2 = HqIej1PzSpAEWZ8Y7buc.message[h17Zb2ld4yLBrCP5tiw]
			except: f5fDJrRQGbEtTp07zHBKCua2 = str(HqIej1PzSpAEWZ8Y7buc)
			GGfJsel3Pjz0uEbK7aow5i4VqY = sBvufaD6c9YHdOqTjCQ3.findall(mpusoZBJ6V(u"ࠤ࡟࡟ࡊࡸࡲ࡯ࡱࠣࠬࡡࡪࠫࠪ࡞ࡠࠤ࠭࠴ࠪࡀࠫࠪࠦ၇"),f5fDJrRQGbEtTp07zHBKCua2)
			if not GGfJsel3Pjz0uEbK7aow5i4VqY: GGfJsel3Pjz0uEbK7aow5i4VqY = sBvufaD6c9YHdOqTjCQ3.findall(mmKqLr9RX0ACN384JMcsFHzd(u"ࠥ࠰ࠥ࡫ࡲࡳࡱࡵࡠ࠭࠮࡜ࡥ࠭ࠬ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ၈"),f5fDJrRQGbEtTp07zHBKCua2)
			if not GGfJsel3Pjz0uEbK7aow5i4VqY:
				DiBMwTqvyLn7r4hVbp6e5 = sBvufaD6c9YHdOqTjCQ3.findall(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠦ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯࠺ࠣ၉"),f5fDJrRQGbEtTp07zHBKCua2)
				if DiBMwTqvyLn7r4hVbp6e5: GGfJsel3Pjz0uEbK7aow5i4VqY = [DiBMwTqvyLn7r4hVbp6e5[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk],DiBMwTqvyLn7r4hVbp6e5[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw]]
			if not GGfJsel3Pjz0uEbK7aow5i4VqY: GGfJsel3Pjz0uEbK7aow5i4VqY = sBvufaD6c9YHdOqTjCQ3.findall(XWbHfI9B8swrOL(u"ࠧࡀࠨ࡝ࡦ࠮࠭࠿ࠦࠨ࠯ࠬࡂ࠭ࠬࠨ၊"),f5fDJrRQGbEtTp07zHBKCua2)
			if not GGfJsel3Pjz0uEbK7aow5i4VqY: GGfJsel3Pjz0uEbK7aow5i4VqY = sBvufaD6c9YHdOqTjCQ3.findall(K7bLVaiRkx0lgU5SQM(u"ࠨࠠࠩ࡞ࡧ࠯࠮ࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢ။"),f5fDJrRQGbEtTp07zHBKCua2)
			try: kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp = GGfJsel3Pjz0uEbK7aow5i4VqY[h17Zb2ld4yLBrCP5tiw]
			except: kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp = -JJu4MPClbTFpUwHiN(u"࠳፲"),f5fDJrRQGbEtTp07zHBKCua2
		except rBU6o8SmdykhQ.exceptions.RequestException as HqIej1PzSpAEWZ8Y7buc:
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: C4RUnz8IDZ15uXOqG96F2kSTNiygp = HqIej1PzSpAEWZ8Y7buc.message
			else: C4RUnz8IDZ15uXOqG96F2kSTNiygp = str(HqIej1PzSpAEWZ8Y7buc)
		except:
			BvG3RL7yr0k4ANpY = YoAMfqm37GyFxbuKTt6e8CESHrhB
			try: kQKmN8hHvzcC6PWtbJqr4aL9 = lE7ZB0CTayhKItApFnYxz.status_code
			except: pass
			try: C4RUnz8IDZ15uXOqG96F2kSTNiygp = lE7ZB0CTayhKItApFnYxz.reason
			except: pass
		C4RUnz8IDZ15uXOqG96F2kSTNiygp = str(C4RUnz8IDZ15uXOqG96F2kSTNiygp)
		SQdRhwozVfv(AwKhgdpmBj0,Xr2aHOK0huQ5DTS(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࡟ࡸࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ၌")+str(kQKmN8hHvzcC6PWtbJqr4aL9)+Xr2aHOK0huQ5DTS(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ၍")+C4RUnz8IDZ15uXOqG96F2kSTNiygp+tg9l25NH6WTacVSifLyAmY(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ၎")+m9TrBXjhwRgI+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ၏")+iCr0xsqwDZXLPaJK1W5YU24F6hp+y5yX4jh6kUEgWZQIc(u"ࠫࠥࡣࠧၐ"))
		if TQfykK63DroxZY74N and DiTz8KGU6j and BvG3RL7yr0k4ANpY and not BDyYbWxlmRHJ903Nn6PEvQ and kQKmN8hHvzcC6PWtbJqr4aL9!=Xr2aHOK0huQ5DTS(u"࠴࠳࠴፳"):
			Kj0TOU6BmSMlJHZYLd = RtgDZhJyA136QOfUxTprok7Cdl
			BDyYbWxlmRHJ903Nn6PEvQ = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			continue
		if BvG3RL7yr0k4ANpY: break
	if K6STmZrVO8bqYxz7IgjPh!=None and qqPWDhZlp2zOJ1xAmKXjne!=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࡙ࠬࡔࡐࡒࠪၑ"): N2CrvQs8jFGW5Z7E.create_connection = C2bMXu86VGNF04OEZ
	if qqPWDhZlp2zOJ1xAmKXjne==tg9l25NH6WTacVSifLyAmY(u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭ၒ") and EEhZybv0NfRuH: K6STmZrVO8bqYxz7IgjPh = None
	if not AMu7aiqvPT6WcLOXDSkhFzdN and xUW6Rh7CXS==None and m9TrBXjhwRgI not in bbaZdrlivfI6:
		THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
		if THFfWLwt62MmUz!=Fg72JX6T5DkPy(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪၓ"): KXhrv29CGR8QTDzJIWLY.stderr.write(THFfWLwt62MmUz)
	FoZ6n1al9wLqprS = aTqvbmueLIYkRjSODlK8BCW()
	if nxGRV5rKuDzvdNthMa4f: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Fxt7KiXZ5jIvCU1PYk2fr
	FoZ6n1al9wLqprS.url = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx
	FoZ6n1al9wLqprS.scrape = nxGRV5rKuDzvdNthMa4f
	try: MuQ7bAnf2z9v = lE7ZB0CTayhKItApFnYxz.content
	except: MuQ7bAnf2z9v = QigevCplXxbPI1H
	try: IBsPJlUbjVW = lE7ZB0CTayhKItApFnYxz.headers
	except: IBsPJlUbjVW = {}
	try: r5ZlLpMIfh4tW = lE7ZB0CTayhKItApFnYxz.cookies.get_dict()
	except: r5ZlLpMIfh4tW = {}
	try: lE7ZB0CTayhKItApFnYxz.close()
	except: pass
	if b7sJAmSxlBvaMdHFz:
		try: MuQ7bAnf2z9v = MuQ7bAnf2z9v.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		except: pass
	kQKmN8hHvzcC6PWtbJqr4aL9 = int(kQKmN8hHvzcC6PWtbJqr4aL9)
	FoZ6n1al9wLqprS.code = kQKmN8hHvzcC6PWtbJqr4aL9
	FoZ6n1al9wLqprS.reason = C4RUnz8IDZ15uXOqG96F2kSTNiygp
	FoZ6n1al9wLqprS.content = MuQ7bAnf2z9v
	FoZ6n1al9wLqprS.headers = IBsPJlUbjVW
	FoZ6n1al9wLqprS.cookies = r5ZlLpMIfh4tW
	FoZ6n1al9wLqprS.succeeded = AMu7aiqvPT6WcLOXDSkhFzdN
	FoZ6n1al9wLqprS.scrapernumber = QigevCplXxbPI1H
	FoZ6n1al9wLqprS.scraperserver = QigevCplXxbPI1H
	FoZ6n1al9wLqprS.scraperurl = QigevCplXxbPI1H
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG or isinstance(FoZ6n1al9wLqprS.content,str): GvNVH0jL19al4fw5XY2KCtER = FoZ6n1al9wLqprS.content.lower()
	else: GvNVH0jL19al4fw5XY2KCtER = QigevCplXxbPI1H
	Zn2yQOf6lWMt9pUeuvcCR51JNIwiB = (mpusoZBJ6V(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬၔ") in GvNVH0jL19al4fw5XY2KCtER or vZL6j4tSClIGxzNE5DX(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩၕ") in GvNVH0jL19al4fw5XY2KCtER) and GvNVH0jL19al4fw5XY2KCtER.count(tg9l25NH6WTacVSifLyAmY(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ၖ"))>O4ylJvVNwLztdiHqBWDU(u"࠵፴") and Xr2aHOK0huQ5DTS(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ၗ") not in m9TrBXjhwRgI and DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴࠧၘ") not in GvNVH0jL19al4fw5XY2KCtER and not nxGRV5rKuDzvdNthMa4f
	if kQKmN8hHvzcC6PWtbJqr4aL9==tg9l25NH6WTacVSifLyAmY(u"࠶࠵࠶፵") and Zn2yQOf6lWMt9pUeuvcCR51JNIwiB: FoZ6n1al9wLqprS.succeeded = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if FoZ6n1al9wLqprS.succeeded and TQfykK63DroxZY74N and DiTz8KGU6j:
		OquV5KJCsw2kQ = pTwKPmzMSZhil5d2RWonre(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧၙ")+tNQDMKVydhBqgaUvJ7oeAkTHxsL1[TCF8wLyDvgumfiXPSKRh(u"ࠧ࡫ࡱࡥࠫၚ")].upper().replace(y5yX4jh6kUEgWZQIc(u"ࠨࡉࡈࡘࠬၛ"),QigevCplXxbPI1H) if kwxdOg3zPMHvYZ2tDGhTlIFNm else v3lzXQkLZTStAp
		xwq7peVj8AJy = HNLnAOlivm(OquV5KJCsw2kQ)
	if not FoZ6n1al9wLqprS.succeeded and TQfykK63DroxZY74N:
		K0ycsNJSEtzfUiAM8Bg92YblId = (mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ၜ") in GvNVH0jL19al4fw5XY2KCtER and y5yX4jh6kUEgWZQIc(u"ࠪࡶࡦࡿࠠࡪࡦ࠽ࠤࠬၝ") in GvNVH0jL19al4fw5XY2KCtER)
		a0be7vBzlxVqpC9wKfmPWJU = (K7bLVaiRkx0lgU5SQM(u"ࠫ࠺ࠦࡳࡦࡥࠪၞ") in GvNVH0jL19al4fw5XY2KCtER and tg9l25NH6WTacVSifLyAmY(u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭ၟ") in GvNVH0jL19al4fw5XY2KCtER)
		VBohLxNst629vPcAauqMXpO4z = (kQKmN8hHvzcC6PWtbJqr4aL9 in [O4ylJvVNwLztdiHqBWDU(u"࠹࠶࠳፶")] and g4UCaNkHvLwGhjmW(u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩၠ") in GvNVH0jL19al4fw5XY2KCtER)
		ULAv63nqIj4S5RPgVwlpCr = (FF70emVxhWOngCty(u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩၡ") in GvNVH0jL19al4fw5XY2KCtER and vZL6j4tSClIGxzNE5DX(u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬၢ") in GvNVH0jL19al4fw5XY2KCtER)
		if   Zn2yQOf6lWMt9pUeuvcCR51JNIwiB: C4RUnz8IDZ15uXOqG96F2kSTNiygp = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩၣ")
		elif K0ycsNJSEtzfUiAM8Bg92YblId: C4RUnz8IDZ15uXOqG96F2kSTNiygp = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫၤ")
		elif a0be7vBzlxVqpC9wKfmPWJU: C4RUnz8IDZ15uXOqG96F2kSTNiygp = pTwKPmzMSZhil5d2RWonre(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫၥ")
		elif VBohLxNst629vPcAauqMXpO4z: C4RUnz8IDZ15uXOqG96F2kSTNiygp = JJu4MPClbTFpUwHiN(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡡࡤࡥࡨࡷࡸࠦࡤࡦࡰ࡬ࡩࡩ࠭ၦ")
		elif ULAv63nqIj4S5RPgVwlpCr: C4RUnz8IDZ15uXOqG96F2kSTNiygp = Fg72JX6T5DkPy(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨၧ")
		else: C4RUnz8IDZ15uXOqG96F2kSTNiygp = str(C4RUnz8IDZ15uXOqG96F2kSTNiygp)
		if m9TrBXjhwRgI in mB9ZMXEe6rJ1yicGOdAWL8Q: pass
		elif m9TrBXjhwRgI in bbaZdrlivfI6:
			SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+vZL6j4tSClIGxzNE5DX(u"ࠧࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪၨ")+str(kQKmN8hHvzcC6PWtbJqr4aL9)+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪၩ")+C4RUnz8IDZ15uXOqG96F2kSTNiygp+g4UCaNkHvLwGhjmW(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫၪ")+m9TrBXjhwRgI+pGncXOodjKhJzLSqVP1r(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩၫ")+Kj0TOU6BmSMlJHZYLd+Xr2aHOK0huQ5DTS(u"ࠫࠥࡣࠧၬ"))
		else: SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OOhnpQ8XvCVclGqdu(u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩၭ")+str(kQKmN8hHvzcC6PWtbJqr4aL9)+fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨၮ")+C4RUnz8IDZ15uXOqG96F2kSTNiygp+g4UCaNkHvLwGhjmW(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩၯ")+m9TrBXjhwRgI+OOhnpQ8XvCVclGqdu(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧၰ")+Kj0TOU6BmSMlJHZYLd+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࠣࡡࠬၱ"))
		lW0gspXPAn7w3itFKuEVq5 = Fxt7KiXZ5jIvCU1PYk2fr if nxGRV5rKuDzvdNthMa4f else MVkP7zfWlxUXj(Kj0TOU6BmSMlJHZYLd)
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG and isinstance(lW0gspXPAn7w3itFKuEVq5,unicode): lW0gspXPAn7w3itFKuEVq5 = lW0gspXPAn7w3itFKuEVq5.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		if DiTz8KGU6j: lW0gspXPAn7w3itFKuEVq5 = lW0gspXPAn7w3itFKuEVq5.split(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪ࠳ࠬၲ"))[-nfC2im3NzUQk]
		sq0Fz1N4aklnvZdrg3LPKe = str(C4RUnz8IDZ15uXOqG96F2kSTNiygp)+bDt7Ya1VEio3(u"ࠫࡡࡴࠨࠡࠩၳ")+lW0gspXPAn7w3itFKuEVq5+y5yX4jh6kUEgWZQIc(u"ࠬࠦࠩࠨၴ")
		if kQKmN8hHvzcC6PWtbJqr4aL9 in [-nfC2im3NzUQk,-JxuTQLOD357o41evylqPmRdf] or Zn2yQOf6lWMt9pUeuvcCR51JNIwiB or K0ycsNJSEtzfUiAM8Bg92YblId or a0be7vBzlxVqpC9wKfmPWJU or VBohLxNst629vPcAauqMXpO4z or ULAv63nqIj4S5RPgVwlpCr:
			FoZ6n1al9wLqprS.code = -mVjHAyIwzSNKLFcd
			FoZ6n1al9wLqprS.reason = C4RUnz8IDZ15uXOqG96F2kSTNiygp
			if DBw0bSH2GWziLoMlmac1Tf59:
				NARyWwVfmIG1uMtqic08jH = BLrz8bS6dQXf5mKeHjg1T9ZE(vBA4PehsH7aOQGDZi9zj2,Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp)
				if NARyWwVfmIG1uMtqic08jH.succeeded: return NARyWwVfmIG1uMtqic08jH
		nndcv6tehuoKPpI = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if (qqPWDhZlp2zOJ1xAmKXjne==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡁࡔࡍࠪၵ") or Zb0GKOIxPgts18Y6FlSouCV2QEhR==tg9l25NH6WTacVSifLyAmY(u"ࠧࡂࡕࡎࠫၶ")) and (EEhZybv0NfRuH or DBw0bSH2GWziLoMlmac1Tf59):
			nndcv6tehuoKPpI = Wk5ISuRlA7sVLf1j(kQKmN8hHvzcC6PWtbJqr4aL9,sq0Fz1N4aklnvZdrg3LPKe,m9TrBXjhwRgI,xoAmWTH8vprhc)
			if nndcv6tehuoKPpI and qqPWDhZlp2zOJ1xAmKXjne==tOrSvd8QKNB(u"ࠨࡃࡖࡏࠬၷ"): qqPWDhZlp2zOJ1xAmKXjne = pTwKPmzMSZhil5d2RWonre(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫၸ")
			else: qqPWDhZlp2zOJ1xAmKXjne = tOrSvd8QKNB(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬၹ")
			if nndcv6tehuoKPpI and Zb0GKOIxPgts18Y6FlSouCV2QEhR==v54ZuLY6dQ(u"ࠫࡆ࡙ࡋࠨၺ"): Zb0GKOIxPgts18Y6FlSouCV2QEhR = pTwKPmzMSZhil5d2RWonre(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧၻ")
			else: Zb0GKOIxPgts18Y6FlSouCV2QEhR = tOrSvd8QKNB(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨၼ")
			uUTRHgAXJzm7pIDBjNt8.setSetting(XWbHfI9B8swrOL(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪၽ"),qqPWDhZlp2zOJ1xAmKXjne)
			uUTRHgAXJzm7pIDBjNt8.setSetting(TCF8wLyDvgumfiXPSKRh(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ၾ"),Zb0GKOIxPgts18Y6FlSouCV2QEhR)
		if nndcv6tehuoKPpI:
			if kQKmN8hHvzcC6PWtbJqr4aL9==mmKqLr9RX0ACN384JMcsFHzd(u"࠾፷") and DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࡫ࡸࡹࡶࡳࠨၿ") in Kj0TOU6BmSMlJHZYLd and wJoY30TfNUk7GzbdIL:
				if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(Fg72JX6T5DkPy(u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪႀ"),Xr2aHOK0huQ5DTS(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ႁ"),B3TKLo71hAGRqYgV0=aqUlAdFto05NmG4Y6guEzTr8vK(u"࠲࠱࠲࠳፸"))
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬႂ")
				xwq7peVj8AJy = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,xoAmWTH8vprhc,svULcgJ7jm(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧႃ"))
				if xwq7peVj8AJy.succeeded:
					FoZ6n1al9wLqprS = xwq7peVj8AJy
					SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+pTwKPmzMSZhil5d2RWonre(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩႄ")+m9TrBXjhwRgI+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧႅ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+OTRKI6LbrQnZEm(u"ࠩࠣࡡࠬႆ"))
					if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(tg9l25NH6WTacVSifLyAmY(u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧႇ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ႈ"),B3TKLo71hAGRqYgV0=OOhnpQ8XvCVclGqdu(u"࠳࠲࠳࠴፹"))
				else:
					SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+JJu4MPClbTFpUwHiN(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫႉ")+m9TrBXjhwRgI+aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬႊ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+vZL6j4tSClIGxzNE5DX(u"ࠧࠡ࡟ࠪႋ"))
					if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫႌ"),pTwKPmzMSZhil5d2RWonre(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อႍࠫ"),B3TKLo71hAGRqYgV0=Xr2aHOK0huQ5DTS(u"࠴࠳࠴࠵፺"))
			if not FoZ6n1al9wLqprS.succeeded and Zb0GKOIxPgts18Y6FlSouCV2QEhR in [DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡅ࡚࡚ࡏࠨႎ"),OTRKI6LbrQnZEm(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ႏ")] and DBw0bSH2GWziLoMlmac1Tf59:
				if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(Fg72JX6T5DkPy(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ႐"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ႑"),B3TKLo71hAGRqYgV0=O4ylJvVNwLztdiHqBWDU(u"࠵࠴࠵࠶፻"))
				xwq7peVj8AJy = chBoC51wvd(vBA4PehsH7aOQGDZi9zj2,Kj0TOU6BmSMlJHZYLd,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,xoAmWTH8vprhc,m9TrBXjhwRgI)
				if xwq7peVj8AJy.succeeded:
					FoZ6n1al9wLqprS = xwq7peVj8AJy
					SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OOhnpQ8XvCVclGqdu(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ႒")+m9TrBXjhwRgI+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ႓")+iCr0xsqwDZXLPaJK1W5YU24F6hp+FF70emVxhWOngCty(u"ࠩࠣࡡࠬ႔"))
					if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(K7bLVaiRkx0lgU5SQM(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩ႕"),pGncXOodjKhJzLSqVP1r(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭႖"),B3TKLo71hAGRqYgV0=mpusoZBJ6V(u"࠶࠵࠶࠰፼"))
				else:
					SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+y5yX4jh6kUEgWZQIc(u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ႗")+m9TrBXjhwRgI+tg9l25NH6WTacVSifLyAmY(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ႘")+iCr0xsqwDZXLPaJK1W5YU24F6hp+OOhnpQ8XvCVclGqdu(u"ࠧࠡ࡟ࠪ႙"))
					if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(v54ZuLY6dQ(u"ࠨใืู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ႚ"),s0vAWcLSXEToH9Mik134q(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫႛ"),B3TKLo71hAGRqYgV0=VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷࠶࠰࠱፽"))
			if not FoZ6n1al9wLqprS.succeeded and qqPWDhZlp2zOJ1xAmKXjne in [Fg72JX6T5DkPy(u"ࠪࡅ࡚࡚ࡏࠨႜ"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ႝ")] and EEhZybv0NfRuH:
				if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬะแฺ์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧ႞"),mpusoZBJ6V(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ႟"),B3TKLo71hAGRqYgV0=v54ZuLY6dQ(u"࠸࠰࠱࠲፾"))
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd+tg9l25NH6WTacVSifLyAmY(u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬႠ")
				xwq7peVj8AJy = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,xoAmWTH8vprhc,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠺ࡴࡩࠩႡ"))
				if xwq7peVj8AJy.succeeded:
					FoZ6n1al9wLqprS = xwq7peVj8AJy
					SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+pTwKPmzMSZhil5d2RWonre(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩႢ")+aamzjlvJfDIsVxrOYLgnXMo49kN2Z+tg9l25NH6WTacVSifLyAmY(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬႣ")+m9TrBXjhwRgI+K7bLVaiRkx0lgU5SQM(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪႤ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࠦ࡝ࠨႥ"))
					if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(XWbHfI9B8swrOL(u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧႦ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩႧ"),B3TKLo71hAGRqYgV0=O4ylJvVNwLztdiHqBWDU(u"࠲࠱࠲࠳፿"))
				else:
					SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬႨ")+aamzjlvJfDIsVxrOYLgnXMo49kN2Z+tg9l25NH6WTacVSifLyAmY(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫႩ")+m9TrBXjhwRgI+pTwKPmzMSZhil5d2RWonre(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩႪ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+y5yX4jh6kUEgWZQIc(u"ࠫࠥࡣࠧႫ"))
					if xoAmWTH8vprhc: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬႬ"),mpusoZBJ6V(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨႭ"),B3TKLo71hAGRqYgV0=OTRKI6LbrQnZEm(u"࠳࠲࠳࠴ᎀ"))
		if Zb0GKOIxPgts18Y6FlSouCV2QEhR==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩႮ") or qqPWDhZlp2zOJ1xAmKXjne==TCF8wLyDvgumfiXPSKRh(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪႯ"): xoAmWTH8vprhc = YoAMfqm37GyFxbuKTt6e8CESHrhB
		if not FoZ6n1al9wLqprS.succeeded:
			if xoAmWTH8vprhc: Vcud91q2i4Tm5zEvw = Wk5ISuRlA7sVLf1j(kQKmN8hHvzcC6PWtbJqr4aL9,sq0Fz1N4aklnvZdrg3LPKe,m9TrBXjhwRgI,xoAmWTH8vprhc)
			if kQKmN8hHvzcC6PWtbJqr4aL9!=svULcgJ7jm(u"࠴࠳࠴ᎁ") and m9TrBXjhwRgI not in AhnoyUqMCdFs1ijNKeQJuOrH and y5yX4jh6kUEgWZQIc(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭Ⴐ") not in m9TrBXjhwRgI: ksV5ngvbcaS8ByMLYxlfXh()
	if uUTRHgAXJzm7pIDBjNt8.getSetting(Xr2aHOK0huQ5DTS(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭Ⴑ")) not in [TCF8wLyDvgumfiXPSKRh(u"ࠫࡆ࡛ࡔࡐࠩႲ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࡙ࠬࡔࡐࡒࠪႳ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡁࡔࡍࠪႴ")]: uUTRHgAXJzm7pIDBjNt8.setSetting(g4UCaNkHvLwGhjmW(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪႵ"),s0vAWcLSXEToH9Mik134q(u"ࠨࡃࡖࡏࠬႶ"))
	if uUTRHgAXJzm7pIDBjNt8.getSetting(O4ylJvVNwLztdiHqBWDU(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧႷ")) not in [WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡅ࡚࡚ࡏࠨႸ"),svULcgJ7jm(u"ࠫࡘ࡚ࡏࡑࠩႹ"),pTwKPmzMSZhil5d2RWonre(u"ࠬࡇࡓࡌࠩႺ")]: uUTRHgAXJzm7pIDBjNt8.setSetting(g4UCaNkHvLwGhjmW(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫႻ"),pTwKPmzMSZhil5d2RWonre(u"ࠧࡂࡕࡎࠫႼ"))
	return FoZ6n1al9wLqprS
def C2nmAGfShy(n7r4GJUyTcaBNqX=None):
	d3nA2LsHai59 = uUTRHgAXJzm7pIDBjNt8.getSetting(tg9l25NH6WTacVSifLyAmY(u"ࠨࡣࡹ࠲ࡸࡩࡡࡳࡲࡨࡶࡸ࠴ࡦࡢ࡫࡯ࡹࡷ࡫ࡳࡤࡱࡸࡲࡹࡹࠧႽ"))
	d3nA2LsHai59 = d3nA2LsHai59.split(bDt7Ya1VEio3(u"ࠩ࠽࠾ࠬႾ")) if d3nA2LsHai59 else [JJu4MPClbTFpUwHiN(u"ࠪ࠴ࠬႿ")]*g4UCaNkHvLwGhjmW(u"࠹ᎂ")
	ceBTpZ3G4jmKVMHguQyokbLSX = uUTRHgAXJzm7pIDBjNt8.getSetting(bDt7Ya1VEio3(u"ࠫࡦࡼ࠮ࡴࡥࡤࡶࡵ࡫ࡲࡴ࠰࡯ࡥࡸࡺࡦࡢ࡫࡯ࡹࡷ࡫ࡳࡵ࡫ࡰࡩࡸ࠭Ⴠ"))
	ceBTpZ3G4jmKVMHguQyokbLSX = ceBTpZ3G4jmKVMHguQyokbLSX.split(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡀ࠺ࠨჁ")) if ceBTpZ3G4jmKVMHguQyokbLSX else [str(qyUPZBiAE3YkuOKrMnTFex92D)]*Fg72JX6T5DkPy(u"࠺ᎃ")
	bClzpIGQsTUid0qmtwFnXx6WVMRJ = []
	if n7r4GJUyTcaBNqX: n7r4GJUyTcaBNqX -= DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠶ᎄ")
	for ATh6upUgFnm1VybLRcHv2QiGEfX4 in range(y5yX4jh6kUEgWZQIc(u"࠼ᎅ")):
		if ATh6upUgFnm1VybLRcHv2QiGEfX4==n7r4GJUyTcaBNqX:
			d3nA2LsHai59[ATh6upUgFnm1VybLRcHv2QiGEfX4] = str(int(d3nA2LsHai59[ATh6upUgFnm1VybLRcHv2QiGEfX4])+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠱ᎆ"))
			ceBTpZ3G4jmKVMHguQyokbLSX[ATh6upUgFnm1VybLRcHv2QiGEfX4] = str(qyUPZBiAE3YkuOKrMnTFex92D)
		if int(d3nA2LsHai59[ATh6upUgFnm1VybLRcHv2QiGEfX4])<=Fg72JX6T5DkPy(u"࠴ᎇ"): bClzpIGQsTUid0qmtwFnXx6WVMRJ.append(ATh6upUgFnm1VybLRcHv2QiGEfX4)
		elif ATh6upUgFnm1VybLRcHv2QiGEfX4==n7r4GJUyTcaBNqX and qyUPZBiAE3YkuOKrMnTFex92D>int(ceBTpZ3G4jmKVMHguQyokbLSX[ATh6upUgFnm1VybLRcHv2QiGEfX4])+y5yX4jh6kUEgWZQIc(u"࠷ᎈ")*ivRIPHFStXJAM:
			d3nA2LsHai59[ATh6upUgFnm1VybLRcHv2QiGEfX4] = fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࠰ࠨჂ")
			ceBTpZ3G4jmKVMHguQyokbLSX[ATh6upUgFnm1VybLRcHv2QiGEfX4] = str(qyUPZBiAE3YkuOKrMnTFex92D)
			bClzpIGQsTUid0qmtwFnXx6WVMRJ.append(ATh6upUgFnm1VybLRcHv2QiGEfX4)
	if not bClzpIGQsTUid0qmtwFnXx6WVMRJ: d3nA2LsHai59,ceBTpZ3G4jmKVMHguQyokbLSX = [svULcgJ7jm(u"ࠧ࠱ࠩჃ")]*tg9l25NH6WTacVSifLyAmY(u"࠹ᎉ"),[str(qyUPZBiAE3YkuOKrMnTFex92D)]*tg9l25NH6WTacVSifLyAmY(u"࠹ᎉ")
	d3nA2LsHai59 = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࠼࠽ࠫჄ").join(d3nA2LsHai59)
	uUTRHgAXJzm7pIDBjNt8.setSetting(TCF8wLyDvgumfiXPSKRh(u"ࠩࡤࡺ࠳ࡹࡣࡢࡴࡳࡩࡷࡹ࠮ࡧࡣ࡬ࡰࡺࡸࡥࡴࡥࡲࡹࡳࡺࡳࠨჅ"),d3nA2LsHai59)
	ceBTpZ3G4jmKVMHguQyokbLSX = K7bLVaiRkx0lgU5SQM(u"ࠪ࠾࠿࠭჆").join(ceBTpZ3G4jmKVMHguQyokbLSX)
	uUTRHgAXJzm7pIDBjNt8.setSetting(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡦࡼ࠮ࡴࡥࡤࡶࡵ࡫ࡲࡴ࠰࡯ࡥࡸࡺࡦࡢ࡫࡯ࡹࡷ࡫ࡳࡵ࡫ࡰࡩࡸ࠭Ⴧ"),ceBTpZ3G4jmKVMHguQyokbLSX)
	return bClzpIGQsTUid0qmtwFnXx6WVMRJ
def BLrz8bS6dQXf5mKeHjg1T9ZE(vBA4PehsH7aOQGDZi9zj2,Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp):
	X69Fkr1VNnf2pJQC8wl7YR4HmaKc(tg9l25NH6WTacVSifLyAmY(u"ࠬฮฯฤฬࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠧ჈"),QigevCplXxbPI1H,B3TKLo71hAGRqYgV0=svULcgJ7jm(u"࠻࠺࠶ᎊ"))
	SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+FF70emVxhWOngCty(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ჉")+str(kQKmN8hHvzcC6PWtbJqr4aL9)+pTwKPmzMSZhil5d2RWonre(u"ࠧࠡ࡟ࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ჊")+C4RUnz8IDZ15uXOqG96F2kSTNiygp+K7bLVaiRkx0lgU5SQM(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ჋")+m9TrBXjhwRgI+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࠣࡡࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ჌")+Kj0TOU6BmSMlJHZYLd+svULcgJ7jm(u"ࠪࠤࡢ࠭Ⴭ"))
	LrAeZcIyR9duQTob1 = C2nmAGfShy()
	if Fg72JX6T5DkPy(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭჎") in m9TrBXjhwRgI:
		KWd8gTIVsbfk31S6C2zeQAaN = []
		if O4ylJvVNwLztdiHqBWDU(u"࠶ᎋ") in LrAeZcIyR9duQTob1: KWd8gTIVsbfk31S6C2zeQAaN += [O4ylJvVNwLztdiHqBWDU(u"࠶ᎋ")]
		if aqUlAdFto05NmG4Y6guEzTr8vK(u"࠸ᎌ") in LrAeZcIyR9duQTob1: KWd8gTIVsbfk31S6C2zeQAaN += [aqUlAdFto05NmG4Y6guEzTr8vK(u"࠸ᎌ")]
		if OOhnpQ8XvCVclGqdu(u"࠵ᎍ") in LrAeZcIyR9duQTob1: KWd8gTIVsbfk31S6C2zeQAaN += [OOhnpQ8XvCVclGqdu(u"࠵ᎍ")]*OOhnpQ8XvCVclGqdu(u"࠵ᎍ")
		if KWd8gTIVsbfk31S6C2zeQAaN: LrAeZcIyR9duQTob1 = KWd8gTIVsbfk31S6C2zeQAaN
	elif K7bLVaiRkx0lgU5SQM(u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ჏") in m9TrBXjhwRgI:
		KWd8gTIVsbfk31S6C2zeQAaN = []
		if svULcgJ7jm(u"࠲ᎎ") in LrAeZcIyR9duQTob1: KWd8gTIVsbfk31S6C2zeQAaN += [svULcgJ7jm(u"࠲ᎎ")]
		if JJu4MPClbTFpUwHiN(u"࠴ᎏ") in LrAeZcIyR9duQTob1: KWd8gTIVsbfk31S6C2zeQAaN += [JJu4MPClbTFpUwHiN(u"࠴ᎏ")]
		if KWd8gTIVsbfk31S6C2zeQAaN: LrAeZcIyR9duQTob1 = KWd8gTIVsbfk31S6C2zeQAaN
	elif mpusoZBJ6V(u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨა") in m9TrBXjhwRgI:
		if pTwKPmzMSZhil5d2RWonre(u"࠷᎐") in LrAeZcIyR9duQTob1:
			LrAeZcIyR9duQTob1 = [aqUlAdFto05NmG4Y6guEzTr8vK(u"࠹᎒")]*DDHwpETQrAm0xMNXGfyhqsUi(u"࠵࠵᎑")
	if LrAeZcIyR9duQTob1:
		hrftZz4FcEDoKSxA5laPg1URViHb = yarjPEMGV6m7fHRFeJXt.sample(LrAeZcIyR9duQTob1,XWbHfI9B8swrOL(u"࠷᎓"))[v54ZuLY6dQ(u"࠰᎔")]
	else: hrftZz4FcEDoKSxA5laPg1URViHb = -pGncXOodjKhJzLSqVP1r(u"࠲᎕")
	if hrftZz4FcEDoKSxA5laPg1URViHb==tg9l25NH6WTacVSifLyAmY(u"࠳᎖"):
		scraperserver = O4ylJvVNwLztdiHqBWDU(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠴ࠫბ")
		oXzyl5t23u47mBYG8 = OOhnpQ8XvCVclGqdu(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲ࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡘࡷࡻࡥ࠻ࡤ࠵ࡧ࠷࡬ࡣ࠶࠻࠰࠼࡫ࡪ࠰࠮࠶ࡦ࠶ࡩ࠳࠹࠲࠸ࡦ࠱ࡧࡩ࠷࠴࠹࠼࠼࠵ࡩࡥ࠳ࡣࡃࡴࡷࡵࡸࡺ࠰ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳࡯࡯࠻࠷࠶࠹࠸࠭გ")
		mQx10f2SaKD = Kj0TOU6BmSMlJHZYLd+y5yX4jh6kUEgWZQIc(u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩდ")+oXzyl5t23u47mBYG8+mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࢀࢁࡔ࡯ࡗࡧࡵ࡭࡫ࡿࡓࡔࡎࠪე")
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==fk8jc5uDLX16qrih3ZaPxsvO(u"࠵᎗"):
		scraperserver = FF70emVxhWOngCty(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠲ࠨვ")
		oXzyl5t23u47mBYG8 = O4ylJvVNwLztdiHqBWDU(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡭ࡨࡩࡵࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩ࠿࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠿࠻࠳࠶࠵ࠪზ")
		mQx10f2SaKD = Kj0TOU6BmSMlJHZYLd+fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭თ")+oXzyl5t23u47mBYG8+mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧი")
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==OOhnpQ8XvCVclGqdu(u"࠷᎘"):
		scraperserver = XWbHfI9B8swrOL(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬკ")
		oXzyl5t23u47mBYG8 = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠴࡫ࡦࡧࡳࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠽࠻࠻ࡨ࠴ࡧࡥ࠶࠸࡫ࡩࡤ࠲࠻ࡧ࠽ࡨ࠻࠵ࡢ࠳࠸ࡪ࠸࠼࠰࠵ࡥࡧ࠽࠶࠺ࡣࡁࡲࡵࡳࡽࡿ࠭ࡴࡧࡵࡺࡪࡸ࠮ࡴࡥࡵࡥࡵ࡫ࡲࡢࡲ࡬࠲ࡨࡵ࡭࠻࠺࠳࠴࠶࠭ლ")
		mQx10f2SaKD = Kj0TOU6BmSMlJHZYLd+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪმ")+oXzyl5t23u47mBYG8+y5yX4jh6kUEgWZQIc(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫნ")
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==FF70emVxhWOngCty(u"࠹᎙"):
		scraperserver = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡹࡣࡳࡣࡳࡩࡺࡶࠧო")
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd.replace(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨპ"),bDt7Ya1VEio3(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨჟ"))
		mQx10f2SaKD = Xr2aHOK0huQ5DTS(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡣࡳࡣࡳࡩࡺࡶ࠮ࡤࡱࡰ࠳ࡄࡧࡰࡪࡡ࡮ࡩࡾࡃ࠱ࡗࡐࡶࡑࡹࡒ࠱ࡰࡄࡕ࡜ࡰ࡙ࡎࡄࡤࡆࡑࡏ࠷ࡋ࡙࡛ࡍ࡮࡯࠶ࡤ࡫࡜ࡺࠪࡰ࡫ࡥࡱࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡊࡦࡲࡳࡦࠨࡸࡶࡱࡃࠧრ")+NW6gmPcC1B4ILwdHTz0GlDsi5Fkx
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(Xr2aHOK0huQ5DTS(u"ࠩࡊࡉ࡙࠭ს"),mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==K7bLVaiRkx0lgU5SQM(u"࠻᎚"):
		scraperserver = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶࠪტ")
		mQx10f2SaKD = mmKqLr9RX0ACN384JMcsFHzd(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡵࡳࡧࡵࡴ࠯ࡥࡲࡱ࠴ࡅࡴࡰ࡭ࡨࡲࡂࡧ࠴ࡧ࠹ࡩࡦ࠶࠺࠭࠳ࡦࡨࡪ࠲࠺࠰࠸࠳࠰࠼࠻࠺ࡢ࠮࠴࠵ࡩ࠸࠸࠶࠵ࡦ࠷ࡨࡩࡩࠦࡱࡴࡲࡼࡾࡉ࡯ࡶࡰࡷࡶࡾࡃࡊࡐࠨࡸࡶࡱࡃࠧუ")+sqXK91rDldVAEcRTSQL4n2tbC(Kj0TOU6BmSMlJHZYLd)
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(v54ZuLY6dQ(u"ࠬࡍࡅࡕࠩფ"),mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		try:
			NARyWwVfmIG1uMtqic08jH.content = CH86N7xw4cyPt3TlIBJF(XWbHfI9B8swrOL(u"࠭ࡤࡪࡥࡷࠫქ"),NARyWwVfmIG1uMtqic08jH.content)
			NARyWwVfmIG1uMtqic08jH.content = NARyWwVfmIG1uMtqic08jH.content[y5yX4jh6kUEgWZQIc(u"ࠧࡳࡧࡶࡹࡱࡺࠧღ")]
		except: pass
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==mpusoZBJ6V(u"࠶᎛"):
		scraperserver = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠭ყ")
		oXzyl5t23u47mBYG8 = vZL6j4tSClIGxzNE5DX(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠦࡱࡴࡲࡼࡾࡥࡣࡰࡷࡱࡸࡷࡿ࠽ࡂࡇࠩࡦࡷࡵࡷࡴࡧࡵࡁࡋࡧ࡬ࡴࡧࠩࡪࡴࡸࡷࡢࡴࡧࡣ࡭࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧ࠽࠶ࡧ࠹࠴࠱ࡣ࠹࠼࠾࠶ࡡ࠶࠶࠳࠵ࡩࡨࡣ࠴࠹࠵ࡧ࠶࠷࠴࠶ࡦ࠼࠺࠷࡫࠸ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸ࠳ࡩ࡯࡮࠼࠻࠴࠽࠶ࠧშ")
		mQx10f2SaKD = Kj0TOU6BmSMlJHZYLd+Fg72JX6T5DkPy(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪჩ")+oXzyl5t23u47mBYG8+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫც")
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==O4ylJvVNwLztdiHqBWDU(u"࠵࠳᎜"):
		scraperserver = O4ylJvVNwLztdiHqBWDU(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠲ࠩძ")
		oXzyl5t23u47mBYG8 = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡤ࠴࠹࠷ࡦࡨ࠱ࡦ࠷࠳࠸࠹ࡪ࠲ࡤࡣ࠸ࡨ࠺ࡪ࠳ࡧ࠻ࡨ࠷ࡨ࠹࠸࠷ࡧࡦࡥ࠶࠷࠰࠹࠵࠻࠽ࡦ࠽࠳࠻ࡥࡸࡷࡹࡵ࡭ࡉࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭წ")
		mQx10f2SaKD = Kj0TOU6BmSMlJHZYLd+K7bLVaiRkx0lgU5SQM(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧჭ")+oXzyl5t23u47mBYG8+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨხ")
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if O4ylJvVNwLztdiHqBWDU(u"ࠩࡖࡧࡷࡧࡰࡦ࠰ࡧࡳ࠲ࡘࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧ࠮ࡅࡵࡩࡩ࡯ࡴࡴࠩჯ") in list(NARyWwVfmIG1uMtqic08jH.headers.keys()):
			uI7fls9tProqUB = NARyWwVfmIG1uMtqic08jH.headers[O4ylJvVNwLztdiHqBWDU(u"ࠪࡗࡨࡸࡡࡱࡧ࠱ࡨࡴ࠳ࡒࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨ࠯ࡆࡶࡪࡪࡩࡵࡵࠪჰ")]
			uUTRHgAXJzm7pIDBjNt8.setSetting(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡪ࡯࠵࠳ࠪჱ"),uI7fls9tProqUB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==TCF8wLyDvgumfiXPSKRh(u"࠶࠵᎝"):
		scraperserver = tOrSvd8QKNB(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠳ࠩჲ")
		oXzyl5t23u47mBYG8 = tg9l25NH6WTacVSifLyAmY(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱ࡤ࠵ࡧ࠷ࡦ࡫࠱࠹࠷ࡧࡪ࠹ࡨࡦ࠷ࡣࡩ࠹࠸࠹ࡣ࠸࠲࠷࠴ࡧ࠹࠴࠸ࡥ࠼ࡩ࠾࠿ࡢࡦ࠶࠹࠺ࡦ࡫࠹࠻ࡥࡸࡷࡹࡵ࡭ࡉࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯࠻࠺࠳࠼࠵࠭ჳ")
		mQx10f2SaKD = Kj0TOU6BmSMlJHZYLd+JJu4MPClbTFpUwHiN(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧჴ")+oXzyl5t23u47mBYG8+O4ylJvVNwLztdiHqBWDU(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨჵ")
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if s0vAWcLSXEToH9Mik134q(u"ࠩࡖࡧࡷࡧࡰࡦ࠰ࡧࡳ࠲ࡘࡥ࡮ࡣ࡬ࡲ࡮ࡴࡧ࠮ࡅࡵࡩࡩ࡯ࡴࡴࠩჶ") in list(NARyWwVfmIG1uMtqic08jH.headers.keys()):
			uI7fls9tProqUB = NARyWwVfmIG1uMtqic08jH.headers[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡗࡨࡸࡡࡱࡧ࠱ࡨࡴ࠳ࡒࡦ࡯ࡤ࡭ࡳ࡯࡮ࡨ࠯ࡆࡶࡪࡪࡩࡵࡵࠪჷ")]
			uUTRHgAXJzm7pIDBjNt8.setSetting(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡪ࡯࠵࠴ࠪჸ"),uI7fls9tProqUB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	elif hrftZz4FcEDoKSxA5laPg1URViHb==K7bLVaiRkx0lgU5SQM(u"࠸࠵᎞"):
		scraperserver = JJu4MPClbTFpUwHiN(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠴ࠩჹ")
		mQx10f2SaKD = bDt7Ya1VEio3(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡬ࡳ࠴ࡼ࠱࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀࡦ࠷ࡩ࠲ࡧࡥ࠸࠽࠲࠾ࡦࡥ࠲࠰࠸ࡨ࠸ࡤ࠮࠻࠴࠺ࡨ࠳ࡢࡤ࠹࠶࠻࠾࠾࠰ࡤࡧ࠵ࡥࠫࡻࡲ࡭࠿ࠪჺ")+Kj0TOU6BmSMlJHZYLd
		NARyWwVfmIG1uMtqic08jH = ISAO6PGrtB5u1edT4Jif0mq(TCF8wLyDvgumfiXPSKRh(u"ࠧࡈࡇࡗࠫ჻"),mQx10f2SaKD,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,YbgdiQeolJWPRr0F,xoAmWTH8vprhc,m9TrBXjhwRgI,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
		if not NARyWwVfmIG1uMtqic08jH.succeeded: C2nmAGfShy(hrftZz4FcEDoKSxA5laPg1URViHb)
	else:
		scraperserver,mQx10f2SaKD = QigevCplXxbPI1H,QigevCplXxbPI1H
		NARyWwVfmIG1uMtqic08jH = aTqvbmueLIYkRjSODlK8BCW()
	NARyWwVfmIG1uMtqic08jH.scrapernumber = str(hrftZz4FcEDoKSxA5laPg1URViHb)
	NARyWwVfmIG1uMtqic08jH.scraperserver = scraperserver
	NARyWwVfmIG1uMtqic08jH.scraperurl = mQx10f2SaKD
	ANZG57T6EHmv1Wl = JJu4MPClbTFpUwHiN(u"ࠨีํีๆืࠠาไ่ࠤࠬჼ")+NARyWwVfmIG1uMtqic08jH.scrapernumber
	if NARyWwVfmIG1uMtqic08jH.succeeded:
		SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+svULcgJ7jm(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩჽ")+scraperserver+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬჾ")+m9TrBXjhwRgI+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪჿ")+Kj0TOU6BmSMlJHZYLd+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࠦ࡝ࠨᄀ"))
		X69Fkr1VNnf2pJQC8wl7YR4HmaKc(g4UCaNkHvLwGhjmW(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᄁ"),ANZG57T6EHmv1Wl,B3TKLo71hAGRqYgV0=DDHwpETQrAm0xMNXGfyhqsUi(u"࠻࠺࠶᎟"))
	else:
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫᄂ")+scraperserver+tOrSvd8QKNB(u"ࠨࠢࡠࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨᄃ")+str(NARyWwVfmIG1uMtqic08jH.code)+g4UCaNkHvLwGhjmW(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᄄ")+NARyWwVfmIG1uMtqic08jH.reason+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᄅ")+m9TrBXjhwRgI+JJu4MPClbTFpUwHiN(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᄆ")+Kj0TOU6BmSMlJHZYLd+pGncXOodjKhJzLSqVP1r(u"ࠬࠦ࡝ࠨᄇ"))
		X69Fkr1VNnf2pJQC8wl7YR4HmaKc(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᄈ"),ANZG57T6EHmv1Wl,B3TKLo71hAGRqYgV0=OTRKI6LbrQnZEm(u"࠼࠻࠰Ꭰ"))
	return NARyWwVfmIG1uMtqic08jH
def hPo36xNERyQtmrMABnDc4zKY0elUa(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2=QigevCplXxbPI1H,L7hdwV2QJmK8CtWEkGRanu=QigevCplXxbPI1H):
	Kj0TOU6BmSMlJHZYLd,xUW6Rh7CXS,K6STmZrVO8bqYxz7IgjPh,owqUkQjRIrH7puTyOG = bnETX3l26rzAve7p0ci(iCr0xsqwDZXLPaJK1W5YU24F6hp)
	try: LLGzYF3eCa8S6UAKj4ZsP9Qcwq72Oy = zXCVN4eIxRJTrUD.copy()
	except: LLGzYF3eCa8S6UAKj4ZsP9Qcwq72Oy = zXCVN4eIxRJTrUD
	a3m046bDiUGHgNtVKXMrpQCAcF = vBA4PehsH7aOQGDZi9zj2,Kj0TOU6BmSMlJHZYLd,VV4iSgTwskE6uyoBCl3ZDh7HQ,LLGzYF3eCa8S6UAKj4ZsP9Qcwq72Oy,PBCTIHLWQZMz2gJiy8kE9fcYUV
	if xU4Y951Jcpf6jKGPOSemWILdCEZvg:
		lE7ZB0CTayhKItApFnYxz = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,mpusoZBJ6V(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩᄉ"),bDt7Ya1VEio3(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠫᄊ"),a3m046bDiUGHgNtVKXMrpQCAcF)
		if lE7ZB0CTayhKItApFnYxz.succeeded:
			OOIHQRsiD2(OTRKI6LbrQnZEm(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡖࠤࠥࡘࡅࡂࡆࡢࡇࡆࡉࡈࡆࠩᄋ"),Kj0TOU6BmSMlJHZYLd,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,m9TrBXjhwRgI,vBA4PehsH7aOQGDZi9zj2)
			return lE7ZB0CTayhKItApFnYxz
	lE7ZB0CTayhKItApFnYxz = ISAO6PGrtB5u1edT4Jif0mq(vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,PBCTIHLWQZMz2gJiy8kE9fcYUV,showDialogs,m9TrBXjhwRgI,vw1Fb37ptGlaEVdDy2,L7hdwV2QJmK8CtWEkGRanu)
	if lE7ZB0CTayhKItApFnYxz.succeeded:
		if svULcgJ7jm(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᄌ") in m9TrBXjhwRgI: lE7ZB0CTayhKItApFnYxz.content = hznK9suBQoEtTmwND4qXFg2(lE7ZB0CTayhKItApFnYxz.content)
		if lE7ZB0CTayhKItApFnYxz.scrape: xU4Y951Jcpf6jKGPOSemWILdCEZvg = g6gNzml5rOsa8bBETxPCpnVj
		if xU4Y951Jcpf6jKGPOSemWILdCEZvg: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,bDt7Ya1VEio3(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧᄍ"),a3m046bDiUGHgNtVKXMrpQCAcF,lE7ZB0CTayhKItApFnYxz,xU4Y951Jcpf6jKGPOSemWILdCEZvg)
	return lE7ZB0CTayhKItApFnYxz
def XcU2IYdoEG9vzrDiLxsQC(xU4Y951Jcpf6jKGPOSemWILdCEZvg,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,showDialogs,m9TrBXjhwRgI):
	if not VV4iSgTwskE6uyoBCl3ZDh7HQ or isinstance(VV4iSgTwskE6uyoBCl3ZDh7HQ,dict): vBA4PehsH7aOQGDZi9zj2 = vZL6j4tSClIGxzNE5DX(u"ࠬࡍࡅࡕࠩᄎ")
	else:
		vBA4PehsH7aOQGDZi9zj2 = y5yX4jh6kUEgWZQIc(u"࠭ࡐࡐࡕࡗࠫᄏ")
		VV4iSgTwskE6uyoBCl3ZDh7HQ = MVkP7zfWlxUXj(VV4iSgTwskE6uyoBCl3ZDh7HQ)
		aHlF8CxVr9WPLGIApMbXwKyenEZ7z,VV4iSgTwskE6uyoBCl3ZDh7HQ = b9PJzXFf4dYnGHm52NWsyA8(VV4iSgTwskE6uyoBCl3ZDh7HQ)
	lE7ZB0CTayhKItApFnYxz = hPo36xNERyQtmrMABnDc4zKY0elUa(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,showDialogs,m9TrBXjhwRgI)
	zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.content
	zHrPxh0aevGnlKMTdjQsV = str(zHrPxh0aevGnlKMTdjQsV)
	return zHrPxh0aevGnlKMTdjQsV
def bnETX3l26rzAve7p0ci(iCr0xsqwDZXLPaJK1W5YU24F6hp):
	eAwku4VOW9gLXfFYMbily7m = iCr0xsqwDZXLPaJK1W5YU24F6hp.split(K7bLVaiRkx0lgU5SQM(u"ࠧࡽࡾࠪᄐ"))
	Kj0TOU6BmSMlJHZYLd,xUW6Rh7CXS,K6STmZrVO8bqYxz7IgjPh,owqUkQjRIrH7puTyOG = eAwku4VOW9gLXfFYMbily7m[h17Zb2ld4yLBrCP5tiw],None,None,XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	for a3m046bDiUGHgNtVKXMrpQCAcF in eAwku4VOW9gLXfFYMbily7m:
		if aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᄑ") in a3m046bDiUGHgNtVKXMrpQCAcF: xUW6Rh7CXS = a3m046bDiUGHgNtVKXMrpQCAcF[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠷࠱Ꭱ"):]
		elif FF70emVxhWOngCty(u"ࠩࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬᄒ") in a3m046bDiUGHgNtVKXMrpQCAcF: K6STmZrVO8bqYxz7IgjPh = a3m046bDiUGHgNtVKXMrpQCAcF[svULcgJ7jm(u"࠹Ꭲ"):]
		elif Fg72JX6T5DkPy(u"ࠪࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᄓ") in a3m046bDiUGHgNtVKXMrpQCAcF: owqUkQjRIrH7puTyOG = YoAMfqm37GyFxbuKTt6e8CESHrhB
	return Kj0TOU6BmSMlJHZYLd,xUW6Rh7CXS,K6STmZrVO8bqYxz7IgjPh,owqUkQjRIrH7puTyOG
def bPTkyvMBIxeajFqWRu3KhfE0G1sS(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,aDqWGX4EpVIAml7rYQjzNLZTc,MuUh8gkow4AzQ,Ua0wVyWP5cN3D8QztAEe7469mFibT,zXCVN4eIxRJTrUD=QigevCplXxbPI1H):
	nsrje9UyYWudl8maTF5ko1h6ZQCOJ = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(iCr0xsqwDZXLPaJK1W5YU24F6hp,O4ylJvVNwLztdiHqBWDU(u"ࠫࡺࡸ࡬ࠨᄔ"))
	yyVAGdCK5Pjhar8gpnbcIetUkMT = uUTRHgAXJzm7pIDBjNt8.getSetting(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧᄕ")+aDqWGX4EpVIAml7rYQjzNLZTc)
	if nsrje9UyYWudl8maTF5ko1h6ZQCOJ==yyVAGdCK5Pjhar8gpnbcIetUkMT: uUTRHgAXJzm7pIDBjNt8.setSetting(K7bLVaiRkx0lgU5SQM(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᄖ")+aDqWGX4EpVIAml7rYQjzNLZTc,QigevCplXxbPI1H)
	if yyVAGdCK5Pjhar8gpnbcIetUkMT: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = iCr0xsqwDZXLPaJK1W5YU24F6hp.replace(nsrje9UyYWudl8maTF5ko1h6ZQCOJ,yyVAGdCK5Pjhar8gpnbcIetUkMT)
	else:
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = iCr0xsqwDZXLPaJK1W5YU24F6hp
		yyVAGdCK5Pjhar8gpnbcIetUkMT = nsrje9UyYWudl8maTF5ko1h6ZQCOJ
	xwq7peVj8AJy = hPo36xNERyQtmrMABnDc4zKY0elUa(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,QigevCplXxbPI1H,zXCVN4eIxRJTrUD,QigevCplXxbPI1H,QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫᄗ"))
	zHrPxh0aevGnlKMTdjQsV = xwq7peVj8AJy.content
	if b7sJAmSxlBvaMdHFz:
		try: zHrPxh0aevGnlKMTdjQsV = zHrPxh0aevGnlKMTdjQsV.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᄘ"))
		except: pass
	if not xwq7peVj8AJy.succeeded or Ua0wVyWP5cN3D8QztAEe7469mFibT not in zHrPxh0aevGnlKMTdjQsV:
		MuUh8gkow4AzQ = MuUh8gkow4AzQ.replace(hT7zFDpEyUqf8sXuN,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ࠮ࠫᄙ"))
		Kj0TOU6BmSMlJHZYLd = g4UCaNkHvLwGhjmW(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᄚ")+MuUh8gkow4AzQ
		T24Te3uDwBS5vLgUEAhF1O = {FF70emVxhWOngCty(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᄛ"):QigevCplXxbPI1H}
		FoZ6n1al9wLqprS = hPo36xNERyQtmrMABnDc4zKY0elUa(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠸࡮ࡥࠩᄜ"))
		if FoZ6n1al9wLqprS.succeeded:
			zHrPxh0aevGnlKMTdjQsV = FoZ6n1al9wLqprS.content
			if b7sJAmSxlBvaMdHFz:
				try: zHrPxh0aevGnlKMTdjQsV = zHrPxh0aevGnlKMTdjQsV.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᄝ"))
				except: pass
			rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡠࡼ࠰࡜ࡀ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨᄞ"),zHrPxh0aevGnlKMTdjQsV,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			O4OTiMlX2wLGIHUKW07xg5Ck = [yyVAGdCK5Pjhar8gpnbcIetUkMT]
			gvAXF0HkubRtUlYKWn2dwGmsa = [aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡣࡳ࡯ࠬᄟ"),pGncXOodjKhJzLSqVP1r(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩᄠ"),v54ZuLY6dQ(u"ࠪࡸࡼ࡯ࡴࡵࡧࡵࠫᄡ"),mpusoZBJ6V(u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬᄢ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱࠧᄣ"),DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡰࡩࡲࠪᄤ"),tg9l25NH6WTacVSifLyAmY(u"ࠧࡢࡶ࡯ࡥࡶ࠭ᄥ"),K7bLVaiRkx0lgU5SQM(u"ࠨࡵ࡬ࡸࡪ࡯࡮ࡥ࡫ࡦࡩࡸ࠭ᄦ"),tOrSvd8QKNB(u"ࠩࡶࡹࡷ࠴࡬ࡺࠩᄧ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡦࡱࡵࡧࡴࡲࡲࡸࠬᄨ"),Fg72JX6T5DkPy(u"ࠫ࡮ࡴࡦࡰࡴࡰࡩࡷ࠭ᄩ"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࡹࡩࡵࡧ࡯࡭ࡰ࡫ࠧᄪ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡩ࡯ࡵࡷࡥ࡬ࡸࡡ࡮ࠩᄫ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡴࡰࡤࡴࡨ࡮ࡡࡵࠩᄬ"),JJu4MPClbTFpUwHiN(u"ࠨࡪࡷࡸࡵ࠳ࡥࡲࡷ࡬ࡺࠬᄭ"),Xr2aHOK0huQ5DTS(u"ࠩࡩࡥࡸ࡫࡬ࡱ࡮ࡸࡷࠬᄮ")]
			for g2JSOX0pTIYL6 in rsBojxT8UZwL:
				if any(nFdGHjceZzW in g2JSOX0pTIYL6 for nFdGHjceZzW in gvAXF0HkubRtUlYKWn2dwGmsa): continue
				yyVAGdCK5Pjhar8gpnbcIetUkMT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(g2JSOX0pTIYL6,s0vAWcLSXEToH9Mik134q(u"ࠪࡹࡷࡲࠧᄯ"))
				if yyVAGdCK5Pjhar8gpnbcIetUkMT in O4OTiMlX2wLGIHUKW07xg5Ck: continue
				if len(O4OTiMlX2wLGIHUKW07xg5Ck)==Fg72JX6T5DkPy(u"࠺Ꭳ"):
					SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+Xr2aHOK0huQ5DTS(u"ࠫࠥࠦࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡡࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫᄰ")+aDqWGX4EpVIAml7rYQjzNLZTc+y5yX4jh6kUEgWZQIc(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪᄱ")+nsrje9UyYWudl8maTF5ko1h6ZQCOJ+O4ylJvVNwLztdiHqBWDU(u"࠭ࠠ࡞ࠩᄲ"))
					uUTRHgAXJzm7pIDBjNt8.setSetting(Fg72JX6T5DkPy(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᄳ")+aDqWGX4EpVIAml7rYQjzNLZTc,QigevCplXxbPI1H)
					break
				O4OTiMlX2wLGIHUKW07xg5Ck.append(yyVAGdCK5Pjhar8gpnbcIetUkMT)
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = iCr0xsqwDZXLPaJK1W5YU24F6hp.replace(nsrje9UyYWudl8maTF5ko1h6ZQCOJ,yyVAGdCK5Pjhar8gpnbcIetUkMT)
				xwq7peVj8AJy = hPo36xNERyQtmrMABnDc4zKY0elUa(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,QigevCplXxbPI1H,zXCVN4eIxRJTrUD,QigevCplXxbPI1H,QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬᄴ"))
				zHrPxh0aevGnlKMTdjQsV = xwq7peVj8AJy.content
				if xwq7peVj8AJy.succeeded and Ua0wVyWP5cN3D8QztAEe7469mFibT in zHrPxh0aevGnlKMTdjQsV:
					SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+XWbHfI9B8swrOL(u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡦࠦ࡮ࡦࡹࠣ࡬ࡴࡹࡴ࡯ࡣࡰࡩࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩᄵ")+aDqWGX4EpVIAml7rYQjzNLZTc+mpusoZBJ6V(u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩᄶ")+yyVAGdCK5Pjhar8gpnbcIetUkMT+OTRKI6LbrQnZEm(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩᄷ")+nsrje9UyYWudl8maTF5ko1h6ZQCOJ+mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࠦ࡝ࠨᄸ"))
					uUTRHgAXJzm7pIDBjNt8.setSetting(TCF8wLyDvgumfiXPSKRh(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᄹ")+aDqWGX4EpVIAml7rYQjzNLZTc,yyVAGdCK5Pjhar8gpnbcIetUkMT)
					break
	return yyVAGdCK5Pjhar8gpnbcIetUkMT,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,xwq7peVj8AJy
def aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(CyarqoiHxV2e80ScjAN):
	qqenf73wNiG1IyVdA6O5 = {
	 tOrSvd8QKNB(u"ࠧࡰ࡮ࡧࠫᄺ")					:Fg72JX6T5DkPy(u"ࠨไา๎๊࠭ᄻ")
	,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫᄼ")				:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"้ࠪฯ๎โโࠩᄽ")
	,v54ZuLY6dQ(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬᄾ")				:K7bLVaiRkx0lgU5SQM(u"๋ࠬแใ๊าࠫᄿ")
	,bDt7Ya1VEio3(u"࠭ࡧࡰࡱࡧࠫᅀ")					:OOhnpQ8XvCVclGqdu(u"ࠧอ์าࠫᅁ")
	,mpusoZBJ6V(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᅂ")				:Xr2aHOK0huQ5DTS(u"ࠩไุ้࠭ᅃ")
	,tOrSvd8QKNB(u"ࠪࡪࡴࡲࡤࡦࡴࠪᅄ")				:DDHwpETQrAm0xMNXGfyhqsUi(u"๊ࠫาไะࠩᅅ")
	,TCF8wLyDvgumfiXPSKRh(u"ࠬࡼࡩࡥࡧࡲࠫᅆ")				:mpusoZBJ6V(u"࠭แ๋ัํ์ࠬᅇ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧ࡭࡫ࡹࡩࠬᅈ")					:s0vAWcLSXEToH9Mik134q(u"ࠨไ้หฮ࠭ᅉ")
	,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡤ࡬ࡼࡧ࡫ࠨᅊ")				:pTwKPmzMSZhil5d2RWonre(u"้ࠪํู่ࠡล๊์ฬ้ࠠห์ไ๎ࠬᅋ")
	,K7bLVaiRkx0lgU5SQM(u"ࠫࡦࡱ࡯ࡢ࡯ࠪᅌ")				:NUZQ4Wgo6OIuRY0avMPepqVcyK(u"๋่ࠬใ฻ࠣว่๎วๆࠢส่็ี๊ๆࠩᅍ")
	,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡡ࡬ࡱࡤࡱࡨࡧ࡭ࠨᅎ")				:OOhnpQ8XvCVclGqdu(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨᅏ")
	,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡣ࡮ࡻࡦࡳࠧᅐ")				:K7bLVaiRkx0lgU5SQM(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭ᅑ")
	,tg9l25NH6WTacVSifLyAmY(u"ࠪࡥࡱࡧࡲࡢࡤࠪᅒ")				:svULcgJ7jm(u"๊ࠫ๎โฺࠢๆ่ࠥอไฺำหࠫᅓ")
	,y5yX4jh6kUEgWZQIc(u"ࠬࡧ࡬ࡧࡣࡷ࡭ࡲ࡯ࠧᅔ")				:s0vAWcLSXEToH9Mik134q(u"࠭ๅ้ไ฼ࠤฬ๊ๅ็สิࠤฬ๊แศู่๎ࠬᅕ")
	,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡢ࡮࡮ࡥࡼࡺࡨࡢࡴࠪᅖ")			:DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ใ้อิࠫᅗ")
	,v54ZuLY6dQ(u"ࠩࡤࡰࡲࡧࡡࡳࡧࡩࠫᅘ")				:hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"้ࠪํู่ࠡไ้หฮࠦวๅ็฼หึ็ࠧᅙ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡦࡸࡡࡣ࡫ࡦࡸࡴࡵ࡮ࡴࠩᅚ")			:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"๋่ࠬใ฻ࠣฮํ์าࠡ฻ิฬ๏ฯࠧᅛ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨᅜ")				:XWbHfI9B8swrOL(u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧᅝ")
	,bDt7Ya1VEio3(u"ࠨࡣࡵࡦࡱ࡯࡯࡯ࡼࠪᅞ")				:y5yX4jh6kUEgWZQIc(u"่ࠩ์็฿ฺࠠำหࠤ้๐่็ิࠪᅟ")
	,vZL6j4tSClIGxzNE5DX(u"ࠪࡦࡴࡱࡲࡢࠩᅠ")				:DD7NjwespWyQJ4E6mXk0ZAufPg(u"๊ࠫ๎โฺࠢห็ึอࠧᅡ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡨࡲࡴࡶࡨ࡮ࠬᅢ")				:aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ๅ้ไ฼ࠤอืำห์ฯࠫᅣ")
	,O4ylJvVNwLztdiHqBWDU(u"ࠧࡤ࡫ࡰࡥ࠹࠶࠰ࠨᅤ")				:tg9l25NH6WTacVSifLyAmY(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ࠹࠶࠰ࠨᅥ")
	,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩᅦ")				:QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬᅧ")
	,pGncXOodjKhJzLSqVP1r(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭ᅨ")				:mpusoZBJ6V(u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭ᅩ")
	,svULcgJ7jm(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨᅪ")				:Xr2aHOK0huQ5DTS(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨᅫ")
	,v54ZuLY6dQ(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࡺࡳࡷࡱࠧᅬ")			:bDt7Ya1VEio3(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠣ฽๊๊ࠧᅭ")
	,s0vAWcLSXEToH9Mik134q(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡴࠬᅮ")				:mmKqLr9RX0ACN384JMcsFHzd(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬᅯ")
	,mpusoZBJ6V(u"ࠬࡩࡩ࡮ࡣࡩࡥࡳࡹࠧᅰ")				:vZL6j4tSClIGxzNE5DX(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧᅱ")
	,pGncXOodjKhJzLSqVP1r(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪᅲ")			:Xr2aHOK0huQ5DTS(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩᅳ")
	,y5yX4jh6kUEgWZQIc(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᅴ")				:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪᅵ")
	,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᅶ")			:Fg72JX6T5DkPy(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭ᅷ")
	,FF70emVxhWOngCty(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᅸ")	:hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡไ้์ฬะࠧᅹ")
	,pGncXOodjKhJzLSqVP1r(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩᅺ"):O4ylJvVNwLztdiHqBWDU(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆํอฦๆࠩᅻ")
	,tOrSvd8QKNB(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡶࡲࡴ࡮ࡩࡳࠨᅼ")	:s0vAWcLSXEToH9Mik134q(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬᅽ")
	,OOhnpQ8XvCVclGqdu(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡺ࡮ࡪࡥࡰࡵࠪᅾ")	:QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩᅿ")
	,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡲࡩࡷࡧࡶࠫᆀ")	:g4UCaNkHvLwGhjmW(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็่ࠢฬฬฺัࠨᆁ")
	,y5yX4jh6kUEgWZQIc(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡩࡣࡶ࡬ࡹࡧࡧࡴࠩᆂ")	:OOhnpQ8XvCVclGqdu(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ์อิหษๆࠫᆃ")
	,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡩࡸࡡ࡮ࡣࡶ࠻ࠬᆄ")				:OTRKI6LbrQnZEm(u"๋่ࠬใ฻ࠣำึอๅศุࠢัࠬᆅ")
	,bDt7Ya1VEio3(u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧᆆ")				:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠨᆇ")
	,TCF8wLyDvgumfiXPSKRh(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪᆈ")				:y5yX4jh6kUEgWZQIc(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠵ࠬᆉ")
	,FF70emVxhWOngCty(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠶ࠬᆊ")				:OTRKI6LbrQnZEm(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧᆋ")
	,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧᆌ")				:K7bLVaiRkx0lgU5SQM(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠴ࠩᆍ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠵ࠩᆎ")				:Fg72JX6T5DkPy(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫᆏ")
	,g4UCaNkHvLwGhjmW(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵ࠭ᆐ")			:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤࡻ࡯ࡰࠨᆑ")
	,O4ylJvVNwLztdiHqBWDU(u"ࠫࡪ࡭ࡹࡥࡧࡤࡨࠬᆒ")				:FF70emVxhWOngCty(u"๋่ࠬใ฻ࠣษ๏า๊ࠡัํำࠬᆓ")
	,bDt7Ya1VEio3(u"࠭ࡥࡨࡻࡱࡳࡼ࠭ᆔ")				:O4ylJvVNwLztdiHqBWDU(u"ࠧๆ๊ๅ฽ࠥห๊อ์๊ࠣฬ๎ࠧᆕ")
	,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣࠪᆖ")				:vZL6j4tSClIGxzNE5DX(u"่ࠩ์็฿ࠠศๆึ๎๋๋วࠨᆗ")
	,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡪࡦࡨࡲࡢ࡭ࡤࠫᆘ")				:OOhnpQ8XvCVclGqdu(u"๊ࠫ๎โฺࠢไฬึ้ษࠨᆙ")
	,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬ࡬ࡡ࡫ࡧࡵࡷ࡭ࡵࡷࠨᆚ")			:v54ZuLY6dQ(u"࠭ๅ้ไ฼ࠤๆาัࠡึ๋ࠫᆛ")
	,JJu4MPClbTFpUwHiN(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩᆜ")				:g4UCaNkHvLwGhjmW(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊ร้ๆࠪᆝ")
	,K7bLVaiRkx0lgU5SQM(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠵ࠫᆞ")				:mpusoZBJ6V(u"้ࠪํู่ࠡใสู้ࠦวๅอส๊๏࠭ᆟ")
	,FF70emVxhWOngCty(u"ࠫ࡫ࡵࡳࡵࡣࠪᆠ")				:vZL6j4tSClIGxzNE5DX(u"๋่ࠬใ฻ࠣๅํูสศࠩᆡ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨᆢ")				:fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧๆ๊ๅ฽ࠥํไศࠢึ๎๊อࠧᆣ")
	,JJu4MPClbTFpUwHiN(u"ࠨࡪࡨࡰࡦࡲࠧᆤ")				:fk8jc5uDLX16qrih3ZaPxsvO(u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬᆥ")
	,vZL6j4tSClIGxzNE5DX(u"ࠪ࡭࡫࡯࡬࡮ࠩᆦ")				:Fg72JX6T5DkPy(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠨᆧ")
	,FF70emVxhWOngCty(u"ࠬ࡯ࡦࡪ࡮ࡰ࠱ࡦࡸࡡࡣ࡫ࡦࠫᆨ")			:vZL6j4tSClIGxzNE5DX(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠣ฽ึฮ๊ࠨᆩ")
	,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡥ࡯ࡩ࡯࡭ࡸ࡮ࠧᆪ")		:OOhnpQ8XvCVclGqdu(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥอๆอๆํึ๏࠭ᆫ")
	,FF70emVxhWOngCty(u"ࠩ࡬ࡴࡹࡼࠧᆬ")					:VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡍࡕ࡚ࡖࠨᆭ")
	,vZL6j4tSClIGxzNE5DX(u"ࠫ࡮ࡶࡴࡷ࠯࡯࡭ࡻ࡫ࠧᆮ")			:FF70emVxhWOngCty(u"ࠬࡏࡐࡕࡘࠣๆ๋๎วหࠩᆯ")
	,mpusoZBJ6V(u"࠭ࡩࡱࡶࡹ࠱ࡲࡵࡶࡪࡧࡶࠫᆰ")			:svULcgJ7jm(u"ࠧࡊࡒࡗ࡚ࠥษแๅษ่ࠫᆱ")
	,vZL6j4tSClIGxzNE5DX(u"ࠨ࡫ࡳࡸࡻ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᆲ")			:s0vAWcLSXEToH9Mik134q(u"ࠩࡌࡔ࡙࡜ࠠๆี็ื้อสࠨᆳ")
	,mpusoZBJ6V(u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭ᆴ")			:g4UCaNkHvLwGhjmW(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧᆵ")
	,Fg72JX6T5DkPy(u"ࠬࡱࡡࡵ࡭ࡲࡸࡹࡼࠧᆶ")				:bDt7Ya1VEio3(u"࠭ๅ้ไ฼ࠤ่ะใ้ฬࠣฮ๏็๊ࠨᆷ")
	,v54ZuLY6dQ(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩᆸ")				:OOhnpQ8XvCVclGqdu(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠬᆹ")
	,OTRKI6LbrQnZEm(u"ࠩ࡯ࡥࡷࡵࡺࡢࠩᆺ")				:s0vAWcLSXEToH9Mik134q(u"้ࠪํู่ࠡๆสีํุวࠨᆻ")
	,svULcgJ7jm(u"ࠫࡱ࡯ࡢࡳࡣࡵࡽࠬᆼ")				:NUZQ4Wgo6OIuRY0avMPepqVcyK(u"๋ࠬไโࠩᆽ")
	,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࡬ࡪࡸࡨࡸࡻ࠭ᆾ")				:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧๆๆไࠫᆿ")
	,Xr2aHOK0huQ5DTS(u"ࠨ࡮ࡲࡨࡾࡴࡥࡵࠩᇀ")				:pTwKPmzMSZhil5d2RWonre(u"่ࠩ์็฿ࠠๅ๊า๎ࠥ์สࠨᇁ")
	,bDt7Ya1VEio3(u"ࠪࡱ࠸ࡻࠧᇂ")					:XWbHfI9B8swrOL(u"ࠫࡒ࠹ࡕࠨᇃ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡳ࠳ࡶ࠯࡯࡭ࡻ࡫ࠧᇄ")				:fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡍ࠴ࡗࠣๆ๋๎วหࠩᇅ")
	,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧ࡮࠵ࡸ࠱ࡲࡵࡶࡪࡧࡶࠫᇆ")			:OTRKI6LbrQnZEm(u"ࠨࡏ࠶࡙ࠥษแๅษ่ࠫᇇ")
	,XWbHfI9B8swrOL(u"ࠩࡰ࠷ࡺ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ᇈ")			:Xr2aHOK0huQ5DTS(u"ࠪࡑ࠸࡛ࠠๆี็ื้อสࠨᇉ")
	,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫᇊ")				:g4UCaNkHvLwGhjmW(u"๋่ࠬใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧᇋ")
	,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ᇌ")				:mmKqLr9RX0ACN384JMcsFHzd(u"ࠧๆ๊ๅ฽๋ࠥว๋ࠢึ๎๊อࠧᇍ")
	,Xr2aHOK0huQ5DTS(u"ࠨࡲࡤࡲࡪࡺࠧᇎ")				:TCF8wLyDvgumfiXPSKRh(u"่ࠩ์็฿ࠠษษ้๎ฯ࠭ᇏ")
	,TCF8wLyDvgumfiXPSKRh(u"ࠪࡴࡦࡴࡥࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩᇐ")			:g4UCaNkHvLwGhjmW(u"๊ࠫ๎โฺࠢหห๋๐สࠡษไ่ฬ๋ࠧᇑ")
	,Xr2aHOK0huQ5DTS(u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡸ࡫ࡲࡪࡧࡶࠫᇒ")			:OOhnpQ8XvCVclGqdu(u"࠭ๅ้ไ฼ࠤออๆ๋ฬุ้๊ࠣำๅษอࠫᇓ")
	,vZL6j4tSClIGxzNE5DX(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩᇔ")				:tOrSvd8QKNB(u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠪᇕ")
	,tOrSvd8QKNB(u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭ᇖ")			:g4UCaNkHvLwGhjmW(u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫᇗ")
	,s0vAWcLSXEToH9Mik134q(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫ࠧᇘ")			:pGncXOodjKhJzLSqVP1r(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠧᇙ")
	,vZL6j4tSClIGxzNE5DX(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡰࡧࡻ࡭ࡴࠩᇚ")		:v54ZuLY6dQ(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠢส่อ๎ๅࠨᇛ")
	,FF70emVxhWOngCty(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡦࡻࡤࡪࡱࡶࠫᇜ")		:XWbHfI9B8swrOL(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤฺ๎ส๋ษอࠫᇝ")
	,JJu4MPClbTFpUwHiN(u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠳ࡰࡦࡴࡶࡳࡳࡹࠧᇞ")	:s0vAWcLSXEToH9Mik134q(u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫᇟ")
	,XWbHfI9B8swrOL(u"ࠬࡹࡨࡰࡨ࡫ࡥࠬᇠ")				:VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨᇡ")
	,v54ZuLY6dQ(u"ࠧࡴࡪࡲࡳ࡫ࡳࡡࡹࠩᇢ")				:TCF8wLyDvgumfiXPSKRh(u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨᇣ")
	,FF70emVxhWOngCty(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫᇤ")				:K7bLVaiRkx0lgU5SQM(u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩᇥ")
	,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡹࡼࡦࡶࡰࠪᇦ")				:tOrSvd8QKNB(u"๋่ࠬใ฻ࠣฮ๏็๊ࠡใส๊ࠬᇧ")
	,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭ᇨ")				:JJu4MPClbTFpUwHiN(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬ࠭ᇩ")
	,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡻࡤࡵࡴࡺࠧᇪ")				:svULcgJ7jm(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭ᇫ")
	,Fg72JX6T5DkPy(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫᇬ")				:v54ZuLY6dQ(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩᇭ")
	,XWbHfI9B8swrOL(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨᇮ")		:DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็์่ศฬࠪᇯ")
	,OOhnpQ8XvCVclGqdu(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫᇰ")	:vZL6j4tSClIGxzNE5DX(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬᇱ")
	,tOrSvd8QKNB(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪᇲ")		:Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪᇳ")
	,K7bLVaiRkx0lgU5SQM(u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪᇴ")			:Fg72JX6T5DkPy(u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫᇵ")
	}
	try: cL4pMx8ECUzgdQPelwohuFmnsK = qqenf73wNiG1IyVdA6O5[CyarqoiHxV2e80ScjAN.lower()]
	except: cL4pMx8ECUzgdQPelwohuFmnsK = QigevCplXxbPI1H
	return cL4pMx8ECUzgdQPelwohuFmnsK
def ksV5ngvbcaS8ByMLYxlfXh(hQGVDU4xS7d5ZrNwnlI3ju0p8Wm=None,nFdGHjceZzW=QigevCplXxbPI1H):
	if not nFdGHjceZzW and hQGVDU4xS7d5ZrNwnlI3ju0p8Wm: nFdGHjceZzW = aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡒࡆࡓࡘࡉࡘ࡚࡟ࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧᇶ")
	uUTRHgAXJzm7pIDBjNt8.setSetting(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫᇷ"),nFdGHjceZzW)
	if hQGVDU4xS7d5ZrNwnlI3ju0p8Wm!=None:
		LFtkv1dZI6QNUlAq0wX = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡡࡢࡣࡗࡋࡆࡓࡇࡖࡌࡤࡇࡎࡅࡡࡢࡣࠬᇸ")
		LFtkv1dZI6QNUlAq0wX += vZL6j4tSClIGxzNE5DX(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬᇹ")
		raise ValueError(LFtkv1dZI6QNUlAq0wX)
	else:
		pJHMl4kqyvhfZdse()
		KXhrv29CGR8QTDzJIWLY.exit()
def sqXK91rDldVAEcRTSQL4n2tbC(iCr0xsqwDZXLPaJK1W5YU24F6hp,VVNF2143fItRG0huQbx=v54ZuLY6dQ(u"ࠪ࠾࠴࠭ᇺ")):
	return _0NlhwdvYf2A3PituyUGemxDMJz9(iCr0xsqwDZXLPaJK1W5YU24F6hp,VVNF2143fItRG0huQbx)
def LPnzlyYDXRmbwVi2SK(ozfPw0HuT9snMtSZDE):
	if ozfPw0HuT9snMtSZDE in [QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"ࠫ࠵࠭ᇻ"),h17Zb2ld4yLBrCP5tiw]: return QigevCplXxbPI1H
	ozfPw0HuT9snMtSZDE = int(ozfPw0HuT9snMtSZDE)
	xjFmKDyaceJ = ozfPw0HuT9snMtSZDE^g6gNzml5rOsa8bBETxPCpnVj
	s0jFvuH2JMxyZc697D = ozfPw0HuT9snMtSZDE^pETKl7xuH1f5yjdFAb6C8JzOLV
	L95a7iGDRwhMIAbk4q = ozfPw0HuT9snMtSZDE^vjPhaUE819opVQg7uRk4wG6cYBOTd
	cL4pMx8ECUzgdQPelwohuFmnsK = str(xjFmKDyaceJ)+str(s0jFvuH2JMxyZc697D)+str(L95a7iGDRwhMIAbk4q)
	return cL4pMx8ECUzgdQPelwohuFmnsK
def uu5IGUj02yVQvsWlhKXpZEB3Fb(ozfPw0HuT9snMtSZDE):
	if ozfPw0HuT9snMtSZDE in [QigevCplXxbPI1H,XWbHfI9B8swrOL(u"ࠬ࠶ࠧᇼ"),h17Zb2ld4yLBrCP5tiw]: return QigevCplXxbPI1H
	ozfPw0HuT9snMtSZDE = str(ozfPw0HuT9snMtSZDE)
	cL4pMx8ECUzgdQPelwohuFmnsK = QigevCplXxbPI1H
	if len(ozfPw0HuT9snMtSZDE)==Fg72JX6T5DkPy(u"࠳࠸Ꭴ"):
		xjFmKDyaceJ,s0jFvuH2JMxyZc697D,L95a7iGDRwhMIAbk4q = ozfPw0HuT9snMtSZDE[h17Zb2ld4yLBrCP5tiw:bWU9StnJOg6aIQiTMxh7sFZG8lPud],ozfPw0HuT9snMtSZDE[bWU9StnJOg6aIQiTMxh7sFZG8lPud:hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠼Ꭵ")],ozfPw0HuT9snMtSZDE[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠼Ꭵ"):]
		xjFmKDyaceJ = int(xjFmKDyaceJ)^vjPhaUE819opVQg7uRk4wG6cYBOTd
		s0jFvuH2JMxyZc697D = int(s0jFvuH2JMxyZc697D)^pETKl7xuH1f5yjdFAb6C8JzOLV
		L95a7iGDRwhMIAbk4q = int(L95a7iGDRwhMIAbk4q)^g6gNzml5rOsa8bBETxPCpnVj
		if xjFmKDyaceJ==s0jFvuH2JMxyZc697D==L95a7iGDRwhMIAbk4q: cL4pMx8ECUzgdQPelwohuFmnsK = str(xjFmKDyaceJ*OOhnpQ8XvCVclGqdu(u"࠺࠵Ꭶ"))
	return cL4pMx8ECUzgdQPelwohuFmnsK
def lY3kWbFJCKMto68f(ozfPw0HuT9snMtSZDE,TEG42lAqIQim0jKn35pPZycot7=vZL6j4tSClIGxzNE5DX(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨᇽ")):
	if ozfPw0HuT9snMtSZDE==QigevCplXxbPI1H: return QigevCplXxbPI1H
	ozfPw0HuT9snMtSZDE = int(ozfPw0HuT9snMtSZDE)+int(TEG42lAqIQim0jKn35pPZycot7)
	xjFmKDyaceJ = ozfPw0HuT9snMtSZDE^g6gNzml5rOsa8bBETxPCpnVj
	s0jFvuH2JMxyZc697D = ozfPw0HuT9snMtSZDE^pETKl7xuH1f5yjdFAb6C8JzOLV
	L95a7iGDRwhMIAbk4q = ozfPw0HuT9snMtSZDE^vjPhaUE819opVQg7uRk4wG6cYBOTd
	cL4pMx8ECUzgdQPelwohuFmnsK = str(xjFmKDyaceJ)+str(s0jFvuH2JMxyZc697D)+str(L95a7iGDRwhMIAbk4q)
	return cL4pMx8ECUzgdQPelwohuFmnsK
def Z0njBFkw321oC9NItAmEX5O4S6ay(ozfPw0HuT9snMtSZDE,TEG42lAqIQim0jKn35pPZycot7=tOrSvd8QKNB(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩᇾ")):
	if ozfPw0HuT9snMtSZDE==QigevCplXxbPI1H: return QigevCplXxbPI1H
	ozfPw0HuT9snMtSZDE = str(ozfPw0HuT9snMtSZDE)
	E1lpZAJBhUtv9Wnfsa8c3OL = int(len(ozfPw0HuT9snMtSZDE)/mVjHAyIwzSNKLFcd)
	xjFmKDyaceJ = int(ozfPw0HuT9snMtSZDE[h17Zb2ld4yLBrCP5tiw:E1lpZAJBhUtv9Wnfsa8c3OL])^g6gNzml5rOsa8bBETxPCpnVj
	s0jFvuH2JMxyZc697D = int(ozfPw0HuT9snMtSZDE[E1lpZAJBhUtv9Wnfsa8c3OL:JxuTQLOD357o41evylqPmRdf*E1lpZAJBhUtv9Wnfsa8c3OL])^pETKl7xuH1f5yjdFAb6C8JzOLV
	L95a7iGDRwhMIAbk4q = int(ozfPw0HuT9snMtSZDE[JxuTQLOD357o41evylqPmRdf*E1lpZAJBhUtv9Wnfsa8c3OL:mVjHAyIwzSNKLFcd*E1lpZAJBhUtv9Wnfsa8c3OL])^vjPhaUE819opVQg7uRk4wG6cYBOTd
	cL4pMx8ECUzgdQPelwohuFmnsK = QigevCplXxbPI1H
	if xjFmKDyaceJ==s0jFvuH2JMxyZc697D==L95a7iGDRwhMIAbk4q: cL4pMx8ECUzgdQPelwohuFmnsK = str(int(xjFmKDyaceJ)-int(TEG42lAqIQim0jKn35pPZycot7))
	return cL4pMx8ECUzgdQPelwohuFmnsK
def r4kvMcV79HDh(XXwdYAmZkV80Dc7RSIOTE3):
	LreM5daNvV9qKt4Ox2XGD = OQv0iWIw5bFRATU2mxJjZK[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨᇿ")][svULcgJ7jm(u"࠽Ꭷ")]
	B17q5NvClMW3RYjcXib6xIyA0LF = U8bMvkLTxSzw5ac(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠹࠲Ꭸ"))
	xzBRHpXDTfUKG = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,OOhnpQ8XvCVclGqdu(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬሀ"),JJu4MPClbTFpUwHiN(u"ࠪࡷࡰ࡯࡮ࡴࠩሁ"),Xr2aHOK0huQ5DTS(u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬሂ"),svULcgJ7jm(u"ࠬ࠽࠲࠱ࡲࠪሃ"),pTwKPmzMSZhil5d2RWonre(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨሄ"))
	OftawMxm4TEHZzI1LSeh3q0sguQ,naqZbtWl9cgKJQCiL = dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(xzBRHpXDTfUKG)
	OftawMxm4TEHZzI1LSeh3q0sguQ = lY3kWbFJCKMto68f(OftawMxm4TEHZzI1LSeh3q0sguQ,JJu4MPClbTFpUwHiN(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪህ"))
	E3sOpIZVNz = {QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨ࡫ࡧࡷࠬሆ"):DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡇࡍࡆࡒࡏࡈࠩሇ"),bDt7Ya1VEio3(u"ࠪࡹࡸࡸࠧለ"):B17q5NvClMW3RYjcXib6xIyA0LF,K7bLVaiRkx0lgU5SQM(u"ࠫࡻ࡫ࡲࠨሉ"):GVmdqbtLu8lUXNxp13aHOvkscR,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡹࡣࡳࠩሊ"):XXwdYAmZkV80Dc7RSIOTE3,TCF8wLyDvgumfiXPSKRh(u"࠭ࡳࡪࡼࠪላ"):OftawMxm4TEHZzI1LSeh3q0sguQ}
	uZUDey4YLIGpS2Ojf65MVClKn0 = {Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ሌ"):OOhnpQ8XvCVclGqdu(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧል")}
	paZN7jFet3lgIkrYfzqx = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,tOrSvd8QKNB(u"ࠩࡓࡓࡘ࡚ࠧሎ"),LreM5daNvV9qKt4Ox2XGD,E3sOpIZVNz,uZUDey4YLIGpS2Ojf65MVClKn0,QigevCplXxbPI1H,QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡓࡐࡆ࡟࡟ࡅࡋࡄࡐࡔࡍ࠭࠲ࡵࡷࠫሏ"))
	LiPMpGXcEtOov0qHZW4jmTC29nQ = paZN7jFet3lgIkrYfzqx.content
	try:
		if not LiPMpGXcEtOov0qHZW4jmTC29nQ: GRp2D0sEtFy1CiTVzgYk8ISvKcj
		p9U0WqD5INg7lZ = CH86N7xw4cyPt3TlIBJF(FF70emVxhWOngCty(u"ࠫࡩ࡯ࡣࡵࠩሐ"),LiPMpGXcEtOov0qHZW4jmTC29nQ)
		idfL6hlm3O = p9U0WqD5INg7lZ[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡳࡳࡨࠩሑ")]
		sBJjXOPzvye9CthMVH5kZmnW = p9U0WqD5INg7lZ[fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡳࡦࡥࠪሒ")]
		dSGWf36jcC9YvDlwRe2 = p9U0WqD5INg7lZ[tg9l25NH6WTacVSifLyAmY(u"ࠧࡴࡶࡳࠫሓ")]
		sBJjXOPzvye9CthMVH5kZmnW = int(Z0njBFkw321oC9NItAmEX5O4S6ay(sBJjXOPzvye9CthMVH5kZmnW,pGncXOodjKhJzLSqVP1r(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫሔ")))
		dSGWf36jcC9YvDlwRe2 = int(Z0njBFkw321oC9NItAmEX5O4S6ay(dSGWf36jcC9YvDlwRe2,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬሕ")))
		for L9KsSl0gYuEdApGe in range(sBJjXOPzvye9CthMVH5kZmnW,h17Zb2ld4yLBrCP5tiw,-dSGWf36jcC9YvDlwRe2):
			if not eval(OTRKI6LbrQnZEm(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࡜ࡩࡥࡧࡲࠬ࠮࠭ሖ"),{DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡽࡨ࡭ࡤࠩሗ"):qVuYLZTmSUhQe7rEwvFRfc}): GRp2D0sEtFy1CiTVzgYk8ISvKcj
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬฮวใ์่้ࠣะฬาสฬࠤํอไโฯุࠫመ"),str(L9KsSl0gYuEdApGe)+fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠࠡอส๊๏ฯࠧሙ"),B3TKLo71hAGRqYgV0=K7bLVaiRkx0lgU5SQM(u"࠳࠱࠲Ꭹ")*dSGWf36jcC9YvDlwRe2)
			qVuYLZTmSUhQe7rEwvFRfc.sleep(v54ZuLY6dQ(u"࠲࠲࠳࠴Ꭺ")*dSGWf36jcC9YvDlwRe2)
		if eval(mpusoZBJ6V(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪሚ"),{OTRKI6LbrQnZEm(u"ࠨࡺࡥࡱࡨ࠭ማ"):qVuYLZTmSUhQe7rEwvFRfc}):
			idfL6hlm3O = idfL6hlm3O.replace(aSBkt4OU8JpWTEzVIHjAiv,svULcgJ7jm(u"ࠩ࡟ࡠࡳ࠭ሜ")).replace(Ymkp8qFPsjovc57UT,OOhnpQ8XvCVclGqdu(u"ࠪࡠࡡࡸࠧም"))
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠫำื่อࠩሞ"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨሟ"),idfL6hlm3O)
		GRp2D0sEtFy1CiTVzgYk8ISvKcj
	except: exec(FF70emVxhWOngCty(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ሠ"),{tOrSvd8QKNB(u"ࠧࡹࡤࡰࡧࠬሡ"):qVuYLZTmSUhQe7rEwvFRfc})
	return
def gIkDSqPu05YZ():
	exec(pTwKPmzMSZhil5d2RWonre(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩࠥࡧࡶࡣࡱࡲࡰࡪࡧ࡮ࡵࡴࡸࡩ࠿ࠓࠊࠊࠋࡻࡦࡲࡩ࠮ࡴ࡮ࡨࡩࡵ࠮࠱࠱࠲࠳࠭ࠒࠐࠉࠊࡶࡵࡽ࠿ࠦࡷࡪࡰࡧࡳࡼ࠷࠲࠴࠰ࡪࡩࡹࡌ࡯ࡤࡷࡶࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡤࡵࡩࡦࡱࠍࠋࠋࡽࡧࡷ࡫ࡡࡵࡧࡢࡩࡷࡵࡲࡳࠏࠍࡩࡽࡩࡥࡱࡶ࠽ࠤࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠑࠏ࠭ࠧࠨሢ"),{Fg72JX6T5DkPy(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪሣ"):Q0BXbnOs1jr8afIyTUHZDw4lCAki7,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡼࡧࡳࡣࠨሤ"):qVuYLZTmSUhQe7rEwvFRfc})
	return
def dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(Hl7FmSYzejKpB1v8T0):
	h2McBXGu6mEJVQPnZfDS0,S6bnmEiKxr0JUvHMt5pgsjV = h17Zb2ld4yLBrCP5tiw,h17Zb2ld4yLBrCP5tiw
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(Hl7FmSYzejKpB1v8T0):
		try: h2McBXGu6mEJVQPnZfDS0 = KiTt9ZskMLjnCAUIJNXD7.path.getsize(Hl7FmSYzejKpB1v8T0)
		except: pass
		if not h2McBXGu6mEJVQPnZfDS0:
			try: h2McBXGu6mEJVQPnZfDS0 = KiTt9ZskMLjnCAUIJNXD7.stat(Hl7FmSYzejKpB1v8T0).st_size
			except: pass
		if not h2McBXGu6mEJVQPnZfDS0:
			try:
				from pathlib import Path as yUnEBimLKbWhFkMtel
				h2McBXGu6mEJVQPnZfDS0 = yUnEBimLKbWhFkMtel(Hl7FmSYzejKpB1v8T0).stat().st_size
			except: pass
		if h2McBXGu6mEJVQPnZfDS0: S6bnmEiKxr0JUvHMt5pgsjV = nfC2im3NzUQk
	return h2McBXGu6mEJVQPnZfDS0,S6bnmEiKxr0JUvHMt5pgsjV
def eB8jr3L1inmU6OzINJd(A1Jto26cjgqK53PsnI4VEw,vdM6wCaG3iUqVnOEs8yWJ1DP,showDialogs):
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሥ"),A1Jto26cjgqK53PsnI4VEw+TCF8wLyDvgumfiXPSKRh(u"ࠬࡢ࡮࡝ࡰࠪሦ")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+JJu4MPClbTFpUwHiN(u"࠭็ๅࠢอี๏ีࠠๆีะࠤ์ึวࠡษ็้ั๊ฯࠡมࠤࠫሧ")+jhAlCQ47ZgG)
		if nndcv6tehuoKPpI!=nfC2im3NzUQk: return
	f5fDJrRQGbEtTp07zHBKCua2 = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(A1Jto26cjgqK53PsnI4VEw):
		for dSZirVLRbpCDn3NUxtz,xGpYfljiqaH4TQo7DPzkR3AmNESU,ad6U8LEqbwI9t7PhKOkJBusX4en in KiTt9ZskMLjnCAUIJNXD7.walk(A1Jto26cjgqK53PsnI4VEw,topdown=YoAMfqm37GyFxbuKTt6e8CESHrhB):
			for Hl7FmSYzejKpB1v8T0 in ad6U8LEqbwI9t7PhKOkJBusX4en:
				OOlAhT76nC = KiTt9ZskMLjnCAUIJNXD7.path.join(dSZirVLRbpCDn3NUxtz,Hl7FmSYzejKpB1v8T0)
				try: KiTt9ZskMLjnCAUIJNXD7.remove(OOlAhT76nC)
				except Exception as HqIej1PzSpAEWZ8Y7buc:
					if showDialogs and not f5fDJrRQGbEtTp07zHBKCua2: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪረ"),str(HqIej1PzSpAEWZ8Y7buc))
					f5fDJrRQGbEtTp07zHBKCua2 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			if vdM6wCaG3iUqVnOEs8yWJ1DP:
				for dir in xGpYfljiqaH4TQo7DPzkR3AmNESU:
					jmgxnfTeOPc = KiTt9ZskMLjnCAUIJNXD7.path.join(dSZirVLRbpCDn3NUxtz,dir)
					try: KiTt9ZskMLjnCAUIJNXD7.rmdir(jmgxnfTeOPc)
					except: pass
		if vdM6wCaG3iUqVnOEs8yWJ1DP:
			try: KiTt9ZskMLjnCAUIJNXD7.rmdir(dSZirVLRbpCDn3NUxtz)
			except: pass
	if showDialogs and not f5fDJrRQGbEtTp07zHBKCua2:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫሩ"),Xr2aHOK0huQ5DTS(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪሪ"))
		ksV5ngvbcaS8ByMLYxlfXh(JJu4MPClbTFpUwHiN(u"ࡋࡧ࡬ࡴࡧᎵ"))
	return
def pJHMl4kqyvhfZdse(THFfWLwt62MmUz=QigevCplXxbPI1H):
	if THFfWLwt62MmUz:
		if K7bLVaiRkx0lgU5SQM(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ራ") in THFfWLwt62MmUz:
			THFfWLwt62MmUz  = THFfWLwt62MmUz.split(OTRKI6LbrQnZEm(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧሬ"))[nfC2im3NzUQk][OTRKI6LbrQnZEm(u"࠳Ꭻ"):]
			if THFfWLwt62MmUz:
				SQdRhwozVfv(QigevCplXxbPI1H,THFfWLwt62MmUz)
		else:
			ssGfCdzum4rMlEqaNkKDLR = uUTRHgAXJzm7pIDBjNt8.getSetting(pTwKPmzMSZhil5d2RWonre(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ር"))
			uUTRHgAXJzm7pIDBjNt8.setSetting(O4ylJvVNwLztdiHqBWDU(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧሮ"),QigevCplXxbPI1H)
			L5C2adJcDkS0e(THFfWLwt62MmUz)
			uUTRHgAXJzm7pIDBjNt8.setSetting(Fg72JX6T5DkPy(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨሯ"),ssGfCdzum4rMlEqaNkKDLR)
	SxKAmIcoHeQ1(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡵࡷࡳࡵ࠭ሰ"))
	aeRHmPISMkDNA2vd7F6gzpB9C = uUTRHgAXJzm7pIDBjNt8.getSetting(FF70emVxhWOngCty(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ሱ"))
	if aeRHmPISMkDNA2vd7F6gzpB9C==pTwKPmzMSZhil5d2RWonre(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡣࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫሲ"): uUTRHgAXJzm7pIDBjNt8.setSetting(pGncXOodjKhJzLSqVP1r(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨሳ"),JJu4MPClbTFpUwHiN(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬሴ"))
	elif aeRHmPISMkDNA2vd7F6gzpB9C==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ስ"): uUTRHgAXJzm7pIDBjNt8.setSetting(pTwKPmzMSZhil5d2RWonre(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫሶ"),QigevCplXxbPI1H)
	if uUTRHgAXJzm7pIDBjNt8.getSetting(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡥࡰࡶࠫሷ")) not in [mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࡄ࡙࡙ࡕࠧሸ"),y5yX4jh6kUEgWZQIc(u"ࠪࡗ࡙ࡕࡐࠨሹ"),vZL6j4tSClIGxzNE5DX(u"ࠫࡆ࡙ࡋࠨሺ")]: uUTRHgAXJzm7pIDBjNt8.setSetting(mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨሻ"),K7bLVaiRkx0lgU5SQM(u"࠭ࡁࡔࡍࠪሼ"))
	if uUTRHgAXJzm7pIDBjNt8.getSetting(mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬሽ")) not in [bDt7Ya1VEio3(u"ࠨࡃࡘࡘࡔ࠭ሾ"),y5yX4jh6kUEgWZQIc(u"ࠩࡖࡘࡔࡖࠧሿ"),pTwKPmzMSZhil5d2RWonre(u"ࠪࡅࡘࡑࠧቀ")]: uUTRHgAXJzm7pIDBjNt8.setSetting(pGncXOodjKhJzLSqVP1r(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩቁ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡇࡓࡌࠩቂ"))
	hLlK5NdGuWeZXqMU = uUTRHgAXJzm7pIDBjNt8.getSetting(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡡࡷ࠰ࡰࡽࡸࡱࡩ࡯࠰ࡹ࡭ࡪࡽ࡭ࡰࡦࡨࠫቃ"))
	Y8TnKMyWpslzubrkFR6tAOaDiSBg = qVuYLZTmSUhQe7rEwvFRfc.executeJSONRPC(FF70emVxhWOngCty(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪቄ"))
	if JJu4MPClbTFpUwHiN(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧቅ") in str(Y8TnKMyWpslzubrkFR6tAOaDiSBg) and hLlK5NdGuWeZXqMU in [Fg72JX6T5DkPy(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬቆ"),bDt7Ya1VEio3(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩቇ")]:
		B3TKLo71hAGRqYgV0.sleep(K7bLVaiRkx0lgU5SQM(u"࠳࠲࠶࠶࠰Ꭼ"))
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(FF70emVxhWOngCty(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡔࡧࡷ࡚࡮࡫ࡷࡎࡱࡧࡩ࠭࠶ࠩࠨቈ"))
	if h17Zb2ld4yLBrCP5tiw and NNZh0HbgakloGKdCOUYJ3W1SAnXPwi>-nfC2im3NzUQk:
		Z7ZstrGoNP3XSLYClzUm8TqV.setResolvedUrl(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,YoAMfqm37GyFxbuKTt6e8CESHrhB,Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ListItem())
		AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L = YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB
		Z7ZstrGoNP3XSLYClzUm8TqV.endOfDirectory(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,AMu7aiqvPT6WcLOXDSkhFzdN,BFlrO18heutDTW309yopHdLgzIUJj,TTNjGlo8t4Cb6nsMPUqBaID5L)
	return
def xYWkrtyMJs48(xU4Y951Jcpf6jKGPOSemWILdCEZvg,vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,m9TrBXjhwRgI):
	Kj0TOU6BmSMlJHZYLd,xUW6Rh7CXS,K6STmZrVO8bqYxz7IgjPh,owqUkQjRIrH7puTyOG = bnETX3l26rzAve7p0ci(iCr0xsqwDZXLPaJK1W5YU24F6hp)
	a3m046bDiUGHgNtVKXMrpQCAcF = vBA4PehsH7aOQGDZi9zj2,Kj0TOU6BmSMlJHZYLd,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD
	if xU4Y951Jcpf6jKGPOSemWILdCEZvg:
		zHrPxh0aevGnlKMTdjQsV = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡹࡴࡳࠩ቉"),VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧቊ"),a3m046bDiUGHgNtVKXMrpQCAcF)
		if zHrPxh0aevGnlKMTdjQsV:
			OOIHQRsiD2(OOhnpQ8XvCVclGqdu(u"ࠧࡖࡔࡏࡐࡎࡈࠠࠡࡔࡈࡅࡉࡥࡃࡂࡅࡋࡉࠬቋ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,m9TrBXjhwRgI,vBA4PehsH7aOQGDZi9zj2)
			return zHrPxh0aevGnlKMTdjQsV
	zHrPxh0aevGnlKMTdjQsV = jZmIRWGxy60AongCuFOpMJV(vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,m9TrBXjhwRgI)
	if zHrPxh0aevGnlKMTdjQsV and xU4Y951Jcpf6jKGPOSemWILdCEZvg: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,OOhnpQ8XvCVclGqdu(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩቌ"),a3m046bDiUGHgNtVKXMrpQCAcF,zHrPxh0aevGnlKMTdjQsV,xU4Y951Jcpf6jKGPOSemWILdCEZvg)
	return zHrPxh0aevGnlKMTdjQsV
from JD27eAMu4z import *
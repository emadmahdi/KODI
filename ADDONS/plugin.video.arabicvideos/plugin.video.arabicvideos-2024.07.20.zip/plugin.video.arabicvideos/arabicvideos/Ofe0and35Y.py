# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'ALARAB'
headers = {'User-Agent':QigevCplXxbPI1H}
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_KLA_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==10: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==11: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	elif mode==12: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==13: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==14: W9lfsoMawqOzpQcXD = MWRoOhZwE6FeD7GuJ4bylU2Tg()
	elif mode==15: W9lfsoMawqOzpQcXD = DFB3uk964t2P()
	elif mode==16: W9lfsoMawqOzpQcXD = YMFClcmbrx3i8()
	elif mode==19: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,19,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'آخر الإضافات',QigevCplXxbPI1H,14)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان',QigevCplXxbPI1H,15)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'ALARAB-MENU-1st')
	fwSu6JsQZpEiv=sBvufaD6c9YHdOqTjCQ3.findall('id="nav-slider"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	BAuRv6icDU8LEo = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',BAuRv6icDU8LEo,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
		title = title.strip(hT7zFDpEyUqf8sXuN)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="navbar"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Pk5h14WpxO3nAQFv0rYmNa8KDblSg = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',Pk5h14WpxO3nAQFv0rYmNa8KDblSg,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,11)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def DFB3uk964t2P():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'جميع المسلسلات العربية',vxQUXEuH9m+'/view-8/مسلسلات-عربية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات السنة الأخيرة',QigevCplXxbPI1H,16)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان الأخيرة 1',vxQUXEuH9m+'/view-8/مسلسلات-رمضان-2022',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان الأخيرة 2',vxQUXEuH9m+'/view-8/مسلسلات-رمضان-2023',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2023',vxQUXEuH9m+'/ramadan2023/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2022',vxQUXEuH9m+'/ramadan2022/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2021',vxQUXEuH9m+'/ramadan2021/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2020',vxQUXEuH9m+'/ramadan2020/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2019',vxQUXEuH9m+'/ramadan2019/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2018',vxQUXEuH9m+'/ramadan2018/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2017',vxQUXEuH9m+'/ramadan2017/مصرية',11)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات رمضان 2016',vxQUXEuH9m+'/ramadan2016/مصرية',11)
	return
def MWRoOhZwE6FeD7GuJ4bylU2Tg():
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,vxQUXEuH9m,QigevCplXxbPI1H,headers,True,'ALARAB-LATEST-1st')
	fwSu6JsQZpEiv=sBvufaD6c9YHdOqTjCQ3.findall('heading-top(.*?)div class=',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]+fwSu6JsQZpEiv[1]
	items=sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		url = vxQUXEuH9m + RMC6c2kL5hGOnFaIwAyb
		if 'series' in url: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,11,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,12,cXu4fN1moCypJqb72OZvd)
	return
def ddbEXhWzOnIaR(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,True,True,'ALARAB-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('video-category(.*?)right_content',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv: return
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	ARiQLVuwZY2nqCB5tv9mbe31f6 = False
	items = sBvufaD6c9YHdOqTjCQ3.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM,NMwXB7fWHCAUQrtlh = [],[]
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if title==QigevCplXxbPI1H: title = RMC6c2kL5hGOnFaIwAyb.split('/')[-1].replace('-',hT7zFDpEyUqf8sXuN)
		BLIwYgHkv25j1d6DsEUl3rae7M = sBvufaD6c9YHdOqTjCQ3.findall('(\d+)',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if BLIwYgHkv25j1d6DsEUl3rae7M: BLIwYgHkv25j1d6DsEUl3rae7M = int(BLIwYgHkv25j1d6DsEUl3rae7M[0])
		else: BLIwYgHkv25j1d6DsEUl3rae7M = 0
		NMwXB7fWHCAUQrtlh.append([cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title,BLIwYgHkv25j1d6DsEUl3rae7M])
	NMwXB7fWHCAUQrtlh = sorted(NMwXB7fWHCAUQrtlh, reverse=True, key=lambda key: key[3])
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title,BLIwYgHkv25j1d6DsEUl3rae7M in NMwXB7fWHCAUQrtlh:
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m + RMC6c2kL5hGOnFaIwAyb
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',QigevCplXxbPI1H)
		title = title.replace('عالية على العرب',QigevCplXxbPI1H)
		title = title.replace('مشاهدة مباشرة',QigevCplXxbPI1H)
		title = title.replace('اون لاين',QigevCplXxbPI1H)
		title = title.replace('اونلاين',QigevCplXxbPI1H)
		title = title.replace('بجودة عالية',QigevCplXxbPI1H)
		title = title.replace('جودة عالية',QigevCplXxbPI1H)
		title = title.replace('بدون تحميل',QigevCplXxbPI1H)
		title = title.replace('على العرب',QigevCplXxbPI1H)
		title = title.replace('مباشرة',QigevCplXxbPI1H)
		title = title.strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
		title = '_MOD_'+title
		YIwQJyV0hAUR1EfKogObLzDMmx = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if V1nZX7O5WwEq8HmvkY: YIwQJyV0hAUR1EfKogObLzDMmx = V1nZX7O5WwEq8HmvkY[0]
		if YIwQJyV0hAUR1EfKogObLzDMmx not in wibHRCAFtsupIjx4ZTELeM:
			wibHRCAFtsupIjx4ZTELeM.append(YIwQJyV0hAUR1EfKogObLzDMmx)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,RMC6c2kL5hGOnFaIwAyb,13,cXu4fN1moCypJqb72OZvd)
				ARiQLVuwZY2nqCB5tv9mbe31f6 = True
			elif 'series' in RMC6c2kL5hGOnFaIwAyb:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,11,cXu4fN1moCypJqb72OZvd)
				ARiQLVuwZY2nqCB5tv9mbe31f6 = True
			else:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,12,cXu4fN1moCypJqb72OZvd)
				ARiQLVuwZY2nqCB5tv9mbe31f6 = True
	if ARiQLVuwZY2nqCB5tv9mbe31f6:
		items = sBvufaD6c9YHdOqTjCQ3.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,JJM6TofH4g5n7SRwq in items:
			url = vxQUXEuH9m + RMC6c2kL5hGOnFaIwAyb
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+JJM6TofH4g5n7SRwq,url,11)
	return
def oB2rmVgqUND(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,True,'ALARAB-EPISODES-1st')
	SpE2b6aJIGz8HAfmkFDrgvWhedCKuP = sBvufaD6c9YHdOqTjCQ3.findall('href="(/series.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+SpE2b6aJIGz8HAfmkFDrgvWhedCKuP[0]
	W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m = []
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,True,'ALARAB-PLAY-1st')
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('class="resp-iframe" src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Kj0TOU6BmSMlJHZYLd:
		Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[0]
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('^(http.*?)(http.*?)$',Kj0TOU6BmSMlJHZYLd,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if rsBojxT8UZwL:
			JwNdW5ulnaVBmKPCijI4tHFEf39R = rsBojxT8UZwL[0][0]
			SYe6C904pkvNF7MQi,L95a7iGDRwhMIAbk4q = rsBojxT8UZwL[0][1].rsplit('/',1)
			NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = SYe6C904pkvNF7MQi+'?named=__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
			mQx10f2SaKD = JwNdW5ulnaVBmKPCijI4tHFEf39R+L95a7iGDRwhMIAbk4q
		else:
			BhxM1UVjtbEoSp640kIcag = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,False,'ALARAB-PLAY-2nd')
			Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('"src": "(.*?)"',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if Kj0TOU6BmSMlJHZYLd:
				Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[0]+'?named=__watch__m3u8'
				ldFqnNIsftrY43JBM6LPjzU8m.append(Kj0TOU6BmSMlJHZYLd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('searchBox(.*?)<style>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if Kj0TOU6BmSMlJHZYLd:
			Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[0]+'?named=__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(Kj0TOU6BmSMlJHZYLd)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def YMFClcmbrx3i8():
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,True,'ALARAB-RAMADAN-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="content_sec"(.*?)id="left_content"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	W1Ip0MQijrEZNfCJgcA4onwvszy = sBvufaD6c9YHdOqTjCQ3.findall('/ramadan([0-9]+)/',str(items),sBvufaD6c9YHdOqTjCQ3.DOTALL)
	W1Ip0MQijrEZNfCJgcA4onwvszy = W1Ip0MQijrEZNfCJgcA4onwvszy[0]
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		url = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
		title = title.strip(hT7zFDpEyUqf8sXuN)+hT7zFDpEyUqf8sXuN+W1Ip0MQijrEZNfCJgcA4onwvszy
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,11)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m + "/q/" + VIo6FYRkx0MLP4wufEGsgnz9
	W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	return
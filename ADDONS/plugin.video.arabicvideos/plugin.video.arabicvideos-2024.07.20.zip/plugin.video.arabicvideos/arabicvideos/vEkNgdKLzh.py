# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'RANDOMS'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_LST_'
ecuN3vGB5hMrK = 4
K2Vsh1Rca0MYH6vBj5J = 10
def YnMSWTbKj1N8wuRJVF(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,url,d8kolNVuLsPAjQZ9ROpUHBgix,JJM6TofH4g5n7SRwq,zHTPjrSgp8Zcbf):
	try: bnfEyUuXgk7GV9LjO81KNxrdDPzZ = str(zHTPjrSgp8Zcbf['folder'])
	except: bnfEyUuXgk7GV9LjO81KNxrdDPzZ = QigevCplXxbPI1H
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==160: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==161: W9lfsoMawqOzpQcXD = Spqt1wyZMKFuH(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==162: W9lfsoMawqOzpQcXD = CCQyIrD0bjnlxZh8(d8kolNVuLsPAjQZ9ROpUHBgix,162)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==163: W9lfsoMawqOzpQcXD = CCQyIrD0bjnlxZh8(d8kolNVuLsPAjQZ9ROpUHBgix,163)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==164: W9lfsoMawqOzpQcXD = qDHhMIrXnTKA(d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==165: W9lfsoMawqOzpQcXD = wz17IEWn5qe2(url,d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==166: W9lfsoMawqOzpQcXD = cpP0F5CrNes1(url,d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==167: W9lfsoMawqOzpQcXD = C3Cgf1TPLNSoxDOeAqpbv(url,d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==168: W9lfsoMawqOzpQcXD = a7a4pIsmYv8Dx(url,d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==761: W9lfsoMawqOzpQcXD = dY6gtEzCKkeiq5pha()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==762: W9lfsoMawqOzpQcXD = fGBwgJyYps()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==763: W9lfsoMawqOzpQcXD = b1ClydWzfUv(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,d8kolNVuLsPAjQZ9ROpUHBgix,JJM6TofH4g5n7SRwq)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==764: W9lfsoMawqOzpQcXD = WZkPONMHYp53EG7Ddth8fK(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==765: W9lfsoMawqOzpQcXD = N7nZjqxzmEi3Ps2wd8bUOu4GIBTF(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,d8kolNVuLsPAjQZ9ROpUHBgix)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قنوات تلفزيون عشوائية',QigevCplXxbPI1H,161,QigevCplXxbPI1H,QigevCplXxbPI1H,'_LIVETV__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قسم عشوائي',QigevCplXxbPI1H,162,QigevCplXxbPI1H,QigevCplXxbPI1H,'_SITES__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات عشوائية',QigevCplXxbPI1H,163,QigevCplXxbPI1H,QigevCplXxbPI1H,'_SITES__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات بحث عشوائي',QigevCplXxbPI1H,164,QigevCplXxbPI1H,QigevCplXxbPI1H,'_SITES__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات عشوائية من قسم',QigevCplXxbPI1H,763,QigevCplXxbPI1H,QigevCplXxbPI1H,'_SITES__RANDOM_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قنوات M3U عشوائية',QigevCplXxbPI1H,163,QigevCplXxbPI1H,QigevCplXxbPI1H,'_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات M3U عشوائية',QigevCplXxbPI1H,163,QigevCplXxbPI1H,QigevCplXxbPI1H,'_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قسم قنوات M3U عشوائي',QigevCplXxbPI1H,162,QigevCplXxbPI1H,QigevCplXxbPI1H,'_M3U__LIVE__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قسم فيديو M3U عشوائي',QigevCplXxbPI1H,162,QigevCplXxbPI1H,QigevCplXxbPI1H,'_M3U__VOD__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات M3U بحث عشوائي',QigevCplXxbPI1H,164,QigevCplXxbPI1H,QigevCplXxbPI1H,'_M3U__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات M3U عشوائية من قسم',QigevCplXxbPI1H,765,QigevCplXxbPI1H,QigevCplXxbPI1H,'_M3U__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قنوات IPTV عشوائية',QigevCplXxbPI1H,163,QigevCplXxbPI1H,QigevCplXxbPI1H,'_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات IPTV عشوائية',QigevCplXxbPI1H,163,QigevCplXxbPI1H,QigevCplXxbPI1H,'_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قسم قنوات IPTV عشوائي',QigevCplXxbPI1H,162,QigevCplXxbPI1H,QigevCplXxbPI1H,'_IPTV__LIVE__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','قسم فيديو IPTV عشوائي',QigevCplXxbPI1H,162,QigevCplXxbPI1H,QigevCplXxbPI1H,'_IPTV__VOD__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات IPTV بحث عشوائي',QigevCplXxbPI1H,164,QigevCplXxbPI1H,QigevCplXxbPI1H,'_IPTV__RANDOM__REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','فيديوهات IPTV عشوائية من قسم',QigevCplXxbPI1H,764,QigevCplXxbPI1H,QigevCplXxbPI1H,'_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def dY6gtEzCKkeiq5pha():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_IPT_'+'فيديوهات جميع IPTV',QigevCplXxbPI1H,764)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
		iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_IP'+str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ)+'_'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' فيديوهات مجلد '+qqfVzPxYZ5R[bnfEyUuXgk7GV9LjO81KNxrdDPzZ],QigevCplXxbPI1H,764,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':bnfEyUuXgk7GV9LjO81KNxrdDPzZ})
	return
def fGBwgJyYps():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_M3U_'+'فيديوهات جميع M3U',QigevCplXxbPI1H,765)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
		iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_MU'+str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ)+'_'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' فيديوهات مجلد '+qqfVzPxYZ5R[bnfEyUuXgk7GV9LjO81KNxrdDPzZ],QigevCplXxbPI1H,765,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':bnfEyUuXgk7GV9LjO81KNxrdDPzZ})
	return
def d2IM6apcA8vLK3X(c1Ifu0OGV2kyRwLPWlsho8Ct6nz):
	global eFdHJ7McxZj,f9HGmKT0F1Pi3OkVdUjJRozx
	CNdL1jR9m2AWpBV4PKitDhnx5qw,srPjEeQn5UkWDfKm,Ej3yCdX0csTKgrwlvqm2nBPZz8If = nBYW0gcOpt7HyfU(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
	try:
		if 'IFILM' in c1Ifu0OGV2kyRwLPWlsho8Ct6nz: CNdL1jR9m2AWpBV4PKitDhnx5qw(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
		else: CNdL1jR9m2AWpBV4PKitDhnx5qw()
		IcwRCgmq3UtPdz1ykx9D07BL = False
	except:
		L5C2adJcDkS0e()
		IcwRCgmq3UtPdz1ykx9D07BL = True
	c1Ifu0OGV2kyRwLPWlsho8Ct6nz = aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
	if IcwRCgmq3UtPdz1ykx9D07BL:
		X69Fkr1VNnf2pJQC8wl7YR4HmaKc(c1Ifu0OGV2kyRwLPWlsho8Ct6nz,'فشل للأسف',B3TKLo71hAGRqYgV0=2000)
		eFdHJ7McxZj += 1
		f9HGmKT0F1Pi3OkVdUjJRozx += hT7zFDpEyUqf8sXuN+c1Ifu0OGV2kyRwLPWlsho8Ct6nz
	else: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(c1Ifu0OGV2kyRwLPWlsho8Ct6nz,QigevCplXxbPI1H,B3TKLo71hAGRqYgV0=1000)
	return
def eeIdF5nxslS1ROXDKhUYHP0Ga(KXyt2GpRL67NkToaBA=True):
	global eFdHJ7McxZj,f9HGmKT0F1Pi3OkVdUjJRozx
	if not KXyt2GpRL67NkToaBA:
		global MGNnlD6YCcemWAuhkL
		W9lfsoMawqOzpQcXD = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if W9lfsoMawqOzpQcXD:
			MGNnlD6YCcemWAuhkL = W9lfsoMawqOzpQcXD
			return
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if nndcv6tehuoKPpI!=1: return
	Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(False,False,False)
	bENBHsYoGjVfqX3nw9SD6LKuiJIa = lc0jJQ4zboeDI3tqTrpvm5gZO
	eFdHJ7McxZj,f9HGmKT0F1Pi3OkVdUjJRozx,threads = 0,QigevCplXxbPI1H,{}
	for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in uuHQdnTvybc9oEzaq81BLNFMhm:
		B3TKLo71hAGRqYgV0.sleep(0.75)
		threads[c1Ifu0OGV2kyRwLPWlsho8Ct6nz] = VVGXMeyJq25S6tf.Thread(target=d2IM6apcA8vLK3X,args=(c1Ifu0OGV2kyRwLPWlsho8Ct6nz,))
		threads[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].start()
		if eFdHJ7McxZj>=K2Vsh1Rca0MYH6vBj5J: break
	else:
		for c1Ifu0OGV2kyRwLPWlsho8Ct6nz in list(threads.keys()):
			threads[c1Ifu0OGV2kyRwLPWlsho8Ct6nz].join()
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = bENBHsYoGjVfqX3nw9SD6LKuiJIa
	if eFdHJ7McxZj>=K2Vsh1Rca0MYH6vBj5J: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','لديك مشكلة في '+str(eFdHJ7McxZj)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+f9HGmKT0F1Pi3OkVdUjJRozx)
	else:
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'SECTIONS_SITES','SECTIONS_SITES_ALL',MGNnlD6YCcemWAuhkL,xfdjCmFwb0k8JAVegiL)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)
	ksV5ngvbcaS8ByMLYxlfXh()
	return
def PUS9D4oelzQbiXLAc0TxBFO2mG(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx):
	ouzBYNFqJn9fbP1y = False
	doKBx5kz19q7tf8RUAc = lc0jJQ4zboeDI3tqTrpvm5gZO
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
	if ouzBYNFqJn9fbP1y and '_CREATENEW_' not in ccKJQrzh9DnNO3jx:
		W9lfsoMawqOzpQcXD = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+bnfEyUuXgk7GV9LjO81KNxrdDPzZ)
	elif '_LIVE_' not in ccKJQrzh9DnNO3jx or '_VOD_' not in ccKJQrzh9DnNO3jx:
		import WnaUtzx70u
		nDRKguWex0iVN8 = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in ccKJQrzh9DnNO3jx:
			try: WnaUtzx70u.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'VOD_UNKNOWN_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـIPTV للفيديوهات',nDRKguWex0iVN8)
			try: WnaUtzx70u.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'VOD_MOVIES_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـIPTV للفيديوهات',nDRKguWex0iVN8)
			try: WnaUtzx70u.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'VOD_SERIES_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـIPTV للفيديوهات',nDRKguWex0iVN8)
		if '_VOD_' not in ccKJQrzh9DnNO3jx:
			try: WnaUtzx70u.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'LIVE_UNKNOWN_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـIPTV للقنوات',nDRKguWex0iVN8)
			try: WnaUtzx70u.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'LIVE_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـIPTV للقنوات',nDRKguWex0iVN8)
		W9lfsoMawqOzpQcXD = lc0jJQ4zboeDI3tqTrpvm5gZO
		if ouzBYNFqJn9fbP1y: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'SECTIONS_IPTV','SECTIONS_IPTV_'+bnfEyUuXgk7GV9LjO81KNxrdDPzZ,W9lfsoMawqOzpQcXD,xfdjCmFwb0k8JAVegiL)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc
	return W9lfsoMawqOzpQcXD
def a7kC0JSiNjhF8(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx):
	ouzBYNFqJn9fbP1y = False
	doKBx5kz19q7tf8RUAc = lc0jJQ4zboeDI3tqTrpvm5gZO
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
	if ouzBYNFqJn9fbP1y and '_CREATENEW_' not in ccKJQrzh9DnNO3jx:
		W9lfsoMawqOzpQcXD = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','SECTIONS_M3U','SECTIONS_M3U_'+bnfEyUuXgk7GV9LjO81KNxrdDPzZ)
	elif '_LIVE_' not in ccKJQrzh9DnNO3jx or '_VOD_' not in ccKJQrzh9DnNO3jx:
		import BGdPH3ey27
		nDRKguWex0iVN8 = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in ccKJQrzh9DnNO3jx:
			try: BGdPH3ey27.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'VOD_UNKNOWN_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـM3U للفيديوهات',nDRKguWex0iVN8)
			try: BGdPH3ey27.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'VOD_MOVIES_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـM3U للفيديوهات',nDRKguWex0iVN8)
			try: BGdPH3ey27.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'VOD_SERIES_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـM3U للفيديوهات',nDRKguWex0iVN8)
		if '_VOD_' not in ccKJQrzh9DnNO3jx:
			try: BGdPH3ey27.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'LIVE_UNKNOWN_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـM3U للقنوات',nDRKguWex0iVN8)
			try: BGdPH3ey27.uLBdfExXvZnPw2gpNOjRt8yQi(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,'LIVE_GROUPED_SORTED',QigevCplXxbPI1H,QigevCplXxbPI1H,ccKJQrzh9DnNO3jx+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع ـM3U للقنوات',nDRKguWex0iVN8)
		W9lfsoMawqOzpQcXD = lc0jJQ4zboeDI3tqTrpvm5gZO
		if ouzBYNFqJn9fbP1y: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'SECTIONS_M3U','SECTIONS_M3U_'+bnfEyUuXgk7GV9LjO81KNxrdDPzZ,W9lfsoMawqOzpQcXD,xfdjCmFwb0k8JAVegiL)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc
	return W9lfsoMawqOzpQcXD
def b1ClydWzfUv(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx,RUqyx4EFsQtIDPg3zOuB5avlkV1jb):
	if '_CREATENEW_' in ccKJQrzh9DnNO3jx and RUqyx4EFsQtIDPg3zOuB5avlkV1jb==QigevCplXxbPI1H: eeIdF5nxslS1ROXDKhUYHP0Ga(True)
	elif RUqyx4EFsQtIDPg3zOuB5avlkV1jb: eeIdF5nxslS1ROXDKhUYHP0Ga(False)
	F9f6HYcRotrjQTuJ31gKZnp = ccKJQrzh9DnNO3jx.replace('_CREATENEW_',QigevCplXxbPI1H).replace('_FORGETRESULTS_',QigevCplXxbPI1H).replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	if not RUqyx4EFsQtIDPg3zOuB5avlkV1jb:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','تحديث هذه القائمة',QigevCplXxbPI1H,763,QigevCplXxbPI1H,QigevCplXxbPI1H,'_CREATENEW_'+F9f6HYcRotrjQTuJ31gKZnp,QigevCplXxbPI1H,{'folder':bnfEyUuXgk7GV9LjO81KNxrdDPzZ})
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	Z8O95QXEfjdcWgp = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	a2Ji6Puzs3 = ['افلام','movie','فيلم','فلم']
	z8N3PlXtp5U1hCa = ['مسلسل','series']
	qqW2QHgVFR3I = ['مسارح','مسرحيات']
	MMu2A5cBC7EHlkeRP = ['برامج','show','تلفزيون','تليفزيون']
	HcFzO6khrU4e0Cn2f1NMG3 = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	YMFClcmbrx3i8 = ['رمضان']
	MWRoOhZwE6FeD7GuJ4bylU2Tg = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	NydR53a7DsuQA8BjCcXIfPT4Krv2 = ['سلاسل','سلسله']
	pABOuy4mDY79fIMCr0WgS3twaxc = ['اغاني','موسيقى','كليب','حفل','music']
	AZaidso3QULERMHG7Jtx = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	y3eu8nTDhLxpfBtUFW = ['الان','حالي','مثبت','رائج']
	NNQhKp3Pb5zOFHADru = ['ضحك','كوميدي']
	JaVWnSgE92X0Cfm4e6OubHyo51lGvN = ['رياضه','كوره','مصارعه','شوت','رياضة']
	qq7iOcNeKPDCHrf5R03Ta4ok = ['نيتفلكس','netflix','نيتفليكس']
	eMH7p6EiVqfDQFvUh4xN8R = ['ممثلين','اشخاص','نجوم']
	NuF8RLt0WonUPObjBdYXm4Dfa = ['بث حي','live','قناه','قنوات']
	ayzl0TpW7gnQtxLjVvrh2N43Pde = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	vC7h9wyotxsm = ['19','20','21','22','23','24','25','26']
	if not RUqyx4EFsQtIDPg3zOuB5avlkV1jb:
		RUqyx4EFsQtIDPg3zOuB5avlkV1jb = 0
		for dpUuvw1lSFGgJe in Z8O95QXEfjdcWgp:
			RUqyx4EFsQtIDPg3zOuB5avlkV1jb += 1
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+dpUuvw1lSFGgJe,QigevCplXxbPI1H,763,QigevCplXxbPI1H,str(RUqyx4EFsQtIDPg3zOuB5avlkV1jb),F9f6HYcRotrjQTuJ31gKZnp,QigevCplXxbPI1H,{'folder':bnfEyUuXgk7GV9LjO81KNxrdDPzZ})
	else:
		for zsj5qOxnfaXmdEco3DK29HgYybUCM6 in sorted(list(MGNnlD6YCcemWAuhkL.keys())):
			BazW8QlSDmdsZrhXNAjPEo0 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.lower()
			opIyA9rsJMXPL1k = []
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in a2Ji6Puzs3): opIyA9rsJMXPL1k.append(1)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in z8N3PlXtp5U1hCa): opIyA9rsJMXPL1k.append(2)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in qqW2QHgVFR3I): opIyA9rsJMXPL1k.append(3)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in MMu2A5cBC7EHlkeRP): opIyA9rsJMXPL1k.append(4)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in HcFzO6khrU4e0Cn2f1NMG3): opIyA9rsJMXPL1k.append(5)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in YMFClcmbrx3i8): opIyA9rsJMXPL1k.append(6)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in MWRoOhZwE6FeD7GuJ4bylU2Tg) and BazW8QlSDmdsZrhXNAjPEo0 not in ['اخرى']: opIyA9rsJMXPL1k.append(7)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in NydR53a7DsuQA8BjCcXIfPT4Krv2): opIyA9rsJMXPL1k.append(8)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in pABOuy4mDY79fIMCr0WgS3twaxc): opIyA9rsJMXPL1k.append(9)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in AZaidso3QULERMHG7Jtx): opIyA9rsJMXPL1k.append(10)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in y3eu8nTDhLxpfBtUFW): opIyA9rsJMXPL1k.append(11)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in NNQhKp3Pb5zOFHADru): opIyA9rsJMXPL1k.append(12)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in JaVWnSgE92X0Cfm4e6OubHyo51lGvN): opIyA9rsJMXPL1k.append(13)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in qq7iOcNeKPDCHrf5R03Ta4ok): opIyA9rsJMXPL1k.append(14)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in eMH7p6EiVqfDQFvUh4xN8R): opIyA9rsJMXPL1k.append(15)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in NuF8RLt0WonUPObjBdYXm4Dfa): opIyA9rsJMXPL1k.append(16)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in ayzl0TpW7gnQtxLjVvrh2N43Pde): opIyA9rsJMXPL1k.append(17)
			if any(nFdGHjceZzW in BazW8QlSDmdsZrhXNAjPEo0 for nFdGHjceZzW in vC7h9wyotxsm): opIyA9rsJMXPL1k.append(18)
			if not opIyA9rsJMXPL1k: opIyA9rsJMXPL1k = [19]
			for WD7JIEFhAfP3O0 in opIyA9rsJMXPL1k:
				if str(WD7JIEFhAfP3O0)==RUqyx4EFsQtIDPg3zOuB5avlkV1jb:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+zsj5qOxnfaXmdEco3DK29HgYybUCM6,zsj5qOxnfaXmdEco3DK29HgYybUCM6,166,QigevCplXxbPI1H,QigevCplXxbPI1H,F9f6HYcRotrjQTuJ31gKZnp+'_REMEMBERRESULTS_')
	return
def WZkPONMHYp53EG7Ddth8fK(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx):
	ouzBYNFqJn9fbP1y = False
	if ouzBYNFqJn9fbP1y:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','تحديث هذه القائمة',QigevCplXxbPI1H,764,QigevCplXxbPI1H,QigevCplXxbPI1H,'_CREATENEW_',QigevCplXxbPI1H,{'folder':bnfEyUuXgk7GV9LjO81KNxrdDPzZ})
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	doKBx5kz19q7tf8RUAc = lc0jJQ4zboeDI3tqTrpvm5gZO[:]
	import WnaUtzx70u
	if bnfEyUuXgk7GV9LjO81KNxrdDPzZ:
		if not WnaUtzx70u.pQW09CG5Fojk4i(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,True): return
		bXsQoACg82YKvMjOxIB = PUS9D4oelzQbiXLAc0TxBFO2mG(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx)
		rjlBpomcFhUsDGY423A9 = sorted(bXsQoACg82YKvMjOxIB,reverse=False,key=lambda key: key[1].lower())
	else:
		if not WnaUtzx70u.pQW09CG5Fojk4i(QigevCplXxbPI1H,True): return
		if ouzBYNFqJn9fbP1y and '_CREATENEW_' not in ccKJQrzh9DnNO3jx:
			rjlBpomcFhUsDGY423A9 = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			ffwZreq12SYK0jVFcmutxEbXCNnI,rjlBpomcFhUsDGY423A9,bXsQoACg82YKvMjOxIB = [],[],[]
			for g094iokuKC in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
				rjlBpomcFhUsDGY423A9 += PUS9D4oelzQbiXLAc0TxBFO2mG(str(g094iokuKC),ccKJQrzh9DnNO3jx)
			for type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in rjlBpomcFhUsDGY423A9:
				if d8kolNVuLsPAjQZ9ROpUHBgix not in ffwZreq12SYK0jVFcmutxEbXCNnI:
					ffwZreq12SYK0jVFcmutxEbXCNnI.append(d8kolNVuLsPAjQZ9ROpUHBgix)
					aW1dxYEGwHzDAOZfKhqRC = type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,d8kolNVuLsPAjQZ9ROpUHBgix,165,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,ccKJQrzh9DnNO3jx,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf
					bXsQoACg82YKvMjOxIB.append(aW1dxYEGwHzDAOZfKhqRC)
			rjlBpomcFhUsDGY423A9 = sorted(bXsQoACg82YKvMjOxIB,reverse=False,key=lambda key: key[1].lower())
			if ouzBYNFqJn9fbP1y: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',rjlBpomcFhUsDGY423A9,xfdjCmFwb0k8JAVegiL)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc+rjlBpomcFhUsDGY423A9
	ksV5ngvbcaS8ByMLYxlfXh(False)
	return
def N7nZjqxzmEi3Ps2wd8bUOu4GIBTF(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx):
	ouzBYNFqJn9fbP1y = False
	if ouzBYNFqJn9fbP1y:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','تحديث هذه القائمة',QigevCplXxbPI1H,765,QigevCplXxbPI1H,QigevCplXxbPI1H,'_CREATENEW_',QigevCplXxbPI1H,{'folder':bnfEyUuXgk7GV9LjO81KNxrdDPzZ})
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	doKBx5kz19q7tf8RUAc = lc0jJQ4zboeDI3tqTrpvm5gZO[:]
	import BGdPH3ey27
	if bnfEyUuXgk7GV9LjO81KNxrdDPzZ:
		if not BGdPH3ey27.pQW09CG5Fojk4i(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,True): return
		bXsQoACg82YKvMjOxIB = a7kC0JSiNjhF8(bnfEyUuXgk7GV9LjO81KNxrdDPzZ,ccKJQrzh9DnNO3jx)
		rjlBpomcFhUsDGY423A9 = sorted(bXsQoACg82YKvMjOxIB,reverse=False,key=lambda key: key[1].lower())
	else:
		if not BGdPH3ey27.pQW09CG5Fojk4i(QigevCplXxbPI1H,True): return
		if ouzBYNFqJn9fbP1y and '_CREATENEW_' not in ccKJQrzh9DnNO3jx:
			rjlBpomcFhUsDGY423A9 = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			ffwZreq12SYK0jVFcmutxEbXCNnI,rjlBpomcFhUsDGY423A9,bXsQoACg82YKvMjOxIB = [],[],[]
			for g094iokuKC in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
				rjlBpomcFhUsDGY423A9 += a7kC0JSiNjhF8(str(g094iokuKC),ccKJQrzh9DnNO3jx)
			for type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in rjlBpomcFhUsDGY423A9:
				if d8kolNVuLsPAjQZ9ROpUHBgix not in ffwZreq12SYK0jVFcmutxEbXCNnI:
					ffwZreq12SYK0jVFcmutxEbXCNnI.append(d8kolNVuLsPAjQZ9ROpUHBgix)
					aW1dxYEGwHzDAOZfKhqRC = type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,d8kolNVuLsPAjQZ9ROpUHBgix,165,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,ccKJQrzh9DnNO3jx,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf
					bXsQoACg82YKvMjOxIB.append(aW1dxYEGwHzDAOZfKhqRC)
			rjlBpomcFhUsDGY423A9 = sorted(bXsQoACg82YKvMjOxIB,reverse=False,key=lambda key: key[1].lower())
			if ouzBYNFqJn9fbP1y: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'SECTIONS_M3U','SECTIONS_M3U_ALL',rjlBpomcFhUsDGY423A9,xfdjCmFwb0k8JAVegiL)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc+rjlBpomcFhUsDGY423A9
	ksV5ngvbcaS8ByMLYxlfXh(False)
	return
def wz17IEWn5qe2(group,ccKJQrzh9DnNO3jx):
	ouzBYNFqJn9fbP1y = False
	W9lfsoMawqOzpQcXD = []
	DBShyJqpxNuEn = '_IPTV_' if 'IPTV' in ccKJQrzh9DnNO3jx else '_M3U_'
	if ouzBYNFqJn9fbP1y: W9lfsoMawqOzpQcXD = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','SECTIONS'+DBShyJqpxNuEn[:-1],group)
	if not W9lfsoMawqOzpQcXD:
		for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
			if ouzBYNFqJn9fbP1y: W9lfsoMawqOzpQcXD += wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','SECTIONS'+DBShyJqpxNuEn[:-1],'SECTIONS'+DBShyJqpxNuEn+str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ))
			elif DBShyJqpxNuEn=='_IPTV_': W9lfsoMawqOzpQcXD += PUS9D4oelzQbiXLAc0TxBFO2mG(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),'_CREATENEW_')
			elif DBShyJqpxNuEn=='_M3U_': W9lfsoMawqOzpQcXD += a7kC0JSiNjhF8(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),'_CREATENEW_')
		for type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in W9lfsoMawqOzpQcXD:
			if d8kolNVuLsPAjQZ9ROpUHBgix==group: tZd9HYuJBf0SUegwOcWbz8FoaipLQm(type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
		items,WWcSoXlyFCIzMGpxr = [],[]
		for type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in lc0jJQ4zboeDI3tqTrpvm5gZO:
			R8snCkJV7Gm5T9XDlKAhgL = type,zsj5qOxnfaXmdEco3DK29HgYybUCM6[4:],url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,QigevCplXxbPI1H
			if R8snCkJV7Gm5T9XDlKAhgL not in WWcSoXlyFCIzMGpxr:
				WWcSoXlyFCIzMGpxr.append(R8snCkJV7Gm5T9XDlKAhgL)
				upHdVltvOIDPnN0SefZwGo4gJ9LqsY = type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf
				items.append(upHdVltvOIDPnN0SefZwGo4gJ9LqsY)
		W9lfsoMawqOzpQcXD = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if ouzBYNFqJn9fbP1y: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'SECTIONS'+DBShyJqpxNuEn[:-1],group,W9lfsoMawqOzpQcXD,xfdjCmFwb0k8JAVegiL)
	if '_RANDOM_' in ccKJQrzh9DnNO3jx and len(W9lfsoMawqOzpQcXD)>ecuN3vGB5hMrK:
		lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','[[COLOR FFC89008]'+group+'[/COLOR] :القسم]',group,165,QigevCplXxbPI1H,QigevCplXxbPI1H,DBShyJqpxNuEn+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة الطلب العشوائي من نفس القسم',group,165,QigevCplXxbPI1H,QigevCplXxbPI1H,DBShyJqpxNuEn+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
		W9lfsoMawqOzpQcXD = lc0jJQ4zboeDI3tqTrpvm5gZO+yarjPEMGV6m7fHRFeJXt.sample(W9lfsoMawqOzpQcXD,ecuN3vGB5hMrK)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = W9lfsoMawqOzpQcXD
	ksV5ngvbcaS8ByMLYxlfXh(False)
	return
def Spqt1wyZMKFuH(ccKJQrzh9DnNO3jx):
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة طلب قنوات عشوائية',QigevCplXxbPI1H,161,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	Qd3mDMlcRgBIT4LU6ywW = lc0jJQ4zboeDI3tqTrpvm5gZO[:]
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
	import FgsvjTqQ1h
	FgsvjTqQ1h.PYViltfWah910OHUZeR('0',False)
	FgsvjTqQ1h.PYViltfWah910OHUZeR('1',False)
	FgsvjTqQ1h.PYViltfWah910OHUZeR('2',False)
	if '_RANDOM_' in ccKJQrzh9DnNO3jx:
		lc0jJQ4zboeDI3tqTrpvm5gZO[:] = KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO)
		if len(lc0jJQ4zboeDI3tqTrpvm5gZO)>ecuN3vGB5hMrK: lc0jJQ4zboeDI3tqTrpvm5gZO[:] = yarjPEMGV6m7fHRFeJXt.sample(lc0jJQ4zboeDI3tqTrpvm5gZO,ecuN3vGB5hMrK)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = Qd3mDMlcRgBIT4LU6ywW+lc0jJQ4zboeDI3tqTrpvm5gZO
	return
def qDHhMIrXnTKA(ccKJQrzh9DnNO3jx):
	ccKJQrzh9DnNO3jx = ccKJQrzh9DnNO3jx.replace('_FORGETRESULTS_',QigevCplXxbPI1H).replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	headers = { 'User-Agent' : QigevCplXxbPI1H }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = q8KvkirVNMoRIB5eJ(data)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vMlT137PE8q4wiKpWIojraR29B,'GET',url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="content"(.*?)class="clearfix"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	w845RV1UPfvHna9qijoK3kQcZyFNX,htsXZDjl5Ec4FIQHMA8TyB0azegYd = list(zip(*items))
	WWlzotM6p2sdiw1FKQYAhCgb987fH3 = []
	CyRLiIlz4utWVeGp62JDhq = [hT7zFDpEyUqf8sXuN,'"','`',',','.',':',';',"'",'-']
	Q9qVJFDtRnE8UuGHX2A6 = htsXZDjl5Ec4FIQHMA8TyB0azegYd+w845RV1UPfvHna9qijoK3kQcZyFNX
	for WWA2P3ONVb0jH4q1z8 in Q9qVJFDtRnE8UuGHX2A6:
		if WWA2P3ONVb0jH4q1z8 in htsXZDjl5Ec4FIQHMA8TyB0azegYd: tQzVkljfXEZH1NGJdMLRI5 = 2
		if WWA2P3ONVb0jH4q1z8 in w845RV1UPfvHna9qijoK3kQcZyFNX: tQzVkljfXEZH1NGJdMLRI5 = 4
		GCtUpIPsefoDqv = [A5SjhJUg37pNiMC4Eot6lOF in WWA2P3ONVb0jH4q1z8 for A5SjhJUg37pNiMC4Eot6lOF in CyRLiIlz4utWVeGp62JDhq]
		if any(GCtUpIPsefoDqv):
			nVWUleSBvsKaEhoCxNryf = GCtUpIPsefoDqv.index(True)
			LCHgrfobVEvu2pBI10Tl9 = CyRLiIlz4utWVeGp62JDhq[nVWUleSBvsKaEhoCxNryf]
			cmWJVZ0F6GgO4oy2x7p9BsuYL = QigevCplXxbPI1H
			if WWA2P3ONVb0jH4q1z8.count(LCHgrfobVEvu2pBI10Tl9)>1: QnaE5rhUJivYC70TWN4GeRy13,FF8LtjzCXASmBynHsilEwNb0uK7YU,cmWJVZ0F6GgO4oy2x7p9BsuYL = WWA2P3ONVb0jH4q1z8.split(LCHgrfobVEvu2pBI10Tl9,2)
			else: QnaE5rhUJivYC70TWN4GeRy13,FF8LtjzCXASmBynHsilEwNb0uK7YU = WWA2P3ONVb0jH4q1z8.split(LCHgrfobVEvu2pBI10Tl9,1)
			if len(QnaE5rhUJivYC70TWN4GeRy13)>tQzVkljfXEZH1NGJdMLRI5: WWlzotM6p2sdiw1FKQYAhCgb987fH3.append(QnaE5rhUJivYC70TWN4GeRy13.lower())
			if len(FF8LtjzCXASmBynHsilEwNb0uK7YU)>tQzVkljfXEZH1NGJdMLRI5: WWlzotM6p2sdiw1FKQYAhCgb987fH3.append(FF8LtjzCXASmBynHsilEwNb0uK7YU.lower())
			if len(cmWJVZ0F6GgO4oy2x7p9BsuYL)>tQzVkljfXEZH1NGJdMLRI5: WWlzotM6p2sdiw1FKQYAhCgb987fH3.append(cmWJVZ0F6GgO4oy2x7p9BsuYL.lower())
		elif len(WWA2P3ONVb0jH4q1z8)>tQzVkljfXEZH1NGJdMLRI5: WWlzotM6p2sdiw1FKQYAhCgb987fH3.append(WWA2P3ONVb0jH4q1z8.lower())
	for A5SjhJUg37pNiMC4Eot6lOF in range(9): yarjPEMGV6m7fHRFeJXt.shuffle(WWlzotM6p2sdiw1FKQYAhCgb987fH3)
	if '_SITES_' in ccKJQrzh9DnNO3jx:
		DDXP7vuGpd = zfE9YjC6MTa8
	elif '_IPTV_' in ccKJQrzh9DnNO3jx:
		DDXP7vuGpd = ['IPTV']
		import WnaUtzx70u
		if not WnaUtzx70u.pQW09CG5Fojk4i(QigevCplXxbPI1H,True): return
	elif '_M3U_' in ccKJQrzh9DnNO3jx:
		DDXP7vuGpd = ['M3U']
		import BGdPH3ey27
		if not BGdPH3ey27.pQW09CG5Fojk4i(QigevCplXxbPI1H,True): return
	count,oKSM47UczN8OZxVuJftFgH0ALD = 0,0
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','[  ] :البحث عن',QigevCplXxbPI1H,164,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+ccKJQrzh9DnNO3jx)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة البحث العشوائي',QigevCplXxbPI1H,164,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+ccKJQrzh9DnNO3jx)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	Z7HqiRDgV2m9vW = lc0jJQ4zboeDI3tqTrpvm5gZO[:]
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
	yd7LuIKcp4S5 = []
	for WWA2P3ONVb0jH4q1z8 in WWlzotM6p2sdiw1FKQYAhCgb987fH3:
		FF8LtjzCXASmBynHsilEwNb0uK7YU = sBvufaD6c9YHdOqTjCQ3.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',WWA2P3ONVb0jH4q1z8,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if FF8LtjzCXASmBynHsilEwNb0uK7YU: WWA2P3ONVb0jH4q1z8 = WWA2P3ONVb0jH4q1z8.split(FF8LtjzCXASmBynHsilEwNb0uK7YU[0],1)[0]
		E5E39KyIJHie2 = WWA2P3ONVb0jH4q1z8.replace('ّ',QigevCplXxbPI1H).replace('َ',QigevCplXxbPI1H).replace('ً',QigevCplXxbPI1H).replace('ُ',QigevCplXxbPI1H).replace('ٌ',QigevCplXxbPI1H)
		E5E39KyIJHie2 = E5E39KyIJHie2.replace('ِ',QigevCplXxbPI1H).replace('ٍ',QigevCplXxbPI1H).replace('ْ',QigevCplXxbPI1H).replace('،',QigevCplXxbPI1H).replace('ـ',QigevCplXxbPI1H)
		if E5E39KyIJHie2: yd7LuIKcp4S5.append(E5E39KyIJHie2)
	OuD9xiUh45M2AgCIBQjmlrTPJyc = []
	for GzabfJx3T1 in range(0,20):
		search = yarjPEMGV6m7fHRFeJXt.sample(yd7LuIKcp4S5,1)[0]
		if search in OuD9xiUh45M2AgCIBQjmlrTPJyc: continue
		OuD9xiUh45M2AgCIBQjmlrTPJyc.append(search)
		c1Ifu0OGV2kyRwLPWlsho8Ct6nz = yarjPEMGV6m7fHRFeJXt.sample(DDXP7vuGpd,1)[0]
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Random Video Search   site:'+str(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)+'  search:'+search)
		CNdL1jR9m2AWpBV4PKitDhnx5qw,srPjEeQn5UkWDfKm,Ej3yCdX0csTKgrwlvqm2nBPZz8If = nBYW0gcOpt7HyfU(c1Ifu0OGV2kyRwLPWlsho8Ct6nz)
		srPjEeQn5UkWDfKm(search+'_NODIALOGS_')
		if len(lc0jJQ4zboeDI3tqTrpvm5gZO)>0: break
	search = search.replace('_MOD_',QigevCplXxbPI1H)
	Z7HqiRDgV2m9vW[0][1] = '[[COLOR FFC89008]'+search+'[/COLOR] :بحث عن]'
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO)
	if len(lc0jJQ4zboeDI3tqTrpvm5gZO)>ecuN3vGB5hMrK: lc0jJQ4zboeDI3tqTrpvm5gZO[:] = yarjPEMGV6m7fHRFeJXt.sample(lc0jJQ4zboeDI3tqTrpvm5gZO,ecuN3vGB5hMrK)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = Z7HqiRDgV2m9vW+lc0jJQ4zboeDI3tqTrpvm5gZO
	return
def cpP0F5CrNes1(F8GID5mOXPJ3pK,ccKJQrzh9DnNO3jx):
	F8GID5mOXPJ3pK = F8GID5mOXPJ3pK.replace('_MOD_',QigevCplXxbPI1H)
	ccKJQrzh9DnNO3jx = ccKJQrzh9DnNO3jx.replace('_FORGETRESULTS_',QigevCplXxbPI1H).replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	eeIdF5nxslS1ROXDKhUYHP0Ga(False)
	if MGNnlD6YCcemWAuhkL=={}: return
	if '_RANDOM_' in ccKJQrzh9DnNO3jx:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','[[COLOR FFC89008]'+F8GID5mOXPJ3pK+'[/COLOR] :القسم]',F8GID5mOXPJ3pK,166,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+ccKJQrzh9DnNO3jx)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة الطلب العشوائي من نفس القسم',F8GID5mOXPJ3pK,166,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+ccKJQrzh9DnNO3jx)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	for website in sorted(list(MGNnlD6YCcemWAuhkL[F8GID5mOXPJ3pK].keys())):
		type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = MGNnlD6YCcemWAuhkL[F8GID5mOXPJ3pK][website]
		if '_RANDOM_' in ccKJQrzh9DnNO3jx or len(MGNnlD6YCcemWAuhkL[F8GID5mOXPJ3pK])==1:
			tZd9HYuJBf0SUegwOcWbz8FoaipLQm(type,QigevCplXxbPI1H,url,qLQisyBRkG5o1VxOnbCegD,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,QigevCplXxbPI1H)
			lc0jJQ4zboeDI3tqTrpvm5gZO[:] = KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO)
			doKBx5kz19q7tf8RUAc,rjlBpomcFhUsDGY423A9 = lc0jJQ4zboeDI3tqTrpvm5gZO[:3],lc0jJQ4zboeDI3tqTrpvm5gZO[3:]
			for A5SjhJUg37pNiMC4Eot6lOF in range(9): yarjPEMGV6m7fHRFeJXt.shuffle(rjlBpomcFhUsDGY423A9)
			if '_RANDOM_' in ccKJQrzh9DnNO3jx: lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc+rjlBpomcFhUsDGY423A9[:ecuN3vGB5hMrK]
			else: lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc+rjlBpomcFhUsDGY423A9
		elif '_SITES_' in ccKJQrzh9DnNO3jx: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',website,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
	return
def CCQyIrD0bjnlxZh8(ccKJQrzh9DnNO3jx,TsckNQJ6yLiaEeCRml98WwKfVP0dYv):
	ccKJQrzh9DnNO3jx = ccKJQrzh9DnNO3jx.replace('_FORGETRESULTS_',QigevCplXxbPI1H).replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	zsj5qOxnfaXmdEco3DK29HgYybUCM6,nazIjkLHhSc8PM75WxU2Fo = QigevCplXxbPI1H,[]
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','[[COLOR FFC89008]'+zsj5qOxnfaXmdEco3DK29HgYybUCM6+'[/COLOR] :القسم]',QigevCplXxbPI1H,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+ccKJQrzh9DnNO3jx)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة طلب قسم عشوائي',QigevCplXxbPI1H,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+ccKJQrzh9DnNO3jx)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	doKBx5kz19q7tf8RUAc = lc0jJQ4zboeDI3tqTrpvm5gZO[:]
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
	W9lfsoMawqOzpQcXD = []
	if '_SITES_' in ccKJQrzh9DnNO3jx:
		eeIdF5nxslS1ROXDKhUYHP0Ga(False)
		if MGNnlD6YCcemWAuhkL=={}: return
		f4dsNBt6K9GjF3gxOAnEQS2wLYrvu = list(MGNnlD6YCcemWAuhkL.keys())
		F8GID5mOXPJ3pK = yarjPEMGV6m7fHRFeJXt.sample(f4dsNBt6K9GjF3gxOAnEQS2wLYrvu,1)[0]
		WWlzotM6p2sdiw1FKQYAhCgb987fH3 = list(MGNnlD6YCcemWAuhkL[F8GID5mOXPJ3pK].keys())
		website = yarjPEMGV6m7fHRFeJXt.sample(WWlzotM6p2sdiw1FKQYAhCgb987fH3,1)[0]
		type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = MGNnlD6YCcemWAuhkL[F8GID5mOXPJ3pK][website]
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Random Category   website: '+website+'   name: '+zsj5qOxnfaXmdEco3DK29HgYybUCM6+'   url: '+url+'   mode: '+str(qLQisyBRkG5o1VxOnbCegD))
	elif '_IPTV_' in ccKJQrzh9DnNO3jx:
		import WnaUtzx70u
		if not WnaUtzx70u.pQW09CG5Fojk4i(QigevCplXxbPI1H,True): return
		for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
			W9lfsoMawqOzpQcXD += PUS9D4oelzQbiXLAc0TxBFO2mG(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),ccKJQrzh9DnNO3jx)
		if not W9lfsoMawqOzpQcXD: return
		type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = yarjPEMGV6m7fHRFeJXt.sample(W9lfsoMawqOzpQcXD,1)[0]
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Random Category   name: '+zsj5qOxnfaXmdEco3DK29HgYybUCM6+'   url: '+url+'   mode: '+str(qLQisyBRkG5o1VxOnbCegD))
	elif '_M3U_' in ccKJQrzh9DnNO3jx:
		import BGdPH3ey27
		if not BGdPH3ey27.pQW09CG5Fojk4i(QigevCplXxbPI1H,True): return
		for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
			W9lfsoMawqOzpQcXD += a7kC0JSiNjhF8(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),ccKJQrzh9DnNO3jx)
		if not W9lfsoMawqOzpQcXD: return
		type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = yarjPEMGV6m7fHRFeJXt.sample(W9lfsoMawqOzpQcXD,1)[0]
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Random Category   name: '+zsj5qOxnfaXmdEco3DK29HgYybUCM6+'   url: '+url+'   mode: '+str(qLQisyBRkG5o1VxOnbCegD))
	TTw9XPqlNCp8OmG52uzgA7cVUM = zsj5qOxnfaXmdEco3DK29HgYybUCM6
	oSHrFnqwXhP0pK = []
	for A5SjhJUg37pNiMC4Eot6lOF in range(0,10):
		if A5SjhJUg37pNiMC4Eot6lOF>0: SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   Random Category   name: '+zsj5qOxnfaXmdEco3DK29HgYybUCM6+'   url: '+url+'   mode: '+str(qLQisyBRkG5o1VxOnbCegD))
		lc0jJQ4zboeDI3tqTrpvm5gZO[:] = []
		if qLQisyBRkG5o1VxOnbCegD==234 and '__IPTVSeries__' in d8kolNVuLsPAjQZ9ROpUHBgix: qLQisyBRkG5o1VxOnbCegD = 233
		if qLQisyBRkG5o1VxOnbCegD==714 and '__M3USeries__' in d8kolNVuLsPAjQZ9ROpUHBgix: qLQisyBRkG5o1VxOnbCegD = 713
		if qLQisyBRkG5o1VxOnbCegD==144: qLQisyBRkG5o1VxOnbCegD = 291
		tX1WYGPmux = tZd9HYuJBf0SUegwOcWbz8FoaipLQm(type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf)
		if '_IPTV_' in ccKJQrzh9DnNO3jx and qLQisyBRkG5o1VxOnbCegD==167: del lc0jJQ4zboeDI3tqTrpvm5gZO[:3]
		if '_M3U_' in ccKJQrzh9DnNO3jx and qLQisyBRkG5o1VxOnbCegD==168: del lc0jJQ4zboeDI3tqTrpvm5gZO[:3]
		nazIjkLHhSc8PM75WxU2Fo[:] = KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO)
		if oSHrFnqwXhP0pK and Sk3BJ4bvyposwt0mFuGnqZHg(u'حلقة') in str(nazIjkLHhSc8PM75WxU2Fo) or Sk3BJ4bvyposwt0mFuGnqZHg(u'حلقه') in str(nazIjkLHhSc8PM75WxU2Fo):
			zsj5qOxnfaXmdEco3DK29HgYybUCM6 = TTw9XPqlNCp8OmG52uzgA7cVUM
			nazIjkLHhSc8PM75WxU2Fo[:] = oSHrFnqwXhP0pK
			break
		TTw9XPqlNCp8OmG52uzgA7cVUM = zsj5qOxnfaXmdEco3DK29HgYybUCM6
		oSHrFnqwXhP0pK = nazIjkLHhSc8PM75WxU2Fo
		if str(nazIjkLHhSc8PM75WxU2Fo).count('video')>0: break
		if str(nazIjkLHhSc8PM75WxU2Fo).count('live')>0: break
		if qLQisyBRkG5o1VxOnbCegD==233: break
		if qLQisyBRkG5o1VxOnbCegD==713: break
		if qLQisyBRkG5o1VxOnbCegD==291: break
		if nazIjkLHhSc8PM75WxU2Fo: type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,qLQisyBRkG5o1VxOnbCegD,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = yarjPEMGV6m7fHRFeJXt.sample(nazIjkLHhSc8PM75WxU2Fo,1)[0]
	if not zsj5qOxnfaXmdEco3DK29HgYybUCM6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = '....'
	elif zsj5qOxnfaXmdEco3DK29HgYybUCM6.count('_')>1: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.split('_',2)[2]
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace('UNKNOWN: ',QigevCplXxbPI1H)
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace('_MOD_',QigevCplXxbPI1H)
	doKBx5kz19q7tf8RUAc[0][1] = '[[COLOR FFC89008]'+zsj5qOxnfaXmdEco3DK29HgYybUCM6+'[/COLOR] :القسم]'
	for A5SjhJUg37pNiMC4Eot6lOF in range(9): yarjPEMGV6m7fHRFeJXt.shuffle(nazIjkLHhSc8PM75WxU2Fo)
	if '_RANDOM_' in ccKJQrzh9DnNO3jx: lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc+nazIjkLHhSc8PM75WxU2Fo[:ecuN3vGB5hMrK]
	else: lc0jJQ4zboeDI3tqTrpvm5gZO[:] = doKBx5kz19q7tf8RUAc+nazIjkLHhSc8PM75WxU2Fo
	return
def C3Cgf1TPLNSoxDOeAqpbv(aBgiKXClAdLWFq3YuVpS8fZ4z6,LM3EcSvGzJbe4):
	LM3EcSvGzJbe4 = LM3EcSvGzJbe4.replace('_FORGETRESULTS_',QigevCplXxbPI1H).replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	EEvpA4oBUtqfH07j6Kmrw8 = LM3EcSvGzJbe4
	if '__IPTVSeries__' in LM3EcSvGzJbe4:
		EEvpA4oBUtqfH07j6Kmrw8 = LM3EcSvGzJbe4.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in aBgiKXClAdLWFq3YuVpS8fZ4z6: type = ',VIDEOS: '
	elif 'LIVE' in aBgiKXClAdLWFq3YuVpS8fZ4z6: type = ',LIVE: '
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','[[COLOR FFC89008]'+type+EEvpA4oBUtqfH07j6Kmrw8+'[/COLOR] :القسم]',aBgiKXClAdLWFq3YuVpS8fZ4z6,167,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+LM3EcSvGzJbe4)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة الطلب العشوائي من نفس القسم',aBgiKXClAdLWFq3YuVpS8fZ4z6,167,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+LM3EcSvGzJbe4)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	import WnaUtzx70u
	for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
		if '__IPTVSeries__' in LM3EcSvGzJbe4: WnaUtzx70u.uLBdfExXvZnPw2gpNOjRt8yQi(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),aBgiKXClAdLWFq3YuVpS8fZ4z6,LM3EcSvGzJbe4,QigevCplXxbPI1H,False)
		else: WnaUtzx70u.PYViltfWah910OHUZeR(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),aBgiKXClAdLWFq3YuVpS8fZ4z6,LM3EcSvGzJbe4,QigevCplXxbPI1H,False)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO)
	if len(lc0jJQ4zboeDI3tqTrpvm5gZO)>(ecuN3vGB5hMrK+3): lc0jJQ4zboeDI3tqTrpvm5gZO[:] = lc0jJQ4zboeDI3tqTrpvm5gZO[:3]+yarjPEMGV6m7fHRFeJXt.sample(lc0jJQ4zboeDI3tqTrpvm5gZO[3:],ecuN3vGB5hMrK)
	return
def a7a4pIsmYv8Dx(aBgiKXClAdLWFq3YuVpS8fZ4z6,LM3EcSvGzJbe4):
	LM3EcSvGzJbe4 = LM3EcSvGzJbe4.replace('_FORGETRESULTS_',QigevCplXxbPI1H).replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	EEvpA4oBUtqfH07j6Kmrw8 = LM3EcSvGzJbe4
	if '__M3USeries__' in LM3EcSvGzJbe4:
		EEvpA4oBUtqfH07j6Kmrw8 = LM3EcSvGzJbe4.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in aBgiKXClAdLWFq3YuVpS8fZ4z6: type = ',VIDEOS: '
	elif 'LIVE' in aBgiKXClAdLWFq3YuVpS8fZ4z6: type = ',LIVE: '
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','[[COLOR FFC89008]'+type+EEvpA4oBUtqfH07j6Kmrw8+'[/COLOR] :القسم]',aBgiKXClAdLWFq3YuVpS8fZ4z6,168,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+LM3EcSvGzJbe4)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','إعادة الطلب العشوائي من نفس القسم',aBgiKXClAdLWFq3YuVpS8fZ4z6,168,QigevCplXxbPI1H,QigevCplXxbPI1H,'_FORGETRESULTS__REMEMBERRESULTS_'+LM3EcSvGzJbe4)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	import BGdPH3ey27
	for bnfEyUuXgk7GV9LjO81KNxrdDPzZ in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
		if '__M3USeries__' in LM3EcSvGzJbe4: BGdPH3ey27.uLBdfExXvZnPw2gpNOjRt8yQi(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),aBgiKXClAdLWFq3YuVpS8fZ4z6,LM3EcSvGzJbe4,QigevCplXxbPI1H,False)
		else: BGdPH3ey27.PYViltfWah910OHUZeR(str(bnfEyUuXgk7GV9LjO81KNxrdDPzZ),aBgiKXClAdLWFq3YuVpS8fZ4z6,LM3EcSvGzJbe4,QigevCplXxbPI1H,False)
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO)
	if len(lc0jJQ4zboeDI3tqTrpvm5gZO)>(ecuN3vGB5hMrK+3): lc0jJQ4zboeDI3tqTrpvm5gZO[:] = lc0jJQ4zboeDI3tqTrpvm5gZO[:3]+yarjPEMGV6m7fHRFeJXt.sample(lc0jJQ4zboeDI3tqTrpvm5gZO[3:],ecuN3vGB5hMrK)
	return
def KVr7FmcuCo5jJYIdMxwynXqBA(lc0jJQ4zboeDI3tqTrpvm5gZO):
	nazIjkLHhSc8PM75WxU2Fo = []
	for type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf in lc0jJQ4zboeDI3tqTrpvm5gZO:
		if 'صفحة' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 or 'صفحه' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 or 'page' in zsj5qOxnfaXmdEco3DK29HgYybUCM6.lower(): continue
		nazIjkLHhSc8PM75WxU2Fo.append([type,zsj5qOxnfaXmdEco3DK29HgYybUCM6,url,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,d8kolNVuLsPAjQZ9ROpUHBgix,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf])
	return nazIjkLHhSc8PM75WxU2Fo
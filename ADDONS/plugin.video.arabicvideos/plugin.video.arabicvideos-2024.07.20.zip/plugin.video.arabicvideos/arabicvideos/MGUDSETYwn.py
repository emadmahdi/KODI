# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'CIMALIGHT'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_CML_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['قنوات فضائية']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==470: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==471: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==472: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==473: W9lfsoMawqOzpQcXD = LU7F3uNrm06e8OwTEcCJ(url,text)
	elif mode==474: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==479: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = sBvufaD6c9YHdOqTjCQ3.findall('"url": "(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	unA4F0ajXBUwHksrx3IyNCJL = unA4F0ajXBUwHksrx3IyNCJL[0].strip('/')
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(unA4F0ajXBUwHksrx3IyNCJL,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,479,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"content"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		title = title.replace(eZXCHufT9YW4bRErSBOLmI,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('cat=online-movies1','cat=online-movies')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,474)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('/category.php">(.*?)"navslide-divider"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall("'dropdown-menu'(.*?)</ul>",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,474)
	return
def eR6YT8AbXwl(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if 'topvideos.php' in url: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"caret"(.*?)id="pm-grid"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"caret"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if 'topvideos.php' in RMC6c2kL5hGOnFaIwAyb:
				if 'topvideos.php?c=english-movies' in RMC6c2kL5hGOnFaIwAyb: continue
				if 'topvideos.php?c=online-movies1' in RMC6c2kL5hGOnFaIwAyb: continue
				if 'topvideos.php?c=misc' in RMC6c2kL5hGOnFaIwAyb: continue
				if 'topvideos.php?c=tv-channel' in RMC6c2kL5hGOnFaIwAyb: continue
				if 'منذ البداية' in title and 'do=rating' not in RMC6c2kL5hGOnFaIwAyb: continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,471)
	else: ddbEXhWzOnIaR(url)
	return
def ddbEXhWzOnIaR(url,x9Ahuz3FVWmJDaNp5=QigevCplXxbPI1H):
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	items = []
	if x9Ahuz3FVWmJDaNp5=='featured_movies':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"container-fluid"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		rsBojxT8UZwL,hu8mLEVaH12kwABO7nKtUpybXM,QYpMVndWxhHlsba8t7CN4RFeSg = zip(*items)
		items = zip(QYpMVndWxhHlsba8t7CN4RFeSg,rsBojxT8UZwL,hu8mLEVaH12kwABO7nKtUpybXM)
	elif x9Ahuz3FVWmJDaNp5=='featured_series':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('المسلسلات المميزة(.*?)<style>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		rsBojxT8UZwL,hu8mLEVaH12kwABO7nKtUpybXM,QYpMVndWxhHlsba8t7CN4RFeSg = zip(*items)
		items = zip(QYpMVndWxhHlsba8t7CN4RFeSg,rsBojxT8UZwL,hu8mLEVaH12kwABO7nKtUpybXM)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('(data-echo=".*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"BlocksList"(.*?)"titleSectionCon"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="pm-grid"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="pm-related"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('pm-ul-browse-videos(.*?)clearfix',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: return
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb).strip('/')
		title = title.replace('ماي سيما',QigevCplXxbPI1H).replace('مشاهدة',QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
		if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
		if 'http' not in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = unA4F0ajXBUwHksrx3IyNCJL+'/'+cXu4fN1moCypJqb72OZvd.strip('/')
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|حلقة) \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			title = '_MOD_'+title
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,472,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY and 'حلقة' in title:
			title = '_MOD_'+V1nZX7O5WwEq8HmvkY[0][0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,473,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif '/movseries/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,471,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,473,cXu4fN1moCypJqb72OZvd)
	if x9Ahuz3FVWmJDaNp5 not in ['featured_movies','featured_series']:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				if RMC6c2kL5hGOnFaIwAyb=='#': continue
				RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,471)
		CMdDv3wHmpqtT0JBPrUXhR = sBvufaD6c9YHdOqTjCQ3.findall('showmore" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if CMdDv3wHmpqtT0JBPrUXhR:
			RMC6c2kL5hGOnFaIwAyb = CMdDv3wHmpqtT0JBPrUXhR[0]
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مشاهدة المزيد',RMC6c2kL5hGOnFaIwAyb,471)
	return
def LU7F3uNrm06e8OwTEcCJ(url,q0zc3k5wP7Qo9A):
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-EPISODES-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"SeasonsBox"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	items = []
	if Z5CDQW96jye and not q0zc3k5wP7Qo9A:
		cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('"series-header".*?src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0] if cXu4fN1moCypJqb72OZvd else QigevCplXxbPI1H
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(items)==1: q0zc3k5wP7Qo9A = items[0][0]
		elif len(items)>1:
			for q0zc3k5wP7Qo9A,title in items: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,473,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,q0zc3k5wP7Qo9A)
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('id="'+q0zc3k5wP7Qo9A+'"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if gQ5KvJ6G2lbWwYBOMiTr and len(items)<2:
		cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('"series-header".*?src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0] if cXu4fN1moCypJqb72OZvd else QigevCplXxbPI1H
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if items:
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = title.replace('ماي سيما',QigevCplXxbPI1H).replace('مسلسل',QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,472,cXu4fN1moCypJqb72OZvd)
		else:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,472,cXu4fN1moCypJqb72OZvd)
	if 'id="pm-related"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		if items: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مواضيع ذات صلة',url,471)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<div itemprop="description">(.*?)href=',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('<p>(.*?)</p>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl,True): return
	Kj0TOU6BmSMlJHZYLd = url.replace('/watch.php','/play.php')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-PLAY-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	uyR7V4mUOKBphYLEDTxs1tgwvl = []
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('"embedURL" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0]
		if RMC6c2kL5hGOnFaIwAyb and RMC6c2kL5hGOnFaIwAyb not in uyR7V4mUOKBphYLEDTxs1tgwvl:
			uyR7V4mUOKBphYLEDTxs1tgwvl.append(RMC6c2kL5hGOnFaIwAyb)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named=__embed'
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	items = sBvufaD6c9YHdOqTjCQ3.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if RMC6c2kL5hGOnFaIwAyb not in uyR7V4mUOKBphYLEDTxs1tgwvl:
			uyR7V4mUOKBphYLEDTxs1tgwvl.append(RMC6c2kL5hGOnFaIwAyb)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	Kj0TOU6BmSMlJHZYLd = url.replace('/watch.php','/downloads.php')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMALIGHT-PLAY-3rd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"downloadlist"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<strong>(.*?)</strong>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if RMC6c2kL5hGOnFaIwAyb not in uyR7V4mUOKBphYLEDTxs1tgwvl:
				uyR7V4mUOKBphYLEDTxs1tgwvl.append(RMC6c2kL5hGOnFaIwAyb)
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(vxQUXEuH9m,'url')
	url = bSrdN78jxURTvh9+'/search.php?keywords='+search
	ddbEXhWzOnIaR(url,'search')
	return
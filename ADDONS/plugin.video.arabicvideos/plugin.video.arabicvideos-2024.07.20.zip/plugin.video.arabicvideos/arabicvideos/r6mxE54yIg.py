# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
import xbmc as qVuYLZTmSUhQe7rEwvFRfc,re as sBvufaD6c9YHdOqTjCQ3,sys as KXhrv29CGR8QTDzJIWLY,xbmcaddon as rljJ8cEGHQtapvDK4LZb6wWMmId2N,random as yarjPEMGV6m7fHRFeJXt,os as KiTt9ZskMLjnCAUIJNXD7,xbmcvfs as YwzoJLlhkvf4a,time as B3TKLo71hAGRqYgV0,pickle as GqDnWM523CgyzifeoIHvwEtSl0FP,zlib as NitQwg0RoyESdkOU3D4pqu,xbmcgui as Q0BXbnOs1jr8afIyTUHZDw4lCAki7,xbmcplugin as Z7ZstrGoNP3XSLYClzUm8TqV,sqlite3 as DZLbiWNFXwpM26,traceback as aaoGmpybi6Q9wxsgFzXIt,threading as VVGXMeyJq25S6tf
PuT0IphGNsketAQ = TCF8wLyDvgumfiXPSKRh(u"ࠧࡍࡋࡅࡗࡔࡔࡅࠨ२")
QigevCplXxbPI1H = bDt7Ya1VEio3(u"ࠨࠩ३")
hT7zFDpEyUqf8sXuN = vZL6j4tSClIGxzNE5DX(u"ࠩࠣࠫ४")
eZXCHufT9YW4bRErSBOLmI = hT7zFDpEyUqf8sXuN*mmKqLr9RX0ACN384JMcsFHzd(u"࠵૥")
Ec4QJmyAo3G7Vp2X6SY8UifnOh = hT7zFDpEyUqf8sXuN*VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷૦")
f1p0IN8alhrDKHyvqWk9UZ = hT7zFDpEyUqf8sXuN*TCF8wLyDvgumfiXPSKRh(u"࠹૧")
XpREPf7d08GnIS6i4KNLMyZHmuQqxD = XWbHfI9B8swrOL(u"ࡔࡳࡷࡨନ")
YoAMfqm37GyFxbuKTt6e8CESHrhB = bDt7Ya1VEio3(u"ࡇࡣ࡯ࡷࡪ଩")
h17Zb2ld4yLBrCP5tiw = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶૨")
nfC2im3NzUQk = VvhRUZgko5Af1BIynMGOJSbpmK(u"࠱૩")
JxuTQLOD357o41evylqPmRdf = OOhnpQ8XvCVclGqdu(u"࠳૪")
mVjHAyIwzSNKLFcd = OTRKI6LbrQnZEm(u"࠵૫")
bWU9StnJOg6aIQiTMxh7sFZG8lPud = Xr2aHOK0huQ5DTS(u"࠷૬")
iVCLpNIM8BQs9PdSgKZvlFeo3a5 = TCF8wLyDvgumfiXPSKRh(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭५")
r9rhtA5Tek8sIoLfqwF7JcEV = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ६")
jhAlCQ47ZgG = vZL6j4tSClIGxzNE5DX(u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ७")
zW0xYFg17enwNcXOmKqvikapMyfHjL = Xr2aHOK0huQ5DTS(u"࠭ࡵࡵࡨ࠻ࠫ८")
AwKhgdpmBj0 = g4UCaNkHvLwGhjmW(u"ࠧࡏࡑࡗࡍࡈࡋࠧ९")
wwCMPEQvjF4kBApyIzXml = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ॰")
wJ1SrGzhYcZ0aofnKQkV5 = O4ylJvVNwLztdiHqBWDU(u"ࠩࡈࡖࡗࡕࡒࠨॱ")
QKaGISLxUqbmh = XWbHfI9B8swrOL(u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨॲ")
aSBkt4OU8JpWTEzVIHjAiv = TCF8wLyDvgumfiXPSKRh(u"ࠫࡡࡴࠧॳ")
Ymkp8qFPsjovc57UT = vZL6j4tSClIGxzNE5DX(u"ࠬࡢࡲࠨॴ")
XoeSNbWwLnKC8Q = rljJ8cEGHQtapvDK4LZb6wWMmId2N.Addon().getAddonInfo(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡰࡢࡶ࡫ࠫॵ"))
m4fkwvSt7gxu5ZKcIX = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩॶ"))
KXhrv29CGR8QTDzJIWLY.path.append(m4fkwvSt7gxu5ZKcIX)
FwcH7quaG4m5vp2W9I = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢॷ"))
aybmzWnDkuEcT3jpJClB2 = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"ࠩࠫࡠࡩࡢࡤ࡝࠰࡟ࡨ࠮࠭ॸ"),FwcH7quaG4m5vp2W9I,sBvufaD6c9YHdOqTjCQ3.DOTALL)
aybmzWnDkuEcT3jpJClB2 = float(aybmzWnDkuEcT3jpJClB2[h17Zb2ld4yLBrCP5tiw])
JKY4wWzokjPbOs1XaEQ = qVuYLZTmSUhQe7rEwvFRfc.Player
Roa4WbzDQZ95UPFSwkBsujAMgLtpX2 = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.WindowXMLDialog
L2EXWK5vf3AoDtV8F6OgNBqkmyG = aybmzWnDkuEcT3jpJClB2<s0vAWcLSXEToH9Mik134q(u"࠵࠾૭")
b7sJAmSxlBvaMdHFz = aybmzWnDkuEcT3jpJClB2>DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠶࠾࠮࠺࠻૮")
if b7sJAmSxlBvaMdHFz:
	efCNIngzSRLr0 = qVuYLZTmSUhQe7rEwvFRfc.LOGINFO
	yy7OzVc6J5WiY4pLMwFoXRs,AhkIX24vpNGzdLU5 = pGncXOodjKhJzLSqVP1r(u"ࡸࠫࡡࡻ࠲࠱࠴ࡤࠫॹ"),FF70emVxhWOngCty(u"ࡹࠬࡢࡵ࠳࠲࠵ࡦࠬॺ")
	UyIB8wf6GzD = YwzoJLlhkvf4a.translatePath(vZL6j4tSClIGxzNE5DX(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭ॻ"))
	from urllib.parse import unquote as _dM63mfqsTFBKnLAX
else:
	efCNIngzSRLr0 = qVuYLZTmSUhQe7rEwvFRfc.LOGNOTICE
	yy7OzVc6J5WiY4pLMwFoXRs,AhkIX24vpNGzdLU5 = tg9l25NH6WTacVSifLyAmY(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧॼ").encode(zW0xYFg17enwNcXOmKqvikapMyfHjL),DDHwpETQrAm0xMNXGfyhqsUi(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨॽ").encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	UyIB8wf6GzD = qVuYLZTmSUhQe7rEwvFRfc.translatePath(Fg72JX6T5DkPy(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡹ࡫࡭ࡱࠩॾ"))
	from urllib import unquote as _dM63mfqsTFBKnLAX
VZDHXewu049nNgFqmifv3r = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠼࠰૯")
oaxeugQnX1W6UJN = y5yX4jh6kUEgWZQIc(u"࠶࠱૰")*VZDHXewu049nNgFqmifv3r
ivRIPHFStXJAM = pTwKPmzMSZhil5d2RWonre(u"࠳࠶૱")*oaxeugQnX1W6UJN
S8QZ9PUG1BTr0v4MhH5KLzuwY = fk8jc5uDLX16qrih3ZaPxsvO(u"࠵࠳૲")*ivRIPHFStXJAM
oL2eIiFEJnd7vxc = h17Zb2ld4yLBrCP5tiw
vMlT137PE8q4wiKpWIojraR29B = bDt7Ya1VEio3(u"࠶࠴૳")*VZDHXewu049nNgFqmifv3r
vjPhaUE819opVQg7uRk4wG6cYBOTd = JxuTQLOD357o41evylqPmRdf*oaxeugQnX1W6UJN
pETKl7xuH1f5yjdFAb6C8JzOLV = O4ylJvVNwLztdiHqBWDU(u"࠵࠻૴")*oaxeugQnX1W6UJN
g6gNzml5rOsa8bBETxPCpnVj = mVjHAyIwzSNKLFcd*ivRIPHFStXJAM
hWYVzubgexwTPIfq = OOhnpQ8XvCVclGqdu(u"࠸࠶૵")*ivRIPHFStXJAM
xfdjCmFwb0k8JAVegiL = K7bLVaiRkx0lgU5SQM(u"࠷࠲૶")*S8QZ9PUG1BTr0v4MhH5KLzuwY
S8BEV2s9fbO14kaX = oaxeugQnX1W6UJN
GTZC7rKJtPlueQ = KXhrv29CGR8QTDzJIWLY.argv[h17Zb2ld4yLBrCP5tiw].split(O4ylJvVNwLztdiHqBWDU(u"ࠩ࠲ࠫॿ"))[JxuTQLOD357o41evylqPmRdf]
NNZh0HbgakloGKdCOUYJ3W1SAnXPwi = int(KXhrv29CGR8QTDzJIWLY.argv[nfC2im3NzUQk])
MYIqLm4Nyhniu6QORWlrp = KXhrv29CGR8QTDzJIWLY.argv[JxuTQLOD357o41evylqPmRdf]
bczPgHELSovQYWRG5IdZy3u1q8 = GTZC7rKJtPlueQ.split(mmKqLr9RX0ACN384JMcsFHzd(u"ࠪ࠲ࠬঀ"))[JxuTQLOD357o41evylqPmRdf]
GVmdqbtLu8lUXNxp13aHOvkscR = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡆࡪࡤࡰࡰ࡙ࡩࡷࡹࡩࡰࡰࠫࠫঁ")+GTZC7rKJtPlueQ+pTwKPmzMSZhil5d2RWonre(u"ࠬ࠯ࠧং"))
nZ5AkguavpEc7zWo8SOHRD = KiTt9ZskMLjnCAUIJNXD7.path.join(UyIB8wf6GzD,GTZC7rKJtPlueQ)
qH5vZR0MhF97zt4PULV = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,pTwKPmzMSZhil5d2RWonre(u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫঃ"))
Nk7BzXcC5VbpSanw = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,K7bLVaiRkx0lgU5SQM(u"ࠧ࡭ࡣࡶࡸࡻ࡯ࡤࡦࡱࡶ࠲ࡩࡧࡴࠨ঄"))
qyUPZBiAE3YkuOKrMnTFex92D = int(B3TKLo71hAGRqYgV0.time())
uUTRHgAXJzm7pIDBjNt8 = rljJ8cEGHQtapvDK4LZb6wWMmId2N.Addon(id=GTZC7rKJtPlueQ)
GGQExm1HXI7ChgaRL5dy = uUTRHgAXJzm7pIDBjNt8.getSetting(Fg72JX6T5DkPy(u"ࠨࡣࡹ࠲ࡻ࡫ࡲࡴ࡫ࡲࡲࠬঅ"))
enGPuSCj3A2R = YoAMfqm37GyFxbuKTt6e8CESHrhB if GGQExm1HXI7ChgaRL5dy==GVmdqbtLu8lUXNxp13aHOvkscR else XpREPf7d08GnIS6i4KNLMyZHmuQqxD
def b9PJzXFf4dYnGHm52NWsyA8(iCr0xsqwDZXLPaJK1W5YU24F6hp,JvHXPSz0mLOf2Tl=DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡂࠫআ")):
	if svULcgJ7jm(u"ࠪࡁࠬই") in iCr0xsqwDZXLPaJK1W5YU24F6hp:
		if JvHXPSz0mLOf2Tl in iCr0xsqwDZXLPaJK1W5YU24F6hp: Kj0TOU6BmSMlJHZYLd,y2DrJpPUXLzjwotvVlAe = iCr0xsqwDZXLPaJK1W5YU24F6hp.split(JvHXPSz0mLOf2Tl,XWbHfI9B8swrOL(u"࠱૷"))
		else: Kj0TOU6BmSMlJHZYLd,y2DrJpPUXLzjwotvVlAe = QigevCplXxbPI1H,iCr0xsqwDZXLPaJK1W5YU24F6hp
		y2DrJpPUXLzjwotvVlAe = y2DrJpPUXLzjwotvVlAe.split(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࠫ࠭ঈ"))
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = {}
		for irNFCMw0n15 in y2DrJpPUXLzjwotvVlAe:
			QQPBwuOv2LeWXTnYygj,AWiQJuPfExS2ey3KM6cVNFv4Ypa = irNFCMw0n15.split(pGncXOodjKhJzLSqVP1r(u"ࠬࡃࠧউ"),svULcgJ7jm(u"࠲૸"))
			tNQDMKVydhBqgaUvJ7oeAkTHxsL1[QQPBwuOv2LeWXTnYygj] = AWiQJuPfExS2ey3KM6cVNFv4Ypa
	else: Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = iCr0xsqwDZXLPaJK1W5YU24F6hp,{}
	return Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1
def rybze7NZwv(yBWPDAeJF1o2b):
	q5b7CW4BcLSGJ3aosgz2AQwXjRp0M,c1Ifu0OGV2kyRwLPWlsho8Ct6nz,T5jWiLs7lEYk2FrAZ86I4bHxevyz = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	yBWPDAeJF1o2b = yBWPDAeJF1o2b.replace(yy7OzVc6J5WiY4pLMwFoXRs,QigevCplXxbPI1H).replace(AhkIX24vpNGzdLU5,QigevCplXxbPI1H)
	UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall(svULcgJ7jm(u"࠭ࠨ࠯ࠫ࡟࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡡࡣࠨ࡝ࡹ࡟ࡻࡡࡽࠩࠡ࠭࡟࡟ࡡ࠵ࡃࡐࡎࡒࡖࡡࡣࠨ࠯ࠬࡂ࠭ࠩ࠭ঊ"),yBWPDAeJF1o2b,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if UX3RT0evEunCm2cHIz1Qs: q5b7CW4BcLSGJ3aosgz2AQwXjRp0M,c1Ifu0OGV2kyRwLPWlsho8Ct6nz,yBWPDAeJF1o2b = UX3RT0evEunCm2cHIz1Qs[h17Zb2ld4yLBrCP5tiw]
	if q5b7CW4BcLSGJ3aosgz2AQwXjRp0M not in [hT7zFDpEyUqf8sXuN,tOrSvd8QKNB(u"ࠧ࠭ࠩঋ"),QigevCplXxbPI1H]: T5jWiLs7lEYk2FrAZ86I4bHxevyz = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡡࡐࡓࡉࡥࠧঌ")
	if c1Ifu0OGV2kyRwLPWlsho8Ct6nz: c1Ifu0OGV2kyRwLPWlsho8Ct6nz = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡢࠫ঍")+c1Ifu0OGV2kyRwLPWlsho8Ct6nz+pGncXOodjKhJzLSqVP1r(u"ࠪࡣࠬ঎")
	yBWPDAeJF1o2b = c1Ifu0OGV2kyRwLPWlsho8Ct6nz+T5jWiLs7lEYk2FrAZ86I4bHxevyz+yBWPDAeJF1o2b
	return yBWPDAeJF1o2b
def MVkP7zfWlxUXj(iCr0xsqwDZXLPaJK1W5YU24F6hp):
	return _dM63mfqsTFBKnLAX(iCr0xsqwDZXLPaJK1W5YU24F6hp)
def c79RqAVuZjN1UaSOPB(ya5W8pRxoYqjSs2e):
	d2DvCszfGgjmrW8FZbSEUXLI7R94oe = {XWbHfI9B8swrOL(u"ࠫࡹࡿࡰࡦࠩএ"):QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠬࡳ࡯ࡥࡧࠪঐ"):QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡵࡳ࡮ࠪ঑"):QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠧࡵࡧࡻࡸࠬ঒"):QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"ࠨࡲࡤ࡫ࡪ࠭ও"):QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠩࡱࡥࡲ࡫ࠧঔ"):QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪ࡭ࡲࡧࡧࡦࠩক"):QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬখ"):QigevCplXxbPI1H,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧগ"):QigevCplXxbPI1H}
	if g4UCaNkHvLwGhjmW(u"࠭࠿ࠨঘ") in ya5W8pRxoYqjSs2e: ya5W8pRxoYqjSs2e = ya5W8pRxoYqjSs2e.split(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡀࠩঙ"),nfC2im3NzUQk)[nfC2im3NzUQk]
	Kj0TOU6BmSMlJHZYLd,KGWR61s8oNJ5z34fb2umetir = b9PJzXFf4dYnGHm52NWsyA8(ya5W8pRxoYqjSs2e)
	aargs = dict(list(d2DvCszfGgjmrW8FZbSEUXLI7R94oe.items())+list(KGWR61s8oNJ5z34fb2umetir.items()))
	OQzUY9RicH = aargs[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࡯ࡲࡨࡪ࠭চ")]
	BhrLoijzPEQdMFf4G981Kl = MVkP7zfWlxUXj(aargs[pTwKPmzMSZhil5d2RWonre(u"ࠩࡸࡶࡱ࠭ছ")])
	XULthrmAYvfVx9M0dkZaz2n = MVkP7zfWlxUXj(aargs[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡸࡪࡾࡴࠨজ")])
	RsTtrzxBK961JWwk4 = MVkP7zfWlxUXj(aargs[Fg72JX6T5DkPy(u"ࠫࡵࡧࡧࡦࠩঝ")])
	ut0GrdCjHJDIEgyOsvUTNLVF2 = MVkP7zfWlxUXj(aargs[JJu4MPClbTFpUwHiN(u"ࠬࡺࡹࡱࡧࠪঞ")])
	AYvyVPneLu0gCIObkQRrKFNwqD9 = MVkP7zfWlxUXj(aargs[K7bLVaiRkx0lgU5SQM(u"࠭࡮ࡢ࡯ࡨࠫট")])
	XXQM6ytjGOkW = MVkP7zfWlxUXj(aargs[XWbHfI9B8swrOL(u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ঠ")])
	uqeGx2DZ6SngyVPwj = aargs[v54ZuLY6dQ(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩড")]
	n8uzSqGdeImPR = MVkP7zfWlxUXj(aargs[mpusoZBJ6V(u"ࠩ࡬ࡲ࡫ࡵࡤࡪࡥࡷࠫঢ")])
	if n8uzSqGdeImPR: n8uzSqGdeImPR = eval(n8uzSqGdeImPR)
	else: n8uzSqGdeImPR = {}
	if not OQzUY9RicH: ut0GrdCjHJDIEgyOsvUTNLVF2 = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡪࡴࡲࡤࡦࡴࠪণ") ; OQzUY9RicH = O4ylJvVNwLztdiHqBWDU(u"ࠫ࠷࠼࠰ࠨত")
	return ut0GrdCjHJDIEgyOsvUTNLVF2,AYvyVPneLu0gCIObkQRrKFNwqD9,BhrLoijzPEQdMFf4G981Kl,OQzUY9RicH,XXQM6ytjGOkW,RsTtrzxBK961JWwk4,XULthrmAYvfVx9M0dkZaz2n,uqeGx2DZ6SngyVPwj,n8uzSqGdeImPR
def w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ):
	VQaiSWKderZ3PvF8lTqp1 = KXhrv29CGR8QTDzJIWLY._getframe(nfC2im3NzUQk).f_code.co_name
	if not PuT0IphGNsketAQ or not VQaiSWKderZ3PvF8lTqp1 or VQaiSWKderZ3PvF8lTqp1==v54ZuLY6dQ(u"ࠬࡂ࡭ࡰࡦࡸࡰࡪࡄࠧথ"):
		return QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࡛࠭ࠡࠩদ")+bczPgHELSovQYWRG5IdZy3u1q8.upper()+FF70emVxhWOngCty(u"ࠧ࠮ࠩধ")+GVmdqbtLu8lUXNxp13aHOvkscR+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨ࠯ࠪন")+str(aybmzWnDkuEcT3jpJClB2)+v54ZuLY6dQ(u"ࠩࠣࡡࠬ঩")
	return svULcgJ7jm(u"ࠪ࠲ࡡࡺࠧপ")+VQaiSWKderZ3PvF8lTqp1
def SQdRhwozVfv(NRDUT4hdJ81X,LFtkv1dZI6QNUlAq0wX):
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: LFtkv1dZI6QNUlAq0wX = LFtkv1dZI6QNUlAq0wX.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL).encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	XX5ltnuVsqvfJdWmz34jckZpo = efCNIngzSRLr0
	pS1FVtbXfLgZ0nxY3eTzqGd = [QigevCplXxbPI1H,QigevCplXxbPI1H]
	if NRDUT4hdJ81X: LFtkv1dZI6QNUlAq0wX = LFtkv1dZI6QNUlAq0wX.replace(r9rhtA5Tek8sIoLfqwF7JcEV,QigevCplXxbPI1H).replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,QigevCplXxbPI1H).replace(jhAlCQ47ZgG,QigevCplXxbPI1H)
	else: NRDUT4hdJ81X = AwKhgdpmBj0
	Eo8XslgU9qR,JvHXPSz0mLOf2Tl = XWbHfI9B8swrOL(u"ࠫࡡࡺࠧফ"),Ec4QJmyAo3G7Vp2X6SY8UifnOh
	eeiA67ImNfHlGvBCYxEphzJ3 = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠷࠶ૺ")*hT7zFDpEyUqf8sXuN if b7sJAmSxlBvaMdHFz else DDHwpETQrAm0xMNXGfyhqsUi(u"࠵࠴ૹ")*hT7zFDpEyUqf8sXuN
	vuwZOlDQy6JPx07Mpz8WHtEXCb = bWU9StnJOg6aIQiTMxh7sFZG8lPud*Eo8XslgU9qR
	if LFtkv1dZI6QNUlAq0wX.startswith(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭ব")): LFtkv1dZI6QNUlAq0wX = DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭࠮࡝ࡶࠪভ")+LFtkv1dZI6QNUlAq0wX
	if wJ1SrGzhYcZ0aofnKQkV5 in NRDUT4hdJ81X: XX5ltnuVsqvfJdWmz34jckZpo = qVuYLZTmSUhQe7rEwvFRfc.LOGERROR
	if NRDUT4hdJ81X in [AwKhgdpmBj0,wJ1SrGzhYcZ0aofnKQkV5]: pS1FVtbXfLgZ0nxY3eTzqGd = [LFtkv1dZI6QNUlAq0wX]
	elif NRDUT4hdJ81X==QKaGISLxUqbmh: pS1FVtbXfLgZ0nxY3eTzqGd = LFtkv1dZI6QNUlAq0wX.split(JvHXPSz0mLOf2Tl)
	elif NRDUT4hdJ81X==wwCMPEQvjF4kBApyIzXml:
		KWd8gTIVsbfk31S6C2zeQAaN = LFtkv1dZI6QNUlAq0wX.split(JvHXPSz0mLOf2Tl)
		pS1FVtbXfLgZ0nxY3eTzqGd = [KWd8gTIVsbfk31S6C2zeQAaN[h17Zb2ld4yLBrCP5tiw]]
		for ATh6upUgFnm1VybLRcHv2QiGEfX4 in range(nfC2im3NzUQk,len(KWd8gTIVsbfk31S6C2zeQAaN),JxuTQLOD357o41evylqPmRdf):
			try: vvnmGabAKo0T23WIzdcJMgEuONit = KWd8gTIVsbfk31S6C2zeQAaN[ATh6upUgFnm1VybLRcHv2QiGEfX4]+JvHXPSz0mLOf2Tl+KWd8gTIVsbfk31S6C2zeQAaN[ATh6upUgFnm1VybLRcHv2QiGEfX4+bDt7Ya1VEio3(u"࠵ૻ")]
			except: vvnmGabAKo0T23WIzdcJMgEuONit = KWd8gTIVsbfk31S6C2zeQAaN[ATh6upUgFnm1VybLRcHv2QiGEfX4]
			pS1FVtbXfLgZ0nxY3eTzqGd.append(vvnmGabAKo0T23WIzdcJMgEuONit)
	C20VMngHFDoLW = pS1FVtbXfLgZ0nxY3eTzqGd[h17Zb2ld4yLBrCP5tiw]
	for U6ZM8BVcn1re7STQLsEgxk3oJK in pS1FVtbXfLgZ0nxY3eTzqGd[nfC2im3NzUQk:]:
		if NRDUT4hdJ81X in [QKaGISLxUqbmh,wwCMPEQvjF4kBApyIzXml]: vuwZOlDQy6JPx07Mpz8WHtEXCb += Eo8XslgU9qR
		C20VMngHFDoLW += Ymkp8qFPsjovc57UT+eeiA67ImNfHlGvBCYxEphzJ3+vuwZOlDQy6JPx07Mpz8WHtEXCb+U6ZM8BVcn1re7STQLsEgxk3oJK
	C20VMngHFDoLW += JJu4MPClbTFpUwHiN(u"ࠧࠡࡡࠪম")
	if Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࠧࠪয") in C20VMngHFDoLW: C20VMngHFDoLW = MVkP7zfWlxUXj(C20VMngHFDoLW)
	qVuYLZTmSUhQe7rEwvFRfc.log(C20VMngHFDoLW,level=XX5ltnuVsqvfJdWmz34jckZpo)
	return
def gomHdCqRMikpnujeWJ2XSZL(aYXiUPQDVd7hjTsumgL):
	R2wuKSVBTLW4sAOQNob18UEdGf0hv = DZLbiWNFXwpM26.connect(aYXiUPQDVd7hjTsumgL)
	B6xRu5lFyJ = R2wuKSVBTLW4sAOQNob18UEdGf0hv.cursor()
	B6xRu5lFyJ.execute(Xr2aHOK0huQ5DTS(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨর"))
	B6xRu5lFyJ.execute(JJu4MPClbTFpUwHiN(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭঱"))
	B6xRu5lFyJ.execute(pTwKPmzMSZhil5d2RWonre(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭ল"))
	B6xRu5lFyJ.execute(pTwKPmzMSZhil5d2RWonre(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩ঳"))
	B6xRu5lFyJ.execute(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫ঴"))
	B6xRu5lFyJ.execute(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪ঵"))
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.text_factory = str
	return R2wuKSVBTLW4sAOQNob18UEdGf0hv,B6xRu5lFyJ
def P2zHZToLl1hQVUpvS7D(aYXiUPQDVd7hjTsumgL,mK39DivOJWl6dj1oGbx50nreIcP8,F51kHeuSfO0yg=None):
	try: R2wuKSVBTLW4sAOQNob18UEdGf0hv,B6xRu5lFyJ = gomHdCqRMikpnujeWJ2XSZL(aYXiUPQDVd7hjTsumgL)
	except: return
	if F51kHeuSfO0yg==None: B6xRu5lFyJ.execute(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪশ")+mK39DivOJWl6dj1oGbx50nreIcP8+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࠥࠤࡀ࠭ষ"))
	else:
		SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX = (str(F51kHeuSfO0yg),)
		try:
			if OTRKI6LbrQnZEm(u"ࠪࠩࠬস") in F51kHeuSfO0yg: B6xRu5lFyJ.execute(Xr2aHOK0huQ5DTS(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫহ")+mK39DivOJWl6dj1oGbx50nreIcP8+FF70emVxhWOngCty(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨ঺"),SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX)
			else: B6xRu5lFyJ.execute(FF70emVxhWOngCty(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭঻")+mK39DivOJWl6dj1oGbx50nreIcP8+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁ়ࠧ"),SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX)
		except: pass
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	return
class GD7MbtEArLHP(): pass
class aTqvbmueLIYkRjSODlK8BCW(GD7MbtEArLHP):
	def __init__(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.url = QigevCplXxbPI1H
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.code = -DDHwpETQrAm0xMNXGfyhqsUi(u"࠾࠿ૼ")
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.reason = QigevCplXxbPI1H
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.content = QigevCplXxbPI1H
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.headers = {}
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.cookies = {}
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.succeeded = YoAMfqm37GyFxbuKTt6e8CESHrhB
def ALZXz4TgYUtb9r5CEnad2yqBF(NWdTSkYP5E6wqsDogApZmLCcbu3j2I):
	if NWdTSkYP5E6wqsDogApZmLCcbu3j2I==Xr2aHOK0huQ5DTS(u"ࠨࡦ࡬ࡧࡹ࠭ঽ"): VV4iSgTwskE6uyoBCl3ZDh7HQ = {}
	elif NWdTSkYP5E6wqsDogApZmLCcbu3j2I==O4ylJvVNwLztdiHqBWDU(u"ࠩ࡯࡭ࡸࡺࠧা"): VV4iSgTwskE6uyoBCl3ZDh7HQ = []
	elif NWdTSkYP5E6wqsDogApZmLCcbu3j2I==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡷࡹࡸࠧি"): VV4iSgTwskE6uyoBCl3ZDh7HQ = QigevCplXxbPI1H
	elif NWdTSkYP5E6wqsDogApZmLCcbu3j2I==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࡮ࡴࡴࠨী"): VV4iSgTwskE6uyoBCl3ZDh7HQ = h17Zb2ld4yLBrCP5tiw
	elif NWdTSkYP5E6wqsDogApZmLCcbu3j2I==y5yX4jh6kUEgWZQIc(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧু"): VV4iSgTwskE6uyoBCl3ZDh7HQ = aTqvbmueLIYkRjSODlK8BCW()
	elif not NWdTSkYP5E6wqsDogApZmLCcbu3j2I: VV4iSgTwskE6uyoBCl3ZDh7HQ = None
	else: VV4iSgTwskE6uyoBCl3ZDh7HQ = None
	return VV4iSgTwskE6uyoBCl3ZDh7HQ
def nVIdjZ1ybeU8TB9tSpAQH(fBWIUmRvLTjFVYAu0Ppz2kGO8):
	from hashlib import md5 as o2vzJrWZyOS0Dk73dNpubl
	BBlrV106Cu2EIvciMpADGmgZL = uUTRHgAXJzm7pIDBjNt8.getSetting(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩূ"))
	ooaqbuv0HeUB9Ex38A5ijTQ1g = U8bMvkLTxSzw5ac(tg9l25NH6WTacVSifLyAmY(u"࠹࠲૽")).splitlines()
	YcmAzrjHudGXBfK0gsUvwx = h17Zb2ld4yLBrCP5tiw
	for Io5V03X8cU in [qyUPZBiAE3YkuOKrMnTFex92D,qyUPZBiAE3YkuOKrMnTFex92D-vjPhaUE819opVQg7uRk4wG6cYBOTd]:
		fuMzqkndGa = str(Io5V03X8cU*g4UCaNkHvLwGhjmW(u"࠲࠲࠳࠴࠵࠶࠮࠱૿")/hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠴࠴࠴࠳࠴࠵૾"))[h17Zb2ld4yLBrCP5tiw:OOhnpQ8XvCVclGqdu(u"࠶଀")]
		if fuMzqkndGa!=YcmAzrjHudGXBfK0gsUvwx:
			for OgaznoRv17Y52AIwEq in ooaqbuv0HeUB9Ex38A5ijTQ1g:
				V6pR8Qm1FsNzEkgOJ5PG = tg9l25NH6WTacVSifLyAmY(u"࡙ࠧ࠳࠼ࠫৃ")+fBWIUmRvLTjFVYAu0Ppz2kGO8+pTwKPmzMSZhil5d2RWonre(u"ࠨ࠳࠻ࡁࠬৄ")+OgaznoRv17Y52AIwEq[-JJu4MPClbTFpUwHiN(u"࠵࠸ଁ"):]+GVmdqbtLu8lUXNxp13aHOvkscR+fuMzqkndGa
				V6pR8Qm1FsNzEkgOJ5PG = o2vzJrWZyOS0Dk73dNpubl(V6pR8Qm1FsNzEkgOJ5PG.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)).hexdigest()[:bDt7Ya1VEio3(u"࠷࠷ଂ")]
				if V6pR8Qm1FsNzEkgOJ5PG in BBlrV106Cu2EIvciMpADGmgZL: return XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			YcmAzrjHudGXBfK0gsUvwx = fuMzqkndGa
	return YoAMfqm37GyFxbuKTt6e8CESHrhB
def wZ8QjMrd2u3V6TGxsmU(aYXiUPQDVd7hjTsumgL,xXg50B8W9Koq,mK39DivOJWl6dj1oGbx50nreIcP8,F51kHeuSfO0yg=None):
	VV4iSgTwskE6uyoBCl3ZDh7HQ = ALZXz4TgYUtb9r5CEnad2yqBF(xXg50B8W9Koq)
	xU4Y951Jcpf6jKGPOSemWILdCEZvg = uUTRHgAXJzm7pIDBjNt8.getSetting(g4UCaNkHvLwGhjmW(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨ৅"))
	if mK39DivOJWl6dj1oGbx50nreIcP8 not in [FF70emVxhWOngCty(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭৆"),s0vAWcLSXEToH9Mik134q(u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩে")] and aYXiUPQDVd7hjTsumgL==qH5vZR0MhF97zt4PULV and F51kHeuSfO0yg!=JJu4MPClbTFpUwHiN(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧৈ"):
		if xU4Y951Jcpf6jKGPOSemWILdCEZvg==K7bLVaiRkx0lgU5SQM(u"࠭ࡓࡕࡑࡓࠫ৉"): return VV4iSgTwskE6uyoBCl3ZDh7HQ
		aeRHmPISMkDNA2vd7F6gzpB9C = uUTRHgAXJzm7pIDBjNt8.getSetting(mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫ৊"))
		if aeRHmPISMkDNA2vd7F6gzpB9C==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨো"):
			P2zHZToLl1hQVUpvS7D(aYXiUPQDVd7hjTsumgL,mK39DivOJWl6dj1oGbx50nreIcP8,F51kHeuSfO0yg)
			return VV4iSgTwskE6uyoBCl3ZDh7HQ
	UF6NqSAEmLz7d = h17Zb2ld4yLBrCP5tiw
	if xU4Y951Jcpf6jKGPOSemWILdCEZvg==JJu4MPClbTFpUwHiN(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪৌ"): UF6NqSAEmLz7d = S8BEV2s9fbO14kaX
	try: R2wuKSVBTLW4sAOQNob18UEdGf0hv,B6xRu5lFyJ = gomHdCqRMikpnujeWJ2XSZL(aYXiUPQDVd7hjTsumgL)
	except: return VV4iSgTwskE6uyoBCl3ZDh7HQ
	GDQB3pCmbVNgytHsLM6wEUo4u = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	try: B6xRu5lFyJ.execute(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏ্ࠣࠦࠬ")+mK39DivOJWl6dj1oGbx50nreIcP8+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࠧࠦࡌࡊࡏࡌࡘࠥ࠷ࠠ࠼ࠩৎ"))
	except: GDQB3pCmbVNgytHsLM6wEUo4u = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if GDQB3pCmbVNgytHsLM6wEUo4u:
		if UF6NqSAEmLz7d: B6xRu5lFyJ.execute(OOhnpQ8XvCVclGqdu(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ৏")+mK39DivOJWl6dj1oGbx50nreIcP8+tg9l25NH6WTacVSifLyAmY(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠾ࠨ৐")+str(qyUPZBiAE3YkuOKrMnTFex92D+UF6NqSAEmLz7d)+Fg72JX6T5DkPy(u"ࠧࠡ࠽ࠪ৑"))
		R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
		B6xRu5lFyJ.execute(Xr2aHOK0huQ5DTS(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ৒")+mK39DivOJWl6dj1oGbx50nreIcP8+Xr2aHOK0huQ5DTS(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻ࠿ࠫ৓")+str(qyUPZBiAE3YkuOKrMnTFex92D)+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࠤࡀ࠭৔"))
		R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
		if F51kHeuSfO0yg:
			SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX = (str(F51kHeuSfO0yg),)
			B6xRu5lFyJ.execute(O4ylJvVNwLztdiHqBWDU(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ৕")+mK39DivOJWl6dj1oGbx50nreIcP8+bDt7Ya1VEio3(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ৖"),SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX)
			evn4M7hX8L2QKZHNEamVz5kw = B6xRu5lFyJ.fetchall()
			if evn4M7hX8L2QKZHNEamVz5kw:
				try:
					CyarqoiHxV2e80ScjAN = NitQwg0RoyESdkOU3D4pqu.decompress(evn4M7hX8L2QKZHNEamVz5kw[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw])
					VV4iSgTwskE6uyoBCl3ZDh7HQ = GqDnWM523CgyzifeoIHvwEtSl0FP.loads(CyarqoiHxV2e80ScjAN)
				except: pass
		else:
			B6xRu5lFyJ.execute(Xr2aHOK0huQ5DTS(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡣࡰ࡮ࡸࡱࡳ࠲ࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫৗ")+mK39DivOJWl6dj1oGbx50nreIcP8+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࠣࠢ࠾ࠫ৘"))
			evn4M7hX8L2QKZHNEamVz5kw = B6xRu5lFyJ.fetchall()
			if evn4M7hX8L2QKZHNEamVz5kw:
				VV4iSgTwskE6uyoBCl3ZDh7HQ,oOancrCU76Mm9 = {},[]
				for HLAFsBtr2Q,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 in evn4M7hX8L2QKZHNEamVz5kw:
					rtZM5KYaGepo7F2 = NitQwg0RoyESdkOU3D4pqu.decompress(tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
					tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = GqDnWM523CgyzifeoIHvwEtSl0FP.loads(rtZM5KYaGepo7F2)
					VV4iSgTwskE6uyoBCl3ZDh7HQ[HLAFsBtr2Q] = tNQDMKVydhBqgaUvJ7oeAkTHxsL1
					oOancrCU76Mm9.append(HLAFsBtr2Q)
				if oOancrCU76Mm9:
					VV4iSgTwskE6uyoBCl3ZDh7HQ[g4UCaNkHvLwGhjmW(u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ৙")] = oOancrCU76Mm9
					if xXg50B8W9Koq==vZL6j4tSClIGxzNE5DX(u"ࠩ࡯࡭ࡸࡺࠧ৚"): VV4iSgTwskE6uyoBCl3ZDh7HQ = oOancrCU76Mm9
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	return VV4iSgTwskE6uyoBCl3ZDh7HQ
class XmIdijotlxQ6LuJ(JKY4wWzokjPbOs1XaEQ):
	def __init__(WnaR8GmjVCwcob6tNeJQ3TS1XL9U): pass
	def M4yLHpiledUP3SVE8f(WnaR8GmjVCwcob6tNeJQ3TS1XL9U,XXwdYAmZkV80Dc7RSIOTE3):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.Iifg8zaT0jN1kOHXUPDBK2An9Qt5c = nVIdjZ1ybeU8TB9tSpAQH(pTwKPmzMSZhil5d2RWonre(u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ৛"))
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.FmA8PM65eJcoUnp2agY = nVIdjZ1ybeU8TB9tSpAQH(Xr2aHOK0huQ5DTS(u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬড়"))
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.ULl9wGkg1NTK8ChmyszQ6oaS = nVIdjZ1ybeU8TB9tSpAQH(mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪঢ়"))
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = O4ylJvVNwLztdiHqBWDU(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ৞") if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.Iifg8zaT0jN1kOHXUPDBK2An9Qt5c else QigevCplXxbPI1H
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.XXwdYAmZkV80Dc7RSIOTE3 = XXwdYAmZkV80Dc7RSIOTE3
		if not WnaR8GmjVCwcob6tNeJQ3TS1XL9U.FmA8PM65eJcoUnp2agY:
			from TEsNM9QVZc import otYUTIzA5Qwdy1ClJuKLas6r8
			otYUTIzA5Qwdy1ClJuKLas6r8(vMlT137PE8q4wiKpWIojraR29B)
	def onPlayBackStopped(WnaR8GmjVCwcob6tNeJQ3TS1XL9U): WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = OTRKI6LbrQnZEm(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧয়")
	def onPlayBackError(WnaR8GmjVCwcob6tNeJQ3TS1XL9U): WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = vZL6j4tSClIGxzNE5DX(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨৠ")
	def onPlayBackEnded(WnaR8GmjVCwcob6tNeJQ3TS1XL9U): WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = K7bLVaiRkx0lgU5SQM(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩৡ")
	def onPlayBackStarted(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = s0vAWcLSXEToH9Mik134q(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫৢ")
		Pbf7xBiz0q = VVGXMeyJq25S6tf.Thread(target=WnaR8GmjVCwcob6tNeJQ3TS1XL9U.qjifE1eR9Ou3gtWHrzslK7A,args=())
		Pbf7xBiz0q.start()
	def onAVStarted(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.FmA8PM65eJcoUnp2agY: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬৣ")
		else: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭৤")
	def qjifE1eR9Ou3gtWHrzslK7A(WnaR8GmjVCwcob6tNeJQ3TS1XL9U):
		from TEsNM9QVZc import r4kvMcV79HDh,gIkDSqPu05YZ,SxKAmIcoHeQ1
		SxKAmIcoHeQ1(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡳࡵࡱࡳࠫ৥"))
		eH62VBKOwrhWU = h17Zb2ld4yLBrCP5tiw
		while not eval(svULcgJ7jm(u"ࠧࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡪࡵࡓࡰࡦࡿࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠩࠫࠪ০"),{g4UCaNkHvLwGhjmW(u"ࠨࡺࡥࡱࡨ࠭১"):qVuYLZTmSUhQe7rEwvFRfc}) and WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY==DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ২"):
			qVuYLZTmSUhQe7rEwvFRfc.sleep(mpusoZBJ6V(u"࠶࠶࠰࠱ଃ"))
			eH62VBKOwrhWU += nfC2im3NzUQk
			if eH62VBKOwrhWU>O4ylJvVNwLztdiHqBWDU(u"࠼࠰଄"): return
		if WnaR8GmjVCwcob6tNeJQ3TS1XL9U.Iifg8zaT0jN1kOHXUPDBK2An9Qt5c: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = pTwKPmzMSZhil5d2RWonre(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৩")
		elif WnaR8GmjVCwcob6tNeJQ3TS1XL9U.FmA8PM65eJcoUnp2agY: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ৪")
		elif WnaR8GmjVCwcob6tNeJQ3TS1XL9U.ULl9wGkg1NTK8ChmyszQ6oaS:
			WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = XWbHfI9B8swrOL(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭৫")
			OsvSfAzo3k6iDqa2b47Ln = VVGXMeyJq25S6tf.Thread(target=r4kvMcV79HDh,args=(WnaR8GmjVCwcob6tNeJQ3TS1XL9U.XXwdYAmZkV80Dc7RSIOTE3,))
			OsvSfAzo3k6iDqa2b47Ln.start()
			VPRrOBpKoyX1atGz4c92MZfYiq5 = VVGXMeyJq25S6tf.Thread(target=gIkDSqPu05YZ,args=())
			VPRrOBpKoyX1atGz4c92MZfYiq5.start()
		else: WnaR8GmjVCwcob6tNeJQ3TS1XL9U.q1EjrzRPQJvuUolfY = pTwKPmzMSZhil5d2RWonre(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ৬")
def YxTzL85pRuX():
	RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf = QigevCplXxbPI1H,QigevCplXxbPI1H
	PyOsZ0lh2mc7K = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴ࡬ࡩࡳࡪ࡬ࡺࡐࡤࡱࡪ࠭৭"))
	try:
		GE3yjxMvKReYc8WaArH6Pf2oUu4qD = open(FF70emVxhWOngCty(u"ࠨ࠱ࡳࡶࡴࡩ࠯ࡤࡲࡸ࡭ࡳ࡬࡯ࠨ৮"),y5yX4jh6kUEgWZQIc(u"ࠩࡵࡦࠬ৯")).read()
		if b7sJAmSxlBvaMdHFz: GE3yjxMvKReYc8WaArH6Pf2oUu4qD = GE3yjxMvKReYc8WaArH6Pf2oUu4qD.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		hRpONZJ2woI = sBvufaD6c9YHdOqTjCQ3.findall(FF70emVxhWOngCty(u"ࠪࡗࡪࡸࡩࡢ࡮࠱࠮ࡄࡀࠠࠩ࠰࠭ࡃ࠮ࠪࠧৰ"),GE3yjxMvKReYc8WaArH6Pf2oUu4qD,sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if hRpONZJ2woI: RIoNvEKJ0xqTshdwH = hRpONZJ2woI[h17Zb2ld4yLBrCP5tiw]
	except: pass
	try:
		import subprocess as oPTIyjikBa
		WPR2Odv7lzr = oPTIyjikBa.Popen(tOrSvd8QKNB(u"ࠫࡸࡺࡡࡵࠢ࠰ࡧࠥࠨ࡚ࠠࠦࠣࠦࠥ࠵ࡳࡵࡱࡵࡥ࡬࡫࠯ࡦ࡯ࡸࡰࡦࡺࡥࡥ࠱࠳ࠤࡀࠦࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡛ࠥࠨࠠ࠰ࡸࡤࡶ࠴ࡲ࡯ࡨࠩৱ"),shell=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,stdin=oPTIyjikBa.PIPE,stdout=oPTIyjikBa.PIPE,stderr=oPTIyjikBa.PIPE)
		QqmPZEg8C6TGJxIWY4S5viOpHljARD = WPR2Odv7lzr.stdout.read()
		if QqmPZEg8C6TGJxIWY4S5viOpHljARD:
			if b7sJAmSxlBvaMdHFz:
				QqmPZEg8C6TGJxIWY4S5viOpHljARD = QqmPZEg8C6TGJxIWY4S5viOpHljARD.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,pGncXOodjKhJzLSqVP1r(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ৲"))
			CCdoxyR1t2nuhDWvSG = sBvufaD6c9YHdOqTjCQ3.findall(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠࠩ࡞ࡧࡿ࠶࠶ࡽࠪࠢࠪ৳"),QqmPZEg8C6TGJxIWY4S5viOpHljARD,sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
			if CCdoxyR1t2nuhDWvSG: XOhA98wyutGqoTDbKHEf = min(CCdoxyR1t2nuhDWvSG)
	except: pass
	return PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf
def U8bMvkLTxSzw5ac(E1lpZAJBhUtv9Wnfsa8c3OL,jDsFg6c9y7dK8X4eqRV2roaYL5IA=XpREPf7d08GnIS6i4KNLMyZHmuQqxD):
	ww8r1DfmOzUP9jGn = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if jDsFg6c9y7dK8X4eqRV2roaYL5IA:
		ZZos6yCG0PzilbJwOp93Efxc = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,svULcgJ7jm(u"ࠧ࡭࡫ࡶࡸࠬ৴"),g4UCaNkHvLwGhjmW(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ৵"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧ৶"))
		if ZZos6yCG0PzilbJwOp93Efxc:
			ooaqbuv0HeUB9Ex38A5ijTQ1g,Oa2rCoWv3KtLADy7HMpl0nJ8VhU,n4hmfNbLjuPWJTlXkz2wU9eE85FiD,TTx1Gvrbmznf2 = ZZos6yCG0PzilbJwOp93Efxc
			ww8r1DfmOzUP9jGn = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,pGncXOodjKhJzLSqVP1r(u"ࠪࡰ࡮ࡹࡴࠨ৷"),TCF8wLyDvgumfiXPSKRh(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ৸"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࡙ࠬࡉࡕࡇࡖࡣ࡛ࡋࡒࡊࡈ࡜ࠫ৹"))
			if ww8r1DfmOzUP9jGn: PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf = ww8r1DfmOzUP9jGn
			else: PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf = YxTzL85pRuX()
			if (Oa2rCoWv3KtLADy7HMpl0nJ8VhU,n4hmfNbLjuPWJTlXkz2wU9eE85FiD,TTx1Gvrbmznf2)==(PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf): return aSBkt4OU8JpWTEzVIHjAiv.join(ooaqbuv0HeUB9Ex38A5ijTQ1g)
	if ww8r1DfmOzUP9jGn: PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf = YxTzL85pRuX()
	global lhbgaJzc7iUjNo,Q8ckUXnpEeT5bV32v
	lhbgaJzc7iUjNo,Q8ckUXnpEeT5bV32v,XpEw5mUBZeO = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	E1lpZAJBhUtv9Wnfsa8c3OL = E1lpZAJBhUtv9Wnfsa8c3OL//JxuTQLOD357o41evylqPmRdf
	VVGXMeyJq25S6tf.Thread(target=U6UsyO8uFR2n).start()
	VVGXMeyJq25S6tf.Thread(target=bgfdYKAOUQcsEHIP5Zk1WN8oypSX).start()
	for GzabfJx3T1 in range(Xr2aHOK0huQ5DTS(u"࠱࠱ଅ")):
		B3TKLo71hAGRqYgV0.sleep(fk8jc5uDLX16qrih3ZaPxsvO(u"࠱࠰࠸ଆ"))
		if not XpEw5mUBZeO:
			try:
				LR7XE68TJCdl31DHyjzkvaNZm25nA = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(svULcgJ7jm(u"࠭ࡎࡦࡶࡺࡳࡷࡱ࠮ࡎࡣࡦࡅࡩࡪࡲࡦࡵࡶࠫ৺"))
				if LR7XE68TJCdl31DHyjzkvaNZm25nA.count(O4ylJvVNwLztdiHqBWDU(u"ࠧ࠻ࠩ৻"))==tg9l25NH6WTacVSifLyAmY(u"࠸ଈ") and LR7XE68TJCdl31DHyjzkvaNZm25nA.count(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨ࠲ࠪৼ"))<Xr2aHOK0huQ5DTS(u"࠻ଇ"):
					LR7XE68TJCdl31DHyjzkvaNZm25nA = LR7XE68TJCdl31DHyjzkvaNZm25nA.lower().replace(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࠽ࠫ৽"),QigevCplXxbPI1H)
					XpEw5mUBZeO = str(int(LR7XE68TJCdl31DHyjzkvaNZm25nA,tOrSvd8QKNB(u"࠵࠻ଉ")))
			except: pass
		if lhbgaJzc7iUjNo and Q8ckUXnpEeT5bV32v and XpEw5mUBZeO: break
	D0DPu3Zo8jXf = [lhbgaJzc7iUjNo,Q8ckUXnpEeT5bV32v,XpEw5mUBZeO,QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠪ࠴࠵࠷࠱࠳࠴࠶࠷࠹࠺࠵࠶࠸࠹࠻࠼࠭৾")]
	if RIoNvEKJ0xqTshdwH or XOhA98wyutGqoTDbKHEf:
		from hashlib import md5 as o2vzJrWZyOS0Dk73dNpubl
		ywgPfxNdj9r6DVA = [(bWU9StnJOg6aIQiTMxh7sFZG8lPud,RIoNvEKJ0xqTshdwH),(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠺ଊ"),XOhA98wyutGqoTDbKHEf)]
		for QQPBwuOv2LeWXTnYygj,AWiQJuPfExS2ey3KM6cVNFv4Ypa in ywgPfxNdj9r6DVA:
			AWiQJuPfExS2ey3KM6cVNFv4Ypa = AWiQJuPfExS2ey3KM6cVNFv4Ypa.strip(FF70emVxhWOngCty(u"ࠫ࠵࠭৿"))
			if AWiQJuPfExS2ey3KM6cVNFv4Ypa:
				if b7sJAmSxlBvaMdHFz: AWiQJuPfExS2ey3KM6cVNFv4Ypa = AWiQJuPfExS2ey3KM6cVNFv4Ypa.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				AWiQJuPfExS2ey3KM6cVNFv4Ypa = str(int(o2vzJrWZyOS0Dk73dNpubl(AWiQJuPfExS2ey3KM6cVNFv4Ypa).hexdigest(),pGncXOodjKhJzLSqVP1r(u"࠹࠶ଋ")))
				PPDvfMSbrKR0wLj59oxXYuAy = [int(AWiQJuPfExS2ey3KM6cVNFv4Ypa[pztU0SkDmP3cqy:pztU0SkDmP3cqy+vZL6j4tSClIGxzNE5DX(u"࠲࠷଍")]) for pztU0SkDmP3cqy in range(len(AWiQJuPfExS2ey3KM6cVNFv4Ypa)) if pztU0SkDmP3cqy%vZL6j4tSClIGxzNE5DX(u"࠲࠷଍")==pTwKPmzMSZhil5d2RWonre(u"࠰ଌ")]
				D0DPu3Zo8jXf[QQPBwuOv2LeWXTnYygj-nfC2im3NzUQk] = str(sum(PPDvfMSbrKR0wLj59oxXYuAy))
	ooaqbuv0HeUB9Ex38A5ijTQ1g,otwjELdCQJD9kG23AY = [],YoAMfqm37GyFxbuKTt6e8CESHrhB
	for W2IlpRkMYjOy in range(len(D0DPu3Zo8jXf)):
		PPDvfMSbrKR0wLj59oxXYuAy = D0DPu3Zo8jXf[W2IlpRkMYjOy]
		if not PPDvfMSbrKR0wLj59oxXYuAy: continue
		if otwjELdCQJD9kG23AY and PPDvfMSbrKR0wLj59oxXYuAy==D0DPu3Zo8jXf[-nfC2im3NzUQk]: continue
		otwjELdCQJD9kG23AY = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		PPDvfMSbrKR0wLj59oxXYuAy = K7bLVaiRkx0lgU5SQM(u"ࠬ࠶ࠧ਀")*E1lpZAJBhUtv9Wnfsa8c3OL+PPDvfMSbrKR0wLj59oxXYuAy
		PPDvfMSbrKR0wLj59oxXYuAy = PPDvfMSbrKR0wLj59oxXYuAy[-E1lpZAJBhUtv9Wnfsa8c3OL:]
		nEmifFhtwxC4Wk,lLP9IcGTnuskK0 = QigevCplXxbPI1H,QigevCplXxbPI1H
		b1dvHkxpJiynlF2gYoN8BS6tm4DwIc = str(int(Xr2aHOK0huQ5DTS(u"࠭࠹ࠨਁ")*(E1lpZAJBhUtv9Wnfsa8c3OL+nfC2im3NzUQk))-int(PPDvfMSbrKR0wLj59oxXYuAy))[-E1lpZAJBhUtv9Wnfsa8c3OL:]
		for ATh6upUgFnm1VybLRcHv2QiGEfX4 in list(range(h17Zb2ld4yLBrCP5tiw,E1lpZAJBhUtv9Wnfsa8c3OL,bWU9StnJOg6aIQiTMxh7sFZG8lPud)):
			nEmifFhtwxC4Wk += b1dvHkxpJiynlF2gYoN8BS6tm4DwIc[ATh6upUgFnm1VybLRcHv2QiGEfX4:ATh6upUgFnm1VybLRcHv2QiGEfX4+bWU9StnJOg6aIQiTMxh7sFZG8lPud]+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧ࠮ࠩਂ")
			lLP9IcGTnuskK0 += str(sum(map(int,PPDvfMSbrKR0wLj59oxXYuAy[ATh6upUgFnm1VybLRcHv2QiGEfX4:ATh6upUgFnm1VybLRcHv2QiGEfX4+bWU9StnJOg6aIQiTMxh7sFZG8lPud]))%Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠳࠳଎"))
		OgaznoRv17Y52AIwEq = str(W2IlpRkMYjOy)+nEmifFhtwxC4Wk+lLP9IcGTnuskK0
		ooaqbuv0HeUB9Ex38A5ijTQ1g.append(OgaznoRv17Y52AIwEq)
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,tOrSvd8QKNB(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫਃ"),K7bLVaiRkx0lgU5SQM(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ਄"),[PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf],pETKl7xuH1f5yjdFAb6C8JzOLV)
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,Fg72JX6T5DkPy(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ਅ"),tOrSvd8QKNB(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩਆ"),[ooaqbuv0HeUB9Ex38A5ijTQ1g,PyOsZ0lh2mc7K,RIoNvEKJ0xqTshdwH,XOhA98wyutGqoTDbKHEf],g6gNzml5rOsa8bBETxPCpnVj)
	return aSBkt4OU8JpWTEzVIHjAiv.join(ooaqbuv0HeUB9Ex38A5ijTQ1g)
def OOIHQRsiD2(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,m9TrBXjhwRgI,vBA4PehsH7aOQGDZi9zj2):
	T24Te3uDwBS5vLgUEAhF1O = str(zXCVN4eIxRJTrUD)[h17Zb2ld4yLBrCP5tiw:K7bLVaiRkx0lgU5SQM(u"࠵࠹࠵ଏ")].replace(aSBkt4OU8JpWTEzVIHjAiv,OOhnpQ8XvCVclGqdu(u"ࠬࡢ࡜࡯ࠩਇ")).replace(Ymkp8qFPsjovc57UT,mpusoZBJ6V(u"࠭࡜࡝ࡴࠪਈ")).replace(f1p0IN8alhrDKHyvqWk9UZ,hT7zFDpEyUqf8sXuN).replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN)
	if len(str(zXCVN4eIxRJTrUD))>pGncXOodjKhJzLSqVP1r(u"࠶࠺࠶ଐ"): T24Te3uDwBS5vLgUEAhF1O = T24Te3uDwBS5vLgUEAhF1O+Fg72JX6T5DkPy(u"ࠧࠡ࠰࠱࠲ࠬਉ")
	tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = str(VV4iSgTwskE6uyoBCl3ZDh7HQ)[h17Zb2ld4yLBrCP5tiw:bDt7Ya1VEio3(u"࠷࠻࠰଑")].replace(aSBkt4OU8JpWTEzVIHjAiv,bDt7Ya1VEio3(u"ࠨ࡞࡟ࡲࠬਊ")).replace(Ymkp8qFPsjovc57UT,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩ࡟ࡠࡷ࠭਋")).replace(f1p0IN8alhrDKHyvqWk9UZ,hT7zFDpEyUqf8sXuN).replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN)
	if len(str(VV4iSgTwskE6uyoBCl3ZDh7HQ))>tOrSvd8QKNB(u"࠸࠵࠱଒"): tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = tNQDMKVydhBqgaUvJ7oeAkTHxsL1+svULcgJ7jm(u"ࠪࠤ࠳࠴࠮ࠨ਌")
	SQdRhwozVfv(AwKhgdpmBj0,pGncXOodjKhJzLSqVP1r(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࠭਍")+NWdTSkYP5E6wqsDogApZmLCcbu3j2I+FF70emVxhWOngCty(u"ࠬࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ਎")+iCr0xsqwDZXLPaJK1W5YU24F6hp+tg9l25NH6WTacVSifLyAmY(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨਏ")+m9TrBXjhwRgI+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡵࡪࡲࡨ࠿࡛ࠦࠡࠩਐ")+vBA4PehsH7aOQGDZi9zj2+tg9l25NH6WTacVSifLyAmY(u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫ਑")+str(T24Te3uDwBS5vLgUEAhF1O)+v54ZuLY6dQ(u"ࠩࠣࡡࠥࠦࠠࡅࡣࡷࡥ࠿࡛ࠦࠡࠩ਒")+tNQDMKVydhBqgaUvJ7oeAkTHxsL1+FF70emVxhWOngCty(u"ࠪࠤࡢ࠭ਓ"))
	return
def U6UsyO8uFR2n():
	global lhbgaJzc7iUjNo
	import getmac82 as QokHw4auGeSmMlbCxp59BOWs
	try:
		K9KCEXDJ7wy3Hbeg8qFGhBa6fVSL = QokHw4auGeSmMlbCxp59BOWs.get_mac_address()
		if K9KCEXDJ7wy3Hbeg8qFGhBa6fVSL.count(y5yX4jh6kUEgWZQIc(u"ࠫ࠿࠭ਔ"))==O4ylJvVNwLztdiHqBWDU(u"࠶ଔ") and K9KCEXDJ7wy3Hbeg8qFGhBa6fVSL.count(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࠶ࠧਕ"))<DDHwpETQrAm0xMNXGfyhqsUi(u"࠹ଓ"):
			K9KCEXDJ7wy3Hbeg8qFGhBa6fVSL = K9KCEXDJ7wy3Hbeg8qFGhBa6fVSL.lower().replace(Fg72JX6T5DkPy(u"࠭࠺ࠨਖ"),QigevCplXxbPI1H)
			lhbgaJzc7iUjNo = str(int(K9KCEXDJ7wy3Hbeg8qFGhBa6fVSL,O4ylJvVNwLztdiHqBWDU(u"࠳࠹କ")))
	except: pass
	return
def bgfdYKAOUQcsEHIP5Zk1WN8oypSX():
	global Q8ckUXnpEeT5bV32v
	import getmac94 as lWhUCwimvALjIQgJsH5y2Bz3R9
	try:
		Wf0JcN4LQtxIjrpzB = lWhUCwimvALjIQgJsH5y2Bz3R9.get_mac_address()
		if Wf0JcN4LQtxIjrpzB.count(v54ZuLY6dQ(u"ࠧ࠻ࠩਗ"))==mmKqLr9RX0ACN384JMcsFHzd(u"࠹ଗ") and Wf0JcN4LQtxIjrpzB.count(y5yX4jh6kUEgWZQIc(u"ࠨ࠲ࠪਘ"))<hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠼ଖ"):
			Wf0JcN4LQtxIjrpzB = Wf0JcN4LQtxIjrpzB.lower().replace(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩ࠽ࠫਙ"),QigevCplXxbPI1H)
			Q8ckUXnpEeT5bV32v = str(int(Wf0JcN4LQtxIjrpzB,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠶࠼ଘ")))
	except: pass
	return
def jZmIRWGxy60AongCuFOpMJV(vBA4PehsH7aOQGDZi9zj2,iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ=QigevCplXxbPI1H,zXCVN4eIxRJTrUD=QigevCplXxbPI1H,m9TrBXjhwRgI=QigevCplXxbPI1H):
	OOIHQRsiD2(K7bLVaiRkx0lgU5SQM(u"࡙ࠪࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡏࡑࡇࡑࡣ࡚ࡘࡌࠨਚ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,m9TrBXjhwRgI,vBA4PehsH7aOQGDZi9zj2)
	if b7sJAmSxlBvaMdHFz: import urllib.request as z3rh4lMBgWmP5cT2Z1KsJdF0L8ka
	else: import urllib2 as z3rh4lMBgWmP5cT2Z1KsJdF0L8ka
	if not zXCVN4eIxRJTrUD: zXCVN4eIxRJTrUD = {O4ylJvVNwLztdiHqBWDU(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਛ"):QigevCplXxbPI1H}
	if not VV4iSgTwskE6uyoBCl3ZDh7HQ: VV4iSgTwskE6uyoBCl3ZDh7HQ = {}
	if vBA4PehsH7aOQGDZi9zj2==FF70emVxhWOngCty(u"ࠬࡍࡅࡕࠩਜ"):
		iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp+Xr2aHOK0huQ5DTS(u"࠭࠿ࠨਝ")+q8KvkirVNMoRIB5eJ(VV4iSgTwskE6uyoBCl3ZDh7HQ)
		VV4iSgTwskE6uyoBCl3ZDh7HQ = None
	elif vBA4PehsH7aOQGDZi9zj2==TCF8wLyDvgumfiXPSKRh(u"ࠧࡑࡑࡖࡘࠬਞ") and Xr2aHOK0huQ5DTS(u"ࠨ࡬ࡶࡳࡳ࠭ਟ") in str(zXCVN4eIxRJTrUD):
		from json import dumps as A9EuBOqiFelKUSzQMgc
		VV4iSgTwskE6uyoBCl3ZDh7HQ = A9EuBOqiFelKUSzQMgc(VV4iSgTwskE6uyoBCl3ZDh7HQ)
		VV4iSgTwskE6uyoBCl3ZDh7HQ = str(VV4iSgTwskE6uyoBCl3ZDh7HQ).encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	elif vBA4PehsH7aOQGDZi9zj2==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡓࡓࡘ࡚ࠧਠ"):
		VV4iSgTwskE6uyoBCl3ZDh7HQ = q8KvkirVNMoRIB5eJ(VV4iSgTwskE6uyoBCl3ZDh7HQ)
		VV4iSgTwskE6uyoBCl3ZDh7HQ = VV4iSgTwskE6uyoBCl3ZDh7HQ.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	try:
		UovfLkmA28IKFW3HNeawt49gh5xQ = z3rh4lMBgWmP5cT2Z1KsJdF0L8ka.Request(iCr0xsqwDZXLPaJK1W5YU24F6hp,headers=zXCVN4eIxRJTrUD,data=VV4iSgTwskE6uyoBCl3ZDh7HQ)
		lE7ZB0CTayhKItApFnYxz = z3rh4lMBgWmP5cT2Z1KsJdF0L8ka.urlopen(UovfLkmA28IKFW3HNeawt49gh5xQ)
		zHrPxh0aevGnlKMTdjQsV = lE7ZB0CTayhKItApFnYxz.read()
		kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp = fk8jc5uDLX16qrih3ZaPxsvO(u"࠸࠰࠱ଙ"),s0vAWcLSXEToH9Mik134q(u"ࠪࡓࡐ࠭ਡ")
	except:
		zHrPxh0aevGnlKMTdjQsV = QigevCplXxbPI1H
		kQKmN8hHvzcC6PWtbJqr4aL9,C4RUnz8IDZ15uXOqG96F2kSTNiygp = -nfC2im3NzUQk,pTwKPmzMSZhil5d2RWonre(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡋࡲࡳࡱࡵࠫਢ")
	SQdRhwozVfv(AwKhgdpmBj0,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇࡢࡴ࡝ࡶࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧਣ")+str(kQKmN8hHvzcC6PWtbJqr4aL9)+fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨਤ")+C4RUnz8IDZ15uXOqG96F2kSTNiygp+TCF8wLyDvgumfiXPSKRh(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩਥ")+m9TrBXjhwRgI+mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧਦ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+JJu4MPClbTFpUwHiN(u"ࠩࠣࡡࠬਧ"))
	if zHrPxh0aevGnlKMTdjQsV and b7sJAmSxlBvaMdHFz: zHrPxh0aevGnlKMTdjQsV = zHrPxh0aevGnlKMTdjQsV.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	return zHrPxh0aevGnlKMTdjQsV
def HNLnAOlivm(mGBPrzn5OcJfRw3lsiaKpZ9L,sFZgkoiXlB82xCm516qYGd9RwEuj3=QigevCplXxbPI1H):
	ta5uJnT9B2opZEQKPckSV0j6G = str(yarjPEMGV6m7fHRFeJXt.randrange(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵ଚ"),v54ZuLY6dQ(u"࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾ଛ")))
	zXCVN4eIxRJTrUD = {DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩਨ"):OTRKI6LbrQnZEm(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧ਩")}
	oAlaehOSGbn = {	v54ZuLY6dQ(u"ࠧࡻࡳࡦࡴࡢ࡭ࡩࠨਪ"):U8bMvkLTxSzw5ac(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠶ଝ")).splitlines()[h17Zb2ld4yLBrCP5tiw][-WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠴࠷ଜ"):],
				tOrSvd8QKNB(u"ࠨ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠥਫ"):str(aybmzWnDkuEcT3jpJClB2),
				y5yX4jh6kUEgWZQIc(u"ࠢࡢࡲࡳࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧਬ"):GVmdqbtLu8lUXNxp13aHOvkscR,
				v54ZuLY6dQ(u"ࠣࡦࡨࡺ࡮ࡩࡥࡠࡨࡤࡱ࡮ࡲࡹࠣਭ"):GVmdqbtLu8lUXNxp13aHOvkscR,
				O4ylJvVNwLztdiHqBWDU(u"ࠤࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪࠨਮ"):mGBPrzn5OcJfRw3lsiaKpZ9L,
				s0vAWcLSXEToH9Mik134q(u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࠧਯ"): GVmdqbtLu8lUXNxp13aHOvkscR,
				pGncXOodjKhJzLSqVP1r(u"ࠦࡨࡧࡲࡳ࡫ࡨࡶࠧਰ"):hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࠧ਱"),
				DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠤਲ"):{hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠢࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦਲ਼"):mGBPrzn5OcJfRw3lsiaKpZ9L},
				hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠣࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ਴"): {bDt7Ya1VEio3(u"ࠤࡘࡷࡪࡸ࡟ࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦਵ"):mGBPrzn5OcJfRw3lsiaKpZ9L},
				QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠥࠨࡸࡱࡩࡱࡡࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࡣࡸࡿ࡮ࡤࠤਸ਼"):YoAMfqm37GyFxbuKTt6e8CESHrhB,
				vZL6j4tSClIGxzNE5DX(u"ࠦ࡮ࡶࠢ਷"): NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࠪࡲࡦ࡯ࡲࡸࡪࠨਸ")
			}
	if not sFZgkoiXlB82xCm516qYGd9RwEuj3: TUZyEHAg9Gc6blWFoOX2qf7Rpt = [oAlaehOSGbn]
	else:
		U8QFCsHiw1gyLRrftA53lmqJ7NPKh = oAlaehOSGbn.copy()
		U8QFCsHiw1gyLRrftA53lmqJ7NPKh[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪਹ")] = sFZgkoiXlB82xCm516qYGd9RwEuj3
		U8QFCsHiw1gyLRrftA53lmqJ7NPKh[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ਺")] = {pGncXOodjKhJzLSqVP1r(u"ࠣࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ਻"):sFZgkoiXlB82xCm516qYGd9RwEuj3}
		U8QFCsHiw1gyLRrftA53lmqJ7NPKh[FF70emVxhWOngCty(u"ࠩࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶ਼ࠫ")] = {WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࡙ࠥࡸ࡫ࡲࡠࡇࡹࡩࡳࡺ࡟ࡏࡣࡰࡩࠧ਽"):sFZgkoiXlB82xCm516qYGd9RwEuj3}
		TUZyEHAg9Gc6blWFoOX2qf7Rpt = [oAlaehOSGbn,U8QFCsHiw1gyLRrftA53lmqJ7NPKh]
	VV4iSgTwskE6uyoBCl3ZDh7HQ = {mpusoZBJ6V(u"ࠦࡦࡶࡩࡠ࡭ࡨࡽࠧਾ"):svULcgJ7jm(u"ࠬ࠸࠵࠵ࡦࡧ࠷ࡦ࠺࠰࠺ࡦ࠻ࡦ࠻࠾࠱ࡥ࠶ࡨ࠵࠶࠽ࡥࡦ࠹࠻ࡧࡪࡨࡦ࠳࠻ࠪਿ"),
			pTwKPmzMSZhil5d2RWonre(u"ࠨࡩ࡯ࡵࡨࡶࡹࡥࡩࡥࠤੀ"):ta5uJnT9B2opZEQKPckSV0j6G,
			VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠢࡦࡸࡨࡲࡹࡹࠢੁ"): TUZyEHAg9Gc6blWFoOX2qf7Rpt
		}
	iCr0xsqwDZXLPaJK1W5YU24F6hp = g4UCaNkHvLwGhjmW(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠸࠮ࡢ࡯ࡳࡰ࡮ࡺࡵࡥࡧ࠱ࡧࡴࡳ࠯࠳࠱࡫ࡸࡹࡶࡡࡱ࡫ࠪੂ")
	zHrPxh0aevGnlKMTdjQsV = jZmIRWGxy60AongCuFOpMJV(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡓࡓࡘ࡚ࠧ੃"),iCr0xsqwDZXLPaJK1W5YU24F6hp,VV4iSgTwskE6uyoBCl3ZDh7HQ,zXCVN4eIxRJTrUD,s0vAWcLSXEToH9Mik134q(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ੄"))
	return zHrPxh0aevGnlKMTdjQsV
def CH86N7xw4cyPt3TlIBJF(xXg50B8W9Koq,CyarqoiHxV2e80ScjAN):
	CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.replace(OTRKI6LbrQnZEm(u"ࠫࡳࡻ࡬࡭ࠩ੅"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡔ࡯࡯ࡧࠪ੆"))
	CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.replace(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡴࡳࡷࡨࠫੇ"),s0vAWcLSXEToH9Mik134q(u"ࠧࡕࡴࡸࡩࠬੈ"))
	CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.replace(pGncXOodjKhJzLSqVP1r(u"ࠨࡨࡤࡰࡸ࡫ࠧ੉"),JJu4MPClbTFpUwHiN(u"ࠩࡉࡥࡱࡹࡥࠨ੊"))
	CyarqoiHxV2e80ScjAN = CyarqoiHxV2e80ScjAN.replace(v54ZuLY6dQ(u"ࠪࡠ࠴࠭ੋ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ࠴࠭ੌ"))
	try: rtZM5KYaGepo7F2 = eval(CyarqoiHxV2e80ScjAN)
	except: rtZM5KYaGepo7F2 = ALZXz4TgYUtb9r5CEnad2yqBF(xXg50B8W9Koq)
	return rtZM5KYaGepo7F2
def VKsQmdD8RBlM4pzPZUocJXH75bejI():
	NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = c79RqAVuZjN1UaSOPB(MYIqLm4Nyhniu6QORWlrp)
	UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall(mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡ࡞࡞࠳ࡈࡕࡌࡐࡔ࡟ࡡ੍ࠬ"),yBWPDAeJF1o2b,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if UX3RT0evEunCm2cHIz1Qs: yBWPDAeJF1o2b = yBWPDAeJF1o2b.split(UX3RT0evEunCm2cHIz1Qs[h17Zb2ld4yLBrCP5tiw],JJu4MPClbTFpUwHiN(u"࠵ଞ"))[nfC2im3NzUQk]
	EEQ7ZxANwPIugLy = B3TKLo71hAGRqYgV0.strftime(bDt7Ya1VEio3(u"࠭࡟ࠦ࡯࠱ࠩࡩࡥࠥࡉ࠼ࠨࡑࡤ࠭੎"),B3TKLo71hAGRqYgV0.localtime(qyUPZBiAE3YkuOKrMnTFex92D))
	yBWPDAeJF1o2b = yBWPDAeJF1o2b+EEQ7ZxANwPIugLy
	dd9H4XLuJQGqki = NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(Nk7BzXcC5VbpSanw):
		MPuNKf0A87TUDJkxs15o = open(Nk7BzXcC5VbpSanw,pTwKPmzMSZhil5d2RWonre(u"ࠧࡳࡤࠪ੏")).read()
		if b7sJAmSxlBvaMdHFz: MPuNKf0A87TUDJkxs15o = MPuNKf0A87TUDJkxs15o.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		MPuNKf0A87TUDJkxs15o = CH86N7xw4cyPt3TlIBJF(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡦ࡬ࡧࡹ࠭੐"),MPuNKf0A87TUDJkxs15o)
	else: MPuNKf0A87TUDJkxs15o = {}
	OksXbHD6tZEGfzA = {}
	for DqTYh4ZMjAw in list(MPuNKf0A87TUDJkxs15o.keys()):
		if DqTYh4ZMjAw!=NWdTSkYP5E6wqsDogApZmLCcbu3j2I: OksXbHD6tZEGfzA[DqTYh4ZMjAw] = MPuNKf0A87TUDJkxs15o[DqTYh4ZMjAw]
		else:
			if yBWPDAeJF1o2b and yBWPDAeJF1o2b!=svULcgJ7jm(u"ࠩ࠱࠲ࠬੑ"):
				S89sGzND3RyKEYp75TVXul = MPuNKf0A87TUDJkxs15o[DqTYh4ZMjAw]
				if dd9H4XLuJQGqki in S89sGzND3RyKEYp75TVXul:
					nVWUleSBvsKaEhoCxNryf = S89sGzND3RyKEYp75TVXul.index(dd9H4XLuJQGqki)
					del S89sGzND3RyKEYp75TVXul[nVWUleSBvsKaEhoCxNryf]
				rjlBpomcFhUsDGY423A9 = [dd9H4XLuJQGqki]+S89sGzND3RyKEYp75TVXul
				rjlBpomcFhUsDGY423A9 = rjlBpomcFhUsDGY423A9[:FF70emVxhWOngCty(u"࠺࠶ଟ")]
				OksXbHD6tZEGfzA[DqTYh4ZMjAw] = rjlBpomcFhUsDGY423A9
			else: OksXbHD6tZEGfzA[DqTYh4ZMjAw] = MPuNKf0A87TUDJkxs15o[DqTYh4ZMjAw]
	if NWdTSkYP5E6wqsDogApZmLCcbu3j2I not in list(OksXbHD6tZEGfzA.keys()): OksXbHD6tZEGfzA[NWdTSkYP5E6wqsDogApZmLCcbu3j2I] = [dd9H4XLuJQGqki]
	OksXbHD6tZEGfzA = str(OksXbHD6tZEGfzA)
	if b7sJAmSxlBvaMdHFz: OksXbHD6tZEGfzA = OksXbHD6tZEGfzA.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	open(Nk7BzXcC5VbpSanw,g4UCaNkHvLwGhjmW(u"ࠪࡻࡧ࠭੒")).write(OksXbHD6tZEGfzA)
	return
def BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(aYXiUPQDVd7hjTsumgL,mK39DivOJWl6dj1oGbx50nreIcP8,F51kHeuSfO0yg,VV4iSgTwskE6uyoBCl3ZDh7HQ,WoITajU9q2EgcGKFbnm1,eOlq3kroBXAj206Kpga5cTJ=YoAMfqm37GyFxbuKTt6e8CESHrhB):
	xU4Y951Jcpf6jKGPOSemWILdCEZvg = uUTRHgAXJzm7pIDBjNt8.getSetting(g4UCaNkHvLwGhjmW(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ੓"))
	if xU4Y951Jcpf6jKGPOSemWILdCEZvg==bDt7Ya1VEio3(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭੔") and WoITajU9q2EgcGKFbnm1>S8BEV2s9fbO14kaX: WoITajU9q2EgcGKFbnm1 = S8BEV2s9fbO14kaX
	if eOlq3kroBXAj206Kpga5cTJ:
		T9Ax7pUEP6Ilg4cC,MO4AKUmTp2kJjR8tVZ = [],[]
		for GzabfJx3T1 in range(len(F51kHeuSfO0yg)):
			CyarqoiHxV2e80ScjAN = GqDnWM523CgyzifeoIHvwEtSl0FP.dumps(VV4iSgTwskE6uyoBCl3ZDh7HQ[GzabfJx3T1])
			vWZQajHdKx7b4qT3GX02tFyfDN5csn = NitQwg0RoyESdkOU3D4pqu.compress(CyarqoiHxV2e80ScjAN)
			T9Ax7pUEP6Ilg4cC.append((F51kHeuSfO0yg[GzabfJx3T1],))
			MO4AKUmTp2kJjR8tVZ.append((WoITajU9q2EgcGKFbnm1+qyUPZBiAE3YkuOKrMnTFex92D,str(F51kHeuSfO0yg[GzabfJx3T1]),vWZQajHdKx7b4qT3GX02tFyfDN5csn))
	else:
		CyarqoiHxV2e80ScjAN = GqDnWM523CgyzifeoIHvwEtSl0FP.dumps(VV4iSgTwskE6uyoBCl3ZDh7HQ)
		jIzXQVS9lg6orD5vF = NitQwg0RoyESdkOU3D4pqu.compress(CyarqoiHxV2e80ScjAN)
	try: R2wuKSVBTLW4sAOQNob18UEdGf0hv,B6xRu5lFyJ = gomHdCqRMikpnujeWJ2XSZL(aYXiUPQDVd7hjTsumgL)
	except: return
	while XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
		try:
			B6xRu5lFyJ.execute(g4UCaNkHvLwGhjmW(u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨ੕"))
			break
		except: B3TKLo71hAGRqYgV0.sleep(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠶࠮࠶ଠ"))
	B6xRu5lFyJ.execute(mpusoZBJ6V(u"ࠧࡄࡔࡈࡅ࡙ࡋࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡑࡓ࡙ࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ੖")+mK39DivOJWl6dj1oGbx50nreIcP8+XWbHfI9B8swrOL(u"ࠨࠤࠣࠬࡪࡾࡰࡪࡴࡼ࠰ࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠫࠣ࠿ࠬ੗"))
	if eOlq3kroBXAj206Kpga5cTJ:
		B6xRu5lFyJ.executemany(Xr2aHOK0huQ5DTS(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ੘")+mK39DivOJWl6dj1oGbx50nreIcP8+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪਖ਼"),T9Ax7pUEP6Ilg4cC)
		B6xRu5lFyJ.executemany(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫਗ਼")+mK39DivOJWl6dj1oGbx50nreIcP8+XWbHfI9B8swrOL(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪਜ਼"),MO4AKUmTp2kJjR8tVZ)
	else:
		if WoITajU9q2EgcGKFbnm1:
			SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX = (str(F51kHeuSfO0yg),)
			B6xRu5lFyJ.execute(tOrSvd8QKNB(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭ੜ")+mK39DivOJWl6dj1oGbx50nreIcP8+K7bLVaiRkx0lgU5SQM(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ੝"),SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX)
			SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX = (WoITajU9q2EgcGKFbnm1+qyUPZBiAE3YkuOKrMnTFex92D,str(F51kHeuSfO0yg),jIzXQVS9lg6orD5vF)
			B6xRu5lFyJ.execute(Xr2aHOK0huQ5DTS(u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨਫ਼")+mK39DivOJWl6dj1oGbx50nreIcP8+mpusoZBJ6V(u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ੟"),SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX)
		else:
			SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX = (jIzXQVS9lg6orD5vF,str(F51kHeuSfO0yg))
			B6xRu5lFyJ.execute(OOhnpQ8XvCVclGqdu(u"࡙ࠪࡕࡊࡁࡕࡇࠣࠦࠬ੠")+mK39DivOJWl6dj1oGbx50nreIcP8+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࠧࠦࡓࡆࡖࠣࡨࡦࡺࡡࠡ࠿ࠣࡃࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ੡"),SQtkNIZTb1K2qzy5hfxWOHgFvJPwYX)
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	return
def q8KvkirVNMoRIB5eJ(VV4iSgTwskE6uyoBCl3ZDh7HQ):
	if b7sJAmSxlBvaMdHFz: import urllib.parse as GRJC8jBythUEIf63eQb
	else: import urllib as GRJC8jBythUEIf63eQb
	Jv1PBEeFRniDzbYQh2mS8lpI76 = GRJC8jBythUEIf63eQb.urlencode(VV4iSgTwskE6uyoBCl3ZDh7HQ)
	return Jv1PBEeFRniDzbYQh2mS8lpI76
q1EjrzRPQJvuUolfY = QigevCplXxbPI1H
def B9BaTCd86Iwz1e3sRMXZylKpcHU(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,GrSXDiIwqHsVeZ2Y4K9kWj=QigevCplXxbPI1H,ut0GrdCjHJDIEgyOsvUTNLVF2=QigevCplXxbPI1H):
	StF7gAOLnb6jh3zEJrkPBWTyHZ = GrSXDiIwqHsVeZ2Y4K9kWj not in [NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡓ࠳ࡖࠩ੢"),tOrSvd8QKNB(u"࠭ࡉࡑࡖ࡙ࠫ੣")]
	global q1EjrzRPQJvuUolfY
	if not ut0GrdCjHJDIEgyOsvUTNLVF2: ut0GrdCjHJDIEgyOsvUTNLVF2 = O4ylJvVNwLztdiHqBWDU(u"ࠧࡷ࡫ࡧࡩࡴ࠭੤")
	q1EjrzRPQJvuUolfY,AALrfaosIbKUj5N6wqZ,aigfcr5We4qGY9Bwz = pTwKPmzMSZhil5d2RWonre(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ੥"),QigevCplXxbPI1H,QigevCplXxbPI1H
	if len(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)==mVjHAyIwzSNKLFcd:
		iCr0xsqwDZXLPaJK1W5YU24F6hp,yo15fA6eX7l4sPvFjWVGDtEK,aigfcr5We4qGY9Bwz = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx
		if yo15fA6eX7l4sPvFjWVGDtEK: AALrfaosIbKUj5N6wqZ = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫ੦")+yo15fA6eX7l4sPvFjWVGDtEK+pTwKPmzMSZhil5d2RWonre(u"ࠪࠤࡢ࠭੧")
	else: iCr0xsqwDZXLPaJK1W5YU24F6hp,yo15fA6eX7l4sPvFjWVGDtEK,aigfcr5We4qGY9Bwz = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,QigevCplXxbPI1H,QigevCplXxbPI1H
	iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp.replace(OTRKI6LbrQnZEm(u"ࠫࠪ࠸࠰ࠨ੨"),hT7zFDpEyUqf8sXuN)
	denYhNEq72TZSD0psXick9tzg5 = z2dZ1anR6O(iCr0xsqwDZXLPaJK1W5YU24F6hp)
	if GrSXDiIwqHsVeZ2Y4K9kWj not in [v54ZuLY6dQ(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੩"),tOrSvd8QKNB(u"࠭ࡉࡑࡖ࡙ࠫ੪")]:
		if GrSXDiIwqHsVeZ2Y4K9kWj!=v54ZuLY6dQ(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ੫"): iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp.replace(hT7zFDpEyUqf8sXuN,s0vAWcLSXEToH9Mik134q(u"ࠨࠧ࠵࠴ࠬ੬"))
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OTRKI6LbrQnZEm(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ੭")+iCr0xsqwDZXLPaJK1W5YU24F6hp+svULcgJ7jm(u"ࠪࠤࡢ࠭੮")+AALrfaosIbKUj5N6wqZ)
		if denYhNEq72TZSD0psXick9tzg5==vZL6j4tSClIGxzNE5DX(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ੯") and GrSXDiIwqHsVeZ2Y4K9kWj not in [WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡏࡐࡕࡘࠪੰ"),y5yX4jh6kUEgWZQIc(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧੱ")]:
			from TEsNM9QVZc import HHSM1J4ofulwIPqTjnQA,zYWJO03iISD,X69Fkr1VNnf2pJQC8wl7YR4HmaKc
			ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = HHSM1J4ofulwIPqTjnQA(iCr0xsqwDZXLPaJK1W5YU24F6hp)
			S6bnmEiKxr0JUvHMt5pgsjV = len(ldFqnNIsftrY43JBM6LPjzU8m)
			if S6bnmEiKxr0JUvHMt5pgsjV>nfC2im3NzUQk:
				HHZ6579kAv8 = zYWJO03iISD(FF70emVxhWOngCty(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨੲ")+str(S6bnmEiKxr0JUvHMt5pgsjV)+Fg72JX6T5DkPy(u"ࠨ่่ࠢๆ࠯ࠧੳ"), ttGBwQOv3K41hIkc6)
				if HHZ6579kAv8==-nfC2im3NzUQk:
					X69Fkr1VNnf2pJQC8wl7YR4HmaKc(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧੴ"),TCF8wLyDvgumfiXPSKRh(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪੵ"))
					return q1EjrzRPQJvuUolfY
			else: HHZ6579kAv8 = h17Zb2ld4yLBrCP5tiw
			iCr0xsqwDZXLPaJK1W5YU24F6hp = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
			if ttGBwQOv3K41hIkc6[h17Zb2ld4yLBrCP5tiw]!=JJu4MPClbTFpUwHiN(u"ࠫ࠲࠷ࠧ੶"):
				SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ੷")+ttGBwQOv3K41hIkc6[HHZ6579kAv8]+pGncXOodjKhJzLSqVP1r(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ੸")+iCr0xsqwDZXLPaJK1W5YU24F6hp+K7bLVaiRkx0lgU5SQM(u"ࠧࠡ࡟ࠪ੹"))
		if TCF8wLyDvgumfiXPSKRh(u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩ੺") in iCr0xsqwDZXLPaJK1W5YU24F6hp: iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp+O4ylJvVNwLztdiHqBWDU(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ੻")
		elif vZL6j4tSClIGxzNE5DX(u"ࠪ࡬ࡹࡺࡰࠨ੼") in iCr0xsqwDZXLPaJK1W5YU24F6hp.lower() and NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ੽") not in iCr0xsqwDZXLPaJK1W5YU24F6hp and OOhnpQ8XvCVclGqdu(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ੾") not in iCr0xsqwDZXLPaJK1W5YU24F6hp:
			iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp+svULcgJ7jm(u"࠭ࡼࠨ੿") if fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡽࠩ઀") not in iCr0xsqwDZXLPaJK1W5YU24F6hp else iCr0xsqwDZXLPaJK1W5YU24F6hp+mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࠨࠪઁ")
			if JJu4MPClbTFpUwHiN(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࠧં") not in iCr0xsqwDZXLPaJK1W5YU24F6hp and hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬઃ") in iCr0xsqwDZXLPaJK1W5YU24F6hp.lower(): iCr0xsqwDZXLPaJK1W5YU24F6hp += OOhnpQ8XvCVclGqdu(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡈࡤࡰࡸ࡫ࠦࠨ઄")
			if Fg72JX6T5DkPy(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵ࠿ࠪઅ") not in iCr0xsqwDZXLPaJK1W5YU24F6hp.lower() and GrSXDiIwqHsVeZ2Y4K9kWj not in [tg9l25NH6WTacVSifLyAmY(u"࠭ࡉࡑࡖ࡙ࠫઆ"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡎ࠵ࡘࠫઇ")]: iCr0xsqwDZXLPaJK1W5YU24F6hp += Xr2aHOK0huQ5DTS(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧઈ")
			if TCF8wLyDvgumfiXPSKRh(u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࡀࠫઉ") not in iCr0xsqwDZXLPaJK1W5YU24F6hp.lower(): iCr0xsqwDZXLPaJK1W5YU24F6hp += OOhnpQ8XvCVclGqdu(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࠨࠪઊ")
	SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+mpusoZBJ6V(u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬઋ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+mpusoZBJ6V(u"ࠬࠦ࡝ࠨઌ"))
	RX03OLEFbDVscYoirQNv6nk5ehlTzy = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ListItem()
	ut0GrdCjHJDIEgyOsvUTNLVF2,AYvyVPneLu0gCIObkQRrKFNwqD9,BhrLoijzPEQdMFf4G981Kl,OQzUY9RicH,XXQM6ytjGOkW,RsTtrzxBK961JWwk4,XULthrmAYvfVx9M0dkZaz2n,uqeGx2DZ6SngyVPwj,n8uzSqGdeImPR = c79RqAVuZjN1UaSOPB(MYIqLm4Nyhniu6QORWlrp)
	if GrSXDiIwqHsVeZ2Y4K9kWj not in [Fg72JX6T5DkPy(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨઍ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡊࡒࡗ࡚ࠬ઎")]:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: bGnkZM85y9WAJN7Ho46 = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫએ")
		else: bGnkZM85y9WAJN7Ho46 = vZL6j4tSClIGxzNE5DX(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࠧઐ")
		RX03OLEFbDVscYoirQNv6nk5ehlTzy.setProperty(bGnkZM85y9WAJN7Ho46, QigevCplXxbPI1H)
		RX03OLEFbDVscYoirQNv6nk5ehlTzy.setMimeType(tg9l25NH6WTacVSifLyAmY(u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨઑ"))
		if aybmzWnDkuEcT3jpJClB2<y5yX4jh6kUEgWZQIc(u"࠲࠱ଡ"): RX03OLEFbDVscYoirQNv6nk5ehlTzy.setInfo(OTRKI6LbrQnZEm(u"ࠫࡻ࡯ࡤࡦࡱࠪ઒"),{mpusoZBJ6V(u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨઓ"):Fg72JX6T5DkPy(u"࠭࡭ࡰࡸ࡬ࡩࠬઔ")})
		else:
			g3ITXkylLYKERbmacox71V = RX03OLEFbDVscYoirQNv6nk5ehlTzy.getVideoInfoTag()
			g3ITXkylLYKERbmacox71V.setMediaType(XWbHfI9B8swrOL(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭ક"))
		RX03OLEFbDVscYoirQNv6nk5ehlTzy.setArt({s0vAWcLSXEToH9Mik134q(u"ࠨࡶ࡫ࡹࡲࡨࠧખ"):XXQM6ytjGOkW,vZL6j4tSClIGxzNE5DX(u"ࠩࡳࡳࡸࡺࡥࡳࠩગ"):XXQM6ytjGOkW,tOrSvd8QKNB(u"ࠪࡦࡦࡴ࡮ࡦࡴࠪઘ"):XXQM6ytjGOkW,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫઙ"):XXQM6ytjGOkW,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧચ"):XXQM6ytjGOkW,mpusoZBJ6V(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩછ"):XXQM6ytjGOkW,svULcgJ7jm(u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪજ"):XXQM6ytjGOkW,tOrSvd8QKNB(u"ࠨ࡫ࡦࡳࡳ࠭ઝ"):XXQM6ytjGOkW})
		if denYhNEq72TZSD0psXick9tzg5 in [pTwKPmzMSZhil5d2RWonre(u"ࠩ࠱ࡱࡵࡪࠧઞ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩટ")]: RX03OLEFbDVscYoirQNv6nk5ehlTzy.setContentLookup(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		else: RX03OLEFbDVscYoirQNv6nk5ehlTzy.setContentLookup(YoAMfqm37GyFxbuKTt6e8CESHrhB)
		from WZPsXYo7QE import UU8FkvnySO
		if FF70emVxhWOngCty(u"ࠫࡷࡺ࡭ࡱࠩઠ") in iCr0xsqwDZXLPaJK1W5YU24F6hp:
			UU8FkvnySO(FF70emVxhWOngCty(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨડ"),YoAMfqm37GyFxbuKTt6e8CESHrhB)
		elif denYhNEq72TZSD0psXick9tzg5==Fg72JX6T5DkPy(u"࠭࠮࡮ࡲࡧࠫઢ") or tOrSvd8QKNB(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧણ") in iCr0xsqwDZXLPaJK1W5YU24F6hp:
			UU8FkvnySO(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨત"),YoAMfqm37GyFxbuKTt6e8CESHrhB)
			RX03OLEFbDVscYoirQNv6nk5ehlTzy.setProperty(bGnkZM85y9WAJN7Ho46,v54ZuLY6dQ(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩથ"))
			RX03OLEFbDVscYoirQNv6nk5ehlTzy.setProperty(XWbHfI9B8swrOL(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪદ"),bDt7Ya1VEio3(u"ࠫࡲࡶࡤࠨધ"))
		if yo15fA6eX7l4sPvFjWVGDtEK:
			RX03OLEFbDVscYoirQNv6nk5ehlTzy.setSubtitles([yo15fA6eX7l4sPvFjWVGDtEK])
	if ut0GrdCjHJDIEgyOsvUTNLVF2==g4UCaNkHvLwGhjmW(u"ࠬࡼࡩࡥࡧࡲࠫન") and GrSXDiIwqHsVeZ2Y4K9kWj==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ઩"):
		q1EjrzRPQJvuUolfY = v54ZuLY6dQ(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧપ")
		GrSXDiIwqHsVeZ2Y4K9kWj = mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨફ")
	elif ut0GrdCjHJDIEgyOsvUTNLVF2==FF70emVxhWOngCty(u"ࠩࡹ࡭ࡩ࡫࡯ࠨબ") and uqeGx2DZ6SngyVPwj.startswith(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪ࠺ࠬભ")):
		q1EjrzRPQJvuUolfY = y5yX4jh6kUEgWZQIc(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭મ")
		GrSXDiIwqHsVeZ2Y4K9kWj = GrSXDiIwqHsVeZ2Y4K9kWj+mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡥࡄࡍࠩય")
	if q1EjrzRPQJvuUolfY!=bDt7Ya1VEio3(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨર"): VKsQmdD8RBlM4pzPZUocJXH75bejI()
	D1DvzIMryFn9cGt4PCY3T6hqjJu = XmIdijotlxQ6LuJ()
	D1DvzIMryFn9cGt4PCY3T6hqjJu.M4yLHpiledUP3SVE8f(GrSXDiIwqHsVeZ2Y4K9kWj)
	if D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY: return svULcgJ7jm(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ઱")
	if ut0GrdCjHJDIEgyOsvUTNLVF2==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡸ࡬ࡨࡪࡵࠧલ") and not uqeGx2DZ6SngyVPwj.startswith(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩ࠹ࠫળ")):
		RX03OLEFbDVscYoirQNv6nk5ehlTzy.setPath(iCr0xsqwDZXLPaJK1W5YU24F6hp)
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+TCF8wLyDvgumfiXPSKRh(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ઴")+iCr0xsqwDZXLPaJK1W5YU24F6hp+Fg72JX6T5DkPy(u"ࠫࠥࡣࠧવ"))
		Z7ZstrGoNP3XSLYClzUm8TqV.setResolvedUrl(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,RX03OLEFbDVscYoirQNv6nk5ehlTzy)
	elif ut0GrdCjHJDIEgyOsvUTNLVF2==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡲࡩࡷࡧࠪશ"):
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩષ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+g4UCaNkHvLwGhjmW(u"ࠧࠡ࡟ࠪસ"))
		D1DvzIMryFn9cGt4PCY3T6hqjJu.play(iCr0xsqwDZXLPaJK1W5YU24F6hp,RX03OLEFbDVscYoirQNv6nk5ehlTzy)
	AMu7aiqvPT6WcLOXDSkhFzdN = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if q1EjrzRPQJvuUolfY==OTRKI6LbrQnZEm(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪહ"):
		from HV54JYdbCX import z91Sfe65ZD4RsdXwokHPFcyQ0T
		AMu7aiqvPT6WcLOXDSkhFzdN = z91Sfe65ZD4RsdXwokHPFcyQ0T(iCr0xsqwDZXLPaJK1W5YU24F6hp,denYhNEq72TZSD0psXick9tzg5,GrSXDiIwqHsVeZ2Y4K9kWj)
		if AMu7aiqvPT6WcLOXDSkhFzdN: VKsQmdD8RBlM4pzPZUocJXH75bejI()
	else:
		XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc,q1EjrzRPQJvuUolfY,MMn5PY3x1hZuyUCAbOTcQ98WIoLt,ZRD24QlTAI6w,ZlE3DA5VbvfLQpTz = h17Zb2ld4yLBrCP5tiw,bDt7Ya1VEio3(u"ࠩࡷࡶ࡮࡫ࡤࠨ઺"),YoAMfqm37GyFxbuKTt6e8CESHrhB,v54ZuLY6dQ(u"࠳࠳࠴࠵ଣ"),tOrSvd8QKNB(u"࠵࠷࠳࠴࠵ଢ")
		if StF7gAOLnb6jh3zEJrkPBWTyHZ: from TEsNM9QVZc import X69Fkr1VNnf2pJQC8wl7YR4HmaKc
		while XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc<ZlE3DA5VbvfLQpTz:
			qVuYLZTmSUhQe7rEwvFRfc.sleep(ZRD24QlTAI6w)
			XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc += ZRD24QlTAI6w
			if D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY==tg9l25NH6WTacVSifLyAmY(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ઻") and not MMn5PY3x1hZuyUCAbOTcQ98WIoLt:
				if StF7gAOLnb6jh3zEJrkPBWTyHZ: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(DDHwpETQrAm0xMNXGfyhqsUi(u"๋ࠫาอหࠢ฼้้๐ษࠡวํะฬีࠠศๆไ๎ิ๐่ࠨ઼"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ઽ"),B3TKLo71hAGRqYgV0=fk8jc5uDLX16qrih3ZaPxsvO(u"࠺࠹࠵ତ"))
				SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪા")+iCr0xsqwDZXLPaJK1W5YU24F6hp+svULcgJ7jm(u"ࠧࠡ࡟ࠪિ")+AALrfaosIbKUj5N6wqZ)
				MMn5PY3x1hZuyUCAbOTcQ98WIoLt = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			elif D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY in [DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩી"),FF70emVxhWOngCty(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪુ")]:
				SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OTRKI6LbrQnZEm(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧૂ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࠥࡣࠧૃ")+AALrfaosIbKUj5N6wqZ)
				break
			elif D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY==TCF8wLyDvgumfiXPSKRh(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬૄ"):
				SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+pTwKPmzMSZhil5d2RWonre(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧૅ")+iCr0xsqwDZXLPaJK1W5YU24F6hp+Fg72JX6T5DkPy(u"ࠧࠡ࡟ࠪ૆")+AALrfaosIbKUj5N6wqZ)
				if StF7gAOLnb6jh3zEJrkPBWTyHZ: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬે"),v54ZuLY6dQ(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪૈ"),B3TKLo71hAGRqYgV0=NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠻࠺࠶ଥ"))
				break
			elif D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY==pTwKPmzMSZhil5d2RWonre(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫૉ"):
				SQdRhwozVfv(wJ1SrGzhYcZ0aofnKQkV5,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OOhnpQ8XvCVclGqdu(u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ૊")+iCr0xsqwDZXLPaJK1W5YU24F6hp+tOrSvd8QKNB(u"ࠬࠦ࡝ࠨો"))
				break
		else:
			if StF7gAOLnb6jh3zEJrkPBWTyHZ: X69Fkr1VNnf2pJQC8wl7YR4HmaKc(s0vAWcLSXEToH9Mik134q(u"࠭แีๆอࠤ฾๋ไ๋หࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪૌ"),tg9l25NH6WTacVSifLyAmY(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨ્"),B3TKLo71hAGRqYgV0=vZL6j4tSClIGxzNE5DX(u"࠼࠻࠰ଦ"))
			SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+K7bLVaiRkx0lgU5SQM(u"ࠨࠢࠣࠤ࡙࡯࡭ࡦࡱࡸࡸ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡲࡵࡳࡧࡲࡥ࡮ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ૎")+iCr0xsqwDZXLPaJK1W5YU24F6hp+FF70emVxhWOngCty(u"ࠩࠣࡡࠬ૏")+AALrfaosIbKUj5N6wqZ)
			q1EjrzRPQJvuUolfY = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫૐ")
	if q1EjrzRPQJvuUolfY in [y5yX4jh6kUEgWZQIc(u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ૑")] or D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY in [v54ZuLY6dQ(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭૒"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ૓")] or AMu7aiqvPT6WcLOXDSkhFzdN:
		if D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ૔"): GrSXDiIwqHsVeZ2Y4K9kWj = GrSXDiIwqHsVeZ2Y4K9kWj+g4UCaNkHvLwGhjmW(u"ࠨࡡࡗࡗࠬ૕")
		lE7ZB0CTayhKItApFnYxz = HNLnAOlivm(GrSXDiIwqHsVeZ2Y4K9kWj)
	else: exec(OTRKI6LbrQnZEm(u"ࠩ࡬ࡱࡵࡵࡲࡵࠢࡻࡦࡲࡩ࠻ࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠧ૖"))
	return D1DvzIMryFn9cGt4PCY3T6hqjJu.q1EjrzRPQJvuUolfY
def z2dZ1anR6O(iCr0xsqwDZXLPaJK1W5YU24F6hp):
	if b7sJAmSxlBvaMdHFz: from urllib.parse import urlparse as mmzSwBRhavC5tYLoEkHXWy
	else: from urlparse import urlparse as mmzSwBRhavC5tYLoEkHXWy
	path = mmzSwBRhavC5tYLoEkHXWy(iCr0xsqwDZXLPaJK1W5YU24F6hp).path
	xZ8tTskANLOBmPz2hGU4JY1 = QigevCplXxbPI1H if XWbHfI9B8swrOL(u"ࠪ࠲ࠬ૗") not in path else path.rsplit(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࠳࠭૘"),Xr2aHOK0huQ5DTS(u"࠷ଧ"))[nfC2im3NzUQk]
	if xZ8tTskANLOBmPz2hGU4JY1 in [XWbHfI9B8swrOL(u"ࠬࡧࡶࡪࠩ૙"),JJu4MPClbTFpUwHiN(u"࠭ࡴࡴࠩ૚"),K7bLVaiRkx0lgU5SQM(u"ࠧࡢࡣࡦࠫ૛"),y5yX4jh6kUEgWZQIc(u"ࠨ࡯ࡳ࠸ࠬ૜"),svULcgJ7jm(u"ࠩࡰ࠷ࡺ࠭૝"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡱ࠸ࡻ࠸ࠨ૞"),tg9l25NH6WTacVSifLyAmY(u"ࠫࡲࡶࡤࠨ૟"),tg9l25NH6WTacVSifLyAmY(u"ࠬࡳ࡫ࡷࠩૠ"),XWbHfI9B8swrOL(u"࠭ࡦ࡭ࡸࠪૡ"),tg9l25NH6WTacVSifLyAmY(u"ࠧ࡮ࡲ࠶ࠫૢ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡹࡨࡦࡲ࠭ૣ")]: return tg9l25NH6WTacVSifLyAmY(u"ࠩ࠱ࠫ૤")+xZ8tTskANLOBmPz2hGU4JY1
	return QigevCplXxbPI1H
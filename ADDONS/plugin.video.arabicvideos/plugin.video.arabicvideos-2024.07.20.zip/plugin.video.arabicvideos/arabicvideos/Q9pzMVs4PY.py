# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
import bs4 as d3ihaIgxPtlpJq5
PuT0IphGNsketAQ = 'ELCINEMA'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_ELC_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
headers = {'Referer':vxQUXEuH9m}
ef1pQcbEtPjMnXYrvOi = []
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==510: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==511: W9lfsoMawqOzpQcXD = v2APVqjzUKZ4GEc(url)
	elif mode==512: W9lfsoMawqOzpQcXD = btyMpPg3OQHAR2L7irNwDoTcZ(url)
	elif mode==513: W9lfsoMawqOzpQcXD = RNSJsbafULt6og20du(url)
	elif mode==514: W9lfsoMawqOzpQcXD = xvChDKIR0zw(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: W9lfsoMawqOzpQcXD = xvChDKIR0zw(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: W9lfsoMawqOzpQcXD = L3MniHlApOFP(text)
	elif mode==517: W9lfsoMawqOzpQcXD = PyOAWRlTCqLkb97BUxu2(url)
	elif mode==518: W9lfsoMawqOzpQcXD = bhFHuPWe7Ork5t4IawE10o(url)
	elif mode==519: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	elif mode==520: W9lfsoMawqOzpQcXD = zroNhg41TyJv35ZFqaK(url)
	elif mode==521: W9lfsoMawqOzpQcXD = IEQ0yOluNcUw5k7FhP9DdfT6JpB2(url)
	elif mode==522: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==523: W9lfsoMawqOzpQcXD = ZEeQMH9w2fvRqrTLX8u(text)
	elif mode==524: W9lfsoMawqOzpQcXD = tJOhHoKLWbMpzmDsje73iBScw()
	elif mode==525: W9lfsoMawqOzpQcXD = I2XaTcMRV5g3yJtx4BWvEqPK()
	elif mode==526: W9lfsoMawqOzpQcXD = DeMIRiBE36yvHVXd4PTx()
	elif mode==527: W9lfsoMawqOzpQcXD = i0CyEufbdKG73Y1QJMcwqg()
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث بموسوعة السينما',QigevCplXxbPI1H,519)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'موسوعة الأعمال',QigevCplXxbPI1H,525)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'موسوعة الأشخاص',QigevCplXxbPI1H,526)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'موسوعة المصنفات',QigevCplXxbPI1H,527)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'موسوعة المنوعات',QigevCplXxbPI1H,524)
	return
def tJOhHoKLWbMpzmDsje73iBScw():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' فيديوهات - خاصة',vxQUXEuH9m+'/video',520)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فيديوهات - أحدث',vxQUXEuH9m+'/video/latest',521)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فيديوهات - أقدم',vxQUXEuH9m+'/video/oldest',521)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فيديوهات - أكثر مشاهدة',vxQUXEuH9m+'/video/views',521)
	return
def I2XaTcMRV5g3yJtx4BWvEqPK():
	TnFbX3WEtskH5I6g9QDB02YjzN1 = vxQUXEuH9m+'/lineup?utf8=%E2%9C%93'
	WlscZbCgxVDQvEB7 = TnFbX3WEtskH5I6g9QDB02YjzN1+'&type=2&category=1&foreign=false&tag='
	SV40t7hXUjlnbFpeKOZ = TnFbX3WEtskH5I6g9QDB02YjzN1+'&type=2&category=3&foreign=false&tag='
	eJCbpHtXPfxFBy = TnFbX3WEtskH5I6g9QDB02YjzN1+'&type=2&category=1&foreign=true&tag='
	zoYW2unKe7sPBcQSF0qw16RjH = TnFbX3WEtskH5I6g9QDB02YjzN1+'&type=2&category=3&foreign=true&tag='
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات أفلام عربي',WlscZbCgxVDQvEB7,511)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات مسلسلات عربي',SV40t7hXUjlnbFpeKOZ,511)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات أفلام اجنبي',eJCbpHtXPfxFBy,511)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات مسلسلات اجنبي',zoYW2unKe7sPBcQSF0qw16RjH,511)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس أعمال أبجدي',vxQUXEuH9m+'/index/work/alphabet',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس  بلد الإنتاج',vxQUXEuH9m+'/index/work/country',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس اللغة',vxQUXEuH9m+'/index/work/language',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس مصنفات العمل',vxQUXEuH9m+'/index/work/genre',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس سنة الإصدار',vxQUXEuH9m+'/index/work/release_year',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مواسم - فلتر محدد',vxQUXEuH9m+'/seasonals',515)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مواسم - فلتر كامل',vxQUXEuH9m+'/seasonals',514)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات - فلتر محدد',vxQUXEuH9m+'/lineup',515)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات - فلتر كامل',vxQUXEuH9m+'/lineup',514)
	return
def i0CyEufbdKG73Y1QJMcwqg():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m+'/lineup',QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	LKzFWsmvjUVGMDBapflx6H4NY = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find('select',attrs={'name':'tag'})
	iBux5zA0swygKtRlDCTH = LKzFWsmvjUVGMDBapflx6H4NY.find_all('option')
	for C4kS0cewBJy8YOWtZxXNjfM2 in iBux5zA0swygKtRlDCTH:
		nFdGHjceZzW = C4kS0cewBJy8YOWtZxXNjfM2.get('value')
		if not nFdGHjceZzW: continue
		title = C4kS0cewBJy8YOWtZxXNjfM2.text
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			title = title.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			nFdGHjceZzW = nFdGHjceZzW.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+nFdGHjceZzW
		title = title.replace('قائمة ',QigevCplXxbPI1H)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,511)
	return
def DeMIRiBE36yvHVXd4PTx():
	TnFbX3WEtskH5I6g9QDB02YjzN1 = vxQUXEuH9m+'/lineup?utf8=%E2%9C%93'
	LrqiEUXQaKocezTI23hmZW1PbF65uY = TnFbX3WEtskH5I6g9QDB02YjzN1+'&type=1&category=&foreign=&tag='
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات أشخاص',LrqiEUXQaKocezTI23hmZW1PbF65uY,511)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس أشخاص أبجدي',vxQUXEuH9m+'/index/person/alphabet',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس موطن',vxQUXEuH9m+'/index/person/nationality',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس  تاريخ الميلاد',vxQUXEuH9m+'/index/person/birth_year',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فهرس  تاريخ الوفاة',vxQUXEuH9m+'/index/person/death_year',517)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات - فلتر محدد',vxQUXEuH9m+'/lineup',515)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مصنفات - فلتر كامل',vxQUXEuH9m+'/lineup',514)
	return
def v2APVqjzUKZ4GEc(url):
	if '/seasonals' in url: nVWUleSBvsKaEhoCxNryf = 0
	elif '/lineup' in url: nVWUleSBvsKaEhoCxNryf = 1
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-LISTS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	mfFwcWZHXVGvyU3B0ILburCoh = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find_all(class_='jumbo-theater clearfix')
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		title = LKzFWsmvjUVGMDBapflx6H4NY.find_all('a')[nVWUleSBvsKaEhoCxNryf].text
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+LKzFWsmvjUVGMDBapflx6H4NY.find_all('a')[nVWUleSBvsKaEhoCxNryf].get('href')
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			title = title.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		if not mfFwcWZHXVGvyU3B0ILburCoh:
			btyMpPg3OQHAR2L7irNwDoTcZ(RMC6c2kL5hGOnFaIwAyb)
			return
		else:
			title = title.replace('قائمة ',QigevCplXxbPI1H)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,512)
	YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu,511)
	return
def YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu,mode):
	LKzFWsmvjUVGMDBapflx6H4NY = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find(class_='pagination')
	if LKzFWsmvjUVGMDBapflx6H4NY:
		aGp27PkoNrcv19Xd = LKzFWsmvjUVGMDBapflx6H4NY.find_all('a')
		s3mWKxaEuUHkoNYeC1 = LKzFWsmvjUVGMDBapflx6H4NY.find_all('li')
		i83nlgHvGVoD6L0SkCqdjA5YuET = list(zip(aGp27PkoNrcv19Xd,s3mWKxaEuUHkoNYeC1))
		GzabfJx3T1 = -1
		iz7sjYCJZp1O2g09r6HuloRnaqEKG3 = len(i83nlgHvGVoD6L0SkCqdjA5YuET)
		for qqFGtbgNUTj1Jr6ze3PlSEnIx0O,lfP6V0ZrFhXcUR1sj58CnLk in i83nlgHvGVoD6L0SkCqdjA5YuET:
			GzabfJx3T1 += 1
			lfP6V0ZrFhXcUR1sj58CnLk = lfP6V0ZrFhXcUR1sj58CnLk['class']
			if 'unavailable' in lfP6V0ZrFhXcUR1sj58CnLk or 'current' in lfP6V0ZrFhXcUR1sj58CnLk: continue
			BazW8QlSDmdsZrhXNAjPEo0 = qqFGtbgNUTj1Jr6ze3PlSEnIx0O.text
			Wdek0SptsHCKog19OBJDTRAX7m = vxQUXEuH9m+qqFGtbgNUTj1Jr6ze3PlSEnIx0O.get('href')
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
				BazW8QlSDmdsZrhXNAjPEo0 = BazW8QlSDmdsZrhXNAjPEo0.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				Wdek0SptsHCKog19OBJDTRAX7m = Wdek0SptsHCKog19OBJDTRAX7m.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			if   GzabfJx3T1==0: BazW8QlSDmdsZrhXNAjPEo0 = 'أولى'
			elif GzabfJx3T1==1: BazW8QlSDmdsZrhXNAjPEo0 = 'سابقة'
			elif GzabfJx3T1==iz7sjYCJZp1O2g09r6HuloRnaqEKG3-2: BazW8QlSDmdsZrhXNAjPEo0 = 'لاحقة'
			elif GzabfJx3T1==iz7sjYCJZp1O2g09r6HuloRnaqEKG3-1: BazW8QlSDmdsZrhXNAjPEo0 = 'أخيرة'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+BazW8QlSDmdsZrhXNAjPEo0,Wdek0SptsHCKog19OBJDTRAX7m,mode)
	return
def btyMpPg3OQHAR2L7irNwDoTcZ(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-TITLES1-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	mfFwcWZHXVGvyU3B0ILburCoh = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find_all(class_='row')
	items,JwNdW5ulnaVBmKPCijI4tHFEf39R = [],True
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		if not LKzFWsmvjUVGMDBapflx6H4NY.find(class_='thumbnail-wrapper'): continue
		if JwNdW5ulnaVBmKPCijI4tHFEf39R: JwNdW5ulnaVBmKPCijI4tHFEf39R = False ; continue
		DFYvUHaMp9wQz0S6Erxb3Ze8ktm7 = []
		SqmxaTR6yOI5kvAX3ZEgoi4usrtj = LKzFWsmvjUVGMDBapflx6H4NY.find_all(class_=['censorship red','censorship purple'])
		for vn9iZ4o3CKL6r7m5DVR in SqmxaTR6yOI5kvAX3ZEgoi4usrtj:
			apu6oDVjmgIHPFKyNnUsA7O10G9t = vn9iZ4o3CKL6r7m5DVR.find_all('li')[1].text
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
				apu6oDVjmgIHPFKyNnUsA7O10G9t = apu6oDVjmgIHPFKyNnUsA7O10G9t.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			DFYvUHaMp9wQz0S6Erxb3Ze8ktm7.append(apu6oDVjmgIHPFKyNnUsA7O10G9t)
		if not Q7YCG4unmP8HTL(PuT0IphGNsketAQ,QigevCplXxbPI1H,DFYvUHaMp9wQz0S6Erxb3Ze8ktm7,False):
			XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('data-src')
			title = LKzFWsmvjUVGMDBapflx6H4NY.find('h3')
			name = title.find('a').text
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+title.find('a').get('href')
			Ny50GWzalcLQkFqYdv6KIigVtE = LKzFWsmvjUVGMDBapflx6H4NY.find(class_='no-margin')
			ceFqoflXVGdi6M8hIx0LsA = LKzFWsmvjUVGMDBapflx6H4NY.find(class_='legend')
			if Ny50GWzalcLQkFqYdv6KIigVtE: Ny50GWzalcLQkFqYdv6KIigVtE = Ny50GWzalcLQkFqYdv6KIigVtE.text
			if ceFqoflXVGdi6M8hIx0LsA: ceFqoflXVGdi6M8hIx0LsA = ceFqoflXVGdi6M8hIx0LsA.text
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
				XGjn5q2cy6mRYZ1hPaDslHMK = XGjn5q2cy6mRYZ1hPaDslHMK.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				name = name.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				if Ny50GWzalcLQkFqYdv6KIigVtE: Ny50GWzalcLQkFqYdv6KIigVtE = Ny50GWzalcLQkFqYdv6KIigVtE.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			zHTPjrSgp8Zcbf = {}
			if ceFqoflXVGdi6M8hIx0LsA: zHTPjrSgp8Zcbf['stars'] = ceFqoflXVGdi6M8hIx0LsA
			if Ny50GWzalcLQkFqYdv6KIigVtE:
				Ny50GWzalcLQkFqYdv6KIigVtE = Ny50GWzalcLQkFqYdv6KIigVtE.replace(aSBkt4OU8JpWTEzVIHjAiv,' .. ')
				zHTPjrSgp8Zcbf['plot'] = Ny50GWzalcLQkFqYdv6KIigVtE.replace('...اقرأ المزيد',QigevCplXxbPI1H)
			if '/work/' in RMC6c2kL5hGOnFaIwAyb:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,516,XGjn5q2cy6mRYZ1hPaDslHMK,QigevCplXxbPI1H,name,QigevCplXxbPI1H,zHTPjrSgp8Zcbf)
			elif '/person/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,513,XGjn5q2cy6mRYZ1hPaDslHMK,QigevCplXxbPI1H,name,QigevCplXxbPI1H,zHTPjrSgp8Zcbf)
	YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu,512)
	return
def RNSJsbafULt6og20du(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-TITLES2-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	mfFwcWZHXVGvyU3B0ILburCoh = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find_all('li')
	MAXhvbWiFu,items = [],[]
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		if not LKzFWsmvjUVGMDBapflx6H4NY.find(class_='thumbnail-wrapper'): continue
		if not LKzFWsmvjUVGMDBapflx6H4NY.find(class_=['unstyled','unstyled text-center']): continue
		if LKzFWsmvjUVGMDBapflx6H4NY.find(class_='hide'): continue
		title = LKzFWsmvjUVGMDBapflx6H4NY.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in MAXhvbWiFu: continue
		MAXhvbWiFu.append(name)
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+title.find('a').get('href')
		if '/search/work/' in url: XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('src')
		elif '/search/person/' in url: XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('data-src')
		elif '/search/video/' in url: XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('data-src')
		else: XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('src')
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			name = name.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			XGjn5q2cy6mRYZ1hPaDslHMK = XGjn5q2cy6mRYZ1hPaDslHMK.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		name = name.strip(hT7zFDpEyUqf8sXuN)
		items.append((name,RMC6c2kL5hGOnFaIwAyb,XGjn5q2cy6mRYZ1hPaDslHMK))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,RMC6c2kL5hGOnFaIwAyb,XGjn5q2cy6mRYZ1hPaDslHMK in items:
		if '/search/video/' in url: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,522,XGjn5q2cy6mRYZ1hPaDslHMK)
		elif '/search/person/' in url: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,513,XGjn5q2cy6mRYZ1hPaDslHMK,QigevCplXxbPI1H,name)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,516,XGjn5q2cy6mRYZ1hPaDslHMK,QigevCplXxbPI1H,name)
	return
def L3MniHlApOFP(text):
	text = text.replace('الإعلان',QigevCplXxbPI1H).replace('لفيلم',QigevCplXxbPI1H).replace('الرسمي',QigevCplXxbPI1H)
	text = text.replace('إعلان',QigevCplXxbPI1H).replace('فيلم',QigevCplXxbPI1H).replace('البرومو',QigevCplXxbPI1H)
	text = text.replace('التشويقي',QigevCplXxbPI1H).replace('لمسلسل',QigevCplXxbPI1H).replace('مسلسل',QigevCplXxbPI1H)
	text = text.replace(':',QigevCplXxbPI1H).replace(')',QigevCplXxbPI1H).replace('(',QigevCplXxbPI1H).replace(',',QigevCplXxbPI1H)
	text = text.replace('_',QigevCplXxbPI1H).replace(';',QigevCplXxbPI1H).replace('-',QigevCplXxbPI1H).replace('.',QigevCplXxbPI1H)
	text = text.replace('\'',QigevCplXxbPI1H).replace('\"',QigevCplXxbPI1H)
	text = text.replace(f1p0IN8alhrDKHyvqWk9UZ,hT7zFDpEyUqf8sXuN).replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	text = text.strip(hT7zFDpEyUqf8sXuN)
	g3UQqT2pNBEZnCO = text.count(hT7zFDpEyUqf8sXuN)+1
	if g3UQqT2pNBEZnCO==1:
		ZEeQMH9w2fvRqrTLX8u(text)
		return
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'[COLOR FFC89008]==== كلمات للبحث ====[/COLOR]',QigevCplXxbPI1H,9999)
	hpCFBGmrxMY1Q9L = text.split(hT7zFDpEyUqf8sXuN)
	AfQgnWhRox0qKcwZJbH6mlOUe8 = pow(2,g3UQqT2pNBEZnCO)
	L0PyDvUawVsljcdH5bCqu7QBE8Jrgn = []
	def FQrnUwv9mcYp(JTMk2hstqR,whgSVN07RoY4js1Di8tlqLprK2kW):
		if JTMk2hstqR=='1': return whgSVN07RoY4js1Di8tlqLprK2kW
		return QigevCplXxbPI1H
	for GzabfJx3T1 in range(AfQgnWhRox0qKcwZJbH6mlOUe8,0,-1):
		HqObB5MVdlyzTk = list(g3UQqT2pNBEZnCO*'0'+bin(GzabfJx3T1)[2:])[-g3UQqT2pNBEZnCO:]
		HqObB5MVdlyzTk = reversed(HqObB5MVdlyzTk)
		RnGKqWfH2YOp0zDaA = map(FQrnUwv9mcYp,HqObB5MVdlyzTk,hpCFBGmrxMY1Q9L)
		title = hT7zFDpEyUqf8sXuN.join(filter(None,RnGKqWfH2YOp0zDaA))
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: YIwQJyV0hAUR1EfKogObLzDMmx = title.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		else: YIwQJyV0hAUR1EfKogObLzDMmx = title
		if len(YIwQJyV0hAUR1EfKogObLzDMmx)>2 and title not in L0PyDvUawVsljcdH5bCqu7QBE8Jrgn:
			L0PyDvUawVsljcdH5bCqu7QBE8Jrgn.append(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,523,QigevCplXxbPI1H,QigevCplXxbPI1H,title)
	return
def ZEeQMH9w2fvRqrTLX8u(gKMPH8ajYeX45Vz0yr):
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
		gKMPH8ajYeX45Vz0yr = gKMPH8ajYeX45Vz0yr.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		import arabic_reshaper as QQEdvZB1AmzWeqMPs7pVR,bidi.algorithm as Vzd34t8iynRGBZ21oj
		gKMPH8ajYeX45Vz0yr = QQEdvZB1AmzWeqMPs7pVR.ArabicReshaper().reshape(gKMPH8ajYeX45Vz0yr)
		gKMPH8ajYeX45Vz0yr = Vzd34t8iynRGBZ21oj.get_display(gKMPH8ajYeX45Vz0yr)
	import x6evIlTMjh
	gKMPH8ajYeX45Vz0yr = XAfEvmh95VkgurjdiJ(bZATrHylco1EOa03Iuw4BjF=gKMPH8ajYeX45Vz0yr)
	x6evIlTMjh.UJL7oB1rySs6ERpjGnhvz(gKMPH8ajYeX45Vz0yr)
	return
def PyOAWRlTCqLkb97BUxu2(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-INDEXES_LISTS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	LKzFWsmvjUVGMDBapflx6H4NY = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find(class_='list-separator list-title')
	hu8mLEVaH12kwABO7nKtUpybXM = LKzFWsmvjUVGMDBapflx6H4NY.find_all('a')
	items = []
	for title in hu8mLEVaH12kwABO7nKtUpybXM:
		name = title.text
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+title.get('href')
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			name = name.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		if '#' not in RMC6c2kL5hGOnFaIwAyb: items.append((name,RMC6c2kL5hGOnFaIwAyb))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
		name,RMC6c2kL5hGOnFaIwAyb = upHdVltvOIDPnN0SefZwGo4gJ9LqsY
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,518)
	return
def bhFHuPWe7Ork5t4IawE10o(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-INDEXES_TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	mfFwcWZHXVGvyU3B0ILburCoh = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find(class_='expand').find_all('tr')
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		FKuE4m6aMz2ktr5pUQfL1 = LKzFWsmvjUVGMDBapflx6H4NY.find_all('a')
		if not FKuE4m6aMz2ktr5pUQfL1: continue
		XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('data-src')
		name = FKuE4m6aMz2ktr5pUQfL1[1].text
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+FKuE4m6aMz2ktr5pUQfL1[1].get('href')
		ceFqoflXVGdi6M8hIx0LsA = LKzFWsmvjUVGMDBapflx6H4NY.find(class_='legend')
		if ceFqoflXVGdi6M8hIx0LsA: ceFqoflXVGdi6M8hIx0LsA = ceFqoflXVGdi6M8hIx0LsA.text
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			name = name.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			XGjn5q2cy6mRYZ1hPaDslHMK = XGjn5q2cy6mRYZ1hPaDslHMK.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		zHTPjrSgp8Zcbf = {}
		if ceFqoflXVGdi6M8hIx0LsA: zHTPjrSgp8Zcbf['stars'] = ceFqoflXVGdi6M8hIx0LsA
		if '/work/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,516,XGjn5q2cy6mRYZ1hPaDslHMK,QigevCplXxbPI1H,name,QigevCplXxbPI1H,zHTPjrSgp8Zcbf)
		elif '/person/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name,RMC6c2kL5hGOnFaIwAyb,513,XGjn5q2cy6mRYZ1hPaDslHMK,QigevCplXxbPI1H,name,QigevCplXxbPI1H,zHTPjrSgp8Zcbf)
	YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu,518)
	return
def zroNhg41TyJv35ZFqaK(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-VIDEOS_LISTS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	hu8mLEVaH12kwABO7nKtUpybXM = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find_all(class_='section-title inline')
	rsBojxT8UZwL = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find_all(class_='button green small right')
	items = zip(hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL)
	for title,RMC6c2kL5hGOnFaIwAyb in items:
		title = title.text
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb.get('href')
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			title = title.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		title = title.replace(f1p0IN8alhrDKHyvqWk9UZ,hT7zFDpEyUqf8sXuN).replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,521)
	return
def IEQ0yOluNcUw5k7FhP9DdfT6JpB2(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-VIDEOS_TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	zzSXLOcZJDIbxvuaCANnl3pV48 = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	mfFwcWZHXVGvyU3B0ILburCoh = zzSXLOcZJDIbxvuaCANnl3pV48.find_all('li')
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		title = LKzFWsmvjUVGMDBapflx6H4NY.find(class_='title').text
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+LKzFWsmvjUVGMDBapflx6H4NY.find('a').get('href')
		XGjn5q2cy6mRYZ1hPaDslHMK = LKzFWsmvjUVGMDBapflx6H4NY.find('img').get('data-src')
		ThO0AMm4jUGP9yr = LKzFWsmvjUVGMDBapflx6H4NY.find(class_='duration').text
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			title = title.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			XGjn5q2cy6mRYZ1hPaDslHMK = XGjn5q2cy6mRYZ1hPaDslHMK.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,522,XGjn5q2cy6mRYZ1hPaDslHMK,ThO0AMm4jUGP9yr)
	YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu,521)
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	RMC6c2kL5hGOnFaIwAyb = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find(class_='flex-video').find('iframe').get('src')
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM([RMC6c2kL5hGOnFaIwAyb],PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	url = vxQUXEuH9m+'/search/?q='+search
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-SEARCH-1st')
	if not JJrhP4C6osGDFEKVSRBvX.succeeded:
		LrqiEUXQaKocezTI23hmZW1PbF65uY = vxQUXEuH9m+'/search_entity/?q='+search+'&entity=work'
		Wdek0SptsHCKog19OBJDTRAX7m = vxQUXEuH9m+'/search_entity/?q='+search+'&entity=person'
		apxojgOULPdDJ1HlTIy8 = vxQUXEuH9m+'/search_entity/?q='+search+'&entity=video'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن أعمال',LrqiEUXQaKocezTI23hmZW1PbF65uY,513,QigevCplXxbPI1H,search)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن أشخاص',Wdek0SptsHCKog19OBJDTRAX7m,513,QigevCplXxbPI1H,search)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن فيديوهات',apxojgOULPdDJ1HlTIy8,513,QigevCplXxbPI1H,search)
		return
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu = d3ihaIgxPtlpJq5.BeautifulSoup(aY63L2NhgvwJIxPAoDG4MKECmZXF1,'html.parser',multi_valued_attributes=None)
	mfFwcWZHXVGvyU3B0ILburCoh = Y9A0vpMGz1lOoNIW8xQ3Cc6wHqyu.find_all(class_='section-title left')
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		title = LKzFWsmvjUVGMDBapflx6H4NY.text
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			title = title.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		title = title.split('(',1)[0].strip(hT7zFDpEyUqf8sXuN)
		if   'أعمال' in title: RMC6c2kL5hGOnFaIwAyb = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: RMC6c2kL5hGOnFaIwAyb = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: RMC6c2kL5hGOnFaIwAyb = url.replace('/search/','/search/video/')
		else: continue
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,513)
	return
def xvChDKIR0zw(url,text):
	global XGiBxdyuLeSzpmvUCEwJI,NBJvnaA2GkRo6SD79YsVjqd
	if '/seasonals' in url:
		XGiBxdyuLeSzpmvUCEwJI = ['seasonal','year','category']
		NBJvnaA2GkRo6SD79YsVjqd = ['seasonal','year','category']
	elif '/lineup' in url:
		XGiBxdyuLeSzpmvUCEwJI = ['category','foreign','type']
		NBJvnaA2GkRo6SD79YsVjqd = ['category','foreign','type']
	fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,text)
	return
def bZ297CKlfXUW1n5BghJjzHQMi(url):
	url = url.split('/smartemadfilter?')[0]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('form action="/(.*?)</form>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return GTvCiBk9e5HnWobxXw6AzV3KQ
def k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY):
	items = sBvufaD6c9YHdOqTjCQ3.findall('<option value="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return items
def ZUusq9Gr6KtlWHJQ(url):
	ffJtczXvkj0o2HUZRprAOS = url.split('/smartemadfilter?')[0]
	gd2lmLiIyEvcsT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def KYfeyXkEI7U(oG5dMKyX6VQPhmuL0,url):
	IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'all_filters')
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'/smartemadfilter?'+IhG0UytMJko7
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = ZUusq9Gr6KtlWHJQ(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
	return NW6gmPcC1B4ILwdHTz0GlDsi5Fkx
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if XGiBxdyuLeSzpmvUCEwJI[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XGiBxdyuLeSzpmvUCEwJI[0:-1])):
			if XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
	elif type=='ALL_ITEMS_FILTER':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		Kj0TOU6BmSMlJHZYLd = ZUusq9Gr6KtlWHJQ(Kj0TOU6BmSMlJHZYLd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',Kj0TOU6BmSMlJHZYLd,511)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',Kj0TOU6BmSMlJHZYLd,511)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	GTvCiBk9e5HnWobxXw6AzV3KQ = bZ297CKlfXUW1n5BghJjzHQMi(url)
	dict = {}
	for name,Vjv2Okb6qhMRQgaDlu3JCir,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		name = name.replace('--',QigevCplXxbPI1H)
		items = k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='SPECIFIED_FILTER':
			if Vjv2Okb6qhMRQgaDlu3JCir not in XGiBxdyuLeSzpmvUCEwJI: continue
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<2:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]:
					url = ZUusq9Gr6KtlWHJQ(url)
					btyMpPg3OQHAR2L7irNwDoTcZ(url)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'SPECIFIED_FILTER___'+Vq4HIkij2ZLE)
				return
			else:
				Kj0TOU6BmSMlJHZYLd = ZUusq9Gr6KtlWHJQ(Kj0TOU6BmSMlJHZYLd)
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,511)
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,515,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='ALL_ITEMS_FILTER':
			if Vjv2Okb6qhMRQgaDlu3JCir not in NBJvnaA2GkRo6SD79YsVjqd: continue
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع: '+name,Kj0TOU6BmSMlJHZYLd,514,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			if 'مصنفات أخرى' in C4kS0cewBJy8YOWtZxXNjfM2: continue
			if 'الكل' in C4kS0cewBJy8YOWtZxXNjfM2: continue
			if 'اللغة' in C4kS0cewBJy8YOWtZxXNjfM2: continue
			C4kS0cewBJy8YOWtZxXNjfM2 = C4kS0cewBJy8YOWtZxXNjfM2.replace('قائمة ',QigevCplXxbPI1H)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			if name: title = C4kS0cewBJy8YOWtZxXNjfM2+' :'+name
			else: title = C4kS0cewBJy8YOWtZxXNjfM2
			if type=='ALL_ITEMS_FILTER': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,514,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='SPECIFIED_FILTER' and XGiBxdyuLeSzpmvUCEwJI[-2]+'=' in QSUrMykAebtx0Ea6:
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = KYfeyXkEI7U(oG5dMKyX6VQPhmuL0,url)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,511)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,515,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.replace('=&','=0&')
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	for key in NBJvnaA2GkRo6SD79YsVjqd:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all_filters': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.replace('=0','=')
	return bYlTrNXtvf0G7y
XGiBxdyuLeSzpmvUCEwJI = []
NBJvnaA2GkRo6SD79YsVjqd = []
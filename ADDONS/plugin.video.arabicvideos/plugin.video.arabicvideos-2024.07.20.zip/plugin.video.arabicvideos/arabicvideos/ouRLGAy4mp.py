# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'ARABICTOONS'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_ART_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==730: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==731: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	elif mode==732: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==733: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==734: W9lfsoMawqOzpQcXD = Ku3Yt57E9mrZsXjw1VRTIN40Bk(url)
	elif mode==735: W9lfsoMawqOzpQcXD = XGrpeWSPU70F3EcnjwICAy(url)
	elif mode==739: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,739,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات مميزة',vxQUXEuH9m+'/top.php',735)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات',vxQUXEuH9m+'/cartoon.php',734)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'افلام',vxQUXEuH9m+'/movies.php',731)
	return
def Ku3Yt57E9mrZsXjw1VRTIN40Bk(url):
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الكل',url,731)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABICTOONS-SERIES_SUBMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('label="navigation"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall("href='(.*?)'>(.*?)</a>",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
			title = 'حرف '+title
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,731)
	return
def XGrpeWSPU70F3EcnjwICAy(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABICTOONS-SERIES_FEATURED-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="slider"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
			cXu4fN1moCypJqb72OZvd = vxQUXEuH9m+'/'+cXu4fN1moCypJqb72OZvd
			title = title.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,733,cXu4fN1moCypJqb72OZvd)
	return
def ddbEXhWzOnIaR(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABICTOONS-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall("class='moviesBlocks(.*?)navigation",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
		cXu4fN1moCypJqb72OZvd = vxQUXEuH9m+'/'+cXu4fN1moCypJqb72OZvd
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if 'movies.php' in url: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,732,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,733,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[-1]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
			title = title.strip(hT7zFDpEyUqf8sXuN)
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,731)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABICTOONS-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall("class='moviesBlocks(.*?)script",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,ozfPw0HuT9snMtSZDE in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
			cXu4fN1moCypJqb72OZvd = vxQUXEuH9m+'/'+cXu4fN1moCypJqb72OZvd
			title = title.strip(hT7zFDpEyUqf8sXuN)
			title = title+hT7zFDpEyUqf8sXuN+ozfPw0HuT9snMtSZDE.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,732,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	vdLczqkV5b48ZKyGxTE3jJi17aWS6 = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABICTOONS-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('source src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if rsBojxT8UZwL:
		RMC6c2kL5hGOnFaIwAyb = rsBojxT8UZwL[0]
		if 'Referer=' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'|Referer=https://www.arabic-toons.com'
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named=__embed')
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	ldFqnNIsftrY43JBM6LPjzU8m = [QigevCplXxbPI1H,'m']
	It5BbEQNGcxzRK68 = ['مسلسلات','افلام']
	if showDialogs:
		HHZ6579kAv8 = zYWJO03iISD('اختر النوع المطلوب:', It5BbEQNGcxzRK68)
		if HHZ6579kAv8==-1: return
	else: HHZ6579kAv8 = 0
	type = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
	url = vxQUXEuH9m+'/livesearch.php?'+type+'&q='+search
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABICTOONS-SEARCH-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if type=='m': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,732)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,733)
	return
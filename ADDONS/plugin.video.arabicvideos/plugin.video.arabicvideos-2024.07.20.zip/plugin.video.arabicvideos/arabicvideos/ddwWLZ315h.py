# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'ARABSEED'
headers = {'User-Agent':eUBL1rOR4ZfndJAWPsoN6pybT0()}
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_ARS_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==250: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==251: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==252: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==253: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==254: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'CATEGORIES___'+text)
	elif mode==255: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'FILTERS___'+text)
	elif mode==256: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url,text)
	elif mode==259: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m+'/main',QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,259,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',vxQUXEuH9m+'/category/اخرى',254)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',vxQUXEuH9m+'/category/اخرى',255)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',vxQUXEuH9m+'/main',251,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured_main')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'جديد الأفلام',vxQUXEuH9m+'/main',251,QigevCplXxbPI1H,QigevCplXxbPI1H,'new_movies')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'جديد الحلقات',vxQUXEuH9m+'/main',251,QigevCplXxbPI1H,QigevCplXxbPI1H,'new_episodes')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المضاف حديثاً',vxQUXEuH9m+'/latest',251,QigevCplXxbPI1H,QigevCplXxbPI1H,'lastest')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('class="MenuHeader"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Pk5h14WpxO3nAQFv0rYmNa8KDblSg = gQ5KvJ6G2lbWwYBOMiTr[0]
	WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',Pk5h14WpxO3nAQFv0rYmNa8KDblSg,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in WWcSoXlyFCIzMGpxr:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if title not in ef1pQcbEtPjMnXYrvOi and title!=QigevCplXxbPI1H:
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,256)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def eR6YT8AbXwl(url,type):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-SUBMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if 'class="SliderInSection' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الأكثر مشاهدة',url,251,QigevCplXxbPI1H,QigevCplXxbPI1H,'most')
	if 'class="MainSlides' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',url,251,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	if 'class="LinksList' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="LinksList(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			if len(fwSu6JsQZpEiv)>1 and type=='new_episodes': LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[1]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				YIwQJyV0hAUR1EfKogObLzDMmx = sBvufaD6c9YHdOqTjCQ3.findall('</i>(.*?)<span>(.*?)<',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				try: T9Ax7pUEP6Ilg4cC = YIwQJyV0hAUR1EfKogObLzDMmx[0][0].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
				except: T9Ax7pUEP6Ilg4cC = QigevCplXxbPI1H
				try: MO4AKUmTp2kJjR8tVZ = YIwQJyV0hAUR1EfKogObLzDMmx[0][1].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
				except: MO4AKUmTp2kJjR8tVZ = QigevCplXxbPI1H
				YIwQJyV0hAUR1EfKogObLzDMmx = T9Ax7pUEP6Ilg4cC+hT7zFDpEyUqf8sXuN+MO4AKUmTp2kJjR8tVZ
				if '<strong>' in title:
					kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf = sBvufaD6c9YHdOqTjCQ3.findall('</i>(.*?)<',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					if kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf: YIwQJyV0hAUR1EfKogObLzDMmx = kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf[0]
				if not YIwQJyV0hAUR1EfKogObLzDMmx:
					kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf = sBvufaD6c9YHdOqTjCQ3.findall('alt="(.*?)"',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					if kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf: YIwQJyV0hAUR1EfKogObLzDMmx = kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf[0]
				if YIwQJyV0hAUR1EfKogObLzDMmx:
					if 'key=' in RMC6c2kL5hGOnFaIwAyb: type = RMC6c2kL5hGOnFaIwAyb.split('key=')[1]
					else: type = 'newest'
					YIwQJyV0hAUR1EfKogObLzDMmx = YIwQJyV0hAUR1EfKogObLzDMmx.strip(hT7zFDpEyUqf8sXuN)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,RMC6c2kL5hGOnFaIwAyb,251,QigevCplXxbPI1H,QigevCplXxbPI1H,type)
	return
def ddbEXhWzOnIaR(url,type):
	meRBy38nDXP2cGW9aVUlKCZTgx1oI,data,items = 'GET',QigevCplXxbPI1H,[]
	if type=='filters':
		if '?' in url:
			x1NOSq6wIZU9hnJuyfPgY0Q3G2,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = 'POST',{}
			Kj0TOU6BmSMlJHZYLd,aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU = url.split('?')
			pS1FVtbXfLgZ0nxY3eTzqGd = aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU.split('&')
			for lP9YsOehk3r8HWpxC in pS1FVtbXfLgZ0nxY3eTzqGd:
				key,nFdGHjceZzW = lP9YsOehk3r8HWpxC.split('=')
				tNQDMKVydhBqgaUvJ7oeAkTHxsL1[key] = nFdGHjceZzW
			if pS1FVtbXfLgZ0nxY3eTzqGd: meRBy38nDXP2cGW9aVUlKCZTgx1oI,url,data = x1NOSq6wIZU9hnJuyfPgY0Q3G2,Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,meRBy38nDXP2cGW9aVUlKCZTgx1oI,url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if type=='filters': fwSu6JsQZpEiv = [aY63L2NhgvwJIxPAoDG4MKECmZXF1]
	elif 'featured' in type: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="MainSlides(.*?)class="LinksList',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='new_movies': fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='new_episodes': fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='most': fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="SliderInSection(.*?)class="LinksList',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="Blocks-UL"(.*?)class="AboElSeed"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if 'featured' in type:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		tIzl5aXovVDWReF0fBbcjTnJ4Hpu = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if tIzl5aXovVDWReF0fBbcjTnJ4Hpu:
			ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6,mGFKQHpZbcqtNIwOkd,ccrXN0VUmvKdPZOI4n3GFEjiz = zip(*tIzl5aXovVDWReF0fBbcjTnJ4Hpu)
			items = zip(ldFqnNIsftrY43JBM6LPjzU8m,ccrXN0VUmvKdPZOI4n3GFEjiz,ttGBwQOv3K41hIkc6)
	else:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if 'WWE' in title: continue
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if 'الحلقة' in title:
			V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if V1nZX7O5WwEq8HmvkY:
				title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
				if title not in wibHRCAFtsupIjx4ZTELeM:
					wibHRCAFtsupIjx4ZTELeM.append(title)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,253,cXu4fN1moCypJqb72OZvd)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,252,cXu4fN1moCypJqb72OZvd)
		elif '/selary/' in RMC6c2kL5hGOnFaIwAyb or 'مسلسل' in title:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,253,cXu4fN1moCypJqb72OZvd)
		else:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,252,cXu4fN1moCypJqb72OZvd)
	if type in ['newest','best','most']:
		items = sBvufaD6c9YHdOqTjCQ3.findall('page-numbers" href="(.*?)">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			RMC6c2kL5hGOnFaIwAyb = i7gQvkPzZJm4jM3uYV2xfAqhs(RMC6c2kL5hGOnFaIwAyb)
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,251,QigevCplXxbPI1H,QigevCplXxbPI1H,type)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1[10000:]
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-src="(.*?)".*?alt="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items: return
	cXu4fN1moCypJqb72OZvd,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(hT7zFDpEyUqf8sXuN)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(hT7zFDpEyUqf8sXuN)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="ContainerEpisodesList"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<em>(.*?)</em>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,V1nZX7O5WwEq8HmvkY in items:
			title = name+' - الحلقة رقم '+V1nZX7O5WwEq8HmvkY
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,252,cXu4fN1moCypJqb72OZvd)
	else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'ملف التشغيل',url,252,cXu4fN1moCypJqb72OZvd)
	return
def fCMn7A9wOHzGQpDZuUdF5(title,RMC6c2kL5hGOnFaIwAyb):
	YIwQJyV0hAUR1EfKogObLzDMmx = sBvufaD6c9YHdOqTjCQ3.findall('[a-zA-Z-]+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if YIwQJyV0hAUR1EfKogObLzDMmx: title = YIwQJyV0hAUR1EfKogObLzDMmx[0]
	else: title = title+hT7zFDpEyUqf8sXuN+gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,'name')
	title = title.replace('عرب سيد',QigevCplXxbPI1H).replace('مباشر',QigevCplXxbPI1H).replace('مشاهدة',QigevCplXxbPI1H)
	title = title.replace('ٍ',QigevCplXxbPI1H)
	title = title.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	return title
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Kj0TOU6BmSMlJHZYLd = JJrhP4C6osGDFEKVSRBvX.url
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,'url')
	headers['Referer'] = bSrdN78jxURTvh9+'/'
	QnAdNfZcMqEtXxY9yaRThuD8CzU7,vu7TjA4N6YeMEFQsSKDqBICXyG9oZa,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,QigevCplXxbPI1H,[]
	ay50z4rAIkjhDJ7Esu = sBvufaD6c9YHdOqTjCQ3.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if ay50z4rAIkjhDJ7Esu: QnAdNfZcMqEtXxY9yaRThuD8CzU7,dbCzTyu4VLtwxoQvqnHjiGUK,vu7TjA4N6YeMEFQsSKDqBICXyG9oZa,sM0mej2fYOFP7AHlnyDNJq63o = ay50z4rAIkjhDJ7Esu[0]
	else:
		ay50z4rAIkjhDJ7Esu = sBvufaD6c9YHdOqTjCQ3.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if ay50z4rAIkjhDJ7Esu:
			RMC6c2kL5hGOnFaIwAyb,dbCzTyu4VLtwxoQvqnHjiGUK = ay50z4rAIkjhDJ7Esu[0]
			if 'watch' in dbCzTyu4VLtwxoQvqnHjiGUK: QnAdNfZcMqEtXxY9yaRThuD8CzU7 = RMC6c2kL5hGOnFaIwAyb
			else: vu7TjA4N6YeMEFQsSKDqBICXyG9oZa = RMC6c2kL5hGOnFaIwAyb
	if QnAdNfZcMqEtXxY9yaRThuD8CzU7:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',QnAdNfZcMqEtXxY9yaRThuD8CzU7,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-PLAY-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="WatcherArea"(.*?</ul>)',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			jN9uE3biQTade68Sgqmpl4xGMyts1W = fwSu6JsQZpEiv[0]
			jN9uE3biQTade68Sgqmpl4xGMyts1W = jN9uE3biQTade68Sgqmpl4xGMyts1W.replace('</ul>','<h3>')
			jN9uE3biQTade68Sgqmpl4xGMyts1W = jN9uE3biQTade68Sgqmpl4xGMyts1W.replace('<h3>','<h3><h3>')
			mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall('<h3>.*?(\d+)(.*?)<h3>',jN9uE3biQTade68Sgqmpl4xGMyts1W,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if not mfFwcWZHXVGvyU3B0ILburCoh: mfFwcWZHXVGvyU3B0ILburCoh = [(QigevCplXxbPI1H,jN9uE3biQTade68Sgqmpl4xGMyts1W)]
			for oI6LvXMf4VEPe8jOdpKC0hUmS,LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
				if oI6LvXMf4VEPe8jOdpKC0hUmS: oI6LvXMf4VEPe8jOdpKC0hUmS = '____'+oI6LvXMf4VEPe8jOdpKC0hUmS
				items = sBvufaD6c9YHdOqTjCQ3.findall('data-link="(.*?)".*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for RMC6c2kL5hGOnFaIwAyb,name in items:
					if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
					RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__watch'+oI6LvXMf4VEPe8jOdpKC0hUmS
					ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not rsBojxT8UZwL: rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if rsBojxT8UZwL:
			RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS = rsBojxT8UZwL[0]
			name = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,'name')
			if '%' in oI6LvXMf4VEPe8jOdpKC0hUmS: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__embed__'
			else: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__embed____'+oI6LvXMf4VEPe8jOdpKC0hUmS
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if vu7TjA4N6YeMEFQsSKDqBICXyG9oZa:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vu7TjA4N6YeMEFQsSKDqBICXyG9oZa,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-PLAY-3rd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="DownloadArea"(.*?)function',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title,oI6LvXMf4VEPe8jOdpKC0hUmS in items:
				if not RMC6c2kL5hGOnFaIwAyb: continue
				if 'reviewstation' in RMC6c2kL5hGOnFaIwAyb: continue
				RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb)
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download____'+oI6LvXMf4VEPe8jOdpKC0hUmS
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	UiwouabAP9Vlhg = str(ldFqnNIsftrY43JBM6LPjzU8m)
	XGAV7UMKQvPFWnB6ub9380 = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(nFdGHjceZzW in UiwouabAP9Vlhg for nFdGHjceZzW in XGAV7UMKQvPFWnB6ub9380):
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search: search = XAfEvmh95VkgurjdiJ()
	if not search: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/find/?find='+search
	ddbEXhWzOnIaR(url,'search')
	return
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='CATEGORIES':
		if XU3eP0JI7tSANQ6CzaBy1H[0]+'==' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XU3eP0JI7tSANQ6CzaBy1H[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XU3eP0JI7tSANQ6CzaBy1H[0:-1])):
			if XU3eP0JI7tSANQ6CzaBy1H[A5SjhJUg37pNiMC4Eot6lOF]+'==' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XU3eP0JI7tSANQ6CzaBy1H[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&&'+opIyA9rsJMXPL1k+'==0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&&'+opIyA9rsJMXPL1k+'==0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&&')+'___'+oG5dMKyX6VQPhmuL0.strip('&&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		Kj0TOU6BmSMlJHZYLd = url+'//getposts??'+IhG0UytMJko7
	elif type=='FILTERS':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'//getposts??'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		mQx10f2SaKD = LyOj2WGHrRXZK0c(Kj0TOU6BmSMlJHZYLd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',mQx10f2SaKD,251,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',mQx10f2SaKD,251,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'POST',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'ARABSEED-FILTERS_MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	lSVcizPesrTB4Zq31bfMjWtmy5YU2G = sBvufaD6c9YHdOqTjCQ3.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	J8JFSq2IX6fl = sBvufaD6c9YHdOqTjCQ3.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	GTvCiBk9e5HnWobxXw6AzV3KQ = lSVcizPesrTB4Zq31bfMjWtmy5YU2G+J8JFSq2IX6fl
	dict = {}
	for name,Vjv2Okb6qhMRQgaDlu3JCir,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('data-rate="(.*?)".*?<em>(.*?)</em>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			items = []
			for C4kS0cewBJy8YOWtZxXNjfM2,nFdGHjceZzW in WWcSoXlyFCIzMGpxr: items.append([C4kS0cewBJy8YOWtZxXNjfM2,QigevCplXxbPI1H,nFdGHjceZzW])
			Vjv2Okb6qhMRQgaDlu3JCir = 'rate'
			name = 'التقييم'
		else: Vjv2Okb6qhMRQgaDlu3JCir = items[0][1]
		if '==' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='CATEGORIES':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<=1:
				if Vjv2Okb6qhMRQgaDlu3JCir==XU3eP0JI7tSANQ6CzaBy1H[-1]: ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'CATEGORIES___'+Vq4HIkij2ZLE)
				return
			else:
				mQx10f2SaKD = LyOj2WGHrRXZK0c(Kj0TOU6BmSMlJHZYLd)
				if Vjv2Okb6qhMRQgaDlu3JCir==XU3eP0JI7tSANQ6CzaBy1H[-1]: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع ',mQx10f2SaKD,251,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع ',Kj0TOU6BmSMlJHZYLd,254,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='FILTERS':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'==0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'==0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع :'+name,Kj0TOU6BmSMlJHZYLd,255,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for C4kS0cewBJy8YOWtZxXNjfM2,tX1WYGPmux,nFdGHjceZzW in items:
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			if 'الكل' in C4kS0cewBJy8YOWtZxXNjfM2: continue
			C4kS0cewBJy8YOWtZxXNjfM2 = i7gQvkPzZJm4jM3uYV2xfAqhs(C4kS0cewBJy8YOWtZxXNjfM2)
			eliZWRgEXtMSxzpAPBUY4rnuq85F,YIwQJyV0hAUR1EfKogObLzDMmx = C4kS0cewBJy8YOWtZxXNjfM2,C4kS0cewBJy8YOWtZxXNjfM2
			YIwQJyV0hAUR1EfKogObLzDMmx = name+': '+eliZWRgEXtMSxzpAPBUY4rnuq85F
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = YIwQJyV0hAUR1EfKogObLzDMmx
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'=='+eliZWRgEXtMSxzpAPBUY4rnuq85F
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'=='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			if type=='FILTERS':
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,url,255,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='CATEGORIES' and XU3eP0JI7tSANQ6CzaBy1H[-2]+'==' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'modified_filters')
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'//getposts??'+IhG0UytMJko7
				mQx10f2SaKD = LyOj2WGHrRXZK0c(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,mQx10f2SaKD,251,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,url,254,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
XU3eP0JI7tSANQ6CzaBy1H = ['category','country','release-year']
tp3jXgGP9wamJAW5kuCxdYfQz = ['category','country','genre','release-year','language','quality','rate']
def LyOj2WGHrRXZK0c(url):
	PuNvaobVzRqCp6g3M = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',PuNvaobVzRqCp6g3M)
	url = url.replace('/category/اخرى',QigevCplXxbPI1H)
	if PuNvaobVzRqCp6g3M not in url: url = url+PuNvaobVzRqCp6g3M
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc,bYlTrNXtvf0G7y = {},QigevCplXxbPI1H
	if '==' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('==')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	for key in tp3jXgGP9wamJAW5kuCxdYfQz:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&&'+key+'=='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&&'+key+'=='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&&')
	return bYlTrNXtvf0G7y
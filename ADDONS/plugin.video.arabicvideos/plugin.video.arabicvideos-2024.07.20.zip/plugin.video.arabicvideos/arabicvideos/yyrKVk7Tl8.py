# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'EGYBEST1'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_EB1_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['مكتبتي','ايجي بست']
def YnMSWTbKj1N8wuRJVF(mode,url,JJM6TofH4g5n7SRwq,text):
	if   mode==770: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==771: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,JJM6TofH4g5n7SRwq)
	elif mode==772: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==773: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==774: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'FULL_FILTER___'+text)
	elif mode==775: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'DEFINED_FILTER___'+text)
	elif mode==776: W9lfsoMawqOzpQcXD = XPjvI9V0xhbLzoQAStGTWM(url,JJM6TofH4g5n7SRwq)
	elif mode==779: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text,url)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,779,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST1-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('nav-list(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,771)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-article(.*?)social-box',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('main-title.*?">(.*?)<.*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for title,RMC6c2kL5hGOnFaIwAyb in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,771,QigevCplXxbPI1H,'mainmenu')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-menu(.*?)</div></div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,771)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def XPjvI9V0xhbLzoQAStGTWM(url,type=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST1-SEASONS_EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-article".*?">(.*?)<(.*?)article',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		X6z7OV8NFovq0IKagdmberiM1,yjHcgifXG1,items = QigevCplXxbPI1H,QigevCplXxbPI1H,[]
		for name,LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
			if 'حلقات' in name: yjHcgifXG1 = LKzFWsmvjUVGMDBapflx6H4NY
			if 'مواسم' in name: X6z7OV8NFovq0IKagdmberiM1 = LKzFWsmvjUVGMDBapflx6H4NY
		if X6z7OV8NFovq0IKagdmberiM1 and not type:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',X6z7OV8NFovq0IKagdmberiM1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if len(items)>1:
				for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,776,cXu4fN1moCypJqb72OZvd,'season')
		if yjHcgifXG1 and len(items)<2:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',yjHcgifXG1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if items:
				for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,773,cXu4fN1moCypJqb72OZvd)
			else:
				items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',yjHcgifXG1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for RMC6c2kL5hGOnFaIwAyb,title in items:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,773)
	return
def ddbEXhWzOnIaR(url,type=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST1-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	items,ZNvUplCHSuj3cOQaT4bwDgoMk8rI,ZycmQiCsdhDMvz = [],False,False
	if not type:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-content(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = title.strip(hT7zFDpEyUqf8sXuN)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,771,QigevCplXxbPI1H,'submenu')
				ZNvUplCHSuj3cOQaT4bwDgoMk8rI = True
	if not type and 'p=' not in url:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('searchform(.*?)</form>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			if ZNvUplCHSuj3cOQaT4bwDgoMk8rI: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',url,775,QigevCplXxbPI1H,'filter')
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',url,774,QigevCplXxbPI1H,'filter')
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث',url,779)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
			ZycmQiCsdhDMvz = True
	if not ZNvUplCHSuj3cOQaT4bwDgoMk8rI:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('blocks(.*?)article',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
				cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.strip(aSBkt4OU8JpWTEzVIHjAiv)
				RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb)
				if '/serie/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,776,cXu4fN1moCypJqb72OZvd,'season')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,773,cXu4fN1moCypJqb72OZvd)
			JJM6TofH4g5n7SRwq = '1'
			if 'p=' in url: url,JJM6TofH4g5n7SRwq = url.split('p=',1)
			R2wuKSVBTLW4sAOQNob18UEdGf0hv = '&' if '?' in url else '?'
			url = url+R2wuKSVBTLW4sAOQNob18UEdGf0hv
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(JJM6TofH4g5n7SRwq)+1)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الصفحة التالية',url,771)
			elif JJM6TofH4g5n7SRwq!='1':
				url = url+'p='+str(int(JJM6TofH4g5n7SRwq)-1)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الصفحة السابقة',url,771)
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST1-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('<label>التصنيف</label>.*?">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6,fW2AtYU7jeDkv6a = [],[],[]
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('download-section.*?action="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0]
		if RMC6c2kL5hGOnFaIwAyb not in fW2AtYU7jeDkv6a:
			fW2AtYU7jeDkv6a.append(RMC6c2kL5hGOnFaIwAyb)
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named=__embed______'+sqXK91rDldVAEcRTSQL4n2tbC(url))
	mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall('WatchServers(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall("url='(.*?)'.*?>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,bSrdN78jxURTvh9 in rsBojxT8UZwL:
			if RMC6c2kL5hGOnFaIwAyb not in fW2AtYU7jeDkv6a:
				fW2AtYU7jeDkv6a.append(RMC6c2kL5hGOnFaIwAyb)
				vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+bSrdN78jxURTvh9+'__both______'+sqXK91rDldVAEcRTSQL4n2tbC(url))
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search,url=QigevCplXxbPI1H):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search: search = XAfEvmh95VkgurjdiJ()
	if not search: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	if not url: url = vxQUXEuH9m+'/search?query='+VIo6FYRkx0MLP4wufEGsgnz9
	else: url = url+'?title='+VIo6FYRkx0MLP4wufEGsgnz9+'&genre=&year=&lang='
	ddbEXhWzOnIaR(url,'search')
	return
def bZ297CKlfXUW1n5BghJjzHQMi(url):
	url = url.split('/smartemadfilter?')[0]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	GTvCiBk9e5HnWobxXw6AzV3KQ = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('form-row(.*?)</form>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ePIfNzugQUHWdmD1qa7t5Kxy0rjV2,MAXhvbWiFu,mfFwcWZHXVGvyU3B0ILburCoh = zip(*GTvCiBk9e5HnWobxXw6AzV3KQ)
		GTvCiBk9e5HnWobxXw6AzV3KQ = zip(MAXhvbWiFu,ePIfNzugQUHWdmD1qa7t5Kxy0rjV2,mfFwcWZHXVGvyU3B0ILburCoh)
	return GTvCiBk9e5HnWobxXw6AzV3KQ
def k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY):
	items = sBvufaD6c9YHdOqTjCQ3.findall('value="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return items
def WCeuTjxl9koBEtc1sUnJ(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
JJ6RaNTlM0zB2hmUt = ['year','lang','genre']
kS9YipEdhWD = ['year','lang','genre']
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='DEFINED_FILTER':
		if kS9YipEdhWD[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = kS9YipEdhWD[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(kS9YipEdhWD[0:-1])):
			if kS9YipEdhWD[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = kS9YipEdhWD[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'all')
		Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
	elif type=='FULL_FILTER':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'all')
		if not nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,771,QigevCplXxbPI1H,'filter')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,771,QigevCplXxbPI1H,'filter')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	GTvCiBk9e5HnWobxXw6AzV3KQ = bZ297CKlfXUW1n5BghJjzHQMi(url)
	dict = {}
	for name,Vjv2Okb6qhMRQgaDlu3JCir,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		name = name.replace('كل ',QigevCplXxbPI1H)
		items = k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='DEFINED_FILTER':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<2:
				if Vjv2Okb6qhMRQgaDlu3JCir==kS9YipEdhWD[-1]:
					NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
					ddbEXhWzOnIaR(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'DEFINED_FILTER___'+Vq4HIkij2ZLE)
				return
			else:
				if Vjv2Okb6qhMRQgaDlu3JCir==kS9YipEdhWD[-1]:
					NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع ',NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,771,QigevCplXxbPI1H,'filter')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع ',Kj0TOU6BmSMlJHZYLd,775,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='FULL_FILTER':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع :'+name,Kj0TOU6BmSMlJHZYLd,774,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if not nFdGHjceZzW: continue
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'#+dict[Vjv2Okb6qhMRQgaDlu3JCir]['0']
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'+name
			if type=='FULL_FILTER': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,774,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='DEFINED_FILTER' and kS9YipEdhWD[-2]+'=' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'modified_filters')
				Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,771,QigevCplXxbPI1H,'filter')
			elif type=='DEFINED_FILTER': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,775,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.replace('=&','=0&')
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	for key in JJ6RaNTlM0zB2hmUt:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.replace('=0','=')
	return bYlTrNXtvf0G7y
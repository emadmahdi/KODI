# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'KATKOUTE'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_KTK_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['الصفحة الرئيسية','Sign in','الأقسام']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==670: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==671: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==672: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==673: W9lfsoMawqOzpQcXD = LU7F3uNrm06e8OwTEcCJ(url,text)
	elif mode==674: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==679: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,679,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"navslide-divider"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title in ef1pQcbEtPjMnXYrvOi: continue
			if title=='الأقسام': mode = 675
			else: mode = 674
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,mode)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	items = qqIRsngutpzP52Moa(vxQUXEuH9m+'/watch/browse.html')
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,674,cXu4fN1moCypJqb72OZvd)
	return
def qqIRsngutpzP52Moa(url):
	Z8O95QXEfjdcWgp = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','KATKOUTE','CATEGORIES')
	if Z8O95QXEfjdcWgp: return Z8O95QXEfjdcWgp
	Z8O95QXEfjdcWgp = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-CATEGORIES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"category-header"(.*?)<footer>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		Z8O95QXEfjdcWgp = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?src="(.*?)" alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if Z8O95QXEfjdcWgp: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'KATKOUTE','CATEGORIES',Z8O95QXEfjdcWgp,g6gNzml5rOsa8bBETxPCpnVj)
	return Z8O95QXEfjdcWgp
def eR6YT8AbXwl(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-SUBMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"caret"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Z5CDQW96jye:
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('"presentation"','</ul>')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = [(QigevCplXxbPI1H,LKzFWsmvjUVGMDBapflx6H4NY)]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] فرز أو فلتر أو ترتيب [/COLOR]',QigevCplXxbPI1H,9999)
		for EVZ0Dhsl5r8tHPq6GNS19I3ox,LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if EVZ0Dhsl5r8tHPq6GNS19I3ox: EVZ0Dhsl5r8tHPq6GNS19I3ox = EVZ0Dhsl5r8tHPq6GNS19I3ox+': '
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = EVZ0Dhsl5r8tHPq6GNS19I3ox+title
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,671)
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"pm-category-subcats"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if gQ5KvJ6G2lbWwYBOMiTr:
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(items)<30:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,671)
	if not Z5CDQW96jye and not gQ5KvJ6G2lbWwYBOMiTr: ddbEXhWzOnIaR(url)
	return
def ddbEXhWzOnIaR(url,x9Ahuz3FVWmJDaNp5=QigevCplXxbPI1H):
	if x9Ahuz3FVWmJDaNp5=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-TITLES-1st')
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-TITLES-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	LKzFWsmvjUVGMDBapflx6H4NY,items = QigevCplXxbPI1H,[]
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	if x9Ahuz3FVWmJDaNp5=='ajax-search':
		LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
		WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in WWcSoXlyFCIzMGpxr: items.append((QigevCplXxbPI1H,RMC6c2kL5hGOnFaIwAyb,title))
	elif x9Ahuz3FVWmJDaNp5=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pm-video-watch-featured"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif x9Ahuz3FVWmJDaNp5=='new_episodes':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"row pm-ul-browse-videos(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif x9Ahuz3FVWmJDaNp5=='new_movies':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"row pm-ul-browse-videos(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(fwSu6JsQZpEiv)>1: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[1]
	elif x9Ahuz3FVWmJDaNp5=='featured_series':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in WWcSoXlyFCIzMGpxr: items.append((QigevCplXxbPI1H,RMC6c2kL5hGOnFaIwAyb,title))
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('(data-echo=".*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if LKzFWsmvjUVGMDBapflx6H4NY and not items: items = sBvufaD6c9YHdOqTjCQ3.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items: return
	wibHRCAFtsupIjx4ZTELeM = []
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','فلم']
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|حلقة).\d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,672,cXu4fN1moCypJqb72OZvd)
		elif x9Ahuz3FVWmJDaNp5=='new_episodes':
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,672,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0][0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,673,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif '/movseries/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,671,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,673,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if RMC6c2kL5hGOnFaIwAyb=='#': continue
			if 'http' not in RMC6c2kL5hGOnFaIwAyb:
				Kj0TOU6BmSMlJHZYLd = url.rsplit('/',1)[0]
				RMC6c2kL5hGOnFaIwAyb = Kj0TOU6BmSMlJHZYLd+'/'+RMC6c2kL5hGOnFaIwAyb.strip('/')
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,671,QigevCplXxbPI1H,QigevCplXxbPI1H,x9Ahuz3FVWmJDaNp5)
	return
def LU7F3uNrm06e8OwTEcCJ(url,q0zc3k5wP7Qo9A):
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'تشغيل الفيديو',url,672)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	Z8O95QXEfjdcWgp = qqIRsngutpzP52Moa(vxQUXEuH9m+'/watch/browse.html')
	QQlCptcxMbY0U4ZgqJRLTXvHj,Gdo7XgIO3kSecbq9uTUH1Yy8x5RBK,YFxBM8DyhoCPvesAmbZ0Gzug = zip(*Z8O95QXEfjdcWgp)
	KtNenzG1wWDEY7yFoPpMui84UH2 = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-EPISODES-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"row pm-video-heading"(.*?)id="player"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('class="myButton".*?href="(.*?)".*?<b>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in rsBojxT8UZwL:
			if RMC6c2kL5hGOnFaIwAyb not in QQlCptcxMbY0U4ZgqJRLTXvHj:
				upHdVltvOIDPnN0SefZwGo4gJ9LqsY = (RMC6c2kL5hGOnFaIwAyb,title)
				KtNenzG1wWDEY7yFoPpMui84UH2.append(upHdVltvOIDPnN0SefZwGo4gJ9LqsY)
		if len(KtNenzG1wWDEY7yFoPpMui84UH2)==1:
			RMC6c2kL5hGOnFaIwAyb,title = KtNenzG1wWDEY7yFoPpMui84UH2[0]
			ddbEXhWzOnIaR(RMC6c2kL5hGOnFaIwAyb,'new_episodes')
			return
		else:
			for RMC6c2kL5hGOnFaIwAyb,title in KtNenzG1wWDEY7yFoPpMui84UH2:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,671,QigevCplXxbPI1H,QigevCplXxbPI1H,'new_episodes')
	if not KtNenzG1wWDEY7yFoPpMui84UH2: ddbEXhWzOnIaR(url,'new_episodes')
	return
def nibvTq2jfRXDM4tYP039S(url):
	vdLczqkV5b48ZKyGxTE3jJi17aWS6 = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'KATKOUTE-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('sources:(.*?)flashplayer',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('file: "(.*?)".*?label: "(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS in rsBojxT8UZwL:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named=__watch__'+oI6LvXMf4VEPe8jOdpKC0hUmS
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
	rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('"embedded-video".*?src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not rsBojxT8UZwL: rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall("file: '(.*?)'",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if rsBojxT8UZwL:
		RMC6c2kL5hGOnFaIwAyb = rsBojxT8UZwL[0]
		if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named=__embed')
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/watch/search.php?keywords='+search
	ddbEXhWzOnIaR(url,'search')
	return
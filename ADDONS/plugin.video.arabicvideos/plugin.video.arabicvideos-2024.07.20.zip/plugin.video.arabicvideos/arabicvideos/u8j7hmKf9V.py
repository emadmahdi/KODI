# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from TEsNM9QVZc import *
PuT0IphGNsketAQ = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᣻")
unXQyBMHwD = []
headers = {aqUlAdFto05NmG4Y6guEzTr8vK(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ᣼"):QigevCplXxbPI1H}
CqR1s0zlxIQ2XUL5HbWJfZYSheyd3c = [FF70emVxhWOngCty(u"࠭ࡁࡌ࡙ࡄࡑࠬ᣽"),K7bLVaiRkx0lgU5SQM(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ᣾"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡋࡉࡍࡑࡓࠧ᣿"),g4UCaNkHvLwGhjmW(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬᤀ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬᤁ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧᤂ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡏࡐࡕࡘࠪᤃ"),OTRKI6LbrQnZEm(u"࠭ࡍ࠴ࡗࠪᤄ")]
def v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,source,type,url):
	if not vdLczqkV5b48ZKyGxTE3jJi17aWS6:
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧᤅ")+source+O4ylJvVNwLztdiHqBWDU(u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩᤆ")+type+mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࠣࡡࠬᤇ"))
		l3OPZneGtmogjidbaHBLr80XpUCfw = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,XWbHfI9B8swrOL(u"ࠪࡨ࡮ࡩࡴࠨᤈ"),K7bLVaiRkx0lgU5SQM(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧᤉ"),DDHwpETQrAm0xMNXGfyhqsUi(u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫᤊ"))
		EEQ7ZxANwPIugLy = B3TKLo71hAGRqYgV0.strftime(Xr2aHOK0huQ5DTS(u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧᤋ"),B3TKLo71hAGRqYgV0.gmtime(qyUPZBiAE3YkuOKrMnTFex92D))
		lP9YsOehk3r8HWpxC = EEQ7ZxANwPIugLy,url
		key = source+f1p0IN8alhrDKHyvqWk9UZ+GVmdqbtLu8lUXNxp13aHOvkscR+f1p0IN8alhrDKHyvqWk9UZ+str(aybmzWnDkuEcT3jpJClB2)
		nDRKguWex0iVN8 = QigevCplXxbPI1H
		if key not in list(l3OPZneGtmogjidbaHBLr80XpUCfw.keys()): l3OPZneGtmogjidbaHBLr80XpUCfw[key] = [lP9YsOehk3r8HWpxC]
		else:
			if url not in str(l3OPZneGtmogjidbaHBLr80XpUCfw[key]): l3OPZneGtmogjidbaHBLr80XpUCfw[key].append(lP9YsOehk3r8HWpxC)
			else: nDRKguWex0iVN8 = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧ࡝ࡰ๋ࠣีอࠠศๆไ๎ิ๐่ࠡ็๋ะํีࠠโ์ࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊๊หฯࠦวๅฬํࠤ้๋ࠠห฻่่ࠬᤌ")
		aACH7pwVFPdU0vqMSTo5N = aqUlAdFto05NmG4Y6guEzTr8vK(u"࠶ι")
		for key in list(l3OPZneGtmogjidbaHBLr80XpUCfw.keys()):
			l3OPZneGtmogjidbaHBLr80XpUCfw[key] = list(set(l3OPZneGtmogjidbaHBLr80XpUCfw[key]))
			aACH7pwVFPdU0vqMSTo5N += len(l3OPZneGtmogjidbaHBLr80XpUCfw[key])
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᤍ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪᤎ")+nDRKguWex0iVN8+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡠࡳࡢ࡮ࠡๆ็฽้๋ࠠศๆหี๋อๅอࠢํๆํ๋ࠠษฮ่฽่ࠥวว็ฬࠤออไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣ๎ัีࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้๋ࠢืํ็๋ࠠ฻ิฺࠥ฿ไ๋ๅࠣห้ฮั็ษ่ะࠥษๆࠡฬิื้ࠦ็ั้ࠣห้่วว็ฬࠤส๊้ࠡษ็้อืๅอࠢ฼๊ิ๋วࠡ์ุฬาูࠦะั๊หࠥ࠻ࠠโ์า๎ํํวหࠩᤏ")+pGncXOodjKhJzLSqVP1r(u"ࠫࡡࡴ࡜࡯ࠩᤐ")+mmKqLr9RX0ACN384JMcsFHzd(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨᤑ")+str(aACH7pwVFPdU0vqMSTo5N))
		if aACH7pwVFPdU0vqMSTo5N>=FF70emVxhWOngCty(u"࠵᾿"):
			nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,vZL6j4tSClIGxzNE5DX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᤒ"),tOrSvd8QKNB(u"ࠧศๆหี๋อๅอࠢฯ้฾ࠦโศศ่อࠥ็๊่ษࠣ࠹ࠥ็๊ะ์๋๋ฬะࠠๅ็ࠣ๎ัีࠠศๆหี๋อๅอࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤ࠳࠴ࠠิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหุ้ำ่ࠠา๊ࠤฬ๊โศศ่อࠥࡢ࡮࡝ࡰ๋้ࠣࠦสา์าࠤสืำศๆ๋ࠣีํࠠศๆๅหห๋ษࠡไห่๋ࠥำฮ้สࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ๅษำ่ะࠥฮแฮื๋ࠣีํࠠศๆไ๎ิ๐่่ษอࠤฤࠧࠡࠨᤓ"))
			if nndcv6tehuoKPpI==pGncXOodjKhJzLSqVP1r(u"࠲῀"):
				ffSMj4UdbgVEZpvX8BwlFQ1q = QigevCplXxbPI1H
				for key in list(l3OPZneGtmogjidbaHBLr80XpUCfw.keys()):
					ffSMj4UdbgVEZpvX8BwlFQ1q += aSBkt4OU8JpWTEzVIHjAiv+key
					yyIhdEm2AaLRGq6N8vFUcD79oJjs = sorted(l3OPZneGtmogjidbaHBLr80XpUCfw[key],reverse=YoAMfqm37GyFxbuKTt6e8CESHrhB,key=lambda uubZXjlJo9fBpAF: uubZXjlJo9fBpAF[h17Zb2ld4yLBrCP5tiw])
					for EEQ7ZxANwPIugLy,url in yyIhdEm2AaLRGq6N8vFUcD79oJjs:
						ffSMj4UdbgVEZpvX8BwlFQ1q += aSBkt4OU8JpWTEzVIHjAiv+EEQ7ZxANwPIugLy+f1p0IN8alhrDKHyvqWk9UZ+MVkP7zfWlxUXj(url)
					ffSMj4UdbgVEZpvX8BwlFQ1q += bDt7Ya1VEio3(u"ࠨ࡞ࡱࡠࡳ࠭ᤔ")
				import WZPsXYo7QE
				AMu7aiqvPT6WcLOXDSkhFzdN = WZPsXYo7QE.PZMEo96N8F50USez4(VvhRUZgko5Af1BIynMGOJSbpmK(u"࡙ࠩ࡭ࡩ࡫࡯ࡴࠩᤕ"),QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡍࡃ࡜ࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᤖ"),QigevCplXxbPI1H,ffSMj4UdbgVEZpvX8BwlFQ1q)
				if AMu7aiqvPT6WcLOXDSkhFzdN: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᤗ"),pTwKPmzMSZhil5d2RWonre(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨᤘ"))
				else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᤙ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ลาีส่ࠬᤚ"))
			if nndcv6tehuoKPpI!=-QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠳῁"):
				l3OPZneGtmogjidbaHBLr80XpUCfw = {}
				P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫᤛ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨᤜ"))
		if l3OPZneGtmogjidbaHBLr80XpUCfw: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,vZL6j4tSClIGxzNE5DX(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ᤝ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪᤞ"),l3OPZneGtmogjidbaHBLr80XpUCfw,xfdjCmFwb0k8JAVegiL)
		return
	vdLczqkV5b48ZKyGxTE3jJi17aWS6 = list(set(vdLczqkV5b48ZKyGxTE3jJi17aWS6))
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = LbmgyAdKr5UQSoaZExu7(vdLczqkV5b48ZKyGxTE3jJi17aWS6,source)
	eqDsdofaNOxm0hruc15TZYFy = str(ldFqnNIsftrY43JBM6LPjzU8m).count(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭᤟"))
	XkM8DN2I5laK6LJoS1wB = str(ldFqnNIsftrY43JBM6LPjzU8m).count(K7bLVaiRkx0lgU5SQM(u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪᤠ"))
	lILw8Q2sBt4JUZqaKgkYozE36CmPx7 = len(ldFqnNIsftrY43JBM6LPjzU8m)-eqDsdofaNOxm0hruc15TZYFy-XkM8DN2I5laK6LJoS1wB
	NaxfA8pL2ZYkMI = tOrSvd8QKNB(u"ࠧๆึส๋ิฯ࠺ࠨᤡ")+str(eqDsdofaNOxm0hruc15TZYFy)+JJu4MPClbTFpUwHiN(u"ࠨࠢࠣࠤࠥะอๆ์็࠾ࠬᤢ")+str(XkM8DN2I5laK6LJoS1wB)+mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࠣࠤࠥࠦรฯำ์࠾ࠬᤣ")+str(lILw8Q2sBt4JUZqaKgkYozE36CmPx7)
	if not ldFqnNIsftrY43JBM6LPjzU8m: RnGKqWfH2YOp0zDaA,gcXCwZe9xP = FF70emVxhWOngCty(u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧᤤ"),QigevCplXxbPI1H
	else:
		add = DDHwpETQrAm0xMNXGfyhqsUi(u"࠳ῂ")
		if not any(nFdGHjceZzW in source for nFdGHjceZzW in CqR1s0zlxIQ2XUL5HbWJfZYSheyd3c):
			add = v54ZuLY6dQ(u"࠵ῃ")
			ldFqnNIsftrY43JBM6LPjzU8m = [g4UCaNkHvLwGhjmW(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡤࡇࡌࡍࡡࡏࡍࡓࡑࡓࠨᤥ")]+list(ldFqnNIsftrY43JBM6LPjzU8m)
			ttGBwQOv3K41hIkc6 = [iVCLpNIM8BQs9PdSgKZvlFeo3a5+y5yX4jh6kUEgWZQIc(u"ࠬ็อึࠢฯ้๏฿ࠠศๆึ๎ึ็ัศฬࠪᤦ")+jhAlCQ47ZgG]+list(ttGBwQOv3K41hIkc6)
		while XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
			gcXCwZe9xP,RnGKqWfH2YOp0zDaA = QigevCplXxbPI1H,QigevCplXxbPI1H
			if add and len(ldFqnNIsftrY43JBM6LPjzU8m)==Xr2aHOK0huQ5DTS(u"࠸῅"): HHZ6579kAv8 = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠶ῄ")
			else: HHZ6579kAv8 = zYWJO03iISD(NaxfA8pL2ZYkMI,ttGBwQOv3K41hIkc6)
			if HHZ6579kAv8==-OTRKI6LbrQnZEm(u"࠱ῆ"): RnGKqWfH2YOp0zDaA = mpusoZBJ6V(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪᤧ")
			elif add and HHZ6579kAv8==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠱ῇ"):
				RnGKqWfH2YOp0zDaA = v54ZuLY6dQ(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫᤨ")
				W9lfsoMawqOzpQcXD = zzMjDn6TIBobkdvx(ttGBwQOv3K41hIkc6[add:],ldFqnNIsftrY43JBM6LPjzU8m[add:],source)
				if W9lfsoMawqOzpQcXD:
					m2NsBVXAdvxDw71 = []
					for kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf,apxojgOULPdDJ1HlTIy8,d2ZJ5lMkWfCucRmz3hV8,tpu4XEvLBM357ifDk960zgGx2nd8O,oo3UqnQZHrgepkGXy in W9lfsoMawqOzpQcXD:
						if oo3UqnQZHrgepkGXy: m2NsBVXAdvxDw71.append((kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf,apxojgOULPdDJ1HlTIy8,d2ZJ5lMkWfCucRmz3hV8,tpu4XEvLBM357ifDk960zgGx2nd8O,oo3UqnQZHrgepkGXy))
					if m2NsBVXAdvxDw71: ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,errors,hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL = zip(*m2NsBVXAdvxDw71)
					else:
						lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᤩ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ็่ศูแࠡๆ่ࠤ๏ะๅࠡวํะฬีࠠิ์ิๅึอสࠡฮํำฮࠦแ๋๊ࠢิฬࠦวๅใํำ๏๎ࠠ࠯࠰ࠣัฬ๎ไࠡล้ࠤฯฮอฬࠢ฼๊ࠥํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ࠦๅ้ษๅ฽ࠥษฮา๋ࠪᤪ"))
						RnGKqWfH2YOp0zDaA = tg9l25NH6WTacVSifLyAmY(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᤫ")
						break
					NaxfA8pL2ZYkMI = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫฬ๊ำ๋ำไีฬะࠠศๆฯ๎ิฯࠠࠩࠢࠪ᤬")+str(len(ldFqnNIsftrY43JBM6LPjzU8m))+K7bLVaiRkx0lgU5SQM(u"ࠬࠦࠩࠨ᤭")
					add = y5yX4jh6kUEgWZQIc(u"࠲Ὲ")
					continue
			else:
				W9lfsoMawqOzpQcXD = zzMjDn6TIBobkdvx([ttGBwQOv3K41hIkc6[HHZ6579kAv8]],[ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]],source)
				if W9lfsoMawqOzpQcXD:
					title,RMC6c2kL5hGOnFaIwAyb,errors,hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL = W9lfsoMawqOzpQcXD[h17Zb2ld4yLBrCP5tiw]
					if not rsBojxT8UZwL and not any(nFdGHjceZzW in source for nFdGHjceZzW in CqR1s0zlxIQ2XUL5HbWJfZYSheyd3c):
						errors,hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL = nbGZQNzWD0LHB(title,RMC6c2kL5hGOnFaIwAyb,source,vZL6j4tSClIGxzNE5DX(u"࠳Έ"))
						if errors==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᤮"): return errors
					if aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧิ์ิๅึ࠭᤯") in title and bDt7Ya1VEio3(u"ࠨ࠴่ะ์๎ไ࠳ࠩᤰ") in title:
						SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+OOhnpQ8XvCVclGqdu(u"ࠩࠣࠤ࡛ࠥ࡮࡬ࡰࡲࡻࡳࠦࡳࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧᤱ")+title+mpusoZBJ6V(u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧᤲ")+RMC6c2kL5hGOnFaIwAyb+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࠥࡣࠧᤳ"))
						import WZPsXYo7QE
						WZPsXYo7QE.DIE2YAwz0cBKdte6xS()
						RnGKqWfH2YOp0zDaA = mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩᤴ")
					else:
						RnGKqWfH2YOp0zDaA,gcXCwZe9xP,kQlGI4ouaPwteZq9XgKB02 = HPmrIhDw45EtNidJ6k9gneyoY802ZA(title,RMC6c2kL5hGOnFaIwAyb,errors,hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL,source,type)
			if RnGKqWfH2YOp0zDaA in [Xr2aHOK0huQ5DTS(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᤵ"),pTwKPmzMSZhil5d2RWonre(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩᤶ"),bDt7Ya1VEio3(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩᤷ"),pTwKPmzMSZhil5d2RWonre(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪᤸ"),svULcgJ7jm(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠷ࡳࡵࡡࡰࡩࡳࡻ᤹ࠧ")] or len(ldFqnNIsftrY43JBM6LPjzU8m)==K7bLVaiRkx0lgU5SQM(u"࠵Ὴ")+add: break
			elif RnGKqWfH2YOp0zDaA in [NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ᤺"),TCF8wLyDvgumfiXPSKRh(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ᤻࠭"),O4ylJvVNwLztdiHqBWDU(u"࠭ࡴࡳ࡫ࡨࡨࠬ᤼")]: break
			elif RnGKqWfH2YOp0zDaA not in [VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ᤽"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡪࡷࡸࡵࡹࠧ᤾")]:
				if aSBkt4OU8JpWTEzVIHjAiv in gcXCwZe9xP: gcXCwZe9xP = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠢࠣࠫ᤿")+gcXCwZe9xP.replace(aSBkt4OU8JpWTEzVIHjAiv,y5yX4jh6kUEgWZQIc(u"ࠪࡠࡳࡡࡌࡆࡈࡗࡡࠥࠦࠧ᥀"))
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᥁"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬอไิ์ิๅึࠦไๆࠢํ฽๊๊ࠠอำหࠤุ๐ัโำࠣ฾๏ื็ࠨ᥂")+aSBkt4OU8JpWTEzVIHjAiv+gcXCwZe9xP,profile=hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࡟࡮ࡧࡧ࡭ࡺࡳࡦࡰࡰࡷࠫ᥃"))
	if RnGKqWfH2YOp0zDaA==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ᥄") and len(ttGBwQOv3K41hIkc6)>JJu4MPClbTFpUwHiN(u"࠵Ή"): lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᥅"),v54ZuLY6dQ(u"ࠩึ๎ึ็ั้ࠡำหࠥอไโ์า๎ํࠦไๆࠢํ฽๊๊ࠠอำหࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠨ᥆")+aSBkt4OU8JpWTEzVIHjAiv+gcXCwZe9xP,profile=pGncXOodjKhJzLSqVP1r(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡲ࡫ࡤࡪࡷࡰࡪࡴࡴࡴࠨ᥇"))
	elif RnGKqWfH2YOp0zDaA in [pTwKPmzMSZhil5d2RWonre(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ᥈"),v54ZuLY6dQ(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭᥉")] and gcXCwZe9xP!=QigevCplXxbPI1H: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᥊"),gcXCwZe9xP,profile=fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡧࡱࡱࡸࠬ᥋"))
	return RnGKqWfH2YOp0zDaA
hV7CwFI9Z23PSv6,xTBtlJcMDR3ojraeHNuW6s5LVKPE2g,ffbEAoQPeYlnJwpUGz1aD7tOuscHmS,ONYjJuG4ClZ,j30vnGJTzmftkMaebxI5KVDFyZC = [],[],[],[],[]
def zzMjDn6TIBobkdvx(xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6,source):
	global hV7CwFI9Z23PSv6,xTBtlJcMDR3ojraeHNuW6s5LVKPE2g,ffbEAoQPeYlnJwpUGz1aD7tOuscHmS,ONYjJuG4ClZ,j30vnGJTzmftkMaebxI5KVDFyZC
	W9lfsoMawqOzpQcXD,DDbYBlexjKnGqWP,new = [],[],[]
	Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	count = len(vdLczqkV5b48ZKyGxTE3jJi17aWS6)
	for ATh6upUgFnm1VybLRcHv2QiGEfX4 in range(count):
		hV7CwFI9Z23PSv6.append(None)
		xTBtlJcMDR3ojraeHNuW6s5LVKPE2g.append(None)
		ffbEAoQPeYlnJwpUGz1aD7tOuscHmS.append(None)
		ONYjJuG4ClZ.append(None)
		j30vnGJTzmftkMaebxI5KVDFyZC.append(None)
		title = xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw[ATh6upUgFnm1VybLRcHv2QiGEfX4]
		RMC6c2kL5hGOnFaIwAyb = vdLczqkV5b48ZKyGxTE3jJi17aWS6[ATh6upUgFnm1VybLRcHv2QiGEfX4].strip(hT7zFDpEyUqf8sXuN).strip(OTRKI6LbrQnZEm(u"ࠨࠨࠪ᥌")).strip(v54ZuLY6dQ(u"ࠩࡂࠫ᥍")).strip(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪ࠳ࠬ᥎"))
		if count>JJu4MPClbTFpUwHiN(u"࠷ῌ"): X69Fkr1VNnf2pJQC8wl7YR4HmaKc(FF70emVxhWOngCty(u"ࠫๆำีࠡีํีๆืࠠาไ่ࠤࠥ࠭᥏")+str(ATh6upUgFnm1VybLRcHv2QiGEfX4+JJu4MPClbTFpUwHiN(u"࠷ῌ")),title)
		XgAmEczNG0IKH7DY4ynZw956qe = RMC6c2kL5hGOnFaIwAyb.split(Fg72JX6T5DkPy(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᥐ"),g4UCaNkHvLwGhjmW(u"࠱῍"))[h17Zb2ld4yLBrCP5tiw]
		D25eXFMWdErtvAn = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,g4UCaNkHvLwGhjmW(u"࠭࡬ࡪࡵࡷࠫᥑ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࠩᥒ"),XgAmEczNG0IKH7DY4ynZw956qe)
		if D25eXFMWdErtvAn and VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡃࡎ࡛ࡆࡓࠧᥓ") not in source:
			hV7CwFI9Z23PSv6[ATh6upUgFnm1VybLRcHv2QiGEfX4] = D25eXFMWdErtvAn
		else:
			pefuBNw2CDv = VVGXMeyJq25S6tf.Thread(target=nbGZQNzWD0LHB,args=(title,RMC6c2kL5hGOnFaIwAyb,source,ATh6upUgFnm1VybLRcHv2QiGEfX4))
			pefuBNw2CDv.start()
			DDbYBlexjKnGqWP.append(pefuBNw2CDv)
			new.append(ATh6upUgFnm1VybLRcHv2QiGEfX4)
			B3TKLo71hAGRqYgV0.sleep(svULcgJ7jm(u"࠱࠰࠺࠹῎"))
	timeout = DDHwpETQrAm0xMNXGfyhqsUi(u"࠸࠳῏") if source==OTRKI6LbrQnZEm(u"ࠩࡄࡏ࡜ࡇࡍࠨᥔ") else O4ylJvVNwLztdiHqBWDU(u"࠶࠴ῐ")
	for pefuBNw2CDv in DDbYBlexjKnGqWP: pefuBNw2CDv.join(timeout)
	for ATh6upUgFnm1VybLRcHv2QiGEfX4 in range(count):
		title = xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw[ATh6upUgFnm1VybLRcHv2QiGEfX4]
		RMC6c2kL5hGOnFaIwAyb = vdLczqkV5b48ZKyGxTE3jJi17aWS6[ATh6upUgFnm1VybLRcHv2QiGEfX4].strip(hT7zFDpEyUqf8sXuN).strip(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࠪࠬᥕ")).strip(OOhnpQ8XvCVclGqdu(u"ࠫࡄ࠭ᥖ")).strip(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬ࠵ࠧᥗ"))
		if hV7CwFI9Z23PSv6[ATh6upUgFnm1VybLRcHv2QiGEfX4]: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = hV7CwFI9Z23PSv6[ATh6upUgFnm1VybLRcHv2QiGEfX4]
		else: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = tOrSvd8QKNB(u"࠭࡜࡯ࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡘ࡮ࡳࡥࡰࡷࡷࠤ࠭࠭ᥘ")+str(timeout)+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪᥙ"),[],[]
		W9lfsoMawqOzpQcXD.append([title,RMC6c2kL5hGOnFaIwAyb,gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m])
		if ATh6upUgFnm1VybLRcHv2QiGEfX4 in new:
			XgAmEczNG0IKH7DY4ynZw956qe = RMC6c2kL5hGOnFaIwAyb.split(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᥚ"),Fg72JX6T5DkPy(u"࠵ῑ"))[h17Zb2ld4yLBrCP5tiw]
			try: OOa13B29xhTbZ,awjqAdRMPWQip4UkJc9btYgBn715Ch,XXGm4ZqK2ueysQTalMoPpCvEBt = ldFqnNIsftrY43JBM6LPjzU8m[h17Zb2ld4yLBrCP5tiw]
			except: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࠫᥛ"),XgAmEczNG0IKH7DY4ynZw956qe,[gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m],pETKl7xuH1f5yjdFAb6C8JzOLV)
	Yo7KhTw4ia5xXbEm0VZ2SjryFuQWHA(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H)
	return W9lfsoMawqOzpQcXD
def nbGZQNzWD0LHB(bSrdN78jxURTvh9,url,source,bb6LKGv5OYmaWIHz3ZfuUS):
	global hV7CwFI9Z23PSv6
	SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫᥜ")+bSrdN78jxURTvh9+XWbHfI9B8swrOL(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨᥝ")+url+v54ZuLY6dQ(u"ࠬࠦ࡝ࠨᥞ"))
	RMC6c2kL5hGOnFaIwAyb,VVBLsmOuvzC = url,QigevCplXxbPI1H
	PPcCAi2DtLpyY4O78fQ9zmjx = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡉࡏࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࠪᥟ")
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = jrG0Ah4COFRV5i3afexwT(url,source)
	if gcXCwZe9xP==vZL6j4tSClIGxzNE5DX(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᥠ"):
		hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᥡ"),[],[]
		return hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS]
	elif K7bLVaiRkx0lgU5SQM(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᥢ") in gcXCwZe9xP:
		VVBLsmOuvzC = XWbHfI9B8swrOL(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࡓ࡫ࡥࡥࠢࡈࡼࡹ࡫ࡲ࡯ࡣ࡯ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࠭ᥣ")
		RMC6c2kL5hGOnFaIwAyb = TTPODWBYHSIClG1gpVsZ8(ldFqnNIsftrY43JBM6LPjzU8m)[h17Zb2ld4yLBrCP5tiw]
		PPcCAi2DtLpyY4O78fQ9zmjx,VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = iudGyJsfbF7Aa5U8WToY3NISv4(VVBLsmOuvzC,RMC6c2kL5hGOnFaIwAyb,source,bb6LKGv5OYmaWIHz3ZfuUS)
		if VVBLsmOuvzC==pTwKPmzMSZhil5d2RWonre(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᥤ"): return VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	elif gcXCwZe9xP: VVBLsmOuvzC = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠤࠬᥥ")+gcXCwZe9xP.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)[:DDHwpETQrAm0xMNXGfyhqsUi(u"࠽࠶ῒ")]
	if ldFqnNIsftrY43JBM6LPjzU8m:
		ldFqnNIsftrY43JBM6LPjzU8m = TTPODWBYHSIClG1gpVsZ8(ldFqnNIsftrY43JBM6LPjzU8m)
		SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩᥦ")+bSrdN78jxURTvh9+FF70emVxhWOngCty(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫᥧ")+PPcCAi2DtLpyY4O78fQ9zmjx+s0vAWcLSXEToH9Mik134q(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬᥨ")+url+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩᥩ")+RMC6c2kL5hGOnFaIwAyb+bDt7Ya1VEio3(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࡳ࠻ࠢ࡞ࠤࠬᥪ")+str(ldFqnNIsftrY43JBM6LPjzU8m)+Xr2aHOK0huQ5DTS(u"ࠫࠥࡣࠧᥫ"))
	else: SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+svULcgJ7jm(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬᥬ")+bSrdN78jxURTvh9+pGncXOodjKhJzLSqVP1r(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪᥭ")+url+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧ᥮")+RMC6c2kL5hGOnFaIwAyb+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࠢࡠࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪ᥯")+VVBLsmOuvzC+tg9l25NH6WTacVSifLyAmY(u"ࠩࠣࡡࠬᥰ"))
	VVBLsmOuvzC = MVkP7zfWlxUXj(VVBLsmOuvzC)
	hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	return VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def HPmrIhDw45EtNidJ6k9gneyoY802ZA(title,RMC6c2kL5hGOnFaIwAyb,gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,source,type=QigevCplXxbPI1H):
	if gcXCwZe9xP==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᥱ"): return gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	elif ldFqnNIsftrY43JBM6LPjzU8m:
		while XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
			if len(ldFqnNIsftrY43JBM6LPjzU8m)==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠷ΐ"): HHZ6579kAv8 = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠰῔")
			else: HHZ6579kAv8 = zYWJO03iISD(bDt7Ya1VEio3(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪᥲ"), ttGBwQOv3K41hIkc6)
			if HHZ6579kAv8==-s0vAWcLSXEToH9Mik134q(u"࠲῕"): RnGKqWfH2YOp0zDaA = vZL6j4tSClIGxzNE5DX(u"ࠬࡺࡲࡪࡧࡧࠫᥳ")
			else:
				YDLrk8TptQE47mFine59GwxdfyaA = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
				SQdRhwozVfv(wwCMPEQvjF4kBApyIzXml,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬᥴ")+title+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ᥵")+RMC6c2kL5hGOnFaIwAyb+pTwKPmzMSZhil5d2RWonre(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ᥶")+str(YDLrk8TptQE47mFine59GwxdfyaA)+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࠣࡡࠬ᥷"))
				if OTRKI6LbrQnZEm(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭᥸") in YDLrk8TptQE47mFine59GwxdfyaA and QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ᥹") in YDLrk8TptQE47mFine59GwxdfyaA:
					nCs6r3iy1A0Bbzgk2vQEVcaFqZGS,XxAz2nKNP6ORDfaLFo7MQT4rsEde,kQlGI4ouaPwteZq9XgKB02 = c3p8udUeDGvSzn1PtlV(YDLrk8TptQE47mFine59GwxdfyaA)
					if kQlGI4ouaPwteZq9XgKB02: YDLrk8TptQE47mFine59GwxdfyaA = kQlGI4ouaPwteZq9XgKB02[h17Zb2ld4yLBrCP5tiw]
					else: YDLrk8TptQE47mFine59GwxdfyaA = QigevCplXxbPI1H
				if not YDLrk8TptQE47mFine59GwxdfyaA: RnGKqWfH2YOp0zDaA = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ᥺")
				else: RnGKqWfH2YOp0zDaA = B9BaTCd86Iwz1e3sRMXZylKpcHU(YDLrk8TptQE47mFine59GwxdfyaA,source,type)
			if RnGKqWfH2YOp0zDaA in [vZL6j4tSClIGxzNE5DX(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ᥻"),FF70emVxhWOngCty(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ᥼"),mpusoZBJ6V(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ᥽")] or len(ldFqnNIsftrY43JBM6LPjzU8m)==s0vAWcLSXEToH9Mik134q(u"࠳ῖ"): break
			elif RnGKqWfH2YOp0zDaA in [WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ᥾"),pTwKPmzMSZhil5d2RWonre(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ᥿"),mpusoZBJ6V(u"ࠫࡹࡸࡩࡦࡦࠪᦀ")]: break
			else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᦁ"),O4ylJvVNwLztdiHqBWDU(u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬᦂ"))
	else:
		RnGKqWfH2YOp0zDaA = pGncXOodjKhJzLSqVP1r(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᦃ")
		if z2dZ1anR6O(RMC6c2kL5hGOnFaIwAyb): RnGKqWfH2YOp0zDaA = B9BaTCd86Iwz1e3sRMXZylKpcHU(RMC6c2kL5hGOnFaIwAyb,source,type)
	return RnGKqWfH2YOp0zDaA,gcXCwZe9xP,ldFqnNIsftrY43JBM6LPjzU8m
def T0kZ3UeF4NL2YPGbzaSrEDA(url,source):
	Kj0TOU6BmSMlJHZYLd,WWXborTDPkCq6dBsZmU9,bSrdN78jxURTvh9,zmEW92NVcqxK73eU1,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	if tg9l25NH6WTacVSifLyAmY(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᦄ") in url:
		Kj0TOU6BmSMlJHZYLd,WWXborTDPkCq6dBsZmU9 = url.split(TCF8wLyDvgumfiXPSKRh(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᦅ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠴ῗ"))
		WWXborTDPkCq6dBsZmU9 = WWXborTDPkCq6dBsZmU9+OOhnpQ8XvCVclGqdu(u"ࠪࡣࡤ࠭ᦆ")+v54ZuLY6dQ(u"ࠫࡤࡥࠧᦇ")+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡥ࡟ࠨᦈ")+aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭࡟ࡠࠩᦉ")+FF70emVxhWOngCty(u"ࠧࡠࡡࠪᦊ")
		zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6,vmU4abqgc5ndeKHfCw7ETlXRNy, = WWXborTDPkCq6dBsZmU9.split(Fg72JX6T5DkPy(u"ࠨࡡࡢࠫᦋ"))[:DDHwpETQrAm0xMNXGfyhqsUi(u"࠺Ῐ")]
	if not oI6LvXMf4VEPe8jOdpKC0hUmS: oI6LvXMf4VEPe8jOdpKC0hUmS = bDt7Ya1VEio3(u"ࠩ࠳ࠫᦌ")
	else: oI6LvXMf4VEPe8jOdpKC0hUmS = oI6LvXMf4VEPe8jOdpKC0hUmS.replace(vZL6j4tSClIGxzNE5DX(u"ࠪࡴࠬᦍ"),QigevCplXxbPI1H).replace(hT7zFDpEyUqf8sXuN,QigevCplXxbPI1H)
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.strip(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࡄ࠭ᦎ")).strip(TCF8wLyDvgumfiXPSKRh(u"ࠬ࠵ࠧᦏ")).strip(tg9l25NH6WTacVSifLyAmY(u"࠭ࠦࠨᦐ"))
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,FF70emVxhWOngCty(u"ࠧࡩࡱࡶࡸࠬᦑ"))
	if zsj5qOxnfaXmdEco3DK29HgYybUCM6: zmEW92NVcqxK73eU1 = zsj5qOxnfaXmdEco3DK29HgYybUCM6
	else: zmEW92NVcqxK73eU1 = bSrdN78jxURTvh9
	zmEW92NVcqxK73eU1 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(zmEW92NVcqxK73eU1,y5yX4jh6kUEgWZQIc(u"ࠨࡰࡤࡱࡪ࠭ᦒ"))
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace(DD7NjwespWyQJ4E6mXk0ZAufPg(u"่ࠩฬฬฺัࠨᦓ"),QigevCplXxbPI1H).replace(OTRKI6LbrQnZEm(u"ࠪื๏ืแาࠩᦔ"),QigevCplXxbPI1H).replace(pGncXOodjKhJzLSqVP1r(u"ࠫฬ๊ࠠࠨᦕ"),hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	WWXborTDPkCq6dBsZmU9 = WWXborTDPkCq6dBsZmU9.replace(DD7NjwespWyQJ4E6mXk0ZAufPg(u"๋ࠬศศึิࠫᦖ"),QigevCplXxbPI1H).replace(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ำ๋ำไีࠬᦗ"),QigevCplXxbPI1H).replace(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧศๆࠣࠫᦘ"),hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	zmEW92NVcqxK73eU1 = zmEW92NVcqxK73eU1.replace(Xr2aHOK0huQ5DTS(u"ࠨ็หหูืࠧᦙ"),QigevCplXxbPI1H).replace(pGncXOodjKhJzLSqVP1r(u"ࠩึ๎ึ็ัࠨᦚ"),QigevCplXxbPI1H).replace(vZL6j4tSClIGxzNE5DX(u"ࠪห้ࠦࠧᦛ"),hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	return Kj0TOU6BmSMlJHZYLd,WWXborTDPkCq6dBsZmU9,bSrdN78jxURTvh9,zmEW92NVcqxK73eU1,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6
def OAu2RoLHeFwYs7D61cC(url,source):
	TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6,eesC3oVv0zu,rboPjVO2W0da4SLzqD7kI1pHiMT,K5zInlJPvNZ,GYju2SR1hXKenic9xPZkgol5VLbM,PPcCAi2DtLpyY4O78fQ9zmjx = QigevCplXxbPI1H,QigevCplXxbPI1H,None,None,None,None,None
	Kj0TOU6BmSMlJHZYLd,WWXborTDPkCq6dBsZmU9,bSrdN78jxURTvh9,zmEW92NVcqxK73eU1,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = T0kZ3UeF4NL2YPGbzaSrEDA(url,source)
	if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᦜ") in url:
		if   type==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࡫࡭ࡣࡧࡧࠫᦝ"): type = hT7zFDpEyUqf8sXuN+JJu4MPClbTFpUwHiN(u"࠭ๅโุ็ࠫᦞ")
		elif type==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡸࡣࡷࡧ࡭࠭ᦟ"): type = hT7zFDpEyUqf8sXuN+pTwKPmzMSZhil5d2RWonre(u"ࠨุ่ࠧฬํฯสࠩᦠ")
		elif type==O4ylJvVNwLztdiHqBWDU(u"ࠩࡥࡳࡹ࡮ࠧᦡ"): type = hT7zFDpEyUqf8sXuN+tg9l25NH6WTacVSifLyAmY(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬᦢ")
		elif type==TCF8wLyDvgumfiXPSKRh(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ᦣ"): type = hT7zFDpEyUqf8sXuN+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࠫࠥࠦฬะ้๏๊ࠧᦤ")
		elif type==QigevCplXxbPI1H: type = hT7zFDpEyUqf8sXuN+v54ZuLY6dQ(u"࠭ࠥࠦࠧࠨࠫᦥ")
		if ain78FlYBCWD31qLKEgT2bvIy!=QigevCplXxbPI1H:
			if v54ZuLY6dQ(u"ࠧ࡮ࡲ࠷ࠫᦦ") not in ain78FlYBCWD31qLKEgT2bvIy: ain78FlYBCWD31qLKEgT2bvIy = K7bLVaiRkx0lgU5SQM(u"ࠨࠧࠪᦧ")+ain78FlYBCWD31qLKEgT2bvIy
			ain78FlYBCWD31qLKEgT2bvIy = hT7zFDpEyUqf8sXuN+ain78FlYBCWD31qLKEgT2bvIy
		if oI6LvXMf4VEPe8jOdpKC0hUmS!=QigevCplXxbPI1H:
			oI6LvXMf4VEPe8jOdpKC0hUmS = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬᦨ")+oI6LvXMf4VEPe8jOdpKC0hUmS
			oI6LvXMf4VEPe8jOdpKC0hUmS = hT7zFDpEyUqf8sXuN+oI6LvXMf4VEPe8jOdpKC0hUmS[-bDt7Ya1VEio3(u"࠾Ῑ"):]
	if   fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡅࡐࡕࡁࡎࠩᦩ")		in source: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif tOrSvd8QKNB(u"ࠫࡆࡑࡗࡂࡏࠪᦪ")		in source: eesC3oVv0zu	= JJu4MPClbTFpUwHiN(u"ࠬࡧ࡫ࡸࡣࡰࠫᦫ")
	elif OOhnpQ8XvCVclGqdu(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥࠨ᦬")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif vZL6j4tSClIGxzNE5DX(u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭᦭")	in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif g4UCaNkHvLwGhjmW(u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ᦮")		in source: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif OOhnpQ8XvCVclGqdu(u"ࠩࡤࡰࡦࡸࡡࡣࠩ᦯")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif bDt7Ya1VEio3(u"ࠪࡪࡦࡹࡥ࡭ࠩᦰ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif vZL6j4tSClIGxzNE5DX(u"ࠫࡹ࠽࡭ࡦࡧ࡯ࠫᦱ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif OTRKI6LbrQnZEm(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬᦲ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif TCF8wLyDvgumfiXPSKRh(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨᦳ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif Xr2aHOK0huQ5DTS(u"ࠧࡧࡣ࡭ࡩࡷ࠭ᦴ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨใฯีࠬᦵ")			in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡩࡥ࡯࡫ࡲࠨᦶ")
	elif bDt7Ya1VEio3(u"ࠪๅู้ื๋่ࠪᦷ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= y5yX4jh6kUEgWZQIc(u"ࠫࡵࡧ࡬ࡦࡵࡷ࡭ࡳ࡫ࠧᦸ")
	elif Fg72JX6T5DkPy(u"ࠬ࡭ࡤࡳ࡫ࡹࡩࠬᦹ")		in Kj0TOU6BmSMlJHZYLd:   eesC3oVv0zu	= aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡧࡰࡱࡪࡰࡪ࠭ᦺ")
	elif FF70emVxhWOngCty(u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧᦻ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif OOhnpQ8XvCVclGqdu(u"ࠨࡹࡨࡧ࡮ࡳࡡࠨᦼ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif O4ylJvVNwLztdiHqBWDU(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᦽ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif OTRKI6LbrQnZEm(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫᦾ")		in zsj5qOxnfaXmdEco3DK29HgYybUCM6:   eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif FF70emVxhWOngCty(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩᦿ")	in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif pTwKPmzMSZhil5d2RWonre(u"ࠬࡨ࡯࡬ࡴࡤࠫᧀ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ࡴࡷࡨࡸࡲࠬᧁ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡵࡸ࡮ࡷࡦ࠭ᧂ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif OTRKI6LbrQnZEm(u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩᧃ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif Xr2aHOK0huQ5DTS(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫᧄ")		in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬᧅ")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠭ᧆ")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif pGncXOodjKhJzLSqVP1r(u"ࠬࡩࡩ࡮ࡣ࠷ࡹࠬᧇ")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif Fg72JX6T5DkPy(u"࠭ࡥࡨࡻࡱࡳࡼ࠭ᧈ")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif y5yX4jh6kUEgWZQIc(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩᧉ")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡥ࡬ࡱࡦࡧࡢࡥࡱࠪ᧊")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡼࡳࡺࡺࡵࠨ᧋")	 	in bSrdN78jxURTvh9: eesC3oVv0zu	= hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ᧌")
	elif tg9l25NH6WTacVSifLyAmY(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ᧍")	 	in bSrdN78jxURTvh9: eesC3oVv0zu	= aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭᧎")
	elif mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ᧏")	in bSrdN78jxURTvh9: eesC3oVv0zu	= zmEW92NVcqxK73eU1
	elif VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ᧐")	in bSrdN78jxURTvh9: eesC3oVv0zu	= vZL6j4tSClIGxzNE5DX(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ᧑")
	elif DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ᧒")		in bSrdN78jxURTvh9: eesC3oVv0zu	= pGncXOodjKhJzLSqVP1r(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬ᧓")
	elif svULcgJ7jm(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ᧔")		in bSrdN78jxURTvh9: eesC3oVv0zu	= pGncXOodjKhJzLSqVP1r(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧ᧕")
	elif OTRKI6LbrQnZEm(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ᧖")		in bSrdN78jxURTvh9: eesC3oVv0zu	= WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ᧗")
	elif hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ᧘")	in bSrdN78jxURTvh9: eesC3oVv0zu	= v54ZuLY6dQ(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ᧙")
	elif VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭᧚")	in bSrdN78jxURTvh9: eesC3oVv0zu	= y5yX4jh6kUEgWZQIc(u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ᧛")
	elif FF70emVxhWOngCty(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭᧜")		in bSrdN78jxURTvh9: eesC3oVv0zu	= bDt7Ya1VEio3(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ᧝")
	elif tg9l25NH6WTacVSifLyAmY(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ᧞")	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= tOrSvd8QKNB(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ᧟")
	elif Fg72JX6T5DkPy(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ᧠")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= K7bLVaiRkx0lgU5SQM(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ᧡")
	elif Fg72JX6T5DkPy(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭᧢")	 	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= v54ZuLY6dQ(u"ࠬࡩࡡࡵࡥ࡫ࠫ᧣")
	elif svULcgJ7jm(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ᧤")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ᧥")
	elif K7bLVaiRkx0lgU5SQM(u"ࠨࡸ࡬ࡨࡧࡳࠧ᧦")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= Fg72JX6T5DkPy(u"ࠩࡹ࡭ࡩࡨ࡭ࠨ᧧")
	elif pTwKPmzMSZhil5d2RWonre(u"ࠪࡺ࡮ࡪࡨࡥࠩ᧨")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif XWbHfI9B8swrOL(u"ࠫࡲࡿࡶࡪࡦࠪ᧩")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif JJu4MPClbTFpUwHiN(u"ࠬࡳࡹࡷ࡫࡬ࡨࠬ᧪")		in bSrdN78jxURTvh9: GYju2SR1hXKenic9xPZkgol5VLbM	= zmEW92NVcqxK73eU1
	elif y5yX4jh6kUEgWZQIc(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ᧫")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ᧬")
	elif bDt7Ya1VEio3(u"ࠨࡩࡲࡺ࡮ࡪࠧ᧭")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= XWbHfI9B8swrOL(u"ࠩࡪࡳࡻ࡯ࡤࠨ᧮")
	elif s0vAWcLSXEToH9Mik134q(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ᧯") 	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭᧰")
	elif g4UCaNkHvLwGhjmW(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ᧱")	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= pGncXOodjKhJzLSqVP1r(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ᧲")
	elif hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ᧳")	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= FF70emVxhWOngCty(u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭᧴")
	elif y5yX4jh6kUEgWZQIc(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭᧵") 	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ᧶")
	elif v54ZuLY6dQ(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ᧷")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭᧸")
	elif mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡵࡱࡲࠪ᧹") 			in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡶࡲࡥࡳࡲ࠭᧺")
	elif mpusoZBJ6V(u"ࠨࡷࡳࡦࠬ᧻") 			in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡸࡴࡧࡵ࡭ࠨ᧼")
	elif Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡹࡶࡲ࡯ࡢࡦࠪ᧽") 		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ᧾")
	elif VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ᧿") 	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨᨀ")
	elif TCF8wLyDvgumfiXPSKRh(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧᨁ")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= svULcgJ7jm(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨᨂ")
	elif Xr2aHOK0huQ5DTS(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩᨃ") 		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪᨄ")
	elif Xr2aHOK0huQ5DTS(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨᨅ") 	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= OTRKI6LbrQnZEm(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩᨆ")
	elif Xr2aHOK0huQ5DTS(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪᨇ")	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= s0vAWcLSXEToH9Mik134q(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫᨈ")
	elif WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬᨉ")	in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= XWbHfI9B8swrOL(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭ᨊ")
	elif DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪᨋ")		in bSrdN78jxURTvh9: rboPjVO2W0da4SLzqD7kI1pHiMT	= aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫᨌ")
	if   eesC3oVv0zu:	TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = s0vAWcLSXEToH9Mik134q(u"ࠬิวึࠩᨍ"),eesC3oVv0zu
	elif GYju2SR1hXKenic9xPZkgol5VLbM:		TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࠥๆฯาำࠬᨎ"),GYju2SR1hXKenic9xPZkgol5VLbM
	elif rboPjVO2W0da4SLzqD7kI1pHiMT:		TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = TCF8wLyDvgumfiXPSKRh(u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬᨏ"),rboPjVO2W0da4SLzqD7kI1pHiMT
	elif K5zInlJPvNZ:	TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧᨐ"),K5zInlJPvNZ
	elif PPcCAi2DtLpyY4O78fQ9zmjx:	TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩᨑ"),zmEW92NVcqxK73eU1
	else:			TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫᨒ"),zmEW92NVcqxK73eU1
	return TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS
def jrG0Ah4COFRV5i3afexwT(url,source):
	Kj0TOU6BmSMlJHZYLd,GYju2SR1hXKenic9xPZkgol5VLbM,bSrdN78jxURTvh9,zmEW92NVcqxK73eU1,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = T0kZ3UeF4NL2YPGbzaSrEDA(url,source)
	if   y5yX4jh6kUEgWZQIc(u"ࠫࡆࡑࡏࡂࡏࠪᨓ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = LgyfTlFJC3(Kj0TOU6BmSMlJHZYLd,zsj5qOxnfaXmdEco3DK29HgYybUCM6)
	elif y5yX4jh6kUEgWZQIc(u"ࠬࡇࡋࡘࡃࡐࠫᨔ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = kkERyGgDWI(Kj0TOU6BmSMlJHZYLd,type,oI6LvXMf4VEPe8jOdpKC0hUmS)
	elif mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᨕ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = tIuoSjwAEZ(Kj0TOU6BmSMlJHZYLd)
	elif O4ylJvVNwLztdiHqBWDU(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᨖ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ikY7SnFWRE(Kj0TOU6BmSMlJHZYLd)
	elif DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡻࡲࡹࡹࡻࠧᨗ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ikY7SnFWRE(Kj0TOU6BmSMlJHZYLd)
	elif tg9l25NH6WTacVSifLyAmY(u"ࠩࡼ࠶ࡺ࠴ࡢࡦᨘࠩ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ikY7SnFWRE(Kj0TOU6BmSMlJHZYLd)
	elif QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪᨙ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = Jv9dkHFNmq(Kj0TOU6BmSMlJHZYLd)
	elif aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ᨚ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = xKNzwc5Jhp(Kj0TOU6BmSMlJHZYLd)
	elif svULcgJ7jm(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧᨛ")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ddwWLZ315h(Kj0TOU6BmSMlJHZYLd)
	elif fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ᨜")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = Pe1N9oEwBQ(Kj0TOU6BmSMlJHZYLd)
	elif aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡔࡊࡒࡊࡍࡇࠧ᨝")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = bh6GSD1NJp(Kj0TOU6BmSMlJHZYLd)
	elif XWbHfI9B8swrOL(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ᨞")		in source: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = yyrKVk7Tl8(Kj0TOU6BmSMlJHZYLd,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6)
	elif NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫ᨟")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = zzwTfWEtBN(Kj0TOU6BmSMlJHZYLd)
	elif JJu4MPClbTFpUwHiN(u"ࠪࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭ᨠ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = on6lS1PVQD(Kj0TOU6BmSMlJHZYLd)
	elif QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡦࡲࡡࡳࡣࡥࠫᨡ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = nL6zQkfyY3EOSm7(Kj0TOU6BmSMlJHZYLd)
	elif OOhnpQ8XvCVclGqdu(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧᨢ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = Q8XUhOplV9(Kj0TOU6BmSMlJHZYLd)
	elif mpusoZBJ6V(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨᨣ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = Q8XUhOplV9(Kj0TOU6BmSMlJHZYLd)
	elif hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡦࡩࡼࡲࡴࡽࠧᨤ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = p4H1dtwvk9(Kj0TOU6BmSMlJHZYLd)
	elif OOhnpQ8XvCVclGqdu(u"ࠨࡶࡹࡪࡺࡴࠧᨥ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ggl2cikBed(Kj0TOU6BmSMlJHZYLd)
	elif NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡷࡺࡰࡹࡡࠨᨦ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ggl2cikBed(Kj0TOU6BmSMlJHZYLd)
	elif aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡸࡻ࠳ࡦ࠯ࡥࡲࡱࠬᨧ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ggl2cikBed(Kj0TOU6BmSMlJHZYLd)
	elif QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠭ᨨ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = MMPgAmhWqX(Kj0TOU6BmSMlJHZYLd)
	elif OTRKI6LbrQnZEm(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧᨩ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = RflsiP2MmZ(Kj0TOU6BmSMlJHZYLd)
	elif K7bLVaiRkx0lgU5SQM(u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨᨪ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = e3b91aL8OyojAs(Kj0TOU6BmSMlJHZYLd)
	elif XWbHfI9B8swrOL(u"ࠧࡷࡵ࠷ࡹࠬᨫ")			in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = LMRkxQV5j6(Kj0TOU6BmSMlJHZYLd)
	elif OTRKI6LbrQnZEm(u"ࠨࡨࡤ࡮ࡪࡸࠧᨬ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = zVn5N1ujF0(Kj0TOU6BmSMlJHZYLd)
	elif O4ylJvVNwLztdiHqBWDU(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪᨭ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ssTIo54KM1(Kj0TOU6BmSMlJHZYLd)
	elif NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡲࡪࡽࡣࡪ࡯ࡤࠫᨮ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ssTIo54KM1(Kj0TOU6BmSMlJHZYLd)
	elif O4ylJvVNwLztdiHqBWDU(u"ࠫࡨ࡯࡭ࡢ࠯࡯࡭࡬࡮ࡴࠨᨯ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = MGUDSETYwn(Kj0TOU6BmSMlJHZYLd)
	elif svULcgJ7jm(u"ࠬࡩࡩ࡮ࡣ࡯࡭࡬࡮ࡴࠨᨰ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = MGUDSETYwn(Kj0TOU6BmSMlJHZYLd)
	elif XWbHfI9B8swrOL(u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭ᨱ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = YgfswWlCO1(Kj0TOU6BmSMlJHZYLd)
	elif JJu4MPClbTFpUwHiN(u"ࠧࡸࡧࡦ࡭ࡲࡧࠧᨲ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = FCjhbSetXr(Kj0TOU6BmSMlJHZYLd)
	elif mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡤࡲ࡯ࡷࡧࠧᨳ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = gzhm8lLXR0(Kj0TOU6BmSMlJHZYLd)
	elif svULcgJ7jm(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧᨴ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = rYtXalHbju(Kj0TOU6BmSMlJHZYLd)
	elif y5yX4jh6kUEgWZQIc(u"ࠪࡥࡷࡨ࡬ࡪࡱࡱࡾࠬᨵ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = UwKh83oDl1(Kj0TOU6BmSMlJHZYLd)
	elif FF70emVxhWOngCty(u"ࠫࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪᨶ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = B6keJXpbSa(Kj0TOU6BmSMlJHZYLd)
	elif svULcgJ7jm(u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪᨷ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	elif bDt7Ya1VEio3(u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧᨸ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ymHvX9woJW(Kj0TOU6BmSMlJHZYLd)
	elif K7bLVaiRkx0lgU5SQM(u"ࠧࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠭ᨹ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = v8ShNal6bj(Kj0TOU6BmSMlJHZYLd)
	elif O4ylJvVNwLztdiHqBWDU(u"ࠨࡷࡳࡦࡦࡳࠧᨺ") 		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	else: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = JJu4MPClbTFpUwHiN(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᨻ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	if gcXCwZe9xP!=Fg72JX6T5DkPy(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᨼ"): gcXCwZe9xP = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧᨽ")+gcXCwZe9xP
	return gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def p8GfkE4DKLyjACvuszb3Yxn(gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m):
	hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL = [],[]
	for title,RMC6c2kL5hGOnFaIwAyb in zip(ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m):
		if z2dZ1anR6O(RMC6c2kL5hGOnFaIwAyb):
			hu8mLEVaH12kwABO7nKtUpybXM.append(title)
			rsBojxT8UZwL.append(RMC6c2kL5hGOnFaIwAyb)
	if not rsBojxT8UZwL and not gcXCwZe9xP: gcXCwZe9xP = pGncXOodjKhJzLSqVP1r(u"ࠬࡌࡡࡪ࡮ࡨࡨࠬᨾ")
	return gcXCwZe9xP,hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL
def iudGyJsfbF7Aa5U8WToY3NISv4(VVBLsmOuvzC,url,source,bb6LKGv5OYmaWIHz3ZfuUS):
	global hV7CwFI9Z23PSv6,xTBtlJcMDR3ojraeHNuW6s5LVKPE2g,ffbEAoQPeYlnJwpUGz1aD7tOuscHmS,ONYjJuG4ClZ,j30vnGJTzmftkMaebxI5KVDFyZC
	qLnAf927tO = []
	ZadVLkU4fWXIj = (O4ylJvVNwLztdiHqBWDU(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧᨿ"),[],[])
	xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS],ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS],ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS],j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS] = ZadVLkU4fWXIj,ZadVLkU4fWXIj,ZadVLkU4fWXIj,ZadVLkU4fWXIj
	LYet4jPBzng = [AjGNq3t90S2ezHCwvp8mTcaPdfBg1,aeRSWXnO6to,w10gfQcXWspMR,TvgSjy4lMJpdB2FPQrqUnGKIRAft]
	for vvyOFYECnRzP9mhQSc in LYet4jPBzng:
		YYhr8yLE6KCe7kt4Ri = VVGXMeyJq25S6tf.Thread(target=vvyOFYECnRzP9mhQSc,args=(url,source,bb6LKGv5OYmaWIHz3ZfuUS))
		YYhr8yLE6KCe7kt4Ri.start()
		if xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᩀ") or (not xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		if ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==s0vAWcLSXEToH9Mik134q(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᩁ") or (not ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		if ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==tOrSvd8QKNB(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᩂ") or (not ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		if j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᩃ") or (not j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		B3TKLo71hAGRqYgV0.sleep(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠮࠸࠷Ὶ"))
		qLnAf927tO.append(YYhr8yLE6KCe7kt4Ri)
	timeout,step = XWbHfI9B8swrOL(u"࠴࠲῜"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠲Ί")
	for ZadVLkU4fWXIj in range(timeout//step):
		if xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==svULcgJ7jm(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᩄ") or (not xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		if ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==v54ZuLY6dQ(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᩅ") or (not ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		if ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᩆ") or (not ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		if j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw]==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᩇ") or (not j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS][h17Zb2ld4yLBrCP5tiw] and j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS][JxuTQLOD357o41evylqPmRdf]): break
		B3TKLo71hAGRqYgV0.sleep(step)
	for YYhr8yLE6KCe7kt4Ri in qLnAf927tO: YYhr8yLE6KCe7kt4Ri.join(FF70emVxhWOngCty(u"࠳῝"))
	Qz71n3ZBC28sKV5UgkTAF = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠸ࠧᩈ")
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS]
	ldFqnNIsftrY43JBM6LPjzU8m = TTPODWBYHSIClG1gpVsZ8(ldFqnNIsftrY43JBM6LPjzU8m)
	hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	if gcXCwZe9xP==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᩉ") or ldFqnNIsftrY43JBM6LPjzU8m: return Qz71n3ZBC28sKV5UgkTAF,gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	VVBLsmOuvzC += mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠣࠤࠬᩊ")+gcXCwZe9xP.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)[:OTRKI6LbrQnZEm(u"࠻࠴῞")]
	Qz71n3ZBC28sKV5UgkTAF = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪᩋ")
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS]
	ldFqnNIsftrY43JBM6LPjzU8m = TTPODWBYHSIClG1gpVsZ8(ldFqnNIsftrY43JBM6LPjzU8m)
	hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	if gcXCwZe9xP==Fg72JX6T5DkPy(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᩌ") or ldFqnNIsftrY43JBM6LPjzU8m: return Qz71n3ZBC28sKV5UgkTAF,gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	VVBLsmOuvzC += bDt7Ya1VEio3(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠷࠿ࠦࠠࠨᩍ")+gcXCwZe9xP.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)[:TCF8wLyDvgumfiXPSKRh(u"࠼࠵῟")]
	Qz71n3ZBC28sKV5UgkTAF = y5yX4jh6kUEgWZQIc(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠹࠭ᩎ")
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS]
	ldFqnNIsftrY43JBM6LPjzU8m = TTPODWBYHSIClG1gpVsZ8(ldFqnNIsftrY43JBM6LPjzU8m)
	hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	if gcXCwZe9xP==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᩏ") or ldFqnNIsftrY43JBM6LPjzU8m: return Qz71n3ZBC28sKV5UgkTAF,gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	VVBLsmOuvzC += mmKqLr9RX0ACN384JMcsFHzd(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠴࠻ࠢࠣࠫᩐ")+gcXCwZe9xP.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)[:VvhRUZgko5Af1BIynMGOJSbpmK(u"࠽࠶ῠ")]
	Qz71n3ZBC28sKV5UgkTAF = s0vAWcLSXEToH9Mik134q(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠶ࠩᩑ")
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS]
	ldFqnNIsftrY43JBM6LPjzU8m = TTPODWBYHSIClG1gpVsZ8(ldFqnNIsftrY43JBM6LPjzU8m)
	hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	if gcXCwZe9xP==tOrSvd8QKNB(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᩒ") or ldFqnNIsftrY43JBM6LPjzU8m: return Qz71n3ZBC28sKV5UgkTAF,gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	VVBLsmOuvzC += mpusoZBJ6V(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠸࠾ࠥࠦࠧᩓ")+gcXCwZe9xP.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)[:Fg72JX6T5DkPy(u"࠾࠰ῡ")]
	hV7CwFI9Z23PSv6[bb6LKGv5OYmaWIHz3ZfuUS] = VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	return Qz71n3ZBC28sKV5UgkTAF,VVBLsmOuvzC,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def AjGNq3t90S2ezHCwvp8mTcaPdfBg1(url,source,bb6LKGv5OYmaWIHz3ZfuUS):
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,O4ylJvVNwLztdiHqBWDU(u"࠭࡮ࡢ࡯ࡨࠫᩔ"))
	ldFqnNIsftrY43JBM6LPjzU8m = []
	if vZL6j4tSClIGxzNE5DX(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬᩕ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = rYtXalHbju(url)
	elif JJu4MPClbTFpUwHiN(u"ࠨࡩࡲࡳ࡬ࡲࡥࡶࡵࡨࡶࡨࡵࠧᩖ") in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = HHGWlUDvAzTJP1Z9Xam8tjw7g2e(url)
	elif fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡼࡳࡺࡺࡵࠨᩗ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ikY7SnFWRE(url)
	elif tOrSvd8QKNB(u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪᩘ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ikY7SnFWRE(url)
	elif Fg72JX6T5DkPy(u"ࠫࡵ࡮࡯ࡵࡱࡶ࠲ࡦࡶࡰ࠯ࡩࠪᩙ")	in url   : gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = JDzGrVCWUM2npvitFTylaRq9Akbg(url)
	elif g4UCaNkHvLwGhjmW(u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧࠧᩚ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = c3p8udUeDGvSzn1PtlV(url)
	elif NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧᩛ")		in url   : gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = tIuoSjwAEZ(url)
	elif vZL6j4tSClIGxzNE5DX(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪᩜ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = psXH7NlyKWrtaf3qbiZ(url)
	elif Fg72JX6T5DkPy(u"ࠨࡣࡵࡧ࡭࡯ࡶࡦࠩᩝ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = NNritfW7KyEPu(url)
	elif fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪᩞ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = BpljQVWu7AHdUreY0tPaTS(url)
	elif g4UCaNkHvLwGhjmW(u"ࠪࡩ࠺ࡺࡳࡢࡴࠪ᩟")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = J2Y7yqHDguKbse6iOQ5lo0CLx(url)
	elif g4UCaNkHvLwGhjmW(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵ᩠ࠪ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = fntbcviROlkdGWHSsKeFLVgjoBJ(url)
	elif y5yX4jh6kUEgWZQIc(u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨᩡ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = fntbcviROlkdGWHSsKeFLVgjoBJ(url)
	elif pGncXOodjKhJzLSqVP1r(u"࠭ࡵࡱࡤࡤࡱࠬᩢ") 		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[QigevCplXxbPI1H],[url]
	elif Fg72JX6T5DkPy(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩᩣ") 	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = YHAOC38h7lr4mGZj(url)
	elif WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫᩤ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = KFa17tYgX6iC(url)
	elif OOhnpQ8XvCVclGqdu(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭ᩥ") 	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = OjVCNXx1pJS(url)
	elif tg9l25NH6WTacVSifLyAmY(u"ࠪࡸࡴࡶ࠴ࡵࡱࡳࠫᩦ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = k7ZShnuRNmAQXJ(url)
	elif tOrSvd8QKNB(u"ࠫࡺࡶࡢࠨᩧ") 			in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = KnyDmaUqRv3JuSzOi4BA5w7LgXECh(url)
	elif svULcgJ7jm(u"ࠬࡻࡰࡱࠩᩨ") 			in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = KnyDmaUqRv3JuSzOi4BA5w7LgXECh(url)
	elif y5yX4jh6kUEgWZQIc(u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭ᩩ") 		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = nna4iu9HUeKb30L(url)
	elif Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩᩪ") 	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = VyOU3WrCbidm(url)
	elif s0vAWcLSXEToH9Mik134q(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨᩫ")		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = tS0iV5xjYlQJm1ynMrgFdAINb(url)
	elif hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡹ࡭ࡩࡵࡺࡢࠩᩬ") 		in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = z2zJLkfHa0oQvNKYEBS96(url)
	elif g4UCaNkHvLwGhjmW(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧᩭ") 	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = XB6wFC8O73(url)
	elif tg9l25NH6WTacVSifLyAmY(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨᩮ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = MaPtmv9NcsUdKurjq2Gb0SA3BR(url)
	elif XWbHfI9B8swrOL(u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩᩯ")	in bSrdN78jxURTvh9: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = qiRVEdg23KmwbHOlJ8X5MD(url)
	else: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[],[]
	global xTBtlJcMDR3ojraeHNuW6s5LVKPE2g
	if gcXCwZe9xP and gcXCwZe9xP!=bDt7Ya1VEio3(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᩰ"): gcXCwZe9xP = g4UCaNkHvLwGhjmW(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࠪᩱ")
	xTBtlJcMDR3ojraeHNuW6s5LVKPE2g[bb6LKGv5OYmaWIHz3ZfuUS] = gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	return
def aeRSWXnO6to(url,source,bb6LKGv5OYmaWIHz3ZfuUS):
	global ffbEAoQPeYlnJwpUGz1aD7tOuscHmS
	if TCF8wLyDvgumfiXPSKRh(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩᩲ") in url:
		ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS] = mpusoZBJ6V(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࡘࡱࡩࡱࡲࡨࡨࠬᩳ"),[],[]
		return
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[],[]
	if z2dZ1anR6O(url): gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[QigevCplXxbPI1H],[url]
	if not ldFqnNIsftrY43JBM6LPjzU8m: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = xxt9lH4aVTdOAMjUS7hPe(url)
	if not ldFqnNIsftrY43JBM6LPjzU8m: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = ooBc6t7ZNASGhLM4HWp(url)
	if not ldFqnNIsftrY43JBM6LPjzU8m:
		if gcXCwZe9xP==XWbHfI9B8swrOL(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᩴ"): gcXCwZe9xP = QigevCplXxbPI1H
		ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS] = XWbHfI9B8swrOL(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧ᩵")+gcXCwZe9xP,[],[]
		return
	ffbEAoQPeYlnJwpUGz1aD7tOuscHmS[bb6LKGv5OYmaWIHz3ZfuUS] = gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	return
def w10gfQcXWspMR(url,source,bb6LKGv5OYmaWIHz3ZfuUS):
	THFfWLwt62MmUz = QigevCplXxbPI1H
	W9lfsoMawqOzpQcXD = YoAMfqm37GyFxbuKTt6e8CESHrhB
	try:
		import resolveurl as NnDL4TMswbRv1Qpdl6gPAEqBhSC
		W9lfsoMawqOzpQcXD = NnDL4TMswbRv1Qpdl6gPAEqBhSC.resolve(url)
	except Exception as wjgVENDB1QoPCbpn: THFfWLwt62MmUz = str(wjgVENDB1QoPCbpn)
	global ONYjJuG4ClZ
	if not W9lfsoMawqOzpQcXD:
		if THFfWLwt62MmUz==QigevCplXxbPI1H:
			THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
			if THFfWLwt62MmUz!=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨ᩶"): KXhrv29CGR8QTDzJIWLY.stderr.write(THFfWLwt62MmUz)
		gcXCwZe9xP = THFfWLwt62MmUz.splitlines()[-mpusoZBJ6V(u"࠱ῢ")]
		ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS] = Fg72JX6T5DkPy(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩ᩷")+gcXCwZe9xP,[],[]
		return
	ONYjJuG4ClZ[bb6LKGv5OYmaWIHz3ZfuUS] = QigevCplXxbPI1H,[QigevCplXxbPI1H],[W9lfsoMawqOzpQcXD]
	return
def TvgSjy4lMJpdB2FPQrqUnGKIRAft(url,source,bb6LKGv5OYmaWIHz3ZfuUS):
	THFfWLwt62MmUz = QigevCplXxbPI1H
	W9lfsoMawqOzpQcXD = YoAMfqm37GyFxbuKTt6e8CESHrhB
	try:
		import yt_dlp as Szv2fXZihtI3qBpVEHu61cF
		pUjMulxD30QAq1 = Szv2fXZihtI3qBpVEHu61cF.YoutubeDL({OTRKI6LbrQnZEm(u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩ᩸"): XpREPf7d08GnIS6i4KNLMyZHmuQqxD})
		W9lfsoMawqOzpQcXD = pUjMulxD30QAq1.extract_info(url,download=YoAMfqm37GyFxbuKTt6e8CESHrhB)
	except Exception as wjgVENDB1QoPCbpn: THFfWLwt62MmUz = str(wjgVENDB1QoPCbpn)
	global j30vnGJTzmftkMaebxI5KVDFyZC
	if not W9lfsoMawqOzpQcXD or OOhnpQ8XvCVclGqdu(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ᩹") not in list(W9lfsoMawqOzpQcXD.keys()):
		if THFfWLwt62MmUz==QigevCplXxbPI1H:
			THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
			if THFfWLwt62MmUz!=vZL6j4tSClIGxzNE5DX(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬ᩺"): KXhrv29CGR8QTDzJIWLY.stderr.write(THFfWLwt62MmUz)
		gcXCwZe9xP = THFfWLwt62MmUz.splitlines()[-Xr2aHOK0huQ5DTS(u"࠲ΰ")]
		j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS] = FF70emVxhWOngCty(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥ࠭᩻")+gcXCwZe9xP,[],[]
	else:
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
		for RMC6c2kL5hGOnFaIwAyb in W9lfsoMawqOzpQcXD[svULcgJ7jm(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ᩼")]:
			ttGBwQOv3K41hIkc6.append(RMC6c2kL5hGOnFaIwAyb[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬ᩽")])
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb[OOhnpQ8XvCVclGqdu(u"࠭ࡵࡳ࡮ࠪ᩾")])
		j30vnGJTzmftkMaebxI5KVDFyZC[bb6LKGv5OYmaWIHz3ZfuUS] = QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	return
def xxt9lH4aVTdOAMjUS7hPe(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,XWbHfI9B8swrOL(u"ࠧࡈࡇࡗ᩿ࠫ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,v54ZuLY6dQ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡋࡄࡊࡔࡈࡇ࡙ࡥࡕࡓࡎ࠰࠵ࡸࡺࠧ᪀"))
	headers = JJrhP4C6osGDFEKVSRBvX.headers
	if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ᪁") in list(headers.keys()):
		RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[y5yX4jh6kUEgWZQIc(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ᪂")]
		if z2dZ1anR6O(RMC6c2kL5hGOnFaIwAyb): return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	return DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧ᪃"),[],[]
def TTPODWBYHSIClG1gpVsZ8(G0RTQfMtClr5zXvaOxgepE9VYS):
	if bDt7Ya1VEio3(u"ࠬࡲࡩࡴࡶࠪ᪄") in str(type(G0RTQfMtClr5zXvaOxgepE9VYS)):
		rsBojxT8UZwL = []
		for RMC6c2kL5hGOnFaIwAyb in G0RTQfMtClr5zXvaOxgepE9VYS:
			if fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡳࡵࡴࠪ᪅") in str(type(RMC6c2kL5hGOnFaIwAyb)): RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H).replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			rsBojxT8UZwL.append(RMC6c2kL5hGOnFaIwAyb)
	else: rsBojxT8UZwL = G0RTQfMtClr5zXvaOxgepE9VYS.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H).replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
	return rsBojxT8UZwL
def LbmgyAdKr5UQSoaZExu7(kQlGI4ouaPwteZq9XgKB02,source):
	WoITajU9q2EgcGKFbnm1 = g6gNzml5rOsa8bBETxPCpnVj
	data = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,JJu4MPClbTFpUwHiN(u"ࠧ࡭࡫ࡶࡸࠬ᪆"),aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ᪇"),kQlGI4ouaPwteZq9XgKB02)
	if data:
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = list(zip(*data))
		return ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,zZd8Upsryq74ONXKLlcSwP3xHb520 = [],[],[]
	for RMC6c2kL5hGOnFaIwAyb in kQlGI4ouaPwteZq9XgKB02:
		if pTwKPmzMSZhil5d2RWonre(u"ࠩ࠲࠳ࠬ᪈") not in RMC6c2kL5hGOnFaIwAyb: continue
		TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS = OAu2RoLHeFwYs7D61cC(RMC6c2kL5hGOnFaIwAyb,source)
		oI6LvXMf4VEPe8jOdpKC0hUmS = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"ࠪࡠࡩ࠱ࠧ᪉"),oI6LvXMf4VEPe8jOdpKC0hUmS,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if oI6LvXMf4VEPe8jOdpKC0hUmS: oI6LvXMf4VEPe8jOdpKC0hUmS = int(oI6LvXMf4VEPe8jOdpKC0hUmS[h17Zb2ld4yLBrCP5tiw])
		else: oI6LvXMf4VEPe8jOdpKC0hUmS = OTRKI6LbrQnZEm(u"࠲ῤ")
		bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࡳࡧ࡭ࡦࠩ᪊"))
		zZd8Upsryq74ONXKLlcSwP3xHb520.append([TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,RMC6c2kL5hGOnFaIwAyb,bSrdN78jxURTvh9])
	if zZd8Upsryq74ONXKLlcSwP3xHb520:
		LL7Epny8KemPGF6NQiTXBw = sorted(zZd8Upsryq74ONXKLlcSwP3xHb520,reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,key=lambda key: (key[bWU9StnJOg6aIQiTMxh7sFZG8lPud],key[h17Zb2ld4yLBrCP5tiw],key[mVjHAyIwzSNKLFcd],key[JxuTQLOD357o41evylqPmRdf],key[nfC2im3NzUQk],key[XWbHfI9B8swrOL(u"࠸ῥ")],key[mmKqLr9RX0ACN384JMcsFHzd(u"࠺ῦ")]))
		bT4rFPxEGc5Dq2piofWnCg = []
		for lP9YsOehk3r8HWpxC in LL7Epny8KemPGF6NQiTXBw:
			if lP9YsOehk3r8HWpxC not in bT4rFPxEGc5Dq2piofWnCg:
				bT4rFPxEGc5Dq2piofWnCg.append(lP9YsOehk3r8HWpxC)
		for TOj4Ee25brzwQdfnyAD9VK,zsj5qOxnfaXmdEco3DK29HgYybUCM6,type,ain78FlYBCWD31qLKEgT2bvIy,oI6LvXMf4VEPe8jOdpKC0hUmS,RMC6c2kL5hGOnFaIwAyb,bSrdN78jxURTvh9 in bT4rFPxEGc5Dq2piofWnCg:
			if oI6LvXMf4VEPe8jOdpKC0hUmS: oI6LvXMf4VEPe8jOdpKC0hUmS = str(oI6LvXMf4VEPe8jOdpKC0hUmS)
			else: oI6LvXMf4VEPe8jOdpKC0hUmS = QigevCplXxbPI1H
			title = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ู๊ࠬาใิࠫ᪋")+hT7zFDpEyUqf8sXuN+type+hT7zFDpEyUqf8sXuN+TOj4Ee25brzwQdfnyAD9VK+hT7zFDpEyUqf8sXuN+oI6LvXMf4VEPe8jOdpKC0hUmS+hT7zFDpEyUqf8sXuN+ain78FlYBCWD31qLKEgT2bvIy+hT7zFDpEyUqf8sXuN+zsj5qOxnfaXmdEco3DK29HgYybUCM6
			if bSrdN78jxURTvh9 not in title: title = title+hT7zFDpEyUqf8sXuN+bSrdN78jxURTvh9
			title = title.replace(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࠥࠨ᪌"),QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
			if RMC6c2kL5hGOnFaIwAyb not in ldFqnNIsftrY43JBM6LPjzU8m:
				ttGBwQOv3K41hIkc6.append(title)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		if ldFqnNIsftrY43JBM6LPjzU8m:
			data = list(zip(ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m))
			if data: BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡔࡇࡕ࡚ࡊࡘࡓࠨ᪍"),kQlGI4ouaPwteZq9XgKB02,data,WoITajU9q2EgcGKFbnm1)
	return ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def nL6zQkfyY3EOSm7(url):
	if pGncXOodjKhJzLSqVP1r(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ᪎") in url:
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = HHSM1J4ofulwIPqTjnQA(url)
		if ldFqnNIsftrY43JBM6LPjzU8m: return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
		return QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࠹ࡕ࠹ࠩ᪏"),[],[]
	return QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᪐"),[QigevCplXxbPI1H],[url]
def zzwTfWEtBN(url):
	vdLczqkV5b48ZKyGxTE3jJi17aWS6,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw = [],[]
	if Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫ࠴ࡼࡩࡥࡧࡲࡷ࠳ࡳࡰ࠵ࡁࡹ࡭ࡩࡃࠧ᪑") in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡍࡅࡕࠩ᪒"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱࠶ࡹࡴࠨ᪓"))
		if aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ᪔") in JJrhP4C6osGDFEKVSRBvX.headers:
			RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ᪕")]
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
			bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡱࡥࡲ࡫ࠧ᪖"))
			xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(bSrdN78jxURTvh9)
	elif WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩ࠳ࡩ࡯࡮ࠩ᪗") in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,Xr2aHOK0huQ5DTS(u"ࠫࡌࡋࡔࠨ᪘"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠶ࡳࡪࠧ᪙"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		ixUV6tokgq0K8a = sBvufaD6c9YHdOqTjCQ3.findall(svULcgJ7jm(u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪࠫ࠱ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭᪚"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if ixUV6tokgq0K8a:
			ixUV6tokgq0K8a = ixUV6tokgq0K8a[h17Zb2ld4yLBrCP5tiw]
			xu3Kmpia9Q0RvB5ZwnhLYNF = eCLWPXUqk9uo(ixUV6tokgq0K8a)
			zfljGLIQwP6U = sBvufaD6c9YHdOqTjCQ3.findall(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠪ࡟࡟࠳࠰࠿࡝࡟ࠬ࠰ࠬ᪛"),xu3Kmpia9Q0RvB5ZwnhLYNF,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if zfljGLIQwP6U:
				zfljGLIQwP6U = zfljGLIQwP6U[h17Zb2ld4yLBrCP5tiw]
				zfljGLIQwP6U = CH86N7xw4cyPt3TlIBJF(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨ࡮࡬ࡷࡹ࠭᪜"),zfljGLIQwP6U)
				for dict in zfljGLIQwP6U:
					RMC6c2kL5hGOnFaIwAyb = dict[s0vAWcLSXEToH9Mik134q(u"ࠩࡩ࡭ࡱ࡫ࠧ᪝")]
					oI6LvXMf4VEPe8jOdpKC0hUmS = dict[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡰࡦࡨࡥ࡭ࠩ᪞")]
					vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
					bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,pGncXOodjKhJzLSqVP1r(u"ࠫࡳࡧ࡭ࡦࠩ᪟"))
					xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(oI6LvXMf4VEPe8jOdpKC0hUmS+hT7zFDpEyUqf8sXuN+bSrdN78jxURTvh9)
		elif bDt7Ya1VEio3(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ᪠") in JJrhP4C6osGDFEKVSRBvX.headers:
			RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[y5yX4jh6kUEgWZQIc(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ᪡")]
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
			bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧ࡯ࡣࡰࡩࠬ᪢"))
			xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(bSrdN78jxURTvh9)
		if O4ylJvVNwLztdiHqBWDU(u"ࠨࡁࡸࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬ࡵ࡯ࠨ᪣") in url:
			RMC6c2kL5hGOnFaIwAyb = url.split(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡂࡹࡷࡲ࠽ࠨ᪤"))[nfC2im3NzUQk]
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.split(g4UCaNkHvLwGhjmW(u"ࠪࠪࠬ᪥"))[h17Zb2ld4yLBrCP5tiw]
			if RMC6c2kL5hGOnFaIwAyb:
				vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
				xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(y5yX4jh6kUEgWZQIc(u"ࠫࡵ࡮࡯ࡵࡱࡶࠤ࡬ࡵ࡯ࡨ࡮ࡨࠫ᪦"))
	else:
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(url)
		bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,OTRKI6LbrQnZEm(u"ࠬࡴࡡ࡮ࡧࠪᪧ"))
		xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(bSrdN78jxURTvh9)
	if not vdLczqkV5b48ZKyGxTE3jJi17aWS6: return vZL6j4tSClIGxzNE5DX(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡍࡄࡘࡐࡕࡕࡕࡇࠪ᪨"),[],[]
	elif len(vdLczqkV5b48ZKyGxTE3jJi17aWS6)==OTRKI6LbrQnZEm(u"࠶ῧ"): RMC6c2kL5hGOnFaIwAyb = vdLczqkV5b48ZKyGxTE3jJi17aWS6[h17Zb2ld4yLBrCP5tiw]
	else:
		HHZ6579kAv8 = zYWJO03iISD(y5yX4jh6kUEgWZQIc(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ᪩"),xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw)
		if HHZ6579kAv8==-fk8jc5uDLX16qrih3ZaPxsvO(u"࠷Ῠ"): return y5yX4jh6kUEgWZQIc(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᪪"),[],[]
		RMC6c2kL5hGOnFaIwAyb = vdLczqkV5b48ZKyGxTE3jJi17aWS6[HHZ6579kAv8]
	return tOrSvd8QKNB(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᪫"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def HHGWlUDvAzTJP1Z9Xam8tjw7g2e(url):
	headers = {WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᪬"):pTwKPmzMSZhil5d2RWonre(u"ࠫࡐࡵࡤࡪ࠱ࠪ᪭")+str(aybmzWnDkuEcT3jpJClB2)}
	for GzabfJx3T1 in range(Xr2aHOK0huQ5DTS(u"࠵࠱Ῡ")):
		B3TKLo71hAGRqYgV0.sleep(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠱࠰࠴࠴࠵Ὺ"))
		JJrhP4C6osGDFEKVSRBvX = ISAO6PGrtB5u1edT4Jif0mq(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡍࡅࡕࠩ᪮"),url,QigevCplXxbPI1H,headers,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,tOrSvd8QKNB(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠳࠱ࡴࡶࠪ᪯"))
		if NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ᪰") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()):
			RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[s0vAWcLSXEToH9Mik134q(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ᪱")]
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ᪲")+headers[JJu4MPClbTFpUwHiN(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᪳")]
			return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
		if JJrhP4C6osGDFEKVSRBvX.code!=g4UCaNkHvLwGhjmW(u"࠶࠵࠽Ύ"): break
	return QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖࠪ᪴"),[],[]
def JDzGrVCWUM2npvitFTylaRq9Akbg(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡍࡅࡕ᪵ࠩ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅ࠮࠳ࡶࡸ᪶ࠬ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠧࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪࡥࡰ࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࡷ࠳࠰࠿ࠪࠤ࠯࠲࠯ࡅࠬ࠯ࠬࡂ࠰࠭࠴ࠪࡀࠫ࠯᪷ࠫ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
		return QigevCplXxbPI1H,[oI6LvXMf4VEPe8jOdpKC0hUmS],[RMC6c2kL5hGOnFaIwAyb]
	return aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆ᪸ࠩ"),[],[]
def tIuoSjwAEZ(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,g4UCaNkHvLwGhjmW(u"ࠩࡊࡉ࡙᪹࠭"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠱࠮࠳ࡶࡸ᪺ࠬ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = hznK9suBQoEtTmwND4qXFg2(aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(Fg72JX6T5DkPy(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ᪻"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]]
	return v54ZuLY6dQ(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ᪼"),[],[]
def bh6GSD1NJp(url):
	if TCF8wLyDvgumfiXPSKRh(u"࠭࠯ࡥࡱࡺࡲ࠳ࡶࡨࡱ᪽ࠩ") in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,tOrSvd8QKNB(u"ࠧࡈࡇࡗࠫ᪾"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡇࡊࡄ࠱࠶ࡹࡴࠨᪿ"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(Xr2aHOK0huQ5DTS(u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡹࡵࡥࡵࡶࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤᫀࠪ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		url = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	return VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᫁"),[QigevCplXxbPI1H],[url]
def Jv9dkHFNmq(url):
	if s0vAWcLSXEToH9Mik134q(u"ࠫࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ᫂") in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡍࡅࡕ᫃ࠩ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,bDt7Ya1VEio3(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ᫄࠭"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᫅"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
		if y5yX4jh6kUEgWZQIc(u"ࠨࡪࡷࡸࡵ࠭᫆") in RMC6c2kL5hGOnFaIwAyb: return s0vAWcLSXEToH9Mik134q(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᫇"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
		return JJu4MPClbTFpUwHiN(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃ࠷࡙ࠬ᫈"),[],[]
	return Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᫉"),[QigevCplXxbPI1H],[url]
def p4H1dtwvk9(url):
	Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
	T24Te3uDwBS5vLgUEAhF1O = {Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ᫊"):pGncXOodjKhJzLSqVP1r(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ᫋"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᫌ"):Fg72JX6T5DkPy(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨᫍ")}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡓࡓࡘ࡚ࠧᫎ"),Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪ᫏"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(K7bLVaiRkx0lgU5SQM(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᫐"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not RMC6c2kL5hGOnFaIwAyb: return K7bLVaiRkx0lgU5SQM(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ᫑"),[],[]
	RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	return OTRKI6LbrQnZEm(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᫒"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def RflsiP2MmZ(url):
	headers = {pTwKPmzMSZhil5d2RWonre(u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ᫓"):JJu4MPClbTFpUwHiN(u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ᫔")}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,vZL6j4tSClIGxzNE5DX(u"ࠩࡊࡉ࡙࠭᫕"),url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡑࡒࡊࡕࡘࡏ࠮࠳ࡶࡸࠬ᫖"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(K7bLVaiRkx0lgU5SQM(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᫗"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
	if not RMC6c2kL5hGOnFaIwAyb: return JJu4MPClbTFpUwHiN(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡒࡓࡋࡖࡒࡐࠩ᫘"),[],[]
	RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	return tg9l25NH6WTacVSifLyAmY(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᫙"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def MMPgAmhWqX(url):
	Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
	T24Te3uDwBS5vLgUEAhF1O = {mpusoZBJ6V(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭᫚"):FF70emVxhWOngCty(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ᫛")}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡓࡓࡘ࡚ࠧ᫜"),Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,FF70emVxhWOngCty(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ᫝"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࠬ࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࡠࠨࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣࠩࡠࠫࠬ࠭᫞"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
	if not RMC6c2kL5hGOnFaIwAyb: return mpusoZBJ6V(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩ᫟"),[],[]
	RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	if O4ylJvVNwLztdiHqBWDU(u"࠭ࡨࡵࡶࡳࠫ᫠") not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡩࡶࡷࡴ࠿࠭᫡")+RMC6c2kL5hGOnFaIwAyb
	return v54ZuLY6dQ(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᫢"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def Pe1N9oEwBQ(url):
	Wdek0SptsHCKog19OBJDTRAX7m,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = url,[],[]
	if TCF8wLyDvgumfiXPSKRh(u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࠩ᫣") in url:
		Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
		T24Te3uDwBS5vLgUEAhF1O = {FF70emVxhWOngCty(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ᫤"):s0vAWcLSXEToH9Mik134q(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ᫥")}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,O4ylJvVNwLztdiHqBWDU(u"ࠬࡖࡏࡔࡖࠪ᫦"),Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡁࡃࡆࡒ࠱࠶ࡹࡴࠨ᫧"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		KWd8gTIVsbfk31S6C2zeQAaN = sBvufaD6c9YHdOqTjCQ3.findall(s0vAWcLSXEToH9Mik134q(u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫ᫨"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if KWd8gTIVsbfk31S6C2zeQAaN: Wdek0SptsHCKog19OBJDTRAX7m = KWd8gTIVsbfk31S6C2zeQAaN[h17Zb2ld4yLBrCP5tiw]
	return Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᫩"),[QigevCplXxbPI1H],[Wdek0SptsHCKog19OBJDTRAX7m]
def ggl2cikBed(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,TCF8wLyDvgumfiXPSKRh(u"ࠩࡊࡉ࡙࠭᫪"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡔࡗࡈࡘࡒ࠲࠷ࡳࡵࠩ᫫"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	pfqUwreoL6HFNx = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠦࡻࡧࡲࠡࡨࡶࡩࡷࡼࠠ࠾࠰࠭ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧ᫬"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
	if pfqUwreoL6HFNx:
		pfqUwreoL6HFNx = pfqUwreoL6HFNx[h17Zb2ld4yLBrCP5tiw][tg9l25NH6WTacVSifLyAmY(u"࠵Ῥ"):]
		pfqUwreoL6HFNx = akgfpLEN8Kn396XjFUut4QJVI.b64decode(pfqUwreoL6HFNx)
		if b7sJAmSxlBvaMdHFz: pfqUwreoL6HFNx = pfqUwreoL6HFNx.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(XWbHfI9B8swrOL(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᫭"),pfqUwreoL6HFNx,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: RMC6c2kL5hGOnFaIwAyb = QigevCplXxbPI1H
	if not RMC6c2kL5hGOnFaIwAyb: return OTRKI6LbrQnZEm(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧ᫮"),[],[]
	RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	if tg9l25NH6WTacVSifLyAmY(u"ࠧࡩࡶࡷࡴࠬ᫯") not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = O4ylJvVNwLztdiHqBWDU(u"ࠨࡪࡷࡸࡵࡀࠧ᫰")+RMC6c2kL5hGOnFaIwAyb
	return v54ZuLY6dQ(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᫱"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def e3b91aL8OyojAs(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,tOrSvd8QKNB(u"ࠪࡋࡊ࡚ࠧ᫲"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡈࡋ࡞࡜ࡉࡑ࠯࠴ࡷࡹ࠭᫳"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲࠷࠲ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᫴"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not RMC6c2kL5hGOnFaIwAyb: return JJu4MPClbTFpUwHiN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡉࡌ࡟ࡖࡊࡒࠪ᫵"),[],[]
	RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	return hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᫶"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def rYtXalHbju(url):
	id = url.split(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࠱ࠪ᫷"))[-y5yX4jh6kUEgWZQIc(u"࠵῭")]
	if DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩ࠲ࡩࡲࡨࡥࡥࠩ᫸") in url: url = url.replace(g4UCaNkHvLwGhjmW(u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ᫹"),QigevCplXxbPI1H)
	url = url.replace(Xr2aHOK0huQ5DTS(u"ࠫ࠳ࡩ࡯࡮࠱ࠪ᫺"),pTwKPmzMSZhil5d2RWonre(u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭᫻"))
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,K7bLVaiRkx0lgU5SQM(u"࠭ࡇࡆࡖࠪ᫼"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ᫽"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	gcXCwZe9xP = tg9l25NH6WTacVSifLyAmY(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ᫾")
	wjgVENDB1QoPCbpn = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠩࠥࡩࡷࡸ࡯ࡳࠤ࠱࠮ࡄࠨ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ᫿"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if wjgVENDB1QoPCbpn: gcXCwZe9xP = wjgVENDB1QoPCbpn[h17Zb2ld4yLBrCP5tiw]
	url = sBvufaD6c9YHdOqTjCQ3.findall(OTRKI6LbrQnZEm(u"ࠪࡼ࠲ࡳࡰࡦࡩࡘࡖࡑࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧᬀ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not url and gcXCwZe9xP:
		return gcXCwZe9xP,[],[]
	RMC6c2kL5hGOnFaIwAyb = url[h17Zb2ld4yLBrCP5tiw].replace(OOhnpQ8XvCVclGqdu(u"ࠫࡡࡢࠧᬁ"),QigevCplXxbPI1H)
	XxAz2nKNP6ORDfaLFo7MQT4rsEde,kQlGI4ouaPwteZq9XgKB02 = HHSM1J4ofulwIPqTjnQA(RMC6c2kL5hGOnFaIwAyb)
	ehgc4bBVGPZOS = sBvufaD6c9YHdOqTjCQ3.findall(mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࠨ࡯ࡸࡰࡨࡶࠧࡀࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡴࡥࡵࡩࡪࡴ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᬂ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if ehgc4bBVGPZOS: p2TOq8kFzAjotC0HYgIs6cnG4Pwb,JS9FNeq3Azjv6Kx8,QDI0foN8wakC = ehgc4bBVGPZOS[h17Zb2ld4yLBrCP5tiw]
	else: p2TOq8kFzAjotC0HYgIs6cnG4Pwb,JS9FNeq3Azjv6Kx8,QDI0foN8wakC = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	QDI0foN8wakC = QDI0foN8wakC.replace(s0vAWcLSXEToH9Mik134q(u"࠭࡜࠰ࠩᬃ"),pTwKPmzMSZhil5d2RWonre(u"ࠧ࠰ࠩᬄ"))
	JS9FNeq3Azjv6Kx8 = arFSQucmG9HxDody67JCI8pBMk4L(JS9FNeq3Azjv6Kx8)
	ttGBwQOv3K41hIkc6 = [iVCLpNIM8BQs9PdSgKZvlFeo3a5+O4ylJvVNwLztdiHqBWDU(u"ࠨࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪᬅ")+JS9FNeq3Azjv6Kx8+jhAlCQ47ZgG]+XxAz2nKNP6ORDfaLFo7MQT4rsEde
	ldFqnNIsftrY43JBM6LPjzU8m = [QDI0foN8wakC]+kQlGI4ouaPwteZq9XgKB02
	HHZ6579kAv8 = zYWJO03iISD(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪᬆ")+str(len(ldFqnNIsftrY43JBM6LPjzU8m)-s0vAWcLSXEToH9Mik134q(u"࠶΅"))+mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࠤ๊๊แࠪࠩᬇ"),ttGBwQOv3K41hIkc6)
	if HHZ6579kAv8==-Fg72JX6T5DkPy(u"࠷`"): return svULcgJ7jm(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᬈ"),[],[]
	elif HHZ6579kAv8==tOrSvd8QKNB(u"࠰῰"):
		ZxMLFtnDSoCH714 = KXhrv29CGR8QTDzJIWLY.argv[h17Zb2ld4yLBrCP5tiw]+svULcgJ7jm(u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠷࠴࠷ࠬࡵࡳ࡮ࡀࠫᬉ")+QDI0foN8wakC+TCF8wLyDvgumfiXPSKRh(u"࠭ࠦࡵࡧࡻࡸࡹࡃࠧᬊ")+JS9FNeq3Azjv6Kx8
		qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(vZL6j4tSClIGxzNE5DX(u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦᬋ")+ZxMLFtnDSoCH714+Fg72JX6T5DkPy(u"ࠣࠫࠥᬌ"))
		return OOhnpQ8XvCVclGqdu(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᬍ"),[],[]
	RMC6c2kL5hGOnFaIwAyb =  ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
	return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def gzhm8lLXR0(RMC6c2kL5hGOnFaIwAyb):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,OOhnpQ8XvCVclGqdu(u"ࠪࡋࡊ࡚ࠧᬎ"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃࡑࡎࡖࡆ࠳࠱ࡴࡶࠪᬏ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࠴ࡪࡴࡱࡱࠫᬐ") in RMC6c2kL5hGOnFaIwAyb: url = sBvufaD6c9YHdOqTjCQ3.findall(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࠢࡴࡴࡦࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᬑ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: url = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᬒ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not url: return aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆࡔࡑࡒࡂࠩᬓ"),[],[]
	url = url[h17Zb2ld4yLBrCP5tiw]
	if mpusoZBJ6V(u"ࠩ࡫ࡸࡹࡶࠧᬔ") not in url: url = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪ࡬ࡹࡺࡰ࠻ࠩᬕ")+url
	return QigevCplXxbPI1H,[QigevCplXxbPI1H],[url]
def c3p8udUeDGvSzn1PtlV(url):
	headers = { WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᬖ") : QigevCplXxbPI1H }
	if vZL6j4tSClIGxzNE5DX(u"ࠬࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠨᬗ") in url:
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,XWbHfI9B8swrOL(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠶ࡹࡴࠨᬘ"))
		items = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᬙ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if items: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[items[h17Zb2ld4yLBrCP5tiw]]
		else:
			nDRKguWex0iVN8 = sBvufaD6c9YHdOqTjCQ3.findall(y5yX4jh6kUEgWZQIc(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡵࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᬚ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if nDRKguWex0iVN8:
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊วึๆํࠫᬛ"),nDRKguWex0iVN8[h17Zb2ld4yLBrCP5tiw])
				return mpusoZBJ6V(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࠫᬜ")+nDRKguWex0iVN8[h17Zb2ld4yLBrCP5tiw],[],[]
	else:
		BazW8QlSDmdsZrhXNAjPEo0 = O4ylJvVNwLztdiHqBWDU(u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧᬝ")
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠶ࡳࡪࠧᬞ"))
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"࠭ࡆࡰࡴࡰࠤࡲ࡫ࡴࡩࡱࡧࡁࠧࡖࡏࡔࡖࠥࠤࡦࡩࡴࡪࡱࡱࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨᬟ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: return svULcgJ7jm(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫᬠ"),[],[]
		Wdek0SptsHCKog19OBJDTRAX7m = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw]
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk]
		if hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨ࠰ࡵࡥࡷ࠭ᬡ") in LKzFWsmvjUVGMDBapflx6H4NY or bDt7Ya1VEio3(u"ࠩ࠱ࡾ࡮ࡶࠧᬢ") in LKzFWsmvjUVGMDBapflx6H4NY: return mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡑࡔ࡙ࡈࡂࡊࡇࡅࠥࡔ࡯ࡵࠢࡤࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠨᬣ"),[],[]
		items = sBvufaD6c9YHdOqTjCQ3.findall(tg9l25NH6WTacVSifLyAmY(u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᬤ"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		A1AqSc2LNwW0ETgyaRl9 = {}
		for zsj5qOxnfaXmdEco3DK29HgYybUCM6,nFdGHjceZzW in items:
			A1AqSc2LNwW0ETgyaRl9[zsj5qOxnfaXmdEco3DK29HgYybUCM6] = nFdGHjceZzW
		data = q8KvkirVNMoRIB5eJ(A1AqSc2LNwW0ETgyaRl9)
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,Wdek0SptsHCKog19OBJDTRAX7m,data,headers,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠷ࡷࡪࠧᬥ"))
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(O4ylJvVNwLztdiHqBWDU(u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࠡࡘ࡬ࡨࡪࡵ࠮ࠫࡁࡪࡩࡹࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࠯ࠬࡂ࠭࡮ࡳࡡࡨࡧ࠽ࠫᬦ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: return NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡓࡘࡎࡁࡉࡆࡄࠫᬧ"),[],[]
		download = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw]
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk]
		items = sBvufaD6c9YHdOqTjCQ3.findall(svULcgJ7jm(u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣ࠰࠭ࡃࠧࢂࠩࠨᬨ"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		BkKyq6tfJldMGcTZr8WIDwouCP,ttGBwQOv3K41hIkc6,NTpQsJIxWYotw5jnUkqC6Ez,ldFqnNIsftrY43JBM6LPjzU8m,UUnhPwzDrfJaE6ogQ3vmCKcs1 = [],[],[],[],[]
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if vZL6j4tSClIGxzNE5DX(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᬩ") in RMC6c2kL5hGOnFaIwAyb:
				BkKyq6tfJldMGcTZr8WIDwouCP,NTpQsJIxWYotw5jnUkqC6Ez = HHSM1J4ofulwIPqTjnQA(RMC6c2kL5hGOnFaIwAyb)
				ldFqnNIsftrY43JBM6LPjzU8m = ldFqnNIsftrY43JBM6LPjzU8m + NTpQsJIxWYotw5jnUkqC6Ez
				if BkKyq6tfJldMGcTZr8WIDwouCP[h17Zb2ld4yLBrCP5tiw]==TCF8wLyDvgumfiXPSKRh(u"ࠪ࠱࠶࠭ᬪ"): ttGBwQOv3K41hIkc6.append(bDt7Ya1VEio3(u"ู๊ࠫࠥาใิࠤำอีࠡࠩᬫ")+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡳ࠳ࡶ࠺ࠣࠫᬬ")+BazW8QlSDmdsZrhXNAjPEo0)
				else:
					for title in BkKyq6tfJldMGcTZr8WIDwouCP:
						ttGBwQOv3K41hIkc6.append(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠิ์ิๅึࠦฮศืࠣࠫᬭ")+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧ࡮࠵ࡸ࠼ࠥ࠭ᬮ")+BazW8QlSDmdsZrhXNAjPEo0+hT7zFDpEyUqf8sXuN+title)
			else:
				title = title.replace(vZL6j4tSClIGxzNE5DX(u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪᬯ"),QigevCplXxbPI1H)
				title = title.strip(XWbHfI9B8swrOL(u"ࠩࠥࠫᬰ"))
				title = mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩᬱ")+FF70emVxhWOngCty(u"ࠫࠥࡳࡰ࠵ࠢࠪᬲ")+BazW8QlSDmdsZrhXNAjPEo0+hT7zFDpEyUqf8sXuN+title
				ttGBwQOv3K41hIkc6.append(title)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		RMC6c2kL5hGOnFaIwAyb = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧᬳ") + download
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓࡘࡎࡁࡉࡆࡄ࠱࠺ࡺࡨࠨ᬴"))
		items = sBvufaD6c9YHdOqTjCQ3.findall(mmKqLr9RX0ACN384JMcsFHzd(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯ࠦᬵ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for id,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hash,BWNcTU4ukQLAm25Xn3lbqrOzSJ in items:
			title = pGncXOodjKhJzLSqVP1r(u"ࠨࠢึ๎ึ็ัࠡฬะ้๏๊ࠠฯษุࠤࠬᬶ")+Fg72JX6T5DkPy(u"ࠩࠣࡱࡵ࠺ࠠࠨᬷ")+BazW8QlSDmdsZrhXNAjPEo0+hT7zFDpEyUqf8sXuN+BWNcTU4ukQLAm25Xn3lbqrOzSJ.split(tOrSvd8QKNB(u"ࠪࡼࠬᬸ"))[nfC2im3NzUQk]
			RMC6c2kL5hGOnFaIwAyb = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡤ࡭ࡁࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠫ࡯ࡤ࠾ࠩᬹ")+id+svULcgJ7jm(u"ࠬࠬ࡭ࡰࡦࡨࡁࠬᬺ")+TsckNQJ6yLiaEeCRml98WwKfVP0dYv+bDt7Ya1VEio3(u"࠭ࠦࡩࡣࡶ࡬ࡂ࠭ᬻ")+hash
			UUnhPwzDrfJaE6ogQ3vmCKcs1.append(BWNcTU4ukQLAm25Xn3lbqrOzSJ)
			ttGBwQOv3K41hIkc6.append(title)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		UUnhPwzDrfJaE6ogQ3vmCKcs1 = set(UUnhPwzDrfJaE6ogQ3vmCKcs1)
		rAZOUKSfP4,BkNarI8sCLORfpeK1VHEUGMZ7vxDwX = [],[]
		for title in ttGBwQOv3K41hIkc6:
			IeBWJ9sMvo0Aq = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢᬼ"),title+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࠨࠩࠫᬽ"),sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for BWNcTU4ukQLAm25Xn3lbqrOzSJ in UUnhPwzDrfJaE6ogQ3vmCKcs1:
				if IeBWJ9sMvo0Aq[h17Zb2ld4yLBrCP5tiw] in BWNcTU4ukQLAm25Xn3lbqrOzSJ:
					title = title.replace(IeBWJ9sMvo0Aq[h17Zb2ld4yLBrCP5tiw],BWNcTU4ukQLAm25Xn3lbqrOzSJ.split(JJu4MPClbTFpUwHiN(u"ࠩࡻࠫᬾ"))[nfC2im3NzUQk])
			rAZOUKSfP4.append(title)
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(ldFqnNIsftrY43JBM6LPjzU8m)):
			items = sBvufaD6c9YHdOqTjCQ3.findall(OTRKI6LbrQnZEm(u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦᬿ"),mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࠫࠬࠧᭀ")+rAZOUKSfP4[A5SjhJUg37pNiMC4Eot6lOF]+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࠬࠦࠨᭁ"),sBvufaD6c9YHdOqTjCQ3.DOTALL)
			BkNarI8sCLORfpeK1VHEUGMZ7vxDwX.append( [rAZOUKSfP4[A5SjhJUg37pNiMC4Eot6lOF],ldFqnNIsftrY43JBM6LPjzU8m[A5SjhJUg37pNiMC4Eot6lOF],items[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw],items[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk]] )
		BkNarI8sCLORfpeK1VHEUGMZ7vxDwX = sorted(BkNarI8sCLORfpeK1VHEUGMZ7vxDwX, key=lambda X0XNcZhM4KyO3uUxozmjFtIAPa: X0XNcZhM4KyO3uUxozmjFtIAPa[mVjHAyIwzSNKLFcd], reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		BkNarI8sCLORfpeK1VHEUGMZ7vxDwX = sorted(BkNarI8sCLORfpeK1VHEUGMZ7vxDwX, key=lambda X0XNcZhM4KyO3uUxozmjFtIAPa: X0XNcZhM4KyO3uUxozmjFtIAPa[JxuTQLOD357o41evylqPmRdf], reverse=YoAMfqm37GyFxbuKTt6e8CESHrhB)
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(BkNarI8sCLORfpeK1VHEUGMZ7vxDwX)):
			ttGBwQOv3K41hIkc6.append(BkNarI8sCLORfpeK1VHEUGMZ7vxDwX[A5SjhJUg37pNiMC4Eot6lOF][h17Zb2ld4yLBrCP5tiw])
			ldFqnNIsftrY43JBM6LPjzU8m.append(BkNarI8sCLORfpeK1VHEUGMZ7vxDwX[A5SjhJUg37pNiMC4Eot6lOF][nfC2im3NzUQk])
	if len(ldFqnNIsftrY43JBM6LPjzU8m)==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠱῱"): return WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪᭂ"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def J2Y7yqHDguKbse6iOQ5lo0CLx(url):
	WShVouXDRCGjeIFMYTHyimk5dlz = url.split(OTRKI6LbrQnZEm(u"ࠧࡀࠩᭃ"))
	Kj0TOU6BmSMlJHZYLd = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
	headers = { DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸ᭄ࠬ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋ࠵ࡕࡕࡄࡖ࠲࠷ࡳࡵࠩᭅ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠪࡔࡱ࡫ࡡࡴࡧࠣࡻࡦ࡯ࡴ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫᭆ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	url = items[h17Zb2ld4yLBrCP5tiw]
	return y5yX4jh6kUEgWZQIc(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᭇ"),[QigevCplXxbPI1H],[url]
def BpljQVWu7AHdUreY0tPaTS(url):
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
	headers = { DD7NjwespWyQJ4E6mXk0ZAufPg(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᭈ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬᭉ"))
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(y5yX4jh6kUEgWZQIc(u"ࠧࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡࡸࡶࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᭊ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Kj0TOU6BmSMlJHZYLd: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]]
	else: return FF70emVxhWOngCty(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡆ࡚ࡠ࡚ࡗࡔࡏࠫᭋ"),[],[]
def fntbcviROlkdGWHSsKeFLVgjoBJ(url):
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
	headers = { Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᭌ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗ࠲࠷ࡳࡵࠩ᭍"))
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(K7bLVaiRkx0lgU5SQM(u"ࠫ࡭ࡸࡥࡧࠤ࠯ࠦ࠭࡮ࡴࡵ࠰࠭ࡃ࠮ࠨࠧ᭎"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Kj0TOU6BmSMlJHZYLd: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]]
	else: return pGncXOodjKhJzLSqVP1r(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠭᭏"),[],[]
def zVn5N1ujF0(url):
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,errno = [],[],QigevCplXxbPI1H
	if vZL6j4tSClIGxzNE5DX(u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࠪ᭐") in url:
		Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
		T24Te3uDwBS5vLgUEAhF1O = {s0vAWcLSXEToH9Mik134q(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭᭑"):g4UCaNkHvLwGhjmW(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ᭒")}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,mpusoZBJ6V(u"ࠩࡓࡓࡘ࡚ࠧ᭓"),Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠵ࡲࡩ࠭᭔"))
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		if BhxM1UVjtbEoSp640kIcag.startswith(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫ࡭ࡺࡴࡱࠩ᭕")): Kj0TOU6BmSMlJHZYLd = BhxM1UVjtbEoSp640kIcag
		else:
			NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = sBvufaD6c9YHdOqTjCQ3.findall(FF70emVxhWOngCty(u"ࠬ࠭ࠧࡴࡴࡦࡁࡠ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛ࠨࠤࡠࠫࠬ࠭᭖"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if NW6gmPcC1B4ILwdHTz0GlDsi5Fkx:
				Kj0TOU6BmSMlJHZYLd = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx[h17Zb2ld4yLBrCP5tiw]
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = sBvufaD6c9YHdOqTjCQ3.findall(tOrSvd8QKNB(u"࠭ࡳࡰࡷࡵࡧࡪࡃࠨ࠯ࠬࡂ࠭ࡠࠬࠤ࡞ࠩ᭗"),Kj0TOU6BmSMlJHZYLd,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if NW6gmPcC1B4ILwdHTz0GlDsi5Fkx:
					Kj0TOU6BmSMlJHZYLd = MVkP7zfWlxUXj(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx[h17Zb2ld4yLBrCP5tiw])
					return QigevCplXxbPI1H,[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	elif fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧ࠰࡮࡬ࡲࡰࡹ࠯ࠨ᭘") in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,JJu4MPClbTFpUwHiN(u"ࠨࡉࡈࡘࠬ᭙"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠳ࡶࡸࠬ᭚"))
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		if WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ᭛") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()): Kj0TOU6BmSMlJHZYLd = JJrhP4C6osGDFEKVSRBvX.headers[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭᭜")]
		else: Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(s0vAWcLSXEToH9Mik134q(u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᭝"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)[h17Zb2ld4yLBrCP5tiw]
	if JJu4MPClbTFpUwHiN(u"࠭࠯ࡷ࠱ࠪ᭞") in Kj0TOU6BmSMlJHZYLd or v54ZuLY6dQ(u"ࠧ࠰ࡨ࠲ࠫ᭟") in Kj0TOU6BmSMlJHZYLd:
		Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace(s0vAWcLSXEToH9Mik134q(u"ࠨ࠱ࡩ࠳ࠬ᭠"),tg9l25NH6WTacVSifLyAmY(u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ᭡"))
		Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace(s0vAWcLSXEToH9Mik134q(u"ࠪ࠳ࡻ࠵ࠧ᭢"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ᭣"))
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡖࡏࡔࡖࠪ᭤"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡏࡋࡒࡔࡊࡒ࡛࠲࠹ࡲࡥࠩ᭥"))
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		items = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤ࡯ࡥࡧ࡫࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ᭦"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if items:
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(FF70emVxhWOngCty(u"ࠨ࡞࡟ࠫ᭧"),QigevCplXxbPI1H)
				ttGBwQOv3K41hIkc6.append(title)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		else:
			items = sBvufaD6c9YHdOqTjCQ3.findall(v54ZuLY6dQ(u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ᭨"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if items:
				RMC6c2kL5hGOnFaIwAyb = items[h17Zb2ld4yLBrCP5tiw]
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡠࡡ࠭᭩"),QigevCplXxbPI1H)
				ttGBwQOv3K41hIkc6.append(QigevCplXxbPI1H)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	else: return v54ZuLY6dQ(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᭪"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	if len(ldFqnNIsftrY43JBM6LPjzU8m)==svULcgJ7jm(u"࠲ῲ"): return FF70emVxhWOngCty(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ᭫"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def LMRkxQV5j6(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,v54ZuLY6dQ(u"࠭ࡇࡆࡖ᭬ࠪ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,OOhnpQ8XvCVclGqdu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠵ࡸࡺࠧ᭭"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,errno = [],[],QigevCplXxbPI1H
	if XWbHfI9B8swrOL(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ᭮") in url or JJu4MPClbTFpUwHiN(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ᭯") in url:
		if Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭᭰") in url:
			Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᭱"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]
		else: Kj0TOU6BmSMlJHZYLd = url
		if pGncXOodjKhJzLSqVP1r(u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ᭲") not in Kj0TOU6BmSMlJHZYLd: return mpusoZBJ6V(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᭳"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,FF70emVxhWOngCty(u"ࠧࡈࡇࡗࠫ᭴"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,OOhnpQ8XvCVclGqdu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠷ࡴࡤࠨ᭵"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(O4ylJvVNwLztdiHqBWDU(u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࡭ࡷࠬ᭶"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw]
		items = sBvufaD6c9YHdOqTjCQ3.findall(s0vAWcLSXEToH9Mik134q(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᭷"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if items:
			for RMC6c2kL5hGOnFaIwAyb,J4kSW2aUHYg6 in items:
				ttGBwQOv3K41hIkc6.append(J4kSW2aUHYg6)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	elif FF70emVxhWOngCty(u"ࠫࡲࡧࡩ࡯ࡡࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵ࠭᭸") in url:
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠬࡻࡲ࡭࠿ࠫ࠲࠯ࡅࠩࠣࠩ᭹"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡇࡆࡖࠪ᭺"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠷ࡷࡪࠧ᭻"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = sBvufaD6c9YHdOqTjCQ3.findall(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ᭼"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx[h17Zb2ld4yLBrCP5tiw]
		ttGBwQOv3K41hIkc6.append(QigevCplXxbPI1H)
		ldFqnNIsftrY43JBM6LPjzU8m.append(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
	elif OOhnpQ8XvCVclGqdu(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡱ࡯࡮࡬ࠩ᭽") in url:
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"ࠪࡀࡨ࡫࡮ࡵࡧࡵࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᭾"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if Kj0TOU6BmSMlJHZYLd:
			Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]
			return TCF8wLyDvgumfiXPSKRh(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᭿"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	if len(ldFqnNIsftrY43JBM6LPjzU8m)==Fg72JX6T5DkPy(u"࠳ῳ"): return K7bLVaiRkx0lgU5SQM(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑ࡙ࡗ࠹࡛ࠧᮀ"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def xKNzwc5Jhp(url):
	if v54ZuLY6dQ(u"࠭࠿ࡨࡧࡷࡁࠬᮁ") in url:
		RMC6c2kL5hGOnFaIwAyb = url.split(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡀࡩࡨࡸࡂ࠭ᮂ"),OOhnpQ8XvCVclGqdu(u"࠵ῴ"))[nfC2im3NzUQk]
		RMC6c2kL5hGOnFaIwAyb = akgfpLEN8Kn396XjFUut4QJVI.b64decode(RMC6c2kL5hGOnFaIwAyb)
		if b7sJAmSxlBvaMdHFz: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,s0vAWcLSXEToH9Mik134q(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨᮃ"))
		return TCF8wLyDvgumfiXPSKRh(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᮄ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	website = OQv0iWIw5bFRATU2mxJjZK[pGncXOodjKhJzLSqVP1r(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬᮅ")][h17Zb2ld4yLBrCP5tiw]
	headers = {JJu4MPClbTFpUwHiN(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬᮆ"):website}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡍࡅࡕࠩᮇ"),url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡅ࠱࠷ࡴࡤࠨᮈ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,bDt7Ya1VEio3(u"ࠧࡶࡴ࡯ࠫᮉ"))
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(vZL6j4tSClIGxzNE5DX(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᮊ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠤࡶࡳࡺࡸࡣࡦࡵ࠽ࠤࡡࡡࠧࠩ࠰࠭ࡃ࠮࠭ࠢᮋ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(tOrSvd8QKNB(u"ࠥࡪ࡮ࡲࡥ࠻ࠩࠫ࠲࠯ࡅࠩࠨࠤᮌ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]+OOhnpQ8XvCVclGqdu(u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧᮍ")+website
		return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	if Xr2aHOK0huQ5DTS(u"ࠬࡴࡡ࡮ࡧࡀࠦ࡝ࡺ࡯࡬ࡧࡱࠦࠬᮎ") in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		P2SbOUD5YqrT0Mw = sBvufaD6c9YHdOqTjCQ3.findall(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࡮ࡢ࡯ࡨࡁࠧ࡞ࡴࡰ࡭ࡨࡲࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᮏ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if P2SbOUD5YqrT0Mw:
			RMC6c2kL5hGOnFaIwAyb = P2SbOUD5YqrT0Mw[h17Zb2ld4yLBrCP5tiw]
			RMC6c2kL5hGOnFaIwAyb = akgfpLEN8Kn396XjFUut4QJVI.b64decode(RMC6c2kL5hGOnFaIwAyb)
			if b7sJAmSxlBvaMdHFz: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,TCF8wLyDvgumfiXPSKRh(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᮐ"))
			RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(tg9l25NH6WTacVSifLyAmY(u"ࠨࡪࡷࡸࡵ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬ࠰ࠬᮑ"),RMC6c2kL5hGOnFaIwAyb,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if RMC6c2kL5hGOnFaIwAyb:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]+OOhnpQ8XvCVclGqdu(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬᮒ")+website
				return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	return TCF8wLyDvgumfiXPSKRh(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᮓ"),[QigevCplXxbPI1H],[url]
def yyrKVk7Tl8(url,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6):
	xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = [],[]
	if svULcgJ7jm(u"ࠫ࠴࠷࠯ࠨᮔ") in url:
		RMC6c2kL5hGOnFaIwAyb = url.replace(JJu4MPClbTFpUwHiN(u"ࠬ࠵࠱࠰ࠩᮕ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭࠯࠵࠱ࠪᮖ"))
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,tg9l25NH6WTacVSifLyAmY(u"ࠧࡈࡇࡗࠫᮗ"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠱ࡴࡶࠪᮘ"))
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩ࠿ࡺ࡮ࡪࡥࡰࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡨࡪࡵ࠾ࠨᮙ"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw]
			items = sBvufaD6c9YHdOqTjCQ3.findall(Xr2aHOK0huQ5DTS(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᮚ"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS in items:
				if RMC6c2kL5hGOnFaIwAyb not in vdLczqkV5b48ZKyGxTE3jJi17aWS6:
					vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
					bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡳࡧ࡭ࡦࠩᮛ"))
					xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(bSrdN78jxURTvh9+eZXCHufT9YW4bRErSBOLmI+oI6LvXMf4VEPe8jOdpKC0hUmS)
			return QigevCplXxbPI1H,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6
	elif y5yX4jh6kUEgWZQIc(u"ࠬ࠵ࡤ࠰ࠩᮜ") in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,v54ZuLY6dQ(u"࠭ࡇࡆࡖࠪᮝ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠸࡮ࡥࠩᮞ"))
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(Fg72JX6T5DkPy(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᮟ"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RMC6c2kL5hGOnFaIwAyb:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw].replace(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩ࠲࠵࠴࠭ᮠ"),K7bLVaiRkx0lgU5SQM(u"ࠪ࠳࠹࠵ࠧᮡ"))
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡌࡋࡔࠨᮢ"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠷ࡷࡪࠧᮣ"))
			BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
			RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(tg9l25NH6WTacVSifLyAmY(u"࠭ࡣ࡭ࡣࡶࡷ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᮤ"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if RMC6c2kL5hGOnFaIwAyb: return hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᮥ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]]
	elif XWbHfI9B8swrOL(u"ࠨ࠱ࡵࡳࡱ࡫࠯ࠨᮦ") in url:
		headers = {JJu4MPClbTFpUwHiN(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᮧ"):TTrmYne2lRXM0jLyHAF8CzQ7vpKi6}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡋࡊ࡚ࠧᮨ"),url,QigevCplXxbPI1H,headers,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,FF70emVxhWOngCty(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠷ࡸ࡭࠭ᮩ"))
		RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[bDt7Ya1VEio3(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴ᮪ࠧ")]
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡇࡆࡖ᮫ࠪ"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠻ࡴࡩࠩᮬ"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = nSTd2ALhNuXoys5eaKZ1JG4miRcf7D(RMC6c2kL5hGOnFaIwAyb,aY63L2NhgvwJIxPAoDG4MKECmZXF1)
		return gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6
	elif pTwKPmzMSZhil5d2RWonre(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬᮭ") in url:
		Kj0TOU6BmSMlJHZYLd = url.replace(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ᮮ"),tOrSvd8QKNB(u"ࠪ࠳ࡸࡩࡲࡪࡲࡷ࠳ࠬᮯ"))
		T24Te3uDwBS5vLgUEAhF1O = {s0vAWcLSXEToH9Mik134q(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ᮰"):TTrmYne2lRXM0jLyHAF8CzQ7vpKi6}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,tg9l25NH6WTacVSifLyAmY(u"ࠬࡍࡅࡕࠩ᮱"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,svULcgJ7jm(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠻ࡺࡨࠨ᮲"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(v54ZuLY6dQ(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᮳"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RMC6c2kL5hGOnFaIwAyb:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡉࡈࡘࠬ᮴"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠸ࡶ࡫ࠫ᮵"))
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
			if TCF8wLyDvgumfiXPSKRh(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ᮶") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()):
				RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[TCF8wLyDvgumfiXPSKRh(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭᮷")]
				JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࡍࡅࡕࠩ᮸"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,tOrSvd8QKNB(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠽ࡺࡨࠨ᮹"))
				aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
				gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = nSTd2ALhNuXoys5eaKZ1JG4miRcf7D(RMC6c2kL5hGOnFaIwAyb,aY63L2NhgvwJIxPAoDG4MKECmZXF1)
				if vdLczqkV5b48ZKyGxTE3jJi17aWS6: return gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6
			elif hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨᮺ") in RMC6c2kL5hGOnFaIwAyb:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(TCF8wLyDvgumfiXPSKRh(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩᮻ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩ࠲࡮ࡼࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ᮼ"))
				return NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᮽ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	else: return O4ylJvVNwLztdiHqBWDU(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᮾ"),[QigevCplXxbPI1H],[url]
	return VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩᮿ"),[],[]
def ymHvX9woJW(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,vZL6j4tSClIGxzNE5DX(u"࠭ࡇࡆࡖࠪᯀ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,vZL6j4tSClIGxzNE5DX(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠷ࡳࡵࠩᯁ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	data = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠨࠤࡤࡧࡹ࡯࡯࡯ࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᯂ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if data:
		FG1azhXQ673rdcJgO,id,aVuG9B1RQ0AfLvcwnXpo7rOxEyP = data[h17Zb2ld4yLBrCP5tiw]
		data = Xr2aHOK0huQ5DTS(u"ࠩࡲࡴࡂ࠭ᯃ")+FG1azhXQ673rdcJgO+XWbHfI9B8swrOL(u"ࠪࠪ࡮ࡪ࠽ࠨᯄ")+id+mpusoZBJ6V(u"ࠫࠫ࡬࡮ࡢ࡯ࡨࡁࠬᯅ")+aVuG9B1RQ0AfLvcwnXpo7rOxEyP
		headers = {mpusoZBJ6V(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᯆ"):tg9l25NH6WTacVSifLyAmY(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᯇ")}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,K7bLVaiRkx0lgU5SQM(u"ࠧࡑࡑࡖࡘࠬᯈ"),url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠸࠳࠲࡯ࡦࠪᯉ"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠩࠥࡶࡪ࡬ࡥࡳࡧࡵࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᯊ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RMC6c2kL5hGOnFaIwAyb: return O4ylJvVNwLztdiHqBWDU(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᯋ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]]
	return Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨᯌ"),[],[]
def B6keJXpbSa(url):
	headers = {NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨᯍ"):TCF8wLyDvgumfiXPSKRh(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧᯎ")}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,pGncXOodjKhJzLSqVP1r(u"ࠧࡈࡇࡗࠫᯏ"),url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠹࠳࠱ࡴࡶࠪᯐ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᯑ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
		return K7bLVaiRkx0lgU5SQM(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᯒ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	return VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨᯓ"),[],[]
def UOvqsPuVWh(url):
	Kj0TOU6BmSMlJHZYLd = url.split(O4ylJvVNwLztdiHqBWDU(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᯔ"),XWbHfI9B8swrOL(u"࠶῵"))[h17Zb2ld4yLBrCP5tiw].strip(tOrSvd8QKNB(u"࠭࠿ࠨᯕ")).strip(JJu4MPClbTFpUwHiN(u"ࠧ࠰ࠩᯖ")).strip(svULcgJ7jm(u"ࠨࠨࠪᯗ"))
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,items,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = [],[],[],QigevCplXxbPI1H
	headers = { Fg72JX6T5DkPy(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᯘ"):s0vAWcLSXEToH9Mik134q(u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠪᯙ") }
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࡌࡋࡔࠨᯚ"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠴ࡷࡹ࠭ᯛ"))
	if Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᯜ") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()): NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = JJrhP4C6osGDFEKVSRBvX.headers[y5yX4jh6kUEgWZQIc(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᯝ")]
	if fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡪࡷࡸࡵ࠭ᯞ") in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx:
		if pTwKPmzMSZhil5d2RWonre(u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᯟ") in url: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx.replace(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪ࠳࡫࠵ࠧᯠ"),pTwKPmzMSZhil5d2RWonre(u"ࠫ࠴ࡼ࠯ࠨᯡ"))
		mvf8nNiTM5cpbojQVqdJxGH2z = Kj0TOU6BmSMlJHZYLd.split(Fg72JX6T5DkPy(u"ࠬࡅࡐࡉࡒࡖࡍࡉࡃࠧᯢ"))[nfC2im3NzUQk]
		headers = { mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᯣ"):headers[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᯤ")] , O4ylJvVNwLztdiHqBWDU(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨᯥ"):y5yX4jh6kUEgWZQIc(u"ࠩࡓࡌࡕ࡙ࡉࡅ࠿᯦ࠪ")+mvf8nNiTM5cpbojQVqdJxGH2z }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡋࡊ࡚ࠧᯧ"),NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,QigevCplXxbPI1H,headers,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧᯨ"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		if WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬ࠵ࡦ࠰ࠩᯩ") in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx: items = sBvufaD6c9YHdOqTjCQ3.findall(v54ZuLY6dQ(u"࠭࠼ࡩ࠴ࡁ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᯪ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		elif y5yX4jh6kUEgWZQIc(u"ࠧ࠰ࡸ࠲ࠫᯫ") in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx: items = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᯬ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if items: return [],[QigevCplXxbPI1H],[ items[h17Zb2ld4yLBrCP5tiw] ]
		elif OTRKI6LbrQnZEm(u"ࠩ࠿࡬࠶ࡄ࠴࠱࠶࠿࠳࡭࠷࠾ࠨᯭ") in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			return mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣื๏ืแาࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎ࠥ๎ๅึัิ๋๋ࠥๆࠡษ็ษ๋ะั็ฬࠣห้ิวึหࠣฬ่࠭ᯮ"),[],[]
	else: return FF70emVxhWOngCty(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚ࠧᯯ"),[],[]
def v8ShNal6bj(RMC6c2kL5hGOnFaIwAyb):
	WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧᯰ"),RMC6c2kL5hGOnFaIwAyb+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࠦࠧࠩᯱ"),sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
	d8o4GfOLXIhV7b,rYsGTvB7OdokCyS10MHXEPzhe = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
	url = tg9l25NH6WTacVSifLyAmY(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮࠮࡯ࡧࡷ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ᯲")+d8o4GfOLXIhV7b+tOrSvd8QKNB(u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ᯳ࠬ")+rYsGTvB7OdokCyS10MHXEPzhe
	headers = { Xr2aHOK0huQ5DTS(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᯴"):QigevCplXxbPI1H , TCF8wLyDvgumfiXPSKRh(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭᯵"):Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ᯶") }
	Kj0TOU6BmSMlJHZYLd = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭࠲ࡵࡷࠫ᯷"))
	return pGncXOodjKhJzLSqVP1r(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᯸"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
def YgfswWlCO1(url):
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,K7bLVaiRkx0lgU5SQM(u"ࠧࡶࡴ࡯ࠫ᯹"))
	T24Te3uDwBS5vLgUEAhF1O = {vZL6j4tSClIGxzNE5DX(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ᯺"):bSrdN78jxURTvh9,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ᯻"):Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ᯼")}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vMlT137PE8q4wiKpWIojraR29B,mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡌࡋࡔࠨ᯽"),url,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ᯾"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡱࡶࡣ࡯࡭ࡹࡿࡳࡦ࡮ࡨࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮࡬࡯ࡳ࡯ࡤࡸࡸࡀࠧ᯿"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Kj0TOU6BmSMlJHZYLd = QigevCplXxbPI1H
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw]
		items = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡧࡱࡵࡱࡦࡺ࠺ࠡ࡞ࠪࠬࡡࡪ࠮ࠫࡁࠬࡠࠬ࠲ࠠࡴࡴࡦ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᰀ"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
		for title,RMC6c2kL5hGOnFaIwAyb in items:
			ttGBwQOv3K41hIkc6.append(title)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		if len(ldFqnNIsftrY43JBM6LPjzU8m)==O4ylJvVNwLztdiHqBWDU(u"࠷ῶ"): Kj0TOU6BmSMlJHZYLd = ldFqnNIsftrY43JBM6LPjzU8m[h17Zb2ld4yLBrCP5tiw]
		elif len(ldFqnNIsftrY43JBM6LPjzU8m)>OTRKI6LbrQnZEm(u"࠱ῷ"):
			HHZ6579kAv8 = zYWJO03iISD(XWbHfI9B8swrOL(u"ࠨลัฮึࠦวๅ็็ๅࠥอไๆ่สือ࠭ᰁ"), ttGBwQOv3K41hIkc6)
			if HHZ6579kAv8==-FF70emVxhWOngCty(u"࠲Ὸ"): return QigevCplXxbPI1H,[],[]
			Kj0TOU6BmSMlJHZYLd = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(XWbHfI9B8swrOL(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᰂ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: Kj0TOU6BmSMlJHZYLd = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw]
	if not Kj0TOU6BmSMlJHZYLd: return tOrSvd8QKNB(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡄࡋࡐࡅࠬᰃ"),[],[]
	return QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᰄ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
def FCjhbSetXr(url):
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡻࡲ࡭ࠩᰅ"))
	T24Te3uDwBS5vLgUEAhF1O = {Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᰆ"):bSrdN78jxURTvh9,JJu4MPClbTFpUwHiN(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩᰇ"):Xr2aHOK0huQ5DTS(u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨᰈ")}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vMlT137PE8q4wiKpWIojraR29B,O4ylJvVNwLztdiHqBWDU(u"ࠩࡊࡉ࡙࠭ᰉ"),url,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,OOhnpQ8XvCVclGqdu(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠳࠱ࡴࡶࠪᰊ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬᰋ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Kj0TOU6BmSMlJHZYLd = QigevCplXxbPI1H
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw]
		items = sBvufaD6c9YHdOqTjCQ3.findall(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᰌ"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
		for title,RMC6c2kL5hGOnFaIwAyb in items:
			ttGBwQOv3K41hIkc6.append(title)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
		if len(ldFqnNIsftrY43JBM6LPjzU8m)==pGncXOodjKhJzLSqVP1r(u"࠳Ό"): Kj0TOU6BmSMlJHZYLd = ldFqnNIsftrY43JBM6LPjzU8m[h17Zb2ld4yLBrCP5tiw]
		elif len(ldFqnNIsftrY43JBM6LPjzU8m)>K7bLVaiRkx0lgU5SQM(u"࠴Ὼ"):
			HHZ6579kAv8 = zYWJO03iISD(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᰍ"), ttGBwQOv3K41hIkc6)
			if HHZ6579kAv8==-s0vAWcLSXEToH9Mik134q(u"࠵Ώ"): return QigevCplXxbPI1H,[],[]
			Kj0TOU6BmSMlJHZYLd = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
	if not Kj0TOU6BmSMlJHZYLd:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall(tOrSvd8QKNB(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᰎ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: Kj0TOU6BmSMlJHZYLd = fwSu6JsQZpEiv[h17Zb2ld4yLBrCP5tiw]
	if not Kj0TOU6BmSMlJHZYLd: return tg9l25NH6WTacVSifLyAmY(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪᰏ"),[],[]
	return DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᰐ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
def on6lS1PVQD(RMC6c2kL5hGOnFaIwAyb):
	WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩᰑ"),RMC6c2kL5hGOnFaIwAyb+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࠫࠬࠧᰒ"),sBvufaD6c9YHdOqTjCQ3.DOTALL)
	url,d8o4GfOLXIhV7b,rYsGTvB7OdokCyS10MHXEPzhe = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
	data = {DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭ᰓ"):d8o4GfOLXIhV7b,JJu4MPClbTFpUwHiN(u"࠭ࡳࡦࡴࡹࡩࡷ࠭ᰔ"):rYsGTvB7OdokCyS10MHXEPzhe}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,OTRKI6LbrQnZEm(u"ࠧࡑࡑࡖࡘࠬᰕ"),url,data,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪᰖ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᰗ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[h17Zb2ld4yLBrCP5tiw]
	return DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᰘ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
def MGUDSETYwn(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡌࡋࡔࠨᰙ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱࠶ࡹࡴࠨᰚ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᰛ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
		if RMC6c2kL5hGOnFaIwAyb: return tOrSvd8QKNB(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᰜ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	return DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᰝ"),[],[]
def dL4SBey7iu(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,tOrSvd8QKNB(u"ࠩࡊࡉ࡙࠭ᰞ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬᰟ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(XWbHfI9B8swrOL(u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᰠ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[h17Zb2ld4yLBrCP5tiw]
	return WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᰡ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def ssTIo54KM1(url):
	ffJtczXvkj0o2HUZRprAOS = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡵࡳ࡮ࠪᰢ"))
	if NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡪࡰࡧࡩࡽࡃࠧᰣ") in url:
		headers = {DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᰤ"):ffJtczXvkj0o2HUZRprAOS}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࡊࡉ࡙࠭ᰥ"),url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫᰦ"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᰧ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if Kj0TOU6BmSMlJHZYLd:
			Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]
			if vZL6j4tSClIGxzNE5DX(u"ࠬ࡮ࡴࡵࡲࠪᰨ") not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = JJu4MPClbTFpUwHiN(u"࠭ࡨࡵࡶࡳ࠾ࠬᰩ")+Kj0TOU6BmSMlJHZYLd
			if mpusoZBJ6V(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᰪ") in Kj0TOU6BmSMlJHZYLd:
				Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace(pGncXOodjKhJzLSqVP1r(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪᰫ"),bDt7Ya1VEio3(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪᰬ"))
				JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,JJu4MPClbTFpUwHiN(u"ࠪࡋࡊ࡚ࠧᰭ"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬᰮ"))
				BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
				items = sBvufaD6c9YHdOqTjCQ3.findall(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᰯ"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
				gd2lmLiIyEvcsT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,tg9l25NH6WTacVSifLyAmY(u"࠭ࡵࡳ࡮ࠪᰰ"))
				for RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS in reversed(items):
					RMC6c2kL5hGOnFaIwAyb = gd2lmLiIyEvcsT+RMC6c2kL5hGOnFaIwAyb+FF70emVxhWOngCty(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᰱ")+gd2lmLiIyEvcsT
					ttGBwQOv3K41hIkc6.append(oI6LvXMf4VEPe8jOdpKC0hUmS)
					ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
				return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
			else: return g4UCaNkHvLwGhjmW(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᰲ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	Kj0TOU6BmSMlJHZYLd = url+mpusoZBJ6V(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬᰳ")+ffJtczXvkj0o2HUZRprAOS
	if OOhnpQ8XvCVclGqdu(u"ࠪ࡬ࡹࡺࡰࠨᰴ") not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = Xr2aHOK0huQ5DTS(u"ࠫ࡭ࡺࡴࡱ࠼ࠪᰵ")+Kj0TOU6BmSMlJHZYLd
	return QigevCplXxbPI1H,[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
def G6mpvTjkPO8QiWyANKsfaSoFh0R3zV(RMC6c2kL5hGOnFaIwAyb):
	ffJtczXvkj0o2HUZRprAOS = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡻࡲ࡭ࠩᰶ"))
	if mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡰࡰࡵࡷ࡭ࡩ᰷࠭") in RMC6c2kL5hGOnFaIwAyb:
		WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(y5yX4jh6kUEgWZQIc(u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭᰸"),RMC6c2kL5hGOnFaIwAyb+FF70emVxhWOngCty(u"ࠨࠨࠩࠫ᰹"),sBvufaD6c9YHdOqTjCQ3.DOTALL)
		url,d8o4GfOLXIhV7b,rYsGTvB7OdokCyS10MHXEPzhe = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
		data = {mpusoZBJ6V(u"ࠩ࡬ࡨࠬ᰺"):d8o4GfOLXIhV7b,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡷࡪࡸࡶࡦࡴࠪ᰻"):rYsGTvB7OdokCyS10MHXEPzhe}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,y5yX4jh6kUEgWZQIc(u"ࠫࡕࡕࡓࡕࠩ᰼"),url,data,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭᰽"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᰾"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[h17Zb2ld4yLBrCP5tiw]
		if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ᰿") in Kj0TOU6BmSMlJHZYLd:
			headers = {hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ᱀"):ffJtczXvkj0o2HUZRprAOS,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᱁"):QigevCplXxbPI1H}
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,O4ylJvVNwLztdiHqBWDU(u"ࠪࡋࡊ࡚ࠧ᱂"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ᱃"))
			BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
			items = sBvufaD6c9YHdOqTjCQ3.findall(O4ylJvVNwLztdiHqBWDU(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᱄"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
			gd2lmLiIyEvcsT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡵࡳ࡮ࠪ᱅"))
			for RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS in reversed(items):
				RMC6c2kL5hGOnFaIwAyb = gd2lmLiIyEvcsT+RMC6c2kL5hGOnFaIwAyb+svULcgJ7jm(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ᱆")+gd2lmLiIyEvcsT
				ttGBwQOv3K41hIkc6.append(oI6LvXMf4VEPe8jOdpKC0hUmS)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
		else: return O4ylJvVNwLztdiHqBWDU(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᱇"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	else:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ᱈")+ffJtczXvkj0o2HUZRprAOS
		return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
def UwKh83oDl1(RMC6c2kL5hGOnFaIwAyb):
	if tg9l25NH6WTacVSifLyAmY(u"ࠪࡴࡴࡹࡴࡪࡦࠪ᱉") in RMC6c2kL5hGOnFaIwAyb:
		WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭᱊"),RMC6c2kL5hGOnFaIwAyb+tOrSvd8QKNB(u"ࠬࠬࠦࠨ᱋"),sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		d8o4GfOLXIhV7b,rYsGTvB7OdokCyS10MHXEPzhe = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
		tMCKuqcWisxdf8XwI5lYBQ9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,pGncXOodjKhJzLSqVP1r(u"࠭ࡵࡳ࡮ࠪ᱌"))
		url = tMCKuqcWisxdf8XwI5lYBQ9+tOrSvd8QKNB(u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬᱍ")+d8o4GfOLXIhV7b+tg9l25NH6WTacVSifLyAmY(u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬᱎ")+rYsGTvB7OdokCyS10MHXEPzhe
		headers = { svULcgJ7jm(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᱏ"):QigevCplXxbPI1H , pTwKPmzMSZhil5d2RWonre(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭᱐"):O4ylJvVNwLztdiHqBWDU(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ᱑") }
		Kj0TOU6BmSMlJHZYLd = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ᱒"))
		Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
		return mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᱓"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	elif tg9l25NH6WTacVSifLyAmY(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ᱔") in RMC6c2kL5hGOnFaIwAyb:
		d3nA2LsHai59 = OTRKI6LbrQnZEm(u"࠵ῼ")
		while DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ᱕") in RMC6c2kL5hGOnFaIwAyb and d3nA2LsHai59<fk8jc5uDLX16qrih3ZaPxsvO(u"࠻´"):
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,JJu4MPClbTFpUwHiN(u"ࠩࡊࡉ࡙࠭᱖"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬ᱗"))
			if WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭᱘") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()): RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[s0vAWcLSXEToH9Mik134q(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ᱙")]
			d3nA2LsHai59 += VvhRUZgko5Af1BIynMGOJSbpmK(u"࠱῾")
		return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	else: return mpusoZBJ6V(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪᱚ"),[],[]
def ddwWLZ315h(url):
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,OOhnpQ8XvCVclGqdu(u"ࠧࡶࡴ࡯ࠫᱛ"))
	headers = {svULcgJ7jm(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᱜ"):bSrdN78jxURTvh9,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᱝ"):eUBL1rOR4ZfndJAWPsoN6pybT0()}
	if y5yX4jh6kUEgWZQIc(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫᱞ") in url:
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭ᱟ"))
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(O4ylJvVNwLztdiHqBWDU(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᱠ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RMC6c2kL5hGOnFaIwAyb:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw].replace(Xr2aHOK0huQ5DTS(u"࠭ࡨࡵࡶࡳࡷࠬᱡ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡩࡶࡷࡴࠬᱢ"))
			return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	else:
		NXwx2iFPUKHqS1fgV9n0k = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡉࡈࡘࠬᱣ"),url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫᱤ"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = NXwx2iFPUKHqS1fgV9n0k.content
		T24Te3uDwBS5vLgUEAhF1O = headers.copy()
		if OOhnpQ8XvCVclGqdu(u"ࠪࡣࡱࡴ࡫ࡠࠩᱥ") in str(NXwx2iFPUKHqS1fgV9n0k.cookies):
			cookies = NXwx2iFPUKHqS1fgV9n0k.cookies
			T24Te3uDwBS5vLgUEAhF1O[y5yX4jh6kUEgWZQIc(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫᱦ")] = MVkP7zfWlxUXj(q8KvkirVNMoRIB5eJ(cookies))
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨᱧ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not RMC6c2kL5hGOnFaIwAyb: return y5yX4jh6kUEgWZQIc(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱨ"),[QigevCplXxbPI1H],[url]
		else:
			RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw])+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࠧࡦࡀ࠵ࠬᱩ")
			FoZ6n1al9wLqprS = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࡉࡈࡘࠬᱪ"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,s0vAWcLSXEToH9Mik134q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫᱫ"))
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = FoZ6n1al9wLqprS.content
			RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᱬ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if RMC6c2kL5hGOnFaIwAyb:
				RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw])
				if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡲࡶ࠴ࠨᱭ") in RMC6c2kL5hGOnFaIwAyb and g4UCaNkHvLwGhjmW(u"ࠬ࠵ࡤ࠰ࠩᱮ") in RMC6c2kL5hGOnFaIwAyb: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
				else: return bDt7Ya1VEio3(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱯ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	return y5yX4jh6kUEgWZQIc(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫᱰ"),[],[]
def Q8XUhOplV9(RMC6c2kL5hGOnFaIwAyb):
	if fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬᱱ") in RMC6c2kL5hGOnFaIwAyb:
		headers = {v54ZuLY6dQ(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬᱲ"):hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫᱳ")}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,Fg72JX6T5DkPy(u"ࠫࡌࡋࡔࠨᱴ"),RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧᱵ"))
		url = JJrhP4C6osGDFEKVSRBvX.content
		if url: return pGncXOodjKhJzLSqVP1r(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱶ"),[QigevCplXxbPI1H],[url]
	else:
		WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨᱷ"),RMC6c2kL5hGOnFaIwAyb,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if not WShVouXDRCGjeIFMYTHyimk5dlz: WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫᱸ"),RMC6c2kL5hGOnFaIwAyb,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		d8o4GfOLXIhV7b,rYsGTvB7OdokCyS10MHXEPzhe = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
		bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,s0vAWcLSXEToH9Mik134q(u"ࠩࡸࡶࡱ࠭ᱹ"))
		url = bSrdN78jxURTvh9+bDt7Ya1VEio3(u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫᱺ")
		data = {tOrSvd8QKNB(u"ࠫ࡮ࡪࠧᱻ"):d8o4GfOLXIhV7b,OTRKI6LbrQnZEm(u"ࠬ࡯ࠧᱼ"):rYsGTvB7OdokCyS10MHXEPzhe}
		headers = {tg9l25NH6WTacVSifLyAmY(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᱽ"):OOhnpQ8XvCVclGqdu(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ᱾"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ᱿"):RMC6c2kL5hGOnFaIwAyb}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,tg9l25NH6WTacVSifLyAmY(u"ࠩࡓࡓࡘ࡚ࠧᲀ"),url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬᲁ"))
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᲂ"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if Kj0TOU6BmSMlJHZYLd:
			Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[h17Zb2ld4yLBrCP5tiw]
			return TCF8wLyDvgumfiXPSKRh(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᲃ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	return OOhnpQ8XvCVclGqdu(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪᲄ"),[],[]
def OO9ACzVFXtRUmyWq1c4dj(nnPAxcXvhQ1Ib):
	ZM9W2ujVN6qaSHYg5cPi83FT = uUTRHgAXJzm7pIDBjNt8.getSetting(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨᲅ"))
	headers = {s0vAWcLSXEToH9Mik134q(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨᲆ"):ZM9W2ujVN6qaSHYg5cPi83FT} if ZM9W2ujVN6qaSHYg5cPi83FT else QigevCplXxbPI1H
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,OOhnpQ8XvCVclGqdu(u"ࠩࡊࡉ࡙࠭ᲇ"),nnPAxcXvhQ1Ib,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪᲈ"))
	ufJaRr0F38Ns = JJrhP4C6osGDFEKVSRBvX.content
	nwa0TbXoIcrhJm = str(JJrhP4C6osGDFEKVSRBvX.headers)
	JDhSrvo6BI4M0Yf5LEPe = nwa0TbXoIcrhJm+ufJaRr0F38Ns
	if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࠳ࡳࡰ࠵ࠩᲉ") in JDhSrvo6BI4M0Yf5LEPe: ARiQLVuwZY2nqCB5tv9mbe31f6 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	else:
		I8RHb6PaZDjAi1XJN,F01WAKej2RtVrpXQvi,MFVQk4JzvW2Zoqts,EEu6hFOcqYXr,ARiQLVuwZY2nqCB5tv9mbe31f6 = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB
		captcha = sBvufaD6c9YHdOqTjCQ3.findall(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡶࡡࡨࡧ࠰ࡶࡪࡪࡩࡳࡧࡦࡸ࠳࠰࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵ࡬ࡸࡪࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᲊ"),ufJaRr0F38Ns,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if captcha: MFVQk4JzvW2Zoqts,EEu6hFOcqYXr = captcha[h17Zb2ld4yLBrCP5tiw]
		DLmu1da4ls6HcfbGU5RznFOQXT = OQv0iWIw5bFRATU2mxJjZK[pTwKPmzMSZhil5d2RWonre(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭᲋")][tg9l25NH6WTacVSifLyAmY(u"࠸῿")]
		PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(vZL6j4tSClIGxzNE5DX(u"࠷࠷ࠀ"))
		if Fg72JX6T5DkPy(u"࠵ࠁ"):
			data = {Fg72JX6T5DkPy(u"ࠧࡶࡵࡨࡶࠬ᲌"):PXVdZQYTNslvg7wF0159Akr,Fg72JX6T5DkPy(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ᲍"):GVmdqbtLu8lUXNxp13aHOvkscR,Xr2aHOK0huQ5DTS(u"ࠩࡸࡶࡱ࠭᲎"):nnPAxcXvhQ1Ib,FF70emVxhWOngCty(u"ࠪ࡯ࡪࡿࠧ᲏"):EEu6hFOcqYXr,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫ࡮ࡪࠧᲐ"):QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡰ࡯ࡣࠩᲑ"):s0vAWcLSXEToH9Mik134q(u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧᲒ")}
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡑࡑࡖࡘࠬᲓ"),DLmu1da4ls6HcfbGU5RznFOQXT,data,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠷ࡴࡤࠨᲔ"))
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = QigevCplXxbPI1H
		if aY63L2NhgvwJIxPAoDG4MKECmZXF1.startswith(JJu4MPClbTFpUwHiN(u"ࠩࡘࡖࡑ࡙࠽ࠨᲕ")):
			G0RTQfMtClr5zXvaOxgepE9VYS = CH86N7xw4cyPt3TlIBJF(TCF8wLyDvgumfiXPSKRh(u"ࠪࡰ࡮ࡹࡴࠨᲖ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1.split(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࡚ࠫࡘࡌࡔ࠿ࠪᲗ"),y5yX4jh6kUEgWZQIc(u"࠷ࠂ"))[nfC2im3NzUQk])
			for x9Ahuz3FVWmJDaNp5 in G0RTQfMtClr5zXvaOxgepE9VYS:
				url = x9Ahuz3FVWmJDaNp5[XWbHfI9B8swrOL(u"ࠬࡻࡲ࡭ࠩᲘ")]
				meRBy38nDXP2cGW9aVUlKCZTgx1oI = x9Ahuz3FVWmJDaNp5[s0vAWcLSXEToH9Mik134q(u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭Კ")]
				data = x9Ahuz3FVWmJDaNp5[tg9l25NH6WTacVSifLyAmY(u"ࠧࡥࡣࡷࡥࠬᲚ")]
				headers = x9Ahuz3FVWmJDaNp5[TCF8wLyDvgumfiXPSKRh(u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩᲛ")]
				JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,meRBy38nDXP2cGW9aVUlKCZTgx1oI,url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩᲜ"))
				ufJaRr0F38Ns = JJrhP4C6osGDFEKVSRBvX.content
				if svULcgJ7jm(u"ࠪ࠲ࡲࡶ࠴ࠨᲝ") in ufJaRr0F38Ns:
					ARiQLVuwZY2nqCB5tv9mbe31f6 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
					break
				nwa0TbXoIcrhJm = str(JJrhP4C6osGDFEKVSRBvX.headers)
				JDhSrvo6BI4M0Yf5LEPe = nwa0TbXoIcrhJm+ufJaRr0F38Ns
				I8RHb6PaZDjAi1XJN = sBvufaD6c9YHdOqTjCQ3.findall(Xr2aHOK0huQ5DTS(u"ࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࡞ࡺ࠯࠮࠴ࠪࡀࠤࠫࡩࡾࡐ࠮ࠫࡁࠬࠦࠬᲞ"),JDhSrvo6BI4M0Yf5LEPe,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				F01WAKej2RtVrpXQvi = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴ࠮ࠫࡁࠥࠬ࠵࠹ࡁ࠯ࠬࡂ࠭ࠧ࠭Ჟ"),JDhSrvo6BI4M0Yf5LEPe,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if F01WAKej2RtVrpXQvi: F01WAKej2RtVrpXQvi = F01WAKej2RtVrpXQvi[h17Zb2ld4yLBrCP5tiw]
				if I8RHb6PaZDjAi1XJN or F01WAKej2RtVrpXQvi: break
		if not ARiQLVuwZY2nqCB5tv9mbe31f6:
			if not I8RHb6PaZDjAi1XJN:
				if captcha and not F01WAKej2RtVrpXQvi:
					if VvhRUZgko5Af1BIynMGOJSbpmK(u"࠱ࠃ"): F01WAKej2RtVrpXQvi = FpP6hwI4C3u(EEu6hFOcqYXr,pTwKPmzMSZhil5d2RWonre(u"࠭ࡡࡳࠩᲠ"),nnPAxcXvhQ1Ib)
					else:
						if not aY63L2NhgvwJIxPAoDG4MKECmZXF1.startswith(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡊࡆࡀࠫᲡ")):
							data = {mpusoZBJ6V(u"ࠨࡷࡶࡩࡷ࠭Ტ"):PXVdZQYTNslvg7wF0159Akr,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪᲣ"):GVmdqbtLu8lUXNxp13aHOvkscR,svULcgJ7jm(u"ࠪࡹࡷࡲࠧᲤ"):nnPAxcXvhQ1Ib,OTRKI6LbrQnZEm(u"ࠫࡰ࡫ࡹࠨᲥ"):EEu6hFOcqYXr,pTwKPmzMSZhil5d2RWonre(u"ࠬ࡯ࡤࠨᲦ"):QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡪࡰࡤࠪᲧ"):mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡨࡧࡷ࡭ࡩ࠭Შ")}
							JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡒࡒࡗ࡙࠭Ჩ"),DLmu1da4ls6HcfbGU5RznFOQXT,data,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,FF70emVxhWOngCty(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠺ࡴࡩࠩᲪ"))
							aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
						else: aY63L2NhgvwJIxPAoDG4MKECmZXF1 = DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡍࡉࡃ࠱࠳࠵࠷࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾࠶࠸ࠫᲫ")
						if aY63L2NhgvwJIxPAoDG4MKECmZXF1.startswith(tOrSvd8QKNB(u"ࠫࡎࡊ࠽ࠨᲬ")):
							hrNDaUfp68Pd = sBvufaD6c9YHdOqTjCQ3.findall(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡏࡄ࠾ࠪ࠱࠮ࡄ࠯࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠭࠴ࠪࡀࠫࠧࠫᲭ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
							Ahtl8SavnWrqksG,XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc = hrNDaUfp68Pd[h17Zb2ld4yLBrCP5tiw]
							nDRKguWex0iVN8 = K7bLVaiRkx0lgU5SQM(u"࠭็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ์็ะࠠๆ่ࠣ࠵࠵ࠦลๅ๋ࠣࠫᲮ")+XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc+tg9l25NH6WTacVSifLyAmY(u"ࠧࠡอส๊๏ฯࠧᲯ")
							KeUEGFHb0LfrZhCaqd3O4NuDTQ = EkO3SZvUhBmswzoC2cKRbfxyMYW7H()
							KeUEGFHb0LfrZhCaqd3O4NuDTQ.create(OTRKI6LbrQnZEm(u"ࠨ็ะหํ๊ษࠡฬฯหํุࠠโฯุࠤศ์วࠡล้ืฬ์้ࠠๆึฮࠥฮั็ษ่ะ้่ࠥๆสํ์ฯืࠧᲰ"),nDRKguWex0iVN8)
							qqt6cmaLxOR841rUD5ik9pBQI = B3TKLo71hAGRqYgV0.time()
							ssNJjphTyqfka,LnC9Dx0ejO8XrEYa = mmKqLr9RX0ACN384JMcsFHzd(u"࠱ࠄ"),mmKqLr9RX0ACN384JMcsFHzd(u"࠱ࠄ")
							while ssNJjphTyqfka<int(XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc):
								flLzKUbZqpmX(KeUEGFHb0LfrZhCaqd3O4NuDTQ,int(ssNJjphTyqfka/int(XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc)*O4ylJvVNwLztdiHqBWDU(u"࠳࠳࠴ࠅ")),nDRKguWex0iVN8,QigevCplXxbPI1H,XX4T9ZFf7DnbzGv2kpPNeLoVWQJOKc+FF70emVxhWOngCty(u"ࠩࠣ࠳ࠥ࠭Ჱ")+str(int(ssNJjphTyqfka))+K7bLVaiRkx0lgU5SQM(u"ࠪࠤࠥัว็์ฬࠫᲲ"))
								if ssNJjphTyqfka>LnC9Dx0ejO8XrEYa+mpusoZBJ6V(u"࠴࠴ࠆ"):
									data = {fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡺࡹࡥࡳࠩᲳ"):PXVdZQYTNslvg7wF0159Akr,mpusoZBJ6V(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭Ჴ"):GVmdqbtLu8lUXNxp13aHOvkscR,v54ZuLY6dQ(u"࠭ࡵࡳ࡮ࠪᲵ"):nnPAxcXvhQ1Ib,y5yX4jh6kUEgWZQIc(u"ࠧ࡬ࡧࡼࠫᲶ"):EEu6hFOcqYXr,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࡫ࡧࠫᲷ"):Ahtl8SavnWrqksG,g4UCaNkHvLwGhjmW(u"ࠩ࡭ࡳࡧ࠭Ჸ"):s0vAWcLSXEToH9Mik134q(u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬᲹ")}
									JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,bDt7Ya1VEio3(u"ࠫࡕࡕࡓࡕࠩᲺ"),DLmu1da4ls6HcfbGU5RznFOQXT,data,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ᲻"))
									aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
									if aY63L2NhgvwJIxPAoDG4MKECmZXF1.startswith(OTRKI6LbrQnZEm(u"࠭ࡔࡐࡍࡈࡒࡂ࠭᲼")):
										F01WAKej2RtVrpXQvi = aY63L2NhgvwJIxPAoDG4MKECmZXF1.split(OOhnpQ8XvCVclGqdu(u"ࠧࡕࡑࡎࡉࡓࡃࠧᲽ"),mmKqLr9RX0ACN384JMcsFHzd(u"࠵ࠇ"))[nfC2im3NzUQk]
										break
									LnC9Dx0ejO8XrEYa = ssNJjphTyqfka
								else: B3TKLo71hAGRqYgV0.sleep(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠶ࠈ"))
								ssNJjphTyqfka = B3TKLo71hAGRqYgV0.time()-qqt6cmaLxOR841rUD5ik9pBQI
							KeUEGFHb0LfrZhCaqd3O4NuDTQ.close()
				if F01WAKej2RtVrpXQvi:
					TTXZV7CstHrKSkz49ULRGcEaN = JJrhP4C6osGDFEKVSRBvX.cookies
					BxyHIU8VP36gkTMp = sBvufaD6c9YHdOqTjCQ3.findall(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠪ࠱࠮ࡄ࠯࠻ࠨᲾ"),JDhSrvo6BI4M0Yf5LEPe,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					if y5yX4jh6kUEgWZQIc(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩᲿ") in list(TTXZV7CstHrKSkz49ULRGcEaN.keys()): BxyHIU8VP36gkTMp = TTXZV7CstHrKSkz49ULRGcEaN[svULcgJ7jm(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࠪ᳀")]
					elif BxyHIU8VP36gkTMp: BxyHIU8VP36gkTMp = BxyHIU8VP36gkTMp[h17Zb2ld4yLBrCP5tiw]
					captcha = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᳁"),ufJaRr0F38Ns,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					if captcha: MFVQk4JzvW2Zoqts,EEu6hFOcqYXr = captcha[h17Zb2ld4yLBrCP5tiw]
					if BxyHIU8VP36gkTMp and captcha:
						headers = {aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ᳂"):WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠧ᳃")+BxyHIU8VP36gkTMp,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ᳄"):nnPAxcXvhQ1Ib,mpusoZBJ6V(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ᳅"):DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ᳆")}
						data = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪ࡫࠲ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡴࡨࡷࡵࡵ࡮ࡴࡧࡀࠫ᳇")+F01WAKej2RtVrpXQvi
						JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,XWbHfI9B8swrOL(u"ࠫࡕࡕࡓࡕࠩ᳈"),MFVQk4JzvW2Zoqts,data,headers,YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,bDt7Ya1VEio3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠸ࡷ࡬ࠬ᳉"))
						ufJaRr0F38Ns = JJrhP4C6osGDFEKVSRBvX.content
						try: cookies = JJrhP4C6osGDFEKVSRBvX.cookies
						except: cookies = {}
						I8RHb6PaZDjAi1XJN = sBvufaD6c9YHdOqTjCQ3.findall(O4ylJvVNwLztdiHqBWDU(u"ࠨࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠳࠰࠿ࠪࠩ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ᳊"),str(cookies),sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if I8RHb6PaZDjAi1XJN:
				zsj5qOxnfaXmdEco3DK29HgYybUCM6,I8RHb6PaZDjAi1XJN = I8RHb6PaZDjAi1XJN[h17Zb2ld4yLBrCP5tiw]
				ZM9W2ujVN6qaSHYg5cPi83FT = zsj5qOxnfaXmdEco3DK29HgYybUCM6+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧ࠾ࠩ᳋")+I8RHb6PaZDjAi1XJN
				uUTRHgAXJzm7pIDBjNt8.setSetting(y5yX4jh6kUEgWZQIc(u"ࠨࡣࡹ࠲ࡦࡱࡷࡢ࡯࠱ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ᳌"),ZM9W2ujVN6qaSHYg5cPi83FT)
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᳍"),g4UCaNkHvLwGhjmW(u"๊ࠪัำสࠡ฻่่๏ฯࠠโฯุࠤศ์วࠡว้ืฬ์ࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬำุๆ่ࠡอหหา่ࠠาสࠤฬ๊แฮื่่ࠣ๐๋ࠠีอาิ๋็ศࠢ็หา่วࠡ࠰࠱ࠤํ๊วࠡฬ๋ะิࠦอศฮฬࠤ้หูศัฬࠤ์ึวࠡษ็ๅา฻ࠠๅ฻าอࠥษิ่ำࠣࡠࡳࡢ࡮ࠡ฻็้ฬࠦร็๊ࠢิฬࠦวๅใะูู่ࠥโࠢํฮ่ืัࠡใํࠤาอไสࠢอ฾๏ืࠠาสฺࠤฬ๊ฬ่ษีࠤออไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦลุใสลࠥืว้ฬิࠤฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥ็ีๅࠢึ่่ࠦวๅำส์ฯืࠠ࠯࠰ࠣวํࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤศ๎ࠠษำ๋็ุ๐ࠧ᳎"))
				if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࠳ࡳࡰ࠵ࠩ᳏") not in ufJaRr0F38Ns:
					headers = {OTRKI6LbrQnZEm(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ᳐"):ZM9W2ujVN6qaSHYg5cPi83FT}
					JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,Fg72JX6T5DkPy(u"࠭ࡇࡆࡖࠪ᳑"),nnPAxcXvhQ1Ib,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠻ࡹ࡮ࠧ᳒"))
					ufJaRr0F38Ns = JJrhP4C6osGDFEKVSRBvX.content
	if not ARiQLVuwZY2nqCB5tv9mbe31f6 and not ZM9W2ujVN6qaSHYg5cPi83FT: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᳓"),bDt7Ya1VEio3(u"ࠩไุ้ะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฤ่ึห๋ࠦ࠮࠯ࠢะหํ๊ࠠฦ฻สำฮࠦวๅ฻่่๏ฯࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤ๋็ำࠡษ็ๅ๏ี๊้ࠢฦ์ࠥ็๊ะ์๋ࠤ฿๐ั่่๊ࠢࠥ์แิࠢส่๊๎โ᳔ฺࠩ"))
	return ufJaRr0F38Ns
def kkERyGgDWI(url,type,oI6LvXMf4VEPe8jOdpKC0hUmS):
	vdLczqkV5b48ZKyGxTE3jJi17aWS6,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw = [],[]
	nnPAxcXvhQ1Ib = url
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,v54ZuLY6dQ(u"ࠪࡋࡊ࡚᳕ࠧ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠱ࡴࡶ᳖ࠪ"))
	BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
	YovCLBg5RcQi8OXFx = []
	if v54ZuLY6dQ(u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴᳗࠭") in BhxM1UVjtbEoSp640kIcag or VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱᳘ࠪ") in BhxM1UVjtbEoSp640kIcag:
		mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠮ࠫࡁ࠿࠳ࡦࡄ᳙ࠧ"),BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if mfFwcWZHXVGvyU3B0ILburCoh:
			for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
				rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᳚"),LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for RMC6c2kL5hGOnFaIwAyb,title in rsBojxT8UZwL:
					if RMC6c2kL5hGOnFaIwAyb in vdLczqkV5b48ZKyGxTE3jJi17aWS6: continue
					if DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ᳛") not in RMC6c2kL5hGOnFaIwAyb and v54ZuLY6dQ(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵᳜ࠧ") not in RMC6c2kL5hGOnFaIwAyb: continue
					if vZL6j4tSClIGxzNE5DX(u"ࠫฬ᳝࠭") not in title:
						YovCLBg5RcQi8OXFx.append((title,RMC6c2kL5hGOnFaIwAyb))
						continue
					title = title.replace(v54ZuLY6dQ(u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ᳞࠭"),QigevCplXxbPI1H).replace(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࠠ࠮᳟ࠢࠪ"),QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
					if v54ZuLY6dQ(u"ࠧࡴࡲࡤࡲࠬ᳠") in title: continue
					vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
					xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(title)
			for title,RMC6c2kL5hGOnFaIwAyb in YovCLBg5RcQi8OXFx:
				if RMC6c2kL5hGOnFaIwAyb not in vdLczqkV5b48ZKyGxTE3jJi17aWS6:
					vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
					xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(title)
			HHZ6579kAv8 = bDt7Ya1VEio3(u"࠶ࠉ")
			if len(vdLczqkV5b48ZKyGxTE3jJi17aWS6)>y5yX4jh6kUEgWZQIc(u"࠱ࠊ"):
				HHZ6579kAv8 = zYWJO03iISD(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨส฼ฺ์อ๋ࠠฯอหัࠦ࠶࠱ࠢฮห๋๐ษࠨ᳡"),xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw)
				if HHZ6579kAv8==-y5yX4jh6kUEgWZQIc(u"࠲ࠋ"): return VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡈࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑ᳢ࠬ"),[],[]
			if vdLczqkV5b48ZKyGxTE3jJi17aWS6 and HHZ6579kAv8>=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠲ࠌ"): nnPAxcXvhQ1Ib = vdLczqkV5b48ZKyGxTE3jJi17aWS6[HHZ6579kAv8]
	ufJaRr0F38Ns = OO9ACzVFXtRUmyWq1c4dj(nnPAxcXvhQ1Ib)
	ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6 = [],[]
	if type==WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ᳣ࠬ"):
		d3OY0tnXQGxTK9s4Uk8quhH = sBvufaD6c9YHdOqTjCQ3.findall(OTRKI6LbrQnZEm(u"ࠫࡧࡺ࡮࠮࡮ࡲࡥࡩ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅ᳤ࠩࠣࠩ"),ufJaRr0F38Ns,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if d3OY0tnXQGxTK9s4Uk8quhH:
			RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(d3OY0tnXQGxTK9s4Uk8quhH[h17Zb2ld4yLBrCP5tiw])
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			ttGBwQOv3K41hIkc6.append(oI6LvXMf4VEPe8jOdpKC0hUmS)
	elif type==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡽࡡࡵࡥ࡫᳥ࠫ"):
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall(s0vAWcLSXEToH9Mik134q(u"࠭࠼ࡴࡱࡸࡶࡨ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᳦"),ufJaRr0F38Ns,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,size in rsBojxT8UZwL:
			if not RMC6c2kL5hGOnFaIwAyb: continue
			if oI6LvXMf4VEPe8jOdpKC0hUmS in size:
				ttGBwQOv3K41hIkc6.append(size)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
				break
		if not ldFqnNIsftrY43JBM6LPjzU8m:
			for RMC6c2kL5hGOnFaIwAyb,size in rsBojxT8UZwL:
				if not RMC6c2kL5hGOnFaIwAyb: continue
				ttGBwQOv3K41hIkc6.append(size)
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if not ldFqnNIsftrY43JBM6LPjzU8m: return Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ᳧"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def LgyfTlFJC3(url,zsj5qOxnfaXmdEco3DK29HgYybUCM6):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,pGncXOodjKhJzLSqVP1r(u"ࠨࡉࡈࡘ᳨ࠬ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠶ࡹࡴࠨᳩ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	cookies = JJrhP4C6osGDFEKVSRBvX.cookies
	if Xr2aHOK0huQ5DTS(u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪᳪ") in list(cookies.keys()):
		ZM9W2ujVN6qaSHYg5cPi83FT = cookies[y5yX4jh6kUEgWZQIc(u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫᳫ")]
		ZM9W2ujVN6qaSHYg5cPi83FT = MVkP7zfWlxUXj(arFSQucmG9HxDody67JCI8pBMk4L(ZM9W2ujVN6qaSHYg5cPi83FT))
		items = sBvufaD6c9YHdOqTjCQ3.findall(FF70emVxhWOngCty(u"ࠬࡸ࡯ࡶࡶࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᳬ"),ZM9W2ujVN6qaSHYg5cPi83FT,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		Kj0TOU6BmSMlJHZYLd = items[h17Zb2ld4yLBrCP5tiw].replace(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭࡜࠰᳭ࠩ"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧ࠰ࠩᳮ"))
		Kj0TOU6BmSMlJHZYLd = arFSQucmG9HxDody67JCI8pBMk4L(Kj0TOU6BmSMlJHZYLd)
	else: Kj0TOU6BmSMlJHZYLd = url
	if s0vAWcLSXEToH9Mik134q(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪᳯ") in Kj0TOU6BmSMlJHZYLd:
		id = Kj0TOU6BmSMlJHZYLd.split(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࠨ࠶ࡋ࠭ᳰ"))[-Xr2aHOK0huQ5DTS(u"࠴ࠍ")]
		Kj0TOU6BmSMlJHZYLd = aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡦࡺࡣࡩ࠰࡬ࡷ࠴࠭ᳱ")+id
		return Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᳲ"),[QigevCplXxbPI1H],[Kj0TOU6BmSMlJHZYLd]
	else:
		website = OQv0iWIw5bFRATU2mxJjZK[svULcgJ7jm(u"ࠬࡇࡋࡐࡃࡐࠫᳳ")][h17Zb2ld4yLBrCP5tiw]
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡇࡆࡖࠪ᳴"),website,QigevCplXxbPI1H,QigevCplXxbPI1H,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,QigevCplXxbPI1H,OOhnpQ8XvCVclGqdu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭ᳵ"))
		ss95pZ4TnmUfKjI1RiYgO3 = JJrhP4C6osGDFEKVSRBvX.url
		clx9X4qeshaJjGHK3PB = Kj0TOU6BmSMlJHZYLd.split(Fg72JX6T5DkPy(u"ࠨ࠱ࠪᳶ"))[JxuTQLOD357o41evylqPmRdf]
		eQnbdsNGPfM2qhtDawXEk1VBJg9 = ss95pZ4TnmUfKjI1RiYgO3.split(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩ࠲ࠫ᳷"))[JxuTQLOD357o41evylqPmRdf]
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd.replace(clx9X4qeshaJjGHK3PB,eQnbdsNGPfM2qhtDawXEk1VBJg9)
		headers = { NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᳸"):QigevCplXxbPI1H , y5yX4jh6kUEgWZQIc(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ᳹"):NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ᳺ") , tg9l25NH6WTacVSifLyAmY(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ᳻"):NW6gmPcC1B4ILwdHTz0GlDsi5Fkx }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡑࡑࡖࡘࠬ᳼"), NW6gmPcC1B4ILwdHTz0GlDsi5Fkx, QigevCplXxbPI1H, headers, YoAMfqm37GyFxbuKTt6e8CESHrhB,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠷ࡷࡪࠧ᳽"))
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		items = sBvufaD6c9YHdOqTjCQ3.findall(y5yX4jh6kUEgWZQIc(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ᳾"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if not items:
			items = sBvufaD6c9YHdOqTjCQ3.findall(JJu4MPClbTFpUwHiN(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᳿"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
			if not items:
				items = sBvufaD6c9YHdOqTjCQ3.findall(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫࡁ࡫࡭ࡣࡧࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᴀ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if items:
			RMC6c2kL5hGOnFaIwAyb = items[h17Zb2ld4yLBrCP5tiw].replace(vZL6j4tSClIGxzNE5DX(u"ࠬࡢ࠯ࠨᴁ"),Fg72JX6T5DkPy(u"࠭࠯ࠨᴂ"))
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.rstrip(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧ࠰ࠩᴃ"))
			if tg9l25NH6WTacVSifLyAmY(u"ࠨࡪࡷࡸࡵ࠭ᴄ") not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩ࡫ࡸࡹࡶ࠺ࠨᴅ") + RMC6c2kL5hGOnFaIwAyb
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(pGncXOodjKhJzLSqVP1r(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫᴆ"),v54ZuLY6dQ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ᴇ"))
			if zsj5qOxnfaXmdEco3DK29HgYybUCM6==QigevCplXxbPI1H: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
			else: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴈ"),[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
		else: gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = s0vAWcLSXEToH9Mik134q(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧᴉ"),[],[]
		return gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def OjVCNXx1pJS(url):
	headers = { OOhnpQ8XvCVclGqdu(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᴊ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,FF70emVxhWOngCty(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬᴋ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴌ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m,errno = [],[],QigevCplXxbPI1H
	if items:
		for RMC6c2kL5hGOnFaIwAyb,J4kSW2aUHYg6 in items:
			ttGBwQOv3K41hIkc6.append(J4kSW2aUHYg6)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if len(ldFqnNIsftrY43JBM6LPjzU8m)==s0vAWcLSXEToH9Mik134q(u"࠴ࠎ"): return mpusoZBJ6V(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐࠩᴍ"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def nna4iu9HUeKb30L(url):
	headers = {v54ZuLY6dQ(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᴎ"):QigevCplXxbPI1H}
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡔࡐࡔࡇࡄ࠮࠳ࡶࡸࠬᴏ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(mpusoZBJ6V(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫᴐ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items:
		url = items[h17Zb2ld4yLBrCP5tiw]+OTRKI6LbrQnZEm(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᴑ")+url
		return QigevCplXxbPI1H,[QigevCplXxbPI1H],[url]
	else: return WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡖࡒࡏࡂࡆࠪᴒ"),[],[]
def VyOU3WrCbidm(url):
	url = url.strip(JJu4MPClbTFpUwHiN(u"ࠩ࠲ࠫᴓ"))
	if NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫᴔ") in url: id = url.split(g4UCaNkHvLwGhjmW(u"ࠫ࠴࠭ᴕ"))[bWU9StnJOg6aIQiTMxh7sFZG8lPud]
	else: id = url.split(g4UCaNkHvLwGhjmW(u"ࠬ࠵ࠧᴖ"))[-FF70emVxhWOngCty(u"࠶ࠏ")]
	url = DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡥࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡳ࠴ࡶ࡬ࡢࡻࡨࡶࡄ࡬ࡩࡥ࠿ࠪᴗ") + id
	headers = { DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᴘ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,y5yX4jh6kUEgWZQIc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡉࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪᴙ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace(OOhnpQ8XvCVclGqdu(u"ࠩ࡟ࡠࠬᴚ"),QigevCplXxbPI1H)
	items = sBvufaD6c9YHdOqTjCQ3.findall(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪᴛ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[ items[h17Zb2ld4yLBrCP5tiw] ]
	else: return DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡄࡕࡗࡖࡊࡇࡍࠨᴜ"),[],[]
def z2zJLkfHa0oQvNKYEBS96(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬᴝ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴞ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
	for RMC6c2kL5hGOnFaIwAyb,J4kSW2aUHYg6,IeBWJ9sMvo0Aq in items:
		ttGBwQOv3K41hIkc6.append(J4kSW2aUHYg6+hT7zFDpEyUqf8sXuN+IeBWJ9sMvo0Aq)
		ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if len(ldFqnNIsftrY43JBM6LPjzU8m)==K7bLVaiRkx0lgU5SQM(u"࠶ࠐ"): return VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡕ࡚ࡂࠩᴟ"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def XB6wFC8O73(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬᴠ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢᴡ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	items = set(items)
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
	for id,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hash,J4kSW2aUHYg6,IeBWJ9sMvo0Aq in items:
		url = s0vAWcLSXEToH9Mik134q(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧᴢ")+id+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࠫࡳ࡯ࡥࡧࡀࠫᴣ")+TsckNQJ6yLiaEeCRml98WwKfVP0dYv+mpusoZBJ6V(u"ࠬࠬࡨࡢࡵ࡫ࡁࠬᴤ")+hash
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪᴥ"))
		items = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴦ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb in items:
			ttGBwQOv3K41hIkc6.append(J4kSW2aUHYg6+hT7zFDpEyUqf8sXuN+IeBWJ9sMvo0Aq)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if len(ldFqnNIsftrY43JBM6LPjzU8m)==K7bLVaiRkx0lgU5SQM(u"࠰ࠑ"): return WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧᴧ"),[],[]
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def KnyDmaUqRv3JuSzOi4BA5w7LgXECh(url):
	RMC6c2kL5hGOnFaIwAyb = QigevCplXxbPI1H
	if fk8jc5uDLX16qrih3ZaPxsvO(u"࠲ࠒ") or y5yX4jh6kUEgWZQIc(u"ࠩࡎࡩࡾࡃࠧᴨ") not in url:
		Kj0TOU6BmSMlJHZYLd = url.replace(g4UCaNkHvLwGhjmW(u"ࠪࡹࡵࡨ࡯࡮࠰࡯࡭ࡻ࡫ࠧᴩ"),OTRKI6LbrQnZEm(u"ࠫࡺࡶࡰࡰ࡯࠱ࡰ࡮ࡼࡥࠨᴪ"))
		Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.split(g4UCaNkHvLwGhjmW(u"ࠬ࠵ࠧᴫ"))
		id = Kj0TOU6BmSMlJHZYLd[mVjHAyIwzSNKLFcd]
		Kj0TOU6BmSMlJHZYLd = fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࠯ࠨᴬ").join(Kj0TOU6BmSMlJHZYLd[pGncXOodjKhJzLSqVP1r(u"࠲ࠓ"):Xr2aHOK0huQ5DTS(u"࠷ࠔ")])
		A1AqSc2LNwW0ETgyaRl9 = {Xr2aHOK0huQ5DTS(u"ࠧࡪࡦࠪᴭ"):id,TCF8wLyDvgumfiXPSKRh(u"ࠨࡱࡳࠫᴮ"):QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬᴯ"),pGncXOodjKhJzLSqVP1r(u"ࠪࡱࡪࡺࡨࡰࡦࡢࡪࡷ࡫ࡥࠨᴰ"):VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡋࡸࡥࡦ࠭ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠯ࠪ࠹ࡅࠦ࠵ࡈࠫᴱ")}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,s0vAWcLSXEToH9Mik134q(u"ࠬࡖࡏࡔࡖࠪᴲ"),Kj0TOU6BmSMlJHZYLd,A1AqSc2LNwW0ETgyaRl9,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,FF70emVxhWOngCty(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠳ࡶࡸࠬᴳ"))
		if WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᴴ") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()): RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[mpusoZBJ6V(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᴵ")]
		if not RMC6c2kL5hGOnFaIwAyb and JJrhP4C6osGDFEKVSRBvX.succeeded:
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
			RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(svULcgJ7jm(u"ࠩ࡬ࡨࡂࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴶ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡋࡊ࡚ࠧᴷ"),url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠲࡯ࡦࠪᴸ"))
		if mpusoZBJ6V(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧᴹ") in list(JJrhP4C6osGDFEKVSRBvX.headers.keys()): RMC6c2kL5hGOnFaIwAyb = JJrhP4C6osGDFEKVSRBvX.headers[K7bLVaiRkx0lgU5SQM(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨᴺ")]
	if RMC6c2kL5hGOnFaIwAyb: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	return DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡔࡇࡕࡍࠨᴻ"),[],[]
def YHAOC38h7lr4mGZj(url):
	headers = { WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᴼ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫᴽ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩᴾ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
	if items:
		ttGBwQOv3K41hIkc6.append(TCF8wLyDvgumfiXPSKRh(u"ࠫࡲࡶ࠴ࠨᴿ"))
		ldFqnNIsftrY43JBM6LPjzU8m.append(items[h17Zb2ld4yLBrCP5tiw][nfC2im3NzUQk])
		ttGBwQOv3K41hIkc6.append(svULcgJ7jm(u"ࠬࡳ࠳ࡶ࠺ࠪᵀ"))
		ldFqnNIsftrY43JBM6LPjzU8m.append(items[h17Zb2ld4yLBrCP5tiw][h17Zb2ld4yLBrCP5tiw])
		return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
	else: return WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪᵁ"),[],[]
KAZSxgLItWq0UsC = YoAMfqm37GyFxbuKTt6e8CESHrhB
def ikY7SnFWRE(url):
	global KAZSxgLItWq0UsC
	if KAZSxgLItWq0UsC: return g4UCaNkHvLwGhjmW(u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧᵂ"),[],[]
	KAZSxgLItWq0UsC = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	id = url.split(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࠱ࠪᵃ"))[-DDHwpETQrAm0xMNXGfyhqsUi(u"࠵ࠕ")]
	id = id.split(bDt7Ya1VEio3(u"ࠩࠩࠫᵄ"))[h17Zb2ld4yLBrCP5tiw]
	id = id.replace(v54ZuLY6dQ(u"ࠪࡻࡦࡺࡣࡩࡁࡹࡁࠬᵅ"),QigevCplXxbPI1H)
	Kj0TOU6BmSMlJHZYLd = OQv0iWIw5bFRATU2mxJjZK[pGncXOodjKhJzLSqVP1r(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬᵆ")][h17Zb2ld4yLBrCP5tiw]+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠬ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨᵇ")+id
	mbUgTzOcZWXJx6aC9E = mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹ࠳ࡨࡥ࠰ࠩᵈ")+id
	MM6GJA5PupqZ43EWTFgQ07cbK,Cz91VYbFNUWIRKhdo3SpijDQr6GkP,KagPt5Af6b47U38w,c9OuYl7fZ6FPXSe34 = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	headers = {vZL6j4tSClIGxzNE5DX(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᵉ"):QigevCplXxbPI1H}
	if XWbHfI9B8swrOL(u"࠵ࠖ"):
		for GzabfJx3T1 in range(JJu4MPClbTFpUwHiN(u"࠻ࠗ")):
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡉࡈࡘࠬᵊ"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,tg9l25NH6WTacVSifLyAmY(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪᵋ"))
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
			if svULcgJ7jm(u"ࠪ࡭ࡹࡧࡧࠨᵌ") in aY63L2NhgvwJIxPAoDG4MKECmZXF1: break
			B3TKLo71hAGRqYgV0.sleep(pGncXOodjKhJzLSqVP1r(u"࠲࠘"))
		XJ2TlxN04ArswFneYPSLtMB53vGc = sBvufaD6c9YHdOqTjCQ3.findall(XWbHfI9B8swrOL(u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡔࡱࡧࡹࡦࡴࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࠨ࠯ࠬࡂ࠭ࡀࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨᵍ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if XJ2TlxN04ArswFneYPSLtMB53vGc: XJ2TlxN04ArswFneYPSLtMB53vGc = XJ2TlxN04ArswFneYPSLtMB53vGc[h17Zb2ld4yLBrCP5tiw]
		else: XJ2TlxN04ArswFneYPSLtMB53vGc = aY63L2NhgvwJIxPAoDG4MKECmZXF1
	else:
		headers[Xr2aHOK0huQ5DTS(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᵎ")] = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩᵏ")
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = OQv0iWIw5bFRATU2mxJjZK[Fg72JX6T5DkPy(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᵐ")][h17Zb2ld4yLBrCP5tiw]+pTwKPmzMSZhil5d2RWonre(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡱ࡮ࡤࡽࡪࡸࠧᵑ")
		aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU = svULcgJ7jm(u"ࠩࡾࠦࡻ࡯ࡤࡦࡱࡌࡨࠧࡀࠠࠣࠩᵒ")+id+svULcgJ7jm(u"ࠪࠦ࠱ࠦࠢࡤࡱࡱࡸࡪࡾࡴࠣ࠼ࠣࡿࠧࡩ࡬ࡪࡧࡱࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ࠽ࠤࠧ࠷࠮࠺ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤࠧࡇࡎࡅࡔࡒࡍࡉࡥࡔࡆࡕࡗࡗ࡚ࡏࡔࡆࠤࢀࢁࢂ࠭ᵓ")
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,Xr2aHOK0huQ5DTS(u"ࠫࡕࡕࡓࡕࠩᵔ"),NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠴ࡷࡹ࠭ᵕ"))
		XJ2TlxN04ArswFneYPSLtMB53vGc = JJrhP4C6osGDFEKVSRBvX.content
	XJ2TlxN04ArswFneYPSLtMB53vGc = XJ2TlxN04ArswFneYPSLtMB53vGc.replace(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧᵖ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࠧࠩᵗ"))
	SHmM7V9pyvrjNgftxLaQhUCbqoJE = CH86N7xw4cyPt3TlIBJF(Fg72JX6T5DkPy(u"ࠨࡦ࡬ࡧࡹ࠭ᵘ"),XJ2TlxN04ArswFneYPSLtMB53vGc)
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [OOhnpQ8XvCVclGqdu(u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭ᵙ")],[QigevCplXxbPI1H]
	try:
		FxJI3jWESrM4OQ9aCHsz67K1At0u = SHmM7V9pyvrjNgftxLaQhUCbqoJE[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬᵚ")][svULcgJ7jm(u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨᵛ")][v54ZuLY6dQ(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬᵜ")]
		for bmNf3qCStB1 in FxJI3jWESrM4OQ9aCHsz67K1At0u:
			RMC6c2kL5hGOnFaIwAyb = bmNf3qCStB1[TCF8wLyDvgumfiXPSKRh(u"࠭ࡢࡢࡵࡨ࡙ࡷࡲࠧᵝ")]
			try: title = bmNf3qCStB1[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧ࡯ࡣࡰࡩࠬᵞ")][DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬᵟ")]
			except: title = bmNf3qCStB1[s0vAWcLSXEToH9Mik134q(u"ࠩࡱࡥࡲ࡫ࠧᵠ")][FF70emVxhWOngCty(u"ࠪࡶࡺࡴࡳࠨᵡ")][h17Zb2ld4yLBrCP5tiw][JJu4MPClbTFpUwHiN(u"ࠫࡹ࡫ࡸࡵࡶࠪᵢ")]
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			ttGBwQOv3K41hIkc6.append(title)
	except: pass
	if len(ttGBwQOv3K41hIkc6)>TCF8wLyDvgumfiXPSKRh(u"࠲࠙"):
		HHZ6579kAv8 = zYWJO03iISD(bDt7Ya1VEio3(u"ࠬอฮหำࠣห้ะัอ็ฬࠤ࠭࠭ᵣ")+str(len(ttGBwQOv3K41hIkc6))+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࠠๆๆไ࠭ࠬᵤ"), ttGBwQOv3K41hIkc6)
		if HHZ6579kAv8==-OOhnpQ8XvCVclGqdu(u"࠳ࠚ"): return vZL6j4tSClIGxzNE5DX(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᵥ"),[],[]
		elif HHZ6579kAv8!=K7bLVaiRkx0lgU5SQM(u"࠳ࠛ"):
			RMC6c2kL5hGOnFaIwAyb = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]+TCF8wLyDvgumfiXPSKRh(u"ࠨࠨࠪᵦ")
			HKtkTvGneFfZprBN = sBvufaD6c9YHdOqTjCQ3.findall(mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࠩࠬ࡫ࡳࡴ࠾࠰࠭ࡃ࠮ࠬࠧᵧ"),RMC6c2kL5hGOnFaIwAyb)
			if HKtkTvGneFfZprBN: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(HKtkTvGneFfZprBN[h17Zb2ld4yLBrCP5tiw],v54ZuLY6dQ(u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫᵨ"))
			else: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+Xr2aHOK0huQ5DTS(u"ࠫ࡫ࡳࡴ࠾ࡸࡷࡸࠬᵩ")
			MM6GJA5PupqZ43EWTFgQ07cbK = RMC6c2kL5hGOnFaIwAyb.strip(tg9l25NH6WTacVSifLyAmY(u"ࠬࠬࠧᵪ"))
	GJwfPVjOS8UrIWkKd61CMmAgi,NNRynYbufVC,JlBk4hCaG2ZWD5z,NuaPv09Itcrlq5Mom,GbuVNlxqtmkrOE0QLniPhdpRHU = [],[],[],[],[]
	try: Cz91VYbFNUWIRKhdo3SpijDQr6GkP = SHmM7V9pyvrjNgftxLaQhUCbqoJE[mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ᵫ")][NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩᵬ")]
	except: pass
	try: KagPt5Af6b47U38w = SHmM7V9pyvrjNgftxLaQhUCbqoJE[TCF8wLyDvgumfiXPSKRh(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨᵭ")][svULcgJ7jm(u"ࠩ࡫ࡰࡸࡓࡡ࡯࡫ࡩࡩࡸࡺࡕࡳ࡮ࠪᵮ")]
	except: pass
	try: GJwfPVjOS8UrIWkKd61CMmAgi = SHmM7V9pyvrjNgftxLaQhUCbqoJE[FF70emVxhWOngCty(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪᵯ")][svULcgJ7jm(u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬᵰ")]
	except: pass
	try: NNRynYbufVC = SHmM7V9pyvrjNgftxLaQhUCbqoJE[O4ylJvVNwLztdiHqBWDU(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬᵱ")][Xr2aHOK0huQ5DTS(u"࠭ࡡࡥࡣࡳࡸ࡮ࡼࡥࡇࡱࡵࡱࡦࡺࡳࠨᵲ")]
	except: pass
	t1VZ9A5dzJUDkFmfBxMYrePScCW = GJwfPVjOS8UrIWkKd61CMmAgi+NNRynYbufVC
	for dict in t1VZ9A5dzJUDkFmfBxMYrePScCW:
		if Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡪࡶࡤ࡫ࠬᵳ") in list(dict.keys()): dict[svULcgJ7jm(u"ࠨ࡫ࡷࡥ࡬࠭ᵴ")] = str(dict[y5yX4jh6kUEgWZQIc(u"ࠩ࡬ࡸࡦ࡭ࠧᵵ")])
		if s0vAWcLSXEToH9Mik134q(u"ࠪࡪࡵࡹࠧᵶ") in list(dict.keys()): dict[tOrSvd8QKNB(u"ࠫ࡫ࡶࡳࠨᵷ")] = str(dict[O4ylJvVNwLztdiHqBWDU(u"ࠬ࡬ࡰࡴࠩᵸ")])
		if VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࡭ࡪ࡯ࡨࡘࡾࡶࡥࠨᵹ") in list(dict.keys()): dict[O4ylJvVNwLztdiHqBWDU(u"ࠧࡵࡻࡳࡩࠬᵺ")] = dict[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨ࡯࡬ࡱࡪ࡚ࡹࡱࡧࠪᵻ")]
		if VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫᵼ") in list(dict.keys()): dict[Xr2aHOK0huQ5DTS(u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧᵽ")] = str(dict[K7bLVaiRkx0lgU5SQM(u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭ᵾ")])
		if WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᵿ") in list(dict.keys()): dict[Fg72JX6T5DkPy(u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧᶀ")] = str(dict[JJu4MPClbTFpUwHiN(u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧᶁ")])
		if Fg72JX6T5DkPy(u"ࠨࡹ࡬ࡨࡹ࡮ࠧᶂ") in list(dict.keys()): dict[XWbHfI9B8swrOL(u"ࠩࡶ࡭ࡿ࡫ࠧᶃ")] = str(dict[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡻ࡮ࡪࡴࡩࠩᶄ")])+FF70emVxhWOngCty(u"ࠫࡽ࠭ᶅ")+str(dict[g4UCaNkHvLwGhjmW(u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬᶆ")])
		if TCF8wLyDvgumfiXPSKRh(u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩᶇ") in list(dict.keys()): dict[tOrSvd8QKNB(u"ࠧࡪࡰ࡬ࡸࠬᶈ")] = dict[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫᶉ")][y5yX4jh6kUEgWZQIc(u"ࠩࡶࡸࡦࡸࡴࠨᶊ")]+Xr2aHOK0huQ5DTS(u"ࠪ࠱ࠬᶋ")+dict[tg9l25NH6WTacVSifLyAmY(u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧᶌ")][TCF8wLyDvgumfiXPSKRh(u"ࠬ࡫࡮ࡥࠩᶍ")]
		if svULcgJ7jm(u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪᶎ") in list(dict.keys()): dict[TCF8wLyDvgumfiXPSKRh(u"ࠧࡪࡰࡧࡩࡽ࠭ᶏ")] = dict[Xr2aHOK0huQ5DTS(u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬᶐ")][vZL6j4tSClIGxzNE5DX(u"ࠩࡶࡸࡦࡸࡴࠨᶑ")]+FF70emVxhWOngCty(u"ࠪ࠱ࠬᶒ")+dict[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨᶓ")][g4UCaNkHvLwGhjmW(u"ࠬ࡫࡮ࡥࠩᶔ")]
		if O4ylJvVNwLztdiHqBWDU(u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧᶕ") in list(dict.keys()): dict[bDt7Ya1VEio3(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨᶖ")] = dict[OTRKI6LbrQnZEm(u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩᶗ")]
		if OOhnpQ8XvCVclGqdu(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪᶘ") in list(dict.keys()) and int(dict[pGncXOodjKhJzLSqVP1r(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫᶙ")])>Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠶࠷࠲࠳࠴࠶࠷࠸ࠜ"): del dict[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬᶚ")]
		if QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧᶛ") in list(dict.keys()):
			LLmung3DKPM7i6 = dict[OTRKI6LbrQnZEm(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨᶜ")].split(FF70emVxhWOngCty(u"ࠧࠧࠩᶝ"))
			for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in LLmung3DKPM7i6:
				key,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split(Fg72JX6T5DkPy(u"ࠨ࠿ࠪᶞ"),pTwKPmzMSZhil5d2RWonre(u"࠶ࠝ"))
				dict[key] = MVkP7zfWlxUXj(nFdGHjceZzW)
		if DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡸࡶࡱ࠭ᶟ") in list(dict.keys()): dict[pTwKPmzMSZhil5d2RWonre(u"ࠪࡹࡷࡲࠧᶠ")] = MVkP7zfWlxUXj(dict[g4UCaNkHvLwGhjmW(u"ࠫࡺࡸ࡬ࠨᶡ")])
		JlBk4hCaG2ZWD5z.append(dict)
	GsPjS8tnprMgI14dLxkyeBmTc3b = QigevCplXxbPI1H
	if K7bLVaiRkx0lgU5SQM(u"ࠬࡹࡰ࠾ࡵ࡬࡫ࠬᶢ") in XJ2TlxN04ArswFneYPSLtMB53vGc:
		cmflCoJLGPO13K8w95 = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬᶣ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if cmflCoJLGPO13K8w95:
			cmflCoJLGPO13K8w95 = OQv0iWIw5bFRATU2mxJjZK[FF70emVxhWOngCty(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨᶤ")][h17Zb2ld4yLBrCP5tiw]+cmflCoJLGPO13K8w95[h17Zb2ld4yLBrCP5tiw]
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡉࡈࡘࠬᶥ"),cmflCoJLGPO13K8w95,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,K7bLVaiRkx0lgU5SQM(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪᶦ"))
			GsPjS8tnprMgI14dLxkyeBmTc3b = JJrhP4C6osGDFEKVSRBvX.content
			import youtube_signature.cipher as utFne85IDbJMrf9LwEzogaXNpv,youtube_signature.json_script_engine as WQgaMxAIOvh9nVXjHD57pELc
			LLmung3DKPM7i6 = YXce4tCsPDFZK92pJaGRxzkWuUIMm.LLmung3DKPM7i6.Cipher()
			LLmung3DKPM7i6._object_cache = {}
			oe5FZKJR6hMkj = LLmung3DKPM7i6._load_javascript(GsPjS8tnprMgI14dLxkyeBmTc3b)
			qZARxi5fmQcyg9OeY = CH86N7xw4cyPt3TlIBJF(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡷࡹࡸࠧᶧ"),str(oe5FZKJR6hMkj))
			bb59qPBgHpRd = YXce4tCsPDFZK92pJaGRxzkWuUIMm.kS9NdMh0j4wmcpeyEG.JsonScriptEngine(qZARxi5fmQcyg9OeY)
	for dict in JlBk4hCaG2ZWD5z:
		url = dict[vZL6j4tSClIGxzNE5DX(u"ࠫࡺࡸ࡬ࠨᶨ")]
		if JJu4MPClbTFpUwHiN(u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠾ࠩᶩ") in url or url.count(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡳࡪࡩࡀࠫᶪ"))>pTwKPmzMSZhil5d2RWonre(u"࠷ࠞ"):
			NuaPv09Itcrlq5Mom.append(dict)
		elif GsPjS8tnprMgI14dLxkyeBmTc3b and svULcgJ7jm(u"ࠧࡴࠩᶫ") in list(dict.keys()) and K7bLVaiRkx0lgU5SQM(u"ࠨࡵࡳࠫᶬ") in list(dict.keys()):
			qGzlZSQUnOMcygDAKv1 = bb59qPBgHpRd.execute(dict[JJu4MPClbTFpUwHiN(u"ࠩࡶࠫᶭ")])
			if qGzlZSQUnOMcygDAKv1!=dict[TCF8wLyDvgumfiXPSKRh(u"ࠪࡷࠬᶮ")]:
				dict[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫࡺࡸ࡬ࠨᶯ")] = url+O4ylJvVNwLztdiHqBWDU(u"ࠬࠬࠧᶰ")+dict[VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࡳࡱࠩᶱ")]+JJu4MPClbTFpUwHiN(u"ࠧ࠾ࠩᶲ")+qGzlZSQUnOMcygDAKv1
				NuaPv09Itcrlq5Mom.append(dict)
	for dict in NuaPv09Itcrlq5Mom:
		ain78FlYBCWD31qLKEgT2bvIy,BDbAWq6y1EMwhHPik,wQEM6IzJ3D2RX0p,sM0mej2fYOFP7AHlnyDNJq63o,jj0598HRyNM6mcQUp,yQ0ebFuxaJkWsPS = OTRKI6LbrQnZEm(u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩᶳ"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪᶴ"),OOhnpQ8XvCVclGqdu(u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫᶵ"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬᶶ"),QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬ࠶ࠧᶷ")
		try:
			k0khbCoLmjBWXYZt6yxcQGg5vJSiFO = dict[mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡴࡺࡲࡨࠫᶸ")]
			k0khbCoLmjBWXYZt6yxcQGg5vJSiFO = k0khbCoLmjBWXYZt6yxcQGg5vJSiFO.replace(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࠬࠩᶹ"),QigevCplXxbPI1H)
			items = sBvufaD6c9YHdOqTjCQ3.findall(TCF8wLyDvgumfiXPSKRh(u"ࠨࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࡁ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪᶺ"),k0khbCoLmjBWXYZt6yxcQGg5vJSiFO,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			sM0mej2fYOFP7AHlnyDNJq63o,ain78FlYBCWD31qLKEgT2bvIy,jj0598HRyNM6mcQUp = items[h17Zb2ld4yLBrCP5tiw]
			ggELNzXTKS7MWePsIkVlJOY1BcF = jj0598HRyNM6mcQUp.split(O4ylJvVNwLztdiHqBWDU(u"ࠩ࠯ࠫᶻ"))
			BDbAWq6y1EMwhHPik = QigevCplXxbPI1H
			for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in ggELNzXTKS7MWePsIkVlJOY1BcF: BDbAWq6y1EMwhHPik += upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split(pGncXOodjKhJzLSqVP1r(u"ࠪ࠲ࠬᶼ"))[h17Zb2ld4yLBrCP5tiw]+pTwKPmzMSZhil5d2RWonre(u"ࠫ࠱࠭ᶽ")
			BDbAWq6y1EMwhHPik = BDbAWq6y1EMwhHPik.strip(TCF8wLyDvgumfiXPSKRh(u"ࠬ࠲ࠧᶾ"))
			if OTRKI6LbrQnZEm(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧᶿ") in list(dict.keys()): yQ0ebFuxaJkWsPS = str(float(dict[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ᷀")]*v54ZuLY6dQ(u"࠱࠱ࠟ"))//O4ylJvVNwLztdiHqBWDU(u"࠲࠲࠵࠸ࠠ")/v54ZuLY6dQ(u"࠱࠱ࠟ"))+Fg72JX6T5DkPy(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ᷁")
			else: yQ0ebFuxaJkWsPS = QigevCplXxbPI1H
			if sM0mej2fYOFP7AHlnyDNJq63o==NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡷࡩࡽࡺࡴࠨ᷂"): continue
			elif K7bLVaiRkx0lgU5SQM(u"ࠪ࠰ࠬ᷃") in k0khbCoLmjBWXYZt6yxcQGg5vJSiFO:
				sM0mej2fYOFP7AHlnyDNJq63o = vZL6j4tSClIGxzNE5DX(u"ࠫࡆ࠱ࡖࠨ᷄")
				wQEM6IzJ3D2RX0p = ain78FlYBCWD31qLKEgT2bvIy+eZXCHufT9YW4bRErSBOLmI+yQ0ebFuxaJkWsPS+dict[aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡹࡩࡻࡧࠪ᷅")].split(g4UCaNkHvLwGhjmW(u"࠭ࡸࠨ᷆"))[nfC2im3NzUQk]
			elif sM0mej2fYOFP7AHlnyDNJq63o==Fg72JX6T5DkPy(u"ࠧࡷ࡫ࡧࡩࡴ࠭᷇"):
				sM0mej2fYOFP7AHlnyDNJq63o = tg9l25NH6WTacVSifLyAmY(u"ࠨࡘ࡬ࡨࡪࡵࠧ᷈")
				wQEM6IzJ3D2RX0p = yQ0ebFuxaJkWsPS+dict[O4ylJvVNwLztdiHqBWDU(u"ࠩࡶ࡭ࡿ࡫ࠧ᷉")].split(mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡼ᷊ࠬ"))[nfC2im3NzUQk]+eZXCHufT9YW4bRErSBOLmI+dict[svULcgJ7jm(u"ࠫ࡫ࡶࡳࠨ᷋")]+tOrSvd8QKNB(u"ࠬ࡬ࡰࡴࠩ᷌")+eZXCHufT9YW4bRErSBOLmI+ain78FlYBCWD31qLKEgT2bvIy
			elif sM0mej2fYOFP7AHlnyDNJq63o==DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡡࡶࡦ࡬ࡳࠬ᷍"):
				sM0mej2fYOFP7AHlnyDNJq63o = mmKqLr9RX0ACN384JMcsFHzd(u"ࠧࡂࡷࡧ࡭ࡴ᷎࠭")
				wQEM6IzJ3D2RX0p = yQ0ebFuxaJkWsPS+str(int(dict[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡣࡸࡨ࡮ࡵ࡟ࡴࡣࡰࡴࡱ࡫࡟ࡳࡣࡷࡩ᷏ࠬ")])/DDHwpETQrAm0xMNXGfyhqsUi(u"࠳࠳࠴࠵ࠡ"))+svULcgJ7jm(u"ࠩ࡮࡬ࡿࠦࠠࠨ᷐")+dict[TCF8wLyDvgumfiXPSKRh(u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ᷑")]+y5yX4jh6kUEgWZQIc(u"ࠫࡨ࡮ࠧ᷒")+eZXCHufT9YW4bRErSBOLmI+ain78FlYBCWD31qLKEgT2bvIy
		except:
			THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
			if THFfWLwt62MmUz!=g4UCaNkHvLwGhjmW(u"ࠬࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࡢ࡮ࠨᷓ"): KXhrv29CGR8QTDzJIWLY.stderr.write(THFfWLwt62MmUz)
		if pTwKPmzMSZhil5d2RWonre(u"࠭ࡤࡶࡴࡀࠫᷔ") in dict[tOrSvd8QKNB(u"ࠧࡶࡴ࡯ࠫᷕ")]: ThO0AMm4jUGP9yr = round(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠴࠳࠻ࠣ")+float(dict[DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡷࡵࡰࠬᷖ")].split(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡧࡹࡷࡃࠧᷗ"),vZL6j4tSClIGxzNE5DX(u"࠴ࠢ"))[nfC2im3NzUQk].split(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࠪࠬᷘ"),vZL6j4tSClIGxzNE5DX(u"࠴ࠢ"))[h17Zb2ld4yLBrCP5tiw]))
		elif QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫࡦࡶࡰࡳࡱࡻࡈࡺࡸࡡࡵ࡫ࡲࡲࡒࡹࠧᷙ") in list(dict.keys()): ThO0AMm4jUGP9yr = round(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠵࠴࠵ࠤ")+float(dict[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨᷚ")])/Xr2aHOK0huQ5DTS(u"࠷࠰࠱࠲ࠥ"))
		else: ThO0AMm4jUGP9yr = DDHwpETQrAm0xMNXGfyhqsUi(u"࠭࠰ࠨᷛ")
		if DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨᷜ") not in list(dict.keys()): yQ0ebFuxaJkWsPS = dict[mpusoZBJ6V(u"ࠨࡵ࡬ࡾࡪ࠭ᷝ")].split(Fg72JX6T5DkPy(u"ࠩࡻࠫᷞ"))[nfC2im3NzUQk]
		else: yQ0ebFuxaJkWsPS = dict[FF70emVxhWOngCty(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫᷟ")]
		if Fg72JX6T5DkPy(u"ࠫ࡮ࡴࡩࡵࠩᷠ") not in list(dict.keys()): dict[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬ࡯࡮ࡪࡶࠪᷡ")] = OOhnpQ8XvCVclGqdu(u"࠭࠰࠮࠲ࠪᷢ")
		dict[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡵ࡫ࡷࡰࡪ࠭ᷣ")] = sM0mej2fYOFP7AHlnyDNJq63o+y5yX4jh6kUEgWZQIc(u"ࠨ࠼ࠣࠤࠬᷤ")+wQEM6IzJ3D2RX0p+XWbHfI9B8swrOL(u"ࠩࠣࠤ࠭࠭ᷥ")+BDbAWq6y1EMwhHPik+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪ࠰ࠬᷦ")+dict[mpusoZBJ6V(u"ࠫ࡮ࡺࡡࡨࠩᷧ")]+K7bLVaiRkx0lgU5SQM(u"ࠬ࠯ࠧᷨ")
		dict[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧᷩ")] = wQEM6IzJ3D2RX0p.split(eZXCHufT9YW4bRErSBOLmI)[h17Zb2ld4yLBrCP5tiw].split(svULcgJ7jm(u"ࠧ࡬ࡤࡳࡷࠬᷪ"))[h17Zb2ld4yLBrCP5tiw]
		dict[FF70emVxhWOngCty(u"ࠨࡶࡼࡴࡪ࠸ࠧᷫ")] = sM0mej2fYOFP7AHlnyDNJq63o
		dict[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫᷬ")] = ain78FlYBCWD31qLKEgT2bvIy
		dict[O4ylJvVNwLztdiHqBWDU(u"ࠪࡧࡴࡪࡥࡤࡵࠪᷭ")] = jj0598HRyNM6mcQUp
		dict[mpusoZBJ6V(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ᷮ")] = ThO0AMm4jUGP9yr
		dict[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ᷯ")] = yQ0ebFuxaJkWsPS
		GbuVNlxqtmkrOE0QLniPhdpRHU.append(dict)
	cF8W4PpOVjzUhS7oqHNa9YBsdL,TK5GzeftvowFY,lop2H38GQnZy,UglHeVCW4z5JEy,W3WFats85x6JIYZhmuA = [],[],[],[],[]
	KKhVCde9AQISF,eHJYCqSWAb,rjnLHXGx3wy9I,ALMyumHOQ1fxbXg9NoqrnpdDV4G7J,WTHsjp9MfRD58oLJIEa = [],[],[],[],[]
	if Cz91VYbFNUWIRKhdo3SpijDQr6GkP:
		dict = {}
		dict[pTwKPmzMSZhil5d2RWonre(u"࠭ࡴࡺࡲࡨ࠶ࠬᷰ")] = vZL6j4tSClIGxzNE5DX(u"ࠧࡂ࡙࠭ࠫᷱ")
		dict[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪᷲ")] = JJu4MPClbTFpUwHiN(u"ࠩࡰࡴࡩ࠭ᷳ")
		dict[FF70emVxhWOngCty(u"ࠪࡸ࡮ࡺ࡬ࡦࠩᷴ")] = dict[bDt7Ya1VEio3(u"ࠫࡹࡿࡰࡦ࠴ࠪ᷵")]+vZL6j4tSClIGxzNE5DX(u"ࠬࡀࠠࠡࠩ᷶")+dict[bDt7Ya1VEio3(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ᷷")]+eZXCHufT9YW4bRErSBOLmI+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧอ๊าอࠥึใ๋ห᷸ࠪ")
		dict[OTRKI6LbrQnZEm(u"ࠨࡷࡵࡰ᷹ࠬ")] = Cz91VYbFNUWIRKhdo3SpijDQr6GkP
		dict[s0vAWcLSXEToH9Mik134q(u"ࠩࡴࡹࡦࡲࡩࡵࡻ᷺ࠪ")] = JJu4MPClbTFpUwHiN(u"ࠪ࠴ࠬ᷻")
		dict[K7bLVaiRkx0lgU5SQM(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ᷼")] = bDt7Ya1VEio3(u"ࠬ࠿࠸࠸࠸࠸࠸࠸࠸࠱࠱᷽ࠩ")
		GbuVNlxqtmkrOE0QLniPhdpRHU.append(dict)
	if KagPt5Af6b47U38w:
		BkKyq6tfJldMGcTZr8WIDwouCP,NTpQsJIxWYotw5jnUkqC6Ez = HHSM1J4ofulwIPqTjnQA(KagPt5Af6b47U38w)
		MdpAeFQO9UqILRjNy6 = list(zip(BkKyq6tfJldMGcTZr8WIDwouCP,NTpQsJIxWYotw5jnUkqC6Ez))
		for title,RMC6c2kL5hGOnFaIwAyb in MdpAeFQO9UqILRjNy6:
			dict = {}
			dict[v54ZuLY6dQ(u"࠭ࡴࡺࡲࡨ࠶ࠬ᷾")] = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡂ࡙᷿࠭ࠫ")
			dict[Fg72JX6T5DkPy(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪḀ")] = JJu4MPClbTFpUwHiN(u"ࠩࡰ࠷ࡺ࠾ࠧḁ")
			dict[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡹࡷࡲࠧḂ")] = RMC6c2kL5hGOnFaIwAyb
			if svULcgJ7jm(u"ࠫࡰࡨࡰࡴࠩḃ") in title: dict[mpusoZBJ6V(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭Ḅ")] = title.split(DDHwpETQrAm0xMNXGfyhqsUi(u"࠭࡫ࡣࡲࡶࠫḅ"))[h17Zb2ld4yLBrCP5tiw].rsplit(eZXCHufT9YW4bRErSBOLmI)[-JJu4MPClbTFpUwHiN(u"࠱ࠦ")]
			else: dict[OTRKI6LbrQnZEm(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨḆ")] = tg9l25NH6WTacVSifLyAmY(u"ࠨ࠳࠳ࠫḇ")
			if title.count(eZXCHufT9YW4bRErSBOLmI)>y5yX4jh6kUEgWZQIc(u"࠲ࠧ"):
				oI6LvXMf4VEPe8jOdpKC0hUmS = title.rsplit(eZXCHufT9YW4bRErSBOLmI)[-K7bLVaiRkx0lgU5SQM(u"࠵ࠨ")]
				if oI6LvXMf4VEPe8jOdpKC0hUmS.isdigit(): dict[K7bLVaiRkx0lgU5SQM(u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪḈ")] = oI6LvXMf4VEPe8jOdpKC0hUmS
				else: dict[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫḉ")] = VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫ࠵࠶࠰࠱ࠩḊ")
			if title==fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬ࠳࠱ࠨḋ"): dict[TCF8wLyDvgumfiXPSKRh(u"࠭ࡴࡪࡶ࡯ࡩࠬḌ")] = dict[bDt7Ya1VEio3(u"ࠧࡵࡻࡳࡩ࠷࠭ḍ")]+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨ࠼ࠣࠤࠬḎ")+dict[Fg72JX6T5DkPy(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫḏ")]+eZXCHufT9YW4bRErSBOLmI+y5yX4jh6kUEgWZQIc(u"ࠪะํีษࠡาๆ๎ฮ࠭Ḑ")
			else: dict[OTRKI6LbrQnZEm(u"ࠫࡹ࡯ࡴ࡭ࡧࠪḑ")] = dict[XWbHfI9B8swrOL(u"ࠬࡺࡹࡱࡧ࠵ࠫḒ")]+VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࠺ࠡࠢࠪḓ")+dict[g4UCaNkHvLwGhjmW(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩḔ")]+eZXCHufT9YW4bRErSBOLmI+dict[mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩḕ")]+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩḖ")+dict[XWbHfI9B8swrOL(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫḗ")]
			GbuVNlxqtmkrOE0QLniPhdpRHU.append(dict)
	GbuVNlxqtmkrOE0QLniPhdpRHU = sorted(GbuVNlxqtmkrOE0QLniPhdpRHU,reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,key=lambda key: float(key[FF70emVxhWOngCty(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬḘ")]))
	if not GbuVNlxqtmkrOE0QLniPhdpRHU:
		ZZ1G8ui05FrMvbkC = sBvufaD6c9YHdOqTjCQ3.findall(tOrSvd8QKNB(u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨḙ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		p9YD6iyZOzKubQgFMh3X = sBvufaD6c9YHdOqTjCQ3.findall(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࠢࡱ࡮ࡤࡽࡪࡸࡅࡳࡴࡲࡶࡒ࡫ࡳࡴࡣࡪࡩࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡷࡺࡨࡲࡦࡣࡶࡳࡳࠨ࠺࡝ࡽࠥࡶࡺࡴࡳࠣ࠼࡟࡟ࡡࢁࠢࡵࡧࡻࡸࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨḚ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		uCyjMoXJUOq6eVP = sBvufaD6c9YHdOqTjCQ3.findall(K7bLVaiRkx0lgU5SQM(u"ࠧࠣࡲ࡯ࡥࡾ࡫ࡲࡆࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠢ࠻࡞ࡾࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ḛ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		S0ZwbUTgNQzXtM7OEJR1hDC8n2F = sBvufaD6c9YHdOqTjCQ3.findall(Fg72JX6T5DkPy(u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪḜ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		try: mmSXEfeMr8nG7s9j = SHmM7V9pyvrjNgftxLaQhUCbqoJE[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭ḝ")][mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨḞ")][XWbHfI9B8swrOL(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬḟ")][mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡺࡩࡵ࡮ࡨࠫḠ")][NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ࡲࡶࡰࡶࠫḡ")][h17Zb2ld4yLBrCP5tiw][DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧࡵࡧࡻࡸࡹ࠭Ḣ")]
		except: mmSXEfeMr8nG7s9j = QigevCplXxbPI1H
		try: VT3DWmtrq1sgQRI = SHmM7V9pyvrjNgftxLaQhUCbqoJE[Fg72JX6T5DkPy(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬḣ")][s0vAWcLSXEToH9Mik134q(u"ࠩࡨࡶࡷࡵࡲࡔࡥࡵࡩࡪࡴࠧḤ")][s0vAWcLSXEToH9Mik134q(u"ࠪࡧࡴࡴࡦࡪࡴࡰࡈ࡮ࡧ࡬ࡰࡩࡕࡩࡳࡪࡥࡳࡧࡵࠫḥ")][tOrSvd8QKNB(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡑࡪࡹࡳࡢࡩࡨࡷࠬḦ")][h17Zb2ld4yLBrCP5tiw][WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡸࡵ࡯ࡵࠪḧ")][h17Zb2ld4yLBrCP5tiw][hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡴࡦࡺࡷࡸࠬḨ")]
		except: VT3DWmtrq1sgQRI = QigevCplXxbPI1H
		try: G4K290WjbOsaMHoXLwzPBx56TUg = SHmM7V9pyvrjNgftxLaQhUCbqoJE[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࡱ࡮ࡤࡽࡦࡨࡩ࡭࡫ࡷࡽࡘࡺࡡࡵࡷࡶࠫḩ")][mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡴࡨࡥࡸࡵ࡮ࠨḪ")]
		except: G4K290WjbOsaMHoXLwzPBx56TUg = QigevCplXxbPI1H
		if ZZ1G8ui05FrMvbkC or p9YD6iyZOzKubQgFMh3X or uCyjMoXJUOq6eVP or S0ZwbUTgNQzXtM7OEJR1hDC8n2F or mmSXEfeMr8nG7s9j or VT3DWmtrq1sgQRI or G4K290WjbOsaMHoXLwzPBx56TUg:
			if   ZZ1G8ui05FrMvbkC: nDRKguWex0iVN8 = ZZ1G8ui05FrMvbkC[h17Zb2ld4yLBrCP5tiw]
			elif p9YD6iyZOzKubQgFMh3X: nDRKguWex0iVN8 = p9YD6iyZOzKubQgFMh3X[h17Zb2ld4yLBrCP5tiw]
			elif uCyjMoXJUOq6eVP: nDRKguWex0iVN8 = uCyjMoXJUOq6eVP[h17Zb2ld4yLBrCP5tiw]
			elif S0ZwbUTgNQzXtM7OEJR1hDC8n2F: nDRKguWex0iVN8 = S0ZwbUTgNQzXtM7OEJR1hDC8n2F[h17Zb2ld4yLBrCP5tiw]
			elif mmSXEfeMr8nG7s9j: nDRKguWex0iVN8 = mmSXEfeMr8nG7s9j
			elif VT3DWmtrq1sgQRI: nDRKguWex0iVN8 = VT3DWmtrq1sgQRI
			elif G4K290WjbOsaMHoXLwzPBx56TUg: nDRKguWex0iVN8 = G4K290WjbOsaMHoXLwzPBx56TUg
			VHhP3Jy6ucInRg4te2p = nDRKguWex0iVN8.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			gabMFEp9mvr3KxOPAutsT5JSc4oL7 = iVCLpNIM8BQs9PdSgKZvlFeo3a5+Xr2aHOK0huQ5DTS(u"๊ࠩิฬࠦวๅใํำ๏๎ࠠโ์๊ࠤฺ๊ใๅหࠣ์็ี๋ࠠๅ๋๊ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣวํฺ๋ࠦำ้ࠣฯ๎แาࠢส่ว์ࠧḫ")+jhAlCQ47ZgG
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥ๎วๅ็หี๊าࠧḬ"),gabMFEp9mvr3KxOPAutsT5JSc4oL7+mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࡡࡴ࡜࡯ࠩḭ")+VHhP3Jy6ucInRg4te2p)
			return OOhnpQ8XvCVclGqdu(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠧḮ")+VHhP3Jy6ucInRg4te2p,[],[]
		else: return mpusoZBJ6V(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭ḯ"),[],[]
	ut5gbBYJSRlkqPLTds1GFQVxy8X,phlE7KTq8NML,uuyNhUzcKA72RdWCHnqx = [],[],[]
	for dict in GbuVNlxqtmkrOE0QLniPhdpRHU:
		if dict[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡵࡻࡳࡩ࠷࠭Ḱ")]==bDt7Ya1VEio3(u"ࠨࡘ࡬ࡨࡪࡵࠧḱ"):
			cF8W4PpOVjzUhS7oqHNa9YBsdL.append(dict[tOrSvd8QKNB(u"ࠩࡷ࡭ࡹࡲࡥࠨḲ")])
			KKhVCde9AQISF.append(dict)
		elif dict[DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠪࡸࡾࡶࡥ࠳ࠩḳ")]==aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡆࡻࡤࡪࡱࠪḴ"):
			TK5GzeftvowFY.append(dict[svULcgJ7jm(u"ࠬࡺࡩࡵ࡮ࡨࠫḵ")])
			eHJYCqSWAb.append(dict)
		elif dict[pGncXOodjKhJzLSqVP1r(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨḶ")]==VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧ࡮ࡲࡧࠫḷ"):
			title = dict[JJu4MPClbTFpUwHiN(u"ࠨࡶ࡬ࡸࡱ࡫ࠧḸ")].replace(FF70emVxhWOngCty(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩḹ"),QigevCplXxbPI1H)
			if tOrSvd8QKNB(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫḺ") not in list(dict.keys()): yQ0ebFuxaJkWsPS = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫ࠵࠭ḻ")
			else: yQ0ebFuxaJkWsPS = dict[K7bLVaiRkx0lgU5SQM(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭Ḽ")]
			ut5gbBYJSRlkqPLTds1GFQVxy8X.append([dict,{},title,yQ0ebFuxaJkWsPS])
		else:
			title = dict[v54ZuLY6dQ(u"࠭ࡴࡪࡶ࡯ࡩࠬḽ")].replace(svULcgJ7jm(u"ࠧࡂ࡙࠭࠾ࠥࠦࠧḾ"),QigevCplXxbPI1H)
			if g4UCaNkHvLwGhjmW(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩḿ") not in list(dict.keys()): yQ0ebFuxaJkWsPS = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩ࠳ࠫṀ")
			else: yQ0ebFuxaJkWsPS = dict[pGncXOodjKhJzLSqVP1r(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫṁ")]
			ut5gbBYJSRlkqPLTds1GFQVxy8X.append([dict,{},title,yQ0ebFuxaJkWsPS])
			lop2H38GQnZy.append(title)
			rjnLHXGx3wy9I.append(dict)
		KkCPWSAO2JbFu = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		if OOhnpQ8XvCVclGqdu(u"ࠫࡨࡵࡤࡦࡥࡶࠫṂ") in list(dict.keys()):
			if VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡧࡶ࠱ࠩṃ") in dict[OTRKI6LbrQnZEm(u"࠭ࡣࡰࡦࡨࡧࡸ࠭Ṅ")]: KkCPWSAO2JbFu = YoAMfqm37GyFxbuKTt6e8CESHrhB
			elif aybmzWnDkuEcT3jpJClB2<XWbHfI9B8swrOL(u"࠴࠼ࠩ"):
				if vZL6j4tSClIGxzNE5DX(u"ࠧࡢࡸࡦࠫṅ") not in dict[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡥࡲࡨࡪࡩࡳࠨṆ")] and NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡰࡴ࠹ࡧࠧṇ") not in dict[XWbHfI9B8swrOL(u"ࠪࡧࡴࡪࡥࡤࡵࠪṈ")]: KkCPWSAO2JbFu = YoAMfqm37GyFxbuKTt6e8CESHrhB
		if dict[Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡹࡿࡰࡦ࠴ࠪṉ")]==OOhnpQ8XvCVclGqdu(u"ࠬ࡜ࡩࡥࡧࡲࠫṊ") and dict[fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡩ࡯࡫ࡷࠫṋ")]!=tOrSvd8QKNB(u"ࠧ࠱࠯࠳ࠫṌ") and KkCPWSAO2JbFu==XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
			W3WFats85x6JIYZhmuA.append(dict[K7bLVaiRkx0lgU5SQM(u"ࠨࡶ࡬ࡸࡱ࡫ࠧṍ")])
			WTHsjp9MfRD58oLJIEa.append(dict)
		elif dict[OTRKI6LbrQnZEm(u"ࠩࡷࡽࡵ࡫࠲ࠨṎ")]==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡅࡺࡪࡩࡰࠩṏ") and dict[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫ࡮ࡴࡩࡵࠩṐ")]!=tOrSvd8QKNB(u"ࠬ࠶࠭࠱ࠩṑ") and KkCPWSAO2JbFu==XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
			UglHeVCW4z5JEy.append(dict[tg9l25NH6WTacVSifLyAmY(u"࠭ࡴࡪࡶ࡯ࡩࠬṒ")])
			ALMyumHOQ1fxbXg9NoqrnpdDV4G7J.append(dict)
	for Rda0wMBKDk in ALMyumHOQ1fxbXg9NoqrnpdDV4G7J:
		Ya2B6Fk9OHNXQVrgfy4 = Rda0wMBKDk[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨṓ")]
		for yJ5oixVORFN9lC03MfUH in WTHsjp9MfRD58oLJIEa:
			EI7TnDLQxWuas61mMN = yJ5oixVORFN9lC03MfUH[OOhnpQ8XvCVclGqdu(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩṔ")]
			yQ0ebFuxaJkWsPS = EI7TnDLQxWuas61mMN+Ya2B6Fk9OHNXQVrgfy4
			title = yJ5oixVORFN9lC03MfUH[s0vAWcLSXEToH9Mik134q(u"ࠩࡷ࡭ࡹࡲࡥࠨṕ")].replace(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࡚ࠪ࡮ࡪࡥࡰ࠼ࠣࠤࠬṖ"),Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡲࡶࡤࠡࠢࠪṗ"))
			title = title.replace(yJ5oixVORFN9lC03MfUH[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧṘ")]+eZXCHufT9YW4bRErSBOLmI,QigevCplXxbPI1H)
			title = title.replace(str((float(EI7TnDLQxWuas61mMN*Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠵ࠪ"))//WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠶࠶࠲࠵ࠫ")/Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠵ࠪ")))+pTwKPmzMSZhil5d2RWonre(u"࠭࡫ࡣࡲࡶࠫṙ"),str((float(yQ0ebFuxaJkWsPS*Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠵ࠪ"))//WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠶࠶࠲࠵ࠫ")/Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠵ࠪ")))+bDt7Ya1VEio3(u"ࠧ࡬ࡤࡳࡷࠬṚ"))
			title = title+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨࠪࠪṛ")+Rda0wMBKDk[vZL6j4tSClIGxzNE5DX(u"ࠩࡷ࡭ࡹࡲࡥࠨṜ")].split(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࠬࠬṝ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠷ࠬ"))[nfC2im3NzUQk]
			ut5gbBYJSRlkqPLTds1GFQVxy8X.append([yJ5oixVORFN9lC03MfUH,Rda0wMBKDk,title,yQ0ebFuxaJkWsPS])
	ut5gbBYJSRlkqPLTds1GFQVxy8X = sorted(ut5gbBYJSRlkqPLTds1GFQVxy8X, reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD, key=lambda key: float(key[mVjHAyIwzSNKLFcd]))
	for yJ5oixVORFN9lC03MfUH,Rda0wMBKDk,title,yQ0ebFuxaJkWsPS in ut5gbBYJSRlkqPLTds1GFQVxy8X:
		OOWhXcArVwo5Dq6J = yJ5oixVORFN9lC03MfUH[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭Ṟ")]
		if Xr2aHOK0huQ5DTS(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧṟ") in list(Rda0wMBKDk.keys()):
			OOWhXcArVwo5Dq6J = s0vAWcLSXEToH9Mik134q(u"࠭࡭ࡱࡦࠪṠ")
		if OOWhXcArVwo5Dq6J not in uuyNhUzcKA72RdWCHnqx:
			uuyNhUzcKA72RdWCHnqx.append(OOWhXcArVwo5Dq6J)
			phlE7KTq8NML.append([yJ5oixVORFN9lC03MfUH,Rda0wMBKDk,title,yQ0ebFuxaJkWsPS])
	dVqXTofylFgHA98U,Vtvw6l1xhBs2EGaNb,eeiA67ImNfHlGvBCYxEphzJ3 = [],[],DDHwpETQrAm0xMNXGfyhqsUi(u"࠰࠭")
	JS9FNeq3Azjv6Kx8,NfFKlaRhtyusSkGCJo17Iq = QigevCplXxbPI1H,QigevCplXxbPI1H
	try: JS9FNeq3Azjv6Kx8 = SHmM7V9pyvrjNgftxLaQhUCbqoJE[Xr2aHOK0huQ5DTS(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ṡ")][bDt7Ya1VEio3(u"ࠨࡣࡸࡸ࡭ࡵࡲࠨṢ")]
	except: JS9FNeq3Azjv6Kx8 = QigevCplXxbPI1H
	try: lfAWK2uFxJU3GMZIPizwkh9geTt = SHmM7V9pyvrjNgftxLaQhUCbqoJE[s0vAWcLSXEToH9Mik134q(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨṣ")][NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩ࠭Ṥ")]
	except: lfAWK2uFxJU3GMZIPizwkh9geTt = QigevCplXxbPI1H
	if JS9FNeq3Azjv6Kx8 and lfAWK2uFxJU3GMZIPizwkh9geTt:
		eeiA67ImNfHlGvBCYxEphzJ3 += vZL6j4tSClIGxzNE5DX(u"࠲࠮")
		title = iVCLpNIM8BQs9PdSgKZvlFeo3a5+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ṥ")+JS9FNeq3Azjv6Kx8+jhAlCQ47ZgG
		RMC6c2kL5hGOnFaIwAyb = OQv0iWIw5bFRATU2mxJjZK[pGncXOodjKhJzLSqVP1r(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭Ṧ")][h17Zb2ld4yLBrCP5tiw]+s0vAWcLSXEToH9Mik134q(u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩṧ")+lfAWK2uFxJU3GMZIPizwkh9geTt
		dVqXTofylFgHA98U.append(title)
		Vtvw6l1xhBs2EGaNb.append(RMC6c2kL5hGOnFaIwAyb)
		try: NfFKlaRhtyusSkGCJo17Iq = SHmM7V9pyvrjNgftxLaQhUCbqoJE[fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭Ṩ")][XWbHfI9B8swrOL(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫṩ")][TCF8wLyDvgumfiXPSKRh(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭Ṫ")][-OOhnpQ8XvCVclGqdu(u"࠳࠯")][tOrSvd8QKNB(u"ࠪࡹࡷࡲࠧṫ")]
		except: pass
	for yJ5oixVORFN9lC03MfUH,Rda0wMBKDk,title,yQ0ebFuxaJkWsPS in phlE7KTq8NML:
		dVqXTofylFgHA98U.append(title) ; Vtvw6l1xhBs2EGaNb.append(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬṬ"))
	if lop2H38GQnZy: dVqXTofylFgHA98U.append(OTRKI6LbrQnZEm(u"ࠬ฻่าหࠣ์ฺ๎สࠡ็ะำิฯࠧṭ")) ; Vtvw6l1xhBs2EGaNb.append(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭࡭ࡶࡺࡨࡨࠬṮ"))
	if ut5gbBYJSRlkqPLTds1GFQVxy8X: dVqXTofylFgHA98U.append(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧึ๊ิอࠥ๎ี้ฬࠣห้๋ส้ใิࠫṯ")) ; Vtvw6l1xhBs2EGaNb.append(FF70emVxhWOngCty(u"ࠨࡣ࡯ࡰࠬṰ"))
	if W3WFats85x6JIYZhmuA: dVqXTofylFgHA98U.append(svULcgJ7jm(u"ࠩࡰࡴࡩࠦวฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫṱ")) ; Vtvw6l1xhBs2EGaNb.append(XWbHfI9B8swrOL(u"ࠪࡱࡵࡪࠧṲ"))
	if cF8W4PpOVjzUhS7oqHNa9YBsdL: dVqXTofylFgHA98U.append(pTwKPmzMSZhil5d2RWonre(u"ฺࠫ๎ัสࠢหำํ์ࠠึ๊อࠫṳ")) ; Vtvw6l1xhBs2EGaNb.append(pGncXOodjKhJzLSqVP1r(u"ࠬࡼࡩࡥࡧࡲࠫṴ"))
	if TK5GzeftvowFY: dVqXTofylFgHA98U.append(FF70emVxhWOngCty(u"࠭ี้ฬࠣฬิ๎ๆࠡื๋ีฮ࠭ṵ")) ; Vtvw6l1xhBs2EGaNb.append(vZL6j4tSClIGxzNE5DX(u"ࠧࡢࡷࡧ࡭ࡴ࠭Ṷ"))
	arUfuDhF2WkysTEnqLwoA4Jjv76 = YoAMfqm37GyFxbuKTt6e8CESHrhB
	while XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
		HHZ6579kAv8 = zYWJO03iISD(mbUgTzOcZWXJx6aC9E, dVqXTofylFgHA98U)
		if HHZ6579kAv8==-hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠴࠰"): return DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ṷ"),[],[]
		elif HHZ6579kAv8==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠴࠱") and JS9FNeq3Azjv6Kx8:
			RMC6c2kL5hGOnFaIwAyb = Vtvw6l1xhBs2EGaNb[HHZ6579kAv8]
			ZxMLFtnDSoCH714 = KXhrv29CGR8QTDzJIWLY.argv[h17Zb2ld4yLBrCP5tiw]+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠩࡂࡸࡾࡶࡥ࠾ࡨࡲࡰࡩ࡫ࡲࠧ࡯ࡲࡨࡪࡃ࠱࠵࠳ࠩࡲࡦࡳࡥ࠾ࠩṸ")+sqXK91rDldVAEcRTSQL4n2tbC(JS9FNeq3Azjv6Kx8)+g4UCaNkHvLwGhjmW(u"ࠪࠪࡺࡸ࡬࠾ࠩṹ")+RMC6c2kL5hGOnFaIwAyb
			if NfFKlaRhtyusSkGCJo17Iq: ZxMLFtnDSoCH714 = ZxMLFtnDSoCH714+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࠫ࡯࡭ࡢࡩࡨࡁࠬṺ")+sqXK91rDldVAEcRTSQL4n2tbC(NfFKlaRhtyusSkGCJo17Iq)
			qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(tg9l25NH6WTacVSifLyAmY(u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤṻ")+ZxMLFtnDSoCH714+XWbHfI9B8swrOL(u"ࠨࠩࠣṼ"))
			return OTRKI6LbrQnZEm(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬṽ"),[],[]
		BBt5dqgsIEbFNDCioAl = Vtvw6l1xhBs2EGaNb[HHZ6579kAv8]
		OIai182FRZxJW = dVqXTofylFgHA98U[HHZ6579kAv8]
		if BBt5dqgsIEbFNDCioAl==Fg72JX6T5DkPy(u"ࠨࡦࡤࡷ࡭࠭Ṿ"):
			c9OuYl7fZ6FPXSe34 = Cz91VYbFNUWIRKhdo3SpijDQr6GkP
			break
		elif BBt5dqgsIEbFNDCioAl in [pGncXOodjKhJzLSqVP1r(u"ࠩࡤࡹࡩ࡯࡯ࠨṿ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡺ࡮ࡪࡥࡰࠩẀ"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡲࡻࡸࡦࡦࠪẁ")]:
			if BBt5dqgsIEbFNDCioAl==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬࡳࡵࡹࡧࡧࠫẂ"): ttGBwQOv3K41hIkc6,YCZoDPMESG1h3g2Nq5QlH0rRu9aXW = lop2H38GQnZy,rjnLHXGx3wy9I
			elif BBt5dqgsIEbFNDCioAl==s0vAWcLSXEToH9Mik134q(u"࠭ࡶࡪࡦࡨࡳࠬẃ"): ttGBwQOv3K41hIkc6,YCZoDPMESG1h3g2Nq5QlH0rRu9aXW = cF8W4PpOVjzUhS7oqHNa9YBsdL,KKhVCde9AQISF
			elif BBt5dqgsIEbFNDCioAl==vZL6j4tSClIGxzNE5DX(u"ࠧࡢࡷࡧ࡭ࡴ࠭Ẅ"): ttGBwQOv3K41hIkc6,YCZoDPMESG1h3g2Nq5QlH0rRu9aXW = TK5GzeftvowFY,eHJYCqSWAb
			HHZ6579kAv8 = zYWJO03iISD(tg9l25NH6WTacVSifLyAmY(u"ࠨษัฮึࠦวๅ็็ๅࠥ࠮ࠧẅ")+str(len(ttGBwQOv3K41hIkc6))+mmKqLr9RX0ACN384JMcsFHzd(u"้้ࠩࠣ็ࠩࠨẆ"), ttGBwQOv3K41hIkc6)
			if HHZ6579kAv8!=-Fg72JX6T5DkPy(u"࠶࠲"):
				c9OuYl7fZ6FPXSe34 = YCZoDPMESG1h3g2Nq5QlH0rRu9aXW[HHZ6579kAv8][JJu4MPClbTFpUwHiN(u"ࠪࡹࡷࡲࠧẇ")]
				OIai182FRZxJW = ttGBwQOv3K41hIkc6[HHZ6579kAv8]
				break
		elif BBt5dqgsIEbFNDCioAl==aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡲࡶࡤࠨẈ"):
			HHZ6579kAv8 = zYWJO03iISD(svULcgJ7jm(u"ࠬอฮหำࠣะํีษࠡษ็ูํืษࠡࠪࠪẉ")+str(len(W3WFats85x6JIYZhmuA))+DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠭ࠠๆๆไ࠭ࠬẊ"), W3WFats85x6JIYZhmuA)
			if HHZ6579kAv8!=-aqUlAdFto05NmG4Y6guEzTr8vK(u"࠷࠳"):
				OIai182FRZxJW = W3WFats85x6JIYZhmuA[HHZ6579kAv8]
				T32NVhoOCUlq0x5DLJyiaH4GAes9 = WTHsjp9MfRD58oLJIEa[HHZ6579kAv8]
				HHZ6579kAv8 = zYWJO03iISD(v54ZuLY6dQ(u"ࠧศะอีࠥา่ะหࠣห้฻่หࠢࠫࠫẋ")+str(len(UglHeVCW4z5JEy))+OTRKI6LbrQnZEm(u"ࠨ่่ࠢๆ࠯ࠧẌ"), UglHeVCW4z5JEy)
				if HHZ6579kAv8!=-tOrSvd8QKNB(u"࠱࠴"):
					OIai182FRZxJW += mmKqLr9RX0ACN384JMcsFHzd(u"ࠩࠣ࠯ࠥ࠭ẍ")+UglHeVCW4z5JEy[HHZ6579kAv8]
					qUNHiAfLbB5aVXuse1F78dtnIE = ALMyumHOQ1fxbXg9NoqrnpdDV4G7J[HHZ6579kAv8]
					arUfuDhF2WkysTEnqLwoA4Jjv76 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
					break
		elif BBt5dqgsIEbFNDCioAl==TCF8wLyDvgumfiXPSKRh(u"ࠪࡥࡱࡲࠧẎ"):
			Sihy6Z0mDJXvs4gRr2O9W1PVUENw,I4Aws0WRHv2KtOlJ9,KNbUZsjV2fcp7kEgxTmXLvd96tuC1,r8rLbcmYiIjhB = list(zip(*ut5gbBYJSRlkqPLTds1GFQVxy8X))
			HHZ6579kAv8 = zYWJO03iISD(bDt7Ya1VEio3(u"ࠫฬิสาࠢส่๊๊แࠡࠪࠪẏ")+str(len(KNbUZsjV2fcp7kEgxTmXLvd96tuC1))+pTwKPmzMSZhil5d2RWonre(u"ࠬࠦๅๅใࠬࠫẐ"), KNbUZsjV2fcp7kEgxTmXLvd96tuC1)
			if HHZ6579kAv8!=-s0vAWcLSXEToH9Mik134q(u"࠲࠵"):
				OIai182FRZxJW = KNbUZsjV2fcp7kEgxTmXLvd96tuC1[HHZ6579kAv8]
				T32NVhoOCUlq0x5DLJyiaH4GAes9 = Sihy6Z0mDJXvs4gRr2O9W1PVUENw[HHZ6579kAv8]
				if svULcgJ7jm(u"࠭࡭ࡱࡦࠪẑ") in KNbUZsjV2fcp7kEgxTmXLvd96tuC1[HHZ6579kAv8] and T32NVhoOCUlq0x5DLJyiaH4GAes9[tg9l25NH6WTacVSifLyAmY(u"ࠧࡶࡴ࡯ࠫẒ")]!=Cz91VYbFNUWIRKhdo3SpijDQr6GkP:
					qUNHiAfLbB5aVXuse1F78dtnIE = I4Aws0WRHv2KtOlJ9[HHZ6579kAv8]
					arUfuDhF2WkysTEnqLwoA4Jjv76 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
				else: c9OuYl7fZ6FPXSe34 = T32NVhoOCUlq0x5DLJyiaH4GAes9[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨࡷࡵࡰࠬẓ")]
				break
		elif BBt5dqgsIEbFNDCioAl==OOhnpQ8XvCVclGqdu(u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪẔ"):
			Sihy6Z0mDJXvs4gRr2O9W1PVUENw,I4Aws0WRHv2KtOlJ9,KNbUZsjV2fcp7kEgxTmXLvd96tuC1,r8rLbcmYiIjhB = list(zip(*phlE7KTq8NML))
			T32NVhoOCUlq0x5DLJyiaH4GAes9 = Sihy6Z0mDJXvs4gRr2O9W1PVUENw[HHZ6579kAv8-eeiA67ImNfHlGvBCYxEphzJ3]
			if tg9l25NH6WTacVSifLyAmY(u"ࠪࡱࡵࡪࠧẕ") in KNbUZsjV2fcp7kEgxTmXLvd96tuC1[HHZ6579kAv8-eeiA67ImNfHlGvBCYxEphzJ3] and T32NVhoOCUlq0x5DLJyiaH4GAes9[pGncXOodjKhJzLSqVP1r(u"ࠫࡺࡸ࡬ࠨẖ")]!=Cz91VYbFNUWIRKhdo3SpijDQr6GkP:
				qUNHiAfLbB5aVXuse1F78dtnIE = I4Aws0WRHv2KtOlJ9[HHZ6579kAv8-eeiA67ImNfHlGvBCYxEphzJ3]
				arUfuDhF2WkysTEnqLwoA4Jjv76 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			else: c9OuYl7fZ6FPXSe34 = T32NVhoOCUlq0x5DLJyiaH4GAes9[s0vAWcLSXEToH9Mik134q(u"ࠬࡻࡲ࡭ࠩẗ")]
			OIai182FRZxJW = KNbUZsjV2fcp7kEgxTmXLvd96tuC1[HHZ6579kAv8-eeiA67ImNfHlGvBCYxEphzJ3]
			break
	if not arUfuDhF2WkysTEnqLwoA4Jjv76: C0ChRW2TNEewsbZuXoQfm = c9OuYl7fZ6FPXSe34
	else: C0ChRW2TNEewsbZuXoQfm = pGncXOodjKhJzLSqVP1r(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠧẘ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[Fg72JX6T5DkPy(u"ࠧࡶࡴ࡯ࠫẙ")]+mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࠢ࠮ࠤࡆࡻࡤࡪࡱ࠽ࠤࠬẚ")+qUNHiAfLbB5aVXuse1F78dtnIE[s0vAWcLSXEToH9Mik134q(u"ࠩࡸࡶࡱ࠭ẛ")]
	if arUfuDhF2WkysTEnqLwoA4Jjv76:
		b0TsLZSd4tJ5QKyPNfIAR1anvE7x = int(T32NVhoOCUlq0x5DLJyiaH4GAes9[tg9l25NH6WTacVSifLyAmY(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬẜ")])
		Q6UTIzrF9N7Vg = int(qUNHiAfLbB5aVXuse1F78dtnIE[svULcgJ7jm(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ẝ")])
		ThO0AMm4jUGP9yr = str(max(b0TsLZSd4tJ5QKyPNfIAR1anvE7x,Q6UTIzrF9N7Vg))
		CmklS7T9Bt1Y48X6cnPo = T32NVhoOCUlq0x5DLJyiaH4GAes9[mmKqLr9RX0ACN384JMcsFHzd(u"ࠬࡻࡲ࡭ࠩẞ")].replace(JJu4MPClbTFpUwHiN(u"࠭ࠦࠨẟ"),y5yX4jh6kUEgWZQIc(u"ࠧࠧࡣࡰࡴࡀ࠭Ạ"))
		sidgXUn254YkHLfQ = qUNHiAfLbB5aVXuse1F78dtnIE[XWbHfI9B8swrOL(u"ࠨࡷࡵࡰࠬạ")].replace(pTwKPmzMSZhil5d2RWonre(u"ࠩࠩࠫẢ"),s0vAWcLSXEToH9Mik134q(u"ࠪࠪࡦࡳࡰ࠼ࠩả"))
		mpd = tOrSvd8QKNB(u"ࠫࡁࡅࡸ࡮࡮ࠣࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠷࠮࠱ࠤࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࡂࠨࡕࡕࡈ࠰࠼ࠧࡅ࠾࡝ࡰࠪẤ")
		mpd += s0vAWcLSXEToH9Mik134q(u"ࠬࡂࡍࡑࡆࠣࡼࡲࡲ࡮ࡴ࠼ࡻࡷ࡮ࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡼ࠹࠮ࡰࡴࡪ࠳࠷࠶࠰࠲࠱࡛ࡑࡑ࡙ࡣࡩࡧࡰࡥ࠲࡯࡮ࡴࡶࡤࡲࡨ࡫ࠢࠡࡺࡰࡰࡳࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡵࡦ࡬ࡪࡳࡡ࠻࡯ࡳࡨ࠿࠸࠰࠲࠳ࠥࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡱ࡯࡮࡬࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠲࠻࠼࠽࠴ࡾ࡬ࡪࡰ࡮ࠦࠥࡾࡳࡪ࠼ࡶࡧ࡭࡫࡭ࡢࡎࡲࡧࡦࡺࡩࡰࡰࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠦࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡱࡨࡦࡸࡤࡴ࠰࡬ࡷࡴ࠴࡯ࡳࡩ࠲࡭ࡹࡺࡦ࠰ࡒࡸࡦࡱ࡯ࡣ࡭ࡻࡄࡺࡦ࡯࡬ࡢࡤ࡯ࡩࡘࡺࡡ࡯ࡦࡤࡶࡩࡹ࠯ࡎࡒࡈࡋ࠲ࡊࡁࡔࡊࡢࡷࡨ࡮ࡥ࡮ࡣࡢࡪ࡮ࡲࡥࡴ࠱ࡇࡅࡘࡎ࠭ࡎࡒࡇ࠲ࡽࡹࡤࠣࠢࡰ࡭ࡳࡈࡵࡧࡨࡨࡶ࡙࡯࡭ࡦ࠿ࠥࡔ࡙࠷࠮࠶ࡕࠥࠤࡲ࡫ࡤࡪࡣࡓࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࡅࡷࡵࡥࡹ࡯࡯࡯࠿ࠥࡔ࡙࠭ấ")+ThO0AMm4jUGP9yr+pGncXOodjKhJzLSqVP1r(u"࠭ࡓࠣࠢࡷࡽࡵ࡫࠽ࠣࡵࡷࡥࡹ࡯ࡣࠣࠢࡳࡶࡴ࡬ࡩ࡭ࡧࡶࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡶࡲࡰࡨ࡬ࡰࡪࡀࡩࡴࡱࡩࡪ࠲ࡳࡡࡪࡰ࠽࠶࠵࠷࠱ࠣࡀ࡟ࡲࠬẦ")
		mpd += tOrSvd8QKNB(u"ࠧ࠽ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫầ")
		mpd += VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢ࡬ࡨࡂࠨ࠰ࠣࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡼࡩࡥࡧࡲ࠳ࠬẨ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[g4UCaNkHvLwGhjmW(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫẩ")]+y5yX4jh6kUEgWZQIc(u"ࠪࠦࠥࡹࡵࡣࡵࡨ࡫ࡲ࡫࡮ࡵࡃ࡯࡭࡬ࡴ࡭ࡦࡰࡷࡁ࡚ࠧࡲࡶࡧࠥࡂࡡࡴࠧẪ")
		mpd += O4ylJvVNwLztdiHqBWDU(u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩẫ")
		mpd += tOrSvd8QKNB(u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬẬ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࡩࡵࡣࡪࠫậ")]+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫẮ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡥࡲࡨࡪࡩࡳࠨắ")]+s0vAWcLSXEToH9Mik134q(u"ࠩࠥࠤࡸࡺࡡࡳࡶ࡚࡭ࡹ࡮ࡓࡂࡒࡀࠦ࠶ࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦࠬẰ")+str(T32NVhoOCUlq0x5DLJyiaH4GAes9[s0vAWcLSXEToH9Mik134q(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫằ")])+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫࠧࠦࡷࡪࡦࡷ࡬ࡂࠨࠧẲ")+str(T32NVhoOCUlq0x5DLJyiaH4GAes9[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠬࡽࡩࡥࡶ࡫ࠫẳ")])+DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࠢࠡࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠪẴ")+str(T32NVhoOCUlq0x5DLJyiaH4GAes9[pTwKPmzMSZhil5d2RWonre(u"ࠧࡩࡧ࡬࡫࡭ࡺࠧẵ")])+svULcgJ7jm(u"ࠨࠤࠣࡪࡷࡧ࡭ࡦࡔࡤࡸࡪࡃࠢࠨẶ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[pGncXOodjKhJzLSqVP1r(u"ࠩࡩࡴࡸ࠭ặ")]+v54ZuLY6dQ(u"ࠪࠦࡃࡢ࡮ࠨẸ")
		mpd += JJu4MPClbTFpUwHiN(u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧẹ")+CmklS7T9Bt1Y48X6cnPo+Xr2aHOK0huQ5DTS(u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫẺ")
		mpd += tOrSvd8QKNB(u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫẻ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࡪࡰࡧࡩࡽ࠭Ẽ")]+pTwKPmzMSZhil5d2RWonre(u"ࠨࠤࡁࡠࡳ࠭ẽ")
		mpd += NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬẾ")+T32NVhoOCUlq0x5DLJyiaH4GAes9[JJu4MPClbTFpUwHiN(u"ࠪ࡭ࡳ࡯ࡴࠨế")]+mpusoZBJ6V(u"ࠫࠧࠦ࠯࠿࡞ࡱࠫỀ")
		mpd += s0vAWcLSXEToH9Mik134q(u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨề")
		mpd += FF70emVxhWOngCty(u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬỂ")
		mpd += O4ylJvVNwLztdiHqBWDU(u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬể")
		mpd += mpusoZBJ6V(u"ࠨ࠾ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࠢ࡬ࡨࡂࠨ࠱ࠣࠢࡰ࡭ࡲ࡫ࡔࡺࡲࡨࡁࠧࡧࡵࡥ࡫ࡲ࠳ࠬỄ")+qUNHiAfLbB5aVXuse1F78dtnIE[XWbHfI9B8swrOL(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫễ")]+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࠦࠥࡹࡵࡣࡵࡨ࡫ࡲ࡫࡮ࡵࡃ࡯࡭࡬ࡴ࡭ࡦࡰࡷࡁ࡚ࠧࡲࡶࡧࠥࡂࡡࡴࠧỆ")
		mpd += g4UCaNkHvLwGhjmW(u"ࠫࡁࡘ࡯࡭ࡧࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡉࡇࡓࡉ࠼ࡵࡳࡱ࡫࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨ࡭ࡢ࡫ࡱࠦ࠴ࡄ࡜࡯ࠩệ")
		mpd += tOrSvd8QKNB(u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࠬỈ")+qUNHiAfLbB5aVXuse1F78dtnIE[DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࡩࡵࡣࡪࠫỉ")]+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࠣࠢࡦࡳࡩ࡫ࡣࡴ࠿ࠥࠫỊ")+qUNHiAfLbB5aVXuse1F78dtnIE[XWbHfI9B8swrOL(u"ࠨࡥࡲࡨࡪࡩࡳࠨị")]+g4UCaNkHvLwGhjmW(u"ࠩࠥࠤࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮࠽ࠣ࠳࠶࠴࠹࠽࠵ࠣࡀ࡟ࡲࠬỌ")
		mpd += s0vAWcLSXEToH9Mik134q(u"ࠪࡀࡆࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻࠴࠶࠴࠵࠹࠺࠴࠼ࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡡࡦࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯࠼࠵࠴࠶࠷ࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠩọ")+qUNHiAfLbB5aVXuse1F78dtnIE[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬỎ")]+tg9l25NH6WTacVSifLyAmY(u"ࠬࠨ࠯࠿࡞ࡱࠫỏ")
		mpd += OOhnpQ8XvCVclGqdu(u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩỐ")+sidgXUn254YkHLfQ+tOrSvd8QKNB(u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭ố")
		mpd += FF70emVxhWOngCty(u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭Ồ")+qUNHiAfLbB5aVXuse1F78dtnIE[FF70emVxhWOngCty(u"ࠩ࡬ࡲࡩ࡫ࡸࠨồ")]+tOrSvd8QKNB(u"ࠪࠦࡃࡢ࡮ࠨỔ")
		mpd += Xr2aHOK0huQ5DTS(u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧổ")+qUNHiAfLbB5aVXuse1F78dtnIE[aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬ࡯࡮ࡪࡶࠪỖ")]+DDHwpETQrAm0xMNXGfyhqsUi(u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭ỗ")
		mpd += mpusoZBJ6V(u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪỘ")
		mpd += svULcgJ7jm(u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧộ")
		mpd += JJu4MPClbTFpUwHiN(u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧỚ")
		mpd += VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࡀ࠴ࡖࡥࡳ࡫ࡲࡨࡃࡢ࡮ࠨớ")
		mpd += O4ylJvVNwLztdiHqBWDU(u"ࠫࡁ࠵ࡍࡑࡆࡁࡠࡳ࠭Ờ")
		if b7sJAmSxlBvaMdHFz:
			import http.server as ddRZoNKjr2Cl1iLG04zHc
			import http.client as i3a6KbvxWsJ9kyg
		else:
			import BaseHTTPServer as ddRZoNKjr2Cl1iLG04zHc
			import httplib as i3a6KbvxWsJ9kyg
		class ttTDflA86GvakzF5(ddRZoNKjr2Cl1iLG04zHc.HTTPServer):
			def __init__(exy8R6A9igVLkKa1vXd3,ip=QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨờ"),port=VvhRUZgko5Af1BIynMGOJSbpmK(u"࠷࠸࠴࠺࠻࠶"),mpd=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࠼࠿ࠩỞ")):
				exy8R6A9igVLkKa1vXd3.ip = ip
				exy8R6A9igVLkKa1vXd3.port = port
				exy8R6A9igVLkKa1vXd3.mpd = mpd
				ddRZoNKjr2Cl1iLG04zHc.HTTPServer.__init__(exy8R6A9igVLkKa1vXd3,(exy8R6A9igVLkKa1vXd3.ip,exy8R6A9igVLkKa1vXd3.port),Ujuk4diGI5Yas7VObRE9H3)
				exy8R6A9igVLkKa1vXd3.mpdurl = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨở")+ip+FF70emVxhWOngCty(u"ࠨ࠼ࠪỠ")+str(port)+mpusoZBJ6V(u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨỡ")
			def start(exy8R6A9igVLkKa1vXd3):
				exy8R6A9igVLkKa1vXd3.threads = UZ28903VuMoInShOjv4zpYDFxliy(YoAMfqm37GyFxbuKTt6e8CESHrhB)
				exy8R6A9igVLkKa1vXd3.threads.jxT7SROozva0I9(XWbHfI9B8swrOL(u"࠴࠷"),exy8R6A9igVLkKa1vXd3.sPIuAtX1oKnExR9UfmOVF8JHvYwMT)
			def sPIuAtX1oKnExR9UfmOVF8JHvYwMT(exy8R6A9igVLkKa1vXd3):
				exy8R6A9igVLkKa1vXd3.keeprunning = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
				while exy8R6A9igVLkKa1vXd3.keeprunning:
					exy8R6A9igVLkKa1vXd3.handle_request()
			def stop(exy8R6A9igVLkKa1vXd3):
				exy8R6A9igVLkKa1vXd3.keeprunning = YoAMfqm37GyFxbuKTt6e8CESHrhB
				exy8R6A9igVLkKa1vXd3.zzRxSsLQ0CENXoq8nH3GJ()
			def JhKyOEQgFr91NmLxVMjcdY(exy8R6A9igVLkKa1vXd3):
				exy8R6A9igVLkKa1vXd3.stop()
				exy8R6A9igVLkKa1vXd3.LXYK9GkF5MnA.close()
				exy8R6A9igVLkKa1vXd3.server_close()
			def kfxO2iH4XdJYtuz6r(exy8R6A9igVLkKa1vXd3,mpd):
				exy8R6A9igVLkKa1vXd3.mpd = mpd
			def zzRxSsLQ0CENXoq8nH3GJ(exy8R6A9igVLkKa1vXd3):
				R2wuKSVBTLW4sAOQNob18UEdGf0hv = i3a6KbvxWsJ9kyg.HTTPConnection(exy8R6A9igVLkKa1vXd3.ip+TCF8wLyDvgumfiXPSKRh(u"ࠪ࠾ࠬỢ")+str(exy8R6A9igVLkKa1vXd3.port))
				R2wuKSVBTLW4sAOQNob18UEdGf0hv.request(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠦࡍࡋࡁࡅࠤợ"), s0vAWcLSXEToH9Mik134q(u"ࠧ࠵ࠢỤ"))
		class Ujuk4diGI5Yas7VObRE9H3(ddRZoNKjr2Cl1iLG04zHc.BaseHTTPRequestHandler):
			def jPfhdYy3CwLRaFlJnAGTB(exy8R6A9igVLkKa1vXd3):
				exy8R6A9igVLkKa1vXd3.send_response(pGncXOodjKhJzLSqVP1r(u"࠶࠵࠶࠸"))
				exy8R6A9igVLkKa1vXd3.send_header(v54ZuLY6dQ(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬụ"),v54ZuLY6dQ(u"ࠧࡵࡧࡻࡸࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬỦ"))
				exy8R6A9igVLkKa1vXd3.end_headers()
				exy8R6A9igVLkKa1vXd3.wfile.write(exy8R6A9igVLkKa1vXd3.bSrdN78jxURTvh9.mpd.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL))
				B3TKLo71hAGRqYgV0.sleep(g4UCaNkHvLwGhjmW(u"࠶࠹"))
				if exy8R6A9igVLkKa1vXd3.path==fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧủ"): exy8R6A9igVLkKa1vXd3.bSrdN78jxURTvh9.JhKyOEQgFr91NmLxVMjcdY()
				if exy8R6A9igVLkKa1vXd3.path==s0vAWcLSXEToH9Mik134q(u"ࠩ࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬỨ"): exy8R6A9igVLkKa1vXd3.bSrdN78jxURTvh9.JhKyOEQgFr91NmLxVMjcdY()
			def LLgQnWPNd1Y(exy8R6A9igVLkKa1vXd3):
				exy8R6A9igVLkKa1vXd3.send_response(pTwKPmzMSZhil5d2RWonre(u"࠸࠰࠱࠺"))
				exy8R6A9igVLkKa1vXd3.end_headers()
		aigfcr5We4qGY9Bwz = ttTDflA86GvakzF5(pTwKPmzMSZhil5d2RWonre(u"ࠪ࠵࠷࠽࠮࠱࠰࠳࠲࠶࠭ứ"),Fg72JX6T5DkPy(u"࠵࠶࠲࠸࠹࠻"),mpd)
		c9OuYl7fZ6FPXSe34 = aigfcr5We4qGY9Bwz.mpdurl
		aigfcr5We4qGY9Bwz.start()
	else: aigfcr5We4qGY9Bwz = QigevCplXxbPI1H
	if not c9OuYl7fZ6FPXSe34: return OOhnpQ8XvCVclGqdu(u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫỪ"),[],[]
	return QigevCplXxbPI1H,[QigevCplXxbPI1H],[[c9OuYl7fZ6FPXSe34,MM6GJA5PupqZ43EWTFgQ07cbK,aigfcr5We4qGY9Bwz]]
def tS0iV5xjYlQJm1ynMrgFdAINb(url):
	headers = { WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩừ") : QigevCplXxbPI1H }
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡍࡉࡈࡏࡃ࠯࠴ࡷࡹ࠭Ử"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࡼࠪ࡞ࢀࠫử"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	items = set(items)
	items = sorted(items, reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD, key=lambda key: key[JxuTQLOD357o41evylqPmRdf])
	BkKyq6tfJldMGcTZr8WIDwouCP,ttGBwQOv3K41hIkc6,NTpQsJIxWYotw5jnUkqC6Ez,ldFqnNIsftrY43JBM6LPjzU8m = [],[],[],[]
	if not items: return y5yX4jh6kUEgWZQIc(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡂࡐࡄࠪỮ"),[],[]
	for RMC6c2kL5hGOnFaIwAyb,tX1WYGPmux,J4kSW2aUHYg6 in items:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩữ"),pGncXOodjKhJzLSqVP1r(u"ࠪ࡬ࡹࡺࡰ࠻ࠩỰ"))
		if bDt7Ya1VEio3(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪự") in RMC6c2kL5hGOnFaIwAyb:
			BkKyq6tfJldMGcTZr8WIDwouCP,NTpQsJIxWYotw5jnUkqC6Ez = HHSM1J4ofulwIPqTjnQA(RMC6c2kL5hGOnFaIwAyb)
			ldFqnNIsftrY43JBM6LPjzU8m = ldFqnNIsftrY43JBM6LPjzU8m + NTpQsJIxWYotw5jnUkqC6Ez
			if BkKyq6tfJldMGcTZr8WIDwouCP[h17Zb2ld4yLBrCP5tiw]==bDt7Ya1VEio3(u"ࠬ࠳࠱ࠨỲ"): ttGBwQOv3K41hIkc6.append(pGncXOodjKhJzLSqVP1r(u"࠭ำ๋ำไีࠥิวึࠩỳ")+g4UCaNkHvLwGhjmW(u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨỴ"))
			else:
				for title in BkKyq6tfJldMGcTZr8WIDwouCP:
					ttGBwQOv3K41hIkc6.append(tOrSvd8QKNB(u"ࠨีํีๆืࠠฯษุࠫỵ")+Ec4QJmyAo3G7Vp2X6SY8UifnOh+title)
		else:
			title = s0vAWcLSXEToH9Mik134q(u"ࠩึ๎ึ็ัࠡะสูࠬỶ")+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠣࠤࠥ࠭ỷ")+J4kSW2aUHYg6
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			ttGBwQOv3K41hIkc6.append(title)
	return QigevCplXxbPI1H,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
def nSTd2ALhNuXoys5eaKZ1JG4miRcf7D(url,aY63L2NhgvwJIxPAoDG4MKECmZXF1):
	xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6,YIua5gAX48COGexvtK,fW5M4LSmOYJBgyswb1T8,rsBojxT8UZwL = [],[],[],[],[]
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(OTRKI6LbrQnZEm(u"ࠫࡁࡼࡩࡥࡧࡲࠤࡵࡸࡥ࡭ࡱࡤࡨ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬỸ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb and not z2dZ1anR6O(RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]): RMC6c2kL5hGOnFaIwAyb = []
	if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫỹ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb and not z2dZ1anR6O(RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]): RMC6c2kL5hGOnFaIwAyb = []
	if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall(FF70emVxhWOngCty(u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬỺ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb and not z2dZ1anR6O(RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]): RMC6c2kL5hGOnFaIwAyb = []
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[h17Zb2ld4yLBrCP5tiw]
		title = RMC6c2kL5hGOnFaIwAyb.rsplit(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧ࠯ࠩỻ"),aqUlAdFto05NmG4Y6guEzTr8vK(u"࠲࠼"))[nfC2im3NzUQk]
		xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(title)
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
	else:
		mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠣ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧỼ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not mfFwcWZHXVGvyU3B0ILburCoh: mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall(g4UCaNkHvLwGhjmW(u"ࠩࡹࡥࡷࠦࡳࡰࡷࡵࡧࡪࡹࠠ࠾ࠢࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࠬỽ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not mfFwcWZHXVGvyU3B0ILburCoh: mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall(mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࡺࡦࡸࠠ࡫ࡹࠣࡁࠥ࠮࡜ࡼ࠰࠭ࡃࡡࢃࠩࠨỾ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not mfFwcWZHXVGvyU3B0ILburCoh: mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࡻࡧࡲࠡࡲ࡯ࡥࡾ࡫ࡲࠡ࠿ࠣ࠲࠯ࡅ࡜ࠩࠪ࡟ࡿ࠳࠰࠿࡝ࡿࠬࡠ࠮࠭ỿ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if mfFwcWZHXVGvyU3B0ILburCoh:
			mfFwcWZHXVGvyU3B0ILburCoh = mfFwcWZHXVGvyU3B0ILburCoh[h17Zb2ld4yLBrCP5tiw]
			mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.sub(tg9l25NH6WTacVSifLyAmY(u"ࡷ࠭ࠨ࡜࡞ࡾࡠ࠱ࡣ࡛࡝ࡶ࡟ࡷࡡࡴ࡜ࡳ࡟࠭࠭࠭ࡢࡷࠬ࡝࡟ࡸࡡࡹ࡝ࠫࠫ࠽ࠫἀ"),vZL6j4tSClIGxzNE5DX(u"ࡸࠧ࡝࠳ࠥࡠ࠷ࠨ࠺ࠨἁ"),mfFwcWZHXVGvyU3B0ILburCoh)
			mfFwcWZHXVGvyU3B0ILburCoh = CH86N7xw4cyPt3TlIBJF(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡥ࡫ࡦࡸࠬἂ"),mfFwcWZHXVGvyU3B0ILburCoh)
			if isinstance(mfFwcWZHXVGvyU3B0ILburCoh,dict): mfFwcWZHXVGvyU3B0ILburCoh = [mfFwcWZHXVGvyU3B0ILburCoh]
			for LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
				IIZ4pkrNMYacSUXGzdfWR,RMC6c2kL5hGOnFaIwAyb = QigevCplXxbPI1H,QigevCplXxbPI1H
				if isinstance(LKzFWsmvjUVGMDBapflx6H4NY,dict):
					keys = list(LKzFWsmvjUVGMDBapflx6H4NY.keys())
					if   bDt7Ya1VEio3(u"ࠨࡶࡼࡴࡪ࠭ἃ") in keys: IIZ4pkrNMYacSUXGzdfWR = str(LKzFWsmvjUVGMDBapflx6H4NY[svULcgJ7jm(u"ࠩࡷࡽࡵ࡫ࠧἄ")])
					if   FF70emVxhWOngCty(u"ࠪࡪ࡮ࡲࡥࠨἅ") in keys: RMC6c2kL5hGOnFaIwAyb = LKzFWsmvjUVGMDBapflx6H4NY[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࡫࡯࡬ࡦࠩἆ")]
					elif v54ZuLY6dQ(u"ࠬ࡮࡬ࡴࠩἇ") in keys: RMC6c2kL5hGOnFaIwAyb = LKzFWsmvjUVGMDBapflx6H4NY[s0vAWcLSXEToH9Mik134q(u"࠭ࡨ࡭ࡵࠪἈ")]
					elif s0vAWcLSXEToH9Mik134q(u"ࠧࡴࡴࡦࠫἉ") in keys: RMC6c2kL5hGOnFaIwAyb = LKzFWsmvjUVGMDBapflx6H4NY[mpusoZBJ6V(u"ࠨࡵࡵࡧࠬἊ")]
					if   g4UCaNkHvLwGhjmW(u"ࠩ࡯ࡥࡧ࡫࡬ࠨἋ") in keys: title = str(LKzFWsmvjUVGMDBapflx6H4NY[tOrSvd8QKNB(u"ࠪࡰࡦࡨࡥ࡭ࠩἌ")])
					elif s0vAWcLSXEToH9Mik134q(u"ࠫࡻ࡯ࡤࡦࡱࡢ࡬ࡪ࡯ࡧࡩࡶࠪἍ") in keys: title = str(LKzFWsmvjUVGMDBapflx6H4NY[K7bLVaiRkx0lgU5SQM(u"ࠬࡼࡩࡥࡧࡲࡣ࡭࡫ࡩࡨࡪࡷࠫἎ")])
					elif O4ylJvVNwLztdiHqBWDU(u"࠭࠮ࠨἏ") in RMC6c2kL5hGOnFaIwAyb: title = RMC6c2kL5hGOnFaIwAyb.rsplit(OOhnpQ8XvCVclGqdu(u"ࠧ࠯ࠩἐ"),g4UCaNkHvLwGhjmW(u"࠳࠽"))[nfC2im3NzUQk]
					else: title = RMC6c2kL5hGOnFaIwAyb
				elif isinstance(LKzFWsmvjUVGMDBapflx6H4NY,str):
					RMC6c2kL5hGOnFaIwAyb = LKzFWsmvjUVGMDBapflx6H4NY
					title = RMC6c2kL5hGOnFaIwAyb.rsplit(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࠰ࠪἑ"),g4UCaNkHvLwGhjmW(u"࠴࠾"))[nfC2im3NzUQk]
				if XWbHfI9B8swrOL(u"࠵࠿"):
					xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw.append(title+eZXCHufT9YW4bRErSBOLmI+IIZ4pkrNMYacSUXGzdfWR)
					vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
	for RMC6c2kL5hGOnFaIwAyb,title in zip(vdLczqkV5b48ZKyGxTE3jJi17aWS6,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw):
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(y5yX4jh6kUEgWZQIc(u"ࠩ࡟ࡠ࠴࠭ἒ"),OOhnpQ8XvCVclGqdu(u"ࠪ࠳ࠬἓ"))
		bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,JJu4MPClbTFpUwHiN(u"ࠫࡺࡸ࡬ࠨἔ"))
		lfPqTpgMXhVcd = eUBL1rOR4ZfndJAWPsoN6pybT0()
		if s0vAWcLSXEToH9Mik134q(u"ࠬ࡮ࡴࡵࡲࠪἕ") not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = bSrdN78jxURTvh9+RMC6c2kL5hGOnFaIwAyb
		if hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭࠮࡮࠵ࡸ࠼ࠬ἖") in RMC6c2kL5hGOnFaIwAyb:
			headers = {JJu4MPClbTFpUwHiN(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ἗"):lfPqTpgMXhVcd,mmKqLr9RX0ACN384JMcsFHzd(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩἘ"):bSrdN78jxURTvh9}
			qYNOZ4mvry1UufLEiaeSo,ggZFSwdO6mGfeilQ20 = HHSM1J4ofulwIPqTjnQA(RMC6c2kL5hGOnFaIwAyb,headers)
			fW5M4LSmOYJBgyswb1T8 += ggZFSwdO6mGfeilQ20
			YIua5gAX48COGexvtK += qYNOZ4mvry1UufLEiaeSo
		else:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨἙ")+lfPqTpgMXhVcd+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭Ἒ")+bSrdN78jxURTvh9
			fW5M4LSmOYJBgyswb1T8.append(RMC6c2kL5hGOnFaIwAyb)
			YIua5gAX48COGexvtK.append(title)
	gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = QigevCplXxbPI1H,[],[]
	if fW5M4LSmOYJBgyswb1T8: gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6 = QigevCplXxbPI1H,YIua5gAX48COGexvtK,fW5M4LSmOYJBgyswb1T8
	else:
		if WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠫࡁ࠭Ἓ") not in aY63L2NhgvwJIxPAoDG4MKECmZXF1 and len(aY63L2NhgvwJIxPAoDG4MKECmZXF1)<XWbHfI9B8swrOL(u"࠶࠶࠰ࡀ") and aY63L2NhgvwJIxPAoDG4MKECmZXF1: gcXCwZe9xP = aY63L2NhgvwJIxPAoDG4MKECmZXF1
		else:
			msg = sBvufaD6c9YHdOqTjCQ3.findall(K7bLVaiRkx0lgU5SQM(u"ࠬࡂࡤࡪࡸࠣࡷࡹࡿ࡬ࡦ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪࡉ࡭ࡱ࡫࠮ࠫࡁࠬࡀࠬἜ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if not msg: msg = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡻࡶ࡟ࡷ࡫ࡧࡩࡴࡥࡳࡵࡷࡥࡣࡹࡾࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩἝ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if not msg: msg = sBvufaD6c9YHdOqTjCQ3.findall(OOhnpQ8XvCVclGqdu(u"ࠧ࠽ࡪ࠵ࡂ࡙࠭࡯ࡳࡴࡼ࠲࠯ࡅࠩ࠽ࠩ἞"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if msg: gcXCwZe9xP = msg[h17Zb2ld4yLBrCP5tiw]
	return gcXCwZe9xP,xnCNkRsMJtIXUqlhVmHD3Kv8SjQiyw,vdLczqkV5b48ZKyGxTE3jJi17aWS6
def qqOXilt0IvcSUdrmZw1yBWfYD(gzESUAarDRmsTMqvw4k0VNXZGe7JI,url):
	global z2zH1LGhxrO5sCWAaF
	url = url.strip(mmKqLr9RX0ACN384JMcsFHzd(u"ࠨ࠱ࠪ἟"))
	xu3Kmpia9Q0RvB5ZwnhLYNF,A1AqSc2LNwW0ETgyaRl9 = QigevCplXxbPI1H,{}
	headers = {Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ἠ"):eUBL1rOR4ZfndJAWPsoN6pybT0()}
	headers[FF70emVxhWOngCty(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫἡ")] = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,TCF8wLyDvgumfiXPSKRh(u"ࠫࡺࡸ࡬ࠨἢ"))
	headers[VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧἣ")] = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭ࡥ࡯࠯ࡘࡗ࠱࡫࡮࠼ࡳࡀ࠴࠳࠿ࠧἤ")
	headers[FF70emVxhWOngCty(u"ࠧࡔࡧࡦ࠱ࡋ࡫ࡴࡤࡪ࠰ࡈࡪࡹࡴࠨἥ")] = OOhnpQ8XvCVclGqdu(u"ࠨ࡫ࡩࡶࡦࡳࡥࠨἦ")
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠩࡊࡉ࡙࠭ἧ"),url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬἨ"))
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	AzdauDNS31oWrnOJEftky5FcILUXZ6 = JJrhP4C6osGDFEKVSRBvX.code
	if not isinstance(aY63L2NhgvwJIxPAoDG4MKECmZXF1,str): aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫἩ"))
	if Fg72JX6T5DkPy(u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࠫἪ") in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		ixUV6tokgq0K8a = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡡࡤࡳ࡟࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩἫ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if ixUV6tokgq0K8a:
			try: xu3Kmpia9Q0RvB5ZwnhLYNF = eCLWPXUqk9uo(ixUV6tokgq0K8a[h17Zb2ld4yLBrCP5tiw])
			except: xu3Kmpia9Q0RvB5ZwnhLYNF = QigevCplXxbPI1H
	BhxM1UVjtbEoSp640kIcag = aY63L2NhgvwJIxPAoDG4MKECmZXF1+xu3Kmpia9Q0RvB5ZwnhLYNF
	if VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࠣ࡫ࡧ࠶ࠧ࠭Ἤ") in BhxM1UVjtbEoSp640kIcag or DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࠤ࡬ࡨࠧ࠭Ἥ") in BhxM1UVjtbEoSp640kIcag:
		nQ2VRgu1OYGMCisdLKbe = url.split(Xr2aHOK0huQ5DTS(u"ࠩ࠲ࠫἮ"))[mVjHAyIwzSNKLFcd].replace(Xr2aHOK0huQ5DTS(u"ࠪࡩࡲࡨࡥࡥ࠯ࠪἯ"),QigevCplXxbPI1H).replace(OTRKI6LbrQnZEm(u"ࠫ࠳࡮ࡴ࡮࡮ࠪἰ"),QigevCplXxbPI1H)
		if Xr2aHOK0huQ5DTS(u"ࠬࠨࡩࡥ࠴ࠥࠫἱ") in BhxM1UVjtbEoSp640kIcag: A1AqSc2LNwW0ETgyaRl9 = {Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡩࡥ࠴ࠪἲ"):nQ2VRgu1OYGMCisdLKbe,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡰࡲࠪἳ"):FF70emVxhWOngCty(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫἴ")}
		elif aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠩࠥ࡭ࡩࠨࠧἵ") in BhxM1UVjtbEoSp640kIcag: A1AqSc2LNwW0ETgyaRl9 = {v54ZuLY6dQ(u"ࠪ࡭ࡩ࠭ἶ"):nQ2VRgu1OYGMCisdLKbe,K7bLVaiRkx0lgU5SQM(u"ࠫࡴࡶࠧἷ"):pGncXOodjKhJzLSqVP1r(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨἸ")}
		T24Te3uDwBS5vLgUEAhF1O = headers.copy()
		T24Te3uDwBS5vLgUEAhF1O[WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬἹ")] = mpusoZBJ6V(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭Ἲ")
		FoZ6n1al9wLqprS = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,y5yX4jh6kUEgWZQIc(u"ࠨࡒࡒࡗ࡙࠭Ἳ"),url,A1AqSc2LNwW0ETgyaRl9,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠳ࡰࡧࠫἼ"))
		BhxM1UVjtbEoSp640kIcag = FoZ6n1al9wLqprS.content
	G0O1xY9Af6m5Sni4EoKctPX3k,mR2Ya5OS9G8bC7NA,W5sDYeQmkzE6qGpgbjrl3LfhXAI = nSTd2ALhNuXoys5eaKZ1JG4miRcf7D(url,BhxM1UVjtbEoSp640kIcag)
	z2zH1LGhxrO5sCWAaF[gzESUAarDRmsTMqvw4k0VNXZGe7JI] = G0O1xY9Af6m5Sni4EoKctPX3k,mR2Ya5OS9G8bC7NA,W5sDYeQmkzE6qGpgbjrl3LfhXAI,AzdauDNS31oWrnOJEftky5FcILUXZ6
	return
z2zH1LGhxrO5sCWAaF,DD4cEbTduYBs8CS = {},pTwKPmzMSZhil5d2RWonre(u"࠶ࡁ")
def ooBc6t7ZNASGhLM4HWp(url):
	global z2zH1LGhxrO5sCWAaF,DD4cEbTduYBs8CS
	rsBojxT8UZwL,threads = [],[]
	DD4cEbTduYBs8CS += bDt7Ya1VEio3(u"࠱࠱࠲ࡂ")
	SD4FYRJkuET2fcGO5ritadhKlAeMw7 = DD4cEbTduYBs8CS
	rsBojxT8UZwL.append([vZL6j4tSClIGxzNE5DX(u"࠲ࡃ"),url])
	z2zH1LGhxrO5sCWAaF[SD4FYRJkuET2fcGO5ritadhKlAeMw7+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠳ࡄ")] = [None,None,None,None]
	dtvsWiaMpJc2gGLuob6y937BY = VVGXMeyJq25S6tf.Thread(target=qqOXilt0IvcSUdrmZw1yBWfYD,args=(SD4FYRJkuET2fcGO5ritadhKlAeMw7+y5yX4jh6kUEgWZQIc(u"࠴ࡅ"),url))
	dtvsWiaMpJc2gGLuob6y937BY.start()
	dtvsWiaMpJc2gGLuob6y937BY.join(vZL6j4tSClIGxzNE5DX(u"࠵࠵ࡆ"))
	if not z2zH1LGhxrO5sCWAaF[SD4FYRJkuET2fcGO5ritadhKlAeMw7+Xr2aHOK0huQ5DTS(u"࠶ࡇ")][JxuTQLOD357o41evylqPmRdf]:
		Kj0TOU6BmSMlJHZYLd = url.replace(FF70emVxhWOngCty(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫἽ"),XWbHfI9B8swrOL(u"ࠫ࠴࠭Ἶ"))
		WShVouXDRCGjeIFMYTHyimk5dlz = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"ࠬࡤࠨ࠯ࠬࡂ࠾࠴࠵࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠲ࠬ࠳࠰࠿ࠪࠦࠪἿ"),Kj0TOU6BmSMlJHZYLd+Fg72JX6T5DkPy(u"࠭࠯ࠨὀ"),sBvufaD6c9YHdOqTjCQ3.DOTALL)
		start,J1KzSo3pt7bakG4AVWQL0f9qlHEnU,end = WShVouXDRCGjeIFMYTHyimk5dlz[h17Zb2ld4yLBrCP5tiw]
		end = end.strip(svULcgJ7jm(u"ࠧ࠰ࠩὁ"))
		gFXuERabtZzi0HADOc3plP = len(J1KzSo3pt7bakG4AVWQL0f9qlHEnU)<OOhnpQ8XvCVclGqdu(u"࠺ࡈ") or J1KzSo3pt7bakG4AVWQL0f9qlHEnU in [tg9l25NH6WTacVSifLyAmY(u"ࠨࡨ࡬ࡰࡪ࠭ὂ"),K7bLVaiRkx0lgU5SQM(u"ࠩࡹ࡭ࡩ࡫࡯ࠨὃ"),tOrSvd8QKNB(u"ࠪࡺ࡮ࡪࡥࡰࡧࡰࡦࡪࡪࠧὄ"),pGncXOodjKhJzLSqVP1r(u"ࠫࡦࡰࡡࡹࠩὅ"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬ࡯ࡦࡳࡣࡰࡩࠬ὆"),mmKqLr9RX0ACN384JMcsFHzd(u"࠭࡭ࡪࡴࡵࡳࡷ࠭὇")]
		if not gFXuERabtZzi0HADOc3plP: rsBojxT8UZwL.append([OTRKI6LbrQnZEm(u"࠲ࡉ"),start+tg9l25NH6WTacVSifLyAmY(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨὈ")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+g4UCaNkHvLwGhjmW(u"ࠨ࠱ࠪὉ")+end])
		if end: rsBojxT8UZwL.append([s0vAWcLSXEToH9Mik134q(u"࠴ࡊ"),start+s0vAWcLSXEToH9Mik134q(u"ࠩ࠲ࠫὊ")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+bDt7Ya1VEio3(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫὋ")+end])
		if bDt7Ya1VEio3(u"ࠫ࠳࡮ࡴ࡮࡮ࠪὌ") in J1KzSo3pt7bakG4AVWQL0f9qlHEnU:
			PM7RnLEzfIX9G1KZSWN = J1KzSo3pt7bakG4AVWQL0f9qlHEnU.replace(FF70emVxhWOngCty(u"ࠬ࠴ࡨࡵ࡯࡯ࠫὍ"),QigevCplXxbPI1H)
			rsBojxT8UZwL.append([svULcgJ7jm(u"࠶ࡋ"),start+vZL6j4tSClIGxzNE5DX(u"࠭࠯ࠨ὎")+PM7RnLEzfIX9G1KZSWN+K7bLVaiRkx0lgU5SQM(u"ࠧ࠰ࠩ὏")+end])
			rsBojxT8UZwL.append([VvhRUZgko5Af1BIynMGOJSbpmK(u"࠸ࡌ"),start+XWbHfI9B8swrOL(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩὐ")+PM7RnLEzfIX9G1KZSWN+FF70emVxhWOngCty(u"ࠩ࠲ࠫὑ")+end])
			if end: rsBojxT8UZwL.append([hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠺ࡍ"),start+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪ࠳ࠬὒ")+PM7RnLEzfIX9G1KZSWN+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬὓ")+end])
		elif fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬ࠴ࡨࡵ࡯࡯ࠫὔ") in end:
			OgXRc37IvSwDJhGyb2Wn4NjP1A = end.replace(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࠮ࡩࡶࡰࡰࠬὕ"),QigevCplXxbPI1H)
			rsBojxT8UZwL.append([OOhnpQ8XvCVclGqdu(u"࠼ࡎ"),start+OOhnpQ8XvCVclGqdu(u"ࠧ࠰ࠩὖ")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨ࠱ࠪὗ")+OgXRc37IvSwDJhGyb2Wn4NjP1A])
			if not gFXuERabtZzi0HADOc3plP: rsBojxT8UZwL.append([OOhnpQ8XvCVclGqdu(u"࠾ࡏ"),start+XWbHfI9B8swrOL(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ὘")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+y5yX4jh6kUEgWZQIc(u"ࠪ࠳ࠬὙ")+OgXRc37IvSwDJhGyb2Wn4NjP1A])
			rsBojxT8UZwL.append([g4UCaNkHvLwGhjmW(u"࠹ࡐ"),start+tOrSvd8QKNB(u"ࠫ࠴࠭὚")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+TCF8wLyDvgumfiXPSKRh(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭Ὓ")+OgXRc37IvSwDJhGyb2Wn4NjP1A])
		else:
			if not gFXuERabtZzi0HADOc3plP: rsBojxT8UZwL.append([Xr2aHOK0huQ5DTS(u"࠲࠲ࡑ"),start+OTRKI6LbrQnZEm(u"࠭࠯ࠨ὜")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧ࠯ࡪࡷࡱࡱ࠭Ὕ")])
			if not gFXuERabtZzi0HADOc3plP: rsBojxT8UZwL.append([fk8jc5uDLX16qrih3ZaPxsvO(u"࠳࠴ࡒ"),start+bDt7Ya1VEio3(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩ὞")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+O4ylJvVNwLztdiHqBWDU(u"ࠩ࠱࡬ࡹࡳ࡬ࠨὟ")])
			if end: rsBojxT8UZwL.append([DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠴࠶ࡓ"),start+Fg72JX6T5DkPy(u"ࠪ࠳ࠬὠ")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+pTwKPmzMSZhil5d2RWonre(u"ࠫ࠴࠭ὡ")+end+mpusoZBJ6V(u"ࠬ࠴ࡨࡵ࡯࡯ࠫὢ")])
			if end: rsBojxT8UZwL.append([Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠸ࡔ"),start+Xr2aHOK0huQ5DTS(u"࠭࠯ࠨὣ")+J1KzSo3pt7bakG4AVWQL0f9qlHEnU+O4ylJvVNwLztdiHqBWDU(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨὤ")+end+pGncXOodjKhJzLSqVP1r(u"ࠨ࠰࡫ࡸࡲࡲࠧὥ")])
		if gFXuERabtZzi0HADOc3plP and end:
			end = end.replace(mpusoZBJ6V(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪὦ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪ࠳ࠬὧ"))
			rsBojxT8UZwL.append([OOhnpQ8XvCVclGqdu(u"࠶࠺ࡕ"),start+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫ࠴࠭Ὠ")+end])
			rsBojxT8UZwL.append([pTwKPmzMSZhil5d2RWonre(u"࠷࠵ࡖ"),start+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭Ὡ")+end])
			if fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࠮ࡩࡶࡰࡰࠬὪ") in end:
				OgXRc37IvSwDJhGyb2Wn4NjP1A = end.replace(JJu4MPClbTFpUwHiN(u"ࠧ࠯ࡪࡷࡱࡱ࠭Ὣ"),QigevCplXxbPI1H)
				rsBojxT8UZwL.append([hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠱࠷ࡗ"),start+pGncXOodjKhJzLSqVP1r(u"ࠨ࠱ࠪὬ")+OgXRc37IvSwDJhGyb2Wn4NjP1A])
				rsBojxT8UZwL.append([pTwKPmzMSZhil5d2RWonre(u"࠲࠹ࡘ"),start+pGncXOodjKhJzLSqVP1r(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪὭ")+OgXRc37IvSwDJhGyb2Wn4NjP1A])
			else:
				rsBojxT8UZwL.append([K7bLVaiRkx0lgU5SQM(u"࠳࠻࡙"),start+K7bLVaiRkx0lgU5SQM(u"ࠪ࠳ࠬὮ")+end+TCF8wLyDvgumfiXPSKRh(u"ࠫ࠳࡮ࡴ࡮࡮ࠪὯ")])
				rsBojxT8UZwL.append([mpusoZBJ6V(u"࠴࠽࡚"),start+vZL6j4tSClIGxzNE5DX(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ὰ")+end+s0vAWcLSXEToH9Mik134q(u"࠭࠮ࡩࡶࡰࡰࠬά")])
		YVvkLCQwf3F = []
		for TfilazROjy,RMC6c2kL5hGOnFaIwAyb in rsBojxT8UZwL[tOrSvd8QKNB(u"࠵࡛"):]:
			z2zH1LGhxrO5sCWAaF[SD4FYRJkuET2fcGO5ritadhKlAeMw7+TfilazROjy] = [None,None,None,None]
			WmqlEZNtrDc9jHKPIAxFUea7o84R = VVGXMeyJq25S6tf.Thread(target=qqOXilt0IvcSUdrmZw1yBWfYD,args=(SD4FYRJkuET2fcGO5ritadhKlAeMw7+TfilazROjy,RMC6c2kL5hGOnFaIwAyb))
			WmqlEZNtrDc9jHKPIAxFUea7o84R.start()
			YVvkLCQwf3F.append(WmqlEZNtrDc9jHKPIAxFUea7o84R)
			B3TKLo71hAGRqYgV0.sleep(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠵࠴࠷࠶࡜"))
		for WmqlEZNtrDc9jHKPIAxFUea7o84R in YVvkLCQwf3F: WmqlEZNtrDc9jHKPIAxFUea7o84R.join(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠷࠰࡝"))
	gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = QigevCplXxbPI1H,[],[]
	lcnZ2IwYPAKMt0s7k = []
	for TfilazROjy,RMC6c2kL5hGOnFaIwAyb in rsBojxT8UZwL:
		pQE6h7ceaPM0BRym5u3G,TTVxpNOCgKS7kLseDlI,AnrxaQjp4JlYX8dZ05sw9DNL7qHUT3,XXz5uhmokjgPtL01DWiNGFS3Bq = z2zH1LGhxrO5sCWAaF[SD4FYRJkuET2fcGO5ritadhKlAeMw7+TfilazROjy]
		if not ldFqnNIsftrY43JBM6LPjzU8m and AnrxaQjp4JlYX8dZ05sw9DNL7qHUT3: ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = TTVxpNOCgKS7kLseDlI,AnrxaQjp4JlYX8dZ05sw9DNL7qHUT3
		if not gcXCwZe9xP and pQE6h7ceaPM0BRym5u3G: gcXCwZe9xP = pQE6h7ceaPM0BRym5u3G
		if XXz5uhmokjgPtL01DWiNGFS3Bq: lcnZ2IwYPAKMt0s7k.append(XXz5uhmokjgPtL01DWiNGFS3Bq)
	lcnZ2IwYPAKMt0s7k = list(set(lcnZ2IwYPAKMt0s7k))
	if not gcXCwZe9xP and len(lcnZ2IwYPAKMt0s7k)==s0vAWcLSXEToH9Mik134q(u"࠱࡞"):
		AzdauDNS31oWrnOJEftky5FcILUXZ6 = lcnZ2IwYPAKMt0s7k[h17Zb2ld4yLBrCP5tiw]
		if AzdauDNS31oWrnOJEftky5FcILUXZ6!=vZL6j4tSClIGxzNE5DX(u"࠳࠲࠳࡟"):
			if AzdauDNS31oWrnOJEftky5FcILUXZ6<NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠲ࡠ"): gcXCwZe9xP = Xr2aHOK0huQ5DTS(u"ࠧࡗ࡫ࡧࡩࡴࠦࡰࡢࡩࡨ࠳ࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠ࡯ࡱࡷࠤࡦࡩࡣࡦࡵࡶ࡭ࡧࡲࡥࠨὲ")
			else:
				gcXCwZe9xP = bDt7Ya1VEio3(u"ࠨࡊࡗࡘࡕࠦࡅࡳࡴࡲࡶ࠿ࠦࠧέ")+str(AzdauDNS31oWrnOJEftky5FcILUXZ6)
				if b7sJAmSxlBvaMdHFz: import http.client as i3a6KbvxWsJ9kyg
				else: import httplib as i3a6KbvxWsJ9kyg
				try: gcXCwZe9xP += Fg72JX6T5DkPy(u"ࠩࠣࠬࠥ࠭ὴ")+i3a6KbvxWsJ9kyg.responses[AzdauDNS31oWrnOJEftky5FcILUXZ6]+vZL6j4tSClIGxzNE5DX(u"ࠪࠤ࠮࠭ή")
				except: pass
	B3TKLo71hAGRqYgV0.sleep(tOrSvd8QKNB(u"࠴ࡡ"))
	return gcXCwZe9xP,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m
class atSIqXiPQULmpH4Ge9WrjgCdJosZ(Q0BXbnOs1jr8afIyTUHZDw4lCAki7.WindowDialog):
	def __init__(exy8R6A9igVLkKa1vXd3, *args, **HujQryvzX4n2gaV0):
		abZCy3vQLhRuonXxkH4tw = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q, tOrSvd8QKNB(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧὶ"), bDt7Ya1VEio3(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩί"), K7bLVaiRkx0lgU5SQM(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡨࡧ࠯ࡲࡱ࡫ࠬὸ"))
		xx7YOi5byeFd = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q, svULcgJ7jm(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪό"), DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬὺ"), fk8jc5uDLX16qrih3ZaPxsvO(u"ࠩࡶࡩࡱ࡫ࡣࡵࡧࡧ࠲ࡵࡴࡧࠨύ"))
		uUJLAMVmzl2Wey = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q, fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ὼ"), pGncXOodjKhJzLSqVP1r(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨώ"), OOhnpQ8XvCVclGqdu(u"ࠬࡨࡵࡵࡶࡲࡲ࡫ࡵ࠮ࡱࡰࡪࠫ὾"))
		udQKpIrL3gZV5x1 = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q, v54ZuLY6dQ(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ὿"), fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫᾀ"), tg9l25NH6WTacVSifLyAmY(u"ࠨࡤࡸࡸࡹࡵ࡮࡯ࡨ࠱ࡴࡳ࡭ࠧᾁ"))
		S4Vew8EakP = KiTt9ZskMLjnCAUIJNXD7.path.join(XoeSNbWwLnKC8Q, pGncXOodjKhJzLSqVP1r(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬᾂ"), O4ylJvVNwLztdiHqBWDU(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧᾃ"), aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡧࡻࡴࡵࡱࡱࡦ࡬࠴ࡰ࡯ࡩࠪᾄ"))
		exy8R6A9igVLkKa1vXd3.cancelled = YoAMfqm37GyFxbuKTt6e8CESHrhB
		exy8R6A9igVLkKa1vXd3.chk = [h17Zb2ld4yLBrCP5tiw] * Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠽ࡢ")
		exy8R6A9igVLkKa1vXd3.chkbutton = [h17Zb2ld4yLBrCP5tiw] * svULcgJ7jm(u"࠾ࡣ")
		exy8R6A9igVLkKa1vXd3.chkstate = [YoAMfqm37GyFxbuKTt6e8CESHrhB] * DDHwpETQrAm0xMNXGfyhqsUi(u"࠿ࡤ")
		MEsibgo7XxKfvpneRj09OQwtk8, rEYeNT1DcbxXO6tJdoa5f2Si3gZqjU, jP5hIyZorDKck8, ETH60GPtcQyFdalk38KOR2UXm = mpusoZBJ6V(u"࠳࠷࠳ࡦ"), bDt7Ya1VEio3(u"࠰ࡥ"), hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠹࠳࠴ࡧ"), DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠺࠺࠵ࡨ")
		lI3CBNncuoHgFdZOGA6vieU2MS = MEsibgo7XxKfvpneRj09OQwtk8+jP5hIyZorDKck8//y5yX4jh6kUEgWZQIc(u"࠶ࡩ")
		ttS39kribmUR16Q2gnGdTO, qLxe3whO1N, vvE5mjZgObX6S1WVHecUPlhtwLTCQ, SBGYczQpi789rdD3yoHA4VO5 = fk8jc5uDLX16qrih3ZaPxsvO(u"࠹࠵࠶࡫"), QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࠸࠰ࡪ"), TCF8wLyDvgumfiXPSKRh(u"࠵࠱࠲࡬"), TCF8wLyDvgumfiXPSKRh(u"࠵࠱࠲࡬")
		Fl3TVPOrByCkoGIxhtA6 = ttS39kribmUR16Q2gnGdTO+vvE5mjZgObX6S1WVHecUPlhtwLTCQ//tg9l25NH6WTacVSifLyAmY(u"࠳࡭")
		WuyOHkSrZUf936DAq5szPC, nxZA1LESh4FXKM, X0a6OmpDHY574lncM, QQYVGJey0rakNshx2CzU1Tnp3XPE = TCF8wLyDvgumfiXPSKRh(u"࠴࠴࠵࡯"), WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠺࠺࠻ࡰ"), XWbHfI9B8swrOL(u"࠳࠸࠴࡮"), OTRKI6LbrQnZEm(u"࠺࠶ࡱ")
		EFeqjhgPHubcrVkvSDMIZ5fN9w0RBJ = lI3CBNncuoHgFdZOGA6vieU2MS-X0a6OmpDHY574lncM-WuyOHkSrZUf936DAq5szPC//hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠸ࡲ")
		a7MQhdCXwb63RxlrK5s = lI3CBNncuoHgFdZOGA6vieU2MS+WuyOHkSrZUf936DAq5szPC//NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠲ࡳ")
		q8gBYWTFv1LDl5jCRxOt, agjdHvlwZPIn0pCBEDGzibx, sjPBAmlnqv6L8ecgTaM0F, qKm16LSIuW53rgFxNv4dnRh2 = vZL6j4tSClIGxzNE5DX(u"࠴࠷࠸ࡴ"), Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠵࠳ࡵ"), fk8jc5uDLX16qrih3ZaPxsvO(u"࠹࠵࠶ࡷ"), tOrSvd8QKNB(u"࠸࠴ࡶ")
		bcARK8SMhO6Qeo3s, gGUe5nNfsl2MARkWBqT, rVGWzwQp6TfR19my5sZq, FuJeHPqCAW = K7bLVaiRkx0lgU5SQM(u"࠸࠻࠵ࡸ"), K7bLVaiRkx0lgU5SQM(u"࠸࠲ࡻ"), QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠵࠱࠲ࡺ"), tOrSvd8QKNB(u"࠻࠰ࡹ")
		ewTOM4WkpdUqNDomCis = OTRKI6LbrQnZEm(u"࠲࠱࠽ࡼ")
		MEsibgo7XxKfvpneRj09OQwtk8, rEYeNT1DcbxXO6tJdoa5f2Si3gZqjU, jP5hIyZorDKck8, ETH60GPtcQyFdalk38KOR2UXm = int(MEsibgo7XxKfvpneRj09OQwtk8*ewTOM4WkpdUqNDomCis), int(rEYeNT1DcbxXO6tJdoa5f2Si3gZqjU*ewTOM4WkpdUqNDomCis), int(jP5hIyZorDKck8*ewTOM4WkpdUqNDomCis), int(ETH60GPtcQyFdalk38KOR2UXm*ewTOM4WkpdUqNDomCis)
		ttS39kribmUR16Q2gnGdTO, qLxe3whO1N, vvE5mjZgObX6S1WVHecUPlhtwLTCQ, SBGYczQpi789rdD3yoHA4VO5 = int(ttS39kribmUR16Q2gnGdTO*ewTOM4WkpdUqNDomCis), int(qLxe3whO1N*ewTOM4WkpdUqNDomCis), int(vvE5mjZgObX6S1WVHecUPlhtwLTCQ*ewTOM4WkpdUqNDomCis), int(SBGYczQpi789rdD3yoHA4VO5*ewTOM4WkpdUqNDomCis)
		EFeqjhgPHubcrVkvSDMIZ5fN9w0RBJ, Xp1NOCLEu87SsYhgw, zBRigvjpQTYJHXhrIKsD7q6FA9dkb, op78VLB3T2JKW = int(EFeqjhgPHubcrVkvSDMIZ5fN9w0RBJ*ewTOM4WkpdUqNDomCis), int(nxZA1LESh4FXKM*ewTOM4WkpdUqNDomCis), int(X0a6OmpDHY574lncM*ewTOM4WkpdUqNDomCis), int(QQYVGJey0rakNshx2CzU1Tnp3XPE*ewTOM4WkpdUqNDomCis)
		a7MQhdCXwb63RxlrK5s, R4r671jSfaUd2Yk0s3eOlHimTh, so72IblYraOmdWTiqSvgQpNUcR, gijumEYbqTdfeAQ = int(a7MQhdCXwb63RxlrK5s*ewTOM4WkpdUqNDomCis), int(nxZA1LESh4FXKM*ewTOM4WkpdUqNDomCis), int(X0a6OmpDHY574lncM*ewTOM4WkpdUqNDomCis), int(QQYVGJey0rakNshx2CzU1Tnp3XPE*ewTOM4WkpdUqNDomCis)
		q8gBYWTFv1LDl5jCRxOt, agjdHvlwZPIn0pCBEDGzibx, sjPBAmlnqv6L8ecgTaM0F, qKm16LSIuW53rgFxNv4dnRh2 = int(q8gBYWTFv1LDl5jCRxOt*ewTOM4WkpdUqNDomCis), int(agjdHvlwZPIn0pCBEDGzibx*ewTOM4WkpdUqNDomCis), int(sjPBAmlnqv6L8ecgTaM0F*ewTOM4WkpdUqNDomCis), int(qKm16LSIuW53rgFxNv4dnRh2*ewTOM4WkpdUqNDomCis)
		bcARK8SMhO6Qeo3s, gGUe5nNfsl2MARkWBqT, rVGWzwQp6TfR19my5sZq, FuJeHPqCAW = int(bcARK8SMhO6Qeo3s*ewTOM4WkpdUqNDomCis), int(gGUe5nNfsl2MARkWBqT*ewTOM4WkpdUqNDomCis), int(rVGWzwQp6TfR19my5sZq*ewTOM4WkpdUqNDomCis), int(FuJeHPqCAW*ewTOM4WkpdUqNDomCis)
		IoOVkimJeF5 = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlImage(MEsibgo7XxKfvpneRj09OQwtk8, rEYeNT1DcbxXO6tJdoa5f2Si3gZqjU, jP5hIyZorDKck8, ETH60GPtcQyFdalk38KOR2UXm, abZCy3vQLhRuonXxkH4tw)
		exy8R6A9igVLkKa1vXd3.addControl(IoOVkimJeF5)
		exy8R6A9igVLkKa1vXd3.iteration = HujQryvzX4n2gaV0.get(Fg72JX6T5DkPy(u"ࠬ࡯ࡴࡦࡴࡤࡸ࡮ࡵ࡮ࠨᾅ"))
		onrqSyGT2j7K = r9rhtA5Tek8sIoLfqwF7JcEV+bDt7Ya1VEio3(u"࠭แฮืࠣว๋อࠠฦ่ึห๋่ࠦๅีอࠤึ๎ศ้ฬࠣࠤࠥࠦࠠࠡࠢࠣࠤࠬᾆ")+v54ZuLY6dQ(u"ࠧศๆ่ัฬ๎ไสࠢิๆ๊ࠦࠠࠨᾇ")+str(exy8R6A9igVLkKa1vXd3.iteration)+jhAlCQ47ZgG
		exy8R6A9igVLkKa1vXd3.strActionInfo = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlLabel(q8gBYWTFv1LDl5jCRxOt, agjdHvlwZPIn0pCBEDGzibx, sjPBAmlnqv6L8ecgTaM0F, qKm16LSIuW53rgFxNv4dnRh2, onrqSyGT2j7K, VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠨࡨࡲࡲࡹ࠷࠳ࠨᾈ"))
		exy8R6A9igVLkKa1vXd3.addControl(exy8R6A9igVLkKa1vXd3.strActionInfo)
		cXu4fN1moCypJqb72OZvd = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlImage(ttS39kribmUR16Q2gnGdTO, qLxe3whO1N, vvE5mjZgObX6S1WVHecUPlhtwLTCQ, SBGYczQpi789rdD3yoHA4VO5, HujQryvzX4n2gaV0.get(K7bLVaiRkx0lgU5SQM(u"ࠩࡦࡥࡵࡺࡣࡩࡣࠪᾉ")))
		exy8R6A9igVLkKa1vXd3.addControl(cXu4fN1moCypJqb72OZvd)
		Qz5cWGP8DguCqbaAdsMBp1mrt7 = r9rhtA5Tek8sIoLfqwF7JcEV+HujQryvzX4n2gaV0.get(tOrSvd8QKNB(u"ࠪࡱࡸ࡭ࠧᾊ"))+jhAlCQ47ZgG
		exy8R6A9igVLkKa1vXd3.strActionInfo = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlLabel(bcARK8SMhO6Qeo3s, gGUe5nNfsl2MARkWBqT, rVGWzwQp6TfR19my5sZq, FuJeHPqCAW, Qz5cWGP8DguCqbaAdsMBp1mrt7, g4UCaNkHvLwGhjmW(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫᾋ"))
		exy8R6A9igVLkKa1vXd3.addControl(exy8R6A9igVLkKa1vXd3.strActionInfo)
		text = r9rhtA5Tek8sIoLfqwF7JcEV+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬิั้ฮࠪᾌ")+jhAlCQ47ZgG
		exy8R6A9igVLkKa1vXd3.cancelbutton = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlButton(EFeqjhgPHubcrVkvSDMIZ5fN9w0RBJ, Xp1NOCLEu87SsYhgw, zBRigvjpQTYJHXhrIKsD7q6FA9dkb, op78VLB3T2JKW, text, focusTexture=S4Vew8EakP, noFocusTexture=uUJLAMVmzl2Wey, alignment=aqUlAdFto05NmG4Y6guEzTr8vK(u"࠵ࡽ"))
		text = r9rhtA5Tek8sIoLfqwF7JcEV+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠭วิฬ่ีฬืࠧᾍ")+jhAlCQ47ZgG
		exy8R6A9igVLkKa1vXd3.okbutton = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlButton(a7MQhdCXwb63RxlrK5s, R4r671jSfaUd2Yk0s3eOlHimTh, so72IblYraOmdWTiqSvgQpNUcR, gijumEYbqTdfeAQ, text, focusTexture=S4Vew8EakP, noFocusTexture=uUJLAMVmzl2Wey, alignment=mpusoZBJ6V(u"࠶ࡾ"))
		exy8R6A9igVLkKa1vXd3.addControl(exy8R6A9igVLkKa1vXd3.okbutton)
		exy8R6A9igVLkKa1vXd3.addControl(exy8R6A9igVLkKa1vXd3.cancelbutton)
		TxWudS5HR8yPDZVXNksQp6rnG79wE, GhnxdUgZW2THqcK = SBGYczQpi789rdD3yoHA4VO5//XWbHfI9B8swrOL(u"࠸ࡿ"), vvE5mjZgObX6S1WVHecUPlhtwLTCQ//XWbHfI9B8swrOL(u"࠸ࡿ")
		for A5SjhJUg37pNiMC4Eot6lOF in range(JJu4MPClbTFpUwHiN(u"࠿ࢀ")):
			lKuCTV8bvt1M4ehj0NJqPkaH2QGUz = A5SjhJUg37pNiMC4Eot6lOF // fk8jc5uDLX16qrih3ZaPxsvO(u"࠳ࢁ")
			s3MVkER80lZ9qau = A5SjhJUg37pNiMC4Eot6lOF % Xr2aHOK0huQ5DTS(u"࠴ࢂ")
			FWocx4DP9M0YUia5uhgHXnqBr8 = ttS39kribmUR16Q2gnGdTO + (GhnxdUgZW2THqcK * s3MVkER80lZ9qau)
			LTlg1oA0Dump6QnMShbvwra29N8tf = qLxe3whO1N + (TxWudS5HR8yPDZVXNksQp6rnG79wE * lKuCTV8bvt1M4ehj0NJqPkaH2QGUz)
			exy8R6A9igVLkKa1vXd3.chk[A5SjhJUg37pNiMC4Eot6lOF] = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlImage(FWocx4DP9M0YUia5uhgHXnqBr8, LTlg1oA0Dump6QnMShbvwra29N8tf, GhnxdUgZW2THqcK, TxWudS5HR8yPDZVXNksQp6rnG79wE, xx7YOi5byeFd)
			exy8R6A9igVLkKa1vXd3.addControl(exy8R6A9igVLkKa1vXd3.chk[A5SjhJUg37pNiMC4Eot6lOF])
			exy8R6A9igVLkKa1vXd3.chk[A5SjhJUg37pNiMC4Eot6lOF].setVisible(YoAMfqm37GyFxbuKTt6e8CESHrhB)
			exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF] = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ControlButton(FWocx4DP9M0YUia5uhgHXnqBr8, LTlg1oA0Dump6QnMShbvwra29N8tf, GhnxdUgZW2THqcK, TxWudS5HR8yPDZVXNksQp6rnG79wE, str(A5SjhJUg37pNiMC4Eot6lOF + tg9l25NH6WTacVSifLyAmY(u"࠳ࢃ")), font=OOhnpQ8XvCVclGqdu(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧᾎ"), focusTexture=uUJLAMVmzl2Wey, noFocusTexture=udQKpIrL3gZV5x1)
			exy8R6A9igVLkKa1vXd3.addControl(exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF])
		for A5SjhJUg37pNiMC4Eot6lOF in range(aqUlAdFto05NmG4Y6guEzTr8vK(u"࠼ࢄ")):
			wwknE8yQ6sLhdqr5FfTueva34zYG = (A5SjhJUg37pNiMC4Eot6lOF // JJu4MPClbTFpUwHiN(u"࠷ࢅ")) * JJu4MPClbTFpUwHiN(u"࠷ࢅ")
			IWwJQotdaz1fTCLkvZ = wwknE8yQ6sLhdqr5FfTueva34zYG + (A5SjhJUg37pNiMC4Eot6lOF + Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠶ࢆ")) % Xr2aHOK0huQ5DTS(u"࠹ࢇ")
			kqtzN4IgVLilhuCe56YFXHjsBE = wwknE8yQ6sLhdqr5FfTueva34zYG + (A5SjhJUg37pNiMC4Eot6lOF - vZL6j4tSClIGxzNE5DX(u"࠱࢈")) % bDt7Ya1VEio3(u"࠴ࢉ")
			t7mnM0yQH1zkJrUS3YF = (A5SjhJUg37pNiMC4Eot6lOF - Xr2aHOK0huQ5DTS(u"࠶ࢋ")) % g4UCaNkHvLwGhjmW(u"࠻ࢊ")
			uz1ISb3txMw4 = (A5SjhJUg37pNiMC4Eot6lOF + WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠸ࢍ")) % Fg72JX6T5DkPy(u"࠽ࢌ")
			exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF].controlRight(exy8R6A9igVLkKa1vXd3.chkbutton[IWwJQotdaz1fTCLkvZ])
			exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF].controlLeft(exy8R6A9igVLkKa1vXd3.chkbutton[kqtzN4IgVLilhuCe56YFXHjsBE])
			if A5SjhJUg37pNiMC4Eot6lOF <= NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠸ࢎ"):
				exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF].controlUp(exy8R6A9igVLkKa1vXd3.okbutton)
			else:
				exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF].controlUp(exy8R6A9igVLkKa1vXd3.chkbutton[t7mnM0yQH1zkJrUS3YF])
			if A5SjhJUg37pNiMC4Eot6lOF >= pTwKPmzMSZhil5d2RWonre(u"࠶࢏"):
				exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF].controlDown(exy8R6A9igVLkKa1vXd3.okbutton)
			else:
				exy8R6A9igVLkKa1vXd3.chkbutton[A5SjhJUg37pNiMC4Eot6lOF].controlDown(exy8R6A9igVLkKa1vXd3.chkbutton[uz1ISb3txMw4])
		exy8R6A9igVLkKa1vXd3.okbutton.controlLeft(exy8R6A9igVLkKa1vXd3.cancelbutton)
		exy8R6A9igVLkKa1vXd3.okbutton.controlRight(exy8R6A9igVLkKa1vXd3.cancelbutton)
		exy8R6A9igVLkKa1vXd3.cancelbutton.controlLeft(exy8R6A9igVLkKa1vXd3.okbutton)
		exy8R6A9igVLkKa1vXd3.cancelbutton.controlRight(exy8R6A9igVLkKa1vXd3.okbutton)
		exy8R6A9igVLkKa1vXd3.okbutton.controlDown(exy8R6A9igVLkKa1vXd3.chkbutton[JxuTQLOD357o41evylqPmRdf])
		exy8R6A9igVLkKa1vXd3.okbutton.controlUp(exy8R6A9igVLkKa1vXd3.chkbutton[QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠹࢐")])
		exy8R6A9igVLkKa1vXd3.cancelbutton.controlDown(exy8R6A9igVLkKa1vXd3.chkbutton[h17Zb2ld4yLBrCP5tiw])
		exy8R6A9igVLkKa1vXd3.cancelbutton.controlUp(exy8R6A9igVLkKa1vXd3.chkbutton[g4UCaNkHvLwGhjmW(u"࠸࢑")])
		exy8R6A9igVLkKa1vXd3.setFocus(exy8R6A9igVLkKa1vXd3.okbutton)
	def get(exy8R6A9igVLkKa1vXd3):
		exy8R6A9igVLkKa1vXd3.doModal()
		exy8R6A9igVLkKa1vXd3.close()
		if not exy8R6A9igVLkKa1vXd3.cancelled:
			return [A5SjhJUg37pNiMC4Eot6lOF for A5SjhJUg37pNiMC4Eot6lOF in range(Fg72JX6T5DkPy(u"࠼࢒")) if exy8R6A9igVLkKa1vXd3.chkstate[A5SjhJUg37pNiMC4Eot6lOF]]
	def onControl(exy8R6A9igVLkKa1vXd3, KQYao6l40iHndCZjSG5FJyv2teR9hf):
		if KQYao6l40iHndCZjSG5FJyv2teR9hf.getId() == exy8R6A9igVLkKa1vXd3.okbutton.getId() and any(exy8R6A9igVLkKa1vXd3.chkstate):
			exy8R6A9igVLkKa1vXd3.close()
		elif KQYao6l40iHndCZjSG5FJyv2teR9hf.getId() == exy8R6A9igVLkKa1vXd3.cancelbutton.getId():
			exy8R6A9igVLkKa1vXd3.cancelled = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			exy8R6A9igVLkKa1vXd3.close()
		else:
			J4kSW2aUHYg6 = KQYao6l40iHndCZjSG5FJyv2teR9hf.getLabel()
			if J4kSW2aUHYg6.isnumeric():
				index = int(J4kSW2aUHYg6) - fk8jc5uDLX16qrih3ZaPxsvO(u"࠵࢓")
				exy8R6A9igVLkKa1vXd3.chkstate[index] = not exy8R6A9igVLkKa1vXd3.chkstate[index]
				exy8R6A9igVLkKa1vXd3.chk[index].setVisible(exy8R6A9igVLkKa1vXd3.chkstate[index])
	def onAction(exy8R6A9igVLkKa1vXd3, v3lzXQkLZTStAp):
		if v3lzXQkLZTStAp == tg9l25NH6WTacVSifLyAmY(u"࠶࠶࢔"):
			exy8R6A9igVLkKa1vXd3.cancelled = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
			exy8R6A9igVLkKa1vXd3.close()
def FpP6hwI4C3u(key,UmDMPlYnsIOZ3HX4J76i,url):
	headers = {y5yX4jh6kUEgWZQIc(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᾏ"):url,tg9l25NH6WTacVSifLyAmY(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫᾐ"):UmDMPlYnsIOZ3HX4J76i}
	IIXfiwW4U8Roq751cGQAnKYzT3kZC = pGncXOodjKhJzLSqVP1r(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠯ࡢࡲ࡬࠳࡫ࡧ࡬࡭ࡤࡤࡧࡰࡅ࡫࠾ࠩᾑ")+key
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,OTRKI6LbrQnZEm(u"ࠫࡌࡋࡔࠨᾒ"),IIXfiwW4U8Roq751cGQAnKYzT3kZC,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡉࡈࡘࡤࡘࡅࡄࡃࡓࡘࡈࡎࡁ࠳ࡡࡗࡓࡐࡋࡎ࠮࠳ࡶࡸࠬᾓ"))
	F01WAKej2RtVrpXQvi,iteration = QigevCplXxbPI1H,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠶࢕")
	while XpREPf7d08GnIS6i4KNLMyZHmuQqxD:
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		A1AqSc2LNwW0ETgyaRl9 = sBvufaD6c9YHdOqTjCQ3.findall(OTRKI6LbrQnZEm(u"࠭ࠢࠩ࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠴࠲ࡴࡦࡿ࡬ࡰࡣࡧ࡟ࡣࠨ࡝ࠬࠫࠪᾔ"), aY63L2NhgvwJIxPAoDG4MKECmZXF1)
		iteration += hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠱࢖")
		message = sBvufaD6c9YHdOqTjCQ3.findall(XWbHfI9B8swrOL(u"ࠧ࠽࡮ࡤࡦࡪࡲ࡛࡟ࡀࡠ࠯ࡨࡲࡡࡴࡵࡀࠦ࡫ࡨࡣ࠮࡫ࡰࡥ࡬࡫ࡳࡦ࡮ࡨࡧࡹ࠳࡭ࡦࡵࡶࡥ࡬࡫࠭ࡵࡧࡻࡸࠧࡡ࡞࠿࡟࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱࡧࡢࡦ࡮ࡁࠫᾕ"), aY63L2NhgvwJIxPAoDG4MKECmZXF1)
		if not message: message = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"ࠨ࠾ࡧ࡭ࡻࡡ࡞࠿࡟࠮ࡧࡱࡧࡳࡴ࠿ࠥࡪࡧࡩ࠭ࡪ࡯ࡤ࡫ࡪࡹࡥ࡭ࡧࡦࡸ࠲ࡳࡥࡴࡵࡤ࡫ࡪ࠳ࡥࡳࡴࡲࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᾖ"), aY63L2NhgvwJIxPAoDG4MKECmZXF1)
		if not message:
			F01WAKej2RtVrpXQvi = sBvufaD6c9YHdOqTjCQ3.findall(NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩࡵࡩࡦࡪ࡯࡯࡮ࡼࡂ࠭࠴ࠪࡀࠫ࠿ࠫᾗ"), aY63L2NhgvwJIxPAoDG4MKECmZXF1)[h17Zb2ld4yLBrCP5tiw]
			break
		else:
			message = message[h17Zb2ld4yLBrCP5tiw]
			A1AqSc2LNwW0ETgyaRl9 = A1AqSc2LNwW0ETgyaRl9[h17Zb2ld4yLBrCP5tiw]
		b7V9TBNQDrGWU = sBvufaD6c9YHdOqTjCQ3.findall(pTwKPmzMSZhil5d2RWonre(u"ࡵࠫࡳࡧ࡭ࡦ࠿ࠥࡧࠧࡢࡳࠬࡸࡤࡰࡺ࡫࠽ࠣࠪ࡞ࡢࠧࡣࠫࠪࠩᾘ"), aY63L2NhgvwJIxPAoDG4MKECmZXF1)[h17Zb2ld4yLBrCP5tiw]
		cPKZDJ50W6If1kUi7X28y4SHuN = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲࠫࡳࠨᾙ") % (A1AqSc2LNwW0ETgyaRl9.replace(g4UCaNkHvLwGhjmW(u"ࠬࠬࡡ࡮ࡲ࠾ࠫᾚ"), v54ZuLY6dQ(u"࠭ࠦࠨᾛ")))
		message = sBvufaD6c9YHdOqTjCQ3.sub(DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠧ࠽࠱ࡂࠬࡩ࡯ࡶࡽࡵࡷࡶࡴࡴࡧࠪ࡝ࡡࡂࡢ࠰࠾ࠨᾜ"), QigevCplXxbPI1H, message)
		egbnFyozkuEfiM5t3LrwCQNcS = atSIqXiPQULmpH4Ge9WrjgCdJosZ(captcha=cPKZDJ50W6If1kUi7X28y4SHuN, msg=message, iteration=iteration)
		FXIZ9j2LqkmpN = egbnFyozkuEfiM5t3LrwCQNcS.get()
		if not FXIZ9j2LqkmpN: break
		data = {s0vAWcLSXEToH9Mik134q(u"ࠨࡥࠪᾝ"): b7V9TBNQDrGWU, v54ZuLY6dQ(u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫᾞ"): FXIZ9j2LqkmpN}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,Fg72JX6T5DkPy(u"ࠪࡔࡔ࡙ࡔࠨᾟ"),IIXfiwW4U8Roq751cGQAnKYzT3kZC,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡇࡗࡣࡗࡋࡃࡂࡒࡗࡇࡍࡇ࠲ࡠࡖࡒࡏࡊࡔ࠭࠳ࡰࡧࠫᾠ"))
	return F01WAKej2RtVrpXQvi
def psXH7NlyKWrtaf3qbiZ(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇࡒࡏࡂࡆࡖ࠱࠶ࡹࡴࠨᾡ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(fk8jc5uDLX16qrih3ZaPxsvO(u"࠭ࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᾢ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[ items[h17Zb2ld4yLBrCP5tiw] ]
	else: return tOrSvd8QKNB(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡌࡐࡃࡇࡗࠬᾣ"),[],[]
def k7ZShnuRNmAQXJ(url):
	return QigevCplXxbPI1H,[QigevCplXxbPI1H],[url]
def qiRVEdg23KmwbHOlJ8X5MD(url):
	bSrdN78jxURTvh9 = url.split(pGncXOodjKhJzLSqVP1r(u"ࠨ࠱ࠪᾤ"))
	HWJILAVRusgbDvOqUrzpCe1m = pTwKPmzMSZhil5d2RWonre(u"ࠩ࠲ࠫᾥ").join(bSrdN78jxURTvh9[hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠱ࢗ"):tg9l25NH6WTacVSifLyAmY(u"࠵࢘")])
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡚ࡊࡒࡓ࡝ࡘࡎࡁࡓࡇ࠰࠵ࡸࡺࠧᾦ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(bDt7Ya1VEio3(u"ࠫࡩࡲࡢࡶࡶࡷࡳࡳࡢࠧ࡝ࠫ࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠤࡡ࠱ࠠ࡝ࠪࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫࠣࡠ࠰ࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯࡜ࠪࠢ࡟࠯ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᾧ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items:
		KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn,iXlCG2W7y3KdELAh,e6ncX1k4JKdgmSa,thjavJxeHW6quwfDSKQP02Rl3ziL,H7JEV2SFk8zl9KrR = items[h17Zb2ld4yLBrCP5tiw]
		BfQEXlmstMPK762JyZnDA8 = int(xJG92hkptaqRIiDMKBmPwXr1uAHWzn) % int(iXlCG2W7y3KdELAh) + int(e6ncX1k4JKdgmSa) % int(thjavJxeHW6quwfDSKQP02Rl3ziL)
		url = HWJILAVRusgbDvOqUrzpCe1m + KJLgseu6fmCwXoHEOy7i + str(BfQEXlmstMPK762JyZnDA8) + H7JEV2SFk8zl9KrR
		return QigevCplXxbPI1H,[QigevCplXxbPI1H],[url]
	else: return hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡛ࠠࡋࡓࡔ࡞࡙ࡈࡂࡔࡈࠫᾨ"),[],[]
def KFa17tYgX6iC(url):
	id = url.split(OTRKI6LbrQnZEm(u"࠭࠯ࠨᾩ"))[-Fg72JX6T5DkPy(u"࠴࢙")]
	headers = { mpusoZBJ6V(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᾪ") : bDt7Ya1VEio3(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧᾫ") }
	A1AqSc2LNwW0ETgyaRl9 = { TCF8wLyDvgumfiXPSKRh(u"ࠤ࡬ࡨࠧᾬ"):id , Fg72JX6T5DkPy(u"ࠥࡳࡵࠨᾭ"):VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠢᾮ") }
	x9Ahuz3FVWmJDaNp5 = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,FF70emVxhWOngCty(u"ࠬࡖࡏࡔࡖࠪᾯ"), url, A1AqSc2LNwW0ETgyaRl9, headers, QigevCplXxbPI1H,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩᾰ"))
	if bDt7Ya1VEio3(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩᾱ") in list(x9Ahuz3FVWmJDaNp5.headers.keys()): RMC6c2kL5hGOnFaIwAyb = x9Ahuz3FVWmJDaNp5.headers[Fg72JX6T5DkPy(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᾲ")]
	else: RMC6c2kL5hGOnFaIwAyb = url
	if RMC6c2kL5hGOnFaIwAyb: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[RMC6c2kL5hGOnFaIwAyb]
	else: return y5yX4jh6kUEgWZQIc(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡖ࠴ࡖࡒࡏࡓࡆࡊࠧᾳ"),[],[]
def MaPtmv9NcsUdKurjq2Gb0SA3BR(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡊࡐࡗ࡚ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭ᾴ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(FF70emVxhWOngCty(u"ࠫࡲࡶ࠴࠻ࠢ࡟࡟ࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ᾵"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[ items[h17Zb2ld4yLBrCP5tiw] ]
	else: return VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪᾶ"),[],[]
def NNritfW7KyEPu(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,tOrSvd8QKNB(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡈࡎࡉࡗࡇ࠰࠵ࡸࡺࠧᾷ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᾸ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items:
		url = url = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡨ࡮ࡩࡷࡧ࠱ࡳࡷ࡭ࠧᾹ") + items[h17Zb2ld4yLBrCP5tiw]
		return QigevCplXxbPI1H,[QigevCplXxbPI1H],[ url ]
	else: return tOrSvd8QKNB(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡃࡉࡋ࡙ࡉࠬᾺ"),[],[]
def jdwxpu1b086qZQtRYge3DnS(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫΆ"))
	items = sBvufaD6c9YHdOqTjCQ3.findall(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᾼ"),aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items: return QigevCplXxbPI1H,[QigevCplXxbPI1H],[ items[h17Zb2ld4yLBrCP5tiw] ]
	else: return pGncXOodjKhJzLSqVP1r(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡕࡗࡖࡊࡇࡍࠨ᾽"),[],[]
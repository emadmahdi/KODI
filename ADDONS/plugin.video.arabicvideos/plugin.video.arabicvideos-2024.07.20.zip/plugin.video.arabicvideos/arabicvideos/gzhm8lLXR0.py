# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'BOKRA'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_BKR_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
headers = {'User-Agent':QigevCplXxbPI1H}
ef1pQcbEtPjMnXYrvOi = ['افلام للكبار','بكرا TV']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==370: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==371: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==372: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==374: W9lfsoMawqOzpQcXD = avE0UZshD72P(url)
	elif mode==375: W9lfsoMawqOzpQcXD = AZaidso3QULERMHG7Jtx(url)
	elif mode==376: W9lfsoMawqOzpQcXD = T7mUa8AHpXcM3Vsw(0,url)
	elif mode==377: W9lfsoMawqOzpQcXD = T7mUa8AHpXcM3Vsw(1,url)
	elif mode==379: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-MENU-1st')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,379,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'قنوات تلفزيونية',vxQUXEuH9m+'/al_1103560_1',371)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('right-side(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',vxQUXEuH9m,375)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الأحدث',vxQUXEuH9m,376)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'قائمة الممثلين',vxQUXEuH9m,374)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="container"(.*?)top-menu',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items[7:]:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371)
		for RMC6c2kL5hGOnFaIwAyb,title in items[0:7]:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371)
	return
def avE0UZshD72P(website=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-ACTORSMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="row cat Tags"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if 'http' in RMC6c2kL5hGOnFaIwAyb: continue
			else: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371)
	return
def AZaidso3QULERMHG7Jtx(website=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-FEATURED-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"MainContent"(.*?)main-title2',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
				cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('://',':///').replace('//','/').replace(hT7zFDpEyUqf8sXuN,'%20')
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,372,cXu4fN1moCypJqb72OZvd)
	return
def T7mUa8AHpXcM3Vsw(id,website=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-WATCHINGNOW-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-title2(.*?)class="row',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[id]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
				cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('://',':///').replace('//','/').replace(hT7zFDpEyUqf8sXuN,'%20')
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,372,cXu4fN1moCypJqb72OZvd)
	return
def ddbEXhWzOnIaR(url,dbCzTyu4VLtwxoQvqnHjiGUK=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if 'vidpage_' in url:
		RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('href="(/Album-.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if RMC6c2kL5hGOnFaIwAyb:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb[0]
			ddbEXhWzOnIaR(RMC6c2kL5hGOnFaIwAyb)
			return
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class=" subcats"(.*?)class="col-md-3',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if dbCzTyu4VLtwxoQvqnHjiGUK==QigevCplXxbPI1H and fwSu6JsQZpEiv and fwSu6JsQZpEiv[0].count('href')>1:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',url,371,QigevCplXxbPI1H,QigevCplXxbPI1H,'titles')
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+RMC6c2kL5hGOnFaIwAyb
			title = title.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371)
	else:
		wibHRCAFtsupIjx4ZTELeM = []
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="col-md-3(.*?)col-xs-12',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="col-sm-8"(.*?)col-xs-12',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
				RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
				title = title.strip(hT7zFDpEyUqf8sXuN)
				cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('://',':///').replace('//','/').replace(hT7zFDpEyUqf8sXuN,'%20')
				if '/al_' in RMC6c2kL5hGOnFaIwAyb:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371,cXu4fN1moCypJqb72OZvd)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) - +الحلقة +\d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					if V1nZX7O5WwEq8HmvkY: title = '_MOD_مسلسل '+V1nZX7O5WwEq8HmvkY[0]
					if title not in wibHRCAFtsupIjx4ZTELeM:
						wibHRCAFtsupIjx4ZTELeM.append(title)
						E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371,cXu4fN1moCypJqb72OZvd)
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,372,cXu4fN1moCypJqb72OZvd)
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('class="".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
				title = 'صفحة '+i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,371,QigevCplXxbPI1H,QigevCplXxbPI1H,'titles')
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('label-success mrg-btm-5 ">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = QigevCplXxbPI1H
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('var url = "(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[0]
	else: Kj0TOU6BmSMlJHZYLd = url.replace('/vidpage_','/Play/')
	if 'http' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+Kj0TOU6BmSMlJHZYLd
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.strip('-')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'BOKRA-PLAY-2nd')
	BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)"',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if NW6gmPcC1B4ILwdHTz0GlDsi5Fkx:
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = NW6gmPcC1B4ILwdHTz0GlDsi5Fkx[-1]
		if 'http' not in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = 'http:'+NW6gmPcC1B4ILwdHTz0GlDsi5Fkx
		if '/PLAY/' not in Kj0TOU6BmSMlJHZYLd:
			if 'embed.min.js' in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx:
				EYX8bNBsr2QJGWLuMV4jI = sBvufaD6c9YHdOqTjCQ3.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if EYX8bNBsr2QJGWLuMV4jI:
					RlaP8dkIQYWZTVX4NEMu, R1PobgEHFMnOK2hi59IpV = EYX8bNBsr2QJGWLuMV4jI[0]
					NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,'url')+'/v2/'+RlaP8dkIQYWZTVX4NEMu+'/config/'+R1PobgEHFMnOK2hi59IpV+'.json'
		import u8j7hmKf9V
		u8j7hmKf9V.v7h95wpulLk8HGNgezKM([NW6gmPcC1B4ILwdHTz0GlDsi5Fkx],PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/Search/'+search
	ddbEXhWzOnIaR(url)
	return
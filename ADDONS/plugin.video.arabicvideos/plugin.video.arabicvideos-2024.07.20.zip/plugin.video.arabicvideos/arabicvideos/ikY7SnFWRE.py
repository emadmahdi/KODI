# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'YOUTUBE'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_YUT_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
BBiHfPlIuejE2MrOx30cWQqX = 0
def YnMSWTbKj1N8wuRJVF(mode,url,text,type,JJM6TofH4g5n7SRwq,name,XGjn5q2cy6mRYZ1hPaDslHMK):
	if	 mode==140: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==141: W9lfsoMawqOzpQcXD = RfN78YzsLxK(url,name,XGjn5q2cy6mRYZ1hPaDslHMK)
	elif mode==143: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url,type)
	elif mode==144: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,JJM6TofH4g5n7SRwq,text)
	elif mode==145: W9lfsoMawqOzpQcXD = yyliWBxLn3IGjr(url,JJM6TofH4g5n7SRwq)
	elif mode==147: W9lfsoMawqOzpQcXD = VVjWIPZO0rGUT7uwJztF2CYmnBoq()
	elif mode==148: W9lfsoMawqOzpQcXD = O2R9vwCrX4VPNI()
	elif mode==149: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	if 0:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'قائمة',vxQUXEuH9m+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'شخص',vxQUXEuH9m+'/user/TCNofficial',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'موقع',vxQUXEuH9m+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'حساب',vxQUXEuH9m+'/@TheSocialCTV',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'العاب',vxQUXEuH9m+'/gaming',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'افلام',vxQUXEuH9m+'/feed/storefront',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مختارات',vxQUXEuH9m+'/feed/guide_builder',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'قصيرة',vxQUXEuH9m+'/shorts',144,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'تصفح',vxQUXEuH9m+'/youtubei/v1/guide?key=',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'رئيسية',vxQUXEuH9m+QigevCplXxbPI1H,144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'رائج',vxQUXEuH9m+'/feed/trending?bp=',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,149,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الرائجة',vxQUXEuH9m+'/feed/trending',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'التصفح',vxQUXEuH9m+'/youtubei/v1/guide?key=',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'القصيرة',vxQUXEuH9m+'/shorts',144,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مختارات يوتيوب',vxQUXEuH9m+'/feed/guide_builder',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مختارات البرنامج',QigevCplXxbPI1H,290)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: قنوات عربية',QigevCplXxbPI1H,147)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: قنوات أجنبية',QigevCplXxbPI1H,148)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: افلام عربية',vxQUXEuH9m+'/results?search_query=فيلم',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: افلام اجنبية',vxQUXEuH9m+'/results?search_query=movie',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسرحيات عربية',vxQUXEuH9m+'/results?search_query=مسرحية',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسلسلات عربية',vxQUXEuH9m+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسلسلات اجنبية',vxQUXEuH9m+'/results?search_query=series&sp=EgIQAw==',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسلسلات كارتون',vxQUXEuH9m+'/results?search_query=كارتون&sp=EgIQAw==',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: خطبة المرجعية',vxQUXEuH9m+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def RfN78YzsLxK(url,name,XGjn5q2cy6mRYZ1hPaDslHMK):
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'CHNL:  '+name,url,144,XGjn5q2cy6mRYZ1hPaDslHMK)
	return
def VVjWIPZO0rGUT7uwJztF2CYmnBoq():
	ddbEXhWzOnIaR(vxQUXEuH9m+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def O2R9vwCrX4VPNI():
	ddbEXhWzOnIaR(vxQUXEuH9m+'/results?search_query=tv&sp=EgJAAQ==')
	return
def nibvTq2jfRXDM4tYP039S(url,type):
	url = url.split('&',1)[0]
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM([url],PuT0IphGNsketAQ,type,url)
	return
def DEJRhy01nd(IoNA5ZqQwVR1Pl0fDm,url,nVWUleSBvsKaEhoCxNryf):
	level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = nVWUleSBvsKaEhoCxNryf.split('::')
	kaP2Oj14TDlM3v0cRnKz6WN,OWkKCv5Jdnts = [],[]
	if '/youtubei/v1/browse' in url: kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['onResponseReceivedCommands']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['entries']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['items'][3]['guideSectionRenderer']['items']")
	mmB1aHkywODc3JYRbMGT7NC0Keih,qdvl27skzgOoHSMnTUDjpPVeaY,qn1ztP8V7vfxY4A9L2lepJkb = cm6KydvI0B7e9JGDZF(IoNA5ZqQwVR1Pl0fDm,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
	if level=='1' and mmB1aHkywODc3JYRbMGT7NC0Keih:
		if len(qdvl27skzgOoHSMnTUDjpPVeaY)>1 and 'search_query' not in url:
			for tIzl5aXovVDWReF0fBbcjTnJ4Hpu in range(len(qdvl27skzgOoHSMnTUDjpPVeaY)):
				CmUe187SvDgsNFrfto = str(tIzl5aXovVDWReF0fBbcjTnJ4Hpu)
				kaP2Oj14TDlM3v0cRnKz6WN = []
				kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['reloadContinuationItemsCommand']['continuationItems']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['command']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]")
				AMu7aiqvPT6WcLOXDSkhFzdN,upHdVltvOIDPnN0SefZwGo4gJ9LqsY,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(qdvl27skzgOoHSMnTUDjpPVeaY,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
				if AMu7aiqvPT6WcLOXDSkhFzdN: OWkKCv5Jdnts.append([upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,'2::'+CmUe187SvDgsNFrfto+'::0::0'])
			kaP2Oj14TDlM3v0cRnKz6WN.append("yccc['continuationEndpoint']")
			AMu7aiqvPT6WcLOXDSkhFzdN,upHdVltvOIDPnN0SefZwGo4gJ9LqsY,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(IoNA5ZqQwVR1Pl0fDm,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
			if AMu7aiqvPT6WcLOXDSkhFzdN and OWkKCv5Jdnts and 'continuationCommand' in list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY.keys()):
				RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/my_main_page_shorts_link'
				OWkKCv5Jdnts.append([upHdVltvOIDPnN0SefZwGo4gJ9LqsY,RMC6c2kL5hGOnFaIwAyb,'1::0::0::0'])
	return qdvl27skzgOoHSMnTUDjpPVeaY,mmB1aHkywODc3JYRbMGT7NC0Keih,OWkKCv5Jdnts,qn1ztP8V7vfxY4A9L2lepJkb
def SX63j8i751smkA4ouLPenqChElH(IoNA5ZqQwVR1Pl0fDm,qdvl27skzgOoHSMnTUDjpPVeaY,url,nVWUleSBvsKaEhoCxNryf):
	level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = nVWUleSBvsKaEhoCxNryf.split('::')
	kaP2Oj14TDlM3v0cRnKz6WN,FAQVCWNflEukrsahbGdS5R3Bw = [],[]
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd[0]['itemSectionRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['reloadContinuationItemsCommand']['continuationItems']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: kaP2Oj14TDlM3v0cRnKz6WN.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: kaP2Oj14TDlM3v0cRnKz6WN.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yddd["+CmUe187SvDgsNFrfto+"]")
	DIhH2pcoCjvYs7ROBKV39b5XZ,LsqdSPg6yNmhiZY,OUW9g25zKDx0djr8L7PibCp6 = cm6KydvI0B7e9JGDZF(qdvl27skzgOoHSMnTUDjpPVeaY,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
	if level=='2' and DIhH2pcoCjvYs7ROBKV39b5XZ:
		if len(LsqdSPg6yNmhiZY)>1:
			for tIzl5aXovVDWReF0fBbcjTnJ4Hpu in range(len(LsqdSPg6yNmhiZY)):
				eoIWZ4mSdEOl = str(tIzl5aXovVDWReF0fBbcjTnJ4Hpu)
				kaP2Oj14TDlM3v0cRnKz6WN = []
				kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['richSectionRenderer']['content']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['richItemRenderer']['content']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]")
				AMu7aiqvPT6WcLOXDSkhFzdN,upHdVltvOIDPnN0SefZwGo4gJ9LqsY,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(LsqdSPg6yNmhiZY,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
				if AMu7aiqvPT6WcLOXDSkhFzdN: FAQVCWNflEukrsahbGdS5R3Bw.append([upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,'3::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::0'])
			kaP2Oj14TDlM3v0cRnKz6WN.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			kaP2Oj14TDlM3v0cRnKz6WN.append("yddd[1]")
			AMu7aiqvPT6WcLOXDSkhFzdN,upHdVltvOIDPnN0SefZwGo4gJ9LqsY,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(qdvl27skzgOoHSMnTUDjpPVeaY,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
			if AMu7aiqvPT6WcLOXDSkhFzdN and FAQVCWNflEukrsahbGdS5R3Bw and 'continuationItemRenderer' in list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY.keys()):
				FAQVCWNflEukrsahbGdS5R3Bw.append([upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,'3::0::0::0'])
	return LsqdSPg6yNmhiZY,DIhH2pcoCjvYs7ROBKV39b5XZ,FAQVCWNflEukrsahbGdS5R3Bw,OUW9g25zKDx0djr8L7PibCp6
def exCk1HwqaobZ4vlASMdpWUJyn0I9sB(IoNA5ZqQwVR1Pl0fDm,LsqdSPg6yNmhiZY,url,nVWUleSBvsKaEhoCxNryf):
	level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = nVWUleSBvsKaEhoCxNryf.split('::')
	kaP2Oj14TDlM3v0cRnKz6WN,WJf6xXStIecajlPR = [],[]
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['reelShelfRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee["+eoIWZ4mSdEOl+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yeee")
	UkY1bxX5wsZ2mHA9Ji,ejJ4O9yA5wPKcTl,g0LNXTbOweaUHExzk5iMf = cm6KydvI0B7e9JGDZF(LsqdSPg6yNmhiZY,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
	if level=='3' and UkY1bxX5wsZ2mHA9Ji:
		if len(ejJ4O9yA5wPKcTl)>0:
			for tIzl5aXovVDWReF0fBbcjTnJ4Hpu in range(len(ejJ4O9yA5wPKcTl)):
				YiIRAkKdZEs = str(tIzl5aXovVDWReF0fBbcjTnJ4Hpu)
				kaP2Oj14TDlM3v0cRnKz6WN = []
				kaP2Oj14TDlM3v0cRnKz6WN.append("yfff["+YiIRAkKdZEs+"]['richItemRenderer']['content']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yfff["+YiIRAkKdZEs+"]['gameCardRenderer']['game']")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yfff["+YiIRAkKdZEs+"]['itemSectionRenderer']['contents'][0]")
				kaP2Oj14TDlM3v0cRnKz6WN.append("yfff["+YiIRAkKdZEs+"]")
				AMu7aiqvPT6WcLOXDSkhFzdN,upHdVltvOIDPnN0SefZwGo4gJ9LqsY,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(ejJ4O9yA5wPKcTl,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
				if AMu7aiqvPT6WcLOXDSkhFzdN: WJf6xXStIecajlPR.append([upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,'4::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs])
	return ejJ4O9yA5wPKcTl,UkY1bxX5wsZ2mHA9Ji,WJf6xXStIecajlPR,g0LNXTbOweaUHExzk5iMf
def cm6KydvI0B7e9JGDZF(KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn,LgO5HKyr06T7iupoDM):
	IoNA5ZqQwVR1Pl0fDm,xJG92hkptaqRIiDMKBmPwXr1uAHWzn = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	qdvl27skzgOoHSMnTUDjpPVeaY,xJG92hkptaqRIiDMKBmPwXr1uAHWzn = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	LsqdSPg6yNmhiZY,xJG92hkptaqRIiDMKBmPwXr1uAHWzn = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	ejJ4O9yA5wPKcTl,xJG92hkptaqRIiDMKBmPwXr1uAHWzn = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	count = len(LgO5HKyr06T7iupoDM)
	for GzabfJx3T1 in range(count):
		try:
			BBLvPZi6eo9DO = eval(LgO5HKyr06T7iupoDM[GzabfJx3T1])
			return True,BBLvPZi6eo9DO,GzabfJx3T1+1
		except: pass
	return False,QigevCplXxbPI1H,0
def ddbEXhWzOnIaR(url,nVWUleSBvsKaEhoCxNryf=QigevCplXxbPI1H,data=QigevCplXxbPI1H):
	OWkKCv5Jdnts,FAQVCWNflEukrsahbGdS5R3Bw,WJf6xXStIecajlPR = [],[],[]
	if '::' not in nVWUleSBvsKaEhoCxNryf: nVWUleSBvsKaEhoCxNryf = '1::0::0::0'
	level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = nVWUleSBvsKaEhoCxNryf.split('::')
	if level=='4': level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = '1',CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs
	data = data.replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1,IoNA5ZqQwVR1Pl0fDm,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = TTbkMfupX6an9LBIYriy0G3hW(url,data)
	nVWUleSBvsKaEhoCxNryf = level+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
	if level in ['1','2','3']:
		qdvl27skzgOoHSMnTUDjpPVeaY,mmB1aHkywODc3JYRbMGT7NC0Keih,OWkKCv5Jdnts,qn1ztP8V7vfxY4A9L2lepJkb = DEJRhy01nd(IoNA5ZqQwVR1Pl0fDm,url,nVWUleSBvsKaEhoCxNryf)
		if not mmB1aHkywODc3JYRbMGT7NC0Keih: return
		V5Uy2sj6BD4zWketiCqpZuI = len(OWkKCv5Jdnts)
		if V5Uy2sj6BD4zWketiCqpZuI<2:
			if level=='1': level = '2'
			OWkKCv5Jdnts = []
	nVWUleSBvsKaEhoCxNryf = level+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
	if level in ['2','3']:
		LsqdSPg6yNmhiZY,DIhH2pcoCjvYs7ROBKV39b5XZ,FAQVCWNflEukrsahbGdS5R3Bw,OUW9g25zKDx0djr8L7PibCp6 = SX63j8i751smkA4ouLPenqChElH(IoNA5ZqQwVR1Pl0fDm,qdvl27skzgOoHSMnTUDjpPVeaY,url,nVWUleSBvsKaEhoCxNryf)
		if not DIhH2pcoCjvYs7ROBKV39b5XZ: return
		zyndDKf6GoREN = len(FAQVCWNflEukrsahbGdS5R3Bw)
		if zyndDKf6GoREN<2:
			if level=='2': level = '3'
			FAQVCWNflEukrsahbGdS5R3Bw = []
	nVWUleSBvsKaEhoCxNryf = level+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
	if level in ['3']:
		ejJ4O9yA5wPKcTl,UkY1bxX5wsZ2mHA9Ji,WJf6xXStIecajlPR,g0LNXTbOweaUHExzk5iMf = exCk1HwqaobZ4vlASMdpWUJyn0I9sB(IoNA5ZqQwVR1Pl0fDm,LsqdSPg6yNmhiZY,url,nVWUleSBvsKaEhoCxNryf)
		if not UkY1bxX5wsZ2mHA9Ji: return
		a5CdPjZAV7lOIJbKm06e = len(WJf6xXStIecajlPR)
	for upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,nVWUleSBvsKaEhoCxNryf in OWkKCv5Jdnts+FAQVCWNflEukrsahbGdS5R3Bw+WJf6xXStIecajlPR:
		nPjzT9ZKLxm40kNytH2WsQEI = SlrbqDyBJVPRY(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,nVWUleSBvsKaEhoCxNryf)
	return
def SlrbqDyBJVPRY(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url=QigevCplXxbPI1H,nVWUleSBvsKaEhoCxNryf=QigevCplXxbPI1H):
	if '::' in nVWUleSBvsKaEhoCxNryf: level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = nVWUleSBvsKaEhoCxNryf.split('::')
	else: level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = '1','0','0','0'
	AMu7aiqvPT6WcLOXDSkhFzdN,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1,TAxseg8oyH6UREziw = XLkKvrOTGz(upHdVltvOIDPnN0SefZwGo4gJ9LqsY)
	Zn2yQOf6lWMt9pUeuvcCR51JNIwiB = '/videos?' in RMC6c2kL5hGOnFaIwAyb or '/streams?' in RMC6c2kL5hGOnFaIwAyb or '/playlists?' in RMC6c2kL5hGOnFaIwAyb
	K0ycsNJSEtzfUiAM8Bg92YblId = '/channels?' in RMC6c2kL5hGOnFaIwAyb or '/shorts?' in RMC6c2kL5hGOnFaIwAyb
	if Zn2yQOf6lWMt9pUeuvcCR51JNIwiB or K0ycsNJSEtzfUiAM8Bg92YblId: RMC6c2kL5hGOnFaIwAyb = url
	Zn2yQOf6lWMt9pUeuvcCR51JNIwiB = 'watch?v=' not in RMC6c2kL5hGOnFaIwAyb and '/playlist?list=' not in RMC6c2kL5hGOnFaIwAyb
	K0ycsNJSEtzfUiAM8Bg92YblId = '/gaming' not in RMC6c2kL5hGOnFaIwAyb  and '/feed/storefront' not in RMC6c2kL5hGOnFaIwAyb
	if nVWUleSBvsKaEhoCxNryf[0:5]=='3::0::' and Zn2yQOf6lWMt9pUeuvcCR51JNIwiB and K0ycsNJSEtzfUiAM8Bg92YblId: RMC6c2kL5hGOnFaIwAyb = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in RMC6c2kL5hGOnFaIwAyb:
		level,CmUe187SvDgsNFrfto,eoIWZ4mSdEOl,YiIRAkKdZEs = '1','0','0','0'
		nVWUleSBvsKaEhoCxNryf = QigevCplXxbPI1H
	tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = QigevCplXxbPI1H
	if '/youtubei/v1/browse' in RMC6c2kL5hGOnFaIwAyb or '/youtubei/v1/search' in RMC6c2kL5hGOnFaIwAyb or '/my_main_page_shorts_link' in url:
		data = uUTRHgAXJzm7pIDBjNt8.getSetting('av.youtube.data')
		if data.count(':::')==4:
			BrbMc7vuG6PW5AR8qhsHpE4X,key,XQTUfehBIlNCSqsmw,kkWeUiTQDrVBLzNZHsc7IApG8aRv,F01WAKej2RtVrpXQvi = data.split(':::')
			tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = BrbMc7vuG6PW5AR8qhsHpE4X+':::'+key+':::'+XQTUfehBIlNCSqsmw+':::'+kkWeUiTQDrVBLzNZHsc7IApG8aRv+':::'+TAxseg8oyH6UREziw
			if '/my_main_page_shorts_link' in url and not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = url
			else: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?key='+key
	if not title:
		global BBiHfPlIuejE2MrOx30cWQqX
		BBiHfPlIuejE2MrOx30cWQqX += 1
		title = 'فيديوهات '+str(BBiHfPlIuejE2MrOx30cWQqX)
		nVWUleSBvsKaEhoCxNryf = '3'+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
	if not AMu7aiqvPT6WcLOXDSkhFzdN: return False
	elif 'searchPyvRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY): return False
	elif '/about' in RMC6c2kL5hGOnFaIwAyb: return False
	elif '/community' in RMC6c2kL5hGOnFaIwAyb: return False
	elif 'continuationItemRenderer' in list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY.keys()) or 'continuationCommand' in list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY.keys()):
		if int(level)>1: level = str(int(level)-1)
		nVWUleSBvsKaEhoCxNryf = level+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: '+'صفحة أخرى',RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf,tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
	elif '/search' in RMC6c2kL5hGOnFaIwAyb:
		title = ':: '+title
		nVWUleSBvsKaEhoCxNryf = '3'+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
		url = url.replace('/search',QigevCplXxbPI1H)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,145,QigevCplXxbPI1H,nVWUleSBvsKaEhoCxNryf,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not RMC6c2kL5hGOnFaIwAyb:
		nVWUleSBvsKaEhoCxNryf = '3'+'::'+CmUe187SvDgsNFrfto+'::'+eoIWZ4mSdEOl+'::'+YiIRAkKdZEs
		title = ':: '+title
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf,tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
	elif '/browse' in RMC6c2kL5hGOnFaIwAyb and url==vxQUXEuH9m:
		title = ':: '+title
		nVWUleSBvsKaEhoCxNryf = '2::0::0::0'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf,tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
	elif not RMC6c2kL5hGOnFaIwAyb and 'horizontalMovieListRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY):
		title = ':: '+title
		nVWUleSBvsKaEhoCxNryf = '3::0::0::0'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf)
	elif 'messageRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY):
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,9999)
	elif uRZUlrefpBCJmI0h4xEb:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+uRZUlrefpBCJmI0h4xEb+title,RMC6c2kL5hGOnFaIwAyb,143,cXu4fN1moCypJqb72OZvd)
	elif '/playlist?list=' in RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('&playnext=1',QigevCplXxbPI1H)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'LIST'+count+':  '+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf)
	elif '/shorts/' in RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.split('&list=',1)[0]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,143,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr)
	elif '/watch?v=' in RMC6c2kL5hGOnFaIwAyb:
		if '&list=' in RMC6c2kL5hGOnFaIwAyb and count:
			NhOoFyHwcx9IDAXbY0UmPEnT5suZV = RMC6c2kL5hGOnFaIwAyb.split('&list=',1)[1]
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/playlist?list='+NhOoFyHwcx9IDAXbY0UmPEnT5suZV
			nVWUleSBvsKaEhoCxNryf = '3::0::0::0'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'LIST'+count+':  '+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf)
		else:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.split('&list=',1)[0]
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,143,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr)
	elif '/channel/' in RMC6c2kL5hGOnFaIwAyb or '/c/' in RMC6c2kL5hGOnFaIwAyb or ('/@' in RMC6c2kL5hGOnFaIwAyb and RMC6c2kL5hGOnFaIwAyb.count('/')==3):
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			title = title.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL).encode('raw_unicode_escape')
			title = arFSQucmG9HxDody67JCI8pBMk4L(title)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'CHNL'+count+':  '+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf)
	elif '/user/' in RMC6c2kL5hGOnFaIwAyb:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'USER'+count+':  '+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf)
	else:
		if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = url
		title = ':: '+title
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,nVWUleSBvsKaEhoCxNryf,tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
	return True
def XLkKvrOTGz(upHdVltvOIDPnN0SefZwGo4gJ9LqsY):
	AMu7aiqvPT6WcLOXDSkhFzdN,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1,F01WAKej2RtVrpXQvi = False,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	if not isinstance(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,dict): return AMu7aiqvPT6WcLOXDSkhFzdN,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1,F01WAKej2RtVrpXQvi
	for vjcyxK0CoYD in list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY.keys()):
		FojXmS53yDaP0i4Tn6Cz9k = upHdVltvOIDPnN0SefZwGo4gJ9LqsY[vjcyxK0CoYD]
		if isinstance(FojXmS53yDaP0i4Tn6Cz9k,dict): break
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['header']['richListHeaderRenderer']['title']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['headline']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['unplayableText']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['formattedTitle']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['title']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['title']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['text']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['text']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['title']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['title']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['reelWatchEndpoint']['videoId']")
	AMu7aiqvPT6WcLOXDSkhFzdN,title,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['commandMetadata']['webCommandMetadata']['url']")
	AMu7aiqvPT6WcLOXDSkhFzdN,RMC6c2kL5hGOnFaIwAyb,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnail']['thumbnails'][0]['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	AMu7aiqvPT6WcLOXDSkhFzdN,cXu4fN1moCypJqb72OZvd,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['videoCount']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['videoCountText']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	AMu7aiqvPT6WcLOXDSkhFzdN,count,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['lengthText']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	AMu7aiqvPT6WcLOXDSkhFzdN,ThO0AMm4jUGP9yr,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	AMu7aiqvPT6WcLOXDSkhFzdN,F01WAKej2RtVrpXQvi,BLIwYgHkv25j1d6DsEUl3rae7M = cm6KydvI0B7e9JGDZF(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,FojXmS53yDaP0i4Tn6Cz9k,kaP2Oj14TDlM3v0cRnKz6WN)
	if 'LIVE' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb = QigevCplXxbPI1H,'LIVE:  '
	if 'مباشر' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb = QigevCplXxbPI1H,'LIVE:  '
	if 'badges' in list(FojXmS53yDaP0i4Tn6Cz9k.keys()):
		b6pZVEYMyaj0zdDCrNHk4nwQWmSho9 = str(FojXmS53yDaP0i4Tn6Cz9k['badges'])
		if 'Free with Ads' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$:  '
		if 'LIVE' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: uRZUlrefpBCJmI0h4xEb = 'LIVE:  '
		if 'Buy' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9 or 'Rent' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$$:  '
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'مباشر') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: uRZUlrefpBCJmI0h4xEb = 'LIVE:  '
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'شراء') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$$:  '
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'استئجار') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$$:  '
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'إعلانات') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$:  '
	RMC6c2kL5hGOnFaIwAyb = arFSQucmG9HxDody67JCI8pBMk4L(RMC6c2kL5hGOnFaIwAyb)
	if RMC6c2kL5hGOnFaIwAyb and 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
	cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.split('?')[0]
	if  cXu4fN1moCypJqb72OZvd and 'http' not in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = 'https:'+cXu4fN1moCypJqb72OZvd
	title = arFSQucmG9HxDody67JCI8pBMk4L(title)
	if mnriNIfKFPuaYTDAEcWMwGS65Lvb1: title = mnriNIfKFPuaYTDAEcWMwGS65Lvb1+title
	ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.replace(',',QigevCplXxbPI1H)
	count = count.replace(',',QigevCplXxbPI1H)
	count = sBvufaD6c9YHdOqTjCQ3.findall('\d+',count)
	if count: count = count[0]
	else: count = QigevCplXxbPI1H
	return True,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1,F01WAKej2RtVrpXQvi
def TTbkMfupX6an9LBIYriy0G3hW(url,data=QigevCplXxbPI1H,x9Ahuz3FVWmJDaNp5=QigevCplXxbPI1H):
	if x9Ahuz3FVWmJDaNp5==QigevCplXxbPI1H: x9Ahuz3FVWmJDaNp5 = 'ytInitialData'
	lfPqTpgMXhVcd = eUBL1rOR4ZfndJAWPsoN6pybT0()
	T24Te3uDwBS5vLgUEAhF1O = {'User-Agent':lfPqTpgMXhVcd,'Cookie':'PREF=hl=ar'}
	global uUTRHgAXJzm7pIDBjNt8
	if not data: data = uUTRHgAXJzm7pIDBjNt8.getSetting('av.youtube.data')
	if data.count(':::')==4: BrbMc7vuG6PW5AR8qhsHpE4X,key,XQTUfehBIlNCSqsmw,kkWeUiTQDrVBLzNZHsc7IApG8aRv,F01WAKej2RtVrpXQvi = data.split(':::')
	else: BrbMc7vuG6PW5AR8qhsHpE4X,key,XQTUfehBIlNCSqsmw,kkWeUiTQDrVBLzNZHsc7IApG8aRv,F01WAKej2RtVrpXQvi = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":XQTUfehBIlNCSqsmw}}}
	if url==vxQUXEuH9m+'/shorts' or '/my_main_page_shorts_link' in url:
		url = vxQUXEuH9m+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1['sequenceParams'] = BrbMc7vuG6PW5AR8qhsHpE4X
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = str(tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',url,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = vxQUXEuH9m+'/youtubei/v1/guide?key='+key
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = str(tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',url,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and BrbMc7vuG6PW5AR8qhsHpE4X:
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1['continuation'] = F01WAKej2RtVrpXQvi
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1['context']['client']['visitorData'] = BrbMc7vuG6PW5AR8qhsHpE4X
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = str(tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',url,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and kkWeUiTQDrVBLzNZHsc7IApG8aRv:
		T24Te3uDwBS5vLgUEAhF1O.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':XQTUfehBIlNCSqsmw})
		T24Te3uDwBS5vLgUEAhF1O.update({'Cookie':'VISITOR_INFO1_LIVE='+kkWeUiTQDrVBLzNZHsc7IApG8aRv})
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'YOUTUBE-GET_PAGE_DATA-6th')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall('"innertubeApiKey".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if UX3RT0evEunCm2cHIz1Qs: key = UX3RT0evEunCm2cHIz1Qs[0]
	UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall('"cver".*?"value".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if UX3RT0evEunCm2cHIz1Qs: XQTUfehBIlNCSqsmw = UX3RT0evEunCm2cHIz1Qs[0]
	UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall('"visitorData".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if UX3RT0evEunCm2cHIz1Qs: BrbMc7vuG6PW5AR8qhsHpE4X = UX3RT0evEunCm2cHIz1Qs[0]
	cookies = JJrhP4C6osGDFEKVSRBvX.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): kkWeUiTQDrVBLzNZHsc7IApG8aRv = cookies['VISITOR_INFO1_LIVE']
	aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU = BrbMc7vuG6PW5AR8qhsHpE4X+':::'+key+':::'+XQTUfehBIlNCSqsmw+':::'+kkWeUiTQDrVBLzNZHsc7IApG8aRv+':::'+F01WAKej2RtVrpXQvi
	if x9Ahuz3FVWmJDaNp5=='ytInitialData' and 'ytInitialData' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		f0HesnbtUICXMwg71RNxJkj = sBvufaD6c9YHdOqTjCQ3.findall('window\["ytInitialData"\] = ({.*?});',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not f0HesnbtUICXMwg71RNxJkj: f0HesnbtUICXMwg71RNxJkj = sBvufaD6c9YHdOqTjCQ3.findall('var ytInitialData = ({.*?});',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ddSFGVHhyYW1Uwmu27c5n3f0 = CH86N7xw4cyPt3TlIBJF('str',f0HesnbtUICXMwg71RNxJkj[0])
	elif x9Ahuz3FVWmJDaNp5=='ytInitialGuideData' and 'ytInitialGuideData' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		f0HesnbtUICXMwg71RNxJkj = sBvufaD6c9YHdOqTjCQ3.findall('var ytInitialGuideData = ({.*?});',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ddSFGVHhyYW1Uwmu27c5n3f0 = CH86N7xw4cyPt3TlIBJF('str',f0HesnbtUICXMwg71RNxJkj[0])
	elif '</script>' not in aY63L2NhgvwJIxPAoDG4MKECmZXF1: ddSFGVHhyYW1Uwmu27c5n3f0 = CH86N7xw4cyPt3TlIBJF('str',aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	else: ddSFGVHhyYW1Uwmu27c5n3f0 = QigevCplXxbPI1H
	if 0:
		IoNA5ZqQwVR1Pl0fDm = str(ddSFGVHhyYW1Uwmu27c5n3f0)
		if b7sJAmSxlBvaMdHFz: IoNA5ZqQwVR1Pl0fDm = IoNA5ZqQwVR1Pl0fDm.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		open('S:\\0000emad.dat','wb').write(IoNA5ZqQwVR1Pl0fDm)
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.youtube.data',aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1,ddSFGVHhyYW1Uwmu27c5n3f0,aXVQgnCo0NGE6Tqpi53rm7ADKBbMvU
def yyliWBxLn3IGjr(url,nVWUleSBvsKaEhoCxNryf):
	search = XAfEvmh95VkgurjdiJ()
	if not search: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	Kj0TOU6BmSMlJHZYLd = url+'/search?query='+search
	ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd,nVWUleSBvsKaEhoCxNryf)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search:
		search = XAfEvmh95VkgurjdiJ()
		if not search: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in iBux5zA0swygKtRlDCTH: Ah0IaXwQtLdvi1KqepTxl = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in iBux5zA0swygKtRlDCTH: Ah0IaXwQtLdvi1KqepTxl = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in iBux5zA0swygKtRlDCTH: Ah0IaXwQtLdvi1KqepTxl = '&sp=EgIQAg%253D%253D'
		else: Ah0IaXwQtLdvi1KqepTxl = QigevCplXxbPI1H
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd+Ah0IaXwQtLdvi1KqepTxl
	else:
		FGB46mLk5PhAR2,t4s6NDyvabFYZrG3AqgPuwndeEm,YIwQJyV0hAUR1EfKogObLzDMmx = [],[],QigevCplXxbPI1H
		pVBRbowMOytmDnqCufzhAk8Uxr9cN = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		Sb2w4FnDy0gxMYEAILCofzPvtk = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		da7w53zb6kXqj4 = zYWJO03iISD('اختر البحث المناسب',pVBRbowMOytmDnqCufzhAk8Uxr9cN)
		if da7w53zb6kXqj4 == -1: return
		wU4Gpn97WR2aXe53dF8vj = Sb2w4FnDy0gxMYEAILCofzPvtk[da7w53zb6kXqj4]
		aY63L2NhgvwJIxPAoDG4MKECmZXF1,ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm,data = TTbkMfupX6an9LBIYriy0G3hW(Kj0TOU6BmSMlJHZYLd+wU4Gpn97WR2aXe53dF8vj)
		if ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm:
			try:
				lWpU8hve642Qdm9BJoKjVrIf = ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for EgbAKlvHdGzt6UrmZeI7MyxW in range(len(lWpU8hve642Qdm9BJoKjVrIf)):
					group = lWpU8hve642Qdm9BJoKjVrIf[EgbAKlvHdGzt6UrmZeI7MyxW]['searchFilterGroupRenderer']['filters']
					for es4CZNxAmEz3B67 in range(len(group)):
						FojXmS53yDaP0i4Tn6Cz9k = group[es4CZNxAmEz3B67]['searchFilterRenderer']
						if 'navigationEndpoint' in list(FojXmS53yDaP0i4Tn6Cz9k.keys()):
							RMC6c2kL5hGOnFaIwAyb = FojXmS53yDaP0i4Tn6Cz9k['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('\u0026','&')
							title = FojXmS53yDaP0i4Tn6Cz9k['tooltip']
							title = title.replace('البحث عن ',QigevCplXxbPI1H)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								YIwQJyV0hAUR1EfKogObLzDMmx = title
								Wdek0SptsHCKog19OBJDTRAX7m = RMC6c2kL5hGOnFaIwAyb
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',QigevCplXxbPI1H)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								YIwQJyV0hAUR1EfKogObLzDMmx = title
								Wdek0SptsHCKog19OBJDTRAX7m = RMC6c2kL5hGOnFaIwAyb
							if 'Sort by' in title: continue
							FGB46mLk5PhAR2.append(arFSQucmG9HxDody67JCI8pBMk4L(title))
							t4s6NDyvabFYZrG3AqgPuwndeEm.append(RMC6c2kL5hGOnFaIwAyb)
			except: pass
		if not YIwQJyV0hAUR1EfKogObLzDMmx: c9HDFTKdLpJhZMIQN0nymg = QigevCplXxbPI1H
		else:
			FGB46mLk5PhAR2 = ['بدون فلتر',YIwQJyV0hAUR1EfKogObLzDMmx]+FGB46mLk5PhAR2
			t4s6NDyvabFYZrG3AqgPuwndeEm = [QigevCplXxbPI1H,Wdek0SptsHCKog19OBJDTRAX7m]+t4s6NDyvabFYZrG3AqgPuwndeEm
			nFwGpZdzDsfP4 = zYWJO03iISD('موقع يوتيوب - اختر الفلتر',FGB46mLk5PhAR2)
			if nFwGpZdzDsfP4 == -1: return
			c9HDFTKdLpJhZMIQN0nymg = t4s6NDyvabFYZrG3AqgPuwndeEm[nFwGpZdzDsfP4]
		if c9HDFTKdLpJhZMIQN0nymg: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = vxQUXEuH9m+c9HDFTKdLpJhZMIQN0nymg
		elif wU4Gpn97WR2aXe53dF8vj: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd+wU4Gpn97WR2aXe53dF8vj
		else: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd
	ddbEXhWzOnIaR(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
	return
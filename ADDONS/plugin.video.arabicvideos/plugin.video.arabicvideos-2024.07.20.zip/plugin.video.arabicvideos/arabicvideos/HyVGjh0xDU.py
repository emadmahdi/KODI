# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'EGYBESTVIP'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_EGV_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
def YnMSWTbKj1N8wuRJVF(mode,url,JJM6TofH4g5n7SRwq,text):
	if   mode==220: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==221: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,JJM6TofH4g5n7SRwq)
	elif mode==222: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==223: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==224: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url)
	elif mode==229: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,229,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="i i-home"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,222)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="ba(.*?)<script',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for title,RMC6c2kL5hGOnFaIwAyb in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,221)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if 'html' not in RMC6c2kL5hGOnFaIwAyb: continue
			if not RMC6c2kL5hGOnFaIwAyb.endswith('/'): E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,221)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def eR6YT8AbXwl(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-SUBMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="rs_scroll"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,224)
	return
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url):
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',url,221)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-FILTERS_MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="sub_nav(.*?)id="movies',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".+?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if RMC6c2kL5hGOnFaIwAyb=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,221)
	else: ddbEXhWzOnIaR(url)
	return
def ddbEXhWzOnIaR(url,JJM6TofH4g5n7SRwq='1'):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	if '/search' in url or '?' in url: Kj0TOU6BmSMlJHZYLd = url + '&'
	else: Kj0TOU6BmSMlJHZYLd = url + '?'
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd + 'page=' + JJM6TofH4g5n7SRwq
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		fwSu6JsQZpEiv=sBvufaD6c9YHdOqTjCQ3.findall('class="pda"(.*?)div',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[-1]
	elif '/series/' in url:
		fwSu6JsQZpEiv=sBvufaD6c9YHdOqTjCQ3.findall('class="owl-carousel owl-carousel(.*?)div',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	else:
		fwSu6JsQZpEiv=sBvufaD6c9YHdOqTjCQ3.findall('id="movies(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[-1]
	items = sBvufaD6c9YHdOqTjCQ3.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if '/movie/' in RMC6c2kL5hGOnFaIwAyb or '/episode' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb.rstrip('/'),223,cXu4fN1moCypJqb72OZvd)
		else:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,221,cXu4fN1moCypJqb72OZvd)
	if len(items)>=16:
		ERZfti7TcIjuO0MB = ['/movies','/tv','/search','/trending']
		JJM6TofH4g5n7SRwq = int(JJM6TofH4g5n7SRwq)
		if any(nFdGHjceZzW in url for nFdGHjceZzW in ERZfti7TcIjuO0MB):
			for v3rj8X6lDnbAxkQMFaP0TKh in range(0,1000,100):
				if int(JJM6TofH4g5n7SRwq/100)*100==v3rj8X6lDnbAxkQMFaP0TKh:
					for A5SjhJUg37pNiMC4Eot6lOF in range(v3rj8X6lDnbAxkQMFaP0TKh,v3rj8X6lDnbAxkQMFaP0TKh+100,10):
						if int(JJM6TofH4g5n7SRwq/10)*10==A5SjhJUg37pNiMC4Eot6lOF:
							for ucq82anY4dC6sy3ZO9Fglkpix in range(A5SjhJUg37pNiMC4Eot6lOF,A5SjhJUg37pNiMC4Eot6lOF+10,1):
								if not JJM6TofH4g5n7SRwq==ucq82anY4dC6sy3ZO9Fglkpix and ucq82anY4dC6sy3ZO9Fglkpix!=0:
									E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+str(ucq82anY4dC6sy3ZO9Fglkpix),url,221,QigevCplXxbPI1H,str(ucq82anY4dC6sy3ZO9Fglkpix))
						elif A5SjhJUg37pNiMC4Eot6lOF!=0: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+str(A5SjhJUg37pNiMC4Eot6lOF),url,221,QigevCplXxbPI1H,str(A5SjhJUg37pNiMC4Eot6lOF))
						else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+str(1),url,221,QigevCplXxbPI1H,str(1))
				elif v3rj8X6lDnbAxkQMFaP0TKh!=0: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+str(v3rj8X6lDnbAxkQMFaP0TKh),url,221,QigevCplXxbPI1H,str(v3rj8X6lDnbAxkQMFaP0TKh))
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+str(1),url,221)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = [],[]
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-PLAY-1st')
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('<td>التصنيف</td>.*?">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	QnAdNfZcMqEtXxY9yaRThuD8CzU7,vu7TjA4N6YeMEFQsSKDqBICXyG9oZa = QigevCplXxbPI1H,QigevCplXxbPI1H
	dPRMJetTbKNF1p09oIvY753VxUED6,dA1O7EH8593RKQh064SIYZra = aY63L2NhgvwJIxPAoDG4MKECmZXF1,aY63L2NhgvwJIxPAoDG4MKECmZXF1
	JsSZxG6WydBwUubkgA2 = sBvufaD6c9YHdOqTjCQ3.findall('show_dl api" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if JsSZxG6WydBwUubkgA2:
		for RMC6c2kL5hGOnFaIwAyb in JsSZxG6WydBwUubkgA2:
			if '/watch/' in RMC6c2kL5hGOnFaIwAyb: QnAdNfZcMqEtXxY9yaRThuD8CzU7 = RMC6c2kL5hGOnFaIwAyb
			elif '/download/' in RMC6c2kL5hGOnFaIwAyb: vu7TjA4N6YeMEFQsSKDqBICXyG9oZa = RMC6c2kL5hGOnFaIwAyb
		if QnAdNfZcMqEtXxY9yaRThuD8CzU7!=QigevCplXxbPI1H: dPRMJetTbKNF1p09oIvY753VxUED6 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,QnAdNfZcMqEtXxY9yaRThuD8CzU7,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-PLAY-2nd')
		if vu7TjA4N6YeMEFQsSKDqBICXyG9oZa!=QigevCplXxbPI1H: dA1O7EH8593RKQh064SIYZra = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vu7TjA4N6YeMEFQsSKDqBICXyG9oZa,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-PLAY-3rd')
	CCnO1xcY8Rav6zoG = sBvufaD6c9YHdOqTjCQ3.findall('id="video".*?data-src="(.*?)"',dPRMJetTbKNF1p09oIvY753VxUED6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if CCnO1xcY8Rav6zoG:
		Kj0TOU6BmSMlJHZYLd = CCnO1xcY8Rav6zoG[0]
		if Kj0TOU6BmSMlJHZYLd!=QigevCplXxbPI1H and 'uploaded.egybest.download' in Kj0TOU6BmSMlJHZYLd and '/?id=_' not in Kj0TOU6BmSMlJHZYLd:
			BhxM1UVjtbEoSp640kIcag = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-PLAY-4th')
			EXp6ztn1Yr8cdPMILom = sBvufaD6c9YHdOqTjCQ3.findall('source src="(.*?)" title="(.*?)"',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if EXp6ztn1Yr8cdPMILom:
				for RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS in EXp6ztn1Yr8cdPMILom:
					ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb+'?named=ed.egybest.do__watch__mp4__'+oI6LvXMf4VEPe8jOdpKC0hUmS)
			else:
				bSrdN78jxURTvh9 = Kj0TOU6BmSMlJHZYLd.split('/')[2]
				ldFqnNIsftrY43JBM6LPjzU8m.append(Kj0TOU6BmSMlJHZYLd+'?named='+bSrdN78jxURTvh9+'__watch')
		elif Kj0TOU6BmSMlJHZYLd!=QigevCplXxbPI1H:
			bSrdN78jxURTvh9 = Kj0TOU6BmSMlJHZYLd.split('/')[2]
			ldFqnNIsftrY43JBM6LPjzU8m.append(Kj0TOU6BmSMlJHZYLd+'?named='+bSrdN78jxURTvh9+'__watch')
	LRGcxUHlZw = sBvufaD6c9YHdOqTjCQ3.findall('<table class="dls_table(.*?)</table>',dA1O7EH8593RKQh064SIYZra,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if LRGcxUHlZw:
		LRGcxUHlZw = LRGcxUHlZw[0]
		YNESrahqeFX71gT0iB = sBvufaD6c9YHdOqTjCQ3.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',LRGcxUHlZw,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if YNESrahqeFX71gT0iB:
			for oI6LvXMf4VEPe8jOdpKC0hUmS,RMC6c2kL5hGOnFaIwAyb in YNESrahqeFX71gT0iB:
				if 'myegyvip' not in RMC6c2kL5hGOnFaIwAyb: continue
				if RMC6c2kL5hGOnFaIwAyb.count('/')>=2:
					bSrdN78jxURTvh9 = RMC6c2kL5hGOnFaIwAyb.split('/')[2]
					ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb+'?named='+bSrdN78jxURTvh9+'__download__mp4__'+oI6LvXMf4VEPe8jOdpKC0hUmS)
	rjlBpomcFhUsDGY423A9 = []
	for RMC6c2kL5hGOnFaIwAyb in ldFqnNIsftrY43JBM6LPjzU8m:
		rjlBpomcFhUsDGY423A9.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(rjlBpomcFhUsDGY423A9,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'+')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBESTVIP-SEARCH-1st')
	F01WAKej2RtVrpXQvi = sBvufaD6c9YHdOqTjCQ3.findall('name="_token" value="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if F01WAKej2RtVrpXQvi:
		url = vxQUXEuH9m+'/search?_token='+F01WAKej2RtVrpXQvi[0]+'&q='+VIo6FYRkx0MLP4wufEGsgnz9
		ddbEXhWzOnIaR(url)
	return
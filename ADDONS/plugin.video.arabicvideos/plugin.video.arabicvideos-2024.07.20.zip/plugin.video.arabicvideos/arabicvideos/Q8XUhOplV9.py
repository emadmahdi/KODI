# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'SHAHID4U'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_SH4_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==110: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==111: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==112: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==113: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url,True)
	elif mode==114: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'FULL_FILTER___'+text)
	elif mode==115: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'DEFINED_FILTER___'+text)
	elif mode==116: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url,False)
	elif mode==119: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	headers = {'User-Agent':eUBL1rOR4ZfndJAWPsoN6pybT0(True)}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(JJrhP4C6osGDFEKVSRBvX.url,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,119,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',unA4F0ajXBUwHksrx3IyNCJL,115)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',unA4F0ajXBUwHksrx3IyNCJL,114)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',unA4F0ajXBUwHksrx3IyNCJL,111,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('simple-filter(.*?)adv-filter',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for filter,cXu4fN1moCypJqb72OZvd,title in items:
			url = unA4F0ajXBUwHksrx3IyNCJL+filter
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,111,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,filter)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="dropdown"(.*?)<script>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			if title in ef1pQcbEtPjMnXYrvOi: continue
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+RMC6c2kL5hGOnFaIwAyb
			if 'netflix' in RMC6c2kL5hGOnFaIwAyb: title = 'نيتفلكس'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,111)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,ZDQqkvbtHmB4=QigevCplXxbPI1H,JJrhP4C6osGDFEKVSRBvX=QigevCplXxbPI1H):
	headers = {'User-Agent':eUBL1rOR4ZfndJAWPsoN6pybT0(True)}
	if not JJrhP4C6osGDFEKVSRBvX: JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv,items,wibHRCAFtsupIjx4ZTELeM = [],[],[]
	if ZDQqkvbtHmB4=='featured': fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('glide__slides(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('shows-container(.*?)pagination',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv: return
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if 'WWE' in title: continue
		if 'javascript' in RMC6c2kL5hGOnFaIwAyb: continue
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb).strip('/')
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		title = title.strip(hT7zFDpEyUqf8sXuN)
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if '/film/' in RMC6c2kL5hGOnFaIwAyb or 'فيلم' in RMC6c2kL5hGOnFaIwAyb or any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,112,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,113,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif '/actor/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,111,cXu4fN1moCypJqb72OZvd)
		elif '/series/' in RMC6c2kL5hGOnFaIwAyb and '/list' not in url:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'/list'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,111,cXu4fN1moCypJqb72OZvd)
		elif '/list' in url and 'حلقة' in title:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,112,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,113,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		if ZDQqkvbtHmB4!='search': items = sBvufaD6c9YHdOqTjCQ3.findall('(updateQuery).*?>(.+?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		else: items = sBvufaD6c9YHdOqTjCQ3.findall('<li>.*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if ZDQqkvbtHmB4!='search':
				if '?' in url: RMC6c2kL5hGOnFaIwAyb = url+'&page='+title
				else: RMC6c2kL5hGOnFaIwAyb = url+'?page='+title
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			if title: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,111,QigevCplXxbPI1H,QigevCplXxbPI1H,ZDQqkvbtHmB4)
	return
def oB2rmVgqUND(url,ISc1XGEtbiRanJeAUvoY2):
	headers = {'User-Agent':eUBL1rOR4ZfndJAWPsoN6pybT0(True)}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('items d-flex(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if len(fwSu6JsQZpEiv)>1:
		if '/season/' in fwSu6JsQZpEiv[0]: X6z7OV8NFovq0IKagdmberiM1,yjHcgifXG1 = fwSu6JsQZpEiv[0],fwSu6JsQZpEiv[1]
		else: X6z7OV8NFovq0IKagdmberiM1,yjHcgifXG1 = fwSu6JsQZpEiv[1],fwSu6JsQZpEiv[0]
	else: X6z7OV8NFovq0IKagdmberiM1,yjHcgifXG1 = fwSu6JsQZpEiv[0],fwSu6JsQZpEiv[0]
	for GzabfJx3T1 in range(2):
		if ISc1XGEtbiRanJeAUvoY2: mode,type,LKzFWsmvjUVGMDBapflx6H4NY = 116,'folder',X6z7OV8NFovq0IKagdmberiM1
		else: mode,type,LKzFWsmvjUVGMDBapflx6H4NY = 112,'video',yjHcgifXG1
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if ISc1XGEtbiRanJeAUvoY2 and len(items)<2:
			ISc1XGEtbiRanJeAUvoY2 = False
			continue
		for RMC6c2kL5hGOnFaIwAyb,eliZWRgEXtMSxzpAPBUY4rnuq85F,YIwQJyV0hAUR1EfKogObLzDMmx in items:
			title = eliZWRgEXtMSxzpAPBUY4rnuq85F+hT7zFDpEyUqf8sXuN+YIwQJyV0hAUR1EfKogObLzDMmx
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj(type,iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,mode)
		break
	if not items and '/episodes' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		fq3nlxd1gG0 = sBvufaD6c9YHdOqTjCQ3.findall('class="breadcrumb"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fq3nlxd1gG0:
			LKzFWsmvjUVGMDBapflx6H4NY = fq3nlxd1gG0[0]
			rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if len(rsBojxT8UZwL)>2:
				RMC6c2kL5hGOnFaIwAyb = rsBojxT8UZwL[2]+'list'
				ddbEXhWzOnIaR(RMC6c2kL5hGOnFaIwAyb)
	return
def nibvTq2jfRXDM4tYP039S(url):
	headers = {'User-Agent':eUBL1rOR4ZfndJAWPsoN6pybT0(True)}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="actions(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv: return
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	qlNQ1PHbG8TyBaLh = '/watch/' in LKzFWsmvjUVGMDBapflx6H4NY
	download = '/download/' in LKzFWsmvjUVGMDBapflx6H4NY
	if   qlNQ1PHbG8TyBaLh and not download: P6eCBz1WQSIMgoUiylm,BwG5fIqUDcuNsVJkoKT6QC2p8FmbW = rsBojxT8UZwL[0],QigevCplXxbPI1H
	elif not qlNQ1PHbG8TyBaLh and download: P6eCBz1WQSIMgoUiylm,BwG5fIqUDcuNsVJkoKT6QC2p8FmbW = QigevCplXxbPI1H,rsBojxT8UZwL[0]
	elif qlNQ1PHbG8TyBaLh and download: P6eCBz1WQSIMgoUiylm,BwG5fIqUDcuNsVJkoKT6QC2p8FmbW = rsBojxT8UZwL[0],rsBojxT8UZwL[1]
	else: P6eCBz1WQSIMgoUiylm,BwG5fIqUDcuNsVJkoKT6QC2p8FmbW = QigevCplXxbPI1H,QigevCplXxbPI1H
	ldFqnNIsftrY43JBM6LPjzU8m = []
	if qlNQ1PHbG8TyBaLh:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',P6eCBz1WQSIMgoUiylm,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-PLAY-2nd')
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('let servers(.*?)player',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		if gQ5KvJ6G2lbWwYBOMiTr:
			Pk5h14WpxO3nAQFv0rYmNa8KDblSg = gQ5KvJ6G2lbWwYBOMiTr[0]
			WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('"name":"(.*?)".*?"url":"(.*?)"',Pk5h14WpxO3nAQFv0rYmNa8KDblSg,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for title,RMC6c2kL5hGOnFaIwAyb in WWcSoXlyFCIzMGpxr:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('\\/','/')
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if download:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',BwG5fIqUDcuNsVJkoKT6QC2p8FmbW,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-PLAY-3rd')
		BhxM1UVjtbEoSp640kIcag = JJrhP4C6osGDFEKVSRBvX.content
		gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"servers"(.*?)info-container',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if gQ5KvJ6G2lbWwYBOMiTr:
			Pk5h14WpxO3nAQFv0rYmNa8KDblSg = gQ5KvJ6G2lbWwYBOMiTr[0]
			WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',Pk5h14WpxO3nAQFv0rYmNa8KDblSg,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title,oI6LvXMf4VEPe8jOdpKC0hUmS in WWcSoXlyFCIzMGpxr:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'+'____'+oI6LvXMf4VEPe8jOdpKC0hUmS
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search:
		search = XAfEvmh95VkgurjdiJ()
		if not search: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/search?s='+search
	ddbEXhWzOnIaR(url,'search')
	return
def bZ297CKlfXUW1n5BghJjzHQMi(url):
	url = url.split('/smartemadfilter?')[0]
	headers = {'User-Agent':eUBL1rOR4ZfndJAWPsoN6pybT0(True)}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	GTvCiBk9e5HnWobxXw6AzV3KQ = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('adv-filter(.*?)shows-container',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('''updateQuery\('(.*?)'.*?value="">(.*?)<(.*?)</select''',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ePIfNzugQUHWdmD1qa7t5Kxy0rjV2,MAXhvbWiFu,mfFwcWZHXVGvyU3B0ILburCoh = zip(*GTvCiBk9e5HnWobxXw6AzV3KQ)
		GTvCiBk9e5HnWobxXw6AzV3KQ = zip(MAXhvbWiFu,ePIfNzugQUHWdmD1qa7t5Kxy0rjV2,mfFwcWZHXVGvyU3B0ILburCoh)
	return GTvCiBk9e5HnWobxXw6AzV3KQ
def k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY):
	items = sBvufaD6c9YHdOqTjCQ3.findall('value="(.*?)".*?>\s*(.*?)\s*<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return items
def WCeuTjxl9koBEtc1sUnJ(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	ffJtczXvkj0o2HUZRprAOS = url.split('/smartemadfilter?')[0]
	gd2lmLiIyEvcsT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	url = url.replace(ffJtczXvkj0o2HUZRprAOS,gd2lmLiIyEvcsT)
	url = url.replace('/smartemadfilter?','/?')
	return url
JJ6RaNTlM0zB2hmUt = ['quality','year','genre','category']
kS9YipEdhWD = ['category','genre','year']
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='DEFINED_FILTER':
		if kS9YipEdhWD[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = kS9YipEdhWD[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(kS9YipEdhWD[0:-1])):
			if kS9YipEdhWD[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = kS9YipEdhWD[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
	elif type=='FULL_FILTER':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,111)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,111)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	GTvCiBk9e5HnWobxXw6AzV3KQ = bZ297CKlfXUW1n5BghJjzHQMi(url)
	dict = {}
	for name,Vjv2Okb6qhMRQgaDlu3JCir,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		name = name.replace('كل ',QigevCplXxbPI1H)
		items = k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='DEFINED_FILTER':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<2:
				if Vjv2Okb6qhMRQgaDlu3JCir==kS9YipEdhWD[-1]:
					NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
					ddbEXhWzOnIaR(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'DEFINED_FILTER___'+Vq4HIkij2ZLE)
				return
			else:
				if Vjv2Okb6qhMRQgaDlu3JCir==kS9YipEdhWD[-1]:
					NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,111)
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,115,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='FULL_FILTER':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع :'+name,Kj0TOU6BmSMlJHZYLd,114,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if nFdGHjceZzW=='196533': C4kS0cewBJy8YOWtZxXNjfM2 = 'أفلام نيتفلكس'
			elif nFdGHjceZzW=='196531': C4kS0cewBJy8YOWtZxXNjfM2 = 'مسلسلات نيتفلكس'
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'#+dict[Vjv2Okb6qhMRQgaDlu3JCir]['0']
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'+name
			if type=='FULL_FILTER': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,114,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='DEFINED_FILTER' and kS9YipEdhWD[-2]+'=' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'modified_filters')
				Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = WCeuTjxl9koBEtc1sUnJ(Kj0TOU6BmSMlJHZYLd)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,111)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,115,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.replace('=&','=0&')
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	for key in JJ6RaNTlM0zB2hmUt:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.replace('=0','=')
	return bYlTrNXtvf0G7y
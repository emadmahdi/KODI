# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'HALACIMA'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_HLC_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['مصارعة','احدث البرامج','احدث الالعاب','احدث الاغانى']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==80: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==81: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==82: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==83: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==89: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'HALACIMA-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(vxQUXEuH9m,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,89,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-content(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-name="(.*?)".*?</i>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for ZDQqkvbtHmB4,title in items:
		RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/ajax/getItem?item='+ZDQqkvbtHmB4+'&Ajax=1'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,81)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"nav-main"(.*?)</nav>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if RMC6c2kL5hGOnFaIwAyb=='#': continue
		if title in ef1pQcbEtPjMnXYrvOi: continue
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,81)
	return
def ddbEXhWzOnIaR(url,ZDQqkvbtHmB4=QigevCplXxbPI1H):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
		T24Te3uDwBS5vLgUEAhF1O = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'HALACIMA-TITLES-1st')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = [aY63L2NhgvwJIxPAoDG4MKECmZXF1]
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'HALACIMA-TITLES-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		if ZDQqkvbtHmB4=='featured':
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"container"(.*?)"container"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		elif '"section-post mb-10"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"section-post mb-10"(.*?)"container"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		else:
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<article(.*?)"pagination"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv: return
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if not items:
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb).strip('/')
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if '/series/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,83,cXu4fN1moCypJqb72OZvd)
		elif 'سلاسل' not in url and any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,82,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY and 'الحلقة' in title:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,83,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif '/movies/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,81,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,83,cXu4fN1moCypJqb72OZvd)
	if ZDQqkvbtHmB4==QigevCplXxbPI1H:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)<footer',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				if RMC6c2kL5hGOnFaIwAyb=="": continue
				if title!=QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,81)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'هناك المزيد',url,81)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'HALACIMA-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"getSeasonsBySeries(.*?)"container"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"list-episodes"(.*?)"container"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Z5CDQW96jye and '/series/' not in url:
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,83,cXu4fN1moCypJqb72OZvd)
	elif gQ5KvJ6G2lbWwYBOMiTr:
		cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('"image" src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0]
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,82,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	Kj0TOU6BmSMlJHZYLd = url.replace('/movies/','/watch_movies/')
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace('/episodes/','/watch_episodes/')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'HALACIMA-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,'url')
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"servers"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		d8o4GfOLXIhV7b = sBvufaD6c9YHdOqTjCQ3.findall('postID = "(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		d8o4GfOLXIhV7b = d8o4GfOLXIhV7b[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for bSrdN78jxURTvh9,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/ajax/getPlayer?server='+bSrdN78jxURTvh9+'&postID='+d8o4GfOLXIhV7b+'&Ajax=1'
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"downs"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,name in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__download'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'-')
	url = vxQUXEuH9m+'/search/'+search+'.html'
	ddbEXhWzOnIaR(url)
	return
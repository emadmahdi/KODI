# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'FAJERSHOW'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_FJS_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==390: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==391: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==392: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==393: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==399: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,399,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FAJERSHOW-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	items = sBvufaD6c9YHdOqTjCQ3.findall('<header>.*?<h2>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for mOX6U4vRFfJ in range(len(items)):
		title = items[mOX6U4vRFfJ]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,vxQUXEuH9m,391,QigevCplXxbPI1H,QigevCplXxbPI1H,'latest'+str(mOX6U4vRFfJ))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مختارات عشوائية',vxQUXEuH9m,391,QigevCplXxbPI1H,QigevCplXxbPI1H,'randoms')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أعلى الأفلام تقييماً',vxQUXEuH9m,391,QigevCplXxbPI1H,QigevCplXxbPI1H,'top_imdb_movies')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أعلى المسلسلات تقييماً',vxQUXEuH9m,391,QigevCplXxbPI1H,QigevCplXxbPI1H,'top_imdb_series')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أفلام مميزة',vxQUXEuH9m+'/movies',391,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured_movies')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات مميزة',vxQUXEuH9m+'/tvshows',391,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured_tvshows')
	LKzFWsmvjUVGMDBapflx6H4NY = QigevCplXxbPI1H
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="menu"(.*?)id="contenedor"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY += fwSu6JsQZpEiv[0]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m+'/movies',QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FAJERSHOW-MENU-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="releases"(.*?)aside',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY += fwSu6JsQZpEiv[0]
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	JwNdW5ulnaVBmKPCijI4tHFEf39R = True
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if title=='الأعلى مشاهدة':
			if JwNdW5ulnaVBmKPCijI4tHFEf39R:
				title = 'الافلام '+title
				JwNdW5ulnaVBmKPCijI4tHFEf39R = False
			else: title = 'المسلسلات '+title
		if title not in ef1pQcbEtPjMnXYrvOi:
			if title=='أفلام': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,vxQUXEuH9m+'/movies',391,QigevCplXxbPI1H,QigevCplXxbPI1H,'all_movies_tvshows')
			elif title=='مسلسلات': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,vxQUXEuH9m+'/tvshows',391,QigevCplXxbPI1H,QigevCplXxbPI1H,'all_movies_tvshows')
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,391)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,type):
	LKzFWsmvjUVGMDBapflx6H4NY,items = [],[]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FAJERSHOW-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if type in ['featured_movies','featured_tvshows']:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="content"(.*?)id="archive-content"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif type=='all_movies_tvshows':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="archive-content"(.*?)class="pagination"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif type=='top_imdb_movies':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='top_imdb_series':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall("class='top-imdb-list tright(.*?)footer",aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall("img src='(.*?)'.*?href='(.*?)'>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='search':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="search-page"(.*?)class="sidebar',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='sider':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="widget(.*?)class="widget',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ldFqnNIsftrY43JBM6LPjzU8m,ccrXN0VUmvKdPZOI4n3GFEjiz,ttGBwQOv3K41hIkc6 = zip(*w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf)
		items = zip(ccrXN0VUmvKdPZOI4n3GFEjiz,ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6)
	elif type=='randoms':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="slider-movies-tvshows"(.*?)<header>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif 'latest' in type:
		mOX6U4vRFfJ = int(type[-1:])
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('<header>','<end><start>')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('</div></div></div>','</div></div></div><end>')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<start>(.*?)<end>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[mOX6U4vRFfJ]
		if mOX6U4vRFfJ==6:
			w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)" alt="(.*?)".*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			ccrXN0VUmvKdPZOI4n3GFEjiz,ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = zip(*w6ZLY37WXPEA0p5vzuFjxyi4H1rUIf)
			items = zip(ccrXN0VUmvKdPZOI4n3GFEjiz,ldFqnNIsftrY43JBM6LPjzU8m,ttGBwQOv3K41hIkc6)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="content"(.*?)class="(pagination|sidebar)',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0][0]
			if '/collection/' in url:
				items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			elif '/quality/' in url:
				items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items and LKzFWsmvjUVGMDBapflx6H4NY:
		items = sBvufaD6c9YHdOqTjCQ3.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = sBvufaD6c9YHdOqTjCQ3.findall('^(.*?)<.*?serie">(.*?)<',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			title = title[0][1]
			if title in wibHRCAFtsupIjx4ZTELeM: continue
			wibHRCAFtsupIjx4ZTELeM.append(title)
			title = '_MOD_'+title
		YIwQJyV0hAUR1EfKogObLzDMmx = sBvufaD6c9YHdOqTjCQ3.findall('^(.*?)<',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if YIwQJyV0hAUR1EfKogObLzDMmx: title = YIwQJyV0hAUR1EfKogObLzDMmx[0]
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if '/tvshows/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,393,cXu4fN1moCypJqb72OZvd)
		elif '/episodes/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,393,cXu4fN1moCypJqb72OZvd)
		elif '/seasons/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,393,cXu4fN1moCypJqb72OZvd)
		elif '/collection/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,391,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,392,cXu4fN1moCypJqb72OZvd)
	if type not in ['featured_movies','featured_tvshows']:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,391,QigevCplXxbPI1H,QigevCplXxbPI1H,type)
	return
def oB2rmVgqUND(url):
	bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	url = url.replace(bSrdN78jxURTvh9,vxQUXEuH9m)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FAJERSHOW-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('class="C rated".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<ul class="episodios">(.*?)</ul></div></div></div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)".*?href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,392,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = xYWkrtyMJs48(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,'FAJERSHOW-PLAY-1st')
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('class="C rated".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0][0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for type,Mc0PCsFDyLYA1VkTpXvfG8nuB5,nsYiC4Ej8eL,title in items:
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+Mc0PCsFDyLYA1VkTpXvfG8nuB5+'&nume='+nsYiC4Ej8eL+'&type='+type
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS,UmDMPlYnsIOZ3HX4J76i in items:
			if '=' in cXu4fN1moCypJqb72OZvd:
				tMCKuqcWisxdf8XwI5lYBQ9 = cXu4fN1moCypJqb72OZvd.split('=')[1]
				title = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(tMCKuqcWisxdf8XwI5lYBQ9,'host')
			else: title = QigevCplXxbPI1H
			title = UmDMPlYnsIOZ3HX4J76i+hT7zFDpEyUqf8sXuN+title
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download____'+oI6LvXMf4VEPe8jOdpKC0hUmS
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/?s='+search
	ddbEXhWzOnIaR(url,'search')
	return
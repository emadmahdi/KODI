# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
JwBc6IZ4xeLmM8 = 'EXCLUDES'
def GGdRtBL5keSN3(zsj5qOxnfaXmdEco3DK29HgYybUCM6,qFkl8PWfGsCo):
	qFkl8PWfGsCo = qFkl8PWfGsCo.replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,QigevCplXxbPI1H).replace(' [/COLOR]',QigevCplXxbPI1H)[1:]
	esO0GAn4mMQWbrNfVy = sBvufaD6c9YHdOqTjCQ3.findall('[a-zA-Z]',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if 'بحث IPTV - ' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace('بحث IPTV - ',AhkIX24vpNGzdLU5+'بحث IPTV - '+AhkIX24vpNGzdLU5)
	elif ' IPTV' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 and qFkl8PWfGsCo=='IPT': zsj5qOxnfaXmdEco3DK29HgYybUCM6 = AhkIX24vpNGzdLU5+zsj5qOxnfaXmdEco3DK29HgYybUCM6
	elif 'بحث M3U - ' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace('بحث M3U - ',AhkIX24vpNGzdLU5+'بحث M3U - '+AhkIX24vpNGzdLU5)
	elif ' M3U' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 and qFkl8PWfGsCo=='M3U': zsj5qOxnfaXmdEco3DK29HgYybUCM6 = AhkIX24vpNGzdLU5+zsj5qOxnfaXmdEco3DK29HgYybUCM6
	elif 'بحث ' in zsj5qOxnfaXmdEco3DK29HgYybUCM6 and ' - ' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = AhkIX24vpNGzdLU5+zsj5qOxnfaXmdEco3DK29HgYybUCM6
	elif not esO0GAn4mMQWbrNfVy:
		PdximgAbj1uM52JalshHDLOUBNR86 = sBvufaD6c9YHdOqTjCQ3.findall('^( *?)(.*?)( *?)$',zsj5qOxnfaXmdEco3DK29HgYybUCM6)
		Sce2tLJarG8jRqxyoYbk,f96B0zyCOHQouDT32Xw5,ZcQredAEXOJix7z4jSvIb1H = PdximgAbj1uM52JalshHDLOUBNR86[0]
		Cuz3hbSlXc6 = sBvufaD6c9YHdOqTjCQ3.findall('^([!-~])',f96B0zyCOHQouDT32Xw5)
		if Cuz3hbSlXc6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = Sce2tLJarG8jRqxyoYbk+yy7OzVc6J5WiY4pLMwFoXRs+f96B0zyCOHQouDT32Xw5+ZcQredAEXOJix7z4jSvIb1H
		else: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = ZcQredAEXOJix7z4jSvIb1H+AhkIX24vpNGzdLU5+f96B0zyCOHQouDT32Xw5+Sce2tLJarG8jRqxyoYbk
	else:
		import bidi.algorithm as Vzd34t8iynRGBZ21oj
		if 1:
			zUI0YNatb3plRi6yxcJdHG = zsj5qOxnfaXmdEco3DK29HgYybUCM6
			touVCTM9fdcXvWl4nSiI53y8ZrhRa = Vzd34t8iynRGBZ21oj.get_display(zsj5qOxnfaXmdEco3DK29HgYybUCM6,base_dir='L')
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: zUI0YNatb3plRi6yxcJdHG = zUI0YNatb3plRi6yxcJdHG.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: touVCTM9fdcXvWl4nSiI53y8ZrhRa = touVCTM9fdcXvWl4nSiI53y8ZrhRa.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			xWKl4hZuPcvGTw = zUI0YNatb3plRi6yxcJdHG.split(hT7zFDpEyUqf8sXuN)
			Jsoibz6IZrNOD5VF = touVCTM9fdcXvWl4nSiI53y8ZrhRa.split(hT7zFDpEyUqf8sXuN)
			pq9uSrViy0k46gsMYZDbwhC8deaPm,pH31LbM5ustZazvY,DDNcSUt10KV,sgoABd8Fcu1y = [],[],QigevCplXxbPI1H,QigevCplXxbPI1H
			cnzhGVPBtDL1048vNQEKdHA3job = zip(xWKl4hZuPcvGTw,Jsoibz6IZrNOD5VF)
			for EG62Sq5AUXCYuimsJtN7coKnv,nLlMgEthF2uw1cIQ8jbVo in cnzhGVPBtDL1048vNQEKdHA3job:
				if EG62Sq5AUXCYuimsJtN7coKnv==nLlMgEthF2uw1cIQ8jbVo==QigevCplXxbPI1H and sgoABd8Fcu1y:
					DDNcSUt10KV += hT7zFDpEyUqf8sXuN
					continue
				if EG62Sq5AUXCYuimsJtN7coKnv==nLlMgEthF2uw1cIQ8jbVo:
					cXnibjZo95leMaFHJRkE7UBz3GYgvD = 'EN'
					if sgoABd8Fcu1y==cXnibjZo95leMaFHJRkE7UBz3GYgvD: DDNcSUt10KV += hT7zFDpEyUqf8sXuN+EG62Sq5AUXCYuimsJtN7coKnv
					elif EG62Sq5AUXCYuimsJtN7coKnv:
						if DDNcSUt10KV:
							pH31LbM5ustZazvY.append(DDNcSUt10KV)
							pq9uSrViy0k46gsMYZDbwhC8deaPm.append(QigevCplXxbPI1H)
						DDNcSUt10KV = EG62Sq5AUXCYuimsJtN7coKnv
				else:
					cXnibjZo95leMaFHJRkE7UBz3GYgvD = 'AR'
					if sgoABd8Fcu1y==cXnibjZo95leMaFHJRkE7UBz3GYgvD: DDNcSUt10KV += hT7zFDpEyUqf8sXuN+EG62Sq5AUXCYuimsJtN7coKnv
					elif EG62Sq5AUXCYuimsJtN7coKnv:
						if DDNcSUt10KV:
							pq9uSrViy0k46gsMYZDbwhC8deaPm.append(DDNcSUt10KV)
							pH31LbM5ustZazvY.append(QigevCplXxbPI1H)
						DDNcSUt10KV = EG62Sq5AUXCYuimsJtN7coKnv
				sgoABd8Fcu1y = cXnibjZo95leMaFHJRkE7UBz3GYgvD
			if cXnibjZo95leMaFHJRkE7UBz3GYgvD=='EN':
				pq9uSrViy0k46gsMYZDbwhC8deaPm.append(DDNcSUt10KV)
				pH31LbM5ustZazvY.append(QigevCplXxbPI1H)
			else:
				pH31LbM5ustZazvY.append(DDNcSUt10KV)
				pq9uSrViy0k46gsMYZDbwhC8deaPm.append(QigevCplXxbPI1H)
			y6anD8RCEFTZ = QigevCplXxbPI1H
			cnzhGVPBtDL1048vNQEKdHA3job = zip(pq9uSrViy0k46gsMYZDbwhC8deaPm,pH31LbM5ustZazvY)
			import bidi.mirror as jPULDCVq3Sioftc8rd1wg4
			for gTfxHokGULh813Iv0KbWQiFy,aYNydk0gOUCBDcnpXrt42ZQJfAT3 in cnzhGVPBtDL1048vNQEKdHA3job:
				if gTfxHokGULh813Iv0KbWQiFy: y6anD8RCEFTZ += hT7zFDpEyUqf8sXuN+gTfxHokGULh813Iv0KbWQiFy
				else:
					Cuz3hbSlXc6 = sBvufaD6c9YHdOqTjCQ3.findall('([!-~]) *$',aYNydk0gOUCBDcnpXrt42ZQJfAT3)
					if Cuz3hbSlXc6:
						Cuz3hbSlXc6 = Cuz3hbSlXc6[0]
						try:
							KGwefiY54FqacHZyNUWE = jPULDCVq3Sioftc8rd1wg4.MIRRORED[Cuz3hbSlXc6]
							PdximgAbj1uM52JalshHDLOUBNR86 = sBvufaD6c9YHdOqTjCQ3.findall('^( *?)(.*?)( *?)$',aYNydk0gOUCBDcnpXrt42ZQJfAT3)
							if PdximgAbj1uM52JalshHDLOUBNR86: Sce2tLJarG8jRqxyoYbk,aYNydk0gOUCBDcnpXrt42ZQJfAT3,ZcQredAEXOJix7z4jSvIb1H = PdximgAbj1uM52JalshHDLOUBNR86[0]
							aYNydk0gOUCBDcnpXrt42ZQJfAT3 = Sce2tLJarG8jRqxyoYbk+KGwefiY54FqacHZyNUWE+aYNydk0gOUCBDcnpXrt42ZQJfAT3[:-1]+ZcQredAEXOJix7z4jSvIb1H
						except: pass
					y6anD8RCEFTZ += hT7zFDpEyUqf8sXuN+aYNydk0gOUCBDcnpXrt42ZQJfAT3
			zsj5qOxnfaXmdEco3DK29HgYybUCM6 = y6anD8RCEFTZ[1:]
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		else:
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			zsj5qOxnfaXmdEco3DK29HgYybUCM6 = Vzd34t8iynRGBZ21oj.get_display(zsj5qOxnfaXmdEco3DK29HgYybUCM6)
			zUI0YNatb3plRi6yxcJdHG,touVCTM9fdcXvWl4nSiI53y8ZrhRa = zsj5qOxnfaXmdEco3DK29HgYybUCM6,zsj5qOxnfaXmdEco3DK29HgYybUCM6
			if 1:
				sgoABd8Fcu1y,vw6zYg8U4qrDZTL97cRuJ = QigevCplXxbPI1H,[]
				XMjkIwvEupz0fmN7ObdCDBF = zsj5qOxnfaXmdEco3DK29HgYybUCM6.split(hT7zFDpEyUqf8sXuN)
				for WWmsxuq6AtKeE2inaTp8jwZ5g7Db in XMjkIwvEupz0fmN7ObdCDBF:
					if not WWmsxuq6AtKeE2inaTp8jwZ5g7Db:
						if vw6zYg8U4qrDZTL97cRuJ: vw6zYg8U4qrDZTL97cRuJ[-1] += hT7zFDpEyUqf8sXuN
						else: vw6zYg8U4qrDZTL97cRuJ.append(QigevCplXxbPI1H)
						continue
					f3yO9n5A6giTBhGpYksP0 = sBvufaD6c9YHdOqTjCQ3.findall('[!-~]',WWmsxuq6AtKeE2inaTp8jwZ5g7Db[0])
					if f3yO9n5A6giTBhGpYksP0==sgoABd8Fcu1y and vw6zYg8U4qrDZTL97cRuJ: vw6zYg8U4qrDZTL97cRuJ[-1] += hT7zFDpEyUqf8sXuN+WWmsxuq6AtKeE2inaTp8jwZ5g7Db
					else:
						if vw6zYg8U4qrDZTL97cRuJ:
							FpfgePrLH1NatXE0myz6ZK4 = sBvufaD6c9YHdOqTjCQ3.findall('[^!-~]',vw6zYg8U4qrDZTL97cRuJ[-1])
							if FpfgePrLH1NatXE0myz6ZK4:
								vw6zYg8U4qrDZTL97cRuJ[-1] = Vzd34t8iynRGBZ21oj.get_display(vw6zYg8U4qrDZTL97cRuJ[-1])
								At1s2e4ujygk3TNwdHS0ZX = sBvufaD6c9YHdOqTjCQ3.findall('^ +',vw6zYg8U4qrDZTL97cRuJ[-1])
								if At1s2e4ujygk3TNwdHS0ZX: vw6zYg8U4qrDZTL97cRuJ[-1] = vw6zYg8U4qrDZTL97cRuJ[-1].lstrip(hT7zFDpEyUqf8sXuN)+At1s2e4ujygk3TNwdHS0ZX[0]
						vw6zYg8U4qrDZTL97cRuJ.append(WWmsxuq6AtKeE2inaTp8jwZ5g7Db)
					sgoABd8Fcu1y = f3yO9n5A6giTBhGpYksP0
				if vw6zYg8U4qrDZTL97cRuJ: vw6zYg8U4qrDZTL97cRuJ[-1] = Vzd34t8iynRGBZ21oj.get_display(vw6zYg8U4qrDZTL97cRuJ[-1])
				zsj5qOxnfaXmdEco3DK29HgYybUCM6 = hT7zFDpEyUqf8sXuN.join(vw6zYg8U4qrDZTL97cRuJ)
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	return zsj5qOxnfaXmdEco3DK29HgYybUCM6
def hhTVKzB6fi5b1M9RPxkJGgdtHIlqy(HARXP1tbN8r6xYlm,uaE9NF7eSmIGjt,PPU8VT5csgqmJ30BH):
	pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,L8ixrP6IGRVeM3TtmswzQukXHn5U,E8xtXl1g7Q,SFQtU7cnyeo,TV74iI95g1jkpRMyQ = HARXP1tbN8r6xYlm
	TsckNQJ6yLiaEeCRml98WwKfVP0dYv = int(TsckNQJ6yLiaEeCRml98WwKfVP0dYv)
	gJYDRfkQNnmcueMUwiSX0oyvWzOHl = sBvufaD6c9YHdOqTjCQ3.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if gJYDRfkQNnmcueMUwiSX0oyvWzOHl:
		gJYDRfkQNnmcueMUwiSX0oyvWzOHl,uAdeYhMRpq4VwyJ6W9,LA4hIWnHFV6fM8 = gJYDRfkQNnmcueMUwiSX0oyvWzOHl[0]
		zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace(gJYDRfkQNnmcueMUwiSX0oyvWzOHl,QigevCplXxbPI1H)
	yblBWzsUQdqAm0fpjD6oCx = zsj5qOxnfaXmdEco3DK29HgYybUCM6
	qFkl8PWfGsCo = sBvufaD6c9YHdOqTjCQ3.findall('^_(\w\w\w)_(.*?)$',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if qFkl8PWfGsCo:
		qFkl8PWfGsCo,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = qFkl8PWfGsCo[0]
		WlUDFuGrysIKVXkPtZieOMc79v0LEn = '_MOD_' in zsj5qOxnfaXmdEco3DK29HgYybUCM6
		wiWn9NIP6XG = pf6P4wckhgTa=='folder'
		if WlUDFuGrysIKVXkPtZieOMc79v0LEn and wiWn9NIP6XG: hQuKXxJP80LCAaZO62q13bv4 = ';'
		elif WlUDFuGrysIKVXkPtZieOMc79v0LEn and not wiWn9NIP6XG: hQuKXxJP80LCAaZO62q13bv4 = bJ75YtchPxVNaSsn
		elif not WlUDFuGrysIKVXkPtZieOMc79v0LEn and wiWn9NIP6XG: hQuKXxJP80LCAaZO62q13bv4 = ','
		elif not WlUDFuGrysIKVXkPtZieOMc79v0LEn and not wiWn9NIP6XG: hQuKXxJP80LCAaZO62q13bv4 = hT7zFDpEyUqf8sXuN
		zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace('_MOD_',QigevCplXxbPI1H)
		qFkl8PWfGsCo = hQuKXxJP80LCAaZO62q13bv4+iVCLpNIM8BQs9PdSgKZvlFeo3a5+qFkl8PWfGsCo+' [/COLOR]'
	else: qFkl8PWfGsCo = QigevCplXxbPI1H
	if gJYDRfkQNnmcueMUwiSX0oyvWzOHl:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			gJYDRfkQNnmcueMUwiSX0oyvWzOHl = r9rhtA5Tek8sIoLfqwF7JcEV+uAdeYhMRpq4VwyJ6W9+hT7zFDpEyUqf8sXuN+LA4hIWnHFV6fM8+jhAlCQ47ZgG
			if qFkl8PWfGsCo: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = gJYDRfkQNnmcueMUwiSX0oyvWzOHl+hT7zFDpEyUqf8sXuN+AhkIX24vpNGzdLU5+qFkl8PWfGsCo+zsj5qOxnfaXmdEco3DK29HgYybUCM6
			else: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = gJYDRfkQNnmcueMUwiSX0oyvWzOHl+AhkIX24vpNGzdLU5+zsj5qOxnfaXmdEco3DK29HgYybUCM6+hT7zFDpEyUqf8sXuN
		elif b7sJAmSxlBvaMdHFz:
			if qFkl8PWfGsCo:
				gJYDRfkQNnmcueMUwiSX0oyvWzOHl = r9rhtA5Tek8sIoLfqwF7JcEV+uAdeYhMRpq4VwyJ6W9+hT7zFDpEyUqf8sXuN+LA4hIWnHFV6fM8+jhAlCQ47ZgG
				zsj5qOxnfaXmdEco3DK29HgYybUCM6 = gJYDRfkQNnmcueMUwiSX0oyvWzOHl+hT7zFDpEyUqf8sXuN+qFkl8PWfGsCo+zsj5qOxnfaXmdEco3DK29HgYybUCM6
			else:
				gJYDRfkQNnmcueMUwiSX0oyvWzOHl = r9rhtA5Tek8sIoLfqwF7JcEV+LA4hIWnHFV6fM8+hT7zFDpEyUqf8sXuN+uAdeYhMRpq4VwyJ6W9+jhAlCQ47ZgG
				zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6+hT7zFDpEyUqf8sXuN+AhkIX24vpNGzdLU5+gJYDRfkQNnmcueMUwiSX0oyvWzOHl
	elif qFkl8PWfGsCo:
		zsj5qOxnfaXmdEco3DK29HgYybUCM6 = GGdRtBL5keSN3(zsj5qOxnfaXmdEco3DK29HgYybUCM6,qFkl8PWfGsCo)
		zsj5qOxnfaXmdEco3DK29HgYybUCM6 = qFkl8PWfGsCo+zsj5qOxnfaXmdEco3DK29HgYybUCM6
	HARXP1tbN8r6xYlm = pf6P4wckhgTa,yblBWzsUQdqAm0fpjD6oCx,XCapNbgw2xWQ5jRt,str(TsckNQJ6yLiaEeCRml98WwKfVP0dYv),hhQxqntdaHTLE0V4UMXbOvgepKRG,L8ixrP6IGRVeM3TtmswzQukXHn5U,E8xtXl1g7Q,SFQtU7cnyeo,TV74iI95g1jkpRMyQ
	j5V0EiFQ8dkr3U4M = {'type':QigevCplXxbPI1H,'mode':QigevCplXxbPI1H,'url':QigevCplXxbPI1H,'text':QigevCplXxbPI1H,'page':QigevCplXxbPI1H,'name':QigevCplXxbPI1H,'image':QigevCplXxbPI1H,'context':QigevCplXxbPI1H,'infodict':QigevCplXxbPI1H}
	j5V0EiFQ8dkr3U4M['name'] = sqXK91rDldVAEcRTSQL4n2tbC(yblBWzsUQdqAm0fpjD6oCx)
	j5V0EiFQ8dkr3U4M['type'] = pf6P4wckhgTa.strip(hT7zFDpEyUqf8sXuN)
	j5V0EiFQ8dkr3U4M['mode'] = str(TsckNQJ6yLiaEeCRml98WwKfVP0dYv).strip(hT7zFDpEyUqf8sXuN)
	if pf6P4wckhgTa=='folder' and L8ixrP6IGRVeM3TtmswzQukXHn5U: j5V0EiFQ8dkr3U4M['page'] = sqXK91rDldVAEcRTSQL4n2tbC(L8ixrP6IGRVeM3TtmswzQukXHn5U.strip(hT7zFDpEyUqf8sXuN))
	if SFQtU7cnyeo: j5V0EiFQ8dkr3U4M['context'] = SFQtU7cnyeo.strip(hT7zFDpEyUqf8sXuN)
	if E8xtXl1g7Q: j5V0EiFQ8dkr3U4M['text'] = sqXK91rDldVAEcRTSQL4n2tbC(E8xtXl1g7Q.strip(hT7zFDpEyUqf8sXuN))
	if hhQxqntdaHTLE0V4UMXbOvgepKRG: j5V0EiFQ8dkr3U4M['image'] = sqXK91rDldVAEcRTSQL4n2tbC(hhQxqntdaHTLE0V4UMXbOvgepKRG.strip(hT7zFDpEyUqf8sXuN))
	if TV74iI95g1jkpRMyQ:
		TV74iI95g1jkpRMyQ = str(TV74iI95g1jkpRMyQ)
		j5V0EiFQ8dkr3U4M['infodict'] = sqXK91rDldVAEcRTSQL4n2tbC(TV74iI95g1jkpRMyQ.strip(hT7zFDpEyUqf8sXuN))
		TV74iI95g1jkpRMyQ = eval(TV74iI95g1jkpRMyQ)
	else: TV74iI95g1jkpRMyQ = {}
	if XCapNbgw2xWQ5jRt: j5V0EiFQ8dkr3U4M['url'] = sqXK91rDldVAEcRTSQL4n2tbC(XCapNbgw2xWQ5jRt.strip(hT7zFDpEyUqf8sXuN))
	FMGs1KZyN6v8ufxThbSe = {'name':QigevCplXxbPI1H,'context_menu':QigevCplXxbPI1H,'plot':QigevCplXxbPI1H,'stars':QigevCplXxbPI1H,'image':QigevCplXxbPI1H,'type':QigevCplXxbPI1H,'isFolder':QigevCplXxbPI1H,'newpath':QigevCplXxbPI1H,'duration':QigevCplXxbPI1H}
	wwmp1ML4Uvr8HOQ3kBsgR = []
	pySnuJGXihUzrkBWftdQHTglCVOM = 'plugin://'+GTZC7rKJtPlueQ+'/?type='+j5V0EiFQ8dkr3U4M['type']+'&mode='+j5V0EiFQ8dkr3U4M['mode']
	if j5V0EiFQ8dkr3U4M['page']: pySnuJGXihUzrkBWftdQHTglCVOM += '&page='+j5V0EiFQ8dkr3U4M['page']
	if j5V0EiFQ8dkr3U4M['name']: pySnuJGXihUzrkBWftdQHTglCVOM += '&name='+j5V0EiFQ8dkr3U4M['name']
	if j5V0EiFQ8dkr3U4M['text']: pySnuJGXihUzrkBWftdQHTglCVOM += '&text='+j5V0EiFQ8dkr3U4M['text']
	if j5V0EiFQ8dkr3U4M['infodict']: pySnuJGXihUzrkBWftdQHTglCVOM += '&infodict='+j5V0EiFQ8dkr3U4M['infodict']
	if j5V0EiFQ8dkr3U4M['image']: pySnuJGXihUzrkBWftdQHTglCVOM += '&image='+j5V0EiFQ8dkr3U4M['image']
	if j5V0EiFQ8dkr3U4M['url']: pySnuJGXihUzrkBWftdQHTglCVOM += '&url='+j5V0EiFQ8dkr3U4M['url']
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv!=265: FMGs1KZyN6v8ufxThbSe['favorites'] = True
	else: FMGs1KZyN6v8ufxThbSe['favorites'] = False
	if j5V0EiFQ8dkr3U4M['context']: pySnuJGXihUzrkBWftdQHTglCVOM += '&context='+j5V0EiFQ8dkr3U4M['context']
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv in [235,238] and pf6P4wckhgTa=='live' and 'EPG' in SFQtU7cnyeo:
		OcqTIk12a9wWPgsJMiBhUSjYpA = 'plugin://'+GTZC7rKJtPlueQ+'?mode=238&text=SHORT_EPG&url='+XCapNbgw2xWQ5jRt
		RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
		wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv==265:
		Y6aKlGeH3p8BvbR = uaE9NF7eSmIGjt(E8xtXl1g7Q,True)
		if Y6aKlGeH3p8BvbR>0:
			OcqTIk12a9wWPgsJMiBhUSjYpA = 'plugin://'+GTZC7rKJtPlueQ+'?mode=266&text='+E8xtXl1g7Q
			RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(E8xtXl1g7Q)+jhAlCQ47ZgG
			OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
			wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	if pf6P4wckhgTa=='video' and TsckNQJ6yLiaEeCRml98WwKfVP0dYv!=331:
		OcqTIk12a9wWPgsJMiBhUSjYpA = pySnuJGXihUzrkBWftdQHTglCVOM+'&context=6_DOWNLOAD'
		RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
		wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv==331:
		OcqTIk12a9wWPgsJMiBhUSjYpA = pySnuJGXihUzrkBWftdQHTglCVOM+'&context=6_DELETE'
		RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
		wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	if pf6P4wckhgTa=='folder' and TsckNQJ6yLiaEeCRml98WwKfVP0dYv==540:
		tiFswrhdPZXLRVcgoq83BeHuYAE5J = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','GLOBALSEARCH_SITES')
		if tiFswrhdPZXLRVcgoq83BeHuYAE5J:
			OcqTIk12a9wWPgsJMiBhUSjYpA = 'plugin://'+GTZC7rKJtPlueQ+'?context=7'
			RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
			wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	Z6ZSDfleydzK9Iqat3Pcb0BWQv1NVY = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv not in Z6ZSDfleydzK9Iqat3Pcb0BWQv1NVY:
		OcqTIk12a9wWPgsJMiBhUSjYpA = 'plugin://'+GTZC7rKJtPlueQ+'?context=8&mode=260'
		RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]القائمة الرئيسية[/COLOR]'
		OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
		wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	VlAFbsDGP6ENIoyMfLOxpd = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv%10 and TsckNQJ6yLiaEeCRml98WwKfVP0dYv!=9990:
		sKgBxbjXGOohtvA1nY47uqE8Ualk = TsckNQJ6yLiaEeCRml98WwKfVP0dYv-TsckNQJ6yLiaEeCRml98WwKfVP0dYv%10
		if sKgBxbjXGOohtvA1nY47uqE8Ualk==280: sKgBxbjXGOohtvA1nY47uqE8Ualk = 230
		if sKgBxbjXGOohtvA1nY47uqE8Ualk==410: sKgBxbjXGOohtvA1nY47uqE8Ualk = 400
		if sKgBxbjXGOohtvA1nY47uqE8Ualk==520: sKgBxbjXGOohtvA1nY47uqE8Ualk = 510
		if sKgBxbjXGOohtvA1nY47uqE8Ualk not in VlAFbsDGP6ENIoyMfLOxpd:
			OcqTIk12a9wWPgsJMiBhUSjYpA = 'plugin://'+GTZC7rKJtPlueQ+'?context=8&mode='+str(sKgBxbjXGOohtvA1nY47uqE8Ualk)
			RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]قائمة الموقع[/COLOR]'
			OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
			wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	OcqTIk12a9wWPgsJMiBhUSjYpA = pySnuJGXihUzrkBWftdQHTglCVOM+'&context=9'
	RG3qpQkiLdCuArKvhDF7Ua4e2yw = '[COLOR FFFFFF00]تحديث القائمة[/COLOR]'
	OG1vtDAbdlpVyE = (RG3qpQkiLdCuArKvhDF7Ua4e2yw,'RunPlugin('+OcqTIk12a9wWPgsJMiBhUSjYpA+')')
	wwmp1ML4Uvr8HOQ3kBsgR.append(OG1vtDAbdlpVyE)
	if pf6P4wckhgTa in ['link','video','live']: lLpcD9SvTIkVOXnhqGQJxBNH = False
	elif pf6P4wckhgTa=='folder': lLpcD9SvTIkVOXnhqGQJxBNH = True
	FMGs1KZyN6v8ufxThbSe['name'] = zsj5qOxnfaXmdEco3DK29HgYybUCM6
	FMGs1KZyN6v8ufxThbSe['context_menu'] = wwmp1ML4Uvr8HOQ3kBsgR
	if 'plot' in list(TV74iI95g1jkpRMyQ.keys()): FMGs1KZyN6v8ufxThbSe['plot'] = TV74iI95g1jkpRMyQ['plot']
	if 'stars' in list(TV74iI95g1jkpRMyQ.keys()): FMGs1KZyN6v8ufxThbSe['stars'] = TV74iI95g1jkpRMyQ['stars']
	if hhQxqntdaHTLE0V4UMXbOvgepKRG: FMGs1KZyN6v8ufxThbSe['image'] = hhQxqntdaHTLE0V4UMXbOvgepKRG
	if pf6P4wckhgTa=='video' and L8ixrP6IGRVeM3TtmswzQukXHn5U:
		aU7D9VldsKxSr0 = sBvufaD6c9YHdOqTjCQ3.findall('[\d:]+',L8ixrP6IGRVeM3TtmswzQukXHn5U,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if aU7D9VldsKxSr0:
			aU7D9VldsKxSr0 = '0:0:0:0:0:'+aU7D9VldsKxSr0[0]
			eAYEQ2kZ8w1yua7PDKcJXrhV6R3p,WJTK4NmtQO,VRZFha02P5NzdSqsgl1XGjKbB,jHBGQ8DLfb3V7pyZx69kK,neF8uTyb6pEdM1Kag4DHSNPOk = aU7D9VldsKxSr0.rsplit(':',4)
			DRiPuWIpbenCwNK0S8oThrz2OyJqt = int(WJTK4NmtQO)*24*oaxeugQnX1W6UJN+int(VRZFha02P5NzdSqsgl1XGjKbB)*oaxeugQnX1W6UJN+int(jHBGQ8DLfb3V7pyZx69kK)*60+int(neF8uTyb6pEdM1Kag4DHSNPOk)
			FMGs1KZyN6v8ufxThbSe['duration'] = DRiPuWIpbenCwNK0S8oThrz2OyJqt
	FMGs1KZyN6v8ufxThbSe['type'] = pf6P4wckhgTa
	FMGs1KZyN6v8ufxThbSe['isFolder'] = lLpcD9SvTIkVOXnhqGQJxBNH
	FMGs1KZyN6v8ufxThbSe['newpath'] = pySnuJGXihUzrkBWftdQHTglCVOM
	FMGs1KZyN6v8ufxThbSe['menuItem'] = HARXP1tbN8r6xYlm
	FMGs1KZyN6v8ufxThbSe['mode'] = TsckNQJ6yLiaEeCRml98WwKfVP0dYv
	return FMGs1KZyN6v8ufxThbSe
def YIimk2Pfta65FTg7HrbwK1n9(uaE9NF7eSmIGjt):
	gEDUA8kJHb9FsQ0Z4hawim = []
	from T9PmfG7SQA import xCTgdOF20zM4U,WLjdqXog7ZQcPSb6
	PPU8VT5csgqmJ30BH = xCTgdOF20zM4U()
	for HARXP1tbN8r6xYlm in lc0jJQ4zboeDI3tqTrpvm5gZO:
		FMGs1KZyN6v8ufxThbSe = hhTVKzB6fi5b1M9RPxkJGgdtHIlqy(HARXP1tbN8r6xYlm,uaE9NF7eSmIGjt,PPU8VT5csgqmJ30BH)
		if FMGs1KZyN6v8ufxThbSe['favorites']:
			nMRCkxJupmqbUry9 = WLjdqXog7ZQcPSb6(PPU8VT5csgqmJ30BH,FMGs1KZyN6v8ufxThbSe['menuItem'],FMGs1KZyN6v8ufxThbSe['newpath'])
			FMGs1KZyN6v8ufxThbSe['context_menu'] = nMRCkxJupmqbUry9+FMGs1KZyN6v8ufxThbSe['context_menu']
		gEDUA8kJHb9FsQ0Z4hawim.append(FMGs1KZyN6v8ufxThbSe)
	return gEDUA8kJHb9FsQ0Z4hawim
def K0KkCQPqE3ONvWm7yJtXn1f(kcZDbGjVROS96nrzfL1wpq2te):
	hQuKXxJP80LCAaZO62q13bv4,kBLZSOWsqXyoCUcmt1JdgENn, = [],QigevCplXxbPI1H
	for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
		if not Sy8dRNAqBu: hQuKXxJP80LCAaZO62q13bv4.append(QigevCplXxbPI1H)
		else: break
	kcZDbGjVROS96nrzfL1wpq2te = kcZDbGjVROS96nrzfL1wpq2te[len(hQuKXxJP80LCAaZO62q13bv4):]
	d8kolNVuLsPAjQZ9ROpUHBgix = '\n\n\n\n'.join(kcZDbGjVROS96nrzfL1wpq2te)
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('===== ===== =====','000001')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,'000002')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(r9rhtA5Tek8sIoLfqwF7JcEV,'000003')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(jhAlCQ47ZgG,'000004')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[RIGHT]','000005')
	bb6LKGv5OYmaWIHz3ZfuUS = 100000
	yv8jxCcI6hqTtmwU1epgbuaDLkNn = {}
	YK9AhfpuBN35SIH6jGJ = sBvufaD6c9YHdOqTjCQ3.findall('http.*?[\r\n ]',d8kolNVuLsPAjQZ9ROpUHBgix,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for q8scEzedK6lRra in YK9AhfpuBN35SIH6jGJ:
		bb6LKGv5OYmaWIHz3ZfuUS += 1
		d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(q8scEzedK6lRra,str(bb6LKGv5OYmaWIHz3ZfuUS))
		yv8jxCcI6hqTtmwU1epgbuaDLkNn[str(bb6LKGv5OYmaWIHz3ZfuUS)] = q8scEzedK6lRra
	for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(0,len(d8kolNVuLsPAjQZ9ROpUHBgix),4800):
		ssMoF1PYqvcgmx7Z3IwR4y5ltT = d8kolNVuLsPAjQZ9ROpUHBgix[DDSXKTgdvtyImN2aJYV35QGZjpkxoU:DDSXKTgdvtyImN2aJYV35QGZjpkxoU+4800]
		BinKGwlxWAHZQ97YVu1Cf32y = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.code')
		XCapNbgw2xWQ5jRt = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+BinKGwlxWAHZQ97YVu1Cf32y
		UFtxHq7c39mD = {'Content-Type':'text/plain'}
		y0HsepSTX49jdvnYAN53KFfIGJmra = ssMoF1PYqvcgmx7Z3IwR4y5ltT.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		T4U1lV3YFrtSv = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'POST',XCapNbgw2xWQ5jRt,y0HsepSTX49jdvnYAN53KFfIGJmra,UFtxHq7c39mD,QigevCplXxbPI1H,QigevCplXxbPI1H,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if T4U1lV3YFrtSv.succeeded:
			AHI1BUrVOKWfMlzZg = T4U1lV3YFrtSv.content
			tY1FPpMdAKvlh7WgX = CH86N7xw4cyPt3TlIBJF('str',AHI1BUrVOKWfMlzZg)
			if tY1FPpMdAKvlh7WgX:
				tY1FPpMdAKvlh7WgX = tY1FPpMdAKvlh7WgX['translation']
				tY1FPpMdAKvlh7WgX = arFSQucmG9HxDody67JCI8pBMk4L(tY1FPpMdAKvlh7WgX)
				for Aevbx5WrR2zHw3noa8VX9m0jNUtqCL in range(len(tY1FPpMdAKvlh7WgX)):
					kBLZSOWsqXyoCUcmt1JdgENn += tY1FPpMdAKvlh7WgX[Aevbx5WrR2zHw3noa8VX9m0jNUtqCL][0]
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000001','===== ===== =====')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000002',iVCLpNIM8BQs9PdSgKZvlFeo3a5)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000003',r9rhtA5Tek8sIoLfqwF7JcEV)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000004',jhAlCQ47ZgG)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000005','[RIGHT]')
	for bb6LKGv5OYmaWIHz3ZfuUS in list(yv8jxCcI6hqTtmwU1epgbuaDLkNn.keys()):
		q8scEzedK6lRra = yv8jxCcI6hqTtmwU1epgbuaDLkNn[bb6LKGv5OYmaWIHz3ZfuUS]
		kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace(bb6LKGv5OYmaWIHz3ZfuUS,q8scEzedK6lRra)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.split('\n\n\n\n')
	return hQuKXxJP80LCAaZO62q13bv4+kBLZSOWsqXyoCUcmt1JdgENn
def xBRodiLb5mlKMk0nCAESX(kcZDbGjVROS96nrzfL1wpq2te):
	hQuKXxJP80LCAaZO62q13bv4,kBLZSOWsqXyoCUcmt1JdgENn, = [],QigevCplXxbPI1H
	for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
		if not Sy8dRNAqBu: hQuKXxJP80LCAaZO62q13bv4.append(QigevCplXxbPI1H)
		else: break
	kcZDbGjVROS96nrzfL1wpq2te = kcZDbGjVROS96nrzfL1wpq2te[len(hQuKXxJP80LCAaZO62q13bv4):]
	d8kolNVuLsPAjQZ9ROpUHBgix = '\\n\\n\\n\\n'.join(kcZDbGjVROS96nrzfL1wpq2te)
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('كلا','no')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('استمرار','continue')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('===== ===== =====','000001')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,'000002')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(r9rhtA5Tek8sIoLfqwF7JcEV,'000003')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(jhAlCQ47ZgG,'000004')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[RIGHT]','000005')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[CENTER]','000006')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[RTL]','000007')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace("'","\\\\\\'")
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('"','\\\\\\"')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(aSBkt4OU8JpWTEzVIHjAiv,'\\n')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(Ymkp8qFPsjovc57UT,'\\\\r')
	for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(0,len(d8kolNVuLsPAjQZ9ROpUHBgix),4800):
		ssMoF1PYqvcgmx7Z3IwR4y5ltT = d8kolNVuLsPAjQZ9ROpUHBgix[DDSXKTgdvtyImN2aJYV35QGZjpkxoU:DDSXKTgdvtyImN2aJYV35QGZjpkxoU+4800]
		XCapNbgw2xWQ5jRt = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		UFtxHq7c39mD = {'Content-Type':'application/x-www-form-urlencoded'}
		BinKGwlxWAHZQ97YVu1Cf32y = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.code')
		y0HsepSTX49jdvnYAN53KFfIGJmra = 'f.req='+sqXK91rDldVAEcRTSQL4n2tbC('[[["MkEWBc","[[\\"'+ssMoF1PYqvcgmx7Z3IwR4y5ltT+'\\",\\"ar\\",\\"'+BinKGwlxWAHZQ97YVu1Cf32y+'\\",1],[]]",null,"generic"]]]',QigevCplXxbPI1H)
		y0HsepSTX49jdvnYAN53KFfIGJmra = y0HsepSTX49jdvnYAN53KFfIGJmra.replace('%5Cn','%5C%5Cn')
		T4U1lV3YFrtSv = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'POST',XCapNbgw2xWQ5jRt,y0HsepSTX49jdvnYAN53KFfIGJmra,UFtxHq7c39mD,QigevCplXxbPI1H,QigevCplXxbPI1H,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if T4U1lV3YFrtSv.succeeded:
			AHI1BUrVOKWfMlzZg = T4U1lV3YFrtSv.content
			AHI1BUrVOKWfMlzZg = AHI1BUrVOKWfMlzZg.split(aSBkt4OU8JpWTEzVIHjAiv)[-1]
			tY1FPpMdAKvlh7WgX = CH86N7xw4cyPt3TlIBJF('str',AHI1BUrVOKWfMlzZg)[0][2]
			if tY1FPpMdAKvlh7WgX:
				tY1FPpMdAKvlh7WgX = CH86N7xw4cyPt3TlIBJF('str',tY1FPpMdAKvlh7WgX)[1][0][0][5]
				tY1FPpMdAKvlh7WgX = arFSQucmG9HxDody67JCI8pBMk4L(tY1FPpMdAKvlh7WgX)
				for Aevbx5WrR2zHw3noa8VX9m0jNUtqCL in range(len(tY1FPpMdAKvlh7WgX)):
					kBLZSOWsqXyoCUcmt1JdgENn += tY1FPpMdAKvlh7WgX[Aevbx5WrR2zHw3noa8VX9m0jNUtqCL][0]
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('00000','0000').replace('0000','000')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0001','===== ===== =====')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0002',iVCLpNIM8BQs9PdSgKZvlFeo3a5)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0003',r9rhtA5Tek8sIoLfqwF7JcEV)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0004',jhAlCQ47ZgG)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0005','[RIGHT]')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0006','[CENTER]')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0007','[RTL]')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.split('\n\n\n\n')
	return hQuKXxJP80LCAaZO62q13bv4+kBLZSOWsqXyoCUcmt1JdgENn
def h5QoALNsIakln1rdwe(kcZDbGjVROS96nrzfL1wpq2te):
	hQuKXxJP80LCAaZO62q13bv4,X5Qt0WZ7zNmILe4gqBDECKckUV = [],[]
	for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
		if not Sy8dRNAqBu: hQuKXxJP80LCAaZO62q13bv4.append(QigevCplXxbPI1H)
		else: break
	kcZDbGjVROS96nrzfL1wpq2te = kcZDbGjVROS96nrzfL1wpq2te[len(hQuKXxJP80LCAaZO62q13bv4):]
	d8kolNVuLsPAjQZ9ROpUHBgix = '\n\n\n\n'.join(kcZDbGjVROS96nrzfL1wpq2te)
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('كلا','no')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('استمرار','continue')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('أدناه','below')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,'00001')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(r9rhtA5Tek8sIoLfqwF7JcEV,'00002')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(jhAlCQ47ZgG,'00003')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('=====','00004')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(',','00005')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[RTL]','00009')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[CENTER]','0000A')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(Ymkp8qFPsjovc57UT,'0000B')
	kcZDbGjVROS96nrzfL1wpq2te = d8kolNVuLsPAjQZ9ROpUHBgix.split(aSBkt4OU8JpWTEzVIHjAiv)
	d8kolNVuLsPAjQZ9ROpUHBgix,kBLZSOWsqXyoCUcmt1JdgENn = QigevCplXxbPI1H,QigevCplXxbPI1H
	for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
		if len(d8kolNVuLsPAjQZ9ROpUHBgix+Sy8dRNAqBu)<1800: d8kolNVuLsPAjQZ9ROpUHBgix += aSBkt4OU8JpWTEzVIHjAiv+Sy8dRNAqBu
		else:
			X5Qt0WZ7zNmILe4gqBDECKckUV.append(d8kolNVuLsPAjQZ9ROpUHBgix)
			d8kolNVuLsPAjQZ9ROpUHBgix = Sy8dRNAqBu
	X5Qt0WZ7zNmILe4gqBDECKckUV.append(d8kolNVuLsPAjQZ9ROpUHBgix)
	import json as hlKGtjPuCaeIWUwvgMxp9
	for Sy8dRNAqBu in X5Qt0WZ7zNmILe4gqBDECKckUV:
		UFtxHq7c39mD = {'Content-Type':'application/json','User-Agent':QigevCplXxbPI1H}
		XCapNbgw2xWQ5jRt = 'https://api.reverso.net/translate/v1/translation'
		BinKGwlxWAHZQ97YVu1Cf32y = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.code')
		y0HsepSTX49jdvnYAN53KFfIGJmra = {"format":"text","from":"ara","to":BinKGwlxWAHZQ97YVu1Cf32y,"input":Sy8dRNAqBu,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		y0HsepSTX49jdvnYAN53KFfIGJmra = hlKGtjPuCaeIWUwvgMxp9.dumps(y0HsepSTX49jdvnYAN53KFfIGJmra)
		T4U1lV3YFrtSv = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'POST',XCapNbgw2xWQ5jRt,y0HsepSTX49jdvnYAN53KFfIGJmra,UFtxHq7c39mD,QigevCplXxbPI1H,QigevCplXxbPI1H,'LIBRARY-REVERSO_TRANSLATE-1st')
		if T4U1lV3YFrtSv.succeeded:
			AHI1BUrVOKWfMlzZg = T4U1lV3YFrtSv.content
			AHI1BUrVOKWfMlzZg = CH86N7xw4cyPt3TlIBJF('dict',AHI1BUrVOKWfMlzZg)
			kBLZSOWsqXyoCUcmt1JdgENn += aSBkt4OU8JpWTEzVIHjAiv+QigevCplXxbPI1H.join(AHI1BUrVOKWfMlzZg['translation'])
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn[2:]
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000000','00000').replace('00000','0000').replace('0000','000')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0001',iVCLpNIM8BQs9PdSgKZvlFeo3a5)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0002',r9rhtA5Tek8sIoLfqwF7JcEV)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0003',jhAlCQ47ZgG)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0004','=====')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0005',',')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('0009','[RTL]')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000A','[CENTER]')
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.replace('000B',Ymkp8qFPsjovc57UT)
	kBLZSOWsqXyoCUcmt1JdgENn = kBLZSOWsqXyoCUcmt1JdgENn.split('\n\n\n\n')
	return hQuKXxJP80LCAaZO62q13bv4+kBLZSOWsqXyoCUcmt1JdgENn
def nKBlgoMNaSr0wx(kcZDbGjVROS96nrzfL1wpq2te):
	rOJ0qkgs3p2VwCxWMP69 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.translate')
	if not rOJ0qkgs3p2VwCxWMP69 or not kcZDbGjVROS96nrzfL1wpq2te: return kcZDbGjVROS96nrzfL1wpq2te
	dnD7eUchiyoZwQ9 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.provider')
	BinKGwlxWAHZQ97YVu1Cf32y = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.code')
	rI4qFZGtUljD8k1YPLBKc6Ng9w = BinKGwlxWAHZQ97YVu1Cf32y+'__'+str(kcZDbGjVROS96nrzfL1wpq2te)
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.language.translate',QigevCplXxbPI1H)
	kBLZSOWsqXyoCUcmt1JdgENn = wZ8QjMrd2u3V6TGxsmU(qH5vZR0MhF97zt4PULV,'list','TRANSLATE_'+dnD7eUchiyoZwQ9,rI4qFZGtUljD8k1YPLBKc6Ng9w)
	if not kBLZSOWsqXyoCUcmt1JdgENn:
		if dnD7eUchiyoZwQ9=='GOOGLE': kBLZSOWsqXyoCUcmt1JdgENn = xBRodiLb5mlKMk0nCAESX(kcZDbGjVROS96nrzfL1wpq2te)
		elif dnD7eUchiyoZwQ9=='REVERSO': kBLZSOWsqXyoCUcmt1JdgENn = h5QoALNsIakln1rdwe(kcZDbGjVROS96nrzfL1wpq2te)
		elif dnD7eUchiyoZwQ9=='GLOSBE': kBLZSOWsqXyoCUcmt1JdgENn = K0KkCQPqE3ONvWm7yJtXn1f(kcZDbGjVROS96nrzfL1wpq2te)
		if len(kcZDbGjVROS96nrzfL1wpq2te)==len(kBLZSOWsqXyoCUcmt1JdgENn):
			BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(qH5vZR0MhF97zt4PULV,'TRANSLATE_'+dnD7eUchiyoZwQ9,rI4qFZGtUljD8k1YPLBKc6Ng9w,kBLZSOWsqXyoCUcmt1JdgENn,hWYVzubgexwTPIfq)
		else:
			kBLZSOWsqXyoCUcmt1JdgENn = kcZDbGjVROS96nrzfL1wpq2te
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc('الترجمة فشلت','Translation Failed')
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.language.translate','1')
	return kBLZSOWsqXyoCUcmt1JdgENn
def O4uqMjBo8zCZ(HARXP1tbN8r6xYlm,gEDUA8kJHb9FsQ0Z4hawim,jgA5IRNqLonwC47,CCW3YZq7DPnjk,VL5PGFDltuySfkhT0n6e29zHU8O):
	pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ = HARXP1tbN8r6xYlm
	Vc48o3resjF6Cp5NUaAd1fkWyRhJ = []
	rOJ0qkgs3p2VwCxWMP69 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.translate')
	if rOJ0qkgs3p2VwCxWMP69:
		Gs9hHq0xFbARMDivz,VhKQRTpbSqGoPOIz,zzdef5IGnDO = [],[],[]
		if not Vc48o3resjF6Cp5NUaAd1fkWyRhJ:
			for FMGs1KZyN6v8ufxThbSe in gEDUA8kJHb9FsQ0Z4hawim:
				zsj5qOxnfaXmdEco3DK29HgYybUCM6 = FMGs1KZyN6v8ufxThbSe['name'].replace(AhkIX24vpNGzdLU5,QigevCplXxbPI1H).replace(yy7OzVc6J5WiY4pLMwFoXRs,QigevCplXxbPI1H)
				gJYDRfkQNnmcueMUwiSX0oyvWzOHl = sBvufaD6c9YHdOqTjCQ3.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if gJYDRfkQNnmcueMUwiSX0oyvWzOHl:
					hQuKXxJP80LCAaZO62q13bv4,uAdeYhMRpq4VwyJ6W9,LA4hIWnHFV6fM8,HawVfkRcO6pK9,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = gJYDRfkQNnmcueMUwiSX0oyvWzOHl[0]
					gJYDRfkQNnmcueMUwiSX0oyvWzOHl = hQuKXxJP80LCAaZO62q13bv4+uAdeYhMRpq4VwyJ6W9+hT7zFDpEyUqf8sXuN+LA4hIWnHFV6fM8+HawVfkRcO6pK9+hT7zFDpEyUqf8sXuN
				else:
					gJYDRfkQNnmcueMUwiSX0oyvWzOHl = sBvufaD6c9YHdOqTjCQ3.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					if gJYDRfkQNnmcueMUwiSX0oyvWzOHl:
						zsj5qOxnfaXmdEco3DK29HgYybUCM6,hQuKXxJP80LCAaZO62q13bv4,LA4hIWnHFV6fM8,uAdeYhMRpq4VwyJ6W9,HawVfkRcO6pK9 = gJYDRfkQNnmcueMUwiSX0oyvWzOHl[0]
						gJYDRfkQNnmcueMUwiSX0oyvWzOHl = hQuKXxJP80LCAaZO62q13bv4+uAdeYhMRpq4VwyJ6W9+hT7zFDpEyUqf8sXuN+LA4hIWnHFV6fM8+HawVfkRcO6pK9+hT7zFDpEyUqf8sXuN
					else: gJYDRfkQNnmcueMUwiSX0oyvWzOHl = QigevCplXxbPI1H
				qFkl8PWfGsCo = sBvufaD6c9YHdOqTjCQ3.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if qFkl8PWfGsCo: qFkl8PWfGsCo,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = qFkl8PWfGsCo[0]
				else: qFkl8PWfGsCo = QigevCplXxbPI1H
				Gs9hHq0xFbARMDivz.append(gJYDRfkQNnmcueMUwiSX0oyvWzOHl+qFkl8PWfGsCo)
				VhKQRTpbSqGoPOIz.append(zsj5qOxnfaXmdEco3DK29HgYybUCM6)
			zzdef5IGnDO = nKBlgoMNaSr0wx(VhKQRTpbSqGoPOIz)
			if zzdef5IGnDO:
				for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(len(gEDUA8kJHb9FsQ0Z4hawim)):
					FMGs1KZyN6v8ufxThbSe = gEDUA8kJHb9FsQ0Z4hawim[DDSXKTgdvtyImN2aJYV35QGZjpkxoU]
					FMGs1KZyN6v8ufxThbSe['name'] = Gs9hHq0xFbARMDivz[DDSXKTgdvtyImN2aJYV35QGZjpkxoU]+zzdef5IGnDO[DDSXKTgdvtyImN2aJYV35QGZjpkxoU]
					Vc48o3resjF6Cp5NUaAd1fkWyRhJ.append(FMGs1KZyN6v8ufxThbSe)
	if Vc48o3resjF6Cp5NUaAd1fkWyRhJ: gEDUA8kJHb9FsQ0Z4hawim = Vc48o3resjF6Cp5NUaAd1fkWyRhJ
	t03tnAoJWKVO2cDwzTy4MRGQdlZkPC,oIt3ErUwSsxuC,MVTeZRq5zy4SrQD0B6fk1dh8J = [],0,0
	UZcdHKuDWFPCXT4kfJMejgYq15sRnz = uUTRHgAXJzm7pIDBjNt8.getSetting('av.status.menusimages')
	if UZcdHKuDWFPCXT4kfJMejgYq15sRnz!='STOP':
		yyJ87FpLV3vIQgN2OhemA = KiTt9ZskMLjnCAUIJNXD7.path.join(UE7QOpJtiYsfF8bTd4vVowZ,TsckNQJ6yLiaEeCRml98WwKfVP0dYv)
		try: azYrvwpZAXnMg = KiTt9ZskMLjnCAUIJNXD7.listdir(yyJ87FpLV3vIQgN2OhemA)
		except:
			if not KiTt9ZskMLjnCAUIJNXD7.path.exists(yyJ87FpLV3vIQgN2OhemA):
				try: KiTt9ZskMLjnCAUIJNXD7.makedirs(yyJ87FpLV3vIQgN2OhemA)
				except: pass
			azYrvwpZAXnMg = []
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc('إضافة الكتابة لصور القائمة','انتظار',B3TKLo71hAGRqYgV0=500)
	HXkwoVgTD8qRAYBvKW937aJpf = yD5QizUb9L('menu_item')
	for FMGs1KZyN6v8ufxThbSe in gEDUA8kJHb9FsQ0Z4hawim:
		zsj5qOxnfaXmdEco3DK29HgYybUCM6 = FMGs1KZyN6v8ufxThbSe['name']
		wwmp1ML4Uvr8HOQ3kBsgR = FMGs1KZyN6v8ufxThbSe['context_menu']
		xEONn4MiG9Qofh8XLHc01gaZ = FMGs1KZyN6v8ufxThbSe['plot']
		oohOBPc9eiLV63JQ0EGfUSu1 = FMGs1KZyN6v8ufxThbSe['stars']
		hhQxqntdaHTLE0V4UMXbOvgepKRG = FMGs1KZyN6v8ufxThbSe['image']
		pf6P4wckhgTa = FMGs1KZyN6v8ufxThbSe['type']
		aU7D9VldsKxSr0 = FMGs1KZyN6v8ufxThbSe['duration']
		lLpcD9SvTIkVOXnhqGQJxBNH = FMGs1KZyN6v8ufxThbSe['isFolder']
		pySnuJGXihUzrkBWftdQHTglCVOM = FMGs1KZyN6v8ufxThbSe['newpath']
		pKswJV7XtIkv41n = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.ListItem(zsj5qOxnfaXmdEco3DK29HgYybUCM6)
		pKswJV7XtIkv41n.addContextMenuItems(wwmp1ML4Uvr8HOQ3kBsgR)
		pCZfoEOqX6NsMW1KRe3 = False if UZcdHKuDWFPCXT4kfJMejgYq15sRnz!='STOP' else True
		if hhQxqntdaHTLE0V4UMXbOvgepKRG:
			pKswJV7XtIkv41n.setArt({'icon':hhQxqntdaHTLE0V4UMXbOvgepKRG,'thumb':hhQxqntdaHTLE0V4UMXbOvgepKRG,'fanart':hhQxqntdaHTLE0V4UMXbOvgepKRG,'banner':hhQxqntdaHTLE0V4UMXbOvgepKRG,'clearart':hhQxqntdaHTLE0V4UMXbOvgepKRG,'poster':hhQxqntdaHTLE0V4UMXbOvgepKRG,'clearlogo':hhQxqntdaHTLE0V4UMXbOvgepKRG,'landscape':hhQxqntdaHTLE0V4UMXbOvgepKRG})
			pCZfoEOqX6NsMW1KRe3 = False
		elif not pCZfoEOqX6NsMW1KRe3:
			pCZfoEOqX6NsMW1KRe3 = True
			zsj5qOxnfaXmdEco3DK29HgYybUCM6 = RU3DWNPsrdXFHT7jB0lmC(zsj5qOxnfaXmdEco3DK29HgYybUCM6)
			zsj5qOxnfaXmdEco3DK29HgYybUCM6 = W8eXj3fGrbByNQPCnhY(zsj5qOxnfaXmdEco3DK29HgYybUCM6)
			pmT8IP5qluDYF = zsj5qOxnfaXmdEco3DK29HgYybUCM6+'.png'
			EMS1sITJuCkK9HbtAhyOBPc0mroga = KiTt9ZskMLjnCAUIJNXD7.path.join(yyJ87FpLV3vIQgN2OhemA,pmT8IP5qluDYF)
			if pmT8IP5qluDYF in azYrvwpZAXnMg:
				pKswJV7XtIkv41n.setArt({'icon':EMS1sITJuCkK9HbtAhyOBPc0mroga,'thumb':EMS1sITJuCkK9HbtAhyOBPc0mroga,'fanart':EMS1sITJuCkK9HbtAhyOBPc0mroga,'banner':EMS1sITJuCkK9HbtAhyOBPc0mroga,'clearart':EMS1sITJuCkK9HbtAhyOBPc0mroga,'poster':EMS1sITJuCkK9HbtAhyOBPc0mroga,'clearlogo':EMS1sITJuCkK9HbtAhyOBPc0mroga,'landscape':EMS1sITJuCkK9HbtAhyOBPc0mroga})
				pCZfoEOqX6NsMW1KRe3 = False
			elif oIt3ErUwSsxuC<50 and MVTeZRq5zy4SrQD0B6fk1dh8J<=3:
				try:
					FapQSfNAvRtD43UXiM278lWbkxB = zsWpkY584JGl9ZR3IUhX(HXkwoVgTD8qRAYBvKW937aJpf,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,zsj5qOxnfaXmdEco3DK29HgYybUCM6,'menu_item','center',False,EMS1sITJuCkK9HbtAhyOBPc0mroga)
					pKswJV7XtIkv41n.setArt({'icon':EMS1sITJuCkK9HbtAhyOBPc0mroga,'thumb':EMS1sITJuCkK9HbtAhyOBPc0mroga,'fanart':EMS1sITJuCkK9HbtAhyOBPc0mroga,'banner':EMS1sITJuCkK9HbtAhyOBPc0mroga,'clearart':EMS1sITJuCkK9HbtAhyOBPc0mroga,'poster':EMS1sITJuCkK9HbtAhyOBPc0mroga,'clearlogo':EMS1sITJuCkK9HbtAhyOBPc0mroga,'landscape':EMS1sITJuCkK9HbtAhyOBPc0mroga})
					oIt3ErUwSsxuC += 1
					pCZfoEOqX6NsMW1KRe3 = False
				except: MVTeZRq5zy4SrQD0B6fk1dh8J += 1
		if pCZfoEOqX6NsMW1KRe3:
			pKswJV7XtIkv41n.setArt({'icon':jdasRuBy7t3JXE2g,'thumb':jdasRuBy7t3JXE2g,'fanart':jdasRuBy7t3JXE2g,'banner':jdasRuBy7t3JXE2g,'clearart':jdasRuBy7t3JXE2g,'poster':jdasRuBy7t3JXE2g,'clearlogo':jdasRuBy7t3JXE2g,'landscape':jdasRuBy7t3JXE2g})
		if aybmzWnDkuEcT3jpJClB2<20:
			if xEONn4MiG9Qofh8XLHc01gaZ: pKswJV7XtIkv41n.setInfo('video',{'Plot':xEONn4MiG9Qofh8XLHc01gaZ,'PlotOutline':xEONn4MiG9Qofh8XLHc01gaZ})
			if oohOBPc9eiLV63JQ0EGfUSu1: pKswJV7XtIkv41n.setInfo('video',{'Rating':oohOBPc9eiLV63JQ0EGfUSu1})
			if not hhQxqntdaHTLE0V4UMXbOvgepKRG:
				pKswJV7XtIkv41n.setInfo('video',{'Title':zsj5qOxnfaXmdEco3DK29HgYybUCM6})
			if pf6P4wckhgTa=='video':
				pKswJV7XtIkv41n.setInfo('video',{'mediatype':'movie'})
				if aU7D9VldsKxSr0: pKswJV7XtIkv41n.setInfo('video',{'duration':aU7D9VldsKxSr0})
				pKswJV7XtIkv41n.setProperty('IsPlayable','true')
		else:
			TUF9BiDvJ341Mlpg = pKswJV7XtIkv41n.getVideoInfoTag()
			if oohOBPc9eiLV63JQ0EGfUSu1: TUF9BiDvJ341Mlpg.setRating(float(oohOBPc9eiLV63JQ0EGfUSu1))
			if not hhQxqntdaHTLE0V4UMXbOvgepKRG:
				TUF9BiDvJ341Mlpg.setTitle(zsj5qOxnfaXmdEco3DK29HgYybUCM6)
			if pf6P4wckhgTa=='video':
				TUF9BiDvJ341Mlpg.setMediaType('tvshow')
				if aU7D9VldsKxSr0: TUF9BiDvJ341Mlpg.setDuration(aU7D9VldsKxSr0)
				pKswJV7XtIkv41n.setProperty('IsPlayable','true')
		t03tnAoJWKVO2cDwzTy4MRGQdlZkPC.append((pySnuJGXihUzrkBWftdQHTglCVOM,pKswJV7XtIkv41n,lLpcD9SvTIkVOXnhqGQJxBNH))
	Z7ZstrGoNP3XSLYClzUm8TqV.setContent(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,'tvshows')
	qqDK9vrjV43YSsuFe6TQ7LAcibHxBP = Z7ZstrGoNP3XSLYClzUm8TqV.addDirectoryItems(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,t03tnAoJWKVO2cDwzTy4MRGQdlZkPC)
	Z7ZstrGoNP3XSLYClzUm8TqV.endOfDirectory(NNZh0HbgakloGKdCOUYJ3W1SAnXPwi,jgA5IRNqLonwC47,CCW3YZq7DPnjk,VL5PGFDltuySfkhT0n6e29zHU8O)
	return qqDK9vrjV43YSsuFe6TQ7LAcibHxBP
def E6WSo7GYiNkQ8TU5dH9aqFtClARLj(pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG=QigevCplXxbPI1H,iIBnwPa3gYp4d=QigevCplXxbPI1H,d8kolNVuLsPAjQZ9ROpUHBgix=QigevCplXxbPI1H,SFQtU7cnyeo=QigevCplXxbPI1H,TV74iI95g1jkpRMyQ={}):
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H).replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace('\t',QigevCplXxbPI1H)
	XCapNbgw2xWQ5jRt = XCapNbgw2xWQ5jRt.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H).replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace('\t',QigevCplXxbPI1H)
	if '_SCRIPT_' in zsj5qOxnfaXmdEco3DK29HgYybUCM6: JwBc6IZ4xeLmM8,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.split('_SCRIPT_',1)
	else: JwBc6IZ4xeLmM8,zsj5qOxnfaXmdEco3DK29HgYybUCM6 = QigevCplXxbPI1H,zsj5qOxnfaXmdEco3DK29HgYybUCM6
	if JwBc6IZ4xeLmM8:
		zsg0Xlw1j3yorSthG = zsj5qOxnfaXmdEco3DK29HgYybUCM6
		if not zsg0Xlw1j3yorSthG: zsg0Xlw1j3yorSthG = '....'
		elif zsg0Xlw1j3yorSthG.count('_')>1: zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.split('_',2)[2]
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace(' ',QigevCplXxbPI1H)
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('ـ',QigevCplXxbPI1H).replace('ة','ه').replace('ؤ','و')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('َ',QigevCplXxbPI1H).replace('ً',QigevCplXxbPI1H).replace('ُ',QigevCplXxbPI1H).replace('ٌ',QigevCplXxbPI1H)
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('ِ',QigevCplXxbPI1H).replace('ٍ',QigevCplXxbPI1H).replace('ْ',QigevCplXxbPI1H).replace('ّ',QigevCplXxbPI1H)
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('|',QigevCplXxbPI1H).replace('~',QigevCplXxbPI1H)
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('اون لاين',QigevCplXxbPI1H).replace('سيما لايت',QigevCplXxbPI1H)
		aVyWiUt3w5GYxA6RSkd = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(K98qyBI4dRrCLmhPviSoN13DxW5b in zsg0Xlw1j3yorSthG for K98qyBI4dRrCLmhPviSoN13DxW5b in aVyWiUt3w5GYxA6RSkd): zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('ال',QigevCplXxbPI1H)
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		zsg0Xlw1j3yorSthG = zsg0Xlw1j3yorSthG.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).strip(hT7zFDpEyUqf8sXuN)
		JwBc6IZ4xeLmM8 = '_LST_'+aMNuxgv3BlLwp8jEJqAkYKCiy9b1o(JwBc6IZ4xeLmM8)
		if zsg0Xlw1j3yorSthG not in list(MGNnlD6YCcemWAuhkL.keys()): MGNnlD6YCcemWAuhkL[zsg0Xlw1j3yorSthG] = {}
		MGNnlD6YCcemWAuhkL[zsg0Xlw1j3yorSthG][JwBc6IZ4xeLmM8] = [pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ]
	lc0jJQ4zboeDI3tqTrpvm5gZO.append([pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ])
	return
def i7gQvkPzZJm4jM3uYV2xfAqhs(aU2sDcSyTmR1fPKh4FZWH5b):
	if b7sJAmSxlBvaMdHFz: from html import unescape as _fgQsBjqI2Lb8Z
	else:
		from HTMLParser import HTMLParser as D6pv4zPjqa2QrLFX1eBc7yiObg
		_fgQsBjqI2Lb8Z = D6pv4zPjqa2QrLFX1eBc7yiObg().unescape
	if '&' in aU2sDcSyTmR1fPKh4FZWH5b and ';' in aU2sDcSyTmR1fPKh4FZWH5b:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: aU2sDcSyTmR1fPKh4FZWH5b = aU2sDcSyTmR1fPKh4FZWH5b.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		aU2sDcSyTmR1fPKh4FZWH5b = _fgQsBjqI2Lb8Z(aU2sDcSyTmR1fPKh4FZWH5b)
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: aU2sDcSyTmR1fPKh4FZWH5b = aU2sDcSyTmR1fPKh4FZWH5b.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	return aU2sDcSyTmR1fPKh4FZWH5b
def arFSQucmG9HxDody67JCI8pBMk4L(aU2sDcSyTmR1fPKh4FZWH5b):
	if '\\u' in aU2sDcSyTmR1fPKh4FZWH5b:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: aU2sDcSyTmR1fPKh4FZWH5b = aU2sDcSyTmR1fPKh4FZWH5b.decode('unicode_escape','ignore').encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		elif b7sJAmSxlBvaMdHFz: aU2sDcSyTmR1fPKh4FZWH5b = aU2sDcSyTmR1fPKh4FZWH5b.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL).decode('unicode_escape','ignore')
	return aU2sDcSyTmR1fPKh4FZWH5b
def SYUGgKyAwVTOQs9nuxR04(UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,TTuPjazY6hU0wxGse14dCmMLvKZAo,i6YtAZuKdVp9eB1TkDO,XXnwJYbOQFs7CjcG8aRMHgLEzoSy,d8kolNVuLsPAjQZ9ROpUHBgix,a3PhDutjdbGQJ,ck6JqfyFOxtIM0Ru1VNBhlZ,yA4c5EWr9lXn1mbQ,YuJ06h7UQl):
	vrqAjCFolhNBfs = KiTt9ZskMLjnCAUIJNXD7.path.dirname(YuJ06h7UQl)
	if not KiTt9ZskMLjnCAUIJNXD7.path.exists(vrqAjCFolhNBfs):
		try: KiTt9ZskMLjnCAUIJNXD7.makedirs(vrqAjCFolhNBfs)
		except: pass
	JZCI0MW8DHObXPSmNxpAdL7u2 = yD5QizUb9L(a3PhDutjdbGQJ)
	FapQSfNAvRtD43UXiM278lWbkxB = zsWpkY584JGl9ZR3IUhX(JZCI0MW8DHObXPSmNxpAdL7u2,UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,TTuPjazY6hU0wxGse14dCmMLvKZAo,i6YtAZuKdVp9eB1TkDO,XXnwJYbOQFs7CjcG8aRMHgLEzoSy,d8kolNVuLsPAjQZ9ROpUHBgix,a3PhDutjdbGQJ,ck6JqfyFOxtIM0Ru1VNBhlZ,yA4c5EWr9lXn1mbQ,YuJ06h7UQl)
	return FapQSfNAvRtD43UXiM278lWbkxB
def yD5QizUb9L(a3PhDutjdbGQJ):
	kPljdKaTuYBIvC = 5
	YmWo3C5FOscwvMIhnd1B4XA = 20
	KB94C1EhzsgtXlAnQFLZ = 20
	lgqepE4LBCRnbk = 0
	hqNOzsgXJAtjTGZCR4Y = 'center'
	BRymCWvuJ9TQogkZ0Pxq8M4L = 0
	mNJoebY9cUgyM1BwlqpKF = 19
	aOviyboTG81Q = 30
	jFpC4BE9Yah2lW1ImxyD58ZsTNXG = 8
	bXvQkKl3g2EyUrFsd8wDJHViY = True
	g6SiYfTHh2 = 375
	vv6YI1DNhG = 410
	YYJF2PGz1Lki8ds = 50
	ME0TKSkuYzpcj = 280
	YUEopeV6jdaXJTOLvm2GxMt = 28
	kHpUuJ7qG60OgdjiMyxhv = 5
	L4VvI60AwSkW9eJu = 0
	nFbHA9a2chJeZl8wNzqMy0oRj = 31
	X8xPeW4cJKgNdj2FoMphyrqB = [36,32,28]
	from PIL import ImageDraw as A9EuBOqiFelKUSzQMgc,ImageFont as wLNAcp1EzHoU5q7t9hfTKGli0IOS,Image as SYgdGcXQU74TrsHwfWz
	if a3PhDutjdbGQJ in ['notification','notification_twohalfs']:
		if a3PhDutjdbGQJ=='notification_twohalfs':
			N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = 'UPPER',720
			hqNOzsgXJAtjTGZCR4Y = 'right'
			bXvQkKl3g2EyUrFsd8wDJHViY = True
			lgqepE4LBCRnbk = 10
		else:
			N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = 97+20,720
			hqNOzsgXJAtjTGZCR4Y = 'left'
			bXvQkKl3g2EyUrFsd8wDJHViY = False
		X8xPeW4cJKgNdj2FoMphyrqB = [33,33,33]
		KB94C1EhzsgtXlAnQFLZ = 20
		YmWo3C5FOscwvMIhnd1B4XA = 0
		aOviyboTG81Q = 20
		mNJoebY9cUgyM1BwlqpKF = 25+10
	elif a3PhDutjdbGQJ=='menu_item':
		X8xPeW4cJKgNdj2FoMphyrqB,QWO5ZczVTnrFNbLGxjAiR1dX6P,N3NH6hupRfydnlbXB5izMLUIeW19K = [30,30,30],200,250
		BRymCWvuJ9TQogkZ0Pxq8M4L,aOviyboTG81Q,mNJoebY9cUgyM1BwlqpKF, = 0,-10,-30
		YmWo3C5FOscwvMIhnd1B4XA = 0
		fXr84VTLYl5khJjd6mb9WMIv = SYgdGcXQU74TrsHwfWz.open(jdasRuBy7t3JXE2g)
		zHVXfweRirU6qLZab = SYgdGcXQU74TrsHwfWz.new('RGBA',(QWO5ZczVTnrFNbLGxjAiR1dX6P,N3NH6hupRfydnlbXB5izMLUIeW19K),(255,0,0,255))
	elif a3PhDutjdbGQJ=='confirm_smallfont': X8xPeW4cJKgNdj2FoMphyrqB,N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = [28,24,20],500,900
	elif a3PhDutjdbGQJ=='confirm_mediumfont': X8xPeW4cJKgNdj2FoMphyrqB,N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = [32,28,24],500,900
	elif a3PhDutjdbGQJ=='confirm_bigfont': X8xPeW4cJKgNdj2FoMphyrqB,N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = [36,32,28],500,900
	elif a3PhDutjdbGQJ=='textview_bigfont': N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = 740,1270
	elif a3PhDutjdbGQJ=='textview_bigfont_long': N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = 'UPPER',1270
	elif a3PhDutjdbGQJ=='textview_smallfont': X8xPeW4cJKgNdj2FoMphyrqB,N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = [28,23,18],740,1270
	elif a3PhDutjdbGQJ=='textview_smallfont_long': X8xPeW4cJKgNdj2FoMphyrqB,N3NH6hupRfydnlbXB5izMLUIeW19K,QWO5ZczVTnrFNbLGxjAiR1dX6P = [28,23,18],'UPPER',1270
	OOsrcIHJ2AqfjG185DYT,fTIZCiQJzGocj2huSkmKtwbdYaU7A,LvyPrDzwOEUV = X8xPeW4cJKgNdj2FoMphyrqB
	yFnzPDgmqrLwY4oT2S = wLNAcp1EzHoU5q7t9hfTKGli0IOS.truetype(rizEfk7lRM9ZWtTLDNS2,size=OOsrcIHJ2AqfjG185DYT)
	V2V8z4WKPGEuTq0yQReixSX9pr = wLNAcp1EzHoU5q7t9hfTKGli0IOS.truetype(rizEfk7lRM9ZWtTLDNS2,size=fTIZCiQJzGocj2huSkmKtwbdYaU7A)
	HLXzuZDhdrsYqf8Cpa0Vw = wLNAcp1EzHoU5q7t9hfTKGli0IOS.truetype(rizEfk7lRM9ZWtTLDNS2,size=LvyPrDzwOEUV)
	LacAoFf82Hj34IXJQ = QWO5ZczVTnrFNbLGxjAiR1dX6P-aOviyboTG81Q*2
	ZNIQ8wfDB0YaXhzbdJEOLoP5K67jgk = SYgdGcXQU74TrsHwfWz.new('RGBA',(LacAoFf82Hj34IXJQ,100),(255,255,255,0))
	CZOBzkIa5ySxcNbog = A9EuBOqiFelKUSzQMgc.Draw(ZNIQ8wfDB0YaXhzbdJEOLoP5K67jgk)
	ERrtSIvYHwJO0XjPG6Ffe,gsnqUOtMQGHjXF1aZYWie = CZOBzkIa5ySxcNbog.textsize('HHH BBB 888 000',font=yFnzPDgmqrLwY4oT2S)
	NCI5wnMy42YpjOqmhfLd,k5kMtqUfozO = CZOBzkIa5ySxcNbog.textsize('HHH BBB 888 000',font=V2V8z4WKPGEuTq0yQReixSX9pr)
	swDGFNHi4BvtUukp6KfMJSI2e = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as GiYD6r9mKqCeP
	cv67rhFVdtGb3q0suESDlxyQw4 = GiYD6r9mKqCeP(configuration=swDGFNHi4BvtUukp6KfMJSI2e)
	JZCI0MW8DHObXPSmNxpAdL7u2 = {}
	hag2YLMycsi6fqZebR0m1Bz3K = locals()
	for Z6ZpWLOjfodPKl3QVqrTYai8MBA9 in hag2YLMycsi6fqZebR0m1Bz3K: JZCI0MW8DHObXPSmNxpAdL7u2[Z6ZpWLOjfodPKl3QVqrTYai8MBA9] = hag2YLMycsi6fqZebR0m1Bz3K[Z6ZpWLOjfodPKl3QVqrTYai8MBA9]
	return JZCI0MW8DHObXPSmNxpAdL7u2
def zsWpkY584JGl9ZR3IUhX(JZCI0MW8DHObXPSmNxpAdL7u2,UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,TTuPjazY6hU0wxGse14dCmMLvKZAo,i6YtAZuKdVp9eB1TkDO,XXnwJYbOQFs7CjcG8aRMHgLEzoSy,d8kolNVuLsPAjQZ9ROpUHBgix,a3PhDutjdbGQJ,ck6JqfyFOxtIM0Ru1VNBhlZ,yA4c5EWr9lXn1mbQ,YuJ06h7UQl):
	for Z6ZpWLOjfodPKl3QVqrTYai8MBA9 in JZCI0MW8DHObXPSmNxpAdL7u2: globals()[Z6ZpWLOjfodPKl3QVqrTYai8MBA9] = JZCI0MW8DHObXPSmNxpAdL7u2[Z6ZpWLOjfodPKl3QVqrTYai8MBA9]
	global YUEopeV6jdaXJTOLvm2GxMt,kHpUuJ7qG60OgdjiMyxhv
	if a3PhDutjdbGQJ!='menu_item':
		rOJ0qkgs3p2VwCxWMP69 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.translate')
		if rOJ0qkgs3p2VwCxWMP69:
			if UXiAW53Tdg9HYcoPawCsOQtLDuf2yG=='نعم  Yes': UXiAW53Tdg9HYcoPawCsOQtLDuf2yG = 'Yes'
			elif UXiAW53Tdg9HYcoPawCsOQtLDuf2yG=='كلا  No': UXiAW53Tdg9HYcoPawCsOQtLDuf2yG = 'No'
			if TTuPjazY6hU0wxGse14dCmMLvKZAo=='نعم  Yes': TTuPjazY6hU0wxGse14dCmMLvKZAo = 'Yes'
			elif TTuPjazY6hU0wxGse14dCmMLvKZAo=='كلا  No': TTuPjazY6hU0wxGse14dCmMLvKZAo = 'No'
			if i6YtAZuKdVp9eB1TkDO=='نعم  Yes': i6YtAZuKdVp9eB1TkDO = 'Yes'
			elif i6YtAZuKdVp9eB1TkDO=='كلا  No': i6YtAZuKdVp9eB1TkDO = 'No'
			JX4pLs7W5Mdm = nKBlgoMNaSr0wx([UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,TTuPjazY6hU0wxGse14dCmMLvKZAo,i6YtAZuKdVp9eB1TkDO,XXnwJYbOQFs7CjcG8aRMHgLEzoSy,d8kolNVuLsPAjQZ9ROpUHBgix])
			if JX4pLs7W5Mdm: UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,TTuPjazY6hU0wxGse14dCmMLvKZAo,i6YtAZuKdVp9eB1TkDO,XXnwJYbOQFs7CjcG8aRMHgLEzoSy,d8kolNVuLsPAjQZ9ROpUHBgix = JX4pLs7W5Mdm
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
		d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		XXnwJYbOQFs7CjcG8aRMHgLEzoSy = XXnwJYbOQFs7CjcG8aRMHgLEzoSy.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		UXiAW53Tdg9HYcoPawCsOQtLDuf2yG = UXiAW53Tdg9HYcoPawCsOQtLDuf2yG.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		TTuPjazY6hU0wxGse14dCmMLvKZAo = TTuPjazY6hU0wxGse14dCmMLvKZAo.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		i6YtAZuKdVp9eB1TkDO = i6YtAZuKdVp9eB1TkDO.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	DFI4Wn7mVkHL = XXnwJYbOQFs7CjcG8aRMHgLEzoSy.count(aSBkt4OU8JpWTEzVIHjAiv)+1
	fhI4z8kvZsLbG = YmWo3C5FOscwvMIhnd1B4XA+DFI4Wn7mVkHL*(gsnqUOtMQGHjXF1aZYWie+lgqepE4LBCRnbk)-lgqepE4LBCRnbk
	if d8kolNVuLsPAjQZ9ROpUHBgix:
		Cu6IwD5v4fm0WtEJRZQXGTNF = k5kMtqUfozO+jFpC4BE9Yah2lW1ImxyD58ZsTNXG
		oqKjOT3UNJH80x9BSu1A5 = cv67rhFVdtGb3q0suESDlxyQw4.reshape(d8kolNVuLsPAjQZ9ROpUHBgix)
		if bXvQkKl3g2EyUrFsd8wDJHViY:
			I1odYHJeGzAqT23PR = kkJb10TwWSMroluPzDxa8CcvqpQ(CZOBzkIa5ySxcNbog,V2V8z4WKPGEuTq0yQReixSX9pr,oqKjOT3UNJH80x9BSu1A5,fTIZCiQJzGocj2huSkmKtwbdYaU7A,LacAoFf82Hj34IXJQ,Cu6IwD5v4fm0WtEJRZQXGTNF)
			VYcpryimu4Nk2Gh6SIJ = EMIPut17KZOvsz(I1odYHJeGzAqT23PR)
			hhLXfRmtMA3yFpV = VYcpryimu4Nk2Gh6SIJ.count(aSBkt4OU8JpWTEzVIHjAiv)+1
			xl1KWEYvQdGa = mNJoebY9cUgyM1BwlqpKF+hhLXfRmtMA3yFpV*Cu6IwD5v4fm0WtEJRZQXGTNF-jFpC4BE9Yah2lW1ImxyD58ZsTNXG
		else:
			xl1KWEYvQdGa = mNJoebY9cUgyM1BwlqpKF+k5kMtqUfozO
			VYcpryimu4Nk2Gh6SIJ = oqKjOT3UNJH80x9BSu1A5.split(aSBkt4OU8JpWTEzVIHjAiv)[0]
			I1odYHJeGzAqT23PR = oqKjOT3UNJH80x9BSu1A5.split(aSBkt4OU8JpWTEzVIHjAiv)[0]
	else: xl1KWEYvQdGa = mNJoebY9cUgyM1BwlqpKF
	EikfMB4m2X8YcUFG = L4VvI60AwSkW9eJu+nFbHA9a2chJeZl8wNzqMy0oRj
	if yA4c5EWr9lXn1mbQ:
		aaN9r2KMG6j = vv6YI1DNhG-g6SiYfTHh2
		EikfMB4m2X8YcUFG += aaN9r2KMG6j
	else: aaN9r2KMG6j = 0
	if UXiAW53Tdg9HYcoPawCsOQtLDuf2yG or TTuPjazY6hU0wxGse14dCmMLvKZAo or i6YtAZuKdVp9eB1TkDO: EikfMB4m2X8YcUFG += YYJF2PGz1Lki8ds
	FapQSfNAvRtD43UXiM278lWbkxB = N3NH6hupRfydnlbXB5izMLUIeW19K if N3NH6hupRfydnlbXB5izMLUIeW19K!='UPPER' else fhI4z8kvZsLbG+xl1KWEYvQdGa+EikfMB4m2X8YcUFG
	ZNIQ8wfDB0YaXhzbdJEOLoP5K67jgk = SYgdGcXQU74TrsHwfWz.new('RGBA',(QWO5ZczVTnrFNbLGxjAiR1dX6P,FapQSfNAvRtD43UXiM278lWbkxB),(255,255,255,0))
	s7EGMJSHWkciyuYrg3Cq0FNaVwtx = A9EuBOqiFelKUSzQMgc.Draw(ZNIQ8wfDB0YaXhzbdJEOLoP5K67jgk)
	AWhBxDtiFgfwC4Yvb2LJScT = FapQSfNAvRtD43UXiM278lWbkxB-fhI4z8kvZsLbG-EikfMB4m2X8YcUFG-mNJoebY9cUgyM1BwlqpKF
	if not TTuPjazY6hU0wxGse14dCmMLvKZAo and UXiAW53Tdg9HYcoPawCsOQtLDuf2yG and i6YtAZuKdVp9eB1TkDO:
		YUEopeV6jdaXJTOLvm2GxMt += 105
		kHpUuJ7qG60OgdjiMyxhv -= 110
	import bidi.algorithm as Vzd34t8iynRGBZ21oj
	if XXnwJYbOQFs7CjcG8aRMHgLEzoSy:
		mSFnQpKwgh = YmWo3C5FOscwvMIhnd1B4XA
		XXnwJYbOQFs7CjcG8aRMHgLEzoSy = Vzd34t8iynRGBZ21oj.get_display(cv67rhFVdtGb3q0suESDlxyQw4.reshape(XXnwJYbOQFs7CjcG8aRMHgLEzoSy))
		kcZDbGjVROS96nrzfL1wpq2te = XXnwJYbOQFs7CjcG8aRMHgLEzoSy.splitlines()
		for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
			if Sy8dRNAqBu:
				lm6oITEWndR4Aq3pD2OLMvbHsKkPS,wCmZ5UnJxebfPMKRHdVFNh = s7EGMJSHWkciyuYrg3Cq0FNaVwtx.textsize(Sy8dRNAqBu,font=yFnzPDgmqrLwY4oT2S)
				if hqNOzsgXJAtjTGZCR4Y=='center': wR4hs8P2tgYSe = kPljdKaTuYBIvC+(QWO5ZczVTnrFNbLGxjAiR1dX6P-lm6oITEWndR4Aq3pD2OLMvbHsKkPS)/2
				elif hqNOzsgXJAtjTGZCR4Y=='right': wR4hs8P2tgYSe = kPljdKaTuYBIvC+QWO5ZczVTnrFNbLGxjAiR1dX6P-lm6oITEWndR4Aq3pD2OLMvbHsKkPS-KB94C1EhzsgtXlAnQFLZ
				elif hqNOzsgXJAtjTGZCR4Y=='left': wR4hs8P2tgYSe = kPljdKaTuYBIvC+KB94C1EhzsgtXlAnQFLZ
				s7EGMJSHWkciyuYrg3Cq0FNaVwtx.text((wR4hs8P2tgYSe,mSFnQpKwgh),Sy8dRNAqBu,font=yFnzPDgmqrLwY4oT2S,fill='yellow')
			mSFnQpKwgh += OOsrcIHJ2AqfjG185DYT+lgqepE4LBCRnbk
	if UXiAW53Tdg9HYcoPawCsOQtLDuf2yG or TTuPjazY6hU0wxGse14dCmMLvKZAo or i6YtAZuKdVp9eB1TkDO:
		R3RMlw0UzOYEbxsPFVL = fhI4z8kvZsLbG+AWhBxDtiFgfwC4Yvb2LJScT+mNJoebY9cUgyM1BwlqpKF+aaN9r2KMG6j+L4VvI60AwSkW9eJu
		if UXiAW53Tdg9HYcoPawCsOQtLDuf2yG:
			UXiAW53Tdg9HYcoPawCsOQtLDuf2yG = Vzd34t8iynRGBZ21oj.get_display(cv67rhFVdtGb3q0suESDlxyQw4.reshape(UXiAW53Tdg9HYcoPawCsOQtLDuf2yG))
			MkAnSDUW7h35mo,jjsnX65vT4i0kcbOKDRUZw1lPqoEe = s7EGMJSHWkciyuYrg3Cq0FNaVwtx.textsize(UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,font=HLXzuZDhdrsYqf8Cpa0Vw)
			V7OWpSbjxkfM = YUEopeV6jdaXJTOLvm2GxMt+0*(kHpUuJ7qG60OgdjiMyxhv+ME0TKSkuYzpcj)+(ME0TKSkuYzpcj-MkAnSDUW7h35mo)/2
			s7EGMJSHWkciyuYrg3Cq0FNaVwtx.text((V7OWpSbjxkfM,R3RMlw0UzOYEbxsPFVL),UXiAW53Tdg9HYcoPawCsOQtLDuf2yG,font=HLXzuZDhdrsYqf8Cpa0Vw,fill='yellow')
		if TTuPjazY6hU0wxGse14dCmMLvKZAo:
			TTuPjazY6hU0wxGse14dCmMLvKZAo = Vzd34t8iynRGBZ21oj.get_display(cv67rhFVdtGb3q0suESDlxyQw4.reshape(TTuPjazY6hU0wxGse14dCmMLvKZAo))
			FFtiyHTnsAJc8GjE7RMIde,fGLeIcjqFuHN50Ppyt69wT38 = s7EGMJSHWkciyuYrg3Cq0FNaVwtx.textsize(TTuPjazY6hU0wxGse14dCmMLvKZAo,font=HLXzuZDhdrsYqf8Cpa0Vw)
			qFVWktSlGcK403BCfHms = YUEopeV6jdaXJTOLvm2GxMt+1*(kHpUuJ7qG60OgdjiMyxhv+ME0TKSkuYzpcj)+(ME0TKSkuYzpcj-FFtiyHTnsAJc8GjE7RMIde)/2
			s7EGMJSHWkciyuYrg3Cq0FNaVwtx.text((qFVWktSlGcK403BCfHms,R3RMlw0UzOYEbxsPFVL),TTuPjazY6hU0wxGse14dCmMLvKZAo,font=HLXzuZDhdrsYqf8Cpa0Vw,fill='yellow')
		if i6YtAZuKdVp9eB1TkDO:
			i6YtAZuKdVp9eB1TkDO = Vzd34t8iynRGBZ21oj.get_display(cv67rhFVdtGb3q0suESDlxyQw4.reshape(i6YtAZuKdVp9eB1TkDO))
			QKeXcHZaSFNM7,cVOyhndHQaLs2XivEGIwj71URMft6Y = s7EGMJSHWkciyuYrg3Cq0FNaVwtx.textsize(i6YtAZuKdVp9eB1TkDO,font=HLXzuZDhdrsYqf8Cpa0Vw)
			o6mPeOtATk0Y9z = YUEopeV6jdaXJTOLvm2GxMt+2*(kHpUuJ7qG60OgdjiMyxhv+ME0TKSkuYzpcj)+(ME0TKSkuYzpcj-QKeXcHZaSFNM7)/2
			s7EGMJSHWkciyuYrg3Cq0FNaVwtx.text((o6mPeOtATk0Y9z,R3RMlw0UzOYEbxsPFVL),i6YtAZuKdVp9eB1TkDO,font=HLXzuZDhdrsYqf8Cpa0Vw,fill='yellow')
	if d8kolNVuLsPAjQZ9ROpUHBgix:
		VVWlzxkcyfKY,w6PptSaIiqAX7WYHJuzZ = [],[]
		I1odYHJeGzAqT23PR = gCj3oYN4Zl1Dz0AELKIQJOi(I1odYHJeGzAqT23PR)
		a02K8jsQrocJ3w4iM6ugmVtCSnqb = I1odYHJeGzAqT23PR.split('_sss__newline_')
		for Yl0DdoMmbPFxKGtXhLu6EwHVqvI in a02K8jsQrocJ3w4iM6ugmVtCSnqb:
			fNYb17WhG2SaKiVuB0EnZlRTA3sx = ck6JqfyFOxtIM0Ru1VNBhlZ
			if   '_sss__lineleft_' in Yl0DdoMmbPFxKGtXhLu6EwHVqvI: fNYb17WhG2SaKiVuB0EnZlRTA3sx = 'left'
			elif '_sss__lineright_' in Yl0DdoMmbPFxKGtXhLu6EwHVqvI: fNYb17WhG2SaKiVuB0EnZlRTA3sx = 'right'
			elif '_sss__linecenter_' in Yl0DdoMmbPFxKGtXhLu6EwHVqvI: fNYb17WhG2SaKiVuB0EnZlRTA3sx = 'center'
			hBPgvEr230qZNKzVkM1Ycy6 = Yl0DdoMmbPFxKGtXhLu6EwHVqvI
			P5hGD8uwNEovnzWeMmH = sBvufaD6c9YHdOqTjCQ3.findall('_sss__.*?_',Yl0DdoMmbPFxKGtXhLu6EwHVqvI,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for BCXUkIx4Am85z in P5hGD8uwNEovnzWeMmH: hBPgvEr230qZNKzVkM1Ycy6 = hBPgvEr230qZNKzVkM1Ycy6.replace(BCXUkIx4Am85z,QigevCplXxbPI1H)
			if hBPgvEr230qZNKzVkM1Ycy6==QigevCplXxbPI1H: lm6oITEWndR4Aq3pD2OLMvbHsKkPS,wCmZ5UnJxebfPMKRHdVFNh = 0,Cu6IwD5v4fm0WtEJRZQXGTNF
			else: lm6oITEWndR4Aq3pD2OLMvbHsKkPS,wCmZ5UnJxebfPMKRHdVFNh = s7EGMJSHWkciyuYrg3Cq0FNaVwtx.textsize(hBPgvEr230qZNKzVkM1Ycy6,font=V2V8z4WKPGEuTq0yQReixSX9pr)
			if   fNYb17WhG2SaKiVuB0EnZlRTA3sx=='left': ff1gJiOBnRLNWp3A = BRymCWvuJ9TQogkZ0Pxq8M4L+aOviyboTG81Q
			elif fNYb17WhG2SaKiVuB0EnZlRTA3sx=='right': ff1gJiOBnRLNWp3A = BRymCWvuJ9TQogkZ0Pxq8M4L+aOviyboTG81Q+LacAoFf82Hj34IXJQ-lm6oITEWndR4Aq3pD2OLMvbHsKkPS
			elif fNYb17WhG2SaKiVuB0EnZlRTA3sx=='center': ff1gJiOBnRLNWp3A = BRymCWvuJ9TQogkZ0Pxq8M4L+aOviyboTG81Q+(LacAoFf82Hj34IXJQ-lm6oITEWndR4Aq3pD2OLMvbHsKkPS)/2
			if ff1gJiOBnRLNWp3A<aOviyboTG81Q: ff1gJiOBnRLNWp3A = BRymCWvuJ9TQogkZ0Pxq8M4L+aOviyboTG81Q
			VVWlzxkcyfKY.append(ff1gJiOBnRLNWp3A)
			w6PptSaIiqAX7WYHJuzZ.append(lm6oITEWndR4Aq3pD2OLMvbHsKkPS)
		ff1gJiOBnRLNWp3A = VVWlzxkcyfKY[0]
		atoG4C2f6nymLhicK3Zlp8Sbdq = I1odYHJeGzAqT23PR.split('_sss_')
		BknZzO8T20calbdpwj5MfN = (255,255,255,255)
		oR1b2qtspiJ45mNC9Hf8IgM3 = BknZzO8T20calbdpwj5MfN
		MGTpEe61yfrsgW5R48maYO,DCbfAzauMmoN2J8PZp6lYTs05LH = 0,0
		hWiQFAyvRS58kBClIxwtMD7ZJ = False
		v67Oh1UTRBML3XKQxft5ylHjg = 0
		Ckm5y4P3geiS = fhI4z8kvZsLbG+mNJoebY9cUgyM1BwlqpKF/2
		if xl1KWEYvQdGa<(AWhBxDtiFgfwC4Yvb2LJScT+mNJoebY9cUgyM1BwlqpKF):
			v2snG5LVhlSQbCWF6u = (AWhBxDtiFgfwC4Yvb2LJScT+mNJoebY9cUgyM1BwlqpKF-xl1KWEYvQdGa)/2
			Ckm5y4P3geiS = fhI4z8kvZsLbG+mNJoebY9cUgyM1BwlqpKF+v2snG5LVhlSQbCWF6u-k5kMtqUfozO/2
		for Sy8dRNAqBu in atoG4C2f6nymLhicK3Zlp8Sbdq:
			if not Sy8dRNAqBu or (Sy8dRNAqBu and ord(Sy8dRNAqBu[0])==65279): continue
			gRby7mUcPWfK = Sy8dRNAqBu.split('_newline_',1)
			mmHfOAp4UZzXcqb7Ma1 = Sy8dRNAqBu.split('_newcolor',1)
			iydUzmrIwjvXPsJYgOL5c7CF = Sy8dRNAqBu.split('_endcolor_',1)
			n2ohILerfjU1z6wvB = Sy8dRNAqBu.split('_linertl_',1)
			tNjPb3Ba42rh9igeLfQYX5CpOFGE = Sy8dRNAqBu.split('_lineleft_',1)
			BYqpAj9uCiVJXNbPw = Sy8dRNAqBu.split('_lineright_',1)
			BBbAaNGOL0ZUvp8XSVift = Sy8dRNAqBu.split('_linecenter_',1)
			if len(gRby7mUcPWfK)>1:
				v67Oh1UTRBML3XKQxft5ylHjg += 1
				Sy8dRNAqBu = gRby7mUcPWfK[1]
				MGTpEe61yfrsgW5R48maYO = 0
				ff1gJiOBnRLNWp3A = VVWlzxkcyfKY[v67Oh1UTRBML3XKQxft5ylHjg]
				DCbfAzauMmoN2J8PZp6lYTs05LH += Cu6IwD5v4fm0WtEJRZQXGTNF
				hWiQFAyvRS58kBClIxwtMD7ZJ = False
			elif len(mmHfOAp4UZzXcqb7Ma1)>1:
				Sy8dRNAqBu = mmHfOAp4UZzXcqb7Ma1[1]
				oR1b2qtspiJ45mNC9Hf8IgM3 = Sy8dRNAqBu[0:8]
				oR1b2qtspiJ45mNC9Hf8IgM3 = '#'+oR1b2qtspiJ45mNC9Hf8IgM3[2:]
				Sy8dRNAqBu = Sy8dRNAqBu[9:]
			elif len(iydUzmrIwjvXPsJYgOL5c7CF)>1:
				Sy8dRNAqBu = iydUzmrIwjvXPsJYgOL5c7CF[1]
				oR1b2qtspiJ45mNC9Hf8IgM3 = BknZzO8T20calbdpwj5MfN
			elif len(n2ohILerfjU1z6wvB)>1:
				Sy8dRNAqBu = n2ohILerfjU1z6wvB[1]
				hWiQFAyvRS58kBClIxwtMD7ZJ = True
				MGTpEe61yfrsgW5R48maYO = w6PptSaIiqAX7WYHJuzZ[v67Oh1UTRBML3XKQxft5ylHjg]
			elif len(tNjPb3Ba42rh9igeLfQYX5CpOFGE)>1: Sy8dRNAqBu = tNjPb3Ba42rh9igeLfQYX5CpOFGE[1]
			elif len(BYqpAj9uCiVJXNbPw)>1: Sy8dRNAqBu = BYqpAj9uCiVJXNbPw[1]
			elif len(BBbAaNGOL0ZUvp8XSVift)>1: Sy8dRNAqBu = BBbAaNGOL0ZUvp8XSVift[1]
			if Sy8dRNAqBu:
				n74MYGrDJaX5Iuk9 = Ckm5y4P3geiS+DCbfAzauMmoN2J8PZp6lYTs05LH
				Sy8dRNAqBu = Vzd34t8iynRGBZ21oj.get_display(Sy8dRNAqBu)
				lm6oITEWndR4Aq3pD2OLMvbHsKkPS,wCmZ5UnJxebfPMKRHdVFNh = s7EGMJSHWkciyuYrg3Cq0FNaVwtx.textsize(Sy8dRNAqBu,font=V2V8z4WKPGEuTq0yQReixSX9pr)
				if hWiQFAyvRS58kBClIxwtMD7ZJ: MGTpEe61yfrsgW5R48maYO -= lm6oITEWndR4Aq3pD2OLMvbHsKkPS
				wxOmsa879QEcYhUDgFIPbNZBd = ff1gJiOBnRLNWp3A+MGTpEe61yfrsgW5R48maYO
				s7EGMJSHWkciyuYrg3Cq0FNaVwtx.text((wxOmsa879QEcYhUDgFIPbNZBd,n74MYGrDJaX5Iuk9),Sy8dRNAqBu,font=V2V8z4WKPGEuTq0yQReixSX9pr,fill=oR1b2qtspiJ45mNC9Hf8IgM3)
				if a3PhDutjdbGQJ=='menu_item':
					s7EGMJSHWkciyuYrg3Cq0FNaVwtx.text((wxOmsa879QEcYhUDgFIPbNZBd+1,n74MYGrDJaX5Iuk9+1),Sy8dRNAqBu,font=V2V8z4WKPGEuTq0yQReixSX9pr,fill=oR1b2qtspiJ45mNC9Hf8IgM3)
				if not hWiQFAyvRS58kBClIxwtMD7ZJ: MGTpEe61yfrsgW5R48maYO += lm6oITEWndR4Aq3pD2OLMvbHsKkPS
				if n74MYGrDJaX5Iuk9>AWhBxDtiFgfwC4Yvb2LJScT+Cu6IwD5v4fm0WtEJRZQXGTNF: break
	if a3PhDutjdbGQJ=='menu_item':
		QPIoac4R7nADmdBFt1zV6 = fXr84VTLYl5khJjd6mb9WMIv.copy()
		QPIoac4R7nADmdBFt1zV6.paste(zHVXfweRirU6qLZab,(0,0),mask=ZNIQ8wfDB0YaXhzbdJEOLoP5K67jgk)
	else: QPIoac4R7nADmdBFt1zV6 = ZNIQ8wfDB0YaXhzbdJEOLoP5K67jgk
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: YuJ06h7UQl = YuJ06h7UQl.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	try: QPIoac4R7nADmdBFt1zV6.save(YuJ06h7UQl)
	except UnicodeError:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			YuJ06h7UQl = YuJ06h7UQl.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			QPIoac4R7nADmdBFt1zV6.save(YuJ06h7UQl)
	return FapQSfNAvRtD43UXiM278lWbkxB
def kkJb10TwWSMroluPzDxa8CcvqpQ(CZOBzkIa5ySxcNbog,V2V8z4WKPGEuTq0yQReixSX9pr,NEam5tOUBPLGWZbdjuH0nqF,W3MdC2DFBQNlv9kufGp,LacAoFf82Hj34IXJQ,aa09wptHgfsNDxIE1YSXLWOcMZ3C):
	oRBdDCra70,wEsdO4foRS8Tn0gvyXucbAqaFJlZ7,B3im9bH0YXOfCFzudtK6lwIgL2qPh = QigevCplXxbPI1H,0,15000
	NEam5tOUBPLGWZbdjuH0nqF = NEam5tOUBPLGWZbdjuH0nqF.replace('[COLOR ','[COLOR:::')
	SjkNCPKe2EByz8Li07df3MacxDH1 = LacAoFf82Hj34IXJQ-W3MdC2DFBQNlv9kufGp*2
	for tAEn839VHDme7Gd in NEam5tOUBPLGWZbdjuH0nqF.splitlines():
		wEsdO4foRS8Tn0gvyXucbAqaFJlZ7 += aa09wptHgfsNDxIE1YSXLWOcMZ3C
		WYUHmPINyf2etwQMl,eAtRkxbi8dGl5zpJuNyqLU6ZQXIP = 0,QigevCplXxbPI1H
		for WWmsxuq6AtKeE2inaTp8jwZ5g7Db in tAEn839VHDme7Gd.split(hT7zFDpEyUqf8sXuN):
			nTbLfCzxR1qOdpiJ74tePoFcUgG6a = EMIPut17KZOvsz(hT7zFDpEyUqf8sXuN+WWmsxuq6AtKeE2inaTp8jwZ5g7Db)
			vLCg4nFfIBc0zK2u,HnZebAcDpSu8MWqGy79 = CZOBzkIa5ySxcNbog.textsize(nTbLfCzxR1qOdpiJ74tePoFcUgG6a,font=V2V8z4WKPGEuTq0yQReixSX9pr)
			if WYUHmPINyf2etwQMl+vLCg4nFfIBc0zK2u<SjkNCPKe2EByz8Li07df3MacxDH1:
				if not eAtRkxbi8dGl5zpJuNyqLU6ZQXIP: eAtRkxbi8dGl5zpJuNyqLU6ZQXIP += WWmsxuq6AtKeE2inaTp8jwZ5g7Db
				else: eAtRkxbi8dGl5zpJuNyqLU6ZQXIP += hT7zFDpEyUqf8sXuN+WWmsxuq6AtKeE2inaTp8jwZ5g7Db
				WYUHmPINyf2etwQMl += vLCg4nFfIBc0zK2u
			else:
				if vLCg4nFfIBc0zK2u<SjkNCPKe2EByz8Li07df3MacxDH1:
					eAtRkxbi8dGl5zpJuNyqLU6ZQXIP += '\n '+WWmsxuq6AtKeE2inaTp8jwZ5g7Db
					wEsdO4foRS8Tn0gvyXucbAqaFJlZ7 += aa09wptHgfsNDxIE1YSXLWOcMZ3C
					WYUHmPINyf2etwQMl = vLCg4nFfIBc0zK2u
				else:
					while vLCg4nFfIBc0zK2u>SjkNCPKe2EByz8Li07df3MacxDH1:
						for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(1,len(hT7zFDpEyUqf8sXuN+WWmsxuq6AtKeE2inaTp8jwZ5g7Db),1):
							P9a3Hjekhw85nzLOG1m = hT7zFDpEyUqf8sXuN+WWmsxuq6AtKeE2inaTp8jwZ5g7Db[:DDSXKTgdvtyImN2aJYV35QGZjpkxoU]
							ascpuXlWU2KPfbx = WWmsxuq6AtKeE2inaTp8jwZ5g7Db[DDSXKTgdvtyImN2aJYV35QGZjpkxoU:]
							ya5nAeht0ZFHNjuYUErdlW8O4qT = EMIPut17KZOvsz(P9a3Hjekhw85nzLOG1m)
							njZuiSLYxsqNGK,XM02UEbyLONSA = CZOBzkIa5ySxcNbog.textsize(ya5nAeht0ZFHNjuYUErdlW8O4qT,font=V2V8z4WKPGEuTq0yQReixSX9pr)
							if WYUHmPINyf2etwQMl+njZuiSLYxsqNGK>SjkNCPKe2EByz8Li07df3MacxDH1:
								ldNpHKjmCMgIVovYzZAfQLr = vLCg4nFfIBc0zK2u-njZuiSLYxsqNGK
								eAtRkxbi8dGl5zpJuNyqLU6ZQXIP += P9a3Hjekhw85nzLOG1m+aSBkt4OU8JpWTEzVIHjAiv
								wEsdO4foRS8Tn0gvyXucbAqaFJlZ7 += aa09wptHgfsNDxIE1YSXLWOcMZ3C
								vLCg4nFfIBc0zK2u = ldNpHKjmCMgIVovYzZAfQLr
								if ldNpHKjmCMgIVovYzZAfQLr>SjkNCPKe2EByz8Li07df3MacxDH1:
									WYUHmPINyf2etwQMl = 0
									WWmsxuq6AtKeE2inaTp8jwZ5g7Db = ascpuXlWU2KPfbx
								else:
									WYUHmPINyf2etwQMl = ldNpHKjmCMgIVovYzZAfQLr
									eAtRkxbi8dGl5zpJuNyqLU6ZQXIP += ascpuXlWU2KPfbx
								break
				if wEsdO4foRS8Tn0gvyXucbAqaFJlZ7>B3im9bH0YXOfCFzudtK6lwIgL2qPh: break
		oRBdDCra70 += aSBkt4OU8JpWTEzVIHjAiv+eAtRkxbi8dGl5zpJuNyqLU6ZQXIP
		if wEsdO4foRS8Tn0gvyXucbAqaFJlZ7>B3im9bH0YXOfCFzudtK6lwIgL2qPh: break
	oRBdDCra70 = oRBdDCra70[1:]
	oRBdDCra70 = oRBdDCra70.replace('[COLOR:::','[COLOR ')
	return oRBdDCra70
def EMIPut17KZOvsz(WWmsxuq6AtKeE2inaTp8jwZ5g7Db):
	if '[' in WWmsxuq6AtKeE2inaTp8jwZ5g7Db and ']' in WWmsxuq6AtKeE2inaTp8jwZ5g7Db:
		P5hGD8uwNEovnzWeMmH = [jhAlCQ47ZgG,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		G7GzDCWQjsed0oJBvbFKi19aXx3N = sBvufaD6c9YHdOqTjCQ3.findall('\[COLOR .*?\]',WWmsxuq6AtKeE2inaTp8jwZ5g7Db,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		AiHCk3Y0G4ZqNtUfo217ul = sBvufaD6c9YHdOqTjCQ3.findall('\[COLOR:::.*?\]',WWmsxuq6AtKeE2inaTp8jwZ5g7Db,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		aJdVzG4uA9oeOmH7k3 = P5hGD8uwNEovnzWeMmH+G7GzDCWQjsed0oJBvbFKi19aXx3N+AiHCk3Y0G4ZqNtUfo217ul
		for BCXUkIx4Am85z in aJdVzG4uA9oeOmH7k3: WWmsxuq6AtKeE2inaTp8jwZ5g7Db = WWmsxuq6AtKeE2inaTp8jwZ5g7Db.replace(BCXUkIx4Am85z,QigevCplXxbPI1H)
	return WWmsxuq6AtKeE2inaTp8jwZ5g7Db
def gCj3oYN4Zl1Dz0AELKIQJOi(d8kolNVuLsPAjQZ9ROpUHBgix):
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(aSBkt4OU8JpWTEzVIHjAiv,'_sss__newline_')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[RTL]','_sss__linertl_')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[LEFT]','_sss__lineleft_')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[RIGHT]','_sss__lineright_')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[CENTER]','_sss__linecenter_')
	d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace(jhAlCQ47ZgG,'_sss__endcolor_')
	XpeyAIMvZNB = sBvufaD6c9YHdOqTjCQ3.findall('\[COLOR (.*?)\]',d8kolNVuLsPAjQZ9ROpUHBgix,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for ppMySPAqjeEgKcJ2 in XpeyAIMvZNB: d8kolNVuLsPAjQZ9ROpUHBgix = d8kolNVuLsPAjQZ9ROpUHBgix.replace('[COLOR '+ppMySPAqjeEgKcJ2+']','_sss__newcolor'+ppMySPAqjeEgKcJ2+'_')
	return d8kolNVuLsPAjQZ9ROpUHBgix
def RU3DWNPsrdXFHT7jB0lmC(zsj5qOxnfaXmdEco3DK29HgYybUCM6=QigevCplXxbPI1H):
	if not zsj5qOxnfaXmdEco3DK29HgYybUCM6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel('ListItem.Label')
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace(jhAlCQ47ZgG,QigevCplXxbPI1H)
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace(f1p0IN8alhrDKHyvqWk9UZ,hT7zFDpEyUqf8sXuN).replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).strip(hT7zFDpEyUqf8sXuN)
	zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.replace(r9rhtA5Tek8sIoLfqwF7JcEV,QigevCplXxbPI1H).replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,QigevCplXxbPI1H)
	lr9AHtSx0gRGJ2DUVm = sBvufaD6c9YHdOqTjCQ3.findall('\d\d:\d\d ',zsj5qOxnfaXmdEco3DK29HgYybUCM6,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if lr9AHtSx0gRGJ2DUVm: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = zsj5qOxnfaXmdEco3DK29HgYybUCM6.split(lr9AHtSx0gRGJ2DUVm[0],1)[1]
	if not zsj5qOxnfaXmdEco3DK29HgYybUCM6: zsj5qOxnfaXmdEco3DK29HgYybUCM6 = 'Main Menu'
	return zsj5qOxnfaXmdEco3DK29HgYybUCM6
def W8eXj3fGrbByNQPCnhY(eehakOTYstEIfg5zd):
	R3m2FshJMa7 = QigevCplXxbPI1H.join(DDSXKTgdvtyImN2aJYV35QGZjpkxoU for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in eehakOTYstEIfg5zd if DDSXKTgdvtyImN2aJYV35QGZjpkxoU not in '\/":*?<>|'+bJ75YtchPxVNaSsn)
	return R3m2FshJMa7
def hznK9suBQoEtTmwND4qXFg2(iIBnwPa3gYp4d):
	y0HsepSTX49jdvnYAN53KFfIGJmra = sBvufaD6c9YHdOqTjCQ3.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",iIBnwPa3gYp4d,sBvufaD6c9YHdOqTjCQ3.S)
	if y0HsepSTX49jdvnYAN53KFfIGJmra:
		Umt2MkbCqOW60lX5u4DEe,w6wsVgIrTd9z3n20oY = y0HsepSTX49jdvnYAN53KFfIGJmra[0]
		Umt2MkbCqOW60lX5u4DEe = sBvufaD6c9YHdOqTjCQ3.findall("=[\r\n\s\t]+'(.*?)';", Umt2MkbCqOW60lX5u4DEe, sBvufaD6c9YHdOqTjCQ3.S)[0]
		if Umt2MkbCqOW60lX5u4DEe and w6wsVgIrTd9z3n20oY:
			PsbJMnlN74EK5v = Umt2MkbCqOW60lX5u4DEe.replace("'",QigevCplXxbPI1H).replace("+",QigevCplXxbPI1H).replace("\n",QigevCplXxbPI1H).replace("\r",QigevCplXxbPI1H)
			GlAMBwJ724mc = PsbJMnlN74EK5v.split('.')
			iIBnwPa3gYp4d = QigevCplXxbPI1H
			for H7nGtsum1wUJjNQciBZPe in GlAMBwJ724mc:
				tmhTL2BWMKoJ8xRAEdHU9 = akgfpLEN8Kn396XjFUut4QJVI.b64decode(H7nGtsum1wUJjNQciBZPe+'==').decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				GAUlqtpXiDbeCYo8s3dRE9 = sBvufaD6c9YHdOqTjCQ3.findall('\d+', tmhTL2BWMKoJ8xRAEdHU9, sBvufaD6c9YHdOqTjCQ3.S)
				if GAUlqtpXiDbeCYo8s3dRE9:
					njcFukP3XK18bq = int(GAUlqtpXiDbeCYo8s3dRE9[0])
					njcFukP3XK18bq += int(w6wsVgIrTd9z3n20oY)
					iIBnwPa3gYp4d = iIBnwPa3gYp4d + chr(njcFukP3XK18bq)
			if b7sJAmSxlBvaMdHFz: iIBnwPa3gYp4d = iIBnwPa3gYp4d.encode('iso-8859-1').decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	return iIBnwPa3gYp4d
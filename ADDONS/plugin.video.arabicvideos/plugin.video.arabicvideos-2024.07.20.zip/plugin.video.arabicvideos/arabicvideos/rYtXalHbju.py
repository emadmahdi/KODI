# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'DAILYMOTION'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_DLM_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
PTKgtGhwsW51oZ3uQImn6Czd0ERNyb = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][1]
def YnMSWTbKj1N8wuRJVF(mode,url,text,type,JJM6TofH4g5n7SRwq):
	if	 mode==400: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==401: W9lfsoMawqOzpQcXD = fZLFkAmYOMWVwqQRGc4Eiusv3I0X(url,text)
	elif mode==402: W9lfsoMawqOzpQcXD = T5bPOltpVin6vohX3z497WqL(url,text)
	elif mode==403: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url,text)
	elif mode==404: W9lfsoMawqOzpQcXD = cisnRd6C0aBvhWJ5SPwfr(text,JJM6TofH4g5n7SRwq)
	elif mode==405: W9lfsoMawqOzpQcXD = UywBf1uCx4nAQcvIDKF(text,JJM6TofH4g5n7SRwq)
	elif mode==406: W9lfsoMawqOzpQcXD = zPZKh8wiqW5mke62DnMjLdfHcb(text,JJM6TofH4g5n7SRwq)
	elif mode==407: W9lfsoMawqOzpQcXD = Y578ZbBGUOmnqNW4lVc0hE2XJDjA1(url,JJM6TofH4g5n7SRwq)
	elif mode==408: W9lfsoMawqOzpQcXD = EXsLPZ74eUc5A9kJ6BwOd0jWbqChN(url,JJM6TofH4g5n7SRwq)
	elif mode==409: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text,JJM6TofH4g5n7SRwq)
	elif mode==411: W9lfsoMawqOzpQcXD = ycowiQ2dveCIrp1S(url,text)
	elif mode==414: W9lfsoMawqOzpQcXD = r4NC7c80mAzD(text)
	elif mode==415: W9lfsoMawqOzpQcXD = kSzVvRd9DN6i8HEX(text,JJM6TofH4g5n7SRwq)
	elif mode==416: W9lfsoMawqOzpQcXD = rrPjzBD9bdlEaUmuWqFCfyHM5is(text,JJM6TofH4g5n7SRwq)
	elif mode==417: W9lfsoMawqOzpQcXD = XtiN9Bfbyzm(url,JJM6TofH4g5n7SRwq)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الرئيسية',QigevCplXxbPI1H,414)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,409,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن فيديوهات',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'videos?sortBy=','_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن آخر الفيديوهات',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن الفيديوهات الأكثر مشاهدة',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن قوائم التشغيل',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'playlists','_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن قنوات',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'channels','_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن بث حي',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'lives','_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث عن هاشتاك',QigevCplXxbPI1H,409,QigevCplXxbPI1H,'hashtags','_REMEMBERRESULTS_')
	return
def T5bPOltpVin6vohX3z497WqL(url,yD6qlPU85KXcOfQzAI3auHEhMvi):
	if '/dm_' in url:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,False,QigevCplXxbPI1H,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = JJrhP4C6osGDFEKVSRBvX.headers
		if 'Location' in list(headers.keys()): url = vxQUXEuH9m+headers['Location']
	yD6qlPU85KXcOfQzAI3auHEhMvi = iVCLpNIM8BQs9PdSgKZvlFeo3a5+yD6qlPU85KXcOfQzAI3auHEhMvi+jhAlCQ47ZgG
	yD6qlPU85KXcOfQzAI3auHEhMvi = h8LjG7kcunwVTvysiN2FE0aJPMl(yD6qlPU85KXcOfQzAI3auHEhMvi)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: بث حي',url,411,QigevCplXxbPI1H,QigevCplXxbPI1H,'channel_lives_now')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: آخر الفيديوهات',url+'/videos',408)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: المميزة',url,411,QigevCplXxbPI1H,QigevCplXxbPI1H,'channel_featured_videos')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: قوائم التشغيل',url+'/playlists',407)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+':: قنوات ذات صلة',url,411,QigevCplXxbPI1H,QigevCplXxbPI1H,'channel_related_channel')
	return
def h8LjG7kcunwVTvysiN2FE0aJPMl(title):
	title = title.rstrip('\\').strip(hT7zFDpEyUqf8sXuN).replace('\\\\','\\')
	title = arFSQucmG9HxDody67JCI8pBMk4L(title)
	return title
def nibvTq2jfRXDM4tYP039S(url,ehgc4bBVGPZOS):
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM([url],PuT0IphGNsketAQ,'video',url)
	return
def cisnRd6C0aBvhWJ5SPwfr(search,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = QigevCplXxbPI1H
	search = search.split('/videos')[0]
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysearchwords',search)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	if sort==QigevCplXxbPI1H: x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysortmethod',QigevCplXxbPI1H)
	else: x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = vxQUXEuH9m+'/search/'+search+'/videos'
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"videos"(.*?)"VideoConnection"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for id,title,sRJDi27kNoAbxYTCc,yD6qlPU85KXcOfQzAI3auHEhMvi,ThO0AMm4jUGP9yr,cXu4fN1moCypJqb72OZvd in items:
			if '"' in id: id = id.replace('"',QigevCplXxbPI1H)
			if '"' in title: title = title.replace('"',QigevCplXxbPI1H)
			if '"' in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('"',QigevCplXxbPI1H)
			if '"' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.replace('"',QigevCplXxbPI1H)
			if '"' in sRJDi27kNoAbxYTCc: sRJDi27kNoAbxYTCc = sRJDi27kNoAbxYTCc.replace('"',QigevCplXxbPI1H)
			if '"' in yD6qlPU85KXcOfQzAI3auHEhMvi: yD6qlPU85KXcOfQzAI3auHEhMvi = yD6qlPU85KXcOfQzAI3auHEhMvi.replace('"',QigevCplXxbPI1H)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+id
			title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
			ehgc4bBVGPZOS = sRJDi27kNoAbxYTCc+'::'+yD6qlPU85KXcOfQzAI3auHEhMvi
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr,ehgc4bBVGPZOS)
		if '"hasNextPage":true' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,404,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,search)
	return
def UywBf1uCx4nAQcvIDKF(search,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysearchwords',search)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	url = vxQUXEuH9m+'/search/'+search+'/playlists'
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search)
	items = sBvufaD6c9YHdOqTjCQ3.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for id,name,HbB96sEAt75NjCXGzq,sRJDi27kNoAbxYTCc,yD6qlPU85KXcOfQzAI3auHEhMvi,cXu4fN1moCypJqb72OZvd,count in items:
		if '"' in HbB96sEAt75NjCXGzq: HbB96sEAt75NjCXGzq = HbB96sEAt75NjCXGzq.replace('"',QigevCplXxbPI1H)
		if '"' in sRJDi27kNoAbxYTCc: sRJDi27kNoAbxYTCc = sRJDi27kNoAbxYTCc.replace('"',QigevCplXxbPI1H)
		if '"' in yD6qlPU85KXcOfQzAI3auHEhMvi: yD6qlPU85KXcOfQzAI3auHEhMvi = yD6qlPU85KXcOfQzAI3auHEhMvi.replace('"',QigevCplXxbPI1H)
		if '"' in id: id = id.replace('"',QigevCplXxbPI1H)
		if '"' in name: name = name.replace('"',QigevCplXxbPI1H)
		if '"' in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('"',QigevCplXxbPI1H)
		if '"' in count: count = count.replace('"',QigevCplXxbPI1H)
		RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
		ehgc4bBVGPZOS = sRJDi27kNoAbxYTCc+'::'+yD6qlPU85KXcOfQzAI3auHEhMvi
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,401,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,ehgc4bBVGPZOS)
	if '"hasNextPage":true' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,405,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,search)
	return
def zPZKh8wiqW5mke62DnMjLdfHcb(search,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysearchwords',search)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	url = vxQUXEuH9m+'/search/'+search+'/channels'
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"channels"(.*?)"ChannelConnection"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for id,name,cXu4fN1moCypJqb72OZvd in items:
			if '"' in id: id = id.replace('"',QigevCplXxbPI1H)
			if '"' in name: name = name.replace('"',QigevCplXxbPI1H)
			if '"' in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('"',QigevCplXxbPI1H)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+id
			title = 'CHNL:  '+name
			title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,402,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,name)
		if '"hasNextPage":true' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,406,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,search)
	return
def r4NC7c80mAzD(PA4OEBc2j176rodz5Iv):
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	XJ2TlxN04ArswFneYPSLtMB53vGc = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	if XJ2TlxN04ArswFneYPSLtMB53vGc:
		j1jfdScTy3Ozki2sR = CH86N7xw4cyPt3TlIBJF('dict',XJ2TlxN04ArswFneYPSLtMB53vGc)
		Fmio1IMauDS7jRENl0pxYn4KgzsV9q = j1jfdScTy3Ozki2sR['data']['home']['neon']['sections']['edges']
		if not PA4OEBc2j176rodz5Iv:
			P0sZtqhOEdaRDLQAUx = []
			for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
				MGoAvuTzp67QP8K91xYOf = Vtcubo3KWTCHJFdlSeGv['node']['title']
				if MGoAvuTzp67QP8K91xYOf not in P0sZtqhOEdaRDLQAUx: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+MGoAvuTzp67QP8K91xYOf,QigevCplXxbPI1H,414,QigevCplXxbPI1H,QigevCplXxbPI1H,MGoAvuTzp67QP8K91xYOf)
				P0sZtqhOEdaRDLQAUx.append(MGoAvuTzp67QP8K91xYOf)
		else:
			for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
				MGoAvuTzp67QP8K91xYOf = Vtcubo3KWTCHJFdlSeGv['node']['title']
				if MGoAvuTzp67QP8K91xYOf==PA4OEBc2j176rodz5Iv:
					wwZSjRvUxm4bcA = Vtcubo3KWTCHJFdlSeGv['node']['components']['edges']
					for FFjKE1Iirv in wwZSjRvUxm4bcA:
						ThO0AMm4jUGP9yr = str(FFjKE1Iirv['node']['duration'])
						title = arFSQucmG9HxDody67JCI8pBMk4L(FFjKE1Iirv['node']['title'])
						title = title.replace('\/','/')
						iiptJBQ38OU0xYXW9wLP = FFjKE1Iirv['node']['xid']
						cXu4fN1moCypJqb72OZvd = FFjKE1Iirv['node']['thumbnailx480']
						cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('\/','/')
						RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+iiptJBQ38OU0xYXW9wLP
						E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr)
	return
def kSzVvRd9DN6i8HEX(search,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysearchwords',search)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	url = vxQUXEuH9m+'/search/'+search+'/lives'
	XJ2TlxN04ArswFneYPSLtMB53vGc = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search)
	if XJ2TlxN04ArswFneYPSLtMB53vGc:
		j1jfdScTy3Ozki2sR = CH86N7xw4cyPt3TlIBJF('dict',XJ2TlxN04ArswFneYPSLtMB53vGc)
		try: Fmio1IMauDS7jRENl0pxYn4KgzsV9q = j1jfdScTy3Ozki2sR['data']['search']['lives']['edges']
		except: Fmio1IMauDS7jRENl0pxYn4KgzsV9q = []
		for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
			name = Vtcubo3KWTCHJFdlSeGv['node']['title']
			name = arFSQucmG9HxDody67JCI8pBMk4L(name)
			iiptJBQ38OU0xYXW9wLP = Vtcubo3KWTCHJFdlSeGv['node']['xid']
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+iiptJBQ38OU0xYXW9wLP
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'LIVE: '+name,RMC6c2kL5hGOnFaIwAyb,403)
		if '"hasNextPage":true' in XJ2TlxN04ArswFneYPSLtMB53vGc:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,415,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,search)
	return
def hAxy69U3M0gREDGFdbetTf(search,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysearchwords',search)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	url = vxQUXEuH9m+'/search/'+search+'/topics'
	XJ2TlxN04ArswFneYPSLtMB53vGc = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search)
	if XJ2TlxN04ArswFneYPSLtMB53vGc:
		j1jfdScTy3Ozki2sR = CH86N7xw4cyPt3TlIBJF('dict',XJ2TlxN04ArswFneYPSLtMB53vGc)
		try: Fmio1IMauDS7jRENl0pxYn4KgzsV9q = j1jfdScTy3Ozki2sR['data']['search']['topics']['edges']
		except: Fmio1IMauDS7jRENl0pxYn4KgzsV9q = []
		for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
			name = Vtcubo3KWTCHJFdlSeGv['node']['name']
			iiptJBQ38OU0xYXW9wLP = Vtcubo3KWTCHJFdlSeGv['node']['xid']
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/topic/'+iiptJBQ38OU0xYXW9wLP
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'TOPIC: '+name,RMC6c2kL5hGOnFaIwAyb,413)
		if '"hasNextPage":true' in XJ2TlxN04ArswFneYPSLtMB53vGc:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,412,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,search)
	return
def rXHsId4olgakc7z5AwDtfyZ(url,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	iiptJBQ38OU0xYXW9wLP = url.split('/')[-1]
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mytopicid',iiptJBQ38OU0xYXW9wLP)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	XJ2TlxN04ArswFneYPSLtMB53vGc = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	if XJ2TlxN04ArswFneYPSLtMB53vGc:
		j1jfdScTy3Ozki2sR = CH86N7xw4cyPt3TlIBJF('dict',XJ2TlxN04ArswFneYPSLtMB53vGc)
		Fmio1IMauDS7jRENl0pxYn4KgzsV9q = j1jfdScTy3Ozki2sR['data']['topic']['videos']['edges']
		for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
			ThO0AMm4jUGP9yr = str(Vtcubo3KWTCHJFdlSeGv['node']['duration'])
			title = arFSQucmG9HxDody67JCI8pBMk4L(Vtcubo3KWTCHJFdlSeGv['node']['title'])
			title = title.replace('\/','/')
			iiptJBQ38OU0xYXW9wLP = Vtcubo3KWTCHJFdlSeGv['node']['xid']
			cXu4fN1moCypJqb72OZvd = Vtcubo3KWTCHJFdlSeGv['node']['thumbnailx480']
			cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('\/','/')
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+iiptJBQ38OU0xYXW9wLP
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr)
		if '"hasNextPage":true' in XJ2TlxN04ArswFneYPSLtMB53vGc:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,413,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq)
	return
def fZLFkAmYOMWVwqQRGc4Eiusv3I0X(url,ehgc4bBVGPZOS):
	id = url.split('/')[-1]
	sRJDi27kNoAbxYTCc,yD6qlPU85KXcOfQzAI3auHEhMvi = ehgc4bBVGPZOS.split('::',1)
	RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+sRJDi27kNoAbxYTCc
	yD6qlPU85KXcOfQzAI3auHEhMvi = h8LjG7kcunwVTvysiN2FE0aJPMl(yD6qlPU85KXcOfQzAI3auHEhMvi)
	title = '[COLOR FFC89008]OWNER:  '+yD6qlPU85KXcOfQzAI3auHEhMvi+jhAlCQ47ZgG
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,402,QigevCplXxbPI1H,QigevCplXxbPI1H,yD6qlPU85KXcOfQzAI3auHEhMvi)
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('myplaylistid',id)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"collection_videos"(.*?)"SectionEdge"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for id,title,ThO0AMm4jUGP9yr,cXu4fN1moCypJqb72OZvd,sRJDi27kNoAbxYTCc,yD6qlPU85KXcOfQzAI3auHEhMvi in items:
			if '"' in id: id = id.replace('"',QigevCplXxbPI1H)
			if '"' in title: title = title.replace('"',QigevCplXxbPI1H)
			if '"' in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('"',QigevCplXxbPI1H)
			if '"' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.replace('"',QigevCplXxbPI1H)
			if '"' in sRJDi27kNoAbxYTCc: sRJDi27kNoAbxYTCc = sRJDi27kNoAbxYTCc.replace('"',QigevCplXxbPI1H)
			if '"' in yD6qlPU85KXcOfQzAI3auHEhMvi: yD6qlPU85KXcOfQzAI3auHEhMvi = yD6qlPU85KXcOfQzAI3auHEhMvi.replace('"',QigevCplXxbPI1H)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+id
			title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
			ehgc4bBVGPZOS = sRJDi27kNoAbxYTCc+'::'+yD6qlPU85KXcOfQzAI3auHEhMvi
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr,ehgc4bBVGPZOS)
	return
def EXsLPZ74eUc5A9kJ6BwOd0jWbqChN(url,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	TfilazROjy = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mychannelid',TfilazROjy)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysortmethod',sort)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for id,title,ThO0AMm4jUGP9yr,sRJDi27kNoAbxYTCc,yD6qlPU85KXcOfQzAI3auHEhMvi,cXu4fN1moCypJqb72OZvd in items:
			if '"' in id: id = id.replace('"',QigevCplXxbPI1H)
			if '"' in title: title = title.replace('"',QigevCplXxbPI1H)
			if '"' in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('"',QigevCplXxbPI1H)
			if '"' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.replace('"',QigevCplXxbPI1H)
			if '"' in sRJDi27kNoAbxYTCc: sRJDi27kNoAbxYTCc = sRJDi27kNoAbxYTCc.replace('"',QigevCplXxbPI1H)
			if '"' in yD6qlPU85KXcOfQzAI3auHEhMvi: yD6qlPU85KXcOfQzAI3auHEhMvi = yD6qlPU85KXcOfQzAI3auHEhMvi.replace('"',QigevCplXxbPI1H)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+id
			title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
			ehgc4bBVGPZOS = sRJDi27kNoAbxYTCc+'::'+yD6qlPU85KXcOfQzAI3auHEhMvi
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr,ehgc4bBVGPZOS)
		if '"hasNextPage":true' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,408,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq)
	return
def Y578ZbBGUOmnqNW4lVc0hE2XJDjA1(url,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	TfilazROjy = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mychannelid',TfilazROjy)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysortmethod',sort)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for id,name,cXu4fN1moCypJqb72OZvd,count,HbB96sEAt75NjCXGzq,sRJDi27kNoAbxYTCc,yD6qlPU85KXcOfQzAI3auHEhMvi in items:
			if '"' in id: id = id.replace('"',QigevCplXxbPI1H)
			if '"' in name: name = name.replace('"',QigevCplXxbPI1H)
			if '"' in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('"',QigevCplXxbPI1H)
			if '"' in count: count = count.replace('"',QigevCplXxbPI1H)
			if '"' in HbB96sEAt75NjCXGzq: HbB96sEAt75NjCXGzq = HbB96sEAt75NjCXGzq.replace('"',QigevCplXxbPI1H)
			if '"' in sRJDi27kNoAbxYTCc: sRJDi27kNoAbxYTCc = sRJDi27kNoAbxYTCc.replace('"',QigevCplXxbPI1H)
			if '"' in yD6qlPU85KXcOfQzAI3auHEhMvi: yD6qlPU85KXcOfQzAI3auHEhMvi = yD6qlPU85KXcOfQzAI3auHEhMvi.replace('"',QigevCplXxbPI1H)
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
			ehgc4bBVGPZOS = sRJDi27kNoAbxYTCc+'::'+yD6qlPU85KXcOfQzAI3auHEhMvi
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,401,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,ehgc4bBVGPZOS)
		if '"hasNextPage":true' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,407,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq)
	return
def ycowiQ2dveCIrp1S(url,pKv4Q7Lj0et6W2VlR):
	TfilazROjy = url.split('/')[3]
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mychannelid',TfilazROjy)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	import json as hlKGtjPuCaeIWUwvgMxp9
	P1hdGF6WN7ToD2zBviCx5Q = hlKGtjPuCaeIWUwvgMxp9.loads(aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	try: items = P1hdGF6WN7ToD2zBviCx5Q['data']['channel'][pKv4Q7Lj0et6W2VlR]['edges']
	except: items = []
	if not items: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'لا توجد نتائج',QigevCplXxbPI1H,9999)
	else:
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			CGuO7KFhITx89zMS = upHdVltvOIDPnN0SefZwGo4gJ9LqsY['node']
			iiptJBQ38OU0xYXW9wLP = CGuO7KFhITx89zMS['xid']
			keys = list(CGuO7KFhITx89zMS.keys())
			K2aDMeiUOVx1usbrPhdFvYCRck = CGuO7KFhITx89zMS['__typename'].lower()
			if K2aDMeiUOVx1usbrPhdFvYCRck=='channel':
				name = CGuO7KFhITx89zMS['name']
				oTQhDwLjpE = CGuO7KFhITx89zMS['displayName']
				title = 'CHNL:  '+oTQhDwLjpE
				cXu4fN1moCypJqb72OZvd = CGuO7KFhITx89zMS['coverURLx375']
			else:
				name = CGuO7KFhITx89zMS['channel']['name']
				oTQhDwLjpE = CGuO7KFhITx89zMS['channel']['displayName']
				title = CGuO7KFhITx89zMS['title']
				cXu4fN1moCypJqb72OZvd = CGuO7KFhITx89zMS['thumbnailx360']
				if K2aDMeiUOVx1usbrPhdFvYCRck=='live': title = 'LIVE:  '+title
			title = h8LjG7kcunwVTvysiN2FE0aJPMl(title)
			ehgc4bBVGPZOS = name+'::'+oTQhDwLjpE
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
				title = title.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
				ehgc4bBVGPZOS = ehgc4bBVGPZOS.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			if K2aDMeiUOVx1usbrPhdFvYCRck=='channel':
				RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/'+iiptJBQ38OU0xYXW9wLP
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,402,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,ehgc4bBVGPZOS)
			else:
				if K2aDMeiUOVx1usbrPhdFvYCRck=='video': ThO0AMm4jUGP9yr = str(CGuO7KFhITx89zMS['duration'])
				else: ThO0AMm4jUGP9yr = QigevCplXxbPI1H
				RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+iiptJBQ38OU0xYXW9wLP
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj(K2aDMeiUOVx1usbrPhdFvYCRck,iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr,ehgc4bBVGPZOS)
	return
def rrPjzBD9bdlEaUmuWqFCfyHM5is(search,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mysearchwords',search)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagelimit','40')
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	url = vxQUXEuH9m+'/search/'+search+'/hashtags'
	XJ2TlxN04ArswFneYPSLtMB53vGc = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search)
	if XJ2TlxN04ArswFneYPSLtMB53vGc:
		j1jfdScTy3Ozki2sR = CH86N7xw4cyPt3TlIBJF('dict',XJ2TlxN04ArswFneYPSLtMB53vGc)
		try: Fmio1IMauDS7jRENl0pxYn4KgzsV9q = j1jfdScTy3Ozki2sR['data']['search']['hashtags']['edges']
		except: Fmio1IMauDS7jRENl0pxYn4KgzsV9q = []
		for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
			name = Vtcubo3KWTCHJFdlSeGv['node']['name']
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/hashtag/'+name[1:]
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'HASHTAG: '+name,RMC6c2kL5hGOnFaIwAyb,417)
		if '"hasNextPage":true' in XJ2TlxN04ArswFneYPSLtMB53vGc:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,416,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,search)
	return
def XtiN9Bfbyzm(url,JJM6TofH4g5n7SRwq=QigevCplXxbPI1H):
	if JJM6TofH4g5n7SRwq==QigevCplXxbPI1H: JJM6TofH4g5n7SRwq = '1'
	name = url.split('/')[-1]
	x9Ahuz3FVWmJDaNp5 = '{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('myhashtagname',name)
	x9Ahuz3FVWmJDaNp5 = x9Ahuz3FVWmJDaNp5.replace('mypagenumber',JJM6TofH4g5n7SRwq)
	XJ2TlxN04ArswFneYPSLtMB53vGc = EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5)
	if XJ2TlxN04ArswFneYPSLtMB53vGc:
		j1jfdScTy3Ozki2sR = CH86N7xw4cyPt3TlIBJF('dict',XJ2TlxN04ArswFneYPSLtMB53vGc)
		Fmio1IMauDS7jRENl0pxYn4KgzsV9q = j1jfdScTy3Ozki2sR['data']['contentFeed']['edges']
		for Vtcubo3KWTCHJFdlSeGv in Fmio1IMauDS7jRENl0pxYn4KgzsV9q:
			ThO0AMm4jUGP9yr = str(Vtcubo3KWTCHJFdlSeGv['node']['post']['duration'])
			title = arFSQucmG9HxDody67JCI8pBMk4L(Vtcubo3KWTCHJFdlSeGv['node']['post']['title'])
			title = title.replace('\/','/')
			iiptJBQ38OU0xYXW9wLP = Vtcubo3KWTCHJFdlSeGv['node']['post']['xid']
			cXu4fN1moCypJqb72OZvd = Vtcubo3KWTCHJFdlSeGv['node']['post']['thumbnailx480']
			cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.replace('\/','/')
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/video/'+iiptJBQ38OU0xYXW9wLP
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,403,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr)
		if '"hasNextPage":true' in XJ2TlxN04ArswFneYPSLtMB53vGc:
			JJM6TofH4g5n7SRwq = str(int(JJM6TofH4g5n7SRwq)+1)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+JJM6TofH4g5n7SRwq,url,416,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq)
	return
def EEpFjfbuUsh0x78JvCAdMZL(x9Ahuz3FVWmJDaNp5,search=QigevCplXxbPI1H):
	if b7sJAmSxlBvaMdHFz and search:
		aIT5ZBqwyK4h2J67RrY = sBvufaD6c9YHdOqTjCQ3.findall('[a-zA-Z]',search,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not aIT5ZBqwyK4h2J67RrY: x9Ahuz3FVWmJDaNp5 += ' }'
	bfVxsd0X1y = ZZjDLhiEoHrxy8gqSXRG()
	headers = {"Authorization":bfVxsd0X1y,"Origin":vxQUXEuH9m,'Content-Type':'application/json'}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',PTKgtGhwsW51oZ3uQImn6Czd0ERNyb,x9Ahuz3FVWmJDaNp5,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'DAILYMOTION-GET_PAGEDATA-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ZZjDLhiEoHrxy8gqSXRG():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'DAILYMOTION-GET_AUTHINTICATION-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	CAFyiTsI7k = sBvufaD6c9YHdOqTjCQ3.findall('var r="(.*?)",o="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ZZ4l8RpcMQ0yfHPibxONFwD,f7cRJ3iUWSv2xz = CAFyiTsI7k[-1]
	MVemW3iugBkzI = 'https://graphql.api.dailymotion.com/oauth/token'
	l5QFcw3qjBktXaCPfZW4s2Hm = 'client_credentials'
	data = {'client_id':ZZ4l8RpcMQ0yfHPibxONFwD,'client_secret':f7cRJ3iUWSv2xz,'grant_type':l5QFcw3qjBktXaCPfZW4s2Hm}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',MVemW3iugBkzI,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	CAFyiTsI7k = sBvufaD6c9YHdOqTjCQ3.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Z3rjYNacwq1R,rrUbPpsiqImd = CAFyiTsI7k[0]
	bfVxsd0X1y = rrUbPpsiqImd+" "+Z3rjYNacwq1R
	return bfVxsd0X1y
def UJL7oB1rySs6ERpjGnhvz(search,type=QigevCplXxbPI1H):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not type and showDialogs:
		CsbVv9B2mRW4A1LQrJMefwKoUG = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن قنوات','بحث عن بث حي','بحث عن هاشتاك']
		HHZ6579kAv8 = zYWJO03iISD('موقع ديلي موشن - اختر البحث',CsbVv9B2mRW4A1LQrJMefwKoUG)
		if HHZ6579kAv8==-1: return
		elif HHZ6579kAv8==0: type = 'videos?sortBy='
		elif HHZ6579kAv8==1: type = 'videos?sortBy=RECENT'
		elif HHZ6579kAv8==2: type = 'videos?sortBy=VIEW_COUNT'
		elif HHZ6579kAv8==3: type = 'playlists'
		elif HHZ6579kAv8==4: type = 'channels'
		elif HHZ6579kAv8==5: type = 'lives'
		elif HHZ6579kAv8==6: type = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in iBux5zA0swygKtRlDCTH: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in iBux5zA0swygKtRlDCTH: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in iBux5zA0swygKtRlDCTH: type = 'channels'
	elif '_DAILYMOTION-LIVES_' in iBux5zA0swygKtRlDCTH: type = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in iBux5zA0swygKtRlDCTH: type = 'hashtags'
	if not search:
		search = XAfEvmh95VkgurjdiJ()
		if not search: return
	if 'videos' in type: cisnRd6C0aBvhWJ5SPwfr(search+'/'+type)
	elif 'playlists' in type: UywBf1uCx4nAQcvIDKF(search)
	elif 'channels' in type: zPZKh8wiqW5mke62DnMjLdfHcb(search)
	elif 'lives' in type: kSzVvRd9DN6i8HEX(search)
	elif 'hashtags' in type: rrPjzBD9bdlEaUmuWqFCfyHM5is(search)
	return
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
headers = { 'User-Agent' : QigevCplXxbPI1H }
PuT0IphGNsketAQ = 'AKOAM'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_AKO_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
XX6fcgOkPT3qKuApd9I7QFMzyvsSt = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==70: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==71: W9lfsoMawqOzpQcXD = qqIRsngutpzP52Moa(url)
	elif mode==72: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==73: W9lfsoMawqOzpQcXD = OO5JqYWGeDgP2T8AMVj7dImN0SzELc(url)
	elif mode==74: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==79: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,79,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'سلسلة افلام',QigevCplXxbPI1H,79,QigevCplXxbPI1H,QigevCplXxbPI1H,'سلسلة افلام')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'سلاسل منوعة',QigevCplXxbPI1H,79,QigevCplXxbPI1H,QigevCplXxbPI1H,'سلسلة')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	ef1pQcbEtPjMnXYrvOi = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKOAM-MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="partions"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title not in ef1pQcbEtPjMnXYrvOi:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,71)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def qqIRsngutpzP52Moa(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'AKOAM-CATEGORIES-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('sect_parts(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,72)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'جميع الفروع',url,72)
	else: ddbEXhWzOnIaR(url,QigevCplXxbPI1H)
	return
def ddbEXhWzOnIaR(url,type):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('section_title featured_title(.*?)subjects-crousel',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='search':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('akoam_result(.*?)<script',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='more':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('section_title more_title(.*?)footer_bottom_services',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('navigation(.*?)<script',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items and fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if any(nFdGHjceZzW in title for nFdGHjceZzW in XX6fcgOkPT3qKuApd9I7QFMzyvsSt): E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,73,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,73,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall("</li><li >.*?href='(.*?)'>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,72,QigevCplXxbPI1H,QigevCplXxbPI1H,type)
	return
def kIlDC719fTvKVzGaAd2(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,True,'AKOAM-SECTIONS-2nd')
	Kj0TOU6BmSMlJHZYLd = sBvufaD6c9YHdOqTjCQ3.findall('"href","(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd[1]
	return Kj0TOU6BmSMlJHZYLd
def OO5JqYWGeDgP2T8AMVj7dImN0SzELc(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,True,'AKOAM-SECTIONS-1st')
	uuj53AvlRkx = sBvufaD6c9YHdOqTjCQ3.findall('"(https*://akwam.net/\w+.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	vHqjkAuwaEY7LrgXlCzs8fbRV = sBvufaD6c9YHdOqTjCQ3.findall('"(https*://underurl.com/\w+.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if uuj53AvlRkx or vHqjkAuwaEY7LrgXlCzs8fbRV:
		if uuj53AvlRkx: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = uuj53AvlRkx[0]
		elif vHqjkAuwaEY7LrgXlCzs8fbRV: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = kIlDC719fTvKVzGaAd2(vHqjkAuwaEY7LrgXlCzs8fbRV[0])
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = MVkP7zfWlxUXj(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
		import kkERyGgDWI
		if '/series/' in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx or '/shows/' in NW6gmPcC1B4ILwdHTz0GlDsi5Fkx: kkERyGgDWI.oB2rmVgqUND(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
		else: kkERyGgDWI.nibvTq2jfRXDM4tYP039S(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
		return
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	items = sBvufaD6c9YHdOqTjCQ3.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,73)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv:
		X69Fkr1VNnf2pJQC8wl7YR4HmaKc('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,cXu4fN1moCypJqb72OZvd,LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	name = name.strip(hT7zFDpEyUqf8sXuN)
	if 'sub_epsiode_title' in LKzFWsmvjUVGMDBapflx6H4NY:
		items = sBvufaD6c9YHdOqTjCQ3.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else:
		bBgUjVsuK3nr6xcFQ8TpSOvdIM = sBvufaD6c9YHdOqTjCQ3.findall('sub_file_title\'>(.*?) - <i>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		items = []
		for filename in bBgUjVsuK3nr6xcFQ8TpSOvdIM:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',QigevCplXxbPI1H) ]
	count = 0
	ttGBwQOv3K41hIkc6,Ph0poEUyRA = [],[]
	size = len(items)
	for title,filename in items:
		ain78FlYBCWD31qLKEgT2bvIy = QigevCplXxbPI1H
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: ain78FlYBCWD31qLKEgT2bvIy = filename.split('.')[-1]
		title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		ttGBwQOv3K41hIkc6.append(title)
		Ph0poEUyRA.append(count)
		count += 1
	if size>0:
		if any(nFdGHjceZzW in name for nFdGHjceZzW in XX6fcgOkPT3qKuApd9I7QFMzyvsSt):
			if size==1:
				HHZ6579kAv8 = 0
			else:
				HHZ6579kAv8 = zYWJO03iISD('اختر الفيديو المناسب:', ttGBwQOv3K41hIkc6)
				if HHZ6579kAv8 == -1: return
			nibvTq2jfRXDM4tYP039S(url+'?section='+str(1+Ph0poEUyRA[size-HHZ6579kAv8-1]))
		else:
			for A5SjhJUg37pNiMC4Eot6lOF in reversed(range(size)):
				title = name + ' - ' + ttGBwQOv3K41hIkc6[A5SjhJUg37pNiMC4Eot6lOF]
				title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
				RMC6c2kL5hGOnFaIwAyb = url + '?section='+str(size-A5SjhJUg37pNiMC4Eot6lOF)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,74,cXu4fN1moCypJqb72OZvd)
	else:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الرابط ليس فيديو',QigevCplXxbPI1H,9999,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	Kj0TOU6BmSMlJHZYLd,V1nZX7O5WwEq8HmvkY = url.split('?section=')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,True,QigevCplXxbPI1H,'AKOAM-PLAY_AKOAM-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	DtlCRnPLhMzNc8TQG3xSBg7 = fwSu6JsQZpEiv[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	DtlCRnPLhMzNc8TQG3xSBg7 = DtlCRnPLhMzNc8TQG3xSBg7 + 'direct_link_box'
	mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall('epsoide_box(.*?)direct_link_box',DtlCRnPLhMzNc8TQG3xSBg7,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	V1nZX7O5WwEq8HmvkY = len(mfFwcWZHXVGvyU3B0ILburCoh)-int(V1nZX7O5WwEq8HmvkY)
	LKzFWsmvjUVGMDBapflx6H4NY = mfFwcWZHXVGvyU3B0ILburCoh[V1nZX7O5WwEq8HmvkY]
	vdLczqkV5b48ZKyGxTE3jJi17aWS6 = []
	Xl2PwqBdexykESG0TCZNubjItDMa = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = sBvufaD6c9YHdOqTjCQ3.findall("class='download_btn.*?href='(.*?)'",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb in items:
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named=________akoam')
	items = sBvufaD6c9YHdOqTjCQ3.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for nFEdDqiXLvK,RMC6c2kL5hGOnFaIwAyb in items:
		nFEdDqiXLvK = nFEdDqiXLvK.split('/')[-1]
		nFEdDqiXLvK = nFEdDqiXLvK.split('.')[0]
		if nFEdDqiXLvK in Xl2PwqBdexykESG0TCZNubjItDMa:
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+Xl2PwqBdexykESG0TCZNubjItDMa[nFEdDqiXLvK]+'________akoam')
		else: vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+nFEdDqiXLvK+'________akoam')
	if not vdLczqkV5b48ZKyGxTE3jJi17aWS6:
		message = sBvufaD6c9YHdOqTjCQ3.findall('sub-no-file.*?\n(.*?)\n',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if message: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من الموقع الاصلي',message[0])
	else:
		import u8j7hmKf9V
		u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	url = vxQUXEuH9m + '/search/'+VIo6FYRkx0MLP4wufEGsgnz9
	W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,'search')
	return
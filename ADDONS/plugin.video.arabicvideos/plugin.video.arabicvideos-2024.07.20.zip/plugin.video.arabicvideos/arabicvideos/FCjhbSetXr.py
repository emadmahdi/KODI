# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'WECIMA'
headers = {'User-Agent':QigevCplXxbPI1H}
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_WCM_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['مصارعة حرة','wwe']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==560: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==561: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==562: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==563: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url,text)
	elif mode==564: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'CATEGORIES___'+text)
	elif mode==565: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'FILTERS___'+text)
	elif mode==566: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==569: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text,url)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',vxQUXEuH9m,569,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',vxQUXEuH9m+'/AjaxCenter/RightBar',564)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',vxQUXEuH9m+'/AjaxCenter/RightBar',565)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'WECIMA-MENU-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('class="menu-item.*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if title==QigevCplXxbPI1H: continue
			if any(nFdGHjceZzW in title.lower() for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,566)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('hoverable activable(.*?)hoverable activable',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,566,cXu4fN1moCypJqb72OZvd)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def eR6YT8AbXwl(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'WECIMA-SUBMENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if 'class="Slider--Grid"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',url,561,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="list--Tabsui"(.*?)div',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?i>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,561)
	return
def ddbEXhWzOnIaR(X6sJNAHy4Ufmi,type=QigevCplXxbPI1H):
	if '::' in X6sJNAHy4Ufmi:
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,url = X6sJNAHy4Ufmi.split('::')
		bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,'url')
		url = bSrdN78jxURTvh9+url
	else: url,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = X6sJNAHy4Ufmi,X6sJNAHy4Ufmi
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'WECIMA-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if type=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type in ['filters','search']:
		fwSu6JsQZpEiv = [aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('\\/','/').replace('\\"','"')]
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"Grid--WecimaPosts"(.*?)"RightUI"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"Thumb--GridItem".*?href="(.*?)" title="(.*?)".*?url\((.*?)\)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
			if any(nFdGHjceZzW in title.lower() for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			cXu4fN1moCypJqb72OZvd = arFSQucmG9HxDody67JCI8pBMk4L(cXu4fN1moCypJqb72OZvd)
			RMC6c2kL5hGOnFaIwAyb = arFSQucmG9HxDody67JCI8pBMk4L(RMC6c2kL5hGOnFaIwAyb)
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			title = arFSQucmG9HxDody67JCI8pBMk4L(title)
			title = title.replace('مشاهدة ',QigevCplXxbPI1H)
			if '/series/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,563,cXu4fN1moCypJqb72OZvd)
			elif 'حلقة' in title:
				V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) +حلقة +\d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if V1nZX7O5WwEq8HmvkY: title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
				if title not in wibHRCAFtsupIjx4ZTELeM:
					wibHRCAFtsupIjx4ZTELeM.append(title)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,563,cXu4fN1moCypJqb72OZvd)
			else:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,562,cXu4fN1moCypJqb72OZvd)
		if type=='filters':
			G1kbAhTnqMwIjiVv3Cc = sBvufaD6c9YHdOqTjCQ3.findall('"more_button_page":(.*?),',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if G1kbAhTnqMwIjiVv3Cc:
				count = G1kbAhTnqMwIjiVv3Cc[0]
				RMC6c2kL5hGOnFaIwAyb = url+'/offset/'+count
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة أخرى',RMC6c2kL5hGOnFaIwAyb,561,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
		elif type==QigevCplXxbPI1H:
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if fwSu6JsQZpEiv:
				LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
				items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for RMC6c2kL5hGOnFaIwAyb,title in items:
					if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
					title = 'صفحة '+i7gQvkPzZJm4jM3uYV2xfAqhs(title)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,561)
	return
def oB2rmVgqUND(url,type=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'WECIMA-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = MVkP7zfWlxUXj(aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="Seasons--Episodes"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not type and fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if len(items)>1:
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,563,QigevCplXxbPI1H,QigevCplXxbPI1H,'episodes')
			return
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="Episodes--Seasons--Episodes(.*?)</singlesections>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<episodeTitle>(.*?)</episodeTitle>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.IGNORECASE)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,562)
	if not lc0jJQ4zboeDI3tqTrpvm5gZO:
		title = sBvufaD6c9YHdOqTjCQ3.findall('<title>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',QigevCplXxbPI1H).replace('مشاهدة ',QigevCplXxbPI1H)
		else: title = 'ملف التشغيل'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,562)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'WECIMA-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl:
		eFQorJTmf8xANMbKW9sl = [eFQorJTmf8xANMbKW9sl[0][0],eFQorJTmf8xANMbKW9sl[0][1]]
		if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-url="(.*?)".*?strong>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,name in items:
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if name=='سيرفر وي سيما': name = 'wecima'
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__watch'
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="List--Download(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,oI6LvXMf4VEPe8jOdpKC0hUmS in items:
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			oI6LvXMf4VEPe8jOdpKC0hUmS = sBvufaD6c9YHdOqTjCQ3.findall('\d\d\d+',oI6LvXMf4VEPe8jOdpKC0hUmS,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if oI6LvXMf4VEPe8jOdpKC0hUmS: oI6LvXMf4VEPe8jOdpKC0hUmS = '____'+oI6LvXMf4VEPe8jOdpKC0hUmS[0]
			else: oI6LvXMf4VEPe8jOdpKC0hUmS = QigevCplXxbPI1H
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named=wecima'+'__download'+oI6LvXMf4VEPe8jOdpKC0hUmS
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search,YAiEga58hrs9w06yOzXMZNe2D=QigevCplXxbPI1H):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	if not YAiEga58hrs9w06yOzXMZNe2D:
		YAiEga58hrs9w06yOzXMZNe2D = vxQUXEuH9m
	Kj0TOU6BmSMlJHZYLd = YAiEga58hrs9w06yOzXMZNe2D+'/AjaxCenter/Searching/'+search+'/'
	ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd,'search')
	return
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(X6sJNAHy4Ufmi,filter):
	if '??' in X6sJNAHy4Ufmi: url = X6sJNAHy4Ufmi.split('//getposts??')[0]
	else: url = X6sJNAHy4Ufmi
	filter = filter.replace('_FORGETRESULTS_',QigevCplXxbPI1H)
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='CATEGORIES':
		if XU3eP0JI7tSANQ6CzaBy1H[0]+'==' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XU3eP0JI7tSANQ6CzaBy1H[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XU3eP0JI7tSANQ6CzaBy1H[0:-1])):
			if XU3eP0JI7tSANQ6CzaBy1H[A5SjhJUg37pNiMC4Eot6lOF]+'==' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XU3eP0JI7tSANQ6CzaBy1H[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&&'+opIyA9rsJMXPL1k+'==0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&&'+opIyA9rsJMXPL1k+'==0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&&')+'___'+oG5dMKyX6VQPhmuL0.strip('&&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		Kj0TOU6BmSMlJHZYLd = url+'//getposts??'+IhG0UytMJko7
	elif type=='FILTERS':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'//getposts??'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		mQx10f2SaKD = LyOj2WGHrRXZK0c(Kj0TOU6BmSMlJHZYLd,X6sJNAHy4Ufmi)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',mQx10f2SaKD,561,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',mQx10f2SaKD,561,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'WECIMA-FILTERS_MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('\\"','"').replace('\\/','/')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<wecima--filter(.*?)</wecima--filter>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not fwSu6JsQZpEiv: return
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',LKzFWsmvjUVGMDBapflx6H4NY+'<filterbox',sBvufaD6c9YHdOqTjCQ3.DOTALL)
	dict = {}
	for Vjv2Okb6qhMRQgaDlu3JCir,name,LKzFWsmvjUVGMDBapflx6H4NY in GTvCiBk9e5HnWobxXw6AzV3KQ:
		name = arFSQucmG9HxDody67JCI8pBMk4L(name)
		if 'interest' in Vjv2Okb6qhMRQgaDlu3JCir: continue
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if '==' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='CATEGORIES':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<=1:
				if Vjv2Okb6qhMRQgaDlu3JCir==XU3eP0JI7tSANQ6CzaBy1H[-1]: ddbEXhWzOnIaR(Kj0TOU6BmSMlJHZYLd)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'CATEGORIES___'+Vq4HIkij2ZLE)
				return
			else:
				mQx10f2SaKD = LyOj2WGHrRXZK0c(Kj0TOU6BmSMlJHZYLd,X6sJNAHy4Ufmi)
				if Vjv2Okb6qhMRQgaDlu3JCir==XU3eP0JI7tSANQ6CzaBy1H[-1]:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',mQx10f2SaKD,561,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,564,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='FILTERS':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'==0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'==0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+name+': الجميع',Kj0TOU6BmSMlJHZYLd,565,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE+'_FORGETRESULTS_')
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			name = arFSQucmG9HxDody67JCI8pBMk4L(name)
			C4kS0cewBJy8YOWtZxXNjfM2 = arFSQucmG9HxDody67JCI8pBMk4L(C4kS0cewBJy8YOWtZxXNjfM2)
			if nFdGHjceZzW=='r' or nFdGHjceZzW=='nc-17': continue
			if any(nFdGHjceZzW in C4kS0cewBJy8YOWtZxXNjfM2.lower() for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			if 'http' in C4kS0cewBJy8YOWtZxXNjfM2: continue
			if 'الكل' in C4kS0cewBJy8YOWtZxXNjfM2: continue
			if 'n-a' in nFdGHjceZzW: continue
			if C4kS0cewBJy8YOWtZxXNjfM2==QigevCplXxbPI1H: C4kS0cewBJy8YOWtZxXNjfM2 = nFdGHjceZzW
			eliZWRgEXtMSxzpAPBUY4rnuq85F = C4kS0cewBJy8YOWtZxXNjfM2
			ulriBEj46A0khIOXn = sBvufaD6c9YHdOqTjCQ3.findall('<name>(.*?)</name>',C4kS0cewBJy8YOWtZxXNjfM2,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if ulriBEj46A0khIOXn: eliZWRgEXtMSxzpAPBUY4rnuq85F = ulriBEj46A0khIOXn[0]
			YIwQJyV0hAUR1EfKogObLzDMmx = name+': '+eliZWRgEXtMSxzpAPBUY4rnuq85F
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = YIwQJyV0hAUR1EfKogObLzDMmx
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'=='+eliZWRgEXtMSxzpAPBUY4rnuq85F
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&&'+Vjv2Okb6qhMRQgaDlu3JCir+'=='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			if type=='FILTERS':
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,url,565,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and XU3eP0JI7tSANQ6CzaBy1H[-2]+'==' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'modified_filters')
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'//getposts??'+IhG0UytMJko7
				mQx10f2SaKD = LyOj2WGHrRXZK0c(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,X6sJNAHy4Ufmi)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,mQx10f2SaKD,561,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,url,564,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
XU3eP0JI7tSANQ6CzaBy1H = ['genre','release-year','nation']
tp3jXgGP9wamJAW5kuCxdYfQz = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def LyOj2WGHrRXZK0c(Kj0TOU6BmSMlJHZYLd,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx):
	if '/AjaxCenter/RightBar' in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace('//getposts??','::/AjaxCenter/Filtering/')
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace('==','/')
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace('&&','/')
	return Kj0TOU6BmSMlJHZYLd
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc,bYlTrNXtvf0G7y = {},QigevCplXxbPI1H
	if '==' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('==')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	for key in tp3jXgGP9wamJAW5kuCxdYfQz:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&&'+key+'=='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&&'+key+'=='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&&')
	return bYlTrNXtvf0G7y
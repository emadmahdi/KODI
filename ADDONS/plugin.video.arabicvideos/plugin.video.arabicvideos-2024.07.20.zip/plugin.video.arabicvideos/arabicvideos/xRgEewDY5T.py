﻿# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'ALMAAREF'
headers = {'User-Agent':QigevCplXxbPI1H}
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_MRF_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def YnMSWTbKj1N8wuRJVF(mode,url,text,JJM6TofH4g5n7SRwq):
	if   mode==40: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==41: W9lfsoMawqOzpQcXD = NuF8RLt0WonUPObjBdYXm4Dfa()
	elif mode==42: W9lfsoMawqOzpQcXD = hmwycrfHE6Rx9WYPOUSMV0zi(text,JJM6TofH4g5n7SRwq)
	elif mode==43: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==44: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(text,JJM6TofH4g5n7SRwq)
	elif mode==49: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,49)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'البث الحي لقناة المعارف',QigevCplXxbPI1H,41)
	hmwycrfHE6Rx9WYPOUSMV0zi(QigevCplXxbPI1H,'1')
	return
def Te80IuCAKxndtilwPNEYjcBr3L9(iBux5zA0swygKtRlDCTH,QDf1peuhkzd):
	search,sort,SpE2b6aJIGz8HAfmkFDrgvWhedCKuP,opIyA9rsJMXPL1k,KlGAaC9r32UJE0k8xgWoSZcLTY5 = QigevCplXxbPI1H,[],[],[],[]
	tX1WYGPmux,IIG6gjmlBn2OLrXH4Rq = b9PJzXFf4dYnGHm52NWsyA8(iBux5zA0swygKtRlDCTH)
	for C4kS0cewBJy8YOWtZxXNjfM2 in list(IIG6gjmlBn2OLrXH4Rq.keys()):
		nFdGHjceZzW = IIG6gjmlBn2OLrXH4Rq[C4kS0cewBJy8YOWtZxXNjfM2]
		if not nFdGHjceZzW: continue
		if   C4kS0cewBJy8YOWtZxXNjfM2=='sort': sort = [nFdGHjceZzW]
		elif C4kS0cewBJy8YOWtZxXNjfM2=='series': SpE2b6aJIGz8HAfmkFDrgvWhedCKuP = [nFdGHjceZzW]
		elif C4kS0cewBJy8YOWtZxXNjfM2=='search': search = nFdGHjceZzW
		elif C4kS0cewBJy8YOWtZxXNjfM2=='category': opIyA9rsJMXPL1k = [nFdGHjceZzW]
		elif C4kS0cewBJy8YOWtZxXNjfM2=='specialist': KlGAaC9r32UJE0k8xgWoSZcLTY5 = [nFdGHjceZzW]
	A1AqSc2LNwW0ETgyaRl9 = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":opIyA9rsJMXPL1k,"specialist":KlGAaC9r32UJE0k8xgWoSZcLTY5,"series":SpE2b6aJIGz8HAfmkFDrgvWhedCKuP,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(QDf1peuhkzd)}}
	import json as hlKGtjPuCaeIWUwvgMxp9
	A1AqSc2LNwW0ETgyaRl9 = hlKGtjPuCaeIWUwvgMxp9.dumps(A1AqSc2LNwW0ETgyaRl9)
	RMC6c2kL5hGOnFaIwAyb = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',RMC6c2kL5hGOnFaIwAyb,A1AqSc2LNwW0ETgyaRl9,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	data = CH86N7xw4cyPt3TlIBJF('dict',aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	return data
def hmwycrfHE6Rx9WYPOUSMV0zi(iBux5zA0swygKtRlDCTH,level):
	mfFwcWZHXVGvyU3B0ILburCoh = Te80IuCAKxndtilwPNEYjcBr3L9(iBux5zA0swygKtRlDCTH,'1')
	LKzFWsmvjUVGMDBapflx6H4NY = mfFwcWZHXVGvyU3B0ILburCoh['facets']
	if level=='1':
		LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY['video_categories']
		items = sBvufaD6c9YHdOqTjCQ3.findall('<div(.*?)/div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',upHdVltvOIDPnN0SefZwGo4gJ9LqsY+'<',sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if not UX3RT0evEunCm2cHIz1Qs: UX3RT0evEunCm2cHIz1Qs = sBvufaD6c9YHdOqTjCQ3.findall('data-value=\\"(.*?)\\">(.*?)<',upHdVltvOIDPnN0SefZwGo4gJ9LqsY+'<',sBvufaD6c9YHdOqTjCQ3.DOTALL)
			opIyA9rsJMXPL1k,title = UX3RT0evEunCm2cHIz1Qs[0]
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: title = arFSQucmG9HxDody67JCI8pBMk4L(title)
			if not iBux5zA0swygKtRlDCTH: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,42,QigevCplXxbPI1H,'2','?category='+opIyA9rsJMXPL1k)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,42,QigevCplXxbPI1H,'2',iBux5zA0swygKtRlDCTH+'&category='+opIyA9rsJMXPL1k)
	if level=='2':
		LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY['specialist']
		items = sBvufaD6c9YHdOqTjCQ3.findall('value="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for KlGAaC9r32UJE0k8xgWoSZcLTY5,title in items:
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: title = arFSQucmG9HxDody67JCI8pBMk4L(title)
			if not KlGAaC9r32UJE0k8xgWoSZcLTY5: title = title = 'الجميع'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,42,QigevCplXxbPI1H,'3',iBux5zA0swygKtRlDCTH+'&specialist='+KlGAaC9r32UJE0k8xgWoSZcLTY5)
	elif level=='3':
		LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY['series']
		items = sBvufaD6c9YHdOqTjCQ3.findall('value="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for SpE2b6aJIGz8HAfmkFDrgvWhedCKuP,title in items:
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: title = arFSQucmG9HxDody67JCI8pBMk4L(title)
			if not SpE2b6aJIGz8HAfmkFDrgvWhedCKuP: title = title = 'الجميع'
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,42,QigevCplXxbPI1H,'4',iBux5zA0swygKtRlDCTH+'&series='+SpE2b6aJIGz8HAfmkFDrgvWhedCKuP)
	elif level=='4':
		LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY['sort_video']
		items = sBvufaD6c9YHdOqTjCQ3.findall('value="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for sort,title in items:
			if not sort: continue
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: title = arFSQucmG9HxDody67JCI8pBMk4L(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,44,QigevCplXxbPI1H,'1',iBux5zA0swygKtRlDCTH+'&sort='+sort)
	return
def ddbEXhWzOnIaR(iBux5zA0swygKtRlDCTH,QDf1peuhkzd):
	mfFwcWZHXVGvyU3B0ILburCoh = Te80IuCAKxndtilwPNEYjcBr3L9(iBux5zA0swygKtRlDCTH,QDf1peuhkzd)
	LKzFWsmvjUVGMDBapflx6H4NY = mfFwcWZHXVGvyU3B0ILburCoh['template']
	items = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)".*?href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: title = arFSQucmG9HxDody67JCI8pBMk4L(title)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,43,cXu4fN1moCypJqb72OZvd)
	LKzFWsmvjUVGMDBapflx6H4NY = mfFwcWZHXVGvyU3B0ILburCoh['facets']['pagination']
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-page="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for JJM6TofH4g5n7SRwq,title in items:
		if QDf1peuhkzd==JJM6TofH4g5n7SRwq: continue
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG: title = arFSQucmG9HxDody67JCI8pBMk4L(title)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,QigevCplXxbPI1H,44,QigevCplXxbPI1H,JJM6TofH4g5n7SRwq,iBux5zA0swygKtRlDCTH)
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ALMAAREF-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('<video src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('youtube_url.*?(http.*?)&',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	vdLczqkV5b48ZKyGxTE3jJi17aWS6 = []
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0].replace('\/','/')
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def NuF8RLt0WonUPObjBdYXm4Dfa():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m+'/بث-مباشر',QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ALMAAREF-LIVE-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	url = sBvufaD6c9YHdOqTjCQ3.findall('"svpPlayer".*?(http.*?)&',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	url = url[0].replace('\\',QigevCplXxbPI1H)
	B9BaTCd86Iwz1e3sRMXZylKpcHU(url,PuT0IphGNsketAQ,'live')
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	BS2DrNyuWw8FLP75 = False
	if search==QigevCplXxbPI1H:
		search = XAfEvmh95VkgurjdiJ()
		BS2DrNyuWw8FLP75 = True
	if search==QigevCplXxbPI1H: return
	if not BS2DrNyuWw8FLP75: ddbEXhWzOnIaR('?search='+search,'1')
	else: hmwycrfHE6Rx9WYPOUSMV0zi('?search='+search,'1')
	return
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'CIMA4U'
headers = {'User-Agent':QigevCplXxbPI1H}
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_C4U_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==420: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==421: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==422: W9lfsoMawqOzpQcXD = Wy9QU4Ns8orXtliKZSjnJH3bVF(url)
	elif mode==423: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==424: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==427: W9lfsoMawqOzpQcXD = WYlKcfgd9BnhGCJj(url)
	elif mode==429: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	unA4F0ajXBUwHksrx3IyNCJL = unA4F0ajXBUwHksrx3IyNCJL[0].strip('/')
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(unA4F0ajXBUwHksrx3IyNCJL,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,429,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',unA4F0ajXBUwHksrx3IyNCJL,425)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',unA4F0ajXBUwHksrx3IyNCJL,424)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الرئيسية',unA4F0ajXBUwHksrx3IyNCJL,421)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('NavigationMenu(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="*(.*?)"*>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		if '/actors' in RMC6c2kL5hGOnFaIwAyb: title = 'أفلام النجوم'
		elif '/netflix' in RMC6c2kL5hGOnFaIwAyb: title = 'أفلام ومسلسلات نيتفلكس'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,421)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'قائمة تفصيلية',unA4F0ajXBUwHksrx3IyNCJL,427)
	return
def WYlKcfgd9BnhGCJj(website=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('FilteringTitle(.*?)PageTitle',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for opIyA9rsJMXPL1k,id,RMC6c2kL5hGOnFaIwAyb,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		if 'netflix-movies' in RMC6c2kL5hGOnFaIwAyb: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in RMC6c2kL5hGOnFaIwAyb: title = 'مسلسلات نيتفلكس'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,421,QigevCplXxbPI1H,QigevCplXxbPI1H,opIyA9rsJMXPL1k+'|'+id)
	return
def ddbEXhWzOnIaR(url,ZDQqkvbtHmB4=QigevCplXxbPI1H):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if not ZDQqkvbtHmB4 or '|' in ZDQqkvbtHmB4:
		if '|' not in ZDQqkvbtHmB4: ZxRYrvb8a2pqITAJX50oPeFVyktfu = QigevCplXxbPI1H
		else: ZxRYrvb8a2pqITAJX50oPeFVyktfu = '/archive/'+ZDQqkvbtHmB4
		JvHXPSz0mLOf2Tl = False
		if 'PinSlider' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',url,421,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
			JvHXPSz0mLOf2Tl = True
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('PageTitle(.*?)PageContent',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			Pk5h14WpxO3nAQFv0rYmNa8KDblSg = fwSu6JsQZpEiv[0]
			WWcSoXlyFCIzMGpxr = sBvufaD6c9YHdOqTjCQ3.findall('data-tab="(.*?)".*?<span>(.*?)<',Pk5h14WpxO3nAQFv0rYmNa8KDblSg,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for j7iLCQGXTK3SMYI021RmBvsb6dz8k,YIwQJyV0hAUR1EfKogObLzDMmx in WWcSoXlyFCIzMGpxr:
				Wdek0SptsHCKog19OBJDTRAX7m = unA4F0ajXBUwHksrx3IyNCJL+'/ajaxcenter/action/HomepageLoader/tab/'+j7iLCQGXTK3SMYI021RmBvsb6dz8k+ZxRYrvb8a2pqITAJX50oPeFVyktfu+'/'
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,Wdek0SptsHCKog19OBJDTRAX7m,421)
				JvHXPSz0mLOf2Tl = True
		if JvHXPSz0mLOf2Tl: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	if ZDQqkvbtHmB4=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('PinSlider(.*?)MultiFilter',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('PinSlider(.*?)PageTitle',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		else: LKzFWsmvjUVGMDBapflx6H4NY = QigevCplXxbPI1H
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
	elif '/filter/' in url:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('PageContent(.*?)class="*pagination"*',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif '/actors' in url:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('PageContent(.*?)class="*pagination"*',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('Cima4uBlocks(.*?)</li></ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		else: LKzFWsmvjUVGMDBapflx6H4NY = QigevCplXxbPI1H
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if not title: continue
		if '?news=' in RMC6c2kL5hGOnFaIwAyb: continue
		title = title.replace('مشاهدة ',QigevCplXxbPI1H)
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) حلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if V1nZX7O5WwEq8HmvkY and 'حلقة' in title:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,422,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif '/actor/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,421,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,422,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('pagination(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv and ZDQqkvbtHmB4!='featured':
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			title = title.replace('الصفحة ',QigevCplXxbPI1H)
			if title!=QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,421)
	CMdDv3wHmpqtT0JBPrUXhR = sBvufaD6c9YHdOqTjCQ3.findall('</li><a href="(.*?)".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if CMdDv3wHmpqtT0JBPrUXhR:
		RMC6c2kL5hGOnFaIwAyb,title = CMdDv3wHmpqtT0JBPrUXhR[0]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,421)
	return
def Wy9QU4Ns8orXtliKZSjnJH3bVF(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-SEASONS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="WatchNow".*?href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		url = fwSu6JsQZpEiv[0]
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-SEASONS-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('SeasonsSections(.*?)</div></div></div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if '/tag/' in url or '/actor' in url:
		ddbEXhWzOnIaR(url)
	elif fwSu6JsQZpEiv:
		cXu4fN1moCypJqb72OZvd = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel('ListItem.Thumb')
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall("href='(.*?)'>(.*?)<",LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		SEzTUF4vo1hQj5aWJf32u6KRb = ['مسلسل','موسم','برنامج','حلقة']
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if any(nFdGHjceZzW in title for nFdGHjceZzW in SEzTUF4vo1hQj5aWJf32u6KRb):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,423,cXu4fN1moCypJqb72OZvd)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,426,cXu4fN1moCypJqb72OZvd)
	else: oB2rmVgqUND(url)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('"background-image:url\((.*?)\)',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0]
	else: cXu4fN1moCypJqb72OZvd = QigevCplXxbPI1H
	fq3nlxd1gG0 = sBvufaD6c9YHdOqTjCQ3.findall('EpisodesSection(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fq3nlxd1gG0:
		LKzFWsmvjUVGMDBapflx6H4NY = fq3nlxd1gG0[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,V1nZX7O5WwEq8HmvkY in items:
			title = title+hT7zFDpEyUqf8sXuN+V1nZX7O5WwEq8HmvkY
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,426,cXu4fN1moCypJqb72OZvd)
	else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'رابط التشغيل',url,426,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	sWCdrbui4wDjMg9yhQR7T3O = JJrhP4C6osGDFEKVSRBvX.url
	if L2EXWK5vf3AoDtV8F6OgNBqkmyG: sWCdrbui4wDjMg9yhQR7T3O = sWCdrbui4wDjMg9yhQR7T3O.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(sWCdrbui4wDjMg9yhQR7T3O,'url')
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('WatchSection(.*?)</div></div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-link="(.*?)".*? />(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for rYsGTvB7OdokCyS10MHXEPzhe,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if 'myvid' in title.lower(): title = 'خاص '+title
			RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/structure/server.php?id='+rYsGTvB7OdokCyS10MHXEPzhe+'?named='+title+'__watch'
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('DownloadServers(.*?)</div></div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*? />(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if 'myvid' in title.lower(): YIwQJyV0hAUR1EfKogObLzDMmx = '__خاص'
			else: YIwQJyV0hAUR1EfKogObLzDMmx = QigevCplXxbPI1H
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'+YIwQJyV0hAUR1EfKogObLzDMmx
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(Ymkp8qFPsjovc57UT,QigevCplXxbPI1H)
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/Search?q='+search
	ddbEXhWzOnIaR(url,'search')
	return
def bZ297CKlfXUW1n5BghJjzHQMi(url):
	if 'smartemadfilter' not in url: url = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('MultiFilter(.*?)PageTitle',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return GTvCiBk9e5HnWobxXw6AzV3KQ
def k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY):
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-id="(.*?)".*?</div>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return items
def ZUusq9Gr6KtlWHJQ(url):
	ffJtczXvkj0o2HUZRprAOS = url.split('/smartemadfilter?')[0]
	gd2lmLiIyEvcsT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	url = url.replace(ffJtczXvkj0o2HUZRprAOS,gd2lmLiIyEvcsT)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
XGiBxdyuLeSzpmvUCEwJI = ['category','types','release-year']
NBJvnaA2GkRo6SD79YsVjqd = ['Quality','release-year','types','category']
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global XGiBxdyuLeSzpmvUCEwJI
			XGiBxdyuLeSzpmvUCEwJI = XGiBxdyuLeSzpmvUCEwJI[1:]
		if XGiBxdyuLeSzpmvUCEwJI[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XGiBxdyuLeSzpmvUCEwJI[0:-1])):
			if XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
	elif type=='ALL_ITEMS_FILTER':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		Kj0TOU6BmSMlJHZYLd = ZUusq9Gr6KtlWHJQ(Kj0TOU6BmSMlJHZYLd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',Kj0TOU6BmSMlJHZYLd,421,QigevCplXxbPI1H,QigevCplXxbPI1H,'filter')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',Kj0TOU6BmSMlJHZYLd,421,QigevCplXxbPI1H,QigevCplXxbPI1H,'filter')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	GTvCiBk9e5HnWobxXw6AzV3KQ = bZ297CKlfXUW1n5BghJjzHQMi(url)
	dict = {}
	for name,LKzFWsmvjUVGMDBapflx6H4NY,Vjv2Okb6qhMRQgaDlu3JCir in GTvCiBk9e5HnWobxXw6AzV3KQ:
		if '/category/' in url and Vjv2Okb6qhMRQgaDlu3JCir=='category': continue
		name = name.replace('--',QigevCplXxbPI1H)
		items = k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='SPECIFIED_FILTER':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<2:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]:
					url = ZUusq9Gr6KtlWHJQ(url)
					ddbEXhWzOnIaR(url)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'SPECIFIED_FILTER___'+Vq4HIkij2ZLE)
				return
			else:
				Kj0TOU6BmSMlJHZYLd = ZUusq9Gr6KtlWHJQ(Kj0TOU6BmSMlJHZYLd)
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,421,QigevCplXxbPI1H,QigevCplXxbPI1H,'filter')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',Kj0TOU6BmSMlJHZYLd,425,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='ALL_ITEMS_FILTER':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع :'+name,Kj0TOU6BmSMlJHZYLd,424,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if nFdGHjceZzW=='196533': C4kS0cewBJy8YOWtZxXNjfM2 = 'أفلام نيتفلكس'
			elif nFdGHjceZzW=='196531': C4kS0cewBJy8YOWtZxXNjfM2 = 'مسلسلات نيتفلكس'
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'#+dict[Vjv2Okb6qhMRQgaDlu3JCir]['0']
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'+name
			if type=='ALL_ITEMS_FILTER': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,424,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='SPECIFIED_FILTER' and XGiBxdyuLeSzpmvUCEwJI[-2]+'=' in QSUrMykAebtx0Ea6:
				IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'modified_filters')
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'/smartemadfilter?'+IhG0UytMJko7
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = ZUusq9Gr6KtlWHJQ(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,421,QigevCplXxbPI1H,QigevCplXxbPI1H,'filter')
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,425,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.replace('=&','=0&')
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	for key in NBJvnaA2GkRo6SD79YsVjqd:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.replace('=0','=')
	return bYlTrNXtvf0G7y
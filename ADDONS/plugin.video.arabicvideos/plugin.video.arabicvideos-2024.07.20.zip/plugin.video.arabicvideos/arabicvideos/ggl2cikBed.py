# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'TVFUN'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_TVF_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['بث مباشر']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==460: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==461: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==462: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==463: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==469: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'TVFUN-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,469,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"menu-btn"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in ef1pQcbEtPjMnXYrvOi: continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,461)
	return
def ddbEXhWzOnIaR(url,ZDQqkvbtHmB4=QigevCplXxbPI1H):
	items = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'TVFUN-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="head-title"(.*?)id="footer"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		wibHRCAFtsupIjx4ZTELeM = []
		EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			title = '_MOD_'+title.replace('<br>',hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).strip(hT7zFDpEyUqf8sXuN)
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb)
			V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,462,cXu4fN1moCypJqb72OZvd)
			elif V1nZX7O5WwEq8HmvkY and 'الحلقة' in title:
				title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
				if title not in wibHRCAFtsupIjx4ZTELeM:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,463,cXu4fN1moCypJqb72OZvd)
					wibHRCAFtsupIjx4ZTELeM.append(title)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,463,cXu4fN1moCypJqb72OZvd)
	if ZDQqkvbtHmB4!='latest':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('<a href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.strip(hT7zFDpEyUqf8sXuN)
				if RMC6c2kL5hGOnFaIwAyb=="": continue
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
				if title!=QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,461)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'TVFUN-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="head-title"(.*?)id="footer"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if items:
			for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
				title = '_MOD_'+title.replace('<br>',hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).strip(hT7zFDpEyUqf8sXuN)
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,462,cXu4fN1moCypJqb72OZvd)
		else:
			items = sBvufaD6c9YHdOqTjCQ3.findall('class="episode.*?href="(.*?)" title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,462)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.strip(hT7zFDpEyUqf8sXuN)
			if RMC6c2kL5hGOnFaIwAyb=="": continue
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if title!=QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,463)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m = []
	Kj0TOU6BmSMlJHZYLd = url.replace('/video/','/watch/')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'TVFUN-PLAY-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('VideoServers"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for pfqUwreoL6HFNx,name in rsBojxT8UZwL:
			pfqUwreoL6HFNx = pfqUwreoL6HFNx[2:]
			if L2EXWK5vf3AoDtV8F6OgNBqkmyG: pfqUwreoL6HFNx = pfqUwreoL6HFNx.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			pfqUwreoL6HFNx = akgfpLEN8Kn396XjFUut4QJVI.b64decode(pfqUwreoL6HFNx)
			if b7sJAmSxlBvaMdHFz: pfqUwreoL6HFNx = pfqUwreoL6HFNx.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)"',pfqUwreoL6HFNx,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0]
			if 'http' not in RMC6c2kL5hGOnFaIwAyb:
				if '//' in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
				else: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			if RMC6c2kL5hGOnFaIwAyb not in ldFqnNIsftrY43JBM6LPjzU8m:
				RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__watch'
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search:
		search = XAfEvmh95VkgurjdiJ()
		if not search: return
	if hT7zFDpEyUqf8sXuN in search:
		if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = vxQUXEuH9m+'/q/'+search+'/'
	ddbEXhWzOnIaR(url)
	return
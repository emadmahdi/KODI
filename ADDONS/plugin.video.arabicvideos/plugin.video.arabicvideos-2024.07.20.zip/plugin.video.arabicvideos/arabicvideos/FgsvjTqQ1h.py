# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'LIVETV'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK['PYTHON'][0]
def YnMSWTbKj1N8wuRJVF(mode,url):
	if   mode==100: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==101: W9lfsoMawqOzpQcXD = PYViltfWah910OHUZeR('0',True)
	elif mode==102: W9lfsoMawqOzpQcXD = PYViltfWah910OHUZeR('1',True)
	elif mode==103: W9lfsoMawqOzpQcXD = PYViltfWah910OHUZeR('2',True)
	elif mode==104: W9lfsoMawqOzpQcXD = PYViltfWah910OHUZeR('3',True)
	elif mode==105: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==106: W9lfsoMawqOzpQcXD = PYViltfWah910OHUZeR('4',True)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_M3U_'+'قوائم فيديوهات M3U',QigevCplXxbPI1H,762)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_IPT_'+'قوائم فيديوهات IPTV',QigevCplXxbPI1H,761)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_TV0_'+'قنوات من مواقعها الأصلية',QigevCplXxbPI1H,101)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_TV4_'+'قنوات مختارة من يوتيوب',QigevCplXxbPI1H,106)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_YUT_'+'قنوات عربية من يوتيوب',QigevCplXxbPI1H,147)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_YUT_'+'قنوات أجنبية من يوتيوب',QigevCplXxbPI1H,148)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',QigevCplXxbPI1H,28)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live','_MRF_'+'قناة المعارف من موقعهم',QigevCplXxbPI1H,41)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live','_PNT_'+'قناة هلا من موقع بانيت',QigevCplXxbPI1H,38)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_TV1_'+'قنوات تلفزيونية عامة',QigevCplXxbPI1H,102)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_TV2_'+'قنوات تلفزيونية خاصة',QigevCplXxbPI1H,103)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder','_TV3_'+'قنوات تلفزيونية للفحص',QigevCplXxbPI1H,104)
	return
def PYViltfWah910OHUZeR(by1nQW7VS4FL,showDialogs=True):
	iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_TV'+by1nQW7VS4FL+'_'
	PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(32)
	A1AqSc2LNwW0ETgyaRl9 = {'id':QigevCplXxbPI1H,'user':PXVdZQYTNslvg7wF0159Akr,'function':'list','menu':by1nQW7VS4FL}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',vxQUXEuH9m,A1AqSc2LNwW0ETgyaRl9,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'LIVETV-ITEMS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	items = sBvufaD6c9YHdOqTjCQ3.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items:
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(items)):
			name = items[A5SjhJUg37pNiMC4Eot6lOF][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[A5SjhJUg37pNiMC4Eot6lOF] = items[A5SjhJUg37pNiMC4Eot6lOF][0],items[A5SjhJUg37pNiMC4Eot6lOF][1],items[A5SjhJUg37pNiMC4Eot6lOF][2],name,items[A5SjhJUg37pNiMC4Eot6lOF][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for m9TrBXjhwRgI,bSrdN78jxURTvh9,TfilazROjy,name,cXu4fN1moCypJqb72OZvd in items:
			if '#' in m9TrBXjhwRgI: continue
			if m9TrBXjhwRgI!='URL': name = name+iVCLpNIM8BQs9PdSgKZvlFeo3a5+Ec4QJmyAo3G7Vp2X6SY8UifnOh+m9TrBXjhwRgI+jhAlCQ47ZgG
			url = m9TrBXjhwRgI+';;'+bSrdN78jxURTvh9+';;'+TfilazROjy+';;'+by1nQW7VS4FL
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+QigevCplXxbPI1H+name,url,105,cXu4fN1moCypJqb72OZvd)
	else:
		if showDialogs: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'هذه الخدمة مخصصة للمبرمج فقط',QigevCplXxbPI1H,9999)
	return
def nibvTq2jfRXDM4tYP039S(id):
	m9TrBXjhwRgI,bSrdN78jxURTvh9,TfilazROjy,by1nQW7VS4FL = id.split(';;')
	url = QigevCplXxbPI1H
	PXVdZQYTNslvg7wF0159Akr = U8bMvkLTxSzw5ac(32)
	if m9TrBXjhwRgI=='URL': url = TfilazROjy
	elif m9TrBXjhwRgI=='YOUTUBE':
		url = OQv0iWIw5bFRATU2mxJjZK['YOUTUBE'][0]+'/watch?v='+TfilazROjy
		import u8j7hmKf9V
		u8j7hmKf9V.v7h95wpulLk8HGNgezKM([url],PuT0IphGNsketAQ,'live',url)
		return
	elif m9TrBXjhwRgI=='GA':
		A1AqSc2LNwW0ETgyaRl9 = { 'id' : QigevCplXxbPI1H, 'user' : PXVdZQYTNslvg7wF0159Akr , 'function' : 'playGA1' , 'menu' : QigevCplXxbPI1H }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',vxQUXEuH9m,A1AqSc2LNwW0ETgyaRl9,QigevCplXxbPI1H,False,QigevCplXxbPI1H,'LIVETV-PLAY-1st')
		if not JJrhP4C6osGDFEKVSRBvX.succeeded:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		cookies = JJrhP4C6osGDFEKVSRBvX.cookies
		BxyHIU8VP36gkTMp = cookies['ASP.NET_SessionId']
		url = JJrhP4C6osGDFEKVSRBvX.headers['Location']
		A1AqSc2LNwW0ETgyaRl9 = { 'id' : TfilazROjy , 'user' : PXVdZQYTNslvg7wF0159Akr , 'function' : 'playGA2' , 'menu' : QigevCplXxbPI1H }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+BxyHIU8VP36gkTMp }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',vxQUXEuH9m,A1AqSc2LNwW0ETgyaRl9,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'LIVETV-PLAY-2nd')
		if not JJrhP4C6osGDFEKVSRBvX.succeeded:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		url = sBvufaD6c9YHdOqTjCQ3.findall('resp":"(http.*?m3u8)(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		RMC6c2kL5hGOnFaIwAyb = url[0][0]
		gg6KCcWVSQTO85LDf = url[0][1]
		VjfaBs57DhXSTYRZ0MAFwkv = 'http://38.'+bSrdN78jxURTvh9+'777/'+TfilazROjy+'_HD.m3u8'+gg6KCcWVSQTO85LDf
		uSexJlUOrKEG3w21vRPTApmys = VjfaBs57DhXSTYRZ0MAFwkv.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		mxTjDzW8KYQ = VjfaBs57DhXSTYRZ0MAFwkv.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		ttGBwQOv3K41hIkc6 = ['HD','SD1','SD2']
		ldFqnNIsftrY43JBM6LPjzU8m = [VjfaBs57DhXSTYRZ0MAFwkv,uSexJlUOrKEG3w21vRPTApmys,mxTjDzW8KYQ]
		HHZ6579kAv8 = 0
		if HHZ6579kAv8 == -1: return
		else: url = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
	elif m9TrBXjhwRgI=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		A1AqSc2LNwW0ETgyaRl9 = { 'id' : TfilazROjy , 'user' : PXVdZQYTNslvg7wF0159Akr , 'function' : 'playNT' , 'menu' : by1nQW7VS4FL }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST', vxQUXEuH9m, A1AqSc2LNwW0ETgyaRl9, headers, False,QigevCplXxbPI1H,'LIVETV-PLAY-3rd')
		if not JJrhP4C6osGDFEKVSRBvX.succeeded:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		url = JJrhP4C6osGDFEKVSRBvX.headers['Location']
		url = url.replace('%20',hT7zFDpEyUqf8sXuN)
		url = url.replace('%3D','=')
		if 'Learn' in TfilazROjy:
			url = url.replace('NTNNile',QigevCplXxbPI1H)
			url = url.replace('learning1','Learning')
	elif m9TrBXjhwRgI=='PL':
		A1AqSc2LNwW0ETgyaRl9 = { 'id' : TfilazROjy , 'user' : PXVdZQYTNslvg7wF0159Akr , 'function' : 'playPL' , 'menu' : by1nQW7VS4FL }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST', vxQUXEuH9m, A1AqSc2LNwW0ETgyaRl9, QigevCplXxbPI1H,False,QigevCplXxbPI1H,'LIVETV-PLAY-4th')
		if not JJrhP4C6osGDFEKVSRBvX.succeeded:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		url = JJrhP4C6osGDFEKVSRBvX.headers['Location']
		headers = {'Referer':JJrhP4C6osGDFEKVSRBvX.headers['Referer']}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'POST',url, QigevCplXxbPI1H,headers , QigevCplXxbPI1H,QigevCplXxbPI1H,'LIVETV-PLAY-5th')
		if not JJrhP4C6osGDFEKVSRBvX.succeeded:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		items = sBvufaD6c9YHdOqTjCQ3.findall('source src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		url = items[0]
	elif m9TrBXjhwRgI in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if m9TrBXjhwRgI=='TA': TfilazROjy = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		A1AqSc2LNwW0ETgyaRl9 = { 'id' : TfilazROjy , 'user' : PXVdZQYTNslvg7wF0159Akr , 'function' : 'play'+m9TrBXjhwRgI , 'menu' : by1nQW7VS4FL }
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',vxQUXEuH9m,A1AqSc2LNwW0ETgyaRl9,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'LIVETV-PLAY-6th')
		if not JJrhP4C6osGDFEKVSRBvX.succeeded:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		url = JJrhP4C6osGDFEKVSRBvX.headers['Location']
		if m9TrBXjhwRgI=='FM':
			JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'GET', url, QigevCplXxbPI1H, QigevCplXxbPI1H, False,QigevCplXxbPI1H,'LIVETV-PLAY-7th')
			url = JJrhP4C6osGDFEKVSRBvX.headers['Location']
			url = url.replace('https','http')
	B9BaTCd86Iwz1e3sRMXZylKpcHU(url,PuT0IphGNsketAQ,'live')
	return
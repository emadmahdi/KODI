# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
JwBc6IZ4xeLmM8 = 'FAVORITES'
def WPjOcwA2E7GS4doDXyU3l9C(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hmlzWyBeMwpn6NSgcV0jLo5PQrv74):
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==270: JX4pLs7W5Mdm = aARx6VJZyYimz8Ns(hmlzWyBeMwpn6NSgcV0jLo5PQrv74)
	else: JX4pLs7W5Mdm = False
	return JX4pLs7W5Mdm
def rLdIGxeRKphTWYJ(SFQtU7cnyeo,hmlzWyBeMwpn6NSgcV0jLo5PQrv74,rwEQcd2z0uVB93Zb46XqSD):
	if not SFQtU7cnyeo: return
	if   rwEQcd2z0uVB93Zb46XqSD=='UP1'	: O8ECsBnZFiywSGJ2ka5tITQPgvcp(hmlzWyBeMwpn6NSgcV0jLo5PQrv74,True,1)
	elif rwEQcd2z0uVB93Zb46XqSD=='DOWN1'	: O8ECsBnZFiywSGJ2ka5tITQPgvcp(hmlzWyBeMwpn6NSgcV0jLo5PQrv74,False,1)
	elif rwEQcd2z0uVB93Zb46XqSD=='UP4'	: O8ECsBnZFiywSGJ2ka5tITQPgvcp(hmlzWyBeMwpn6NSgcV0jLo5PQrv74,True,4)
	elif rwEQcd2z0uVB93Zb46XqSD=='DOWN4'	: O8ECsBnZFiywSGJ2ka5tITQPgvcp(hmlzWyBeMwpn6NSgcV0jLo5PQrv74,False,4)
	elif rwEQcd2z0uVB93Zb46XqSD=='ADD1'	: E704nQHPAiGa(hmlzWyBeMwpn6NSgcV0jLo5PQrv74)
	elif rwEQcd2z0uVB93Zb46XqSD=='REMOVE1': X1Sa8sNmBcb40OqKyCpwjv(hmlzWyBeMwpn6NSgcV0jLo5PQrv74)
	elif rwEQcd2z0uVB93Zb46XqSD=='DELETELIST': v9QbBY4FZej28glacIiCwoTWzUy(hmlzWyBeMwpn6NSgcV0jLo5PQrv74)
	return
def aARx6VJZyYimz8Ns(hmlzWyBeMwpn6NSgcV0jLo5PQrv74):
	hNlMiomT7HXSeuOB4L6 = xCTgdOF20zM4U()
	if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()):
		try:
			goNvWtOLp5l8GDR7ixHJ = hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]
			for pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ in goNvWtOLp5l8GDR7ixHJ:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj(pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ)
		except:
			hNlMiomT7HXSeuOB4L6 = obvQGmCVO8(RpmwIQ5vaFkP8SuNW)
			goNvWtOLp5l8GDR7ixHJ = hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]
			for pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ in goNvWtOLp5l8GDR7ixHJ:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj(pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ)
	return
def E704nQHPAiGa(hmlzWyBeMwpn6NSgcV0jLo5PQrv74):
	pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ = c79RqAVuZjN1UaSOPB(MYIqLm4Nyhniu6QORWlrp)
	HARXP1tbN8r6xYlm = pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,TV74iI95g1jkpRMyQ
	hNlMiomT7HXSeuOB4L6 = xCTgdOF20zM4U()
	ovT3EZFKRSCPsy1zAtp8OaHgWk4hX = {}
	for OXqp8e1yM4Y9I5QvCWdTjhPoRN in list(hNlMiomT7HXSeuOB4L6.keys()):
		if OXqp8e1yM4Y9I5QvCWdTjhPoRN!=hmlzWyBeMwpn6NSgcV0jLo5PQrv74: ovT3EZFKRSCPsy1zAtp8OaHgWk4hX[OXqp8e1yM4Y9I5QvCWdTjhPoRN] = hNlMiomT7HXSeuOB4L6[OXqp8e1yM4Y9I5QvCWdTjhPoRN]
		else:
			if zsj5qOxnfaXmdEco3DK29HgYybUCM6 and zsj5qOxnfaXmdEco3DK29HgYybUCM6!='..':
				z0u9nQUfpFGelb2w5s = hNlMiomT7HXSeuOB4L6[OXqp8e1yM4Y9I5QvCWdTjhPoRN]
				if HARXP1tbN8r6xYlm in z0u9nQUfpFGelb2w5s:
					T05T2SACes1xXKIw = z0u9nQUfpFGelb2w5s.index(HARXP1tbN8r6xYlm)
					del z0u9nQUfpFGelb2w5s[T05T2SACes1xXKIw]
				NYv8Vi0kaz5xL2 = z0u9nQUfpFGelb2w5s+[HARXP1tbN8r6xYlm]
				ovT3EZFKRSCPsy1zAtp8OaHgWk4hX[OXqp8e1yM4Y9I5QvCWdTjhPoRN] = NYv8Vi0kaz5xL2
			else: ovT3EZFKRSCPsy1zAtp8OaHgWk4hX[OXqp8e1yM4Y9I5QvCWdTjhPoRN] = hNlMiomT7HXSeuOB4L6[OXqp8e1yM4Y9I5QvCWdTjhPoRN]
	if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 not in list(ovT3EZFKRSCPsy1zAtp8OaHgWk4hX.keys()): ovT3EZFKRSCPsy1zAtp8OaHgWk4hX[hmlzWyBeMwpn6NSgcV0jLo5PQrv74] = [HARXP1tbN8r6xYlm]
	L3kwNrgxRPSThJ9lfj4 = str(ovT3EZFKRSCPsy1zAtp8OaHgWk4hX)
	if b7sJAmSxlBvaMdHFz: L3kwNrgxRPSThJ9lfj4 = L3kwNrgxRPSThJ9lfj4.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	open(RpmwIQ5vaFkP8SuNW,'wb').write(L3kwNrgxRPSThJ9lfj4)
	return
def X1Sa8sNmBcb40OqKyCpwjv(hmlzWyBeMwpn6NSgcV0jLo5PQrv74):
	pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ = c79RqAVuZjN1UaSOPB(MYIqLm4Nyhniu6QORWlrp)
	HARXP1tbN8r6xYlm = pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,TV74iI95g1jkpRMyQ
	hNlMiomT7HXSeuOB4L6 = xCTgdOF20zM4U()
	if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()) and HARXP1tbN8r6xYlm in hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]:
		hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74].remove(HARXP1tbN8r6xYlm)
		if len(hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74])==0: del hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]
		L3kwNrgxRPSThJ9lfj4 = str(hNlMiomT7HXSeuOB4L6)
		if b7sJAmSxlBvaMdHFz: L3kwNrgxRPSThJ9lfj4 = L3kwNrgxRPSThJ9lfj4.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		open(RpmwIQ5vaFkP8SuNW,'wb').write(L3kwNrgxRPSThJ9lfj4)
	return
def O8ECsBnZFiywSGJ2ka5tITQPgvcp(hmlzWyBeMwpn6NSgcV0jLo5PQrv74,wLZfah1v6q7dEMKtmSUe,LHmZ7qBpcVrntkKaQXuNwDWsg3Ge8):
	pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ = c79RqAVuZjN1UaSOPB(MYIqLm4Nyhniu6QORWlrp)
	HARXP1tbN8r6xYlm = pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,TV74iI95g1jkpRMyQ
	hNlMiomT7HXSeuOB4L6 = xCTgdOF20zM4U()
	if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()):
		z0u9nQUfpFGelb2w5s = hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]
		if HARXP1tbN8r6xYlm not in z0u9nQUfpFGelb2w5s: return
		yyQfNqao6bnwHmUxgiztPk08M = len(z0u9nQUfpFGelb2w5s)
		for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(0,LHmZ7qBpcVrntkKaQXuNwDWsg3Ge8):
			wRP2QjZI5rnSW4lg = z0u9nQUfpFGelb2w5s.index(HARXP1tbN8r6xYlm)
			if wLZfah1v6q7dEMKtmSUe: qLC6xJBP8Fw9RKWVuZTXt4 = wRP2QjZI5rnSW4lg-1
			else: qLC6xJBP8Fw9RKWVuZTXt4 = wRP2QjZI5rnSW4lg+1
			if qLC6xJBP8Fw9RKWVuZTXt4>=yyQfNqao6bnwHmUxgiztPk08M: qLC6xJBP8Fw9RKWVuZTXt4 = qLC6xJBP8Fw9RKWVuZTXt4-yyQfNqao6bnwHmUxgiztPk08M
			if qLC6xJBP8Fw9RKWVuZTXt4<0: qLC6xJBP8Fw9RKWVuZTXt4 = qLC6xJBP8Fw9RKWVuZTXt4+yyQfNqao6bnwHmUxgiztPk08M
			z0u9nQUfpFGelb2w5s.insert(qLC6xJBP8Fw9RKWVuZTXt4, z0u9nQUfpFGelb2w5s.pop(wRP2QjZI5rnSW4lg))
		hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74] = z0u9nQUfpFGelb2w5s
		L3kwNrgxRPSThJ9lfj4 = str(hNlMiomT7HXSeuOB4L6)
		if b7sJAmSxlBvaMdHFz: L3kwNrgxRPSThJ9lfj4 = L3kwNrgxRPSThJ9lfj4.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		open(RpmwIQ5vaFkP8SuNW,'wb').write(L3kwNrgxRPSThJ9lfj4)
	return
def v9QbBY4FZej28glacIiCwoTWzUy(hmlzWyBeMwpn6NSgcV0jLo5PQrv74):
	tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+' ؟!')
	if tNVOmK5d8DvYoGr2!=1: return
	hNlMiomT7HXSeuOB4L6 = xCTgdOF20zM4U()
	if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()):
		del hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]
		L3kwNrgxRPSThJ9lfj4 = str(hNlMiomT7HXSeuOB4L6)
		if b7sJAmSxlBvaMdHFz: L3kwNrgxRPSThJ9lfj4 = L3kwNrgxRPSThJ9lfj4.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		open(RpmwIQ5vaFkP8SuNW,'wb').write(L3kwNrgxRPSThJ9lfj4)
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+hmlzWyBeMwpn6NSgcV0jLo5PQrv74)
	return
def xCTgdOF20zM4U():
	hNlMiomT7HXSeuOB4L6 = {}
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(RpmwIQ5vaFkP8SuNW):
		D4mRrLETpIV239 = open(RpmwIQ5vaFkP8SuNW,'rb').read()
		if b7sJAmSxlBvaMdHFz: D4mRrLETpIV239 = D4mRrLETpIV239.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		hNlMiomT7HXSeuOB4L6 = CH86N7xw4cyPt3TlIBJF('dict',D4mRrLETpIV239)
	return hNlMiomT7HXSeuOB4L6
def WLjdqXog7ZQcPSb6(hNlMiomT7HXSeuOB4L6,HARXP1tbN8r6xYlm,OgVDXbCjHIivnWGEdf0Yk6sm):
	pf6P4wckhgTa,zsj5qOxnfaXmdEco3DK29HgYybUCM6,XCapNbgw2xWQ5jRt,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,hhQxqntdaHTLE0V4UMXbOvgepKRG,iIBnwPa3gYp4d,d8kolNVuLsPAjQZ9ROpUHBgix,SFQtU7cnyeo,TV74iI95g1jkpRMyQ = HARXP1tbN8r6xYlm
	if not TsckNQJ6yLiaEeCRml98WwKfVP0dYv: pf6P4wckhgTa,TsckNQJ6yLiaEeCRml98WwKfVP0dYv = 'folder','260'
	s50PpMtH7aZJ2LXIvyFnReKcdzAfWj,hmlzWyBeMwpn6NSgcV0jLo5PQrv74 = [],QigevCplXxbPI1H
	if 'context=' in MYIqLm4Nyhniu6QORWlrp:
		lr9AHtSx0gRGJ2DUVm = sBvufaD6c9YHdOqTjCQ3.findall('context=(\d+)',MYIqLm4Nyhniu6QORWlrp,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if lr9AHtSx0gRGJ2DUVm: hmlzWyBeMwpn6NSgcV0jLo5PQrv74 = str(lr9AHtSx0gRGJ2DUVm[0])
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv=='270':
		hmlzWyBeMwpn6NSgcV0jLo5PQrv74 = SFQtU7cnyeo
		if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()):
			s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('مسح قائمة مفضلة '+hmlzWyBeMwpn6NSgcV0jLo5PQrv74,'RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_DELETELIST'+')'))
	else:
		if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()):
			count = len(hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74])
			if count>1: s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('تحريك 1 للأعلى','RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_UP1)'))
			if count>4: s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('تحريك 4 للأعلى','RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_UP4)'))
			if count>1: s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('تحريك 1 للأسفل','RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_DOWN1)'))
			if count>4: s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('تحريك 4 للأسفل','RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_DOWN4)'))
		for hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in ['1','2','3','4','5']:
			if hmlzWyBeMwpn6NSgcV0jLo5PQrv74 in list(hNlMiomT7HXSeuOB4L6.keys()) and HARXP1tbN8r6xYlm in hNlMiomT7HXSeuOB4L6[hmlzWyBeMwpn6NSgcV0jLo5PQrv74]:
				s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('مسح من مفضلة '+hmlzWyBeMwpn6NSgcV0jLo5PQrv74,'RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_REMOVE1)'))
			else: s50PpMtH7aZJ2LXIvyFnReKcdzAfWj.append(('إضافة لمفضلة '+hmlzWyBeMwpn6NSgcV0jLo5PQrv74,'RunPlugin('+OgVDXbCjHIivnWGEdf0Yk6sm+'&context='+hmlzWyBeMwpn6NSgcV0jLo5PQrv74+'_ADD1)'))
	ZghJLpMVQq = []
	for Ye0MRIdTyABpukLr7,Hmsk0ybpK1B2qS8 in s50PpMtH7aZJ2LXIvyFnReKcdzAfWj:
		Ye0MRIdTyABpukLr7 = r9rhtA5Tek8sIoLfqwF7JcEV+Ye0MRIdTyABpukLr7+jhAlCQ47ZgG
		ZghJLpMVQq.append((Ye0MRIdTyABpukLr7,Hmsk0ybpK1B2qS8,))
	return ZghJLpMVQq
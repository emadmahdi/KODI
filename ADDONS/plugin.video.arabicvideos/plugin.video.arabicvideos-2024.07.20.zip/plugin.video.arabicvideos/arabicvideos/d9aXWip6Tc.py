# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'YOUTUBE'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_YUT_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
def YnMSWTbKj1N8wuRJVF(mode,url,text,type,JJM6TofH4g5n7SRwq):
	if	 mode==140: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==143: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url,type)
	elif mode==144: W9lfsoMawqOzpQcXD = PYViltfWah910OHUZeR(url,text,JJM6TofH4g5n7SRwq)
	elif mode==145: W9lfsoMawqOzpQcXD = yyliWBxLn3IGjr(url)
	elif mode==146: W9lfsoMawqOzpQcXD = xSaHqvJk6n(url)
	elif mode==147: W9lfsoMawqOzpQcXD = VVjWIPZO0rGUT7uwJztF2CYmnBoq()
	elif mode==148: W9lfsoMawqOzpQcXD = O2R9vwCrX4VPNI()
	elif mode==149: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,149,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج',QigevCplXxbPI1H,290)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مواقع اختارها يوتيوب',vxQUXEuH9m+'/feed/guide_builder',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الصفحة الرئيسية',vxQUXEuH9m,144,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المحتوى الرائج',vxQUXEuH9m+'/feed/trending',146)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: قنوات عربية',QigevCplXxbPI1H,147)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: قنوات أجنبية',QigevCplXxbPI1H,148)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: افلام عربية',vxQUXEuH9m+'/results?search_query=فيلم',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: افلام اجنبية',vxQUXEuH9m+'/results?search_query=movie',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسرحيات عربية',vxQUXEuH9m+'/results?search_query=مسرحية',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسلسلات عربية',vxQUXEuH9m+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسلسلات اجنبية',vxQUXEuH9m+'/results?search_query=series&sp=EgIQAw==',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: مسلسلات كارتون',vxQUXEuH9m+'/results?search_query=كارتون&sp=EgIQAw==',144)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث: خطبة المرجعية',vxQUXEuH9m+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def VVjWIPZO0rGUT7uwJztF2CYmnBoq():
	PYViltfWah910OHUZeR(vxQUXEuH9m+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def O2R9vwCrX4VPNI():
	PYViltfWah910OHUZeR(vxQUXEuH9m+'/results?search_query=tv&sp=EgJAAQ==')
	return
def nibvTq2jfRXDM4tYP039S(url,type):
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM([url],PuT0IphGNsketAQ,type,url)
	return
def xSaHqvJk6n(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1,B6xRu5lFyJ,data = TTbkMfupX6an9LBIYriy0G3hW(url)
	rrnG3dERNiZvSjshJQyo = B6xRu5lFyJ['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for GzabfJx3T1 in range(len(rrnG3dERNiZvSjshJQyo)):
		upHdVltvOIDPnN0SefZwGo4gJ9LqsY = rrnG3dERNiZvSjshJQyo[GzabfJx3T1]
		SlrbqDyBJVPRY(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,str(GzabfJx3T1))
	fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	vT6X5goquhV4ncINzyjm3tZlpCw = 0
	for GzabfJx3T1 in range(len(fXAMk8dU34jsIG90FVwWOzmh)):
		upHdVltvOIDPnN0SefZwGo4gJ9LqsY = fXAMk8dU34jsIG90FVwWOzmh[GzabfJx3T1]['itemSectionRenderer']['contents'][0]
		if list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		jgA5IRNqLonwC47,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = XLkKvrOTGz(upHdVltvOIDPnN0SefZwGo4gJ9LqsY)
		if not title:
			vT6X5goquhV4ncINzyjm3tZlpCw += 1
			title = 'فيديوهات رائجة '+str(vT6X5goquhV4ncINzyjm3tZlpCw)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,144,QigevCplXxbPI1H,str(GzabfJx3T1))
	key = sBvufaD6c9YHdOqTjCQ3.findall('"innertubeApiKey":"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Kj0TOU6BmSMlJHZYLd = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	aY63L2NhgvwJIxPAoDG4MKECmZXF1,B6xRu5lFyJ,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = TTbkMfupX6an9LBIYriy0G3hW(Kj0TOU6BmSMlJHZYLd)
	for UbThgLS9PfiE605FJHtqQDBR in range(3,4):
		rrnG3dERNiZvSjshJQyo = B6xRu5lFyJ['items'][UbThgLS9PfiE605FJHtqQDBR]['guideSectionRenderer']['items']
		for GzabfJx3T1 in range(len(rrnG3dERNiZvSjshJQyo)):
			upHdVltvOIDPnN0SefZwGo4gJ9LqsY = rrnG3dERNiZvSjshJQyo[GzabfJx3T1]
			if 'YouTube Premium' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY): continue
			SlrbqDyBJVPRY(upHdVltvOIDPnN0SefZwGo4gJ9LqsY)
	return
def PYViltfWah910OHUZeR(url,data=QigevCplXxbPI1H,index=0):
	global uUTRHgAXJzm7pIDBjNt8
	if not data: data = uUTRHgAXJzm7pIDBjNt8.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_',QigevCplXxbPI1H)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1,B6xRu5lFyJ,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = TTbkMfupX6an9LBIYriy0G3hW(url,data)
	yD6qlPU85KXcOfQzAI3auHEhMvi,ZuMYyjC0J74dQHfcotnXILk = QigevCplXxbPI1H,QigevCplXxbPI1H
	ehgc4bBVGPZOS = sBvufaD6c9YHdOqTjCQ3.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not ehgc4bBVGPZOS: ehgc4bBVGPZOS = sBvufaD6c9YHdOqTjCQ3.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not ehgc4bBVGPZOS: ehgc4bBVGPZOS = sBvufaD6c9YHdOqTjCQ3.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if ehgc4bBVGPZOS:
		yD6qlPU85KXcOfQzAI3auHEhMvi = iVCLpNIM8BQs9PdSgKZvlFeo3a5+ehgc4bBVGPZOS[0][0]+jhAlCQ47ZgG
		RMC6c2kL5hGOnFaIwAyb = ehgc4bBVGPZOS[0][1]
		if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
		if 'list=' in url: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+yD6qlPU85KXcOfQzAI3auHEhMvi,RMC6c2kL5hGOnFaIwAyb,144)
	iGX4SLYQRO1ZrpDIo5 = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	uhHs7ZznOcN5fiSGqayAP = not any(nFdGHjceZzW in url for nFdGHjceZzW in iGX4SLYQRO1ZrpDIo5)
	if uhHs7ZznOcN5fiSGqayAP and yD6qlPU85KXcOfQzAI3auHEhMvi:
		eliZWRgEXtMSxzpAPBUY4rnuq85F = 'البحث'
		YIwQJyV0hAUR1EfKogObLzDMmx = 'قوائم التشغيل'
		kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf = 'الفيديوهات'
		TTVxpNOCgKS7kLseDlI = 'القنوات'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+yD6qlPU85KXcOfQzAI3auHEhMvi,url,9999)
		if '"title":"بحث"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+eliZWRgEXtMSxzpAPBUY4rnuq85F,url,145,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,url+'/playlists',144)
		if '"title":"الفيديوهات"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf,url+'/videos',144)
		if '"title":"القنوات"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+TTVxpNOCgKS7kLseDlI,url+'/channels',144)
		if '"title":"Search"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+eliZWRgEXtMSxzpAPBUY4rnuq85F,url,145,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
		if '"title":"Playlists"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+YIwQJyV0hAUR1EfKogObLzDMmx,url+'/playlists',144)
		if '"title":"Videos"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+kIpEHT7mMO5CdAhgoaGxwLWcjBVlJf,url+'/videos',144)
		if '"title":"Channels"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+TTVxpNOCgKS7kLseDlI,url+'/channels',144)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	if 'search_query' in url:
		rrnG3dERNiZvSjshJQyo = B6xRu5lFyJ['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		wwuAMFekVatdD4xoNgB = 0
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(rrnG3dERNiZvSjshJQyo)):
			if 'itemSectionRenderer' in list(rrnG3dERNiZvSjshJQyo[A5SjhJUg37pNiMC4Eot6lOF].keys()):
				QQw0INAzVOH = rrnG3dERNiZvSjshJQyo[A5SjhJUg37pNiMC4Eot6lOF]['itemSectionRenderer']
				iz7sjYCJZp1O2g09r6HuloRnaqEKG3 = len(str(QQw0INAzVOH))
				if iz7sjYCJZp1O2g09r6HuloRnaqEKG3>wwuAMFekVatdD4xoNgB:
					wwuAMFekVatdD4xoNgB = iz7sjYCJZp1O2g09r6HuloRnaqEKG3
					ZuMYyjC0J74dQHfcotnXILk = QQw0INAzVOH
		if wwuAMFekVatdD4xoNgB==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==vxQUXEuH9m:
		kaP2Oj14TDlM3v0cRnKz6WN = []
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		WqmyTgJ03QaA957C8,ZuMYyjC0J74dQHfcotnXILk = mXE6e8awT9Zxjs0yv(B6xRu5lFyJ,QigevCplXxbPI1H,kaP2Oj14TDlM3v0cRnKz6WN)
	if not ZuMYyjC0J74dQHfcotnXILk:
		try:
			rrnG3dERNiZvSjshJQyo = B6xRu5lFyJ['contents']['twoColumnBrowseResultsRenderer']['tabs']
			Zn2yQOf6lWMt9pUeuvcCR51JNIwiB = '/videos' in url or '/playlists' in url or '/channels' in url
			ppk7bU0Pyx = '"title":"الفيديوهات"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 or '"title":"قوائم التشغيل"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 or '"title":"القنوات"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1
			TTrdaKDsWpPHCl = '"title":"Videos"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 or '"title":"Playlists"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 or '"title":"Channels"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1
			if Zn2yQOf6lWMt9pUeuvcCR51JNIwiB and (ppk7bU0Pyx or TTrdaKDsWpPHCl):
				for GzabfJx3T1 in range(len(rrnG3dERNiZvSjshJQyo)):
					if 'tabRenderer' not in list(rrnG3dERNiZvSjshJQyo[GzabfJx3T1].keys()): continue
					fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[GzabfJx3T1]['tabRenderer']
					try: waEHiRnFbDMzV8AjJeg = fXAMk8dU34jsIG90FVwWOzmh['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][GzabfJx3T1]
					except: waEHiRnFbDMzV8AjJeg = fXAMk8dU34jsIG90FVwWOzmh
					try: RMC6c2kL5hGOnFaIwAyb = waEHiRnFbDMzV8AjJeg['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in RMC6c2kL5hGOnFaIwAyb	and '/videos'		in url: fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[GzabfJx3T1] ; break
					elif '/playlists'	in RMC6c2kL5hGOnFaIwAyb	and '/playlists'	in url: fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[GzabfJx3T1] ; break
					elif '/channels'	in RMC6c2kL5hGOnFaIwAyb	and '/channels'		in url: fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[GzabfJx3T1] ; break
					else: fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[0]
			elif 'bp=' in url: fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[index]
			else: fXAMk8dU34jsIG90FVwWOzmh = rrnG3dERNiZvSjshJQyo[0]
			ZuMYyjC0J74dQHfcotnXILk = fXAMk8dU34jsIG90FVwWOzmh['tabRenderer']['content']
		except: pass
	if not ZuMYyjC0J74dQHfcotnXILk: return
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['sectionListRenderer']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['richGridRenderer']['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff['contents']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("ff")
	XFbsIRACfWnrEvU1VOSmpcDZTy03 = Sk3BJ4bvyposwt0mFuGnqZHg(u'كل قوائم التشغيل')
	emIQDf0T17gon4E = Sk3BJ4bvyposwt0mFuGnqZHg(u'كل الفيديوهات')
	PVy6XoE4Jfpwms1LGiW = Sk3BJ4bvyposwt0mFuGnqZHg(u'كل القنوات')
	f4dsNBt6K9GjF3gxOAnEQS2wLYrvu = [XFbsIRACfWnrEvU1VOSmpcDZTy03,emIQDf0T17gon4E,PVy6XoE4Jfpwms1LGiW,'All playlists','All videos','All channels']
	SekiAzUJEdMZ3pruC,waEHiRnFbDMzV8AjJeg = mXE6e8awT9Zxjs0yv(ZuMYyjC0J74dQHfcotnXILk,index,kaP2Oj14TDlM3v0cRnKz6WN)
	if 'list' in str(type(waEHiRnFbDMzV8AjJeg)) and any(nFdGHjceZzW in str(waEHiRnFbDMzV8AjJeg[0]) for nFdGHjceZzW in f4dsNBt6K9GjF3gxOAnEQS2wLYrvu): del waEHiRnFbDMzV8AjJeg[0]
	for eoIWZ4mSdEOl in range(len(waEHiRnFbDMzV8AjJeg)):
		kaP2Oj14TDlM3v0cRnKz6WN = []
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['itemSectionRenderer']['header']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['horizontalCardListRenderer']['header']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['richSectionRenderer']['content']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['richItemRenderer']['content']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]['gameCardRenderer']['game']")
		kaP2Oj14TDlM3v0cRnKz6WN.append("gg[index2]")
		WqmyTgJ03QaA957C8,upHdVltvOIDPnN0SefZwGo4gJ9LqsY = mXE6e8awT9Zxjs0yv(waEHiRnFbDMzV8AjJeg,eoIWZ4mSdEOl,kaP2Oj14TDlM3v0cRnKz6WN)
		SlrbqDyBJVPRY(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url,str(eoIWZ4mSdEOl))
		if WqmyTgJ03QaA957C8=='4':
			try:
				lceLzPCiaf12B49UAhWM = upHdVltvOIDPnN0SefZwGo4gJ9LqsY['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for YiIRAkKdZEs in range(len(lceLzPCiaf12B49UAhWM)):
					R8snCkJV7Gm5T9XDlKAhgL = lceLzPCiaf12B49UAhWM[YiIRAkKdZEs]
					SlrbqDyBJVPRY(R8snCkJV7Gm5T9XDlKAhgL)
			except: pass
	ZNvUplCHSuj3cOQaT4bwDgoMk8rI = False
	if 'view=' not in url and SekiAzUJEdMZ3pruC=='8': ZNvUplCHSuj3cOQaT4bwDgoMk8rI = True
	if ':::' in tNQDMKVydhBqgaUvJ7oeAkTHxsL1: BrbMc7vuG6PW5AR8qhsHpE4X,key,XOAf9DpL85IkzZHK4gcF6leU7i,XQTUfehBIlNCSqsmw,F01WAKej2RtVrpXQvi,kkWeUiTQDrVBLzNZHsc7IApG8aRv = tNQDMKVydhBqgaUvJ7oeAkTHxsL1.split(':::')
	else: BrbMc7vuG6PW5AR8qhsHpE4X,key,XOAf9DpL85IkzZHK4gcF6leU7i,XQTUfehBIlNCSqsmw,F01WAKej2RtVrpXQvi,kkWeUiTQDrVBLzNZHsc7IApG8aRv = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	Kj0TOU6BmSMlJHZYLd,G1kbAhTnqMwIjiVv3Cc = QigevCplXxbPI1H,QigevCplXxbPI1H
	if lc0jJQ4zboeDI3tqTrpvm5gZO:
		JBY7f2iCAtsLWmauU = str(lc0jJQ4zboeDI3tqTrpvm5gZO[-1][1])
		if   iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'CHNL' in JBY7f2iCAtsLWmauU: G1kbAhTnqMwIjiVv3Cc = 'CHANNELS'
		elif iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'USER' in JBY7f2iCAtsLWmauU: G1kbAhTnqMwIjiVv3Cc = 'CHANNELS'
		elif iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'LIST' in JBY7f2iCAtsLWmauU: G1kbAhTnqMwIjiVv3Cc = 'PLAYLISTS'
	if '"continuations"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 and '&list=' not in url and not ZNvUplCHSuj3cOQaT4bwDgoMk8rI and 'shelf_id' not in url:
		Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/browse_ajax?ctoken='+XOAf9DpL85IkzZHK4gcF6leU7i
	elif '"token"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/youtubei/v1/search?key='+key
	elif '"token"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 and 'bp=' not in url:
		Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/youtubei/v1/browse?key='+key
	if Kj0TOU6BmSMlJHZYLd: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة أخرى',Kj0TOU6BmSMlJHZYLd,144,G1kbAhTnqMwIjiVv3Cc,QigevCplXxbPI1H,tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
	return
def mXE6e8awT9Zxjs0yv(KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn,LgO5HKyr06T7iupoDM):
	B6xRu5lFyJ = KJLgseu6fmCwXoHEOy7i
	ZuMYyjC0J74dQHfcotnXILk,index = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	waEHiRnFbDMzV8AjJeg,eoIWZ4mSdEOl = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	upHdVltvOIDPnN0SefZwGo4gJ9LqsY,F7dbU89JEhDGn3pILeWjiqCxtr2H6 = KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn
	count = len(LgO5HKyr06T7iupoDM)
	for GzabfJx3T1 in range(count):
		try:
			BBLvPZi6eo9DO = eval(LgO5HKyr06T7iupoDM[GzabfJx3T1])
			return str(GzabfJx3T1+1),BBLvPZi6eo9DO
		except: pass
	return QigevCplXxbPI1H,QigevCplXxbPI1H
def XLkKvrOTGz(upHdVltvOIDPnN0SefZwGo4gJ9LqsY):
	try: vjcyxK0CoYD = list(upHdVltvOIDPnN0SefZwGo4gJ9LqsY.keys())[0]
	except: return False,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	jgA5IRNqLonwC47,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = False,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	F7dbU89JEhDGn3pILeWjiqCxtr2H6 = upHdVltvOIDPnN0SefZwGo4gJ9LqsY[vjcyxK0CoYD]
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['unplayableText']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['formattedTitle']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['title']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['title']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['text']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['text']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['title']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['title']")
	WqmyTgJ03QaA957C8,title = mXE6e8awT9Zxjs0yv(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,F7dbU89JEhDGn3pILeWjiqCxtr2H6,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	WqmyTgJ03QaA957C8,RMC6c2kL5hGOnFaIwAyb = mXE6e8awT9Zxjs0yv(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,F7dbU89JEhDGn3pILeWjiqCxtr2H6,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['thumbnail']['thumbnails'][0]['url']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	WqmyTgJ03QaA957C8,cXu4fN1moCypJqb72OZvd = mXE6e8awT9Zxjs0yv(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,F7dbU89JEhDGn3pILeWjiqCxtr2H6,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['videoCount']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['videoCountText']['runs'][0]['text']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	WqmyTgJ03QaA957C8,count = mXE6e8awT9Zxjs0yv(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,F7dbU89JEhDGn3pILeWjiqCxtr2H6,kaP2Oj14TDlM3v0cRnKz6WN)
	kaP2Oj14TDlM3v0cRnKz6WN = []
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['lengthText']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	kaP2Oj14TDlM3v0cRnKz6WN.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	WqmyTgJ03QaA957C8,ThO0AMm4jUGP9yr = mXE6e8awT9Zxjs0yv(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,F7dbU89JEhDGn3pILeWjiqCxtr2H6,kaP2Oj14TDlM3v0cRnKz6WN)
	if 'LIVE' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb = QigevCplXxbPI1H,'LIVE:  '
	if 'مباشر' in ThO0AMm4jUGP9yr: ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb = QigevCplXxbPI1H,'LIVE:  '
	if 'badges' in list(F7dbU89JEhDGn3pILeWjiqCxtr2H6.keys()):
		b6pZVEYMyaj0zdDCrNHk4nwQWmSho9 = str(F7dbU89JEhDGn3pILeWjiqCxtr2H6['badges'])
		if 'Free with Ads' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$:'
		if 'LIVE NOW' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: uRZUlrefpBCJmI0h4xEb = 'LIVE:  '
		if 'Buy' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9 or 'Rent' in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$$:'
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'مباشر') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: uRZUlrefpBCJmI0h4xEb = 'LIVE:  '
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'شراء') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$$:'
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'استئجار') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$$:'
		if Sk3BJ4bvyposwt0mFuGnqZHg(u'إعلانات') in b6pZVEYMyaj0zdDCrNHk4nwQWmSho9: mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = '$:'
	RMC6c2kL5hGOnFaIwAyb = arFSQucmG9HxDody67JCI8pBMk4L(RMC6c2kL5hGOnFaIwAyb)
	if RMC6c2kL5hGOnFaIwAyb and 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
	cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.split('?')[0]
	if  cXu4fN1moCypJqb72OZvd and 'http' not in cXu4fN1moCypJqb72OZvd: cXu4fN1moCypJqb72OZvd = 'https:'+cXu4fN1moCypJqb72OZvd
	title = arFSQucmG9HxDody67JCI8pBMk4L(title)
	if mnriNIfKFPuaYTDAEcWMwGS65Lvb1: title = mnriNIfKFPuaYTDAEcWMwGS65Lvb1+eZXCHufT9YW4bRErSBOLmI+title
	ThO0AMm4jUGP9yr = ThO0AMm4jUGP9yr.replace(',',QigevCplXxbPI1H)
	count = count.replace(',',QigevCplXxbPI1H)
	count = sBvufaD6c9YHdOqTjCQ3.findall('\d+',count)
	if count: count = count[0]
	else: count = QigevCplXxbPI1H
	return True,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1
def SlrbqDyBJVPRY(upHdVltvOIDPnN0SefZwGo4gJ9LqsY,url=QigevCplXxbPI1H,index=QigevCplXxbPI1H):
	jgA5IRNqLonwC47,title,RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,count,ThO0AMm4jUGP9yr,uRZUlrefpBCJmI0h4xEb,mnriNIfKFPuaYTDAEcWMwGS65Lvb1 = XLkKvrOTGz(upHdVltvOIDPnN0SefZwGo4gJ9LqsY)
	if not jgA5IRNqLonwC47: return
	elif 'continuationItemRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY): return
	elif 'searchPyvRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY): return
	elif not RMC6c2kL5hGOnFaIwAyb and 'search_query' in url: return
	elif title and not RMC6c2kL5hGOnFaIwAyb and ('search_query' in url or 'horizontalMovieListRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY) or url==vxQUXEuH9m):
		title = '=== '+title+' ==='
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,9999)
	elif title and 'messageRenderer' in str(upHdVltvOIDPnN0SefZwGo4gJ9LqsY):
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,QigevCplXxbPI1H,9999)
	elif '/feed/trending' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,index)
	elif not title: return
	elif uRZUlrefpBCJmI0h4xEb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('live',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+uRZUlrefpBCJmI0h4xEb+title,RMC6c2kL5hGOnFaIwAyb,143,cXu4fN1moCypJqb72OZvd)
	elif 'watch?v=' in RMC6c2kL5hGOnFaIwAyb or '/shorts/' in RMC6c2kL5hGOnFaIwAyb:
		if '&list=' in RMC6c2kL5hGOnFaIwAyb and 'index=' not in RMC6c2kL5hGOnFaIwAyb:
			NhOoFyHwcx9IDAXbY0UmPEnT5suZV = RMC6c2kL5hGOnFaIwAyb.split('&list=',1)[1]
			RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/playlist?list='+NhOoFyHwcx9IDAXbY0UmPEnT5suZV
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'LIST'+count+':  '+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd)
		else:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.split('&list=',1)[0]
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,143,cXu4fN1moCypJqb72OZvd,ThO0AMm4jUGP9yr)
	else:
		type = QigevCplXxbPI1H
		if not RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = url
		elif not any(nFdGHjceZzW in RMC6c2kL5hGOnFaIwAyb for nFdGHjceZzW in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in RMC6c2kL5hGOnFaIwAyb or '/c/' in RMC6c2kL5hGOnFaIwAyb: type = 'CHNL'+count+':  '
			if '/user/' in RMC6c2kL5hGOnFaIwAyb: type = 'USER'+count+':  '
			index,u6YPVwkIQbmdg2 = QigevCplXxbPI1H,QigevCplXxbPI1H
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+type+title,RMC6c2kL5hGOnFaIwAyb,144,cXu4fN1moCypJqb72OZvd,index)
	return
def TTbkMfupX6an9LBIYriy0G3hW(url,data=QigevCplXxbPI1H,x9Ahuz3FVWmJDaNp5=QigevCplXxbPI1H):
	global uUTRHgAXJzm7pIDBjNt8
	if not data: data = uUTRHgAXJzm7pIDBjNt8.getSetting('av.youtube.data')
	if x9Ahuz3FVWmJDaNp5==QigevCplXxbPI1H: x9Ahuz3FVWmJDaNp5 = 'ytInitialData'
	lfPqTpgMXhVcd = eUBL1rOR4ZfndJAWPsoN6pybT0()
	T24Te3uDwBS5vLgUEAhF1O = {'User-Agent':lfPqTpgMXhVcd,'Cookie':'PREF=hl=ar'}
	if ':::' in data: BrbMc7vuG6PW5AR8qhsHpE4X,key,XOAf9DpL85IkzZHK4gcF6leU7i,XQTUfehBIlNCSqsmw,F01WAKej2RtVrpXQvi,kkWeUiTQDrVBLzNZHsc7IApG8aRv = data.split(':::')
	else: BrbMc7vuG6PW5AR8qhsHpE4X,key,XOAf9DpL85IkzZHK4gcF6leU7i,XQTUfehBIlNCSqsmw,F01WAKej2RtVrpXQvi,kkWeUiTQDrVBLzNZHsc7IApG8aRv = QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	if 'guide?key=' in url:
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = {}
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":XQTUfehBIlNCSqsmw}}
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = str(tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',url,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and BrbMc7vuG6PW5AR8qhsHpE4X:
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = {'continuation':F01WAKej2RtVrpXQvi}
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1['context'] = {"client":{"visitorData":BrbMc7vuG6PW5AR8qhsHpE4X,"clientName":"WEB","clientVersion":XQTUfehBIlNCSqsmw}}
		tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = str(tNQDMKVydhBqgaUvJ7oeAkTHxsL1)
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'POST',url,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and kkWeUiTQDrVBLzNZHsc7IApG8aRv:
		T24Te3uDwBS5vLgUEAhF1O.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':XQTUfehBIlNCSqsmw})
		T24Te3uDwBS5vLgUEAhF1O.update({'Cookie':'VISITOR_INFO1_LIVE='+kkWeUiTQDrVBLzNZHsc7IApG8aRv})
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'YOUTUBE-GET_PAGE_DATA-4th')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	KWd8gTIVsbfk31S6C2zeQAaN = sBvufaD6c9YHdOqTjCQ3.findall('"innertubeApiKey".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if KWd8gTIVsbfk31S6C2zeQAaN: key = KWd8gTIVsbfk31S6C2zeQAaN[0]
	KWd8gTIVsbfk31S6C2zeQAaN = sBvufaD6c9YHdOqTjCQ3.findall('"cver".*?"value".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if KWd8gTIVsbfk31S6C2zeQAaN: XQTUfehBIlNCSqsmw = KWd8gTIVsbfk31S6C2zeQAaN[0]
	KWd8gTIVsbfk31S6C2zeQAaN = sBvufaD6c9YHdOqTjCQ3.findall('"token".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if KWd8gTIVsbfk31S6C2zeQAaN: F01WAKej2RtVrpXQvi = KWd8gTIVsbfk31S6C2zeQAaN[0]
	KWd8gTIVsbfk31S6C2zeQAaN = sBvufaD6c9YHdOqTjCQ3.findall('"visitorData".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if KWd8gTIVsbfk31S6C2zeQAaN: BrbMc7vuG6PW5AR8qhsHpE4X = KWd8gTIVsbfk31S6C2zeQAaN[0]
	KWd8gTIVsbfk31S6C2zeQAaN = sBvufaD6c9YHdOqTjCQ3.findall('"continuation".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL|sBvufaD6c9YHdOqTjCQ3.I)
	if KWd8gTIVsbfk31S6C2zeQAaN: XOAf9DpL85IkzZHK4gcF6leU7i = KWd8gTIVsbfk31S6C2zeQAaN[0]
	cookies = JJrhP4C6osGDFEKVSRBvX.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): kkWeUiTQDrVBLzNZHsc7IApG8aRv = cookies['VISITOR_INFO1_LIVE']
	data = BrbMc7vuG6PW5AR8qhsHpE4X+':::'+key+':::'+XOAf9DpL85IkzZHK4gcF6leU7i+':::'+XQTUfehBIlNCSqsmw+':::'+F01WAKej2RtVrpXQvi+':::'+kkWeUiTQDrVBLzNZHsc7IApG8aRv
	if x9Ahuz3FVWmJDaNp5=='ytInitialData' and 'ytInitialData' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		f0HesnbtUICXMwg71RNxJkj = sBvufaD6c9YHdOqTjCQ3.findall('window\["ytInitialData"\] = ({.*?});',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not f0HesnbtUICXMwg71RNxJkj: f0HesnbtUICXMwg71RNxJkj = sBvufaD6c9YHdOqTjCQ3.findall('var ytInitialData = ({.*?});',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ddSFGVHhyYW1Uwmu27c5n3f0 = CH86N7xw4cyPt3TlIBJF('str',f0HesnbtUICXMwg71RNxJkj[0])
	elif x9Ahuz3FVWmJDaNp5=='ytInitialGuideData' and 'ytInitialGuideData' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		f0HesnbtUICXMwg71RNxJkj = sBvufaD6c9YHdOqTjCQ3.findall('var ytInitialGuideData = ({.*?});',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		ddSFGVHhyYW1Uwmu27c5n3f0 = CH86N7xw4cyPt3TlIBJF('str',f0HesnbtUICXMwg71RNxJkj[0])
	elif '</script>' not in aY63L2NhgvwJIxPAoDG4MKECmZXF1: ddSFGVHhyYW1Uwmu27c5n3f0 = CH86N7xw4cyPt3TlIBJF('str',aY63L2NhgvwJIxPAoDG4MKECmZXF1)
	else: ddSFGVHhyYW1Uwmu27c5n3f0 = QigevCplXxbPI1H
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.youtube.data',data)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1,ddSFGVHhyYW1Uwmu27c5n3f0,data
def yyliWBxLn3IGjr(url):
	search = XAfEvmh95VkgurjdiJ()
	if not search: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	Kj0TOU6BmSMlJHZYLd = url+'/search?query='+search
	PYViltfWah910OHUZeR(Kj0TOU6BmSMlJHZYLd)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search:
		search = XAfEvmh95VkgurjdiJ()
		if not search: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in iBux5zA0swygKtRlDCTH: Ah0IaXwQtLdvi1KqepTxl = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in iBux5zA0swygKtRlDCTH: Ah0IaXwQtLdvi1KqepTxl = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in iBux5zA0swygKtRlDCTH: Ah0IaXwQtLdvi1KqepTxl = '&sp=EgIQAg%253D%253D'
		NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd+Ah0IaXwQtLdvi1KqepTxl
	else:
		FGB46mLk5PhAR2,t4s6NDyvabFYZrG3AqgPuwndeEm,YIwQJyV0hAUR1EfKogObLzDMmx = [],[],QigevCplXxbPI1H
		pVBRbowMOytmDnqCufzhAk8Uxr9cN = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		Sb2w4FnDy0gxMYEAILCofzPvtk = [QigevCplXxbPI1H,'&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		da7w53zb6kXqj4 = zYWJO03iISD('موقع يوتيوب - اختر الترتيب',pVBRbowMOytmDnqCufzhAk8Uxr9cN)
		if da7w53zb6kXqj4 == -1: return
		wU4Gpn97WR2aXe53dF8vj = Sb2w4FnDy0gxMYEAILCofzPvtk[da7w53zb6kXqj4]
		aY63L2NhgvwJIxPAoDG4MKECmZXF1,ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm,data = TTbkMfupX6an9LBIYriy0G3hW(Kj0TOU6BmSMlJHZYLd+wU4Gpn97WR2aXe53dF8vj)
		if ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm:
			lWpU8hve642Qdm9BJoKjVrIf = ePKDlsnVjL9ZHr7Ry1NzFiXdftpWm['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for EgbAKlvHdGzt6UrmZeI7MyxW in range(len(lWpU8hve642Qdm9BJoKjVrIf)):
				group = lWpU8hve642Qdm9BJoKjVrIf[EgbAKlvHdGzt6UrmZeI7MyxW]['searchFilterGroupRenderer']['filters']
				for es4CZNxAmEz3B67 in range(len(group)):
					F7dbU89JEhDGn3pILeWjiqCxtr2H6 = group[es4CZNxAmEz3B67]['searchFilterRenderer']
					if 'navigationEndpoint' in list(F7dbU89JEhDGn3pILeWjiqCxtr2H6.keys()):
						RMC6c2kL5hGOnFaIwAyb = F7dbU89JEhDGn3pILeWjiqCxtr2H6['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('\u0026','&')
						title = F7dbU89JEhDGn3pILeWjiqCxtr2H6['tooltip']
						title = title.replace('البحث عن ',QigevCplXxbPI1H)
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							YIwQJyV0hAUR1EfKogObLzDMmx = title
							Wdek0SptsHCKog19OBJDTRAX7m = RMC6c2kL5hGOnFaIwAyb
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ',QigevCplXxbPI1H)
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							YIwQJyV0hAUR1EfKogObLzDMmx = title
							Wdek0SptsHCKog19OBJDTRAX7m = RMC6c2kL5hGOnFaIwAyb
						if 'Sort by' in title: continue
						FGB46mLk5PhAR2.append(arFSQucmG9HxDody67JCI8pBMk4L(title))
						t4s6NDyvabFYZrG3AqgPuwndeEm.append(RMC6c2kL5hGOnFaIwAyb)
		if not YIwQJyV0hAUR1EfKogObLzDMmx: c9HDFTKdLpJhZMIQN0nymg = QigevCplXxbPI1H
		else:
			FGB46mLk5PhAR2 = ['بدون فلتر',YIwQJyV0hAUR1EfKogObLzDMmx]+FGB46mLk5PhAR2
			t4s6NDyvabFYZrG3AqgPuwndeEm = [QigevCplXxbPI1H,Wdek0SptsHCKog19OBJDTRAX7m]+t4s6NDyvabFYZrG3AqgPuwndeEm
			nFwGpZdzDsfP4 = zYWJO03iISD('موقع يوتيوب - اختر الفلتر',FGB46mLk5PhAR2)
			if nFwGpZdzDsfP4 == -1: return
			c9HDFTKdLpJhZMIQN0nymg = t4s6NDyvabFYZrG3AqgPuwndeEm[nFwGpZdzDsfP4]
		if c9HDFTKdLpJhZMIQN0nymg: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = vxQUXEuH9m+c9HDFTKdLpJhZMIQN0nymg
		elif wU4Gpn97WR2aXe53dF8vj: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd+wU4Gpn97WR2aXe53dF8vj
		else: NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd
	PYViltfWah910OHUZeR(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
	return
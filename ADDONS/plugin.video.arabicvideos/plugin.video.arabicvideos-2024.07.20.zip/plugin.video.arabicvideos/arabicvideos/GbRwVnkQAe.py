# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'ALFATIMI'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_FTM_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
jqb3y74B0Fi9tUgPQGNuV = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
ggKnGZo9IBSQJaEkLTbePcuDhX = ['3030','628']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==60: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==61: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==62: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==63: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==64: W9lfsoMawqOzpQcXD = BBrsw5RjCTFq2OibS1L3(text)
	elif mode==69: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,69,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'ما يتم مشاهدته الان',vxQUXEuH9m,64,QigevCplXxbPI1H,QigevCplXxbPI1H,'recent_viewed_vids')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الاكثر مشاهدة',vxQUXEuH9m,64,QigevCplXxbPI1H,QigevCplXxbPI1H,'most_viewed_vids')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'اضيفت مؤخرا',vxQUXEuH9m,64,QigevCplXxbPI1H,QigevCplXxbPI1H,'recently_added_vids')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فيديو عشوائي',vxQUXEuH9m,64,QigevCplXxbPI1H,QigevCplXxbPI1H,'random_vids')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'افلام ومسلسلات',vxQUXEuH9m,61,QigevCplXxbPI1H,QigevCplXxbPI1H,'-1')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'البرامج الدينية',vxQUXEuH9m,61,QigevCplXxbPI1H,QigevCplXxbPI1H,'-2')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'English Videos',vxQUXEuH9m,61,QigevCplXxbPI1H,QigevCplXxbPI1H,'-3')
	return QigevCplXxbPI1H
def ddbEXhWzOnIaR(url,opIyA9rsJMXPL1k):
	WD7JIEFhAfP3O0 = QigevCplXxbPI1H
	if opIyA9rsJMXPL1k not in ['-1','-2','-3']: WD7JIEFhAfP3O0 = '?cat='+opIyA9rsJMXPL1k
	Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m+'/menu_level.php'+WD7JIEFhAfP3O0
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'ALFATIMI-TITLES-1st')
	items = sBvufaD6c9YHdOqTjCQ3.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	czGRe329KVvjMY68E10N4ZWH,ARiQLVuwZY2nqCB5tv9mbe31f6 = False,False
	for RMC6c2kL5hGOnFaIwAyb,title,count in items:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
		WD7JIEFhAfP3O0 = sBvufaD6c9YHdOqTjCQ3.findall('cat=(.*?)&',RMC6c2kL5hGOnFaIwAyb,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
		if opIyA9rsJMXPL1k==WD7JIEFhAfP3O0: czGRe329KVvjMY68E10N4ZWH = True
		elif czGRe329KVvjMY68E10N4ZWH 	or (opIyA9rsJMXPL1k=='-1' and WD7JIEFhAfP3O0 in jqb3y74B0Fi9tUgPQGNuV)  						or (opIyA9rsJMXPL1k=='-2' and WD7JIEFhAfP3O0 not in ggKnGZo9IBSQJaEkLTbePcuDhX and WD7JIEFhAfP3O0 not in jqb3y74B0Fi9tUgPQGNuV)  						or (opIyA9rsJMXPL1k=='-3' and WD7JIEFhAfP3O0 in ggKnGZo9IBSQJaEkLTbePcuDhX):
							if count=='1': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,63)
							else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,61,QigevCplXxbPI1H,QigevCplXxbPI1H,WD7JIEFhAfP3O0)
							ARiQLVuwZY2nqCB5tv9mbe31f6 = True
	if not ARiQLVuwZY2nqCB5tv9mbe31f6: oB2rmVgqUND(url)
	return
def oB2rmVgqUND(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,QigevCplXxbPI1H,True,'ALFATIMI-EPISODES-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('pagination(.*?)id="footer',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	RMC6c2kL5hGOnFaIwAyb = QigevCplXxbPI1H
	for cXu4fN1moCypJqb72OZvd,title,RMC6c2kL5hGOnFaIwAyb in items:
		title = title.replace('Add',QigevCplXxbPI1H).replace('to Quicklist',QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
		if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,63,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv=sBvufaD6c9YHdOqTjCQ3.findall('(.*?)div',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY=fwSu6JsQZpEiv[0]
	LKzFWsmvjUVGMDBapflx6H4NY=sBvufaD6c9YHdOqTjCQ3.findall('pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	items=sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	Kj0TOU6BmSMlJHZYLd = url.split('?')[0]
	for RMC6c2kL5hGOnFaIwAyb,qqFGtbgNUTj1Jr6ze3PlSEnIx0O in items:
		RMC6c2kL5hGOnFaIwAyb = Kj0TOU6BmSMlJHZYLd + RMC6c2kL5hGOnFaIwAyb
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(qqFGtbgNUTj1Jr6ze3PlSEnIx0O)
		title = 'صفحة ' + title
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,62)
	return RMC6c2kL5hGOnFaIwAyb
def nibvTq2jfRXDM4tYP039S(url):
	if 'videos.php' in url: url = oB2rmVgqUND(url)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,QigevCplXxbPI1H,True,'ALFATIMI-PLAY-1st')
	items = sBvufaD6c9YHdOqTjCQ3.findall('playlistfile:"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	B9BaTCd86Iwz1e3sRMXZylKpcHU(url,PuT0IphGNsketAQ,'video')
	return
def BBrsw5RjCTFq2OibS1L3(opIyA9rsJMXPL1k):
	A1AqSc2LNwW0ETgyaRl9 = { 'mode' : opIyA9rsJMXPL1k }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = q8KvkirVNMoRIB5eJ(A1AqSc2LNwW0ETgyaRl9)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(vjPhaUE819opVQg7uRk4wG6cYBOTd,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = 'http:'+RMC6c2kL5hGOnFaIwAyb
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,63,cXu4fN1moCypJqb72OZvd)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m + '/search_result.php?query=' + VIo6FYRkx0MLP4wufEGsgnz9
	oB2rmVgqUND(url)
	return
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'MOVIZLAND'
headers = { 'User-Agent' : QigevCplXxbPI1H }
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_MVZ_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
PTKgtGhwsW51oZ3uQImn6Czd0ERNyb = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][1]
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==180: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==181: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==182: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==183: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==188: W9lfsoMawqOzpQcXD = ssJie8zwRB5YMlx()
	elif mode==189: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def ssJie8zwRB5YMlx():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج',message)
	return
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,189,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بوكس اوفيس موفيز لاند',vxQUXEuH9m,181,QigevCplXxbPI1H,QigevCplXxbPI1H,'box-office')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أحدث الافلام',vxQUXEuH9m,181,QigevCplXxbPI1H,QigevCplXxbPI1H,'latest-movies')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'تليفزيون موفيز لاند',vxQUXEuH9m,181,QigevCplXxbPI1H,QigevCplXxbPI1H,'tv')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الاكثر مشاهدة',vxQUXEuH9m,181,QigevCplXxbPI1H,QigevCplXxbPI1H,'top-views')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أقوى الافلام الحالية',vxQUXEuH9m,181,QigevCplXxbPI1H,QigevCplXxbPI1H,'top-movies')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-MENU-1st')
	items = sBvufaD6c9YHdOqTjCQ3.findall('<h2><a href="(.*?)".*?">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,181)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,type=QigevCplXxbPI1H):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': LKzFWsmvjUVGMDBapflx6H4NY = sBvufaD6c9YHdOqTjCQ3.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	elif type=='box-office': LKzFWsmvjUVGMDBapflx6H4NY = sBvufaD6c9YHdOqTjCQ3.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	elif type=='top-movies': LKzFWsmvjUVGMDBapflx6H4NY = sBvufaD6c9YHdOqTjCQ3.findall('btn-2-overlay(.*?)<style>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	elif type=='top-views': LKzFWsmvjUVGMDBapflx6H4NY = sBvufaD6c9YHdOqTjCQ3.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	elif type=='tv': LKzFWsmvjUVGMDBapflx6H4NY = sBvufaD6c9YHdOqTjCQ3.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	else: LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
	if type in ['top-views','top-movies']:
		items = sBvufaD6c9YHdOqTjCQ3.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else: items = sBvufaD6c9YHdOqTjCQ3.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	LVyczatgBIT = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for cXu4fN1moCypJqb72OZvd,KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn,iXlCG2W7y3KdELAh in items:
		if type in ['top-views','top-movies']:
			cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,Wdek0SptsHCKog19OBJDTRAX7m,title = cXu4fN1moCypJqb72OZvd,KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn,iXlCG2W7y3KdELAh
		else: cXu4fN1moCypJqb72OZvd,title,RMC6c2kL5hGOnFaIwAyb,Wdek0SptsHCKog19OBJDTRAX7m = cXu4fN1moCypJqb72OZvd,KJLgseu6fmCwXoHEOy7i,xJG92hkptaqRIiDMKBmPwXr1uAHWzn,iXlCG2W7y3KdELAh
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb)
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace('?view=true',QigevCplXxbPI1H)
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',QigevCplXxbPI1H).replace('بجوده ',QigevCplXxbPI1H)
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if 'الحلقة' in title or 'الحلقه' in title:
			V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|الحلقه) \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if V1nZX7O5WwEq8HmvkY:
				title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0][0]
				if title not in wibHRCAFtsupIjx4ZTELeM:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,183,cXu4fN1moCypJqb72OZvd)
					wibHRCAFtsupIjx4ZTELeM.append(title)
		elif any(nFdGHjceZzW in title for nFdGHjceZzW in LVyczatgBIT):
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb + '?servers=' + Wdek0SptsHCKog19OBJDTRAX7m
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,182,cXu4fN1moCypJqb72OZvd)
		else:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb + '?servers=' + Wdek0SptsHCKog19OBJDTRAX7m
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,183,cXu4fN1moCypJqb72OZvd)
	if type==QigevCplXxbPI1H:
		items = sBvufaD6c9YHdOqTjCQ3.findall('\n<li><a href="(.*?)".*?>(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			title = title.replace('الصفحة ',QigevCplXxbPI1H)
			if title!=QigevCplXxbPI1H:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,181)
	return
def oB2rmVgqUND(url):
	Kj0TOU6BmSMlJHZYLd = url.split('?servers=')[0]
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-EPISODES-1st')
	LKzFWsmvjUVGMDBapflx6H4NY = sBvufaD6c9YHdOqTjCQ3.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	title,tX1WYGPmux,cXu4fN1moCypJqb72OZvd = LKzFWsmvjUVGMDBapflx6H4NY[0]
	name = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="episodesNumbers"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb in items:
			RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb)
			title = sBvufaD6c9YHdOqTjCQ3.findall('(الحلقة|الحلقه)-([0-9]+)',RMC6c2kL5hGOnFaIwAyb.split('/')[-2],sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if not title: title = sBvufaD6c9YHdOqTjCQ3.findall('()-([0-9]+)',RMC6c2kL5hGOnFaIwAyb.split('/')[-2],sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if title: title = hT7zFDpEyUqf8sXuN + title[0][1]
			else: title = QigevCplXxbPI1H
			title = name + ' - ' + 'الحلقة' + title
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,182,cXu4fN1moCypJqb72OZvd)
	if not items:
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',QigevCplXxbPI1H).replace('بجوده ',QigevCplXxbPI1H)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,182,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	G0RTQfMtClr5zXvaOxgepE9VYS = url.split('?servers=')
	Kj0TOU6BmSMlJHZYLd = G0RTQfMtClr5zXvaOxgepE9VYS[0]
	del G0RTQfMtClr5zXvaOxgepE9VYS[0]
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-PLAY-1st')
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('font-size: 25px;" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)[0]
	if RMC6c2kL5hGOnFaIwAyb not in G0RTQfMtClr5zXvaOxgepE9VYS: G0RTQfMtClr5zXvaOxgepE9VYS.append(RMC6c2kL5hGOnFaIwAyb)
	ldFqnNIsftrY43JBM6LPjzU8m = []
	for RMC6c2kL5hGOnFaIwAyb in G0RTQfMtClr5zXvaOxgepE9VYS:
		if '://moshahda.' in RMC6c2kL5hGOnFaIwAyb:
			MMFqVB5XYaj2zfUEs3ehTx4Q9b1 = RMC6c2kL5hGOnFaIwAyb
			ldFqnNIsftrY43JBM6LPjzU8m.append(MMFqVB5XYaj2zfUEs3ehTx4Q9b1+'?named=Main')
	for RMC6c2kL5hGOnFaIwAyb in G0RTQfMtClr5zXvaOxgepE9VYS:
		if '://vb.movizland.' in RMC6c2kL5hGOnFaIwAyb:
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,RMC6c2kL5hGOnFaIwAyb,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-PLAY-2nd')
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.decode('windows-1256').encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			aY63L2NhgvwJIxPAoDG4MKECmZXF1 = aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if fwSu6JsQZpEiv:
				XxAz2nKNP6ORDfaLFo7MQT4rsEde,kQlGI4ouaPwteZq9XgKB02 = [],[]
				if len(fwSu6JsQZpEiv)==1:
					title = QigevCplXxbPI1H
					LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
				else:
					for LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
						Pk5h14WpxO3nAQFv0rYmNa8KDblSg = sBvufaD6c9YHdOqTjCQ3.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
						if Pk5h14WpxO3nAQFv0rYmNa8KDblSg: LKzFWsmvjUVGMDBapflx6H4NY = 'src="/uploads/13721411411.png"  \n  ' + Pk5h14WpxO3nAQFv0rYmNa8KDblSg[0][1]
						Pk5h14WpxO3nAQFv0rYmNa8KDblSg = sBvufaD6c9YHdOqTjCQ3.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
						if Pk5h14WpxO3nAQFv0rYmNa8KDblSg: LKzFWsmvjUVGMDBapflx6H4NY = 'src="/uploads/13721411411.png"  \n  ' + Pk5h14WpxO3nAQFv0rYmNa8KDblSg[0]
						Pk5h14WpxO3nAQFv0rYmNa8KDblSg = sBvufaD6c9YHdOqTjCQ3.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
						if Pk5h14WpxO3nAQFv0rYmNa8KDblSg: LKzFWsmvjUVGMDBapflx6H4NY = Pk5h14WpxO3nAQFv0rYmNa8KDblSg[0] + '  \n  src="/uploads/13721411411.png"'
						nR68VtcrkLC2evOla = sBvufaD6c9YHdOqTjCQ3.findall('<(.*?)http://up.movizland.(online|com)/uploads/',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
						title = sBvufaD6c9YHdOqTjCQ3.findall('> *([^<>]+) *<',nR68VtcrkLC2evOla[0][0],sBvufaD6c9YHdOqTjCQ3.DOTALL)
						title = hT7zFDpEyUqf8sXuN.join(title)
						title = title.strip(hT7zFDpEyUqf8sXuN)
						title = title.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
						XxAz2nKNP6ORDfaLFo7MQT4rsEde.append(title)
					HHZ6579kAv8 = zYWJO03iISD('أختر الفيديو المطلوب:', XxAz2nKNP6ORDfaLFo7MQT4rsEde)
					if HHZ6579kAv8 == -1 : return
					title = XxAz2nKNP6ORDfaLFo7MQT4rsEde[HHZ6579kAv8]
					LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[HHZ6579kAv8]
				RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('href="(http://moshahda\..*?/\w+.html)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				llkQ5Iv67nuDs = RMC6c2kL5hGOnFaIwAyb[0]
				ldFqnNIsftrY43JBM6LPjzU8m.append(llkQ5Iv67nuDs+'?named=Forum')
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('ـ',QigevCplXxbPI1H)
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				LKzFWsmvjUVGMDBapflx6H4NY = LKzFWsmvjUVGMDBapflx6H4NY.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				X56fJuj41Wi8GtlhdFZSpTHzLg = sBvufaD6c9YHdOqTjCQ3.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for xHZf59Plbkn8z34wcBvJ6mt in X56fJuj41Wi8GtlhdFZSpTHzLg:
					type = sBvufaD6c9YHdOqTjCQ3.findall(' typetype="(.*?)" ',xHZf59Plbkn8z34wcBvJ6mt)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = QigevCplXxbPI1H
					items = sBvufaD6c9YHdOqTjCQ3.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',xHZf59Plbkn8z34wcBvJ6mt,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					for sbiE4zPKvMJd2BU0rZn,RMC6c2kL5hGOnFaIwAyb in items:
						title = sBvufaD6c9YHdOqTjCQ3.findall('(\w+[ \w]*)<',sbiE4zPKvMJd2BU0rZn)
						title = title[-1]
						RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb + '?named=' + title + type
						ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = Kj0TOU6BmSMlJHZYLd.replace(vxQUXEuH9m,PTKgtGhwsW51oZ3uQImn6Czd0ERNyb)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-PLAY-3rd')
	items = sBvufaD6c9YHdOqTjCQ3.findall('" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if items:
		Kuf2iWSopHwVZYEIXjGP6r14bqeT = items[-1]
		ldFqnNIsftrY43JBM6LPjzU8m.append(Kuf2iWSopHwVZYEIXjGP6r14bqeT+'?named=Mobile')
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'MOVIZLAND-SEARCH-1st')
	items = sBvufaD6c9YHdOqTjCQ3.findall('<option value="(.*?)">(.*?)</option>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ESmb8w0xDN5XR7cMvdzTneKBoI6 = [ QigevCplXxbPI1H ]
	WMN8Kb4iJjeZVgSdP3UOCX = [ 'الكل وبدون فلتر' ]
	for opIyA9rsJMXPL1k,title in items:
		ESmb8w0xDN5XR7cMvdzTneKBoI6.append(opIyA9rsJMXPL1k)
		WMN8Kb4iJjeZVgSdP3UOCX.append(title)
	if opIyA9rsJMXPL1k:
		HHZ6579kAv8 = zYWJO03iISD('اختر الفلتر المناسب:', WMN8Kb4iJjeZVgSdP3UOCX)
		if HHZ6579kAv8 == -1 : return
		opIyA9rsJMXPL1k = ESmb8w0xDN5XR7cMvdzTneKBoI6[HHZ6579kAv8]
	else: opIyA9rsJMXPL1k = QigevCplXxbPI1H
	url = vxQUXEuH9m + '/?s='+search+'&mcat='+opIyA9rsJMXPL1k
	ddbEXhWzOnIaR(url)
	return
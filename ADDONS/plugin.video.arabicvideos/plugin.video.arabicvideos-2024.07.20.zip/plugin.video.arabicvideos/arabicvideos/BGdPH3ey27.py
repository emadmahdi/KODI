# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
JwBc6IZ4xeLmM8 = 'M3U'
KNY6Ao0Stysxc = '_M3U_'
AI5jVSyzuU4 = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
BfLAwW35nUiRPuNpymh9t = 4
def WPjOcwA2E7GS4doDXyU3l9C(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XCapNbgw2xWQ5jRt,d8kolNVuLsPAjQZ9ROpUHBgix,pf6P4wckhgTa,iIBnwPa3gYp4d,TV74iI95g1jkpRMyQ):
	global KNY6Ao0Stysxc
	try:
		wiWn9NIP6XG = str(TV74iI95g1jkpRMyQ['folder'])
		KNY6Ao0Stysxc = '_MU'+wiWn9NIP6XG+'_'
	except: wiWn9NIP6XG = QigevCplXxbPI1H
	try: ivF0XNlyjxR7TWA12 = str(TV74iI95g1jkpRMyQ['sequence'])
	except: ivF0XNlyjxR7TWA12 = QigevCplXxbPI1H
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==710: JX4pLs7W5Mdm = M7FJkEI0H8Z()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==711: JX4pLs7W5Mdm = WWyGcmtUOg85nDhwYAdpvXLFilfK(wiWn9NIP6XG,ivF0XNlyjxR7TWA12)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==712: JX4pLs7W5Mdm = UUQLCXmFkH4owN8SAJ7l3PcxV(wiWn9NIP6XG)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==713: JX4pLs7W5Mdm = uLBdfExXvZnPw2gpNOjRt8yQi(wiWn9NIP6XG,XCapNbgw2xWQ5jRt,d8kolNVuLsPAjQZ9ROpUHBgix,iIBnwPa3gYp4d)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==714: JX4pLs7W5Mdm = PYViltfWah910OHUZeR(wiWn9NIP6XG,XCapNbgw2xWQ5jRt,d8kolNVuLsPAjQZ9ROpUHBgix,iIBnwPa3gYp4d)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==715: JX4pLs7W5Mdm = nibvTq2jfRXDM4tYP039S(wiWn9NIP6XG,XCapNbgw2xWQ5jRt,pf6P4wckhgTa)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==716: JX4pLs7W5Mdm = ytTiCxl1Ig(wiWn9NIP6XG,True)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==717: JX4pLs7W5Mdm = guYc0nphomZA(wiWn9NIP6XG,True)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==718: JX4pLs7W5Mdm = u5RVgwQxXIe7MiHkKlD8yA(wiWn9NIP6XG,XCapNbgw2xWQ5jRt,d8kolNVuLsPAjQZ9ROpUHBgix)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==719: JX4pLs7W5Mdm = xajb3VgNyPAo(d8kolNVuLsPAjQZ9ROpUHBgix,wiWn9NIP6XG,XCapNbgw2xWQ5jRt,iIBnwPa3gYp4d)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==720: JX4pLs7W5Mdm = aARx6VJZyYimz8Ns(wiWn9NIP6XG,True)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==721: JX4pLs7W5Mdm = oYDBUW2zuFe9vEx(wiWn9NIP6XG)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==722: JX4pLs7W5Mdm = VtkydMQAJcfoGuTNeYCH8Dg7(wiWn9NIP6XG)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==723: JX4pLs7W5Mdm = ctmC0UDzaB(wiWn9NIP6XG)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==726: JX4pLs7W5Mdm = l1iBTU4Cn9y(wiWn9NIP6XG)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==729: JX4pLs7W5Mdm = hIQfYFl7nKURr93vd4Hs2mNC(d8kolNVuLsPAjQZ9ROpUHBgix,wiWn9NIP6XG,XCapNbgw2xWQ5jRt,iIBnwPa3gYp4d)
	else: JX4pLs7W5Mdm = False
	return JX4pLs7W5Mdm
def M7FJkEI0H8Z():
	for wiWn9NIP6XG in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
		KNY6Ao0Stysxc = '_MU'+str(wiWn9NIP6XG)+'_'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قائمة مجلد '+qqfVzPxYZ5R[wiWn9NIP6XG],QigevCplXxbPI1H,720,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	return
def aARx6VJZyYimz8Ns(wiWn9NIP6XG=QigevCplXxbPI1H,YLb0uVtp5ZEChqf1In2zGNi4e=QigevCplXxbPI1H):
	if wiWn9NIP6XG:
		nnzNkr3UYmFH5lMTOByiSERpu9 = {'folder':wiWn9NIP6XG}
		eSfNjkcdFXgrs8tUMDo75 = QigevCplXxbPI1H
	else:
		nnzNkr3UYmFH5lMTOByiSERpu9 = QigevCplXxbPI1H
		eSfNjkcdFXgrs8tUMDo75 = QigevCplXxbPI1H
	dWEYgjioeB5Z = pQW09CG5Fojk4i(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e)
	if not dWEYgjioeB5Z:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'[COLOR FFFFFF00] إضافة وتغيير رابط'+eSfNjkcdFXgrs8tUMDo75+hT7zFDpEyUqf8sXuN+qqfVzPxYZ5R[1]+' [/COLOR]',QigevCplXxbPI1H,711,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG,'sequence':1})
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'[COLOR FFFFFF00] جلب ملفات'+eSfNjkcdFXgrs8tUMDo75+' [/COLOR]',QigevCplXxbPI1H,712,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	else:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'بحث في الملفات'+eSfNjkcdFXgrs8tUMDo75,QigevCplXxbPI1H,729,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_',QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات مصنفة مرتبة'+eSfNjkcdFXgrs8tUMDo75,'LIVE_GROUPED_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات مصنفة من القسم'+eSfNjkcdFXgrs8tUMDo75,'LIVE_FROM_GROUP_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات مصنفة من الاسم'+eSfNjkcdFXgrs8tUMDo75,'LIVE_FROM_NAME_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات مصنفة بلا ترتيب'+eSfNjkcdFXgrs8tUMDo75,'LIVE_GROUPED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات بلا ترتيب'+eSfNjkcdFXgrs8tUMDo75,'LIVE_ORIGINAL_GROUPED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات مجهولة مرتبة'+eSfNjkcdFXgrs8tUMDo75,'LIVE_UNKNOWN_GROUPED_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'قنوات مجهولة بلا ترتيب'+eSfNjkcdFXgrs8tUMDo75,'LIVE_UNKNOWN_GROUPED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'فيديوهات بلا ترتيب'+eSfNjkcdFXgrs8tUMDo75,'VOD_ORIGINAL_GROUPED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'فيديوهات مصنفة القسم'+eSfNjkcdFXgrs8tUMDo75,'VOD_FROM_GROUP_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'فيديوهات مصنفة من الاسم'+eSfNjkcdFXgrs8tUMDo75,'VOD_FROM_NAME_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'فيديوهات مجهولة بلا ترتيب'+eSfNjkcdFXgrs8tUMDo75,'VOD_UNKNOWN_GROUPED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'فيديوهات مجهولة مرتبة'+eSfNjkcdFXgrs8tUMDo75,'VOD_UNKNOWN_GROUPED_SORTED',713,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	for bb6LKGv5OYmaWIHz3ZfuUS in range(1,BfLAwW35nUiRPuNpymh9t+1):
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'إضافة وتغيير رابط'+eSfNjkcdFXgrs8tUMDo75+hT7zFDpEyUqf8sXuN+qqfVzPxYZ5R[bb6LKGv5OYmaWIHz3ZfuUS],QigevCplXxbPI1H,711,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG,'sequence':bb6LKGv5OYmaWIHz3ZfuUS})
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'جلب ملفات'+eSfNjkcdFXgrs8tUMDo75,QigevCplXxbPI1H,712,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'مسح ملفات'+eSfNjkcdFXgrs8tUMDo75,QigevCplXxbPI1H,717,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'عدد فيديوهات'+eSfNjkcdFXgrs8tUMDo75,QigevCplXxbPI1H,721,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'Referer تغيير'+eSfNjkcdFXgrs8tUMDo75,QigevCplXxbPI1H,726,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'User-Agent تغيير'+eSfNjkcdFXgrs8tUMDo75,QigevCplXxbPI1H,723,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,nnzNkr3UYmFH5lMTOByiSERpu9)
	return
def ytTiCxl1Ig(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e=True):
	NjtUM0miun9gYWpdSa,KmPCnI7tJDvzSdaYgk2wHEFNGpy = False,QigevCplXxbPI1H
	IIHx8tTugDeGLV4l6SiFvPohp5,v5SYTclVo1yUrH = QigevCplXxbPI1H,QigevCplXxbPI1H
	gsRbHLpw8V4oxhnZuW,N4aCiYwI2szoFfrqEWmV0jtTeX,zqr2pO8XK5CoZi9uHwQTtsxLVkGP,qqgeBldQsSGocHAx,hvgPWl0BteqJNjMOkZC = UZunqWaibYvmr1zhMOK4AJ(wiWn9NIP6XG)
	if qqgeBldQsSGocHAx==QigevCplXxbPI1H: return False,QigevCplXxbPI1H,QigevCplXxbPI1H
	UFtxHq7c39mD = uPO26bDTs5ZA(wiWn9NIP6XG)
	if gsRbHLpw8V4oxhnZuW:
		T4U1lV3YFrtSv = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'GET',gsRbHLpw8V4oxhnZuW,QigevCplXxbPI1H,UFtxHq7c39mD,False,QigevCplXxbPI1H,'M3U-CHECK_ACCOUNT-1st')
		AHI1BUrVOKWfMlzZg = T4U1lV3YFrtSv.content
		if T4U1lV3YFrtSv.succeeded:
			nGxSQPHg12tBWoc6AFdOp7wT,Bo79SliEPtXe1,IWCVxQhdETvl5ZktXg8KFjw1n27,GPb2t0vfXjRDZqgTdMWmO,y3EMW4u5bp2NfgvHmIohBVJ = 0,0,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
			try:
				T98gC4zIa1hD = CH86N7xw4cyPt3TlIBJF('dict',AHI1BUrVOKWfMlzZg)
				KmPCnI7tJDvzSdaYgk2wHEFNGpy = T98gC4zIa1hD['user_info']['status']
				NjtUM0miun9gYWpdSa = True
				IWCVxQhdETvl5ZktXg8KFjw1n27 = T98gC4zIa1hD['server_info']['time_now']
			except: pass
			if IWCVxQhdETvl5ZktXg8KFjw1n27:
				try:
					w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz = B3TKLo71hAGRqYgV0.strptime(IWCVxQhdETvl5ZktXg8KFjw1n27,'%Y.%m.%d %H:%M:%S')
					nGxSQPHg12tBWoc6AFdOp7wT = int(B3TKLo71hAGRqYgV0.mktime(w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz))
					Bo79SliEPtXe1 = int(qyUPZBiAE3YkuOKrMnTFex92D-nGxSQPHg12tBWoc6AFdOp7wT)
					Bo79SliEPtXe1 = int((Bo79SliEPtXe1+900)/1800)*1800
				except: pass
				try:
					w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz = B3TKLo71hAGRqYgV0.localtime(int(T98gC4zIa1hD['user_info']['created_at']))
					GPb2t0vfXjRDZqgTdMWmO = B3TKLo71hAGRqYgV0.strftime('%Y.%m.%d %H:%M:%S',w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz)
				except: pass
				try:
					w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz = B3TKLo71hAGRqYgV0.localtime(int(T98gC4zIa1hD['user_info']['exp_date']))
					y3EMW4u5bp2NfgvHmIohBVJ = B3TKLo71hAGRqYgV0.strftime('%Y.%m.%d %H:%M:%S',w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz)
				except: pass
			uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.timestamp_'+wiWn9NIP6XG,str(qyUPZBiAE3YkuOKrMnTFex92D))
			uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.timediff_'+wiWn9NIP6XG,str(Bo79SliEPtXe1))
			try:
				uAgbnfV9QHaeLxrkXj8qKYFo7c4Zs = '"server_info":'+AHI1BUrVOKWfMlzZg.split('"server_info":')[1]
				uAgbnfV9QHaeLxrkXj8qKYFo7c4Zs = uAgbnfV9QHaeLxrkXj8qKYFo7c4Zs.replace(':',': ').replace(',',', ').replace('}}','}')
				vWbnPh8Z4Ox529USD7Y1 = sBvufaD6c9YHdOqTjCQ3.findall('"url": "(.*?)", "port": "(.*?)"',uAgbnfV9QHaeLxrkXj8qKYFo7c4Zs,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				IIHx8tTugDeGLV4l6SiFvPohp5,v5SYTclVo1yUrH = vWbnPh8Z4Ox529USD7Y1[0]
			except: NjtUM0miun9gYWpdSa = False
			if NjtUM0miun9gYWpdSa and YLb0uVtp5ZEChqf1In2zGNi4e:
				max = T98gC4zIa1hD['user_info']['max_connections']
				zUclBfg5t3WQ8monO4D6T = T98gC4zIa1hD['user_info']['active_cons']
				UU7TKBAfQ0h4eH = T98gC4zIa1hD['user_info']['is_trial']
				XF5AiKR4ZeG2x9uO1gLQMnr = gsRbHLpw8V4oxhnZuW.split('?',1)
				nDRKguWex0iVN8 = 'URL:  [COLOR FFC89008]'+gsRbHLpw8V4oxhnZuW+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\n\nStatus:  '+iVCLpNIM8BQs9PdSgKZvlFeo3a5+KmPCnI7tJDvzSdaYgk2wHEFNGpy+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\nTrial:    '+iVCLpNIM8BQs9PdSgKZvlFeo3a5+str(UU7TKBAfQ0h4eH=='1')+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\nCreated  At:  '+iVCLpNIM8BQs9PdSgKZvlFeo3a5+GPb2t0vfXjRDZqgTdMWmO+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\nExpiry Date:  '+iVCLpNIM8BQs9PdSgKZvlFeo3a5+y3EMW4u5bp2NfgvHmIohBVJ+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\nConnections   ( Active / Maximum ) :  '+iVCLpNIM8BQs9PdSgKZvlFeo3a5+zUclBfg5t3WQ8monO4D6T+' / '+max+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\nAllowed Outputs:   '+iVCLpNIM8BQs9PdSgKZvlFeo3a5+" , ".join(T98gC4zIa1hD['user_info']['allowed_output_formats'])+jhAlCQ47ZgG
				nDRKguWex0iVN8 += '\n\n'+uAgbnfV9QHaeLxrkXj8qKYFo7c4Zs
				if KmPCnI7tJDvzSdaYgk2wHEFNGpy=='Active': vxHN6SWyDEMjBY2ksUl9n('الاشتراك يعمل بدون مشاكل',nDRKguWex0iVN8)
				else: vxHN6SWyDEMjBY2ksUl9n('يبدو أن هناك مشكلة في الاشتراك',nDRKguWex0iVN8)
	if gsRbHLpw8V4oxhnZuW and NjtUM0miun9gYWpdSa and KmPCnI7tJDvzSdaYgk2wHEFNGpy=='Active':
		SQdRhwozVfv(AwKhgdpmBj0,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+gsRbHLpw8V4oxhnZuW+' ]')
		jgA5IRNqLonwC47 = True
	else:
		SQdRhwozVfv(QKaGISLxUqbmh,'Checking M3U URL   [ Does not work ]   [ '+gsRbHLpw8V4oxhnZuW+' ]')
		if YLb0uVtp5ZEChqf1In2zGNi4e: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		jgA5IRNqLonwC47 = False
	return jgA5IRNqLonwC47,IIHx8tTugDeGLV4l6SiFvPohp5,v5SYTclVo1yUrH
def PYViltfWah910OHUZeR(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it,elnx5NakKGbAY4u6fjIs7M2,VjyFvc68g4YboUlHR,YLb0uVtp5ZEChqf1In2zGNi4e=True):
	if not VjyFvc68g4YboUlHR: VjyFvc68g4YboUlHR = '1'
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e): return
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it)
	eZrCtjVSdlx3Q70 = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'list',alwxe3cuQACn067UZJpqkybP2it,elnx5NakKGbAY4u6fjIs7M2)
	HawVfkRcO6pK9 = int(VjyFvc68g4YboUlHR)*100
	hQuKXxJP80LCAaZO62q13bv4 = HawVfkRcO6pK9-100
	for SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m in eZrCtjVSdlx3Q70[hQuKXxJP80LCAaZO62q13bv4:HawVfkRcO6pK9]:
		BBuFJaV4pGYdKLrszb = ('GROUPED' in alwxe3cuQACn067UZJpqkybP2it or alwxe3cuQACn067UZJpqkybP2it=='ALL')
		YftUdjWxaAIycHlXTw = ('GROUPED' not in alwxe3cuQACn067UZJpqkybP2it and alwxe3cuQACn067UZJpqkybP2it!='ALL')
		if BBuFJaV4pGYdKLrszb or YftUdjWxaAIycHlXTw:
			if   'ARCHIVED'  in alwxe3cuQACn067UZJpqkybP2it: lc0jJQ4zboeDI3tqTrpvm5gZO.append(['folder',KNY6Ao0Stysxc+aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,718,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,'ARCHIVED',QigevCplXxbPI1H,{'folder':wiWn9NIP6XG}])
			elif 'EPG' 		 in alwxe3cuQACn067UZJpqkybP2it: lc0jJQ4zboeDI3tqTrpvm5gZO.append(['folder',KNY6Ao0Stysxc+aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,718,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,'FULL_EPG',QigevCplXxbPI1H,{'folder':wiWn9NIP6XG}])
			elif 'TIMESHIFT' in alwxe3cuQACn067UZJpqkybP2it: lc0jJQ4zboeDI3tqTrpvm5gZO.append(['folder',KNY6Ao0Stysxc+aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,718,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,'TIMESHIFT',QigevCplXxbPI1H,{'folder':wiWn9NIP6XG}])
			elif 'LIVE' 	 in alwxe3cuQACn067UZJpqkybP2it: lc0jJQ4zboeDI3tqTrpvm5gZO.append(['live',KNY6Ao0Stysxc+aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,715,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,QigevCplXxbPI1H,SFQtU7cnyeo,{'folder':wiWn9NIP6XG}])
			else: lc0jJQ4zboeDI3tqTrpvm5gZO.append(['video',KNY6Ao0Stysxc+aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,715,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG}])
	TTxDNLsAzuynXYK = len(eZrCtjVSdlx3Q70)
	YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(wiWn9NIP6XG,VjyFvc68g4YboUlHR,alwxe3cuQACn067UZJpqkybP2it,714,TTxDNLsAzuynXYK,elnx5NakKGbAY4u6fjIs7M2)
	return
def Ph1tRHudDqKaG6sbSk3I2XOonJC5W(ssS3xY6EAlKkQGt9F7X):
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',ssS3xY6EAlKkQGt9F7X+'هذه القائمة إما فارغة أو غير موجودة',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',ssS3xY6EAlKkQGt9F7X+'أو الخدمة غير موجودة في اشتراكك',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',ssS3xY6EAlKkQGt9F7X+'أو رابط M3U الذي أنت أضفته غير صحيح',QigevCplXxbPI1H,9999)
	return
def uLBdfExXvZnPw2gpNOjRt8yQi(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it,elnx5NakKGbAY4u6fjIs7M2,VjyFvc68g4YboUlHR,Kg6X2WwPvUudBibaMC3nsDrfG1L=QigevCplXxbPI1H,YLb0uVtp5ZEChqf1In2zGNi4e=True):
	if not VjyFvc68g4YboUlHR: VjyFvc68g4YboUlHR = '1'
	ssS3xY6EAlKkQGt9F7X = KNY6Ao0Stysxc
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e): return False
	if '__SERIES__' in elnx5NakKGbAY4u6fjIs7M2: EE18bvdnuF4JN,Hx9DCLeRuva7sQ3iIp0J1 = elnx5NakKGbAY4u6fjIs7M2.split('__SERIES__')
	else: EE18bvdnuF4JN,Hx9DCLeRuva7sQ3iIp0J1 = elnx5NakKGbAY4u6fjIs7M2,QigevCplXxbPI1H
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it)
	c6l4C9akdTJfQ0PAwMpnj5muSzOK = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'list',alwxe3cuQACn067UZJpqkybP2it,'__GROUPS__')
	if not c6l4C9akdTJfQ0PAwMpnj5muSzOK: return False
	qIPhQkjK1OYcvRtFwHmLs6XnGEeTrJ = []
	for KKQDtNb1Awl5Jy3vWIEYFaU6kq,AkHOcXEv2wJp7W085m in c6l4C9akdTJfQ0PAwMpnj5muSzOK:
		if '===== ===== =====' in KKQDtNb1Awl5Jy3vWIEYFaU6kq:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',ssS3xY6EAlKkQGt9F7X+KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,9999)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',ssS3xY6EAlKkQGt9F7X+KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,9999)
			continue
		if Kg6X2WwPvUudBibaMC3nsDrfG1L:
			if '__SERIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq: ssS3xY6EAlKkQGt9F7X = 'SERIES'
			elif '!!__UNKNOWN__!!' in KKQDtNb1Awl5Jy3vWIEYFaU6kq: ssS3xY6EAlKkQGt9F7X = 'UNKNOWN'
			elif 'LIVE' in alwxe3cuQACn067UZJpqkybP2it: ssS3xY6EAlKkQGt9F7X = 'LIVE'
			else: ssS3xY6EAlKkQGt9F7X = 'VIDEOS'
			ssS3xY6EAlKkQGt9F7X = ',[COLOR FFC89008]'+ssS3xY6EAlKkQGt9F7X+': [/COLOR]'
		if '__SERIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq: CCl7qnAxYaOdJuoXgV6NKQWwSPM,Ad7J1HD5lhI = KKQDtNb1Awl5Jy3vWIEYFaU6kq.split('__SERIES__')
		else: CCl7qnAxYaOdJuoXgV6NKQWwSPM,Ad7J1HD5lhI = KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H
		if not elnx5NakKGbAY4u6fjIs7M2:
			if CCl7qnAxYaOdJuoXgV6NKQWwSPM in qIPhQkjK1OYcvRtFwHmLs6XnGEeTrJ: continue
			qIPhQkjK1OYcvRtFwHmLs6XnGEeTrJ.append(CCl7qnAxYaOdJuoXgV6NKQWwSPM)
			if 'RANDOM' in Kg6X2WwPvUudBibaMC3nsDrfG1L: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',ssS3xY6EAlKkQGt9F7X+CCl7qnAxYaOdJuoXgV6NKQWwSPM,alwxe3cuQACn067UZJpqkybP2it,168,QigevCplXxbPI1H,'1',KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
			elif '__SERIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',ssS3xY6EAlKkQGt9F7X+CCl7qnAxYaOdJuoXgV6NKQWwSPM,alwxe3cuQACn067UZJpqkybP2it,713,QigevCplXxbPI1H,'1',KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',ssS3xY6EAlKkQGt9F7X+CCl7qnAxYaOdJuoXgV6NKQWwSPM,alwxe3cuQACn067UZJpqkybP2it,714,QigevCplXxbPI1H,'1',KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
		elif '__SERIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq and CCl7qnAxYaOdJuoXgV6NKQWwSPM==EE18bvdnuF4JN:
			if Ad7J1HD5lhI in qIPhQkjK1OYcvRtFwHmLs6XnGEeTrJ: continue
			qIPhQkjK1OYcvRtFwHmLs6XnGEeTrJ.append(Ad7J1HD5lhI)
			if 'RANDOM' in Kg6X2WwPvUudBibaMC3nsDrfG1L: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',ssS3xY6EAlKkQGt9F7X+Ad7J1HD5lhI,alwxe3cuQACn067UZJpqkybP2it,168,QigevCplXxbPI1H,'1',KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',ssS3xY6EAlKkQGt9F7X+Ad7J1HD5lhI,alwxe3cuQACn067UZJpqkybP2it,714,AkHOcXEv2wJp7W085m,'1',KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	lc0jJQ4zboeDI3tqTrpvm5gZO[:] = sorted(lc0jJQ4zboeDI3tqTrpvm5gZO,reverse=False,key=lambda Z6ZpWLOjfodPKl3QVqrTYai8MBA9: Z6ZpWLOjfodPKl3QVqrTYai8MBA9[1].lower())
	if not Kg6X2WwPvUudBibaMC3nsDrfG1L:
		HawVfkRcO6pK9 = int(VjyFvc68g4YboUlHR)*100
		hQuKXxJP80LCAaZO62q13bv4 = HawVfkRcO6pK9-100
		TTxDNLsAzuynXYK = len(lc0jJQ4zboeDI3tqTrpvm5gZO)
		lc0jJQ4zboeDI3tqTrpvm5gZO[:] = lc0jJQ4zboeDI3tqTrpvm5gZO[hQuKXxJP80LCAaZO62q13bv4:HawVfkRcO6pK9]
		YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(wiWn9NIP6XG,VjyFvc68g4YboUlHR,alwxe3cuQACn067UZJpqkybP2it,713,TTxDNLsAzuynXYK,elnx5NakKGbAY4u6fjIs7M2)
	return True
def u5RVgwQxXIe7MiHkKlD8yA(wiWn9NIP6XG,XCapNbgw2xWQ5jRt,XEVvQydDRrPai4):
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,True): return
	UFtxHq7c39mD = uPO26bDTs5ZA(wiWn9NIP6XG)
	nGxSQPHg12tBWoc6AFdOp7wT = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.timestamp_'+wiWn9NIP6XG)
	if not nGxSQPHg12tBWoc6AFdOp7wT or qyUPZBiAE3YkuOKrMnTFex92D-int(nGxSQPHg12tBWoc6AFdOp7wT)>24*oaxeugQnX1W6UJN:
		jgA5IRNqLonwC47,IIHx8tTugDeGLV4l6SiFvPohp5,v5SYTclVo1yUrH = ytTiCxl1Ig(wiWn9NIP6XG,False)
		if not jgA5IRNqLonwC47: return
	Bo79SliEPtXe1 = int(uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.timediff_'+wiWn9NIP6XG))
	zqr2pO8XK5CoZi9uHwQTtsxLVkGP = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.server_'+wiWn9NIP6XG)
	qqgeBldQsSGocHAx = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.username_'+wiWn9NIP6XG)
	hvgPWl0BteqJNjMOkZC = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.password_'+wiWn9NIP6XG)
	iiKXMLpUyx1BzIoD8bHWlVOgT6fS23 = XCapNbgw2xWQ5jRt.split('/')
	KIxQBvA8RT40h63V = iiKXMLpUyx1BzIoD8bHWlVOgT6fS23[-1].replace('.ts',QigevCplXxbPI1H).replace('.m3u8',QigevCplXxbPI1H)
	if XEVvQydDRrPai4=='SHORT_EPG': Btp7q6l8L0hfz4 = 'get_short_epg'
	else: Btp7q6l8L0hfz4 = 'get_simple_data_table'
	gsRbHLpw8V4oxhnZuW,N4aCiYwI2szoFfrqEWmV0jtTeX,zqr2pO8XK5CoZi9uHwQTtsxLVkGP,qqgeBldQsSGocHAx,hvgPWl0BteqJNjMOkZC = UZunqWaibYvmr1zhMOK4AJ(wiWn9NIP6XG)
	if not qqgeBldQsSGocHAx: return
	bt8PyLFmRf = gsRbHLpw8V4oxhnZuW+'&action='+Btp7q6l8L0hfz4+'&stream_id='+KIxQBvA8RT40h63V
	AHI1BUrVOKWfMlzZg = N4h95otDIcBfO2YqVdTnZLvC83(oL2eIiFEJnd7vxc,bt8PyLFmRf,QigevCplXxbPI1H,UFtxHq7c39mD,QigevCplXxbPI1H,'M3U-EPG_ITEMS-2nd')
	d5E809xuk6zBqjNR = CH86N7xw4cyPt3TlIBJF('dict',AHI1BUrVOKWfMlzZg)
	ppw41ghPADSRVsv3 = d5E809xuk6zBqjNR['epg_listings']
	xEwuiyWIvVmXrplZn = []
	if XEVvQydDRrPai4 in ['ARCHIVED','TIMESHIFT']:
		for T98gC4zIa1hD in ppw41ghPADSRVsv3:
			if T98gC4zIa1hD['has_archive']==1:
				xEwuiyWIvVmXrplZn.append(T98gC4zIa1hD)
				if XEVvQydDRrPai4 in ['TIMESHIFT']: break
		if not xEwuiyWIvVmXrplZn: return
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]',QigevCplXxbPI1H,9999)
		if XEVvQydDRrPai4 in ['TIMESHIFT']:
			W1gqNAMaVeD5d8Zm7HJ2Ql = 2
			lK0gFL4jE2GO9yd5Nr = W1gqNAMaVeD5d8Zm7HJ2Ql*oaxeugQnX1W6UJN
			xEwuiyWIvVmXrplZn = []
			G0RnqZvAazbUcrLJyTtE = int(int(T98gC4zIa1hD['start_timestamp'])/lK0gFL4jE2GO9yd5Nr)*lK0gFL4jE2GO9yd5Nr
			nPvf073Tt6IkRmxuJFBAw9U = qyUPZBiAE3YkuOKrMnTFex92D+lK0gFL4jE2GO9yd5Nr
			RIS7rD26ufU = int((nPvf073Tt6IkRmxuJFBAw9U-G0RnqZvAazbUcrLJyTtE)/oaxeugQnX1W6UJN)
			for bbVNsXZRi7yBGEJotc5K3Ax in range(RIS7rD26ufU):
				if bbVNsXZRi7yBGEJotc5K3Ax>=6:
					if bbVNsXZRi7yBGEJotc5K3Ax%W1gqNAMaVeD5d8Zm7HJ2Ql!=0: continue
					aU7D9VldsKxSr0 = lK0gFL4jE2GO9yd5Nr
				else: aU7D9VldsKxSr0 = lK0gFL4jE2GO9yd5Nr//2
				f1fwGYdreh0o = G0RnqZvAazbUcrLJyTtE+bbVNsXZRi7yBGEJotc5K3Ax*oaxeugQnX1W6UJN
				T98gC4zIa1hD = {}
				T98gC4zIa1hD['title'] = QigevCplXxbPI1H
				w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz = B3TKLo71hAGRqYgV0.localtime(f1fwGYdreh0o-Bo79SliEPtXe1-oaxeugQnX1W6UJN)
				T98gC4zIa1hD['start'] = B3TKLo71hAGRqYgV0.strftime('%Y.%m.%d %H:%M:%S',w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz)
				T98gC4zIa1hD['start_timestamp'] = str(f1fwGYdreh0o)
				T98gC4zIa1hD['stop_timestamp'] = str(f1fwGYdreh0o+aU7D9VldsKxSr0)
				xEwuiyWIvVmXrplZn.append(T98gC4zIa1hD)
	elif XEVvQydDRrPai4 in ['SHORT_EPG','FULL_EPG']: xEwuiyWIvVmXrplZn = ppw41ghPADSRVsv3
	if XEVvQydDRrPai4=='FULL_EPG' and len(xEwuiyWIvVmXrplZn)>0:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]',QigevCplXxbPI1H,9999)
	iKXG8T9fq4w = []
	AkHOcXEv2wJp7W085m = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel('ListItem.Icon')
	for T98gC4zIa1hD in xEwuiyWIvVmXrplZn:
		aotWnjvVy8k3iS = akgfpLEN8Kn396XjFUut4QJVI.b64decode(T98gC4zIa1hD['title'])
		if b7sJAmSxlBvaMdHFz: aotWnjvVy8k3iS = aotWnjvVy8k3iS.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		f1fwGYdreh0o = int(T98gC4zIa1hD['start_timestamp'])
		Mrg6IEZqx7A5y = int(T98gC4zIa1hD['stop_timestamp'])
		cXn1MsLFThWH83EOoljuIrKtq7Dvf4 = str(int((Mrg6IEZqx7A5y-f1fwGYdreh0o+59)/60))
		rdbHhKJ2Goq0VZycs56eauO = T98gC4zIa1hD['start'].replace(hT7zFDpEyUqf8sXuN,':')
		w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz = B3TKLo71hAGRqYgV0.localtime(f1fwGYdreh0o-oaxeugQnX1W6UJN)
		yjNpS4PsJnl7oaktqB1XK9bC = B3TKLo71hAGRqYgV0.strftime('%H:%M',w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz)
		GvNBlPuW8r3Mat = B3TKLo71hAGRqYgV0.strftime('%a',w9kmc3uZbtLMWGqy5hXP8RUCsE2gxz)
		if XEVvQydDRrPai4=='SHORT_EPG': aotWnjvVy8k3iS = r9rhtA5Tek8sIoLfqwF7JcEV+yjNpS4PsJnl7oaktqB1XK9bC+' ـ '+aotWnjvVy8k3iS+jhAlCQ47ZgG
		elif XEVvQydDRrPai4=='TIMESHIFT': aotWnjvVy8k3iS = GvNBlPuW8r3Mat+hT7zFDpEyUqf8sXuN+yjNpS4PsJnl7oaktqB1XK9bC+' ('+cXn1MsLFThWH83EOoljuIrKtq7Dvf4+'min)'
		else: aotWnjvVy8k3iS = GvNBlPuW8r3Mat+hT7zFDpEyUqf8sXuN+yjNpS4PsJnl7oaktqB1XK9bC+' ('+cXn1MsLFThWH83EOoljuIrKtq7Dvf4+'min)   '+aotWnjvVy8k3iS+' ـ'
		if XEVvQydDRrPai4 in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			ttxVbBRw0HuQ5 = zqr2pO8XK5CoZi9uHwQTtsxLVkGP+'/timeshift/'+qqgeBldQsSGocHAx+'/'+hvgPWl0BteqJNjMOkZC+'/'+cXn1MsLFThWH83EOoljuIrKtq7Dvf4+'/'+rdbHhKJ2Goq0VZycs56eauO+'/'+KIxQBvA8RT40h63V+'.m3u8'
			if XEVvQydDRrPai4=='FULL_EPG': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link',KNY6Ao0Stysxc+aotWnjvVy8k3iS,ttxVbBRw0HuQ5,9999,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',KNY6Ao0Stysxc+aotWnjvVy8k3iS,ttxVbBRw0HuQ5,715,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
		iKXG8T9fq4w.append(aotWnjvVy8k3iS)
	if XEVvQydDRrPai4=='SHORT_EPG' and iKXG8T9fq4w: TyQUbJkwsMKLY10dc6gAhz4C8Nuo = j05zXdGbEn3MBCFHuvw(iKXG8T9fq4w)
	return iKXG8T9fq4w
def VtkydMQAJcfoGuTNeYCH8Dg7(wiWn9NIP6XG):
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,True): return
	zqr2pO8XK5CoZi9uHwQTtsxLVkGP,N9WutHy4M2lV1LjUO,Acap7sJmUQPn6WHVkRgiSYOeB = QigevCplXxbPI1H,0,0
	jgA5IRNqLonwC47,IIHx8tTugDeGLV4l6SiFvPohp5,v5SYTclVo1yUrH = ytTiCxl1Ig(wiWn9NIP6XG,False)
	if jgA5IRNqLonwC47:
		HnrmZQM8XiS = u3uZaBnIvki0TFMzdbQo6VUjRgEL(IIHx8tTugDeGLV4l6SiFvPohp5)
		N9WutHy4M2lV1LjUO = s6smWAehjkQv9nbw2JgSr(HnrmZQM8XiS[0],int(v5SYTclVo1yUrH))
		R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,'LIVE_GROUPED')
		heT4Yup97BVd3bXlcWCqQfDwIP = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'list','LIVE_GROUPED')
		eZrCtjVSdlx3Q70 = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'list','LIVE_GROUPED',heT4Yup97BVd3bXlcWCqQfDwIP[1])
		XCapNbgw2xWQ5jRt = eZrCtjVSdlx3Q70[0][2]
		stVRqQgMhUTYFb9dZJ5a = sBvufaD6c9YHdOqTjCQ3.findall('://(.*?)/',XCapNbgw2xWQ5jRt,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		stVRqQgMhUTYFb9dZJ5a = stVRqQgMhUTYFb9dZJ5a[0]
		if ':' in stVRqQgMhUTYFb9dZJ5a: DzSB9HCeJk7FZPv,AyPvfK5TLe = stVRqQgMhUTYFb9dZJ5a.split(':')
		else: DzSB9HCeJk7FZPv,AyPvfK5TLe = stVRqQgMhUTYFb9dZJ5a,'80'
		rr7njoktUKLmqO48XRvzWeGBZp = u3uZaBnIvki0TFMzdbQo6VUjRgEL(DzSB9HCeJk7FZPv)
		Acap7sJmUQPn6WHVkRgiSYOeB = s6smWAehjkQv9nbw2JgSr(rr7njoktUKLmqO48XRvzWeGBZp[0],int(AyPvfK5TLe))
	if N9WutHy4M2lV1LjUO and Acap7sJmUQPn6WHVkRgiSYOeB:
		nDRKguWex0iVN8 = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		nDRKguWex0iVN8 += '\n\n'+'وقت ضائع في السيرفر الأصلي'+aSBkt4OU8JpWTEzVIHjAiv+str(int(Acap7sJmUQPn6WHVkRgiSYOeB*1000))+' ملي ثانية'
		nDRKguWex0iVN8 += '\n\n'+'وقت ضائع في السيرفر البديل'+aSBkt4OU8JpWTEzVIHjAiv+str(int(N9WutHy4M2lV1LjUO*1000))+' ملي ثانية'
		tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',nDRKguWex0iVN8)
		if tNVOmK5d8DvYoGr2==1 and N9WutHy4M2lV1LjUO<Acap7sJmUQPn6WHVkRgiSYOeB: zqr2pO8XK5CoZi9uHwQTtsxLVkGP = IIHx8tTugDeGLV4l6SiFvPohp5+':'+v5SYTclVo1yUrH
	else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.server_'+wiWn9NIP6XG,zqr2pO8XK5CoZi9uHwQTtsxLVkGP)
	return
def nibvTq2jfRXDM4tYP039S(wiWn9NIP6XG,XCapNbgw2xWQ5jRt,pf6P4wckhgTa):
	JscYrBTLU4QEejuMywG6 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.useragent_'+wiWn9NIP6XG)
	ooAvFkt4MQbn7m = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.referer_'+wiWn9NIP6XG)
	if JscYrBTLU4QEejuMywG6 or ooAvFkt4MQbn7m:
		XCapNbgw2xWQ5jRt += '|'
		if JscYrBTLU4QEejuMywG6: XCapNbgw2xWQ5jRt += '&User-Agent='+JscYrBTLU4QEejuMywG6
		if ooAvFkt4MQbn7m: XCapNbgw2xWQ5jRt += '&Referer='+ooAvFkt4MQbn7m
		XCapNbgw2xWQ5jRt = XCapNbgw2xWQ5jRt.replace('|&','|')
	B9BaTCd86Iwz1e3sRMXZylKpcHU(XCapNbgw2xWQ5jRt,JwBc6IZ4xeLmM8,pf6P4wckhgTa)
	return
def ctmC0UDzaB(wiWn9NIP6XG):
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	JscYrBTLU4QEejuMywG6 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.useragent_'+wiWn9NIP6XG)
	XaCF3qefsmgN = UJV3rPyElz5xRav0FD('center','استخدام الأصلي','تعديل القديم',JscYrBTLU4QEejuMywG6,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if XaCF3qefsmgN==1: JscYrBTLU4QEejuMywG6 = XAfEvmh95VkgurjdiJ('أكتب ـM3U User-Agent جديد',JscYrBTLU4QEejuMywG6,True)
	else: JscYrBTLU4QEejuMywG6 = 'Unknown'
	if JscYrBTLU4QEejuMywG6==hT7zFDpEyUqf8sXuN:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	XaCF3qefsmgN = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,JscYrBTLU4QEejuMywG6,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if XaCF3qefsmgN!=1:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم الإلغاء')
		return
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.useragent_'+wiWn9NIP6XG,JscYrBTLU4QEejuMywG6)
	ArJS5DFPgnf4ea3KoNV(wiWn9NIP6XG)
	return
def l1iBTU4Cn9y(wiWn9NIP6XG):
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	ooAvFkt4MQbn7m = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.referer_'+wiWn9NIP6XG)
	XaCF3qefsmgN = UJV3rPyElz5xRav0FD('center','استخدام الأصلي','تعديل القديم',ooAvFkt4MQbn7m,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if XaCF3qefsmgN==1: ooAvFkt4MQbn7m = XAfEvmh95VkgurjdiJ('أكتب ـM3U Referer جديد',ooAvFkt4MQbn7m,True)
	else: ooAvFkt4MQbn7m = QigevCplXxbPI1H
	if ooAvFkt4MQbn7m==hT7zFDpEyUqf8sXuN:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	XaCF3qefsmgN = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,ooAvFkt4MQbn7m,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if XaCF3qefsmgN!=1:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم الإلغاء')
		return
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.referer_'+wiWn9NIP6XG,ooAvFkt4MQbn7m)
	ArJS5DFPgnf4ea3KoNV(wiWn9NIP6XG)
	return
def UZunqWaibYvmr1zhMOK4AJ(wiWn9NIP6XG,VVkWSPbgxujcZE8mRiU=QigevCplXxbPI1H):
	if not SSzL1XUTMen8fO0EZl2jyDmbc: SSzL1XUTMen8fO0EZl2jyDmbc = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.url_'+wiWn9NIP6XG)
	zqr2pO8XK5CoZi9uHwQTtsxLVkGP = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(SSzL1XUTMen8fO0EZl2jyDmbc,'url')
	qqgeBldQsSGocHAx = sBvufaD6c9YHdOqTjCQ3.findall('username=(.*?)&',SSzL1XUTMen8fO0EZl2jyDmbc+'&',sBvufaD6c9YHdOqTjCQ3.DOTALL)
	hvgPWl0BteqJNjMOkZC = sBvufaD6c9YHdOqTjCQ3.findall('password=(.*?)&',SSzL1XUTMen8fO0EZl2jyDmbc+'&',sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not qqgeBldQsSGocHAx or not hvgPWl0BteqJNjMOkZC:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	qqgeBldQsSGocHAx = qqgeBldQsSGocHAx[0]
	hvgPWl0BteqJNjMOkZC = hvgPWl0BteqJNjMOkZC[0]
	gsRbHLpw8V4oxhnZuW = zqr2pO8XK5CoZi9uHwQTtsxLVkGP+'/player_api.php?username='+qqgeBldQsSGocHAx+'&password='+hvgPWl0BteqJNjMOkZC
	N4aCiYwI2szoFfrqEWmV0jtTeX = zqr2pO8XK5CoZi9uHwQTtsxLVkGP+'/get.php?username='+qqgeBldQsSGocHAx+'&password='+hvgPWl0BteqJNjMOkZC+'&type=m3u_plus'
	return gsRbHLpw8V4oxhnZuW,N4aCiYwI2szoFfrqEWmV0jtTeX,zqr2pO8XK5CoZi9uHwQTtsxLVkGP,qqgeBldQsSGocHAx,hvgPWl0BteqJNjMOkZC
def ejZSs8nYUhdIbXQ(wiWn9NIP6XG,JbN0MHFCGqBg=QigevCplXxbPI1H):
	xqiApJPacfut2 = JbN0MHFCGqBg.replace('/','_').replace(':','_').replace('.','_')
	xqiApJPacfut2 = xqiApJPacfut2.replace('?','_').replace('=','_').replace('&','_')
	xqiApJPacfut2 = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,xqiApJPacfut2).strip('.m3u')+'.m3u'
	return xqiApJPacfut2
def WWyGcmtUOg85nDhwYAdpvXLFilfK(wiWn9NIP6XG,ivF0XNlyjxR7TWA12):
	cvdZyBWmLGUQXrM1gw9OJDH8pSKC = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.url_'+wiWn9NIP6XG+'_'+ivF0XNlyjxR7TWA12)
	EEkQOq4tpRTno = True
	if cvdZyBWmLGUQXrM1gw9OJDH8pSKC:
		XaCF3qefsmgN = L2Lu1MQVHhiTX0('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',iVCLpNIM8BQs9PdSgKZvlFeo3a5+cvdZyBWmLGUQXrM1gw9OJDH8pSKC+jhAlCQ47ZgG+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if XaCF3qefsmgN==-1: return
		elif XaCF3qefsmgN==0: cvdZyBWmLGUQXrM1gw9OJDH8pSKC = QigevCplXxbPI1H
		elif XaCF3qefsmgN==2:
			XaCF3qefsmgN = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if XaCF3qefsmgN in [-1,0]: return
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم مسح الرابط')
			EEkQOq4tpRTno = False
			v2EGXfWJClaNioZzBMuxm63y = QigevCplXxbPI1H
	if EEkQOq4tpRTno:
		v2EGXfWJClaNioZzBMuxm63y = XAfEvmh95VkgurjdiJ('اكتب رابط M3U كاملا',cvdZyBWmLGUQXrM1gw9OJDH8pSKC)
		v2EGXfWJClaNioZzBMuxm63y = v2EGXfWJClaNioZzBMuxm63y.strip(hT7zFDpEyUqf8sXuN)
		if not v2EGXfWJClaNioZzBMuxm63y:
			XaCF3qefsmgN = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if XaCF3qefsmgN in [-1,0]: return
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم مسح الرابط')
		else:
			nDRKguWex0iVN8 = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			XaCF3qefsmgN = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'الرابط الجديد هو:',iVCLpNIM8BQs9PdSgKZvlFeo3a5+v2EGXfWJClaNioZzBMuxm63y+jhAlCQ47ZgG+'\n\n'+nDRKguWex0iVN8)
			if XaCF3qefsmgN!=1:
				lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم الإلغاء')
				return
	uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.url_'+wiWn9NIP6XG+'_'+ivF0XNlyjxR7TWA12,v2EGXfWJClaNioZzBMuxm63y)
	JscYrBTLU4QEejuMywG6 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.useragent_'+wiWn9NIP6XG)
	if not JscYrBTLU4QEejuMywG6: uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.useragent_'+wiWn9NIP6XG,'Unknown')
	ArJS5DFPgnf4ea3KoNV(wiWn9NIP6XG)
	return
def jors6IM9WbaPN8(kcZDbGjVROS96nrzfL1wpq2te,NE12mzZnrWeKjhu4HIFVBgk,eyvLuS473W1CIgcFoTNfnG,fPwYupnlAg57qIVUkhBQJRdsrK6,Y6aKlGeH3p8BvbR,Aevbx5WrR2zHw3noa8VX9m0jNUtqCL,N4aCiYwI2szoFfrqEWmV0jtTeX):
	eZrCtjVSdlx3Q70,i6RAfaYHydLmVzjb = [],[]
	NOk69U8dCI1PmroScTD2vKaiYWHM = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
		if Aevbx5WrR2zHw3noa8VX9m0jNUtqCL%473==0:
			flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,40+int(10*Aevbx5WrR2zHw3noa8VX9m0jNUtqCL/Y6aKlGeH3p8BvbR),'قراءة الفيديوهات','الفيديو رقم:-',str(Aevbx5WrR2zHw3noa8VX9m0jNUtqCL)+' / '+str(Y6aKlGeH3p8BvbR))
			if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
				fPwYupnlAg57qIVUkhBQJRdsrK6.close()
				return None,None,None
		XCapNbgw2xWQ5jRt = sBvufaD6c9YHdOqTjCQ3.findall('^(.*?)\n+((http|https|rtmp).*?)$',Sy8dRNAqBu,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if XCapNbgw2xWQ5jRt:
			Sy8dRNAqBu,XCapNbgw2xWQ5jRt,eAYEQ2kZ8w1yua7PDKcJXrhV6R3p = XCapNbgw2xWQ5jRt[0]
			XCapNbgw2xWQ5jRt = XCapNbgw2xWQ5jRt.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
			Sy8dRNAqBu = Sy8dRNAqBu.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
		else:
			i6RAfaYHydLmVzjb.append({'line':Sy8dRNAqBu})
			continue
		pWrms5v84hEyJ1Uqlt0N,SFQtU7cnyeo,KKQDtNb1Awl5Jy3vWIEYFaU6kq,aotWnjvVy8k3iS,pf6P4wckhgTa,CCdv3uLQcTI2ABSNs14DtzGg5Vy6Ym = {},QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,False
		try:
			Sy8dRNAqBu,aotWnjvVy8k3iS = Sy8dRNAqBu.rsplit('",',1)
			Sy8dRNAqBu = Sy8dRNAqBu+'"'
		except:
			try: Sy8dRNAqBu,aotWnjvVy8k3iS = Sy8dRNAqBu.rsplit('1,',1)
			except: aotWnjvVy8k3iS = QigevCplXxbPI1H
		pWrms5v84hEyJ1Uqlt0N['url'] = XCapNbgw2xWQ5jRt
		hNnEztVebf = sBvufaD6c9YHdOqTjCQ3.findall(' (.*?)="(.*?)"',Sy8dRNAqBu,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for Z6ZpWLOjfodPKl3QVqrTYai8MBA9,K98qyBI4dRrCLmhPviSoN13DxW5b in hNnEztVebf:
			Z6ZpWLOjfodPKl3QVqrTYai8MBA9 = Z6ZpWLOjfodPKl3QVqrTYai8MBA9.replace('"',QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			pWrms5v84hEyJ1Uqlt0N[Z6ZpWLOjfodPKl3QVqrTYai8MBA9] = K98qyBI4dRrCLmhPviSoN13DxW5b.strip(hT7zFDpEyUqf8sXuN)
		epdY4LAC7a2KQbU8D = list(pWrms5v84hEyJ1Uqlt0N.keys())
		if not aotWnjvVy8k3iS:
			if 'name' in epdY4LAC7a2KQbU8D and pWrms5v84hEyJ1Uqlt0N['name']: aotWnjvVy8k3iS = pWrms5v84hEyJ1Uqlt0N['name']
		pWrms5v84hEyJ1Uqlt0N['title'] = aotWnjvVy8k3iS.strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
		if 'logo' in epdY4LAC7a2KQbU8D:
			pWrms5v84hEyJ1Uqlt0N['img'] = pWrms5v84hEyJ1Uqlt0N['logo']
			del pWrms5v84hEyJ1Uqlt0N['logo']
		else: pWrms5v84hEyJ1Uqlt0N['img'] = QigevCplXxbPI1H
		if 'group' in epdY4LAC7a2KQbU8D and pWrms5v84hEyJ1Uqlt0N['group']: KKQDtNb1Awl5Jy3vWIEYFaU6kq = pWrms5v84hEyJ1Uqlt0N['group']
		if any(nFdGHjceZzW in XCapNbgw2xWQ5jRt.lower() for nFdGHjceZzW in NOk69U8dCI1PmroScTD2vKaiYWHM):
			CCdv3uLQcTI2ABSNs14DtzGg5Vy6Ym = True if 'm3u' not in XCapNbgw2xWQ5jRt else False
		if CCdv3uLQcTI2ABSNs14DtzGg5Vy6Ym or '__SERIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq or '__MOVIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq:
			pf6P4wckhgTa = 'VOD'
			if '__SERIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq: pf6P4wckhgTa = pf6P4wckhgTa+'_SERIES'
			elif '__MOVIES__' in KKQDtNb1Awl5Jy3vWIEYFaU6kq: pf6P4wckhgTa = pf6P4wckhgTa+'_MOVIES'
			else: pf6P4wckhgTa = pf6P4wckhgTa+'_UNKNOWN'
			KKQDtNb1Awl5Jy3vWIEYFaU6kq = KKQDtNb1Awl5Jy3vWIEYFaU6kq.replace('__SERIES__',QigevCplXxbPI1H).replace('__MOVIES__',QigevCplXxbPI1H)
		else:
			pf6P4wckhgTa = 'LIVE'
			if aotWnjvVy8k3iS in NE12mzZnrWeKjhu4HIFVBgk: SFQtU7cnyeo = SFQtU7cnyeo+'_EPG'
			if aotWnjvVy8k3iS in eyvLuS473W1CIgcFoTNfnG: SFQtU7cnyeo = SFQtU7cnyeo+'_ARCHIVED'
			if not KKQDtNb1Awl5Jy3vWIEYFaU6kq: pf6P4wckhgTa = pf6P4wckhgTa+'_UNKNOWN'
			else: pf6P4wckhgTa = pf6P4wckhgTa+SFQtU7cnyeo
		KKQDtNb1Awl5Jy3vWIEYFaU6kq = KKQDtNb1Awl5Jy3vWIEYFaU6kq.strip(hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
		if 'LIVE_UNKNOWN' in pf6P4wckhgTa: KKQDtNb1Awl5Jy3vWIEYFaU6kq = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in pf6P4wckhgTa: KKQDtNb1Awl5Jy3vWIEYFaU6kq = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in pf6P4wckhgTa:
			bu8GSMPQNIRaW395j = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) [Ss]\d+ +[Ee]\d+',pWrms5v84hEyJ1Uqlt0N['title'],sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if bu8GSMPQNIRaW395j: bu8GSMPQNIRaW395j = bu8GSMPQNIRaW395j[0]
			else: bu8GSMPQNIRaW395j = '!!__UNKNOWN_SERIES__!!'
			KKQDtNb1Awl5Jy3vWIEYFaU6kq = KKQDtNb1Awl5Jy3vWIEYFaU6kq+'__SERIES__'+bu8GSMPQNIRaW395j
		if 'id' in epdY4LAC7a2KQbU8D: del pWrms5v84hEyJ1Uqlt0N['id']
		if 'ID' in epdY4LAC7a2KQbU8D: del pWrms5v84hEyJ1Uqlt0N['ID']
		if 'name' in epdY4LAC7a2KQbU8D: del pWrms5v84hEyJ1Uqlt0N['name']
		aotWnjvVy8k3iS = pWrms5v84hEyJ1Uqlt0N['title']
		aotWnjvVy8k3iS = arFSQucmG9HxDody67JCI8pBMk4L(aotWnjvVy8k3iS)
		aotWnjvVy8k3iS = V8VLJi0fGUvDuzEYI1gXQ4On9tSe(aotWnjvVy8k3iS)
		XEHlOmstJZikCA9,KKQDtNb1Awl5Jy3vWIEYFaU6kq = uyow1a7ngVRXtlsIO0KcYF(KKQDtNb1Awl5Jy3vWIEYFaU6kq)
		LbZukwX9MUArBG4ta10,aotWnjvVy8k3iS = uyow1a7ngVRXtlsIO0KcYF(aotWnjvVy8k3iS)
		pWrms5v84hEyJ1Uqlt0N['type'] = pf6P4wckhgTa
		pWrms5v84hEyJ1Uqlt0N['context'] = SFQtU7cnyeo
		pWrms5v84hEyJ1Uqlt0N['group'] = KKQDtNb1Awl5Jy3vWIEYFaU6kq.upper()
		pWrms5v84hEyJ1Uqlt0N['title'] = aotWnjvVy8k3iS.upper()
		pWrms5v84hEyJ1Uqlt0N['country'] = LbZukwX9MUArBG4ta10.upper()
		pWrms5v84hEyJ1Uqlt0N['language'] = XEHlOmstJZikCA9.upper()
		eZrCtjVSdlx3Q70.append(pWrms5v84hEyJ1Uqlt0N)
		Aevbx5WrR2zHw3noa8VX9m0jNUtqCL += 1
	return eZrCtjVSdlx3Q70,Aevbx5WrR2zHw3noa8VX9m0jNUtqCL,i6RAfaYHydLmVzjb
def V8VLJi0fGUvDuzEYI1gXQ4On9tSe(aotWnjvVy8k3iS):
	aotWnjvVy8k3iS = aotWnjvVy8k3iS.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	aotWnjvVy8k3iS = aotWnjvVy8k3iS.replace('||','|').replace('___',':').replace('--','-')
	aotWnjvVy8k3iS = aotWnjvVy8k3iS.replace('[[','[').replace(']]',']')
	aotWnjvVy8k3iS = aotWnjvVy8k3iS.replace('((','(').replace('))',')')
	aotWnjvVy8k3iS = aotWnjvVy8k3iS.replace('<<','<').replace('>>','>')
	aotWnjvVy8k3iS = aotWnjvVy8k3iS.strip(hT7zFDpEyUqf8sXuN)
	return aotWnjvVy8k3iS
def LL62WuFkyJZ10RxagTzbodfX93iDQG(maKYQxUNEPiX9oG,fPwYupnlAg57qIVUkhBQJRdsrK6,ivF0XNlyjxR7TWA12):
	E9ERJgnNAWfHL10s3UVCTc2Po6 = {}
	for NdyL4wCF2xV in AI5jVSyzuU4: E9ERJgnNAWfHL10s3UVCTc2Po6[NdyL4wCF2xV+'_'+ivF0XNlyjxR7TWA12] = []
	Y6aKlGeH3p8BvbR = len(maKYQxUNEPiX9oG)
	NcZHhy5TUvdCKP = str(Y6aKlGeH3p8BvbR)
	Aevbx5WrR2zHw3noa8VX9m0jNUtqCL = 0
	i6RAfaYHydLmVzjb = []
	for pWrms5v84hEyJ1Uqlt0N in maKYQxUNEPiX9oG:
		if Aevbx5WrR2zHw3noa8VX9m0jNUtqCL%873==0:
			flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,50+int(5*Aevbx5WrR2zHw3noa8VX9m0jNUtqCL/Y6aKlGeH3p8BvbR),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(Aevbx5WrR2zHw3noa8VX9m0jNUtqCL)+' / '+NcZHhy5TUvdCKP)
			if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
				fPwYupnlAg57qIVUkhBQJRdsrK6.close()
				return None,None
		KKQDtNb1Awl5Jy3vWIEYFaU6kq,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m = pWrms5v84hEyJ1Uqlt0N['group'],pWrms5v84hEyJ1Uqlt0N['context'],pWrms5v84hEyJ1Uqlt0N['title'],pWrms5v84hEyJ1Uqlt0N['url'],pWrms5v84hEyJ1Uqlt0N['img']
		LbZukwX9MUArBG4ta10,XEHlOmstJZikCA9,NdyL4wCF2xV = pWrms5v84hEyJ1Uqlt0N['country'],pWrms5v84hEyJ1Uqlt0N['language'],pWrms5v84hEyJ1Uqlt0N['type']
		xY0SunXWQepv78c2j31dso = (KKQDtNb1Awl5Jy3vWIEYFaU6kq,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m)
		NNuAGmwfaso70 = False
		if 'LIVE' in NdyL4wCF2xV:
			if 'UNKNOWN' in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_UNKNOWN_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			elif 'LIVE' in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			else: NNuAGmwfaso70 = True
			E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_ORIGINAL_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
		elif 'VOD' in NdyL4wCF2xV:
			if 'UNKNOWN' in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_UNKNOWN_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			elif 'MOVIES' in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_MOVIES_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			elif 'SERIES' in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_SERIES_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			else: NNuAGmwfaso70 = True
			E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_ORIGINAL_GROUPED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
		else: NNuAGmwfaso70 = True
		if NNuAGmwfaso70: i6RAfaYHydLmVzjb.append(pWrms5v84hEyJ1Uqlt0N)
		Aevbx5WrR2zHw3noa8VX9m0jNUtqCL += 1
	hSG6Apb5CEDf4UI3WdTlKFRuimtoV = sorted(maKYQxUNEPiX9oG,reverse=False,key=lambda Z6ZpWLOjfodPKl3QVqrTYai8MBA9: Z6ZpWLOjfodPKl3QVqrTYai8MBA9['title'].lower())
	del maKYQxUNEPiX9oG
	NcZHhy5TUvdCKP = str(Y6aKlGeH3p8BvbR)
	Aevbx5WrR2zHw3noa8VX9m0jNUtqCL = 0
	for pWrms5v84hEyJ1Uqlt0N in hSG6Apb5CEDf4UI3WdTlKFRuimtoV:
		Aevbx5WrR2zHw3noa8VX9m0jNUtqCL += 1
		if Aevbx5WrR2zHw3noa8VX9m0jNUtqCL%873==0:
			flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,55+int(5*Aevbx5WrR2zHw3noa8VX9m0jNUtqCL/Y6aKlGeH3p8BvbR),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(Aevbx5WrR2zHw3noa8VX9m0jNUtqCL)+' / '+NcZHhy5TUvdCKP)
			if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
				fPwYupnlAg57qIVUkhBQJRdsrK6.close()
				return None,None
		NdyL4wCF2xV = pWrms5v84hEyJ1Uqlt0N['type']
		KKQDtNb1Awl5Jy3vWIEYFaU6kq,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m = pWrms5v84hEyJ1Uqlt0N['group'],pWrms5v84hEyJ1Uqlt0N['context'],pWrms5v84hEyJ1Uqlt0N['title'],pWrms5v84hEyJ1Uqlt0N['url'],pWrms5v84hEyJ1Uqlt0N['img']
		LbZukwX9MUArBG4ta10,XEHlOmstJZikCA9 = pWrms5v84hEyJ1Uqlt0N['country'],pWrms5v84hEyJ1Uqlt0N['language']
		Xh2p8KFBM4zySlwTEd = (KKQDtNb1Awl5Jy3vWIEYFaU6kq,SFQtU7cnyeo+'_TIMESHIFT',aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m)
		xY0SunXWQepv78c2j31dso = (KKQDtNb1Awl5Jy3vWIEYFaU6kq,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m)
		TkMLg04OvxtjS = (LbZukwX9MUArBG4ta10,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m)
		jjRrzHDnwGePXY = (XEHlOmstJZikCA9,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m)
		if 'LIVE' in NdyL4wCF2xV:
			if 'UNKNOWN' in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_UNKNOWN_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			else: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			if 'EPG'		in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_EPG_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			if 'ARCHIVED'	in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_ARCHIVED_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			if 'ARCHIVED'	in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_TIMESHIFT_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(Xh2p8KFBM4zySlwTEd)
			E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_FROM_NAME_SORTED_'+ivF0XNlyjxR7TWA12].append(TkMLg04OvxtjS)
			E9ERJgnNAWfHL10s3UVCTc2Po6['LIVE_FROM_GROUP_SORTED_'+ivF0XNlyjxR7TWA12].append(jjRrzHDnwGePXY)
		elif 'VOD' in NdyL4wCF2xV:
			if   'UNKNOWN'	in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_UNKNOWN_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			elif 'MOVIES'	in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_MOVIES_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			elif 'SERIES'	in NdyL4wCF2xV: E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_SERIES_GROUPED_SORTED_'+ivF0XNlyjxR7TWA12].append(xY0SunXWQepv78c2j31dso)
			E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_FROM_NAME_SORTED_'+ivF0XNlyjxR7TWA12].append(TkMLg04OvxtjS)
			E9ERJgnNAWfHL10s3UVCTc2Po6['VOD_FROM_GROUP_SORTED_'+ivF0XNlyjxR7TWA12].append(jjRrzHDnwGePXY)
	return E9ERJgnNAWfHL10s3UVCTc2Po6,i6RAfaYHydLmVzjb
def uyow1a7ngVRXtlsIO0KcYF(aotWnjvVy8k3iS):
	if len(aotWnjvVy8k3iS)<3: return aotWnjvVy8k3iS,aotWnjvVy8k3iS
	cXnibjZo95leMaFHJRkE7UBz3GYgvD,MCiQEPT2GYy6Hp3rR5zFl1 = QigevCplXxbPI1H,QigevCplXxbPI1H
	woe4bkrxQByjz = aotWnjvVy8k3iS
	MrF2vGpe9KsT1DiLJP5 = aotWnjvVy8k3iS[:1]
	nQ7qgBZji5DVFfA9wuPr83 = aotWnjvVy8k3iS[1:]
	if   MrF2vGpe9KsT1DiLJP5=='(': MCiQEPT2GYy6Hp3rR5zFl1 = ')'
	elif MrF2vGpe9KsT1DiLJP5=='[': MCiQEPT2GYy6Hp3rR5zFl1 = ']'
	elif MrF2vGpe9KsT1DiLJP5=='<': MCiQEPT2GYy6Hp3rR5zFl1 = '>'
	elif MrF2vGpe9KsT1DiLJP5=='|': MCiQEPT2GYy6Hp3rR5zFl1 = '|'
	if MCiQEPT2GYy6Hp3rR5zFl1 and (MCiQEPT2GYy6Hp3rR5zFl1 in nQ7qgBZji5DVFfA9wuPr83):
		J5YIZOMWCypP0,xzWmA1QjoqgTGFKXPtuZMfi3 = nQ7qgBZji5DVFfA9wuPr83.split(MCiQEPT2GYy6Hp3rR5zFl1,1)
		cXnibjZo95leMaFHJRkE7UBz3GYgvD = J5YIZOMWCypP0
		woe4bkrxQByjz = MrF2vGpe9KsT1DiLJP5+J5YIZOMWCypP0+MCiQEPT2GYy6Hp3rR5zFl1+hT7zFDpEyUqf8sXuN+xzWmA1QjoqgTGFKXPtuZMfi3
	elif aotWnjvVy8k3iS.count('|')>=2:
		J5YIZOMWCypP0,xzWmA1QjoqgTGFKXPtuZMfi3 = aotWnjvVy8k3iS.split('|',1)
		cXnibjZo95leMaFHJRkE7UBz3GYgvD = J5YIZOMWCypP0
		woe4bkrxQByjz = J5YIZOMWCypP0+' |'+xzWmA1QjoqgTGFKXPtuZMfi3
	else:
		MCiQEPT2GYy6Hp3rR5zFl1 = sBvufaD6c9YHdOqTjCQ3.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',aotWnjvVy8k3iS,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not MCiQEPT2GYy6Hp3rR5zFl1: MCiQEPT2GYy6Hp3rR5zFl1 = sBvufaD6c9YHdOqTjCQ3.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',aotWnjvVy8k3iS,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not MCiQEPT2GYy6Hp3rR5zFl1: MCiQEPT2GYy6Hp3rR5zFl1 = sBvufaD6c9YHdOqTjCQ3.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',aotWnjvVy8k3iS,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if MCiQEPT2GYy6Hp3rR5zFl1:
			J5YIZOMWCypP0,xzWmA1QjoqgTGFKXPtuZMfi3 = aotWnjvVy8k3iS.split(MCiQEPT2GYy6Hp3rR5zFl1[0],1)
			cXnibjZo95leMaFHJRkE7UBz3GYgvD = J5YIZOMWCypP0
			woe4bkrxQByjz = J5YIZOMWCypP0+hT7zFDpEyUqf8sXuN+MCiQEPT2GYy6Hp3rR5zFl1[0]+hT7zFDpEyUqf8sXuN+xzWmA1QjoqgTGFKXPtuZMfi3
	woe4bkrxQByjz = woe4bkrxQByjz.replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	cXnibjZo95leMaFHJRkE7UBz3GYgvD = cXnibjZo95leMaFHJRkE7UBz3GYgvD.replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	if not cXnibjZo95leMaFHJRkE7UBz3GYgvD: cXnibjZo95leMaFHJRkE7UBz3GYgvD = '!!__UNKNOWN__!!'
	cXnibjZo95leMaFHJRkE7UBz3GYgvD = cXnibjZo95leMaFHJRkE7UBz3GYgvD.strip(hT7zFDpEyUqf8sXuN)
	woe4bkrxQByjz = woe4bkrxQByjz.strip(hT7zFDpEyUqf8sXuN)
	return cXnibjZo95leMaFHJRkE7UBz3GYgvD,woe4bkrxQByjz
def uPO26bDTs5ZA(wiWn9NIP6XG):
	UFtxHq7c39mD = {}
	JscYrBTLU4QEejuMywG6 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.useragent_'+wiWn9NIP6XG)
	if JscYrBTLU4QEejuMywG6: UFtxHq7c39mD['User-Agent'] = JscYrBTLU4QEejuMywG6
	ooAvFkt4MQbn7m = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.referer_'+wiWn9NIP6XG)
	if ooAvFkt4MQbn7m: UFtxHq7c39mD['Referer'] = ooAvFkt4MQbn7m
	return UFtxHq7c39mD
def BjYtnCJv0NHPROm6VUc(wiWn9NIP6XG,ivF0XNlyjxR7TWA12):
	global fPwYupnlAg57qIVUkhBQJRdsrK6,E9ERJgnNAWfHL10s3UVCTc2Po6,UvuLTMEXPahZp,reR6x2LqKpVmdY7jDto3C4OygF9,YY0zwKdupEaTbg3,heT4Yup97BVd3bXlcWCqQfDwIP,ifWArxpvm6oJUNKEe4gdk0,Sc1LwAIryJWf7s2U3E,OWEjbpcm8wxi16H
	N4aCiYwI2szoFfrqEWmV0jtTeX = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.url_'+wiWn9NIP6XG+'_'+ivF0XNlyjxR7TWA12)
	JscYrBTLU4QEejuMywG6 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.useragent_'+wiWn9NIP6XG)
	UFtxHq7c39mD = {'User-Agent':JscYrBTLU4QEejuMywG6}
	xqiApJPacfut2 = qOm1IJUYKPiroj59ZHnkXDVy6zMw.replace('___','_'+wiWn9NIP6XG+'_'+ivF0XNlyjxR7TWA12)
	if 1:
		jgA5IRNqLonwC47,IIHx8tTugDeGLV4l6SiFvPohp5,v5SYTclVo1yUrH = True,QigevCplXxbPI1H,QigevCplXxbPI1H
		if not jgA5IRNqLonwC47:
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not N4aCiYwI2szoFfrqEWmV0jtTeX: SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+'   No M3U URL found to download M3U files')
			else: SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(JwBc6IZ4xeLmM8)+'   Failed to download M3U files')
			return
		JxbaBnTtC0HEsS8M97c1qv = HMm6TqGlgU75axyS(N4aCiYwI2szoFfrqEWmV0jtTeX,UFtxHq7c39mD,True)
		if not JxbaBnTtC0HEsS8M97c1qv: return
		open(xqiApJPacfut2,'wb').write(JxbaBnTtC0HEsS8M97c1qv)
	else: JxbaBnTtC0HEsS8M97c1qv = open(xqiApJPacfut2,'rb').read()
	if b7sJAmSxlBvaMdHFz and JxbaBnTtC0HEsS8M97c1qv: JxbaBnTtC0HEsS8M97c1qv = JxbaBnTtC0HEsS8M97c1qv.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
	fPwYupnlAg57qIVUkhBQJRdsrK6 = EkO3SZvUhBmswzoC2cKRbfxyMYW7H()
	fPwYupnlAg57qIVUkhBQJRdsrK6.create('جلب ملفات M3U جديدة',QigevCplXxbPI1H)
	flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,15,'تنظيف الملف الرئيسي',QigevCplXxbPI1H)
	JxbaBnTtC0HEsS8M97c1qv = JxbaBnTtC0HEsS8M97c1qv.replace('"tvg-','" tvg-')
	JxbaBnTtC0HEsS8M97c1qv = JxbaBnTtC0HEsS8M97c1qv.replace('َ',QigevCplXxbPI1H).replace('ً',QigevCplXxbPI1H).replace('ُ',QigevCplXxbPI1H).replace('ٌ',QigevCplXxbPI1H)
	JxbaBnTtC0HEsS8M97c1qv = JxbaBnTtC0HEsS8M97c1qv.replace('ّ',QigevCplXxbPI1H).replace('ِ',QigevCplXxbPI1H).replace('ٍ',QigevCplXxbPI1H).replace('ْ',QigevCplXxbPI1H)
	JxbaBnTtC0HEsS8M97c1qv = JxbaBnTtC0HEsS8M97c1qv.replace('group-title=','group=').replace('tvg-',QigevCplXxbPI1H)
	eyvLuS473W1CIgcFoTNfnG,NE12mzZnrWeKjhu4HIFVBgk = [],[]
	JxbaBnTtC0HEsS8M97c1qv = JxbaBnTtC0HEsS8M97c1qv.replace(Ymkp8qFPsjovc57UT,aSBkt4OU8JpWTEzVIHjAiv)
	kcZDbGjVROS96nrzfL1wpq2te = sBvufaD6c9YHdOqTjCQ3.findall('NF:(.+?)'+'#'+'EXTI',JxbaBnTtC0HEsS8M97c1qv+'\n+'+'#'+'EXTINF:',sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if not kcZDbGjVROS96nrzfL1wpq2te:
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(JwBc6IZ4xeLmM8)+'   Folder:'+wiWn9NIP6XG+'  Sequence:'+ivF0XNlyjxR7TWA12+'   No video links found in M3U file')
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+aSBkt4OU8JpWTEzVIHjAiv+r9rhtA5Tek8sIoLfqwF7JcEV+'مجلد رقم '+wiWn9NIP6XG+'      رابط رقم '+ivF0XNlyjxR7TWA12+jhAlCQ47ZgG)
		fPwYupnlAg57qIVUkhBQJRdsrK6.close()
		return
	Ukyd9pgvEfsnH = []
	for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
		mn23TGS4aoWMUtX0 = Sy8dRNAqBu.lower()
		if 'adult' in mn23TGS4aoWMUtX0: continue
		if 'xxx' in mn23TGS4aoWMUtX0: continue
		Ukyd9pgvEfsnH.append(Sy8dRNAqBu)
	kcZDbGjVROS96nrzfL1wpq2te = Ukyd9pgvEfsnH
	del Ukyd9pgvEfsnH
	if 'iptv-org' in N4aCiYwI2szoFfrqEWmV0jtTeX:
		Ukyd9pgvEfsnH,rb7BycMiKhe4JtNdZgSC01 = [],[]
		for Sy8dRNAqBu in kcZDbGjVROS96nrzfL1wpq2te:
			heT4Yup97BVd3bXlcWCqQfDwIP = sBvufaD6c9YHdOqTjCQ3.findall('group="(.*?)"',Sy8dRNAqBu,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if heT4Yup97BVd3bXlcWCqQfDwIP:
				heT4Yup97BVd3bXlcWCqQfDwIP = heT4Yup97BVd3bXlcWCqQfDwIP[0]
				AQVaPsN5Dtcb0qOgiyhFE = heT4Yup97BVd3bXlcWCqQfDwIP.split(';')
				if 'region' in N4aCiYwI2szoFfrqEWmV0jtTeX: qYZhDbSrR3VWJvjsXB4Q = '1_'
				elif 'category' in N4aCiYwI2szoFfrqEWmV0jtTeX: qYZhDbSrR3VWJvjsXB4Q = '2_'
				elif 'language' in N4aCiYwI2szoFfrqEWmV0jtTeX: qYZhDbSrR3VWJvjsXB4Q = '3_'
				elif 'country' in N4aCiYwI2szoFfrqEWmV0jtTeX: qYZhDbSrR3VWJvjsXB4Q = '4_'
				else: qYZhDbSrR3VWJvjsXB4Q = '5_'
				wLvzSbjcRCNfQxWFgH9TruknB8 = Sy8dRNAqBu.replace('group="'+heT4Yup97BVd3bXlcWCqQfDwIP+'"','group="'+qYZhDbSrR3VWJvjsXB4Q+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				Ukyd9pgvEfsnH.append(wLvzSbjcRCNfQxWFgH9TruknB8)
				for KKQDtNb1Awl5Jy3vWIEYFaU6kq in AQVaPsN5Dtcb0qOgiyhFE:
					wLvzSbjcRCNfQxWFgH9TruknB8 = Sy8dRNAqBu.replace('group="'+heT4Yup97BVd3bXlcWCqQfDwIP+'"','group="'+qYZhDbSrR3VWJvjsXB4Q+KKQDtNb1Awl5Jy3vWIEYFaU6kq+'"')
					Ukyd9pgvEfsnH.append(wLvzSbjcRCNfQxWFgH9TruknB8)
			else: Ukyd9pgvEfsnH.append(Sy8dRNAqBu)
		kcZDbGjVROS96nrzfL1wpq2te = Ukyd9pgvEfsnH
		del Ukyd9pgvEfsnH,rb7BycMiKhe4JtNdZgSC01
	PH2mBspDet74Jlkbvi6Gn = 1024*1024
	GoZW4rix8cjnzvkpgmLY = 1+len(JxbaBnTtC0HEsS8M97c1qv)//PH2mBspDet74Jlkbvi6Gn//10
	del JxbaBnTtC0HEsS8M97c1qv
	HgPiIae4Su1 = len(kcZDbGjVROS96nrzfL1wpq2te)
	rb7BycMiKhe4JtNdZgSC01 = Web35Nz1LEIQvTrtK0U4HJ(kcZDbGjVROS96nrzfL1wpq2te,GoZW4rix8cjnzvkpgmLY)
	del kcZDbGjVROS96nrzfL1wpq2te
	for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(GoZW4rix8cjnzvkpgmLY):
		flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,35+int(5*DDSXKTgdvtyImN2aJYV35QGZjpkxoU/GoZW4rix8cjnzvkpgmLY),'تقطيع الملف الرئيسي','الجزء رقم:-',str(DDSXKTgdvtyImN2aJYV35QGZjpkxoU+1)+' / '+str(GoZW4rix8cjnzvkpgmLY))
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
			fPwYupnlAg57qIVUkhBQJRdsrK6.close()
			return
		HJGd63jrmZ9lAQCo = str(rb7BycMiKhe4JtNdZgSC01[DDSXKTgdvtyImN2aJYV35QGZjpkxoU])
		if b7sJAmSxlBvaMdHFz: HJGd63jrmZ9lAQCo = HJGd63jrmZ9lAQCo.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		open(xqiApJPacfut2+'.00'+str(DDSXKTgdvtyImN2aJYV35QGZjpkxoU),'wb').write(HJGd63jrmZ9lAQCo)
	del rb7BycMiKhe4JtNdZgSC01,HJGd63jrmZ9lAQCo
	c7uJWs4FOzQplg8KL1S6y,maKYQxUNEPiX9oG,Aevbx5WrR2zHw3noa8VX9m0jNUtqCL = [],[],0
	for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in range(GoZW4rix8cjnzvkpgmLY):
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
			fPwYupnlAg57qIVUkhBQJRdsrK6.close()
			return
		HJGd63jrmZ9lAQCo = open(xqiApJPacfut2+'.00'+str(DDSXKTgdvtyImN2aJYV35QGZjpkxoU),'rb').read()
		B3TKLo71hAGRqYgV0.sleep(1)
		try: KiTt9ZskMLjnCAUIJNXD7.remove(xqiApJPacfut2+'.00'+str(DDSXKTgdvtyImN2aJYV35QGZjpkxoU))
		except: pass
		if b7sJAmSxlBvaMdHFz: HJGd63jrmZ9lAQCo = HJGd63jrmZ9lAQCo.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		gI3f6WuAdqxV = CH86N7xw4cyPt3TlIBJF('list',HJGd63jrmZ9lAQCo)
		del HJGd63jrmZ9lAQCo
		eZrCtjVSdlx3Q70,Aevbx5WrR2zHw3noa8VX9m0jNUtqCL,i6RAfaYHydLmVzjb = jors6IM9WbaPN8(gI3f6WuAdqxV,NE12mzZnrWeKjhu4HIFVBgk,eyvLuS473W1CIgcFoTNfnG,fPwYupnlAg57qIVUkhBQJRdsrK6,HgPiIae4Su1,Aevbx5WrR2zHw3noa8VX9m0jNUtqCL,N4aCiYwI2szoFfrqEWmV0jtTeX)
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
			fPwYupnlAg57qIVUkhBQJRdsrK6.close()
			return
		if not eZrCtjVSdlx3Q70:
			fPwYupnlAg57qIVUkhBQJRdsrK6.close()
			return
		maKYQxUNEPiX9oG += eZrCtjVSdlx3Q70
		c7uJWs4FOzQplg8KL1S6y += i6RAfaYHydLmVzjb
	del gI3f6WuAdqxV,eZrCtjVSdlx3Q70
	E9ERJgnNAWfHL10s3UVCTc2Po6,i6RAfaYHydLmVzjb = LL62WuFkyJZ10RxagTzbodfX93iDQG(maKYQxUNEPiX9oG,fPwYupnlAg57qIVUkhBQJRdsrK6,ivF0XNlyjxR7TWA12)
	if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
		fPwYupnlAg57qIVUkhBQJRdsrK6.close()
		return
	c7uJWs4FOzQplg8KL1S6y += i6RAfaYHydLmVzjb
	del maKYQxUNEPiX9oG,i6RAfaYHydLmVzjb
	reR6x2LqKpVmdY7jDto3C4OygF9,YY0zwKdupEaTbg3,heT4Yup97BVd3bXlcWCqQfDwIP,ifWArxpvm6oJUNKEe4gdk0,Sc1LwAIryJWf7s2U3E = {},{},{},0,0
	bbfCJKkn4v8HpXuEiZ1Qmo = list(E9ERJgnNAWfHL10s3UVCTc2Po6.keys())
	OWEjbpcm8wxi16H = len(bbfCJKkn4v8HpXuEiZ1Qmo)*3
	if 1:
		GXHzaVZiDOhY = {}
		for alwxe3cuQACn067UZJpqkybP2it in bbfCJKkn4v8HpXuEiZ1Qmo:
			GXHzaVZiDOhY[alwxe3cuQACn067UZJpqkybP2it] = VVGXMeyJq25S6tf.Thread(target=OdHVseJ4miKZX,args=(alwxe3cuQACn067UZJpqkybP2it,))
			GXHzaVZiDOhY[alwxe3cuQACn067UZJpqkybP2it].start()
		for alwxe3cuQACn067UZJpqkybP2it in bbfCJKkn4v8HpXuEiZ1Qmo:
			GXHzaVZiDOhY[alwxe3cuQACn067UZJpqkybP2it].join()
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
			fPwYupnlAg57qIVUkhBQJRdsrK6.close()
			return
	else:
		for alwxe3cuQACn067UZJpqkybP2it in bbfCJKkn4v8HpXuEiZ1Qmo:
			OdHVseJ4miKZX(alwxe3cuQACn067UZJpqkybP2it)
			if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
				fPwYupnlAg57qIVUkhBQJRdsrK6.close()
				return
	qXNwIg1Zdx2YEAmG(wiWn9NIP6XG,ivF0XNlyjxR7TWA12,False)
	bbfCJKkn4v8HpXuEiZ1Qmo = list(reR6x2LqKpVmdY7jDto3C4OygF9.keys())
	UvuLTMEXPahZp = 0
	if 1:
		GXHzaVZiDOhY = {}
		for alwxe3cuQACn067UZJpqkybP2it in bbfCJKkn4v8HpXuEiZ1Qmo:
			GXHzaVZiDOhY[alwxe3cuQACn067UZJpqkybP2it] = VVGXMeyJq25S6tf.Thread(target=jeH7K90N1u4Xnytdr,args=(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it))
			GXHzaVZiDOhY[alwxe3cuQACn067UZJpqkybP2it].start()
		for alwxe3cuQACn067UZJpqkybP2it in bbfCJKkn4v8HpXuEiZ1Qmo:
			GXHzaVZiDOhY[alwxe3cuQACn067UZJpqkybP2it].join()
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
			fPwYupnlAg57qIVUkhBQJRdsrK6.close()
			return
	else:
		for alwxe3cuQACn067UZJpqkybP2it in bbfCJKkn4v8HpXuEiZ1Qmo:
			jeH7K90N1u4Xnytdr(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it)
			if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
				fPwYupnlAg57qIVUkhBQJRdsrK6.close()
				return
	DDSXKTgdvtyImN2aJYV35QGZjpkxoU = 0
	ZDifXdMHG6JElOFUIyok = len(c7uJWs4FOzQplg8KL1S6y)
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,'IGNORED')
	for mFCJRiKsG6jhIWr7HUP in c7uJWs4FOzQplg8KL1S6y:
		if DDSXKTgdvtyImN2aJYV35QGZjpkxoU%27==0:
			flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,95+int(5*DDSXKTgdvtyImN2aJYV35QGZjpkxoU//ZDifXdMHG6JElOFUIyok),'تخزين المهملة','الفيديو رقم:-',str(DDSXKTgdvtyImN2aJYV35QGZjpkxoU)+' / '+str(ZDifXdMHG6JElOFUIyok))
			if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled():
				fPwYupnlAg57qIVUkhBQJRdsrK6.close()
				return
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,'IGNORED_'+ivF0XNlyjxR7TWA12,str(mFCJRiKsG6jhIWr7HUP),QigevCplXxbPI1H,xfdjCmFwb0k8JAVegiL)
		DDSXKTgdvtyImN2aJYV35QGZjpkxoU += 1
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,'IGNORED_'+ivF0XNlyjxR7TWA12,'__COUNT__',str(ZDifXdMHG6JElOFUIyok),xfdjCmFwb0k8JAVegiL)
	fPwYupnlAg57qIVUkhBQJRdsrK6.close()
	B3TKLo71hAGRqYgV0.sleep(1)
	ArJS5DFPgnf4ea3KoNV(wiWn9NIP6XG)
	return
def OdHVseJ4miKZX(alwxe3cuQACn067UZJpqkybP2it):
	global fPwYupnlAg57qIVUkhBQJRdsrK6,E9ERJgnNAWfHL10s3UVCTc2Po6,UvuLTMEXPahZp,reR6x2LqKpVmdY7jDto3C4OygF9,YY0zwKdupEaTbg3,heT4Yup97BVd3bXlcWCqQfDwIP,ifWArxpvm6oJUNKEe4gdk0,Sc1LwAIryJWf7s2U3E,OWEjbpcm8wxi16H
	reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it] = {}
	xIQUyXevRuMBE8a4iGlTzSoq7sVdnj,pylu5i7XHY = {},[]
	TTRNPXYCyB9lOx = len(E9ERJgnNAWfHL10s3UVCTc2Po6[alwxe3cuQACn067UZJpqkybP2it])
	reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it]['__COUNT__'] = TTRNPXYCyB9lOx
	if TTRNPXYCyB9lOx>0:
		SSJ3atQb2uTmO,sR7tOzA6EVCJ4hS2MLKabilu9Nxg8m,HyG9Vco1kQKITB0WlUzLgFjXb6mZNe,NO7KmxFer3agouJ2ktM9A5zcn,dkVwgXtIhr3DsBP1FYNfeZ = zip(*E9ERJgnNAWfHL10s3UVCTc2Po6[alwxe3cuQACn067UZJpqkybP2it])
		del sR7tOzA6EVCJ4hS2MLKabilu9Nxg8m,HyG9Vco1kQKITB0WlUzLgFjXb6mZNe,NO7KmxFer3agouJ2ktM9A5zcn
		AQVaPsN5Dtcb0qOgiyhFE = list(set(SSJ3atQb2uTmO))
		for KKQDtNb1Awl5Jy3vWIEYFaU6kq in AQVaPsN5Dtcb0qOgiyhFE:
			xIQUyXevRuMBE8a4iGlTzSoq7sVdnj[KKQDtNb1Awl5Jy3vWIEYFaU6kq] = QigevCplXxbPI1H
			reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it][KKQDtNb1Awl5Jy3vWIEYFaU6kq] = []
		flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,60+int(15*Sc1LwAIryJWf7s2U3E//OWEjbpcm8wxi16H),'تصنيع القوائم','الجزء رقم:-',str(Sc1LwAIryJWf7s2U3E)+' / '+str(OWEjbpcm8wxi16H))
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled(): return
		Sc1LwAIryJWf7s2U3E += 1
		oQ3ryneHGB0WkxDt1O = len(AQVaPsN5Dtcb0qOgiyhFE)
		del AQVaPsN5Dtcb0qOgiyhFE
		pylu5i7XHY = list(set(zip(SSJ3atQb2uTmO,dkVwgXtIhr3DsBP1FYNfeZ)))
		del SSJ3atQb2uTmO,dkVwgXtIhr3DsBP1FYNfeZ
		for KKQDtNb1Awl5Jy3vWIEYFaU6kq,hhQxqntdaHTLE0V4UMXbOvgepKRG in pylu5i7XHY:
			if not xIQUyXevRuMBE8a4iGlTzSoq7sVdnj[KKQDtNb1Awl5Jy3vWIEYFaU6kq] and hhQxqntdaHTLE0V4UMXbOvgepKRG: xIQUyXevRuMBE8a4iGlTzSoq7sVdnj[KKQDtNb1Awl5Jy3vWIEYFaU6kq] = hhQxqntdaHTLE0V4UMXbOvgepKRG
		flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,60+int(15*Sc1LwAIryJWf7s2U3E//OWEjbpcm8wxi16H),'تصنيع القوائم','الجزء رقم:-',str(Sc1LwAIryJWf7s2U3E)+' / '+str(OWEjbpcm8wxi16H))
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled(): return
		Sc1LwAIryJWf7s2U3E += 1
		ysq4MzdTgvSZVaj7WcIEGlY = list(xIQUyXevRuMBE8a4iGlTzSoq7sVdnj.keys())
		K4O9EuR6pNcZzj5W7yd1GsIwh2 = list(xIQUyXevRuMBE8a4iGlTzSoq7sVdnj.values())
		del xIQUyXevRuMBE8a4iGlTzSoq7sVdnj
		pylu5i7XHY = list(zip(ysq4MzdTgvSZVaj7WcIEGlY,K4O9EuR6pNcZzj5W7yd1GsIwh2))
		del ysq4MzdTgvSZVaj7WcIEGlY,K4O9EuR6pNcZzj5W7yd1GsIwh2
		pylu5i7XHY = sorted(pylu5i7XHY)
	else: Sc1LwAIryJWf7s2U3E += 2
	reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it]['__GROUPS__'] = pylu5i7XHY
	del pylu5i7XHY
	for KKQDtNb1Awl5Jy3vWIEYFaU6kq,SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m in E9ERJgnNAWfHL10s3UVCTc2Po6[alwxe3cuQACn067UZJpqkybP2it]:
		reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it][KKQDtNb1Awl5Jy3vWIEYFaU6kq].append((SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m))
	flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,60+int(15*Sc1LwAIryJWf7s2U3E//OWEjbpcm8wxi16H),'تصنيع القوائم','الجزء رقم:-',str(Sc1LwAIryJWf7s2U3E)+' / '+str(OWEjbpcm8wxi16H))
	if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled(): return
	Sc1LwAIryJWf7s2U3E += 1
	del E9ERJgnNAWfHL10s3UVCTc2Po6[alwxe3cuQACn067UZJpqkybP2it]
	heT4Yup97BVd3bXlcWCqQfDwIP[alwxe3cuQACn067UZJpqkybP2it] = list(reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it].keys())
	YY0zwKdupEaTbg3[alwxe3cuQACn067UZJpqkybP2it] = len(heT4Yup97BVd3bXlcWCqQfDwIP[alwxe3cuQACn067UZJpqkybP2it])
	ifWArxpvm6oJUNKEe4gdk0 += YY0zwKdupEaTbg3[alwxe3cuQACn067UZJpqkybP2it]
	return
def jeH7K90N1u4Xnytdr(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it):
	global fPwYupnlAg57qIVUkhBQJRdsrK6,E9ERJgnNAWfHL10s3UVCTc2Po6,UvuLTMEXPahZp,reR6x2LqKpVmdY7jDto3C4OygF9,YY0zwKdupEaTbg3,heT4Yup97BVd3bXlcWCqQfDwIP,ifWArxpvm6oJUNKEe4gdk0,Sc1LwAIryJWf7s2U3E,OWEjbpcm8wxi16H
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it)
	for Aevbx5WrR2zHw3noa8VX9m0jNUtqCL in range(1+YY0zwKdupEaTbg3[alwxe3cuQACn067UZJpqkybP2it]//273):
		T2DfphxuGS0lQqn6OWEL4U = []
		XXY65wSpzoUAB8maQEJT4jInWqHg = heT4Yup97BVd3bXlcWCqQfDwIP[alwxe3cuQACn067UZJpqkybP2it][0:273]
		for KKQDtNb1Awl5Jy3vWIEYFaU6kq in XXY65wSpzoUAB8maQEJT4jInWqHg:
			T2DfphxuGS0lQqn6OWEL4U.append(reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it][KKQDtNb1Awl5Jy3vWIEYFaU6kq])
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,alwxe3cuQACn067UZJpqkybP2it,XXY65wSpzoUAB8maQEJT4jInWqHg,T2DfphxuGS0lQqn6OWEL4U,xfdjCmFwb0k8JAVegiL,True)
		UvuLTMEXPahZp += len(XXY65wSpzoUAB8maQEJT4jInWqHg)
		flLzKUbZqpmX(fPwYupnlAg57qIVUkhBQJRdsrK6,75+int(20*UvuLTMEXPahZp//ifWArxpvm6oJUNKEe4gdk0),'تخزين القوائم','القائمة رقم:-',str(UvuLTMEXPahZp)+' / '+str(ifWArxpvm6oJUNKEe4gdk0))
		if fPwYupnlAg57qIVUkhBQJRdsrK6.iscanceled(): return
		del heT4Yup97BVd3bXlcWCqQfDwIP[alwxe3cuQACn067UZJpqkybP2it][0:273]
	del reR6x2LqKpVmdY7jDto3C4OygF9[alwxe3cuQACn067UZJpqkybP2it],heT4Yup97BVd3bXlcWCqQfDwIP[alwxe3cuQACn067UZJpqkybP2it],YY0zwKdupEaTbg3[alwxe3cuQACn067UZJpqkybP2it]
	return
def vKVX0i1ZegUuWM9qzo7Ns6xJ(wiWn9NIP6XG,ivF0XNlyjxR7TWA12,YLb0uVtp5ZEChqf1In2zGNi4e=True):
	XdcDabowpZOGNvItUr47seHWCifS3K = 'عدد فيديوهات جميع الروابط'
	NNzMvakgOQRPZfcyqW1XV = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,'LIVE_ORIGINAL_GROUPED')
	MXUJhK7DObE1V5pla8cBo9 = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,'VOD_ORIGINAL_GROUPED')
	if ivF0XNlyjxR7TWA12:
		XdcDabowpZOGNvItUr47seHWCifS3K = 'عدد فيديوهات رابط '+qqfVzPxYZ5R[int(ivF0XNlyjxR7TWA12)]
		ivF0XNlyjxR7TWA12 = '_'+ivF0XNlyjxR7TWA12
	ZDifXdMHG6JElOFUIyok = wZ8QjMrd2u3V6TGxsmU(NNzMvakgOQRPZfcyqW1XV,'int','IGNORED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	cDZRnCpJSBQYljP456HyFKqkM = wZ8QjMrd2u3V6TGxsmU(NNzMvakgOQRPZfcyqW1XV,'int','LIVE_ORIGINAL_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	MEuc2SAYN7pWDmnwl = wZ8QjMrd2u3V6TGxsmU(MXUJhK7DObE1V5pla8cBo9,'int','VOD_ORIGINAL_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	UxF4SRcIl5s8yWuLG9dp0TEzmfZq = wZ8QjMrd2u3V6TGxsmU(NNzMvakgOQRPZfcyqW1XV,'int','LIVE_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	J8MPyFWNofkHuC = wZ8QjMrd2u3V6TGxsmU(NNzMvakgOQRPZfcyqW1XV,'int','LIVE_UNKNOWN_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	vWVgB1c6oIuzmxdhiPQGbFNalCyf7H = wZ8QjMrd2u3V6TGxsmU(NNzMvakgOQRPZfcyqW1XV,'int','VOD_MOVIES_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	yisFORNIqUdv6j13kcW4Q2 = wZ8QjMrd2u3V6TGxsmU(MXUJhK7DObE1V5pla8cBo9,'int','VOD_SERIES_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	lWNA1cItJ9jhZbC3UgQkRoP = wZ8QjMrd2u3V6TGxsmU(NNzMvakgOQRPZfcyqW1XV,'int','VOD_UNKNOWN_GROUPED'+ivF0XNlyjxR7TWA12,'__COUNT__')
	heT4Yup97BVd3bXlcWCqQfDwIP = wZ8QjMrd2u3V6TGxsmU(MXUJhK7DObE1V5pla8cBo9,'list','VOD_SERIES_GROUPED'+ivF0XNlyjxR7TWA12,'__GROUPS__')
	V0i3EGLh9S7 = []
	for KKQDtNb1Awl5Jy3vWIEYFaU6kq,AkHOcXEv2wJp7W085m in heT4Yup97BVd3bXlcWCqQfDwIP:
		LGpw7KN23uSYmbsq0Wf = KKQDtNb1Awl5Jy3vWIEYFaU6kq.split('__SERIES__')[1]
		V0i3EGLh9S7.append(LGpw7KN23uSYmbsq0Wf)
	kKUCO27P9yniVv = len(V0i3EGLh9S7)
	TTxDNLsAzuynXYK = int(vWVgB1c6oIuzmxdhiPQGbFNalCyf7H)+int(yisFORNIqUdv6j13kcW4Q2)+int(lWNA1cItJ9jhZbC3UgQkRoP)+int(J8MPyFWNofkHuC)+int(UxF4SRcIl5s8yWuLG9dp0TEzmfZq)
	LmPGiAj90UJtN2E1KxvBCb58rgFu = QigevCplXxbPI1H
	LmPGiAj90UJtN2E1KxvBCb58rgFu += 'قنوات: '+str(UxF4SRcIl5s8yWuLG9dp0TEzmfZq)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '   .   أفلام: '+str(vWVgB1c6oIuzmxdhiPQGbFNalCyf7H)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '\nمسلسلات: '+str(kKUCO27P9yniVv)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '   .   حلقات: '+str(yisFORNIqUdv6j13kcW4Q2)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '\nقنوات مجهولة: '+str(J8MPyFWNofkHuC)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '   .   فيدوهات مجهولة: '+str(lWNA1cItJ9jhZbC3UgQkRoP)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '\nمجموع القنوات: '+str(cDZRnCpJSBQYljP456HyFKqkM)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '   .   مجموع الفيديوهات: '+str(MEuc2SAYN7pWDmnwl)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '\n\nمجموع المضافة: '+str(TTxDNLsAzuynXYK)
	LmPGiAj90UJtN2E1KxvBCb58rgFu += '   .   مجموع المهملة: '+str(ZDifXdMHG6JElOFUIyok)
	if YLb0uVtp5ZEChqf1In2zGNi4e: lKfIRYspw15BD8vgtoAP('center',QigevCplXxbPI1H,XdcDabowpZOGNvItUr47seHWCifS3K,LmPGiAj90UJtN2E1KxvBCb58rgFu)
	HUXtReg92ac = LmPGiAj90UJtN2E1KxvBCb58rgFu.replace('\n\n',aSBkt4OU8JpWTEzVIHjAiv)
	if not ivF0XNlyjxR7TWA12: ivF0XNlyjxR7TWA12 = 'All'
	else: ivF0XNlyjxR7TWA12 = ivF0XNlyjxR7TWA12[1]
	SQdRhwozVfv(AwKhgdpmBj0,'.\tCounts of M3U videos   Folder: '+wiWn9NIP6XG+'   Sequence: '+ivF0XNlyjxR7TWA12+aSBkt4OU8JpWTEzVIHjAiv+HUXtReg92ac)
	return LmPGiAj90UJtN2E1KxvBCb58rgFu
def qXNwIg1Zdx2YEAmG(wiWn9NIP6XG,ivF0XNlyjxR7TWA12,YLb0uVtp5ZEChqf1In2zGNi4e=True):
	if YLb0uVtp5ZEChqf1In2zGNi4e:
		tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if tNVOmK5d8DvYoGr2!=1: return
		Ggv4tSadse02uJL1DZrnNfq = qOm1IJUYKPiroj59ZHnkXDVy6zMw.replace('___','_'+wiWn9NIP6XG+'_'+ivF0XNlyjxR7TWA12)
		try: KiTt9ZskMLjnCAUIJNXD7.remove(Ggv4tSadse02uJL1DZrnNfq)
		except: pass
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,QigevCplXxbPI1H)
	if ivF0XNlyjxR7TWA12:
		rjE9MxV6aySqZuQAnb1kWR = []
		for jzgmGF8uDvTy9k2 in AI5jVSyzuU4:
			rjE9MxV6aySqZuQAnb1kWR.append(jzgmGF8uDvTy9k2+'_'+ivF0XNlyjxR7TWA12)
		P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,'LINK_'+ivF0XNlyjxR7TWA12)
	else:
		rjE9MxV6aySqZuQAnb1kWR = AI5jVSyzuU4
		P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,'DUMMY')
		P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,'GROUPS')
		P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,'ITEMS')
		P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,'SEARCH')
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'SECTIONS_M3U','SECTIONS_M3U_'+wiWn9NIP6XG)
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for alwxe3cuQACn067UZJpqkybP2it in rjE9MxV6aySqZuQAnb1kWR:
		P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,alwxe3cuQACn067UZJpqkybP2it)
	MfFlidaIObTrEBK08eg(False)
	ArJS5DFPgnf4ea3KoNV(wiWn9NIP6XG)
	if YLb0uVtp5ZEChqf1In2zGNi4e: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def pQW09CG5Fojk4i(wiWn9NIP6XG=QigevCplXxbPI1H,YLb0uVtp5ZEChqf1In2zGNi4e=True):
	if wiWn9NIP6XG:
		R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(str(wiWn9NIP6XG),'DUMMY')
		eAYEQ2kZ8w1yua7PDKcJXrhV6R3p = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'str','DUMMY','__DUMMY__')
		if eAYEQ2kZ8w1yua7PDKcJXrhV6R3p: return True
	else:
		wiWn9NIP6XG = '1'
		for eSfNjkcdFXgrs8tUMDo75 in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
			R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(str(eSfNjkcdFXgrs8tUMDo75),'DUMMY')
			eAYEQ2kZ8w1yua7PDKcJXrhV6R3p = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'str','DUMMY','__DUMMY__')
			if eAYEQ2kZ8w1yua7PDKcJXrhV6R3p: return True
	if YLb0uVtp5ZEChqf1In2zGNi4e:
		WNU495LunH81pdtSBPJqw = 'https://iptv-org.github.io/iptv/index.region.m3u'
		tUVgSGoasFqh2dBKEk4YHcpiN = 'https://iptv-org.github.io/iptv/index.category.m3u'
		gBM17ns9jYFWx2RZ = 'https://iptv-org.github.io/iptv/index.language.m3u'
		dwyexUOMjT5az2hWRSu = 'https://iptv-org.github.io/iptv/index.country.m3u'
		PqGd9z5vYgWeZc0pQ2 = WNU495LunH81pdtSBPJqw+aSBkt4OU8JpWTEzVIHjAiv+tUVgSGoasFqh2dBKEk4YHcpiN+aSBkt4OU8JpWTEzVIHjAiv+gBM17ns9jYFWx2RZ+aSBkt4OU8JpWTEzVIHjAiv+dwyexUOMjT5az2hWRSu
		tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+PqGd9z5vYgWeZc0pQ2+jhAlCQ47ZgG,profile='confirm_mediumfont')
		if tNVOmK5d8DvYoGr2==1:
			uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.url_'+str(wiWn9NIP6XG)+'_1',WNU495LunH81pdtSBPJqw)
			uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.url_'+str(wiWn9NIP6XG)+'_2',tUVgSGoasFqh2dBKEk4YHcpiN)
			uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.url_'+str(wiWn9NIP6XG)+'_3',gBM17ns9jYFWx2RZ)
			uUTRHgAXJzm7pIDBjNt8.setSetting('av.m3u.url_'+str(wiWn9NIP6XG)+'_4',dwyexUOMjT5az2hWRSu)
			tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if tNVOmK5d8DvYoGr2==1:
				GG4QCqhPbHorI63lFjNwWO5XAt1Mu = UUQLCXmFkH4owN8SAJ7l3PcxV(wiWn9NIP6XG)
				return GG4QCqhPbHorI63lFjNwWO5XAt1Mu
		else:
			XdcDabowpZOGNvItUr47seHWCifS3K = 'إضافة وتغيير رابط '+qqfVzPxYZ5R[1]+' (مجلد '+qqfVzPxYZ5R[int(wiWn9NIP6XG)]+')'
			tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,XdcDabowpZOGNvItUr47seHWCifS3K,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if tNVOmK5d8DvYoGr2==1: WWyGcmtUOg85nDhwYAdpvXLFilfK(wiWn9NIP6XG,'1')
	return False
def xajb3VgNyPAo(ce6iHWubmXOLPBnK4Gd2QCxD,wiWn9NIP6XG=QigevCplXxbPI1H,alwxe3cuQACn067UZJpqkybP2it=QigevCplXxbPI1H,VjyFvc68g4YboUlHR=QigevCplXxbPI1H):
	if not VjyFvc68g4YboUlHR: VjyFvc68g4YboUlHR = '1'
	IghAzcTSrx1Wq6,ccKJQrzh9DnNO3jx,YLb0uVtp5ZEChqf1In2zGNi4e = RPLdkDS2mf6rvjb8e5yQ1hCu4(ce6iHWubmXOLPBnK4Gd2QCxD)
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e): return
	if not IghAzcTSrx1Wq6:
		IghAzcTSrx1Wq6 = XAfEvmh95VkgurjdiJ()
		if not IghAzcTSrx1Wq6: return
	Ew0v56kqBmNKxflF = [QigevCplXxbPI1H,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not alwxe3cuQACn067UZJpqkybP2it:
		if not YLb0uVtp5ZEChqf1In2zGNi4e:
			if   '_M3U-LIVE_' in ccKJQrzh9DnNO3jx: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[1]
			elif '_M3U-MOVIES' in ccKJQrzh9DnNO3jx: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[2]
			elif '_M3U-SERIES' in ccKJQrzh9DnNO3jx: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[3]
			else: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[0]
		else:
			CGSITpdkJv3h = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			BBt5dqgsIEbFNDCioAl = zYWJO03iISD('أختر البحث المناسب', CGSITpdkJv3h)
			if BBt5dqgsIEbFNDCioAl==-1: return
			alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[BBt5dqgsIEbFNDCioAl]
	IghAzcTSrx1Wq6 = IghAzcTSrx1Wq6+'_NODIALOGS_'
	if wiWn9NIP6XG: hIQfYFl7nKURr93vd4Hs2mNC(IghAzcTSrx1Wq6,wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it,VjyFvc68g4YboUlHR)
	else:
		for wiWn9NIP6XG in range(1,FNU9Shpblgo4mLkGQ3EOfyCJ0a+1):
			hIQfYFl7nKURr93vd4Hs2mNC(IghAzcTSrx1Wq6,str(wiWn9NIP6XG),alwxe3cuQACn067UZJpqkybP2it,VjyFvc68g4YboUlHR)
		lc0jJQ4zboeDI3tqTrpvm5gZO[:] = sorted(lc0jJQ4zboeDI3tqTrpvm5gZO,reverse=False,key=lambda Z6ZpWLOjfodPKl3QVqrTYai8MBA9: Z6ZpWLOjfodPKl3QVqrTYai8MBA9[1].lower())
	return
def hIQfYFl7nKURr93vd4Hs2mNC(ce6iHWubmXOLPBnK4Gd2QCxD,wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it=QigevCplXxbPI1H,VjyFvc68g4YboUlHR=QigevCplXxbPI1H):
	if not VjyFvc68g4YboUlHR: VjyFvc68g4YboUlHR = '1'
	IghAzcTSrx1Wq6,ccKJQrzh9DnNO3jx,YLb0uVtp5ZEChqf1In2zGNi4e = RPLdkDS2mf6rvjb8e5yQ1hCu4(ce6iHWubmXOLPBnK4Gd2QCxD)
	if not wiWn9NIP6XG: return
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e): return
	if not IghAzcTSrx1Wq6:
		IghAzcTSrx1Wq6 = XAfEvmh95VkgurjdiJ()
		if not IghAzcTSrx1Wq6: return
	Ew0v56kqBmNKxflF = [QigevCplXxbPI1H,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not alwxe3cuQACn067UZJpqkybP2it:
		if not YLb0uVtp5ZEChqf1In2zGNi4e:
			if   '_M3U-LIVE_' in ccKJQrzh9DnNO3jx: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[1]
			elif '_M3U-MOVIES' in ccKJQrzh9DnNO3jx: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[2]
			elif '_M3U-SERIES' in ccKJQrzh9DnNO3jx: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[3]
			else: alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[0]
		else:
			CGSITpdkJv3h = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			BBt5dqgsIEbFNDCioAl = zYWJO03iISD('أختر البحث المناسب', CGSITpdkJv3h)
			if BBt5dqgsIEbFNDCioAl==-1: return
			alwxe3cuQACn067UZJpqkybP2it = Ew0v56kqBmNKxflF[BBt5dqgsIEbFNDCioAl]
	yLKdhVuk8T0IAfZpe = IghAzcTSrx1Wq6.lower()
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,'SEARCH')
	JX4pLs7W5Mdm = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'list','SEARCH',(alwxe3cuQACn067UZJpqkybP2it,yLKdhVuk8T0IAfZpe))
	if not JX4pLs7W5Mdm:
		uuU3zsFNDHimYGRf,jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx = [],[]
		if not alwxe3cuQACn067UZJpqkybP2it: hZ9jYxD8lrfNdH = [1,2,3,4,5]
		else: hZ9jYxD8lrfNdH = [Ew0v56kqBmNKxflF.index(alwxe3cuQACn067UZJpqkybP2it)]
		for DDSXKTgdvtyImN2aJYV35QGZjpkxoU in hZ9jYxD8lrfNdH:
			if DDSXKTgdvtyImN2aJYV35QGZjpkxoU!=3:
				eZrCtjVSdlx3Q70 = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'dict',Ew0v56kqBmNKxflF[DDSXKTgdvtyImN2aJYV35QGZjpkxoU])
				del eZrCtjVSdlx3Q70['__COUNT__']
				del eZrCtjVSdlx3Q70['__GROUPS__']
				del eZrCtjVSdlx3Q70['__SEQUENCED_COLUMNS__']
				heT4Yup97BVd3bXlcWCqQfDwIP = list(eZrCtjVSdlx3Q70.keys())
				for KKQDtNb1Awl5Jy3vWIEYFaU6kq in heT4Yup97BVd3bXlcWCqQfDwIP:
					for SFQtU7cnyeo,aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m in eZrCtjVSdlx3Q70[KKQDtNb1Awl5Jy3vWIEYFaU6kq]:
						if yLKdhVuk8T0IAfZpe in aotWnjvVy8k3iS.lower(): jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx.append((aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m))
					del eZrCtjVSdlx3Q70[KKQDtNb1Awl5Jy3vWIEYFaU6kq]
				del eZrCtjVSdlx3Q70
			else: heT4Yup97BVd3bXlcWCqQfDwIP = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'list',Ew0v56kqBmNKxflF[DDSXKTgdvtyImN2aJYV35QGZjpkxoU],'__GROUPS__')
			for KKQDtNb1Awl5Jy3vWIEYFaU6kq in heT4Yup97BVd3bXlcWCqQfDwIP:
				try: KKQDtNb1Awl5Jy3vWIEYFaU6kq,AkHOcXEv2wJp7W085m = KKQDtNb1Awl5Jy3vWIEYFaU6kq
				except: AkHOcXEv2wJp7W085m = QigevCplXxbPI1H
				if yLKdhVuk8T0IAfZpe in KKQDtNb1Awl5Jy3vWIEYFaU6kq.lower():
					if DDSXKTgdvtyImN2aJYV35QGZjpkxoU!=3: kWeLhUljf0zyAF5n = KKQDtNb1Awl5Jy3vWIEYFaU6kq
					else:
						CCl7qnAxYaOdJuoXgV6NKQWwSPM,Ad7J1HD5lhI = KKQDtNb1Awl5Jy3vWIEYFaU6kq.split('__SERIES__')
						if yLKdhVuk8T0IAfZpe in CCl7qnAxYaOdJuoXgV6NKQWwSPM.lower(): kWeLhUljf0zyAF5n = CCl7qnAxYaOdJuoXgV6NKQWwSPM
						else: kWeLhUljf0zyAF5n = Ad7J1HD5lhI
					uuU3zsFNDHimYGRf.append((KKQDtNb1Awl5Jy3vWIEYFaU6kq,kWeLhUljf0zyAF5n,Ew0v56kqBmNKxflF[DDSXKTgdvtyImN2aJYV35QGZjpkxoU],AkHOcXEv2wJp7W085m))
			del heT4Yup97BVd3bXlcWCqQfDwIP
		uuU3zsFNDHimYGRf = set(uuU3zsFNDHimYGRf)
		jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx = set(jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx)
		uuU3zsFNDHimYGRf = sorted(uuU3zsFNDHimYGRf,reverse=False,key=lambda Z6ZpWLOjfodPKl3QVqrTYai8MBA9: Z6ZpWLOjfodPKl3QVqrTYai8MBA9[1])
		jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx = sorted(jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx,reverse=False,key=lambda Z6ZpWLOjfodPKl3QVqrTYai8MBA9: Z6ZpWLOjfodPKl3QVqrTYai8MBA9[0])
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,'SEARCH',(alwxe3cuQACn067UZJpqkybP2it,yLKdhVuk8T0IAfZpe),(uuU3zsFNDHimYGRf,jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx),xfdjCmFwb0k8JAVegiL)
	else: uuU3zsFNDHimYGRf,jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx = JX4pLs7W5Mdm
	heT4Yup97BVd3bXlcWCqQfDwIP = len(uuU3zsFNDHimYGRf)
	Vl1DqBJXZkUw4OF58vTpnbf0MzG2eE = len(jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx)
	iIBnwPa3gYp4d = int(VjyFvc68g4YboUlHR)
	GG9zjSe7UwVgcmL = max(0,(iIBnwPa3gYp4d-1)*100)
	ww8otnNfilZKXxeuUASDqrcy = max(0,iIBnwPa3gYp4d*100)
	rrfViYSwC5W8HR = max(0,GG9zjSe7UwVgcmL-heT4Yup97BVd3bXlcWCqQfDwIP)
	hw5fJQVjDmd = max(0,ww8otnNfilZKXxeuUASDqrcy-heT4Yup97BVd3bXlcWCqQfDwIP)
	for KKQDtNb1Awl5Jy3vWIEYFaU6kq,kWeLhUljf0zyAF5n,nxN3VQtlWiJI51svRS,AkHOcXEv2wJp7W085m in uuU3zsFNDHimYGRf[GG9zjSe7UwVgcmL:ww8otnNfilZKXxeuUASDqrcy]:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+kWeLhUljf0zyAF5n,nxN3VQtlWiJI51svRS,714,AkHOcXEv2wJp7W085m,'1',KKQDtNb1Awl5Jy3vWIEYFaU6kq,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	del uuU3zsFNDHimYGRf
	for aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,AkHOcXEv2wJp7W085m in jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx[rrfViYSwC5W8HR:hw5fJQVjDmd]:
		RuVTBkmPEJSNd = z2dZ1anR6O(XCapNbgw2xWQ5jRt)
		pf6P4wckhgTa = 'live'
		if '.mkv' in RuVTBkmPEJSNd or 'VOD' in alwxe3cuQACn067UZJpqkybP2it: pf6P4wckhgTa = 'video'
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj(pf6P4wckhgTa,KNY6Ao0Stysxc+aotWnjvVy8k3iS,XCapNbgw2xWQ5jRt,715,AkHOcXEv2wJp7W085m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	del jEwvhD0oU5ln7MdiLgYRZ4V3Qe2KBx
	YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(wiWn9NIP6XG,VjyFvc68g4YboUlHR,alwxe3cuQACn067UZJpqkybP2it,719,heT4Yup97BVd3bXlcWCqQfDwIP+Vl1DqBJXZkUw4OF58vTpnbf0MzG2eE,IghAzcTSrx1Wq6+'_NODIALOGS_')
	return
def YYeDAFKkQBuqRCgv7MU2tOwjmfzdJ(wiWn9NIP6XG,VjyFvc68g4YboUlHR,alwxe3cuQACn067UZJpqkybP2it,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,TTxDNLsAzuynXYK,d8kolNVuLsPAjQZ9ROpUHBgix):
	if not VjyFvc68g4YboUlHR: VjyFvc68g4YboUlHR = '1'
	if VjyFvc68g4YboUlHR!='1': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'صفحة '+str(1),alwxe3cuQACn067UZJpqkybP2it,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,QigevCplXxbPI1H,str(1),d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	if not TTxDNLsAzuynXYK: TTxDNLsAzuynXYK = 0
	OLTgiUeul98m2Q0NW3 = int(TTxDNLsAzuynXYK/100)+1
	for iIBnwPa3gYp4d in range(2,OLTgiUeul98m2Q0NW3):
		BBuFJaV4pGYdKLrszb = (iIBnwPa3gYp4d%10==0 or int(VjyFvc68g4YboUlHR)-4<iIBnwPa3gYp4d<int(VjyFvc68g4YboUlHR)+4)
		YftUdjWxaAIycHlXTw = (BBuFJaV4pGYdKLrszb and int(VjyFvc68g4YboUlHR)-40<iIBnwPa3gYp4d<int(VjyFvc68g4YboUlHR)+40)
		if str(iIBnwPa3gYp4d)!=VjyFvc68g4YboUlHR and (iIBnwPa3gYp4d%100==0 or YftUdjWxaAIycHlXTw):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'صفحة '+str(iIBnwPa3gYp4d),alwxe3cuQACn067UZJpqkybP2it,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,QigevCplXxbPI1H,str(iIBnwPa3gYp4d),d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	if str(OLTgiUeul98m2Q0NW3)!=VjyFvc68g4YboUlHR: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',KNY6Ao0Stysxc+'أخر صفحة '+str(OLTgiUeul98m2Q0NW3),alwxe3cuQACn067UZJpqkybP2it,TsckNQJ6yLiaEeCRml98WwKfVP0dYv,QigevCplXxbPI1H,str(OLTgiUeul98m2Q0NW3),d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,{'folder':wiWn9NIP6XG})
	return
def kO8SJNxd39v14Xhwi(wiWn9NIP6XG,alwxe3cuQACn067UZJpqkybP2it):
	R0ejFr1UkA98f = K28yBvSdRwo.replace('___','_'+wiWn9NIP6XG)
	return R0ejFr1UkA98f
def UUQLCXmFkH4owN8SAJ7l3PcxV(wiWn9NIP6XG):
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,QigevCplXxbPI1H)
	tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if tNVOmK5d8DvYoGr2!=1: return False
	guYc0nphomZA(wiWn9NIP6XG,False)
	SnfsW69TA5FQRyMUc0vI = [0]
	for bb6LKGv5OYmaWIHz3ZfuUS in range(1,BfLAwW35nUiRPuNpymh9t+1):
		JbN0MHFCGqBg = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.url_'+wiWn9NIP6XG+'_'+str(bb6LKGv5OYmaWIHz3ZfuUS))
		if JbN0MHFCGqBg: BjYtnCJv0NHPROm6VUc(wiWn9NIP6XG,str(bb6LKGv5OYmaWIHz3ZfuUS))
		SnfsW69TA5FQRyMUc0vI.append(0)
	for alwxe3cuQACn067UZJpqkybP2it in AI5jVSyzuU4:
		SSnUOb1e3zPuMsc,X2XsDWUmY4zkxow,V8VxGMuvLw671gp,SDgPJFfBRUsLIoVmrvQxtNa,xIQUyXevRuMBE8a4iGlTzSoq7sVdnj = 0,{},[],[],[]
		for bb6LKGv5OYmaWIHz3ZfuUS in range(1,BfLAwW35nUiRPuNpymh9t+1):
			nxN3VQtlWiJI51svRS = alwxe3cuQACn067UZJpqkybP2it+'_'+str(bb6LKGv5OYmaWIHz3ZfuUS)
			E9ERJgnNAWfHL10s3UVCTc2Po6 = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'dict',nxN3VQtlWiJI51svRS)
			try:
				ttkmeacHVgEqh1xPL6T = E9ERJgnNAWfHL10s3UVCTc2Po6['__GROUPS__']
				bbVNsXZRi7yBGEJotc5K3Ax = E9ERJgnNAWfHL10s3UVCTc2Po6['__COUNT__']
			except: ttkmeacHVgEqh1xPL6T,bbVNsXZRi7yBGEJotc5K3Ax = [],'0'
			for wwAhrENlRoWmH7jvTIuze2KF in ttkmeacHVgEqh1xPL6T:
				KKQDtNb1Awl5Jy3vWIEYFaU6kq,hhQxqntdaHTLE0V4UMXbOvgepKRG = wwAhrENlRoWmH7jvTIuze2KF
				eZrCtjVSdlx3Q70 = E9ERJgnNAWfHL10s3UVCTc2Po6[KKQDtNb1Awl5Jy3vWIEYFaU6kq]
				if KKQDtNb1Awl5Jy3vWIEYFaU6kq not in SDgPJFfBRUsLIoVmrvQxtNa:
					SDgPJFfBRUsLIoVmrvQxtNa.append(KKQDtNb1Awl5Jy3vWIEYFaU6kq)
					xIQUyXevRuMBE8a4iGlTzSoq7sVdnj.append(wwAhrENlRoWmH7jvTIuze2KF)
					X2XsDWUmY4zkxow[KKQDtNb1Awl5Jy3vWIEYFaU6kq] = []
				X2XsDWUmY4zkxow[KKQDtNb1Awl5Jy3vWIEYFaU6kq] += eZrCtjVSdlx3Q70
			P2zHZToLl1hQVUpvS7D(R0ejFr1UkA98f,nxN3VQtlWiJI51svRS)
			BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,nxN3VQtlWiJI51svRS,'__COUNT__',bbVNsXZRi7yBGEJotc5K3Ax,xfdjCmFwb0k8JAVegiL)
			SnfsW69TA5FQRyMUc0vI[bb6LKGv5OYmaWIHz3ZfuUS] += int(bbVNsXZRi7yBGEJotc5K3Ax)
		for KKQDtNb1Awl5Jy3vWIEYFaU6kq in SDgPJFfBRUsLIoVmrvQxtNa:
			eZrCtjVSdlx3Q70 = list(set(X2XsDWUmY4zkxow[KKQDtNb1Awl5Jy3vWIEYFaU6kq]))
			if 'SORTED' in alwxe3cuQACn067UZJpqkybP2it: eZrCtjVSdlx3Q70 = sorted(eZrCtjVSdlx3Q70,reverse=False,key=lambda key: key[1].lower())
			SSnUOb1e3zPuMsc += len(eZrCtjVSdlx3Q70)
			V8VxGMuvLw671gp.append(eZrCtjVSdlx3Q70)
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,alwxe3cuQACn067UZJpqkybP2it,'__COUNT__',str(SSnUOb1e3zPuMsc),xfdjCmFwb0k8JAVegiL)
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,alwxe3cuQACn067UZJpqkybP2it,'__GROUPS__',xIQUyXevRuMBE8a4iGlTzSoq7sVdnj,xfdjCmFwb0k8JAVegiL)
		BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,alwxe3cuQACn067UZJpqkybP2it,SDgPJFfBRUsLIoVmrvQxtNa,V8VxGMuvLw671gp,xfdjCmFwb0k8JAVegiL,True)
	IIrMxG1UVuDk3PLoqb = False
	for bb6LKGv5OYmaWIHz3ZfuUS in range(1,BfLAwW35nUiRPuNpymh9t+1):
		if int(SnfsW69TA5FQRyMUc0vI[bb6LKGv5OYmaWIHz3ZfuUS])>0:
			JbN0MHFCGqBg = uUTRHgAXJzm7pIDBjNt8.getSetting('av.m3u.url_'+wiWn9NIP6XG+'_'+str(bb6LKGv5OYmaWIHz3ZfuUS))
			BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,'LINK_'+str(bb6LKGv5OYmaWIHz3ZfuUS),'__LINK__',JbN0MHFCGqBg,xfdjCmFwb0k8JAVegiL)
			IIrMxG1UVuDk3PLoqb = True
	BLzxpQ2FkeIjcqvr30Kyo86Z7fnV(R0ejFr1UkA98f,'DUMMY','__DUMMY__','DUMMY',xfdjCmFwb0k8JAVegiL)
	if not IIrMxG1UVuDk3PLoqb:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	oYDBUW2zuFe9vEx(wiWn9NIP6XG)
	ksV5ngvbcaS8ByMLYxlfXh(False)
	return True
def oYDBUW2zuFe9vEx(wiWn9NIP6XG):
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,QigevCplXxbPI1H)
	if not pQW09CG5Fojk4i(wiWn9NIP6XG,True): return
	for bb6LKGv5OYmaWIHz3ZfuUS in range(1,BfLAwW35nUiRPuNpymh9t+1):
		JbN0MHFCGqBg = wZ8QjMrd2u3V6TGxsmU(R0ejFr1UkA98f,'str','LINK_'+str(bb6LKGv5OYmaWIHz3ZfuUS),'__LINK__')
		if JbN0MHFCGqBg: LmPGiAj90UJtN2E1KxvBCb58rgFu = vKVX0i1ZegUuWM9qzo7Ns6xJ(wiWn9NIP6XG,str(bb6LKGv5OYmaWIHz3ZfuUS))
	vKVX0i1ZegUuWM9qzo7Ns6xJ(wiWn9NIP6XG,QigevCplXxbPI1H)
	return
def guYc0nphomZA(wiWn9NIP6XG,YLb0uVtp5ZEChqf1In2zGNi4e):
	if YLb0uVtp5ZEChqf1In2zGNi4e:
		tNVOmK5d8DvYoGr2 = UJV3rPyElz5xRav0FD('center',QigevCplXxbPI1H,QigevCplXxbPI1H,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if tNVOmK5d8DvYoGr2!=1: return
	R0ejFr1UkA98f = kO8SJNxd39v14Xhwi(wiWn9NIP6XG,QigevCplXxbPI1H)
	try: KiTt9ZskMLjnCAUIJNXD7.remove(R0ejFr1UkA98f)
	except: pass
	for bb6LKGv5OYmaWIHz3ZfuUS in range(1,BfLAwW35nUiRPuNpymh9t+1):
		eehakOTYstEIfg5zd = qOm1IJUYKPiroj59ZHnkXDVy6zMw.replace('___','_'+wiWn9NIP6XG+'_'+str(bb6LKGv5OYmaWIHz3ZfuUS))
		keYdfKGUBmrNFA67cM1bRJD9px = KiTt9ZskMLjnCAUIJNXD7.path.join(nZ5AkguavpEc7zWo8SOHRD,eehakOTYstEIfg5zd)
		try: KiTt9ZskMLjnCAUIJNXD7.remove(keYdfKGUBmrNFA67cM1bRJD9px)
		except: pass
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'SECTIONS_M3U','SECTIONS_M3U_'+wiWn9NIP6XG)
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if YLb0uVtp5ZEChqf1In2zGNi4e:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		ksV5ngvbcaS8ByMLYxlfXh(False)
	return
def ArJS5DFPgnf4ea3KoNV(wiWn9NIP6XG):
	dnD7eUchiyoZwQ9 = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.provider')
	BinKGwlxWAHZQ97YVu1Cf32y = uUTRHgAXJzm7pIDBjNt8.getSetting('av.language.code')
	P2zHZToLl1hQVUpvS7D(qH5vZR0MhF97zt4PULV,'MENUS_CACHE_'+dnD7eUchiyoZwQ9+'_'+BinKGwlxWAHZQ97YVu1Cf32y,'%_MU'+wiWn9NIP6XG+'_%')
	return
cohJxIm12tMDET7Q5N = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
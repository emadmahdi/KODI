# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'EGYNOW'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_EGN_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==430: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==431: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==432: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==433: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==434: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: W9lfsoMawqOzpQcXD = fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==437: W9lfsoMawqOzpQcXD = WYlKcfgd9BnhGCJj(url)
	elif mode==439: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m+'/films',QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = sBvufaD6c9YHdOqTjCQ3.findall('"canonical" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	unA4F0ajXBUwHksrx3IyNCJL = unA4F0ajXBUwHksrx3IyNCJL[0].strip('/')
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(unA4F0ajXBUwHksrx3IyNCJL,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,439,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر محدد',unA4F0ajXBUwHksrx3IyNCJL,435)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر كامل',unA4F0ajXBUwHksrx3IyNCJL,434)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المضاف حديثا',unA4F0ajXBUwHksrx3IyNCJL,431)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'افلام اون لاين',unA4F0ajXBUwHksrx3IyNCJL+'/films1',436)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مسلسلات اون لاين',unA4F0ajXBUwHksrx3IyNCJL+'/series-all1',436)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'قائمة تفصيلية',unA4F0ajXBUwHksrx3IyNCJL,437)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"SiteNavigation"(.*?)"Search"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,431)
	return
def WYlKcfgd9BnhGCJj(website=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',website+'/films',QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = sBvufaD6c9YHdOqTjCQ3.findall('"canonical" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	unA4F0ajXBUwHksrx3IyNCJL = unA4F0ajXBUwHksrx3IyNCJL[0].strip('/')
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(unA4F0ajXBUwHksrx3IyNCJL,'url')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"ListDroped"(.*?)"SearchingMaster"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for opIyA9rsJMXPL1k,nFdGHjceZzW,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		RMC6c2kL5hGOnFaIwAyb = website+'/explore/?'+opIyA9rsJMXPL1k+'='+nFdGHjceZzW
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,431)
	return
def eR6YT8AbXwl(url):
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-SUBMENU-1st')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع',url,431)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"titleSectionCon"(.*?)</div></div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-key="(.*?)".*?<em>(.*?)</em>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for ZDQqkvbtHmB4,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		Kj0TOU6BmSMlJHZYLd = unA4F0ajXBUwHksrx3IyNCJL+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+ZDQqkvbtHmB4
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,Kj0TOU6BmSMlJHZYLd,431)
	return
def ddbEXhWzOnIaR(url,x9Ahuz3FVWmJDaNp5=QigevCplXxbPI1H):
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
		T24Te3uDwBS5vLgUEAhF1O = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-TITLES-1st')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
	elif x9Ahuz3FVWmJDaNp5=='featured':
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-TITLES-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"MainSlider"(.*?)"MatchesTable"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-TITLES-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"BlocksList"(.*?)"Paginate"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"BlocksList"(.*?)"titleSectionCon"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb).strip('/')
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,432,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY and 'الحلقة' in title:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,433,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif '/movseries/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,431,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,433,cXu4fN1moCypJqb72OZvd)
	if x9Ahuz3FVWmJDaNp5!='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"Paginate"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+RMC6c2kL5hGOnFaIwAyb
				RMC6c2kL5hGOnFaIwAyb = i7gQvkPzZJm4jM3uYV2xfAqhs(RMC6c2kL5hGOnFaIwAyb)
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				if title!=QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,431)
		CMdDv3wHmpqtT0JBPrUXhR = sBvufaD6c9YHdOqTjCQ3.findall('showmore" href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if CMdDv3wHmpqtT0JBPrUXhR:
			RMC6c2kL5hGOnFaIwAyb = CMdDv3wHmpqtT0JBPrUXhR[0]
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مشاهدة المزيد',RMC6c2kL5hGOnFaIwAyb,431)
	return
def oB2rmVgqUND(url):
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	Z5CDQW96jye,gQ5KvJ6G2lbWwYBOMiTr = [],[]
	if 'Episodes.php' in url:
		Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = b9PJzXFf4dYnGHm52NWsyA8(url)
		T24Te3uDwBS5vLgUEAhF1O = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',Kj0TOU6BmSMlJHZYLd,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-EPISODES-1st')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		gQ5KvJ6G2lbWwYBOMiTr = [aY63L2NhgvwJIxPAoDG4MKECmZXF1]
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-EPISODES-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"SeasonsList"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"EpisodesList"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Z5CDQW96jye:
		cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('"og:image" content="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0]
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for Mc0PCsFDyLYA1VkTpXvfG8nuB5,QbMvEmDZVokt6qLB4KHWjnF02SlINy,title in items:
			RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+QbMvEmDZVokt6qLB4KHWjnF02SlINy+'&post_id='+Mc0PCsFDyLYA1VkTpXvfG8nuB5
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,433,cXu4fN1moCypJqb72OZvd)
	elif gQ5KvJ6G2lbWwYBOMiTr:
		cXu4fN1moCypJqb72OZvd = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel('ListItem.Thumb')
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,V1nZX7O5WwEq8HmvkY in items:
			title = title+hT7zFDpEyUqf8sXuN+V1nZX7O5WwEq8HmvkY
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,432,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	Kj0TOU6BmSMlJHZYLd = url+'/watch/'
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	ldFqnNIsftrY43JBM6LPjzU8m = []
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,'url')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"container-servers"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		yOIi0uvVs1 = sBvufaD6c9YHdOqTjCQ3.findall('data-id="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if yOIi0uvVs1:
			yOIi0uvVs1 = yOIi0uvVs1[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('data-server="(.*?)".*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for bSrdN78jxURTvh9,title in items:
				RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+bSrdN78jxURTvh9+'&post_id='+yOIi0uvVs1+'?named='+title+'__watch'
				ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	BugX1lkbxEyiwc4jfTosVCJtA = sBvufaD6c9YHdOqTjCQ3.findall('"container-iframe"><iframe src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if BugX1lkbxEyiwc4jfTosVCJtA:
		BugX1lkbxEyiwc4jfTosVCJtA = BugX1lkbxEyiwc4jfTosVCJtA[0].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
		title = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(BugX1lkbxEyiwc4jfTosVCJtA,'name')
		RMC6c2kL5hGOnFaIwAyb = BugX1lkbxEyiwc4jfTosVCJtA+'?named='+title+'__embed'
		ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"container-download"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,oI6LvXMf4VEPe8jOdpKC0hUmS in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
			if oI6LvXMf4VEPe8jOdpKC0hUmS!=QigevCplXxbPI1H: oI6LvXMf4VEPe8jOdpKC0hUmS = '____'+oI6LvXMf4VEPe8jOdpKC0hUmS
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'+oI6LvXMf4VEPe8jOdpKC0hUmS
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'%20')
	url = vxQUXEuH9m+'/?s='+search
	ddbEXhWzOnIaR(url)
	return
def bZ297CKlfXUW1n5BghJjzHQMi(url):
	url = url.split('/smartemadfilter?')[0]
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',unA4F0ajXBUwHksrx3IyNCJL,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('("dropdown-button".*?)"SearchingMaster"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	GTvCiBk9e5HnWobxXw6AzV3KQ = sBvufaD6c9YHdOqTjCQ3.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return GTvCiBk9e5HnWobxXw6AzV3KQ
def k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY):
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-term="(\d+)" data-name="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	return items
def ZUusq9Gr6KtlWHJQ(url):
	ffJtczXvkj0o2HUZRprAOS = url.split('/smartemadfilter?')[0]
	gd2lmLiIyEvcsT = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
	url = url.replace(ffJtczXvkj0o2HUZRprAOS,gd2lmLiIyEvcsT)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def hi394gNbEqyD1mtc2I5sJx(oG5dMKyX6VQPhmuL0,url):
	IhG0UytMJko7 = llw70XcediabtjVrGNHFD(oG5dMKyX6VQPhmuL0,'modified_filters')
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = url+'/smartemadfilter?'+IhG0UytMJko7
	NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = ZUusq9Gr6KtlWHJQ(NW6gmPcC1B4ILwdHTz0GlDsi5Fkx)
	return NW6gmPcC1B4ILwdHTz0GlDsi5Fkx
XGiBxdyuLeSzpmvUCEwJI = ['category','country','genre','release-year']
NBJvnaA2GkRo6SD79YsVjqd = ['quality','release-year','genre','category','language','country']
def fZtVmUy2OLen0BNMcu1A7QvTChzY5(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==QigevCplXxbPI1H: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = QigevCplXxbPI1H,QigevCplXxbPI1H
	else: QSUrMykAebtx0Ea6,nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if XGiBxdyuLeSzpmvUCEwJI[0]+'=' not in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[0]
		for A5SjhJUg37pNiMC4Eot6lOF in range(len(XGiBxdyuLeSzpmvUCEwJI[0:-1])):
			if XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF]+'=' in QSUrMykAebtx0Ea6: opIyA9rsJMXPL1k = XGiBxdyuLeSzpmvUCEwJI[A5SjhJUg37pNiMC4Eot6lOF+1]
		W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+opIyA9rsJMXPL1k+'=0'
		oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+opIyA9rsJMXPL1k+'=0'
		Vq4HIkij2ZLE = W5sangcNZQzm.strip('&')+'___'+oG5dMKyX6VQPhmuL0.strip('&')
		IhG0UytMJko7 = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+IhG0UytMJko7
	elif type=='ALL_ITEMS_FILTER':
		HoqigOQCETtzRauxnBSMIb3ypr = llw70XcediabtjVrGNHFD(QSUrMykAebtx0Ea6,'modified_values')
		HoqigOQCETtzRauxnBSMIb3ypr = MVkP7zfWlxUXj(HoqigOQCETtzRauxnBSMIb3ypr)
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY!=QigevCplXxbPI1H: nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY = llw70XcediabtjVrGNHFD(nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY,'modified_filters')
		if nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY==QigevCplXxbPI1H: Kj0TOU6BmSMlJHZYLd = url
		else: Kj0TOU6BmSMlJHZYLd = url+'/smartemadfilter?'+nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY
		Kj0TOU6BmSMlJHZYLd = ZUusq9Gr6KtlWHJQ(Kj0TOU6BmSMlJHZYLd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'أظهار قائمة الفيديو التي تم اختيارها ',Kj0TOU6BmSMlJHZYLd,431)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+' [[   '+HoqigOQCETtzRauxnBSMIb3ypr+'   ]]',Kj0TOU6BmSMlJHZYLd,431)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	GTvCiBk9e5HnWobxXw6AzV3KQ = bZ297CKlfXUW1n5BghJjzHQMi(url)
	dict = {}
	for name,LKzFWsmvjUVGMDBapflx6H4NY,Vjv2Okb6qhMRQgaDlu3JCir in GTvCiBk9e5HnWobxXw6AzV3KQ:
		name = name.replace('--',QigevCplXxbPI1H)
		items = k5xf8BcMlmdaN7w6vKp9(LKzFWsmvjUVGMDBapflx6H4NY)
		if '=' not in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd = url
		if type=='SPECIFIED_FILTER':
			if opIyA9rsJMXPL1k!=Vjv2Okb6qhMRQgaDlu3JCir: continue
			elif len(items)<2:
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]:
					url = ZUusq9Gr6KtlWHJQ(url)
					ddbEXhWzOnIaR(url)
				else: fZtVmUy2OLen0BNMcu1A7QvTChzY5(Kj0TOU6BmSMlJHZYLd,'SPECIFIED_FILTER___'+Vq4HIkij2ZLE)
				return
			else:
				Kj0TOU6BmSMlJHZYLd = ZUusq9Gr6KtlWHJQ(Kj0TOU6BmSMlJHZYLd)
				if Vjv2Okb6qhMRQgaDlu3JCir==XGiBxdyuLeSzpmvUCEwJI[-1]: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع ',Kj0TOU6BmSMlJHZYLd,431)
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع ',Kj0TOU6BmSMlJHZYLd,435,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		elif type=='ALL_ITEMS_FILTER':
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'=0'
			Vq4HIkij2ZLE = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الجميع :'+name,Kj0TOU6BmSMlJHZYLd,434,QigevCplXxbPI1H,QigevCplXxbPI1H,Vq4HIkij2ZLE)
		dict[Vjv2Okb6qhMRQgaDlu3JCir] = {}
		for nFdGHjceZzW,C4kS0cewBJy8YOWtZxXNjfM2 in items:
			if nFdGHjceZzW=='196533': C4kS0cewBJy8YOWtZxXNjfM2 = 'أفلام نيتفلكس'
			elif nFdGHjceZzW=='196531': C4kS0cewBJy8YOWtZxXNjfM2 = 'مسلسلات نيتفلكس'
			if C4kS0cewBJy8YOWtZxXNjfM2 in ef1pQcbEtPjMnXYrvOi: continue
			dict[Vjv2Okb6qhMRQgaDlu3JCir][nFdGHjceZzW] = C4kS0cewBJy8YOWtZxXNjfM2
			W5sangcNZQzm = QSUrMykAebtx0Ea6+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+C4kS0cewBJy8YOWtZxXNjfM2
			oG5dMKyX6VQPhmuL0 = nmZTiqXIgOHU7KeGtJ9cM5N2o6yxVY+'&'+Vjv2Okb6qhMRQgaDlu3JCir+'='+nFdGHjceZzW
			yQFDm1qs5H74BLr6pXe = W5sangcNZQzm+'___'+oG5dMKyX6VQPhmuL0
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'#+dict[Vjv2Okb6qhMRQgaDlu3JCir]['0']
			title = C4kS0cewBJy8YOWtZxXNjfM2+' :'+name
			if type=='ALL_ITEMS_FILTER': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,434,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
			elif type=='SPECIFIED_FILTER' and XGiBxdyuLeSzpmvUCEwJI[-2]+'=' in QSUrMykAebtx0Ea6:
				NW6gmPcC1B4ILwdHTz0GlDsi5Fkx = hi394gNbEqyD1mtc2I5sJx(oG5dMKyX6VQPhmuL0,url)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,NW6gmPcC1B4ILwdHTz0GlDsi5Fkx,431)
			else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,435,QigevCplXxbPI1H,QigevCplXxbPI1H,yQFDm1qs5H74BLr6pXe)
	return
def llw70XcediabtjVrGNHFD(ZycmQiCsdhDMvz,mode):
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.replace('=&','=0&')
	ZycmQiCsdhDMvz = ZycmQiCsdhDMvz.strip('&')
	lN0IMdsA1ij8SRaQrfJ3hO9ZFc = {}
	if '=' in ZycmQiCsdhDMvz:
		items = ZycmQiCsdhDMvz.split('&')
		for upHdVltvOIDPnN0SefZwGo4gJ9LqsY in items:
			BfQEXlmstMPK762JyZnDA8,nFdGHjceZzW = upHdVltvOIDPnN0SefZwGo4gJ9LqsY.split('=')
			lN0IMdsA1ij8SRaQrfJ3hO9ZFc[BfQEXlmstMPK762JyZnDA8] = nFdGHjceZzW
	bYlTrNXtvf0G7y = QigevCplXxbPI1H
	for key in NBJvnaA2GkRo6SD79YsVjqd:
		if key in list(lN0IMdsA1ij8SRaQrfJ3hO9ZFc.keys()): nFdGHjceZzW = lN0IMdsA1ij8SRaQrfJ3hO9ZFc[key]
		else: nFdGHjceZzW = '0'
		if '%' not in nFdGHjceZzW: nFdGHjceZzW = sqXK91rDldVAEcRTSQL4n2tbC(nFdGHjceZzW)
		if mode=='modified_values' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+' + '+nFdGHjceZzW
		elif mode=='modified_filters' and nFdGHjceZzW!='0': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
		elif mode=='all_filters': bYlTrNXtvf0G7y = bYlTrNXtvf0G7y+'&'+key+'='+nFdGHjceZzW
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip(' + ')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.strip('&')
	bYlTrNXtvf0G7y = bYlTrNXtvf0G7y.replace('=0','=')
	return bYlTrNXtvf0G7y
﻿# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
def YnMSWTbKj1N8wuRJVF(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,ddAEJGF38yPKS):
	if ddAEJGF38yPKS==QigevCplXxbPI1H: return
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv==1:
		nWQsOEmjVrxlh = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.getCurrentWindowDialogId()
		qWa01nz35c9rEDUxLh = Q0BXbnOs1jr8afIyTUHZDw4lCAki7.Window(nWQsOEmjVrxlh)
		ddAEJGF38yPKS = Yrz5bs6eFPfiZQTpBSLx8nH2Kcl(ddAEJGF38yPKS)
		qWa01nz35c9rEDUxLh.getControl(311).setLabel(ddAEJGF38yPKS)
	if TsckNQJ6yLiaEeCRml98WwKfVP0dYv==0:
		NWdTSkYP5E6wqsDogApZmLCcbu3j2I='X'
		if b7sJAmSxlBvaMdHFz: YN1UjuHzV7silAgw5M3TCy = isinstance(ddAEJGF38yPKS,str)
		else: YN1UjuHzV7silAgw5M3TCy = isinstance(ddAEJGF38yPKS,unicode)
		if YN1UjuHzV7silAgw5M3TCy==True: NWdTSkYP5E6wqsDogApZmLCcbu3j2I='U'
		fVWeFcrtTp0a5UDPowQj3=str(type(ddAEJGF38yPKS))+hT7zFDpEyUqf8sXuN+ddAEJGF38yPKS+hT7zFDpEyUqf8sXuN+NWdTSkYP5E6wqsDogApZmLCcbu3j2I+hT7zFDpEyUqf8sXuN
		for A5SjhJUg37pNiMC4Eot6lOF in range(0,len(ddAEJGF38yPKS),1):
			fVWeFcrtTp0a5UDPowQj3 += hex(ord(ddAEJGF38yPKS[A5SjhJUg37pNiMC4Eot6lOF])).replace('0x',QigevCplXxbPI1H)+hT7zFDpEyUqf8sXuN
		ddAEJGF38yPKS = Yrz5bs6eFPfiZQTpBSLx8nH2Kcl(ddAEJGF38yPKS)
		NWdTSkYP5E6wqsDogApZmLCcbu3j2I='X'
		if b7sJAmSxlBvaMdHFz: YN1UjuHzV7silAgw5M3TCy = isinstance(ddAEJGF38yPKS, str)
		else: YN1UjuHzV7silAgw5M3TCy = isinstance(ddAEJGF38yPKS, unicode)
		if YN1UjuHzV7silAgw5M3TCy==True: NWdTSkYP5E6wqsDogApZmLCcbu3j2I='U'
		jrPNgMTkH8UeXn2cZuKavIbWxQFw=str(type(ddAEJGF38yPKS))+hT7zFDpEyUqf8sXuN+ddAEJGF38yPKS+hT7zFDpEyUqf8sXuN+NWdTSkYP5E6wqsDogApZmLCcbu3j2I+hT7zFDpEyUqf8sXuN
		for A5SjhJUg37pNiMC4Eot6lOF in range(0,len(ddAEJGF38yPKS),1):
			jrPNgMTkH8UeXn2cZuKavIbWxQFw += hex(ord(ddAEJGF38yPKS[A5SjhJUg37pNiMC4Eot6lOF])).replace('0x',QigevCplXxbPI1H)+hT7zFDpEyUqf8sXuN
	return
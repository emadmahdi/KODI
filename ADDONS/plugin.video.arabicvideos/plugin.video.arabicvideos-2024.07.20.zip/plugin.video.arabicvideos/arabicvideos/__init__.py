# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from r6mxE54yIg import *
PuT0IphGNsketAQ = tOrSvd8QKNB(u"ࠪࡍࡓࡏࡔࠨవ")
d840cUPmlMn6kHrEb = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠫశ")
NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf = c79RqAVuZjN1UaSOPB(MYIqLm4Nyhniu6QORWlrp)
cGMR9nOxZFfiElhVj4zd = int(zcl5RYhWSMKwDGqLjtgknbU)
J4kSW2aUHYg6 = qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(O4ylJvVNwLztdiHqBWDU(u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭ష"))
J4kSW2aUHYg6 = J4kSW2aUHYg6.replace(yy7OzVc6J5WiY4pLMwFoXRs,QigevCplXxbPI1H).replace(AhkIX24vpNGzdLU5,QigevCplXxbPI1H)
if cGMR9nOxZFfiElhVj4zd==mmKqLr9RX0ACN384JMcsFHzd(u"࠳࠸࠳ౝ"): VY9iRPNd5O0G8qwLkflnD46vH1We = aqUlAdFto05NmG4Y6guEzTr8vK(u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧస")+GVmdqbtLu8lUXNxp13aHOvkscR+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧహ")+FwcH7quaG4m5vp2W9I+OOhnpQ8XvCVclGqdu(u"ࠨࠢࡠࠫ఺")
else:
	eLHE5b0QsoMj = MVkP7zfWlxUXj(MYIqLm4Nyhniu6QORWlrp).replace(iVCLpNIM8BQs9PdSgKZvlFeo3a5,QigevCplXxbPI1H).replace(r9rhtA5Tek8sIoLfqwF7JcEV,QigevCplXxbPI1H)
	eLHE5b0QsoMj = eLHE5b0QsoMj.replace(jhAlCQ47ZgG,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
	eLHE5b0QsoMj = eLHE5b0QsoMj.replace(f1p0IN8alhrDKHyvqWk9UZ,hT7zFDpEyUqf8sXuN).replace(Ec4QJmyAo3G7Vp2X6SY8UifnOh,hT7zFDpEyUqf8sXuN).replace(eZXCHufT9YW4bRErSBOLmI,hT7zFDpEyUqf8sXuN)
	VY9iRPNd5O0G8qwLkflnD46vH1We = XWbHfI9B8swrOL(u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨ఻")+J4kSW2aUHYg6+vZL6j4tSClIGxzNE5DX(u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜఼ࠢࠪ")+zcl5RYhWSMKwDGqLjtgknbU+Xr2aHOK0huQ5DTS(u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫఽ")+eLHE5b0QsoMj+s0vAWcLSXEToH9Mik134q(u"ࠬࠦ࡝ࠨా")
SQdRhwozVfv(AwKhgdpmBj0,d840cUPmlMn6kHrEb+aSBkt4OU8JpWTEzVIHjAiv+w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+VY9iRPNd5O0G8qwLkflnD46vH1We)
if svULcgJ7jm(u"࠭࡟ࠨి") in Jl1Za0IHxnshWC: CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1 = Jl1Za0IHxnshWC.split(K7bLVaiRkx0lgU5SQM(u"ࠧࡠࠩీ"),O4ylJvVNwLztdiHqBWDU(u"࠳౞"))
else: CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1 = Jl1Za0IHxnshWC,QigevCplXxbPI1H
if CisD6xT0rWmGnER7lI2Qqad1y in [OOhnpQ8XvCVclGqdu(u"ࠨ࠳ࠪు"),svULcgJ7jm(u"ࠩ࠵ࠫూ"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪ࠷ࠬృ"),v54ZuLY6dQ(u"ࠫ࠹࠭ౄ"),OOhnpQ8XvCVclGqdu(u"ࠬ࠻ࠧ౅")] and (Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭ࡁࡅࡆࠪె") in PnCEQ8xD3AI1 or aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧే") in PnCEQ8xD3AI1 or QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨࡗࡓࠫై") in PnCEQ8xD3AI1 or bDt7Ya1VEio3(u"ࠩࡇࡓ࡜ࡔࠧ౉") in PnCEQ8xD3AI1):
	from T9PmfG7SQA import rLdIGxeRKphTWYJ
	rLdIGxeRKphTWYJ(Jl1Za0IHxnshWC,CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1)
	uUTRHgAXJzm7pIDBjNt8.setSetting(OOhnpQ8XvCVclGqdu(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧొ"),MYIqLm4Nyhniu6QORWlrp)
	qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(Fg72JX6T5DkPy(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨో"))
elif not enGPuSCj3A2R and cGMR9nOxZFfiElhVj4zd in [pTwKPmzMSZhil5d2RWonre(u"࠵࠷࠺౟"),Xr2aHOK0huQ5DTS(u"࠻࠶࠻ౠ")]:
	bnfEyUuXgk7GV9LjO81KNxrdDPzZ = str(zHTPjrSgp8Zcbf[y5yX4jh6kUEgWZQIc(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬౌ")])
	PuT0IphGNsketAQ = bDt7Ya1VEio3(u"࠭ࡉࡑࡖ్࡙ࠫ") if cGMR9nOxZFfiElhVj4zd==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠷࠹࠵ౡ") else pTwKPmzMSZhil5d2RWonre(u"ࠧࡎ࠵ࡘࠫ౎")
	lHrBmgVyNDAZkicF9CpGsWSIzP = PuT0IphGNsketAQ.lower()
	lfPqTpgMXhVcd = uUTRHgAXJzm7pIDBjNt8.getSetting(mpusoZBJ6V(u"ࠨࡣࡹ࠲ࠬ౏")+lHrBmgVyNDAZkicF9CpGsWSIzP+mmKqLr9RX0ACN384JMcsFHzd(u"ࠩ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ౐")+bnfEyUuXgk7GV9LjO81KNxrdDPzZ)
	TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = uUTRHgAXJzm7pIDBjNt8.getSetting(TCF8wLyDvgumfiXPSKRh(u"ࠪࡥࡻ࠴ࠧ౑")+lHrBmgVyNDAZkicF9CpGsWSIzP+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧ౒")+bnfEyUuXgk7GV9LjO81KNxrdDPzZ)
	if lfPqTpgMXhVcd or TTrmYne2lRXM0jLyHAF8CzQ7vpKi6:
		iCr0xsqwDZXLPaJK1W5YU24F6hp += K7bLVaiRkx0lgU5SQM(u"ࠬࢂࠧ౓")
		if lfPqTpgMXhVcd: iCr0xsqwDZXLPaJK1W5YU24F6hp += y5yX4jh6kUEgWZQIc(u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ౔")+lfPqTpgMXhVcd
		if TTrmYne2lRXM0jLyHAF8CzQ7vpKi6: iCr0xsqwDZXLPaJK1W5YU24F6hp += JJu4MPClbTFpUwHiN(u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ౕࠪ")+TTrmYne2lRXM0jLyHAF8CzQ7vpKi6
		iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp.replace(tOrSvd8QKNB(u"ࠨࡾౖࠩࠫ"),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࡿࠫ౗"))
	qpyukOT348S5GiVlYfzMeWvw = uUTRHgAXJzm7pIDBjNt8.getSetting(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࡥࡻ࠴ࠧౘ")+lHrBmgVyNDAZkicF9CpGsWSIzP+mpusoZBJ6V(u"ࠫ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭ౙ")+bnfEyUuXgk7GV9LjO81KNxrdDPzZ)
	if qpyukOT348S5GiVlYfzMeWvw:
		yTQLoPG8rCWepVaDtM = sBvufaD6c9YHdOqTjCQ3.findall(pGncXOodjKhJzLSqVP1r(u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨౚ"),iCr0xsqwDZXLPaJK1W5YU24F6hp,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		iCr0xsqwDZXLPaJK1W5YU24F6hp = iCr0xsqwDZXLPaJK1W5YU24F6hp.replace(yTQLoPG8rCWepVaDtM[h17Zb2ld4yLBrCP5tiw],qpyukOT348S5GiVlYfzMeWvw)
	B9BaTCd86Iwz1e3sRMXZylKpcHU(iCr0xsqwDZXLPaJK1W5YU24F6hp,PuT0IphGNsketAQ,NWdTSkYP5E6wqsDogApZmLCcbu3j2I)
else:
	AYvyVPneLu0gCIObkQRrKFNwqD9 = rybze7NZwv(yBWPDAeJF1o2b)
	import TEsNM9QVZc
	THFfWLwt62MmUz = QigevCplXxbPI1H
	try: TEsNM9QVZc.EMmSnW7KIz1aqZgxoDChJ(NWdTSkYP5E6wqsDogApZmLCcbu3j2I,yBWPDAeJF1o2b,iCr0xsqwDZXLPaJK1W5YU24F6hp,zcl5RYhWSMKwDGqLjtgknbU,XGjn5q2cy6mRYZ1hPaDslHMK,JJM6TofH4g5n7SRwq,CyarqoiHxV2e80ScjAN,Jl1Za0IHxnshWC,zHTPjrSgp8Zcbf,AYvyVPneLu0gCIObkQRrKFNwqD9,cGMR9nOxZFfiElhVj4zd,CisD6xT0rWmGnER7lI2Qqad1y,PnCEQ8xD3AI1,J4kSW2aUHYg6)
	except Exception as f5fDJrRQGbEtTp07zHBKCua2: THFfWLwt62MmUz = aaoGmpybi6Q9wxsgFzXIt.format_exc()
	TEsNM9QVZc.pJHMl4kqyvhfZdse(THFfWLwt62MmUz)
	if fk8jc5uDLX16qrih3ZaPxsvO(u"࠭࡟ࡠࡡࡕࡉࡋࡘࡅࡔࡊࡢࡅࡓࡊ࡟ࡠࡡࠪ౛") in THFfWLwt62MmUz: qVuYLZTmSUhQe7rEwvFRfc.executebuiltin(Fg72JX6T5DkPy(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ౜"))
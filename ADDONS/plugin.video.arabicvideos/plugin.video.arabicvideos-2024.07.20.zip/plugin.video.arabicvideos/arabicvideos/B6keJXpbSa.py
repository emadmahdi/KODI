# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'EGYBEST4'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_EB4_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def YnMSWTbKj1N8wuRJVF(mode,url,JJM6TofH4g5n7SRwq,text):
	if   mode==800: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==801: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,JJM6TofH4g5n7SRwq)
	elif mode==802: W9lfsoMawqOzpQcXD = eR6YT8AbXwl(url)
	elif mode==803: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==804: W9lfsoMawqOzpQcXD = G5vmLAlwhJ(url)
	elif mode==806: W9lfsoMawqOzpQcXD = XPjvI9V0xhbLzoQAStGTWM(url,JJM6TofH4g5n7SRwq)
	elif mode==809: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,809,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'فلتر',vxQUXEuH9m+'/trending',804,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(g6gNzml5rOsa8bBETxPCpnVj,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST4-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('nav-categories(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('mainContent(.*?)<footer>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801,QigevCplXxbPI1H,'mainmenu')
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-menu(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.strip(hT7zFDpEyUqf8sXuN)
			if any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
			if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+RMC6c2kL5hGOnFaIwAyb
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def XPjvI9V0xhbLzoQAStGTWM(url,type=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST4-SEASONS_EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('mainTitle.*?>(.*?)<(.*?)pageContent',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		X6z7OV8NFovq0IKagdmberiM1,yjHcgifXG1,items = QigevCplXxbPI1H,QigevCplXxbPI1H,[]
		for name,LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
			if 'حلقات' in name: yjHcgifXG1 = LKzFWsmvjUVGMDBapflx6H4NY
			if 'مواسم' in name: X6z7OV8NFovq0IKagdmberiM1 = LKzFWsmvjUVGMDBapflx6H4NY
		if X6z7OV8NFovq0IKagdmberiM1 and not type:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',X6z7OV8NFovq0IKagdmberiM1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if len(items)>1:
				for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,806,cXu4fN1moCypJqb72OZvd,'season')
		if yjHcgifXG1 and len(items)<2:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',yjHcgifXG1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if items:
				for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,803,cXu4fN1moCypJqb72OZvd)
			else:
				items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',yjHcgifXG1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for RMC6c2kL5hGOnFaIwAyb,title in items:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,803)
	return
def ddbEXhWzOnIaR(url,type=QigevCplXxbPI1H):
	NjEG6es8OlRu,start,sM0mej2fYOFP7AHlnyDNJq63o,select,coS7y0wkpvAaz = 0,0,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H
	if 'pagination' in type:
		HOe0Ih3yX4pfJ7QKE,tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = url.split('?next=page&')
		T24Te3uDwBS5vLgUEAhF1O = {'Content-Type':'application/x-www-form-urlencoded'}
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',HOe0Ih3yX4pfJ7QKE,tNQDMKVydhBqgaUvJ7oeAkTHxsL1,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST4-TITLES-1st')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		BhxM1UVjtbEoSp640kIcag = 'secContent'+aY63L2NhgvwJIxPAoDG4MKECmZXF1+'<footer>'
	else:
		JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST4-TITLES-2nd')
		aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
		BhxM1UVjtbEoSp640kIcag = aY63L2NhgvwJIxPAoDG4MKECmZXF1
	items,ZNvUplCHSuj3cOQaT4bwDgoMk8rI,ZycmQiCsdhDMvz = [],False,False
	if not type and '/collections' not in url:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('mainContent(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</i>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = title.strip(hT7zFDpEyUqf8sXuN)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801,QigevCplXxbPI1H,'submenu')
				ZNvUplCHSuj3cOQaT4bwDgoMk8rI = True
	if not ZNvUplCHSuj3cOQaT4bwDgoMk8rI:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('secContent(.*?)mainContent',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
				RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb)
				cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd.strip(aSBkt4OU8JpWTEzVIHjAiv)
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				if '/series/' in RMC6c2kL5hGOnFaIwAyb and type=='season': E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,806,cXu4fN1moCypJqb72OZvd,'season')
				elif '/series/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,806,cXu4fN1moCypJqb72OZvd)
				elif '/seasons/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801,cXu4fN1moCypJqb72OZvd,'season')
				elif '/collections' in url: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801,cXu4fN1moCypJqb72OZvd,'collections')
				else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,803,cXu4fN1moCypJqb72OZvd)
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('loadMoreParams = (.*?);',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			gg6KCcWVSQTO85LDf = CH86N7xw4cyPt3TlIBJF('dict',LKzFWsmvjUVGMDBapflx6H4NY)
			coS7y0wkpvAaz = gg6KCcWVSQTO85LDf['ajaxurl']
			G1kbAhTnqMwIjiVv3Cc = int(gg6KCcWVSQTO85LDf['current_page'])+1
			JOmAQUlrDZvpLVHszhaFeSPN94ny = int(gg6KCcWVSQTO85LDf['max_page'])
			G95pqon7i0IAr6DhtdYk2bsKjHfS = gg6KCcWVSQTO85LDf['posts'].replace('False','false').replace('True','true').replace('None','null')
			if G1kbAhTnqMwIjiVv3Cc<JOmAQUlrDZvpLVHszhaFeSPN94ny:
				tNQDMKVydhBqgaUvJ7oeAkTHxsL1 = 'action=loadmore&query='+sqXK91rDldVAEcRTSQL4n2tbC(G95pqon7i0IAr6DhtdYk2bsKjHfS,QigevCplXxbPI1H)+'&page='+str(G1kbAhTnqMwIjiVv3Cc)
				Kj0TOU6BmSMlJHZYLd = coS7y0wkpvAaz+'?next=page&'+tNQDMKVydhBqgaUvJ7oeAkTHxsL1
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'جلب المزيد',Kj0TOU6BmSMlJHZYLd,801,QigevCplXxbPI1H,'pagination_'+type)
		elif '?next=page&' in url:
			tNQDMKVydhBqgaUvJ7oeAkTHxsL1,qqFGtbgNUTj1Jr6ze3PlSEnIx0O = tNQDMKVydhBqgaUvJ7oeAkTHxsL1.rsplit('=',1)
			qqFGtbgNUTj1Jr6ze3PlSEnIx0O = int(qqFGtbgNUTj1Jr6ze3PlSEnIx0O)+1
			Kj0TOU6BmSMlJHZYLd = HOe0Ih3yX4pfJ7QKE+'?next=page&'+tNQDMKVydhBqgaUvJ7oeAkTHxsL1+'='+str(qqFGtbgNUTj1Jr6ze3PlSEnIx0O)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'جلب المزيد',Kj0TOU6BmSMlJHZYLd,801,QigevCplXxbPI1H,'pagination_'+type)
	return
def G5vmLAlwhJ(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST4-FILTERS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('sub_nav(.*?)secContent ',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		mfFwcWZHXVGvyU3B0ILburCoh = sBvufaD6c9YHdOqTjCQ3.findall('"current_opt">(.*?)<(.*?)</div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for name,LKzFWsmvjUVGMDBapflx6H4NY in mfFwcWZHXVGvyU3B0ILburCoh:
			if 'التصنيف' in name: continue
			name = name.strip(hT7zFDpEyUqf8sXuN)
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,nFdGHjceZzW in items:
				title = name+':  '+nFdGHjceZzW
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,801,QigevCplXxbPI1H,'filter')
	return
def nibvTq2jfRXDM4tYP039S(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(oL2eIiFEJnd7vxc,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYBEST4-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	eFQorJTmf8xANMbKW9sl = sBvufaD6c9YHdOqTjCQ3.findall('<td>التصنيف</td>.*?">(.*?)<',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if eFQorJTmf8xANMbKW9sl and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,eFQorJTmf8xANMbKW9sl): return
	vdLczqkV5b48ZKyGxTE3jJi17aWS6,fW2AtYU7jeDkv6a = [],[]
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('postEmbed.*?src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0].replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
		fW2AtYU7jeDkv6a.append(RMC6c2kL5hGOnFaIwAyb)
		bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,'name')
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+bSrdN78jxURTvh9+'__embed')
	TvRtVUoOxmeLnFrC2j5u = sBvufaD6c9YHdOqTjCQ3.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if TvRtVUoOxmeLnFrC2j5u:
		coS7y0wkpvAaz,d8o4GfOLXIhV7b = TvRtVUoOxmeLnFrC2j5u[0]
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('postPlayer(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			rhG6i0J5X8Ltv9b72PYze = sBvufaD6c9YHdOqTjCQ3.findall('<li.*?id\,(.*?)\);">(.*?)</li>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for yLp13FCheE5a,name in rhG6i0J5X8Ltv9b72PYze:
				RMC6c2kL5hGOnFaIwAyb = coS7y0wkpvAaz+'/temp/ajax/iframe.php?id='+d8o4GfOLXIhV7b+'&video='+yLp13FCheE5a
				vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__watch')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('pageContentDown(.*?)</table>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for oI6LvXMf4VEPe8jOdpKC0hUmS,RMC6c2kL5hGOnFaIwAyb in items:
			if RMC6c2kL5hGOnFaIwAyb not in fW2AtYU7jeDkv6a:
				if '/?url=' in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.split('/?url=')[1]
				fW2AtYU7jeDkv6a.append(RMC6c2kL5hGOnFaIwAyb)
				bSrdN78jxURTvh9 = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(RMC6c2kL5hGOnFaIwAyb,'name')
				vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+bSrdN78jxURTvh9+'__download____'+oI6LvXMf4VEPe8jOdpKC0hUmS)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(vdLczqkV5b48ZKyGxTE3jJi17aWS6,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if not search: search = XAfEvmh95VkgurjdiJ()
	if not search: return
	VIo6FYRkx0MLP4wufEGsgnz9 = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/?s='+VIo6FYRkx0MLP4wufEGsgnz9
	ddbEXhWzOnIaR(url,'search')
	return
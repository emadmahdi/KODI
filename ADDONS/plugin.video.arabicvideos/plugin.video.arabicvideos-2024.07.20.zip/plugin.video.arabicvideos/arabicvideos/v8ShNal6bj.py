# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'SERIES4WATCH'
headers = { 'User-Agent' : QigevCplXxbPI1H }
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_SFW_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==210: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==211: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url)
	elif mode==212: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==213: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==214: W9lfsoMawqOzpQcXD = M3DyJNEr68BRCUncWAaZ9K(url)
	elif mode==215: W9lfsoMawqOzpQcXD = NrMkLYl3TRFGixqbZvOQzP2jcC(url)
	elif mode==218: W9lfsoMawqOzpQcXD = ssJie8zwRB5YMlx()
	elif mode==219: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def ssJie8zwRB5YMlx():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def vZR0cSd4X7seq():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,219,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	url = vxQUXEuH9m+'/getpostsPin?type=one&data=pin&limit=25'
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',url,211)
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,vxQUXEuH9m,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'SERIES4WATCH-MENU-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('FiltersButtons(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('data-get="(.*?)".*?</i>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		url = vxQUXEuH9m+'/getposts?type=one&data='+RMC6c2kL5hGOnFaIwAyb
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,211)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('navigation-menu(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(http.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	ef1pQcbEtPjMnXYrvOi = ['مسلسلات انمي','الرئيسية']
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if not any(nFdGHjceZzW in title for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,211)
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url):
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: LKzFWsmvjUVGMDBapflx6H4NY = aY63L2NhgvwJIxPAoDG4MKECmZXF1
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('MediaGrid"(.*?)class="pagination"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv: LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		else: return
	items = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	LVyczatgBIT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for cXu4fN1moCypJqb72OZvd,RMC6c2kL5hGOnFaIwAyb,title in items:
		if '/series/' in RMC6c2kL5hGOnFaIwAyb: continue
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb).strip('/')
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		title = title.strip(hT7zFDpEyUqf8sXuN)
		if '/film/' in RMC6c2kL5hGOnFaIwAyb or any(nFdGHjceZzW in title for nFdGHjceZzW in LVyczatgBIT):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,212,cXu4fN1moCypJqb72OZvd)
		elif '/episode/' in RMC6c2kL5hGOnFaIwAyb and 'الحلقة' in title:
			V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if V1nZX7O5WwEq8HmvkY:
				title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
				if title not in wibHRCAFtsupIjx4ZTELeM:
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,213,cXu4fN1moCypJqb72OZvd)
					wibHRCAFtsupIjx4ZTELeM.append(title)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,213,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = i7gQvkPzZJm4jM3uYV2xfAqhs(RMC6c2kL5hGOnFaIwAyb)
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			title = title.replace('الصفحة ',QigevCplXxbPI1H)
			if title!=QigevCplXxbPI1H: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,211)
	return
def oB2rmVgqUND(url):
	xQg9UM2ClPc7,items,NMwXB7fWHCAUQrtlh = -1,[],[]
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(pETKl7xuH1f5yjdFAb6C8JzOLV,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'SERIES4WATCH-EPISODES-1st')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('ti-list-numbered(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		mfFwcWZHXVGvyU3B0ILburCoh = QigevCplXxbPI1H.join(fwSu6JsQZpEiv)
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"',mfFwcWZHXVGvyU3B0ILburCoh,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	items.append(url)
	items = set(items)
	for RMC6c2kL5hGOnFaIwAyb in items:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.strip('/')
		title = '_MOD_' + RMC6c2kL5hGOnFaIwAyb.split('/')[-1].replace('-',hT7zFDpEyUqf8sXuN)
		BLIwYgHkv25j1d6DsEUl3rae7M = sBvufaD6c9YHdOqTjCQ3.findall('الحلقة-(\d+)',RMC6c2kL5hGOnFaIwAyb.split('/')[-1],sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if BLIwYgHkv25j1d6DsEUl3rae7M: BLIwYgHkv25j1d6DsEUl3rae7M = BLIwYgHkv25j1d6DsEUl3rae7M[0]
		else: BLIwYgHkv25j1d6DsEUl3rae7M = '0'
		NMwXB7fWHCAUQrtlh.append([RMC6c2kL5hGOnFaIwAyb,title,BLIwYgHkv25j1d6DsEUl3rae7M])
	items = sorted(NMwXB7fWHCAUQrtlh, reverse=False, key=lambda key: int(key[2]))
	IkqaRtE8w7xBuhrFmi1K3WvU = str(items).count('/season/')
	xQg9UM2ClPc7 = str(items).count('/episode/')
	if IkqaRtE8w7xBuhrFmi1K3WvU>1 and xQg9UM2ClPc7>0 and '/season/' not in url:
		for RMC6c2kL5hGOnFaIwAyb,title,BLIwYgHkv25j1d6DsEUl3rae7M in items:
			if '/season/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,213)
	else:
		for RMC6c2kL5hGOnFaIwAyb,title,BLIwYgHkv25j1d6DsEUl3rae7M in items:
			if '/season/' not in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,212)
	return
def nibvTq2jfRXDM4tYP039S(url):
	ldFqnNIsftrY43JBM6LPjzU8m = []
	WShVouXDRCGjeIFMYTHyimk5dlz = url.split('/')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,url,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		Kj0TOU6BmSMlJHZYLd = url.replace(WShVouXDRCGjeIFMYTHyimk5dlz[3],'watch')
		BhxM1UVjtbEoSp640kIcag = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'SERIES4WATCH-PLAY-2nd')
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="servers-list(.*?)</div>',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if items:
				id = sBvufaD6c9YHdOqTjCQ3.findall('post_id=(.*?)"',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if id:
					TfilazROjy = id[0]
					for RMC6c2kL5hGOnFaIwAyb,title in items:
						RMC6c2kL5hGOnFaIwAyb = vxQUXEuH9m+'/?postid='+TfilazROjy+'&serverid='+RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
						ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
			else:
				items = sBvufaD6c9YHdOqTjCQ3.findall('data-embedd=".*?(http.*?)("|&quot;)',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				for RMC6c2kL5hGOnFaIwAyb,tX1WYGPmux in items:
					ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	if '/download/' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		Kj0TOU6BmSMlJHZYLd = url.replace(WShVouXDRCGjeIFMYTHyimk5dlz[3],'download')
		BhxM1UVjtbEoSp640kIcag = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,headers,QigevCplXxbPI1H,'SERIES4WATCH-PLAY-3rd')
		id = sBvufaD6c9YHdOqTjCQ3.findall('postId:"(.*?)"',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if id:
			TfilazROjy = id[0]
			T24Te3uDwBS5vLgUEAhF1O = { 'User-Agent':QigevCplXxbPI1H , 'X-Requested-With':'XMLHttpRequest' }
			Kj0TOU6BmSMlJHZYLd = vxQUXEuH9m + '/ajaxCenter?_action=getdownloadlinks&postId='+TfilazROjy
			BhxM1UVjtbEoSp640kIcag = XcU2IYdoEG9vzrDiLxsQC(g6gNzml5rOsa8bBETxPCpnVj,Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,T24Te3uDwBS5vLgUEAhF1O,QigevCplXxbPI1H,'SERIES4WATCH-PLAY-4th')
			fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<h3.*?(\d+)(.*?)</div>',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if fwSu6JsQZpEiv:
				for BWNcTU4ukQLAm25Xn3lbqrOzSJ,LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
					items = sBvufaD6c9YHdOqTjCQ3.findall('<td>(.*?)<.*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					for name,RMC6c2kL5hGOnFaIwAyb in items:
						ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__download'+'____'+BWNcTU4ukQLAm25Xn3lbqrOzSJ)
			else:
				fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<h6(.*?)</table>',BhxM1UVjtbEoSp640kIcag,sBvufaD6c9YHdOqTjCQ3.DOTALL)
				if not fwSu6JsQZpEiv: fwSu6JsQZpEiv = [BhxM1UVjtbEoSp640kIcag]
				for LKzFWsmvjUVGMDBapflx6H4NY in fwSu6JsQZpEiv:
					name = QigevCplXxbPI1H
					items = sBvufaD6c9YHdOqTjCQ3.findall('href="(http.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
					for RMC6c2kL5hGOnFaIwAyb in items:
						bSrdN78jxURTvh9 = '&&' + RMC6c2kL5hGOnFaIwAyb.split('/')[2].lower() + '&&'
						bSrdN78jxURTvh9 = bSrdN78jxURTvh9.replace('.com&&',QigevCplXxbPI1H).replace('.co&&',QigevCplXxbPI1H)
						bSrdN78jxURTvh9 = bSrdN78jxURTvh9.replace('.net&&',QigevCplXxbPI1H).replace('.org&&',QigevCplXxbPI1H)
						bSrdN78jxURTvh9 = bSrdN78jxURTvh9.replace('.live&&',QigevCplXxbPI1H).replace('.online&&',QigevCplXxbPI1H)
						bSrdN78jxURTvh9 = bSrdN78jxURTvh9.replace('&&hd.',QigevCplXxbPI1H).replace('&&www.',QigevCplXxbPI1H)
						bSrdN78jxURTvh9 = bSrdN78jxURTvh9.replace('&&',QigevCplXxbPI1H)
						RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb + '?named=' + name + bSrdN78jxURTvh9 + '__download'
						ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m + '/search?s='+search
	ddbEXhWzOnIaR(url)
	return
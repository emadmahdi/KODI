# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'FASELHD2'
headers = {'User-Agent':QigevCplXxbPI1H}
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_FH2_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['wwe']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==590: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==591: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==592: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==593: W9lfsoMawqOzpQcXD = XPjvI9V0xhbLzoQAStGTWM(url,text)
	elif mode==599: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	unA4F0ajXBUwHksrx3IyNCJL = vxQUXEuH9m
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',unA4F0ajXBUwHksrx3IyNCJL,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FASELHD2-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',unA4F0ajXBUwHksrx3IyNCJL,599,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المميزة',unA4F0ajXBUwHksrx3IyNCJL,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured1')
	items = sBvufaD6c9YHdOqTjCQ3.findall('<strong>(.*?)</strong>.*?href="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for title,RMC6c2kL5hGOnFaIwAyb in items:
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'details1')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('main-menu"(.*?)header-social',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		zOocdxW45QA9uGVljn7wh = sBvufaD6c9YHdOqTjCQ3.findall('<li (.*?)</li>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for by1nQW7VS4FL in zOocdxW45QA9uGVljn7wh:
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',by1nQW7VS4FL,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				if 'http' not in RMC6c2kL5hGOnFaIwAyb: RMC6c2kL5hGOnFaIwAyb = unA4F0ajXBUwHksrx3IyNCJL+RMC6c2kL5hGOnFaIwAyb
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'details2')
	return aY63L2NhgvwJIxPAoDG4MKECmZXF1
def ddbEXhWzOnIaR(url,type=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FASELHD2-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	EWny6xJ4fcKaLHrdmt5UPMA3 = 0
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"archive-slider(.*?)<h4>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if gQ5KvJ6G2lbWwYBOMiTr: Pk5h14WpxO3nAQFv0rYmNa8KDblSg = gQ5KvJ6G2lbWwYBOMiTr[0]
	else: Pk5h14WpxO3nAQFv0rYmNa8KDblSg = QigevCplXxbPI1H
	if type=='featured1':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"slider-carousel"(.*?)</container>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		JvMSAtx9C3lw2yXQ0,hu8mLEVaH12kwABO7nKtUpybXM,rsBojxT8UZwL = zip(*items)
		items = zip(rsBojxT8UZwL,JvMSAtx9C3lw2yXQ0,hu8mLEVaH12kwABO7nKtUpybXM)
	elif type=='featured2':
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',Pk5h14WpxO3nAQFv0rYmNa8KDblSg,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif type=='filters':
		fwSu6JsQZpEiv = [aY63L2NhgvwJIxPAoDG4MKECmZXF1.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in Pk5h14WpxO3nAQFv0rYmNa8KDblSg:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<h4>(.*?)</h4>(.*?)</container>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مميزة',url,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured2')
		title = fwSu6JsQZpEiv[0][0]
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'details3')
		return
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<h4>(.*?)</h4>(.*?)</container>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		title,LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	wibHRCAFtsupIjx4ZTELeM = []
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if any(nFdGHjceZzW in title.lower() for nFdGHjceZzW in ef1pQcbEtPjMnXYrvOi): continue
		title = title.strip(hT7zFDpEyUqf8sXuN)
		title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) (الحلقة|حلقة).\d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if '/movseries/' in RMC6c2kL5hGOnFaIwAyb:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,591,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY and type==QigevCplXxbPI1H:
			title = '_MOD_'+V1nZX7O5WwEq8HmvkY[0][0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,593,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		elif any(nFdGHjceZzW in title for nFdGHjceZzW in EcyPTkJuKBDvZRVe4):
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,592,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,593,cXu4fN1moCypJqb72OZvd)
	if type=='filters':
		G1kbAhTnqMwIjiVv3Cc = sBvufaD6c9YHdOqTjCQ3.findall('"more_button_page":(.*?),',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if G1kbAhTnqMwIjiVv3Cc:
			count = G1kbAhTnqMwIjiVv3Cc[0]
			RMC6c2kL5hGOnFaIwAyb = url+'/offset/'+count
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة أخرى',RMC6c2kL5hGOnFaIwAyb,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'filters')
	elif 'details' in type:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = 'صفحة '+i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,591,QigevCplXxbPI1H,QigevCplXxbPI1H,'details4')
	return
def XPjvI9V0xhbLzoQAStGTWM(url,type=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FASELHD2-SEASONS_EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	X6z7OV8NFovq0IKagdmberiM1 = False
	if not type:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<seasons(.*?)</seasons>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if len(items)>1:
				unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(url,'url')
				X6z7OV8NFovq0IKagdmberiM1 = True
				for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
					title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
					E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,593,cXu4fN1moCypJqb72OZvd,QigevCplXxbPI1H,'episodes')
	if type=='episodes' or not X6z7OV8NFovq0IKagdmberiM1:
		XGjn5q2cy6mRYZ1hPaDslHMK = sBvufaD6c9YHdOqTjCQ3.findall('<bkز*?image:url\((.*?)\)"></bk>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if XGjn5q2cy6mRYZ1hPaDslHMK: cXu4fN1moCypJqb72OZvd = XGjn5q2cy6mRYZ1hPaDslHMK[0]
		else: cXu4fN1moCypJqb72OZvd = QigevCplXxbPI1H
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<all-episodes(.*?)</all-episodes>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = title.strip(hT7zFDpEyUqf8sXuN)
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,592,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	vdLczqkV5b48ZKyGxTE3jJi17aWS6,KKXE5FZBpUAL4NRny91,fW5M4LSmOYJBgyswb1T8 = [],[],[]
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'FASELHD2-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	j21fXuSCrdZLvPFGei4qJz9MhR = sBvufaD6c9YHdOqTjCQ3.findall('العمر :.*?<strong">(.*?)</strong>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if j21fXuSCrdZLvPFGei4qJz9MhR and Q7YCG4unmP8HTL(PuT0IphGNsketAQ,url,j21fXuSCrdZLvPFGei4qJz9MhR): return
	RMC6c2kL5hGOnFaIwAyb = sBvufaD6c9YHdOqTjCQ3.findall('<iframe src="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if RMC6c2kL5hGOnFaIwAyb:
		RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb[0]
		vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named=__embed')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<slice-title(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-url="(.*?)".*?</i>(.*?)</li>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,name in items:
			name = name.strip(hT7zFDpEyUqf8sXuN)
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__watch')
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('<downloads(.*?)</downloads>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?</div>(.*?)</div>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,name in items:
			vdLczqkV5b48ZKyGxTE3jJi17aWS6.append(RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__download')
	for HNf7BK8xJn1gAa5CY9s0rjeRTlM3 in vdLczqkV5b48ZKyGxTE3jJi17aWS6:
		RMC6c2kL5hGOnFaIwAyb,name = HNf7BK8xJn1gAa5CY9s0rjeRTlM3.split('?named')
		if RMC6c2kL5hGOnFaIwAyb not in KKXE5FZBpUAL4NRny91:
			KKXE5FZBpUAL4NRny91.append(RMC6c2kL5hGOnFaIwAyb)
			fW5M4LSmOYJBgyswb1T8.append(HNf7BK8xJn1gAa5CY9s0rjeRTlM3)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(fW5M4LSmOYJBgyswb1T8,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	unA4F0ajXBUwHksrx3IyNCJL = vxQUXEuH9m
	url = unA4F0ajXBUwHksrx3IyNCJL+'/?s='+search
	ddbEXhWzOnIaR(url,'details5')
	return
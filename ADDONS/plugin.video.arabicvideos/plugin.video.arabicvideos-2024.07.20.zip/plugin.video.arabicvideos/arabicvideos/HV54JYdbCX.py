# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from TEsNM9QVZc import *
PuT0IphGNsketAQ = TCF8wLyDvgumfiXPSKRh(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫࢭ")
def YnMSWTbKj1N8wuRJVF(TsckNQJ6yLiaEeCRml98WwKfVP0dYv,XCapNbgw2xWQ5jRt):
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==bDt7Ya1VEio3(u"࠳࠴࠲ा"): W9lfsoMawqOzpQcXD = PioZcsulmBFWw()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Fg72JX6T5DkPy(u"࠴࠵࠴ि"): W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(XCapNbgw2xWQ5jRt)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==JJu4MPClbTFpUwHiN(u"࠵࠶࠶ी"): W9lfsoMawqOzpQcXD = M3VsLkOJFlZU2jXpwDHEad0bA4()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Xr2aHOK0huQ5DTS(u"࠶࠷࠸ु"): W9lfsoMawqOzpQcXD = ZAlUIFh5PzDfTv3RSsBiOu6xm2wC4t()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==y5yX4jh6kUEgWZQIc(u"࠷࠸࠺ू"): W9lfsoMawqOzpQcXD = tNMC5KveRUDWfzYAaGymgHIdoJ1S6(XCapNbgw2xWQ5jRt)
	else: W9lfsoMawqOzpQcXD = YoAMfqm37GyFxbuKTt6e8CESHrhB
	return W9lfsoMawqOzpQcXD
def tNMC5KveRUDWfzYAaGymgHIdoJ1S6(O5CdB3ZYW91G4E):
	try: KiTt9ZskMLjnCAUIJNXD7.remove(O5CdB3ZYW91G4E.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL))
	except: KiTt9ZskMLjnCAUIJNXD7.remove(O5CdB3ZYW91G4E)
	return
def nibvTq2jfRXDM4tYP039S(XCapNbgw2xWQ5jRt):
	B9BaTCd86Iwz1e3sRMXZylKpcHU(XCapNbgw2xWQ5jRt,PuT0IphGNsketAQ,tg9l25NH6WTacVSifLyAmY(u"ࠪࡺ࡮ࡪࡥࡰࠩࢮ"))
	return
def ZAlUIFh5PzDfTv3RSsBiOu6xm2wC4t():
	nDRKguWex0iVN8 = pGncXOodjKhJzLSqVP1r(u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪࢯ")
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Xr2aHOK0huQ5DTS(u"ࠬ฽ั๋ไฬࠤฯำๅ๋ๆࠣห้๋ไโษอࠫࢰ"),nDRKguWex0iVN8)
	return
def PioZcsulmBFWw():
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(Fg72JX6T5DkPy(u"࠭࡬ࡪࡰ࡮ࠫࢱ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+y5yX4jh6kUEgWZQIc(u"ุࠧำํๆฮࠦสฮ็ํ่๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬࢲ")+jhAlCQ47ZgG,QigevCplXxbPI1H,vZL6j4tSClIGxzNE5DX(u"࠸࠹࠳ृ"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(tg9l25NH6WTacVSifLyAmY(u"ࠨ࡮࡬ࡲࡰ࠭ࢳ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩอ฾๏๐ัࠡ็ๆห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠩࢴ")+jhAlCQ47ZgG,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"࠹࠳࠳ॄ"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪࡰ࡮ࡴ࡫ࠨࢵ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+g4UCaNkHvLwGhjmW(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪࢶ")+jhAlCQ47ZgG,QigevCplXxbPI1H,svULcgJ7jm(u"࠹࠺࠻࠼ॅ"))
	y2szBREkPSfhO7egronjqbwQTNJX0 = KC6jXPzHpE7VaBD()
	n2sPV6SCFQ9NkA = KiTt9ZskMLjnCAUIJNXD7.stat(y2szBREkPSfhO7egronjqbwQTNJX0).st_mtime
	ad6U8LEqbwI9t7PhKOkJBusX4en = []
	if b7sJAmSxlBvaMdHFz: MBV93fbKUDu2rLg65ZjR0 = KiTt9ZskMLjnCAUIJNXD7.listdir(y2szBREkPSfhO7egronjqbwQTNJX0.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL))
	else: MBV93fbKUDu2rLg65ZjR0 = KiTt9ZskMLjnCAUIJNXD7.listdir(y2szBREkPSfhO7egronjqbwQTNJX0.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL))
	for eehakOTYstEIfg5zd in MBV93fbKUDu2rLg65ZjR0:
		if b7sJAmSxlBvaMdHFz: eehakOTYstEIfg5zd = eehakOTYstEIfg5zd.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		if not eehakOTYstEIfg5zd.startswith(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬ࡬ࡩ࡭ࡧࡢࠫࢷ")): continue
		GjP73zHxQeMDViokLgaJITROmZh = KiTt9ZskMLjnCAUIJNXD7.path.join(y2szBREkPSfhO7egronjqbwQTNJX0,eehakOTYstEIfg5zd)
		n2sPV6SCFQ9NkA = KiTt9ZskMLjnCAUIJNXD7.path.getmtime(GjP73zHxQeMDViokLgaJITROmZh)
		ad6U8LEqbwI9t7PhKOkJBusX4en.append([eehakOTYstEIfg5zd,n2sPV6SCFQ9NkA])
	ad6U8LEqbwI9t7PhKOkJBusX4en = sorted(ad6U8LEqbwI9t7PhKOkJBusX4en,reverse=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,key=lambda key: key[nfC2im3NzUQk])
	for eehakOTYstEIfg5zd,n2sPV6SCFQ9NkA in ad6U8LEqbwI9t7PhKOkJBusX4en:
		if L2EXWK5vf3AoDtV8F6OgNBqkmyG:
			try: eehakOTYstEIfg5zd = eehakOTYstEIfg5zd.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
			except: pass
			eehakOTYstEIfg5zd = eehakOTYstEIfg5zd.encode(zW0xYFg17enwNcXOmKqvikapMyfHjL)
		GjP73zHxQeMDViokLgaJITROmZh = KiTt9ZskMLjnCAUIJNXD7.path.join(y2szBREkPSfhO7egronjqbwQTNJX0,eehakOTYstEIfg5zd)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj(XWbHfI9B8swrOL(u"࠭ࡶࡪࡦࡨࡳࠬࢸ"),eehakOTYstEIfg5zd,GjP73zHxQeMDViokLgaJITROmZh,pTwKPmzMSZhil5d2RWonre(u"࠴࠵࠴ॆ"))
	return
def KC6jXPzHpE7VaBD():
	y2szBREkPSfhO7egronjqbwQTNJX0 = uUTRHgAXJzm7pIDBjNt8.getSetting(pGncXOodjKhJzLSqVP1r(u"ࠧࡢࡸ࠱ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠳ࡶࡡࡵࡪࠪࢹ"))
	if y2szBREkPSfhO7egronjqbwQTNJX0: return y2szBREkPSfhO7egronjqbwQTNJX0
	uUTRHgAXJzm7pIDBjNt8.setSetting(DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡣࡹ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠴ࡰࡢࡶ࡫ࠫࢺ"),nZ5AkguavpEc7zWo8SOHRD)
	return nZ5AkguavpEc7zWo8SOHRD
def M3VsLkOJFlZU2jXpwDHEad0bA4():
	y2szBREkPSfhO7egronjqbwQTNJX0 = KC6jXPzHpE7VaBD()
	PdqbjvYcxAJTGINtrH4EF2Ug5WB09 = UJV3rPyElz5xRav0FD(bDt7Ya1VEio3(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢻ"),QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢼ"),r9rhtA5Tek8sIoLfqwF7JcEV+y2szBREkPSfhO7egronjqbwQTNJX0+jhAlCQ47ZgG+XWbHfI9B8swrOL(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬࢽ"))
	if PdqbjvYcxAJTGINtrH4EF2Ug5WB09==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠳े"):
		GGsvd5wyCarROxf0 = Y3VgCSHRF6dtK0DX5AWGlqb7(vZL6j4tSClIGxzNE5DX(u"࠶ै"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"๋ࠬใศ่ࠣฮา๋๊ๅ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩࢾ"),mmKqLr9RX0ACN384JMcsFHzd(u"࠭࡬ࡰࡥࡤࡰࠬࢿ"),QigevCplXxbPI1H,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,y2szBREkPSfhO7egronjqbwQTNJX0)
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡤࡧࡱࡸࡪࡸࠧࣀ"),QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠨ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊สฮ็ํ่ࠬࣁ"),r9rhtA5Tek8sIoLfqwF7JcEV+y2szBREkPSfhO7egronjqbwQTNJX0+jhAlCQ47ZgG+v54ZuLY6dQ(u"ࠩ࡟ࡲࡡࡴ็ัษ๋ࠣํࠦวๅ็ๆห๋ࠦวๅฮา๎ิࠦไหะี๎๋ࠦๅๅใสฮࠥอไโ์า๎ํࠦวๅฬํࠤฯำๅๅ้สࠤฬ์สࠡสสืฯิฯศ็๋ࠣีอࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥอำหะาห๊ํࠠษั็ห๋ࠥๆࠡษ็้่อๆࠡษ็ๆิ๐ๅࠡมࠪࣂ"))
		if nndcv6tehuoKPpI==K7bLVaiRkx0lgU5SQM(u"࠵ॉ"):
			uUTRHgAXJzm7pIDBjNt8.setSetting(JJu4MPClbTFpUwHiN(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࣃ"),GGsvd5wyCarROxf0)
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,tOrSvd8QKNB(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࣄ"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠬะๅࠡฬ฽๎๏ืࠠๆๅส๊ࠥะฮำ์้ࠤฬ๊ๅๅใสฮࠥอไๆฯ่่ฮ࠭ࣅ"))
	return
def z91Sfe65ZD4RsdXwokHPFcyQ0T(XCapNbgw2xWQ5jRt,denYhNEq72TZSD0psXick9tzg5=QigevCplXxbPI1H,website=QigevCplXxbPI1H):
	SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+Fg72JX6T5DkPy(u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣆ")+XCapNbgw2xWQ5jRt+Fg72JX6T5DkPy(u"ࠧࠡ࡟ࠪࣇ"))
	if not denYhNEq72TZSD0psXick9tzg5: denYhNEq72TZSD0psXick9tzg5 = z2dZ1anR6O(XCapNbgw2xWQ5jRt)
	y2szBREkPSfhO7egronjqbwQTNJX0 = KC6jXPzHpE7VaBD()
	kZINFVLcUObK8Wsxohq0 = RU3DWNPsrdXFHT7jB0lmC()
	eehakOTYstEIfg5zd = kZINFVLcUObK8Wsxohq0.replace(hT7zFDpEyUqf8sXuN,svULcgJ7jm(u"ࠨࡡࠪࣈ"))
	eehakOTYstEIfg5zd = W8eXj3fGrbByNQPCnhY(eehakOTYstEIfg5zd)
	eehakOTYstEIfg5zd = WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࡩ࡭ࡱ࡫࡟ࠨࣉ")+str(int(qyUPZBiAE3YkuOKrMnTFex92D))[-mpusoZBJ6V(u"࠹ॊ"):]+TCF8wLyDvgumfiXPSKRh(u"ࠪࡣࠬ࣊")+eehakOTYstEIfg5zd+denYhNEq72TZSD0psXick9tzg5
	Znh3Rt7GPdW5s241oJDazjSvE = KiTt9ZskMLjnCAUIJNXD7.path.join(y2szBREkPSfhO7egronjqbwQTNJX0,eehakOTYstEIfg5zd)
	UFtxHq7c39mD = {}
	UFtxHq7c39mD[JJu4MPClbTFpUwHiN(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭࣋")] = QigevCplXxbPI1H
	UFtxHq7c39mD[NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࡇࡣࡤࡧࡳࡸࠬ࣌")] = OOhnpQ8XvCVclGqdu(u"࠭ࠪ࠰ࠬࠪ࣍")
	XCapNbgw2xWQ5jRt = XCapNbgw2xWQ5jRt.replace(y5yX4jh6kUEgWZQIc(u"ࠧࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁࡦࡼࡢࡰࡱ࡯ࡩࡦࡴࡦࡢ࡮ࡶࡩࠬ࣎"),QigevCplXxbPI1H)
	if vZL6j4tSClIGxzNE5DX(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࣏࠭") in XCapNbgw2xWQ5jRt:
		Kj0TOU6BmSMlJHZYLd,lfPqTpgMXhVcd = XCapNbgw2xWQ5jRt.rsplit(svULcgJ7jm(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃ࣐ࠧ"),y5yX4jh6kUEgWZQIc(u"࠷ो"))
		lfPqTpgMXhVcd = lfPqTpgMXhVcd.replace(g4UCaNkHvLwGhjmW(u"ࠪࢀ࣑ࠬ"),QigevCplXxbPI1H).replace(aqUlAdFto05NmG4Y6guEzTr8vK(u"࣒ࠫࠫ࠭"),QigevCplXxbPI1H)
	else: Kj0TOU6BmSMlJHZYLd,lfPqTpgMXhVcd = XCapNbgw2xWQ5jRt,None
	if not lfPqTpgMXhVcd: lfPqTpgMXhVcd = eUBL1rOR4ZfndJAWPsoN6pybT0()
	if lfPqTpgMXhVcd: UFtxHq7c39mD[K7bLVaiRkx0lgU5SQM(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࣓ࠩ")] = lfPqTpgMXhVcd
	if Xr2aHOK0huQ5DTS(u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨࣔ") in Kj0TOU6BmSMlJHZYLd: Kj0TOU6BmSMlJHZYLd,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = Kj0TOU6BmSMlJHZYLd.rsplit(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩࣕ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠱ौ"))
	else: Kj0TOU6BmSMlJHZYLd,TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.strip(FF70emVxhWOngCty(u"ࠨࡾࠪࣖ")).strip(mpusoZBJ6V(u"ࠩࠩࠫࣗ")).strip(Fg72JX6T5DkPy(u"ࠪࢀࠬࣘ")).strip(mpusoZBJ6V(u"ࠫࠫ࠭ࣙ"))
	TTrmYne2lRXM0jLyHAF8CzQ7vpKi6 = TTrmYne2lRXM0jLyHAF8CzQ7vpKi6.replace(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬࢂࠧࣚ"),QigevCplXxbPI1H).replace(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭ࠦࠨࣛ"),QigevCplXxbPI1H)
	if TTrmYne2lRXM0jLyHAF8CzQ7vpKi6:	UFtxHq7c39mD[Xr2aHOK0huQ5DTS(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨࣜ")] = TTrmYne2lRXM0jLyHAF8CzQ7vpKi6
	SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩࣝ")+Kj0TOU6BmSMlJHZYLd+DDHwpETQrAm0xMNXGfyhqsUi(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬࣞ")+str(UFtxHq7c39mD)+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣟ")+Znh3Rt7GPdW5s241oJDazjSvE+mmKqLr9RX0ACN384JMcsFHzd(u"ࠫࠥࡣࠧ࣠"))
	KmQftHqs6RuGLIg2lO7ndPUehX3DAJ = QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠲࠲࠵࠸्")*QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠲࠲࠵࠸्")
	If0LEPSjhX = Xr2aHOK0huQ5DTS(u"࠲ॎ")
	try:
		DrHNh2fVnwWAQpPg =	qVuYLZTmSUhQe7rEwvFRfc.getInfoLabel(DDHwpETQrAm0xMNXGfyhqsUi(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡌࡲࡦࡧࡖࡴࡦࡩࡥࠨ࣡"))
		DrHNh2fVnwWAQpPg = sBvufaD6c9YHdOqTjCQ3.findall(VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭࡜ࡥ࠭ࠪ࣢"),DrHNh2fVnwWAQpPg)
		If0LEPSjhX = int(DrHNh2fVnwWAQpPg[h17Zb2ld4yLBrCP5tiw])
	except: pass
	if not If0LEPSjhX:
		try:
			dbxvA5ikp84SwVr9ycCQXI = KiTt9ZskMLjnCAUIJNXD7.statvfs(y2szBREkPSfhO7egronjqbwQTNJX0)
			If0LEPSjhX = dbxvA5ikp84SwVr9ycCQXI.f_frsize*dbxvA5ikp84SwVr9ycCQXI.f_bavail//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ
		except: pass
	if not If0LEPSjhX:
		try:
			dbxvA5ikp84SwVr9ycCQXI = KiTt9ZskMLjnCAUIJNXD7.fstatvfs(y2szBREkPSfhO7egronjqbwQTNJX0)
			If0LEPSjhX = dbxvA5ikp84SwVr9ycCQXI.f_frsize*dbxvA5ikp84SwVr9ycCQXI.f_bavail//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ
		except: pass
	if not If0LEPSjhX:
		try:
			import shutil as rUjHo2P4f5Jn0C
			aACH7pwVFPdU0vqMSTo5N,EQaehVULjyYKMB,k39YEaNvZXCwUOAluSdRKDM = rUjHo2P4f5Jn0C.disk_usage(y2szBREkPSfhO7egronjqbwQTNJX0)
			If0LEPSjhX = k39YEaNvZXCwUOAluSdRKDM//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ
		except: pass
	if not If0LEPSjhX:
		XRZyfuiD8nLlKYPJ(y5yX4jh6kUEgWZQIc(u"ࠧࡳ࡫ࡪ࡬ࡹࣣ࠭"),DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨࣤ"),JJu4MPClbTFpUwHiN(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭ࣥ"),Fg72JX6T5DkPy(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࣦ࠭"))
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+K7bLVaiRkx0lgU5SQM(u"ࠫࠥࠦࠠࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡴࡩࡧࠣࡨ࡮ࡹ࡫ࠡࡨࡵࡩࡪࠦࡳࡱࡣࡦࡩࠬࣧ"))
		return YoAMfqm37GyFxbuKTt6e8CESHrhB
	if denYhNEq72TZSD0psXick9tzg5==hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠬ࠴࡭࠴ࡷ࠻ࠫࣨ"):
		ttGBwQOv3K41hIkc6,ldFqnNIsftrY43JBM6LPjzU8m = HHSM1J4ofulwIPqTjnQA(Kj0TOU6BmSMlJHZYLd,UFtxHq7c39mD)
		if len(ttGBwQOv3K41hIkc6)==mmKqLr9RX0ACN384JMcsFHzd(u"࠳ॏ"):
			X69Fkr1VNnf2pJQC8wl7YR4HmaKc(vZL6j4tSClIGxzNE5DX(u"࠭แีๆࠣๅ๏ࠦล๋ฮสำ๋ࠥไโࠢส่ฯำๅ๋ๆࣩࠪ"),QigevCplXxbPI1H)
			return YoAMfqm37GyFxbuKTt6e8CESHrhB
		elif len(ttGBwQOv3K41hIkc6)==aqUlAdFto05NmG4Y6guEzTr8vK(u"࠵ॐ"): HHZ6579kAv8 = tOrSvd8QKNB(u"࠵॑")
		elif len(ttGBwQOv3K41hIkc6)>TCF8wLyDvgumfiXPSKRh(u"࠷॒"):
			HHZ6579kAv8 = zYWJO03iISD(svULcgJ7jm(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ࣪"), ttGBwQOv3K41hIkc6)
			if HHZ6579kAv8 == -aqUlAdFto05NmG4Y6guEzTr8vK(u"࠱॓") :
				X69Fkr1VNnf2pJQC8wl7YR4HmaKc(mpusoZBJ6V(u"ࠨฬ่ࠤสฺ๊ศรࠣห้ะอๆ์็ࠫ࣫"),QigevCplXxbPI1H)
				return YoAMfqm37GyFxbuKTt6e8CESHrhB
		Kj0TOU6BmSMlJHZYLd = ldFqnNIsftrY43JBM6LPjzU8m[HHZ6579kAv8]
	ve2x0RQtnT3P9k7KU1maINXVChB = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠱॔")
	import requests as rBU6o8SmdykhQ
	if denYhNEq72TZSD0psXick9tzg5==bDt7Ya1VEio3(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ࣬"):
		Znh3Rt7GPdW5s241oJDazjSvE = Znh3Rt7GPdW5s241oJDazjSvE.rsplit(QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠪ࠲ࡲ࠹ࡵ࠹࣭ࠩ"))[h17Zb2ld4yLBrCP5tiw]+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠫ࠳ࡳࡰ࠵࣮ࠩ")
		T4U1lV3YFrtSv = hPo36xNERyQtmrMABnDc4zKY0elUa(vjPhaUE819opVQg7uRk4wG6cYBOTd,bDt7Ya1VEio3(u"ࠬࡍࡅࡕ࣯ࠩ"),Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,UFtxHq7c39mD,QigevCplXxbPI1H,QigevCplXxbPI1H,WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄ࠮ࡆࡒ࡛ࡓࡒࡏࡂࡆࡢ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹࣰ࠭"))
		HhdD6AcQ7sC03uIO9UGl14k = T4U1lV3YFrtSv.content
		rsBojxT8UZwL = sBvufaD6c9YHdOqTjCQ3.findall(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࠤࡇ࡛ࡘࡎࡔࡆ࠻࠰࠭ࡃࡠࡢ࡮࡝ࡴࡠࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠨࣱ"),HhdD6AcQ7sC03uIO9UGl14k+hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨ࡞ࡱࡠࡷࣲ࠭"),sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not rsBojxT8UZwL:
			SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+bDt7Ya1VEio3(u"ࠩࠣࠤ࡚ࠥࡨࡦࠢࡰ࠷ࡺ࠾ࠠࡧ࡫࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡨࡢࡸࡨࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࡦࠣࡰ࡮ࡴ࡫ࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬࣳ")+Kj0TOU6BmSMlJHZYLd+Fg72JX6T5DkPy(u"ࠪࠤࡢ࠭ࣴ"))
			return YoAMfqm37GyFxbuKTt6e8CESHrhB
		RMC6c2kL5hGOnFaIwAyb = rsBojxT8UZwL[h17Zb2ld4yLBrCP5tiw]
		if not RMC6c2kL5hGOnFaIwAyb.startswith(OOhnpQ8XvCVclGqdu(u"ࠫ࡭ࡺࡴࡱࠩࣵ")):
			if RMC6c2kL5hGOnFaIwAyb.startswith(svULcgJ7jm(u"ࠬ࠵࠯ࠨࣶ")): RMC6c2kL5hGOnFaIwAyb = Kj0TOU6BmSMlJHZYLd.split(Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠭࠺ࠨࣷ"),FF70emVxhWOngCty(u"࠳ॕ"))[h17Zb2ld4yLBrCP5tiw]+tg9l25NH6WTacVSifLyAmY(u"ࠧ࠻ࠩࣸ")+RMC6c2kL5hGOnFaIwAyb
			elif RMC6c2kL5hGOnFaIwAyb.startswith(JJu4MPClbTFpUwHiN(u"ࠨ࠱ࣹࠪ")): RMC6c2kL5hGOnFaIwAyb = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,O4ylJvVNwLztdiHqBWDU(u"ࠩࡸࡶࡱࣺ࠭"))+RMC6c2kL5hGOnFaIwAyb
			else: RMC6c2kL5hGOnFaIwAyb = Kj0TOU6BmSMlJHZYLd.rsplit(JJu4MPClbTFpUwHiN(u"ࠪ࠳ࠬࣻ"),mmKqLr9RX0ACN384JMcsFHzd(u"࠴ॖ"))[h17Zb2ld4yLBrCP5tiw]+pGncXOodjKhJzLSqVP1r(u"ࠫ࠴࠭ࣼ")+RMC6c2kL5hGOnFaIwAyb
		T4U1lV3YFrtSv = rBU6o8SmdykhQ.request(K7bLVaiRkx0lgU5SQM(u"ࠬࡍࡅࡕࠩࣽ"),RMC6c2kL5hGOnFaIwAyb,headers=UFtxHq7c39mD,verify=YoAMfqm37GyFxbuKTt6e8CESHrhB)
		S5g0Fr4JEmXWzO9VQtlyjUDABGbn = T4U1lV3YFrtSv.content
		zzm8wqcdorbxEQgaUj = len(S5g0Fr4JEmXWzO9VQtlyjUDABGbn)
		aaEGJYkv6tcRMso1hK0 = len(rsBojxT8UZwL)
		ve2x0RQtnT3P9k7KU1maINXVChB = zzm8wqcdorbxEQgaUj*aaEGJYkv6tcRMso1hK0
	else:
		zzm8wqcdorbxEQgaUj = g4UCaNkHvLwGhjmW(u"࠵ॗ")*KmQftHqs6RuGLIg2lO7ndPUehX3DAJ
		T4U1lV3YFrtSv = rBU6o8SmdykhQ.request(g4UCaNkHvLwGhjmW(u"࠭ࡇࡆࡖࠪࣾ"),Kj0TOU6BmSMlJHZYLd,headers=UFtxHq7c39mD,verify=YoAMfqm37GyFxbuKTt6e8CESHrhB,stream=XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
		if pTwKPmzMSZhil5d2RWonre(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨࣿ") in T4U1lV3YFrtSv.headers: ve2x0RQtnT3P9k7KU1maINXVChB = int(T4U1lV3YFrtSv.headers[DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩऀ")])
		aaEGJYkv6tcRMso1hK0 = int(ve2x0RQtnT3P9k7KU1maINXVChB//zzm8wqcdorbxEQgaUj)
	g1gQfCpZG3ViFtl = int(ve2x0RQtnT3P9k7KU1maINXVChB//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ)+pGncXOodjKhJzLSqVP1r(u"࠶क़")
	if ve2x0RQtnT3P9k7KU1maINXVChB<bDt7Ya1VEio3(u"࠸࠱࠱࠲࠳ख़"):
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+bDt7Ya1VEio3(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢ࡬ࡷࠥࡺ࡯ࡰࠢࡶࡱࡦࡲ࡬ࠡࡱࡵࠤ࡮ࡺࠠࡪࡵࠣࡱ࠸ࡻ࠸࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫँ")+Kj0TOU6BmSMlJHZYLd+mmKqLr9RX0ACN384JMcsFHzd(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧं")+str(g1gQfCpZG3ViFtl)+JJu4MPClbTFpUwHiN(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪः")+str(If0LEPSjhX)+pTwKPmzMSZhil5d2RWonre(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨऄ")+Znh3Rt7GPdW5s241oJDazjSvE+OOhnpQ8XvCVclGqdu(u"࠭ࠠ࡞ࠩअ"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪआ"),QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠨใื่ࠥ็๊ࠡ็฼ีๆฯࠠฮฮ่ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไๆๆไࠤฺเ๊าࠢฯำฬ่ࠦๅ้ำห๊ࠥวࠡ์่็๋ࠦไๅสิ๊ฬ๋ฬࠡฬะ้๏๊่ࠠาสࠤฬ๊ๅๅใࠪइ"))
		return YoAMfqm37GyFxbuKTt6e8CESHrhB
	zBdlmFtC7V2SGIM4ksoiUP = v54ZuLY6dQ(u"࠴࠱࠲ग़")
	rWUkoJ3YT6NgpenX5LQ78 = If0LEPSjhX-g1gQfCpZG3ViFtl
	if rWUkoJ3YT6NgpenX5LQ78<zBdlmFtC7V2SGIM4ksoiUP:
		SQdRhwozVfv(QKaGISLxUqbmh,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+TCF8wLyDvgumfiXPSKRh(u"ࠩࠣࠤࠥࡔ࡯ࡵࠢࡨࡲࡴࡻࡧࡩࠢࡧ࡭ࡸࡱࠠࡴࡲࡤࡧࡪࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡹ࡮ࡥࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨई")+Kj0TOU6BmSMlJHZYLd+TCF8wLyDvgumfiXPSKRh(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧउ")+str(g1gQfCpZG3ViFtl)+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪऊ")+str(If0LEPSjhX)+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠬࠦࡍࡃࠢ࠰ࠤࠬऋ")+str(zBdlmFtC7V2SGIM4ksoiUP)+vZL6j4tSClIGxzNE5DX(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩऌ")+Znh3Rt7GPdW5s241oJDazjSvE+OOhnpQ8XvCVclGqdu(u"ࠧࠡ࡟ࠪऍ"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨๆสࠤ๏๎ฬะ่ࠢืฬำษࠡๅสๅ๏ฯࠠๅๆอั๊๐ไࠨऎ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩส่๊๊แࠡษ็้฼๊่ษࠢอั๊๐ไ่ࠢะะ๊ํࠠࠨए")+str(g1gQfCpZG3ViFtl)+Fg72JX6T5DkPy(u"ࠪࠤ๊๐ฺศสส๎ฯ่ࠦอ้สึ่ࠦแุ๋้้ࠣออสࠢไหึเษࠡࠩऐ")+str(If0LEPSjhX)+tg9l25NH6WTacVSifLyAmY(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠๆ็้าอแูหࠣ฽้๏ฺࠠ็็ࠤัํวำๅࠣฬิ๎ๆࠡ็ืห่๊๋ࠠฮหࠤสฮโศรࠣࠫऑ")+str(zBdlmFtC7V2SGIM4ksoiUP)+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠬࠦๅ๋฼สฬฬ๐สࠡใสี฿ฯࠠะษษ้ฬ่่ࠦาสࠤ๊฿ๆศ้ࠣว๋ࠦฬ่ษี็๊ࠥวࠡฬ๋ะิࠦแุ๋้้ࠣออสࠢๆหๆ๐ษࠡๆอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮࠧऒ"))
		return YoAMfqm37GyFxbuKTt6e8CESHrhB
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(s0vAWcLSXEToH9Mik134q(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ओ"),QigevCplXxbPI1H,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"่ࠧๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦฟࠨऔ"),Fg72JX6T5DkPy(u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฯฯ้์ࠦสใำํฬฬࠦࠧक")+str(g1gQfCpZG3ViFtl)+DD7NjwespWyQJ4E6mXk0ZAufPg(u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠหไิ๎ออࠠࠨख")+str(If0LEPSjhX)+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪࠤ๊๐ฺศสส๎ฯ่่ࠦาสࠤฬ๊ๅๅใࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡๆ็ฮา๋๊ๅ่๊ࠢࠥอไฦ่อี๋ะࠠฦๆ์ࠤัํวำๅࠣ࠲ࠥํไࠡษ้ฮ๋ࠥสฤๅาࠤํะั๋ัࠣห้อำห็ิหึࠦศหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฤ࠭ग"))
	if nndcv6tehuoKPpI!=tg9l25NH6WTacVSifLyAmY(u"࠲ज़"):
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩघ"))
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+K7bLVaiRkx0lgU5SQM(u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡰࡨࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧङ")+Kj0TOU6BmSMlJHZYLd+pGncXOodjKhJzLSqVP1r(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭च")+Znh3Rt7GPdW5s241oJDazjSvE+g4UCaNkHvLwGhjmW(u"ࠧࠡ࡟ࠪछ"))
		return YoAMfqm37GyFxbuKTt6e8CESHrhB
	SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+K7bLVaiRkx0lgU5SQM(u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡵࡣࡵࡸࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠭ज"))
	KeUEGFHb0LfrZhCaqd3O4NuDTQ = EkO3SZvUhBmswzoC2cKRbfxyMYW7H()
	KeUEGFHb0LfrZhCaqd3O4NuDTQ.create(Znh3Rt7GPdW5s241oJDazjSvE,VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪझ"))
	UUNhZY7wC6QgxPvfEqy9 = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	T9Ax7pUEP6Ilg4cC = B3TKLo71hAGRqYgV0.time()
	if b7sJAmSxlBvaMdHFz: Ggv4tSadse02uJL1DZrnNfq = open(Znh3Rt7GPdW5s241oJDazjSvE,y5yX4jh6kUEgWZQIc(u"ࠪࡻࡧ࠭ञ"))
	else: Ggv4tSadse02uJL1DZrnNfq = open(Znh3Rt7GPdW5s241oJDazjSvE.decode(zW0xYFg17enwNcXOmKqvikapMyfHjL),y5yX4jh6kUEgWZQIc(u"ࠫࡼࡨࠧट"))
	if denYhNEq72TZSD0psXick9tzg5==FF70emVxhWOngCty(u"ࠬ࠴࡭࠴ࡷ࠻ࠫठ"):
		for GzabfJx3T1 in range(tOrSvd8QKNB(u"࠳ड़"),aaEGJYkv6tcRMso1hK0+tOrSvd8QKNB(u"࠳ड़")):
			RMC6c2kL5hGOnFaIwAyb = rsBojxT8UZwL[GzabfJx3T1-pTwKPmzMSZhil5d2RWonre(u"࠴ढ़")]
			if not RMC6c2kL5hGOnFaIwAyb.startswith(y5yX4jh6kUEgWZQIc(u"࠭ࡨࡵࡶࡳࠫड")):
				if RMC6c2kL5hGOnFaIwAyb.startswith(pTwKPmzMSZhil5d2RWonre(u"ࠧ࠰࠱ࠪढ")): RMC6c2kL5hGOnFaIwAyb = Kj0TOU6BmSMlJHZYLd.split(TCF8wLyDvgumfiXPSKRh(u"ࠨ࠼ࠪण"),TCF8wLyDvgumfiXPSKRh(u"࠵फ़"))[h17Zb2ld4yLBrCP5tiw]+Xr2aHOK0huQ5DTS(u"ࠩ࠽ࠫत")+RMC6c2kL5hGOnFaIwAyb
				elif RMC6c2kL5hGOnFaIwAyb.startswith(pGncXOodjKhJzLSqVP1r(u"ࠪ࠳ࠬथ")): RMC6c2kL5hGOnFaIwAyb = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,OTRKI6LbrQnZEm(u"ࠫࡺࡸ࡬ࠨद"))+RMC6c2kL5hGOnFaIwAyb
				else: RMC6c2kL5hGOnFaIwAyb = Kj0TOU6BmSMlJHZYLd.rsplit(svULcgJ7jm(u"ࠬ࠵ࠧध"),NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠶य़"))[h17Zb2ld4yLBrCP5tiw]+O4ylJvVNwLztdiHqBWDU(u"࠭࠯ࠨन")+RMC6c2kL5hGOnFaIwAyb
			T4U1lV3YFrtSv = rBU6o8SmdykhQ.request(hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠧࡈࡇࡗࠫऩ"),RMC6c2kL5hGOnFaIwAyb,headers=UFtxHq7c39mD,verify=YoAMfqm37GyFxbuKTt6e8CESHrhB)
			S5g0Fr4JEmXWzO9VQtlyjUDABGbn = T4U1lV3YFrtSv.content
			T4U1lV3YFrtSv.close()
			Ggv4tSadse02uJL1DZrnNfq.write(S5g0Fr4JEmXWzO9VQtlyjUDABGbn)
			GSiF9DxgB2 = B3TKLo71hAGRqYgV0.time()
			cc51OCnJKMS3Dzjv = GSiF9DxgB2-T9Ax7pUEP6Ilg4cC
			b4GzImt8YRaBkxcsy3KqM9NjeAhu = cc51OCnJKMS3Dzjv//GzabfJx3T1
			FmrC0jlog7cJu1ESetvdUsKW8 = b4GzImt8YRaBkxcsy3KqM9NjeAhu*(aaEGJYkv6tcRMso1hK0+tOrSvd8QKNB(u"࠷ॠ"))
			IuEB1MXT8C0beqJmzQ = FmrC0jlog7cJu1ESetvdUsKW8-cc51OCnJKMS3Dzjv
			flLzKUbZqpmX(KeUEGFHb0LfrZhCaqd3O4NuDTQ,int(TCF8wLyDvgumfiXPSKRh(u"࠲࠲࠳ॢ")*GzabfJx3T1//(aaEGJYkv6tcRMso1hK0+OTRKI6LbrQnZEm(u"࠱ॡ"))),K7bLVaiRkx0lgU5SQM(u"ࠨษ็ื฼ืࠠโ๊ๅࠤ์๎ࠠๆๅส๊ࠥะฮำ์้ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩप"),WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩฯ่อࠦๅๅใࠣห้็๊ะ์๋࠾࠲ࠦวๅฮีลࠥืโๆࠩफ"),str(GzabfJx3T1*zzm8wqcdorbxEQgaUj//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ)+pTwKPmzMSZhil5d2RWonre(u"ࠪ࠳ࠬब")+str(g1gQfCpZG3ViFtl)+g4UCaNkHvLwGhjmW(u"ࠫࠥࡓࡂࠡࠢࠣࠤํ่สࠡ็อฬ็๐࠺ࠡࠩभ")+B3TKLo71hAGRqYgV0.strftime(fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢम"),B3TKLo71hAGRqYgV0.gmtime(IuEB1MXT8C0beqJmzQ))+VvhRUZgko5Af1BIynMGOJSbpmK(u"࠭ࠠแࠩय"))
			if KeUEGFHb0LfrZhCaqd3O4NuDTQ.iscanceled():
				UUNhZY7wC6QgxPvfEqy9 = YoAMfqm37GyFxbuKTt6e8CESHrhB
				break
	else:
		GzabfJx3T1 = v54ZuLY6dQ(u"࠲ॣ")
		for S5g0Fr4JEmXWzO9VQtlyjUDABGbn in T4U1lV3YFrtSv.iter_content(chunk_size=zzm8wqcdorbxEQgaUj):
			Ggv4tSadse02uJL1DZrnNfq.write(S5g0Fr4JEmXWzO9VQtlyjUDABGbn)
			GzabfJx3T1 = GzabfJx3T1+O4ylJvVNwLztdiHqBWDU(u"࠴।")
			GSiF9DxgB2 = B3TKLo71hAGRqYgV0.time()
			cc51OCnJKMS3Dzjv = GSiF9DxgB2-T9Ax7pUEP6Ilg4cC
			b4GzImt8YRaBkxcsy3KqM9NjeAhu = cc51OCnJKMS3Dzjv/GzabfJx3T1
			FmrC0jlog7cJu1ESetvdUsKW8 = b4GzImt8YRaBkxcsy3KqM9NjeAhu*(aaEGJYkv6tcRMso1hK0+s0vAWcLSXEToH9Mik134q(u"࠵॥"))
			IuEB1MXT8C0beqJmzQ = FmrC0jlog7cJu1ESetvdUsKW8-cc51OCnJKMS3Dzjv
			flLzKUbZqpmX(KeUEGFHb0LfrZhCaqd3O4NuDTQ,int(fk8jc5uDLX16qrih3ZaPxsvO(u"࠷࠰࠱१")*GzabfJx3T1/(aaEGJYkv6tcRMso1hK0+y5yX4jh6kUEgWZQIc(u"࠶०"))),DDHwpETQrAm0xMNXGfyhqsUi(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨर"),K7bLVaiRkx0lgU5SQM(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨऱ"),str(GzabfJx3T1*zzm8wqcdorbxEQgaUj//KmQftHqs6RuGLIg2lO7ndPUehX3DAJ)+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩ࠲ࠫल")+str(g1gQfCpZG3ViFtl)+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨळ")+B3TKLo71hAGRqYgV0.strftime(O4ylJvVNwLztdiHqBWDU(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨऴ"),B3TKLo71hAGRqYgV0.gmtime(IuEB1MXT8C0beqJmzQ))+aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠬࠦเࠨव"))
			if KeUEGFHb0LfrZhCaqd3O4NuDTQ.iscanceled():
				UUNhZY7wC6QgxPvfEqy9 = YoAMfqm37GyFxbuKTt6e8CESHrhB
				break
		T4U1lV3YFrtSv.close()
	Ggv4tSadse02uJL1DZrnNfq.close()
	KeUEGFHb0LfrZhCaqd3O4NuDTQ.close()
	if not UUNhZY7wC6QgxPvfEqy9:
		SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+XWbHfI9B8swrOL(u"࠭ࠠࠡࠢࡘࡷࡪࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠱࡬ࡲࡹ࡫ࡲࡳࡷࡳࡸࡪࡪࠠࡵࡪࡨࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡳࡱࡦࡩࡸࡹࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪश")+Kj0TOU6BmSMlJHZYLd+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧष")+Znh3Rt7GPdW5s241oJDazjSvE+mpusoZBJ6V(u"ࠨࠢࡠࠫस"))
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,v54ZuLY6dQ(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧह"))
		return XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	SQdRhwozVfv(AwKhgdpmBj0,w0TjQvmnSVrpaJoeCl6I(PuT0IphGNsketAQ)+JJu4MPClbTFpUwHiN(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऺ")+Kj0TOU6BmSMlJHZYLd+bDt7Ya1VEio3(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऻ")+Znh3Rt7GPdW5s241oJDazjSvE+pTwKPmzMSZhil5d2RWonre(u"ࠬࠦ࡝ࠨ़"))
	lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"࠭สๆࠢอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦศ็ฮสัࠬऽ"))
	return XpREPf7d08GnIS6i4KNLMyZHmuQqxD
# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'LODYNET'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_LDN_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['الرئيسية','استفسارتكم و الطلبات']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==450: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==451: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==452: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==453: W9lfsoMawqOzpQcXD = Wy9QU4Ns8orXtliKZSjnJH3bVF(url)
	elif mode==454: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==459: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'LODYNET-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(vxQUXEuH9m,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,459,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'مثبتات لودي نت',unA4F0ajXBUwHksrx3IyNCJL,451,QigevCplXxbPI1H,QigevCplXxbPI1H,'featured')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'المضاف حديثا',unA4F0ajXBUwHksrx3IyNCJL,451,QigevCplXxbPI1H,QigevCplXxbPI1H,'latest')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"MainMenu"(.*?)"SiteSlider"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			if RMC6c2kL5hGOnFaIwAyb=='#': continue
			if title in ef1pQcbEtPjMnXYrvOi: continue
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,451)
	return
def ddbEXhWzOnIaR(url,ZDQqkvbtHmB4=QigevCplXxbPI1H):
	items = []
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'LODYNET-TITLES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	if ZDQqkvbtHmB4=='featured':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"SiteSlider"(.*?)"waves"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif ZDQqkvbtHmB4=='latest':
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"RecentPosts"(.*?)"pagination"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	elif '"ActorsList"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"ActorsList"(.*?)"text/javascript"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	elif ZDQqkvbtHmB4 in ['0','1','2']:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"Section"(.*?)</li></ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[int(ZDQqkvbtHmB4)]
	else:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"BlocksArea"(.*?)"text/javascript"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	if not items: items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	wibHRCAFtsupIjx4ZTELeM = []
	EcyPTkJuKBDvZRVe4 = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
		if '"ActorsList"' in aY63L2NhgvwJIxPAoDG4MKECmZXF1 and 'src=' in cXu4fN1moCypJqb72OZvd:
			cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('src="(.*?)"',cXu4fN1moCypJqb72OZvd,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0]
		RMC6c2kL5hGOnFaIwAyb = MVkP7zfWlxUXj(RMC6c2kL5hGOnFaIwAyb).strip('/')
		V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) حلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if not V1nZX7O5WwEq8HmvkY: V1nZX7O5WwEq8HmvkY = sBvufaD6c9YHdOqTjCQ3.findall('(.*?) الحلقة \d+',title,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if set(title.split()) & set(EcyPTkJuKBDvZRVe4) and 'مسلسل' not in title:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,452,cXu4fN1moCypJqb72OZvd)
		elif V1nZX7O5WwEq8HmvkY and 'حلقة' in title:
			title = '_MOD_' + V1nZX7O5WwEq8HmvkY[0]
			if title not in wibHRCAFtsupIjx4ZTELeM:
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,453,cXu4fN1moCypJqb72OZvd)
				wibHRCAFtsupIjx4ZTELeM.append(title)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,453,cXu4fN1moCypJqb72OZvd)
	if ZDQqkvbtHmB4 in [QigevCplXxbPI1H,'latest']:
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,451)
	return
def Wy9QU4Ns8orXtliKZSjnJH3bVF(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'LODYNET-SEASONS-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"CategorySubLinks"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Z5CDQW96jye and 'href=' in str(Z5CDQW96jye):
		title = sBvufaD6c9YHdOqTjCQ3.findall('<title>(.*?)-',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		title = title[0].strip(hT7zFDpEyUqf8sXuN)
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,url,454)
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,454)
	else: oB2rmVgqUND(url)
	return
def oB2rmVgqUND(url):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'LODYNET-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"BlocksArea"(.*?)"text/javascript"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if gQ5KvJ6G2lbWwYBOMiTr:
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?src="(.*?)".*?<h2>(.*?)</h2>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,cXu4fN1moCypJqb72OZvd,title in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,452,cXu4fN1moCypJqb72OZvd)
		fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"pagination"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		if fwSu6JsQZpEiv:
			LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
			items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			for RMC6c2kL5hGOnFaIwAyb,title in items:
				title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
				E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,454)
	return
def nibvTq2jfRXDM4tYP039S(url):
	Kj0TOU6BmSMlJHZYLd = url.replace('/movies/','/watch_movies/')
	Kj0TOU6BmSMlJHZYLd = Kj0TOU6BmSMlJHZYLd.replace('/episodes/','/watch_episodes/')
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',Kj0TOU6BmSMlJHZYLd,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'LODYNET-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(Kj0TOU6BmSMlJHZYLd,'url')
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"WatchTitle"(.*?)</aside>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-embed="(.*?)">(.*?)</li>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"DownloadLinks"(.*?)"selary"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?<span>(.*?)</span>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,name in items:
			name = i7gQvkPzZJm4jM3uYV2xfAqhs(name)
			oI6LvXMf4VEPe8jOdpKC0hUmS = sBvufaD6c9YHdOqTjCQ3.findall('\d\d\d+',name,sBvufaD6c9YHdOqTjCQ3.DOTALL)
			if oI6LvXMf4VEPe8jOdpKC0hUmS:
				oI6LvXMf4VEPe8jOdpKC0hUmS = '____'+oI6LvXMf4VEPe8jOdpKC0hUmS[0]
				name = QigevCplXxbPI1H
			else: oI6LvXMf4VEPe8jOdpKC0hUmS = QigevCplXxbPI1H
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+name+'__download'+oI6LvXMf4VEPe8jOdpKC0hUmS
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/search/'+search
	ddbEXhWzOnIaR(url)
	return
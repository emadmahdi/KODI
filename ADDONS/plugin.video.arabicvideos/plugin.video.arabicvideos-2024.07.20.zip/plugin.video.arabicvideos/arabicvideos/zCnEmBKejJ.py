# -*- coding: utf-8 -*-
from TEsNM9QVZc import *
PuT0IphGNsketAQ = 'EGYDEAD'
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = '_EGD_'
vxQUXEuH9m = OQv0iWIw5bFRATU2mxJjZK[PuT0IphGNsketAQ][0]
ef1pQcbEtPjMnXYrvOi = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def YnMSWTbKj1N8wuRJVF(mode,url,text):
	if   mode==440: W9lfsoMawqOzpQcXD = vZR0cSd4X7seq()
	elif mode==441: W9lfsoMawqOzpQcXD = ddbEXhWzOnIaR(url,text)
	elif mode==442: W9lfsoMawqOzpQcXD = nibvTq2jfRXDM4tYP039S(url)
	elif mode==443: W9lfsoMawqOzpQcXD = oB2rmVgqUND(url)
	elif mode==449: W9lfsoMawqOzpQcXD = UJL7oB1rySs6ERpjGnhvz(text)
	else: W9lfsoMawqOzpQcXD = False
	return W9lfsoMawqOzpQcXD
def vZR0cSd4X7seq():
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',vxQUXEuH9m,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYDEAD-MENU-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	unA4F0ajXBUwHksrx3IyNCJL = gmEAzp8ul4xGJiVB6N5M7RWdFOnbce(vxQUXEuH9m,'url')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'بحث في الموقع',QigevCplXxbPI1H,449,QigevCplXxbPI1H,QigevCplXxbPI1H,'_REMEMBERRESULTS_')
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'الرئيسية',vxQUXEuH9m,441)
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',QigevCplXxbPI1H,9999)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="title_menu_right"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)</a>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title in items:
		if title in ef1pQcbEtPjMnXYrvOi: continue
		if RMC6c2kL5hGOnFaIwAyb=='#': continue
		E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',PuT0IphGNsketAQ+'_SCRIPT_'+iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,441)
	return
def ddbEXhWzOnIaR(url,BLIwYgHkv25j1d6DsEUl3rae7M=QigevCplXxbPI1H):
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'GET',url,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYDEAD-TITLES-2nd')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="list-related"(.*?)class="pagination"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
	items = sBvufaD6c9YHdOqTjCQ3.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
		if '/url/' in RMC6c2kL5hGOnFaIwAyb: continue
		elif '/season/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,443,cXu4fN1moCypJqb72OZvd)
		elif '/episode/' in RMC6c2kL5hGOnFaIwAyb: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,443,cXu4fN1moCypJqb72OZvd)
		else: E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,442,cXu4fN1moCypJqb72OZvd)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('class="pagination"(.*?)</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)">(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = i7gQvkPzZJm4jM3uYV2xfAqhs(title)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+'صفحة '+title,RMC6c2kL5hGOnFaIwAyb,441)
	return
def oB2rmVgqUND(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYDEAD-EPISODES-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	Z5CDQW96jye = sBvufaD6c9YHdOqTjCQ3.findall('"seasons-list"(.*?)</div>.</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	gQ5KvJ6G2lbWwYBOMiTr = sBvufaD6c9YHdOqTjCQ3.findall('"episodes-list"(.*?)</div>.</div>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if Z5CDQW96jye:
		LKzFWsmvjUVGMDBapflx6H4NY = Z5CDQW96jye[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title,cXu4fN1moCypJqb72OZvd in items:
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('folder',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,443,cXu4fN1moCypJqb72OZvd)
	elif gQ5KvJ6G2lbWwYBOMiTr:
		cXu4fN1moCypJqb72OZvd = sBvufaD6c9YHdOqTjCQ3.findall('"og:image" content="(.*?)"',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		cXu4fN1moCypJqb72OZvd = cXu4fN1moCypJqb72OZvd[0]
		LKzFWsmvjUVGMDBapflx6H4NY = gQ5KvJ6G2lbWwYBOMiTr[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('href="(.*?)".*?>(.*?)<',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			E6WSo7GYiNkQ8TU5dH9aqFtClARLj('video',iiWOIMsq4w3zkHdyo0CEDm2vGhnB+title,RMC6c2kL5hGOnFaIwAyb,442,cXu4fN1moCypJqb72OZvd)
	return
def nibvTq2jfRXDM4tYP039S(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	JJrhP4C6osGDFEKVSRBvX = hPo36xNERyQtmrMABnDc4zKY0elUa(pETKl7xuH1f5yjdFAb6C8JzOLV,'POST',url,data,headers,QigevCplXxbPI1H,QigevCplXxbPI1H,'EGYDEAD-PLAY-1st')
	aY63L2NhgvwJIxPAoDG4MKECmZXF1 = JJrhP4C6osGDFEKVSRBvX.content
	ldFqnNIsftrY43JBM6LPjzU8m = []
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"watchAreaMaster"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('data-link="(.*?)".*?<p>(.*?)</p>',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for RMC6c2kL5hGOnFaIwAyb,title in items:
			title = title.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H).strip(hT7zFDpEyUqf8sXuN)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__watch'
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	fwSu6JsQZpEiv = sBvufaD6c9YHdOqTjCQ3.findall('"donwload-servers-list"(.*?)</ul>',aY63L2NhgvwJIxPAoDG4MKECmZXF1,sBvufaD6c9YHdOqTjCQ3.DOTALL)
	if fwSu6JsQZpEiv:
		LKzFWsmvjUVGMDBapflx6H4NY = fwSu6JsQZpEiv[0]
		items = sBvufaD6c9YHdOqTjCQ3.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',LKzFWsmvjUVGMDBapflx6H4NY,sBvufaD6c9YHdOqTjCQ3.DOTALL)
		for title,oI6LvXMf4VEPe8jOdpKC0hUmS,RMC6c2kL5hGOnFaIwAyb in items:
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb.replace(aSBkt4OU8JpWTEzVIHjAiv,QigevCplXxbPI1H)
			RMC6c2kL5hGOnFaIwAyb = RMC6c2kL5hGOnFaIwAyb+'?named='+title+'__download'+'____'+oI6LvXMf4VEPe8jOdpKC0hUmS
			ldFqnNIsftrY43JBM6LPjzU8m.append(RMC6c2kL5hGOnFaIwAyb)
	import u8j7hmKf9V
	u8j7hmKf9V.v7h95wpulLk8HGNgezKM(ldFqnNIsftrY43JBM6LPjzU8m,PuT0IphGNsketAQ,'video',url)
	return
def UJL7oB1rySs6ERpjGnhvz(search):
	search,iBux5zA0swygKtRlDCTH,showDialogs = RPLdkDS2mf6rvjb8e5yQ1hCu4(search)
	if search==QigevCplXxbPI1H: search = XAfEvmh95VkgurjdiJ()
	if search==QigevCplXxbPI1H: return
	search = search.replace(hT7zFDpEyUqf8sXuN,'+')
	url = vxQUXEuH9m+'/?s='+search
	ddbEXhWzOnIaR(url)
	return
# -*- coding: utf-8 -*-
import sys as KXhrv29CGR8QTDzJIWLY
L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I = KXhrv29CGR8QTDzJIWLY.version_info [0] == 2
lnU3cPzOswGVSdBK0AxtfN4iq = 2048
qNXFAk7yDYpr = 7
def vJs2m5yIhWwUYLi7kaMe1DTHdlZC (oJA2FQaygXpHRBMDEYmNkSe3bh):
	global HIQ9VLeKhulnSwc81Po
	oo0Epejgath3 = ord (oJA2FQaygXpHRBMDEYmNkSe3bh [-1])
	pKu36eyYCbE9ZI = oJA2FQaygXpHRBMDEYmNkSe3bh [:-1]
	KzeLafSwRIP4xkD52pXs = oo0Epejgath3 % len (pKu36eyYCbE9ZI)
	u3u8HNKolm7vsfx = pKu36eyYCbE9ZI [:KzeLafSwRIP4xkD52pXs] + pKu36eyYCbE9ZI [KzeLafSwRIP4xkD52pXs:]
	if L3dUDq0Nhu1sXR6elFQtCxB8gEHn5I:
		QYaSwNncjGikdBZH8 = unicode () .join ([unichr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	else:
		QYaSwNncjGikdBZH8 = str () .join ([chr (ord (cb2RmBudLIQM4Dz) - lnU3cPzOswGVSdBK0AxtfN4iq - (HsZ74GJdtlwRM + oo0Epejgath3) % qNXFAk7yDYpr) for HsZ74GJdtlwRM, cb2RmBudLIQM4Dz in enumerate (u3u8HNKolm7vsfx)])
	return eval (QYaSwNncjGikdBZH8)
pTwKPmzMSZhil5d2RWonre,XWbHfI9B8swrOL,DD7NjwespWyQJ4E6mXk0ZAufPg=vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC,vJs2m5yIhWwUYLi7kaMe1DTHdlZC
mmKqLr9RX0ACN384JMcsFHzd,bDt7Ya1VEio3,Fg72JX6T5DkPy=DD7NjwespWyQJ4E6mXk0ZAufPg,XWbHfI9B8swrOL,pTwKPmzMSZhil5d2RWonre
vZL6j4tSClIGxzNE5DX,NUZQ4Wgo6OIuRY0avMPepqVcyK,s0vAWcLSXEToH9Mik134q=Fg72JX6T5DkPy,bDt7Ya1VEio3,mmKqLr9RX0ACN384JMcsFHzd
hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq,aqUlAdFto05NmG4Y6guEzTr8vK,TCF8wLyDvgumfiXPSKRh=s0vAWcLSXEToH9Mik134q,NUZQ4Wgo6OIuRY0avMPepqVcyK,vZL6j4tSClIGxzNE5DX
mpusoZBJ6V,g4UCaNkHvLwGhjmW,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw=TCF8wLyDvgumfiXPSKRh,aqUlAdFto05NmG4Y6guEzTr8vK,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq
pGncXOodjKhJzLSqVP1r,fk8jc5uDLX16qrih3ZaPxsvO,VvhRUZgko5Af1BIynMGOJSbpmK=Z1m7a8V3dCxpgfNXt0j2o5OW9LEw,g4UCaNkHvLwGhjmW,mpusoZBJ6V
K7bLVaiRkx0lgU5SQM,tOrSvd8QKNB,y5yX4jh6kUEgWZQIc=VvhRUZgko5Af1BIynMGOJSbpmK,fk8jc5uDLX16qrih3ZaPxsvO,pGncXOodjKhJzLSqVP1r
svULcgJ7jm,Xr2aHOK0huQ5DTS,WXHTj9QUEKMOV0BAd2ch6IGtxNe3=y5yX4jh6kUEgWZQIc,tOrSvd8QKNB,K7bLVaiRkx0lgU5SQM
DDHwpETQrAm0xMNXGfyhqsUi,FF70emVxhWOngCty,O4ylJvVNwLztdiHqBWDU=WXHTj9QUEKMOV0BAd2ch6IGtxNe3,Xr2aHOK0huQ5DTS,svULcgJ7jm
QBji1dC9OsRWlJP6HDyG4Zv7wqfUT,JJu4MPClbTFpUwHiN,OOhnpQ8XvCVclGqdu=O4ylJvVNwLztdiHqBWDU,FF70emVxhWOngCty,DDHwpETQrAm0xMNXGfyhqsUi
tg9l25NH6WTacVSifLyAmY,v54ZuLY6dQ,OTRKI6LbrQnZEm=OOhnpQ8XvCVclGqdu,JJu4MPClbTFpUwHiN,QBji1dC9OsRWlJP6HDyG4Zv7wqfUT
from TEsNM9QVZc import *
PuT0IphGNsketAQ = FF70emVxhWOngCty(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
iiWOIMsq4w3zkHdyo0CEDm2vGhnB = mpusoZBJ6V(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
nX14pwyR68fLE7A2x0QkOICmFvJrP = KiTt9ZskMLjnCAUIJNXD7.path.join(UhsM4xeGEpyW9tr31oCRf,mmKqLr9RX0ACN384JMcsFHzd(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
EJLWmCZeTr8f50zVhnv = KiTt9ZskMLjnCAUIJNXD7.path.join(UhsM4xeGEpyW9tr31oCRf,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
uVq5Lci1IkQySO = KiTt9ZskMLjnCAUIJNXD7.path.join(ydKHnhCfRwT0JgF9iD7WQSYlusGk5,DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
ww8unPaNBFYseWDJ7HM2Gmbd5j0 = XE4VUzrimwqb3RJTnjovLA
GWduPDF2lH8zgh9j1bmZ0Cy7 = NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
jtiGVNUm3crZxwQXBRqS9pv4Dauz = O4ylJvVNwLztdiHqBWDU(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
kFevATZtNHCSmlsKRPYUb = mpusoZBJ6V(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
Bc7WnsXLU6wFmSoHCiyE51tjdl = mpusoZBJ6V(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
V9QhauFrinleKIgw7G4b0AB = TCF8wLyDvgumfiXPSKRh(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
HI7JNsSyiUQfaZPYlL02o = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def YnMSWTbKj1N8wuRJVF(TsckNQJ6yLiaEeCRml98WwKfVP0dYv):
	if   TsckNQJ6yLiaEeCRml98WwKfVP0dYv==mmKqLr9RX0ACN384JMcsFHzd(u"࠻࠹࠶ࡾ"): W9lfsoMawqOzpQcXD = XIQDmTr5NjupkvEn8()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==v54ZuLY6dQ(u"࠼࠺࠱ࡿ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(nX14pwyR68fLE7A2x0QkOICmFvJrP,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Xr2aHOK0huQ5DTS(u"࠽࠴࠳ࢀ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(EJLWmCZeTr8f50zVhnv,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠷࠵࠵ࢁ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(uVq5Lci1IkQySO,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==pTwKPmzMSZhil5d2RWonre(u"࠸࠶࠷ࢂ"): W9lfsoMawqOzpQcXD = jydu96WtOKPw(ww8unPaNBFYseWDJ7HM2Gmbd5j0,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==pTwKPmzMSZhil5d2RWonre(u"࠹࠷࠹ࢃ"): W9lfsoMawqOzpQcXD = Bbg6Zj30wqiPOKTv9x1H4QopRmS(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==TCF8wLyDvgumfiXPSKRh(u"࠺࠹࠵ࢄ"): W9lfsoMawqOzpQcXD = BKPVA2ILRkTU7q30Y()
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠻࠺࠷ࢅ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(GWduPDF2lH8zgh9j1bmZ0Cy7,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==mmKqLr9RX0ACN384JMcsFHzd(u"࠼࠻࠲ࢆ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(jtiGVNUm3crZxwQXBRqS9pv4Dauz,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==svULcgJ7jm(u"࠽࠵࠴ࢇ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(kFevATZtNHCSmlsKRPYUb,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==mmKqLr9RX0ACN384JMcsFHzd(u"࠷࠶࠶࢈"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(Bc7WnsXLU6wFmSoHCiyE51tjdl,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==DD7NjwespWyQJ4E6mXk0ZAufPg(u"࠸࠷࠸ࢉ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(V9QhauFrinleKIgw7G4b0AB,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==tOrSvd8QKNB(u"࠹࠸࠺ࢊ"): W9lfsoMawqOzpQcXD = eB8jr3L1inmU6OzINJd(HI7JNsSyiUQfaZPYlL02o,YoAMfqm37GyFxbuKTt6e8CESHrhB,XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==mpusoZBJ6V(u"࠺࠹࠼ࢋ"): W9lfsoMawqOzpQcXD = baUIQTlrC1OPe(XpREPf7d08GnIS6i4KNLMyZHmuQqxD)
	elif TsckNQJ6yLiaEeCRml98WwKfVP0dYv==VvhRUZgko5Af1BIynMGOJSbpmK(u"࠻࠺࠾ࢌ"): W9lfsoMawqOzpQcXD = QQ4DgInamlcLreY12zk5wHtCfdTo8()
	else: W9lfsoMawqOzpQcXD = YoAMfqm37GyFxbuKTt6e8CESHrhB
	return W9lfsoMawqOzpQcXD
def XIQDmTr5NjupkvEn8():
	WSZd6VsD2AYeh0j3BQM5Kf,V5Uy2sj6BD4zWketiCqpZuI = PjXRh9YSNsnvIJxM2yHWOwad(nX14pwyR68fLE7A2x0QkOICmFvJrP)
	HXCpQ721ZwstSKrPcqo,zyndDKf6GoREN = PjXRh9YSNsnvIJxM2yHWOwad(EJLWmCZeTr8f50zVhnv)
	mdknf6y0eAtw5sBazENiqWo,a5CdPjZAV7lOIJbKm06e = PjXRh9YSNsnvIJxM2yHWOwad(uVq5Lci1IkQySO)
	cc6aFSvpVOBd9qCmzMjwPKrlU8,GEaCYKHevsLlc7idt5x4XFp = dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(ww8unPaNBFYseWDJ7HM2Gmbd5j0)
	cc6aFSvpVOBd9qCmzMjwPKrlU8 -= pGncXOodjKhJzLSqVP1r(u"࠸࠼࠸࠷࠶ࢍ")
	GEaCYKHevsLlc7idt5x4XFp -= y5yX4jh6kUEgWZQIc(u"࠷ࢎ")
	p8pA2fGcZjvX = tOrSvd8QKNB(u"ࠩࠣࠬࠬࠌ")+bwTHW2GP3Sjok684EDd1y(WSZd6VsD2AYeh0j3BQM5Kf)+v54ZuLY6dQ(u"ࠪࠤ࠲ࠦࠧࠍ")+str(V5Uy2sj6BD4zWketiCqpZuI)+Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	rtZM5KYaGepo7F2 = tg9l25NH6WTacVSifLyAmY(u"ࠬࠦࠨࠨࠏ")+bwTHW2GP3Sjok684EDd1y(HXCpQ721ZwstSKrPcqo)+OOhnpQ8XvCVclGqdu(u"࠭ࠠ࠮ࠢࠪࠐ")+str(zyndDKf6GoREN)+y5yX4jh6kUEgWZQIc(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	p0gLWY5oTqa = fk8jc5uDLX16qrih3ZaPxsvO(u"ࠨࠢࠫࠫࠒ")+bwTHW2GP3Sjok684EDd1y(mdknf6y0eAtw5sBazENiqWo)+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(a5CdPjZAV7lOIJbKm06e)+Fg72JX6T5DkPy(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	NUakojpPKfYR28rzDdBwVOIX63u0cT = hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠫࠥ࠮ࠧࠕ")+bwTHW2GP3Sjok684EDd1y(cc6aFSvpVOBd9qCmzMjwPKrlU8)+DD7NjwespWyQJ4E6mXk0ZAufPg(u"ࠬ࠯ࠧࠖ")
	yyQfNqao6bnwHmUxgiztPk08M = WSZd6VsD2AYeh0j3BQM5Kf+HXCpQ721ZwstSKrPcqo+mdknf6y0eAtw5sBazENiqWo+cc6aFSvpVOBd9qCmzMjwPKrlU8
	bbVNsXZRi7yBGEJotc5K3Ax = V5Uy2sj6BD4zWketiCqpZuI+zyndDKf6GoREN+a5CdPjZAV7lOIJbKm06e+GEaCYKHevsLlc7idt5x4XFp
	d8kolNVuLsPAjQZ9ROpUHBgix = aqUlAdFto05NmG4Y6guEzTr8vK(u"࠭ࠠࠩࠩࠗ")+bwTHW2GP3Sjok684EDd1y(yyQfNqao6bnwHmUxgiztPk08M)+VvhRUZgko5Af1BIynMGOJSbpmK(u"ࠧࠡ࠯ࠣࠫ࠘")+str(bbVNsXZRi7yBGEJotc5K3Ax)+K7bLVaiRkx0lgU5SQM(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(XWbHfI9B8swrOL(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+O4ylJvVNwLztdiHqBWDU(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,mmKqLr9RX0ACN384JMcsFHzd(u"࠷࠵࠷࢏"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(mpusoZBJ6V(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+tg9l25NH6WTacVSifLyAmY(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+jhAlCQ47ZgG,QigevCplXxbPI1H,bDt7Ya1VEio3(u"࠺࠻࠼࠽࢐"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(tg9l25NH6WTacVSifLyAmY(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+p8pA2fGcZjvX,QigevCplXxbPI1H,v54ZuLY6dQ(u"࠹࠷࠵࢑"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+O4ylJvVNwLztdiHqBWDU(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+rtZM5KYaGepo7F2,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"࠺࠸࠷࢒"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(aqUlAdFto05NmG4Y6guEzTr8vK(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+DDHwpETQrAm0xMNXGfyhqsUi(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+p0gLWY5oTqa,QigevCplXxbPI1H,tOrSvd8QKNB(u"࠻࠹࠹࢓"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(O4ylJvVNwLztdiHqBWDU(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+NUakojpPKfYR28rzDdBwVOIX63u0cT,QigevCplXxbPI1H,v54ZuLY6dQ(u"࠼࠺࠴࢔"))
	uUTRHgAXJzm7pIDBjNt8.setSetting(pTwKPmzMSZhil5d2RWonre(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),QigevCplXxbPI1H)
	return
def BKPVA2ILRkTU7q30Y():
	JSWfOpdkV0mBnYqix1rPLKwEzuct = XpREPf7d08GnIS6i4KNLMyZHmuQqxD if JJu4MPClbTFpUwHiN(u"ࠨ࠱ࠪࠧ") in ydKHnhCfRwT0JgF9iD7WQSYlusGk5 else YoAMfqm37GyFxbuKTt6e8CESHrhB
	if not JSWfOpdkV0mBnYqix1rPLKwEzuct:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),g4UCaNkHvLwGhjmW(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	aeRHmPISMkDNA2vd7F6gzpB9C = uUTRHgAXJzm7pIDBjNt8.getSetting(pTwKPmzMSZhil5d2RWonre(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not aeRHmPISMkDNA2vd7F6gzpB9C: QQ4DgInamlcLreY12zk5wHtCfdTo8()
	WSZd6VsD2AYeh0j3BQM5Kf,V5Uy2sj6BD4zWketiCqpZuI = PjXRh9YSNsnvIJxM2yHWOwad(GWduPDF2lH8zgh9j1bmZ0Cy7)
	HXCpQ721ZwstSKrPcqo,zyndDKf6GoREN = PjXRh9YSNsnvIJxM2yHWOwad(jtiGVNUm3crZxwQXBRqS9pv4Dauz)
	mdknf6y0eAtw5sBazENiqWo,a5CdPjZAV7lOIJbKm06e = PjXRh9YSNsnvIJxM2yHWOwad(kFevATZtNHCSmlsKRPYUb)
	cc6aFSvpVOBd9qCmzMjwPKrlU8,GEaCYKHevsLlc7idt5x4XFp = PjXRh9YSNsnvIJxM2yHWOwad(Bc7WnsXLU6wFmSoHCiyE51tjdl)
	xIMWk2XQ7cZFLEJwhsCDv4Gbz3qrTj,HEcf3gtuJ4rnspT2KUCAzZ9MqDL = PjXRh9YSNsnvIJxM2yHWOwad(V9QhauFrinleKIgw7G4b0AB)
	fJtMQLb9WFemq,iOlwKbjDgc7 = PjXRh9YSNsnvIJxM2yHWOwad(HI7JNsSyiUQfaZPYlL02o)
	p8pA2fGcZjvX = pGncXOodjKhJzLSqVP1r(u"ࠬࠦࠨࠨࠫ")+bwTHW2GP3Sjok684EDd1y(WSZd6VsD2AYeh0j3BQM5Kf)+O4ylJvVNwLztdiHqBWDU(u"࠭ࠠ࠮ࠢࠪࠬ")+str(V5Uy2sj6BD4zWketiCqpZuI)+Fg72JX6T5DkPy(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	rtZM5KYaGepo7F2 = OOhnpQ8XvCVclGqdu(u"ࠨࠢࠫࠫ࠮")+bwTHW2GP3Sjok684EDd1y(HXCpQ721ZwstSKrPcqo)+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠩࠣ࠱ࠥ࠭࠯")+str(zyndDKf6GoREN)+FF70emVxhWOngCty(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	p0gLWY5oTqa = tOrSvd8QKNB(u"ࠫࠥ࠮ࠧ࠱")+bwTHW2GP3Sjok684EDd1y(mdknf6y0eAtw5sBazENiqWo)+mpusoZBJ6V(u"ࠬࠦ࠭ࠡࠩ࠲")+str(a5CdPjZAV7lOIJbKm06e)+OOhnpQ8XvCVclGqdu(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	NUakojpPKfYR28rzDdBwVOIX63u0cT = tg9l25NH6WTacVSifLyAmY(u"ࠧࠡࠪࠪ࠴")+bwTHW2GP3Sjok684EDd1y(cc6aFSvpVOBd9qCmzMjwPKrlU8)+bDt7Ya1VEio3(u"ࠨࠢ࠰ࠤࠬ࠵")+str(GEaCYKHevsLlc7idt5x4XFp)+g4UCaNkHvLwGhjmW(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	mVaQhk2c0Z8jx = DDHwpETQrAm0xMNXGfyhqsUi(u"ࠪࠤ࠭࠭࠷")+bwTHW2GP3Sjok684EDd1y(xIMWk2XQ7cZFLEJwhsCDv4Gbz3qrTj)+pTwKPmzMSZhil5d2RWonre(u"ࠫࠥ࠳ࠠࠨ࠸")+str(HEcf3gtuJ4rnspT2KUCAzZ9MqDL)+y5yX4jh6kUEgWZQIc(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	dDSMcqveBGfZ2hT8ou5bUIRiPO = K7bLVaiRkx0lgU5SQM(u"࠭ࠠࠩࠩ࠺")+bwTHW2GP3Sjok684EDd1y(fJtMQLb9WFemq)+QBji1dC9OsRWlJP6HDyG4Zv7wqfUT(u"ࠧࠡ࠯ࠣࠫ࠻")+str(iOlwKbjDgc7)+bDt7Ya1VEio3(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	yyQfNqao6bnwHmUxgiztPk08M = WSZd6VsD2AYeh0j3BQM5Kf+HXCpQ721ZwstSKrPcqo+mdknf6y0eAtw5sBazENiqWo+cc6aFSvpVOBd9qCmzMjwPKrlU8+xIMWk2XQ7cZFLEJwhsCDv4Gbz3qrTj+fJtMQLb9WFemq
	bbVNsXZRi7yBGEJotc5K3Ax = V5Uy2sj6BD4zWketiCqpZuI+zyndDKf6GoREN+a5CdPjZAV7lOIJbKm06e+GEaCYKHevsLlc7idt5x4XFp+HEcf3gtuJ4rnspT2KUCAzZ9MqDL+iOlwKbjDgc7
	d8kolNVuLsPAjQZ9ROpUHBgix = pTwKPmzMSZhil5d2RWonre(u"ࠩࠣࠬࠬ࠽")+bwTHW2GP3Sjok684EDd1y(yyQfNqao6bnwHmUxgiztPk08M)+OOhnpQ8XvCVclGqdu(u"ࠪࠤ࠲ࠦࠧ࠾")+str(bbVNsXZRi7yBGEJotc5K3Ax)+FF70emVxhWOngCty(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(bDt7Ya1VEio3(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+bDt7Ya1VEio3(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),QigevCplXxbPI1H,Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"࠽࠵࠹࢕"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(tg9l25NH6WTacVSifLyAmY(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+OOhnpQ8XvCVclGqdu(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+d8kolNVuLsPAjQZ9ROpUHBgix,QigevCplXxbPI1H,aqUlAdFto05NmG4Y6guEzTr8vK(u"࠷࠶࠹࢖"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(JJu4MPClbTFpUwHiN(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+vZL6j4tSClIGxzNE5DX(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+jhAlCQ47ZgG,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"࠺࠻࠼࠽ࢗ"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(vZL6j4tSClIGxzNE5DX(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+VvhRUZgko5Af1BIynMGOJSbpmK(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+p8pA2fGcZjvX,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"࠹࠸࠵࢘"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(v54ZuLY6dQ(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+JJu4MPClbTFpUwHiN(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+rtZM5KYaGepo7F2,QigevCplXxbPI1H,svULcgJ7jm(u"࠺࠹࠷࢙"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(mmKqLr9RX0ACN384JMcsFHzd(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+O4ylJvVNwLztdiHqBWDU(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+p0gLWY5oTqa,QigevCplXxbPI1H,fk8jc5uDLX16qrih3ZaPxsvO(u"࠻࠺࠹࢚"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+mmKqLr9RX0ACN384JMcsFHzd(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+NUakojpPKfYR28rzDdBwVOIX63u0cT,QigevCplXxbPI1H,pGncXOodjKhJzLSqVP1r(u"࠼࠻࠴࢛"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(O4ylJvVNwLztdiHqBWDU(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+TCF8wLyDvgumfiXPSKRh(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+mVaQhk2c0Z8jx,QigevCplXxbPI1H,svULcgJ7jm(u"࠽࠵࠶࢜"))
	E6WSo7GYiNkQ8TU5dH9aqFtClARLj(K7bLVaiRkx0lgU5SQM(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),iiWOIMsq4w3zkHdyo0CEDm2vGhnB+WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+dDSMcqveBGfZ2hT8ou5bUIRiPO,QigevCplXxbPI1H,O4ylJvVNwLztdiHqBWDU(u"࠷࠶࠸࢝"))
	uUTRHgAXJzm7pIDBjNt8.setSetting(FF70emVxhWOngCty(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),QigevCplXxbPI1H)
	return
def QQ4DgInamlcLreY12zk5wHtCfdTo8():
	nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,TCF8wLyDvgumfiXPSKRh(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),g4UCaNkHvLwGhjmW(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if nndcv6tehuoKPpI==-y5yX4jh6kUEgWZQIc(u"࠲࢞"): return
	if nndcv6tehuoKPpI:
		import subprocess as oPTIyjikBa
		try:
			oPTIyjikBa.Popen(XWbHfI9B8swrOL(u"ࠬࡹࡵࠨࡕ"))
			jvxz4RXuaMY2f = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
		except: jvxz4RXuaMY2f = YoAMfqm37GyFxbuKTt6e8CESHrhB
		if jvxz4RXuaMY2f:
			pAY3FLlgG5j9uh2JHsox4ENKTafvZk = GWduPDF2lH8zgh9j1bmZ0Cy7+hT7zFDpEyUqf8sXuN+jtiGVNUm3crZxwQXBRqS9pv4Dauz+hT7zFDpEyUqf8sXuN+kFevATZtNHCSmlsKRPYUb+hT7zFDpEyUqf8sXuN+Bc7WnsXLU6wFmSoHCiyE51tjdl+hT7zFDpEyUqf8sXuN+V9QhauFrinleKIgw7G4b0AB+hT7zFDpEyUqf8sXuN+HI7JNsSyiUQfaZPYlL02o
			O0MTHAiV7QdZgGPFfU3IravkxWqeh = oPTIyjikBa.Popen(tOrSvd8QKNB(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+pAY3FLlgG5j9uh2JHsox4ENKTafvZk+svULcgJ7jm(u"ࠧࠣࠩࡗ"),shell=XpREPf7d08GnIS6i4KNLMyZHmuQqxD,stdin=oPTIyjikBa.PIPE,stdout=oPTIyjikBa.PIPE,stderr=oPTIyjikBa.PIPE)
			lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,OTRKI6LbrQnZEm(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),XWbHfI9B8swrOL(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			ksV5ngvbcaS8ByMLYxlfXh(mmKqLr9RX0ACN384JMcsFHzd(u"ࡊࡦࡲࡳࡦࢨ"))
		else: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,svULcgJ7jm(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),O4ylJvVNwLztdiHqBWDU(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def bwTHW2GP3Sjok684EDd1y(yyQfNqao6bnwHmUxgiztPk08M):
	for X0XNcZhM4KyO3uUxozmjFtIAPa in [K7bLVaiRkx0lgU5SQM(u"ࠬࡈࠧ࡜"),Xr2aHOK0huQ5DTS(u"࠭ࡋࡃࠩ࡝"),K7bLVaiRkx0lgU5SQM(u"ࠧࡎࡄࠪ࡞"),hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠨࡉࡅࠫ࡟"),tOrSvd8QKNB(u"ࠩࡗࡆࠬࡠ")]:
		if yyQfNqao6bnwHmUxgiztPk08M<hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠳࠳࠶࠹࢟"): break
		else: yyQfNqao6bnwHmUxgiztPk08M /= OTRKI6LbrQnZEm(u"࠴࠴࠷࠺࠮࠱ࢠ")
	d8kolNVuLsPAjQZ9ROpUHBgix = Z1m7a8V3dCxpgfNXt0j2o5OW9LEw(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(yyQfNqao6bnwHmUxgiztPk08M,X0XNcZhM4KyO3uUxozmjFtIAPa)
	return d8kolNVuLsPAjQZ9ROpUHBgix
def PjXRh9YSNsnvIJxM2yHWOwad(igqlovSGTY=DDHwpETQrAm0xMNXGfyhqsUi(u"ࠫ࠳࠭ࡢ")):
	global HQRsjGlr28gbXBiTfWdOUk,Z5d8jihHUEeDNg1aPFuRtw
	HQRsjGlr28gbXBiTfWdOUk,Z5d8jihHUEeDNg1aPFuRtw = O4ylJvVNwLztdiHqBWDU(u"࠴ࢡ"),O4ylJvVNwLztdiHqBWDU(u"࠴ࢡ")
	def T14QPZBga0N(igqlovSGTY):
		global HQRsjGlr28gbXBiTfWdOUk,Z5d8jihHUEeDNg1aPFuRtw
		if KiTt9ZskMLjnCAUIJNXD7.path.exists(igqlovSGTY):
			if hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"࠵ࢢ") and JJu4MPClbTFpUwHiN(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(KiTt9ZskMLjnCAUIJNXD7):
				for rkm4zigUtbaEIdcPTy78jxwDsfp in KiTt9ZskMLjnCAUIJNXD7.scandir(igqlovSGTY):
					if rkm4zigUtbaEIdcPTy78jxwDsfp.is_dir(follow_symlinks=YoAMfqm37GyFxbuKTt6e8CESHrhB):
						T14QPZBga0N(rkm4zigUtbaEIdcPTy78jxwDsfp.path)
					elif rkm4zigUtbaEIdcPTy78jxwDsfp.is_file(follow_symlinks=YoAMfqm37GyFxbuKTt6e8CESHrhB):
						HQRsjGlr28gbXBiTfWdOUk += rkm4zigUtbaEIdcPTy78jxwDsfp.stat().st_size
						Z5d8jihHUEeDNg1aPFuRtw += DDHwpETQrAm0xMNXGfyhqsUi(u"࠷ࢣ")
			else:
				for rkm4zigUtbaEIdcPTy78jxwDsfp in KiTt9ZskMLjnCAUIJNXD7.listdir(igqlovSGTY):
					CjJc2Zwn8TRA = KiTt9ZskMLjnCAUIJNXD7.path.abspath(KiTt9ZskMLjnCAUIJNXD7.path.join(igqlovSGTY,rkm4zigUtbaEIdcPTy78jxwDsfp))
					if KiTt9ZskMLjnCAUIJNXD7.path.isdir(CjJc2Zwn8TRA):
						T14QPZBga0N(CjJc2Zwn8TRA)
					elif KiTt9ZskMLjnCAUIJNXD7.path.isfile(CjJc2Zwn8TRA):
						yyQfNqao6bnwHmUxgiztPk08M,bbVNsXZRi7yBGEJotc5K3Ax = dGbl5YypV1CiAgwFO2ftWTIDSZ4eh(CjJc2Zwn8TRA)
						HQRsjGlr28gbXBiTfWdOUk += yyQfNqao6bnwHmUxgiztPk08M
						Z5d8jihHUEeDNg1aPFuRtw += bbVNsXZRi7yBGEJotc5K3Ax
		return
	try: T14QPZBga0N(igqlovSGTY)
	except: pass
	return HQRsjGlr28gbXBiTfWdOUk,Z5d8jihHUEeDNg1aPFuRtw
def tNMC5KveRUDWfzYAaGymgHIdoJ1S6(hKEnauDcAeW26wl8gGX1vi3,showDialogs):
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),hKEnauDcAeW26wl8gGX1vi3+vZL6j4tSClIGxzNE5DX(u"ࠧ࡝ࡰ࡟ࡲࠬࡥ")+iVCLpNIM8BQs9PdSgKZvlFeo3a5+FF70emVxhWOngCty(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢยࠥࠬࡦ")+jhAlCQ47ZgG)
		if nndcv6tehuoKPpI!=v54ZuLY6dQ(u"࠱ࢤ"): return
	xQRmZrWJCg5D3Ab = YoAMfqm37GyFxbuKTt6e8CESHrhB
	if KiTt9ZskMLjnCAUIJNXD7.path.exists(hKEnauDcAeW26wl8gGX1vi3):
		try: KiTt9ZskMLjnCAUIJNXD7.remove(hKEnauDcAeW26wl8gGX1vi3)
		except Exception as GVHX7YkcEI0Dsi:
			if showDialogs: lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,JJu4MPClbTFpUwHiN(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡧ"),str(GVHX7YkcEI0Dsi))
			xQRmZrWJCg5D3Ab = XpREPf7d08GnIS6i4KNLMyZHmuQqxD
	if showDialogs and not xQRmZrWJCg5D3Ab:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,Fg72JX6T5DkPy(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),tg9l25NH6WTacVSifLyAmY(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		ksV5ngvbcaS8ByMLYxlfXh(Xr2aHOK0huQ5DTS(u"ࡋࡧ࡬ࡴࡧࢩ"))
	return
def Bbg6Zj30wqiPOKTv9x1H4QopRmS(showDialogs):
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,mpusoZBJ6V(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+OOhnpQ8XvCVclGqdu(u"࠭็ๅࠢอี๏ีࠠๆีะࠫ࡫")+aSBkt4OU8JpWTEzVIHjAiv+fk8jc5uDLX16qrih3ZaPxsvO(u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭࡬")+aSBkt4OU8JpWTEzVIHjAiv+pGncXOodjKhJzLSqVP1r(u"ࠨมࠤࠥࠬ࡭")+jhAlCQ47ZgG)
		if nndcv6tehuoKPpI!=y5yX4jh6kUEgWZQIc(u"࠲ࢥ"): return
	eB8jr3L1inmU6OzINJd(nX14pwyR68fLE7A2x0QkOICmFvJrP,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(EJLWmCZeTr8f50zVhnv,XpREPf7d08GnIS6i4KNLMyZHmuQqxD,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(uVq5Lci1IkQySO,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	jydu96WtOKPw(ww8unPaNBFYseWDJ7HM2Gmbd5j0,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	if showDialogs:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,NUZQ4Wgo6OIuRY0avMPepqVcyK(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),y5yX4jh6kUEgWZQIc(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		ksV5ngvbcaS8ByMLYxlfXh(FF70emVxhWOngCty(u"ࡌࡡ࡭ࡵࡨࢪ"))
	return
def baUIQTlrC1OPe(showDialogs):
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+pTwKPmzMSZhil5d2RWonre(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠩࡱ")+aSBkt4OU8JpWTEzVIHjAiv+Fg72JX6T5DkPy(u"࠭ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠣ࠲࠳ࠦࡤࡳࡱࡳࡦࡴࡾࠠ࠯࠰ࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠠ࠯࠰ࠣࡰࡴ࡭ࡧࡦࡴࠣ࠲࠳ࠦ࡬ࡰࡩࠣ࠲࠳ࠦࡡ࡯ࡴࠪࡲ")+aSBkt4OU8JpWTEzVIHjAiv+TCF8wLyDvgumfiXPSKRh(u"ࠧࡀࠣࠤࠫࡳ")+jhAlCQ47ZgG)
		if nndcv6tehuoKPpI!=JJu4MPClbTFpUwHiN(u"࠳ࢦ"): return
	eB8jr3L1inmU6OzINJd(GWduPDF2lH8zgh9j1bmZ0Cy7,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(jtiGVNUm3crZxwQXBRqS9pv4Dauz,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(kFevATZtNHCSmlsKRPYUb,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(Bc7WnsXLU6wFmSoHCiyE51tjdl,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(V9QhauFrinleKIgw7G4b0AB,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	eB8jr3L1inmU6OzINJd(HI7JNsSyiUQfaZPYlL02o,YoAMfqm37GyFxbuKTt6e8CESHrhB,YoAMfqm37GyFxbuKTt6e8CESHrhB)
	if showDialogs:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,g4UCaNkHvLwGhjmW(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡴ"),K7bLVaiRkx0lgU5SQM(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࡵ"))
		ksV5ngvbcaS8ByMLYxlfXh(DDHwpETQrAm0xMNXGfyhqsUi(u"ࡆࡢ࡮ࡶࡩࢫ"))
	return
def jydu96WtOKPw(aYXiUPQDVd7hjTsumgL,showDialogs):
	if showDialogs:
		nndcv6tehuoKPpI = UJV3rPyElz5xRav0FD(QigevCplXxbPI1H,QigevCplXxbPI1H,QigevCplXxbPI1H,hPTZFj3kY8ECBc4dIa2zHfsrlLvmRq(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),iVCLpNIM8BQs9PdSgKZvlFeo3a5+Xr2aHOK0huQ5DTS(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่ࠢัฯ๎๊ศฬ้้ࠣ็ࠠึ๊ิࠤฬ๊ฬๅัࠣรࠦࠧࠧࡷ")+jhAlCQ47ZgG)
		if nndcv6tehuoKPpI!=JJu4MPClbTFpUwHiN(u"࠴ࢧ"): return
	R2wuKSVBTLW4sAOQNob18UEdGf0hv = DZLbiWNFXwpM26.connect(aYXiUPQDVd7hjTsumgL)
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.text_factory = str
	B6xRu5lFyJ = R2wuKSVBTLW4sAOQNob18UEdGf0hv.cursor()
	B6xRu5lFyJ.execute(OTRKI6LbrQnZEm(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࡸ"))
	B6xRu5lFyJ.execute(OOhnpQ8XvCVclGqdu(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࡹ"))
	B6xRu5lFyJ.execute(pTwKPmzMSZhil5d2RWonre(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࡺ"))
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.commit()
	B6xRu5lFyJ.execute(svULcgJ7jm(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࡻ"))
	R2wuKSVBTLW4sAOQNob18UEdGf0hv.close()
	if showDialogs:
		lKfIRYspw15BD8vgtoAP(QigevCplXxbPI1H,QigevCplXxbPI1H,pTwKPmzMSZhil5d2RWonre(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),fk8jc5uDLX16qrih3ZaPxsvO(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫࡽ"))
		ksV5ngvbcaS8ByMLYxlfXh(WXHTj9QUEKMOV0BAd2ch6IGtxNe3(u"ࡇࡣ࡯ࡷࡪࢬ"))
	return
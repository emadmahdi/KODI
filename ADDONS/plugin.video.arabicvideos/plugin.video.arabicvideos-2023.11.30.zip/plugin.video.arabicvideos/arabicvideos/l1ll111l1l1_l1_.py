# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ⽲")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨ⽳")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⽴"):l1l111_l1_ (u"ࠫࠬ⽵")}
def l11l1ll_l1_(mode,url,text):
	if   mode==320: l1lll_l1_ = l1l1l11_l1_()
	elif mode==321: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==322: l1lll_l1_ = PLAY(url)
	elif mode==329: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⽶"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⽷"),l1l111_l1_ (u"ࠧࠨ⽸"),329,l1l111_l1_ (u"ࠨࠩ⽹"),l1l111_l1_ (u"ࠩࠪ⽺"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⽻"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⽼"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⽽"),l1l111_l1_ (u"࠭ࠧ⽾"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⽿"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ⾀"),l1l111_l1_ (u"ࠩࠪ⾁"),headers,l1l111_l1_ (u"ࠪࠫ⾂"),l1l111_l1_ (u"ࠫࠬ⾃"),l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⾄"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡤࡱࡱࡳ࠲ࡶ࡬ࡶࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⾅"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⾆"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title==l1l111_l1_ (u"ࠨษ็้่ะศสࠢส่๊ืฦ๋หࠪ⾇"): continue
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⾈"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⾉")+l1lllll_l1_+title,l1ll1ll_l1_,321)
	return html
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⾊"),url,l1l111_l1_ (u"ࠬ࠭⾋"),headers,l1l111_l1_ (u"࠭ࠧ⾌"),l1l111_l1_ (u"ࠧࠨ⾍"),l1l111_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⾎"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡵࡴࡦࡴࠪ⾏"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡶࡤ࠶ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⾐"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡰ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⾑"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,count,title in items:
		count = count.replace(l1l111_l1_ (u"ࠬ฿ฯะࠢࠪ⾒"),l1l111_l1_ (u"࠭ࠧ⾓")).replace(l1l111_l1_ (u"ࠧࠡࠩ⾔"),l1l111_l1_ (u"ࠨࠩ⾕"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࠲ࠫ⾖"),l1l111_l1_ (u"ࠪࠫ⾗"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠦࠬࠨ⾘"),l1l111_l1_ (u"ࠬ࠭⾙"))
		if l1l111_l1_ (u"࠭࠮ࡱࡪࡳࠫ⾚") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠴ࡰࡩࡲࠪ⾛")+l1ll1ll_l1_
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ⾜")+l1ll1ll_l1_
		l1ll1l_l1_ = l111l1_l1_+l1ll1l_l1_
		title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ⾝"))
		title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭⾞")+count+l1l111_l1_ (u"ࠫ࠮࠭⾟")
		if l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨ⾠") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾡"),l1lllll_l1_+title,l1ll1ll_l1_,321,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪ⾢") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⾣"),l1lllll_l1_+title,l1ll1ll_l1_,322,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡵࡴࡦࡴࠪ⾤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⾥"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨ⾦")+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⾧"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ⾨")+title,l1ll1ll_l1_,321)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⾩"),url,l1l111_l1_ (u"ࠨࠩ⾪"),headers,l1l111_l1_ (u"ࠩࠪ⾫"),l1l111_l1_ (u"ࠪࠫ⾬"),l1l111_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⾭"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⾮"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⾯"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ⾰"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ⾱"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ⾲"),l1l111_l1_ (u"ࠪ࠯ࠬ⾳"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ⾴")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ傏")
headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭傐") : l1l111_l1_ (u"ࠪࠫ傑") }
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡙ࡆࡘࡡࠪ傒")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==210: l1lll_l1_ = l1l1l11_l1_()
	elif mode==211: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==212: l1lll_l1_ = PLAY(url)
	elif mode==213: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==214: l1lll_l1_ = l11ll11l1lll_l1_(url)
	elif mode==215: l1lll_l1_ = l11ll11ll111_l1_(url)
	elif mode==218: l1lll_l1_ = l1l1l11lll11_l1_()
	elif mode==219: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11lll11_l1_():
	message = l1l111_l1_ (u"ࠬํะศࠢส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠡ࠰࠱࠲ࠥ๎ศฮษฯอࠥอไ๊ࠢส฽ฬีษࠡสิ้ัฯࠠๆ่ࠣห้฻แาࠢ࠱࠲࠳่ࠦศๆ่ฬึ๋ฬࠡฯส่๏อࠠๆึ฽์้่๋ࠦ฻ส๊๏ࠦๅ็๋ࠢ฽่ฯࠠึฯํอࠥ࠴࠮࠯๋่ࠢ์ึวࠡี๋ๅࠥ๐ศใ๋ࠣห้๋่ใ฻้ࠣ฿๊โࠡษ็ํ๋ࠥวࠡึสลࠥอไๅ้ࠪ傓")
	l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ傔"),l1l111_l1_ (u"ࠧࠨ傕"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ傖"),l1l111_l1_ (u"ࠩส่๊๎โฺࠢอ฾๏ืࠠษษ็็ฬ๋ไࠨ傗"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ傘"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ備"),l1l111_l1_ (u"ࠬ࠭傚"),219,l1l111_l1_ (u"࠭ࠧ傛"),l1l111_l1_ (u"ࠧࠨ傜"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ傝"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡕ࡯࡮ࡀࡶࡼࡴࡪࡃ࡯࡯ࡧࠩࡨࡦࡺࡡ࠾ࡲ࡬ࡲࠫࡲࡩ࡮࡫ࡷࡁ࠷࠻ࠧ傞")
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ傟"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭傠")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭傡"),url,211)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ傢"),headers,l1l111_l1_ (u"ࠧࠨ傣"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ傤"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡉ࡭ࡱࡺࡥࡳࡵࡅࡹࡹࡺ࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ傥"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ傦"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡵࡻࡳࡩࡂࡵ࡮ࡦࠨࡧࡥࡹࡧ࠽ࠨ傧")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ储"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ傩")+l1lllll_l1_+title,url,211)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭傪"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ傫"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"่ࠩืู้ไศฬࠣห๋๋๊ࠨ催"),l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ傭")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭傮"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ傯"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ傰")+l1lllll_l1_+title,l1ll1ll_l1_,211)
	return html
def l1lll11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ傱"),headers,l1l111_l1_ (u"ࠨࠩ傲"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ傳"))
	if l1l111_l1_ (u"ࠪ࡫ࡪࡺࡰࡰࡵࡷࡷࠬ傴") in url or l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ債") in url: block = html
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡓࡥࡥ࡫ࡤࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ傶"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		else: return
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ傷"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ傸"),l1l111_l1_ (u"ࠨใํ่๊࠭傹"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ傺"),l1l111_l1_ (u"ࠪ็้๐ศࠨ傻"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ傼"),l1l111_l1_ (u"ࠬํฯศใࠪ傽"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭傾"),l1l111_l1_ (u"ฺࠧำูࠫ傿"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ僀"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ僁")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ僂") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠫ࠴࠭僃"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠬࠦࠧ僄"))
		if l1l111_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭僅") in l1ll1ll_l1_ or any(value in title for value in l1l111111_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭僆"),l1lllll_l1_+title,l1ll1ll_l1_,212,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ僇") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩส่า๊โสࠩ僈") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭僉"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ僊") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僋"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
					l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭僌"),l1lllll_l1_+title,l1ll1ll_l1_,213,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ働"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ僎"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = unescapeHTML(l1ll1ll_l1_)
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠩสฺ่็อสࠢࠪ像"),l1l111_l1_ (u"ࠪࠫ僐"))
			if title!=l1l111_l1_ (u"ࠫࠬ僑"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ僒"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ僓")+title,l1ll1ll_l1_,211)
	return
def l1ll1l11_l1_(url):
	l1l1111ll_l1_,items,l11111ll_l1_ = -1,[],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ僔"),headers,l1l111_l1_ (u"ࠨࠩ僕"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ僖"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ僗"),html,re.DOTALL)
	if l11llll_l1_:
		l1lll1l1_l1_ = l1l111_l1_ (u"ࠫࠬ僘").join(l11llll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ僙"),l1lll1l1_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ僚"))
		title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭僛") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ僜"))[-1].replace(l1l111_l1_ (u"ࠩ࠰ࠫ僝"),l1l111_l1_ (u"ࠪࠤࠬ僞"))
		l1111ll1_l1_ = re.findall(l1l111_l1_ (u"ࠫฬ๊อๅไฬ࠱࠭ࡢࡤࠬࠫࠪ僟"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ僠"))[-1],re.DOTALL)
		if l1111ll1_l1_: l1111ll1_l1_ = l1111ll1_l1_[0]
		else: l1111ll1_l1_ = l1l111_l1_ (u"࠭࠰ࠨ僡")
		l11111ll_l1_.append([l1ll1ll_l1_,title,l1111ll1_l1_])
	items = sorted(l11111ll_l1_, reverse=False, key=lambda key: int(key[2]))
	l1l11111l_l1_ = str(items).count(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩ僢"))
	l1l1111ll_l1_ = str(items).count(l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ僣"))
	if l1l11111l_l1_>1 and l1l1111ll_l1_>0 and l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ僤") not in url:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ僥") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ僦"),l1lllll_l1_+title,l1ll1ll_l1_,213)
	else:
		for l1ll1ll_l1_,title,l1111ll1_l1_ in items:
			if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ僧") not in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ僨"),l1lllll_l1_+title,l1ll1ll_l1_,212)
	return
def PLAY(url):
	l1llll_l1_ = []
	parts = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ僩"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ僪"),headers,l1l111_l1_ (u"ࠩࠪ僫"),l1l111_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ僬"))
	if l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ僭") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ僮"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ僯"),headers,l1l111_l1_ (u"ࠧࠨ僰"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ僱"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡷࡼࡥࡳࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ僲"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡳࡡࡨࡧࠥࡂࡡࡴࠨ࠯ࠬࡂ࠭ࡡࡴࠧ僳"),block,re.DOTALL)
			if items:
				id = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠦࠬ僴"),l11l1ll1_l1_,re.DOTALL)
				if id:
					l1l1l11l1l_l1_ = id[0]
					for l1ll1ll_l1_,title in items:
						l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ僵")+l1l1l11l1l_l1_+l1l111_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ僶")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ僷")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ僸")
						l1llll_l1_.append(l1ll1ll_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ價"),block,re.DOTALL)
				for l1ll1ll_l1_,dummy in items:
					l1llll_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ僺") in html:
		l1lllll1_l1_ = url.replace(parts[3],l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭僻"))
		l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭僼"),headers,l1l111_l1_ (u"࠭ࠧ僽"),l1l111_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ僾"))
		id = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹࡏࡤ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ僿"),l11l1ll1_l1_,re.DOTALL)
		if id:
			l1l1l11l1l_l1_ = id[0]
			l1ll1ll1l_l1_ = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭儀"):l1l111_l1_ (u"ࠪࠫ儁") , l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ儂"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭儃") }
			l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡦࡲࡻࡳࡲ࡯ࡢࡦ࡯࡭ࡳࡱࡳࠧࡲࡲࡷࡹࡏࡤ࠾ࠩ億")+l1l1l11l1l_l1_
			l11l1ll1_l1_ = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ儅"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ儆"),l1l111_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠴ࡵࡪࠪ儇"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠹࠮ࠫࡁࠫࡠࡩ࠱ࠩࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ儈"),l11l1ll1_l1_,re.DOTALL)
			if l11llll_l1_:
				for resolution,block in l11llll_l1_:
					items = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ儉"),block,re.DOTALL)
					for name,l1ll1ll_l1_ in items:
						l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭儊")+name+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ儋")+l1l111_l1_ (u"ࠧࡠࡡࡢࡣࠬ儌")+resolution)
			else:
				l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠾࡫࠺࠭࠴ࠪࡀࠫ࠿࠳ࡹࡧࡢ࡭ࡧࡁࠫ儍"),l11l1ll1_l1_,re.DOTALL)
				if not l11llll_l1_: l11llll_l1_ = [l11l1ll1_l1_]
				for block in l11llll_l1_:
					name = l1l111_l1_ (u"ࠩࠪ儎")
					items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭儏"),block,re.DOTALL)
					for l1ll1ll_l1_ in items:
						server = l1l111_l1_ (u"ࠫࠫࠬࠧ儐") + l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ儑"))[2].lower() + l1l111_l1_ (u"࠭ࠦࠧࠩ儒")
						server = server.replace(l1l111_l1_ (u"ࠧ࠯ࡥࡲࡱࠫࠬࠧ儓"),l1l111_l1_ (u"ࠨࠩ儔")).replace(l1l111_l1_ (u"ࠩ࠱ࡧࡴࠬࠦࠨ儕"),l1l111_l1_ (u"ࠪࠫ儖"))
						server = server.replace(l1l111_l1_ (u"ࠫ࠳ࡴࡥࡵࠨࠩࠫ儗"),l1l111_l1_ (u"ࠬ࠭儘")).replace(l1l111_l1_ (u"࠭࠮ࡰࡴࡪࠪࠫ࠭儙"),l1l111_l1_ (u"ࠧࠨ儚"))
						server = server.replace(l1l111_l1_ (u"ࠨ࠰࡯࡭ࡻ࡫ࠦࠧࠩ儛"),l1l111_l1_ (u"ࠩࠪ儜")).replace(l1l111_l1_ (u"ࠪ࠲ࡴࡴ࡬ࡪࡰࡨࠪࠫ࠭儝"),l1l111_l1_ (u"ࠫࠬ儞"))
						server = server.replace(l1l111_l1_ (u"ࠬࠬࠦࡩࡦ࠱ࠫ償"),l1l111_l1_ (u"࠭ࠧ儠")).replace(l1l111_l1_ (u"ࠧࠧࠨࡺࡻࡼ࠴ࠧ儡"),l1l111_l1_ (u"ࠨࠩ儢"))
						server = server.replace(l1l111_l1_ (u"ࠩࠩࠪࠬ儣"),l1l111_l1_ (u"ࠪࠫ儤"))
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ儥") + name + server + l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ儦")
						l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ儧"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨ儨"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ儩"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ優"),l1l111_l1_ (u"ࠪ࠯ࠬ儫"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ儬")+search
	l1lll11_l1_(url)
	return
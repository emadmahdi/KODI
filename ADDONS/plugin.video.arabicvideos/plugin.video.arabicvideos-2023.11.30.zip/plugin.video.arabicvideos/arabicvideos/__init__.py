# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111ll1l1_l1_ import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡏࡎࡊࡖࠪ掩")
l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭措"),l1l111_l1_ (u"ࠧ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠬ掫"))
l1ll1ll11l1_l1_ = EXTRACT_KODI_PATH(addon_path)
type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = l1ll1ll11l1_l1_
l1ll1l1ll11l_l1_ = int(mode)
l1lll1l1ll11_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ掬"))
l1lll1l1ll11_l1_ = l1lll1l1ll11_l1_.replace(ltr,l1l111_l1_ (u"ࠩࠪ掭")).replace(rtl,l1l111_l1_ (u"ࠪࠫ掮"))
if l1ll1l1ll11l_l1_==260: message = l1l111_l1_ (u"ࠫࠥࠦࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢ࡞ࠤࠬ掯")+l1l11l11111_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡏࡴࡪࡩ࠻ࠢ࡞ࠤࠬ掰")+l1l1l11111l_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ掱")
else:
	l111l11llll1_l1_ = l111l11_l1_(addon_path).replace(l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ掲"),l1l111_l1_ (u"ࠨࠩ掳")).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ掴"),l1l111_l1_ (u"ࠪࠫ掵"))
	l111l11llll1_l1_ = l111l11llll1_l1_.replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭掶"),l1l111_l1_ (u"ࠬ࠭掷")).strip(l1l111_l1_ (u"࠭ࠠࠨ掸"))
	l111l11llll1_l1_ = l111l11llll1_l1_.replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ掹"),l1l111_l1_ (u"ࠨࠢࠪ掺")).replace(l1l111_l1_ (u"ࠩࠣࠤࠥ࠭掻"),l1l111_l1_ (u"ࠪࠤࠬ掼")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ掽"),l1l111_l1_ (u"ࠬࠦࠧ掾"))
	message = l1l111_l1_ (u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬ掿")+l1lll1l1ll11_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧ揀")+mode+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ揁")+l111l11llll1_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ揂")
l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ揃"),l11lll1l11_l1_(l1ll1_l1_)+message)
l1ll1l11l111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ揄"))
l1111lll1ll_l1_ = False if l1ll1l11l111_l1_==l1l11l11111_l1_ else True
if not l1111lll1ll_l1_ and l1ll1l1ll11l_l1_ in [235,715]:
	l1l11ll1llll_l1_ = str(l1llll11l11_l1_[l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ揅")])
	l1ll1_l1_ = l1l111_l1_ (u"࠭ࡩࡱࡶࡹࠫ揆") if l1ll1l1ll11l_l1_==235 else l1l111_l1_ (u"ࠧ࡮࠵ࡸࠫ揇")
	l11l1l11ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࠬ揈")+l1ll1_l1_+l1l111_l1_ (u"ࠩ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ揉")+l1l11ll1llll_l1_)
	l11ll1l11l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࠧ揊")+l1ll1_l1_+l1l111_l1_ (u"ࠫ࠳ࡸࡥࡧࡧࡵࡩࡷࡥࠧ揋")+l1l11ll1llll_l1_)
	if l11l1l11ll_l1_ or l11ll1l11l_l1_:
		url += l1l111_l1_ (u"ࠬࢂࠧ揌")
		if l11l1l11ll_l1_: url += l1l111_l1_ (u"࠭ࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬ揍")+l11l1l11ll_l1_
		if l11ll1l11l_l1_: url += l1l111_l1_ (u"ࠧࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ揎")+l11ll1l11l_l1_
		url = url.replace(l1l111_l1_ (u"ࠨࡾࠩࠫ描"),l1l111_l1_ (u"ࠩࡿࠫ提"))
	l111ll1lll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࠧ揑")+l1ll1_l1_+l1l111_l1_ (u"ࠫ࠳ࡹࡥࡳࡸࡨࡶࡤ࠭插")+l1l11ll1llll_l1_)
	if l111ll1lll_l1_:
		l111l11lllll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨ揓"),url,re.DOTALL)
		url = url.replace(l111l11lllll_l1_[0],l111ll1lll_l1_)
	l1ll1_l1_ = l1ll1_l1_.upper()
	l1llll111_l1_(url,l1ll1_l1_,type)
else:
	from LIBSTWO import l11ll11l11l_l1_,l1lllllllll1_l1_,l1ll1ll1l111_l1_
	l1111l1l1l1_l1_ = l1l111_l1_ (u"࠭ࠧ揔")
	l11ll11l11l_l1_(l1l111_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭揕"))
	try: l1lllllllll1_l1_(l1ll1ll11l1_l1_,l1lll1l1ll11_l1_)
	except Exception as error: l1111l1l1l1_l1_ = traceback.format_exc()
	l11ll11l11l_l1_(l1l111_l1_ (u"ࠨࡵࡷࡳࡵ࠭揖"))
	l1ll1ll1l111_l1_(l1111l1l1l1_l1_)
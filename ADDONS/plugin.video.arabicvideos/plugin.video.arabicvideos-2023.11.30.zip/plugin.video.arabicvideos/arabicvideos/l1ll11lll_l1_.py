﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪඊ")
headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭උ"):l1l111_l1_ (u"ࠪࠫඌ")}
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡓࡒࡇࡡࠪඍ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไห๊สู้ࠦวๅษฯฮ๊อู๋ࠩඎ"),l1l111_l1_ (u"࠭ี้ำࠣห้ะ่ศื็ࠤฬ๊วอฬ่ห฾๐ࠧඏ"),l1l111_l1_ (u"ࠧฤำื๎ๆࠦฬๆ์฼ࠤฬ๊ศาษ่ะࠬඐ")]
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==40: l1lll_l1_ = l1l1l11_l1_()
	elif mode==41: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==42: l1lll_l1_ = l1ll11l11_l1_(text,l1llllll1_l1_)
	elif mode==43: l1lll_l1_ = PLAY(url)
	elif mode==44: l1lll_l1_ = l1lll11_l1_(text,l1llllll1_l1_)
	elif mode==49: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭එ"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่อัࠠศๆะ๎๊ࠥโ็ษฬࠤฬ๊ๅฺษิๅࠬඒ"),l1l111_l1_ (u"ࠪࠫඓ"),41)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫඔ"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬඕ"),l1l111_l1_ (u"࠭ࠧඖ"),49)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ඗"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ඘"),l1l111_l1_ (u"ࠩࠪ඙"),9999)
	l1ll11l11_l1_(l1l111_l1_ (u"ࠪࠫක"),l1l111_l1_ (u"ࠫ࠶࠭ඛ"))
	return
def l1ll111l1_l1_(options,l1ll11l1l_l1_):
	search,sort,l1111l1l_l1_,category,l1ll1l11l_l1_ = l1l111_l1_ (u"ࠬ࠭ග"),[],[],[],[]
	dummy,l1ll111ll_l1_ = l1ll11ll1_l1_(options)
	for option in list(l1ll111ll_l1_.keys()):
		value = l1ll111ll_l1_[option]
		if not value: continue
		if   option==l1l111_l1_ (u"࠭ࡳࡰࡴࡷࠫඝ"): sort = [value]
		elif option==l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧඞ"): l1111l1l_l1_ = [value]
		elif option==l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨඟ"): search = value
		elif option==l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫච"): category = [value]
		elif option==l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࡭ࡸࡺࠧඡ"): l1ll1l11l_l1_ = [value]
	payload = {l1l111_l1_ (u"ࠦࡦࡩࡴࡪࡱࡱࠦජ"):l1l111_l1_ (u"ࠧ࡬ࡡࡤࡧࡷࡻࡵࡥࡲࡦࡨࡵࡩࡸ࡮ࠢඣ"),l1l111_l1_ (u"ࠨࡤࡢࡶࡤࠦඤ"):{l1l111_l1_ (u"ࠢࡧࡣࡦࡩࡹࡹࠢඥ"):{l1l111_l1_ (u"ࠣࡵࡨࡥࡷࡩࡨࠣඦ"):search,l1l111_l1_ (u"ࠤࡹ࡭ࡩ࡫࡯ࡠࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷࠧට"):category,l1l111_l1_ (u"ࠥࡷࡵ࡫ࡣࡪࡣ࡯࡭ࡸࡺࠢඨ"):l1ll1l11l_l1_,l1l111_l1_ (u"ࠦࡸ࡫ࡲࡪࡧࡶࠦඩ"):l1111l1l_l1_,l1l111_l1_ (u"ࠧࡴࡵ࡮ࡤࡨࡶࠧඪ"):[],l1l111_l1_ (u"ࠨࡳࡰࡴࡷࡣࡻ࡯ࡤࡦࡱࠥණ"):sort,l1l111_l1_ (u"ࠢࡤࡱࡸࡲࡹࠨඬ"):[],l1l111_l1_ (u"ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧත"):[]},l1l111_l1_ (u"ࠤࡩࡶࡴࢀࡥ࡯ࡡࡩࡥࡨ࡫ࡴࡴࠤථ"):{},l1l111_l1_ (u"ࠥࡸࡪࡳࡰ࡭ࡣࡷࡩࠧද"):l1l111_l1_ (u"ࠦࡻ࡯ࡤࡦࡱࡢࡨࡪࡹ࡫ࡵࡱࡳࡣࡵࡵࡳࡵࡵࠥධ"),l1l111_l1_ (u"ࠧ࡫ࡸࡵࡴࡤࡷࠧන"):{l1l111_l1_ (u"ࠨࡳࡰࡴࡷࠦ඲"):l1l111_l1_ (u"ࠢࡥࡧࡩࡥࡺࡲࡴࠣඳ")},l1l111_l1_ (u"ࠣࡵࡲࡪࡹࡥࡲࡦࡨࡵࡩࡸ࡮ࠢප"):0,l1l111_l1_ (u"ࠤ࡬ࡷࡤࡨࡦࡤࡣࡦ࡬ࡪࠨඵ"):1,l1l111_l1_ (u"ࠥࡪ࡮ࡸࡳࡵࡡ࡯ࡳࡦࡪࠢබ"):0,l1l111_l1_ (u"ࠦࡵࡧࡧࡦࡦࠥභ"):int(l1ll11l1l_l1_)}}
	import json
	payload = json.dumps(payload)
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡭࡯ࡤࡥࡷ࡫ࡦ࠯ࡥ࡫࠳ࡼࡶ࠭࡫ࡵࡲࡲ࠴࡬ࡡࡤࡧࡷࡻࡵ࠵ࡶ࠲࠱ࡵࡩ࡫ࡸࡥࡴࡪࠪම")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫඹ"),l1ll1ll_l1_,payload,l1l111_l1_ (u"ࠧࠨය"),l1l111_l1_ (u"ࠨࠩර"),l1l111_l1_ (u"ࠩࠪ඼"),l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊ࠲ࡘࡅࡒࡗࡈࡗ࡙ࡥࡄࡂࡖࡄࡣࡕࡇࡇࡆ࠯࠴ࡷࡹ࠭ල"))
	html = response.content
	data = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ඾"),html)
	return data
def l1ll11l11_l1_(options,level):
	l1lll1l1_l1_ = l1ll111l1_l1_(options,l1l111_l1_ (u"ࠬ࠷ࠧ඿"))
	block = l1lll1l1_l1_[l1l111_l1_ (u"࠭ࡦࡢࡥࡨࡸࡸ࠭ව")]
	if level==l1l111_l1_ (u"ࠧ࠲ࠩශ"):
		block = block[l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࡟ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶࠫෂ")]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡨ࡮ࡼࠨ࠯ࠬࡂ࠭࠴ࡪࡩࡷࡀࠪස"),block,re.DOTALL)
		for item in items:
			tmp = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡸࡤࡰࡺ࡫࠽࡝࡞ࠥࠬ࠳࠰࠿ࠪ࡞࡟ࠦ࠳࠰࠿ࡥ࡫ࡶࡴࡱࡧࡹ࠮ࡸࡤࡰࡺ࡫࡜࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪහ"),item+l1l111_l1_ (u"ࠫࡁ࠭ළ"),re.DOTALL)
			if not tmp: tmp = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺࡦࡲࡵࡦ࠿࡟ࡠࠧ࠮࠮ࠫࡁࠬࡠࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧෆ"),item+l1l111_l1_ (u"࠭࠼ࠨ෇"),re.DOTALL)
			category,title = tmp[0]
			if not options: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ෈"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ෉")+l1lllll_l1_+title,l1l111_l1_ (u"්ࠩࠪ"),42,l1l111_l1_ (u"ࠪࠫ෋"),l1l111_l1_ (u"ࠫ࠷࠭෌"),l1l111_l1_ (u"ࠬࡅࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ෍")+category)
			else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෎"),l1lllll_l1_+title,l1l111_l1_ (u"ࠧࠨා"),42,l1l111_l1_ (u"ࠨࠩැ"),l1l111_l1_ (u"ࠩ࠵ࠫෑ"),options+l1l111_l1_ (u"ࠪࠪࡨࡧࡴࡦࡩࡲࡶࡾࡃࠧි")+category)
	if level==l1l111_l1_ (u"ࠫ࠷࠭ී"):
		block = block[l1l111_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱ࡯ࡳࡵࠩු")]
		items = re.findall(l1l111_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ෕"),block,re.DOTALL)
		for l1ll1l11l_l1_,title in items:
			if not l1ll1l11l_l1_: title = title = l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧූ")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ෗"),l1lllll_l1_+title,l1l111_l1_ (u"ࠩࠪෘ"),42,l1l111_l1_ (u"ࠪࠫෙ"),l1l111_l1_ (u"ࠫ࠸࠭ේ"),options+l1l111_l1_ (u"ࠬࠬࡳࡱࡧࡦ࡭ࡦࡲࡩࡴࡶࡀࠫෛ")+l1ll1l11l_l1_)
	elif level==l1l111_l1_ (u"࠭࠳ࠨො"):
		block = block[l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧෝ")]
		items = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫෞ"),block,re.DOTALL)
		for l1111l1l_l1_,title in items:
			if not l1111l1l_l1_: title = title = l1l111_l1_ (u"ࠩส่ัฺ๋๊ࠩෟ")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෠"),l1lllll_l1_+title,l1l111_l1_ (u"ࠫࠬ෡"),42,l1l111_l1_ (u"ࠬ࠭෢"),l1l111_l1_ (u"࠭࠴ࠨ෣"),options+l1l111_l1_ (u"ࠧࠧࡵࡨࡶ࡮࡫ࡳ࠾ࠩ෤")+l1111l1l_l1_)
	elif level==l1l111_l1_ (u"ࠨ࠶ࠪ෥"):
		block = block[l1l111_l1_ (u"ࠩࡶࡳࡷࡺ࡟ࡷ࡫ࡧࡩࡴ࠭෦")]
		items = re.findall(l1l111_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭෧"),block,re.DOTALL)
		for sort,title in items:
			if not sort: continue
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ෨"),l1lllll_l1_+title,l1l111_l1_ (u"ࠬ࠭෩"),44,l1l111_l1_ (u"࠭ࠧ෪"),l1l111_l1_ (u"ࠧ࠲ࠩ෫"),options+l1l111_l1_ (u"ࠨࠨࡶࡳࡷࡺ࠽ࠨ෬")+sort)
	return
def l1lll11_l1_(options,l1ll11l1l_l1_):
	l1lll1l1_l1_ = l1ll111l1_l1_(options,l1ll11l1l_l1_)
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠩࡷࡩࡲࡶ࡬ࡢࡶࡨࠫ෭")]
	items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ෮"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ෯"),l1lllll_l1_+title,l1ll1ll_l1_,43,l1ll1l_l1_)
	block = l1lll1l1_l1_[l1l111_l1_ (u"ࠬ࡬ࡡࡤࡧࡷࡷࠬ෰")][l1l111_l1_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ෱")]
	items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡶࡡࡨࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫෲ"),block,re.DOTALL)
	for l1llllll1_l1_,title in items:
		if l1ll11l1l_l1_==l1llllll1_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨෳ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ෴")+title,l1l111_l1_ (u"ࠪࠫ෵"),44,l1l111_l1_ (u"ࠫࠬ෶"),l1llllll1_l1_,options)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ෷"),url,l1l111_l1_ (u"࠭ࠧ෸"),l1l111_l1_ (u"ࠧࠨ෹"),l1l111_l1_ (u"ࠨࠩ෺"),l1l111_l1_ (u"ࠩࠪ෻"),l1l111_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ෼"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ෽"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪࡥࡵࡳ࡮࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠧࠩ෾"),html,re.DOTALL)
	l1ll11l1_l1_ = []
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"࠭࡜࠰ࠩ෿"),l1l111_l1_ (u"ࠧ࠰ࠩ฀"))
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧก"),url)
	return
def l1ll1llll_l1_():
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ข"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳อั࠭ๆสสุึ࠭ฃ"),l1l111_l1_ (u"ࠫࠬค"),l1l111_l1_ (u"ࠬ࠭ฅ"),l1l111_l1_ (u"࠭ࠧฆ"),l1l111_l1_ (u"ࠧࠨง"),l1l111_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈ࠰ࡐࡎ࡜ࡅ࠮࠳ࡶࡸࠬจ"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧฉ"),html,re.DOTALL)
	url = l111l11_l1_(items[0])
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨช"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	l1ll1l111_l1_ = False
	if search==l1l111_l1_ (u"ࠫࠬซ"):
		search = l1llll1_l1_()
		l1ll1l111_l1_ = True
	if search==l1l111_l1_ (u"ࠬ࠭ฌ"): return
	if not l1ll1l111_l1_: l1lll11_l1_(l1l111_l1_ (u"࠭࠿ࡴࡧࡤࡶࡨ࡮࠽ࠨญ")+search,l1l111_l1_ (u"ࠧ࠲ࠩฎ"))
	else: l1ll11l11_l1_(l1l111_l1_ (u"ࠨࡁࡶࡩࡦࡸࡣࡩ࠿ࠪฏ")+search,l1l111_l1_ (u"ࠩ࠴ࠫฐ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from l1l111ll1l1_l1_ import *
import bidi.algorithm,base64
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡌࡆࡘ࡚ࡗࡐࠩ㌣")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l1111111lll_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ㌤"))
	l1ll1l1111_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ㌥"))
	l11l11ll111_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ㌦"))
	l111l111lll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ㌧"),l1l111_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ㌨"),l1l111_l1_ (u"ࠧࡂࡦࡧࡳࡳࡹ࠳࠴࠰ࡧࡦࠬ㌩"))
	l11l1l1lll1_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㌪"),l1l111_l1_ (u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ㌫"),l1l111_l1_ (u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ㌬"))
	l1llll1ll1_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㌭"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㌮"),l1l111_l1_ (u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭㌯"))
	half_triangular_colon = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ㌰")
	from urllib.parse import quote as _1llll11l11l_l1_
else:
	l1111111lll_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡽࡨ࡭ࡤࠩ㌱"))
	l1ll1l1111_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ㌲"))
	l11l11ll111_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵࡬ࡰࡩࡳࡥࡹ࡮ࠧ㌳"))
	l111l111lll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭㌴"),l1l111_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ㌵"),l1l111_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠸࠷࠯ࡦࡥࠫ㌶"))
	l11l1l1lll1_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㌷"),l1l111_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ㌸"),l1l111_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ㌹"))
	l1llll1ll1_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ㌺"),l1l111_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭㌻"),l1l111_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ㌼"))
	half_triangular_colon = l1l111_l1_ (u"ࡻࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ㌽").encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㌾"))
	from urllib import quote as _1llll11l11l_l1_
l1llll11ll11_l1_ = os.path.join(l11l11ll111_l1_,l1l111_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪ㌿"))
l1lllll1ll1l_l1_ = os.path.join(l11l11ll111_l1_,l1l111_l1_ (u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨ㍀"))
iptv1_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㍁"))
iptv2_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭㍂"))
m3u_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ㍃"))
favoritesfile = os.path.join(addoncachefolder,l1l111_l1_ (u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ㍄"))
fulliptvfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㍅"))
fullm3ufile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ㍆"))
l1l1ll111lll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡩࡧࡴࠨ㍇"))
l1l1ll1lllll_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭㍈"))
l1l1l11l1ll_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠫࡵࡧࡴࡩࠩ㍉"))
defaulticon = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧ㍊"))
defaultthumb = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩ㍋"))
defaultfanart = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫ㍌"))
defaultbanner = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠨࡤࡤࡲࡳ࡫ࡲ࠯ࡲࡱ࡫ࠬ㍍"))
defaultlandscape = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࠳ࡶ࡮ࡨࠩ㍎"))
defaultposter = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡦࡴ࠱ࡴࡳ࡭ࠧ㍏"))
defaultclearlogo = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵ࠮ࡱࡰࡪࠫ㍐"))
defaultclearart = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺ࠮ࡱࡰࡪࠫ㍑"))
l1ll1ll11lll_l1_ = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"࠭ࡣࡩࡣࡱ࡫ࡪࡲ࡯ࡨ࠰ࡷࡼࡹ࠭㍒"))
l1llllllll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ㍓"))
l1ll1l1lll1l_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ㍔"),l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭㍕"),addon_id,l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㍖"))
l11111l1ll1_l1_ = os.path.join(l1111111lll_l1_,l1l111_l1_ (u"ࠫࡲ࡫ࡤࡪࡣࠪ㍗"),l1l111_l1_ (u"ࠬࡌ࡯࡯ࡶࡶࠫ㍘"),l1l111_l1_ (u"࠭ࡡࡳ࡫ࡤࡰ࠳ࡺࡴࡧࠩ㍙"))
FOLDERS_COUNT = 5
NUMBERS_SEQ_NAME = [l1l111_l1_ (u"ࠧึใิࠫ㍚"),l1l111_l1_ (u"ࠨล๋่ࠬ㍛"),l1l111_l1_ (u"ࠩฮห๋๐ࠧ㍜"),l1l111_l1_ (u"ࠪฯฬ๊หࠨ㍝"),l1l111_l1_ (u"ࠫึอศฺࠩ㍞"),l1l111_l1_ (u"ࠬิวๆีࠪ㍟"),l1l111_l1_ (u"࠭ำศัึࠫ㍠"),l1l111_l1_ (u"ࠧิษห฽ࠬ㍡"),l1l111_l1_ (u"ࠨอส้๋࠭㍢"),l1l111_l1_ (u"ࠩอหุ฿ࠧ㍣"),l1l111_l1_ (u"ࠪ฽ฬฺัࠨ㍤")]
l1lllll1l1ll_l1_ = l1l111_l1_ (u"ࠫ⹀ࠦ⼝ࠡ⸬ࠣ⸿ࠬ㍥")
l11ll11l_l1_ = 0
l1lll111l1l1_l1_ = 30*l1l1ll111l1_l1_
l111l11l_l1_ = 2*l1l11ll1ll1_l1_
l11l1l1_l1_ = 16*l1l11ll1ll1_l1_
l1ll1ll1lll_l1_ = 30*l1l11ll11l1_l1_
l1l111lllll_l1_ = 1*l1l11ll1ll1_l1_
l1l1llll111l_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㍦")]
l1111111ll1_l1_ = [l1l111_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ㍧"),l1l111_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ㍨"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ㍩"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ㍪"),l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭㍫"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ㍬"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ㍭"),l1l111_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭㍮")]
l1111111ll1_l1_ += [l1l111_l1_ (u"ࠧࡉࡇࡏࡅࡑ࠭㍯"),l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㍰"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ㍱"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ㍲"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭㍳"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㍴"),l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡕࡘࡏࠨ㍵"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭㍶"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ㍷")]
l1l1ll11l1l1_l1_ = [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㍸"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭㍹"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ㍺"),l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ㍻")]
l1l1ll11l1l1_l1_ += [l1l111_l1_ (u"࠭ࡍ࠴ࡗࠪ㍼"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ㍽"),l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㍾"),l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㍿")]
l1l1ll11l1l1_l1_ += [l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ㎀"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㎁"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㎂")]
l1l1ll11l1l1_l1_ += [l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㎃"),l1l111_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈࠧ㎄"),l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㎅"),l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㎆"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㎇"),l1l111_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ㎈"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ㎉")]
l1l1ll11l1l1_l1_ += [l1l111_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ㎊"),l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㎋"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㎌"),l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ㎍"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㎎"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㎏")]
l1ll1l11l1l_l1_ = [l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㎐"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㎑"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㎒"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㎓")]
l1ll1l11l1l_l1_ += [l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ㎔"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ㎕"),l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ㎖"),l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ㎗"),l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ㎘")]
l1ll1l1lll1_l1_ = [l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㎙"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㎚"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ㎛"),l1l111_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ㎜"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ㎝"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࡗࡐࡔࡎࠫ㎞")]
l1ll1l1lll1_l1_ += [l1l111_l1_ (u"࠭ࡃࡊࡏࡄ࠸࡚࠭㎟"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩ㎠"),l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㎡"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㎢"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬ㎣")]
l1lll11l11l_l1_ = [l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㎤"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㎥"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㎦"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㎧"),l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠴ࠪ㎨"),l1l111_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㎩"),l1l111_l1_ (u"ࠪࡅࡍ࡝ࡁࡌࠩ㎪"),l1l111_l1_ (u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬ㎫")]
l1lll11l11l_l1_ += [l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㎬"),l1l111_l1_ (u"࠭ࡂࡓࡕࡗࡉࡏ࠭㎭"),l1l111_l1_ (u"࡚ࠧࡃࡔࡓ࡙࠭㎮"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㎯"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ㎰"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㎱")]
l1ll1ll1ll1l_l1_  = [l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ㎲"),l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㎳"),l1l111_l1_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ㎴"),l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㎵"),l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㎶"),l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㎷"),l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㎸"),l1l111_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭㎹")]
l1ll1ll1ll1l_l1_ += [l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㎺"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㎻"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㎼"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㎽"),l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㎾"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㎿"),l1l111_l1_ (u"ࠫࡋࡕࡓࡕࡃࠪ㏀"),l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㏁"),l1l111_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㏂")]
l1ll1ll1ll1l_l1_ += [l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㏃"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ㏄"),l1l111_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬ㏅"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㏆"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭㏇"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ㏈"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ㏉")]
l1ll1ll1ll1l_l1_ += [l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㏊"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ㏋"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㏌"),l1l111_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ㏍"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡃࡅࡈࡔ࠭㏎"),l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㏏"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㏐")]
l1ll1ll1ll1l_l1_ += [l1l111_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ㏑"),l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ㏒"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ㏓"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㏔"),l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㏕"),l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㏖"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ㏗")]
l1ll1111llll_l1_  = [l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ㏘"),l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ㏙"),l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ㏚"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ㏛")]
l1ll1111llll_l1_ += [l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ㏜"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ㏝")]
l1ll1111llll_l1_ += [l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ㏞"),l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ㏟"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ㏠")]
l1ll1111llll_l1_ += [l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ㏡"),l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ㏢"),l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ㏣")]
l1ll1111llll_l1_ += [l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ㏤"),l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪ㏥"),l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫ㏦")]
l1ll11l1ll11_l1_ = [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㏧"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㏨"),l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ㏩"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ㏪"),l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㏫")]
l1ll1lll1ll_l1_ = l1ll1ll1ll1l_l1_+l1ll1111llll_l1_
l1ll1l1l1l1l_l1_ = l1ll1ll1ll1l_l1_+l1ll11l1ll11_l1_
l1l11111l11_l1_ = l1ll1ll1ll1l_l1_+l1ll11l1ll11_l1_
l1ll1lll1l1_l1_ = l1l1ll11l1l1_l1_+l1ll1l1lll1_l1_+l1lll11l11l_l1_+l1ll1l11l1l_l1_
l1lllll11l11_l1_ = [
						l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ㏬")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ㏭")
						,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ㏮")
						,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ㏯")
						,l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ㏰")
						,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡐࡎࡒࡇࡆ࡚ࡉࡐࡐ࠰࠵ࡸࡺࠧ㏱")
						,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠷ࡳࡵࠩ㏲")
						,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠳ࡳࡦࠪ㏳")
						,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫ㏴")
						,l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ㏵")
						,l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩ㏶")
						,l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠵ࡵࡪࠪ㏷")
						]
l11l11lllll_l1_ = l1lllll11l11_l1_+[
				 l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭㏸")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㏹")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ㏺")
				,l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ㏻")
				,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ㏼")
				,l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ㏽")
				,l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ㏾")
				,l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭㏿")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ㐀")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ㐁")
				,l1l111_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ㐂")
				,l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠲ࡵࡷࠫ㐃")
				,l1l111_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠴ࡱࡨࠬ㐄")
				,l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡛ࡓࡂࡉࡈࡣࡗࡋࡐࡐࡔࡗ࠱࠶ࡹࡴࠨ㐅")
				,l1l111_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ㐆")
				,l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭㐇")
				,l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨ㐈")
				]
l11111l1l1l_l1_ = [l1l111_l1_ (u"ࠧ࠹࠰࠻࠲࠽࠴࠸ࠨ㐉"),l1l111_l1_ (u"ࠨ࠳࠱࠵࠳࠷࠮࠲ࠩ㐊"),l1l111_l1_ (u"ࠩ࠴࠲࠵࠴࠰࠯࠳ࠪ㐋"),l1l111_l1_ (u"ࠪ࠼࠳࠾࠮࠵࠰࠷ࠫ㐌"),l1l111_l1_ (u"ࠫ࠷࠶࠸࠯࠸࠺࠲࠷࠸࠲࠯࠴࠵࠶ࠬ㐍"),l1l111_l1_ (u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠱࠰࠵࠶࠵࠭㐎")]
l1l11l1_l1_ = {
			 l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㐏")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮ࡳࡦࡳ࠮࡯ࡧࡷࠫ㐐")]
			,l1l111_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ㐑")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡡࡩࡹࡤ࡯ࡹࡼ࠮࡯ࡧࡷࠫ㐒")]
			,l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㐓")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫ࡸࡣࡰ࠲ࡳ࡫ࡴࠨ㐔")]
			,l1l111_l1_ (u"ࠬࡇࡌࡂࡔࡄࡆࠬ㐕")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲࡡࡳࡣࡥ࠲ࡨࡵ࡭ࠨ㐖")]
			,l1l111_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ㐗")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡪࡦࡺࡩ࡮࡫࠱ࡸࡻ࠭㐘")]
			,l1l111_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ㐙")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡲ࡭ࡢࡣࡵࡩ࡫࠴ࡣࡩࠩ㐚")]
			,l1l111_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ㐛")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱࠬ㐜")]
			,l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㐝")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡥࡧࡹࡥࡦࡦ࠱ࡲࡪࡺࠧ㐞")]
			,l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㐟")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡷࡱࡧ࠲ࡨࡵ࡭ࠨ㐠")]
			,l1l111_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ㐡")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡨࡲࡴࡶࡨ࡮࠳ࡩ࡯࡮ࠩ㐢")]
			,l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭㐣")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤ࡫ࡰࡥ࠹࠶࠰࠯ࡥࡲࡱࠬ㐤")]
			,l1l111_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ㐥")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠴ࡧ࡮ࡳࡡ࠵ࡷ࠱ࡧࡴࡳࠧ㐦")]
			,l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ㐧")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡣࡥࡨࡴ࠴ࡣࡰ࡯ࠪ㐨")]
			,l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪ㐩")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡹࡲࡶࡰ࠭㐪")]
			,l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨ㐫")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡩ࡮ࡣࡩࡥࡳࡹ࠮ࡤࡱࡰࠫ㐬")]
			,l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ㐭")	:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻ࠷࠼࠮࡮ࡻ࠰ࡧ࡮ࡳࡡ࠯ࡰࡨࡸࠬ㐮")]
			,l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㐯")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠰ࡲࡴࡽ࠮ࡤࡱࡰࠫ㐰")]
			,l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ㐱")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠭㐲"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩࡵࡥࡵ࡮ࡱ࡭࠰ࡤࡴ࡮࠴ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠲ࡨࡵ࡭ࠨ㐳")]
			,l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ㐴")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡨ࠴ࡤࡳࡣࡰࡥࡸ࠽࠮ࡤࡱࡰࠫ㐵")]
			,l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬ㐶")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴ࠭ࡦࡩࡼ࠲ࡧ࡫ࡳࡵࠩ㐷")]
			,l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ㐸")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࡩࡻ࠭㐹")]
			,l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠴ࠩ㐺")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡬ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡧ࡯ࡤࠨ㐻")]
			,l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ㐼")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠮ࡤࡨࡷࡹ࠴࡮ࡦࡶࠪ㐽")]
			,l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㐾")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡧࡩࡦࡪ࠮࡭࡫ࡹࡩࠬ㐿")]
			,l1l111_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ㑀")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࡯ࡧ࡮ࡴࡥ࡮ࡣ࠱ࡧࡴࡳࠧ㑁")]
			,l1l111_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ㑂")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧ㑃")]
			,l1l111_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭㑄")	:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩ㑅")]
			,l1l111_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ㑆")		:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠳ࡼࡩࡱࠩ㑇")]
			,l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ㑈")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧ㑉")]
			,l1l111_l1_ (u"ࠩࡉࡓࡘ࡚ࡁࠨ㑊")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧ㑋")]
			,l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭㑌")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯ࡷࡶࠫ㑍")]
			,l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ㑎")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ㑏"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩ㑐"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ㑑"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬ㑒"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫ㑓")]
			,l1l111_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ㑔")	:[l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧ㑕")]
			,l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ㑖")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ㑗")]
			,l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ㑘")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲࡵࡶ࠯࡭࡬ࡸࡰࡵࡴ࠯ࡶࡹࠫ㑙")]
			,l1l111_l1_ (u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ㑚")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩ㑛"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࠰ࡩࡻࡸ࠴ࡳࡵࡱࡵࡩࠬ㑜")]
			,l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨ㑝")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡳࡩࡿ࡮ࡦࡶ࠱ࡧࡦࡳࠧ㑞")]
			,l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ㑟")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬ㑠")]
			,l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㑡")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࠲࠰ࡹ࡭ࡵ࠭㑢")]
			,l1l111_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ㑣")	:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧ࠱ࡷ࡭࠺ࡵ࠯ࡰࡨࡻࡸ࠭㑤")]
			,l1l111_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁࠨ㑥")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࠳ࡹࡨࡰࡨ࡫ࡥ࠳ࡺࡶࠨ㑦")]
			,l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ㑧")		:[l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫ㑨"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬ㑩"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ㑪")]
			,l1l111_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭㑫")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲ࡹࡼࡦࡶࡰ࠱ࡱࡪ࠭㑬")]
			,l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㑭")		:[l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼ࡫ࡣࡪ࡯ࡤ࠲ࡹࡻࡢࡦࠩ㑮")]
			,l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ㑯")		:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡹ࠯ࡻࡤࡵࡴࡺ࠮ࡵࡸࠪ㑰")]
			,l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ㑱")		:[l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯ࠪ㑲")]
			,l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ㑳")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ㑴"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ㑵"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ㑶"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ㑷"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ㑸"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭㑹"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ㑺"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡦࡥࡵࡺࡣࡩࡣࠪ㑻"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡸࡪࡹࡴࡪࡰࡪࠫ㑼")]
			,l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨ㑽")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨ㑾"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬ㑿"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫ㒀"),l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ㒁"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ㒂"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ㒃"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭㒄"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧ㒅"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ㒆")]
			,l1l111_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㒇")		:[l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨ㒈"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠾࠯ࡢࡦࡧࡳࡳࡹ࠱࠹࠰ࡻࡱࡱ࠭㒉"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠷࠹࠰ࡣࡧࡨࡴࡴࡳ࠲࠻࠱ࡼࡲࡲࠧ㒊")]
			,l1l111_l1_ (u"ࠫࡗࡋࡐࡐࡕࡢࡆࡐࡖࠧ㒋")	:[l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪ㒌"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨ㒍"),l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩ㒎")]
			,l1l111_l1_ (u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩ㒏")		:[l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡰࡵࡤࡪࠩ㒐"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡳࡶࡴࡪࡩ࠳ࡹࡨࠨ㒑"),l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕࠧ㒒")]
			}
l1111l1lll1_l1_ = [l1l111_l1_ (u"ࠬࡒࡉࡔࡖࡓࡐࡆ࡟ࠧ㒓"),l1l111_l1_ (u"࠭ࡒࡆࡒࡒࡖ࡙࡙ࠧ㒔"),l1l111_l1_ (u"ࠧࡆࡏࡄࡍࡑ࡙ࠧ㒕"),l1l111_l1_ (u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪ㒖"),l1l111_l1_ (u"ࠩࡌࡗࡑࡇࡍࡊࡅࡖࠫ㒗"),l1l111_l1_ (u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭㒘"),l1l111_l1_ (u"ࠫࡐࡔࡏࡘࡐࡈࡖࡗࡕࡒࡔࠩ㒙"),l1l111_l1_ (u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭㒚"),l1l111_l1_ (u"࠭ࡔࡆࡕࡗࡍࡓࡍࠧ㒛")]
l11l111l1ll_l1_ = [l1l111_l1_ (u"ࠧࡂࡆࡇࡓࡓ࡙ࠧ㒜"),l1l111_l1_ (u"ࠨࡃࡇࡈࡔࡔࡓ࠲࠺ࠪ㒝"),l1l111_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠼ࠫ㒞")]
class l1ll11l1lll1_l1_(l1l1l1l11ll_l1_):
	def __init__(self,*args,**kwargs):
		self.l11llll1ll1_l1_ = -1
	def onClick(self,l11111ll11l_l1_):
		if l11111ll11l_l1_>=9010: self.l11llll1ll1_l1_ = l11111ll11l_l1_-9010
		self.delete()
	def l111ll1llll_l1_(self,*args):
		self.l1111llllll_l1_,self.l1ll11l11111_l1_,self.l111l111l11_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.profile,self.l1ll1llll11l_l1_ = args[5],args[6]
		self.l1ll1lllllll_l1_,self.l1l1ll1111ll_l1_,self.l1l1lllll1l1_l1_ = args[7],args[8],args[9]
		if self.l1l1ll1111ll_l1_>0 or self.l1l1lllll1l1_l1_>0: self.l1ll1ll11111_l1_ = True
		else: self.l1ll1ll11111_l1_ = False
		self.l1lll1111111_l1_,self.l111lll1111_l1_ = l1lllll1ll11_l1_(self.l1111llllll_l1_,self.l1ll11l11111_l1_,self.l111l111l11_l1_,self.header,self.text,self.profile,self.l1ll1llll11l_l1_,self.l1ll1lllllll_l1_,self.l1ll1ll11111_l1_)
		self.show()
		self.getControl(9050).setImage(self.l1lll1111111_l1_)
		self.getControl(9050).setHeight(self.l111lll1111_l1_)
		if not self.l1ll11l11111_l1_ and self.l1111llllll_l1_ and self.l111l111l11_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l1lll1111111_l1_,self.l111lll1111_l1_
	def l11llll11ll_l1_(self):
		if self.l1l1ll1111ll_l1_:
			from threading import Thread
			self.l1l111lll11_l1_ = Thread(target=self.l1lll11l1l11_l1_,args=())
			self.l1l111lll11_l1_.start()
		else: self.l11l11111ll_l1_()
	def l1lll11l1l11_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l1l11l111l_l1_ in range(1,self.l1l1ll1111ll_l1_+1):
			time.sleep(1)
			l1l1ll11l111_l1_ = int(100*l1l11l111l_l1_/self.l1l1ll1111ll_l1_)
			self.l1l1lll11l11_l1_(l1l1ll11l111_l1_)
			if self.l11llll1ll1_l1_>0: break
		self.l11l11111ll_l1_()
	def l11ll1ll11l_l1_(self):
		if self.l1l1lllll1l1_l1_:
			from threading import Thread
			self.l1ll1l1l1l11_l1_ = Thread(target=self.l1llllll1l11_l1_,args=())
			self.l1ll1l1l1l11_l1_.start()
		else: self.l11l11111ll_l1_()
	def l1llllll1l11_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1l1ll1111ll_l1_)
		for l1l11l111l_l1_ in range(self.l1l1lllll1l1_l1_-1,-1,-1):
			time.sleep(1)
			l1l1ll11l111_l1_ = int(100*l1l11l111l_l1_/self.l1l1lllll1l1_l1_)
			self.l1l1lll11l11_l1_(l1l1ll11l111_l1_)
			if self.l11llll1ll1_l1_>0: break
		if self.l1l1lllll1l1_l1_>0: self.l11llll1ll1_l1_ = 10
		self.delete()
	def l1l1lll11l11_l1_(self,l1l1ll11l111_l1_):
		self.l1l1llllllll_l1_ = l1l1ll11l111_l1_
		self.getControl(9020).setPercent(self.l1l1llllllll_l1_)
	def l11l11111ll_l1_(self):
		if self.l1111llllll_l1_: self.getControl(9010).setEnabled(True)
		if self.l1ll11l11111_l1_: self.getControl(9011).setEnabled(True)
		if self.l111l111l11_l1_: self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l1lll1111111_l1_)
		except: pass
class l11l1111l1l_l1_():
	def __init__(self,l11_l1_=False,l1ll1ll111ll_l1_=True):
		self.l11_l1_ = l11_l1_
		self.l1ll1ll111ll_l1_ = l1ll1ll111ll_l1_
		self.l11l11ll11l_l1_,self.l1l111111ll_l1_ = [],[]
		self.l11111ll1l1_l1_,self.l1llll1ll1l1_l1_ = {},{}
		self.l111l1ll1ll_l1_ = []
		self.l1l1lll11l1l_l1_,self.l1l1lll1llll_l1_,self.l11lll1ll11_l1_ = {},{},{}
	def l111llll11l_l1_(self,id,func,*args):
		id = str(id)
		self.l11111ll1l1_l1_[id] = l1l111_l1_ (u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫ㒟")
		if self.l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫࠬ㒠"),id)
		from threading import Thread
		l11lllll111_l1_ = Thread(target=self.run,args=(id,func,args))
		self.l111l1ll1ll_l1_.append(l11lllll111_l1_)
		return l11lllll111_l1_
	def start_new_thread(self,id,func,*args):
		l11lllll111_l1_ = self.l111llll11l_l1_(id,func,*args)
		l11lllll111_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l1lll11l1l_l1_[id] = time.time()
		try:
			self.l1llll1ll1l1_l1_[id] = func(*args)
			if l1l111_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑ࠭㒡") in str(func) and not self.l1llll1ll1l1_l1_[id].succeeded:
				l1111111111_l1_(l1l111_l1_ (u"࠭ࡆࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠤࡩࡻࡥࠡࡶࡲࠤࡹ࡮ࡲࡦࡣࡧࡩࡩࠦࡏࡑࡇࡑ࡙ࡗࡒࠠࡧࡣ࡬ࡰࠬ㒢"))
			self.l11l11ll11l_l1_.append(id)
			self.l11111ll1l1_l1_[id] = l1l111_l1_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ㒣")
		except Exception as err:
			if self.l1ll1ll111ll_l1_:
				l1111l1l1l1_l1_ = traceback.format_exc()
				sys.stderr.write(l1111l1l1l1_l1_)
			self.l1l111111ll_l1_.append(id)
			self.l11111ll1l1_l1_[id] = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㒤")
		self.l1l1lll1llll_l1_[id] = time.time()
		self.l11lll1ll11_l1_[id] = self.l1l1lll1llll_l1_[id] - self.l1l1lll11l1l_l1_[id]
	def l1ll1ll111l1_l1_(self):
		for proc in self.l111l1ll1ll_l1_:
			proc.start()
	def l1l1ll11ll1l_l1_(self):
		while l1l111_l1_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ㒥") in list(self.l11111ll1l1_l1_.values()): time.sleep(1.000)
def l1ll1lll1l1l_l1_():
	l1ll1l11l111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ㒦"))
	l1111lll1ll_l1_ = True
	if l1ll1l11l111_l1_==l1l11l11111_l1_:
		status = l1l111_l1_ (u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧ㒧")
		l1111lll1ll_l1_ = False
	elif not os.path.exists(addoncachefolder):
		status = l1l111_l1_ (u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪ㒨")
		os.makedirs(addoncachefolder)
	else:
		status = l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫ㒩")
		l1ll1111ll1l_l1_ = [l1l111_l1_ (u"ࠧ࠹࠰࠸࠲࠵࠭㒪"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ࠬ㒫"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧࠧ㒬"),l1l111_l1_ (u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧ㒭"),l1l111_l1_ (u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨ㒮"),l1l111_l1_ (u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩ㒯"),l1l111_l1_ (u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪ㒰"),l1l111_l1_ (u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫ㒱"),l1l111_l1_ (u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬ㒲"),l1l111_l1_ (u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭㒳")]
		l1llll11llll_l1_ = l1ll1111ll1l_l1_[-1]
		l111l111ll1_l1_ = l1l1ll111ll1_l1_(l1llll11llll_l1_)
		l1lll1ll11ll_l1_ = l1l1ll111ll1_l1_(l1l11l11111_l1_)
		if l1lll1ll11ll_l1_>l111l111ll1_l1_:
			status = l1l111_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ㒴")
	return status,l1111lll1ll_l1_
def l1lllllllll1_l1_(l1ll1ll11l1_l1_,l1lll1l1ll11_l1_):
	succeeded,l1111l1l111_l1_,l11ll11l1ll_l1_ = True,False,False
	type,name,l1l1l111lll_l1_,mode,l1l1l1l1l1l_l1_,l1l1111ll1l_l1_,text,context,l1llll11l11_l1_ = l1ll1ll11l1_l1_
	l1l1llll1111_l1_ = type,name,l1l1l111lll_l1_,mode,l1l1l1l1l1l_l1_,l1l1111ll1l_l1_,text,l1l111_l1_ (u"ࠫࠬ㒵"),l1llll11l11_l1_
	l1ll1l1ll11l_l1_ = int(mode)
	l1ll1l1ll111_l1_ = int(l1ll1l1ll11l_l1_%10)
	l1ll1l1ll1l1_l1_ = int(l1ll1l1ll11l_l1_/10)
	l1l1ll11ll11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡲࡺࡹ࡟ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭㒶"))
	l1111l1llll_l1_,l1111lll1ll_l1_ = l1ll1lll1l1l_l1_()
	if l1111lll1ll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㒷"),l1l111_l1_ (u"ࠧࠨ㒸"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㒹"),l1l111_l1_ (u"ࠩอ้ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦแ๋ࠢฯ๋ฬุใ࡝ࡰศ่๎ࠦวๅวุำฬืࠠาไ่࠾ࡡࡴ࡜࡯ࠩ㒺")+l1l11l11111_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㒻"),l1l111_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㒼"))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㒽"),l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ㒾"))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㒿"),l1l111_l1_ (u"ࠨࡃࡘࡘࡍ࠭㓀"))
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㓁"),l1l111_l1_ (u"ࠪࡍࡉ࡙ࠧ㓂"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧ㓃"),l1l111_l1_ (u"ࠬ࠭㓄"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡱࡶࡸࡦ࠭㓅"),l1l111_l1_ (u"ࠧࠨ㓆"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡧࡸࡡ࡬ࡣࠪ㓇"),l1l111_l1_ (u"ࠩࠪ㓈"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭㓉"),l1l111_l1_ (u"ࠫࠬ㓊"))
		settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㓋"),l1l111_l1_ (u"࠭ࠧ㓌"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㓍"),l1l111_l1_ (u"ࠨࠩ㓎"))
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡻࡳࡦࡴ࠱ࡴࡷ࡯ࡶࡴࠩ㓏"),l1l111_l1_ (u"ࠪࠫ㓐"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠭㓑"),l1l111_l1_ (u"ࠬ࠭㓒"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ㓓"),l1l111_l1_ (u"ࠧࠨ㓔"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡰࡰࡵ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠭㓕"),l1l111_l1_ (u"ࠩࠪ㓖"))
		import l1l11lll11l_l1_
		if l1111l1llll_l1_==l1l111_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ㓗"):
			l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㓘"),l1l111_l1_ (u"ࠬ࠴ࠠࠡࡃࡵࡥࡧ࡯ࡣࡗ࡫ࡧࡩࡴࡹࠠࡖࡲࡧࡥࡹ࡫ࠠࡕࡻࡳࡩ࠿ࠦࠠࡔࡋࡐࡔࡑࡋࠠࡖࡒࡇࡅ࡙ࡋࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫ㓙")+addon_path+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㓚"))
			l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ㓛"))
			l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ㓜"))
			l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࠨ㓝"))
		else:
			l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㓞"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ㓟")+addon_path+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㓠"))
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㓡"),l1l111_l1_ (u"ࠧࠨ㓢"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㓣"),l1l111_l1_ (u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬ㓤"))
			l11l1l1ll11_l1_()
			FIX_ALL_DATABASES(False)
			l1l11lll11l_l1_.l1ll111ll1ll_l1_()
			l1l11lll11l_l1_.l1l1l1l11l1_l1_(l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ㓥"),False)
			l1l11lll11l_l1_.l1l1l1l11l1_l1_(l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ㓦"),False)
			l1l11lll11l_l1_.l1lllll1llll_l1_(False)
			l1l11lll11l_l1_.l1ll111l1l11_l1_(False)
			l1l11lll11l_l1_.l111l1l11l1_l1_(l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㓧"),l1l111_l1_ (u"࠭ࡥ࡯ࡣࡥࡰࡪ࠭㓨"),False)
			try:
				l1l1lll111ll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㓩"),l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ㓪"),l1l111_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭㓫"),l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㓬"))
				l11111l11ll_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ㓭"))
				l11111l11ll_l1_.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡣࡸࡸࡴࡥࡰࡪࡥ࡮ࠫ㓮"),l1l111_l1_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ㓯"))
			except: pass
			try:
				l1l1lll111ll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㓰"),l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ㓱"),l1l111_l1_ (u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡱ࠭㓲"),l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㓳"))
				l11111l11ll_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪ࡬ࠨ㓴"))
				l11111l11ll_l1_.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡸ࡬ࡨࡪࡵ࡟ࡲࡷࡤࡰ࡮ࡺࡹࠨ㓵"),l1l111_l1_ (u"࠭࠳ࠨ㓶"))
			except: pass
			try:
				l1l1lll111ll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ㓷"),l1l111_l1_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬ㓸"),l1l111_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㓹"),l1l111_l1_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩ㓺"))
				l11111l11ll_l1_ = xbmcaddon.Addon(id=l1l111_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ㓻"))
				l11111l11ll_l1_.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡕࡗࡖࡊࡇࡍࡔࡇࡏࡉࡈ࡚ࡉࡐࡐࠪ㓼"),l1l111_l1_ (u"࠭࠲ࠨ㓽"))
			except: pass
		data = FIX_AND_GET_FILE_CONTENTS(l1l11llll1l_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l1ll111lll_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ㓾"),l1l11l11111_l1_)
		l1l11lll11l_l1_.l11ll1l11ll_l1_(False)
	l1ll11lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㓿"))
	l1l111l1ll_l1_ = l11lll11111_l1_(l1lll1l1ll11_l1_)
	l1l11ll111l_l1_ = l11lll11111_l1_(name)
	l11111111l1_l1_ = [0,15,17,19,26,34,50,53]
	l1ll1lllll1l_l1_ = [0,15,17,19,26,34,50,53]
	l11llll111l_l1_ = l1ll1l1ll1l1_l1_ not in l1ll1lllll1l_l1_
	l1l1ll11llll_l1_ = l1ll1l1ll1l1_l1_ in [23,28,71,72]
	l1lll1l11ll1_l1_ = l1ll1l1ll11l_l1_ in [265,270]
	l1llll1llll1_l1_ = (l11llll111l_l1_ or l1l1ll11llll_l1_) and not l1lll1l11ll1_l1_
	l11l1l1l111_l1_ = l1ll11lll1_l1_!=l1l111_l1_ (u"ࠩࡕࡉࡋࡘࡅࡔࡊࡈࡈࠬ㔀") and (l1ll11lll1_l1_!=l1l111_l1_ (u"ࠪࠫ㔁") or context==l1l111_l1_ (u"ࠫࠬ㔂"))
	l1ll1l1llll1_l1_ = l1l111_l1_ (u"ࠬࡺࡹࡱࡧࡀࠫ㔃") in l1ll11lll1_l1_
	l1ll111l1ll1_l1_ = l1ll1l1ll11l_l1_ in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	l1lll1_l1_ = l1ll1l1ll111_l1_==9 or l1ll1l1ll11l_l1_ in [145,516,523,45]
	l11ll1lllll_l1_ = not l1ll111l1ll1_l1_
	l11l11l1ll1_l1_ = not l1lll1_l1_
	l1lll1ll111l_l1_ = l1l111l1ll_l1_ in [l1l111_l1_ (u"࠭ࠧ㔄"),l1l111_l1_ (u"ࠧ࠯࠰ࠪ㔅")]
	l111l1111ll_l1_ = l1lll1ll111l_l1_ or l11ll1lllll_l1_
	l1111111l1l_l1_ = l1lll1ll111l_l1_ or l11l11l1ll1_l1_ or l1ll1l1llll1_l1_
	l1l1llll11ll_l1_ = l1ll1l1ll11l_l1_ not in [260,265,270,330,540]
	if l1l1ll11ll11_l1_: l111l111111_l1_ = l1lll1_l1_ or l1ll111l1ll1_l1_
	else: l111l111111_l1_ = True
	l1ll1lllll_l1_ = l1ll1l1ll1l1_l1_ in [74,75]
	l11ll1l1l1l_l1_ = l1ll1l1ll11l_l1_ in [280,720]
	l111l11llll_l1_ = not l1ll1lllll_l1_ and not l11ll1l1l1l_l1_
	l1l1ll1l11l1_l1_ = l111l1111ll_l1_ and l1111111l1l_l1_ and l1l1llll11ll_l1_ and l111l111111_l1_ and l111l11llll_l1_
	l11l11l1111_l1_ = l1l1llll11ll_l1_ and l111l111111_l1_ and l111l11llll_l1_
	l11l1ll1l1l_l1_ = l11l11l1111_l1_
	l1l11111ll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡰࡳࡱࡹ࡭ࡩ࡫ࡲࠨ㔆"))
	l111ll111l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡤࡱࡧࡩࠬ㔇"))
	if 1 and l11l1l1l111_l1_ and l1l1ll1l11l1_l1_:
		l1llll1l1lll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㔈"),l1l111_l1_ (u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ㔉")+l1l11111ll1_l1_+l1l111_l1_ (u"ࠬࡥࠧ㔊")+l111ll111l1_l1_,l1l1llll1111_l1_)
		if l1llll1l1lll_l1_:
			l11lllll1l_l1_(l1l111_l1_ (u"࠭ࠧ㔋"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㔌")+l1l11111ll1_l1_+l1l111_l1_ (u"ࠨࡡࠪ㔍")+l111ll111l1_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦ࡭ࡦࡰࡸࠤ࡫ࡸ࡯࡮ࠢࡦࡥࡨ࡮ࡥࠨ㔎"))
			if 1 and l1ll1l1llll1_l1_:
				l11ll1l1lll_l1_ = []
				from l1ll1111111l_l1_ import l1llll1l1l11_l1_
				from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
				l1lll1l1lll1_l1_ = l1llll1l1l11_l1_
				l11ll1l1111_l1_ = GET_ALL_FAVORITES()
				l11111lll1l_l1_ = l1ll11lll1_l1_
				l11l111ll1l_l1_,l11l11ll1l1_l1_,l1lll1l11lll_l1_,l1ll1l1l11l1_l1_,l11l1lll11l_l1_,l1lllllll1l1_l1_,l11l11ll1ll_l1_,l1lll1111ll1_l1_,l1llllll1ll1_l1_ = EXTRACT_KODI_PATH(l11111lll1l_l1_)
				l1lll1ll1111_l1_ = l11l111ll1l_l1_,l11l11ll1l1_l1_,l1lll1l11lll_l1_,l1ll1l1l11l1_l1_,l11l1lll11l_l1_,l1lllllll1l1_l1_,l11l11ll1ll_l1_,l1l111_l1_ (u"ࠪࠫ㔏"),l1llllll1ll1_l1_
				for l1l11111lll_l1_ in l1llll1l1lll_l1_:
					l1ll11ll11l1_l1_ = l1l11111lll_l1_[l1l111_l1_ (u"ࠫࡲ࡫࡮ࡶࡋࡷࡩࡲ࠭㔐")]
					if l1ll11ll11l1_l1_==l1lll1ll1111_l1_ or l1l11111lll_l1_[l1l111_l1_ (u"ࠬࡳ࡯ࡥࡧࠪ㔑")] in [265,270]:
						l1l11111lll_l1_ = GET_LIST_ITEM(l1ll11ll11l1_l1_,l1lll1l1lll1_l1_,l11ll1l1111_l1_)
						if l1l11111lll_l1_[l1l111_l1_ (u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࠩ㔒")]:
							l1ll1l11l11l_l1_ = GET_FAVORITES_CONTEXT_MENU(l11ll1l1111_l1_,l1ll11ll11l1_l1_,l1l11111lll_l1_[l1l111_l1_ (u"ࠧ࡯ࡧࡺࡴࡦࡺࡨࠨ㔓")])
							l1l11111lll_l1_[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ㔔")] = l1ll1l11l11l_l1_+l1l11111lll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ㔕")]
					l11ll1l1lll_l1_.append(l1l11111lll_l1_)
				settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㔖"),l1l111_l1_ (u"ࠫࠬ㔗"))
				if type==l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔘"): l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ㔙")+l1l11111ll1_l1_+l1l111_l1_ (u"ࠧࡠࠩ㔚")+l111ll111l1_l1_,l1l1llll1111_l1_,l11ll1l1lll_l1_,l11l1l1_l1_)
			else: l11ll1l1lll_l1_ = l1llll1l1lll_l1_
			if type==l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔛") and l1l111l1ll_l1_!=l1l111_l1_ (u"ࠩ࠱࠲ࠬ㔜") and l1llll1llll1_l1_: l1l1l1l111l_l1_()
			l11l1l11l11_l1_ = CREATE_KODI_MENU(l1l1llll1111_l1_,l11ll1l1lll_l1_,succeeded,l1111l1l111_l1_,l11ll11l1ll_l1_)
			return
	elif type==l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㔝") and l1ll11lll1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㔞") and l11l11l1111_l1_:
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ㔟")+l1l11111ll1_l1_+l1l111_l1_ (u"࠭࡟ࠨ㔠")+l111ll111l1_l1_,l1l1llll1111_l1_)
	if l1l111_l1_ (u"ࠧࡠࠩ㔡") in context: l1lll111111l_l1_,l1l1lllll111_l1_ = context.split(l1l111_l1_ (u"ࠨࡡࠪ㔢"),1)
	else: l1lll111111l_l1_,l1l1lllll111_l1_ = context,l1l111_l1_ (u"ࠩࠪ㔣")
	if l1lll111111l_l1_ in [l1l111_l1_ (u"ࠪ࠵ࠬ㔤"),l1l111_l1_ (u"ࠫ࠷࠭㔥"),l1l111_l1_ (u"ࠬ࠹ࠧ㔦"),l1l111_l1_ (u"࠭࠴ࠨ㔧"),l1l111_l1_ (u"ࠧ࠶ࠩ㔨")] and l1l1lllll111_l1_:
		from FAVORITES import FAVORITES_DISPATCHER
		FAVORITES_DISPATCHER(context)
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ㔩"),addon_path)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭㔪"))
		return
	elif l1lll111111l_l1_==l1l111_l1_ (u"ࠪ࠺ࠬ㔫"):
		if l1l1lllll111_l1_==l1l111_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭㔬"): l1ll1lll_l1_(l1l111_l1_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬ㔭"),l1l111_l1_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭㔮"))
		elif l1l1lllll111_l1_==l1l111_l1_ (u"ࠧࡅࡇࡏࡉ࡙ࡋࠧ㔯"): l1ll1l1ll11l_l1_ = 334
		l1lll_l1_ = l1ll11ll1l1l_l1_(type,l1l11ll111l_l1_,l1l1l111lll_l1_,l1ll1l1ll11l_l1_,l1l1l1l1l1l_l1_,l1l1111ll1l_l1_,text,context,l1llll11l11_l1_)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㔰"))
		return
	elif context==l1l111_l1_ (u"ࠩ࠺ࠫ㔱"):
		from l1lllllll1l_l1_ import l1ll1l1llll_l1_
		l1ll1l1llll_l1_()
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ㔲"))
		return
	elif context==l1l111_l1_ (u"ࠫ࠽࠭㔳"):
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ㔴")+addon_id+l1l111_l1_ (u"࠭࠿࡮ࡱࡧࡩࡂ࠭㔵")+str(mode)+l1l111_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷ࠯ࠧ㔶"))
		return
	elif context==l1l111_l1_ (u"ࠨ࠻ࠪ㔷"):
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㔸"),l1l111_l1_ (u"ࠪࡖࡊࡗࡕࡆࡕࡗࡉࡉ࠭㔹"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㔺"))
		return
	if settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ㔻")) not in [l1l111_l1_ (u"࠭ࡁࡖࡖࡒࠫ㔼"),l1l111_l1_ (u"ࠧࡔࡖࡒࡔࠬ㔽"),l1l111_l1_ (u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ㔾")]: settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ㔿"),l1l111_l1_ (u"ࠪࡅ࡚࡚ࡏࠨ㕀"))
	if not settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ㕁")): settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ㕂"),l11111l1l1l_l1_[0])
	l1l1ll1lll11_l1_ = False if l1l11l1ll1l_l1_(l1l111_l1_ (u"࠭ࡏࡕ࠳࠼ࡎ࡚࠶ࡸࡃࡖࡘࡰࡉ࡞ࠧ㕃")) else True
	l11llll1l1l_l1_ = l111l11l_l1_ if l1l1ll1lll11_l1_ else l11l1l1_l1_
	l11lll111l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ㕄"))
	l1l1llll1l11_l1_ = l1llllllll1l_l1_(settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㕅")))
	l1l1llll1l11_l1_ = 0 if not l1l1llll1l11_l1_ else int(l1l1llll1l11_l1_)
	if l11lll111l1_l1_ in [l1l111_l1_ (u"ࠩࠪ㕆"),l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㕇")] or not l11llll1l1l_l1_ or not l1l1llll1l11_l1_ or now-l1l1llll1l11_l1_<0 or now-l1l1llll1l11_l1_>l11llll1l1l_l1_:
		l11lll111l1_l1_ = l111111l111_l1_(True,False)
	l11lll1ll1l_l1_ = l1llllllll1l_l1_(settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡪࡰࡩࡳࡸ࠴ࡰࡦࡴ࡬ࡳࡩ࠭㕈")))
	l11lll1ll1l_l1_ = 0 if not l11lll1ll1l_l1_ else int(l11lll1ll1l_l1_)
	l11l11l1lll_l1_ = l1llllllll1l_l1_(settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱࠧ㕉")))
	l11l11l1lll_l1_ = 0 if not l11l11l1lll_l1_ else int(l11l11l1lll_l1_)
	if not l11lll1ll1l_l1_ or not l11l11l1lll_l1_ or now-l11l11l1lll_l1_<0 or now-l11l11l1lll_l1_>l11lll1ll1l_l1_:
		l1ll1l111l1l_l1_ = 1
		if l1l1ll1lll11_l1_:
			l1ll11ll1l11_l1_ = l11lll1l11l_l1_(True)
			if len(l1ll11ll1l11_l1_)>1:
				l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㕊"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ㕋")+addon_path+l1l111_l1_ (u"ࠨࠢࡠࠫ㕌"))
				id,l1l1ll111l11_l1_,l1l1lll1l11l_l1_,l11l111111l_l1_,l111llll1l1_l1_,reason = l1ll11ll1l11_l1_[0]
				l11111ll1ll_l1_,l11111lll11_l1_ = l11l111111l_l1_.split(l1l111_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ㕍"))
				del l1ll11ll1l11_l1_[0]
				l1ll1l1ll1ll_l1_ = random.sample(l1ll11ll1l11_l1_,1)
				id,l1l1ll111l11_l1_,l1l1lll1l11l_l1_,l11l111111l_l1_,l111llll1l1_l1_,reason = l1ll1l1ll1ll_l1_[0]
				l1l1lll1l11l_l1_ = l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠤ࠿ࠦࠧ㕎")+id+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㕏")+l1l1lll1l11l_l1_
				l111llll1l1_l1_ = l1l111_l1_ (u"ࠬหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠪ㕐")
				l1lllll1l1ll_l1_ = l1l111_l1_ (u"࠭วๅฬหี฾อสࠨ㕑")
				l1111llllll_l1_,l1ll11l11111_l1_ = l11l111111l_l1_,l111llll1l1_l1_
				l111llll_l1_ = [l1111llllll_l1_,l1ll11l11111_l1_,l1lllll1l1ll_l1_]
				l111ll1ll1l_l1_ = 5 if l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨ㕒")) else 5
				l111ll1lll1_l1_ = -9
				while l111ll1lll1_l1_<0:
					l11l11llll1_l1_ = random.sample(l111llll_l1_,3)
					l111ll1lll1_l1_ = l1l1ll1l11ll_l1_(l1l111_l1_ (u"ࠨࠩ㕓"),l11l11llll1_l1_[0],l11l11llll1_l1_[1],l11l11llll1_l1_[2],l11111ll1ll_l1_,l1l1lll1l11l_l1_,l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ㕔"),l111ll1ll1l_l1_,60)
					if l111ll1lll1_l1_==10: break
					from l1l11lll11l_l1_ import l1ll1ll1l11l_l1_,l1l1l11l11l_l1_
					if l111ll1lll1_l1_>=0 and l11l11llll1_l1_[l111ll1lll1_l1_]==l111llll_l1_[1]:
						l1ll1ll1l11l_l1_()
						if l111ll1lll1_l1_>=0: l111ll1lll1_l1_ = -9
					elif l111ll1lll1_l1_>=0 and l11l11llll1_l1_[l111ll1lll1_l1_]==l111llll_l1_[2]:
						l1l1l11l11l_l1_(False)
					if l111ll1lll1_l1_==-1: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㕕"),l1l111_l1_ (u"ࠫࠬ㕖"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㕗"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ะิ์ัࠦฮุล࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࠦไๅะิ์ัࠦวๅืะ๎าࠦรฯฬิࠤํออะ่๊ࠢࠥอไฤฮ๋ฬฮࠦวๅ็อ์ๆืษࠨ㕘"))
				l1ll1l111l1l_l1_ = 1
			else: l1ll1l111l1l_l1_ = 0
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬ࠩ㕙"),l1ll1ll1ll11_l1_(now))
		l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㕚"),l1l111_l1_ (u"ࠩࡄ࡙࡙ࡎࠧ㕛"),l1ll1l111l1l_l1_,l1l1lll1l1l_l1_)
	l1lll_l1_ = l1ll11ll1l1l_l1_(type,l1l11ll111l_l1_,l1l1l111lll_l1_,mode,l1l1l1l1l1l_l1_,l1l1111ll1l_l1_,text,context,l1llll11l11_l1_)
	if l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㕜") in text: l1111l1l111_l1_ = True
	if type==l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕝"):
		if l1l111l1ll_l1_!=l1l111_l1_ (u"ࠬ࠴࠮ࠨ㕞") and l1llll1llll1_l1_: l1l1l1l111l_l1_()
		if addon_handle>-1:
			if (l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡩ࡯ࡶࠪ㕟"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ㕠"),l1l111_l1_ (u"ࠨࡃࡘࡘࡍ࠭㕡")) or l1ll1l1ll11l_l1_ not in l11111111l1_l1_) and not l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠩࡆࡘࡊ࠿ࡄࡔ࠳࠼࡚࡚࠶ࡖࡔ࡚ࠪ㕢")):
				from l1ll1111111l_l1_ import l1llll1l1l11_l1_
				l1llll1l1lll_l1_ = GET_ALL_LIST_ITEMS(l1llll1l1l11_l1_)
				l11l1l11l11_l1_ = CREATE_KODI_MENU(l1l1llll1111_l1_,l1llll1l1lll_l1_,succeeded,l1111l1l111_l1_,l11ll11l1ll_l1_)
				if 1 and l1llll1l1lll_l1_ and l11l1ll1l1l_l1_:
					l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩ㕣")+l1l11111ll1_l1_+l1l111_l1_ (u"ࠫࡤ࠭㕤")+l111ll111l1_l1_,l1l1llll1111_l1_,l1llll1l1lll_l1_,l11l1l1_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ㕥")+addon_id+l1l111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭㕦"),xbmcgui.ListItem(l1l111_l1_ (u"ࠧๅัํ็๋ࠥิไๆฬࠤ๊์ࠠอ้สึ่࠭㕧")))
				xbmcplugin.addDirectoryItem(addon_handle,l1l111_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ㕨")+addon_id+l1l111_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩ㕩"),xbmcgui.ListItem(l1l111_l1_ (u"ࠪวๆะอࠡๆอๆึษࠠศๆอๅฬ฻๊ๅࠩ㕪")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111l1l111_l1_,l11ll11l1ll_l1_)
	return
def l1ll11ll1l1l_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_):
	l1ll1l1ll11l_l1_ = int(mode)
	l1ll1l1ll1l1_l1_ = int(l1ll1l1ll11l_l1_//10)
	if   l1ll1l1ll1l1_l1_==0:  from l1l11lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,text)
	elif l1ll1l1ll1l1_l1_==1:  from l1111l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==2:  from l1ll1l111l1_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==3:  from l11l111l11l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==4:  from l1ll11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1l1ll1l1_l1_==5:  from l11lll1l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==6:  from l1lll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==7:  from l11l111_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==8:  from l1ll1l111ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==9:  from l11111lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==10: from l1lll1l1l1ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url)
	elif l1ll1l1ll1l1_l1_==11: from l1ll11l11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==12: from l111ll1ll1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==13: from l1ll1l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==14: from l11ll1ll1l1_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_,name,l11l_l1_)
	elif l1ll1l1ll1l1_l1_==15: from l1l11lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,text)
	elif l1ll1l1ll1l1_l1_==16: from l1ll111l1ll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,l1llllll1_l1_,l1llll11l11_l1_)
	elif l1ll1l1ll1l1_l1_==17: from l1l11lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,text)
	elif l1ll1l1ll1l1_l1_==18: from l1l1ll1l1lll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==19: from l1l11lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,text)
	elif l1ll1l1ll1l1_l1_==20: from l11llllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==21: from l111ll1ll11_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==22: from l1111l1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==23: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_,l1llll11l11_l1_)
	elif l1ll1l1ll1l1_l1_==24: from l1ll1l1l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==25: from l1l11l111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==26: from l1ll1111111l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==27: from FAVORITES 		import MAINn	; l1lll_l1_ = MAINn(l1ll1l1ll11l_l1_,context)
	elif l1ll1l1ll1l1_l1_==28: from IPTV 			import MAINn	; l1lll_l1_ = MAINn(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_,l1llll11l11_l1_)
	elif l1ll1l1ll1l1_l1_==29: from l11ll111111_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==30: from l111111l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==31: from l11l11l111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==32: from l1ll111l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==33: from l1l11l1111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url)
	elif l1ll1l1ll1l1_l1_==34: from l1l11lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,text)
	elif l1ll1l1ll1l1_l1_==35: from l1l1111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==36: from l1lll11l111l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==37: from l11l1ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==38: from l1ll1l1l11ll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==39: from l1lll1ll11l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==40: from l1l1l11ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1l1ll1l1_l1_==41: from l1l1l11ll1_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_)
	elif l1ll1l1ll1l1_l1_==42: from l11l111ll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==43: from l11111ll1l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==44: from l11111lll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==45: from l11lllll1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==46: from l1111111l11_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==47: from l11111l11_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==48: from l1ll1111l111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==49: from l1111l1l1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==50: from l1l11lll11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,text)
	elif l1ll1l1ll1l1_l1_==51: from l1lllllll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==52: from l1lllllll11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==53: from l1ll1111111l_l1_ 			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==54: from l1lllllll1l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,l1llllll1_l1_)
	elif l1ll1l1ll1l1_l1_==55: from l111l1l11_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==56: from l1ll11l1llll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==57: from l1lll1l1l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==58: from l11ll11lll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==59: from l1lll1l1111_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==60: from l1lll11lll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==61: from l1l1ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==62: from l1lll1lll1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==63: from l1111l1ll_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==64: from l1111l11lll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==65: from l11l11ll1_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==66: from l11lll1111l_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==67: from l1ll1111ll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==68: from l11l1l111l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==69: from l11l11l1l_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==70: from l1l1lll1lll_l1_			import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==71: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_,l1llll11l11_l1_)
	elif l1ll1l1ll1l1_l1_==72: from M3U			import MAINn	; l1lll_l1_ = MAINn(l1ll1l1ll11l_l1_,url,text,type,l1llllll1_l1_,l1llll11l11_l1_)
	elif l1ll1l1ll1l1_l1_==73: from l1ll1111l_l1_	import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	elif l1ll1l1ll1l1_l1_==74: from l1ll1lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_)
	elif l1ll1l1ll1l1_l1_==75: from l1ll1lllll_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_)
	elif l1ll1l1ll1l1_l1_==76: from l1ll111l1ll1_l1_		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text,l1llllll1_l1_,l1llll11l11_l1_)
	elif l1ll1l1ll1l1_l1_==77: from l111l11lll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==78: from l1111lllll_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==79: from l1111lll1l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==80: from l1111ll111_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,l1llllll1_l1_,text)
	elif l1ll1l1ll1l1_l1_==81: from l1ll111l11l_l1_ 		import l11l1ll_l1_	; l1lll_l1_ = l11l1ll_l1_(l1ll1l1ll11l_l1_,url,text)
	else: l1lll_l1_ = None
	return l1lll_l1_
def l1l111111l_l1_(name=l1l111_l1_ (u"ࠫࠬ㕫")):
	if not name: name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭㕬"))
	name = name.replace(l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㕭"),l1l111_l1_ (u"ࠧࠨ㕮"))
	name = name.replace(l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭㕯"),l1l111_l1_ (u"ࠩࠣࠫ㕰")).replace(l1l111_l1_ (u"ࠪࠤࠥࠦࠧ㕱"),l1l111_l1_ (u"ࠫࠥ࠭㕲")).replace(l1l111_l1_ (u"ࠬࠦࠠࠨ㕳"),l1l111_l1_ (u"࠭ࠠࠨ㕴")).strip(l1l111_l1_ (u"ࠧࠡࠩ㕵"))
	name = name.replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㕶"),l1l111_l1_ (u"ࠩࠪ㕷")).replace(l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭㕸"),l1l111_l1_ (u"ࠫࠬ㕹"))
	tmp = re.findall(l1l111_l1_ (u"ࠬࡢࡤ࡝ࡦ࠽ࡠࡩࡢࡤࠡࠩ㕺"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l1l111_l1_ (u"࠭ࡍࡢ࡫ࡱࠤࡒ࡫࡮ࡶࠩ㕻")
	return name
def l1llll1l1l1l_l1_(code,reason,source,l11_l1_):
	l1llllll1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ㕼"))
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ㕽"),l1l111_l1_ (u"ࠩࠪ㕾"))
	if l1l111_l1_ (u"ࠪ࠱ࠬ㕿") in source: l1ll1ll1ll1_l1_ = source.split(l1l111_l1_ (u"ࠫ࠲࠭㖀"),1)[0]
	else: l1ll1ll1ll1_l1_ = source
	l11l1l11l1l_l1_ = code in [7,11001,11002,10054]
	l1l1ll1l111l_l1_ = reason.lower()
	l1llll111l1l_l1_ = code in [0,104,10061,111]
	l1llll111l11_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㖁") in l1l1ll1l111l_l1_
	l1llll1111ll_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭㖂") in l1l1ll1l111l_l1_
	l1llll1111l1_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ㖃") in l1l1ll1l111l_l1_
	l1llll11111l_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ㖄") in l1l1ll1l111l_l1_
	l1ll111ll1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ㖅"))
	l1ll11111l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㖆"))
	l111111l1ll_l1_ = l1l111_l1_ (u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭㖇")
	l1lllllll1ll_l1_ = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵࠤࠬ㖈")+str(code)+l1l111_l1_ (u"࠭࠺ࠡࠩ㖉")+reason
	l1lllllll1ll_l1_ = l111l11_l1_(l1lllllll1ll_l1_)
	if l1llll111l1l_l1_ or l1llll111l11_l1_ or l1llll1111ll_l1_ or l1llll1111l1_l1_ or l1llll11111l_l1_:
		l111111l1ll_l1_ += l1l111_l1_ (u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧ㖊")
	if l11l1l11l1l_l1_: l111111l1ll_l1_ += l1l111_l1_ (u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨ㖋")
	l1lllllll1ll_l1_ = l1l111_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ㖌")+l1lllllll1ll_l1_+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㖍")
	if l1ll111ll1l1_l1_==l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㖎") or l1ll11111l1l_l1_==l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㖏"):
		l111111l1ll_l1_ += l1l111_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋้ࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡ࠰࠱ࠤศ๋ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣวํࠦฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡมࠤࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㖐")
	l11lll11ll1_l1_ = False
	if l11_l1_ and source not in l1lllll11l11_l1_:
		if l1ll111ll1l1_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㖑") or l1ll11111l1l_l1_==l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㖒"):
			l111ll1lll1_l1_ = l1l1ll1l11ll_l1_(l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㖓"),l1l111_l1_ (u"ࠪาึ๎ฬࠨ㖔"),l1l111_l1_ (u"ࠫสืำศๆࠣีุอไสࠢฦ์ࠥิืฤࠩ㖕"),l1l111_l1_ (u"ࠬหีๅษะࠤฬ๊ๅีๅ็อࠬ㖖"),l1ll1ll1ll1_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࠪ㖗")+TRANSLATE(l1ll1ll1ll1_l1_),l111111l1ll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㖘")+l1lllllll1ll_l1_)
			if l111ll1lll1_l1_==1:
				from l1l11lll11l_l1_ import l1ll1ll1l11l_l1_
				l1ll1ll1l11l_l1_()
			elif l111ll1lll1_l1_==2: l11lll11ll1_l1_ = True
		else: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㖙"),l1l111_l1_ (u"ࠩࠪ㖚"),l1ll1ll1ll1_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠧ㖛")+TRANSLATE(l1ll1ll1ll1_l1_),l111111l1ll_l1_,l1lllllll1ll_l1_)
	settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㖜"),l1llllll1l1l_l1_)
	return l11lll11ll1_l1_
def l11l1l1ll11_l1_(l1l1lllllll1_l1_=False):
	l11111l1111_l1_ = [l1l11llll1l_l1_,favoritesfile,l1l1ll111lll_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1l1lllllll1_l1_ and (filename.startswith(l1l111_l1_ (u"ࠬ࡯ࡰࡵࡸࠪ㖝")) or filename.startswith(l1l111_l1_ (u"࠭࡭࠴ࡷࠪ㖞"))): continue
		if filename.startswith(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࡤ࠭㖟")): continue
		l1llll1ll11l_l1_ = os.path.join(addoncachefolder,filename)
		if l1llll1ll11l_l1_ in l11111l1111_l1_: continue
		try: os.remove(l1llll1ll11l_l1_)
		except: pass
	time.sleep(1)
	return
def l1lll11llll1_l1_(proxy,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l111_l1_=True,l1ll1lll11ll_l1_=True):
	l1ll11l1l1l1_l1_,l1lll11ll1ll_l1_ = proxy.split(l1l111_l1_ (u"ࠨ࠼ࠪ㖠"))
	url = url+l1l111_l1_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࠩ㖡")+proxy
	response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l111_l1_,l1ll1lll11ll_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		l1111111111_l1_(l1l111_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ㖢"))
	return response
def l1ll111111l1_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㖣"),url,l1l111_l1_ (u"ࠬ࠭㖤"),l1l111_l1_ (u"࠭ࠧ㖥"),True,l1l111_l1_ (u"ࠧࠨ㖦"),l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ㖧"),True,False)
	l111l11111l_l1_ = []
	if response.succeeded:
		html = response.content
		l1ll1ll1l1l1_l1_ = re.findall(l1l111_l1_ (u"ࠩࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡨࢀ࠷ࠬ࠴ࡿࡰࡷࠬ㖨"),html)
		if l1ll1ll1l1l1_l1_: html = l1l111_l1_ (u"ࠪࡠࡳ࠭㖩").join(l1ll1ll1l1l1_l1_)
		proxies = html.replace(l1l111_l1_ (u"ࠫࡡࡸࠧ㖪"),l1l111_l1_ (u"ࠬ࠭㖫")).strip(l1l111_l1_ (u"࠭࡜࡯ࠩ㖬")).split(l1l111_l1_ (u"ࠧ࡝ࡰࠪ㖭"))
		l111l11111l_l1_ = []
		for proxy in proxies:
			if proxy.count(l1l111_l1_ (u"ࠨ࠰ࠪ㖮"))==3: l111l11111l_l1_.append(proxy)
	return l111l11111l_l1_
def l11ll11l1l1_l1_(*args):
	l11lll1lll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ㖯")
	l1llll11l1l1_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ㖰")
	l111l1111l1_l1_ = l1ll111111l1_l1_(l1llll11l1l1_l1_)
	l111l11111l_l1_ = l1ll111111l1_l1_(l11lll1lll1_l1_)
	l11lllll1ll_l1_ = l111l1111l1_l1_+l111l11111l_l1_
	l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㖱"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥࡶࡲࡰࡺ࡬ࡩࡸࠦ࡬ࡪࡵࡷࠤࠥࠦ࠱ࡴࡶ࠮࠶ࡳࡪ࠺ࠡ࡝ࠣࠫ㖲")+str(len(l111l1111l1_l1_))+l1l111_l1_ (u"࠭ࠫࠨ㖳")+str(len(l111l11111l_l1_))+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㖴"))
	proxy = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ㖵"))
	response = l1l1ll1l1l1_l1_()
	settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ㖶"),l1l111_l1_ (u"ࠪࠫ㖷"))
	if proxy or l11lllll1ll_l1_:
		id,l1l1111l1ll_l1_ = 0,10
		l111l1l11ll_l1_ = len(l11lllll1ll_l1_)
		l111ll1l111_l1_ = l1l1111l1ll_l1_
		if l111l1l11ll_l1_>l111ll1l111_l1_: counts = l111ll1l111_l1_
		else: counts = l111l1l11ll_l1_
		l11l11lll1l_l1_ = random.sample(l11lllll1ll_l1_,counts)
		if proxy: l11l11lll1l_l1_ = [proxy]+l11l11lll1l_l1_
		threads = l11l1111l1l_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=l1l1111l1ll_l1_ and not threads.l11l11ll11l_l1_:
			if id<counts:
				proxy = l11l11lll1l_l1_[id]
				threads.start_new_thread(id,l1lll11llll1_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㖸"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㖹")+proxy+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㖺"))
		l11l11ll11l_l1_ = threads.l11l11ll11l_l1_
		if l11l11ll11l_l1_:
			l1llll1ll1l1_l1_ = threads.l1llll1ll1l1_l1_
			l1lllllll11l_l1_ = l11l11ll11l_l1_[0]
			response = l1llll1ll1l1_l1_[l1lllllll11l_l1_]
			proxy = l11l11lll1l_l1_[int(l1lllllll11l_l1_)]
			settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ㖻"),proxy)
			if l1lllllll11l_l1_!=0: l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㖼"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ㖽")+proxy+l1l111_l1_ (u"ࠪࠤࡢ࠭㖾"))
			else: l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㖿"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ㗀")+proxy+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㗁"))
	return response
def l1l1lll1ll11_l1_(connection,l1l1ll1ll1ll_l1_):
	l111lllll1l_l1_ = connection.create_connection
	def l1ll11lll11l_l1_(address,*args,**kwargs):
		host,port = address
		l1ll1l1lllll_l1_ = DNS_RESOLVER(host,l1l1ll1ll1ll_l1_)
		if l1ll1l1lllll_l1_: host = l1ll1l1lllll_l1_[0]
		else:
			if l1l1ll1ll1ll_l1_ in l11111l1l1l_l1_: l11111l1l1l_l1_.remove(l1l1ll1ll1ll_l1_)
			if l11111l1l1l_l1_:
				l111l1lll1l_l1_ = l11111l1l1l_l1_[0]
				l1ll1l1lllll_l1_ = DNS_RESOLVER(host,l111l1lll1l_l1_)
				if l1ll1l1lllll_l1_: host = l1ll1l1lllll_l1_[0]
		address = (host,port)
		return l111lllll1l_l1_(address,*args,**kwargs)
	connection.create_connection = l1ll11lll11l_l1_
	return l111lllll1l_l1_
def l1l1ll1l1l1l_l1_(url):
	l11l1l1l11l_l1_,l1111ll1l1l_l1_ = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ㗂"))[2],80
	if l1l111_l1_ (u"ࠨ࠼ࠪ㗃") in l11l1l1l11l_l1_: l11l1l1l11l_l1_,l1111ll1l1l_l1_ = l11l1l1l11l_l1_.split(l1l111_l1_ (u"ࠩ࠽ࠫ㗄"))
	l111lll1l1l_l1_ = l1l111_l1_ (u"ࠪ࠳ࠬ㗅")+l1l111_l1_ (u"ࠫ࠴࠭㗆").join(url.split(l1l111_l1_ (u"ࠬ࠵ࠧ㗇"))[3:])
	request = l1l111_l1_ (u"࠭ࡇࡆࡖࠣࠫ㗈")+l111lll1l1l_l1_+l1l111_l1_ (u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧ㗉")
	request += l1l111_l1_ (u"ࠨࡊࡲࡷࡹࡀࠠࠨ㗊")+l11l1l1l11l_l1_+l1l111_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ㗋")
	request += l1l111_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ㗌")
	from socket import socket,AF_INET,SOCK_STREAM
	try:
		client = socket(AF_INET,SOCK_STREAM)
		client.connect((l11l1l1l11l_l1_,l1111ll1l1l_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l1l111_l1_ (u"ࠫࠬ㗍")
	return html
def l1l111l_l1_(l1ll1ll_l1_,type):
	if l1l111_l1_ (u"ࠬ࠴ࠧ㗎") not in l1ll1ll_l1_: return l1ll1ll_l1_
	l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ㗏")
	l1ll1l1111ll_l1_,l1ll1l1111l1_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧ࠯ࠩ㗐"),1)
	l1ll1l11111l_l1_,l1ll1l111111_l1_ = l1ll1l1111l1_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ㗑"),1)
	server = l1ll1l1111ll_l1_+l1l111_l1_ (u"ࠩ࠱ࠫ㗒")+l1ll1l11111l_l1_
	if type in [l1l111_l1_ (u"ࠪ࡬ࡴࡹࡴࠨ㗓"),l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㗔")] and l1l111_l1_ (u"ࠬ࠵ࠧ㗕") in server: server = server.rsplit(l1l111_l1_ (u"࠭࠯ࠨ㗖"),1)[1]
	if type==l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㗗") and l1l111_l1_ (u"ࠨ࠰ࠪ㗘") in server:
		l1ll1llll1l1_l1_ = server.split(l1l111_l1_ (u"ࠩ࠱ࠫ㗙"))
		l1l1l111l1l_l1_ = len(l1ll1llll1l1_l1_)
		if l1l1l111l1l_l1_<=2 or l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㗚") in server: l1ll1llll1l1_l1_ = l1ll1llll1l1_l1_[0]
		elif l1l1l111l1l_l1_>=3: l1ll1llll1l1_l1_ = l1ll1llll1l1_l1_[1]
		if len(l1ll1llll1l1_l1_)>1: server = l1ll1llll1l1_l1_
	return server
def l111l1l1l11_l1_(l11l1111lll_l1_):
	l11l111l111_l1_ = repr(l11l1111lll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㗛"))).replace(l1l111_l1_ (u"ࠧ࠭ࠢ㗜"),l1l111_l1_ (u"࠭ࠧ㗝"))
	return l11l111l111_l1_
def l1l1lllll11_l1_(string):
	l1l1lll1lll1_l1_ = l1l111_l1_ (u"ࠧࠨ㗞")
	if kodi_version<19: string = string.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㗟"))
	from unicodedata import decomposition
	for l1lllll1l111_l1_ in string:
		if   l1lllll1l111_l1_==l1l111_l1_ (u"ࡷࠪฦࠬ㗠"): l11111111ll_l1_ = l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠵ࠫ㗡")
		elif l1lllll1l111_l1_==l1l111_l1_ (u"ࡹࠬษࠧ㗢"): l11111111ll_l1_ = l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠸࠭㗣")
		elif l1lllll1l111_l1_==l1l111_l1_ (u"ࡻࠧลࠩ㗤"): l11111111ll_l1_ = l1l111_l1_ (u"ࠧ࡝࡞ࡸ࠴࠻࠸࠴ࠨ㗥")
		elif l1lllll1l111_l1_==l1l111_l1_ (u"ࡶࠩศࠫ㗦"): l11111111ll_l1_ = l1l111_l1_ (u"ࠩ࡟ࡠࡺ࠶࠶࠳࠷ࠪ㗧")
		elif l1lllll1l111_l1_==l1l111_l1_ (u"ࡸࠫห࠭㗨"): l11111111ll_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠺ࠬ㗩")
		else:
			l1l1l1llllll_l1_ = decomposition(l1lllll1l111_l1_)
			if l1l111_l1_ (u"ࠬࠦࠧ㗪") in l1l1l1llllll_l1_: l11111111ll_l1_ = l1l111_l1_ (u"࠭࡜࡝ࡷࠪ㗫")+l1l1l1llllll_l1_.split(l1l111_l1_ (u"ࠧࠡࠩ㗬"),1)[1]
			else:
				l11111111ll_l1_ = l1l111_l1_ (u"ࠨ࠲࠳࠴࠵࠭㗭")+hex(ord(l1lllll1l111_l1_)).replace(l1l111_l1_ (u"ࠩ࠳ࡼࠬ㗮"),l1l111_l1_ (u"ࠪࠫ㗯"))
				l11111111ll_l1_ = l1l111_l1_ (u"ࠫࡡࡢࡵࠨ㗰")+l11111111ll_l1_[-4:]
		l1l1lll1lll1_l1_ += l11111111ll_l1_
	l1l1lll1lll1_l1_ = l1l1lll1lll1_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭㗱"),l1l111_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧ㗲"))
	if kodi_version<19: l1l1lll1lll1_l1_ = l1l1lll1lll1_l1_.decode(l1l111_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㗳")).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㗴"))
	else: l1l1lll1lll1_l1_ = l1l1lll1lll1_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㗵")).decode(l1l111_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ㗶"))
	return l1l1lll1lll1_l1_
def l1llll1_l1_(header=l1l111_l1_ (u"้ࠫ๎อสࠢส่๊็วห์ะࠫ㗷"),default=l1l111_l1_ (u"ࠬ࠭㗸"),l111ll11ll1_l1_=False,source=l1l111_l1_ (u"࠭ࠧ㗹")):
	text = l1ll1ll11l11_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l1l111_l1_ (u"ࠧࠡࠢࠪ㗺"),l1l111_l1_ (u"ࠨࠢࠪ㗻")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ㗼"),l1l111_l1_ (u"ࠪࠤࠬ㗽")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ㗾"),l1l111_l1_ (u"ࠬࠦࠧ㗿"))
	if not text and not l111ll11ll1_l1_:
		l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㘀"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡀࠠࠡࠢࠥࠫ㘁")+text+l1l111_l1_ (u"ࠨࠤࠪ㘂"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㘃"),l1l111_l1_ (u"ࠪࠫ㘄"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㘅"),l1l111_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨ㘆"))
		return l1l111_l1_ (u"࠭ࠧ㘇")
	if text not in [l1l111_l1_ (u"ࠧࠨ㘈"),l1l111_l1_ (u"ࠨࠢࠪ㘉")]:
		text = text.strip(l1l111_l1_ (u"ࠩࠣࠫ㘊"))
		text = l1l1lllll11_l1_(text)
	if source!=l1l111_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ㘋") and l11111l_l1_(l1l111_l1_ (u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭㘌"),l1l111_l1_ (u"ࠬ࠭㘍"),[text],False):
		l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㘎"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡏࡪࡿࡢࡰࡣࡵࡨࠥ࡫࡮ࡵࡴࡼࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠿ࠦࠠࠡࠤࠪ㘏")+text+l1l111_l1_ (u"ࠨࠤࠪ㘐"))
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㘑"),l1l111_l1_ (u"ࠪࠫ㘒"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㘓"),l1l111_l1_ (u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧ㘔"))
		return l1l111_l1_ (u"࠭ࠧ㘕")
	l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㘖"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡧ࡬࡭ࡱࡺࡩࡩࡀࠠࠡࠢࠥࠫ㘗")+text+l1l111_l1_ (u"ࠩࠥࠫ㘘"))
	return text
def l1l11l1lll_l1_(l1lllll1_l1_,headers={}):
	url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ㘙")
	if l1l111_l1_ (u"ࠫࢁ࠭㘚") in l1lllll1_l1_:
		url,params = l1lllll1_l1_.split(l1l111_l1_ (u"ࠬࢂࠧ㘛"),1)
		if l1l111_l1_ (u"࠭࠽ࠨ㘜") not in params: url,params = l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ㘝")
	response = l11l1l_l1_(l1lll111l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ㘞"),url,l1l111_l1_ (u"ࠩࠪ㘟"),headers,l1l111_l1_ (u"ࠪࠫ㘠"),l1l111_l1_ (u"ࠫࠬ㘡"),l1l111_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ㘢"),False,False)
	html = response.content
	if l1l111_l1_ (u"࠭ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈࠪ㘣") not in html: return [l1l111_l1_ (u"ࠧ࠮࠳ࠪ㘤")],[l1lllll1_l1_]
	if l1l111_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡁࡖࡆࡌࡓࠬ㘥") in html: return [l1l111_l1_ (u"ࠩ࠰࠵ࠬ㘦")],[l1lllll1_l1_]
	if l1l111_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡘࡌࡈࡊࡕࠧ㘧") in html: return [l1l111_l1_ (u"ࠫ࠲࠷ࠧ㘨")],[l1lllll1_l1_]
	l1l1lll1_l1_,l1llll_l1_,l111l11l1ll_l1_,l1ll1llll111_l1_ = [],[],[],[]
	lines = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࠤࡇ࡛ࡘ࠲࡞࠭ࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉ࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠨࠩࠪ㘩"),html+l1l111_l1_ (u"࠭࡜࡯ࠩ㘪"),re.DOTALL)
	if not lines: return [l1l111_l1_ (u"ࠧ࠮࠳ࠪ㘫")],[l1lllll1_l1_]
	for line,l1ll1ll_l1_ in lines:
		l1l1lll11ll1_l1_,l11ll1111l1_l1_,l111l1ll_l1_ = {},-1,-1
		title = l1l111_l1_ (u"ࠨࠩ㘬")
		items = line.split(l1l111_l1_ (u"ࠩ࠯ࠫ㘭"))
		for item in items:
			if l1l111_l1_ (u"ࠪࡁࠬ㘮") in item:
				key,value = item.split(l1l111_l1_ (u"ࠫࡂ࠭㘯"),1)
				l1l1lll11ll1_l1_[key.lower()] = value
		if l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ㘰") in line.lower():
			l11ll1111l1_l1_ = int(l1l1lll11ll1_l1_[l1l111_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ㘱")])//1024
			title += str(l11ll1111l1_l1_)+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㘲")
		elif l1l111_l1_ (u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ㘳") in line.lower():
			l11ll1111l1_l1_ = int(l1l1lll11ll1_l1_[l1l111_l1_ (u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ㘴")])//1024
			title += str(l11ll1111l1_l1_)+l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ㘵")
		if l1l111_l1_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ㘶") in line.lower():
			l111l1ll_l1_ = int(l1l1lll11ll1_l1_[l1l111_l1_ (u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩ㘷")].split(l1l111_l1_ (u"࠭ࡸࠨ㘸"))[1])
			title += str(l111l1ll_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠪ㘹")
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠣࠫ㘺"))
		if not title: title = l1l111_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠪ㘻")
		if not l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ㘼")):
			if l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠫ࠴࠵ࠧ㘽")): l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠬࡀࠧ㘾"),1)[0]+l1l111_l1_ (u"࠭࠺ࠨ㘿")+l1ll1ll_l1_
			elif l1ll1ll_l1_.startswith(l1l111_l1_ (u"ࠧ࠰ࠩ㙀")): l1ll1ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ㙁"))+l1ll1ll_l1_
			else: l1ll1ll_l1_ = url.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫ㙂"),1)[0]+l1l111_l1_ (u"ࠪ࠳ࠬ㙃")+l1ll1ll_l1_
		if params!=l1l111_l1_ (u"ࠫࠬ㙄"): l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࢂࠧ㙅")+params
		if l1l111_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ㙆") in list(l1l1lll11ll1_l1_.keys()):
			l111lllll_l1_ = l1l1lll11ll1_l1_[l1l111_l1_ (u"ࠧࡱࡴࡲ࡫ࡷ࡫ࡳࡴ࡫ࡹࡩ࠲ࡻࡲࡪࠩ㙇")]
			l111lllll_l1_ = l111lllll_l1_.replace(l1l111_l1_ (u"ࠨࠤࠪ㙈"),l1l111_l1_ (u"ࠩࠪ㙉")).replace(l1l111_l1_ (u"ࠥࠫࠧ㙊"),l1l111_l1_ (u"ࠫࠬ㙋")).split(l1l111_l1_ (u"ࠬࠩࠧ㙌"),1)[0]
			l11l1l11l1_l1_ = l1l1111l11_l1_(l111lllll_l1_)
			if l11l1l11l1_l1_: l1lllllll_l1_ = title+l1l111_l1_ (u"࠭ࠠࠡࠩ㙍")+l11l1l11l1_l1_
			else: l1lllllll_l1_ = title
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠧࠡࠢࡓࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫ࠧ㙎")
			l1lllllll_l1_ = l1lllllll_l1_+l1l111_l1_ (u"ࠨࠢࠣࠫ㙏")+l1l111l_l1_(l111lllll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㙐"))
			l1l1lll1_l1_.append(l1lllllll_l1_)
			l1llll_l1_.append(l111lllll_l1_)
			l111l11l1ll_l1_.append(l111l1ll_l1_)
			l1ll1llll111_l1_.append(l11ll1111l1_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠧࠬ㙑"),1)[0]
		l11l1l11l1_l1_ = l1l1111l11_l1_(l1ll1ll_l1_)
		if l11l1l11l1_l1_: title = title+l1l111_l1_ (u"ࠫࠥࠦࠧ㙒")+l11l1l11l1_l1_
		title = title+l1l111_l1_ (u"ࠬࠦࠠࠨ㙓")+l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㙔"))
		l1l1lll1_l1_.append(title)
		l1llll_l1_.append(l1ll1ll_l1_)
		l111l11l1ll_l1_.append(l111l1ll_l1_)
		l1ll1llll111_l1_.append(l11ll1111l1_l1_)
	zz = list(zip(l1l1lll1_l1_,l1llll_l1_,l111l11l1ll_l1_,l1ll1llll111_l1_))
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1l1lll1_l1_,l1llll_l1_,l111l11l1ll_l1_,l1ll1llll111_l1_ = list(zip(*zz))
	l1l1lll1_l1_,l1llll_l1_ = list(l1l1lll1_l1_),list(l1llll_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def DNS_RESOLVER(host,l1l1ll1ll1ll_l1_=l1l111_l1_ (u"ࠧࠨ㙕")):
	if not l1l1ll1ll1ll_l1_: l1l1ll1ll1ll_l1_ = l11111l1l1l_l1_[0]
	if host.replace(l1l111_l1_ (u"ࠨ࠰ࠪ㙖"),l1l111_l1_ (u"ࠩࠪ㙗")).isdigit(): return [host]
	from struct import pack,unpack_from
	from socket import socket,AF_INET,SOCK_DGRAM
	try:
		l111111lll1_l1_ = pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㙘"), 12049)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㙙"), 256)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠧࡄࡈࠣ㙚"), 1)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠨ࠾ࡉࠤ㙛"), 0)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠢ࠿ࡊࠥ㙜"), 0)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠣࡀࡋࠦ㙝"), 0)
		if kodi_version>18.99: l1llll1l11ll_l1_ = host.split(l1l111_l1_ (u"ࠩ࠱ࠫ㙞"))
		else: l1llll1l11ll_l1_ = host.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㙟")).split(l1l111_l1_ (u"ࠫ࠳࠭㙠"))
		for part in l1llll1l11ll_l1_:
			parts = part.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㙡"))
			l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠨࡂࠣ㙢"), len(part))
			for l1111ll111l_l1_ in part:
				l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠢࡤࠤ㙣"), l1111ll111l_l1_.encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㙤")))
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠤࡅࠦ㙥"), 0)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠥࡂࡍࠨ㙦"), 1)
		l111111lll1_l1_ += pack(l1l111_l1_ (u"ࠦࡃࡎࠢ㙧"), 1)
		sock = socket(AF_INET,SOCK_DGRAM)
		sock.sendto(bytes(l111111lll1_l1_), (l1l1ll1ll1ll_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11l1l111ll_l1_ = unpack_from(l1l111_l1_ (u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨ㙨"), data, 0)
		l111l1ll111_l1_ = l11l1l111ll_l1_[3]
		offset = len(host)+18
		l11l111111l_l1_ = []
		for _ in range(l111l1ll111_l1_):
			l111l11l11l_l1_ = offset
			l1lll1l1l111_l1_ = 1
			l111111l1l1_l1_ = False
			while True:
				l1111ll111l_l1_ = unpack_from(l1l111_l1_ (u"ࠨ࠾ࡃࠤ㙩"), data, l111l11l11l_l1_)[0]
				if l1111ll111l_l1_ == 0:
					l111l11l11l_l1_ += 1
					break
				if l1111ll111l_l1_ >= 192:
					l1111l1l11l_l1_ = unpack_from(l1l111_l1_ (u"ࠢ࠿ࡄࠥ㙪"), data, l111l11l11l_l1_ + 1)[0]
					l111l11l11l_l1_ = ((l1111ll111l_l1_ << 8) + l1111l1l11l_l1_ - 0xc000) - 1
					l111111l1l1_l1_ = True
				l111l11l11l_l1_ += 1
				if l111111l1l1_l1_ == False: l1lll1l1l111_l1_ += 1
			if l111111l1l1_l1_ == True: l1lll1l1l111_l1_ += 1
			offset = offset + l1lll1l1l111_l1_
			l11llll1lll_l1_ = unpack_from(l1l111_l1_ (u"ࠣࡀࡋࡌࡎࡎࠢ㙫"), data, offset)
			offset = offset + 10
			l11l1l11lll_l1_ = l11llll1lll_l1_[0]
			l111111ll11_l1_ = l11llll1lll_l1_[3]
			if l11l1l11lll_l1_ == 1:
				l1111ll11ll_l1_ = unpack_from(l1l111_l1_ (u"ࠤࡁࠦ㙬")+l1l111_l1_ (u"ࠥࡆࠧ㙭")*l111111ll11_l1_, data, offset)
				l1ll1l1lllll_l1_ = l1l111_l1_ (u"ࠫࠬ㙮")
				for l1111ll111l_l1_ in l1111ll11ll_l1_: l1ll1l1lllll_l1_ += str(l1111ll111l_l1_) + l1l111_l1_ (u"ࠬ࠴ࠧ㙯")
				l1ll1l1lllll_l1_ = l1ll1l1lllll_l1_[0:-1]
				l11l111111l_l1_.append(l1ll1l1lllll_l1_)
			if l11l1l11lll_l1_ in [1,2,5,6,15,28]: offset = offset + l111111ll11_l1_
	except: l11l111111l_l1_ = []
	if not l11l111111l_l1_: l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㙰"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈࡓ࡙࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡍࡵࡳࡵ࠼ࠣ࡟ࠥ࠭㙱")+host+l1l111_l1_ (u"ࠨࠢࡠࠫ㙲"))
	return l11l111111l_l1_
def l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,l11_l1_=True):
	if l1111ll_l1_:
		l11l1l1111l_l1_ = [l1l111_l1_ (u"ࠩๆฬฬืࠧ㙳"),l1l111_l1_ (u"ࠪฬฬฺ๊ࠨ㙴"),l1l111_l1_ (u"ࠫࡦࡪࡵ࡭ࡶࠪ㙵"),l1l111_l1_ (u"ࠬࡾࡸࠨ㙶"),l1l111_l1_ (u"࠭ࡳࡦࡺࠪ㙷")]
		if l1ll1_l1_!=l1l111_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭㙸"):
			l11l1l1111l_l1_ += [l1l111_l1_ (u"ࠨࡴ࠽ࠫ㙹"),l1l111_l1_ (u"ࠩࡵ࠱ࠬ㙺"),l1l111_l1_ (u"ࠪ࠱ࡲࡧࠧ㙻")]
			l11l1l1111l_l1_ += [l1l111_l1_ (u"ࠫ࠿ࡸࠧ㙼"),l1l111_l1_ (u"ࠬ࠳ࡲࠨ㙽"),l1l111_l1_ (u"࠭࡭ࡢ࠯ࠪ㙾")]
		for l11111l111_l1_ in l1111ll_l1_:
			if l1l111_l1_ (u"ࠧࡨࡧࡷ࠲ࡵ࡮ࡰࡀࠩ㙿") in l11111l111_l1_: continue
			if l1l111_l1_ (u"ࠨฯ็ๆฮ࠭㚀") in l11111l111_l1_: continue
			l11111l111_l1_ = l11111l111_l1_.lower()
			if kodi_version<19: l11111l111_l1_ = l11111l111_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㚁")).encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㚂"))
			l11111l111_l1_ = l11111l111_l1_.replace(l1l111_l1_ (u"ࠫ࠿࠭㚃"),l1l111_l1_ (u"ࠬ࠭㚄"))
			l111llll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠲࡝࠸࠱࠾ࡣࠫࡽ࠴࡞࠴࠲࠹࡝ࠬࠫࠪ㚅"),l11111l111_l1_,re.DOTALL)
			l1ll1lllll11_l1_ = False
			for digits in l111llll1ll_l1_:
				if len(digits)==2:
					l1ll1lllll11_l1_ = True
					break
			if l1l111_l1_ (u"ࠧ࡯ࡱࡷࠤࡷࡧࡴࡦࡦࠪ㚆") in l11111l111_l1_: continue
			elif l1l111_l1_ (u"ࠨࡷࡱࡶࡦࡺࡥࡥࠩ㚇") in l11111l111_l1_: continue
			elif l1l111_l1_ (u"ࠩ฽๎ึࠦๅึ่ไࠫ㚈") in l11111l111_l1_: continue
			elif l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘࡰ࡛ࡊࡖࡆࡘࡈ࡜ࠬ㚉")): continue
			elif l11111l111_l1_ in [l1l111_l1_ (u"ࠫࡷ࠭㚊")] or l1ll1lllll11_l1_ or any(value in l11111l111_l1_ for value in l11l1l1111l_l1_):
				l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㚋"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㚌")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㚍"))
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㚎"),l1l111_l1_ (u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫ㚏"))
				return True
	return False
def l1111l1_l1_(*args,**kwargs):
	if args:
		l1ll1llll11l_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l1ll1llll11l_l1_: l1ll1llll11l_l1_ = l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㚐")
		if not l11l111l_l1_: l11l111l_l1_ = l1l111_l1_ (u"ࠫฬูสๆำสีࠬ㚑")
		header = args[2]
		text = l1l111_l1_ (u"ࠬࡢ࡮ࠨ㚒").join(args[3:])
	else: l1ll1llll11l_l1_,l11l111l_l1_,header,text = l1l111_l1_ (u"࠭ࠧ㚓"),l1l111_l1_ (u"ࠧࡐࡍࠪ㚔"),l1l111_l1_ (u"ࠨࠩ㚕"),l1l111_l1_ (u"ࠩࠪ㚖")
	l1l1ll1l11ll_l1_(l1ll1llll11l_l1_,l1l111_l1_ (u"ࠪࠫ㚗"),l11l111l_l1_,l1l111_l1_ (u"ࠫࠬ㚘"),header,text,**kwargs)
	return
def l1ll1l111l_l1_(*args,**kwargs):
	l1ll1llll11l_l1_ = args[0]
	l1lll1ll1lll_l1_ = args[1]
	l1lll1l11l11_l1_ = args[2]
	if l1lll1l11l11_l1_ or l1lll1ll1lll_l1_: l1lll1ll1l11_l1_ = True
	else: l1lll1ll1l11_l1_ = False
	header = args[3]
	text = args[4]
	if not l1ll1llll11l_l1_: l1ll1llll11l_l1_ = l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㚙")
	if not l1lll1ll1lll_l1_: l1lll1ll1lll_l1_ = l1l111_l1_ (u"࠭ใๅษࠪ㚚")
	if not l1lll1l11l11_l1_: l1lll1l11l11_l1_ = l1l111_l1_ (u"ࠧ็฻่ࠫ㚛")
	if len(args)>=6: text += l1l111_l1_ (u"ࠨ࡞ࡱࠫ㚜")+args[5]
	if len(args)>=7: text += l1l111_l1_ (u"ࠩ࡟ࡲࠬ㚝")+args[6]
	l111ll1lll1_l1_ = l1l1ll1l11ll_l1_(l1ll1llll11l_l1_,l1lll1ll1lll_l1_,l1l111_l1_ (u"ࠪࠫ㚞"),l1lll1l11l11_l1_,header,text,**kwargs)
	if l111ll1lll1_l1_==-1 and l1lll1ll1l11_l1_: l111ll1lll1_l1_ = -1
	elif l111ll1lll1_l1_==-1 and not l1lll1ll1l11_l1_: l111ll1lll1_l1_ = False
	elif l111ll1lll1_l1_==0: l111ll1lll1_l1_ = False
	elif l111ll1lll1_l1_==2: l111ll1lll1_l1_ = True
	return l111ll1lll1_l1_
def l1ll11ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll1lll_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l1l111_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ㚟") in list(kwargs.keys()): l1l1111111l_l1_ = kwargs[l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࠪ㚠")]
	else: l1l1111111l_l1_ = 1000
	if len(args)>2 and l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࠫ㚡") not in args[2]: profile = args[2]
	else: profile = l1l111_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭㚢")
	l1l1lllll11l_l1_ = l1l1l1l11ll_l1_(l1l111_l1_ (u"ࠨࡆ࡬ࡥࡱࡵࡧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡏ࡭ࡢࡩࡨ࠲ࡽࡳ࡬ࠨ㚣"),l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࠪ㚤"),l1l111_l1_ (u"ࠪ࠻࠷࠶ࡰࠨ㚥"))
	l1lll1111111_l1_,l111lll1111_l1_ = l1lllll1ll11_l1_(l1l111_l1_ (u"ࠫࠬ㚦"),l1l111_l1_ (u"ࠬ࠭㚧"),l1l111_l1_ (u"࠭ࠧ㚨"),header,text,profile,l1l111_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㚩"),720,False)
	l1l1lllll11l_l1_.show()
	if profile==l1l111_l1_ (u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡵࡹࡲ࡬ࡦࡲࡦࡴࠩ㚪"):
		l1l1lllll11l_l1_.getControl(9040).setHeight(215)
		l1l1lllll11l_l1_.getControl(9040).setPosition(55,-80)
		l1l1lllll11l_l1_.getControl(9050).setPosition(120,-60)
		l1l1lllll11l_l1_.getControl(400).setPosition(90,-35)
	l1l1lllll11l_l1_.getControl(401).setVisible(False)
	l1l1lllll11l_l1_.getControl(402).setVisible(False)
	l1l1lllll11l_l1_.getControl(9050).setImage(l1lll1111111_l1_)
	l1l1lllll11l_l1_.getControl(9050).setHeight(l111lll1111_l1_)
	from threading import Thread
	l11lllll111_l1_ = Thread(target=l1l1ll11111l_l1_,args=(l1l1lllll11l_l1_,l1lll1111111_l1_,l1l1111111l_l1_))
	l11lllll111_l1_.start()
	return
def l1l1ll11111l_l1_(l1l1lllll11l_l1_,l1lll1111111_l1_,l1l1111111l_l1_):
	time.sleep(l1l1111111l_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l1lll1111111_l1_):
		try: os.remove(l1lll1111111_l1_)
		except: pass
	return
def l1ll111l1111_l1_(*args,**kwargs):
	header,text,profile,l1ll1llll11l_l1_ = l1l111_l1_ (u"ࠩࠪ㚫"),l1l111_l1_ (u"ࠪࠫ㚬"),l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ㚭"),l1l111_l1_ (u"ࠬࡲࡥࡧࡶࠪ㚮")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: profile = args[2]
	if len(args)>=4: l1ll1llll11l_l1_ = args[3]
	return l1l11ll11l_l1_(l1ll1llll11l_l1_,header,text,profile)
def l11l1lll1l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().l1ll1l111ll1_l1_(*args,**kwargs)
def l11llll1l1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l1ll1ll11l11_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l11l111ll11_l1_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l11ll11l11l_l1_(l1lll11lllll_l1_):
	if kodi_version>17.99: l1l1lllll11l_l1_ = l1l111_l1_ (u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࡱࡳࡨࡧ࡮ࡤࡧ࡯ࠫ㚯")
	else: l1l1lllll11l_l1_ = l1l111_l1_ (u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࠫ㚰")
	l1lll11lllll_l1_ = l1lll11lllll_l1_.lower()
	if l1lll11lllll_l1_==l1l111_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ㚱"): xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹࠫࠫ㚲")+l1l1lllll11l_l1_+l1l111_l1_ (u"ࠪ࠭ࠬ㚳"))
	elif l1lll11lllll_l1_==l1l111_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ㚴"): xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࠬ㚵")+l1l1lllll11l_l1_+l1l111_l1_ (u"࠭ࠩࠨ㚶"))
	return
def l1l1ll1l11ll_l1_(l1ll1llll11l_l1_,l1111llllll_l1_=l1l111_l1_ (u"ࠧࠨ㚷"),l1ll11l11111_l1_=l1l111_l1_ (u"ࠨࠩ㚸"),l111l111l11_l1_=l1l111_l1_ (u"ࠩࠪ㚹"),header=l1l111_l1_ (u"ࠪࠫ㚺"),text=l1l111_l1_ (u"ࠫࠬ㚻"),profile=l1l111_l1_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ㚼"),l1lll1ll11l1_l1_=0,l1ll1l1l1ll1_l1_=0):
	if not l1ll1llll11l_l1_: l1ll1llll11l_l1_ = l1l111_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㚽")
	l1l1lllll11l_l1_ = l1ll11l1lll1_l1_(l1l111_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ㚾"),l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㚿"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㛀"))
	l1l1lllll11l_l1_.l111ll1llll_l1_(l1111llllll_l1_,l1ll11l11111_l1_,l111l111l11_l1_,header,text,profile,l1ll1llll11l_l1_,900,l1lll1ll11l1_l1_,l1ll1l1l1ll1_l1_)
	if l1lll1ll11l1_l1_>0: l1l1lllll11l_l1_.l11llll11ll_l1_()
	if l1ll1l1l1ll1_l1_>0: l1l1lllll11l_l1_.l11ll1ll11l_l1_()
	if l1lll1ll11l1_l1_==0 and l1ll1l1l1ll1_l1_==0: l1l1lllll11l_l1_.l11l11111ll_l1_()
	l1l1lllll11l_l1_.doModal()
	l111ll1lll1_l1_ = l1l1lllll11l_l1_.l11llll1ll1_l1_
	return l111ll1lll1_l1_
def l1l11ll11l_l1_(l1ll1llll11l_l1_,header,text,profile=l1l111_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ㛁")):
	if not l1ll1llll11l_l1_: l1ll1llll11l_l1_ = l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㛂")
	l1l1lllll11l_l1_ = l1l1l1l11ll_l1_(l1l111_l1_ (u"ࠬࡊࡩࡢ࡮ࡲ࡫࡙࡫ࡸࡵࡘ࡬ࡩࡼ࡫ࡲࡇࡷ࡯ࡰࡘࡩࡲࡦࡧࡱ࠲ࡽࡳ࡬ࠨ㛃"),l1l1l11l1ll_l1_,l1l111_l1_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ㛄"),l1l111_l1_ (u"ࠧ࠸࠴࠳ࡴࠬ㛅"))
	l1lll1111111_l1_,l111lll1111_l1_ = l1lllll1ll11_l1_(l1l111_l1_ (u"ࠨࠩ㛆"),l1l111_l1_ (u"ࠩࠪ㛇"),l1l111_l1_ (u"ࠪࠫ㛈"),header,text,profile,l1ll1llll11l_l1_,1270,False)
	l1l1lllll11l_l1_.show()
	l1l1lllll11l_l1_.getControl(9050).setHeight(l111lll1111_l1_)
	l1l1lllll11l_l1_.getControl(9050).setImage(l1lll1111111_l1_)
	result = l1l1lllll11l_l1_.doModal()
	try: os.remove(l1lll1111111_l1_)
	except: pass
	return result
def l1l1ll11l_l1_(l1ll1l11l1l1_l1_=True):
	if l1ll1l11l1l1_l1_:
		l11l1l11ll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡸࡺࡲࠨ㛉"),l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ㛊"),l1l111_l1_ (u"࠭ࡕࡔࡇࡕࡅࡌࡋࡎࡕࠩ㛋"))
		if l11l1l11ll_l1_: return l11l1l11ll_l1_
	text = l1l111_l1_ (u"ࠧࠨ㛌")
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷࡩࡨ࡮ࡢ࡭ࡱࡪ࠲ࡼ࡯࡬࡭ࡵ࡫ࡳࡺࡹࡥ࠯ࡥࡲࡱ࠴࠸࠰࠲࠴࠲࠴࠶࠵࠰࠴࠱ࡰࡳࡸࡺ࠭ࡤࡱࡰࡱࡴࡴ࠭ࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࡷ࠴࠭㛍")
	headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㛎"):url}
	response = l11l1l_l1_(l1ll1ll1lll_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㛏"),url,l1l111_l1_ (u"ࠫࠬ㛐"),headers,l1l111_l1_ (u"ࠬ࠭㛑"),l1l111_l1_ (u"࠭ࠧ㛒"),l1l111_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡄࡒࡉࡕࡍࡠࡗࡖࡉࡗࡇࡇࡆࡐࡗ࠱࠶ࡹࡴࠨ㛓"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l1l111_l1_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢࠩ㛔"))
		if count>80:
			text = re.findall(l1l111_l1_ (u"ࠩࡪࡩࡹ࠳ࡴࡩࡧ࠰ࡰ࡮ࡹࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㛕"),html,re.DOTALL)
			text = text[0]
	if not text:
		l1llll1l11l1_l1_ = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㛖"),l1l111_l1_ (u"ࠫࡺࡹࡥࡳࡣࡪࡩࡳࡺࡳ࠯ࡶࡻࡸࠬ㛗"))
		text = open(l1llll1l11l1_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㛘")).read()
		if kodi_version>18.99: text = text.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㛙"))
		text = text.replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ㛚"),l1l111_l1_ (u"ࠨࠩ㛛"))
	l1lllll11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡑࡴࢀࡩ࡭࡮ࡤ࠲࠯ࡅࠩ࡝ࡰࠪ㛜"),text,re.DOTALL)
	l11ll111ll1_l1_ = []
	for line in l1lllll11l1l_l1_:
		l1lll11lll11_l1_ = line.lower()
		if l1l111_l1_ (u"ࠪࡥࡳࡪࡲࡰ࡫ࡧࠫ㛝") in l1lll11lll11_l1_: continue
		if l1l111_l1_ (u"ࠫࡺࡨࡵ࡯ࡶࡸࠫ㛞") in l1lll11lll11_l1_: continue
		if l1l111_l1_ (u"ࠬ࡯ࡰࡩࡱࡱࡩࠬ㛟") in l1lll11lll11_l1_: continue
		if l1l111_l1_ (u"࠭ࡣࡳࡱࡶࠫ㛠") in l1lll11lll11_l1_: continue
		l11ll111ll1_l1_.append(line)
	l11l1l11ll_l1_ = random.sample(l11ll111ll1_l1_,1)
	l11l1l11ll_l1_ = l11l1l11ll_l1_[0]
	l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㛡"),l1l111_l1_ (u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫ㛢"),l11l1l11ll_l1_,l11l1l1_l1_)
	return l11l1l11ll_l1_
def l11l111llll_l1_(l1111l1l1l1_l1_):
	sys.stderr.write(l1111l1l1l1_l1_)
	lines = l1111l1l1l1_l1_.splitlines()
	error = lines[-1]
	l111l11l1l1_l1_ = open(l1llll11ll11_l1_,l1l111_l1_ (u"ࠩࡵࡦࠬ㛣")).read()
	if kodi_version>18.99: l111l11l1l1_l1_ = l111l11l1l1_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㛤"))
	l111l11l1l1_l1_ = l111l11l1l1_l1_[-8000:]
	sep = l1l111_l1_ (u"ࠫࡂ࠭㛥")*100
	if sep in l111l11l1l1_l1_: l111l11l1l1_l1_ = l111l11l1l1_l1_.rsplit(sep,1)[1]
	if error in l111l11l1l1_l1_: l111l11l1l1_l1_ = l111l11l1l1_l1_.rsplit(error,1)[0]
	l1ll11ll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡓࡰࡷࡵࡧࡪࢂࡍࡰࡦࡨ࠭࠿ࠦ࡜࡜ࠢࠫ࠲࠯ࡅࠩࠡ࡞ࡠࠫ㛦"),l111l11l1l1_l1_,re.DOTALL)
	for typ,source in reversed(l1ll11ll1ll1_l1_):
		if source: break
	else: source = l1l111_l1_ (u"࠭ࡎࡐࡖࠣࡗࡕࡋࡃࡊࡈࡌࡉࡉ࠭㛧")
	file,line,func = l1l111_l1_ (u"ࠧࠨ㛨"),l1l111_l1_ (u"ࠨࠩ㛩"),l1l111_l1_ (u"ࠩࠪ㛪")
	l11l1llll1l_l1_ = l1l111_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ิืฤ࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㛫")+error
	l1ll1l111lll_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅึัิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㛬")+source
	for l1lll1ll1l1l_l1_ in reversed(lines):
		if l1l111_l1_ (u"ࠬࡌࡩ࡭ࡧࠣࠦࠬ㛭") in l1lll1ll1l1l_l1_ and l1l111_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ㛮") in l1lll1ll1l1l_l1_: break
	l1lll1ll1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ࠪࠦࠪ㛯"),l1lll1ll1l1l_l1_,re.DOTALL)
	if l1lll1ll1l1l_l1_:
		file,line,func = l1lll1ll1l1l_l1_[0]
		if l1l111_l1_ (u"ࠨ࠱ࠪ㛰") in file: file = file.rsplit(l1l111_l1_ (u"ࠩ࠲ࠫ㛱"),1)[1]
		else: file = file.rsplit(l1l111_l1_ (u"ࠪࡠࡡ࠭㛲"),1)[1]
		l1l1llll11l1_l1_ = l1l111_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅๅใ࠽ࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㛳")+file
		line2 = l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิูิ࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㛴")+line
		l11llll1l11_l1_ = l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣวๅ็ๆห๋ࡀࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㛵")+func
		l111l11lll1_l1_ = l1l1llll11l1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㛶")+line2+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㛷")+l11llll1l11_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㛸")+l1ll1l111lll_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㛹")+l11l1llll1l_l1_
		l1lll111ll11_l1_ = line2+l1l111_l1_ (u"ࠫࡡࡴࠧ㛺")+l1ll1l111lll_l1_+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㛻")+l11l1llll1l_l1_+l1l111_l1_ (u"࠭࡜࡯ࠩ㛼")+l1l1llll11l1_l1_+l1l111_l1_ (u"ࠧ࡝ࡰࠪ㛽")+l11llll1l11_l1_
		l1llllll1111_l1_ = line2+l1l111_l1_ (u"ࠨ࡞ࡱࠫ㛾")+l11l1llll1l_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㛿")+l1l1llll11l1_l1_+l1l111_l1_ (u"ࠪࡠࡳ࠭㜀")+l11llll1l11_l1_
	else:
		l1l1llll11l1_l1_,line2,l11llll1l11_l1_ = l1l111_l1_ (u"ࠫࠬ㜁"),l1l111_l1_ (u"ࠬ࠭㜂"),l1l111_l1_ (u"࠭ࠧ㜃")
		l111l11lll1_l1_ = l1ll1l111lll_l1_+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㜄")+l11l1llll1l_l1_
		l1lll111ll11_l1_ = l1ll1l111lll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭㜅")+l11l1llll1l_l1_
		l1llllll1111_l1_ = l11l1llll1l_l1_
	l11l111l1l1_l1_ = l1l111_l1_ (u"ࠩะำะࠦฮุลࠣ฾๏ืࠠๆไุ์ิ࠭㜆")+l1l111_l1_ (u"ࠪࡠࡳ࠭㜇")
	l1l1llll1lll_l1_ = l111ll11l1l_l1_()
	l1llll11l111_l1_ = []
	l1lll_l1_ = l1l1llll1lll_l1_[l1l111_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ㜈")]
	l1lll1ll11ll_l1_ = l1l1ll111ll1_l1_(l1l11l11111_l1_)
	if l1l111_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ㜉") in list(l1l1llll1lll_l1_.keys()):
		for l1ll1l11l111_l1_,l1111l1111l_l1_,l11l1llllll_l1_ in l1lll_l1_: l1llll11l111_l1_ = max(l1llll11l111_l1_,l1111l1111l_l1_)
		if l1lll1ll11ll_l1_<l1llll11l111_l1_:
			header = l1l111_l1_ (u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ㜊")
			l111ll1lll1_l1_ = l1l1ll1l11ll_l1_(l1l111_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭㜋"),l1l111_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㜌"),l1l111_l1_ (u"ࠩอัิ๐หࠨ㜍"),l1l111_l1_ (u"ࠪาึ๎ฬࠨ㜎"),l11l111l1l1_l1_+header,l111l11lll1_l1_)
			if l111ll1lll1_l1_==0:
				l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㜏"),l1l111_l1_ (u"ࠬิั้ฮࠪ㜐"),l1l111_l1_ (u"࠭สฮัํฯࠬ㜑"),l1l111_l1_ (u"ࠧࠨ㜒"),header)
				if l1llll1l1l_l1_==1: l111ll1lll1_l1_ = 1
			if l111ll1lll1_l1_==1:
				from l1l11lll11l_l1_ import l1lll1l111ll_l1_
				l1lll1l111ll_l1_()
			return
	l1l1ll111111_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㜓"),l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ㜔"),l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ㜕"))
	if not l1l1ll111111_l1_: l1l1ll111111_l1_ = []
	l1lll111ll11_l1_ = l1lll111ll11_l1_.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ㜖"),l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㜗")).replace(l1l111_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ㜘"),l1l111_l1_ (u"ࠧࠨ㜙")).replace(l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㜚"),l1l111_l1_ (u"ࠩࠪ㜛")).replace(l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㜜"),l1l111_l1_ (u"ࠫࠬ㜝"))
	l1llllll1111_l1_ = l1llllll1111_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㜞"),l1l111_l1_ (u"࠭࡜࡝ࡰࠪ㜟")).replace(l1l111_l1_ (u"ࠧ࡜ࡔࡗࡐࡢ࠭㜠"),l1l111_l1_ (u"ࠨࠩ㜡")).replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㜢"),l1l111_l1_ (u"ࠪࠫ㜣")).replace(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㜤"),l1l111_l1_ (u"ࠬ࠭㜥"))
	l1l1ll1l1111_l1_ = l1l11l11111_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ㜦")+l1llllll1111_l1_
	if l1l1ll1l1111_l1_ in l1l1ll111111_l1_:
		header = l1l111_l1_ (u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ㜧")
		l1111l1_l1_(l1l111_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ㜨"),l1l111_l1_ (u"ࠩࠪ㜩"),l11l111l1l1_l1_+header,l111l11lll1_l1_)
		return
	l1l1ll1ll1l1_l1_ = str(kodi_version).split(l1l111_l1_ (u"ࠪ࠲ࠬ㜪"))[0]
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㜫")][6]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㜬"),url,l1l111_l1_ (u"࠭ࠧ㜭"),l1l111_l1_ (u"ࠧࠨ㜮"),l1l111_l1_ (u"ࠨࠩ㜯"),l1l111_l1_ (u"ࠩࠪ㜰"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭㜱"),False,False)
	html = response.content
	l11ll1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫ㜲"),html,re.DOTALL)
	for l11l1111ll1_l1_,l11l1llll11_l1_,l1llllll1lll_l1_,l1lll111l1ll_l1_ in l11ll1ll111_l1_:
		l11l1111ll1_l1_ = l11l1111ll1_l1_.split(l1l111_l1_ (u"ࠬ࠱ࠧ㜳"))
		l1llllll1lll_l1_ = l1llllll1lll_l1_.split(l1l111_l1_ (u"࠭ࠫࠨ㜴"))
		l1lll111l1ll_l1_ = l1lll111l1ll_l1_.split(l1l111_l1_ (u"ࠧࠬࠩ㜵"))
		if line in l11l1111ll1_l1_ and error==l11l1llll11_l1_ and l1l11l11111_l1_ in l1llllll1lll_l1_ and l1l1ll1ll1l1_l1_ in l1lll111l1ll_l1_:
			header = l1l111_l1_ (u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭㜶")
			l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㜷"),l1l111_l1_ (u"ࠪาึ๎ฬࠨ㜸"),l1l111_l1_ (u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㜹"),l11l111l1l1_l1_+header,l111l11lll1_l1_)
			if l1llll1l1l_l1_==1: l1111l1_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㜺"),l1l111_l1_ (u"࠭ࠧ㜻"),l1l111_l1_ (u"ࠧࠨ㜼"),header)
			return
	header = l1l111_l1_ (u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨ㜽")
	l1111l1_l1_(l1l111_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ㜾"),l1l111_l1_ (u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧ㜿"),l11l111l1l1_l1_+header,l111l11lll1_l1_)
	l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㝀"),l1l111_l1_ (u"้ࠬไศࠩ㝁"),l1l111_l1_ (u"࠭ๆฺ็ࠪ㝂"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㝃"),l1l111_l1_ (u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩ㝄"))
	if l1llll1l1l_l1_==1: l1l1ll1l1l11_l1_ = l1l111_l1_ (u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ㝅")
	else:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㝆"),l1l111_l1_ (u"ࠫࠬ㝇"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㝈"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽ร࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱ่ศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥหีๅษะࠤฬ๊ฮุลࠣฬิ๎ๆࠡีฯ่ࠥอไฤะฺหฦࠦวๅาํࠤ๊้ส้สࠣๅ๏ํࠠอ็ํ฽ࠥะแศืํ่ࠥํะศࠢส่ำ฽ร๊ࠡ฽๎ึํࠠๆ่ࠣห้ษฮุษฤࠫ㝉"))
		return
	message = l1lll111ll11_l1_
	from l1l11lll11l_l1_ import l11l11l1l1l_l1_
	succeeded = l11l11l1l1l_l1_(l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡹࠧ㝊"),message,True,l1l111_l1_ (u"ࠨࠩ㝋"),l1l111_l1_ (u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫ㝌"),l1l1ll1l1l11_l1_)
	if succeeded and l1l1ll1l1l11_l1_:
		l1l1ll111111_l1_.append(l1l1ll1l1111_l1_)
		l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㝍"),l1l111_l1_ (u"ࠫࡆࡒࡌࡠࡕࡈࡒ࡙ࡥࡅࡓࡔࡒࡖࡘ࠭㝎"),l1l1ll111111_l1_,l1l1lll1l1l_l1_)
	return
def l1ll1l11l1ll_l1_(data):
	if kodi_version>18.99: data = data.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㝏"))
	filename = l1l111_l1_ (u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭㝐")+str(time.time())+l1l111_l1_ (u"ࠧ࠯ࡦࡤࡸࠬ㝑")
	open(filename,l1l111_l1_ (u"ࠨࡹࡥࠫ㝒")).write(data)
	return
def l11lll1l11l_l1_(l1l1ll1111l_l1_):
	if l1l1ll1111l_l1_:
		l1ll11ll1l11_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㝓"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭㝔"),l1l111_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ㝕"))
		if l1ll11ll1l11_l1_: return l1ll11ll1l11_l1_
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㝖")][5]
	user = l1l1l1l1lll_l1_(32)
	l1111l111l1_l1_ = l111lll1l11_l1_()
	l1lll11ll111_l1_ = l1111l111l1_l1_.split(l1l111_l1_ (u"࠭ࠬࠨ㝗"))[2]
	l1ll1lll111l_l1_ = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭㝘"))
	l1lllll111l1_l1_ = l1l1lll1l1ll_l1_()
	payload = {l1l111_l1_ (u"ࠨࡷࡶࡩࡷ࠭㝙"):user,l1l111_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ㝚"):l1l11l11111_l1_,l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ㝛"):l1lll11ll111_l1_,l1l111_l1_ (u"ࠫ࡮ࡪࡳࠨ㝜"):l1ll1ll1ll11_l1_(l1lllll111l1_l1_)}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ㝝"),url,payload,l1l111_l1_ (u"࠭ࠧ㝞"),l1l111_l1_ (u"ࠧࠨ㝟"),l1l111_l1_ (u"ࠨࠩ㝠"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ㝡"))
	if not response.succeeded: return []
	html = response.content
	l1ll11ll1l11_l1_ = html.replace(l1l111_l1_ (u"ࠪࡠࡡࡸࠧ㝢"),l1l111_l1_ (u"ࠫࡡࡴࠧ㝣")).replace(l1l111_l1_ (u"ࠬࡢ࡜࡯ࠩ㝤"),l1l111_l1_ (u"࠭࡜࡯ࠩ㝥")).replace(l1l111_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ㝦"),l1l111_l1_ (u"ࠨ࡞ࡱࠫ㝧")).replace(l1l111_l1_ (u"ࠩ࡟ࡶࠬ㝨"),l1l111_l1_ (u"ࠪࡠࡳ࠭㝩"))
	l1ll11ll1l11_l1_ = re.findall(l1l111_l1_ (u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࠽࠾࠭ࡢࡤࠬࠫ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡋࡎࡅ࠼࠽ࡉࡓࡊࠧ㝪"),l1ll11ll1l11_l1_,re.DOTALL)
	if not l1ll11ll1l11_l1_: return []
	l1ll11ll1l11_l1_ = sorted(l1ll11ll1l11_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1ll111l11_l1_,l1l1lll1l11l_l1_,l11l111111l_l1_,l111llll1l1_l1_,reason = l1ll11ll1l11_l1_[0]
	l1lll111llll_l1_ = reason if l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠬࡓࡔ࠱࠷ࡋ࡜࠵ࡲࡔࡕࡇࡉࡒࡘ࡛ࡎࡧࡗࡈ࡚ࡘ࡙ࡕ࠺ࡇ࡛ࠫ㝫")) else l1l1lll1l11l_l1_
	settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡬ࡲ࡫ࡵࡳ࠯ࡲࡨࡶ࡮ࡵࡤࠨ㝬"),l1lll111llll_l1_)
	l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㝭"),l1l111_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ㝮"),l1ll11ll1l11_l1_,l11l1l1_l1_)
	return l1ll11ll1l11_l1_
def SPLIT_BIGLIST(items,l1l1ll11lll1_l1_=0,l1llll1ll111_l1_=0):
	if l1l1ll11lll1_l1_ and not l1llll1ll111_l1_: l1llll1ll111_l1_ = len(items)//l1l1ll11lll1_l1_
	l1ll1ll1lll1_l1_,l1l11l111l_l1_,l1lll11lll1l_l1_ = [],-1,0
	for item in items:
		if l1lll11lll1l_l1_%l1llll1ll111_l1_==0:
			l1l11l111l_l1_ += 1
			l1ll1ll1lll1_l1_.append([])
		l1ll1ll1lll1_l1_[l1l11l111l_l1_].append(item)
		l1lll11lll1l_l1_ += 1
	return l1ll1ll1lll1_l1_
def l111l1llll1_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	if 1 or l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࡟ࠨ㝯") not in filename or l1l111_l1_ (u"ࠪࡑ࠸࡛࡟ࠨ㝰") not in filename: text = str(data)
	else:
		l1ll1ll1lll1_l1_ = SPLIT_BIGLIST(data,8)
		text = l1l111_l1_ (u"ࠫࠬ㝱")
		for split in l1ll1ll1lll1_l1_:
			text += str(split)+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ㝲")
		text = text.strip(l1l111_l1_ (u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ㝳"))
	l1l1l11l111_l1_ = zlib.compress(text)
	open(filepath,l1l111_l1_ (u"ࠧࡸࡤࠪ㝴")).write(l1l1l11l111_l1_)
	return
def l11ll111l1l_l1_(l1l1l11lll1_l1_,filename):
	if l1l1l11lll1_l1_==l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㝵"): data = {}
	elif l1l1l11lll1_l1_==l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㝶"): data = []
	elif l1l1l11lll1_l1_==l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㝷"): data = l1l111_l1_ (u"ࠫࠬ㝸")
	elif l1l1l11lll1_l1_==l1l111_l1_ (u"ࠬ࡯࡮ࡵࠩ㝹"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l1l1l11l111_l1_ = open(filepath,l1l111_l1_ (u"࠭ࡲࡣࠩ㝺")).read()
	text = zlib.decompress(l1l1l11l111_l1_)
	if l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭㝻") not in text: data = eval(text)
	else:
		l1ll1ll1lll1_l1_ = text.split(l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ㝼"))
		del text
		data = []
		l11l11lll11_l1_ = l11l1111l1l_l1_()
		id = 0
		for split in l1ll1ll1lll1_l1_:
			l11l11lll11_l1_.l111llll11l_l1_(str(id),eval,split)
			id += 1
		del l1ll1ll1lll1_l1_
		l11l11lll11_l1_.l1ll1ll111l1_l1_()
		l11l11lll11_l1_.l1l1ll11ll1l_l1_()
		l1l1lll1l111_l1_ = list(l11l11lll11_l1_.l1llll1ll1l1_l1_.keys())
		l1ll111l11l1_l1_ = sorted(l1l1lll1l111_l1_,reverse=False,key=lambda key: int(key))
		for id in l1ll111l11l1_l1_:
			data += l11l11lll11_l1_.l1llll1ll1l1_l1_[id]
	return data
def l1ll11l1ll1l_l1_(addon_id):
	l1ll11l1l1ll_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ㝽"),addon_id,l1l111_l1_ (u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭㝾"))
	try: l11111lllll_l1_ = open(l1ll11l1l1ll_l1_,l1l111_l1_ (u"ࠫࡷࡨࠧ㝿")).read()
	except:
		l1lll11ll11l_l1_ = os.path.join(l1111111lll_l1_,l1l111_l1_ (u"ࠬࡧࡤࡥࡱࡱࡷࠬ㞀"),addon_id,l1l111_l1_ (u"࠭ࡡࡥࡦࡲࡲ࠳ࡾ࡭࡭ࠩ㞁"))
		try: l11111lllll_l1_ = open(l1lll11ll11l_l1_,l1l111_l1_ (u"ࠧࡳࡤࠪ㞂")).read()
		except: return l1l111_l1_ (u"ࠨࠩ㞃"),[]
	if kodi_version>18.99: l11111lllll_l1_ = l11111lllll_l1_.decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㞄"))
	version = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃ࠮ࠫࡁࡹࡩࡷࡹࡩࡰࡰࡀ࡟ࡡࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࡠࠬࡣࠧ㞅"),l11111lllll_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l1l111_l1_ (u"ࠫࠬ㞆"),[]
	l11llllll1l_l1_,l111lll1lll_l1_ = version[0],l1l1ll111ll1_l1_(version[0])
	return l11llllll1l_l1_,l111lll1lll_l1_
def l111ll11l1l_l1_():
	l1111llll11_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ㞇"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ㞈"),l1l111_l1_ (u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨ㞉"))
	if l1111llll11_l1_: return l1111llll11_l1_
	l1l1llll1lll_l1_,l1111llll11_l1_ = {},{}
	l1ll11ll1ll1_l1_ = [l1l11l1_l1_[l1l111_l1_ (u"ࠨࡔࡈࡔࡔ࡙ࠧ㞊")][0]]
	if kodi_version>17.99: l1ll11ll1ll1_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࠨ㞋")][1])
	if kodi_version>18.99: l1ll11ll1ll1_l1_.append(l1l11l1_l1_[l1l111_l1_ (u"ࠪࡖࡊࡖࡏࡔࠩ㞌")][2])
	for l1ll111lll1l_l1_ in l1ll11ll1ll1_l1_:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㞍"),l1ll111lll1l_l1_,l1l111_l1_ (u"ࠬ࠭㞎"),l1l111_l1_ (u"࠭ࠧ㞏"),l1l111_l1_ (u"ࠧࠨ㞐"),l1l111_l1_ (u"ࠨࠩ㞑"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭㞒"))
		if response.succeeded:
			html = response.content
			l1l1ll1ll111_l1_ = l1ll111lll1l_l1_.rsplit(l1l111_l1_ (u"ࠪ࠳ࠬ㞓"),1)[0]
			l1111lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡪࡸࡳࡪࡱࡱࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㞔"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l111l1lll11_l1_ in l1111lllll1_l1_:
				l111llll111_l1_ = l1l1ll1ll111_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ㞕")+addon_id+l1l111_l1_ (u"࠭࠯ࠨ㞖")+addon_id+l1l111_l1_ (u"ࠧ࠮ࠩ㞗")+l111l1lll11_l1_+l1l111_l1_ (u"ࠨ࠰ࡽ࡭ࡵ࠭㞘")
				if addon_id not in list(l1l1llll1lll_l1_.keys()):
					l1l1llll1lll_l1_[addon_id] = []
					l1111llll11_l1_[addon_id] = []
				l1lll1l11l1l_l1_ = l1l1ll111ll1_l1_(l111l1lll11_l1_)
				l1l1llll1lll_l1_[addon_id].append((l111l1lll11_l1_,l1lll1l11l1l_l1_,l111llll111_l1_))
	for addon_id in list(l1l1llll1lll_l1_.keys()):
		l1111llll11_l1_[addon_id] = sorted(l1l1llll1lll_l1_[addon_id],reverse=True,key=lambda key: key[1])
	l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ㞙"),l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ㞚"),l1111llll11_l1_,l11l1l1_l1_)
	return l1111llll11_l1_
def l1l1ll111ll1_l1_(l111l1lll11_l1_):
	l1lll1l11l1l_l1_ = []
	l1lll1l11l1_l1_ = l111l1lll11_l1_.split(l1l111_l1_ (u"ࠫ࠳࠭㞛"))
	for l1l1ll1ll1_l1_ in l1lll1l11l1_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩ㞜"),l1l1ll1ll1_l1_,re.DOTALL)
		l1l1lll1l1l1_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l1l1lll1l1l1_l1_.append(part)
		l1lll1l11l1l_l1_.append(l1l1lll1l1l1_l1_)
	return l1lll1l11l1l_l1_
def l1lll11111ll_l1_(l1lll1l11l1l_l1_):
	l111l1lll11_l1_ = l1l111_l1_ (u"࠭ࠧ㞝")
	for l1l1ll1ll1_l1_ in l1lll1l11l1l_l1_:
		for part in l1l1ll1ll1_l1_: l111l1lll11_l1_ += str(part)
		l111l1lll11_l1_ += l1l111_l1_ (u"ࠧ࠯ࠩ㞞")
	l111l1lll11_l1_ = l111l1lll11_l1_.strip(l1l111_l1_ (u"ࠨ࠰ࠪ㞟"))
	return l111l1lll11_l1_
def l1lllll1l11l_l1_(l11ll1111ll_l1_):
	l1l1ll1ll11l_l1_ = {}
	l1l1llll1lll_l1_ = l111ll11l1l_l1_()
	l11ll1llll1_l1_ = l1ll1ll1111l_l1_(l11ll1111ll_l1_)
	for addon_id in l11ll1111ll_l1_:
		if addon_id not in list(l1l1llll1lll_l1_.keys()): continue
		l1111llll11_l1_ = l1l1llll1lll_l1_[addon_id]
		l11ll1l1l11_l1_,l11ll1l11l1_l1_,l1l1l1llll11_l1_ = l1111llll11_l1_[0]
		l1111l1ll11_l1_,l11111l11l1_l1_ = l1ll11l1ll1l_l1_(addon_id)
		l11l1l1ll1l_l1_,l1llll1l1ll1_l1_ = l11ll1llll1_l1_[addon_id]
		l11lll1l1l1_l1_ = l11ll1l11l1_l1_>l11111l11l1_l1_ and l11l1l1ll1l_l1_
		l1l1l1lllll1_l1_ = True
		if not l11l1l1ll1l_l1_: l11llllllll_l1_ = l1l111_l1_ (u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ㞠")
		elif not l1llll1l1ll1_l1_: l11llllllll_l1_ = l1l111_l1_ (u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ㞡")
		elif l11lll1l1l1_l1_: l11llllllll_l1_ = l1l111_l1_ (u"ࠫࡴࡲࡤࠨ㞢")
		else:
			l11llllllll_l1_ = l1l111_l1_ (u"ࠬ࡭࡯ࡰࡦࠪ㞣")
			l1l1l1lllll1_l1_ = False
		l1l1ll1ll11l_l1_[addon_id] = (l1l1l1lllll1_l1_,l1111l1ll11_l1_,l11111l11l1_l1_,l11ll1l1l11_l1_,l11ll1l11l1_l1_,l11llllllll_l1_,l1l1l1llll11_l1_)
	return l1l1ll1ll11l_l1_
def l1ll1llll1ll_l1_(l11l1ll11ll_l1_,l11111ll111_l1_,l11l1111l11_l1_=l1l111_l1_ (u"࠭ࠧ㞤"),line2=l1l111_l1_ (u"ࠧࠨ㞥"),l11l1111ll1_l1_=l1l111_l1_ (u"ࠨࠩ㞦")):
	if kodi_version<19: l11l1ll11ll_l1_.update(l11111ll111_l1_,l11l1111l11_l1_,line2,l11l1111ll1_l1_)
	else: l11l1ll11ll_l1_.update(l11111ll111_l1_,l11l1111l11_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㞧")+line2+l1l111_l1_ (u"ࠪࡠࡳ࠭㞨")+l11l1111ll1_l1_)
	return
def l1ll1ll11l1l_l1_(l1llllll11ll_l1_):
	def l1lllll1111l_l1_(num,b,l1ll1l11ll11_l1_=l1l111_l1_ (u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝ࠦ㞩")):
		return ((num == 0) and l1ll1l11ll11_l1_[0]) or (l1lllll1111l_l1_(num // b, b, l1ll1l11ll11_l1_).lstrip(l1ll1l11ll11_l1_[0]) + l1ll1l11ll11_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l1l111_l1_ (u"ࠧࡢ࡜ࡣࠤ㞪") + l1lllll1111l_l1_(c, a) + l1l111_l1_ (u"ࠨ࡜࡝ࡤࠥ㞫"),  k[c], p)
		return p
	l1llllll11ll_l1_ = l1llllll11ll_l1_.split(l1l111_l1_ (u"ࠧࡾࠪࠪ㞬"))[1][:-1]
	l1ll1l111l11_l1_ = eval(l1l111_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩ㞭")+l1llllll11ll_l1_,{l1l111_l1_ (u"ࠩࡥࡥࡸ࡫ࡎࠨ㞮"):l1lllll1111l_l1_,l1l111_l1_ (u"ࠪࡹࡳࡶࡡࡤ࡭ࠪ㞯"):unpack})
	return l1ll1l111l11_l1_
def l111ll11111_l1_(url,l1ll1lll1111_l1_=l1l111_l1_ (u"ࠫࠬ㞰")):
	if l1ll1lll1111_l1_==l1l111_l1_ (u"ࠬࡲ࡯ࡸࡧࡵࠫ㞱"): url = re.sub(l1l111_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭㞲"),lambda l11llll11l1_l1_: l11llll11l1_l1_.group(0).lower(),url)
	elif l1ll1lll1111_l1_==l1l111_l1_ (u"ࠧࡶࡲࡳࡩࡷ࠭㞳"): url = re.sub(l1l111_l1_ (u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨ㞴"),lambda l11llll11l1_l1_: l11llll11l1_l1_.group(0).upper(),url)
	return url
def l1ll1ll1111l_l1_(l11ll1111ll_l1_):
	l111ll1l11l_l1_,l111111l11l_l1_ = False,False
	conn = sqlite3.connect(l111l111lll_l1_)
	conn.text_factory = str
	l1lllll1ll_l1_ = conn.cursor()
	if len(l11ll1111ll_l1_)==1: l111ll11l11_l1_ = l1l111_l1_ (u"ࠩࠫࠦࠬ㞵")+l11ll1111ll_l1_[0]+l1l111_l1_ (u"ࠪࠦ࠮࠭㞶")
	else: l111ll11l11_l1_ = str(tuple(l11ll1111ll_l1_))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫ㞷")+l111ll11l11_l1_+l1l111_l1_ (u"ࠬࠦ࠻ࠨ㞸"))
	l1l11ll1lll_l1_ = l1lllll1ll_l1_.fetchall()
	l11ll1llll1_l1_ = {}
	for addon_id in l11ll1111ll_l1_: l11ll1llll1_l1_[addon_id] = (False,False)
	for addon_id,l111111l11l_l1_ in l1l11ll1lll_l1_:
		l111ll1l11l_l1_ = True
		l111111l11l_l1_ = l111111l11l_l1_==1
		l11ll1llll1_l1_[addon_id] = (l111ll1l11l_l1_,l111111l11l_l1_)
	conn.close()
	return l11ll1llll1_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	l1lll_l1_ = l1l111_l1_ (u"࠭ࠧ㞹")
	if file==l1l1ll111lll_l1_: status = l111111l111_l1_(True,False)
	if os.path.exists(file):
		l1l11l1ll11_l1_ = open(file,l1l111_l1_ (u"ࠧࡳࡤࠪ㞺")).read()
		if kodi_version>18.99: l1l11l1ll11_l1_ = l1l11l1ll11_l1_.decode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㞻"))
		if file==l1l1ll111lll_l1_: l1lll_l1_ = l1l11l1ll11_l1_
		else:
			l1111ll1111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ㞼"),l1l11l1ll11_l1_)
			if l1111ll1111_l1_:
				l1lll_l1_ = {}
				for key in l1111ll1111_l1_.keys():
					l1lll_l1_[key] = []
					for l1lllll1l1l1_l1_ in l1111ll1111_l1_[key]:
						type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = l1l111_l1_ (u"ࠪࠫ㞽"),l1l111_l1_ (u"ࠫࠬ㞾"),l1l111_l1_ (u"ࠬ࠭㞿"),l1l111_l1_ (u"࠭ࠧ㟀"),l1l111_l1_ (u"ࠧࠨ㟁"),l1l111_l1_ (u"ࠨࠩ㟂"),l1l111_l1_ (u"ࠩࠪ㟃"),l1l111_l1_ (u"ࠪࠫ㟄"),l1l111_l1_ (u"ࠫࠬ㟅")
						type = l1lllll1l1l1_l1_[0]
						name = l1lllll1l1l1_l1_[1]
						name = l11lll11111_l1_(name)
						url = l1lllll1l1l1_l1_[2]
						mode = l1lllll1l1l1_l1_[3]
						l11l_l1_ = l1lllll1l1l1_l1_[4]
						l1llllll1_l1_ = l1lllll1l1l1_l1_[5]
						if len(l1lllll1l1l1_l1_)>6: text = l1lllll1l1l1_l1_[6]
						if len(l1lllll1l1l1_l1_)>7: context = l1lllll1l1l1_l1_[7]
						if len(l1lllll1l1l1_l1_)>8: l1llll11l11_l1_ = l1lllll1l1l1_l1_[8]
						if file==favoritesfile: l1l1lll111l1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,l1l111_l1_ (u"ࠬ࠭㟆"),l1llll11l11_l1_
						else: l1l1lll111l1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_
						l1lll_l1_[key].append(l1l1lll111l1_l1_)
			l1l11l1111l_l1_ = str(l1lll_l1_)
			if kodi_version>18.99: l1l11l1111l_l1_ = l1l11l1111l_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㟇"))
			open(file,l1l111_l1_ (u"ࠧࡸࡤࠪ㟈")).write(l1l11l1111l_l1_)
	return l1lll_l1_
def l1ll1l1l111_l1_(l1ll1ll1ll1_l1_):
	l1lll11l1ll1_l1_ = l1ll1ll1ll1_l1_.split(l1l111_l1_ (u"ࠨ࠯ࠪ㟉"),1)[0]
	l1ll1l1ll1l_l1_,l1ll1ll1l1l_l1_,l1lll11ll11_l1_ = l1l111_l1_ (u"ࠩࠪ㟊"),l1l111_l1_ (u"ࠪࠫ㟋"),l1l111_l1_ (u"ࠫࠬ㟌")
	if   l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ㟍")		:	from l1l1ll1_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ㟎")		:	from l11l111_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ㟏")	:	from l1l1111l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ㟐")		:	from l1ll1l1l_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ㟑")	:	from l1111l11_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㟒")	:	from l1lll1ll1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ㟓")	: 	from l1ll1l1l1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ㟔")	:	from l1ll11lll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ㟕"):	from l1ll1111l_l1_	import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ㟖")	:	from l1l11l111_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡄࡒࡏࡗࡇࠧ㟗")		:	from l11l1ll1l_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ㟘")	:	from l11l11ll1_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫ㟙")	:	from l11l11l1l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ㟚")	:	from l11l111ll_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧ㟛")	:	from l111l1l11_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬ㟜"):	from l1111l1ll_l1_	import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ㟝")	:	from l1111l1l1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ㟞")	:	from l11111lll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ㟟")	:	from l11111l11_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫ㟠")	:	from l111111l1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ㟡"):	from l1l1l11ll1_l1_	import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭㟢")	:	from l11l1l111l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ㟣")	:	from l111ll1ll1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ㟤")	:	from l111l11lll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ㟥")	:	from l1111lllll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ㟦")	:	from l1111lll1l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ㟧")	:	from l1111ll111_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ㟨")	:	from l11111lll1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ㟩")	:	from l11111ll1l_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ㟪")	:	from l1lll1lll1l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㟫")	:	from l1lll1ll11l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ㟬")	:	from l1lll1l1l1l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ㟭")	:	from l1lll1l1111_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ㟮")		:	from l1lll11lll1_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭㟯")	:	from l1ll1l111ll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐࠫ㟰")		:	from l1ll1l111l1_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㟱")		:	from IPTV			import MENUu as l1ll1l1ll1l_l1_,SEARCHh as l1ll1ll1l1l_l1_,menu_namee as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ㟲")	:	from l1ll111l1l1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪ㟳")	:	from l1ll111l11l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ㟴")	:	from l1ll1111ll1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ㟵")	:	from l1l1lll1lll_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬ㟶")	:	from l11lllll1l1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㟷")		:	from M3U			import MENUu as l1ll1l1ll1l_l1_,SEARCHh as l1ll1ll1l1l_l1_,menu_namee as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭㟸")	:	from l1ll1l1l11ll_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ㟹")	:	from l1lll11l111l_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ㟺")		:	from l11l111l11l_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㟻")	:	from l1ll11l11lll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧ㟼"):	from l11ll11lll1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ㟽")	:	from l11l11l111l_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࡙ࠬࡈࡐࡈࡋࡅࠬ㟾")	:	from l1111l11lll_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ㟿")	:	from l11lll1l1ll_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ㠀")	:	from l1ll1111l111_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ㠁")		:	from l1111111l11_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ㠂")	:	from l1ll11l1llll_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ㠃")		:	from l11lll1111l_l1_			import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㠄")	:	from l11ll1ll1l1_l1_		import l1l1l11_l1_ as l1ll1l1ll1l_l1_,l1lll1_l1_ as l1ll1ll1l1l_l1_,l1lllll_l1_ as l1lll11ll11_l1_
	elif l1lll11l1ll1_l1_==l1l111_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ㠅"):	from l11ll111111_l1_	import l1l1l11_l1_ as l1ll1l1ll1l_l1_
	return l1ll1l1ll1l_l1_,l1ll1ll1l1l_l1_,l1lll11ll11_l1_
def l1lll1llll1l_l1_(l1l1l1llll1l_l1_,headers,l11_l1_):
	l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㠆"),l1l111_l1_ (u"ࠧ࠯ࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧ࠻ࠢ࡞ࠤࠬ㠇")+l1l1l1llll1l_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫ㠈")+str(headers)+l1l111_l1_ (u"ࠩࠣࡡࠬ㠉"))
	l11l1ll11ll_l1_ = l11l111ll11_l1_()
	l11l1ll11ll_l1_.create(l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㠊"),l1l111_l1_ (u"ࠫ๏าั๋ࠢส่ว์ࠠโฯุࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤํฮูะ้สࠤุ๎แࠡฬหำศูࠦๆๆํอࠥาไษࠢส่๊๊แࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭㠋"))
	l11l1lll1l_l1_ = 1024*1024
	chunksize = 1*l11l1lll1l_l1_
	from requests import get
	response = get(l1l1l1llll1l_l1_,stream=True,headers=headers)
	l1ll11111lll_l1_ = response.headers
	response.close()
	l1ll11111111_l1_ = bytes()
	if not l1ll11111lll_l1_:
		if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭㠌"),l1l111_l1_ (u"࠭ࠧ㠍"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㠎"),l1l111_l1_ (u"ࠨษ็ฬึ์วๆฮ่๊๊ࠣࠦห็ๆ๊๋ࠥๆࠡฬะ้๏๊ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮ้ࠠษ็ือฮࠠใัࠣ๎่๎ๆࠡ฻้ำ่ࠦๅีๅ็อࠥ็๊ࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥ࠴ࠠอำหࠤฯำๅ๋ๆࠣห้๋ไโ่ࠢีฮࠦรฯำ์ࠫ㠏"))
		l11l1ll11ll_l1_.close()
	else:
		if l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪ㠐") not in list(l1ll11111lll_l1_.keys()): filesize = 0
		else: filesize = int(l1ll11111lll_l1_[l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫ㠑")])
		l11ll1lll1l_l1_ = str(int(1000*filesize/l11l1lll1l_l1_)/1000.0)
		l1lll1l1111l_l1_ = int(filesize/chunksize)+1
		if l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡘࡡ࡯ࡩࡨࠫ㠒") in list(l1ll11111lll_l1_.keys()) and filesize>l11l1lll1l_l1_:
			l1ll111lllll_l1_ = True
			ranges = []
			l11l1ll1l11_l1_ = 10
			ranges.append(str(0*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㠓")+str(1*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(1*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㠔")+str(2*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(2*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㠕")+str(3*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(3*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠨ࠯ࠪ㠖")+str(4*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(4*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠩ࠰ࠫ㠗")+str(5*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(5*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠪ࠱ࠬ㠘")+str(6*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(6*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠫ࠲࠭㠙")+str(7*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(7*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠬ࠳ࠧ㠚")+str(8*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(8*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"࠭࠭ࠨ㠛")+str(9*filesize//l11l1ll1l11_l1_-1))
			ranges.append(str(9*filesize//l11l1ll1l11_l1_)+l1l111_l1_ (u"ࠧ࠮ࠩ㠜"))
			l11ll11ll11_l1_ = float(l1lll1l1111l_l1_)/l11l1ll1l11_l1_
			l1lllllll111_l1_ = l11ll11ll11_l1_/int(1+l11ll11ll11_l1_)
		else:
			l1ll111lllll_l1_ = False
			l11l1ll1l11_l1_ = 1
			l1lllllll111_l1_ = 1
		l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㠝"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡲࡢࡰࡪࡩࡸࡀࠠ࡜ࠢࠪ㠞")+str(l1ll111lllll_l1_)+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬ㠟")+str(filesize)+l1l111_l1_ (u"ࠫࠥࡣࠧ㠠"))
		l1l11l111l_l1_,l1ll11l1l11l_l1_ = 0,0
		for l1lll11lll1l_l1_ in range(l11l1ll1l11_l1_):
			l1ll1ll1l_l1_ = headers.copy()
			if l1ll111lllll_l1_: l1ll1ll1l_l1_[l1l111_l1_ (u"ࠬࡘࡡ࡯ࡩࡨࠫ㠡")] = l1l111_l1_ (u"࠭ࡢࡺࡶࡨࡷࡂ࠭㠢")+ranges[l1lll11lll1l_l1_]
			response = get(l1l1l1llll1l_l1_,stream=True,headers=l1ll1ll1l_l1_,timeout=300)
			for chunk in response.iter_content(chunk_size=chunksize):
				if l11l1ll11ll_l1_.iscanceled():
					l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㠣"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡃࡢࡰࡦࡩࡱ࡫ࡤࠨ㠤"))
					break
				l1l11l111l_l1_ += l1lllllll111_l1_
				l1ll11111111_l1_ += chunk
				if not l1ll11l1l11l_l1_: l1ll11l1l11l_l1_ = len(chunk)
				if filesize: l1ll1llll1ll_l1_(l11l1ll11ll_l1_,100*l1l11l111l_l1_//l1lll1l1111l_l1_,l1l111_l1_ (u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠠศๆฯึฦࠦัใ็ࠪ㠥"),str(100.0*l1ll11l1l11l_l1_*l1l11l111l_l1_//chunksize//100.0)+l1l111_l1_ (u"ࠪࠤ࠴ࠦࠧ㠦")+l11ll1lll1l_l1_+l1l111_l1_ (u"ࠫࠥࡓࡂࠨ㠧"))
				else: l1ll1llll1ll_l1_(l11l1ll11ll_l1_,l1ll11l1l11l_l1_*l1l11l111l_l1_//chunksize,l1l111_l1_ (u"ࠬาไษࠢส่๊๊แ࠻࠯ࠪ㠨"),str(100.0*l1ll11l1l11l_l1_*l1l11l111l_l1_//chunksize//100.0)+l1l111_l1_ (u"࠭ࠠࡎࡄࠪ㠩"))
			response.close()
		l11l1ll11ll_l1_.close()
		if len(l1ll11111111_l1_)<filesize and filesize>0:
			l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㠪"),l1l111_l1_ (u"ࠨ࠰ࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡦࡢ࡫࡯ࡩࡩࠦ࡯ࡳࠢࡦࡥࡳࡩࡥ࡭ࡧࡧࠤࡦࡺ࠺ࠡ࡝ࠣࠫ㠫")+str(len(l1ll11111111_l1_)//l11l1lll1l_l1_)+l1l111_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊࡷࡵ࡭ࠡࡶࡲࡸࡦࡲࠠࡰࡨ࠽ࠤࡠࠦࠧ㠬")+l11ll1lll1l_l1_+l1l111_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠩ㠭"))
			l111ll1lll1_l1_ = l1l1ll1l11ll_l1_(l1l111_l1_ (u"ࠫࠬ㠮"),l1l111_l1_ (u"ࠬหไ฻ษฤࠤํิั้ฮࠪ㠯"),l1l111_l1_ (u"࠭วิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺ࠭㠰"),l1l111_l1_ (u"ࠧฦ฻สำฮࠦฬๅสࠣห้๋ไโࠩ㠱"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㠲"),l1l111_l1_ (u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭㠳")+str(len(l1ll11111111_l1_)//l11l1lll1l_l1_)+l1l111_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩ㠴")+l11ll1lll1l_l1_+l1l111_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭㠵"))
			if l111ll1lll1_l1_==2: l1ll11111111_l1_ = l1lll1llll1l_l1_(l1l1l1llll1l_l1_,headers,l11_l1_)
			elif l111ll1lll1_l1_==1: l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㠶"),l1l111_l1_ (u"࠭࠮ࠡࠢࡑࡳࡹࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡢࡥࡦࡩࡵࡺࡥࡥࠢࡤࡲࡩࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡶࡵࡨࡨࠬ㠷"))
			else: return l1l111_l1_ (u"ࠧࠨ㠸")
			if not l1ll11111111_l1_: return l1l111_l1_ (u"ࠨࠩ㠹")
		else: l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㠺"),l1l111_l1_ (u"ࠪ࠲ࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧ㠻")+l11ll1lll1l_l1_+l1l111_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠪ㠼"))
	return l1ll11111111_l1_
def l1llllllll11_l1_(l1ll1_l1_):
	return response
def l111lll1l11_l1_(l1ll1l1lllll_l1_=l1l111_l1_ (u"ࠬ࠭㠽")):
	l1ll11l11ll1_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡳࡵࡴࠪ㠾"),l1l111_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ㠿"),l1l111_l1_ (u"ࠨࡋࡓࡐࡔࡉࡁࡕࡋࡒࡒࠬ㡀"))
	if l1ll11l11ll1_l1_: return l1ll11l11ll1_l1_
	l1ll1l1lllll_l1_,l1ll11ll1111_l1_,l1lll11ll111_l1_,l1l11111111_l1_,l1lll11l1lll_l1_,l1111l11111_l1_,timezone = l1l111_l1_ (u"ࠩࠪ㡁"),l1l111_l1_ (u"ࠪࠫ㡂"),l1l111_l1_ (u"ࠫࠬ㡃"),l1l111_l1_ (u"ࠬ࠭㡄"),l1l111_l1_ (u"࠭ࠧ㡅"),l1l111_l1_ (u"ࠧࠨ㡆"),l1l111_l1_ (u"ࠨࠩ㡇")
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬ㡈")+l1ll1l1lllll_l1_+l1l111_l1_ (u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ㡉")
	headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㡊"):l1l111_l1_ (u"ࠬ࠭㡋")}
	response = l1111l1ll1l_l1_(l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㡌"),url,l1l111_l1_ (u"ࠧࠨ㡍"),headers,l1l111_l1_ (u"ࠨࠩ㡎"),l1l111_l1_ (u"ࠩࠪ㡏"),l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭㡐"))
	if not response.succeeded: l1111l111l1_l1_ = l1ll1l1lllll_l1_+l1l111_l1_ (u"ࠫ࠱࠭㡑")+l1ll11ll1111_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㡒")+l1lll11ll111_l1_+l1l111_l1_ (u"࠭ࠬࠨ㡓")+l1lll11l1lll_l1_+l1l111_l1_ (u"ࠧ࠭ࠩ㡔")+l1111l11111_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㡕")+timezone
	else:
		html = response.content
		html = re.findall(l1l111_l1_ (u"ࠩ࡟ࡿ࠳࠰࠿࡝ࡿ࡟ࢁࠬ㡖"),html,re.DOTALL)
		if html:
			html = html[0]
			l111llllll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㡗"),html)
			if l1l111_l1_ (u"ࠫ࡮ࡶࠧ㡘") in list(l111llllll1_l1_.keys()): l1ll1l1lllll_l1_ = l111llllll1_l1_[l1l111_l1_ (u"ࠬ࡯ࡰࠨ㡙")]
			if l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩ㡚") in list(l111llllll1_l1_.keys()): l1ll11ll1111_l1_ = l111llllll1_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ㡛")]
			if l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㡜") in list(l111llllll1_l1_.keys()): l1lll11ll111_l1_ = l111llllll1_l1_[l1l111_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪ㡝")]
			if l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩ㡞") in list(l111llllll1_l1_.keys()): l1l11111111_l1_ = l111llllll1_l1_[l1l111_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪ㡟")]
			if l1l111_l1_ (u"ࠬࡸࡥࡨ࡫ࡲࡲࠬ㡠") in list(l111llllll1_l1_.keys()): l1lll11l1lll_l1_ = l111llllll1_l1_[l1l111_l1_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭㡡")]
			if l1l111_l1_ (u"ࠧࡤ࡫ࡷࡽࠬ㡢") in list(l111llllll1_l1_.keys()): l1111l11111_l1_ = l111llllll1_l1_[l1l111_l1_ (u"ࠨࡥ࡬ࡸࡾ࠭㡣")]
			if l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ㡤") in list(l111llllll1_l1_.keys()):
				timezone = l111llllll1_l1_[l1l111_l1_ (u"ࠪࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ㡥")][l1l111_l1_ (u"ࠫࡺࡺࡣࠨ㡦")]
				if timezone[0] not in [l1l111_l1_ (u"ࠬ࠳ࠧ㡧"),l1l111_l1_ (u"࠭ࠫࠨ㡨")]: timezone = l1l111_l1_ (u"ࠧࠬࠩ㡩")+timezone
			l1111l111l1_l1_ = l1ll1l1lllll_l1_+l1l111_l1_ (u"ࠨ࠮ࠪ㡪")+l1ll11ll1111_l1_+l1l111_l1_ (u"ࠩ࠯ࠫ㡫")+l1lll11ll111_l1_+l1l111_l1_ (u"ࠪ࠰ࠬ㡬")+l1lll11l1lll_l1_+l1l111_l1_ (u"ࠫ࠱࠭㡭")+l1111l11111_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ㡮")+timezone
			if kodi_version>18.99: l1111l111l1_l1_ = l1111l111l1_l1_.encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㡯")).decode(l1l111_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㡰"))
		l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ㡱"),l1l111_l1_ (u"ࠩࡌࡔࡑࡕࡃࡂࡖࡌࡓࡓ࠭㡲"),l1111l111l1_l1_,l111l11l_l1_)
	return l1111l111l1_l1_
def l111ll_l1_(search):
	options,l11_l1_ = l1l111_l1_ (u"ࠪࠫ㡳"),True
	if search.count(l1l111_l1_ (u"ࠫࡤ࠭㡴"))>=2:
		search,options = search.split(l1l111_l1_ (u"ࠬࡥࠧ㡵"),1)
		options = l1l111_l1_ (u"࠭࡟ࠨ㡶")+options
		if l1l111_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ㡷") in options: l11_l1_ = False
		else: l11_l1_ = True
	return search,options,l11_l1_
def l1l1lll1l1ll_l1_():
	l1ll1lll111l_l1_ = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ㡸"))
	l1lllll111l1_l1_ = 0
	if os.path.exists(l1ll1lll111l_l1_):
		for filename in os.listdir(l1ll1lll111l_l1_):
			if l1l111_l1_ (u"ࠩ࠱ࡴࡾࡵࠧ㡹") in filename: continue
			if l1l111_l1_ (u"ࠪࡣࡤࡶࡹࡤࡣࡦ࡬ࡪࡥ࡟ࠨ㡺") in filename: continue
			l1ll111l11_l1_ = os.path.join(l1ll1lll111l_l1_,filename)
			size,count = l1ll1l1lll_l1_(l1ll111l11_l1_)
			l1lllll111l1_l1_ += size
	return l1lllll111l1_l1_
def l111111l111_l1_(l1l1ll1111l_l1_,l11_l1_):
	url = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ㡻")][3]
	user = l1l1l1l1lll_l1_(32)
	l1111l111l1_l1_ = l111lll1l11_l1_()
	l1lll11ll111_l1_ = l1111l111l1_l1_.split(l1l111_l1_ (u"ࠬ࠲ࠧ㡼"))[2]
	l1lllll111l1_l1_ = l1l1lll1l1ll_l1_()
	payload = {l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㡽"):user,l1l111_l1_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ㡾"):l1l11l11111_l1_,l1l111_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ㡿"):l1lll11ll111_l1_,l1l111_l1_ (u"ࠩ࡬ࡨࡸ࠭㢀"):l1ll1ll1ll11_l1_(l1lllll111l1_l1_)}
	if not l1l1ll1111l_l1_: l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㢁"),(l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㢂"),url,payload,l1l111_l1_ (u"ࠬ࠭㢃"),l1l111_l1_ (u"࠭ࠧ㢄"),l1l111_l1_ (u"ࠧࠨ㢅")))
	settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㢆"),l1l111_l1_ (u"ࠩࠪ㢇"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㢈"),url,payload,l1l111_l1_ (u"ࠫࠬ㢉"),l1l111_l1_ (u"ࠬ࠭㢊"),l1l111_l1_ (u"࠭ࠧ㢋"),l1l111_l1_ (u"ࠧࡎࡇࡑ࡙ࡘ࠳ࡓࡉࡑ࡚ࡣࡒࡋࡓࡔࡃࡊࡉࡘ࠳࠱ࡴࡶࠪ㢌"),True,True)
	l11lll1l111_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭㢍"))
	if not l11lll1l111_l1_: l11lll1l111_l1_ = l1l111_l1_ (u"ࠩࡑࡉ࡜࠭㢎")
	l1lll1111lll_l1_ = l11lll1l111_l1_
	if not response.succeeded: l1lll1111lll_l1_ = l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࠩ㢏")
	else:
		l1l11l1l1l1_l1_,l1111l1l1ll_l1_,l1111ll1lll_l1_,l11l111lll1_l1_ = l1l111_l1_ (u"ࠫࠬ㢐"),l1l111_l1_ (u"ࠬ࠭㢑"),l1l111_l1_ (u"࠭ࠧ㢒"),[]
		newfile = response.content
		if newfile:
			l11l111lll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ㢓"),newfile)
			for l1llll11lll1_l1_,l1ll11ll1lll_l1_,message in l11l111lll1_l1_:
				if kodi_version>18.99: message = message.encode(l1l111_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㢔")).decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㢕"))
				if l1llll11lll1_l1_==l1l111_l1_ (u"ࠪ࠴ࠬ㢖"): l1l11l1l1l1_l1_ += message+l1l111_l1_ (u"ࠫ࠿ࡀࠧ㢗")
				else: l1111l1l1ll_l1_ += message+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㢘")
			l1111l1l1ll_l1_ = l1111l1l1ll_l1_.strip(l1l111_l1_ (u"࠭࡜࡯ࠩ㢙"))
			l1l11l1l1l1_l1_ = l1l11l1l1l1_l1_.strip(l1l111_l1_ (u"ࠧ࠻࠼ࠪ㢚"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ㢛"),l1l11l1l1l1_l1_)
		settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭ࠪ㢜"),l1ll1ll1ll11_l1_(now))
		if os.path.exists(l1l1ll111lll_l1_): l1111ll1lll_l1_ = open(l1l1ll111lll_l1_,l1l111_l1_ (u"ࠪࡶࡧ࠭㢝")).read()
		if kodi_version>18.99: l1111l1l1ll_l1_ = l1111l1l1ll_l1_.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㢞"))
		if l1111l1l1ll_l1_!=l1111ll1lll_l1_:
			l1lll1111lll_l1_ = l1l111_l1_ (u"ࠬࡔࡅࡘࠩ㢟")
			try: open(l1l1ll111lll_l1_,l1l111_l1_ (u"࠭ࡷࡣࠩ㢠")).write(l1111l1l1ll_l1_)
			except: pass
		if l11_l1_:
			l11l111lll1_l1_ = sorted(l11l111lll1_l1_,reverse=True,key=lambda key: int(key[0]))
			l1111ll1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ㢡")
			for l1llll11lll1_l1_,l1ll11ll1lll_l1_,message in l11l111lll1_l1_:
				if kodi_version>18.99: message = message.encode(l1l111_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㢢")).decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㢣"))
				if l1111ll1ll1_l1_: l1111ll1ll1_l1_ += l1l111_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ㢤")
				if l1llll11lll1_l1_==l1l111_l1_ (u"ࠫ࠵࠭㢥"): continue
				date = message.split(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㢦"))[0]
				l11l1ll1111_l1_ = l1l111_l1_ (u"࠭ࠧ㢧")
				if l1ll11ll1lll_l1_:
					l11l1ll1111_l1_ = l1l111_l1_ (u"ࠧาีส่ฮࠦฮศืฬࠤ้้ࠠโไฺࠫ㢨")
					if kodi_version>18.99: l11l1ll1111_l1_ = l11l1ll1111_l1_.encode(l1l111_l1_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭㢩")).decode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㢪"))
				l1111ll1ll1_l1_ += message.replace(date,l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㢫")+date+l11l1ll1111_l1_+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㢬"))+l1l111_l1_ (u"ࠬࡢ࡮ࠨ㢭")
			l1111ll1ll1_l1_ = escapeUNICODE(l1111ll1ll1_l1_)
			l1l11ll11l_l1_(l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㢮"),l1l111_l1_ (u"ࠧาีสส้ࠦๅ็ࠢส่๊ฮัๆฮࠣษ้๏ࠠๆีอาิ๋๊ࠡษ็ฬึ์วๆฮࠪ㢯"),l1111ll1ll1_l1_,l1l111_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ㢰"))
			l1lll1111lll_l1_ = l1l111_l1_ (u"ࠩࡒࡐࡉ࠭㢱")
		if l1lll1111lll_l1_!=l11lll1l111_l1_:
			settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㢲"),l1lll1111lll_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㢳"))
	return l1lll1111lll_l1_
def PING(host,port):
	from socket import socket,AF_INET,SOCK_STREAM
	sock = socket(AF_INET,SOCK_STREAM)
	sock.settimeout(1)
	l1ll111ll11l_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l1ll111ll11l_l1_ = False
	l11lll11l1l_l1_ = time.time()
	if l1ll111ll11l_l1_: resp = l11lll11l1l_l1_-t1
	return resp
def FIX_ALL_DATABASES(l11_l1_):
	if l11_l1_:
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠬ࠭㢴"),l1l111_l1_ (u"࠭ࠧ㢵"),l1l111_l1_ (u"ࠧࠨ㢶"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㢷"),l1l111_l1_ (u"ࠩึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอหีๅษะࠤํะๆู์ไࠤัฺ๋๊ࠢๅ์ฬ฿ฯࠡษ็ฬ๏อๆศฬࠣ์ฬ๊ใศึࠣห้๋ำหะา้ฮࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏ฺ๊ࠠ็็๎ฮࠦวๅฬ้฼๏็ࠠศๆล๊ࠥลࠡࠨ㢸"))
	else: l1llll1l1l_l1_ = True
	if l1llll1l1l_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l1l111_l1_ (u"ࠪ࠲ࡩࡨࠧ㢹")) and l1l111_l1_ (u"ࠫࡩࡧࡴࡢࠩ㢺") in filename:
				l1lll1111l_l1_ = os.path.join(addoncachefolder,filename)
				try: conn,l1lllll1ll_l1_ = l1l1ll1l111_l1_(l1lll1111l_l1_)
				except: return
				l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯࡮ࡵࡧࡪࡶ࡮ࡺࡹࡠࡥ࡫ࡩࡨࡱ࠻ࠨ㢻"))
				l1lllll1ll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦ࡯ࡱࡶ࡬ࡱ࡮ࢀࡥ࠼ࠩ㢼"))
				l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨ㢽"))
				conn.commit()
				conn.close()
		if l11_l1_:
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㢾"),l1l111_l1_ (u"ࠩࠪ㢿"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㣀"),l1l111_l1_ (u"ࠫฯ๋สࠡส้ะฬำฺࠠ็็๎ฮࠦลึๆสัࠥ๎ส็ฺํๅࠥาๅ๋฻ࠣๆํอูะࠢส่อ๐ว็ษอࠤํอไไษืࠤฬ๊ๅิฬัำ๊ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ㣁"))
	return
def l1ll11l11l11_l1_(word):
	if l1l111_l1_ (u"ࠬࡡࠧ㣂") in word and l1l111_l1_ (u"࠭࡝ࠨ㣃") in word:
		l11ll111lll_l1_ = [l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㣄"),l1l111_l1_ (u"ࠨ࡝࠲ࡖ࡙ࡒ࡝ࠨ㣅"),l1l111_l1_ (u"ࠩ࡞࠳ࡑࡋࡆࡕ࡟ࠪ㣆"),l1l111_l1_ (u"ࠪ࡟࠴ࡘࡉࡈࡊࡗࡡࠬ㣇"),l1l111_l1_ (u"ࠫࡠ࠵ࡃࡆࡐࡗࡉࡗࡣࠧ㣈"),l1l111_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ㣉"),l1l111_l1_ (u"࡛࠭ࡍࡇࡉࡘࡢ࠭㣊"),l1l111_l1_ (u"ࠧ࡜ࡔࡌࡋࡍ࡚࡝ࠨ㣋"),l1l111_l1_ (u"ࠨ࡝ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ㣌")]
		l11l1ll111l_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡟࡟ࡈࡕࡌࡐࡔࠣ࠲࠯ࡅ࡜࡞ࠩ㣍"),word,re.DOTALL)
		l11l1ll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡠࡉࡏࡍࡑࡕ࠾࠿ࡀ࠮ࠫࡁ࡟ࡡࠬ㣎"),word,re.DOTALL)
		l1ll11ll11ll_l1_ = l11ll111lll_l1_+l11l1ll111l_l1_+l11l1ll11l1_l1_
		for tag in l1ll11ll11ll_l1_: word = word.replace(tag,l1l111_l1_ (u"ࠫࠬ㣏"))
	return word
def l1llll1l111l_l1_(l1l11111l1l_l1_,l111111llll_l1_,l1lll1l1l1l1_l1_,l1ll1l11lll1_l1_):
	from PIL import ImageDraw,ImageFont,Image
	l11ll111l11_l1_,l11l11l11ll_l1_,l1ll11111l11_l1_ = l1l111_l1_ (u"ࠬ࠭㣐"),0,15000
	l1l11111l1l_l1_ = l1l11111l1l_l1_.replace(l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࠧ㣑"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘ࠺࠻࠼ࠪ㣒"))
	l1l1lll11111_l1_ = ImageFont.truetype(l11111l1ll1_l1_,size=l111111llll_l1_)
	l1lll1l1l1l1_l1_ -= l111111llll_l1_*2
	l11l1l1l1ll_l1_ = Image.new(l1l111_l1_ (u"ࠨࡔࡊࡆࡆ࠭㣓"),(l1lll1l1l1l1_l1_,99),(255,255,255,0))
	l111l1lllll_l1_ = ImageDraw.Draw(l11l1l1l1ll_l1_)
	for l1ll111lll11_l1_ in l1l11111l1l_l1_.splitlines():
		l11l11l11ll_l1_ += l1ll1l11lll1_l1_
		l11111l1l11_l1_,newline = 0,l1l111_l1_ (u"ࠩࠪ㣔")
		for word in l1ll111lll11_l1_.split(l1l111_l1_ (u"ࠪࠤࠬ㣕")):
			l111l1l1111_l1_ = l1ll11l11l11_l1_(l1l111_l1_ (u"ࠫࠥ࠭㣖")+word)
			l1llll1ll1ll_l1_,l111l1l1l1l_l1_ = l111l1lllll_l1_.textsize(l111l1l1111_l1_,font=l1l1lll11111_l1_)
			if l11111l1l11_l1_+l1llll1ll1ll_l1_<l1lll1l1l1l1_l1_:
				if not newline: newline += word
				else: newline += l1l111_l1_ (u"ࠬࠦࠧ㣗")+word
				l11111l1l11_l1_ += l1llll1ll1ll_l1_
			else:
				if l1llll1ll1ll_l1_<l1lll1l1l1l1_l1_:
					newline += l1l111_l1_ (u"࠭࡜࡯ࠢࠪ㣘")+word
					l11l11l11ll_l1_ += l1ll1l11lll1_l1_
					l11111l1l11_l1_ = l1llll1ll1ll_l1_
				else:
					while l1llll1ll1ll_l1_>l1lll1l1l1l1_l1_:
						for l1l11l111l_l1_ in range(1,len(l1l111_l1_ (u"ࠧࠡࠩ㣙")+word),1):
							l111ll111ll_l1_ = l1l111_l1_ (u"ࠨࠢࠪ㣚")+word[:l1l11l111l_l1_]
							l111lllll11_l1_ = word[l1l11l111l_l1_:]
							l1lll1l1llll_l1_ = l1ll11l11l11_l1_(l111ll111ll_l1_)
							l11l1lll1ll_l1_,l1111llll1l_l1_ = l111l1lllll_l1_.textsize(l1lll1l1llll_l1_,font=l1l1lll11111_l1_)
							if l11111l1l11_l1_+l11l1lll1ll_l1_>l1lll1l1l1l1_l1_:
								l1lll11l1l1l_l1_ = l1llll1ll1ll_l1_-l11l1lll1ll_l1_
								newline += l111ll111ll_l1_+l1l111_l1_ (u"ࠩ࡟ࡲࠬ㣛")
								l11l11l11ll_l1_ += l1ll1l11lll1_l1_
								l1llll1ll1ll_l1_ = l1lll11l1l1l_l1_
								if l1lll11l1l1l_l1_>l1lll1l1l1l1_l1_:
									l11111l1l11_l1_ = 0
									word = l111lllll11_l1_
								else:
									l11111l1l11_l1_ = l1lll11l1l1l_l1_
									newline += l111lllll11_l1_
								break
				if l11l11l11ll_l1_>l1ll11111l11_l1_: break
		l11ll111l11_l1_ += l1l111_l1_ (u"ࠪࡠࡳ࠭㣜")+newline
		if l11l11l11ll_l1_>l1ll11111l11_l1_: break
	l11ll111l11_l1_ = l11ll111l11_l1_[1:]
	l11ll111l11_l1_ = l11ll111l11_l1_.replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕ࠾࠿ࡀࠧ㣝"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭㣞"))
	return l11ll111l11_l1_
def l11l1l111l1_l1_(text):
	text = text.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ㣟"),l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹ࡯࡭ࡳ࡫࡟ࠨ㣠"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ㣡"),l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡴ࡭ࡡࠪ㣢"))
	text = text.replace(l1l111_l1_ (u"ࠪ࡟ࡑࡋࡆࡕ࡟ࠪ㣣"),l1l111_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥ࡭ࡧࡩࡸࡤ࠭㣤"))
	text = text.replace(l1l111_l1_ (u"ࠬࡡࡒࡊࡉࡋࡘࡢ࠭㣥"),l1l111_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡵ࡭࡬࡮ࡴࡠࠩ㣦"))
	text = text.replace(l1l111_l1_ (u"ࠧ࡜ࡅࡈࡒ࡙ࡋࡒ࡞ࠩ㣧"),l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡭࡫ࡱࡩࡨ࡫࡮ࡵࡧࡵࡣࠬ㣨"))
	text = text.replace(l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㣩"),l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡨࡲࡩࡩ࡯࡭ࡱࡵࡣࠬ㣪"))
	l1lllll11111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡡࡃࡐࡎࡒࡖࠥ࠮࠮ࠫࡁࠬࡠࡢ࠭㣫"),text,re.DOTALL)
	for l1lll11l1111_l1_ in l1lllll11111_l1_: text = text.replace(l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࠭㣬")+l1lll11l1111_l1_+l1l111_l1_ (u"࠭࡝ࠨ㣭"),l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡮ࡦࡹࡦࡳࡱࡵࡲࠨ㣮")+l1lll11l1111_l1_+l1l111_l1_ (u"ࠨࡡࠪ㣯"))
	return text
def l1lllll1ll11_l1_(l1111llllll_l1_,l1ll11l11111_l1_,l111l111l11_l1_,header,text,profile,l11ll11111l_l1_,l1ll1lllllll_l1_,l1ll1ll11111_l1_):
	l1llllll1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ㣰"))
	if l1llllll1l1l_l1_:
		l1lll_l1_ = LANGUAGE_TRANSLATE([l1111llllll_l1_,l1ll11l11111_l1_,l111l111l11_l1_,header,text])
		if l1lll_l1_: l1111llllll_l1_,l1ll11l11111_l1_,l111l111l11_l1_,header,text = l1lll_l1_
	from PIL import ImageDraw,ImageFont,Image
	if kodi_version<19:
		text = text.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㣱"))
		header = header.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㣲"))
		l1111llllll_l1_ = l1111llllll_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㣳"))
		l1ll11l11111_l1_ = l1ll11l11111_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㣴"))
		l111l111l11_l1_ = l111l111l11_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㣵"))
	l111l1ll11l_l1_ = 5
	l1l1ll1lll1l_l1_ = 20
	l1llll111ll1_l1_ = 20
	l1lll11ll1l1_l1_ = 0
	l1l1111l111_l1_ = l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㣶")
	l1l1lllll1ll_l1_ = 0
	l1ll1111ll11_l1_ = 19
	l11l11l11l1_l1_ = 30
	l1lll1lllll1_l1_ = 8
	l1lll11l11ll_l1_ = True
	l1ll11l1111l_l1_ = 375
	l1l1lll11lll_l1_ = 410
	l1l1ll11l1ll_l1_ = 50
	l1ll1l1l1111_l1_ = 280
	l1111ll1l11_l1_ = 28
	l1l1llll1l1l_l1_ = 5
	l111lll111l_l1_ = 0
	l1lll1l1l11l_l1_ = 31
	l111lll11ll_l1_ = [36,32,28]
	if profile in [l1l111_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ㣷"),l1l111_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ㣸")]:
		if profile==l1l111_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ㣹"):
			l1l111111l1_l1_ = l1l111_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ㣺")
			l1l1111l111_l1_ = l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㣻")
			l1lll11l11ll_l1_ = True
			l1lll11ll1l1_l1_ = 10
		else:
			l1l111111l1_l1_ = 97+20
			l1l1111l111_l1_ = l1l111_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ㣼")
			l1lll11l11ll_l1_ = False
		l111lll11ll_l1_ = [33,33,33]
		l1llll111ll1_l1_ = 20
		l1l1ll1lll1l_l1_ = 0
		l11l11l11l1_l1_ = 20
		l1ll1111ll11_l1_ = 25+10
	elif profile==l1l111_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ㣽"): l111lll11ll_l1_ = [28,24,20] ; l1l111111l1_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧ㣾"): l111lll11ll_l1_ = [32,28,24] ; l1l111111l1_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ㣿"): l111lll11ll_l1_ = [36,32,28] ; l1l111111l1_l1_ = 500
	elif profile==l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ㤀"): l1l111111l1_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭㤁"): l1l111111l1_l1_ = l1l111_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ㤂")
	elif profile==l1l111_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࠬ㤃"): l111lll11ll_l1_ = [28,23,18] ; l1l111111l1_l1_ = 740
	elif profile==l1l111_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ㤄"): l111lll11ll_l1_ = [28,23,18] ; l1l111111l1_l1_ = l1l111_l1_ (u"ࠩࡘࡔࡕࡋࡒࠨ㤅")
	l111111ll1l_l1_ = l111lll11ll_l1_[0]
	l11l1111111_l1_ = l111lll11ll_l1_[1]
	l11lllllll1_l1_ = l111lll11ll_l1_[2]
	l11111l1lll_l1_ = ImageFont.truetype(l11111l1ll1_l1_,size=l111111ll1l_l1_)
	l1llll11l1ll_l1_ = ImageFont.truetype(l11111l1ll1_l1_,size=l11l1111111_l1_)
	l1llll1lllll_l1_ = ImageFont.truetype(l11111l1ll1_l1_,size=l11lllllll1_l1_)
	l11l1l1l1ll_l1_ = Image.new(l1l111_l1_ (u"ࠪࡖࡌࡈࡁࠨ㤆"),(100,100),(255,255,255,0))
	l111l1lllll_l1_ = ImageDraw.Draw(l11l1l1l1ll_l1_)
	l1ll111l11ll_l1_,l1ll1lll11l1_l1_ = l111l1lllll_l1_.textsize(l1l111_l1_ (u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭㤇"),font=l1llll11l1ll_l1_)
	l1ll111llll1_l1_,l1111lll1l1_l1_ = l111l1lllll_l1_.textsize(l1l111_l1_ (u"ࠬࡎࡈࡉࠢࡅࡆࡇࠦ࠸࠹࠺ࠣ࠴࠵࠶ࠧ㤈"),font=l11111l1lll_l1_)
	l1l1llllll1l_l1_ = header.count(l1l111_l1_ (u"࠭࡜࡯ࠩ㤉"))+1
	l11l1lll111_l1_ = l1l1ll1lll1l_l1_+l1l1llllll1l_l1_*(l1111lll1l1_l1_+l1lll11ll1l1_l1_)-l1lll11ll1l1_l1_
	l1lll1111l11_l1_ = {l1l111_l1_ (u"ࠧࡥࡧ࡯ࡩࡹ࡫࡟ࡩࡣࡵࡥࡰࡧࡴࠨ㤊"):False,l1l111_l1_ (u"ࠨࡵࡸࡴࡵࡵࡲࡵࡡ࡯࡭࡬ࡧࡴࡶࡴࡨࡷࠬ㤋"):True,l1l111_l1_ (u"ࠩࡄࡖࡆࡈࡉࡄࠢࡏࡍࡌࡇࡔࡖࡔࡈࠤࡆࡒࡌࡂࡊࠪ㤌"):False}
	from arabic_reshaper import ArabicReshaper
	l11l1ll1lll_l1_ = ArabicReshaper(configuration=l1lll1111l11_l1_)
	if text:
		l11llllll11_l1_ = l1ll1lllllll_l1_-l11l11l11l1_l1_*2
		l1ll1111l1ll_l1_ = l1ll1lll11l1_l1_+l1lll1lllll1_l1_
		l1lll111l11l_l1_ = l11l1ll1lll_l1_.reshape(text)
		if l1lll11l11ll_l1_:
			l1l1ll1111l1_l1_ = l1llll1l111l_l1_(l1lll111l11l_l1_,l11l1111111_l1_,l11llllll11_l1_,l1ll1111l1ll_l1_)
			l1llllll111l_l1_ = l1ll11l11l11_l1_(l1l1ll1111l1_l1_)
			l1lll11111l1_l1_ = l1llllll111l_l1_.count(l1l111_l1_ (u"ࠪࡠࡳ࠭㤍"))+1
			if l1lll11111l1_l1_<6:
				l1ll11l111ll_l1_ = l11llllll11_l1_
				l1l1ll1111l1_l1_ = l1llll1l111l_l1_(l1lll111l11l_l1_,l11l1111111_l1_,l1ll11l111ll_l1_,l1ll1111l1ll_l1_)
				l1llllll111l_l1_ = l1ll11l11l11_l1_(l1l1ll1111l1_l1_)
				l1lll11111l1_l1_ = l1llllll111l_l1_.count(l1l111_l1_ (u"ࠫࡡࡴࠧ㤎"))+1
			l11ll1l1ll1_l1_ = l1ll1111ll11_l1_+l1lll11111l1_l1_*l1ll1111l1ll_l1_-l1lll1lllll1_l1_
		else:
			l11ll1l1ll1_l1_ = l1ll1111ll11_l1_+l1ll1lll11l1_l1_
			l1llllll111l_l1_ = l1lll111l11l_l1_.split(l1l111_l1_ (u"ࠬࡢ࡮ࠨ㤏"))[0]
			l1l1ll1111l1_l1_ = l1lll111l11l_l1_.split(l1l111_l1_ (u"࠭࡜࡯ࠩ㤐"))[0]
	else: l11ll1l1ll1_l1_ = l1ll1111ll11_l1_
	l1lll1l111l1_l1_ = l111lll111l_l1_+l1lll1l1l11l_l1_
	if l1ll1ll11111_l1_:
		l1ll11llllll_l1_ = l1l1lll11lll_l1_-l1ll11l1111l_l1_
		l1lll1l111l1_l1_ += l1ll11llllll_l1_
	else: l1ll11llllll_l1_ = 0
	if l1111llllll_l1_ or l1ll11l11111_l1_ or l111l111l11_l1_: l1lll1l111l1_l1_ += l1l1ll11l1ll_l1_
	if l1l111111l1_l1_!=l1l111_l1_ (u"ࠧࡖࡒࡓࡉࡗ࠭㤑"): l111lll1111_l1_ = l1l111111l1_l1_
	else: l111lll1111_l1_ = l11l1lll111_l1_+l11ll1l1ll1_l1_+l1lll1l111l1_l1_
	l1lllll11lll_l1_ = l111lll1111_l1_-l11l1lll111_l1_-l1lll1l111l1_l1_-l1ll1111ll11_l1_
	l11l1l1l1ll_l1_ = Image.new(l1l111_l1_ (u"ࠨࡔࡊࡆࡆ࠭㤒"),(l1ll1lllllll_l1_,l111lll1111_l1_),(255,255,255,0))
	l111l1lllll_l1_ = ImageDraw.Draw(l11l1l1l1ll_l1_)
	if not l1ll11l11111_l1_ and l1111llllll_l1_ and l111l111l11_l1_:
		l1111ll1l11_l1_ += 105
		l1l1llll1l1l_l1_ -= 110
	if header:
		l111l1ll1l1_l1_ = l1l1ll1lll1l_l1_
		header = bidi.algorithm.get_display(l11l1ll1lll_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1lll111ll1l_l1_ = l111l1lllll_l1_.textsize(line,font=l11111l1lll_l1_)
				if l1l1111l111_l1_==l1l111_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㤓"): l1ll11l1l111_l1_ = l111l1ll11l_l1_+(l1ll1lllllll_l1_-width)/2
				elif l1l1111l111_l1_==l1l111_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ㤔"): l1ll11l1l111_l1_ = l111l1ll11l_l1_+l1ll1lllllll_l1_-width-l1llll111ll1_l1_
				elif l1l1111l111_l1_==l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㤕"): l1ll11l1l111_l1_ = l111l1ll11l_l1_+l1llll111ll1_l1_
				l111l1lllll_l1_.text((l1ll11l1l111_l1_,l111l1ll1l1_l1_),line,font=l11111l1lll_l1_,fill=l1l111_l1_ (u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ㤖"))
			l111l1ll1l1_l1_ += l111111ll1l_l1_+l1lll11ll1l1_l1_
	if l1111llllll_l1_ or l1ll11l11111_l1_ or l111l111l11_l1_:
		l11l1ll1ll1_l1_ = l11l1lll111_l1_+l1lllll11lll_l1_+l1ll1111ll11_l1_+l1ll11llllll_l1_+l111lll111l_l1_
		if l1111llllll_l1_:
			l1111llllll_l1_ = bidi.algorithm.get_display(l11l1ll1lll_l1_.reshape(l1111llllll_l1_))
			l1ll1lll1lll_l1_,l111ll1l1ll_l1_ = l111l1lllll_l1_.textsize(l1111llllll_l1_,font=l1llll1lllll_l1_)
			l111lll11l1_l1_ = l1111ll1l11_l1_+0*(l1l1llll1l1l_l1_+l1ll1l1l1111_l1_)+(l1ll1l1l1111_l1_-l1ll1lll1lll_l1_)/2
			l111l1lllll_l1_.text((l111lll11l1_l1_,l11l1ll1ll1_l1_),l1111llllll_l1_,font=l1llll1lllll_l1_,fill=l1l111_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭㤗"))
		if l1ll11l11111_l1_:
			l1ll11l11111_l1_ = bidi.algorithm.get_display(l11l1ll1lll_l1_.reshape(l1ll11l11111_l1_))
			l1lll1llllll_l1_,l1lll1l1ll1l_l1_ = l111l1lllll_l1_.textsize(l1ll11l11111_l1_,font=l1llll1lllll_l1_)
			l111lllllll_l1_ = l1111ll1l11_l1_+1*(l1l1llll1l1l_l1_+l1ll1l1l1111_l1_)+(l1ll1l1l1111_l1_-l1lll1llllll_l1_)/2
			l111l1lllll_l1_.text((l111lllllll_l1_,l11l1ll1ll1_l1_),l1ll11l11111_l1_,font=l1llll1lllll_l1_,fill=l1l111_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ㤘"))
		if l111l111l11_l1_:
			l111l111l11_l1_ = bidi.algorithm.get_display(l11l1ll1lll_l1_.reshape(l111l111l11_l1_))
			l11l1l1l1l1_l1_,l1111lll111_l1_ = l111l1lllll_l1_.textsize(l111l111l11_l1_,font=l1llll1lllll_l1_)
			l111111111l_l1_ = l1111ll1l11_l1_+2*(l1l1llll1l1l_l1_+l1ll1l1l1111_l1_)+(l1ll1l1l1111_l1_-l11l1l1l1l1_l1_)/2
			l111l1lllll_l1_.text((l111111111l_l1_,l11l1ll1ll1_l1_),l111l111l11_l1_,font=l1llll1lllll_l1_,fill=l1l111_l1_ (u"ࠨࡻࡨࡰࡱࡵࡷࠨ㤙"))
	if text:
		l1l1ll1l1ll1_l1_,l11l1l1llll_l1_ = [],[]
		l1l1ll1111l1_l1_ = l11l1l111l1_l1_(l1l1ll1111l1_l1_)
		l1ll111l1lll_l1_ = l1l1ll1111l1_l1_.split(l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠࡰࡨࡻࡱ࡯࡮ࡦࡡࠪ㤚"))
		for l1l1lll1ll1l_l1_ in l1ll111l1lll_l1_:
			l11ll1lll11_l1_ = l11ll11111l_l1_
			if   l1l111_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡ࡯࡭ࡳ࡫࡬ࡦࡨࡷࡣࠬ㤛") in l1l1lll1ll1l_l1_: l11ll1lll11_l1_ = l1l111_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ㤜")
			elif l1l111_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴ࡬࡫࡭ࡺ࡟ࠨ㤝") in l1l1lll1ll1l_l1_: l11ll1lll11_l1_ = l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㤞")
			elif l1l111_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡧࡪࡴࡴࡦࡴࡢࠫ㤟") in l1l1lll1ll1l_l1_: l11ll1lll11_l1_ = l1l111_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ㤠")
			l11lll11l11_l1_ = l1l1lll1ll1l_l1_
			l11ll111lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࠰࠭ࡃࡤ࠭㤡"),l1l1lll1ll1l_l1_,re.DOTALL)
			for tag in l11ll111lll_l1_: l11lll11l11_l1_ = l11lll11l11_l1_.replace(tag,l1l111_l1_ (u"ࠪࠫ㤢"))
			if l11lll11l11_l1_==l1l111_l1_ (u"ࠫࠬ㤣"): width,l1lll111ll1l_l1_ = 0,l1ll1111l1ll_l1_
			else: width,l1lll111ll1l_l1_ = l111l1lllll_l1_.textsize(l11lll11l11_l1_,font=l1llll11l1ll_l1_)
			if   l11ll1lll11_l1_==l1l111_l1_ (u"ࠬࡲࡥࡧࡶࠪ㤤"): l1111l11l11_l1_ = l1l1lllll1ll_l1_+l11l11l11l1_l1_
			elif l11ll1lll11_l1_==l1l111_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ㤥"): l1111l11l11_l1_ = l1l1lllll1ll_l1_+l11l11l11l1_l1_+l11llllll11_l1_-width
			elif l11ll1lll11_l1_==l1l111_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㤦"): l1111l11l11_l1_ = l1l1lllll1ll_l1_+l11l11l11l1_l1_+(l11llllll11_l1_-width)/2
			if l1111l11l11_l1_<l11l11l11l1_l1_: l1111l11l11_l1_ = l1l1lllll1ll_l1_+l11l11l11l1_l1_
			l1l1ll1l1ll1_l1_.append(l1111l11l11_l1_)
			l11l1l1llll_l1_.append(width)
		l1111l11l11_l1_ = l1l1ll1l1ll1_l1_[0]
		l1ll11l11l1l_l1_ = l1l1ll1111l1_l1_.split(l1l111_l1_ (u"ࠨࡡࡶࡷࡸࡥࠧ㤧"))
		l11llll1111_l1_ = (255,255,255,255)
		l1llll1l1111_l1_ = l11llll1111_l1_
		l1ll1111l1l1_l1_,l1lll1ll1ll1_l1_ = 0,0
		l1llllllllll_l1_ = False
		l111l11l111_l1_ = 0
		l1l1llllll11_l1_ = l11l1lll111_l1_+l1ll1111ll11_l1_/2
		if l11ll1l1ll1_l1_<(l1lllll11lll_l1_+l1ll1111ll11_l1_):
			l111l1l1ll1_l1_ = (l1lllll11lll_l1_+l1ll1111ll11_l1_-l11ll1l1ll1_l1_)/2
			l1l1llllll11_l1_ = l11l1lll111_l1_+l1ll1111ll11_l1_+l111l1l1ll1_l1_-l1ll1lll11l1_l1_/2
		for line in l1ll11l11l1l_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1ll11llll11_l1_ = line.split(l1l111_l1_ (u"ࠩࡢࡲࡪࡽ࡬ࡪࡰࡨࡣࠬ㤨"),1)
			l1ll11llll1l_l1_ = line.split(l1l111_l1_ (u"ࠪࡣࡳ࡫ࡷࡤࡱ࡯ࡳࡷ࠭㤩"),1)
			l1ll11lllll1_l1_ = line.split(l1l111_l1_ (u"ࠫࡤ࡫࡮ࡥࡥࡲࡰࡴࡸ࡟ࠨ㤪"),1)
			l1ll11lll111_l1_ = line.split(l1l111_l1_ (u"ࠬࡥ࡬ࡪࡰࡨࡶࡹࡲ࡟ࠨ㤫"),1)
			l1llll1lll11_l1_ = line.split(l1l111_l1_ (u"࠭࡟࡭࡫ࡱࡩࡱ࡫ࡦࡵࡡࠪ㤬"),1)
			l1ll11lll1l1_l1_ = line.split(l1l111_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡸࡩࡨࡪࡷࡣࠬ㤭"),1)
			l1ll11lll1ll_l1_ = line.split(l1l111_l1_ (u"ࠨࡡ࡯࡭ࡳ࡫ࡣࡦࡰࡷࡩࡷࡥࠧ㤮"),1)
			if len(l1ll11llll11_l1_)>1:
				l111l11l111_l1_ += 1
				line = l1ll11llll11_l1_[1]
				l1ll1111l1l1_l1_ = 0
				l1111l11l11_l1_ = l1l1ll1l1ll1_l1_[l111l11l111_l1_]
				l1lll1ll1ll1_l1_ += l1ll1111l1ll_l1_
				l1llllllllll_l1_ = False
			elif len(l1ll11llll1l_l1_)>1:
				line = l1ll11llll1l_l1_[1]
				l1llll1l1111_l1_ = line[0:8]
				l1llll1l1111_l1_ = l1l111_l1_ (u"ࠩࠦࠫ㤯")+l1llll1l1111_l1_[2:]
				line = line[9:]
			elif len(l1ll11lllll1_l1_)>1:
				line = l1ll11lllll1_l1_[1]
				l1llll1l1111_l1_ = l11llll1111_l1_
			elif len(l1ll11lll111_l1_)>1:
				line = l1ll11lll111_l1_[1]
				l1llllllllll_l1_ = True
				l1ll1111l1l1_l1_ = l11l1l1llll_l1_[l111l11l111_l1_]
			elif len(l1llll1lll11_l1_)>1:
				line = l1llll1lll11_l1_[1]
			elif len(l1ll11lll1l1_l1_)>1:
				line = l1ll11lll1l1_l1_[1]
			elif len(l1ll11lll1ll_l1_)>1:
				line = l1ll11lll1ll_l1_[1]
			if line:
				l1ll1l11llll_l1_ = l1l1llllll11_l1_+l1lll1ll1ll1_l1_
				line = bidi.algorithm.get_display(line)
				width,l1lll111ll1l_l1_ = l111l1lllll_l1_.textsize(line,font=l1llll11l1ll_l1_)
				if l1llllllllll_l1_: l1ll1111l1l1_l1_ -= width
				l1111l111ll_l1_ = l1111l11l11_l1_+l1ll1111l1l1_l1_
				l111l1lllll_l1_.text((l1111l111ll_l1_,l1ll1l11llll_l1_),line,font=l1llll11l1ll_l1_,fill=l1llll1l1111_l1_)
				if not l1llllllllll_l1_: l1ll1111l1l1_l1_ += width
				if l1ll1l11llll_l1_>l1lllll11lll_l1_+l1ll1111l1ll_l1_: break
	l1lll1111111_l1_ = l1l1ll1lllll_l1_.replace(l1l111_l1_ (u"ࠪࡣ࠵࠶࠰࠱ࡡࠪ㤰"),l1l111_l1_ (u"ࠫࡤ࠭㤱")+str(time.time())+l1l111_l1_ (u"ࠬࡥࠧ㤲"))
	l1lll1111111_l1_ = l1lll1111111_l1_.replace(l1l111_l1_ (u"࠭࡜࡝ࠩ㤳"),l1l111_l1_ (u"ࠧ࡝࡞࡟ࡠࠬ㤴")).replace(l1l111_l1_ (u"ࠨ࠱࠲ࠫ㤵"),l1l111_l1_ (u"ࠩ࠲࠳࠴࠵ࠧ㤶"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	l11l1l1l1ll_l1_.save(l1lll1111111_l1_)
	return l1lll1111111_l1_,l111lll1111_l1_
def l1111l1ll1l_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l111_l1_=True,l1ll1lll11ll_l1_=True):
	if allow_redirects==l1l111_l1_ (u"ࠪࠫ㤷"): allow_redirects = True
	if l11_l1_==l1l111_l1_ (u"ࠫࠬ㤸"): l11_l1_ = True
	if l11ll11l111_l1_==l1l111_l1_ (u"ࠬ࠭㤹"): l11ll11l111_l1_ = True
	if l1ll1lll11ll_l1_==l1l111_l1_ (u"࠭ࠧ㤺"): l1ll1lll11ll_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	l1lll11l11l1_l1_ = list(headers.keys())
	if l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㤻") not in l1lll11l11l1_l1_: headers[l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㤼")] = l1l111_l1_ (u"ࠩࡃࡄࡅ࡙ࡋࡊࡒࡢࡌࡊࡇࡄࡆࡔࡃࡄࡅ࠭㤽")
	l1lllll1_l1_,l1ll111l111l_l1_,l1ll1lll1ll1_l1_,l1ll1l1lll11_l1_ = l1l1llll1ll1_l1_(url)
	l1l1ll1ll1ll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ㤾"))
	l1ll11111l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㤿"))
	l1ll111ll1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ㥀"))
	l1ll1ll1llll_l1_ = (l1ll111l111l_l1_==None and l1ll1lll1ll1_l1_==None and l1ll1l1lll11_l1_==None)
	l111l1l1lll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㥁")]
	l1ll111111ll_l1_ = l1lllll1_l1_ in l111l1l1lll_l1_
	l111ll1111l_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭㥂")]
	l11ll11ll1l_l1_ = l1lllll1_l1_ in l111ll1111l_l1_
	l111ll11lll_l1_ = l1ll111111ll_l1_ or l11ll11ll1l_l1_
	if l1ll1ll1llll_l1_ and l111ll11lll_l1_:
		if l1ll111111ll_l1_:
			l1lllll11ll1_l1_ = l111l1l1lll_l1_.index(l1lllll1_l1_)
			l1111l11l1l_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬ㥃")][l1lllll11ll1_l1_]
			l111l111l1l_l1_ = l1111l1lll1_l1_[l1lllll11ll1_l1_]
		elif l11ll11ll1l_l1_:
			l1lllll11ll1_l1_ = l111ll1111l_l1_.index(l1lllll1_l1_)
			l1111l11l1l_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔࠬ㥄")][l1lllll11ll1_l1_]
			l111l111l1l_l1_ = l11l111l1ll_l1_[l1lllll11ll1_l1_]
	if l1ll1lll1ll1_l1_==l1l111_l1_ (u"ࠪࠫ㥅"): l1ll1lll1ll1_l1_ = l1l1ll1ll1ll_l1_
	elif l1ll1lll1ll1_l1_==None and l1ll11111l1l_l1_ in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㥆"),l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㥇")] and l11ll11l111_l1_: l1ll1lll1ll1_l1_ = l1l1ll1ll1ll_l1_
	l1ll1lll1l11_l1_ = l1lllll1_l1_==l1l11l1_l1_[l1l111_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㥈")][7]
	if source==l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠷ࡷࡪࠧ㥉"): l1l1111l1ll_l1_ = 120
	elif source==l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡕࡉ࡛ࡋࡒࡔࡑࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ㥊"): l1l1111l1ll_l1_ = 20
	elif source==l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪ㥋"): l1l1111l1ll_l1_ = 20
	elif source in l1lllll11l11_l1_: l1l1111l1ll_l1_ = 10
	elif l1ll111111ll_l1_ or l11ll11ll1l_l1_: l1l1111l1ll_l1_ = 15
	elif l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑࠬ㥌") in source: l1l1111l1ll_l1_ = 70
	elif l1l111_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ㥍") in source: l1l1111l1ll_l1_ = 75
	elif l1l111_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ㥎") in source: l1l1111l1ll_l1_ = 25
	elif l1l111_l1_ (u"࠭ࡁࡉ࡙ࡄࡏࠬ㥏") in source: l1l1111l1ll_l1_ = 20
	elif l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ㥐") in source: l1l1111l1ll_l1_ = 20
	elif l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ㥑") in source: l1l1111l1ll_l1_ = 20
	elif l1l111_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ㥒") in source: l1l1111l1ll_l1_ = 25
	elif l1l111_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ㥓") in source: l1l1111l1ll_l1_ = 30
	else: l1l1111l1ll_l1_ = 15
	if l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㥔") in source and not data and l1l111_l1_ (u"ࠬࠬࠧ㥕") not in l1lllll1_l1_ and l1l111_l1_ (u"࠭࠿ࠨ㥖") not in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.rstrip(l1l111_l1_ (u"ࠧ࠰ࠩ㥗"))+l1l111_l1_ (u"ࠨ࠱ࠪ㥘")
	l11ll1l111l_l1_ = (l1ll111l111l_l1_!=None)
	l1ll1ll1l1ll_l1_ = (l1ll1lll1ll1_l1_!=None and l1ll11111l1l_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㥙"))
	if l11ll1l111l_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠪฮๆ฿๊ๅࠢหีํ้ำ๋ࠢิๆ๊࠭㥚"),l1ll111l111l_l1_)
	elif l1ll1ll1l1ll_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣࡈࡓ࡙ࠠาไ่ࠫ㥛"),l1ll1lll1ll1_l1_)
	if l11ll1l111l_l1_:
		proxies = {l1l111_l1_ (u"ࠧ࡮ࡴࡵࡲࠥ㥜"):l1ll111l111l_l1_,l1l111_l1_ (u"ࠨࡨࡵࡶࡳࡷࠧ㥝"):l1ll111l111l_l1_}
		l1lllll1lll1_l1_ = l1ll111l111l_l1_
	else: proxies,l1lllll1lll1_l1_ = {},l1l111_l1_ (u"ࠧࠨ㥞")
	if l1ll1ll1l1ll_l1_:
		import urllib3.util.connection as connection
		l111lllll1l_l1_ = l1l1lll1ll11_l1_(connection,l1l1ll1ll1ll_l1_)
	verify = True
	l1ll11l111l1_l1_,l1ll1l111lll_l1_,l1l11lll1_l1_,l11lll111ll_l1_,l11ll11llll_l1_ = allow_redirects,source,method,False,False
	if l1ll1lll1l11_l1_: l11ll11llll_l1_ = True
	if l111ll11lll_l1_ or allow_redirects: l1ll11l111l1_l1_ = False
	if l1ll111111ll_l1_: l1l11lll1_l1_ = l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㥟")
	import requests
	code,reason = -1,l1l111_l1_ (u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡉࡷࡸ࡯ࡳࠩ㥠")
	for l1l11l111l_l1_ in range(9):
		l1llll11ll1l_l1_ = True
		succeeded = False
		try:
			if l1l11l111l_l1_: l1ll1l111lll_l1_ = l1l111_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠲ࡵࡷࠫ㥡")
			if not l11ll1l111l_l1_: l1l1l11llll_l1_(l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡐࡒࡈࡒࡤ࡛ࡒࡍࠩ㥢"),l1lllll1_l1_,data,headers,l1ll1l111lll_l1_,l1l11lll1_l1_)
			try: response.close()
			except: pass
			l1llllll_l1_ = l1lllll1_l1_
			response = requests.request(l1l11lll1_l1_,l1lllll1_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1ll11l111l1_l1_,timeout=l1l1111l1ll_l1_,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l11lll111ll_l1_:
					l1llllll11l1_l1_ = list(response.headers.keys())
					if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㥣") in l1llllll11l1_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㥤")]
					elif l1l111_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ㥥") in l1llllll11l1_l1_: l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ㥦")]
					else: l11lll111ll_l1_ = True
					if not l11lll111ll_l1_: l1lllll1_l1_ = l1lllll1_l1_.encode(l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡯࡮࠮࠳ࠪ㥧"),l1l111_l1_ (u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪ㥨")).decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㥩"),l1l111_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ㥪"))
					if l111ll11lll_l1_ and response.status_code==307:
						l1ll11l111l1_l1_ = allow_redirects
						l1l11lll1_l1_ = method
						l11lll111ll_l1_ = True
						l1lll111lll1_l1_
				if not l11lll111ll_l1_ or allow_redirects:
					if l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㥫") not in l1lllll1_l1_:
						server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㥬"))
						l1lllll1_l1_ = server+l1l111_l1_ (u"ࠨ࠱ࠪ㥭")+l1lllll1_l1_
				if not l11lll111ll_l1_ and allow_redirects:
					l11l1l11l1_l1_ = l1l1111l11_l1_(l1lllll1_l1_)
					if l11l1l11l1_l1_ not in [l1l111_l1_ (u"ࠩ࠱ࡥࡻ࡯ࠧ㥮"),l1l111_l1_ (u"ࠪ࠲ࡹࡹࠧ㥯"),l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ㥰"),l1l111_l1_ (u"ࠬ࠴ࡡࡢࡥࠪ㥱"),l1l111_l1_ (u"࠭࠮࡮࡭ࡹࠫ㥲"),l1l111_l1_ (u"ࠧ࠯࡯ࡳ࠷ࠬ㥳"),l1l111_l1_ (u"ࠨ࠰ࡺࡩࡧࡳࠧ㥴")]: l1lll111lll1_l1_
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l11ll11llll_l1_ = True
			l1llllll_l1_ = response.url
			code = response.status_code
			reason = response.reason
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			if kodi_version<19: reason = str(err.message).split(l1l111_l1_ (u"ࠩ࠽ࠤࠬ㥵"))[1]
			else: reason = str(err).split(l1l111_l1_ (u"ࠪ࠾ࠥ࠭㥶"))[1]
		except requests.exceptions.ConnectionError as err:
			try:
				error = err.message[0]
				reason = error
				if l1l111_l1_ (u"ࠫࡊࡸࡲ࡯ࡱࠪ㥷") in error: code,reason = re.findall(l1l111_l1_ (u"ࠧࡢ࡛ࡆࡴࡵࡲࡴࠦࠨ࡝ࡦ࠮࠭ࡡࡣࠠࠩ࠰࠭ࡃ࠮࠭ࠢ㥸"),error)[0]
				elif l1l111_l1_ (u"࠭ࠬࠡࡧࡵࡶࡴࡸࠨࠨ㥹") in error: code,reason = re.findall(l1l111_l1_ (u"ࠢ࠭ࠢࡨࡶࡷࡵࡲ࡝ࠪࠫࡠࡩ࠱ࠩ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥ㥺"),error)[0]
				elif error.count(l1l111_l1_ (u"ࠨ࠼ࠪ㥻"))>=2: reason,code = re.findall(l1l111_l1_ (u"ࠩ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭ࠬ㥼"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			l1llll11ll1l_l1_ = False
			try: code = response.status_code
			except: pass
			try: reason = response.reason
			except: pass
		reason = str(reason)
		l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㥽"),l1l111_l1_ (u"ࠫ࠳ࠦࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡓࡑࡑࡑࡗࡊࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ㥾")+str(code)+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ㥿")+reason+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㦀")+source+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㦁")+l1lllll1_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㦂"))
		if l1llll11ll1l_l1_ and l111ll11lll_l1_ and not l11ll11llll_l1_ and code!=200:
			l1lllll1_l1_ = l1111l11l1l_l1_
			l11ll11llll_l1_ = True
			continue
		if l1llll11ll1l_l1_: break
	if l1ll1lll1ll1_l1_!=None and l1ll11111l1l_l1_!=l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㦃"): connection.create_connection = l111lllll1l_l1_
	if l1ll11111l1l_l1_==l1l111_l1_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ㦄") and l11ll11l111_l1_: l1ll1lll1ll1_l1_ = None
	if not succeeded and l1ll111l111l_l1_==None and source not in l1lllll11l11_l1_:
		l1111l1l1l1_l1_ = traceback.format_exc()
		sys.stderr.write(l1111l1l1l1_l1_)
	l1lll1l11_l1_ = l1l1ll1l1l1_l1_()
	l1lll1l11_l1_.url = l1llllll_l1_
	try: content = response.content
	except: content = l1l111_l1_ (u"ࠫࠬ㦅")
	try: headers = response.headers
	except: headers = {}
	try: cookies = response.cookies.get_dict()
	except: cookies = {}
	try: response.close()
	except: pass
	if kodi_version>18.99:
		try: content = content.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㦆"))
		except: pass
	code = int(code)
	l1lll1l11_l1_.code = code
	l1lll1l11_l1_.reason = reason
	l1lll1l11_l1_.content = content
	l1lll1l11_l1_.headers = headers
	l1lll1l11_l1_.cookies = cookies
	l1lll1l11_l1_.succeeded = succeeded
	if kodi_version<19 or isinstance(l1lll1l11_l1_.content,str): l1ll11111ll1_l1_ = l1lll1l11_l1_.content.lower()
	else: l1ll11111ll1_l1_ = l1l111_l1_ (u"࠭ࠧ㦇")
	l1lll1lll1l1_l1_ = (l1l111_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㦈") in l1ll11111ll1_l1_ or l1l111_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ㦉") in l1ll11111ll1_l1_) and l1ll11111ll1_l1_.count(l1l111_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ㦊"))>2 and l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ㦋") not in source and l1l111_l1_ (u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠭㦌") not in l1ll11111ll1_l1_
	if code==200 and l1lll1lll1l1_l1_: l1lll1l11_l1_.succeeded = False
	if l1lll1l11_l1_.succeeded and l1ll1ll1llll_l1_ and l111ll11lll_l1_:
		if l1ll1lll1l11_l1_: l111l111l1l_l1_ = l1l111_l1_ (u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭㦍")+data[l1l111_l1_ (u"࠭ࡪࡰࡤࠪ㦎")].upper().replace(l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㦏"),l1l111_l1_ (u"ࠨࠩ㦐"))
		l1lll11ll_l1_ = l1l1ll1ll1l_l1_(l111l111l1l_l1_)
	if not l1lll1l11_l1_.succeeded and l1ll1ll1llll_l1_:
		l1lll1lll111_l1_ = (l1l111_l1_ (u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭㦑") in l1ll11111ll1_l1_ and l1l111_l1_ (u"ࠪࡶࡦࡿࠠࡪࡦ࠽ࠤࠬ㦒") in l1ll11111ll1_l1_)
		l1lll1lll11l_l1_ = (l1l111_l1_ (u"ࠫ࠺ࠦࡳࡦࡥࠪ㦓") in l1ll11111ll1_l1_ and l1l111_l1_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭㦔") in l1ll11111ll1_l1_)
		l1lll1lll1ll_l1_ = (code in [403] and l1l111_l1_ (u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩ㦕") in l1ll11111ll1_l1_)
		l1lll1llll11_l1_ = (l1l111_l1_ (u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩ㦖") in l1ll11111ll1_l1_ and l1l111_l1_ (u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬ㦗") in l1ll11111ll1_l1_)
		if   l1lll1lll1l1_l1_: reason = l1l111_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ㦘")
		elif l1lll1lll111_l1_: reason = l1l111_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ㦙")
		elif l1lll1lll11l_l1_: reason = l1l111_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ㦚")
		elif l1lll1lll1ll_l1_: reason = l1l111_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡡࡤࡥࡨࡷࡸࠦࡤࡦࡰ࡬ࡩࡩ࠭㦛")
		elif l1lll1llll11_l1_: reason = l1l111_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ㦜")
		else: reason = str(reason)
		if source in l1lllll11l11_l1_:
			l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㦝"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ㦞")+str(code)+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㦟")+reason+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㦠")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㦡")+l1lllll1_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㦢"))
		else: l11lllll1l_l1_(l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㦣"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࠢࠣࡈ࡮ࡸࡥࡤࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ㦤")+str(code)+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ㦥")+reason+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㦦")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㦧")+l1lllll1_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ㦨"))
		l11111l111l_l1_ = l111l11_l1_(l1lllll1_l1_)
		if kodi_version<19 and isinstance(l11111l111l_l1_,unicode): l11111l111l_l1_ = l11111l111l_l1_.encode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㦩"))
		if l111ll11lll_l1_: l11111l111l_l1_ = l11111l111l_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ㦪"))[-1]
		reason = str(reason)+l1l111_l1_ (u"ࠧ࡝ࡰࠫࠤࠬ㦫")+l11111l111l_l1_+l1l111_l1_ (u"ࠨࠢࠬࠫ㦬")
		if l1lll1lll1l1_l1_ or l1lll1lll111_l1_ or l1lll1lll11l_l1_ or l1lll1lll1ll_l1_ or l1lll1llll11_l1_:
			code = -2
			l1lll1l11_l1_.code = code
			l1lll1l11_l1_.reason = reason
		l1llll1l1l_l1_ = True
		if (l1ll11111l1l_l1_==l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㦭") or l1ll111ll1l1_l1_==l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㦮")) and (l11ll11l111_l1_ or l1ll1lll11ll_l1_):
			l1llll1l1l_l1_ = l1llll1l1l1l_l1_(code,reason,source,l11_l1_)
			if l1llll1l1l_l1_ and l1ll11111l1l_l1_==l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㦯"): l1ll11111l1l_l1_ = l1l111_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ㦰")
			else: l1ll11111l1l_l1_ = l1l111_l1_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ㦱")
			if l1llll1l1l_l1_ and l1ll111ll1l1_l1_==l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㦲"): l1ll111ll1l1_l1_ = l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㦳")
			else: l1ll111ll1l1_l1_ = l1l111_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ㦴")
			settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ㦵"),l1ll11111l1l_l1_)
			settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭㦶"),l1ll111ll1l1_l1_)
		if l1llll1l1l_l1_:
			l1l1lll1111l_l1_ = True
			if code==8 and l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㦷") in l1lllll1_l1_ and l1l1lll1111l_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭㦸"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㦹"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠨࡾࡿࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭㦺")
				l1lll11ll_l1_ = l1111l1ll1l_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㦻"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㦼")+source+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㦽")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㦾"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭ๆอษะࠤออำหะาห๊ࠦࡓࡔࡎࠪ㦿"),l1l111_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ㧀"),time=2000)
				else:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㧁"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧂")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧃")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧄"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨ㧅"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧆"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll111ll1l1_l1_ in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㧇"),l1l111_l1_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ㧈")] and l1ll1lll11ll_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩ㧉"),l1l111_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ㧊"),time=2000)
				l1lll11ll_l1_ = l11ll11l1l1_l1_(method,l1lllll1_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ㧋"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ㧌")+source+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㧍")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㧎"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨ่ฯหาࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ㧏"),l1l111_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ㧐"),time=2000)
				else:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㧑"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ㧒")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㧓")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㧔"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧโึ็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬ㧕"),l1l111_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ㧖"),time=2000)
			if not l1lll1l11_l1_.succeeded and l1ll11111l1l_l1_ in [l1l111_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ㧗"),l1l111_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ㧘")] and l11ll11l111_l1_:
				if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭㧙"),l1l111_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ㧚"),time=2000)
				l1llllll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ㧛")
				l1lll11ll_l1_ = l1111l1ll1l_l1_(method,l1llllll_l1_,data,headers,allow_redirects,l11_l1_,source)
				if l1lll11ll_l1_.succeeded:
					l1lll1l11_l1_ = l1lll11ll_l1_
					l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㧜"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ㧝")+l1l1ll1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㧞")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧟")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧠"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ์ฬศฯࠣื๏ืแาࠢࡇࡒࡘ࠭㧡"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧢"),time=2000)
				else:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㧣"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬ㧤")+l1l1ll1ll1ll_l1_+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ㧥")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㧦")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㧧"))
					if l11_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬ㧨"),l1l111_l1_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ㧩"),time=2000)
		if l1ll111ll1l1_l1_==l1l111_l1_ (u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩ㧪") or l1ll11111l1l_l1_==l1l111_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ㧫"): l11_l1_ = False
		if not l1lll1l11_l1_.succeeded:
			if l11_l1_: l11lll11ll1_l1_ = l1llll1l1l1l_l1_(code,reason,source,l11_l1_)
			if code!=200 and source not in l11l11lllll_l1_ and l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭㧬") not in source:
				l1111111111_l1_(l1l111_l1_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡩࡽ࡯ࡴࠡࡦࡸࡩࠥࡺ࡯ࠡࡰࡨࡸࡼࡵࡲ࡬ࠢ࡬ࡷࡸࡻࡥࡴࠢࡺ࡭ࡹ࡮࠺ࠡࠩ㧭")+source)
	if settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㧮")) not in [l1l111_l1_ (u"ࠬࡇࡕࡕࡑࠪ㧯"),l1l111_l1_ (u"࠭ࡓࡕࡑࡓࠫ㧰"),l1l111_l1_ (u"ࠧࡂࡕࡎࠫ㧱")]: settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ㧲"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㧳"))
	if settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㧴")) not in [l1l111_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ㧵"),l1l111_l1_ (u"࡙ࠬࡔࡐࡒࠪ㧶"),l1l111_l1_ (u"࠭ࡁࡔࡍࠪ㧷")]: settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ㧸"),l1l111_l1_ (u"ࠨࡃࡖࡏࠬ㧹"))
	return l1lll1l11_l1_
def l11l1l_l1_(l1l1l11ll11_l1_,method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l111_l1_=True,l1ll1lll11ll_l1_=True):
	item = method,url,data,headers,allow_redirects,l11_l1_
	if l1l1l11ll11_l1_:
		response = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ㧺"),l1l111_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭㧻"),item)
		if response.succeeded:
			l1l1l11llll_l1_(l1l111_l1_ (u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫ㧼"),url,data,headers,source,method)
			return response
	response = l1111l1ll1l_l1_(method,url,data,headers,allow_redirects,l11_l1_,source,l11ll11l111_l1_,l1ll1lll11ll_l1_)
	if response.succeeded:
		if l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭㧽") in source: response.content = DECODE_ADILBO_HTML(response.content)
		if l1l1l11ll11_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ㧾"),item,response,l1l1l11ll11_l1_)
	return response
def l1l1llll_l1_(l1l1l11ll11_l1_,url,data,headers,l11_l1_,source):
	if not data or isinstance(data,dict): method = l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㧿")
	else:
		method = l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭㨀")
		data = l111l11_l1_(data)
		dummy,data = l1ll11ll1_l1_(data)
	response = l11l1l_l1_(l1l1l11ll11_l1_,method,url,data,headers,True,l11_l1_,source)
	html = response.content
	html = str(html)
	return html
def l1l1llll1ll1_l1_(url):
	l1ll111ll111_l1_ = url.split(l1l111_l1_ (u"ࠩࡿࢀࠬ㨁"))
	l1lllll1_l1_,l1ll111l111l_l1_,l1ll1lll1ll1_l1_,l1ll1l1lll11_l1_ = l1ll111ll111_l1_[0],None,None,None
	for item in l1ll111ll111_l1_:
		if l1l111_l1_ (u"ࠪࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ㨂") in item: l1ll111l111l_l1_ = item.split(l1l111_l1_ (u"ࠫࡂ࠭㨃"))[1]
		elif l1l111_l1_ (u"ࠬࡓࡹࡅࡐࡖ࡙ࡷࡲ࠽ࠨ㨄") in item: l1ll1lll1ll1_l1_ = item.split(l1l111_l1_ (u"࠭࠽ࠨ㨅"))[1]
		elif l1l111_l1_ (u"ࠧࡎࡻࡖࡗࡑ࡛ࡲ࡭࠿ࠪ㨆") in item: l1ll1l1lll11_l1_ = item.split(l1l111_l1_ (u"ࠨ࠿ࠪ㨇"))[1]
	return l1lllll1_l1_,l1ll111l111l_l1_,l1ll1lll1ll1_l1_,l1ll1l1lll11_l1_
def l11lll11111_l1_(name):
	start,l1ll1ll1ll1_l1_,modified = l1l111_l1_ (u"ࠩࠪ㨈"),l1l111_l1_ (u"ࠪࠫ㨉"),l1l111_l1_ (u"ࠫࠬ㨊")
	name = name.replace(ltr,l1l111_l1_ (u"ࠬ࠭㨋")).replace(rtl,l1l111_l1_ (u"࠭ࠧ㨌"))
	tmp = re.findall(l1l111_l1_ (u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧ㨍"),name,re.DOTALL)
	if tmp: start,l1ll1ll1ll1_l1_,name = tmp[0]
	if start not in [l1l111_l1_ (u"ࠨࠢࠪ㨎"),l1l111_l1_ (u"ࠩ࠯ࠫ㨏"),l1l111_l1_ (u"ࠪࠫ㨐")]: modified = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ㨑")
	if l1ll1ll1ll1_l1_: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠬࡥࠧ㨒")+l1ll1ll1ll1_l1_+l1l111_l1_ (u"࠭࡟ࠨ㨓")
	name = l1ll1ll1ll1_l1_+modified+name
	return name
def l1lll1llll1_l1_(url,l1ll1l1l1lll_l1_,l1ll1ll11ll1_l1_,l1lllll111ll_l1_,headers={}):
	l1l1ll11l11l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㨔"))
	l11l11l1l11_l1_ = settings.getSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪ㨕")+l1ll1l1l1lll_l1_)
	if l11l11l1l11_l1_: l1llllll_l1_ = url.replace(l1l1ll11l11l_l1_,l11l11l1l11_l1_)
	else:
		l1llllll_l1_ = url
		l11l11l1l11_l1_ = l1l1ll11l11l_l1_
	l1lll11ll_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㨖"),l1llllll_l1_,l1l111_l1_ (u"ࠪࠫ㨗"),headers,l1l111_l1_ (u"ࠫࠬ㨘"),l1l111_l1_ (u"ࠬ࠭㨙"),l1l111_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪ㨚"))
	html = l1lll11ll_l1_.content
	try: html = html.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㨛"),l1l111_l1_ (u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ㨜"))
	except: pass
	if not l1lll11ll_l1_.succeeded or l1lllll111ll_l1_ not in html:
		l1lllll1_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ㨝")+l1ll1ll11ll1_l1_
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㨞"):l1l111_l1_ (u"ࠫࠬ㨟")}
		l1lll1l11_l1_ = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㨠"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ㨡"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ㨢"),l1l111_l1_ (u"ࠨࠩ㨣"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭㨤"))
		if l1lll1l11_l1_.succeeded:
			html = l1lll1l11_l1_.content
			if kodi_version>18.99:
				try: html = html.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㨥"),l1l111_l1_ (u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ㨦"))
				except: pass
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰ࡷࡵࡰࡡࡅࡱ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ㨧"),html,re.DOTALL)
			l11111llll1_l1_ = [l11l11l1l11_l1_]
			for l1ll1ll_l1_ in l1ll_l1_:
				l11l11l1l11_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ㨨"))
				if l1l111_l1_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰࠫ㨩") in l1ll1ll_l1_: continue
				if l11l11l1l11_l1_ in l11111llll1_l1_: continue
				if len(l11111llll1_l1_)==9:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㨪"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥࡪࡩࡥࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨ㨫")+l1ll1l1l1lll_l1_+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨ㨬")+l1l1ll11l11l_l1_+l1l111_l1_ (u"ࠫࠥࡣࠧ㨭"))
					settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧ㨮")+l1ll1l1l1lll_l1_,l1l111_l1_ (u"࠭ࠧ㨯"))
					break
				l11111llll1_l1_.append(l11l11l1l11_l1_)
				l1llllll_l1_ = url.replace(l1l1ll11l11l_l1_,l11l11l1l11_l1_)
				l1lll11ll_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㨰"),l1llllll_l1_,l1l111_l1_ (u"ࠨࠩ㨱"),headers,l1l111_l1_ (u"ࠩࠪ㨲"),l1l111_l1_ (u"ࠪࠫ㨳"),l1l111_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠸ࡸࡤࠨ㨴"))
				html = l1lll11ll_l1_.content
				if l1lll11ll_l1_.succeeded and l1lllll111ll_l1_ in html:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㨵"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡰࡨࡻࠥ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠠࠡࠢࡖ࡭ࡹ࡫࠺ࠡ࡝ࠣࠫ㨶")+l1ll1l1l1lll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭㨷")+l11l11l1l11_l1_+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭㨸")+l1l1ll11l11l_l1_+l1l111_l1_ (u"ࠩࠣࡡࠬ㨹"))
					settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬ㨺")+l1ll1l1l1lll_l1_,l11l11l1l11_l1_)
					break
	return l11l11l1l11_l1_,l1llllll_l1_,l1lll11ll_l1_
def TRANSLATE(text):
	dict = {
	 l1l111_l1_ (u"ࠫࡴࡲࡤࠨ㨻")			:l1l111_l1_ (u"่ࠬฯ๋็ࠪ㨼")
	,l1l111_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ㨽")		:l1l111_l1_ (u"ࠧๆฬ๋ๆๆ࠭㨾")
	,l1l111_l1_ (u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩ㨿")		:l1l111_l1_ (u"่ࠩๅ็๎ฯࠨ㩀")
	,l1l111_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ㩁")			:l1l111_l1_ (u"ࠫั๐ฯࠨ㩂")
	,l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㩃")		:l1l111_l1_ (u"࠭แีๆࠪ㩄")
	,l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㩅")		:l1l111_l1_ (u"ࠨ็ฯ่ิ࠭㩆")
	,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㩇")		:l1l111_l1_ (u"ࠪๅ๏ี๊้ࠩ㩈")
	,l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㩉")			:l1l111_l1_ (u"่ࠬๆศหࠪ㩊")
	,l1l111_l1_ (u"࠭ࡡ࡬ࡱࡤࡱࠬ㩋")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫ㩌")
	,l1l111_l1_ (u"ࠨࡣ࡮ࡻࡦࡳࠧ㩍")		:l1l111_l1_ (u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅฮา๎ิ࠭㩎")
	,l1l111_l1_ (u"ࠪࡥࡰࡵࡡ࡮ࡥࡤࡱࠬ㩏")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢฦ็ํอๅࠡๅส้ࠬ㩐")
	,l1l111_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ㩑")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ่๊ࠠศๆ฼ีอ࠭㩒")
	,l1l111_l1_ (u"ࠧࡢ࡮ࡩࡥࡹ࡯࡭ࡪࠩ㩓")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦวๅ็้ฬึࠦวๅใส฻๊๐ࠧ㩔")
	,l1l111_l1_ (u"ࠩࡤࡰࡰࡧࡷࡵࡪࡤࡶࠬ㩕")	:l1l111_l1_ (u"้ࠪํู่ࠡไ้หฮࠦวๅๅ๋ฯึ࠭㩖")
	,l1l111_l1_ (u"ࠫࡦࡲ࡭ࡢࡣࡵࡩ࡫࠭㩗")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩ㩘")
	,l1l111_l1_ (u"࠭ࡡࡳࡤ࡯࡭ࡴࡴࡺࠨ㩙")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢ็๎ํ์าࠨ㩚")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ㩛")	:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧ㩜")
	,l1l111_l1_ (u"ࠪࡩࡱࡩࡩ࡯ࡧࡰࡥࠬ㩝")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢสุ่๐ๆๆษࠪ㩞")
	,l1l111_l1_ (u"ࠬ࡮ࡥ࡭ࡣ࡯ࠫ㩟")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ์๊วๅࠢํ์ฯ๐่ษࠩ㩠")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩ㩡")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩ㩢")
	,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ㩣")		:l1l111_l1_ (u"้ࠪํู่ࠡึส๋ิࠦแ้ำํ์ࠬ㩤")
	,l1l111_l1_ (u"ࠫࡸ࡮࡯ࡰࡨࡰࡥࡽ࠭㩥")		:l1l111_l1_ (u"๋่ࠬใ฻ุࠣํ็ࠠๆษๆืࠬ㩦")
	,l1l111_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㩧")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧ㩨")
	,l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ㩩")		:l1l111_l1_ (u"่ࠩ์็฿ࠠิ์่หࠥ์ว้ࠩ㩪")
	,l1l111_l1_ (u"ࠪ࡯ࡦࡸࡢࡢ࡮ࡤࡸࡻ࠭㩫")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠไำห่ฬวࠧ㩬")
	,l1l111_l1_ (u"ࠬࡿࡴࡣࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㩭")	:l1l111_l1_ (u"࠭ๅ้ษๅ฽ࠥ๐่ห์๋ฬࠬ㩮")
	,l1l111_l1_ (u"ࠧ࡮ࡻࡦ࡭ࡲࡧࠧ㩯")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦๅศ์ࠣื๏๋วࠨ㩰")
	,l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ㩱")		:l1l111_l1_ (u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠩ㩲")
	,l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭㩳")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๅฬ฻ไࠡษ็วํ๊ࠧ㩴")
	,l1l111_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪ࠲ࠨ㩵")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ็วึๆࠣห้ัว็์ࠪ㩶")
	,l1l111_l1_ (u"ࠨࡤࡲ࡯ࡷࡧࠧ㩷")		:l1l111_l1_ (u"่ࠩ์็฿ࠠษๅิหࠬ㩸")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬ㩹")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อฺࠠสา์ࠬ㩺")
	,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࡷࡺࠬ㩻")		:l1l111_l1_ (u"࠭ๅๅใࠪ㩼")
	,l1l111_l1_ (u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨ㩽")		:l1l111_l1_ (u"ࠨ็็ๅࠬ㩾")
	,l1l111_l1_ (u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ㩿")		:l1l111_l1_ (u"้ࠪํู่ࠡ็๋ๅืࠦแ้ำํ์ࠬ㪀")
	,l1l111_l1_ (u"ࠫ࡫ࡧࡪࡦࡴࡶ࡬ࡴࡽࠧ㪁")	:l1l111_l1_ (u"๋่ࠬใ฻ࠣๅัืࠠี๊ࠪ㪂")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ㪃")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠨ㪄")
	,l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠳ࠪ㪅")		:l1l111_l1_ (u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠵ࠬ㪆")
	,l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠶ࠬ㪇")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥ࠸ࠧ㪈")
	,l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧ㪉")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠴ࠩ㪊")
	,l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠵ࠩ㪋")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠷ࠫ㪌")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩ㪍")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬ㪎")
	,l1l111_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ㪏")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣษ๏า๊่ࠡส์ࠬ㪐")
	,l1l111_l1_ (u"࠭ࡥࡨࡻࡧࡩࡦࡪࠧ㪑")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥห๊อ์ࠣำ๏ีࠧ㪒")
	,l1l111_l1_ (u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪ㪓")		:l1l111_l1_ (u"่ࠩ์็฿่ࠠๆสࠤุ๐ๅศࠩ㪔")
	,l1l111_l1_ (u"ࠪࡰࡴࡪࡹ࡯ࡧࡷࠫ㪕")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢ็์ิ๐ࠠ็ฬࠪ㪖")
	,l1l111_l1_ (u"ࠬࡺࡶࡧࡷࡱࠫ㪗")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭㪘")
	,l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ㪙")	:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩ㪚")
	,l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡩࡥࡰࡨࡻࡸ࠭㪛")	:l1l111_l1_ (u"้ࠪํู่ࠡึส๋ิࠦๆ๋๊ีࠫ㪜")
	,l1l111_l1_ (u"ࠫ࡫ࡵࡳࡵࡣࠪ㪝")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣๅํูสศࠩ㪞")
	,l1l111_l1_ (u"࠭ࡡࡩࡹࡤ࡯ࠬ㪟")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩ㪠")
	,l1l111_l1_ (u"ࠨࡨࡤࡦࡷࡧ࡫ࡢࠩ㪡")		:l1l111_l1_ (u"่ࠩ์็฿ࠠโสิ็ฮ࠭㪢")
	,l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩ㪣")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩ㪤")
	,l1l111_l1_ (u"ࠬࡹࡨࡰࡨ࡫ࡥࠬ㪥")		:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤู๎แ่ษࠣฮ๏็๊ࠨ㪦")
	,l1l111_l1_ (u"ࠧࡣࡴࡶࡸࡪࡰࠧ㪧")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦศาีอ๎ั࠭㪨")
	,l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪ㪩")		:l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪ㪪")
	,l1l111_l1_ (u"ࠫࡱࡧࡲࡰࡼࡤࠫ㪫")		:l1l111_l1_ (u"๋่ࠬใ฻่ࠣฬื่ำษࠪ㪬")
	,l1l111_l1_ (u"࠭ࡹࡢࡳࡲࡸࠬ㪭")		:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐วใ๊อࠫ㪮")
	,l1l111_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ㪯")		:l1l111_l1_ (u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭㪰")
	,l1l111_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡶࡷࡺࠬ㪱")		:l1l111_l1_ (u"๊ࠫ๎โฺࠢๆฮ่๎สࠡฬํๅ๏࠭㪲")
	,l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡬ࡧࡹࡵ࡯࡯ࡵࠪ㪳")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨ㪴")
	,l1l111_l1_ (u"ࠧࡥࡴࡤࡱࡦࡹ࠷ࠨ㪵")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨ㪶")
	,l1l111_l1_ (u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫ㪷")		:l1l111_l1_ (u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩ㪸")
	,l1l111_l1_ (u"ࠫ࡮࡬ࡩ࡭࡯ࠪ㪹")				:l1l111_l1_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩ㪺")
	,l1l111_l1_ (u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬ㪻")			:l1l111_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩ㪼")
	,l1l111_l1_ (u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨ㪽")		:l1l111_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧ㪾")
	,l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵࠩ㪿")				:l1l111_l1_ (u"๊ࠫ๎โฺࠢหห๋๐สࠨ㫀")
	,l1l111_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡲࡵࡶࡪࡧࡶࠫ㫁")			:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠣหๆ๊วๆࠩ㫂")
	,l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡳࡦࡴ࡬ࡩࡸ࠭㫃")			:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮ๋ࠥำๅี็หฯ࠭㫄")
	,l1l111_l1_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ㫅")				:l1l111_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨ㫆")
	,l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠲ࡼࡩࡥࡧࡲࡷࠬ㫇")		:l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣๅ๏ี๊้้สฮࠬ㫈")
	,l1l111_l1_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ㫉")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬ่่ࠥศศ่ࠫ㫊")
	,l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ㫋")		:l1l111_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭㫌")
	,l1l111_l1_ (u"ࠪࡷ࡭࡯ࡡࡷࡱ࡬ࡧࡪ࠭㫍")			:l1l111_l1_ (u"๊ࠫ๎โฺุࠢ์ฯࠦวๅึํ฽ฮ࠭㫎")
	,l1l111_l1_ (u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥ࠮ࡲࡨࡶࡸࡵ࡮ࡴࠩ㫏")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠡไสีห࠭㫐")
	,l1l111_l1_ (u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪ㫑")		:l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩ㫒")
	,l1l111_l1_ (u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬ㫓")		:l1l111_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬ㫔")
	,l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ㫕")			:l1l111_l1_ (u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋࠭㫖")
	,l1l111_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡻ࡯ࡤࡦࡱࡶࠫ㫗")	:l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡใํำ๏๎็ศฬࠪ㫘")
	,l1l111_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ㫙"):l1l111_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠣๆํอฦๆࠩ㫚")
	,l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ㫛")	:l1l111_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊่ࠥๆ้ษอࠫ㫜")
	,l1l111_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡸࡴࡶࡩࡤࡵࠪ㫝")	:l1l111_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠๆ๊สฺ๏฿ࠧ㫞")
	,l1l111_l1_ (u"ࠧࡪࡲࡷࡺࠬ㫟")					:l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㫠")
	,l1l111_l1_ (u"ࠩ࡬ࡴࡹࡼ࠭࡭࡫ࡹࡩࠬ㫡")			:l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖࠡไ้์ฬะࠧ㫢")
	,l1l111_l1_ (u"ࠫ࡮ࡶࡴࡷ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㫣")			:l1l111_l1_ (u"ࠬࡏࡐࡕࡘࠣวๆ๊วๆࠩ㫤")
	,l1l111_l1_ (u"࠭ࡩࡱࡶࡹ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㫥")			:l1l111_l1_ (u"ࠧࡊࡒࡗ๋࡚ࠥำๅี็หฯ࠭㫦")
	,l1l111_l1_ (u"ࠨ࡯࠶ࡹࠬ㫧")					:l1l111_l1_ (u"ࠩࡐ࠷࡚࠭㫨")
	,l1l111_l1_ (u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬ㫩")				:l1l111_l1_ (u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧ㫪")
	,l1l111_l1_ (u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㫫")			:l1l111_l1_ (u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩ㫬")
	,l1l111_l1_ (u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫ㫭")			:l1l111_l1_ (u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭㫮")
	}
	try: result = dict[text.lower()]
	except: result = l1l111_l1_ (u"ࠩࠪ㫯")
	return result
def l1111111111_l1_(message=l1l111_l1_ (u"ࠪࠫ㫰")):
	l1ll1ll1l111_l1_()
	if message: sys.exit(message)
	else: sys.exit()
	return
def QUOTE(urll,exceptions=l1l111_l1_ (u"ࠫ࠿࠵ࠧ㫱")):
	return _1llll11l11l_l1_(urll,exceptions)
def l111lll1ll1_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠬ࠭㫲"),l1l111_l1_ (u"࠭࠰ࠨ㫳"),0]: return l1l111_l1_ (u"ࠧࠨ㫴")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)
	l11l1l11111_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111l1l111l_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1l11111_l1_)+str(l111l1l111l_l1_)+str(l111l111_l1_)
	return result
def l1ll111l1l1l_l1_(l1l1llll1_l1_):
	if l1l1llll1_l1_ in [l1l111_l1_ (u"ࠨࠩ㫵"),l1l111_l1_ (u"ࠩ࠳ࠫ㫶"),0]: return l1l111_l1_ (u"ࠪࠫ㫷")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	result = l1l111_l1_ (u"ࠫࠬ㫸")
	if len(l1l1llll1_l1_)==15:
		l11l1l11111_l1_,l111l1l111l_l1_,l111l111_l1_ = l1l1llll1_l1_[0:4],l1l1llll1_l1_[4:9],l1l1llll1_l1_[9:]
		l11l1l11111_l1_ = int(l11l1l11111_l1_)^l111l11l_l1_
		l111l1l111l_l1_ = int(l111l1l111l_l1_)^l11l1l1_l1_
		l111l111_l1_ = int(l111l111_l1_)^l1ll1ll1_l1_
		if l11l1l11111_l1_==l111l1l111l_l1_==l111l111_l1_: result = str(l11l1l11111_l1_*60)
	return result
def l1ll1ll1ll11_l1_(l1l1llll1_l1_,l1ll1llllll1_l1_=l1l111_l1_ (u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧ㫹")):
	if l1l1llll1_l1_==l1l111_l1_ (u"࠭ࠧ㫺"): return l1l111_l1_ (u"ࠧࠨ㫻")
	l1l1llll1_l1_ = int(l1l1llll1_l1_)+int(l1ll1llllll1_l1_)
	l11l1l11111_l1_ = l1l1llll1_l1_^l1ll1ll1_l1_
	l111l1l111l_l1_ = l1l1llll1_l1_^l11l1l1_l1_
	l111l111_l1_ = l1l1llll1_l1_^l111l11l_l1_
	result = str(l11l1l11111_l1_)+str(l111l1l111l_l1_)+str(l111l111_l1_)
	return result
def l1llllllll1l_l1_(l1l1llll1_l1_,l1ll1llllll1_l1_=l1l111_l1_ (u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪ㫼")):
	if l1l1llll1_l1_==l1l111_l1_ (u"ࠩࠪ㫽"): return l1l111_l1_ (u"ࠪࠫ㫾")
	l1l1llll1_l1_ = str(l1l1llll1_l1_)
	l1l1l111l1l_l1_ = int(len(l1l1llll1_l1_)/3)
	l11l1l11111_l1_ = int(l1l1llll1_l1_[0:l1l1l111l1l_l1_])^l1ll1ll1_l1_
	l111l1l111l_l1_ = int(l1l1llll1_l1_[l1l1l111l1l_l1_:2*l1l1l111l1l_l1_])^l11l1l1_l1_
	l111l111_l1_ = int(l1l1llll1_l1_[2*l1l1l111l1l_l1_:3*l1l1l111l1l_l1_])^l111l11l_l1_
	result = l1l111_l1_ (u"ࠫࠬ㫿")
	if l11l1l11111_l1_==l111l1l111l_l1_==l111l111_l1_: result = str(int(l11l1l11111_l1_)-int(l1ll1llllll1_l1_))
	return result
def l1l1l1l1ll1_l1_(l1l11l11lll_l1_):
	l1llll111111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ㬀")][8]
	l1111l11ll1_l1_ = l1l1l1l1lll_l1_(32)
	l1ll1l1l111l_l1_ = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩ㬁"),l1l111_l1_ (u"ࠧࡴ࡭࡬ࡲࡸ࠭㬂"),l1l111_l1_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ㬃"),l1l111_l1_ (u"ࠩ࠺࠶࠵ࡶࠧ㬄"),l1l111_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ㬅"))
	l11l1lllll1_l1_,l111ll1l1l1_l1_ = l1ll1l1lll_l1_(l1ll1l1l111l_l1_)
	l11l1lllll1_l1_ = l1ll1ll1ll11_l1_(l11l1lllll1_l1_,l1l111_l1_ (u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧ㬆"))
	l111l11ll11_l1_ = {l1l111_l1_ (u"ࠬ࡯ࡤࡴࠩ㬇"):l1l111_l1_ (u"࠭ࡄࡊࡃࡏࡓࡌ࠭㬈"),l1l111_l1_ (u"ࠧࡶࡵࡵࠫ㬉"):l1111l11ll1_l1_,l1l111_l1_ (u"ࠨࡸࡨࡶࠬ㬊"):l1l11l11111_l1_,l1l111_l1_ (u"ࠩࡶࡧࡷ࠭㬋"):l1l11l11lll_l1_,l1l111_l1_ (u"ࠪࡷ࡮ࢀࠧ㬌"):l11l1lllll1_l1_}
	l1lll111l111_l1_ = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㬍"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㬎")}
	l1llll111lll_l1_ = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㬏"),l1llll111111_l1_,l111l11ll11_l1_,l1lll111l111_l1_,l1l111_l1_ (u"ࠧࠨ㬐"),l1l111_l1_ (u"ࠨࠩ㬑"),l1l111_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪ㬒"))
	l11l1l11ll1_l1_ = l1llll111lll_l1_.content
	try:
		if not l11l1l11ll1_l1_: l1ll1111l11l_l1_
		l1lll1111l1l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㬓"),l11l1l11ll1_l1_)
		l1l1ll1llll1_l1_ = l1lll1111l1l_l1_[l1l111_l1_ (u"ࠫࡲࡹࡧࠨ㬔")]
		l1ll1111lll1_l1_ = l1lll1111l1l_l1_[l1l111_l1_ (u"ࠬࡹࡥࡤࠩ㬕")]
		l1lll1l11111_l1_ = l1lll1111l1l_l1_[l1l111_l1_ (u"࠭ࡳࡵࡲࠪ㬖")]
		l1ll1111lll1_l1_ = int(l1llllllll1l_l1_(l1ll1111lll1_l1_,l1l111_l1_ (u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪ㬗")))
		l1lll1l11111_l1_ = int(l1llllllll1l_l1_(l1lll1l11111_l1_,l1l111_l1_ (u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫ㬘")))
		for l1111ll11l1_l1_ in range(l1ll1111lll1_l1_,0,-l1lll1l11111_l1_):
			if not eval(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬ㬙")): l1ll1111l11l_l1_
			l1ll1lll_l1_(l1l111_l1_ (u"ࠪฬฬ่๊ࠡๆ็ฮัืศส๋ࠢห้็อึࠩ㬚"),str(l1111ll11l1_l1_)+l1l111_l1_ (u"ࠫࠥࠦหศ่ํอࠬ㬛"),time=500)
			xbmc.sleep(l1lll1l11111_l1_*1000)
		if eval(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࡗ࡫ࡧࡩࡴ࠮ࠩࠨ㬜")):
			l111l11ll1l_l1_ = l1l111_l1_ (u"ࠨࡄࡊࡃࡏࡓࡌ࡭࡟ࡐࡍࠫࠫࠬ࠲ࠧฯำ๋ะࠬ࠲ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬࠨ㬝")+l1l1ll1llll1_l1_+l1l111_l1_ (u"ࠢࠨࠫࠥ㬞")
			l111l11ll1l_l1_ = l111l11ll1l_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㬟"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㬠")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㬡"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㬢"))
			exec(l111l11ll1l_l1_)
		l1ll1111l11l_l1_
	except: exec(l1l111_l1_ (u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ㬣"))
	return
def l1l1111llll_l1_():
	exec(l1l111_l1_ (u"࠭ࠧࠨࠏࠍࡸࡷࡿ࠺ࠎࠌࠌࡻ࡮ࡴࡤࡰࡹ࠴࠶࠸ࠦ࠽ࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰࡚࡭ࡳࡪ࡯ࡸࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࡼ࡮ࡩ࡭ࡧࠣࡘࡷࡻࡥ࠻ࠏࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡷࡱ࡫ࡥࡱࠪ࠴࠴࠵࠶ࠩࠎࠌࠌࠍࡹࡸࡹ࠻ࠢࡺ࡭ࡳࡪ࡯ࡸ࠳࠵࠷࠳࡭ࡥࡵࡈࡲࡧࡺࡹࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࢀࡣࡳࡧࡤࡸࡪࡥࡥࡳࡱࡵࡶࠒࠐࡥࡹࡥࡨࡴࡹࡀࠠࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡴࡶࡲࡴ࠭࠯ࠍࠋࠩࠪࠫ㬤"))
	return
def l1ll1l1lll_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				from pathlib import Path
				size = Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1lllll1l1_l1_(l1llll1lll1l_l1_,l1ll11ll111l_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠧࠨ㬥"),l1l111_l1_ (u"ࠨࠩ㬦"),l1l111_l1_ (u"ࠩࠪ㬧"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㬨"),l1llll1lll1l_l1_+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㬩")+l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่ๆࠣฮึ๐ฯࠡ็ึัࠥํะศࠢส่๊าไะࠢยࠥࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㬪"))
		if l1llll1l1l_l1_!=1: return
	error = False
	if os.path.exists(l1llll1lll1l_l1_):
		for root,dirs,l11llll111_l1_ in os.walk(l1llll1lll1l_l1_,topdown=False):
			for file in l11llll111_l1_:
				filepath = os.path.join(root,file)
				try: os.remove(filepath)
				except Exception as err:
					if l11_l1_ and not error: l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㬫"),l1l111_l1_ (u"ࠧࠨ㬬"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㬭"),str(err))
					error = True
			if l1ll11ll111l_l1_:
				for dir in dirs:
					l1l1ll111l1l_l1_ = os.path.join(root,dir)
					try: os.rmdir(l1l1ll111l1l_l1_)
					except: pass
		if l1ll11ll111l_l1_:
			try: os.rmdir(root)
			except: pass
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ㬮"),l1l111_l1_ (u"ࠪࠫ㬯"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㬰"),l1l111_l1_ (u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭㬱"))
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ㬲"),l1l111_l1_ (u"ࠧࡔࡑࡐࡉ࡙ࡎࡉࡏࡉࠪ㬳"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ㬴"))
	return
def l1ll1ll1l111_l1_(l1111l1l1l1_l1_=l1l111_l1_ (u"ࠩࠪ㬵")):
	if l1111l1l1l1_l1_:
		l1llllll1l1l_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ㬶"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ㬷"),l1l111_l1_ (u"ࠬ࠭㬸"))
		l11l111llll_l1_(l1111l1l1l1_l1_)
		settings.setSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ㬹"),l1llllll1l1l_l1_)
	l1ll11lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ㬺"))
	if l1ll11lll1_l1_==l1l111_l1_ (u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡇࡇࠫ㬻"): settings.setSetting(l1l111_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭㬼"),l1l111_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭㬽"))
	elif l1ll11lll1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㬾"): settings.setSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡴࡨࡪࡷ࡫ࡳࡩ࠰ࡶࡸࡦࡺࡵࡴࠩ㬿"),l1l111_l1_ (u"࠭ࠧ㭀"))
	if settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ㭁")) not in [l1l111_l1_ (u"ࠨࡃࡘࡘࡔ࠭㭂"),l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㭃"),l1l111_l1_ (u"ࠪࡅࡘࡑࠧ㭄")]: settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ㭅"),l1l111_l1_ (u"ࠬࡇࡓࡌࠩ㭆"))
	if settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ㭇")) not in [l1l111_l1_ (u"ࠧࡂࡗࡗࡓࠬ㭈"),l1l111_l1_ (u"ࠨࡕࡗࡓࡕ࠭㭉"),l1l111_l1_ (u"ࠩࡄࡗࡐ࠭㭊")]: settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ㭋"),l1l111_l1_ (u"ࠫࡆ࡙ࡋࠨ㭌"))
	l11lll1llll_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ㭍"))
	l11l11111l1_l1_ = xbmc.executeJSONRPC(l1l111_l1_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩ㭎"))
	if l1l111_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭㭏") in str(l11l11111l1_l1_) and l11lll1llll_l1_ in [l1l111_l1_ (u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫ㭐"),l1l111_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ㭑")]:
		time.sleep(0.100)
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧ㭒"))
	if 0 and addon_handle>-1:
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l1111l1l111_l1_,l11ll11l1ll_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l1111l1l111_l1_,l11ll11l1ll_l1_)
	return
def l1lll1ll1l1_l1_(l1l1l11ll11_l1_,method,url,data,headers,source):
	if l1l1l11ll11_l1_:
		html = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡸࡺࡲࠨ㭓"),l1l111_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭㭔"),(method,url,data,headers))
		if html:
			l1l1l11llll_l1_(l1l111_l1_ (u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫ㭕"),url,data,headers,source,method)
			return html
	html = l1l111l1111_l1_(method,url,data,headers,source)
	if html and l1l1l11ll11_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨ㭖"),(method,url,data,headers),html,l1l1l11ll11_l1_)
	return html
OPENURLl_CACHED = l1l1llll_l1_
OPENURLl_REQUESTS_CACHED = l11l1l_l1_
DIALOGg_OK = l1111l1_l1_
l11lllll11l_l1_ = l11ll11l11l_l1_
l11lll11lll_l1_ = l1ll1ll11l11_l1_
DIALOGg_YESNO = l1ll1l111l_l1_
DIALOGg_SELECT = l1ll11ll_l1_
l11ll1ll1ll_l1_ = l11l111ll11_l1_
DIALOGg_TEXTVIEWER = l1ll111l1111_l1_
DIALOGg_CONTEXTMENU = l11l1lll1l1_l1_
l1111lll11l_l1_ = l11llll1l1_l1_
DIALOGg_NOTIFICATION = l1ll1lll_l1_
DIALOGg_THREEBUTTONS_TIMEOUT = l1l1ll1l11ll_l1_
l1ll1l11ll1l_l1_ = l1l11ll11l_l1_
SERVERr = l1l111l_l1_
OPENn_KEYBOARD = l1llll1_l1_
SEARCHh_OPTIONS = l111ll_l1_
PROGRESSs_UPDATE = l1ll1llll1ll_l1_
HOURr = l1l11ll1ll1_l1_
NO_CACHEe = l11ll11l_l1_
REGULAR_CACHEe = l11l1l1_l1_
VERYLONG_CACHEe = l1ll1ll1lll_l1_
PERMANENT_CACHEe = l1l1lll1l1l_l1_
from EXCLUDES import *
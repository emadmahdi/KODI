# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩ⭯")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡍࡌࡔࡡࠪ⭰")
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_):
	if   mode==540: l1lll_l1_ = l1l1l11_l1_()
	elif mode==541: l1lll_l1_ = l1lll111111_l1_(text)
	elif mode==542: l1lll_l1_ = l1ll1ll11ll_l1_(text,url,l1llllll1_l1_)
	elif mode==549: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭱"),l1l111_l1_ (u"࠭ศฮอࠣะิ๐ฯࠨ⭲"),l1l111_l1_ (u"ࠧࠨ⭳"),549)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⭴"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾ࠢๆ่๊อสࠡ็ัึ๋ฯࠠ࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⭵"),l1l111_l1_ (u"ࠪࠫ⭶"),9999)
	l1ll1llll11_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ⭷"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⭸"))
	if l1ll1llll11_l1_:
		l1ll1llll11_l1_ = l1ll1llll11_l1_[l1l111_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ⭹")]
		for search in reversed(l1ll1llll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⭺"),search,l1l111_l1_ (u"ࠨࠩ⭻"),549,l1l111_l1_ (u"ࠩࠪ⭼"),l1l111_l1_ (u"ࠪࠫ⭽"),search)
	return
def l1lll1_l1_(search):
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l1111111l1_l1_ = search.replace(l1lllll_l1_,l1l111_l1_ (u"ࠫࠬ⭾"))
	l1ll1l1l1ll_l1_(l1111111l1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⭿"),l1l111_l1_ (u"ู࠭ๆๆࠣฬาัࠠอ็ส฽๏ࠦ࠭ࠡࠩ⮀")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⮁"),542,l1l111_l1_ (u"ࠨࠩ⮂"),l1l111_l1_ (u"ࠩࠪ⮃"),l1111111l1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⮄"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⮅"),l1l111_l1_ (u"ࠬ࠭⮆"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⮇"),l1l111_l1_ (u"ࠧ็ฬสสัࠦวๅสะฯ๋ࠥแึๆฬࠤ࠲ࠦࠧ⮈")+l1111111l1_l1_,l1l111_l1_ (u"ࠨࡱࡳࡩࡳ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⮉"),542,l1l111_l1_ (u"ࠩࠪ⮊"),l1l111_l1_ (u"ࠪࠫ⮋"),l1111111l1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⮌"),l1l111_l1_ (u"ࠬ์สศศฯࠤฬ๊ศฮอ้ࠣ็ูๅสࠢ࠰ࠤࠬ⮍")+l1111111l1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬ⮎"),542,l1l111_l1_ (u"ࠧࠨ⮏"),l1l111_l1_ (u"ࠨࠩ⮐"),l1111111l1_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⮑"),l1l111_l1_ (u"ࠪฬาัࠠๆ่ไีิࠦ࠭ࠡࠩ⮒")+l1111111l1_l1_,l1l111_l1_ (u"ࠫࠬ⮓"),541,l1l111_l1_ (u"ࠬ࠭⮔"),l1l111_l1_ (u"࠭ࠧ⮕"),l1111111l1_l1_)
	return
def l1ll1l1l1ll_l1_(l1lll111ll1_l1_):
	l1lll11l111_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⮖"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡋࡗࡉࡘ࠭⮗"),l1lll111ll1_l1_)
	l1lll111lll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮘"),l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⮙"),l1lllll_l1_+l1lll111ll1_l1_)
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮚"),l1lll111ll1_l1_)
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮛"),l1lllll_l1_+l1lll111ll1_l1_)
	old_value = l1lll11l111_l1_+l1lll111lll_l1_
	if old_value: l1lll111ll1_l1_ = l1lllll_l1_+l1lll111ll1_l1_
	l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮜"),l1lll111ll1_l1_,old_value,l1ll1ll1lll_l1_)
	return
def l1ll1l1llll_l1_():
	l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠧࠨ⮝"),l1l111_l1_ (u"ࠨࠩ⮞"),l1l111_l1_ (u"ࠩࠪ⮟"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⮠"),l1l111_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠไๆ่หฯࠦวๅสะฯࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠡࠨ⮡"))
	if l1llll1l1l_l1_!=1: return
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮢"))
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ⮣"))
	l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭⮤"))
	l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ⮥"),l1l111_l1_ (u"ࠩࠪ⮦"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⮧"),l1l111_l1_ (u"ࠫฯ๋ࠠษ่ฯหาࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ⮨"))
	return
def l1ll1ll11ll_l1_(l1ll1ll1111_l1_,action,l1ll1ll1ll1_l1_=l1l111_l1_ (u"ࠬ࠭⮩")):
	l1ll1lll111_l1_,l1ll1lll11l_l1_,l1ll1llll1l_l1_,l1ll1l11l11_l1_,l1ll1l11lll_l1_,l1ll1l11ll1_l1_,threads = [],[],[],{},{},{},{}
	if action!=l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬ⮪"):
		if action==l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⮫"): l1ll1llll1l_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⮬"),l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮭"),l1lllll_l1_+l1ll1ll1111_l1_)
		elif action==l1l111_l1_ (u"ࠪࡳࡵ࡫࡮ࡦࡦࡢࡷ࡮ࡺࡥࡴࠩ⮮"): l1ll1llll1l_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ⮯"),l1l111_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡔࡖࡅࡏࡇࡇࠫ⮰"),l1ll1ll1111_l1_)
		elif action==l1l111_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬ⮱"): l1ll1llll1l_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ⮲"),l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧ⮳"),(l1ll1ll1ll1_l1_,l1ll1ll1111_l1_))
	if not l1ll1llll1l_l1_:
		l1lll11111l_l1_ = l1l111_l1_ (u"๊ࠩิฬࠦวๅสะฯࠥเ๊า่ࠢ์ั๎ฯࠡใํࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮࡝ࡰࠪ⮴")
		l1lll1111l1_l1_ = l1l111_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ย็ࠢส่อำหࠡใํࠤัฺ๋๊ࠢส่๊๎วใ฻ࠣ฽๋ࠦ࡜࡯ࠢࠥ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢࠦࠧ⮵")+l1ll1ll1111_l1_+l1l111_l1_ (u"ࠫࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࠡ࡞ࡱࠤ฾๊ๅศࠢฦ๊ࠥํะศࠢส่อำหࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯ࠭⮶")
		if action==l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫ⮷"): message = l1lll1111l1_l1_
		else: message = l1lll11111l_l1_+l1lll1111l1_l1_
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"࠭ࠧ⮸"),l1l111_l1_ (u"ࠧࠨ⮹"),l1l111_l1_ (u"ࠨࠩ⮺"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⮻"),message)
		if l1llll1l1l_l1_!=1: return
		l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⮼"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡔࡧࡤࡶࡨ࡮ࠠࡇࡱࡵ࠾ࠥࡡࠠࠨ⮽")+l1ll1ll1111_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ⮾"))
		import threading
		l1lll11ll1l_l1_ = 1
		for l1ll1ll1ll1_l1_ in l1ll1lll1ll_l1_:
			l1ll1l11l11_l1_[l1ll1ll1ll1_l1_] = []
			options = l1l111_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ⮿")
			if l1l111_l1_ (u"ࠧ࠮ࠩ⯀") in l1ll1ll1ll1_l1_: options = options+l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤ࠭⯁")+l1ll1ll1ll1_l1_+l1l111_l1_ (u"ࠩࡢࠫ⯂")
			l1ll1l1ll1l_l1_,l1ll1ll1l1l_l1_,l1lll11ll11_l1_ = l1ll1l1l111_l1_(l1ll1ll1ll1_l1_)
			if l1lll11ll1l_l1_:
				time.sleep(0.5)
				threads[l1ll1ll1ll1_l1_] = threading.Thread(target=l1ll1ll1l1l_l1_,args=(l1ll1ll1111_l1_+options,))
				threads[l1ll1ll1ll1_l1_].start()
			else: l1ll1ll1l1l_l1_(l1ll1ll1111_l1_+options)
			l1ll1lll_l1_(TRANSLATE(l1ll1ll1ll1_l1_),l1l111_l1_ (u"ࠪࠫ⯃"),time=1000)
		if l1lll11ll1l_l1_:
			time.sleep(2)
			for l1ll1ll1ll1_l1_ in l1ll1lll1ll_l1_:
				threads[l1ll1ll1ll1_l1_].join(10)
			time.sleep(2)
		for l1ll1ll1ll1_l1_ in l1ll1lll1ll_l1_:
			l1ll1l1ll1l_l1_,l1ll1ll1l1l_l1_,l1lll11ll11_l1_ = l1ll1l1l111_l1_(l1ll1ll1ll1_l1_)
			for l1ll1ll11l1_l1_ in menuItemsLIST:
				type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = l1ll1ll11l1_l1_
				if l1lll11ll11_l1_ in name:
					if l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࠪ⯄") in l1ll1ll1ll1_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⯅")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ⯆")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ⯇")]: continue
						if l1l111_l1_ (u"ࠨืไัฮ࠭⯈") not in name:
							if   type==l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⯉"): l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭⯊")
							elif type==l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⯋"): l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⯌")
							elif type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯍"): l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ⯎")
						else:
							if   l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭⯏") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ⯐")
							elif l1l111_l1_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪ⯑") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⯒")
							elif l1l111_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ⯓") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⯔")
					elif l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࠬ⯕") in l1ll1ll1ll1_l1_ and 729>=mode>=710:
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ⯖")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭⯗")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯘")]: continue
						if l1l111_l1_ (u"ฺࠫ็อสࠩ⯙") not in name:
							if   type==l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⯚"): l1ll1ll1ll1_l1_ = l1l111_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ⯛")
							elif type==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⯜"): l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⯝")
							elif type==l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯞"): l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯟")
						else:
							if   l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ⯠") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ⯡")
							elif l1l111_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭⯢") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ⯣")
							elif l1l111_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨ⯤") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⯥")
					elif l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࠬ⯦") in l1ll1ll1ll1_l1_ and 149>=mode>=140:
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯧")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⯨")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯩")]: continue
						if l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ⯪") in name or l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ⯫") in name:
							continue
						else:
							if   mode==144 and l1l111_l1_ (u"ࠩࡘࡗࡊࡘࠧ⯬") in name: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⯭")
							elif mode==144 and l1l111_l1_ (u"ࠫࡈࡎࡎࡍࠩ⯮") in name: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯯")
							elif mode==144 and l1l111_l1_ (u"࠭ࡌࡊࡕࡗࠫ⯰") in name: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⯱")
							elif mode==143: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ⯲")
							else: continue
					elif l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࠨ⯳") in l1ll1ll1ll1_l1_ and 419>=mode>=400:
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ⯴")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ⯵")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ⯶")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡙ࡕࡐࡊࡅࡖࠫ⯷")]: continue
						if   mode in [401,405]: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ⯸")
						elif mode in [402,406]: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ⯹")
						elif mode in [403,404]: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯺")
						elif mode in [412,413]: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡖࡒࡔࡎࡉࡓࠨ⯻")
					elif l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࠫ⯼") in l1ll1ll1ll1_l1_ and 39>=mode>=30:
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫ⯽")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ⯾")]: continue
						if   mode in [32,39]: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭⯿")
						elif mode in [33,39]: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧⰀ")
					elif l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࠩⰁ") in l1ll1ll1ll1_l1_ and 29>=mode>=20:
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩⰂ")]: continue
						if l1ll1ll11l1_l1_ in l1ll1l11l11_l1_[l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫⰃ")]: continue
						if   l1l111_l1_ (u"ࠬ࠵ࡡࡳ࠰ࠪⰄ") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬⰅ")
						elif l1l111_l1_ (u"ࠧ࠰ࡧࡱ࠲ࠬⰆ") in url: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨⰇ")
					l1ll1l11l11_l1_[l1ll1ll1ll1_l1_].append(l1ll1ll11l1_l1_)
		menuItemsLIST[:] = []
		for l1ll1ll1ll1_l1_ in list(l1ll1l11l11_l1_.keys()):
			l1ll1l11lll_l1_[l1ll1ll1ll1_l1_] = []
			l1ll1l11ll1_l1_[l1ll1ll1ll1_l1_] = []
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in l1ll1l11l11_l1_[l1ll1ll1ll1_l1_]:
				l1ll1ll11l1_l1_ = (type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_)
				if l1l111_l1_ (u"ุࠩๅาฯࠧⰈ") in name and type==l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⰉ"): l1ll1l11ll1_l1_[l1ll1ll1ll1_l1_].append(l1ll1ll11l1_l1_)
				else: l1ll1l11lll_l1_[l1ll1ll1ll1_l1_].append(l1ll1ll11l1_l1_)
		l1ll1llllll_l1_ = [(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⰊ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⰋ"),l1l111_l1_ (u"࠭ࠧⰌ"),157,l1l111_l1_ (u"ࠧࠨⰍ"),l1l111_l1_ (u"ࠨࠩⰎ"),l1l111_l1_ (u"ࠩࠪⰏ"),l1l111_l1_ (u"ࠪࠫⰐ"),l1l111_l1_ (u"ࠫࠬⰑ"))]
		for l1ll1ll1ll1_l1_ in l1ll1lll1l1_l1_:
			if l1ll1ll1ll1_l1_==l1ll1l1lll1_l1_[0]: l1ll1llllll_l1_ = [(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪⰒ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮฺ่ࠦษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⰓ"),l1l111_l1_ (u"ࠧࠨⰔ"),157,l1l111_l1_ (u"ࠨࠩⰕ"),l1l111_l1_ (u"ࠩࠪⰖ"),l1l111_l1_ (u"ࠪࠫⰗ"),l1l111_l1_ (u"ࠫࠬⰘ"),l1l111_l1_ (u"ࠬ࠭Ⱉ"))]
			elif l1ll1ll1ll1_l1_==l1lll11l11l_l1_[0]: l1ll1llllll_l1_ = [(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⰚ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⰛ"),l1l111_l1_ (u"ࠨࠩⰜ"),157,l1l111_l1_ (u"ࠩࠪⰝ"),l1l111_l1_ (u"ࠪࠫⰞ"),l1l111_l1_ (u"ࠫࠬⰟ"),l1l111_l1_ (u"ࠬ࠭Ⱐ"),l1l111_l1_ (u"࠭ࠧⰡ"))]
			elif l1ll1ll1ll1_l1_==l1ll1l11l1l_l1_[0]: l1ll1llllll_l1_ = [(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰢ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰣ"),l1l111_l1_ (u"ࠩࠪⰤ"),157,l1l111_l1_ (u"ࠪࠫⰥ"),l1l111_l1_ (u"ࠫࠬⰦ"),l1l111_l1_ (u"ࠬ࠭Ⱗ"),l1l111_l1_ (u"࠭ࠧⰨ"),l1l111_l1_ (u"ࠧࠨⰩ"))]
			if l1ll1ll1ll1_l1_ not in l1ll1l11lll_l1_.keys(): continue
			if l1ll1l11lll_l1_[l1ll1ll1ll1_l1_]:
				l1ll1l1l1l1_l1_ = TRANSLATE(l1ll1ll1ll1_l1_)
				l1ll1ll111l_l1_ = [(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⱚ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࡂࡃ࠽࠾࠿ࠣࠫⰫ")+l1ll1l1l1l1_l1_+l1l111_l1_ (u"ࠪࠤࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰬ"),l1l111_l1_ (u"ࠫࠬⰭ"),9999,l1l111_l1_ (u"ࠬ࠭Ⱞ"),l1l111_l1_ (u"࠭ࠧⰯ"),l1l111_l1_ (u"ࠧࠨⰰ"),l1l111_l1_ (u"ࠨࠩⰱ"),l1l111_l1_ (u"ࠩࠪⰲ"))]
				if 0:
					l1lll11l1l1_l1_ = l1ll1ll1111_l1_+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧⰳ")+l1l111_l1_ (u"ࠫอำหࠨⰴ")+l1l111_l1_ (u"ࠬࠦࠧⰵ")+l1ll1l1l1l1_l1_
				else:
					l1lll11l1l1_l1_ = l1l111_l1_ (u"࠭ศฮอࠪⰶ")+l1l111_l1_ (u"ࠧࠡࠩⰷ")+l1ll1l1l1l1_l1_+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬⰸ")+l1ll1ll1111_l1_
				if len(l1ll1l11lll_l1_[l1ll1ll1ll1_l1_])<8: l1ll1lllll1_l1_ = []
				else:
					l1lll11l1ll_l1_ = l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬⰹ")+l1lll11l1l1_l1_+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬⰺ")
					l1ll1lllll1_l1_ = [(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⰻ"),l1lllll_l1_+l1lll11l1ll_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡰࡵࡨࡨࡤࡹࡩࡵࡧࡶࠫⰼ"),542,l1l111_l1_ (u"࠭ࠧⰽ"),l1ll1ll1ll1_l1_,l1ll1ll1111_l1_,l1l111_l1_ (u"ࠧࠨⰾ"),l1l111_l1_ (u"ࠨࠩⰿ"))]
				l1lll111l11_l1_ = l1ll1l11lll_l1_[l1ll1ll1ll1_l1_]+l1ll1l11ll1_l1_[l1ll1ll1ll1_l1_]
				l1ll1lll11l_l1_ += l1ll1llllll_l1_+l1ll1ll111l_l1_+l1lll111l11_l1_[:7]+l1ll1lllll1_l1_
				l1ll1l1l11l_l1_ = [(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱀ"),l1lllll_l1_+l1lll11l1l1_l1_,l1l111_l1_ (u"ࠪࡧࡱࡵࡳࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⱁ"),542,l1l111_l1_ (u"ࠫࠬⱂ"),l1ll1ll1ll1_l1_,l1ll1ll1111_l1_,l1l111_l1_ (u"ࠬ࠭ⱃ"),l1l111_l1_ (u"࠭ࠧⱄ"))]
				l1ll1lll111_l1_ += l1ll1llllll_l1_+l1ll1l1l11l_l1_
				l1ll1llllll_l1_ = []
				l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡃࡍࡑࡖࡉࡉ࠭ⱅ"),(l1ll1ll1ll1_l1_,l1ll1ll1111_l1_),l1lll111l11_l1_,l1ll1ll1lll_l1_)
		l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡐࡒࡈࡒࡊࡊࠧⱆ"),l1ll1ll1111_l1_,l1ll1lll11l_l1_,l1ll1ll1lll_l1_)
		l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧⱇ"),l1ll1ll1111_l1_)
		l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨⱈ"),l1lllll_l1_+l1ll1ll1111_l1_,l1ll1lll111_l1_,l1ll1ll1lll_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬⱉ"),l1l111_l1_ (u"ࠬ࠭ⱊ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩⱋ"),l1l111_l1_ (u"ࠧศๆหัะࠦวๅฮ่ห฾๐ࠠศ่อ๋๎ࠦศ็ฮสัࠥࡢ࡮࡝ࡰࠣฮ๊ࠦสฯิํ๊ࠥอไ็ฬสสัࠦแ๋ࠢๆหูࠦวๅสิ๊ฬ๋ฬࠡๆ่ำฮࠦหๅษฮ๎๋๊้ࠦ็่่ࠣ๐ࠠหีอ฻๏฿ࠠศๆ฼์ิฯࠠฦๆํ๋ฬࠦศะ๊้ࠤ฾๋ไࠡสะฯࠥาฯ๋ัࠪⱌ"))
		if action==l1l111_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱍ") and l1ll1lll111_l1_: l1ll1llll1l_l1_ = l1ll1lll111_l1_
		else: l1ll1llll1l_l1_ = l1ll1lll11l_l1_
	if action!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡶ࡭ࡹ࡫ࡳࠨⱎ"):
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in l1ll1llll1l_l1_:
			if action in [l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࡦࡦࡢࡷ࡮ࡺࡥࡴࠩⱏ"),l1l111_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⱐ")] and l1l111_l1_ (u"ࠬ฻แฮหࠪⱑ") in name and type==l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱒ"): continue
			addMenuItem(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_)
	return
def l1lll111111_l1_(l1ll1ll1111_l1_=l1l111_l1_ (u"ࠧࠨⱓ")):
	search,options,l11_l1_ = l111ll_l1_(l1ll1ll1111_l1_)
	if not search:
		search = l1llll1_l1_()
		if not search: return
		search = search.lower()
	l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨⱔ"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡥࡢࡴࡦ࡬ࠥࡌ࡯ࡳ࠼ࠣ࡟ࠥ࠭ⱕ")+search+l1l111_l1_ (u"ࠪࠤࡢ࠭ⱖ"))
	l1lll1ll_l1_ = search+options
	if 0: l1lll111l1l_l1_,l1111111l1_l1_ = search+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨⱗ"),l1l111_l1_ (u"ࠬ࠭ⱘ")
	else: l1lll111l1l_l1_,l1111111l1_l1_ = l1l111_l1_ (u"࠭ࠧⱙ"),l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫⱚ")+search
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⱛ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⱜ"),l1l111_l1_ (u"ࠪࠫⱝ"),157)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱞ"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫⱟ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอࠣࡑ࠸࡛ࠧⱠ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⱡ"),719,l1l111_l1_ (u"ࠨࠩⱢ"),l1l111_l1_ (u"ࠩࠪⱣ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⱤ"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡡࠪⱥ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠬฮอฬࠢࡌࡔ࡙࡜ࠧⱦ")+l1111111l1_l1_,l1l111_l1_ (u"࠭ࠧⱧ"),239,l1l111_l1_ (u"ࠧࠨⱨ"),l1l111_l1_ (u"ࠨࠩⱩ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱪ"),l1l111_l1_ (u"ࠪࡣࡇࡑࡒࡠࠩⱫ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦศไำสࠫⱬ")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭Ɑ"),379,l1l111_l1_ (u"࠭ࠧⱮ"),l1l111_l1_ (u"ࠧࠨⱯ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⱰ"),l1l111_l1_ (u"ࠩࡢࡏࡑࡇ࡟ࠨⱱ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽้ࠥไࠡษ็฽ึฮࠧⱲ")+l1111111l1_l1_,l1l111_l1_ (u"ࠫࠬⱳ"),19,l1l111_l1_ (u"ࠬ࠭ⱴ"),l1l111_l1_ (u"࠭ࠧⱵ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱶ"),l1l111_l1_ (u"ࠨࡡࡄࡖ࡙ࡥࠧⱷ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨⱸ")+l1111111l1_l1_,l1l111_l1_ (u"ࠪࠫⱹ"),739,l1l111_l1_ (u"ࠫࠬⱺ"),l1l111_l1_ (u"ࠬ࠭ⱻ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⱼ"),l1l111_l1_ (u"ࠧࡠࡍࡕࡆࡤ࠭ⱽ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨⱾ")+l1111111l1_l1_,l1l111_l1_ (u"ࠩࠪⱿ"),329,l1l111_l1_ (u"ࠪࠫⲀ"),l1l111_l1_ (u"ࠫࠬⲁ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲂ"),l1l111_l1_ (u"࠭࡟ࡇࡊ࠴ࡣࠬⲃ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไหฺ๊ࠠศๆฦ์้࠭Ⲅ")+l1111111l1_l1_,l1l111_l1_ (u"ࠨࠩⲅ"),579,l1l111_l1_ (u"ࠩࠪⲆ"),l1l111_l1_ (u"ࠪࠫⲇ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲈ"),l1l111_l1_ (u"ࠬࡥࡋࡕࡘࡢࠫⲉ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡๅอ็ํะࠠห์ไ๎ࠬⲊ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⲋ"),819,l1l111_l1_ (u"ࠨࠩⲌ"),l1l111_l1_ (u"ࠩࠪⲍ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲎ"),l1l111_l1_ (u"ࠫࡤࡋࡂ࠲ࡡࠪⲏ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠵ࠬⲐ")+l1111111l1_l1_,l1l111_l1_ (u"࠭ࠧⲑ"),779,l1l111_l1_ (u"ࠧࠨⲒ"),l1l111_l1_ (u"ࠨࠩⲓ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲔ"),l1l111_l1_ (u"ࠪࡣࡊࡈ࠲ࡠࠩⲕ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠵ࠫⲖ")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭ⲗ"),789,l1l111_l1_ (u"࠭ࠧⲘ"),l1l111_l1_ (u"ࠧࠨⲙ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲚ"),l1l111_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨⲛ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥฮอฬ่ࠢ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊࠭Ⲝ")+l1111111l1_l1_+l1l111_l1_ (u"ࠫࠥࠦࠧⲝ"),l1l111_l1_ (u"ࠬ࠭Ⲟ"),29,l1l111_l1_ (u"࠭ࠧⲟ"),l1l111_l1_ (u"ࠧࠨⲠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲡ"),l1l111_l1_ (u"ࠩࡢࡅࡐࡕ࡟ࠨⲢ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫⲣ")+l1111111l1_l1_,l1l111_l1_ (u"ࠫࠬⲤ"),79,l1l111_l1_ (u"ࠬ࠭ⲥ"),l1l111_l1_ (u"࠭ࠧⲦ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲧ"),l1l111_l1_ (u"ࠨࡡࡄࡏ࡜ࡥࠧⲨ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪⲩ")+l1111111l1_l1_,l1l111_l1_ (u"ࠪࠫⲪ"),249,l1l111_l1_ (u"ࠫࠬⲫ"),l1l111_l1_ (u"ࠬ࠭Ⲭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲭ"),l1l111_l1_ (u"ࠧࡠࡏࡕࡊࡤ࠭Ⲯ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๆ๋อษࠡษ็้฾อัโࠩⲯ")+l1111111l1_l1_,l1l111_l1_ (u"ࠩࠪⲰ"),49,l1l111_l1_ (u"ࠪࠫⲱ"),l1l111_l1_ (u"ࠫࠬⲲ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⲳ"),l1l111_l1_ (u"࠭࡟ࡔࡊࡐࡣࠬⲴ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆࠦๅศๅึࠫⲵ")+l1111111l1_l1_,l1l111_l1_ (u"ࠨࠩⲶ"),59,l1l111_l1_ (u"ࠩࠪⲷ"),l1l111_l1_ (u"ࠪࠫⲸ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⲹ"),l1l111_l1_ (u"ࠬࡥࡆࡕࡏࡢࠫⲺ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩⲻ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⲼ"),69,l1l111_l1_ (u"ࠨࠩⲽ"),l1l111_l1_ (u"ࠩࠪⲾ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⲿ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤํ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⳁ"),l1l111_l1_ (u"ࠬ࠭ⳁ"),157)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⳃ"),l1l111_l1_ (u"ࠧࡠࡈࡍࡗࡤ࠭ⳃ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠨࠢหัะࠦๅ้ไ฼ࠤๆาัࠡึ๋ࠫⳄ")+l1111111l1_l1_+l1l111_l1_ (u"ࠩࠣࠫⳅ"),l1l111_l1_ (u"ࠪࠫⳆ"),399,l1l111_l1_ (u"ࠫࠬⳇ"),l1l111_l1_ (u"ࠬ࠭Ⳉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⳉ"),l1l111_l1_ (u"ࠧࡠࡖ࡙ࡊࡤ࠭Ⳋ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฮ๏็๊ࠡใส๊ࠬⳋ")+l1111111l1_l1_,l1l111_l1_ (u"ࠩࠪⳌ"),469,l1l111_l1_ (u"ࠪࠫⳍ"),l1l111_l1_ (u"ࠫࠬⳎ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳏ"),l1l111_l1_ (u"࠭࡟ࡍࡆࡑࡣࠬⳐ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢ็์ิ๐ࠠ็ฬࠪⳑ")+l1111111l1_l1_,l1l111_l1_ (u"ࠨࠩⳒ"),459,l1l111_l1_ (u"ࠩࠪⳓ"),l1l111_l1_ (u"ࠪࠫⳔ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⳕ"),l1l111_l1_ (u"ࠬࡥࡃࡎࡐࡢࠫⳖ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦๆศ๊ࠪⳗ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⳘ"),309,l1l111_l1_ (u"ࠨࠩⳙ"),l1l111_l1_ (u"ࠩࠪⳚ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⳛ"),l1l111_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪⳜ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿้ࠠ์ࠣื๏๋วࠨⳝ")+l1111111l1_l1_,l1l111_l1_ (u"࠭ࠧⳞ"),569,l1l111_l1_ (u"ࠧࠨⳟ"),l1l111_l1_ (u"ࠨࠩⳠ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⳡ"),l1l111_l1_ (u"ࠪࡣࡘࡎࡎࡠࠩⳢ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩⳣ")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭ⳤ"),589,l1l111_l1_ (u"࠭ࠧ⳥"),l1l111_l1_ (u"ࠧࠨ⳦"),l1lll1ll_l1_+l1l111_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭⳧"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳨"),l1l111_l1_ (u"ࠪࡣࡆࡘࡓࡠࠩ⳩")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ⳪")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭Ⳬ"),259,l1l111_l1_ (u"࠭ࠧⳬ"),l1l111_l1_ (u"ࠧࠨⳭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⳮ"),l1l111_l1_ (u"ࠩࡢࡇ࠹࡛࡟ࠨ⳯")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣๅํื๊้ࠩ⳰")+l1111111l1_l1_,l1l111_l1_ (u"ࠫࠬ⳱"),429,l1l111_l1_ (u"ࠬ࠭Ⳳ"),l1l111_l1_ (u"࠭ࠧⳳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⳴"),l1l111_l1_ (u"ࠨࡡࡖࡌ࠹ࡥࠧ⳵")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨ⳶")+l1111111l1_l1_,l1l111_l1_ (u"ࠪࠫ⳷"),119,l1l111_l1_ (u"ࠫࠬ⳸"),l1l111_l1_ (u"ࠬ࠭⳹"),l1lll1ll_l1_+l1l111_l1_ (u"࠭࡟ࡏࡑࡇࡍࡆࡒࡏࡈࡕࡢࠫ⳺"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⳻"),l1l111_l1_ (u"ࠨࡡࡈࡆ࠸ࡥࠧ⳼")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠ࠴ࠩ⳽")+l1111111l1_l1_,l1l111_l1_ (u"ࠪࠫ⳾"),799,l1l111_l1_ (u"ࠫࠬ⳿"),l1l111_l1_ (u"ࠬ࠭ⴀ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫⴁ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟่์ฬู่ࠡีํีๆืวหࠢ฼ห๊ฯࠠ࠮ࠢๆฯ๏ืษࠡษ็ู้อใๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⴂ"),l1l111_l1_ (u"ࠨࠩⴃ"),157)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⴄ"),l1l111_l1_ (u"ࠪࡣࡋ࡙ࡔࡠࠩⴅ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦแ้ีอหࠬⴆ")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭ⴇ"),609,l1l111_l1_ (u"࠭ࠧⴈ"),l1l111_l1_ (u"ࠧࠨⴉ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴊ"),l1l111_l1_ (u"ࠩࡢࡊࡇࡑ࡟ࠨⴋ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ็ศาๅฬࠫⴌ")+l1111111l1_l1_,l1l111_l1_ (u"ࠫࠬⴍ"),629,l1l111_l1_ (u"ࠬ࠭ⴎ"),l1l111_l1_ (u"࠭ࠧⴏ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴐ"),l1l111_l1_ (u"ࠨࡡ࡜ࡕ࡙ࡥࠧⴑ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ๏อโ้ฬࠪⴒ")+l1111111l1_l1_,l1l111_l1_ (u"ࠪࠫⴓ"),669,l1l111_l1_ (u"ࠫࠬⴔ"),l1l111_l1_ (u"ࠬ࠭ⴕ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴖ"),l1l111_l1_ (u"ࠧࡠࡄࡕࡗࡤ࠭ⴗ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣฬึูส๋ฮࠪⴘ")+l1111111l1_l1_,l1l111_l1_ (u"ࠩࠪⴙ"),659,l1l111_l1_ (u"ࠪࠫⴚ"),l1l111_l1_ (u"ࠫࠬⴛ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴜ"),l1l111_l1_ (u"࠭࡟ࡉࡎࡆࡣࠬⴝ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺ๊่ࠢฬࠦำ๋็สࠫⴞ")+l1111111l1_l1_,l1l111_l1_ (u"ࠨࠩⴟ"),89,l1l111_l1_ (u"ࠩࠪⴠ"),l1l111_l1_ (u"ࠪࠫⴡ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⴢ"),l1l111_l1_ (u"ࠬࡥࡄࡓ࠹ࡢࠫⴣ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡัิห๊อࠠึฯࠪⴤ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⴥ"),689,l1l111_l1_ (u"ࠨࠩ⴦"),l1l111_l1_ (u"ࠩࠪⴧ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⴨"),l1l111_l1_ (u"ࠫࡤࡉࡍࡇࡡࠪ⴩")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่หࠥ็ว็ิࠪ⴪")+l1111111l1_l1_,l1l111_l1_ (u"࠭ࠧ⴫"),99,l1l111_l1_ (u"ࠧࠨ⴬"),l1l111_l1_ (u"ࠨࠩⴭ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⴮"),l1l111_l1_ (u"ࠪࡣࡈࡓࡌࡠࠩ⴯")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩⴰ")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭ⴱ"),479,l1l111_l1_ (u"࠭ࠧⴲ"),l1l111_l1_ (u"ࠧࠨⴳ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴴ"),l1l111_l1_ (u"ࠩࡢࡅࡇࡊ࡟ࠨⴵ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨⴶ")+l1111111l1_l1_,l1l111_l1_ (u"ࠫࠬⴷ"),559,l1l111_l1_ (u"ࠬ࠭ⴸ"),l1l111_l1_ (u"࠭ࠧⴹ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴺ"),l1l111_l1_ (u"ࠨࡡࡆ࠸ࡍࡥࠧⴻ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭ⴼ")+l1111111l1_l1_,l1l111_l1_ (u"ࠪࠫⴽ"),699,l1l111_l1_ (u"ࠫࠬⴾ"),l1l111_l1_ (u"ࠬ࠭ⴿ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵀ"),l1l111_l1_ (u"ࠧࡠࡃࡋࡏࡤ࠭ⵁ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧⵂ")+l1111111l1_l1_,l1l111_l1_ (u"ࠩࠪⵃ"),619,l1l111_l1_ (u"ࠪࠫⵄ"),l1l111_l1_ (u"ࠫࠬⵅ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵆ"),l1l111_l1_ (u"࠭࡟ࡔࡊࡗࡣࠬⵇ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢื์ๆํวࠡฬํๅ๏࠭ⵈ")+l1111111l1_l1_,l1l111_l1_ (u"ࠨࠩⵉ"),649,l1l111_l1_ (u"ࠩࠪⵊ"),l1l111_l1_ (u"ࠪࠫⵋ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵌ"),l1l111_l1_ (u"ࠬࡥࡆࡉ࠴ࡢࠫⵍ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡใสู้ࠦวๅอส๊๏࠭ⵎ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⵏ"),599,l1l111_l1_ (u"ࠨࠩⵐ"),l1l111_l1_ (u"ࠩࠪⵑ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵒ"),l1l111_l1_ (u"ࠫࡤࡋࡂ࠵ࡡࠪⵓ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬⵔ")+l1111111l1_l1_,l1l111_l1_ (u"࠭ࠧⵕ"),809,l1l111_l1_ (u"ࠧࠨⵖ"),l1l111_l1_ (u"ࠨࠩⵗ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵘ"),l1l111_l1_ (u"ࠪࡣࡈࡉࡗࡠࠩⵙ")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠢ฼้้࠭ⵚ")+l1111111l1_l1_,l1l111_l1_ (u"ࠬ࠭ⵛ"),639,l1l111_l1_ (u"࠭ࠧⵜ"),l1l111_l1_ (u"ࠧࠨⵝ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ⵞ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็࡟࠴ࡉࡏࡍࡑࡕࡡࠬⵟ"),l1l111_l1_ (u"ࠪࠫⵠ"),157)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵡ"),l1l111_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫⵢ")+l1lll111l1l_l1_+l1l111_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์๋ฮ๏๎ศࠨⵣ")+l1111111l1_l1_,l1l111_l1_ (u"ࠧࠨⵤ"),149,l1l111_l1_ (u"ࠨࠩⵥ"),l1l111_l1_ (u"ࠩࠪⵦ"),l1lll1ll_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵧ"),l1l111_l1_ (u"ࠫࡤࡊࡌࡎࡡࠪ⵨")+l1lll111l1l_l1_+l1l111_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠะ์็๎๋่ࠥี่ࠪ⵩")+l1111111l1_l1_,l1l111_l1_ (u"࠭ࠧ⵪"),409,l1l111_l1_ (u"ࠧࠨ⵫"),l1l111_l1_ (u"ࠨࠩ⵬"),l1lll1ll_l1_)
	return
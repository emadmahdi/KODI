# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕࠩ㱅")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡐࡉࡔ࡟ࠨ㱆")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪห้ืฦ๋ีํอࠬ㱇"),l1l111_l1_ (u"ࠫฬูสโีสีฯ้ๅ๊ࠡࠣห้฽ไษษอࠫ㱈")]
def l11l1ll_l1_(mode,url,text):
	if   mode==450: l1lll_l1_ = l1l1l11_l1_()
	elif mode==451: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==452: l1lll_l1_ = PLAY(url)
	elif mode==453: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==454: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==459: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㱉"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ㱊"),l1l111_l1_ (u"ࠧࠨ㱋"),l1l111_l1_ (u"ࠨࠩ㱌"),l1l111_l1_ (u"ࠩࠪ㱍"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㱎"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㱏"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㱐"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㱑"),l1l111_l1_ (u"ࠧࠨ㱒"),459,l1l111_l1_ (u"ࠨࠩ㱓"),l1l111_l1_ (u"ࠩࠪ㱔"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㱕"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㱖"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㱗")+l1lllll_l1_+l1l111_l1_ (u"࠭ๅฬสอหฯࠦไ้ัํࠤ๋ะࠧ㱘"),l1l11ll_l1_,451,l1l111_l1_ (u"ࠧࠨ㱙"),l1l111_l1_ (u"ࠨࠩ㱚"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ㱛"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㱜"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㱝")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ㱞"),l1l11ll_l1_,451,l1l111_l1_ (u"࠭ࠧ㱟"),l1l111_l1_ (u"ࠧࠨ㱠"),l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㱡"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㱢"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㱣"),l1l111_l1_ (u"ࠫࠬ㱤"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡍࡢ࡫ࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࠢࡔ࡫ࡷࡩࡘࡲࡩࡥࡧࡵࠦࠬ㱥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㱦"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩ㱧"): continue
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㱨"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㱩")+l1lllll_l1_+title,l1ll1ll_l1_,451)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠪࠫ㱪")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㱫"),url,l1l111_l1_ (u"ࠬ࠭㱬"),l1l111_l1_ (u"࠭ࠧ㱭"),l1l111_l1_ (u"ࠧࠨ㱮"),l1l111_l1_ (u"ࠨࠩ㱯"),l1l111_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ㱰"))
	html = response.content
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㱱"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡹࡤࡺࡪࡹࠢࠨ㱲"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l111l1l1l_l1_==l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㱳"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡓࡧࡦࡩࡳࡺࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ㱴"),html,re.DOTALL)
		block = l11llll_l1_[0]
	elif l1l111_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭㱵") in html:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㱶"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࠨࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㱷"),block,re.DOTALL)
	elif l111l1l1l_l1_ in [l1l111_l1_ (u"ࠪ࠴ࠬ㱸"),l1l111_l1_ (u"ࠫ࠶࠭㱹"),l1l111_l1_ (u"ࠬ࠸ࠧ㱺")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀࠪ㱻"),html,re.DOTALL)
		block = l11llll_l1_[int(l111l1l1l_l1_)]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㱼"),html,re.DOTALL)
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ㱽"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ㱾"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨ㱿"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪ㲀"),l1l111_l1_ (u"ࠬษฺ็์ฬࠫ㲁"),l1l111_l1_ (u"࠭ใๅ์หࠫ㲂"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭㲃"),l1l111_l1_ (u"ࠨ้าหๆ࠭㲄"),l1l111_l1_ (u"่ࠩฬฬืวสࠩ㲅"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧ㲆"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫ㲇"),l1l111_l1_ (u"ࠬอไษ๊่ࠫ㲈")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ㲉") in html and l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠬ㲊") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㲋"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠩ࠲ࠫ㲌"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ㲍"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ㲎"),title,re.DOTALL)
		if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"๋ࠬำๅี็ࠫ㲏") not in title:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㲐"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧฮๆๅอࠬ㲑") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㲒") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㲓"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㲔"),l1lllll_l1_+title,l1ll1ll_l1_,453,l1ll1l_l1_)
	if l111l1l1l_l1_ in [l1l111_l1_ (u"ࠫࠬ㲕"),l1l111_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㲖")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㲗"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㲘"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲙"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ㲚")+title,l1ll1ll_l1_,451)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ㲛"),url,l1l111_l1_ (u"ࠫࠬ㲜"),l1l111_l1_ (u"ࠬ࠭㲝"),l1l111_l1_ (u"࠭ࠧ㲞"),l1l111_l1_ (u"ࠧࠨ㲟"),l1l111_l1_ (u"ࠨࡎࡒࡈ࡞ࡔࡅࡕ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧ㲠"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡇࡦࡺࡥࡨࡱࡵࡽࡘࡻࡢࡍ࡫ࡱ࡯ࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㲡"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩ㲢") in str(l11ll1l_l1_):
		title = re.findall(l1l111_l1_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠰ࠫ㲣"),html,re.DOTALL)
		title = title[0].strip(l1l111_l1_ (u"ࠬࠦࠧ㲤"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲥"),l1lllll_l1_+title,url,454)
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㲦"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㲧"),l1lllll_l1_+title,l1ll1ll_l1_,454)
	else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭㲨"),url,l1l111_l1_ (u"ࠪࠫ㲩"),l1l111_l1_ (u"ࠫࠬ㲪"),l1l111_l1_ (u"ࠬ࠭㲫"),l1l111_l1_ (u"࠭ࠧ㲬"),l1l111_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㲭"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㲮"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࡁࠫ㲯"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㲰"),l1lllll_l1_+title,l1ll1ll_l1_,452,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㲱"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㲲"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㲳"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭㲴")+title,l1ll1ll_l1_,454)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ㲵"),l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡡࡰࡳࡻ࡯ࡥࡴ࠱ࠪ㲶"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㲷"),l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ㲸"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㲹"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ㲺"),l1l111_l1_ (u"ࠧࠨ㲻"),l1l111_l1_ (u"ࠨࠩ㲼"),l1l111_l1_ (u"ࠩࠪ㲽"),l1l111_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㲾"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ㲿"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬࡙࡯ࡴ࡭ࡧࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡸ࡯ࡤࡦࡀࠪ㳀"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡳࡢࡦࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ㳁"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㳂")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ㳃")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡈࡴࡽ࡮࡭ࡱࡤࡨࡑ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪࠤࡶࡩࡱࡧࡲࡺࠤࠪ㳄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ㳅"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			name = unescapeHTML(name)
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ㳆"),name,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ㳇")+l111l1ll_l1_[0]
				name = l1l111_l1_ (u"࠭ࠧ㳈")
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠧࠨ㳉")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㳊")+name+l1l111_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㳋")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㳌"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠫࠬ㳍"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠬ࠭㳎"): return
	search = search.replace(l1l111_l1_ (u"࠭ࠠࠨ㳏"),l1l111_l1_ (u"ࠧࠬࠩ㳐"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ㳑")+search
	l1lll11_l1_(url)
	return
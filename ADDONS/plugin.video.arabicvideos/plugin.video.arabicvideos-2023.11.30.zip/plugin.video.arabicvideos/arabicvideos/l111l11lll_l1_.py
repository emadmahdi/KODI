# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭῟")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡅࡃ࠳ࡢࠫῠ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭ๅไฬหฮ๏࠭ῡ"),l1l111_l1_ (u"ࠧศ์ฯ๎ࠥฮำหࠩῢ")]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==770: l1lll_l1_ = l1l1l11_l1_()
	elif mode==771: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==772: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==773: l1lll_l1_ = PLAY(url)
	elif mode==774: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩΰ")+text)
	elif mode==775: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ῤ")+text)
	elif mode==776: l1lll_l1_ = l111l1111_l1_(url,l1llllll1_l1_)
	elif mode==779: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῥ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫῦ"),l1l111_l1_ (u"ࠬ࠭ῧ"),779,l1l111_l1_ (u"࠭ࠧῨ"),l1l111_l1_ (u"ࠧࠨῩ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬῪ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧΎ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪῬ"),l1l111_l1_ (u"ࠫࠬ῭"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ΅"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ`"),l1l111_l1_ (u"ࠧࠨ῰"),l1l111_l1_ (u"ࠨࠩ῱"),l1l111_l1_ (u"ࠩࠪῲ"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧῳ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡳࡧࡶ࠮࡮࡬ࡷࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩῴ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ῵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨῶ"))
			if any(value in title for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧῷ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪῸ")+l1lllll_l1_+title,l1ll1ll_l1_,771)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧΌ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪῺ"),l1l111_l1_ (u"ࠫࠬΏ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡳࡡࡪࡰ࠰ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࡵࡲࡧ࡮ࡧ࡬࠮ࡤࡲࡼࠬῼ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ´"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ῾"))
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ῿"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ ")+l1lllll_l1_+title,l1ll1ll_l1_,771,l1l111_l1_ (u"ࠪࠫ "),l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࡯ࡨࡲࡺ࠭ "))
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ "),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ "),l1l111_l1_ (u"ࠧࠨ "),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ "),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ "),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ "))
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ "),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ ")+l1lllll_l1_+title,l1ll1ll_l1_,771)
	return html
def l111l1111_l1_(url,type=l1l111_l1_ (u"࠭ࠧ​")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ‌"),url,l1l111_l1_ (u"ࠨࠩ‍"),l1l111_l1_ (u"ࠩࠪ‎"),l1l111_l1_ (u"ࠪࠫ‏"),l1l111_l1_ (u"ࠫࠬ‐"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭ࡔࡇࡄࡗࡔࡔࡓࡠࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ‑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡭ࡢ࡫ࡱ࠱ࡦࡸࡴࡪࡥ࡯ࡩࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩࡢࡴࡷ࡭ࡨࡲࡥࠨ‒"),html,re.DOTALL)
	if l11llll_l1_:
		l111l1l111_l1_,l1l1l1l1_l1_,items = l1l111_l1_ (u"ࠧࠨ–"),l1l111_l1_ (u"ࠨࠩ—"),[]
		for name,block in l11llll_l1_:
			if l1l111_l1_ (u"ࠩะ่็อสࠨ―") in name: l1l1l1l1_l1_ = block
			if l1l111_l1_ (u"้ࠪํอำๆࠩ‖") in name: l111l1l111_l1_ = block
		if l111l1l111_l1_ and not type:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ‗"),l111l1l111_l1_,re.DOTALL)
			if len(items)>1:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ‘"),l1lllll_l1_+title,l1ll1ll_l1_,776,l1ll1l_l1_,l1l111_l1_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭’"))
		if l1l1l1l1_l1_ and len(items)<2:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭‚"),l1l1l1l1_l1_,re.DOTALL)
			if items:
				for l1ll1ll_l1_,l1ll1l_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ‛"),l1lllll_l1_+title,l1ll1ll_l1_,773,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ“"),l1l1l1l1_l1_,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ”"),l1lllll_l1_+title,l1ll1ll_l1_,773)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠫࠬ„")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ‟"),url,l1l111_l1_ (u"࠭ࠧ†"),l1l111_l1_ (u"ࠧࠨ‡"),l1l111_l1_ (u"ࠨࠩ•"),l1l111_l1_ (u"ࠩࠪ‣"),l1l111_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ․"))
	html = response.content
	items,l111l1l11l_l1_,filters = [],False,False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲࡧࡩ࡯࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ‥"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭…"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ‧"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ "),l1lllll_l1_+title,l1ll1ll_l1_,771,l1l111_l1_ (u"ࠨࠩ "),l1l111_l1_ (u"ࠩࡶࡹࡧࡳࡥ࡯ࡷࠪ‪"))
				l111l1l11l_l1_ = True
	if not type and l1l111_l1_ (u"ࠪࡴࡂ࠭‫") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡪࡴࡸ࡭ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭‬"),html,re.DOTALL)
		if l11llll_l1_:
			if l111l1l11l_l1_: addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ‭"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭‮"),l1l111_l1_ (u"ࠧࠨ "),9999)
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ‰"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ‱"),url,775,l1l111_l1_ (u"ࠪࠫ′"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ″"))
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ‴"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩ‵"),url,774,l1l111_l1_ (u"ࠧࠨ‶"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨ‷"))
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ‸"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠧ‹"),url,779)
			addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ›"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ※"),l1l111_l1_ (u"࠭ࠧ‼"),9999)
			filters = True
	if not l111l1l11l_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࡦࡸࡴࡪࡥ࡯ࡩࠬ‽"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ‾"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				l1ll1l_l1_ = l1ll1l_l1_.strip(l1l111_l1_ (u"ࠩ࡟ࡲࠬ‿"))
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
				if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧ࠲ࠫ⁀") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⁁"),l1lllll_l1_+title,l1ll1ll_l1_,776,l1ll1l_l1_,l1l111_l1_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ⁂"))
				else: addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⁃"),l1lllll_l1_+title,l1ll1ll_l1_,773,l1ll1l_l1_)
			l1llllll1_l1_ = l1l111_l1_ (u"ࠧ࠲ࠩ⁄")
			if l1l111_l1_ (u"ࠨࡲࡀࠫ⁅") in url: url,l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠩࡳࡁࠬ⁆"),1)
			conn = l1l111_l1_ (u"ࠪࠪࠬ⁇") if l1l111_l1_ (u"ࠫࡄ࠭⁈") in url else l1l111_l1_ (u"ࠬࡅࠧ⁉")
			url = url+conn
			url = url.replace(l1l111_l1_ (u"࠭࠿ࠧࠩ⁊"),l1l111_l1_ (u"ࠧࡀࠩ⁋"))
			if len(items)==40:
				url = url+l1l111_l1_ (u"ࠨࡲࡀࠫ⁌")+str(int(l1llllll1_l1_)+1)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⁍"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้฻แฮหࠣห้ะวๅ์ฬࠫ⁎"),url,771)
			elif l1llllll1_l1_!=l1l111_l1_ (u"ࠫ࠶࠭⁏"):
				url = url+l1l111_l1_ (u"ࠬࡶ࠽ࠨ⁐")+str(int(l1llllll1_l1_)-1)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⁑"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆุๅาฯࠠศๆึหอ่ษࠨ⁒"),url,771)
	return
def PLAY(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⁓"),url,l1l111_l1_ (u"ࠩࠪ⁔"),l1l111_l1_ (u"ࠪࠫ⁕"),l1l111_l1_ (u"ࠫࠬ⁖"),l1l111_l1_ (u"ࠬ࠭⁗"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⁘"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡮ࡤࡦࡪࡲ࠾ศๆอู๋๐แ࠽࠱࡯ࡥࡧ࡫࡬࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⁙"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l111l11ll1_l1_,l1ll11l1_l1_,l111l11l1_l1_ = [],[],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡱ࡮ࡤࡽ࠲࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⁚"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ not in l111l11l1_l1_:
			l111l11l1_l1_.append(l1ll1ll_l1_)
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ⁛"))
	items = re.findall(l1l111_l1_ (u"ࠪࠦࡹࡸࠠࡧ࡮ࡨࡼ࠲ࡹࡴࡢࡴࡷࠦ࠳࠰࠿࠽ࡦ࡬ࡺࡃࡡࠠࡢ࠯ࡽࡅ࠲ࡠ࡝ࠫࠪ࡟ࡨࢀ࠹ࠬ࠵ࡿࠬ࡟ࠥࡧ࠭ࡻࡃ࠰࡞ࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⁜"),html,re.DOTALL)
	for l111l1ll_l1_,l1ll1ll_l1_ in items:
		if l1ll1ll_l1_ not in l111l11l1_l1_:
			l111l11l1_l1_.append(l1ll1ll_l1_)
			l111l1ll_l1_ = l111l1ll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭⁝"))
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ⁞"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ ")+server+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡥ࡟ࠨ⁠")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⁡"),url)
	return
def l1lll1_l1_(search,url=l1l111_l1_ (u"ࠩࠪ⁢")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠪࠤࠬ⁣"),l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ⁤"))
	if not url: url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭⁥")+l1lll1ll_l1_
	else: url = url+l1l111_l1_ (u"࠭࠿ࡵ࡫ࡷࡰࡪࡃࠧ⁦")+l1lll1ll_l1_+l1l111_l1_ (u"ࠧࠧࡩࡨࡲࡷ࡫࠽ࠧࡻࡨࡥࡷࡃࠦ࡭ࡣࡱ࡫ࡂ࠭⁧")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⁨"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⁩"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⁪"),url,l1l111_l1_ (u"ࠫࠬ⁫"),l1l111_l1_ (u"ࠬ࠭⁬"),l1l111_l1_ (u"࠭ࠧ⁭"),l1l111_l1_ (u"ࠧࠨ⁮"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰ࡋࡊ࡚࡟ࡇࡋࡏࡘࡊࡘࡓࡠࡄࡏࡓࡈࡑࡓ࠮࠳ࡶࡸࠬ⁯"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡩࡳࡷࡳ࠭ࡳࡱࡺࠬ࠳࠰࠿ࠪ࠾࠲ࡪࡴࡸ࡭࠿ࠩ⁰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡪࡲࡥࡤࡶࠣࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࠩⁱ"),block,re.DOTALL)
		l1111lll1_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111lll1_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠫࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⁲"),block,re.DOTALL)
	return items
def l1111ll11_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ⁳"),l1l111_l1_ (u"࠭࠿ࡵ࡫ࡷࡰࡪࡃࠦࠨ⁴"))
	return url
l1111ll1l_l1_ = [l1l111_l1_ (u"ࠧࡺࡧࡤࡶࠬ⁵"),l1l111_l1_ (u"ࠨ࡮ࡤࡲ࡬࠭⁶"),l1l111_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ⁷")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠪࡽࡪࡧࡲࠨ⁸"),l1l111_l1_ (u"ࠫࡱࡧ࡮ࡨࠩ⁹"),l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ⁺")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⁻"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ⁼"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ⁽"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ⁾"),l1l111_l1_ (u"ࠪࠫⁿ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ₀"))
	if type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭₁"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"࠭࠽ࠨ₂") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"ࠧ࠾ࠩ₃") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠪ₄")+category+l1l111_l1_ (u"ࠩࡀ࠴ࠬ₅")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠬ₆")+category+l1l111_l1_ (u"ࠫࡂ࠶ࠧ₇")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠧ₈"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ₉")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ₊"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨࡣ࡯ࡰࠬ₋"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭₌")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࠨ₍"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭₎"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ₏"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪₐ")+l11lll11_l1_
		l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧₑ"),l1lllll_l1_+l1l111_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫₒ"),l1llllll_l1_,771,l1l111_l1_ (u"ࠩࠪₓ"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࠪₔ"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫₕ"),l1lllll_l1_+l1l111_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬₖ")+l11l1l1l_l1_+l1l111_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬₗ"),l1llllll_l1_,771,l1l111_l1_ (u"ࠧࠨₘ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨₙ"))
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧₚ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪₛ"),l1l111_l1_ (u"ࠫࠬₜ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"้ࠬไࠡࠩ₝"),l1l111_l1_ (u"࠭ࠧ₞"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠧ࠾ࠩ₟") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠨࡆࡈࡊࡎࡔࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩ₠"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭₡")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ₢"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬ₣"),l1llllll_l1_,771,l1l111_l1_ (u"ࠬ࠭₤"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭₥"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ₦"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ₧"),l1lllll1_l1_,775,l1l111_l1_ (u"ࠩࠪ₨"),l1l111_l1_ (u"ࠪࠫ₩"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩ₪"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧ₫")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩ€")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩ₭")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ₮")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭₯")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ₰"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭₱")+name,l1lllll1_l1_,774,l1l111_l1_ (u"ࠬ࠭₲"),l1l111_l1_ (u"࠭ࠧ₳"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ₴")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ₵")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ₶")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬ₷")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ₸")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨ₹")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨ₺")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪ₻")+name
			if type==l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭₼"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ₽"),l1lllll_l1_+title,url,774,l1l111_l1_ (u"ࠪࠫ₾"),l1l111_l1_ (u"ࠫࠬ₿"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⃀") and l111l111l_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨ⃁") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⃂"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⃃")+l11ll111_l1_
				l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⃄"),l1lllll_l1_+title,l1llllll_l1_,771,l1l111_l1_ (u"ࠪࠫ⃅"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫ⃆"))
			elif type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭⃇"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⃈"),l1lllll_l1_+title,url,775,l1l111_l1_ (u"ࠧࠨ⃉"),l1l111_l1_ (u"ࠨࠩ⃊"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠩࡀࠪࠬ⃋"),l1l111_l1_ (u"ࠪࡁ࠵ࠬࠧ⃌"))
	filters = filters.strip(l1l111_l1_ (u"ࠫࠫ࠭⃍"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠬࡃࠧ⃎") in filters:
		items = filters.split(l1l111_l1_ (u"࠭ࠦࠨ⃏"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠧ࠾ࠩ⃐"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠨࠩ⃑")
	for key in l1111ll1l_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠩ࠳⃒ࠫ")
		if l1l111_l1_ (u"⃓ࠪࠩࠬ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⃔") and value!=l1l111_l1_ (u"ࠬ࠶ࠧ⃕"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠠࠬࠢࠪ⃖")+value
		elif mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ⃗") and value!=l1l111_l1_ (u"ࠨ࠲⃘ࠪ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"⃙ࠩࠩࠫ")+key+l1l111_l1_ (u"ࠪࡁ⃚ࠬ")+value
		elif mode==l1l111_l1_ (u"ࠫࡦࡲ࡬ࠨ⃛"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ⃜")+key+l1l111_l1_ (u"࠭࠽ࠨ⃝")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ⃞"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪ⃟"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠩࡀ࠴ࠬ⃠"),l1l111_l1_ (u"ࠪࡁࠬ⃡"))
	return l1l1l111_l1_
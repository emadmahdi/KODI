# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䡟")
l11llll1llll_l1_ = []
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䡠"):l1l111_l1_ (u"ࠧࠨ䡡")}
def l1l_l1_(l1ll11l1_l1_,source,type,url):
	if not l1ll11l1_l1_:
		l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭䡢"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ䡣")+source+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫ䡤")+type+l1l111_l1_ (u"ࠫࠥࡣࠧ䡥"))
		l11ll1l1llll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ䡦"),l1l111_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䡧"),l1l111_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䡨"))
		datetime = time.strftime(l1l111_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩ䡩"),time.gmtime(now))
		line = datetime,url
		key = source+l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧ䡪")+l1l11l11111_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠨ䡫")+str(kodi_version)
		message = l1l111_l1_ (u"ࠫࠬ䡬")
		if key not in list(l11ll1l1llll_l1_.keys()): l11ll1l1llll_l1_[key] = [line]
		else:
			if url not in str(l11ll1l1llll_l1_[key]): l11ll1l1llll_l1_[key].append(line)
			else: message = l1l111_l1_ (u"ࠬࡢ࡮้ࠡำหࠥอไโ์า๎ํࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥะูๆๆࠪ䡭")
		total = 0
		for key in list(l11ll1l1llll_l1_.keys()):
			l11ll1l1llll_l1_[key] = list(set(l11ll1l1llll_l1_[key]))
			total += len(l11ll1l1llll_l1_[key])
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ䡮"),l1l111_l1_ (u"ࠧࠨ䡯"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䡰"),l1l111_l1_ (u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪ䡱")+message+l1l111_l1_ (u"ࠪࡠࡳࡢ࡮ࠡๆ็฽้๋ࠠศๆหี๋อๅอࠢํๆํ๋ࠠษฮ่฽่ࠥวว็ฬࠤออไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣ๎ัีࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้๋ࠢืํ็๋ࠠ฻ิฺࠥ฿ไ๋ๅࠣห้ฮั็ษ่ะࠥษๆࠡฬิื้ࠦ็ั้ࠣห้่วว็ฬࠤส๊้ࠡษ็้อืๅอࠢ฼๊ิ๋วࠡ์ุฬาูࠦะั๊หࠥ࠻ࠠโ์า๎ํํวหࠩ䡲")+l1l111_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ䡳")+l1l111_l1_ (u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨ䡴")+str(total))
		if total>=5:
			l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"࠭ࠧ䡵"),l1l111_l1_ (u"ࠧࠨ䡶"),l1l111_l1_ (u"ࠨࠩ䡷"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䡸"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะࠥาๅฺࠢๅหห๋ษࠡใํ๋ฬࠦ࠵ࠡใํำ๏๎็ศฬ่๊๊ࠣࠦอัࠣห้ฮั็ษ่ะ๊ࠥ็ศ่่ࠢๆอสࠡใํำ๏๎ࠠ࠯࠰ࠣืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮๅิฯ๋ࠣีํࠠศๆๅหห๋ษࠡ࡞ࡱࡠࡳࠦ็ๅࠢอี๏ีࠠฦำึห้ࠦ็ั้ࠣห้่วว็ฬࠤ็ฮไࠡ็ึั์อࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆ่ฬึ๋ฬࠡสไัฺࠦ็ั้ࠣห้็๊ะ์๋๋ฬะࠠภࠣࠤࠫ䡹"))
			if l1llll1l1l_l1_==1:
				l11ll1ll111l_l1_ = l1l111_l1_ (u"ࠫࠬ䡺")
				for key in list(l11ll1l1llll_l1_.keys()):
					l11ll1ll111l_l1_ += l1l111_l1_ (u"ࠬࡢ࡮ࠨ䡻")+key
					l1l111l111ll_l1_ = sorted(l11ll1l1llll_l1_[key],reverse=False,key=lambda l11ll1l111ll_l1_: l11ll1l111ll_l1_[0])
					for datetime,url in l1l111l111ll_l1_:
						l11ll1ll111l_l1_ += l1l111_l1_ (u"࠭࡜࡯ࠩ䡼")+datetime+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ䡽")+l111l11_l1_(url)
					l11ll1ll111l_l1_ += l1l111_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭䡾")
				import l1l11lll11l_l1_
				succeeded = l1l11lll11l_l1_.l11l11l1l1l_l1_(l1l111_l1_ (u"࡙ࠩ࡭ࡩ࡫࡯ࡴࠩ䡿"),l1l111_l1_ (u"ࠪࠫ䢀"),False,l1l111_l1_ (u"ࠫࠬ䢁"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䢂"),l1l111_l1_ (u"࠭ࠧ䢃"),l11ll1ll111l_l1_)
				if succeeded: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䢄"),l1l111_l1_ (u"ࠨࠩ䢅"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䢆"),l1l111_l1_ (u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭䢇"))
				else: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䢈"),l1l111_l1_ (u"ࠬ࠭䢉"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䢊"),l1l111_l1_ (u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ลาีส่ࠬ䢋"))
			if l1llll1l1l_l1_!=-1:
				l11ll1l1llll_l1_ = {}
				l1lll1111ll_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䢌"),l1l111_l1_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡇࡕࡖࡔࡘࡓࠨ䢍"))
		if l11ll1l1llll_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䢎"),l1l111_l1_ (u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ䢏"),l11ll1l1llll_l1_,l1l1lll1l1l_l1_)
		return
	l1ll11l1_l1_ = list(set(l1ll11l1_l1_))
	l1l1lll1_l1_,l1llll_l1_ = l11ll11ll11l_l1_(l1ll11l1_l1_,source)
	l1l1111ll1l1_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭䢐"))
	l11ll1l11111_l1_ = str(l1llll_l1_).count(l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䢑"))
	l1l111l11ll1_l1_ = len(l1llll_l1_)-l1l1111ll1l1_l1_-l11ll1l11111_l1_
	l11ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧๆึส๋ิฯ࠺ࠨ䢒")+str(l1l1111ll1l1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࠥะอๆ์็࠾ࠬ䢓")+str(l11ll1l11111_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࠦรฯำ์࠾ࠬ䢔")+str(l1l111l11ll1_l1_)
	if not l1llll_l1_: result,l1l111l1l111_l1_ = l1l111_l1_ (u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ䢕"),l1l111_l1_ (u"ࠫࠬ䢖")
	else:
		while True:
			l1l111l1l111_l1_ = l1l111_l1_ (u"ࠬ࠭䢗")
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l11ll1ll1ll1_l1_,l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠳ࡶࡸࡤࡳࡥ࡯ࡷࠪ䢘")
			else:
				title = l1l1lll1_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠧิ์ิๅึ࠭䢙") in title and l1l111_l1_ (u"ࠨ࠴่ะ์๎ไ࠳ࠩ䢚") in title:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䢛"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ䢜")+title+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ䢝")+l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ䢞"))
					import l1l11lll11l_l1_
					l1l11lll11l_l1_.l11l1ll_l1_(156)
					result = l1l111_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䢟")
				else:
					l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䢠"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭䢡")+title+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䢢")+l1ll1ll_l1_+l1l111_l1_ (u"ࠪࠤࡢ࠭䢣"))
					result,l1l111l1l111_l1_,l1l1l11ll1l1_l1_ = l11lll1lllll_l1_(l1ll1ll_l1_,source,type)
			if l1l111_l1_ (u"ࠫࡡࡴࠧ䢤") not in l1l111l1l111_l1_: l11llllll1ll_l1_,l11l1llll1l_l1_ = l1l111l1l111_l1_,l1l111_l1_ (u"ࠬ࠭䢥")
			else: l11llllll1ll_l1_,l11l1llll1l_l1_ = l1l111l1l111_l1_.split(l1l111_l1_ (u"࠭࡜࡯ࠩ䢦"),1)
			if result in [l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䢧"),l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ䢨"),l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ䢩"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ䢪"),l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ䢫")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ䢬"),l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ䢭"),l1l111_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭䢮")]: break
			elif result not in [l1l111_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ䢯"),l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ䢰")]: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䢱"),l1l111_l1_ (u"ࠫࠬ䢲"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䢳"),l1l111_l1_ (u"࠭วๅีํีๆืࠠๅ็ࠣ๎฾๋ไࠡฮิฬู๊ࠥาใิࠤ฿๐ั่ࠩ䢴")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ䢵")+l11llllll1ll_l1_+l1l111_l1_ (u"ࠨ࡞ࡱࠫ䢶")+l11l1llll1l_l1_)
	if result==l1l111_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䢷") and len(l1l1lll1_l1_)>0: l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䢸"),l1l111_l1_ (u"ࠫࠬ䢹"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䢺"),l1l111_l1_ (u"࠭ำ๋ำไีࠥํะศࠢส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠤัืศࠡใํำ๏๎ࠠ฻์ิ๋ࠬ䢻")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ䢼")+l1l111l1l111_l1_)
	elif result in [l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ䢽"),l1l111_l1_ (u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪ䢾")] and l1l111l1l111_l1_!=l1l111_l1_ (u"ࠪࠫ䢿"): l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䣀"),l1l111_l1_ (u"ࠬ࠭䣁"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䣂"),l1l111l1l111_l1_)
	return result
def l11lll1lllll_l1_(url,source,type=l1l111_l1_ (u"ࠧࠨ䣃")):
	url = url.strip(l1l111_l1_ (u"ࠨࠢࠪ䣄")).strip(l1l111_l1_ (u"ࠩࠩࠫ䣅")).strip(l1l111_l1_ (u"ࠪࡃࠬ䣆")).strip(l1l111_l1_ (u"ࠫ࠴࠭䣇"))
	l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111ll11l_l1_(url,source)
	if l1l111l1l111_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䣈"): return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_:
		while True:
			if len(l1llll_l1_)==1: l11l11l_l1_ = 0
			else: l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ䣉"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: result = l1l111_l1_ (u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࡡ࠵ࡲࡩࡥ࡭ࡦࡰࡸࠫ䣊")
			else:
				l1l11l11111l_l1_ = l1llll_l1_[l11l11l_l1_]
				title = l1l1lll1_l1_[l11l11l_l1_]
				l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䣋"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡳࡦ࡮ࡨࡧࡹ࡫ࡤࠡࡸ࡬ࡨࡪࡵࠠࠡࠢࡖࡩࡱ࡫ࡣࡵࡧࡧ࠾ࠥࡡࠠࠨ䣌")+title+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ䣍")+str(l1l11l11111l_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠧ䣎"))
				if l1l111_l1_ (u"ࠬࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࠨ䣏") in l1l11l11111l_l1_ and l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭䣐") in l1l11l11111l_l1_:
					l1l11l111l11_l1_,l1l1l11l1l11_l1_,l1l1l11ll1l1_l1_ = l11lll111l11_l1_(l1l11l11111l_l1_)
					if l1l1l11ll1l1_l1_: l1l11l11111l_l1_ = l1l1l11ll1l1_l1_[0]
					else: l1l11l11111l_l1_ = l1l111_l1_ (u"ࠧࠨ䣑")
				if not l1l11l11111l_l1_: result = l1l111_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䣒")
				else: result = l1llll111_l1_(l1l11l11111l_l1_,source,type)
			if result in [l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ䣓"),l1l111_l1_ (u"ࠪࡸࡪࡹࡴࡪࡰࡪࠫ䣔"),l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ䣕")] or len(l1llll_l1_)==1: break
			elif result in [l1l111_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ䣖"),l1l111_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ䣗"),l1l111_l1_ (u"ࠧࡵࡴ࡬ࡩࡩ࠭䣘")]: break
			else: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䣙"),l1l111_l1_ (u"ࠩࠪ䣚"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䣛"),l1l111_l1_ (u"ࠫฬ๊ๅๅใฺ่๊๊ࠣࠦ็็ࠤัืศࠡ็็ๅࠥเ๊า้ࠪ䣜"))
	else:
		result = l1l111_l1_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ䣝")
		l11l1l11l1_l1_ = l1l1111l11_l1_(url)
		if l11l1l11l1_l1_: result = l1llll111_l1_(url,source,type)
	return result,l1l111l1l111_l1_,l1llll_l1_
def l11lll1l1lll_l1_(url,source):
	l1lllll1_l1_,l11lll1lll1l_l1_,server,l11ll1l11l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = url,l1l111_l1_ (u"࠭ࠧ䣞"),l1l111_l1_ (u"ࠧࠨ䣟"),l1l111_l1_ (u"ࠨࠩ䣠"),l1l111_l1_ (u"ࠩࠪ䣡"),l1l111_l1_ (u"ࠪࠫ䣢"),l1l111_l1_ (u"ࠫࠬ䣣"),l1l111_l1_ (u"ࠬ࠭䣤")
	if l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䣥") in url:
		l1lllll1_l1_,l11lll1lll1l_l1_ = url.split(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䣦"),1)
		l11lll1lll1l_l1_ = l11lll1lll1l_l1_+l1l111_l1_ (u"ࠨࡡࡢࠫ䣧")+l1l111_l1_ (u"ࠩࡢࡣࠬ䣨")+l1l111_l1_ (u"ࠪࡣࡤ࠭䣩")+l1l111_l1_ (u"ࠫࡤࡥࠧ䣪")
		l11lll1lll1l_l1_ = l11lll1lll1l_l1_.lower()
		name,type,l111lll_l1_,l111l1ll_l1_,l1ll1l111lll_l1_ = l11lll1lll1l_l1_.split(l1l111_l1_ (u"ࠬࡥ࡟ࠨ䣫"))[:5]
	if l111l1ll_l1_==l1l111_l1_ (u"࠭ࠧ䣬"): l111l1ll_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ䣭")
	else: l111l1ll_l1_ = l111l1ll_l1_.replace(l1l111_l1_ (u"ࠨࡲࠪ䣮"),l1l111_l1_ (u"ࠩࠪ䣯")).replace(l1l111_l1_ (u"ࠪࠤࠬ䣰"),l1l111_l1_ (u"ࠫࠬ䣱"))
	l1lllll1_l1_ = l1lllll1_l1_.strip(l1l111_l1_ (u"ࠬࡅࠧ䣲")).strip(l1l111_l1_ (u"࠭࠯ࠨ䣳")).strip(l1l111_l1_ (u"ࠧࠧࠩ䣴"))
	server = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠨࡪࡲࡷࡹ࠭䣵"))
	if name: l11ll1l11l11_l1_ = name
	else: l11ll1l11l11_l1_ = server
	l11ll1l11l11_l1_ = l1l111l_l1_(l11ll1l11l11_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䣶"))
	name = name.replace(l1l111_l1_ (u"้ࠪออิาࠩ䣷"),l1l111_l1_ (u"ࠫࠬ䣸")).replace(l1l111_l1_ (u"ู๊ࠬาใิࠫ䣹"),l1l111_l1_ (u"࠭ࠧ䣺")).replace(l1l111_l1_ (u"ࠧศๆࠣࠫ䣻"),l1l111_l1_ (u"ࠨࠢࠪ䣼")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䣽"),l1l111_l1_ (u"ࠪࠤࠬ䣾"))
	l11lll1lll1l_l1_ = l11lll1lll1l_l1_.replace(l1l111_l1_ (u"๊ࠫฮวีำࠪ䣿"),l1l111_l1_ (u"ࠬ࠭䤀")).replace(l1l111_l1_ (u"࠭ำ๋ำไีࠬ䤁"),l1l111_l1_ (u"ࠧࠨ䤂")).replace(l1l111_l1_ (u"ࠨษ็ࠤࠬ䤃"),l1l111_l1_ (u"ࠩࠣࠫ䤄")).replace(l1l111_l1_ (u"ࠪࠤࠥ࠭䤅"),l1l111_l1_ (u"ࠫࠥ࠭䤆"))
	l11ll1l11l11_l1_ = l11ll1l11l11_l1_.replace(l1l111_l1_ (u"๋ࠬศศึิࠫ䤇"),l1l111_l1_ (u"࠭ࠧ䤈")).replace(l1l111_l1_ (u"ࠧิ์ิๅึ࠭䤉"),l1l111_l1_ (u"ࠨࠩ䤊")).replace(l1l111_l1_ (u"ࠩส่ࠥ࠭䤋"),l1l111_l1_ (u"ࠪࠤࠬ䤌")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䤍"),l1l111_l1_ (u"ࠬࠦࠧ䤎"))
	return l1lllll1_l1_,l11lll1lll1l_l1_,server,l11ll1l11l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l1l1111ll1ll_l1_(url,source):
	l1l111ll1111_l1_,name,l11l1ll1111_l1_,l11lll1ll111_l1_,l11lll1ll11l_l1_,l11lllll1111_l1_,l1l111l1ll11_l1_ = l1l111_l1_ (u"࠭ࠧ䤏"),l1l111_l1_ (u"ࠧࠨ䤐"),None,None,None,None,None
	l1lllll1_l1_,l11lll1lll1l_l1_,server,l11ll1l11l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11lll1l1lll_l1_(url,source)
	if l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䤑") in url:
		if   type==l1l111_l1_ (u"ࠩࡨࡱࡧ࡫ࡤࠨ䤒"): type = l1l111_l1_ (u"ࠪࠤࠬ䤓")+l1l111_l1_ (u"๊ࠫ็ึๅࠩ䤔")
		elif type==l1l111_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䤕"): type = l1l111_l1_ (u"࠭ࠠࠨ䤖")+l1l111_l1_ (u"ࠧࠦ็ืห์ีษࠨ䤗")
		elif type==l1l111_l1_ (u"ࠨࡤࡲࡸ࡭࠭䤘"): type = l1l111_l1_ (u"ࠩࠣࠫ䤙")+l1l111_l1_ (u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬ䤚")
		elif type==l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䤛"): type = l1l111_l1_ (u"ࠬࠦࠧ䤜")+l1l111_l1_ (u"࠭ࠥࠦࠧอั๊๐ไࠨ䤝")
		elif type==l1l111_l1_ (u"ࠧࠨ䤞"): type = l1l111_l1_ (u"ࠨࠢࠪ䤟")+l1l111_l1_ (u"ࠩࠨࠩࠪࠫࠧ䤠")
		if l111lll_l1_!=l1l111_l1_ (u"ࠪࠫ䤡"):
			if l1l111_l1_ (u"ࠫࡲࡶ࠴ࠨ䤢") not in l111lll_l1_: l111lll_l1_ = l1l111_l1_ (u"ࠬࠫࠧ䤣")+l111lll_l1_
			l111lll_l1_ = l1l111_l1_ (u"࠭ࠠࠨ䤤")+l111lll_l1_
		if l111l1ll_l1_!=l1l111_l1_ (u"ࠧࠨ䤥"):
			l111l1ll_l1_ = l1l111_l1_ (u"ࠨࠧࠨࠩࠪࠫࠥࠦࠧࠨࠫ䤦")+l111l1ll_l1_
			l111l1ll_l1_ = l1l111_l1_ (u"ࠩࠣࠫ䤧")+l111l1ll_l1_[-9:]
	if   l1l111_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䤨")		in source: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ䤩")		in source: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࠫ䤪")
	elif l1l111_l1_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ䤫")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩ䤬")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧ䤭")	in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠩࡶࡩࡪ࡫ࡥࡥࠩ䤮")		in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ䤯")
	elif l1l111_l1_ (u"ࠫࡦࡲࡡࡳࡣࡥࠫ䤰")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠬࡹࡥࡦࡧࡨࡨࠬ䤱")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ䤲")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠧࡵ࠹ࡰࡩࡪࡲࠧ䤳")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨ䤴")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ䤵")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䤶")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢ࠯ࡦࡰࡺࡨࠧ䤷")	in name:   l11l1ll1111_l1_	= l1l111_l1_ (u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧ䤸")
	elif l1l111_l1_ (u"࠭แอำࠪ䤹")			in name:   l11l1ll1111_l1_	= l1l111_l1_ (u"ࠧࡧࡣ࡭ࡩࡷ࠭䤺")
	elif l1l111_l1_ (u"ࠨใ็ื฼๐ๆࠨ䤻")		in name:   l11l1ll1111_l1_	= l1l111_l1_ (u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬ䤼")
	elif l1l111_l1_ (u"ࠪ࡫ࡩࡸࡩࡷࡧࠪ䤽")		in l1lllll1_l1_:   l11l1ll1111_l1_	= l1l111_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ䤾")
	elif l1l111_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ䤿")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭䥀")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ䥁")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ䥂")		in name:   l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ䥃")	in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ䥄")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠫࡹࡼࡦࡶࡰࠪ䥅")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠬࡺࡶ࡬ࡵࡤࠫ䥆")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ䥇")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䥈")		in server: l11l1ll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ䥉")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ䥊")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ䥋")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ䥌")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ䥍")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ䥎")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭䥏")	 	in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ䥐")
	elif l1l111_l1_ (u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ䥑")	 	in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ䥒")
	elif l1l111_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ䥓")	in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩ䥔")
	elif l1l111_l1_ (u"࠭ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨ䥕")		in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩ䥖")
	elif l1l111_l1_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ䥗")		in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫ䥘")
	elif l1l111_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ䥙")		in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䥚")
	elif l1l111_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䥛")	in server: l11l1ll1111_l1_	= l1l111_l1_ (u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ䥜")
	elif l1l111_l1_ (u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ䥝")	in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ䥞")
	elif l1l111_l1_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ䥟")		in server: l11l1ll1111_l1_	= l1l111_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ䥠")
	elif l1l111_l1_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ䥡")	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ䥢")
	elif l1l111_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ䥣")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䥤")
	elif l1l111_l1_ (u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ䥥")	 	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠩࡦࡥࡹࡩࡨࠨ䥦")
	elif l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ䥧")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ䥨")
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡤࡰࠫ䥩")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"࠭ࡶࡪࡦࡥࡱࠬ䥪")
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧ࡬ࡩ࠭䥫")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡺ࡮ࡪࠧ䥬")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ䥭")		in server: l11lllll1111_l1_	= l11ll1l11l11_l1_
	elif l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ䥮")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭䥯")
	elif l1l111_l1_ (u"ࠬ࡭࡯ࡷ࡫ࡧࠫ䥰")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"࠭ࡧࡰࡸ࡬ࡨࠬ䥱")
	elif l1l111_l1_ (u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ䥲") 	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ䥳")
	elif l1l111_l1_ (u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ䥴")	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䥵")
	elif l1l111_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ䥶")	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ䥷")
	elif l1l111_l1_ (u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ䥸") 	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ䥹")
	elif l1l111_l1_ (u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ䥺")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䥻")
	elif l1l111_l1_ (u"ࠪࡹࡵࡶࠧ䥼") 			in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ䥽")
	elif l1l111_l1_ (u"ࠬࡻࡰࡣࠩ䥾") 			in server: l11lll1ll111_l1_	= l1l111_l1_ (u"࠭ࡵࡱࡤࡲࡱࠬ䥿")
	elif l1l111_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䦀") 		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠨࡷࡴࡰࡴࡧࡤࠨ䦁")
	elif l1l111_l1_ (u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ䦂") 	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ䦃")
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ䦄")		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠬࡼࡩࡥࡤࡲࡦࠬ䦅")
	elif l1l111_l1_ (u"࠭ࡶࡪࡦࡲࡾࡦ࠭䦆") 		in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ䦇")
	elif l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ䦈") 	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭䦉")
	elif l1l111_l1_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ䦊")	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ䦋")
	elif l1l111_l1_ (u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩ䦌")	in server: l11lll1ll111_l1_	= l1l111_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䦍")
	if   l11l1ll1111_l1_:	l1l111ll1111_l1_,name = l1l111_l1_ (u"ࠧฯษุࠫ䦎"),l11l1ll1111_l1_
	elif l11lllll1111_l1_:		l1l111ll1111_l1_,name = l1l111_l1_ (u"ࠨ่ࠧัิีࠧ䦏"),l11lllll1111_l1_
	elif l11lll1ll111_l1_:		l1l111ll1111_l1_,name = l1l111_l1_ (u"ࠩࠨࠩ฾อๅࠡ็฼ีํ็ࠧ䦐"),l11lll1ll111_l1_
	elif l11lll1ll11l_l1_:	l1l111ll1111_l1_,name = l1l111_l1_ (u"ูࠪࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ䦑"),l11lll1ll11l_l1_
	elif l1l111l1ll11_l1_:	l1l111ll1111_l1_,name = l1l111_l1_ (u"ࠫࠪࠫࠥࠦ฻ส้ࠥิวาฮํࠫ䦒"),l11ll1l11l11_l1_
	else:			l1l111ll1111_l1_,name = l1l111_l1_ (u"ࠬࠫࠥࠦࠧࠨ฽ฬ๋ࠠๆฮ๊์้࠭䦓"),l11ll1l11l11_l1_
	return l1l111ll1111_l1_,name,type,l111lll_l1_,l111l1ll_l1_
def l11llll11lll_l1_(url,source):
	l1lllll1_l1_,l11lll1lll1l_l1_,server,l11ll1l11l11_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l11lll1l1lll_l1_(url,source)
	if   l1l111_l1_ (u"࠭ࡁࡌࡑࡄࡑࠬ䦔")		in source: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111_l1_(l1lllll1_l1_,name)
	elif l1l111_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭䦕")		in source: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l_l1_(l1lllll1_l1_,type,l111l1ll_l1_)
	elif l1l111_l1_ (u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䦖")		in source: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll1l1l1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ䦗")		in source: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬ䦘")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1111ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ䦙")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡧ࡬ࡢࡴࡤࡦࠬ䦚")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ䦛")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11l11lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡴࡪࡤ࡬ࡪࡪ࠴ࡶࠩ䦜")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11l11lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡧࡪࡽࡳࡵࡷࠨ䦝")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡷࡺ࡫ࡻ࡮ࠨ䦞")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡸࡻࡱࡳࡢࠩ䦟")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡹࡼ࠭ࡧ࠰ࡦࡳࡲ࠭䦠")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ䦡")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l111ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ䦢")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l1l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ䦣")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1111l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䦤")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l11lll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡹࡷ࠹ࡻࠧ䦥")			in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll1l1l11ll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡪࡦࡰࡥࡳࠩ䦦")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll1ll11l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ䦧")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭䦨")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111111l1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪ䦩")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ䦪")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11111l11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ䦫")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll11l111l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ䦬")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1ll11l1llll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡦࡴࡱࡲࡢࠩ䦭")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11l1ll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ䦮")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11ll1_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧ䦯")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭䦰")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࡴࡦࡥ࡫ࠫ䦱")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠨࡩࡸࡰ࡫ࡺࡥࡤࡪࠪ䦲")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡴࡤࡸࡪ࠭䦳")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠪࡴࡨࡸࡥࡷ࡫ࡨࡻࠬ䦴")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ䦵")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ䦶")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ䦷")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䦸"),[l1l111_l1_ (u"ࠨࠩ䦹")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ䦺")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111l11lll_l1_(url)
	elif l1l111_l1_ (u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࠫ䦻")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1111lll1l_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠪ䦼")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l111ll1ll11_l1_(l1lllll1_l1_)
	elif l1l111_l1_ (u"ࠬࡻࡰࡣࡣࡰࠫ䦽") 		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"࠭ࠧ䦾"),[l1l111_l1_ (u"ࠧࠨ䦿")],[l1lllll1_l1_]
	else: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䧀"),[l1l111_l1_ (u"ࠩࠪ䧁")],[l1lllll1_l1_]
	return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll1l11ll_l1_(url,source):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ䧂"))
	l11llll11ll1_l1_ = False
	if   l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࠪ䧃")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ䧄")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1l1_l1_(url)
	elif l1l111_l1_ (u"࠭ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶࠪ䧅") in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l1lll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬࠭䧆")	in url: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll11l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ䧇")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"ࠩࡵࡩࡻ࡯ࡥࡸࡴࡤࡸࡪ࠭䧈")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111_l1_(url)
	elif l1l111_l1_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ䧉")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1l11ll1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭䧊")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111l11_l1_(url)
	elif l1l111_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭䧋")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1lll1l1l1l_l1_(url)
	elif l1l111_l1_ (u"࠭ࡡࡳࡣࡥࡰࡴࡧࡤࡴࠩ䧌")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l1111l111l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ䧍")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1ll1111_l1_(url)
	elif l1l111_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ䧎")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111111lll_l1_(url)
	elif l1l111_l1_ (u"ࠩࡨ࠹ࡹࡹࡡࡳࠩ䧏")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll11lll11_l1_(url)
	elif l1l111_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ䧐")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l111l1_l1_(url)
	elif l1l111_l1_ (u"ࠫ࡮ࡴࡦ࡭ࡣࡰ࠲ࡨࡩࠧ䧑")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1l111l1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ䧒")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll1l1_l1_(url)
	elif l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ䧓")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡷ࡫ࡧࡦࡲ࠭䧔")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠨࡸ࡬ࡨ࡭ࡪࠧ䧕")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ䧖")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠪࡰ࡮࡯ࡩࡷ࡫ࡧࡩࡴ࠭䧗")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡰࡤࡤࠫ䧘")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11llll_l1_(url)
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡵࡳࡩࡪࡪࠧ䧙")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll11llll_l1_(url)
	elif l1l111_l1_ (u"࠭ࡵࡱࡤࡤࡱࠬ䧚") 		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䧛"),[l1l111_l1_ (u"ࠨࠩ䧜")],[url]
	elif l1l111_l1_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ䧝") 	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll1l11l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭䧞")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll1l1_l1_(url)
	elif l1l111_l1_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࡪࡲࠫ䧟")in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l11l111ll1_l1_(url)
	elif l1l111_l1_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ䧠") 	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll1lll111_l1_(url)
	elif l1l111_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ䧡")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllllll1_l1_(url)
	elif l1l111_l1_ (u"ࠧࡶࡲࡥࠫ䧢") 			in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111111_l1_(url)
	elif l1l111_l1_ (u"ࠨࡷࡳࡴࠬ䧣") 			in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll111111_l1_(url)
	elif l1l111_l1_ (u"ࠩࡸࡵࡱࡵࡡࡥࠩ䧤") 		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllll111l_l1_(url)
	elif l1l111_l1_ (u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ䧥") 	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll1111l_l1_(url)
	elif l1l111_l1_ (u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ䧦")		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lllllll1l_l1_(url)
	elif l1l111_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ䧧") 		in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l1111_l1_(url)
	elif l1l111_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ䧨") 	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llllll11l_l1_(url)
	elif l1l111_l1_ (u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ䧩")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11ll11ll1ll_l1_(url)
	elif l1l111_l1_ (u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ䧪")	in server: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111l111l1_l1_(url)
	else: l11llll11ll1_l1_ = True
	if l11llll11ll1_l1_ or l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠫ䧫") in l1l111l1l111_l1_:
		l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠢࡉࡥ࡮ࡲࡥࡥࠩ䧬"),[],[]
	return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
def l11lll11l1ll_l1_(l1l1l11ll111_l1_):
	if l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䧭") in str(type(l1l1l11ll111_l1_)):
		l1ll_l1_ = []
		for l1ll1ll_l1_ in l1l1l11ll111_l1_:
			if l1l111_l1_ (u"ࠬࡹࡴࡳࠩ䧮") in str(type(l1ll1ll_l1_)):
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"࠭࡜ࡳࠩ䧯"),l1l111_l1_ (u"ࠧࠨ䧰")).replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ䧱"),l1l111_l1_ (u"ࠩࠪ䧲")).strip(l1l111_l1_ (u"ࠪࠤࠬ䧳"))
			l1ll_l1_.append(l1ll1ll_l1_)
	else: l1ll_l1_ = l1l1l11ll111_l1_.replace(l1l111_l1_ (u"ࠫࡡࡸࠧ䧴"),l1l111_l1_ (u"ࠬ࠭䧵")).replace(l1l111_l1_ (u"࠭࡜࡯ࠩ䧶"),l1l111_l1_ (u"ࠧࠨ䧷")).strip(l1l111_l1_ (u"ࠨࠢࠪ䧸"))
	return l1ll_l1_
def l1l1111ll11l_l1_(url,source):
	l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䧹"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡶࡸࡦࡸࡴࡦࡦࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫ䧺")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ䧻"))
	l1l111l1ll11_l1_,l1ll1ll_l1_,l11lll11ll11_l1_ = l1l111_l1_ (u"ࠬࡏࡎࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࠩ䧼"),l1l111_l1_ (u"࠭ࠧ䧽"),l1l111_l1_ (u"ࠧࠨ䧾")
	l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11llll11lll_l1_(url,source)
	l1llll_l1_ = l11lll11l1ll_l1_(l1llll_l1_)
	if l1l111l1l111_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䧿"): return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
	elif l1llll_l1_: l1ll1ll_l1_ = l1llll_l1_[0]
	if l1l111l1l111_l1_==l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䨀"):
		l1l111l1ll11_l1_ = l1l111_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠲ࠩ䨁")
		l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l11ll_l1_(l1ll1ll_l1_,source)
		l1llll_l1_ = l11lll11l1ll_l1_(l1llll_l1_)
		if l1l111l1l111_l1_==l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䨂"): return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
		elif l1l111_l1_ (u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠴ࠫ䨃") in l1l111l1l111_l1_:
			l11lll11ll11_l1_ += l1l111_l1_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠵࠿ࠦࠧ䨄")+l1l111l1l111_l1_
			l1l111l1ll11_l1_ = l1l111_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭䨅")
			l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l11l1_l1_(l1ll1ll_l1_,source)
			l1llll_l1_ = l11lll11l1ll_l1_(l1llll_l1_)
			if l1l111l1l111_l1_==l1l111_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䨆"): return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
			elif l1l111_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠨ䨇") in l1l111l1l111_l1_:
				l11lll11ll11_l1_ += l1l111_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠣࠫ䨈")+l1l111l1l111_l1_
				l1l111l1ll11_l1_ = l1l111_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠵ࠪ䨉")
				l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l11lll1l111l_l1_(l1ll1ll_l1_,source)
				l1llll_l1_ = l11lll11l1ll_l1_(l1llll_l1_)
				if l1l111l1l111_l1_==l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ䨊"): return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
				elif l1l111_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬ䨋") in l1l111l1l111_l1_:
					l11lll11ll11_l1_ += l1l111_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࡀࠠࠨ䨌")+l1l111l1l111_l1_
	elif l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠪ䨍") in l1l111l1l111_l1_: l11lll11ll11_l1_ = l1l111_l1_ (u"ࠩࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠵ࡀࠠࠨ䨎")+l1l111l1l111_l1_
	if l1llll_l1_: l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䨏"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡔࡨࡷࡴࡲࡶࡦࡴ࠽ࠤࡠࠦࠧ䨐")+l1l111l1ll11_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩ䨑")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭䨒")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡷ࡯ࡸࡸࡀࠠ࡜ࠢࠪ䨓")+str(l1llll_l1_)+l1l111_l1_ (u"ࠨࠢࡠࠫ䨔"))
	else: l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䨕"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ䨖")+url+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ䨗")+l1ll1ll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡉࡷࡸ࡯ࡳࡵ࠽ࠤࡠࠦࠧ䨘")+l11lll11ll11_l1_+l1l111_l1_ (u"࠭ࠠ࡞ࠩ䨙"))
	l11lll11ll11_l1_ = l111l11_l1_(l11lll11ll11_l1_)
	return l11lll11ll11_l1_,l1l1lll1_l1_,l1llll_l1_
def l11ll11ll11l_l1_(l1l1l11ll1l1_l1_,source):
	l1l1l11ll11_l1_ = l1ll1ll1_l1_
	data = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䨚"),l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䨛"),l1l1l11ll1l1_l1_)
	if data:
		l1l1lll1_l1_,l1llll_l1_ = list(zip(*data))
		return l1l1lll1_l1_,l1llll_l1_
	l1l1lll1_l1_,l1llll_l1_,l1l111l1111l_l1_ = [],[],[]
	for l1ll1ll_l1_ in l1l1l11ll1l1_l1_:
		if l1l111_l1_ (u"ࠩ࠲࠳ࠬ䨜") not in l1ll1ll_l1_: continue
		l1l111ll1111_l1_,name,type,l111lll_l1_,l111l1ll_l1_ = l1l1111ll1ll_l1_(l1ll1ll_l1_,source)
		l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡠࡩ࠱ࠧ䨝"),l111l1ll_l1_,re.DOTALL)
		if l111l1ll_l1_: l111l1ll_l1_ = int(l111l1ll_l1_[0])
		else: l111l1ll_l1_ = 0
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䨞"))
		l1l111l1111l_l1_.append([l1l111ll1111_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server])
	if l1l111l1111l_l1_:
		l11lll11lll1_l1_ = sorted(l1l111l1111l_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l11lll1111l1_l1_ = []
		for line in l11lll11lll1_l1_:
			if line not in l11lll1111l1_l1_:
				l11lll1111l1_l1_.append(line)
		for l1l111ll1111_l1_,name,type,l111lll_l1_,l111l1ll_l1_,l1ll1ll_l1_,server in l11lll1111l1_l1_:
			if l111l1ll_l1_: l111l1ll_l1_ = str(l111l1ll_l1_)
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠬ࠭䨟")
			title = l1l111_l1_ (u"࠭ำ๋ำไีࠬ䨠")+l1l111_l1_ (u"ࠧࠡࠩ䨡")+type+l1l111_l1_ (u"ࠨࠢࠪ䨢")+l1l111ll1111_l1_+l1l111_l1_ (u"ࠩࠣࠫ䨣")+l111l1ll_l1_+l1l111_l1_ (u"ࠪࠤࠬ䨤")+l111lll_l1_+l1l111_l1_ (u"ࠫࠥ࠭䨥")+name
			if server not in title: title = title+l1l111_l1_ (u"ࠬࠦࠧ䨦")+server
			title = title.replace(l1l111_l1_ (u"࠭ࠥࠨ䨧"),l1l111_l1_ (u"ࠧࠨ䨨")).strip(l1l111_l1_ (u"ࠨࠢࠪ䨩")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䨪"),l1l111_l1_ (u"ࠪࠤࠬ䨫")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䨬"),l1l111_l1_ (u"ࠬࠦࠧ䨭")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䨮"),l1l111_l1_ (u"ࠧࠡࠩ䨯"))
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		if l1llll_l1_:
			data = list(zip(l1l1lll1_l1_,l1llll_l1_))
			if data: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ䨰"),l1l1l11ll1l1_l1_,data,l1l1l11ll11_l1_)
	return l1l1lll1_l1_,l1llll_l1_
def l11lll1l11l1_l1_(url,source):
	l1111l1l1l1_l1_ = l1l111_l1_ (u"ࠩࠪ䨱")
	l1lll_l1_ = False
	try:
		import resolveurl
		l1lll_l1_ = resolveurl.resolve(url)
	except Exception as error: l1111l1l1l1_l1_ = str(error)
	if not l1lll_l1_:
		if l1111l1l1l1_l1_==l1l111_l1_ (u"ࠪࠫ䨲"):
			l1111l1l1l1_l1_ = traceback.format_exc()
			sys.stderr.write(l1111l1l1l1_l1_)
		l1l111l1l111_l1_ = l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠣࡊࡦ࡯࡬ࡦࡦࠪ䨳")
		l1l111l1l111_l1_ += l1l111_l1_ (u"ࠬࠦࠧ䨴")+l1111l1l1l1_l1_.splitlines()[-1]
		return l1l111l1l111_l1_,[],[]
	return l1l111_l1_ (u"࠭ࠧ䨵"),[l1l111_l1_ (u"ࠧࠨ䨶")],[l1lll_l1_]
def l11lll1l111l_l1_(url,source):
	l1111l1l1l1_l1_ = l1l111_l1_ (u"ࠨࠩ䨷")
	l1lll_l1_ = False
	try:
		import youtube_dl
		l1l11111l11l_l1_ = youtube_dl.YoutubeDL({l1l111_l1_ (u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫ䨸"): True})
		l1lll_l1_ = l1l11111l11l_l1_.extract_info(url,download=False)
	except Exception as error: l1111l1l1l1_l1_ = str(error)
	if not l1lll_l1_ or l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫ䨹") not in list(l1lll_l1_.keys()):
		if l1111l1l1l1_l1_==l1l111_l1_ (u"ࠫࠬ䨺"):
			l1111l1l1l1_l1_ = traceback.format_exc()
			sys.stderr.write(l1111l1l1l1_l1_)
		l1l111l1l111_l1_ = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠤࡋࡧࡩ࡭ࡧࡧࠫ䨻")
		l1l111l1l111_l1_ += l1l111_l1_ (u"࠭ࠠࠨ䨼")+l1111l1l1l1_l1_.splitlines()[-1]
		return l1l111l1l111_l1_,[],[]
	else:
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_ in l1lll_l1_[l1l111_l1_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ䨽")]:
			l1l1lll1_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࠨ䨾")])
			l1llll_l1_.append(l1ll1ll_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䨿")])
		return l1l111_l1_ (u"ࠪࠫ䩀"),l1l1lll1_l1_,l1llll_l1_
def l1l111111ll1_l1_(url):
	if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ䩁") in url:
		l1l1lll1_l1_,l1llll_l1_ = l1l11l1lll_l1_(url)
		if l1llll_l1_: return l1l111_l1_ (u"ࠬ࠭䩂"),l1l1lll1_l1_,l1llll_l1_
		return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡅࡗࡇࡂࠨ䩃"),[],[]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䩄"),[l1l111_l1_ (u"ࠨࠩ䩅")],[url]
def l1ll1111ll1_l1_(url):
	l1ll11l1_l1_,l111l11ll1_l1_ = [],[]
	if l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵ࠱ࡱࡵ࠺࠿ࡷ࡫ࡧࡁࠬ䩆") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䩇"),url,l1l111_l1_ (u"ࠫࠬ䩈"),l1l111_l1_ (u"ࠬ࠭䩉"),False,l1l111_l1_ (u"࠭ࠧ䩊"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡏࡆ࡚ࡋࡐࡗࡗࡉ࠲࠷ࡳࡵࠩ䩋"))
		if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䩌") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䩍")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠪࡲࡦࡳࡥࠨ䩎"))
			l111l11ll1_l1_.append(server)
	elif l1l111_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠴ࡣࡰ࡯ࠪ䩏") in url:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䩐"),url,l1l111_l1_ (u"࠭ࠧ䩑"),l1l111_l1_ (u"ࠧࠨ䩒"),l1l111_l1_ (u"ࠨࠩ䩓"),l1l111_l1_ (u"ࠩࠪ䩔"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮࠴ࡱࡨࠬ䩕"))
		html = response.content
		l1llllll11ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࡫ࡶࡢ࡮࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࡨࡡ࠯࠮ࠫࡁ࡟࠭ࡡ࠯ࠩ࠯࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ䩖"),html,re.DOTALL)
		if l1llllll11ll_l1_:
			l1llllll11ll_l1_ = l1llllll11ll_l1_[0]
			l1ll1l111l11_l1_ = l1ll1ll11l1l_l1_(l1llllll11ll_l1_)
			l1ll11ll1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪ࠮ࠪ䩗"),l1ll1l111l11_l1_,re.DOTALL)
			if l1ll11ll1ll1_l1_:
				l1ll11ll1ll1_l1_ = l1ll11ll1ll1_l1_[0]
				l1ll11ll1ll1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䩘"),l1ll11ll1ll1_l1_)
				for dict in l1ll11ll1ll1_l1_:
					l1ll1ll_l1_ = dict[l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩࠬ䩙")]
					l111l1ll_l1_ = dict[l1l111_l1_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ䩚")]
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䩛"))
					l111l11ll1_l1_.append(l111l1ll_l1_+l1l111_l1_ (u"ࠪࠤࠬ䩜")+server)
		elif l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䩝") in response.headers:
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䩞")]
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ䩟"))
			l111l11ll1_l1_.append(server)
		if l1l111_l1_ (u"ࠧࡀࡷࡵࡰࡂ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࡴࡵࠧ䩠") in url:
			l1ll1ll_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡸࡶࡱࡃࠧ䩡"))[1]
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩࠫ䩢"))[0]
			if l1ll1ll_l1_:
				l1ll11l1_l1_.append(l1ll1ll_l1_)
				l111l11ll1_l1_.append(l1l111_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵࠣ࡫ࡴࡵࡧ࡭ࡧࠪ䩣"))
	else:
		l1ll11l1_l1_.append(url)
		server = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䩤"))
		l111l11ll1_l1_.append(server)
	if not l1ll11l1_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ䩥"),[],[]
	elif len(l1ll11l1_l1_)==1: l1ll1ll_l1_ = l1ll11l1_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ䩦"),l111l11ll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠧࡆ࡚ࡌࡘࠬ䩧"),[],[]
		l1ll1ll_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䩨"),[l1l111_l1_ (u"ࠩࠪ䩩")],[l1ll1ll_l1_]
def l11ll1l1lll1_l1_(url):
	headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䩪"):l1l111_l1_ (u"ࠫࡐࡵࡤࡪ࠱ࠪ䩫")+str(kodi_version)}
	for l1l11l111l_l1_ in range(50):
		time.sleep(0.100)
		response = l1111l1ll1l_l1_(l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䩬"),url,l1l111_l1_ (u"࠭ࠧ䩭"),headers,False,l1l111_l1_ (u"ࠧࠨ䩮"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ䩯"))
		if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䩰") in list(response.headers.keys()):
			l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䩱")]
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ䩲")+headers[l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䩳")]
			return l1l111_l1_ (u"࠭ࠧ䩴"),[l1l111_l1_ (u"ࠧࠨ䩵")],[l1ll1ll_l1_]
		if response.code!=429: break
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚ࠧ䩶"),[],[]
def l11lllll11l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䩷"),url,l1l111_l1_ (u"ࠪࠫ䩸"),l1l111_l1_ (u"ࠫࠬ䩹"),l1l111_l1_ (u"ࠬ࠭䩺"),l1l111_l1_ (u"࠭ࠧ䩻"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡔࡍࡕࡔࡐࡕࡊࡓࡔࡍࡌࡆ࠯࠴ࡷࡹ࠭䩼"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࠪࡀࠫࠥ࠰࠳࠰࠿࠭࠰࠭ࡃ࠱࠮࠮ࠫࡁࠬ࠰ࠬ䩽"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_,l111l1ll_l1_ = l1ll1ll_l1_[0]
		return l1l111_l1_ (u"ࠩࠪ䩾"),[l111l1ll_l1_],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈࠫ䩿"),[],[]
def l1lll1l1l1l_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䪀"),url,l1l111_l1_ (u"ࠬ࠭䪁"),l1l111_l1_ (u"࠭ࠧ䪂"),l1l111_l1_ (u"ࠧࠨ䪃"),l1l111_l1_ (u"ࠨࠩ䪄"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡔࡇࡏࡌࡉ࠷࠭࠲ࡵࡷࠫ䪅"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䪆"),html,re.DOTALL)
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࠬ䪇"),[l1l111_l1_ (u"ࠬ࠭䪈")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ䪉"),[],[]
def l11l111ll_l1_(url):
	if l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫ䪊") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䪋"),url,l1l111_l1_ (u"ࠩࠪ䪌"),l1l111_l1_ (u"ࠪࠫ䪍"),l1l111_l1_ (u"ࠫࠬ䪎"),l1l111_l1_ (u"ࠬ࠭䪏"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇ࠴ࡖ࠯࠴ࡷࡹ࠭䪐"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䪑"),html,re.DOTALL)
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䪒") in l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䪓"),[l1l111_l1_ (u"ࠪࠫ䪔")],[l1ll1ll_l1_]
		return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡃࡊࡏࡄ࠸࡚࠭䪕"),[],[]
	else: return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䪖"),[l1l111_l1_ (u"࠭ࠧ䪗")],[url]
def l11111ll1l_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䪘"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䪙"),l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䪚"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䪛")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䪜"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䪝"),l1l111_l1_ (u"࠭ࠧ䪞"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡎࡐ࡙࠰࠵ࡸࡺࠧ䪟"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䪠"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡏࡑ࡚ࠫ䪡"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪢"),[l1l111_l1_ (u"ࠫࠬ䪣")],[l1ll1ll_l1_]
def l1ll1111l111_l1_(url):
	headers = {l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ䪤"):l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ䪥")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䪦"),url,l1l111_l1_ (u"ࠨࠩ䪧"),headers,l1l111_l1_ (u"ࠩࠪ䪨"),l1l111_l1_ (u"ࠪࠫ䪩"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡒࡓࡋࡖࡒࡐ࠯࠴ࡷࡹ࠭䪪"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䪫"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡓࡔࡌࡐࡓࡑࠪ䪬"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䪭"),[l1l111_l1_ (u"ࠨࠩ䪮")],[l1ll1ll_l1_]
def l1ll1l111ll_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ䪯"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ䪰")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䪱"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䪲"),l1l111_l1_ (u"࠭ࠧ䪳"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡌࡆࡒࡁࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ䪴"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ䪵"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡍࡇࡌࡂࡅࡌࡑࡆ࠭䪶"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䪷") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䪸")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䪹"),[l1l111_l1_ (u"࠭ࠧ䪺")],[l1ll1ll_l1_]
def l111l1l11_l1_(url):
	l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䪻"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䪼")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䪽"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䪾"),l1l111_l1_ (u"ࠫࠬ䪿"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧ䫀"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ䫁"),html,re.DOTALL|re.IGNORECASE)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡁࡃࡆࡒࠫ䫂"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䫃"),[l1l111_l1_ (u"ࠩࠪ䫄")],[l1ll1ll_l1_]
def l1111111l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䫅"),url,l1l111_l1_ (u"ࠫࠬ䫆"),l1l111_l1_ (u"ࠬ࠭䫇"),l1l111_l1_ (u"࠭ࠧ䫈"),l1l111_l1_ (u"ࠧࠨ䫉"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡙࡜ࡆࡖࡐ࠰࠵ࡸࡺࠧ䫊"))
	html = response.content
	l11ll1l11ll1_l1_ = re.findall(l1l111_l1_ (u"ࠤࡹࡥࡷࠦࡦࡴࡧࡵࡺࠥࡃ࠮ࠫࡁࠪࠬ࠳࠰࠿ࠪࠩࠥ䫋"),html,re.DOTALL|re.IGNORECASE)
	if l11ll1l11ll1_l1_:
		l11ll1l11ll1_l1_ = l11ll1l11ll1_l1_[0][2:]
		l11ll1l11ll1_l1_ = base64.b64decode(l11ll1l11ll1_l1_)
		if kodi_version>18.99: l11ll1l11ll1_l1_ = l11ll1l11ll1_l1_.decode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䫌"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䫍"),l11ll1l11ll1_l1_,re.DOTALL)
	else: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࠭䫎")
	if not l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡖ࡙ࡊ࡚ࡔࠧ䫏"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䫐") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ䫑")+l1ll1ll_l1_
	return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䫒"),[l1l111_l1_ (u"ࠪࠫ䫓")],[l1ll1ll_l1_]
def l1l111l11lll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䫔"),url,l1l111_l1_ (u"ࠬ࠭䫕"),l1l111_l1_ (u"࠭ࠧ䫖"),l1l111_l1_ (u"ࠧࠨ䫗"),l1l111_l1_ (u"ࠨࠩ䫘"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡆࡉ࡜࡚ࡎࡖ࠭࠲ࡵࡷࠫ䫙"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠵࠷ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䫚"),html,re.DOTALL)
	if not l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡇࡊ࡝࡛ࡏࡐࠨ䫛"),[],[]
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䫜"),[l1l111_l1_ (u"࠭ࠧ䫝")],[l1ll1ll_l1_]
def l1l1l11ll1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䫞"))[-1]
	if l1l111_l1_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ䫟") in url: url = url.replace(l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥࠩ䫠"),l1l111_l1_ (u"ࠪࠫ䫡"))
	url = url.replace(l1l111_l1_ (u"ࠫ࠳ࡩ࡯࡮࠱ࠪ䫢"),l1l111_l1_ (u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭䫣"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䫤"),url,l1l111_l1_ (u"ࠧࠨ䫥"),l1l111_l1_ (u"ࠨࠩ䫦"),l1l111_l1_ (u"ࠩࠪ䫧"),l1l111_l1_ (u"ࠪࠫ䫨"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ䫩"))
	html = response.content
	l1l111l1l111_l1_ = l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ䫪")
	error = re.findall(l1l111_l1_ (u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫫"),html,re.DOTALL)
	if error: l1l111l1l111_l1_ = error[0]
	url = re.findall(l1l111_l1_ (u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䫬"),html,re.DOTALL)
	if not url and l1l111l1l111_l1_:
		return l1l111l1l111_l1_,[],[]
	l1ll1ll_l1_ = url[0].replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ䫭"),l1l111_l1_ (u"ࠩࠪ䫮"))
	l1l1l11l1l11_l1_,l1l1l11ll1l1_l1_ = l1l11l1lll_l1_(l1ll1ll_l1_)
	owner = re.findall(l1l111_l1_ (u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࢀࠨࡩࡥࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡹࡣࡳࡧࡨࡲࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䫯"),html,re.DOTALL)
	if owner: l1l11111l1l1_l1_,l1l11111l111_l1_,l1l111lll11l_l1_ = owner[0]
	else: l1l11111l1l1_l1_,l1l11111l111_l1_,l1l111lll11l_l1_ = l1l111_l1_ (u"ࠫࠬ䫰"),l1l111_l1_ (u"ࠬ࠭䫱"),l1l111_l1_ (u"࠭ࠧ䫲")
	l1l111lll11l_l1_ = l1l111lll11l_l1_.replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ䫳"),l1l111_l1_ (u"ࠨ࠱ࠪ䫴"))
	l1l11111l111_l1_ = escapeUNICODE(l1l11111l111_l1_)
	l1l1lll1_l1_ = [l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭䫵")+l1l11111l111_l1_+l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䫶")]+l1l1l11l1l11_l1_
	l1llll_l1_ = [l1l111lll11l_l1_]+l1l1l11ll1l1_l1_
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬ䫷")+str(len(l1llll_l1_)-1)+l1l111_l1_ (u"ࠬࠦๅๅใࠬࠫ䫸"),l1l1lll1_l1_)
	if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ䫹"),[],[]
	elif l11l11l_l1_==0:
		new_path = sys.argv[0]+l1l111_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠹࠶࠲ࠧࡷࡵࡰࡂ࠭䫺")+l1l111lll11l_l1_+l1l111_l1_ (u"ࠨࠨࡷࡩࡽࡺ࠽ࠨ䫻")+l1l11111l111_l1_
		xbmc.executebuiltin(l1l111_l1_ (u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ䫼")+new_path+l1l111_l1_ (u"ࠥ࠭ࠧ䫽"))
		return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䫾"),[],[]
	l1ll1ll_l1_ =  l1llll_l1_[l11l11l_l1_]
	return l1l111_l1_ (u"ࠬ࠭䫿"),[l1l111_l1_ (u"࠭ࠧ䬀")],[l1ll1ll_l1_]
def l11l1ll1l_l1_(l1ll1ll_l1_):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䬁"),l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䬂"),l1l111_l1_ (u"ࠩࠪ䬃"),l1l111_l1_ (u"ࠪࠫ䬄"),l1l111_l1_ (u"ࠫࠬ䬅"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄࡒࡏࡗࡇ࠭࠲ࡵࡷࠫ䬆"))
	html = response.content
	if l1l111_l1_ (u"࠭࠮࡫ࡵࡲࡲࠬ䬇") in l1ll1ll_l1_: url = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䬈"),html,re.DOTALL)
	else: url = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䬉"),html,re.DOTALL)
	if not url: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇࡕࡋࡓࡃࠪ䬊"),[],[]
	url = url[0]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䬋") not in url: url = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䬌")+url
	return l1l111_l1_ (u"ࠬ࠭䬍"),[l1l111_l1_ (u"࠭ࠧ䬎")],[url]
def l11lll111l11_l1_(url):
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䬏") : l1l111_l1_ (u"ࠨࠩ䬐") }
	if l1l111_l1_ (u"ࠩࡲࡴࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ䬑") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ䬒"),headers,l1l111_l1_ (u"ࠫࠬ䬓"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠵ࡸࡺࠧ䬔"))
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䬕"),html,re.DOTALL)
		if items: return l1l111_l1_ (u"ࠧࠨ䬖"),[l1l111_l1_ (u"ࠨࠩ䬗")],[items[0]]
		else:
			message = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡶࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䬘"),html,re.DOTALL)
			if message:
				l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ䬙"),l1l111_l1_ (u"ࠫࠬ䬚"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧ䬛"),message[0])
				return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧ䬜")+message[0],[],[]
	else:
		l1llll1l1l1_l1_ = l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠪ䬝")
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠨࠩ䬞"),headers,l1l111_l1_ (u"ࠩࠪ䬟"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬ䬠"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭䬡"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ䬢"),[],[]
		l111lllll_l1_ = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		if l1l111_l1_ (u"࠭࠮ࡳࡣࡵࠫ䬣") in block or l1l111_l1_ (u"ࠧ࠯ࡼ࡬ࡴࠬ䬤") in block: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭䬥"),[],[]
		items = re.findall(l1l111_l1_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䬦"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lllll11_l1_(payload)
		html = l1l1llll_l1_(l111l11l_l1_,l111lllll_l1_,data,headers,l1l111_l1_ (u"ࠪࠫ䬧"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭䬨"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪ䬩"),html,re.DOTALL)
		if not l11llll_l1_: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ䬪"),[],[]
		download = l11llll_l1_[0][0]
		block = l11llll_l1_[0][1]
		items = re.findall(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧ䬫"),block,re.DOTALL)
		l1l111l11l11_l1_,l1l1lll1_l1_,l11lll1llll1_l1_,l1llll_l1_,l11lll1ll1l1_l1_ = [],[],[],[],[]
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ䬬") in l1ll1ll_l1_:
				l1l111l11l11_l1_,l11lll1llll1_l1_ = l1l11l1lll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11lll1llll1_l1_
				if l1l111l11l11_l1_[0]==l1l111_l1_ (u"ࠩ࠰࠵ࠬ䬭"): l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ䬮")+l1l111_l1_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ䬯")+l1llll1l1l1_l1_)
				else:
					for title in l1l111l11l11_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ䬰")+l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠬ䬱")+l1llll1l1l1_l1_+l1l111_l1_ (u"ࠧࠡࠩ䬲")+title)
			else:
				title = title.replace(l1l111_l1_ (u"ࠨ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠪ䬳"),l1l111_l1_ (u"ࠩࠪ䬴"))
				title = title.strip(l1l111_l1_ (u"ࠪࠦࠬ䬵"))
				title = l1l111_l1_ (u"ู๊ࠫࠥาใิࠤࠥิวึࠢࠪ䬶")+l1l111_l1_ (u"ࠬࠦ࡭ࡱ࠶ࠣࠫ䬷")+l1llll1l1l1_l1_+l1l111_l1_ (u"࠭ࠠࠨ䬸")+title
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦࠩ䬹") + download
		html = l1l1llll_l1_(l111l11l_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠨࠩ䬺"),headers,l1l111_l1_ (u"ࠩࠪ䬻"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠷ࡷ࡬ࠬ䬼"))
		items = re.findall(l1l111_l1_ (u"ࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡥࡶࡪࡦࡨࡳࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯ࠬࠣ䬽"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l1l111_l1_ (u"ࠬࠦำ๋ำไีࠥะอๆ์็ࠤำอีࠡࠩ䬾")+l1l111_l1_ (u"࠭ࠠ࡮ࡲ࠷ࠤࠬ䬿")+l1llll1l1l1_l1_+l1l111_l1_ (u"ࠧࠡࠩ䭀")+resolution.split(l1l111_l1_ (u"ࠨࡺࠪ䭁"))[1]
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ䭂")+id+l1l111_l1_ (u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ䭃")+mode+l1l111_l1_ (u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ䭄")+hash
			l11lll1ll1l1_l1_.append(resolution)
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		l11lll1ll1l1_l1_ = set(l11lll1ll1l1_l1_)
		l11lllll1l11_l1_,l1l111llllll_l1_ = [],[]
		for title in l1l1lll1_l1_:
			res = re.findall(l1l111_l1_ (u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧ䭅"),title+l1l111_l1_ (u"࠭ࠦࠧࠩ䭆"),re.DOTALL)
			for resolution in l11lll1ll1l1_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l1l111_l1_ (u"ࠧࡹࠩ䭇"))[1])
			l11lllll1l11_l1_.append(title)
		for i in range(len(l1llll_l1_)):
			items = re.findall(l1l111_l1_ (u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤ䭈"),l1l111_l1_ (u"ࠩࠩࠪࠬ䭉")+l11lllll1l11_l1_[i]+l1l111_l1_ (u"ࠪࠪࠫ࠭䭊"),re.DOTALL)
			l1l111llllll_l1_.append( [l11lllll1l11_l1_[i],l1llll_l1_[i],items[0][0],items[0][1]] )
		l1l111llllll_l1_ = sorted(l1l111llllll_l1_, key=lambda x: x[3], reverse=True)
		l1l111llllll_l1_ = sorted(l1l111llllll_l1_, key=lambda x: x[2], reverse=False)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for i in range(len(l1l111llllll_l1_)):
			l1l1lll1_l1_.append(l1l111llllll_l1_[i][0])
			l1llll_l1_.append(l1l111llllll_l1_[i][1])
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ䭋"),[],[]
	return l1l111_l1_ (u"ࠬ࠭䭌"),l1l1lll1_l1_,l1llll_l1_
def l11ll11lll11_l1_(url):
	parts = url.split(l1l111_l1_ (u"࠭࠿ࠨ䭍"))
	l1lllll1_l1_ = parts[0]
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䭎") : l1l111_l1_ (u"ࠨࠩ䭏") }
	html = l1l1llll_l1_(l111l11l_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䭐"),headers,l1l111_l1_ (u"ࠪࠫ䭑"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆ࠷ࡗࡗࡆࡘ࠭࠲ࡵࡷࠫ䭒"))
	items = re.findall(l1l111_l1_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥࡽࡡࡪࡶ࠱࠮ࡄ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭䭓"),html,re.DOTALL)
	url = items[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䭔"),[l1l111_l1_ (u"ࠧࠨ䭕")],[url]
def l1l111111lll_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䭖") : l1l111_l1_ (u"ࠩࠪ䭗") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠪࠫ䭘"),headers,l1l111_l1_ (u"ࠫࠬ䭙"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫ䭚"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡷࡵࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䭛"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠧࠨ䭜"),[l1l111_l1_ (u"ࠨࠩ䭝")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡇ࡛࡚࡛ࡘࡕࡐࠬ䭞"),[],[]
def l11ll1l111l1_l1_(url):
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䭟") : l1l111_l1_ (u"ࠫࠬ䭠") }
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠬ࠭䭡"),headers,l1l111_l1_ (u"࠭ࠧ䭢"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭䭣"))
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࠨࠬࠣࠪ࡫ࡸࡹ࠴ࠪࡀࠫࠥࠫ䭤"),html,re.DOTALL)
	if l1lllll1_l1_: return l1l111_l1_ (u"ࠩࠪ䭥"),[l1l111_l1_ (u"ࠪࠫ䭦")],[l1lllll1_l1_[0]]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗࠬ䭧"),[],[]
def l1lll1ll11l_l1_(url):
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠬ࠭䭨")
	if l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡥࡩࡳࡩ࡯࠱ࠪ䭩") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䭪"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ䭫")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䭬"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠪࠫ䭭"),l1l111_l1_ (u"ࠫࠬ䭮"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠷ࡴࡤࠨ䭯"))
		l11l1ll1_l1_ = response.content
		if l11l1ll1_l1_.startswith(l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ䭰")): l1lllll1_l1_ = l11l1ll1_l1_
		else:
			l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠨࠩࡶࡶࡨࡃ࡛ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝ࠪࠦࡢ࠭ࠧࠨ䭱"),l11l1ll1_l1_,re.DOTALL)
			if l1llllll_l1_:
				l1lllll1_l1_ = l1llllll_l1_[0]
				l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䭲"),l1lllll1_l1_,re.DOTALL)
				if l1llllll_l1_:
					l1lllll1_l1_ = l111l11_l1_(l1llllll_l1_[0])
					return l1l111_l1_ (u"ࠩࠪ䭳"),[l1l111_l1_ (u"ࠪࠫ䭴")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠫ࠴ࡲࡩ࡯࡭ࡶ࠳ࠬ䭵") in url:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䭶"),url,l1l111_l1_ (u"࠭ࠧ䭷"),l1l111_l1_ (u"ࠧࠨ䭸"),True,l1l111_l1_ (u"ࠨࠩ䭹"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠳ࡶࡸࠬ䭺"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䭻") in list(response.headers.keys()): l1lllll1_l1_ = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䭼")]
		else: l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤ࡯࡭ࡳࡱࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䭽"),l11l1ll1_l1_,re.DOTALL)[0]
	if l1l111_l1_ (u"࠭࠯ࡷ࠱ࠪ䭾") in l1lllll1_l1_ or l1l111_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䭿") in l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡩ࠳ࠬ䮀"),l1l111_l1_ (u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ䮁"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠳ࡻ࠵ࠧ䮂"),l1l111_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ䮃"))
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ䮄"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ䮅"),l1l111_l1_ (u"ࠧࠨ䮆"),l1l111_l1_ (u"ࠨࠩ䮇"),l1l111_l1_ (u"ࠩࠪ䮈"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠶ࡶࡩ࠭䮉"))
		l11l1ll1_l1_ = response.content
		items = re.findall(l1l111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨ࡬ࡢࡤࡨࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䮊"),l11l1ll1_l1_,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ䮋"),l1l111_l1_ (u"࠭ࠧ䮌"))
				l1l1lll1_l1_.append(title)
				l1llll_l1_.append(l1ll1ll_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䮍"),l11l1ll1_l1_,re.DOTALL)
			if items:
				l1ll1ll_l1_ = items[0]
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ䮎"),l1l111_l1_ (u"ࠩࠪ䮏"))
				l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࠫ䮐"))
				l1llll_l1_.append(l1ll1ll_l1_)
	else: return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䮑"),[l1l111_l1_ (u"ࠬ࠭䮒")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ䮓"),[],[]
	return l1l111_l1_ (u"ࠧࠨ䮔"),l1l1lll1_l1_,l1llll_l1_
def l1ll1l1l11ll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䮕"),url,l1l111_l1_ (u"ࠩࠪ䮖"),l1l111_l1_ (u"ࠪࠫ䮗"),l1l111_l1_ (u"ࠫࠬ䮘"),l1l111_l1_ (u"ࠬ࠭䮙"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭䮚"))
	html = response.content
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠧࠨ䮛")
	if l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫ䮜") in url or l1l111_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ䮝") in url:
		if l1l111_l1_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭䮞") in url:
			l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䮟"),html,re.DOTALL)
			l1lllll1_l1_ = l1lllll1_l1_[0]
		else: l1lllll1_l1_ = url
		if l1l111_l1_ (u"ࠬࡳ࡯ࡷࡵ࠷ࡹࠬ䮠") not in l1lllll1_l1_: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䮡"),[l1l111_l1_ (u"ࠧࠨ䮢")],[l1lllll1_l1_]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䮣"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䮤"),l1l111_l1_ (u"ࠪࠫ䮥"),l1l111_l1_ (u"ࠫࠬ䮦"),l1l111_l1_ (u"ࠬ࠭䮧"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭䮨"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪ䮩"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䮪"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1lll1l1ll11_l1_ in items:
				l1l1lll1_l1_.append(l1lll1l1ll11_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
	elif l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫ䮫") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧ䮬"),html,re.DOTALL)
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䮭"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䮮"),l1l111_l1_ (u"࠭ࠧ䮯"),l1l111_l1_ (u"ࠧࠨ䮰"),l1l111_l1_ (u"ࠨࠩ䮱"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡗࡕ࠷࡙࠲࠹ࡲࡥࠩ䮲"))
		html = response.content
		l1llllll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡫࡯࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䮳"),html,re.DOTALL)
		l1llllll_l1_ = l1llllll_l1_[0]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࠬ䮴"))
		l1llll_l1_.append(l1llllll_l1_)
	elif l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟࡭࡫ࡱ࡯ࠬ䮵") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡤࡧࡱࡸࡪࡸ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䮶"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䮷"),[l1l111_l1_ (u"ࠨࠩ䮸")],[l1lllll1_l1_]
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡖࡔ࠶ࡘࠫ䮹"),[],[]
	return l1l111_l1_ (u"ࠪࠫ䮺"),l1l1lll1_l1_,l1llll_l1_
def l1111llll_l1_(url):
	l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭䮻")][0]
	headers = {l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䮼"):l1l11l11_l1_}
	if l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࠪ䮽") in url:
		l1ll1ll1l_l1_ = headers.copy()
		l1ll1ll1l_l1_[l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䮾")] = l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䮿")
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䯀"),url,l1l111_l1_ (u"ࠪࠫ䯁"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ䯂"),l1l111_l1_ (u"ࠬ࠭䯃"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡃࡍࡗࡅ࠱࠶ࡹࡴࠨ䯄"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠧࠫ䯅"),html,re.DOTALL)
		if l1ll1ll_l1_: url = l1ll1ll_l1_[0]
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䯆"),url,l1l111_l1_ (u"ࠩࠪ䯇"),headers,l1l111_l1_ (u"ࠪࠫ䯈"),l1l111_l1_ (u"ࠫࠬ䯉"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡄ࠰࠶ࡳࡪࠧ䯊"))
	html = response.content
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䯋"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䯌"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠣࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ䯍"),html,re.DOTALL)
	if l1ll1ll_l1_:
		url = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䯎")+l1l11l11_l1_
		return l1l111_l1_ (u"ࠪࠫ䯏"),[l1l111_l1_ (u"ࠫࠬ䯐")],[url]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡬ࡩ࡭ࡧ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦ䯑"),html,re.DOTALL)
	if l1ll1ll_l1_: url = server+l1ll1ll_l1_[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䯒"),[l1l111_l1_ (u"ࠧࠨ䯓")],[url]
def l111l11lll_l1_(url):
	l111l11ll1_l1_,l1ll11l1_l1_ = [],[]
	if l1l111_l1_ (u"ࠨ࠱࠴࠳ࠬ䯔") in url:
		l1ll1ll_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲࠵࠴࠭䯕"),l1l111_l1_ (u"ࠪ࠳࠹࠵ࠧ䯖"))
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䯗"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䯘"),l1l111_l1_ (u"࠭ࠧ䯙"),False,l1l111_l1_ (u"ࠧࠨ䯚"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠱ࡴࡶࠪ䯛"))
		l11l1ll1_l1_ = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡺ࡮ࡪࡥࡰࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡨࡪࡵ࠾ࠨ䯜"),l11l1ll1_l1_,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䯝"),block,re.DOTALL)
			for l1ll1ll_l1_,l111l1ll_l1_ in items:
				if l1ll1ll_l1_ not in l1ll11l1_l1_:
					l1ll11l1_l1_.append(l1ll1ll_l1_)
					server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ䯞"))
					l111l11ll1_l1_.append(server+l1l111_l1_ (u"ࠬࠦࠠࠨ䯟")+l111l1ll_l1_)
			return l1l111_l1_ (u"࠭ࠧ䯠"),l111l11ll1_l1_,l1ll11l1_l1_
	elif l1l111_l1_ (u"ࠧ࠰ࡦ࠲ࠫ䯡") in url:
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䯢"),url,l1l111_l1_ (u"ࠩࠪ䯣"),l1l111_l1_ (u"ࠪࠫ䯤"),l1l111_l1_ (u"ࠫࠬ䯥"),l1l111_l1_ (u"ࠬ࠭䯦"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠷ࡴࡤࠨ䯧"))
		l11l1ll1_l1_ = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯨"),l11l1ll1_l1_,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠨ࠱࠴࠳ࠬ䯩"),l1l111_l1_ (u"ࠩ࠲࠸࠴࠭䯪"))
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䯫"),l1ll1ll_l1_,l1l111_l1_ (u"ࠫࠬ䯬"),l1l111_l1_ (u"ࠬ࠭䯭"),False,l1l111_l1_ (u"࠭ࠧ䯮"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠹ࡲࡥࠩ䯯"))
			l11l1ll1_l1_ = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䯰"),l11l1ll1_l1_,re.DOTALL)
			if l1ll1ll_l1_: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䯱"),[l1l111_l1_ (u"ࠪࠫ䯲")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨ䯳"),[],[]
def l1111lll1l_l1_(url):
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䯴"),url,l1l111_l1_ (u"࠭ࠧ䯵"),l1l111_l1_ (u"ࠧࠨ䯶"),l1l111_l1_ (u"ࠨࠩ䯷"),l1l111_l1_ (u"ࠩࠪ䯸"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠳࠮࠳ࡶࡸࠬ䯹"))
	html = response.content
	data = re.findall(l1l111_l1_ (u"ࠫࠧࡧࡣࡵ࡫ࡲࡲࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䯺"),html,re.DOTALL)
	if data:
		op,id,fname = data[0]
		data = l1l111_l1_ (u"ࠬࡵࡰ࠾ࠩ䯻")+op+l1l111_l1_ (u"࠭ࠦࡪࡦࡀࠫ䯼")+id+l1l111_l1_ (u"ࠧࠧࡨࡱࡥࡲ࡫࠽ࠨ䯽")+fname
		headers = {l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䯾"):l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ䯿")}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䰀"),url,data,headers,l1l111_l1_ (u"ࠫࠬ䰁"),l1l111_l1_ (u"ࠬ࠭䰂"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠷ࡴࡤࠨ䰃"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡨࡪࡪࡸࡥࡳࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䰄"),html,re.DOTALL)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䰅"),[l1l111_l1_ (u"ࠩࠪ䰆")],[l1ll1ll_l1_[0]]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ䰇"),[],[]
def l111ll1ll1_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䰈"),1)[0].strip(l1l111_l1_ (u"ࠬࡅࠧ䰉")).strip(l1l111_l1_ (u"࠭࠯ࠨ䰊")).strip(l1l111_l1_ (u"ࠧࠧࠩ䰋"))
	l1l1lll1_l1_,l1llll_l1_,items,l1llllll_l1_ = [],[],[],l1l111_l1_ (u"ࠨࠩ䰌")
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䰍"):l1l111_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠪ䰎") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䰏"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䰐"),headers,True,l1l111_l1_ (u"࠭ࠧ䰑"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠱࠶ࡹࡴࠨ䰒"))
	if l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䰓") in list(response.headers.keys()): l1llllll_l1_ = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䰔")]
	if l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䰕") in l1llllll_l1_:
		if l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䰖") in url: l1llllll_l1_ = l1llllll_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡦ࠰ࠩ䰗"),l1l111_l1_ (u"࠭࠯ࡷ࠱ࠪ䰘"))
		l11llllll111_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠧࡀࡒࡋࡔࡘࡏࡄ࠾ࠩ䰙"))[1]
		headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䰚"):headers[l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䰛")] , l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䰜"):l1l111_l1_ (u"ࠫࡕࡎࡐࡔࡋࡇࡁࠬ䰝")+l11llllll111_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䰞"),l1llllll_l1_,l1l111_l1_ (u"࠭ࠧ䰟"),headers,False,l1l111_l1_ (u"ࠧࠨ䰠"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ䰡"))
		html = response.content
		if l1l111_l1_ (u"ࠩ࠲ࡪ࠴࠭䰢") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠪࡀ࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰣"),html,re.DOTALL)
		elif l1l111_l1_ (u"ࠫ࠴ࡼ࠯ࠨ䰤") in l1llllll_l1_: items = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䰥"),html,re.DOTALL)
		if items: return [],[l1l111_l1_ (u"࠭ࠧ䰦")],[ items[0] ]
		elif l1l111_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭䰧") in html:
			return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫ䰨"),[],[]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬ䰩"),[],[]
def l111ll1ll11_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ䰪"),l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䰫"),re.DOTALL|re.IGNORECASE)
	l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	url = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭䰬")+l11l1l11_l1_+l1l111_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䰭")+l11l1lll_l1_
	headers = { l1l111_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䰮"):l1l111_l1_ (u"ࠨࠩ䰯") , l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䰰"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䰱") }
	l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䰲"),headers,l1l111_l1_ (u"ࠬ࠭䰳"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮࠳ࡶࡸࠬ䰴"))
	return l1l111_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䰵"),[l1l111_l1_ (u"ࠨࠩ䰶")],[l1lllll1_l1_]
def l1lll11l111l_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䰷"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䰸"):server,l1l111_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭䰹"):l1l111_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ䰺")}
	response = l11l1l_l1_(l1lll111l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䰻"),url,l1l111_l1_ (u"ࠧࠨ䰼"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ䰽"),l1l111_l1_ (u"ࠩࠪ䰾"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ䰿"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ䱀"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࠭䱁")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䱂"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ䱃"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠨࠩ䱄"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䱅"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡄࡋࡐࡅࠬ䱆"),[],[]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䱇"),[l1l111_l1_ (u"ࠬ࠭䱈")],[l1lllll1_l1_]
def l1ll11l1llll_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䱉"))
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ䱊"):server,l1l111_l1_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ䱋"):l1l111_l1_ (u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ䱌")}
	response = l11l1l_l1_(l1lll111l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䱍"),url,l1l111_l1_ (u"ࠫࠬ䱎"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠬ࠭䱏"),l1l111_l1_ (u"࠭ࠧ䱐"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠰࠵ࡸࡺࠧ䱑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠯ࡳࡸࡥࡱ࡯ࡴࡺࡵࡨࡰࡪࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡧࡱࡵࡱࡦࡺࡳ࠻ࠩ䱒"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠩࠪ䱓")
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶ࠽ࠤࡡ࠭ࠨ࡝ࡦ࠱࠮ࡄ࠯࡜ࠨ࠮ࠣࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䱔"),block,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for title,l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		if len(l1llll_l1_)==1: l1lllll1_l1_ = l1llll_l1_[0]
		elif len(l1llll_l1_)>1:
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫศิสาࠢส่๊๊แࠡษ็้๋อำษࠩ䱕"), l1l1lll1_l1_)
			if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠬ࠭䱖"),[],[]
			l1lllll1_l1_ = l1llll_l1_[l11l11l_l1_]
	if not l1lllll1_l1_:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䱗"),html,re.DOTALL)
		if l11llll_l1_: l1lllll1_l1_ = l11llll_l1_[0]
	if not l1lllll1_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩ䱘"),[],[]
	return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䱙"),[l1l111_l1_ (u"ࠩࠪ䱚")],[l1lllll1_l1_]
def l1l1111l_l1_(l1ll1ll_l1_):
	parts = re.findall(l1l111_l1_ (u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䱛"),l1ll1ll_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䱜"),re.DOTALL)
	url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
	data = {l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭䱝"):l11l1l11_l1_,l1l111_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭䱞"):l11l1lll_l1_}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䱟"),url,data,l1l111_l1_ (u"ࠨࠩ䱠"),l1l111_l1_ (u"ࠩࠪ䱡"),l1l111_l1_ (u"ࠪࠫ䱢"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒࡉࡁࡎ࠯࠴ࡷࡹ࠭䱣"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱤"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䱥"),[l1l111_l1_ (u"ࠧࠨ䱦")],[l1lllll1_l1_]
def l11111l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䱧"),url,l1l111_l1_ (u"ࠩࠪ䱨"),l1l111_l1_ (u"ࠪࠫ䱩"),l1l111_l1_ (u"ࠫࠬ䱪"),l1l111_l1_ (u"ࠬ࠭䱫"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲࠷ࡳࡵࠩ䱬"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䱭"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䱮"),[l1l111_l1_ (u"ࠩࠪ䱯")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ䱰"),[],[]
def l1111l1l1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䱱"),url,l1l111_l1_ (u"ࠬ࠭䱲"),l1l111_l1_ (u"࠭ࠧ䱳"),l1l111_l1_ (u"ࠧࠨ䱴"),l1l111_l1_ (u"ࠨࠩ䱵"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫ䱶"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䱷"),html,re.DOTALL)[0]
	return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䱸"),[l1l111_l1_ (u"ࠬ࠭䱹")],[l1ll1ll_l1_]
def l111111l1_l1_(url):
	l11l11111_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䱺"))
	if l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ䱻") in url:
		headers = {l1l111_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䱼"):l11l11111_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䱽"),url,l1l111_l1_ (u"ࠪࠫ䱾"),headers,l1l111_l1_ (u"ࠫࠬ䱿"),l1l111_l1_ (u"ࠬ࠭䲀"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ䲁"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䲂"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			if l1l111_l1_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ䲃") in l1lllll1_l1_:
				l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ䲄"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ䲅"))
				response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䲆"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭䲇"),headers,l1l111_l1_ (u"࠭ࠧ䲈"),l1l111_l1_ (u"ࠧࠨ䲉"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠸࡮ࡥࠩ䲊"))
				l11l1ll1_l1_ = response.content
				items = re.findall(l1l111_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䲋"),l11l1ll1_l1_,re.DOTALL)
				l1l1lll1_l1_,l1llll_l1_ = [],[]
				l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䲌"))
				for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
					l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ䲍")+l111lll1l_l1_
					l1l1lll1_l1_.append(l111l1ll_l1_)
					l1llll_l1_.append(l1ll1ll_l1_)
				return l1l111_l1_ (u"ࠬ࠭䲎"),l1l1lll1_l1_,l1llll_l1_
			else: return l1l111_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䲏"),[l1l111_l1_ (u"ࠧࠨ䲐")],[l1lllll1_l1_]
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䲑")+l11l11111_l1_
	return l1l111_l1_ (u"ࠩࠪ䲒"),[l1l111_l1_ (u"ࠪࠫ䲓")],[l1lllll1_l1_]
def l11llll1ll1l_l1_(l1ll1ll_l1_):
	l11l11111_l1_ = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ䲔"))
	if l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ䲕") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ䲖"),l1ll1ll_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䲗"),re.DOTALL)
		url,l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		data = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ䲘"):l11l1l11_l1_,l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ䲙"):l11l1lll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䲚"),url,data,l1l111_l1_ (u"ࠫࠬ䲛"),l1l111_l1_ (u"ࠬ࠭䲜"),l1l111_l1_ (u"࠭ࠧ䲝"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ䲞"))
		html = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䲟"),html,re.DOTALL)[0]
		if l1l111_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䲠") in l1lllll1_l1_:
			headers = {l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䲡"):l11l11111_l1_,l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䲢"):l1l111_l1_ (u"ࠬ࠭䲣")}
			response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䲤"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ䲥"),headers,l1l111_l1_ (u"ࠨࠩ䲦"),l1l111_l1_ (u"ࠩࠪ䲧"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ䲨"))
			l11l1ll1_l1_ = response.content
			items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䲩"),l11l1ll1_l1_,re.DOTALL)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			l111lll1l_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䲪"))
			for l1ll1ll_l1_,l111l1ll_l1_ in reversed(items):
				l1ll1ll_l1_ = l111lll1l_l1_+l1ll1ll_l1_+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䲫")+l111lll1l_l1_
				l1l1lll1_l1_.append(l111l1ll_l1_)
				l1llll_l1_.append(l1ll1ll_l1_)
			return l1l111_l1_ (u"ࠧࠨ䲬"),l1l1lll1_l1_,l1llll_l1_
		else: return l1l111_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䲭"),[l1l111_l1_ (u"ࠩࠪ䲮")],[l1lllll1_l1_]
	else:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䲯")+l11l11111_l1_
		return l1l111_l1_ (u"ࠫࠬ䲰"),[l1l111_l1_ (u"ࠬ࠭䲱")],[l1ll1ll_l1_]
def l11llllll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭䲲") in l1ll1ll_l1_:
		parts = re.findall(l1l111_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䲳"),l1ll1ll_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ䲴"),re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		host = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭䲵"))
		url = host+l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ䲶")+l11l1l11_l1_+l1l111_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ䲷")+l11l1lll_l1_
		headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䲸"):l1l111_l1_ (u"࠭ࠧ䲹") , l1l111_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ䲺"):l1l111_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ䲻") }
		l1lllll1_l1_ = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ䲼"),headers,l1l111_l1_ (u"ࠪࠫ䲽"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠴ࡷࡹ࠭䲾"))
		l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ䲿"),l1l111_l1_ (u"࠭ࠧ䳀")).replace(l1l111_l1_ (u"ࠧ࡝ࡴࠪ䳁"),l1l111_l1_ (u"ࠨࠩ䳂"))
		return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䳃"),[l1l111_l1_ (u"ࠪࠫ䳄")],[l1lllll1_l1_]
	elif l1l111_l1_ (u"ࠫ࠴ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠯ࠨ䳅") in l1ll1ll_l1_:
		counts = 0
		while l1l111_l1_ (u"ࠬ࠵ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠰ࠩ䳆") in l1ll1ll_l1_ and counts<5:
			response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䳇"),l1ll1ll_l1_,l1l111_l1_ (u"ࠧࠨ䳈"),l1l111_l1_ (u"ࠨࠩ䳉"),l1l111_l1_ (u"ࠩࠪ䳊"),l1l111_l1_ (u"ࠪࠫ䳋"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠵ࡲࡩ࠭䳌"))
			if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䳍") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䳎")]
			counts += 1
		return l1l111_l1_ (u"ࠧࠨ䳏"),[l1l111_l1_ (u"ࠨࠩ䳐")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡂࡍࡋࡒࡒ࡟࠭䳑"),[],[]
def l1l11l111_l1_(url):
	server = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ䳒"))
	if l1l111_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡶࡦࡺࡥࠨ䳓") in url and l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䳔") not in url: url = server+l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ䳕")+url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䳖"))[-1]+l1l111_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ䳗")
	headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䳘"):server,l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䳙"):l1l1ll11l_l1_()}
	if l1l111_l1_ (u"ࠫ࠴࡙ࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࠩ䳚") in url:
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䳛"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䳜")}
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䳝"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,True,l1l111_l1_ (u"ࠨࠩ䳞"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠲ࡵࡷࠫ䳟"))
		html = response.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡗࡗࡉ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䳠"),html,re.DOTALL|re.IGNORECASE)
		if l1ll1ll_l1_: return l1l111_l1_ (u"ࠫࠬ䳡"),[l1l111_l1_ (u"ࠬ࠭䳢")],[l1ll1ll_l1_[0]]
	elif l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ䳣") in url:
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ䳤"),headers,l1l111_l1_ (u"ࠨࠩ䳥"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠳ࡰࡧࠫ䳦"))
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䳧"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0].replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ䳨"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ䳩"))
			return l1l111_l1_ (u"࠭ࠧ䳪"),[l1l111_l1_ (u"ࠧࠨ䳫")],[l1ll1ll_l1_]
	else:
		l1l1111lll1l_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䳬"),url,l1l111_l1_ (u"ࠩࠪ䳭"),headers,l1l111_l1_ (u"ࠪࠫ䳮"),l1l111_l1_ (u"ࠫࠬ䳯"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠷ࡷࡪࠧ䳰"))
		html = l1l1111lll1l_l1_.content
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮࠲࡭ࡸࡥࡧࠢࡀࠤࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩ䳱"),html,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])+l1l111_l1_ (u"ࠧࠧࡦࡀ࠵ࠬ䳲")
			l1lll1l11_l1_ = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䳳"),l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䳴"),headers,l1l111_l1_ (u"ࠪࠫ䳵"),l1l111_l1_ (u"ࠫࠬ䳶"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠸ࡹ࡮ࠧ䳷"))
			html = l1lll1l11_l1_.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡦࡹࡴࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䳸"),html,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠧࠨ䳹"),[l1l111_l1_ (u"ࠨࠩ䳺")],[l1ll1ll_l1_]
		if l1l111_l1_ (u"ࠩࡶࡩࡹ࠳ࡣࡰࡱ࡮࡭ࡪ࠭䳻") in list(l1l1111lll1l_l1_.headers.keys()):
			cookies = l1l1111lll1l_l1_.headers[l1l111_l1_ (u"ࠪࡷࡪࡺ࠭ࡤࡱࡲ࡯࡮࡫ࠧ䳼")]
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡤࡲ࡮࡬ࡡ࠱࠮ࡄࡃࠨ࠯ࠬࡂ࠭ࡀ࠭䳽"),cookies,re.DOTALL)
			if l1ll1ll_l1_:
				l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_[0])
				return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䳾"),[l1l111_l1_ (u"࠭ࠧ䳿")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫ䴀"),[],[]
def l1ll11l11lll_l1_(l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬ䴁") in l1ll1ll_l1_:
		headers = {l1l111_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䴂"):l1l111_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䴃")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䴄"),l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠭䴅"),headers,l1l111_l1_ (u"࠭ࠧ䴆"),l1l111_l1_ (u"ࠧࠨ䴇"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡁࡉࡋࡇ࠸࡚࠳࠱ࡴࡶࠪ䴈"))
		url = response.content
		if url: return l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䴉"),[l1l111_l1_ (u"ࠪࠫ䴊")],[url]
	else:
		parts = re.findall(l1l111_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠨࠬ䴋"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l1l111_l1_ (u"ࠬࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨ䴌"),l1ll1ll_l1_,re.DOTALL|re.IGNORECASE)
		l11l1l11_l1_,l11l1lll_l1_ = parts[0]
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䴍"))
		url = server+l1l111_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡺࡨࡦ࡯ࡨ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡘ࡯࡮ࡨ࡮ࡨ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ䴎")
		data = {l1l111_l1_ (u"ࠨ࡫ࡧࠫ䴏"):l11l1l11_l1_,l1l111_l1_ (u"ࠩ࡬ࠫ䴐"):l11l1lll_l1_}
		headers = {l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䴑"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䴒"),l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䴓"):l1ll1ll_l1_}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䴔"),url,data,headers,l1l111_l1_ (u"ࠧࠨ䴕"),l1l111_l1_ (u"ࠨࠩ䴖"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠳ࡰࡧࠫ䴗"))
		l11l1ll1_l1_ = response.content
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䴘"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[0]
			return l1l111_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䴙"),[l1l111_l1_ (u"ࠬ࠭䴚")],[l1lllll1_l1_]
	return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ䴛"),[],[]
def l1l1111l1ll1_l1_(l11ll1l1l111_l1_):
	l1l11111111l_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡴࡶࡵࠫ䴜"),l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ䴝"),l1l111_l1_ (u"ࠩࡄࡏ࡜ࡇࡍࡠࡘࡈࡖࡎࡌࡉࡄࡃࡗࡍࡔࡔࠧ䴞"))
	headers = {l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䴟"):l1l11111111l_l1_} if l1l11111111l_l1_ else l1l111_l1_ (u"ࠫࠬ䴠")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䴡"),l11ll1l1l111_l1_,l1l111_l1_ (u"࠭ࠧ䴢"),headers,l1l111_l1_ (u"ࠧࠨ䴣"),l1l111_l1_ (u"ࠨࠩ䴤"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠷ࡳࡵࠩ䴥"))
	l11llll111ll_l1_ = response.content
	l1l111l1l1ll_l1_ = str(response.headers)
	l11ll11lll1l_l1_ = l1l111l1l1ll_l1_+l11llll111ll_l1_
	if l1l111_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ䴦") in l11ll11lll1l_l1_: found = True
	else:
		l11lll11l111_l1_,token,l11ll1l1111l_l1_,l11lll1l1ll1_l1_,found = l1l111_l1_ (u"ࠫࠬ䴧"),l1l111_l1_ (u"ࠬ࠭䴨"),l1l111_l1_ (u"࠭ࠧ䴩"),l1l111_l1_ (u"ࠧࠨ䴪"),False
		l11lll11111l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡲࡦࡦ࡬ࡶࡪࡩࡴ࠯ࠬࡂࡥࡨࡺࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸ࡯ࡴࡦ࡭ࡨࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䴫"),l11llll111ll_l1_,re.DOTALL)
		if l11lll11111l_l1_: l11ll1l1111l_l1_,l11lll1l1ll1_l1_ = l11lll11111l_l1_[0]
		l11lll1111ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ䴬")][7]
		user = l1l1l1l1lll_l1_(32)
		if 0:
			data = {l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ䴭"):user,l1l111_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ䴮"):l1l11l11111_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䴯"):l11ll1l1l111_l1_,l1l111_l1_ (u"࠭࡫ࡦࡻࠪ䴰"):l11lll1l1ll1_l1_,l1l111_l1_ (u"ࠧࡪࡦࠪ䴱"):l1l111_l1_ (u"ࠨࠩ䴲"),l1l111_l1_ (u"ࠩ࡭ࡳࡧ࠭䴳"):l1l111_l1_ (u"ࠪ࡫ࡪࡺࡵࡳ࡮ࡶࠫ䴴")}
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䴵"),l11lll1111ll_l1_,data,l1l111_l1_ (u"ࠬ࠭䴶"),l1l111_l1_ (u"࠭ࠧ䴷"),l1l111_l1_ (u"ࠧࠨ䴸"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠷ࡴࡤࠨ䴹"))
			html = response.content
		html = l1l111_l1_ (u"ࠩࠪ䴺")
		if html.startswith(l1l111_l1_ (u"࡙ࠪࡗࡒࡓ࠾ࠩ䴻")):
			l1l1l11ll111_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䴼"),html.split(l1l111_l1_ (u"࡛ࠬࡒࡍࡕࡀࠫ䴽"),1)[1])
			for request in l1l1l11ll111_l1_:
				url = request[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䴾")]
				method = request[l1l111_l1_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪࠧ䴿")]
				data = request[l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠭䵀")]
				headers = request[l1l111_l1_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ䵁")]
				response = l11l1l_l1_(l11ll11l_l1_,method,url,data,headers,l1l111_l1_ (u"ࠪࠫ䵂"),l1l111_l1_ (u"ࠫࠬ䵃"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬ䵄"))
				l11llll111ll_l1_ = response.content
				if l1l111_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ䵅") in l11llll111ll_l1_:
					found = True
					break
				l1l111l1l1ll_l1_ = str(response.headers)
				l11ll11lll1l_l1_ = l1l111l1l1ll_l1_+l11llll111ll_l1_
				l11lll11l111_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡽࠫࠪ࠰࠭ࡃࠧ࠮ࡥࡺࡌ࠱࠮ࡄ࠯ࠢࠨ䵆"),l11ll11lll1l_l1_,re.DOTALL)
				token = re.findall(l1l111_l1_ (u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡹࡵ࡫ࡦࡰ࠱࠮ࡄࠨࠨ࠱࠵ࡄ࠲࠯ࡅࠩࠣࠩ䵇"),l11ll11lll1l_l1_,re.DOTALL)
				if token: token = token[0]
				if l11lll11l111_l1_ or token: break
		if not found:
			if not l11lll11l111_l1_:
				if not token and l11lll11111l_l1_:
					if 1 and not html.startswith(l1l111_l1_ (u"ࠩࡌࡈࡂ࠭䵈")):
						data = {l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ䵉"):user,l1l111_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ䵊"):l1l11l11111_l1_,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ䵋"):l11ll1l1l111_l1_,l1l111_l1_ (u"࠭࡫ࡦࡻࠪ䵌"):l11lll1l1ll1_l1_,l1l111_l1_ (u"ࠧࡪࡦࠪ䵍"):l1l111_l1_ (u"ࠨࠩ䵎"),l1l111_l1_ (u"ࠩ࡭ࡳࡧ࠭䵏"):l1l111_l1_ (u"ࠪ࡫ࡪࡺࡩࡥࠩ䵐")}
						response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䵑"),l11lll1111ll_l1_,data,l1l111_l1_ (u"ࠬ࠭䵒"),l1l111_l1_ (u"࠭ࠧ䵓"),l1l111_l1_ (u"ࠧࠨ䵔"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠹ࡺࡨࠨ䵕"))
						html = response.content
					else: html = l1l111_l1_ (u"ࠩࡌࡈࡂ࠷࠲࠴࠶࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽࠵࠷ࠪ䵖")
					if html.startswith(l1l111_l1_ (u"ࠪࡍࡉࡃࠧ䵗")):
						l11ll1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡎࡊ࠽ࠩ࠰࠭ࡃ࠮ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀࠬ࠳࠰࠿ࠪࠦࠪ䵘"),html,re.DOTALL)
						l1l111lll1ll_l1_,l1l1111l1ll_l1_ = l11ll1l11l1l_l1_[0]
						message = l1l111_l1_ (u"ࠬํะ่ࠢส่฾๋ไ๋หࠣฮาะวอ๋ࠢๆฯࠦๅ็ࠢ࠴࠴ࠥหไ๊ࠢࠪ䵙")+l1l1111l1ll_l1_+l1l111_l1_ (u"࠭ࠠฬษ้๎ฮ࠭䵚")
						l11l1ll11ll_l1_ = l11l111ll11_l1_()
						l11l1ll11ll_l1_.create(l1l111_l1_ (u"ࠧๆฯส์้ฯࠠหฮส์ืࠦแฮืࠣว๋อࠠฤ่ึห๋่ࠦๅีอࠤอืๆศ็ฯࠤ่๎ๅษ์๋ฮึ࠭䵛"),message)
						t1 = time.time()
						l11llll1l111_l1_,l11ll1ll1l1l_l1_ = 0,0
						while l11llll1l111_l1_<int(l1l1111l1ll_l1_):
							l1ll1llll1ll_l1_(l11l1ll11ll_l1_,int(l11llll1l111_l1_/int(l1l1111l1ll_l1_)*100),message,l1l111_l1_ (u"ࠨࠩ䵜"),l1l1111l1ll_l1_+l1l111_l1_ (u"ࠩࠣ࠳ࠥ࠭䵝")+str(int(l11llll1l111_l1_))+l1l111_l1_ (u"ࠪࠤࠥัว็์ฬࠫ䵞"))
							if l11llll1l111_l1_>l11ll1ll1l1l_l1_+10:
								data = {l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ䵟"):user,l1l111_l1_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭䵠"):l1l11l11111_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䵡"):l11ll1l1l111_l1_,l1l111_l1_ (u"ࠧ࡬ࡧࡼࠫ䵢"):l11lll1l1ll1_l1_,l1l111_l1_ (u"ࠨ࡫ࡧࠫ䵣"):l1l111lll1ll_l1_,l1l111_l1_ (u"ࠩ࡭ࡳࡧ࠭䵤"):l1l111_l1_ (u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬ䵥")}
								response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ䵦"),l11lll1111ll_l1_,data,l1l111_l1_ (u"ࠬ࠭䵧"),l1l111_l1_ (u"࠭ࠧ䵨"),l1l111_l1_ (u"ࠧࠨ䵩"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠺ࡺࡨࠨ䵪"))
								html = response.content
								if html.startswith(l1l111_l1_ (u"ࠩࡗࡓࡐࡋࡎ࠾ࠩ䵫")):
									token = html.split(l1l111_l1_ (u"ࠪࡘࡔࡑࡅࡏ࠿ࠪ䵬"),1)[1]
									break
								l11ll1ll1l1l_l1_ = l11llll1l111_l1_
							else: time.sleep(1)
							l11llll1l111_l1_ = time.time()-t1
						l11l1ll11ll_l1_.close()
				if token:
					l11ll1l11lll_l1_ = response.cookies
					l1l1l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠫࡦࡱࡷࡢ࡯ࡢࡷࡪࡹࡳࡪࡱࡱࡁ࠭࠴ࠪࡀࠫ࠾ࠫ䵭"),l11ll11lll1l_l1_,re.DOTALL)
					if l1l111_l1_ (u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ䵮") in list(l11ll1l11lll_l1_.keys()): l1l1l1lll1l1_l1_ = l11ll1l11lll_l1_[l1l111_l1_ (u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭䵯")]
					elif l1l1l1lll1l1_l1_: l1l1l1lll1l1_l1_ = l1l1l1lll1l1_l1_[0]
					l11lll11111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡪࡩ࠲ࡸࡥࡥ࡫ࡵࡩࡨࡺ࠮ࠫࡁࡤࡧࡹ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷ࡮ࡺࡥ࡬ࡧࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䵰"),l11llll111ll_l1_,re.DOTALL)
					if l11lll11111l_l1_: l11ll1l1111l_l1_,l11lll1l1ll1_l1_ = l11lll11111l_l1_[0]
					if l1l1l1lll1l1_l1_ and l11lll11111l_l1_:
						headers = {l1l111_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䵱"):l1l111_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࠪ䵲")+l1l1l1lll1l1_l1_,l1l111_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䵳"):l11ll1l1l111_l1_,l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䵴"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ䵵")}
						data = l1l111_l1_ (u"࠭ࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪࡃࠧ䵶")+token
						response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ䵷"),l11ll1l1111l_l1_,data,headers,False,l1l111_l1_ (u"ࠨࠩ䵸"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠼ࡴࡩࠩ䵹"))
						l11llll111ll_l1_ = response.content
						try: cookies = response.cookies
						except: cookies = {}
						l11lll11l111_l1_ = re.findall(l1l111_l1_ (u"ࠥࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࠰࠭ࡃ࠮࠭࠺ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ䵺"),str(cookies),re.DOTALL)
			if l11lll11l111_l1_:
				name,l11lll11l111_l1_ = l11lll11l111_l1_[0]
				l1l11111111l_l1_ = name+l1l111_l1_ (u"ࠫࡂ࠭䵻")+l11lll11l111_l1_
				l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䵼"),l1l111_l1_ (u"࠭ࡁࡌ࡙ࡄࡑࡤ࡜ࡅࡓࡋࡉࡍࡈࡇࡔࡊࡑࡑࠫ䵽"),l1l11111111l_l1_,l1l1lll1l1l_l1_)
				l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䵾"),l1l111_l1_ (u"ࠨࠩ䵿"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䶀"),l1l111_l1_ (u"๊ࠪัำสࠡ฻่่๏ฯࠠโฯุࠤศ์วࠡว้ืฬ์ࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬำุๆ่ࠡอหหา่ࠠาสࠤฬ๊แฮื่่ࠣ๐๋ࠠีอาิ๋็ศࠢ็หา่วࠡ࠰࠱ࠤํ๊วࠡฬ๋ะิࠦอศฮฬࠤ้หูศัฬࠤ์ึวࠡษ็ๅา฻ࠠๅ฻าอࠥษิ่ำࠣࡠࡳࡢ࡮ࠡ฻็้ฬࠦร็๊ࠢิฬࠦวๅใะูู่ࠥโࠢํฮ่ืัࠡใํࠤาอไสࠢอ฾๏ืࠠาสฺࠤฬ๊ฬ่ษีࠤออไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦลุใสลࠥืว้ฬิࠤฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥ็ีๅࠢึ่่ࠦวๅำส์ฯืࠠ࠯࠰ࠣวํࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤศ๎ࠠษำ๋็ุ๐ࠧ䶁"))
				if l1l111_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ䶂") not in l11llll111ll_l1_:
					headers = {l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䶃"):l1l11111111l_l1_}
					response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䶄"),l11ll1l1l111_l1_,l1l111_l1_ (u"ࠧࠨ䶅"),headers,l1l111_l1_ (u"ࠨࠩ䶆"),l1l111_l1_ (u"ࠩࠪ䶇"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠷ࡵࡪࠪ䶈"))
					l11llll111ll_l1_ = response.content
	if not found and not l1l11111111l_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䶉"),l1l111_l1_ (u"ࠬ࠭䶊"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䶋"),l1l111_l1_ (u"ฺࠧ็็๎ฮࠦแฮืࠣว๋อࠠฤ่ึห๋ࠦแีๆอࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧ䶌"))
	return l11llll111ll_l1_
def l1ll1l1l_l1_(url,type,l111l1ll_l1_):
	l1ll11l1_l1_,l111l11ll1_l1_ = [],[]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䶍"),url,l1l111_l1_ (u"ࠩࠪ䶎"),l1l111_l1_ (u"ࠪࠫ䶏"),l1l111_l1_ (u"ࠫࠬ䶐"),l1l111_l1_ (u"ࠬ࠭䶑"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍ࠮࠳ࡶࡸࠬ䶒"))
	l11l1ll1_l1_ = response.content
	l1lll1l1_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࡂ࠯ࡢࡀࠪ䶓"),l11l1ll1_l1_,re.DOTALL)
	for block in l1lll1l1_l1_:
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ䶔"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ in l1ll11l1_l1_: continue
			if l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪ䶕") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ䶖") not in l1ll1ll_l1_: continue
			title = title.replace(l1l111_l1_ (u"ࠫࡁ࠵ࡳࡱࡣࡱࡂࠬ䶗"),l1l111_l1_ (u"ࠬ࠭䶘")).replace(l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ䶙"),l1l111_l1_ (u"ࠧࠨ䶚")).strip(l1l111_l1_ (u"ࠨࠢࠪ䶛")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䶜"),l1l111_l1_ (u"ࠪࠤࠬ䶝"))
			l1ll11l1_l1_.append(l1ll1ll_l1_)
			l111l11ll1_l1_.append(title)
	if len(l1ll11l1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠫอ฿ึ่ษࠣ๎าะวอࠢ࠹࠴ࠥัว็์ฬࠫ䶞"),l111l11ll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡄࡣࡱࡧࡪࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䶟"),[],[]
	elif len(l1ll11l1_l1_)==1: l11l11l_l1_ = 0
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧ䶠"),[],[]
	l11ll1l1l111_l1_ = l1ll11l1_l1_[l11l11l_l1_]
	l11llll111ll_l1_ = l1l1111l1ll1_l1_(l11ll1l1l111_l1_)
	l1llll_l1_,l1l1lll1_l1_ = [],[]
	if type==l1l111_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ䶡"):
		l1l11111ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࡤࡷࡲ࠲ࡲ࡯ࡢࡦࡨࡶ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䶢"),l11llll111ll_l1_,re.DOTALL)
		if l1l11111ll1l_l1_:
			l1ll1ll_l1_ = l111l11_l1_(l1l11111ll1l_l1_[0])
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(l111l1ll_l1_)
	elif type==l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࠨ䶣"):
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䶤"),l11llll111ll_l1_,re.DOTALL)
		for l1ll1ll_l1_,size in l1ll_l1_:
			if not l1ll1ll_l1_: continue
			if l111l1ll_l1_ in size:
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
				break
		if not l1llll_l1_:
			for l1ll1ll_l1_,size in l1ll_l1_:
				if not l1ll1ll_l1_: continue
				l1l1lll1_l1_.append(size)
				l1llll_l1_.append(l1ll1ll_l1_)
	if not l1llll_l1_: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌ࡙ࡄࡑࠬ䶥"),[],[]
	return l1l111_l1_ (u"ࠬ࠭䶦"),l1l1lll1_l1_,l1llll_l1_
def l11l111_l1_(url,name):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䶧"),url,l1l111_l1_ (u"ࠧࠨ䶨"),l1l111_l1_ (u"ࠨࠩ䶩"),True,l1l111_l1_ (u"ࠩࠪ䶪"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩ䶫"))
	html = response.content
	cookies = response.cookies
	if l1l111_l1_ (u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫ䶬") in list(cookies.keys()):
		l1l11111111l_l1_ = cookies[l1l111_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ䶭")]
		l1l11111111l_l1_ = l111l11_l1_(escapeUNICODE(l1l11111111l_l1_))
		items = re.findall(l1l111_l1_ (u"࠭ࡲࡰࡷࡷࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䶮"),l1l11111111l_l1_,re.DOTALL)
		l1lllll1_l1_ = items[0].replace(l1l111_l1_ (u"ࠧ࡝࠱ࠪ䶯"),l1l111_l1_ (u"ࠨ࠱ࠪ䶰"))
		l1lllll1_l1_ = escapeUNICODE(l1lllll1_l1_)
	else: l1lllll1_l1_ = url
	if l1l111_l1_ (u"ࠩࡦࡥࡹࡩࡨ࠯࡫ࡶࠫ䶱") in l1lllll1_l1_:
		id = l1lllll1_l1_.split(l1l111_l1_ (u"ࠪࠩ࠷ࡌࠧ䶲"))[-1]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡧࡴࡤࡪ࠱࡭ࡸ࠵ࠧ䶳")+id
		return l1l111_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䶴"),[l1l111_l1_ (u"࠭ࠧ䶵")],[l1lllll1_l1_]
	else:
		l1l11l11_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭䶶")][0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ䶷"),l1l11l11_l1_,l1l111_l1_ (u"ࠩࠪ䶸"),l1l111_l1_ (u"ࠪࠫ䶹"),True,l1l111_l1_ (u"ࠫࠬ䶺"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫ䶻"))
		l11lll1l1l1l_l1_ = response.url
		l1l111lll111_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ䶼"))[2]
		l1l11l111l1l_l1_ = l11lll1l1l1l_l1_.split(l1l111_l1_ (u"ࠧ࠰ࠩ䶽"))[2]
		l1llllll_l1_ = l1lllll1_l1_.replace(l1l111lll111_l1_,l1l11l111l1l_l1_)
		headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䶾"):l1l111_l1_ (u"ࠩࠪ䶿") , l1l111_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䷀"):l1l111_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䷁") , l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭䷂"):l1llllll_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ䷃"), l1llllll_l1_, l1l111_l1_ (u"ࠧࠨ䷄"), headers, False,l1l111_l1_ (u"ࠨࠩ䷅"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠸ࡸࡤࠨ䷆"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䷇"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l1l111_l1_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䷈"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l1l111_l1_ (u"ࠬࡂࡥ࡮ࡤࡨࡨ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䷉"),html,re.DOTALL|re.IGNORECASE)
		if items:
			l1ll1ll_l1_ = items[0].replace(l1l111_l1_ (u"࠭࡜࠰ࠩ䷊"),l1l111_l1_ (u"ࠧ࠰ࠩ䷋"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪ䷌"))
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䷍") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ䷎") + l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬ䷏"),l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧ䷐"))
			if name==l1l111_l1_ (u"࠭ࠧ䷑"): l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠧࠨ䷒"),[l1l111_l1_ (u"ࠨࠩ䷓")],[l1ll1ll_l1_]
			else: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䷔"),[l1l111_l1_ (u"ࠪࠫ䷕")],[l1ll1ll_l1_]
		else: l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_ = l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬ䷖"),[],[]
		return l1l111l1l111_l1_,l1l1lll1_l1_,l1llll_l1_
def l11ll1lll111_l1_(url):
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䷗") : l1l111_l1_ (u"࠭ࠧ䷘") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ䷙"),headers,l1l111_l1_ (u"ࠨࠩ䷚"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐ࠯࠴ࡷࡹ࠭䷛"))
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䷜"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_,errno = [],[],l1l111_l1_ (u"ࠫࠬ䷝")
	if items:
		for l1ll1ll_l1_,l1lll1l1ll11_l1_ in items:
			l1l1lll1_l1_.append(l1lll1l1ll11_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡓࡃࡓࡍࡉ࡜ࡉࡅࡇࡒࠫ䷞"),[],[]
	return l1l111_l1_ (u"࠭ࠧ䷟"),l1l1lll1_l1_,l1llll_l1_
def l11lllll111l_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䷠"),l1l111_l1_ (u"ࠨࠩ䷡"))
	headers = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䷢"):l1l111_l1_ (u"ࠪࠫ䷣")}
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ䷤"),headers,l1l111_l1_ (u"ࠬ࠭䷥"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡕࡑࡕࡁࡅ࠯࠴ࡷࡹ࠭䷦"))
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ䷧"),html,re.DOTALL)
	if items:
		url = items[0]+l1l111_l1_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ䷨")+url
		return l1l111_l1_ (u"ࠩࠪ䷩"),[l1l111_l1_ (u"ࠪࠫ䷪")],[url]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡒࡎࡒࡅࡉ࠭䷫"),[],[]
def l11llll1111l_l1_(url):
	url = url.strip(l1l111_l1_ (u"ࠬ࠵ࠧ䷬"))
	if l1l111_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ䷭") in url: id = url.split(l1l111_l1_ (u"ࠧ࠰ࠩ䷮"))[4]
	else: id = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ䷯"))[-1]
	url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡨࡹࡴࡳࡧࡤࡱ࠳ࡺ࡯࠰ࡲ࡯ࡥࡾ࡫ࡲࡀࡨ࡬ࡨࡂ࠭䷰") + id
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䷱") : l1l111_l1_ (u"ࠫࠬ䷲") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭䷳"),headers,l1l111_l1_ (u"࠭ࠧ䷴"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩ䷵"))
	html = html.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠫ䷶"),l1l111_l1_ (u"ࠩࠪ䷷"))
	items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䷸"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ䷹"),[l1l111_l1_ (u"ࠬ࠭䷺")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪ䷻"),[],[]
def l11lll1l1111_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䷼"),l1l111_l1_ (u"ࠨࠩ䷽"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠩࠪ䷾"),l1l111_l1_ (u"ࠪࠫ䷿"),l1l111_l1_ (u"ࠫࠬ一"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬ丁"))
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭丂"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for l1ll1ll_l1_,l1lll1l1ll11_l1_,res in items:
		l1l1lll1_l1_.append(l1lll1l1ll11_l1_+l1l111_l1_ (u"ࠧࠡࠩ七")+res)
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡏ࡛ࡃࠪ丄"),[],[]
	return l1l111_l1_ (u"ࠩࠪ丅"),l1l1lll1_l1_,l1llll_l1_
def l11llllll11l_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ丆"),l1l111_l1_ (u"ࠫࠬ万"))
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭丈"),l1l111_l1_ (u"࠭ࠧ三"),l1l111_l1_ (u"ࠧࠨ上"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ下"))
	items = re.findall(l1l111_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢ丌"),html,re.DOTALL)
	items = set(items)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	for id,mode,hash,l1lll1l1ll11_l1_,res in items:
		url = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ不")+id+l1l111_l1_ (u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ与")+mode+l1l111_l1_ (u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ丏")+hash
		html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ丐"),l1l111_l1_ (u"ࠧࠨ丑"),l1l111_l1_ (u"ࠨࠩ丒"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠵ࡲࡩ࠭专"))
		items = re.findall(l1l111_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ且"),html,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1l1lll1_l1_.append(l1lll1l1ll11_l1_+l1l111_l1_ (u"ࠫࠥ࠭丕")+res)
			l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==0: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫ世"),[],[]
	return l1l111_l1_ (u"࠭ࠧ丗"),l1l1lll1_l1_,l1llll_l1_
def l11lll111111_l1_(url):
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠧࠨ丘")
	if 1 or l1l111_l1_ (u"ࠨࡍࡨࡽࡂ࠭丙") not in url:
		l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭业"),l1l111_l1_ (u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧ丛"))
		l1lllll1_l1_ = l1lllll1_l1_.split(l1l111_l1_ (u"ࠫ࠴࠭东"))
		id = l1lllll1_l1_[3]
		l1lllll1_l1_ = l1l111_l1_ (u"ࠬ࠵ࠧ丝").join(l1lllll1_l1_[0:4])
		payload = {l1l111_l1_ (u"࠭ࡩࡥࠩ丞"):id,l1l111_l1_ (u"ࠧࡰࡲࠪ丟"):l1l111_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫ丠"),l1l111_l1_ (u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧ両"):l1l111_l1_ (u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪ丢")}
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ丣"),l1lllll1_l1_,payload,l1l111_l1_ (u"ࠬ࠭两"),l1l111_l1_ (u"࠭ࠧ严"),l1l111_l1_ (u"ࠧࠨ並"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡚ࡖࡂࡐࡏ࠰࠵ࡸࡺࠧ丧"))
		if l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ丨") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ丩")]
		if not l1ll1ll_l1_ and response.succeeded:
			html = response.content
			l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ个"),html,re.DOTALL)
			if l1ll1ll_l1_: l1ll1ll_l1_ = l1ll1ll_l1_[0]
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ丫"),url,l1l111_l1_ (u"࠭ࠧ丬"),l1l111_l1_ (u"ࠧࠨ中"),l1l111_l1_ (u"ࠨࠩ丮"),l1l111_l1_ (u"ࠩࠪ丯"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩ丰"))
		if l1l111_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭丱") in list(response.headers.keys()): l1ll1ll_l1_ = response.headers[l1l111_l1_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧ串")]
	if l1ll1ll_l1_: return l1l111_l1_ (u"࠭ࠧ丳"),[l1l111_l1_ (u"ࠧࠨ临")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡕࡈࡏࡎࠩ丵"),[],[]
def l11llll1l11l_l1_(url):
	headers = { l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭丶") : l1l111_l1_ (u"ࠪࠫ丷") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ丸"),headers,l1l111_l1_ (u"ࠬ࠭丹"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡏࡍࡎ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ为"))
	items = re.findall(l1l111_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࡳ࠻࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭主"),html,re.DOTALL)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	if items:
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳ࠸ࠬ丼"))
		l1llll_l1_.append(items[0][1])
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࡰ࠷ࡺ࠾ࠧ丽"))
		l1llll_l1_.append(items[0][0])
		return l1l111_l1_ (u"ࠪࠫ举"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ丿"),[],[]
def l11ll1ll1l1_l1_(url):
	id = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ乀"))[-1]
	id = id.split(l1l111_l1_ (u"࠭ࠦࠨ乁"))[0]
	id = id.replace(l1l111_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ乂"),l1l111_l1_ (u"ࠨࠩ乃"))
	l1lllll1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ乄")][0]+l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠭久")+id
	l11lll111lll_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡾࡵࡵࡵࡷ࠱ࡦࡪ࠵ࠧ乆")+id
	l1l1111ll111_l1_,l11lll11ll1l_l1_,l1l111111111_l1_,l11llll111l1_l1_ = l1l111_l1_ (u"ࠬ࠭乇"),l1l111_l1_ (u"࠭ࠧ么"),l1l111_l1_ (u"ࠧࠨ义"),l1l111_l1_ (u"ࠨࠩ乊")
	for l1l11l111l_l1_ in range(5):
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭之"),l1lllll1_l1_,l1l111_l1_ (u"ࠪࠫ乌"),l1l111_l1_ (u"ࠫࠬ乍"),l1l111_l1_ (u"ࠬ࠭乎"),l1l111_l1_ (u"࠭ࠧ乏"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨ乐"))
		html = response.content
		if l1l111_l1_ (u"ࠨ࡫ࡷࡥ࡬࠭乑") in html: break
		time.sleep(2)
	l1l1l111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡒ࡯ࡥࡾ࡫ࡲࡓࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤ࠭࠴ࠪࡀࠫ࠾ࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭乒"),html,re.DOTALL)
	if l1l1l111ll_l1_: l1l1l111ll_l1_ = l1l1l111ll_l1_[0]
	else: l1l1l111ll_l1_ = html
	l1l1l111ll_l1_ = l1l1l111ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡࡻ࠰࠱࠴࠹ࠫ乓"),l1l111_l1_ (u"ࠫࠫ࠭乔"))
	l1l111l1l11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ乕"),l1l1l111ll_l1_)
	l1l1lll1_l1_,l1llll_l1_ = [l1l111_l1_ (u"࠭ศะ๊้ࠤฯืฬๆหࠣ๎ํะ๊้สࠪ乖")],[l1l111_l1_ (u"ࠧࠨ乗")]
	try:
		l1l11l1111ll_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡵࠪ乘")][l1l111_l1_ (u"ࠩࡳࡰࡦࡿࡥࡳࡅࡤࡴࡹ࡯࡯࡯ࡵࡗࡶࡦࡩ࡫࡭࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭乙")][l1l111_l1_ (u"ࠪࡧࡦࡶࡴࡪࡱࡱࡘࡷࡧࡣ࡬ࡵࠪ乚")]
		for l11lllll1lll_l1_ in l1l11l1111ll_l1_:
			l1ll1ll_l1_ = l11lllll1lll_l1_[l1l111_l1_ (u"ࠫࡧࡧࡳࡦࡗࡵࡰࠬ乛")]
			try: title = l11lllll1lll_l1_[l1l111_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ乜")][l1l111_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪ九")]
			except: title = l11lllll1lll_l1_[l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ乞")][l1l111_l1_ (u"ࠨࡴࡸࡲࡸ࠭也")][0][l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ习")]
			l1llll_l1_.append(l1ll1ll_l1_)
			l1l1lll1_l1_.append(title)
	except: pass
	if len(l1l1lll1_l1_)>1:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡษ็ฮึาๅสࠢส่๊์วิสฬ࠾ࠬ乡"), l1l1lll1_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ乢"),[],[]
		elif l11l11l_l1_!=0:
			l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠬࠬࠧ乣")
			l11llll1ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠦࠩࡨࡰࡸࡂ࠴ࠪࡀࠫࠩࠫ乤"),l1ll1ll_l1_)
			if l11llll1ll11_l1_: l1ll1ll_l1_ = l1ll1ll_l1_.replace(l11llll1ll11_l1_[0],l1l111_l1_ (u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨ乥"))
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡨࡰࡸࡂࡼࡴࡵࠩ书")
			l1l1111ll111_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩࠩࠫ乧"))
	formats,l1l111l1l1l1_l1_,l11ll1llll11_l1_,l11ll1llll1l_l1_,l11ll1lll1ll_l1_ = [],[],[],[],[]
	try: l11lll11ll1l_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ乨")][l1l111_l1_ (u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭乩")]
	except: pass
	try: l1l111111111_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ乪")][l1l111_l1_ (u"࠭ࡨ࡭ࡵࡐࡥࡳ࡯ࡦࡦࡵࡷ࡙ࡷࡲࠧ乫")]
	except: pass
	try: formats = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ乬")][l1l111_l1_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ乭")]
	except: pass
	try: l1l111l1l1l1_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩ乮")][l1l111_l1_ (u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬ乯")]
	except: pass
	l1l1111l1lll_l1_ = formats+l1l111l1l1l1_l1_
	for dict in l1l1111l1lll_l1_:
		if l1l111_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ买") in list(dict.keys()): dict[l1l111_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ乱")] = str(dict[l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ乲")])
		if l1l111_l1_ (u"ࠧࡧࡲࡶࠫ乳") in list(dict.keys()): dict[l1l111_l1_ (u"ࠨࡨࡳࡷࠬ乴")] = str(dict[l1l111_l1_ (u"ࠩࡩࡴࡸ࠭乵")])
		if l1l111_l1_ (u"ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬ乶") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦࠩ乷")] = dict[l1l111_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ乸")]
		if l1l111_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡘࡧ࡭ࡱ࡮ࡨࡖࡦࡺࡥࠨ乹") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴࡥࡳࡢ࡯ࡳࡰࡪࡥࡲࡢࡶࡨࠫ乺")] = str(dict[l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ乻")])
		if l1l111_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ乼") in list(dict.keys()): dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ乽")] = str(dict[l1l111_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ乾")])
		if l1l111_l1_ (u"ࠬࡽࡩࡥࡶ࡫ࠫ乿") in list(dict.keys()): dict[l1l111_l1_ (u"࠭ࡳࡪࡼࡨࠫ亀")] = str(dict[l1l111_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭亁")])+l1l111_l1_ (u"ࠨࡺࠪ亂")+str(dict[l1l111_l1_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩ亃")])
		if l1l111_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭亄") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ亅")] = dict[l1l111_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ了")][l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ亇")]+l1l111_l1_ (u"ࠧ࠮ࠩ予")+dict[l1l111_l1_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ争")][l1l111_l1_ (u"ࠩࡨࡲࡩ࠭亊")]
		if l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ事") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ二")] = dict[l1l111_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ亍")][l1l111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ于")]+l1l111_l1_ (u"ࠧ࠮ࠩ亏")+dict[l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ亐")][l1l111_l1_ (u"ࠩࡨࡲࡩ࠭云")]
		if l1l111_l1_ (u"ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫ互") in list(dict.keys()): dict[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ亓")] = dict[l1l111_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭五")]
		if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ井") in list(dict.keys()) and int(dict[l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ亖")])>111222333: del dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ亗")]
		if l1l111_l1_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡈ࡯ࡰࡩࡧࡵࠫ亘") in list(dict.keys()):
			cipher = dict[l1l111_l1_ (u"ࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬ亙")].split(l1l111_l1_ (u"ࠫࠫ࠭亚"))
			for item in cipher:
				key,value = item.split(l1l111_l1_ (u"ࠬࡃࠧ些"),1)
				dict[key] = l111l11_l1_(value)
		if l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ亜") in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ亝")] = l111l11_l1_(dict[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ亞")])
		l11ll1llll11_l1_.append(dict)
	l1l111111l11_l1_ = l1l111_l1_ (u"ࠩࠪ亟")
	if l1l111_l1_ (u"ࠪࡷࡵࡃࡳࡪࡩࠪ亠") in l1l1l111ll_l1_:
		l1l111l11111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡜ࡸࠬࡂ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࠳࠴࠯ࡣࡣࡶࡩ࠳ࡰࡳࠪࠤࠪ亡"),html,re.DOTALL)
		if l1l111l11111_l1_:
			l1l111l11111_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭亢")][0]+l1l111l11111_l1_[0]
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ亣"),l1l111l11111_l1_,l1l111_l1_ (u"ࠧࠨ交"),l1l111_l1_ (u"ࠨࠩ亥"),l1l111_l1_ (u"ࠩࠪ亦"),l1l111_l1_ (u"ࠪࠫ产"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ亨"))
			l1l111111l11_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l11ll1l1l1l1_l1_ = cipher._load_javascript(l1l111111l11_l1_)
			l11lll11l1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ亩"),str(l11ll1l1l1l1_l1_))
			l11ll1l1ll11_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l11lll11l1l1_l1_)
	for dict in l11ll1llll11_l1_:
		url = dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ亪")]
		if l1l111_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡀࠫ享") in url or url.count(l1l111_l1_ (u"ࠨࡵ࡬࡫ࡂ࠭京"))>1:
			l11ll1llll1l_l1_.append(dict)
		elif l1l111111l11_l1_ and l1l111_l1_ (u"ࠩࡶࠫ亭") in list(dict.keys()) and l1l111_l1_ (u"ࠪࡷࡵ࠭亮") in list(dict.keys()):
			l11lllll1l1l_l1_ = l11ll1l1ll11_l1_.execute(dict[l1l111_l1_ (u"ࠫࡸ࠭亯")])
			if l11lllll1l1l_l1_!=dict[l1l111_l1_ (u"ࠬࡹࠧ亰")]:
				dict[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ亱")] = url+l1l111_l1_ (u"ࠧࠧࠩ亲")+dict[l1l111_l1_ (u"ࠨࡵࡳࠫ亳")]+l1l111_l1_ (u"ࠩࡀࠫ亴")+l11lllll1l1l_l1_
				l11ll1llll1l_l1_.append(dict)
	for dict in l11ll1llll1l_l1_:
		l111lll_l1_,l11ll1ll11l1_l1_,l1l11l111111_l1_,l1l1l1ll1_l1_,codecs,l11ll1111l1_l1_ = l1l111_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ亵"),l1l111_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ亶"),l1l111_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭亷"),l1l111_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ亸"),l1l111_l1_ (u"ࠧࠨ亹"),l1l111_l1_ (u"ࠨ࠲ࠪ人")
		try:
			l11ll1lllll1_l1_ = dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ亻")]
			l11ll1lllll1_l1_ = l11ll1lllll1_l1_.replace(l1l111_l1_ (u"ࠪ࠯ࠬ亼"),l1l111_l1_ (u"ࠫࠬ亽"))
			items = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ亾"),l11ll1lllll1_l1_,re.DOTALL)
			l1l1l1ll1_l1_,l111lll_l1_,codecs = items[0]
			l1l1111llll1_l1_ = codecs.split(l1l111_l1_ (u"࠭ࠬࠨ亿"))
			l11ll1ll11l1_l1_ = l1l111_l1_ (u"ࠧࠨ什")
			for item in l1l1111llll1_l1_: l11ll1ll11l1_l1_ += item.split(l1l111_l1_ (u"ࠨ࠰ࠪ仁"))[0]+l1l111_l1_ (u"ࠩ࠯ࠫ仂")
			l11ll1ll11l1_l1_ = l11ll1ll11l1_l1_.strip(l1l111_l1_ (u"ࠪ࠰ࠬ仃"))
			if l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ仄") in list(dict.keys()): l11ll1111l1_l1_ = str(float(dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭仅")]*10)//1024/10)+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭仆")
			else: l11ll1111l1_l1_ = l1l111_l1_ (u"ࠧࠨ仇")
			if l1l1l1ll1_l1_==l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠭仈"): continue
			elif l1l111_l1_ (u"ࠩ࠯ࠫ仉") in l11ll1lllll1_l1_:
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠪࡅ࠰࡜ࠧ今")
				l1l11l111111_l1_ = l111lll_l1_+l1l111_l1_ (u"ࠫࠥࠦࠧ介")+l11ll1111l1_l1_+dict[l1l111_l1_ (u"ࠬࡹࡩࡻࡧࠪ仌")].split(l1l111_l1_ (u"࠭ࡸࠨ仍"))[1]
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭从"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ仏")
				l1l11l111111_l1_ = l11ll1111l1_l1_+dict[l1l111_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ仐")].split(l1l111_l1_ (u"ࠪࡼࠬ仑"))[1]+l1l111_l1_ (u"ࠫࠥࠦࠧ仒")+dict[l1l111_l1_ (u"ࠬ࡬ࡰࡴࠩ仓")]+l1l111_l1_ (u"࠭ࡦࡱࡵࠪ仔")+l1l111_l1_ (u"ࠧࠡࠢࠪ仕")+l111lll_l1_
			elif l1l1l1ll1_l1_==l1l111_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ他"):
				l1l1l1ll1_l1_ = l1l111_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ仗")
				l1l11l111111_l1_ = l11ll1111l1_l1_+str(int(dict[l1l111_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ付")])/1000)+l1l111_l1_ (u"ࠫࡰ࡮ࡺࠡࠢࠪ仙")+dict[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭仚")]+l1l111_l1_ (u"࠭ࡣࡩࠩ仛")+l1l111_l1_ (u"ࠧࠡࠢࠪ仜")+l111lll_l1_
		except:
			l1111l1l1l1_l1_ = traceback.format_exc()
			sys.stderr.write(l1111l1l1l1_l1_)
		if l1l111_l1_ (u"ࠨࡦࡸࡶࡂ࠭仝") in dict[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭仞")]: l1l1llll11_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ仟")].split(l1l111_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ仠"),1)[1].split(l1l111_l1_ (u"ࠬࠬࠧ仡"),1)[0]))
		elif l1l111_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ仢") in list(dict.keys()): l1l1llll11_l1_ = round(0.5+float(dict[l1l111_l1_ (u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ代")])/1000)
		else: l1l1llll11_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ令")
		if l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ以") not in list(dict.keys()): l11ll1111l1_l1_ = dict[l1l111_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ仦")].split(l1l111_l1_ (u"ࠫࡽ࠭仧"))[1]
		else: l11ll1111l1_l1_ = dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭仨")]
		if l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ仩") not in list(dict.keys()): dict[l1l111_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ仪")] = l1l111_l1_ (u"ࠨ࠲࠰࠴ࠬ仫")
		dict[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ们")] = l1l1l1ll1_l1_+l1l111_l1_ (u"ࠪ࠾ࠥࠦࠧ仭")+l1l11l111111_l1_+l1l111_l1_ (u"ࠫࠥࠦࠨࠨ仮")+l11ll1ll11l1_l1_+l1l111_l1_ (u"ࠬ࠲ࠧ仯")+dict[l1l111_l1_ (u"࠭ࡩࡵࡣࡪࠫ仰")]+l1l111_l1_ (u"ࠧࠪࠩ仱")
		dict[l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ仲")] = l1l11l111111_l1_.split(l1l111_l1_ (u"ࠩࠣࠤࠬ仳"))[0].split(l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ仴"))[0]
		dict[l1l111_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ仵")] = l1l1l1ll1_l1_
		dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ件")] = l111lll_l1_
		dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭价")] = codecs
		dict[l1l111_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ仸")] = l1l1llll11_l1_
		dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ仹")] = l11ll1111l1_l1_
		l11ll1lll1ll_l1_.append(dict)
	l1l1111l1l11_l1_,l11llll1l1l1_l1_,l1l111ll1ll1_l1_,l1l111llll11_l1_,l11ll11llll1_l1_ = [],[],[],[],[]
	l1l1111lllll_l1_,l11lll111ll1_l1_,l11lll11l11l_l1_,l1l1111lll11_l1_,l1l111l1llll_l1_ = [],[],[],[],[]
	if l11lll11ll1l_l1_:
		dict = {}
		dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ仺")] = l1l111_l1_ (u"ࠪࡅ࠰࡜ࠧ任")
		dict[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭仼")] = l1l111_l1_ (u"ࠬࡳࡰࡥࠩ份")
		dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ仾")] = dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭仿")]+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ伀")+dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ企")]+l1l111_l1_ (u"ࠪࠤࠥ࠭伂")+l1l111_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ伃")
		dict[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ伄")] = l11lll11ll1l_l1_
		dict[l1l111_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ伅")] = l1l111_l1_ (u"ࠧ࠱ࠩ伆")
		dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ伇")] = l1l111_l1_ (u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭伈")
		l11ll1lll1ll_l1_.append(dict)
	if l1l111111111_l1_:
		l1l111l11l11_l1_,l11lll1llll1_l1_ = l1l11l1lll_l1_(l1l111111111_l1_)
		l11lllllll11_l1_ = list(zip(l1l111l11l11_l1_,l11lll1llll1_l1_))
		for title,l1ll1ll_l1_ in l11lllllll11_l1_:
			dict = {}
			dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ伉")] = l1l111_l1_ (u"ࠫࡆ࠱ࡖࠨ伊")
			dict[l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ伋")] = l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ伌")
			dict[l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ伍")] = l1ll1ll_l1_
			if l1l111_l1_ (u"ࠨ࡭ࡥࡴࡸ࠭伎") in title: dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ伏")] = title.split(l1l111_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ伐"))[0].rsplit(l1l111_l1_ (u"ࠫࠥࠦࠧ休"))[-1]
			else: dict[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭伒")] = l1l111_l1_ (u"࠭࠱࠱ࠩ伓")
			if title.count(l1l111_l1_ (u"ࠧࠡࠢࠪ伔"))>1:
				l111l1ll_l1_ = title.rsplit(l1l111_l1_ (u"ࠨࠢࠣࠫ伕"))[-3]
				if l111l1ll_l1_.isdigit(): dict[l1l111_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ伖")] = l111l1ll_l1_
				else: dict[l1l111_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ众")] = l1l111_l1_ (u"ࠫ࠵࠶࠰࠱ࠩ优")
			if title==l1l111_l1_ (u"ࠬ࠳࠱ࠨ伙"): dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ会")] = dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭伛")]+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ伜")+dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ伝")]+l1l111_l1_ (u"ࠪࠤࠥ࠭伞")+l1l111_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ伟")
			else: dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ传")] = dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ伡")]+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ伢")+dict[l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ伣")]+l1l111_l1_ (u"ࠩࠣࠤࠬ伤")+dict[l1l111_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ伥")]+l1l111_l1_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ伦")+dict[l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭伧")]
			l11ll1lll1ll_l1_.append(dict)
	l11ll1lll1ll_l1_ = sorted(l11ll1lll1ll_l1_,reverse=True,key=lambda key: float(key[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ伨")]))
	if not l11ll1lll1ll_l1_:
		l1lll11111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ伩"),html,re.DOTALL)
		l1lll1111l1_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ伪"),html,re.DOTALL)
		l1l11111llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ伫"),html,re.DOTALL)
		l1l1111l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࢀࠨࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ伬"),html,re.DOTALL)
		try: l11ll11ll1l1_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ伭")][l1l111_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ伮")][l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ伯")][l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭估")][l1l111_l1_ (u"ࠨࡴࡸࡲࡸ࠭伱")][0][l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ伲")]
		except: l11ll11ll1l1_l1_ = l1l111_l1_ (u"ࠪࠫ伳")
		try: l1l1111l11l1_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ伴")][l1l111_l1_ (u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ伵")][l1l111_l1_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ伶")][l1l111_l1_ (u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨ伷")][0][l1l111_l1_ (u"ࠨࡴࡸࡲࡸ࠭伸")][0][l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ伹")]
		except: l1l1111l11l1_l1_ = l1l111_l1_ (u"ࠪࠫ伺")
		try: l1l1111l11ll_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ伻")][l1l111_l1_ (u"ࠬࡸࡥࡢࡵࡲࡲࠬ似")]
		except: l1l1111l11ll_l1_ = l1l111_l1_ (u"࠭ࠧ伽")
		if l1lll11111l_l1_ or l1lll1111l1_l1_ or l1l11111llll_l1_ or l1l1111l1111_l1_ or l11ll11ll1l1_l1_ or l1l1111l11l1_l1_ or l1l1111l11ll_l1_:
			if   l1lll11111l_l1_: message = l1lll11111l_l1_[0]
			elif l1lll1111l1_l1_: message = l1lll1111l1_l1_[0]
			elif l1l11111llll_l1_: message = l1l11111llll_l1_[0]
			elif l1l1111l1111_l1_: message = l1l1111l1111_l1_[0]
			elif l11ll11ll1l1_l1_: message = l11ll11ll1l1_l1_
			elif l1l1111l11l1_l1_: message = l1l1111l11l1_l1_
			elif l1l1111l11ll_l1_: message = l1l1111l11ll_l1_
			l1l111lllll1_l1_ = message.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ伾"),l1l111_l1_ (u"ࠨࠩ伿")).strip(l1l111_l1_ (u"ࠩࠣࠫ佀"))
			l1l111llll1l_l1_ = l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ่ࠦใัࠣ๎่๎ๆࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่࡞࠳ࡈࡕࡌࡐࡔࡠࠫ佁")
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ佂"),l1l111_l1_ (u"ࠬ࠭佃"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่๊ࠡส่๊ฮัๆฮࠪ佄"),l1l111llll1l_l1_+l1l111_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ佅")+l1l111lllll1_l1_)
			return l1l111_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠪ但")+l1l111lllll1_l1_,[],[]
		else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ佇"),[],[]
	l11ll1ll11ll_l1_,l11ll1ll1l11_l1_,l11llll1lll1_l1_ = [],[],[]
	for dict in l11ll1lll1ll_l1_:
		if dict[l1l111_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ佈")]==l1l111_l1_ (u"࡛ࠫ࡯ࡤࡦࡱࠪ佉"):
			l1l1111l1l11_l1_.append(dict[l1l111_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ佊")])
			l1l1111lllll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ佋")]==l1l111_l1_ (u"ࠧࡂࡷࡧ࡭ࡴ࠭佌"):
			l11llll1l1l1_l1_.append(dict[l1l111_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ位")])
			l11lll111ll1_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ低")]==l1l111_l1_ (u"ࠪࡱࡵࡪࠧ住"):
			title = dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ佐")].replace(l1l111_l1_ (u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ佑"),l1l111_l1_ (u"࠭ࠧ佒"))
			if l1l111_l1_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ体") not in list(dict.keys()): l11ll1111l1_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ佔")
			else: l11ll1111l1_l1_ = dict[l1l111_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ何")]
			l11ll1ll11ll_l1_.append([dict,{},title,l11ll1111l1_l1_])
		else:
			title = dict[l1l111_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ佖")].replace(l1l111_l1_ (u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫ佗"),l1l111_l1_ (u"ࠬ࠭佘"))
			if l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ余") not in list(dict.keys()): l11ll1111l1_l1_ = l1l111_l1_ (u"ࠧ࠱ࠩ佚")
			else: l11ll1111l1_l1_ = dict[l1l111_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ佛")]
			l11ll1ll11ll_l1_.append([dict,{},title,l11ll1111l1_l1_])
			l1l111ll1ll1_l1_.append(title)
			l11lll11l11l_l1_.append(dict)
		l1l111111l1l_l1_ = True
		if l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ作") in list(dict.keys()):
			if l1l111_l1_ (u"ࠪࡥࡻ࠶ࠧ佝") in dict[l1l111_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ佞")]: l1l111111l1l_l1_ = False
			elif kodi_version<18:
				if l1l111_l1_ (u"ࠬࡧࡶࡤࠩ佟") not in dict[l1l111_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭你")] and l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࡥࠬ佡") not in dict[l1l111_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ佢")]: l1l111111l1l_l1_ = False
		if dict[l1l111_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ佣")]==l1l111_l1_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ佤") and dict[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ佥")]!=l1l111_l1_ (u"ࠬ࠶࠭࠱ࠩ佦") and l1l111111l1l_l1_==True:
			l11ll11llll1_l1_.append(dict[l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ佧")])
			l1l111l1llll_l1_.append(dict)
		elif dict[l1l111_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭佨")]==l1l111_l1_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ佩") and dict[l1l111_l1_ (u"ࠩ࡬ࡲ࡮ࡺࠧ佪")]!=l1l111_l1_ (u"ࠪ࠴࠲࠶ࠧ佫") and l1l111111l1l_l1_==True:
			l1l111llll11_l1_.append(dict[l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ佬")])
			l1l1111lll11_l1_.append(dict)
	for l1l1111111l1_l1_ in l1l1111lll11_l1_:
		l1l11l1111l1_l1_ = l1l1111111l1_l1_[l1l111_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭佭")]
		for l1l11111lll1_l1_ in l1l111l1llll_l1_:
			l1l11l111lll_l1_ = l1l11111lll1_l1_[l1l111_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ佮")]
			l11ll1111l1_l1_ = l1l11l111lll_l1_+l1l11l1111l1_l1_
			title = l1l11111lll1_l1_[l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭佯")].replace(l1l111_l1_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪ佰"),l1l111_l1_ (u"ࠩࡰࡴࡩࠦࠠࠨ佱"))
			title = title.replace(l1l11111lll1_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ佲")]+l1l111_l1_ (u"ࠫࠥࠦࠧ佳"),l1l111_l1_ (u"ࠬ࠭佴"))
			title = title.replace(str((float(l1l11l111lll_l1_*10)//1024/10))+l1l111_l1_ (u"࠭࡫ࡣࡲࡶࠫ併"),str((float(l11ll1111l1_l1_*10)//1024/10))+l1l111_l1_ (u"ࠧ࡬ࡤࡳࡷࠬ佶"))
			title = title+l1l111_l1_ (u"ࠨࠪࠪ佷")+l1l1111111l1_l1_[l1l111_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ佸")].split(l1l111_l1_ (u"ࠪࠬࠬ佹"),1)[1]
			l11ll1ll11ll_l1_.append([l1l11111lll1_l1_,l1l1111111l1_l1_,title,l11ll1111l1_l1_])
	l11ll1ll11ll_l1_ = sorted(l11ll1ll11ll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1l11111lll1_l1_,l1l1111111l1_l1_,title,l11ll1111l1_l1_ in l11ll1ll11ll_l1_:
		l11ll1ll1lll_l1_ = l1l11111lll1_l1_[l1l111_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭佺")]
		if l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ佻") in list(l1l1111111l1_l1_.keys()):
			l11ll1ll1lll_l1_ = l1l111_l1_ (u"࠭࡭ࡱࡦࠪ佼")
		if l11ll1ll1lll_l1_ not in l11llll1lll1_l1_:
			l11llll1lll1_l1_.append(l11ll1ll1lll_l1_)
			l11ll1ll1l11_l1_.append([l1l11111lll1_l1_,l1l1111111l1_l1_,title,l11ll1111l1_l1_])
	l11ll1l1l11l_l1_,l1l111l11l1l_l1_,shift = [],[],0
	l1l11111l111_l1_,l1l111l1lll1_l1_ = l1l111_l1_ (u"ࠧࠨ佽"),l1l111_l1_ (u"ࠨࠩ佾")
	try: l1l11111l111_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ使")][l1l111_l1_ (u"ࠪࡥࡺࡺࡨࡰࡴࠪ侀")]
	except: l1l11111l111_l1_ = l1l111_l1_ (u"ࠫࠬ侁")
	try: l11llll11l1l_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ侂")][l1l111_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩ侃")]
	except: l11llll11l1l_l1_ = l1l111_l1_ (u"ࠧࠨ侄")
	if l1l11111l111_l1_ and l11llll11l1l_l1_:
		shift += 1
		title = l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ侅")+l1l11111l111_l1_+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ來")
		l1ll1ll_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ侇")][0]+l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ侈")+l11llll11l1l_l1_
		l11ll1l1l11l_l1_.append(title)
		l1l111l11l1l_l1_.append(l1ll1ll_l1_)
		try: l1l111l1lll1_l1_ = l1l111l1l11l_l1_[l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ侉")][l1l111_l1_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠩ侊")][l1l111_l1_ (u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠫ例")][-1][l1l111_l1_ (u"ࠨࡷࡵࡰࠬ侌")]
		except: pass
	for l1l11111lll1_l1_,l1l1111111l1_l1_,title,l11ll1111l1_l1_ in l11ll1ll1l11_l1_:
		l11ll1l1l11l_l1_.append(title) ; l1l111l11l1l_l1_.append(l1l111_l1_ (u"ࠩ࡫࡭࡬࡮ࡥࡴࡶࠪ侍"))
	if l1l111ll1ll1_l1_: l11ll1l1l11l_l1_.append(l1l111_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮัาอࠬ侎")) ; l1l111l11l1l_l1_.append(l1l111_l1_ (u"ࠫࡲࡻࡸࡦࡦࠪ侏"))
	if l11ll1ll11ll_l1_: l11ll1l1l11l_l1_.append(l1l111_l1_ (u"ࠬ฻่าหࠣ์ฺ๎สࠡษ็้ฯ๎แาࠩ侐")) ; l1l111l11l1l_l1_.append(l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ侑"))
	if l11ll11llll1_l1_: l11ll1l1l11l_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲࡧࠤฬิสาࠢสฺ่๎ัส๋ࠢห้฻่หࠩ侒")) ; l1l111l11l1l_l1_.append(l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ侓"))
	if l1l1111l1l11_l1_: l11ll1l1l11l_l1_.append(l1l111_l1_ (u"ุࠩ์ึฯࠠษั๋๊ࠥ฻่หࠩ侔")) ; l1l111l11l1l_l1_.append(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ侕"))
	if l11llll1l1l1_l1_: l11ll1l1l11l_l1_.append(l1l111_l1_ (u"ฺࠫ๎สࠡสา์๋ࠦี้ำฬࠫ侖")) ; l1l111l11l1l_l1_.append(l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ侗"))
	l1l111lll1l1_l1_ = False
	while True:
		l11l11l_l1_ = l1ll11ll_l1_(l11lll111lll_l1_, l11ll1l1l11l_l1_)
		if l11l11l_l1_==-1: return l1l111_l1_ (u"࠭ࡅ࡙ࡋࡗࠫ侘"),[],[]
		elif l11l11l_l1_==0 and l1l11111l111_l1_:
			l1ll1ll_l1_ = l1l111l11l1l_l1_[l11l11l_l1_]
			new_path = sys.argv[0]+l1l111_l1_ (u"ࠧࡀࡶࡼࡴࡪࡃࡦࡰ࡮ࡧࡩࡷࠬ࡭ࡰࡦࡨࡁ࠶࠺࠱ࠧࡰࡤࡱࡪࡃࠧ侙")+QUOTE(l1l11111l111_l1_)+l1l111_l1_ (u"ࠨࠨࡸࡶࡱࡃࠧ侚")+l1ll1ll_l1_
			if l1l111l1lll1_l1_: new_path = new_path+l1l111_l1_ (u"ࠩࠩ࡭ࡲࡧࡧࡦ࠿ࠪ供")+QUOTE(l1l111l1lll1_l1_)
			xbmc.executebuiltin(l1l111_l1_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠢ侜")+new_path+l1l111_l1_ (u"ࠦ࠮ࠨ依"))
			return l1l111_l1_ (u"ࠬࡋࡘࡊࡖࠪ侞"),[],[]
		choice = l1l111l11l1l_l1_[l11l11l_l1_]
		l1l1111l1l1l_l1_ = l11ll1l1l11l_l1_[l11l11l_l1_]
		if choice==l1l111_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ侟"):
			l11llll111l1_l1_ = l11lll11ll1l_l1_
			break
		elif choice in [l1l111_l1_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭侠"),l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ価"),l1l111_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ侢")]:
			if choice==l1l111_l1_ (u"ࠪࡱࡺࡾࡥࡥࠩ侣"): l1l1lll1_l1_,l1l1111111ll_l1_ = l1l111ll1ll1_l1_,l11lll11l11l_l1_
			elif choice==l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ侤"): l1l1lll1_l1_,l1l1111111ll_l1_ = l1l1111l1l11_l1_,l1l1111lllll_l1_
			elif choice==l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ侥"): l1l1lll1_l1_,l1l1111111ll_l1_ = l11llll1l1l1_l1_,l11lll111ll1_l1_
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ侦"), l1l1lll1_l1_)
			if l11l11l_l1_!=-1:
				l11llll111l1_l1_ = l1l1111111ll_l1_[l11l11l_l1_][l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ侧")]
				l1l1111l1l1l_l1_ = l1l1lll1_l1_[l11l11l_l1_]
				break
		elif choice==l1l111_l1_ (u"ࠨ࡯ࡳࡨࠬ侨"):
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอ࠿࠭侩"), l11ll11llll1_l1_)
			if l11l11l_l1_!=-1:
				l1l1111l1l1l_l1_ = l11ll11llll1_l1_[l11l11l_l1_]
				l11ll1l1l1ll_l1_ = l1l111l1llll_l1_[l11l11l_l1_]
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ฮ࠿࠭侪"), l1l111llll11_l1_)
				if l11l11l_l1_!=-1:
					l1l1111l1l1l_l1_ += l1l111_l1_ (u"ࠫࠥ࠱ࠠࠨ侫")+l1l111llll11_l1_[l11l11l_l1_]
					l11lllll1ll1_l1_ = l1l1111lll11_l1_[l11l11l_l1_]
					l1l111lll1l1_l1_ = True
					break
		elif choice==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ侬"):
			l11lll1l1l11_l1_,l11ll11lllll_l1_,l11ll1llllll_l1_,l1l111ll1lll_l1_ = list(zip(*l11ll1ll11ll_l1_))
			l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬ侭"), l11ll1llllll_l1_)
			if l11l11l_l1_!=-1:
				l1l1111l1l1l_l1_ = l11ll1llllll_l1_[l11l11l_l1_]
				l11ll1l1l1ll_l1_ = l11lll1l1l11_l1_[l11l11l_l1_]
				if l1l111_l1_ (u"ࠧ࡮ࡲࡧࠫ侮") in l11ll1llllll_l1_[l11l11l_l1_] and l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ侯")]!=l11lll11ll1l_l1_:
					l11lllll1ll1_l1_ = l11ll11lllll_l1_[l11l11l_l1_]
					l1l111lll1l1_l1_ = True
				else: l11llll111l1_l1_ = l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭侰")]
				break
		elif choice==l1l111_l1_ (u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫ侱"):
			l11lll1l1l11_l1_,l11ll11lllll_l1_,l11ll1llllll_l1_,l1l111ll1lll_l1_ = list(zip(*l11ll1ll1l11_l1_))
			l11ll1l1l1ll_l1_ = l11lll1l1l11_l1_[l11l11l_l1_-shift]
			if l1l111_l1_ (u"ࠫࡲࡶࡤࠨ侲") in l11ll1llllll_l1_[l11l11l_l1_-shift] and l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ侳")]!=l11lll11ll1l_l1_:
				l11lllll1ll1_l1_ = l11ll11lllll_l1_[l11l11l_l1_-shift]
				l1l111lll1l1_l1_ = True
			else: l11llll111l1_l1_ = l11ll1l1l1ll_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ侴")]
			l1l1111l1l1l_l1_ = l11ll1llllll_l1_[l11l11l_l1_-shift]
			break
	if not l1l111lll1l1_l1_: l11llll11111_l1_ = l11llll111l1_l1_
	else: l11llll11111_l1_ = l1l111_l1_ (u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠨ侵")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠨࡷࡵࡰࠬ侶")]+l1l111_l1_ (u"ࠩࠣ࠯ࠥࡇࡵࡥ࡫ࡲ࠾ࠥ࠭侷")+l11lllll1ll1_l1_[l1l111_l1_ (u"ࠪࡹࡷࡲࠧ侸")]
	if l1l111lll1l1_l1_:
		l1l111l1ll1l_l1_ = int(l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭侹")])
		l11llll11l11_l1_ = int(l11lllll1ll1_l1_[l1l111_l1_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ侺")])
		l1l1llll11_l1_ = str(max(l1l111l1ll1l_l1_,l11llll11l11_l1_))
		l11lll111l1l_l1_ = l11ll1l1l1ll_l1_[l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ侻")].replace(l1l111_l1_ (u"ࠧࠧࠩ侼"),l1l111_l1_ (u"ࠨࠨࡤࡱࡵࡁࠧ侽"))
		l11llll1l1ll_l1_ = l11lllll1ll1_l1_[l1l111_l1_ (u"ࠩࡸࡶࡱ࠭侾")].replace(l1l111_l1_ (u"ࠪࠪࠬ便"),l1l111_l1_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪ俀"))
		l1l111ll11ll_l1_ = l1l111_l1_ (u"ࠬࡂ࠿ࡹ࡯࡯ࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨ࠱࠯࠲ࠥࠤࡪࡴࡣࡰࡦ࡬ࡲ࡬ࡃࠢࡖࡖࡉ࠱࠽ࠨ࠿࠿࡞ࡱࠫ俁")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"࠭࠼ࡎࡒࡇࠤࡽࡳ࡬࡯ࡵ࠽ࡼࡸ࡯࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠸࠰࠱࠳࠲࡜ࡒࡒࡓࡤࡪࡨࡱࡦ࠳ࡩ࡯ࡵࡷࡥࡳࡩࡥࠣࠢࡻࡱࡱࡴࡳ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠦࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡲࡩ࡯࡭ࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡹ࠶࠲ࡴࡸࡧ࠰࠳࠼࠽࠾࠵ࡸ࡭࡫ࡱ࡯ࠧࠦࡸࡴ࡫࠽ࡷࡨ࡮ࡥ࡮ࡣࡏࡳࡨࡧࡴࡪࡱࡱࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡥࡣࡶ࡬࠿ࡹࡣࡩࡧࡰࡥ࠿ࡳࡰࡥ࠼࠵࠴࠶࠷ࠠࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡲࡩࡧࡲࡥࡵ࠱࡭ࡸࡵ࠮ࡰࡴࡪ࠳࡮ࡺࡴࡧ࠱ࡓࡹࡧࡲࡩࡤ࡮ࡼࡅࡻࡧࡩ࡭ࡣࡥࡰࡪ࡙ࡴࡢࡰࡧࡥࡷࡪࡳ࠰ࡏࡓࡉࡌ࠳ࡄࡂࡕࡋࡣࡸࡩࡨࡦ࡯ࡤࡣ࡫࡯࡬ࡦࡵ࠲ࡈࡆ࡙ࡈ࠮ࡏࡓࡈ࠳ࡾࡳࡥࠤࠣࡱ࡮ࡴࡂࡶࡨࡩࡩࡷ࡚ࡩ࡮ࡧࡀࠦࡕ࡚࠱࠯࠷ࡖࠦࠥࡳࡥࡥ࡫ࡤࡔࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡆࡸࡶࡦࡺࡩࡰࡰࡀࠦࡕ࡚ࠧ係")+l1l1llll11_l1_+l1l111_l1_ (u"ࠧࡔࠤࠣࡸࡾࡶࡥ࠾ࠤࡶࡸࡦࡺࡩࡤࠤࠣࡴࡷࡵࡦࡪ࡮ࡨࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡰࡳࡱࡩ࡭ࡱ࡫࠺ࡪࡵࡲࡪ࡫࠳࡭ࡢ࡫ࡱ࠾࠷࠶࠱࠲ࠤࡁࡠࡳ࠭促")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠨ࠾ࡓࡩࡷ࡯࡯ࡥࡀ࡟ࡲࠬ俄")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠱ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡶࡪࡦࡨࡳ࠴࠭俅")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ俆")]+l1l111_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ俇")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ俈")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭俉")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ俊")]+l1l111_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ俋")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ俌")]+l1l111_l1_ (u"ࠪࠦࠥࡹࡴࡢࡴࡷ࡛࡮ࡺࡨࡔࡃࡓࡁࠧ࠷ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠭俍")+str(l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ俎")])+l1l111_l1_ (u"ࠬࠨࠠࡸ࡫ࡧࡸ࡭ࡃࠢࠨ俏")+str(l11ll1l1l1ll_l1_[l1l111_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ俐")])+l1l111_l1_ (u"ࠧࠣࠢ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠫ俑")+str(l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ俒")])+l1l111_l1_ (u"ࠩࠥࠤ࡫ࡸࡡ࡮ࡧࡕࡥࡹ࡫࠽ࠣࠩ俓")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠪࡪࡵࡹࠧ俔")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ俕")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ俖")+l11lll111l1l_l1_+l1l111_l1_ (u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ俗")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ俘")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ俙")]+l1l111_l1_ (u"ࠩࠥࡂࡡࡴࠧ俚")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭俛")+l11ll1l1l1ll_l1_[l1l111_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ俜")]+l1l111_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ保")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ俞")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭俟")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭俠")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࠣ࡭ࡩࡃࠢ࠲ࠤࠣࡱ࡮ࡳࡥࡕࡻࡳࡩࡂࠨࡡࡶࡦ࡬ࡳ࠴࠭信")+l11lllll1ll1_l1_[l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ俢")]+l1l111_l1_ (u"ࠫࠧࠦࡳࡶࡤࡶࡩ࡬ࡳࡥ࡯ࡶࡄࡰ࡮࡭࡮࡮ࡧࡱࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ俣")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ俤")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭俥")+l11lllll1ll1_l1_[l1l111_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ俦")]+l1l111_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ俧")+l11lllll1ll1_l1_[l1l111_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ俨")]+l1l111_l1_ (u"ࠪࠦࠥࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨ࠾ࠤ࠴࠷࠵࠺࠷࠶ࠤࡁࡠࡳ࠭俩")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠫࡁࡇࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡇࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࠣࡷࡨ࡮ࡥ࡮ࡧࡌࡨ࡚ࡸࡩ࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼࠵࠷࠵࠶࠳࠻࠵࠽ࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡢࡧࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠪ俪")+l11lllll1ll1_l1_[l1l111_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭俫")]+l1l111_l1_ (u"࠭ࠢ࠰ࡀ࡟ࡲࠬ俬")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪ俭")+l11llll1l1ll_l1_+l1l111_l1_ (u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧ修")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧ俯")+l11lllll1ll1_l1_[l1l111_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ俰")]+l1l111_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ俱")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨ俲")+l11lllll1ll1_l1_[l1l111_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ俳")]+l1l111_l1_ (u"ࠧࠣࠢ࠲ࡂࡡࡴࠧ俴")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫ俵")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨ俶")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨ俷")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠫࡁ࠵ࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ俸")
		l1l111ll11ll_l1_ += l1l111_l1_ (u"ࠬࡂ࠯ࡎࡒࡇࡂࡡࡴࠧ俹")
		if kodi_version>18.99:
			import http.server as l11lll1ll1ll_l1_
			import http.client as l11lllll11ll_l1_
		else:
			import BaseHTTPServer as l11lll1ll1ll_l1_
			import httplib as l11lllll11ll_l1_
		class l1l11111ll11_l1_(l11lll1ll1ll_l1_.HTTPServer):
			def __init__(self,l1ll1l1lllll_l1_=l1l111_l1_ (u"࠭࡬ࡰࡥࡤࡰ࡭ࡵࡳࡵࠩ俺"),port=55055,l1l111ll11ll_l1_=l1l111_l1_ (u"ࠧ࠽ࡀࠪ俻")):
				self.l1ll1l1lllll_l1_ = l1ll1l1lllll_l1_
				self.port = port
				self.l1l111ll11ll_l1_ = l1l111ll11ll_l1_
				l11lll1ll1ll_l1_.HTTPServer.__init__(self,(self.l1ll1l1lllll_l1_,self.port),l1l111ll111l_l1_)
				self.l11lllllllll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ俼")+l1ll1l1lllll_l1_+l1l111_l1_ (u"ࠩ࠽ࠫ俽")+str(port)+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ俾")
			def start(self):
				self.threads = l11l1111l1l_l1_(False)
				self.threads.start_new_thread(1,self.l11lll1lll11_l1_)
			def l11lll1lll11_l1_(self):
				self.l11ll1l1ll1l_l1_ = True
				while self.l11ll1l1ll1l_l1_:
					self.handle_request()
			def stop(self):
				self.l11ll1l1ll1l_l1_ = False
				self.l1l11111l1ll_l1_()
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
			def load(self,l1l111ll11ll_l1_):
				self.l1l111ll11ll_l1_ = l1l111ll11ll_l1_
			def l1l11111l1ll_l1_(self):
				conn = l11lllll11ll_l1_.HTTPConnection(self.l1ll1l1lllll_l1_+l1l111_l1_ (u"ࠫ࠿࠭俿")+str(self.port))
				conn.request(l1l111_l1_ (u"ࠧࡎࡅࡂࡆࠥ倀"), l1l111_l1_ (u"ࠨ࠯ࠣ倁"))
		class l1l111ll111l_l1_(l11lll1ll1ll_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				self.send_response(200)
				self.send_header(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭倂"),l1l111_l1_ (u"ࠨࡶࡨࡼࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬ倃"))
				self.end_headers()
				self.wfile.write(self.server.l1l111ll11ll_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ倄")))
				time.sleep(1)
				if self.path==l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ倅"): self.server.shutdown()
				if self.path==l1l111_l1_ (u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ倆"): self.server.shutdown()
			def do_HEAD(self):
				self.send_response(200)
				self.end_headers()
		httpd = l1l11111ll11_l1_(l1l111_l1_ (u"ࠬ࠷࠲࠸࠰࠳࠲࠵࠴࠱ࠨ倇"),55055,l1l111ll11ll_l1_)
		l11llll111l1_l1_ = httpd.l11lllllllll_l1_
		httpd.start()
	else: httpd = l1l111_l1_ (u"࠭ࠧ倈")
	if not l11llll111l1_l1_: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧ倉"),[],[]
	return l1l111_l1_ (u"ࠨࠩ倊"),[l1l111_l1_ (u"ࠩࠪ個")],[[l11llll111l1_l1_,l1l1111ll111_l1_,httpd]]
def l11lllllll1l_l1_(url):
	headers = { l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ倌") : l1l111_l1_ (u"ࠫࠬ倍") }
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠬ࠭倎"),headers,l1l111_l1_ (u"࠭ࠧ倏"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ倐"))
	items = re.findall(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ們"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l111l11l11_l1_,l1l1lll1_l1_,l11lll1llll1_l1_,l1llll_l1_ = [],[],[],[]
	if items:
		for l1ll1ll_l1_,dummy,l1lll1l1ll11_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ倒"),l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ倓"))
			if l1l111_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ倔") in l1ll1ll_l1_:
				l1l111l11l11_l1_,l11lll1llll1_l1_ = l1l11l1lll_l1_(l1ll1ll_l1_)
				l1llll_l1_ = l1llll_l1_ + l11lll1llll1_l1_
				if l1l111l11l11_l1_[0]==l1l111_l1_ (u"ࠬ࠳࠱ࠨ倕"): l1l1lll1_l1_.append(l1l111_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ倖")+l1l111_l1_ (u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨ倗"))
				else:
					for title in l1l111l11l11_l1_:
						l1l1lll1_l1_.append(l1l111_l1_ (u"ࠨีํีๆืࠠฯษุࠫ倘")+l1l111_l1_ (u"ࠩࠣࠤࠥ࠭候")+title)
			else:
				title = l1l111_l1_ (u"ࠪื๏ืแาࠢัหฺ࠭倚")+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ倛")+l1lll1l1ll11_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
				l1l1lll1_l1_.append(title)
		return l1l111_l1_ (u"ࠬ࠭倜"),l1l1lll1_l1_,l1llll_l1_
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡇࡕࡂࠨ倝"),[],[]
def l11lll11llll_l1_(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ倞"),url,l1l111_l1_ (u"ࠨࠩ借"),l1l111_l1_ (u"ࠩࠪ倠"),l1l111_l1_ (u"ࠪࠫ倡"),l1l111_l1_ (u"ࠫࠬ倢"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚࡙ࡍࡉࡋࡏࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ倣"))
	html = response.content
	l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ値"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		return l1l111_l1_ (u"ࠧࠨ倥"),[l1l111_l1_ (u"ࠨࠩ倦")],[l1ll1ll_l1_]
	return l1l111_l1_ (u"ࠩࠪ倧"),[],[]
def l11ll1lll1l1_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ倨"),l1l111_l1_ (u"ࠫࠬ倩")).replace(l1l111_l1_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫ倪"),l1l111_l1_ (u"࠭ࠧ倫"))
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ倬"),url,l1l111_l1_ (u"ࠨࠩ倭"),l1l111_l1_ (u"ࠩࠪ倮"),l1l111_l1_ (u"ࠪࠫ倯"),l1l111_l1_ (u"ࠫࠬ倰"),l1l111_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡉࡍࡑࡋࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ倱"))
	html = response.content
	l1llllll11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪ࡜ࠪ࠰࠭ࡃࡡ࠯࡜ࠪ࡞ࠬ࠭ࠬ倲"),html,re.DOTALL)
	if l1llllll11ll_l1_:
		l1llllll11ll_l1_ = l1llllll11ll_l1_[0]
		l1ll1l111l11_l1_ = l1ll1ll11l1l_l1_(l1llllll11ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭倳"),l1ll1l111l11_l1_,re.DOTALL)
		if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨࠪࡿࠪ倴"),l1ll1l111l11_l1_,re.DOTALL)
		l1l1lll1_l1_,l1llll_l1_ = [],[]
		for l1ll1ll_l1_,title in l1ll_l1_:
			if not title: title = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠩ࠱ࠫ倵"),1)[1]
			l1l1lll1_l1_.append(title)
			l1llll_l1_.append(l1ll1ll_l1_)
		return l1l111_l1_ (u"ࠪࠫ倶"),l1l1lll1_l1_,l1llll_l1_
	id = url.split(l1l111_l1_ (u"ࠫ࠴࠭倷"))[3]
	headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ倸"):l1l111_l1_ (u"࠭ࠧ倹") , l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭债"):l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ倻") }
	payload = { l1l111_l1_ (u"ࠩ࡬ࡨࠬ值"):id , l1l111_l1_ (u"ࠪࡳࡵ࠭倽"):l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ倾") }
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪ倿"),url,payload,headers,l1l111_l1_ (u"࠭ࠧ偀"),l1l111_l1_ (u"ࠧࠨ偁"),l1l111_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ偂"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ偃"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠪࠫ偄"),[l1l111_l1_ (u"ࠫࠬ偅")],[ items[0] ]
	return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪ࡙ࠠࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠭偆"),[],[]
def l1l1111l111l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ假"),l1l111_l1_ (u"ࠧࠨ偈"),l1l111_l1_ (u"ࠨࠩ偉"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ偊"))
	items = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ偋"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ偌"),[l1l111_l1_ (u"ࠬ࠭偍")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠫ偎"),[],[]
def l11llllllll1_l1_(url):
	return l1l111_l1_ (u"ࠧࠨ偏"),[l1l111_l1_ (u"ࠨࠩ偐")],[ url ]
def l1l111l111l1_l1_(url):
	server = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ偑"))
	basename = l1l111_l1_ (u"ࠪ࠳ࠬ偒").join(server[0:3])
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ偓"),l1l111_l1_ (u"ࠬ࠭偔"),l1l111_l1_ (u"࠭ࠧ偕"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ偖"))
	items = re.findall(l1l111_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ偗"),html,re.DOTALL)
	if items:
		l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_,l1l1l11llll1_l1_,l1l111ll1l11_l1_,l1l111ll1l1l_l1_,l1l111ll11l1_l1_ = items[0]
		var = int(l1l1l11lll1l_l1_) % int(l1l1l11llll1_l1_) + int(l1l111ll1l11_l1_) % int(l1l111ll1l1l_l1_)
		url = basename + l1l1l11l1l1l_l1_ + str(var) + l1l111ll11l1_l1_
		return l1l111_l1_ (u"ࠩࠪ偘"),[l1l111_l1_ (u"ࠪࠫ偙")],[url]
	else: return l1l111_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩ࡚ࠦࡊࡒࡓ࡝ࡘࡎࡁࡓࡇࠪ做"),[],[]
def l11llllll1l1_l1_(url):
	url = url.replace(l1l111_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ偛"),l1l111_l1_ (u"࠭ࠧ停"))
	url = url.replace(l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭偝"),l1l111_l1_ (u"ࠨࠩ偞"))
	id = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ偟"))[-1]
	headers = { l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ偠") : l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ偡") }
	payload = { l1l111_l1_ (u"ࠧ࡯ࡤࠣ偢"):id , l1l111_l1_ (u"ࠨ࡯ࡱࠤ偣"):l1l111_l1_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠥ偤") }
	request = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭健"), url, payload, headers, l1l111_l1_ (u"ࠩࠪ偦"),l1l111_l1_ (u"ࠪࠫ偧"),l1l111_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧ偨"))
	if l1l111_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ偩") in list(request.headers.keys()): l1ll1ll_l1_ = request.headers[l1l111_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ偪")]
	else: l1ll1ll_l1_ = url
	if l1ll1ll_l1_: return l1l111_l1_ (u"ࠧࠨ偫"),[l1l111_l1_ (u"ࠨࠩ偬")],[l1ll1ll_l1_]
	else: return l1l111_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡖ࠴ࡖࡒࡏࡓࡆࡊࠧ偭"),[],[]
def l11ll11ll1ll_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠪࠫ偮"),l1l111_l1_ (u"ࠫࠬ偯"),l1l111_l1_ (u"ࠬ࠭偰"),l1l111_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡍࡓ࡚ࡖࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ偱"))
	items = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲ࠷࠾ࠥࡢ࡛࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ偲"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠨࠩ偳"),[l1l111_l1_ (u"ࠩࠪ側")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠨ偵"),[],[]
def l11ll1ll1111_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠫࠬ偶"),l1l111_l1_ (u"ࠬ࠭偷"),l1l111_l1_ (u"࠭ࠧ偸"),l1l111_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡉࡈࡊࡘࡈ࠱࠶ࡹࡴࠨ偹"))
	items = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭偺"),html,re.DOTALL)
	if items:
		url = url = l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨ偻") + items[0]
		return l1l111_l1_ (u"ࠪࠫ偼"),[l1l111_l1_ (u"ࠫࠬ偽")],[ url ]
	else: return l1l111_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨ偾"),[],[]
def l1l11l111ll1_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"࠭ࠧ偿"),l1l111_l1_ (u"ࠧࠨ傀"),l1l111_l1_ (u"ࠨࠩ傁"),l1l111_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡕࡃࡎࡌࡇ࡛ࡏࡄࡆࡑࡋࡓࡘ࡚࠭࠲ࡵࡷࠫ傂"))
	items = re.findall(l1l111_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ傃"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠫࠬ傄"),[l1l111_l1_ (u"ࠬ࠭傅")],[ items[0] ]
	else: return l1l111_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖࠪ傆"),[],[]
def l11ll1lll11l_l1_(url):
	html = l1l1llll_l1_(l111l11l_l1_,url,l1l111_l1_ (u"ࠧࠨ傇"),l1l111_l1_ (u"ࠨࠩ傈"),l1l111_l1_ (u"ࠩࠪ傉"),l1l111_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ傊"))
	items = re.findall(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ傋"),html,re.DOTALL)
	if items: return l1l111_l1_ (u"ࠬ࠭傌"),[l1l111_l1_ (u"࠭ࠧ傍")],[ items[0] ]
	else: return l1l111_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡗ࡙ࡘࡅࡂࡏࠪ傎"),[],[]
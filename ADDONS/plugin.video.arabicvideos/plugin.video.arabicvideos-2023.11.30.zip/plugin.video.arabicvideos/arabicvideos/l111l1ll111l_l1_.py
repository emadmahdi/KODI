# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ庇")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ庈")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = ITEMS(url,text,l1llllll1_l1_)
	elif mode==145: l1lll_l1_ = l111ll1llll1_l1_(url)
	elif mode==146: l1lll_l1_ = l111l1l1l111_l1_(url)
	elif mode==147: l1lll_l1_ = l111ll11llll_l1_()
	elif mode==148: l1lll_l1_ = l111ll1l111l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ庉"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ床"),l1l111_l1_ (u"ࠫࠬ庋"),149,l1l111_l1_ (u"ࠬ࠭庌"),l1l111_l1_ (u"࠭ࠧ庍"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ庎"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ序"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ庐")+l1l111_l1_ (u"ࠪࡣ࡞࡚ࡃࡠࠩ庑")+l1l111_l1_ (u"๊ࠫ๎วใ฻ࠣหำะวา้สࠤฬ๊ๅษำ่ะࠬ庒"),l1l111_l1_ (u"ࠬ࠭库"),290)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭应"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ底")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็๋ห็฿ࠠศะอหึํวࠡ์๋ฮ๏๎ศࠨ庖"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ店"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ庘"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭庙")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ庚"),l111l1_l1_,144,l1l111_l1_ (u"࠭ࠧ庛"),l1l111_l1_ (u"ࠧࠨ府"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ庝"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ庞"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ废")+l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ๅฮฬ๋ํࠥอไาษษะࠬ庠"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡹࡸࡥ࡯ࡦ࡬ࡲ࡬࠭庡"),146)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ庢"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ庣"),l1l111_l1_ (u"ࠨࠩ庤"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ庥"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ度")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻ࠢๅ๊ํอสࠡ฻ิฬ๏ฯࠧ座"),l1l111_l1_ (u"ࠬ࠭庨"),147)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭庩"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ庪")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦโ็๊สฮࠥษฬ็สํอࠬ庫"),l1l111_l1_ (u"ࠩࠪ庬"),148)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ庭"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭庮")+l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ庯"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ庰"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ庱"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ庲")+l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠศใ็ห๊ࠦวอ่ห๎ฮ࠭庳"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡲࡵࡶࡪࡧࠪ庴"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ庵"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ庶")+l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤู๊ัฮ์สฮࠥ฿ัษ์ฬࠫ康"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾็ึีา๐ษࠨ庸"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ庹"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ庺")+l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ庻"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ庼"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ庽"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ庾")+l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭庿"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ廀"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ廁"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ廂")+l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ็ฬืส้่ࠪ廃"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃใศำอ์๋ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ廄"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭廅"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ廆")+l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦฮุสฬࠤฬ๊ๅาฮ฼๎ฮ࠭廇"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๆ๋อษࠬๅิฬ้อมࠬษ็ๅ฻อฦ๋ห࠮า฼ฮษࠬษ็ะ๊฿ษࠧࡵࡳࡁࡈࡇࡉࡔࡃ࡫ࡅࡇ࠭廈"),144)
	return
def l111ll11llll_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭หฯࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ廉"))
	return
def l111ll1l111l_l1_():
	ITEMS(l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡺࡶࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭廊"))
	return
def PLAY(url,type):
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111l1l1l111_l1_(url):
	html,l1lllll1ll_l1_,data = l111ll11l1ll_l1_(url)
	dd = l1lllll1ll_l1_[l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ廋")][l1l111_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡄࡵࡳࡼࡹࡥࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ廌")][l1l111_l1_ (u"ࠧࡵࡣࡥࡷࠬ廍")]
	for l1l11l111l_l1_ in range(len(dd)):
		item = dd[l1l11l111l_l1_]
		l111l1lll1ll_l1_(item,url,str(l1l11l111l_l1_))
	l111l1l1llll_l1_ = dd[0][l1l111_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廎")][l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ廏")][l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ廐")][l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭廑")]
	s = 0
	for l1l11l111l_l1_ in range(len(l111l1l1llll_l1_)):
		item = l111l1l1llll_l1_[l1l11l111l_l1_][l1l111_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫ廒")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ廓")][0]
		if list(item[l1l111_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ廔")][l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ廕")].keys())[0]==l1l111_l1_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ廖"): continue
		succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_ = l111lll111l1_l1_(item)
		if not title:
			s += 1
			title = l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥืววฮฬࠤࠬ廗")+str(s)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廘"),l1lllll_l1_+title,url,144,l1l111_l1_ (u"ࠬ࠭廙"),str(l1l11l111l_l1_))
	key = re.findall(l1l111_l1_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ廚"),html,re.DOTALL)
	l1lllll1_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ廛")+key[0]
	html,l1lllll1ll_l1_,l1l11llll_l1_ = l111ll11l1ll_l1_(l1lllll1_l1_)
	for l1lll11lll1l_l1_ in range(3,4):
		dd = l1lllll1ll_l1_[l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ廜")][l1lll11lll1l_l1_][l1l111_l1_ (u"ࠩࡪࡹ࡮ࡪࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ廝")][l1l111_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ廞")]
		for l1l11l111l_l1_ in range(len(dd)):
			item = dd[l1l11l111l_l1_]
			if l1l111_l1_ (u"ࠫ࡞ࡵࡵࡕࡷࡥࡩࠥࡖࡲࡦ࡯࡬ࡹࡲ࠭廟") in str(item): continue
			l111l1lll1ll_l1_(item)
	return
def ITEMS(url,data=l1l111_l1_ (u"ࠬ࠭廠"),index=0):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ廡"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ廢"),l1l111_l1_ (u"ࠨࠩ廣"))
	html,l1lllll1ll_l1_,l1l11llll_l1_ = l111ll11l1ll_l1_(url,data)
	l1l11lll1l_l1_,l111l1l11ll1_l1_ = l1l111_l1_ (u"ࠩࠪ廤"),l1l111_l1_ (u"ࠪࠫ廥")
	owner = re.findall(l1l111_l1_ (u"ࠫࠧࡵࡷ࡯ࡧࡵࡒࡦࡳࡥࠣ࠰࠭ࡃࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ廦"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"ࠬࠨࡶࡪࡦࡨࡳࡔࡽ࡮ࡦࡴࠥ࠲࠯ࡅࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ廧"),html,re.DOTALL)
	if not owner: owner = re.findall(l1l111_l1_ (u"࠭ࠢࡤࡪࡤࡲࡳ࡫࡬ࡎࡧࡷࡥࡩࡧࡴࡢࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡴࡽ࡮ࡦࡴࡘࡶࡱࡹࠢ࠻࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫ廨"),html,re.DOTALL)
	if owner:
		l1l11lll1l_l1_ = l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ廩")+owner[0][0]+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ廪")
		l1ll1ll_l1_ = owner[0][1]
		if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ廫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠩ廬") in url: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ廭"),l1lllll_l1_+l1l11lll1l_l1_,l1ll1ll_l1_,144)
	l111l1l1ll11_l1_ = [l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠭廮"),l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ廯"),l1l111_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ廰"),l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ廱"),l1l111_l1_ (u"ࠩ࠲ࡪࡪࡧࡴࡶࡴࡨࡨࠬ廲"),l1l111_l1_ (u"ࠪࡷࡸࡃࠧ廳"),l1l111_l1_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ廴"),l1l111_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ廵"),l1l111_l1_ (u"࠭ࡢࡱ࠿ࠪ延"),l1l111_l1_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ廷")]
	l111l1l11l1l_l1_ = not any(value in url for value in l111l1l1ll11_l1_)
	if l111l1l11l1l_l1_ and l1l11lll1l_l1_:
		l1l11l1ll_l1_ = l1l111_l1_ (u"ࠨษ็ฬาัࠧ廸")
		l1lllllll_l1_ = l1l111_l1_ (u"ࠩๅ์ฬฬๅࠡษ็ฮูเ๊ๅࠩ廹")
		l1l11l1l1_l1_ = l1l111_l1_ (u"ࠪห้็๊ะ์๋๋ฬะࠧ建")
		l111l1l11lll_l1_ = l1l111_l1_ (u"ࠫฬ๊โ็๊สฮࠬ廻")
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ廼"),l1lllll_l1_+l1l11lll1l_l1_,url,9999)
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣสะฯࠧ࠭廽") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ廾"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠨࠩ廿"),l1l111_l1_ (u"ࠩࠪ开"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ弁"))
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ异") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弃"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ弄"),144)
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่ๆ๐ฯ๋๊๊หฯࠨࠧ弅") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弆"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ弇"),144)
		if l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ弈") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弉"),l1lllll_l1_+l111l1l11lll_l1_,url+l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ弊"),144)
		if l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡕࡨࡥࡷࡩࡨࠣࠩ弋") in html: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ弌"),l1lllll_l1_+l1l11l1ll_l1_,url,145,l1l111_l1_ (u"ࠨࠩ弍"),l1l111_l1_ (u"ࠩࠪ弎"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ式"))
		if l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠤࠪ弐") in html: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弑"),l1lllll_l1_+l1lllllll_l1_,url+l1l111_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ弒"),144)
		if l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ弓") in html: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弔"),l1lllll_l1_+l1l11l1l1_l1_,url+l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ引"),144)
		if l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡉࡨࡢࡰࡱࡩࡱࡹࠢࠨ弖") in html: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弗"),l1lllll_l1_+l111l1l11lll_l1_,url+l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲࡳࠨ弘"),144)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ弙"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ弚"),l1l111_l1_ (u"ࠨࠩ弛"),9999)
	if l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹࠨ弜") in url:
		dd = l1lllll1ll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ弝")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡓࡦࡣࡵࡧ࡭ࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弞")][l1l111_l1_ (u"ࠬࡶࡲࡪ࡯ࡤࡶࡾࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ弟")][l1l111_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ张")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ弡")]
		l111l1l111ll_l1_ = 0
		for i in range(len(dd)):
			if l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弢") in list(dd[i].keys()):
				l111l1l111l1_l1_ = dd[i][l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ弣")]
				length = len(str(l111l1l111l1_l1_))
				if length>l111l1l111ll_l1_:
					l111l1l111ll_l1_ = length
					l111l1l11ll1_l1_ = l111l1l111l1_l1_
		if l111l1l111ll_l1_==0: return
	elif l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ弤") in url or l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡱࡥࡺ࠿ࠪ弥") in url or l1l111_l1_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡅ࡫ࡦࡻࡀࠫ弦") in url or l1l111_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ弧") in url or l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ弨") in url or url==l111l1_l1_:
		l111l1lll1l1_l1_ = []
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡆࡳࡲࡳࡡ࡯ࡦࡶࠫࡢࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ弩"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡥࡵࡶࡥ࡯ࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡇࡣࡵ࡫ࡲࡲࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬࡣࠢ弪"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ弫"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ弬"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡩࡣ࡜࠳ࡠ࡟ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ࡟ࠥ弭"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠮࠳ࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡦࡨ࡬ࡦࡖࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ弮"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝ࠣ弯"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡝ࡡࡵࡥ࡫ࡒࡪࡾࡴࡓࡧࡶࡹࡱࡺࡳࠨ࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭࡝࡜ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࠫࡢࠨ弰"))
		l111l1l1l1ll_l1_,l111l1l11ll1_l1_ = l111l1l1111l_l1_(l1lllll1ll_l1_,l1l111_l1_ (u"ࠩࠪ弱"),l111l1lll1l1_l1_)
	if not l111l1l11ll1_l1_:
		try:
			dd = l1lllll1ll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ弲")][l1l111_l1_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弳")][l1l111_l1_ (u"ࠬࡺࡡࡣࡵࠪ弴")]
			l1lll1lll1l1_l1_ = l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ張") in url or l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ弶") in url or l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ強") in url
			l111l1ll1l11_l1_ = l1l111_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠣࠩ弸") in html or l1l111_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭弹") in html or l1l111_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨวๅไ้์ฬะࠢࠨ强") in html
			l111l1ll11ll_l1_ = l1l111_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡗ࡫ࡧࡩࡴࡹࠢࠨ弻") in html or l1l111_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶࡶࠦࠬ弼") in html or l1l111_l1_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠦࠬ弽") in html
			if l1lll1lll1l1_l1_ and (l111l1ll1l11_l1_ or l111l1ll11ll_l1_):
				for l1l11l111l_l1_ in range(len(dd)):
					if l1l111_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭弾") not in list(dd[l1l11l111l_l1_].keys()): continue
					l111l1l1llll_l1_ = dd[l1l11l111l_l1_][l1l111_l1_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ弿")]
					try: l111l1l1l1l1_l1_ = l111l1l1llll_l1_[l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫ彀")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彁")][l1l111_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭彂")][l1l111_l1_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彃")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡕࡻࡳࡩࡘࡻࡢࡎࡧࡱࡹࡎࡺࡥ࡮ࡵࠪ彄")][l1l11l111l_l1_]
					except: l111l1l1l1l1_l1_ = l111l1l1llll_l1_
					try: l1ll1ll_l1_ = l111l1l1l1l1_l1_[l1l111_l1_ (u"ࠨࡧࡱࡨࡵࡵࡩ࡯ࡶࠪ彅")][l1l111_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ彆")][l1l111_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ彇")][l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ彈")]
					except: continue
					if   l1l111_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭彉")		in l1ll1ll_l1_	and l1l111_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ彊")		in url: l111l1l1llll_l1_ = dd[l1l11l111l_l1_] ; break
					elif l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ彋")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ彌")	in url: l111l1l1llll_l1_ = dd[l1l11l111l_l1_] ; break
					elif l1l111_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ彍")	in l1ll1ll_l1_	and l1l111_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭彎")		in url: l111l1l1llll_l1_ = dd[l1l11l111l_l1_] ; break
					else: l111l1l1llll_l1_ = dd[0]
			elif l1l111_l1_ (u"ࠫࡧࡶ࠽ࠨ彏") in url: l111l1l1llll_l1_ = dd[index]
			else: l111l1l1llll_l1_ = dd[0]
			l111l1l11ll1_l1_ = l111l1l1llll_l1_[l1l111_l1_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彐")][l1l111_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ彑")]
		except: pass
	if not l111l1l11ll1_l1_: return
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ归"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ当"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ彔"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ录"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ彖"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ彗"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ彘"))
	if l1l111_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭彙") not in url: l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡴࡷࡥࡑࡪࡴࡵࠨ࡟࡞ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡗࡽࡵ࡫ࡓࡶࡤࡐࡩࡳࡻࡉࡵࡧࡰࡷࠬࡣࠢ彚"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡫ࡸࡱࡣࡱࡨࡪࡪࡓࡩࡧ࡯ࡪࡈࡵ࡮ࡵࡧࡱࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ彛"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ彜"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ彝"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡩࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ彞"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ彟"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࠧ彠"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡨࡩ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ彡"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡩࡪࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ形"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡪ࡫ࠨ彣"))
	l11l1111lll_l1_ = l111l1l1l11_l1_(l1l111_l1_ (u"ࡹ้ࠬไࠡไ๋หห๋ࠠศๆอุ฿๐ไࠨ彤"))
	l11l111l111_l1_ = l111l1l1l11_l1_(l1l111_l1_ (u"ࡺ࠭ใๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭彥"))
	l111l1l1l11l_l1_ = l111l1l1l11_l1_(l1l111_l1_ (u"ࡻࠧไๆࠣห้่ๆ้ษอࠫ彦"))
	l1l11ll11lll_l1_ = [l11l1111lll_l1_,l11l111l111_l1_,l111l1l1l11l_l1_,l1l111_l1_ (u"ࠧࡂ࡮࡯ࠤࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ彧"),l1l111_l1_ (u"ࠨࡃ࡯ࡰࠥࡼࡩࡥࡧࡲࡷࠬ彨"),l1l111_l1_ (u"ࠩࡄࡰࡱࠦࡣࡩࡣࡱࡲࡪࡲࡳࠨ彩")]
	l111l1l1ll1l_l1_,l111l1l1l1l1_l1_ = l111l1l1111l_l1_(l111l1l11ll1_l1_,index,l111l1lll1l1_l1_)
	if l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ彪") in str(type(l111l1l1l1l1_l1_)) and any(value in str(l111l1l1l1l1_l1_[0]) for value in l1l11ll11lll_l1_): del l111l1l1l1l1_l1_[0]
	for index2 in range(len(l111l1l1l1l1_l1_)):
		l111l1lll1l1_l1_ = []
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡅࡤࡶࡩࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞ࠤ彫"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ彬"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ彭"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣࠢ彮"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ彯"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ彰"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡩࡤࡱࡪࡉࡡࡳࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡨࡣࡰࡩࠬࡣࠢ影"))
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝ࠣ彲"))
		l111l1l1l1ll_l1_,item = l111l1l1111l_l1_(l111l1l1l1l1_l1_,index2,l111l1lll1l1_l1_)
		l111l1lll1ll_l1_(item,url,str(index2))
		if l111l1l1l1ll_l1_==l1l111_l1_ (u"ࠬ࠺ࠧ彳"):
			try:
				hh = item[l1l111_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭彴")][l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ彵")][l1l111_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ彶")][l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ彷")]
				for l111ll1111ll_l1_ in range(len(hh)):
					l1l11llll11l_l1_ = hh[l111ll1111ll_l1_]
					l111l1lll1ll_l1_(l1l11llll11l_l1_)
			except: pass
	l111l1l11l_l1_ = False
	if l1l111_l1_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ彸") not in url and l111l1l1ll1l_l1_==l1l111_l1_ (u"ࠫ࠽࠭役"): l111l1l11l_l1_ = True
	if l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ彺") in l1l11llll_l1_: l111ll1l1l1l_l1_,key,l111l1l11l11_l1_,l111ll1l1111_l1_,token,l111ll11ll1l_l1_ = l1l11llll_l1_.split(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ彻"))
	else: l111ll1l1l1l_l1_,key,l111l1l11l11_l1_,l111ll1l1111_l1_,token,l111ll11ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ彼"),l1l111_l1_ (u"ࠨࠩ彽"),l1l111_l1_ (u"ࠩࠪ彾"),l1l111_l1_ (u"ࠪࠫ彿"),l1l111_l1_ (u"ࠫࠬ往"),l1l111_l1_ (u"ࠬ࠭征")
	l1lllll1_l1_,l1111ll11l_l1_ = l1l111_l1_ (u"࠭ࠧ徂"),l1l111_l1_ (u"ࠧࠨ徃")
	if menuItemsLIST:
		l111l1ll11l1_l1_ = str(menuItemsLIST[-1][1])
		if   l1lllll_l1_+l1l111_l1_ (u"ࠨࡅࡋࡒࡑ࠭径") in l111l1ll11l1_l1_: l1111ll11l_l1_ = l1l111_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ待")
		elif l1lllll_l1_+l1l111_l1_ (u"࡙ࠪࡘࡋࡒࠨ徆") in l111l1ll11l1_l1_: l1111ll11l_l1_ = l1l111_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭徇")
		elif l1lllll_l1_+l1l111_l1_ (u"ࠬࡒࡉࡔࡖࠪ很") in l111l1ll11l1_l1_: l1111ll11l_l1_ = l1l111_l1_ (u"࠭ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ徉")
	if l1l111_l1_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ徊") in html and l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ律") not in url and not l111l1l11l_l1_ and l1l111_l1_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ後") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ徍")+l111l1l11l11_l1_
	elif l1l111_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ徎") in html and l1l111_l1_ (u"ࠬࡨࡰ࠾ࠩ徏") not in url and l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ徐") in url or l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ徑") in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ徒")+key
	elif l1l111_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ従") in html and l1l111_l1_ (u"ࠪࡦࡵࡃࠧ徔") not in url:
		l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ徕")+key
	if l1lllll1_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ徖"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ得"),l1lllll1_l1_,144,l1111ll11l_l1_,l1l111_l1_ (u"ࠧࠨ徘"),l1l11llll_l1_)
	return
def l111l1l1111l_l1_(l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_,l111ll111111_l1_):
	l1lllll1ll_l1_ = l1l1l11l1l1l_l1_
	l111l1l11ll1_l1_,index = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	l111l1l1l1l1_l1_,index2 = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	item,l111l1ll1111_l1_ = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	count = len(l111ll111111_l1_)
	for l1l11l111l_l1_ in range(count):
		try:
			out = eval(l111ll111111_l1_[l1l11l111l_l1_])
			return str(l1l11l111l_l1_+1),out
		except: pass
	return l1l111_l1_ (u"ࠨࠩ徙"),l1l111_l1_ (u"ࠩࠪ徚")
def l111lll111l1_l1_(item):
	try: l111ll11lll1_l1_ = list(item.keys())[0]
	except: return False,l1l111_l1_ (u"ࠪࠫ徛"),l1l111_l1_ (u"ࠫࠬ徜"),l1l111_l1_ (u"ࠬ࠭徝"),l1l111_l1_ (u"࠭ࠧ從"),l1l111_l1_ (u"ࠧࠨ徟"),l1l111_l1_ (u"ࠨࠩ徠"),l1l111_l1_ (u"ࠩࠪ御")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_ = False,l1l111_l1_ (u"ࠪࠫ徢"),l1l111_l1_ (u"ࠫࠬ徣"),l1l111_l1_ (u"ࠬ࠭徤"),l1l111_l1_ (u"࠭ࠧ徥"),l1l111_l1_ (u"ࠧࠨ徦"),l1l111_l1_ (u"ࠨࠩ徧"),l1l111_l1_ (u"ࠩࠪ徨")
	l111l1ll1111_l1_ = item[l111ll11lll1_l1_]
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡺࡴࡰ࡭ࡣࡼࡥࡧࡲࡥࡕࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ復"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡬࡯ࡳ࡯ࡤࡸࡹ࡫ࡤࡕ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ循"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ徫"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ徬"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ徭"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ微"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠࠦ徯"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ徰"))
	l111l1l1l1ll_l1_,title = l111l1l1111l_l1_(item,l111l1ll1111_l1_,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ徱"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ徲"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ徳"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ徴"))
	l111l1l1l1ll_l1_,l1ll1ll_l1_ = l111l1l1111l_l1_(item,l111l1ll1111_l1_,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ徵"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ徶"))
	l111l1l1l1ll_l1_,l1ll1l_l1_ = l111l1l1111l_l1_(item,l111l1ll1111_l1_,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡻ࡯ࡤࡦࡱࡆࡳࡺࡴࡴࠨ࡟ࠥ德"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡼࡩࡥࡧࡲࡇࡴࡻ࡮ࡵࡖࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ徸"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡇࡵࡴࡵࡱࡰࡔࡦࡴࡥ࡭ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ徹"))
	l111l1l1l1ll_l1_,count = l111l1l1111l_l1_(item,l111l1ll1111_l1_,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧ࡭ࡧࡱ࡫ࡹ࡮ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ徺"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ徻"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡕ࡫ࡰࡩࡘࡺࡡࡵࡷࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ徼"))
	l111l1l1l1ll_l1_,l1l1llll11_l1_ = l111l1l1111l_l1_(item,l111l1ll1111_l1_,l111l1lll1l1_l1_)
	if l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ徽") in l1l1llll11_l1_: l1l1llll11_l1_,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠪࠫ徾"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ徿")
	if l1l111_l1_ (u"๋ࠬศศึิࠫ忀") in l1l1llll11_l1_: l1l1llll11_l1_,l111ll1l1lll_l1_ = l1l111_l1_ (u"࠭ࠧ忁"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ忂")
	if l1l111_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ心") in list(l111l1ll1111_l1_.keys()):
		l111ll1ll1ll_l1_ = str(l111l1ll1111_l1_[l1l111_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ忄")])
		if l1l111_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ必") in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠫࠩࡀࠧ忆")
		if l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠣࡒࡔ࡝ࠧ忇") in l111ll1ll1ll_l1_: l111ll1l1lll_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ忈")
		if l1l111_l1_ (u"ࠧࡃࡷࡼࠫ忉") in l111ll1ll1ll_l1_ or l1l111_l1_ (u"ࠨࡔࡨࡲࡹ࠭忊") in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿࠭忋")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡸ๊ࠫฮวีำࠪ忌")) in l111ll1ll1ll_l1_: l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ忍")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡺ࠭ิาษฤࠫ忎")) in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"࠭ࠤࠥ࠼ࠪ忏")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡵࠨษึฮหาวาࠩ忐")) in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠬ忑")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ忒")) in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠪࠨ࠿࠭忓")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ忔") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠬࡅࠧ忕"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ忖") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ志")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111ll11ll11_l1_: title = l111ll11ll11_l1_+l1l111_l1_ (u"ࠨࠢࠣࠫ忘")+title
	l1l1llll11_l1_ = l1l1llll11_l1_.replace(l1l111_l1_ (u"ࠩ࠯ࠫ忙"),l1l111_l1_ (u"ࠪࠫ忚"))
	count = count.replace(l1l111_l1_ (u"ࠫ࠱࠭忛"),l1l111_l1_ (u"ࠬ࠭応"))
	count = re.findall(l1l111_l1_ (u"࠭࡜ࡥ࠭ࠪ忝"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"ࠧࠨ忞")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_
def l111l1lll1ll_l1_(item,url=l1l111_l1_ (u"ࠨࠩ忟"),index=l1l111_l1_ (u"ࠩࠪ忠")):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_ = l111lll111l1_l1_(item)
	if not succeeded: return
	elif l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忡") in str(item): return
	elif l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡔࡾࡼࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ忢") in str(item): return
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ忣") in url: return
	elif title and not l1ll1ll_l1_ and (l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ忤") in url or l1l111_l1_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忥") in str(item) or url==l111l1_l1_):
		title = l1l111_l1_ (u"ࠨ࠿ࡀࡁࠥ࠭忦")+title+l1l111_l1_ (u"ࠩࠣࡁࡂࡃࠧ忧")
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ忨"),l1lllll_l1_+title,l1l111_l1_ (u"ࠫࠬ忩"),9999)
	elif title and l1l111_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忪") in str(item):
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ快"),l1lllll_l1_+title,l1l111_l1_ (u"ࠧࠨ忬"),9999)
	elif l1l111_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ忭") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ忮"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l111ll1l1lll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ忯"),l1lllll_l1_+l111ll1l1lll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭忰") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ忱") in l1ll1ll_l1_:
		if l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭忲") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡪࡰࡧࡩࡽࡃࠧ忳") not in l1ll1ll_l1_:
			l111ll1l11ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ忴"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ念")+l111ll1l11ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ忶"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡑࡏࡓࡕࠩ忷")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ忸")+title,l1ll1ll_l1_,144,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"࠭ࠦ࡭࡫ࡶࡸࡂ࠭忹"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭忺"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1llll11_l1_)
	else:
		type = l1l111_l1_ (u"ࠨࠩ忻")
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		elif not any(value in l1ll1ll_l1_ for value in [l1l111_l1_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰࡵࠪ忼"),l1l111_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ忽"),l1l111_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ忾"),l1l111_l1_ (u"ࠬ࠵ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ忿"),l1l111_l1_ (u"࠭ࡳࡴ࠿ࠪ怀"),l1l111_l1_ (u"ࠧࡣࡲࡀࠫ态")]):
			if l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲ࠫ怂")	in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡧ࠴࠭怃") in l1ll1ll_l1_: type = l1l111_l1_ (u"ࠪࡇࡍࡔࡌࠨ怄")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ怅")
			if l1l111_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ怆") in l1ll1ll_l1_: type = l1l111_l1_ (u"࠭ࡕࡔࡇࡕࠫ怇")+count+l1l111_l1_ (u"ࠧ࠻ࠢࠣࠫ怈")
			index,l111l1l1lll1_l1_ = l1l111_l1_ (u"ࠨࠩ怉"),l1l111_l1_ (u"ࠩࠪ怊")
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ怋"),l1lllll_l1_+type+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	return
def l111ll11l1ll_l1_(url,data=l1l111_l1_ (u"ࠫࠬ怌"),request=l1l111_l1_ (u"ࠬ࠭怍")):
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"࠭ࡡࡷ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡨࡦࡺࡡࠨ怎"))
	if request==l1l111_l1_ (u"ࠧࠨ怏"): request = l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ怐")
	l11l1l11ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭怑"):l11l1l11ll_l1_,l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ怒"):l1l111_l1_ (u"ࠫࡕࡘࡅࡇ࠿࡫ࡰࡂࡧࡲࠨ怓")}
	if l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ怔") in data: l111ll1l1l1l_l1_,key,l111l1l11l11_l1_,l111ll1l1111_l1_,token,l111ll11ll1l_l1_ = data.split(l1l111_l1_ (u"࠭࠺࠻࠼ࠪ怕"))
	else: l111ll1l1l1l_l1_,key,l111l1l11l11_l1_,l111ll1l1111_l1_,token,l111ll11ll1l_l1_ = l1l111_l1_ (u"ࠧࠨ怖"),l1l111_l1_ (u"ࠨࠩ怗"),l1l111_l1_ (u"ࠩࠪ怘"),l1l111_l1_ (u"ࠪࠫ怙"),l1l111_l1_ (u"ࠫࠬ怚"),l1l111_l1_ (u"ࠬ࠭怛")
	if l1l111_l1_ (u"࠭ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ怜") in url:
		l1l11llll_l1_ = {}
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ思")] = {l1l111_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࠣ怞"):{l1l111_l1_ (u"ࠤ࡫ࡰࠧ怟"):l1l111_l1_ (u"ࠥࡥࡷࠨ怠"),l1l111_l1_ (u"ࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ怡"):l1l111_l1_ (u"ࠧ࡝ࡅࡃࠤ怢"),l1l111_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ怣"):l111ll1l1111_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ怤"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠴ࡷࡹ࠭急"))
	elif l1l111_l1_ (u"ࠩ࡮ࡩࡾࡃࠧ怦") in url and l111ll1l1l1l_l1_:
		l1l11llll_l1_ = {l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩ性"):token}
		l1l11llll_l1_[l1l111_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ怨")] = {l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࠧ怩"):{l1l111_l1_ (u"ࠨࡶࡪࡵ࡬ࡸࡴࡸࡄࡢࡶࡤࠦ怪"):l111ll1l1l1l_l1_,l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠦ怫"):l1l111_l1_ (u"࡙ࠣࡈࡆࠧ怬"),l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠤ怭"):l111ll1l1111_l1_}}
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ怮"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠸࡮ࡥࠩ怯"))
	elif l1l111_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭怰") in url and l111ll11ll1l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯ࡑࡥࡲ࡫ࠧ怱"):l1l111_l1_ (u"ࠧ࠲ࠩ怲"),l1l111_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱࡛࡫ࡲࡴ࡫ࡲࡲࠬ怳"):l111ll1l1111_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ怴"):l1l111_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅ࠾ࠩ怵")+l111ll11ll1l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ怶"),url,l1l111_l1_ (u"ࠬ࠭怷"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ怸"),l1l111_l1_ (u"ࠧࠨ怹"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠶ࡶࡩ࠭怺"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭总"),url,l1l111_l1_ (u"ࠪࠫ怼"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ怽"),l1l111_l1_ (u"ࠬ࠭怾"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠵ࡶ࡫ࠫ怿"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ恀"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡺࡪࡸࠢ࠯ࠬࡂࠦࡻࡧ࡬ࡶࡧࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ恁"),html,re.DOTALL|re.I)
	if tmp: l111ll1l1111_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭恂"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠪࠦࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭恃"),html,re.DOTALL|re.I)
	if tmp: l111ll1l1l1l_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠫࠧࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ恄"),html,re.DOTALL|re.I)
	if tmp: l111l1l11l11_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"ࠬ࡜ࡉࡔࡋࡗࡓࡗࡥࡉࡏࡈࡒ࠵ࡤࡒࡉࡗࡇࠪ恅") in list(cookies.keys()): l111ll11ll1l_l1_ = cookies[l1l111_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ恆")]
	data = l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ恇")+key+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ恈")+l111l1l11l11_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭恉")+l111ll1l1111_l1_+l1l111_l1_ (u"ࠪ࠾࠿ࡀࠧ恊")+token+l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ恋")+l111ll11ll1l_l1_
	if request==l1l111_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ恌") and l1l111_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭恍") in html:
		l11l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡸ࡫ࡱࡨࡴࡽ࡜࡜ࠤࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠤ࡟ࡡࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ恎"),html,re.DOTALL)
		if not l11l1l1111_l1_: l11l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠥࡃࠠࠩࡽ࠱࠮ࡄࢃࠩ࠼ࠩ恏"),html,re.DOTALL)
		l111ll1ll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠩࡶࡸࡷ࠭恐"),l11l1l1111_l1_[0])
	elif request==l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠨ恑") and l1l111_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ恒") in html:
		l11l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡌࡻࡩࡥࡧࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ恓"),html,re.DOTALL)
		l111ll1ll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ恔"),l11l1l1111_l1_[0])
	elif l1l111_l1_ (u"ࠧ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ恕") not in html: l111ll1ll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠨࡵࡷࡶࠬ恖"),html)
	else: l111ll1ll1l1_l1_ = l1l111_l1_ (u"ࠩࠪ恗")
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ恘"),data)
	return html,l111ll1ll1l1_l1_,data
def l111ll1llll1_l1_(url):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭恙"),l1l111_l1_ (u"ࠬ࠱ࠧ恚"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲࡷࡨࡶࡾࡃࠧ恛")+search
	ITEMS(l1lllll1_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ恜"),l1l111_l1_ (u"ࠨ࠭ࠪ恝"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࠫ恞")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࡤ࠭恟") in options: l111ll111l1l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡑࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ恠")
		elif l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫ恡") in options: l111ll111l1l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭恢")
		elif l1l111_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬ恣") in options: l111ll111l1l_l1_ = l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄ࡫ࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ恤")
		l1llllll_l1_ = l1lllll1_l1_+l111ll111l1l_l1_
	else:
		l111ll111l11_l1_,l111l1ll1lll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠩࠪ恥")
		l111l1lll11l_l1_ = [l1l111_l1_ (u"ࠪฬิ๎ๆࠡฬิฮ๏ฮࠧ恦"),l1l111_l1_ (u"ࠫฯืส๋สࠣัุฮࠠๆั์ࠤฬ๊ีๅหࠪ恧"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡฬสี๏ิࠠศๆอั๊๐ไࠨ恨"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢ฼ำิࠦวๅ็ืห์ีวหࠩ恩"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣห้ะโ๋์่ࠫ恪")]
		l111ll1ll11l_l1_ = [l1l111_l1_ (u"ࠨࠩ恫"),l1l111_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡃࠨ࠶࠺࠹ࡄࠨ恬"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡌࠩ࠷࠻࠳ࡅࠩ恭"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡑࠪ࠸࠵࠴ࡆࠪ恮"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡊࠫ࠲࠶࠵ࡇࠫ息")]
		l111ll1lll11_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊สาฬํฬࠬ恰"),l111l1lll11l_l1_)
		if l111ll1lll11_l1_ == -1: return
		l111ll1111l1_l1_ = l111ll1ll11l_l1_[l111ll1lll11_l1_]
		html,c,data = l111ll11l1ll_l1_(l1lllll1_l1_+l111ll1111l1_l1_)
		if c:
			d = c[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ恱")][l1l111_l1_ (u"ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡗࡪࡧࡲࡤࡪࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫ恲")][l1l111_l1_ (u"ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫ恳")][l1l111_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ恴")][l1l111_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ恵")][l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡘࡻࡢࡎࡧࡱࡹࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭恶")][l1l111_l1_ (u"࠭ࡧࡳࡱࡸࡴࡸ࠭恷")]
			for l111l1ll1ll1_l1_ in range(len(d)):
				group = d[l111l1ll1ll1_l1_][l1l111_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡍࡲࡰࡷࡳࡖࡪࡴࡤࡦࡴࡨࡶࠬ恸")][l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ恹")]
				for l111ll1lllll_l1_ in range(len(group)):
					l111l1ll1111_l1_ = group[l111ll1lllll_l1_][l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩ恺")]
					if l1l111_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ恻") in list(l111l1ll1111_l1_.keys()):
						l1ll1ll_l1_ = l111l1ll1111_l1_[l1l111_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ恼")][l1l111_l1_ (u"ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ恽")][l1l111_l1_ (u"࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ恾")][l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ恿")]
						l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞ࡸ࠴࠵࠸࠶ࠨ悀"),l1l111_l1_ (u"ࠩࠩࠫ悁"))
						title = l111l1ll1111_l1_[l1l111_l1_ (u"ࠪࡸࡴࡵ࡬ࡵ࡫ࡳࠫ悂")]
						title = title.replace(l1l111_l1_ (u"ࠫฬ๊ศฮอࠣ฽๋ࠦࠧ悃"),l1l111_l1_ (u"ࠬ࠭悄"))
						if l1l111_l1_ (u"࠭ลำษ็อࠥอไโๆอีࠬ悅") in title: continue
						if l1l111_l1_ (u"ࠧใษษ้ฮࠦสี฼ํ่ࠬ悆") in title:
							title = l1l111_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ悇")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠬ悈") in title: continue
						title = title.replace(l1l111_l1_ (u"ࠪࡗࡪࡧࡲࡤࡪࠣࡪࡴࡸࠠࠨ悉"),l1l111_l1_ (u"ࠫࠬ悊"))
						if l1l111_l1_ (u"ࠬࡘࡥ࡮ࡱࡹࡩࠬ悋") in title: continue
						if l1l111_l1_ (u"࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨ悌") in title:
							title = l1l111_l1_ (u"ࠧอ์าࠤ้๊ๅิๆึ่ฬะࠠࠨ悍")+title
							l1lllllll_l1_ = title
							l111lllll_l1_ = l1ll1ll_l1_
						if l1l111_l1_ (u"ࠨࡕࡲࡶࡹࠦࡢࡺࠩ悎") in title: continue
						l111ll111l11_l1_.append(escapeUNICODE(title))
						l111l1ll1lll_l1_.append(l1ll1ll_l1_)
		if not l1lllllll_l1_: l111ll1ll111_l1_ = l1l111_l1_ (u"ࠩࠪ悏")
		else:
			l111ll111l11_l1_ = [l1l111_l1_ (u"ࠪฬิ๎ๆࠡใ็ฮึ࠭悐"),l1lllllll_l1_]+l111ll111l11_l1_
			l111l1ll1lll_l1_ = [l1l111_l1_ (u"ࠫࠬ悑"),l111lllll_l1_]+l111l1ll1lll_l1_
			l111lll1111l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ࠣ๎ํะ๊้สࠣ࠱ࠥอฮหำࠣห้็ไหำࠪ悒"),l111ll111l11_l1_)
			if l111lll1111l_l1_ == -1: return
			l111ll1ll111_l1_ = l111l1ll1lll_l1_[l111lll1111l_l1_]
		if l111ll1ll111_l1_: l1llllll_l1_ = l111l1_l1_+l111ll1ll111_l1_
		elif l111ll1111l1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1111l1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	ITEMS(l1llllll_l1_)
	return
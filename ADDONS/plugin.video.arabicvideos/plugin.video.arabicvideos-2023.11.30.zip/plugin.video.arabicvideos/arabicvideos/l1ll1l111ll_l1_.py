# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ⵭")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩ⵮")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๊ࠫ฻วา฻ฬࠫⵯ"),l1l111_l1_ (u"ࠬออะอࠣห้ฮัศ็ฯࠫ⵰"),l1l111_l1_ (u"࠭วฮัฮࠤฬ๊วๅ฻สฬࠬ⵱"),l1l111_l1_ (u"ࠧศฯาฯࠥอไศ฼ส๊๎࠭⵲")]
def l11l1ll_l1_(mode,url,text):
	if   mode==80: l1lll_l1_ = l1l1l11_l1_()
	elif mode==81: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==82: l1lll_l1_ = PLAY(url)
	elif mode==83: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==89: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⵳"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ⵴"),l1l111_l1_ (u"ࠪࠫ⵵"),l1l111_l1_ (u"ࠫࠬ⵶"),l1l111_l1_ (u"ࠬ࠭⵷"),l1l111_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⵸"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l111l1_l1_,l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ⵹"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⵺"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⵻"),l1l111_l1_ (u"ࠪࠫ⵼"),89,l1l111_l1_ (u"ࠫࠬ⵽"),l1l111_l1_ (u"ࠬ࠭⵾"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡ⵿ࠪ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⶀ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨⶁ"),l1l111_l1_ (u"ࠩࠪⶂ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡱࡦ࡯࡮࠮ࡥࡲࡲࡹ࡫࡮ࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬⶃ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧⶄ"),block,re.DOTALL)
	for l111l1l1l_l1_,title in items:
		l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࡄ࡯ࡴࡦ࡯ࡀࠫⶅ")+l111l1l1l_l1_+l1l111_l1_ (u"࠭ࠦࡂ࡬ࡤࡼࡂ࠷ࠧⶆ")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶇ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪⶈ")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⶉ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪⶊ"),l1l111_l1_ (u"ࠫࠬⶋ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨ࡮ࡢࡸ࠰ࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡰࡤࡺࡃ࠭ⶌ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬⶍ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠧࠤࠩⶎ"): continue
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶏ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫⶐ")+l1lllll_l1_+title,l1ll1ll_l1_,81)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠪࠫⶑ")):
	items = []
	if l1l111_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࠫⶒ") in url or l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ⶓ") in url:
		l1lllll1_l1_,l1l11llll_l1_ = l1ll11ll1_l1_(url)
		l1ll1ll1l_l1_ = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬⶔ"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧⶕ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭ⶖ"),l1lllll1_l1_,l1l11llll_l1_,l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ⶗"),l1l111_l1_ (u"ࠪࠫ⶘"),l1l111_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⶙"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ⶚"),url,l1l111_l1_ (u"࠭ࠧ⶛"),l1l111_l1_ (u"ࠧࠨ⶜"),l1l111_l1_ (u"ࠨࠩ⶝"),l1l111_l1_ (u"ࠩࠪ⶞"),l1l111_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ⶟"))
		html = response.content
		if l111l1l1l_l1_==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ⶠ"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠬⶡ"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⶢ"),block,re.DOTALL)
		elif l1l111_l1_ (u"ࠧࠣࡵࡨࡧࡹ࡯࡯࡯࠯ࡳࡳࡸࡺࠠ࡮ࡤ࠰࠵࠵ࠨࠧⶣ") in html:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡨࡺࡩࡰࡰ࠰ࡴࡴࡹࡴࠡ࡯ࡥ࠱࠶࠶ࠢࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪⶤ"),html,re.DOTALL)
		else:
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠧⶥ"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items:
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦࠬⶦ"),block,re.DOTALL)
		if not items: items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⶧"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬⶨ"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫⶩ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭ⶪ"),l1l111_l1_ (u"ࠨๅ็๎อ࠭ⶫ"),l1l111_l1_ (u"ࠩส฽้อๆࠨⶬ"),l1l111_l1_ (u"๋ࠪิอแࠨⶭ"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫⶮ"),l1l111_l1_ (u"ࠬ฿ัืࠩ⶯"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭ⶰ"),l1l111_l1_ (u"ࠧศๆห์๊࠭ⶱ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠨ࠱ࠪⶲ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬⶳ"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬⶴ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶵ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
		elif l1l111_l1_ (u"ูࠬไศี็ࠫⶶ") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⶷"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠧศๆะ่็ฯࠧⶸ") in title:
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧⶹ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶺ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬⶻ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⶼ"),l1lllll_l1_+title,l1ll1ll_l1_,81,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶽ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	if l111l1l1l_l1_==l1l111_l1_ (u"࠭ࠧⶾ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࠫ⶿"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪⷀ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠤࠥⷁ"): continue
				if title!=l1l111_l1_ (u"ࠪࠫⷂ"): addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷃ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫⷄ")+title,l1ll1ll_l1_,81)
	if l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭ⷅ") in url or l1l111_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨⷆ") in url:
		if l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡍࡹ࡫࡭ࠨ⷇") in url:
			url = url.replace(l1l111_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡩࡨࡸࡎࡺࡥ࡮ࠩⷈ"),l1l111_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱࡯ࡳࡦࡪࡍࡰࡴࡨࠫⷉ"))+l1l111_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠸࠰ࠨⷊ")
		elif l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡱࡵࡡࡥࡏࡲࡶࡪ࠭ⷋ") in url:
			url,offset = url.split(l1l111_l1_ (u"࠭ࠦࡰࡨࡩࡷࡪࡺ࠽ࠨⷌ"))
			offset = int(offset)+20
			url = url+l1l111_l1_ (u"ࠧࠧࡱࡩࡪࡸ࡫ࡴ࠾ࠩⷍ")+str(offset)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷎ"),l1lllll_l1_+l1l111_l1_ (u"๊๊ࠩฬ้ࠠศๆ่ึ๏ีࠧ⷏"),url,81)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧⷐ"),url,l1l111_l1_ (u"ࠫࠬⷑ"),l1l111_l1_ (u"ࠬ࠭ⷒ"),l1l111_l1_ (u"࠭ࠧⷓ"),l1l111_l1_ (u"ࠧࠨⷔ"),l1l111_l1_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩⷕ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࡂࡺࡕࡨࡶ࡮࡫ࡳࠩ࠰࠭ࡃ࠮ࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠪⷖ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡱ࡯ࡳࡵ࠯ࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⷗"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭ⷘ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⷙ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷚ"),l1lllll_l1_+title,l1ll1ll_l1_,83,l1ll1l_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡰࡥ࡬࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ⷛ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧⷜ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨⷝ"),l1lllll_l1_+title,l1ll1ll_l1_,82,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬⷞ"),l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡲࡵࡶࡪࡧࡶ࠳ࠬ⷟"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩⷠ"),l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩⷡ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫⷢ"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩⷣ"),l1l111_l1_ (u"ࠩࠪⷤ"),l1l111_l1_ (u"ࠪࠫⷥ"),l1l111_l1_ (u"ࠫࠬⷦ"),l1l111_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩⷧ"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪⷨ"))
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ⷩ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫⷪ"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠤࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤⷫ"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭ⷬ"),l1l111_l1_ (u"ࠫࠬⷭ")).strip(l1l111_l1_ (u"ࠬࠦࠧⷮ"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩⷯ")+server+l1l111_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩⷰ")+l11l1l11_l1_+l1l111_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩⷱ")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪⷲ")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫⷳ")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨⷴ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫⷵ"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧⷶ")+name+l1l111_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫⷷ")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧⷸ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠩࠪⷹ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠪࠫⷺ"): return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭ⷻ"),l1l111_l1_ (u"ࠬ࠳ࠧⷼ"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨⷽ")+search+l1l111_l1_ (u"ࠧ࠯ࡪࡷࡱࡱ࠭ⷾ")
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧᡶ")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡃࡎࡎࡢࠫᡷ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"࠭โ็๊สฮࠥ็ึศศํอࠬᡸ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==470: l1lll_l1_ = l1l1l11_l1_()
	elif mode==471: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==472: l1lll_l1_ = PLAY(url)
	elif mode==473: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==474: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==479: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ᡹"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ᡺"),l1l111_l1_ (u"ࠩࠪ᡻"),l1l111_l1_ (u"ࠪࠫ᡼"),l1l111_l1_ (u"ࠫࠬ᡽"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ᡾"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᡿"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠧ࠰ࠩᢀ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᢁ"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᢂ"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᢃ"),l1l111_l1_ (u"ࠫࠬᢄ"),479,l1l111_l1_ (u"ࠬ࠭ᢅ"),l1l111_l1_ (u"࠭ࠧᢆ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᢇ"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᢈ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᢉ"),l1l111_l1_ (u"ࠪࠫᢊ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢋ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᢌ")+l1lllll_l1_+l1l111_l1_ (u"࠭รโๆส้๋ࠥๅ๋ิฬࠫᢍ"),l1l11ll_l1_,471,l1l111_l1_ (u"ࠧࠨᢎ"),l1l111_l1_ (u"ࠨࠩᢏ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡲࡵࡶࡪࡧࡶࠫᢐ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᢑ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩᢒ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠬࠦࠠࠨᢓ"),l1l111_l1_ (u"࠭ࠧᢔ")).strip(l1l111_l1_ (u"ࠧࠡࠩᢕ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨࡥࡤࡸࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠶࠭ᢖ"),l1l111_l1_ (u"ࠩࡦࡥࡹࡃ࡯࡯࡮࡬ࡲࡪ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ᢗ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᢘ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᢙ")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᢚ"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᢛ"),l1l111_l1_ (u"ࠧࠨᢜ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬᢝ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢᢞ"),html,re.DOTALL)
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᢟ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫᢠ") in title: continue
		if l1l111_l1_ (u"ࠬฮั็ษ่ะࠥ࠭ᢡ") in title: continue
		if l1l111_l1_ (u"࠭ไๅๅหหึ࠭ᢢ") in title: continue
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᢣ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᢤ")+l1lllll_l1_+title,l1ll1ll_l1_,474)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᢥ"),url,l1l111_l1_ (u"ࠪࠫᢦ"),l1l111_l1_ (u"ࠫࠬᢧ"),l1l111_l1_ (u"ࠬ࠭ᢨ"),l1l111_l1_ (u"ᢩ࠭ࠧ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᢪ"))
	html = response.content
	if l1l111_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࠨ᢫") in url: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩࡪࡦࡀࠦࡵࡳ࠭ࡨࡴ࡬ࡨࠧ࠭᢬"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᢭"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ᢮"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࠬ᢯") in l1ll1ll_l1_:
				if l1l111_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡧࡱ࡫ࡱ࡯ࡳࡩ࠯ࡰࡳࡻ࡯ࡥࡴࠩᢰ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡲࡲࡱ࡯࡮ࡦ࠯ࡰࡳࡻ࡯ࡥࡴ࠳ࠪᢱ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡱ࡮ࡹࡣࠨᢲ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"ࠩࡷࡳࡵࡼࡩࡥࡧࡲࡷ࠳ࡶࡨࡱࡁࡦࡁࡹࡼ࠭ࡤࡪࡤࡲࡳ࡫࡬ࠨᢳ") in l1ll1ll_l1_: continue
				if l1l111_l1_ (u"้๋ࠪึࠠศๆหำฬ๐ษࠨᢴ") in title and l1l111_l1_ (u"ࠫࡩࡵ࠽ࡳࡣࡷ࡭ࡳ࡭ࠧᢵ") not in l1ll1ll_l1_: continue
			else: title = l1l111_l1_ (u"ࠬะัห์หࠤออำหะาห๊ࡀࠠࠡࠩᢶ")+title
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᢷ"),l1lllll_l1_+title,l1ll1ll_l1_,471)
	else: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨᢸ")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬᢹ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭ᢺ"),url,l1l111_l1_ (u"ࠪࠫᢻ"),l1l111_l1_ (u"ࠫࠬᢼ"),l1l111_l1_ (u"ࠬ࠭ᢽ"),l1l111_l1_ (u"࠭ࠧᢾ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᢿ"))
	html = response.content
	items = []
	if request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡱࡴࡼࡩࡦࡵࠪᣀ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠳ࡦ࡭ࡷ࡬ࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᣁ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᣂ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l11111l1l_l1_ = zip(*items)
		items = zip(l11111l1l_l1_,l1ll_l1_,l11l11_l1_)
	elif request==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᣃ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬอไๆี็ื้อสࠡษ็้๊๐าสࠪ࠱࠮ࡄ࠯࠼ࡴࡶࡼࡰࡪࡄࠧᣄ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠫᣅ"),block,re.DOTALL)
		l1ll_l1_,l11l11_l1_,l11111l1l_l1_ = zip(*items)
		items = zip(l11111l1l_l1_,l1ll_l1_,l11l11_l1_)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣆ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࡇࡴࡴࠢࠨᣇ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡪࡶ࡮ࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᣈ"),html,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰ࡶࡪࡲࡡࡵࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣉ"),html,re.DOTALL)
		if not l11llll_l1_: return
		block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬᣊ"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᣋ"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ᣌ"),l1l111_l1_ (u"ࠧโ์็้ࠬᣍ"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧᣎ"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧᣏ"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩᣐ"),l1l111_l1_ (u"ࠫ์ีวโࠩᣑ"),l1l111_l1_ (u"๋ࠬศศำสอࠬᣒ"),l1l111_l1_ (u"ู࠭าุࠪᣓ"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧᣔ"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧᣕ"),l1l111_l1_ (u"่ࠩืึำ๊สࠩᣖ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬᣗ"))
		title = title.replace(l1l111_l1_ (u"๊ࠫอ๊ࠡีํ้ฬ࠭ᣘ"),l1l111_l1_ (u"ࠬ࠭ᣙ")).replace(l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭ᣚ"),l1l111_l1_ (u"ࠧࠨᣛ")).strip(l1l111_l1_ (u"ࠨࠢࠪᣜ")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬᣝ"),l1l111_l1_ (u"ࠪࠤࠬᣞ"))
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᣟ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧᣠ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨᣡ"))
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬᣢ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࠪᣣ")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫᣤ"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᣥ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᣦ")+title
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᣧ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭ᣨ") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭ᣩ")+l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᣪ"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧᣫ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᣬ"),l1lllll_l1_+title,l1ll1ll_l1_,471,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᣭ"),l1lllll_l1_+title,l1ll1ll_l1_,473,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧᣮ"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᣯ")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᣰ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᣱ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫᣲ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬᣳ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ᣴ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᣵ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ᣶")+title,l1ll1ll_l1_,471)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᣷"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᣸"),l1lllll_l1_+l1l111_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะࠩ᣹"),l1ll1ll_l1_,471)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ᣺"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ᣻"),url,l1l111_l1_ (u"ࠬ࠭᣼"),l1l111_l1_ (u"࠭ࠧ᣽"),l1l111_l1_ (u"ࠧࠨ᣾"),l1l111_l1_ (u"ࠨࠩ᣿"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫᤀ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᤁ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠩᤂ")+l1l11_l1_+l1l111_l1_ (u"ࠬࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᤃ"),html,re.DOTALL)
	items = []
	if l11ll1l_l1_ and not l1l11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᤄ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࡞࠯ࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࡜ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡺࡺࡴࡰࡰࡁࠫᤅ"),block,re.DOTALL)
		for l1l11_l1_,title in items: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᤆ"),l1lllll_l1_+title,url,473,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪᤇ"),l1l11_l1_)
	elif l11ll11_l1_:
		l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᤈ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠦࡹ࡯ࡴ࡭ࡧࡀࠫ࠭࠴ࠪࡀࠫࠪࠤ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࠥᤉ"),block,re.DOTALL)
		if items:
			for title,l1ll1ll_l1_ in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧᤊ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨᤋ"))
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᤌ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
		else:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᤍ"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᤎ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬᤏ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭ᤐ"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᤑ"),l1lllll_l1_+title,l1ll1ll_l1_,472,l1ll1l_l1_)
	if l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡲ࠳ࡲࡦ࡮ࡤࡸࡪࡪࠢࠨᤒ") in html:
		if items: addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᤓ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᤔ"),l1l111_l1_ (u"ࠩࠪᤕ"),9999)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᤖ"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫ๎วื์฼ࠤีอสࠡื็อࠬᤗ"),url,471)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᤘ"),url,l1l111_l1_ (u"࠭ࠧᤙ"),l1l111_l1_ (u"ࠧࠨᤚ"),l1l111_l1_ (u"ࠨࠩᤛ"),l1l111_l1_ (u"ࠩࠪᤜ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᤝ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡪࡩࡷࠢ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥࡂ࠭࠴ࠪࡀࠫ࡫ࡶࡪ࡬࠽ࠨᤞ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ᤟"),block,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,True): return
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᤠ"),l1l111_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾ࠴ࡰࡩࡲࠪᤡ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᤢ"),l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪᤣ"),l1l111_l1_ (u"ࠪࠫᤤ"),l1l111_l1_ (u"ࠫࠬᤥ"),l1l111_l1_ (u"ࠬ࠭ᤦ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫᤧ"))
	html = response.content
	l111111ll_l1_ = []
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡧࡰࡦࡪࡪࡕࡓࡎࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᤨ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		if l1ll1ll_l1_ and l1ll1ll_l1_ not in l111111ll_l1_:
			l111111ll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩᤩ")
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᤪ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩᤫ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠦࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠢ᤬"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l111111ll_l1_:
			l111111ll_l1_.append(l1ll1ll_l1_)
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭᤭")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ᤮")
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ᤯") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧᤰ")+l1ll1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭ᤱ"),l1l111_l1_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠮ࡱࡪࡳࠫᤲ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᤳ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭ᤴ"),l1l111_l1_ (u"࠭ࠧᤵ"),l1l111_l1_ (u"ࠧࠨᤶ"),l1l111_l1_ (u"ࠨࠩᤷ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧᤸ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ᤹ࠧ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ᤺"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_ not in l111111ll_l1_:
				l111111ll_l1_.append(l1ll1ll_l1_)
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ᤻࠭")+title+l1l111_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ᤼")
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ᤽") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ᤾")+l1ll1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᤿"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ᥀"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ᥁"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ᥂"),l1l111_l1_ (u"࠭ࠫࠨ᥃"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨ᥄")+search
	l1lll11_l1_(url)
	return
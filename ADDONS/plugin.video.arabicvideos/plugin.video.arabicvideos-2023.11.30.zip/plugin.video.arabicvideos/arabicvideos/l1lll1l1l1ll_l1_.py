# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨ㭗")
l111l1_l1_ = l1l11l1_l1_[l1l111_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ㭘")][0]
def l11l1ll_l1_(mode,url):
	if   mode==100: l1lll_l1_ = l1l1l11_l1_()
	elif mode==101: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠪ࠴ࠬ㭙"),True)
	elif mode==102: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠫ࠶࠭㭚"),True)
	elif mode==103: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠬ࠸ࠧ㭛"),True)
	elif mode==104: l1lll_l1_ = ITEMS(l1l111_l1_ (u"࠭࠳ࠨ㭜"),True)
	elif mode==105: l1lll_l1_ = PLAY(url)
	elif mode==106: l1lll_l1_ = ITEMS(l1l111_l1_ (u"ࠧ࠵ࠩ㭝"),True)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㭞"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㭟")+l1l111_l1_ (u"ࠪๆํอฦๆࠢไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠨ㭠"),l1l111_l1_ (u"ࠫࠬ㭡"),762)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㭢"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗࡣࠬ㭣")+l1l111_l1_ (u"ࠧใ๊สส๊ࠦแ๋ัํ์์อสࠡࡋࡓࡘ࡛࠭㭤"),l1l111_l1_ (u"ࠨࠩ㭥"),761)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㭦"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠰ࡠࠩ㭧")+l1l111_l1_ (u"ࠫ็์่ศฬ้๋ࠣࠦๅ้ษๅ฽์อࠠศๆฦู้๐ษࠨ㭨"),l1l111_l1_ (u"ࠬ࠭㭩"),101)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㭪"),l1l111_l1_ (u"ࠧࡠࡖ࡙࠸ࡤ࠭㭫")+l1l111_l1_ (u"ࠨไ้์ฬะࠠๆะอหึฯࠠๆ่ࠣ๎ํะ๊้สࠪ㭬"),l1l111_l1_ (u"ࠩࠪ㭭"),106)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㭮"),l1l111_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪ㭯")+l1l111_l1_ (u"่ࠬๆ้ษอࠤ฾ืศ๋ห้๋๊้ࠣࠦฬํ์อ࠭㭰"),l1l111_l1_ (u"࠭ࠧ㭱"),147)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㭲"),l1l111_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ㭳")+l1l111_l1_ (u"ࠩๅ๊ํอสࠡลฯ๊อ๐ษࠡ็้ࠤ๏๎ส๋๊หࠫ㭴"),l1l111_l1_ (u"ࠪࠫ㭵"),148)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㭶"),l1l111_l1_ (u"ࠬࡥࡉࡇࡎࡢࠫ㭷")+l1l111_l1_ (u"࠭ࠠࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠๆ่้ࠣํู่่็ࠣࠤࠬ㭸"),l1l111_l1_ (u"ࠧࠨ㭹"),28)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㭺"),l1l111_l1_ (u"ࠩࡢࡑࡗࡌ࡟ࠨ㭻")+l1l111_l1_ (u"ࠪๆ๋อษࠡษ็้฾อัโ่๊๋่ࠢࠥใ฻๊้ࠬ㭼"),l1l111_l1_ (u"ࠫࠬ㭽"),41)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㭾"),l1l111_l1_ (u"࠭࡟ࡑࡐࡗࡣࠬ㭿")+l1l111_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ㮀"),l1l111_l1_ (u"ࠨࠩ㮁"),38)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㮂"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㮃"),l1l111_l1_ (u"ࠫࠬ㮄"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㮅"),l1l111_l1_ (u"࠭࡟ࡕࡘ࠴ࡣࠬ㮆")+l1l111_l1_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ฼ห๊ฯࠧ㮇"),l1l111_l1_ (u"ࠨࠩ㮈"),102)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㮉"),l1l111_l1_ (u"ࠪࡣ࡙࡜࠲ࡠࠩ㮊")+l1l111_l1_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦฮศืฬࠫ㮋"),l1l111_l1_ (u"ࠬ࠭㮌"),103)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㮍"),l1l111_l1_ (u"ࠧࡠࡖ࡙࠷ࡤ࠭㮎")+l1l111_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋ห่้ࠣ็อึࠩ㮏"),l1l111_l1_ (u"ࠩࠪ㮐"),104)
	return
def ITEMS(l1lll1ll111_l1_,l11_l1_=True):
	l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣ࡙࡜ࠧ㮑")+l1lll1ll111_l1_+l1l111_l1_ (u"ࠫࡤ࠭㮒")
	user = l1l1l1l1lll_l1_(32)
	payload = {l1l111_l1_ (u"ࠬ࡯ࡤࠨ㮓"):l1l111_l1_ (u"࠭ࠧ㮔"),l1l111_l1_ (u"ࠧࡶࡵࡨࡶࠬ㮕"):user,l1l111_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㮖"):l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㮗"),l1l111_l1_ (u"ࠪࡱࡪࡴࡵࠨ㮘"):l1lll1ll111_l1_}
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩ㮙"),l111l1_l1_,payload,l1l111_l1_ (u"ࠬ࠭㮚"),l1l111_l1_ (u"࠭ࠧ㮛"),l1l111_l1_ (u"ࠧࠨ㮜"),l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ㮝"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠩࠫ࡟ࡣࡁ࡜ࡳ࡞ࡱࡡ࠰ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠫ࠲࠯ࡅࠩ࠼࠽ࠪ㮞"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l1l111_l1_ (u"ࠪࡥࡱ࠭㮟"),l1l111_l1_ (u"ࠫࡆࡲࠧ㮠"))
			start = start.replace(l1l111_l1_ (u"ࠬࡋ࡬ࠨ㮡"),l1l111_l1_ (u"࠭ࡁ࡭ࠩ㮢"))
			start = start.replace(l1l111_l1_ (u"ࠧࡂࡎࠪ㮣"),l1l111_l1_ (u"ࠨࡃ࡯ࠫ㮤"))
			start = start.replace(l1l111_l1_ (u"ࠩࡈࡐࠬ㮥"),l1l111_l1_ (u"ࠪࡅࡱ࠭㮦"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l1l111_l1_ (u"ࠫࡆࡲ࠭ࠨ㮧"),l1l111_l1_ (u"ࠬࡇ࡬ࠨ㮨"))
			start = start.replace(l1l111_l1_ (u"࠭ࡁ࡭ࠢࠪ㮩"),l1l111_l1_ (u"ࠧࡂ࡮ࠪ㮪"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l1l1l11l1l_l1_,name,l1ll1l_l1_ in items:
			if l1l111_l1_ (u"ࠨࠥࠪ㮫") in source: continue
			if source!=l1l111_l1_ (u"ࠩࡘࡖࡑ࠭㮬"): name = name+l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠࠡࠩ㮭")+source+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㮮")
			url = source+l1l111_l1_ (u"ࠬࡁ࠻ࠨ㮯")+server+l1l111_l1_ (u"࠭࠻࠼ࠩ㮰")+l1l1l11l1l_l1_+l1l111_l1_ (u"ࠧ࠼࠽ࠪ㮱")+l1lll1ll111_l1_
			addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㮲"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠪ㮳")+name,url,105,l1ll1l_l1_)
	else:
		if l11_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㮴"),l1lllll_l1_+l1l111_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㮵"),l1l111_l1_ (u"ࠬ࠭㮶"),9999)
	return
def PLAY(id):
	source,server,l1l1l11l1l_l1_,l1lll1ll111_l1_ = id.split(l1l111_l1_ (u"࠭࠻࠼ࠩ㮷"))
	url = l1l111_l1_ (u"ࠧࠨ㮸")
	user = l1l1l1l1lll_l1_(32)
	if source==l1l111_l1_ (u"ࠨࡗࡕࡐࠬ㮹"): url = l1l1l11l1l_l1_
	elif source==l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㮺"):
		url = l1l11l1_l1_[l1l111_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㮻")][0]+l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ㮼")+l1l1l11l1l_l1_
		import ll_l1_
		ll_l1_.l1l_l1_([url],l1ll1_l1_,l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ㮽"),url)
		return
	elif source==l1l111_l1_ (u"࠭ࡇࡂࠩ㮾"):
		payload = { l1l111_l1_ (u"ࠧࡪࡦࠪ㮿") : l1l111_l1_ (u"ࠨࠩ㯀"), l1l111_l1_ (u"ࠩࡸࡷࡪࡸࠧ㯁") : user , l1l111_l1_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ㯂") : l1l111_l1_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠵ࠬ㯃") , l1l111_l1_ (u"ࠬࡳࡥ࡯ࡷࠪ㯄") : l1l111_l1_ (u"࠭ࠧ㯅") }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ㯆"),l111l1_l1_,payload,l1l111_l1_ (u"ࠨࠩ㯇"),False,l1l111_l1_ (u"ࠩࠪ㯈"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㯉"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㯊"),l1l111_l1_ (u"ࠬ࠭㯋"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㯌"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㯍"))
			return
		html = response.content
		cookies = response.cookies
		l1l1l1lll1l1_l1_ = cookies[l1l111_l1_ (u"ࠨࡃࡖࡔ࠳ࡔࡅࡕࡡࡖࡩࡸࡹࡩࡰࡰࡌࡨࠬ㯎")]
		url = response.headers[l1l111_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㯏")]
		payload = { l1l111_l1_ (u"ࠪ࡭ࡩ࠭㯐") : l1l1l11l1l_l1_ , l1l111_l1_ (u"ࠫࡺࡹࡥࡳࠩ㯑") : user , l1l111_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㯒") : l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼࡋࡆ࠸ࠧ㯓") , l1l111_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㯔") : l1l111_l1_ (u"ࠨࠩ㯕") }
		headers = { l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ㯖") : l1l111_l1_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪ࠽ࠨ㯗")+l1l1l1lll1l1_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ㯘"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠬ࠭㯙"),l1l111_l1_ (u"࠭ࠧ㯚"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㯛"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ㯜"),l1l111_l1_ (u"ࠩࠪ㯝"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㯞"),l1l111_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㯟"))
			return
		html = response.content
		url = re.findall(l1l111_l1_ (u"ࠬࡸࡥࡴࡲࠥ࠾ࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅ࡭࠴ࡷ࠻࠭࠭࠴ࠪࡀࠫࠥࠫ㯠"),html,re.DOTALL)
		l1ll1ll_l1_ = url[0][0]
		params = url[0][1]
		l1l1l1lll11l_l1_ = l1l111_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠳࠹࠰ࠪ㯡")+server+l1l111_l1_ (u"ࠧ࠸࠹࠺࠳ࠬ㯢")+l1l1l11l1l_l1_+l1l111_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㯣")+params
		l1l1l1lll111_l1_ = l1l1l1lll11l_l1_.replace(l1l111_l1_ (u"ࠩ࠶࠺࠿࠽ࠧ㯤"),l1l111_l1_ (u"ࠪ࠸࠵ࡀ࠷ࠨ㯥")).replace(l1l111_l1_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭㯦"),l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㯧"))
		l1l1l1lll1ll_l1_ = l1l1l1lll11l_l1_.replace(l1l111_l1_ (u"࠭࠳࠷࠼࠺ࠫ㯨"),l1l111_l1_ (u"ࠧ࠵࠴࠽࠻ࠬ㯩")).replace(l1l111_l1_ (u"ࠨࡡࡋࡈ࠳ࡳ࠳ࡶ࠺ࠪ㯪"),l1l111_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ㯫"))
		l1l1lll1_l1_ = [l1l111_l1_ (u"ࠪࡌࡉ࠭㯬"),l1l111_l1_ (u"ࠫࡘࡊ࠱ࠨ㯭"),l1l111_l1_ (u"࡙ࠬࡄ࠳ࠩ㯮")]
		l1llll_l1_ = [l1l1l1lll11l_l1_,l1l1l1lll111_l1_,l1l1l1lll1ll_l1_]
		l11l11l_l1_ = 0
		if l11l11l_l1_ == -1: return
		else: url = l1llll_l1_[l11l11l_l1_]
	elif source==l1l111_l1_ (u"࠭ࡎࡕࠩ㯯"):
		headers = { l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㯰") : l1l111_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㯱") }
		payload = { l1l111_l1_ (u"ࠩ࡬ࡨࠬ㯲") : l1l1l11l1l_l1_ , l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㯳") : user , l1l111_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㯴") : l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡑࡘࠬ㯵") , l1l111_l1_ (u"࠭࡭ࡦࡰࡸࠫ㯶") : l1lll1ll111_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㯷"), l111l1_l1_, payload, headers, False,l1l111_l1_ (u"ࠨࠩ㯸"),l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ㯹"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ㯺"),l1l111_l1_ (u"ࠫࠬ㯻"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㯼"),l1l111_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㯽"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㯾")]
		url = url.replace(l1l111_l1_ (u"ࠨࠧ࠵࠴ࠬ㯿"),l1l111_l1_ (u"ࠩࠣࠫ㰀"))
		url = url.replace(l1l111_l1_ (u"ࠪࠩ࠸ࡊࠧ㰁"),l1l111_l1_ (u"ࠫࡂ࠭㰂"))
		if l1l111_l1_ (u"ࠬࡒࡥࡢࡴࡱࠫ㰃") in l1l1l11l1l_l1_:
			url = url.replace(l1l111_l1_ (u"࠭ࡎࡕࡐࡑ࡭ࡱ࡫ࠧ㰄"),l1l111_l1_ (u"ࠧࠨ㰅"))
			url = url.replace(l1l111_l1_ (u"ࠨ࡮ࡨࡥࡷࡴࡩ࡯ࡩ࠴ࠫ㰆"),l1l111_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࡪࡰࡪࠫ㰇"))
	elif source==l1l111_l1_ (u"ࠪࡔࡑ࠭㰈"):
		payload = { l1l111_l1_ (u"ࠫ࡮ࡪࠧ㰉") : l1l1l11l1l_l1_ , l1l111_l1_ (u"ࠬࡻࡳࡦࡴࠪ㰊") : user , l1l111_l1_ (u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ㰋") : l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡕࡒࠧ㰌") , l1l111_l1_ (u"ࠨ࡯ࡨࡲࡺ࠭㰍") : l1lll1ll111_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㰎"), l111l1_l1_, payload, l1l111_l1_ (u"ࠪࠫ㰏"),False,l1l111_l1_ (u"ࠫࠬ㰐"),l1l111_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ㰑"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ㰒"),l1l111_l1_ (u"ࠧࠨ㰓"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㰔"),l1l111_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㰕"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㰖")]
		headers = {l1l111_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㰗"):response.headers[l1l111_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭㰘")]}
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ㰙"),url, l1l111_l1_ (u"ࠧࠨ㰚"),headers , l1l111_l1_ (u"ࠨࠩ㰛"),l1l111_l1_ (u"ࠩࠪ㰜"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬ㰝"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ㰞"),l1l111_l1_ (u"ࠬ࠭㰟"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㰠"),l1l111_l1_ (u"่ࠧา๊ࠤฬ๊ฮะ็ฬࠤ๊ิีึห่้๋ࠣศา็ฯࠤๆ่ืࠨ㰡"))
			return
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㰢"),html,re.DOTALL)
		url = items[0]
	elif source in [l1l111_l1_ (u"ࠩࡗࡅࠬ㰣"),l1l111_l1_ (u"ࠪࡊࡒ࠭㰤"),l1l111_l1_ (u"ࠫ࡞࡛ࠧ㰥"),l1l111_l1_ (u"ࠬ࡝ࡓ࠲ࠩ㰦"),l1l111_l1_ (u"࠭ࡗࡔ࠴ࠪ㰧"),l1l111_l1_ (u"ࠧࡓࡎ࠴ࠫ㰨"),l1l111_l1_ (u"ࠨࡔࡏ࠶ࠬ㰩")]:
		if source==l1l111_l1_ (u"ࠩࡗࡅࠬ㰪"): l1l1l11l1l_l1_ = id
		headers = { l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ㰫") : l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ㰬") }
		payload = { l1l111_l1_ (u"ࠬ࡯ࡤࠨ㰭") : l1l1l11l1l_l1_ , l1l111_l1_ (u"࠭ࡵࡴࡧࡵࠫ㰮") : user , l1l111_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㰯") : l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾ࠭㰰")+source , l1l111_l1_ (u"ࠩࡰࡩࡳࡻࠧ㰱") : l1lll1ll111_l1_ }
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㰲"),l111l1_l1_,payload,headers,l1l111_l1_ (u"ࠫࠬ㰳"),l1l111_l1_ (u"ࠬ࠭㰴"),l1l111_l1_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠻ࡺࡨࠨ㰵"))
		if not response.succeeded:
			l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ㰶"),l1l111_l1_ (u"ࠨࠩ㰷"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㰸"),l1l111_l1_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ㰹"))
			return
		html = response.content
		url = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㰺")]
		if source==l1l111_l1_ (u"ࠬࡌࡍࠨ㰻"):
			response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ㰼"), url, l1l111_l1_ (u"ࠧࠨ㰽"), l1l111_l1_ (u"ࠨࠩ㰾"), False,l1l111_l1_ (u"ࠩࠪ㰿"),l1l111_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡔࡑࡇ࡙࠮࠹ࡷ࡬ࠬ㱀"))
			url = response.headers[l1l111_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㱁")]
			url = url.replace(l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ㱂"),l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ㱃"))
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㱄"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ⾵")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡌࡖ࡙ࡣࠬ⾶")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩ⾷")]
def l11l1ll_l1_(mode,url,text):
	if   mode==810: l1lll_l1_ = l1l1l11_l1_()
	elif mode==811: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==812: l1lll_l1_ = PLAY(url)
	elif mode==813: l1lll_l1_ = l1ll111l111_l1_(url)
	elif mode==819: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⾸"),l111l1_l1_,l1l111_l1_ (u"ࠩࠪ⾹"),l1l111_l1_ (u"ࠪࠫ⾺"),l1l111_l1_ (u"ࠫࠬ⾻"),l1l111_l1_ (u"ࠬ࠭⾼"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⾽"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⾾"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ⾿"),l1l111_l1_ (u"ࠩࠪ⿀"),819,l1l111_l1_ (u"ࠪࠫ⿁"),l1l111_l1_ (u"ࠫࠬ⿂"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⿃"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⿄"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⿅"),l1l111_l1_ (u"ࠨࠩ⿆"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡷ࡯࡭ࡢࡴࡼ࠱ࡱ࡯࡮࡬ࡵࠥࠬ࠳࠰࠿ࠪࠤࡰࡳࡸࡺ࠭ࡷ࡫ࡨࡻࡪࡪࠢࠨ⿇"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⿈"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⿉"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⿊")+l1lllll_l1_+title,l1ll1ll_l1_,811)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"࠭ࠧ⿋")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⿌"),url,l1l111_l1_ (u"ࠨࠩ⿍"),l1l111_l1_ (u"ࠩࠪ⿎"),l1l111_l1_ (u"ࠪࠫ⿏"),l1l111_l1_ (u"ࠫࠬ⿐"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⿑"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࠧ࡬࡯ࡰࡶࡨࡶࠧ࠭⿒"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࠣࡶ࡫ࡹࡲࡨࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⿓"),block,re.DOTALL)
		l1l1_l1_ = []
		for l1ll1l_l1_,l1ll1ll_l1_,title in items:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ⿔"),title,re.DOTALL)
			if l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⿕") not in type and l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ⿖") + l1l1lll_l1_[0][0]
				title = title.replace(l1l111_l1_ (u"ࠫฬ๎ๆࠡๆส๎๋࠭⿗"),l1l111_l1_ (u"ࠬ࠭⿘"))
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿙"),l1lllll_l1_+title,l1ll1ll_l1_,813,l1ll1l_l1_)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⿚"),l1lllll_l1_+title,l1ll1ll_l1_,812,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ࠨ࠯ࠬࡂ࠭࡫ࡵ࡯ࡵࡧࡵࠦ⿛"),html,re.DOTALL)
	if l11llll_l1_:
		type = l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࡣࡵࡧࡧࡦࡵࠪ⿜") if l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⿝") in type else l1l111_l1_ (u"ࠫࡵࡧࡧࡦࡵࠪ⿞")
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⿟"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿠"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭⿡")+title,l1ll1ll_l1_,811,l1l111_l1_ (u"ࠨࠩ⿢"),l1l111_l1_ (u"ࠩࠪ⿣"),type)
	return
def l1ll111l111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ⿤"),url,l1l111_l1_ (u"ࠫࠬ⿥"),l1l111_l1_ (u"ࠬ࠭⿦"),l1l111_l1_ (u"࠭ࠧ⿧"),l1l111_l1_ (u"ࠧࠨ⿨"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘ࠰ࡗࡊࡘࡉࡆࡕ࠰࠵ࡸࡺࠧ⿩"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡧࡦࡺࡥࡨࡱࡵࡽࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⿪"),html,re.DOTALL)
	if l1ll1ll_l1_: l1lll11_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ⿫"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ⿬"),url,l1l111_l1_ (u"ࠬ࠭⿭"),l1l111_l1_ (u"࠭ࠧ⿮"),l1l111_l1_ (u"ࠧࠨ⿯"),l1l111_l1_ (u"ࠨࠩ⿰"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⿱"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ⿲"),html,re.DOTALL)
	l1ll11l_l1_ = base64.b64decode(l1ll11l_l1_[0])
	if kodi_version>18.99: l1ll11l_l1_ = l1ll11l_l1_.decode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ⿳"))
	l1ll11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡪࡩࡤࡶࠪ⿴"),l1ll11l_l1_)
	l1ll_l1_ = l1ll11l_l1_[l1l111_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡹࠧ⿵")]
	l11l11_l1_ = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	l1lll1l_l1_ = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in l1lll1l_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⿶")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⿷")
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⿸"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ⿹"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ⿺"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ⿻"),l1l111_l1_ (u"࠭ࠫࠨ⿼"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ⿽")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ⿾"))
	return
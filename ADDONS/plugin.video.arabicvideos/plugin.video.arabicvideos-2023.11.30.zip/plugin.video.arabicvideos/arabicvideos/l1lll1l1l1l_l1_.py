# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ⥩")
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⥪"):l1l111_l1_ (u"ࠬ࠭⥫")}
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟ࡇࡊ࠴ࡣࠬ⥬")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠧอ๊สสืࠦวๅล๋ื่อัࠨ⥭"),l1l111_l1_ (u"ࠨษ็้ึอฬฺษอࠫ⥮"),l1l111_l1_ (u"ࠩࡺࡻࡪ࠭⥯")]
def l11l1ll_l1_(mode,url,text):
	if   mode==570: l1lll_l1_ = l1l1l11_l1_()
	elif mode==571: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==572: l1lll_l1_ = PLAY(url)
	elif mode==573: l1lll_l1_ = l111l1111_l1_(url,text)
	elif mode==579: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lll1llll1_l1_(l111l1_l1_,l1l111_l1_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧ࠵ࠬ⥰"),l1l111_l1_ (u"ࠫๆอีๅࠢศ฽้อๆ๋ࠩ⥱"),l1l111_l1_ (u"ࠬࡪࡵࡣࡤࡨࡨ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬ⥲"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⥳"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ⥴"),l1l11ll_l1_,579,l1l111_l1_ (u"ࠨࠩ⥵"),l1l111_l1_ (u"ࠩࠪ⥶"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⥷"))
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⥸"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⥹"),l1l111_l1_ (u"࠭ࠧ⥺"),9999)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⥻"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩ⥼"),l1l11ll_l1_,571,l1l111_l1_ (u"ࠩࠪ⥽"),l1l111_l1_ (u"ࠪࠫ⥾"),l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠷ࠧ⥿"))
	items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮࠳ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⦀"),html,re.DOTALL)
	if not items:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ⦁"),l1l111_l1_ (u"ࠧࠨ⦂"),l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬาࠠะ์ࠣ์ฬำฯࠨ⦃"),l1l111_l1_ (u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠฦ์ฯหิูࠦ็๊ส๊ࠥอไๆ๊ๅ฽ࠥษ่ࠡฬุ้๏๋ࠠศๆ่์็฿ࠠห฼ํีࠬ⦄"))
		return
	for title,l1ll1ll_l1_ in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦅"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⦆")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠬ࠭⦇"),l1l111_l1_ (u"࠭ࠧ⦈"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠲ࠩ⦉"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡰࡩࡳࡻ࠭ࡱࡴ࡬ࡱࡦࡸࡹࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ⦊"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1lll1l1ll1_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡰ࡮ࠦࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ⦋"),block,re.DOTALL)
		l1lll1l11l1_l1_ = [l1l111_l1_ (u"ࠪࠫ⦌"),l1l111_l1_ (u"ࠫศ็ไศ็࠽ࠤࠬ⦍"),l1l111_l1_ (u"๋ࠬำๅี็หฯࡀࠠࠨ⦎"),l1l111_l1_ (u"࠭ศาษ่ะ࠿ࠦࠧ⦏"),l1l111_l1_ (u"ࠧรีํ์๏ࡀࠠࠨ⦐"),l1l111_l1_ (u"ࠨล้้๏ࡀࠠࠨ⦑")]
		l1l11l111l_l1_ = 0
		for l1lll1ll111_l1_ in l1lll1l1ll1_l1_:
			if l1l11l111l_l1_>0: addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ⦒"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⦓"),l1l111_l1_ (u"ࠫࠬ⦔"),9999)
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⦕"),l1lll1ll111_l1_,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨ⦖"): continue
				if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ⦗") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
				if title==l1l111_l1_ (u"ࠨࠩ⦘"): continue
				if any(value in title.lower() for value in l11lll_l1_): continue
				title = l1lll1l11l1_l1_[l1l11l111l_l1_]+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⦙"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⦚")+l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠫࠬ⦛"),l1l111_l1_ (u"ࠬ࠭⦜"),l1l111_l1_ (u"࠭ࡤࡦࡶࡤ࡭ࡱࡹ࠲ࠨ⦝"))
			l1l11l111l_l1_ += 1
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠧࠨ⦞")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ⦟"),url,l1l111_l1_ (u"ࠩࠪ⦠"),l1l111_l1_ (u"ࠪࠫ⦡"),l1l111_l1_ (u"ࠫࠬ⦢"),l1l111_l1_ (u"ࠬ࠭⦣"),l1l111_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⦤"))
	html = response.content
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩ࠶ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⦥"),html,re.DOTALL)
	if not l11ll11_l1_: return
	if type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⦦"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭⦧"),l1l111_l1_ (u"ࠪ࠳ࠬ⦨")).replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ⦩"),l1l111_l1_ (u"ࠬࠨࠧ⦪"))]
	elif type==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤ࠲ࠩ⦫"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡲࡱࡪ࡙࡬ࡪࡦࡨࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⦬"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⦭"),block,re.DOTALL)
		l11ll1l11_l1_,l1ll_l1_,l11l11_l1_ = zip(*items)
		items = zip(l1ll_l1_,l11ll1l11_l1_,l11l11_l1_)
	elif type==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧ࠶ࠬ⦮"):
		title,block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠥࡪࡡࡵࡣ࠰ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⦯"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠫࡩ࡫ࡴࡢ࡫࡯ࡷ࠷࠭⦰") and len(l11ll11_l1_)>1:
		title = l11ll11_l1_[0][0]
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⦱"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"࠭ࠧ⦲"),l1l111_l1_ (u"ࠧࠨ⦳"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦ࠵ࠫ⦴"))
		title = l11ll11_l1_[1][0]
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⦵"),l1lllll_l1_+title,url,571,l1l111_l1_ (u"ࠪࠫ⦶"),l1l111_l1_ (u"ࠫࠬ⦷"),l1l111_l1_ (u"ࠬࡪࡥࡵࡣ࡬ࡰࡸ࠹ࠧ⦸"))
		return
	else:
		title,block = l11ll11_l1_[-1]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡩ࠳ࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⦹"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if any(value in title.lower() for value in l11lll_l1_): continue
		l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
		l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠧࡀࡴࡨࡷ࡮ࢀࡥ࠾ࠩ⦺"))[0]
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ⦻"),title,re.DOTALL)
		if l1l111_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳ࠰ࠩ⦼") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⦽"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1ll1l_l1_)
		elif l1l1lll_l1_ and type==l1l111_l1_ (u"ࠫࠬ⦾"):
			title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⦿")+l1l1lll_l1_[0][0]
			title = title.strip(l1l111_l1_ (u"࠭ࠠ⠔ࠩ⧀"))
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⧁"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ⧂") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴ࠱ࠪ⧃") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠪ࡬࡮ࡴࡤࡪ࠱ࠪ⧄") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⧅"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⧆"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⧇"):
		l1111ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ⧈"),block,re.DOTALL)
		if l1111ll11l_l1_:
			count = l1111ll11l_l1_[0]
			l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ⧉")+count
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⧊"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡลัี๎࠭⧋"),l1ll1ll_l1_,571,l1l111_l1_ (u"ࠫࠬ⧌"),l1l111_l1_ (u"ࠬ࠭⧍"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ⧎"))
	elif l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳࠨ⧏") in type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࡥ࡯ࡥࡸࡹ࠽ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠤ⧐"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦ⧑"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = l1l111_l1_ (u"ูࠪๆำษࠡࠩ⧒")+unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⧓"),l1lllll_l1_+title,l1ll1ll_l1_,571,l1l111_l1_ (u"ࠬ࠭⧔"),l1l111_l1_ (u"࠭ࠧ⧕"),l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠵ࠩ⧖"))
	return
def l111l1111_l1_(url,type=l1l111_l1_ (u"ࠨࠩ⧗")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⧘"),url,l1l111_l1_ (u"ࠪࠫ⧙"),l1l111_l1_ (u"ࠫࠬ⧚"),l1l111_l1_ (u"ࠬ࠭⧛"),l1l111_l1_ (u"࠭ࠧ⧜"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲࠯ࡖࡉࡆ࡙ࡏࡏࡕࡢࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⧝"))
	html = response.content
	l111l1l111_l1_ = False
	if not type:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡦࡹ࡯࡯ࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠩ⧞"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬ࠠ࠾ࠢ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠳࠰࠿ࠡࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ⧟"),block,re.DOTALL)
			if len(items)>1:
				l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ⧠"))
				l111l1l111_l1_ = True
				for l1ll1ll_l1_,l1ll1l_l1_,name,title in items:
					name = unescapeHTML(name)
					if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⧡") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
					title = name+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩ⧢")+title
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⧣"),l1lllll_l1_+title,l1ll1ll_l1_,573,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ⧤"),l1l111_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ⧥"))
	if type==l1l111_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ⧦") or not l111l1l111_l1_:
		l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡵࡳࡵࡧࡵࡍࡲ࡭ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⧧"),html,re.DOTALL)
		if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
		else: l1ll1l_l1_ = l1l111_l1_ (u"ࠫࠬ⧨")
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡥࡱࡃ࡯ࡰࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⧩"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⧪"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ⧫"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⧬"),l1lllll_l1_+title,l1ll1ll_l1_,572,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_,l1lll1l1l11_l1_,l1lll1l1lll_l1_ = [],[],[]
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭⧭"),url,l1l111_l1_ (u"ࠪࠫ⧮"),l1l111_l1_ (u"ࠫࠬ⧯"),l1l111_l1_ (u"ࠬ࠭⧰"),l1l111_l1_ (u"࠭ࠧ⧱"),l1l111_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⧲"))
	html = response.content
	l1lll1l111l_l1_ = re.findall(l1l111_l1_ (u"ࠨ็ึฮํ๏ࠠศๆุ่ฬํฯส࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ⧳"),html,re.DOTALL)
	if l1lll1l111l_l1_:
		l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡸࡦ࡭ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⧴"),html,re.DOTALL)
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡻ࡯ࡤࡦࡱࡕࡳࡼࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⧵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⧶"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬࠬࡩ࡮ࡩࡀࠫ⧷"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ⧸"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡶࡵࡩࡦࡳࡈࡦࡣࡧࡩࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⧹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠣࡪࡵࡩ࡫ࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠦ⧺"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩࠩ࡭ࡲ࡭࠽ࠨ⧻"))[0]
			name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ⧼"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⧽")+name+l1l111_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭⧾"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࡍ࡫ࡱ࡯ࡸ࠮࠮ࠫࡁࠬࡦࡱࡧࡣ࡬ࡹ࡬ࡲࡩࡵࡷࠨ⧿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⨀"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠨ࡬ࡱ࡬ࡃࠧ⨁"))[0]
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⨂")+name+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ⨃"))
	for l1lll1l11ll_l1_ in l1ll11l1_l1_:
		l1ll1ll_l1_,name = l1lll1l11ll_l1_.split(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࠫ⨄"))
		if l1ll1ll_l1_ not in l1lll1l1l11_l1_:
			l1lll1l1l11_l1_.append(l1ll1ll_l1_)
			l1lll1l1lll_l1_.append(l1lll1l11ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1lll1l1lll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⨅"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ⨆"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ⨇"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⨈"),l1l111_l1_ (u"ࠩ࠮ࠫ⨉"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ⨊")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lll1llll1_l1_(url,l1l111_l1_ (u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭⨋"),l1l111_l1_ (u"ࠬ็วึๆࠣษ฾๊ว็์ࠪ⨌"),l1l111_l1_ (u"࠭ࡤࡶࡤࡥࡩࡩ࠳࡭ࡰࡸ࡬ࡩࡸ࠭⨍"))
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠧࡥࡧࡷࡥ࡮ࡲࡳ࠶ࠩ⨎"))
	return
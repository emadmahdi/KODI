# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ᥅")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡇࡒࡔ࡟ࠨ᥆")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠪๆฬฬๅห์ࠪ᥇")]
def l11l1ll_l1_(mode,url,text):
	if   mode==300: l1lll_l1_ = l1l1l11_l1_()
	elif mode==301: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==302: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==303: l1lll_l1_ = l111l1lll_l1_(url)
	elif mode==304: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==305: l1lll_l1_ = PLAY(url)
	elif mode==306: l1lll_l1_ = l1111111l_l1_()
	elif mode==309: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᥈"),l1lllll_l1_+l1l111_l1_ (u"๊ࠬๅศาสࠤฬ๊ๅ้ไ฼ࠤอ฽๊ยࠩ᥉"),l1l111_l1_ (u"࠭ࠧ᥊"),306)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᥋"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᥌"),l1l111_l1_ (u"ࠩࠪ᥍"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᥎"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ᥏"),l1l111_l1_ (u"ࠬ࠭ᥐ"),309,l1l111_l1_ (u"࠭ࠧᥑ"),l1l111_l1_ (u"ࠧࠨᥒ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᥓ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᥔ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᥕ"),l1l111_l1_ (u"ࠫࠬᥖ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᥗ"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬᥘ"),l1l111_l1_ (u"ࠧࠨᥙ"),l1l111_l1_ (u"ࠨࠩᥚ"),l1l111_l1_ (u"ࠩࠪᥛ"),l1l111_l1_ (u"ࠪࠫᥜ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᥝ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨࡦࡣࡧࡩࡷࡄࠧᥞ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᥟ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩᥠ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᥡ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᥢ")+l1lllll_l1_+title,l1ll1ll_l1_,301)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᥣ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᥤ"),l1l111_l1_ (u"ࠬ࠭ᥥ"),9999)
	l11ll1_l1_(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡩࡱࡰࡩࠬᥦ"),html)
	return html
def l1111111l_l1_():
	l1111l1_l1_(l1l111_l1_ (u"ࠧࠨᥧ"),l1l111_l1_ (u"ࠨࠩᥨ"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᥩ"),l1l111_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠣฬ฼๐มࠡ็้ࠤฬ๊ๅึัิࠤ࠳࠴ࠠษีหฬ่๊ࠥศ็ࠣวฺำวษࠢส่๊๎โฺࠢหฮู็๊า่ࠢัฯ๎๊ศฬࠣะ๊๐ูࠡืไัฬะࠠศๆ่์็฿ࠠ࠯࠰ࠣ์ฬ๊่ใฬࠣห้฼วว฻ࠣ๎ีํศࠡใํࠤ๊฿วๅฮฬࠤฯฺแ๋ำࠣห้฻แฮษอࠤฬ๊ๅีใิอ่ࠥศๅࠢ฼ี฻ࠦๅฮฬ๋๎ฬะ็ศࠢไ๎่่ࠥศศ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠪᥪ"))
	return
def l11ll1_l1_(url,html=l1l111_l1_ (u"ࠫࠬᥫ")):
	if not html:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᥬ"),url,l1l111_l1_ (u"࠭ࠧᥭ"),l1l111_l1_ (u"ࠧࠨ᥮"),l1l111_l1_ (u"ࠨࠩ᥯"),l1l111_l1_ (u"ࠩࠪᥰ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩᥱ"))
		html = response.content
	seq = 0
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡂࡳࡦࡥࡷ࡭ࡴࡴ࠾࠯ࠬࡂࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠩࠨᥲ"),html,re.DOTALL)
	if l11llll_l1_:
		for block in l11llll_l1_:
			seq += 1
			items = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡦࡥࡷ࡭ࡴࡴ࠾࠯࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᥳ"),block,re.DOTALL)
			for title,test,l1ll1ll_l1_ in items:
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨᥴ"))
				if title==l1l111_l1_ (u"ࠧࠨ᥵"): title = l1l111_l1_ (u"ࠨส๋์ํ๎่ࠨ᥶")
				if l1l111_l1_ (u"ࠩࡨࡱࡃࡂࡡࠨ᥷") not in test:
					if block.count(l1l111_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧ᥸"))>0:
						l11111111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᥹"),block,re.DOTALL)
						for l1ll1ll_l1_ in l11111111_l1_:
							title = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠬ࠵ࠧ᥺"))[-2]
							addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᥻"),l1lllll_l1_+title,l1ll1ll_l1_,301)
						continue
					else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠧࡀࡵࡨࡵࡺ࡫࡮ࡤࡧࡀࠫ᥼")+str(seq)
				if not any(value in title for value in l11lll_l1_):
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᥽"),l1lllll_l1_+title,l1ll1ll_l1_,302)
	else: l1lll11_l1_(url,html)
	return
def l1lll11_l1_(url,html=l1l111_l1_ (u"ࠩࠪ᥾")):
	if html==l1l111_l1_ (u"ࠪࠫ᥿"):
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᦀ"),url,l1l111_l1_ (u"ࠬ࠭ᦁ"),l1l111_l1_ (u"࠭ࠧᦂ"),l1l111_l1_ (u"ࠧࠨᦃ"),l1l111_l1_ (u"ࠨࠩᦄ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᦅ"))
		html = response.content
	if l1l111_l1_ (u"ࠪࡃࡸ࡫ࡱࡶࡧࡱࡧࡪࡃࠧᦆ") in url:
		url,seq = url.split(l1l111_l1_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨᦇ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠼ࡴࡧࡦࡸ࡮ࡵ࡮࠿࠰࠭ࡃࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠪࠩᦈ"),html,re.DOTALL)
		block = l11llll_l1_[int(seq)-1]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡱࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡰࡦࡼࡂࠬᦉ"),html,re.DOTALL)
		block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧ࠽ࡣ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᦊ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1ll_l1_,data,l1ll1l_l1_ in items:
		title = re.findall(l1l111_l1_ (u"ࠨ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠳࠰࠿࠽࠱ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࡪࡳ࠾ࠨᦋ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l1l111_l1_ (u"ࠩ࡟ࡲࠬᦌ"),l1l111_l1_ (u"ࠪࠫᦍ")).strip(l1l111_l1_ (u"ࠫࠥ࠭ᦎ"))
		if not title or title==l1l111_l1_ (u"ࠬ࠭ᦏ"):
			title = re.findall(l1l111_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠧࡄ࠮ࠫࡁ࠿࠳ࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᦐ"),data,re.DOTALL)
			if title: title = title[0].replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪᦑ"),l1l111_l1_ (u"ࠨࠩᦒ")).strip(l1l111_l1_ (u"ࠩࠣࠫᦓ"))
			if not title or title==l1l111_l1_ (u"ࠪࠫᦔ"):
				title = re.findall(l1l111_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᦕ"),data,re.DOTALL)
				title = title[0].replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨᦖ"),l1l111_l1_ (u"࠭ࠧᦗ")).strip(l1l111_l1_ (u"ࠧࠡࠩᦘ"))
		title = unescapeHTML(title)
		if title not in l1l1_l1_:
			l1l1_l1_.append(title)
			l1l1l1l_l1_ = l1ll1ll_l1_+data+l1ll1l_l1_
			if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡱࡧࡲࡺ࠱ࠪᦙ") in l1l1l1l_l1_ or l1l111_l1_ (u"่ࠩืู้ไࠨᦚ") in l1l1l1l_l1_ or l1l111_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࠧ࠭ᦛ") in l1l1l1l_l1_:
				if l1l111_l1_ (u"ࠫอืวๆฮࠪᦜ") in data: title = l1l111_l1_ (u"ࠬฮั็ษ่ะࠥ࠭ᦝ")+title
				elif l1l111_l1_ (u"࠭ๅิๆึ่ࠬᦞ") in data or l1l111_l1_ (u"ࠧๆ๊ึ้ࠬᦟ") in data: title = l1l111_l1_ (u"ࠨ็ึุ่๊ࠠࠨᦠ")+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᦡ"),l1lllll_l1_+title,l1ll1ll_l1_,303,l1ll1l_l1_)
			else: addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᦢ"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᦣ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᦤ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦥ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ᦦ")+title,l1ll1ll_l1_,302)
	return
def l111l1lll_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᦧ"),url,l1l111_l1_ (u"ࠩࠪᦨ"),l1l111_l1_ (u"ࠪࠫᦩ"),l1l111_l1_ (u"ࠫࠬᦪ"),l1l111_l1_ (u"ࠬ࠭ᦫ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡔࡇࡄࡗࡔࡔࡓ࠮࠳ࡶࡸࠬ᦬"))
	html = response.content
	name = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵ࡫ࡷࡰࡪࡄࠧ᦭"),html,re.DOTALL)
	name = name[0].replace(l1l111_l1_ (u"ࠨࡾࠣื๏๋ว่ࠡส์ࠬ᦮"),l1l111_l1_ (u"ࠩࠪ᦯")).replace(l1l111_l1_ (u"ࠪࡇ࡮ࡳࡡࠡࡐࡲࡻࠬᦰ"),l1l111_l1_ (u"ࠫࠬᦱ")).strip(l1l111_l1_ (u"ࠬࠦࠧᦲ")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩᦳ"),l1l111_l1_ (u"ࠧࠡࠩᦴ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡶࡩࡦࡹ࡯࡯ࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬᦵ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᦶ"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠪࡠࡳ࠭ᦷ"),l1l111_l1_ (u"ࠫࠬᦸ")).strip(l1l111_l1_ (u"ࠬࠦࠧᦹ"))
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦺ"),l1lllll_l1_+title,l1ll1ll_l1_,304)
		else: l1ll1l11_l1_(url)
	return
def l1ll1l11_l1_(url):
	if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡰࡦࡸࡹ࠰ࠩᦻ") not in url: url = url.strip(l1l111_l1_ (u"ࠨ࠱ࠪᦼ"))+l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࡫ࡱ࡫ࠬᦽ")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᦾ"),url,l1l111_l1_ (u"ࠫࠬᦿ"),l1l111_l1_ (u"ࠬ࠭ᧀ"),l1l111_l1_ (u"࠭ࠧᧁ"),l1l111_l1_ (u"ࠧࠨᧂ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨᧃ"))
	html = response.content
	if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡲࡡࡳࡻ࠲ࠫᧄ") not in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡪࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᧅ"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᧆ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨᧇ"),l1l111_l1_ (u"࠭ࠧᧈ")).strip(l1l111_l1_ (u"ࠧࠡࠩᧉ"))
			title = l1l111_l1_ (u"ࠨษ็ั้่ษࠡࠩ᧊")+title
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᧋"),l1lllll_l1_+title,l1ll1ll_l1_,305)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡩ࡫ࡴࡢ࡫࡯ࡷࠧ࠮࠮ࠫࡁࠬࠦࡷ࡫࡬ࡢࡶࡨࡨࠧ࠭᧌"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᧍"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨ᧎"),l1l111_l1_ (u"࠭ࠧ᧏")).strip(l1l111_l1_ (u"ࠧࠡࠩ᧐"))
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᧑"),l1lllll_l1_+title,l1ll1ll_l1_,305,l1ll1l_l1_)
	return
def PLAY(url):
	l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩࡺࡥࡹࡩࡨࡪࡰࡪ࠳ࠬ᧒")
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ᧓"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ᧔"),l1l111_l1_ (u"ࠬ࠭᧕"),l1l111_l1_ (u"࠭ࠧ᧖"),l1l111_l1_ (u"ࠧࠨ᧗"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫ᧘"))
	html = response.content
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᧙"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ᧚"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠫࡡࡴࠧ᧛"),l1l111_l1_ (u"ࠬ࠭᧜")).strip(l1l111_l1_ (u"࠭ࠠࠨ᧝"))
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ᧞"),title,re.DOTALL)
			if l111l1ll_l1_:
				l111l1ll_l1_ = l1l111_l1_ (u"ࠨࡡࡢࡣࡤ࠭᧟")+l111l1ll_l1_[0]
				title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ᧠"))
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠫ᧡")
			l111lllll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᧢")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ᧣")+l111l1ll_l1_
			l1llll_l1_.append(l111lllll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡸࡣࡷࡧ࡭ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᧤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠱࠲࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭᧥"),block,re.DOTALL)
		for l1ll1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ᧦")+l1ll1ll_l1_
			title = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ᧧"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᧨")+title+l1l111_l1_ (u"ࠫࡤࡥࡥ࡮ࡤࡨࡨࠬ᧩")
			l1llll_l1_.append(l1ll1ll_l1_)
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࡟ࠬࢀࡻࡲ࡭࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ᧪"),html,re.DOTALL)
		if l1ll_l1_:
			items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡴࡤࡦࡺࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ᧫"),block,re.DOTALL)
			for index,id,title in items:
				title = title.replace(l1l111_l1_ (u"ࠧ࡝ࡰࠪ᧬"),l1l111_l1_ (u"ࠨࠩ᧭")).strip(l1l111_l1_ (u"ࠩࠣࠫ᧮"))
				title = title.replace(l1l111_l1_ (u"ࠪࡇ࡮ࡳࡡࠡࡐࡲࡻࠬ᧯"),l1l111_l1_ (u"ࠫࡈ࡯࡭ࡢࡐࡲࡻࠬ᧰"))
				l1ll1ll_l1_ = l1ll_l1_[0]+l1l111_l1_ (u"ࠬࡅࡡࡤࡶ࡬ࡳࡳࡃࡳࡸ࡫ࡷࡧ࡭ࠬࡩ࡯ࡦࡨࡼࡂ࠭᧱")+index+l1l111_l1_ (u"࠭ࠦࡪࡦࡀࠫ᧲")+id+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᧳")+title+l1l111_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ᧴")
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᧵"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫ᧶"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬ᧷"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧ᧸"),l1l111_l1_ (u"࠭ࠫࠨ᧹"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ᧺")+search
	l1lll11_l1_(url)
	return
﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
def l11l1ll_l1_(mode,l1ll111111l_l1_):
	if l1ll111111l_l1_==l1l111_l1_ (u"ࠧࠨガ"): return
	if mode==1:
		l1l1lllllll_l1_ = xbmcgui.l1l1llllll1_l1_()
		l1ll1111111_l1_ = xbmcgui.l1l1lllll1l_l1_(l1l1lllllll_l1_)
		l1ll111111l_l1_ = l1l1lllll11_l1_(l1ll111111l_l1_)
		l1ll1111111_l1_.getControl(311).l1ll11111l1_l1_(l1ll111111l_l1_)
	if mode==0:
		l1l1llll11l_l1_=l1l111_l1_ (u"ࠨ࡚ࠪキ")
		if kodi_version>18.99: check = isinstance(l1ll111111l_l1_,str)
		else: check = isinstance(l1ll111111l_l1_,unicode)
		if check==True: l1l1llll11l_l1_=l1l111_l1_ (u"ࠩࡘࠫギ")
		l1l1llll111_l1_=str(type(l1ll111111l_l1_))+l1l111_l1_ (u"ࠪࠤࠬク")+l1ll111111l_l1_+l1l111_l1_ (u"ࠫࠥ࠭グ")+l1l1llll11l_l1_+l1l111_l1_ (u"ࠬࠦࠧケ")
		for i in range(0,len(l1ll111111l_l1_),1):
			l1l1llll111_l1_ += hex(ord(l1ll111111l_l1_[i])).replace(l1l111_l1_ (u"࠭࠰ࡹࠩゲ"),l1l111_l1_ (u"ࠧࠨコ"))+l1l111_l1_ (u"ࠨࠢࠪゴ")
		l1ll111111l_l1_ = l1l1lllll11_l1_(l1ll111111l_l1_)
		l1l1llll11l_l1_=l1l111_l1_ (u"࡛ࠩࠫサ")
		if kodi_version>18.99: check = isinstance(l1ll111111l_l1_, str)
		else: check = isinstance(l1ll111111l_l1_, unicode)
		if check==True: l1l1llll11l_l1_=l1l111_l1_ (u"࡙ࠪࠬザ")
		l1l1llll1l1_l1_=str(type(l1ll111111l_l1_))+l1l111_l1_ (u"ࠫࠥ࠭シ")+l1ll111111l_l1_+l1l111_l1_ (u"ࠬࠦࠧジ")+l1l1llll11l_l1_+l1l111_l1_ (u"࠭ࠠࠨス")
		for i in range(0,len(l1ll111111l_l1_),1):
			l1l1llll1l1_l1_ += hex(ord(l1ll111111l_l1_[i])).replace(l1l111_l1_ (u"ࠧ࠱ࡺࠪズ"),l1l111_l1_ (u"ࠨࠩセ"))+l1l111_l1_ (u"ࠩࠣࠫゼ")
	return
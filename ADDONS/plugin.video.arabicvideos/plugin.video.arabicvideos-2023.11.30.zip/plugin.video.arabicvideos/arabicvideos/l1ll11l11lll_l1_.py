# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ啶")
headers = l1l111_l1_ (u"ࠫࠬ啷")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫ啸")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫ啹"),l1l111_l1_ (u"ࠧศๆๆ่ࠬ啺"),l1l111_l1_ (u"ࠨษไ่ฬ๋ࠧ啻"),l1l111_l1_ (u"ࠩ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹ࠭啼"),l1l111_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ啽")]
def l11l1ll_l1_(mode,url,text):
	if   mode==110: l1lll_l1_ = l1l1l11_l1_()
	elif mode==111: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==112: l1lll_l1_ = PLAY(url)
	elif mode==113: l1lll_l1_ = l1ll1l11_l1_(url,True)
	elif mode==114: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ啾")+text)
	elif mode==115: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ啿")+text)
	elif mode==116: l1lll_l1_ = l1ll1l11_l1_(url,False)
	elif mode==119: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	l1l11ll_l1_,url,response = l1lll1llll1_l1_(l111l1_l1_,l1l111_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ喀"),l1l111_l1_ (u"ࠧีษ๊ำࠥ็่า์๋ࠤ࠲ࠦࡓࡩࡣ࡫࡭ࡩࠦ࠴ࡶࠩ喁"),l1l111_l1_ (u"ࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨ喂"),headers)
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ喃"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ善"),l1l111_l1_ (u"ࠫࠬ喅"),119,l1l111_l1_ (u"ࠬ࠭喆"),l1l111_l1_ (u"࠭ࠧ喇"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ喈"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喉"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ喊"),l1l11ll_l1_,115)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喋"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ喌"),l1l11ll_l1_,114)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ喍"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭喎"),l1l111_l1_ (u"ࠧࠨ喏"),9999)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ喐"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่๊๋๊ำหࠪ喑"),l1l11ll_l1_,111,l1l111_l1_ (u"ࠪࠫ喒"),l1l111_l1_ (u"ࠫࠬ喓"),l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ喔"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡪ࡯ࡳࡰࡪ࠳ࡦࡪ࡮ࡷࡩࡷ࠮࠮ࠫࡁࠬࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠧ喕"),html,re.DOTALL)
	if not l11llll_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ喖"),l1l111_l1_ (u"ࠨࠩ喗"),l1l111_l1_ (u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫ喘"),l1l111_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡวํะฬีฺ่๋ࠠห๋ࠦวๅ็๋ๆ฾ࠦร้ࠢอู๊๐ๅࠡษ็้ํู่ࠡฬ฽๎ึ࠭喙"))
		return
	else:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳࠦ࠽ࠡ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ喚"),block,re.DOTALL)
		for filter,l1ll1l_l1_,title in items:
			url = l1l11ll_l1_+filter
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喛"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ喜")+l1lllll_l1_+title,url,111,l1ll1l_l1_,l1l111_l1_ (u"ࠧࠨ喝"),filter)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭喞"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ喟"),l1l111_l1_ (u"ࠪࠫ喠"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡩࡸ࡯ࡱࡦࡲࡻࡳࠨࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࡃ࠭喡"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ喢"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ喣"),l1l111_l1_ (u"ࠧࠨ喤")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ喥"),l1l111_l1_ (u"ࠩࠪ喦")).strip(l1l111_l1_ (u"ࠪࠤࠬ喧"))
			if title in l11lll_l1_: continue
			if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ喨") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭喩") in l1ll1ll_l1_: title = l1l111_l1_ (u"࠭ๆ๋ฬไู่่ࠧ喪")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ喫"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ喬")+l1lllll_l1_+title,l1ll1ll_l1_,111)
	return html
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠩࠪ喭"),response=l1l111_l1_ (u"ࠪࠫ單")):
	if not response: response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ喯"),url,l1l111_l1_ (u"ࠬ࠭喰"),headers,l1l111_l1_ (u"࠭ࠧ喱"),l1l111_l1_ (u"ࠧࠨ喲"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ喳"))
	html = response.content
	l11llll_l1_,items,l1l1_l1_ = [],[],[]
	if l111l1l1l_l1_==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ喴"): l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡫ࡱ࡯ࡤࡦࡡࡢࡷࡱ࡯ࡤࡦࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭喵"),html,re.DOTALL)
	else: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ営"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂࠬ喷"),block,re.DOTALL)
	l1ll11_l1_ = [l1l111_l1_ (u"࠭ๅีษ๊ำฮ࠭喸"),l1l111_l1_ (u"ࠧโ์็้ࠬ喹"),l1l111_l1_ (u"ࠨษ฽๊๏ฯࠧ喺"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ喻"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ喼"),l1l111_l1_ (u"ࠫ์ีวโࠩ喽"),l1l111_l1_ (u"๋ࠬศศำสอࠬ喾"),l1l111_l1_ (u"ู࠭าุࠪ喿"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ嗀"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ嗁")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠩ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹ࠭嗂") in l1ll1ll_l1_: continue
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠪ࠳ࠬ嗃"))
		title = unescapeHTML(title)
		title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭嗄"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡡࡪࠫࠨ嗅"),title,re.DOTALL)
		if l1l111_l1_ (u"࠭แ๋ๆ่ࠫ嗆") in l1ll1ll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嗇"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠨษ็ั้่ษࠨ嗈") in title and l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ嗉") not in url:
			title = l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ嗊") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嗋"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠬ࠵ࡡࡤࡶࡲࡶ࠴࠭嗌") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嗍"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ嗎") in l1ll1ll_l1_ and l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ嗏") not in url:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ嗐")
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗑"),l1lllll_l1_+title,l1ll1ll_l1_,111,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠫ࠴ࡲࡩࡴࡶࠪ嗒") in url and l1l111_l1_ (u"ࠬำไใหࠪ嗓") in title:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嗔"),l1lllll_l1_+title,l1ll1ll_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗕"),l1lllll_l1_+title,l1ll1ll_l1_,113,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ嗖"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l111l1l1l_l1_!=l1l111_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ嗗"): items = re.findall(l1l111_l1_ (u"ࠪࠬࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺࠫ࠱࠮ࡄࡄࠨ࠯࠭ࡂ࠭ࡁ࠭嗘"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠫࡁࡲࡩ࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嗙"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l111l1l1l_l1_!=l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ嗚"):
				title = title.replace(l1l111_l1_ (u"࠭࡜࡯ࠩ嗛"),l1l111_l1_ (u"ࠧࠨ嗜")).replace(l1l111_l1_ (u"ࠨ࡞ࡵࠫ嗝"),l1l111_l1_ (u"ࠩࠪ嗞"))
				if l1l111_l1_ (u"ࠪࡃࠬ嗟") in url: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ嗠")+title
				else: l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬࡅࡰࡢࡩࡨࡁࠬ嗡")+title
			title = unescapeHTML(title)
			if title: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嗢"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭嗣")+title,l1ll1ll_l1_,111,l1l111_l1_ (u"ࠨࠩ嗤"),l1l111_l1_ (u"ࠩࠪ嗥"),l111l1l1l_l1_)
	return
def l1ll1l11_l1_(url,l111lllll1l1_l1_):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嗦"),url,l1l111_l1_ (u"ࠫࠬ嗧"),headers,l1l111_l1_ (u"ࠬ࠭嗨"),l1l111_l1_ (u"࠭ࠧ嗩"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ嗪"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡹࠠࡥ࠯ࡩࡰࡪࡾࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ嗫"),html,re.DOTALL)
	if len(l11llll_l1_)>1:
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫ嗬") in l11llll_l1_[0]: l111l1l111_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[1]
		else: l111l1l111_l1_,l1l1l1l1_l1_ = l11llll_l1_[1],l11llll_l1_[0]
	else: l111l1l111_l1_,l1l1l1l1_l1_ = l11llll_l1_[0],l11llll_l1_[0]
	for l1l11l111l_l1_ in range(2):
		if l111lllll1l1_l1_: mode,type,block = 116,l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗭"),l111l1l111_l1_
		else: mode,type,block = 112,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嗮"),l1l1l1l1_l1_
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡵࡧ࡮࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嗯"),block,re.DOTALL)
		if l111lllll1l1_l1_ and len(items)<2:
			l111lllll1l1_l1_ = False
			continue
		for l1ll1ll_l1_,l1l11l1ll_l1_,l1lllllll_l1_ in items:
			title = l1l11l1ll_l1_+l1l111_l1_ (u"࠭ࠠࠨ嗰")+l1lllllll_l1_
			addMenuItem(type,l1lllll_l1_+title,l1ll1ll_l1_,mode)
		break
	if not items and l1l111_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ嗱") in html:
		l111ll111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡵࡩࡦࡪࡣࡳࡷࡰࡦࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嗲"),html,re.DOTALL)
		if l111ll111_l1_:
			block = l111ll111_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ嗳"),block,re.DOTALL)
			if len(l1ll_l1_)>2:
				l1ll1ll_l1_ = l1ll_l1_[2]+l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ嗴")
				l1lll11_l1_(l1ll1ll_l1_)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ嗵"),url,l1l111_l1_ (u"ࠬ࠭嗶"),headers,l1l111_l1_ (u"࠭ࠧ嗷"),l1l111_l1_ (u"ࠧࠨ嗸"),l1l111_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ嗹"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡤࡧࡹ࡯࡯࡯ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ嗺"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗻"),block,re.DOTALL)
	l111lllll1ll_l1_ = l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ嗼") in block
	download = l1l111_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩ嗽") in block
	if   l111lllll1ll_l1_ and not download: l111llllll11_l1_,l111lllll11l_l1_ = l1ll_l1_[0],l1l111_l1_ (u"࠭ࠧ嗾")
	elif not l111lllll1ll_l1_ and download: l111llllll11_l1_,l111lllll11l_l1_ = l1l111_l1_ (u"ࠧࠨ嗿"),l1ll_l1_[0]
	elif l111lllll1ll_l1_ and download: l111llllll11_l1_,l111lllll11l_l1_ = l1ll_l1_[0],l1ll_l1_[1]
	else: l111llllll11_l1_,l111lllll11l_l1_ = l1l111_l1_ (u"ࠨࠩ嘀"),l1l111_l1_ (u"ࠩࠪ嘁")
	if l111lllll1ll_l1_:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嘂"),l111llllll11_l1_,l1l111_l1_ (u"ࠫࠬ嘃"),headers,l1l111_l1_ (u"ࠬ࠭嘄"),l1l111_l1_ (u"࠭ࠧ嘅"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ嘆"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡮ࡨࡸࠥࡹࡥࡳࡸࡨࡶࡸ࠮࠮ࠫࡁࠬࡴࡱࡧࡹࡦࡴࠪ嘇"),l11l1ll1_l1_,re.DOTALL|re.IGNORECASE)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡳࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ嘈"),l1l1l1l_l1_,re.DOTALL)
			for title,l1ll1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ嘉"),l1l111_l1_ (u"ࠫ࠴࠭嘊"))
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭嘋")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ嘌")
				l1llll_l1_.append(l1ll1ll_l1_)
	if download:
		response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ嘍"),l111lllll11l_l1_,l1l111_l1_ (u"ࠨࠩ嘎"),headers,l1l111_l1_ (u"ࠩࠪ嘏"),l1l111_l1_ (u"ࠪࠫ嘐"),l1l111_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ嘑"))
		l11l1ll1_l1_ = response.content
		l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࠢࠩ࠰࠭ࡃ࠮࡯࡮ࡧࡱ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭嘒"),l11l1ll1_l1_,re.DOTALL)
		if l11ll11_l1_:
			l1l1l1l_l1_ = l11ll11_l1_[0]
			l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾࠲࡭ࡃ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ嘓"),l1l1l1l_l1_,re.DOTALL)
			for l1ll1ll_l1_,title,l111l1ll_l1_ in l1l1111_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ嘔")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ嘕")+l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ嘖")+l111l1ll_l1_
				l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嘗"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭嘘"),l1l111_l1_ (u"ࠬ࠱ࠧ嘙"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ嘚")+search
	l1l11ll_l1_,l1lllll1_l1_,l1lll1l11_l1_ = l1lll1llll1_l1_(url,l1l111_l1_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ嘛"),l1l111_l1_ (u"ࠨึส๋ิࠦแ้ำํ์ࠥ࠳ࠠࡔࡪࡤ࡬࡮ࡪࠠ࠵ࡷࠪ嘜"),l1l111_l1_ (u"ࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩ嘝"),headers)
	l1lll11_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ嘞"),l1lll1l11_l1_)
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ嘟"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嘠"),url,l1l111_l1_ (u"࠭ࠧ嘡"),headers,l1l111_l1_ (u"ࠧࠨ嘢"),l1l111_l1_ (u"ࠨࠩ嘣"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡌࡋࡔࡠࡈࡌࡐ࡙ࡋࡒࡔࡡࡅࡐࡔࡉࡋࡔ࠯࠴ࡷࡹ࠭嘤"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡩࡼ࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡸ࡮࡯ࡸࡵ࠰ࡧࡴࡴࡴࡢ࡫ࡱࡩࡷ࠭嘥"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡕࡺ࡫ࡲࡺ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࠩ嘦"),block,re.DOTALL)
		l1111lll1_l1_,names,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111lll1_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿࡞ࡶ࠮࠭࠴ࠪࡀࠫ࡟ࡷ࠯ࡂࠧ嘧"),block,re.DOTALL)
	return items
def l1111ll11_l1_(url):
	if l1l111_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ嘨") not in url: url = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ嘩")
	l11l11111_l1_ = url.split(l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ嘪"))[0]
	l111lll1l_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭嘫"))
	url = url.replace(l11l11111_l1_,l111lll1l_l1_)
	url = url.replace(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ嘬"),l1l111_l1_ (u"ࠫ࠴ࡅࠧ嘭"))
	return url
l1111ll1l_l1_ = [l1l111_l1_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭嘮"),l1l111_l1_ (u"࠭ࡹࡦࡣࡵࠫ嘯"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭嘰"),l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ嘱")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ嘲"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ嘳"),l1l111_l1_ (u"ࠫࡾ࡫ࡡࡳࠩ嘴")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ嘵"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嘶"),1)
	if filter==l1l111_l1_ (u"ࠧࠨ嘷"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩ嘸"),l1l111_l1_ (u"ࠩࠪ嘹")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧ嘺"))
	if type==l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ嘻"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠬࡃࠧ嘼") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"࠭࠽ࠨ嘽") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ嘾")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫ嘿")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ噀")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭噁")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭噂"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ噃")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨ噄"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ噅"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ噆")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ噇"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ噈"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠫࠬ噉"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ噊"))
		if l11lll11_l1_==l1l111_l1_ (u"࠭ࠧ噋"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ噌")+l11lll11_l1_
		l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噍"),l1lllll_l1_+l1l111_l1_ (u"ࠩฦ฼์อัࠡไสส๊ฯࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสๆࠢสาฯ๐วา้สࠤࠬ噎"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噏"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫ噐")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫ噑"),l1llllll_l1_,111)
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ噒"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ噓"),l1l111_l1_ (u"ࠨࠩ噔"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"ࠩๆ่ࠥ࠭噕"),l1l111_l1_ (u"ࠪࠫ噖"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠫࡂ࠭噗") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭噘"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡄࡆࡈࡌࡒࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ噙")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ噚"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩ噛"),l1llllll_l1_,111)
				else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ噜"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣࠫ噝"),l1lllll1_l1_,115,l1l111_l1_ (u"ࠫࠬ噞"),l1l111_l1_ (u"ࠬ࠭噟"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"࠭ࡆࡖࡎࡏࡣࡋࡏࡌࡕࡇࡕࠫ噠"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩ噡")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ噢")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫ噣")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁ࠵࠭噤")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ噥")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ噦"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨ噧")+name,l1lllll1_l1_,114,l1l111_l1_ (u"ࠧࠨ器"),l1l111_l1_ (u"ࠨࠩ噩"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if value==l1l111_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ噪"): option = l1l111_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ噫")
			elif value==l1l111_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ噬"): option = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ噭")
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ噮")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ噯")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪ噰")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫ噱")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ噲")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧ噳")#+dict[l1l111ll_l1_][l1l111_l1_ (u"ࠬ࠶ࠧ噴")]
			title = option+l1l111_l1_ (u"࠭ࠠ࠻ࠩ噵")+name
			if type==l1l111_l1_ (u"ࠧࡇࡗࡏࡐࡤࡌࡉࡍࡖࡈࡖࠬ噶"): addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噷"),l1lllll_l1_+title,url,114,l1l111_l1_ (u"ࠩࠪ噸"),l1l111_l1_ (u"ࠪࠫ噹"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ噺") and l111l111l_l1_[-2]+l1l111_l1_ (u"ࠬࡃࠧ噻") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ噼"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ噽")+l11ll111_l1_
				l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噾"),l1lllll_l1_+title,l1llllll_l1_,111)
			else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ噿"),l1lllll_l1_+title,url,115,l1l111_l1_ (u"ࠪࠫ嚀"),l1l111_l1_ (u"ࠫࠬ嚁"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠬࡃࠦࠨ嚂"),l1l111_l1_ (u"࠭࠽࠱ࠨࠪ嚃"))
	filters = filters.strip(l1l111_l1_ (u"ࠧࠧࠩ嚄"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠨ࠿ࠪ嚅") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠫ嚆"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࠬ嚇"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠫࠬ嚈")
	for key in l1111ll1l_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠬ࠶ࠧ嚉")
		if l1l111_l1_ (u"࠭ࠥࠨ嚊") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ嚋") and value!=l1l111_l1_ (u"ࠨ࠲ࠪ嚌"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭嚍")+value
		elif mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嚎") and value!=l1l111_l1_ (u"ࠫ࠵࠭嚏"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠬࠧ嚐")+key+l1l111_l1_ (u"࠭࠽ࠨ嚑")+value
		elif mode==l1l111_l1_ (u"ࠧࡢ࡮࡯ࠫ嚒"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪ嚓")+key+l1l111_l1_ (u"ࠩࡀࠫ嚔")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠤ࠰ࠦࠧ嚕"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭嚖"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠬࡃ࠰ࠨ嚗"),l1l111_l1_ (u"࠭࠽ࠨ嚘"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧᶕ")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡆࡕ࠻ࡤ࠭ᶖ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪᶗ"),l1l111_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪᶘ"),l1l111_l1_ (u"ࠪฮุา๊ๅࠩᶙ")]
def l11l1ll_l1_(mode,url,text):
	if   mode==680: l1lll_l1_ = l1l1l11_l1_()
	elif mode==681: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==682: l1lll_l1_ = PLAY(url)
	elif mode==683: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==684: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==689: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᶚ"),l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ᶛ"),l1l111_l1_ (u"࠭ࠧᶜ"),l1l111_l1_ (u"ࠧࠨᶝ"),l1l111_l1_ (u"ࠨࠩᶞ"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᶟ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶠ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᶡ"),l1l111_l1_ (u"ࠬ࠭ᶢ"),689,l1l111_l1_ (u"࠭ࠧᶣ"),l1l111_l1_ (u"ࠧࠨᶤ"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶥ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᶦ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᶧ"),l1l111_l1_ (u"ࠫࠬᶨ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶩ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᶪ")+l1lllll_l1_+l1l111_l1_ (u"ࠧอัํำࠥอไฮๆๅหฯ࠭ᶫ"),l111l1_l1_,681,l1l111_l1_ (u"ࠨࠩᶬ"),l1l111_l1_ (u"ࠩࠪᶭ"),l1l111_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᶮ"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᶯ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᶰ")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่๊๋๊ำหࠪᶱ"),l111l1_l1_,681,l1l111_l1_ (u"ࠧࠨᶲ"),l1l111_l1_ (u"ࠨࠩᶳ"),l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᶴ"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᶵ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᶶ"),l1l111_l1_ (u"ࠬ࠭ᶷ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪᶸ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᶹ"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠨࠩᶺ"))
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᶻ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᶽ")+l1lllll_l1_+title,l1ll1ll_l1_,684)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᶾ"),url,l1l111_l1_ (u"࠭ࠧᶿ"),l1l111_l1_ (u"ࠧࠨ᷀"),l1l111_l1_ (u"ࠨࠩ᷁"),l1l111_l1_ (u"᷂ࠩࠪ"),l1l111_l1_ (u"ࠪࡈࡗࡇࡍࡂࡕ࠺࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ᷃"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᷄"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭᷅"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ᷆"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᷇"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩ᷈"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ᷉"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᷊"),l1l111_l1_ (u"ࠫࠬ᷋"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ᷌"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩ᷍")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ᷎ࠧ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂ᷏ࠬ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ᷐ࠫ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᷑"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᷒"),l1l111_l1_ (u"ࠬ࠭ᷓ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᷔ"),l1lllll_l1_+title,l1ll1ll_l1_,681)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨᷕ")):
	if request==l1l111_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ᷖ"):
		url,search = url.split(l1l111_l1_ (u"ࠩࡂࠫᷗ"),1)
		data = l1l111_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩᷘ")+search
		headers = {l1l111_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᷙ"):l1l111_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬᷚ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫᷛ"),url,data,headers,l1l111_l1_ (u"ࠧࠨᷜ"),l1l111_l1_ (u"ࠨࠩᷝ"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᷞ"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᷟ"),url,l1l111_l1_ (u"ࠫࠬᷠ"),l1l111_l1_ (u"ࠬ࠭ᷡ"),l1l111_l1_ (u"࠭ࠧᷢ"),l1l111_l1_ (u"ࠧࠨᷣ"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᷤ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠩࠪᷥ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧᷦ"))
	if request==l1l111_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩᷧ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᷨ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"࠭ࠧᷩ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩᷪ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᷫ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨᷬ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᷭ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨᷮ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᷯ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨᷰ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩᷱ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᷲ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠩࠪᷳ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᷴ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ᷵"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ᷶"),l1l111_l1_ (u"࠭แ๋ๆ่᷷ࠫ"),l1l111_l1_ (u"ࠧศ฼้๎ฮ᷸࠭"),l1l111_l1_ (u"ࠨๅ็๎อ᷹࠭"),l1l111_l1_ (u"ࠩส฽้อๆࠨ᷺"),l1l111_l1_ (u"๋ࠪิอแࠨ᷻"),l1l111_l1_ (u"๊ࠫฮวาษฬࠫ᷼"),l1l111_l1_ (u"ࠬ฿ัื᷽ࠩ"),l1l111_l1_ (u"࠭ๅ่ำฯห๋࠭᷾"),l1l111_l1_ (u"ࠧศๆห์๊᷿࠭"),l1l111_l1_ (u"ࠨ็ึีา๐ษࠨḀ")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬḁ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩḂ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪḃ"):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫḄ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬḅ") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḆ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨḇ"),l1lllll_l1_+title,l1ll1ll_l1_,683,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪḈ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨḉ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭Ḋ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧḋ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨḌ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḍ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧḎ")+title,l1ll1ll_l1_,681)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ḏ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧḐ"),url,l1l111_l1_ (u"ࠫࠬḑ"),l1l111_l1_ (u"ࠬ࠭Ḓ"),l1l111_l1_ (u"࠭ࠧḓ"),l1l111_l1_ (u"ࠧࠨḔ"),l1l111_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨḕ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬḖ"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬḗ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠫࠬḘ")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡰࡰࡦࡰ࡮ࡩ࡫࠾ࠤࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰ࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬḙ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"࠭ࠣࠨḚ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧḛ"),l1lllll_l1_+title,url,683,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩḜ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠧḝ")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨḞ"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࡀࡱ࡯࠾࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠥḟ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫḠ"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨḡ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩḢ"))
			title = title.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡩࡲࡄ࠼ࡴࡲࡤࡲࡃ࠭ḣ"),l1l111_l1_ (u"ࠩࠣࠫḤ"))
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩḥ"),l1lllll_l1_+title,l1ll1ll_l1_,682,l1ll1l_l1_)
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨḦ"),url,l1l111_l1_ (u"ࠬ࠭ḧ"),l1l111_l1_ (u"࠭ࠧḨ"),l1l111_l1_ (u"ࠧࠨḩ"),l1l111_l1_ (u"ࠨࠩḪ"),l1l111_l1_ (u"ࠩࡇࡖࡆࡓࡁࡔ࠹࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬḫ"))
	html = response.content
	l1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦ࡮ࡹࡆࡰࡴࡰࡗࡪࡸࡶࡴࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪḬ"),html,re.DOTALL)
	if not l1ll11l_l1_: l1ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶ࡬ࡢࡻ࠰ࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡶ࡯ࡴࡶࡀࠬ࠳࠰࠿ࠪࠤࠪḭ"),html,re.DOTALL)
	l1ll11l_l1_ = base64.b64decode(l1ll11l_l1_[0])
	if kodi_version>18.99: l1ll11l_l1_ = l1ll11l_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪḮ"))
	l1ll11l_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡤࡪࡥࡷࠫḯ"),l1ll11l_l1_)
	l1ll_l1_ = l1ll11l_l1_[l1l111_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࡳࠨḰ")]
	l11l11_l1_ = list(l1ll_l1_.keys())
	l1ll_l1_ = list(l1ll_l1_.values())
	l1lll1l_l1_ = zip(l11l11_l1_,l1ll_l1_)
	for title,l1ll1ll_l1_ in l1lll1l_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩḱ")+title+l1l111_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪḲ")
		l1ll11l1_l1_.append(l1ll1ll_l1_)
	if l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪḳ") in html:
		url = url.replace(l1l111_l1_ (u"ࠫࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧḴ"),l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࡲ࡫ࡴࠬḵ"))
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪḶ"),url,l1l111_l1_ (u"ࠧࠨḷ"),l1l111_l1_ (u"ࠨࠩḸ"),l1l111_l1_ (u"ࠩࠪḹ"),l1l111_l1_ (u"ࠪࠫḺ"),l1l111_l1_ (u"ࠫࡉࡘࡁࡎࡃࡖ࠻࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧḻ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡤࡰࡹࡱࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬḼ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			l1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ḽ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in l1ll_l1_:
				l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨḾ")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬḿ")
				l1ll11l1_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨṀ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠪࠫṁ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠫࠬṂ"): return
	search = search.replace(l1l111_l1_ (u"ࠬࠦࠧṃ"),l1l111_l1_ (u"࠭ࠫࠨṄ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨṅ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨṆ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䔏"):l1l111_l1_ (u"ࠬ࠭䔐")}
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘࠬ䔑")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭䔒")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==30: l1lll_l1_ = l1l1l11_l1_()
	elif mode==31: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠨ࠵ࠪ䔓"))
	elif mode==32: l1lll_l1_ = ITEMS(url)
	elif mode==33: l1lll_l1_ = PLAY(url)
	elif mode==35: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠩ࠴ࠫ䔔"))
	elif mode==36: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠪ࠶ࠬ䔕"))
	elif mode==37: l1lll_l1_ = CATEGORIES(url,l1l111_l1_ (u"ࠫ࠹࠭䔖"))
	elif mode==38: l1lll_l1_ = l1ll1llll_l1_()
	elif mode==39: l1lll_l1_ = l1lll1_l1_(text,l1llllll1_l1_)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ䔗"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䔘")+l1lllll_l1_+l1l111_l1_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ䔙"),l1l111_l1_ (u"ࠨࠩ䔚"),38)
	return l1l111_l1_ (u"ࠩࠪ䔛")
def CATEGORIES(url,select=l1l111_l1_ (u"ࠪࠫ䔜")):
	type = url.split(l1l111_l1_ (u"ࠫ࠴࠭䔝"))[3]
	if type==l1l111_l1_ (u"ࠬࡳ࡯ࡴࡣ࡯ࡷࡦࡲࡡࡵࠩ䔞"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"࠭ࠧ䔟"),headers,l1l111_l1_ (u"ࠧࠨ䔠"),l1l111_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨ䔡"))
		if select==l1l111_l1_ (u"ࠩ࠶ࠫ䔢"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࡍࡦࡰࡸࠬ࠳࠰࠿ࠪࡵࡨࡶ࡮࡫ࡳࡇࡱࡵࡱࠬ䔣"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䔤"),block,re.DOTALL)
			for l1ll1ll_l1_,name in items:
				if l1l111_l1_ (u"้ࠬไ๋สสฮ๋ࠥึฮๅฬࠫ䔥") in name: continue
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"࠭ࠠࠨ䔦"))
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔧"),l1lllll_l1_+name,url,32)
		if select==l1l111_l1_ (u"ࠨ࠶ࠪ䔨"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡦࡨࡸࡦ࡯࡬ࡴ࠯ࡳࡥࡳ࡫࡬ࠩ࠰࠭ࡃ࠮ࡼ࠾࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࠫ䔩"),html,re.DOTALL)
			block= l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䔪"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				title = title.strip(l1l111_l1_ (u"ࠫࠥ࠭䔫"))
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔬"),l1lllll_l1_+title,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䔭"):
		html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠧࠨ䔮"),headers,l1l111_l1_ (u"ࠨࠩ䔯"),l1l111_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠸࡮ࡥࠩ䔰"))
		if select==l1l111_l1_ (u"ࠪ࠵ࠬ䔱"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࡋࡪࡴࡤࡦࡴࠫ࠲࠯ࡅࠩࡴࡧ࡯ࡩࡨࡺࠧ䔲"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠬࡵࡰࡵ࡫ࡲࡲࡃࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䔳"),block,re.DOTALL)
			for value,name in items:
				url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࡨࡧࡱࡶࡪ࠵ࠧ䔴") + value
				name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ䔵"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䔶"),l1lllll_l1_+name,url,32)
		elif select==l1l111_l1_ (u"ࠩ࠵ࠫ䔷"):
			l11llll_l1_=re.findall(l1l111_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࡄࡧࡹࡵࡲࠩ࠰࠭ࡃ࠮ࡹࡥ࡭ࡧࡦࡸࠬ䔸"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items=re.findall(l1l111_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࡂࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䔹"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l1l111_l1_ (u"ࠬࠦࠧ䔺"))
				url = l111l1_l1_ + l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪࡹ࠯ࡢࡥࡷࡳࡷ࠵ࠧ䔻") + value
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䔼"),l1lllll_l1_+name,url,32)
	return
def ITEMS(url):
	type = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ䔽"))[3]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠩࠪ䔾"),headers,l1l111_l1_ (u"ࠪࠫ䔿"),l1l111_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭䕀"))
	if l1l111_l1_ (u"ࠬ࡮࡯࡮ࡧࠪ䕁") in url: type=l1l111_l1_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ䕂")
	if type==l1l111_l1_ (u"ࠧ࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷࠫ䕃"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡶࠬ࠳࠰࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䕄"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䕅"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,name in items:
				url = l111l1_l1_ + l1ll1ll_l1_
				name = name.strip(l1l111_l1_ (u"ࠪࠤࠬ䕆"))
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕇"),l1lllll_l1_+name,url,32,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䕈"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪ䕉"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠫࡀࠫࠥࠫ䕊"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ䕋"))
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䕌"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ䕍"):
		l1llllll1_l1_ = url.split(l1l111_l1_ (u"ࠫ࠴࠭䕎"))[-1]
		if l1llllll1_l1_==l1l111_l1_ (u"ࠬ࠷ࠧ䕏"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠫ䕐"),html,re.DOTALL)
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡱࡣࡱࡩࡹ࠳ࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲࡯࡮ࡧࡱࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶࠨ䕑"),block,re.DOTALL)
			count = 0
			for l1ll1ll_l1_,l1ll1l_l1_,l1l1lll_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䕒") + l1l1lll_l1_
				url = l111l1_l1_ + l1ll1ll_l1_
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䕓"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹ࠮ࠫࡁࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䕔"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶࠳࠰࠿ࡱࡣࡱࡩࡹ࠳ࡩ࡯ࡨࡲࠦࡃࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࠬ䕕"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,l1l1lll_l1_ in items:
			l1l1lll_l1_ = l1l1lll_l1_.strip(l1l111_l1_ (u"ࠬࠦࠧ䕖"))
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ䕗"))
			name = title + l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫ䕘") + l1l1lll_l1_
			url = l111l1_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䕙"),l1lllll_l1_+name,url,33,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡪࡰࡾࡶࡨࡪࡥࡲࡲ࠲ࡩࡨࡦࡸࡵࡳࡳ࠳ࡲࡪࡩ࡫ࡸ࠭࠴ࠫࡀࠫࡧࡥࡹࡧ࠭ࡳࡧࡹ࡭ࡻ࡫࠭ࡻࡱࡱࡩ࡮ࡪ࠽ࠣ࠶ࠥࠫ䕚"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䕛"),block,re.DOTALL)
	for l1ll1ll_l1_,l1llllll1_l1_ in items:
		url = l111l1_l1_ + l1ll1ll_l1_
		name = l1l111_l1_ (u"ฺࠫ็อสࠢࠪ䕜") + l1llllll1_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䕝"),l1lllll_l1_+name,url,32)
	return
def PLAY(url):
	if l1l111_l1_ (u"࠭࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶࠪ䕞") in url:
		url = l111l1_l1_ + l1l111_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸ࠴ࡼ࠱࠰ࡵࡨࡶ࡮࡫ࡳࡍ࡫ࡱ࡯࠴࠭䕟") + url.split(l1l111_l1_ (u"ࠨ࠱ࠪ䕠"))[-1]
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䕡"),url,l1l111_l1_ (u"ࠪࠫ䕢"),headers,l1l111_l1_ (u"ࠫࠬ䕣"),l1l111_l1_ (u"ࠬ࠭䕤"),l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䕥"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠧࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䕦"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ䕧"),l1l111_l1_ (u"ࠩ࠲ࠫ䕨"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䕩"),url,l1l111_l1_ (u"ࠫࠬ䕪"),headers,l1l111_l1_ (u"ࠬ࠭䕫"),l1l111_l1_ (u"࠭ࠧ䕬"),l1l111_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ䕭"))
		html = response.content
		items = re.findall(l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡗࡕࡐࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䕮"),html,re.DOTALL)
		url = items[0]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䕯"))
	return
def l1lll1_l1_(search,l1llllll1_l1_=l1l111_l1_ (u"ࠪࠫ䕰")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭䕱"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ䕲"))
	l1lll11l1_l1_ = [l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭䕳"),l1l111_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䕴")]
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠨ࠳ࠪ䕵")
	else: l1llllll1_l1_,type = l1llllll1_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ䕶"))
	if l11_l1_:
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠪฬาัฺ่ࠠࠣหๆ๊วๆࠩ䕷") , l1l111_l1_ (u"ࠫอำหࠡ฻้ࠤู๊ไิๆสฮࠬ䕸")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊หࠢ࠰ࠤฬิสาࠢส่อำหࠨ䕹"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		type = l1lll11l1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧ䕺") in options: type = l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䕻")
		elif l1l111_l1_ (u"ࠨࡡࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࡠࠩ䕼") in options: type = l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ䕽")
		else: return
	headers[l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䕾")] = l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ䕿")
	data = {l1l111_l1_ (u"ࠬࡷࡵࡦࡴࡼࠫ䖀"):l1lll1ll_l1_ , l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡊ࡯࡮ࡣ࡬ࡲࠬ䖁"):type}
	if l1llllll1_l1_!=l1l111_l1_ (u"ࠧ࠲ࠩ䖂"): data[l1l111_l1_ (u"ࠨࡨࡵࡳࡲ࠭䖃")] = l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䖄"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ䖅"),data,headers,l1l111_l1_ (u"ࠫࠬ䖆"),l1l111_l1_ (u"ࠬ࠭䖇"),l1l111_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䖈"))
	html = response.content
	items=re.findall(l1l111_l1_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰ࡮ࡴ࡫ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䖉"),html,re.DOTALL)
	if items:
		for title,l1ll1ll_l1_ in items:
			url = l111l1_l1_ + l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ䖊"),l1l111_l1_ (u"ࠩ࠲ࠫ䖋"))
			if l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ䖌") in url: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䖍"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็๊ๅ็ࠣࠫ䖎")+title,url,33)
			elif l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ䖏") in url:
				url = url.replace(l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䖐"),l1l111_l1_ (u"ࠨ࠱ࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠵ࠧ䖑"))
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䖒"),l1lllll_l1_+l1l111_l1_ (u"ุ้๊ࠪำๅࠢࠪ䖓")+title,url+l1l111_l1_ (u"ࠫ࠴࠷ࠧ䖔"),32)
	count=re.findall(l1l111_l1_ (u"ࠬࠨࡴࡰࡶࡤࡰࠧࡀࠨ࠯ࠬࡂ࠭ࢂ࠭䖕"),html,re.DOTALL)
	if count:
		l1ll1l1ll_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1lll1l1l_l1_ in range(1,l1ll1l1ll_l1_):
			l1lll1l1l_l1_ = str(l1lll1l1l_l1_)
			if l1lll1l1l_l1_!=l1llllll1_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䖖"),l1l111_l1_ (u"ࠧึใะอࠥ࠭䖗")+l1lll1l1l_l1_,l1l111_l1_ (u"ࠨࠩ䖘"),39,l1l111_l1_ (u"ࠩࠪ䖙"),l1lll1l1l_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ䖚")+type,search)
	return
def l1ll1llll_l1_():
	l1ll1ll_l1_ = l1l111_l1_ (u"ࠫࡦࡎࡒ࠱ࡥࡇࡳࡻࡒ࠲ࡥࡼࡧࡌࡏࡲ࡙ࡘ࠲࠳ࡐࡳࡈࡨࡣ࡯࡙࠴ࡑࡳࡎࡷࡎࡰࡰࡸࡒ࠲ࡗ࡭࡝࠶࡛࡬࡙ࡘࡌࡼࡐ࠷࡮ࡨࡣࡉࡉ࡙࡛࡯࠹ࡸࡤࡊࡊ࠺ࡨࡇ࡭ࡼࡧࡇ࠺ࡺࡍ࠴ࡗ࠷ࠫ䖛")
	l1ll1ll_l1_ = base64.b64decode(l1ll1ll_l1_)
	l1ll1ll_l1_ = l1ll1ll_l1_.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ䖜"))
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ䖝"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭䌮")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡏ࠷࡙ࡤ࠭䌯")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨษ้์ฬ฿ࠠศใ็ห๊࠭䌰"),l1l111_l1_ (u"ࠩฯ์ิอสࠡษไ่ฬ๋ࠧ䌱")]
def l11l1ll_l1_(mode,url,text):
	if   mode==380: l1lll_l1_ = l1l1l11_l1_()
	elif mode==381: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==382: l1lll_l1_ = PLAY(url)
	elif mode==383: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==389: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䌲"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ䌳"),l1l111_l1_ (u"ࠬ࠭䌴"),389,l1l111_l1_ (u"࠭ࠧ䌵"),l1l111_l1_ (u"ࠧࠨ䌶"),l1l111_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䌷"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䌸"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䌹"),l1l111_l1_ (u"ࠫࠬ䌺"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䌻"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䌼")+l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่้๏ุษࠨ䌽"),l111l1_l1_,381,l1l111_l1_ (u"ࠨࠩ䌾"),l1l111_l1_ (u"ࠩࠪ䌿"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䍀"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䍁"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䍂")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮส๊อ๐ษࠨ䍃"),l111l1_l1_,381,l1l111_l1_ (u"ࠧࠨ䍄"),l1l111_l1_ (u"ࠨࠩ䍅"),l1l111_l1_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ䍆"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䍇"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䍈"),l1l111_l1_ (u"ࠬ࠭䍉"),l1l111_l1_ (u"࠭ࠧ䍊"),l1l111_l1_ (u"ࠧࠨ䍋"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ䍌"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䍍"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䍎"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䍏")+l1lllll_l1_+title,l111l1_l1_,381,l1l111_l1_ (u"ࠬ࠭䍐"),l1l111_l1_ (u"࠭ࠧ䍑"),l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ䍒")+str(seq))
	block = l1l111_l1_ (u"ࠨࠩ䍓")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧ䍔"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠬ࠳࠰࠿ࠪࡣࡶ࡭ࡩ࡫ࠧ䍕"),html,re.DOTALL)
	if l11llll_l1_: block += l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䍖"),block,re.DOTALL)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䍗"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䍘"),l1l111_l1_ (u"ࠧࠨ䍙"),9999)
	first = True
	for l1ll1ll_l1_,title in items:
		title = unescapeHTML(title)
		if title==l1l111_l1_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ䍚"):
			if first:
				title = l1l111_l1_ (u"ࠩส่ฬ็ไศ็ࠣࠫ䍛")+title
				first = False
			else: title = l1l111_l1_ (u"ࠪห้๋ำๅี็หฯࠦࠧ䍜")+title
		if title not in l11lll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䍝"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䍞")+l1lllll_l1_+title,l1ll1ll_l1_,381)
	return html
def l1lll11_l1_(url,type):
	block,items = [],[]
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䍟"),url,l1l111_l1_ (u"ࠧࠨ䍠"),l1l111_l1_ (u"ࠨࠩ䍡"),l1l111_l1_ (u"ࠩࠪ䍢"),l1l111_l1_ (u"ࠪࠫ䍣"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ䍤"))
	html = response.content
	if type==l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ䍥"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ䍦"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䍧"),block,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ䍨"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭䍩"),html,re.DOTALL)
		block = l11llll_l1_[0]
		z = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ䍪"),block,re.DOTALL)
		l1llll_l1_,l1l1ll1ll_l1_,l1l1lll1_l1_ = zip(*z)
		items = zip(l1l1ll1ll_l1_,l1llll_l1_,l1l1lll1_l1_)
	elif type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭䍫"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ䍬"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䍭"),block,re.DOTALL)
	elif l1l111_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ䍮") in type:
		seq = int(type[-1:])
		html = html.replace(l1l111_l1_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ䍯"),l1l111_l1_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨ䍰"))
		html = html.replace(l1l111_l1_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ䍱"),l1l111_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ䍲"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩ䍳"),html,re.DOTALL)
		block = l11llll_l1_[seq]
		if seq==2: items = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䍴"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭䍵"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0][0]
			if l1l111_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ䍶") in url:
				items = re.findall(l1l111_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䍷"),block,re.DOTALL)
			elif l1l111_l1_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭䍸") in url:
				items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䍹"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l1l111_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䍺"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࠬ䍻") in title:
			title = re.findall(l1l111_l1_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡪࡸࡩࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䍼"),title,re.DOTALL)
			title = title[0][1]
			if title in l1l1_l1_: continue
			l1l1_l1_.append(title)
			title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䍽")+title
		l1lllllll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡡࠬ࠳࠰࠿ࠪ࠾ࠪ䍾"),title,re.DOTALL)
		if l1lllllll_l1_: title = l1lllllll_l1_[0]
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭䍿") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䎀"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ䎁") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䎂"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮ࡴ࠱ࠪ䎃") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎄"),l1lllll_l1_+title,l1ll1ll_l1_,383,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴ࠯ࠨ䎅") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䎆"),l1lllll_l1_+title,l1ll1ll_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䎇"),l1lllll_l1_+title,l1ll1ll_l1_,382,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄࡖࡡࡨࡧࠣࠬ࠳࠰࠿ࠪࠢࡲࡪࠥ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ䎈"),html,re.DOTALL)
	if l11llll_l1_:
		current = l11llll_l1_[0][0]
		last = l11llll_l1_[0][1]
		block = l11llll_l1_[0][2]
		items = re.findall(l1l111_l1_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣ䎉"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"ࠧࠨ䎊") or title==last: continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䎋"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ䎌")+title,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠪࠫ䎍"),l1l111_l1_ (u"ࠫࠬ䎎"),type)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬ䎏")+title+l1l111_l1_ (u"࠭࠯ࠨ䎐"),l1l111_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ䎑")+last+l1l111_l1_ (u"ࠨ࠱ࠪ䎒"))
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎓"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำืࠠึใะอࠥ࠭䎔")+last,l1ll1ll_l1_,381,l1l111_l1_ (u"ࠫࠬ䎕"),l1l111_l1_ (u"ࠬ࠭䎖"),type)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ䎗"),url,l1l111_l1_ (u"ࠧࠨ䎘"),l1l111_l1_ (u"ࠨࠩ䎙"),l1l111_l1_ (u"ࠩࠪ䎚"),l1l111_l1_ (u"ࠪࠫ䎛"),l1l111_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ䎜"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡉࠠࡳࡣࡷࡩࡩࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䎝"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_,False):
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䎞"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆ่ืู้ไࠡๆ็็ออั๊ࠡส่๊ฮัๆฮ้๋ࠣ฿็ࠨ䎟"),l1l111_l1_ (u"ࠨࠩ䎠"),9999)
		return
	if l1l111_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭䎡") in url or l1l111_l1_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷ࠴࠭䎢") in url:
		l1lllll1_l1_ = re.findall(l1l111_l1_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂ࠭ࡩࡵࡧࡰࠫࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ䎣"),html,re.DOTALL)
		if l1lllll1_l1_:
			l1lllll1_l1_ = l1lllll1_l1_[1]
			l1ll1l11_l1_(l1lllll1_l1_)
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡦࡲ࡬ࡷࡴࡪࡩࡰࡵࠪࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡩࡡࡴࡶࠥࠫࠬ࠭䎤"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࠧࠨࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠨࡰࡸࡱࡪࡸࡡ࡯ࡦࡲࠫࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠧࠨ䎥"),block,re.DOTALL)
		for l1ll1l_l1_,l1l1lll_l1_,l1ll1ll_l1_,name in items:
			title = l1l1lll_l1_+l1l111_l1_ (u"ࠧࠡ࠼ࠣࠫ䎦")+name+l1l111_l1_ (u"ࠨࠢส่า๊โสࠩ䎧")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䎨"),l1lllll_l1_+title,l1ll1ll_l1_,382)
	return
def PLAY(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䎩"),url,l1l111_l1_ (u"ࠫࠬ䎪"),l1l111_l1_ (u"ࠬ࠭䎫"),l1l111_l1_ (u"࠭ࠧ䎬"),l1l111_l1_ (u"ࠧࠨ䎭"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ䎮"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䎯"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l1llll_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠫࠬ࡯ࡤ࠾ࠩࡳࡰࡦࡿࡥࡳ࠯ࡲࡴࡹ࡯࡯࡯࠯࠴ࠫ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠪࠥࡷ࡭࡫ࡡࡥࡧࡵࠦࢁ࠭ࡰࡢࡩࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ࠯ࠧࠨࠩ䎰"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0][0]
		items = re.findall(l1l111_l1_ (u"ࠦࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡶࡩࡷࡼࡥࡳࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠥ䎱"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䎲")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ䎳")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡯ࡲࡨࡦࡲ࠭ࡤ࡮ࡲࡷࡪࠨࠧ䎴"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡡࡢࡣࡩࡲ࡟ࡨࡦࡵ࡭ࡻ࡫࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䎵"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䎶")+title+l1l111_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䎷")
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䎸"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠬ࠭䎹"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"࠭ࠧ䎺"): return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ䎻"),l1l111_l1_ (u"ࠨ࠭ࠪ䎼"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡃࡸࡃࠧ䎽")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ䎾"))
	return
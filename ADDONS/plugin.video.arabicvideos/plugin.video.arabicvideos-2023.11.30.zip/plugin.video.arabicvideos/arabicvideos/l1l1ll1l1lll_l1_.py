# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ䉌")
headers = { l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䉍") : l1l111_l1_ (u"࠭ࠧ䉎") }
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡏ࡙࡞ࡤ࠭䉏")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
def l11l1ll_l1_(mode,url,text):
	if   mode==180: l1lll_l1_ = l1l1l11_l1_()
	elif mode==181: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==182: l1lll_l1_ = PLAY(url)
	elif mode==183: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==188: l1lll_l1_ = l1l1l11lll11_l1_()
	elif mode==189: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11lll11_l1_():
	message = l1l111_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭䉐")
	l1111l1_l1_(l1l111_l1_ (u"ࠩࠪ䉑"),l1l111_l1_ (u"ࠪࠫ䉒"),l1l111_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䉓"),message)
	return
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉔"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䉕"),l1l111_l1_ (u"ࠧࠨ䉖"),189,l1l111_l1_ (u"ࠨࠩ䉗"),l1l111_l1_ (u"ࠩࠪ䉘"),l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䉙"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䉚"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䉛")+l1lllll_l1_+l1l111_l1_ (u"࠭ศ้ๅึࠤฬ๎แ๋ี้ࠣํ็๊ำࠢ็ห๋ีࠧ䉜"),l111l1_l1_,181,l1l111_l1_ (u"ࠧࠨ䉝"),l1l111_l1_ (u"ࠨࠩ䉞"),l1l111_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭䉟"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉠"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䉡")+l1lllll_l1_+l1l111_l1_ (u"ࠬษอะอࠣห้อแๅษ่ࠫ䉢"),l111l1_l1_,181,l1l111_l1_ (u"࠭ࠧ䉣"),l1l111_l1_ (u"ࠧࠨ䉤"),l1l111_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䉥"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉦"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䉧")+l1lllll_l1_+l1l111_l1_ (u"ࠫฯ๊๊โิํ์๋ࠦๅ้ใํึ๊ࠥว็ัࠪ䉨"),l111l1_l1_,181,l1l111_l1_ (u"ࠬ࠭䉩"),l1l111_l1_ (u"࠭ࠧ䉪"),l1l111_l1_ (u"ࠧࡵࡸࠪ䉫"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䉬"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䉭")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้อใฬำู้ࠣอ็ะหࠪ䉮"),l111l1_l1_,181,l1l111_l1_ (u"ࠫࠬ䉯"),l1l111_l1_ (u"ࠬ࠭䉰"),l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ䉱"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䉲"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䉳")+l1lllll_l1_+l1l111_l1_ (u"ࠩฦๆํ๏ࠠศๆสๅ้อๅࠡษ็ัฬ๊๊สࠩ䉴"),l111l1_l1_,181,l1l111_l1_ (u"ࠪࠫ䉵"),l1l111_l1_ (u"ࠫࠬ䉶"),l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䉷"))
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"࠭ࠧ䉸"),headers,l1l111_l1_ (u"ࠧࠨ䉹"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭䉺"))
	items = re.findall(l1l111_l1_ (u"ࠩ࠿࡬࠷ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䉻"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉼"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䉽")+l1lllll_l1_+title,l1ll1ll_l1_,181)
	return html
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠬ࠭䉾")):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ䉿"),headers,l1l111_l1_ (u"ࠧࠨ䊀"),l1l111_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ䊁"))
	if type==l1l111_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ䊂"): block = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁวาีหࠡษ็วๆ๊วๆ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࡮࠱ࠨ䊃"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠫࡧࡵࡸ࠮ࡱࡩࡪ࡮ࡩࡥࠨ䊄"): block = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃฮ่ไีࠣหํ็๊ิ่ࠢ์ๆ๐าࠡๆส๊ิࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࡫࠵ࠬ䊅"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䊆"): block = re.findall(l1l111_l1_ (u"ࠧࡣࡶࡱ࠱࠷࠳࡯ࡷࡧࡵࡰࡦࡿࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬ䊇"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ䊈"): block = re.findall(l1l111_l1_ (u"ࠩࡥࡸࡳ࠳࠱ࠡࡤࡷࡲ࠲ࡧࡢࡴࡱ࡯ࡽ࠭࠴ࠪࡀࠫࡥࡸࡳ࠳࠲ࠡࡤࡷࡲ࠲ࡧࡢࡴࡱ࡯ࡽࠬ䊉"),html,re.DOTALL)[0]
	elif type==l1l111_l1_ (u"ࠪࡸࡻ࠭䊊"): block = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂฯ๊๊โิํ์๋ࠦๅ้ใํึ๊ࠥว็ั࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱ࡫ࠧ࠭䊋"),html,re.DOTALL)[0]
	else: block = html
	if type in [l1l111_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ䊌"),l1l111_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ䊍")]:
		items = re.findall(l1l111_l1_ (u"ࠧࡴࡶࡼࡰࡪࡃࠢࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡸࡹࡵ࡭࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䊎"),block,re.DOTALL)
	else: items = re.findall(l1l111_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴ࠾ࠤ࠶࡟࠵࠳࠹࡞࠭ࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵࡴࡵࡱࡰ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䊏"),block,re.DOTALL)
	l1l1_l1_ = []
	l1l111111_l1_ = [l1l111_l1_ (u"ࠩไ๎้๋ࠧ䊐"),l1l111_l1_ (u"ࠪห้ำไใหࠪ䊑"),l1l111_l1_ (u"ࠫฬ๊อๅไ๊ࠫ䊒"),l1l111_l1_ (u"ࠬ฿ัืࠩ䊓"),l1l111_l1_ (u"࠭ࡒࡢࡹࠪ䊔"),l1l111_l1_ (u"ࠧࡔ࡯ࡤࡧࡰࡊ࡯ࡸࡰࠪ䊕"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧ䊖"),l1l111_l1_ (u"ࠩสะือมࠨ䊗")]
	for l1ll1l_l1_,l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_,l1l1l11llll1_l1_ in items:
		if type in [l1l111_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭䊘"),l1l111_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ䊙")]:
			l1ll1l_l1_,l1ll1ll_l1_,l111lllll_l1_,title = l1ll1l_l1_,l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_,l1l1l11llll1_l1_
		else: l1ll1l_l1_,title,l1ll1ll_l1_,l111lllll_l1_ = l1ll1l_l1_,l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_,l1l1l11llll1_l1_
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬࡅࡶࡪࡧࡺࡁࡹࡸࡵࡦࠩ䊚"),l1l111_l1_ (u"࠭ࠧ䊛"))
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䊜") in title or l1l111_l1_ (u"ࠨสฯ์ิํࠠࠨ䊝") in title:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䊞") + title.replace(l1l111_l1_ (u"ࠪฬั๎ฯสࠢࠪ䊟"),l1l111_l1_ (u"ࠫࠬ䊠")).replace(l1l111_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䊡"),l1l111_l1_ (u"࠭ࠧ䊢"))
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ䊣"))
		if l1l111_l1_ (u"ࠨษ็ั้่ษࠨ䊤") in title or l1l111_l1_ (u"ࠩส่า๊โ่ࠩ䊥") in title:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿห้ำไใ้ࠬࠤࡡࡪࠫࠨ䊦"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䊧") + l1l1lll_l1_[0][0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊨"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif any(value in title for value in l1l111111_l1_):
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ䊩") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䊪"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䊫") + l111lllll_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊬"),l1lllll_l1_+title,l1ll1ll_l1_,183,l1ll1l_l1_)
	if type==l1l111_l1_ (u"ࠪࠫ䊭"):
		items = re.findall(l1l111_l1_ (u"ࠫࡡࡴ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䊮"),html,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠬอไึใะอࠥ࠭䊯"),l1l111_l1_ (u"࠭ࠧ䊰"))
			if title!=l1l111_l1_ (u"ࠧࠨ䊱"):
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊲"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ䊳")+title,l1ll1ll_l1_,181)
	return
def l1ll1l11_l1_(url):
	l1lllll1_l1_ = url.split(l1l111_l1_ (u"ࠪࡃࡸ࡫ࡲࡷࡧࡵࡷࡂ࠭䊴"))[0]
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ䊵"),headers,l1l111_l1_ (u"ࠬ࠭䊶"),l1l111_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ䊷"))
	block = re.findall(l1l111_l1_ (u"ࠧ࠽ࡶ࡬ࡸࡱ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵ࡫ࡷࡰࡪࡄ࠮ࠫࡁ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠬࡠ࠶࠭࠺࡟࠮࠭ࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䊸"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽษ็ั้่็ࠪࠢ࡞࠴࠲࠿࡝ࠬࠩ䊹"),title,re.DOTALL)
	if name: name = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䊺") + name[0][0]
	else: name = title
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷࡓࡻ࡭ࡣࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䊻"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䊼"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			title = re.findall(l1l111_l1_ (u"ࠬ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯࠭ࠩ࡝࠳࠱࠾ࡣࠫࠪࠩ䊽"),l1ll1ll_l1_.split(l1l111_l1_ (u"࠭࠯ࠨ䊾"))[-2],re.DOTALL)
			if not title: title = re.findall(l1l111_l1_ (u"ࠧࠩࠫ࠰ࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ䊿"),l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨ࠱ࠪ䋀"))[-2],re.DOTALL)
			if title: title = l1l111_l1_ (u"ࠩࠣࠫ䋁") + title[0][1]
			else: title = l1l111_l1_ (u"ࠪࠫ䋂")
			title = name + l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨ䋃") + l1l111_l1_ (u"ࠬอไฮๆๅอࠬ䋄") + title
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䋅"),l1lllll_l1_+title,l1ll1ll_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l1l111_l1_ (u"ࠧษฮ๋ำฮࠦࠧ䋆") in title or l1l111_l1_ (u"ࠨสฯ์ิํࠠࠨ䋇") in title:
			title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ䋈") + title.replace(l1l111_l1_ (u"ࠪฬั๎ฯสࠢࠪ䋉"),l1l111_l1_ (u"ࠫࠬ䋊")).replace(l1l111_l1_ (u"ࠬฮฬ้ั๊ࠤࠬ䋋"),l1l111_l1_ (u"࠭ࠧ䋌"))
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䋍"),l1lllll_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1l11ll111_l1_ = url.split(l1l111_l1_ (u"ࠨࡁࡶࡩࡷࡼࡥࡳࡵࡀࠫ䋎"))
	l1lllll1_l1_ = l1l1l11ll111_l1_[0]
	del l1l1l11ll111_l1_[0]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ䋏"),headers,l1l111_l1_ (u"ࠪࠫ䋐"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䋑"))
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡬࡯࡯ࡶ࠰ࡷ࡮ࢀࡥ࠻ࠢ࠵࠹ࡵࡾ࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䋒"),html,re.DOTALL)[0]
	if l1ll1ll_l1_ not in l1l1l11ll111_l1_: l1l1l11ll111_l1_.append(l1ll1ll_l1_)
	l1llll_l1_ = []
	for l1ll1ll_l1_ in l1l1l11ll111_l1_:
		if l1l111_l1_ (u"࠭࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ䋓") in l1ll1ll_l1_:
			l1l1l11l11ll_l1_ = l1ll1ll_l1_
			l1llll_l1_.append(l1l1l11l11ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡣ࡬ࡲࠬ䋔"))
	for l1ll1ll_l1_ in l1l1l11ll111_l1_:
		if l1l111_l1_ (u"ࠨ࠼࠲࠳ࡻࡨ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࠫ䋕") in l1ll1ll_l1_:
			html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll1ll_l1_,l1l111_l1_ (u"ࠩࠪ䋖"),headers,l1l111_l1_ (u"ࠪࠫ䋗"),l1l111_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ䋘"))
			html = html.decode(l1l111_l1_ (u"ࠬࡽࡩ࡯ࡦࡲࡻࡸ࠳࠱࠳࠷࠹ࠫ䋙")).encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䋚"))
			html = html.replace(l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡨࡵ࡭࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䋛"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ䋜"))
			html = html.replace(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䋝"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䋞"))
			html = html.replace(l1l111_l1_ (u"ࠫࡁ࠵ࡡ࠿࠾࠲ࡨ࡮ࡼ࠾࠽ࡤࡵࠤ࠴ࡄ࠼ࡥ࡫ࡹࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࡃ࠭䋟"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ䋠"))
			html = html.replace(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡣࡱࡵࡨࡪࡸࠢࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠩ䋡"),l1l111_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ䋢"))
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ䋣"),html,re.DOTALL)
			if l11llll_l1_:
				l1l1l11l1l11_l1_,l1l1l11ll1l1_l1_ = [],[]
				if len(l11llll_l1_)==1:
					title = l1l111_l1_ (u"ࠩࠪ䋤")
					block = html
				else:
					for block in l11llll_l1_:
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠯ࠬࡂࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࡞࠭࠯࠭࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䋥"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭䋦") + l1l1l1l_l1_[0][1]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠩ䋧")+l1l111_l1_ (u"࠭ࠣࠨ䋨")+l1l111_l1_ (u"ࠧ࠴࠵࠶࠿ࠥࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯ࡦࡳࡱࡵࡲ࠻ࠩ䋩")+l1l111_l1_ (u"ࠨࠥࠪ䋪")+l1l111_l1_ (u"ࠩ࠶࠷࠸ࠨࠠ࠰ࡀࠫ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ䋫"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࠬ䋬") + l1l1l1l_l1_[0]
						l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱࡟ࡻ࠰࠴ࡨࡵ࡯࡯ࠦ࠳࠰࠿ࠪ࠾࡫ࡶࠥࡹࡩࡻࡧࡀࠦ࠶ࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࠧ䋭")+l1l111_l1_ (u"ࠬࠩࠧ䋮")+l1l111_l1_ (u"࠭࠳࠴࠵࠾ࠤࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮ࡥࡲࡰࡴࡸ࠺ࠨ䋯")+l1l111_l1_ (u"ࠧࠤࠩ䋰")+l1l111_l1_ (u"ࠨ࠵࠶࠷ࠧࠦ࠯࠿࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ䋱"),block,re.DOTALL)
						if l1l1l1l_l1_: block = l1l1l1l_l1_[0] + l1l111_l1_ (u"ࠩࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ䋲")
						l1l1l11ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀ࠭࠴ࠪࡀࠫ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰ࠩ䋳"),block,re.DOTALL)
						title = re.findall(l1l111_l1_ (u"ࠫࡃࠦࠪࠩ࡝ࡡࡀࡃࡣࠫࠪࠢ࠭ࡀࠬ䋴"),l1l1l11ll1ll_l1_[0][0],re.DOTALL)
						title = l1l111_l1_ (u"ࠬࠦࠧ䋵").join(title)
						title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ䋶"))
						title = title.replace(l1l111_l1_ (u"ࠧࠡࠢࠪ䋷"),l1l111_l1_ (u"ࠨࠢࠪ䋸")).replace(l1l111_l1_ (u"ࠩࠣࠤࠬ䋹"),l1l111_l1_ (u"ࠪࠤࠬ䋺")).replace(l1l111_l1_ (u"ࠫࠥࠦࠧ䋻"),l1l111_l1_ (u"ࠬࠦࠧ䋼")).replace(l1l111_l1_ (u"࠭ࠠࠡࠩ䋽"),l1l111_l1_ (u"ࠧࠡࠩ䋾")).replace(l1l111_l1_ (u"ࠨࠢࠣࠫ䋿"),l1l111_l1_ (u"ࠩࠣࠫ䌀"))
						l1l1l11l1l11_l1_.append(title)
					l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠪวำะัࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้ส࠽ࠫ䌁"), l1l1l11l1l11_l1_)
					if l11l11l_l1_ == -1 : return
					title = l1l1l11l1l11_l1_[l11l11l_l1_]
					block = l11llll_l1_[l11l11l_l1_]
				l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱ࠯ࠢࠨ䌂"),block,re.DOTALL)
				l1l1l11l11l1_l1_ = l1ll1ll_l1_[0]
				l1llll_l1_.append(l1l1l11l11l1_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡌ࡯ࡳࡷࡰࠫ䌃"))
				block = block.replace(l1l111_l1_ (u"࠭เࠨ䌄"),l1l111_l1_ (u"ࠧࠨ䌅"))
				block = block.replace(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠶࠳࠺࠸࠶࠸࠱࠸࠷࠵࠽࠻࠴ࡰ࡯ࡩࠥࠫ䌆"),l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ䌇"))
				block = block.replace(l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡤࡱࡰ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ䌈"),l1l111_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡥࡳࡹ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䌉"))
				block = block.replace(l1l111_l1_ (u"ู๊ࠬาใิหฯࠦวๅฬะ้๏๊ࠧ䌊"),l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭䌋"))
				block = block.replace(l1l111_l1_ (u"ࠧา๊สฬ฼ࠦวๅฬะ้๏๊ࠧ䌌"),l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠢࠣࡠࡳࠦࠠࠨ䌍"))
				block = block.replace(l1l111_l1_ (u"ࠩึ๎ึ็ัศฬࠣห้๋ิศ้าࠫ䌎"),l1l111_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ䌏"))
				block = block.replace(l1l111_l1_ (u"ࠫึ๎วษูࠣห้๋ิศ้าࠫ䌐"),l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡻࡦࡺࡣࡩࠤࠣࠤࡡࡴࠠࠡࠩ䌑"))
				l1l1l11l1ll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࡞ࡧ࠯ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ䌒"),block,re.DOTALL)
				for l1l1l11ll11l_l1_ in l1l1l11l1ll1_l1_:
					type = re.findall(l1l111_l1_ (u"ࠧࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࠬ䌓"),l1l1l11ll11l_l1_)
					if type:
						if type[0]!=l1l111_l1_ (u"ࠨࡤࡲࡸ࡭࠭䌔"): type = l1l111_l1_ (u"ࠩࡢࡣࠬ䌕")+type[0]
						else: type = l1l111_l1_ (u"ࠪࠫ䌖")
					items = re.findall(l1l111_l1_ (u"ࠫ࠭ࡅ࠼ࠢࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴࠯ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿࠳࡫ࡵ࡮ࡵࡀ࠱࠮ࡄࢂ࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫ࠾ࡥࡶࠥ࠵࠾࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࠰࠭ࡃ࠮ࠨࠧ䌗"),l1l1l11ll11l_l1_,re.DOTALL)
					for l1l1l11l1lll_l1_,l1ll1ll_l1_ in items:
						title = re.findall(l1l111_l1_ (u"ࠬ࠮࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫࠫ࠿ࠫ䌘"),l1l1l11l1lll_l1_)
						title = title[-1]
						l1ll1ll_l1_ = l1ll1ll_l1_ + l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䌙") + title + type
						l1llll_l1_.append(l1ll1ll_l1_)
	l1llllll_l1_ = l1lllll1_l1_.replace(l111l1_l1_,l1l1l1lll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1llllll_l1_,l1l111_l1_ (u"ࠧࠨ䌚"),headers,l1l111_l1_ (u"ࠨࠩ䌛"),l1l111_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ䌜"))
	items = re.findall(l1l111_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䌝"),html,re.DOTALL)
	if items:
		l1l1l11lllll_l1_ = items[-1]
		l1llll_l1_.append(l1l1l11lllll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡒࡵࡢࡪ࡮ࡨࠫ䌞"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䌟"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ䌠"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ䌡"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ䌢"),l1l111_l1_ (u"ࠩ࠮ࠫ䌣"))
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠪࠫ䌤"),headers,l1l111_l1_ (u"ࠫࠬ䌥"),l1l111_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ䌦"))
	items = re.findall(l1l111_l1_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴ࠾ࠨ䌧"),html,re.DOTALL)
	l11lllll1_l1_ = [ l1l111_l1_ (u"ࠧࠨ䌨") ]
	l11ll1ll1_l1_ = [ l1l111_l1_ (u"ࠨษ็็้่ࠦษั๋๊ࠥ็ไหำࠪ䌩") ]
	for category,title in items:
		l11lllll1_l1_.append(category)
		l11ll1ll1_l1_.append(title)
	if category:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩ䌪"), l11ll1ll1_l1_)
		if l11l11l_l1_ == -1 : return
		category = l11lllll1_l1_[l11l11l_l1_]
	else: category = l1l111_l1_ (u"ࠪࠫ䌫")
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴ࡅࡳ࠾ࠩ䌬")+search+l1l111_l1_ (u"ࠬࠬ࡭ࡤࡣࡷࡁࠬ䌭")+category
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓࠨ䖞")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡏࡗ࡙ࡥࠧ䖟")
l1l1l11111l1_l1_ = 4
l1l11llllll1_l1_ = 10
def l11l1ll_l1_(mode,url,text,l1llllll1_l1_,l1llll11l11_l1_):
	try: l1l11ll1llll_l1_ = str(l1llll11l11_l1_[l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䖠")])
	except: l1l11ll1llll_l1_ = l1l111_l1_ (u"ࠪࠫ䖡")
	if   mode==160: l1lll_l1_ = l1l1l11_l1_()
	elif mode==161: l1lll_l1_ = l1l1l11l111l_l1_(text)
	elif mode==162: l1lll_l1_ = l1l11ll11l1l_l1_(text,162)
	elif mode==163: l1lll_l1_ = l1l11ll11l1l_l1_(text,163)
	elif mode==164: l1lll_l1_ = l1l1l111llll_l1_(text)
	elif mode==165: l1lll_l1_ = l1l11l1ll11l_l1_(url,text)
	elif mode==166: l1lll_l1_ = l1l1l1111lll_l1_(url,text)
	elif mode==167: l1lll_l1_ = l1l11l1ll111_l1_(url,text)
	elif mode==168: l1lll_l1_ = l1l11l11ll1l_l1_(url,text)
	elif mode==761: l1lll_l1_ = l1l1l111ll11_l1_()
	elif mode==762: l1lll_l1_ = l1l11lll1l11_l1_()
	elif mode==763: l1lll_l1_ = l1l11lll11l1_l1_(l1l11ll1llll_l1_,text,l1llllll1_l1_)
	elif mode==764: l1lll_l1_ = l1l1l1111111_l1_(l1l11ll1llll_l1_,text)
	elif mode==765: l1lll_l1_ = l1l1l111l1l1_l1_(l1l11ll1llll_l1_,text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䖢"),l1l111_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭䖣"),l1l111_l1_ (u"࠭ࠧ䖤"),161,l1l111_l1_ (u"ࠧࠨ䖥"),l1l111_l1_ (u"ࠨࠩ䖦"),l1l111_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䖧"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䖨"),l1l111_l1_ (u"ࠫ็ูๅࠡ฻ื์ฬฬ๊ࠨ䖩"),l1l111_l1_ (u"ࠬ࠭䖪"),162,l1l111_l1_ (u"࠭ࠧ䖫"),l1l111_l1_ (u"ࠧࠨ䖬"),l1l111_l1_ (u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䖭"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䖮"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮ࠭䖯"),l1l111_l1_ (u"ࠫࠬ䖰"),163,l1l111_l1_ (u"ࠬ࠭䖱"),l1l111_l1_ (u"࠭ࠧ䖲"),l1l111_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䖳"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䖴"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤอำหࠡ฻ื์ฬฬ๊ࠨ䖵"),l1l111_l1_ (u"ࠪࠫ䖶"),164,l1l111_l1_ (u"ࠫࠬ䖷"),l1l111_l1_ (u"ࠬ࠭䖸"),l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䖹"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䖺"),l1l111_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ䖻"),l1l111_l1_ (u"ࠩࠪ䖼"),763,l1l111_l1_ (u"ࠪࠫ䖽"),l1l111_l1_ (u"ࠫࠬ䖾"),l1l111_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ䖿"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䗀"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䗁"),l1l111_l1_ (u"ࠨࠩ䗂"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䗃"),l1l111_l1_ (u"ࠪๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ䗄"),l1l111_l1_ (u"ࠫࠬ䗅"),163,l1l111_l1_ (u"ࠬ࠭䗆"),l1l111_l1_ (u"࠭ࠧ䗇"),l1l111_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡌࡊࡘࡈࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䗈"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䗉"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊สࠩ䗊"),l1l111_l1_ (u"ࠪࠫ䗋"),163,l1l111_l1_ (u"ࠫࠬ䗌"),l1l111_l1_ (u"ࠬ࠭䗍"),l1l111_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࡤ࡜ࡏࡅࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䗎"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䗏"),l1l111_l1_ (u"ࠨไึ้่ࠥๆ้ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ࠨ䗐"),l1l111_l1_ (u"ࠩࠪ䗑"),162,l1l111_l1_ (u"ࠪࠫ䗒"),l1l111_l1_ (u"ࠫࠬ䗓"),l1l111_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗔"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗕"),l1l111_l1_ (u"ࠧใี่ࠤๆ๐ฯ๋๊ࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ䗖"),l1l111_l1_ (u"ࠨࠩ䗗"),162,l1l111_l1_ (u"ࠩࠪ䗘"),l1l111_l1_ (u"ࠪࠫ䗙"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䗚"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗛"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩ䗜"),l1l111_l1_ (u"ࠧࠨ䗝"),164,l1l111_l1_ (u"ࠨࠩ䗞"),l1l111_l1_ (u"ࠩࠪ䗟"),l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䗠"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗡"),l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ䗢"),l1l111_l1_ (u"࠭ࠧ䗣"),765,l1l111_l1_ (u"ࠧࠨ䗤"),l1l111_l1_ (u"ࠨࠩ䗥"),l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗦"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䗧"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䗨"),l1l111_l1_ (u"ࠬ࠭䗩"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䗪"),l1l111_l1_ (u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ䗫"),l1l111_l1_ (u"ࠨࠩ䗬"),163,l1l111_l1_ (u"ࠩࠪ䗭"),l1l111_l1_ (u"ࠪࠫ䗮"),l1l111_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䗯"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䗰"),l1l111_l1_ (u"࠭แ๋ัํ์์อสࠡࡋࡓࡘู࡛ࠦี๊สส๏ฯࠧ䗱"),l1l111_l1_ (u"ࠧࠨ䗲"),163,l1l111_l1_ (u"ࠨࠩ䗳"),l1l111_l1_ (u"ࠩࠪ䗴"),l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䗵"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䗶"),l1l111_l1_ (u"่ࠬำๆࠢๅ๊ํอสࠡࡋࡓࡘู࡛ࠦี๊สส๏࠭䗷"),l1l111_l1_ (u"࠭ࠧ䗸"),162,l1l111_l1_ (u"ࠧࠨ䗹"),l1l111_l1_ (u"ࠨࠩ䗺"),l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䗻"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䗼"),l1l111_l1_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ䗽"),l1l111_l1_ (u"ࠬ࠭䗾"),162,l1l111_l1_ (u"࠭ࠧ䗿"),l1l111_l1_ (u"ࠧࠨ䘀"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䘁"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘂"),l1l111_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣฬาัฺࠠึ๋หห๐ࠧ䘃"),l1l111_l1_ (u"ࠫࠬ䘄"),164,l1l111_l1_ (u"ࠬ࠭䘅"),l1l111_l1_ (u"࠭ࠧ䘆"),l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䘇"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䘈"),l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ䘉"),l1l111_l1_ (u"ࠪࠫ䘊"),764,l1l111_l1_ (u"ࠫࠬ䘋"),l1l111_l1_ (u"ࠬ࠭䘌"),l1l111_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䘍"))
	return
def l1l1l111ll11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䘎"),l1l111_l1_ (u"ࠨࡡࡌࡔ࡙ࡥࠧ䘏")+l1l111_l1_ (u"ࠩไ๎ิ๐่่ษอࠤัฺ๋๊ࠢࡌࡔ࡙࡜ࠧ䘐"),l1l111_l1_ (u"ࠪࠫ䘑"),764)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䘒"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䘓"),l1l111_l1_ (u"࠭ࠧ䘔"),9999)
	for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡋࡓࠫ䘕")+str(l1l11ll1llll_l1_)+l1l111_l1_ (u"ࠨࡡࠪ䘖")
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘗"),l1lllll_l1_+l1l111_l1_ (u"ࠪࠤๆ๐ฯ๋๊๊หฯࠦๅอๆาࠤࠬ䘘")+NUMBERS_SEQ_NAME[l1l11ll1llll_l1_],l1l111_l1_ (u"ࠫࠬ䘙"),764,l1l111_l1_ (u"ࠬ࠭䘚"),l1l111_l1_ (u"࠭ࠧ䘛"),l1l111_l1_ (u"ࠧࠨ䘜"),l1l111_l1_ (u"ࠨࠩ䘝"),{l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䘞"):l1l11ll1llll_l1_})
	return
def l1l11lll1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䘟"),l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䘠")+l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡓ࠳ࡖࠩ䘡"),l1l111_l1_ (u"࠭ࠧ䘢"),765)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䘣"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䘤"),l1l111_l1_ (u"ࠩࠪ䘥"),9999)
	for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
		l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡒ࡛ࠧ䘦")+str(l1l11ll1llll_l1_)+l1l111_l1_ (u"ࠫࡤ࠭䘧")
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘨"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠโ์า๎ํํวห่ࠢะ้ีࠠࠨ䘩")+NUMBERS_SEQ_NAME[l1l11ll1llll_l1_],l1l111_l1_ (u"ࠧࠨ䘪"),765,l1l111_l1_ (u"ࠨࠩ䘫"),l1l111_l1_ (u"ࠩࠪ䘬"),l1l111_l1_ (u"ࠪࠫ䘭"),l1l111_l1_ (u"ࠫࠬ䘮"),{l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䘯"):l1l11ll1llll_l1_})
	return
def l1l1l111l1ll_l1_(l1ll1ll1ll1_l1_):
	l1ll1l1ll1l_l1_,l1ll1ll1l1l_l1_,l1lll11ll11_l1_ = l1ll1l1l111_l1_(l1ll1ll1ll1_l1_)
	try:
		if l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ䘰") in l1ll1ll1ll1_l1_: l1ll1l1ll1l_l1_(l1ll1ll1ll1_l1_)
		else: l1ll1l1ll1l_l1_()
		l1l11lll11ll_l1_ = False
	except: l1l11lll11ll_l1_ = True
	l1ll1ll1ll1_l1_ = TRANSLATE(l1ll1ll1ll1_l1_)
	if l1l11lll11ll_l1_: l1ll1lll_l1_(l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠧโึ็ࠤอํะศࠢส่๊๎โฺࠩ䘱"),time=2000)
	else: l1ll1lll_l1_(l1ll1ll1ll1_l1_,l1l111_l1_ (u"ࠨฬ่ࠤั๊ศࠡษ็ว็ูวๆࠩ䘲"),time=2000)
	return l1l11lll11ll_l1_
def l1l11ll1ll1l_l1_(l1l11lll1l1l_l1_=True):
	if not l1l11lll1l1l_l1_:
		global contentsDICT
		l1lll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ䘳"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ䘴"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩ䘵"))
		if l1lll_l1_:
			contentsDICT = l1lll_l1_
			return
	l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ䘶"),l1l111_l1_ (u"࠭ࠧ䘷"),l1l111_l1_ (u"ࠧࠨ䘸"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ䘹"),l1l111_l1_ (u"ࠩ็็๏ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱ࠤฬ๊ศา่ส้ั๊ࠦฮฬสะࠥษๆࠡ์ไัฺࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠๅๅํࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱ࠤะ๋๋ࠠไ๋้ࠥอไษำ้ห๊าࠠษะี๊ࠥํะ่ࠢส่ศ่ำศ็ࠣัฯ๏ࠠๅษࠣฮาะวอࠢฦ๊ࠥะๅๅศ๊ห๋ࠥัสࠢฦาึ๏ࠠ࠯ࠢ฼้้๐ษࠡ็็สࠥาๅ๋฻ࠣห้ษโิษ่ࠤฯำสศฮࠣ฽ฬีษࠡลๅ่๋ࠥๆࠡ࠵ࠣำ็อฦใࠢ࠱ࠤ์๊ࠠหำํำࠥษๆࠡฬฯ้฾ࠦโศศ่อࠥอไฤไึห๊ࠦวๅฤ้ࠤฤ࠭䘺"))
	if l1llll1l1l_l1_!=1: return
	l1l11l1l11l1_l1_ = menuItemsLIST
	l1l11ll1l1ll_l1_,l1l11ll1l11l_l1_ = 0,l1l111_l1_ (u"ࠪࠫ䘻")
	for l1ll1ll1ll1_l1_ in l1l11111l11_l1_:
		time.sleep(0.5)
		l1l11lll11ll_l1_ = l1l1l111l1ll_l1_(l1ll1ll1ll1_l1_)
		if l1l11lll11ll_l1_:
			l1l11ll1l1ll_l1_ += 1
			l1l11ll1l11l_l1_ += l1l111_l1_ (u"ࠫࠥ࠭䘼")+l1ll1ll1ll1_l1_
			if l1l11ll1l1ll_l1_>=l1l11llllll1_l1_: break
	menuItemsLIST[:] = l1l11l1l11l1_l1_
	if l1l11ll1l1ll_l1_>=l1l11llllll1_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䘽"),l1l111_l1_ (u"࠭ࠧ䘾"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䘿"),l1l111_l1_ (u"ࠨๆา๎่ࠦๅีๅ็อࠥ็๊ࠡࠩ䙀")+str(l1l11ll1l1ll_l1_)+l1l111_l1_ (u"้ࠩࠣํอโฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์ุฮศ่ษࠣๆิ๊ࠦไ๊้ࠤ฾ีๅ๊ࠡฯ์ิࠦล็ฬิ๊๏ะࠠโ์ࠣะ์อาไ๋๋ࠢ๏ࡀࠧ䙁")+l1l11ll1l11l_l1_)
	else:
		l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫ䙂"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࡤࡇࡌࡍࠩ䙃"),contentsDICT,l1l1lll1l1l_l1_)
		l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䙄"),l1l111_l1_ (u"࠭ࠧ䙅"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䙆"),l1l111_l1_ (u"ࠨฬ่ࠤั๊ศࠡฮ่๎฾ࠦวๅลๅืฬ๋ࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไษำ้ห๊าࠧ䙇"))
	return
def l1l11ll111l1_l1_(l1l11ll1llll_l1_,options):
	l1l1ll1111l_l1_ = False
	l1l11l11lll1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1ll1111l_l1_ and l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䙈") not in options:
		l1lll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䙉"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ䙊"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭䙋")+l1l11ll1llll_l1_)
	elif l1l111_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭䙌") not in options or l1l111_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䙍") not in options:
		import IPTV
		message = l1l111_l1_ (u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭䙎")
		if l1l111_l1_ (u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ䙏") not in options:
			try: IPTV.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ䙐"),l1l111_l1_ (u"ࠫࠬ䙑"),l1l111_l1_ (u"ࠬ࠭䙒"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䙓"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䙔"),l1l111_l1_ (u"ࠨࠩ䙕"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ䙖"),message)
			try: IPTV.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䙗"),l1l111_l1_ (u"ࠫࠬ䙘"),l1l111_l1_ (u"ࠬ࠭䙙"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䙚"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䙛"),l1l111_l1_ (u"ࠨࠩ䙜"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ䙝"),message)
			try: IPTV.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䙞"),l1l111_l1_ (u"ࠫࠬ䙟"),l1l111_l1_ (u"ࠬ࠭䙠"),options+l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䙡"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ䙢"),l1l111_l1_ (u"ࠨࠩ䙣"),l1l111_l1_ (u"่ࠩ์็฿ࠠแࡋࡓࡘ࡛ࠦไๅใํำ๏๎็ศฬࠪ䙤"),message)
		if l1l111_l1_ (u"ࠪࡣ࡛ࡕࡄࡠࠩ䙥") not in options:
			try: IPTV.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ䙦"),l1l111_l1_ (u"ࠬ࠭䙧"),l1l111_l1_ (u"࠭ࠧ䙨"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙩"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䙪"),l1l111_l1_ (u"ࠩࠪ䙫"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ䙬"),message)
			try: IPTV.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ䙭"),l1l111_l1_ (u"ࠬ࠭䙮"),l1l111_l1_ (u"࠭ࠧ䙯"),options+l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䙰"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ䙱"),l1l111_l1_ (u"ࠩࠪ䙲"),l1l111_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆๅ๊ํอสࠨ䙳"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1ll1111l_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫ䙴"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࡤ࠭䙵")+l1l11ll1llll_l1_,l1lll_l1_,l1l1lll1l1l_l1_)
	menuItemsLIST[:] = l1l11l11lll1_l1_
	return l1lll_l1_
def l1l11lll111l_l1_(l1l11ll1llll_l1_,options):
	l1l1ll1111l_l1_ = False
	l1l11l11lll1_l1_ = menuItemsLIST
	menuItemsLIST[:] = []
	if l1l1ll1111l_l1_ and l1l111_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䙶") not in options:
		l1lll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ䙷"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ䙸"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ䙹")+l1l11ll1llll_l1_)
	elif l1l111_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䙺") not in options or l1l111_l1_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ䙻") not in options:
		import M3U
		message = l1l111_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ䙼")
		if l1l111_l1_ (u"࠭࡟ࡍࡋ࡙ࡉࡤ࠭䙽") not in options:
			try: M3U.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭䙾"),l1l111_l1_ (u"ࠨࠩ䙿"),l1l111_l1_ (u"ࠩࠪ䚀"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚁"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚂"),l1l111_l1_ (u"ࠬ࠭䚃"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䚄"),message)
			try: M3U.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚅"),l1l111_l1_ (u"ࠨࠩ䚆"),l1l111_l1_ (u"ࠩࠪ䚇"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚈"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚉"),l1l111_l1_ (u"ࠬ࠭䚊"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䚋"),message)
			try: M3U.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ䚌"),l1l111_l1_ (u"ࠨࠩ䚍"),l1l111_l1_ (u"ࠩࠪ䚎"),options+l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䚏"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ䚐"),l1l111_l1_ (u"ࠬ࠭䚑"),l1l111_l1_ (u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭䚒"),message)
		if l1l111_l1_ (u"ࠧࡠࡘࡒࡈࡤ࠭䚓") not in options:
			try: M3U.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ䚔"),l1l111_l1_ (u"ࠩࠪ䚕"),l1l111_l1_ (u"ࠪࠫ䚖"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚗"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚘"),l1l111_l1_ (u"࠭ࠧ䚙"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ䚚"),message)
			try: M3U.GROUPS(l1l11ll1llll_l1_,l1l111_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ䚛"),l1l111_l1_ (u"ࠩࠪ䚜"),l1l111_l1_ (u"ࠪࠫ䚝"),options+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚞"),False)
			except: l1111l1_l1_(l1l111_l1_ (u"ࠬ࠭䚟"),l1l111_l1_ (u"࠭ࠧ䚠"),l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้่ࠣๆ้ษอࠫ䚡"),message)
		l1lll_l1_ = menuItemsLIST
		if l1l1ll1111l_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧ䚢"),l1l111_l1_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࠩ䚣")+l1l11ll1llll_l1_,l1lll_l1_,l1l1lll1l1l_l1_)
	menuItemsLIST[:] = l1l11l11lll1_l1_
	return l1lll_l1_
def l1l11lll11l1_l1_(l1l11ll1llll_l1_,options,l1l11l1ll1ll_l1_):
	if l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䚤") in options and l1l11l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠬ䚥"): l1l11ll1ll1l_l1_(True)
	elif l1l11l1ll1ll_l1_: l1l11ll1ll1l_l1_(False)
	l1l11l1llll1_l1_ = options.replace(l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䚦"),l1l111_l1_ (u"࠭ࠧ䚧")).replace(l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䚨"),l1l111_l1_ (u"ࠨࠩ䚩")).replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䚪"),l1l111_l1_ (u"ࠪࠫ䚫"))
	if not l1l11l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䚬"),l1l111_l1_ (u"ࠬะอะ์ฮࠤ์ึ็ࠡษ็ๆฬฬๅสࠩ䚭"),l1l111_l1_ (u"࠭ࠧ䚮"),763,l1l111_l1_ (u"ࠧࠨ䚯"),l1l111_l1_ (u"ࠨࠩ䚰"),l1l111_l1_ (u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ䚱")+l1l11l1llll1_l1_,l1l111_l1_ (u"ࠪࠫ䚲"),{l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䚳"):l1l11ll1llll_l1_})
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䚴"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䚵"),l1l111_l1_ (u"ࠧࠨ䚶"),9999)
	l11111111_l1_ = [l1l111_l1_ (u"ࠨลไ่ฬ๋ࠧ䚷"),l1l111_l1_ (u"่ࠩืู้ไศฬࠪ䚸"),l1l111_l1_ (u"ุ้ࠪือ๋ษอࠫ䚹"),l1l111_l1_ (u"ࠫอืวๆฮࠪ䚺"),l1l111_l1_ (u"ࠬษืโษ็ࠤํ้ัห๊้ࠫ䚻"),l1l111_l1_ (u"࠭ัๆุส๊ࠬ䚼"),l1l111_l1_ (u"ࠧฤฯาฯ࠲ษฮาࠩ䚽"),l1l111_l1_ (u"ࠨี็หุ๊ࠧ䚾"),l1l111_l1_ (u"่ࠩ์ุ๐โ๊ࠩ䚿"),l1l111_l1_ (u"ࠪวูํั࠮ลๆฯึ࠭䛀"),l1l111_l1_ (u"ࠫฬ๊ย็ࠩ䛁"),l1l111_l1_ (u"ࠬ฼อไࠩ䛂"),l1l111_l1_ (u"࠭ั๋ษูอࠬ䛃"),l1l111_l1_ (u"ࠧ็์อๅ้้ำࠨ䛄"),l1l111_l1_ (u"ࠨ็่ฯ้๐ๆࠨ䛅"),l1l111_l1_ (u"ࠩหฯࠥำ๊ࠨ䛆"),l1l111_l1_ (u"ࠪำ๏์๊สࠩ䛇"),l1l111_l1_ (u"ุࠫ์่ศฬࠪ䛈"),l1l111_l1_ (u"ࠬษฮา๋ࠪ䛉")]
	l1l11l1l11ll_l1_ = [l1l111_l1_ (u"࠭วโๆส้ࠬ䛊"),l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭䛋"),l1l111_l1_ (u"ࠨใํ่๊࠭䛌"),l1l111_l1_ (u"ࠩไ่๊࠭䛍")]
	l1ll111l111_l1_ = [l1l111_l1_ (u"ุ้๊ࠪำๅࠩ䛎"),l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ䛏")]
	l1l1l11l1111_l1_ = [l1l111_l1_ (u"๋ࠬำศำะࠫ䛐"),l1l111_l1_ (u"࠭ๅิำะ๎ฬะࠧ䛑")]
	l1l11l1lll1l_l1_ = [l1l111_l1_ (u"ࠧษำส้ั࠭䛒"),l1l111_l1_ (u"ࠨࡵ࡫ࡳࡼ࠭䛓"),l1l111_l1_ (u"ࠩอ่ๆุ๊้่ࠪ䛔"),l1l111_l1_ (u"ࠪฮ้๐แำ์๋๊ࠬ䛕")]
	l1l11lllll11_l1_ = [l1l111_l1_ (u"ࠫฬ์ๅ๋ࠩ䛖"),l1l111_l1_ (u"้ࠬัห๊้ࠫ䛗"),l1l111_l1_ (u"࠭ใศำอ์๋࠭䛘"),l1l111_l1_ (u"ࠧ࡬࡫ࡧࡷࠬ䛙"),l1l111_l1_ (u"ࠨูไ่ࠬ䛚"),l1l111_l1_ (u"ࠩส฻ๆอไࠨ䛛")]
	l11111l1_l1_ = [l1l111_l1_ (u"ࠪี๊฼ว็ࠩ䛜")]
	l1lllll1l_l1_ = [l1l111_l1_ (u"ࠫฬำฯฬࠩ䛝"),l1l111_l1_ (u"ࠬอฮาࠩ䛞"),l1l111_l1_ (u"࠭ๅ้ะิࠫ䛟"),l1l111_l1_ (u"ࠧอัํำࠬ䛠"),l1l111_l1_ (u"ࠨ็ูหๆ࠭䛡"),l1l111_l1_ (u"ࠩะำ๏ัࠧ䛢")]
	l1l11ll111ll_l1_ = [l1l111_l1_ (u"ࠪื้อำๅࠩ䛣"),l1l111_l1_ (u"ุ๊ࠫำๅ้ࠪ䛤")]
	l1l11l11ll11_l1_ = [l1l111_l1_ (u"ࠬอฺศ่ํࠫ䛥"),l1l111_l1_ (u"࠭ๅ้ีํๆ๎࠭䛦"),l1l111_l1_ (u"ࠧไๆํฬࠬ䛧"),l1l111_l1_ (u"ࠨฯไ่ࠬ䛨"),l1l111_l1_ (u"ࠩࡰࡹࡸ࡯ࡣࠨ䛩")]
	l11l1l111_l1_ = [l1l111_l1_ (u"ࠪห่ััࠨ䛪"),l1l111_l1_ (u"ࠫฬฺ็าࠩ䛫"),l1l111_l1_ (u"๋ࠬๅ๋ิ๊ࠫ䛬"),l1l111_l1_ (u"࠭วฺๆ์ࠫ䛭"),l1l111_l1_ (u"ࠧๆะอหึํࠧ䛮"),l1l111_l1_ (u"ࠨ็ัฮฬืวหࠩ䛯"),l1l111_l1_ (u"ࠩสๆํ๏ࠧ䛰")]
	l1l11l11l1ll_l1_ = [l1l111_l1_ (u"ࠪห้อๆࠨ䛱"),l1l111_l1_ (u"ࠫาอไ๋ࠩ䛲"),l1l111_l1_ (u"๋ࠬหษฬࠪ䛳"),l1l111_l1_ (u"࠭ัศศฯࠫ䛴")]
	l1l11l11llll_l1_ = [l1l111_l1_ (u"ࠧืฯๆࠫ䛵"),l1l111_l1_ (u"ࠨๅ๋้๏ี๊ࠨ䛶")]
	l1l1l1111ll1_l1_ = [l1l111_l1_ (u"ࠩิ๎ฬ฼็ࠨ䛷"),l1l111_l1_ (u"ࠪ็ํื็ࠨ䛸"),l1l111_l1_ (u"๊ࠫ฻วา฻๊ࠫ䛹"),l1l111_l1_ (u"ฺ่ࠬหࠩ䛺"),l1l111_l1_ (u"࠭ั๋ษูอࠬ䛻")]
	l1l11lll1lll_l1_ = [l1l111_l1_ (u"ࠧ็์อๅ้้ำࠨ䛼"),l1l111_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ䛽"),l1l111_l1_ (u"้ࠩ๎ฯ็ไ๋ๅึࠫ䛾")]
	l1l11l1l111l_l1_ = [l1l111_l1_ (u"้๊ࠪัไ๋่ࠪ䛿"),l1l111_l1_ (u"ࠫฬฺฮศืࠪ䜀"),l1l111_l1_ (u"ࠬ์ฬ้็ࠪ䜁")]
	l1ll1llll_l1_ = [l1l111_l1_ (u"࠭ศฬࠢะ๎ࠬ䜂"),l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ䜃"),l1l111_l1_ (u"ࠨไ้ห์࠭䜄"),l1l111_l1_ (u"ࠩๅ๊ํอสࠨ䜅")]
	l1l11llll1l1_l1_ = [l1l111_l1_ (u"ࠪำ๏์ࠧ䜆"),l1l111_l1_ (u"ࠫฬีู๋้ࠪ䜇"),l1l111_l1_ (u"ุ๊ࠬศำสฮࠬ䜈"),l1l111_l1_ (u"࠭ไุ็ํหฯ࠭䜉"),l1l111_l1_ (u"ࠧะ฻สลࠬ䜊"),l1l111_l1_ (u"ࠨไิห๋࠭䜋"),l1l111_l1_ (u"ࠩๅูฬฬฯࠨ䜌"),l1l111_l1_ (u"ࠪีะอมࠨ䜍"),l1l111_l1_ (u"๊ࠫืฬฺ์๊ࠫ䜎"),l1l111_l1_ (u"ࠬอะศ่ࠪ䜏"),l1l111_l1_ (u"࠭วิๆส้ࠬ䜐"),l1l111_l1_ (u"ࠧห๊สุ๏ำࠧ䜑"),l1l111_l1_ (u"ࠨะฺฬࠬ䜒"),l1l111_l1_ (u"ࠩะ์ื๎๊ࠨ䜓"),l1l111_l1_ (u"ࠪ฽ฯฮวหࠩ䜔"),l1l111_l1_ (u"๊ࠫ๎วๅ์าࠫ䜕"),l1l111_l1_ (u"ࠬ์่ศ฻ํࠫ䜖"),l1l111_l1_ (u"ู࠭ใษษำࠬ䜗"),l1l111_l1_ (u"ࠧศ่สุ๏ีࠧ䜘")]
	l1l11l1l1l11_l1_ = [l1l111_l1_ (u"ࠨ࠳࠼ࠫ䜙"),l1l111_l1_ (u"ࠩ࠵࠴ࠬ䜚"),l1l111_l1_ (u"ࠪ࠶࠶࠭䜛"),l1l111_l1_ (u"ࠫ࠷࠸ࠧ䜜"),l1l111_l1_ (u"ࠬ࠸࠳ࠨ䜝"),l1l111_l1_ (u"࠭࠲࠵ࠩ䜞"),l1l111_l1_ (u"ࠧ࠳࠷ࠪ䜟"),l1l111_l1_ (u"ࠨ࠴࠹ࠫ䜠")]
	if not l1l11l1ll1ll_l1_:
		l1l11l1ll1ll_l1_ = 0
		for l1l11ll1lll1_l1_ in l11111111_l1_:
			l1l11l1ll1ll_l1_ += 1
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䜡"),l1lllll_l1_+l1l11ll1lll1_l1_,l1l111_l1_ (u"ࠪࠫ䜢"),763,l1l111_l1_ (u"ࠫࠬ䜣"),str(l1l11l1ll1ll_l1_),l1l11l1llll1_l1_,l1l111_l1_ (u"ࠬ࠭䜤"),{l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䜥"):l1l11ll1llll_l1_})
	else:
		for name in sorted(list(contentsDICT.keys())):
			l1llll1l1l1_l1_ = name.lower()
			category = []
			if any(value in l1llll1l1l1_l1_ for value in l1l11l1l11ll_l1_): category.append(1)
			if any(value in l1llll1l1l1_l1_ for value in l1ll111l111_l1_): category.append(2)
			if any(value in l1llll1l1l1_l1_ for value in l1l1l11l1111_l1_): category.append(3)
			if any(value in l1llll1l1l1_l1_ for value in l1l11l1lll1l_l1_): category.append(4)
			if any(value in l1llll1l1l1_l1_ for value in l1l11lllll11_l1_): category.append(5)
			if any(value in l1llll1l1l1_l1_ for value in l11111l1_l1_): category.append(6)
			if any(value in l1llll1l1l1_l1_ for value in l1lllll1l_l1_) and l1llll1l1l1_l1_ not in [l1l111_l1_ (u"ࠧศะิํࠬ䜦")]: category.append(7)
			if any(value in l1llll1l1l1_l1_ for value in l1l11ll111ll_l1_): category.append(8)
			if any(value in l1llll1l1l1_l1_ for value in l1l11l11ll11_l1_): category.append(9)
			if any(value in l1llll1l1l1_l1_ for value in l11l1l111_l1_): category.append(10)
			if any(value in l1llll1l1l1_l1_ for value in l1l11l11l1ll_l1_): category.append(11)
			if any(value in l1llll1l1l1_l1_ for value in l1l11l11llll_l1_): category.append(12)
			if any(value in l1llll1l1l1_l1_ for value in l1l1l1111ll1_l1_): category.append(13)
			if any(value in l1llll1l1l1_l1_ for value in l1l11lll1lll_l1_): category.append(14)
			if any(value in l1llll1l1l1_l1_ for value in l1l11l1l111l_l1_): category.append(15)
			if any(value in l1llll1l1l1_l1_ for value in l1ll1llll_l1_): category.append(16)
			if any(value in l1llll1l1l1_l1_ for value in l1l11llll1l1_l1_): category.append(17)
			if any(value in l1llll1l1l1_l1_ for value in l1l11l1l1l11_l1_): category.append(18)
			if not category: category = [19]
			for cat in category:
				if str(cat)==l1l11l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䜧"),l1lllll_l1_+name,name,166,l1l111_l1_ (u"ࠩࠪ䜨"),l1l111_l1_ (u"ࠪࠫ䜩"),l1l11l1llll1_l1_+l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䜪"))
	return
def l1l1l1111111_l1_(l1l11ll1llll_l1_,options):
	l1l1ll1111l_l1_ = False
	if l1l1ll1111l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䜫"),l1l111_l1_ (u"࠭สฮัํฯࠥํะ่ࠢส่็อฦๆหࠪ䜬"),l1l111_l1_ (u"ࠧࠨ䜭"),764,l1l111_l1_ (u"ࠨࠩ䜮"),l1l111_l1_ (u"ࠩࠪ䜯"),l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䜰"),l1l111_l1_ (u"ࠫࠬ䜱"),{l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䜲"):l1l11ll1llll_l1_})
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䜳"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䜴"),l1l111_l1_ (u"ࠨࠩ䜵"),9999)
	l1l11l11lll1_l1_ = menuItemsLIST[:]
	import IPTV
	if l1l11ll1llll_l1_:
		if not IPTV.CHECK_TABLES_EXIST(l1l11ll1llll_l1_,True): return
		l1l11ll11l11_l1_ = l1l11ll111l1_l1_(l1l11ll1llll_l1_,options)
		l1111l1ll1_l1_ = sorted(l1l11ll11l11_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠩࠪ䜶"),True): return
		if l1l1ll1111l_l1_ and l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䜷") not in options:
			l1111l1ll1_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䜸"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ䜹"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡋࡓࡘ࡛ࡥࡁࡍࡎࠪ䜺"))
		else:
			l1l11l1l1l1l_l1_,l1111l1ll1_l1_,l1l11ll11l11_l1_ = [],[],[]
			for l1l11ll1ll11_l1_ in range(1,FOLDERS_COUNT+1):
				l1111l1ll1_l1_ += l1l11ll111l1_l1_(str(l1l11ll1ll11_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in l1111l1ll1_l1_:
				if text not in l1l11l1l1l1l_l1_:
					l1l11l1l1l1l_l1_.append(text)
					l1l1l111l111_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llll11l11_l1_
					l1l11ll11l11_l1_.append(l1l1l111l111_l1_)
			l1111l1ll1_l1_ = sorted(l1l11ll11l11_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1ll1111l_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧ䜻"),l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࡃࡏࡐࠬ䜼"),l1111l1ll1_l1_,l1l1lll1l1l_l1_)
	menuItemsLIST[:] = l1l11l11lll1_l1_+l1111l1ll1_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭䜽"))
	return
def l1l1l111l1l1_l1_(l1l11ll1llll_l1_,options):
	l1l1ll1111l_l1_ = False
	if l1l1ll1111l_l1_:
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䜾"),l1l111_l1_ (u"ࠫฯำฯ๋อ๋ࠣีํࠠศๆๅหห๋ษࠨ䜿"),l1l111_l1_ (u"ࠬ࠭䝀"),765,l1l111_l1_ (u"࠭ࠧ䝁"),l1l111_l1_ (u"ࠧࠨ䝂"),l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䝃"),l1l111_l1_ (u"ࠩࠪ䝄"),{l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝅"):l1l11ll1llll_l1_})
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䝆"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䝇"),l1l111_l1_ (u"࠭ࠧ䝈"),9999)
	l1l11l11lll1_l1_ = menuItemsLIST[:]
	import M3U
	if l1l11ll1llll_l1_:
		if not M3U.CHECK_TABLES_EXIST(l1l11ll1llll_l1_,True): return
		l1l11ll11l11_l1_ = l1l11lll111l_l1_(l1l11ll1llll_l1_,options)
		l1111l1ll1_l1_ = sorted(l1l11ll11l11_l1_,reverse=False,key=lambda key: key[1].lower())
	else:
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠧࠨ䝉"),True): return
		if l1l1ll1111l_l1_ and l1l111_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䝊") not in options:
			l1111l1ll1_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䝋"),l1l111_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡓ࠳ࡖࠩ䝌"),l1l111_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࡅࡑࡒࠧ䝍"))
		else:
			l1l11l1l1l1l_l1_,l1111l1ll1_l1_,l1l11ll11l11_l1_ = [],[],[]
			for l1l11ll1ll11_l1_ in range(1,FOLDERS_COUNT+1):
				l1111l1ll1_l1_ += l1l11lll111l_l1_(str(l1l11ll1ll11_l1_),options)
			for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in l1111l1ll1_l1_:
				if text not in l1l11l1l1l1l_l1_:
					l1l11l1l1l1l_l1_.append(text)
					l1l1l111l111_l1_ = type,name,text,165,l11l_l1_,l1llllll1_l1_,options,context,l1llll11l11_l1_
					l1l11ll11l11_l1_.append(l1l1l111l111_l1_)
			l1111l1ll1_l1_ = sorted(l1l11ll11l11_l1_,reverse=False,key=lambda key: key[1].lower())
			if l1l1ll1111l_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ䝎"),l1l111_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤࡇࡌࡍࠩ䝏"),l1111l1ll1_l1_,l1l1lll1l1l_l1_)
	menuItemsLIST[:] = l1l11l11lll1_l1_+l1111l1ll1_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ䝐"))
	return
def l1l11l1ll11l_l1_(group,options):
	l1l1ll1111l_l1_ = False
	l1lll_l1_ = []
	l1l11lll1111_l1_ = l1l111_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䝑") if l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ䝒") in options else l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䝓")
	if l1l1ll1111l_l1_: l1lll_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠫࡱ࡯ࡳࡵࠩ䝔"),l1l111_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙ࠧ䝕")+l1l11lll1111_l1_[:-1],group)
	if not l1lll_l1_:
		for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
			if l1l1ll1111l_l1_: l1lll_l1_ += l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"࠭࡬ࡪࡵࡷࠫ䝖"),l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ䝗")+l1l11lll1111_l1_[:-1],l1l111_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ䝘")+l1l11lll1111_l1_+str(l1l11ll1llll_l1_))
			elif l1l11lll1111_l1_==l1l111_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䝙"): l1lll_l1_ += l1l11ll111l1_l1_(str(l1l11ll1llll_l1_),l1l111_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䝚"))
			elif l1l11lll1111_l1_==l1l111_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࠪ䝛"): l1lll_l1_ += l1l11lll111l_l1_(str(l1l11ll1llll_l1_),l1l111_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䝜"))
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in l1lll_l1_:
			if text==group: l1ll11ll1l1l_l1_(type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_)
		items,l1l1111_l1_ = [],[]
		for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in menuItemsLIST:
			l1l11llll11l_l1_ = type,name[4:],url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1l111_l1_ (u"࠭ࠧ䝝")
			if l1l11llll11l_l1_ not in l1l1111_l1_:
				l1l1111_l1_.append(l1l11llll11l_l1_)
				item = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_
				items.append(item)
		l1lll_l1_ = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if l1l1ll1111l_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩ䝞")+l1l11lll1111_l1_[:-1],group,l1lll_l1_,l1l1lll1l1l_l1_)
	if l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䝟") in options and len(l1lll_l1_)>l1l1l11111l1_l1_:
		menuItemsLIST[:] = []
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䝠"),l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䝡")+group+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䝢"),group,165,l1l111_l1_ (u"ࠬ࠭䝣"),l1l111_l1_ (u"࠭ࠧ䝤"),l1l11lll1111_l1_+l1l111_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䝥"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䝦"),l1l111_l1_ (u"ࠩศ฽ฬีษࠡษ็฻้ฮࠠศๆ฼ุํอฦ๋่๊ࠢࠥ์แิࠢส่็ูๅࠨ䝧"),group,165,l1l111_l1_ (u"ࠪࠫ䝨"),l1l111_l1_ (u"ࠫࠬ䝩"),l1l11lll1111_l1_+l1l111_l1_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䝪"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䝫"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䝬"),l1l111_l1_ (u"ࠨࠩ䝭"),9999)
		l1lll_l1_ = menuItemsLIST+random.sample(l1lll_l1_,l1l1l11111l1_l1_)
	menuItemsLIST[:] = l1lll_l1_
	xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭䝮"))
	return
def l1l1l11l111l_l1_(options):
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䝯"),l1l111_l1_ (u"ࠫส฿วะหࠣ฻้ฮࠠใ่๋หฯูࠦี๊สส๏ฯࠧ䝰"),l1l111_l1_ (u"ࠬ࠭䝱"),161,l1l111_l1_ (u"࠭ࠧ䝲"),l1l111_l1_ (u"ࠧࠨ䝳"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䝴"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䝵"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䝶"),l1l111_l1_ (u"ࠫࠬ䝷"),9999)
	l1l11lllllll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	import l1lll1l1l1ll_l1_
	l1lll1l1l1ll_l1_.ITEMS(l1l111_l1_ (u"ࠬ࠶ࠧ䝸"),False)
	l1lll1l1l1ll_l1_.ITEMS(l1l111_l1_ (u"࠭࠱ࠨ䝹"),False)
	l1lll1l1l1ll_l1_.ITEMS(l1l111_l1_ (u"ࠧ࠳ࠩ䝺"),False)
	if l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䝻") in options:
		menuItemsLIST[:] = l1l11ll1l111_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l1l1l11111l1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11111l1_l1_)
	menuItemsLIST[:] = l1l11lllllll_l1_+menuItemsLIST
	return
def l1l1l111llll_l1_(options):
	options = options.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䝼"),l1l111_l1_ (u"ࠪࠫ䝽")).replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䝾"),l1l111_l1_ (u"ࠬ࠭䝿"))
	headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䞀") : l1l111_l1_ (u"ࠧࠨ䞁") }
	url = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡦࡵࡷࡶࡦࡴࡤࡰ࡯ࡶ࠲ࡨࡵ࡭࠰ࡴࡤࡲࡩࡵ࡭࠮ࡣࡵࡥࡧ࡯ࡣ࠮ࡹࡲࡶࡩࡹࠧ䞂")
	data = {l1l111_l1_ (u"ࠩࡴࡹࡦࡴࡴࡪࡶࡼࠫ䞃"):l1l111_l1_ (u"ࠪ࠹࠵࠭䞄")}
	data = l1lllll11_l1_(data)
	response = l11l1l_l1_(l1lll111l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ䞅"),url,data,headers,l1l111_l1_ (u"ࠬ࠭䞆"),l1l111_l1_ (u"࠭ࠧ䞇"),l1l111_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩ䞈"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪ䞉"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ䞊"),block,re.DOTALL)
	l1l11l11l11l_l1_,l1l11l1l1ll1_l1_ = list(zip(*items))
	l1l1l111l11l_l1_ = []
	l1l1l111lll1_l1_ = [l1l111_l1_ (u"ࠪࠤࠬ䞋"),l1l111_l1_ (u"ࠫࠧ࠭䞌"),l1l111_l1_ (u"ࠬࡦࠧ䞍"),l1l111_l1_ (u"࠭ࠬࠨ䞎"),l1l111_l1_ (u"ࠧ࠯ࠩ䞏"),l1l111_l1_ (u"ࠨ࠼ࠪ䞐"),l1l111_l1_ (u"ࠩ࠾ࠫ䞑"),l1l111_l1_ (u"ࠥࠫࠧ䞒"),l1l111_l1_ (u"ࠫ࠲࠭䞓")]
	l1l11l1lllll_l1_ = l1l11l1l1ll1_l1_+l1l11l11l11l_l1_
	for word in l1l11l1lllll_l1_:
		if word in l1l11l1l1ll1_l1_: l1l11lll1ll1_l1_ = 2
		if word in l1l11l11l11l_l1_: l1l11lll1ll1_l1_ = 4
		l1l11ll1111l_l1_ = [i in word for i in l1l1l111lll1_l1_]
		if any(l1l11ll1111l_l1_):
			index = l1l11ll1111l_l1_.index(True)
			l1l11l1lll11_l1_ = l1l1l111lll1_l1_[index]
			l1l1l1111l11_l1_ = l1l111_l1_ (u"ࠬ࠭䞔")
			if word.count(l1l11l1lll11_l1_)>1: l1l1l1111l1l_l1_,l1l1l11111ll_l1_,l1l1l1111l11_l1_ = word.split(l1l11l1lll11_l1_,2)
			else: l1l1l1111l1l_l1_,l1l1l11111ll_l1_ = word.split(l1l11l1lll11_l1_,1)
			if len(l1l1l1111l1l_l1_)>l1l11lll1ll1_l1_: l1l1l111l11l_l1_.append(l1l1l1111l1l_l1_.lower())
			if len(l1l1l11111ll_l1_)>l1l11lll1ll1_l1_: l1l1l111l11l_l1_.append(l1l1l11111ll_l1_.lower())
			if len(l1l1l1111l11_l1_)>l1l11lll1ll1_l1_: l1l1l111l11l_l1_.append(l1l1l1111l11_l1_.lower())
		elif len(word)>l1l11lll1ll1_l1_: l1l1l111l11l_l1_.append(word.lower())
	for i in range(9): random.shuffle(l1l1l111l11l_l1_)
	if l1l111_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ䞕") in options:
		l1l11l1l1111_l1_ = l1ll1l1l1l1l_l1_
	elif l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䞖") in options:
		l1l11l1l1111_l1_ = [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭䞗")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠩࠪ䞘"),True): return
	elif l1l111_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࠩ䞙") in options:
		l1l11l1l1111_l1_ = [l1l111_l1_ (u"ࠫࡒ࠹ࡕࠨ䞚")]
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠬ࠭䞛"),True): return
	count,l1l11l1l1lll_l1_ = 0,0
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䞜"),l1l111_l1_ (u"ࠧ࡜ࠢࠣࡡࠥࡀวๅสะฯࠥ฿ๆࠨ䞝"),l1l111_l1_ (u"ࠨࠩ䞞"),164,l1l111_l1_ (u"ࠩࠪ䞟"),l1l111_l1_ (u"ࠪࠫ䞠"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䞡")+options)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䞢"),l1l111_l1_ (u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭䞣"),l1l111_l1_ (u"ࠧࠨ䞤"),164,l1l111_l1_ (u"ࠨࠩ䞥"),l1l111_l1_ (u"ࠩࠪ䞦"),l1l111_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䞧")+options)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䞨"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䞩"),l1l111_l1_ (u"࠭ࠧ䞪"),9999)
	l1l11l11l111_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1l1l111ll1l_l1_ = []
	for word in l1l1l111l11l_l1_:
		l1l1l11111ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡜ࠢ࡟࠰ࡡࡁ࡜࠻࡞࠰ࡠ࠰ࡢ࠽࡝ࠤ࡟ࠫࡡࡡ࡜࡞࡞ࠫࡠ࠮ࡢࡻ࡝ࡿ࡟ࠥࡡࡆࠧ䞫")+l1l111_l1_ (u"ࠨࠥࠪ䞬")+l1l111_l1_ (u"ࠩ࡟ࠨࡡࠫ࡜࡟࡞ࠩࡠ࠯ࡢ࡟࡝࠾࡟ࡂࡢ࠭䞭"),word,re.DOTALL)
		if l1l1l11111ll_l1_: word = word.split(l1l1l11111ll_l1_[0],1)[0]
		l1l11lllll1l_l1_ = word.replace(l1l111_l1_ (u"ࠪ๕ࠬ䞮"),l1l111_l1_ (u"ࠫࠬ䞯")).replace(l1l111_l1_ (u"ࠬ๔ࠧ䞰"),l1l111_l1_ (u"࠭ࠧ䞱")).replace(l1l111_l1_ (u"ࠧ์ࠩ䞲"),l1l111_l1_ (u"ࠨࠩ䞳")).replace(l1l111_l1_ (u"ࠩ๒ࠫ䞴"),l1l111_l1_ (u"ࠪࠫ䞵")).replace(l1l111_l1_ (u"ࠫ๑࠭䞶"),l1l111_l1_ (u"ࠬ࠭䞷"))
		l1l11lllll1l_l1_ = l1l11lllll1l_l1_.replace(l1l111_l1_ (u"࠭๐ࠨ䞸"),l1l111_l1_ (u"ࠧࠨ䞹")).replace(l1l111_l1_ (u"ࠨ๏ࠪ䞺"),l1l111_l1_ (u"ࠩࠪ䞻")).replace(l1l111_l1_ (u"ࠪ๖ࠬ䞼"),l1l111_l1_ (u"ࠫࠬ䞽")).replace(l1l111_l1_ (u"ࠬฒࠧ䞾"),l1l111_l1_ (u"࠭ࠧ䞿")).replace(l1l111_l1_ (u"ࠧแࠩ䟀"),l1l111_l1_ (u"ࠨࠩ䟁"))
		if l1l11lllll1l_l1_: l1l1l111ll1l_l1_.append(l1l11lllll1l_l1_)
	l1l11llll1ll_l1_ = []
	for l1l11l111l_l1_ in range(0,20):
		search = random.sample(l1l1l111ll1l_l1_,1)[0]
		if search in l1l11llll1ll_l1_: continue
		l1l11llll1ll_l1_.append(search)
		l1ll1ll1ll1_l1_ = random.sample(l1l11l1l1111_l1_,1)[0]
		l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䟂"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡒࡢࡰࡧࡳࡲࠦࡖࡪࡦࡨࡳ࡙ࠥࡥࡢࡴࡦ࡬ࠥࠦࠠࡴ࡫ࡷࡩ࠿࠭䟃")+str(l1ll1ll1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࡳࡦࡣࡵࡧ࡭ࡀࠧ䟄")+search)
		l1ll1l1ll1l_l1_,l1ll1ll1l1l_l1_,l1lll11ll11_l1_ = l1ll1l1l111_l1_(l1ll1ll1ll1_l1_)
		l1ll1ll1l1l_l1_(search+l1l111_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ䟅"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ䟆"),l1l111_l1_ (u"ࠧࠨ䟇"))
	l1l11l11l111_l1_[0][1] = l1l111_l1_ (u"ࠨ࡝࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䟈")+search+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠤ࠿ฮอฬࠢ฼๊ࡢ࠭䟉")
	menuItemsLIST[:] = l1l11ll1l111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l1l1l11111l1_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l1l1l11111l1_l1_)
	menuItemsLIST[:] = l1l11l11l111_l1_+menuItemsLIST
	return
def l1l1l1111lll_l1_(l1l11l1ll1l1_l1_,options):
	l1l11l1ll1l1_l1_ = l1l11l1ll1l1_l1_.replace(l1l111_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ䟊"),l1l111_l1_ (u"ࠫࠬ䟋"))
	options = options.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䟌"),l1l111_l1_ (u"࠭ࠧ䟍")).replace(l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䟎"),l1l111_l1_ (u"ࠨࠩ䟏"))
	l1l11ll1ll1l_l1_(False)
	if contentsDICT=={}: return
	if l1l111_l1_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ䟐") in options:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䟑"),l1l111_l1_ (u"ࠫࡠࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䟒")+l1l11l1ll1l1_l1_+l1l111_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠻ษ็ๆุ๋࡝ࠨ䟓"),l1l11l1ll1l1_l1_,166,l1l111_l1_ (u"࠭ࠧ䟔"),l1l111_l1_ (u"ࠧࠨ䟕"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䟖")+options)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟗"),l1l111_l1_ (u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩ䟘"),l1l11l1ll1l1_l1_,166,l1l111_l1_ (u"ࠫࠬ䟙"),l1l111_l1_ (u"ࠬ࠭䟚"),l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䟛")+options)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䟜"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䟝"),l1l111_l1_ (u"ࠩࠪ䟞"),9999)
	for l1l11l11_l1_ in sorted(list(contentsDICT[l1l11l1ll1l1_l1_].keys())):
		type,name,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = contentsDICT[l1l11l1ll1l1_l1_][l1l11l11_l1_]
		if l1l111_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䟟") in options or len(contentsDICT[l1l11l1ll1l1_l1_])==1:
			l1ll11ll1l1l_l1_(type,l1l111_l1_ (u"ࠫࠬ䟠"),url,l1ll1l1ll1l1_l1_,l1l111_l1_ (u"ࠬ࠭䟡"),l1llllll1_l1_,text,l1l111_l1_ (u"࠭ࠧ䟢"),l1l111_l1_ (u"ࠧࠨ䟣"))
			menuItemsLIST[:] = l1l11ll1l111_l1_(menuItemsLIST)
			l1l11l11lll1_l1_,l1111l1ll1_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1111l1ll1_l1_)
			if l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䟤") in options: menuItemsLIST[:] = l1l11l11lll1_l1_+l1111l1ll1_l1_[:l1l1l11111l1_l1_]
			else: menuItemsLIST[:] = l1l11l11lll1_l1_+l1111l1ll1_l1_
		elif l1l111_l1_ (u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪ䟥") in options: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䟦"),l1l11l11_l1_,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_)
	return
def l1l11ll11l1l_l1_(options,mode):
	options = options.replace(l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䟧"),l1l111_l1_ (u"ࠬ࠭䟨")).replace(l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䟩"),l1l111_l1_ (u"ࠧࠨ䟪"))
	name,l1l11ll11111_l1_ = l1l111_l1_ (u"ࠨࠩ䟫"),[]
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟬"),l1l111_l1_ (u"ࠪ࡟ࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䟭")+name+l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠺ศๆๅื๊ࡣࠧ䟮"),l1l111_l1_ (u"ࠬ࠭䟯"),mode,l1l111_l1_ (u"࠭ࠧ䟰"),l1l111_l1_ (u"ࠧࠨ䟱"),l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䟲")+options)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䟳"),l1l111_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโิ็ࠣ฽ู๎วว์ࠪ䟴"),l1l111_l1_ (u"ࠫࠬ䟵"),mode,l1l111_l1_ (u"ࠬ࠭䟶"),l1l111_l1_ (u"࠭ࠧ䟷"),l1l111_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䟸")+options)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䟹"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䟺"),l1l111_l1_ (u"ࠪࠫ䟻"),9999)
	l1l11l11lll1_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l1lll_l1_ = []
	if l1l111_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ䟼") in options:
		l1l11ll1ll1l_l1_(False)
		if contentsDICT=={}: return
		l1l11ll11lll_l1_ = list(contentsDICT.keys())
		l1l11l1ll1l1_l1_ = random.sample(l1l11ll11lll_l1_,1)[0]
		l1l1l111l11l_l1_ = list(contentsDICT[l1l11l1ll1l1_l1_].keys())
		l1l11l11_l1_ = random.sample(l1l1l111l11l_l1_,1)[0]
		type,name,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = contentsDICT[l1l11l1ll1l1_l1_][l1l11l11_l1_]
		l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䟽"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩ䟾")+l1l11l11_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䟿")+name+l1l111_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䠀")+url+l1l111_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䠁")+str(l1ll1l1ll1l1_l1_))
	elif l1l111_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䠂") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠫࠬ䠃"),True): return
		for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l11ll111l1_l1_(str(l1l11ll1llll_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = random.sample(l1lll_l1_,1)[0]
		l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䠄"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䠅")+name+l1l111_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䠆")+url+l1l111_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䠇")+str(l1ll1l1ll1l1_l1_))
	elif l1l111_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䠈") in options:
		import M3U
		if not M3U.CHECK_TABLES_EXIST(l1l111_l1_ (u"ࠪࠫ䠉"),True): return
		for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
			l1lll_l1_ += l1l11lll111l_l1_(str(l1l11ll1llll_l1_),options)
		if not l1lll_l1_: return
		type,name,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = random.sample(l1lll_l1_,1)[0]
		l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䠊"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ䠋")+name+l1l111_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ䠌")+url+l1l111_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ䠍")+str(l1ll1l1ll1l1_l1_))
	l1l11llll111_l1_ = name
	l1l11ll1l1l1_l1_ = []
	for i in range(0,10):
		if i>0: l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䠎"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ䠏")+name+l1l111_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䠐")+url+l1l111_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䠑")+str(l1ll1l1ll1l1_l1_))
		menuItemsLIST[:] = []
		if l1ll1l1ll1l1_l1_==234 and l1l111_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䠒") in text: l1ll1l1ll1l1_l1_ = 233
		if l1ll1l1ll1l1_l1_==714 and l1l111_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䠓") in text: l1ll1l1ll1l1_l1_ = 713
		if l1ll1l1ll1l1_l1_==144: l1ll1l1ll1l1_l1_ = 291
		dummy = l1ll11ll1l1l_l1_(type,name,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_)
		if l1l111_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥࠧ䠔") in options and l1ll1l1ll1l1_l1_==167: del menuItemsLIST[:3]
		if l1l111_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䠕") in options and l1ll1l1ll1l1_l1_==168: del menuItemsLIST[:3]
		l1l11ll11111_l1_[:] = l1l11ll1l111_l1_(menuItemsLIST)
		if l1l11ll1l1l1_l1_ and l111l1l1l11_l1_(l1l111_l1_ (u"ࡷࠪั้่ษࠨ䠖")) in str(l1l11ll11111_l1_) or l111l1l1l11_l1_(l1l111_l1_ (u"ࡸࠫา๊โ่ࠩ䠗")) in str(l1l11ll11111_l1_):
			name = l1l11llll111_l1_
			l1l11ll11111_l1_[:] = l1l11ll1l1l1_l1_
			break
		l1l11llll111_l1_ = name
		l1l11ll1l1l1_l1_ = l1l11ll11111_l1_
		if str(l1l11ll11111_l1_).count(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䠘"))>0: break
		if str(l1l11ll11111_l1_).count(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ䠙"))>0: break
		if l1ll1l1ll1l1_l1_==233: break
		if l1ll1l1ll1l1_l1_==713: break
		if l1ll1l1ll1l1_l1_==291: break
		if l1l11ll11111_l1_: type,name,url,l1ll1l1ll1l1_l1_,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = random.sample(l1l11ll11111_l1_,1)[0]
	if not name: name = l1l111_l1_ (u"࠭࠮࠯࠰࠱ࠫ䠚")
	elif name.count(l1l111_l1_ (u"ࠧࡠࠩ䠛"))>1: name = name.split(l1l111_l1_ (u"ࠨࡡࠪ䠜"),2)[2]
	name = name.replace(l1l111_l1_ (u"ࠩࡘࡒࡐࡔࡏࡘࡐ࠽ࠤࠬ䠝"),l1l111_l1_ (u"ࠪࠫ䠞"))
	name = name.replace(l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䠟"),l1l111_l1_ (u"ࠬ࠭䠠"))
	l1l11l11lll1_l1_[0][1] = l1l111_l1_ (u"࡛࠭࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ䠡")+name+l1l111_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠽ห้่ำๆ࡟ࠪ䠢")
	for i in range(9): random.shuffle(l1l11ll11111_l1_)
	if l1l111_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䠣") in options: menuItemsLIST[:] = l1l11l11lll1_l1_+l1l11ll11111_l1_[:l1l1l11111l1_l1_]
	else: menuItemsLIST[:] = l1l11l11lll1_l1_+l1l11ll11111_l1_
	return
def l1l11l1ll111_l1_(l1l11l11l1l1_l1_,l1l1l111111l_l1_):
	l1l1l111111l_l1_ = l1l1l111111l_l1_.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䠤"),l1l111_l1_ (u"ࠪࠫ䠥")).replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䠦"),l1l111_l1_ (u"ࠬ࠭䠧"))
	l1l11ll11ll1_l1_ = l1l1l111111l_l1_
	if l1l111_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䠨") in l1l1l111111l_l1_:
		l1l11ll11ll1_l1_ = l1l1l111111l_l1_.split(l1l111_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䠩"))[0]
		type = l1l111_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ䠪")
	elif l1l111_l1_ (u"࡙ࠩࡓࡉ࠭䠫") in l1l11l11l1l1_l1_: type = l1l111_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭䠬")
	elif l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ䠭") in l1l11l11l1l1_l1_: type = l1l111_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭䠮")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䠯"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䠰")+type+l1l11ll11ll1_l1_+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䠱"),l1l11l11l1l1_l1_,167,l1l111_l1_ (u"ࠩࠪ䠲"),l1l111_l1_ (u"ࠪࠫ䠳"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䠴")+l1l1l111111l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䠵"),l1l111_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䠶"),l1l11l11l1l1_l1_,167,l1l111_l1_ (u"ࠧࠨ䠷"),l1l111_l1_ (u"ࠨࠩ䠸"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䠹")+l1l1l111111l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䠺"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䠻"),l1l111_l1_ (u"ࠬ࠭䠼"),9999)
	import IPTV
	for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䠽") in l1l1l111111l_l1_: IPTV.GROUPS(str(l1l11ll1llll_l1_),l1l11l11l1l1_l1_,l1l1l111111l_l1_,l1l111_l1_ (u"ࠧࠨ䠾"),False)
		else: IPTV.ITEMS(str(l1l11ll1llll_l1_),l1l11l11l1l1_l1_,l1l1l111111l_l1_,l1l111_l1_ (u"ࠨࠩ䠿"),False)
	menuItemsLIST[:] = l1l11ll1l111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11111l1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11111l1_l1_)
	return
def l1l11l11ll1l_l1_(l1l11l11l1l1_l1_,l1l1l111111l_l1_):
	l1l1l111111l_l1_ = l1l1l111111l_l1_.replace(l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䡀"),l1l111_l1_ (u"ࠪࠫ䡁")).replace(l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䡂"),l1l111_l1_ (u"ࠬ࠭䡃"))
	l1l11ll11ll1_l1_ = l1l1l111111l_l1_
	if l1l111_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䡄") in l1l1l111111l_l1_:
		l1l11ll11ll1_l1_ = l1l1l111111l_l1_.split(l1l111_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䡅"))[0]
		type = l1l111_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ䡆")
	elif l1l111_l1_ (u"࡙ࠩࡓࡉ࠭䡇") in l1l11l11l1l1_l1_: type = l1l111_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭䡈")
	elif l1l111_l1_ (u"ࠫࡑࡏࡖࡆࠩ䡉") in l1l11l11l1l1_l1_: type = l1l111_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭䡊")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䡋"),l1l111_l1_ (u"ࠧ࡜࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䡌")+type+l1l11ll11ll1_l1_+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࠾ฬ๊โิ็ࡠࠫ䡍"),l1l11l11l1l1_l1_,168,l1l111_l1_ (u"ࠩࠪ䡎"),l1l111_l1_ (u"ࠪࠫ䡏"),l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䡐")+l1l1l111111l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䡑"),l1l111_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䡒"),l1l11l11l1l1_l1_,168,l1l111_l1_ (u"ࠧࠨ䡓"),l1l111_l1_ (u"ࠨࠩ䡔"),l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䡕")+l1l1l111111l_l1_)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䡖"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䡗"),l1l111_l1_ (u"ࠬ࠭䡘"),9999)
	import M3U
	for l1l11ll1llll_l1_ in range(1,FOLDERS_COUNT+1):
		if l1l111_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䡙") in l1l1l111111l_l1_: M3U.GROUPS(str(l1l11ll1llll_l1_),l1l11l11l1l1_l1_,l1l1l111111l_l1_,l1l111_l1_ (u"ࠧࠨ䡚"),False)
		else: M3U.ITEMS(str(l1l11ll1llll_l1_),l1l11l11l1l1_l1_,l1l1l111111l_l1_,l1l111_l1_ (u"ࠨࠩ䡛"),False)
	menuItemsLIST[:] = l1l11ll1l111_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l1l1l11111l1_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l1l1l11111l1_l1_)
	return
def l1l11ll1l111_l1_(menuItemsLIST):
	l1l11ll11111_l1_ = []
	for type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ in menuItemsLIST:
		if l1l111_l1_ (u"ุࠩๅาฯࠧ䡜") in name or l1l111_l1_ (u"ูࠪๆำ็ࠨ䡝") in name or l1l111_l1_ (u"ࠫࡵࡧࡧࡦࠩ䡞") in name.lower(): continue
		l1l11ll11111_l1_.append([type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_])
	return l1l11ll11111_l1_
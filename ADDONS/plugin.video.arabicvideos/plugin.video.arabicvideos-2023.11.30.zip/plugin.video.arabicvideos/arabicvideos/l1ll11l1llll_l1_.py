# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫ࡜ࡋࡃࡊࡏࡄࠫ婣")
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ婤"):l1l111_l1_ (u"࠭ࠧ婥")}
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠ࡙ࡆࡑࡤ࠭婦")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ婧"),l1l111_l1_ (u"ࠩࡺࡻࡪ࠭婨")]
def l11l1ll_l1_(mode,url,text):
	if   mode==560: l1lll_l1_ = l1l1l11_l1_()
	elif mode==561: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==562: l1lll_l1_ = PLAY(url)
	elif mode==563: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==564: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ婩")+text)
	elif mode==565: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ婪")+text)
	elif mode==566: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==569: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ婫"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭婬"),l111l1_l1_,569,l1l111_l1_ (u"ࠧࠨ婭"),l1l111_l1_ (u"ࠨࠩ婮"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭婯"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ婰"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ婱"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ婲"),564)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭婳"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ婴"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ婵"),565)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ婶"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ婷"),l1l111_l1_ (u"ࠫࠬ婸"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ婹"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ婺"),l1l111_l1_ (u"ࠧࠨ婻"),l1l111_l1_ (u"ࠨࠩ婼"),l1l111_l1_ (u"ࠩࠪ婽"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ婾"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡳࡍ࡫ࡶࡸࡇࡻࡴࡵࡱࡱࠦࠬ婿"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ媀"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"࠭ࠧ媁"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媂"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ媃")+l1lllll_l1_+title,l1ll1ll_l1_,566)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ媄"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ媅"),l1l111_l1_ (u"ࠫࠬ媆"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠧ媇"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭媈"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ媉"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ媊")+l1lllll_l1_+title,l1ll1ll_l1_,566,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭媋"),url,l1l111_l1_ (u"ࠪࠫ媌"),l1l111_l1_ (u"ࠫࠬ媍"),l1l111_l1_ (u"ࠬ࠭媎"),l1l111_l1_ (u"࠭ࠧ媏"),l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ媐"))
	html = response.content
	if l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ媑") in html:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媒"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ媓"),url,561,l1l111_l1_ (u"ࠫࠬ媔"),l1l111_l1_ (u"ࠬ࠭媕"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ媖"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ媗"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ媘"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ媙"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1lll11_l1_(l1lll1l11lll_l1_,type=l1l111_l1_ (u"ࠪࠫ媚")):
	if l1l111_l1_ (u"ࠫ࠿ࡀࠧ媛") in l1lll1l11lll_l1_:
		l1llllll_l1_,url = l1lll1l11lll_l1_.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ媜"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ媝"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1l11lll_l1_,l1lll1l11lll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ媞"),url,l1l111_l1_ (u"ࠨࠩ媟"),l1l111_l1_ (u"ࠩࠪ媠"),l1l111_l1_ (u"ࠪࠫ媡"),l1l111_l1_ (u"ࠫࠬ媢"),l1l111_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ媣"))
	html = response.content
	if type==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ媤"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ媥"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ媦"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭媧"),l1l111_l1_ (u"ࠪ࠳ࠬ媨")).replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ媩"),l1l111_l1_ (u"ࠬࠨࠧ媪"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲࡝ࡥࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ媫"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡈࡴ࡬ࡨࡎࡺࡥ࡮ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭媬"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ媭"),l1l111_l1_ (u"ࠩࠪ媮"))
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ媯") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ媰"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠬำไใหࠪ媱") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ媲"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭媳") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ媴"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ媵"),l1lllll_l1_+title,l1ll1ll_l1_,562,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ媶"):
			l1111ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ媷"),block,re.DOTALL)
			if l1111ll11l_l1_:
				count = l1111ll11l_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ媸")+count
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭媹"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ媺"),l1ll1ll_l1_,561,l1l111_l1_ (u"ࠨࠩ媻"),l1l111_l1_ (u"ࠩࠪ媼"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ媽"))
		elif type==l1l111_l1_ (u"ࠫࠬ媾"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭媿"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ嫀"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠧึใะอࠥ࠭嫁")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嫂"),l1lllll_l1_+title,l1ll1ll_l1_,561)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ嫃")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ嫄"),url,l1l111_l1_ (u"ࠫࠬ嫅"),l1l111_l1_ (u"ࠬ࠭嫆"),l1l111_l1_ (u"࠭ࠧ嫇"),l1l111_l1_ (u"ࠧࠨ嫈"),l1l111_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ嫉"))
	html = response.content
	html = l111l11_l1_(html)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ嫊"),html,re.DOTALL)
	if not type and l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ嫋"),block,re.DOTALL)
		if len(items)>1:
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫌"),l1lllll_l1_+title,l1ll1ll_l1_,563,l1l111_l1_ (u"ࠬ࠭嫍"),l1l111_l1_ (u"࠭ࠧ嫎"),l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ嫏"))
			return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࡳ࠿ࠩ嫐"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠪ嫑"),block,re.DOTALL|re.IGNORECASE)
		for l1ll1ll_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ嫒"))
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嫓"),l1lllll_l1_+title,l1ll1ll_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ嫔"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ嫕"),l1l111_l1_ (u"ࠧࠨ嫖")).replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ嫗"),l1l111_l1_ (u"ࠩࠪ嫘"))
		else: title = l1l111_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ嫙")
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嫚"),l1lllll_l1_+title,url,562)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嫛"),url,l1l111_l1_ (u"࠭ࠧ嫜"),l1l111_l1_ (u"ࠧࠨ嫝"),l1l111_l1_ (u"ࠨࠩ嫞"),l1l111_l1_ (u"ࠩࠪ嫟"),l1l111_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ嫠"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嫡"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ嫢"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嫣"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嫤") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠨีํีๆื้ࠠ์ࠣื๏๋วࠨ嫥"): name = l1l111_l1_ (u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ嫦")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ嫧")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ嫨")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嫩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ嫪"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ嫫") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ嫬"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ嫭")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠫ嫮")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡼ࡫ࡣࡪ࡯ࡤࠫ嫯")+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ嫰")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嫱"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠧࠨ嫲")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ嫳"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ嫴"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ嫵"),l1l111_l1_ (u"ࠫ࠰࠭嫶"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠬ࠵ࠧ嫷"),l1l111_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡹࡥࡳ࡫ࡨࡷࠬ嫸"),l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡡ࡯࡫ࡰࡩࠬ嫹"),l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡵࡸࠪ嫺"),l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴࠨ嫻")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠪวๆ๊วๆࠩ嫼"),l1l111_l1_ (u"ู๊ࠫไิๆสฮࠬ嫽"),l1l111_l1_ (u"ࠬษๆ๋็ํࠤํ้ัห๊้ࠫ嫾"),l1l111_l1_ (u"࠭ศาษ่ะࠥะไ๋ใี๎ํ์ࠧ嫿"),l1l111_l1_ (u"ࠧๆี็ื้อส๊ࠡฦ๊๏๋๊ࠨ嬀")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆู็์อࡀࠧ嬁"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if not hostname:
		hostname = l111l1_l1_
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫ嬂")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lll1l11lll_l1_,filter):
	if l1l111_l1_ (u"ࠪࡃࡄ࠭嬃") in l1lll1l11lll_l1_: url = l1lll1l11lll_l1_.split(l1l111_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ嬄"))[0]
	else: url = l1lll1l11lll_l1_
	filter = filter.replace(l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ嬅"),l1l111_l1_ (u"࠭ࠧ嬆"))
	type,filter = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ嬇"),1)
	if filter==l1l111_l1_ (u"ࠨࠩ嬈"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠩࠪ嬉"),l1l111_l1_ (u"ࠪࠫ嬊")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ嬋"))
	if type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ嬌"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"࠭࠽࠾ࠩ嬍") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠧ࠾࠿ࠪ嬎") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ嬏")+category+l1l111_l1_ (u"ࠩࡀࡁ࠵࠭嬐")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭嬑")+category+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ嬒")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ嬓"))+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ嬔")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠧࠧࠨࠪ嬕"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嬖"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ嬗")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ嬘"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭嬙"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"ࠬ࠭嬚"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嬛"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠧࠨ嬜"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ嬝")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1l11lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬞"),l1lllll_l1_+l1l111_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭嬟"),l1111111_l1_,561,l1l111_l1_ (u"ࠫࠬ嬠"),l1l111_l1_ (u"ࠬ࠭嬡"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ嬢"))
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嬣"),l1lllll_l1_+l1l111_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ嬤")+l11l1l1l_l1_+l1l111_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ嬥"),l1111111_l1_,561,l1l111_l1_ (u"ࠪࠫ嬦"),l1l111_l1_ (u"ࠫࠬ嬧"),l1l111_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嬨"))
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嬩"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嬪"),l1l111_l1_ (u"ࠨࠩ嬫"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭嬬"),url,l1l111_l1_ (u"ࠪࠫ嬭"),l1l111_l1_ (u"ࠫࠬ嬮"),l1l111_l1_ (u"ࠬ࠭嬯"),l1l111_l1_ (u"࠭ࠧ嬰"),l1l111_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ嬱"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠨ࡞࡟ࠦࠬ嬲"),l1l111_l1_ (u"ࠩࠥࠫ嬳")).replace(l1l111_l1_ (u"ࠪࡠࡡ࠵ࠧ嬴"),l1l111_l1_ (u"ࠫ࠴࠭嬵"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ嬶"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ嬷"),block+l1l111_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ嬸"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ嬹") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ嬺"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠪࡁࡂ࠭嬻") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ嬼"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ嬽")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1l11lll_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嬾"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠧ嬿"),l1111111_l1_,561,l1l111_l1_ (u"ࠨࠩ孀"),l1l111_l1_ (u"ࠩࠪ孁"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ孂"))
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ孃"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠬ孄"),l1lllll1_l1_,564,l1l111_l1_ (u"࠭ࠧ孅"),l1l111_l1_ (u"ࠧࠨ孆"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ孇"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ孈")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ孉")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ孊")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ孋")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"࠭࡟ࡠࡡࠪ孌")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ孍"),l1lllll_l1_+name+l1l111_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ孎"),l1lllll1_l1_,565,l1l111_l1_ (u"ࠩࠪ孏"),l1l111_l1_ (u"ࠪࠫ子"),l1l111l1_l1_+l1l111_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭孑"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"ࠬࡸࠧ孒") or value==l1l111_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ孓"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ孔") in option: continue
			if l1l111_l1_ (u"ࠨษ็็้࠭孕") in option: continue
			if l1l111_l1_ (u"ࠩࡱ࠱ࡦ࠭孖") in value: continue
			if option==l1l111_l1_ (u"ࠪࠫ字"): option = value
			l1l11l1ll_l1_ = option
			l1ll111llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡴࡡ࡮ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡳࡥ࠿ࠩ存"),option,re.DOTALL)
			if l1ll111llll_l1_: l1l11l1ll_l1_ = l1ll111llll_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"ࠬࡀࠠࠨ孙")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ孚")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠿ࠪ孛")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠩࠫ孜")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࡁࠬ孝")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧ孞")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ孟"):
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孠"),l1lllll_l1_+l1lllllll_l1_,url,565,l1l111_l1_ (u"࠭ࠧ孡"),l1l111_l1_ (u"ࠧࠨ孢"),l1l1l11l_l1_+l1l111_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ季"))
			elif type==l1l111_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭孤") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠪࡁࡂ࠭孥") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ学"))
				l1llllll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ孧")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1l11lll_l1_)
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭孨"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,561,l1l111_l1_ (u"ࠧࠨ孩"),l1l111_l1_ (u"ࠨࠩ孪"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ孫"))
			else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ孬"),l1lllll_l1_+l1lllllll_l1_,url,564,l1l111_l1_ (u"ࠫࠬ孭"),l1l111_l1_ (u"ࠬ࠭孮"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬ孯"),l1l111_l1_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭孰"),l1l111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ孱")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠩࡰࡴࡦࡧࠧ孲"),l1l111_l1_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ孳"),l1l111_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪ孴"),l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ孵"),l1l111_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧ孶"),l1l111_l1_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩ孷"),l1l111_l1_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨ學"),l1l111_l1_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ孹")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ孺") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ孻"),l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬࠭孼"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ孽"),l1l111_l1_ (u"ࠧ࠻࠼࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩ࠲ࠫ孾"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠨ࠿ࡀࠫ孿"),l1l111_l1_ (u"ࠩ࠲ࠫ宀"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠪࠪࠫ࠭宁"),l1l111_l1_ (u"ࠫ࠴࠭宂"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"ࠬࠬࠦࠨ它"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"࠭ࠧ宄")
	if l1l111_l1_ (u"ࠧ࠾࠿ࠪ宅") in filters:
		items = filters.split(l1l111_l1_ (u"ࠨࠨࠩࠫ宆"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠩࡀࡁࠬ宇"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠪ࠴ࠬ守")
		if l1l111_l1_ (u"ࠫࠪ࠭安") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ宊") and value!=l1l111_l1_ (u"࠭࠰ࠨ宋"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠡ࠭ࠣࠫ完")+value
		elif mode==l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ宍") and value!=l1l111_l1_ (u"ࠩ࠳ࠫ宎"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭宏")+key+l1l111_l1_ (u"ࠫࡂࡃࠧ宐")+value
		elif mode==l1l111_l1_ (u"ࠬࡧ࡬࡭ࠩ宑"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"࠭ࠦࠧࠩ宒")+key+l1l111_l1_ (u"ࠧ࠾࠿ࠪ宓")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ宔"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠩࠪࠬ宕"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ嚙")
l1lllll_l1_ = l1l111_l1_ (u"ࠨࡡࡖࡌࡓࡥࠧ嚚")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠩๅ๊ํอสࠡใูหห๐ษࠨ嚛"),l1l111_l1_ (u"ࠪๅฬืำไ๊ࠪ嚜"),l1l111_l1_ (u"ࠫࡘ࡮࡯ࡸࠢࡰࡳࡷ࡫ࠧ嚝")]
def l11l1ll_l1_(mode,url,text):
	if   mode==580: l1lll_l1_ = l1l1l11_l1_()
	elif mode==581: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==582: l1lll_l1_ = PLAY(url)
	elif mode==583: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==584: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==589: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嚞"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ嚟"),l1l111_l1_ (u"ࠧࠨ嚠"),l1l111_l1_ (u"ࠨࠩ嚡"),l1l111_l1_ (u"ࠩࠪ嚢"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ嚣"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚤"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ嚥"),l1l111_l1_ (u"࠭ࠧ嚦"),589,l1l111_l1_ (u"ࠧࠨ嚧"),l1l111_l1_ (u"ࠨࠩ嚨"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嚩"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ嚪"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ嚫"),l1l111_l1_ (u"ࠬ࠭嚬"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ嚭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ嚮"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ嚯"))
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ嚰"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嚱"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嚲")+l1lllll_l1_+title,l1ll1ll_l1_,584)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ嚳"),url,l1l111_l1_ (u"࠭ࠧ嚴"),l1l111_l1_ (u"ࠧࠨ嚵"),l1l111_l1_ (u"ࠨࠩ嚶"),l1l111_l1_ (u"ࠩࠪ嚷"),l1l111_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ嚸"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嚹"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭嚺"),l1l111_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ嚻"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ嚼"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠨࠩ嚽"),block)]
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ嚾"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ嚿"),l1l111_l1_ (u"ࠫࠬ囀"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ囁"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"࠭࠺ࠡࠩ囂")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ囃"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ囄"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ囅"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ囆"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ囇"),l1l111_l1_ (u"ࠬ࠭囈"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囉"),l1lllll_l1_+title,l1ll1ll_l1_,581)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠧࠨ囊")):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ囋"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭囌"),url,l1l111_l1_ (u"ࠪࠫ囍"),l1l111_l1_ (u"ࠫࠬ囎"),l1l111_l1_ (u"ࠬ࠭囏"),l1l111_l1_ (u"࠭ࠧ囐"),l1l111_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ囑"))
	html = response.content
	items = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囒"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࡏ࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࠨࡴࡪࡶ࡯ࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡈࡵ࡮ࠣࠩ囓"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡭ࡩࡃࠢࡱ࡯࠰࡫ࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ囔"),html,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱ࡷ࡫࡬ࡢࡶࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囕"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	if not items: items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡨ࡮࡯࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭囖"),block,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ囗"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ囘"),l1l111_l1_ (u"ࠨใํ่๊࠭囙"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ囚"),l1l111_l1_ (u"ࠪ็้๐ศࠨ四"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ囜"),l1l111_l1_ (u"ࠬํฯศใࠪ囝"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭回"),l1l111_l1_ (u"ฺࠧำูࠫ囟"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ因"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ囡"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪ团")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_).strip(l1l111_l1_ (u"ࠫ࠴࠭団"))
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ囤") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ囥")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ囦"))
		if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭囧") not in l1ll1l_l1_: l1ll1l_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ囨")+l1ll1l_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬ囩"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ囪"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ囫"),l1lllll_l1_+title,l1ll1ll_l1_,582,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"࠭วๅฯ็ๆฮ࠭囬") in title:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭园") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ囮"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ囯") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ困"),l1lllll_l1_+title,l1ll1ll_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囱"),l1lllll_l1_+title,l1ll1ll_l1_,583,l1ll1l_l1_)
	if request not in [l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧ囲"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ図")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ围"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭囵"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠩࠦࠫ囶"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ囷")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭囸"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ囹"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ固")+title,l1ll1ll_l1_,581)
		l111llll1_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡪࡲࡻࡲࡵࡲࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ囻"),html,re.DOTALL)
		if l111llll1_l1_:
			l1ll1ll_l1_ = l111llll1_l1_[0]
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ囼"),l1lllll_l1_+l1l111_l1_ (u"ุ่ࠩฬํฯสࠢสุ่๊๊ะࠩ国"),l1ll1ll_l1_,581)
	return
def l1ll1l11_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ图"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ囿"),url,l1l111_l1_ (u"ࠬ࠭圀"),l1l111_l1_ (u"࠭ࠧ圁"),l1l111_l1_ (u"ࠧࠨ圂"),l1l111_l1_ (u"ࠨࠩ圃"),l1l111_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ圄"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡼ࠭ࡴࡧࡤࡷࡴࡴࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ圅"),html,re.DOTALL)
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭圆"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠬࠩࠧ圇"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭圈"),l1lllll_l1_+title,url,583,l1l111_l1_ (u"ࠧࠨ圉"),l1l111_l1_ (u"ࠨࠩ圊"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠧ國")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ圌"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ圍"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ圎")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ圏"))
				addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭圐"),l1lllll_l1_+title,l1ll1ll_l1_,582)
		else:
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ圑"),block,re.DOTALL)
			for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
				if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ園") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ圓")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭圔"))
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ圕"),l1lllll_l1_+title,l1ll1ll_l1_,582)
	return
def PLAY(url):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ圖"))
	l1llll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ圗"),url,l1l111_l1_ (u"ࠨࠩ團"),l1l111_l1_ (u"ࠩࠪ圙"),l1l111_l1_ (u"ࠪࠫ圚"),l1l111_l1_ (u"ࠫࠬ圛"),l1l111_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ圜"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡑ࡮ࡤࡽࡪࡸࡨࡰ࡮ࡧࡩࡷࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ圝"),html,re.DOTALL)
	l1ll1ll_l1_ = l1ll1ll_l1_[0]
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ圞") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧ土")+l1ll1ll_l1_
	hash = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࡫ࡥࡸ࡮࠽ࠨ圠"))[1]
	parts = hash.split(l1l111_l1_ (u"ࠪࡣࡤ࠭圡"))
	l1l1lll1l1l1_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l1l111_l1_ (u"ࠫࡂ࠭圢"))
			if kodi_version>18.99: part = part.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ圣"))
			l1l1lll1l1l1_l1_.append(part)
		except: pass
	l1ll_l1_ = l1l111_l1_ (u"࠭࠾ࠨ圤").join(l1l1lll1l1l1_l1_)
	l1ll_l1_ = l1ll_l1_.splitlines()
	if l1l111_l1_ (u"ࠧࡧࡣࡵࡷࡴࡲࠧ圥") not in str(l1ll_l1_):
		for l1ll1ll_l1_ in l1ll_l1_:
			title,l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠨࠢࡀࡂࠥ࠭圦"))
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ圧")+title+l1l111_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ在")
			l1llll_l1_.append(l1ll1ll_l1_)
		import ll_l1_
		ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ圩"),url)
	else:
		title,l1ll1ll_l1_ = l1ll_l1_[0].split(l1l111_l1_ (u"ࠬࠦ࠽࠿ࠢࠪ圪"))
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧ圫"),l1l111_l1_ (u"ࠧࠨ圬"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ圭"),l1l111_l1_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠ฻์ิࠤ๊ะ่โำࠣห้ศๆࠨ圮")+l1l111_l1_ (u"ࠪࡠࡳ࠭圯")+l1l111_l1_ (u"ࠫ๏ืฬ๊ࠢส่๊ำว้ๆฬࠤ้ออใษࠪ地")+l1l111_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ圱")+title)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ圲"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ圳"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ圴"),l1l111_l1_ (u"ࠩ࠮ࠫ圵"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ圶")+search
	l1lll11_l1_(url)
	return
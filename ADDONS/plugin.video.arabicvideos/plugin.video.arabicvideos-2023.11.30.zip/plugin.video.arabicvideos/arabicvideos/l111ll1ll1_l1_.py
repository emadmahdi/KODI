# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪṇ")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡊࡍࡂࡠࠩṈ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨṉ"):l1l111_l1_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠪṊ")}
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==120: l1lll_l1_ = l1l1l11_l1_()
	elif mode==121: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==122: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==123: l1lll_l1_ = PLAY(url)
	elif mode==124: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬṋ")+text)
	elif mode==125: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Ṍ")+text)
	elif mode==129: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨṍ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩṎ"),l1l111_l1_ (u"ࠪࠫṏ"),129,l1l111_l1_ (u"ࠫࠬṐ"),l1l111_l1_ (u"ࠬ࠭ṑ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪṒ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬṓ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨṔ"),l1l111_l1_ (u"ࠩࠪṕ"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧṖ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬṗ"),headers,l1l111_l1_ (u"ࠬ࠭Ṙ"),l1l111_l1_ (u"࠭ࠧṙ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪṚ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡮࡯࡮ࡧࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࠣ࡭࠲࡬࡯࡭ࡦࡨࡶࠧ࠭ṛ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫṜ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1l111_l1_ (u"ࠪห้๋ีศำ฼อࠬṝ") in title: continue
			title = title.rsplit(l1l111_l1_ (u"ࠫࡃ࠭Ṟ"),1)[1]
			title = title.strip(l1l111_l1_ (u"ࠬࠦࠧṟ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨṠ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṡ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪṢ")+l1lllll_l1_+title,l1ll1ll_l1_,122)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧṣ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪṤ"),l1l111_l1_ (u"ࠫࠬṥ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡥ࡮ࡴࡌࡰࡣࡧࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡹࡩࡷࡺࡩࡤࡣ࡯ࡈࡾࡴࡡ࡮࡫ࡦࠦࠬṦ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡰࡥࡣࠣࡦࡩࡨࠢ࠿࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪṧ"),html,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩṨ"))
			l1ll1ll_l1_ = l1ll1ll_l1_.rstrip(l1l111_l1_ (u"ࠨ࠱ࠪṩ"))
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if l1l111_l1_ (u"ࠩส่๊฻วา฻ฬࠫṪ") in title: continue
			if l1l111_l1_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬṫ") in l1ll1ll_l1_: continue
			if not title and l1l111_l1_ (u"ࠫ࠴ࡺࡶ࠰ࡣࡵࡥࡧ࡯ࡣࠨṬ") in l1ll1ll_l1_: title = l1l111_l1_ (u"๋ࠬำๅี็หฯูࠦาสํอࠬṭ")
			addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ṯ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩṯ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ṱ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩṱ"),l1l111_l1_ (u"ࠪࠫṲ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠨ࠯ࠬࡂ࠭ࡃࡋࡧࡺࡄࡨࡷࡹࡂ࠯ࡢࡀࠪṳ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧṴ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"࠭ࠠࠨṵ"))
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧṶ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪṷ")+l1lllll_l1_+title,l1ll1ll_l1_,121)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭Ṹ"),url,l1l111_l1_ (u"ࠪࠫṹ"),headers,l1l111_l1_ (u"ࠫࠬṺ"),l1l111_l1_ (u"ࠬ࠭ṻ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬṼ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡵࡢࡷࡨࡸ࡯࡭࡮ࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨṽ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩṾ"),block,re.DOTALL)
	if l1l111_l1_ (u"ࠩࡷࡶࡪࡴࡤࡪࡰࡪࠫṿ") not in url:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẀ"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧẁ"),url,125)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẂ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩẃ"),url,124)
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬẄ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨẅ"),l1l111_l1_ (u"ࠩࠪẆ"),9999)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪẇ"),l1lllll_l1_+title,l1ll1ll_l1_,121)
	return
def l1lll11_l1_(url,l1llllll1_l1_=l1l111_l1_ (u"ࠫ࠶࠭Ẉ")):
	if not l1llllll1_l1_: l1llllll1_l1_ = l1l111_l1_ (u"ࠬ࠷ࠧẉ")
	if l1l111_l1_ (u"࠭࠯ࡦࡺࡳࡰࡴࡸࡥ࠰ࠩẊ") in url or l1l111_l1_ (u"ࠧࡀࠩẋ") in url: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠨࠨࠪẌ")
	else: l1lllll1_l1_ = url + l1l111_l1_ (u"ࠩࡂࠫẍ")
	l1lllll1_l1_ = l1lllll1_l1_ + l1l111_l1_ (u"ࠪࡳࡺࡺࡰࡶࡶࡢࡪࡴࡸ࡭ࡢࡶࡀ࡮ࡸࡵ࡮ࠧࡱࡸࡸࡵࡻࡴࡠ࡯ࡲࡨࡪࡃ࡭ࡰࡸ࡬ࡩࡸࡥ࡬ࡪࡵࡷࠪࡵࡧࡧࡦ࠿ࠪẎ")+l1llllll1_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨẏ"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭Ẑ"),headers,l1l111_l1_ (u"࠭ࠧẑ"),l1l111_l1_ (u"ࠧࠨẒ"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ẓ"))
	html = response.content
	name,items = l1l111_l1_ (u"ࠩࠪẔ"),[]
	if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬẕ") in url:
		name = re.findall(l1l111_l1_ (u"ࠫࡁ࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࠨẖ"),html,re.DOTALL)
		if name: name = escapeUNICODE(name[0]).strip(l1l111_l1_ (u"ࠬࠦࠧẗ")) + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪẘ")
		else: name = xbmc.getInfoLabel( l1l111_l1_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠣẙ") ) + l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬẚ")
	if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࠪẛ") not in url: items = re.findall(l1l111_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡡࡢ࡜࡝ࠤࠫࡠࡡࡢ࡜࡝࠱ࡶࡩࡦࡹ࡯࡯࠰࠭ࡃ࠮ࡢ࡜࡝࡞ࠥ࠲࠯ࡅࡳࡳࡥࡀࡠࡡࡢ࡜ࠣࠪ࠱࠮ࡄ࠯࡜࡝࡞࡟ࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫࡜࡝࡞࡟ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬẜ"),html,re.DOTALL)
	if not items: items = re.findall(l1l111_l1_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡢ࡜࡝࡞ࠥࠬ࠳࠰࠿ࠪ࡞࡟ࡠࡡࠨ࠮ࠫࡁࡶࡶࡨࡃ࡜࡝࡞࡟ࠦ࠭࠴ࠪࡀࠫ࡟ࡠࡡࡢࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࡞࡟ࡠࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧẝ"),html,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		if l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧẞ") in url and l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࡜࠰ࠩẟ") not in l1ll1ll_l1_: continue
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩẠ") in url and l1l111_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࡟࠳ࠬạ") not in l1ll1ll_l1_: continue
		title = name+escapeUNICODE(title).strip(l1l111_l1_ (u"ࠩࠣࠫẢ"))
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠪࡠ࠴࠭ả"),l1l111_l1_ (u"ࠫ࠴࠭Ấ"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l1l111_l1_ (u"ࠬࡢ࠯ࠨấ"),l1l111_l1_ (u"࠭࠯ࠨẦ"))
		if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬầ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧẨ")+l1ll1l_l1_
		l1lllll1_l1_ = l111l1_l1_+l1ll1ll_l1_
		if l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱ࠪẩ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭Ẫ") in l1lllll1_l1_ or l1l111_l1_ (u"ࠫ࠴ࡳࡡࡴࡴࡤ࡬࡮ࡿࡡࡵ࠱ࠪẫ") in url:
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫẬ"),l1lllll_l1_+title,l1lllll1_l1_.rstrip(l1l111_l1_ (u"࠭࠯ࠨậ")),123,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧẮ"),l1lllll_l1_+title,l1lllll1_l1_,121,l1ll1l_l1_)
	if len(items)>=12:
		l111llllll_l1_ = [l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪắ"),l1l111_l1_ (u"ࠩ࠲ࡸࡻ࠵ࠧẰ"),l1l111_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴࠭ằ"),l1l111_l1_ (u"ࠫ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠯ࠨẲ"),l1l111_l1_ (u"ࠬ࠵࡭ࡢࡵࡵࡥ࡭࡯ࡹࡢࡶ࠲ࠫẳ")]
		l1llllll1_l1_ = int(l1llllll1_l1_)
		if any(value in url for value in l111llllll_l1_):
			for n in range(0,1100,100):
				if int(l1llllll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l1llllll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l1llllll1_l1_==j and j!=0:
									addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ẵ"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥ࠭ẵ")+str(j),url,121,l1l111_l1_ (u"ࠨࠩẶ"),str(j))
						elif i!=0: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩặ"),l1lllll_l1_+l1l111_l1_ (u"ูࠪๆำษࠡࠩẸ")+str(i),url,121,l1l111_l1_ (u"ࠫࠬẹ"),str(i))
						else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬẺ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬẻ")+str(1),url,121,l1l111_l1_ (u"ࠧࠨẼ"),str(1))
				elif n!=0: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨẽ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨẾ")+str(n),url,121,l1l111_l1_ (u"ࠪࠫế"),str(n))
				else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫỀ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫề")+str(1),url,121)
	return
def PLAY(url):
	headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪỂ"):l1l111_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠬể")}
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬỄ"),url,l1l111_l1_ (u"ࠩࠪễ"),headers,l1l111_l1_ (u"ࠪࠫỆ"),l1l111_l1_ (u"ࠫࠬệ"),l1l111_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨỈ"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁห้ะี็์ไࡀ࠴ࡺࡤ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ỉ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l111ll1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡱࡪ࠾ࡺࡸ࡬ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫỊ"),html,re.DOTALL)
	if l111ll1lll_l1_: server = l1l111l_l1_(l111ll1lll_l1_[0],l1l111_l1_ (u"ࠨࡷࡵࡰࠬị"))
	else: server = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭Ọ"))
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	l111llll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡥࡺࡺ࡯࠮ࡵ࡬ࡾࡪࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬọ"),html,re.DOTALL)
	if l111llll11_l1_:
		l111llll11_l1_ = server+l111llll11_l1_[0]
		response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨỎ"),l111llll11_l1_,l1l111_l1_ (u"ࠬ࠭ỏ"),headers,l1l111_l1_ (u"࠭ࠧỐ"),l1l111_l1_ (u"ࠧࠨố"),l1l111_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫỒ"))
		l11l1ll1_l1_ = response.content
		if l1l111_l1_ (u"ࠩࡧࡳࡸࡺࡲࡦࡣࡰࠫồ") not in l11l1ll1_l1_:
			l111l1lll1_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡸࡩࡲࡪࡲࡷ࠲࠯ࡅ࠾ࡧࡷࡱࡧࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩỔ"),l11l1ll1_l1_,re.DOTALL)
			l111l1lll1_l1_ = l111l1lll1_l1_[0]
			result = l111lll111_l1_(l111l1lll1_l1_)
			try: l111ll1l1l_l1_,l111l1ll11_l1_,l11l11lll1_l1_ = result
			except:
				l1111l1_l1_(l1l111_l1_ (u"ࠫࠬổ"),l1l111_l1_ (u"ࠬ࠭Ỗ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩỗ"),l1l111_l1_ (u"ࠧๅๆฦืๆࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏าฯࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡ࠰ࠣๆิ๊ࠦไ๊้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ็อๅࠡสอัิ๐หࠡืไัฬะ็๊ࠡส่อืๆศ็ฯࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣๆึอมสࠢสฺ่็อศฬࠣห้าฯ๋ัฬࠫỘ"))
				return
			l111l1ll11_l1_ = server+l111l1ll11_l1_
			l111ll1l1l_l1_ = server+l111ll1l1l_l1_
			cookies = response.cookies
			if l1l111_l1_ (u"ࠨࡒࡖࡗࡎࡊࠧộ") in cookies.keys():
				l111l1l1ll_l1_ = cookies[l1l111_l1_ (u"ࠩࡓࡗࡘࡏࡄࠨỚ")]
				headers[l1l111_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪớ")] = l1l111_l1_ (u"ࠫࡕ࡙ࡓࡊࡆࡀࠫỜ")+l111l1l1ll_l1_
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩờ"),l111ll1l1l_l1_,l1l111_l1_ (u"࠭ࠧỞ"),headers,l1l111_l1_ (u"ࠧࠨở"),l1l111_l1_ (u"ࠨࠩỠ"),l1l111_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬỡ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨỢ"),l111l1ll11_l1_,l11l11lll1_l1_,headers,l1l111_l1_ (u"ࠫࠬợ"),l1l111_l1_ (u"ࠬ࠭Ụ"),l1l111_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩụ"))
				response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫỦ"),l111llll11_l1_,l1l111_l1_ (u"ࠨࠩủ"),headers,l1l111_l1_ (u"ࠩࠪỨ"),l1l111_l1_ (u"ࠪࠫứ"),l1l111_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧỪ"))
				l11l1ll1_l1_ = response.content
		l11lll11l1_l1_ = re.findall(l1l111_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪừ"),l11l1ll1_l1_,re.DOTALL)
		if l11lll11l1_l1_:
			l11lll11l1_l1_ = server+l11lll11l1_l1_[0]
			l1l1lll1_l1_,l1llll_l1_ = l1l11l1lll_l1_(l11lll11l1_l1_,headers)
			zz = zip(l1l1lll1_l1_,l1llll_l1_)
			l1l1lll1_l1_,l1llll_l1_ = [],[]
			for title,l1ll1ll_l1_ in zz:
				l111l1ll_l1_ = title.split(l1l111_l1_ (u"࠭ࠠࠡࠩỬ"))[1]
				l1llll_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡷ࡫ࡧࡷࡹࡸࡥࡢ࡯ࡢࡣࡼࡧࡴࡤࡪࡢࡣࡲ࠹ࡵ࠹ࡡࡢࠫử")+l111l1ll_l1_)
				l11l11ll1l_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠱ࡶࡸࡷ࡫ࡡ࡮࠱ࠪỮ"),l1l111_l1_ (u"ࠩ࠲ࡨࡱ࠵ࠧữ")).replace(l1l111_l1_ (u"ࠪ࠳ࡸࡺࡲࡦࡣࡰ࠲ࡲ࠹ࡵ࠹ࠩỰ"),l1l111_l1_ (u"ࠫࠬự"))
				l1llll_l1_.append(l11l11ll1l_l1_+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡼࡩࡥࡵࡷࡶࡪࡧ࡭ࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡤࡳࡰ࠵ࡡࡢࠫỲ")+l111l1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬỳ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨỴ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩỵ"): return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠩࠣࠫỶ"),l1l111_l1_ (u"ࠪ࠯ࠬỷ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࡲ࠿ࠪỸ") + l1lll1ll_l1_
	l1lll11_l1_(url)
	return
l1l11111_l1_ = [l1l111_l1_ (u"ࠬอไ็๊฼ࠫỹ"),l1l111_l1_ (u"࠭วๅี้อࠬỺ"),l1l111_l1_ (u"ࠧศๆห่ิ࠭ỻ")]
l1l11lll_l1_ = [l1l111_l1_ (u"ࠨษ็ื๋ฯࠧỼ"),l1l111_l1_ (u"ࠩส่้เษࠨỽ"),l1l111_l1_ (u"ࠪห้ฮไะࠩỾ"),l1l111_l1_ (u"ࠫฬ๊ฯใหࠪỿ"),l1l111_l1_ (u"ࠬอไอ๊าอࠬἀ"),l1l111_l1_ (u"࠭วๅฬิะ๊ฯࠧἁ"),l1l111_l1_ (u"ࠧศๆ้์฾࠭ἂ"),l1l111_l1_ (u"ࠨษ็ฮฺ์๊โࠩἃ")]
l11lll_l1_ = []
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ἄ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧἅ"),url,l1l111_l1_ (u"ࠫࠬἆ"),headers,l1l111_l1_ (u"ࠬ࠭ἇ"),l1l111_l1_ (u"࠭ࠧἈ"),l1l111_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠮ࡉࡈࡘࡤࡌࡉࡍࡖࡈࡖࡘࡥࡂࡍࡑࡆࡏࡘ࠳࠱ࡴࡶࠪἉ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡵࡳࡵࡪ࡯ࡸࡰࠥࠬ࠳࠰࠿ࠪ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷࠧ࠭Ἂ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	zz = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡹࡷࡸࡥ࡯ࡶࡢࡳࡵࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫἋ"),block,re.DOTALL)
	l11l1111l1_l1_,l11l111lll_l1_ = zip(*zz)
	l1l11l1l_l1_ = zip(l11l1111l1_l1_,l11l111lll_l1_,l11l1111l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩἌ"),block,re.DOTALL)
	l111l1l1l1_l1_ = []
	for l1ll1ll_l1_,name in items:
		name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭Ἅ"))
		value = l1ll1ll_l1_.rsplit(l1l111_l1_ (u"ࠬ࠵ࠧἎ"),1)[1]
		if name in l11lll_l1_: continue
		if l1l111_l1_ (u"࠭ไๅๅหหึ࠭Ἇ") in name: continue
		if l1l111_l1_ (u"ࠧࡕࡘ࠰ࡑࡆ࠭ἐ") in name: continue
		if l1l111_l1_ (u"ࠨࡖ࡙࠱࠶࠺ࠧἑ") in name: continue
		l111l1l1l1_l1_.append((value,name))
	return l111l1l1l1_l1_
def l111llll1l_l1_(l1l1ll11_l1_,url):
	url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ἒ"),1)[0]
	url = url.strip(l1l111_l1_ (u"ࠪ࠳ࠬἓ"))
	l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ἔ"))
	l11ll111_l1_ = l11ll111_l1_.replace(l1l111_l1_ (u"ࠬࠦࠫࠡࠩἕ"),l1l111_l1_ (u"࠭࠭ࠨ἖"))
	url = url+l1l111_l1_ (u"ࠧ࠰ࠩ἗")+l11ll111_l1_
	return url
def l1l1ll1l_l1_(url,filter):
	if l1l111_l1_ (u"ࠨࡁࠪἘ") in url: url = url.split(l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ἑ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧἚ"),1)
	if filter==l1l111_l1_ (u"ࠫࠬἛ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠬ࠭Ἔ"),l1l111_l1_ (u"࠭ࠧἝ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠧࡠࡡࡢࠫ἞"))
	if type==l1l111_l1_ (u"ࠨࡕࡓࡉࡈࡏࡆࡊࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ἟"):
		if l1l11111_l1_[0]+l1l111_l1_ (u"ࠩࡀࠫἠ") not in l11lll1l_l1_: category = l1l11111_l1_[0]
		for i in range(len(l1l11111_l1_[0:-1])):
			if l1l11111_l1_[i]+l1l111_l1_ (u"ࠪࡁࠬἡ") in l11lll1l_l1_: category = l1l11111_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ἢ")+category+l1l111_l1_ (u"ࠬࡃ࠰ࠨἣ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨἤ")+category+l1l111_l1_ (u"ࠧ࠾࠲ࠪἥ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠨࠨࠪἦ"))+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭ἧ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠪࠪࠬἨ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧἩ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩἪ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"࠭ࡁࡍࡎࡢࡍ࡙ࡋࡍࡔࡡࡉࡍࡑ࡚ࡅࡓࠩἫ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩἬ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫἭ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭Ἦ")+l11lll11_l1_
		l1llllll_l1_ = l111llll1l_l1_(l11lll11_l1_,l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪἯ"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧἰ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬἱ"),l1lllll_l1_+l1l111_l1_ (u"࠭ࠠ࡜࡝ࠣࠤࠥ࠭ἲ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࡡࡢ࠭ἳ"),l1llllll_l1_,121)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ἴ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩἵ"),l1l111_l1_ (u"ࠪࠫἶ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,block,l1l111ll_l1_ in l1l11l1l_l1_:
		l1l111ll_l1_ = l1l111ll_l1_.strip(l1l111_l1_ (u"ࠫࠥ࠭ἷ"))
		name = name.strip(l1l111_l1_ (u"ࠬࠦࠧἸ"))
		name = name.replace(l1l111_l1_ (u"࠭࠭࠮ࠩἹ"),l1l111_l1_ (u"ࠧࠨἺ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"ࠨ࠿ࠪἻ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬἼ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l1l11111_l1_[-1]:
					l1llllll_l1_ = l111llll1l_l1_(l11lll11_l1_,url)
					l1lll11_l1_(l1llllll_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠪࡗࡕࡋࡃࡊࡈࡌࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩἽ")+l1l111l1_l1_)
				return
			else:
				l1llllll_l1_ = l111llll1l_l1_(l11lll11_l1_,l1lllll1_l1_)
				if l1l111ll_l1_==l1l11111_l1_[-1]: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫἾ"),l1lllll_l1_+l1l111_l1_ (u"ࠬอไอ็ํ฽ࠥ࠭Ἷ"),l1llllll_l1_,121)
				else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ὀ"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨὁ"),l1lllll1_l1_,125,l1l111_l1_ (u"ࠨࠩὂ"),l1l111_l1_ (u"ࠩࠪὃ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭ὄ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠫࠫ࠭ὅ")+l1l111ll_l1_+l1l111_l1_ (u"ࠬࡃ࠰ࠨ὆")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"࠭ࠦࠨ὇")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾࠲ࠪὈ")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠨࡡࡢࡣࠬὉ")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩὊ"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬὋ")+name,l1lllll1_l1_,124,l1l111_l1_ (u"ࠫࠬὌ"),l1l111_l1_ (u"ࠬ࠭Ὅ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"࠭ࠦࠨ὎")+l1l111ll_l1_+l1l111_l1_ (u"ࠧ࠾ࠩ὏")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠨࠨࠪὐ")+l1l111ll_l1_+l1l111_l1_ (u"ࠩࡀࠫὑ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠪࡣࡤࡥࠧὒ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠫࠥࡀࠧὓ")+name
			if type==l1l111_l1_ (u"ࠬࡇࡌࡍࡡࡌࡘࡊࡓࡓࡠࡈࡌࡐ࡙ࡋࡒࠨὔ"): addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ὕ"),l1lllll_l1_+title,url,124,l1l111_l1_ (u"ࠧࠨὖ"),l1l111_l1_ (u"ࠨࠩὗ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ὘") and l1l11111_l1_[-2]+l1l111_l1_ (u"ࠪࡁࠬὙ") in l11lll1l_l1_:
				l1llllll_l1_ = l111llll1l_l1_(l1l1ll11_l1_,url)
				addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ὚"),l1lllll_l1_+title,l1llllll_l1_,121)
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬὛ"),l1lllll_l1_+title,url,125,l1l111_l1_ (u"࠭ࠧ὜"),l1l111_l1_ (u"ࠧࠨὝ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫ὞"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭Ὗ"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬὠ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭ὡ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧὢ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨὣ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨὤ")
	for key in l1l11lll_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪὥ")
		if l1l111_l1_ (u"ࠩࠨࠫὦ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬὧ") and value!=l1l111_l1_ (u"ࠫ࠵࠭Ὠ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩὩ")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩὪ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩὫ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪὬ")+key+l1l111_l1_ (u"ࠩࡀࠫὭ")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨὮ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭Ὧ")+key+l1l111_l1_ (u"ࠬࡃࠧὰ")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪά"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩὲ"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫέ"),l1l111_l1_ (u"ࠩࡀࠫὴ"))
	return l1l1l111_l1_
def l11l11l1l1_l1_(l111l1ll1l_l1_):
	m = re.search(l1l111_l1_ (u"ࡵࠫࡣ࠮࡜ࡥ࠭ࠬ࡟࠳࠲࡝ࡀ࡞ࡧ࠮ࡄ࠭ή"), str(l111l1ll1l_l1_))
	return int(m.groups()[-1]) if m and not callable(l111l1ll1l_l1_) else 0
def l111ll11ll_l1_(l11l11l111_l1_):
	try:
		l11l111l11_l1_ = base64.b64decode(l11l11l111_l1_)
	except:
		try:
			l11l111l11_l1_ = base64.b64decode(l11l11l111_l1_+l1l111_l1_ (u"ࠫࡂ࠭ὶ"))
		except:
			try:
				l11l111l11_l1_ = base64.b64decode(l11l11l111_l1_+l1l111_l1_ (u"ࠬࡃ࠽ࠨί"))
			except:
				l11l111l11_l1_ = l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡧࡧࡳࡦ࠸࠷ࠤࡩ࡫ࡣࡰࡦࡨࠤࡪࡸࡲࡰࡴࠪὸ")
	if kodi_version>18.99: l11l111l11_l1_ = l11l111l11_l1_.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬό"))
	return l11l111l11_l1_
def l111ll111l_l1_(l11l1111ll_l1_,l11l111111_l1_,a):
	a = a - l11l111111_l1_
	if a<0:
		c = l1l111_l1_ (u"ࠨࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠫὺ")
	else:
		c = l11l1111ll_l1_[a]
	return c
def x(l11l1111ll_l1_,l11l111111_l1_,a):
	return(l111ll111l_l1_(l11l1111ll_l1_,l11l111111_l1_,a))
def l11l111l1l_l1_(l11l11l1ll_l1_,step,l11l111111_l1_,l111lll11l_l1_):
	l111lll11l_l1_ = l111lll11l_l1_.replace(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࠧύ"),l1l111_l1_ (u"ࠪ࡫ࡱࡵࡢࡢ࡮ࠣࡨࡀࠦࠧὼ"))
	l111lll11l_l1_ = l111lll11l_l1_.replace(l1l111_l1_ (u"ࠫࡽ࠮ࠧώ"),l1l111_l1_ (u"ࠬࡾࠨࡵࡣࡥ࠰ࡸࡺࡥࡱ࠴࠯ࠫ὾"))
	l111lll11l_l1_ = l111lll11l_l1_.replace(l1l111_l1_ (u"࠭ࡧ࡭ࡱࡥࡥࡱࠦࡤ࠼ࠢࡧࡁࠬ὿"),l1l111_l1_ (u"ࠧࠨᾀ"))
	d = eval(l111lll11l_l1_,{l1l111_l1_ (u"ࠨࡲࡤࡶࡸ࡫ࡉ࡯ࡶࠪᾁ"):l11l11l1l1_l1_,l1l111_l1_ (u"ࠩࡻࠫᾂ"):x,l1l111_l1_ (u"ࠪࡸࡦࡨࠧᾃ"):l11l11l1ll_l1_,l1l111_l1_ (u"ࠫࡸࡺࡥࡱ࠴ࠪᾄ"):l11l111111_l1_})
	l11l1l1111_l1_=0
	while True:
		l11l1l1111_l1_=l11l1l1111_l1_+1
		l11l11l1ll_l1_.append(l11l11l1ll_l1_[0])
		del l11l11l1ll_l1_[0]
		d = eval(l111lll11l_l1_,{l1l111_l1_ (u"ࠬࡶࡡࡳࡵࡨࡍࡳࡺࠧᾅ"):l11l11l1l1_l1_,l1l111_l1_ (u"࠭ࡸࠨᾆ"):x,l1l111_l1_ (u"ࠧࡵࡣࡥࠫᾇ"):l11l11l1ll_l1_,l1l111_l1_ (u"ࠨࡵࡷࡩࡵ࠸ࠧᾈ"):l11l111111_l1_})
		if ((d == step) or (l11l1l1111_l1_>10000)): break
	return
def l111lll111_l1_(l111l1lll1_l1_):
	tmp = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷ࠴ࠪࡀ࠿ࠫ࠲ࢀ࠸ࠬ࠵ࡿࠬࡠ࠭ࡢࠩࠨᾉ"), l111l1lll1_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠪࡉࡗࡘ࠺ࡗࡣࡵࡧࡴࡴࡳࡵࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾊ")
	l111l1llll_l1_ = tmp[0].strip()
	_print(l1l111_l1_ (u"࡛ࠫࡧࡲࡤࡱࡱࡷࡹࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨᾋ") % l111l1llll_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࢃ࡜ࠩࠩᾌ")+l111l1llll_l1_+l1l111_l1_ (u"࠭࠿࠭ࠪ࠳ࡼࡠ࠶࠭࠺ࡣ࠰ࡪࡢࢁ࠱࠭࠳࠳ࢁ࠮ࡢࠩ࡝ࠫ࠾ࠫᾍ"), l111l1lll1_l1_)
	if not tmp: return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾࡙ࠥࡴࡦࡲ࠴ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧᾎ")
	step = eval(tmp[0])
	_print(l1l111_l1_ (u"ࠨࡕࡷࡩࡵ࠷ࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢ࠳ࡼࠪࡹࠧᾏ") % l1l111_l1_ (u"ࠩࡾ࠾࠵࠸ࡘࡾࠩᾐ").format(step).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠪࡨࡂࡪ࠭ࠩ࠲ࡻ࡟࠵࠳࠹ࡢ࠯ࡩࡡࢀ࠷ࠬ࠲࠲ࢀ࠭ࡀ࠭ᾑ"), l111l1lll1_l1_)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡕࡷࡩࡵ࠸ࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪᾒ")
	l11l111111_l1_ = eval(tmp[0])
	_print(l1l111_l1_ (u"࡙ࠬࡴࡦࡲ࠵ࠤࠥࠦࠠࠡࠢࠣࠤࡂࠦ࠰ࡹࠧࡶࠫᾓ") % l1l111_l1_ (u"࠭ࡻ࠻࠲࠵࡜ࢂ࠭ᾔ").format(l11l111111_l1_).lower())
	tmp = re.findall(l1l111_l1_ (u"ࠢࡵࡴࡼࡿ࠭ࡼࡡࡳ࠰࠭ࡃ࠮ࡁࠢᾕ"), l111l1lll1_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿ࡪࡥࡤࡣ࡯ࡣ࡫ࡴࡣࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾖ")
	l111lll11l_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠩࡇࡩࡨࡧ࡬ࠡࡨࡸࡲࡨࠦࠠࠡ࠿ࠣࠦࠥࠫࡳ࠯࠰࠱ࠦࠬᾗ") % l111lll11l_l1_[0:135])
	tmp = re.findall(l1l111_l1_ (u"ࠥࠫࡩࡧࡴࡢࠩ࠽ࡿࠬ࠮࡟࡜࠲࠰࠽ࡦ࠳ࡺࡂ࠯࡝ࡡࢀ࠷࠰࠭࠴࠳ࢁ࠮࠭࠺ࠨࡱ࡮ࠫࠧᾘ"), l111l1lll1_l1_)
	if not tmp: return l1l111_l1_ (u"ࠫࡊࡘࡒ࠻ࡒࡲࡷࡹࡑࡥࡺࠢࡑࡳࡹࠦࡆࡰࡷࡱࡨࠬᾙ")
	l11l11l11l_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠬࡖ࡯ࡴࡶࡎࡩࡾࠦࠠࠡࠢࠣࠤࡂࠦࠥࡴࠩᾚ") % l11l11l11l_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࠤᾛ")+l111l1llll_l1_+l1l111_l1_ (u"ࠢ࠯ࠬࡂࡺࡦࡸ࠮ࠫࡁࡀࠬࡡࡡ࠮ࠫࡁࡠ࠭ࠧᾜ"), l111l1lll1_l1_)
	if not tmp: return l1l111_l1_ (u"ࠨࡇࡕࡖ࠿࡚ࡡࡣࡎ࡬ࡷࡹࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩᾝ")
	l111lllll1_l1_ = tmp[0]
	l111lllll1_l1_ = l111l1llll_l1_ + l1l111_l1_ (u"ࠤࡀࠦᾞ") + l111lllll1_l1_
	exec(l111lllll1_l1_) in globals(), locals()
	l11l1111ll_l1_ = locals()[l111l1llll_l1_]
	_print(l111l1llll_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧ࠱࠽࠵ࡹ࠮࠯࠰ࠪᾟ")%str(l11l1111ll_l1_))
	l11l111l1l_l1_(l11l1111ll_l1_,step,l11l111111_l1_,l111lll11l_l1_)
	_print(l111l1llll_l1_+l1l111_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠾ࠢࠨ࠲࠾࠶ࡳ࠯࠰࠱ࠫᾠ")%str(l11l1111ll_l1_))
	tmp = re.findall(l1l111_l1_ (u"ࠧࡢࠨ࡝ࠫ࠾ࠬࡻࡧࡲࠡ࠰࠭ࡃ࠮ࡢࠤ࡝ࠪࠪࡠ࠯࠭࡜ࠪࠤᾡ"), l111l1lll1_l1_, re.S)
	if not tmp:
		tmp = re.findall(l1l111_l1_ (u"ࠨࡡ࠱ࡣ࡟ࠬࡡ࠯࠻ࠩ࠰࠭ࡃ࠮ࡢࠤ࡝ࠪࠪࡠ࠯࠭࡜ࠪࠤᾢ"), l111l1lll1_l1_, re.S)
		if not tmp:
			return l1l111_l1_ (u"ࠧࡆࡔࡕ࠾ࡑ࡯ࡳࡵࡡ࡙ࡥࡷࠦࡎࡰࡶࠣࡊࡴࡻ࡮ࡥࠩᾣ")
	l11l11llll_l1_ = tmp[0]
	l11l11llll_l1_ = re.sub(l1l111_l1_ (u"ࠣࠪࡩࡹࡳࡩࡴࡪࡱࡱࠤ࠳࠰࠿ࡾ࠰࠭ࡃࢂ࠯ࠢᾤ"), l1l111_l1_ (u"ࠤࠥᾥ"), l11l11llll_l1_)
	_print(l1l111_l1_ (u"ࠪࡐ࡮ࡹࡴࡠࡘࡤࡶࠥࠦࠠࠡࠢࡀࠤࠪ࠴࠹࠱ࡵ࠱࠲࠳࠭ᾦ") % l11l11llll_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠦ࠭ࡥ࡛ࡢ࠯ࡽࡅ࠲ࢀ࠰࠮࠻ࡠࡿ࠹࠲࠸ࡾࠫࡀࡠࡠࡢ࡝ࠣᾧ") , l11l11llll_l1_)
	if not tmp: return l1l111_l1_ (u"ࠬࡋࡒࡓ࠼࠶࡚ࡦࡸࡳࠡࡐࡲࡸࠥࡌ࡯ࡶࡰࡧࠫᾨ")
	_11l11111l_l1_ = tmp
	_print(l1l111_l1_ (u"࠭࠳ࡗࡣࡵࡷࠥࠦࠠࠡࠢࠣࠤࠥࡃࠠࠦࡵࠪᾩ")%str(_11l11111l_l1_))
	l111lll1ll_l1_ = _11l11111l_l1_[1]
	_print(l1l111_l1_ (u"ࠧࡣ࡫ࡪࡣࡸࡺࡲࡠࡸࡤࡶࠥࠦ࠽ࠡࠧࡶࠫᾪ")%l111lll1ll_l1_)
	l11l11llll_l1_ = l11l11llll_l1_.replace(l1l111_l1_ (u"ࠨ࠮ࠪᾫ"),l1l111_l1_ (u"ࠩ࠾ࠫᾬ")).split(l1l111_l1_ (u"ࠪ࠿ࠬᾭ"))
	for l11l11l111_l1_ in l11l11llll_l1_:
		l11l11l111_l1_ = l11l11l111_l1_.strip()
		if l1l111_l1_ (u"ࠫ࡮ࡹ࡭ࡰࡤࠪᾮ") in l11l11l111_l1_: l11l11l111_l1_=l1l111_l1_ (u"ࠬ࠭ᾯ")
		if l1l111_l1_ (u"࠭࠽࡜࡟ࠪᾰ")   in l11l11l111_l1_: l11l11l111_l1_ = l11l11l111_l1_.replace(l1l111_l1_ (u"ࠧ࠾࡝ࡠࠫᾱ"),l1l111_l1_ (u"ࠨ࠿ࡾࢁࠬᾲ"))
		l11l11l111_l1_ = re.sub(l1l111_l1_ (u"ࠤࠫࡥ࠵࠴࡜ࠩࠫࠥᾳ"), l1l111_l1_ (u"ࠥࡥ࠵ࡪࠨ࡮ࡣ࡬ࡲࡤࡺࡡࡣ࠮ࡶࡸࡪࡶ࠲࠭ࠤᾴ"), l11l11l111_l1_)
		if l11l11l111_l1_!=l1l111_l1_ (u"ࠫࠬ᾵"):
			l11l11l111_l1_ = l11l11l111_l1_.replace(l1l111_l1_ (u"ࠬࠧࠡ࡜࡟ࠪᾶ"),l1l111_l1_ (u"࠭ࡔࡳࡷࡨࠫᾷ"));
			l11l11l111_l1_ = l11l11l111_l1_.replace(l1l111_l1_ (u"ࠧࠢ࡝ࡠࠫᾸ"),l1l111_l1_ (u"ࠨࡈࡤࡰࡸ࡫ࠧᾹ"));
			l11l11l111_l1_ = l11l11l111_l1_.replace(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࠧᾺ"),l1l111_l1_ (u"ࠪࠫΆ"));
			try:
				exec(l11l11l111_l1_,{l1l111_l1_ (u"ࠫࡵࡧࡲࡴࡧࡌࡲࡹ࠭ᾼ"):l11l11l1l1_l1_,l1l111_l1_ (u"ࠬࡧࡴࡰࡤࠪ᾽"):l111ll11ll_l1_,l1l111_l1_ (u"࠭ࡡ࠱ࡦࠪι"):l111ll111l_l1_,l1l111_l1_ (u"ࠧࡹࠩ᾿"):x,l1l111_l1_ (u"ࠨ࡯ࡤ࡭ࡳࡥࡴࡢࡤࠪ῀"):l11l1111ll_l1_,l1l111_l1_ (u"ࠩࡶࡸࡪࡶ࠲ࠨ῁"):l11l111111_l1_},locals())
			except:
				pass
	l11l11ll11_l1_ = l1l111_l1_ (u"ࠪࠫῂ")
	for i in range(0,len(locals()[_11l11111l_l1_[2]])):
		if locals()[_11l11111l_l1_[2]][i] in locals()[_11l11111l_l1_[1]]:
			l11l11ll11_l1_ = l11l11ll11_l1_ + locals()[_11l11111l_l1_[1]][locals()[_11l11111l_l1_[2]][i]]
	_print(l1l111_l1_ (u"ࠫࡧ࡯ࡧࡔࡶࡵ࡭ࡳ࡭ࠠࠡࠢࠣࡁࠥࠫ࠮࠺࠲ࡶ࠲࠳࠴ࠧῃ")%l11l11ll11_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡥࡁࡡ࠭࠯࡝ࠩ࡟࠯࠭࠴ࠪࡀࠫࠫࡃ࠿࠲ࡼ࠼ࠫࠪῄ"), l111l1lll1_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡌ࡫ࡴࡖࡴ࡯ࠤࡓࡵࡴࠡࡈࡲࡹࡳࡪࠧ῅")
	l111ll1111_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡈࡧࡷ࡙ࡷࡲࠠࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫῆ") % l111ll1111_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠨࠪࡢ࠲࠯ࡅࠩ࡝࡝ࠪῇ"), l111ll1111_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"ࠩࡈࡖࡗࡀࠠࡈࡧࡷ࡚ࡦࡸࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠪῈ")
	l111ll11l1_l1_ = tmp[0]
	_print(l1l111_l1_ (u"ࠪࡋࡪࡺࡖࡢࡴࠣࠤࠥࠦࠠࠡࠢࡀࠤࠪࡹࠧΈ") % l111ll11l1_l1_)
	l11l111ll1_l1_ = locals()[l111ll11l1_l1_][0]
	l11l111ll1_l1_ = l111ll11ll_l1_(l11l111ll1_l1_)
	_print(l1l111_l1_ (u"ࠫࡌ࡫ࡴࡗࡣ࡯ࠤࠥࠦࠠࠡࠢࠣࡁࠥࠫࡳࠨῊ") % l11l111ll1_l1_)
	tmp = re.findall(l1l111_l1_ (u"ࠬࢃࡶࡢࡴࠣࠬ࡫ࡃ࠮ࠫࡁࠬ࠿ࠬΉ"), l111l1lll1_l1_, re.S)
	if not tmp: return l1l111_l1_ (u"࠭ࡅࡓࡔ࠽ࠤࡕࡵࡳࡵࡗࡵࡰࠥࡔ࡯ࡵࠢࡉࡳࡺࡴࡤࠨῌ")
	l111ll1l11_l1_ = str(tmp[0])
	_print(l1l111_l1_ (u"ࠧࡑࡱࡶࡸ࡚ࡸ࡬ࠡࠢࠣࠤࠥࠦ࠽ࠡࠧࡶࠫ῍") % l111ll1l11_l1_)
	l111ll1l11_l1_ = re.sub(l1l111_l1_ (u"ࠣࠪࡺ࡭ࡳࡪ࡯ࡸ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠥ῎"), l1l111_l1_ (u"ࠤࡤࡸࡴࡨࠢ῏"), l111ll1l11_l1_)
	l111ll1l11_l1_ = re.sub(l1l111_l1_ (u"ࠥࠬࡠࡇ࡛࠭࡟ࡾ࠵࠱࠸ࡽ࡝ࠪࠬࠦῐ"), l1l111_l1_ (u"ࠦࡦ࠶ࡤࠩ࡯ࡤ࡭ࡳࡥࡴࡢࡤ࠯ࡷࡹ࡫ࡰ࠳࠮ࠥῑ"), l111ll1l11_l1_)
	l111ll1l11_l1_ = l1l111_l1_ (u"ࠬ࡭࡬ࡰࡤࡤࡰࠥ࡬࠻ࠡࠩῒ")+l111ll1l11_l1_
	verify = re.findall(l1l111_l1_ (u"࠭࡜ࠬࠪࡢ࠲࠯ࡅࠩࠥࠩΐ"),l111ll1l11_l1_,re.DOTALL)[0]
	l111lll1l1_l1_ = eval(verify)
	l111ll1l11_l1_ = l111ll1l11_l1_.replace(l1l111_l1_ (u"ࠧࡨ࡮ࡲࡦࡦࡲࠠࡧ࠽ࠣࡪࡂ࠭῔"),l1l111_l1_ (u"ࠨࠩ῕"))
	f = eval(l111ll1l11_l1_,{l1l111_l1_ (u"ࠩࡤࡸࡴࡨࠧῖ"):l111ll11ll_l1_,l1l111_l1_ (u"ࠪࡥ࠵ࡪࠧῗ"):l111ll111l_l1_,l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࡡࡷࡥࡧ࠭Ῐ"):l11l1111ll_l1_,l1l111_l1_ (u"ࠬࡹࡴࡦࡲ࠵ࠫῙ"):l11l111111_l1_,verify:l111lll1l1_l1_})
	_print(l1l111_l1_ (u"࠭࠯ࠨῚ")+l11l111ll1_l1_+l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬΊ")+f+l11l11ll11_l1_+l1l111_l1_ (u"ࠨࠢࠣࠤࠥ࠭῜")+l11l11l11l_l1_)
	return([l1l111_l1_ (u"ࠩ࠲ࠫ῝")+l11l111ll1_l1_,f+l11l11ll11_l1_,{ l11l11l11l_l1_ : l1l111_l1_ (u"ࠪࡳࡰ࠭῞")}])
def _print(text):
	return
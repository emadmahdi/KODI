# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘࠨ墂")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡕࡋࡑࡤ࠭境")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll11l1lll_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
def l11l1ll_l1_(mode,url,text):
	if   mode==50: l1lll_l1_ = l1l1l11_l1_()
	elif mode==51: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==52: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==53: l1lll_l1_ = PLAY(url)
	elif mode==55: l1lll_l1_ = l111llll11ll_l1_()
	elif mode==56: l1lll_l1_ = l111lll1lll1_l1_()
	elif mode==57: l1lll_l1_ = l1111lll11_l1_(url,1)
	elif mode==58: l1lll_l1_ = l1111lll11_l1_(url,2)
	elif mode==59: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墄"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ墅"),l1l111_l1_ (u"ࠪࠫ墆"),59,l1l111_l1_ (u"ࠫࠬ墇"),l1l111_l1_ (u"ࠬ࠭墈"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ墉"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ墊"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭墋"),l1l111_l1_ (u"ࠩࠪ墌"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ墍"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭墎")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆี็ื้อสࠨ墏"),l1l111_l1_ (u"࠭ࠧ墐"),56)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墑"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ墒")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ฬ็ไศ็ࠪ墓"),l1l111_l1_ (u"ࠪࠫ墔"),55)
	return l1l111_l1_ (u"ࠫࠬ墕")
def l111llll11ll_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ墖"),l1lllll_l1_+l1l111_l1_ (u"࠭วฮัฮࠤฬ๊วโๆส้ࠬ増"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡱࡩࡼ࡫ࡳࡵࠩ墘"),51)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墙"),l1lllll_l1_+l1l111_l1_ (u"ࠩสๅ้อๅࠡำสสัฯࠧ墚"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠭墛"),51)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ墜"),l1lllll_l1_+l1l111_l1_ (u"ࠬอฮาࠢสฺฬ็วหࠢส่ฬ็ไศ็ࠪ墝"),l111l1_l1_+l1l111_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰࡮ࡤࡸࡪࡹࡴࠨ增"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墟"),l1lllll_l1_+l1l111_l1_ (u"ࠨษไ่ฬ๋ࠠไๆสื๏้๊สࠩ墠"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡨࡲࡡࡴࡵ࡬ࡧࠬ墡"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ墢"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ墣"),l1l111_l1_ (u"ࠬ࠭墤"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭墥"),l1lllll_l1_+l1l111_l1_ (u"ࠧศะอ๎ฬืࠠศใ็ห๊ࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ墦"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡽࡴࡶࠧ墧"),57)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墨"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะ๊ศำࠣหๆ๊วๆ่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ墩"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡲࡦࡸ࡬ࡩࡼ࠭墪"),57)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ墫"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦวโๆส้๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ墬"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫࠯࠲࠱ࡹ࡭ࡪࡽࡳࠨ墭"),57)
	return
def l111lll1lll1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ墮"),l1lllll_l1_+l1l111_l1_ (u"ࠩสัิัࠠศๆ่ืู้ไศฬࠪ墯"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵࡮ࡦࡹࡨࡷࡹ࠭墰"),51)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ墱"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำๅี็หฯࠦัศศฯอࠬ墲"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡳࡳࡵࡻ࡬ࡢࡴࠪ墳"),51)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ墴"),l1lllll_l1_+l1l111_l1_ (u"ࠨษัีࠥอึศใสฮࠥอไๆี็ื้อสࠨ墵"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡲࡡࡵࡧࡶࡸࠬ墶"),51)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ墷"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆสฮ้ࠥไศีํ็๏ฯࠧ墸"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡥ࡯ࡥࡸࡹࡩࡤࠩ墹"),51)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ墺"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ墻"),l1l111_l1_ (u"ࠨࠩ墼"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ墽"),l1lllll_l1_+l1l111_l1_ (u"ࠪหำะ๊ศำุ้๊ࠣำๅษอࠤ๊ืสษหࠣฬุ์ษࠡษ็ห๋ะวอࠩ墾"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯ࡺࡱࡳࠫ墿"),57)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壀"),l1lllll_l1_+l1l111_l1_ (u"࠭วฯฬํหึࠦๅิๆึ่ฬะࠠๆำอฬฮࠦศศๆสๅ฻๊ࠠหไํ๎๊࠭壁"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡶࡪࡼࡩࡦࡹࠪ壂"),57)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ壃"),l1lllll_l1_+l1l111_l1_ (u"ࠩสาฯ๐วา่ࠢืู้ไศฬ้ࠣึะศสࠢหห้อใฬำู้ࠣอ็ะหࠪ壄"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠶࠵ࡶࡪࡧࡺࡷࠬ壅"),57)
	return
def l1lll11_l1_(url):
	if l1l111_l1_ (u"ࠫࡄ࠭壆") in url:
		parts = url.split(l1l111_l1_ (u"ࠬࡅࠧ壇"))
		url = parts[0]
		filter = l1l111_l1_ (u"࠭࠿ࠨ壈") + QUOTE(parts[1],l1l111_l1_ (u"ࠧ࠾ࠨ࠽࠳ࠪ࠭壉"))
	else: filter = l1l111_l1_ (u"ࠨࠩ壊")
	parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ壋"))
	sort,l1llllll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l1l111_l1_ (u"ࠪࡽࡴࡶࠧ壌"),l1l111_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ壍"),l1l111_l1_ (u"ࠬࡼࡩࡦࡹࡶࠫ壎")]:
		if type==l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ壏"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠧโ์็้ࠬ壐")
		elif type==l1l111_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ壑"): l1l1l1lll_l1_=l1l111_l1_ (u"่ࠩืู้ไࠨ壒")
		url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ࡪ࡮ࡲࡴࡦࡴ࠲ࠫ壓") + QUOTE(l1l1l1lll_l1_) + l1l111_l1_ (u"ࠫ࠴࠭壔") + l1llllll1_l1_ + l1l111_l1_ (u"ࠬ࠵ࠧ壕") + sort + filter
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"࠭ࠧ壖"),l1l111_l1_ (u"ࠧࠨ壗"),l1l111_l1_ (u"ࠨࠩ壘"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ壙"))
		items = re.findall(l1l111_l1_ (u"ࠪࠦࡵ࡯ࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡶࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡴࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡱࡴࡨࡷࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ壚"),html,re.DOTALL)
		l1ll111ll11_l1_=0
		for id,title,l111lll1ll1l_l1_,l1ll1l_l1_ in items:
			l1ll111ll11_l1_ += 1
			l1ll1l_l1_ = l1ll11l1lll_l1_ + l1l111_l1_ (u"ࠫ࠴ࡼ࠲࠰࡫ࡰ࡫࠴ࡶࡲࡰࡩࡵࡥࡲ࠵࡭ࡢ࡫ࡱ࠳ࠬ壛") + l1ll1l_l1_ + l1l111_l1_ (u"ࠬ࠳࠲࠯࡬ࡳ࡫ࠬ壜")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ壝") + id
			if type==l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭壞"): addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ壟"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ壠"): addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ壡"),l1lllll_l1_+l1l111_l1_ (u"ู๊ࠫไิๆࠣࠫ壢")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠬࡅࡥࡱ࠿ࠪ壣")+l111lll1ll1l_l1_+l1l111_l1_ (u"࠭࠽ࠨ壤")+title+l1l111_l1_ (u"ࠧ࠾ࠩ壥")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l1l111_l1_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧ壦"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ壧")
		elif type==l1l111_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ壨"): l1l1l1lll_l1_=l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ壩")
		url = l1l1l1lll1_l1_ + l1l111_l1_ (u"ࠬ࠵ࡪࡴࡱࡱ࠳ࡸ࡫࡬ࡦࡥࡷࡩࡩ࠵ࠧ壪") + sort + l1l111_l1_ (u"࠭࠭ࠨ士") + l1l1l1lll_l1_ + l1l111_l1_ (u"ࠧ࠮࡙࡚࠲࡯ࡹ࡯࡯ࠩ壬")
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠨࠩ壭"),l1l111_l1_ (u"ࠩࠪ壮"),l1l111_l1_ (u"ࠪࠫ壯"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ声"))
		items = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡦࡨࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡪࡶࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡤࡤࡷࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ壱"),html,re.DOTALL)
		l1ll111ll11_l1_=0
		for id,l111lll1ll1l_l1_,l1ll1l_l1_,title in items:
			l1ll111ll11_l1_ += 1
			l1ll1l_l1_ = l1l1l1lll1_l1_ + l1l111_l1_ (u"࠭࠯ࡪ࡯ࡪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭売") + l1ll1l_l1_ + l1l111_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ壳")
			l1ll1ll_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ壴") + id
			if type==l1l111_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ壵"): addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ壶"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
			elif type==l1l111_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ壷"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ壸"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิๆึ่ࠥ࠭壹")+title,l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡧࡳࡁࠬ壺")+l111lll1ll1l_l1_+l1l111_l1_ (u"ࠨ࠿ࠪ壻")+title+l1l111_l1_ (u"ࠩࡀࠫ壼")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l1l111_l1_ (u"ูࠪๆำษࠡࠩ壽")
	if l1ll111ll11_l1_==16:
		for l1ll11ll111_l1_ in range(1,13) :
			if not l1llllll1_l1_==str(l1ll11ll111_l1_):
				url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬ壾")+type+l1l111_l1_ (u"ࠬ࠵ࠧ壿")+str(l1ll11ll111_l1_)+l1l111_l1_ (u"࠭࠯ࠨ夀")+sort + filter
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ夁"),l1lllll_l1_+title+str(l1ll11ll111_l1_),url,51)
	return
def l1ll1l11_l1_(url):
	parts = url.split(l1l111_l1_ (u"ࠨ࠿ࠪ夂"))
	l111lll1ll1l_l1_ = int(parts[1])
	name = l111l11_l1_(parts[2])
	name = name.replace(l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ夃"),l1l111_l1_ (u"ࠪࠫ处"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l1l111_l1_ (u"ࠫࡄ࠭夅"))[0]
	if l111lll1ll1l_l1_==0:
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠬ࠭夆"),l1l111_l1_ (u"࠭ࠧ备"),l1l111_l1_ (u"ࠧࠨ夈"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ変"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࠿ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡱ࡫ࡣࡵࡀࠪ夊"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ夋"),block,re.DOTALL)
		l111lll1ll1l_l1_ = int(items[-1])
	for l1l1lll_l1_ in range(l111lll1ll1l_l1_,0,-1):
		l1ll1ll_l1_ = url + l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾ࠩ夌") + str(l1l1lll_l1_)
		title = l1l111_l1_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ复")+name+l1l111_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ夎")+str(l1l1lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭夏"),l1lllll_l1_+title,l1ll1ll_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠨࠩ夐"),l1l111_l1_ (u"ࠩࠪ夑"),l1l111_l1_ (u"ࠪࠫ夒"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ夓"))
	l111lll1llll_l1_ = re.findall(l1l111_l1_ (u"๋ࠬส้ใิࠤ฾๊้ࠡึ๋ๅ๋ࠥวไีࠣฬ฾ี࠮ࠫࡁࡰࡳࡲ࡫࡮ࡵ࡞ࠫࠦ࠭࠴ࠪࡀࠫࠥࠫ夔"),html,re.DOTALL)
	if l111lll1llll_l1_:
		time = l111lll1llll_l1_[1].replace(l1l111_l1_ (u"࠭ࡔࠨ夕"),l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ外"))
		l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ夗"),l1l111_l1_ (u"ࠩࠪ夘"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠬ夙"),l1l111_l1_ (u"ࠫ์ึวࠡษ็ๅ๏ี๊้ࠢึ๎่๎ๆࠡ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั๋ࠣีอࠠศๆ๋ๆฯ࠭多")+l1l111_l1_ (u"ࠬࡢ࡮ࠨ夛")+time)
		return
	l111lll1l1ll_l1_,l111llll111l_l1_ = [],[]
	l111llll11l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࡶࡢࡴࠣࡳࡷ࡯ࡧࡪࡰࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ夜"),html,re.DOTALL)[0]
	l111llll1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡷࡣࡵࠤࡧࡧࡣ࡬ࡷࡳࡣࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ夝"),html,re.DOTALL)[0]
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪ࡯ࡷ࠿ࠦࠨ࠯ࠬࡂ࠭ࡤࡲࡩ࡯࡭࡟࠯ࠧ࠮࠮ࠫࡁࠬࠦࠬ夞"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		if l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠩ够") in server:
			server = l1l111_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠣࡷࡪࡸࡶࡦࡴࠪ夠")
			url = l111llll1111_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࠢࡶࡩࡷࡼࡥࡳࠩ夡")
			url = l111llll11l1_l1_ + l1ll1ll_l1_
		if l1l111_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ夢") in url:
			l111lll1l1ll_l1_.append(url)
			l111llll111l_l1_.append(l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠤࠥ࠭夣")+server)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿ࡠ࡮࡬ࡲࡰ࠴ࠪࡀ࡞ࡷࠬ࠳࠰࠿ࠪࡡ࡯࡭ࡳࡱ࡜ࠬࠤࠫ࠲࠯ࡅࠩࠣࠩ夤"),html,re.DOTALL)
	l1ll_l1_ += re.findall(l1l111_l1_ (u"ࠨ࡯ࡳ࠸࠿࠴ࠪࡀ࡞ࡷࠬ࠳࠰࠿ࠪࡡ࡯࡭ࡳࡱ࡜ࠬࠤࠫ࠲࠯ࡅࠩࠣࠩ夥"),html,re.DOTALL)
	for server,l1ll1ll_l1_ in l1ll_l1_:
		filename = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠩ࠲ࠫ夦"))[-1]
		filename = filename.replace(l1l111_l1_ (u"ࠪࡪࡦࡲ࡬ࡣࡣࡦ࡯ࠬ大"),l1l111_l1_ (u"ࠫࠬ夨"))
		filename = filename.replace(l1l111_l1_ (u"ࠬ࠴࡭ࡱ࠶ࠪ天"),l1l111_l1_ (u"࠭ࠧ太"))
		filename = filename.replace(l1l111_l1_ (u"ࠧ࠮ࠩ夫"),l1l111_l1_ (u"ࠨࠩ夬"))
		if l1l111_l1_ (u"ࠩࡥࡥࡨࡱࡵࡱࠩ夭") in server:
			server = l1l111_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠣࡷࡪࡸࡶࡦࡴࠪ央")
			url = l111llll1111_l1_ + l1ll1ll_l1_
		else:
			server = l1l111_l1_ (u"ࠫࡲࡧࡩ࡯ࠢࡶࡩࡷࡼࡥࡳࠩ夯")
			url = l111llll11l1_l1_ + l1ll1ll_l1_
		l111lll1l1ll_l1_.append(url)
		l111llll111l_l1_.append(l1l111_l1_ (u"ࠬࡳࡰ࠵ࠢࠣࠫ夰")+server+l1l111_l1_ (u"࠭ࠠࠡࠩ失")+filename)
	l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧࡔࡧ࡯ࡩࡨࡺࠠࡗ࡫ࡧࡩࡴࠦࡑࡶࡣ࡯࡭ࡹࡿ࠺ࠨ夲"), l111llll111l_l1_)
	if l11l11l_l1_ == -1 : return
	url = l111lll1l1ll_l1_[l11l11l_l1_]
	l1llll111_l1_(url,l1ll1_l1_,l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ夳"))
	return
def l1111lll11_l1_(url,type):
	if l1l111_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࡴࠩ头") in url: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ุ้๊ำๅࠩ夵")
	else: l1lllll1_l1_ = l111l1_l1_ + l1l111_l1_ (u"ࠫ࠴࡭ࡥ࡯ࡴࡨ࠳ๆ๐ไๆࠩ夶")
	l1lllll1_l1_ = QUOTE(l1lllll1_l1_)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭夷"),l1l111_l1_ (u"࠭ࠧ夸"),l1l111_l1_ (u"ࠧࠨ夹"),l1l111_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡊࡎࡒࡔࡆࡔࡖ࠱࠶ࡹࡴࠨ夺"))
	if type==1: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡹࡧ࡭ࡥ࡯ࡴࡨࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ夻"),html,re.DOTALL)
	elif type==2: l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ夼"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡴࡶࡴࡪࡱࡱࠫ夽"),block,re.DOTALL)
	if type==1:
		for l111lll1ll11_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ夾"),l1lllll_l1_+title,url+l1l111_l1_ (u"࠭࠿ࡴࡷࡥ࡫ࡪࡴࡲࡦ࠿ࠪ夿")+l111lll1ll11_l1_,58)
	elif type==2:
		url,l111lll1ll11_l1_ = url.split(l1l111_l1_ (u"ࠧࡀࠩ奀"))
		for l1lll11ll111_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ奁"),l1lllll_l1_+title,url+l1l111_l1_ (u"ࠩࡂࡧࡴࡻ࡮ࡵࡴࡼࡁࠬ奂")+l1lll11ll111_l1_+l1l111_l1_ (u"ࠪࠪࠬ奃")+l111lll1ll11_l1_,51)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠫࠥ࠭奄"),l1l111_l1_ (u"ࠬࠫ࠲࠱ࠩ奅"))
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪ奆")+l1lll1ll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ奇"),url,l1l111_l1_ (u"ࠨࠩ奈"),l1l111_l1_ (u"ࠩࠪ奉"),True,l1l111_l1_ (u"ࠪࠫ奊"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠲࡯ࡦࠪ奋"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡭ࡥ࡯ࡧࡵࡥࡱ࠳ࡢࡰࡦࡼࠬ࠳࠰࠿ࠪࡵࡨࡥࡷࡩࡨ࠮ࡤࡲࡸࡹࡵ࡭࠮ࡲࡤࡨࡩ࡯࡮ࡨࠩ奌"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ奍"),block,re.DOTALL)
	if items:
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			url = l111l1_l1_ + l1ll1ll_l1_
			if l1l111_l1_ (u"ࠧ࠰ࡲࡵࡳ࡬ࡸࡡ࡮࠱ࠪ奎") in url:
				if l1l111_l1_ (u"ࠨࡁࡨࡴࡂ࠭奏") in url:
					title = l1l111_l1_ (u"ࠩࡢࡑࡔࡊ࡟ๆี็ื้ࠦࠧ奐")+title
					url = url.replace(l1l111_l1_ (u"ࠪࡃࡪࡶ࠽࠲ࠩ契"),l1l111_l1_ (u"ࠫࡄ࡫ࡰ࠾࠲ࠪ奒"))
					url = url+l1l111_l1_ (u"ࠬࡃࠧ奓")+QUOTE(title)+l1l111_l1_ (u"࠭࠽ࠨ奔")+l1ll1l_l1_
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ奕"),l1lllll_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l1l111_l1_ (u"ࠨࡡࡐࡓࡉࡥแ๋ๆ่ࠤࠬ奖")+title
					addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ套"),l1lllll_l1_+title,url,53,l1ll1l_l1_)
	return
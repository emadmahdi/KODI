# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬᖏ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉࡃࡃࡡࠪᖐ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬ฿ัุ้ࠣห้๋ีศำ฼๋ࠬᖑ"),l1l111_l1_ (u"࠭ไๅๅหหึࠦแใูࠣ࠯࠶࠾ࠧᖒ"),l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩᖓ"),l1l111_l1_ (u"ࠨษไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠫᖔ")]
headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᖕ"):l111l1_l1_}
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==630: l1lll_l1_ = l1l1l11_l1_()
	elif mode==631: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==632: l1lll_l1_ = PLAY(url)
	elif mode==633: l1lll_l1_ = l111l1111_l1_(url)
	elif mode==634: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡈࡌࡐ࡙ࡋࡒࡠࡡࡢࠫᖖ")+text)
	elif mode==635: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࡤࡥ࡟ࠨᖗ")+text)
	elif mode==639: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩᖘ"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧᖙ"),headers,l1l111_l1_ (u"ࠧࠨᖚ"),l1l111_l1_ (u"ࠨࠩᖛ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ᖜ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᖝ"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᖞ"),l111l1_l1_,639,l1l111_l1_ (u"ࠬ࠭ᖟ"),l1l111_l1_ (u"࠭ࠧᖠ"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᖡ"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖢ"),l1lllll_l1_+l1l111_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬᖣ"),l111l1_l1_,635,l1l111_l1_ (u"ࠪࠫᖤ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᖥ"))
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᖦ"),l1lllll_l1_+l1l111_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩᖧ"),l111l1_l1_,634,l1l111_l1_ (u"ࠧࠨᖨ"),l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨᖩ"))
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᖪ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖫ"),l1l111_l1_ (u"ࠫࠬᖬ"),9999)
	l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡱ࡫ࡱࡴࡴࡹࡴࡴࠨࡢࡧࡴࡻ࡮ࡵ࠿࠴࠴ࠬᖭ")
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖮ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᖯ")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้๊๐าสࠩᖰ"),l1ll1ll_l1_,631,l1l111_l1_ (u"ࠩࠪᖱ"),l1l111_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬᖲ"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᖳ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡔࡢࡤࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᖴ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡧࡦࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀࠬᖵ"),block,re.DOTALL)
		for data,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࠫᖶ")+data
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖷ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᖸ")+l1lllll_l1_+title,l1ll1ll_l1_,631)
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᖹ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᖺ"),l1l111_l1_ (u"ࠬ࠭ᖻ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᖼ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᖽ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᖾ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᖿ")+l1lllll_l1_+title,l1ll1ll_l1_,631)
	return
def l1lll11_l1_(url,type=l1l111_l1_ (u"ࠪࠫᗀ")):
	if type==l1l111_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ᗁ"):
		l1ll1ll1l_l1_ = headers.copy()
		l1ll1ll1l_l1_[l1l111_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨᗂ")] = l1l111_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧᗃ")
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᗄ"),url,l1l111_l1_ (u"ࠨࠩᗅ"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠩࠪᗆ"),l1l111_l1_ (u"ࠪࠫᗇ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᗈ"))
		html = response.content
		block = html
	else:
		block = l1l111_l1_ (u"ࠬ࠭ᗉ")
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᗊ"),url,l1l111_l1_ (u"ࠧࠨᗋ"),headers,l1l111_l1_ (u"ࠨࠩᗌ"),l1l111_l1_ (u"ࠩࠪᗍ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩᗎ"))
		html = response.content
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡲ࡫ࡤࡪࡣ࠰ࡦࡱࡵࡣ࡬ࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷ࠳࡭ࡦࡰࡸࠫᗏ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᗐ"),block,re.DOTALL)
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		l1ll1l_l1_ = l1ll1l_l1_+l1l111_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᗑ")+l111l1_l1_
		if l1l111_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩᗒ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗓ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᗔ")+l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬᗕ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᗖ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᗗ")+l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
		elif l1l111_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᗘ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᗙ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᗚ")+l1lllll_l1_+title,l1ll1ll_l1_,631,l1ll1l_l1_)
		elif l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶࠫᗛ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᗜ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᗝ")+l1lllll_l1_+title,l1ll1ll_l1_,631,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᗞ"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᗟ")+l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᗠ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᗡ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠩสฺ่็อสࠢࠪᗢ"),l1l111_l1_ (u"ࠪࠫᗣ"))
			if title!=l1l111_l1_ (u"ࠫࠬᗤ"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᗥ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬᗦ")+title,l1ll1ll_l1_,631)
	return
def l111l1111_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᗧ"),url,l1l111_l1_ (u"ࠨࠩᗨ"),headers,l1l111_l1_ (u"ࠩࠪᗩ"),l1l111_l1_ (u"ࠪࠫᗪ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡓࡆࡃࡖࡓࡓ࡙࡟ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᗫ"))
	html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡯ࡴࡶࡨࡶ࠲࡯࡭ࡢࡩࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᗬ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0] if l1ll1l_l1_ else l1l111_l1_ (u"࠭ࠧᗭ")
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡱ࡯ࡨࡪࡸ࠭ࡣ࡮ࡲࡧࡰ࠴ࠪࡀ࠾࡫࠶࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᗮ"),html,re.DOTALL)
	for name,block in l11llll_l1_:
		if l1l111_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪᗯ") in url and l1l111_l1_ (u"่ࠩ์ฬูๅࠨᗰ") in name:
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬᗱ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁࠫᗲ"),l1l111_l1_ (u"ࠬࠦࠧᗳ")).replace(l1l111_l1_ (u"࠭࠼࠰ࡵࡳࡥࡳࡄࠧᗴ"),l1l111_l1_ (u"ࠧࠨᗵ"))
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᗶ"),l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
		if l1l111_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᗷ") in url and l1l111_l1_ (u"ࠪั้่วหࠩᗸ") in name:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠷ࡃ࠭ᗹ"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.replace(l1l111_l1_ (u"ࠬࡂࡳࡱࡣࡱࡂࠬᗺ"),l1l111_l1_ (u"࠭ࠠࠨᗻ")).replace(l1l111_l1_ (u"ࠧ࠽࠱ࡶࡴࡦࡴ࠾ࠨᗼ"),l1l111_l1_ (u"ࠨࠩᗽ"))
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᗾ"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
	return
def PLAY(url):
	url = url.replace(l1l111_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ᗿ"),l1l111_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬᘀ")).replace(l1l111_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰ࠳ࠬᘁ"),l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧᘂ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫᘃ"),url,l1l111_l1_ (u"ࠨࠩᘄ"),headers,l1l111_l1_ (u"ࠩࠪᘅ"),l1l111_l1_ (u"ࠪࠫᘆ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨᘇ"))
	html = response.content
	l1ll11l1_l1_,l111l11l1_l1_ = [],[]
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠲ࡽࡲࡢࡲࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᘈ"),html,re.DOTALL)
	if l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_[0]
		l111l11l1_l1_.append(l1ll1ll_l1_)
		server = l1l111l_l1_(l1ll1ll_l1_,l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫᘉ"))
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᘊ")+server+l1l111_l1_ (u"ࠨࡡࡢࡩࡲࡨࡥࡥࠩᘋ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᘌ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11l1l11_l1_ = re.findall(l1l111_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠥࠫᘍ"),html,re.DOTALL)
		l11l1l11_l1_ = l11l1l11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᘎ"),block,re.DOTALL)
		for l11l1lll_l1_,title in items:
			title = title.replace(l1l111_l1_ (u"ࠬࡢ࡮ࠨᘏ"),l1l111_l1_ (u"࠭ࠧᘐ"))
			if not title: title = l1l111_l1_ (u"ࠧศๆึ๎ึ็ัࠡษ็้๊๐าࠨᘑ")
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭ᘒ")+l11l1l11_l1_+l1l111_l1_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭ᘓ")+l11l1lll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᘔ")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬᘕ")
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡣ࡮ࡲࡧࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪᘖ"),html,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_ not in l111l11l1_l1_:
			l111l11l1_l1_.append(l1ll1ll_l1_)
			title = title.replace(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠭ᘗ"),l1l111_l1_ (u"ࠧࠡࠩᘘ")).replace(l1l111_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿ࠩᘙ"),l1l111_l1_ (u"ࠩࠪᘚ")).replace(l1l111_l1_ (u"ࠪࡀ࡮ࡄࠧᘛ"),l1l111_l1_ (u"ࠫࠬᘜ")).replace(l1l111_l1_ (u"ࠬࡂ࠯ࡪࡀࠪᘝ"),l1l111_l1_ (u"࠭ࠠࠨᘞ"))
			l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᘟ")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬᘠ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᘡ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search: search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬᘢ"),l1l111_l1_ (u"ࠫ࠰࠭ᘣ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳ࠾ࠩᘤ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᘥ"))
	return
def l11l111l1_l1_(url):
	url = url.split(l1l111_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫᘦ"))[0]
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬᘧ"),url,l1l111_l1_ (u"ࠩࠪᘨ"),headers,l1l111_l1_ (u"ࠪࠫᘩ"),l1l111_l1_ (u"ࠫࠬᘪ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈ࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩᘫ"))
	html = response.content
	l1l11l1l_l1_ = []
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭ᘬ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡴࡧ࡯ࡩࡨࡺ࠭࡮ࡧࡱࡹࠧࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡤࡢࡶࡤ࠱ࡹࡧࡸ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᘭ"),block,re.DOTALL)
		names,l1111lll1_l1_,l1lll1l1_l1_ = zip(*l1l11l1l_l1_)
		l1l11l1l_l1_ = zip(names,l1111lll1_l1_,l1lll1l1_l1_)
	return l1l11l1l_l1_
def l111ll1ll_l1_(block):
	items = re.findall(l1l111_l1_ (u"ࠨࡥࡤࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡰࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᘮ"),block,re.DOTALL)
	return items
def l1111ll11_l1_(url):
	if l1l111_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭ᘯ") in url:
		url,filters = url.split(l1l111_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧᘰ"))
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨᘱ")+filters
	else: l1ll1ll_l1_ = l111l1_l1_
	return l1ll1ll_l1_
l1111ll1l_l1_ = [l1l111_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᘲ"),l1l111_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᘳ"),l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭ᘴ"),l1l111_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩᘵ")]
l111l111l_l1_ = [l1l111_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᘶ"),l1l111_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩᘷ"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪᘸ")]
def l1l1ll1l_l1_(url,filter):
	url = url.split(l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᘹ"))[0]
	type,filter = filter.split(l1l111_l1_ (u"࠭࡟ࡠࡡࠪᘺ"),1)
	if filter==l1l111_l1_ (u"ࠧࠨᘻ"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠨࠩᘼ"),l1l111_l1_ (u"ࠩࠪᘽ")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠪࡣࡤࡥࠧᘾ"))
	if type==l1l111_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬᘿ"):
		if l111l111l_l1_[0]+l1l111_l1_ (u"ࠬࡃࠧᙀ") not in l11lll1l_l1_: category = l111l111l_l1_[0]
		for i in range(len(l111l111l_l1_[0:-1])):
			if l111l111l_l1_[i]+l1l111_l1_ (u"࠭࠽ࠨᙁ") in l11lll1l_l1_: category = l111l111l_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩᙂ")+category+l1l111_l1_ (u"ࠨ࠿࠳ࠫᙃ")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫᙄ")+category+l1l111_l1_ (u"ࠪࡁ࠵࠭ᙅ")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"ࠫࠫ࠭ᙆ"))+l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩᙇ")+l1l1ll11_l1_.strip(l1l111_l1_ (u"࠭ࠦࠨᙈ"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᙉ"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᙊ")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧᙋ"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᙌ"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_: l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧᙍ"))
		if not l11lll11_l1_: l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩᙎ")+l11lll11_l1_
		l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᙏ"),l1lllll_l1_+l1l111_l1_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪᙐ"),l1llllll_l1_,631,l1l111_l1_ (u"ࠨࠩᙑ"),l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࠩᙒ"))
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙓ"),l1lllll_l1_+l1l111_l1_ (u"ࠫࠥࡡ࡛ࠡࠢࠣࠫᙔ")+l11l1l1l_l1_+l1l111_l1_ (u"ࠬࠦࠠࠡ࡟ࡠࠫᙕ"),l1llllll_l1_,631,l1l111_l1_ (u"࠭ࠧᙖ"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࠧᙗ"))
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᙘ"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᙙ"),l1l111_l1_ (u"ࠪࠫᙚ"),9999)
	l1l11l1l_l1_ = l11l111l1_l1_(url)
	dict = {}
	for name,l1l111ll_l1_,block in l1l11l1l_l1_:
		name = name.replace(l1l111_l1_ (u"่๊ࠫࠠࠨᙛ"),l1l111_l1_ (u"ࠬ࠭ᙜ"))
		items = l111ll1ll_l1_(block)
		if l1l111_l1_ (u"࠭࠽ࠨᙝ") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨᙞ"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<2:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
					l1lll11_l1_(l1llllll_l1_,l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࠨᙟ"))
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"ࠩࡇࡉࡋࡏࡎࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭ᙠ")+l1l111l1_l1_)
				return
			else:
				if l1l111ll_l1_==l111l111l_l1_[-1]:
					l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙡ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬᙢ"),l1llllll_l1_,631,l1l111_l1_ (u"ࠬ࠭ᙣ"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷ࠭ᙤ"))
				else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᙥ"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩᙦ"),l1lllll1_l1_,635,l1l111_l1_ (u"ࠩࠪᙧ"),l1l111_l1_ (u"ࠪࠫᙨ"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࠩᙩ"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠬࠬࠧᙪ")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠱ࠩᙫ")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠧࠧࠩᙬ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿࠳ࠫ᙭")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠩࡢࡣࡤ࠭᙮")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᙯ"),l1lllll_l1_+l1l111_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ᙰ")+name,l1lllll1_l1_,634,l1l111_l1_ (u"ࠬ࠭ᙱ"),l1l111_l1_ (u"࠭ࠧᙲ"),l1l111l1_l1_)
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			if not value: continue
			if option in l11lll_l1_: continue
			dict[l1l111ll_l1_][value] = option
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠩᙳ")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࠪᙴ")+option
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠫᙵ")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࠬᙶ")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨᙷ")+l1l1ll11_l1_
			title = option+l1l111_l1_ (u"ࠬࠦ࠺ࠨᙸ")#+dict[l1l111ll_l1_][l1l111_l1_ (u"࠭࠰ࠨᙹ")]
			title = option+l1l111_l1_ (u"ࠧࠡ࠼ࠪᙺ")+name
			if type==l1l111_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭ᙻ"): addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᙼ"),l1lllll_l1_+title,url,634,l1l111_l1_ (u"ࠪࠫᙽ"),l1l111_l1_ (u"ࠫࠬᙾ"),l1l1l11l_l1_)
			elif type==l1l111_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗ࠭ᙿ") and l111l111l_l1_[-2]+l1l111_l1_ (u"࠭࠽ࠨ ") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᚁ"))
				l1lllll1_l1_ = url+l1l111_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬᚂ")+l11ll111_l1_
				l1llllll_l1_ = l1111ll11_l1_(l1lllll1_l1_)
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᚃ"),l1lllll_l1_+title,l1llllll_l1_,631,l1l111_l1_ (u"ࠪࠫᚄ"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࠫᚅ"))
			else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᚆ"),l1lllll_l1_+title,url,635,l1l111_l1_ (u"࠭ࠧᚇ"),l1l111_l1_ (u"ࠧࠨᚈ"),l1l1l11l_l1_)
	return
def l11ll1l1_l1_(filters,mode):
	filters = filters.replace(l1l111_l1_ (u"ࠨ࠿ࠩࠫᚉ"),l1l111_l1_ (u"ࠩࡀ࠴ࠫ࠭ᚊ"))
	filters = filters.strip(l1l111_l1_ (u"ࠪࠪࠬᚋ"))
	l11lllll_l1_ = {}
	if l1l111_l1_ (u"ࠫࡂ࠭ᚌ") in filters:
		items = filters.split(l1l111_l1_ (u"ࠬࠬࠧᚍ"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"࠭࠽ࠨᚎ"))
			l11lllll_l1_[var] = value
	l1l1l111_l1_ = l1l111_l1_ (u"ࠧࠨᚏ")
	for key in l1111ll1l_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠨ࠲ࠪᚐ")
		if l1l111_l1_ (u"ࠩࠨࠫᚑ") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬᚒ") and value!=l1l111_l1_ (u"ࠫ࠵࠭ᚓ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠬࠦࠫࠡࠩᚔ")+value
		elif mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᚕ") and value!=l1l111_l1_ (u"ࠧ࠱ࠩᚖ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠨࠪᚗ")+key+l1l111_l1_ (u"ࠩࡀࠫᚘ")+value
		elif mode==l1l111_l1_ (u"ࠪࡥࡱࡲࠧᚙ"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫ࠭ᚚ")+key+l1l111_l1_ (u"ࠬࡃࠧ᚛")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"࠭ࠠࠬࠢࠪ᚜"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠧࠧࠩ᚝"))
	l1l1l111_l1_ = l1l1l111_l1_.replace(l1l111_l1_ (u"ࠨ࠿࠳ࠫ᚞"),l1l111_l1_ (u"ࠩࡀࠫ᚟"))
	return l1l1l111_l1_
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭屇")
l1lllll_l1_ = l1l111_l1_ (u"࠭࡟࡚ࡗࡗࡣࠬ屈")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l111l1lllll1_l1_ = 0
def l11l1ll_l1_(mode,url,text,type,l1llllll1_l1_,name,l11l_l1_):
	if	 mode==140: l1lll_l1_ = l1l1l11_l1_()
	elif mode==141: l1lll_l1_ = l111l1llll11_l1_(url,name,l11l_l1_)
	elif mode==143: l1lll_l1_ = PLAY(url,type)
	elif mode==144: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_,text)
	elif mode==145: l1lll_l1_ = l111ll1llll1_l1_(url,l1llllll1_l1_)
	elif mode==147: l1lll_l1_ = l111ll11llll_l1_()
	elif mode==148: l1lll_l1_ = l111ll1l111l_l1_()
	elif mode==149: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	if 0:
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ屉"),l1lllll_l1_+l1l111_l1_ (u"ࠨไสส๊ฯࠧ届"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑࡇࡪ࠶ࡉࡶ࠼ࡋࡎ࠸࡛ࡰࡘࡦࡋ࠶ࡒࡗ࠯࠺ࡋ࠸ࡈ࡯ࡲࡋࡼ࡞ࡆ࠺ࡵࡔࡃࠪ屋"),144)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屌"),l1lllll_l1_+l1l111_l1_ (u"ูࠫิีࠨ屍"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳࡙ࡉࡎࡰࡨࡩ࡭ࡨ࡯ࡡ࡭ࠩ屎"),144)
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屏"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠬ屐"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮࠲࡙ࡈࡷ࠵࠺ࡣࡊࡒࡸࡷ࠹ࡣࡤ࡫ࡻ࡛࡚ࡱ࠲ࡗࡷࡺ࡬ࡽࠧ屑"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屒"),l1lllll_l1_+l1l111_l1_ (u"ࠪัุอศࠨ屓"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡆࡔࡩࡧࡖࡳࡨ࡯ࡡ࡭ࡅࡗ࡚ࠬ屔"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ展"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅ฻สฬࠬ屖"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡩࡤࡱ࡮ࡴࡧࠨ屗"),144)
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屘"),l1lllll_l1_+l1l111_l1_ (u"ࠩสๅ้อๅࠨ屙"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡶࡸࡴࡸࡥࡧࡴࡲࡲࡹ࠭屚"),144)
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屛"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬฮหษิหฯ࠭屜"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴࡭ࡵࡪࡦࡨࡣࡧࡻࡩ࡭ࡦࡨࡶࠬ屝"),144)
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ属"),l1lllll_l1_+l1l111_l1_ (u"ࠨไุ๎ึฯࠧ屟"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡷ࡭ࡵࡲࡵࡵࠪ屠"),144,l1l111_l1_ (u"ࠪࠫ屡"),l1l111_l1_ (u"ࠫࠬ屢"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ屣"))
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭層"),l1lllll_l1_+l1l111_l1_ (u"ࠧหืไัࠬ履"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ屦"),144)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屧"),l1lllll_l1_+l1l111_l1_ (u"ࠪีห๐ำ๋หࠪ屨"),l111l1_l1_+l1l111_l1_ (u"ࠫࠬ屩"),144)
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屪"),l1lllll_l1_+l1l111_l1_ (u"࠭ัศศฯࠫ屫"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࡀࡤࡳࡁࠬ屬"),144)
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭屭"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ屮"),l1l111_l1_ (u"ࠪࠫ屯"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屰"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ山"),l1l111_l1_ (u"࠭ࠧ屲"),149,l1l111_l1_ (u"ࠧࠨ屳"),l1l111_l1_ (u"ࠨࠩ屴"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭屵"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ屶"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ屷"),l1l111_l1_ (u"ࠬ࠭屸"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屹"),l1lllll_l1_+l1l111_l1_ (u"ࠧศๆิส๏ู๊สࠩ屺"),l111l1_l1_+l1l111_l1_ (u"ࠨࠩ屻"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屼"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้ืววฮฬࠫ屽"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ屾"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屿"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฬุๅา࠭岀"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ岁"),144)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岂"),l1lllll_l1_+l1l111_l1_ (u"ࠩส่็฻๊าหࠪ岃"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶࠫ岄"),144,l1l111_l1_ (u"ࠫࠬ岅"),l1l111_l1_ (u"ࠬ࠭岆"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ岇"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岈"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ัฮฬืวหࠢํ์ฯ๐่ษࠩ岉"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡩࡸ࡭ࡩ࡫࡟ࡣࡷ࡬ࡰࡩ࡫ࡲࠨ岊"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岋"),l1lllll_l1_+l1l111_l1_ (u"๊ࠫิสศำสฮࠥอไษำ้ห๊าࠧ岌"),l1l111_l1_ (u"ࠬ࠭岍"),290)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ岎"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ岏"),l1l111_l1_ (u"ࠨࠩ岐"),9999)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岑"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะฺࠠำห๎ฮ࠭岒"),l1l111_l1_ (u"ࠫࠬ岓"),147)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岔"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣวั์ศ๋หࠪ岕"),l1l111_l1_ (u"ࠧࠨ岖"),148)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岗"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࡀࠠศใ็หู๊ࠦาสํอࠬ岘"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁๆ๐ไๆࠩ岙"),144)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岚"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢสะ๋ฮ๊สࠩ岛"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽࡮ࡱࡹ࡭ࡪ࠭岜"),144)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岝"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭岞"),l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ岟"),144)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岠"),l1lllll_l1_+l1l111_l1_ (u"ࠫอำห࠻่ࠢืู้ไศฬࠣ฽ึฮ๊สࠩ岡"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิๆึ่ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ岢"),144)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岣"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯࠦวอ่ห๎ฮ࠭岤"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ࡶࡩࡷ࡯ࡥࡴࠨࡶࡴࡂࡋࡧࡊࡓࡄࡻࡂࡃࠧ岥"),144)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岦"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢๆหึะ่็ࠩ岧"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ้วาฬ๋๊ࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ岨"),144)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岩"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอ࠽ࠤำ฽ศสࠢส่๊ืฬฺ์ฬࠫ岪"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ไ้หฮ࠱ใาส็หฦ࠱วๅใูหห๐ษࠬะฺฬฮ࠱วๅฮ่฽ฮࠬࡳࡱ࠿ࡆࡅࡎ࡙ࡁࡩࡃࡅࠫ岫"),144)
	return
def l111l1llll11_l1_(url,name,l11l_l1_):
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岬"),l1lllll_l1_+l1l111_l1_ (u"ࠩࡆࡌࡓࡒ࠺ࠡࠢࠪ岭")+name,url,144,l11l_l1_)
	return
def l111ll11llll_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭หฯࠫࡹࡰ࠾ࡇࡪࡎࡆࡇࡑ࠾࠿ࠪ岮"))
	return
def l111ll1l111l_l1_():
	l1lll11_l1_(l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡺࡶࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭岯"))
	return
def PLAY(url,type):
	url = url.split(l1l111_l1_ (u"ࠬࠬࠧ岰"),1)[0]
	import ll_l1_
	ll_l1_.l1l_l1_([url],l1ll1_l1_,type,url)
	return
def l111ll11l111_l1_(yccc,url,index):
	level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ岱"))
	l111l1lll1l1_l1_,l111ll11l11l_l1_ = [],[]
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪ࠭岲") in url: l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡆࡩࡴࡪࡱࡱࡷࠬࡣࠢ岳"))
	if l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ岴") in url: l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡨࡩࡣ࡜ࠩࡲࡲࡗ࡫ࡳࡱࡱࡱࡷࡪࡘࡥࡤࡧ࡬ࡺࡪࡪࡃࡰ࡯ࡰࡥࡳࡪࡳࠨ࡟ࠥ岵"))
	if level==l1l111_l1_ (u"ࠫ࠶࠭岶"): l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡣࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶࡤࡦࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ岷"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡤࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡳࡶ࡮ࡳࡡࡳࡻࡆࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ岸"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡥࡦࡧࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡦࡨࡳࠨ࡟ࠥ岹"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡦࡰࡷࡶ࡮࡫ࡳࠨ࡟ࠥ岺"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡧࡨࡩ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞࡝࠶ࡡࡠ࠭ࡧࡶ࡫ࡧࡩࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ岻"))
	l111ll1l1l11_l1_,yddd,l111ll111lll_l1_ = l111l1lll111_l1_(yccc,l1l111_l1_ (u"ࠪࠫ岼"),l111l1lll1l1_l1_)
	if level==l1l111_l1_ (u"ࠫ࠶࠭岽") and l111ll1l1l11_l1_:
		if len(yddd)>1 and l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ岾") not in url:
			for zz in range(len(yddd)):
				l111ll11111l_l1_ = str(zz)
				l111l1lll1l1_l1_ = []
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ岿")+l111ll11111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡶࡪࡲ࡯ࡢࡦࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝ࠣ峀"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ峁")+l111ll11111l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩ࠭࡝ࠣ峂"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ峃")+l111ll11111l_l1_+l1l111_l1_ (u"ࠦࡢࠨ峄"))
				succeeded,item,l1111ll1_l1_ = l111l1lll111_l1_(yddd,l1l111_l1_ (u"ࠬ࠭峅"),l111l1lll1l1_l1_)
				if succeeded: l111ll11l11l_l1_.append([item,url,l1l111_l1_ (u"࠭࠲࠻࠼ࠪ峆")+l111ll11111l_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ峇")])
			l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡦࡧࡨࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞ࠤ峈"))
			succeeded,item,l1111ll1_l1_ = l111l1lll111_l1_(yccc,l1l111_l1_ (u"ࠩࠪ峉"),l111l1lll1l1_l1_)
			if succeeded and l111ll11l11l_l1_ and l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠩ峊") in list(item.keys()):
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ峋")
				l111ll11l11l_l1_.append([item,l1ll1ll_l1_,l1l111_l1_ (u"ࠬ࠷࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ峌")])
	return yddd,l111ll1l1l11_l1_,l111ll11l11l_l1_,l111ll111lll_l1_
def l111l1ll1l1l_l1_(yccc,yddd,url,index):
	level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ峍"))
	l111l1lll1l1_l1_,l111ll11l1l1_l1_ = [],[]
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峎"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ峏")+l111ll11111l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ峐"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜࠳ࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ峑"))
	if l1l111_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࠪ峒") in url: l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ峓"))
	elif l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡹࡥࡢࡴࡦ࡬ࠬ峔") in url: l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峕"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ峖")+l111ll11111l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峗"))
	if l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ峘") in url or (l1l111_l1_ (u"ࠫ࠴ࡹࡨࡰࡴࡷࡷࠬ峙") in url and l1l111_l1_ (u"ࠬ࠵ࡳࡩࡱࡵࡸࡸ࠵ࠧ峚") not in url):
		l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟ࠧ峛")+l111ll11111l_l1_+l1l111_l1_ (u"ࠢ࡞࡝ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡪࡪ࡫ࡤࡇ࡫࡯ࡸࡪࡸࡃࡩ࡫ࡳࡆࡦࡸࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峜"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡧࡨࡩࡡࠢ峝")+l111ll11111l_l1_+l1l111_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ峞"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡩࡪࡤ࡜ࠤ峟")+l111ll11111l_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡦࡺࡳࡥࡳࡪࡡࡣ࡮ࡨࡘࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ峠"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡤࡥࡦ࡞ࠦ峡")+l111ll11111l_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ峢"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠࠨ峣")+l111ll11111l_l1_+l1l111_l1_ (u"ࠣ࡟ࠥ峤"))
	l111ll1l11l1_l1_,yeee,l111ll111ll1_l1_ = l111l1lll111_l1_(yddd,l1l111_l1_ (u"ࠩࠪ峥"),l111l1lll1l1_l1_)
	if level==l1l111_l1_ (u"ࠪ࠶ࠬ峦") and l111ll1l11l1_l1_:
		if len(yeee)>1:
			for zz in range(len(yeee)):
				index2 = str(zz)
				l111l1lll1l1_l1_ = []
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ峧")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ峨"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ峩")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡆࡥࡷࡪࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟ࠥ峪"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ峫")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡦࡸࡤࡴࠩࡠࠦ峬"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ峭")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞ࠤ峮"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ峯")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠࠦ峰"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ峱")+index2+l1l111_l1_ (u"ࠣ࡟ࠥ峲"))
				succeeded,item,l1111ll1_l1_ = l111l1lll111_l1_(yeee,l1l111_l1_ (u"ࠩࠪ峳"),l111l1lll1l1_l1_)
				if succeeded: l111ll11l1l1_l1_.append([item,url,l1l111_l1_ (u"ࠪ࠷࠿ࡀࠧ峴")+l111ll11111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ峵")+index2+l1l111_l1_ (u"ࠬࡀ࠺࠱ࠩ島")])
			l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡥࡦࡧ࡟࠵ࡣ࡛ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࡠ࠷࡝ࠣ峷"))
			l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡦࡧࡨࡠ࠷࡝ࠣ峸"))
			succeeded,item,l1111ll1_l1_ = l111l1lll111_l1_(yddd,l1l111_l1_ (u"ࠨࠩ峹"),l111l1lll1l1_l1_)
			if succeeded and l111ll11l1l1_l1_ and l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭峺") in list(item.keys()):
				l111ll11l1l1_l1_.append([item,url,l1l111_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ峻")])
	return yeee,l111ll1l11l1_l1_,l111ll11l1l1_l1_,l111ll111ll1_l1_
def l111l1llll1l_l1_(yccc,yeee,url,index):
	level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = index.split(l1l111_l1_ (u"ࠫ࠿ࡀࠧ峼"))
	l111l1lll1l1_l1_,l111l1llllll_l1_ = [],[]
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ峽")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡹࡩࡷࡺࡩࡤࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ峾"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠࠨ峿")+index2+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ崀"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛ࠣ崁")+index2+l1l111_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡵࡩࡪࡲࡓࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崂"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡾ࡫ࡥࡦ࡝ࠥ崃")+index2+l1l111_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崄"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡦࡧࡨ࡟ࠧ崅")+index2+l1l111_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崆"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡࠢ崇")+index2+l1l111_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡧࡻࡴࡦࡴࡤࡦࡦࡖ࡬ࡪࡲࡦࡄࡱࡱࡸࡪࡴࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崈"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崉")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩࡡࡳࡦࡶࠫࡢࠨ崊"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崋")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崌"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崍"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡨࡩࡪࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡧࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崎"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡩࡪ࡫࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡘ࡬ࡨࡪࡵࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ崏"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡪ࡫ࡥ࡜ࠤ崐")+index2+l1l111_l1_ (u"ࠦࡢࡡࠧࡳࡧࡨࡰࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ崑"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡥࡦࡧ࡞ࠦ崒")+index2+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ崓"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡧࡨࡩࠧ崔"))
	l111ll1l1ll1_l1_,yfff,l111lll11111_l1_ = l111l1lll111_l1_(yeee,l1l111_l1_ (u"ࠨࠩ崕"),l111l1lll1l1_l1_)
	if level==l1l111_l1_ (u"ࠩ࠶ࠫ崖") and l111ll1l1ll1_l1_:
		if len(yfff)>0:
			for zz in range(len(yfff)):
				l111ll1111ll_l1_ = str(zz)
				l111l1lll1l1_l1_ = []
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽ࡫࡬ࡦ࡜ࠤ崗")+l111ll1111ll_l1_+l1l111_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ崘"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡦࡧࡨ࡞ࠦ崙")+l111ll1111ll_l1_+l1l111_l1_ (u"ࠨ࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ崚"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡨࡩࡪࡠࠨ崛")+l111ll1111ll_l1_+l1l111_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ崜"))
				l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡪ࡫࡬࡛ࠣ崝")+l111ll1111ll_l1_+l1l111_l1_ (u"ࠥࡡࠧ崞"))
				succeeded,item,l1111ll1_l1_ = l111l1lll111_l1_(yfff,l1l111_l1_ (u"ࠫࠬ崟"),l111l1lll1l1_l1_)
				if succeeded: l111l1llllll_l1_.append([item,url,l1l111_l1_ (u"ࠬ࠺࠺࠻ࠩ崠")+l111ll11111l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ崡")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ崢")+l111ll1111ll_l1_])
	return yfff,l111ll1l1ll1_l1_,l111l1llllll_l1_,l111lll11111_l1_
def l111l1lll111_l1_(l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_,l111ll111111_l1_):
	yccc,l1l1l11lll1l_l1_ = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	yddd,l1l1l11lll1l_l1_ = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	yeee,l1l1l11lll1l_l1_ = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	yfff,l1l1l11lll1l_l1_ = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	item,yrender = l1l1l11l1l1l_l1_,l1l1l11lll1l_l1_
	count = len(l111ll111111_l1_)
	for l1l11l111l_l1_ in range(count):
		try:
			out = eval(l111ll111111_l1_[l1l11l111l_l1_])
			return True,out,l1l11l111l_l1_+1
		except: pass
	return False,l1l111_l1_ (u"ࠨࠩ崣"),0
def l1lll11_l1_(url,index=l1l111_l1_ (u"ࠩࠪ崤"),data=l1l111_l1_ (u"ࠪࠫ崥")):
	l111ll11l11l_l1_,l111ll11l1l1_l1_,l111l1llllll_l1_ = [],[],[]
	if l1l111_l1_ (u"ࠫ࠿ࡀࠧ崦") not in index: index = l1l111_l1_ (u"ࠬ࠷࠺࠻࠲࠽࠾࠵ࡀ࠺࠱ࠩ崧")
	level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = index.split(l1l111_l1_ (u"࠭࠺࠻ࠩ崨"))
	if level==l1l111_l1_ (u"ࠧ࠵ࠩ崩"): level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = l1l111_l1_ (u"ࠨ࠳ࠪ崪"),l111ll11111l_l1_,index2,l111ll1111ll_l1_
	data = data.replace(l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭崫"),l1l111_l1_ (u"ࠪࠫ崬"))
	html,yccc,l1l11llll_l1_ = l111ll11l1ll_l1_(url,data)
	index = level+l1l111_l1_ (u"ࠫ࠿ࡀࠧ崭")+l111ll11111l_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠨ崮")+index2+l1l111_l1_ (u"࠭࠺࠻ࠩ崯")+l111ll1111ll_l1_
	if level in [l1l111_l1_ (u"ࠧ࠲ࠩ崰"),l1l111_l1_ (u"ࠨ࠴ࠪ崱"),l1l111_l1_ (u"ࠩ࠶ࠫ崲")]:
		yddd,l111ll1l1l11_l1_,l111ll11l11l_l1_,l111ll111lll_l1_ = l111ll11l111_l1_(yccc,url,index)
		if not l111ll1l1l11_l1_: return
		l1lllll11l_l1_ = len(l111ll11l11l_l1_)
		if l1lllll11l_l1_<2:
			if level==l1l111_l1_ (u"ࠪ࠵ࠬ崳"): level = l1l111_l1_ (u"ࠫ࠷࠭崴")
			l111ll11l11l_l1_ = []
	index = level+l1l111_l1_ (u"ࠬࡀ࠺ࠨ崵")+l111ll11111l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ崶")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ崷")+l111ll1111ll_l1_
	if level in [l1l111_l1_ (u"ࠨ࠴ࠪ崸"),l1l111_l1_ (u"ࠩ࠶ࠫ崹")]:
		yeee,l111ll1l11l1_l1_,l111ll11l1l1_l1_,l111ll111ll1_l1_ = l111l1ll1l1l_l1_(yccc,yddd,url,index)
		if not l111ll1l11l1_l1_: return
		l1ll1l1l1l_l1_ = len(l111ll11l1l1_l1_)
		if l1ll1l1l1l_l1_<2:
			if level==l1l111_l1_ (u"ࠪ࠶ࠬ崺"): level = l1l111_l1_ (u"ࠫ࠸࠭崻")
			l111ll11l1l1_l1_ = []
	index = level+l1l111_l1_ (u"ࠬࡀ࠺ࠨ崼")+l111ll11111l_l1_+l1l111_l1_ (u"࠭࠺࠻ࠩ崽")+index2+l1l111_l1_ (u"ࠧ࠻࠼ࠪ崾")+l111ll1111ll_l1_
	if level in [l1l111_l1_ (u"ࠨ࠵ࠪ崿")]:
		yfff,l111ll1l1ll1_l1_,l111l1llllll_l1_,l111lll11111_l1_ = l111l1llll1l_l1_(yccc,yeee,url,index)
		if not l111ll1l1ll1_l1_: return
		l1ll1l1ll1_l1_ = len(l111l1llllll_l1_)
	for item,url,index in l111ll11l11l_l1_+l111ll11l1l1_l1_+l111l1llllll_l1_:
		l1ll111ll11l_l1_ = l111l1lll1ll_l1_(item,url,index)
	return
def l111l1lll1ll_l1_(item,url=l1l111_l1_ (u"ࠩࠪ嵀"),index=l1l111_l1_ (u"ࠪࠫ嵁")):
	if l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵂") in index: level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = index.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵃"))
	else: level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = l1l111_l1_ (u"࠭࠱ࠨ嵄"),l1l111_l1_ (u"ࠧ࠱ࠩ嵅"),l1l111_l1_ (u"ࠨ࠲ࠪ嵆"),l1l111_l1_ (u"ࠩ࠳ࠫ嵇")
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_,l111ll1lll1l_l1_ = l111lll111l1_l1_(item)
	l1lll1lll1l1_l1_ = l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࡃࠬ嵈") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠫ࠴ࡹࡴࡳࡧࡤࡱࡸࡅࠧ嵉") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࡁࠪ嵊") in l1ll1ll_l1_
	l1lll1lll111_l1_ = l1l111_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࡁࠪ嵋") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳࡀࠩ嵌") in l1ll1ll_l1_
	if l1lll1lll1l1_l1_ or l1lll1lll111_l1_: l1ll1ll_l1_ = url
	l1lll1lll1l1_l1_ = l1l111_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠪ嵍") not in l1ll1ll_l1_ and l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ嵎") not in l1ll1ll_l1_
	l1lll1lll111_l1_ = l1l111_l1_ (u"ࠪ࠳࡬ࡧ࡭ࡪࡰࡪࠫ嵏") not in l1ll1ll_l1_  and l1l111_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡷࡹࡵࡲࡦࡨࡵࡳࡳࡺࠧ嵐") not in l1ll1ll_l1_
	if index[0:5]==l1l111_l1_ (u"ࠬ࠹࠺࠻࠲࠽࠾ࠬ嵑") and l1lll1lll1l1_l1_ and l1lll1lll111_l1_: l1ll1ll_l1_ = url
	if l1l111_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴࡭ࡵࡪࡦࡨࡃࡰ࡫ࡹ࠾ࠩ嵒") in url or l1l111_l1_ (u"ࠧ࠰ࡩࡤࡱ࡮ࡴࡧࠨ嵓") in l1ll1ll_l1_:
		level,l111ll11111l_l1_,index2,l111ll1111ll_l1_ = l1l111_l1_ (u"ࠨ࠳ࠪ嵔"),l1l111_l1_ (u"ࠩ࠳ࠫ嵕"),l1l111_l1_ (u"ࠪ࠴ࠬ嵖"),l1l111_l1_ (u"ࠫ࠵࠭嵗")
		index = l1l111_l1_ (u"ࠬ࠭嵘")
	l1l11llll_l1_ = l1l111_l1_ (u"࠭ࠧ嵙")
	if l1l111_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡢࡳࡱࡺࡷࡪ࠭嵚") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ嵛") in l1ll1ll_l1_ or l1l111_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ嵜") in url:
		data = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ嵝"))
		if data.count(l1l111_l1_ (u"ࠫ࠿ࡀ࠺ࠨ嵞"))==4:
			l111ll1l1l1l_l1_,key,l111ll1l1111_l1_,l111ll11ll1l_l1_,token = data.split(l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ嵟"))
			l1l11llll_l1_ = l111ll1l1l1l_l1_+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ嵠")+key+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ嵡")+l111ll1l1111_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ嵢")+l111ll11ll1l_l1_+l1l111_l1_ (u"ࠩ࠽࠾࠿࠭嵣")+l111ll1lll1l_l1_
			if l1l111_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ嵤") in url and not l1ll1ll_l1_: l1ll1ll_l1_ = url
			else: l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡱࡥࡺ࠿ࠪ嵥")+key
	if not title:
		global l111l1lllll1_l1_
		l111l1lllll1_l1_ += 1
		title = l1l111_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠࠨ嵦")+str(l111l1lllll1_l1_)
		index = l1l111_l1_ (u"࠭࠳ࠨ嵧")+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嵨")+l111ll11111l_l1_+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵩")+index2+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵪")+l111ll1111ll_l1_
	if not succeeded: return False
	elif l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡓࡽࡻࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嵫") in str(item): return False
	elif l1l111_l1_ (u"ࠫ࠴ࡧࡢࡰࡷࡷࠫ嵬") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"ࠬ࠵ࡣࡰ࡯ࡰࡹࡳ࡯ࡴࡺࠩ嵭") in l1ll1ll_l1_: return False
	elif l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ嵮") in list(item.keys()) or l1l111_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭嵯") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嵰")+l111ll11111l_l1_+l1l111_l1_ (u"ࠩ࠽࠾ࠬ嵱")+index2+l1l111_l1_ (u"ࠪ࠾࠿࠭嵲")+l111ll1111ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嵳"),l1lllll_l1_+l1l111_l1_ (u"ࠬࡀ࠺ࠡࠩ嵴")+l1l111_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ嵵"),l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࠨ嵶") in l1ll1ll_l1_:
		title = l1l111_l1_ (u"ࠨ࠼࠽ࠤࠬ嵷")+title
		index = l1l111_l1_ (u"ࠩ࠶ࠫ嵸")+l1l111_l1_ (u"ࠪ࠾࠿࠭嵹")+l111ll11111l_l1_+l1l111_l1_ (u"ࠫ࠿ࡀࠧ嵺")+index2+l1l111_l1_ (u"ࠬࡀ࠺ࠨ嵻")+l111ll1111ll_l1_
		url = url.replace(l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ嵼"),l1l111_l1_ (u"ࠧࠨ嵽"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ嵾"),l1lllll_l1_+title,url,145,l1l111_l1_ (u"ࠩࠪ嵿"),index,l1l111_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ嶀"))
	elif l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ嶁") in url and not l1ll1ll_l1_:
		index = l1l111_l1_ (u"ࠬ࠹ࠧ嶂")+l1l111_l1_ (u"࠭࠺࠻ࠩ嶃")+l111ll11111l_l1_+l1l111_l1_ (u"ࠧ࠻࠼ࠪ嶄")+index2+l1l111_l1_ (u"ࠨ࠼࠽ࠫ嶅")+l111ll1111ll_l1_
		title = l1l111_l1_ (u"ࠩ࠽࠾ࠥ࠭嶆")+title
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶇"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif l1l111_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࠬ嶈") in l1ll1ll_l1_ and url==l111l1_l1_:
		title = l1l111_l1_ (u"ࠬࡀ࠺ࠡࠩ嶉")+title
		index = l1l111_l1_ (u"࠭࠲࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ嶊")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶋"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	elif not l1ll1ll_l1_ and l1l111_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ嶌") in str(item):
		title = l1l111_l1_ (u"ࠩ࠽࠾ࠥ࠭嶍")+title
		index = l1l111_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ嶎")
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嶏"),l1lllll_l1_+title,url,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嶐") in str(item):
		addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嶑"),l1lllll_l1_+title,l1l111_l1_ (u"ࠧࠨ嶒"),9999)
	elif l111ll1l1lll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭嶓"),l1lllll_l1_+l111ll1l1lll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ嶔") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶕"),l1lllll_l1_+l1l111_l1_ (u"ࠫࡑࡏࡓࡕࠩ嶖")+count+l1l111_l1_ (u"ࠬࡀࠠࠡࠩ嶗")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹ࠯ࠨ嶘") in l1ll1ll_l1_:
		l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ嶙"),1)[0]
		addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嶚"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1llll11_l1_)
	elif l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ嶛") in l1ll1ll_l1_:
		if l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ嶜") in l1ll1ll_l1_ and count:
			l111ll1l11ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ嶝"),1)[1]
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ嶞")+l111ll1l11ll_l1_
			index = l1l111_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠶࠺࠻࠲ࠪ嶟")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嶠"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡎࡌࡗ࡙࠭嶡")+count+l1l111_l1_ (u"ࠩ࠽ࠤࠥ࠭嶢")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
		else:
			l1ll1ll_l1_ = l1ll1ll_l1_.split(l1l111_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ嶣"),1)[0]
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嶤"),l1lllll_l1_+title,l1ll1ll_l1_,143,l1ll1l_l1_,l1l1llll11_l1_)
	elif l1l111_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ嶥") in l1ll1ll_l1_ or l1l111_l1_ (u"࠭࠯ࡤ࠱ࠪ嶦") in l1ll1ll_l1_ or (l1l111_l1_ (u"ࠧ࠰ࡂࠪ嶧") in l1ll1ll_l1_ and l1ll1ll_l1_.count(l1l111_l1_ (u"ࠨ࠱ࠪ嶨"))==3):
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嶩"),l1lllll_l1_+l1l111_l1_ (u"ࠪࡇࡍࡔࡌࠨ嶪")+count+l1l111_l1_ (u"ࠫ࠿ࠦࠠࠨ嶫")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	elif l1l111_l1_ (u"ࠬ࠵ࡵࡴࡧࡵ࠳ࠬ嶬") in l1ll1ll_l1_:
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶭"),l1lllll_l1_+l1l111_l1_ (u"ࠧࡖࡕࡈࡖࠬ嶮")+count+l1l111_l1_ (u"ࠨ࠼ࠣࠤࠬ嶯")+title,l1ll1ll_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1ll1ll_l1_: l1ll1ll_l1_ = url
		title = l1l111_l1_ (u"ࠩ࠽࠾ࠥ࠭嶰")+title
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嶱"),l1lllll_l1_+title,l1ll1ll_l1_,144,l1ll1l_l1_,index,l1l11llll_l1_)
	return True
def l111lll111l1_l1_(item):
	succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_,token = False,l1l111_l1_ (u"ࠫࠬ嶲"),l1l111_l1_ (u"ࠬ࠭嶳"),l1l111_l1_ (u"࠭ࠧ嶴"),l1l111_l1_ (u"ࠧࠨ嶵"),l1l111_l1_ (u"ࠨࠩ嶶"),l1l111_l1_ (u"ࠩࠪ嶷"),l1l111_l1_ (u"ࠪࠫ嶸"),l1l111_l1_ (u"ࠫࠬ嶹")
	if not isinstance(item,dict): return succeeded,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_,token
	for l111ll11lll1_l1_ in list(item.keys()):
		yrender = item[l111ll11lll1_l1_]
		if isinstance(yrender,dict): break
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ嶺"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫࡷ࡯ࡣࡩࡎ࡬ࡷࡹࡎࡥࡢࡦࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ嶻"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩ࡫ࡩࡦࡪ࡬ࡪࡰࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ嶼"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡹࡳࡶ࡬ࡢࡻࡤࡦࡱ࡫ࡔࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ嶽"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࡔࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ嶾"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ嶿"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ巀"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠬࡣࠢ巁"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶࡨࡼࡹ࠭࡝࡜ࠩࡵࡹࡳࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࠨ巂"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟ࠥ巃"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ巄"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡴࡨࡩࡱ࡝ࡡࡵࡥ࡫ࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡸ࡬ࡨࡪࡵࡉࡥࠩࡠࠦ巅"))
	succeeded,title,l1111ll1_l1_ = l111l1lll111_l1_(item,yrender,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ巆"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巇"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡤࡴ࡮࡛ࡲ࡭ࠩࡠࠦ巈"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡣࡳ࡭࡚ࡸ࡬ࠨ࡟ࠥ巉"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巊"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ巋"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ巌"))
	succeeded,l1ll1ll_l1_,l1111ll1_l1_ = l111l1lll111_l1_(item,yrender,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ巍"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ巎"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡷ࡫ࡥ࡭࡙ࡤࡸࡨ࡮ࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧ࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ巏"))
	succeeded,l1ll1l_l1_,l1111ll1_l1_ = l111l1lll111_l1_(item,yrender,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸࠬࡣࠢ巐"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ巑"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡄࡲࡸࡹࡵ࡭ࡑࡣࡱࡩࡱࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ巒"))
	succeeded,count,l1111ll1_l1_ = l111l1lll111_l1_(item,yrender,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠤࡼࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ巓"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠥࡽࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡘ࡮ࡳࡥࡔࡶࡤࡸࡺࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ巔"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠦࡾࡸࡥ࡯ࡦࡨࡶࡠ࠭࡬ࡦࡰࡪࡸ࡭࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ巕"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠧࡿࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡤࡱࡱࠫࡢࡡࠧࡪࡥࡲࡲ࡙ࡿࡰࡦࠩࡠࠦ巖"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠨࡹࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡓࡻ࡫ࡲ࡭ࡣࡼࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡔࡪ࡯ࡨࡗࡹࡧࡴࡶࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡴࡶࡼࡰࡪ࠭࡝ࠣ巗"))
	succeeded,l1l1llll11_l1_,l1111ll1_l1_ = l111l1lll111_l1_(item,yrender,l111l1lll1l1_l1_)
	l111l1lll1l1_l1_ = []
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠢࡺࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡅࡲࡱࡲࡧ࡮ࡥࠩࡠ࡟ࠬࡺ࡯࡬ࡧࡱࠫࡢࠨ巘"))
	l111l1lll1l1_l1_.append(l1l111_l1_ (u"ࠣࡻࡵࡩࡳࡪࡥࡳ࡝ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠬࡣ࡛ࠨࡶࡲ࡯ࡪࡴࠧ࡞ࠤ巙"))
	succeeded,token,l1111ll1_l1_ = l111l1lll111_l1_(item,yrender,l111l1lll1l1_l1_)
	if l1l111_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ巚") in l1l1llll11_l1_: l1l1llll11_l1_,l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠪࠫ巛"),l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ巜")
	if l1l111_l1_ (u"๋ࠬศศึิࠫ川") in l1l1llll11_l1_: l1l1llll11_l1_,l111ll1l1lll_l1_ = l1l111_l1_ (u"࠭ࠧ州"),l1l111_l1_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ巟")
	if l1l111_l1_ (u"ࠨࡤࡤࡨ࡬࡫ࡳࠨ巠") in list(yrender.keys()):
		l111ll1ll1ll_l1_ = str(yrender[l1l111_l1_ (u"ࠩࡥࡥࡩ࡭ࡥࡴࠩ巡")])
		if l1l111_l1_ (u"ࠪࡊࡷ࡫ࡥࠡࡹ࡬ࡸ࡭ࠦࡁࡥࡵࠪ巢") in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠫࠩࡀࠠࠡࠩ巣")
		if l1l111_l1_ (u"ࠬࡒࡉࡗࡇࠪ巤") in l111ll1ll1ll_l1_: l111ll1l1lll_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ工")
		if l1l111_l1_ (u"ࠧࡃࡷࡼࠫ左") in l111ll1ll1ll_l1_ or l1l111_l1_ (u"ࠨࡔࡨࡲࡹ࠭巧") in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠩࠧࠨ࠿ࠦࠠࠨ巨")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡸ๊ࠫฮวีำࠪ巩")) in l111ll1ll1ll_l1_: l111ll1l1lll_l1_ = l1l111_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ巪")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡺ࠭ิาษฤࠫ巫")) in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ巬")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡵࠨษึฮหาวาࠩ巭")) in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ差")
		if l111l1l1l11_l1_(l1l111_l1_ (u"ࡷࠪษ฾๊ว็ษอࠫ巯")) in l111ll1ll1ll_l1_: l111ll11ll11_l1_ = l1l111_l1_ (u"ࠪࠨ࠿ࠦࠠࠨ巰")
	l1ll1ll_l1_ = escapeUNICODE(l1ll1ll_l1_)
	if l1ll1ll_l1_ and l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ己") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l1l111_l1_ (u"ࠬࡅࠧ已"))[0]
	if  l1ll1l_l1_ and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࠫ巳") not in l1ll1l_l1_: l1ll1l_l1_ = l1l111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ巴")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l111ll11ll11_l1_: title = l111ll11ll11_l1_+title
	l1l1llll11_l1_ = l1l1llll11_l1_.replace(l1l111_l1_ (u"ࠨ࠮ࠪ巵"),l1l111_l1_ (u"ࠩࠪ巶"))
	count = count.replace(l1l111_l1_ (u"ࠪ࠰ࠬ巷"),l1l111_l1_ (u"ࠫࠬ巸"))
	count = re.findall(l1l111_l1_ (u"ࠬࡢࡤࠬࠩ巹"),count)
	if count: count = count[0]
	else: count = l1l111_l1_ (u"࠭ࠧ巺")
	return True,title,l1ll1ll_l1_,l1ll1l_l1_,count,l1l1llll11_l1_,l111ll1l1lll_l1_,l111ll11ll11_l1_,token
def l111ll11l1ll_l1_(url,data=l1l111_l1_ (u"ࠧࠨ巻"),request=l1l111_l1_ (u"ࠨࠩ巼")):
	if request==l1l111_l1_ (u"ࠩࠪ巽"): request = l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ巾")
	l11l1l11ll_l1_ = l1l1ll11l_l1_()
	l1ll1ll1l_l1_ = {l1l111_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ巿"):l11l1l11ll_l1_,l1l111_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ帀"):l1l111_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ币")}
	global settings
	if not data: data = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ市"))
	if data.count(l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ布"))==4: l111ll1l1l1l_l1_,key,l111ll1l1111_l1_,l111ll11ll1l_l1_,token = data.split(l1l111_l1_ (u"ࠩ࠽࠾࠿࠭帄"))
	else: l111ll1l1l1l_l1_,key,l111ll1l1111_l1_,l111ll11ll1l_l1_,token = l1l111_l1_ (u"ࠪࠫ帅"),l1l111_l1_ (u"ࠫࠬ帆"),l1l111_l1_ (u"ࠬ࠭帇"),l1l111_l1_ (u"࠭ࠧ师"),l1l111_l1_ (u"ࠧࠨ帉")
	l1l11llll_l1_ = {l1l111_l1_ (u"ࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ帊"):{l1l111_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ帋"):{l1l111_l1_ (u"ࠥ࡬ࡱࠨ希"):l1l111_l1_ (u"ࠦࡦࡸࠢ帍"),l1l111_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ帎"):l1l111_l1_ (u"ࠨࡗࡆࡄࠥ帏"),l1l111_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ帐"):l111ll1l1111_l1_}}}
	if url==l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ帑") or l1l111_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ帒") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡵࡩࡪࡲ࠯ࡳࡧࡨࡰࡤࡽࡡࡵࡥ࡫ࡣࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭帓")+l1l111_l1_ (u"ࠫࡄࡱࡥࡺ࠿ࠪ帔")+key
		l1l11llll_l1_[l1l111_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫ࡐࡢࡴࡤࡱࡸ࠭帕")] = l111ll1l1l1l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"࠭ࡐࡐࡕࡗࠫ帖"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ帗"))
	elif l1l111_l1_ (u"ࠨ࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭帘") in url:
		url = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ帙")+key
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ帚"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠹ࡲࡥࠩ帛"))
	elif l1l111_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ帜") in url and l111ll1l1l1l_l1_:
		l1l11llll_l1_[l1l111_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ帝")] = token
		l1l11llll_l1_[l1l111_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ帞")][l1l111_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࠨ帟")][l1l111_l1_ (u"ࠩࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠧ帠")] = l111ll1l1l1l_l1_
		l1l11llll_l1_ = str(l1l11llll_l1_)
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ帡"),url,l1l11llll_l1_,l1ll1ll1l_l1_,True,True,l1l111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠺ࡴࡩࠩ帢"))
	elif l1l111_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭帣") in url and l111ll11ll1l_l1_:
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯ࡑࡥࡲ࡫ࠧ帤"):l1l111_l1_ (u"ࠧ࠲ࠩ帥"),l1l111_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱࡛࡫ࡲࡴ࡫ࡲࡲࠬ带"):l111ll1l1111_l1_})
		l1ll1ll1l_l1_.update({l1l111_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ帧"):l1l111_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅ࠾ࠩ帨")+l111ll11ll1l_l1_})
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ帩"),url,l1l111_l1_ (u"ࠬ࠭帪"),l1ll1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ師"),l1l111_l1_ (u"ࠧࠨ帬"),l1l111_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠸ࡸ࡭࠭席"))
	else:
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭帮"),url,l1l111_l1_ (u"ࠪࠫ帯"),l1ll1ll1l_l1_,l1l111_l1_ (u"ࠫࠬ帰"),l1l111_l1_ (u"ࠬ࠭帱"),l1l111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠷ࡶ࡫ࠫ帲"))
	html = response.content
	tmp = re.findall(l1l111_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ帳"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠨࠤࡦࡺࡪࡸࠢ࠯ࠬࡂࠦࡻࡧ࡬ࡶࡧࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ帴"),html,re.DOTALL|re.I)
	if tmp: l111ll1l1111_l1_ = tmp[0]
	tmp = re.findall(l1l111_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ帵"),html,re.DOTALL|re.I)
	if tmp: l111ll1l1l1l_l1_ = tmp[0]
	cookies = response.cookies
	if l1l111_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ帶") in list(cookies.keys()): l111ll11ll1l_l1_ = cookies[l1l111_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ帷")]
	l1l1l1111_l1_ = l111ll1l1l1l_l1_+l1l111_l1_ (u"ࠬࡀ࠺࠻ࠩ常")+key+l1l111_l1_ (u"࠭࠺࠻࠼ࠪ帹")+l111ll1l1111_l1_+l1l111_l1_ (u"ࠧ࠻࠼࠽ࠫ帺")+l111ll11ll1l_l1_+l1l111_l1_ (u"ࠨ࠼࠽࠾ࠬ帻")+token
	if request==l1l111_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ帼") and l1l111_l1_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ帽") in html:
		l11l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡠࡠࠨࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠨ࡜࡞ࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭帾"),html,re.DOTALL)
		if not l11l1l1111_l1_: l11l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠢࡀࠤ࠭ࢁ࠮ࠫࡁࢀ࠭ࡀ࠭帿"),html,re.DOTALL)
		l111ll1ll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"࠭ࡳࡵࡴࠪ幀"),l11l1l1111_l1_[0])
	elif request==l1l111_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ幁") and l1l111_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡋࡺ࡯ࡤࡦࡆࡤࡸࡦ࠭幂") in html:
		l11l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ幃"),html,re.DOTALL)
		l111ll1ll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠪࡷࡹࡸࠧ幄"),l11l1l1111_l1_[0])
	elif l1l111_l1_ (u"ࠫࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ幅") not in html: l111ll1ll1l1_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠬࡹࡴࡳࠩ幆"),html)
	else: l111ll1ll1l1_l1_ = l1l111_l1_ (u"࠭ࠧ幇")
	if 0:
		yccc = str(l111ll1ll1l1_l1_)
		if kodi_version>18.99: yccc = yccc.encode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ幈"))
		open(l1l111_l1_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰࠱࠲ࡨࡱࡦࡪ࠮ࡥࡣࡷࠫ幉"),l1l111_l1_ (u"ࠩࡺࡦࠬ幊")).write(yccc)
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ幋"),l1l1l1111_l1_)
	return html,l111ll1ll1l1_l1_,l1l1l1111_l1_
def l111ll1llll1_l1_(url,index):
	search = l1llll1_l1_()
	if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭幌"),l1l111_l1_ (u"ࠬ࠱ࠧ幍"))
	l1lllll1_l1_ = url+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲࡷࡨࡶࡾࡃࠧ幎")+search
	l1lll11_l1_(l1lllll1_l1_,index)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠧࠡࠩ幏"),l1l111_l1_ (u"ࠨ࠭ࠪ幐"))
	l1lllll1_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࠫ幑")+search
	if not l11_l1_:
		if l1l111_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࡤ࠭幒") in options: l111ll111l1l_l1_ = l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡑࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ幓")
		elif l1l111_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫ幔") in options: l111ll111l1l_l1_ = l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡹࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭幕")
		elif l1l111_l1_ (u"ࠧࡠ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࠬ幖") in options: l111ll111l1l_l1_ = l1l111_l1_ (u"ࠨࠨࡶࡴࡂࡋࡧࡊࡓࡄ࡫ࠪ࠸࠵࠴ࡆࠨ࠶࠺࠹ࡄࠨ幗")
		else: l111ll111l1l_l1_ = l1l111_l1_ (u"ࠩࠪ幘")
		l1llllll_l1_ = l1lllll1_l1_+l111ll111l1l_l1_
	else:
		l111ll111l11_l1_,l111l1ll1lll_l1_,l1lllllll_l1_ = [],[],l1l111_l1_ (u"ࠪࠫ幙")
		l111l1lll11l_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢอีฯ๐ศࠨ幚"),l1l111_l1_ (u"ࠬะัห์หࠤาูศࠡ็าํࠥอไึๆฬࠫ幛"),l1l111_l1_ (u"࠭สาฬํฬࠥำำษࠢอหึ๐ฮࠡษ็ฮา๋๊ๅࠩ幜"),l1l111_l1_ (u"ࠧหำอ๎อࠦอิสࠣ฽ิีࠠศๆุ่ฬํฯศฬࠪ幝"),l1l111_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤฬ๊สใ์ํ้ࠬ幞")]
		l111ll1ll11l_l1_ = [l1l111_l1_ (u"ࠩࠪ幟"),l1l111_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡄࠩ࠷࠻࠳ࡅࠩ幠"),l1l111_l1_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡍࠪ࠸࠵࠴ࡆࠪ幡"),l1l111_l1_ (u"ࠬࠬࡳࡱ࠿ࡆࡅࡒࠫ࠲࠶࠵ࡇࠫ幢"),l1l111_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡋࠥ࠳࠷࠶ࡈࠬ幣")]
		l111ll1lll11_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠥ࠳ࠠศะอีࠥอไหำอ๎อ࠭幤"),l111l1lll11l_l1_)
		if l111ll1lll11_l1_ == -1: return
		l111ll1111l1_l1_ = l111ll1ll11l_l1_[l111ll1lll11_l1_]
		html,c,data = l111ll11l1ll_l1_(l1lllll1_l1_+l111ll1111l1_l1_)
		if c:
			try:
				d = c[l1l111_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ幥")][l1l111_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ幦")][l1l111_l1_ (u"ࠪࡴࡷ࡯࡭ࡢࡴࡼࡇࡴࡴࡴࡦࡰࡷࡷࠬ幧")][l1l111_l1_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ幨")][l1l111_l1_ (u"ࠬࡹࡵࡣࡏࡨࡲࡺ࠭幩")][l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ幪")][l1l111_l1_ (u"ࠧࡨࡴࡲࡹࡵࡹࠧ幫")]
				for l111l1ll1ll1_l1_ in range(len(d)):
					group = d[l111l1ll1ll1_l1_][l1l111_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡇ࡫࡯ࡸࡪࡸࡇࡳࡱࡸࡴࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭幬")][l1l111_l1_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪ幭")]
					for l111ll1lllll_l1_ in range(len(group)):
						yrender = group[l111ll1lllll_l1_][l1l111_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡉ࡭ࡱࡺࡥࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ幮")]
						if l1l111_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩ幯") in list(yrender.keys()):
							l1ll1ll_l1_ = yrender[l1l111_l1_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ幰")][l1l111_l1_ (u"࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ幱")][l1l111_l1_ (u"ࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ干")][l1l111_l1_ (u"ࠨࡷࡵࡰࠬ平")]
							l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠩ࡟ࡹ࠵࠶࠲࠷ࠩ年"),l1l111_l1_ (u"ࠪࠪࠬ幵"))
							title = yrender[l1l111_l1_ (u"ࠫࡹࡵ࡯࡭ࡶ࡬ࡴࠬ并")]
							title = title.replace(l1l111_l1_ (u"ࠬอไษฯฮࠤ฾์ࠠࠨ幷"),l1l111_l1_ (u"࠭ࠧ幸"))
							if l1l111_l1_ (u"ࠧฦิส่ฮࠦวๅใ็ฮึ࠭幹") in title: continue
							if l1l111_l1_ (u"ࠨไสส๊ฯࠠหึ฽๎้࠭幺") in title:
								title = l1l111_l1_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ幻")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠪฮึะ๊ษࠢะือ࠭幼") in title: continue
							title = title.replace(l1l111_l1_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡫ࡵࡲࠡࠩ幽"),l1l111_l1_ (u"ࠬ࠭幾"))
							if l1l111_l1_ (u"࠭ࡒࡦ࡯ࡲࡺࡪ࠭广") in title: continue
							if l1l111_l1_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࠩ庀") in title:
								title = l1l111_l1_ (u"ࠨฮํำ๊ࠥไๆี็ื้อสࠡࠩ庁")+title
								l1lllllll_l1_ = title
								l111lllll_l1_ = l1ll1ll_l1_
							if l1l111_l1_ (u"ࠩࡖࡳࡷࡺࠠࡣࡻࠪ庂") in title: continue
							l111ll111l11_l1_.append(escapeUNICODE(title))
							l111l1ll1lll_l1_.append(l1ll1ll_l1_)
			except: pass
		if not l1lllllll_l1_: l111ll1ll111_l1_ = l1l111_l1_ (u"ࠪࠫ広")
		else:
			l111ll111l11_l1_ = [l1l111_l1_ (u"ࠫอี่็ࠢไ่ฯืࠧ庄"),l1lllllll_l1_]+l111ll111l11_l1_
			l111l1ll1lll_l1_ = [l1l111_l1_ (u"ࠬ࠭庅"),l111lllll_l1_]+l111l1ll1lll_l1_
			l111lll1111l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ࠲ࠦวฯฬิࠤฬ๊แๅฬิࠫ庆"),l111ll111l11_l1_)
			if l111lll1111l_l1_ == -1: return
			l111ll1ll111_l1_ = l111l1ll1lll_l1_[l111lll1111l_l1_]
		if l111ll1ll111_l1_: l1llllll_l1_ = l111l1_l1_+l111ll1ll111_l1_
		elif l111ll1111l1_l1_: l1llllll_l1_ = l1lllll1_l1_+l111ll1111l1_l1_
		else: l1llllll_l1_ = l1lllll1_l1_
	l1lll11_l1_(l1llllll_l1_)
	return
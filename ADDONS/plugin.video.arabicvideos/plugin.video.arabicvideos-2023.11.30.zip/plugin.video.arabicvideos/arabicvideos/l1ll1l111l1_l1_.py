# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧⷿ")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ⸀")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l1l1l1lll1_l1_ = l1l11l1_l1_[l1ll1_l1_][1]
l1ll11l1lll_l1_ = l1l11l1_l1_[l1ll1_l1_][2]
l1ll11ll11l_l1_ = l1l11l1_l1_[l1ll1_l1_][3]
def l11l1ll_l1_(mode,url,l1llllll1_l1_,text):
	if   mode==20: l1lll_l1_ = l1ll11ll1l1_l1_()
	elif mode==21: l1lll_l1_ = l1l1l11_l1_(url)
	elif mode==22: l1lll_l1_ = l1lll11_l1_(url,l1llllll1_l1_)
	elif mode==23: l1lll_l1_ = l1ll1l11_l1_(url,l1llllll1_l1_)
	elif mode==24: l1lll_l1_ = PLAY(url,text)
	elif mode==25: l1lll_l1_ = l1ll111lll1_l1_(url)
	elif mode==27: l1lll_l1_ = l1ll1llll_l1_(url)
	elif mode==28: l1lll_l1_ = l1ll11lll11_l1_()
	elif mode==29: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1ll11ll1l1_l1_():
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⸁"),l1lllll_l1_+l1l111_l1_ (u"ࠫ฾ืศ๋ࠩ⸂"),l111l1_l1_,21,l1l111_l1_ (u"ࠬ࠭⸃"),l1l111_l1_ (u"࠭࠱࠱࠳ࠪ⸄"))
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸅"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ⸆"),l1l1l1lll1_l1_,21,l1l111_l1_ (u"ࠩࠪ⸇"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⸈"))
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸉"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็วาี์ࠫ⸊"),l1ll11l1lll_l1_,21,l1l111_l1_ (u"࠭ࠧ⸋"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⸌"))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸍"),l1lllll_l1_+l1l111_l1_ (u"ࠩไหึู้ࠡ࠴ࠪ⸎"),l1ll11ll11l_l1_,21,l1l111_l1_ (u"ࠪࠫ⸏"),l1l111_l1_ (u"ࠫ࠶࠶࠱ࠨ⸐"))
	return
def l1ll11lll11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩࡷࡧࠪ⸑"),l1lllll_l1_+l1l111_l1_ (u"ู࠭าสํࠫ⸒"),l111l1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⸓"),l1lllll_l1_+l1l111_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ⸔"),l1l1l1lll1_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⸕"),l1lllll_l1_+l1l111_l1_ (u"ࠪๅฬืำ๊ࠩ⸖"),l1ll11l1lll_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⸗"),l1lllll_l1_+l1l111_l1_ (u"ࠬ็วาี์ࠤ࠷࠭⸘"),l1ll11ll11l_l1_,27)
	return
def l1l1l11_l1_(l1ll11lll1l_l1_):
	l1ll1_l1_ = l1ll11lll1l_l1_
	if l1ll11lll1l_l1_==l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࠬ⸙"): l1ll11lll1l_l1_ = l111l1_l1_
	elif l1ll11lll1l_l1_==l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎࠧ⸚"): l1ll11lll1l_l1_ = l1l1l1lll1_l1_
	else: l1ll1_l1_ = l1l111_l1_ (u"ࠨࠩ⸛")
	l1lll1lll11_l1_ = l1ll11lllll_l1_(l1ll11lll1l_l1_)
	if l1lll1lll11_l1_==l1l111_l1_ (u"ࠩࡤࡶࠬ⸜") or l1ll1_l1_==l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩ⸝"):
		l1ll11l1111_l1_ = l1l111_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⸞")
		l1ll111llll_l1_ = l1l111_l1_ (u"๋ࠬำๅี็หฯࠦ࠭ࠡฯส่๏ฯࠧ⸟")
		l1llll1l1l1_l1_ = l1l111_l1_ (u"࠭ๅิๆึ่ฬะࠠ࠮ࠢฦัิัࠧ⸠")
		l1ll11l111l_l1_ = l1l111_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣวอาฯ๋ࠩ⸡")
		l1ll11l11ll_l1_ = l1l111_l1_ (u"ࠨสฮࠤา๐ࠠร์ࠣๅ๏๊ๅࠨ⸢")
		l1ll11l11l1_l1_ = l1l111_l1_ (u"ࠩฦๅ้อๅࠨ⸣")
		l1ll11l1l1l_l1_ = l1l111_l1_ (u"้ࠪํู๊ใ๋ࠪ⸤")
		l1ll11l1l11_l1_ = l1l111_l1_ (u"ࠫอืวๆฮࠪ⸥")
	elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⸦") or l1ll1_l1_==l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭⸧"):
		l1ll11l1111_l1_ = l1l111_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡪࡰࠣࡷ࡮ࡺࡥࠨ⸨")
		l1ll111llll_l1_ = l1l111_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠡ࠯ࠣࡇࡺࡸࡲࡦࡰࡷࠫ⸩")
		l1llll1l1l1_l1_ = l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠰ࠤࡑࡧࡴࡦࡵࡷࠫ⸪")
		l1ll11l111l_l1_ = l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡇ࡬ࡱࡪࡤࡦࡪࡺࠧ⸫")
		l1ll11l11ll_l1_ = l1l111_l1_ (u"ࠫࡑ࡯ࡶࡦࠢ࡬ࡊ࡮ࡲ࡭ࠡࡥ࡫ࡥࡳࡴࡥ࡭ࠩ⸬")
		l1ll11l11l1_l1_ = l1l111_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࡷࠬ⸭")
		l1ll11l1l1l_l1_ = l1l111_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⸮")
		l1ll11l1l11_l1_ = l1l111_l1_ (u"ࠧࡔࡪࡲࡻࡸ࠭ⸯ")
	elif l1lll1lll11_l1_ in [l1l111_l1_ (u"ࠨࡨࡤࠫ⸰"),l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⸱")]:
		l1ll11l1111_l1_ = l1l111_l1_ (u"ࠪะุะฬ้ࠢาีูࠥวໍฬࠪ⸲")
		l1ll111llll_l1_ = l1l111_l1_ (u"ุࠫื๊ศๆࠣ࠱ࠥาวา໎ࠪ⸳")
		l1llll1l1l1_l1_ = l1l111_l1_ (u"ูࠬั๋ษ็ࠤ࠲ࠦยฯำ໏๊ࠬ⸴")
		l1ll11l111l_l1_ = l1l111_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠศๆไฬฬ࠭⸵")
		l1ll11l11ll_l1_ = l1l111_l1_ (u"ࠧ๿ะืࠤื์ฯ่ࠢส๎ࠥ็๊ๅ็ࠪ⸶")
		l1ll11l11l1_l1_ = l1l111_l1_ (u"ࠨใํ่๊࠭⸷")
		l1ll11l1l1l_l1_ = l1l111_l1_ (u"่ࠩ์ุ๐โ๊ࠩ⸸")
		l1ll11l1l11_l1_ = l1l111_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬ࠭⸹")
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸺"),l1lllll_l1_+l1ll11l1111_l1_,l1ll11lll1l_l1_,29,l1l111_l1_ (u"ࠬ࠭⸻"),l1l111_l1_ (u"࠭ࠧ⸼"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⸽"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭⸾"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⸿")+l1lllll_l1_+l1ll11l11ll_l1_,l1ll11lll1l_l1_,27)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⹀"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠱ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࠵ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⹁"),l1l111_l1_ (u"ࠬ࠭⹂"),9999)
	l1lll1ll111_l1_ = [l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⹃"),l1l111_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⹄"),l1l111_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⹅")]
	html = l1l1llll_l1_(l1ll1ll1_l1_,l1ll11lll1l_l1_+l1l111_l1_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ⹆"),l1l111_l1_ (u"ࠪࠫ⹇"),l1l111_l1_ (u"ࠫࠬ⹈"),l1l111_l1_ (u"ࠬ࠭⹉"),l1l111_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⹊"))
	l11llll_l1_=re.findall(l1l111_l1_ (u"ࠧࡣࡷࡷࡸࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠲ࡇࡴࡴࡴࡢࡥࡷࠫ⹋"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⹌"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if any(value in l1ll1ll_l1_ for value in l1lll1ll111_l1_):
				url = l1ll11lll1l_l1_+l1ll1ll_l1_
				if l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⹍") in l1ll1ll_l1_:
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹎"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⹏")+l1lllll_l1_+l1ll111llll_l1_,url,22,l1l111_l1_ (u"ࠬ࠭⹐"),l1l111_l1_ (u"࠭࠱࠱࠲ࠪ⹑"))
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹒"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⹓")+l1lllll_l1_+l1llll1l1l1_l1_,url,22,l1l111_l1_ (u"ࠩࠪ⹔"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⹕"))
					addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⹖"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⹗")+l1lllll_l1_+l1ll11l111l_l1_,url,22,l1l111_l1_ (u"࠭ࠧ⹘"),l1l111_l1_ (u"ࠧ࠳࠲࠴ࠫ⹙"))
				elif l1l111_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⹚") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹛"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⹜")+l1lllll_l1_+l1ll11l11l1_l1_,url,22,l1l111_l1_ (u"ࠫࠬ⹝"),l1l111_l1_ (u"ࠬ࠷࠰࠱ࠩ⹞"))
				elif l1l111_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⹟") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹠"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⹡")+l1lllll_l1_+l1ll11l1l1l_l1_,url,25,l1l111_l1_ (u"ࠩࠪ⹢"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⹣"))
				elif l1l111_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⹤") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹥"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⹦")+l1lllll_l1_+l1ll11l1l11_l1_,url,22,l1l111_l1_ (u"ࠧࠨ⹧"),l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⹨"))
	return html
def l1ll111lll1_l1_(url):
	l1ll11lll1l_l1_ = l1ll11l1ll1_l1_(url)
	html = l1l1llll_l1_(l1ll1ll1_l1_,url,l1l111_l1_ (u"ࠩࠪ⹩"),l1l111_l1_ (u"ࠪࠫ⹪"),l1l111_l1_ (u"ࠫࠬ⹫"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡒ࡛ࡓࡊࡅࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ⹬"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡍࡶࡵ࡬ࡧ࠲ࡺ࡯ࡰ࡮ࡶ࠱࡭࡫ࡡࡥࡧࡵࠬ࠳࠰࠿ࠪࡏࡸࡷ࡮ࡩ࠭ࡣࡱࡧࡽࠬ⹭"),html,re.DOTALL)
	block = l11llll_l1_[0]
	title = re.findall(l1l111_l1_ (u"ࠧ࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭⹮"),block,re.DOTALL)[0]
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹯"),l1lllll_l1_+title,url,22,l1l111_l1_ (u"ࠩࠪ⹰"),l1l111_l1_ (u"ࠪ࠵࠵࠷ࠧ⹱"))
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⹲"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l1ll11lll1l_l1_ + l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⹳"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1l111_l1_ (u"࠭ࠧ⹴"),l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⹵"))
	return
def l1lll11_l1_(url,l1llllll1_l1_):
	l1ll11lll1l_l1_ = l1ll11l1ll1_l1_(url)
	l1lll1lll11_l1_ = l1ll11lllll_l1_(url)
	type = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ⹶"))[-1]
	l1ll111l1ll_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	if type==l1l111_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⹷") and l1llllll1_l1_==l1l111_l1_ (u"ࠪ࠴ࠬ⹸"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ⹹"),l1l111_l1_ (u"ࠬ࠭⹺"),l1l111_l1_ (u"࠭ࠧ⹻"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⹼"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬࠮ࡤࡲࡨࡾ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡴࡽࠧ⹽"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠩ࠰࠭ࡃ࠮ࡄ࠮ࠫࡁ࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ⹾"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1ll1ll_l1_ = l1ll11lll1l_l1_ + l1ll1ll_l1_
			l1ll1l_l1_ = l1ll11lll1l_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⹿"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll111l1ll_l1_+l1l111_l1_ (u"ࠫ࠵࠷ࠧ⺀"))
	l1ll111ll11_l1_=0
	if type==l1l111_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ⺁"): category=l1l111_l1_ (u"࠭࠳ࠨ⺂")
	if type==l1l111_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⺃"): category=l1l111_l1_ (u"ࠨ࠷ࠪ⺄")
	if type==l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⺅"): category=l1l111_l1_ (u"ࠪ࠻ࠬ⺆")
	if type in [l1l111_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⺇"),l1l111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⺈"),l1l111_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⺉")] and l1llllll1_l1_!=l1l111_l1_ (u"ࠧ࠱ࠩ⺊"):
		l1lllll1_l1_ = l1ll11lll1l_l1_+l1l111_l1_ (u"ࠨ࠱ࡋࡳࡲ࡫࠯ࡑࡣࡪࡩ࡮ࡴࡧࡊࡶࡨࡱࡄࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ⺋")+category+l1l111_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾ࠩ⺌")+l1llllll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡵࡲࡥࡧࡵࡦࡾࡃࠧ⺍")+l1ll111l1ll_l1_
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⺎"),l1l111_l1_ (u"ࠬ࠭⺏"),l1l111_l1_ (u"࠭ࠧ⺐"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⺑"))
		items = re.findall(l1l111_l1_ (u"ࠨࠤࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠫࡀࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ⺒"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠬ⺓"),l1l111_l1_ (u"ࠪࠫ⺔"))
			title = title.replace(l1l111_l1_ (u"ࠫࠧ࠭⺕"),l1l111_l1_ (u"ࠬ࠭⺖"))
			l1ll111ll11_l1_ += 1
			l1ll1ll_l1_ = l1ll11lll1l_l1_ + l1l111_l1_ (u"࠭࠯ࠨ⺗") + type + l1l111_l1_ (u"ࠧ࠰ࡅࡲࡲࡹ࡫࡮ࡵ࠱ࠪ⺘") + id
			l1ll1l_l1_ = l1ll11lll1l_l1_ + QUOTE(l1ll1l_l1_)
			if type==l1l111_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭⺙"): addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⺚"),l1lllll_l1_+title,l1ll1ll_l1_,24,l1ll1l_l1_,l1ll111l1ll_l1_+l1l111_l1_ (u"ࠪ࠴࠶࠭⺛"))
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⺜"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1ll111l1ll_l1_+l1l111_l1_ (u"ࠬ࠶࠱ࠨ⺝"))
	if type==l1l111_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⺞"):
		html = l1l1llll_l1_(l11l1l1_l1_,l1ll11lll1l_l1_+l1l111_l1_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡊࡰࡧࡩࡽࡅࡰࡢࡩࡨࡁࠬ⺟")+l1llllll1_l1_,l1l111_l1_ (u"ࠨࠩ⺠"),l1l111_l1_ (u"ࠩࠪ⺡"),l1l111_l1_ (u"ࠪࠫ⺢"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠷ࡷࡪࠧ⺣"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯࠯ࡧࡩࡲࡵࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࠮ࡦࡨࡱࡴ࠭⺤"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ⺥"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			l1ll111ll11_l1_ += 1
			l1ll1l_l1_ = l1ll11lll1l_l1_ + l1ll1l_l1_
			l1ll1ll_l1_ = l1ll11lll1l_l1_ + l1ll1ll_l1_
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⺦"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠨ࠳࠳࠵ࠬ⺧"))
	if l1ll111ll11_l1_>20:
		title=l1l111_l1_ (u"ุࠩๅาฯࠠࠨ⺨")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠪࡩࡳ࠭⺩"): title = l1l111_l1_ (u"ࠫࡕࡧࡧࡦࠢࠪ⺪")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⺫"): title = l1l111_l1_ (u"࠭ีโฯ๊ࠤࠬ⺬")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠧࡧࡣ࠵ࠫ⺭"): title = l1l111_l1_ (u"ࠨืไั์ࠦࠧ⺮")
		for l1ll11ll111_l1_ in range(1,11) :
			if not l1llllll1_l1_==str(l1ll11ll111_l1_):
				l1ll111ll1l_l1_ = l1l111_l1_ (u"ࠩ࠳ࠫ⺯")+str(l1ll11ll111_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺰"),l1lllll_l1_+title+str(l1ll11ll111_l1_),url,22,l1l111_l1_ (u"ࠫࠬ⺱"),l1ll111l1ll_l1_+l1ll111ll1l_l1_[-2:])
	return
def l1ll1l11_l1_(url,l1llllll1_l1_):
	if not l1llllll1_l1_: l1llllll1_l1_ = 0
	l1ll11lll1l_l1_ = l1ll11l1ll1_l1_(url)
	l1ll11llll1_l1_ = l1ll11l1ll1_l1_(url)
	l1lll1lll11_l1_ = l1ll11lllll_l1_(url)
	parts = url.split(l1l111_l1_ (u"ࠬ࠵ࠧ⺲"))
	id,type = parts[-1],parts[3]
	l1ll111l1ll_l1_ = str(int(l1llllll1_l1_)//100)
	l1llllll1_l1_ = str(int(l1llllll1_l1_)%100)
	l1ll111ll11_l1_ = 0
	if type==l1l111_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⺳"):
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠧࠨ⺴"),l1l111_l1_ (u"ࠨࠩ⺵"),l1l111_l1_ (u"ࠩࠪ⺶"),l1l111_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ⺷"))
		items = re.findall(l1l111_l1_ (u"ࠫࡈࡵ࡭࡮ࡧࡱࡸࡤࡶࡡ࡯ࡧ࡯ࡣࡎࡺࡥ࡮࠰࠭ࡃࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࡯࠮ࠬࡁࡹࡥࡷࠦࡩ࡯ࡶࡨࡶࡤࠦ࠽ࠡࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࡢࠧࠨ⺸"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩ⺹")
		if l1lll1lll11_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⺺"): title = l1l111_l1_ (u"ࠧࠡ࠯ࠣࡉࡵ࡯ࡳࡰࡦࡨࠤࠬ⺻")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⺼"): title = l1l111_l1_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫ⺽")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⺾"): title = l1l111_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⺿")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠬ࡬ࡡࠨ⻀"): l1ll11ll1ll_l1_ = l1l111_l1_ (u"࠭ࠧ⻁")
		else: l1ll11ll1ll_l1_ = l1lll1lll11_l1_
		l1ll1l1111l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲࡁࠧ࠮࠮ࠫࡁࠬࠬࡡ࠭࠮ࠫࡁ࡟ࠫࡤ࠯ࠨ࠯ࠬࡂ࠭ࠧࡄࠧ⻂"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1ll1ll_l1_ in items:
			for l1l1lll_l1_ in range(int(count),0,-1):
				l1ll1l11111_l1_ = l1ll1l_l1_ + l1ll11ll1ll_l1_ + id + l1l111_l1_ (u"ࠨ࠱ࠪ⻃") + str(l1l1lll_l1_) + l1l111_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧ⻄")
				l1ll111llll_l1_ = name + title + str(l1l1lll_l1_)
				l1ll111llll_l1_ = unescapeHTML(l1ll111llll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⻅"),l1lllll_l1_+l1ll111llll_l1_,url,24,l1ll1l11111_l1_,l1l111_l1_ (u"ࠫࠬ⻆"),str(l1l1lll_l1_))
	elif type==l1l111_l1_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭⻇"):
		l1lllll1_l1_ = l1ll11lll1l_l1_+l1l111_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡖࡡࡨࡧ࡬ࡲ࡬ࡇࡴࡵࡣࡦ࡬ࡲ࡫࡮ࡵࡋࡷࡩࡲࡅࡩࡥ࠿ࠪ⻈")+str(id)+l1l111_l1_ (u"ࠧࠧࡲࡤ࡫ࡪࡃࠧ⻉")+l1llllll1_l1_+l1l111_l1_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡳࡷࡪࡥࡳࡤࡼࡁ࠶࠭⻊")
		html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠩࠪ⻋"),l1l111_l1_ (u"ࠪࠫ⻌"),l1l111_l1_ (u"ࠫࠬ⻍"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ⻎"))
		items = re.findall(l1l111_l1_ (u"࠭ࡅࡱ࡫ࡶࡳࡩ࡫ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡉ࡯ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⻏"),html,re.DOTALL)
		title = l1l111_l1_ (u"ࠧࠡ࠯ࠣห้ำไใหࠣࠫ⻐")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠨࡧࡱࠫ⻑"): title = l1l111_l1_ (u"ࠩࠣ࠱ࠥࡋࡰࡪࡵࡲࡨࡪࠦࠧ⻒")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠭⻓"): title = l1l111_l1_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭⻔")
		if l1lll1lll11_l1_==l1l111_l1_ (u"ࠬ࡬ࡡ࠳ࠩ⻕"): title = l1l111_l1_ (u"࠭ࠠ࠮ࠢๅื๊ะࠠࠨ⻖")
		for l1l1lll_l1_,l1ll1l_l1_,l1ll1ll_l1_,desc,name in items:
			l1ll111ll11_l1_ += 1
			l1ll1l11111_l1_ = l1ll11llll1_l1_ + QUOTE(l1ll1l_l1_)
			name = escapeUNICODE(name)
			l1ll111llll_l1_ = name + title + str(l1l1lll_l1_)
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⻗"),l1lllll_l1_+l1ll111llll_l1_,l1lllll1_l1_,24,l1ll1l11111_l1_,l1l111_l1_ (u"ࠨࠩ⻘"),str(l1ll111ll11_l1_))
	elif type==l1l111_l1_ (u"ࠩࡐࡹࡸ࡯ࡣࠨ⻙"):
		if l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷࠫ⻚") in url and l1l111_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⻛") not in url:
			l1lllll1_l1_ = l1ll11lll1l_l1_+l1l111_l1_ (u"ࠬ࠵ࡍࡶࡵ࡬ࡧ࠴ࡍࡥࡵࡖࡵࡥࡨࡱࡳࡃࡻࡂ࡭ࡩࡃࠧ⻜")+str(id)+l1l111_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⻝")+l1llllll1_l1_+l1l111_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠱ࠩ⻞")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⻟"),l1l111_l1_ (u"ࠩࠪ⻠"),l1l111_l1_ (u"ࠪࠫ⻡"),l1l111_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠹ࡲࡥࠩ⻢"))
			items = re.findall(l1l111_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⻣"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll111ll11_l1_ += 1
				l1ll1l11111_l1_ = l1ll11llll1_l1_ + QUOTE(l1ll1l_l1_)
				l1ll111llll_l1_ = name + l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪ⻤") + title
				l1ll111llll_l1_ = l1ll111llll_l1_.strip(l1l111_l1_ (u"ࠧࠡࠩ⻥"))
				l1ll111llll_l1_ = escapeUNICODE(l1ll111llll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⻦"),l1lllll_l1_+l1ll111llll_l1_,l1lllll1_l1_,24,l1ll1l11111_l1_,l1l111_l1_ (u"ࠩࠪ⻧"),str(l1ll111ll11_l1_))
		elif l1l111_l1_ (u"ࠪࡇࡱ࡯ࡰࡴࠩ⻨") in url:
			l1lllll1_l1_ = l1ll11lll1l_l1_+l1l111_l1_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭⻩")+l1llllll1_l1_+l1l111_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠷࠵ࠨ⻪")
			html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ⻫"),l1l111_l1_ (u"ࠧࠨ⻬"),l1l111_l1_ (u"ࠨࠩ⻭"),l1l111_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠸ࡹ࡮ࠧ⻮"))
			items = re.findall(l1l111_l1_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡅࡤࡴࡹ࡯࡯࡯ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡪࡦࡨࡳࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⻯"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1ll1ll_l1_ in items:
				l1ll111ll11_l1_ += 1
				l1ll1l11111_l1_ = l1ll11llll1_l1_ + QUOTE(l1ll1l_l1_)
				l1ll111llll_l1_ = title.strip(l1l111_l1_ (u"ࠫࠥ࠭⻰"))
				l1ll111llll_l1_ = escapeUNICODE(l1ll111llll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⻱"),l1lllll_l1_+l1ll111llll_l1_,l1lllll1_l1_,24,l1ll1l11111_l1_,l1l111_l1_ (u"࠭ࠧ⻲"),str(l1ll111ll11_l1_))
		elif l1l111_l1_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ⻳") in url:
			if l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠺ࠬ⻴") in url:
				l1lllll1_l1_ = l1ll11lll1l_l1_+l1l111_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⻵")+l1llllll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠺ࠬ⻶")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⻷"),l1l111_l1_ (u"ࠬ࠭⻸"),l1l111_l1_ (u"࠭ࠧ⻹"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠷ࡷ࡬ࠬ⻺"))
			elif l1l111_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡀ࠸ࠬ⻻") in url:
				l1lllll1_l1_ = l1ll11lll1l_l1_+l1l111_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀ࠴ࠫࡶࡡࡨࡧࡀࠫ⻼")+l1llllll1_l1_+l1l111_l1_ (u"ࠪࠪࡸ࡯ࡺࡦ࠿࠶࠴ࠫࡺࡹࡱࡧࡀ࠸ࠬ⻽")
				html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬ⻾"),l1l111_l1_ (u"ࠬ࠭⻿"),l1l111_l1_ (u"࠭ࠧ⼀"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠸ࡷ࡬ࠬ⼁"))
			items = re.findall(l1l111_l1_ (u"ࠨࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡰ࡫ࡦࡩࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡆࡥࡵࡺࡩࡰࡰࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠨࡔࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⼂"),html,re.DOTALL)
			for l1ll1l_l1_,l1ll1ll_l1_,name,title in items:
				l1ll111ll11_l1_ += 1
				l1ll1l11111_l1_ = l1ll11llll1_l1_ + QUOTE(l1ll1l_l1_)
				l1ll111llll_l1_ = name + l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭⼃") + title
				l1ll111llll_l1_ = l1ll111llll_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬ⼄"))
				l1ll111llll_l1_ = escapeUNICODE(l1ll111llll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⼅"),l1lllll_l1_+l1ll111llll_l1_,l1lllll1_l1_,24,l1ll1l11111_l1_,l1l111_l1_ (u"ࠬ࠭⼆"),str(l1ll111ll11_l1_))
	if type==l1l111_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⼇") or type==l1l111_l1_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ⼈"):
		if l1ll111ll11_l1_>25:
			title=l1l111_l1_ (u"ࠨืไัฮࠦࠧ⼉")
			if l1lll1lll11_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⼊"): title = l1l111_l1_ (u"ࠪࠤࡕࡧࡧࡦࠢࠪ⼋")
			if l1lll1lll11_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⼌"): title = l1l111_l1_ (u"ࠬࠦีโฯ๊ࠤࠬ⼍")
			if l1lll1lll11_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⼎"): title = l1l111_l1_ (u"ࠧࠡืไั์ࠦࠧ⼏")
			for l1ll11ll111_l1_ in range(1,11):
				if not l1llllll1_l1_==str(l1ll11ll111_l1_):
					l1ll111ll1l_l1_ = l1l111_l1_ (u"ࠨ࠲ࠪ⼐")+str(l1ll11ll111_l1_)
					addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼑"),l1lllll_l1_+title+str(l1ll11ll111_l1_),url,23,l1l111_l1_ (u"ࠪࠫ⼒"),l1ll111l1ll_l1_+l1ll111ll1l_l1_[-2:])
	return
def PLAY(url,l1l1lll_l1_):
	l1ll11llll1_l1_ = l1ll11l1ll1_l1_(url)
	l1l1lll1_l1_,l1llll_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠫࠬ⼓"),l1l111_l1_ (u"ࠬ࠭⼔"),l1l111_l1_ (u"࠭ࠧ⼕"),l1l111_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⼖"))
	items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ⼗"),html,re.DOTALL)
	if items:
		l1lll1lll11_l1_ = l1ll11lllll_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠩ࠲ࠫ⼘"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lll1lll11_l1_+id+l1l111_l1_ (u"ࠪ࠳࠱࠭⼙")+l1l1lll_l1_+l1l111_l1_ (u"ࠫ࠱࠭⼚")+l1l1lll_l1_+l1l111_l1_ (u"ࠬࡥࠧ⼛")+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ⼜"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡻࡲ࡭࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮࡜ࠨ࠰࠭ࡃࡡ࠭ࠩࠩ࡞࠱࠲࠯ࡅࠩࠣࠩ⼝"),html,re.DOTALL)
	if items:
		l1lll1lll11_l1_ = l1ll11lllll_l1_(url)
		parts = url.split(l1l111_l1_ (u"ࠨ࠱ࠪ⼞"))
		id,type = parts[-1],parts[3]
		l1ll1ll_l1_ = items[0][0]+l1lll1lll11_l1_+id+l1l111_l1_ (u"ࠩ࠲ࠫ⼟")+l1l1lll_l1_+items[0][2]
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠪࡱࡵ࠺ࠠࡶࡴ࡯ࠫ⼠"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⼡"),html,re.DOTALL)
	for l1ll1ll_l1_ in items:
		l1ll1ll_l1_ = l1ll1ll_l1_.replace(l1l111_l1_ (u"ࠬ࠵࠯ࠨ⼢"),l1l111_l1_ (u"࠭࠯ࠨ⼣"))
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡸࡸࡣࠨ⼤"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ⼥"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll11llll1_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠩࡰࡴ࠹ࠦࡡࡥࡦࡵࡩࡸࡹࠧ⼦"))
		l1llll_l1_.append(l1ll1ll_l1_)
	items = re.findall(l1l111_l1_ (u"࡚ࠪࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⼧"),html,re.DOTALL)
	if items:
		l1ll1ll_l1_ = items[int(l1l1lll_l1_)-1]
		l1ll1ll_l1_ = l1ll11llll1_l1_+QUOTE(l1ll1ll_l1_)
		l1l1lll1_l1_.append(l1l111_l1_ (u"ࠫࡲࡶ࠳ࠡࡣࡧࡨࡷ࡫ࡳࡴࠩ⼨"))
		l1llll_l1_.append(l1ll1ll_l1_)
	if len(l1llll_l1_)==1: l1ll1ll_l1_ = l1llll_l1_[0]
	else:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭⼩"), l1l1lll1_l1_)
		if l11l11l_l1_ == -1 : return
		l1ll1ll_l1_ = l1llll_l1_[l11l11l_l1_]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⼪"))
	return
def l1ll11l1ll1_l1_(url):
	if l111l1_l1_ in url: l1ll1ll1ll1_l1_ = l111l1_l1_
	elif l1l1l1lll1_l1_ in url: l1ll1ll1ll1_l1_ = l1l1l1lll1_l1_
	elif l1ll11l1lll_l1_ in url: l1ll1ll1ll1_l1_ = l1ll11l1lll_l1_
	elif l1ll11ll11l_l1_ in url: l1ll1ll1ll1_l1_ = l1ll11ll11l_l1_
	else: l1ll1ll1ll1_l1_ = l1l111_l1_ (u"ࠧࠨ⼫")
	return l1ll1ll1ll1_l1_
def l1ll11lllll_l1_(url):
	if   l111l1_l1_ in url: l1lll1lll11_l1_ = l1l111_l1_ (u"ࠨࡣࡵࠫ⼬")
	elif l1l1l1lll1_l1_ in url: l1lll1lll11_l1_ = l1l111_l1_ (u"ࠩࡨࡲࠬ⼭")
	elif l1ll11l1lll_l1_ in url: l1lll1lll11_l1_ = l1l111_l1_ (u"ࠪࡪࡦ࠭⼮")
	elif l1ll11ll11l_l1_ in url: l1lll1lll11_l1_ = l1l111_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⼯")
	else: l1lll1lll11_l1_ = l1l111_l1_ (u"ࠬ࠭⼰")
	return l1lll1lll11_l1_
def l1ll1llll_l1_(url):
	l1lll1lll11_l1_ = l1ll11lllll_l1_(url)
	l1lllll1_l1_ = url + l1l111_l1_ (u"࠭࠯ࡉࡱࡰࡩ࠴ࡒࡩࡷࡧࠪ⼱")
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ⼲"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩ⼳"),l1l111_l1_ (u"ࠩࠪ⼴"),l1l111_l1_ (u"ࠪࠫ⼵"),l1l111_l1_ (u"ࠫࠬ⼶"),l1l111_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡑࡏࡖࡆ࠯࠴ࡷࡹ࠭⼷"))
	html = response.content
	items = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⼸"),html,re.DOTALL)
	l1llllll_l1_ = items[0]
	l1llll111_l1_(l1llllll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⼹"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	l1lll1ll_l1_ = search.replace(l1l111_l1_ (u"ࠨࠢࠪ⼺"),l1l111_l1_ (u"ࠩ࠮ࠫ⼻"))
	if l11_l1_:
		l11111ll1_l1_ = [ l111l1_l1_ , l1l1l1lll1_l1_ , l1ll11l1lll_l1_ , l1ll11ll11l_l1_ ]
		l1ll11111_l1_ = [ l1l111_l1_ (u"ࠪ฽ึฮ๊ࠨ⼼") , l1l111_l1_ (u"ࠫࡊࡴࡧ࡭࡫ࡶ࡬ࠬ⼽") , l1l111_l1_ (u"ࠬ็วาี์ࠫ⼾") , l1l111_l1_ (u"࠭แศำึํࠥ࠸ࠧ⼿") ]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠧศะอีࠥอไๅ฼ฬࠤฬ๊ๅ็ษึฬฮࡀࠧ⽀"), l1ll11111_l1_)
		if l11l11l_l1_ == -1 : return
		l1l11l11_l1_ = l11111ll1_l1_[l11l11l_l1_]
	else:
		if l1l111_l1_ (u"ࠨࡡࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࡠࠩ⽁") in options: l1l11l11_l1_ = l111l1_l1_
		elif l1l111_l1_ (u"ࠩࡢࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࡢࠫ⽂") in options: l1l11l11_l1_ = l1l1l1lll1_l1_
		else: l1l11l11_l1_ = l1l111_l1_ (u"ࠪࠫ⽃")
	if not l1l11l11_l1_: return
	l1lll1lll11_l1_ = l1ll11lllll_l1_(l1l11l11_l1_)
	l1lllll1_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠦ࠴ࡎ࡯࡮ࡧ࠲ࡗࡪࡧࡲࡤࡪࡂࡷࡪࡧࡲࡤࡪࡶࡸࡷ࡯࡮ࡨ࠿ࠥ⽄") + l1lll1ll_l1_
	html = l1l1llll_l1_(l11l1l1_l1_,l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭⽅"),l1l111_l1_ (u"࠭ࠧ⽆"),l1l111_l1_ (u"ࠧࠨ⽇"),l1l111_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ⽈"))
	items = re.findall(l1l111_l1_ (u"ࠩࠥࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡆࡥࡹ࡫ࡧࡰࡴࡼࡍࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡊࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯࡙ࠦ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱࠭⽉"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			if category in [l1l111_l1_ (u"ࠪ࠷ࠬ⽊"),l1l111_l1_ (u"ࠫ࠼࠭⽋")]:
				title = title.replace(l1l111_l1_ (u"ࠬࡢ࡜ࠨ⽌"),l1l111_l1_ (u"࠭ࠧ⽍"))
				title = title.replace(l1l111_l1_ (u"ࠧࠣࠩ⽎"),l1l111_l1_ (u"ࠨࠩ⽏"))
				if category==l1l111_l1_ (u"ࠩ࠶ࠫ⽐"):
					type = l1l111_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ⽑")
					if l1lll1lll11_l1_==l1l111_l1_ (u"ࠫࡦࡸࠧ⽒"): name = l1l111_l1_ (u"๋ࠬำๅี็ࠤ࠿ࠦࠧ⽓")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"࠭ࡥ࡯ࠩ⽔"): name = l1l111_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠ࠻ࠢࠪ⽕")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠨࡨࡤࠫ⽖"): name = l1l111_l1_ (u"ࠩึี๏อไ้ࠡสࠤ࠿ࠦࠧ⽗")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠪࡪࡦ࠸ࠧ⽘"): name = l1l111_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ⽙")
				elif category==l1l111_l1_ (u"ࠬ࠻ࠧ⽚"):
					type = l1l111_l1_ (u"࠭ࡆࡪ࡮ࡰࠫ⽛")
					if l1lll1lll11_l1_==l1l111_l1_ (u"ࠧࡢࡴࠪ⽜"): name = l1l111_l1_ (u"ࠨใํ่๊ࠦ࠺ࠡࠩ⽝")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠩࡨࡲࠬ⽞"): name = l1l111_l1_ (u"ࠪࡑࡴࡼࡩࡦࠢ࠽ࠤࠬ⽟")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࠧ⽠"): name = l1l111_l1_ (u"ࠬ็๊ๅ็ࠣ࠾ࠥ࠭⽡")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"࠭ࡦࡢ࠴ࠪ⽢"): name = l1l111_l1_ (u"ࠧโๆ่ࠤ์อࠠ࠻ࠢࠪ⽣")
				elif category==l1l111_l1_ (u"ࠨ࠹ࠪ⽤"):
					type = l1l111_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⽥")
					if l1lll1lll11_l1_==l1l111_l1_ (u"ࠪࡥࡷ࠭⽦"): name = l1l111_l1_ (u"ࠫอืๆศ็ฯࠤ࠿ࠦࠧ⽧")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠬ࡫࡮ࠨ⽨"): name = l1l111_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠠ࠻ࠢࠪ⽩")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠧࡧࡣࠪ⽪"): name = l1l111_l1_ (u"ࠨสิ๊ฬ๋็้ࠡสࠤ࠿ࠦࠧ⽫")
					elif l1lll1lll11_l1_==l1l111_l1_ (u"ࠩࡩࡥ࠷࠭⽬"): name = l1l111_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ⽭")
				title = name + title
				l1ll1ll_l1_ = l1l11l11_l1_ + l1l111_l1_ (u"ࠫ࠴࠭⽮") + type + l1l111_l1_ (u"ࠬ࠵ࡃࡰࡰࡷࡩࡳࡺ࠯ࠨ⽯") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11l11_l1_+l1ll1l_l1_
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⽰"),l1lllll_l1_+title,l1ll1ll_l1_,23,l1ll1l_l1_,l1l111_l1_ (u"ࠧ࠲࠲࠴ࠫ⽱"))
	return
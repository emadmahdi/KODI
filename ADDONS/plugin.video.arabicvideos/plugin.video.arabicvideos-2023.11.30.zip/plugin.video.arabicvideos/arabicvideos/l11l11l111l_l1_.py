# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ圷")
l1lllll_l1_ = l1l111_l1_ (u"ࠬࡥࡓࡉࡘࡢࠫ圸")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
headers = {l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ圹"):None}
def l11l1ll_l1_(mode,url,text):
	if   mode==310: l1lll_l1_ = l1l1l11_l1_()
	elif mode==311: l1lll_l1_ = l1lll11_l1_(url)
	elif mode==312: l1lll_l1_ = PLAY(url)
	elif mode==313: l1lll_l1_ = l111llll1l1l_l1_(url)
	elif mode==314: l1lll_l1_ = l1lllll1l_l1_(text)
	elif mode==319: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ场"),l1lllll_l1_+l1l111_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ圻"),l1l111_l1_ (u"ࠩࠪ圼"),319,l1l111_l1_ (u"ࠪࠫ圽"),l1l111_l1_ (u"ࠫࠬ圾"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ圿"))
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ址"),l111l1_l1_,l1l111_l1_ (u"ࠧࠨ坁"),l1l111_l1_ (u"ࠨࠩ坂"),l1l111_l1_ (u"ࠩࠪ坃"),l1l111_l1_ (u"ࠪࠫ坄"),l1l111_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ坅"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻ࡬ࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ坆"),html,re.DOTALL)
	block = l11llll_l1_[0]
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ均"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ坈"),l1l111_l1_ (u"ࠨࠩ坉"),9999)
	items = re.findall(l1l111_l1_ (u"ࠩ࠿࡬࠺ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠶ࡀࠪ坊"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l1l111_l1_ (u"ࠪࠤࠬ坋"))
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坌"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ坍")+l1lllll_l1_+title,l111l1_l1_,314,l1l111_l1_ (u"࠭ࠧ坎"),l1l111_l1_ (u"ࠧࠨ坏"),str(seq+1))
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ坐"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ坑")+l1lllll_l1_+l1l111_l1_ (u"้ࠪ็อืฺࠢื๋ึ࠭坒"),l111l1_l1_,314,l1l111_l1_ (u"ࠫࠬ坓"),l1l111_l1_ (u"ࠬ࠭坔"),l1l111_l1_ (u"࠭࠰ࠨ坕"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ坖"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ块"),l1l111_l1_ (u"ࠩࠪ坘"),9999)
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡈ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡃࡀࠪ坙"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴࠭坚")+l1ll1ll_l1_
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ坛"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ坜")+l1lllll_l1_+title,l1ll1ll_l1_,311)
	return html
def l1lllll1l_l1_(seq):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ坝"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ坞"),l1l111_l1_ (u"ࠩࠪ坟"),l1l111_l1_ (u"ࠪࠫ坠"),l1l111_l1_ (u"ࠫࠬ坡"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡎࡄࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬ坢"))
	html = response.content
	if seq==l1l111_l1_ (u"࠭࠰ࠨ坣"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ坤"),html,re.DOTALL)
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ坥"),block,re.DOTALL)
		for l1ll1ll_l1_,name,title in items:
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ坦")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ坧"))
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭坨"))
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ坩")+name+l1l111_l1_ (u"࠭ࠩࠨ坪")
			addMenuItem(l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭坫"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	elif seq in [l1l111_l1_ (u"ࠨ࠳ࠪ坬"),l1l111_l1_ (u"ࠩ࠵ࠫ坭"),l1l111_l1_ (u"ࠪ࠷ࠬ坮")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮࡮ࡪࠫ坯"),html,re.DOTALL)
		l111llll1ll1_l1_ = int(seq)-1
		block = l11llll_l1_[l111llll1ll1_l1_]
		if seq==l1l111_l1_ (u"ࠬ࠷ࠧ坰"): items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ坱"),block,re.DOTALL)
		else: items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ坲"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࠪ坳")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ坴")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ坵"))
			name = name.strip(l1l111_l1_ (u"ࠫࠥ࠭坶"))
			title = title+l1l111_l1_ (u"ࠬࠦࠨࠨ坷")+name+l1l111_l1_ (u"࠭ࠩࠨ坸")
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坹"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	elif seq in [l1l111_l1_ (u"ࠨ࠶ࠪ坺"),l1l111_l1_ (u"ࠩ࠸ࠫ坻"),l1l111_l1_ (u"ࠪ࠺ࠬ坼")]:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࠭ࡂࡨ࠶ࡀ࠱࠮ࡄ࠯࠼࠰ࡶࡤࡦࡱ࡫࠾ࠨ坽"),html,re.DOTALL)
		seq = int(seq)-4
		block = l11llll_l1_[seq]
		items = re.findall(l1l111_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀ࠯ࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ坾"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll1ll_l1_,l1ll111llll_l1_,title,l1llll1l1l1_l1_ in items:
			l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ坿")+l1ll1l_l1_
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࠩ垀")+l1ll1ll_l1_
			title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ垁"))
			l1ll111llll_l1_ = l1ll111llll_l1_.strip(l1l111_l1_ (u"ࠩࠣࠫ垂"))
			l1llll1l1l1_l1_ = l1llll1l1l1_l1_.strip(l1l111_l1_ (u"ࠪࠤࠬ垃"))
			if l1ll111llll_l1_: name = l1ll111llll_l1_
			else: name = l1llll1l1l1_l1_
			title = title+l1l111_l1_ (u"ࠫࠥ࠮ࠧ垄")+name+l1l111_l1_ (u"ࠬ࠯ࠧ垅")
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ垆"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1ll1l_l1_)
	return
def l1lll11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ垇"),url,l1l111_l1_ (u"ࠨࠩ垈"),l1l111_l1_ (u"ࠩࠪ垉"),l1l111_l1_ (u"ࠪࠫ垊"),l1l111_l1_ (u"ࠫࠬ型"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ垌"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡣࡱࡻ࠱࡭࡫ࡡࡥ࡫ࡱ࡫ࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡪࡱࡵࡡࡵ࠯ࡵ࡭࡬࡮ࡴࠨ垍"),html,re.DOTALL)
	block = l11llll_l1_[0]
	if l1l111_l1_ (u"ࠧࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠧ垎") in block:
		items = re.findall(l1l111_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࡣࡢࡶࡶࡹࡲ࠳࡭ࡰࡤ࡬ࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ垏"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1ll1ll_l1_,title,count in items:
				l1ll1l_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫ垐")+l1ll1l_l1_
				l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࠬ垑")+l1ll1ll_l1_
				count = count.replace(l1l111_l1_ (u"ࠫࠥอไึ๊อ๎ฮࡀࠠࠨ垒"),l1l111_l1_ (u"ࠬࡀࠧ垓"))
				title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垔"))
				title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垕")+count+l1l111_l1_ (u"ࠨࠫࠪ垖")
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垗"),l1lllll_l1_+title,l1ll1ll_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l1l111_l1_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ垘"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l111llll1lll_l1_,l1l1llll11_l1_ in items:
			if title==l1l111_l1_ (u"ࠫࠬ垙") or l111llll1lll_l1_==l1l111_l1_ (u"ࠬ࠭垚"): continue
			l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ垛")+l1ll1ll_l1_
			title = title+l1l111_l1_ (u"ࠧࠡࠪࠪ垜")+l1l1llll11_l1_+l1l111_l1_ (u"ࠨࠫࠪ垝")
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ垞"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	if not items: l1ll1l11_l1_(html)
	return
def l1ll1l11_l1_(html):
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ垟"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ垠"),block,re.DOTALL)
	for l1ll1ll_l1_,title,name,count,l1l1llll11_l1_ in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࠧ垡")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"࠭ࠠࠨ垢"))
		name = name.strip(l1l111_l1_ (u"ࠧࠡࠩ垣"))
		title = title+l1l111_l1_ (u"ࠨࠢࠫࠫ垤")+name+l1l111_l1_ (u"ࠩࠬࠫ垥")
		addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ垦"),l1lllll_l1_+title,l1ll1ll_l1_,312,l1l111_l1_ (u"ࠫࠬ垧"),l1l1llll11_l1_)
	return
def l111llll1l1l_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ垨"),url,l1l111_l1_ (u"࠭ࠧ垩"),l1l111_l1_ (u"ࠧࠨ垪"),l1l111_l1_ (u"ࠨࠩ垫"),l1l111_l1_ (u"ࠩࠪ垬"),l1l111_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍࡥࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩ垭"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠣࡴ࠲࠷ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ垮"),html,re.DOTALL)
	if not l11llll_l1_:
		l1lll11_l1_(url)
		return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ垯"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		l1ll1ll_l1_ = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࠨ垰")+l1ll1ll_l1_
		title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ垱"))
		if l1l111_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࠭ࠨ垲") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ垳"),l1lllll_l1_+title,l1ll1ll_l1_,312)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垴"),l1lllll_l1_+title,l1ll1ll_l1_,311)
	return
def PLAY(url):
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ垵"),url,l1l111_l1_ (u"ࠬ࠭垶"),l1l111_l1_ (u"࠭ࠧ垷"),l1l111_l1_ (u"ࠧࠨ垸"),l1l111_l1_ (u"ࠨࠩ垹"),l1l111_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ垺"))
	html = response.content
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡀࡦࡻࡤࡪࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ垻"),html,re.DOTALL)
	if not l1ll1ll_l1_: l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡼࡩࡥࡧࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ垼"),html,re.DOTALL)
	l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_[0]
	l1llll111_l1_(l1ll1ll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ垽"))
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ垾"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ垿"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ埀"),l1l111_l1_ (u"ࠩ࠮ࠫ埁"))
	l111lllll111_l1_ = [l1l111_l1_ (u"ࠪࠪࡹࡃࡡࠨ埂"),l1l111_l1_ (u"ࠫࠫࡺ࠽ࡤࠩ埃"),l1l111_l1_ (u"ࠬࠬࡴ࠾ࡵࠪ埄")]
	if l11_l1_:
		l111llll1l11_l1_ = [l1l111_l1_ (u"࠭โศำษࠫ埅"),l1l111_l1_ (u"ࠧฦืาหึࠦ࠯ࠡ็ฯ่ิ࠭埆"),l1l111_l1_ (u"ࠨ็ๅ฻฾ࠦวๅื๋ฮ๏࠭埇")]
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ࠲ࠦรฯฬิࠤฬ๊ศฮอࠪ埈"), l111llll1l11_l1_)
		if l11l11l_l1_ == -1: return
	elif l1l111_l1_ (u"ࠪࡣࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡑࡇࡕࡗࡔࡔࡓࡠࠩ埉") in options: l11l11l_l1_ = 0
	elif l1l111_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡏࡆ࡚ࡓࡓࡠࠩ埊") in options: l11l11l_l1_ = 1
	elif l1l111_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࡡࠪ埋") in options: l11l11l_l1_ = 2
	else: return
	type = l111lllll111_l1_[l11l11l_l1_]
	url = l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡶࡃࠧ埌")+search+type
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ埍"),url,l1l111_l1_ (u"ࠨࠩ城"),l1l111_l1_ (u"ࠩࠪ埏"),l1l111_l1_ (u"ࠪࠫ埐"),l1l111_l1_ (u"ࠫࠬ埑"),l1l111_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ埒"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠪ埓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if l11l11l_l1_ in [0,1]:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ埔"),block,re.DOTALL)
			for l1ll1ll_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ埕"))
				name = name.strip(l1l111_l1_ (u"ࠩࠣࠫ埖"))
				title = title+l1l111_l1_ (u"ࠪࠤ࠭࠭埗")+name+l1l111_l1_ (u"ࠫ࠮࠭埘")
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埙"),l1lllll_l1_+title,l1ll1ll_l1_,313,l1ll1l_l1_)
		elif l11l11l_l1_==2:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡺࡤ࠿࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀࠬ埚"),block,re.DOTALL)
			for l1ll1ll_l1_,title,name in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ埛"))
				name = name.strip(l1l111_l1_ (u"ࠨࠢࠪ埜"))
				title = title+l1l111_l1_ (u"ࠩࠣࠬࠬ埝")+name+l1l111_l1_ (u"ࠪ࠭ࠬ埞")
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ域"),l1lllll_l1_+title,l1ll1ll_l1_,312)
	return
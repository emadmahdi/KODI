# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ៴")
headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ៵") : l1l111_l1_ (u"ࠩࠪ៶") }
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡈࡓࡆࡠࠩ៷")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
def l11l1ll_l1_(mode,url,text):
	if   mode==90: l1lll_l1_ = l1l1l11_l1_()
	elif mode==91: l1lll_l1_ = ITEMS(url)
	elif mode==92: l1lll_l1_ = PLAY(url)
	elif mode==94: l1lll_l1_ = l1lllll1l_l1_()
	elif mode==95: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==99: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ៸"),l1lllll_l1_+l1l111_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ៹"),l1l111_l1_ (u"࠭ࠧ៺"),99,l1l111_l1_ (u"ࠧࠨ៻"),l1l111_l1_ (u"ࠨࠩ៼"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭៽"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ៾"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ៿"),l1l111_l1_ (u"ࠬ࠭᠀"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᠁"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᠂")+l1lllll_l1_+l1l111_l1_ (u"ࠨษ็้฻อแࠡฯา๎ะอࠧ᠃"),l1l111_l1_ (u"ࠩࠪ᠄"),94)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠅"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭᠆")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไฤฯาฯࠬ᠇"),l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡢࡶࡨࡷࡹ࠭᠈"),91)
	addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᠉"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ᠊")+l1lllll_l1_+l1l111_l1_ (u"ࠩส่ศ฿ไ๊ࠢอๆ๏๋ว์ࠩ᠋"),l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀ࡭ࡲࡪࡢࠨ᠌"),91)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᠍"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᠎")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅลๆฯึࠦๅีษ๊ำฮ࠭᠏"),l111l1_l1_+l1l111_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡷ࡫ࡨࡻࠬ᠐"),91)
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠑"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᠒")+l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋หษฬࠪ᠓"),l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡵ࡯࡮ࠨ᠔"),91)
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᠕"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᠖")+l1lllll_l1_+l1l111_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭᠗"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡰࡨࡻࡒࡵࡶࡪࡧࡶࠫ᠘"),91)
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᠙"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ᠚")+l1lllll_l1_+l1l111_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ᠛"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡴࡥࡸࡇࡳ࡭ࡸࡵࡤࡦࡵࠪ᠜"),91)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᠝"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᠞"),l1l111_l1_ (u"ࠨࠩ᠟"),9999)
	html = l1l1llll_l1_(l1ll1ll1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠩࠪᠠ"),headers,l1l111_l1_ (u"ࠪࠫᠡ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᠢ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡡࡪࡰࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡳࡧࡶࠨᠣ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᠤ"),block,re.DOTALL)
	l11lll_l1_ = [l1l111_l1_ (u"ࠧศใ็ห๊ࠦไๅๅหหึࠦแใูࠪᠥ")]
	for l1ll1ll_l1_,title in items:
		title = title.strip(l1l111_l1_ (u"ࠨࠢࠪᠦ"))
		if not any(value in title for value in l11lll_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠧ"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᠨ")+l1lllll_l1_+title,l1ll1ll_l1_,91)
	return html
def ITEMS(url):
	if l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࠩᠩ") in url:
		url,search = url.split(l1l111_l1_ (u"ࠬࡅࡴ࠾ࠩᠪ"))
		headers = { l1l111_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᠫ") : l1l111_l1_ (u"ࠧࠨᠬ") , l1l111_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᠭ") : l1l111_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᠮ") }
		data = { l1l111_l1_ (u"ࠪࡸࠬᠯ") : search }
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡕࡕࡓࡕࠩᠰ"),url,data,headers,l1l111_l1_ (u"ࠬ࠭ᠱ"),l1l111_l1_ (u"࠭ࠧᠲ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬᠳ"))
		html = response.content
	else:
		headers = { l1l111_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᠴ") : l1l111_l1_ (u"ࠩࠪᠵ") }
		html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫᠶ"),headers,l1l111_l1_ (u"ࠫࠬᠷ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡊࡖࡈࡑࡘ࠳࠲࡯ࡦࠪᠸ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩࡥ࠿ࠥࡱࡴࡼࡩࡦࡵ࠰࡭ࡹ࡫࡭ࡴࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷࡪࡴࡵࡴࠣࠩᠹ"),html,re.DOTALL)
	if l11llll_l1_: block = l11llll_l1_[0]
	else: block = l1l111_l1_ (u"ࠧࠨᠺ")
	items = re.findall(l1l111_l1_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡭ࡰࡸ࡬ࡩ࠲ࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᠻ"),block,re.DOTALL)
	l1l1_l1_ = []
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠩส่า๊โสࠩᠼ") in title and l1l111_l1_ (u"ࠪ࠳ࡨ࠵ࠧᠽ") not in url and l1l111_l1_ (u"ࠫ࠴ࡩࡡࡵ࠱ࠪᠾ") not in url:
			l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮࠮ࠫࡁࠬࠤฬ๊อๅไฬࠤࡠ࠶࠭࠺࡟࠮ࠫᠿ"),title,re.DOTALL)
			if l1l1lll_l1_:
				title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬᡀ")+l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᡁ"),l1lllll_l1_+title,l1ll1ll_l1_,95,l1ll1l_l1_)
					l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩᡂ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᡃ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᡄ"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩᡅ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᡆ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"࠭วๅืไัฮࠦࠧᡇ"),l1l111_l1_ (u"ࠧࠨᡈ"))
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᡉ"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨᡊ")+title,l1ll1ll_l1_,91)
	return
def l1ll1l11_l1_(url):
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫᡋ"),headers,l1l111_l1_ (u"ࠫࠬᡌ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᡍ"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᡎ"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡪࡶࡩࡴࡱࡧࡩࡸ࠳ࡰࡢࡰࡨࡰ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᡏ"),html,re.DOTALL)
	if l11llll_l1_:
		name = re.findall(l1l111_l1_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᡐ"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l1l111_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪᡑ"))
			if l1l111_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᡒ") in name: name = name.split(l1l111_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᡓ"),1)[1]
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᡔ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᡕ"),l1lllll_l1_+name+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᡖ")+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	else:
		tmp = re.findall(l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡲࡺ࡮࡫ࡴࡪࡶ࡯ࡩࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᡗ"),html,re.DOTALL)
		if tmp: l1ll1ll_l1_,title = tmp[0]
		else: l1ll1ll_l1_,title = url,name
		addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᡘ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l11111ll1_l1_ = [],[]
	html = l1l1llll_l1_(l11l1l1_l1_,url,l1l111_l1_ (u"ࠪࠫᡙ"),headers,l1l111_l1_ (u"ࠫࠬᡚ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᡛ"))
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡴࡦࡺࡷ࠱ࡸ࡮ࡡࡥࡱࡺ࠾ࠥࡴ࡯࡯ࡧ࠾ࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᡜ"),html,re.DOTALL)
	if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪᡝ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᡞ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠩࡂࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᡟ")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡲࡦࡼ࠭ࡵࡣࡥࡷࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࠯ࡳࡥࡳ࡫࡬࠮࡯ࡲࡶࡪ࠭ᡠ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡩࡲࡨࡥࡥࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᡡ"),block,re.DOTALL)
		for id,l1ll1ll_l1_ in items:
			title = l1l111_l1_ (u"ู๊ࠬาใิࠤࠬᡢ")+id
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᡣ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᡤ")
			l1llll_l1_.append(l1ll1ll_l1_)
		items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡴࡹࡩࡷ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᡥ"),block,re.DOTALL)
		for l1ll1ll_l1_ in items:
			if l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᡦ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩᡧ")+l1ll1ll_l1_
			l1ll1ll_l1_ = l111l11_l1_(l1ll1ll_l1_)
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᡨ"),url)
	return
def l1lllll1l_l1_():
	html = l1l1llll_l1_(l11l1l1_l1_,l111l1_l1_,l1l111_l1_ (u"ࠬ࠭ᡩ"),headers,l1l111_l1_ (u"࠭ࠧᡪ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭ᡫ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࡯࡮ࡥࡧࡻ࠱ࡱࡧࡳࡵ࠯ࡰࡳࡻ࡯ࡥࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤ࡬ࡲࡩ࡫ࡸ࠮ࡵ࡯࡭ࡩ࡫ࡲ࠮࡯ࡲࡺ࡮࡫ࠧᡬ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᡭ"),block,re.DOTALL)
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		if l1l111_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࠫᡮ") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᡯ"),l1lllll_l1_+title,l1ll1ll_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᡰ"),l1lllll_l1_+title,l1ll1ll_l1_,91,l1ll1l_l1_)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧᡱ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨᡲ"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪᡳ"),l1l111_l1_ (u"ࠩ࠮ࠫᡴ"))
	url = l111l1_l1_ + l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࡶࡀࠫᡵ")+search
	ITEMS(url)
	return
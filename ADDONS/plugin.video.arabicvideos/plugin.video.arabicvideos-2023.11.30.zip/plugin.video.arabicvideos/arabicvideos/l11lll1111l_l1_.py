# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕࠩ宖")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡟ࡑࡕࡡࠪ宗")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ官"),l1l111_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ宙"),l1l111_l1_ (u"ࠧหีฯ๎้࠭定"),l1l111_l1_ (u"ࠨฬึะ๏๊ࠠศๆาาํ๊ࠧ宛"),l1l111_l1_ (u"ࠩ฼ี฻ࠦวๅ็ี๎ิ࠭宜")]
def l11l1ll_l1_(mode,url,text):
	if   mode==660: l1lll_l1_ = l1l1l11_l1_()
	elif mode==661: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==662: l1lll_l1_ = PLAY(url)
	elif mode==663: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==664: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==669: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ宝"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ实"),l1l111_l1_ (u"ࠬ࠭実"),l1l111_l1_ (u"࠭ࠧ宠"),l1l111_l1_ (u"ࠧࠨ审"),l1l111_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ客"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ宣"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ室"),l1l111_l1_ (u"ࠫࠬ宥"),669,l1l111_l1_ (u"ࠬ࠭宦"),l1l111_l1_ (u"࠭ࠧ宧"),l1l111_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ宨"))
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭宩"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ宪"),l1l111_l1_ (u"ࠪࠫ宫"),9999)
	addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ宬"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ宭")+l1lllll_l1_+l1l111_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ宮"),l111l1_l1_,661,l1l111_l1_ (u"ࠧࠨ宯"),l1l111_l1_ (u"ࠨࠩ宰"),l1l111_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ宱"))
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ宲"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ害"),l1l111_l1_ (u"ࠬ࠭宴"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠰ࡳ࡬ࡵࠨ࠾ࠩ࠰࠭ࡃ࠮ࠨ࡮ࡢࡸࡶࡰ࡮ࡪࡥ࠮ࡦ࡬ࡺ࡮ࡪࡥࡳࠤࠪ宵"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧ家"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠨࠩ宷"))
	items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ宸"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠪࡀࡧࡄࠧ容"),l1l111_l1_ (u"ࠫࠬ宺")).replace(l1l111_l1_ (u"ࠬࡂ࠯ࡣࡀࠪ宻"),l1l111_l1_ (u"࠭ࠧ宼")).replace(l1l111_l1_ (u"ࠧ࠽ࡤࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡸࡥࡵࠤࡁࠫ宽"),l1l111_l1_ (u"ࠨࠩ宾")).replace(l1l111_l1_ (u"ࠩ࠿ࡦࡃ࠭宿"),l1l111_l1_ (u"ࠪࠫ寀")).strip(l1l111_l1_ (u"ࠫࠥ࠭寁"))
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寂"),l1ll1_l1_+l1l111_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ寃")+l1lllll_l1_+title,l1ll1ll_l1_,664)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ寄"),url,l1l111_l1_ (u"ࠨࠩ寅"),l1l111_l1_ (u"ࠩࠪ密"),l1l111_l1_ (u"ࠪࠫ寇"),l1l111_l1_ (u"ࠫࠬ寈"),l1l111_l1_ (u"ࠬ࡟ࡁࡒࡑࡗ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ寉"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡧࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ寊"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨ寋"),l1l111_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧ富"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭寍"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠪࠫ寎"),block)]
		addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ寏"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ寐"),l1l111_l1_ (u"࠭ࠧ寑"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ寒"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠨ࠼ࠣࠫ寓")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ寔"),l1lllll_l1_+title,l1ll1ll_l1_,661)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ寕"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭寖"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ寗"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭寘"),l1l111_l1_ (u"ࠧࠨ寙"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ寚"),l1lllll_l1_+title,l1ll1ll_l1_,661)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠩࠪ寛")):
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ寜"):
		url,search = url.split(l1l111_l1_ (u"ࠫࡄ࠭寝"),1)
		data = l1l111_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ寞")+search
		headers = {l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ察"):l1l111_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ寠")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡒࡒࡗ࡙࠭寡"),url,data,headers,l1l111_l1_ (u"ࠩࠪ寢"),l1l111_l1_ (u"ࠪࠫ寣"),l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ寤"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ寥"),url,l1l111_l1_ (u"࠭ࠧ實"),l1l111_l1_ (u"ࠧࠨ寧"),l1l111_l1_ (u"ࠨࠩ寨"),l1l111_l1_ (u"ࠩࠪ審"),l1l111_l1_ (u"ࠪ࡝ࡆࡗࡏࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭寪"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠫࠬ寫"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠬࡻࡲ࡭ࠩ寬"))
	if request==l1l111_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ寭"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ寮"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩ寯"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ寰"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ寱"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ寲"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ寳"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ寴"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ寵"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ寶"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫ寷"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ寸"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠫࠬ对"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭寺"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ寻"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ导"),l1l111_l1_ (u"ࠨใํ่๊࠭寽"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨ対"),l1l111_l1_ (u"ࠪ็้๐ศࠨ寿"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪ尀"),l1l111_l1_ (u"ࠬํฯศใࠪ封"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭専"),l1l111_l1_ (u"ฺࠧำูࠫ尃"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨ射"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨ尅"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪ将")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		title = title.replace(l1l111_l1_ (u"ࠫฬ๎ๆࠡๆส๎๋ࠦࠧ將"),l1l111_l1_ (u"ࠬ࠭專")).replace(l1l111_l1_ (u"࠭ว้่็ห๏์ࠠࠨ尉"),l1l111_l1_ (u"ࠧࠨ尊")).replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ尋"),l1l111_l1_ (u"ࠩࠪ尌"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭對"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ導"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ小"):
			addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ尐"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭少") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尒"),l1lllll_l1_+title,l1ll1ll_l1_,663,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ尓"),l1lllll_l1_+title,l1ll1ll_l1_,663,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ尔"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ尕"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠬࠩࠧ尖"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ尗")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠰ࠩ尘"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尙"),l1lllll_l1_+l1l111_l1_ (u"ุࠩๅาฯࠠࠨ尚")+title,l1ll1ll_l1_,661)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ尛"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ尜"),url,l1l111_l1_ (u"ࠬ࠭尝"),l1l111_l1_ (u"࠭ࠧ尞"),l1l111_l1_ (u"ࠧࠨ尟"),l1l111_l1_ (u"ࠨࠩ尠"),l1l111_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ尡"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭尢"),html,re.DOTALL)
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭尣"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠬ࠭尤")
	items = []
	l11l1_l1_ = False
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ尥"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"ࠧࠤࠩ尦"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尧"),l1lllll_l1_+title,url,663,l1ll1l_l1_,l1l111_l1_ (u"ࠩࠪ尨"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ尩")+l1l11_l1_+l1l111_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ尪"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ尫"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࠨ尬")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠧ࠯࠱ࠪ尭"))
			title = title.replace(l1l111_l1_ (u"ࠨ࠾࠲ࡩࡲࡄ࠼ࡴࡲࡤࡲࡃ࠭尮"),l1l111_l1_ (u"ࠩࠣࠫ尯"))
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ尰"),l1lllll_l1_+title,l1ll1ll_l1_,662,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨ就"),l1l111_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼ࠲ࡵ࡮ࡰࠨ尲"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ尳"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ尴"),l1l111_l1_ (u"ࠨࠩ尵"),l1l111_l1_ (u"ࠩࠪ尶"),l1l111_l1_ (u"ࠪࠫ尷"),l1l111_l1_ (u"ࠫ࡞ࡇࡑࡐࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ尸"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡓࡰࡦࡿࡥࡳࡪࡲࡰࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭尹"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ尺"),block,re.DOTALL)
		if l1ll1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_[0]
			l1ll11111_l1_.append(l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ尻"))
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ尼"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪ尽"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ尾")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ尿"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ局"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"࠭ࠧ屁"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠧࠨ层"): return
	search = search.replace(l1l111_l1_ (u"ࠨࠢࠪ屃"),l1l111_l1_ (u"ࠩ࠮ࠫ屄"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ居")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ屆"))
	return
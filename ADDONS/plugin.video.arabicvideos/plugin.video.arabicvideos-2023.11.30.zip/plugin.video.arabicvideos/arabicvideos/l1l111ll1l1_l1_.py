# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
import xbmc,re,sys,xbmcaddon,random,os,xbmcvfs,time,pickle,zlib,xbmcgui,xbmcplugin,sqlite3,traceback
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧㅶ")
l1l1l11l1ll_l1_ = xbmcaddon.Addon().getAddonInfo(l1l111_l1_ (u"ࠧࡱࡣࡷ࡬ࠬㅷ"))
l1l111l11ll_l1_ = os.path.join(l1l1l11l1ll_l1_,l1l111_l1_ (u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪㅸ"))
sys.path.append(l1l111l11ll_l1_)
l1l1l11111l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣㅹ"))
kodi_version = re.findall(l1l111_l1_ (u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧㅺ"),l1l1l11111l_l1_,re.DOTALL)
kodi_version = float(kodi_version[0])
l1l1l1ll1l1_l1_ = xbmc.Player
l1l1l1l11ll_l1_ = xbmcgui.WindowXMLDialog
if kodi_version>18.99:
	l1l1lll1l11_l1_ = xbmc.LOGINFO
	ltr,rtl = l1l111_l1_ (u"ࡹࠬࡢࡵ࠳࠲࠵ࡥࠬㅻ"),l1l111_l1_ (u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭ㅼ")
	l1l11lll111_l1_ = xbmcvfs.translatePath(l1l111_l1_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧㅽ"))
	from urllib.parse import unquote as _1l1l111111_l1_
else:
	l1l1lll1l11_l1_ = xbmc.LOGNOTICE
	ltr,rtl = l1l111_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨㅾ").encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㅿ")),l1l111_l1_ (u"ࡷࠪࡠࡺ࠸࠰࠳ࡤࠪㆀ").encode(l1l111_l1_ (u"ࠪࡹࡹ࡬࠸ࠨㆁ"))
	l1l11lll111_l1_ = xbmc.translatePath(l1l111_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬㆂ"))
	from urllib import unquote as _1l1l111111_l1_
l1l1ll111l1_l1_ = 60
l1l11ll1ll1_l1_ = 60*l1l1ll111l1_l1_
l1l11ll11l1_l1_ = 24*l1l11ll1ll1_l1_
l1l1l1lll1l_l1_ = 30*l1l11ll11l1_l1_
l1ll1ll1_l1_ = 3*l1l11ll11l1_l1_
l1l1lll1l1l_l1_ = 12*l1l1l1lll1l_l1_
addon_id = sys.argv[0].split(l1l111_l1_ (u"ࠬ࠵ࠧㆃ"))[2]
addon_handle = int(sys.argv[1])
addon_path = sys.argv[2]
l1l1ll11ll1_l1_ = addon_id.split(l1l111_l1_ (u"࠭࠮ࠨㆄ"))[2]
l1l11l11111_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡂࡦࡧࡳࡳ࡜ࡥࡳࡵ࡬ࡳࡳ࠮ࠧㆅ")+addon_id+l1l111_l1_ (u"ࠨࠫࠪㆆ"))
addoncachefolder = os.path.join(l1l11lll111_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠩࡰࡥ࡮ࡴࡤࡢࡶࡤ࠲ࡩࡨࠧㆇ"))
l1l11llll1l_l1_ = os.path.join(addoncachefolder,l1l111_l1_ (u"ࠪࡰࡦࡹࡴࡷ࡫ࡧࡩࡴࡹ࠮ࡥࡣࡷࠫㆈ"))
now = int(time.time())
settings = xbmcaddon.Addon(id=addon_id)
def l1ll11ll1_l1_(url):
	if l1l111_l1_ (u"ࠫࡂ࠭ㆉ") in url:
		if l1l111_l1_ (u"ࠬࡅࠧㆊ") in url: l1lllll1_l1_,filters = url.split(l1l111_l1_ (u"࠭࠿ࠨㆋ"),1)
		else: l1lllll1_l1_,filters = l1l111_l1_ (u"ࠧࠨㆌ"),url
		filters = filters.split(l1l111_l1_ (u"ࠨࠨࠪㆍ"))
		l1l11llll_l1_ = {}
		for filter in filters:
			key,value = filter.split(l1l111_l1_ (u"ࠩࡀࠫㆎ"),1)
			l1l11llll_l1_[key] = value
	else: l1lllll1_l1_,l1l11llll_l1_ = url,{}
	return l1lllll1_l1_,l1l11llll_l1_
def l111l11_l1_(urll):
	return _1l1l111111_l1_(urll)
def EXTRACT_KODI_PATH(l1l111ll111_l1_):
	l1l1lll1111_l1_ = {l1l111_l1_ (u"ࠪࡸࡾࡶࡥࠨ㆏"):l1l111_l1_ (u"ࠫࠬ㆐"),l1l111_l1_ (u"ࠬࡳ࡯ࡥࡧࠪ㆑"):l1l111_l1_ (u"࠭ࠧ㆒"),l1l111_l1_ (u"ࠧࡶࡴ࡯ࠫ㆓"):l1l111_l1_ (u"ࠨࠩ㆔"),l1l111_l1_ (u"ࠩࡷࡩࡽࡺࠧ㆕"):l1l111_l1_ (u"ࠪࠫ㆖"),l1l111_l1_ (u"ࠫࡵࡧࡧࡦࠩ㆗"):l1l111_l1_ (u"ࠬ࠭㆘"),l1l111_l1_ (u"࠭࡮ࡢ࡯ࡨࠫ㆙"):l1l111_l1_ (u"ࠧࠨ㆚"),l1l111_l1_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧ㆛"):l1l111_l1_ (u"ࠩࠪ㆜"),l1l111_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ㆝"):l1l111_l1_ (u"ࠫࠬ㆞"),l1l111_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ㆟"):l1l111_l1_ (u"࠭ࠧㆠ")}
	if l1l111_l1_ (u"ࠧࡀࠩㆡ") in l1l111ll111_l1_: l1l111ll111_l1_ = l1l111ll111_l1_.split(l1l111_l1_ (u"ࠨࡁࠪㆢ"),1)[1]
	l1lllll1_l1_,l1l1ll1llll_l1_ = l1ll11ll1_l1_(l1l111ll111_l1_)
	args = dict(list(l1l1lll1111_l1_.items())+list(l1l1ll1llll_l1_.items()))
	l1l111l1l11_l1_ = args[l1l111_l1_ (u"ࠩࡰࡳࡩ࡫ࠧㆣ")]
	l1l1l111lll_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪࡹࡷࡲࠧㆤ")])
	l1l11ll1111_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠫࡹ࡫ࡸࡵࠩㆥ")])
	l1l1111ll1l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠬࡶࡡࡨࡧࠪㆦ")])
	l1l1111ll11_l1_ = l111l11_l1_(args[l1l111_l1_ (u"࠭ࡴࡺࡲࡨࠫㆧ")])
	l1l11ll111l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠧ࡯ࡣࡰࡩࠬㆨ")])
	l1l1l1l1l1l_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧㆩ")])
	l1l11l1lll1_l1_ = args[l1l111_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪㆪ")]
	l1l11lllll1_l1_ = l111l11_l1_(args[l1l111_l1_ (u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬㆫ")])
	if l1l11lllll1_l1_: l1l11lllll1_l1_ = eval(l1l11lllll1_l1_)
	else: l1l11lllll1_l1_ = {}
	if not l1l111l1l11_l1_: l1l1111ll11_l1_ = l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㆬ") ; l1l111l1l11_l1_ = l1l111_l1_ (u"ࠬ࠸࠶࠱ࠩㆭ")
	return l1l1111ll11_l1_,l1l11ll111l_l1_,l1l1l111lll_l1_,l1l111l1l11_l1_,l1l1l1l1l1l_l1_,l1l1111ll1l_l1_,l1l11ll1111_l1_,l1l11l1lll1_l1_,l1l11lllll1_l1_
def l11lll1l11_l1_(l1ll1_l1_):
	l1l11l1llll_l1_ = sys._getframe(1).f_code.co_name
	if not l1ll1_l1_ or not l1l11l1llll_l1_ or l1l11l1llll_l1_==l1l111_l1_ (u"࠭࠼࡮ࡱࡧࡹࡱ࡫࠾ࠨㆮ"):
		return l1l111_l1_ (u"ࠧ࡜ࠢࠪㆯ")+l1l1ll11ll1_l1_.upper()+l1l111_l1_ (u"ࠨ࠯ࠪㆰ")+l1l11l11111_l1_+l1l111_l1_ (u"ࠩ࠰ࠫㆱ")+str(kodi_version)+l1l111_l1_ (u"ࠪࠤࡢ࠭ㆲ")
	return l1l111_l1_ (u"ࠫ࠳ࠦࠠࠨㆳ")+l1l11l1llll_l1_
def l11lllll1l_l1_(level,message):
	if kodi_version<19: message = message.decode(l1l111_l1_ (u"ࠬࡻࡴࡧ࠺ࠪㆴ")).encode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫㆵ"))
	l1l11l111l1_l1_ = l1l1lll1l11_l1_
	lines = [l1l111_l1_ (u"ࠧࠨㆶ"),l1l111_l1_ (u"ࠨࠩㆷ")]
	if level: message = message.replace(l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬㆸ"),l1l111_l1_ (u"ࠪࠫㆹ")).replace(l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧㆺ"),l1l111_l1_ (u"ࠬ࠭ㆻ")).replace(l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨㆼ"),l1l111_l1_ (u"ࠧࠨㆽ"))
	else: level = l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨㆾ")
	l11l11l1ll_l1_,sep,shift = l1l111_l1_ (u"ࠩࠣࠤࠥࠦࠧㆿ"),l1l111_l1_ (u"ࠪࠤࠥࠦࠧ㇀"),l1l111_l1_ (u"ࠫࠬ㇁")
	if l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㇂") in level: l1l11l111l1_l1_ = xbmc.LOGERROR
	if level==l1l111_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㇃"):
		message = message+sep
		lines = message.split(sep)
		shift = l11l11l1ll_l1_
	elif level==l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭㇄"):
		message = message.replace(l1l111_l1_ (u"ࠨ࠰ࠪ㇅")+sep,l1l111_l1_ (u"ࠩ࠱ࠤࠥ࠭㇆"))
		lines = message.split(sep)
		lines[0] = l1l111_l1_ (u"ࠪ࠲ࠬ㇇")+lines[0][1:]
		shift = l11l11l1ll_l1_+sep
	elif level in [l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㇈"),l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ㇉")]: lines = message.split(l11l11l1ll_l1_)
	shift += 6*l11l11l1ll_l1_
	l1l11l11l1l_l1_ = 3*l11l11l1ll_l1_
	if kodi_version>17.99: shift += 11*l1l111_l1_ (u"࠭ࠠࠨ㇊")
	l1l1l1lll11_l1_ = lines[0]
	for line in lines[1:]:
		if l1l111_l1_ (u"ࠧ࡝ࡰࠪ㇋") in line: line = line.replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㇌"),l1l111_l1_ (u"ࠩ࡟ࡲࠬ㇍")+l11l11l1ll_l1_+l11l11l1ll_l1_)
		l1l11l11l1l_l1_ += l11l11l1ll_l1_
		l1l1l1lll11_l1_ += l1l111_l1_ (u"ࠪࡠࡷ࠭㇎")+shift+l1l11l11l1l_l1_+line
	l1l1l1lll11_l1_ += l1l111_l1_ (u"ࠫࠥࡥࠧ㇏")
	if l1l111_l1_ (u"ࠬࠫࠧ㇐") in l1l1l1lll11_l1_: l1l1l1lll11_l1_ = l111l11_l1_(l1l1l1lll11_l1_)
	xbmc.log(l1l1l1lll11_l1_,level=l1l11l111l1_l1_)
	return
def l1l1ll1l111_l1_(l1lll1111l_l1_):
	conn = sqlite3.connect(l1lll1111l_l1_)
	l1lllll1ll_l1_ = conn.cursor()
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡡࡶࡶࡲࡱࡦࡺࡩࡤࡡ࡬ࡲࡩ࡫ࡸ࠾ࡰࡲ࠿ࠬ㇑"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪ㇒"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡ࡫ࡪࡲࡴࡸࡥࡠࡥ࡫ࡩࡨࡱ࡟ࡤࡱࡱࡷࡹࡸࡡࡪࡰࡷࡷࡂࡿࡥࡴ࠽ࠪ㇓"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡭ࡳࡺࡸ࡮ࡢ࡮ࡢࡱࡴࡪࡥ࠾ࡑࡉࡊࡀ࠭㇔"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡸࡪࡳࡰࡠࡵࡷࡳࡷ࡫࠽ࡎࡇࡐࡓࡗ࡟࠻ࠨ㇕"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤࡸࡿ࡮ࡤࡪࡵࡳࡳࡵࡵࡴ࠿ࡒࡊࡋࡁࠧ㇖"))
	conn.text_factory = str
	return conn,l1lllll1ll_l1_
def l1lll1111ll_l1_(l1lll1111l_l1_,table,l1l1l1111ll_l1_=None):
	try: conn,l1lllll1ll_l1_ = l1l1ll1l111_l1_(l1lll1111l_l1_)
	except: return
	if l1l1l1111ll_l1_==None: l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠬࡊࡒࡐࡒࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡋࡘࡊࡕࡗࡗࠥࠨࠧ㇗")+table+l1l111_l1_ (u"࠭ࠢࠡ࠽ࠪ㇘"))
	else:
		tt = (str(l1l1l1111ll_l1_),)
		try:
			if l1l111_l1_ (u"ࠧࠦࠩ㇙") in l1l1l1111ll_l1_: l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㇚")+table+l1l111_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡰ࡮ࡱࡥࠡࡁࠣ࠿ࠬ㇛"),tt)
			else: l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ㇜")+table+l1l111_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ㇝"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
class l1l1l1llll1_l1_(): pass
class l1l1ll1l1l1_l1_(l1l1l1llll1_l1_):
	def __init__(self):
		self.url = l1l111_l1_ (u"ࠬ࠭㇞")
		self.code = -99
		self.reason = l1l111_l1_ (u"࠭ࠧ㇟")
		self.content = l1l111_l1_ (u"ࠧࠨ㇠")
		self.headers = {}
		self.cookies = {}
		self.succeeded = False
def l1l1l1111l1_l1_(type):
	if type==l1l111_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭㇡"): data = {}
	elif type==l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㇢"): data = []
	elif type==l1l111_l1_ (u"ࠪࡷࡹࡸࠧ㇣"): data = l1l111_l1_ (u"ࠫࠬ㇤")
	elif type==l1l111_l1_ (u"ࠬ࡯࡮ࡵࠩ㇥"): data = 0
	elif type==l1l111_l1_ (u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ㇦"): data = l1l1ll1l1l1_l1_()
	elif not type: data = None
	else: data = None
	return data
def l1ll1ll1l11_l1_(l1lll1111l_l1_,l1l1l11lll1_l1_,table,l1l1l1111ll_l1_=None):
	data = l1l1l1111l1_l1_(l1l1l11lll1_l1_)
	cache = settings.getSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ㇧"))
	if table!=l1l111_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ㇨") and l1lll1111l_l1_==main_dbfile:
		if cache==l1l111_l1_ (u"ࠩࡖࡘࡔࡖࠧ㇩"): return data
		l1ll11lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ㇪"))
		if l1ll11lll1_l1_==l1l111_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ㇫"):
			l1lll1111ll_l1_(l1lll1111l_l1_,table,l1l1l1111ll_l1_)
			return data
	l1l1lll1ll1_l1_ = 0
	if cache==l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㇬"): l1l1lll1ll1_l1_ = l1l111lllll_l1_
	try: conn,l1lllll1ll_l1_ = l1l1ll1l111_l1_(l1lll1111l_l1_)
	except: return data
	l1l11llll11_l1_ = True
	try: l1lllll1ll_l1_.execute(l1l111_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࠢࠨ㇭")+table+l1l111_l1_ (u"ࠧࠣࠢࡏࡍࡒࡏࡔࠡ࠳ࠣ࠿ࠬ㇮"))
	except: l1l11llll11_l1_ = False
	if l1l11llll11_l1_:
		if l1l1lll1ll1_l1_: l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ㇯")+table+l1l111_l1_ (u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫㇰ")+str(now+l1l1lll1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࡀ࠭ㇱ"))
		conn.commit()
		l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫㇲ")+table+l1l111_l1_ (u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧㇳ")+str(now)+l1l111_l1_ (u"࠭ࠠ࠼ࠩㇴ"))
		conn.commit()
		if l1l1l1111ll_l1_:
			tt = (str(l1l1l1111ll_l1_),)
			l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬㇵ")+table+l1l111_l1_ (u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨㇶ"),tt)
			l1l11ll1lll_l1_ = l1lllll1ll_l1_.fetchall()
			if l1l11ll1lll_l1_:
				try:
					text = zlib.decompress(l1l11ll1lll_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧㇷ")+table+l1l111_l1_ (u"ࠪࠦࠥࡁࠧㇸ"))
			l1l11ll1lll_l1_ = l1lllll1ll_l1_.fetchall()
			if l1l11ll1lll_l1_:
				data,l1l1ll11lll_l1_ = {},[]
				for l1l1l1ll1ll_l1_,l1l11llll_l1_ in l1l11ll1lll_l1_:
					l1ll1lll1l_l1_ = zlib.decompress(l1l11llll_l1_)
					l1l11llll_l1_ = pickle.loads(l1ll1lll1l_l1_)
					data[l1l1l1ll1ll_l1_] = l1l11llll_l1_
					l1l1ll11lll_l1_.append(l1l1l1ll1ll_l1_)
				if l1l1ll11lll_l1_:
					data[l1l111_l1_ (u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬㇹ")] = l1l1ll11lll_l1_
					if l1l1l11lll1_l1_==l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪㇺ"): data = l1l1ll11lll_l1_
	conn.close()
	return data
l1l11l1l1ll_l1_ = l1l111_l1_ (u"࠭ࠧㇻ")
def l1l11lll1l1_l1_():
	global l1l11l1l1ll_l1_
	from getmac import get_mac_address
	l1l11l1l1ll_l1_ = get_mac_address()
	return
def l1l1l1l1lll_l1_(l1l1l111l1l_l1_,l1l1ll1111l_l1_=True):
	l1l1111lll1_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡏࡧࡷࡻࡴࡸ࡫࠯ࡋࡓࡅࡩࡪࡲࡦࡵࡶࠫㇼ"))
	l1l1l1ll11l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵ࡭ࡪࡴࡤ࡭ࡻࡑࡥࡲ࡫ࠧㇽ"))
	if l1l1ll1111l_l1_:
		try: l1l1l1l1l1_l1_,l1l1ll11l11_l1_,l1l11l11l11_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠩ࡯࡭ࡸࡺࠧㇾ"),l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ㇿ"),l1l111_l1_ (u"ࠫࡎࡊࡓࠨ㈀"))
		except: l1l1l1l1l1_l1_,l1l1ll11l11_l1_,l1l11l11l11_l1_ = l1l111_l1_ (u"ࠬ࠭㈁"),l1l111_l1_ (u"࠭ࠧ㈂"),l1l111_l1_ (u"ࠧࠨ㈃")
		if l1l1l1l1l1_l1_ and l1l1111lll1_l1_==l1l1ll11l11_l1_ and l1l1l1ll11l_l1_==l1l11l11l11_l1_: return l1l1l1l1l1_l1_
	global l1l11l1l1ll_l1_
	l1l1l111l1l_l1_ = l1l1l111l1l_l1_//2
	from threading import Thread
	l1l111lll11_l1_ = Thread(target=l1l11lll1l1_l1_,args=())
	l1l111lll11_l1_.start()
	for l1l11l111l_l1_ in range(10):
		time.sleep(0.5)
		if l1l11l1l1ll_l1_:
			l1l11l1l1ll_l1_ = l1l11l1l1ll_l1_.replace(l1l111_l1_ (u"ࠨ࠼ࠪ㈄"),l1l111_l1_ (u"ࠩࠪ㈅"))
			l1l1l1ll111_l1_ = str(int(l1l11l1l1ll_l1_,16))
			break
	else: l1l1l1ll111_l1_ = l1l111_l1_ (u"ࠪ࠴࠵࠷࠱࠳࠴࠶࠷࠹࠺࠵࠶࠸࠹࠻࠼࠭㈆")
	l1l1l1ll111_l1_ = re.findall(l1l111_l1_ (u"ࠫࡠ࠶࠭࠺࡟࠮ࠫ㈇"),l1l1l1ll111_l1_,re.DOTALL)
	l1l1l1ll111_l1_ = l1l1l111l1l_l1_*l1l111_l1_ (u"ࠬ࠶ࠧ㈈")+l1l1l1ll111_l1_[0]
	l1l1l1ll111_l1_ = l1l1l1ll111_l1_[-l1l1l111l1l_l1_:]
	mm,ss = l1l111_l1_ (u"࠭ࠧ㈉"),l1l111_l1_ (u"ࠧࠨ㈊")
	l1l11ll1l11_l1_ = str(int(l1l111_l1_ (u"ࠨ࠻ࠪ㈋")*(l1l1l111l1l_l1_+1))-int(l1l1l1ll111_l1_))[-l1l1l111l1l_l1_:]
	for l1l11l111l_l1_ in list(range(0,l1l1l111l1l_l1_,4)):
		l1l111llll1_l1_ = l1l11ll1l11_l1_[l1l11l111l_l1_:l1l11l111l_l1_+4]
		mm += l1l111llll1_l1_+l1l111_l1_ (u"ࠩ࠰ࠫ㈌")
		ss += str(sum(map(int,l1l1l1ll111_l1_[l1l11l111l_l1_:l1l11l111l_l1_+4]))%10)
	l1l1ll1l1ll_l1_ = mm+ss
	l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭㈍"),l1l111_l1_ (u"ࠫࡎࡊࡓࠨ㈎"),[l1l1ll1l1ll_l1_,l1l1111lll1_l1_,l1l1l1ll11l_l1_],l1ll1ll1_l1_)
	return l1l1ll1l1ll_l1_
def l1l11l1ll1l_l1_(l1l1ll1lll1_l1_):
	l1l11l1l1l1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ㈏"))
	user = l1l1l1l1lll_l1_(32)
	from hashlib import md5
	l1l1l11ll1l_l1_ = md5((l1l111_l1_ (u"࠭ࡘ࠲࠻ࠪ㈐")+l1l1ll1lll1_l1_+l1l111_l1_ (u"ࠧ࠲࠺ࡀࠫ㈑")+user).encode(l1l111_l1_ (u"ࠨࡷࡷࡪ࠽࠭㈒"))).hexdigest()[:32]
	if l1l1l11ll1l_l1_ in l1l11l1l1l1_l1_: return True
	return False
class l1l1l11l1l1_l1_(l1l1l1ll1l1_l1_):
	def __init__(self): self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠩࠪ㈓")
	def init(self,l1l11l11lll_l1_):
		self.l1l11l11lll_l1_ = l1l11l11lll_l1_
		self.l1l1lll11ll_l1_ = l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠪࡇ࡙ࡋ࠹ࡅࡕ࠴࠽࡛࡛࠰ࡗࡕ࡛ࠫ㈔"))
		self.l1l1l1l1l11_l1_ = l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠫ࡜࡙ࡕࡓࡈࡗ࠵࠾ࡗࡔࡆࡈ࡝࡜ࠬ㈕"))
		self.l1l1l111l11_l1_ = l1l11l1ll1l_l1_(l1l111_l1_ (u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡕࡓࡘࡑ࡙ࡘ࡛࠵ࡉ࡚ࠪ㈖"))
		if self.l1l1lll11ll_l1_: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧ㈗")
		elif self.l1l1l1l1l11_l1_: return
		elif self.l1l1l111l11_l1_:
			from l1l11lll11l_l1_ import l1l1l11l11l_l1_
			l1l1l11l11l_l1_(False)
		else:
			self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㈘")
			from l1l11lll11l_l1_ import l1l1l11l11l_l1_
			l1l1l11l11l_l1_(False)
	def onPlayBackStopped(self): self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ㈙")
	def onPlayBackError(self): self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㈚")
	def onPlayBackEnded(self): self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ㈛")
	def onPlayBackStarted(self):
		self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ㈜")
		from threading import Thread
		l1l111l1ll1_l1_ = Thread(target=self.l1l111ll1ll_l1_,args=())
		l1l111l1ll1_l1_.start()
	def l1l1ll11l1l_l1_(self):
		if self.l1l1lll11ll_l1_: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭㈝")
		elif self.l1l1l1l1l11_l1_: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㈞")
		elif self.l1l1l111l11_l1_: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㈟")
		else: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ㈠")
	def l1l111ll1ll_l1_(self):
		l1l1l111ll1_l1_ = 0
		while not eval(l1l111_l1_ (u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬ㈡")) and self.l1l1lll11l1_l1_==l1l111_l1_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ㈢"):
			xbmc.sleep(1500)
			l1l1l111ll1_l1_ += 1.5
			if l1l1l111ll1_l1_>60: return
		if self.l1l1lll11ll_l1_: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬ㈣")
		elif self.l1l1l1l1l11_l1_: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭㈤")
		elif self.l1l1l111l11_l1_:
			self.l1l1lll11l1_l1_ = l1l111_l1_ (u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ㈥")
			from LIBSTWO import l1l1l1l1ll1_l1_,l1l1111llll_l1_
			from threading import Thread
			l1l111l1l1l_l1_ = Thread(target=l1l1l1l1ll1_l1_,args=(self.l1l11l11lll_l1_,))
			l1l111l1l1l_l1_.start()
			l1l111l1lll_l1_ = Thread(target=l1l1111llll_l1_,args=())
			l1l111l1lll_l1_.start()
		else: self.l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ㈦")
def l1l1l11llll_l1_(type,url,data,headers,source,method):
	l1ll1ll1l_l1_ = str(headers)[0:250].replace(l1l111_l1_ (u"ࠨ࡞ࡱࠫ㈧"),l1l111_l1_ (u"ࠩ࡟ࡠࡳ࠭㈨")).replace(l1l111_l1_ (u"ࠪࡠࡷ࠭㈩"),l1l111_l1_ (u"ࠫࡡࡢࡲࠨ㈪")).replace(l1l111_l1_ (u"ࠬࠦࠠࠡࠢࠪ㈫"),l1l111_l1_ (u"࠭ࠠࠨ㈬")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠫ㈭"),l1l111_l1_ (u"ࠨࠢࠪ㈮"))
	if len(str(headers))>250: l1ll1ll1l_l1_ = l1ll1ll1l_l1_+l1l111_l1_ (u"ࠩࠣ࠲࠳࠴ࠧ㈯")
	l1l11llll_l1_ = str(data)[0:250].replace(l1l111_l1_ (u"ࠪࡠࡳ࠭㈰"),l1l111_l1_ (u"ࠫࡡࡢ࡮ࠨ㈱")).replace(l1l111_l1_ (u"ࠬࡢࡲࠨ㈲"),l1l111_l1_ (u"࠭࡜࡝ࡴࠪ㈳")).replace(l1l111_l1_ (u"ࠧࠡࠢࠣࠤࠬ㈴"),l1l111_l1_ (u"ࠨࠢࠪ㈵")).replace(l1l111_l1_ (u"ࠩࠣࠤࠥ࠭㈶"),l1l111_l1_ (u"ࠪࠤࠬ㈷"))
	if len(str(data))>250: l1l11llll_l1_ = l1l11llll_l1_+l1l111_l1_ (u"ࠫࠥ࠴࠮࠯ࠩ㈸")
	l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㈹"),l1l111_l1_ (u"࠭࠮ࠡࠢࡒࡔࡊࡔࡕࡓࡎࡢࠫ㈺")+type+l1l111_l1_ (u"ࠧࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㈻")+url+l1l111_l1_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ㈼")+source+l1l111_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡧࡷ࡬ࡴࡪ࠺ࠡ࡝ࠣࠫ㈽")+method+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭㈾")+str(l1ll1ll1l_l1_)+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡇࡥࡹࡧ࠺ࠡ࡝ࠣࠫ㈿")+l1l11llll_l1_+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㉀"))
	return
def l1l111l1111_l1_(method,url,data=l1l111_l1_ (u"࠭ࠧ㉁"),headers=l1l111_l1_ (u"ࠧࠨ㉂"),source=l1l111_l1_ (u"ࠨࠩ㉃")):
	l1l1l11llll_l1_(l1l111_l1_ (u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡓࡕࡋࡎࡠࡗࡕࡐࠬ㉄"),url,data,headers,source,method)
	if kodi_version>18.99: import urllib.request as l1l1ll11111_l1_
	else: import urllib2 as l1l1ll11111_l1_
	if not headers: headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㉅"):l1l111_l1_ (u"ࠫࠬ㉆")}
	if not data: data = {}
	if method==l1l111_l1_ (u"ࠬࡍࡅࡕࠩ㉇"):
		url = url+l1l111_l1_ (u"࠭࠿ࠨ㉈")+l1lllll11_l1_(data)
		data = None
	elif method==l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㉉") and l1l111_l1_ (u"ࠨ࡬ࡶࡳࡳ࠭㉊") in str(headers):
		from json import dumps
		data = dumps(data)
		data = str(data).encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㉋"))
	elif method==l1l111_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ㉌"):
		data = l1lllll11_l1_(data)
		data = data.encode(l1l111_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㉍"))
	try:
		req = l1l1ll11111_l1_.Request(url,headers=headers,data=data)
		response = l1l1ll11111_l1_.urlopen(req)
		html = response.read()
		code,reason = 200,l1l111_l1_ (u"ࠬࡕࡋࠨ㉎")
	except:
		html = l1l111_l1_ (u"࠭ࠧ㉏")
		code,reason = -1,l1l111_l1_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡇࡵࡶࡴࡸࠧ㉐")
	l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㉑"),l1l111_l1_ (u"ࠩ࠱ࠤࠥࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡖࡔࡔࡔࡓࡆࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ㉒")+str(code)+l1l111_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ㉓")+reason+l1l111_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭㉔")+source+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㉕")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㉖"))
	if html and kodi_version>18.99: html = html.decode(l1l111_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㉗"))
	return html
def l1l1ll1ll1l_l1_(l1l11l1l111_l1_,l1l11l1l11l_l1_=l1l111_l1_ (u"ࠨࠩ㉘")):
	l1l11l11ll1_l1_ = str(random.randrange(111111111111,999999999999))
	headers = {l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㉙"):l1l111_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭㉚")}
	l1l1111l11l_l1_ = {	l1l111_l1_ (u"ࠦࡺࡹࡥࡳࡡ࡬ࡨࠧ㉛"):l1l1l1l1lll_l1_(32),
				l1l111_l1_ (u"ࠧࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠤ㉜"):str(kodi_version),
				l1l111_l1_ (u"ࠨࡡࡱࡲࡢࡺࡪࡸࡳࡪࡱࡱࠦ㉝"):l1l11l11111_l1_,
				l1l111_l1_ (u"ࠢࡥࡧࡹ࡭ࡨ࡫࡟ࡧࡣࡰ࡭ࡱࡿࠢ㉞"):l1l11l11111_l1_,
				l1l111_l1_ (u"ࠣࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠧ㉟"):l1l11l1l111_l1_,
				l1l111_l1_ (u"ࠤࡨࡺࡪࡴࡴࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧ㉠"):{l1l111_l1_ (u"ࠥࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ㉡"):l1l11l1l111_l1_},
				l1l111_l1_ (u"ࠦࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ㉢"): {l1l111_l1_ (u"࡛ࠧࡳࡦࡴࡢࡉࡻ࡫࡮ࡵࡡࡑࡥࡲ࡫ࠢ㉣"):l1l11l1l111_l1_},
				l1l111_l1_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣ㉤"): l1l111_l1_ (u"ࠢࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ࡙ࠢ㉥"),
				l1l111_l1_ (u"ࠣࠦࡶ࡯࡮ࡶ࡟ࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࡡࡶࡽࡳࡩࠢ㉦"):False,
				l1l111_l1_ (u"ࠤ࡬ࡴࠧ㉧"): l1l111_l1_ (u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ㉨")
			}
	if not l1l11l1l11l_l1_: l1l111ll11l_l1_ = [l1l1111l11l_l1_]
	else:
		l1l1111l1l1_l1_ = l1l1111l11l_l1_.copy()
		l1l1111l1l1_l1_[l1l111_l1_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨ㉩")] = l1l11l1l11l_l1_
		l1l1111l1l1_l1_[l1l111_l1_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨ㉪")] = {l1l111_l1_ (u"ࠨࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㉫"):l1l11l1l11l_l1_}
		l1l1111l1l1_l1_[l1l111_l1_ (u"ࠧࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ㉬")] = {l1l111_l1_ (u"ࠣࡗࡶࡩࡷࡥࡅࡷࡧࡱࡸࡤࡔࡡ࡮ࡧࠥ㉭"):l1l11l1l11l_l1_}
		l1l111ll11l_l1_ = [l1l1111l11l_l1_,l1l1111l1l1_l1_]
	data = {l1l111_l1_ (u"ࠤࡤࡴ࡮ࡥ࡫ࡦࡻࠥ㉮"):l1l111_l1_ (u"ࠪ࠶࠺࠺ࡤࡥ࠵ࡤ࠸࠵࠿ࡤ࠹ࡤ࠹࠼࠶ࡪ࠴ࡦ࠳࠴࠻ࡪ࡫࠷࠹ࡥࡨࡦ࡫࠸࠹ࠨ㉯"),
			l1l111_l1_ (u"ࠦ࡮ࡴࡳࡦࡴࡷࡣ࡮ࡪࠢ㉰"):l1l11l11ll1_l1_,
			l1l111_l1_ (u"ࠧ࡫ࡶࡦࡰࡷࡷࠧ㉱"): l1l111ll11l_l1_
		}
	url = l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ㉲")
	html = l1l111l1111_l1_(l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬ㉳"),url,data,headers,l1l111_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭㉴"))
	return html
def l1ll1l1_l1_(l1l1l11lll1_l1_,text):
	text = text.replace(l1l111_l1_ (u"ࠩࡱࡹࡱࡲࠧ㉵"),l1l111_l1_ (u"ࠪࡒࡴࡴࡥࠨ㉶"))
	text = text.replace(l1l111_l1_ (u"ࠫࡹࡸࡵࡦࠩ㉷"),l1l111_l1_ (u"࡚ࠬࡲࡶࡧࠪ㉸"))
	text = text.replace(l1l111_l1_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ㉹"),l1l111_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭㉺"))
	text = text.replace(l1l111_l1_ (u"ࠨ࡞࠲ࠫ㉻"),l1l111_l1_ (u"ࠩ࠲ࠫ㉼"))
	try: l1ll1lll1l_l1_ = eval(text)
	except: l1ll1lll1l_l1_ = l1l1l1111l1_l1_(l1l1l11lll1_l1_)
	return l1ll1lll1l_l1_
def l1l1l1l111l_l1_():
	type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l1l111_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦ࡜࡜࠱ࡆࡓࡑࡕࡒ࡝࡟ࠪ㉽"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l1l111_l1_ (u"ࠫࡤࠫ࡭࠯ࠧࡧࡣࠪࡎ࠺ࠦࡏࡢࠫ㉾"),time.localtime(now))
	name = name+datetime
	l1ll1ll11l1_l1_ = type,name,url,mode,l11l_l1_,l1llllll1_l1_,text,context,l1llll11l11_l1_
	if os.path.exists(l1l11llll1l_l1_):
		l1l11l1ll11_l1_ = open(l1l11llll1l_l1_,l1l111_l1_ (u"ࠬࡸࡢࠨ㉿")).read()
		if kodi_version>18.99: l1l11l1ll11_l1_ = l1l11l1ll11_l1_.decode(l1l111_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㊀"))
		l1l11l1ll11_l1_ = l1ll1l1_l1_(l1l111_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ㊁"),l1l11l1ll11_l1_)
	else: l1l11l1ll11_l1_ = {}
	l1l11l1111l_l1_ = {}
	for l1l1ll111ll_l1_ in list(l1l11l1ll11_l1_.keys()):
		if l1l1ll111ll_l1_!=type: l1l11l1111l_l1_[l1l1ll111ll_l1_] = l1l11l1ll11_l1_[l1l1ll111ll_l1_]
		else:
			if name and name!=l1l111_l1_ (u"ࠨ࠰࠱ࠫ㊂"):
				l1l111lll1l_l1_ = l1l11l1ll11_l1_[l1l1ll111ll_l1_]
				if l1ll1ll11l1_l1_ in l1l111lll1l_l1_:
					index = l1l111lll1l_l1_.index(l1ll1ll11l1_l1_)
					del l1l111lll1l_l1_[index]
				l1111l1ll1_l1_ = [l1ll1ll11l1_l1_]+l1l111lll1l_l1_
				l1111l1ll1_l1_ = l1111l1ll1_l1_[:50]
				l1l11l1111l_l1_[l1l1ll111ll_l1_] = l1111l1ll1_l1_
			else: l1l11l1111l_l1_[l1l1ll111ll_l1_] = l1l11l1ll11_l1_[l1l1ll111ll_l1_]
	if type not in list(l1l11l1111l_l1_.keys()): l1l11l1111l_l1_[type] = [l1ll1ll11l1_l1_]
	l1l11l1111l_l1_ = str(l1l11l1111l_l1_)
	if kodi_version>18.99: l1l11l1111l_l1_ = l1l11l1111l_l1_.encode(l1l111_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ㊃"))
	open(l1l11llll1l_l1_,l1l111_l1_ (u"ࠪࡻࡧ࠭㊄")).write(l1l11l1111l_l1_)
	return
def l1ll1l1ll11_l1_(l1lll1111l_l1_,table,l1l1l1111ll_l1_,data,l1l1l11ll11_l1_,l1l1l1lllll_l1_=False):
	cache = settings.getSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭㊅"))
	if cache==l1l111_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭㊆") and l1l1l11ll11_l1_>l1l111lllll_l1_: l1l1l11ll11_l1_ = l1l111lllll_l1_
	if l1l1l1lllll_l1_:
		l1l11ll11_l1_,l1l11ll1l_l1_ = [],[]
		for l1l11l111l_l1_ in range(len(l1l1l1111ll_l1_)):
			text = pickle.dumps(data[l1l11l111l_l1_])
			l1l11l111ll_l1_ = zlib.compress(text)
			l1l11ll11_l1_.append((l1l1l1111ll_l1_[l1l11l111l_l1_],))
			l1l11ll1l_l1_.append((l1l1l11ll11_l1_+now,str(l1l1l1111ll_l1_[l1l11l111l_l1_]),l1l11l111ll_l1_))
	else:
		text = pickle.dumps(data)
		l1l1l11l111_l1_ = zlib.compress(text)
	try: conn,l1lllll1ll_l1_ = l1l1ll1l111_l1_(l1lll1111l_l1_)
	except: return
	while True:
		try:
			l1lllll1ll_l1_.execute(l1l111_l1_ (u"࠭ࡂࡆࡉࡌࡒࠥࡏࡍࡎࡇࡇࡍࡆ࡚ࡅࠡࡖࡕࡅࡓ࡙ࡁࡄࡖࡌࡓࡓࠦ࠻ࠨ㊇"))
			break
		except: time.sleep(0.5)
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠧࡄࡔࡈࡅ࡙ࡋࠠࡕࡃࡅࡐࡊࠦࡉࡇࠢࡑࡓ࡙ࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ㊈")+table+l1l111_l1_ (u"ࠨࠤࠣࠬࡪࡾࡰࡪࡴࡼ࠰ࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠫࠣ࠿ࠬ㊉"))
	if l1l1l1lllll_l1_:
		l1lllll1ll_l1_.executemany(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ㊊")+table+l1l111_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㊋"),l1l11ll11_l1_)
		l1lllll1ll_l1_.executemany(l1l111_l1_ (u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫ㊌")+table+l1l111_l1_ (u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪ㊍"),l1l11ll1l_l1_)
	else:
		if l1l1l11ll11_l1_:
			tt = (str(l1l1l1111ll_l1_),)
			l1lllll1ll_l1_.execute(l1l111_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭㊎")+table+l1l111_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ㊏"),tt)
			tt = (l1l1l11ll11_l1_+now,str(l1l1l1111ll_l1_),l1l1l11l111_l1_)
			l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ㊐")+table+l1l111_l1_ (u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ㊑"),tt)
		else:
			tt = (l1l1l11l111_l1_,str(l1l1l1111ll_l1_))
			l1lllll1ll_l1_.execute(l1l111_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣࠦࠬ㊒")+table+l1l111_l1_ (u"ࠫࠧࠦࡓࡆࡖࠣࡨࡦࡺࡡࠡ࠿ࠣࡃࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ㊓"),tt)
	conn.commit()
	conn.close()
	return
def l1lllll11_l1_(data):
	if kodi_version>18.99: import urllib.parse as l1l1ll1l11l_l1_
	else: import urllib as l1l1ll1l11l_l1_
	l1l1lll111l_l1_ = l1l1ll1l11l_l1_.urlencode(data)
	return l1l1lll111l_l1_
l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠬ࠭㊔")
def l1llll111_l1_(l1llllll_l1_,l1ll11llll1_l1_=l1l111_l1_ (u"࠭ࠧ㊕"),l1l1111ll11_l1_=l1l111_l1_ (u"ࠧࠨ㊖")):
	l1l1l1l1111_l1_ = l1ll11llll1_l1_ not in [l1l111_l1_ (u"ࠨࡏ࠶࡙ࠬ㊗"),l1l111_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ㊘")]
	global l1l1lll11l1_l1_
	if not l1l1111ll11_l1_: l1l1111ll11_l1_ = l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㊙")
	l1l1lll11l1_l1_,l1l11ll11ll_l1_,httpd = l1l111_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠶ࠧ㊚"),l1l111_l1_ (u"ࠬ࠭㊛"),l1l111_l1_ (u"࠭ࠧ㊜")
	if len(l1llllll_l1_)==3:
		url,l1l11lll1ll_l1_,httpd = l1llllll_l1_
		if l1l11lll1ll_l1_: l1l11ll11ll_l1_ = l1l111_l1_ (u"ࠧࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿࡛ࠦࠡࠩ㊝")+l1l11lll1ll_l1_+l1l111_l1_ (u"ࠨࠢࡠࠫ㊞")
	else: url,l1l11lll1ll_l1_,httpd = l1llllll_l1_,l1l111_l1_ (u"ࠩࠪ㊟"),l1l111_l1_ (u"ࠪࠫ㊠")
	url = url.replace(l1l111_l1_ (u"ࠫࠪ࠸࠰ࠨ㊡"),l1l111_l1_ (u"ࠬࠦࠧ㊢"))
	l11l1l11l1_l1_ = l1l1111l11_l1_(url,l1ll11llll1_l1_)
	if l1ll11llll1_l1_ not in [l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㊣"),l1l111_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ㊤")]:
		if l1ll11llll1_l1_!=l1l111_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ㊥"): url = url.replace(l1l111_l1_ (u"ࠩࠣࠫ㊦"),l1l111_l1_ (u"ࠪࠩ࠷࠶ࠧ㊧"))
		l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㊨"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡱ࡮ࡤࡽ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㊩")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㊪")+l1l11ll11ll_l1_)
		if l11l1l11l1_l1_==l1l111_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㊫") and l1ll11llll1_l1_ not in [l1l111_l1_ (u"ࠨࡋࡓࡘ࡛࠭㊬"),l1l111_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㊭")]:
			headers = {l1l111_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㊮"):l1l111_l1_ (u"ࠫࠬ㊯")}
			from LIBSTWO import l1l11l1lll_l1_,l1ll11ll_l1_,l1ll1lll_l1_
			l1l1lll1_l1_,l1llll_l1_ = l1l11l1lll_l1_(url,headers)
			count = len(l1llll_l1_)
			if count>1:
				l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠤ࠭࠭㊰")+str(count)+l1l111_l1_ (u"࠭ࠠๆๆไ࠭ࠬ㊱"), l1l1lll1_l1_)
				if l11l11l_l1_ == -1:
					l1ll1lll_l1_(l1l111_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯฺฺ๋ๆࠪ㊲"),l1l111_l1_ (u"ࠨࠩ㊳"))
					return l1l1lll11l1_l1_
			else: l11l11l_l1_ = 0
			url = l1llll_l1_[l11l11l_l1_]
			if l1l1lll1_l1_[0]!=l1l111_l1_ (u"ࠩ࠰࠵ࠬ㊴"):
				l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㊵"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡀࠠ࡜ࠢࠪ㊶")+l1l1lll1_l1_[l11l11l_l1_]+l1l111_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㊷")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㊸"))
		if l1l111_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ㊹") in url: url = url+l1l111_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㊺")
		elif l1l111_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㊻") in url.lower() and l1l111_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ㊼") not in url and l1l111_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㊽") not in url:
			if l1l111_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ㊾") not in url and l1l111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ㊿") in url.lower():
				if l1l111_l1_ (u"ࠧࡽࠩ㋀") not in url: url = url+l1l111_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ㋁")
				else: url = url+l1l111_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭㋂")
			if l1l111_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ㋃") not in url.lower() and l1ll11llll1_l1_ not in [l1l111_l1_ (u"ࠫࡎࡖࡔࡗࠩ㋄"),l1l111_l1_ (u"ࠬࡓ࠳ࡖࠩ㋅")]:
				if l1l111_l1_ (u"࠭ࡼࠨ㋆") not in url: url = url+l1l111_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ㋇")
				else: url = url+l1l111_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ㋈")
	l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ㋉"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡇࡰࡶࠣࡪ࡮ࡴࡡ࡭ࠢࡸࡶࡱࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋊")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㋋"))
	l1l111l111l_l1_ = xbmcgui.ListItem()
	l1l1111ll11_l1_,l1l11ll111l_l1_,l1l1l111lll_l1_,l1l111l1l11_l1_,l1l1l1l1l1l_l1_,l1l1111ll1l_l1_,l1l11ll1111_l1_,l1l11l1lll1_l1_,l1l11lllll1_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1ll11llll1_l1_ not in [l1l111_l1_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ㋌"),l1l111_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ㋍")]:
		if kodi_version<19: l1l111l11l1_l1_ = l1l111_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࡦࡪࡤࡰࡰࠪ㋎")
		else: l1l111l11l1_l1_ = l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠭㋏")
		l1l111l111l_l1_.setProperty(l1l111l11l1_l1_, l1l111_l1_ (u"ࠩࠪ㋐"))
		l1l111l111l_l1_.setMimeType(l1l111_l1_ (u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨ㋑"))
		if kodi_version<20: l1l111l111l_l1_.setInfo(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㋒"),{l1l111_l1_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨ㋓"):l1l111_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ㋔")})
		else:
			l1l11llllll_l1_ = l1l111l111l_l1_.getVideoInfoTag()
			l1l11llllll_l1_.setMediaType(l1l111_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭㋕"))
		l1l111l111l_l1_.setArt({l1l111_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ㋖"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩ㋗"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪ㋘"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ㋙"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧ㋚"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩ㋛"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ㋜"):l1l1l1l1l1l_l1_,l1l111_l1_ (u"ࠨ࡫ࡦࡳࡳ࠭㋝"):l1l1l1l1l1l_l1_})
		if l11l1l11l1_l1_ in [l1l111_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ㋞"),l1l111_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㋟")]: l1l111l111l_l1_.setContentLookup(True)
		else: l1l111l111l_l1_.setContentLookup(False)
		from l1l11lll11l_l1_ import l1l1l1l11l1_l1_
		if l1l111_l1_ (u"ࠫࡷࡺ࡭ࡱࠩ㋠") in url:
			l1l1l1l11l1_l1_(l1l111_l1_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨ㋡"),False)
		elif l11l1l11l1_l1_==l1l111_l1_ (u"࠭࠮࡮ࡲࡧࠫ㋢") or l1l111_l1_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ㋣") in url:
			l1l1l1l11l1_l1_(l1l111_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ㋤"),False)
			l1l111l111l_l1_.setProperty(l1l111l11l1_l1_,l1l111_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ㋥"))
			l1l111l111l_l1_.setProperty(l1l111_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ㋦"),l1l111_l1_ (u"ࠫࡲࡶࡤࠨ㋧"))
		if l1l11lll1ll_l1_:
			l1l111l111l_l1_.setSubtitles([l1l11lll1ll_l1_])
	if l1l1111ll11_l1_==l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㋨") and l1ll11llll1_l1_==l1l111_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ㋩"):
		l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㋪")
		l1ll11llll1_l1_ = l1l111_l1_ (u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨ㋫")
	elif l1l1111ll11_l1_==l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㋬") and l1l11l1lll1_l1_.startswith(l1l111_l1_ (u"ࠪ࠺ࠬ㋭")):
		l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭㋮")
		l1ll11llll1_l1_ = l1ll11llll1_l1_+l1l111_l1_ (u"ࠬࡥࡄࡍࠩ㋯")
	if l1l1lll11l1_l1_!=l1l111_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㋰"): l1l1l1l111l_l1_()
	l1l11ll1l1l_l1_ = l1l1l11l1l1_l1_()
	l1l11ll1l1l_l1_.init(l1ll11llll1_l1_)
	if l1l11ll1l1l_l1_.l1l1lll11l1_l1_: l1l1lll11l1_l1_ == l1l111_l1_ (u"ࠧࠨ㋱")
	elif l1l1111ll11_l1_==l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㋲") and not l1l11l1lll1_l1_.startswith(l1l111_l1_ (u"ࠩ࠹ࠫ㋳")):
		l1l111l111l_l1_.setPath(url)
		l11lllll1l_l1_(l1l111_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㋴"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋵")+url+l1l111_l1_ (u"ࠬࠦ࡝ࠨ㋶"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1l111l111l_l1_)
	elif l1l1111ll11_l1_==l1l111_l1_ (u"࠭࡬ࡪࡸࡨࠫ㋷"):
		l11lllll1l_l1_(l1l111_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㋸"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠨࠢࠣࠤࡑ࡯ࡶࡦࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡰ࡭ࡣࡼࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ㋹")+url+l1l111_l1_ (u"ࠩࠣࡡࠬ㋺"))
		l1l11ll1l1l_l1_.play(url,l1l111l111l_l1_)
	succeeded = False
	if l1l1lll11l1_l1_==l1l111_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㋻"):
		from l1l11l1111_l1_ import l11ll111l1_l1_
		succeeded = l11ll111l1_l1_(url,l11l1l11l1_l1_,l1ll11llll1_l1_)
		if succeeded: l1l1l1l111l_l1_()
	else:
		l1l1111l1ll_l1_,l1l1lll11l1_l1_,l1l1ll1ll11_l1_,delay = 0,l1l111_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ㋼"),False,2
		if l1l1l1l1111_l1_: from LIBSTWO import l1ll1lll_l1_
		while l1l1111l1ll_l1_<30:
			l1l1lll11l1_l1_ = l1l11ll1l1l_l1_.l1l1lll11l1_l1_
			if l1l1lll11l1_l1_==l1l111_l1_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭㋽") and not l1l1ll1ll11_l1_:
				if l1l1l1l1111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭วๅใํำ๏๎ࠠๆ๊ฯ์ิ࠭㋾"),l1l111_l1_ (u"ࠧࠨ㋿"),time=500)
				l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㌀"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡴࡶࡤࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㌁")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㌂")+l1l11ll11ll_l1_)
				l1l1ll1ll11_l1_ = True
			elif l1l1lll11l1_l1_ in [l1l111_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㌃"),l1l111_l1_ (u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭㌄")]:
				if l1l1l1l1111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"࠭วๅใํำ๏๎๋ࠠ฻่่ࠬ㌅"),l1l111_l1_ (u"ࠧࠨ㌆"),time=500)
				l11lllll1l_l1_(l1l111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ㌇"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡱ࡮ࡤࡽ࡮ࡴࡧ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ㌈")+url+l1l111_l1_ (u"ࠪࠤࡢ࠭㌉")+l1l11ll11ll_l1_)
				break
			elif l1l1lll11l1_l1_==l1l111_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ㌊"):
				l11lllll1l_l1_(l1l111_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㌋"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㌌")+url+l1l111_l1_ (u"ࠧࠡ࡟ࠪ㌍")+l1l11ll11ll_l1_)
				if l1l1l1l1111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢไ๎์ࠦๅีๅ็อࠬ㌎"),l1l111_l1_ (u"ࠩࠪ㌏"),time=500)
				break
			elif l1l1lll11l1_l1_==l1l111_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ㌐"):
				l11lllll1l_l1_(l1l111_l1_ (u"ࠫࡊࡘࡒࡐࡔࠪ㌑"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࠠࠡࡆࡨࡺ࡮ࡩࡥࠡ࡫ࡶࠤࡧࡲ࡯ࡤ࡭ࡨࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ㌒")+url+l1l111_l1_ (u"࠭ࠠ࡞ࠩ㌓"))
				break
			xbmc.sleep(delay*1000)
			l1l1111l1ll_l1_ += delay
		else:
			if l1l1l1l1111_l1_: l1ll1lll_l1_(l1l111_l1_ (u"ࠧศๆไ๎ิ๐่ࠡๆ่ࠤ๏฿ๅๅࠩ㌔"),l1l111_l1_ (u"ࠨࠩ㌕"),time=500)
			l11lllll1l_l1_(l1l111_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ㌖"),l11lll1l11_l1_(l1ll1_l1_)+l1l111_l1_ (u"ࠪࠤࠥࠦࡔࡪ࡯ࡨࡳࡺࡺ࠺ࠡࠢࡘࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ㌗")+url+l1l111_l1_ (u"ࠫࠥࡣࠧ㌘")+l1l11ll11ll_l1_)
			l1l1lll11l1_l1_ = l1l111_l1_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭㌙")
	if l1l1lll11l1_l1_ in [l1l111_l1_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ㌚"),l1l111_l1_ (u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ㌛"),l1l111_l1_ (u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㌜")] or succeeded:
		if l1l1lll11l1_l1_==l1l111_l1_ (u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ㌝"): l1ll11llll1_l1_ = l1ll11llll1_l1_+l1l111_l1_ (u"ࠪࡣ࡙࡙ࠧ㌞")
		response = l1l1ll1ll1l_l1_(l1ll11llll1_l1_)
	else: exec(l1l111_l1_ (u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫ㌟"))
	return l1l1lll11l1_l1_
def l1l1111l11_l1_(url,l1l11l11_l1_=l1l111_l1_ (u"ࠬ࠭㌠")):
	l11l1l11l1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࡝࠰ࡤࡺ࡮ࢂ࡜࠯ࡶࡶࢀࡡ࠴ࡡࡢࡥࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲ࠹ࡵࡽ࡞࠱ࡱ࠸ࡻ࠸ࡽ࡞࠱ࡱࡵࡪࡼ࡝࠰ࡰ࡯ࡻࢂ࡜࠯ࡨ࡯ࡺࢁࡢ࠮࡮ࡲ࠶ࢀࡡ࠴ࡷࡦࡤࡰ࠭࠭ࢂ࡜ࡀ࠰࠭ࡃࢁ࠵࡜ࡀ࠰࠭ࡃࢁࡢࡼ࠯ࠬࡂ࠭ࠩ࠭㌡"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l11l1l11l1_l1_: l11l1l11l1_l1_ = l11l1l11l1_l1_[0][0]
	else: l11l1l11l1_l1_ = l1l111_l1_ (u"ࠧࠨ㌢")
	return l11l1l11l1_l1_
WRITE_TO_sSQL3 = l1ll1l1ll11_l1_
READ_FROM_sSQL3 = l1ll1ll1l11_l1_
DELETE_FROM_sSQL3 = l1lll1111ll_l1_
EVALl = l1ll1l1_l1_
LOGGINGg = l11lll1l11_l1_
LOGg_THIS = l11lllll1l_l1_
PLAY_VIDEOo = l1llll111_l1_
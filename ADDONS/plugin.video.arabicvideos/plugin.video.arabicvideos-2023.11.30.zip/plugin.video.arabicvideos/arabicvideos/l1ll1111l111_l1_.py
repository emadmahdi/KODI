# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬ奘")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤ࡙ࡈࡑࡡࠪ奙")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"๋ࠬีศำ฼อࠬ奚"),l1l111_l1_ (u"࠭ศฬ่ࠢฬฬฺัࠨ奛")]
def l11l1ll_l1_(mode,url,text):
	if   mode==480: l1lll_l1_ = l1l1l11_l1_()
	elif mode==481: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==482: l1lll_l1_ = PLAY(url)
	elif mode==483: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==489: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ奜"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ奝"),l1l111_l1_ (u"ࠩࠪ奞"),l1l111_l1_ (u"ࠪࠫ奟"),l1l111_l1_ (u"ࠫࠬ奠"),l1l111_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ奡"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ奢"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠧ࠰ࠩ奣"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠨࡷࡵࡰࠬ奤"))
	addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ奥"),l1lllll_l1_+l1l111_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ奦"),l1l11ll_l1_,489,l1l111_l1_ (u"ࠫࠬ奧"),l1l111_l1_ (u"ࠬ࠭奨"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ奩"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ奪"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ奫"),l1l111_l1_ (u"ࠩࠪ奬"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ奭"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭奮")+l1lllll_l1_+l1l111_l1_ (u"ࠬษอะอࠣห้๋่ศุํ฽ࠬ奯"),l1l11ll_l1_,481)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫࠥࡱࡾࡇࡣࡤࡱࡸࡲࡹࠨࠧ奰"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ奱"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠨࠥࠪ奲"): continue
		if title in l11lll_l1_: continue
		title = unescapeHTML(title)
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ女"),l1ll1_l1_+l1l111_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ奴")+l1lllll_l1_+title,l1ll1ll_l1_,481)
	return html
def l1lll11_l1_(url,l111lll1l111_l1_):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ奵"),url,l1l111_l1_ (u"ࠬ࠭奶"),l1l111_l1_ (u"࠭ࠧ奷"),l1l111_l1_ (u"ࠧࠨ奸"),l1l111_l1_ (u"ࠨࠩ她"),l1l111_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ奺"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡵࡵࡳࡵࠪ࠱࠮ࡄ࠯ࠢࡧࡱࡲࡸࡪࡸࠢࠨ奻"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ奼"),block,re.DOTALL)
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"๋ࠬิศ้าอࠬ好"),l1l111_l1_ (u"࠭แ๋ๆ่ࠫ奾"),l1l111_l1_ (u"ࠧศ฼้๎ฮ࠭奿"),l1l111_l1_ (u"ࠨล฽๊๏ฯࠧ妀"),l1l111_l1_ (u"ࠩๆ่๏ฮࠧ妁"),l1l111_l1_ (u"ࠪห฾๊ว็ࠩ如"),l1l111_l1_ (u"ࠫ์ีวโࠩ妃"),l1l111_l1_ (u"๋ࠬศศำสอࠬ妄"),l1l111_l1_ (u"ู࠭าุࠪ妅"),l1l111_l1_ (u"ࠧๆ้ิะฬ์ࠧ妆"),l1l111_l1_ (u"ࠨษ็ฬํ๋ࠧ妇"),l1l111_l1_ (u"่ࠩืึำ๊สࠩ妈")]
	l111lll1l11l_l1_ = l1l111_l1_ (u"ࠪ࠳ࠬ妉").join(l111lll1l111_l1_.strip(l1l111_l1_ (u"ࠫ࠴࠭妊")).split(l1l111_l1_ (u"ࠬ࠵ࠧ妋"))[4:]).split(l1l111_l1_ (u"࠭࠭ࠨ妌"))
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ妍"),title,re.DOTALL)
		if l111lll1l111_l1_:
			l111lllll_l1_ = l1l111_l1_ (u"ࠨ࠱ࠪ妎").join(l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠩ࠲ࠫ妏")).split(l1l111_l1_ (u"ࠪ࠳ࠬ妐"))[4:]).split(l1l111_l1_ (u"ࠫ࠲࠭妑"))
			l111lll1l1l1_l1_ = len([x for x in l111lll1l11l_l1_ if x in l111lllll_l1_])
			if l111lll1l1l1_l1_>2 and l1l111_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ妒") in l1ll1ll_l1_:
				addMenuItem(l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ妓"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
		else:
			if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪ妔"),title,re.DOTALL)
			if set(title.split()) & set(l1ll11_l1_) and l1l111_l1_ (u"ࠨ็ึุ่๊ࠧ妕") not in title:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ妖"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
			elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪั้่ษࠨ妗") in title:
				title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ妘") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妙"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"࠭ࠧ妚"),url)
					l1l1_l1_.append(title)
			else: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妛"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩ妜"),url)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠤࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠧ妝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠣ妞"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ妟"),l1l111_l1_ (u"ࠬ࠭妠"))
			if title!=l1l111_l1_ (u"࠭ࠧ妡"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妢"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧ妣")+title,l1ll1ll_l1_,481,l1l111_l1_ (u"ࠩࠪ妤"),l1l111_l1_ (u"ࠪࠫ妥"),l111lll1l111_l1_)
	return
def l1ll1l11_l1_(url,l1lllll1_l1_):
	headers = {l1l111_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ妦"):l1l111_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭妧")}
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ妨"),url,l1l111_l1_ (u"ࠧࠨ妩"),headers,l1l111_l1_ (u"ࠨࠩ妪"),l1l111_l1_ (u"ࠩࠪ妫"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ妬"))
	html = response.content
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ妭"))
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡩ࡮ࡩ࠰ࡶࡪࡹࡰࡰࡰࡶ࡭ࡻ࡫ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妮"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ妯"))
	l111lll11lll_l1_ = True
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࡙ࡥࡢࡵࡲࡲࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ妰"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳࠨ妱") not in url:
		block = l11ll1l_l1_[0]
		count = block.count(l1l111_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴ࡮ࡸ࡫ࡂ࠭妲"))
		if count==0: count = block.count(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡥࡸࡵ࡮࠾ࠩ妳"))
		if count>1:
			l111lll11lll_l1_ = False
			if l1l111_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡰࡺ࡭࠽ࠣࠩ妴") in block:
				items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡱࡻࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭妵"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡻࡵ࠲࠱࠴࠴࠳ࡹ࡫࡭ࡱ࠱ࡤ࡮ࡦࡾ࠯ࡴࡧࡤࡷࡴࡴࡳ࠳࠰ࡳ࡬ࡵࡅࡳ࡭ࡷࡪࡁࠬ妶")+id
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妷"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
			else:
				items = re.findall(l1l111_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡦࡣࡶࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ妸"),block,re.DOTALL)
				for id,title in items:
					l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡷࡱ࠵࠴࠷࠷࠯ࡵࡧࡰࡴ࠴ࡧࡪࡢࡺ࠲ࡷࡪࡧࡳࡰࡰࡶ࠲ࡵ࡮ࡰࡀࡵࡨࡶ࡮࡫ࡳࡊࡆࡀࠫ妹")+id
					addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ妺"),l1lllll_l1_+title,l1ll1ll_l1_,483,l1ll1l_l1_)
	if l111lll11lll_l1_:
		block = l1l111_l1_ (u"ࠫࠬ妻")
		if l1l111_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳ࡸ࡫ࡡࡴࡱࡱࡷࠬ妼") in url: block = html
		else:
			l11ll11_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡦࡲ࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ妽"),html,re.DOTALL)
			if l11ll11_l1_: block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妾"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠨࠢࠪ妿"))
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ姀"),l1lllll_l1_+title,l1ll1ll_l1_,482,l1ll1l_l1_)
	if not menuItemsLIST: l1lll11_l1_(l1lllll1_l1_,url)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠪ࠳ࠬ姁"))+l1l111_l1_ (u"ࠫ࠴ࡅࡤࡰ࠿ࡺࡥࡹࡩࡨࠨ姂")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ姃"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ姄"),l1l111_l1_ (u"ࠧࠨ姅"),l1l111_l1_ (u"ࠨࠩ姆"),l1l111_l1_ (u"ࠩࠪ姇"),l1l111_l1_ (u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ姈"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨ姉"))
	l1111l11l_l1_ = re.findall(l1l111_l1_ (u"ࠬࡼ࡯ࡠࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ姊"),html,re.DOTALL)
	if not l1111l11l_l1_: l1111l11l_l1_ = re.findall(l1l111_l1_ (u"࠭࡜ࠩࡶ࡫࡭ࡸࡢ࠮ࡪࡦ࡟࠰࠵ࡢࠬࠩ࠰࠭ࡃ࠮ࡢࠩࠨ始"),html,re.DOTALL)
	l1111l11l_l1_ = l1111l11l_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ姌"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭姍"),block,re.DOTALL)
		for l1111l111_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ姎"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡸࡲ࠶࠵࠸࠱࠰ࡶࡨࡱࡵ࠵ࡡ࡫ࡣࡻ࠳࡮࡬ࡲࡢ࡯ࡨ࠶࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭姏")+l1111l11l_l1_+l1l111_l1_ (u"ࠫࠫࡼࡩࡥࡧࡲࡁࠬ姐")+l1111l111_l1_[2:]+l1l111_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭姑")+title+l1l111_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ姒")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡩࡨࡸࡊࡳࡢࡦࡦࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ姓"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111l_l1_(l1ll1ll_l1_[0],l1l111_l1_ (u"ࠨࡷࡵࡰࠬ委"))
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ姕")+title+l1l111_l1_ (u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫ姖")
		l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠫ࠴࠭姗"))+l1l111_l1_ (u"ࠬ࠵࠿ࡥࡱࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ姘")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪ姙"),l1lllll1_l1_,l1l111_l1_ (u"ࠧࠨ姚"),l1l111_l1_ (u"ࠨࠩ姛"),l1l111_l1_ (u"ࠩࠪ姜"),l1l111_l1_ (u"ࠪࠫ姝"),l1l111_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ姞"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡢࡤ࡯ࡩ࠲ࡸࡥࡴࡲࡲࡲࡸ࡯ࡶࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ姟"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ姠"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ姡"))
			if l1l111_l1_ (u"ࠨࡣࡱࡥࡻ࡯ࡤࡻࠩ姢") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠩࡢࡣำอีࠨ姣")
			else: l1lllllll_l1_ = l1l111_l1_ (u"ࠪࠫ姤")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ姥")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ姦")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ姧"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠧࠨ姨")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ姩"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ姪"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ姫"),l1l111_l1_ (u"ࠫ࠰࠭姬"))
	if l1l11ll_l1_==l1l111_l1_ (u"ࠬ࠭姭"): l1l11ll_l1_ = l111l1_l1_
	url = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ姮")+search+l1l111_l1_ (u"ࠧ࠰ࠩ姯")
	l1lll11_l1_(url,l1l111_l1_ (u"ࠨࠩ姰"))
	return
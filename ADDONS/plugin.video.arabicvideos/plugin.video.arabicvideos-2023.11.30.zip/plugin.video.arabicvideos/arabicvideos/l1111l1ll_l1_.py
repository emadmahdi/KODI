# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩᚠ")
l1lllll_l1_ = l1l111_l1_ (u"ࠫࡤࡉࡃࡘࡡࠪᚡ")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧᚢ"),l1l111_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧᚣ"),l1l111_l1_ (u"ࠧหีฯ๎้࠭ᚤ"),l1l111_l1_ (u"ࠨ฻ิ์฻ࠦๅึษิ฽ฮ࠭ᚥ")]
headers = {l1l111_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᚦ"):l111l1_l1_}
def l11l1ll_l1_(mode,url,text):
	if   mode==630: l1lll_l1_ = l1l1l11_l1_()
	elif mode==631: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==632: l1lll_l1_ = PLAY(url)
	elif mode==633: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==634: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==639: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᚧ"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬᚨ"),headers,l1l111_l1_ (u"ࠬ࠭ᚩ"),l1l111_l1_ (u"࠭ࠧᚪ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᚫ"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᚬ"),l1lllll_l1_+l1l111_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩᚭ"),l1l111_l1_ (u"ࠪࠫᚮ"),639,l1l111_l1_ (u"ࠫࠬᚯ"),l1l111_l1_ (u"ࠬ࠭ᚰ"),l1l111_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᚱ"))
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᚲ"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᚳ"),l1l111_l1_ (u"ࠩࠪᚴ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᚵ"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᚶ")+l1lllll_l1_+l1l111_l1_ (u"ࠬอไๆ็ํึฮ࠭ᚷ"),l111l1_l1_,631,l1l111_l1_ (u"࠭ࠧᚸ"),l1l111_l1_ (u"ࠧࠨᚹ"),l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᚺ"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᚻ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᚼ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		if title==l1l111_l1_ (u"ࠫศำฯฬࠢส่า๊โศฬࠪᚽ"): mode,request = 631,l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫᚾ")
		else: mode,request = 634,l1l111_l1_ (u"࠭ࠧᚿ")
		addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛀ"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᛁ")+l1lllll_l1_+title,l1ll1ll_l1_,mode,l1l111_l1_ (u"ࠩࠪᛂ"),l1l111_l1_ (u"ࠪࠫᛃ"),request)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᛄ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᛅ"),l1l111_l1_ (u"࠭ࠧᛆ"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫᛇ"),html,re.DOTALL)
	block = l11llll_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨᛈ"),html,re.DOTALL)
	for l1l1l1l_l1_ in l11llll_l1_: block = block.replace(l1l1l1l_l1_,l1l111_l1_ (u"ࠩࠪᛉ"))
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᛊ"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᛋ"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᛌ")+l1lllll_l1_+title,l1ll1ll_l1_,634)
	return
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"࠭ࡇࡆࡖࠪᛍ"),url,l1l111_l1_ (u"ࠧࠨᛎ"),l1l111_l1_ (u"ࠨࠩᛏ"),l1l111_l1_ (u"ࠩࠪᛐ"),l1l111_l1_ (u"ࠪࠫᛑ"),l1l111_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᛒ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᛓ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧᛔ"),l1l111_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭ᛕ"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᛖ"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠩࠪᛗ"),block)]
		addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᛘ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᛙ"),l1l111_l1_ (u"ࠬ࠭ᛚ"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᛛ"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠧ࠻ࠢࠪᛜ")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᛝ"),l1lllll_l1_+title,l1ll1ll_l1_,631)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᛞ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᛟ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᛠ"),l1l111_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᛡ"),l1l111_l1_ (u"࠭ࠧᛢ"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᛣ"),l1lllll_l1_+title,l1ll1ll_l1_,631)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"ࠨࠩᛤ")):
	if request==l1l111_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᛥ"):
		url,search = url.split(l1l111_l1_ (u"ࠪࡃࠬᛦ"),1)
		data = l1l111_l1_ (u"ࠫࡶࡻࡥࡳࡻࡖࡸࡷ࡯࡮ࡨ࠿ࠪᛧ")+search
		headers = {l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᛨ"):l1l111_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᛩ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡑࡑࡖࡘࠬᛪ"),url,data,headers,l1l111_l1_ (u"ࠨࠩ᛫"),l1l111_l1_ (u"ࠩࠪ᛬"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭᛭"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨᛮ"),url,l1l111_l1_ (u"ࠬ࠭ᛯ"),l1l111_l1_ (u"࠭ࠧᛰ"),l1l111_l1_ (u"ࠧࠨᛱ"),l1l111_l1_ (u"ࠨࠩᛲ"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅ࡛ࡔࡘࡋ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬᛳ"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠪࠫᛴ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠫࡺࡸ࡬ࠨᛵ"))
	if request==l1l111_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪᛶ"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᛷ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1l111_l1_ (u"ࠧࠨᛸ")))
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ᛹"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡴࡲࡹࡸ࡫࡬ࡠࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᛺"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪࠫࠬࠨࡰࡰࡵࡷࡆࡱࡵࡣ࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮࠭ࠧࠨ᛻"),block,re.DOTALL)
	elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ᛼"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᛽"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ᛾"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᛿"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪᜀ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫᜁ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᜂ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1l111_l1_ (u"ࠫࠬᜃ")))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᜄ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᜅ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ࠧๆึส๋ิฯࠧᜆ"),l1l111_l1_ (u"ࠨใํ่๊࠭ᜇ"),l1l111_l1_ (u"ࠩส฾๋๐ษࠨᜈ"),l1l111_l1_ (u"ࠪ็้๐ศࠨᜉ"),l1l111_l1_ (u"ࠫฬ฿ไศ่ࠪᜊ"),l1l111_l1_ (u"ࠬํฯศใࠪᜋ"),l1l111_l1_ (u"࠭ๅษษิหฮ࠭ᜌ"),l1l111_l1_ (u"ฺࠧำูࠫᜍ"),l1l111_l1_ (u"ࠨ็๊ีัอๆࠨᜎ"),l1l111_l1_ (u"ࠩส่อ๎ๅࠨᜏ"),l1l111_l1_ (u"ุ้ࠪือ๋หࠪᜐ")]
	for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
		title = title.replace(l1l111_l1_ (u"ู๊ࠫࠥๆษࠣ็้๎ศࠨᜑ"),l1l111_l1_ (u"ࠬ࠭ᜒ"))
		title = title.replace(l1l111_l1_ (u"࠭ࠠศ๊้ࠤ้อ๊็ࠩᜓ"),l1l111_l1_ (u"ࠧࠨ᜔"))
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮᜕ࠫ"),title,re.DOTALL)
		if l1l111_l1_ (u"࡚࡛ࠩࡊ࠭᜖") in title: continue
		elif any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᜗"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ᜘"):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ᜙"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ᜚") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᜛"),l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᜜"),l1lllll_l1_+title,l1ll1ll_l1_,633,l1ll1l_l1_)
	if 1:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᜝"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᜞"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1ll1ll_l1_==l1l111_l1_ (u"ࠫࠨ࠭ᜟ"): continue
				l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠬ࠵ࠧᜠ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨᜡ"))
				title = unescapeHTML(title)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜢ"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮࠦࠧᜣ")+title,l1ll1ll_l1_,631)
	return
def l1111_l1_(url,l1l11_l1_):
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭ᜤ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᜥ"),url,l1l111_l1_ (u"ࠫࠬᜦ"),l1l111_l1_ (u"ࠬ࠭ᜧ"),l1l111_l1_ (u"࠭ࠧᜨ"),l1l111_l1_ (u"ࠧࠨᜩ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ᜪ"))
	html = response.content
	l11l_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᜫ"),html,re.DOTALL)
	if l11l_l1_: l1ll1l_l1_ = l11l_l1_[0]
	else: l1ll1l_l1_ = l1l111_l1_ (u"ࠪࠫᜬ")
	items = []
	l11l1_l1_ = False
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩࠣࡕࡨࡥࡸࡵ࡮ࡴࡇࡳ࡭ࡸࡵࡤࡦࡵࡐࡥ࡮ࡴࠧᜭ"),html,re.DOTALL)
	if l11ll1l_l1_ and not l1l11_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࠭ࠧࡰࡰࡦࡰ࡮ࡩ࡫࠾ࠤࡲࡴࡪࡴࡃࡪࡶࡼࡠ࠭࡫ࡶࡦࡰࡷ࠰࠳࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡥࡹࡹࡺ࡯࡯ࡀࠪࠫࠬᜮ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l1l111_l1_ (u"࠭ࠣࠨᜯ"))
			if len(items)>1: addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᜰ"),l1lllll_l1_+title,url,633,l1ll1l_l1_,l1l111_l1_ (u"ࠨࠩᜱ"),l1l11_l1_)
			else: l11l1_l1_ = True
	else: l11l1_l1_ = True
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࠧᜲ")+l1l11_l1_+l1l111_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᜳ"),html,re.DOTALL)
	if l11ll11_l1_ and l11l1_l1_:
		block = l11ll11_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿᜴ࠩ"),block,re.DOTALL)
		items = []
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1ll1ll_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l1l111_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᜵"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			l1ll1ll_l1_ = l1ll1ll_l1_.strip(l1l111_l1_ (u"࠭࠯ࠨ᜶"))
			title = title.replace(l1l111_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ᜷"),l1l111_l1_ (u"ࠨࠢࠪ᜸"))
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᜹"),l1lllll_l1_+title,l1ll1ll_l1_,632,l1ll1l_l1_)
	return
def PLAY(url):
	l1llll_l1_,l1ll11111_l1_,l1ll11l1_l1_ = [],[],[]
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ᜺"),l1l111_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ᜻"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ᜼"),l1lllll1_l1_,l1l111_l1_ (u"࠭ࠧ᜽"),l1l111_l1_ (u"ࠧࠨ᜾"),l1l111_l1_ (u"ࠨࠩ᜿"),l1l111_l1_ (u"ࠩࠪᝀ"),l1l111_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᝁ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬᝂ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠢᝃ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᝄ")+title+l1l111_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᝅ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lllll1_l1_ = url.replace(l1l111_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࠬᝆ"),l1l111_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠴ࡰࡩࡲࠪᝇ"))
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧᝈ"),l1lllll1_l1_,l1l111_l1_ (u"ࠫࠬᝉ"),l1l111_l1_ (u"ࠬ࠭ᝊ"),l1l111_l1_ (u"࠭ࠧᝋ"),l1l111_l1_ (u"ࠧࠨᝌ"),l1l111_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩᝍ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᝎ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭ᝏ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1llll_l1_:
				l1ll11111_l1_.append(l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᝐ")+title+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᝑ"))
				l1llll_l1_.append(l1ll1ll_l1_)
	l1lll1l_l1_ = zip(l1llll_l1_,l1ll11111_l1_)
	for l1ll1ll_l1_,name in l1lll1l_l1_: l1ll11l1_l1_.append(l1ll1ll_l1_+name)
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᝒ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠧࠨᝓ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠨࠩ᝔"): return
	search = search.replace(l1l111_l1_ (u"ࠩࠣࠫ᝕"),l1l111_l1_ (u"ࠪ࠯ࠬ᝖"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ᝗")+search
	l1lll11_l1_(url,l1l111_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ᝘"))
	return
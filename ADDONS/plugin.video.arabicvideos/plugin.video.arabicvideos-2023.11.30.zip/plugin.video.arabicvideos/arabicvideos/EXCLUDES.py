# -*- coding: utf-8 -*-
from LIBSTWO import *

script_namee = 'EXCLUDES'

def FIX_ARABIC_KODI_MENU_ITEM(namee,sitee):
	sitee = sitee.replace('[COLOR FFC89008]','').replace(' [/COLOR]','')[1:]
	found_englishh = re.findall('[a-zA-Z]',namee,re.DOTALL)
	if 'بحث IPTV - ' in namee: namee = namee.replace('بحث IPTV - ',rtl+'بحث IPTV - '+rtl)
	elif ' IPTV' in namee and sitee=='IPT': namee = rtl+namee
	elif 'بحث M3U - ' in namee: namee = namee.replace('بحث M3U - ',rtl+'بحث M3U - '+rtl)
	elif ' M3U' in namee and sitee=='M3U': namee = rtl+namee
	elif 'بحث ' in namee and ' - ' in namee: namee = rtl+namee
	elif not found_englishh:
		splitterr = re.findall('^( *?)(.*?)( *?)$',namee)
		left_spacess,middlee,right_spacess = splitterr[0]
		punct_charr = re.findall('^([!-~])',middlee)
		if punct_charr: namee = left_spacess+ltr+middlee+right_spacess
		else: namee = right_spacess+rtl+middlee+left_spacess
	else:
		if 1:
			namee_1 = namee
			namee_2 = bidi.algorithm.get_display(namee,base_dir='L')
			if kodi_version<19: namee_1 = namee_1.decode('utf8')
			if kodi_version<19: namee_2 = namee_2.decode('utf8')
			wordss_1 = namee_1.split(' ')
			wordss_2 = namee_2.split(' ')
			englishh,arabicc,sentencee,prev_langg = [],[],'',''
			zzzz = zip(wordss_1,wordss_2)
			for wordd_1,wordd_2 in zzzz:
				if wordd_1==wordd_2=='' and prev_langg:
					sentencee += ' '
					continue
				if wordd_1==wordd_2:
					langg = 'EN'
					if prev_langg==langg: sentencee += ' '+wordd_1
					elif wordd_1:
						if sentencee:
							arabicc.append(sentencee)
							englishh.append('')
						sentencee = wordd_1
				else:
					langg = 'AR'
					if prev_langg==langg: sentencee += ' '+wordd_1
					elif wordd_1:
						if sentencee:
							englishh.append(sentencee)
							arabicc.append('')
						sentencee = wordd_1
				prev_langg = langg
			if langg=='EN':
				englishh.append(sentencee)
				arabicc.append('')
			else:
				arabicc.append(sentencee)
				englishh.append('')
			new_namee = ''
			zzzz = zip(englishh,arabicc)
			for engg,arbb in zzzz:
				if engg: new_namee += ' '+engg
				else:
					punct_charr = re.findall('([!-~]) *$',arbb)
					if punct_charr:
						punct_charr = punct_charr[0]
						try:
							puct_char_mirroredd = bidi.mirror.MIRRORED[punct_charr]
							splitterr = re.findall('^( *?)(.*?)( *?)$',arbb)
							if splitterr: left_spacess,arbb,right_spacess = splitterr[0]
							arbb = left_spacess+puct_char_mirroredd+arbb[:-1]+right_spacess
						except: pass
					new_namee += ' '+arbb
			namee = new_namee[1:]
			if kodi_version<19: namee = namee.encode('utf8')
		else:
			if kodi_version<19: namee = namee.decode('utf8')
			namee = bidi.algorithm.get_display(namee)
			namee_1,namee_2 = namee,namee
			#"""
			#arabicc = re.findall('[^!-~]',letterr)
			#englishh = re.findall('[a-zA-Z]',letterr)
			#ara_puncc = re.findall('[^a-z^A-Z]',letterr)
			#eng_puncc = re.findall('[!-~]',letterr)
			#arabicc = arabicc[0] if arabicc else ''
			#englishh = englishh[0] if englishh else ''
			#ara_puncc = ara_puncc[0] if ara_puncc else ''
			#eng_puncc = eng_puncc[0] if eng_puncc else ''
			#punctuationn = eng_puncc if eng_puncc and not englishh else ''
			#"""
			if 1:
				prev_langg,sentencess = '',[]
				wordss = namee.split(' ')
				for wordd in wordss:
					if not wordd:
						if sentencess: sentencess[-1] += ' '
						else: sentencess.append('')
						continue
					first_letter_english_or_punctt = re.findall('[!-~]',wordd[0])
					if first_letter_english_or_punctt==prev_langg and sentencess: sentencess[-1] += ' '+wordd
					else:
						if sentencess:
							found_arabicc = re.findall('[^!-~]',sentencess[-1])
							if found_arabicc:
								sentencess[-1] = bidi.algorithm.get_display(sentencess[-1])
								spacess = re.findall('^ +',sentencess[-1])
								if spacess: sentencess[-1] = sentencess[-1].lstrip(' ')+spacess[0]
						sentencess.append(wordd)
					prev_langg = first_letter_english_or_punctt
				if sentencess: sentencess[-1] = bidi.algorithm.get_display(sentencess[-1])
				namee = ' '.join(sentencess)
			if kodi_version<19: namee = namee.encode('utf8')
	return namee

def GET_LIST_ITEM(menuItemm,MENUS__LAST_VIDEOS_MENUu,FAVORITES_FILE_DICTt):
	typee,namee,urll,modee,imagee,textt1,textt2,contextt,infodictt = menuItemm
	modee = int(modee)
	datetimee = re.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',namee,re.DOTALL)
	if datetimee:
		datetimee,datee,timee = datetimee[0]
		namee = namee.replace(datetimee,'')
	name_for_pathh = namee
	sitee = re.findall('^_(\w\w\w)_(.*?)$',namee,re.DOTALL)
	if sitee:
		sitee,namee = sitee[0]
		modifiedd = '_MOD_' in namee
		folderr = typee=='folder'
		if modifiedd and folderr: startt = ';'
		elif modifiedd and not folderr: startt = half_triangular_colon
		elif not modifiedd and folderr: startt = ','
		elif not modifiedd and not folderr: startt = ' '
		namee = namee.replace('_MOD_','')
		sitee = startt+'[COLOR FFC89008]'+sitee+' [/COLOR]'
	else: sitee = ''
	if datetimee:
		if kodi_version<19:
			datetimee = '[COLOR FFFFFF00]'+datee+' '+timee+'[/COLOR]'
			if sitee: namee = datetimee+' '+rtl+sitee+namee    #  datetimee+' '+sitee+rtl+namee
			else: namee = datetimee+rtl+namee+' '
		elif kodi_version>18.99:
			if sitee:
				datetimee = '[COLOR FFFFFF00]'+datee+' '+timee+'[/COLOR]'
				namee = datetimee+' '+sitee+namee
			else:
				datetimee = '[COLOR FFFFFF00]'+timee+' '+datee+'[/COLOR]'
				namee = namee+' '+rtl+datetimee
	elif sitee:
		namee = FIX_ARABIC_KODI_MENU_ITEM(namee,sitee)
		namee = sitee+namee
	menuItemm = typee,name_for_pathh,urll,str(modee),imagee,textt1,textt2,contextt,infodictt
	newpath_dictt = {'type':'','mode':'','url':'','text':'','page':'','name':'','image':'','context':'','infodict':''}
	newpath_dictt['name'] = QUOTE(name_for_pathh)
	newpath_dictt['type'] = typee.strip(' ')
	newpath_dictt['mode'] = str(modee).strip(' ')
	if typee=='folder' and textt1: newpath_dictt['page'] = QUOTE(textt1.strip(' '))
	if contextt: newpath_dictt['context'] = contextt.strip(' ')
	if textt2: newpath_dictt['text'] = QUOTE(textt2.strip(' '))
	if imagee: newpath_dictt['image'] = QUOTE(imagee.strip(' '))
	if infodictt:
		infodictt = str(infodictt)
		newpath_dictt['infodict'] = QUOTE(infodictt.strip(' '))
		infodictt = eval(infodictt)
	else: infodictt = {}
	if urll: newpath_dictt['url'] = QUOTE(urll.strip(' '))
	list_itemm = {'name':'','context_menu':'','plot':'','stars':'','image':'','type':'','isFolder':'','newpath':'','duration':''}
	context_menuu = []
	newpathh = 'plugin://'+addon_id+'/?type='+newpath_dictt['type']+'&mode='+newpath_dictt['mode']
	if newpath_dictt['page']: newpathh += '&page='+newpath_dictt['page']
	if newpath_dictt['name']: newpathh += '&name='+newpath_dictt['name']
	if newpath_dictt['text']: newpathh += '&text='+newpath_dictt['text']
	if newpath_dictt['infodict']: newpathh += '&infodict='+newpath_dictt['infodict']
	if newpath_dictt['image']: newpathh += '&image='+newpath_dictt['image']
	if newpath_dictt['url']: newpathh += '&url='+newpath_dictt['url']
	if modee!=265: list_itemm['favorites'] = True
	else: list_itemm['favorites'] = False
	if newpath_dictt['context']: newpathh += '&context='+newpath_dictt['context']
	if modee in [235,238] and typee=='live' and 'EPG' in contextt:
		run_pathh = 'plugin://'+addon_id+'?mode=238&text=SHORT_EPG&url='+urll
		run_textt = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	if modee==265:
		lengthh = MENUS__LAST_VIDEOS_MENUu(textt2,True)
		if lengthh>0:
			run_pathh = 'plugin://'+addon_id+'?mode=266&text='+textt2
			run_textt = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+TRANSLATE(textt2)+'[/COLOR]'
			run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
			context_menuu.append(run_itemm)
	if typee=='video' and modee!=331:
		run_pathh = newpathh+'&context=6_DOWNLOAD'
		run_textt = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	if modee==331:
		run_pathh = newpathh+'&context=6_DELETE'
		run_textt = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	if typee=='folder' and modee==540:
		all_wordss = READ_FROM_sSQL3(main_dbfile,'list','GLOBALSEARCH_SITES')
		if all_wordss:
			run_pathh = 'plugin://'+addon_id+'?context=7'
			run_textt = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
			context_menuu.append(run_itemm)
	MAIN_MENU_MODESs = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if modee not in MAIN_MENU_MODESs:
		run_pathh = 'plugin://'+addon_id+'?context=8&mode=260'
		run_textt = '[COLOR FFFFFF00]ذهاب للقائمة الرئيسية[/COLOR]'
		run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
		context_menuu.append(run_itemm)
	NON_SITES_MENUSs = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if modee%10 and modee!=9990:
		site_modee = modee-modee%10
		if site_modee==280: site_modee = 230
		if site_modee==410: site_modee = 400
		if site_modee==520: site_modee = 510
		if site_modee not in NON_SITES_MENUSs:
			run_pathh = 'plugin://'+addon_id+'?context=8&mode='+str(site_modee)
			run_textt = '[COLOR FFFFFF00]ذهاب لبداية الموقع[/COLOR]'
			run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
			context_menuu.append(run_itemm)
	run_pathh = newpathh+'&context=9'
	run_textt = '[COLOR FFFFFF00]تحديث القائمة الحالية[/COLOR]'
	run_itemm = (run_textt,'RunPlugin('+run_pathh+')')
	context_menuu.append(run_itemm)
	if typee in ['link','video','live']: isFolderr = False
	elif typee=='folder': isFolderr = True
	list_itemm['name'] = namee
	list_itemm['context_menu'] = context_menuu
	if 'plot' in list(infodictt.keys()): list_itemm['plot'] = infodictt['plot']
	if 'stars' in list(infodictt.keys()): list_itemm['stars'] = infodictt['stars']
	if imagee: list_itemm['image'] = imagee
	if typee=='video' and textt1:
		durationn = re.findall('[\d:]+',textt1,re.DOTALL)
		if durationn:
			durationn = '0:0:0:0:0:'+durationn[0]
			dummyy,dayss,hourss,minutess,secondss = durationn.rsplit(':',4)
			durationn2 = int(dayss)*24*HOURr+int(hourss)*HOURr+int(minutess)*60+int(secondss)
			list_itemm['duration'] = durationn2
	list_itemm['type'] = typee
	list_itemm['isFolder'] = isFolderr
	list_itemm['newpath'] = newpathh
	list_itemm['menuItem'] = menuItemm
	list_itemm['mode'] = modee
	return list_itemm

def GET_ALL_LIST_ITEMS(MENUS__LAST_VIDEOS_MENUu):
	DirectoryItems_Listt = []
	from FAVORITES import GET_ALL_FAVORITES,GET_FAVORITES_CONTEXT_MENU
	FAVORITES_FILE_DICTt = GET_ALL_FAVORITES()
	for menuItemm in menuItemsLIST:
		list_itemm = GET_LIST_ITEM(menuItemm,MENUS__LAST_VIDEOS_MENUu,FAVORITES_FILE_DICTt)
		if list_itemm['favorites']:
			fav_context_menuu = GET_FAVORITES_CONTEXT_MENU(FAVORITES_FILE_DICTt,list_itemm['menuItem'],list_itemm['newpath'])
			list_itemm['context_menu'] = fav_context_menuu+list_itemm['context_menu']
		DirectoryItems_Listt.append(list_itemm)
	return DirectoryItems_Listt

#"""
## freetranslations.org
## good but not always correct
#trans_codee = settings.getSetting('av.language.code')
#for iiii in range(len(namess)):
#	new_namess = ':::'.join(namess[iiii])
#	new_namess = new_namess.replace('ˑ','').replace(',','')
#	urll = 'https://t7.freetranslations.org/freetranslationsorg.php?p1='+src_langg+'&p2='+trans_codee+'&p3='+QUOTE(new_namess,'')
#	responsee = OPENURLl_REQUESTS_CACHED(VERYLONG_CACHEe,'GET',urll,'','','','','LIBRARY-CREATE_KODI_MENU-1st')
#	htmll = responsee.content
#	htmll = htmll.replace('] /','[/')
#	htmll = re.sub('\[ */ *C *O *L *O *R','[/COLOR',htmll)
#	htmll = re.sub('\[ *C *O *L *O *R','[COLOR',htmll)
#	htmll = re.sub(' *: *: *: *',':::',htmll)
#	htmll = htmll.replace('COLORE','COLOR')
#	translationn += htmll.split(':::')
##LOGg_THIS('',str(translationn))
#"""
#"""
## microsoft using paralink
## textt is not complete
#for iiii in range(len(namess)):
#	new_namess = ':::'.join(namess[iiii])
#	#new_namess = new_namess.replace('ˑ','').replace(',','')
#	headerss = {'Content-Type':'application/x-www-form-urlencoded'}
#	urll = 'https://translation2.paralink.com/do.asp'
#	#new_namess = new_namess.replace(' ','+')
#	dataa = 'src='+QUOTE(new_namess,'')+'+&dir=ar/en&provider=microsoft'
#	responsee = OPENURLl_REQUESTS_CACHED(VERYLONG_CACHEe,'GET',urll,dataa,headerss,'','','LIBRARY-CREATE_KODI_MENU-1st')
#	htmll = responsee.content
#	#htmll = htmll.replace('] /','[/')
#	#htmll = re.sub('\[ */ *C *O *L *O *R','[/COLOR',htmll)
#	#htmll = re.sub('\[ *C *O *L *O *R','[COLOR',htmll)
#	htmll = re.sub(' *: *: *: *',':::',htmll)
#	htmll = htmll.replace('\\','')
#	if modee==260: htmll = htmll.replace('Language_','اللغة_')
#	textt = re.findall('value="(.*?)"',htmll,re.DOTALL)
#	translationn += textt[0].split(':::')
#"""

# from https://translate.glosbe.com
def GLOSBE_TRANSLATE(liness):
	startt,resultt, = [],''
	for linee in liness:
		if not linee: startt.append('')
		else: break
	liness = liness[len(startt):]
	textt = '\n\n\n\n'.join(liness)
	textt = textt.replace('======= =======','000001')
	textt = textt.replace('[COLOR FFC89008]','000002')
	textt = textt.replace('[COLOR FFFFFF00]','000003')
	textt = textt.replace('[/COLOR]','000004')
	textt = textt.replace('[RIGHT]','000005')
	seqq = 100000
	linksListt = {}
	linkss = re.findall('http.*?[\r\n ]',textt,re.DOTALL)
	for linkk in linkss:
		seqq += 1
		textt = textt.replace(linkk,str(seqq))
		linksListt[str(seqq)] = linkk
	#"""
	#textt = textt.replace('كلا','no')
	#textt = textt.replace('استمرار','continue')
	#textt = textt.replace('[CENTER]','000006')
	#textt = textt.replace('[RTL]','000007')
	#textt = textt.replace("'","\\\\\\'")
	#textt = textt.replace('"','\\\\\\"')
	#textt = textt.replace('\n','\\n')
	#textt = textt.replace('\r','\\\\r')
	#"""
	for iiii in range(0,len(textt),4800):
		splitt = textt[iiii:iiii+4800]
		trans_codee = settings.getSetting('av.language.code')
		urll = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+trans_codee
		headerss = {'Content-Type':'text/plain'}
		dataa = splitt.encode('utf8')
		responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-GLOSBE_TRANSLATE-1st')
		if responsee.succeeded:
			htmll = responsee.content
			###htmll = htmll.decode('utf8')
			#htmll = htmll.split('\n')[-1]
			new_namess = EVALl('str',htmll)
			if new_namess:
				new_namess = new_namess['translation']
				new_namess = escapeUNICODE(new_namess)
				for jjjj in range(len(new_namess)):
					resultt += new_namess[jjjj][0]
	resultt = resultt.replace('000001','======= =======')
	resultt = resultt.replace('000002','[COLOR FFC89008]')
	resultt = resultt.replace('000003','[COLOR FFFFFF00]')
	resultt = resultt.replace('000004','[/COLOR]')
	resultt = resultt.replace('000005','[RIGHT]')
	for seqq in list(linksListt.keys()):
		linkk = linksListt[seqq]
		resultt = resultt.replace(seqq,linkk)
	#"""
	#resultt = resultt.replace('00000','0000').replace('0000','000')
	#resultt = resultt.replace('0006','[CENTER]')
	#resultt = resultt.replace('0007','[RTL]')
	#resultt = re.sub('\s*n\s*','n',resultt)
	#resultt = resultt.replace('\\n','\n')
	#resultt = resultt.replace('\\r','\r')
	#resultt = resultt.replace('\n\n\n\ ','\n\n\n\n')
	#"""
	resultt = resultt.split('\n\n\n\n')
	return startt+resultt

# from http://translate.google.com
# textt is not complete when using ':::' as separator
# it is good when using '\n' as separator
def GOOGLE_TRANSLATE(liness):
	startt,resultt, = [],''
	for linee in liness:
		if not linee: startt.append('')
		else: break
	liness = liness[len(startt):]
	textt = '\\n\\n\\n\\n'.join(liness)
	textt = textt.replace('كلا','no')
	textt = textt.replace('استمرار','continue')
	textt = textt.replace('======= =======','000001')
	textt = textt.replace('[COLOR FFC89008]','000002')
	textt = textt.replace('[COLOR FFFFFF00]','000003')
	textt = textt.replace('[/COLOR]','000004')
	textt = textt.replace('[RIGHT]','000005')
	textt = textt.replace('[CENTER]','000006')
	textt = textt.replace('[RTL]','000007')
	textt = textt.replace("'","\\\\\\'")
	textt = textt.replace('"','\\\\\\"')
	textt = textt.replace('\n','\\n')
	textt = textt.replace('\r','\\\\r')
	for iiii in range(0,len(textt),4800):
		splitt = textt[iiii:iiii+4800]
		#"""
		#urll = 'https://translate.googleapis.com/translate_a/single'
		#headerss = {'Content-Type':'application/x-www-form-urlencoded'}
		#trans_codee = settings.getSetting('av.language.code')
		#dataa = 'client=gtx&sl=ar&tl=en&dt=t&q='+QUOTE(splitt)
		#responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		#if responsee.succeeded:
		#	htmll = responsee.content
		#	#htmll = htmll.decode('utf8')
		#	htmll = htmll.split('\n')[-1]
		#	new_namess = EVALl('str',htmll)[0]
		#"""
		urll = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		headerss = {'Content-Type':'application/x-www-form-urlencoded'}
		trans_codee = settings.getSetting('av.language.code')
		dataa = 'f.req='+QUOTE('[[["MkEWBc","[[\\"'+splitt+'\\",\\"ar\\",\\"'+trans_codee+'\\",1],[]]",null,"generic"]]]','')
		#import json
		#dataa = [[["MkEWBc",'[["'+QUOTE(textt,'')+'","ar","'+trans_codee+'",1],[]]',None,"generic"]]]
		#dataa = 'f.req='+json.dumps(dataa)
		dataa = dataa.replace('%5Cn','%5C%5Cn')
		responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-GOOGLE_TRANSLATE-1st')
		if responsee.succeeded:
			htmll = responsee.content
			#htmll = htmll.decode('utf8')
			htmll = htmll.split('\n')[-1]
			new_namess = EVALl('str',htmll)[0][2]
			if new_namess:
				new_namess = EVALl('str',new_namess)[1][0][0][5]
				new_namess = escapeUNICODE(new_namess)
				for jjjj in range(len(new_namess)):
					resultt += new_namess[jjjj][0]
	resultt = resultt.replace('00000','0000').replace('0000','000')
	resultt = resultt.replace('0001','======= =======')
	resultt = resultt.replace('0002','[COLOR FFC89008]')
	resultt = resultt.replace('0003','[COLOR FFFFFF00]')
	resultt = resultt.replace('0004','[/COLOR]')
	resultt = resultt.replace('0005','[RIGHT]')
	resultt = resultt.replace('0006','[CENTER]')
	resultt = resultt.replace('0007','[RTL]')
	#"""
	#resultt = re.sub('\s*n\s*','n',resultt)
	#resultt = resultt.replace('\\n','\n')
	#resultt = resultt.replace('\\r','\r')
	#resultt = resultt.replace('\n\n\n\ ','\n\n\n\n')
	#"""
	resultt = resultt.split('\n\n\n\n')
	return startt+resultt

# from http://reverso.net
# textt is not complete when using ':::' as separator and resultt is textt
# it is good when using '\n' as separator and resultss will be list not textt
def REVERSO_TRANSLATE(liness):
	startt,new_liness = [],[]
	for linee in liness:
		if not linee: startt.append('')
		else: break
	liness = liness[len(startt):]
	textt = '\n\n\n\n'.join(liness)
	textt = textt.replace('كلا','no')
	textt = textt.replace('استمرار','continue')
	textt = textt.replace('أدناه','below')
	textt = textt.replace('[COLOR FFC89008]','00001')
	textt = textt.replace('[COLOR FFFFFF00]','00002')
	textt = textt.replace('[/COLOR]','00003')
	textt = textt.replace('=======','00004')
	textt = textt.replace(',','00005')
	textt = textt.replace('====','00006')
	#textt = textt.replace('\n','00007')
	textt = textt.replace('[RTL]','00009')
	textt = textt.replace('[CENTER]','0000A')
	textt = textt.replace('\r','0000B')
	liness = textt.split('\n')
	textt,resultt = '',''
	for linee in liness:
		if len(textt+linee)<1800: textt += '\n'+linee
		else:
			new_liness.append(textt)
			textt = linee
	new_liness.append(textt)
	from json import dumps
	for linee in new_liness:
		headerss = {'Content-Type':'application/json','User-Agent':''}
		urll = 'https://api.reverso.net/translate/v1/translation'
		trans_codee = settings.getSetting('av.language.code')
		dataa = {"format":"text","from":"ara","to":trans_codee,"input":linee,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		dataa = dumps(dataa)
		responsee = OPENURLl_REQUESTS_CACHED(NO_CACHEe,'POST',urll,dataa,headerss,'','','LIBRARY-REVERSO_TRANSLATE-1st')
		if responsee.succeeded:
			htmll = responsee.content
			#htmll = htmll.replace('\\n','')
			htmll = EVALl('dict',htmll)
			resultt += '\n'+''.join(htmll['translation'])
	resultt = resultt[2:]
	resultt = resultt.replace('000000','00000').replace('00000','0000').replace('0000','000')
	resultt = resultt.replace('0001','[COLOR FFC89008]')
	resultt = resultt.replace('0002','[COLOR FFFFFF00]')
	resultt = resultt.replace('0003','[/COLOR]')
	resultt = resultt.replace('0004','=======')
	resultt = resultt.replace('0005',',')
	resultt = resultt.replace('0006','====')
	#resultt = resultt.replace('0007','\n')
	#resultt = resultt.replace('007','\n')
	resultt = resultt.replace('0009','[RTL]')
	resultt = resultt.replace('000A','[CENTER]')
	resultt = resultt.replace('000B','\r')
	resultt = resultt.split('\n\n\n\n')
	return startt+resultt

def LANGUAGE_TRANSLATE(liness):
	do_transs = settings.getSetting('av.language.translate')
	if not do_transs or not liness: return liness
	trans_providerr = settings.getSetting('av.language.provider')
	trans_codee = settings.getSetting('av.language.code')
	table_keyy = trans_codee+'__'+str(liness)
	settings.setSetting('av.language.translate','')
	resultt = READ_FROM_sSQL3(main_dbfile,'list','TRANSLATE_'+trans_providerr,table_keyy)
	if not resultt:
		if trans_providerr=='GOOGLE': resultt = GOOGLE_TRANSLATE(liness)
		elif trans_providerr=='REVERSO': resultt = REVERSO_TRANSLATE(liness)
		elif trans_providerr=='GLOSBE': resultt = GLOSBE_TRANSLATE(liness)
		if len(liness)==len(resultt) and liness!=resultt:
			WRITE_TO_sSQL3(main_dbfile,'TRANSLATE_'+trans_providerr,table_keyy,resultt,VERYLONG_CACHEe)
		else:
			resultt = liness
			DIALOGg_NOTIFICATION('الترجمة فشلت','Translation Failed')
	settings.setSetting('av.language.translate','1')
	return resultt

def CREATE_KODI_MENU(menuItemm,DirectoryItems_Listt,succeededd,updateListingg,cacheToDiscc):
	#DirectoryItems_Objectss = READ_FROM_sSQL3(main_dbfile,'list','MENUS_OBJECTS',addon_path)
	#if not DirectoryItems_Objectss:
	typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt = menuItemm
	new_DirectoryItems_Listt = []
	do_transs = settings.getSetting('av.language.translate')
	if do_transs:
		sitess,namess,transs = [],[],[]
		if not new_DirectoryItems_Listt:
			for list_itemm in DirectoryItems_Listt:
				namee = list_itemm['name'].replace(rtl,'').replace(ltr,'')
				datetimee = re.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',namee,re.DOTALL)
				if datetimee:
					startt,datee,timee,endd,namee = datetimee[0]
					datetimee = startt+datee+' '+timee+endd+' '
				else:
					datetimee = re.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',namee,re.DOTALL)
					if datetimee:
						namee,startt,timee,datee,endd = datetimee[0]
						datetimee = startt+datee+' '+timee+endd+' '
					else: datetimee = ''
				sitee = re.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',namee,re.DOTALL)
				if sitee: sitee,namee = sitee[0]
				else: sitee = ''
				sitess.append(datetimee+sitee)
				namess.append(namee)
			transs = LANGUAGE_TRANSLATE(namess)
			if transs:
				for iiii in range(len(DirectoryItems_Listt)):
					list_itemm = DirectoryItems_Listt[iiii]
					list_itemm['name'] = sitess[iiii]+transs[iiii]
					new_DirectoryItems_Listt.append(list_itemm)
	if new_DirectoryItems_Listt: DirectoryItems_Listt = new_DirectoryItems_Listt
	DirectoryItems_Objectss = []
	for list_itemm in DirectoryItems_Listt:
		namee = list_itemm['name']
		context_menuu = list_itemm['context_menu']
		plott = list_itemm['plot']
		starss = list_itemm['stars']
		imagee = list_itemm['image']
		typee = list_itemm['type']
		durationn = list_itemm['duration']
		isFolderr = list_itemm['isFolder']
		newpathh = list_itemm['newpath']
		listitemm = xbmcgui.ListItem(namee)
		listitemm.addContextMenuItems(context_menuu)
		if imagee: listitemm.setArt({'icon':imagee,'thumb':imagee,'fanart':imagee,'banner':imagee,'clearart':imagee,'poster':imagee,'clearlogo':imagee,'landscape':imagee})
		else: listitemm.setArt({'icon':defaulticon,'thumb':defaultthumb,'fanart':defaultfanart,'banner':defaultbanner,'clearart':defaultclearart,'poster':defaultposter,'clearlogo':defaultclearlogo,'landscape':defaultlandscape})
		if kodi_version<20:
			if plott: listitemm.setInfo('video',{'Plot':plott,'PlotOutline':plott})
			if starss: listitemm.setInfo('video',{'Rating':starss})
			if not imagee:
				# needed for my skin photos menu
				listitemm.setInfo('video',{'Title':namee})
			if typee=='video':
				listitemm.setInfo('video',{'mediatype':'movie'})
				if durationn: listitemm.setInfo('video',{'duration':durationn})
				listitemm.setProperty('IsPlayable','true')
		else:
			videoinfoo = listitemm.getVideoInfoTag()
			#if plott:
			#	videoinfoo.setPlot(plott)
			#	videoinfoo.setPlotOutline(plott)
			if starss: videoinfoo.setRating(float(starss))
			if not imagee:
				# needed for my skin photos menu
				videoinfoo.setTitle(namee)
			if typee=='video':
				videoinfoo.setMediaType('tvshow')
				if durationn: videoinfoo.setDuration(durationn)
				listitemm.setProperty('IsPlayable','true')
		DirectoryItems_Objectss.append((newpathh,listitemm,isFolderr))
	xbmcplugin.setContent(addon_handle,'tvshows')
	addItems_succeededd = xbmcplugin.addDirectoryItems(addon_handle,DirectoryItems_Objectss)
	xbmcplugin.endOfDirectory(addon_handle,succeededd,updateListingg,cacheToDiscc)
	#WRITE_TO_sSQL3(main_dbfile,'MENUS_OBJECTS',[addon_path],DirectoryItems_Objectss,REGULAR_CACHEe)
	return addItems_succeededd

def addMenuItem(typee,namee,urll,modee,imagee='',pagee='',textt='',contextt='',infodictt={}):
	namee = namee.replace('\r','').replace('\n','').replace('\t','')
	urll = urll.replace('\r','').replace('\n','').replace('\t','')
	if '_SCRIPT_' in namee: script_namee,namee = namee.split('_SCRIPT_',1)
	else: script_namee,namee = '',namee
	if script_namee:
		nameonlyy = namee
		if not nameonlyy: nameonlyy = '....'
		elif nameonlyy.count('_')>1: nameonlyy = nameonlyy.split('_',2)[2]
		nameonlyy = nameonlyy.replace(' ','')
		nameonlyy = nameonlyy.replace('ـ','').replace('ة','ه').replace('ؤ','و')
		nameonlyy = nameonlyy.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		nameonlyy = nameonlyy.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		nameonlyy = nameonlyy.replace('َ','').replace('ً','').replace('ُ','').replace('ٌ','')
		nameonlyy = nameonlyy.replace('ِ','').replace('ٍ','').replace('ْ','').replace('ّ','')
		nameonlyy = nameonlyy.replace('|','').replace('~','')
		nameonlyy = nameonlyy.replace('اون لاين','').replace('سيما لايت','')
		exceptionsLISTt = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(valuee in nameonlyy for valuee in exceptionsLISTt): nameonlyy = nameonlyy.replace('ال','')
		nameonlyy = nameonlyy.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		nameonlyy = nameonlyy.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		nameonlyy = nameonlyy.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		nameonlyy = nameonlyy.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		nameonlyy = nameonlyy.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		nameonlyy = nameonlyy.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		nameonlyy = nameonlyy.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		nameonlyy = nameonlyy.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		nameonlyy = nameonlyy.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		nameonlyy = nameonlyy.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		nameonlyy = nameonlyy.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		nameonlyy = nameonlyy.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		nameonlyy = nameonlyy.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		nameonlyy = nameonlyy.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		nameonlyy = nameonlyy.replace('  ',' ').strip(' ')
		script_namee = '_LST_'+TRANSLATE(script_namee)
		if nameonlyy not in list(contentsDICT.keys()): contentsDICT[nameonlyy] = {}
		contentsDICT[nameonlyy][script_namee] = [typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt]
	menuItemsLIST.append([typee,namee,urll,modee,imagee,pagee,textt,contextt,infodictt])
	return

def unescapeHTML(stringg):
	if kodi_version>18.99: from html import unescape as _unescapeHTML
	else:
		from HTMLParser import HTMLParser
		_unescapeHTML = HTMLParser().unescape
	if '&' in stringg and ';' in stringg:
		if kodi_version<19: stringg = stringg.decode('utf8')
		stringg = _unescapeHTML(stringg)
		if kodi_version<19: stringg = stringg.encode('utf8')
	return stringg

def escapeUNICODE(stringg):
	#decode('raw_unicode_escape')
	if '\\u' in stringg:
		if kodi_version<19: stringg = stringg.decode('unicode_escape','ignore').encode('utf8')
		elif kodi_version>18.99: stringg = stringg.encode('utf8').decode('unicode_escape','ignore')
	return stringg

#=================================================================================
# the below function were added from:
# https://gitlab.com/Rgysoft/iptv-host-e2iplayer/-/blob/master/IPTVPlayer/tsiplayer/host_faselhd.py
# https://github.com/zombiB/zombi-addons/blob/master/plugin.video.matrix/resources/hosters/faselhd.py
# Thanks to the author "Rgysoft"
#=================================================================================

def DECODE_ADILBO_HTML(dataa):
	pagee = dataa
	if 'adilbo_HTML_encoder' in dataa:
		t_scriptt = re.findall('<script.*?;.*?\'(.*?);', dataa, re.S)
		t_intt = re.findall('/g.....(.*?)\)', dataa, re.S)
		if t_scriptt and t_intt:
			scriptt = t_scriptt[0].replace("'",'')
			scriptt = scriptt.replace("+",'')
			scriptt = scriptt.replace("\n",'')
			scc = scriptt.split('.')
			pagee = ''
			for elmm in scc:
				c_elmm = base64.b64decode(elmm+'==').decode("utf-8")
				t_chh = re.findall('\d+', c_elmm, re.S)
				if t_chh:
					nbb = int(t_chh[0])+int(t_intt[0])
					pagee = pagee + chr(nbb)
			if kodi_version>18.99: pagee = pagee.encode('iso-8859-1').decode('utf8')
	return pagee

#"""
## should be in exclude because it contains lots of single/double quotes
#def FIX_JSON_1(jsonStr):
#	# Remove all empty spaces to make things easier bellow
#	jsonStr = jsonStr.replace('" :','":').replace(': "',':"').replace('"\n','"').replace('" ,','",').replace(', "',',"')
#	# First remove the " from where it is supposed to be.
#	jsonStr = re.sub(r'\\"', '"', jsonStr)
#	jsonStr = re.sub(r'{"', '{`', jsonStr)
#	jsonStr = re.sub(r'"}', '`}', jsonStr)
#	jsonStr = re.sub(r'":"', '`:`', jsonStr)
#	jsonStr = re.sub(r'":\[', '`:[', jsonStr)
#	jsonStr = re.sub(r'":\{', '`:{', jsonStr)
#	#jsonStr = re.sub(r'":([0-9]+)', '`:\\1', jsonStr)
#	jsonStr = re.sub(r'":([\+\-\.0-9]+)', '`:\\1', jsonStr)
#	jsonStr = re.sub(r'":([null|true|false])', '`:\\1', jsonStr)
#	jsonStr = re.sub(r'","', '`,`', jsonStr)
#	jsonStr = re.sub(r'",\[', '`,[', jsonStr)
#	jsonStr = re.sub(r'",\{', '`,{', jsonStr)
#	jsonStr = re.sub(r',"', ',`', jsonStr)
#	jsonStr = re.sub(r'\["', '[`', jsonStr)
#	jsonStr = re.sub(r'"\]', '`]', jsonStr)
#	# Backslash all double quotes (")
#	jsonStr = re.sub(r'"','\\"', jsonStr)
#	# Put back all the " where it is supposed to be.
#	jsonStr = re.sub(r'\`','\"', jsonStr)
#	return jsonStr
#
## should be in exclude because it contains lots of single/double quotes
#def FIX_JSON_2(s):
#	import ast
#	import json
#	while True:
#		try:
#			#jsonStr = ast.literal_eval(s)
#			jsonStr = json.loads(s)   # try to parse...
#			break                    # parsing worked -> exit loop
#		except Exception as e:
#			# "Expecting , delimiter: line 34 column 54 (char 1158)"
#			# position of unexpected character after '"'
#			unexp = int(re.findall(r'\(char (\d+)\)', str(e))[0])
#			# position of unescaped '"' before that
#			unesc = s.rfind(r'"', 0, unexp)
#			s = s[:unesc] + r'\"' + s[unesc+1:]
#			# position of correspondig closing '"' (+2 for inserted '\')
#			closg = s.find(r'"', unesc + 2)
#			s = s[:closg] + r'\"' + s[closg+1:]
#	return jsonStr
#"""



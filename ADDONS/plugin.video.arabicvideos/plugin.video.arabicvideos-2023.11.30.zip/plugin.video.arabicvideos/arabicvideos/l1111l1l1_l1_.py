# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ᝙")
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡅࡐࡇࡤ࠭᝚")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็๋ๆ฾ࠦๆหใ็๎ู่ࠧ᝛")]
def l11l1ll_l1_(mode,url,text):
	if   mode==490: l1lll_l1_ = l1l1l11_l1_()
	elif mode==491: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==492: l1lll_l1_ = PLAY(url)
	elif mode==493: l1lll_l1_ = l1ll1l11_l1_(url)
	elif mode==494: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==499: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭᝜"),l111l1_l1_,l1l111_l1_ (u"ࠪࠫ᝝"),l1l111_l1_ (u"ࠫࠬ᝞"),l1l111_l1_ (u"ࠬ࠭᝟"),l1l111_l1_ (u"࠭ࠧᝠ"),l1l111_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᝡ"))
	html = response.content
	l1l11ll_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᝢ"),html,re.DOTALL)
	l1l11ll_l1_ = l1l11ll_l1_[0].strip(l1l111_l1_ (u"ࠩ࠲ࠫᝣ"))
	l1l11ll_l1_ = l1l111l_l1_(l1l11ll_l1_,l1l111_l1_ (u"ࠪࡹࡷࡲࠧᝤ"))
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧ࡬ࡩ࡭ࡶࡨࡶࠥࡇࡪࡢࡺ࡬ࡪࡾࡌࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᝥ"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡪ࡮ࡲࡴࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᝦ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡴࡲࡤ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠰ࠩᝧ")+l1ll1ll_l1_+l1l111_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬᝨ")
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᝩ"),l1ll1_l1_+l1l111_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᝪ")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᝫ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᝬ"),l1l111_l1_ (u"ࠬ࠭᝭"),9999)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᝮ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᝯ")+l1lllll_l1_+l1l111_l1_ (u"ࠨลไ่ฬ๋ࠧᝰ"),l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อแๅษ่࠱ࡲࡵࡶࡪࡧࡶ࠱࡫࡯࡬࡮ࡧ࠲ࡪࡴࡸࡥࡪࡩࡱ࠱࡭ࡪ࠭ศใ็ห๊࠳วอ่หํ࠲࠸ࠧ᝱"),494,l1l111_l1_ (u"ࠪࠫᝲ"),l1l111_l1_ (u"ࠫࠬᝳ"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᝴"))
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᝵"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ᝶")+l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึุ่๊วหࠩ᝷"),l1l11ll_l1_+l1l111_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴๋ำๅี็หฯ࠵ๅิๆึ่ฬะ࠭ศฮ้ฬ๎࠭᝸"),494,l1l111_l1_ (u"ࠪࠫ᝹"),l1l111_l1_ (u"ࠫࠬ᝺"),l1l111_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᝻"))
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ᝼"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᝽"),l1l111_l1_ (u"ࠨࠩ᝾"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳ࠳࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᝿"),html,re.DOTALL)
	block = l11llll_l1_[0]
	items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨក"),block,re.DOTALL)
	for l1ll1ll_l1_,title in items:
		if l1ll1ll_l1_==l1l111_l1_ (u"ࠫ࠴࠭ខ"): continue
		if l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲࠪគ") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l11ll_l1_+l1ll1ll_l1_
		if title in l11lll_l1_: continue
		addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឃ"),l1ll1_l1_+l1l111_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩង")+l1lllll_l1_+title,l1ll1ll_l1_,491)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬច"),url,l1l111_l1_ (u"ࠩࠪឆ"),l1l111_l1_ (u"ࠪࠫជ"),l1l111_l1_ (u"ࠫࠬឈ"),l1l111_l1_ (u"ࠬ࠭ញ"),l1l111_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ដ"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ឋ"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ឌ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩឍ"),l1lllll_l1_+title,l1ll1ll_l1_,491)
	return
def l1lll11_l1_(url,l111l1l1l_l1_=l1l111_l1_ (u"ࠪࠫណ")):
	items = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨត"),url,l1l111_l1_ (u"ࠬ࠭ថ"),l1l111_l1_ (u"࠭ࠧទ"),l1l111_l1_ (u"ࠧࠨធ"),l1l111_l1_ (u"ࠨࠩន"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨប"))
	html = response.content
	block = l1l111_l1_ (u"ࠪࠫផ")
	if l1l111_l1_ (u"ࠫ࠳ࡶࡨࡱࠩព") in url: block = html
	elif l1l111_l1_ (u"ࠬࡅࡳ࠾ࠩភ") in url:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡣ࡮ࡲࡧࡰࡹࠨ࠯ࠬࡂ࠭ࠧࡳࡡ࡯࡫ࡩࡩࡸࡺࠢࠨម"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭យ"),block,re.DOTALL)
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡅࡰࡴࡩ࡫ࡴࠪ࠱࠮ࡄ࠯ࠢ࡮ࡣࡱ࡭࡫࡫ࡳࡵࠤࠪរ"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
	if not block: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ุ่ࠩฬํฯสࠩល"),l1l111_l1_ (u"ࠪๅ๏๊ๅࠨវ"),l1l111_l1_ (u"ࠫฬเๆ๋หࠪឝ"),l1l111_l1_ (u"ࠬษฺ็์ฬࠫឞ"),l1l111_l1_ (u"࠭ใๅ์หࠫស"),l1l111_l1_ (u"ࠧศ฻็ห๋࠭ហ"),l1l111_l1_ (u"ࠨ้าหๆ࠭ឡ"),l1l111_l1_ (u"่ࠩฬฬืวสࠩអ"),l1l111_l1_ (u"ࠪ฽ึ฼ࠧឣ"),l1l111_l1_ (u"๊ࠫํัอษ้ࠫឤ"),l1l111_l1_ (u"ࠬอไษ๊่ࠫឥ"),l1l111_l1_ (u"࠭ๅิำะ๎ฮ࠭ឦ")]
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨឧ"),title,re.DOTALL)
		if not l1l1lll_l1_: l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫឨ"),title,re.DOTALL)
		if not l1l1lll_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨឩ"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		elif l1l1lll_l1_ and l1l111_l1_ (u"ࠪั้่ษࠨឪ") in title:
			title = l1l111_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪឫ") + l1l1lll_l1_[0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឬ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
				l1l1_l1_.append(title)
		else: addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ឭ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩឮ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ឯ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l1l111_l1_ (u"ࠩสฺ่็อสࠢࠪឰ"),l1l111_l1_ (u"ࠪࠫឱ"))
			if title!=l1l111_l1_ (u"ࠫࠬឲ"): addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬឳ"),l1lllll_l1_+l1l111_l1_ (u"࠭ีโฯฬࠤࠬ឴")+title,l1ll1ll_l1_,491)
	return
def l1ll1l11_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ឵"),url,l1l111_l1_ (u"ࠨࠩា"),l1l111_l1_ (u"ࠩࠪិ"),l1l111_l1_ (u"ࠪࠫី"),l1l111_l1_ (u"ࠫࠬឹ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ឺ"))
	html = response.content
	l1lllll1_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡃࡷࡷࡸࡴࡴࡳࡃࡣࡵࡇࡴࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨុ"),html,re.DOTALL)
	if l1lllll1_l1_:
		l1lllll1_l1_ = l1lllll1_l1_[0]
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫូ"),l1lllll1_l1_,l1l111_l1_ (u"ࠨࠩួ"),l1l111_l1_ (u"ࠩࠪើ"),l1l111_l1_ (u"ࠪࠫឿ"),l1l111_l1_ (u"ࠫࠬៀ"),l1l111_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭េ"))
		html = response.content
	l1ll1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡪ࡯ࡪ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧែ"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l1l111_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨៃ"))
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧោ"),html,re.DOTALL)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬៅ"),html,re.DOTALL)
	if l11ll1l_l1_ and l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬំ") not in url:
		block = l11ll1l_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩះ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬៈ"),l1lllll_l1_+title,l1ll1ll_l1_,493,l1ll1l_l1_)
	elif l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡢ࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࠤࡥࡳࡽࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ៉"),block,re.DOTALL)
		if items:
			for l1ll1ll_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ៊"))
				addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ់"),l1lllll_l1_+title,l1ll1ll_l1_,492,l1ll1l_l1_)
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ៌"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ៍"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬ៎"),l1l111_l1_ (u"ࠬ࠭៏"))
				if title!=l1l111_l1_ (u"࠭ࠧ័"): addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ៑"),l1lllll_l1_+l1l111_l1_ (u"ࠨืไัฮ្ࠦࠧ")+title,l1ll1ll_l1_,491)
	return
def PLAY(url):
	l1lllll1_l1_ = url.strip(l1l111_l1_ (u"ࠩ࠲ࠫ៓"))+l1l111_l1_ (u"ࠪ࠳ࡄࡼࡩࡦࡹࡀ࠵ࠬ។")
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ៕"),l1lllll1_l1_,l1l111_l1_ (u"ࠬ࠭៖"),l1l111_l1_ (u"࠭ࠧៗ"),l1l111_l1_ (u"ࠧࠨ៘"),l1l111_l1_ (u"ࠨࠩ៙"),l1l111_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭៚"))
	html = response.content
	l1llll_l1_ = []
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠪࡹࡷࡲࠧ៛"))
	l1111l11l_l1_ = re.findall(l1l111_l1_ (u"ࠦࡩࡧࡴࡢ࠼ࠣࠫࡶࡃࠨ࠯ࠬࡂ࠭ࠫࠨៜ"),html,re.DOTALL)
	l1111l11l_l1_ = l1111l11l_l1_[0]
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ៝"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ៞"),block,re.DOTALL)
		for l1111l111_l1_,title in items:
			title = title.strip(l1l111_l1_ (u"ࠧࠡࠩ៟"))
			l1ll1ll_l1_ = l1l11ll_l1_+l1l111_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵࡯࡭ࡦ࠲ࡷࡪࡸࡶࡦࡴࡶ࠳ࡸ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࡀࡳࡀࠫ០")+l1111l11l_l1_+l1l111_l1_ (u"ࠩࠩ࡭ࡂ࠭១")+l1111l111_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ២")+title+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ៣")
			l1llll_l1_.append(l1ll1ll_l1_)
	l1ll1ll_l1_ = re.findall(l1l111_l1_ (u"ࠬࠨࡥ࡮ࡤࡨࡨࡘ࡫ࡲࡷࡧࡵࠦ࠳࠰࠿ࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ៤"),html,re.DOTALL)
	if l1ll1ll_l1_:
		title = l1l111_l1_ (u"࠭ๅโุ็ࠫ៥")
		l1ll1ll_l1_ = l1ll1ll_l1_[0]+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࡠࡡࠪ៦")+title
		l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ៧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៨"),block,re.DOTALL)
		for title,l1ll1ll_l1_ in items:
			title = title.strip(l1l111_l1_ (u"ࠪࠤࠬ៩"))
			if l1l111_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ៪") in l1ll1ll_l1_: l1lllllll_l1_ = l1l111_l1_ (u"ࠬࡥ࡟ฯษุࠫ៫")
			else: l1lllllll_l1_ = l1l111_l1_ (u"࠭ࠧ៬")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ៭")+title+l1l111_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ៮")+l1lllllll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ៯"),url)
	return
def l1lll1_l1_(search,l1l11ll_l1_=l1l111_l1_ (u"ࠪࠫ៰")):
	if not l1l11ll_l1_: l1l11ll_l1_ = l111l1_l1_
	search,options,l11_l1_ = l111ll_l1_(search)
	if not search:
		search = l1llll1_l1_()
		if not search: return
	search = search.replace(l1l111_l1_ (u"ࠫࠥ࠭៱"),l1l111_l1_ (u"ࠬ࠱ࠧ៲"))
	url = l1l11ll_l1_+l1l111_l1_ (u"࠭࠯ࡪࡰࡧࡩࡽ࠴ࡰࡩࡲࡂࡷࡂ࠭៳")+search
	l1lll11_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ⿿")
l1lllll_l1_ = l1l111_l1_ (u"ࠪࡣࡐ࡚ࡋࡠࠩ　")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠫฬ๊ีโฯฬࠤฬ๊ัว์ึ๎ฮ࠭、"),l1l111_l1_ (u"࡙ࠬࡩࡨࡰࠣ࡭ࡳ࠭。"),l1l111_l1_ (u"࠭วๅลๅืฬ๋ࠧ〃")]
def l11l1ll_l1_(mode,url,text):
	if   mode==670: l1lll_l1_ = l1l1l11_l1_()
	elif mode==671: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==672: l1lll_l1_ = PLAY(url)
	elif mode==673: l1lll_l1_ = l1111_l1_(url,text)
	elif mode==674: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==679: l1lll_l1_ = l1lll1_l1_(text)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ〄"),l111l1_l1_,l1l111_l1_ (u"ࠨࠩ々"),l1l111_l1_ (u"ࠩࠪ〆"),l1l111_l1_ (u"ࠪࠫ〇"),l1l111_l1_ (u"ࠫࠬ〈"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ〉"))
	html = response.content
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭《"),l1lllll_l1_+l1l111_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ》"),l1l111_l1_ (u"ࠨࠩ「"),679,l1l111_l1_ (u"ࠩࠪ」"),l1l111_l1_ (u"ࠪࠫ『"),l1l111_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ』"))
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ【"),l1l111_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭】"),l1l111_l1_ (u"ࠧࠨ〒"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ〓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ〔"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title in l11lll_l1_: continue
			if title==l1l111_l1_ (u"ࠪห้ษโิษ่ࠫ〕"): mode = 675
			else: mode = 674
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ〖"),l1ll1_l1_+l1l111_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ〗")+l1lllll_l1_+title,l1ll1ll_l1_,mode)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ〘"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〙"),l1l111_l1_ (u"ࠨࠩ〚"),9999)
	items = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࡥࡶࡴࡽࡳࡦ࠰࡫ࡸࡲࡲࠧ〛"))
	for l1ll1ll_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ〜"),l1ll1_l1_+l1l111_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭〝")+l1lllll_l1_+title,l1ll1ll_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l11111111_l1_ = l1ll1ll1l11_l1_(main_dbfile,l1l111_l1_ (u"ࠬࡲࡩࡴࡶࠪ〞"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ〟"),l1l111_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ〠"))
	if l11111111_l1_: return l11111111_l1_
	l11111111_l1_ = []
	response = l11l1l_l1_(l11ll11l_l1_,l1l111_l1_ (u"ࠨࡉࡈࡘࠬ〡"),url,l1l111_l1_ (u"ࠩࠪ〢"),l1l111_l1_ (u"ࠪࠫ〣"),l1l111_l1_ (u"ࠫࠬ〤"),l1l111_l1_ (u"ࠬ࠭〥"),l1l111_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩ〦"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰࡬ࡪࡧࡤࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾ࡩࡳࡴࡺࡥࡳࡀࠪ〧"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l11111111_l1_ = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ〨"),block,re.DOTALL)
		if l11111111_l1_: l1ll1l1ll11_l1_(main_dbfile,l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫ〩"),l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ〪࡙ࠧ"),l11111111_l1_,l1ll1ll1_l1_)
	return l11111111_l1_
def l11ll1_l1_(url):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠫࡌࡋࡔࠨ〫"),url,l1l111_l1_ (u"ࠬ࠭〬"),l1l111_l1_ (u"〭࠭ࠧ"),l1l111_l1_ (u"ࠧࠨ〮"),l1l111_l1_ (u"ࠨ〯ࠩ"),l1l111_l1_ (u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ〰"))
	html = response.content
	l11ll1l_l1_ = re.findall(l1l111_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ〱"),html,re.DOTALL)
	if l11ll1l_l1_:
		block = l11ll1l_l1_[0]
		block = block.replace(l1l111_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ〲"),l1l111_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ〳"))
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ〴"),block,re.DOTALL)
		if not l11llll_l1_: l11llll_l1_ = [(l1l111_l1_ (u"ࠧࠨ〵"),block)]
		addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭〶"),l1l111_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ〷"),l1l111_l1_ (u"ࠪࠫ〸"),9999)
		for l11111_l1_,block in l11llll_l1_:
			items = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ〹"),block,re.DOTALL)
			if l11111_l1_: l11111_l1_ = l11111_l1_+l1l111_l1_ (u"ࠬࡀࠠࠨ〺")
			for l1ll1ll_l1_,title in items:
				title = l11111_l1_+title
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭〻"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	l11ll11_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ〼"),html,re.DOTALL)
	if l11ll11_l1_:
		block = l11ll11_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ〽"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ〾"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ〿"),l1l111_l1_ (u"ࠫࠬ぀"),9999)
			for l1ll1ll_l1_,title in items:
				addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬぁ"),l1lllll_l1_+title,l1ll1ll_l1_,671)
	if not l11ll1l_l1_ and not l11ll11_l1_: l1lll11_l1_(url)
	return
def l1lll11_l1_(url,request=l1l111_l1_ (u"࠭ࠧあ")):
	if request==l1l111_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬぃ"):
		url,search = url.split(l1l111_l1_ (u"ࠨࡁࠪい"),1)
		data = l1l111_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨぅ")+search
		headers = {l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩう"):l1l111_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫぇ")}
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠬࡖࡏࡔࡖࠪえ"),url,data,headers,l1l111_l1_ (u"࠭ࠧぉ"),l1l111_l1_ (u"ࠧࠨお"),l1l111_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧか"))
	else:
		response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭が"),url,l1l111_l1_ (u"ࠪࠫき"),l1l111_l1_ (u"ࠫࠬぎ"),l1l111_l1_ (u"ࠬ࠭く"),l1l111_l1_ (u"࠭ࠧぐ"),l1l111_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭け"))
	html = response.content
	block,items = l1l111_l1_ (u"ࠨࠩげ"),[]
	l1l11ll_l1_ = l1l111l_l1_(url,l1l111_l1_ (u"ࠩࡸࡶࡱ࠭こ"))
	if request==l1l111_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨご"):
		block = html
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭さ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠬ࠭ざ"),l1ll1ll_l1_,title))
	elif request==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨし"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨじ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧす"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩず"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	elif request==l1l111_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧせ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫぜ"),html,re.DOTALL)
		if len(l11llll_l1_)>1: block = l11llll_l1_[1]
	elif request==l1l111_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧそ"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨぞ"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
		l1l1111_l1_ = re.findall(l1l111_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩた"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1l1111_l1_: items.append((l1l111_l1_ (u"ࠨࠩだ"),l1ll1ll_l1_,title))
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪち"),html,re.DOTALL)
		if l11llll_l1_: block = l11llll_l1_[0]
	if block and not items: items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫぢ"),block,re.DOTALL)
	if not items: return
	l1l1_l1_ = []
	l1ll11_l1_ = [l1l111_l1_ (u"ฺ๊ࠫว่ัฬࠫっ"),l1l111_l1_ (u"ࠬ็๊ๅ็ࠪつ"),l1l111_l1_ (u"࠭ว฻่ํอࠬづ"),l1l111_l1_ (u"ࠧไๆํฬࠬて"),l1l111_l1_ (u"ࠨษ฼่ฬ์ࠧで"),l1l111_l1_ (u"๊ࠩำฬ็ࠧと"),l1l111_l1_ (u"้ࠪออัศหࠪど"),l1l111_l1_ (u"ࠫ฾ืึࠨな"),l1l111_l1_ (u"๋ࠬ็าฮส๊ࠬに"),l1l111_l1_ (u"࠭วๅส๋้ࠬぬ"),l1l111_l1_ (u"ࠧๆีิั๏ฯࠧね"),l1l111_l1_ (u"ࠨใ็้ࠬの")]
	for l1ll1l_l1_,l1ll1ll_l1_,title in items:
		l1l1lll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬは"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l1l111_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩば"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif request==l1l111_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪぱ"):
			addMenuItem(l1l111_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫひ"),l1lllll_l1_+title,l1ll1ll_l1_,672,l1ll1l_l1_)
		elif l1l1lll_l1_:
			title = l1l111_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬび") + l1l1lll_l1_[0][0]
			if title not in l1l1_l1_:
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧぴ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
				l1l1_l1_.append(title)
		elif l1l111_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭ふ") in l1ll1ll_l1_:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩぶ"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪぷ"),l1lllll_l1_+title,l1ll1ll_l1_,673,l1ll1l_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬへ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪべ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if l1ll1ll_l1_==l1l111_l1_ (u"࠭ࠣࠨぺ"): continue
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬほ") not in l1ll1ll_l1_:
				l1lllll1_l1_ = url.rsplit(l1l111_l1_ (u"ࠨ࠱ࠪぼ"),1)[0]
				l1ll1ll_l1_ = l1lllll1_l1_+l1l111_l1_ (u"ࠩ࠲ࠫぽ")+l1ll1ll_l1_.strip(l1l111_l1_ (u"ࠪ࠳ࠬま"))
			title = unescapeHTML(title)
			addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫみ"),l1lllll_l1_+l1l111_l1_ (u"ࠬ฻แฮหࠣࠫむ")+title,l1ll1ll_l1_,671,l1l111_l1_ (u"࠭ࠧめ"),l1l111_l1_ (u"ࠧࠨも"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	addMenuItem(l1l111_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧゃ"),l1lllll_l1_+l1l111_l1_ (u"ࠩอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩや"),url,672)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨゅ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫゆ"),l1l111_l1_ (u"ࠬ࠭ょ"),9999)
	l11111111_l1_ = CATEGORIES(l111l1_l1_+l1l111_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࡢࡳࡱࡺࡷࡪ࠴ࡨࡵ࡯࡯ࠫよ"))
	l1ll11111ll_l1_,l1ll1111l1l_l1_,l1ll1111l11_l1_ = zip(*l11111111_l1_)
	l1ll1111lll_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫら"),url,l1l111_l1_ (u"ࠨࠩり"),l1l111_l1_ (u"ࠩࠪる"),l1l111_l1_ (u"ࠪࠫれ"),l1l111_l1_ (u"ࠫࠬろ"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ゎ"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡨࡦࡣࡧ࡭ࡳ࡭ࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡳࡰࡦࡿࡥࡳࠤࠪわ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡻࡅࡹࡹࡺ࡯࡯ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡣࡀࠫ࠲࠯ࡅࠩ࠽ࠩゐ"),block,re.DOTALL)
		for l1ll1ll_l1_,title in l1ll_l1_:
			if l1ll1ll_l1_ not in l1ll11111ll_l1_:
				item = (l1ll1ll_l1_,title)
				l1ll1111lll_l1_.append(item)
		if len(l1ll1111lll_l1_)==1:
			l1ll1ll_l1_,title = l1ll1111lll_l1_[0]
			l1lll11_l1_(l1ll1ll_l1_,l1l111_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧゑ"))
			return
		else:
			for l1ll1ll_l1_,title in l1ll1111lll_l1_:
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩを"),l1lllll_l1_+title,l1ll1ll_l1_,671,l1l111_l1_ (u"ࠪࠫん"),l1l111_l1_ (u"ࠫࠬゔ"),l1l111_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫゕ"))
	if not l1ll1111lll_l1_: l1lll11_l1_(url,l1l111_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬゖ"))
	return
def PLAY(url):
	l1ll11l1_l1_ = []
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ゗"),url,l1l111_l1_ (u"ࠨࠩ゘"),l1l111_l1_ (u"゙ࠩࠪ"),l1l111_l1_ (u"゚ࠪࠫ"),l1l111_l1_ (u"ࠫࠬ゛"),l1l111_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ゜"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠩ࠰࠭ࡃ࠮࡬࡬ࡢࡵ࡫ࡴࡱࡧࡹࡦࡴࠪゝ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡧ࡫࡯ࡩ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪゞ"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in l1ll_l1_:
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡻࡦࡺࡣࡩࡡࡢࠫゟ")+l111l1ll_l1_
			l1ll11l1_l1_.append(l1ll1ll_l1_)
	l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠩࠥࡩࡲࡨࡥࡥࡦࡨࡨ࠲ࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ゠"),html,re.DOTALL)
	if not l1ll_l1_: l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠥࡪ࡮ࡲࡥ࠻ࠢࠪࠬ࠳࠰࠿ࠪࠩࠥァ"),html,re.DOTALL)
	if l1ll_l1_:
		l1ll1ll_l1_ = l1ll_l1_[0]
		if l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱࠩア") not in l1ll1ll_l1_: l1ll1ll_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫィ")+l1ll1ll_l1_
		l1ll11l1_l1_.append(l1ll1ll_l1_+l1l111_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧイ"))
	import ll_l1_
	ll_l1_.l1l_l1_(l1ll11l1_l1_,l1ll1_l1_,l1l111_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ゥ"),url)
	return
def l1lll1_l1_(search):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩウ"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪェ"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬエ"),l1l111_l1_ (u"ࠫ࠰࠭ォ"))
	url = l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬオ")+search
	l1lll11_l1_(url,l1l111_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭カ"))
	return
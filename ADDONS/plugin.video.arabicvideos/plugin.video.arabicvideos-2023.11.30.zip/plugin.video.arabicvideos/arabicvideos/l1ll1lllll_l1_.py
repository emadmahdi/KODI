# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠨࡅࡏࡉࡆࡔࡅࡓࠩ᧻")
l1lllll_l1_ = l1l111_l1_ (u"ࠩࡢࡇࡑࡔ࡟ࠨ᧼")
l1lll1l111_l1_ = os.path.join(l1llllllll_l1_,l1l111_l1_ (u"ࠪࡸࡪࡳࡰࠨ᧽"))
l1ll111lll_l1_ = os.path.join(l1llllllll_l1_,l1l111_l1_ (u"ࠫࡵࡧࡣ࡬ࡣࡪࡩࡸ࠭᧾"))
l1lll11ll1_l1_ = os.path.join(l1ll1l1111_l1_,l1l111_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ᧿"),l1l111_l1_ (u"࠭ࡔࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪᨀ"))
l1ll1l11l1_l1_ = l1llll1ll1_l1_
l1ll11l111_l1_ = l1l111_l1_ (u"ࠧ࠰ࡦࡤࡸࡦ࠵ࡳࡺࡵࡷࡩࡲ࠵ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠪᨁ")
l1ll11l11l_l1_ = l1l111_l1_ (u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡴࡻࡶࡸࡪࡳ࠯ࡥࡴࡲࡴࡧࡵࡸࠨᨂ")
l1lll11l1l_l1_ = l1l111_l1_ (u"ࠩ࠲ࡨࡦࡺࡡ࠰ࡶࡲࡱࡧࡹࡴࡰࡰࡨࡷࠬᨃ")
l1lll1l11l_l1_ = l1l111_l1_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱࡯ࡳ࡬࡭ࡥࡳࠩᨄ")
l1ll11ll11_l1_ = l1l111_l1_ (u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡰࡴ࡭ࠧᨅ")
l1ll11ll1l_l1_ = l1l111_l1_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡦࡴࡲࠨᨆ")
def l11l1ll_l1_(mode):
	if   mode==740: l1lll_l1_ = l1lllllll1_l1_()
	elif mode==741: l1lll_l1_ = l1lllll1l1_l1_(l1lll1l111_l1_,True,True)
	elif mode==742: l1lll_l1_ = l1lllll1l1_l1_(l1ll111lll_l1_,True,True)
	elif mode==743: l1lll_l1_ = l1lllll1l1_l1_(l1lll11ll1_l1_,False,True)
	elif mode==744: l1lll_l1_ = l1ll11llll_l1_(l1ll1l11l1_l1_,True)
	elif mode==745: l1lll_l1_ = l1ll111l1l_l1_(True)
	elif mode==750: l1lll_l1_ = l1ll1llll1_l1_()
	elif mode==751: l1lll_l1_ = l1lllll1l1_l1_(l1ll11l111_l1_,False,True)
	elif mode==752: l1lll_l1_ = l1lllll1l1_l1_(l1ll11l11l_l1_,False,True)
	elif mode==753: l1lll_l1_ = l1lllll1l1_l1_(l1lll11l1l_l1_,False,True)
	elif mode==754: l1lll_l1_ = l1lllll1l1_l1_(l1lll1l11l_l1_,False,True)
	elif mode==755: l1lll_l1_ = l1lllll1l1_l1_(l1ll11ll11_l1_,False,True)
	elif mode==756: l1lll_l1_ = l1lllll1l1_l1_(l1ll11ll1l_l1_,False,True)
	elif mode==757: l1lll_l1_ = l1lll11111_l1_(True)
	elif mode==758: l1lll_l1_ = l1ll1ll1ll_l1_()
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1lllllll1_l1_():
	l1lll1ll1l_l1_,l1lllll11l_l1_ = l1ll11l1l1_l1_(l1lll1l111_l1_)
	l1lll1ll11_l1_,l1ll1l1l1l_l1_ = l1ll11l1l1_l1_(l1ll111lll_l1_)
	l1lll1l1ll_l1_,l1ll1l1ll1_l1_ = l1ll11l1l1_l1_(l1lll11ll1_l1_)
	l1llll1111_l1_,l1ll1l11ll_l1_ = l1ll1l1lll_l1_(l1ll1l11l1_l1_)
	l1llll1111_l1_ -= 36864
	l1ll1l11ll_l1_ -= 1
	l1ll11l1ll_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᨇ")+l1llllll11_l1_(l1lll1ll1l_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᨈ")+str(l1lllll11l_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᨉ")
	l1ll1lll1l_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᨊ")+l1llllll11_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨋ")+str(l1ll1l1l1l_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨌ")
	l1ll1lll11_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨍ")+l1llllll11_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᨎ")+str(l1ll1l1ll1_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᨏ")
	l1llllll1l_l1_ = l1l111_l1_ (u"ࠨࠢࠫࠫᨐ")+l1llllll11_l1_(l1llll1111_l1_)+l1l111_l1_ (u"ࠩࠬࠫᨑ")
	size = l1lll1ll1l_l1_+l1lll1ll11_l1_+l1lll1l1ll_l1_+l1llll1111_l1_
	count = l1lllll11l_l1_+l1ll1l1l1l_l1_+l1ll1l1ll1_l1_+l1ll1l11ll_l1_
	text = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨒ")+l1llllll11_l1_(size)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᨓ")+str(count)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᨔ")
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᨕ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤฬ๊ฬๆ์฼ࠫᨖ")+text,l1l111_l1_ (u"ࠨࠩᨗ"),745)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱᨘࠧ"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᨙ"),l1l111_l1_ (u"ࠫࠬᨚ"),9999)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᨛ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯࠣห้๋ไโษอࠤฬ๊ๅลไออࠬ᨜")+l1ll11l1ll_l1_,l1l111_l1_ (u"ࠧࠨ᨝"),741)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭᨞"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩ᨟")+l1ll1lll1l_l1_,l1l111_l1_ (u"ࠪࠫᨠ"),742)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᨡ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮࠢสฺ่๎ัࠡษ็ๆิ๐ๅสࠩᨢ")+l1ll1lll11_l1_,l1l111_l1_ (u"࠭ࠧᨣ"),743)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᨤ"),l1lllll_l1_+l1l111_l1_ (u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪᨥ")+l1llllll1l_l1_,l1l111_l1_ (u"ࠩࠪᨦ"),744)
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᨧ"),l1l111_l1_ (u"ࠫࠬᨨ"))
	return
def l1ll1llll1_l1_():
	l1lllll111_l1_ = True if l1l111_l1_ (u"ࠬ࠵ࠧᨩ") in l1ll1l1111_l1_ else False
	if not l1lllll111_l1_:
		l1111l1_l1_(l1l111_l1_ (u"࠭ࠧᨪ"),l1l111_l1_ (u"ࠧࠨᨫ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᨬ"),l1l111_l1_ (u"ࠩ฼้้๐ษࠡฬ้฼๏็ࠠศๆฯ๋ฬุࠠๆฬ๋ๅึฯࠠโไฺࠤ้ษฬ่ิฬࠤ๏๎ๆไีࠣ࠲࠳่ࠦอ้สึ่ࠦไ๋ี้๋ࠣࠦๆ้฻ࠣ๎ํ์ใิࠩᨭ"))
		return
	l1ll11lll1_l1_ = settings.getSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧᨮ"))
	if not l1ll11lll1_l1_: l1ll1ll1ll_l1_()
	l1lll1ll1l_l1_,l1lllll11l_l1_ = l1ll11l1l1_l1_(l1ll11l111_l1_)
	l1lll1ll11_l1_,l1ll1l1l1l_l1_ = l1ll11l1l1_l1_(l1ll11l11l_l1_)
	l1lll1l1ll_l1_,l1ll1l1ll1_l1_ = l1ll11l1l1_l1_(l1lll11l1l_l1_)
	l1llll1111_l1_,l1ll1l11ll_l1_ = l1ll11l1l1_l1_(l1lll1l11l_l1_)
	l1lll1llll_l1_,l1ll1l1l11_l1_ = l1ll11l1l1_l1_(l1ll11ll11_l1_)
	l1lll1lll1_l1_,l1lll1l1l1_l1_ = l1ll11l1l1_l1_(l1ll11ll1l_l1_)
	l1ll11l1ll_l1_ = l1l111_l1_ (u"ࠫࠥ࠮ࠧᨯ")+l1llllll11_l1_(l1lll1ll1l_l1_)+l1l111_l1_ (u"ࠬࠦ࠭ࠡࠩᨰ")+str(l1lllll11l_l1_)+l1l111_l1_ (u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧᨱ")
	l1ll1lll1l_l1_ = l1l111_l1_ (u"ࠧࠡࠪࠪᨲ")+l1llllll11_l1_(l1lll1ll11_l1_)+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬᨳ")+str(l1ll1l1l1l_l1_)+l1l111_l1_ (u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪᨴ")
	l1ll1lll11_l1_ = l1l111_l1_ (u"ࠪࠤ࠭࠭ᨵ")+l1llllll11_l1_(l1lll1l1ll_l1_)+l1l111_l1_ (u"ࠫࠥ࠳ࠠࠨᨶ")+str(l1ll1l1ll1_l1_)+l1l111_l1_ (u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ᨷ")
	l1llllll1l_l1_ = l1l111_l1_ (u"࠭ࠠࠩࠩᨸ")+l1llllll11_l1_(l1llll1111_l1_)+l1l111_l1_ (u"ࠧࠡ࠯ࠣࠫᨹ")+str(l1ll1l11ll_l1_)+l1l111_l1_ (u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩᨺ")
	l1ll1ll111_l1_ = l1l111_l1_ (u"ࠩࠣࠬࠬᨻ")+l1llllll11_l1_(l1lll1llll_l1_)+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧᨼ")+str(l1ll1l1l11_l1_)+l1l111_l1_ (u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬᨽ")
	l1ll1ll1l1_l1_ = l1l111_l1_ (u"ࠬࠦࠨࠨᨾ")+l1llllll11_l1_(l1lll1lll1_l1_)+l1l111_l1_ (u"࠭ࠠ࠮ࠢࠪᨿ")+str(l1lll1l1l1_l1_)+l1l111_l1_ (u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨᩀ")
	size = l1lll1ll1l_l1_+l1lll1ll11_l1_+l1lll1l1ll_l1_+l1llll1111_l1_+l1lll1llll_l1_+l1lll1lll1_l1_
	count = l1lllll11l_l1_+l1ll1l1l1l_l1_+l1ll1l1ll1_l1_+l1ll1l11ll_l1_+l1ll1l1l11_l1_+l1lll1l1l1_l1_
	text = l1l111_l1_ (u"ࠨࠢࠫࠫᩁ")+l1llllll11_l1_(size)+l1l111_l1_ (u"ࠩࠣ࠱ࠥ࠭ᩂ")+str(count)+l1l111_l1_ (u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫᩃ")
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩄ"),l1lllll_l1_+l1l111_l1_ (u"ࠬหูุษฤࠤึิีสࠢๅีฬวษ๊ࠡๆฮฬฮษࠨᩅ"),l1l111_l1_ (u"࠭ࠧᩆ"),758)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩇ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึัࠥอไอ็ํ฽ࠬᩈ")+text,l1l111_l1_ (u"ࠩࠪᩉ"),757)
	addMenuItem(l1l111_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᩊ"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᩋ"),l1l111_l1_ (u"ࠬ࠭ᩌ"),9999)
	addMenuItem(l1l111_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᩍ"),l1lllll_l1_+l1l111_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧᩎ")+l1ll11l1ll_l1_,l1l111_l1_ (u"ࠨࠩᩏ"),751)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᩐ"),l1lllll_l1_+l1l111_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦࡤࡳࡱࡳࡦࡴࡾࠧᩑ")+l1ll1lll1l_l1_,l1l111_l1_ (u"ࠫࠬᩒ"),752)
	addMenuItem(l1l111_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᩓ"),l1lllll_l1_+l1l111_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠢࡷࡳࡲࡨࡳࡵࡱࡱࡩࡸ࠭ᩔ")+l1ll1lll11_l1_,l1l111_l1_ (u"ࠧࠨᩕ"),753)
	addMenuItem(l1l111_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ᩖ"),l1lllll_l1_+l1l111_l1_ (u"่ࠩืาࠦๅๅใสฮࠥࡲ࡯ࡨࡩࡨࡶࠬᩗ")+l1llllll1l_l1_,l1l111_l1_ (u"ࠪࠫᩘ"),754)
	addMenuItem(l1l111_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩙ"),l1lllll_l1_+l1l111_l1_ (u"๋ࠬำฮ่่ࠢๆอสࠡ࡮ࡲ࡫ࠬᩚ")+l1ll1ll111_l1_,l1l111_l1_ (u"࠭ࠧᩛ"),755)
	addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᩜ"),l1lllll_l1_+l1l111_l1_ (u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨᩝ")+l1ll1ll1l1_l1_,l1l111_l1_ (u"ࠩࠪᩞ"),756)
	settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᩟"),l1l111_l1_ (u"᩠ࠫࠬ"))
	return
def l1ll1ll1ll_l1_():
	l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠬ࠭ᩡ"),l1l111_l1_ (u"࠭ࠧᩢ"),l1l111_l1_ (u"ࠧࠨᩣ"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᩤ"),l1l111_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩᩥ"))
	if l1llll1l1l_l1_==-1: return
	if l1llll1l1l_l1_:
		l1llll1lll_l1_ = True
		import subprocess
		try: subprocess.Popen(l1l111_l1_ (u"ࠪࡷࡺ࠭ᩦ"))
		except: l1llll1lll_l1_ = False
		if l1llll1lll_l1_:
			l1lll111l1_l1_ = l1ll11l111_l1_+l1l111_l1_ (u"ࠫࠥ࠭ᩧ")+l1ll11l11l_l1_+l1l111_l1_ (u"ࠬࠦࠧᩨ")+l1lll11l1l_l1_+l1l111_l1_ (u"࠭ࠠࠨᩩ")+l1lll1l11l_l1_+l1l111_l1_ (u"ࠧࠡࠩᩪ")+l1ll11ll11_l1_+l1l111_l1_ (u"ࠨࠢࠪᩫ")+l1ll11ll1l_l1_
			proc = subprocess.Popen(l1l111_l1_ (u"ࠩࡶࡹࠥ࠳ࡣࠡࠤࡦ࡬ࡲࡵࡤࠡ࠯ࡕࠤ࠵࠽࠷࠸ࠢࠪᩬ")+l1lll111l1_l1_+l1l111_l1_ (u"ࠪࠦࠬᩭ"),shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
			l1111l1_l1_(l1l111_l1_ (u"ࠫࠬᩮ"),l1l111_l1_ (u"ࠬ࠭ᩯ"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᩰ"),l1l111_l1_ (u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส฿ืศรࠣห้ืฮึหࠪᩱ"))
			settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬᩲ"),l1l111_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬᩳ"))
			xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧᩴ"))
		else: l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ᩵"),l1l111_l1_ (u"ࠬ࠭᩶"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᩷"),l1l111_l1_ (u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧ᩸"))
	return
def l1llllll11_l1_(size):
	for x in [l1l111_l1_ (u"ࠨࡄࠪ᩹"),l1l111_l1_ (u"ࠩࡎࡆࠬ᩺"),l1l111_l1_ (u"ࠪࡑࡇ࠭᩻"),l1l111_l1_ (u"ࠫࡌࡈࠧ᩼"),l1l111_l1_ (u"࡚ࠬࡂࠨ᩽")]:
		if size<1024: break
		else: size /= 1024.0
	text = l1l111_l1_ (u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣ᩾")%(size,x)
	return text
def l1ll11l1l1_l1_(l1llll1l11_l1_=l1l111_l1_ (u"ࠧ࠯᩿ࠩ")):
	global l1lll11l11_l1_,l1llll11l1_l1_
	l1lll11l11_l1_,l1llll11l1_l1_ = 0,0
	def l1lll11lll_l1_(l1llll1l11_l1_):
		global l1lll11l11_l1_,l1llll11l1_l1_
		if os.path.exists(l1llll1l11_l1_):
			if 0 and l1l111_l1_ (u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩ᪀") in dir(os):
				for l1ll111ll1_l1_ in os.scandir(l1llll1l11_l1_):
					if l1ll111ll1_l1_.l1llll11ll_l1_(follow_symlinks=False):
						l1lll11lll_l1_(l1ll111ll1_l1_.path)
					elif l1ll111ll1_l1_.l1ll1ll11l_l1_(follow_symlinks=False):
						l1lll11l11_l1_ += l1ll111ll1_l1_.stat().st_size
						l1llll11l1_l1_ += 1
			else:
				for l1ll111ll1_l1_ in os.listdir(l1llll1l11_l1_):
					l1ll111l11_l1_ = os.path.abspath(os.path.join(l1llll1l11_l1_,l1ll111ll1_l1_))
					if os.path.isdir(l1ll111l11_l1_):
						l1lll11lll_l1_(l1ll111l11_l1_)
					elif os.path.isfile(l1ll111l11_l1_):
						size,count = l1ll1l1lll_l1_(l1ll111l11_l1_)
						l1lll11l11_l1_ += size
						l1llll11l1_l1_ += count
		return
	try: l1lll11lll_l1_(l1llll1l11_l1_)
	except: pass
	return l1lll11l11_l1_,l1llll11l1_l1_
def l1llll111l_l1_(l1lll111ll_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠩࠪ᪁"),l1l111_l1_ (u"ࠪࠫ᪂"),l1l111_l1_ (u"ࠫࠬ᪃"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪄"),l1lll111ll_l1_+l1l111_l1_ (u"࠭࡜࡯࡞ࡱࠫ᪅")+l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅๅใࠣรࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᪆"))
		if l1llll1l1l_l1_!=1: return
	error = False
	if os.path.exists(l1lll111ll_l1_):
		try: os.remove(l1lll111ll_l1_)
		except Exception as err:
			if l11_l1_: l1111l1_l1_(l1l111_l1_ (u"ࠨࠩ᪇"),l1l111_l1_ (u"ࠩࠪ᪈"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪉"),str(err))
			error = True
	if l11_l1_ and not error:
		l1111l1_l1_(l1l111_l1_ (u"ࠫࠬ᪊"),l1l111_l1_ (u"ࠬ࠭᪋"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪌"),l1l111_l1_ (u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨ᪍"))
		settings.setSetting(l1l111_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ᪎"),l1l111_l1_ (u"ࠩࡖࡓࡒࡋࡔࡉࡋࡑࡋࠬ᪏"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ᪐"))
	return
def l1ll111l1l_l1_(l11_l1_):
	if l11_l1_:
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠫࠬ᪑"),l1l111_l1_ (u"ࠬ࠭᪒"),l1l111_l1_ (u"࠭ࠧ᪓"),l1l111_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᪔"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ๋้ࠦสา์าࠤู๊อࠨ᪕")+l1l111_l1_ (u"ࠩ࡟ࡲࠬ᪖")+l1l111_l1_ (u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠩ᪗")+l1l111_l1_ (u"ࠫࡡࡴࠧ᪘")+l1l111_l1_ (u"ࠬลࠡࠢࠩ᪙")+l1l111_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ᪚"))
		if l1llll1l1l_l1_!=1: return
	l1lllll1l1_l1_(l1lll1l111_l1_,True,False)
	l1lllll1l1_l1_(l1ll111lll_l1_,True,False)
	l1lllll1l1_l1_(l1lll11ll1_l1_,False,False)
	l1ll11llll_l1_(l1ll1l11l1_l1_,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠧࠨ᪛"),l1l111_l1_ (u"ࠨࠩ᪜"),l1l111_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᪝"),l1l111_l1_ (u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ᪞"))
		settings.setSetting(l1l111_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ᪟"),l1l111_l1_ (u"࡙ࠬࡏࡎࡇࡗࡌࡎࡔࡇࠨ᪠"))
		xbmc.executebuiltin(l1l111_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ᪡"))
	return
def l1lll11111_l1_(l11_l1_):
	if l11_l1_:
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠧࠨ᪢"),l1l111_l1_ (u"ࠨࠩ᪣"),l1l111_l1_ (u"ࠩࠪ᪤"),l1l111_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪥"),l1l111_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ็ๅࠢอี๏ีࠠๆีะࠤ๊๊แศฬࠪ᪦")+l1l111_l1_ (u"ࠬࡢ࡮ࠨᪧ")+l1l111_l1_ (u"࠭ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠣ࠲࠳ࠦࡤࡳࡱࡳࡦࡴࡾࠠ࠯࠰ࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠠ࠯࠰ࠣࡰࡴ࡭ࡧࡦࡴࠣ࠲࠳ࠦ࡬ࡰࡩࠣ࠲࠳ࠦࡡ࡯ࡴࠪ᪨")+l1l111_l1_ (u"ࠧ࡝ࡰࠪ᪩")+l1l111_l1_ (u"ࠨࡁࠤࠥࠬ᪪")+l1l111_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᪫"))
		if l1llll1l1l_l1_!=1: return
	l1lllll1l1_l1_(l1ll11l111_l1_,False,False)
	l1lllll1l1_l1_(l1ll11l11l_l1_,False,False)
	l1lllll1l1_l1_(l1lll11l1l_l1_,False,False)
	l1lllll1l1_l1_(l1lll1l11l_l1_,False,False)
	l1lllll1l1_l1_(l1ll11ll11_l1_,False,False)
	l1lllll1l1_l1_(l1ll11ll1l_l1_,False,False)
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"ࠪࠫ᪬"),l1l111_l1_ (u"ࠫࠬ᪭"),l1l111_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᪮"),l1l111_l1_ (u"࠭สๆࠢสู่๊อࠡส้ะฬำࠧ᪯"))
		settings.setSetting(l1l111_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ᪰"),l1l111_l1_ (u"ࠨࡕࡒࡑࡊ࡚ࡈࡊࡐࡊࠫ᪱"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭᪲"))
	return
def l1ll11llll_l1_(l1lll1111l_l1_,l11_l1_):
	if l11_l1_:
		l1llll1l1l_l1_ = l1ll1l111l_l1_(l1l111_l1_ (u"ࠪࠫ᪳"),l1l111_l1_ (u"ࠫࠬ᪴"),l1l111_l1_ (u"᪵ࠬ࠭"),l1l111_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอ᪶ࠩ"),l1l111_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟๊่ࠥะั๋ัุ้ࠣำࠠๆฯอ์๏อสࠡ็็ๅࠥ฻่าࠢส่ั๊ฯࠡมࠤ᪷ࠥࠬ")+l1l111_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟᪸ࠪ"))
		if l1llll1l1l_l1_!=1: return
	conn = sqlite3.connect(l1lll1111l_l1_)
	conn.text_factory = str
	l1lllll1ll_l1_ = conn.cursor()
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࡱࡣࡷ࡬ࡀ᪹࠭"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡵ࡬ࡾࡪࡹ࠻ࠨ᪺"))
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡷࡩࡽࡺࡵࡳࡧ࠾ࠫ᪻"))
	conn.commit()
	l1lllll1ll_l1_.execute(l1l111_l1_ (u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭᪼"))
	conn.close()
	if l11_l1_:
		l1111l1_l1_(l1l111_l1_ (u"᪽࠭ࠧ"),l1l111_l1_ (u"ࠧࠨ᪾"),l1l111_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯᪿࠫ"),l1l111_l1_ (u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯᫀࠪ"))
		settings.setSetting(l1l111_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ᫁"),l1l111_l1_ (u"ࠫࡘࡕࡍࡆࡖࡋࡍࡓࡍࠧ᫂"))
		xbmc.executebuiltin(l1l111_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩ᫃ࠩ"))
	return
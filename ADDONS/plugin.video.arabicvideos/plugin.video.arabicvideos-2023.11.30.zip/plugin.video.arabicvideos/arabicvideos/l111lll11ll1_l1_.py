# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1lll_l1_(l1l111_l1_ (u"ࠩࡗࡉࡘ࡚ࠧ姱"),l1l111_l1_ (u"ࠪࡘࡊ࡙ࡔࠨ姲"))
l1l1l1llll1l_l1_ = l1l111_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡶ࠵࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡹ࡮ࡩ࡯࡭ࡥࡶࡴࡧࡤࡣࡣࡱࡨ࠳ࡩ࡯࡮࠱࠴࠴ࡒࡈ࠮ࡻ࡫ࡳࠫ姳")
l1l1l1llll1l_l1_ = l1l111_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡰࡦࡧࡧࡸࡪࡹࡴ࠯ࡨࡷࡴ࠳ࡵࡴࡦࡰࡨࡸ࠳࡭ࡲ࠰ࡨ࡬ࡰࡪࡹ࠯ࡵࡧࡶࡸ࠶࠶࠰࡬࠰ࡧࡦࠬ姴")
l1lll1llll1l_l1_(l1l1l1llll1l_l1_,{},True)
url = l1l111_l1_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ใะู࠳ࡳࡰ࠴ࠩ姵")
url = l1l111_l1_ (u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ࡩ࡭ࡱ࡫࡟࠵࠺࠶࠸ࡤ࡙ࡈࡗࡡี๎ฬืษࡠษ็ีุ๎ไࡠษ็ว฾฾ๅࡠุࠪ࠭ࡤ࠮รษษำีࡤอไฮๆ๋หั๐ࠩ࠯࡯ࡳ࠷ࠬ姶")
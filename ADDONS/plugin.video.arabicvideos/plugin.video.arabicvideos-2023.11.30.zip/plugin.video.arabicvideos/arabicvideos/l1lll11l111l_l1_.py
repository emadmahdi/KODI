# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l111_l1_ = 2048
l11ll_l1_ = 7
def l1l111_l1_ (l1_l1_):
    global l11lll1_l1_
    l111l_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l111l_l1_ % len (l1l1l1_l1_)
    l1ll111_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l1111l_l1_ = unicode () .join ([unichr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    else:
        l1111l_l1_ = str () .join ([chr (ord (char) - l111_l1_ - (l1l1ll_l1_ + l111l_l1_) % l11ll_l1_) for l1l1ll_l1_, char in enumerate (l1ll111_l1_)])
    return eval (l1111l_l1_)
from LIBSTWO import *
l1ll1_l1_ = l1l111_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄࠫ䎿")
headers = {l1l111_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䏀"):l1l111_l1_ (u"࠭ࠧ䏁")}
l1lllll_l1_ = l1l111_l1_ (u"ࠧࡠࡏࡆࡑࡤ࠭䏂")
l111l1_l1_ = l1l11l1_l1_[l1ll1_l1_][0]
l11lll_l1_ = [l1l111_l1_ (u"ࠨ็ุหึ฿ษࠡฯิอࠬ䏃"),l1l111_l1_ (u"ࠩࡺࡻࡪ࠭䏄")]
def l11l1ll_l1_(mode,url,text):
	if   mode==360: l1lll_l1_ = l1l1l11_l1_()
	elif mode==361: l1lll_l1_ = l1lll11_l1_(url,text)
	elif mode==362: l1lll_l1_ = PLAY(url)
	elif mode==363: l1lll_l1_ = l1ll1l11_l1_(url,text)
	elif mode==364: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ䏅")+text)
	elif mode==365: l1lll_l1_ = l1l1ll1l_l1_(url,l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࡤࡥ࡟ࠨ䏆")+text)
	elif mode==366: l1lll_l1_ = l11ll1_l1_(url)
	elif mode==369: l1lll_l1_ = l1lll1_l1_(text,url)
	else: l1lll_l1_ = False
	return l1lll_l1_
def l1l1l11_l1_():
	addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䏇"),l1lllll_l1_+l1l111_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭䏈"),l111l1_l1_,369,l1l111_l1_ (u"ࠧࠨ䏉"),l1l111_l1_ (u"ࠨࠩ䏊"),l1l111_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䏋"))
	addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䏌"),l1lllll_l1_+l1l111_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧ䏍"),l111l1_l1_+l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䏎"),364)
	addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䏏"),l1lllll_l1_+l1l111_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ䏐"),l111l1_l1_+l1l111_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ䏑"),365)
	addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䏒"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䏓"),l1l111_l1_ (u"ࠫࠬ䏔"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䏕"),l111l1_l1_,l1l111_l1_ (u"࠭ࠧ䏖"),l1l111_l1_ (u"ࠧࠨ䏗"),l1l111_l1_ (u"ࠨࠩ䏘"),l1l111_l1_ (u"ࠩࠪ䏙"),l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ䏚"))
	html = response.content
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡓࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡎࡧࡱࡹࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡳࡍ࡫ࡶࡸࡇࡻࡴࡵࡱࡱࠦࠬ䏛"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡥ࡯ࡷ࠰࡭ࡹ࡫࡭࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䏜"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			if title==l1l111_l1_ (u"࠭ࠧ䏝"): continue
			if any(value in title.lower() for value in l11lll_l1_): continue
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䏞"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䏟")+l1lllll_l1_+title,l1ll1ll_l1_,366)
		addMenuItem(l1l111_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ䏠"),l1l111_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䏡"),l1l111_l1_ (u"ࠫࠬ䏢"),9999)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬ࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠬ࠳࠰࠿ࠪࡪࡲࡺࡪࡸࡡࡣ࡮ࡨࠤࡦࡩࡴࡪࡸࡤࡦࡱ࡫ࠧ䏣"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䏤"),block,re.DOTALL)
		for l1ll1ll_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䏥"),l1ll1_l1_+l1l111_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䏦")+l1lllll_l1_+title,l1ll1ll_l1_,366,l1ll1l_l1_)
	return html
def l11ll1_l1_(url):
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠩࡊࡉ࡙࠭䏧"),url,l1l111_l1_ (u"ࠪࠫ䏨"),l1l111_l1_ (u"ࠫࠬ䏩"),l1l111_l1_ (u"ࠬ࠭䏪"),l1l111_l1_ (u"࠭ࠧ䏫"),l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䏬"))
	html = response.content
	if l1l111_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ䏭") in html:
		addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏮"),l1lllll_l1_+l1l111_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ䏯"),url,361,l1l111_l1_ (u"ࠫࠬ䏰"),l1l111_l1_ (u"ࠬ࠭䏱"),l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䏲"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ䏳"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䏴"),block,re.DOTALL)
		for l1ll1ll_l1_,title in items:
			addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䏵"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1lll11_l1_(l1lll1l11lll_l1_,type=l1l111_l1_ (u"ࠪࠫ䏶")):
	if l1l111_l1_ (u"ࠫ࠿ࡀࠧ䏷") in l1lll1l11lll_l1_:
		l1llllll_l1_,url = l1lll1l11lll_l1_.split(l1l111_l1_ (u"ࠬࡀ࠺ࠨ䏸"))
		server = l1l111l_l1_(l1llllll_l1_,l1l111_l1_ (u"࠭ࡵࡳ࡮ࠪ䏹"))
		url = server+url
	else: url,l1llllll_l1_ = l1lll1l11lll_l1_,l1lll1l11lll_l1_
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠧࡈࡇࡗࠫ䏺"),url,l1l111_l1_ (u"ࠨࠩ䏻"),l1l111_l1_ (u"ࠩࠪ䏼"),l1l111_l1_ (u"ࠪࠫ䏽"),l1l111_l1_ (u"ࠫࠬ䏾"),l1l111_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ䏿"))
	html = response.content
	if type==l1l111_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ䐀"):
		l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ䐁"),html,re.DOTALL)
	elif type==l1l111_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䐂"):
		l11llll_l1_ = [html.replace(l1l111_l1_ (u"ࠩ࡟ࡠ࠴࠭䐃"),l1l111_l1_ (u"ࠪ࠳ࠬ䐄")).replace(l1l111_l1_ (u"ࠫࡡࡢࠢࠨ䐅"),l1l111_l1_ (u"ࠬࠨࠧ䐆"))]
	else:
		l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲ࡓࡹࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ䐇"),html,re.DOTALL)
	l1l1_l1_ = []
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"ࠧࡈࡴ࡬ࡨࡎࡺࡥ࡮ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭䐈"),block,re.DOTALL)
		for l1ll1ll_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l11lll_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ䐉"),l1l111_l1_ (u"ࠩࠪ䐊"))
			if l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ䐋") in l1ll1ll_l1_: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐌"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			elif l1l111_l1_ (u"ࠬำไใหࠪ䐍") in title:
				l1l1lll_l1_ = re.findall(l1l111_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠱อๅไฬࠤ࠰ࡢࡤࠬࠩ䐎"),title,re.DOTALL)
				if l1l1lll_l1_: title = l1l111_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭䐏") + l1l1lll_l1_[0]
				if title not in l1l1_l1_:
					l1l1_l1_.append(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐐"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l1l111_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䐑"),l1lllll_l1_+title,l1ll1ll_l1_,362,l1ll1l_l1_)
		if type==l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䐒"):
			l1111ll11l_l1_ = re.findall(l1l111_l1_ (u"ࠫࠧࡳ࡯ࡳࡧࡢࡦࡺࡺࡴࡰࡰࡢࡴࡦ࡭ࡥࠣ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩ䐓"),block,re.DOTALL)
			if l1111ll11l_l1_:
				count = l1111ll11l_l1_[0]
				l1ll1ll_l1_ = url+l1l111_l1_ (u"ࠬ࠵࡯ࡧࡨࡶࡩࡹ࠵ࠧ䐔")+count
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䐕"),l1lllll_l1_+l1l111_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ䐖"),l1ll1ll_l1_,361,l1l111_l1_ (u"ࠨࠩ䐗"),l1l111_l1_ (u"ࠩࠪ䐘"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䐙"))
		elif type==l1l111_l1_ (u"ࠫࠬ䐚"):
			l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䐛"),html,re.DOTALL)
			if l11llll_l1_:
				block = l11llll_l1_[0]
				items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䐜"),block,re.DOTALL)
				for l1ll1ll_l1_,title in items:
					title = l1l111_l1_ (u"ࠧึใะอࠥ࠭䐝")+unescapeHTML(title)
					addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐞"),l1lllll_l1_+title,l1ll1ll_l1_,361)
	return
def l1ll1l11_l1_(url,type=l1l111_l1_ (u"ࠩࠪ䐟")):
	response = l11l1l_l1_(l11l1l1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䐠"),url,l1l111_l1_ (u"ࠫࠬ䐡"),l1l111_l1_ (u"ࠬ࠭䐢"),l1l111_l1_ (u"࠭ࠧ䐣"),l1l111_l1_ (u"ࠧࠨ䐤"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䐥"))
	html = response.content
	html = l111l11_l1_(html)
	name = re.findall(l1l111_l1_ (u"ࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ䐦"),html,re.DOTALL)
	if name: name = name[-1].replace(l1l111_l1_ (u"ࠪ࠱ࠬ䐧"),l1l111_l1_ (u"ࠫࠥ࠭䐨")).strip(l1l111_l1_ (u"ࠬ࠵ࠧ䐩"))
	if l1l111_l1_ (u"࠭ๅ้ี่ࠫ䐪") in name and type==l1l111_l1_ (u"ࠧࠨ䐫"):
		name = name.split(l1l111_l1_ (u"ࠨ็๋ื๊࠭䐬"))[0]
		name = name.replace(l1l111_l1_ (u"ุ่ࠩฬํฯสࠩ䐭"),l1l111_l1_ (u"ࠪࠫ䐮")).strip(l1l111_l1_ (u"ࠫࠥ࠭䐯"))
	elif l1l111_l1_ (u"ࠬำไใหࠪ䐰") in name:
		name = name.split(l1l111_l1_ (u"࠭อๅไฬࠫ䐱"))[0]
		name = name.replace(l1l111_l1_ (u"ࠧๆึส๋ิฯࠧ䐲"),l1l111_l1_ (u"ࠨࠩ䐳")).strip(l1l111_l1_ (u"ࠩࠣࠫ䐴"))
	else: name = name
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࠧ䐵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		if type==l1l111_l1_ (u"ࠫࠬ䐶"):
			items = re.findall(l1l111_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ䐷"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				if l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࠬ䐸") in title: continue
				if l1l111_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨ䐹") in title: continue
				title = name+l1l111_l1_ (u"ࠨࠢ࠰ࠤࠬ䐺")+title
				addMenuItem(l1l111_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䐻"),l1lllll_l1_+title,l1ll1ll_l1_,363,l1l111_l1_ (u"ࠪࠫ䐼"),l1l111_l1_ (u"ࠫࠬ䐽"),l1l111_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ䐾"))
		if len(menuItemsLIST)==0:
			l1l1l1l_l1_ = re.findall(l1l111_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠮࠯ࡖࡩࡦࡹ࡯࡯ࡵ࠰࠱ࡊࡶࡩࡴࡱࡧࡩࡸࠨࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䐿"),block+l1l111_l1_ (u"ࠧࠧࠨࠪ䑀"),re.DOTALL)
			if l1l1l1l_l1_: block = l1l1l1l_l1_[0]
			items = re.findall(l1l111_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡩࡵ࡯ࡳࡰࡦࡨࡘ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䑁"),block,re.DOTALL)
			for l1ll1ll_l1_,title in items:
				title = title.strip(l1l111_l1_ (u"ࠩࠣࠫ䑂"))
				title = name+l1l111_l1_ (u"ࠪࠤ࠲ࠦࠧ䑃")+title
				addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䑄"),l1lllll_l1_+title,l1ll1ll_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l1l111_l1_ (u"ࠬࡂࡴࡪࡶ࡯ࡩࡃ࠮࠮ࠫࡁࠬࡀࠬ䑅"),html,re.DOTALL)
		if title: title = title[0].replace(l1l111_l1_ (u"࠭ࠠ࠮่ࠢห๏ࠦำ๋็สࠫ䑆"),l1l111_l1_ (u"ࠧࠨ䑇")).replace(l1l111_l1_ (u"ࠨ็ืห์ีษࠡࠩ䑈"),l1l111_l1_ (u"ࠩࠪ䑉"))
		else: title = l1l111_l1_ (u"้้ࠪ็ࠠศๆอุ฿๐ไࠨ䑊")
		addMenuItem(l1l111_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䑋"),l1lllll_l1_+title,url,362)
	return
def PLAY(url):
	l1llll_l1_ = []
	response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠬࡍࡅࡕࠩ䑌"),url,l1l111_l1_ (u"࠭ࠧ䑍"),l1l111_l1_ (u"ࠧࠨ䑎"),l1l111_l1_ (u"ࠨࠩ䑏"),l1l111_l1_ (u"ࠩࠪ䑐"),l1l111_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䑑"))
	html = response.content
	l1111ll_l1_ = re.findall(l1l111_l1_ (u"ࠫࡁࡹࡰࡢࡰࡁห้ะี็์ไࡀ࠳࠰࠿࠽ࡣ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䑒"),html,re.DOTALL)
	if l1111ll_l1_:
		l1111ll_l1_ = [l1111ll_l1_[0][0],l1111ll_l1_[0][1]]
		if l1111ll_l1_ and l11111l_l1_(l1ll1_l1_,url,l1111ll_l1_): return
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡝ࡡࡵࡥ࡫ࡗࡪࡸࡶࡦࡴࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࡊࡳࡢࡦࡦࠥࠫ䑓"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䑔"),block,re.DOTALL)
		for l1ll1ll_l1_,name in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䑕") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			if name==l1l111_l1_ (u"ࠨีํีๆืࠠๆษํࠤุ๐ๅศࠩ䑖"): name = l1l111_l1_ (u"ࠩࡰࡽࡨ࡯࡭ࡢࠩ䑗")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䑘")+name+l1l111_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ䑙")
			l1llll_l1_.append(l1ll1ll_l1_)
	l11llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩࡴࡶ࠰࠱ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䑚"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l1l111_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䑛"),block,re.DOTALL)
		for l1ll1ll_l1_,l111l1ll_l1_ in items:
			if l1l111_l1_ (u"ࠧࡩࡶࡷࡴࠬ䑜") not in l1ll1ll_l1_: l1ll1ll_l1_ = l111l1_l1_+l1ll1ll_l1_
			l111l1ll_l1_ = re.findall(l1l111_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ䑝"),l111l1ll_l1_,re.DOTALL)
			if l111l1ll_l1_: l111l1ll_l1_ = l1l111_l1_ (u"ࠩࡢࡣࡤࡥࠧ䑞")+l111l1ll_l1_[0]
			else: l111l1ll_l1_ = l1l111_l1_ (u"ࠪࠫ䑟")
			l1ll1ll_l1_ = l1ll1ll_l1_+l1l111_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡲࡿࡣࡪ࡯ࡤࠫ䑠")+l1l111_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ䑡")+l111l1ll_l1_
			l1llll_l1_.append(l1ll1ll_l1_)
	import ll_l1_
	ll_l1_.l1l_l1_(l1llll_l1_,l1ll1_l1_,l1l111_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䑢"),url)
	return
def l1lll1_l1_(search,hostname=l1l111_l1_ (u"ࠧࠨ䑣")):
	search,options,l11_l1_ = l111ll_l1_(search)
	if search==l1l111_l1_ (u"ࠨࠩ䑤"): search = l1llll1_l1_()
	if search==l1l111_l1_ (u"ࠩࠪ䑥"): return
	search = search.replace(l1l111_l1_ (u"ࠪࠤࠬ䑦"),l1l111_l1_ (u"ࠫ࠰࠭䑧"))
	l1llll_l1_ = [l1l111_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ䑨"),l1l111_l1_ (u"࠭࠯ࠨ䑩"),l1l111_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡳࡦࡴ࡬ࡩࡸ࠭䑪"),l1l111_l1_ (u"ࠨ࠱࡯࡭ࡸࡺ࠯ࡢࡰ࡬ࡱࡪ࠭䑫"),l1l111_l1_ (u"ࠩ࠲ࡰ࡮ࡹࡴ࠰ࡶࡹࠫ䑬")]
	l1ll11111_l1_ = [l1l111_l1_ (u"ࠪห้้ไࠨ䑭"),l1l111_l1_ (u"ࠫฬ๊รโๆส้ࠬ䑮"),l1l111_l1_ (u"ࠬอไๆี็ื้อสࠨ䑯"),l1l111_l1_ (u"࠭วๅษ้๎๊๐้ࠠࠢส่่ืส้่ࠪ䑰"),l1l111_l1_ (u"ࠧศๆหีฬ๋ฬࠡฬ็๎ๆุ๊้่ํอࠬ䑱")]
	if l11_l1_:
		l11l11l_l1_ = l1ll11ll_l1_(l1l111_l1_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆู็์อࡀࠧ䑲"), l1ll11111_l1_)
		if l11l11l_l1_==-1: return
	else: l11l11l_l1_ = 0
	if hostname==l1l111_l1_ (u"ࠩࠪ䑳"):
		response = l11l1l_l1_(l111l11l_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䑴"),l111l1_l1_,l1l111_l1_ (u"ࠫࠬ䑵"),l1l111_l1_ (u"ࠬ࠭䑶"),False,l1l111_l1_ (u"࠭ࠧ䑷"),l1l111_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䑸"))
		hostname = response.headers[l1l111_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䑹")]
		hostname = hostname.strip(l1l111_l1_ (u"ࠩ࠲ࠫ䑺"))
	l1lllll1_l1_ = hostname+l1l111_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࠬ䑻")+search+l1llll_l1_[l11l11l_l1_]
	l1lll11_l1_(l1lllll1_l1_)
	return
def l1l1ll1l_l1_(l1lll1l11lll_l1_,filter):
	if l1l111_l1_ (u"ࠫࡄࡅࠧ䑼") in l1lll1l11lll_l1_: url = l1lll1l11lll_l1_.split(l1l111_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ䑽"))[0]
	else: url = l1lll1l11lll_l1_
	filter = filter.replace(l1l111_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䑾"),l1l111_l1_ (u"ࠧࠨ䑿"))
	type,filter = filter.split(l1l111_l1_ (u"ࠨࡡࡢࡣࠬ䒀"),1)
	if filter==l1l111_l1_ (u"ࠩࠪ䒁"): l11lll1l_l1_,l11lll11_l1_ = l1l111_l1_ (u"ࠪࠫ䒂"),l1l111_l1_ (u"ࠫࠬ䒃")
	else: l11lll1l_l1_,l11lll11_l1_ = filter.split(l1l111_l1_ (u"ࠬࡥ࡟ࡠࠩ䒄"))
	if type==l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䒅"):
		if l1l1lll11_l1_[0]+l1l111_l1_ (u"ࠧ࠾࠿ࠪ䒆") not in l11lll1l_l1_: category = l1l1lll11_l1_[0]
		for i in range(len(l1l1lll11_l1_[0:-1])):
			if l1l1lll11_l1_[i]+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䒇") in l11lll1l_l1_: category = l1l1lll11_l1_[i+1]
		l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䒈")+category+l1l111_l1_ (u"ࠪࡁࡂ࠶ࠧ䒉")
		l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䒊")+category+l1l111_l1_ (u"ࠬࡃ࠽࠱ࠩ䒋")
		l1l111l1_l1_ = l1l11ll1_l1_.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ䒌"))+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ䒍")+l1l1ll11_l1_.strip(l1l111_l1_ (u"ࠨࠨࠩࠫ䒎"))
		l11ll111_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䒏"))
		l1lllll1_l1_ = url+l1l111_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䒐")+l11ll111_l1_
	elif type==l1l111_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ䒑"):
		l11l1l1l_l1_ = l11ll1l1_l1_(l11lll1l_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ䒒"))
		l11l1l1l_l1_ = l111l11_l1_(l11l1l1l_l1_)
		if l11lll11_l1_!=l1l111_l1_ (u"࠭ࠧ䒓"): l11lll11_l1_ = l11ll1l1_l1_(l11lll11_l1_,l1l111_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ䒔"))
		if l11lll11_l1_==l1l111_l1_ (u"ࠨࠩ䒕"): l1lllll1_l1_ = url
		else: l1lllll1_l1_ = url+l1l111_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ䒖")+l11lll11_l1_
		l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1l11lll_l1_)
		addMenuItem(l1l111_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䒗"),l1lllll_l1_+l1l111_l1_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ䒘"),l1111111_l1_,361,l1l111_l1_ (u"ࠬ࠭䒙"),l1l111_l1_ (u"࠭ࠧ䒚"),l1l111_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䒛"))
		addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䒜"),l1lllll_l1_+l1l111_l1_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩ䒝")+l11l1l1l_l1_+l1l111_l1_ (u"ࠪࠤࠥࠦ࡝࡞ࠩ䒞"),l1111111_l1_,361,l1l111_l1_ (u"ࠫࠬ䒟"),l1l111_l1_ (u"ࠬ࠭䒠"),l1l111_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ䒡"))
		addMenuItem(l1l111_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䒢"),l1l111_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䒣"),l1l111_l1_ (u"ࠩࠪ䒤"),9999)
	response = l11l1l_l1_(l1ll1ll1_l1_,l1l111_l1_ (u"ࠪࡋࡊ࡚ࠧ䒥"),url,l1l111_l1_ (u"ࠫࠬ䒦"),l1l111_l1_ (u"ࠬ࠭䒧"),l1l111_l1_ (u"࠭ࠧ䒨"),l1l111_l1_ (u"ࠧࠨ䒩"),l1l111_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䒪"))
	html = response.content
	html = html.replace(l1l111_l1_ (u"ࠩ࡟ࡠࠧ࠭䒫"),l1l111_l1_ (u"ࠪࠦࠬ䒬")).replace(l1l111_l1_ (u"ࠫࡡࡢ࠯ࠨ䒭"),l1l111_l1_ (u"ࠬ࠵ࠧ䒮"))
	l11llll_l1_ = re.findall(l1l111_l1_ (u"࠭࠼࡮ࡻࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲࠩ࠰࠭ࡃ࠮ࡂ࠯࡮ࡻࡦ࡭ࡲࡧ࠭࠮ࡨ࡬ࡰࡹ࡫ࡲ࠿ࠩ䒯"),html,re.DOTALL)
	if not l11llll_l1_: return
	block = l11llll_l1_[0]
	l1l11l1l_l1_ = re.findall(l1l111_l1_ (u"ࠧࡵࡣࡻࡳࡳࡵ࡭ࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ䒰"),block+l1l111_l1_ (u"ࠨ࠾ࡩ࡭ࡱࡺࡥࡳࡤࡲࡼࠬ䒱"),re.DOTALL)
	dict = {}
	for l1l111ll_l1_,name,block in l1l11l1l_l1_:
		name = escapeUNICODE(name)
		if l1l111_l1_ (u"ࠩ࡬ࡲࡹ࡫ࡲࡦࡵࡷࠫ䒲") in l1l111ll_l1_: continue
		items = re.findall(l1l111_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡸࡽࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡺࡷࡂࠬ䒳"),block,re.DOTALL)
		if l1l111_l1_ (u"ࠫࡂࡃࠧ䒴") not in l1lllll1_l1_: l1lllll1_l1_ = url
		if type==l1l111_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ䒵"):
			if category!=l1l111ll_l1_: continue
			elif len(items)<=1:
				if l1l111ll_l1_==l1l1lll11_l1_[-1]: l1lll11_l1_(l1lllll1_l1_)
				else: l1l1ll1l_l1_(l1lllll1_l1_,l1l111_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭䒶")+l1l111l1_l1_)
				return
			else:
				l1111111_l1_ = l1l1l11l1_l1_(l1lllll1_l1_,l1lll1l11lll_l1_)
				if l1l111ll_l1_==l1l1lll11_l1_[-1]:
					addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䒷"),l1lllll_l1_+l1l111_l1_ (u"ࠨษ็ะ๊๐ูࠨ䒸"),l1111111_l1_,361,l1l111_l1_ (u"ࠩࠪ䒹"),l1l111_l1_ (u"ࠪࠫ䒺"),l1l111_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ䒻"))
				else: addMenuItem(l1l111_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒼"),l1lllll_l1_+l1l111_l1_ (u"࠭วๅฮ่๎฾࠭䒽"),l1lllll1_l1_,364,l1l111_l1_ (u"ࠧࠨ䒾"),l1l111_l1_ (u"ࠨࠩ䒿"),l1l111l1_l1_)
		elif type==l1l111_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࠪ䓀"):
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠪࠪࠫ࠭䓁")+l1l111ll_l1_+l1l111_l1_ (u"ࠫࡂࡃ࠰ࠨ䓂")
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠬࠬࠦࠨ䓃")+l1l111ll_l1_+l1l111_l1_ (u"࠭࠽࠾࠲ࠪ䓄")
			l1l111l1_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠧࡠࡡࡢࠫ䓅")+l1l1ll11_l1_
			addMenuItem(l1l111_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䓆"),l1lllll_l1_+name+l1l111_l1_ (u"ࠩ࠽ࠤฬ๊ฬๆ์฼ࠫ䓇"),l1lllll1_l1_,365,l1l111_l1_ (u"ࠪࠫ䓈"),l1l111_l1_ (u"ࠫࠬ䓉"),l1l111l1_l1_+l1l111_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ䓊"))
		dict[l1l111ll_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l1l111_l1_ (u"࠭ࡲࠨ䓋") or value==l1l111_l1_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭䓌"): continue
			if any(value in option.lower() for value in l11lll_l1_): continue
			if l1l111_l1_ (u"ࠨࡪࡷࡸࡵ࠭䓍") in option: continue
			if l1l111_l1_ (u"ࠩส่่๊ࠧ䓎") in option: continue
			if l1l111_l1_ (u"ࠪࡲ࠲ࡧࠧ䓏") in value: continue
			if option==l1l111_l1_ (u"ࠫࠬ䓐"): option = value
			l1l11l1ll_l1_ = option
			l1ll111llll_l1_ = re.findall(l1l111_l1_ (u"ࠬࡂ࡮ࡢ࡯ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡳࡧ࡭ࡦࡀࠪ䓑"),option,re.DOTALL)
			if l1ll111llll_l1_: l1l11l1ll_l1_ = l1ll111llll_l1_[0]
			l1lllllll_l1_ = name+l1l111_l1_ (u"࠭࠺ࠡࠩ䓒")+l1l11l1ll_l1_
			dict[l1l111ll_l1_][value] = l1lllllll_l1_
			l1l11ll1_l1_ = l11lll1l_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䓓")+l1l111ll_l1_+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䓔")+l1l11l1ll_l1_
			l1l1ll11_l1_ = l11lll11_l1_+l1l111_l1_ (u"ࠩࠩࠪࠬ䓕")+l1l111ll_l1_+l1l111_l1_ (u"ࠪࡁࡂ࠭䓖")+value
			l1l1l11l_l1_ = l1l11ll1_l1_+l1l111_l1_ (u"ࠫࡤࡥ࡟ࠨ䓗")+l1l1ll11_l1_
			if type==l1l111_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䓘"):
				addMenuItem(l1l111_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓙"),l1lllll_l1_+l1lllllll_l1_,url,365,l1l111_l1_ (u"ࠧࠨ䓚"),l1l111_l1_ (u"ࠨࠩ䓛"),l1l1l11l_l1_+l1l111_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䓜"))
			elif type==l1l111_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ䓝") and l1l1lll11_l1_[-2]+l1l111_l1_ (u"ࠫࡂࡃࠧ䓞") in l11lll1l_l1_:
				l11ll111_l1_ = l11ll1l1_l1_(l1l1ll11_l1_,l1l111_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䓟"))
				l1llllll_l1_ = url+l1l111_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䓠")+l11ll111_l1_
				l1111111_l1_ = l1l1l11l1_l1_(l1llllll_l1_,l1lll1l11lll_l1_)
				addMenuItem(l1l111_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓡"),l1lllll_l1_+l1lllllll_l1_,l1111111_l1_,361,l1l111_l1_ (u"ࠨࠩ䓢"),l1l111_l1_ (u"ࠩࠪ䓣"),l1l111_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䓤"))
			else: addMenuItem(l1l111_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䓥"),l1lllll_l1_+l1lllllll_l1_,url,364,l1l111_l1_ (u"ࠬ࠭䓦"),l1l111_l1_ (u"࠭ࠧ䓧"),l1l1l11l_l1_)
	return
l1l1lll11_l1_ = [l1l111_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭䓨"),l1l111_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䓩"),l1l111_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ䓪")]
l1l1ll111_l1_ = [l1l111_l1_ (u"ࠪࡱࡵࡧࡡࠨ䓫"),l1l111_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䓬"),l1l111_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䓭"),l1l111_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ䓮"),l1l111_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ䓯"),l1l111_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ䓰"),l1l111_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ䓱"),l1l111_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ䓲")]
def l1l1l11l1_l1_(l1lllll1_l1_,l1llllll_l1_):
	if l1l111_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䓳") in l1lllll1_l1_: l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䓴"),l1l111_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ䓵"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䓶"),l1l111_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ䓷"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠩࡀࡁࠬ䓸"),l1l111_l1_ (u"ࠪ࠳ࠬ䓹"))
	l1lllll1_l1_ = l1lllll1_l1_.replace(l1l111_l1_ (u"ࠫࠫࠬࠧ䓺"),l1l111_l1_ (u"ࠬ࠵ࠧ䓻"))
	return l1lllll1_l1_
def l11ll1l1_l1_(filters,mode):
	filters = filters.strip(l1l111_l1_ (u"࠭ࠦࠧࠩ䓼"))
	l11lllll_l1_,l1l1l111_l1_ = {},l1l111_l1_ (u"ࠧࠨ䓽")
	if l1l111_l1_ (u"ࠨ࠿ࡀࠫ䓾") in filters:
		items = filters.split(l1l111_l1_ (u"ࠩࠩࠪࠬ䓿"))
		for item in items:
			var,value = item.split(l1l111_l1_ (u"ࠪࡁࡂ࠭䔀"))
			l11lllll_l1_[var] = value
	for key in l1l1ll111_l1_:
		if key in list(l11lllll_l1_.keys()): value = l11lllll_l1_[key]
		else: value = l1l111_l1_ (u"ࠫ࠵࠭䔁")
		if l1l111_l1_ (u"ࠬࠫࠧ䔂") not in value: value = QUOTE(value)
		if mode==l1l111_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䔃") and value!=l1l111_l1_ (u"ࠧ࠱ࠩ䔄"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠨࠢ࠮ࠤࠬ䔅")+value
		elif mode==l1l111_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䔆") and value!=l1l111_l1_ (u"ࠪ࠴ࠬ䔇"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠫࠫࠬࠧ䔈")+key+l1l111_l1_ (u"ࠬࡃ࠽ࠨ䔉")+value
		elif mode==l1l111_l1_ (u"࠭ࡡ࡭࡮ࠪ䔊"): l1l1l111_l1_ = l1l1l111_l1_+l1l111_l1_ (u"ࠧࠧࠨࠪ䔋")+key+l1l111_l1_ (u"ࠨ࠿ࡀࠫ䔌")+value
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠩࠣ࠯ࠥ࠭䔍"))
	l1l1l111_l1_ = l1l1l111_l1_.strip(l1l111_l1_ (u"ࠪࠪࠫ࠭䔎"))
	return l1l1l111_l1_
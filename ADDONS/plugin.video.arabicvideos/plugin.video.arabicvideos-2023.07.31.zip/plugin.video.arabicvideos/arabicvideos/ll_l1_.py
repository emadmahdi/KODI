# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䔗")
#l1ll1llll11l_l1_ = [ l11l1l_l1_ (u"࠭࡭ࡺࡵࡷࡶࡪࡧ࡭ࠨ䔘"),l11l1l_l1_ (u"ࠧࡷ࡫ࡰࡴࡱ࡫ࠧ䔙"),l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡧࡵ࡭ࠨ䔚"),l11l1l_l1_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ䔛") ]
l1ll1llll11l_l1_ = []
headers = {l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䔜"):l11l1l_l1_ (u"ࠫࠬ䔝")}
def l11_l1_(l1lll11l_l1_,source,type,url):
	#DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ืวษูࠣห้๋ๆศีหࠫ䔞"),l1lll11l_l1_)
	if not l1lll11l_l1_:
		LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䔟"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡪ࡮ࡴࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࡴࠢࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ䔠")+source+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࠠࡕࡻࡳࡩ࠿࡛ࠦࠡࠩ䔡")+type+l11l1l_l1_ (u"ࠩࠣࡡࠬ䔢"))
		l1llll11111l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ䔣"),l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䔤"),l11l1l_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䔥"))
		datetime = time.strftime(l11l1l_l1_ (u"࡚࠭ࠥ࠰ࠨࡱ࠳ࠫࡤࠡࠧࡋ࠾ࠪࡓࠧ䔦"),time.gmtime(now))
		line = datetime,url
		key = source+l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠬ䔧")+addon_version+l11l1l_l1_ (u"ࠨࠢࠣࠤࠥ࠭䔨")+str(kodi_version)
		if key not in list(l1llll11111l_l1_.keys()): l1llll11111l_l1_[key] = [line]
		else: l1llll11111l_l1_[key].append(line)
		total = 0
		for key in list(l1llll11111l_l1_.keys()):
			l1llll11111l_l1_[key] = list(set(l1llll11111l_l1_[key]))
			total += len(l1llll11111l_l1_[key])
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䔩"),l11l1l_l1_ (u"ࠪࠫ䔪"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䔫"),l11l1l_l1_ (u"๊ࠬไฤีไࠤฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅๅใสฮࠥอไโ์า๎ํࠦ࡜࡯࡞ࡱࠤู้๊ๅ็ࠣห้ฮั็ษ่ะࠥ๐โ้็ࠣฬัู๋ࠡไสส๊ฯࠠษษ็ๅ๏ี๊้้สฮࠥอไห์่๊๊ࠣࠦอั่ࠣ์อࠠๆๆไหฯࠦแ๋ัํ์ࠥ๎ำ้ใࠣ๎฾ืึࠡ฻็๎่ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤฯืำๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ฿ๆะ็สࠤ๏฻ศฮࠢ฼ำิํวࠡ࠹ࠣๅ๏ี๊้้สฮࠬ䔬")+l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ䔭")+l11l1l_l1_ (u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪ䔮")+str(total))
		if total>=7:
			l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࠩ䔯"),l11l1l_l1_ (u"ࠩࠪ䔰"),l11l1l_l1_ (u"ࠪࠫ䔱"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ䔲"),l11l1l_l1_ (u"ࠬอไษำ้ห๊าࠠอ็฼ࠤ็อฦๆหࠣๅ๏ํวࠡ࠹ࠣๅ๏ี๊้้สฮ๊ࠥๅࠡ์ฯำࠥอไษำ้ห๊าࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้ࠢ࠱࠲ู่ࠥโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษ็ึัࠥํะ่ࠢส่็อฦๆหࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢศีุอไ้ࠡำ๋ࠥอไใษษ้ฮࠦโษๆุ้ࠣำ็ศࠢศ่๎ࠦวๅ็หี๊าࠠๅๅํࠤ๏่่ๆࠢส่๊ฮัๆฮࠣฬๆำี้ࠡำ๋ࠥอไโ์า๎ํํวหࠢยࠥࠦ࠭䔳"))
			if l1ll111111_l1_==1:
				l1llll1111ll_l1_ = l11l1l_l1_ (u"࠭ࠧ䔴")
				for key in list(l1llll11111l_l1_.keys()):
					l1llll1111ll_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ䔵")+key
					l1l1ll1l111l_l1_ = sorted(l1llll11111l_l1_[key],reverse=False,key=lambda l11ll11l1ll_l1_: l11ll11l1ll_l1_[0])
					for datetime,url in l1l1ll1l111l_l1_:
						l1llll1111ll_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࠫ䔶")+datetime+l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ䔷")+l1llll_l1_(url)
					l1llll1111ll_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ䔸")
				import l1l1l1ll1l1l_l1_
				l1ll11l1lll1_l1_ = l11l1l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ䔹")+l1l11ll1lll_l1_(32)+l11l1l_l1_ (u"ࠬ࠳ࡖࡪࡦࡨࡳࡸ࠭䔺")
				succeeded = l1l1l1ll1l1l_l1_.l1llll1l1l11_l1_(l1ll11l1lll1_l1_,l11l1l_l1_ (u"࠭ࠧ䔻"),False,l11l1l_l1_ (u"ࠧࠨ䔼"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䔽"),l11l1l_l1_ (u"ࠩࠪ䔾"),l1llll1111ll_l1_)
				if succeeded: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䔿"),l11l1l_l1_ (u"ࠫࠬ䕀"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ䕁"),l11l1l_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ䕂"))
				else: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䕃"),l11l1l_l1_ (u"ࠨࠩ䕄"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䕅"),l11l1l_l1_ (u"ࠪๅู๊สࠡ฻่่๏ฯࠠศๆศีุอไࠨ䕆"))
			if l1ll111111_l1_!=-1:
				l1llll11111l_l1_ = {}
				DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ䕇"),l11l1l_l1_ (u"࡙ࠬࡉࡕࡇࡖࡣࡊࡘࡒࡐࡔࡖࠫ䕈"))
		if l1llll11111l_l1_: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䕉"),l11l1l_l1_ (u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭䕊"),l1llll11111l_l1_,PERMANENT_CACHE)
		return
	l1lll11l_l1_ = list(set(l1lll11l_l1_))
	l1ll1ll1_l1_,l1lll1_l1_ = l1l1lll1l1l1_l1_(l1lll11l_l1_,source)
	l1l1ll11llll_l1_ = str(l1lll1_l1_).count(l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䕋"))
	l1l1lll1ll1l_l1_ = str(l1lll1_l1_).count(l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䕌"))
	l1l1ll1l11ll_l1_ = len(l1lll1_l1_)-l1l1ll11llll_l1_-l1l1lll1ll1l_l1_
	l1l1lllll11l_l1_ = l11l1l_l1_ (u"ู้ࠪอ็ะห࠽ࠫ䕍")+str(l1l1ll11llll_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࠡฬะ้๏๊࠺ࠨ䕎")+str(l1l1lll1ll1l_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࠢฦาึ๏࠺ࠨ䕏")+str(l1l1ll1l11ll_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䕐"),l11l1l_l1_ (u"ࠧࠨ䕑"),str(l1l1ll11llll_l1_),str(l1l1lll1ll1l_l1_))
	#l1l_l1_ = DIALOG_SELECT(l1l1lllll11l_l1_, l1lll1_l1_)
	if not l1lll1_l1_:
		result = l11l1l_l1_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ䕒")
		l111111llll_l1_ = l11l1l_l1_ (u"ࠩࠪ䕓")
	else:
		while True:
			l111111llll_l1_ = l11l1l_l1_ (u"ࠪࠫ䕔")
			if len(l1lll1_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l1l1lllll11l_l1_,l1ll1ll1_l1_)
			if l1l_l1_==-1: result = l11l1l_l1_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ䕕")
			else:
				title = l1ll1ll1_l1_[l1l_l1_]
				l1llll1_l1_ = l1lll1_l1_[l1l_l1_]
				#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䕖"),l11l1l_l1_ (u"࠭ࠧ䕗"),title,l1llll1_l1_)
				if l11l1l_l1_ (u"ࠧิ์ิๅึ࠭䕘") in title and l11l1l_l1_ (u"ࠨ࠴่ะ์๎ไ࠳ࠩ䕙") in title:
					LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ䕚"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ䕛")+title+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ䕜")+l1llll1_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ䕝"))
					import l1l1l1ll1l1l_l1_
					l1l1l1ll1l1l_l1_.MAIN(156)
					result = l11l1l_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䕞")
				else:
					LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䕟"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡕࡲࡡࡺ࡫ࡱ࡫࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࡔࡧࡵࡺࡪࡸࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭䕠")+title+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ䕡")+l1llll1_l1_+l11l1l_l1_ (u"ࠪࠤࡢ࠭䕢"))
					result,l111111llll_l1_,l111lllll11_l1_ = l1ll11111lll_l1_(l1llll1_l1_,source,type)
					#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䕣"),l11l1l_l1_ (u"ࠬ࠭䕤"),result,l111111llll_l1_)
			if l11l1l_l1_ (u"࠭࡜࡯ࠩ䕥") not in l111111llll_l1_: l1llllll1l1l_l1_,l1llllll1l11_l1_ = l111111llll_l1_,l11l1l_l1_ (u"ࠧࠨ䕦")
			else: l1llllll1l1l_l1_,l1llllll1l11_l1_ = l111111llll_l1_.split(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ䕧"),1)
			if result in [l11l1l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䕨"),l11l1l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ䕩"),l11l1l_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ䕪"),l11l1l_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ䕫")] or len(l1lll1_l1_)==1: break
			elif result in [l11l1l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭䕬"),l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ䕭"),l11l1l_l1_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ䕮")]: break
			elif result not in [l11l1l_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭䕯"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ䕰")]: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䕱"),l11l1l_l1_ (u"ࠬ࠭䕲"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ䕳"),l11l1l_l1_ (u"ࠧศๆึ๎ึ็ัࠡๆ่ࠤ๏฿ๅๅࠢฯีอࠦำ๋ำไีࠥเ๊า้ࠪ䕴")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ䕵")+l1llllll1l1l_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ䕶")+l1llllll1l11_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䕷"),l11l1l_l1_ (u"ࠫࠬ䕸"),l11l1l_l1_ (u"ࠬ࠭䕹"),str(l111lllll11_l1_))
	if result==l11l1l_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䕺") and len(l1ll1ll1_l1_)>0: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䕻"),l11l1l_l1_ (u"ࠨࠩ䕼"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䕽"),l11l1l_l1_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ䕾")+l11l1l_l1_ (u"ࠫࡡࡴࠧ䕿")+l111111llll_l1_)
	elif result in [l11l1l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ䖀"),l11l1l_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ䖁")] and l111111llll_l1_!=l11l1l_l1_ (u"ࠧࠨ䖂"): DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䖃"),l11l1l_l1_ (u"ࠩࠪ䖄"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䖅"),l111111llll_l1_)
	#elif l111111llll_l1_==l11l1l_l1_ (u"ࠫࡗࡋࡔࡖࡔࡑࡣ࡙ࡕ࡟࡚ࡑࡘࡘ࡚ࡈࡅࠨ䖆"): result = l111lllll11_l1_
	l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰ࡮࡬ࠠࡳࡧࡶࡹࡱࡺࠠࡪࡰࠣ࡟ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ࠯ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ࡟࠽ࠎࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡖࡨࡷࡹࡀࠠࠡࠢࠪ࠯ࡸࡿࡳ࠯ࡣࡵ࡫ࡻࡡ࠰࡞࠭ࡶࡽࡸ࠴ࡡࡳࡩࡹ࡟࠷ࡣࠩࠋࠋࠌࡼࡧࡳࡣࡱ࡮ࡸ࡫࡮ࡴ࠮ࡴࡧࡷࡖࡪࡹ࡯࡭ࡸࡨࡨ࡚ࡸ࡬ࠩࡣࡧࡨࡴࡴ࡟ࡩࡣࡱࡨࡱ࡫ࠬࠡࡈࡤࡰࡸ࡫ࠬࠡࡺࡥࡱࡨ࡭ࡵࡪ࠰ࡏ࡭ࡸࡺࡉࡵࡧࡰࠬ࠮࠯ࠊࠊࠋࡳࡰࡦࡿ࡟ࡪࡶࡨࡱࠥࡃࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡎ࡬ࡷࡹࡏࡴࡦ࡯ࠫࡴࡦࡺࡨ࠾ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠱ࡂࡱࡴࡪࡥ࠾࠳࠷࠷ࠫࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࠩ࠸ࡌࡶࠦ࠵ࡇ࡫ࡼࡨ࠱ࡱࡺ࡙ࡸࡼ࠿ࡑࠨࠫࠍࠍࠎࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡶ࡬ࡢࡻࠫࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬࡬ࡷ࠳࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳ࠯ࡪࡲ࡫ࡳࡳ࡫࠯࠲࠴࠶࠸࠹࠽࠮࡮ࡲ࠷ࠫ࠱ࡶ࡬ࡢࡻࡢ࡭ࡹ࡫࡭ࠪࠌࠌࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨฬ่ࠤฬ๊วๅ฼สลࠬ࠲ࠧࠨࠫࠍࠍࠧࠨࠢ䖇")
	return result
	#if source==l11l1l_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ䖈"): l1111l_l1_ = l11l1l_l1_ (u"ࠧࡉࡎࡄࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䖉")
	#elif source==l11l1l_l1_ (u"ࠨ࠶ࡋࡉࡑࡇࡌࠨ䖊"): l1111l_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡍࡋࡌࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䖋")
	#elif source==l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ䖌"): l1111l_l1_ = l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡁࡌࡏࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䖍")
	#elif source==l11l1l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ䖎"): l1111l_l1_ = l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡕࡋ࠸ࠥ࠭䖏")
	#size = len(l1ll1l11ll_l1_)
	#for i in range(0,size):
	#	title = l111111ll11_l1_[i]
	#	l1llll1_l1_ = l1ll1l11ll_l1_[i]
	#	addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䖐"),l1111l_l1_+title,l1llll1_l1_,160,l11l1l_l1_ (u"ࠨࠩ䖑"),l11l1l_l1_ (u"ࠩࠪ䖒"),source)
def l1ll11111lll_l1_(url,source,type=l11l1l_l1_ (u"ࠪࠫ䖓")):
	url = url.strip(l11l1l_l1_ (u"ࠫࠥ࠭䖔")).strip(l11l1l_l1_ (u"ࠬࠬࠧ䖕")).strip(l11l1l_l1_ (u"࠭࠿ࠨ䖖")).strip(l11l1l_l1_ (u"ࠧ࠰ࠩ䖗"))
	l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1llllll_l1_(url,source)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䖘"),l11l1l_l1_ (u"ࠩࠪ䖙"),url,l111111llll_l1_)
	if l111111llll_l1_==l11l1l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䖚"): return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
	elif l1lll1_l1_:
		while True:
			if len(l1lll1_l1_)==1: l1l_l1_ = 0
			else: l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ䖛"), l1ll1ll1_l1_)
			if l1l_l1_==-1: result = l11l1l_l1_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ䖜")
			else:
				l1ll1l11l1ll_l1_ = l1lll1_l1_[l1l_l1_]
				title = l1ll1ll1_l1_[l1l_l1_]
				LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䖝"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸ࡫࡬ࡦࡥࡷࡩࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭䖞")+title+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ䖟")+str(l1ll1l11l1ll_l1_)+l11l1l_l1_ (u"ࠩࠣࡡࠬ䖠"))
				if l11l1l_l1_ (u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭䖡") in l1ll1l11l1ll_l1_ and l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫ䖢") in l1ll1l11l1ll_l1_:
					l1ll1ll1ll1l_l1_,l111lll1l11_l1_,l111lllll11_l1_ = l1llll11llll_l1_(l1ll1l11l1ll_l1_)
					if l111lllll11_l1_: l1ll1l11l1ll_l1_ = l111lllll11_l1_[0]
					else: l1ll1l11l1ll_l1_ = l11l1l_l1_ (u"ࠬ࠭䖣")
				if not l1ll1l11l1ll_l1_: result = l11l1l_l1_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ䖤")
				else: result = PLAY_VIDEO(l1ll1l11l1ll_l1_,source,type)
			if result in [l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ䖥"),l11l1l_l1_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ䖦")] or len(l1lll1_l1_)==1: break
			elif result in [l11l1l_l1_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ䖧"),l11l1l_l1_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ䖨"),l11l1l_l1_ (u"ࠫࡹࡸࡩࡦࡦࠪ䖩")]: break
			else: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䖪"),l11l1l_l1_ (u"࠭ࠧ䖫"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ䖬"),l11l1l_l1_ (u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧ䖭"))
	else:
		result = l11l1l_l1_ (u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭䖮")
		l111ll1111_l1_ = l11l1l11l1_l1_(url)
		if l111ll1111_l1_: result = PLAY_VIDEO(url,source,type)
	return result,l111111llll_l1_,l1lll1_l1_
	#title = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ䖯") )
	#if l11l1l_l1_ (u"ุࠫ๐ัโำࠣ฽ฬ๋ࠠๆฮ๊์้࠭䖰") in title:
	#	import l1l1l1ll1l1l_l1_
	#	l1l1l1ll1l1l_l1_.MAIN(156)
	#	return l11l1l_l1_ (u"ࠬ࠭䖱")
def l1l1l1l11ll1_l1_(url,source):
	# url = url+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䖲")+name+l11l1l_l1_ (u"ࠧࡠࡡࠪ䖳")+type+l11l1l_l1_ (u"ࠨࡡࡢࠫ䖴")+l11ll11_l1_+l11l1l_l1_ (u"ࠩࡢࡣࠬ䖵")+l111ll11_l1_
	# url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹࡅ࡮ࡢ࡯ࡨࡨࡂࡧ࡫ࡸࡣࡰࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳࡰ࠵ࡡࡢ࠻࠷࠶ࠧ䖶")
	l111l1l_l1_,l1llll1lll1l_l1_,server,l1ll1l1l1l1l_l1_,name,type,l11ll11_l1_,l111ll11_l1_ = url,l11l1l_l1_ (u"ࠫࠬ䖷"),l11l1l_l1_ (u"ࠬ࠭䖸"),l11l1l_l1_ (u"࠭ࠧ䖹"),l11l1l_l1_ (u"ࠧࠨ䖺"),l11l1l_l1_ (u"ࠨࠩ䖻"),l11l1l_l1_ (u"ࠩࠪ䖼"),l11l1l_l1_ (u"ࠪࠫ䖽")
	#source = source.lower()
	if l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ䖾") in url:
		l111l1l_l1_,l1llll1lll1l_l1_ = url.split(l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭䖿"),1)
		l1llll1lll1l_l1_ = l1llll1lll1l_l1_+l11l1l_l1_ (u"࠭࡟ࡠࠩ䗀")+l11l1l_l1_ (u"ࠧࡠࡡࠪ䗁")+l11l1l_l1_ (u"ࠨࡡࡢࠫ䗂")+l11l1l_l1_ (u"ࠩࡢࡣࠬ䗃")
		l1llll1lll1l_l1_ = l1llll1lll1l_l1_.lower()
		name,type,l11ll11_l1_,l111ll11_l1_,l1l1ll1l1ll1_l1_ = l1llll1lll1l_l1_.split(l11l1l_l1_ (u"ࠪࡣࡤ࠭䗄"))[:5]
	if l111ll11_l1_==l11l1l_l1_ (u"ࠫࠬ䗅"): l111ll11_l1_ = l11l1l_l1_ (u"ࠬ࠶ࠧ䗆")
	else: l111ll11_l1_ = l111ll11_l1_.replace(l11l1l_l1_ (u"࠭ࡰࠨ䗇"),l11l1l_l1_ (u"ࠧࠨ䗈")).replace(l11l1l_l1_ (u"ࠨࠢࠪ䗉"),l11l1l_l1_ (u"ࠩࠪ䗊"))
	l111l1l_l1_ = l111l1l_l1_.strip(l11l1l_l1_ (u"ࠪࡃࠬ䗋")).strip(l11l1l_l1_ (u"ࠫ࠴࠭䗌")).strip(l11l1l_l1_ (u"ࠬࠬࠧ䗍"))
	server = SERVER(l111l1l_l1_,l11l1l_l1_ (u"࠭ࡨࡰࡵࡷࠫ䗎"))
	if name: l1ll1l1l1l1l_l1_ = name
	#elif source: l1ll1l1l1l1l_l1_ = source
	else: l1ll1l1l1l1l_l1_ = server
	l1ll1l1l1l1l_l1_ = SERVER(l1ll1l1l1l1l_l1_,l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䗏"))
	name = name.replace(l11l1l_l1_ (u"ࠨ็หหูืࠧ䗐"),l11l1l_l1_ (u"ࠩࠪ䗑")).replace(l11l1l_l1_ (u"ࠪื๏ืแาࠩ䗒"),l11l1l_l1_ (u"ࠫࠬ䗓")).replace(l11l1l_l1_ (u"ࠬอไࠡࠩ䗔"),l11l1l_l1_ (u"࠭ࠠࠨ䗕")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ䗖"),l11l1l_l1_ (u"ࠨࠢࠪ䗗"))
	l1llll1lll1l_l1_ = l1llll1lll1l_l1_.replace(l11l1l_l1_ (u"่ࠩฬฬฺัࠨ䗘"),l11l1l_l1_ (u"ࠪࠫ䗙")).replace(l11l1l_l1_ (u"ุࠫ๐ัโำࠪ䗚"),l11l1l_l1_ (u"ࠬ࠭䗛")).replace(l11l1l_l1_ (u"࠭วๅࠢࠪ䗜"),l11l1l_l1_ (u"ࠧࠡࠩ䗝")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠫ䗞"),l11l1l_l1_ (u"ࠩࠣࠫ䗟"))
	l1ll1l1l1l1l_l1_ = l1ll1l1l1l1l_l1_.replace(l11l1l_l1_ (u"้ࠪออิาࠩ䗠"),l11l1l_l1_ (u"ࠫࠬ䗡")).replace(l11l1l_l1_ (u"ู๊ࠬาใิࠫ䗢"),l11l1l_l1_ (u"࠭ࠧ䗣")).replace(l11l1l_l1_ (u"ࠧศๆࠣࠫ䗤"),l11l1l_l1_ (u"ࠨࠢࠪ䗥")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ䗦"),l11l1l_l1_ (u"ࠪࠤࠬ䗧"))
	return l111l1l_l1_,l1llll1lll1l_l1_,server,l1ll1l1l1l1l_l1_,name,type,l11ll11_l1_,l111ll11_l1_
def l1111111l1l_l1_(url,source):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䗨"),l11l1l_l1_ (u"ࠬ࠭䗩"),url,l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡇࡂࡍࡇࠪ䗪"))
	# l1lll111l_l1_	: سيرفر خاص
	# l1lllll1ll1l_l1_		: سيرفر محدد
	# l1llll1ll1ll_l1_		: سيرفر عام معروف
	# l1ll11lll_l1_	: سيرفر عام خارجي
	# l1l1ll1l1l1l_l1_	: سيرفر عام خارجي
	l1ll1l11111l_l1_,name,l1lll111l_l1_,l1llll1ll1ll_l1_,l1ll11lll_l1_,l1lllll1ll1l_l1_,l1l1ll1l1l1l_l1_ = l11l1l_l1_ (u"ࠧࠨ䗫"),l11l1l_l1_ (u"ࠨࠩ䗬"),None,None,None,None,None
	l111l1l_l1_,l1llll1lll1l_l1_,server,l1ll1l1l1l1l_l1_,name,type,l11ll11_l1_,l111ll11_l1_ = l1l1l1l11ll1_l1_(url,source)
	if l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䗭") in url:
		if   type==l11l1l_l1_ (u"ࠪࡩࡲࡨࡥࡥࠩ䗮"): type = l11l1l_l1_ (u"ࠫࠥ࠭䗯")+l11l1l_l1_ (u"๋ࠬแืๆࠪ䗰")
		elif type==l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ䗱"): type = l11l1l_l1_ (u"ࠧࠡࠩ䗲")+l11l1l_l1_ (u"ࠨุ่ࠧฬํฯสࠩ䗳")
		elif type==l11l1l_l1_ (u"ࠩࡥࡳࡹ࡮ࠧ䗴"): type = l11l1l_l1_ (u"ࠪࠤࠬ䗵")+l11l1l_l1_ (u"ࠫࠪࠫๅีษ๊ำฮ่ࠦหฯ่๎้࠭䗶")
		elif type==l11l1l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ䗷"): type = l11l1l_l1_ (u"࠭ࠠࠨ䗸")+l11l1l_l1_ (u"ࠧࠦࠧࠨฮา๋๊ๅࠩ䗹")
		elif type==l11l1l_l1_ (u"ࠨࠩ䗺"): type = l11l1l_l1_ (u"ࠩࠣࠫ䗻")+l11l1l_l1_ (u"ࠪࠩࠪࠫࠥࠨ䗼")
		if l11ll11_l1_!=l11l1l_l1_ (u"ࠫࠬ䗽"):
			if l11l1l_l1_ (u"ࠬࡳࡰ࠵ࠩ䗾") not in l11ll11_l1_: l11ll11_l1_ = l11l1l_l1_ (u"࠭ࠥࠨ䗿")+l11ll11_l1_
			l11ll11_l1_ = l11l1l_l1_ (u"ࠧࠡࠩ䘀")+l11ll11_l1_
		if l111ll11_l1_!=l11l1l_l1_ (u"ࠨࠩ䘁"):
			l111ll11_l1_ = l11l1l_l1_ (u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬ䘂")+l111ll11_l1_
			l111ll11_l1_ = l11l1l_l1_ (u"ࠪࠤࠬ䘃")+l111ll11_l1_[-9:]
	#if any(value in server for value in l1ll1llll11l_l1_): return l11l1l_l1_ (u"ࠫࠬ䘄")
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䘅"),l11l1l_l1_ (u"࠭ࠧ䘆"),name,l1ll1l1l1l1l_l1_)
	if   l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭䘇")		in source: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠨࡃࡎ࡛ࡆࡓࠧ䘈")		in source: l1lll111l_l1_	= l11l1l_l1_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ䘉")
	elif l11l1l_l1_ (u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬ䘊")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭䘋")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫ䘌")	in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"࠭ࡳࡦࡧࡨࡩࡩ࠭䘍")		in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩ䘎")
	#elif l11l1l_l1_ (u"ࠨࡴࡨࡺ࡮࡫ࡷࡴࡶࡤࡸ࡮ࡵ࡮ࠨ䘏") in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠩࡤࡰࡦࡸࡡࡣࠩ䘐")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ䘑")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	#elif l11l1l_l1_ (u"ࠫࡵࡩࡲࡦࡸ࡬ࡩࡼ࠭䘒")	in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭䘓")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭䘔")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ䘕")		in name:   l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ䘖")		in name:   l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠩࡩࡥ࡯࡫ࡲࠨ䘗")		in name:   l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮ࡥ࡯ࡹࡧ࠭䘘")	in name:   l1lll111l_l1_	= l11l1l_l1_ (u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡵ࠭䘙")
	elif l11l1l_l1_ (u"ࠬ็ฬาࠩ䘚")			in name:   l1lll111l_l1_	= l11l1l_l1_ (u"࠭ࡦࡢ࡬ࡨࡶࠬ䘛")
	elif l11l1l_l1_ (u"ࠧโๆึ฻๏์ࠧ䘜")		in name:   l1lll111l_l1_	= l11l1l_l1_ (u"ࠨࡲࡤࡰࡪࡹࡴࡪࡰࡨࠫ䘝")
	elif l11l1l_l1_ (u"ࠩࡪࡨࡷ࡯ࡶࡦࠩ䘞")		in l111l1l_l1_:   l1lll111l_l1_	= l11l1l_l1_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪ䘟")
	elif l11l1l_l1_ (u"ࠫࡲࡿࡣࡪ࡯ࡤࠫ䘠")		in name:   l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ䘡")		in name:   l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䘢")		in name:   l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲࠬ䘣")	in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠨࡤࡲ࡯ࡷࡧࠧ䘤")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠩࡷࡺ࡫ࡻ࡮ࠨ䘥")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠪࡸࡻࡱࡳࡢࠩ䘦")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠫࡦࡴࡡࡷ࡫ࡧࡾࠬ䘧")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ䘨")		in server: l1lll111l_l1_	= l1ll1l1l1l1l_l1_
	#elif l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽ࠮࡯ࡧࡷࠫ䘩")	in l111l1l_l1_:   l1lll111l_l1_	= l11l1l_l1_ (u"ࠧࠡࠩ䘪")
	elif l11l1l_l1_ (u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ䘫")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ䘬")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ䘭")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ䘮")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ䘯")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ䘰")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭䘱")	 	in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩ䘲")
	elif l11l1l_l1_ (u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ䘳")	 	in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ䘴")
	elif l11l1l_l1_ (u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩ䘵")	in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩ䘶")
	elif l11l1l_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࠧ䘷")		in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ䘸")
	elif l11l1l_l1_ (u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣࠪ䘹")		in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ䘺")
	elif l11l1l_l1_ (u"ࠪࡪࡦࡩࡵ࡭ࡶࡼࡦࡴࡵ࡫ࡴࠩ䘻")	in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ䘼")
	elif l11l1l_l1_ (u"ࠬ࡯࡮ࡧ࡮ࡤࡱ࠳ࡩࡣࠨ䘽")	in server: l1lll111l_l1_	= l11l1l_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠭䘾")
	elif l11l1l_l1_ (u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ䘿")		in server: l1lll111l_l1_	= l11l1l_l1_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ䙀")
	elif l11l1l_l1_ (u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬ䙁")	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭䙂")
	elif l11l1l_l1_ (u"ࠫࡦࡸࡣࡩ࡫ࡹࡩࠬ䙃")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭䙄")
	elif l11l1l_l1_ (u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨ䙅")	 	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠭䙆")
	elif l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ䙇")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ䙈")
	elif l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡢ࡮ࠩ䙉")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ䙊")
	elif l11l1l_l1_ (u"ࠬࡼࡩࡥࡪࡧࠫ䙋")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"࠭࡭ࡺࡸ࡬ࡨࠬ䙌")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠧ࡮ࡻࡹ࡭࡮ࡪࠧ䙍")		in server: l1lllll1ll1l_l1_	= l1ll1l1l1l1l_l1_
	elif l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ䙎")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ䙏")
	elif l11l1l_l1_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ䙐")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ䙑")
	elif l11l1l_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䙒") 	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ䙓")
	elif l11l1l_l1_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ䙔")	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ䙕")
	elif l11l1l_l1_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ䙖")	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨ䙗")
	elif l11l1l_l1_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ䙘") 	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ䙙")
	elif l11l1l_l1_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ䙚")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ䙛")
	elif l11l1l_l1_ (u"ࠨࡷࡳࡴࠬ䙜") 			in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ䙝")
	elif l11l1l_l1_ (u"ࠪࡹࡵࡨࠧ䙞") 			in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠫࡺࡶࡢࡰ࡯ࠪ䙟")
	elif l11l1l_l1_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ䙠") 		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭䙡")
	elif l11l1l_l1_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ䙢") 	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ䙣")
	elif l11l1l_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ䙤")		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ䙥")
	elif l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ䙦") 		in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ䙧")
	elif l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ䙨") 	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ䙩")
	elif l11l1l_l1_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ䙪")	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭䙫")
	elif l11l1l_l1_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ䙬")	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ䙭")
	#elif l11l1l_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭䙮") 	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ䙯")
	#elif l11l1l_l1_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ䙰")	in server: l1llll1ll1ll_l1_	= l11l1l_l1_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ䙱")
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠉࠤࡎࡒࡋࡤ࡚ࡈࡊࡕࠫࠫࡓࡕࡔࡊࡅࡈࠫ࠱ࡻࡲ࡭࠭ࠪࡁࡂࡃࠧࠬࡷࡵࡰ࠷࠯ࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠊࠊࠋࠌࡶࡪࡹ࡯࡭ࡸࡨࡶࠥࡃࠠࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯࠲ࡍࡵࡳࡵࡧࡧࡑࡪࡪࡩࡢࡈ࡬ࡰࡪ࠮ࡵࡳ࡮࠵࠭࠳ࡼࡡ࡭࡫ࡧࡣࡺࡸ࡬ࠩࠫࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࡲ࠻ࠌࠌࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࠫ࠶࠷࠱࠲ࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨࠫࠍࠍࠎࠏࡲࡦࡵࡲࡰࡻ࡫ࡲࠡ࠿ࠣࡊࡦࡲࡳࡦࠌࠌࠍࠎࠩࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡻࡲࡹࡹࡻࡢࡦ࠯ࡧࡰ࠳ࡵࡲࡨࠌࠌࠍࠎࡲࡩࡴࡶࡢࡹࡷࡲࠠ࠾ࠢࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡺࡤ࡭࠯ࡲࡶ࡬࠴ࡧࡪࡶ࡫ࡹࡧ࠴ࡩࡰ࠱ࡼࡳࡺࡺࡵࡣࡧ࠰ࡨࡱ࠵ࡳࡶࡲࡳࡳࡷࡺࡥࡥࡵ࡬ࡸࡪࡹ࠮ࡩࡶࡰࡰࠬࠐࠉࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬ࡭࡫ࡶࡸࡤࡻࡲ࡭࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡈࡗࡔࡒࡖࡂࡄࡏࡉ࠲࠷ࡳࡵࠩࠬࠎࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡂࡵ࡭ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎ࡯ࡦࠡࡪࡷࡱࡱࡀࠊࠊࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤ࡭ࡺ࡭࡭࡝࠳ࡡ࠳ࡲ࡯ࡸࡧࡵࠬ࠮ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀࡱ࡯࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾ࡥࡂࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠽࠱࡯࡭ࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࠰ࡤࡁࠫ࠱࠭ࠧࠪࠌࠌࠍࠎࠏࠣࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡒࡔ࡚ࡉࡄࡇࠪ࠰ࠬ࠸࠲࠳࠴ࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩࠬࠎࠎࠏࠉࠊࡲࡤࡶࡹࡹࠠ࠾ࠢࡶࡩࡷࡼࡥࡳ࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠱ࠫ࠮ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡱࡣࡵࡸࠥ࡯࡮ࠡࡲࡤࡶࡹࡹ࠺ࠋࠋࠌࠍࠎࠏࡩࡧࠢ࡯ࡩࡳ࠮ࡰࡢࡴࡷ࠭ࡁ࠺࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠍࠍࠎࠏࠉࠊࡧ࡯࡭࡫ࠦࡰࡢࡴࡷࠤ࡮ࡴࠠࡩࡶࡰࡰ࠿ࠐࠉࠊࠋࠌࠍࠎࡸࡥࡴࡱ࡯ࡺࡪࡸࠠ࠾ࠢࡗࡶࡺ࡫ࠊࠊࠋࠌࠍࠎࠏࡢࡳࡧࡤ࡯ࠏࠏࠢࠣࠤ䙲")
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䙳"),l11l1l_l1_ (u"ࠫࠬ䙴"),url,l111l1l_l1_)
	if   l1lll111l_l1_:	l1ll1l11111l_l1_,name = l11l1l_l1_ (u"ࠬิวึࠩ䙵"),l1lll111l_l1_
	elif l1lllll1ll1l_l1_:		l1ll1l11111l_l1_,name = l11l1l_l1_ (u"࠭ࠥๆฯาำࠬ䙶"),l1lllll1ll1l_l1_
	elif l1llll1ll1ll_l1_:		l1ll1l11111l_l1_,name = l11l1l_l1_ (u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬ䙷"),l1llll1ll1ll_l1_
	elif l1ll11lll_l1_:	l1ll1l11111l_l1_,name = l11l1l_l1_ (u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧ䙸"),l1ll11lll_l1_
	elif l1l1ll1l1l1l_l1_:	l1ll1l11111l_l1_,name = l11l1l_l1_ (u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ䙹"),l1ll1l1l1l1l_l1_
	else:			l1ll1l11111l_l1_,name = l11l1l_l1_ (u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫ䙺"),l1ll1l1l1l1l_l1_
	return l1ll1l11111l_l1_,name,type,l11ll11_l1_,l111ll11_l1_
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡱ࡮ࡤࡽࡷ࠴࠴ࡩࡧ࡯ࡥࡱ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡶࡲࡪࡸࡤࡸࡪࠦ࠽ࠡࠩ࡫ࡩࡱࡧ࡬ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡨࡷࡹࡸࡥࡢ࡯ࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡩ࡯ࡶࡲࡹࡵࡲ࡯ࡢࡦࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠍࠍࡪࡲࡩࡧࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺࡪࡼ࠮ࡪࡱࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡦࡸࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠠࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦࡶ࡬ࡦࡸࡥࠨࠌࠌࠦࠧࠨ䙻")
def l1ll111l1l1l_l1_(url,source):
	l111l1l_l1_,l1llll1lll1l_l1_,server,l1ll1l1l1l1l_l1_,name,type,l11ll11_l1_,l111ll11_l1_ = l1l1l1l11ll1_l1_(url,source)
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䙼"),l11l1l_l1_ (u"࠭ࠧ䙽"),l1lllll1ll1l_l1_,server)
	#if l11l1l_l1_ (u"ࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬ䙾")	in server: l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ䙿"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䚀"))
	#if any(value in server for value in l1ll1llll11l_l1_): l1ll1ll1_l1_,l1lll1_l1_ = [l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡊ࡙ࡏࡍࡘࡈࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡲࡦࡵࡲࡰࡻ࡫ࠠࡵࡪ࡬ࡷࠥࡹࡥࡳࡸࡨࡶࠬ䚁")],[]
	if   l11l1l_l1_ (u"ࠫࡆࡑࡏࡂࡏࠪ䚂")		in source: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11ll1l_l1_(l111l1l_l1_,name)
	elif l11l1l_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ䚃")		in source: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll1ll_l1_(l111l1l_l1_,type,l111ll11_l1_)
	elif l11l1l_l1_ (u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ䚄")		in source: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11llll1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ䚅")		in source: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1llll1ll1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪ䚆")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l11l1ll_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬ䚇")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l111ll_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠪࡥࡱࡧࡲࡢࡤࠪ䚈")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1llllllll11_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭䚉")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll1lll11_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧ䚊")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll1lll11_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤ࠱ࡨࡲࡵࡣࠩ䚋")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1lll11_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠧࡦࡩࡼࡲࡴࡽࠧ䚌")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll1l11l1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠨࡶࡹࡪࡺࡴࠧ䚍")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1ll11ll1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠩࡷࡺࡰࡹࡡࠨ䚎")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1ll11ll1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬ䚏")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll1ll11_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭䚐")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1lllll_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧ䚑")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll11111l_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ䚒")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll11l11l_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠧࡷࡵ࠷ࡹࠬ䚓")			in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l111lll11l1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ䚔")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1l11111_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䚕")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11llll_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧ䚖")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1l1111_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧ䚗")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1l1111_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ䚘")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l111lll1111_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭䚙")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1lll111l1_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠧࡣࡱ࡮ࡶࡦ࠭䚚")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11111111_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭䚛")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11ll1l1ll_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫ䚜")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1111l_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠪࡷࡪ࡫ࡥࡦࡦࠪ䚝")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1111l_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࡸࡪࡩࡨࠨ䚞")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1111l_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ䚟")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l111l1l11_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"࠭ࡤ࠯ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡧࠫ䚠")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠧࠨ䚡"),[l11l1l_l1_ (u"ࠨࠩ䚢")],[l111l1l_l1_]
	elif l11l1l_l1_ (u"ࠩࡨ࡫ࡾࡨࡥࡴࡶࠪ䚣")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11111111l_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩࠩ䚤")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll1ll1l1l_l1_(l111l1l_l1_)
	elif l11l1l_l1_ (u"ࠫࡺࡶࡢࡢ࡯ࠪ䚥") 		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠬ࠭䚦"),[l11l1l_l1_ (u"࠭ࠧ䚧")],[l111l1l_l1_]
	else: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䚨"),[l11l1l_l1_ (u"ࠨࠩ䚩")],[l111l1l_l1_]
	return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
def l1llll1ll11l_l1_(url,source):
	server = SERVER(url,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䚪"))
	#if l11l1l_l1_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ䚫")	in server: l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ䚬"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ䚭"))
	#if any(value in server for value in l1ll1llll11l_l1_): l1ll1ll1_l1_,l1lll1_l1_ = [l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡆࡕࡒࡐ࡛ࡋࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࠣࡸ࡭࡯ࡳࠡࡵࡨࡶࡻ࡫ࡲࠨ䚮")],[]
	l1ll111l1l11_l1_ = False
	if   l11l1l_l1_ (u"ࠧࡺࡱࡸࡸࡺ࠭䚯")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1111111lll_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ䚰")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1111111lll_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠭䚱") in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1l1ll11l_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࠩ䚲")	in url: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1llll1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭䚳")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1111l_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ䚴")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11ll1l1ll_l1_(url)
	elif l11l1l_l1_ (u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ䚵")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1llll11llll_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨ䚶")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11llll1_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ䚷")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11l1l1l1_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ䚸")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l111l1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ䚹")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11llll1l_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡪ࠻ࡴࡴࡣࡵࠫ䚺")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll1ll1lll_l1_(url)
	elif l11l1l_l1_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ䚻")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll1lll1l1_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ䚼")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll1lll1l1_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ䚽")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡪࡸࡩࡰࠩ䚾")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡹ࡭ࡩࡨ࡭ࠨ䚿")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡨࡥࠩ䛀")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭䛁")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡲࡩࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ䛂")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡶࡪࡦࡲࡦࡦ࠭䛃")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l111l1_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡷࡵ࡫ࡥࡥࠩ䛄")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l111l1_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡷࡳࡦࡦࡳࠧ䛅") 		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠩࠪ䛆"),[l11l1l_l1_ (u"ࠪࠫ䛇")],[url]
	#elif l11l1l_l1_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ䛈")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l111l1l1_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ䛉") 	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1lll1ll1_l1_(url)
	elif l11l1l_l1_ (u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ䛊")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll11ll11l_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳ࡭ࡵࠧ䛋")in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1l1l1111_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡴࡤࡴ࡮ࡪࡶࡪࡦࡨࡳࠬ䛌") 	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1llll111lll_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ䛍")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll111llll1_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡹࡵࡨࠧ䛎") 			in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1111111_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡺࡶࡰࠨ䛏") 			in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1111111_l1_(url)
	#elif l11l1l_l1_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭䛐") 	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11lll111_l1_(url)
	#elif l11l1l_l1_ (u"࠭ࡵࡱࡶࡲࡷࡹࡸࡥࡢ࡯ࠪ䛑")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11lll111_l1_(url)
	elif l11l1l_l1_ (u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ䛒") 		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1lll1l11l_l1_(url)
	elif l11l1l_l1_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ䛓") 	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1lll1111_l1_(url)
	elif l11l1l_l1_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ䛔")		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll111lll1l_l1_(url)
	elif l11l1l_l1_ (u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ䛕") 		in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll1111111l_l1_(url)
	elif l11l1l_l1_ (u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ䛖") 	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1lll111llll_l1_(url)
	elif l11l1l_l1_ (u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩ䛗")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1lll1ll11_l1_(url)
	elif l11l1l_l1_ (u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪ䛘")	in server: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll11llll11_l1_(url)
	else: l1ll111l1l11_l1_ = True
	if l1ll111l1l11_l1_ or l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠩ䛙") in l111111llll_l1_:
		l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠠࡇࡣ࡬ࡰࡪࡪࠧ䛚"),[],[]
	return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࡥ࡭࡫ࡩࠤࠬ࡫ࡳࡵࡴࡨࡥࡲ࠭ࠉࠡࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇࡖࡘࡗࡋࡁࡎࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡍࡏࡖࡐࡏࡍࡒࡏࡔࡆࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨ࡫ࡱࡸࡴࡻࡰ࡭ࡱࡤࡨࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡉࡏࡖࡒ࡙ࡕࡒࡏࡂࡆࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡶ࡫ࡩࡻ࡯ࡤࡦࡱࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡙ࡎࡅࡗࡋࡇࡉࡔ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡫ࡶ࠯࡫ࡲࠫࠎࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡆࡘࡌࡓ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡴࡱࡧࡹࡳ࠰࠷࡬ࡪࡲࡡ࡭ࠩࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡋࡉࡑࡇࡌࠩࡷࡵࡰ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠉࠊ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵ࠾ࠥ࡫ࡲࡳࡱࡵࡱࡸ࡭ࠬࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡗࡋࡇࡆࡔࡓࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡼࡩࡥࡪࡧࠫࠥࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡋࡈ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡳࡩࡣࡵࡩࠬࠦࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡖࡊࡆࡖࡌࡆࡘࡅࠩࡷࡵࡰ࠮ࠐࠉࠣࠤࠥ䛛")
def	l1ll1ll1l111_l1_(l11l1111l1l_l1_):
	if l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ䛜") in str(type(l11l1111l1l_l1_)):
		l1l1_l1_ = []
		for l1llll1_l1_ in l11l1111l1l_l1_:
			if l11l1l_l1_ (u"ࠫࡸࡺࡲࠨ䛝") in str(type(l1llll1_l1_)):
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࡢࡲࠨ䛞"),l11l1l_l1_ (u"࠭ࠧ䛟")).replace(l11l1l_l1_ (u"ࠧ࡝ࡰࠪ䛠"),l11l1l_l1_ (u"ࠨࠩ䛡")).strip(l11l1l_l1_ (u"ࠩࠣࠫ䛢"))
			l1l1_l1_.append(l1llll1_l1_)
	else: l1l1_l1_ = l11l1111l1l_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡷ࠭䛣"),l11l1l_l1_ (u"ࠫࠬ䛤")).replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ䛥"),l11l1l_l1_ (u"࠭ࠧ䛦")).strip(l11l1l_l1_ (u"ࠧࠡࠩ䛧"))
	return l1l1_l1_
def l1l1l1llllll_l1_(url,source):
	LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䛨"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ䛩")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭䛪"))
	l1l1ll1l1l1l_l1_,l1llll1_l1_,l1ll1ll1l11l_l1_ = l11l1l_l1_ (u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨ䛫"),l11l1l_l1_ (u"ࠬ࠭䛬"),l11l1l_l1_ (u"࠭ࠧ䛭")
	l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1ll111l1l1l_l1_(url,source)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䛮"),l11l1l_l1_ (u"ࠨࠩ䛯"),l11l1l_l1_ (u"ࠩࠪ䛰"),l111111llll_l1_)
	l1lll1_l1_ = l1ll1ll1l111_l1_(l1lll1_l1_)
	if l111111llll_l1_==l11l1l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䛱"): return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
	elif l1lll1_l1_: l1llll1_l1_ = l1lll1_l1_[0]
	if l111111llll_l1_==l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䛲"):
		#l111111llll_l1_ = l111111llll_l1_.replace(l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䛳"),l11l1l_l1_ (u"࠭ࠧ䛴"))
		l1l1ll1l1l1l_l1_ = l11l1l_l1_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠶࠭䛵")
		l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1llll1ll11l_l1_(l1llll1_l1_,source)
		l1lll1_l1_ = l1ll1ll1l111_l1_(l1lll1_l1_)
		if l111111llll_l1_==l11l1l_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䛶"): return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
		elif l11l1l_l1_ (u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠱ࠨ䛷") in l111111llll_l1_:
			l1ll1ll1l11l_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠫ䛸")+l111111llll_l1_
			l1l1ll1l1l1l_l1_ = l11l1l_l1_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ䛹")
			l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1llll1ll111_l1_(l1llll1_l1_,source)
			l1lll1_l1_ = l1ll1ll1l111_l1_(l1lll1_l1_)
			if l111111llll_l1_==l11l1l_l1_ (u"ࠬࡋࡘࡊࡖࠪ䛺"): return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
			elif l11l1l_l1_ (u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠶ࠬ䛻") in l111111llll_l1_:
				l1ll1ll1l11l_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠠࠨ䛼")+l111111llll_l1_
				l1l1ll1l1l1l_l1_ = l11l1l_l1_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠹ࠧ䛽")
				l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l111111lll1_l1_(l1llll1_l1_,source)
				l1lll1_l1_ = l1ll1ll1l111_l1_(l1lll1_l1_)
				if l111111llll_l1_==l11l1l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䛾"): return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
				elif l11l1l_l1_ (u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩ䛿") in l111111llll_l1_:
					l1ll1ll1l11l_l1_ += l11l1l_l1_ (u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵࠽ࠤࠬ䜀")+l111111llll_l1_
	elif l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠧ䜁") in l111111llll_l1_: l1ll1ll1l11l_l1_ = l11l1l_l1_ (u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠲࠽ࠤࠬ䜂")+l111111llll_l1_
	if l1lll1_l1_: LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ䜃"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࠤࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࠺ࠡ࡝ࠣࠫ䜄")+l1l1ll1l1l1l_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭䜅")+url+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ䜆")+l1llll1_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡸࡻ࡬ࡵࡵ࠽ࠤࡠࠦࠧ䜇")+str(l1lll1_l1_)+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ䜈"))
	else: LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ䜉"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ䜊")+url+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡌࡪࡰ࡮࠾ࠥࡡࠠࠨ䜋")+l1llll1_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡆࡴࡵࡳࡷࡹ࠺ࠡ࡝ࠣࠫ䜌")+l1ll1ll1l11l_l1_+l11l1l_l1_ (u"ࠪࠤࡢ࠭䜍"))
	l1ll1ll1l11l_l1_ = l1llll_l1_(l1ll1ll1l11l_l1_)
	return l1ll1ll1l11l_l1_,l1ll1ll1_l1_,l1lll1_l1_
def l1l1lll1l1l1_l1_(l111lllll11_l1_,source):
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ䜎"),l111lllll11_l1_)
	l1l1l1llll11_l1_ = l1llll11_l1_
	data = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ䜏"),l11l1l_l1_ (u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧ䜐"),l111lllll11_l1_)
	if data:
		l1ll1ll1_l1_,l1lll1_l1_ = list(zip(*data))
		return l1ll1ll1_l1_,l1lll1_l1_
	l1ll1ll1_l1_,l1lll1_l1_,l111111ll11_l1_ = [],[],[]
	for l1llll1_l1_ in l111lllll11_l1_:
		if l11l1l_l1_ (u"ࠧ࠰࠱ࠪ䜑") not in l1llll1_l1_: continue
		l1ll1l11111l_l1_,name,type,l11ll11_l1_,l111ll11_l1_ = l1111111l1l_l1_(l1llll1_l1_,source)
		l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡞ࡧ࠯ࠬ䜒"),l111ll11_l1_,re.DOTALL)
		if l111ll11_l1_: l111ll11_l1_ = int(l111ll11_l1_[0])
		else: l111ll11_l1_ = 0
		#if l111ll11_l1_:
		#	l1llll11ll1l_l1_ = sorted(l111ll11_l1_,reverse=True,key=lambda key: int(key))
		#	l111ll11_l1_ = int(l1llll11ll1l_l1_[0])
		#else: l111ll11_l1_ = 0
		server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ䜓"))
		l111111ll11_l1_.append([l1ll1l11111l_l1_,name,type,l11ll11_l1_,l111ll11_l1_,l1llll1_l1_,server])
	if l111111ll11_l1_:
		#l1ll1l11111l_l1_,name,type,l11ll11_l1_,l111ll11_l1_,l1llll1_l1_ = zip(*l111111ll11_l1_)
		#name = reversed(name)
		#l111111ll11_l1_ = zip(l1ll1l11111l_l1_,name,type,l11ll11_l1_,l111ll11_l1_,l1llll1_l1_)
		l1ll1ll1l1l1_l1_ = sorted(l111111ll11_l1_,reverse=True,key=lambda key: (key[4],key[0],key[3],key[2],key[1],key[5],key[6]))
		l1ll1ll1111l_l1_ = []
		for line in l1ll1ll1l1l1_l1_:
			if line not in l1ll1ll1111l_l1_:
				l1ll1ll1111l_l1_.append(line)
				#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ䜔"),str(line))
		for l1ll1l11111l_l1_,name,type,l11ll11_l1_,l111ll11_l1_,l1llll1_l1_,server in l1ll1ll1111l_l1_:
			if l111ll11_l1_: l111ll11_l1_ = str(l111ll11_l1_)
			else: l111ll11_l1_ = l11l1l_l1_ (u"ࠫࠬ䜕")
			#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䜖"),l11l1l_l1_ (u"࠭ࠧ䜗"),name,l1llll1_l1_)
			title = l11l1l_l1_ (u"ࠧิ์ิๅึ࠭䜘")+l11l1l_l1_ (u"ࠨࠢࠪ䜙")+type+l11l1l_l1_ (u"ࠩࠣࠫ䜚")+l1ll1l11111l_l1_+l11l1l_l1_ (u"ࠪࠤࠬ䜛")+l111ll11_l1_+l11l1l_l1_ (u"ࠫࠥ࠭䜜")+l11ll11_l1_+l11l1l_l1_ (u"ࠬࠦࠧ䜝")+name
			if server not in title: title = title+l11l1l_l1_ (u"࠭ࠠࠨ䜞")+server
			title = title.replace(l11l1l_l1_ (u"ࠧࠦࠩ䜟"),l11l1l_l1_ (u"ࠨࠩ䜠")).strip(l11l1l_l1_ (u"ࠩࠣࠫ䜡")).replace(l11l1l_l1_ (u"ࠪࠤࠥ࠭䜢"),l11l1l_l1_ (u"ࠫࠥ࠭䜣")).replace(l11l1l_l1_ (u"ࠬࠦࠠࠨ䜤"),l11l1l_l1_ (u"࠭ࠠࠨ䜥")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ䜦"),l11l1l_l1_ (u"ࠨࠢࠪ䜧"))
			if l1llll1_l1_ not in l1lll1_l1_:
				l1ll1ll1_l1_.append(title)
				l1lll1_l1_.append(l1llll1_l1_)
		if l1lll1_l1_:
			#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ䜨"),l1lll1_l1_)
			data = list(zip(l1ll1ll1_l1_,l1lll1_l1_))
			if data: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ䜩"),l111lllll11_l1_,data,l1l1l1llll11_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ䜪"),l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠽࠶࠿ࠦࠠࠡࠩ䜫")+str(data))
	return l1ll1ll1_l1_,l1lll1_l1_
def	l1llll1ll111_l1_(url,source):
	#url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡅࡥ࡜ࡥࡪࡦࡰࡲࡾࡐࡩࠧ䜬")
	l1ll1lllll1l_l1_ = l11l1l_l1_ (u"ࠧࠨ䜭")
	results = False
	try:
		import resolveurl
		#if resolveurl.HostedMediaFile(url).l1lllll1lll1_l1_():
		#results = resolveurl.HostedMediaFile(url).resolve()
		results = resolveurl.resolve(url)
	except Exception as error: l1ll1lllll1l_l1_ = str(error)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䜮"),l11l1l_l1_ (u"ࠩࠪ䜯"),l11l1l_l1_ (u"ࠪࠫ䜰"),str(results))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䜱"),l11l1l_l1_ (u"ࠬ࠭䜲"),l11l1l_l1_ (u"࠭ࠧ䜳"),str(l1ll1lllll1l_l1_))
	# resolveurl l11111l1ll_l1_ l1lll111lll_l1_ l1ll1l11l1l1_l1_ with l1l1l11ll11l_l1_ error or l1ll1ll1llll_l1_ value False
	if not results:
		if l1ll1lllll1l_l1_==l11l1l_l1_ (u"ࠧࠨ䜴"):
			l1ll1lllll1l_l1_ = traceback.format_exc()
			sys.stderr.write(l1ll1lllll1l_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䜵"),l11l1l_l1_ (u"ࠩࠪ䜶"),l11l1l_l1_ (u"ࠪࠫ䜷"),str(l1ll1lllll1l_l1_))
		l111111llll_l1_ = l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠣࡊࡦ࡯࡬ࡦࡦࠪ䜸")
		l111111llll_l1_ += l11l1l_l1_ (u"ࠬࠦࠧ䜹")+l1ll1lllll1l_l1_.splitlines()[-1]
		return l111111llll_l1_,[],[]
	return l11l1l_l1_ (u"࠭ࠧ䜺"),[l11l1l_l1_ (u"ࠧࠨ䜻")],[results]
def	l111111lll1_l1_(url,source):
	#url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡇࡧࡗࡠ࡬ࡨࡲࡴࢀࡋࡤࠩ䜼")
	#url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮࠱ࡹ࡭ࡩ࡫࡯࠰ࡺ࠺ࡽࡾ࠺࠱ࡴࠩ䜽")
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䜾"),l11l1l_l1_ (u"ࠫࠬ䜿"),url,l11l1l_l1_ (u"ࠬ࠭䝀"))
	#return l11l1l_l1_ (u"࠭ࠧ䝁"),[],[]
	l1ll1lllll1l_l1_ = l11l1l_l1_ (u"ࠧࠨ䝂")
	results = False
	try:
		import youtube_dl
		l1lllllllll1_l1_ = youtube_dl.YoutubeDL({l11l1l_l1_ (u"ࠨࡰࡲࡣࡨࡵ࡬ࡰࡴࠪ䝃"): True})
		results = l1lllllllll1_l1_.extract_info(url,download=False)
	except Exception as error: l1ll1lllll1l_l1_ = str(error)
	# youtube_dl l11111l1ll_l1_ l1lll111lll_l1_ l1ll1l11l1l1_l1_ with l1l1l11ll11l_l1_ error or l1ll1ll1llll_l1_ value False
	if not results or l11l1l_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ䝄") not in list(results.keys()):
		if l1ll1lllll1l_l1_==l11l1l_l1_ (u"ࠪࠫ䝅"):
			l1ll1lllll1l_l1_ = traceback.format_exc()
			sys.stderr.write(l1ll1lllll1l_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䝆"),l11l1l_l1_ (u"ࠬ࠭䝇"),l11l1l_l1_ (u"࠭ࠧ䝈"),l1ll1lllll1l_l1_)
		l111111llll_l1_ = l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸ࠦࡆࡢ࡫࡯ࡩࡩ࠭䝉")
		l111111llll_l1_ += l11l1l_l1_ (u"ࠨࠢࠪ䝊")+l1ll1lllll1l_l1_.splitlines()[-1]
		return l111111llll_l1_,[],[]
	else:
		l1ll1ll1_l1_,l1lll1_l1_ = [],[]
		for l1llll1_l1_ in results[l11l1l_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ䝋")]:
			l1ll1ll1_l1_.append(l1llll1_l1_[l11l1l_l1_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࠪ䝌")])
			l1lll1_l1_.append(l1llll1_l1_[l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䝍")])
		return l11l1l_l1_ (u"ࠬ࠭䝎"),l1ll1ll1_l1_,l1lll1_l1_
def l1llllllll11_l1_(url):
	if l11l1l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ䝏") in url:
		l1ll1ll1_l1_,l1lll1_l1_ = l11l1ll1ll_l1_(url)
		if l1lll1_l1_: return l11l1l_l1_ (u"ࠧࠨ䝐"),l1ll1ll1_l1_,l1lll1_l1_
		return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡑࡇࡒࡂࡄࠪ䝑"),[],[]
	return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䝒"),[l11l1l_l1_ (u"ࠪࠫ䝓")],[url]
def l1l1l11l1ll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䝔"),l11l1l_l1_ (u"ࠬ࠭䝕"),l11l1l_l1_ (u"࠭ࠧ䝖"),url)
	l1lll11l_l1_,l1ll1l11l111_l1_ = [],[]
	if l11l1l_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪ䝗") in url:
		# l1lll11l1l1l_l1_:
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/مشاهدة-فيلم-كرتون-سيارات-الجزء-الثاني_1l1ll1ll111_l1_.html
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l11l1lll11_l1_.l11111l1_l1_?l1l1l11llll_l1_=49e3a27b4
		# l1ll11ll111l_l1_: https://l1ll1lll11ll_l1_.l1lll1l1l1l_l1_.l1l1l11l11l1_l1_.l1lll1ll11l_l1_/15/items/40animeHD/l1ll1ll1l1ll_l1_.l11111l1_l1_
		# l1lll11l1l1l_l1_:
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/شاهد-فيلم-حمى-الجليد-مدبلج-عربي-l1ll111111l1_l1_-l1lll11111ll_l1_.html
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l11l1lll11_l1_.l11111l1_l1_?l1l1l11llll_l1_=l1l1l1ll111l_l1_
		# l1ll11ll111l_l1_: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l11l1lll11_l1_/l1ll1l1ll1ll_l1_%20.l11111l1_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䝘"),url,l11l1l_l1_ (u"ࠩࠪ䝙"),l11l1l_l1_ (u"ࠪࠫ䝚"),False,l11l1l_l1_ (u"ࠫࠬ䝛"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡍࡄࡘࡐࡕࡕࡕࡇ࠰࠵ࡸࡺࠧ䝜"))
		if l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䝝") in response.headers:
			l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䝞")]
			l1lll11l_l1_.append(l1llll1_l1_)
			server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭䝟"))
			l1ll1l11l111_l1_.append(server)
	elif l11l1l_l1_ (u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨ࠲ࡨࡵ࡭ࠨ䝠") in url:
		# جميع الامثلة وجدتها في قائمة الاكثر مشاهدة ثم الاكثر اعجاب
		# l1lll11l1l1l_l1_:
		# url: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/فيلم-كرتون-ملكة-الثلج-مترجم-عربي_1llllll11ll_l1_.html
		# l1llll1_l1_: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l1l1l1ll1111_l1_/l111111111l_l1_/?l1llll1_l1_=https://drive.l1l1ll1l1111_l1_.com/file/d/1cCilPageFUHRn6UlIAWzUsQx1yH_83aNvA/l1lllll11111_l1_&l1l1l1l1l11l_l1_=
		# l1lll11l1l1l_l1_:
		# url: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/فيلم-فندق-ترانسلفانيا-3_da2098e12.html
		# l1llll1_l1_: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l1l1l1ll1111_l1_/l1l1111l1_l1_.l1ll1l1ll1_l1_?url=l1l1l11lll11_l1_==&sub=https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l1lll11lll11_l1_/l1l1l11ll1l1_l1_.l1l1l1ll1lll_l1_&l1l1l1l1l11l_l1_=https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l1l1lll111ll_l1_/l1l1l1111l11_l1_-1.l1l1llllll11_l1_
		# l1lll11l1l1l_l1_:
		# url: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1ll1l1l1lll_l1_.html
		# l1llll1_l1_: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l1l1l1ll1111_l1_/l1ll11lllll1_l1_/?url=https://photos.l1lllll1l1l1_l1_.l1lll11l111l_l1_.l1111l111ll_l1_/l1ll1lll11l1_l1_&sub=&l1l1l1l1l11l_l1_=http://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l1l1lll111ll_l1_/4723b8ebe-1.l1l1llllll11_l1_
		# l1lll11l1l1l_l1_:
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/مشاهدة-فيلم-كرتون-رابونزل-مترجم-عربي-l1lllllll1l1_l1_.html
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l1l1l1ll1111_l1_/l111111111l_l1_/?l1llll1_l1_=https://l1lll1l111l1_l1_.l1l1ll1l1111_l1_.com/file/d/1pk4Px3_zaocpz9bkmdjUk9Kf7nkLAPQ9AQ/l1lllll11111_l1_&sub=&l1l1l1l1l11l_l1_=https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l1l1lll111ll_l1_/2e8bc4c34-1.l1l1llllll11_l1_
		# l1lll11l1l1l_l1_:
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/فيلم-كرتون-باربي-في-مغامرة-متلألئة-مدب_1ll111l111l_l1_.html
		# https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l1l1l1ll1111_l1_/l111111111l_l1_/?l1llll1_l1_=https://drive.l1l1ll1l1111_l1_.com/file/d/12S6CP7inP7hKzHCQwOAsve47nID01jWM/view?l1lllll111l1_l1_=l1llll1lllll_l1_&l1l1l1l1l11l_l1_=https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l1l1lll111ll_l1_/l1lll11l1l11_l1_-1.l1l1llllll11_l1_
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䝡"),url,l11l1l_l1_ (u"ࠫࠬ䝢"),l11l1l_l1_ (u"ࠬ࠭䝣"),l11l1l_l1_ (u"࠭ࠧ䝤"),l11l1l_l1_ (u"ࠧࠨ䝥"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪ䝦"))
		html = response.content
		l1ll11l1llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ䝧"),html,re.DOTALL)
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ䝨"),str(l1ll11l1llll_l1_))
		if l1ll11l1llll_l1_:
			l1ll11l1llll_l1_ = l1ll11l1llll_l1_[0]
			l1l1lll1lll1_l1_ = l1l1llllllll_l1_(l1ll11l1llll_l1_)
			#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ䝩"),str(l1l1lll1lll1_l1_))
			l1l1lll11l11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪ࠮ࠪ䝪"),l1l1lll1lll1_l1_,re.DOTALL)
			if l1l1lll11l11_l1_:
				l1l1lll11l11_l1_ = l1l1lll11l11_l1_[0]
				l1l1lll11l11_l1_ = EVAL(l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫ䝫"),l1l1lll11l11_l1_)
				for dict in l1l1lll11l11_l1_:
					l1llll1_l1_ = dict[l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡩࠬ䝬")]
					l111ll11_l1_ = dict[l11l1l_l1_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ䝭")]
					#l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࡢࡣࠬ䝮")+l111ll11_l1_
					l1lll11l_l1_.append(l1llll1_l1_)
					server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ䝯"))
					l1ll1l11l111_l1_.append(l111ll11_l1_+l11l1l_l1_ (u"ࠫࠥ࠭䝰")+server)
		elif l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䝱") in response.headers:
			l1llll1_l1_ = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䝲")]
			l1lll11l_l1_.append(l1llll1_l1_)
			server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ䝳"))
			l1ll1l11l111_l1_.append(server)
		# l1lll11l1l1l_l1_: 5
		# url: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/شاهد-فيلم-كرتون-توم-وجيري-الإنطلاق-إلى_1ll1l1l1lll_l1_.html
		# l1llll1_l1_: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l1l1l1ll1111_l1_/l1ll11lllll1_l1_/?url=https://photos.l1lllll1l1l1_l1_.l1lll11l111l_l1_.l1111l111ll_l1_/l1ll1lll11l1_l1_&sub=&l1l1l1l1l11l_l1_=http://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1ll1111l1_l1_/l1l1lll111ll_l1_/4723b8ebe-1.l1l1llllll11_l1_
		if l11l1l_l1_ (u"ࠨࡁࡸࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯ࡱࡪࡲࡸࡴࡹ࠮ࡢࡲࡳ࠲࡬ࡵ࡯ࠨ䝴") in url:
			l1llll1_l1_ = url.split(l11l1l_l1_ (u"ࠩࡂࡹࡷࡲ࠽ࠨ䝵"))[1]
			l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪࠪࠬ䝶"))[0]
			if l1llll1_l1_:
				l1lll11l_l1_.append(l1llll1_l1_)
				l1ll1l11l111_l1_.append(l11l1l_l1_ (u"ࠫࡵ࡮࡯ࡵࡱࡶࠤ࡬ࡵ࡯ࡨ࡮ࡨࠫ䝷"))
	else:
		# l1lll11l1l1l_l1_:
		# url: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/فيلم-كرتون-كيف-تدرب-تنينك-العالم-الخفي_1l1l1l11lll_l1_.html
		# l1llll1_l1_: http://ok.l1lll11l11l1_l1_/l1lll1ll11l1_l1_/1676019108395
		# l1lll11l1l1l_l1_:
		# url: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/فيلم-عائلي-فتى-الكاراتيه-مدبلج-عربي_1l1l1l1llll_l1_.html
		# l1llll1_l1_: https://drive.l1l1ll1l1111_l1_.com/file/d/1AS3rrvgKtlbRJi0GwmDPj7S_EOX91YP_/l1lllll11111_l1_
		l1lll11l_l1_.append(url)
		server = SERVER(url,l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䝸"))
		l1ll1l11l111_l1_.append(server)
	if not l1lll11l_l1_: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡍࡄࡘࡐࡕࡕࡕࡇࠪ䝹"),[],[]
	elif len(l1lll11l_l1_)==1: l1llll1_l1_ = l1lll11l_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ䝺"),l1ll1l11l111_l1_)
		if l1l_l1_==-1: return l11l1l_l1_ (u"ࠨࡇ࡛ࡍ࡙࠭䝻"),[],[]
		l1llll1_l1_ = l1lll11l_l1_[l1l_l1_]
	return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䝼"),[l11l1l_l1_ (u"ࠪࠫ䝽")],[l1llll1_l1_]
def l1ll1l1ll11l_l1_(url):
	# test from: https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1lllll11l1l_l1_-l1ll1l1lll1l_l1_-l1ll11ll11l1_l1_-l1l1llll111l_l1_-l1l1lllll1l1_l1_-l11l1lll11_l1_-1-date.html
	# url = https://l1llll111l11_l1_.l1l1l1111l1l_l1_.com/l1ll11l1l11l_l1_=l1ll1lllllll_l1_
	headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䝾"):l11l1l_l1_ (u"ࠬࡑ࡯ࡥ࡫࠲ࠫ䝿")+str(kodi_version)}
	for l11l1l1ll1_l1_ in range(50):
		time.sleep(0.100)
		response = l1lll1111111_l1_(l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䞀"),url,l11l1l_l1_ (u"ࠧࠨ䞁"),headers,False,l11l1l_l1_ (u"ࠨࠩ䞂"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭䞃"))
		if l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䞄") in list(response.headers.keys()):
			l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䞅")]
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ䞆")+headers[l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䞇")]
			return l11l1l_l1_ (u"ࠧࠨ䞈"),[l11l1l_l1_ (u"ࠨࠩ䞉")],[l1llll1_l1_]
		if response.code!=429: break
	return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔࠨ䞊"),[],[]
def l1ll1llll1ll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䞋"),l11l1l_l1_ (u"ࠫࠬ䞌"),l11l1l_l1_ (u"ࠬ࠭䞍"),url)
	# https://photos.l1lllll1l1l1_l1_.l1lll11l111l_l1_.l1111l111ll_l1_/l1ll1lll11l1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䞎"),url,l11l1l_l1_ (u"ࠧࠨ䞏"),l11l1l_l1_ (u"ࠨࠩ䞐"),l11l1l_l1_ (u"ࠩࠪ䞑"),l11l1l_l1_ (u"ࠪࠫ䞒"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡑࡊࡒࡘࡔ࡙ࡇࡐࡑࡊࡐࡊ࠳࠱ࡴࡶࠪ䞓"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠭ࡥࡱࡺࡲࡱࡵࡡࡥࡵ࠱࠮ࡄ࠯ࠢ࠭࠰࠭ࡃ࠱࠴ࠪࡀ࠮ࠫ࠲࠯ࡅࠩ࠭ࠩ䞔"),html,re.DOTALL)
	if l1llll1_l1_:
		l1llll1_l1_,l111ll11_l1_ = l1llll1_l1_[0]
		return l11l1l_l1_ (u"࠭ࠧ䞕"),[l111ll11_l1_],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡓࡌࡔ࡚ࡏࡔࡉࡒࡓࡌࡒࡅࠨ䞖"),[],[]
def l1ll11llll1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䞗"),l11l1l_l1_ (u"ࠩࠪ䞘"),l11l1l_l1_ (u"ࠪࠫ䞙"),url)
	#url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡳࡳ࡫࠯ࡷ࡫ࡧࡩࡴࡥࡰ࡭ࡣࡼࡩࡷࡅࡵࡪࡦࡀ࠴ࠫࡼࡩࡥ࠿ࡩࡪࡧ࠽࠰࠹ࡥ࠴࠽࠷ࡩ࠲࠹ࡦ࠴࠵࠷࠶࠲ࡢࡦ࠴࠼ࡩࡪ࠱࠳ࡥ࠹࠼࠵࠼ࠧ䞚")
	#url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡵࡨࡰ࡭ࡪ࠭ࡦ࡯ࡥࡩࡩ࠴ࡳࡤࡦࡱ࠲ࡹࡵ࠯ࡷ࡫ࡧࡩࡴࡥࡰ࡭ࡣࡼࡩࡷࡅࡵࡪࡦࡀ࠴ࠫࡼࡩࡥ࠿ࡥ࠴࠶࠻࠹࠱࠶ࡤ࠼ࡦࡩࡦ࠸࠻࠸࠺ࡩ࠷ࡥ࠸࠸࠶࠴ࡧ࡫࠱࠸࠸࠸࠼࠼࠹ࠧ䞛")
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䞜"),url,l11l1l_l1_ (u"ࠧࠨ䞝"),l11l1l_l1_ (u"ࠨࠩ䞞"),l11l1l_l1_ (u"ࠩࠪ䞟"),l11l1l_l1_ (u"ࠪࠫ䞠"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡖࡉࡑࡎࡄ࠲࠯࠴ࡷࡹ࠭䞡"))
	html = response.content
	html = DECODE_ADILBO_HTML(html)
	#WRITE_THIS(l11l1l_l1_ (u"ࠬ࠭䞢"),html)
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䞣"),html,re.DOTALL)
	if l1llll1_l1_: return l11l1l_l1_ (u"ࠧࠨ䞤"),[l11l1l_l1_ (u"ࠨࠩ䞥")],[l1llll1_l1_[0]]
	return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡇࡓࡆࡎࡋࡈ࠶࠭䞦"),[],[]
def l1llll1ll1_l1_(url):
	if l11l1l_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧ䞧") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䞨"),url,l11l1l_l1_ (u"ࠬ࠭䞩"),l11l1l_l1_ (u"࠭ࠧ䞪"),l11l1l_l1_ (u"ࠧࠨ䞫"),l11l1l_l1_ (u"ࠨࠩ䞬"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃ࠷࡙࠲࠷ࡳࡵࠩ䞭"))
		html = response.content
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䞮"),html,re.DOTALL)
		l1llll1_l1_ = l1llll1_l1_[0]
		if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䞯") in l1llll1_l1_: return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䞰"),[l11l1l_l1_ (u"࠭ࠧ䞱")],[l1llll1_l1_]
		return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇ࠴ࡖࠩ䞲"),[],[]
	else: return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䞳"),[l11l1l_l1_ (u"ࠩࠪ䞴")],[url]
def l1lll1l11l1_l1_(url):
	l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䞵"):l11l1l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䞶"),l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䞷"):l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䞸")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䞹"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ䞺"),l11l1l_l1_ (u"ࠩࠪ䞻"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡑࡓ࡜࠳࠱ࡴࡶࠪ䞼"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䞽"),html,re.DOTALL)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡆࡉ࡜ࡒࡔ࡝ࠧ䞾"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䞿"),[l11l1l_l1_ (u"ࠧࠨ䟀")],[l1llll1_l1_]
def l1l1ll11111l_l1_(url):
	headers = {l11l1l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ䟁"):l11l1l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ䟂")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䟃"),url,l11l1l_l1_ (u"ࠫࠬ䟄"),headers,l11l1l_l1_ (u"ࠬ࠭䟅"),l11l1l_l1_ (u"࠭ࠧ䟆"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡏࡇࡒࡕࡓ࠲࠷ࡳࡵࠩ䟇"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䟈"),html,re.DOTALL|re.IGNORECASE)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡏࡐࡈࡓࡖࡔ࠭䟉"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䟊"),[l11l1l_l1_ (u"ࠫࠬ䟋")],[l1llll1_l1_]
def l1l1ll1ll11_l1_(url):
	l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䟌"):l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䟍")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䟎"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ䟏"),l11l1l_l1_ (u"ࠩࠪ䟐"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡈࡂࡎࡄࡇࡎࡓࡁ࠮࠳ࡶࡸࠬ䟑"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ䟒"),html,re.DOTALL|re.IGNORECASE)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡉࡃࡏࡅࡈࡏࡍࡂࠩ䟓"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ䟔") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭䟕")+l1llll1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䟖"),l11l1l_l1_ (u"ࠩࠪ䟗"),l11l1l_l1_ (u"ࠪࠫ䟘"),l1llll1_l1_)
	return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䟙"),[l11l1l_l1_ (u"ࠬ࠭䟚")],[l1llll1_l1_]
def l1ll1lllll_l1_(url):
	l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ䟛"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ䟜")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭䟝"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠩࠪ䟞"),l11l1l_l1_ (u"ࠪࠫ䟟"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡆࡈࡄࡐ࠯࠴ࡷࡹ࠭䟠"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ䟡"),html,re.DOTALL|re.IGNORECASE)
	if not l1llll1_l1_: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡅࡌࡑࡆࡇࡂࡅࡑࠪ䟢"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䟣"),[l11l1l_l1_ (u"ࠨࠩ䟤")],[l1llll1_l1_]
def l1ll1ll11ll1_l1_(url):
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ䟥"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䟦"),url,l11l1l_l1_ (u"ࠫࠬ䟧"),l11l1l_l1_ (u"ࠬ࠭䟨"),l11l1l_l1_ (u"࠭ࠧ䟩"),l11l1l_l1_ (u"ࠧࠨ䟪"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡙࡜ࡆࡖࡐ࠰࠵ࡸࡺࠧ䟫"))
	html = response.content
	l1l1l1l1l111_l1_ = re.findall(l11l1l_l1_ (u"ࠤࡹࡥࡷࠦࡦࡴࡧࡵࡺࠥࡃ࠮ࠫࡁࠪࠬ࠳࠰࠿ࠪࠩࠥ䟬"),html,re.DOTALL|re.IGNORECASE)
	if l1l1l1l1l111_l1_:
		l1l1l1l1l111_l1_ = l1l1l1l1l111_l1_[0][2:]
		#l1l1l1l1l111_l1_ = l1l1l1l1l111_l1_.decode(l11l1l_l1_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ䟭"))
		l1l1l1l1l111_l1_ = base64.b64decode(l1l1l1l1l111_l1_)
		if kodi_version>18.99: l1l1l1l1l111_l1_ = l1l1l1l1l111_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䟮"))
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䟯"),l1l1l1l1l111_l1_,re.DOTALL)
	else: l1llll1_l1_ = l11l1l_l1_ (u"࠭ࠧ䟰")
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡗ࡚ࡋ࡛ࡎࠨ䟱"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䟲") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䟳")+l1llll1_l1_
	return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䟴"),[l11l1l_l1_ (u"ࠫࠬ䟵")],[l1llll1_l1_]
def l1l1ll11l11l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䟶"),url,l11l1l_l1_ (u"࠭ࠧ䟷"),l11l1l_l1_ (u"ࠧࠨ䟸"),l11l1l_l1_ (u"ࠨࠩ䟹"),l11l1l_l1_ (u"ࠩࠪ䟺"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡇࡊ࡝࡛ࡏࡐ࠮࠳ࡶࡸࠬ䟻"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡵࡰ࠱࠶࠸ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䟼"),html,re.DOTALL)
	if not l1llll1_l1_: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡈࡋ࡞࡜ࡉࡑࠩ䟽"),[],[]
	l1llll1_l1_ = l1llll1_l1_[0]
	return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䟾"),[l11l1l_l1_ (u"ࠧࠨ䟿")],[l1llll1_l1_]
def l11ll1l1ll_l1_(url):
	id = url.split(l11l1l_l1_ (u"ࠨ࠱ࠪ䠀"))[-1]
	if l11l1l_l1_ (u"ࠩ࠲ࡩࡲࡨࡥࡥࠩ䠁") in url: url = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡪࡳࡢࡦࡦࠪ䠂"),l11l1l_l1_ (u"ࠫࠬ䠃"))
	url = url.replace(l11l1l_l1_ (u"ࠬ࠴ࡣࡰ࡯࠲ࠫ䠄"),l11l1l_l1_ (u"࠭࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡲ࡫ࡴࡢࡦࡤࡸࡦ࠵ࠧ䠅"))
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䠆"),url,l11l1l_l1_ (u"ࠨࠩ䠇"),l11l1l_l1_ (u"ࠩࠪ䠈"),l11l1l_l1_ (u"ࠪࠫ䠉"),l11l1l_l1_ (u"ࠫࠬ䠊"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳࠱ࡴࡶࠪ䠋"))
	html = response.content
	#WRITE_THIS(html)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ䠌"),url)
	l111111llll_l1_ = l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ䠍")
	error = re.findall(l11l1l_l1_ (u"ࠨࠤࡨࡶࡷࡵࡲࠣ࠰࠭ࡃࠧࡳࡥࡴࡵࡤ࡫ࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䠎"),html,re.DOTALL)
	if error: l111111llll_l1_ = error[0]
	url = re.findall(l11l1l_l1_ (u"ࠩࡻ࠱ࡲࡶࡥࡨࡗࡕࡐࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䠏"),html,re.DOTALL)
	if not url and l111111llll_l1_:
		#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䠐"),l11l1l_l1_ (u"ࠫࠬ䠑"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠧ䠒"),l111111llll_l1_)
		return l111111llll_l1_,[],[]
	l1llll1_l1_ = url[0].replace(l11l1l_l1_ (u"࠭࡜࡝ࠩ䠓"),l11l1l_l1_ (u"ࠧࠨ䠔"))
	l111lll1l11_l1_,l111lllll11_l1_ = l11l1ll1ll_l1_(l1llll1_l1_)
	owner = re.findall(l11l1l_l1_ (u"ࠨࠤࡲࡻࡳ࡫ࡲࠣ࠼ࡾࠦ࡮ࡪࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡷࡨࡸࡥࡦࡰࡱࡥࡲ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䠕"),html,re.DOTALL)
	if owner: l1ll11l11ll1_l1_,l1llllllll1l_l1_,l1lll1l1l11l_l1_ = owner[0]
	else: l1ll11l11ll1_l1_,l1llllllll1l_l1_,l1lll1l1l11l_l1_ = l11l1l_l1_ (u"ࠩࠪ䠖"),l11l1l_l1_ (u"ࠪࠫ䠗"),l11l1l_l1_ (u"ࠫࠬ䠘")
	l1lll1l1l11l_l1_ = l1lll1l1l11l_l1_.replace(l11l1l_l1_ (u"ࠬࡢ࠯ࠨ䠙"),l11l1l_l1_ (u"࠭࠯ࠨ䠚"))
	l1llllllll1l_l1_ = escapeUNICODE(l1llllllll1l_l1_)
	l1ll1ll1_l1_ = [l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ䠛")+l1llllllll1l_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ䠜")]+l111lll1l11_l1_
	l1lll1_l1_ = [l1lll1l1l11l_l1_]+l111lllll11_l1_
	l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠡࠪࠪ䠝")+str(len(l1lll1_l1_)-1)+l11l1l_l1_ (u"ࠪࠤ๊๊แࠪࠩ䠞"),l1ll1ll1_l1_)
	if l1l_l1_==-1: return l11l1l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䠟"),[],[]
	elif l1l_l1_==0:
		new_path = sys.argv[0]+l11l1l_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠷࠴࠷ࠬࡵࡳ࡮ࡀࠫ䠠")+l1lll1l1l11l_l1_+l11l1l_l1_ (u"࠭ࠦࡵࡧࡻࡸࡂ࠭䠡")+l1llllllll1l_l1_
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ䠢")+new_path+l11l1l_l1_ (u"ࠣࠫࠥ䠣"))
		return l11l1l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䠤"),[],[]
	l1llll1_l1_ =  l1lll1_l1_[l1l_l1_]
	return l11l1l_l1_ (u"ࠪࠫ䠥"),[l11l1l_l1_ (u"ࠫࠬ䠦")],[l1llll1_l1_]
def l11111111_l1_(l1llll1_l1_):
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䠧"),l1llll1_l1_,l11l1l_l1_ (u"࠭ࠧ䠨"),l11l1l_l1_ (u"ࠧࠨ䠩"),l11l1l_l1_ (u"ࠨࠩ䠪"),l11l1l_l1_ (u"ࠩࠪ䠫"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩ䠬"))
	html = response.content
	if l11l1l_l1_ (u"ࠫ࠳ࡰࡳࡰࡰࠪ䠭") in l1llll1_l1_: url = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ䠮"),html,re.DOTALL)
	else: url = re.findall(l11l1l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䠯"),html,re.DOTALL)
	if not url: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅࡓࡐࡘࡁࠨ䠰"),[],[]
	url = url[0]
	if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䠱") not in url: url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ䠲")+url
	return l11l1l_l1_ (u"ࠪࠫ䠳"),[l11l1l_l1_ (u"ࠫࠬ䠴")],[url]
def l1llll11llll_l1_(url):
	# http://l1ll111l1lll_l1_.l1l1ll1l1lll_l1_/l1111111l11_l1_.html?l1lllll1ll1l_l1_=l1ll1l1lllll_l1_
	# http://l1ll111l1lll_l1_.l1l1ll1l1lll_l1_/l1ll1l111l11_l1_?op=l1l1l11l1l1l_l1_&id=l1111111l11_l1_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䠵") : l11l1l_l1_ (u"࠭ࠧ䠶") }
	if l11l1l_l1_ (u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ䠷") in url:
		html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠨࠩ䠸"),headers,l11l1l_l1_ (u"ࠩࠪ䠹"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬ䠺"))
		#xbmc.log(html)
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䠻"),l11l1l_l1_ (u"ࠬ࠭䠼"),url,html)
		items = re.findall(l11l1l_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䠽"),html,re.DOTALL)
		if items: return l11l1l_l1_ (u"ࠧࠨ䠾"),[l11l1l_l1_ (u"ࠨࠩ䠿")],[items[0]]
		else:
			message = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡶࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䡀"),html,re.DOTALL)
			if message:
				DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䡁"),l11l1l_l1_ (u"ࠫࠬ䡂"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆสู้๐ࠧ䡃"),message[0])
				return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࠧ䡄")+message[0],[],[]
	else:
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䡅"),l11l1l_l1_ (u"ࠨࠩ䡆"),l1llll1_l1_,l11l1l_l1_ (u"ࠩࠪ䡇"))
		#url,l1ll1ll1111_l1_ = url.split(l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ䡈"))
		#l1ll1ll1111_l1_ = l1ll1ll1111_l1_.lower()
		l1ll1ll1111_l1_ = l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠧ䡉")
		# l11l11lll_l1_ l1l1_l1_
		html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠬ࠭䡊"),headers,l11l1l_l1_ (u"࠭ࠧ䡋"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡙ࡈࡂࡊࡇࡅ࠲࠸࡮ࡥࠩ䡌"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡈࡲࡶࡲࠦ࡭ࡦࡶ࡫ࡳࡩࡃࠢࡑࡑࡖࡘࠧࠦࡡࡤࡶ࡬ࡳࡳࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ䡍"),html,re.DOTALL)
		if not l1l11l1_l1_: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒࡕࡓࡉࡃࡋࡈࡆ࠭䡎"),[],[]
		l1llll11l1_l1_ = l1l11l1_l1_[0][0]
		block = l1l11l1_l1_[0][1]
		if l11l1l_l1_ (u"ࠪ࠲ࡷࡧࡲࠨ䡏") in block or l11l1l_l1_ (u"ࠫ࠳ࢀࡩࡱࠩ䡐") in block: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡏࡱࡷࠤࡦࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠪ䡑"),[],[]
		items = re.findall(l11l1l_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䡒"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1ll11ll1_l1_(payload)
		html = OPENURL_CACHED(l1ll1l1ll_l1_,l1llll11l1_l1_,data,headers,l11l1l_l1_ (u"ࠧࠨ䡓"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠳ࡳࡦࠪ䡔"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡛࡯ࡤࡦࡱ࠱࠮ࡄ࡭ࡥࡵ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠴ࠪࡀࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡪ࡯ࡤ࡫ࡪࡀࠧ䡕"),html,re.DOTALL)
		if not l1l11l1_l1_: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡔࡊࡄࡌࡉࡇࠧ䡖"),[],[]
		download = l1l11l1_l1_[0][0]
		block = l1l11l1_l1_[0][1]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠰ࡱࡧࡢࡦ࡮࠽ࠦ࠳࠰࠿ࠣࡾࠬࠫ䡗"),block,re.DOTALL)
		l1l1ll1l11l1_l1_,l1ll1ll1_l1_,l1llll1llll1_l1_,l1lll1_l1_,l1ll11111l1l_l1_ = [],[],[],[],[]
		for l1llll1_l1_,title in items:
			if l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䡘") in l1llll1_l1_:
				l1l1ll1l11l1_l1_,l1llll1llll1_l1_ = l11l1ll1ll_l1_(l1llll1_l1_)
				l1lll1_l1_ = l1lll1_l1_ + l1llll1llll1_l1_
				if l1l1ll1l11l1_l1_[0]==l11l1l_l1_ (u"࠭࠭࠲ࠩ䡙"): l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠧࠡีํีๆืࠠฯษุࠤࠬ䡚")+l11l1l_l1_ (u"ࠨ࡯࠶ࡹ࠽ࠦࠧ䡛")+l1ll1ll1111_l1_)
				else:
					for title in l1l1ll1l11l1_l1_:
						l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠩࠣื๏ืแาࠢัหฺࠦࠧ䡜")+l11l1l_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠡࠩ䡝")+l1ll1ll1111_l1_+l11l1l_l1_ (u"ࠫࠥ࠭䡞")+title)
			else:
				title = title.replace(l11l1l_l1_ (u"ࠬ࠲࡬ࡢࡤࡨࡰ࠿ࠨࠧ䡟"),l11l1l_l1_ (u"࠭ࠧ䡠"))
				title = title.strip(l11l1l_l1_ (u"ࠧࠣࠩ䡡"))
				#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䡢"),l11l1l_l1_ (u"ࠩࠪ䡣"),title,str(l1ll11111l1l_l1_))
				title = l11l1l_l1_ (u"ࠪࠤุ๐ัโำࠣࠤำอีࠡࠩ䡤")+l11l1l_l1_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ䡥")+l1ll1ll1111_l1_+l11l1l_l1_ (u"ࠬࠦࠧ䡦")+title
				l1ll1ll1_l1_.append(title)
				l1lll1_l1_.append(l1llll1_l1_)
		# download l1l1_l1_
		l1llll1_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠨ䡧") + download
		html = OPENURL_CACHED(l1ll1l1ll_l1_,l1llll1_l1_,l11l1l_l1_ (u"ࠧࠨ䡨"),headers,l11l1l_l1_ (u"ࠨࠩ䡩"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠶ࡶ࡫ࠫ䡪"))
		items = re.findall(l11l1l_l1_ (u"ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡼࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭ࠬࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮࠲ࠢ䡫"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l11l1l_l1_ (u"ู๊ࠫࠥาใิࠤฯำๅ๋ๆࠣาฬ฻ࠠࠨ䡬")+l11l1l_l1_ (u"ࠬࠦ࡭ࡱ࠶ࠣࠫ䡭")+l1ll1ll1111_l1_+l11l1l_l1_ (u"࠭ࠠࠨ䡮")+resolution.split(l11l1l_l1_ (u"ࠧࡹࠩ䡯"))[1]
			l1llll1_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭䡰")+id+l11l1l_l1_ (u"ࠩࠩࡱࡴࡪࡥ࠾ࠩ䡱")+mode+l11l1l_l1_ (u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪ䡲")+hash
			l1ll11111l1l_l1_.append(resolution)
			l1ll1ll1_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		l1ll11111l1l_l1_ = set(l1ll11111l1l_l1_)
		l1ll111ll1ll_l1_,l1lll1l1ll1l_l1_ = [],[]
		for title in l1ll1ll1_l1_:
			#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䡳"),l11l1l_l1_ (u"ࠬ࠭䡴"),title,l11l1l_l1_ (u"࠭ࠧ䡵"))
			res = re.findall(l11l1l_l1_ (u"ࠢࠡࠪ࡟ࡨ࠯ࡾࡼ࡝ࡦ࠭࠭ࠫࠬࠢ䡶"),title+l11l1l_l1_ (u"ࠨࠨࠩࠫ䡷"),re.DOTALL)
			for resolution in l1ll11111l1l_l1_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l11l1l_l1_ (u"ࠩࡻࠫ䡸"))[1])
			l1ll111ll1ll_l1_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1lll1_l1_)):
			items = re.findall(l11l1l_l1_ (u"ࠥࠪࠫ࠮࠮ࠫࡁࠬࠬࡡࡪࠪࠪࠨࠩࠦ䡹"),l11l1l_l1_ (u"ࠫࠫࠬࠧ䡺")+l1ll111ll1ll_l1_[i]+l11l1l_l1_ (u"ࠬࠬࠦࠨ䡻"),re.DOTALL)
			l1lll1l1ll1l_l1_.append( [l1ll111ll1ll_l1_[i],l1lll1_l1_[i],items[0][0],items[0][1]] )
		l1lll1l1ll1l_l1_ = sorted(l1lll1l1ll1l_l1_, key=lambda x: x[3], reverse=True)
		l1lll1l1ll1l_l1_ = sorted(l1lll1l1ll1l_l1_, key=lambda x: x[2], reverse=False)
		l1ll1ll1_l1_,l1lll1_l1_ = [],[]
		for i in range(len(l1lll1l1ll1l_l1_)):
			l1ll1ll1_l1_.append(l1lll1l1ll1l_l1_[i][0])
			l1lll1_l1_.append(l1lll1l1ll1l_l1_[i][1])
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ䡼"),[],[]
	return l11l1l_l1_ (u"ࠧࠨ䡽"),l1ll1ll1_l1_,l1lll1_l1_
def l1lll1ll1lll_l1_(url):
	# http://l1l1l11l1l11_l1_.com/717254
	parts = url.split(l11l1l_l1_ (u"ࠨࡁࠪ䡾"))
	l111l1l_l1_ = parts[0]
	headers = { l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䡿") : l11l1l_l1_ (u"ࠪࠫ䢀") }
	html = OPENURL_CACHED(l1ll1l1ll_l1_,l111l1l_l1_,l11l1l_l1_ (u"ࠫࠬ䢁"),headers,l11l1l_l1_ (u"ࠬ࠭䢂"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࠹࡙࡙ࡁࡓ࠯࠴ࡷࡹ࠭䢃"))
	items = re.findall(l11l1l_l1_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡸࡣ࡬ࡸ࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨ䢄"),html,re.DOTALL)
	url = items[0]
	#l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll111ll1_l1_(url)
	#return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
	return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䢅"),[l11l1l_l1_ (u"ࠩࠪ䢆")],[url]
def l1ll11llll1l_l1_(url):
	# https://l1llll11ll1_l1_.l1lll1ll11l_l1_/l1llll1l11l_l1_
	# https://l1lll1ll1l1_l1_.cc/l1llll1l11l_l1_
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䢇") : l11l1l_l1_ (u"ࠫࠬ䢈") }
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠬ࠭䢉"),headers,l11l1l_l1_ (u"࠭ࠧ䢊"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡉࡕࡍࡖ࡜ࡆࡔࡕࡋࡔ࠯࠴ࡷࡹ࠭䢋"))
	l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡹࡷࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䢌"),html,re.DOTALL)
	if l111l1l_l1_: return l11l1l_l1_ (u"ࠩࠪ䢍"),[l11l1l_l1_ (u"ࠪࠫ䢎")],[l111l1l_l1_[0]]
	else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡂࡖ࡜࡝࡚ࡗࡒࠧ䢏"),[],[]
def l1lll1lll1l1_l1_(url):
	# https://l1llll11ll1_l1_.l1lll1ll11l_l1_/l1llll1l11l_l1_
	# https://l1lll1ll1l1_l1_.cc/l1llll1l11l_l1_
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䢐") : l11l1l_l1_ (u"࠭ࠧ䢑") }
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠧࠨ䢒"),headers,l11l1l_l1_ (u"ࠨࠩ䢓"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨ䢔"))
	l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭䢕"),html,re.DOTALL)
	if l111l1l_l1_: return l11l1l_l1_ (u"ࠫࠬ䢖"),[l11l1l_l1_ (u"ࠬ࠭䢗")],[l111l1l_l1_[0]]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙ࠧ䢘"),[],[]
def l1ll1l11111_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䢙"),l11l1l_l1_ (u"ࠨࠩ䢚"),l11l1l_l1_ (u"ࠩࠪ䢛"),url)
	# l11l11lll_l1_    https://show.l1ll11l1l1ll_l1_.com/l1ll11l11111_l1_-l1ll111lll11_l1_/l1ll111lll11_l1_-l1lll1111l1l_l1_.l1ll1l1ll1_l1_?action=l1ll11111ll1_l1_&l1lll11_l1_=32513&l1ll1l1111l_l1_=1&type=l1llll11lll_l1_
	# download https://show.l1ll11l1l1ll_l1_.com/l1l1_l1_/l1l1ll1111ll_l1_
	l1ll1ll1_l1_,l1lll1_l1_,errno = [],[],l11l1l_l1_ (u"ࠪࠫ䢜")
	# l11l11lll_l1_
	if l11l1l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࠨ䢝") in url:
		l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䢞"):l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭䢟")}
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䢠"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ䢡"),l11l1l_l1_ (u"ࠩࠪ䢢"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯࠵ࡲࡩ࠭䢣"))
		l11ll111_l1_ = response.content
		if l11ll111_l1_.startswith(l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䢤")): l111l1l_l1_ = l11ll111_l1_
		else:
			l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࡠ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛ࠨࠤࡠࠫࠬ࠭䢥"),l11ll111_l1_,re.DOTALL)
			if l111ll1_l1_:
				l111l1l_l1_ = l111ll1_l1_[0]
				l111ll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡰࡷࡵࡧࡪࡃࠨ࠯ࠬࡂ࠭ࠩ࠭䢦"),l111l1l_l1_,re.DOTALL)
				if l111ll1_l1_:
					l111l1l_l1_ = l1llll_l1_(l111ll1_l1_[0])
					return l11l1l_l1_ (u"ࠧࠨ䢧"),[l11l1l_l1_ (u"ࠨࠩ䢨")],[l111l1l_l1_]
	# download
	elif l11l1l_l1_ (u"ࠩ࠲ࡰ࡮ࡴ࡫ࡴ࠱ࠪ䢩") in url:
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䢪"),url,l11l1l_l1_ (u"ࠫࠬ䢫"),l11l1l_l1_ (u"ࠬ࠭䢬"),True,l11l1l_l1_ (u"࠭ࠧ䢭"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠱ࡴࡶࠪ䢮"))
		l11ll111_l1_ = response.content
		if l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䢯") in list(response.headers.keys()): l111l1l_l1_ = response.headers[l11l1l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䢰")]
		else: l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䢱"),l11ll111_l1_,re.DOTALL)[0]
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䢲"),l11l1l_l1_ (u"ࠬ࠭䢳"),l111l1l_l1_,str(2222))
	if l11l1l_l1_ (u"࠭࠯ࡷ࠱ࠪ䢴") in l111l1l_l1_ or l11l1l_l1_ (u"ࠧ࠰ࡨ࠲ࠫ䢵") in l111l1l_l1_:
		l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠨ࠱ࡩ࠳ࠬ䢶"),l11l1l_l1_ (u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ䢷"))
		l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠪ࠳ࡻ࠵ࠧ䢸"),l11l1l_l1_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ䢹"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䢺"),l11l1l_l1_ (u"࠭ࠧ䢻"),l111l1l_l1_,str(3333))
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䢼"),l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ䢽"),l11l1l_l1_ (u"ࠩࠪ䢾"),l11l1l_l1_ (u"ࠪࠫ䢿"),l11l1l_l1_ (u"ࠫࠬ䣀"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠸ࡸࡤࠨ䣁"))
		l11ll111_l1_ = response.content
		items = re.findall(l11l1l_l1_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䣂"),l11ll111_l1_,re.DOTALL)
		if items:
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠧ࡝࡞ࠪ䣃"),l11l1l_l1_ (u"ࠨࠩ䣄"))
				l1ll1ll1_l1_.append(title)
				l1lll1_l1_.append(l1llll1_l1_)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䣅"),l11ll111_l1_,re.DOTALL)
			if items:
				l1llll1_l1_ = items[0]
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡡ࠭䣆"),l11l1l_l1_ (u"ࠫࠬ䣇"))
				l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠬ࠭䣈"))
				l1lll1_l1_.append(l1llll1_l1_)
	else: return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䣉"),[l11l1l_l1_ (u"ࠧࠨ䣊")],[l111l1l_l1_]
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䣋"),l11l1l_l1_ (u"ࠩࠪ䣌"),str(l11l1llll_l1_),l111l1l_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ䣍"),[],[]
	return l11l1l_l1_ (u"ࠫࠬ䣎"),l1ll1ll1_l1_,l1lll1_l1_
def l111lll11l1_l1_(url):
	# l11l11lll_l1_ l11111l1_l1_  https://l1ll1l1l1l11_l1_.l1llll1lll11_l1_.l1lll1ll11l_l1_/l1l1lllll1ll_l1_/l1l1l111111l_l1_.l1ll1l1ll1_l1_?s=07&id=l11111l11l1_l1_,&l1ll1l_l1_=2wh9shmvcTypozADtS8EpvgrwWS.l1l1llllll11_l1_&l1lll1l111ll_l1_=l1l1l1l11l1l_l1_&l1ll11ll1lll_l1_=l1l1l111ll1l_l1_
	# l11l11lll_l1_ l1lll1l1l_l1_ https://l1lllll1111l_l1_.l1llll1lll11_l1_.l1lll1ll11l_l1_/l1l1lllll1ll_l1_/l1l1l1ll1l11_l1_.l1ll1l1ll1_l1_?l1llll1111l1_l1_=l1ll111ll111_l1_&l1ll1ll1ll11_l1_=8a26a6cc61a884e89076504130c71626&l1ll1l_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1l1llllll11_l1_&l1lll1l111ll_l1_=l1l1l1l11l1l_l1_&l1ll1l_l1_=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1l1llllll11_l1_&l1lll1l111ll_l1_=l1l1l1l11l1l_l1_&l1ll11ll1lll_l1_=l1l1lll1111l_l1_
	# download https://l1l1l1l111l_l1_.l1llll11lll1_l1_.l1ll11l1111l_l1_/l1lll1l1l1l1_l1_?server=l1l1l1ll11l1_l1_&id=l1lll1llll1l_l1_,,
	# l1l1111l1_l1_ https://l1llll11lll1_l1_.l1ll1ll1l1_l1_/l1l1111l1_l1_/l1lll11ll1ll_l1_
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䣏"),url,l11l1l_l1_ (u"࠭ࠧ䣐"),l11l1l_l1_ (u"ࠧࠨ䣑"),l11l1l_l1_ (u"ࠨࠩ䣒"),l11l1l_l1_ (u"ࠩࠪ䣓"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠱ࡴࡶࠪ䣔"))
	html = response.content
	l1ll1ll1_l1_,l1lll1_l1_,errno = [],[],l11l1l_l1_ (u"ࠫࠬ䣕")
	if l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ䣖") in url or l11l1l_l1_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ䣗") in url:
		if l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ䣘") in url:
			l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣙"),html,re.DOTALL)
			l111l1l_l1_ = l111l1l_l1_[0]
		else: l111l1l_l1_ = url
		if l11l1l_l1_ (u"ࠩࡰࡳࡻࡹ࠴ࡶࠩ䣚") not in l111l1l_l1_: return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䣛"),[l11l1l_l1_ (u"ࠫࠬ䣜")],[l111l1l_l1_]
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䣝"),l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ䣞"),l11l1l_l1_ (u"ࠧࠨ䣟"),l11l1l_l1_ (u"ࠨࠩ䣠"),l11l1l_l1_ (u"ࠩࠪ䣡"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡘࡖ࠸࡚࠳࠲࡯ࡦࠪ䣢"))
		html = response.content
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡶࡪࡦࡨࡳ࡯ࡹࠧ䣣"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣤"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,l1ll11l1l111_l1_ in items:
				l1ll1ll1_l1_.append(l1ll11l1l111_l1_)
				l1lll1_l1_.append(l1llll1_l1_)
	elif l11l1l_l1_ (u"࠭࡭ࡢ࡫ࡱࡣࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨ䣥") in url:
		l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡶࡴ࡯ࡁ࠭࠴ࠪࡀࠫࠥࠫ䣦"),html,re.DOTALL)
		l111l1l_l1_ = l111l1l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䣧"),l111l1l_l1_,l11l1l_l1_ (u"ࠩࠪ䣨"),l11l1l_l1_ (u"ࠪࠫ䣩"),l11l1l_l1_ (u"ࠫࠬ䣪"),l11l1l_l1_ (u"ࠬ࠭䣫"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠶ࡶࡩ࠭䣬"))
		html = response.content
		l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䣭"),html,re.DOTALL)
		l111ll1_l1_ = l111ll1_l1_[0]
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠨࠩ䣮"))
		l1lll1_l1_.append(l111ll1_l1_)
	elif l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡱ࡯࡮࡬ࠩ䣯") in url:
		l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡨ࡫࡮ࡵࡧࡵࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䣰"),html,re.DOTALL)
		if l111l1l_l1_:
			l111l1l_l1_ = l111l1l_l1_[0]
			return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䣱"),[l11l1l_l1_ (u"ࠬ࠭䣲")],[l111l1l_l1_]
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒ࡚ࡘ࠺ࡕࠨ䣳"),[],[]
	return l11l1l_l1_ (u"ࠧࠨ䣴"),l1ll1ll1_l1_,l1lll1_l1_
def l11111111l_l1_(url):
	# https://l1lll1llll11_l1_.l1ll1l1lll11_l1_/l1lllll11lll_l1_?call=l1lll11llll1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l1lllll1ll1l_l1_=l1ll1l1ll1l1_l1_
	# https://l1lll1llll11_l1_.l1ll1l1lll11_l1_/l1lllll11lll_l1_?call=l1lll11llll1_l1_&auth=874ded32a2e3b91d6ae55186274469e2?l1lllll1ll1l_l1_=l1ll111lllll_l1_
	l111l1l_l1_ = url.split(l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ䣵"),1)[0].strip(l11l1l_l1_ (u"ࠩࡂࠫ䣶")).strip(l11l1l_l1_ (u"ࠪ࠳ࠬ䣷")).strip(l11l1l_l1_ (u"ࠫࠫ࠭䣸"))
	l1ll1ll1_l1_,l1lll1_l1_,items,l111ll1_l1_ = [],[],[],l11l1l_l1_ (u"ࠬ࠭䣹")
	headers = { l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䣺"):l11l1l_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠧ䣻") }
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䣼"),l111l1l_l1_,l11l1l_l1_ (u"ࠩࠪ䣽"),headers,True,l11l1l_l1_ (u"ࠪࠫ䣾"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠳ࡶࡸࠬ䣿"))
	if l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䤀") in list(response.headers.keys()): l111ll1_l1_ = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䤁")]
	#response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䤂"),l111ll1_l1_,l11l1l_l1_ (u"ࠨࠩ䤃"),headers,False,l11l1l_l1_ (u"ࠩࠪ䤄"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠳ࡰࡧࠫ䤅"))
	#if l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭䤆") in response.headers: l111ll1_l1_ = response.headers[l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䤇")]
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䤈"),l11l1l_l1_ (u"ࠧࠨ䤉"),l111ll1_l1_,response.content)
	if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭䤊") in l111ll1_l1_:
		# https://l111111lll_l1_.top/f/l1lll111l1l1_l1_/?l111l11ll1_l1_=l11111llll1_l1_
		# https://l111111lll_l1_.top/v/l1lll111l1l1_l1_/?l111l11ll1_l1_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ䤋") in url: l111ll1_l1_ = l111ll1_l1_.replace(l11l1l_l1_ (u"ࠪ࠳࡫࠵ࠧ䤌"),l11l1l_l1_ (u"ࠫ࠴ࡼ࠯ࠨ䤍"))
		l1llllll11l1_l1_ = l111l1l_l1_.split(l11l1l_l1_ (u"ࠬࡅࡐࡉࡒࡖࡍࡉࡃࠧ䤎"))[1]
		headers = { l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䤏"):headers[l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䤐")] , l11l1l_l1_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ䤑"):l11l1l_l1_ (u"ࠩࡓࡌࡕ࡙ࡉࡅ࠿ࠪ䤒")+l1llllll11l1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䤓"),l111ll1_l1_,l11l1l_l1_ (u"ࠫࠬ䤔"),headers,False,l11l1l_l1_ (u"ࠬ࠭䤕"),l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ䤖"))
		html = response.content
		#xbmc.log(html)
		#html = OPENURL_CACHED(l1ll1l1ll_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠧࠨ䤗"),headers,l11l1l_l1_ (u"ࠨࠩ䤘"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠳ࡳࡦࠪ䤙"))
		if l11l1l_l1_ (u"ࠪ࠳࡫࠵ࠧ䤚") in l111ll1_l1_: items = re.findall(l11l1l_l1_ (u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䤛"),html,re.DOTALL)
		elif l11l1l_l1_ (u"ࠬ࠵ࡶ࠰ࠩ䤜") in l111ll1_l1_: items = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䤝"),html,re.DOTALL)
		if items: return [],[l11l1l_l1_ (u"ࠧࠨ䤞")],[ items[0] ]
		elif l11l1l_l1_ (u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧ䤟") in html:
			return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬ䤠"),[],[]
	else: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭䤡"),[],[]
	#xbmc.log(html)
def l1lll1ll1l1l_l1_(l1llll1_l1_):
	# https://l1111l1111l_l1_.net/?l11ll11l_l1_=147043&l11ll1ll_l1_=5
	parts = re.findall(l11l1l_l1_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭䤢"),l1llll1_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ䤣"),re.DOTALL|re.IGNORECASE)
	l11ll11l_l1_,l11ll1ll_l1_ = parts[0]
	url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ䤤")+l11ll11l_l1_+l11l1l_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ䤥")+l11ll1ll_l1_
	headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䤦"):l11l1l_l1_ (u"ࠩࠪ䤧") , l11l1l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䤨"):l11l1l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䤩") }
	l111l1l_l1_ = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠬ࠭䤪"),headers,l11l1l_l1_ (u"࠭ࠧ䤫"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯࠴ࡷࡹ࠭䤬"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䤭"),l11l1l_l1_ (u"ࠩࠪ䤮"),url,l111l1l_l1_)
	#l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll111ll1_l1_(l111l1l_l1_)
	#return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
	return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䤯"),[l11l1l_l1_ (u"ࠫࠬ䤰")],[l111l1l_l1_]
def l111lll1111_l1_(url):
	# https://l1l1l11l111l_l1_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1lll111l11l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l1lll1ll1l11_l1_=1608181746
	server = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䤱"))
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䤲"):server,l11l1l_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩ䤳"):l11l1l_l1_ (u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨ䤴")}
	response = OPENURL_REQUESTS_CACHED(l1111ll1l11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䤵"),url,l11l1l_l1_ (u"ࠪࠫ䤶"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠫࠬ䤷"),l11l1l_l1_ (u"ࠬ࠭䤸"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡝ࡈࡏࡍࡂ࠯࠴ࡷࡹ࠭䤹"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࠮ࡲࡷࡤࡰ࡮ࡺࡹࡴࡧ࡯ࡩࡨࡺ࡯ࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡴࡰࡥࡹࡹ࠺ࠨ䤺"),html,re.DOTALL)
	l111l1l_l1_ = l11l1l_l1_ (u"ࠨࠩ䤻")
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡩࡳࡷࡳࡡࡵ࠼ࠣࡠࠬ࠮࡜ࡥ࠰࠭ࡃ࠮ࡢࠧ࠭ࠢࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䤼"),block,re.DOTALL)
		l1ll1ll1_l1_,l1lll1_l1_ = [],[]
		for title,l1llll1_l1_ in items:
			l1ll1ll1_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		if len(l1lll1_l1_)==1: l111l1l_l1_ = l1lll1_l1_[0]
		elif len(l1lll1_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ䤽"), l1ll1ll1_l1_)
			if l1l_l1_==-1: return l11l1l_l1_ (u"ࠫࠬ䤾"),[],[]
			l111l1l_l1_ = l1lll1_l1_[l1l_l1_]
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䤿"),html,re.DOTALL)
		if l1l11l1_l1_: l111l1l_l1_ = l1l11l1_l1_[0]
	if not l111l1l_l1_: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏ࡜ࡇࡎࡓࡁࠨ䥀"),[],[]
	return l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䥁"),[l11l1l_l1_ (u"ࠨࠩ䥂")],[l111l1l_l1_]
def l1l1lll111l1_l1_(url):
	# https://l1111l111l1_l1_.l1l1ll11l111_l1_/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1lll111l11l_l1_=0GfHI4TukZPPkW7vi8eP8Q&l1lll1ll1l11_l1_=1608181746
	# https://l1111l111l1_l1_.l1ll1l1lll11_l1_/run/2f3b76e9e415b50dda3e12e5d895e1dd83b2f05a0bea10b9c5ed6fd192d1510a5871b818dcd3bf7940cf8efafd5660abe156b6fc0a9014ce7fc95636da06c23b66a18ddad2501c6ddbb3adffebda075d4f0e02abe1cafd7b9873cc495dcfc84baf097a?l1lll111l11l_l1_=l111111l111_l1_&l1lll1ll1l11_l1_=1684182121
	server = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䥃"))
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䥄"):server,l11l1l_l1_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡊࡴࡣࡰࡦ࡬ࡲ࡬࠭䥅"):l11l1l_l1_ (u"ࠬ࡭ࡺࡪࡲ࠯ࠤࡩ࡫ࡦ࡭ࡣࡷࡩࠬ䥆")}
	response = OPENURL_REQUESTS_CACHED(l1111ll1l11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䥇"),url,l11l1l_l1_ (u"ࠧࠨ䥈"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ䥉"),l11l1l_l1_ (u"ࠩࠪ䥊"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠳࠱ࡴࡶࠪ䥋"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬ䥌"),html,re.DOTALL)
	l111l1l_l1_ = l11l1l_l1_ (u"ࠬ࠭䥍")
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ䥎"),block,re.DOTALL)
		l1ll1ll1_l1_,l1lll1_l1_ = [],[]
		for title,l1llll1_l1_ in items:
			l1ll1ll1_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		if len(l1lll1_l1_)==1: l111l1l_l1_ = l1lll1_l1_[0]
		elif len(l1lll1_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ䥏"), l1ll1ll1_l1_)
			if l1l_l1_==-1: return l11l1l_l1_ (u"ࠨࠩ䥐"),[],[]
			l111l1l_l1_ = l1lll1_l1_[l1l_l1_]
	if not l111l1l_l1_:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䥑"),html,re.DOTALL)
		if l1l11l1_l1_: l111l1l_l1_ = l1l11l1_l1_[0]
	if not l111l1l_l1_: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡅࡄࡋࡐࡅࠬ䥒"),[],[]
	return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䥓"),[l11l1l_l1_ (u"ࠬ࠭䥔")],[l111l1l_l1_]
def l1l111ll_l1_(l1llll1_l1_):
	# https://w.l1ll111l1111_l1_.l1llll1l11ll_l1_/l1ll11l11111_l1_-content/l11111l111l_l1_/l1ll1111l1ll_l1_/l1llll1l111l_l1_/l1ll1111l1l1_l1_/l1ll1l1l11ll_l1_/l1ll11l111ll_l1_.l1ll1l1ll1_l1_?l11ll11l_l1_=42869&l11ll1ll_l1_=4
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䥕"),l11l1l_l1_ (u"ࠧࠨ䥖"),l1llll1_l1_,html)
	parts = re.findall(l11l1l_l1_ (u"ࠨࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࡠࡄࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ䥗"),l1llll1_l1_+l11l1l_l1_ (u"ࠩࠩࠪࠬ䥘"),re.DOTALL)
	url,l11ll11l_l1_,l11ll1ll_l1_ = parts[0]
	data = {l11l1l_l1_ (u"ࠪࡴࡴࡹࡴࡠ࡫ࡧࠫ䥙"):l11ll11l_l1_,l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ䥚"):l11ll1ll_l1_}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䥛"),url,data,l11l1l_l1_ (u"࠭ࠧ䥜"),l11l1l_l1_ (u"ࠧࠨ䥝"),l11l1l_l1_ (u"ࠨࠩ䥞"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐࡇࡆࡓ࠭࠲ࡵࡷࠫ䥟"))
	html = response.content
	l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䥠"),html,re.DOTALL)[0]
	return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䥡"),[l11l1l_l1_ (u"ࠬ࠭䥢")],[l111l1l_l1_]
def l1ll1l1111_l1_(url):
	# https://l1lll1l1llll_l1_.l1ll1ll11l_l1_-l1lll1lll1ll_l1_.com/l1l1111l1_l1_.l1ll1l1ll1_l1_?l1l1l11llll_l1_=l1ll11lll11l_l1_
	# https://l.l1ll11l11l11_l1_.l1ll11l1111l_l1_/l1l1111l1_l1_.l1ll1l1ll1_l1_?l1l1l11llll_l1_=40e2032d1
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䥣"),url,l11l1l_l1_ (u"ࠧࠨ䥤"),l11l1l_l1_ (u"ࠨࠩ䥥"),l11l1l_l1_ (u"ࠩࠪ䥦"),l11l1l_l1_ (u"ࠪࠫ䥧"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧ䥨"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䥩"),html,re.DOTALL)
	if l1llll1_l1_:
		l1llll1_l1_ = l1llll1_l1_[0]
		if l1llll1_l1_: return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䥪"),[l11l1l_l1_ (u"ࠧࠨ䥫")],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭䥬"),[],[]
def l1ll1lll11_l1_(url):
	# https://l1ll1ll111_l1_.l1ll1ll11l_l1_-l1ll1ll1l1_l1_.l1ll1ll1l1_l1_/l1ll11l11111_l1_-content/l11111l111l_l1_/old/l1ll1ll_l1_/server.l1ll1l1ll1_l1_?q=140276&i=3
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䥭"),url,l11l1l_l1_ (u"ࠪࠫ䥮"),l11l1l_l1_ (u"ࠫࠬ䥯"),l11l1l_l1_ (u"ࠬ࠭䥰"),l11l1l_l1_ (u"࠭ࠧ䥱"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡄࡎࡘࡔ࠲࠷ࡳࡵࠩ䥲"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡌࡊࡗࡇࡍࡆࠢࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䥳"),html,re.DOTALL)[0]
	return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䥴"),[l11l1l_l1_ (u"ࠪࠫ䥵")],[l1llll1_l1_]
def l1ll11llll_l1_(url):
	# https://l1lll11ll111_l1_.l1l1l1l1ll1l_l1_.cc/l1ll11l11111_l1_-content/l11111l111l_l1_/l1l1ll1ll1l1_l1_%20Now%20New/l1l1ll111111_l1_.l1ll1l1ll1_l1_?action=l1lll1lll111_l1_&index=00&id=58504
	# https://l1lll111l111_l1_.l1l1l1l1ll1l_l1_.net/l1l1ll1111l1_l1_/2021/04/05/_1ll11lll1ll_l1_-l11111lll11_l1_.l1l1l11111ll_l1_ 200.l1l1l1lll111_l1_.2020.l1l1ll11ll11_l1_/[l1l1ll1ll1l1_l1_-l11111lll11_l1_.l1l1lll1l1ll_l1_] 200.l1l1l1lll111_l1_.2020.l1l1ll11ll11_l1_-360p.l11111l1_l1_
	l1llll11ll_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䥶"))
	if l11l1l_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡁࠬ䥷") in url:
		headers = {l11l1l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ䥸"):l1llll11ll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䥹"),url,l11l1l_l1_ (u"ࠨࠩ䥺"),headers,l11l1l_l1_ (u"ࠩࠪ䥻"),l11l1l_l1_ (u"ࠪࠫ䥼"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬ䥽"))
		html = response.content
		l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䥾"),html,re.DOTALL)
		if l111l1l_l1_:
			l111l1l_l1_ = l111l1l_l1_[0]
			if l11l1l_l1_ (u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ䥿") in l111l1l_l1_:
				l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ䦀"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ䦁"))
				response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䦂"),l111l1l_l1_,l11l1l_l1_ (u"ࠪࠫ䦃"),headers,l11l1l_l1_ (u"ࠫࠬ䦄"),l11l1l_l1_ (u"ࠬ࠭䦅"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠶ࡳࡪࠧ䦆"))
				l11ll111_l1_ = response.content
				items = re.findall(l11l1l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䦇"),l11ll111_l1_,re.DOTALL)
				l1ll1ll1_l1_,l1lll1_l1_ = [],[]
				l1lll1lll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䦈"))
				for l1llll1_l1_,l111ll11_l1_ in reversed(items):
					l1llll1_l1_ = l1lll1lll1_l1_+l1llll1_l1_+l11l1l_l1_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ䦉")+l1lll1lll1_l1_
					l1ll1ll1_l1_.append(l111ll11_l1_)
					l1lll1_l1_.append(l1llll1_l1_)
				return l11l1l_l1_ (u"ࠪࠫ䦊"),l1ll1ll1_l1_,l1lll1_l1_
			else: return l11l1l_l1_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ䦋"),[l11l1l_l1_ (u"ࠬ࠭䦌")],[l111l1l_l1_]
	l111l1l_l1_ = url+l11l1l_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䦍")+l1llll11ll_l1_
	return l11l1l_l1_ (u"ࠧࠨ䦎"),[l11l1l_l1_ (u"ࠨࠩ䦏")],[l111l1l_l1_]
def l1ll1ll11lll_l1_(l1llll1_l1_):
	# https://l1l1l1l1ll1l_l1_.l1llll1l11ll_l1_/l1ll11l11111_l1_-content/l11111l111l_l1_/l1lll1ll1ll1_l1_/l1l1ll111l11_l1_/server.l1ll1l1ll1_l1_?l11ll11l_l1_=42869&l11ll1ll_l1_=4
	# https://l1lllll11l11_l1_.l1l1l1l1ll1l_l1_.net/l1l1ll1111l1_l1_/2020/08/14/_1ll11lll1ll_l1_-l11111lll11_l1_.l1l1l11111ll_l1_ l1l1llll1111_l1_.l1ll1l1llll1_l1_.2020.l1ll1l111l1l_l1_-l1ll1ll111ll_l1_/[l1l1ll1ll1l1_l1_-l11111lll11_l1_.l1l1lll1l1ll_l1_] l1l1llll1111_l1_.l1ll1l1llll1_l1_.2020.l1ll1l111l1l_l1_-l1ll1ll111ll_l1_-1080p.l11111l1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䦐"),l11l1l_l1_ (u"ࠪࠫ䦑"),url,html)
	l1llll11ll_l1_ = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䦒"))
	if l11l1l_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬ䦓") in l1llll1_l1_:
		parts = re.findall(l11l1l_l1_ (u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬ䦔"),l1llll1_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪ䦕"),re.DOTALL)
		url,l11ll11l_l1_,l11ll1ll_l1_ = parts[0]
		data = {l11l1l_l1_ (u"ࠨ࡫ࡧࠫ䦖"):l11ll11l_l1_,l11l1l_l1_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ䦗"):l11ll1ll_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䦘"),url,data,l11l1l_l1_ (u"ࠫࠬ䦙"),l11l1l_l1_ (u"ࠬ࠭䦚"),l11l1l_l1_ (u"࠭ࠧ䦛"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡇࡎࡓࡁࡏࡑ࡚࠱࠶ࡹࡴࠨ䦜"))
		html = response.content
		l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䦝"),html,re.DOTALL)[0]
		if l11l1l_l1_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ䦞") in l111l1l_l1_:
			headers = {l11l1l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䦟"):l1llll11ll_l1_,l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䦠"):l11l1l_l1_ (u"ࠬ࠭䦡")}
			response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䦢"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ䦣"),headers,l11l1l_l1_ (u"ࠨࠩ䦤"),l11l1l_l1_ (u"ࠩࠪ䦥"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ䦦"))
			l11ll111_l1_ = response.content
			items = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䦧"),l11ll111_l1_,re.DOTALL)
			l1ll1ll1_l1_,l1lll1_l1_ = [],[]
			l1lll1lll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䦨"))
			for l1llll1_l1_,l111ll11_l1_ in reversed(items):
				l1llll1_l1_ = l1lll1lll1_l1_+l1llll1_l1_+l11l1l_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䦩")+l1lll1lll1_l1_
				l1ll1ll1_l1_.append(l111ll11_l1_)
				l1lll1_l1_.append(l1llll1_l1_)
			return l11l1l_l1_ (u"ࠧࠨ䦪"),l1ll1ll1_l1_,l1lll1_l1_
		else: return l11l1l_l1_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ䦫"),[l11l1l_l1_ (u"ࠩࠪ䦬")],[l111l1l_l1_]
	else:
		l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭䦭")+l1llll11ll_l1_
		return l11l1l_l1_ (u"ࠫࠬ䦮"),[l11l1l_l1_ (u"ࠬ࠭䦯")],[l1llll1_l1_]
def l111l1l11_l1_(l1llll1_l1_):
	# http://l11111111ll_l1_.tv/?l11ll11l_l1_=159485&l11ll1ll_l1_=0
	if l11l1l_l1_ (u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭䦰") in l1llll1_l1_:
		parts = re.findall(l11l1l_l1_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ䦱"),l1llll1_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ䦲"),re.DOTALL|re.IGNORECASE)
		l11ll11l_l1_,l11ll1ll_l1_ = parts[0]
		host = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䦳"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䦴"),l11l1l_l1_ (u"ࠫࠬ䦵"),l1llll1_l1_,host)
		url = host+l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ䦶")+l11ll11l_l1_+l11l1l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ䦷")+l11ll1ll_l1_
		headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䦸"):l11l1l_l1_ (u"ࠨࠩ䦹") , l11l1l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䦺"):l11l1l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䦻") }
		l111l1l_l1_ = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠫࠬ䦼"),headers,l11l1l_l1_ (u"ࠬ࠭䦽"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡇࡒࡉࡐࡐ࡝࠱࠶ࡹࡴࠨ䦾"))
		l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠧ࡝ࡰࠪ䦿"),l11l1l_l1_ (u"ࠨࠩ䧀")).replace(l11l1l_l1_ (u"ࠩ࡟ࡶࠬ䧁"),l11l1l_l1_ (u"ࠪࠫ䧂"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䧃"),l11l1l_l1_ (u"ࠬ࠭䧄"),url,l111l1l_l1_)
		#l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1ll111ll1_l1_(l111l1l_l1_)
		#return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
		return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䧅"),[l11l1l_l1_ (u"ࠧࠨ䧆")],[l111l1l_l1_]
	elif l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ䧇") in l1llll1_l1_:
		counts = 0
		while l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭䧈") in l1llll1_l1_ and counts<5:
			response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䧉"),l1llll1_l1_,l11l1l_l1_ (u"ࠫࠬ䧊"),l11l1l_l1_ (u"ࠬ࠭䧋"),l11l1l_l1_ (u"࠭ࠧ䧌"),l11l1l_l1_ (u"ࠧࠨ䧍"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠲࡯ࡦࠪ䧎"))
			if l11l1l_l1_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ䧏") in list(response.headers.keys()): l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ䧐")]
			counts += 1
		return l11l1l_l1_ (u"ࠫࠬ䧑"),[l11l1l_l1_ (u"ࠬ࠭䧒")],[l1llll1_l1_]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ䧓"),[],[]
def l11l1111l_l1_(url):
	# https://l1ll11ll1111_l1_.l1l1lll1l111_l1_.me/l/l111111l1ll_l1_=
	server = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䧔"))
	headers = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䧕"):server,l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䧖"):l11llll11_l1_()}
	if l11l1l_l1_ (u"ࠪ࠳ࡘ࡫ࡲࡷࡧࡵ࠲ࡵ࡮ࡰࠨ䧗") in url:
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ䧘"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ䧙")}
		l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ䧚"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,True,l11l1l_l1_ (u"ࠧࠨ䧛"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠱ࡴࡶࠪ䧜"))
		html = response.content
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡖࡖࡈࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䧝"),html,re.DOTALL|re.IGNORECASE)
		if l1llll1_l1_: return l11l1l_l1_ (u"ࠪࠫ䧞"),[l11l1l_l1_ (u"ࠫࠬ䧟")],[l1llll1_l1_[0]]
	elif l11l1l_l1_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭䧠") in url:
		html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"࠭ࠧ䧡"),headers,l11l1l_l1_ (u"ࠧࠨ䧢"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠲࡯ࡦࠪ䧣"))
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䧤"),html,re.DOTALL)
		if l1llll1_l1_: return l11l1l_l1_ (u"ࠪࠫ䧥"),[l11l1l_l1_ (u"ࠫࠬ䧦")],[l1llll1_l1_[0]]
	else:
		l1ll11ll11ll_l1_ = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䧧"),url,l11l1l_l1_ (u"࠭ࠧ䧨"),headers,l11l1l_l1_ (u"ࠧࠨ䧩"),l11l1l_l1_ (u"ࠨࠩ䧪"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫ䧫"))
		html = l1ll11ll11ll_l1_.content
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭䧬"),html,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll_l1_(l1llll1_l1_[0])+l11l1l_l1_ (u"ࠫࠫࡪ࠽࠲ࠩ䧭")
			l1l1llll1_l1_ = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䧮"),l1llll1_l1_,l11l1l_l1_ (u"࠭ࠧ䧯"),headers,l11l1l_l1_ (u"ࠧࠨ䧰"),l11l1l_l1_ (u"ࠨࠩ䧱"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫ䧲"))
			html = l1l1llll1_l1_.content
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䧳"),html,re.DOTALL)
			if l1llll1_l1_:
				l1llll1_l1_ = l1llll_l1_(l1llll1_l1_[0])
				return l11l1l_l1_ (u"ࠫࠬ䧴"),[l11l1l_l1_ (u"ࠬ࠭䧵")],[l1llll1_l1_]
		if l11l1l_l1_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ䧶") in list(l1ll11ll11ll_l1_.headers.keys()):
			cookies = l1ll11ll11ll_l1_.headers[l11l1l_l1_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫ䧷")]
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡡ࡯ࡲࡰࡥ࠮ࠫࡁࡀࠬ࠳࠰࠿ࠪ࠽ࠪ䧸"),cookies,re.DOTALL)
			if l1llll1_l1_:
				l1llll1_l1_ = l1llll_l1_(l1llll1_l1_[0])
				return l11l1l_l1_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ䧹"),[l11l1l_l1_ (u"ࠪࠫ䧺")],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡃࡅࡗࡊࡋࡄࠨ䧻"),[],[]
	l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠧࠥࡴ࡯ࡵࠢࡺࡳࡷࡱࡩ࡯ࡩࠍࠍࠎࠩࠠࡪࡶࠣࡲࡪ࡫ࡤࡴࠢࡦࡳࡴࡱࡩࡦࠢࡩࡶࡴࡳࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠎࠎࠏࠣࠡࡅࡲࡳࡰ࡯ࡥ࠻ࠢࡦࡪࡤࡩ࡬ࡦࡣࡵࡥࡳࡩࡥ࠾ࡅࡐࡩ࠳ࡎࡋࡈࡓ࡮ࡱࡼࡴࡓࡗࡷࡱࡾ࡛ࡏࡰࡲࡱࡺࡵࡘࡇ࡚ࡤࡲࡱࡊ࠼ࡰࡂࡑࡗࡒࡕࡧ࡟ࡂࡇ࠲࠰࠵࠻࠼࠳࠲࠳࠵࠴࠵࠼࠭࠱࠯࠵࠹࠵ࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࠡ࠿ࠣࡗࡊࡘࡖࡆࡔࠫࡹࡷࡲࠬࠨࡷࡵࡰࠬ࠯ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࠿ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔࠩࠫ࠯ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡀࡳࡦࡴࡹࡩࡷࢃࠊࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࠧࡈࡇࡗࠫ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠷ࡴࡤࠨࠫࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡯࡭ࡳࡱ࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࡿࡶࡪ࠴ࡉࡈࡐࡒࡖࡊࡉࡁࡔࡇࠬࠎࠎࠏࡩࡧࠢ࡯࡭ࡳࡱࡳ࠻ࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭࡫ࠦࠧࡦ࡯ࡥࡩࡩ࠳ࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࠩ࠯࡟ࠬ࠭࡝࠭࡝࡯࡭ࡳࡱ࡝ࠋࠋࠌࠍࡪࡲࡳࡦ࠼ࠣࡹࡷࡲࠠ࠾ࠢ࡯࡭ࡳࡱࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࠪࠫ࠱ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪ࠮࡫ࡸࡲࡲࠩࠋࠋࠌࠧࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࡝࠳ࡡࠏࠏࠉࠤ࡫ࡩࠤࠬࡧࡲࡢࡤࡶࡩࡪࡪࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠊࠊࠋࠦࠍࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠥࠌࡶࡪࡺࡵࡳࡰࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠍࠍࠎࠩࡥ࡭ࡵࡨ࠾ࠥࡻࡲ࡭ࠢࡀࠤࡱ࡯࡮࡬ࠌࠌࠦࠧࠨ䧼")
	#if l11l1l_l1_ (u"࠭࠮࡮ࡲ࠷࠲࡭ࡺ࡭࡭ࠩ䧽") in url:
	#	l1ll111111ll_l1_ = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ䧾"))
	#	url = l11l1l_l1_ (u"ࠨ࠱ࠪ䧿").join(l1ll111111ll_l1_[:4])
	#	tmp = re.findall(l11l1l_l1_ (u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠳࠴࠴ࠪࡀ࠱ࠬࠬ࠳࠰࠿ࠪࠦࠪ䨀"),url,re.DOTALL)
	#	if tmp: url = tmp[0][0]+l11l1l_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ䨁")+tmp[0][1]+l11l1l_l1_ (u"ࠫ࠳࡮ࡴ࡮࡮ࠪ䨂")
	#	#return l11l1l_l1_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ䨃"),[l11l1l_l1_ (u"࠭ࠧ䨄")],[url]
	#	#l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l1l1l1l1l1ll_l1_(url)
	#	#return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
	# l1l1111l1_l1_ l1llll1_l1_
	#return l11l1l_l1_ (u"ࠧࠨ䨅"),[l11l1l_l1_ (u"ࠨࠩ䨆")],[l1llll1_l1_]
def l1l1ll1lll11_l1_(l1llll1_l1_):
	# https://l1ll1l11ll1l_l1_.l1ll1ll11l1l_l1_/l1l11llllll1_l1_?_1l1lll1llll_l1_=l1l1l11ll1ll_l1_&_1ll1111l111_l1_=86046&l11ll1ll_l1_=0
	if l11l1l_l1_ (u"ࠩࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷ࠭䨇") in l1llll1_l1_:
		headers = {l11l1l_l1_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭䨈"):l11l1l_l1_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ䨉")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ䨊"),l1llll1_l1_,l11l1l_l1_ (u"࠭ࠧ䨋"),headers,l11l1l_l1_ (u"ࠧࠨ䨌"),l11l1l_l1_ (u"ࠨࠩ䨍"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠲ࡵࡷࠫ䨎"))
		url = response.content
		if url: return l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䨏"),[l11l1l_l1_ (u"ࠫࠬ䨐")],[url]
	else:
		# https://l1l1ll11lll1_l1_.net/?l11ll11l_l1_=142302&l11ll1ll_l1_=4
		parts = re.findall(l11l1l_l1_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠩ࠭䨑"),l1llll1_l1_,re.DOTALL|re.IGNORECASE)
		if not parts: parts = re.findall(l11l1l_l1_ (u"࠭࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩ䨒"),l1llll1_l1_,re.DOTALL|re.IGNORECASE)
		l11ll11l_l1_,l11ll1ll_l1_ = parts[0]
		server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䨓"))
		#url = server+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰ࡕࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬ䨔")
		url = server+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪ䨕")
		#url = server+l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹࡅࡨࡲࡹ࡫ࡲࡀࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠫࡥࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠨ䨖")+l11ll11l_l1_+l11l1l_l1_ (u"ࠫࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠨ䨗")+l11ll1ll_l1_
		#data = {l11l1l_l1_ (u"ࠬ࡯ࡤࠨ䨘"):l11ll11l_l1_,l11l1l_l1_ (u"࠭ࡩࠨ䨙"):l11ll1ll_l1_,l11l1l_l1_ (u"ࠧ࡮ࡧࡷࡥࠬ䨚"):l11l1l_l1_ (u"ࠨࡱ࡯ࡨࡤࡹࡥࡳࡸࡨࡶࡸ࠭䨛"),l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ䨜"):l11l1l_l1_ (u"ࠪࡳࡱࡪࠧ䨝")}
		data = {l11l1l_l1_ (u"ࠫ࡮ࡪࠧ䨞"):l11ll11l_l1_,l11l1l_l1_ (u"ࠬ࡯ࠧ䨟"):l11ll1ll_l1_}
		headers = {l11l1l_l1_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ䨠"):l11l1l_l1_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ䨡"),l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䨢"):l1llll1_l1_}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ䨣"),url,data,headers,l11l1l_l1_ (u"ࠪࠫ䨤"),l11l1l_l1_ (u"ࠫࠬ䨥"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠶ࡳࡪࠧ䨦"))
		l11ll111_l1_ = response.content
		l111l1l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䨧"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		if l111l1l_l1_:
			l111l1l_l1_ = l111l1l_l1_[0]
			return l11l1l_l1_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ䨨"),[l11l1l_l1_ (u"ࠨࠩ䨩")],[l111l1l_l1_]
	return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇ࠸࡚࠭䨪"),[],[]
def l1lll1ll_l1_(url,type,l111ll11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䨫"),l11l1l_l1_ (u"ࠫࠬ䨬"),l111l1l_l1_,type)
	# http://l1ll11l1ll11_l1_.l1llllll111l_l1_.io/l1llll1_l1_/136530
	l1lll11l_l1_,l1ll1l11l111_l1_ = [],[]
	l11ll111_l1_ = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠬ࠭䨭"),l11l1l_l1_ (u"࠭ࠧ䨮"),True,l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐ࡝ࡁࡎ࠯࠴ࡷࡹ࠭䨯"))
	l111111_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠼࠰ࡣࡁࠫ䨰"),l11ll111_l1_,re.DOTALL)
	for block in l111111_l1_:
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ䨱"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll11l_l1_ and (l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ䨲") in l1llll1_l1_ or l11l1l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ䨳") in l1llll1_l1_):
				title = title.replace(l11l1l_l1_ (u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭䨴"),l11l1l_l1_ (u"࠭ࠧ䨵")).replace(l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫ䨶"),l11l1l_l1_ (u"ࠨࠩ䨷")).strip(l11l1l_l1_ (u"ࠩࠣࠫ䨸")).replace(l11l1l_l1_ (u"ࠪࠤࠥ࠭䨹"),l11l1l_l1_ (u"ࠫࠥ࠭䨺"))
				l1lll11l_l1_.append(l1llll1_l1_)
				l1ll1l11l111_l1_.append(title)
	if not l1lll11l_l1_: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭䨻"),[],[]
	if len(l1lll11l_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫ䨼"),l1ll1l11l111_l1_)
		if l1l_l1_==-1: l1l_l1_ = 0
	else: l1l_l1_ = 0
	l111ll1_l1_ = l1lll11l_l1_[l1l_l1_]
	l1lll1_l1_,l1ll1ll1_l1_ = [],[]
	if type==l11l1l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ䨽"):
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䨾"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪ䨿"),l11l1l_l1_ (u"ࠪࠫ䩀"),l11l1l_l1_ (u"ࠫࠬ䩁"),True,l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠳ࡰࡧࠫ䩂"))
		l1l1l1lll_l1_ = response.content
		l1llll1ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡢࡵࡰ࠰ࡰࡴࡧࡤࡦࡴ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䩃"),l1l1l1lll_l1_,re.DOTALL)
		if l1llll1ll_l1_:
			l1llll1_l1_ = l1llll_l1_(l1llll1ll_l1_[0])
			l1lll1_l1_.append(l1llll1_l1_)
			l1ll1ll1_l1_.append(l111ll11_l1_)
			#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䩄"),l11l1l_l1_ (u"ࠨࠩ䩅"),l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䩆"),l1llll1_l1_)
	elif type==l11l1l_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩ䩇"):
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䩈"),l111ll1_l1_,l11l1l_l1_ (u"ࠬ࠭䩉"),l11l1l_l1_ (u"࠭ࠧ䩊"),l11l1l_l1_ (u"ࠧࠨ䩋"),True,l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏ࠰࠷ࡷࡪࠧ䩌"))
		l1l1l1lll_l1_ = response.content
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䩍"),l1l1l1lll_l1_,re.DOTALL)
		for l1llll1_l1_,size in l1l1_l1_:
			if l111ll11_l1_ in size:
				l1ll1ll1_l1_.append(size)
				l1lll1_l1_.append(l1llll1_l1_)
				#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䩎"),l11l1l_l1_ (u"ࠫࠬ䩏"),l11l1l_l1_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ䩐"),l1llll1_l1_)
				break
		if not l1lll1_l1_:
			for l1llll1_l1_,size in l1l1_l1_:
				l1ll1ll1_l1_.append(size)
				l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭ࡔࡆࡕࡗࠫ䩑"),l1lll1_l1_)
	if not l1lll1_l1_: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨ䩒"),[],[]
	return l11l1l_l1_ (u"ࠨࠩ䩓"),l1ll1ll1_l1_,l1lll1_l1_
def l11ll1l_l1_(url,name):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䩔"),l11l1l_l1_ (u"ࠪࠫ䩕"),url,l1lllll1ll1l_l1_)
	# http://l1111l11l11_l1_.l1ll111l1111_l1_.net/5cf68c23e6e79			?l1lllll1ll1l_l1_=			__11111ll11l_l1_
	# http://w.l11l1l1l_l1_.l1lll1ll11l_l1_/5e14fd0a2806e			?l1lllll1ll1l_l1_=			ok.l1ll11ll1ll1_l1_
	#l1lllll1ll1l_l1_ = l1lllll1ll1l_l1_.replace(l11l1l_l1_ (u"ࠫࡦࡱ࡯ࡢ࡯ࡢࡣࠬ䩖"),l11l1l_l1_ (u"ࠬ࠭䩗")).split(l11l1l_l1_ (u"࠭࡟ࡠࠩ䩘"))[1]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䩙"),url,l11l1l_l1_ (u"ࠨࠩ䩚"),l11l1l_l1_ (u"ࠩࠪ䩛"),True,l11l1l_l1_ (u"ࠪࠫ䩜"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍࡒࡅࡒ࠳࠱ࡴࡶࠪ䩝"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l11l1l_l1_ (u"ࠬ࡭࡯࡭࡫ࡱ࡯ࠬ䩞") in list(cookies.keys()):
		l11l111ll_l1_ = cookies[l11l1l_l1_ (u"࠭ࡧࡰ࡮࡬ࡲࡰ࠭䩟")]
		l11l111ll_l1_ = l1llll_l1_(escapeUNICODE(l11l111ll_l1_))
		items = re.findall(l11l1l_l1_ (u"ࠧࡳࡱࡸࡸࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䩠"),l11l111ll_l1_,re.DOTALL)
		l111l1l_l1_ = items[0].replace(l11l1l_l1_ (u"ࠨ࡞࠲ࠫ䩡"),l11l1l_l1_ (u"ࠩ࠲ࠫ䩢"))
		l111l1l_l1_ = escapeUNICODE(l111l1l_l1_)
	else: l111l1l_l1_ = url
	if l11l1l_l1_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ䩣") in l111l1l_l1_:
		id = l111l1l_l1_.split(l11l1l_l1_ (u"ࠫࠪ࠸ࡆࠨ䩤"))[-1]
		l111l1l_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡡࡵࡥ࡫࠲࡮ࡹ࠯ࠨ䩥")+id
		return l11l1l_l1_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ䩦"),[l11l1l_l1_ (u"ࠧࠨ䩧")],[l111l1l_l1_]
	else:
		l1l11lll_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ䩨")][0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䩩"),l1l11lll_l1_,l11l1l_l1_ (u"ࠪࠫ䩪"),l11l1l_l1_ (u"ࠫࠬ䩫"),True,l11l1l_l1_ (u"ࠬ࠭䩬"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬ䩭"))
		l1lllll1l1ll_l1_ = response.url
		#l1lllll1l1ll_l1_ = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䩮")]
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䩯"),l11l1l_l1_ (u"ࠩࠪ䩰"),response.url,l1l11lll_l1_)
		l1ll1l111ll1_l1_ = l111l1l_l1_.split(l11l1l_l1_ (u"ࠪ࠳ࠬ䩱"))[2]#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ䩲"))
		l1111l11l1l_l1_ = l1lllll1l1ll_l1_.split(l11l1l_l1_ (u"ࠬ࠵ࠧ䩳"))[2]#.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ䩴"))
		l111ll1_l1_ = l111l1l_l1_.replace(l1ll1l111ll1_l1_,l1111l11l1l_l1_)
		headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䩵"):l11l1l_l1_ (u"ࠨࠩ䩶") , l11l1l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ䩷"):l11l1l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ䩸") , l11l1l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䩹"):l111ll1_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ䩺"), l111ll1_l1_, l11l1l_l1_ (u"࠭ࠧ䩻"), headers, False,l11l1l_l1_ (u"ࠧࠨ䩼"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠷ࡷࡪࠧ䩽"))
		html = response.content
		#xbmc.log(str(l111ll1_l1_), level=xbmc.LOGERROR)
		items = re.findall(l11l1l_l1_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䩾"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l11l1l_l1_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䩿"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l11l1l_l1_ (u"ࠫࡁ࡫࡭ࡣࡧࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䪀"),html,re.DOTALL|re.IGNORECASE)
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䪁"),l11l1l_l1_ (u"࠭ࠧ䪂"),str(items),html)
		if items:
			l1llll1_l1_ = items[0].replace(l11l1l_l1_ (u"ࠧ࡝࠱ࠪ䪃"),l11l1l_l1_ (u"ࠨ࠱ࠪ䪄"))
			l1llll1_l1_ = l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠩ࠲ࠫ䪅"))
			if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ䪆") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䪇") + l1llll1_l1_
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭䪈"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ䪉"))
			if name==l11l1l_l1_ (u"ࠧࠨ䪊"): l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠨࠩ䪋"),[l11l1l_l1_ (u"ࠩࠪ䪌")],[l1llll1_l1_]
			else: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭䪍"),[l11l1l_l1_ (u"ࠫࠬ䪎")],[l1llll1_l1_]
		else: l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭䪏"),[],[]
		return l111111llll_l1_,l1ll1ll1_l1_,l1lll1_l1_
def l1llll111lll_l1_(url):
	# https://l1l1l1l111l_l1_.l1llll1l1ll1_l1_.com/e/l1l1ll1l1l11_l1_
	headers = { l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䪐") : l11l1l_l1_ (u"ࠧࠨ䪑") }
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠨࠩ䪒"),headers,l11l1l_l1_ (u"ࠩࠪ䪓"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡂࡒࡌࡈ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ䪔"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䪕"),l11l1l_l1_ (u"ࠬ࠭䪖"),url,html)
	items = re.findall(l11l1l_l1_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䪗"),html,re.DOTALL)
	l1ll1ll1_l1_,l1lll1_l1_,errno = [],[],l11l1l_l1_ (u"ࠧࠨ䪘")
	if items:
		for l1llll1_l1_,l1ll11l1l111_l1_ in items:
			l1ll1ll1_l1_.append(l1ll11l1l111_l1_)
			l1lll1_l1_.append(l1llll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧ䪙"),[],[]
	return l11l1l_l1_ (u"ࠩࠪ䪚"),l1ll1ll1_l1_,l1lll1_l1_
def l1l1lll1l11l_l1_(url):
	# https://l1ll111ll1l1_l1_.com/l1l1111l1_l1_-l1lll1l11111_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ䪛"),l11l1l_l1_ (u"ࠫࠬ䪜"))
	headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䪝") : l11l1l_l1_ (u"࠭ࠧ䪞") }
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠧࠨ䪟"),headers,l11l1l_l1_ (u"ࠨࠩ䪠"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ䪡"))
	items = re.findall(l11l1l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䪢"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䪣"),l11l1l_l1_ (u"ࠬ࠭䪤"),url,items[0])
	if items:
		url = items[0]+l11l1l_l1_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩ䪥")+url
		return l11l1l_l1_ (u"ࠧࠨ䪦"),[l11l1l_l1_ (u"ࠨࠩ䪧")],[url]
	else: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡚ࡗࡌࡐࡃࡇࠫ䪨"),[],[]
def l1ll1lll1111_l1_(url):
	# https://l1l11lllllll_l1_.to/l1l1111l1_l1_/5c83f14297d62
	url = url.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ䪩"))
	if l11l1l_l1_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ䪪") in url: id = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ䪫"))[4]
	else: id = url.split(l11l1l_l1_ (u"࠭࠯ࠨ䪬"))[-1]
	url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸࡦࡷࡹࡸࡥࡢ࡯࠱ࡸࡴ࠵ࡰ࡭ࡣࡼࡩࡷࡅࡦࡪࡦࡀࠫ䪭") + id
	headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䪮") : l11l1l_l1_ (u"ࠩࠪ䪯") }
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠪࠫ䪰"),headers,l11l1l_l1_ (u"ࠫࠬ䪱"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡆࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ䪲"))
	html = html.replace(l11l1l_l1_ (u"࠭࡜࡝ࠩ䪳"),l11l1l_l1_ (u"ࠧࠨ䪴"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䪵"),l11l1l_l1_ (u"ࠩࠪ䪶"),url,html)
	items = re.findall(l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䪷"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"ࠫࠬ䪸"),[l11l1l_l1_ (u"ࠬ࠭䪹")],[ items[0] ]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡆࡗ࡙ࡘࡅࡂࡏࠪ䪺"),[],[]
def l1ll1111111l_l1_(url):
	# https://l1111111111_l1_.net/l1l1111l1_l1_-l1lll1ll11ll_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䪻"),l11l1l_l1_ (u"ࠨࠩ䪼"))
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠩࠪ䪽"),l11l1l_l1_ (u"ࠪࠫ䪾"),l11l1l_l1_ (u"ࠫࠬ䪿"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬ䫀"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䫁"),html,re.DOTALL)
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	for l1llll1_l1_,l1ll11l1l111_l1_,res in items:
		l1ll1ll1_l1_.append(l1ll11l1l111_l1_+l11l1l_l1_ (u"ࠧࠡࠩ䫂")+res)
		l1lll1_l1_.append(l1llll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡎࡊࡏ࡛ࡃࠪ䫃"),[],[]
	return l11l1l_l1_ (u"ࠩࠪ䫄"),l1ll1ll1_l1_,l1lll1_l1_
def l1lll111llll_l1_(url):
	# https://l11111l1111_l1_.l1lll1l1l1l_l1_/l1l1111l1_l1_-l1ll1111lll1_l1_.html
	url = url.replace(l11l1l_l1_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ䫅"),l11l1l_l1_ (u"ࠫࠬ䫆"))
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠬ࠭䫇"),l11l1l_l1_ (u"࠭ࠧ䫈"),l11l1l_l1_ (u"ࠧࠨ䫉"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ䫊"))
	items = re.findall(l11l1l_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢ䫋"),html,re.DOTALL)
	items = set(items)
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	for id,mode,hash,l1ll11l1l111_l1_,res in items:
		url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ䫌")+id+l11l1l_l1_ (u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ䫍")+mode+l11l1l_l1_ (u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ䫎")+hash
		html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"࠭ࠧ䫏"),l11l1l_l1_ (u"ࠧࠨ䫐"),l11l1l_l1_ (u"ࠨࠩ䫑"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡁࡕࡅࡋ࡚ࡎࡊࡅࡐ࠯࠵ࡲࡩ࠭䫒"))
		items = re.findall(l11l1l_l1_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠣࡰ࡮ࡴ࡫࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ䫓"),html,re.DOTALL)
		for l1llll1_l1_ in items:
			l1ll1ll1_l1_.append(l1ll11l1l111_l1_+l11l1l_l1_ (u"ࠫࠥ࠭䫔")+res)
			l1lll1_l1_.append(l1llll1_l1_)
	if len(l1lll1_l1_)==0: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒࠫ䫕"),[],[]
	return l11l1l_l1_ (u"࠭ࠧ䫖"),l1ll1ll1_l1_,l1lll1_l1_
def l1l1l1111111_l1_(url):
	# https://l1l1l11llll1_l1_.com:2053/l1l1l1l1111l_l1_/l1ll1111l11l_l1_.l1lll11lll1l_l1_.l11111lllll_l1_.1080p.l11111l1lll_l1_.l1lllll1ll11_l1_.l1l1l11l1111_l1_.l11111l1_l1_.html?l1lll111l11l_l1_=2jpqzvpT8BbNUifWZO4QLQ&l1lll1ll1l11_l1_=1624070560
	# http://l1l1l1llll1l_l1_.l1lllll111ll_l1_/l1lll11l1ll1_l1_/l1lll1l1111l_l1_.l1ll1l1l1ll1_l1_.l1lll1l1lll1_l1_.2018.1080p.l1ll1l111l1l_l1_-l1ll1ll111ll_l1_.l1l1l1lll1l1_l1_.l11111l1_l1_.html
	l1llll1_l1_ = l11l1l_l1_ (u"ࠧࠨ䫗")
	if 1 or l11l1l_l1_ (u"ࠨࡍࡨࡽࡂ࠭䫘") not in url:
		l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ࠭䫙"),l11l1l_l1_ (u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧ䫚"))
		l111l1l_l1_ = l111l1l_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭䫛"))
		id = l111l1l_l1_[3]
		l111l1l_l1_ = l11l1l_l1_ (u"ࠬ࠵ࠧ䫜").join(l111l1l_l1_[0:4])
		#headers = {l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ䫝"):l11llll11_l1_(),l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭䫞"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ䫟")}
		payload = {l11l1l_l1_ (u"ࠩ࡬ࡨࠬ䫠"):id,l11l1l_l1_ (u"ࠪࡳࡵ࠭䫡"):l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ䫢"),l11l1l_l1_ (u"ࠬࡳࡥࡵࡪࡲࡨࡤ࡬ࡲࡦࡧࠪ䫣"):l11l1l_l1_ (u"࠭ࡆࡳࡧࡨ࠯ࡉࡵࡷ࡯࡮ࡲࡥࡩ࠱ࠥ࠴ࡇࠨ࠷ࡊ࠭䫤")}
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䫥"),l111l1l_l1_,payload,l11l1l_l1_ (u"ࠨࠩ䫦"),l11l1l_l1_ (u"ࠩࠪ䫧"),l11l1l_l1_ (u"ࠪࠫ䫨"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ䫩"))
		if l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ䫪") in list(response.headers.keys()): l1llll1_l1_ = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䫫")]
		if not l1llll1_l1_ and response.succeeded:
			html = response.content
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䫬"),html,re.DOTALL)
			if l1llll1_l1_: l1llll1_l1_ = l1llll1_l1_[0]
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䫭"),url,l11l1l_l1_ (u"ࠩࠪ䫮"),l11l1l_l1_ (u"ࠪࠫ䫯"),l11l1l_l1_ (u"ࠫࠬ䫰"),l11l1l_l1_ (u"ࠬ࠭䫱"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠴ࡱࡨࠬ䫲"))
		if l11l1l_l1_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩ䫳") in list(response.headers.keys()): l1llll1_l1_ = response.headers[l11l1l_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ䫴")]
	if l1llll1_l1_: return l11l1l_l1_ (u"ࠩࠪ䫵"),[l11l1l_l1_ (u"ࠪࠫ䫶")],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡕࡑࡄࡒࡑࠬ䫷"),[],[]
def l1ll1lll1ll1_l1_(url):
	# https://l1l1l1l111l_l1_.l1ll1l11llll_l1_.com/012ocyw9li6g.html
	headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䫸") : l11l1l_l1_ (u"࠭ࠧ䫹") }
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠧࠨ䫺"),headers,l11l1l_l1_ (u"ࠨࠩ䫻"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫ䫼"))
	items = re.findall(l11l1l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩ䫽"),html,re.DOTALL)
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	if items:
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠫࡲࡶ࠴ࠨ䫾"))
		l1lll1_l1_.append(items[0][1])
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠬࡳ࠳ࡶ࠺ࠪ䫿"))
		l1lll1_l1_.append(items[0][0])
		return l11l1l_l1_ (u"࠭ࠧ䬀"),l1ll1ll1_l1_,l1lll1_l1_
	else: return l11l1l_l1_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡏࡍࡎ࡜ࡉࡅࡇࡒࠫ䬁"),[],[]
def l1111111lll_l1_(url):
	# l1lll11lll11_l1_ l1llll1l11l1_l1_			url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡟࠷ࡘ࠶࠴࡚ࡒࡾࡹࡒࡇࠪ䬂")
	# l1l1l1l1ll11_l1_ .l11111ll1l1_l1_ l1llll1l11l1_l1_		url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡘࡷ࡯ࡖࡒࡆࡿࡥࡺࡈࡌࠫ䬃")
	# l1lll11l1lll_l1_ l11l11l1ll_l1_ .l1lll1l1l_l1_ l1llll1l11l1_l1_		url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡈࡨ࠵࠱ࡓ࡙ࡴࡔࡵࡑࡻࠬ䬄")
	# l1ll1lllll11_l1_ l1llll1l11l1_l1_			url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭䬅")
	# l1111ll1ll_l1_ files have l1ll1lll111l_l1_ l1l1l11lll1l_l1_		url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࠴ࡻࡉࡘࡕࡗࡥࡖࡽࡤࡗࠧ䬆")
	# url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࡨࡈࡱࡠ࠵ࡷࡃࡑࡕ࡚࡭ࠧ䬇")
	# url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺ࠴ࡸ࠲ࡧ࡫࠯ࡦࡆ࡯࡞࠺ࡼࡁࡏࡓࡘ࡫ࠬ䬈")
	# url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡪࡳࡢࡦࡦ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ䬉")
	# url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫ䬊")
	# url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡱࡈࡈࡰࡰ࡯࡟ࡋ࠳࡜࡯ࠫࡧࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭࠿ࡊࡳࡱࡪࡥ࡯ࡎ࡬ࡲࡪ࡬࡯ࡳࡖ࡙ࡔࡷࡵࡤࡶࡥࡷ࡭ࡴࡴࡡ࡯ࡦࡇ࡭ࡸࡺࡲࡪࡤࡸࡸ࡮ࡵ࡮ࡀࡵࡼࡲࡩ࡯ࡣࡢࡶ࡬ࡳࡳࡃ࠲࠸࠹࠸࠻࠺࠭䬋")
	# l1ll1l1l1_l1_ l1l1lll11l1l_l1_ l1l1l111ll11_l1_   https://l1ll1111ll1l_l1_.me/l1l1l11ll111_l1_/l1l1l111l111_l1_-l1l1l11l1lll_l1_-l1l1lll11111_l1_
	id = url.split(l11l1l_l1_ (u"ࠫ࠴࠭䬌"))[-1]
	id = id.split(l11l1l_l1_ (u"ࠬࠬࠧ䬍"))[0]
	id = id.replace(l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ䬎"),l11l1l_l1_ (u"ࠧࠨ䬏"))
	#id = l11l1l_l1_ (u"ࠨࡧࡢࡗ࠾࡜ࡶࡋࡏ࠴ࡔࡎ࠭䬐")
	#url = l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳ࡵࡲࡡࡺ࠱ࡂࡺ࡮ࡪࡥࡰࡡ࡬ࡨࡂ࠭䬑")+id
	#return l11l1l_l1_ (u"ࠪࠫ䬒"),[l11l1l_l1_ (u"ࠫࠬ䬓")],[url]
	l111l1l_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䬔")][0]+l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ䬕")+id
	l1l1l11111l1_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺ࠴ࡢࡦ࠱ࠪ䬖")+id
	l1ll1l1ll111_l1_,l1l1l1l11111_l1_,l1111l11111_l1_,l1l1l1ll11ll_l1_ = l11l1l_l1_ (u"ࠨࠩ䬗"),l11l1l_l1_ (u"ࠩࠪ䬘"),l11l1l_l1_ (u"ࠪࠫ䬙"),l11l1l_l1_ (u"ࠫࠬ䬚")
	l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫࠬࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡢࠧ࠭ࠩࠪ࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠩ࠰࠭ࡃ࠮ࡪࡥࡧࡣࡸࡰࡹࡇࡵࡥ࡫ࡲࡘࡷࡧࡣ࡬ࡋࡱࡨࡪࡾࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡻ࠰࠱࠴࠹ࠫ࠱࠭ࠦࠧࠩࠬࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࢁࠢ࡭ࡣࡱ࡫ࡺࡧࡧࡦࡅࡲࡨࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠ࡜ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭࡝࠭࡝ࠪࠫࡢࠐࠉࠊࠋࡩࡳࡷࠦ࡬ࡢࡰࡪ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡡ࡯ࡩࠬࠎࠎࠏࠉࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡙ࡅࡍࡇࡆࡘ࠭࠭วฯฬิࠤฬ๊สาฮ่อࠥอไๆ่สือฯ࠺ࠨ࠮ࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠯ࠊࠊࠋࠌ࡭࡫ࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡱࡳࡹࠦࡩ࡯ࠢ࡞࠴࠱࠳࠱࡞࠼ࠍࠍࠎࠏࠉࡴࡷࡥࡸ࡮ࡺ࡬ࡦࡗࡕࡐࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡨࡡࡴࡧࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡥࡰࡴࡩ࡫࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊࠋࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒࠠ࠾ࠢࡶࡹࡧࡺࡩࡵ࡮ࡨ࡙ࡗࡒ࡛࠱࡟࠮ࠫࠫ࡬࡭ࡵ࠿ࡹࡸࡹࠬࡴࡺࡲࡨࡁࡹࡸࡡࡤ࡭ࠩࡸࡱࡧ࡮ࡨ࠿ࠪ࠯ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡡࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࡟ࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡪࡨࠣࠫ࠴ࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠰ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣ࠺ࠡࡦࡤࡷ࡭࡛ࡒࡍࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡤࡢࡵ࡫࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡳ࠰ࠩ࠯ࠫ࠴ࡹࡩࡨࡰࡤࡸࡺࡸࡥ࠰ࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡱࡹࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࠾ࠏࠏࠉࡩ࡮ࡶ࡙ࡗࡒࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠎࠩࡨࡵ࡯࡯࠶ࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࡨ࡭ࡵࡘࡖࡑ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠲࡯ࡦࠪ࠭ࠏࠏࠉࠤ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮࡙ࠧ࠯ࡐࡉࡉࡏࡁ࠻ࡗࡕࡍࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࡔ࡚ࡒࡈࡁࡘ࡛ࡂࡕࡋࡗࡐࡊ࡙ࠬࡈࡔࡒ࡙ࡕ࠳ࡉࡅ࠿ࠥࡺࡹࡺࠧ࠭ࡪࡷࡱࡱ࠸ࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠣࡷࡺࡨࡴࡪࡶ࡯ࡩ࡚ࡘࡌࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡࠨ࠱ࠧࠧࡨࡰࡸࡂࡼࡴࡵࠨࡷࡽࡵ࡫࠽ࡵࡴࡤࡧࡰࠬࡴ࡭ࡣࡱ࡫ࡂ࠭ࠊࠊࡤ࡯ࡳࡨࡱࡳ࠭ࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠭ࡨࡰࡸࡤࡹࡩࡻࡧࡢࡨ࡮ࡩࡴࠡ࠿ࠣ࡟ࡢ࠲࡛࡞࠮ࡾࢁࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡺࡸ࡬ࡠࡧࡱࡧࡴࡪࡥࡥࡡࡩࡱࡹࡥࡳࡵࡴࡨࡥࡲࡥ࡭ࡢࡲࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫࡟ࡧ࡯ࡷࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡬ࡪࠥࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡦ࡮ࡶࡢࡰ࡮ࡹࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡤࡲࡩࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠥࡂࡡࠧࠨ࡟࠽ࠎࠎࠏࠉࡧ࡯ࡷࡣࡱ࡯ࡳࡵࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࠊࡨࡰࡸࡤ࡯ࡴࡢࡩࡶࠤࡂࠦࡦ࡮ࡶࡢࡰ࡮ࡹࡴ࠯ࡵࡳࡰ࡮ࡺࠨࠨ࠮ࠪ࠭ࠏࠏࠉࠊࡨࡲࡶࠥ࡯ࡴࡦ࡯ࠣ࡭ࡳࠦࡦ࡮ࡶࡢ࡭ࡹࡧࡧࡴ࠼ࠍࠍࠎࠏࠉࡪࡶࡤ࡫࠱ࡹࡩࡻࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪ࠳ࠬ࠯ࠊࠊࠋࠌࠍ࡫ࡳࡴࡠࡵ࡬ࡾࡪࡥࡤࡪࡥࡷ࡟࡮ࡺࡡࡨ࡟ࠣࡁࠥࡹࡩࡻࡧࠍࠍ࡫ࡵࡲࠡࡤ࡯ࡳࡨࡱࠠࡪࡰࠣࡦࡱࡵࡣ࡬ࡵ࠽ࠎࠎࠏࡩࡧࠢࡱࡳࡹࠦࡢ࡭ࡱࡦ࡯࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࡰ࡮ࡴࡥࡴࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡷࡵࡲࡩࡵࠪࠪ࠰ࠬ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰࡨࠤ࡮ࡴࠠ࡭࡫ࡱࡩࡸࡀࠊࠊࠋࠌࠧࡽࡨ࡭ࡤ࠰࡯ࡳ࡬࠮ࠧ࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ࠯ࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠎࠎࠏࠉࠤࡺࡥࡱࡨ࠴࡬ࡰࡩࠫࡰ࡮ࡴࡥ࠭࡮ࡨࡺࡪࡲ࠽ࡹࡤࡰࡧ࠳ࡒࡏࡈࡐࡒࡘࡎࡉࡅࠪࠌࠌࠍࠎࡲࡩ࡯ࡧࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮࡬ࡪࡰࡨ࠭ࠏࠏࠉࠊࡦ࡬ࡧࡹࠦ࠽ࠡࡽࢀࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡ࡮࡬ࡲࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࠦࠧࠩࠬࠎࠎࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋ࡮ࡩࡾ࠲ࡶࡢ࡮ࡸࡩࠥࡃࠠࡪࡶࡨࡱ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡃࠧ࠭࠳ࠬࠎࠎࠏࠉࠊࡦ࡬ࡧࡹࡡ࡫ࡦࡻࡠࠤࡂࠦࡶࡢ࡮ࡸࡩࠏࠏࠉࠊ࡫ࡩࠤࠬࡹࡩࡻࡧࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩࠡࡣࡱࡨࠥࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࠤ࡮ࡴࠠ࡭࡫ࡶࡸ࠭࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠊࠊࠋࠌࠍࡩ࡯ࡣࡵ࡝ࠪࡷ࡮ࢀࡥࠨ࡟ࠣࡁࠥ࡬࡭ࡵࡡࡶ࡭ࡿ࡫࡟ࡥ࡫ࡦࡸࡠࡪࡩࡤࡶ࡞ࠫ࡮ࡺࡡࡨࠩࡠࡡࠏࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠱࠯ࡣࡳࡴࡪࡴࡤࠩࡦ࡬ࡧࡹ࠯ࠊࠊࡤ࡯ࡳࡨࡱࡳ࠭ࡵࡷࡶࡪࡧ࡭ࡴࡡࡷࡽࡵ࡫࠲ࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡩࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠦࡢ࡭ࡱࡦ࡯ࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠩࠋࠋࡩࡳࡷࠦࡢ࡭ࡱࡦ࡯ࠥ࡯࡮ࠡࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥࡨ࡬ࡰࡥ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠦࠧࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤࡧࡲ࡯ࡤ࡭࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡃࠢࠨ࠮ࠪࡁࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠥࠦࠬ࠲ࠧࠣࠩࠬࠎࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡣ࡮ࡲࡧࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠼ࡷࡶࡺ࡫ࠧ࠭ࠩ࠽ࡘࡷࡻࡥࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡀࡦࡢ࡮ࡶࡩࠬ࠲ࠧ࠻ࡈࡤࡰࡸ࡫ࠧࠪࠌࠌࠍ࡮࡬ࠠࠨ࡝ࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡧࡲ࡯ࡤ࡭࠽ࠤࡧࡲ࡯ࡤ࡭ࠣࡁ࡛ࠥ࠭ࠨ࠭ࡥࡰࡴࡩ࡫ࠬࠩࡠࠫࠏࠏࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡇ࡙ࡅࡑ࠮ࠧ࡭࡫ࡶࡸࠬ࠲ࡢ࡭ࡱࡦ࡯࠮ࠐࠉࠊࡨࡲࡶࠥࡪࡩࡤࡶࠣ࡭ࡳࠦࡢ࡭ࡱࡦ࡯࠿ࠐࠉࠊࠋࡧ࡭ࡨࡺ࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠡ࠿ࠣࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡩࡵࡣࡪࠫࡢ࠯ࠊࠊࠋࠌࡨ࡮ࡩࡴ࡜ࠩࡷࡽࡵ࡫ࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡱ࡮ࡳࡥࡕࡻࡳࡩࠬࡣ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡀࠫ࠱࠭࠽ࠣࠩࠬ࠯ࠬࠨࠧࠋࠋࠌࠍ࡮࡬ࠠࠨࡨࡳࡷࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡦࡱࡵࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡪࡵࡹࠧ࡞ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡡࡶࡦ࡬ࡳࡤࡹࡡ࡮ࡲ࡯ࡩࡤࡸࡡࡵࡧࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬࡣࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨࠢ࡬ࡲࠥࡲࡩࡴࡶࠫࡨ࡮ࡩࡴ࠯࡭ࡨࡽࡸ࠮ࠩࠪ࠼ࠣࡨ࡮ࡩࡴ࡜ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡡࠥࡃࠠࡴࡶࡵࠬࡩ࡯ࡣࡵ࡝ࠪࡥࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪࡡ࠮ࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡷࡪࡦࡷ࡬ࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡳࡪࡼࡨࠫࡢࠦ࠽ࠡࡵࡷࡶ࠭ࡪࡩࡤࡶ࡞ࠫࡼ࡯ࡤࡵࡪࠪࡡ࠮࠱ࠧࡹࠩ࠮ࡷࡹࡸࠨࡥ࡫ࡦࡸࡠ࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭࡝ࠪࠌࠌࠍࠎ࡯ࡦࠡࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯࡫ࡷࠫࡢࠦ࠽ࠡࡦ࡬ࡧࡹࡡࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪࡡࡠ࠭ࡳࡵࡣࡵࡸࠬࡣࠫࠨ࠯ࠪ࠯ࡩ࡯ࡣࡵ࡝ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭࡝࡜ࠩࡨࡲࡩ࠭࡝ࠋࠋࠌࠍ࡮࡬ࠠࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡩ࡯ࡦࡨࡼࠬࡣࠠ࠾ࠢࡧ࡭ࡨࡺ࡛ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬࡣ࡛ࠨࡵࡷࡥࡷࡺࠧ࡞࠭ࠪ࠱ࠬ࠱ࡤࡪࡥࡷ࡟ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩࡠ࡟ࠬ࡫࡮ࡥࠩࡠࠎࠎࠏࠉࡪࡨࠣࠫࡦࡼࡥࡳࡣࡪࡩࡇ࡯ࡴࡳࡣࡷࡩࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠠࡥ࡫ࡦࡸࡠ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ࡞ࠢࡀࠤࡩ࡯ࡣࡵ࡝ࠪࡥࡻ࡫ࡲࡢࡩࡨࡆ࡮ࡺࡲࡢࡶࡨࠫࡢࠐࠉࠊࠋ࡬ࡪࠥ࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧࠡ࡫ࡱࠤࡱ࡯ࡳࡵࠪࡧ࡭ࡨࡺ࠮࡬ࡧࡼࡷ࠭࠯ࠩࠡࡣࡱࡨࠥࡪࡩࡤࡶ࡞ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬࡣ࠾࠲࠳࠴࠶࠷࠸࠳࠴࠵࠽ࠤࡩ࡫࡬ࠡࡦ࡬ࡧࡹࡡࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ࡟ࠍࠍࠎࠏࡩࡧࠢࠪࡷ࡮࡭࡮ࡢࡶࡸࡶࡪࡉࡩࡱࡪࡨࡶࠬࠦࡩ࡯ࠢ࡯࡭ࡸࡺࠨࡥ࡫ࡦࡸ࠳ࡱࡥࡺࡵࠫ࠭࠮ࡀࠊࠊࠋࠌࠍࡨ࡯ࡰࡩࡧࡵࠤࡂࠦࡤࡪࡥࡷ࡟ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ࡞࠰ࡶࡴࡱ࡯ࡴࠩࠩࠩࠫ࠮ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࡶࡨࡱࠥ࡯࡮ࠡࡥ࡬ࡴ࡭࡫ࡲ࠻ࠌࠌࠍࠎࠏࠉ࡬ࡧࡼ࠰ࡻࡧ࡬ࡶࡧࠣࡁࠥ࡯ࡴࡦ࡯࠱ࡷࡵࡲࡩࡵࠪࠪࡁࠬ࠲࠱ࠪࠌࠌࠍࠎࠏࠉࡥ࡫ࡦࡸࡠࡱࡥࡺ࡟ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡶࡢ࡮ࡸࡩ࠮ࠐࠉࠊࠋࠦ࡭࡫ࠦࠧࡶࡴ࡯ࠫࠥ࡯࡮ࠡ࡮࡬ࡷࡹ࠮ࡤࡪࡥࡷ࠲ࡰ࡫ࡹࡴࠪࠬ࠭࠿ࠦࡤࡪࡥࡷ࡟ࠬࡻࡲ࡭ࠩࡠࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸࡠ࠭ࡵࡳ࡮ࠪࡡ࠮ࠐࠉࠊࠋࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠰ࡤࡴࡵ࡫࡮ࡥࠪࡧ࡭ࡨࡺࠩࠋࠋࡸࡶࡱࡥ࡬ࡪࡵࡷ࠰ࡸࡺࡲࡦࡣࡰࡷ࠵࠲ࡳࡵࡴࡨࡥࡲࡹ࠱࠭ࡵࡷࡶࡪࡧ࡭ࡴ࠴ࠣࡁࠥࡡ࡝࠭࡝ࡠ࠰ࡠࡣࠬ࡜࡟ࠍࠍ࡮࡬ࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠠࡢࡰࡧࠤࡸࡺࡲࡦࡣࡰࡷࡤࡺࡹࡱࡧ࠵࠾ࠏࠏࠉࡧࡱࡵࠤࡩ࡯ࡣࡵ࠳ࠣ࡭ࡳࠦࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡻࡳࡩ࠶ࡀࠊࠊࠋࠌࡹࡷࡲ࠱ࠡ࠿ࠣࡨ࡮ࡩࡴ࠲࡝ࠪࡹࡷࡲࠧ࡞࡝࠽࠷࠵࠶࡝ࠋࠋࠌࠍࠨࡻࡲ࡭࠳ࠣࡁ࡛ࠥࡎࡒࡗࡒࡘࡊ࠮ࡕࡏࡓࡘࡓ࡙ࡋࠨࡥ࡫ࡦࡸ࠶ࡡࠧࡶࡴ࡯ࠫࡢ࠯ࠩ࡜࠼࠶࠴࠵ࡣࠊࠊࠋࠌࡪࡴࡸࠠࡥ࡫ࡦࡸ࠷ࠦࡩ࡯ࠢࡶࡸࡷ࡫ࡡ࡮ࡵࡢࡸࡾࡶࡥ࠳࠼ࠍࠍࠎࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡥ࡫ࡦࡸ࠷ࡡࠧࡶࡴ࡯ࠫࡢࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠋࠦࡹࡷࡲ࠲ࠡ࠿࡙ࠣࡓࡗࡕࡐࡖࡈ࡚ࠬࡔࡑࡖࡑࡗࡉ࠭ࡪࡩࡤࡶ࠵࡟ࠬࡻࡲ࡭ࠩࡠ࠭࠮ࡡ࠺࠴࠲࠳ࡡࠏࠏࠉࠊࠋ࡬ࡪࠥࡻࡲ࡭࠳ࡀࡁࡺࡸ࡬࠳ࠢࡤࡲࡩࠦࡵࡳ࡮࠴ࠤࡳࡵࡴࠡ࡫ࡱࠤࡺࡸ࡬ࡠ࡮࡬ࡷࡹࡀࠊࠊࠋࠌࠍࠎࡻࡲ࡭ࡡ࡯࡭ࡸࡺ࠮ࡢࡲࡳࡩࡳࡪࠨࡶࡴ࡯࠵࠮ࠐࠉࠊࠋࠌࠍࡩ࡯ࡣࡵ࠳࠱ࡹࡵࡪࡡࡵࡧࠫࡨ࡮ࡩࡴ࠳ࠫࠍࠍࠎࠏࠉࠊࡵࡷࡶࡪࡧ࡭ࡴ࠲࠱ࡥࡵࡶࡥ࡯ࡦࠫࡨ࡮ࡩࡴ࠲ࠫࠍࠍࡪࡲࡳࡦ࠼ࠣࡷࡹࡸࡥࡢ࡯ࡶ࠴ࠥࡃࠠࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠷ࠫࡴࡶࡵࡩࡦࡳࡳࡠࡶࡼࡴࡪ࠸ࠊࠊࠤࠥࠦ䬛")
	# l1l1l1lll11l_l1_ json data
	# l1l1111l1_l1_ url l1llll1l11l1_l1_:    https://l1l1l1l111l_l1_.l1ll1l1l1_l1_.com/l1l1111l1_l1_/l1lll1l1ll11_l1_
	# list of l1llll1l1l1l_l1_ & l1l1l1l111ll_l1_
	# https://github.com/l1l1ll1lllll_l1_-l1ll11l11lll_l1_/l1l1ll1lllll_l1_-l1ll11l11lll_l1_/blob/master/l1llll11l111_l1_/l1ll1l1l111l_l1_/l1ll1l1l1_l1_.py
	# all the below l1l1llllll1l_l1_ were l1ll1lll1l1l_l1_ using:	https://l1l1l1l111l_l1_.l1ll1l1l1_l1_.com/l1llllll1ll1_l1_/l1l1llll11ll_l1_/l1l1lllll1ll_l1_?l1l1l1111lll_l1_=l1l1l1l11l1l_l1_	&	l1lll1lllll1_l1_ = l1lll1l1ll11_l1_
	# 3 l11lll11ll1_l1_:	13KB:	l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䬜"): l11l1l_l1_ (u"ࠧࡊࡑࡖࡣࡈࡘࡅࡂࡖࡒࡖࠬ䬝"),l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䬞"): l11l1l_l1_ (u"ࠩ࠵࠶࠳࠹࠳࠯࠳࠳࠵ࠬ䬟")
	# 7 l11lll11ll1_l1_		44KB:	l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䬠"): l11l1l_l1_ (u"ࠫࡎࡕࡓࡠࡏࡈࡗࡘࡇࡇࡆࡕࡢࡉ࡝࡚ࡅࡏࡕࡌࡓࡓ࠭䬡"),l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䬢"): l11l1l_l1_ (u"࠭࠱࠸࠰࠶࠷࠳࠸ࠧ䬣")
	# 7 l11lll11ll1_l1_		58KB:	l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䬤"): l11l1l_l1_ (u"ࠨࡋࡒࡗࠬ䬥"),l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䬦"): l11l1l_l1_ (u"ࠪ࠵࠼࠴࠳࠴࠰࠵ࠫ䬧")
	# 9 l11lll11ll1_l1_		24KB:	l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䬨"): l11l1l_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡃࡓࡇࡄࡘࡔࡘࠧ䬩"),l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䬪"): l11l1l_l1_ (u"ࠧ࠳࠴࠱࠷࠵࠴࠱࠱࠲ࠪ䬫")
	# no json file:		21 l11lll11ll1_l1_	95KB:	l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䬬"): l11l1l_l1_ (u"࡚ࠩࡉࡇࡥࡃࡓࡇࡄࡘࡔࡘࠧ䬭"),l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䬮"): l11l1l_l1_ (u"ࠫ࠶࠴࠲࠱࠴࠵࠴࠼࠸࠶࠯࠲࠳࠲࠵࠶ࠧ䬯")
	# no json file:		21 l11lll11ll1_l1_	121KB:	l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䬰"): l11l1l_l1_ (u"࠭ࡗࡆࡄࠪ䬱"),l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䬲"): l11l1l_l1_ (u"ࠨ࠴࠱࠶࠵࠸࠲࠱࠺࠳࠵࠳࠶࠰࠯࠲࠳ࠫ䬳")
	# no json file: 	26 l11lll11ll1_l1_	115KB:	l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䬴"): l11l1l_l1_ (u"ࠪࡑ࡜ࡋࡂࠨ䬵"),l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䬶"): l11l1l_l1_ (u"ࠬ࠸࠮࠳࠲࠵࠶࠵࠾࠰࠲࠰࠳࠴࠳࠶࠰ࠨ䬷")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠪ䬸"): l11l1l_l1_ (u"ࠧࡂࡐࡇࡖࡔࡏࡄࠨ䬹"),l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䬺"): l11l1l_l1_ (u"ࠩ࠴࠻࠳࠹࠱࠯࠵࠸ࠫ䬻")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶࡑࡥࡲ࡫ࠧ䬼"): l11l1l_l1_ (u"ࠫ࡜ࡋࡂࡠࡔࡈࡑࡎ࡞ࠧ䬽"),l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸ࡛࡫ࡲࡴ࡫ࡲࡲࠬ䬾"): l11l1l_l1_ (u"࠭࠱࠯࠴࠳࠶࠷࠶࠷࠳࠹࠱࠴࠶࠴࠰࠱ࠩ䬿")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡎࡢ࡯ࡨࠫ䭀"): l11l1l_l1_ (u"ࠨ࡙ࡈࡆࡤࡋࡍࡃࡇࡇࡈࡊࡊ࡟ࡑࡎࡄ࡝ࡊࡘࠧ䭁"),l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡘࡨࡶࡸ࡯࡯࡯ࠩ䭂"): l11l1l_l1_ (u"ࠪ࠵࠳࠸࠰࠳࠴࠳࠻࠸࠷࠮࠱࠲࠱࠴࠵࠭䭃")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠨ䭄"): l11l1l_l1_ (u"ࠬࡇࡎࡅࡔࡒࡍࡉࡥࡅࡎࡄࡈࡈࡉࡋࡄࡠࡒࡏࡅ࡞ࡋࡒࠨ䭅"),l11l1l_l1_ (u"࠭ࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳ࠭䭆"): l11l1l_l1_ (u"ࠧ࠲࠹࠱࠷࠶࠴࠳࠶ࠩ䭇")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠬ䭈"): l11l1l_l1_ (u"ࠩࡄࡒࡉࡘࡏࡊࡆࡢࡑ࡚࡙ࡉࡄࠩ䭉"),l11l1l_l1_ (u"ࠪࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠪ䭊"): l11l1l_l1_ (u"ࠫ࠺࠴࠱࠷࠰࠸࠵ࠬ䭋")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"ࠬࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠩ䭌"): l11l1l_l1_ (u"࠭ࡔࡗࡊࡗࡑࡑ࠻࡟ࡔࡋࡐࡔࡑ࡟࡟ࡆࡏࡅࡉࡉࡊࡅࡅࡡࡓࡐࡆ࡟ࡅࡓࠩ䭍"),l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠧ䭎"): l11l1l_l1_ (u"ࠨ࠴࠱࠴ࠬ䭏")
	# l111l1ll111_l1_:	l11l1l_l1_ (u"ࠩࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪ࠭䭐"): l11l1l_l1_ (u"ࠪࡍࡔ࡙࡟ࡎࡗࡖࡍࡈ࠭䭑"),l11l1l_l1_ (u"ࠫࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠫ䭒"): l11l1l_l1_ (u"ࠬ࠻࠮࠳࠳ࠪ䭓")
	# l111l1l_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䭔")][0]+l11l1l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡰ࡭ࡣࡼࡩࡷࡅࡰࡳࡧࡷࡸࡾࡖࡲࡪࡰࡷࡁࡹࡸࡵࡦࠩ䭕")  # l1l1l1l11l1l_l1_ l1ll1l1111l1_l1_ l1l1l1l11l11_l1_ and l1l1lll11lll_l1_ l1ll11l1ll1l_l1_ l1l1l11l1l_l1_ l1l1ll11ll1l_l1_ file size
	#l11l1llll_l1_ = l11l1l_l1_ (u"ࠨࡽࠪ䭖")l1l1l1111ll1_l1_ (u"ࠩ࠽࡭ࡩ࠲ࠧ䭗")l1ll1l111lll_l1_ (u"ࠪ࠾ࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࡼࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠣࡃࡑࡈࡗࡕࡉࡅࠤ࠯ࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠨ࠱࠸࠰࠶࠵࠳࠹࠵ࠣࡿࢀࢁࠬ䭘")
	#response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ䭙"),l111l1l_l1_,l11l1llll_l1_,l11l1l_l1_ (u"ࠬ࠭䭚"),l11l1l_l1_ (u"࠭ࠧ䭛"),l11l1l_l1_ (u"ࠧࠨ䭜"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩ䭝"))
	#html = response.content
	for l11l1l1ll1_l1_ in range(5):
		#l1llll1l_l1_(l11l1l_l1_ (u"ࠩส่๊ำว้ๆฬࠤึ่ๅ࠻ࠢࠣࠫ䭞")+str(l11l1l1ll1_l1_+1),l11l1l_l1_ (u"ࠪࠫ䭟"))
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䭠"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭䭡"),l11l1l_l1_ (u"࠭ࠧ䭢"),l11l1l_l1_ (u"ࠧࠨ䭣"),l11l1l_l1_ (u"ࠨࠩ䭤"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ䭥"))
		html = response.content
		if l11l1l_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ䭦") in html: break
		time.sleep(2)
	#WRITE_THIS(l11l1l_l1_ (u"ࠫࠬ䭧"),html)
	l11ll1l111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡼࡡࡳࠢࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡕࡲࡡࡺࡧࡵࡖࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࠩ࠰࠭ࡃ࠮ࡁ࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ䭨"),html,re.DOTALL)
	if l11ll1l111_l1_: l11ll1l111_l1_ = l11ll1l111_l1_[0]
	else: l11ll1l111_l1_ = html
	l11ll1l111_l1_ = l11ll1l111_l1_.replace(l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠴࠷࠼ࠧ䭩"),l11l1l_l1_ (u"ࠧࠧࠩ䭪"))
	l1l1ll1ll1ll_l1_ = EVAL(l11l1l_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭䭫"),l11ll1l111_l1_)
	#WRITE_THIS(l11l1l_l1_ (u"ࠩࠪ䭬"),str(l1l1ll1ll1ll_l1_))
	# l1l1l1lll11l_l1_ l1lll1ll111l_l1_ & l11111l1l1l_l1_
	# l1ll1l1l1_l1_ l1lll11lll11_l1_ l1llll1_l1_ l11lll111_l1_ l11l1l_l1_ (u"ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠬ䭭") to l1111llll1_l1_ on l1llll1l1lll_l1_
	l1ll1ll1_l1_,l1lll1_l1_ = [l11l1l_l1_ (u"ࠫอี่็ࠢอีั๋ษࠡ์๋ฮ๏๎ศࠨ䭮")],[l11l1l_l1_ (u"ࠬ࠭䭯")]
	try:
		l1lll1ll111l_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨ䭰")][l11l1l_l1_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䭱")][l11l1l_l1_ (u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨ䭲")]
		for l1ll1llllll1_l1_ in l1lll1ll111l_l1_:
			l1llll1_l1_ = l1ll1llllll1_l1_[l11l1l_l1_ (u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪ䭳")]
			try: title = l1ll1llllll1_l1_[l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ䭴")][l11l1l_l1_ (u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ䭵")]
			except: title = l1ll1llllll1_l1_[l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ䭶")][l11l1l_l1_ (u"࠭ࡲࡶࡰࡶࠫ䭷")][0][l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࠬ䭸")]
			l1lll1_l1_.append(l1llll1_l1_)
			l1ll1ll1_l1_.append(title)
	except: pass
	if len(l1ll1ll1_l1_)>1:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠศๆ่๊ฬูศส࠼ࠪ䭹"), l1ll1ll1_l1_)
		if l1l_l1_==-1: return l11l1l_l1_ (u"ࠩࡈ࡜ࡎ࡚ࠧ䭺"),[],[]
		elif l1l_l1_!=0:
			l1llll1_l1_ = l1lll1_l1_[l1l_l1_]+l11l1l_l1_ (u"ࠪࠪࠬ䭻")
			l1ll111l1ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠫ࠮ࡦ࡮ࡶࡀ࠲࠯ࡅࠩࠧࠩ䭼"),l1llll1_l1_)
			if l1ll111l1ll1_l1_: l1llll1_l1_ = l1llll1_l1_.replace(l1ll111l1ll1_l1_[0],l11l1l_l1_ (u"ࠬ࡬࡭ࡵ࠿ࡹࡸࡹ࠭䭽"))
			else: l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧ䭾")
			l1ll1l1ll111_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠩ䭿"))
	formats,l11111l11ll_l1_,l1llll11l1l1_l1_,l1llll11l1ll_l1_,l1llll11l11l_l1_ = [],[],[],[],[]
	# l1l1l1lll11l_l1_ l1ll1ll11111_l1_ l11lll11ll1_l1_
	try: l1l1l1l11111_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨ䮀")][l11l1l_l1_ (u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫ䮁")]
	except: pass
	# l1l1l1lll11l_l1_ l1lll11l1lll_l1_ stream
	try: l1111l11111_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪ䮂")][l11l1l_l1_ (u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠬ䮃")]
	except: pass
	# l1l1l1lll11l_l1_ l1ll11ll1l_l1_ l11111l1_l1_ l11lll11ll1_l1_
	try: formats = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬ䮄")][l11l1l_l1_ (u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ䮅")]
	except: pass
	# l1l1l1lll11l_l1_ l1ll11ll1l_l1_ l11111ll1l1_l1_ l11lll11ll1_l1_
	try: l11111l11ll_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ䮆")][l11l1l_l1_ (u"ࠨࡣࡧࡥࡵࡺࡩࡷࡧࡉࡳࡷࡳࡡࡵࡵࠪ䮇")]
	except: pass
	l1lll11l11ll_l1_ = formats+l11111l11ll_l1_
	for dict in l1lll11l11ll_l1_:
		#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ䮈"),str(dict))
		if l11l1l_l1_ (u"ࠪ࡭ࡹࡧࡧࠨ䮉") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䮊")] = str(dict[l11l1l_l1_ (u"ࠬ࡯ࡴࡢࡩࠪ䮋")])
		if l11l1l_l1_ (u"࠭ࡦࡱࡵࠪ䮌") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠧࡧࡲࡶࠫ䮍")] = str(dict[l11l1l_l1_ (u"ࠨࡨࡳࡷࠬ䮎")])
		if l11l1l_l1_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ䮏") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠪࡸࡾࡶࡥࠨ䮐")] = dict[l11l1l_l1_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭䮑")]		#.replace(l11l1l_l1_ (u"ࠬࡃࠧ䮒"),l11l1l_l1_ (u"࠭࠽ࠨ䮓"))+l11l1l_l1_ (u"ࠧࠣࠩ䮔")
		if l11l1l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪ䮕") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭䮖")] = str(dict[l11l1l_l1_ (u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬ䮗")])
		if l11l1l_l1_ (u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ䮘") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䮙")] = str(dict[l11l1l_l1_ (u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䮚")])
		if l11l1l_l1_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭䮛") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠨࡵ࡬ࡾࡪ࠭䮜")] = str(dict[l11l1l_l1_ (u"ࠩࡺ࡭ࡩࡺࡨࠨ䮝")])+l11l1l_l1_ (u"ࠪࡼࠬ䮞")+str(dict[l11l1l_l1_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫ䮟")])
		if l11l1l_l1_ (u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ䮠") in list(dict.keys()): dict[l11l1l_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䮡")] = dict[l11l1l_l1_ (u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ䮢")][l11l1l_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ䮣")]+l11l1l_l1_ (u"ࠩ࠰ࠫ䮤")+dict[l11l1l_l1_ (u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭䮥")][l11l1l_l1_ (u"ࠫࡪࡴࡤࠨ䮦")]
		if l11l1l_l1_ (u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ䮧") in list(dict.keys()): dict[l11l1l_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࠬ䮨")] = dict[l11l1l_l1_ (u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ䮩")][l11l1l_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ䮪")]+l11l1l_l1_ (u"ࠩ࠰ࠫ䮫")+dict[l11l1l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧ䮬")][l11l1l_l1_ (u"ࠫࡪࡴࡤࠨ䮭")]
		if l11l1l_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭䮮") in list(dict.keys()): dict[l11l1l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䮯")] = dict[l11l1l_l1_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ䮰")]
		if l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䮱") in list(dict.keys()) and int(dict[l11l1l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䮲")])>111222333: del dict[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䮳")]
		if l11l1l_l1_ (u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭䮴") in list(dict.keys()):
			cipher = dict[l11l1l_l1_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ䮵")].split(l11l1l_l1_ (u"࠭ࠦࠨ䮶"))
			for item in cipher:
				key,value = item.split(l11l1l_l1_ (u"ࠧ࠾ࠩ䮷"),1)
				dict[key] = l1llll_l1_(value)
		if l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䮸") in list(dict.keys()): dict[l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䮹")] = l1llll_l1_(dict[l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䮺")])
		#if l11l1l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࡁࠬ䮻") in dict[l11l1l_l1_ (u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧ䮼")]: dict[l11l1l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䮽")] = dict[l11l1l_l1_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ䮾")].split(l11l1l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳ࠾࡞ࠥࠫ䮿"))[1].strip(l11l1l_l1_ (u"ࠩ࡟ࠦࠬ䯀"))
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ䯁"),dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦࠩ䯂")]+l11l1l_l1_ (u"ࠬࠦࠠࠡ࠰ࠣࠤࠥ࠭䯃")+dict[l11l1l_l1_ (u"࠭ࡴࡺࡲࡨࠫ䯄")])
		l1llll11l1l1_l1_.append(dict)
	l11l1l111_l1_ = l11l1l_l1_ (u"ࠧࠨ䯅")
	if l11l1l_l1_ (u"ࠨࡵࡳࡁࡸ࡯ࡧࠨ䯆") in l11ll1l111_l1_:
		#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡼࡸࡸ࠵ࡪࡴࡤ࡬ࡲ࠴ࡶ࡬ࡢࡻࡨࡶࡤ࠴ࠪࡀࠫࠥࠫ䯇"),html,re.DOTALL)
		# l1llll1l11l1_l1_:	/s/l1l1lllll1ll_l1_/6dde7fb4/l1l1ll11l1ll_l1_.l1ll1l111111_l1_/l1ll1ll11l11_l1_/base.l1l1ll111lll_l1_
		#l1lllll11ll1_l1_ = [l11l1l_l1_ (u"ࠪ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵ࡤ࠹࠹ࡧ࠹࠽࠷ࡦ࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࡫ࡤࡷ࠳ࡼࡦ࡭ࡵࡨࡸ࠴࡫࡮ࡠࡗࡖ࠳ࡧࡧࡳࡦ࠰࡭ࡷࠬ䯈")]
		l1lllll11ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠳ࡸ࠵ࡰ࡭ࡣࡼࡩࡷ࠵࡜ࡸࠬࡂ࠳ࡵࡲࡡࡺࡧࡵࡣ࡮ࡧࡳ࠯ࡸࡩࡰࡸ࡫ࡴ࠰ࡧࡱࡣ࠳࠴࠯ࡣࡣࡶࡩ࠳ࡰࡳࠪࠤࠪ䯉"),html,re.DOTALL)
		if l1lllll11ll1_l1_:
			l1lllll11ll1_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭䯊")][0]+l1lllll11ll1_l1_[0]
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䯋"),l1lllll11ll1_l1_,l11l1l_l1_ (u"ࠧࠨ䯌"),l11l1l_l1_ (u"ࠨࠩ䯍"),l11l1l_l1_ (u"ࠩࠪ䯎"),l11l1l_l1_ (u"ࠪࠫ䯏"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬ䯐"))
			l11l1l111_l1_ = response.content
			import youtube_signature.cipher,youtube_signature.json_script_engine
			cipher = youtube_signature.cipher.Cipher()
			cipher._object_cache = {}
			l1l1l1lllll1_l1_ = cipher._load_javascript(l11l1l111_l1_)
			l1l1l11lllll_l1_ = EVAL(l11l1l_l1_ (u"ࠬࡹࡴࡳࠩ䯑"),str(l1l1l1lllll1_l1_))
			l1l1llll1ll1_l1_ = youtube_signature.json_script_engine.JsonScriptEngine(l1l1l11lllll_l1_)
	for dict in l1llll11l1l1_l1_:
		url = dict[l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䯒")]
		if l11l1l_l1_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡀࠫ䯓") in url or url.count(l11l1l_l1_ (u"ࠨࡵ࡬࡫ࡂ࠭䯔"))>1:
			l1llll11l1ll_l1_.append(dict)
		elif l11l1l111_l1_ and l11l1l_l1_ (u"ࠩࡶࠫ䯕") in list(dict.keys()) and l11l1l_l1_ (u"ࠪࡷࡵ࠭䯖") in list(dict.keys()):
			l1ll1lllll11_l1_ = l1l1llll1ll1_l1_.execute(dict[l11l1l_l1_ (u"ࠫࡸ࠭䯗")])
			if l1ll1lllll11_l1_!=dict[l11l1l_l1_ (u"ࠬࡹࠧ䯘")]:
				dict[l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䯙")] = url+l11l1l_l1_ (u"ࠧࠧࠩ䯚")+dict[l11l1l_l1_ (u"ࠨࡵࡳࠫ䯛")]+l11l1l_l1_ (u"ࠩࡀࠫ䯜")+l1ll1lllll11_l1_
				l1llll11l1ll_l1_.append(dict)
	for dict in l1llll11l1ll_l1_:
		l11ll11_l1_,l1l1ll1lll1l_l1_,l1ll111ll11l_l1_,l11ll111l_l1_,codecs,l1lllllll111_l1_ = l11l1l_l1_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ䯝"),l11l1l_l1_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ䯞"),l11l1l_l1_ (u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭䯟"),l11l1l_l1_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠧ䯠"),l11l1l_l1_ (u"ࠧࠨ䯡"),l11l1l_l1_ (u"ࠨ࠲ࠪ䯢")
		try:
			l1llll11ll11_l1_ = dict[l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ䯣")]
			l1llll11ll11_l1_ = l1llll11ll11_l1_.replace(l11l1l_l1_ (u"ࠪ࠯ࠬ䯤"),l11l1l_l1_ (u"ࠫࠬ䯥"))
			items = re.findall(l11l1l_l1_ (u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䯦"),l1llll11ll11_l1_,re.DOTALL)
			l11ll111l_l1_,l11ll11_l1_,codecs = items[0]
			l111111l11l_l1_ = codecs.split(l11l1l_l1_ (u"࠭ࠬࠨ䯧"))
			l1l1ll1lll1l_l1_ = l11l1l_l1_ (u"ࠧࠨ䯨")
			for item in l111111l11l_l1_: l1l1ll1lll1l_l1_ += item.split(l11l1l_l1_ (u"ࠨ࠰ࠪ䯩"))[0]+l11l1l_l1_ (u"ࠩ࠯ࠫ䯪")
			l1l1ll1lll1l_l1_ = l1l1ll1lll1l_l1_.strip(l11l1l_l1_ (u"ࠪ࠰ࠬ䯫"))
			if l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䯬") in list(dict.keys()): l1lllllll111_l1_ = str(float(dict[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䯭")]*10)//1024/10)+l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭䯮")
			else: l1lllllll111_l1_ = l11l1l_l1_ (u"ࠧࠨ䯯")
			if l11ll111l_l1_==l11l1l_l1_ (u"ࠨࡶࡨࡼࡹ࠭䯰"): continue
			elif l11l1l_l1_ (u"ࠩ࠯ࠫ䯱") in l1llll11ll11_l1_:
				l11ll111l_l1_ = l11l1l_l1_ (u"ࠪࡅ࠰࡜ࠧ䯲")
				l1ll111ll11l_l1_ = l11ll11_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠧ䯳")+l1lllllll111_l1_+dict[l11l1l_l1_ (u"ࠬࡹࡩࡻࡧࠪ䯴")].split(l11l1l_l1_ (u"࠭ࡸࠨ䯵"))[1]
			elif l11ll111l_l1_==l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䯶"):
				l11ll111l_l1_ = l11l1l_l1_ (u"ࠨࡘ࡬ࡨࡪࡵࠧ䯷")
				l1ll111ll11l_l1_ = l1lllllll111_l1_+dict[l11l1l_l1_ (u"ࠩࡶ࡭ࡿ࡫ࠧ䯸")].split(l11l1l_l1_ (u"ࠪࡼࠬ䯹"))[1]+l11l1l_l1_ (u"ࠫࠥࠦࠧ䯺")+dict[l11l1l_l1_ (u"ࠬ࡬ࡰࡴࠩ䯻")]+l11l1l_l1_ (u"࠭ࡦࡱࡵࠪ䯼")+l11l1l_l1_ (u"ࠧࠡࠢࠪ䯽")+l11ll11_l1_
			elif l11ll111l_l1_==l11l1l_l1_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ䯾"):
				l11ll111l_l1_ = l11l1l_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ䯿")
				l1ll111ll11l_l1_ = l1lllllll111_l1_+str(int(dict[l11l1l_l1_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ䰀")])/1000)+l11l1l_l1_ (u"ࠫࡰ࡮ࡺࠡࠢࠪ䰁")+dict[l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䰂")]+l11l1l_l1_ (u"࠭ࡣࡩࠩ䰃")+l11l1l_l1_ (u"ࠧࠡࠢࠪ䰄")+l11ll11_l1_
		except:
			l1ll1lllll1l_l1_ = traceback.format_exc()
			sys.stderr.write(l1ll1lllll1l_l1_)
		if l11l1l_l1_ (u"ࠨࡦࡸࡶࡂ࠭䰅") in dict[l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭䰆")]: l1l11l1ll_l1_ = round(0.5+float(dict[l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䰇")].split(l11l1l_l1_ (u"ࠫࡩࡻࡲ࠾ࠩ䰈"),1)[1].split(l11l1l_l1_ (u"ࠬࠬࠧ䰉"),1)[0]))
		elif l11l1l_l1_ (u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩ䰊") in list(dict.keys()): l1l11l1ll_l1_ = round(0.5+float(dict[l11l1l_l1_ (u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ䰋")])/1000)
		else: l1l11l1ll_l1_ = l11l1l_l1_ (u"ࠨ࠲ࠪ䰌")
		if l11l1l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䰍") not in list(dict.keys()): l1lllllll111_l1_ = dict[l11l1l_l1_ (u"ࠪࡷ࡮ࢀࡥࠨ䰎")].split(l11l1l_l1_ (u"ࠫࡽ࠭䰏"))[1]
		else: l1lllllll111_l1_ = dict[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䰐")]
		if l11l1l_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䰑") not in list(dict.keys()): dict[l11l1l_l1_ (u"ࠧࡪࡰ࡬ࡸࠬ䰒")] = l11l1l_l1_ (u"ࠨ࠲࠰࠴ࠬ䰓")
		dict[l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䰔")] = l11ll111l_l1_+l11l1l_l1_ (u"ࠪ࠾ࠥࠦࠧ䰕")+l1ll111ll11l_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠨࠨ䰖")+l1l1ll1lll1l_l1_+l11l1l_l1_ (u"ࠬ࠲ࠧ䰗")+dict[l11l1l_l1_ (u"࠭ࡩࡵࡣࡪࠫ䰘")]+l11l1l_l1_ (u"ࠧࠪࠩ䰙")
		dict[l11l1l_l1_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ䰚")] = l1ll111ll11l_l1_.split(l11l1l_l1_ (u"ࠩࠣࠤࠬ䰛"))[0].split(l11l1l_l1_ (u"ࠪ࡯ࡧࡶࡳࠨ䰜"))[0]
		dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䰝")] = l11ll111l_l1_
		dict[l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䰞")] = l11ll11_l1_
		dict[l11l1l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䰟")] = codecs
		dict[l11l1l_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ䰠")] = l1l11l1ll_l1_
		dict[l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䰡")] = l1lllllll111_l1_
		l1llll11l11l_l1_.append(dict)
	l1lll11l1111_l1_,l1lllll1l111_l1_,l11111ll1ll_l1_,l1ll1l11l11l_l1_,l1lll1lll11l_l1_ = [],[],[],[],[]
	l1ll11ll1l1l_l1_,l1llll1l1111_l1_,l1ll1111llll_l1_,l1111111ll1_l1_,l11111l1ll1_l1_ = [],[],[],[],[]
	if l1l1l1l11111_l1_:
		dict = {}
		dict[l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䰢")] = l11l1l_l1_ (u"ࠪࡅ࠰࡜ࠧ䰣")
		dict[l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䰤")] = l11l1l_l1_ (u"ࠬࡳࡰࡥࠩ䰥")
		dict[l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䰦")] = dict[l11l1l_l1_ (u"ࠧࡵࡻࡳࡩ࠷࠭䰧")]+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ䰨")+dict[l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䰩")]+l11l1l_l1_ (u"ࠪࠤࠥ࠭䰪")+l11l1l_l1_ (u"ࠫั๎ฯสࠢำ็๏ฯࠧ䰫")
		dict[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䰬")] = l1l1l1l11111_l1_
		dict[l11l1l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䰭")] = l11l1l_l1_ (u"ࠧ࠱ࠩ䰮") # for l11l11l111_l1_ l1l1l1l11111_l1_ any l1l111l11_l1_ will l1111l11ll1_l1_ l1l1lllll111_l1_ sort l1l1l1l11ll_l1_
		dict[l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䰯")] = l11l1l_l1_ (u"ࠩ࠼࠼࠼࠼࠵࠵࠵࠵࠵࠵࠭䰰") # 20
		l1llll11l11l_l1_.append(dict)
	if l1111l11111_l1_:
		l1l1ll1l11l1_l1_,l1llll1llll1_l1_ = l11l1ll1ll_l1_(l1111l11111_l1_)
		l1llllll1lll_l1_ = list(zip(l1l1ll1l11l1_l1_,l1llll1llll1_l1_))
		for title,l1llll1_l1_ in l1llllll1lll_l1_:
			dict = {}
			dict[l11l1l_l1_ (u"ࠪࡸࡾࡶࡥ࠳ࠩ䰱")] = l11l1l_l1_ (u"ࠫࡆ࠱ࡖࠨ䰲")
			dict[l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䰳")] = l11l1l_l1_ (u"࠭࡭࠴ࡷ࠻ࠫ䰴")
			dict[l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䰵")] = l1llll1_l1_
			#if l11l1l_l1_ (u"ࠨࡄ࡚࠾ࠥ࠭䰶") in title: dict[l11l1l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䰷")] = title.split(l11l1l_l1_ (u"ࠪࠤࠥ࠭䰸"))[1].split(l11l1l_l1_ (u"ࠫࡰࡨࡰࡴࠩ䰹"))[0]
			#if l11l1l_l1_ (u"ࠬࡘࡥࡴ࠼ࠣࠫ䰺") in title: dict[l11l1l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䰻")] = title.split(l11l1l_l1_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭䰼"))[1]
			# title = l11l1l_l1_ (u"ࠣ࠶࠵࠺࠼ࡱࡢࡱࡵࠣࠤ࠼࠸࠰ࠡࠢ࠱ࡱ࠸ࡻ࠸ࠣ䰽")
			if l11l1l_l1_ (u"ࠩ࡮ࡦࡵࡹࠧ䰾") in title: dict[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䰿")] = title.split(l11l1l_l1_ (u"ࠫࡰࡨࡰࡴࠩ䱀"))[0].rsplit(l11l1l_l1_ (u"ࠬࠦࠠࠨ䱁"))[-1]
			else: dict[l11l1l_l1_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ䱂")] = l11l1l_l1_ (u"ࠧ࠲࠲ࠪ䱃")
			if title.count(l11l1l_l1_ (u"ࠨࠢࠣࠫ䱄"))>1:
				l111ll11_l1_ = title.rsplit(l11l1l_l1_ (u"ࠩࠣࠤࠬ䱅"))[-3]
				if l111ll11_l1_.isdigit(): dict[l11l1l_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ䱆")] = l111ll11_l1_
				else: dict[l11l1l_l1_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ䱇")] = l11l1l_l1_ (u"ࠬ࠶࠰࠱࠲ࠪ䱈")
			#dict[l11l1l_l1_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ䱉")] = title
			if title==l11l1l_l1_ (u"ࠧ࠮࠳ࠪ䱊"): dict[l11l1l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䱋")] = dict[l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䱌")]+l11l1l_l1_ (u"ࠪ࠾ࠥࠦࠧ䱍")+dict[l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䱎")]+l11l1l_l1_ (u"ࠬࠦࠠࠨ䱏")+l11l1l_l1_ (u"࠭ฬ้ัฬࠤี้๊สࠩ䱐")
			else: dict[l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䱑")] = dict[l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ䱒")]+l11l1l_l1_ (u"ࠩ࠽ࠤࠥ࠭䱓")+dict[l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䱔")]+l11l1l_l1_ (u"ࠫࠥࠦࠧ䱕")+dict[l11l1l_l1_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭䱖")]+l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭䱗")+dict[l11l1l_l1_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ䱘")]
			l1llll11l11l_l1_.append(dict)
	l1llll11l11l_l1_ = sorted(l1llll11l11l_l1_,reverse=True,key=lambda key: float(key[l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䱙")]))
	if not l1llll11l11l_l1_:
		l1ll111l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡸࡹࡡࡨࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䱚"),html,re.DOTALL)
		l1ll111l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡴࡷࡥࡶࡪࡧࡳࡰࡰࠥ࠾ࡡࢁࠢࡳࡷࡱࡷࠧࡀ࡜࡜࡞ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䱛"),html,re.DOTALL)
		l1lll111l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࡾࠦࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䱜"),html,re.DOTALL)
		l1lll111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰ࡭ࡣࡼࡩࡷࡋࡲࡳࡱࡵࡑࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠧࡀ࡜ࡼࠤࡶࡹࡧࡸࡥࡢࡵࡲࡲࠧࡀࡻࠣࡵ࡬ࡱࡵࡲࡥࡕࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ䱝"),html,re.DOTALL)
		try: l1lll111ll1l_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ䱞")][l11l1l_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ䱟")][l11l1l_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ䱠")][l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ䱡")][l11l1l_l1_ (u"ࠪࡶࡺࡴࡳࠨ䱢")][0][l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ䱣")]
		except: l1lll111ll1l_l1_ = l11l1l_l1_ (u"ࠬ࠭䱤")
		try: l1lll111lll1_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ䱥")][l11l1l_l1_ (u"ࠧࡦࡴࡵࡳࡷ࡙ࡣࡳࡧࡨࡲࠬ䱦")][l11l1l_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡆ࡬ࡥࡱࡵࡧࡓࡧࡱࡨࡪࡸࡥࡳࠩ䱧")][l11l1l_l1_ (u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡏࡨࡷࡸࡧࡧࡦࡵࠪ䱨")][0][l11l1l_l1_ (u"ࠪࡶࡺࡴࡳࠨ䱩")][0][l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ䱪")]
		except: l1lll111lll1_l1_ = l11l1l_l1_ (u"ࠬ࠭䱫")
		try: l1l1llll1l1l_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࡥࡧ࡯࡬ࡪࡶࡼࡗࡹࡧࡴࡶࡵࠪ䱬")][l11l1l_l1_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ䱭")]
		except: l1l1llll1l1l_l1_ = l11l1l_l1_ (u"ࠨࠩ䱮")
		if l1ll111l11l_l1_ or l1ll111l1l1_l1_ or l1lll111l1ll_l1_ or l1lll111ll11_l1_ or l1lll111ll1l_l1_ or l1lll111lll1_l1_ or l1l1llll1l1l_l1_:
			if   l1ll111l11l_l1_: message = l1ll111l11l_l1_[0]
			elif l1ll111l1l1_l1_: message = l1ll111l1l1_l1_[0]
			elif l1lll111l1ll_l1_: message = l1lll111l1ll_l1_[0]
			elif l1lll111ll11_l1_: message = l1lll111ll11_l1_[0]
			elif l1lll111ll1l_l1_: message = l1lll111ll1l_l1_
			elif l1lll111lll1_l1_: message = l1lll111lll1_l1_
			elif l1l1llll1l1l_l1_: message = l1l1llll1l1l_l1_
			l1ll111l11l1_l1_ = message.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ䱯"),l11l1l_l1_ (u"ࠪࠫ䱰")).strip(l11l1l_l1_ (u"ࠫࠥ࠭䱱"))
			l1lll1l1l1ll_l1_ = l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝่าสࠤฬ๊แ๋ัํ์ࠥ็ุ๊่่่๊ࠢษ๊ࠡๅำࠥ๐ใ้่ࠣ฾๏ืࠠๆๆสส๊ࠦไษ฻ูࠤฬ๊ๅิฬัำ๊๐ๆࠡล๋ࠤ฿๐ัࠡ็อ์ๆืࠠศๆล๊ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䱲")
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䱳"),l11l1l_l1_ (u"ࠧࠨ䱴"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ䱵"),l1lll1l1l1ll_l1_+l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ䱶")+l1ll111l11l1_l1_)
			return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠬ䱷")+l1ll111l11l1_l1_,[],[]
		else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴࠣࠤࠥࠦ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧࠫ䱸"),[],[]
	l1l1llll1lll_l1_,l1l1l111lll1_l1_,l1ll1llll111_l1_ = [],[],[]
	for dict in l1llll11l11l_l1_:
		if dict[l11l1l_l1_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ䱹")]==l11l1l_l1_ (u"࠭ࡖࡪࡦࡨࡳࠬ䱺"):
			l1lll11l1111_l1_.append(dict[l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䱻")])
			l1ll11ll1l1l_l1_.append(dict)
		elif dict[l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ䱼")]==l11l1l_l1_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ䱽"):
			l1lllll1l111_l1_.append(dict[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ䱾")])
			l1llll1l1111_l1_.append(dict)
		elif dict[l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䱿")]==l11l1l_l1_ (u"ࠬࡳࡰࡥࠩ䲀"):
			title = dict[l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䲁")].replace(l11l1l_l1_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ䲂"),l11l1l_l1_ (u"ࠨࠩ䲃"))
			if l11l1l_l1_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ䲄") not in list(dict.keys()): l1lllllll111_l1_ = l11l1l_l1_ (u"ࠪ࠴ࠬ䲅")
			else: l1lllllll111_l1_ = dict[l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䲆")]
			l1l1llll1lll_l1_.append([dict,{},title,l1lllllll111_l1_])
		else:
			title = dict[l11l1l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䲇")].replace(l11l1l_l1_ (u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭䲈"),l11l1l_l1_ (u"ࠧࠨ䲉"))
			if l11l1l_l1_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ䲊") not in list(dict.keys()): l1lllllll111_l1_ = l11l1l_l1_ (u"ࠩ࠳ࠫ䲋")
			else: l1lllllll111_l1_ = dict[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䲌")]
			l1l1llll1lll_l1_.append([dict,{},title,l1lllllll111_l1_])
			l11111ll1ll_l1_.append(title)
			l1ll1111llll_l1_.append(dict)
		l1lllllll1ll_l1_ = True
		if l11l1l_l1_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ䲍") in list(dict.keys()):
			if l11l1l_l1_ (u"ࠬࡧࡶ࠱ࠩ䲎") in dict[l11l1l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䲏")]: l1lllllll1ll_l1_ = False
			elif kodi_version<18:
				if l11l1l_l1_ (u"ࠧࡢࡸࡦࠫ䲐") not in dict[l11l1l_l1_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ䲑")] and l11l1l_l1_ (u"ࠩࡰࡴ࠹ࡧࠧ䲒") not in dict[l11l1l_l1_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ䲓")]: l1lllllll1ll_l1_ = False
		if dict[l11l1l_l1_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ䲔")]==l11l1l_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ䲕") and dict[l11l1l_l1_ (u"࠭ࡩ࡯࡫ࡷࠫ䲖")]!=l11l1l_l1_ (u"ࠧ࠱࠯࠳ࠫ䲗") and l1lllllll1ll_l1_==True:
			l1lll1lll11l_l1_.append(dict[l11l1l_l1_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ䲘")])
			l11111l1ll1_l1_.append(dict)
		elif dict[l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ䲙")]==l11l1l_l1_ (u"ࠪࡅࡺࡪࡩࡰࠩ䲚") and dict[l11l1l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䲛")]!=l11l1l_l1_ (u"ࠬ࠶࠭࠱ࠩ䲜") and l1lllllll1ll_l1_==True:
			l1ll1l11l11l_l1_.append(dict[l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䲝")])
			l1111111ll1_l1_.append(dict)
		#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ䲞"),l11l1l_l1_ (u"ࠨ࠭࠮࠯࠰࠱ࠫࠬࠢࠣࠤࠬ䲟")+dict[l11l1l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ䲠")])
	for l1llllll1111_l1_ in l1111111ll1_l1_:
		l1ll1l11ll11_l1_ = l1llllll1111_l1_[l11l1l_l1_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ䲡")]
		for l1lll1111ll1_l1_ in l11111l1ll1_l1_:
			l1l1lll11ll1_l1_ = l1lll1111ll1_l1_[l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䲢")]
			l1lllllll111_l1_ = l1l1lll11ll1_l1_+l1ll1l11ll11_l1_
			title = l1lll1111ll1_l1_[l11l1l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ䲣")].replace(l11l1l_l1_ (u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨ䲤"),l11l1l_l1_ (u"ࠧ࡮ࡲࡧࠤࠥ࠭䲥"))
			title = title.replace(l1lll1111ll1_l1_[l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ䲦")]+l11l1l_l1_ (u"ࠩࠣࠤࠬ䲧"),l11l1l_l1_ (u"ࠪࠫ䲨"))
			title = title.replace(str((float(l1l1lll11ll1_l1_*10)//1024/10))+l11l1l_l1_ (u"ࠫࡰࡨࡰࡴࠩ䲩"),str((float(l1lllllll111_l1_*10)//1024/10))+l11l1l_l1_ (u"ࠬࡱࡢࡱࡵࠪ䲪"))
			title = title+l11l1l_l1_ (u"࠭ࠨࠨ䲫")+l1llllll1111_l1_[l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭䲬")].split(l11l1l_l1_ (u"ࠨࠪࠪ䲭"),1)[1]
			l1l1llll1lll_l1_.append([l1lll1111ll1_l1_,l1llllll1111_l1_,title,l1lllllll111_l1_])
	l1l1llll1lll_l1_ = sorted(l1l1llll1lll_l1_, reverse=True, key=lambda key: float(key[3]))
	for l1lll1111ll1_l1_,l1llllll1111_l1_,title,l1lllllll111_l1_ in l1l1llll1lll_l1_:
		l1llll111ll1_l1_ = l1lll1111ll1_l1_[l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ䲮")]
		if l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ䲯") in list(l1llllll1111_l1_.keys()):
			l1llll111ll1_l1_ = l11l1l_l1_ (u"ࠫࡲࡶࡤࠨ䲰")
			#l1llll111ll1_l1_ = l1llll111ll1_l1_+l1llllll1111_l1_[l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ䲱")]
		if l1llll111ll1_l1_ not in l1ll1llll111_l1_:
			l1ll1llll111_l1_.append(l1llll111ll1_l1_)
			l1l1l111lll1_l1_.append([l1lll1111ll1_l1_,l1llllll1111_l1_,title,l1lllllll111_l1_])
			#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ䲲"),str(l1lllllll111_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ䲳")+title)
	#l1l1l111lll1_l1_ = sorted(l1l1l111lll1_l1_, reverse=True, key=lambda key: int(key[3]))
	l1l1llll1l11_l1_,l1ll11llllll_l1_,shift = [],[],0
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࡵࡷ࡯ࡧࡵࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤࡴࡽ࡮ࡦࡴ࠽ࠎࠎࠏࡳࡩ࡫ࡩࡸࠥ࠱࠽ࠡ࠳ࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡒ࡛ࡓࡋࡒ࠻ࠢࠣࠫ࠰ࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠱࡟࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡲࡻࡳ࡫ࡲ࡜࠲ࡠ࡟࠶ࡣࠊࠊࠋࡶࡩࡱ࡫ࡣࡵࡏࡨࡲࡺ࠴ࡡࡱࡲࡨࡲࡩ࠮ࡴࡪࡶ࡯ࡩ࠮ࠐࠉࠊࡥ࡫ࡳ࡮ࡩࡥࡎࡧࡱࡹ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣ䲴")
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏ࡯ࡸࡰࡨࡶࡤࡩࡨࡢࡰࡱࡩࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠬࡩࡶࡰࡰࡤࡰࡳࡰࡰ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡱࡺࡲࡪࡸ࡟࡯ࡣࡰࡩࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡡࡶࡶ࡫ࡳࡷࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬ࡠ࡬ࡶࡳࡳ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠࡰࡹࡱࡩࡷࡥ࡮ࡢ࡯ࡨ࠾ࠏࠏࠉࡪ࡯ࡤ࡫ࡪࡹ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠧ࠮࠮ࠫࡁࠬࠦࡦࡲ࡬ࡰࡹࡕࡥࡹ࡯࡮ࡨࡵࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋ࡬ࡪࠥ࡯࡭ࡢࡩࡨࡷࡤࡨ࡬ࡰࡥ࡮ࡷ࠿ࠐࠉࠊࠋ࡬ࡱࡦ࡭ࡥࡴࡡࡸࡶࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢࡶࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭࡫ࡰࡥ࡬࡫ࡳࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠ࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡮࡬ࠠࡪ࡯ࡤ࡫ࡪࡹ࡟ࡶࡴ࡯࠾ࠥ࡯࡭ࡢࡩࡨࠤࡂࠦࡩ࡮ࡣࡪࡩࡸࡥࡵࡳ࡮࡞࠱࠶ࡣࠊࠊࠋࡲࡻࡳ࡫ࡲࠡ࠿ࠣࡳࡼࡴࡥࡳࡡࡱࡥࡲ࡫࡛࠱࡟ࠍࠍࠎࡹࡨࡪࡨࡷࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁ࡛ࠥ࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ࠯ࡴࡽ࡮ࡦࡴ࠮ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠊࠊࠋ࡯࡭ࡳࡱࠠ࠾࡚ࠢࡉࡇ࡙ࡉࡕࡇࡖ࡟ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭࡝࡜࠲ࡠ࠯ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ࠭ࡲࡻࡳ࡫ࡲࡠࡥ࡫ࡥࡳࡴࡥ࡭࡝࠳ࡡࠏࠏࠉࡴࡧ࡯ࡩࡨࡺࡍࡦࡰࡸ࠲ࡦࡶࡰࡦࡰࡧࠬࡹ࡯ࡴ࡭ࡧࠬࠎࠎࠏࡣࡩࡱ࡬ࡧࡪࡓࡥ࡯ࡷ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨ䲵")
	l1llllllll1l_l1_,l1lll1llllll_l1_ = l11l1l_l1_ (u"ࠪࠫ䲶"),l11l1l_l1_ (u"ࠫࠬ䲷")
	try: l1llllllll1l_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫ䲸")][l11l1l_l1_ (u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭䲹")]
	except: l1llllllll1l_l1_ = l11l1l_l1_ (u"ࠧࠨ䲺")
	try: l1ll111l11ll_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ䲻")][l11l1l_l1_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡌࡨࠬ䲼")]
	except: l1ll111l11ll_l1_ = l11l1l_l1_ (u"ࠪࠫ䲽")
	if l1llllllll1l_l1_ and l1ll111l11ll_l1_:
		shift += 1
		title = l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡏࡘࡐࡈࡖ࠿ࠦࠠࠨ䲾")+l1llllllll1l_l1_+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䲿")
		l1llll1_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ䳀")][0]+l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ䳁")+l1ll111l11ll_l1_
		l1l1llll1l11_l1_.append(title)
		l1ll11llllll_l1_.append(l1llll1_l1_)
		try: l1lll1llllll_l1_ = l1l1ll1ll1ll_l1_[l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࡄࡦࡶࡤ࡭ࡱࡹࠧ䳂")][l11l1l_l1_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬ䳃")][l11l1l_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ䳄")][-1][l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䳅")]
		except: pass
	#if l1l1l1l11111_l1_:
	#	shift += 1
	#	l1l1llll1l11_l1_.append(l11l1l_l1_ (u"ࠬࡳࡰࡥࠢฯ์ิฯࠠัๅํอࠬ䳆")) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"࠭ࡤࡢࡵ࡫ࠫ䳇"))
	for l1lll1111ll1_l1_,l1llllll1111_l1_,title,l1lllllll111_l1_ in l1l1l111lll1_l1_:
		l1l1llll1l11_l1_.append(title) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ䳈"))
	if l11111ll1ll_l1_: l1l1llll1l11_l1_.append(l11l1l_l1_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤ๊ำฯะหࠪ䳉")) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"ࠩࡰࡹࡽ࡫ࡤࠨ䳊"))
	if l1l1llll1lll_l1_: l1l1llll1l11_l1_.append(l11l1l_l1_ (u"ูࠪํืษุ๊ࠡ์ฯࠦวๅ็อ์ๆืࠧ䳋")) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"ࠫࡦࡲ࡬ࠨ䳌"))
	if l1lll1lll11l_l1_: l1l1llll1l11_l1_.append(l11l1l_l1_ (u"ࠬࡳࡰࡥࠢสาฯืࠠศๆุ์ึฯ้ࠠษ็ูํะࠧ䳍")) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"࠭࡭ࡱࡦࠪ䳎"))
	if l1lll11l1111_l1_: l1l1llll1l11_l1_.append(l11l1l_l1_ (u"ࠧึ๊ิอࠥฮฯู้่ࠣํะࠧ䳏")) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䳐"))
	if l1lllll1l111_l1_: l1l1llll1l11_l1_.append(l11l1l_l1_ (u"ุࠩ์ฯࠦศะ๊้ࠤฺ๎ัสࠩ䳑")) ; l1ll11llllll_l1_.append(l11l1l_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ䳒"))
	l11111lll1l_l1_ = False
	while True:
		l1l_l1_ = DIALOG_SELECT(l1l1l11111l1_l1_, l1l1llll1l11_l1_)
		if l1l_l1_==-1: return l11l1l_l1_ (u"ࠫࡊ࡞ࡉࡕࠩ䳓"),[],[]
		elif l1l_l1_==0 and l1llllllll1l_l1_:
			l1llll1_l1_ = l1ll11llllll_l1_[l1l_l1_]
			new_path = sys.argv[0]+l11l1l_l1_ (u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠴࠸࠶ࠬ࡮ࡢ࡯ࡨࡁࠬ䳔")+QUOTE(l1llllllll1l_l1_)+l11l1l_l1_ (u"࠭ࠦࡶࡴ࡯ࡁࠬ䳕")+l1llll1_l1_
			if l1lll1llllll_l1_: new_path = new_path+l11l1l_l1_ (u"ࠧࠧ࡫ࡰࡥ࡬࡫࠽ࠨ䳖")+QUOTE(l1lll1llllll_l1_)
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ䳗")+new_path+l11l1l_l1_ (u"ࠤࠬࠦ䳘"))
			return l11l1l_l1_ (u"ࠪࡉ࡝ࡏࡔࠨ䳙"),[],[]
		choice = l1ll11llllll_l1_[l1l_l1_]
		l1l1ll11l1l1_l1_ = l1l1llll1l11_l1_[l1l_l1_]
		if choice==l11l1l_l1_ (u"ࠫࡩࡧࡳࡩࠩ䳚"):
			l1l1l1ll11ll_l1_ = l1l1l1l11111_l1_
			break
		elif choice in [l11l1l_l1_ (u"ࠬࡧࡵࡥ࡫ࡲࠫ䳛"),l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䳜"),l11l1l_l1_ (u"ࠧ࡮ࡷࡻࡩࡩ࠭䳝")]:
			if choice==l11l1l_l1_ (u"ࠨ࡯ࡸࡼࡪࡪࠧ䳞"): l1ll1ll1_l1_,l1ll11l111l1_l1_ = l11111ll1ll_l1_,l1ll1111llll_l1_
			elif choice==l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䳟"): l1ll1ll1_l1_,l1ll11l111l1_l1_ = l1lll11l1111_l1_,l1ll11ll1l1l_l1_
			elif choice==l11l1l_l1_ (u"ࠪࡥࡺࡪࡩࡰࠩ䳠"): l1ll1ll1_l1_,l1ll11l111l1_l1_ = l1lllll1l111_l1_,l1llll1l1111_l1_
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ䳡"), l1ll1ll1_l1_)
			if l1l_l1_!=-1:
				l1l1l1ll11ll_l1_ = l1ll11l111l1_l1_[l1l_l1_][l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䳢")]
				l1l1ll11l1l1_l1_ = l1ll1ll1_l1_[l1l_l1_]
				break
		elif choice==l11l1l_l1_ (u"࠭࡭ࡱࡦࠪ䳣"):
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧศะอีࠥา่ะหࠣห้฻่าห࠽ࠫ䳤"), l1lll1lll11l_l1_)
			if l1l_l1_!=-1:
				l1l1ll11l1l1_l1_ = l1lll1lll11l_l1_[l1l_l1_]
				l1llll111111_l1_ = l11111l1ll1_l1_[l1l_l1_]
				l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ฬ࠽ࠫ䳥"), l1ll1l11l11l_l1_)
				if l1l_l1_!=-1:
					l1l1ll11l1l1_l1_ += l11l1l_l1_ (u"ࠩࠣ࠯ࠥ࠭䳦")+l1ll1l11l11l_l1_[l1l_l1_]
					l1lll1111l11_l1_ = l1111111ll1_l1_[l1l_l1_]
					l11111lll1l_l1_ = True
					break
		elif choice==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ䳧"):
			l1llll1ll1l1_l1_,l1ll1l1l11l1_l1_,l1l1l11l11ll_l1_,l1lll1l11lll_l1_ = list(zip(*l1l1llll1lll_l1_))
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪ䳨"), l1l1l11l11ll_l1_)
			if l1l_l1_!=-1:
				l1l1ll11l1l1_l1_ = l1l1l11l11ll_l1_[l1l_l1_]
				l1llll111111_l1_ = l1llll1ll1l1_l1_[l1l_l1_]
				if l11l1l_l1_ (u"ࠬࡳࡰࡥࠩ䳩") in l1l1l11l11ll_l1_[l1l_l1_] and l1llll111111_l1_[l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䳪")]!=l1l1l1l11111_l1_:
					l1lll1111l11_l1_ = l1ll1l1l11l1_l1_[l1l_l1_]
					l11111lll1l_l1_ = True
				else: l1l1l1ll11ll_l1_ = l1llll111111_l1_[l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䳫")]
				break
		elif choice==l11l1l_l1_ (u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ䳬"):
			#shift += 1
			l1llll1ll1l1_l1_,l1ll1l1l11l1_l1_,l1l1l11l11ll_l1_,l1lll1l11lll_l1_ = list(zip(*l1l1l111lll1_l1_))
			l1llll111111_l1_ = l1llll1ll1l1_l1_[l1l_l1_-shift]
			if l11l1l_l1_ (u"ࠩࡰࡴࡩ࠭䳭") in l1l1l11l11ll_l1_[l1l_l1_-shift] and l1llll111111_l1_[l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䳮")]!=l1l1l1l11111_l1_:
				l1lll1111l11_l1_ = l1ll1l1l11l1_l1_[l1l_l1_-shift]
				l11111lll1l_l1_ = True
			else: l1l1l1ll11ll_l1_ = l1llll111111_l1_[l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ䳯")]
			l1l1ll11l1l1_l1_ = l1l1l11l11ll_l1_[l1l_l1_-shift]
			break
	if not l11111lll1l_l1_: l1l1l1l1lll1_l1_ = l1l1l1ll11ll_l1_
	else: l1l1l1l1lll1_l1_ = l11l1l_l1_ (u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥ࠭䳰")+l1llll111111_l1_[l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ䳱")]+l11l1l_l1_ (u"ࠧࠡ࠭ࠣࡅࡺࡪࡩࡰ࠼ࠣࠫ䳲")+l1lll1111l11_l1_[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䳳")]
	if l11111lll1l_l1_:
		#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ䳴"),l11l1l_l1_ (u"ࠪ࠯࠰࠱ࠫࠬ࠭࠮ࠤࠥࠦࠧ䳵")+str(l1llll111111_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ䳶"),l11l1l_l1_ (u"ࠬ࠱ࠫࠬ࠭࠮࠯࠰ࠦࠠࠡࠩ䳷")+str(l1lll1111l11_l1_))
		#if l11111l1l11_l1_>l1ll1lll1l11_l1_: l1l11l1ll_l1_ = str(l11111l1l11_l1_)
		#else: l1l11l1ll_l1_ = str(l1ll1lll1l11_l1_)
		#l1l11l1ll_l1_ = str(l11111l1l11_l1_) if l11111l1l11_l1_>l1ll1lll1l11_l1_ else str(l1ll1lll1l11_l1_)
		l11111l1l11_l1_ = int(l1llll111111_l1_[l11l1l_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ䳸")])
		l1ll1lll1l11_l1_ = int(l1lll1111l11_l1_[l11l1l_l1_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ䳹")])
		l1l11l1ll_l1_ = str(max(l11111l1l11_l1_,l1ll1lll1l11_l1_))
		l1ll1ll111l1_l1_ = l1llll111111_l1_[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ䳺")].replace(l11l1l_l1_ (u"ࠩࠩࠫ䳻"),l11l1l_l1_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ䳼"))		# +l11l1l_l1_ (u"ࠫࠫࡸࡡ࡯ࡩࡨࡁ࠵࠳࠱࠱࠲࠳࠴࠵࠶࠰ࠨ䳽")
		l1lllll1l11l_l1_ = l1lll1111l11_l1_[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ䳾")].replace(l11l1l_l1_ (u"࠭ࠦࠨ䳿"),l11l1l_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭䴀"))		# +l11l1l_l1_ (u"ࠨࠨࡵࡥࡳ࡭ࡥ࠾࠲࠰࠵࠵࠶࠰࠱࠲࠳࠴ࠬ䴁")
		l11111ll1l1_l1_ = l11l1l_l1_ (u"ࠩ࠿ࡃࡽࡳ࡬ࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥ࠵࠳࠶ࠢࠡࡧࡱࡧࡴࡪࡩ࡯ࡩࡀ࡚࡚ࠦࡆ࠮࠺ࠥࡃࡃࡢ࡮ࠨ䴂")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠪࡀࡒࡖࡄࠡࡺࡰࡰࡳࡹ࠺ࡹࡵ࡬ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠵࠴࠵࠷࠯࡙ࡏࡏࡗࡨ࡮ࡥ࡮ࡣ࠰࡭ࡳࡹࡴࡢࡰࡦࡩࠧࠦࡸ࡮࡮ࡱࡷࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠣࠢࡻࡱࡱࡴࡳ࠻ࡺ࡯࡭ࡳࡱ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡽ࠳࠯ࡱࡵ࡫࠴࠷࠹࠺࠻࠲ࡼࡱ࡯࡮࡬ࠤࠣࡼࡸ࡯࠺ࡴࡥ࡫ࡩࡲࡧࡌࡰࡥࡤࡸ࡮ࡵ࡮࠾ࠤࡸࡶࡳࡀ࡭ࡱࡧࡪ࠾ࡩࡧࡳࡩ࠼ࡶࡧ࡭࡫࡭ࡢ࠼ࡰࡴࡩࡀ࠲࠱࠳࠴ࠤ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡ࡯ࡦࡤࡶࡩࡹ࠮ࡪࡵࡲ࠲ࡴࡸࡧ࠰࡫ࡷࡸ࡫࠵ࡐࡶࡤ࡯࡭ࡨࡲࡹࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡖࡸࡦࡴࡤࡢࡴࡧࡷ࠴ࡓࡐࡆࡉ࠰ࡈࡆ࡙ࡈࡠࡵࡦ࡬ࡪࡳࡡࡠࡨ࡬ࡰࡪࡹ࠯ࡅࡃࡖࡌ࠲ࡓࡐࡅ࠰ࡻࡷࡩࠨࠠ࡮࡫ࡱࡆࡺ࡬ࡦࡦࡴࡗ࡭ࡲ࡫࠽ࠣࡒࡗ࠵࠳࠻ࡓࠣࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫ䴃")+l1l11l1ll_l1_+l11l1l_l1_ (u"ࠫࡘࠨࠠࡵࡻࡳࡩࡂࠨࡳࡵࡣࡷ࡭ࡨࠨࠠࡱࡴࡲࡪ࡮ࡲࡥࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡴࡷࡵࡦࡪ࡮ࡨ࠾࡮ࡹ࡯ࡧࡨ࠰ࡱࡦ࡯࡮࠻࠴࠳࠵࠶ࠨ࠾࡝ࡰࠪ䴄")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠬࡂࡐࡦࡴ࡬ࡳࡩࡄ࡜࡯ࠩ䴅")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠵ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡺ࡮ࡪࡥࡰ࠱ࠪ䴆")+l1llll111111_l1_[l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ䴇")]+l11l1l_l1_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ䴈")		# l1ll1llll1l1_l1_=l11l1l_l1_ (u"ࠤ࠴ࠦ䴉") l11111ll111_l1_=l11l1l_l1_ (u"ࠥࡸࡷࡻࡥࠣ䴊") default=l11l1l_l1_ (u"ࠦࡹࡸࡵࡦࠤ䴋")>\n
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠬࡂࡒࡰ࡮ࡨࠤࡸࡩࡨࡦ࡯ࡨࡍࡩ࡛ࡲࡪ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢ࡮ࡣ࡬ࡲࠧ࠵࠾࡝ࡰࠪ䴌")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"࠭࠼ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡ࡫ࡧࡁࠧ࠭䴍")+l1llll111111_l1_[l11l1l_l1_ (u"ࠧࡪࡶࡤ࡫ࠬ䴎")]+l11l1l_l1_ (u"ࠨࠤࠣࡧࡴࡪࡥࡤࡵࡀࠦࠬ䴏")+l1llll111111_l1_[l11l1l_l1_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ䴐")]+l11l1l_l1_ (u"ࠪࠦࠥࡹࡴࡢࡴࡷ࡛࡮ࡺࡨࡔࡃࡓࡁࠧ࠷ࠢࠡࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࡁࠧ࠭䴑")+str(l1llll111111_l1_[l11l1l_l1_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ䴒")])+l11l1l_l1_ (u"ࠬࠨࠠࡸ࡫ࡧࡸ࡭ࡃࠢࠨ䴓")+str(l1llll111111_l1_[l11l1l_l1_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ䴔")])+l11l1l_l1_ (u"ࠧࠣࠢ࡫ࡩ࡮࡭ࡨࡵ࠿ࠥࠫ䴕")+str(l1llll111111_l1_[l11l1l_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ䴖")])+l11l1l_l1_ (u"ࠩࠥࠤ࡫ࡸࡡ࡮ࡧࡕࡥࡹ࡫࠽ࠣࠩ䴗")+l1llll111111_l1_[l11l1l_l1_ (u"ࠪࡪࡵࡹࠧ䴘")]+l11l1l_l1_ (u"ࠫࠧࡄ࡜࡯ࠩ䴙")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ䴚")+l1ll1ll111l1_l1_+l11l1l_l1_ (u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ䴛")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ䴜")+l1llll111111_l1_[l11l1l_l1_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ䴝")]+l11l1l_l1_ (u"ࠩࠥࡂࡡࡴࠧ䴞")	# l1l1l111llll_l1_=l11l1l_l1_ (u"ࠥࡸࡷࡻࡥࠣ䴟")>\n
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧ䴠")+l1llll111111_l1_[l11l1l_l1_ (u"ࠬ࡯࡮ࡪࡶࠪ䴡")]+l11l1l_l1_ (u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭䴢")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪ䴣")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧ䴤")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧ䴥")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠳ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧ䴦")+l1lll1111l11_l1_[l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭䴧")]+l11l1l_l1_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ䴨")		# l1ll1llll1l1_l1_=l11l1l_l1_ (u"ࠨ࠱ࠣ䴩") l11111ll111_l1_=l11l1l_l1_ (u"ࠢࡵࡴࡸࡩࠧ䴪") default=l11l1l_l1_ (u"ࠣࡶࡵࡹࡪࠨ䴫")>\n
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠩ࠿ࡖࡴࡲࡥࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡇࡅࡘࡎ࠺ࡳࡱ࡯ࡩ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࡲࡧࡩ࡯ࠤ࠲ࡂࡡࡴࠧ䴬")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠪࡀࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠥ࡯ࡤ࠾ࠤࠪ䴭")+l1lll1111l11_l1_[l11l1l_l1_ (u"ࠫ࡮ࡺࡡࡨࠩ䴮")]+l11l1l_l1_ (u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩ䴯")+l1lll1111l11_l1_[l11l1l_l1_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭䴰")]+l11l1l_l1_ (u"ࠧࠣࠢࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࡂࠨ࠱࠴࠲࠷࠻࠺ࠨ࠾࡝ࡰࠪ䴱")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠨ࠾ࡄࡹࡩ࡯࡯ࡄࡪࡤࡲࡳ࡫࡬ࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡴࡥ࡫ࡩࡲ࡫ࡉࡥࡗࡵ࡭ࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠧ䴲")+l1lll1111l11_l1_[l11l1l_l1_ (u"ࠩࡤࡹࡩ࡯࡯ࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䴳")]+l11l1l_l1_ (u"ࠪࠦ࠴ࡄ࡜࡯ࠩ䴴")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠧ䴵")+l1lllll1l11l_l1_+l11l1l_l1_ (u"ࠬࡂ࠯ࡃࡣࡶࡩ࡚ࡘࡌ࠿࡞ࡱࠫ䴶")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"࠭࠼ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࠥ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦ࠿ࠥࠫ䴷")+l1lll1111l11_l1_[l11l1l_l1_ (u"ࠧࡪࡰࡧࡩࡽ࠭䴸")]+l11l1l_l1_ (u"ࠨࠤࡁࡠࡳ࠭䴹")	# l1l1l111llll_l1_=l11l1l_l1_ (u"ࠤࡷࡶࡺ࡫ࠢ䴺")>\n
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭䴻")+l1lll1111l11_l1_[l11l1l_l1_ (u"ࠫ࡮ࡴࡩࡵࠩ䴼")]+l11l1l_l1_ (u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬ䴽")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩ䴾")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭䴿")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭䵀")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠩ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧ䵁")
		l11111ll1l1_l1_ += l11l1l_l1_ (u"ࠪࡀ࠴ࡓࡐࡅࡀ࡟ࡲࠬ䵂")
		#open(l11l1l_l1_ (u"ࠫࡸࡀ࡜࡝ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭䵃"),l11l1l_l1_ (u"ࠬࡽࡢࠨ䵄")).write(l11111ll1l1_l1_)
		#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ䵅"),l11111ll1l1_l1_)
		#l11111ll1l1_l1_ = OPENURL_CACHED(NO_CACHE,l1l1l1l11111_l1_,l11l1l_l1_ (u"ࠧࠨ䵆"),l11l1l_l1_ (u"ࠨࠩ䵇"),l11l1l_l1_ (u"ࠩࠪ䵈"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠺ࡶ࡫ࠫ䵉"))
		if kodi_version>18.99:
			import http.server as l1lll11ll1l1_l1_
			import http.client as l1l1llll11l1_l1_
		else:
			import BaseHTTPServer as l1lll11ll1l1_l1_
			import httplib as l1l1llll11l1_l1_
		class l1l1ll111l1l_l1_(l1lll11ll1l1_l1_.HTTPServer):
			#l11111ll1l1_l1_ = l11l1l_l1_ (u"ࠫࡁࡄࠧ䵊")
			def __init__(self,l1l1lllllll1_l1_=l11l1l_l1_ (u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ䵋"),port=55055,l11111ll1l1_l1_=l11l1l_l1_ (u"࠭࠼࠿ࠩ䵌")):
				self.l1l1lllllll1_l1_ = l1l1lllllll1_l1_
				self.port = port
				self.l11111ll1l1_l1_ = l11111ll1l1_l1_
				l1lll11ll1l1_l1_.HTTPServer.__init__(self,(self.l1l1lllllll1_l1_,self.port),l1ll1l1111ll_l1_)
				self.l1l1l1lll1ll_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ䵍")+l1l1lllllll1_l1_+l11l1l_l1_ (u"ࠨ࠼ࠪ䵎")+str(port)+l11l1l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡲࡶࡤࠨ䵏")
				#print(l11l1l_l1_ (u"ࠪࡷࡪࡸࡶࡦࡴࠣ࡭ࡸࠦࡵࡱࠢࡱࡳࡼࠦ࡬ࡪࡵࡷࡩࡳ࡯࡮ࡨࠢࡲࡲࠥࡶ࡯ࡳࡶ࠽ࠤࠬ䵐")+str(port))
			def start(self):
				self.threads = l1llll111l1l_l1_(False)
				self.threads.start_new_thread(1,self.l1ll1ll1lll1_l1_)
			def l1ll1ll1lll1_l1_(self):
				#print(l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡷ࡫ࡱ࡫ࠥࡸࡥࡲࡷࡨࡷࡹࡹࠠࡴࡶࡤࡶࡹ࡫ࡤࠨ䵑"))
				self.l1l1l111l11l_l1_ = True
				#l1l1l1l1l1l_l1_ = 0
				while self.l1l1l111l11l_l1_:
					#l1l1l1l1l1l_l1_ += 1
					#print(l11l1l_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡪࡤࡲࡩࡲࡥࡠࡴࡨࡵࡺ࡫ࡳࡵࠪࠬࠤࡳࡵࡷ࠻ࠢࠪ䵒")+str(l1l1l1l1l1l_l1_)+l11l1l_l1_ (u"࠭ࠧ䵓"))
					#settimeout l1111l111l_l1_ not l1111llll1_l1_ l1ll1111ll11_l1_ to error message if it l1l1ll1ll11l_l1_ l1l1l11ll11l_l1_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l1ll1ll1lll1_l1_ l1ll1lll1lll_l1_ request l1l1l1ll1ll1_l1_ 60 seconds)
					self.handle_request()
				#print(l11l1l_l1_ (u"ࠧࡴࡧࡵࡺ࡮ࡴࡧࠡࡴࡨࡵࡺ࡫ࡳࡵࡵࠣࡷࡹࡵࡰࡱࡧࡧࡠࡳ࠭䵔"))
			def stop(self):
				self.l1l1l111l11l_l1_ = False
				self.l1lll1111lll_l1_()	# needed to l111111l1l1_l1_ self.handle_request() to l1ll1ll1lll1_l1_ l1lll1ll1111_l1_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				#time.sleep(1)
				#print(l11l1l_l1_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡩࡵࡷ࡯ࠢࡱࡳࡼࡢ࡮ࠨ䵕"))
			def load(self,l11111ll1l1_l1_):
				self.l11111ll1l1_l1_ = l11111ll1l1_l1_
			def l1lll1111lll_l1_(self):
				conn = l1l1llll11l1_l1_.HTTPConnection(self.l1l1lllllll1_l1_+l11l1l_l1_ (u"ࠩ࠽ࠫ䵖")+str(self.port))
				conn.request(l11l1l_l1_ (u"ࠥࡌࡊࡇࡄࠣ䵗"), l11l1l_l1_ (u"ࠦ࠴ࠨ䵘"))
		class l1ll1l1111ll_l1_(l1lll11ll1l1_l1_.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l11l1l_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡌࡋࡔࠡࠢࠪ䵙")+self.path)
				self.send_response(200)
				self.send_header(l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࠬ䵚"),l11l1l_l1_ (u"ࠧࡵࡧࡻࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫ䵛"))
				self.end_headers()
				#self.wfile.write(self.path+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ䵜"))
				self.wfile.write(self.server.l11111ll1l1_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ䵝")))
				time.sleep(1)
				if self.path==l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ䵞"): self.server.shutdown()
				if self.path==l11l1l_l1_ (u"ࠫ࠴ࡹࡨࡶࡶࡧࡳࡼࡴࠧ䵟"): self.server.shutdown()
			def do_HEAD(self):
				#print(l11l1l_l1_ (u"ࠬࡪ࡯ࡪࡰࡪࠤࡍࡋࡁࡅࠢࠣࠫ䵠")+self.path)
				self.send_response(200)
				self.end_headers()
		httpd = l1l1ll111l1l_l1_(l11l1l_l1_ (u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩ䵡"),55055,l11111ll1l1_l1_)
		#httpd.load(l11111ll1l1_l1_)
		l1l1l1ll11ll_l1_ = httpd.l1l1l1lll1ll_l1_
		httpd.start()
		# http://localhost:55055/shutdown
		#l1l1l1ll11ll_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡮࡬ࡺࡪࡹࡩ࡮࠰ࡧࡥࡸ࡮ࡩࡧ࠰ࡲࡶ࡬࠵࡬ࡪࡸࡨࡷ࡮ࡳ࠯ࡤࡪࡸࡲࡰࡪࡵࡳࡡ࠴࠳ࡦࡺ࡯ࡠ࠹࠲ࡸࡪࡹࡴࡱ࡫ࡦ࠸ࡤ࠾ࡳ࠰ࡏࡤࡲ࡮࡬ࡥࡴࡶ࠱ࡱࡵࡪࠧ䵢")
		#l1l1l1ll11ll_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡥࡸ࡮࠮ࡢ࡭ࡤࡱࡦ࡯ࡺࡦࡦ࠱ࡲࡪࡺ࠯ࡥࡣࡶ࡬࠷࠼࠴࠰ࡖࡨࡷࡹࡉࡡࡴࡧࡶ࠳࠷ࡩ࠯ࡲࡷࡤࡰࡨࡵ࡭࡮࠱࠴࠳ࡒࡻ࡬ࡵ࡫ࡕࡩࡸࡓࡐࡆࡉ࠵࠲ࡲࡶࡤࠨ䵣")
		#l1l1l1ll11ll_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡹࡹࡩ࠯ࡶࡨࡰࡪࡩ࡯࡮࠯ࡳࡥࡷ࡯ࡳࡵࡧࡦ࡬࠳࡬ࡲ࠰ࡩࡳࡥࡨ࠵ࡄࡂࡕࡋࡣࡈࡕࡎࡇࡑࡕࡑࡆࡔࡃࡆ࠱ࡗࡩࡱ࡫ࡣࡰ࡯ࡓࡥࡷ࡯ࡳࡕࡧࡦ࡬࠴ࡳࡰ࠵࠯࡯࡭ࡻ࡫࠯࡮ࡲ࠷࠱ࡱ࡯ࡶࡦ࠯ࡰࡴࡩ࠳ࡁࡗ࠯ࡅࡗ࠳ࡳࡰࡥࠩ䵤")
		#l1l1l1ll11ll_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡶࡩࡳࡥࡥ࡫ࡤ࠲ࡧࡨࡣ࠯ࡥࡲ࠲ࡺࡱ࠯ࡥࡣࡶ࡬࠴ࡵ࡮ࡥࡧࡰࡥࡳࡪ࠯ࡵࡧࡶࡸࡨࡧࡲࡥ࠱࠴࠳ࡨࡲࡩࡦࡰࡷࡣࡲࡧ࡮ࡪࡨࡨࡷࡹ࠳ࡥࡷࡧࡱࡸࡸ࠳࡭ࡶ࡮ࡷ࡭ࡱࡧ࡮ࡨ࠰ࡰࡴࡩ࠭䵥")
		#l1l1l1ll11ll_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫ䵦")
	else: httpd = l11l1l_l1_ (u"ࠬ࠭䵧")
	if not l1l1l1ll11ll_l1_: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭䵨"),[],[]
	return l11l1l_l1_ (u"ࠧࠨ䵩"),[l11l1l_l1_ (u"ࠨࠩ䵪")],[[l1l1l1ll11ll_l1_,l1ll1l1ll111_l1_,httpd]]
def l1ll111lll1l_l1_(url):
	# https://l11111111l1_l1_.com/l1ll11ll1l11_l1_
	headers = { l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䵫") : l11l1l_l1_ (u"ࠪࠫ䵬") }
	#url = url.replace(l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䵭"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ䵮"))
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"࠭ࠧ䵯"),headers,l11l1l_l1_ (u"ࠧࠨ䵰"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡃࡑࡅ࠱࠶ࡹࡴࠨ䵱"))
	items = re.findall(l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࡾࠬࡠࢂ࠭䵲"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l1ll1l11l1_l1_,l1ll1ll1_l1_,l1llll1llll1_l1_,l1lll1_l1_ = [],[],[],[]
	if items:
		for l1llll1_l1_,dummy,l1ll11l1l111_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ䵳"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ䵴"))
			if l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ䵵") in l1llll1_l1_:
				l1l1ll1l11l1_l1_,l1llll1llll1_l1_ = l11l1ll1ll_l1_(l1llll1_l1_)
				#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䵶"),l11l1l_l1_ (u"ࠧࠨ䵷"),str(l1lll1_l1_),str(l1llll1llll1_l1_))
				l1lll1_l1_ = l1lll1_l1_ + l1llll1llll1_l1_
				if l1l1ll1l11l1_l1_[0]==l11l1l_l1_ (u"ࠨ࠯࠴ࠫ䵸"): l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠩึ๎ึ็ัࠡะสูࠬ䵹")+l11l1l_l1_ (u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ䵺"))
				else:
					for title in l1l1ll1l11l1_l1_:
						l1ll1ll1_l1_.append(l11l1l_l1_ (u"ุࠫ๐ัโำࠣาฬ฻ࠧ䵻")+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ䵼")+title)
			else:
				title = l11l1l_l1_ (u"࠭ำ๋ำไีࠥิวึࠩ䵽")+l11l1l_l1_ (u"ࠧࠡࠢࠣࡱࡵ࠺ࠠࠡࠢࠪ䵾")+l1ll11l1l111_l1_
				l1lll1_l1_.append(l1llll1_l1_)
				l1ll1ll1_l1_.append(title)
		return l11l1l_l1_ (u"ࠨࠩ䵿"),l1ll1ll1_l1_,l1lll1_l1_
	else: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫ䶀"),[],[]
def	l1l1l1l111l1_l1_(url):
	# https://l111111ll1l_l1_.cc/l1l1111l1_l1_-1qrpoobdg7bu.html
	# https://l1lll11111l1_l1_.cc//l1l1111l1_l1_-l1lll1l1l111_l1_.html
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䶁"),url,l11l1l_l1_ (u"ࠫࠬ䶂"),l11l1l_l1_ (u"ࠬ࠭䶃"),l11l1l_l1_ (u"࠭ࠧ䶄"),l11l1l_l1_ (u"ࠧࠨ䶅"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡜ࡉࡅࡇࡒࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨ䶆"))
	html = response.content
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䶇"),html,re.DOTALL)
	if l1l1_l1_:
		l1llll1_l1_ = l1l1_l1_[0]
		return l11l1l_l1_ (u"ࠪࠫ䶈"),[l11l1l_l1_ (u"ࠫࠬ䶉")],[l1llll1_l1_]
	return l11l1l_l1_ (u"ࠬ࠭䶊"),[],[]
def	l1l1l1l1l1ll_l1_(url):
	# https://l1l1l1l1l1l1_l1_.in/l1l1ll1llll1_l1_
	# https://l1l1l1l1l1l1_l1_.in/l1l1111l1_l1_-l1l1ll1llll1_l1_.html
	# https://l1lll11lllll_l1_.l1ll11111111_l1_/l1lllllll11l_l1_
	# https://l1lll11lllll_l1_.l1ll11111111_l1_/l1l1111l1_l1_-l1lllllll11l_l1_.html
	# https://l1l1l1l111l_l1_.l1llllllllll_l1_.com/l1l1111l1_l1_-l1ll1l11lll1_l1_.html
	url = url.replace(l11l1l_l1_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭䶋"),l11l1l_l1_ (u"ࠧࠨ䶌")).replace(l11l1l_l1_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ䶍"),l11l1l_l1_ (u"ࠩࠪ䶎"))
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䶏"),url,l11l1l_l1_ (u"ࠫࠬ䶐"),l11l1l_l1_ (u"ࠬ࠭䶑"),l11l1l_l1_ (u"࠭ࠧ䶒"),l11l1l_l1_ (u"ࠧࠨ䶓"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ䶔"))
	html = response.content
	l1ll11l1llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭ࡡ࠯ࠩࠨ䶕"),html,re.DOTALL)
	if l1ll11l1llll_l1_:
		l1ll11l1llll_l1_ = l1ll11l1llll_l1_[0]
		l1l1lll1lll1_l1_ = l1l1llllllll_l1_(l1ll11l1llll_l1_)
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮࡯ࡥࡧ࡫࡬࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ䶖"),l1l1lll1lll1_l1_,re.DOTALL)
		if not l1l1_l1_: l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠭ࢂ࠭䶗"),l1l1lll1lll1_l1_,re.DOTALL)
		l1ll1ll1_l1_,l1lll1_l1_ = [],[]
		for l1llll1_l1_,title in l1l1_l1_:
			if not title: title = l1llll1_l1_.rsplit(l11l1l_l1_ (u"ࠬ࠴ࠧ䶘"),1)[1]
			l1ll1ll1_l1_.append(title)
			l1lll1_l1_.append(l1llll1_l1_)
		return l11l1l_l1_ (u"࠭ࠧ䶙"),l1ll1ll1_l1_,l1lll1_l1_
	id = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ䶚"))[3]
	headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䶛"):l11l1l_l1_ (u"ࠩࠪ䶜") , l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ䶝"):l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ䶞") }
	payload = { l11l1l_l1_ (u"ࠬ࡯ࡤࠨ䶟"):id , l11l1l_l1_ (u"࠭࡯ࡱࠩ䶠"):l11l1l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ䶡") }
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭䶢"),url,payload,headers,l11l1l_l1_ (u"ࠩࠪ䶣"),l11l1l_l1_ (u"ࠪࠫ䶤"),l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡈࡌࡐࡊ࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪ䶥"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"ࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䶦"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"࠭ࠧ䶧"),[l11l1l_l1_ (u"ࠧࠨ䶨")],[ items[0] ]
	return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡜ࡋࡏࡌࡆࡕࡋࡅࡗࡏࡎࡈࠩ䶩"),[],[]
l11l1l_l1_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡊࡓ࡛ࡏࡄࠩࡷࡵࡰ࠮ࡀࠊࠊࠥࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵࡶࡪࡦ࠱ࡧࡴ࠵ࡶࡪࡦࡨࡳ࠴ࡶ࡬ࡢࡻ࠲ࡅࡆ࡜ࡅࡏࡦࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼ࡙ࠢࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࠡ࠼ࠣࠫࠬࠦࡽࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡖࡊࡆ࠰࠵ࡸࡺࠧࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥ࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡪࠥ࠭࠮࡮࠵ࡸ࠼ࠬࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾ࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔࡵࡧࡰࡴࡠ࠶࡝࠾࠿ࠪ࠱࠶࠭࠺ࠡࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧู๊ࠬࠬาใิࠤำอีࠨ࠭ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫ࠮ࠐࠉࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍࠎ࡬࡯ࡳࠢࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࡴࡦ࡯ࡳ࠾ࠏࠏࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧิ์ิๅึࠦฮศืࠪ࠯ࠬࠦࠠࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩึ๎ึ็ัࠡะสูࠬ࠱ࠧࠡࠢࠣࡱࡵ࠺ࠧࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡵ࡫ࡷࡰࡪ࠯ࠊࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠊࠊࡧ࡯ࡷࡪࡀࠠࡳࡧࡷࡹࡷࡴࠠࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡋࡔ࡜ࡉࡅࠩ࠯࡟ࡢ࠲࡛࡞ࠌࠌࠧࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠲࡯࠱࡫ࡴࡼࡩࡥ࠰ࡦࡳ࠴ࡹࡴࡳࡧࡤࡱ࠴࠸࠲࠺࠰ࡰ࠷ࡺ࠾ࠊࠣࠤࠥ䶪")
#####################################################
#    l1lllll1llll_l1_ l1ll11lll1l1_l1_ l1ll11111l11_l1_
#    16-06-2019
#####################################################
def l1ll11l1l1l1_l1_(url):
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠪࠫ䶫"),l11l1l_l1_ (u"ࠫࠬ䶬"),l11l1l_l1_ (u"ࠬ࠭䶭"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡌࡐࡃࡇࡗ࠲࠷ࡳࡵࠩ䶮"))
	items = re.findall(l11l1l_l1_ (u"ࠧࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䶯"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"ࠨࠩ䶰"),[l11l1l_l1_ (u"ࠩࠪ䶱")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨ䶲"),[],[]
def l1ll111llll1_l1_(url):
	return l11l1l_l1_ (u"ࠫࠬ䶳"),[l11l1l_l1_ (u"ࠬ࠭䶴")],[ url ]
def l1ll11llll11_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䶵"),l11l1l_l1_ (u"ࠧࠨ䶶"),url,l11l1l_l1_ (u"ࠨࠩ䶷"))
	server = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ䶸"))
	basename = l11l1l_l1_ (u"ࠪ࠳ࠬ䶹").join(server[0:3])
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠫࠬ䶺"),l11l1l_l1_ (u"ࠬ࠭䶻"),l11l1l_l1_ (u"࠭ࠧ䶼"),l11l1l_l1_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋ࠭࠲ࡵࡷࠫ䶽"))
	items = re.findall(l11l1l_l1_ (u"ࠨࡦ࡯ࡦࡺࡺࡴࡰࡰ࡟ࠫࡡ࠯࠮ࡩࡴࡨࡪࠥࡃࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡞࠮ࠤࡡ࠮ࠨ࠯ࠬࡂ࠭ࠥࡢࠥࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࠭ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࠩࠥ࠮࠮ࠫࡁࠬࡠ࠮ࠦ࡜ࠬࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䶾"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䶿"),l11l1l_l1_ (u"ࠪࠫ䷀"),url,str(var))
	if items:
		l111lll1ll1_l1_,l11l11111ll_l1_,l11l1111l11_l1_,l1lll1l11l1l_l1_,l1lll1l11ll1_l1_,l1lll1l11l11_l1_ = items[0]
		var = int(l11l11111ll_l1_) % int(l11l1111l11_l1_) + int(l1lll1l11l1l_l1_) % int(l1lll1l11ll1_l1_)
		url = basename + l111lll1ll1_l1_ + str(var) + l1lll1l11l11_l1_
		return l11l1l_l1_ (u"ࠫࠬ䷁"),[l11l1l_l1_ (u"ࠬ࠭䷂")],[url]
	else: return l11l1l_l1_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡ࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉࠬ䷃"),[],[]
def l1lll11ll11l_l1_(url):
	url = url.replace(l11l1l_l1_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ䷄"),l11l1l_l1_ (u"ࠨࠩ䷅"))
	url = url.replace(l11l1l_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ䷆"),l11l1l_l1_ (u"ࠪࠫ䷇"))
	id = url.split(l11l1l_l1_ (u"ࠫ࠴࠭䷈"))[-1]
	headers = { l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ䷉") : l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ䷊") }
	payload = { l11l1l_l1_ (u"ࠢࡪࡦࠥ䷋"):id , l11l1l_l1_ (u"ࠣࡱࡳࠦ䷌"):l11l1l_l1_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧ䷍") }
	request = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ䷎"), url, payload, headers, l11l1l_l1_ (u"ࠫࠬ䷏"),l11l1l_l1_ (u"ࠬ࠭䷐"),l11l1l_l1_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡔ࠹࡛ࡐࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ䷑"))
	if l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ䷒") in list(request.headers.keys()): l1llll1_l1_ = request.headers[l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䷓")]
	else: l1llll1_l1_ = url
	if l1llll1_l1_: return l11l1l_l1_ (u"ࠩࠪ䷔"),[l11l1l_l1_ (u"ࠪࠫ䷕")],[l1llll1_l1_]
	else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩ䷖"),[],[]
def l1l1lll1ll11_l1_(url):
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠬ࠭䷗"),l11l1l_l1_ (u"࠭ࠧ䷘"),l11l1l_l1_ (u"ࠧࠨ䷙"),l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫ䷚"))
	items = re.findall(l11l1l_l1_ (u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ䷛"),html,re.DOTALL)
	if items: return l11l1l_l1_ (u"ࠪࠫ䷜"),[l11l1l_l1_ (u"ࠫࠬ䷝")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡘࡋࡑࡘ࡛ࡒࡉࡗࡇࠪ䷞"),[],[]
def l1l1l111l1ll_l1_(url):
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"࠭ࠧ䷟"),l11l1l_l1_ (u"ࠧࠨ䷠"),l11l1l_l1_ (u"ࠨࠩ䷡"),l11l1l_l1_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪ䷢"))
	items = re.findall(l11l1l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䷣"),html,re.DOTALL)
	#l1lll111111l_l1_.l1l1l11l1ll1_l1_(l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪ䷤") + items[0])
	if items:
		url = url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡥ࡫࡭ࡻ࡫࠮ࡰࡴࡪࠫ䷥") + items[0]
		return l11l1l_l1_ (u"࠭ࠧ䷦"),[l11l1l_l1_ (u"ࠧࠨ䷧")],[ url ]
	else: return l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡅࡗࡉࡈࡊࡘࡈࠫ䷨"),[],[]
def l1ll1l1l1111_l1_(url):
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠩࠪ䷩"),l11l1l_l1_ (u"ࠪࠫ䷪"),l11l1l_l1_ (u"ࠫࠬ䷫"),l11l1l_l1_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡘࡆࡑࡏࡃࡗࡋࡇࡉࡔࡎࡏࡔࡖ࠰࠵ࡸࡺࠧ䷬"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䷭"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䷮"),l11l1l_l1_ (u"ࠨࠩ䷯"),str(items),html)
	if items: return l11l1l_l1_ (u"ࠩࠪ䷰"),[l11l1l_l1_ (u"ࠪࠫ䷱")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡖࡄࡏࡍࡈ࡜ࡉࡅࡇࡒࡌࡔ࡙ࡔࠨ䷲"),[],[]
def l1ll11l11l1l_l1_(url):
	#url = url.replace(l11l1l_l1_ (u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬ䷳"),l11l1l_l1_ (u"࠭ࠧ䷴"))
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,l11l1l_l1_ (u"ࠧࠨ䷵"),l11l1l_l1_ (u"ࠨࠩ䷶"),l11l1l_l1_ (u"ࠩࠪ䷷"),l11l1l_l1_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡔࡖࡕࡉࡆࡓ࠭࠲ࡵࡷࠫ䷸"))
	items = re.findall(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠣࡴࡷ࡫࡬ࡰࡣࡧ࠲࠯ࡅࡳࡳࡥࡀ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䷹"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䷺"),l11l1l_l1_ (u"࠭ࠧ䷻"),items[0],items[0])
	if items: return l11l1l_l1_ (u"ࠧࠨ䷼"),[l11l1l_l1_ (u"ࠨࠩ䷽")],[ items[0] ]
	else: return l11l1l_l1_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊ࡙ࡔࡓࡇࡄࡑࠬ䷾"),[],[]
l11l1l_l1_ (u"ࠥࠦࠧࠐࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠎࠨࠦࠠࠡࠢࡑࡓ࡙ࠦࡗࡐࡔࡎࡍࡓࡍࠠࡂࡐ࡜ࡑࡔࡘࡅࠋࠥࠣࠤࠥࠦ࠰࠳࠯ࡉࡉࡇ࠳࠲࠱࠴࠴ࠎࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠌࠍࠎࠏࠐࠢࠣࠤ䷿")
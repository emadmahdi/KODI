# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪ京")
def MAIN(mode,text=l11l1l_l1_ (u"ࠩࠪ亭")):
	if   mode==  0: l11lllll11l1_l1_(text)
	elif mode==  2: l1l111l11ll1_l1_(text)
	elif mode==  3: l1l111lll111_l1_()
	elif mode==  4: l1l11l111ll1_l1_(text)
	elif mode==  5: l11llll1ll11_l1_()
	elif mode==  6: l1l11l111111_l1_()
	elif mode==  7: l1l1111l1ll1_l1_()
	elif mode==  8: l11llll11l11_l1_()
	elif mode==  9: l11llll11ll1_l1_()
	elif mode==150: l1l111ll1ll1_l1_()
	elif mode==151: l11ll11l11l1_l1_()
	elif mode==152: l1l11111lll1_l1_()
	elif mode==153: l1l11lll1l11_l1_()
	elif mode==154: l1l11l1l1111_l1_()
	elif mode==155: l11llllll111_l1_()
	elif mode==156: l11ll111llll_l1_()
	elif mode==157: l1l11l11111l_l1_()
	elif mode==158: l1l1111l111l_l1_()
	elif mode==159: l1l111l1l111_l1_(True)
	elif mode==170: l11lll1l11l1_l1_()
	elif mode==171: l1l111l111l1_l1_()
	elif mode==172: l1l11ll1l1l1_l1_()
	elif mode==173: l1l1111lllll_l1_(l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ亮"),True)
	elif mode==174: l1l1111lllll_l1_(l11l1l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ亯"),True)
	elif mode==175: l1l1111111l1_l1_()
	elif mode==176: l11lll111l1l_l1_()
	elif mode==177: l1l11l11l11l_l1_(l11l1l_l1_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ亰"))
	elif mode==178: l1l11l11l11l_l1_(l11l1l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ亱"))
	elif mode==179: l1l11l11l11l_l1_(l11l1l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠧ亲"))
	elif mode==190: l11lllll1111_l1_()
	elif mode==191: l11ll1ll1l11_l1_()
	elif mode==192: l11lll111ll1_l1_()
	elif mode==193: l1l111l11l11_l1_()
	elif mode==194: l11lll11111l_l1_()
	elif mode==195: l11lll1ll111_l1_()
	elif mode==196: l1l1111l11ll_l1_()
	elif mode==197: l11lll1llll1_l1_()
	elif mode==198: l1l111l11111_l1_()
	elif mode==199: l11ll1l1llll_l1_()
	elif mode==340: l11ll1l1l1ll_l1_(text)
	elif mode==341: l1l11l11l1ll_l1_()
	elif mode==342: l11lllllll1l_l1_()
	elif mode==343: l11lll1lllll_l1_()
	elif mode==344: l1l11l11lll1_l1_()
	elif mode==345: l1l1111l1lll_l1_()
	elif mode==346: l1l11111l11l_l1_()
	elif mode==347: l1l111lll11l_l1_(True)
	elif mode==348: l1l111l111ll_l1_()
	elif mode==349: l1l111ll1l11_l1_(l1l11ll111ll_l1_)
	elif mode==500: l11ll1lll111_l1_()
	elif mode==501: l11ll1l1111l_l1_()
	elif mode==502: l1l1111llll1_l1_(l11l1l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ亳"),True)
	elif mode==503: l1l111ll1l11_l1_(l11l111l11l_l1_)
	elif mode==504: l1l111ll1l11_l1_(favoritesfile)
	elif mode==505: l1l111111111_l1_()
	elif mode==506: FIX_ALL_DATABASES(True)
	elif mode==507: l1l11l11l111_l1_(text,l11l1l_l1_ (u"ࠩࠪ亴"),True)
	elif mode==508: l1l111l1111l_l1_()
	return
def l1l11l11l111_l1_(addon_id,function,l1ll_l1_):
	conn = sqlite3.connect(l1l111ll1l1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if kodi_version<19: l11lll11l11l_l1_ = l11l1l_l1_ (u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭亵")
	else: l11lll11l11l_l1_ = l11l1l_l1_ (u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪ亶")
	cc.execute(l11l1l_l1_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭亷")+l11lll11l11l_l1_+l11l1l_l1_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫ亸")+addon_id+l11l1l_l1_ (u"ࠧࠣࠢ࠾ࠫ亹"))
	l11llll1l1ll_l1_ = cc.fetchall()
	if l11llll1l1ll_l1_ and function in [l11l1l_l1_ (u"ࠨࠩ人"),l11l1l_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ亻")]:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࠫ亼"),l11l1l_l1_ (u"ࠫࠬ亽"),l11l1l_l1_ (u"ࠬ࠭亾"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ亿"),l11l1l_l1_ (u"ࠧศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅวูหๆฯࠠ࡝ࡰࠣࠫ什")+addon_id+l11l1l_l1_ (u"ࠨࠢ࡟ࡲࡡࡴࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟้ࠣฯ๎โโ๋่ࠢฬฺ๊ࠦ็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣษ๏่วโ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ仁"))
		if l1ll111111_l1_!=1: return
		cc.execute(l11l1l_l1_ (u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨ仂")+l11lll11l11l_l1_+l11l1l_l1_ (u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ仃")+addon_id+l11l1l_l1_ (u"ࠫࠧࠦ࠻ࠨ仄"))
	elif function in [l11l1l_l1_ (u"ࠬ࠭仅"),l11l1l_l1_ (u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࠧ仆")]:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨ仇"),l11l1l_l1_ (u"ࠨࠩ仈"),l11l1l_l1_ (u"ࠩࠪ仉"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭今"),l11l1l_l1_ (u"ࠫฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้หึศใฬࠤࡡࡴࠠࠨ介")+addon_id+l11l1l_l1_ (u"ࠬࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠๆใ฼่ࠥ๎ฺ๊็็ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡวํๆฬ็็ࠡษ็ฦ๋ࠦฟࠢࠣࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣฮุะื๋฻ࠣฮๆ฿๊ๅ้ࠣฬุํ่ๅหࠣ฽๋ีࠠศๆ฼์ิฯࠠฦๆ์ࠤ์ึ็ࠡษ็ุฬฺษࠡษ็้ํา่ะหࠣๅ๏ࠦโศศ่อࠥิฯๆษอࠤอืๆศ็ฯࠤ฾๋วะࠩ仌"))
		if l1ll111111_l1_!=1: return
		if kodi_version<19: cc.execute(l11l1l_l1_ (u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡧࡲࡡࡤ࡭࡯࡭ࡸࡺࠠࠩࡣࡧࡨࡴࡴࡉࡅ࡚ࠫࠣࡆࡒࡕࡆࡕࠣࠬࠧ࠭仍")+addon_id+l11l1l_l1_ (u"ࠧࠣࠫࠣ࠿ࠬ从"))
		else: cc.execute(l11l1l_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࡵࡱࡦࡤࡸࡪࡥࡲࡶ࡮ࡨࡷࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨ仏")+addon_id+l11l1l_l1_ (u"ࠩࠥ࠰࠶࠯ࠠ࠼ࠩ仐"))
	conn.commit()
	conn.close()
	time.sleep(1)
	xbmc.executebuiltin(l11l1l_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ仑"))
	time.sleep(1)
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ仒"),l11l1l_l1_ (u"ࠬ࠭仓"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ仔"),l11l1l_l1_ (u"ࠧห็อࠤฬู๊ๆๆํอࠥฮๆอษะࠫ仕"))
	if function in [l11l1l_l1_ (u"ࠨࠩ他"),l11l1l_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ仗")]: l1l111l1l111_l1_(l1ll_l1_)
	return
def l1l111111111_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭付"),l11l1l_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ仙"))
	l1l111lll1ll_l1_ = l1l11l11l1l1_l1_()
	l1l1111ll1ll_l1_ = l11l1l_l1_ (u"ࠬࡢ࡮ࠨ仚")
	l1l11lll1ll1_l1_ = l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠢ࠰࠱࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰࠱࠲࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ仛")
	l1l11lll1l1l_l1_ = l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ仜")
	for id,l1l1111l1111_l1_,l1l11ll1lll1_l1_,l11l1ll11l1_l1_,l11ll11llll1_l1_,reason in reversed(l1l111lll1ll_l1_):
		if id==l11l1l_l1_ (u"ࠨ࠲ࠪ仝"):
			l11llll111ll_l1_,l1l11l1ll1l1_l1_ = l11l1ll11l1_l1_.split(l11l1l_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ仞"))
			continue
		if l1l1111ll1ll_l1_!=l11l1l_l1_ (u"ࠪࡠࡳ࠭仟"): l1l1111ll1ll_l1_ += l1l11lll1l1l_l1_
		l1ll111l11l_l1_ = l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ仠")+id+l11l1l_l1_ (u"ࠬࠦ࠺ࠡࠩ仡")+l11l1l_l1_ (u"࠭วๅีวห้ࠦ࠺ࠡࠩ仢")+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ代")+l1l11ll1lll1_l1_
		l1ll111l1l1_l1_ = l11l1l_l1_ (u"ࠨ࡞ࡱ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้า่ศสࠣ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ令")+l11l1ll11l1_l1_
		l1lll111l1ll_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่ำ฽รࠡ࠼ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ以")+l11ll11llll1_l1_
		l1lll111ll11_l1_ = l11l1l_l1_ (u"ࠪࡠࡳࡡࡒࡕࡎࡠ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢอไิสหࠤ࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ仦")+reason
		l1l1111ll1ll_l1_ += l1ll111l11l_l1_+l1ll111l1l1_l1_+l11l1l_l1_ (u"ࠫࡡࡴࠧ仧")+l1l11lll1ll1_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ仨")+l1lll111l1ll_l1_+l1lll111ll11_l1_+l11l1l_l1_ (u"࠭࡜࡯ࠩ仩")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭仪"),l1l11l1ll1l1_l1_,l1l1111ll1ll_l1_,l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࡣࡱࡵ࡮ࡨࠩ仫"))
	return
def l1l111ll1l11_l1_(file):
	if file==favoritesfile: l1l111111ll1_l1_ = l11l1l_l1_ (u"ࠩๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩ们")
	elif file==l1l11ll111ll_l1_: l1l111111ll1_l1_ = l11l1l_l1_ (u"ࠪห้ืำศศ็ࠫ仭")
	elif file==l11l111l11l_l1_: l1l111111ll1_l1_ = l11l1l_l1_ (u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ仮")
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ仯"),l11l1l_l1_ (u"࠭ๅิฯࠪ仰"),l11l1l_l1_ (u"ࠧฦื็หา࠭仱"),l11l1l_l1_ (u"ࠨะิ์ั࠭仲"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ仳"),l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨ仴")+l1l111111ll1_l1_+l11l1l_l1_ (u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫ仵"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭件"),l11l1l_l1_ (u"࠭ࠧ价"),l11l1l_l1_ (u"ࠧࠨ仸"),str(choice))
	if choice==0:
		if os.path.exists(file):
			try: os.remove(file)
			except: pass
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ仹"),l11l1l_l1_ (u"ࠩࠪ仺"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭任"),l11l1l_l1_ (u"ࠫฯ๋ࠠๆีะࠤ๊๊แࠡࠩ仼")+l1l111111ll1_l1_)
	elif choice==1:
		data = FIX_AND_GET_FILE_CONTENTS(file)
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭份"),l11l1l_l1_ (u"࠭ࠧ仾"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ仿"),l11l1l_l1_ (u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨ伀")+l1l111111ll1_l1_)
	return
def l11ll1l1111l_l1_():
	if kodi_version<18:
		message = l11l1l_l1_ (u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬ企")+str(kodi_version)+l11l1l_l1_ (u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫ伂")
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ伃"),l11l1l_l1_ (u"ࠬ࠭伄"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ伅"),message)
		return
	l11ll1l1l1l1_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ伆"))
	l1l1l1l111ll_l1_ = l11llllllll1_l1_([l11l1l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ伇")])
	l11l11l1l1l_l1_,l1l111ll111l_l1_,l11ll11ll1ll_l1_,l1l111ll11l1_l1_,l1l111l1lll1_l1_,l11ll1l1l11l_l1_,l1l111ll1111_l1_ = l1l1l1l111ll_l1_[l11l1l_l1_ (u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ伈")]
	if l11l11l1l1l_l1_ or l11l1l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ伉") not in str(l11ll1l1l1l1_l1_):
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ伊"),l11l1l_l1_ (u"ࠬ࠭伋"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ伌"),l11l1l_l1_ (u"ࠧศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬ伍"))
		succeeded = l1l1111llll1_l1_(l11l1l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ伎"),True)
		if not succeeded: return
	l1l111l1l1ll_l1_(True)
	return
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠣࡁࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡨࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬࡧࡶ࠯ࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡸࡾࡶࡥࡊࡆࠪ࠭ࠏࠏࡩࡧࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࡃ࠽ࠨ࠷࠷࠸ࠬࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠢࡀࠤ่่ࠬศศ่ࠤฬ๊ใหษหอࠬࠐࠉࡦ࡮࡬ࡪࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅ࠿ࡀࠫ࠺࠻࠵ࠨ࠼ࠣࡺ࡮࡫ࡷࡵࡻࡳࡩࠥࡃࠠࠨไ๋หห๋ࠠศๆุ์ึ࠭ࠊࠊࡧ࡯ࡷࡪࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࠢࡀࠤ่่ࠬศศ่ࠤ๊า็้ๆฬࠫࠏࠏࡩࡧࠢࡦ࡬ࡴ࡯ࡣࡦ࠿ࡀ࠴࠿ࠏࠉࠤࠢࡤࡲࡾࠦ࡯ࡵࡪࡨࡶࠥࡼࡩࡦࡹࡷࡽࡵ࡫ࠊࠊࠋࡹ࡭ࡪࡽࡴࡺࡲࡨࡍࡉࠦ࠽ࠡࠩࠪࠎࠎࠏࠣࡪ࡯ࡳࡳࡷࡺࠠࡴࡳ࡯࡭ࡹ࡫࠳ࠋࠋࠌࡧࡴࡴ࡮ࠡ࠿ࠣࡷࡶࡲࡩࡵࡧ࠶࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࡼࡩࡦࡹࡶࡣࡩࡨࡦࡪ࡮ࡨ࠭ࠏࠏࠉࡤࡥࠣࡁࠥࡩ࡯࡯ࡰ࠱ࡧࡺࡸࡳࡰࡴࠫ࠭ࠏࠏࠉࡤࡱࡱࡲ࠳ࡺࡥࡹࡶࡢࡪࡦࡩࡴࡰࡴࡼࠤࡂࠦࡳࡵࡴࠍࠍࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࡹ࡭ࡪࡽ࡙ࠢࠡࡋࡉࡗࡋࠠࡷ࡫ࡨࡻࡒࡵࡤࡦࠢࡀࠤ࠶࠿࠷࠲࠳࠺ࠤࡀ࠭ࠩࠋࠋࠌࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࡷ࡫ࡨࡻࠧࠦࡗࡉࡇࡕࡉࠥࡼࡩࡦࡹࡐࡳࡩ࡫ࠠ࠾ࠢ࠹࠺࠵࠾࠰ࠡ࠽ࠪ࠭ࠏࠏࠉࡤࡱࡱࡲ࠳ࡩ࡯࡮࡯࡬ࡸ࠭࠯ࠊࠊࠋࡦࡳࡳࡴ࠮ࡤ࡮ࡲࡷࡪ࠮ࠩࠋࠋࡨࡰ࡮࡬ࠠࡤࡪࡲ࡭ࡨ࡫࠽࠾࠳࠽ࠤࡻ࡯ࡥࡸࡶࡼࡴࡪࡏࡄࠡ࠿ࠣࠫ࠺࠺࠴ࠨࠋࠦࠤࠧࡒࡩࡴࡶࠣࡉࡲࡧࡤࠣࠢࡹ࡭ࡪࡽࡴࡺࡲࡨࠎࠎ࡫࡬ࡪࡨࠣࡧ࡭ࡵࡩࡤࡧࡀࡁ࠷ࡀࠠࡷ࡫ࡨࡻࡹࡿࡰࡦࡋࡇࠤࡂࠦࠧ࠶࠷࠸ࠫࠎࠩࠠࠣࡉࡤࡰࡱ࡫ࡲࡺࡡࡈࡱࡦࡪࠢࠡࡸ࡬ࡩࡼࡺࡹࡱࡧࠍࠍࡪࡲࡳࡦ࠼ࠣࡶࡪࡺࡵࡳࡰࠍࠍࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡳࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡦࡼ࠮ࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡷࡽࡵ࡫ࡉࡅࠩ࠯ࡺ࡮࡫ࡷࡵࡻࡳࡩࡎࡊࠩࠋࠋࠥࠦࠧ伏")
def l1l111l1l1ll_l1_(l1ll_l1_=True):
	l11ll1l1l1l1_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭伐"))
	if l11l1l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ休") not in str(l11ll1l1l1l1_l1_):
		if l1ll_l1_:
			DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭伒"),l11l1l_l1_ (u"࠭ࠧ伓"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ伔"),l11l1l_l1_ (u"ࠨๆ็วุ็ࠠอ้สึ่ࠦไศࠢํืฯิฯๆࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮ࠡษ็ๆํอฦๆࠢส่๊฻่าหࠣฮ฾๋ไࠡใๅ฻ู๋ࠥࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴่ࠠา๊ࠤฬ๊โ้ษษ้ࠥะๅไ่ๆࠤ๊์ࠠาฦํอ่่ࠥศศ่ࠤอืๆศ็ฯࠤ฾๋วะࠢหุ่๊ࠠึ๊ิࠤอีไศ่๊ࠢࠥอไไฬสฬฮ࠭伕"))
		return
	l1l111lllll1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ伖"),l11l1l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ众"),l11l1l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ优"),l11l1l_l1_ (u"ࠬࡓࡹࡗ࡫ࡧࡩࡴࡔࡡࡷ࠰ࡻࡱࡱ࠭伙"))
	if not os.path.exists(l1l111lllll1_l1_): return
	l11lll1l1ll1_l1_ = open(l1l111lllll1_l1_,l11l1l_l1_ (u"࠭ࡲࡣࠩ会")).read()
	if kodi_version>18.99: l11lll1l1ll1_l1_ = l11lll1l1ll1_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ伛"))
	l11ll11ll1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠪ࡟ࡨ࠰࠲࡜ࡥ࠭࠯ࡠࡩ࠱ࠩ࠭ࠪ࠱࠮ࡄ࠯࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ伜"),l11lll1l1ll1_l1_,re.DOTALL)
	l11ll1l1ll1l_l1_,l1l11lll11l1_l1_ = l11ll11ll1l1_l1_[0]
	l1l11l1l1l11_l1_ = l11l1l_l1_ (u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ伝")+l11ll1l1ll1l_l1_+l11l1l_l1_ (u"ࠪ࠰ࠬ伞")+l1l11lll11l1_l1_+l11l1l_l1_ (u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭伟")
	if l1ll_l1_:
		l1l11l1ll111_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡘ࡬ࡩࡼࡳ࡯ࡥࡧࠪ传"))
		if l1l11l1ll111_l1_==l11l1l_l1_ (u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ伡"): l1l11l1l111l_l1_ = l11l1l_l1_ (u"ࠧใ๊สส๊ࠦวๅๅอหอฯࠧ伢")
		elif l1l11l1ll111_l1_==l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧ伣"): l1l11l1l111l_l1_ = l11l1l_l1_ (u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧ伤")
		else: l1l11l1l111l_l1_ = l11l1l_l1_ (u"ࠪๆํอฦๆࠢฦาึ๏ࠧ伥")
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ伦"),l11l1l_l1_ (u"่่ࠬศศ่ࠤศิั๊ࠩ伧"),l11l1l_l1_ (u"࠭โ้ษษ้ࠥอไไฬสฬฮ࠭伨"),l11l1l_l1_ (u"ࠧใ๊สส๊ࠦวๅื๋ีࠬ伩"),l11l1l_l1_ (u"ࠨษ้ฮࠥำวๅ์สࠤฯูสฯั่ࠤࠬ伪")+l1l11l1l111l_l1_,l11l1l_l1_ (u"ࠩส๊ฯࠦวๅฤ้ࠤฯูสฯั่ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊่ࠦสิฬฺ๎฾ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢหำ้อࠠๆ่ࠣๆํอฦๆࠢส่่ะวษหࠣ࠲ࠥ๎รุ๋สࠤฯูสุ์฼ࠤส๐โศใ๊หࠥ็๊ࠡลํࠤํ่สࠡฬืหฦࠦ࡜࡯࡞ࡱࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ伫"))
		if choice==1: l1l111111l11_l1_ = l11l1l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭伬")
		elif choice==2: l1l111111l11_l1_ = l11l1l_l1_ (u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪ伭")
		else: l1l111111l11_l1_ = l11l1l_l1_ (u"ࠬ࠭伮")
	else:
		l1l11l1ll111_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ伯"))
		if   l1l11l1ll111_l1_==l11l1l_l1_ (u"ࠧࠨ估"): choice = 0
		elif l1l11l1ll111_l1_==l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫ伱"): choice = 1
		elif l1l11l1ll111_l1_==l11l1l_l1_ (u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ伲"): choice = 2
		l1l111111l11_l1_ = l1l11l1ll111_l1_
	if   choice==0: l11llll1lll1_l1_ = l11l1l_l1_ (u"ࠪ࠹࠺࠲࠵࠵࠶࠯࠹࠺࠻ࠧ伳")
	elif choice==1: l11llll1lll1_l1_ = l11l1l_l1_ (u"ࠫ࠺࠺࠴࠭࠷࠸࠹࠱࠻࠵ࠨ伴")
	elif choice==2: l11llll1lll1_l1_ = l11l1l_l1_ (u"ࠬ࠻࠵࠶࠮࠸࠹࠱࠻࠴࠵ࠩ伵")
	else: return
	settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ伶"),l1l111111l11_l1_)
	l11ll1lllll1_l1_ = l11l1l_l1_ (u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨ伷")+l11llll1lll1_l1_+l11l1l_l1_ (u"ࠨ࠮ࠪ伸")+l1l11lll11l1_l1_+l11l1l_l1_ (u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫ伹")
	l11ll1ll1l1l_l1_ = l11lll1l1ll1_l1_.replace(l1l11l1l1l11_l1_,l11ll1lllll1_l1_)
	if kodi_version>18.99: l11ll1ll1l1l_l1_ = l11ll1ll1l1l_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ伺"))
	open(l1l111lllll1_l1_,l11l1l_l1_ (u"ࠫࡼࡨࠧ伻")).write(l11ll1ll1l1l_l1_)
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ似"),l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࡗࡰ࡯࡮ࠡࡆࡨࡪࡦࡻ࡬ࡵ࡙ࠢ࡭ࡪࡽࡳ࠻ࠢ࡞ࠤࠬ伽")+l11llll1lll1_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ伾"))
	#time.sleep(2)
	if l1ll_l1_: xbmc.executebuiltin(l11l1l_l1_ (u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧ伿"))
	return
def l11ll1lll111_l1_():
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࠪ佀"),l11l1l_l1_ (u"ࠪ็้อࠧ佁"),l11l1l_l1_ (u"๋ࠫ฿ๅࠨ佂"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ佃"),l11l1l_l1_ (u"࠭ศา่ส้ัูࠦๆษาࠤๆ๐็ࠡ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯ࠢศ้ฬࠦรๅวุำฬืࠠใัํ้ࠥ࠴࠮࠯ࠢฦ์ࠥอๆห่้๋ࠢ๎ูࠡ็้ࠤฬูสฯัส้ࠥอไษำ้ห๊าࠠ࠯࠰࠱ࠤศ๎ࠠๅัํ็๋ࠥิไๆฬࠤศิั๊ࠢอาฺࠦฬ่ษี็ࠥษๆห๋่ࠢฬࠦสฯืࠣฬ็๐ษࠡะ็ๆࠥอไๅ้ࠣࡠࡳࡢ࡮ࠡฯส์้ࠦสฮัํฯࠥอไษำ้ห๊าࠠฤ๊ࠣหฯ฻ไࠡสส่๊ฮัๆฮ่๊ࠣ฿ัโหࠣือฮࠠศๆุ่่๊ษࠡ฻้ำ่ࠦ࠮࠯࠰๋้ࠣࠦสา์าࠤๆำีࠡษ็ฮาี๊ฬษอࠤฬ๊ย็ࠢยࠫ佄"))
	if l1ll111111_l1_==1: l1l1111l1ll1_l1_()
	return
def l11llll11l11_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ佅"),l11l1l_l1_ (u"ࠨࠩ但"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ佇"),l11l1l_l1_ (u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭佈"))
	return
def l1l111l111ll_l1_():
	l1ll111l11l_l1_ = l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣสฺัสำฺฺ๊ࠥหࠣฦ้ࠦๅฮ็าࠤู้ๆสࠢ࠵࠴࠷࠷ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ佉")
	l1ll111l11l_l1_ += l11l1l_l1_ (u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬࠫ佊")
	l1ll111l11l_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ佋")
	l1ll111l1l1_l1_ = l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟หี๋อๅอࠢืี๏฽ࠠศๆ่ื้๋ࠠ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ佌")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬ位")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ低")
	message = l11l1l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ住")+l1ll111l11l_l1_+l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩ佐")+l1ll111l1l1_l1_
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ佑"),l11l1l_l1_ (u"࠭ࠧ佒"),message)
	return
def l1l11111l11l_l1_():
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ体"),l11l1l_l1_ (u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫ佔"))
	l1l111lll1ll_l1_ = l1l11l11l1l1_l1_()
	if not l1l111lll1ll_l1_: return
	id,l1l1111l1111_l1_,l1l11ll1lll1_l1_,l11l1ll11l1_l1_,l11ll11llll1_l1_,reason = l1l111lll1ll_l1_[0]
	l11llll111ll_l1_,l1l11l1ll1l1_l1_ = l11l1ll11l1_l1_.split(l11l1l_l1_ (u"ࠩ࡟ࡲࡀࡁࠧ何"))
	l1ll111l1l1_l1_,l1lll111l1ll_l1_,l1lll111ll11_l1_ = l11ll11llll1_l1_.split(l11l1l_l1_ (u"ࠪࡠࡳࡁ࠻ࠨ佖"))
	l1l11ll11111_l1_ = l11ll11lllll_l1_
	l1l11111llll_l1_ = True
	while l1l11111llll_l1_:
		l11llll11lll_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠫࠬ佗"),l11l1l_l1_ (u"๊ࠬไศ฻อีฬ฼ࠧ佘"),l11l1l_l1_ (u"࠭ไๅลฺๅฬ๊ࠧ余"),l11l1l_l1_ (u"ࠧฯำ๋ะࠬ佚"),l11l1l_l1_ (u"ࠨๆศ๎็อแࠡษ็ษ฾๊ว็ษอࠤ็๋ࠠษ็ึัࠥฮั็ษ่ะࠥ฿ๅศั้๋ࠣࠦฬ่ษี็ࠬ佛"),l1ll111l1l1_l1_)
		if l11llll11lll_l1_==0:
			l1ll111111_l1_ = DIALOG_OK(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ作"),l11l1l_l1_ (u"ࠪ฽ํีษࠨ佝"),l11l1l_l1_ (u"ࠫฬ๊วฺฬิห฻ูࠦๅ๋้ࠣอีรࠡษ็ษ฾๊ว็ษอࠤ฿๐ัࠡไสฬ้ࠦไๅ่ๅหู࠭佞"),l1lll111l1ll_l1_)
			#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ佟"),l11l1l_l1_ (u"ู้࠭ัฬࠫ你"),l11l1l_l1_ (u"ࠧหู๊๎า࠭佡"),l11l1l_l1_ (u"ࠨษ็ห฾ะัศุࠣ฽้๏ࠠๆสาวࠥอไฦ฻็ห๋อสࠡ฼ํี่ࠥวษๆ่้ࠣ์โศึࠪ佢"),l1lll111l1ll_l1_)
			#if l1ll111111_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ佣"),l11l1l_l1_ (u"ࠪ฽ํีษࠨ佤"),l11l1l_l1_ (u"๊๊ࠫวฮฺสฮࠬ佥"),l1lll111ll11_l1_)
		if l11llll11lll_l1_==1: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭佦"),l1l11ll11111_l1_,l1l11ll11111_l1_,l11l1l_l1_ (u"࠭วิฬัำ๊ࠦ็ัษࠣหุ้ัࠡๆ็าึ๎ฬࠡ็้ࠤฬ๊ำลษ็ࠤอี่็ࠢศะฬฮษࠡษ็ืษอไ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡศ๎࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰสืฯิฯๆ้่่ࠣ๐ࠠห฻ิๅࠥอไอ๊สฬࠥอไึฯํัࡡࡴ࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ佧")+l1l11ll11111_l1_+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ佨"))
		if l11llll11lll_l1_==2: l1l11111llll_l1_ = False
	return
def l1l11l11lll1_l1_():
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ佩"),l11l1l_l1_ (u"ࠩࠪ佪"),l11l1l_l1_ (u"ࠪࠫ佫"),l11l1l_l1_ (u"ุࠫสวๅࠩ佬"),l11l1l_l1_ (u"ࠬํไࠡล้ฮ๋ࠥสฤๅาࠤํะั๋ัุ้ࠣำ้ࠠฬุๅ๏ืࠠอ็ํ฽ࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤา๐หࠡฬ฼์ิࠦฬๆ์฼ࠤฬ๊ลฺัสำฬะࠠฦๆ์ࠤํ฼ู๋หࠣฮะฮ๊หࠢส่อืๆศ็ฯࠤฤ࠭佭"))
	if l1ll111111_l1_==1:
		succeeded = True
		if os.path.exists(l11ll1lll1ll_l1_):
			try: os.remove(l11ll1lll1ll_l1_)
			except: succeeded = False
		if succeeded: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ佮"),l11l1l_l1_ (u"ࠧࠨ佯"),l11l1l_l1_ (u"ࠨࠩ佰"),l11l1l_l1_ (u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ佱"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ佲"),l11l1l_l1_ (u"ࠫࠬ佳"),l11l1l_l1_ (u"ࠬ࠭佴"),l11l1l_l1_ (u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊ส่ࠢืาࠦๅๅใࠣห้หูะษาหฯ࠭併"))
	return
def l1l1111l1lll_l1_():
	l11lllll1111_l1_()
	l1l11ll11l11_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ佶"))
	message = {}
	message[l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭佷")] = l11l1l_l1_ (u"ࠩส่่อิࠡษ็ฮ้่วว์ࠣ๎฾๋ไࠨ佸")
	message[l11l1l_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ佹")] = l11l1l_l1_ (u"ࠫฬ๊ใศึ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ佺")
	message[l11l1l_l1_ (u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭佻")] = l11l1l_l1_ (u"࠭ใศึࠣะิอࠠใืํีࠥอไๆั์ࠤ࠳ࠦࠧ佼")+str(l11ll1ll11ll_l1_/60)+l11l1l_l1_ (u"ࠧࠡัๅ๎็ฯࠠโไฺࠫ佽")
	l11lll1l111l_l1_ = message[l1l11ll11l11_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠨࠩ佾"),l11l1l_l1_ (u"ࠩๆหูࠦࠧ使")+str(l11ll1ll11ll_l1_/60)+l11l1l_l1_ (u"ࠪࠤิ่๊ใหࠪ侀"),l11l1l_l1_ (u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ侁"),l11l1l_l1_ (u"ࠬห๊ใษไࠤ่อๅๅࠩ侂"),l11lll1l111l_l1_,l11l1l_l1_ (u"࠭็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็็ฬฺࠠศๆำ็๏ࠦวๅฬ็ๆฬฬ๊ࠡล่ࠤฯื๊ะࠢศ๎็อแࠡษ็็ฬฺࠠษษ็็ฬ๋ไࠡล่ࠤฯื๊ะࠢๆหููࠦๆำ๊ࠤ็฻๊าࠢฯำฬࠦฟࠢࠩ侃"))
	if choice==0: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ侄")
	elif choice==1: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭侅")
	elif choice==2: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ來")
	else: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠪࠫ侇")
	if l11lll11lll1_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭侈"),l11lll11lll1_l1_)
		l11lll1111ll_l1_ = message[l11lll11lll1_l1_]
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭侉"),l11l1l_l1_ (u"࠭ࠧ侊"),l11l1l_l1_ (u"ࠧࠨ例"),l11lll1111ll_l1_)
	return
def l11lll1lllll_l1_():
	message = {}
	message[l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭侌")] = l11l1l_l1_ (u"ࠩึ๎ึ็ัࠡࡆࡑࡗࠥอไหๆๅหห๐๋ࠠ฻่่࠿ࠦࠧ侍")
	message[l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ侎")] = l11l1l_l1_ (u"ุࠫ๐ัโำࠣࡈࡓ࡙ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์ࡀࠠࠨ侏")
	message[l11l1l_l1_ (u"࡙ࠬࡔࡐࡒࠪ侐")] = l11l1l_l1_ (u"࠭ำ๋ำไีࠥࡊࡎࡔ่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ侑")
	l1l11l1111ll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ侒"))
	l1l11ll11l11_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ侓"))
	l11lll1l111l_l1_ = message[l1l11ll11l11_l1_]+l1l11l1111ll_l1_
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࠪ侔"),l11l1l_l1_ (u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ侕"),l11l1l_l1_ (u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ侖"),l11l1l_l1_ (u"ࠬห๊ใษไࠤ่อๅๅࠩ侗"),l11lll1l111l_l1_,l11l1l_l1_ (u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪ侘"))
	if choice==0: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠧࡂࡕࡎࠫ侙")
	elif choice==1: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭侚")
	elif choice==2: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ供")
	if choice in [0,1]:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ侜"),l11l1l_l1_ (u"ุࠫ๐ัโำ࠽ࠤࠬ依")+l11ll1llll1l_l1_[1],l11l1l_l1_ (u"ู๊ࠬาใิ࠾ࠥ࠭侞")+l11ll1llll1l_l1_[0],l11l1l_l1_ (u"࠭ࠧ侟"),l11l1l_l1_ (u"ࠧฤะอหึࠦำ๋ำไีࠥࡊࡎࡔࠢส่๊์วิส่่ࠣ࠭侠"))
		if l1ll111111_l1_==1: l1l111l1llll_l1_ = l11ll1llll1l_l1_[0]
		else: l1l111l1llll_l1_ = l11ll1llll1l_l1_[1]
	elif choice==2: l1l111l1llll_l1_ = l11l1l_l1_ (u"ࠨࠩ価")
	else: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠩࠪ侢")
	if l11lll11lll1_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ侣"),l11lll11lll1_l1_)
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ侤"),l1l111l1llll_l1_)
		l11lll1111ll_l1_ = message[l11lll11lll1_l1_]+l1l111l1llll_l1_
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭侥"),l11l1l_l1_ (u"࠭ࠧ侦"),l11l1l_l1_ (u"ࠧࠨ侧"),l11lll1111ll_l1_)
	return
def l11lllllll1l_l1_():
	l1l11ll11l11_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ侨"))
	message = {}
	message[l11l1l_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ侩")] = l11l1l_l1_ (u"ࠪห้ฮั้ๅึ๎ࠥอไหๆๅหห๐ࠠอษ๊ึ๊ࠥไฺ็็ࠫ侪")
	message[l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ侫")] = l11l1l_l1_ (u"ࠬอไษำ๋็ุ๐ࠠิ์฼้้ࠦศฺัࠣหู้ๅศฯ่ࠣ์࠭侬")
	message[l11l1l_l1_ (u"࠭ࡓࡕࡑࡓࠫ侭")] = l11l1l_l1_ (u"ࠧศๆหีํ้ำ๋่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ侮")
	l11lll1l111l_l1_ = message[l1l11ll11l11_l1_]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠨࠩ侯"),l11l1l_l1_ (u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ侰"),l11l1l_l1_ (u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ侱"),l11l1l_l1_ (u"ࠫส๐โศใࠣ็ฬ๋ไࠨ侲"),l11lll1l111l_l1_,l11l1l_l1_ (u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨ侳"))
	if choice==0: l11lll11lll1_l1_ = l11l1l_l1_ (u"࠭ࡁࡔࡍࠪ侴")
	elif choice==1: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠧࡂࡗࡗࡓࠬ侵")
	elif choice==2: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠨࡕࡗࡓࡕ࠭侶")
	else: l11lll11lll1_l1_ = l11l1l_l1_ (u"ࠩࠪ侷")
	if l11lll11lll1_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ侸"),l11lll11lll1_l1_)
		l11lll1111ll_l1_ = message[l11lll11lll1_l1_]
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ侹"),l11l1l_l1_ (u"ࠬ࠭侺"),l11l1l_l1_ (u"࠭ࠧ侻"),l11lll1111ll_l1_)
	return
def l1l111l1111l_l1_():
	l11ll1lll1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ侼"))
	if l11ll1lll1l1_l1_==l11l1l_l1_ (u"ࠨࡕࡗࡓࡕ࠭侽"): header = l11l1l_l1_ (u"ࠩอาื๐ๆࠡษ็ๆํอฦๆ่ࠢฮํ่แࠨ侾")
	else: header = l11l1l_l1_ (u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣๆ฿ไࠨ便")
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࠬ俀"),l11l1l_l1_ (u"ࠬห๊ใษไࠫ俁"),l11l1l_l1_ (u"࠭สโ฻ํ่ࠬ係"),header,l11l1l_l1_ (u"ࠧใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ์อ้ࠥะอะ์ฮ๋ฬࠦร้ฬ๋้ฬะ๊ไ์สࠤอ฿ฯࠡ࠳࠹ࠤุอูส่๊ࠢࠥษ่ๅࠢฦืฯิฯศ็ࠣ࠲࠳่ࠦฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊๊ࠦลัํࠤส๊้ࠡฬะำ๏ั็ศࠢไ๎้ࠥไࠡ็ิอࠥ๐สๆࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤ࠳࠴้้ࠠำหࠥ๐ำษสࠣฬ฼ฬࠠโ์ࠣๅฯำࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥะแฺ์็ࠤศ๋ࠠฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊ࠦฟࠢࠣࠪ促"))
	if l1ll111111_l1_==-1: return
	elif l1ll111111_l1_:
		settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࡫࡮ࡶࡵࡢࡧࡦࡩࡨࡦ࠰ࡶࡸࡦࡺࡵࡴࠩ俄"),l11l1l_l1_ (u"ࠩࠪ俅"))
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ俆"),l11l1l_l1_ (u"ࠫࠬ俇"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ俈"),l11l1l_l1_ (u"࠭สๆࠢอๅ฾๐ไࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠨ俉"))
	else:
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡴࡵࡴࡡࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ俊"),l11l1l_l1_ (u"ࠨࡕࡗࡓࡕ࠭俋"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ俌"),l11l1l_l1_ (u"ࠪࠫ俍"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ俎"),l11l1l_l1_ (u"ࠬะๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ俏"))
	return
def l11lllll11l1_l1_(text):
	if text!=l11l1l_l1_ (u"࠭ࠧ俐"):
		text = l1l1l1111l1_l1_(text)
		text = text.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ俑")).encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭俒"))
		l1l1l111l1l_l1_ = 10103
		l1l1l1111ll_l1_ = xbmcgui.l1l11lll1ll_l1_(l1l1l111l1l_l1_)
		l1l1l1111ll_l1_.getControl(311).l1l1l11l111_l1_(text)
		#l1l1111111ll_l1_ = xbmcgui.WindowXMLDialog(l11l1l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡍࡨࡽࡧࡵࡡࡳࡦ࠵࠶࠳ࡾ࡭࡭ࠩ俓"), xbmcaddon.Addon().getAddonInfo(l11l1l_l1_ (u"ࠪࡴࡦࡺࡨࠨ俔")).decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ俕")),l11l1l_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭俖"),l11l1l_l1_ (u"࠭࠷࠳࠲ࡳࠫ俗"))
		#l1l1111111ll_l1_.show()
		#l1l1111111ll_l1_.getControl(99991).setPosition(0,0)
		#l1l1111111ll_l1_.getControl(311).l1l1l11l111_l1_(text)
		#l1l1111111ll_l1_.getControl(5).l11ll11l1l11_l1_(l1l111llllll_l1_)
		#width = xbmcgui.l11lll11l1ll_l1_()
		#l1l111llll1l_l1_ = xbmcgui.l1l11111ll1l_l1_()
		#resolution = (0.0+width)/l1l111llll1l_l1_
		#l1l1111111ll_l1_.getControl(5).l1l111l11lll_l1_(width-180)
		#l1l1111111ll_l1_.getControl(5).setHeight(l1l111llll1l_l1_-180)
		#l1l1111111ll_l1_.doModal()
		#del l1l1111111ll_l1_
	return
l11ll1ll111l_l1_ = [
			 l11l1l_l1_ (u"ࠢࡦࡺࡷࡩࡳࡹࡩࡰࡰࠣࠫࠬࠦࡩࡴࠢࡱࡳࡹࠦࡣࡶࡴࡵࡩࡳࡺ࡬ࡺࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠧ俘")
			,l11l1l_l1_ (u"ࠨࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡪࡴࡸࠠࡎࡣ࡯࡭ࡨ࡯࡯ࡶࡵࠣࡷࡨࡸࡩࡱࡶࡶࠫ俙")
			,l11l1l_l1_ (u"ࠩࡓ࡚ࡗࠦࡉࡑࡖ࡙ࠤࡘ࡯࡭ࡱ࡮ࡨࠤࡈࡲࡩࡦࡰࡷࠫ俚")
			,l11l1l_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤ࡛࡯ࡤࡦࡱࠣࡍࡳ࡬࡯ࠡࡍࡨࡽࠬ俛")
			,l11l1l_l1_ (u"ࠫࡹ࡮ࡩࡴࠢ࡫ࡥࡸ࡮ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢ࡬ࡷࠥࡨࡲࡰ࡭ࡨࡲࠬ俜")
			,l11l1l_l1_ (u"ࠬࡻࡳࡦࡵࠣࡴࡱࡧࡩ࡯ࠢࡋࡘ࡙ࡖࠠࡧࡱࡵࠤࡦࡪࡤ࠮ࡱࡱࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࠧ保")
			,l11l1l_l1_ (u"࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡷࡶࡥ࡬࡫࠮ࡩࡶࡰࡰࠨࡹࡳ࡭࠯ࡺࡥࡷࡴࡩ࡯ࡩࡶࠫ俞")
			,l11l1l_l1_ (u"ࠧࡊࡰࡶࡩࡨࡻࡲࡦࡔࡨࡵࡺ࡫ࡳࡵ࡙ࡤࡶࡳ࡯࡮ࡨ࠮ࠪ俟")
			,l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅ࠱ࡂࡱࡴࡪࡥ࠾࠲ࠩࡸࡪࡾࡴ࠾ࠩ俠")
			,l11l1l_l1_ (u"ࠩࡺࡥࡷࡴࡩ࡯ࡩࡶ࠲ࡼࡧࡲ࡯ࠪࠪ信")
			,l11l1l_l1_ (u"ࠪࡢࡣࡤ࡞࡟ࠩ俢")
			,l11l1l_l1_ (u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ俣")
			]
def l11llll111l1_l1_(line):
	if l11l1l_l1_ (u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪ俤") in line and l11l1l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ俥") in line: return True
	for text in l11ll1ll111l_l1_:
		if text in line: return True
	return False
def l11ll11l1ll1_l1_(data):
	data = data.replace(l11l1l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ俦")+l11l1l_l1_ (u"ࠨࠢࠪ俧")*51+l11l1l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ俨"),l11l1l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ俩"))
	data = data.replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ俪")+l11l1l_l1_ (u"ࠬࠦࠧ俫")*51+l11l1l_l1_ (u"࠭࡜ࡳ࡞ࡱࠫ俬"),l11l1l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ俭"))
	data = data.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ修")+l11l1l_l1_ (u"ࠩࠣࠫ俯")*51+l11l1l_l1_ (u"ࠪࡠࡳ࠭俰"),l11l1l_l1_ (u"ࠫࡡࡴࠧ俱"))
	#data = data.replace(l11l1l_l1_ (u"ࠬࠦࠠࠡࠢࠣࡊ࡮ࡲࡥࠡࠤ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰࠰ࡃࡱࡨࡷࡵࡩࡥ࠱ࡧࡥࡹࡧ࠯ࡰࡴࡪ࠲ࡽࡨ࡭ࡤ࠰࡮ࡳࡩ࡯࠯ࡧ࡫࡯ࡩࡸ࠵࠮࡬ࡱࡧ࡭࠴ࡧࡤࡥࡱࡱࡷ࠴࠭俲"),l11l1l_l1_ (u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠫ俳"))
	data = data.replace(l11l1l_l1_ (u"ࠧࠡ࠾ࡪࡩࡳ࡫ࡲࡢ࡮ࡁ࠾ࠥ࠭俴"),l11l1l_l1_ (u"ࠨ࠼ࠣࠫ俵"))
	l11l1llll_l1_ = l11l1l_l1_ (u"ࠩࠪ俶")
	for line in data.splitlines():
		delete = re.findall(l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ俷"),line,re.DOTALL)
		if delete: line = line.replace(delete[0],l11l1l_l1_ (u"ࠫࠬ俸"))
		l11l1llll_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮ࠨ俹")+line
	#WRITE_THIS(l11l1l_l1_ (u"࠭ࠧ俺"),l11l1llll_l1_)
	return l11l1llll_l1_
def l11ll1l1l1ll_l1_(l1l111111l1l_l1_):
	if l11l1l_l1_ (u"ࠧࡐࡎࡇࠫ俻") in l1l111111l1l_l1_:
		l1l11l111l11_l1_ = l11ll1l11l11_l1_
		header = l11l1l_l1_ (u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨ俼")
	else:
		l1l11l111l11_l1_ = l1l11l11ll1l_l1_
		header = l11l1l_l1_ (u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩ俽")
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࠫ俾"),l11l1l_l1_ (u"ࠫࠬ俿"),l11l1l_l1_ (u"ࠬ࠭倀"),header,l11l1l_l1_ (u"࠭ำอๆࠣห้ษฮุษฤࠤ๏ำส้์ࠣว๏฼วࠡ฻็ํูࠥฬๅࠢส่ฬูสฯัส้ࠥ࠴้ࠠษ็หะ์๊็ูࠢีํื๊สࠢ็้฾ืแสࠢๆ๎ๆࠦอะออࠤฬ๊ๅีๅ็อࠥ๎ๅศ๊ࠢ์ࠥอไๆๅส๊ࠥอไั์ࠣือฮࠠฮั๋ฯࠥอไๆึๆ่ฮࠦ࠮ࠡๅ๋ำ๏๊ࠦฮฬไ฼ࠥฮำอๆํ๊ࠥ࠴ࠠศๆฦ์้ࠦ็้ࠢสุ่าไࠡษ็ัฬ๊๊๊ࠡไ๎์ࠦๅฺๆ๋้ฬะࠠหสาว๋ࠥๆัࠢหำฬ๐ษࠡษ็ฮูเ๊ๅࠢส่าอไ๋ࠢ็ฬึ์วๆฮࠣ็ํี๊๊ࠡส่๎ࠦวๅฤ้ࠤ࠳ࠦรๆษࠣหู้ฬๅࠢส่็ี๊ๆࠢไ๋ํࠦวๅีฯ่ࠥอไิษหๆࠥอไั์ࠣฮ๊ࠦฬๆ฻๊ࠤ๊์ࠠษำ้ห๊าࠠไ๊า๎่ࠥศๅࠢลาึࠦลุใสล๊ࠥ็ࠡ࠰๋้ࠣࠦสา์าࠤฬ๊วิฬ่ีฬืࠠภࠩ倁"))
	if l1ll111111_l1_!=1: return
	l11ll11lll11_l1_,counts = [],0
	size,count = l1l11llll1_l1_(l1l11l111l11_l1_)
	#size = os.path.getsize(l1l11l111l11_l1_)
	file = open(l1l11l111l11_l1_,l11l1l_l1_ (u"ࠧࡳࡤࠪ倂"))
	if size>100200: file.seek(-100100,os.SEEK_END)
	data = file.read()
	file.close()
	if kodi_version>18.99: data = data.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭倃"))
	data = l11ll11l1ll1_l1_(data)
	lines = data.split(l11l1l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ倄"))
	for line in reversed(lines):
		#if kodi_version>18.99: line = line.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ倅"))
		#if line.strip(l11l1l_l1_ (u"ࠫࠥ࠭倆"))==l11l1l_l1_ (u"ࠬ࠭倇"): continue
		ignore = l11llll111l1_l1_(line)
		if ignore: continue
		line = line.replace(l11l1l_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡤ࠭倈"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ倉"))
		line = line.replace(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࠺ࠨ倊"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌ࠰࠱࠲࠳ࡡࡊࡘࡒࡐࡔ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠬ個"))
		l11ll1ll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠬࠬࡡࡪࠫ࠮࡞ࡧ࠯ࠥࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪ倌"),line,re.DOTALL)
		l1l11111l111_l1_ = l11l1l_l1_ (u"ࠫࠬ倍")
		if l11ll1ll1111_l1_:
			line = line.replace(l11ll1ll1111_l1_[0][0],l11l1l_l1_ (u"ࠬ࠭倎")).replace(l11ll1ll1111_l1_[0][2],l11l1l_l1_ (u"࠭ࠧ倏"))
			l1l11111l111_l1_ = l11ll1ll1111_l1_[0][1]
		else:
			l11ll1ll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ倐"),line,re.DOTALL)
			if l11ll1ll1111_l1_:
				line = line.replace(l11ll1ll1111_l1_[0][1],l11l1l_l1_ (u"ࠨࠩ們"))
				l1l11111l111_l1_ = l11ll1ll1111_l1_[0][0]
		if l1l11111l111_l1_: line = line.replace(l1l11111l111_l1_,l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ倒")+l1l11111l111_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ倓"))
		l11ll11lll11_l1_.append(line)
		if len(str(l11ll11lll11_l1_))>50100: break
	l11ll11lll11_l1_ = reversed(l11ll11lll11_l1_)
	l1l111llllll_l1_ = l11l1l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ倔").join(l11ll11lll11_l1_)
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠬࡲࡥࡧࡶࠪ倕"),l11l1l_l1_ (u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪ倖"),l1l111llllll_l1_,l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ倗"))
	return
def l11ll1l1llll_l1_():
	l1l11l111l1l_l1_ = open(l1l11111l1l1_l1_,l11l1l_l1_ (u"ࠨࡴࡥࠫ倘")).read()
	if kodi_version>18.99: l1l11l111l1l_l1_ = l1l11l111l1l_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ候"))
	l1l11l111l1l_l1_ = l1l11l111l1l_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡹ࠭倚"),l11l1l_l1_ (u"ࠫࠥࠦࠠࠡࠢࠣࠤࠥ࠭倛"))
	l1l1l1l111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡶ࡝ࡦ࠱࠮ࡄ࠯࡛࡝ࡰ࡟ࡶࡢ࠭倜"),l1l11l111l1l_l1_,re.DOTALL)
	for line in l1l1l1l111ll_l1_:
		l1l11l111l1l_l1_ = l1l11l111l1l_l1_.replace(line,l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ倝")+line+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ倞"))
	DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ࠨษ็ฮ฿๐๊าษอࠤฬ๊รฯ์ิอࠥ็๊ࠡษ็ฬึอๅอࠩ借"),l1l11l111l1l_l1_)
	return
def l1l111l11111_l1_():
	l1ll111l11l_l1_ = l11l1l_l1_ (u"ࠩห฽฻ࠦวๅลีีฬืฺࠠๆ์ࠤฬ๊ั๋็๋ฮ้่ࠥ็ฬิ์้ࠦส้ใิࠤส๋ใศ่ํอࠥะโะ์่ࠤํะรฯ์ิࠤฬ๊แ๋ัํ์ࠥ๎็ั้ࠣห้ษาาษิࠤ์๐ࠠศๆฦื์๋้ࠠษ็วึ่วๆ่ࠢ฽ࠥฮูื๋ࠢ็ฬ๊สศๆํࠫ倠")
	l1ll111l1l1_l1_ = l11l1l_l1_ (u"่ࠪฯ่ฯ๋็ࠣห้็๊ะ์๋ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ๅ๋่ࠣ์้ะรฯ์ิ๋ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ิษิࠤ࠳ࠦรๆษࠣ฽ิฯࠠศี๊้๋ࠥสหษ็๎ฮࠦแ่า๊ࠤฯ่่ๆࠢหฮาื๊ไࠢส่ๆ๐ฯ๋๊ࠣฬํ่สࠡษๆฬึࠦๅ็๋ࠢๆฯࠦวๅี๊้ࠥอไ้ษะำࠥ࠴ࠠฤ็สࠤฬ๊ำ่็ࠣห้ษูๅ๋ࠣ์ฬ๊ริใ็ࠤๆํ่ࠡ์ะี่ࠦวๅใํำ๏๎ࠠฦๆ์ࠤฬ๊รๆษ่ࠤศ๎ࠠฦๆ์ࠤฬ๊่าษฤࠤํ๊ใ็ࠢหๆๆุษࠡๅห๎ึฯࠧ倡")
	l1lll111l1ll_l1_ = l11l1l_l1_ (u"ࠫศ๋วࠡษ็วึ่วๆࠢไ๋๏ࠦสิฬัำ๊ࠦไๅฬๅำ๏๋้ࠠษ็ฮศิ๊า๋่่ࠢ์ࠠษ็ๅำฬืฺࠠัาࠤฬ๊ห้ษ้๎ࠥ๎วๅัๅหห่ࠠ࠯่ࠢฯ้อࠠาไ่ࠤ࠺࠺࠴ࠡฬ฼๊๏ࠦ࠵ࠡัๅหห่้ࠠࠢ࠷࠸ࠥัว็์ฬࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอมࠡสะือࠦวิฬัำฬ๋ใࠡๆ็ื์๋ࠠศๆํ้๏์ࠠฤ๊ࠣื์๋ࠠศๆํืฬืࠧ倢")
	message = l1ll111l11l_l1_+l11l1l_l1_ (u"ࠬࡀࠠࠨ倣")+l1ll111l1l1_l1_+l11l1l_l1_ (u"࠭ࠠ࠯ࠢࠪ値")+l1lll111l1ll_l1_
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ倥"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ倦"),message,l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ倧"))
	return
def l1llll1l1l11_l1_(l1ll11l1lll1_l1_,message,l1ll_l1_=True,url=l11l1l_l1_ (u"ࠪࠫ倨"),source=l11l1l_l1_ (u"ࠫࠬ倩"),text=l11l1l_l1_ (u"ࠬ࠭倪"),l1llll1111ll_l1_=l11l1l_l1_ (u"࠭ࠧ倫")):
	if l11l1l_l1_ (u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪ倬") in text: l1l1l11lll1l_l1_ = True
	else: l1l1l11lll1l_l1_ = False
	l11ll11l1111_l1_ = True
	if not l11lll1lll11_l1_(l11l1l_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ倭")):
		if l1ll_l1_:
			#if message.count(l11l1l_l1_ (u"ࠩ࡟ࡠࡳ࠭倮"))>1: l11ll1llllll_l1_ = l11l1l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ倯")
			#else: l11ll1llllll_l1_ = l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ倰")
			l11ll1llll11_l1_ = (l11l1l_l1_ (u"ࠬอไิูิ࠾ࠬ倱") in message and l11l1l_l1_ (u"࠭วๅ็ๆห๋ࡀࠧ倲") in message and l11l1l_l1_ (u"ࠧศๆ่่ๆࡀࠧ倳") in message and l11l1l_l1_ (u"ࠨษ็า฼ษࠧ倴") in message and l11l1l_l1_ (u"ࠩส่๊฻ฯา࠼ࠪ倵") in message)
			if not l11ll1llll11_l1_: l11ll11l1111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ倶"),l11l1l_l1_ (u"ࠫࠬ倷"),l11l1l_l1_ (u"ࠬ࠭倸"),l11l1l_l1_ (u"࠭็ๅࠢอีุ๊่ࠠา๊ࠤฬ๊ัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ倹"),message.replace(l11l1l_l1_ (u"ࠧ࡝࡞ࡱࠫ债"),l11l1l_l1_ (u"ࠨ࡞ࡱࠫ倻")))
	elif l1ll_l1_:
		message = l11l1l_l1_ (u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩ值")
		l1l11ll11lll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ倽"),l11l1l_l1_ (u"ࠫࠬ倾"),l11l1l_l1_ (u"ࠬ࠭倿"),l11l1l_l1_ (u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭偀")+l11l1l_l1_ (u"ࠧࠡࠢ࠴࠳࠺࠭偁"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭偂"))
		l1l11ll11ll1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ偃"),l11l1l_l1_ (u"ࠪࠫ偄"),l11l1l_l1_ (u"ࠫࠬ偅"),l11l1l_l1_ (u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ偆")+l11l1l_l1_ (u"࠭ࠠࠡ࠴࠲࠹ࠬ假"),l11l1l_l1_ (u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ偈"))
		l1l11ll11l1l_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ偉"),l11l1l_l1_ (u"ࠩࠪ偊"),l11l1l_l1_ (u"ࠪࠫ偋"),l11l1l_l1_ (u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ偌")+l11l1l_l1_ (u"ࠬࠦࠠ࠴࠱࠸ࠫ偍"),l11l1l_l1_ (u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ偎"))
		l1l11ll1l1ll_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ偏"),l11l1l_l1_ (u"ࠨࠩ偐"),l11l1l_l1_ (u"ࠩࠪ偑"),l11l1l_l1_ (u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ偒")+l11l1l_l1_ (u"ࠫࠥࠦ࠴࠰࠷ࠪ偓"),l11l1l_l1_ (u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ偔"))
		l11ll11l1111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭偕"),l11l1l_l1_ (u"ࠧࠨ偖"),l11l1l_l1_ (u"ࠨࠩ偗"),l11l1l_l1_ (u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩ偘")+l11l1l_l1_ (u"ࠪࠤࠥ࠻࠯࠶ࠩ偙"),l11l1l_l1_ (u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ做"))
	if l11ll11l1111_l1_!=1:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭偛"),l11l1l_l1_ (u"࠭ࠧ停"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ偝"),l11l1l_l1_ (u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠤอ์วยࠢ฼่๎ࠦืๅสๆࠫ偞"))
		return False
	l1l11ll1ll11_l1_ = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠣ偟") )
	message += l11l1l_l1_ (u"ࠪࠤࡡࡢ࡮࡝࡞ࡱࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࠤࡡࡢ࡮ࡂࡦࡧࡳࡳࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩ偠")+addon_version+l11l1l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࠪ偡")
	message += l11l1l_l1_ (u"ࠬࡋ࡭ࡢ࡫࡯ࠤࡘ࡫࡮ࡥࡧࡵ࠾ࠥ࠭偢")+l1l11ll1lll_l1_(32)+l11l1l_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࡐࡵࡤࡪ࡙ࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࠬ偣")+kodi_release+l11l1l_l1_ (u"ࠧࠡ࠼࡟ࡠࡳ࠭偤")
	message += l11l1l_l1_ (u"ࠨࡍࡲࡨ࡮ࠦࡎࡢ࡯ࡨ࠾ࠥ࠭健")+l1l11ll1ll11_l1_
	#l11lllllll11_l1_ = l11ll11ll111_l1_(l11l1l_l1_ (u"ࠩ࠺࠺࠳࠼࠵࠯࠳࠶࠼࠳࠸࠳࠱ࠩ偦"))
	l11llll1l111_l1_ = l11ll11ll111_l1_()
	l11llll1l111_l1_ = QUOTE(l11llll1l111_l1_)
	if l11llll1l111_l1_: message += l11l1l_l1_ (u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬ偧")+l11llll1l111_l1_
	if url: message += l11l1l_l1_ (u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨ偨")+url
	if source: message += l11l1l_l1_ (u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬ偩")+source
	message += l11l1l_l1_ (u"࠭ࠠ࠻࡞࡟ࡲࠬ偪")
	if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠧอษิ๎ࠥอไฦำึห้࠭偫"),l11l1l_l1_ (u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪ偬"))
	if l1llll1111ll_l1_:
		l1l111llllll_l1_ = l1llll1111ll_l1_
		if kodi_version>18.99: l1l111llllll_l1_ = l1l111llllll_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ偭"))
		l1l111llllll_l1_ = base64.b64encode(l1l111llllll_l1_)
	elif l1l1l11lll1l_l1_:
		if l11l1l_l1_ (u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤࡕࡌࡅࡡࠪ偮") in text: l1l11ll111l1_l1_ = l11ll1l11l11_l1_
		else: l1l11ll111l1_l1_ = l1l11l11ll1l_l1_
		if not os.path.exists(l1l11ll111l1_l1_):
			DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ偯"),l11l1l_l1_ (u"ࠬ࠭偰"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ偱"),l11l1l_l1_ (u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬ偲"))
			return False
		l11ll11lll11_l1_,counts = [],0
		size,count = l1l11llll1_l1_(l1l11ll111l1_l1_)
		#size = os.path.getsize(l1l11ll111l1_l1_)
		file = open(l1l11ll111l1_l1_,l11l1l_l1_ (u"ࠨࡴࡥࠫ偳"))
		if size>250200: file.seek(-250100,os.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ側"))
		data = l11ll11l1ll1_l1_(data)
		lines = data.splitlines()
		for line in reversed(lines):
			#if kodi_version>18.99: line = line.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ偵"))
			ignore = l11llll111l1_l1_(line)
			if ignore: continue
			l11ll1ll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡣ࠮࡜ࡥ࠭࠰࠭࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ偶"),line,re.DOTALL)
			if l11ll1ll1111_l1_:
				line = line.replace(l11ll1ll1111_l1_[0][0],l11l1l_l1_ (u"ࠬ࠭偷")).replace(l11ll1ll1111_l1_[0][2],l11l1l_l1_ (u"࠭ࠧ偸"))
			else:
				l11ll1ll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡟ࠪ࡟ࡨ࠰ࡀ࡜ࡥ࠭࠽ࡠࡩ࠱࡜࠯࡞ࡧ࠯࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ偹"),line,re.DOTALL)
				if l11ll1ll1111_l1_: line = line.replace(l11ll1ll1111_l1_[0][1],l11l1l_l1_ (u"ࠨࠩ偺"))
			l11ll11lll11_l1_.append(line)
			if len(str(l11ll11lll11_l1_))>121000: break
		l11ll11lll11_l1_ = reversed(l11ll11lll11_l1_)
		l1l111llllll_l1_ = l11l1l_l1_ (u"ࠩ࡟ࡶࡡࡴࠧ偻").join(l11ll11lll11_l1_)
		l1l111llllll_l1_ = l1l111llllll_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ偼"))
		l1l111llllll_l1_ = base64.b64encode(l1l111llllll_l1_)
	else: l1l111llllll_l1_ = l11l1l_l1_ (u"ࠫࠬ偽")
	url = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ偾")][2]
	payload = {l11l1l_l1_ (u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ偿"):l1ll11l1lll1_l1_,l11l1l_l1_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ傀"):message,l11l1l_l1_ (u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩ傁"):l1l111llllll_l1_}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ傂"),url,payload,l11l1l_l1_ (u"ࠪࠫ傃"),l11l1l_l1_ (u"ࠫࠬ傄"),l11l1l_l1_ (u"ࠬ࠭傅"),l11l1l_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡕࡈࡒࡉࡥࡅࡎࡃࡌࡐ࠲࠷ࡳࡵࠩ傆"))
	#succeeded = response.succeeded
	html = response.content
	if l11l1l_l1_ (u"ࠧࠣࡵࡸࡧࡨ࡫ࡥࡥࡧࡧࠦ࠿ࠦ࠱࠭ࠩ傇") in html: succeeded = True
	else: succeeded = False
	if l1ll_l1_:
		if succeeded:
			l1llll1l_l1_(l11l1l_l1_ (u"ࠨฬ่ࠤฬ๊ลาีส่ࠬ傈"),l11l1l_l1_ (u"ࠩห๊ัออࠨ傉"))
			DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ傊"),l11l1l_l1_ (u"ࠫࠬ傋"),l11l1l_l1_ (u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫ傌"),l11l1l_l1_ (u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨ傍"))
		else:
			l1llll1l_l1_(l11l1l_l1_ (u"ࠧๅๆฦืๆ࠭傎"),l11l1l_l1_ (u"ࠨใื่ࠥ็๊ࠡษ็ษึูวๅࠩ傏"))
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ傐"),l11l1l_l1_ (u"ࠪࠫ傑"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ傒"),l11l1l_l1_ (u"ࠬิืฤ๋ࠢๅู๊ࠠโ์ࠣษึูวๅࠢส่ึูวๅหࠪ傓"))
	return succeeded
def l11ll11l11l1_l1_():
	l1ll111l11l_l1_ = l11l1l_l1_ (u"࠭࠱࠯ࠢࠣࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡳࡶࡴࡨ࡬ࡦ࡯ࠣࡻ࡮ࡺࡨࠡࡃࡵࡥࡧ࡯ࡣࠡࡶࡨࡼࡹࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠠࡵࡱࠣࠦࡆࡸࡩࡢ࡮ࠥࠫ傔")
	l1ll111l1l1_l1_ = l11l1l_l1_ (u"ࠧ࠲࠰ࠣࠤࠥหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢส่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩ傕")
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ傖"),l11l1l_l1_ (u"ࠩࠪ傗"),l11l1l_l1_ (u"ࠪࡅࡷࡧࡢࡪࡥࠣࡔࡷࡵࡢ࡭ࡧࡰࠫ傘"),l1ll111l11l_l1_+l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ備")+l1ll111l1l1_l1_)
	l1ll111l11l_l1_ = l11l1l_l1_ (u"ࠬ࠸࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡢࡰࡧࠤࡹ࡮ࡥ࡯ࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡦࡰࡰࡷࠫ傚")
	l1ll111l1l1_l1_ = l11l1l_l1_ (u"࠭࠲࠯ࠢࠣࠤสึวࠡๆ่ࠤฯาฯࠡษ็า฼ࠦࠢࡂࡴ࡬ࡥࡱࠨࠠโไ่ࠤอะฺ๋์ิࠤฬ๊ฬๅัࠣฯ๊ࠦโๆࠢหฮ฿๐ัࠡษ็า฼ࠦวๅ็ึฮำีๅࠡษ็ํࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭傛")
	DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ傜"),l11l1l_l1_ (u"ࠨࠩ傝"),l11l1l_l1_ (u"ࠩࡉࡳࡳࡺࠠࡑࡴࡲࡦࡱ࡫࡭ࠨ傞"),l1ll111l11l_l1_+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ傟")+l1ll111l1l1_l1_)
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ傠"),l11l1l_l1_ (u"ࠬ࠭傡"),l11l1l_l1_ (u"࠭ࠧ傢"),l11l1l_l1_ (u"ࠧࡇࡱࡱࡸࠥࡹࡥࡵࡶ࡬ࡲ࡬ࡹࠧ傣"),l11l1l_l1_ (u"ࠨࡆࡲࠤࡾࡵࡵࠡࡹࡤࡲࡹࠦࡴࡰࠢࡪࡳࠥࡺ࡯ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦ࡮ࡰࡹࠣࡃࠬ傤")+l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴࠧ傥")+l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤฬ๊ะ่ษหࠤส๊้ࠡๆ๋ัฮࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤศ๊ย็มࠪ傦"))
	if l1ll111111_l1_==1: l1l11l111111_l1_()
	return
def l1l11lll1l11_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ傧"),l11l1l_l1_ (u"ࠬ࠭储"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ傩"),l11l1l_l1_ (u"ࠧ฻ษ็ฬฬࠦวๅีหฬࠥํ่ࠡ็้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤฬ๊ๅ฻าํࠤ้๊ศา่ส้ั่ࠦๅๆอว่ีࠠใ็ࠣฬฯฺฺ๋ๆࠣห้ืวษูࠣห้ึ๊ࠡๆสࠤ๏฿ๅๅࠢฮ้่ࠥๅࠡสศีุอไࠡ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะ๋ࠥๆࠡษ็ๆฬฬๅสࠢส่ึฬ๊ิ์ฬࠤ้๊ศา่ส้ั࠭傪"))
	return
def l1l11l1l1111_l1_():
	message = l11l1l_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๆะุูࠥ็โุࠢ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡ็็๋ࠦ็ัษ่ࠣฬ๊ࠦๆ่฼ࠤํา่ะ่ࠢ์ฬู่ࠡใํ๋ฬࠦรโๆส้ࠥ๎ๅิๆึ่ฬะࠠๆฬิะ๊ฯࠠฤ๊้ࠣิฮไอหࠣษ้๏ࠠศๆ็฾ฮࠦวๅ฻ิฬ๏ฯ้ࠠษ็ํฺ๊ࠥศฬࠣหำื้๊ࠡ็หࠥ๐่อัࠣือฮࠠๅๆอ็ึอัࠨ傫")
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ催"),l11l1l_l1_ (u"ࠪࠫ傭"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ傮"),message)
	return
def l11llllll111_l1_():
	message = l11l1l_l1_ (u"ࠬอไา๊สฬ฼ࠦวๅสฺ๎หฯࠠๅษࠣ฽้อโสࠢ็๋ฬࠦศศๆหี๋อๅอ๋ࠢ฾ฬ๊ศศࠢสุ่ฮศ้๋ࠡࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠศๆ่฾ี๐ࠠๅๆหี๋อๅอࠩ傯")
	DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ傰"),l11l1l_l1_ (u"ࠧࠨ傱"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ傲"),message)
	return
def l11ll111llll_l1_():
	message = l11l1l_l1_ (u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭傳")
	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ傴"),l11l1l_l1_ (u"ࠫࠬ債"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ傶"),l11l1l_l1_ (u"࠭ำ๋ำไีฬะࠠิ์ษอࠥษ่ࠡ็ฯ๋ํ๊ษࠨ傷"),message)
	return
def l1l11l11111l_l1_():
	message = l11l1l_l1_ (u"ࠧศๆึ๎ึ็ัศฬࠣห้฿วๆห๋ࠣ๏ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ้ࠠ฼ํีࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤําๅ๋฻ࠣห้๋่ศไ฼ࠤฯูสฯั่๋ฬฺ่ࠦษาอࠥะใ้่้ࠣัอๆ๋หࠣ์ฺ๊วไๆ๊ห้ࠥห๋ำฬࠤ้อๆࠡษ็ๅ๏ี๊้้สฮࠥ็๊่ษࠣษ๊อࠠษูํสฮࠦร้่้๋ࠢ๎ูสࠢฦ์๋ࠥอั๊ไอࠥษ่ࠡใํ๋ฬࠦๅีๅ็อࠥำโ้ไࠣห้๋ไไ์ฬࡠࡳࡢ࡮࡝ࡰสุ่๐ัโำสฮࠥอไฯษุอࠥํ๊ࠡีํีๆืวหࠢอหอ฿ษࠡๆ็้ํู่ࠡษ็วฺ๊๊๊่ࠡืฯิฯๆหࠣๅ๏ࠦๅ้ษๅ฽่ࠥไ๋ๆฬࠤัีว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฯโ๊฼อࠥอไฤฮิࠤศ๎๋ࠠ็็็์อࠠศๆ่์็฿ࠠศๆฦู้๐้ࠠๆ๊ิฬࠦแ่์ࠣะ๏ีษ่ࠡึฬ๏อ้ࠠีิ๎฾ฯ้ࠠ็ืห่๊็ศࠢๅ่๏๊ษࠡฮาหࠬ傸")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ傹"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ傺"),message,l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭傻"))
	return
def l1l1111l111l_l1_():
	l1ll111l11l_l1_ = l11l1l_l1_ (u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไะไฬࠤฬู๊ศๆํอࠬ傼")
	l1ll111l1l1_l1_ = l11l1l_l1_ (u"ࠬอศห฻าࠤ฾์ࠠๆๆไหฯࠦรๅࠢࡰ࠷ࡺ࠾ࠧ傽")
	l1lll111l1ll_l1_ = l11l1l_l1_ (u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆอั๊๐ไ๊ࠡส่ิอ่็ๆ๋ำࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ傾")
	DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ傿"),l11l1l_l1_ (u"ࠨࠩ僀"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ僁"),l1ll111l11l_l1_,l1ll111l1l1_l1_,l1lll111l1ll_l1_)
	return
def l11lllll1111_l1_():
	l1ll111l1l1_l1_ = l11l1l_l1_ (u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫ僂")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ僃") + l11l1l_l1_ (u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ僄") + str(PERMANENT_CACHE/60/60/24/30) + l11l1l_l1_ (u"࠭ࠠี้ิࠫ僅")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ僆") + l11l1l_l1_ (u"ࠨ࠴࠱ࠤัีวู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅ็ไีํ฼ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ื้ࠠ็าฮ์ࠦࠧ僇") + str(VERYLONG_CACHE/60/60/24) + l11l1l_l1_ (u"ࠩࠣ๎ํ๋ࠧ僈")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠪࡠࡳ࠭僉") + l11l1l_l1_ (u"ࠫ࠸࠴ุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์๊ࠣฬีัศࠢอฮ฿๐ั๊่ࠡำฯํࠠࠨ僊") + str(l1llll11_l1_/60/60/24) + l11l1l_l1_ (u"๊้ࠬࠦ็ࠪ僋")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"࠭࡜࡯ࠩ僌") + l11l1l_l1_ (u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ働") + str(REGULAR_CACHE/60/60) + l11l1l_l1_ (u"ࠨࠢึห฾ฯࠧ僎")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ像") + l11l1l_l1_ (u"ࠪ࠹࠳ࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡัสส๊อ้ࠠ็าฮ์ࠦࠧ僐") + str(l1ll1l1ll_l1_/60/60) + l11l1l_l1_ (u"ูࠫࠥวฺหࠪ僑")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮ࠨ僒") + l11l1l_l1_ (u"࠭࠶࠯ࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ส๋ࠢอฮ฿๐ัࠡๅฮ๎ึอ้ࠠ็าฮ์ࠦࠧ僓") + str(l1111ll1l11_l1_/60) + l11l1l_l1_ (u"ࠧࠡัๅ๎็ฯࠧ僔")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱࠫ僕") + l11l1l_l1_ (u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫ僖") + str(NO_CACHE) + l11l1l_l1_ (u"ࠪࠤิ่๊ใหࠪ僗")
	l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ僘") + l11l1l_l1_ (u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩ僙") + str(REGULAR_CACHE/60/60) + l11l1l_l1_ (u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬࠦࠧ僚") + str(l1llll11_l1_/60/60/24) + l11l1l_l1_ (u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭僛") + str(l1ll1l1ll_l1_/60/60) + l11l1l_l1_ (u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬ僜") + str(l1111ll1l11_l1_/60) + l11l1l_l1_ (u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫ僝") + str(NO_CACHE) + l11l1l_l1_ (u"ࠪࠤิ่๊ใหࠪ僞")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠫࡷ࡯ࡧࡩࡶࠪ僟"),l11l1l_l1_ (u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ僠"),l1ll111l1l1_l1_,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ僡"))
	return
def l11ll1ll1l11_l1_():
	message = l11l1l_l1_ (u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ僢")
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ僣"),l11l1l_l1_ (u"ࠩࠪ僤"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭僥"),message)
	return
def l11lll111ll1_l1_():
	message = l11l1l_l1_ (u"ࠫสึว๊ࠡสะ์ะใࠡ็ื็้ฯࠠโ์ࠣหฺ้ศไหࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢฦ์ࠥอๆไࠢอ฼๋ࠦร็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢๆห๋ࠦแู๋้้้ࠣไส่ࠢศ็ะ็๊ࠡอ้ࠥำไ่ษࠣ࠲࠳࠴ࠠโวำ๊ࠥาัษ่ࠢืาࠦใศึࠣห้ฮั็ษ่ะ๊ࠥใ๋ࠢํๆํ๋ࠠศๆหี๋อๅอࠢห฻้ฮࠠศๆุๅาฯࠠศๆุั๏ำษ๊ࠡอาื๐ๆ่ษࠣฬิ๊วࠡ็้ࠤฬ๊ีโฯฬࠤฬ๊โะ์่อࠬ僦")
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭僧"),l11l1l_l1_ (u"࠭ࠧ僨"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ僩"),message)
	return
def l1l111l11l11_l1_():
	message = l11l1l_l1_ (u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬ僪")
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ僫"),l11l1l_l1_ (u"ࠪࠫ僬"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ僭"),message)
	return
def l11lll11111l_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭僮"),l11l1l_l1_ (u"࠭ࠧ僯"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ僰"),l11l1l_l1_ (u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭僱"))
	l1l1111lllll_l1_(l11l1l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ僲"),True)
	return
def l11lll1ll111_l1_():
	message  = l11l1l_l1_ (u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ僳")
	#message += l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞๊๊ิฬࠦวๅ฻สส็ࠦ็้ࠢࡵࡩࡈࡇࡐࡕࡅࡋࡅࠥอไฯษุࠤอฺัไหࠣะําไ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ僴")
	#message += l11l1l_l1_ (u"ࠬ๎วๅาํࠤฺ์ูหุ้ࠣึ้ษࠡฮ๋ะ้ࠦฮึ์ุห๊ࠥๅ็฻ࠣฬึอๅอ่ࠢฯ้ࠦใ้ัํࠤ๊์ࠠหืไัࠥอไฦ่อี๋ะࠧ僵")
	message += l11l1l_l1_ (u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭僶")
	message += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡๅࠦࠠࡗࡒࡑࠤࠥษ่ࠡࠢࡓࡶࡴࡾࡹࠡࠢฦ์ࠥࠦࡄࡏࡕࠣࠤศ๎ࠠฤ์ࠣั้ࠦศิ์ฺࠤวิั࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࠫ僷")
	message += l11l1l_l1_ (u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨ僸")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ價"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭僺"),message,l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ僻"))
	message = l11l1l_l1_ (u"ࠬอไๆ๊สๆ฾ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ僼")
	message += l11l1l_l1_ (u"࠭࡜࡯ࠩ僽")+l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡤ࡯ࡴࡧ࡭ࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠡࠢࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠥࠦࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠥࠦࡳࡩࡣ࡫࡭ࡩ࠺ࡵ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ僾")
	message += l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭僿")+l11l1l_l1_ (u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ儀")
	message += l11l1l_l1_ (u"ࠪࡠࡳ࠭儁")+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅึำࠣࠤฬ๊ใ้์อࠤࠥษๅ๋ำๆหࠥࠦใ็ัสࠤࠥ็ั็ีสࠤࠥอไ๋๊้ห๋ࠦࠠษำํ฻ฬ์๊ศࠢส่ส๋วาษอࠤศ๊ๅศ่ํหࠥื่ิ์สࠤฬ๊๊ศสส๊ࠥอไิ฻๋ำ๏ฯࠠา๊่ห๋๐ว้๋่๋ࠡีว࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ儂")
	message += l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ儃")+l11l1l_l1_ (u"࠭วๅ็หี๊า้ࠠฮาࠤ฼ื๊ให่ࠣฯาว้ิࠣห้฿ววไࠣ์้้ๆ่ษࠣฮาะวอࠢฯ๋ิࠦใษ์ิࠤํอไๆสิ้ัู๊่ࠦࠣห้๋ิไๆฬࠤฺเ๊าหࠣ์้อࠠหีอั็ࠦวๅฬ฼ฬࠥ็ลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠษษ็ำำ๎ไࠡๆห฽฻ࠦวๅ็๋ห็฿้ࠠลํฺฬࠦไไ์ࠣ๎ฯ฼อࠡฯฯ้ࠥอไๆึๆ่ฮࠦࠧ億")
	message += l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟สีุ๊ࠠาีส่ฮࠦๅลัหอࠥหไ๊ࠢส่๊ฮัๆฮࠣ์ฬ้สษࠢไ๎์อࠠศี่ࠤอ๊ฯไ๋ࠢวุ๋วยࠢส่๊๎วใ฻ࠣห้ะ๊ࠡๆสࠤฯูสุ์฼ࠤิิ่ๅ้ส࡟࠴ࡉࡏࡍࡑࡕࡡࠬ儅")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ儆"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ儇"),message,l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭儈"))
	#l1l111l11ll1_l1_(l11l1l_l1_ (u"ࠫࡎࡹࡐࡳࡱࡥࡰࡪࡳ࠽ࡇࡣ࡯ࡷࡪ࠭儉"))
	#message = l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ儊")+l11l1l_l1_ (u"่࠭ๅไาࠤ้ออู่สࠤฬ๐ึศࠢฦ๊ࠥอไๆ๊สๆ฾ࠦวๅ็฼ห็ฯࠠหะอ่ๆࠦศศะอ่ฬ็ࠠศๆห่ิ่ࠦหะอ่ๆࠦศศะอ่ฬ็ࠠีำๆอࠥอไศ่อี๋๐สࠡใํࠤี๊ใࠡษ็ฬ้ี้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์็ࠡฯอํ๊่ࠥࠡฬ่ࠤฬูสฯัส้ࠥ࡜ࡐࡏࠢฦ์ࠥࡖࡲࡰࡺࡼࠤศ๎ࠠฤ์ࠣ์ุ๐ไสࠢสาึ๏ࠠโษ้ࠤฬ๊ๅ้ษๅ฽ࠥอไๆ฻สๆฮࠦำ้ใࠣฮำะไโ๋่่ࠢ์็ศࠢ็๊ࠥะูๆๆࠣะ๊๐ู่ษࠪ儋")
	#message += l11l1l_l1_ (u"ࠧๅฯ็ࠤฬ๊ๅีๅ็อ่ࠥๅࠡส฼้้๐ๆ࠻ࠢࠣࠤࠥอไฤ๊็࠾ࠥษัิๆࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥหไ๊ࠢส่๊ฮัๆฮ๊ࠣࠬ์ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า๊ࠩࠡส็ฯฮࠠๆ฻๊ࠤฬูๅࠡส็ำ่่ࠦศี่ࠤูืใสࠢส่ส์สา่ํฮࠥ๎ริ็สลࠥอไๆ๊สๆ฾ࠦวๅฬํࠤ้อࠠห฻่่ࠥ฿ๆะๅࠪ儌")
	#message += l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭儍")+l11l1l_l1_ (u"๋ࠩห้ัว็์࠽ࠤัืศࠡษึฮำีวๆ࡙ࠢࡔࡓฺ่่ࠦาࠤฬ๊ศฺุࠣๆิࠦสฮฬสะࠥ็โุࠢอ฾๏๐ัࠡࡆࡑࡗࠥ๎วๅละื๋ࠦร็ࠢํ็ํ์ࠠโ์ࠣฬ้ีࠠศะิࠤ฾๊ๅศࠢส๊ࠥอำหะาห๊ࠦࡐࡳࡱࡻࡽ่ࠥฯࠡ์ะ่๋ࠥิไๆฬࠤอ฿ึࠡษ็้ํอโฺ๋่่ࠢ์ࠠๅ์ึࠤๆ๐ࠠอ็ํ฽ࠥอไะ๊็ࠫ儎")
	#DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ู้้ࠪไสࠢ฼๊ิࠦศฺุࠣห้์วิࠩ儏"),message)
	#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ儐"),l11l1l_l1_ (u"ࠬ็อึࠢฯ้๏฿ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠨ儑"),l11l1l_l1_ (u"࠭็ัษࠣห้็อึ๊ࠢ์๊ࠥๅฺำไอࠥํไࠡษ็ู้้ไส่๊ࠢࠥ฿ๆะๅࠣห๊ࠦๅ็ࠢส่อืๆศ็ฯ࠲ู๊ࠥใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ็อึ่ࠢ์ฬู่่่ࠢีฯ๐ๆࠡษ็วํ๊้ࠡสฺ๋฾้ࠠศๆฺฬ๏฿๊๊ࠡส่ะอๆ๋หࠣฬฬูสฯัส้ࠥฮั้ๅึ๎๋ࠥฬศ่ํࠤฬ์สࠡฬัฮฬื็ࠡ็้ࠤฬ๊โศศ่อࠥอไห์ࠣืฯ฾็าࠢ็หา่ว࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึลࠧ儒"),l11l1l_l1_ (u"ࠧࠨ儓"),l11l1l_l1_ (u"ࠨࠩ儔"),l11l1l_l1_ (u"ࠩๆ่ฬ࠭儕"),l11l1l_l1_ (u"๊ࠪ฾๋ࠧ儖"))
	#if l1ll111111_l1_==1:
	#l1l1111111l1_l1_()
	return
def l1l1111l11ll_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ儗"),l11l1l_l1_ (u"ࠬ࠭儘"),l11l1l_l1_ (u"࠭หๅษฮࠤ฼ืโࠡๆ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ั࠭儙"),l11l1l_l1_ (u"ࠧฤำึ่ࠥืำศๆฬࠤศ๎ࠠๆึๆ่ฮࠦๅ็ࠢๅหห๋ษࠡะา้ฬะ่ࠠาสࠤฬ๊ศา่ส้ัࡢ࡮࡝ࡰฦ์ࠥฮวิฬัำฬ๋ࠠศๆไ๎ุฮ่ไࠢฦำ๋อ็࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡧࡣࡦࡤࡲࡳࡰ࠴ࡣࡰ࡯࠲ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠴࠳࠵࠽ࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱวํࠦศศำึห้ࠦว๋็ํ่ࠥอไ๊ࠢฦำ๋อ็ࠡࠢ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࡃ࡫ࡲࡧࡩ࡭࠰ࡦࡳࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ儚"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ儛"),l11l1l_l1_ (u"ࠩࠪ儜"),l11l1l_l1_ (u"ࠪࡆࡇࡈࡂࡃࡄࡅࡆࡇࡈࠠࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ儝"),l11l1l_l1_ (u"ࠫ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹࡜࡯࡞ࡱ࠸࠹࠺࠴࠵ࠢ࠸࠹࠺࠻࠵ࠡ࠸࠹࠺࠻࠼࡟࠸࠹࠺࠻࠼ࠦ࠸࠹࠺࠻࠼ࠥ࠿࠹࠺࠻࠼ࠤࡆࡇࡁࡂࡃ࠴ࡣࡇࡈࡂࡃࡄ࠴ࡣࡈࡉࡃࡄࡅ࠴ࡣࡉࡊࡄࡅࡆ࠴ࡣࡊࡋࡅࡆࡇ࠴ࡣࡋࡌࡆࡇࡈ࠴ࡣࡌࡍࡇࡈࡉ࠴ࡣࡍࡎࡈࡉࡊ࠴ࡣࡎࡏࡉࡊࡋ࠴ࡣࡏࡐࡊࡋࡌ࠴ࡣࡐࡑࡋࡌࡍ࠴ࡣࡑࡒࡌࡍࡎ࠴ࡣࡒࡓࡍࡎࡏ࠴ࠤ࠵࠶࠰࠱࠲ࠣ࠵࠶࠷࠱࠲ࠢ࠵࠶࠷࠸࠲ࠡ࠵࠶࠷࠸࠹ࠠ࠵࠶࠷࠸࠹ࠦࡁࡂࡃࡄࡅ࠷ࡥࡂࡃࡄࡅࡆ࠷ࡥࡃࡄࡅࡆࡇ࠷ࡥࡄࡅࡆࡇࡈ࠷ࡥࡅࡆࡇࡈࡉ࠷ࡥࡆࡇࡈࡉࡊ࠷ࡥࡇࡈࡉࡊࡋ࠷ࡥࡈࡉࡊࡋࡌ࠷ࡥࡉࡊࡋࡌࡍ࠷ࡥࡊࡋࡌࡍࡎ࠷ࠦ࠰࠱࠲࠳࠴ࠥ࠷࠱࠲࠳࠴ࠤ࠷࠸࠲࠳࠴ࠣ࠷࠸࠹࠳࠴ࠢ࠷࠸࠹࠺࠴ࠡ࠷࠸࠹࠺࠻ࠠ࠷࠸࠹࠺࠻ࠦ࠷࠸࠹࠺࠻ࠥ࠾࠸࠹࠺࠻ࠤ࠾࠿࠹࠺࠻ࠣࡅࡆࡇࡁࡂࠢࡅࡆࡇࡈࡂࠨ儞"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭償"),l11l1l_l1_ (u"࠭ࠧ儠"),l11l1l_l1_ (u"ࠧࡃࡄࡅࡆࡇࡈࡂࡃࡄࡅࠤࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ儡"),l11l1l_l1_ (u"ࠨ࠲ࠣ࠴ࠥ࠶ࠠ࠱ࠢ࠳ࠤ࠶ࠦ࠱ࠡ࠳ࠣ࠵ࠥ࠷ࠠ࠳ࠢ࠵ࠤ࠷ࠦ࠲ࠡ࠴ࠣ࠷ࠥ࠹ࠠ࠴ࠢ࠶ࠤ࠸ࠦ࠴ࠡ࠶ࠣ࠸ࠥ࠺ࠠ࠵ࠢ࠸ࠤ࠺ࠦ࠵ࠡ࠷ࠣ࠹ࠥ࠼ࠠ࠷ࠢ࠹ࠤ࠻ࠦ࠶ࠡ࠹ࠣ࠻ࠥ࠽ࠠ࠸ࠢ࠺ࠤ࠽ࠦ࠸ࠡ࠺ࠣ࠼ࠥ࠾ࠠ࠺ࠢ࠼ࠤ࠾ࠦ࠹ࠡ࠻ࠣࡅࡆࡇࡁࡂ࠳ࡢࡆࡇࡈࡂࡃ࠳ࡢࡇࡈࡉࡃࡄ࠳ࡢࡈࡉࡊࡄࡅ࠳ࡢࡉࡊࡋࡅࡆ࠳ࡢࡊࡋࡌࡆࡇ࠳ࡢࡋࡌࡍࡇࡈ࠳ࡢࡌࡍࡎࡈࡉ࠳ࡢࡍࡎࡏࡉࡊ࠳ࡢࡎࡏࡐࡊࡋ࠳ࡢࡏࡐࡑࡋࡌ࠳ࡢࡐࡑࡒࡌࡍ࠳ࡢࡑࡒࡓࡍࡎ࠳ࠣ࠴࠵࠶࠰࠱ࠢ࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸ࠠ࠴࠵࠶࠷࠸ࠦ࠴࠵࠶࠷࠸ࠥࡇࡁࡂࡃࡄ࠶ࡤࡈࡂࡃࡄࡅ࠶ࡤࡉࡃࡄࡅࡆ࠶ࡤࡊࡄࡅࡆࡇ࠶ࡤࡋࡅࡆࡇࡈ࠶ࡤࡌࡆࡇࡈࡉ࠶ࡤࡍࡇࡈࡉࡊ࠶ࡤࡎࡈࡉࡊࡋ࠶ࡤࡏࡉࡊࡋࡌ࠶ࡤࡐࡊࡋࡌࡍ࠶ࠥ࠶࠰࠱࠲࠳ࠤ࠶࠷࠱࠲࠳ࠣ࠶࠷࠸࠲࠳ࠢ࠶࠷࠸࠹࠳ࠡ࠶࠷࠸࠹࠺ࠠ࠶࠷࠸࠹࠺ࠦ࠶࠷࠸࠹࠺ࠥ࠽࠷࠸࠹࠺ࠤ࠽࠾࠸࠹࠺ࠣ࠽࠾࠿࠹࠺ࠢࡄࡅࡆࡇࡁࠡࡄࡅࡆࡇࡈࠧ儢"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ儣"),l11l1l_l1_ (u"ࠪࠫ儤"),l11l1l_l1_ (u"ࠫࡇࡈࡂࡃࡄࡅࡆࡇࡈࡂࠡࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ儥"),l11l1l_l1_ (u"ࠬ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠤ࠵࠷ࠠ࠳࠵ࠣ࠸࠺ࠦ࠶࠸ࠢ࠻࠽ࠥࡧࡢࠡࡥࡧࠤࡪ࡬ࠠࡨࡪࠣ࡭࡯ࠦ࡫࡭ࠢࡰࡲࠥࡵࡰࠡࡳࡵࠤࡸࡺࠠࡸࡺࠣࡽࡿࠦ࠰࠲ࠢ࠵࠷ࠥ࠺࠵ࠡ࠸࠺ࠤ࠽࠿ࠠࡢࡤࠣࡧࡩࠦࡥࡧࠢࡪ࡬ࠥ࡯ࡪࠡ࡭࡯ࠤࡲࡴࠠࡰࡲࠣࡵࡷࠦࡳࡵࠢࡺࡼࠥࡿࡺࠡ࠲࠴ࠤ࠷࠹ࠠ࠵࠷ࠣ࠺࠼ࠦ࠸࠺ࠢࡤࡦࠥࡩࡤࠡࡧࡩࠤ࡬࡮ࠠࡪ࡬ࠣ࡯ࡱࠦ࡭࡯ࠢࡲࡴࠥࡷࡲࠡࡵࡷࠤࡼࡾࠠࡺࡼࠣ࠴࠶ࠦ࠲࠴ࠢ࠷࠹ࠥ࠼࠷ࠡ࠺࠼ࠤࡦࡨࠠࡤࡦࠣࡩ࡫ࠦࡧࡩࠢ࡬࡮ࠥࡱ࡬ࠡ࡯ࡱࠤࡴࡶࠠࡲࡴࠣࡷࡹࠦࡷࡹࠢࡼࡾࠥ࠶࠱ࠡ࠴࠶ࠤ࠹࠻ࠠ࠷࠹ࠣ࠼࠾ࠦࡡࡣࠢࡦࡨࠥ࡫ࡦࠡࡩ࡫ࠤ࡮ࡰࠠ࡬࡮ࠣࡱࡳࠦ࡯ࡱࠢࡴࡶࠥࡹࡴࠡࡹࡻࠤࡾࢀࠠ࠱࠳ࠣ࠶࠸ࠦ࠴࠶ࠢ࠹࠻ࠥ࠾࠹ࠡࡣࡥࠤࡨࡪࠠࡦࡨࠣ࡫࡭ࠦࡩ࡫ࠢ࡮ࡰࠥࡳ࡮ࠡࡱࡳࠤࡶࡸࠠࡴࡶࠣࡻࡽࠦࡹࡻࠢ࠳࠵ࠥ࠸࠳ࠡ࠶࠸ࠤ࠻࠽ࠠ࠹࠻ࠣࡥࡧࠦࡣࡥࠢࡨࡪࠥ࡭ࡨࠡ࡫࡭ࠤࡰࡲࠠ࡮ࡰࠣࡳࡵࠦࡱࡳࠢࡶࡸࠥࡽࡸࠡࡻࡽࠫ儦"))
	#text = l11l1l_l1_ (u"࠭ࠨࠡࡃࡄࡅࡆࡇ࠱ࡠࡄࡅࡆࡇࡈ࠱ࡠࡅࡆࡇࡈࡉ࠱ࡠࡆࡇࡈࡉࡊ࠱ࡠࡇࡈࡉࡊࡋ࠱ࡠࡈࡉࡊࡋࡌ࠱ࡠࡉࡊࡋࡌࡍ࠱ࡠࡊࡋࡌࡍࡎ࠱ࡠࡋࡌࡍࡎࡏ࠱ࠡࠫࠣ࠴ࠥ࠷ࠠ࠳ࠢ࠶ࠤ࠹ࠦ࠵ࠡ࠸ࠣ࠻ࠥ࠾ࠠ࠺ࠢࡤࠤࡧࠦࡣࠡࡦࠣࡩࠥ࡬ࠠࡨࠢ࡫ࠤ࡮ࠦࡪࠡ࡭ࠣࡰࠥࡳࠠ࡯ࠢࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠢࡹࠤࡼࠦࡸࠡࡻࠣࡾࠥ࠶ࠠ࠲ࠢ࠵ࠤ࠸ࠦ࠴ࠡ࠷ࠣ࠺ࠥ࠽ࠠ࠹ࠢ࠼ࠤࡦࠦࡢࠡࡥࠣࡨࠥ࡫ࠠࡧࠢࡪࠤ࡭ࠦࡩࠡ࡬ࠣ࡯ࠥࡲࠠ࡮ࠢࡱࠤࡴࠦࡰࠡࡳࠣࡶࠥࡹࠠࡵࠢࡸࠤࡻࠦࡷࠡࡺࠣࡽࠥࢀࠠ࠱ࠢ࠴ࠤ࠷ࠦ࠳ࠡ࠶ࠣ࠹ࠥ࠼ࠠ࠸ࠢ࠻ࠤ࠾ࠦࡡࠡࡤࠣࡧࠥࡪࠠࡦࠢࡩࠤ࡬ࠦࡨࠡ࡫ࠣ࡮ࠥࡱࠠ࡭ࠢࡰࠤࡳࠦ࡯ࠡࡲࠣࡵࠥࡸࠠࡴࠢࡷࠤࡺࠦࡶࠡࡹࠣࡼࠥࡿࠠࡻࠢ࠳ࠤ࠶ࠦ࠲ࠡ࠵ࠣ࠸ࠥ࠻ࠠ࠷ࠢ࠺ࠤ࠽ࠦ࠹ࠡࡣࠣࡦࠥࡩࠠࡥࠢࡨࠤ࡫ࠦࡧࠡࡪࠣ࡭ࠥࡰࠠ࡬ࠢ࡯ࠤࡲࠦ࡮ࠡࡱࠣࡴࠥࡷࠠࡳࠢࡶࠤࡹࠦࡵࠡࡸࠣࡻࠥࡾࠠࡺࠢࡽࠤ࠵ࠦ࠱ࠡ࠴ࠣ࠷ࠥ࠺ࠠ࠶ࠢ࠹ࠤ࠼ࠦ࠸ࠡ࠻ࠣࡥࠥࡨࠠࡤࠢࡧࠤࡪࠦࡦࠡࡩࠣ࡬ࠥ࡯ࠠ࡫ࠢ࡮ࠤࡱࠦ࡭ࠡࡰࡲࠤࡵࠦࡱࠡࡴࠣࡷࠥࡺࠠࡶࠩ儧")
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠧࠨ儨"),l11l1l_l1_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽࠵࠷࠲࠴࠶ࠪ儩"),l11l1l_l1_ (u"ࠩ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠶࠱࠳࠵࠷ࠫ優"),l11l1l_l1_ (u"ࠪ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿࠰࠲࠴࠶࠸ࠬ儫"),l11l1l_l1_ (u"ࠫ࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ࠡ࠴࠵࠶࠷࠸࠲࠳࠴࠵࠶ࠬ儬"),text,1)
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠬ࠭儭"),l11l1l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭儮"),l11l1l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ儯"),l11l1l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ儰"),l11l1l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭儱"),l11l1l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ儲"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠫࠬ儳"),l11l1l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儴"),l11l1l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭儵"),l11l1l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࠧ儶"),l11l1l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儷"),l11l1l_l1_ (u"ࠩࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࠩ儸"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠪࠫ儹"),l11l1l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ儺"),l11l1l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儻"),l11l1l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭儼"),l11l1l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儽"),l11l1l_l1_ (u"ࠨࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ儾"))
	#DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࠪ儿"),l11l1l_l1_ (u"ࠪࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࠪ兀"),l11l1l_l1_ (u"ࠫࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࠫ允"),l11l1l_l1_ (u"ࠬࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࠬ兂"),l11l1l_l1_ (u"࠭ࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉ࡞ࡱࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍ࠭元"),l11l1l_l1_ (u"ࠧࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࡉࡊࡋࡌࡍࡎࡈࠨ兄"))
	return
def l11llll11ll1_l1_():
	l11lllll1111_l1_()
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ充"),l11l1l_l1_ (u"ࠩࠪ兆"),l11l1l_l1_ (u"ࠪࠫ兇"),l11l1l_l1_ (u"ࠫ์๊ࠠหำํำ๋ࠥำฮࠢฯ้๏฿ࠠศๆๆหูࠦฟࠨ先"),l11l1l_l1_ (u"ࠬอไไษืࠤ๏ูัฺࠢ฼้้ࠦวๅสิ๊ฬ๋ฬ๊่ࠡืาํ๋ࠠ฻ํำูࠥอษࠢสฺ่็อศฬ้๋ࠣࠦวๅว้ฮึ์สࠡ฻้ำࠥอไฮษฯอࠥหไ๋้สࠤํอไๆีะࠤ๏ะๅࠡฬ็ๆฬฬ๊ศࠢ฼๊ิࠦว็ฬ๊หฦูࠦๆำࠣห้฻แฮษอࠤํอไๆีะࠤ้อุ๋ࠠิࠤํ๋ๅไ่ࠣ๎า๊ࠠษ฻ูࠤฬ๊ๅีษๆ่ࠬ光"))
	if l1ll111111_l1_==1:
		l11lllll111l_l1_(True)
		DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ兊"),l11l1l_l1_ (u"ࠧࠨ克"),l11l1l_l1_ (u"ࠨฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠษษ็็ฬ๋ไࠨ兌"),l11l1l_l1_ (u"ࠩศิฬࠦใศ่อࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬำฯࠡษ็้ํอโฺࠢไะึฮࠠศๆ่์็฿ࠠศๆล๊ࠥ࠴࠮࠯๋ࠢวีอࠠศๆุ่่๊ษࠡ็ึฮ๊ืษࠡใศิ๋ࠦวาี็ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ免"))
	return l1ll111111_l1_
def l1l11l111ll1_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll_l1_ = True
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ兎"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡸࡢ࡯ࡳࡰࡪ࠴ࡣࡰ࡯ࠪ兏"),l11l1l_l1_ (u"ࠬ࠭児"),l11l1l_l1_ (u"࠭ࠧ兑"),False,l11l1l_l1_ (u"ࠧࠨ兒"),l11l1l_l1_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ兓"))
	#html = response.content
	if not response.succeeded:
		l11lll1l1l11_l1_ = False
		l11l1l11ll_l1_ = l11l11ll11_l1_()
		LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ兔"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡈࡕࡖࡓࡗࠥࡌࡡࡪ࡮ࡨࡨࠥࠦࠠࡍࡣࡥࡩࡱࡀ࡛ࠨ兕")+l11l1l11ll_l1_+l11l1l_l1_ (u"ࠫࡢ࠭兖"))
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭兗"),l11l1l_l1_ (u"࠭ࠧ兘"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ兙"),l11l1l_l1_ (u"ࠨใะูࠥอไศฬุห้ࠦวๅ็ืๅึࠦ࠮࠯࠰ู้้ࠣไสࠢ࠱࠲࠳ࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠࠩษ็ีอ฽ࠠศๆุ่ๆืࠩࠡๆสࠤ๏฿ๅๅࠢ฼๊ิฺ้ࠠๆ์ࠤ่๎ฯ๋ࠢ࠱࠲࠳ฺ่่ࠦา็้่ࠥะ์ࠣ฾๏ืࠠใษาีࠥ฿ไ๊ࠢสืฯิฯศ็ࠣห้๋่ศไ฼ࠤฬ๊ๅีใิอࠬ党"))
	else:
		l11lll1l1l11_l1_ = True
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ兛"),l11l1l_l1_ (u"ࠪࠫ兜"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ兝"),l11l1l_l1_ (u"ࠬา๊ะࠢฯำฬࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ࠭ࠥ๐ูๆๆࠣ฽๋ีใ๊ࠡส่อืๆศ็ฯࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩ兞"))
	if not l11lll1l1l11_l1_ and l1ll_l1_: l1l11111lll1_l1_()
	return l11lll1l1l11_l1_
def l1l11111lll1_l1_():
	DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ兟"),l11l1l_l1_ (u"ࠧࠨ兠"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ兡"),l11l1l_l1_ (u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨ兢"))
	#l1ll111l1l1_l1_ = l11l1l_l1_ (u"ุࠪ์อฯสࠢส่ฯฺแ๋ำ๋ࠣ๏ࠦๅๅใࠣ๎าะ่๋ࠢ฼่๎ࠦิโำฬࠤำอีสࠢฦ์ࠥะ่ศไํ฽ࠥิวึหู่ࠣืใศฬ้ࠣ฾ื่โหࠣ์้ํࠠหษิ๎ำࠦีๅษะ๎ฮ่ࠦ็ใสิࠥ๎วๅ฼ิฺ๋ࠥๆ่๊ࠢ์ࠥะศศั็ࠤฬ๊ๅฺๆ๋้ฬะࠠษูิ๎็ฯࠠๆึไีฮ๊ࠦึ฻หࠤฬิสาษๅ๋ฬ่ࠦโ้่๋ฬ࠭兣")
	l1l111l11l1l_l1_()
	return
def l1l111l11ll1_l1_(text=l11l1l_l1_ (u"ࠫࠬ兤")):
	l1l1l11lll1l_l1_ = True
	if l11l1l_l1_ (u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ入") not in text:
		l1l1l11lll1l_l1_ = False
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭兦"),l11l1l_l1_ (u"ࠧฦำึห้ࠦัิษ็อࠬ內"),l11l1l_l1_ (u"ࠨวิืฬ๊ࠠๆึๆ่ฮ࠭全"),l11l1l_l1_ (u"ࠩࠪ兩"),l11l1l_l1_ (u"๋้ࠪࠦสา์าࠤศ์ࠠหำึ่ࠥืำศๆฬࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อࠥลࠧ兪"))
		if l1ll111111_l1_==1:
			l1l1l11lll1l_l1_ = True
			text = l11l1l_l1_ (u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ八")
	if l1l1l11lll1l_l1_:
		#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ公"),l11l1l_l1_ (u"࠭ࠧ六"),l11l1l_l1_ (u"ࠧࠨ兮"),l11l1l_l1_ (u"ࠨวิืฬ๊ࠠิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠩ兯"),l11l1l_l1_ (u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏๊ࠦิฬฺ๎฾ࠦวๅ็หี๊าࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠวุ่ฬำ็ศࠩ兰"))
		#if not l1ll111111_l1_:
		#	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ共"),l11l1l_l1_ (u"ࠫࠬ兲"),l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨ关"),l11l1l_l1_ (u"࠭ไๅลึๅࠥฮฯ้่ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ兴"))
		#	return
		l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡫࡬ࡴࡧ࠽ࠎࠎࠏࠉࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡯ࡳ࡬ࡹ࠽ࡺࡧࡶࠫࠏࠏࠉࠊࡻࡨࡷࠥࡃࠠࡅࡋࡄࡐࡔࡍ࡟࡚ࡇࡖࡒࡔ࠮ࠧࡤࡧࡱࡸࡪࡸ๊่ࠧ࠭ࠩࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ࠮ࠪๆอ๊ࠠศำึห้ࠦำอๆࠣห้อฮุษฤࠤํอไศีอาิอๅࠡว็ํࠥอไๆสิ้ัูࠦๅ์ๆࠤฬ์ࠠหไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦว้ࠢส่ึอศุࠢส่ี๐๋ࠠ฻ฺ๎่ࠦวๅ็ื็้ฯࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็หำ฽วย๋ࠢห้อำหะาห๊࠴่ࠠๆࠣฮึ๐ฯࠡษ็หึูวๅࠢส่ฬ์ࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࡺࡧࡶࡁࡂ࠶࠺ࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫฯ๋ࠠศๆ฽หฦࠦวๅษิืฬ๊ࠧࠪࠌࠌࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࠧࠨࠌࠌࠍࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨ࠮ࠪหีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไห้ืฬศรࠣๆึอมสࠢๅื๊ࠦวๅ็ืห่๊้ࠠษ็หุฬไส๋ࠢหีอࠠๅ็ࠣฮัีࠠศๆะ่ࠥํๆศๅࠣๅาอ่ๅࠢๆฮฬฮษࠡฮ่๎฾ࠦสโษุ๎้ࠦวๅ็ื็้ฯࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ࠯ࠊࠊࠋࠥࠦࠧ兵")
		if l11l1l_l1_ (u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨ其") not in text:
			l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ具"),l11l1l_l1_ (u"ࠪࠫ典"),l11l1l_l1_ (u"ࠫࠬ兹"),l11l1l_l1_ (u"ࠬ๎ึฺࠢสฺ่๊ใๅหࠣๅ๏ࠦวๅีฯ่ࠬ兺"),l11l1l_l1_ (u"࠭โษๆࠣษึูวๅࠢสุ่าไࠡ฻็๎่ࠦร็ࠢอ็ึื่ࠠࠡไืࠥอไโ฻็ࠤฬ๊ะ๋ࠢฦ฽฼อใࠡษ็ู้้ไสࠢ࠱ࠤ้้๊ࠡ์อ้ࠥะำอ์็ࠤ์ึ็ࠡษ็ู้้ไสࠢไ๎ูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠ࠯๋ࠢฬิ๎ๆ้ࠡำหࠥอไหีฯ๎้ࠦำ้ใࠣฮึูไࠡ็็ๅ๊ࠥวࠡใสสิฯࠠๆ่๊ࠤ้หๆ่ࠢ็หࠥ๐อห๊ํࠤ฾๊้ࠡษ็ู้้ไสࠢส่ฯ๐ࠠหำํำࠥอๆหࠢส่สฮไศ฼ࠣ฽๋ํวࠡ࠰๋้ࠣࠦโๆฬࠣฬฯ้ัศำࠣห้๋ิไๆฬࠤฤ࠭养"))
			if l1ll111111_l1_!=1:
				DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ兼"),l11l1l_l1_ (u"ࠨࠩ兽"),l11l1l_l1_ (u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠬ兾"),l11l1l_l1_ (u"่้ࠪษำโࠢหำํ์ࠠหีฯ๎้ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ็ว็ࠢส่๊ฮัๆฮ่ࠣฬ๊ࠦิฬฺ๎฾ࠦๅฺำไอࠥอไๆึๆ่ฮ่ࠦๅษࠣั้ํวࠡๆส๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ࠭兿"))
				return
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ冀"),l11l1l_l1_ (u"ࠬ࠭冁"),l11l1l_l1_ (u"࠭ใหษหอࠥ๎ิาฯࠣห้๋่ื๊฼ࠤ้๊ๅษำ่ะࠬ冂"),l11l1l_l1_ (u"ࠧโ์ࠣหฺ้วีหࠣห้่วะ็ฬࠤาอ่ๅࠢฦ๊ࠥะใหสࠣีุอไสࠢศ่๎ࠦวๅ็หี๊า้ࠠษืีาࠦแ๋้สࠤฬ๊ๅีๅ็อࠥษ่ࠡษ็้ํ฼ฺ่๋ࠢษีอࠠฤำาฮࠥา่ศส้๋ࠣࠦวๅ็หี๊าࠠโวำ๊ࠥษใหสࠣ฽๋๎ว็ࠢหี๏ีใࠡล็ษ้้สา๊้๎ࠥอไศ์่๎้่ࠦหาๆีࠥ๎ไศࠢอุ๊๏ࠠฤ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠥอไ฻์หࠫ冃"))
	search = OPEN_KEYBOARD(header=l11l1l_l1_ (u"ࠨ࡙ࡵ࡭ࡹ࡫ࠠࡢࠢࡰࡩࡸࡹࡡࡨࡧࠣࠤࠥอใหสࠣีุอไสࠩ冄"),source=l1ll1_l1_)
	if not search: return
	message = search
	if l1l1l11lll1l_l1_: type = l11l1l_l1_ (u"ࠩ࠰ࡔࡷࡵࡢ࡭ࡧࡰࠫ内")
	else: type = l11l1l_l1_ (u"ࠪ࠱ࡒ࡫ࡳࡴࡣࡪࡩࠬ円")
	l1ll11l1lll1_l1_ = l11l1l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ冇")+l1l11ll1lll_l1_(32)+type
	succeeded = l1llll1l1l11_l1_(l1ll11l1lll1_l1_,message,True,l11l1l_l1_ (u"ࠬ࠭冈"),l11l1l_l1_ (u"࠭ࡅࡎࡃࡌࡐ࠲ࡌࡒࡐࡏ࠰࡙ࡘࡋࡒࡔࠩ冉"),text)
	#	url = l11l1l_l1_ (u"ࠧ࡮ࡻࠣࡅࡕࡏࠠࡢࡰࡧ࠳ࡴࡸࠠࡔࡏࡗࡔࠥࡹࡥࡳࡸࡨࡶࠬ冊")
	#	payload = l11l1l_l1_ (u"ࠨࡽࠥࡥࡵ࡯࡟࡬ࡧࡼࠦ࠿ࠨࡍ࡚ࠢࡄࡔࡎࠦࡋࡆ࡛ࠥ࠰ࠧࡺ࡯ࠣ࠼࡞ࠦࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠥࡡ࠱ࠨࡳࡦࡰࡧࡩࡷࠨ࠺ࠣ࡯ࡨࡄࡪࡳࡡࡪ࡮࠱ࡧࡴࡳࠢ࠭ࠤࡶࡹࡧࡰࡥࡤࡶࠥ࠾ࠧࡌࡲࡰ࡯ࠣࡅࡷࡧࡢࡪࡥ࡚ࠣ࡮ࡪࡥࡰࡵࠥ࠰ࠧࡺࡥࡹࡶࡢࡦࡴࡪࡹࠣ࠼ࠥࠫ冋")+message+l11l1l_l1_ (u"ࠩࠥࢁࠬ册")
	#	#auth=(l11l1l_l1_ (u"ࠥࡥࡵ࡯ࠢ再"), l11l1l_l1_ (u"ࠦࡲࡿࠠࡱࡧࡵࡷࡴࡴࡡ࡭ࠢࡤࡴ࡮ࠦ࡫ࡦࡻࠥ冎")),
	#	import requests
	#	response = requests.request(l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ冏"),url, data=payload, headers=l11l1l_l1_ (u"࠭ࠧ冐"), auth=l11l1l_l1_ (u"ࠧࠨ冑"))
	#	response = requests.l1lll11_l1_(url, data=payload, headers=l11l1l_l1_ (u"ࠨࠩ冒"), auth=l11l1l_l1_ (u"ࠩࠪ冓"))
	#	if response.status_code == 200:
	#		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ冔"),l11l1l_l1_ (u"ࠫࠬ冕"),l11l1l_l1_ (u"ࠬ࠭冖"),l11l1l_l1_ (u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩ冗"))
	#	else:
	#		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ冘"),l11l1l_l1_ (u"ࠨࠩ写"),l11l1l_l1_ (u"ࠩั฻ศࠦแ๋ࠢส่สืำศๆࠪ冚"),l11l1l_l1_ (u"ࠪࡉࡷࡸ࡯ࡳࠢࡾࢁ࠿ࠦࡻࠢࡴࢀࠫ军").format(response.status_code, response.content))
	#	l11lll11llll_l1_ = l11l1l_l1_ (u"ࠫࡲ࡫ࡀࡦ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ农")
	#	l11llll1l11l_l1_ = l11l1l_l1_ (u"ࠬࡳࡥࡁࡧࡰࡥ࡮ࡲ࠮ࡤࡱࡰࠫ冝")
	#	header = l11l1l_l1_ (u"࠭ࠧ冞")
	#	#header += l11l1l_l1_ (u"ࠧࡇࡴࡲࡱ࠿ࠦࠧ冟") + l11lll11llll_l1_
	#	#header += l11l1l_l1_ (u"ࠨ࡞ࡱࡘࡴࡀࠠࠨ冠") + l11ll111lll1_l1_
	#	#header += l11l1l_l1_ (u"ࠩ࡟ࡲࡈࡩ࠺ࠡࠩ冡") + l11ll111lll1_l1_
	#	header += l11l1l_l1_ (u"ࠪࡠࡳ࡙ࡵࡣ࡬ࡨࡧࡹࡀࠠๆ่ࠣ็ํี๊ࠡษ็ๅ๏ี๊้ࠢส่฾ืศ๋ࠩ冢")
	#	server = l1l11l1lll11_l1_.l11lll1ll11l_l1_(l11l1l_l1_ (u"ࠫࡸࡳࡴࡱ࠯ࡶࡩࡷࡼࡥࡳࠩ冣"),25)
	#	#server.l11llllll1l1_l1_()
	#	server.l1l11111111l_l1_(l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ冤"),l11l1l_l1_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ冥"))
	#	response = server.l1l1111ll11l_l1_(l11lll11llll_l1_,l11llll1l11l_l1_, header + l11l1l_l1_ (u"ࠧ࡝ࡰࠪ冦") + message)
	#	server.quit()
	return
def l1l111lll111_l1_():
	text = l11l1l_l1_ (u"ࠨ้ำหࠥอไษำ้ห๊าࠠๅษࠣ๎ําฯࠡๆ๊ࠤศ๐ࠠิ์ิๅึ๊ࠦิฬู๎ๆࠦร๋่ࠢัฯ๎๊ศฬ࠱ࠤฬ๊ศา่ส้ั๊ࠦิฬัำ๊ࠦั้ษห฻ࠥ๎สื็ํ๊๊ࠥๅฮฬ๋๎ฬะࠠๆำไ์฾ฯฺࠠๆ์ࠤุ๐ัโำสฮࠥิวาฮํอ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี๋ࠥำล๊็ࠤ฾์ࠠฤ์้ࠣาะ่๋ษอࠤฯ๋ࠠหฯ่๎้ํวࠡ฻็ํู๊ࠥาใิหฯ่ࠦๆ๊สๆ฾ࠦฮศำฯ๎ฮࠦࠢๆ๊สๆ฾ࠦืาใࠣฯฬ๊หࠣ࠰ࠣะ๊๐ูࠡษ็วุ๋วย๋ࠢห้๋วาๅสฮࠥ๎วๅื๋ีࠥ๎วๅ็ุ้ํืวห๊ࠢ๎ࠥิวึหࠣฬฬ฻อศส๊ห࠳ࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏์ส่ๅࠣั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠣࡈࡒࡉࡁࠡวำห้ࠥว็ࠢ็ำ๏้ࠠีๅ๋ํࠥิวึหࠣฬฬ๊ั้ษห฻ࠥ๎วๅฬูห๊๐ๆࠡษ็าฬืฬ๋หࠣๅฬ๊ัอษฤࠤฬ๊ส้ษุู่๋ࠥࠡวาหึฯ่ࠠา๊ࠤฬ๊ำ๋ำไีฬะ้ࠠษ็้ํอโฺࠢส่ำอัอ์ฬ࠲ࠥํะศࠢส่อืๆศ็ฯࠤ์๎ࠠษสึห฼ฯࠠๆฬุๅาࠦไๆ๊สๆ฾ࠦวๅ๊ํฬࠬ冧")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ冨"),l11l1l_l1_ (u"ࠪั็๎โࠡษ็฻อ฿้ࠠษ็ู๊ื้ࠠไส๊ํ์ࠠศๆฦ่ๆ๐ษࠡๆ็้้้๊สࠢส่ึ่ๅ๋หࠪ冩"),text,l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ冪"))
	text = l11l1l_l1_ (u"࡚ࠬࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡩࡵࡥࡴࠢࡱࡳࡹࠦࡨࡰࡵࡷࠤࡦࡴࡹࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡲࡲࠥࡧ࡮ࡺࠢࡶࡩࡷࡼࡥࡳ࠰ࠣࡍࡹࠦ࡯࡯࡮ࡼࠤࡺࡹࡥࡴࠢ࡯࡭ࡳࡱࡳࠡࡶࡲࠤࡪࡳࡢࡦࡦࡧࡩࡩࠦࡣࡰࡰࡷࡩࡳࡺࠠࡵࡪࡤࡸࠥࡽࡡࡴࠢࡸࡴࡱࡵࡡࡥࡧࡧࠤࡹࡵࠠࡱࡱࡳࡹࡱࡧࡲࠡࡱࡱࡰ࡮ࡴࡥࠡࡸ࡬ࡨࡪࡵࠠࡩࡱࡶࡸ࡮ࡴࡧࠡࡵ࡬ࡸࡪࡹ࠮ࠡࡃ࡯ࡰࠥࡺࡲࡢࡦࡨࡱࡦࡸ࡫ࡴ࠮ࠣࡺ࡮ࡪࡥࡰࡵ࠯ࠤࡹࡸࡡࡥࡧࠣࡲࡦࡳࡥࡴ࠮ࠣࡷࡪࡸࡶࡪࡥࡨࠤࡲࡧࡲ࡬ࡵ࠯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࡥࡥࠢࡺࡳࡷࡱࠬࠡ࡮ࡲ࡫ࡴࡹࠠࡳࡧࡩࡩࡷ࡫࡮ࡤࡧࡧࠤ࡭࡫ࡲࡦ࡫ࡱࠤࡧ࡫࡬ࡰࡰࡪࠤࡹࡵࠠࡵࡪࡨ࡭ࡷࠦࡲࡦࡵࡳࡩࡨࡺࡩࡷࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥࡩ࡯࡮ࡲࡤࡲ࡮࡫ࡳ࠯ࠢࡗ࡬ࡪࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡲࡴࡺࠠࡳࡧࡶࡴࡴࡴࡳࡪࡤ࡯ࡩࠥ࡬࡯ࡳࠢࡺ࡬ࡦࡺࠠࡰࡶ࡫ࡩࡷࠦࡰࡦࡱࡳࡰࡪࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢ࠶ࡶࡩࠦࡰࡢࡴࡷࡽࠥࡹࡩࡵࡧࡶ࠲ࠥ࡝ࡥࠡࡷࡵ࡫ࡪࠦࡡ࡭࡮ࠣࡧࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦ࡯ࡸࡰࡨࡶࡸ࠲ࠠࡵࡱࠣࡶࡪࡩ࡯ࡨࡰ࡬ࡾࡪࠦࡴࡩࡣࡷࠤࡹ࡮ࡥࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡱࡸࡦ࡯࡮ࡦࡦࠣࡻ࡮ࡺࡨࡪࡰࠣࡸ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡤࡶࡪࠦ࡬ࡰࡥࡤࡸࡪࡪࠠࡴࡱࡰࡩࡼ࡮ࡥࡳࡧࠣࡩࡱࡹࡥࠡࡱࡱࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡵࡲࠡࡸ࡬ࡨࡪࡵࠠࡦ࡯ࡥࡩࡩࡪࡥࡥࠢࡤࡶࡪࠦࡦࡳࡱࡰࠤࡴࡺࡨࡦࡴࠣࡺࡦࡸࡩࡰࡷࡶࠤࡸ࡯ࡴࡦࡵ࠱ࠤࡎ࡬ࠠࡺࡱࡸࠤ࡭ࡧࡶࡦࠢࡤࡲࡾࠦ࡬ࡦࡩࡤࡰࠥ࡯ࡳࡴࡷࡨࡷࠥࡶ࡬ࡦࡣࡶࡩࠥࡩ࡯࡯ࡶࡤࡧࡹࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡲ࡫ࡤࡪࡣࠣࡪ࡮ࡲࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣ࡬ࡴࡹࡴࡦࡴࡶ࠲࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡴ࡫ࡰࡴࡱࡿࠠࡢࠢࡺࡩࡧࠦࡢࡳࡱࡺࡷࡪࡸ࠮ࠨ冫")
	l11l1llll1_l1_(l11l1l_l1_ (u"࠭࡬ࡦࡨࡷࠫ冬"),l11l1l_l1_ (u"ࠧࡅ࡫ࡪ࡭ࡹࡧ࡬ࠡࡏ࡬ࡰࡱ࡫࡮࡯࡫ࡸࡱࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡃࡦࡸࠥ࠮ࡄࡎࡅࡄ࠭ࠬ冭"),text,l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ冮"))
	return
def l11lllllllll_l1_(addon_id):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ冯"),l11l1l_l1_ (u"ࠪࠫ冰"),l11l1l_l1_ (u"ࠫࠬ冱"),addon_id)
	result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ冲")+addon_id+l11l1l_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾࡫ࡧ࡬ࡴࡧࢀࢁࠬ决"))
	l1l11l1l1l_l1_ = True
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡸ࡮ࡵࡵ࡫࡯ࠎࠎࡾࡢ࡮ࡥࡩ࡭ࡱ࡫ࠠ࠾ࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱࡮ࡴ࡯࡮ࠩࡺࡥࡱࡨ࡬࡯࡭ࡦࡨࡶ࠱࠭ࡡࡥࡦࡲࡲࡸ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍ࡮࡬ࠠࡰࡵ࠱ࡴࡦࡺࡨ࠯ࡧࡻ࡭ࡸࡺࡳࠩࡺࡥࡱࡨ࡬ࡩ࡭ࡧࠬ࠾ࠏࠏࠉࡴࡪࡸࡸ࡮ࡲ࠮ࡳ࡯ࡷࡶࡪ࡫ࠨࡹࡤࡰࡧ࡫࡯࡬ࡦࠫࠍࠍࠎࡸࡥࡧࡴࡨࡷ࡭ࠦ࠽ࠡࡖࡵࡹࡪࠐࠉࡶࡵࡨࡶ࡫࡯࡬ࡦࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡹࡸ࡫ࡲࡧࡱ࡯ࡨࡪࡸࠬࠨࡣࡧࡨࡴࡴࡳࠨ࠮ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠭ࠏࠏࡩࡧࠢࡲࡷ࠳ࡶࡡࡵࡪ࠱ࡩࡽ࡯ࡳࡵࡵࠫࡹࡸ࡫ࡲࡧ࡫࡯ࡩ࠮ࡀࠊࠊࠋࡶ࡬ࡺࡺࡩ࡭࠰ࡵࡱࡹࡸࡥࡦࠪࡸࡷࡪࡸࡦࡪ࡮ࡨ࠭ࠏࠏࠉࡳࡧࡩࡶࡪࡹࡨࠡ࠿ࠣࡘࡷࡻࡥࠋࠋࠦ࡭ࡲࡶ࡯ࡳࡶࠣࡷࡶࡲࡩࡵࡧ࠶ࠎࠎࡩ࡯࡯ࡰࠣࡁࠥࡹࡱ࡭࡫ࡷࡩ࠸࠴ࡣࡰࡰࡱࡩࡨࡺࠨࡢࡦࡧࡳࡳࡹ࡟ࡥࡤࡩ࡭ࡱ࡫ࠩࠋࠋࡦࡳࡳࡴ࠮ࡵࡧࡻࡸࡤ࡬ࡡࡤࡶࡲࡶࡾࠦ࠽ࠡࡵࡷࡶࠏࠏࡣࡤࠢࡀࠤࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ࠭ࡤࡨࡩࡵ࡮ࡠ࡫ࡧ࠯ࠬࠨࠠ࠼ࠩࠬࠎࠎࡩࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࡣࡧࡨࡴࡴࡳ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ࠱ࡡࡥࡦࡲࡲࡤ࡯ࡤࠬࠩࠥࠤࡀ࠭ࠩࠋࠋࠦࡧࡨ࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࡲࡦࡲࡲࡷࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ࠮ࡥࡩࡪ࡯࡯ࡡ࡬ࡨ࠰࠭ࠢࠡ࠽ࠪ࠭ࠏࠏࡣࡰࡰࡱ࠲ࡨࡵ࡭࡮࡫ࡷࠬ࠮ࠐࠉࡤࡱࡱࡲ࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠣࠤࠥ冴")
	if l1l11l1l1l_l1_:
		time.sleep(1)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ况"))
		time.sleep(1)
	return
def l1l111l111l1_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ冶"),l11l1l_l1_ (u"ࠪࠫ冷"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ冸"),l11l1l_l1_ (u"ࠬอไษำ้ห๊าࠠๅษࠣ๎ๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡ฻้ำࠥอไศฬุห้ࠦศศๆ่์ฬู่ࠡษ็ู้็ัส๋่ࠢ์ึวࠡใํࠤาอไ๊ࠡฯ์ิࠦิ่ษาอࠥเ๊าุࠢั๏ำษࠡล๋ࠤ๊์ส่์ฬࠤฬ๊ีๅษะ๎ฮࠦร้่ࠢึ๏็ษࠡใส๊ࠥํะศࠢ็๊ࠥ๐่ใใࠣห้ืศุࠢสฺ่๊แา๋่๋๊้ࠢࠦไไࠤ฾๋ไࠡษ็ฬึ์วๆฮࠪ冹"))
	l1l111l11l11_l1_()
	return
def l1l111l11l1l_l1_():
	#	https://l1llll1l1lll_l1_.tv/download/849
	#   https://play.l1l1ll1l1111_l1_.com/l11llll1111l_l1_/l11llllll11l_l1_/l1l1l111ll11_l1_?id=l1lll1ll11l_l1_.xbmc.l1llll1l1lll_l1_
	#	http://mirror.l1l1111lll1l_l1_.l11lll1l1111_l1_.l1l11lll1111_l1_/l1l1111l1l1l_l1_/xbmc/l11lll1lll1l_l1_/l11ll11l1l1l_l1_/l1l1111ll111_l1_
	#	http://l11lll1111l1_l1_.l11ll1l11lll_l1_.l1l11lll1111_l1_/l1llll1l1lll_l1_/l11lll1lll1l_l1_/l11ll11l1l1l_l1_/l1l1111ll111_l1_
	url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫ冺")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ冻"),url,l11l1l_l1_ (u"ࠨࠩ冼"),l11l1l_l1_ (u"ࠩࠪ冽"),l11l1l_l1_ (u"ࠪࠫ冾"),l11l1l_l1_ (u"ࠫࠬ冿"),l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡔࡊࡒ࡛ࡤࡒࡁࡕࡇࡖࡘࡤࡑࡏࡅࡋࡢ࡚ࡊࡘࡓࡊࡑࡑ࠱࠶ࡹࡴࠨ净"))
	html = response.content
	l11ll1l111ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨ࡫ࡰࡦ࡬࠱࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱࠭࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠬ࠱ࠬ凁"),html,re.DOTALL)
	l11ll1l111ll_l1_ = l11ll1l111ll_l1_[0].split(l11l1l_l1_ (u"ࠧ࠮ࠩ凂"))[0]
	l1l11ll1l11l_l1_ = str(kodi_version)
	#l1lll111ll11_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ凃")+l11l1l_l1_ (u"ࠩส่อืๆศ็ฯࠤ้อ๋ࠠ฻ู่่๋ࠥࠡๅ๋ำ๏ࠦลึัสีࠥ࠷࠹๊่ࠡหࠥฮูะ้ࠪ凄")+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ凅")
	l1lll111ll11_l1_ = l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭准")+l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ凇")+l11ll1l111ll_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ凈")
	l1lll111ll11_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ凉")+l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣลึัสี้่ࠥะ์ࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦ็้ࠢ࠽ࠤࠥࠦࠧ凊")+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ凋")+l1l11ll1l11l_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ凌")
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ凍"),l11l1l_l1_ (u"ࠬ࠭凎"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ减"),l1lll111ll11_l1_)
	return
def l11lll111l1l_l1_():
	# https://l1l11lll111l_l1_-l11lll11ll11_l1_-l11llll1llll_l1_.l1l11llll111_l1_.com/request-l11lllll11ll_l1_
	# https://l1l11lll111l_l1_-l11lll11ll11_l1_-l11llll1llll_l1_.l1l11llll111_l1_.com/query-l11ll1l11l1l_l1_
	l1ll111l11l_l1_,l1ll111l1l1_l1_,l1lll111l1ll_l1_,l1lll111ll11_l1_,l1l111l1l11l_l1_,l11ll1l1lll1_l1_,l11lll1ll1l1_l1_ = l11l1l_l1_ (u"ࠧࠨ凐"),l11l1l_l1_ (u"ࠨࠩ凑"),l11l1l_l1_ (u"ࠩࠪ凒"),l11l1l_l1_ (u"ࠪࠫ凓"),l11l1l_l1_ (u"ࠫࠬ凔"),l11l1l_l1_ (u"ࠬ࠭凕"),l11l1l_l1_ (u"࠭ࠧ凖")
	payload,l11ll1l11ll1_l1_,l1l1111l1l11_l1_,l11ll11l1lll_l1_ = {l11l1l_l1_ (u"ࠧࡢࠩ凗"):l11l1l_l1_ (u"ࠨࡣࠪ凘")},{},[],{}
	url = l1l1l1l_l1_[l11l1l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ凙")][1]
	response = OPENURL_REQUESTS_CACHED(l1111ll1l11_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ凚"),url,payload,l11l1l_l1_ (u"ࠫࠬ凛"),l11l1l_l1_ (u"ࠬ࠭凜"),l11l1l_l1_ (u"࠭ࠧ凝"),l11l1l_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ凞"))
	html = response.content
	html = html.replace(l11l1l_l1_ (u"ࠨࡗࡱ࡭ࡹ࡫ࡤࠡࡕࡷࡥࡹ࡫ࡳࠨ凟"),l11l1l_l1_ (u"ࠩࡘࡗࡆ࠭几"))
	html = html.replace(l11l1l_l1_ (u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡏ࡮ࡴࡧࡥࡱࡰࠫ凡"),l11l1l_l1_ (u"࡚ࠫࡑࠧ凢"))
	html = html.replace(l11l1l_l1_ (u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡇࡲࡢࡤࠣࡉࡲ࡯ࡲࡢࡶࡨࡷࠬ凣"),l11l1l_l1_ (u"࠭ࡕࡂࡇࠪ凤"))
	html = html.replace(l11l1l_l1_ (u"ࠧࡔࡣࡸࡨ࡮ࠦࡁࡳࡣࡥ࡭ࡦ࠭凥"),l11l1l_l1_ (u"ࠨࡍࡖࡅࠬ処"))
	html = html.replace(l11l1l_l1_ (u"ࠩࡑࡳࡷࡺࡨࠡࡏࡤࡧࡪࡪ࡯࡯࡫ࡤࠫ凧"),l11l1l_l1_ (u"ࠪࡒ࠳ࡓࡡࡤࡧࡧࡳࡳ࡯ࡡࠨ凨"))
	html = html.replace(l11l1l_l1_ (u"ࠫ࡜࡫ࡳࡵࡧࡵࡲ࡙ࠥࡡࡩࡣࡵࡥࠬ凩"),l11l1l_l1_ (u"ࠬ࡝࠮ࡔࡣ࡫ࡥࡷࡧࠧ凪"))
	html = html.replace(l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ凫"),l11l1l_l1_ (u"ࠧࠡࠢࠪ凬"))
	try: l1l1111l11l1_l1_ = EVAL(l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭凭"),html)
	except:
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ凮"),l11l1l_l1_ (u"ࠪࠫ凯"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ凰"),l11l1l_l1_ (u"ࠬ็ิๅࠢไ๎ࠥาไษ่ࠢัฯ๎๊ศฬࠣฮ็ื๊าࠢส่ฬูสฯัส้ࠬ凱"))
		return
	l1l11l1ll1ll_l1_,l1l11ll1llll_l1_,l11llll1ll1l_l1_ = l1l1111l11l1_l1_
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ凲"),str(l1l11l1ll1ll_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ凳"),str(l1l11ll1llll_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ凴"),str(l11llll1ll1l_l1_))
	l11ll11l1lll_l1_ = {}
	l1l11llll11l_l1_ = [l11l1l_l1_ (u"ࠩࡄࡐࡑ࠭凵"),l11l1l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ凶"),l11l1l_l1_ (u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ凷"),l11l1l_l1_ (u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ凸"),l11l1l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ凹")]+l1l11l11ll11_l1_
	for l1l1llllll1_l1_,l1l11l1lll1l_l1_,l1l11l111lll_l1_ in l1l11ll1llll_l1_:
		l1l11l111lll_l1_ = escapeUNICODE(l1l11l111lll_l1_)
		l1l11l111lll_l1_ = l1l11l111lll_l1_.strip(l11l1l_l1_ (u"ࠧࠡࠩ出")).strip(l11l1l_l1_ (u"ࠨࠢ࠱ࠫ击"))
		l1lll111ll11_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ凼")+l1l1llllll1_l1_+l11l1l_l1_ (u"ࠪ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ函")+l1l11l111lll_l1_+l11l1l_l1_ (u"ࠫࡡࡴࠧ凾")
		if l1l11l1lll1l_l1_.isdigit():
			l11ll11l1lll_l1_[l1l1llllll1_l1_] = int(l1l11l1lll1l_l1_)
			if int(l1l11l1lll1l_l1_)>100: l1l11l1lll1l_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ凿")
			else: l1l11l1lll1l_l1_ = l11l1l_l1_ (u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ刀")
		if l1l1llllll1_l1_ not in l1l11llll11l_l1_:
			if   l1l11l1lll1l_l1_==l11l1l_l1_ (u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ刁"): l1ll111l11l_l1_ += l11l1l_l1_ (u"ࠨࠢࠣࠫ刂")+l1l1llllll1_l1_
			elif l1l11l1lll1l_l1_==l11l1l_l1_ (u"ࠩ࡯ࡳࡼࡻࡳࡢࡩࡨࠫ刃"): l1ll111l1l1_l1_ += l11l1l_l1_ (u"ࠪࠤࠥ࠭刄")+l1l1llllll1_l1_
	l1l11l1lllll_l1_,l11lll1l1l1l_l1_,l11lll1ll1ll_l1_ = list(zip(*l1l11ll1llll_l1_))
	for l1l1llllll1_l1_ in sorted(l111l111111_l1_):
		if l1l1llllll1_l1_ not in l1l11l1lllll_l1_:
			l1lll111ll11_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ刅")+l1l1llllll1_l1_+l11l1l_l1_ (u"ࠬࡀࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ分")+l11l1l_l1_ (u"࠭ไศࠢํ์ัีࠧ切")+l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ刈")
			if l1l1llllll1_l1_ not in l1l11llll11l_l1_: l1lll111l1ll_l1_ += l11l1l_l1_ (u"ࠨࠢࠣࠫ刉")+l1l1llllll1_l1_
	for l1l11l111lll_l1_,counts in l1l11l1ll1ll_l1_:
		l1l11l111lll_l1_ = escapeUNICODE(l1l11l111lll_l1_)
		l1l111l1l11l_l1_ += l1l11l111lll_l1_+l11l1l_l1_ (u"ࠩ࠽ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ刊")+str(counts)+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࠦࠠࠨ刋")
	l1ll111l11l_l1_ = l1ll111l11l_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭刌"))
	l1ll111l1l1_l1_ = l1ll111l1l1_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠧ刍"))
	l1lll111l1ll_l1_ = l1lll111l1ll_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠨ刎"))
	l1lll111lll1_l1_ = l1ll111l11l_l1_+l11l1l_l1_ (u"ࠧࠡࠢࠪ刏")+l1ll111l1l1_l1_
	#l1l1llll1l1l_l1_  = l11l1l_l1_ (u"ࠨ࡞ࡱࡌ࡮࡭ࡨࡖࡵࡤ࡫ࡪࡀࠠ࡜ࠢࠪ刐")+l1ll111l11l_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠬ刑")
	#l1l1llll1l1l_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡒ࡯ࡸࡗࡶࡥ࡬࡫ࠠ࠻ࠢ࡞ࠤࠬ划")+l1ll111l1l1_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ刓")
	#l1l1llll1l1l_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮ࡏࡱࡘࡷࡦ࡭ࡥࠡࠢ࠽ࠤࡠࠦࠧ刔")+l1lll111l1ll_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ刕")
	l1lll111ll1l_l1_  = l11l1l_l1_ (u"ࠧๆ๊สๆ฾ࠦิ฻ๆ้๋ࠣํวࠡษ็ฬึ์วๆฮࠣห้ฮวาฯฬࠤ࠭๐่ๆࠢฦุ้࠯ࠠโ์า๎ํํวหࠢหำํ์ࠠๆึส็้࠭刖")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ列")+l11l1l_l1_ (u"๋๋ࠩีอࠠๆ฻้ห์ࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ้ํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠧ刘")+l11l1l_l1_ (u"ࠪࡠࡳ࠭则")
	l1lll111ll1l_l1_ += l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ刚")+l1lll111lll1_l1_+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣ࡜࡯࡞ࡱࠫ创")
	l1lll111ll1l_l1_ += l11l1l_l1_ (u"࠭ๅ้ษๅ฽๊ࠥๅࠡ์ื฾้ࠦวๅสิ๊ฬ๋ฬࠡ็้๋ฬࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣว๏ࠦแ๋ัํ์์อสࠨ刜")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ初")+l11l1l_l1_ (u"ࠨ๊๊ิฬࠦๅฺ่ส๋ࠥออห็ส่้ࠥศ๋ำࠣ์ั๎ฯࠡ็ื็้ฯࠠโ์ࠣห้ฮั็ษ่ะࠬ刞")+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ刟")
	l1lll111ll1l_l1_ += l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭删")+l1lll111l1ll_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭刡")
	l1l11l1l1ll1_l1_,l11lll111lll_l1_,l1l1111lll11_l1_,l11lll111111_l1_ = 0,0,0,0
	all = l11ll11l1lll_l1_[l11l1l_l1_ (u"ࠬࡇࡌࡍࠩ刢")]
	if l11l1l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭刣") in list(l11ll11l1lll_l1_.keys()): l1l11l1l1ll1_l1_ = l11ll11l1lll_l1_[l11l1l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ判")]
	if l11l1l_l1_ (u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ別") in list(l11ll11l1lll_l1_.keys()): l11lll111lll_l1_ = l11ll11l1lll_l1_[l11l1l_l1_ (u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ刦")]
	if l11l1l_l1_ (u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ刧") in list(l11ll11l1lll_l1_.keys()): l1l1111lll11_l1_ = l11ll11l1lll_l1_[l11l1l_l1_ (u"ࠫࡒࡋࡔࡓࡑࡓࡓࡑࡏࡓࠨ刨")]
	if l11l1l_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ利") in list(l11ll11l1lll_l1_.keys()): l11lll111111_l1_ = l11ll11l1lll_l1_[l11l1l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ刪")]
	l11l1l11ll1_l1_ = all-l1l11l1l1ll1_l1_-l11lll111lll_l1_-l1l1111lll11_l1_-l11lll111111_l1_
	dummy,l1l11111ll11_l1_ = l11llll1ll1l_l1_[0]
	dummy,l11ll1ll11l1_l1_ = l11llll1ll1l_l1_[1]
	l11llll1l1l1_l1_ = l1l11111ll11_l1_-l11ll1ll11l1_l1_
	l11lll1ll1l1_l1_ += l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ别")+str(l11ll1ll11l1_l1_)+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ刬")+l11l1l_l1_ (u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭刭")
	l11lll1ll1l1_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ刮")+str(l11llll1l1l1_l1_)+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭刯")+l11l1l_l1_ (u"ࠬฮวิฬัำฬ๋ࠠࡱࡴࡲࡼࡾࠦร้ࠢࡹࡴࡳࠦ࠺ࠡࠩ到")
	l11lll1ll1l1_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ刱")+str(l1l11111ll11_l1_)+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ刲")+l11l1l_l1_ (u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩ刳")
	l11lll1ll1l1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ刴")+str(len(l11llll1ll1l_l1_[2:]))+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ刵")+l11l1l_l1_ (u"ࠫ฾ีฯࠡษ็ำํ๊ࠠศๆอ๎ࠥ็๊่ษࠣวัําสࠢ࠽ࠤࡡࡴ࡜࡯ࠩ制")
	for l11lll1l1ll_l1_,l1l1111l1111_l1_ in l11llll1ll1l_l1_[2:]:
		l11lll1l1ll_l1_ = escapeUNICODE(l11lll1l1ll_l1_)
		l11lll1l1ll_l1_ = l11lll1l1ll_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠧ刷")).strip(l11l1l_l1_ (u"࠭ࠠ࠯ࠩ券"))
		l11lll1ll1l1_l1_ += l11lll1l1ll_l1_+l11l1l_l1_ (u"ࠧ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ刹")+str(l1l1111l1111_l1_)+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠥ࠭刺")
	#l11lll1ll1l1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲ࠳࠭刻")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭刼")+str(l11l1l11ll1_l1_)+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭刽")+l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠศึอ฾้ะࠠ࠻ࠢࠪ刾")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ刿")+str(l1l11l1l1ll1_l1_)+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ剀")+l11l1l_l1_ (u"ࠨู็ฬฬะࠠิ์ิๅึࠦศศ์ฮ์๋ࠦ࠺ࠡࠩ剁")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ剂")+str(l11lll111111_l1_)+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ剃")+l11l1l_l1_ (u"ࠫ฼๊ศศฬࠣื๏ืแาࠢส่๊ิวำ่ࠣ࠾ࠥ࠭剄")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ剅")+str(l11lll111lll_l1_)+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ剆")+l11l1l_l1_ (u"ࠧหอห๎ฯࠦสุสํๆ้่ࠥะ์ࠣ฽๊อฯࠡ࠼ࠣࠫ則")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭剈")+str(l1l1111lll11_l1_)+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ剉")+l11l1l_l1_ (u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩ削")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠫࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ剋")+str(len(l1l11l1ll1ll_l1_))+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ剌")+l11l1l_l1_ (u"࠭ฯ้ๆุࠣ฿๊สࠡใํำ๏๎็ศฬࠣ࠾ࠥ࠭前")
	#l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ剎")+l11l1l_l1_ (u"ࠨ฻าำࠥอไโ์า๎ํํวหࠢส่ฯ๐ࠠี฼็๋ฬࠦ็ัษࠣห้ฮั็ษ่ะࠥ็๊ࠡษ็฽ฬ๊ๅࠡ์๋้ࠥษๅิࠢࠫห้ฮวาฯฬ࠭ࠬ剏")+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ剐")
	l11ll1l1lll1_l1_ += l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ剑")+l1l111l1l11l_l1_
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ剒"),l11l1l_l1_ (u"ࠬ฿ฯะࠢส่ศา็ำหࠣห้ะ๊ࠡษึฮำีๅห๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ剓"),l11lll1ll1l1_l1_,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ剔"))
	#l11l1llll1_l1_(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ剕"),l11l1l_l1_ (u"ࠨฮ่๎฾ࠦ็ั้ࠣห้ษัใษ่ࠤฯิีࠡลึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡࠢไๆ฼๊้ࠦ็ࠣวู๊ࠠࠩษ็ฬฬือสࠫࠪ剖"),l11ll1l1lll1_l1_,l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ剗"))
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ剘"),l11l1l_l1_ (u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥอไห์ุࠣ฿๊็ศ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡษ็ฬฬือสࠢࠫ๎ํ๋ࠠฤ็ึ࠭ࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ剙"),l11ll1l1lll1_l1_,l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ剚"))
	l11l1llll1_l1_(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭剛"),l11l1l_l1_ (u"ࠧๆ๊สๆ฾ࠦวีฬ฽่ฯࠦวๅสสีาฯࠠࠩ์๋้ࠥษๅิࠫࠣࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ剜"),l1lll111ll1l_l1_,l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ剝"))
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠩ࡯ࡩ࡫ࡺࠧ剞"),l11l1l_l1_ (u"ࠪว฾๊้ࠡษ็ำํ๊ࠠศๆอ๎ࠥอไษษิัฮࠦࠨ๋๊่ࠤศ๋ำࠪࠢสืฯิฯๆฬࠣห้ฮั็ษ่ะࠬ剟"),l1lll111ll11_l1_,l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ剠"))
	return
def l11lll1llll1_l1_():
	message = l11l1l_l1_ (u"ࠬํะศࠢส่อืๆศ็ฯࠤ๏฿ๅๅࠢสๅ฻๊ࠠษษึฮำีวๆࠢฯ่ิࠦใ้ัํࠤ࠭ࡑ࡯ࡥ࡫ࠣࡗࡰ࡯࡮ࠪࠢส่ี๐ࠠศี่๋ࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ࡟ࡲࡡࡴ้ࠠ็่็๋ࠦสฬสํฮ์ࠦศศีอาิอๅࠡ็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࠦร้ࠢอั๊๐ไ่่๊ࠢࡡࡴ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࡝࠲ࡇࡔࡒࡏࡓ࡟࡟ࡲࡡࡴ࡜࡯๊ࠢิ์ࠦวๅำึห้ฯ้ࠠ฼ํี์อࠠไอํี๋่ࠥอ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬ๊ࠡสุ่๊๊ะࠢฦ๎฻อࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡลฯ์อฯࠠศๆหี๋อๅอࠩ剡")
	l11l1llll1_l1_(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭剢"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ剣"),message,l11l1l_l1_ (u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ剤"))
	return
def l1l11l11l1ll_l1_():
	message = l11l1l_l1_ (u"ࠩส่ึอศุ์้ࠤศีๆศ้ࠣๅ๏ํๅศࠢอ฻อ๐โࠡๅ๋ำ๏ูࠦๆษาࠤํํ่ࠡ฻หหึฯฺ่ࠠࠣฮะฮ๊หࠢๆห๊๊ࠠศ๊อ์๊อส๋ๅํࠤ้ฮั็ษ่ะ้่ࠥะ์ࠣ์๊฿็ࠡษูหๆฯฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ์๊฿็ࠡษูหๆฯࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤํู๋่ࠢสฺฬ็ษࠡ็ัึู๋ࠦๆษาࠤํ็๊่ࠢฦ๎฻อࠠอ็ํ฽ࠥอูะษาฮ้่ࠥะ์ࠣห้๋ืๅ๊หอู๊ࠥๆๆࠣฬึ์วๆฮࠣ฽๊อฯ๊ࠡๆ่์อࠠหฬ่ࠤฬ๎ส้็สฮ๏้๊ศ๋่ࠢฬࠦสฮฬสะࠥษ๊่๋ࠡ฽๋ࠥๆࠡษ็าอืษࠡใํࠤ่๎ฯ๋ࠢฦ์ࠥอไฯสิอࠥ็๊ࠡฬฮฬ๏ะࠠฤุสๅฬะࠠไ๊า๎ࠬ剥")+l11l1l_l1_ (u"ࠪࡠࡳ࠭剦")+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ剧")+l1l1l1l_l1_[l11l1l_l1_ (u"ࠬࡑࡏࡅࡋࡈࡑࡆࡊ࡟ࡂࡒࡓࠫ剨")][0]+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ剩")+l1l1l1l_l1_[l11l1l_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭剪")][1]+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ剫")
	message += l11l1l_l1_ (u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮื๋่ࠣวิ์ว่๊้ࠢฬࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ剬")+l1l1l1l_l1_[l11l1l_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ剭")][1]+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠠࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ剮")+l1l1l1l_l1_[l11l1l_l1_ (u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭副")][0]+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ剰")
	message += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࡡࡴฬๆ์฼ࠤ๊๊แศฬࠣ฽๊อฯࠡ็๋ะํีษࠡใํࠤฬ๊ๅ้ไ฼ࠤศีๆศ้ࠪ剱")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ割")+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ剳")+l1l1l1l_l1_[l11l1l_l1_ (u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫ剴")][2]+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭創")
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ剶"),l11l1l_l1_ (u"࠭วๅ็๋ห็฿ࠠศๆิื๊๐ษࠡๆหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠬ剷"),message,l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ剸"))
	return
def l1l11l11l11l_l1_(l1l11l11llll_l1_):
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࠧ剹")+l1l11l11llll_l1_+l11l1l_l1_ (u"ࠩࠬࠫ剺"), True)
	return
def l1l11l111111_l1_():
	l1l1lllll_l1_(l11l1l_l1_ (u"ࠪࡷࡹࡵࡰࠨ剻"))
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠦࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭ࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࡔࡧࡷࡸ࡮ࡴࡧࡴࠫࠥ剼"))
	return
def l11llll1ll11_l1_():
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠬࠫ剽"), True)
	return
def l1l111l1l111_l1_(l1ll_l1_=True):
	if not l1ll_l1_: l1ll111111_l1_ = True
	else: l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭剾"),l11l1l_l1_ (u"ࠧࠨ剿"),l11l1l_l1_ (u"ࠨࠩ劀"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ劁"),l11l1l_l1_ (u"ࠪฬึ์วๆฮࠣ็ํี๊ࠡ์ๅ์๊ࠦศฺ็็๎ฮࠦสฮัํฯࠥาๅ๋฻ࠣห้หึศใสฮࠥะไใษษ๎ฬࠦใๅࠢ࠵࠸ูࠥวฺหࠣ์้้ๆࠡ็่็๋ࠦลอำสล์อࠠศๆล๊ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬะำ๏ัࠠอ็ํ฽ࠥหึศใสฮ้่ࠥะ์ࠣห้ศๆࠡมࠪ劂"))
	if l1ll111111_l1_==1:
		xbmc.executebuiltin(l11l1l_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡅࡩࡪ࡯࡯ࡔࡨࡴࡴࡹࠧ劃"))
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭劄"),l11l1l_l1_ (u"࠭ࠧ劅"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ劆"),l11l1l_l1_ (u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢาื์ฺࠠ็สำࠥ࠴๋ࠠำฯํࠥหูุษฤࠤ่๎ฯ๋ࠢ࠸ࠤิ่ววไࠣวํࠦรไอิࠤ้้๊ࠡ์้๋๏ูࠦๆๆํอࠥอไหฯา๎ะ࠭劇"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭劈"))
	l11l11l1l1l_l1_ = not l1ll111111_l1_
	return l11l11l1l1l_l1_
def l11lll1l11l1_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ劉"),l11l1l_l1_ (u"ࠫࠬ劊"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ劋"),l11l1l_l1_ (u"࠭ไๆีะࠤ๊ำส้์สฮ่ࠥวว็ฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ๆฬฬๅสࠢส่ฯ๐ࠠหำํำ๋ࠥำฮ้สࠤํ๊วࠡฬาา้ࠦลๅ์๊หࠥ๎ไไ่ࠣฬฬูสฯัส้ࠥࠨวๅ็ส์ุࠨࠠฤ๊ࠣࠦฬ๊ั๋็๋ฮࠧࠦวื฼ฺࠤ฾๊้ࠡษ็ึึࠦฬ่หࠣห้๐ๅ๋่ࠣวํࠦวิฬัำ๊ࠦࠢศๆๆ๎อ๎ัะࠤࠣ์ฬ฼ฺุࠢ฼่๎ࠦอาใࠣࠦࡈࠨࠠฤ๊ࠣ฽้๏ࠠศุ฽฻ࠥ฿ไ๊ࠢีีࠥࠨวๅไสส๊ฯࠢࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฮࠦวๅ์่๎๋࠭劌"))
	return
def l1l111ll1ll1_l1_():
	DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ劍"),l11l1l_l1_ (u"ࠨࠩ劎"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ劏"),l11l1l_l1_ (u"่้ࠪะูศ็็ࠤ๊฿ࠠศๆ่ๅ฻๊ษࠡ࠰ࠣหีํศࠡว็ํࠥอไาษห฻ࠥอไั์ࠣฮึ๐ฯࠡวูหๆะ็ࠡล๋ࠤู๊อ่่๊ࠢࠥࠦโศศ่อࠥอไๆใู่ฮ่ࠦๅๅ้ࠤ้อࠠหุ฽฻ࠥ฿ไ๋้ࠣ์้อࠠหึ฽่์ࠦ࠮๊ࠡหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํษๅศࠢหหุะฮะษ่ࠤࠧอไไ์ห์ึีࠢࠡใสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํ์แิࠢส่่๊วๆ๋ࠢห้฽ั๋ไฬࠤ฾์ฯࠡษ็ฮ฾อๅๅ่ࠢ฽๋ࠥอห๊ํหฯࠦโ้ษษ้ࠥอไๆใู่ฮ࠭劐"))
	return
#l1l11l1l11l1_l1_ 	  required	and l1l11l1l11l1_l1_     installed	and		not l11l11l1l1l_l1_		ignore
#l1l11l1l11l1_l1_ not required	and	l1l11l1l11l1_l1_ not installed 	and 	    l11l11l1l1l_l1_		ignore
#l1l11l1l11l1_l1_ not required	and	l1l11l1l11l1_l1_ not installed 	and 	not l11l11l1l1l_l1_		ignore
#l1l11l1l11l1_l1_ not required	and	l1l11l1l11l1_l1_     installed 	and 	not l11l11l1l1l_l1_		ignore
#l1l11l1l11l1_l1_     required	and	l1l11l1l11l1_l1_ not installed 	and 	    l11l11l1l1l_l1_		l1lllllll1l_l1_ l11lll111lll_l1_	l11ll11lll1l_l1_
#l1l11l1l11l1_l1_     required	and	l1l11l1l11l1_l1_ not installed 	and 	not l11l11l1l1l_l1_		l1lllllll1l_l1_ l11lll111lll_l1_	l11ll11lll1l_l1_
#l1l11l1l11l1_l1_     required 	and l1l11l1l11l1_l1_     installed 	and 	    l11l11l1l1l_l1_		l1lllllll1l_l1_ l1l11ll1l111_l1_	l11ll11lll1l_l1_
#l1l11l1l11l1_l1_ not required	and	l1l11l1l11l1_l1_     installed 	and 	    l11l11l1l1l_l1_		l1lllllll1l_l1_ l1l11ll1l111_l1_	l11ll11lll1l_l1_
#l1l1111l1ll_l1_: required and not installed: l1lllllll1l_l1_ l11lll111lll_l1_
#l11ll1ll1ll_l1_: installed and l1lllllll1l_l1_ update: l1lllllll1l_l1_ l1l11ll1l111_l1_
def l1l111lll11l_l1_(l1ll_l1_=True):
	l1l1l1l111ll_l1_ = l11llllllll1_l1_([l11l1l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭劑")])
	l1l1111ll1l1_l1_ = []
	for addon_id in [l11l1l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ劒")]:
		if addon_id not in list(l1l1l1l111ll_l1_.keys()): continue
		l11l11l1l1l_l1_,l1l111111lll_l1_,l11ll11ll1ll_l1_,l1l111ll11l1_l1_,l1l111l1lll1_l1_,l11ll1l1l11l_l1_,l1l111ll1111_l1_ = l1l1l1l111ll_l1_[addon_id]
		if not l1l111111lll_l1_ or (l1l111111lll_l1_ and l11l11l1l1l_l1_): l1l1111ll1l1_l1_.append(addon_id)
	l11ll11l111l_l1_ = len(l1l1111ll1l1_l1_)>0
	#import sqlite3
	conn = sqlite3.connect(l1l111ll1l1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	l1l111lll1l1_l1_ = []
	for addon_id in l1l11lll1lll_l1_:
		cc.execute(l11l1l_l1_ (u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࠪࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡧࡱࡥࡧࡲࡥࡥࠢࡀࠤࠧ࠷ࠢࠡࡣࡱࡨࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ劓")+addon_id+l11l1l_l1_ (u"ࠧࠣࠢ࠾ࠫ劔"))
		l11llll1l1ll_l1_ = cc.fetchall()
		if l11llll1l1ll_l1_: l1l111lll1l1_l1_.append(addon_id)
	l11llll11l1l_l1_ = len(l1l111lll1l1_l1_)>0
	for addon_id in l1l111ll11ll_l1_:
		cc.execute(l11l1l_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࡱࡵ࡭࡬࡯࡮ࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭劕")+addon_id+l11l1l_l1_ (u"ࠩࠥࠤࡀ࠭劖"))
		l1l11llll1l1_l1_ = cc.fetchall()
		if l1l11llll1l1_l1_ and l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ劗") not in str(l1l11llll1l1_l1_): l1l1111ll1l1_l1_.append(addon_id)
	l11lll11l1l1_l1_ = len(l1l1111ll1l1_l1_)>0
	l1l1111ll1l1_l1_ = list(set(l1l1111ll1l1_l1_))
	#conn.commit()
	conn.close()
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ劘"),l11l1l_l1_ (u"ࠬࡴࡥࡦࡦࡢࡪ࡮ࡾࡩ࡯ࡩࡢࡶࡪࡶ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰ࠽ࠤࠥ࠭劙")+str(l11ll11l111l_l1_))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ劚"),l11l1l_l1_ (u"ࠧ࡯ࡧࡨࡨࡤࡪࡥ࡭ࡧࡷ࡭ࡳ࡭࡟ࡰ࡮ࡧࡣࡦࡪࡤࡰࡰࡶ࠾ࠥࠦࠧ力")+str(l11llll11l1l_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ劜"),l11l1l_l1_ (u"ࠩࡱࡩࡪࡪ࡟ࡧ࡫ࡻ࡭ࡳ࡭࡟ࡰࡴ࡬࡫࡮ࡴ࠺ࠡࠢࠪ劝")+str(l11lll11l1l1_l1_))
	l11l11l1l1l_l1_ = False
	if l11llll11l1l_l1_ or l11lll11l1l1_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ办"),l11l1l_l1_ (u"ࠫࠬ功"),l11l1l_l1_ (u"ࠬ࠭加"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ务"),l11l1l_l1_ (u"ࠧศๆหี๋อๅอ๋ࠢะิࠦๅีๅ็อࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศั่้ࠣ็๊ะ์๋๋ฬะࠠศๆ฼ีอ๐ษࠡ࠰࠱࠲่ࠥฯࠡ์ๆ์๋ࠦๅฺู็ࠤศ๎ࠠๅษࠣ๎฾๋ไࠡสุ์ึฯࠠึฯํัฮࠦ࡜࡯ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡ์๊ࠠหำํำࠥหีๅษะࠤ์ึ็ࠡษ็ู้้ไสࠢส่ว์ࠠภ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ劢"))
		if l1ll111111_l1_==1:
			l1l11ll1111l_l1_ = True
			if l11ll11l111l_l1_:
				l1l11ll1111l_l1_ = l1l11ll1l1l1_l1_(False)
			l11ll1lll11l_l1_ = True
			if l11llll11l1l_l1_:
				for addon_id in l1l111lll1l1_l1_: l11lllllllll_l1_(addon_id)
				l11ll1lll11l_l1_ = True
			l11lllll1ll1_l1_ = True
			if l11lll11l1l1_l1_:
				conn = sqlite3.connect(l1l111ll1l1l_l1_)
				conn.text_factory = str
				cc = conn.cursor()
				for addon_id in l1l1111ll1l1_l1_:
					if l11l1l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࠫ劣") in addon_id: l1l11llll1l1_l1_ = addon_id
					else: l1l11llll1l1_l1_ = l11l1l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ劤")
					try: cc.execute(l11l1l_l1_ (u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧ劥")+l1l11llll1l1_l1_+l11l1l_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪ劦")+addon_id+l11l1l_l1_ (u"ࠬࠨࠠ࠼ࠩ劧"))
					except: l11lllll1ll1_l1_ = False
				conn.commit()
				conn.close()
			time.sleep(1)
			xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ动"))
			time.sleep(1)
			if l1l11ll1111l_l1_ or l11ll1lll11l_l1_ or l11lllll1ll1_l1_:
				l11l11l1l1l_l1_ = False
				DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ助"),l11l1l_l1_ (u"ࠨࠩ努"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ劫"),l11l1l_l1_ (u"ࠪฮ๊ะࠠษ่ฯหาูࠦๆๆํอࠥะแฺ์็ࠤํหีๅษะࠤฬ๊สฮัํฯࠥอไหๆๅหห๐ࠠๅฮ่๎฾ࠦลืษไหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ劬"))
			else:
				l11l11l1l1l_l1_ = True
				DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ劭"),l11l1l_l1_ (u"ࠬ࠭劮"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ劯"),l11l1l_l1_ (u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หࠣษฺ๊วฮࠢส่ฯำฯ๋อࠣห้ะไใษษ๎๊ࠥลืษไหฯࠦศา่ส้ัูࠦๆษาࠫ劰"))
	elif l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ励"),l11l1l_l1_ (u"ࠩࠪ劲"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭劳"),l11l1l_l1_ (u"ࠫฬ๊ศา่ส้ัࠦไๆࠢํะิࠦๅีๅ็อࠥ็๊ࠡษ็ฮาี๊ฬࠢส่ฯ๊โศศํࠤ้หึศใสฮࠥฮั็ษ่ะࠥ฿ๅศัࠪ労"))
	return l11l11l1l1l_l1_
def l11lll11l111_l1_():
	l11ll11ll11l_l1_,l1l11l1l1lll_l1_,l11ll1l111l1_l1_ = False,l11l1l_l1_ (u"ࠬ࠭劵"),l11l1l_l1_ (u"࠭ࠧ劶")
	l1l11l1l11ll_l1_,l11lllll1lll_l1_,l1l11111l1ll_l1_ = False,l11l1l_l1_ (u"ࠧࠨ劷"),l11l1l_l1_ (u"ࠨࠩ劸")
	l1l1l1l111ll_l1_ = l11llllllll1_l1_([l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ効"),l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬ劺"),l11l1l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪ劻")])
	for addon_id in [l11l1l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ劼"),l11l1l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ劽"),l11l1l_l1_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭劾")]:
		if addon_id not in list(l1l1l1l111ll_l1_.keys()): continue
		l11l11l1l1l_l1_,l1l111111lll_l1_,l1l11l1llll1_l1_,l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l1l111l1l1l1_l1_,l11ll111ll1l_l1_ = l1l1l1l111ll_l1_[addon_id]
		if addon_id==l11l1l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭势"):
			l1l11l1l11ll_l1_ = l11l11l1l1l_l1_
			l11lllll1lll_l1_ = l11l1l_l1_ (u"ࠩࠫࠫ勀")+l1l111111lll_l1_+l11l1l_l1_ (u"ࠪࠤࠬ勁")+TRANSLATE(l1l111l1l1l1_l1_)+l11l1l_l1_ (u"ࠫ࠮࠭勂")
			l1l11111l1ll_l1_ = l1l111l1ll1l_l1_
		elif addon_id==l11l1l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ勃"):
			l11ll11ll11l_l1_ = l11ll11ll11l_l1_ or l11l11l1l1l_l1_
			l1l11l1l1lll_l1_ += l11l1l_l1_ (u"࠭ࠠࠡ࠮ࠣࠤ࠭࠭勄")+l1l111111lll_l1_+l11l1l_l1_ (u"ࠧࠡࠩ勅")+TRANSLATE(l1l111l1l1l1_l1_)+l11l1l_l1_ (u"ࠨࠫࠪ勆")
			l11ll1l111l1_l1_ += l11l1l_l1_ (u"ࠩࠣࠤ࠱ࠦࠠࠨ勇")+l1l111l1ll1l_l1_
		elif addon_id==l11l1l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ勈"):
			l11llll11111_l1_ = l11l11l1l1l_l1_
			l11lll1l1lll_l1_ = l11l1l_l1_ (u"ࠫ࠭࠭勉")+l1l111111lll_l1_+l11l1l_l1_ (u"ࠬࠦࠧ勊")+TRANSLATE(l1l111l1l1l1_l1_)+l11l1l_l1_ (u"࠭ࠩࠨ勋")
			l11ll11l11ll_l1_ = l1l111l1ll1l_l1_
	l1l11l1l1lll_l1_ = l1l11l1l1lll_l1_.strip(l11l1l_l1_ (u"ࠧࠡࠢ࠯ࠤࠥ࠭勌"))
	l11ll1l111l1_l1_ = l11ll1l111l1_l1_.strip(l11l1l_l1_ (u"ࠨࠢࠣ࠰ࠥࠦࠧ勍"))
	l1l11l111l_l1_  = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ勎")+l1l11111l1ll_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ勏")
	l1l11l111l_l1_ += l11l1l_l1_ (u"ࠫࡡࡴࠧ勐")+l11l1l_l1_ (u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦ็้ࠢ࠽ࠤ࡛ࠥࠦࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ勑")+l11lllll1lll_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ勒")
	l1l11l111l_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ勓")+l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅ็ัึู๋ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭勔")+l11ll1l111l1_l1_+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ動")
	l1l11l111l_l1_ += l11l1l_l1_ (u"ࠪࡠࡳ࠭勖")+l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ส่ส฻ฯศำࠣห้ึ๊ࠡษ้ฮࠥะำหะา้์ࠦไๆะี๊ࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭勗")+l1l11l1l1lll_l1_+l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ勘")
	l1l11l111l_l1_ += l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ務")+l11l1l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭勚")+l11ll11l11ll_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ勛")
	l1l11l111l_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࠬ勜")+l11l1l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศั๋ࠣํࠦ࠺ࠡࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭勝")+l11lll1l1lll_l1_+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭勞")
	l11l11l1l1l_l1_ = (l1l11l1l11ll_l1_ or l11ll11ll11l_l1_)
	if l11l11l1l1l_l1_:
		header = l11l1l_l1_ (u"ࠬอไาฮสลࠥะอะ์ฮࠤส฼วโษอࠤ่๎ฯ๋ࠢ็ั้ࠦวๅ็ืห่๊ࠧ募")
		l1l1l11l11_l1_ = l11l1l_l1_ (u"࠭ว็ฬࠣฬาอฬสࠢ็ฮาี๊ฬࠢหี๋อๅอࠢ฼้ฬีࠠฤ๊ࠣฮาี๊ฬ่ࠢาื์ฺࠠ็สำࠬ勠")
	else:
		header = l11l1l_l1_ (u"ࠧฮษ็๎ฬࠦไศࠢํ์ัีࠠหฯา๎ะอสࠡๆหี๋อๅอࠢ฼้ฬีࠠฤ๊้ࠣำุๆࠡ฻่หิ࠭勡")
		l1l1l11l11_l1_ = l11l1l_l1_ (u"ࠨษ็ีัอมࠡวห่ฬเࠠศๆ่ฬึ๋ฬࠡ฻้ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮํอฬ่ๅࠪ勢")
	l1l1l111ll_l1_ = l11l1l_l1_ (u"ࠩ็็๏ฺ๊ࠦ็็ࠤ฾์ฯไࠢส่ฯำฯ๋อࠣห้ะไใษษ๎ࠥ๐ฬษࠢฦ๊ࠥ๐ใ้่่ࠣิ๐ใࠡใํࠤ่๎ฯ๋࡞ࡱ้ำุๆࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨ勣")
	l1l1lll111_l1_ = l1l11l111l_l1_+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ勤")+l1l1l11l11_l1_+l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ勥")+l1l1l111ll_l1_
	l11l1llll1_l1_(l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ勦"),header,l1l1lll111_l1_,l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ勧"))
	return
def l1l1111l1ll1_l1_(l1ll_l1_=True,l11lll11ll1l_l1_=True):
	#DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ勨"),l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ勩"))
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ勪"),l11l1l_l1_ (u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫ勫"))
	if l1ll_l1_:
		l11lll11l111_l1_()
		l1l111l11l1l_l1_()
	if l11lll11ll1l_l1_:
		l11ll1ll1lll_l1_ = l1l111lll11l_l1_(False)
		l11ll1ll1ll1_l1_ = l1l111l1l111_l1_(l1ll_l1_)
		if not l11ll1ll1lll_l1_ and not l11ll1ll1ll1_l1_:
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ勬"))
	return
def l1l11ll1l1l1_l1_(l1ll_l1_=True):
	l1l1l1l111ll_l1_ = l11llllllll1_l1_([l11l1l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧ勭")])
	l1ll111111_l1_,l1l11l1l1l1l_l1_,l1l11lll11ll_l1_ = True,True,True
	for addon_id in [l11l1l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ勮")]:
		l11l11l1l1l_l1_,l1l111111lll_l1_,l1l11l1llll1_l1_,l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l1l111l1l1l1_l1_,l11ll111ll1l_l1_ = l1l1l1l111ll_l1_[addon_id]
		if l11l11l1l1l_l1_:
			l1l11l1l1l1l_l1_ = False
			break
	if l1l11l1l1l1l_l1_:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ勯"),l11l1l_l1_ (u"ࠨࠩ勰"),l11l1l_l1_ (u"ࠩไัฺࠦๅฯิ้ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠫ勱"),l11l1l_l1_ (u"้ࠪำุๆࠡ฻่หิࠦๅ้ฮ๋ำࠥ฿ๆะๅࠣ์๊็ูๅ๋ࠢะฬําࠡๆ็หุะฮะษ่ࠫ勲"))
		return
	if l1ll_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ勳"),l11l1l_l1_ (u"ࠬ࠭勴"),l11l1l_l1_ (u"࠭ࠧ勵"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ勶"),l11l1l_l1_ (u"ࠨ็ัึู๋ࠦๆษาࠤࡊࡓࡁࡅࠢࡕࡩࡵࡵࡳࡪࡶࡲࡶࡾࡢ࡮ࠡใํ๋๋ࠥิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦลๆษࠣๆิ๐ๅࠡล๋ࠤ๊็โ้ัࠣวํࠦๅห๊ๅๅࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣษฺ๊วฮࠢสฺ่๊ใๅหࠣห้ศๆࠡมࠪ勷"))
		if l1ll111111_l1_!=1: return
	if l1ll111111_l1_==1:
		for addon_id in [l11l1l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ勸")]:
			if addon_id not in list(l1l1l1l111ll_l1_.keys()): continue
			l11l11l1l1l_l1_,l1l111111lll_l1_,l1l11l1llll1_l1_,l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l1l111l1l1l1_l1_,l11ll111ll1l_l1_ = l1l1l1l111ll_l1_[addon_id]
			succeeded = l11lll1l11ll_l1_(addon_id,l11ll111ll1l_l1_,l1ll_l1_)
			l1l11lll11ll_l1_ = l1l11lll11ll_l1_ and succeeded
	if l1ll_l1_:
		if l1l11lll11ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ勹"),l11l1l_l1_ (u"ࠫࠬ勺"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ勻"),l11l1l_l1_ (u"࠭สๆࠢอฯอ๐ส๊ࠡอๅ฾๐ไࠡ࡞ࡱࠤ๊ิา็ࠢ฼้ฬีࠠࡆࡏࡄࡈࠥࡘࡥࡱࡱࡶ࡭ࡹࡵࡲࡺࠩ勼"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ勽"),l11l1l_l1_ (u"ࠨࠩ勾"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ勿"),l11l1l_l1_ (u"่้ࠪษำโࠢ็้ࠥ๐สๆๅ้ࠤฬ๊ศา่ส้ัࠦๅ็ࠢศู้ออࠡ็ื็้ฯ࡜࡯่ࠢาื์ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠧ匀"))
	return l1l11lll11ll_l1_
	#xbmc.executebuiltin(l11l1l_l1_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ匁")+sys.argv[0]+l11l1l_l1_ (u"ࠬࡅ࡭ࡰࡦࡨࡁ࠷࠼࠰ࠨ匂")+l11l1l_l1_ (u"ࠨࠩࠣ匃"))
	#xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ匄"))
def l11lll1l11ll_l1_(addon_id,l11ll111ll1l_l1_,l1ll_l1_=True):
	succeeded = False
	if l1ll_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࠩ包"),l11l1l_l1_ (u"ࠩࠪ匆"),l11l1l_l1_ (u"ࠪࠫ匇"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ匈"),l11l1l_l1_ (u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨ匉"))
		if l1ll111111_l1_!=1: return False
	l11ll1l11111_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11ll111ll1l_l1_)
	if l11ll1l11111_l1_:
		import zipfile,io
		l11lllll1l11_l1_ = io.BytesIO(l11ll1l11111_l1_)
		zf = zipfile.ZipFile(l11lllll1l11_l1_)
		zf.extractall(l1ll11l11l_l1_)
		time.sleep(1)
		xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ匊"))
		time.sleep(1)
		result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪ匋")+addon_id+l11l1l_l1_ (u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡴࡳࡷࡨࢁࢂ࠭匌"))
		if l11l1l_l1_ (u"ࠩࡒࡏࠬ匍") in result: succeeded = True
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭匎"),l11l1l_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖࡣࡉࡋࡔࡂࡋࡏࡗࠬ匏"))
	if l1ll_l1_:
		if succeeded: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭匐"),l11l1l_l1_ (u"࠭ࠧ匑"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ匒"),l11l1l_l1_ (u"ࠨฬ่ࠤอ์ฬศฯࠣฮะฮ๊หࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠬ匓"))
		else: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ匔"),l11l1l_l1_ (u"ࠪࠫ匕"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ化"),l11l1l_l1_ (u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪ北"))
	return succeeded
	l11l1l_l1_ (u"ࠨࠢࠣࠌࠌࠧ࡮ࡳࡰࡰࡴࡷࠤࡸࡷ࡬ࡪࡶࡨ࠷ࠏࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡣࡧࡨࡴࡴࡳࡠࡦࡥࡪ࡮ࡲࡥࠪࠌࠌࡧࡴࡴ࡮࠯ࡶࡨࡼࡹࡥࡦࡢࡥࡷࡳࡷࡿࠠ࠾ࠢࡶࡸࡷࠐࠉࡤࡥࠣࡁࠥࡩ࡯࡯ࡰ࠱ࡧࡺࡸࡳࡰࡴࠫ࠭ࠏࠏࡣࡤ࠰ࡨࡼࡪࡩࡵࡵࡧ࡚ࠫࠫࡖࡄࡂࡖࡈࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡔࡇࡗࠤࡴࡸࡩࡨ࡫ࡱࠤࡂࠦࠢࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫࠧ࠭ࠩࠋࠋࡦࡳࡳࡴ࠮ࡤࡱࡰࡱ࡮ࡺࠨࠪࠌࠌࡧࡴࡴ࡮࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠦࠧࠨ匘")
def l1l1111lllll_l1_(addon_id,l1ll_l1_=True):
	if l1ll_l1_==l11l1l_l1_ (u"ࠧࠨ匙"): l1ll_l1_ = True
	#l1l11l1ll11l_l1_ = xbmc.getCondVisibility(l11l1l_l1_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫࠫ匚")+addon_id+l11l1l_l1_ (u"ࠩࠬࠫ匛"))
	l1l111llll11_l1_ = l11lll111l11_l1_([addon_id])
	l1l111ll1lll_l1_,l1l11l1ll11l_l1_ = l1l111llll11_l1_[addon_id]
	if l1l11l1ll11l_l1_:
		succeeded = True
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ匜"),l11l1l_l1_ (u"ࠫࠬ匝"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ匞"),l11l1l_l1_ (u"࠭แฮืࠣห้หึศใฬࠤࡡࡴࠠࠨ匟")+addon_id+l11l1l_l1_ (u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠๆ๊ฯ์ิฯ้ࠠ็ไ฽้ฯ้ࠠฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪ匠"))
	else:
		succeeded = False
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ匡"),l11l1l_l1_ (u"ࠩࠪ匢"),l11l1l_l1_ (u"ࠪࠫ匣"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ匤"),l11l1l_l1_ (u"ࠬ࠭匥")+addon_id+l11l1l_l1_ (u"࠭ࠠ࡝ࡰ๋ࠣีํࠠฤๆศฺฬ็ษࠡ฻้ำฺ่๋ࠦำ้ࠣๆ฿ไสࠢฦ์ࠥเ๊า่ࠢ์ั๎ฯสࠢ࠱ࠤ๏าศࠡฬฮฬ๏ะ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ้้๊ࠡ์฼้้ࠦวๅสิ๊ฬ๋ฬࠡ฻้ำ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤ࠳ࠦ็ๅࠢอี๏ีࠠหอห๎ฯ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫ匦"))
		if l1ll111111_l1_==1:
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡊࡰࡶࡸࡦࡲ࡬ࡂࡦࡧࡳࡳ࠮ࠧ匧")+addon_id+l11l1l_l1_ (u"ࠨࠫࠪ匨"))
			time.sleep(1)
			xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡖࡩࡳࡪࡃ࡭࡫ࡦ࡯࠭࠷࠱ࠪࠩ匩"))
			time.sleep(1)
			while xbmc.getCondVisibility(l11l1l_l1_ (u"࡛ࠪ࡮ࡴࡤࡰࡹ࠱ࡍࡸࡇࡣࡵ࡫ࡹࡩ࠭ࡶࡲࡰࡩࡵࡩࡸࡹࡤࡪࡣ࡯ࡳ࡬࠯ࠧ匪")): time.sleep(1)
			result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧ匫")+addon_id+l11l1l_l1_ (u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ匬"))
			if l11l1l_l1_ (u"࠭ࡏࡌࠩ匭") in result:
				succeeded = True
				if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ匮"),l11l1l_l1_ (u"ࠨࠩ匯"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ匰"),l11l1l_l1_ (u"ࠪฮ๊ࠦแฮืࠣวํࠦสฬสํฮࠥษ่ࠡฬไ฽๏๊ࠠฤ๊ࠣฮาี๊ฬࠢส่ส฼วโหࠣห้๋ืๅ๊หอࠥ๎็๋ࠢส่ว์ࠠอษ๊ึฮࠦไๅษึฮำีวๆࠩ匱"))
			elif l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ匲"),l11l1l_l1_ (u"ࠬ࠭匳"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ匴"),l11l1l_l1_ (u"ࠧโึ็ࠤๆ๐ࠠหอห๎ฯࠦร้ࠢอๅ฾๐ไࠡล๋ࠤฯำฯ๋อࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮะฮ๊ห้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩ匵"))
	return succeeded
def l11lllll1l1l_l1_(addon_id,l1ll_l1_=True):
	l1l1l1l111ll_l1_ = l11llllllll1_l1_([addon_id])
	if addon_id not in list(l1l1l1l111ll_l1_.keys()): return False
	l11l11l1l1l_l1_,l1l111111lll_l1_,l1l11l1llll1_l1_,l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l1l111l1l1l1_l1_,l11ll111ll1l_l1_ = l1l1l1l111ll_l1_[addon_id]
	succeeded,l1l111l1ll11_l1_ = False,l11l1l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ匶")
	if l1l111l1l1l1_l1_==l11l1l_l1_ (u"ࠩࡪࡳࡴࡪࠧ匷"):
		succeeded = True
		l1l111l1ll11_l1_ = l11l1l_l1_ (u"ࠪ࡫ࡴࡵࡤࠨ匸")
	elif l1l111l1l1l1_l1_==l11l1l_l1_ (u"ࠫࡩ࡯ࡳࡢࡤ࡯ࡩࡩ࠭匹"):
		succeeded = False
		result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡆࡪࡤࡰࡰࡶ࠲ࡘ࡫ࡴࡂࡦࡧࡳࡳࡋ࡮ࡢࡤ࡯ࡩࡩࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡦࡪࡤࡰࡰ࡬ࡨࠧࡀࠢࠨ区")+addon_id+l11l1l_l1_ (u"࠭ࠢ࠭ࠤࡨࡲࡦࡨ࡬ࡦࡦࠥ࠾ࡹࡸࡵࡦࡿࢀࠫ医"))
		if l11l1l_l1_ (u"ࠧࡐࡍࠪ匼") in result: succeeded = True
		if succeeded: l1l111l1ll11_l1_ = l11l1l_l1_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩ匽")
	elif l1l111l1l1l1_l1_==l11l1l_l1_ (u"ࠩࡲࡰࡩ࠭匾"):
		succeeded = l11lll1l11ll_l1_(addon_id,l11ll111ll1l_l1_,l1ll_l1_)
		if succeeded: l1l111l1ll11_l1_ = l11l1l_l1_ (u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫ匿")
	elif l1l111l1l1l1_l1_==l11l1l_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ區"):
		l11llllll1ll_l1_ = l1l11ll1l1l1_l1_(l1ll_l1_)
		if l11llllll1ll_l1_:
			succeeded = l1l1111lllll_l1_(addon_id,l1ll_l1_)
			if succeeded: l1l111l1ll11_l1_ = l11l1l_l1_ (u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨ十")
	l11ll1l1ll11_l1_ = l1l111l1ll1l_l1_
	return succeeded,l1l111l1ll11_l1_,l11ll1l1ll11_l1_
def l1l1111llll1_l1_(l1l11l1111l1_l1_=l11l1l_l1_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ卂"),l1ll_l1_=True):
	l11ll1l1l1l1_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ千"))
	import json
	data = json.loads(l11ll1l1l1l1_l1_)
	l11ll1l1l111_l1_ = data[l11l1l_l1_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨ卄")][l11l1l_l1_ (u"ࠩࡹࡥࡱࡻࡥࠨ卅")]
	if kodi_version<19: l11ll1l1l111_l1_ = l11ll1l1l111_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ卆"))
	if l1ll_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࠬ升"),l11l1l_l1_ (u"ࠬ࠭午"),l11l1l_l1_ (u"࠭ࠧ卉"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ半"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡฮ็ำࠥ࠭卋")+l11ll1l1l111_l1_+l11l1l_l1_ (u"ࠩࠣห้ึ๊ࠡ็ึฮำีๅࠡษ็ฦ๋ࠦแ๋ࠢๆ์ิ๐ࠠฦๆ์ࠤฬ๊ลึัสีࠥอไฤะํี๊ࠥฬๅัࠣࠫ卌")+l1l11l1111l1_l1_+l11l1l_l1_ (u"ࠪࠤฤࠧࠧ卍"))
		if l1ll111111_l1_!=1: return False
	succeeded,l1l111l1ll11_l1_,l11ll1l1ll11_l1_ = l11lllll1l1l_l1_(l1l11l1111l1_l1_,False)
	if succeeded:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ华"),l11l1l_l1_ (u"ࠬ࠭协"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ卐"),l11l1l_l1_ (u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩ卑"))
		result = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬ卒")+l1l11l1111l1_l1_+l11l1l_l1_ (u"ࠩࠥࢁࢂ࠭卓"))
		if l11l1l_l1_ (u"ࠪࡓࡐ࠭協") in result: succeeded = True
		time.sleep(1)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ单"))
	elif l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭卖"),l11l1l_l1_ (u"࠭ࠧ南"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ単"),l11l1l_l1_ (u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪ卙"))
	return succeeded
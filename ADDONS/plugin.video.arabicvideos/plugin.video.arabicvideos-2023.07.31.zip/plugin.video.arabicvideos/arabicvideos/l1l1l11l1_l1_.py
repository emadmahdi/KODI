﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪະ")
headers = { l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ັ") : l11l1l_l1_ (u"ࠪࠫາ") }
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡓࡒࡇࡡࠪຳ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,text):
	if   mode==40: results = MENU()
	elif mode==41: results = l1l1ll111_l1_()
	elif mode==42: results = l1lll1l1_l1_(url)
	elif mode==43: results = PLAY(url)
	elif mode==44: results = CATEGORIES(url,text)
	elif mode==45: results = l1lllll_l1_(url,text)
	elif mode==46: results = l1l1l111l_l1_()
	elif mode==47: results = l1l11l111_l1_(url)
	elif mode==49: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪິ"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅสฮࠤฬ๊อ๋ࠢ็ๆ๋อษࠡษ็้฾อัโࠩີ"),l11l1l_l1_ (u"ࠧࠨຶ"),41)
	return
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ࠯ࠫࠬ࠲࠴࠺࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࠯ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็ฬึอๅอࠢส่าอไ๋หࠪ࠰ࠬ࠭ࠬ࠵࠸ࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ࠮ࠐࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࠼ࡩ࠴ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡫࠶ࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡴࡡ࡮ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠱ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ࠮ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱࡮ࡢ࡯ࡨ࠰ࡱ࡯࡮࡬࠮࠷࠹࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠹ࠧࠪࠌࠌࡲࡦࡳࡥࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡴࡨࡧࡪࡴࡴ࠮ࡦࡨࡪࡦࡻ࡬ࡵ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡪࠥࡴࡡ࡮ࡧ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦ࠭ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡱࡥࡲ࡫࡛࠱࡟࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲࠴࠶࠮ࠪࠫ࠱࠭ࠧ࠭ࠩ࠵ࠫ࠮ࠐࠉ࡯ࡣࡰࡩࠥࡃࠠ࡜ࠩสีู๐แࠡษ็ฬึอๅอࠩࡠࠎࠎࠩ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺ࠭ࡵࡱࡳࠦࡃࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧ࠮ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ࠫ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡲࡦࡳࡥ࡜࠲ࡠ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬ࠵࠶࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ࠴ࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡪࡷࡱࡱࠐࠉࠣࠤࠥື")
def l1lllll_l1_(url,select):
	l111l11_l1_ = [l11l1l_l1_ (u"ࠩอ฻อ๐โศฬࠣห้อฬ่ิฬࠤฬ๊ะไ์ฬຸࠫ"),l11l1l_l1_ (u"ࠪะิ๎ไࠡษ็ฬึอๅอູࠩ"),l11l1l_l1_ (u"ࠫฬ๎โศฬࠣฬึอๅอ่ส຺ࠫ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭ົ"),headers,l11l1l_l1_ (u"࠭ࠧຼ"),l11l1l_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ຽ"))
	if select==l11l1l_l1_ (u"ࠨ࠴ࠪ຾"):
		l11llll_l1_=re.findall(l11l1l_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵ࠯ࡧࡩ࡫ࡧࡵ࡭ࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷࠨࠧ຿"),html,re.DOTALL)
		if l11llll_l1_:
			block = l11llll_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡵࡩࡱࡃࠢࡣࡱࡲ࡯ࡲࡧࡲ࡬ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪເ"),block,re.DOTALL)
			for l1ll1l_l1_,url,title in items:
				if not any(value in title for value in l111l11_l1_):
					title = unescapeHTML(title)
					addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫແ"),l1111l_l1_+title,url,42,l1ll1l_l1_)
	elif select==l11l1l_l1_ (u"ࠬ࠹ࠧໂ"):
		l1l11ll11_l1_=re.findall(l11l1l_l1_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡣࡱࡻࠬ࠳࠰࠿ࠪࡵࡦࡶ࡮ࡶࡴࠨໃ"),html,re.DOTALL)
		if l1l11ll11_l1_:
			block = l1l11ll11_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠧࡩ࠴࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫໄ"),block,re.DOTALL)
			for url,title,l1ll1l_l1_ in items:
				if not any(value in title for value in l111l11_l1_):
					title = unescapeHTML(title)
					addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໅"),l1111l_l1_+title,url,42,l1ll1l_l1_)
	l1l11llll_l1_=re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࡮ࠧໆ"),html,re.DOTALL)
	if l1l11llll_l1_:
		block = l1l11llll_l1_[0]
		items=re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ໇"),block,re.DOTALL)
		for url,title in items:
			title = unescapeHTML(title)
			title = l11l1l_l1_ (u"ฺࠫ็อส່ࠢࠪ") + title
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ້ࠬ"),l1111l_l1_+title,url,45,l11l1l_l1_ (u"໊࠭ࠧ"),l11l1l_l1_ (u"ࠧࠨ໋"),select)
	return
def l1lll1l1_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠨࠩ໌"),headers,l11l1l_l1_ (u"ࠩࠪໍ"),l11l1l_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ໎"))
	l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠫࡪࡴࡴࡳࡻ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࡀࡸࡶࡡ࡯ࠢ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ໏"),html,re.DOTALL)
	if l1l11l1_l1_:
		name = l1l11l1_l1_[0]
		name = unescapeHTML(name)
		l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠬࡽࡰ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶ࠰ࡷࡨࡸࡩࡱࡶࠫ࠲࠯ࡅࠩ࠯ࡧࡱࡸࡷࡿࠧ໐"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items=re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡱࡪࡺࡡࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃ࡮ࡳࡡࡨࡧࠥ࠾ࢀࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡪࡸࡱࡧࠨ࠺ࡼࠤࡶࡶࡨࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ໑"),block,re.DOTALL)
			for l1llll1_l1_,title,l1l11lll1_l1_,l1l11l11l_l1_,l1l11l1l1_l1_ in items:
				l1l11l11l_l1_ = l1l11l11l_l1_.replace(l11l1l_l1_ (u"ࠧ࡝࠱ࠪ໒"),l11l1l_l1_ (u"ࠨ࠱ࠪ໓"))
				l1l11l1l1_l1_ = l1l11l1l1_l1_.replace(l11l1l_l1_ (u"ࠩ࡟࠳ࠬ໔"),l11l1l_l1_ (u"ࠪ࠳ࠬ໕"))
				l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠫࡡ࠵ࠧ໖"),l11l1l_l1_ (u"ࠬ࠵ࠧ໗"))
				title = escapeUNICODE(title)
				l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
				title = title.split(l11l1l_l1_ (u"࠭ࠠࠨ໘"))[-1]
				title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭໙") + name + l11l1l_l1_ (u"ࠨࠢ࠰ࠤࠬ໚") + title
				l1l11l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡯ࡩࡳ࡭ࡴࡩࡡࡩࡳࡷࡳࡡࡵࡶࡨࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ໛"),l1l11lll1_l1_,re.DOTALL)
				if l1l11l1ll_l1_: l1l11l1ll_l1_ = l1l11l1ll_l1_[0]
				else:  l1l11l1ll_l1_ = l11l1l_l1_ (u"ࠪࠫໜ")
				addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪໝ"),l1111l_l1_+title,l1llll1_l1_,43,l1l11l1l1_l1_,l1l11l1ll_l1_)
		else:
			items=re.findall(l11l1l_l1_ (u"ࠬ࡯ࡴࡦ࡯ࡳࡶࡴࡶ࠽ࠣࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡳࡳࡺࡥ࡯ࡶࡘࡶࡱࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠱࠮ࡄࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫໞ"),html,re.DOTALL)
			for title,l1llll1_l1_,l1ll1l_l1_ in items:
				l1ll1l_l1_ = l1ll1l_l1_.replace(l11l1l_l1_ (u"࠭࡜࠰ࠩໟ"),l11l1l_l1_ (u"ࠧ࠰ࠩ໠"))
				title = escapeUNICODE(title)
				l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ໡"),l1111l_l1_+title,l1llll1_l1_,43,l1ll1l_l1_)
			#l1l1l1111_l1_(url)
	else:
		l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠳ࡳࡦࡴ࡬ࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ໢"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ໣"),l11l1l_l1_ (u"ࠫࠬ໤"),url, block)
			items=re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ໥"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ໦"),l1111l_l1_+title,l1llll1_l1_,47)
	return
def PLAY(url):
	url = url.replace(l11l1l_l1_ (u"ࠧࠡࠩ໧"),l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬ໨"))
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ໩"))
	return
def l1l11l111_l1_(url):
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠪࠫ໪"),headers,l11l1l_l1_ (u"ࠫࠬ໫"),l11l1l_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡑࡎࡄ࡝ࡤࡔࡅࡘ࡙ࡈࡆࡘࡏࡔࡆ࠯࠴ࡷࡹ࠭໬"))
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࡘࡖࡑࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ໭"),html,re.DOTALL)
	PLAY(l1llll1_l1_[0])
	return
def CATEGORIES(url,category):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ໮"),l11l1l_l1_ (u"ࠨࠩ໯"),type, url)
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠩࠪ໰"),headers,l11l1l_l1_ (u"ࠪࠫ໱"),l11l1l_l1_ (u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠳ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕ࠰࠵ࡸࡺࠧ໲"))
	l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠬࡩࡡࡵ࠳࠱ࡥࡡ࠮࠰࠭ࠪ࠱࠮ࡄ࠯ࡤࡰࡥࡸࡱࡪࡴࡴ࠯ࡹࡵ࡭ࡹ࡫ࠧ໳"),html,re.DOTALL)
	block= l1l11l1_l1_[0]
	items=re.findall(l11l1l_l1_ (u"࠭ࡣࡢࡶ࠴࠲ࡦࡢࠨࠩ࠰࠭ࡃ࠮࠲ࠨ࠯ࠬࡂ࠭࠱ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠭࡞ࠪࡠࠬ࠲࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ໴"),block,re.DOTALL)
	l1l11ll1l_l1_=False
	l111l11_l1_ = [l11l1l_l1_ (u"ࠧ࠮࠵࠼࠽ࠬ໵"),l11l1l_l1_ (u"ࠨ࠷࠹࠸࠸࠭໶"),l11l1l_l1_ (u"ࠩ࠵࠷࠵࠼ࠧ໷"),l11l1l_l1_ (u"ࠪ࠹࠻࠻࠴ࠨ໸"),l11l1l_l1_ (u"ࠫ࠶࠶࠷࠲࠸ࠪ໹"),l11l1l_l1_ (u"ࠬ࠷࠰࠳࠹࠺ࠫ໺"),l11l1l_l1_ (u"࠭࠷࠺࠶࠹ࠫ໻")]
	for cat,parent,title,l1llll1_l1_ in items:
		if parent == category and cat not in l111l11_l1_:
			title = unescapeHTML(title)
			if l11l1l_l1_ (u"้ࠧไสฮࠥฮัศ็ฯࠫ໼") in title: continue
			if l11l1l_l1_ (u"ࠨࠪࠪ໽") in title:
				title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ໾") + title.replace(re.findall(l11l1l_l1_ (u"ࠪࠤࡡ࠮࠮ࠫࡁ࡟࠭ࠬ໿"),title)[0],l11l1l_l1_ (u"ࠫࠬༀ"))
			url = l11l11_l1_ + l11l1l_l1_ (u"ࠬ࠵ࠧ༁") + l1llll1_l1_
			if cat == l11l1l_l1_ (u"࠭࠭࠲࠸࠸ࠫ༂"): title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭༃") + l11l1l_l1_ (u"ࠨษ็ื๏ีࠠึสสัฺࠥศาࠢࠫ࠺࠵࠯ࠧ༄")
			if l11l1l_l1_ (u"ࠩ࠰ࠫ༅") in cat: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༆"),l1111l_l1_+title,url,44,l11l1l_l1_ (u"ࠫࠬ༇"),l11l1l_l1_ (u"ࠬ࠭༈"),cat)
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭༉"),l1111l_l1_+title,url,42)
			l1l11ll1l_l1_=True
	if not l1l11ll1l_l1_: l1lllll_l1_(url,l11l1l_l1_ (u"ࠧ࠴ࠩ༊"))
	return
def l1l1l111l_l1_():
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ་"),l11l1l_l1_ (u"ࠩࠪ༌"),type, url)
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠪࠫ།"),headers,l11l1l_l1_ (u"ࠫࠬ༎"),l11l1l_l1_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡑࡔࡒࡋࡗࡇࡍࡔ࠯࠴ࡷࡹ࠭༏"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡭ࡦࡩࡤ࠱ࡲ࡫࡮ࡶ࠯ࡥࡰࡴࡩ࡫ࠩ࠰࠭ࡃ࠮ࡳࡥࡨࡣ࠰ࡱࡪࡴࡵࠨ༐"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭༑"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ༒"),l1111l_l1_+title,l1llll1_l1_,44)
	return
def l1l1ll111_l1_():
	html = OPENURL_CACHED(l1llll11_l1_,l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ฬะ࠳ๅษษืีࠬ༓"),l11l1l_l1_ (u"ࠪࠫ༔"),l11l1l_l1_ (u"ࠫࠬ༕"),l11l1l_l1_ (u"ࠬ࠭༖"),l11l1l_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ༗"))
	items = re.findall(l11l1l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁ༘ࠬࠦࠬ"),html,re.DOTALL)
	url = l1llll_l1_(items[0])
	#DIALOG_OK(l11l1l_l1_ (u"ࠨ༙ࠩ"),l11l1l_l1_ (u"ࠩࠪ༚"),url,str(html))
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ༛"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ༜"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭༝"): return
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ༞"),l11l1l_l1_ (u"ࠧࠦ࠴࠳ࠫ༟"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭༠") +l11111l_l1_
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠩ࠶ࠫ༡"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪぃ")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡎࡖࡇࡥࠧい")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ぅ"):l11l1l_l1_ (u"ࠪࠫう")}
def MAIN(mode,url,text):
	if   mode==320: results = MENU()
	elif mode==321: results = l1lllll_l1_(url)
	elif mode==322: results = PLAY(url)
	elif mode==329: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫぇ"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬえ"),l11l1l_l1_ (u"࠭ࠧぉ"),329,l11l1l_l1_ (u"ࠧࠨお"),l11l1l_l1_ (u"ࠨࠩか"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭が"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨき"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫぎ"),l11l1l_l1_ (u"ࠬ࠭く"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪぐ"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫけ"),l11l1l_l1_ (u"ࠨࠩげ"),headers,l11l1l_l1_ (u"ࠩࠪこ"),l11l1l_l1_ (u"ࠪࠫご"),l11l1l_l1_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩさ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰࡲ࠱ࡵࡲࡵࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ざ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬし"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title==l11l1l_l1_ (u"ࠧศๆ่็ฯฮษࠡษ็้ึฬ๊สࠩじ"): continue
		l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨす"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫず")+l1111l_l1_+title,l1llll1_l1_,321)
	return html
def l1lllll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫせ"),l11l1l_l1_ (u"ࠫࠬぜ"),url,html)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩそ"),url,l11l1l_l1_ (u"࠭ࠧぞ"),headers,l11l1l_l1_ (u"ࠧࠨた"),l11l1l_l1_ (u"ࠨࠩだ"),l11l1l_l1_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩち"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫぢ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡰࡥ࠷ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧっ"),block,re.DOTALL)
	if not items: items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡱ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬつ"),block,re.DOTALL)
	for l1llll1_l1_,l1ll1l_l1_,count,title in items:
		count = count.replace(l11l1l_l1_ (u"ู࠭ะัࠣࠫづ"),l11l1l_l1_ (u"ࠧࠨて")).replace(l11l1l_l1_ (u"ࠨࠢࠪで"),l11l1l_l1_ (u"ࠩࠪと"))
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠪ࠳ࠬど"),l11l1l_l1_ (u"ࠫࠬな"))
		l1ll1l_l1_ = l1ll1l_l1_.replace(l11l1l_l1_ (u"ࠧ࠭ࠢに"),l11l1l_l1_ (u"࠭ࠧぬ"))
		if l11l1l_l1_ (u"ࠧ࠯ࡲ࡫ࡴࠬね") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵ࠮ࡱࡪࡳࠫの")+l1llll1_l1_
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫは")+l1llll1_l1_
		l1ll1l_l1_ = l11l11_l1_+l1ll1l_l1_
		title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬば"))
		title = title+l11l1l_l1_ (u"ࠫࠥ࠮ࠧぱ")+count+l11l1l_l1_ (u"ࠬ࠯ࠧひ")
		if l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩび") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧぴ"),l1111l_l1_+title,l1llll1_l1_,321,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨࡹࡤࡸࡨ࡮࠮ࡱࡪࡳࠫふ") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨぶ"),l1111l_l1_+title,l1llll1_l1_,322,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡵ࡯ࡵࡧࡵࠫぷ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪへ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩべ")+l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ぺ"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭ほ")+title,l1llll1_l1_,321)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬぼ"),url,l11l1l_l1_ (u"ࠩࠪぽ"),headers,l11l1l_l1_ (u"ࠪࠫま"),l11l1l_l1_ (u"ࠫࠬみ"),l11l1l_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪむ"))
	html = response.content
	#l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡢࡷࡧ࡭ࡴ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭め"),html,re.DOTALL)
	#if not l1llll1_l1_:
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡸ࡬ࡨࡪࡵ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧも"),html,re.DOTALL)
	l1llll1_l1_ = l11l11_l1_+l1llll1_l1_[0]#+l11l1l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧゃ")+l11llll11_l1_()+l11l1l_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡵࡴࡸࡩࠬや")
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩゅ"))
	return
def SEARCH(search):
	#search = l11l1l_l1_ (u"๊ࠫิสศำࠪゆ")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭ょ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧよ"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩら"),l11l1l_l1_ (u"ࠨ࠭ࠪり"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪる")+search
	l1lllll_l1_(url)
	return
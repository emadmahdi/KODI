# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ㾨")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡐ࠸࡚ࡥࠧ㾩")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠩส๊ํอูࠡษไ่ฬ๋ࠧ㾪"),l11l1l_l1_ (u"ࠪะํีวหࠢสๅ้อๅࠨ㾫")]
def MAIN(mode,url,text):
	if   mode==380: results = MENU()
	elif mode==381: results = l1lllll_l1_(url,text)
	elif mode==382: results = PLAY(url)
	elif mode==383: results = l1lll1l1_l1_(url)
	elif mode==389: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㾬"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ㾭"),l11l1l_l1_ (u"࠭ࠧ㾮"),389,l11l1l_l1_ (u"ࠧࠨ㾯"),l11l1l_l1_ (u"ࠨࠩ㾰"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㾱"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㾲"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㾳"),l11l1l_l1_ (u"ࠬ࠭㾴"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㾵"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㾶")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็้๊๐าสࠩ㾷"),l11l11_l1_,381,l11l1l_l1_ (u"ࠩࠪ㾸"),l11l1l_l1_ (u"ࠪࠫ㾹"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㾺"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㾻"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㾼")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯห๋ฮ๊สࠩ㾽"),l11l11_l1_,381,l11l1l_l1_ (u"ࠨࠩ㾾"),l11l1l_l1_ (u"ࠩࠪ㾿"),l11l1l_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ㿀"))
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ㿁"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭㿂"),l11l1l_l1_ (u"࠭ࠧ㿃"),l11l1l_l1_ (u"ࠧࠨ㿄"),l11l1l_l1_ (u"ࠨࠩ㿅"),l11l1l_l1_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ㿆"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂ࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㿇"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㿈"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㿉")+l1111l_l1_+title,l11l11_l1_,381,l11l1l_l1_ (u"࠭ࠧ㿊"),l11l1l_l1_ (u"ࠧࠨ㿋"),l11l1l_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࠨ㿌")+str(seq))
	block = l11l1l_l1_ (u"ࠩࠪ㿍")
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡨࡨࡴࡸࠢࠨ㿎"),html,re.DOTALL)
	if l1l11l1_l1_: block += l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶ࠭࠴ࠪࡀࠫࡤࡷ࡮ࡪࡥࠨ㿏"),html,re.DOTALL)
	if l1l11l1_l1_: block += l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㿐"),block,re.DOTALL)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㿑"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㿒"),l11l1l_l1_ (u"ࠨࠩ㿓"),9999)
	first = True
	for l1llll1_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11l1l_l1_ (u"ࠩส่ศ฿ไุ๊่ࠢฬํฯสࠩ㿔"):
			if first:
				title = l11l1l_l1_ (u"ࠪห้อแๅษ่ࠤࠬ㿕")+title
				first = False
			else: title = l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠࠨ㿖")+title
		if title not in l1l111_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿗"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㿘")+l1111l_l1_+title,l1llll1_l1_,381)
	return html
def l1lllll_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㿙"),l11l1l_l1_ (u"ࠨࠩ㿚"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭㿛"),url,l11l1l_l1_ (u"ࠪࠫ㿜"),l11l1l_l1_ (u"ࠫࠬ㿝"),l11l1l_l1_ (u"ࠬ࠭㿞"),l11l1l_l1_ (u"࠭ࠧ㿟"),l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ㿠"))
	html = response.content
	if type==l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ㿡"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡦࡸࡣࡩ࠯ࡳࡥ࡬࡫ࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡥࡧࡥࡥࡷ࠭㿢"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿣"),block,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠫࡸ࡯ࡤࡦࡴࠪ㿤"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡥࡩࡨࡸ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠩ㿥"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		z = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿦"),block,re.DOTALL)
		l1lll1_l1_,l11llllll_l1_,l1ll1ll1_l1_ = zip(*z)
		items = zip(l11llllll_l1_,l1lll1_l1_,l1ll1ll1_l1_)
	elif type==l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ㿧"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡹ࡬ࡪࡦࡨࡶ࠲ࡳ࡯ࡷ࡫ࡨࡷ࠲ࡺࡶࡴࡪࡲࡻࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࡮ࡥࡢࡦࡨࡶࡃ࠭㿨"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿩"),block,re.DOTALL)
	elif l11l1l_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ㿪") in type:
		seq = int(type[-1:])
		html = html.replace(l11l1l_l1_ (u"ࠫࡁ࡮ࡥࡢࡦࡨࡶࡃ࠭㿫"),l11l1l_l1_ (u"ࠬࡂࡥ࡯ࡦࡁࡀࡸࡺࡡࡳࡶࡁࠫ㿬"))
		html = html.replace(l11l1l_l1_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ㿭"),l11l1l_l1_ (u"ࠧ࠽ࡧࡱࡨࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠫ㿮"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡶࡸࡦࡸࡴ࠿ࠪ࠱࠮ࡄ࠯࠼ࡦࡰࡧࡂࠬ㿯"),html,re.DOTALL)
		block = l1l11l1_l1_[seq]
		if seq==2: items = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㿰"),block,re.DOTALL)
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࠫࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࡼࡴ࡫ࡧࡩࡧࡧࡲࠪࠩ㿱"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0][0]
			if l11l1l_l1_ (u"ࠫ࠴ࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯࠱ࠪ㿲") in url:
				items = re.findall(l11l1l_l1_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿳"),block,re.DOTALL)
			elif l11l1l_l1_ (u"࠭࠯ࡲࡷࡤࡰ࡮ࡺࡹ࠰ࠩ㿴") in url:
				items = re.findall(l11l1l_l1_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿵"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㿶"),block,re.DOTALL)
	l11l_l1_ = []
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠩࡶࡩࡷ࡯ࡥࠨ㿷") in title:
			title = re.findall(l11l1l_l1_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡳࡦࡴ࡬ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㿸"),title,re.DOTALL)
			title = title[0][1]#+l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨ㿹")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㿺")+title
		l1lll11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡞ࠩ࠰࠭ࡃ࠮ࡂࠧ㿻"),title,re.DOTALL)
		if l1lll11l1_l1_: title = l1lll11l1_l1_[0]
		title = unescapeHTML(title)
		if l11l1l_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ㿼") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㿽"),l1111l_l1_+title,l1llll1_l1_,383,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷ࠴࠭㿾") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㿿"),l1111l_l1_+title,l1llll1_l1_,383,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲࡸ࠵ࠧ䀀") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䀁"),l1111l_l1_+title,l1llll1_l1_,383,l1ll1l_l1_)
		elif l11l1l_l1_ (u"࠭࠯ࡤࡱ࡯ࡰࡪࡩࡴࡪࡱࡱ࠳ࠬ䀂") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䀃"),l1111l_l1_+title,l1llll1_l1_,381,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䀄"),l1111l_l1_+title,l1llll1_l1_,382,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨ࠮ࠫࡁࡓࡥ࡬࡫ࠠࠩ࠰࠭ࡃ࠮ࠦ࡯ࡧࠢࠫ࠲࠯ࡅࠩ࠽ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭䀅"),html,re.DOTALL)
	if l1l11l1_l1_:
		current = l1l11l1_l1_[0][0]
		last = l1l11l1_l1_[0][1]
		block = l1l11l1_l1_[0][2]
		items = re.findall(l11l1l_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧ䀆"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title==l11l1l_l1_ (u"ࠫࠬ䀇") or title==last: continue
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䀈"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ䀉")+title,l1llll1_l1_,381,l11l1l_l1_ (u"ࠧࠨ䀊"),l11l1l_l1_ (u"ࠨࠩ䀋"),type)
		#if title==last:
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩ䀌")+title+l11l1l_l1_ (u"ࠪ࠳ࠬ䀍"),l11l1l_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ䀎")+last+l11l1l_l1_ (u"ࠬ࠵ࠧ䀏"))
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䀐"),l1111l_l1_+l11l1l_l1_ (u"ࠧศะิࠤฺ็อสࠢࠪ䀑")+last,l1llll1_l1_,381,l11l1l_l1_ (u"ࠨࠩ䀒"),l11l1l_l1_ (u"ࠩࠪ䀓"),type)
	return
def l1lll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䀔"),url,l11l1l_l1_ (u"ࠫࠬ䀕"),l11l1l_l1_ (u"ࠬ࠭䀖"),l11l1l_l1_ (u"࠭ࠧ䀗"),l11l1l_l1_ (u"ࠧࠨ䀘"),l11l1l_l1_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ䀙"))
	html = response.content
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡆࠤࡷࡧࡴࡦࡦࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䀚"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_,False):
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䀛"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่๊ࠥไไสสีࠥ๎วๅ็หี๊าࠠๆ่฼๋ࠬ䀜"),l11l1l_l1_ (u"ࠬ࠭䀝"),9999)
		return
	if l11l1l_l1_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ䀞") in url or l11l1l_l1_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴ࠱ࠪ䀟") in url:
		l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠩࠪࡧࡱࡧࡳࡴ࠿ࠪ࡭ࡹ࡫࡭ࠨࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭䀠"),html,re.DOTALL)
		if l111l1l_l1_:
			l111l1l_l1_ = l111l1l_l1_[1]
			l1lll1l1_l1_(l111l1l_l1_)
			return
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠪࠫࡨࡲࡡࡴࡵࡀࠫࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠧࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡥࡸࡺࠢࠨࠩࠪ䀡"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࠫࠬࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠬࡴࡵ࡮ࡧࡵࡥࡳࡪ࡯ࠨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠫࠬ䀢"),block,re.DOTALL)
		for l1ll1l_l1_,l1ll11l_l1_,l1llll1_l1_,name in items:
			title = l1ll11l_l1_+l11l1l_l1_ (u"ࠫࠥࡀࠠࠨ䀣")+name+l11l1l_l1_ (u"ࠬࠦวๅฯ็ๆฮ࠭䀤")
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䀥"),l1111l_l1_+title,l1llll1_l1_,382)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䀦"),url,l11l1l_l1_ (u"ࠨࠩ䀧"),l11l1l_l1_ (u"ࠩࠪ䀨"),l11l1l_l1_ (u"ࠪࠫ䀩"),l11l1l_l1_ (u"ࠫࠬ䀪"),l11l1l_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䀫"))
	html = response.content
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䀬"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	l1lll1_l1_ = []
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠢࠣࠤ࡬ࡨࡂ࠭ࡰ࡭ࡣࡼࡩࡷ࠳࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠨࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂ࠮ࠢࡴࡪࡨࡥࡩ࡫ࡲࠣࡾࠪࡴࡦ࡭࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩࠬࠦࠧࠨ䀭"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0][0]
		items = re.findall(l11l1l_l1_ (u"ࠣࡦࡤࡸࡦ࠳ࡵࡳ࡮ࡀࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂ࠭ࡳࡦࡴࡹࡩࡷ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ䀮"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ䀯")+title+l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ䀰")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷ࡫࡭ࡰࡦࡤࡰࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡶࡪࡳ࡯ࡥࡣ࡯࠱ࡨࡲ࡯ࡴࡧࠥࠫ䀱"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡥ࡟ࡠࡦ࡯ࡣ࡬ࡪࡲࡪࡸࡨ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䀲"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ䀳")+title+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ䀴")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭䀵"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䀶"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠪࠫ䀷"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠫࠬ䀸"): return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ䀹"),l11l1l_l1_ (u"࠭ࠫࠨ䀺"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡁࡶࡁࠬ䀻")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨ䀼"))
	return
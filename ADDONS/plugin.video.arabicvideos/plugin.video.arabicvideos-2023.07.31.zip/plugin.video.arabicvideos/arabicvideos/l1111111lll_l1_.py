# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ尵")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ尶")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
#headers = l11l1l_l1_ (u"ࠪࠫ尷")
#headers = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ尸"):l11l1l_l1_ (u"ࠬ࠭尹")}
l11l11lll111_l1_ = 0
def MAIN(mode,url,text,type,l11lll1_l1_,name,l111_l1_):
	if	 mode==140: results = MENU()
	elif mode==141: results = l11l11ll1l1l_l1_(url,name,l111_l1_)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = l1lllll_l1_(url,l11lll1_l1_,text)
	elif mode==145: results = l11l1ll11111_l1_(url,l11lll1_l1_)
	elif mode==147: results = l11l1l11ll11_l1_()
	elif mode==148: results = l11l1l11lll1_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	if 0:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭尺"),l1111l_l1_+l11l1l_l1_ (u"ࠧใษษ้ฮ࠭尻"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡆࡰ࠵ࡈࡵ࠻ࡊࡍ࠾࡚࡯ࡗࡥࡊ࠵ࡘࡖ࠮࠹ࡊ࠷ࡇࡵࡱࡊࡻ࡝ࡅ࠹ࡻࡓࡂࠩ尼"),144)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ尽"),l1111l_l1_+l11l1l_l1_ (u"ุࠪำ฻ࠧ尾"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࡘࡈࡔ࡯ࡧࡨ࡬ࡧ࡮ࡧ࡬ࠨ尿"),144)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ局"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅ้ไ฼ࠫ屁"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࡘࡇࡶ࠻࠹ࡢࡉࡑࡷࡶ࠿ࡢࡣࡪࡺ࡚࡙ࡷ࠱ࡖࡶࡹ࡫ࡼ࠭层"),144)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屃"),l1111l_l1_+l11l1l_l1_ (u"ࠩะืฬฮࠧ屄"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡅ࡚ࡨࡦࡕࡲࡧ࡮ࡧ࡬ࡄࡖ࡙ࠫ居"),144)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屆"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไฺษหࠫ屇"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡨࡣࡰ࡭ࡳ࡭ࠧ屈"),144)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ屉"),l1111l_l1_+l11l1l_l1_ (u"ࠨษไ่ฬ๋ࠧ届"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡵࡷࡳࡷ࡫ࡦࡳࡱࡱࡸࠬ屋"),144)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屌"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫิสศำสฮࠬ屍"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ屎"),144)
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屏"),l1111l_l1_+l11l1l_l1_ (u"ࠧใืํีฮ࠭屐"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ屑"),144,l11l1l_l1_ (u"ࠩࠪ屒"),l11l1l_l1_ (u"ࠪࠫ屓"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ屔"))
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ展"),l1111l_l1_+l11l1l_l1_ (u"࠭สึใะࠫ屖"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ屗"),144)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屘"),l1111l_l1_+l11l1l_l1_ (u"ࠩิส๏ู๊สࠩ屙"),l11l11_l1_+l11l1l_l1_ (u"ࠪࠫ屚"),144)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屛"),l1111l_l1_+l11l1l_l1_ (u"ࠬืววฮࠪ屜"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭࠿ࡣࡲࡀࠫ屝"),144)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ属"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ屟"),l11l1l_l1_ (u"ࠩࠪ屠"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屡"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ屢"),l11l1l_l1_ (u"ࠬ࠭屣"),149,l11l1l_l1_ (u"࠭ࠧ層"),l11l1l_l1_ (u"ࠧࠨ履"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ屦"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ屧"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้ืฦ๋ีํอࠬ屨"),l11l11_l1_+l11l1l_l1_ (u"ࠫࠬ屩"),144)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屪"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅำสสัฯࠧ屫"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ屬"),144)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ屭"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ฯ฻แฮࠩ屮"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭屯"),144)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ屰"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไใืํีฮ࠭山"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ屲"),144,l11l1l_l1_ (u"ࠧࠨ屳"),l11l1l_l1_ (u"ࠨࠩ屴"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭屵"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ屶"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫิสศำสฮࠥ๐่ห์๋ฬࠬ屷"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ屸"),144)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭屹"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆะอหึอสࠡษ็ฬึ์วๆฮࠪ屺"),l11l1l_l1_ (u"ࠨࠩ屻"),290)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ屼"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ屽"),l11l1l_l1_ (u"ࠫࠬ屾"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ屿"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ岀"),l11l1l_l1_ (u"ࠧࠨ岁"),147)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岂"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࡀࠠใ่๋หฯࠦรอ่ห๎ฮ࠭岃"),l11l1l_l1_ (u"ࠪࠫ岄"),148)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岅"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬ࠼ࠣหๆ๊วๆࠢ฼ีอ๐ษࠨ岆"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽โ์็้ࠬ岇"),144)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ岈"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥอฬ็สํอࠬ岉"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡱࡴࡼࡩࡦࠩ岊"),144)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ岋"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำห࠻่ࠢืึำ๊ศฬࠣ฽ึฮ๊สࠩ岌"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃๅิำะ๎ฮ࠭岍"),144)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭岎"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮ࠾๋ࠥำๅี็หฯูࠦาสํอࠬ岏"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืู้ไࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭岐"),144)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ岑"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢสะ๋ฮ๊สࠩ岒"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂࡹࡥࡳ࡫ࡨࡷࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷ࠾࠿ࠪ岓"),144)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ岔"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ岕"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭岖"),144)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ岗"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࡀࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ岘"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ็์วส࠭ๆีอ๊วย࠭ส่ๆ฼วว์ฬ࠯ำ฽ศส࠭ส่ัู๋สࠨࡶࡴࡂࡉࡁࡊࡕࡄ࡬ࡆࡈࠧ岙"),144)
	return
def l11l11ll1l1l_l1_(url,name,l111_l1_):
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ岚"),l1111l_l1_+l11l1l_l1_ (u"ࠬࡉࡈࡏࡎ࠽ࠤࠥ࠭岛")+name,url,144,l111_l1_)
	return
def l11l1l11ll11_l1_():
	l1lllll_l1_(l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭岜"))
	return
def l11l1l11lll1_l1_():
	l1lllll_l1_(l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡶࡹࠪࡸࡶ࠽ࡆࡩࡍࡅࡆࡗ࠽࠾ࠩ岝"))
	return
def PLAY(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ岞"),l11l1l_l1_ (u"ࠩࠪ岟"),l11l1l_l1_ (u"ࠪࠫ岠"),url)
	#url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡩ࡫ࡏ࠼ࡉ࡬࠴ࡶ࠷࠼࡬࠭岡")
	#items = re.findall(l11l1l_l1_ (u"ࠬࡼ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧ岢"),url,re.DOTALL)
	#id = items[0]
	#l1llll1_l1_ = l11l1l_l1_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ岣")+id
	#PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭岤"))
	#return
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎ࡯࡭ࡱࡱࡵࡸࠥࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠋࠋࡸࡶࡱࠦ࠽ࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࡧࡩࡍ࠺ࡇࡱ࠹ࡴ࠵࠺ࡪࠫࠏࠏࡥࡳࡴࡲࡶࡸ࠲ࡴࡪࡶ࡯ࡩࡸ࠲࡬ࡪࡰ࡮ࡷࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠱ࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠪࡸࡶࡱ࠯ࠊࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࠭࠮࠯࠰࠱ࠫࠡࠢࠪ࠯ࡸࡺࡲࠩ࡮࡬ࡲࡰࡹࠩࠪࠌࠌࡩࡷࡸ࡯ࡳࡵ࠯ࡸ࡮ࡺ࡬ࡦࡵ࠯ࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠮ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠮ࡵࡳ࡮ࠬࠎࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࠪ࠰ࠬ࠱ࠫࠬ࠭࠮࠯ࠥࠦࠧࠬࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡶ࠭࠮ࠐࠉࡑࡎࡄ࡝ࡤ࡜ࡉࡅࡇࡒࠬࡱ࡯࡮࡬ࡵ࡞࠴ࡢ࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠰ࡹࡿࡰࡦࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࠨࠢࠣ岥")
	url = url.split(l11l1l_l1_ (u"ࠩࠩࠫ岦"),1)[0]
	import ll_l1_
	ll_l1_.l11_l1_([url],l1ll1_l1_,type,url)
	return
def l11l1l111l11_l1_(cc,url,index):
	level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = index.split(l11l1l_l1_ (u"ࠪ࠾࠿࠭岧"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ岨"),l11l1l_l1_ (u"ࠬ࠭岩"),index,l11l1l_l1_ (u"࠭ࡆࡊࡔࡖࡘࠬ岪")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ岫")+url)
	l11l11ll11l1_l1_,l11l11ll1l11_l1_ = [],[]
	# l1lllll11lll_l1_ l1lllll11l1l_l1_    should be the first item in the l11l11ll11l1_l1_ list
	if l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ岬") in url: l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡦࡧࡠ࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫࡢࠨ岭"))
	# l1lllll11lll_l1_ search l11l1l1l111l_l1_      should be the first item in the l11l11ll11l1_l1_ list
	if l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡶࡩࡦࡸࡣࡩࠩ岮") in url: l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡨࡩ࡛ࠨࡱࡱࡖࡪࡹࡰࡰࡰࡶࡩࡗ࡫ࡣࡦ࡫ࡹࡩࡩࡉ࡯࡮࡯ࡤࡲࡩࡹࠧ࡞ࠤ岯"))
	# main l11lll1_l1_
	if level==l11l1l_l1_ (u"ࠬ࠷ࠧ岰"): l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ岱"))
	# search results
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡘ࡫ࡡࡳࡥ࡫ࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠧ岲"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡥࡦ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡥࡧࡹࠧ࡞ࠤ岳"))
	# l11l1l1l1111_l1_ l11l1l11l1ll_l1_ & main l11lll1_l1_ l11l1l11l1ll_l1_ l11l1l1l111l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡦࡧࡠ࠭ࡥ࡯ࡶࡵ࡭ࡪࡹࠧ࡞ࠤ岴"))
	# l11l1l111l1l_l1_ menu
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡧࡨࡡࠧࡪࡶࡨࡱࡸ࠭࡝࡜࠵ࡠ࡟ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ岵"))
	l11l1l1l11l1_l1_,dd,l11l11l1ll11_l1_ = l11l11ll1111_l1_(cc,l11l1l_l1_ (u"ࠫࠬ岶"),l11l11ll11l1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭岷"),str(dd))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ岸"),l11l1l_l1_ (u"ࠧࠨ岹"),l11l1l_l1_ (u"ࠨࠩ岺"),str(len(dd)))
	if level==l11l1l_l1_ (u"ࠩ࠴ࠫ岻") and l11l1l1l11l1_l1_:
		if len(dd)>1 and l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺࠩ岼") not in url:
			for zz in range(len(dd)):
				l11l11llll1l_l1_ = str(zz)
				l11l11ll11l1_l1_ = []
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡩࡪ࡛ࠣ岽")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠧࡣ࡛ࠨࡴࡨࡰࡴࡧࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡇࡴࡳ࡭ࡢࡰࡧࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ岾"))
				# l11l1l1l1111_l1_ l11l1l11l1ll_l1_
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡤࡥ࡝ࠥ岿")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠢ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࠫࡢࠨ峀"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡦࡧ࡟ࠧ峁")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠤࡠࠦ峂"))
				succeeded,item,l111l111_l1_ = l11l11ll1111_l1_(dd,l11l1l_l1_ (u"ࠪࠫ峃"),l11l11ll11l1_l1_)
				if succeeded: l11l11ll1l11_l1_.append([item,url,l11l1l_l1_ (u"ࠫ࠷ࡀ࠺ࠨ峄")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠬࡀ࠺࠱࠼࠽࠴ࠬ峅")])
				#l11l11ll1ll1_l1_ = l11l1l1ll1ll_l1_(item,url,l11l1l_l1_ (u"࠭࠲࠻࠼ࠪ峆")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠧ࠻࠼࠳࠾࠿࠶ࠧ峇"))
				#if l11l11ll1ll1_l1_: l1ll111l11_l1_ += 1
				#succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,token = l11l1ll11l11_l1_(item)
				#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ峈"),l1111l_l1_+title,l1llll1_l1_,144,l11l1l_l1_ (u"ࠩࠪ峉"),l11l1l_l1_ (u"ࠪ࠶࠿ࡀࠧ峊")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀ࠰࠻࠼࠳ࠫ峋"))
				#l1ll111l11_l1_ += 1
			# main l11lll1_l1_ l11l1l11l1ll_l1_ l11l1l1l111l_l1_
			l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠࠦ峌"))
			succeeded,item,l111l111_l1_ = l11l11ll1111_l1_(cc,l11l1l_l1_ (u"࠭ࠧ峍"),l11l11ll11l1_l1_)
			#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ峎"),str(cc))
			if succeeded and l11l11ll1l11_l1_ and l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰ࡯ࡰࡥࡳࡪࠧ峏") in list(item.keys()):
				l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ峐")
				l11l11ll1l11_l1_.append([item,l1llll1_l1_,l11l1l_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ峑")])
	return dd,l11l1l1l11l1_l1_,l11l11ll1l11_l1_,l11l11l1ll11_l1_
def l11l11l1ll1l_l1_(cc,dd,url,index):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ峒"),l11l1l_l1_ (u"ࠬ࠭峓"),index,l11l1l_l1_ (u"࠭ࡓࡆࡅࡒࡒࡉ࠭峔")+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ峕")+url)
	level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = index.split(l11l1l_l1_ (u"ࠨ࠼࠽ࠫ峖"))
	l11l11ll11l1_l1_,l11l1l111ll1_l1_ = [],[]
	# search results
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峗"))
	# main l11lll1_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡨࡩࡡࠢ峘")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡳࡧ࡯ࡳࡦࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࠪࡡࠧ峙"))
	# l111ll11ll1_l1_ l11l1l11l1ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡪࡤ࡜࠳ࡠ࡟ࠬࡸࡥ࡭ࡱࡤࡨࡈࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࡄࡱࡰࡱࡦࡴࡤࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡳࠨ࡟ࠥ峚"))
	# l1lllll11lll_l1_ search & l1lllll11l1l_l1_ & l11l1l1l111l_l1_
	if l11l1l_l1_ (u"࠭࠯ࡺࡱࡸࡸࡺࡨࡥࡪ࠱ࡹ࠵࠴ࡨࡲࡰࡹࡶࡩࠬ峛") in url: l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡥࡦ࡞࠴ࡢࡡࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡍࡹ࡫࡭ࡴࠩࡠࠦ峜"))
	elif l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮ࠧ峝") in url: l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡧࡨࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峞"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡨࡩࡡࠢ峟")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ峠"))
	# l111ll11ll1_l1_ l11l1lll11_l1_ & l11l1l11l1ll_l1_ filters
	if l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭峡") in url or (l11l1l_l1_ (u"࠭࠯ࡴࡪࡲࡶࡹࡹࠧ峢") in url and l11l1l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ峣") not in url):
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡦࡧ࡟ࠧ峤")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠤࡠ࡟ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡈࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠ࡟ࠬ࡬ࡥࡦࡦࡉ࡭ࡱࡺࡥࡳࡅ࡫࡭ࡵࡈࡡࡳࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ峥"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡨࡩࡡࠢ峦")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡸࡩࡤࡪࡊࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ峧"))
	# l11l1l1l1111_l1_ search
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡪࡤ࡜ࠤ峨")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠨ࡝࡜ࠩࡨࡼࡵࡧ࡮ࡥࡣࡥࡰࡪ࡚ࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ峩"))
	# main l11lll1_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡥࡦ࡞ࠦ峪")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡔࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ峫"))
	# l1lllll11lll_l1_ l1lllll11l1l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡧࡨࡠࠨ峬")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠥࡡࠧ峭"))
	l11l1l11llll_l1_,ee,l11l1l1111l1_l1_ = l11l11ll1111_l1_(dd,l11l1l_l1_ (u"ࠫࠬ峮"),l11l11ll11l1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭峯"),str(ee))
	#DIALOG_OK()
	if level==l11l1l_l1_ (u"࠭࠲ࠨ峰") and l11l1l11llll_l1_:
		if len(ee)>1:
			#DIALOG_OK()
			for zz in range(len(ee)):
				index2 = str(zz)
				l11l11ll11l1_l1_ = []
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡦࡧ࡞ࠦ峱")+index2+l11l1l_l1_ (u"ࠣ࡟࡞ࠫࡷ࡯ࡣࡩࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ峲"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡨࡩࡠࠨ峳")+index2+l11l1l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ峴"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ峵")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ島"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦ࡝ࠥ峷")+index2+l11l1l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࠧ峸"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡧࡨ࡟ࠧ峹")+index2+l11l1l_l1_ (u"ࠤࡠ࡟ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ峺"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡩࡪࡡࠢ峻")+index2+l11l1l_l1_ (u"ࠦࡢࠨ峼"))
				succeeded,item,l111l111_l1_ = l11l11ll1111_l1_(ee,l11l1l_l1_ (u"ࠬ࠭峽"),l11l11ll11l1_l1_)
				if succeeded: l11l1l111ll1_l1_.append([item,url,l11l1l_l1_ (u"࠭࠳࠻࠼ࠪ峾")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ峿")+index2+l11l1l_l1_ (u"ࠨ࠼࠽࠴ࠬ崀")])
				#l11l11ll1ll1_l1_ = l11l1l1ll1ll_l1_(item,url,l11l1l_l1_ (u"ࠩ࠶࠾࠿࠭崁")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠪ࠾࠿࠭崂")+index2+l11l1l_l1_ (u"ࠫ࠿ࡀ࠰ࠨ崃"))
				#if l11l11ll1ll1_l1_: l1l11lll11_l1_ += 1
				#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭崄"),str(l111l111_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ崅")+str(item))
				#l1l11lll11_l1_ += 1
				#item = ee[zz]
				#succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,token = l11l1ll11l11_l1_(item)
				#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ崆"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,l11l1l_l1_ (u"ࠨ࠵࠽࠾ࠬ崇")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ崈")+index2+l11l1l_l1_ (u"ࠪ࠾࠿࠶ࠧ崉"))
			# search l11l1l1l111l_l1_
			l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡩࡪ࡛࠱࡟࡞ࠫࡦࡶࡰࡦࡰࡧࡇࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡹࡁࡤࡶ࡬ࡳࡳ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭࡝࡜࠳ࡠࠦ崊"))
			# search l11l1l1l111l_l1_
			l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡪࡤ࡜࠳ࡠࠦ崋"))
			succeeded,item,l111l111_l1_ = l11l11ll1111_l1_(dd,l11l1l_l1_ (u"࠭ࠧ崌"),l11l11ll11l1_l1_)
			if succeeded and l11l1l111ll1_l1_ and l11l1l_l1_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡕࡩࡳࡪࡥࡳࡧࡵࠫ崍") in list(item.keys()):
				l11l1l111ll1_l1_.append([item,url,l11l1l_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ崎")])
			#l11l11ll1ll1_l1_ = l11l1l1ll1ll_l1_(item,url,l11l1l_l1_ (u"ࠩ࠶࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭崏"))
			#if l11l11ll1ll1_l1_: l1l11lll11_l1_ += 1
			#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ崐"),str(item))
			#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ崑"),l1llll1_l1_+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ崒")+token)
	return ee,l11l1l11llll_l1_,l11l1l111ll1_l1_,l11l1l1111l1_l1_
def l11l11ll1lll_l1_(cc,ee,url,index):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ崓"),l11l1l_l1_ (u"ࠧࠨ崔"),index,l11l1l_l1_ (u"ࠨࡖࡋࡍࡗࡊࠧ崕")+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ崖")+url)
	level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = index.split(l11l1l_l1_ (u"ࠪ࠾࠿࠭崗"))
	l11l11ll11l1_l1_,l11l11lll1l1_l1_ = [],[]
	# search results
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ崘")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崙"))
	# l1lllll11lll_l1_ l1lllll11l1l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦ࡝ࠥ崚")+index2+l11l1l_l1_ (u"ࠢ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ崛"))
	# l11l1l1ll1l1_l1_ menu l11l1l11l1ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡧࡨ࡟ࠧ崜")+index2+l11l1l_l1_ (u"ࠤࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡴࡨࡩࡱ࡙ࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ崝"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡩࡪࡡࠢ崞")+index2+l11l1l_l1_ (u"ࠦࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崟"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡫ࡥ࡜ࠤ崠")+index2+l11l1l_l1_ (u"ࠨ࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ崡"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡦࡧ࡞ࠦ崢")+index2+l11l1l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崣"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡨࡩࡠࠨ崤")+index2+l11l1l_l1_ (u"ࠥࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ崥"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ崦")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡬ࡸࡩࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崧"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦ࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ崨"))
	# l11l1l1l1111_l1_ l11l1ll11l1l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡦࡧ࡞࠴ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡫ࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡴࡦ࡯ࡶࠫࡢࠨ崩"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡧࡨ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡜ࡩࡥࡧࡲࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ崪"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡨࡩࡠࠨ崫")+index2+l11l1l_l1_ (u"ࠥࡡࡠ࠭ࡲࡦࡧ࡯ࡗ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ崬"))
	# main l11lll1_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡪ࡫࡛ࠣ崭")+index2+l11l1l_l1_ (u"ࠧࡣ࡛ࠨࡴ࡬ࡧ࡭࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ崮"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡥࡦࠤ崯"))
	l11l1l1l1l11_l1_,ff,l11l1ll111l1_l1_ = l11l11ll1111_l1_(ee,l11l1l_l1_ (u"ࠧࠨ崰"),l11l11ll11l1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ崱"),str(ff))
	if level==l11l1l_l1_ (u"ࠩ࠶ࠫ崲") and l11l1l1l1l11_l1_:
		if len(ff)>0:
			for zz in range(len(ff)):
				l11l1l11l1l1_l1_ = str(zz)
				#DIALOG_OK()
				l11l11ll11l1_l1_ = []
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡪ࡫ࡡࠢ崳")+l11l1l11l1l1_l1_+l11l1l_l1_ (u"ࠦࡢࡡࠧࡳ࡫ࡦ࡬ࡎࡺࡥ࡮ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࠧ࡞ࠤ崴"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡬ࡦ࡜ࠤ崵")+l11l1l11l1l1_l1_+l11l1l_l1_ (u"ࠨ࡝࡜ࠩࡪࡥࡲ࡫ࡃࡢࡴࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡩࡤࡱࡪ࠭࡝ࠣ崶"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠦ崷")+l11l1l11l1l1_l1_+l11l1l_l1_ (u"ࠣ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ崸"))
				l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࡠࠨ崹")+l11l1l11l1l1_l1_+l11l1l_l1_ (u"ࠥࡡࠧ崺"))
				succeeded,item,l111l111_l1_ = l11l11ll1111_l1_(ff,l11l1l_l1_ (u"ࠫࠬ崻"),l11l11ll11l1_l1_)
				#succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,token = l11l1ll11l11_l1_(item)
				#addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ崼"),l1111l_l1_+l1llll1_l1_,l1llll1_l1_,143,l1ll1l_l1_)
				if succeeded: l11l11lll1l1_l1_.append([item,url,l11l1l_l1_ (u"࠭࠴࠻࠼ࠪ崽")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ崾")+index2+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ崿")+l11l1l11l1l1_l1_])
				#l11l11ll1ll1_l1_ = l11l1l1ll1ll_l1_(item,url,l11l1l_l1_ (u"ࠩ࠷࠾࠿࠭嵀")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠪ࠾࠿࠭嵁")+index2+l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嵂")+l11l1l11l1l1_l1_)
				#if l11l11ll1ll1_l1_: l1l11lll1l_l1_ += 1
	return ff,l11l1l1l1l11_l1_,l11l11lll1l1_l1_,l11l1ll111l1_l1_
def l11l11ll1111_l1_(l111lll1ll1_l1_,l11l11111ll_l1_,l11l11llll11_l1_):
	cc,l11l11111ll_l1_ = l111lll1ll1_l1_,l11l11111ll_l1_
	dd,l11l11111ll_l1_ = l111lll1ll1_l1_,l11l11111ll_l1_
	ee,l11l11111ll_l1_ = l111lll1ll1_l1_,l11l11111ll_l1_
	ff,l11l11111ll_l1_ = l111lll1ll1_l1_,l11l11111ll_l1_
	item,render = l111lll1ll1_l1_,l11l11111ll_l1_
	count = len(l11l11llll11_l1_)
	for l11l1l1ll1_l1_ in range(count):
		try:
			out = eval(l11l11llll11_l1_[l11l1l1ll1_l1_])
			#if isinstance(out,dict): out = l11l1l_l1_ (u"ࠬ࠭嵃")
			return True,out,l11l1l1ll1_l1_+1
		except: pass
	return False,l11l1l_l1_ (u"࠭ࠧ嵄"),0
def l1lllll_l1_(url,index=l11l1l_l1_ (u"ࠧࠨ嵅"),data=l11l1l_l1_ (u"ࠨࠩ嵆")):
	l11l11ll1l11_l1_,l11l1l111ll1_l1_,l11l11lll1l1_l1_ = [],[],[]
	if l11l1l_l1_ (u"ࠩ࠽࠾ࠬ嵇") not in index: index = l11l1l_l1_ (u"ࠪ࠵࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ嵈")
	level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = index.split(l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嵉"))
	if level==l11l1l_l1_ (u"ࠬ࠺ࠧ嵊"): level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ嵋"),l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ嵌"),l11l1l_l1_ (u"ࠨࠩ嵍"),index,url)
	data = data.replace(l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭嵎"),l11l1l_l1_ (u"ࠪࠫ嵏"))
	html,cc,l11l1llll_l1_ = l11l1l111lll_l1_(url,data)
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊ࡫ࡩࠤࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨࠢ࡬ࡲࠥࡻࡲ࡭ࠢࡲࡶࠥ࠭࠯ࡶࡵࡨࡶ࠴࠭ࠠࡪࡰࠣࡹࡷࡲ࠺ࠋࠋࠌࠧࡴࡽ࡮ࡦࡴࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡴࡽ࡮ࡦࡴࡑࡥࡲ࡫ࠢ࠯ࠬࡂࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠣࡪࡨࠣࡲࡴࡺࠠࡰࡹࡱࡩࡷࡀࠠࠋࠋࠌࡳࡼࡴࡥࡳࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࡑࡪࡺࡡࡥࡣࡷࡥࡗ࡫࡮ࡥࡧࡵࡩࡷࠨ࠺࡝ࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡰࡹࡱࡩࡷ࡛ࡲ࡭ࡵࠥ࠾ࡡࡡࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠩࡩࡧࠢࡱࡳࡹࠦ࡯ࡸࡰࡨࡶ࠿ࠦ࡯ࡸࡰࡨࡶࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࠨࡶࡪࡦࡨࡳࡔࡽ࡮ࡦࡴࠥ࠲࠯ࡅࠢࡵࡧࡻࡸࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡪࡨࠣࡳࡼࡴࡥࡳ࠼ࠍࠍࠎࠏ࡯ࡸࡰࡨࡶࡓࡇࡍࡆࠢࡀࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡴࡽ࡮ࡦࡴ࡞࠴ࡢࡡ࠰࡞ࠫࠍࠍࠎࠏ࡯ࡸࡰࡨࡶࡓࡇࡍࡆࠢࡀࠤࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ࠭ࡲࡻࡳ࡫ࡲࡏࡃࡐࡉ࠰࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡵࡷ࡯ࡧࡵ࡟࠵ࡣ࡛࠲࡟ࠍࠍࠎࠏࡩࡧࠢࠪ࡬ࡹࡺࡰࠨࠢࡱࡳࡹࠦࡩ࡯ࠢ࡯࡭ࡳࡱ࠺ࠡ࡮࡬ࡲࡰࠦ࠽ࠡࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯ࡱ࡯࡮࡬ࠌࠌࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡱࡺࡲࡪࡸࡎࡂࡏࡈ࠰ࡱ࡯࡮࡬࠮࠴࠸࠹࠯ࠊࠊࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩ࡯࡭ࡳࡱࠧ࠭ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯ࠫࠬ࠲࠹࠺࠻࠼࠭ࠏࠏࠢࠣࠤ嵐")
	index = level+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嵑")+l11l11llll1l_l1_+l11l1l_l1_ (u"࠭࠺࠻ࠩ嵒")+index2+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ嵓")+l11l1l11l1l1_l1_
	if level in [l11l1l_l1_ (u"ࠨ࠳ࠪ嵔"),l11l1l_l1_ (u"ࠩ࠵ࠫ嵕"),l11l1l_l1_ (u"ࠪ࠷ࠬ嵖")]:
		dd,l11l1l1l11l1_l1_,l11l11ll1l11_l1_,l11l11l1ll11_l1_ = l11l1l111l11_l1_(cc,url,index)
		if not l11l1l1l11l1_l1_: return
		l1ll111l11_l1_ = len(l11l11ll1l11_l1_)
		if l1ll111l11_l1_<2:
			if level==l11l1l_l1_ (u"ࠫ࠶࠭嵗"): level = l11l1l_l1_ (u"ࠬ࠸ࠧ嵘")
			l11l11ll1l11_l1_ = []
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ嵙"),l11l1l_l1_ (u"ࠧࠨ嵚"),index,l11l1l_l1_ (u"ࠨ࡮ࡨࡺࡪࡲ࠺ࠡ࠳࡟ࡲࠬ嵛")+l11l1l_l1_ (u"ࠩࡶࡩࡶࡻࡥ࡯ࡥࡨ࠾ࠥ࠭嵜")+str(l11l11l1ll11_l1_)+l11l1l_l1_ (u"ࠪࡠࡳ࠭嵝")+l11l1l_l1_ (u"ࠫࡱ࡫࡮ࡨࡶ࡫࠾ࠥ࠭嵞")+str(len(dd))+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ嵟")+l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸ࠿ࠦࠧ嵠")+str(l1ll111l11_l1_)+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ嵡")+url)
	index = level+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ嵢")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ嵣")+index2+l11l1l_l1_ (u"ࠪ࠾࠿࠭嵤")+l11l1l11l1l1_l1_
	if level in [l11l1l_l1_ (u"ࠫ࠷࠭嵥"),l11l1l_l1_ (u"ࠬ࠹ࠧ嵦")]:
		ee,l11l1l11llll_l1_,l11l1l111ll1_l1_,l11l1l1111l1_l1_ = l11l11l1ll1l_l1_(cc,dd,url,index)
		if not l11l1l11llll_l1_: return
		l1l11lll11_l1_ = len(l11l1l111ll1_l1_)
		if l1l11lll11_l1_<2:
			if level==l11l1l_l1_ (u"࠭࠲ࠨ嵧"): level = l11l1l_l1_ (u"ࠧ࠴ࠩ嵨")
			l11l1l111ll1_l1_ = []
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ嵩"),l11l1l_l1_ (u"ࠩࠪ嵪"),index,l11l1l_l1_ (u"ࠪࡰࡪࡼࡥ࡭࠼ࠣ࠶ࡡࡴࠧ嵫")+l11l1l_l1_ (u"ࠫࡸ࡫ࡱࡶࡧࡱࡧࡪࡀࠠࠨ嵬")+str(l11l1l1111l1_l1_)+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ嵭")+l11l1l_l1_ (u"࠭࡬ࡦࡰࡪࡸ࡭ࡀࠠࠨ嵮")+str(len(ee))+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ嵯")+l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺ࠺ࠡࠩ嵰")+str(l1l11lll11_l1_)+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ嵱")+url)
	index = level+l11l1l_l1_ (u"ࠪ࠾࠿࠭嵲")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嵳")+index2+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嵴")+l11l1l11l1l1_l1_
	if level in [l11l1l_l1_ (u"࠭࠳ࠨ嵵")]:
		ff,l11l1l1l1l11_l1_,l11l11lll1l1_l1_,l11l1ll111l1_l1_ = l11l11ll1lll_l1_(cc,ee,url,index)
		if not l11l1l1l1l11_l1_: return
		l1l11lll1l_l1_ = len(l11l11lll1l1_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ嵶"),l11l1l_l1_ (u"ࠨࠩ嵷"),index,l11l1l_l1_ (u"ࠩ࡯ࡩࡻ࡫࡬࠻ࠢ࠶ࡠࡳ࠭嵸")+l11l1l_l1_ (u"ࠪࡷࡪࡷࡵࡦࡰࡦࡩ࠿ࠦࠧ嵹")+str(l11l1ll111l1_l1_)+l11l1l_l1_ (u"ࠫࡡࡴࠧ嵺")+l11l1l_l1_ (u"ࠬࡲࡥ࡯ࡩࡷ࡬࠿ࠦࠧ嵻")+str(len(ff))+l11l1l_l1_ (u"࠭࡜࡯ࠩ嵼")+l11l1l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡀࠠࠨ嵽")+str(l1l11lll1l_l1_)+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ嵾")+url)
	for item,url,index in l11l11ll1l11_l1_+l11l1l111ll1_l1_+l11l11lll1l1_l1_:
		l11l11ll1ll1_l1_ = l11l1l1ll1ll_l1_(item,url,index)
	return
def l11l1l1ll1ll_l1_(item,url=l11l1l_l1_ (u"ࠩࠪ嵿"),index=l11l1l_l1_ (u"ࠪࠫ嶀")):
	if l11l1l_l1_ (u"ࠫ࠿ࡀࠧ嶁") in index: level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = index.split(l11l1l_l1_ (u"ࠬࡀ࠺ࠨ嶂"))
	else: level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ嶃"),l11l1l_l1_ (u"ࠧ࠱ࠩ嶄"),l11l1l_l1_ (u"ࠨ࠲ࠪ嶅"),l11l1l_l1_ (u"ࠩ࠳ࠫ嶆")
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,l11l1l1llll1_l1_ = l11l1ll11l11_l1_(item)
	#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ嶇"),url)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ嶈"),l1llll1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭嶉"),l1llll1_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ嶊")+title)
	# needed for l11l1l1l1111_l1_ l11l1ll11l1l_l1_ next l11lll1_l1_
	# and needed for l11l1l1l1111_l1_ l11l1ll11l1l_l1_ sub-menu
	#if (l11l1l_l1_ (u"ࠧࡷ࡫ࡨࡻࡂ࠻࠰ࠨ嶋") in l1llll1_l1_ or l11l1l_l1_ (u"ࠨࡸ࡬ࡩࡼࡃ࠴࠺ࠩ嶌") in l1llll1_l1_) and (l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸࡅࠧ嶍") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸࡅࠧ嶎") in l1llll1_l1_): l1llll1_l1_ = url
	l1l1111l1ll_l1_ = l11l1l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࡄ࠭嶏") in l1llll1_l1_ or l11l1l_l1_ (u"ࠬ࠵ࡳࡵࡴࡨࡥࡲࡹ࠿ࠨ嶐") in l1llll1_l1_ or l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࡂࠫ嶑") in l1llll1_l1_
	l11ll1ll1ll_l1_ = l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࡂࠫ嶒") in l1llll1_l1_ or l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࡁࠪ嶓") in l1llll1_l1_
	if l1l1111l1ll_l1_ or l11ll1ll1ll_l1_: l1llll1_l1_ = url
	l1l1111l1ll_l1_ = l11l1l_l1_ (u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫ嶔") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡅ࡬ࡪࡵࡷࡁࠬ嶕") not in l1llll1_l1_
	l11ll1ll1ll_l1_ = l11l1l_l1_ (u"ࠫ࠴࡭ࡡ࡮࡫ࡱ࡫ࠬ嶖") not in l1llll1_l1_  and l11l1l_l1_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳ࡸࡺ࡯ࡳࡧࡩࡶࡴࡴࡴࠨ嶗") not in l1llll1_l1_
	if index[0:5]==l11l1l_l1_ (u"࠭࠳࠻࠼࠳࠾࠿࠭嶘") and l1l1111l1ll_l1_ and l11ll1ll1ll_l1_: l1llll1_l1_ = url
	if l11l1l_l1_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡧࡶ࡫ࡧࡩࡄࡱࡥࡺ࠿ࠪ嶙") in url or l11l1l_l1_ (u"ࠨ࠱ࡪࡥࡲ࡯࡮ࡨࠩ嶚") in l1llll1_l1_:
		level,l11l11llll1l_l1_,index2,l11l1l11l1l1_l1_ = l11l1l_l1_ (u"ࠩ࠴ࠫ嶛"),l11l1l_l1_ (u"ࠪ࠴ࠬ嶜"),l11l1l_l1_ (u"ࠫ࠵࠭嶝"),l11l1l_l1_ (u"ࠬ࠶ࠧ嶞")
		index = l11l1l_l1_ (u"࠭ࠧ嶟")
	l11l1llll_l1_ = l11l1l_l1_ (u"ࠧࠨ嶠")
	if l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫ࠧ嶡") in l1llll1_l1_ or l11l1l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡵࡨࡥࡷࡩࡨࠨ嶢") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡲࡿ࡟࡮ࡣ࡬ࡲࡤࡶࡡࡨࡧࡢࡷ࡭ࡵࡲࡵࡵࡢࡰ࡮ࡴ࡫ࠨ嶣") in url:
		data = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭嶤"))
		if data.count(l11l1l_l1_ (u"ࠬࡀ࠺࠻ࠩ嶥"))==4:
			l11l1l1l11ll_l1_,key,l11l1l11ll1l_l1_,l11l11llllll_l1_,token = data.split(l11l1l_l1_ (u"࠭࠺࠻࠼ࠪ嶦"))
			l11l1llll_l1_ = l11l1l1l11ll_l1_+l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ嶧")+key+l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ嶨")+l11l1l11ll1l_l1_+l11l1l_l1_ (u"ࠩ࠽࠾࠿࠭嶩")+l11l11llllll_l1_+l11l1l_l1_ (u"ࠪ࠾࠿ࡀࠧ嶪")+l11l1l1llll1_l1_
			if l11l1l_l1_ (u"ࠫ࠴ࡳࡹࡠ࡯ࡤ࡭ࡳࡥࡰࡢࡩࡨࡣࡸ࡮࡯ࡳࡶࡶࡣࡱ࡯࡮࡬ࠩ嶫") in url and not l1llll1_l1_: l1llll1_l1_ = url
			else: l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡫ࡦࡻࡀࠫ嶬")+key
	if not title:
		global l11l11lll111_l1_
		l11l11lll111_l1_ += 1
		title = l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡࠩ嶭")+str(l11l11lll111_l1_)
		index = l11l1l_l1_ (u"ࠧ࠴ࠩ嶮")+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ嶯")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ嶰")+index2+l11l1l_l1_ (u"ࠪ࠾࠿࠭嶱")+l11l1l11l1l1_l1_
	#if l11l1l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ嶲") in url: l1llll1_l1_ = url
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭嶳"),l11l1l_l1_ (u"࠭ࠧ嶴"),title,index+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ嶵")+l1llll1_l1_)
	#if not l1llll1_l1_: l1llll1_l1_ = url
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ嶶"),l11l1l_l1_ (u"ࠩࠪ嶷"),str(succeeded),title+l11l1l_l1_ (u"ࠪࠤ࠿ࡀ࠺ࠡࠩ嶸")+l1llll1_l1_)
	#if l11l1l_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ嶹") in url and index==l11l1l_l1_ (u"ࠬ࠶ࠧ嶺"):
	#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嶻"),l1111l_l1_+title,url,144)
	#	return True
	#if not title: return False
	if not succeeded: return False
	elif l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡐࡺࡸࡕࡩࡳࡪࡥࡳࡧࡵࠫ嶼") in str(item): return False			# l11l1l1ll11l_l1_ not items
	elif l11l1l_l1_ (u"ࠨ࠱ࡤࡦࡴࡻࡴࠨ嶽") in l1llll1_l1_: return False
	elif l11l1l_l1_ (u"ࠩ࠲ࡧࡴࡳ࡭ࡶࡰ࡬ࡸࡾ࠭嶾") in l1llll1_l1_: return False
	elif l11l1l_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ嶿") in list(item.keys()) or l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪ巀") in list(item.keys()):
		if int(level)>1: level = str(int(level)-1)
		index = level+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ巁")+l11l11llll1l_l1_+l11l1l_l1_ (u"࠭࠺࠻ࠩ巂")+index2+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ巃")+l11l1l11l1l1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ巄"),l1111l_l1_+l11l1l_l1_ (u"ࠩ࠽࠾ࠥ࠭巅")+l11l1l_l1_ (u"ูࠪๆำษࠡลัี๎࠭巆"),l1llll1_l1_,144,l1ll1l_l1_,index,l11l1llll_l1_)
	elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ巇") in l1llll1_l1_:
		title = l11l1l_l1_ (u"ࠬࡀ࠺ࠡࠩ巈")+title
		index = l11l1l_l1_ (u"࠭࠳ࠨ巉")+l11l1l_l1_ (u"ࠧ࠻࠼ࠪ巊")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠨ࠼࠽ࠫ巋")+index2+l11l1l_l1_ (u"ࠩ࠽࠾ࠬ巌")+l11l1l11l1l1_l1_
		url = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ巍"),l11l1l_l1_ (u"ࠫࠬ巎"))
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ巏"),l1111l_l1_+title,url,145,l11l1l_l1_ (u"࠭ࠧ巐"),index,l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ巑"))
	elif l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ巒") in url and not l1llll1_l1_:
		index = l11l1l_l1_ (u"ࠩ࠶ࠫ巓")+l11l1l_l1_ (u"ࠪ࠾࠿࠭巔")+l11l11llll1l_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀࠧ巕")+index2+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ巖")+l11l1l11l1l1_l1_
		title = l11l1l_l1_ (u"࠭࠺࠻ࠢࠪ巗")+title
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ巘"),l1111l_l1_+title,url,144,l1ll1l_l1_,index,l11l1llll_l1_)
	#elif l11l1l_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬࡟ࡪࡦࡀࠫ巙") in l1llll1_l1_: return False
	elif l11l1l_l1_ (u"ࠩ࠲ࡦࡷࡵࡷࡴࡧࠪ巚") in l1llll1_l1_ and url==l11l11_l1_:
		title = l11l1l_l1_ (u"ࠪ࠾࠿ࠦࠧ巛")+title
		index = l11l1l_l1_ (u"ࠫ࠷ࡀ࠺࠱࠼࠽࠴࠿ࡀ࠰ࠨ巜")
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ川"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index,l11l1llll_l1_)
	elif not l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡐࡳࡻ࡯ࡥࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭州") in str(item):
		title = l11l1l_l1_ (u"ࠧ࠻࠼ࠣࠫ巟")+title
		index = l11l1l_l1_ (u"ࠨ࠵࠽࠾࠵ࡀ࠺࠱࠼࠽࠴ࠬ巠")
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ巡"),l1111l_l1_+title,url,144,l1ll1l_l1_,index)
	elif l11l1l_l1_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࡖࡪࡴࡤࡦࡴࡨࡶࠬ巢") in str(item):
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ巣"),l1111l_l1_+title,l11l1l_l1_ (u"ࠬ࠭巤"),9999)
	#elif l11l1l_l1_ (u"࠭࠯ࡧࡧࡨࡨ࠴ࡺࡲࡦࡰࡧ࡭ࡳ࡭ࠧ工") in l1llll1_l1_ and l11l1l_l1_ (u"ࠧࡣࡲࡀࠫ左") not in l1llll1_l1_:
	#	title = l11l1l_l1_ (u"ࠨ࠼࠽ࠤࠬ巧")+title
	#	index = l11l1l_l1_ (u"ࠩ࠵࠾࠿࠶࠺࠻࠲࠽࠾࠵࠭巨")
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ巩"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif l1lllll111ll_l1_:
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ巪"),l1111l_l1_+l1lllll111ll_l1_+title,l1llll1_l1_,143,l1ll1l_l1_)
	elif l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ巫") in l1llll1_l1_:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭巬"),l1111l_l1_+l11l1l_l1_ (u"ࠧࡍࡋࡖࡘࠬ巭")+count+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ差")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	#elif l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ巯") in l1llll1_l1_ and l11l1l_l1_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ巰") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠫࡹࡃ࠰ࠨ己") not in l1llll1_l1_:
	#	l11l1l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࡀࠬ࠳࠰࠿ࠪࠦࠪ已"),l1llll1_l1_,re.DOTALL)
	#	l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡁ࡯࡭ࡸࡺ࠽ࠨ巳")+l11l1l11l11l_l1_[0]
	#	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ巴"),l1111l_l1_+l11l1l_l1_ (u"ࠨࡎࡌࡗ࡙࠭巵")+count+l11l1l_l1_ (u"ࠩ࠽ࠤࠥ࠭巶")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif l11l1l_l1_ (u"ࠪ࠳ࡸ࡮࡯ࡳࡶࡶ࠳ࠬ巷") in l1llll1_l1_:
		l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠫࠫࡲࡩࡴࡶࡀࠫ巸"),1)[0]
		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ巹"),l1111l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_,l1l11l1ll_l1_)
	elif l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ巺") in l1llll1_l1_:
		if l11l1l_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ巻") in l1llll1_l1_ and count:
			l11l1l11l11l_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ巼"),1)[1]
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ巽")+l11l1l11l11l_l1_
			index = l11l1l_l1_ (u"ࠪ࠷࠿ࡀ࠰࠻࠼࠳࠾࠿࠶ࠧ巾")
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ巿"),l1111l_l1_+l11l1l_l1_ (u"ࠬࡒࡉࡔࡖࠪ帀")+count+l11l1l_l1_ (u"࠭࠺ࠡࠢࠪ币")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
		else:
			l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ市"),1)[0]
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ布"),l1111l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_,l1l11l1ll_l1_)
	elif l11l1l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ帄") in l1llll1_l1_ or l11l1l_l1_ (u"ࠪ࠳ࡨ࠵ࠧ帅") in l1llll1_l1_ or (l11l1l_l1_ (u"ࠫ࠴ࡆࠧ帆") in l1llll1_l1_ and l1llll1_l1_.count(l11l1l_l1_ (u"ࠬ࠵ࠧ帇"))==3):
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭师"),l1111l_l1_+l11l1l_l1_ (u"ࠧࡄࡊࡑࡐࠬ帉")+count+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ帊")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif l11l1l_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ帋") in l1llll1_l1_:
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ希"),l1111l_l1_+l11l1l_l1_ (u"࡚࡙ࠫࡅࡓࠩ帍")+count+l11l1l_l1_ (u"ࠬࡀࠠࠡࠩ帎")+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	else:
		if not l1llll1_l1_: l1llll1_l1_ = url
		title = l11l1l_l1_ (u"࠭࠺࠻ࠢࠪ帏")+title
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ帐"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index,l11l1llll_l1_)
	return True
def l11l1ll11l11_l1_(item):
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,token = False,l11l1l_l1_ (u"ࠨࠩ帑"),l11l1l_l1_ (u"ࠩࠪ帒"),l11l1l_l1_ (u"ࠪࠫ帓"),l11l1l_l1_ (u"ࠫࠬ帔"),l11l1l_l1_ (u"ࠬ࠭帕"),l11l1l_l1_ (u"࠭ࠧ帖"),l11l1l_l1_ (u"ࠧࠨ帗"),l11l1l_l1_ (u"ࠨࠩ帘")
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ帙"),str(item))
	if not isinstance(item,dict): return succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,token
	for l11l1l1l1lll_l1_ in list(item.keys()):
		render = item[l11l1l1l1lll_l1_]
		if isinstance(render,dict): break
	#WRITE_THIS(l11l1l_l1_ (u"ࠪࠫ帚"),str(render))
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ帛"),str(render))
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡌࡪࡵࡷࡌࡪࡧࡤࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝࡜ࠩࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹ࠭࡝ࠣ帜"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡩࡧࡤࡨࡪࡸࠧ࡞࡝ࠪࡶ࡮ࡩࡨࡍ࡫ࡶࡸࡍ࡫ࡡࡥࡧࡵࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ帝"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡪࡨࡥࡩࡲࡩ࡯ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ帞"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡸࡲࡵࡲࡡࡺࡣࡥࡰࡪ࡚ࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ帟"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡪࡴࡸ࡭ࡢࡶࡷࡩࡩ࡚ࡩࡵ࡮ࡨࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ帠"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ帡"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ帢"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫࡢࠨ帣"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡧࡻࡸࠬࡣ࡛ࠨࡴࡸࡲࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࠧ帤"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞ࠤ帥"))
	# required for l111ll11ll1_l1_ l11l1l1111ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣ࡫ࡷࡩࡲࡡࠧࡵ࡫ࡷࡰࡪ࠭࡝ࠣ带"))
	# l11l1l1l1111_l1_ l11l1l11l1ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤ࡬ࡸࡪࡳ࡛ࠨࡴࡨࡩࡱ࡝ࡡࡵࡥ࡫ࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡸ࡬ࡨࡪࡵࡉࡥࠩࡠࠦ帧"))
	succeeded,title,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ帨"),l11l1l_l1_ (u"ࠫࠬ帩"),l11l1l_l1_ (u"ࠬ࠭帪"),str(l111l111_l1_))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ師"),str(l111l111_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ帬")+str(title))
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ席"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ帮"))
	# l11l1l1l111l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡡࡱ࡫ࡘࡶࡱ࠭࡝ࠣ帯"))
	# header feed
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪࡡࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡧࡰࡪࡗࡵࡰࠬࡣࠢ帰"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡥ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡹࡷࡲࠧ࡞ࠤ帱"))
	# required for l111ll11ll1_l1_ l11l11lll1ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡩࡵࡧࡰ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ帲"))
	# l11l1l1l1111_l1_ l11l1l11l1ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡪࡶࡨࡱࡠ࠭ࡣࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡻࡲ࡭ࠩࡠࠦ帳"))
	succeeded,l1llll1_l1_,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ帴"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ帵"))
	# l11l1l1l1111_l1_ l11l1l11l1ll_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡵࡩࡪࡲࡗࡢࡶࡦ࡬ࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠬࡣ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ帶"))
	succeeded,l1ll1l_l1_,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ帷"),str(l111l111_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ常")+l1ll1l_l1_)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡷ࡫ࡧࡩࡴࡉ࡯ࡶࡰࡷࠫࡢࠨ帹"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡸ࡬ࡨࡪࡵࡃࡰࡷࡱࡸ࡙࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ帺"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡐࡸࡨࡶࡱࡧࡹࡃࡱࡷࡸࡴࡳࡐࡢࡰࡨࡰࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ帻"))
	succeeded,count,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡖ࡬ࡱࡪ࡙ࡴࡢࡶࡸࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡷࡩࡽࡺࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡧࡻࡸࠬࡣࠢ帼"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡗ࡭ࡲ࡫ࡓࡵࡣࡷࡹࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ帽"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ帾"))
	# l11l1l1l1ll1_l1_ l11l1l1l1111_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡯ࡣࡰࡰࠪࡡࡠ࠭ࡩࡤࡱࡱࡘࡾࡶࡥࠨ࡟ࠥ帿"))
	# l11l1l1l1ll1_l1_ l11l1l1l1111_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡵࡻ࡯ࡩࠬࡣࠢ幀"))
	succeeded,l1l11l1ll_l1_,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	#l11l11ll11l1_l1_ = []
	# l11l1l1l111l_l1_
	#l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡲࡩࡤ࡭ࡗࡶࡦࡩ࡫ࡪࡰࡪࡔࡦࡸࡡ࡮ࡵࠪࡡࠧ幁"))
	# l1lllll11lll_l1_ l1lllll11l1l_l1_
	#l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡸࡷࡧࡣ࡬࡫ࡱ࡫ࡕࡧࡲࡢ࡯ࡶࠫࡢࠨ幂"))
	#succeeded,l11l11lll11l_l1_,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	l11l11ll11l1_l1_ = []
	# l1lllll11lll_l1_ l1lllll11l1l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴࡅ࡯ࡦࡳࡳ࡮ࡴࡴࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡆࡳࡲࡳࡡ࡯ࡦࠪࡡࡠ࠭ࡴࡰ࡭ࡨࡲࠬࡣࠢ幃"))
	# l11l1l1l111l_l1_
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡮࡯ࡤࡲࡩ࠭࡝࡜ࠩࡷࡳࡰ࡫࡮ࠨ࡟ࠥ幄"))
	succeeded,token,l111l111_l1_ = l11l11ll1111_l1_(item,render,l11l11ll11l1_l1_)
	if l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࠩ幅") in l1l11l1ll_l1_: l1l11l1ll_l1_,l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠬ࠭幆"),l11l1l_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ幇")
	if l11l1l_l1_ (u"ࠧๆสสุึ࠭幈") in l1l11l1ll_l1_: l1l11l1ll_l1_,l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠨࠩ幉"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ幊")
	if l11l1l_l1_ (u"ࠪࡦࡦࡪࡧࡦࡵࠪ幋") in list(render.keys()):
		l11l1l1lll11_l1_ = str(render[l11l1l_l1_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ幌")])
		if l11l1l_l1_ (u"ࠬࡌࡲࡦࡧࠣࡻ࡮ࡺࡨࠡࡃࡧࡷࠬ幍") in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"࠭ࠤ࠻ࠢࠣࠫ幎")
		if l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ幏") in l11l1l1lll11_l1_: l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡀࠠࠡࠩ幐")
		if l11l1l_l1_ (u"ࠩࡅࡹࡾ࠭幑") in l11l1l1lll11_l1_ or l11l1l_l1_ (u"ࠪࡖࡪࡴࡴࠨ幒") in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠫࠩࠪ࠺ࠡࠢࠪ幓")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡺ࠭ๅษษืีࠬ幔")) in l11l1l1lll11_l1_: l1lllll111ll_l1_ = l11l1l_l1_ (u"࠭ࡌࡊࡘࡈ࠾ࠥࠦࠧ幕")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡵࠨึิหฦ࠭幖")) in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠨࠦࠧ࠾ࠥࠦࠧ幗")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡷࠪหุะฦอษิࠫ幘")) in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠪࠨࠩࡀࠠࠡࠩ幙")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡹࠬหูๅษ้หฯ࠭幚")) in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠬࠪ࠺ࠡࠢࠪ幛")
	l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
	if l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ幜") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l11l1l_l1_ (u"ࠧࡀࠩ幝"))[0]
	if  l1ll1l_l1_ and l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭幞") not in l1ll1l_l1_: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ幟")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1l11l111_l1_: title = l11l1l11l111_l1_+title
	#title = unescapeHTML(title)
	l1l11l1ll_l1_ = l1l11l1ll_l1_.replace(l11l1l_l1_ (u"ࠪ࠰ࠬ幠"),l11l1l_l1_ (u"ࠫࠬ幡"))
	count = count.replace(l11l1l_l1_ (u"ࠬ࠲ࠧ幢"),l11l1l_l1_ (u"࠭ࠧ幣"))
	count = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࠮ࠫ幤"),count)
	if count: count = count[0]
	else: count = l11l1l_l1_ (u"ࠨࠩ幥")
	return True,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_,token
def l11l1l111lll_l1_(url,data=l11l1l_l1_ (u"ࠩࠪ幦"),request=l11l1l_l1_ (u"ࠪࠫ幧")):
	if request==l11l1l_l1_ (u"ࠫࠬ幨"): request = l11l1l_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠬ幩")
	#if l11l1l_l1_ (u"࠭࡟ࡠࠩ幪") in l11l1ll111ll_l1_: l11l1ll111ll_l1_ = l11l1l_l1_ (u"ࠧࠨ幫")
	#if l11l1l_l1_ (u"ࠨࡵࡶࡁࠬ幬") in url: url = url.split(l11l1l_l1_ (u"ࠩࡶࡷࡂ࠭幭"))[0]
	l111ll111l_l1_ = l11llll11_l1_()
	#l111ll111l_l1_ = l11l1l_l1_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠲࠲࠼࠲࠵࠴࠰࠯࠲ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠣࡉࡩ࡭࠯࠲࠲࠼࠲࠵࠴࠱࠶࠳࠻࠲࠼࠶ࠧ幮")
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ幯"):l111ll111l_l1_,l11l1l_l1_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ幰"):l11l1l_l1_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ幱")}
	#l1l1l1ll1_l1_ = headers.copy()
	global settings
	if not data: data = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡧࡴࡢࠩ干"))
	if data.count(l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ平"))==4: l11l1l1l11ll_l1_,key,l11l1l11ll1l_l1_,l11l11llllll_l1_,token = data.split(l11l1l_l1_ (u"ࠩ࠽࠾࠿࠭年"))
	else: l11l1l1l11ll_l1_,key,l11l1l11ll1l_l1_,l11l11llllll_l1_,token = l11l1l_l1_ (u"ࠪࠫ幵"),l11l1l_l1_ (u"ࠫࠬ并"),l11l1l_l1_ (u"ࠬ࠭幷"),l11l1l_l1_ (u"࠭ࠧ幸"),l11l1l_l1_ (u"ࠧࠨ幹")
	l11l1llll_l1_ = {l11l1l_l1_ (u"ࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ幺"):{l11l1l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ幻"):{l11l1l_l1_ (u"ࠥ࡬ࡱࠨ幼"):l11l1l_l1_ (u"ࠦࡦࡸࠢ幽"),l11l1l_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ幾"):l11l1l_l1_ (u"ࠨࡗࡆࡄࠥ广"),l11l1l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ庀"):l11l1l11ll1l_l1_}}}
	if url==l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡸࡴࡴࠩ庁") or l11l1l_l1_ (u"ࠩ࠲ࡱࡾࡥ࡭ࡢ࡫ࡱࡣࡵࡧࡧࡦࡡࡶ࡬ࡴࡸࡴࡴࡡ࡯࡭ࡳࡱࠧ庂") in url:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡵࡩࡪࡲ࠯ࡳࡧࡨࡰࡤࡽࡡࡵࡥ࡫ࡣࡸ࡫ࡱࡶࡧࡱࡧࡪ࠭広")+l11l1l_l1_ (u"ࠫࡄࡱࡥࡺ࠿ࠪ庄")+key
		l11l1llll_l1_[l11l1l_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫ࡐࡢࡴࡤࡱࡸ࠭庅")] = l11l1l1l11ll_l1_
		l11l1llll_l1_ = str(l11l1llll_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ庆"),url,l11l1llll_l1_,l1l1l1ll1_l1_,True,True,l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠳ࡶࡸࠬ庇"))
	elif l11l1l_l1_ (u"ࠨ࠱ࡪࡹ࡮ࡪࡥࡀ࡭ࡨࡽࡂ࠭庈") in url:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ庉")+key
		l11l1llll_l1_ = str(l11l1llll_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ床"),url,l11l1llll_l1_,l1l1l1ll1_l1_,True,True,l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠹ࡲࡥࠩ庋"))
	elif l11l1l_l1_ (u"ࠬࡱࡥࡺ࠿ࠪ庌") in url and l11l1l1l11ll_l1_:
		l11l1llll_l1_[l11l1l_l1_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ庍")] = token
		l11l1llll_l1_[l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ庎")][l11l1l_l1_ (u"ࠨࡥ࡯࡭ࡪࡴࡴࠨ序")][l11l1l_l1_ (u"ࠩࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠧ庐")] = l11l1l1l11ll_l1_
		l11l1llll_l1_ = str(l11l1llll_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ庑"),url,l11l1llll_l1_,l1l1l1ll1_l1_,True,True,l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠲࠺ࡴࡩࠩ庒"))
	elif l11l1l_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭库") in url and l11l11llllll_l1_:
		l1l1l1ll1_l1_.update({l11l1l_l1_ (u"࠭ࡘ࠮࡛ࡲࡹ࡙ࡻࡢࡦ࠯ࡆࡰ࡮࡫࡮ࡵ࠯ࡑࡥࡲ࡫ࠧ应"):l11l1l_l1_ (u"ࠧ࠲ࠩ底"),l11l1l_l1_ (u"ࠨ࡚࠰࡝ࡴࡻࡔࡶࡤࡨ࠱ࡈࡲࡩࡦࡰࡷ࠱࡛࡫ࡲࡴ࡫ࡲࡲࠬ庖"):l11l1l11ll1l_l1_})
		l1l1l1ll1_l1_.update({l11l1l_l1_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ店"):l11l1l_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅ࠾ࠩ庘")+l11l11llllll_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ庙"),url,l11l1l_l1_ (u"ࠬ࠭庚"),l1l1l1ll1_l1_,l11l1l_l1_ (u"࠭ࠧ庛"),l11l1l_l1_ (u"ࠧࠨ府"),l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡊࡉ࡙ࡥࡐࡂࡉࡈࡣࡉࡇࡔࡂ࠯࠸ࡸ࡭࠭庝"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭庞"),url,l11l1l_l1_ (u"ࠪࠫ废"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠫࠬ庠"),l11l1l_l1_ (u"ࠬ࠭庡"),l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡈࡇࡗࡣࡕࡇࡇࡆࡡࡇࡅ࡙ࡇ࠭࠷ࡶ࡫ࠫ庢"))
	html = response.content
	tmp = re.findall(l11l1l_l1_ (u"ࠧࠣ࡫ࡱࡲࡪࡸࡴࡶࡤࡨࡅࡵ࡯ࡋࡦࡻࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ庣"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡺࡪࡸࠢ࠯ࠬࡂࠦࡻࡧ࡬ࡶࡧࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ庤"),html,re.DOTALL|re.I)
	if tmp: l11l1l11ll1l_l1_ = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠩࠥࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠣ࠰࠭ࡃࠧ࠮࠮ࠫࡁࠬࠦࠬ庥"),html,re.DOTALL|re.I)
	if tmp: l11l1l1l11ll_l1_ = tmp[0]
	#tmp = re.findall(l11l1l_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ度"),html,re.DOTALL|re.I)
	#if tmp: token = tmp[0]
	#tmp = re.findall(l11l1l_l1_ (u"ࠫࠧࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ座"),html,re.DOTALL|re.I)
	#if not tmp: tmp = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡈࡵ࡭࡮ࡣࡱࡨࠧࡀࡻࠣࡶࡲ࡯ࡪࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ庨"),html,re.DOTALL|re.I)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ庩"),l11l1l_l1_ (u"ࠧࠨ庪"),l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ庫"),str(len(tmp)))
	#if tmp: l11l1l1l111l_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11l1l_l1_ (u"࡙ࠩࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧ庬") in list(cookies.keys()): l11l11llllll_l1_ = cookies[l11l1l_l1_ (u"࡚ࠪࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ庭")]
	l11ll1111_l1_ = l11l1l1l11ll_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ庮")+key+l11l1l_l1_ (u"ࠬࡀ࠺࠻ࠩ庯")+l11l1l11ll1l_l1_+l11l1l_l1_ (u"࠭࠺࠻࠼ࠪ庰")+l11l11llllll_l1_+l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ庱")+token
	if request==l11l1l_l1_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ庲") and l11l1l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ庳") in html:
		l111l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹ࡟࡟ࠧࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡅࡣࡷࡥࠧࡢ࡝ࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ庴"),html,re.DOTALL)
		if not l111l1ll1l_l1_: l111l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡻࡧࡲࠡࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ庵"),html,re.DOTALL)
		l11l11ll11ll_l1_ = EVAL(l11l1l_l1_ (u"ࠬࡹࡴࡳࠩ庶"),l111l1ll1l_l1_[0])
	elif request==l11l1l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡉࡸ࡭ࡩ࡫ࡄࡢࡶࡤࠫ康") and l11l1l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡊࡹ࡮ࡪࡥࡅࡣࡷࡥࠬ庸") in html:
		l111l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡸࡤࡶࠥࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠣࡁࠥ࠮ࡻ࠯ࠬࡂࢁ࠮ࡁࠧ庹"),html,re.DOTALL)
		l11l11ll11ll_l1_ = EVAL(l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭庺"),l111l1ll1l_l1_[0])
	elif l11l1l_l1_ (u"ࠪࡀ࠴ࡹࡣࡳ࡫ࡳࡸࡃ࠭庻") not in html: l11l11ll11ll_l1_ = EVAL(l11l1l_l1_ (u"ࠫࡸࡺࡲࠨ庼"),html)
	else: l11l11ll11ll_l1_ = l11l1l_l1_ (u"ࠬ࠭庽")
	if 0:
		cc = str(l11l11ll11ll_l1_)
		if kodi_version>18.99: cc = cc.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ庾"))
		open(l11l1l_l1_ (u"ࠧࡔ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩ࠴ࡤࡢࡶࠪ庿"),l11l1l_l1_ (u"ࠨࡹࡥࠫ廀")).write(cc)
		#open(l11l1l_l1_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯ࡪࡷࡱࡱ࠭廁"),l11l1l_l1_ (u"ࠪࡻࠬ廂")).write(html)
	settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭廃"),l11ll1111_l1_)
	return html,l11l11ll11ll_l1_,l11ll1111_l1_
def l11l1ll11111_l1_(url,index):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ廄"),l11l1l_l1_ (u"࠭ࠫࠨ廅"))
	l111l1l_l1_ = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ廆")+search
	l1lllll_l1_(l111l1l_l1_,index)
	return
def SEARCH(search):
	#search = l11l1l_l1_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭廇")+l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤࡥࠧ廈")+l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭廉")+l11l1l_l1_ (u"ࠫࡤ࠭廊")+search
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭廋"),l11l1l_l1_ (u"࠭ࠧ廌"),l11l1l_l1_ (u"ࠧࠨ廍"),search)
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ廎"),l11l1l_l1_ (u"ࠩࠪ廏"),search,options)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬ廐"),l11l1l_l1_ (u"ࠫ࠰࠭廑"))
	l111l1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃࠧ廒")+search
	if not l1ll_l1_:
		if l11l1l_l1_ (u"࠭࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩ廓") in options: l11l1l11111l_l1_ = l11l1l_l1_ (u"ࠧࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡔࠩ࠷࠻࠳ࡅࠧ࠵࠹࠸ࡊࠧ廔")
		elif l11l1l_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘࡥࠧ廕") in options: l11l1l11111l_l1_ = l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡼࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ廖")
		elif l11l1l_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙࡟ࠨ廗") in options: l11l1l11111l_l1_ = l11l1l_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡧࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ廘")
		else: l11l1l11111l_l1_ = l11l1l_l1_ (u"ࠬ࠭廙")
		l111ll1_l1_ = l111l1l_l1_+l11l1l11111l_l1_
	else:
		l11l1l111111_l1_,l11l11l1llll_l1_,l1lll11l1_l1_ = [],[],l11l1l_l1_ (u"࠭ࠧ廚")
		l11l11ll111l_l1_ = [l11l1l_l1_ (u"ࠧษั๋๊ࠥะัห์หࠫ廛"),l11l1l_l1_ (u"ࠨฬิฮ๏ฮࠠฮีหࠤ๊ี้ࠡษ็ู้ฯࠧ廜"),l11l1l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬࠥะวา์ัࠤฬ๊สฮ็ํ่ࠬ廝"),l11l1l_l1_ (u"ࠪฮึะ๊ษࠢะือูࠦะัࠣห้๋ิศ้าหฯ࠭廞"),l11l1l_l1_ (u"ࠫฯืส๋สࠣัุฮࠠศๆอๆ๏๐ๅࠨ廟")]
		l11l1l1ll111_l1_ = [l11l1l_l1_ (u"ࠬ࠭廠"),l11l1l_l1_ (u"࠭ࠦࡴࡲࡀࡇࡆࡇࠥ࠳࠷࠶ࡈࠬ廡"),l11l1l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡉࠦ࠴࠸࠷ࡉ࠭廢"),l11l1l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡎࠧ࠵࠹࠸ࡊࠧ廣"),l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡇࠨ࠶࠺࠹ࡄࠨ廤")]
		l11l1l1lll1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ฮึะ๊ษࠩ廥"),l11l11ll111l_l1_)
		if l11l1l1lll1l_l1_ == -1: return
		l11l11lllll1_l1_ = l11l1l1ll111_l1_[l11l1l1lll1l_l1_]
		html,c,data = l11l1l111lll_l1_(l111l1l_l1_+l11l11lllll1_l1_)
		if c:
			try:
				d = c[l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭廦")][l11l1l_l1_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ廧")][l11l1l_l1_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ廨")][l11l1l_l1_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廩")][l11l1l_l1_ (u"ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩ廪")][l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡕࡸࡦࡒ࡫࡮ࡶࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ廫")][l11l1l_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࡵࠪ廬")]
				for l11l11l1lll1_l1_ in range(len(d)):
					group = d[l11l11l1lll1_l1_][l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡊࡶࡴࡻࡰࡓࡧࡱࡨࡪࡸࡥࡳࠩ廭")][l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭廮")]
					for l11l1ll1111l_l1_ in range(len(group)):
						render = group[l11l1ll1111l_l1_][l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡌࡩ࡭ࡶࡨࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭廯")]
						if l11l1l_l1_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬ廰") in list(render.keys()):
							l1llll1_l1_ = render[l11l1l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭廱")][l11l1l_l1_ (u"ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫ廲")][l11l1l_l1_ (u"ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ廳")][l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ廴")]
							l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࡢࡵ࠱࠲࠵࠺ࠬ廵"),l11l1l_l1_ (u"࠭ࠦࠨ延"))
							title = render[l11l1l_l1_ (u"ࠧࡵࡱࡲࡰࡹ࡯ࡰࠨ廷")]
							title = title.replace(l11l1l_l1_ (u"ࠨษ็ฬาัฺ่ࠠࠣࠫ廸"),l11l1l_l1_ (u"ࠩࠪ廹"))
							if l11l1l_l1_ (u"ࠪษือไสࠢส่ๆ๊สาࠩ建") in title: continue
							if l11l1l_l1_ (u"ࠫ็อฦๆหࠣฮูเ๊ๅࠩ廻") in title:
								title = l11l1l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭廼")+title
								l1lll11l1_l1_ = title
								l1llll11l1_l1_ = l1llll1_l1_
							if l11l1l_l1_ (u"࠭สาฬํฬࠥำำษࠩ廽") in title: continue
							title = title.replace(l11l1l_l1_ (u"ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠤࠬ廾"),l11l1l_l1_ (u"ࠨࠩ廿"))
							if l11l1l_l1_ (u"ࠩࡕࡩࡲࡵࡶࡦࠩ开") in title: continue
							if l11l1l_l1_ (u"ࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬ弁") in title:
								title = l11l1l_l1_ (u"ࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ异")+title
								l1lll11l1_l1_ = title
								l1llll11l1_l1_ = l1llll1_l1_
							if l11l1l_l1_ (u"࡙ࠬ࡯ࡳࡶࠣࡦࡾ࠭弃") in title: continue
							l11l1l111111_l1_.append(escapeUNICODE(title))
							l11l11l1llll_l1_.append(l1llll1_l1_)
			except: pass
		if not l1lll11l1_l1_: l11l1l1l1l1l_l1_ = l11l1l_l1_ (u"࠭ࠧ弄")
		else:
			l11l1l111111_l1_ = [l11l1l_l1_ (u"ࠧษั๋๊ࠥ็ไหำࠪ弅"),l1lll11l1_l1_]+l11l1l111111_l1_
			l11l11l1llll_l1_ = [l11l1l_l1_ (u"ࠨࠩ弆"),l1llll11l1_l1_]+l11l11l1llll_l1_
			l11l1l1lllll_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠ࠮ࠢสาฯืࠠศๆไ่ฯืࠧ弇"),l11l1l111111_l1_)
			if l11l1l1lllll_l1_ == -1: return
			l11l1l1l1l1l_l1_ = l11l11l1llll_l1_[l11l1l1lllll_l1_]
		if l11l1l1l1l1l_l1_: l111ll1_l1_ = l11l11_l1_+l11l1l1l1l1l_l1_
		elif l11l11lllll1_l1_: l111ll1_l1_ = l111l1l_l1_+l11l11lllll1_l1_
		else: l111ll1_l1_ = l111l1l_l1_
		l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡨ࡬ࡰࡹ࡫ࡲ࠮ࡦࡵࡳࡵࡪ࡯ࡸࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱ࠲ࡹࡥࡤࡶ࡬ࡳࡳ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡔࡨࡱࡴࡼࡥࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠥࡩ࡯࡯ࡶ࡬ࡲࡺ࡫ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴࠪ࠰࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳ࠼ࠣࠤࠬ࠯ࠊࠊࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡰࡴࡷࠤࡧࡿࠧ࠭ࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫࠥ࡯࡮ࠡࡶ࡬ࡸࡱ࡫࠺ࠡࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ࠰ࡺࡩࡵ࡮ࡨࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠸࠶ࠨ࠮ࠪࠪࠬ࠯ࠊࠊࠋࠌࠍ࡮࡬ࠠࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶ࠿ࠦࠠࠨࠢ࡬ࡲࠥࡺࡩࡵ࡮ࡨ࠾ࠏࠏࠉࠊࠋࠌࡪ࡮ࡲࡥࡵࡧࡵࡐࡎ࡙ࡔࡠࡵࡨࡥࡷࡩࡨ࠯ࡣࡳࡴࡪࡴࡤࠩࡧࡶࡧࡦࡶࡥࡖࡐࡌࡇࡔࡊࡅࠩࡶ࡬ࡸࡱ࡫ࠩࠪࠌࠌࠍࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠠࡪࡰࠣࡸ࡮ࡺ࡬ࡦ࠼ࠍࠍࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘࡤࡹ࡯ࡳࡶ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠧࠨࠢ弈")
	#DIALOG_OK()
	l1lllll_l1_(l111ll1_l1_)
	return
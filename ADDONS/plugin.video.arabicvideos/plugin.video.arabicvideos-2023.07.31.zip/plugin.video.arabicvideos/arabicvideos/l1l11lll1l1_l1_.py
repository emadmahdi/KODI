# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡎࡄࡖࡔࡠࡁࠨ㇯")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡐࡗࡠ࡟ࠨㇰ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬㇱ"),l11l1l_l1_ (u"ࠫࡘ࡯ࡧ࡯ࠢ࡬ࡲࠬㇲ"),l11l1l_l1_ (u"ࠬอไศไึห๊࠭ㇳ"),l11l1l_l1_ (u"ู࠭าุࠣห้๋า๋ัࠪㇴ")]
def MAIN(mode,url,text):
	if   mode==700: results = MENU()
	elif mode==701: results = l1lllll_l1_(url,text)
	elif mode==702: results = PLAY(url)
	elif mode==703: results = l1111_l1_(url,text)
	elif mode==704: results = l11lll_l1_(url)
	elif mode==709: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫㇵ"),l11l11_l1_,l11l1l_l1_ (u"ࠨࠩㇶ"),l11l1l_l1_ (u"ࠩࠪㇷ"),l11l1l_l1_ (u"ࠪࠫㇸ"),l11l1l_l1_ (u"ࠫࠬㇹ"),l11l1l_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧㇺ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㇻ"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧㇼ"),l11l1l_l1_ (u"ࠨࠩㇽ"),709,l11l1l_l1_ (u"ࠩࠪㇾ"),l11l1l_l1_ (u"ࠪࠫㇿ"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㈀"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㈁"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈂"),l11l1l_l1_ (u"ࠧࠨ㈃"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㈄"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㈅")+l1111l_l1_+l11l1l_l1_ (u"้๊ࠪ๐าࠨ㈆"),l11l11_l1_,701,l11l1l_l1_ (u"ࠫࠬ㈇"),l11l1l_l1_ (u"ࠬ࠭㈈"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ㈉"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㈊"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㈋")+l1111l_l1_+l11l1l_l1_ (u"ࠩฯำ๏ีࠠศๆะ่็อสࠨ㈌"),l11l11_l1_,701,l11l1l_l1_ (u"ࠪࠫ㈍"),l11l1l_l1_ (u"ࠫࠬ㈎"),l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ㈏"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈐"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㈑")+l1111l_l1_+l11l1l_l1_ (u"ࠨฮา๎ิࠦวๅลไ่ฬ๋ࠧ㈒"),l11l11_l1_,701,l11l1l_l1_ (u"ࠩࠪ㈓"),l11l1l_l1_ (u"ࠪࠫ㈔"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ㈕"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㈖"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㈗")+l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧ㈘"),l11l11_l1_,701,l11l1l_l1_ (u"ࠨࠩ㈙"),l11l1l_l1_ (u"ࠩࠪ㈚"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ㈛"))
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㈜"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㈝"),l11l1l_l1_ (u"࠭ࠧ㈞"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱ࡯࠰ࡸࡴࡶ࠭࡯ࡣࡹࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡫࡭ࡩࡪࡥ࡯ࠩ㈟"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࠨ㈠"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		title = title.replace(l11l1l_l1_ (u"ࠩ࠿ࡦࡃ࠭㈡"),l11l1l_l1_ (u"ࠪࠫ㈢")).strip(l11l1l_l1_ (u"ࠫࠥ࠭㈣"))
		if title in l1l111_l1_: continue
		if l1llll1_l1_.endswith(l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠫ㈤")): continue
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈥"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㈦")+l1111l_l1_+title,l1llll1_l1_,704)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㈧"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㈨"),l11l1l_l1_ (u"ࠪࠫ㈩"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫ㈪"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ㈫"),html,re.DOTALL)
	#for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ㈬"))
	#block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࠪ㈭"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	title = title.replace(l11l1l_l1_ (u"ࠨ࠾ࡥࡂࠬ㈮"),l11l1l_l1_ (u"ࠩࠪ㈯")).strip(l11l1l_l1_ (u"ࠪࠤࠬ㈰"))
	#	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㈱"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㈲")+l1111l_l1_+title,l1llll1_l1_,704)
	return
def l11lll_l1_(url):
	l1ll1l111_l1_ = False
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㈳"),url,l11l1l_l1_ (u"ࠧࠨ㈴"),l11l1l_l1_ (u"ࠨࠩ㈵"),l11l1l_l1_ (u"ࠩࠪ㈶"),l11l1l_l1_ (u"ࠪࠫ㈷"),l11l1l_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ㈸"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡸ࡯࡭ࡧࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㈹"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧ㈺"),l11l1l_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭㈻"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ㈼"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠩࠪ㈽"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㈾"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㈿"),l11l1l_l1_ (u"ࠬ࠭㉀"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ㉁"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠧ࠻ࠢࠪ㉂")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㉃"),l1111l_l1_+title,l1llll1_l1_,701)
				l1ll1l111_l1_ = True
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㉄"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ㉅"),block,re.DOTALL)
		if len(items)<30:
			if l1ll1l111_l1_: addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㉆"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㉇"),l11l1l_l1_ (u"࠭ࠧ㉈"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉉"),l1111l_l1_+title,l1llll1_l1_,701)
				l1ll1l111_l1_ = True
	l1l11ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸ࡫ࡵ࡯ࡵࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㉊"),html,re.DOTALL)
	if l1l11ll11_l1_:
		block = l1l11ll11_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ㉋"),block,re.DOTALL)
		if 1:
			if l1ll1l111_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㉌"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㉍"),l11l1l_l1_ (u"ࠬ࠭㉎"),9999)
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ㉏"))
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㉐"),l1111l_l1_+title,l1llll1_l1_,701)
				l1ll1l111_l1_ = True
	if not l1ll1l111_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠨࠩ㉑")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㉒"),l11l1l_l1_ (u"ࠪࠫ㉓"),request,url)
	if request==l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㉔"):
		url,search = url.split(l11l1l_l1_ (u"ࠬࡅࠧ㉕"),1)
		data = l11l1l_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬ㉖")+search
		headers = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㉗"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ㉘")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ㉙"),url,data,headers,l11l1l_l1_ (u"ࠪࠫ㉚"),l11l1l_l1_ (u"ࠫࠬ㉛"),l11l1l_l1_ (u"ࠬࡒࡁࡓࡑ࡝ࡅ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ㉜"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㉝"),url,l11l1l_l1_ (u"ࠧࠨ㉞"),l11l1l_l1_ (u"ࠨࠩ㉟"),l11l1l_l1_ (u"ࠩࠪ㉠"),l11l1l_l1_ (u"ࠪࠫ㉡"),l11l1l_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨ㉢"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠬ࠭㉣"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ㉤"))
	if request==l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ㉥"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㉦"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠩࠪ㉧"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㉨"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㉩"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ㉪"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㉫"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫ㉬"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㉭"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ㉮"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡧࡧࠠ࡮ࡩࡥࠤࡹࡧࡢ࡭ࡧࠣࡪࡺࡲ࡬ࠣࠪ࠱࠮ࡄ࠯ࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪ㉯"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㉰"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠬ࠭㉱"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㉲"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㉳"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠨ็ืห์ีษࠨ㉴"),l11l1l_l1_ (u"ࠩไ๎้๋ࠧ㉵"),l11l1l_l1_ (u"ࠪห฿์๊สࠩ㉶"),l11l1l_l1_ (u"่๊๊ࠫษࠩ㉷"),l11l1l_l1_ (u"ࠬอูๅษ้ࠫ㉸"),l11l1l_l1_ (u"࠭็ะษไࠫ㉹"),l11l1l_l1_ (u"ࠧๆสสีฬฯࠧ㉺"),l11l1l_l1_ (u"ࠨ฻ิฺࠬ㉻"),l11l1l_l1_ (u"่๋ࠩึาว็ࠩ㉼"),l11l1l_l1_ (u"ࠪห้ฮ่ๆࠩ㉽"),l11l1l_l1_ (u"ู๊ࠫัฮ์ฬࠫ㉾")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧ㉿"))
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ㊀") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ㊁")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ㊂"))
		#if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ㊃") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ㊄")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭㊅"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ㊆"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂอๅไฬ࠭࠳ࡢࡤࠬࠩ㊇"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㊈"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ㊉"):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㊊"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ㊋") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㊌"),l1111l_l1_+title,l1llll1_l1_,703,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸࡶࡩࡷ࡯ࡥࡴ࠱ࠪ㊍") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㊎"),l1111l_l1_+title,l1llll1_l1_,701,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㊏"),l1111l_l1_+title,l1llll1_l1_,703,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ㊐"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫ㊑")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㊒"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ㊓"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠬࠩࠧ㊔"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࠨ㊕")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ㊖"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㊗"),l1111l_l1_+l11l1l_l1_ (u"ุࠩๅาฯࠠࠨ㊘")+title,l1llll1_l1_,701)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㊙"),l11l1l_l1_ (u"ࠫࠬ㊚"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ㊛"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㊜"),url,l11l1l_l1_ (u"ࠧࠨ㊝"),l11l1l_l1_ (u"ࠨࠩ㊞"),l11l1l_l1_ (u"ࠩࠪ㊟"),l11l1l_l1_ (u"ࠪࠫ㊠"),l11l1l_l1_ (u"ࠫࡑࡇࡒࡐ࡜ࡄ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ㊡"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡂࡰࡺࠥࠬ࠳࠰࠿ࠪࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠨ㊢"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡴࡧࡵ࡭ࡪࡹ࠭ࡩࡧࡤࡨࡪࡸࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㊣"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠧࠨ㊤")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࠩࠪࡳࡵ࡫࡮ࡄ࡫ࡷࡽࡡ࠮ࡥࡷࡧࡱࡸ࠱ࠦࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩ㊥"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵ࡭ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬ㊦"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠪࠧࠬ㊧"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㊨"),l1111l_l1_+title,url,703,l1ll1l_l1_,l11l1l_l1_ (u"ࠬ࠭㊩"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠮࠮ࠫࡁࠬࡀࡸࡩࡲࡪࡲࡷࡂࠬ㊪"),html,re.DOTALL)
	#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ㊫"),str(l1l11l1_l1_))
	block = l1l11l1_l1_[0]
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭㊬")+l1l11_l1_+l11l1l_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ㊭"),block,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶ࡮࡫࠽ࠣࠩ㊮")+l1l11_l1_+l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㊯"),block,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡖࡩࡦࡹ࡯࡯ࠩ㊰")+l1l11_l1_+l11l1l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ㊱"),block,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄ࠼࡭࡫ࡁࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨ㊲"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㊳"),l11l1l_l1_ (u"ࠩࠪ㊴"),l11l1l_l1_ (u"ࠪࠫ㊵"),l11l1l_l1_ (u"ࠫ࠷࠸࠲࠳࠴ࠪ㊶"))
		if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ㊷"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㊸"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠯࠱ࠪ㊹"))
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ㊺")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ㊻"))
			title = title.replace(l11l1l_l1_ (u"ࠪࡀ࠴࡫࡭࠿࠾ࡶࡴࡦࡴ࠾ࠨ㊼"),l11l1l_l1_ (u"ࠫࠥ࠭㊽"))
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㊾"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ㊿"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬ㋀") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ㋁")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ㋂"))
		#		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㋃"),l1111l_l1_+title,l1llll1_l1_,702,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111ll1_l1_,l1lll11l_l1_ = [],[],[]
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨ㋄"),l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼ࠲ࡵ࡮ࡰࠨ㋅"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㋆"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ㋇"),l11l1l_l1_ (u"ࠨࠩ㋈"),l11l1l_l1_ (u"ࠩࠪ㋉"),l11l1l_l1_ (u"ࠪࠫ㋊"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㋋"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡗࡢࡶࡦ࡬ࡘ࡫ࡲࡷࡧࡵࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀ࠱ࡀ࠴ࡪࡩࡷࡀࠪ㋌"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		# l1l1111l1_l1_ l1llll1_l1_
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㋍"),block,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll1_l1_[0]
			l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ㋎"))
			l1lll1_l1_.append(l1llll1_l1_)
		# l11l11lll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠣࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠤ㋏"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ㋐"))
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㋑")+title+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ㋒"))
				l1lll1_l1_.append(l1llll1_l1_)
		# download l1l1_l1_
		#l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ㋓"),block,re.DOTALL)
		#for l1llll1_l1_,title in l1l1_l1_:
		#	if l1llll1_l1_ not in l1lll1_l1_:
		#		title = title.strip(l11l1l_l1_ (u"࠭࡜࡯ࠩ㋔"))
		#		l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㋕")+title+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㋖"))
		#		l1lll1_l1_.append(l1llll1_l1_)
	l11111_l1_ = zip(l1lll1_l1_,l1l111ll1_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll11l_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㋗"),l1lll11l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll11l_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㋘"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ㋙"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭㋚"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ㋛"),l11l1l_l1_ (u"ࠧࠬࠩ㋜"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾ࠩ㋝")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ㋞"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧ㋟")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ㋠"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭ᓔ")
l1111l_l1_ = l11l1l_l1_ (u"࠭࡟ࡄ࠶ࡋࡣࠬᓕ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩᓖ"),l11l1l_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩᓗ"),l11l1l_l1_ (u"ࠩส่ฬ่ำศ็ࠪᓘ"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠠศๆ่ึ๏ีࠧᓙ"),l11l1l_l1_ (u"ࠫࡈࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠨᓚ"),l11l1l_l1_ (u"ࠬ࠭ᓛ")]
def MAIN(mode,url,text):
	if   mode==690: results = MENU()
	elif mode==691: results = l1lllll_l1_(url,text)
	elif mode==692: results = PLAY(url)
	elif mode==693: results = l1111_l1_(url,text)
	elif mode==694: results = l11lll_l1_(url)
	elif mode==699: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᓜ"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨᓝ"),l11l1l_l1_ (u"ࠨࠩᓞ"),l11l1l_l1_ (u"ࠩࠪᓟ"),l11l1l_l1_ (u"ࠪࠫᓠ"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᓡ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓢ"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᓣ"),l11l1l_l1_ (u"ࠧࠨᓤ"),699,l11l1l_l1_ (u"ࠨࠩᓥ"),l11l1l_l1_ (u"ࠩࠪᓦ"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᓧ"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᓨ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᓩ"),l11l1l_l1_ (u"࠭ࠧᓪ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᓫ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᓬ")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่๊๋๊ำหࠪᓭ"),l11l11_l1_,691,l11l1l_l1_ (u"ࠪࠫᓮ"),l11l1l_l1_ (u"ࠫࠬᓯ"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᓰ"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᓱ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᓲ")+l1111l_l1_+l11l1l_l1_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᓳ"),l11l11_l1_,691,l11l1l_l1_ (u"ࠩࠪᓴ"),l11l1l_l1_ (u"ࠪࠫᓵ"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪᓶ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᓷ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᓸ")+l1111l_l1_+l11l1l_l1_ (u"ࠧอัํำࠥอไฤใ็ห๊࠭ᓹ"),l11l11_l1_,691,l11l1l_l1_ (u"ࠨࠩᓺ"),l11l1l_l1_ (u"ࠩࠪᓻ"),l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧᓼ"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᓽ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᓾ")+l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᓿ"),l11l11_l1_,691,l11l1l_l1_ (u"ࠧࠨᔀ"),l11l1l_l1_ (u"ࠨࠩᔁ"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫᔂ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔃ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔄ"),l11l1l_l1_ (u"ࠬ࠭ᔅ"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡺࡶࡦࡶࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔆ"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᔇ"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᔈ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᔉ")+l1111l_l1_+title,l1llll1_l1_,694)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᔊ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔋ"),l11l1l_l1_ (u"ࠬ࠭ᔌ"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ᔍ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠢࠨࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡱࡪࡴࡵࠨࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠧᔎ"),html,re.DOTALL)
	#for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠨࠩᔏ"))
	#block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬᔐ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		title = title.replace(l11l1l_l1_ (u"ࠪࡀࡧࡄࠧᔑ"),l11l1l_l1_ (u"ࠫࠬᔒ")).strip(l11l1l_l1_ (u"ࠬࠦࠧᔓ"))
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᔔ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᔕ")+l1111l_l1_+title,l1llll1_l1_,694)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᔖ"),url,l11l1l_l1_ (u"ࠩࠪᔗ"),l11l1l_l1_ (u"ࠪࠫᔘ"),l11l1l_l1_ (u"ࠫࠬᔙ"),l11l1l_l1_ (u"ࠬ࠭ᔚ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᔛ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᔜ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩᔝ"),l11l1l_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨᔞ"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᔟ"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠫࠬᔠ"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᔡ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᔢ"),l11l1l_l1_ (u"ࠧࠨᔣ"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᔤ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠩ࠽ࠤࠬᔥ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᔦ"),l1111l_l1_+title,l1llll1_l1_,691)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᔧ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᔨ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᔩ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᔪ"),l11l1l_l1_ (u"ࠨࠩᔫ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᔬ"),l1111l_l1_+title,l1llll1_l1_,691)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠪࠫᔭ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬᔮ"),l11l1l_l1_ (u"ࠬ࠭ᔯ"),request,url)
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᔰ"):
		url,search = url.split(l11l1l_l1_ (u"ࠧࡀࠩᔱ"),1)
		data = l11l1l_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧᔲ")+search
		headers = {l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨᔳ"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪᔴ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩᔵ"),url,data,headers,l11l1l_l1_ (u"ࠬ࠭ᔶ"),l11l1l_l1_ (u"࠭ࠧᔷ"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅ࠹࠶࠰࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬᔸ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᔹ"),url,l11l1l_l1_ (u"ࠩࠪᔺ"),l11l1l_l1_ (u"ࠪࠫᔻ"),l11l1l_l1_ (u"ࠫࠬᔼ"),l11l1l_l1_ (u"ࠬ࠭ᔽ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᔾ"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠧࠨᔿ"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬᕀ"))
	if request==l11l1l_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧᕁ"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᕂ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠫࠬᕃ"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᕄ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧᕅ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ᕆ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᕇ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᕈ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᕉ"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᕊ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡢࡢࠢࡰ࡫ࡧࠦࡴࡢࡤ࡯ࡩࠥ࡬ࡵ࡭࡮ࠥࠬ࠳࠰࠿ࠪࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬᕋ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᕌ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠧࠨᕍ"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᕎ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᕏ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ู้ࠪอ็ะหࠪᕐ"),l11l1l_l1_ (u"ࠫๆ๐ไๆࠩᕑ"),l11l1l_l1_ (u"ࠬอฺ็์ฬࠫᕒ"),l11l1l_l1_ (u"࠭ใๅ์หࠫᕓ"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭ᕔ"),l11l1l_l1_ (u"ࠨ้าหๆ࠭ᕕ"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩᕖ"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧᕗ"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫᕘ"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫᕙ"),l11l1l_l1_ (u"࠭ๅิำะ๎ฮ࠭ᕚ")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠧ࠰ࠩᕛ"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᕜ") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫᕝ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬᕞ"))
		#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᕟ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧᕠ")+l1ll1l_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨᕡ"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩᕢ"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫᕣ"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᕤ"),l1111l_l1_+title,l1llll1_l1_,692,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᕥ"):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᕦ"),l1111l_l1_+title,l1llll1_l1_,692,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫᕧ") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᕨ"),l1111l_l1_+title,l1llll1_l1_,693,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬᕩ") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᕪ"),l1111l_l1_+title,l1llll1_l1_,691,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᕫ"),l1111l_l1_+title,l1llll1_l1_,693,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᕬ"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ᕭ")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᕮ"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᕯ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠧࠤࠩᕰ"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪᕱ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫᕲ"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᕳ"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪᕴ")+title,l1llll1_l1_,691)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᕵ"),l11l1l_l1_ (u"࠭ࠧᕶ"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫᕷ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᕸ"),url,l11l1l_l1_ (u"ࠩࠪᕹ"),l11l1l_l1_ (u"ࠪࠫᕺ"),l11l1l_l1_ (u"ࠫࠬᕻ"),l11l1l_l1_ (u"ࠬ࠭ᕼ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᕽ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪᕾ"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᕿ"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪᖀ")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࠫࠬࡵࡰࡦࡰࡆ࡭ࡹࡿ࡜ࠩࡧࡹࡩࡳࡺࠬࠡࠩࠫ࠲࠯ࡅࠩࠨ࡞ࠬ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫᖁ"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧᖂ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠬࠩࠧᖃ"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᖄ"),l1111l_l1_+title,url,693,l1ll1l_l1_,l11l1l_l1_ (u"ࠧࠨᖅ"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡈࡴ࡮ࡹ࡯ࡥࡧࡶࡑࡦ࡯࡮ࠩ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠭࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᖆ"),html,re.DOTALL)
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪᖇ"),str(l1l11l1_l1_))
	block = l1l11l1_l1_[0]
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࠨᖈ")+l1l11_l1_+l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᖉ"),block,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫᖊ")+l1l11_l1_+l11l1l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᖋ"),block,re.DOTALL)
	if not l11llll_l1_: l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡘ࡫ࡡࡴࡱࡱࠫᖌ")+l1l11_l1_+l11l1l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᖍ"),block,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣᖎ"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫᖏ"),l11l1l_l1_ (u"ࠫࠬᖐ"),l11l1l_l1_ (u"ࠬ࠭ᖑ"),l11l1l_l1_ (u"࠭࠲࠳࠴࠵࠶ࠬᖒ"))
		if not l1l11ll_l1_: l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᖓ"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠨࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖔ"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠱࠳ࠬᖕ"))
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬᖖ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ᖗ"))
			title = title.replace(l11l1l_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪᖘ"),l11l1l_l1_ (u"࠭ࠠࠨᖙ"))
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᖚ"),l1111l_l1_+title,l1llll1_l1_,692,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᖛ"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧᖜ") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬᖝ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ᖞ"))
		#		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖟ"),l1111l_l1_+title,l1llll1_l1_,692,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111ll1_l1_,l1lll11l_l1_ = [],[],[]
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠴ࡰࡩࡲࠪᖠ"),l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡩ࠳ࡶࡨࡱࠩᖡ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᖢ"),l111l1l_l1_,l11l1l_l1_ (u"ࠩࠪᖣ"),l11l1l_l1_ (u"ࠪࠫᖤ"),l11l1l_l1_ (u"ࠫࠬᖥ"),l11l1l_l1_ (u"ࠬ࠭ᖦ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄ࠸࠵࠶࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩᖧ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠧࠣࡤࡸࡨ࡮ࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠿࠳ࡩ࡯ࡶ࠿ࠩᖨ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		# l1l1111l1_l1_ l1llll1_l1_
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖩ"),block,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll1_l1_[0]
			l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪᖪ"))
			l1lll1_l1_.append(l1llll1_l1_)
		# l11l11lll_l1_ l1l1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡰࡰࡦࡰ࡮ࡩ࡫࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᖫ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭ᖬ"))
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ᖭ")+title+l11l1l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧᖮ"))
				l1lll1_l1_.append(l1llll1_l1_)
		# download l1l1_l1_
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬᖯ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1_l1_:
				title = title.strip(l11l1l_l1_ (u"ࠨ࡞ࡱࠫᖰ"))
				l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᖱ")+title+l11l1l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᖲ"))
				l1lll1_l1_.append(l1llll1_l1_)
	l11111_l1_ = zip(l1lll1_l1_,l1l111ll1_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll11l_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᖳ"),l1lll11l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll11l_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᖴ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"࠭ࠧᖵ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠧࠨᖶ"): return
	search = search.replace(l11l1l_l1_ (u"ࠨࠢࠪᖷ"),l11l1l_l1_ (u"ࠩ࠮ࠫᖸ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫᖹ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫᖺ"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩᖻ")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫᖼ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡎ࠵ࡘࠫ㒪")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ㒫")
l11lll1111l_l1_ = [
		 l11l1l_l1_ (u"ࠩࡌࡋࡓࡕࡒࡆࡆࠪ㒬")
		,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㒭"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㒮")
		,l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ㒯"),l11l1l_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㒰")
		#,l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡇࡒࡄࡊࡌ࡚ࡊࡊ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㒱"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡅࡑࡉࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㒲"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡕࡋࡐࡉࡘࡎࡉࡇࡖࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㒳")
		,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㒴"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㒵")
		,l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭㒶"),l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨ㒷"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡌࡒࡐࡏࡢࡒࡆࡓࡅࡠࡕࡒࡖ࡙ࡋࡄࠨ㒸")
		,l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭㒹"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㒺")
		,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㒻"),l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㒼")
		,l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㒽"),l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ㒾"),l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧ㒿")
		]
l11ll1ll1l1_l1_ = 4
def MAIN(mode,url,text,type,l11lll1_l1_,l1ll1l1l1l1_l1_):
	global l1111l_l1_
	try:
		l1l11l11l11_l1_ = str(l1ll1l1l1l1_l1_[l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㓀")])
		l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡑ࡚࠭㓁")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠪࡣࠬ㓂")
	except: l1l11l11l11_l1_ = l11l1l_l1_ (u"ࠫࠬ㓃")
	try: l111l111_l1_ = str(l1ll1l1l1l1_l1_[l11l1l_l1_ (u"ࠬࡹࡥࡲࡷࡨࡲࡨ࡫ࠧ㓄")])
	except: l111l111_l1_ = l11l1l_l1_ (u"࠭ࠧ㓅")
	if   mode==710: results = FOLDERS_MENU()
	elif mode==711: results = ADD_ACCOUNT(l1l11l11l11_l1_,l111l111_l1_)
	elif mode==712: results = l1l1111l11l_l1_(l1l11l11l11_l1_)
	elif mode==713: results = GROUPS(l1l11l11l11_l1_,url,text,l11lll1_l1_)
	elif mode==714: results = ITEMS(l1l11l11l11_l1_,url,text,l11lll1_l1_)
	elif mode==715: results = PLAY(l1l11l11l11_l1_,url,type)
	elif mode==716: results = CHECK_ACCOUNT(l1l11l11l11_l1_,True)
	elif mode==717: results = l1l11l11l1l_l1_(l1l11l11l11_l1_,True)
	elif mode==718: results = EPG_ITEMS(l1l11l11l11_l1_,url,text)
	elif mode==719: results = SEARCH(text,l1l11l11l11_l1_,url,l11lll1_l1_)
	elif mode==720: results = MENU(l1l11l11l11_l1_)
	elif mode==721: results = l11lllll111_l1_(l1l11l11l11_l1_)
	elif mode==722: results = USE_FASTER_SERVER(l1l11l11l11_l1_)
	elif mode==723: results = ADD_USERAGENT(l1l11l11l11_l1_)
	elif mode==724: results = SECTIONS_MENU()
	elif mode==729: results = SEARCH_ONE_FOLDER(text,l1l11l11l11_l1_,url,l11lll1_l1_)
	else: results = False
	return results
def FOLDERS_MENU():
	for l1l11l11l11_l1_ in range(1,FOLDERS_COUNT+1):
		l11lll111l1_l1_ = l11l1l_l1_ (u"ࠧࠡࡏ࠶࡙ࠬ㓆")+str(l1l11l11l11_l1_)
		l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡐ࡙ࠬ㓇")+str(l1l11l11l11_l1_)+l11l1l_l1_ (u"ࠩࡢࠫ㓈")
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓉"),l1111l_l1_+l11l1l_l1_ (u"๊ࠫาไะࠢࠪ㓊")+text_numbers[l1l11l11l11_l1_]+l11lll111l1_l1_,l11l1l_l1_ (u"ࠬ࠭㓋"),720,l11l1l_l1_ (u"࠭ࠧ㓌"),l11l1l_l1_ (u"ࠧࠨ㓍"),l11l1l_l1_ (u"ࠨࠩ㓎"),l11l1l_l1_ (u"ࠩࠪ㓏"),{l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㓐"):l1l11l11l11_l1_})
	return
def SECTIONS_MENU():
	global l1111l_l1_
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓑"),l1111l_l1_+l11l1l_l1_ (u"ࠬาๅ๋฻ࠣว็ูวๆࠩ㓒"),l11l1l_l1_ (u"࠭ࠧ㓓"),165,l11l1l_l1_ (u"ࠧࠨ㓔"),l11l1l_l1_ (u"ࠨࠩ㓕"),l11l1l_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ㓖"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㓗"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㓘"),l11l1l_l1_ (u"ࠬ࠭㓙"),9999)
	for l1l11l11l11_l1_ in range(1,FOLDERS_COUNT+1):
		l11lll111l1_l1_ = l11l1l_l1_ (u"࠭ࠠࡎ࠵ࡘࠫ㓚")+str(l1l11l11l11_l1_)
		l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡏࡘࠫ㓛")+str(l1l11l11l11_l1_)+l11l1l_l1_ (u"ࠨࡡࠪ㓜")
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㓝"),l1111l_l1_+l11l1l_l1_ (u"ࠪว็ูวๆ่ࠢะ้ีࠠࠨ㓞")+text_numbers[l1l11l11l11_l1_]+l11lll111l1_l1_,l11l1l_l1_ (u"ࠫࠬ㓟"),165,l11l1l_l1_ (u"ࠬ࠭㓠"),l11l1l_l1_ (u"࠭ࠧ㓡"),l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㓢"),l11l1l_l1_ (u"ࠨࠩ㓣"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㓤"):l1l11l11l11_l1_})
	return
def MENU(l1l11l11l11_l1_=l11l1l_l1_ (u"ࠪࠫ㓥")):
	if l1l11l11l11_l1_:
		l11ll1111ll_l1_ = {l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㓦"):l1l11l11l11_l1_}
		l11lll111l1_l1_ = l11l1l_l1_ (u"ࠬ࠭㓧")  # l11l1l_l1_ (u"࠭ࠠࡎ࠵ࡘࠫ㓨")+str(l1l11l11l11_l1_)
	else:
		l11ll1111ll_l1_ = l11l1l_l1_ (u"ࠧࠨ㓩")
		l11lll111l1_l1_ = l11l1l_l1_ (u"ࠨࠩ㓪")
	if CHECK_TABLES_EXIST(l1l11l11l11_l1_,True):
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㓫"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์้้ࠣ็วหࠩ㓬")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠫࠬ㓭"),729,l11l1l_l1_ (u"ࠬ࠭㓮"),l11l1l_l1_ (u"࠭ࠧ㓯"),l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㓰"),l11l1l_l1_ (u"ࠨࠩ㓱"),l11ll1111ll_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㓲"),l1111l_l1_+l11l1l_l1_ (u"ࠪๆฬฬๅสࠢฦๆุอๅࠨ㓳")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠫࠬ㓴"),165,l11l1l_l1_ (u"ࠬ࠭㓵"),l11l1l_l1_ (u"࠭ࠧ㓶"),l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤ࠭㓷"),l11l1l_l1_ (u"ࠨࠩ㓸"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㓹"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㓺"),l11l1l_l1_ (u"ࠫࠬ㓻"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㓼"),l1111l_l1_+l11l1l_l1_ (u"࠭โ็๊สฮ๋ࠥี็ใฬࠫ㓽")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭㓾"),713,l11l1l_l1_ (u"ࠨࠩ㓿"),l11l1l_l1_ (u"ࠩࠪ㔀"),l11l1l_l1_ (u"ࠪࠫ㔁"),l11l1l_l1_ (u"ࠫࠬ㔂"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔃"),l1111l_l1_+l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡ็ุ๊ๆฯࠧ㔄")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㔅"),713,l11l1l_l1_ (u"ࠨࠩ㔆"),l11l1l_l1_ (u"ࠩࠪ㔇"),l11l1l_l1_ (u"ࠪࠫ㔈"),l11l1l_l1_ (u"ࠫࠬ㔉"),l11ll1111ll_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔊"),l1111l_l1_+l11l1l_l1_ (u"࠭รโๆส้๋ࠥี็ใฬࠫ㔋")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㔌"),713,l11l1l_l1_ (u"ࠨࠩ㔍"),l11l1l_l1_ (u"ࠩࠪ㔎"),l11l1l_l1_ (u"ࠪࠫ㔏"),l11l1l_l1_ (u"ࠫࠬ㔐"),l11ll1111ll_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔑"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠๆื้ๅฮ࠭㔒")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㔓"),713,l11l1l_l1_ (u"ࠨࠩ㔔"),l11l1l_l1_ (u"ࠩࠪ㔕"),l11l1l_l1_ (u"ࠪࠫ㔖"),l11l1l_l1_ (u"ࠫࠬ㔗"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔘"),l1111l_l1_+l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡ็ฯ๋ํ๊ษࠨ㔙")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࡗࡑࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭㔚"),713,l11l1l_l1_ (u"ࠨࠩ㔛"),l11l1l_l1_ (u"ࠩࠪ㔜"),l11l1l_l1_ (u"ࠪࠫ㔝"),l11l1l_l1_ (u"ࠫࠬ㔞"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㔟"),l1111l_l1_+l11l1l_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬ㔠")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ㔡"),713,l11l1l_l1_ (u"ࠨࠩ㔢"),l11l1l_l1_ (u"ࠩࠪ㔣"),l11l1l_l1_ (u"ࠪࠫ㔤"),l11l1l_l1_ (u"ࠫࠬ㔥"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㔦"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㔧"),l11l1l_l1_ (u"ࠧࠨ㔨"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔩"),l1111l_l1_+l11l1l_l1_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯ้ࠠ็ิฮอฯࠧ㔪")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㔫"),713,l11l1l_l1_ (u"ࠫࠬ㔬"),l11l1l_l1_ (u"ࠬ࠭㔭"),l11l1l_l1_ (u"࠭ࠧ㔮"),l11l1l_l1_ (u"ࠧࠨ㔯"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔰"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊฻ๆโหࠣ์๊ืสษหࠪ㔱")+l11lll111l1_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㔲"),713,l11l1l_l1_ (u"ࠫࠬ㔳"),l11l1l_l1_ (u"ࠬ࠭㔴"),l11l1l_l1_ (u"࠭ࠧ㔵"),l11l1l_l1_ (u"ࠧࠨ㔶"),l11ll1111ll_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔷"),l1111l_l1_+l11l1l_l1_ (u"ࠩฦๅ้อๅࠡ็ุ๊ๆฯ้ࠠ็ิฮอฯࠧ㔸")+l11lll111l1_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㔹"),713,l11l1l_l1_ (u"ࠫࠬ㔺"),l11l1l_l1_ (u"ࠬ࠭㔻"),l11l1l_l1_ (u"࠭ࠧ㔼"),l11l1l_l1_ (u"ࠧࠨ㔽"),l11ll1111ll_l1_)
		#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㔾"),l1111l_l1_+l11l1l_l1_ (u"่ࠩืู้ไศฬฺ้ࠣ์แส๋้ࠢึะศสࠩ㔿")+l11lll111l1_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㕀"),713,l11l1l_l1_ (u"ࠫࠬ㕁"),l11l1l_l1_ (u"ࠬ࠭㕂"),l11l1l_l1_ (u"࠭ࠧ㕃"),l11l1l_l1_ (u"ࠧࠨ㕄"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕅"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ๎ิ๐่่ษอࠤ๊า็้ๆฬࠤํ๋ัหสฬࠫ㕆")+l11lll111l1_l1_,l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㕇"),713,l11l1l_l1_ (u"ࠫࠬ㕈"),l11l1l_l1_ (u"ࠬ࠭㕉"),l11l1l_l1_ (u"࠭ࠧ㕊"),l11l1l_l1_ (u"ࠧࠨ㕋"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㕌"),l1111l_l1_+l11l1l_l1_ (u"ࠩๅ๊ํอสࠡ็ฯ๋ํ๊ษ๊่ࠡีฯฮษࠨ㕍")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㕎"),713,l11l1l_l1_ (u"ࠫࠬ㕏"),l11l1l_l1_ (u"ࠬ࠭㕐"),l11l1l_l1_ (u"࠭ࠧ㕑"),l11l1l_l1_ (u"ࠧࠨ㕒"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭㕓"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㕔"),l11l1l_l1_ (u"ࠪࠫ㕕"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕖"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไใ่๋หฯࠦวๅลุ่๏ฯࠠษั๋๊ࠥะฺ๋์ิࠫ㕗")+l11lll111l1_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡔࡘࡉࡈࡋࡑࡅࡑࡥࡇࡓࡑࡘࡔࡊࡊࠧ㕘"),713,l11l1l_l1_ (u"ࠧࠨ㕙"),l11l1l_l1_ (u"ࠨࠩ㕚"),l11l1l_l1_ (u"ࠩࠪ㕛"),l11l1l_l1_ (u"ࠪࠫ㕜"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㕝"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไโ์า๎ํํวหࠢส่ศ฻ไ๋หࠣฬิ๎ๆࠡฬ฽๎๏ืࠧ㕞")+l11lll111l1_l1_,l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭㕟"),713,l11l1l_l1_ (u"ࠧࠨ㕠"),l11l1l_l1_ (u"ࠨࠩ㕡"),l11l1l_l1_ (u"ࠩࠪ㕢"),l11l1l_l1_ (u"ࠪࠫ㕣"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ㕤"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㕥"),l11l1l_l1_ (u"࠭ࠧ㕦"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕧"),l1111l_l1_+l11l1l_l1_ (u"ࠨไ้์ฬะࠠๆื้ๅฮࠦๅ็ࠢฦื๊อฦ่ษࠣ์๊ืสษหࠪ㕨")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪ㕩"),713,l11l1l_l1_ (u"ࠪࠫ㕪"),l11l1l_l1_ (u"ࠫࠬ㕫"),l11l1l_l1_ (u"ࠬ࠭㕬"),l11l1l_l1_ (u"࠭ࠧ㕭"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㕮"),l1111l_l1_+l11l1l_l1_ (u"ࠨใํำ๏๎็ศฬฺ้ࠣ์แส่๊ࠢࠥษำๆษษ๋ฬ่ࠦๆำอฬฮ࠭㕯")+l11lll111l1_l1_,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡆࡓࡑࡐࡣࡓࡇࡍࡆࡡࡖࡓࡗ࡚ࡅࡅࠩ㕰"),713,l11l1l_l1_ (u"ࠪࠫ㕱"),l11l1l_l1_ (u"ࠫࠬ㕲"),l11l1l_l1_ (u"ࠬ࠭㕳"),l11l1l_l1_ (u"࠭ࠧ㕴"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㕵"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㕶"),l11l1l_l1_ (u"ࠩࠪ㕷"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕸"),l1111l_l1_+l11l1l_l1_ (u"ࠫ็์่ศฬฺ้ࠣ์แส่๊ࠢࠥษโิษ่๋ฬ่ࠦๆำอฬฮ࠭㕹")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡉࡕࡓ࡚ࡖ࡟ࡔࡑࡕࡘࡊࡊࠧ㕺"),713,l11l1l_l1_ (u"࠭ࠧ㕻"),l11l1l_l1_ (u"ࠧࠨ㕼"),l11l1l_l1_ (u"ࠨࠩ㕽"),l11l1l_l1_ (u"ࠩࠪ㕾"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㕿"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅึ่ไอ๋ࠥๆࠡลๅืฬ๋็ศ๋้ࠢึะศสࠩ㖀")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉ࠭㖁"),713,l11l1l_l1_ (u"࠭ࠧ㖂"),l11l1l_l1_ (u"ࠧࠨ㖃"),l11l1l_l1_ (u"ࠨࠩ㖄"),l11l1l_l1_ (u"ࠩࠪ㖅"),l11ll1111ll_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㖆"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㖇"),l11l1l_l1_ (u"ࠬ࠭㖈"),9999)
	for seq in range(1,l11ll1ll1l1_l1_+1):
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㖉"),l1111l_l1_+l11l1l_l1_ (u"ࠧฦุสๅฮ่ࠦห฼ํ๎ึࠦัศสฺࠫ㖊")+l11lll111l1_l1_+l11l1l_l1_ (u"ࠨࠢࠪ㖋")+text_numbers[seq],l11l1l_l1_ (u"ࠩࠪ㖌"),711,l11l1l_l1_ (u"ࠪࠫ㖍"),l11l1l_l1_ (u"ࠫࠬ㖎"),l11l1l_l1_ (u"ࠬ࠭㖏"),l11l1l_l1_ (u"࠭ࠧ㖐"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㖑"):l1l11l11l11_l1_,l11l1l_l1_ (u"ࠨࡵࡨࡵࡺ࡫࡮ࡤࡧࠪ㖒"):seq})
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㖓"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬึอๅอࠢส่็์่ศฬࠣࠬัี่ๅࠢไๆ฼࠯ࠧ㖔")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡈࡔࡌࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㖕"),713,l11l1l_l1_ (u"ࠬ࠭㖖"),l11l1l_l1_ (u"࠭ࠧ㖗"),l11l1l_l1_ (u"ࠧࠨ㖘"),l11l1l_l1_ (u"ࠨࠩ㖙"),l11ll1111ll_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㖚"),l1111l_l1_+l11l1l_l1_ (u"ࠪวึฺ๊โࠢส่็์่ศฬ่้ࠣษ๊ศ็ࠣห้๋วื์ฬࠫ㖛")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㖜"),713,l11l1l_l1_ (u"ࠬ࠭㖝"),l11l1l_l1_ (u"࠭ࠧ㖞"),l11l1l_l1_ (u"ࠧࠨ㖟"),l11l1l_l1_ (u"ࠨࠩ㖠"),l11ll1111ll_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㖡"),l1111l_l1_+l11l1l_l1_ (u"ࠪวึฺ๊โࠢหีฬ๋ฬࠡษ็ๆ๋๎วหࠢ็่ศ๐วๆࠢส่๊อึ๋หࠪ㖢")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡄࡖࡈࡎࡉࡗࡇࡇࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㖣"),713,l11l1l_l1_ (u"ࠬ࠭㖤"),l11l1l_l1_ (u"࠭ࠧ㖥"),l11l1l_l1_ (u"ࠧࠨ㖦"),l11l1l_l1_ (u"ࠨࠩ㖧"),l11ll1111ll_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㖨"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㖩"),l11l1l_l1_ (u"ࠫࠬ㖪"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㖫"),l1111l_l1_+l11l1l_l1_ (u"࠭ลืษไอࠥษ่ࠡฬ฽๎๏ืࠠศึอีฬ้ࠧ㖬")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㖭"),711,l11l1l_l1_ (u"ࠨࠩ㖮"),l11l1l_l1_ (u"ࠩࠪ㖯"),l11l1l_l1_ (u"ࠪࠫ㖰"),l11l1l_l1_ (u"ࠫࠬ㖱"),l11ll1111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㖲"),l1111l_l1_+l11l1l_l1_ (u"ู࠭ะัࠣๅ๏ี๊้้สฮࠬ㖳")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㖴"),721,l11l1l_l1_ (u"ࠨࠩ㖵"),l11l1l_l1_ (u"ࠩࠪ㖶"),l11l1l_l1_ (u"ࠪࠫ㖷"),l11l1l_l1_ (u"ࠫࠬ㖸"),l11ll1111ll_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㖹"),l1111l_l1_+l11l1l_l1_ (u"࠭แฮืࠣหูะัศๅࠪ㖺")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㖻"),716,l11l1l_l1_ (u"ࠨࠩ㖼"),l11l1l_l1_ (u"ࠩࠪ㖽"),l11l1l_l1_ (u"ࠪࠫ㖾"),l11l1l_l1_ (u"ࠫࠬ㖿"),l11ll1111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㗀"),l1111l_l1_+l11l1l_l1_ (u"࠭ฬๅส้้ࠣ็วหࠩ㗁")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㗂"),712,l11l1l_l1_ (u"ࠨࠩ㗃"),l11l1l_l1_ (u"ࠩࠪ㗄"),l11l1l_l1_ (u"ࠪࠫ㗅"),l11l1l_l1_ (u"ࠫࠬ㗆"),l11ll1111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㗇"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิฯ้้ࠣ็วหࠩ㗈")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㗉"),717,l11l1l_l1_ (u"ࠨࠩ㗊"),l11l1l_l1_ (u"ࠩࠪ㗋"),l11l1l_l1_ (u"ࠪࠫ㗌"),l11l1l_l1_ (u"ࠫࠬ㗍"),l11ll1111ll_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㗎"),l1111l_l1_+l11l1l_l1_ (u"࠭วิฬัำฬ๋ࠠศๆึ๎ึ็ัࠡษ็วุืูࠨ㗏")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㗐"),722,l11l1l_l1_ (u"ࠨࠩ㗑"),l11l1l_l1_ (u"ࠩࠪ㗒"),l11l1l_l1_ (u"ࠪࠫ㗓"),l11l1l_l1_ (u"ࠫࠬ㗔"),l11ll1111ll_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㗕"),l1111l_l1_+l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣฮ฿๐๊าࠩ㗖")+l11lll111l1_l1_,l11l1l_l1_ (u"ࠧࠨ㗗"),723,l11l1l_l1_ (u"ࠨࠩ㗘"),l11l1l_l1_ (u"ࠩࠪ㗙"),l11l1l_l1_ (u"ࠪࠫ㗚"),l11l1l_l1_ (u"ࠫࠬ㗛"),l11ll1111ll_l1_)
	return
def CHECK_ACCOUNT(l1l11l11l11_l1_,l1ll_l1_=True):
	ok,status = False,l11l1l_l1_ (u"ࠬ࠭㗜")
	l11ll11111l_l1_,l1l11l1l111_l1_ = l11l1l_l1_ (u"࠭ࠧ㗝"),l11l1l_l1_ (u"ࠧࠨ㗞")
	l11l1ll1ll1_l1_,l11ll1lll1l_l1_,server,username,password = GET_URL(l1l11l11l11_l1_)
	if username==l11l1l_l1_ (u"ࠨࠩ㗟"): return
	l111ll111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹࡥࠧ㗠")+l1l11l11l11_l1_)
	headers = {l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㗡"):l111ll111l_l1_}
	if l11l1ll1ll1_l1_:
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ㗢"),l11l1ll1ll1_l1_,l11l1l_l1_ (u"ࠬ࠭㗣"),headers,False,l11l1l_l1_ (u"࠭ࠧ㗤"),l11l1l_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨ㗥"))
		html = response.content
		if response.succeeded:
			timestamp,l11l1llll11_l1_,l11l1ll1l1l_l1_,l11l1l11l1l_l1_,l11lll11111_l1_ = 0,0,l11l1l_l1_ (u"ࠨࠩ㗦"),l11l1l_l1_ (u"ࠩࠪ㗧"),l11l1l_l1_ (u"ࠪࠫ㗨")
			try:
				dict = EVAL(l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㗩"),html)
				status = dict[l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࡢ࡭ࡳ࡬࡯ࠨ㗪")][l11l1l_l1_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭㗫")]
				ok = True
				l11l1ll1l1l_l1_ = dict[l11l1l_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸ࡟ࡪࡰࡩࡳࠬ㗬")][l11l1l_l1_ (u"ࠨࡶ࡬ࡱࡪࡥ࡮ࡰࡹࠪ㗭")]
			except: pass
			if l11l1ll1l1l_l1_:
				try:
					struct = time.strptime(l11l1ll1l1l_l1_,l11l1l_l1_ (u"ࠩࠨ࡝࠳ࠫ࡭࠯ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭㗮"))
					timestamp = int(time.mktime(struct))
					l11l1llll11_l1_ = int(now-timestamp)
					l11l1llll11_l1_ = int((l11l1llll11_l1_+900)/1800)*1800
				except: pass
				try:
					struct = time.localtime(int(dict[l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭㗯")][l11l1l_l1_ (u"ࠫࡨࡸࡥࡢࡶࡨࡨࡤࡧࡴࠨ㗰")]))
					l11l1l11l1l_l1_ = time.strftime(l11l1l_l1_ (u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ㗱"),struct)
				except: pass
				try:
					struct = time.localtime(int(dict[l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ㗲")][l11l1l_l1_ (u"ࠧࡦࡺࡳࡣࡩࡧࡴࡦࠩ㗳")]))
					l11lll11111_l1_ = time.strftime(l11l1l_l1_ (u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬ㗴"),struct)
				except: pass
			settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵࡥࠧ㗵")+l1l11l11l11_l1_,str(now))
			settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡦ࡬ࡪ࡫ࡥࠧ㗶")+l1l11l11l11_l1_,str(l11l1llll11_l1_))
			try:
				l11lll1l11l_l1_ = l11l1l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡤ࡯࡮ࡧࡱࠥ࠾ࠬ㗷")+html.split(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡥࡩ࡯ࡨࡲࠦ࠿࠭㗸"))[1]
				l11lll1l11l_l1_ = l11lll1l11l_l1_.replace(l11l1l_l1_ (u"࠭࠺ࠨ㗹"),l11l1l_l1_ (u"ࠧ࠻ࠢࠪ㗺")).replace(l11l1l_l1_ (u"ࠨ࠮ࠪ㗻"),l11l1l_l1_ (u"ࠩ࠯ࠤࠬ㗼")).replace(l11l1l_l1_ (u"ࠪࢁࢂ࠭㗽"),l11l1l_l1_ (u"ࠫࢂ࠭㗾"))
				new = re.findall(l11l1l_l1_ (u"ࠬࠨࡵࡳ࡮ࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࠣࡲࡲࡶࡹࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ㗿"),l11lll1l11l_l1_,re.DOTALL)
				l11ll11111l_l1_,l1l11l1l111_l1_ = new[0]
			except: ok = False
			if ok and l1ll_l1_:
				max = dict[l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩ㘀")][l11l1l_l1_ (u"ࠧ࡮ࡣࡻࡣࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࡴࠩ㘁")]
				l11llll1111_l1_ = dict[l11l1l_l1_ (u"ࠨࡷࡶࡩࡷࡥࡩ࡯ࡨࡲࠫ㘂")][l11l1l_l1_ (u"ࠩࡤࡧࡹ࡯ࡶࡦࡡࡦࡳࡳࡹࠧ㘃")]
				l1l11111111_l1_ = dict[l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭㘄")][l11l1l_l1_ (u"ࠫ࡮ࡹ࡟ࡵࡴ࡬ࡥࡱ࠭㘅")]
				parts = l11l1ll1ll1_l1_.split(l11l1l_l1_ (u"ࠬࡅࠧ㘆"),1)
				message = l11l1l_l1_ (u"࠭ࡕࡓࡎ࠽ࠤࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㘇")+l11l1ll1ll1_l1_+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㘈")
				message += l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࡙ࡴࡢࡶࡸࡷ࠿ࠦࠠࠨ㘉")+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㘊")+status+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㘋")
				message += l11l1l_l1_ (u"ࠫࡡࡴࡔࡳ࡫ࡤࡰ࠿ࠦࠠࠡࠢࠪ㘌")+l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㘍")+str(l1l11111111_l1_==l11l1l_l1_ (u"࠭࠱ࠨ㘎"))+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㘏")
				message += l11l1l_l1_ (u"ࠨ࡞ࡱࡇࡷ࡫ࡡࡵࡧࡧࠤࠥࡇࡴ࠻ࠢࠣࠫ㘐")+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㘑")+l11l1l11l1l_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㘒")
				message += l11l1l_l1_ (u"ࠫࡡࡴࡅࡹࡲ࡬ࡶࡾࠦࡄࡢࡶࡨ࠾ࠥࠦࠧ㘓")+l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㘔")+l11lll11111_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㘕")
				message += l11l1l_l1_ (u"ࠧ࡝ࡰࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࡹࠠࠡࠢࠫࠤࡆࡩࡴࡪࡸࡨࠤ࠴ࠦࡍࡢࡺ࡬ࡱࡺࡳࠠࠪࠢ࠽ࠤࠥ࠭㘖")+l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㘗")+l11llll1111_l1_+l11l1l_l1_ (u"ࠩࠣ࠳ࠥ࠭㘘")+max+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㘙")
				message += l11l1l_l1_ (u"ࠫࡡࡴࡁ࡭࡮ࡲࡻࡪࡪࠠࡐࡷࡷࡴࡺࡺࡳ࠻ࠢࠣࠤࠬ㘚")+l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ㘛")+l11l1l_l1_ (u"ࠨࠠ࠭ࠢࠥ㘜").join(dict[l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪ㘝")][l11l1l_l1_ (u"ࠨࡣ࡯ࡰࡴࡽࡥࡥࡡࡲࡹࡹࡶࡵࡵࡡࡩࡳࡷࡳࡡࡵࡵࠪ㘞")])+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㘟")
				message += l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㘠")+l11lll1l11l_l1_
				if status==l11l1l_l1_ (u"ࠫࡆࡩࡴࡪࡸࡨࠫ㘡"): DIALOG_TEXTVIEWER(l11l1l_l1_ (u"ࠬอไศึอีฬ้๋ࠠ฻่่ࠥฮฯู้่้ࠣอใๅࠩ㘢"),message)
				else: DIALOG_TEXTVIEWER(l11l1l_l1_ (u"๊࠭ษั๋ࠤศ์่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠศๆสุฯืวไࠩ㘣"),message)
	if l11l1ll1ll1_l1_ and ok and status==l11l1l_l1_ (u"ࠧࡂࡥࡷ࡭ࡻ࡫ࠧ㘤"):
		LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㘥"),l11l1l_l1_ (u"ࠩ࠱ࠤࠥࠦࡃࡩࡧࡦ࡯࡮ࡴࡧࠡࡋࡓࡘ࡛ࠦࡕࡓࡎࠣࠤࠥࡡࠠࡊࡒࡗ࡚ࠥࡧࡣࡤࡱࡸࡲࡹࠦࡩࡴࠢࡒࡏࠥࡣࠠࠡࠢ࡞ࠤࠬ㘦")+l11l1ll1ll1_l1_+l11l1l_l1_ (u"ࠪࠤࡢ࠭㘧"))
		succeeded = True
	else:
		LOG_THIS(l11l1l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㘨"),l11l1l_l1_ (u"ࠬࡉࡨࡦࡥ࡮࡭ࡳ࡭ࠠࡊࡒࡗ࡚࡛ࠥࡒࡍࠢࠣࠤࡠࠦࡄࡰࡧࡶࠤࡳࡵࡴࠡࡹࡲࡶࡰࠦ࡝ࠡࠢࠣ࡟ࠥ࠭㘩")+l11l1ll1ll1_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ㘪"))
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㘫"),l11l1l_l1_ (u"ࠨࠩ㘬"),l11l1l_l1_ (u"ࠩไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠬ㘭"),l11l1l_l1_ (u"ࠪีฬฮืࠡษืฮึอใࠡโࡌࡔ࡙࡜ࠠศๆำ๎่ࠥๅหࠢส๊ฯࠦศฦุสๅฯํࠠฦๆ์ࠤฬ๊ศา่ส้ัࠦไศࠢํ฽๊๊ࠠฤ๊ࠣห้ืวษูࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦรั้หࠤส๊้ࠡไสส๊ฯࠠศึอีฬ้ࠠแࡋࡓࡘ่࡛ࠦใ็ࠣฬส฼วโหࠣีฬฮืࠡโࡌࡔ࡙࡜ࠠอัํำࠥษ่ࠡไ่ࠤอหีๅษะࠤฬ๊ัศสฺࠤฬ๊โะ์่ࠫ㘮"))
		succeeded = False
	return succeeded,l11ll11111l_l1_,l1l11l1l111_l1_
def ITEMS(l1l11l11l11_l1_,l11l11lllll_l1_,l11ll1llll1_l1_,l11ll111ll1_l1_,l1ll_l1_=True):
	if not l11ll111ll1_l1_: l11ll111ll1_l1_ = l11l1l_l1_ (u"ࠫ࠶࠭㘯")
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,l1ll_l1_): return
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l11lllll_l1_)
	l11lll11ll1_l1_ = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ㘰"),l11l11lllll_l1_,l11ll1llll1_l1_)
	end = int(l11ll111ll1_l1_)*100
	start = end-100
	for context,title,url,l1ll1l_l1_ in l11lll11ll1_l1_[start:end]:
		l1l1111l1ll_l1_ = (l11l1l_l1_ (u"࠭ࡇࡓࡑࡘࡔࡊࡊࠧ㘱") in l11l11lllll_l1_ or l11l11lllll_l1_==l11l1l_l1_ (u"ࠧࡂࡎࡏࠫ㘲"))
		l11ll1ll1ll_l1_ = (l11l1l_l1_ (u"ࠨࡉࡕࡓ࡚ࡖࡅࡅࠩ㘳") not in l11l11lllll_l1_ and l11l11lllll_l1_!=l11l1l_l1_ (u"ࠩࡄࡐࡑ࠭㘴"))
		if l1l1111l1ll_l1_ or l11ll1ll1ll_l1_:
			if   l11l1l_l1_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬ㘵")  in l11l11lllll_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㘶"),l1111l_l1_+title,url,718,l1ll1l_l1_,l11l1l_l1_ (u"ࠬ࠭㘷"),l11l1l_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ㘸"),l11l1l_l1_ (u"ࠧࠨ㘹"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㘺"):l1l11l11l11_l1_}])
			elif l11l1l_l1_ (u"ࠩࡈࡔࡌ࠭㘻") 		 in l11l11lllll_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㘼"),l1111l_l1_+title,url,718,l1ll1l_l1_,l11l1l_l1_ (u"ࠫࠬ㘽"),l11l1l_l1_ (u"ࠬࡌࡕࡍࡎࡢࡉࡕࡍࠧ㘾"),l11l1l_l1_ (u"࠭ࠧ㘿"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙀"):l1l11l11l11_l1_}])
			elif l11l1l_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ㙁") in l11l11lllll_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㙂"),l1111l_l1_+title,url,718,l1ll1l_l1_,l11l1l_l1_ (u"ࠪࠫ㙃"),l11l1l_l1_ (u"࡙ࠫࡏࡍࡆࡕࡋࡍࡋ࡚ࠧ㙄"),l11l1l_l1_ (u"ࠬ࠭㙅"),{l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㙆"):l1l11l11l11_l1_}])
			elif l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ㙇") 	 in l11l11lllll_l1_: menuItemsLIST.append([l11l1l_l1_ (u"ࠨ࡮࡬ࡺࡪ࠭㙈"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"ࠩࠪ㙉"),l11l1l_l1_ (u"ࠪࠫ㙊"),context,{l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㙋"):l1l11l11l11_l1_}])
			else: menuItemsLIST.append([l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㙌"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"࠭ࠧ㙍"),l11l1l_l1_ (u"ࠧࠨ㙎"),l11l1l_l1_ (u"ࠨࠩ㙏"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㙐"):l1l11l11l11_l1_}])
	total = len(l11lll11ll1_l1_)
	PAGINATION(l1l11l11l11_l1_,l11ll111ll1_l1_,l11l11lllll_l1_,714,total,l11ll1llll1_l1_)
	return
def SHOW_EMPTY(l11l1ll11ll_l1_):
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㙑"),l11l1ll11ll_l1_+l11l1l_l1_ (u"ࠫ์ึ็ࠡษ็ๆฬฬๅสࠢศ้ฬࠦแศำ฽อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠬ㙒"),l11l1l_l1_ (u"ࠬ࠭㙓"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㙔"),l11l1ll11ll_l1_+l11l1l_l1_ (u"ࠧฤ๊ࠣห้ิฯๆหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣหูะัศๅๆࠫ㙕"),l11l1l_l1_ (u"ࠨࠩ㙖"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㙗"),l11l1ll11ll_l1_+l11l1l_l1_ (u"ࠪวํࠦัศสฺࠤࡒ࠹ࡕแࠢส่ี๐ࠠฤ่อࠤศ฼แห้ࠣ฾๏ืࠠึฯํัࠬ㙘"),l11l1l_l1_ (u"ࠫࠬ㙙"),9999)
	return
def GROUPS(l1l11l11l11_l1_,l11l11lllll_l1_,l11ll1llll1_l1_,l11ll111ll1_l1_,l1l11lll_l1_=l11l1l_l1_ (u"ࠬ࠭㙚"),l1ll_l1_=True):
	if not l11ll111ll1_l1_: l11ll111ll1_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ㙛")
	l11l1ll11ll_l1_ = l1111l_l1_
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,l1ll_l1_): return False
	if l11l1l_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㙜") in l11ll1llll1_l1_: l11ll11l1l1_l1_,l11l1l1llll_l1_ = l11ll1llll1_l1_.split(l11l1l_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㙝"))
	else: l11ll11l1l1_l1_,l11l1l1llll_l1_ = l11ll1llll1_l1_,l11l1l_l1_ (u"ࠩࠪ㙞")
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l11lllll_l1_)
	l11llll1l11_l1_ = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㙟"),l11l11lllll_l1_,l11l1l_l1_ (u"ࠫࡤࡥࡇࡓࡑࡘࡔࡘࡥ࡟ࠨ㙠"))
	if not l11llll1l11_l1_: return False
	l1l111ll11l_l1_ = []
	for group,l1ll1l_l1_ in l11llll1l11_l1_:
		if l1l11lll_l1_:
			if l11l1l_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ㙡") in group: l11l1ll11ll_l1_ = l11l1l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭㙢")
			elif l11l1l_l1_ (u"ࠧࠢࠣࡢࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡥࠡࠢࠩ㙣") in group: l11l1ll11ll_l1_ = l11l1l_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ㙤")
			elif l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ㙥") in l11l11lllll_l1_: l11l1ll11ll_l1_ = l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ㙦")
			else: l11l1ll11ll_l1_ = l11l1l_l1_ (u"࡛ࠫࡏࡄࡆࡑࡖࠫ㙧")
			l11l1ll11ll_l1_ = l11l1l_l1_ (u"ࠬ࠲࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㙨")+l11l1ll11ll_l1_+l11l1l_l1_ (u"࠭࠺ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㙩")
		if l11l1l_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㙪") in group: l1l11111ll1_l1_,l11l11llll1_l1_ = group.split(l11l1l_l1_ (u"ࠨࡡࡢࡗࡊࡘࡉࡆࡕࡢࡣࠬ㙫"))
		else: l1l11111ll1_l1_,l11l11llll1_l1_ = group,l11l1l_l1_ (u"ࠩࠪ㙬")
		if not l11ll1llll1_l1_:
			if l1l11111ll1_l1_ in l1l111ll11l_l1_: continue
			l1l111ll11l_l1_.append(l1l11111ll1_l1_)
			if l11l1l_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࠪ㙭") in l1l11lll_l1_: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㙮"),l11l1ll11ll_l1_+l1l11111ll1_l1_,l11l11lllll_l1_,168,l11l1l_l1_ (u"ࠬ࠭㙯"),l11l1l_l1_ (u"࠭࠱ࠨ㙰"),group,l11l1l_l1_ (u"ࠧࠨ㙱"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㙲"):l1l11l11l11_l1_})
			elif l11l1l_l1_ (u"ࠩࡢࡣࡘࡋࡒࡊࡇࡖࡣࡤ࠭㙳") in group: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㙴"),l11l1ll11ll_l1_+l1l11111ll1_l1_,l11l11lllll_l1_,713,l11l1l_l1_ (u"ࠫࠬ㙵"),l11l1l_l1_ (u"ࠬ࠷ࠧ㙶"),group,l11l1l_l1_ (u"࠭ࠧ㙷"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㙸"):l1l11l11l11_l1_})
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㙹"),l11l1ll11ll_l1_+l1l11111ll1_l1_,l11l11lllll_l1_,714,l11l1l_l1_ (u"ࠩࠪ㙺"),l11l1l_l1_ (u"ࠪ࠵ࠬ㙻"),group,l11l1l_l1_ (u"ࠫࠬ㙼"),{l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㙽"):l1l11l11l11_l1_})
		elif l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡖࡎࡋࡓࡠࡡࠪ㙾") in group and l1l11111ll1_l1_==l11ll11l1l1_l1_:
			if l11l11llll1_l1_ in l1l111ll11l_l1_: continue
			l1l111ll11l_l1_.append(l11l11llll1_l1_)
			if l11l1l_l1_ (u"ࠧࡓࡃࡑࡈࡔࡓࠧ㙿") in l1l11lll_l1_: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㚀"),l11l1ll11ll_l1_+l11l11llll1_l1_,l11l11lllll_l1_,168,l11l1l_l1_ (u"ࠩࠪ㚁"),l11l1l_l1_ (u"ࠪ࠵ࠬ㚂"),group,l11l1l_l1_ (u"ࠫࠬ㚃"),{l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㚄"):l1l11l11l11_l1_})
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㚅"),l11l1ll11ll_l1_+l11l11llll1_l1_,l11l11lllll_l1_,714,l1ll1l_l1_,l11l1l_l1_ (u"ࠧ࠲ࠩ㚆"),group,l11l1l_l1_ (u"ࠨࠩ㚇"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㚈"):l1l11l11l11_l1_})
	#if l11l1l_l1_ (u"ࠪࡗࡔࡘࡔࡆࡆࠪ㚉") in l11l11lllll_l1_:
	menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	if not l1l11lll_l1_:
		end = int(l11ll111ll1_l1_)*100
		start = end-100
		total = len(menuItemsLIST)
		menuItemsLIST[:] = menuItemsLIST[start:end]
		PAGINATION(l1l11l11l11_l1_,l11ll111ll1_l1_,l11l11lllll_l1_,713,total,l11ll1llll1_l1_)
	return True
def EPG_ITEMS(l1l11l11l11_l1_,url,function):
	l111ll111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࡠࠩ㚊")+l1l11l11l11_l1_)
	headers = {l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㚋"):l111ll111l_l1_}
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,True): return
	timestamp = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࡢࠫ㚌")+l1l11l11l11_l1_)
	if not timestamp or now-int(timestamp)>24*l11l1ll111l_l1_:
		succeeded,l11ll11111l_l1_,l1l11l1l111_l1_ = CHECK_ACCOUNT(l1l11l11l11_l1_,False)
		if not succeeded: return
	l11l1llll11_l1_ = int(settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱࡭ࡵࡺࡶ࠯ࡶ࡬ࡱࡪࡪࡩࡧࡨࡢࠫ㚍")+l1l11l11l11_l1_))
	server = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲࡮ࡶࡴࡷ࠰ࡶࡩࡷࡼࡥࡳࡡࠪ㚎")+l1l11l11l11_l1_)
	username = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡤ࠭㚏")+l1l11l11l11_l1_)
	password = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡩࡱࡶࡹ࠲ࡵࡧࡳࡴࡹࡲࡶࡩࡥࠧ㚐")+l1l11l11l11_l1_)
	l11l1llllll_l1_ = url.split(l11l1l_l1_ (u"ࠫ࠴࠭㚑"))
	l11l1l111ll_l1_ = l11l1llllll_l1_[-1].replace(l11l1l_l1_ (u"ࠬ࠴ࡴࡴࠩ㚒"),l11l1l_l1_ (u"࠭ࠧ㚓")).replace(l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㚔"),l11l1l_l1_ (u"ࠨࠩ㚕"))
	if function==l11l1l_l1_ (u"ࠩࡖࡌࡔࡘࡔࡠࡇࡓࡋࠬ㚖"): l1l11l11111_l1_ = l11l1l_l1_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡪࡲࡶࡹࡥࡥࡱࡩࠪ㚗")
	else: l1l11l11111_l1_ = l11l1l_l1_ (u"ࠫ࡬࡫ࡴࡠࡵ࡬ࡱࡵࡲࡥࡠࡦࡤࡸࡦࡥࡴࡢࡤ࡯ࡩࠬ㚘")
	l11l1ll1ll1_l1_,l11ll1lll1l_l1_,server,username,password = GET_URL(l1l11l11l11_l1_)
	if not username: return
	l11ll11ll1l_l1_ = l11l1ll1ll1_l1_+l11l1l_l1_ (u"ࠬࠬࡡࡤࡶ࡬ࡳࡳࡃࠧ㚙")+l1l11l11111_l1_+l11l1l_l1_ (u"࠭ࠦࡴࡶࡵࡩࡦࡳ࡟ࡪࡦࡀࠫ㚚")+l11l1l111ll_l1_
	html = OPENURL_CACHED(NO_CACHE,l11ll11ll1l_l1_,l11l1l_l1_ (u"ࠧࠨ㚛"),headers,l11l1l_l1_ (u"ࠨࠩ㚜"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡆࡒࡊࡣࡎ࡚ࡅࡎࡕ࠰࠶ࡳࡪࠧ㚝"))
	l11lll11lll_l1_ = EVAL(l11l1l_l1_ (u"ࠪࡨ࡮ࡩࡴࠨ㚞"),html)
	l11l1l1lll1_l1_ = l11lll11lll_l1_[l11l1l_l1_ (u"ࠫࡪࡶࡧࡠ࡮࡬ࡷࡹ࡯࡮ࡨࡵࠪ㚟")]
	l11ll1l1l1l_l1_ = []
	if function in [l11l1l_l1_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ㚠"),l11l1l_l1_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩ㚡")]:
		for dict in l11l1l1lll1_l1_:
			if dict[l11l1l_l1_ (u"ࠧࡩࡣࡶࡣࡦࡸࡣࡩ࡫ࡹࡩࠬ㚢")]==1:
				l11ll1l1l1l_l1_.append(dict)
				if function in [l11l1l_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ㚣")]: break
		if not l11ll1l1l1l_l1_: return
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㚤"),l1111l_l1_+l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢอไๆๆไหฯࠦวๅล๋่๏ࠦศ่า๊ࠤฬ๊โศศ่อ่ࠥฯࠡๆสࠤฯ฿ๅๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㚥"),l11l1l_l1_ (u"ࠫࠬ㚦"),9999)
		if function in [l11l1l_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ㚧")]:
			l1l11l111ll_l1_ = 2
			l11l1ll1111_l1_ = l1l11l111ll_l1_*l11l1ll111l_l1_
			l11ll1l1l1l_l1_ = []
			l1l11l1lll1_l1_ = int(int(dict[l11l1l_l1_ (u"࠭ࡳࡵࡣࡵࡸࡤࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ㚨")])/l11l1ll1111_l1_)*l11l1ll1111_l1_
			l1l11111l11_l1_ = now+l11l1ll1111_l1_
			l11l1l11ll1_l1_ = int((l1l11111l11_l1_-l1l11l1lll1_l1_)/l11l1ll111l_l1_)
			for count in range(l11l1l11ll1_l1_):
				if count>=6:
					if count%l1l11l111ll_l1_!=0: continue
					l1l11l1ll_l1_ = l11l1ll1111_l1_
				else: l1l11l1ll_l1_ = l11l1ll1111_l1_//2
				l11l1l1l11l_l1_ = l1l11l1lll1_l1_+count*l11l1ll111l_l1_
				dict = {}
				dict[l11l1l_l1_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㚩")] = l11l1l_l1_ (u"ࠨࠩ㚪")
				struct = time.localtime(l11l1l1l11l_l1_-l11l1llll11_l1_-l11l1ll111l_l1_)
				dict[l11l1l_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ㚫")] = time.strftime(l11l1l_l1_ (u"ࠪࠩ࡞࠴ࠥ࡮࠰ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧ㚬"),struct)
				dict[l11l1l_l1_ (u"ࠫࡸࡺࡡࡳࡶࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭㚭")] = str(l11l1l1l11l_l1_)
				dict[l11l1l_l1_ (u"ࠬࡹࡴࡰࡲࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭㚮")] = str(l11l1l1l11l_l1_+l1l11l1ll_l1_)
				l11ll1l1l1l_l1_.append(dict)
	elif function in [l11l1l_l1_ (u"࠭ࡓࡉࡑࡕࡘࡤࡋࡐࡈࠩ㚯"),l11l1l_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ㚰")]: l11ll1l1l1l_l1_ = l11l1l1lll1_l1_
	if function==l11l1l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪ㚱") and len(l11ll1l1l1l_l1_)>0:
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㚲"),l1111l_l1_+l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํะ่ࠢๅหห๋ษࠡสิห๊าࠠศๆๅ๊ํอสࠡࠪฯำํ๊ࠠโไฺ࠭ๅࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㚳"),l11l1l_l1_ (u"ࠫࠬ㚴"),9999)
	l11ll1l11l1_l1_ = []
	l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬ㚵"))
	for dict in l11ll1l1l1l_l1_:
		title = base64.b64decode(dict[l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㚶")])
		if kodi_version>18.99: title = title.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ㚷"))
		l11l1l1l11l_l1_ = int(dict[l11l1l_l1_ (u"ࠨࡵࡷࡥࡷࡺ࡟ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ㚸")])
		l1l1111ll1l_l1_ = int(dict[l11l1l_l1_ (u"ࠩࡶࡸࡴࡶ࡟ࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪ㚹")])
		l1l11111lll_l1_ = str(int((l1l1111ll1l_l1_-l11l1l1l11l_l1_+59)/60))
		l1l11ll11l1_l1_ = dict[l11l1l_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ㚺")].replace(l11l1l_l1_ (u"ࠫࠥ࠭㚻"),l11l1l_l1_ (u"ࠬࡀࠧ㚼"))
		struct = time.localtime(l11l1l1l11l_l1_-l11l1ll111l_l1_)
		l11llllll1l_l1_ = time.strftime(l11l1l_l1_ (u"࠭ࠥࡉ࠼ࠨࡑࠬ㚽"),struct)
		l1l1111l111_l1_ = time.strftime(l11l1l_l1_ (u"ࠧࠦࡣࠪ㚾"),struct)
		if function==l11l1l_l1_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫ㚿"): title = l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㛀")+l11llllll1l_l1_+l11l1l_l1_ (u"ࠪࠤๅࠦࠧ㛁")+title+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㛂")
		elif function==l11l1l_l1_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨ㛃"): title = l1l1111l111_l1_+l11l1l_l1_ (u"࠭ࠠࠨ㛄")+l11llllll1l_l1_+l11l1l_l1_ (u"ࠧࠡࠪࠪ㛅")+l1l11111lll_l1_+l11l1l_l1_ (u"ࠨ࡯࡬ࡲ࠮࠭㛆")
		else: title = l1l1111l111_l1_+l11l1l_l1_ (u"ࠩࠣࠫ㛇")+l11llllll1l_l1_+l11l1l_l1_ (u"ࠪࠤ࠭࠭㛈")+l1l11111lll_l1_+l11l1l_l1_ (u"ࠫࡲ࡯࡮ࠪࠢࠣࠤࠬ㛉")+title+l11l1l_l1_ (u"ࠬࠦเࠨ㛊")
		if function in [l11l1l_l1_ (u"࠭ࡁࡓࡅࡋࡍ࡛ࡋࡄࠨ㛋"),l11l1l_l1_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩ㛌"),l11l1l_l1_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫ㛍")]:
			l11lll1l111_l1_ = server+l11l1l_l1_ (u"ࠩ࠲ࡸ࡮ࡳࡥࡴࡪ࡬ࡪࡹ࠵ࠧ㛎")+username+l11l1l_l1_ (u"ࠪ࠳ࠬ㛏")+password+l11l1l_l1_ (u"ࠫ࠴࠭㛐")+l1l11111lll_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ㛑")+l1l11ll11l1_l1_+l11l1l_l1_ (u"࠭࠯ࠨ㛒")+l11l1l111ll_l1_+l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭㛓")
			if function==l11l1l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪ㛔"): addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㛕"),l1111l_l1_+title,l11lll1l111_l1_,9999,l1ll1l_l1_,l11l1l_l1_ (u"ࠪࠫ㛖"),l11l1l_l1_ (u"ࠫࠬ㛗"),l11l1l_l1_ (u"ࠬ࠭㛘"),{l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㛙"):l1l11l11l11_l1_})
			else: addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㛚"),l1111l_l1_+title,l11lll1l111_l1_,235,l1ll1l_l1_,l11l1l_l1_ (u"ࠨࠩ㛛"),l11l1l_l1_ (u"ࠩࠪ㛜"),l11l1l_l1_ (u"ࠪࠫ㛝"),{l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㛞"):l1l11l11l11_l1_})
		l11ll1l11l1_l1_.append(title)
	if function==l11l1l_l1_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨ㛟") and l11ll1l11l1_l1_: l1l_l1_ = DIALOG_CONTEXTMENU(l11ll1l11l1_l1_)
	return l11ll1l11l1_l1_
def USE_FASTER_SERVER(l1l11l11l11_l1_):
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,True): return
	server,l11ll111111_l1_,l1l11ll1111_l1_ = l11l1l_l1_ (u"࠭ࠧ㛠"),0,0
	succeeded,l11ll11111l_l1_,l1l11l1l111_l1_ = CHECK_ACCOUNT(l1l11l11l11_l1_,False)
	if succeeded:
		l1l111lllll_l1_ = DNS_RESOLVER(l11ll11111l_l1_)
		l11ll111111_l1_ = PING(l1l111lllll_l1_[0],int(l1l11l1l111_l1_))
		l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉ࠭㛡"))
		groups = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㛢"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㛣"))
		l11lll11ll1_l1_ = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㛤"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㛥"),groups[1])
		url = l11lll11ll1_l1_[0][2]
		l11llllllll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡀ࠯࠰ࠪ࠱࠮ࡄ࠯࠯ࠨ㛦"),url,re.DOTALL)
		l11llllllll_l1_ = l11llllllll_l1_[0]
		if l11l1l_l1_ (u"࠭࠺ࠨ㛧") in l11llllllll_l1_: l11lll1ll11_l1_,l1l111l1l11_l1_ = l11llllllll_l1_.split(l11l1l_l1_ (u"ࠧ࠻ࠩ㛨"))
		else: l11lll1ll11_l1_,l1l111l1l11_l1_ = l11llllllll_l1_,l11l1l_l1_ (u"ࠨ࠺࠳ࠫ㛩")
		l11l1l11lll_l1_ = DNS_RESOLVER(l11lll1ll11_l1_)
		l1l11ll1111_l1_ = PING(l11l1l11lll_l1_[0],int(l1l111l1l11_l1_))
	if l11ll111111_l1_ and l1l11ll1111_l1_:
		message = l11l1l_l1_ (u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ำ๋ำไีࠥอไฤื็๎ࠥษๅࠡษ็ื๏ืแาࠢส่ศูัฺࠢยࠥࠦ࠭㛪")
		message += l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮ࠨ㛫")+l11l1l_l1_ (u"ࠫํ่สุࠡสส฾ࠦแ๋ࠢสุ่๐ัโำࠣห้ษีๅ์ࠪ㛬")+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ㛭")+str(int(l1l11ll1111_l1_*1000))+l11l1l_l1_ (u"࠭ࠠๆๆํࠤะอๆ๋หࠪ㛮")
		message += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲࠬ㛯")+l11l1l_l1_ (u"ࠨ๊ๅฮࠥ฼วว฻ࠣๅ๏ࠦวๅีํีๆืࠠศๆหำ๏๊ࠧ㛰")+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ㛱")+str(int(l11ll111111_l1_*1000))+l11l1l_l1_ (u"ࠪࠤ๊๊๊ࠡอส๊๏ฯࠧ㛲")
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㛳"),l11l1l_l1_ (u"ࠬอไิ์ิๅึࠦวๅลุ่๏࠭㛴"),l11l1l_l1_ (u"࠭วๅีํีๆืࠠศๆฦืึ฿ࠧ㛵"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㛶"),message)
		if l1ll111111_l1_==1 and l11ll111111_l1_<l1l11ll1111_l1_: server = l11ll11111l_l1_+l11l1l_l1_ (u"ࠨ࠼ࠪ㛷")+l1l11l1l111_l1_
	else: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㛸"),l11l1l_l1_ (u"ࠪࠫ㛹"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㛺"),l11l1l_l1_ (u"ࠬอไษำ้ห๊าࠠๅ็ࠣ๎ัีࠠศๆึ๎ึ็ัࠡษ็ฬิ๐ไࠨ㛻"))
	settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡴࡧࡵࡺࡪࡸ࡟ࠨ㛼")+l1l11l11l11_l1_,server)
	return
def PLAY(l1l11l11l11_l1_,url,type):
	l111ll111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㛽")+l1l11l11l11_l1_)
	if l111ll111l_l1_: url = url+l11l1l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧ㛾")+l111ll111l_l1_
	#l11111l1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡶࡩࡷࡼࡥࡳࡡࠪ㛿")+l1l11l11l11_l1_)
	#if l11111l1l1_l1_:
	#	l11llll1ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠭㜀"),url,re.DOTALL)
	#	url = url.replace(l11llll1ll1_l1_[0],l11111l1l1_l1_)
	PLAY_VIDEO(url,l1ll1_l1_,type)
	return
def ADD_USERAGENT(l1l11l11l11_l1_):
	DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㜁"),l11l1l_l1_ (u"ࠬ࠭㜂"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㜃"),l11l1l_l1_ (u"ࠧหฯำ๎ึࠦๅ่็ࠣ์์อๅࠡฮาหࠥ࠴๋ࠠำฯํࠥ฿ฯๆࠢอ฾๏๐ั่ࠢศิฬࠦใ็ฬ่ࠣฬࠦสฺำไࠤ๊อ่๊ࠠࠣ࠲ฺ่ࠥࠦั่ࠤฯเ๊๋ำ๊ࠤส๊วࠡ฻้ำࠥอไืำ๋ีฮࠦวๅไุ์๎ࠦ࠮ࠡษ็ัฬาษࠡๆ๊ิฬࠦวๅฬ฽๎๏ื่ࠠ์ࠣๅ็฽ࠠฦาสࠤ฼๊ศห่๊่ࠢࠦิาๅฬࠤๅࡓ࠳ࡖࠢฦ๊ࠥะูๆๆ๋ࠣีอࠠศๆอ฾๏๐ัࠡ࠰ࠣ์ๆ่ืࠡ฻้ำ๊อࠠหีอาิ๋ࠠฯั่อࠥๆࡍ࠴ࡗࠣฮาะวอࠢใ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠฯษุࠫ㜄"))
	l111ll111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ㜅")+l1l11l11l11_l1_)
	l11l1ll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㜆"),l11l1l_l1_ (u"ࠪหุะฮะษ่ࠤฬ๊รึๆํࠫ㜇"),l11l1l_l1_ (u"ࠫฯ฿ฯ๋ๆࠣห้่ฯ๋็ࠪ㜈"),l111ll111l_l1_,l11l1l_l1_ (u"ࠬํะศ๊ࠢ์ࠥๆࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠣห้๋ำหะา้ࠥำวๅ์สࠤ๊฿ࠠแࡏ࠶࡙ࠥอไั์ࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬ฼ำ๏๊็ࠡล่ࠤฯื๊ะࠢศ฽ฬีส่ࠢศ่๎่ࠦื฻ํอࠥอไหอห๎ฯࠦวๅลุ่๏่ࠦศๆอ๎ࠥะโา์หหࠥะๆศีหࠤัฺ๋๊ࠢืี่อสࠡโࡐ࠷࡚ࠦฟࠢࠩ㜉"))
	if l11l1ll11l1_l1_==1: l111ll111l_l1_ = OPEN_KEYBOARD(l11l1l_l1_ (u"࠭รไฬหࠤๅࡓ࠳ࡖࠢࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦฬะ์าࠫ㜊"),l111ll111l_l1_,True)
	else: l111ll111l_l1_ = l11l1l_l1_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ㜋")
	if l111ll111l_l1_==l11l1l_l1_ (u"ࠨࠢࠪ㜌"):
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㜍"),l11l1l_l1_ (u"ࠪࠫ㜎"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㜏"),l11l1l_l1_ (u"ࠬเ๊า่ࠢื๊๎อࠡลึฮำีวๆࠢไีฬเࠠๅ๊ะำ์ࠦร้ࠢ฼ำฮࠦแาษ฽หฯࠦไ้ฯา๋ฬࠦ࠮࠯࠰ࠣ๎ัฮࠠฦ็สࠤฯืใ่ࠢไหึเࠠห็ส้ฬࠦร้ࠢศฺฬ็ษࠡฯิๅࠥษ่ࠡลํࠤู๐ࠠระิࠤ๊฿็ศࠩ㜐"))
		return
	l11l1ll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㜑"),l11l1l_l1_ (u"ࠧࠨ㜒"),l11l1l_l1_ (u"ࠨࠩ㜓"),l111ll111l_l1_,l11l1l_l1_ (u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤ์ึวࠡโࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦศะๆสࠤ๊์ࠠࠡษ็ๆิ๐ๅࠡมࠪ㜔"))
	if l11l1ll11l1_l1_!=1:
		DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㜕"),l11l1l_l1_ (u"ࠫࠬ㜖"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㜗"),l11l1l_l1_ (u"࠭สๆࠢส่สฺ๊ศรࠪ㜘"))
		return
	settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱ࠸ࡻ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫ㜙")+l1l11l11l11_l1_,l111ll111l_l1_)
	l1l1111l11l_l1_(l1l11l11l11_l1_)
	return
def GET_URL(l1l11l11l11_l1_,l11l1lll11l_l1_=l11l1l_l1_ (u"ࠨࠩ㜚")):
	if not l11l1lll11l_l1_: l11l1lll11l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯ࡰࡵࡸ࠱ࡹࡷࡲ࡟ࠨ㜛")+l1l11l11l11_l1_)
	server = SERVER(l11l1lll11l_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ㜜"))
	username = re.findall(l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪࡃࠨ࠯ࠬࡂ࠭ࠫ࠭㜝"),l11l1lll11l_l1_+l11l1l_l1_ (u"ࠬࠬࠧ㜞"),re.DOTALL)
	password = re.findall(l11l1l_l1_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨ㜟"),l11l1lll11l_l1_+l11l1l_l1_ (u"ࠧࠧࠩ㜠"),re.DOTALL)
	if not username or not password:
		DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㜡"),l11l1l_l1_ (u"ࠩࠪ㜢"),l11l1l_l1_ (u"ࠪๅา฻ࠠศึอีฬ้ࠠแࡋࡓࡘ࡛࠭㜣"),l11l1l_l1_ (u"ࠫึอศุࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡษ็ิ๏ࠦโๆฬࠣห๋ะࠠษวูหๆะ็ࠡว็ํࠥอไษำ้ห๊าࠠๅษࠣ๎฾๋ไࠡล๋ࠤฬ๊ัศสฺࠤ฿๐ัࠡ็๋ะํีࠠโ์ࠣห้ฮั็ษ่ะࠥ࠴ࠠฤา๊ฬࠥหไ๊ࠢๅหห๋ษࠡษืฮึอใࠡโࡌࡔ࡙࡜้ࠠไ่ࠤอหึศใฬࠤึอศุࠢใࡍࡕ࡚ࡖࠡฮา๎ิࠦร้ࠢๅ้ࠥฮลึๆสัࠥอไาษห฻ࠥอไใัํ้ࠬ㜤"))
		return l11l1l_l1_ (u"ࠬ࠭㜥"),l11l1l_l1_ (u"࠭ࠧ㜦"),l11l1l_l1_ (u"ࠧࠨ㜧"),l11l1l_l1_ (u"ࠨࠩ㜨"),l11l1l_l1_ (u"ࠩࠪ㜩")
	username = username[0]
	password = password[0]
	l11l1ll1ll1_l1_ = server+l11l1l_l1_ (u"ࠪ࠳ࡵࡲࡡࡺࡧࡵࡣࡦࡶࡩ࠯ࡲ࡫ࡴࡄࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠨ㜪")+username+l11l1l_l1_ (u"ࠫࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠨ㜫")+password
	l11ll1lll1l_l1_ = server+l11l1l_l1_ (u"ࠬ࠵ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࡶࡵࡨࡶࡳࡧ࡭ࡦ࠿ࠪ㜬")+username+l11l1l_l1_ (u"࠭ࠦࡱࡣࡶࡷࡼࡵࡲࡥ࠿ࠪ㜭")+password+l11l1l_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃ࡭࠴ࡷࡢࡴࡱࡻࡳࠨ㜮")
	return l11l1ll1ll1_l1_,l11ll1lll1l_l1_,server,username,password
def GET_FILENAME(l1l11l11l11_l1_,l1l111llll1_l1_=l11l1l_l1_ (u"ࠨࠩ㜯")):
	l11lll1llll_l1_ = l1l111llll1_l1_.replace(l11l1l_l1_ (u"ࠩ࠲ࠫ㜰"),l11l1l_l1_ (u"ࠪࡣࠬ㜱")).replace(l11l1l_l1_ (u"ࠫ࠿࠭㜲"),l11l1l_l1_ (u"ࠬࡥࠧ㜳")).replace(l11l1l_l1_ (u"࠭࠮ࠨ㜴"),l11l1l_l1_ (u"ࠧࡠࠩ㜵"))
	l11lll1llll_l1_ = l11lll1llll_l1_.replace(l11l1l_l1_ (u"ࠨࡁࠪ㜶"),l11l1l_l1_ (u"ࠩࡢࠫ㜷")).replace(l11l1l_l1_ (u"ࠪࡁࠬ㜸"),l11l1l_l1_ (u"ࠫࡤ࠭㜹")).replace(l11l1l_l1_ (u"ࠬࠬࠧ㜺"),l11l1l_l1_ (u"࠭࡟ࠨ㜻"))
	l11lll1llll_l1_ = os.path.join(addoncachefolder,l11lll1llll_l1_).strip(l11l1l_l1_ (u"ࠧ࠯࡯࠶ࡹࠬ㜼"))+l11l1l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠭㜽")
	return l11lll1llll_l1_
def ADD_ACCOUNT(l1l11l11l11_l1_,l111l111_l1_):
	l1l111111ll_l1_ = l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㜾")
	if l111l111_l1_: l1l111111ll_l1_ = l11l1l_l1_ (u"ࠪษ฻อแส๋ࠢฮ฿๐๊าࠢิหอ฽ࠠࠨ㜿")+text_numbers[int(l111l111_l1_)]
	l11l1ll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㝀"),l11l1l_l1_ (u"ࠬ࠭㝁"),l11l1l_l1_ (u"࠭ࠧ㝂"),l1l111111ll_l1_,l11l1l_l1_ (u"่ࠧาสࠤฬ๊ฬำร้๋ࠣࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠาษห฻ࠥ็๊ะ์๋๋ฬะࠠๆ่ࠣห้หๆหำ้ฮࠥษ่ࠡลืฮึอใࠡ็าๅํ฿ࠠๆ่ࠣหฺ้ัไษอࠤฬ๊ส๋ࠢอฬ๏฿็๊ࠡส่ึอศุ่๊ࠢࠥ์ฺ่ࠢ࡟ࡲࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࡮࠵ࡸ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡢ࡮࡝ࡰࠣ์์ึวࠡ็ฮห้ࠦไหู๊๎าࠦิไๆ๋ࠣีอࠠศๆิหอ฽ࠠ࡝ࡰࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡶࡴࡷ࠯ࡲࡶ࡬࠴ࡧࡪࡶ࡫ࡹࡧ࠴ࡩࡰ࠱࡬ࡴࡹࡼ࠯࡭ࡣࡱ࡫ࡺࡧࡧࡦࡵ࠲ࡥࡷࡧ࠮࡮࠵ࡸࠤࡡࡴ่ࠠๆࠣฮึ๐ฯࠡวูหๆฯࠠฤ๊ࠣฮ฿๐๊าࠢฦ์๋ࠥำฮࠢส่ึอศุࠢส่ว์ࠠภࠩ㝃"))
	if l11l1ll11l1_l1_!=1: return
	l1l111ll1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡵࡰࡤ࠭㝄")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠩࡢࠫ㝅")+l111l111_l1_)
	l1l111ll1ll_l1_ = True
	if l1l111ll1l1_l1_:
		l11l1ll11l1_l1_ = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㝆"),l11l1l_l1_ (u"่ࠫะวษหࠣะิ๐ฯࠨ㝇"),l11l1l_l1_ (u"ࠬะูะ์็ࠤฬ๊โะ์่ࠫ㝈"),l11l1l_l1_ (u"࠭ๅิฯࠣห้่ฯ๋็ࠪ㝉"),l11l1l_l1_ (u"ࠧศๆิหอ฽ࠠศๆะห้๐่๊ࠠ࠽ࠫ㝊"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㝋")+l1l111ll1l1_l1_+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㝌")+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮้ࠡำหࠥํ่ࠡำสฬ฼ࠦเࡎ࠵ࡘࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠห฻า๎้ํࠠฤ็ࠣฮึ๐ฯࠡๅอหอฯࠠาษห฻ࠥาฯ๋ัࠣรࠦ࠭㝍"))
		if l11l1ll11l1_l1_==-1: return
		elif l11l1ll11l1_l1_==0: l1l111ll1l1_l1_ = l11l1l_l1_ (u"ࠫࠬ㝎")
		elif l11l1ll11l1_l1_==2:
			l11l1ll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ㝏"),l11l1l_l1_ (u"࠭ࠧ㝐"),l11l1l_l1_ (u"ࠧࠨ㝑"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㝒"),l11l1l_l1_ (u"๊่ࠩࠥะั๋ัุ้ࠣำࠠศๆิหอ฽ࠠศๆ่ืั๊ࠠโ์ࠣห้ฮั็ษ่ะࠥลࠡࠨ㝓"))
			if l11l1ll11l1_l1_ in [-1,0]: return
			DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㝔"),l11l1l_l1_ (u"ࠫࠬ㝕"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㝖"),l11l1l_l1_ (u"࠭สๆ่ࠢืาࠦวๅำสฬ฼࠭㝗"))
			l1l111ll1ll_l1_ = False
			l11ll1l11ll_l1_ = l11l1l_l1_ (u"ࠧࠨ㝘")
	if l1l111ll1ll_l1_:
		l11ll1l11ll_l1_ = OPEN_KEYBOARD(l11l1l_l1_ (u"ࠨษๆฮอࠦัศสฺࠤๅࡓ࠳ࡖࠢๆห๊๊วࠨ㝙"),l1l111ll1l1_l1_)
		l11ll1l11ll_l1_ = l11ll1l11ll_l1_.strip(l11l1l_l1_ (u"ࠩࠣࠫ㝚"))
		if not l11ll1l11ll_l1_:
			l11l1ll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ㝛"),l11l1l_l1_ (u"ࠫࠬ㝜"),l11l1l_l1_ (u"ࠬ࠭㝝"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㝞"),l11l1l_l1_ (u"ࠧๅไาࠤ็๋สࠡสศำำอไࠡำสฬ฼ࠦแศำ฽ࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥอไาษห฻ࠥอไๆีฯ่ࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠦ࠭㝟"))
			if l11l1ll11l1_l1_ in [-1,0]: return
			DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㝠"),l11l1l_l1_ (u"ࠩࠪ㝡"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㝢"),l11l1l_l1_ (u"ࠫฯ๋ࠠๆีะࠤฬ๊ัศสฺࠫ㝣"))
		else:
			#l11l1ll1ll1_l1_,l11ll1lll1l_l1_,server,username,password = GET_URL(l1l11l11l11_l1_)
			#if not username: return
			message = l11l1l_l1_ (u"ࠬํะ่ࠢส่๊฿ไ้็สฮࠥะๅࠡลัิ์อࠠๆ่ࠣีฬฮืࠡโࡐ࠷࡚ࠦวๅาํࠤฬ์สࠡๅอฬฯํࠠ࠯๊่ࠢࠥะั๋ัࠣหุะฮะษ่๋ฬࠦฟࠢ࡞ࡱࠫ㝤")
			#message += l11l1l_l1_ (u"࠭࡜࡯࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㝥")+server+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞฻้์ฬ์ࠠศๆึ๎ึ็ั࠻ࠢࠪ㝦")
			#message += l11l1l_l1_ (u"ࠨ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭㝧")+username+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠหุ๋ࠠศๆ่ืฯิฯๆ࠼ࠣࠫ㝨")
			#message += l11l1l_l1_ (u"ࠪࡠࡳࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠨ㝩")+password+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ้ไๆหࠣหู้ั࠻ࠢࠪ㝪")
			l11l1ll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬ࠭㝫"),l11l1l_l1_ (u"࠭ࠧ㝬"),l11l1l_l1_ (u"ࠧࠨ㝭"),l11l1l_l1_ (u"ࠨษ็ีฬฮืࠡษ็ะิ๐ฯ้๋ࠡ࠾ࠬ㝮"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㝯")+l11ll1l11ll_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㝰")+l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㝱")+message)
			if l11l1ll11l1_l1_!=1:
				DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㝲"),l11l1l_l1_ (u"࠭ࠧ㝳"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㝴"),l11l1l_l1_ (u"ࠨฬ่ࠤฬ๊ลๅ฼สลࠬ㝵"))
				return
	settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡶࡱࡥࠧ㝶")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠪࡣࠬ㝷")+l111l111_l1_,l11ll1l11ll_l1_)
	#settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡪࡲࡷࡺ࠳ࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࡠࠩ㝸")+l1l11l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭㝹"))
	#settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡬ࡴࡹࡼ࠮ࡵ࡫ࡰࡩࡩ࡯ࡦࡧࡡࠪ㝺")+l1l11l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ㝻"))
	l111ll111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡲ࠹ࡵ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷࡣࠬ㝼")+l1l11l11l11_l1_)
	if not l111ll111l_l1_: settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭㝽")+l1l11l11l11_l1_,l11l1l_l1_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠫ㝾"))
	#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㝿"),l11l1l_l1_ (u"ࠬ࠭㞀"),l11l1l_l1_ (u"࠭ࠧ㞁"),l11l1l_l1_ (u"ࠧࠨ㞂"),l11ll1l11ll_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳะๅࠡฬ฽๎ึࠦัศสฺࠤฬฺสาษๆࠤๅࡓ࠳ࡖࠢศ่๎ࠦ็ัษࠣห้ืวษูࠣห้าฯ๋ัࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥํะศࠢส่ึอศุࠢส่ว์ࠠภࠩ㞃"))
	#if l1ll111111_l1_==1: ok,l11ll11111l_l1_,l1l11l1l111_l1_ = CHECK_ACCOUNT(l1l11l11l11_l1_,True)
	l1l1111l11l_l1_(l1l11l11l11_l1_)
	return
def READ_ALL_LINES(lines,l1l111lll1l_l1_,l11lll1ll1l_l1_,l11l11ll1l_l1_,length,l11llll11l1_l1_,l11ll1lll1l_l1_):
	l11lll11ll1_l1_,l11l1l1ll1l_l1_ = [],[]
	l11l1ll1lll_l1_ = [l11l1l_l1_ (u"ࠩ࠱ࡥࡻ࡯ࠧ㞄"),l11l1l_l1_ (u"ࠪ࠲ࡲࡶ࠴ࠨ㞅"),l11l1l_l1_ (u"ࠫ࠳ࡳ࡫ࡷࠩ㞆"),l11l1l_l1_ (u"ࠬ࠴ࡦ࡭ࡸࠪ㞇"),l11l1l_l1_ (u"࠭࠮࡮ࡲ࠶ࠫ㞈"),l11l1l_l1_ (u"ࠧ࠯ࡹࡨࡦࡲ࠭㞉")]
	for line in lines:
		if l11llll11l1_l1_%473==0:
			PROGRESS_UPDATE(l11l11ll1l_l1_,40+int(10*l11llll11l1_l1_/length),l11l1l_l1_ (u"ࠨไิหฦฯࠠศๆไ๎ิ๐่่ษอࠫ㞊"),l11l1l_l1_ (u"ࠩส่ๆ๐ฯ๋๊ࠣี็๋࠺࠮ࠩ㞋"),str(l11llll11l1_l1_)+l11l1l_l1_ (u"ࠪࠤ࠴ࠦࠧ㞌")+str(length))
			if l11l11ll1l_l1_.iscanceled():
				l11l11ll1l_l1_.close()
				return None,None,None
		if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ㞍") in line:
			line,url = line.rsplit(l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ㞎"),1)
			url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ㞏")+url
		elif l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ㞐") in line:
			line,url = line.rsplit(l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ㞑"),1)
			url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ㞒")+url
		elif l11l1l_l1_ (u"ࠪࡶࡹࡳࡰ࠻ࠩ㞓") in line:
			line,url = line.rsplit(l11l1l_l1_ (u"ࠫࡷࡺ࡭ࡱ࠼ࠪ㞔"),1)
			url = l11l1l_l1_ (u"ࠬࡸࡴ࡮ࡲ࠽ࠫ㞕")+url
		else:
			l11l1l1ll1l_l1_.append({l11l1l_l1_ (u"࠭࡬ࡪࡰࡨࠫ㞖"):line})
			continue
		l1l1111111l_l1_,context,group,title,type,l11lllll1l1_l1_ = {},l11l1l_l1_ (u"ࠧࠨ㞗"),l11l1l_l1_ (u"ࠨࠩ㞘"),l11l1l_l1_ (u"ࠩࠪ㞙"),l11l1l_l1_ (u"ࠪࠫ㞚"),False
		try:
			line,title = line.rsplit(l11l1l_l1_ (u"ࠫࠧ࠲ࠧ㞛"),1)
			line = line+l11l1l_l1_ (u"ࠬࠨࠧ㞜")
		except:
			try: line,title = line.rsplit(l11l1l_l1_ (u"࠭࠱࠭ࠩ㞝"),1)
			except: title = l11l1l_l1_ (u"ࠧࠨ㞞")
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ㞟")] = url
		params = re.findall(l11l1l_l1_ (u"ࠩࠣࠬ࠳࠰࠿ࠪ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㞠"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l11l1l_l1_ (u"ࠪࠦࠬ㞡"),l11l1l_l1_ (u"ࠫࠬ㞢")).strip(l11l1l_l1_ (u"ࠬࠦࠧ㞣"))
			l1l1111111l_l1_[key] = value.strip(l11l1l_l1_ (u"࠭ࠠࠨ㞤"))
		keys = list(l1l1111111l_l1_.keys())
		if not title:
			if l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ㞥") in keys and l1l1111111l_l1_[l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭㞦")]: title = l1l1111111l_l1_[l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ㞧")]
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㞨")] = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭㞩")).replace(l11l1l_l1_ (u"ࠬࠦࠠࠨ㞪"),l11l1l_l1_ (u"࠭ࠠࠨ㞫")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ㞬"),l11l1l_l1_ (u"ࠨࠢࠪ㞭"))
		if l11l1l_l1_ (u"ࠩ࡯ࡳ࡬ࡵࠧ㞮") in keys:
			l1l1111111l_l1_[l11l1l_l1_ (u"ࠪ࡭ࡲ࡭ࠧ㞯")] = l1l1111111l_l1_[l11l1l_l1_ (u"ࠫࡱࡵࡧࡰࠩ㞰")]
			del l1l1111111l_l1_[l11l1l_l1_ (u"ࠬࡲ࡯ࡨࡱࠪ㞱")]
		else: l1l1111111l_l1_[l11l1l_l1_ (u"࠭ࡩ࡮ࡩࠪ㞲")] = l11l1l_l1_ (u"ࠧࠨ㞳")
		if l11l1l_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㞴") in keys and l1l1111111l_l1_[l11l1l_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ㞵")]: group = l1l1111111l_l1_[l11l1l_l1_ (u"ࠪ࡫ࡷࡵࡵࡱࠩ㞶")]
		if any(value in url.lower() for value in l11l1ll1lll_l1_): l11lllll1l1_l1_ = True
		if l11lllll1l1_l1_ or l11l1l_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㞷") in group or l11l1l_l1_ (u"ࠬࡥ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡠࠩ㞸") in group:
			type = l11l1l_l1_ (u"࠭ࡖࡐࡆࠪ㞹")
			if l11l1l_l1_ (u"ࠧࡠࡡࡖࡉࡗࡏࡅࡔࡡࡢࠫ㞺") in group: type = type+l11l1l_l1_ (u"ࠨࡡࡖࡉࡗࡏࡅࡔࠩ㞻")
			elif l11l1l_l1_ (u"ࠩࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭㞼") in group: type = type+l11l1l_l1_ (u"ࠪࡣࡒࡕࡖࡊࡇࡖࠫ㞽")
			else: type = type+l11l1l_l1_ (u"ࠫࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭㞾")
			group = group.replace(l11l1l_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ㞿"),l11l1l_l1_ (u"࠭ࠧ㟀")).replace(l11l1l_l1_ (u"ࠧࡠࡡࡐࡓ࡛ࡏࡅࡔࡡࡢࠫ㟁"),l11l1l_l1_ (u"ࠨࠩ㟂"))
		else:
			type = l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ㟃")
			if title in l1l111lll1l_l1_: context = context+l11l1l_l1_ (u"ࠪࡣࡊࡖࡇࠨ㟄")
			if title in l11lll1ll1l_l1_: context = context+l11l1l_l1_ (u"ࠫࡤࡇࡒࡄࡊࡌ࡚ࡊࡊࠧ㟅")
			if not group: type = type+l11l1l_l1_ (u"ࠬࡥࡕࡏࡍࡑࡓ࡜ࡔࠧ㟆")
			else: type = type+context
		group = group.strip(l11l1l_l1_ (u"࠭ࠠࠨ㟇")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ㟈"),l11l1l_l1_ (u"ࠨࠢࠪ㟉")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ㟊"),l11l1l_l1_ (u"ࠪࠤࠬ㟋"))
		if l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࠪ㟌") in type: group = l11l1l_l1_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡐࡎ࡜ࡅࡠࡡࠤࠥࠬ㟍")
		elif l11l1l_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫ㟎") in type: group = l11l1l_l1_ (u"ࠧࠢࠣࡢࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤ࡜ࡏࡅࡡࡢࠥࠦ࠭㟏")
		elif l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࠬ㟐") in type:
			l1l111ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࡝ࡖࡷࡢࡢࡤࠬࠢ࠮࡟ࡊ࡫࡝࡝ࡦ࠮ࠫ㟑"),l1l1111111l_l1_[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㟒")],re.DOTALL)
			if l1l111ll111_l1_: l1l111ll111_l1_ = l1l111ll111_l1_[0]
			else: l1l111ll111_l1_ = l11l1l_l1_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡖࡉࡗࡏࡅࡔࡡࡢࠥࠦ࠭㟓")
			group = group+l11l1l_l1_ (u"ࠬࡥ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ㟔")+l1l111ll111_l1_
		l11ll1l1l1_l1_ = l11l1l_l1_ (u"࠭ࠧ㟕")
		if l11l1l_l1_ (u"ࠧࡪࡦࠪ㟖") in keys:
			l11ll1l1l1_l1_ = l1l1111111l_l1_[l11l1l_l1_ (u"ࠨ࡫ࡧࠫ㟗")]
			del l1l1111111l_l1_[l11l1l_l1_ (u"ࠩ࡬ࡨࠬ㟘")]
		if l11l1l_l1_ (u"ࠪࡍࡉ࠭㟙") in keys:
			l11ll1l1l1_l1_ = l1l1111111l_l1_[l11l1l_l1_ (u"ࠫࡎࡊࠧ㟚")]
			del l1l1111111l_l1_[l11l1l_l1_ (u"ࠬࡏࡄࠨ㟛")]
		if l11l1l_l1_ (u"࠭ࡩࡱࡶࡹ࠱ࡴࡸࡧࠨ㟜") in l11ll1lll1l_l1_ and l11l1l_l1_ (u"ࠧ࠯ࠩ㟝") in l11ll1l1l1_l1_:
			l11ll1l1l1_l1_ = l11ll1l1l1_l1_.rsplit(l11l1l_l1_ (u"ࠨ࠰ࠪ㟞"),1)[1]
			l11ll1l1l1_l1_ = l11l1l_l1_ (u"ࠩࡿࠫ㟟")+l11ll1l1l1_l1_.upper()+l11l1l_l1_ (u"ࠪࢀࠥ࠭㟠")
		if l11l1l_l1_ (u"ࠫࡳࡧ࡭ࡦࠩ㟡") in keys: del l1l1111111l_l1_[l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ㟢")]
		title = l11ll1l1l1_l1_+l1l1111111l_l1_[l11l1l_l1_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㟣")]
		title = escapeUNICODE(title)
		title = CLEAN_NAME(title)
		language,group = SPLIT_NAME(group)
		l11lll1l1ll_l1_,title = SPLIT_NAME(title)
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠧࡵࡻࡳࡩࠬ㟤")] = type
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ㟥")] = context
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ㟦")] = group.upper()
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㟧")] = title.upper()
		try: l1l1111111l_l1_[l11l1l_l1_ (u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࠬ㟨")] = COUNTRIES_CODES[l11lll1l1ll_l1_.upper()]
		except: l1l1111111l_l1_[l11l1l_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭㟩")] = l11lll1l1ll_l1_.upper()
		#dictt1[l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㟪")] = countryy.upper()
		l1l1111111l_l1_[l11l1l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ㟫")] = language.upper()
		l11lll11ll1_l1_.append(l1l1111111l_l1_)
		l11llll11l1_l1_ += 1
	return l11lll11ll1_l1_,l11llll11l1_l1_,l11l1l1ll1l_l1_
def CLEAN_NAME(title):
	title = title.replace(l11l1l_l1_ (u"ࠨࠢࠣࠫ㟬"),l11l1l_l1_ (u"ࠩࠣࠫ㟭")).replace(l11l1l_l1_ (u"ࠪࠤࠥ࠭㟮"),l11l1l_l1_ (u"ࠫࠥ࠭㟯")).replace(l11l1l_l1_ (u"ࠬࠦࠠࠨ㟰"),l11l1l_l1_ (u"࠭ࠠࠨ㟱"))
	title = title.replace(l11l1l_l1_ (u"ࠧࡽࡾࠪ㟲"),l11l1l_l1_ (u"ࠨࡾࠪ㟳")).replace(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭㟴"),l11l1l_l1_ (u"ࠪ࠾ࠬ㟵")).replace(l11l1l_l1_ (u"ࠫ࠲࠳ࠧ㟶"),l11l1l_l1_ (u"ࠬ࠳ࠧ㟷"))
	title = title.replace(l11l1l_l1_ (u"࡛࠭࡜ࠩ㟸"),l11l1l_l1_ (u"ࠧ࡜ࠩ㟹")).replace(l11l1l_l1_ (u"ࠨ࡟ࡠࠫ㟺"),l11l1l_l1_ (u"ࠩࡠࠫ㟻"))
	title = title.replace(l11l1l_l1_ (u"ࠪࠬ࠭࠭㟼"),l11l1l_l1_ (u"ࠫ࠭࠭㟽")).replace(l11l1l_l1_ (u"ࠬ࠯ࠩࠨ㟾"),l11l1l_l1_ (u"࠭ࠩࠨ㟿"))
	title = title.replace(l11l1l_l1_ (u"ࠧ࠽࠾ࠪ㠀"),l11l1l_l1_ (u"ࠨ࠾ࠪ㠁")).replace(l11l1l_l1_ (u"ࠩࡁࡂࠬ㠂"),l11l1l_l1_ (u"ࠪࡂࠬ㠃"))
	title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭㠄"))
	return title
def CREATE_GROUPED_STREAMS(l11ll1l1ll1_l1_,l11l11ll1l_l1_,l111l111_l1_):
	l11lll1lll1_l1_ = {}
	for l11ll1l1l_l1_ in l11lll1111l_l1_: l11lll1lll1_l1_[l11ll1l1l_l1_+l11l1l_l1_ (u"ࠬࡥࠧ㠅")+l111l111_l1_] = []
	length = len(l11ll1l1ll1_l1_)
	l1l1l111ll_l1_ = str(length)
	l11llll11l1_l1_ = 0
	l11l1l1ll1l_l1_ = []
	for l1l1111111l_l1_ in l11ll1l1ll1_l1_:
		if l11llll11l1_l1_%873==0:
			PROGRESS_UPDATE(l11l11ll1l_l1_,50+int(5*l11llll11l1_l1_/length),l11l1l_l1_ (u"࠭สึ่ํๅࠥอไโ์า๎ํํวหࠢส่฿๐ัࠡ็ิฮอฯࠧ㠆"),l11l1l_l1_ (u"ࠧศๆไ๎ิ๐่ࠡำๅ้࠿࠳ࠧ㠇"),str(l11llll11l1_l1_)+l11l1l_l1_ (u"ࠨࠢ࠲ࠤࠬ㠈")+l1l1l111ll_l1_)
			if l11l11ll1l_l1_.iscanceled():
				l11l11ll1l_l1_.close()
				return None,None
		group,context,title,url,l1ll1l_l1_ = l1l1111111l_l1_[l11l1l_l1_ (u"ࠩࡪࡶࡴࡻࡰࠨ㠉")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ㠊")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㠋")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ㠌")],l1l1111111l_l1_[l11l1l_l1_ (u"࠭ࡩ࡮ࡩࠪ㠍")]
		l11lll1l1ll_l1_,language,l11ll1l1l_l1_ = l1l1111111l_l1_[l11l1l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ㠎")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ㠏")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠩࡷࡽࡵ࡫ࠧ㠐")]
		l1l111l11l1_l1_ = (group,context,title,url,l1ll1l_l1_)
		l1lll111lll_l1_ = False
		if l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࠨ㠑") in l11ll1l1l_l1_:
			if l11l1l_l1_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒࠬ㠒") in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࠭㠓")+l111l111_l1_].append(l1l111l11l1_l1_)
			elif l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࠫ㠔") in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ㠕")+l111l111_l1_].append(l1l111l11l1_l1_)
			else: l1lll111lll_l1_ = True
			l11lll1lll1_l1_[l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ㠖")+l111l111_l1_].append(l1l111l11l1_l1_)
		elif l11l1l_l1_ (u"࡙ࠩࡓࡉ࠭㠗") in l11ll1l1l_l1_:
			if l11l1l_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ㠘") in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࠫ㠙")+l111l111_l1_].append(l1l111l11l1_l1_)
			elif l11l1l_l1_ (u"ࠬࡓࡏࡗࡋࡈࡗࠬ㠚") in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡑࡔ࡜ࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࠬ㠛")+l111l111_l1_].append(l1l111l11l1_l1_)
			elif l11l1l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙ࠧ㠜") in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࠧ㠝")+l111l111_l1_].append(l1l111l11l1_l1_)
			else: l1lll111lll_l1_ = True
			l11lll1lll1_l1_[l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࠪ㠞")+l111l111_l1_].append(l1l111l11l1_l1_)
		else: l1lll111lll_l1_ = True
		if l1lll111lll_l1_: l11l1l1ll1l_l1_.append(l1l1111111l_l1_)
		l11llll11l1_l1_ += 1
	l11lll11l1l_l1_ = sorted(l11ll1l1ll1_l1_,reverse=False,key=lambda key: key[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㠟")].lower())
	del l11ll1l1ll1_l1_
	l1l1l111ll_l1_ = str(length)
	l11llll11l1_l1_ = 0
	for l1l1111111l_l1_ in l11lll11l1l_l1_:
		l11llll11l1_l1_ += 1
		if l11llll11l1_l1_%873==0:
			PROGRESS_UPDATE(l11l11ll1l_l1_,55+int(5*l11llll11l1_l1_/length),l11l1l_l1_ (u"ࠫฯ฻ๆ๋ใࠣห้็๊ะ์๋๋ฬะࠠศๆ่ีฯฮษࠨ㠠"),l11l1l_l1_ (u"ࠬอไโ์า๎ํࠦัใ็࠽࠱ࠬ㠡"),str(l11llll11l1_l1_)+l11l1l_l1_ (u"࠭ࠠ࠰ࠢࠪ㠢")+l1l1l111ll_l1_)
			if l11l11ll1l_l1_.iscanceled():
				l11l11ll1l_l1_.close()
				return None,None
		l11ll1l1l_l1_ = l1l1111111l_l1_[l11l1l_l1_ (u"ࠧࡵࡻࡳࡩࠬ㠣")]
		group,context,title,url,l1ll1l_l1_ = l1l1111111l_l1_[l11l1l_l1_ (u"ࠨࡩࡵࡳࡺࡶࠧ㠤")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ㠥")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㠦")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ㠧")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠬ࡯࡭ࡨࠩ㠨")]
		l11lll1l1ll_l1_,language = l1l1111111l_l1_[l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ㠩")],l1l1111111l_l1_[l11l1l_l1_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ㠪")]
		l1l111l11ll_l1_ = (group,context+l11l1l_l1_ (u"ࠨࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬ㠫"),title,url,l1ll1l_l1_)
		l1l111l11l1_l1_ = (group,context,title,url,l1ll1l_l1_)
		l1l111l111l_l1_ = (l11lll1l1ll_l1_,context,title,url,l1ll1l_l1_)
		l1l111l1111_l1_ = (language,context,title,url,l1ll1l_l1_)
		if l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࠧ㠬") in l11ll1l1l_l1_:
			if l11l1l_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑࠫ㠭") in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ㠮")+l111l111_l1_].append(l1l111l11l1_l1_)
			else: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ㠯")+l111l111_l1_].append(l1l111l11l1_l1_)
			if l11l1l_l1_ (u"࠭ࡅࡑࡉࠪ㠰")		in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ㠱")+l111l111_l1_].append(l1l111l11l1_l1_)
			if l11l1l_l1_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪ㠲")	in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡂࡔࡆࡌࡎ࡜ࡅࡅࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࡢࠫ㠳")+l111l111_l1_].append(l1l111l11l1_l1_)
			if l11l1l_l1_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬ㠴")	in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉࡥࠧ㠵")+l111l111_l1_].append(l1l111l11ll_l1_)
			l11lll1lll1_l1_[l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉࡥࠧ㠶")+l111l111_l1_].append(l1l111l111l_l1_)
			l11lll1lll1_l1_[l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ㠷")+l111l111_l1_].append(l1l111l1111_l1_)
		elif l11l1l_l1_ (u"ࠧࡗࡑࡇࠫ㠸") in l11ll1l1l_l1_:
			if   l11l1l_l1_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩ㠹")	in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࡠࠩ㠺")+l111l111_l1_].append(l1l111l11l1_l1_)
			elif l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪ㠻")	in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㠼")+l111l111_l1_].append(l1l111l11l1_l1_)
			elif l11l1l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ㠽")	in l11ll1l1l_l1_: l11lll1lll1_l1_[l11l1l_l1_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࡣࠬ㠾")+l111l111_l1_].append(l1l111l11l1_l1_)
			l11lll1lll1_l1_[l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊ࡟ࠨ㠿")+l111l111_l1_].append(l1l111l111l_l1_)
			l11lll1lll1_l1_[l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡋࡗࡕࡕࡑࡡࡖࡓࡗ࡚ࡅࡅࡡࠪ㡀")+l111l111_l1_].append(l1l111l1111_l1_)
	return l11lll1lll1_l1_,l11l1l1ll1l_l1_
def SPLIT_NAME(title):
	if len(title)<3: return title,title
	l1ll1l111l1_l1_,sep = l11l1l_l1_ (u"ࠩࠪ㡁"),l11l1l_l1_ (u"ࠪࠫ㡂")
	l1lll11l1_l1_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l11l1l_l1_ (u"ࠫ࠭࠭㡃"): sep = l11l1l_l1_ (u"ࠬ࠯ࠧ㡄")
	elif first==l11l1l_l1_ (u"࡛࠭ࠨ㡅"): sep = l11l1l_l1_ (u"ࠧ࡞ࠩ㡆")
	elif first==l11l1l_l1_ (u"ࠨ࠾ࠪ㡇"): sep = l11l1l_l1_ (u"ࠩࡁࠫ㡈")
	elif first==l11l1l_l1_ (u"ࠪࢀࠬ㡉"): sep = l11l1l_l1_ (u"ࠫࢁ࠭㡊")
	if sep and (sep in rest):
		l11l1lll111_l1_,l11l1l111l1_l1_ = rest.split(sep,1)
		l1ll1l111l1_l1_ = l11l1lll111_l1_
		l1lll11l1_l1_ = first+l11l1lll111_l1_+sep+l11l1l_l1_ (u"ࠬࠦࠧ㡋")+l11l1l111l1_l1_
	elif title.count(l11l1l_l1_ (u"࠭ࡼࠨ㡌"))>=2:
		l11l1lll111_l1_,l11l1l111l1_l1_ = title.split(l11l1l_l1_ (u"ࠧࡽࠩ㡍"),1)
		l1ll1l111l1_l1_ = l11l1lll111_l1_
		l1lll11l1_l1_ = l11l1lll111_l1_+l11l1l_l1_ (u"ࠨࠢࡿࠫ㡎")+l11l1l111l1_l1_
	else:
		sep = re.findall(l11l1l_l1_ (u"ࠩࡡࡠࡼࢁ࠲ࡾࠪࠣࢀࡡࡀࡼ࡝࠯ࡿࡠࢁࢂ࡜࡞ࡾ࡟࠭ࢁࡢࠣࡽ࡞࠱ࢀࡡ࠲ࡼ࡝ࠦࡿࡠࠬࢂ࡜ࠢࡾ࡟ࡄࢁࡢࠥࡽ࡞ࠩࢀࡡ࠰ࡼ࡝ࡠࠬࠫ㡏"),title,re.DOTALL)
		if not sep: sep = re.findall(l11l1l_l1_ (u"ࠪࡢࡡࡽࡻ࠴ࡿࠫࠤࢁࡢ࠺ࡽ࡞࠰ࢀࡡࢂࡼ࡝࡟ࡿࡠ࠮ࢂ࡜ࠤࡾ࡟࠲ࢁࡢࠬࡽ࡞ࠧࢀࡡ࠭ࡼ࡝ࠣࡿࡠࡅࢂ࡜ࠦࡾ࡟ࠪࢁࡢࠪࡽ࡞ࡡ࠭ࠬ㡐"),title,re.DOTALL)
		if not sep: sep = re.findall(l11l1l_l1_ (u"ࠫࡣࡢࡷࡼ࠶ࢀࠬࠥࢂ࡜࠻ࡾ࡟࠱ࢁࡢࡼࡽ࡞ࡠࢀࡡ࠯ࡼ࡝ࠥࡿࡠ࠳ࢂ࡜࠭ࡾ࡟ࠨࢁࡢࠧࡽ࡞ࠤࢀࡡࡆࡼ࡝ࠧࡿࡠࠫࢂ࡜ࠫࡾ࡟ࡢ࠮࠭㡑"),title,re.DOTALL)
		if sep:
			l11l1lll111_l1_,l11l1l111l1_l1_ = title.split(sep[0],1)
			l1ll1l111l1_l1_ = l11l1lll111_l1_
			l1lll11l1_l1_ = l11l1lll111_l1_+l11l1l_l1_ (u"ࠬࠦࠧ㡒")+sep[0]+l11l1l_l1_ (u"࠭ࠠࠨ㡓")+l11l1l111l1_l1_
	l1lll11l1_l1_ = l1lll11l1_l1_.replace(l11l1l_l1_ (u"ࠧࠡࠢࠣࠫ㡔"),l11l1l_l1_ (u"ࠨࠢࠪ㡕")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ㡖"),l11l1l_l1_ (u"ࠪࠤࠬ㡗"))
	l1ll1l111l1_l1_ = l1ll1l111l1_l1_.replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ㡘"),l11l1l_l1_ (u"ࠬࠦࠧ㡙"))
	if not l1ll1l111l1_l1_: l1ll1l111l1_l1_ = l11l1l_l1_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡤࠧࠡࠨ㡚")
	l1ll1l111l1_l1_ = l1ll1l111l1_l1_.strip(l11l1l_l1_ (u"ࠧࠡࠩ㡛"))
	l1lll11l1_l1_ = l1lll11l1_l1_.strip(l11l1l_l1_ (u"ࠨࠢࠪ㡜"))
	return l1ll1l111l1_l1_,l1lll11l1_l1_
def CREATE_STREAMS(l1l11l11l11_l1_,l111l111_l1_):
	global l11l11ll1l_l1_,l11lll1lll1_l1_,l11l1l1111l_l1_,l1l11l1l11l_l1_,l1l11l111l1_l1_,groups,l11l1lll1l1_l1_,l11ll11l1ll_l1_,l1l11l1111l_l1_
	l11ll1lll1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡶࡱࡥࠧ㡝")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠪࡣࠬ㡞")+l111l111_l1_)
	#l11l1ll1ll1_l1_,l11ll1lll1l_l1_,server,username,password = GET_URL(l1l11l11l11_l1_)
	#if not username: return
	l111ll111l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡮࠵ࡸ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨ㡟")+l1l11l11l11_l1_)
	headers = {l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㡠"):l111ll111l_l1_}
	#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭㡡"),l11l1l_l1_ (u"ࠧࠨ㡢"),l11l1l_l1_ (u"ࠨࠩ㡣"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㡤"),l11l1l_l1_ (u"ࠪ฽๊๊๊สࠢฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣะิ๐ฯสࠢๅำࠥะอหษฯࠤ฾ีษࠡัๅหห่ࠠ࠯๊่ࠢࠥะั๋ัࠣว๋ࠦสอๆหࠤฬ๊ๅๅใสฮࠥอไร่ࠣรࠬ㡥"))
	#if l1ll111111_l1_!=1: return
	l11lll1llll_l1_ = l1l1111llll_l1_.replace(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ㡦"),l11l1l_l1_ (u"ࠬࡥࠧ㡧")+l1l11l11l11_l1_+l11l1l_l1_ (u"࠭࡟ࠨ㡨")+l111l111_l1_)
	if 1:
		succeeded,l11ll11111l_l1_,l1l11l1l111_l1_ = True,l11l1l_l1_ (u"ࠧࠨ㡩"),l11l1l_l1_ (u"ࠨࠩ㡪")
		if not succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㡫"),l11l1l_l1_ (u"ࠪࠫ㡬"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㡭"),l11l1l_l1_ (u"ࠬ็ิๅࠢหืาฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤ࠳ࠦรฮฬ่ห้ࠦัศสฺࠤๅࡓ࠳ࡖࠢ฽๎ึࠦีฮ์ะࠤศ๎ࠠใัํ้ࠥษ่ࠡๆสࠤ๏฿ๅๅࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦ็ั้ࠣห้ิฯๆหࠣฮาะวอࠢสุฯืวไ่ࠢำๆ๎ูุ๊ࠡั๏ำ้ࠠ์ฯฬࠥษๆࠡฬู๎ๆࠦัศสฺࠤฬ๊วีฬิห่ࠦศ็ใึ็๊ࠥไษำ้ห๊าࠠษษึฮำีวๆࠢๅหห๋ษࠡโࡐ࠷࡚ࠦวๅ็๋ะํีษࠡส๊ิฬࠦวๅสิ๊ฬ๋ฬࠨ㡮"))
			if not l11ll1lll1l_l1_: LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ㡯"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡒࡴࠦࡍ࠴ࡗ࡙ࠣࡗࡒࠠࡧࡱࡸࡲࡩࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡒ࠹ࡕࠡࡨ࡬ࡰࡪࡹࠧ㡰"))
			else: LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭㡱"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡑ࠸࡛ࠠࡧ࡫࡯ࡩࡸ࠭㡲"))
			return
		l1l11ll111l_l1_ = DOWNLOAD_USING_PROGRESSBAR(l11ll1lll1l_l1_,headers,True)
		if not l1l11ll111l_l1_: return
		open(l11lll1llll_l1_,l11l1l_l1_ (u"ࠪࡻࡧ࠭㡳")).write(l1l11ll111l_l1_)
	else: l1l11ll111l_l1_ = open(l11lll1llll_l1_,l11l1l_l1_ (u"ࠫࡷࡨࠧ㡴")).read()
	if kodi_version>18.99 and l1l11ll111l_l1_: l1l11ll111l_l1_ = l1l11ll111l_l1_.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㡵"))
	#l1l11ll111l_l1_ = l1l11ll111l_l1_[33000111:77000111]
	l11l11ll1l_l1_ = DIALOG_PROGRESS()
	l11l11ll1l_l1_.create(l11l1l_l1_ (u"࠭ฬๅส้้ࠣ็วหࠢใࡑ࠸࡛ࠠอัํำฮ࠭㡶"),l11l1l_l1_ (u"ࠧࠨ㡷"))
	PROGRESS_UPDATE(l11l11ll1l_l1_,15,l11l1l_l1_ (u"ࠨฬ้฼๏็ࠠศๆ่่ๆࠦวๅำษ๎ุ๐ࠧ㡸"),l11l1l_l1_ (u"ࠩࠪ㡹"))
	l1l11ll111l_l1_ = l1l11ll111l_l1_.replace(l11l1l_l1_ (u"ࠪࠦࡹࡼࡧ࠮ࠩ㡺"),l11l1l_l1_ (u"ࠫࠧࠦࡴࡷࡩ࠰ࠫ㡻"))
	l1l11ll111l_l1_ = l1l11ll111l_l1_.replace(l11l1l_l1_ (u"ࠬ๔ࠧ㡼"),l11l1l_l1_ (u"࠭ࠧ㡽")).replace(l11l1l_l1_ (u"ࠧ์ࠩ㡾"),l11l1l_l1_ (u"ࠨࠩ㡿")).replace(l11l1l_l1_ (u"ࠩ๒ࠫ㢀"),l11l1l_l1_ (u"ࠪࠫ㢁")).replace(l11l1l_l1_ (u"ࠫ๑࠭㢂"),l11l1l_l1_ (u"ࠬ࠭㢃"))
	l1l11ll111l_l1_ = l1l11ll111l_l1_.replace(l11l1l_l1_ (u"࠭๑ࠨ㢄"),l11l1l_l1_ (u"ࠧࠨ㢅")).replace(l11l1l_l1_ (u"ࠨ๒ࠪ㢆"),l11l1l_l1_ (u"ࠩࠪ㢇")).replace(l11l1l_l1_ (u"ࠪ๑ࠬ㢈"),l11l1l_l1_ (u"ࠫࠬ㢉")).replace(l11l1l_l1_ (u"ࠬ๘ࠧ㢊"),l11l1l_l1_ (u"࠭ࠧ㢋"))
	l1l11ll111l_l1_ = l1l11ll111l_l1_.replace(l11l1l_l1_ (u"ࠧࡨࡴࡲࡹࡵ࠳ࡴࡪࡶ࡯ࡩࡂ࠭㢌"),l11l1l_l1_ (u"ࠨࡩࡵࡳࡺࡶ࠽ࠨ㢍")).replace(l11l1l_l1_ (u"ࠩࡷࡺ࡬࠳ࠧ㢎"),l11l1l_l1_ (u"ࠪࠫ㢏"))
	l11lll1ll1l_l1_,l1l111lll1l_l1_ = [],[]
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡒࡕࡓࡌࡘࡅࡔࡕࡢ࡙ࡕࡊࡁࡕࡇࠫࡴࡉ࡯ࡡ࡭ࡱࡪ࠰࠷࠶ࠬࠨฮ็ฬࠥอไๆๆไหฯࠦวๅอส๊ํ๐ษࠨ࠮ࠪห้๋ไโࠢิๆ๊ࡀ࠭ࠨ࠮ࠪ࠵ࠥ࠵ࠠ࠴ࠩࠬࠎࠎ࡯ࡦࠡࡲࡇ࡭ࡦࡲ࡯ࡨ࠰࡬ࡷࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠮ࠩ࠻ࠌࠌࠍࡵࡊࡩࡢ࡮ࡲ࡫࠳ࡩ࡬ࡰࡵࡨࠬ࠮ࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࡸࡶࡱࠦ࠽ࠡࡗࡕࡐࡤࡶ࡬ࡢࡻࡨࡶ࠰࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡸ࡫ࡲࡪࡧࡶࡣࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠨࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮࡫ࡩࡦࡪࡥࡳࡵ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡑ࠸࡛࠭ࡄࡔࡈࡅ࡙ࡋ࡟ࡔࡖࡕࡉࡆࡓࡓ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠱ࡧࡴࡴࡴࡦࡰࡷࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥ࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭࡮ࡴ࡮࡮ࠬࠎࠎࡹࡥࡳ࡫ࡨࡷࡤ࡭ࡲࡰࡷࡳࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡩࡡࡵࡧࡪࡳࡷࡿ࡟࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡩ࡫࡬ࠡࡪࡷࡱࡱࠐࠉࡧࡱࡵࠤ࡬ࡸ࡯ࡶࡲࠣ࡭ࡳࠦࡳࡦࡴ࡬ࡩࡸࡥࡧࡳࡱࡸࡴࡸࡀࠊࠊࠋࡪࡶࡴࡻࡰࠡ࠿ࠣ࡫ࡷࡵࡵࡱ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰ࠿࠵࠾ࡀࠠࡨࡴࡲࡹࡵࠦ࠽ࠡࡩࡵࡳࡺࡶ࠮ࡥࡧࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩ࠯ࡧࡱࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠌࠌࠍࡲ࠹ࡵࡠࡶࡨࡼࡹࠦ࠽ࠡ࡯࠶ࡹࡤࡺࡥࡹࡶ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࡭ࡲࡰࡷࡳࡁࠧ࠭ࠫࡨࡴࡲࡹࡵ࠱ࠧࠣࠩ࠯ࠫ࡬ࡸ࡯ࡶࡲࡀࠦࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ࠭ࡪࡶࡴࡻࡰࠬࠩࠥࠫ࠮ࠐࠉࡥࡧ࡯ࠤࡸ࡫ࡲࡪࡧࡶࡣ࡬ࡸ࡯ࡶࡲࡶࠎࠎࡖࡒࡐࡉࡕࡉࡘ࡙࡟ࡖࡒࡇࡅ࡙ࡋࠨࡱࡆ࡬ࡥࡱࡵࡧ࠭࠴࠸࠰ࠬาไษࠢส่๊๊แศฬࠣห้ัว็๊ํอࠬ࠲ࠧศๆ่่ๆࠦัใ็࠽࠱ࠬ࠲ࠧ࠳ࠢ࠲ࠤ࠸࠭ࠩࠋࠋ࡬ࡪࠥࡶࡄࡪࡣ࡯ࡳ࡬࠴ࡩࡴࡥࡤࡲࡨ࡫࡬ࡦࡦࠫ࠭࠿ࠐࠉࠊࡲࡇ࡭ࡦࡲ࡯ࡨ࠰ࡦࡰࡴࡹࡥࠩࠫࠍࠍࠎࡸࡥࡵࡷࡵࡲࠏࠏࡵࡳ࡮ࠣࡁ࡛ࠥࡒࡍࡡࡳࡰࡦࡿࡥࡳ࠭ࠪࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠࡸࡲࡨࡤࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠩࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡹࡷࡲࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡒ࠹ࡕ࠮ࡅࡕࡉࡆ࡚ࡅࡠࡕࡗࡖࡊࡇࡍࡔ࠯࠵ࡲࡩ࠭ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡥࡴࡥࡤࡴࡪ࡛ࡎࡊࡅࡒࡈࡊ࠮ࡨࡵ࡯࡯࠭ࠏࠏࡶࡰࡦࡢ࡫ࡷࡵࡵࡱࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡦࡺࡥࡨࡱࡵࡽࡤࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡧࡩࡱࠦࡨࡵ࡯࡯ࠎࠎ࡬࡯ࡳࠢࡪࡶࡴࡻࡰࠡ࡫ࡱࠤࡻࡵࡤࡠࡩࡵࡳࡺࡶࡳ࠻ࠌࠌࠍ࡬ࡸ࡯ࡶࡲࠣࡁࠥ࡭ࡲࡰࡷࡳ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜࠰ࠩ࠯ࠫ࠴࠭ࠩࠋࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡁ࠷࠹࠻ࠢࡪࡶࡴࡻࡰࠡ࠿ࠣ࡫ࡷࡵࡵࡱ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫ࠱ࡩࡳࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠎࠎࠏ࡭࠴ࡷࡢࡸࡪࡾࡴࠡ࠿ࠣࡱ࠸ࡻ࡟ࡵࡧࡻࡸ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡨࡴࡲࡹࡵࡃࠢࠨ࠭ࡪࡶࡴࡻࡰࠬࠩࠥࠫ࠱࠭ࡧࡳࡱࡸࡴࡂࠨ࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪ࠯࡬ࡸ࡯ࡶࡲ࠮ࠫࠧ࠭ࠩࠋࠋࡧࡩࡱࠦࡶࡰࡦࡢ࡫ࡷࡵࡵࡱࡵࠍࠍࡕࡘࡏࡈࡔࡈࡗࡘࡥࡕࡑࡆࡄࡘࡊ࠮ࡰࡅ࡫ࡤࡰࡴ࡭ࠬ࠴࠲࠯ࠫั๊ศࠡษ็้้็วหࠢส่ะอๆ้์ฬࠫ࠱࠭วๅ็็ๅࠥืโๆ࠼࠰ࠫ࠱࠭࠳ࠡ࠱ࠣ࠷ࠬ࠯ࠊࠊ࡫ࡩࠤࡵࡊࡩࡢ࡮ࡲ࡫࠳࡯ࡳࡤࡣࡱࡧࡪࡲࡥࡥࠪࠬ࠾ࠏࠏࠉࡱࡆ࡬ࡥࡱࡵࡧ࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠎࠎࡻࡲ࡭ࠢࡀࠤ࡚ࡘࡌࡠࡲ࡯ࡥࡾ࡫ࡲࠬࠩࠩࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺ࡟࡭࡫ࡹࡩࡤࡹࡴࡳࡧࡤࡱࡸ࠭ࠊࠊࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࡠࡅࡄࡇࡍࡋࡄࠩࡔࡈࡋ࡚ࡒࡁࡓࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡶࡴ࡯࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡏ࠶࡙࠲ࡉࡒࡆࡃࡗࡉࡤ࡙ࡔࡓࡇࡄࡑࡘ࠳࠳ࡳࡦࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫ࡬ࡹࡳ࡬ࠪࠌࠌࡰ࡮ࡼࡥࡠࡣࡵࡧ࡭࡯ࡶࡦࡦࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠦࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵࡸࡢࡥࡷࡩࡨࡪࡸࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡩࡳࡷࠦ࡮ࡢ࡯ࡨ࠰ࡦࡸࡣࡩ࡫ࡹࡩࡩࠦࡩ࡯ࠢ࡯࡭ࡻ࡫࡟ࡢࡴࡦ࡬࡮ࡼࡥࡥ࠼ࠍࠍࠎ࡯ࡦࠡࡣࡵࡧ࡭࡯ࡶࡦࡦࡀࡁࠬ࠷ࠧ࠻ࠢ࡯࡭ࡻ࡫࡟ࡢࡴࡦ࡬࡮ࡼࡥࡥࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡳࡧ࡭ࡦࠫࠍࠍࡩ࡫࡬ࠡ࡮࡬ࡺࡪࡥࡡࡳࡥ࡫࡭ࡻ࡫ࡤࠋࠋ࡯࡭ࡻ࡫࡟ࡦࡲࡪࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡴࡡ࡮ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡧࡳ࡫ࡤࡩࡨࡢࡰࡱࡩࡱࡥࡩࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡥࡧ࡯ࠤ࡭ࡺ࡭࡭ࠌࠌࡪࡴࡸࠠ࡯ࡣࡰࡩ࠱࡫ࡰࡨࠢ࡬ࡲࠥࡲࡩࡷࡧࡢࡩࡵ࡭࠺ࠋࠋࠌ࡭࡫ࠦࡥࡱࡩࠤࡁࠬࡴࡵ࡭࡮ࠪ࠾ࠥࡲࡩࡷࡧࡢࡩࡵ࡭࡟ࡤࡪࡤࡲࡳ࡫࡬ࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡱࡥࡲ࡫ࠩࠋࠋࡧࡩࡱࠦ࡬ࡪࡸࡨࡣࡪࡶࡧࠋࠋࠥࠦࠧ㢐")
	lines = re.findall(l11l1l_l1_ (u"ࠬࡔࡆ࠻ࠪ࠱࠯ࡄ࠯ࠣࡆ࡚ࡗࡍࠬ㢑"),l1l11ll111l_l1_+l11l1l_l1_ (u"࠭࡜࡯ࠥࡈ࡜࡙ࡏࡎࡇ࠼ࠪ㢒"),re.DOTALL)
	if not lines:
		LOG_THIS(l11l1l_l1_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ㢓"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡋࡵ࡬ࡥࡧࡵ࠾ࠬ㢔")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠩࠣࠤࡘ࡫ࡱࡶࡧࡱࡧࡪࡀࠧ㢕")+l111l111_l1_+l11l1l_l1_ (u"ࠪࠤࠥࠦࡎࡰࠢࡹ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࡹࠠࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࡐ࠷࡚ࠦࡦࡪ࡮ࡨࠫ㢖"))
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㢗"),l11l1l_l1_ (u"ࠬ࠭㢘"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ㢙"),l11l1l_l1_ (u"ࠧาษห฻ࠥๆࡍ࠴ࡗࠣห้ึ๊ࠡล้ฮࠥษึโฬ๊ࠤ้อࠠห๊ฯำࠥ็๊่ࠢไ๎ิ๐่่ษอࠤ࠳࠴ࠠศฯอ้ฬ๊ࠠาษห฻ࠥๆࡍ࠴ࡗࠣ฾๏ืࠠึฯํัࠬ㢚")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ㢛")+l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ㢜")+l11l1l_l1_ (u"ࠪีฬฮืࠡำๅ้ࠥ࠭㢝")+str(int(l111l111_l1_)+1)+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㢞"))
		l11l11ll1l_l1_.close()
		return
	l11l1ll1l1_l1_ = 1024*1024
	l11ll1l1111_l1_ = 1+len(l1l11ll111l_l1_)//l11l1ll1l1_l1_//10
	del l1l11ll111l_l1_
	l11l1l11l11_l1_ = len(lines)
	l11l1l1ll11_l1_ = SPLIT_BIGLIST(lines,l11ll1l1111_l1_)
	del lines
	for l11l1l1ll1_l1_ in range(l11ll1l1111_l1_):
		PROGRESS_UPDATE(l11l11ll1l_l1_,35+int(5*l11l1l1ll1_l1_/l11ll1l1111_l1_),l11l1l_l1_ (u"ࠬะโุ์฼ࠤฬ๊ๅๅใࠣห้ืฦ๋ีํࠫ㢟"),l11l1l_l1_ (u"࠭วๅฮีลࠥืโๆ࠼࠰ࠫ㢠"),str(l11l1l1ll1_l1_+1)+l11l1l_l1_ (u"ࠧࠡ࠱ࠣࠫ㢡")+str(l11ll1l1111_l1_))
		if l11l11ll1l_l1_.iscanceled():
			l11l11ll1l_l1_.close()
			return
		l11lll11l11_l1_ = str(l11l1l1ll11_l1_[l11l1l1ll1_l1_])
		if kodi_version>18.99: l11lll11l11_l1_ = l11lll11l11_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭㢢"))
		l11lll11l11_l1_ = l11lll11l11_l1_.replace(l11l1l_l1_ (u"ࠩ࡟ࡠࡷ࠭㢣"),l11l1l_l1_ (u"ࠪࠫ㢤")).replace(l11l1l_l1_ (u"ࠫࡡࡢ࡮ࠨ㢥"),l11l1l_l1_ (u"ࠬ࠭㢦"))
		open(l11lll1llll_l1_+l11l1l_l1_ (u"࠭࠮࠱࠲ࠪ㢧")+str(l11l1l1ll1_l1_),l11l1l_l1_ (u"ࠧࡸࡤࠪ㢨")).write(l11lll11l11_l1_)
	del l11l1l1ll11_l1_,l11lll11l11_l1_
	l11l1l1l111_l1_,l11ll1l1ll1_l1_,l11llll11l1_l1_ = [],[],0
	for l11l1l1ll1_l1_ in range(l11ll1l1111_l1_):
		if l11l11ll1l_l1_.iscanceled():
			l11l11ll1l_l1_.close()
			return
		l11lll11l11_l1_ = open(l11lll1llll_l1_+l11l1l_l1_ (u"ࠨ࠰࠳࠴ࠬ㢩")+str(l11l1l1ll1_l1_),l11l1l_l1_ (u"ࠩࡵࡦࠬ㢪")).read()
		time.sleep(1)
		try: os.remove(l11lll1llll_l1_+l11l1l_l1_ (u"ࠪ࠲࠵࠶ࠧ㢫")+str(l11l1l1ll1_l1_))
		except: pass
		if kodi_version>18.99: l11lll11l11_l1_ = l11lll11l11_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㢬"))
		lines = EVAL(l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ㢭"),l11lll11l11_l1_)
		del l11lll11l11_l1_
		l11lll11ll1_l1_,l11llll11l1_l1_,l11l1l1ll1l_l1_ = READ_ALL_LINES(lines,l1l111lll1l_l1_,l11lll1ll1l_l1_,l11l11ll1l_l1_,l11l1l11l11_l1_,l11llll11l1_l1_,l11ll1lll1l_l1_)
		if l11l11ll1l_l1_.iscanceled():
			l11l11ll1l_l1_.close()
			return
		if not l11lll11ll1_l1_:
			l11l11ll1l_l1_.close()
			return
		l11ll1l1ll1_l1_ += l11lll11ll1_l1_
		l11l1l1l111_l1_ += l11l1l1ll1l_l1_
	del lines,l11lll11ll1_l1_
	l11lll1lll1_l1_,l11l1l1ll1l_l1_ = CREATE_GROUPED_STREAMS(l11ll1l1ll1_l1_,l11l11ll1l_l1_,l111l111_l1_)
	if l11l11ll1l_l1_.iscanceled():
		l11l11ll1l_l1_.close()
		return
	l11l1l1l111_l1_ += l11l1l1ll1l_l1_
	del l11ll1l1ll1_l1_,l11l1l1ll1l_l1_
	l1l11l1l11l_l1_,l1l11l111l1_l1_,groups,l11l1lll1l1_l1_,l11ll11l1ll_l1_ = {},{},{},0,0
	l11l1lllll1_l1_ = list(l11lll1lll1_l1_.keys())
	l1l11l1111l_l1_ = len(l11l1lllll1_l1_)*3
	import threading
	if 1:
		threads = {}
		for l11l11lllll_l1_ in l11l1lllll1_l1_:
			threads[l11l11lllll_l1_] = threading.Thread(target=CREATE_MENUS,args=(l11l11lllll_l1_,))
			threads[l11l11lllll_l1_].start()
		for l11l11lllll_l1_ in l11l1lllll1_l1_:
			threads[l11l11lllll_l1_].join()
		if l11l11ll1l_l1_.iscanceled():
			l11l11ll1l_l1_.close()
			return
	else:
		for l11l11lllll_l1_ in l11l1lllll1_l1_:
			CREATE_MENUS(l11l11lllll_l1_)
			if l11l11ll1l_l1_.iscanceled():
				l11l11ll1l_l1_.close()
				return
	DELETE_FILES(l1l11l11l11_l1_,l111l111_l1_,False)
	l11l1lllll1_l1_ = list(l1l11l1l11l_l1_.keys())
	l11l1l1111l_l1_ = 0
	if 1:
		threads = {}
		for l11l11lllll_l1_ in l11l1lllll1_l1_:
			threads[l11l11lllll_l1_] = threading.Thread(target=SAVE_MENUS,args=(l1l11l11l11_l1_,l11l11lllll_l1_))
			threads[l11l11lllll_l1_].start()
		for l11l11lllll_l1_ in l11l1lllll1_l1_:
			threads[l11l11lllll_l1_].join()
		if l11l11ll1l_l1_.iscanceled():
			l11l11ll1l_l1_.close()
			return
	else:
		for l11l11lllll_l1_ in l11l1lllll1_l1_:
			SAVE_MENUS(l1l11l11l11_l1_,l11l11lllll_l1_)
			if l11l11ll1l_l1_.iscanceled():
				l11l11ll1l_l1_.close()
				return
	l11l1l1ll1_l1_ = 0
	l1l11l1l1ll_l1_ = len(l11l1l1l111_l1_)
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"࠭ࡉࡈࡐࡒࡖࡊࡊࠧ㢮"))
	for stream in l11l1l1l111_l1_:
		if l11l1l1ll1_l1_%27==0:
			PROGRESS_UPDATE(l11l11ll1l_l1_,95+int(5*l11l1l1ll1_l1_//l1l11l1l1ll_l1_),l11l1l_l1_ (u"ࠧหะี๎๋ࠦวๅ็๊้้ฯࠧ㢯"),l11l1l_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢิๆ๊ࡀ࠭ࠨ㢰"),str(l11l1l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣ࠳ࠥ࠭㢱")+str(l1l11l1l1ll_l1_))
			if l11l11ll1l_l1_.iscanceled():
				l11l11ll1l_l1_.close()
				return
		WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࡍࡌࡔࡏࡓࡇࡇࡣࠬ㢲")+l111l111_l1_,str(stream),l11l1l_l1_ (u"ࠫࠬ㢳"),PERMANENT_CACHE)
		l11l1l1ll1_l1_ += 1
	WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠬࡏࡇࡏࡑࡕࡉࡉࡥࠧ㢴")+l111l111_l1_,l11l1l_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㢵"),str(l1l11l1l1ll_l1_),PERMANENT_CACHE)
	#WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠧࡅࡗࡐࡑ࡞ࡥࠧ㢶")+l111l111_l1_,l11l1l_l1_ (u"ࠨࡡࡢࡈ࡚ࡓࡍ࡚ࡡࡢࠫ㢷"),l11l1l_l1_ (u"ࠩ࠴ࠫ㢸"),PERMANENT_CACHE)
	#open(l1l1111l1l1_l1_,l11l1l_l1_ (u"ࠪࡻࠬ㢹")).write(l11l1l_l1_ (u"ࠫࠬ㢺"))
	l11l11ll1l_l1_.close()
	time.sleep(1)
	#l11ll111lll_l1_ = COUNTS(l1l11l11l11_l1_,l111l111_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㢻"),l11l1l_l1_ (u"࠭ࠧ㢼"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㢽"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㢾")+l11l1l_l1_ (u"ࠩอ้ࠥาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอࠬ㢿")+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㣀")+l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㣁")+l11ll111lll_l1_)
	#xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ㣂"))
	return
def CREATE_MENUS(l11l11lllll_l1_):
	global l11l11ll1l_l1_,l11lll1lll1_l1_,l11l1l1111l_l1_,l1l11l1l11l_l1_,l1l11l111l1_l1_,groups,l11l1lll1l1_l1_,l11ll11l1ll_l1_,l1l11l1111l_l1_
	l1l11l1l11l_l1_[l11l11lllll_l1_] = {}
	l11ll111l11_l1_,l11lllllll1_l1_ = {},[]
	l11l1l1l1l1_l1_ = len(l11lll1lll1_l1_[l11l11lllll_l1_])
	l1l11l1l11l_l1_[l11l11lllll_l1_][l11l1l_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㣃")] = l11l1l1l1l1_l1_
	if l11l1l1l1l1_l1_>0:
		l1l1111ll11_l1_,l1l11l1llll_l1_,l11l11lll11_l1_,l1l11l1ll11_l1_,l11llll1l1l_l1_ = zip(*l11lll1lll1_l1_[l11l11lllll_l1_])
		del l1l11l1llll_l1_,l11l11lll11_l1_,l1l11l1ll11_l1_
		l11ll1l1lll_l1_ = list(set(l1l1111ll11_l1_))
		for group in l11ll1l1lll_l1_:
			l11ll111l11_l1_[group] = l11l1l_l1_ (u"ࠧࠨ㣄")
			l1l11l1l11l_l1_[l11l11lllll_l1_][group] = []
		PROGRESS_UPDATE(l11l11ll1l_l1_,60+int(15*l11ll11l1ll_l1_//l1l11l1111l_l1_),l11l1l_l1_ (u"ࠨฬุ๊๏฿ࠠศๆๅ์ฬฬๅࠨ㣅"),l11l1l_l1_ (u"ࠩส่ัุมࠡำๅ้࠿࠳ࠧ㣆"),str(l11ll11l1ll_l1_)+l11l1l_l1_ (u"ࠪࠤ࠴ࠦࠧ㣇")+str(l1l11l1111l_l1_))
		if l11l11ll1l_l1_.iscanceled(): return
		l11ll11l1ll_l1_ += 1
		l11l1llll1l_l1_ = len(l11ll1l1lll_l1_)
		del l11ll1l1lll_l1_
		l11lllllll1_l1_ = list(set(zip(l1l1111ll11_l1_,l11llll1l1l_l1_)))
		del l1l1111ll11_l1_,l11llll1l1l_l1_
		for group,l111_l1_ in l11lllllll1_l1_:
			if not l11ll111l11_l1_[group] and l111_l1_: l11ll111l11_l1_[group] = l111_l1_
		PROGRESS_UPDATE(l11l11ll1l_l1_,60+int(15*l11ll11l1ll_l1_//l1l11l1111l_l1_),l11l1l_l1_ (u"ࠫฯ฻ๆ๋฻ࠣห้่่ศศ่ࠫ㣈"),l11l1l_l1_ (u"ࠬอไอิฤࠤึ่ๅ࠻࠯ࠪ㣉"),str(l11ll11l1ll_l1_)+l11l1l_l1_ (u"࠭ࠠ࠰ࠢࠪ㣊")+str(l1l11l1111l_l1_))
		if l11l11ll1l_l1_.iscanceled(): return
		l11ll11l1ll_l1_ += 1
		l11ll1l111l_l1_ = list(l11ll111l11_l1_.keys())
		l11l1lll1ll_l1_ = list(l11ll111l11_l1_.values())
		del l11ll111l11_l1_
		l11lllllll1_l1_ = list(zip(l11ll1l111l_l1_,l11l1lll1ll_l1_))
		del l11ll1l111l_l1_,l11l1lll1ll_l1_
		l11lllllll1_l1_ = sorted(l11lllllll1_l1_)
	else: l11ll11l1ll_l1_ += 2
	l1l11l1l11l_l1_[l11l11lllll_l1_][l11l1l_l1_ (u"ࠧࡠࡡࡊࡖࡔ࡛ࡐࡔࡡࡢࠫ㣋")] = l11lllllll1_l1_
	del l11lllllll1_l1_
	for group,context,title,url,l1ll1l_l1_ in l11lll1lll1_l1_[l11l11lllll_l1_]:
		l1l11l1l11l_l1_[l11l11lllll_l1_][group].append((context,title,url,l1ll1l_l1_))
	PROGRESS_UPDATE(l11l11ll1l_l1_,60+int(15*l11ll11l1ll_l1_//l1l11l1111l_l1_),l11l1l_l1_ (u"ࠨฬุ๊๏฿ࠠศๆๅ์ฬฬๅࠨ㣌"),l11l1l_l1_ (u"ࠩส่ัุมࠡำๅ้࠿࠳ࠧ㣍"),str(l11ll11l1ll_l1_)+l11l1l_l1_ (u"ࠪࠤ࠴ࠦࠧ㣎")+str(l1l11l1111l_l1_))
	if l11l11ll1l_l1_.iscanceled(): return
	l11ll11l1ll_l1_ += 1
	del l11lll1lll1_l1_[l11l11lllll_l1_]
	groups[l11l11lllll_l1_] = list(l1l11l1l11l_l1_[l11l11lllll_l1_].keys())
	l1l11l111l1_l1_[l11l11lllll_l1_] = len(groups[l11l11lllll_l1_])
	l11l1lll1l1_l1_ += l1l11l111l1_l1_[l11l11lllll_l1_]
	return
def SAVE_MENUS(l1l11l11l11_l1_,l11l11lllll_l1_):
	global l11l11ll1l_l1_,l11lll1lll1_l1_,l11l1l1111l_l1_,l1l11l1l11l_l1_,l1l11l111l1_l1_,groups,l11l1lll1l1_l1_,l11ll11l1ll_l1_,l1l11l1111l_l1_
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l11lllll_l1_)
	for l11llll11l1_l1_ in range(1+l1l11l111l1_l1_[l11l11lllll_l1_]//173):
		l11l1ll1l11_l1_ = []
		l1l111111l1_l1_ = groups[l11l11lllll_l1_][0:273]
		for group in l1l111111l1_l1_:
			l11l1ll1l11_l1_.append(l1l11l1l11l_l1_[l11l11lllll_l1_][group])
		WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l11lllll_l1_,l1l111111l1_l1_,l11l1ll1l11_l1_,PERMANENT_CACHE,True)
		l11l1l1111l_l1_ += len(l1l111111l1_l1_)
		PROGRESS_UPDATE(l11l11ll1l_l1_,75+int(20*l11l1l1111l_l1_//l11l1lll1l1_l1_),l11l1l_l1_ (u"ࠫฯิา๋่ࠣห้่่ศศ่ࠫ㣏"),l11l1l_l1_ (u"ࠬอไใษษ้ฮࠦัใ็࠽࠱ࠬ㣐"),str(l11l1l1111l_l1_)+l11l1l_l1_ (u"࠭ࠠ࠰ࠢࠪ㣑")+str(l11l1lll1l1_l1_))
		if l11l11ll1l_l1_.iscanceled(): return
		del groups[l11l11lllll_l1_][0:273]
	del l1l11l1l11l_l1_[l11l11lllll_l1_],groups[l11l11lllll_l1_],l1l11l111l1_l1_[l11l11lllll_l1_]
	return
def COUNTS(l1l11l11l11_l1_,l111l111_l1_,l1ll_l1_=True):
	#if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,l1ll_l1_): return
	l1l111111ll_l1_ = l11l1l_l1_ (u"ฺࠧัาࠤๆ๐ฯ๋๊๊หฯࠦฬๆ์฼ࠤฬ๊ั้ษห฻ࠬ㣒")
	l11ll11l111_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㣓"))
	l11llll111l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ㣔"))
	if l111l111_l1_:
		l1l111111ll_l1_ = l11l1l_l1_ (u"ࠪ฽ิีࠠโ์า๎ํํวหࠢิหอ฽ࠠࠨ㣕")+text_numbers[int(l111l111_l1_)]
		l111l111_l1_ = l11l1l_l1_ (u"ࠫࡤ࠭㣖")+l111l111_l1_
	l1l11l1l1ll_l1_ = READ_FROM_SQL3(l11ll11l111_l1_,l11l1l_l1_ (u"ࠬ࡯࡮ࡵࠩ㣗"),l11l1l_l1_ (u"࠭ࡉࡈࡐࡒࡖࡊࡊࠧ㣘")+l111l111_l1_,l11l1l_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㣙"))
	l11lllll11l_l1_ = READ_FROM_SQL3(l11ll11l111_l1_,l11l1l_l1_ (u"ࠨ࡫ࡱࡸࠬ㣚"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡐࡔࡌࡋࡎࡔࡁࡍࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ㣛")+l111l111_l1_,l11l1l_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㣜"))
	l11l11lll1l_l1_ = READ_FROM_SQL3(l11llll111l_l1_,l11l1l_l1_ (u"ࠫ࡮ࡴࡴࠨ㣝"),l11l1l_l1_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㣞")+l111l111_l1_,l11l1l_l1_ (u"࠭࡟ࡠࡅࡒ࡙ࡓ࡚࡟ࡠࠩ㣟"))
	l11lll1l1l1_l1_ = READ_FROM_SQL3(l11ll11l111_l1_,l11l1l_l1_ (u"ࠧࡪࡰࡷࠫ㣠"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊࠧ㣡")+l111l111_l1_,l11l1l_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㣢"))
	l11ll1111l1_l1_ = READ_FROM_SQL3(l11ll11l111_l1_,l11l1l_l1_ (u"ࠪ࡭ࡳࡺࠧ㣣"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࠫ㣤")+l111l111_l1_,l11l1l_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㣥"))
	l1l1111lll1_l1_ = READ_FROM_SQL3(l11ll11l111_l1_,l11l1l_l1_ (u"࠭ࡩ࡯ࡶࠪ㣦"),l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ㣧")+l111l111_l1_,l11l1l_l1_ (u"ࠨࡡࡢࡇࡔ࡛ࡎࡕࡡࡢࠫ㣨"))
	l1l11l1l1l1_l1_ = READ_FROM_SQL3(l11llll111l_l1_,l11l1l_l1_ (u"ࠩ࡬ࡲࡹ࠭㣩"),l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ㣪")+l111l111_l1_,l11l1l_l1_ (u"ࠫࡤࡥࡃࡐࡗࡑࡘࡤࡥࠧ㣫"))
	l11ll11llll_l1_ = READ_FROM_SQL3(l11ll11l111_l1_,l11l1l_l1_ (u"ࠬ࡯࡮ࡵࠩ㣬"),l11l1l_l1_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࠬ㣭")+l111l111_l1_,l11l1l_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㣮"))
	groups = READ_FROM_SQL3(l11llll111l_l1_,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㣯"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊࠧ㣰")+l111l111_l1_,l11l1l_l1_ (u"ࠪࡣࡤࡍࡒࡐࡗࡓࡗࡤࡥࠧ㣱"))
	l11ll1lllll_l1_ = []
	for group,l1ll1l_l1_ in groups:
		l11ll1ll11l_l1_ = group.split(l11l1l_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㣲"))[1]
		l11ll1lllll_l1_.append(l11ll1ll11l_l1_)
	l11llll11ll_l1_ = len(l11ll1lllll_l1_)
	total = int(l1l1111lll1_l1_)+int(l1l11l1l1l1_l1_)+int(l11ll11llll_l1_)+int(l11ll1111l1_l1_)+int(l11lll1l1l1_l1_)
	l11ll111lll_l1_ = l11l1l_l1_ (u"ࠬ࠭㣳")
	l11ll111lll_l1_ += l11l1l_l1_ (u"࠭โ็๊สฮ࠿ࠦࠧ㣴")+str(l11lll1l1l1_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࠠฤใ็ห๊ࡀࠠࠨ㣵")+str(l1l1111lll1_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠨ࡞ࡱุ้๊ำๅษอ࠾ࠥ࠭㣶")+str(l11llll11ll_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠩࠣࠤࠥ࠴ࠠࠡࠢะ่็อส࠻ࠢࠪ㣷")+str(l1l11l1l1l1_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠪࡠࡳ่ๆ้ษอࠤ๊า็้ๆฬ࠾ࠥ࠭㣸")+str(l11ll1111l1_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠫࠥࠦࠠ࠯ࠢࠣࠤๆ๐ฯ้้สฮ๋ࠥฬ่๊็อ࠿ࠦࠧ㣹")+str(l11ll11llll_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠬࡢ࡮ๆฮ่์฾ࠦวๅไ้์ฬะ࠺ࠡࠩ㣺")+str(l11lllll11l_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"࠭ࠠࠡࠢ࠱ࠤࠥࠦๅอ็๋฽ࠥอไโ์า๎ํํวห࠼ࠣࠫ㣻")+str(l11l11lll1l_l1_)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡟ࡲ๊าๅ้฻ࠣห้๋ึศใฬ࠾ࠥ࠭㣼")+str(total)
	l11ll111lll_l1_ += l11l1l_l1_ (u"ࠨࠢࠣࠤ࠳ࠦࠠࠡ็ฯ้ํ฿ࠠศๆ่๋๊๊ษ࠻ࠢࠪ㣽")+str(l1l11l1l1ll_l1_)
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ㣾"),l11l1l_l1_ (u"ࠪࠫ㣿"),l1l111111ll_l1_,l11ll111lll_l1_)
	l11ll11lll1_l1_ = l11ll111lll_l1_.replace(l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯ࠩ㤀"),l11l1l_l1_ (u"ࠬࡢ࡮ࠨ㤁"))
	if not l111l111_l1_: l111l111_l1_ = l11l1l_l1_ (u"࠭ࡁ࡭࡮ࠪ㤂")
	else: l111l111_l1_ = l111l111_l1_[1]
	LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㤃"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡉ࡯ࡶࡰࡷࡷࠥࡵࡦࠡࡏ࠶࡙ࠥࡼࡩࡥࡧࡲࡷࠥࠦࠠࡇࡱ࡯ࡨࡪࡸ࠺ࠡࠩ㤄")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠩࠣࠤ࡙ࠥࡥࡲࡷࡨࡲࡨ࡫࠺ࠡࠩ㤅")+l111l111_l1_+l11l1l_l1_ (u"ࠪࡠࡳ࠭㤆")+l11ll11lll1_l1_)
	return l11ll111lll_l1_
def DELETE_FILES(l1l11l11l11_l1_,l111l111_l1_,l1ll_l1_=True):
	if l1ll_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㤇"),l11l1l_l1_ (u"ࠬ࠭㤈"),l11l1l_l1_ (u"࠭ࠧ㤉"),l11l1l_l1_ (u"ࠧๆีะࠤ๊๊แศฬࠣไࡒ࠹ࡕࠨ㤊"),l11l1l_l1_ (u"ࠨ้็ࠤฯื๊ะࠢส่ว์ࠠๆีะࠤฬ๊ๅๅใสฮࠥอไใัํ้ฮࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠡࠡ࠰࠱ࠤ฾๊ๅศࠢส๊่ࠦสิฬฺ๎฾ࠦแ๋ࠢฦ๎ࠥ๎โหࠢส่ิิ่ๅࠢศ่๎ࠦโศศ่อࠥๆࡍ࠴ࡗࠣ์ั๊ศࠡ็็ๅฬะࠠแࡏ࠶࡙ࠥาฯ๋ัฬࠫ㤋"))
		if l1ll111111_l1_!=1: return
		file = l1l1111llll_l1_.replace(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭㤌"),l11l1l_l1_ (u"ࠪࡣࠬ㤍")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠫࡤ࠭㤎")+l111l111_l1_)
		try: os.remove(file)
		except: pass
	#try: os.remove(l11lllll1ll_l1_)
	#except: pass
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭㤏"))
	if l111l111_l1_:
		l11lll111ll_l1_ = []
		for l11ll111l_l1_ in l11lll1111l_l1_:
			l11lll111ll_l1_.append(l11ll111l_l1_+l11l1l_l1_ (u"࠭࡟ࠨ㤐")+l111l111_l1_)
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠧࡍࡋࡑࡏࡤ࠭㤑")+l111l111_l1_)
	else:
		l11lll111ll_l1_ = l11lll1111l_l1_
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠨࡆࡘࡑࡒ࡟ࠧ㤒"))
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠩࡊࡖࡔ࡛ࡐࡔࠩ㤓"))
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࡍ࡙ࡋࡍࡔࠩ㤔"))
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠫࡘࡋࡁࡓࡅࡋࠫ㤕"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ㤖"),l11l1l_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭㤗")+l1l11l11l11_l1_)
	for l11l11lllll_l1_ in l11lll111ll_l1_:
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,l11l11lllll_l1_)
	FIX_ALL_DATABASES(False)
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㤘"),l11l1l_l1_ (u"ࠨࠩ㤙"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㤚"),l11l1l_l1_ (u"ࠪฮ๊ࠦๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠแࡏ࠶࡙ࠬ㤛"))
	return
def CHECK_TABLES_EXIST(l1l11l11l11_l1_=l11l1l_l1_ (u"ࠫࠬ㤜"),l1ll_l1_=True):
	if l1l11l11l11_l1_:
		l1l1l1l11l_l1_ = GET_DBFILE_NAME(str(l1l11l11l11_l1_),l11l1l_l1_ (u"ࠬࡊࡕࡎࡏ࡜ࠫ㤝"))
		dummy = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"࠭ࡳࡵࡴࠪ㤞"),l11l1l_l1_ (u"ࠧࡅࡗࡐࡑ࡞࠭㤟"),l11l1l_l1_ (u"ࠨࡡࡢࡈ࡚ࡓࡍ࡚ࡡࡢࠫ㤠"))
		if dummy: return True
	else:
		for l1l11l11l11_l1_ in range(1,FOLDERS_COUNT+1):
			l1l1l1l11l_l1_ = GET_DBFILE_NAME(str(l1l11l11l11_l1_),l11l1l_l1_ (u"ࠩࡇ࡙ࡒࡓ࡙ࠨ㤡"))
			dummy = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ㤢"),l11l1l_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ㤣"),l11l1l_l1_ (u"ࠬࡥ࡟ࡅࡗࡐࡑ࡞ࡥ࡟ࠨ㤤"))
			if dummy: return True
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㤥"),l11l1l_l1_ (u"ࠧࠨ㤦"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㤧"),l11l1l_l1_ (u"ࠩส๊ฯࠦศฮษฯอࠥหไ๊ࠢส่ีํวษࠢศ่๎ࠦโศศ่อࠥๆࡍ࠴ࡗࠣฯ๊ࠦสื฼ฺࠤ฾๊้ࠡࠤศฺฬ็ษࠡำสฬ฼ࠦร้ࠢสุฯืวไࠢใࡑ࠸࡛ࠢࠡ࠰࠱ࠤ์ึ็ࠡษ็ีํอศุࠢสัฯ๋วๅࠢอะิํวࠡใํࠤฬ๊ล็ฬิ๊ฯࠦร้ࠢอุฯื๊่ษ้๋ࠣࠦิาๅฬࠤๆ๐ฯ๋๊๊หฯࠦ࡜࡯࡞ࡱࠤศ๋วࠡวำห่ࠥๅหࠢไ฽้อࠠษวูหๆฯࠠศๆิหอ฽ࠠโวำ๊ࠥษๆหࠢหัฬาษࠡๆฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠣ์ี๊ใࠡสส่ีํวษࠢศ่๎ࠦโศศ่อࠥๆࡍ࠴ࡗࠣฯ๊ࠦสื฼ฺࠤ฾๊้ࠡࠤฯ่อࠦๅๅใสฮࠥๆࡍ࠴ࡗࠥ࠲ࠬ㤨"))
	#SHOW_EMPTY(l1111l_l1_)
	return False
def SEARCH(l1l1llll11l_l1_,l1l11l11l11_l1_=l11l1l_l1_ (u"ࠪࠫ㤩"),l11l11lllll_l1_=l11l1l_l1_ (u"ࠫࠬ㤪"),l11ll111ll1_l1_=l11l1l_l1_ (u"ࠬ࠭㤫")):
	if not l11ll111ll1_l1_: l11ll111ll1_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ㤬")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1llll11l_l1_)
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll1ll111_l1_ = [l11l1l_l1_ (u"ࠧࠨ㤭"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㤮"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㤯"),l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨ㤰"),l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ㤱"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ㤲")]
	if not l11l11lllll_l1_:
		if not l1ll_l1_:
			if   l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡑࡏࡖࡆࡡࠪ㤳") in options: l11l11lllll_l1_ = l11ll1ll111_l1_[1]
			elif l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ㤴") in options: l11l11lllll_l1_ = l11ll1ll111_l1_[2]
			elif l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭㤵") in options: l11l11lllll_l1_ = l11ll1ll111_l1_[3]
			else: l11l11lllll_l1_ = l11ll1ll111_l1_[0]
		else:
			l11llllll11_l1_ = [l11l1l_l1_ (u"ࠩส่่๊ࠧ㤶"),l11l1l_l1_ (u"ࠪๆ๋๎วหࠩ㤷"),l11l1l_l1_ (u"ࠫศ็ไศ็ࠪ㤸"),l11l1l_l1_ (u"๋ࠬำๅี็หฯ࠭㤹"),l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡ็ฯ๋ํ๊ษࠨ㤺"),l11l1l_l1_ (u"ࠧใ่๋หฯࠦๅอ้๋่ฮ࠭㤻")]
			choice = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭㤼"), l11llllll11_l1_)
			if choice==-1: return
			l11l11lllll_l1_ = l11ll1ll111_l1_[choice]
	search = search+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ㤽")
	if l1l11l11l11_l1_: SEARCH_ONE_FOLDER(search,l1l11l11l11_l1_,l11l11lllll_l1_,l11ll111ll1_l1_)
	else:
		for l1l11l11l11_l1_ in range(1,FOLDERS_COUNT+1):
			SEARCH_ONE_FOLDER(search,str(l1l11l11l11_l1_),l11l11lllll_l1_,l11ll111ll1_l1_)
		menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
	return
def SEARCH_ONE_FOLDER(l1l1llll11l_l1_,l1l11l11l11_l1_,l11l11lllll_l1_=l11l1l_l1_ (u"ࠪࠫ㤾"),l11ll111ll1_l1_=l11l1l_l1_ (u"ࠫࠬ㤿")):
	if not l11ll111ll1_l1_: l11ll111ll1_l1_ = l11l1l_l1_ (u"ࠬ࠷ࠧ㥀")
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1llll11l_l1_)
	if not l1l11l11l11_l1_: return
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,l1ll_l1_): return
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11ll1ll111_l1_ = [l11l1l_l1_ (u"࠭ࠧ㥁"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㥂"),l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭㥃"),l11l1l_l1_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ㥄"),l11l1l_l1_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩ㥅"),l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ㥆")]
	if not l11l11lllll_l1_:
		if not l1ll_l1_:
			if   l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࡠࠩ㥇") in options: l11l11lllll_l1_ = l11ll1ll111_l1_[1]
			elif l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ㥈") in options: l11l11lllll_l1_ = l11ll1ll111_l1_[2]
			elif l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙࠲࡙ࡅࡓࡋࡈࡗࠬ㥉") in options: l11l11lllll_l1_ = l11ll1ll111_l1_[3]
			else: l11l11lllll_l1_ = l11ll1ll111_l1_[0]
		else:
			l11llllll11_l1_ = [l11l1l_l1_ (u"ࠨษ็็้࠭㥊"),l11l1l_l1_ (u"ࠩๅ๊ํอสࠨ㥋"),l11l1l_l1_ (u"ࠪวๆ๊วๆࠩ㥌"),l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠬ㥍"),l11l1l_l1_ (u"ࠬ็๊ะ์๋๋ฬะࠠๆฮ๊์้ฯࠧ㥎"),l11l1l_l1_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬ㥏")]
			choice = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ㥐"), l11llllll11_l1_)
			if choice==-1: return
			l11l11lllll_l1_ = l11ll1ll111_l1_[choice]
	l11l1l11111_l1_ = search.lower()
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠨࡕࡈࡅࡗࡉࡈࠨ㥑"))
	results = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ㥒"),l11l1l_l1_ (u"ࠪࡗࡊࡇࡒࡄࡊࠪ㥓"),(l11l11lllll_l1_,l11l1l11111_l1_))
	if not results:
		l1l111lll11_l1_,l11ll1lll11_l1_ = [],[]
		if not l11l11lllll_l1_: l11ll11ll11_l1_ = [1,2,3,4,5]
		else: l11ll11ll11_l1_ = [l11ll1ll111_l1_.index(l11l11lllll_l1_)]
		for l11l1l1ll1_l1_ in l11ll11ll11_l1_:
			#l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11ll1ll111_l1_[l11l1l1ll1_l1_])
			if l11l1l1ll1_l1_!=3:
				l11lll11ll1_l1_ = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ㥔"),l11ll1ll111_l1_[l11l1l1ll1_l1_])
				del l11lll11ll1_l1_[l11l1l_l1_ (u"ࠬࡥ࡟ࡄࡑࡘࡒ࡙ࡥ࡟ࠨ㥕")]
				del l11lll11ll1_l1_[l11l1l_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ㥖")]
				del l11lll11ll1_l1_[l11l1l_l1_ (u"ࠧࡠࡡࡖࡉࡖ࡛ࡅࡏࡅࡈࡈࡤࡉࡏࡍࡗࡐࡒࡘࡥ࡟ࠨ㥗")]
				groups = list(l11lll11ll1_l1_.keys())
				for group in groups:
					for context,title,url,l1ll1l_l1_ in l11lll11ll1_l1_[group]:
						if l11l1l11111_l1_ in title.lower(): l11ll1lll11_l1_.append((title,url,l1ll1l_l1_))
					del l11lll11ll1_l1_[group]
				del l11lll11ll1_l1_
			else: groups = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭㥘"),l11ll1ll111_l1_[l11l1l1ll1_l1_],l11l1l_l1_ (u"ࠩࡢࡣࡌࡘࡏࡖࡒࡖࡣࡤ࠭㥙"))
			for group in groups:
				try: group,l1ll1l_l1_ = group
				except: l1ll1l_l1_ = l11l1l_l1_ (u"ࠪࠫ㥚")
				if l11l1l11111_l1_ in group.lower():
					if l11l1l1ll1_l1_!=3: l1l11111l1l_l1_ = group
					else:
						l1l11111ll1_l1_,l11l11llll1_l1_ = group.split(l11l1l_l1_ (u"ࠫࡤࡥࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ㥛"))
						if l11l1l11111_l1_ in l1l11111ll1_l1_.lower(): l1l11111l1l_l1_ = l1l11111ll1_l1_
						else: l1l11111l1l_l1_ = l11l11llll1_l1_
					l1l111lll11_l1_.append((group,l1l11111l1l_l1_,l11ll1ll111_l1_[l11l1l1ll1_l1_],l1ll1l_l1_))
			del groups
		l1l111lll11_l1_ = set(l1l111lll11_l1_)
		l11ll1lll11_l1_ = set(l11ll1lll11_l1_)
		l1l111lll11_l1_ = sorted(l1l111lll11_l1_,reverse=False,key=lambda key: key[1])
		l11ll1lll11_l1_ = sorted(l11ll1lll11_l1_,reverse=False,key=lambda key: key[0])
		WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"࡙ࠬࡅࡂࡔࡆࡌࠬ㥜"),(l11l11lllll_l1_,l11l1l11111_l1_),(l1l111lll11_l1_,l11ll1lll11_l1_),PERMANENT_CACHE)
	else: l1l111lll11_l1_,l11ll1lll11_l1_ = results
	groups = len(l1l111lll11_l1_)
	l11ll1_l1_ = len(l11ll1lll11_l1_)
	l11lll1_l1_ = int(l11ll111ll1_l1_)
	s1 = max(0,(l11lll1_l1_-1)*100)
	e1 = max(0,l11lll1_l1_*100)
	s2 = max(0,s1-groups)
	e2 = max(0,e1-groups)
	for group,l1l11111l1l_l1_,l1l111l1lll_l1_,l1ll1l_l1_ in l1l111lll11_l1_[s1:e1]:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㥝"),l1111l_l1_+l1l11111l1l_l1_,l1l111l1lll_l1_,714,l1ll1l_l1_,l11l1l_l1_ (u"ࠧ࠲ࠩ㥞"),group,l11l1l_l1_ (u"ࠨࠩ㥟"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㥠"):l1l11l11l11_l1_})
	del l1l111lll11_l1_
	for title,url,l1ll1l_l1_ in l11ll1lll11_l1_[s2:e2]:
		l1l111l1ll1_l1_ = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ㥡"))[-1]
		if l11l1l_l1_ (u"ࠫ࠳࠭㥢") in l1l111l1ll1_l1_ and l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ㥣") not in l1l111l1ll1_l1_: addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㥤"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"ࠧࠨ㥥"),l11l1l_l1_ (u"ࠨࠩ㥦"),l11l1l_l1_ (u"ࠩࠪ㥧"),{l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㥨"):l1l11l11l11_l1_})
		else: addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ㥩"),l1111l_l1_+title,url,715,l1ll1l_l1_,l11l1l_l1_ (u"ࠬ࠭㥪"),l11l1l_l1_ (u"࠭ࠧ㥫"),l11l1l_l1_ (u"ࠧࠨ㥬"),{l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㥭"):l1l11l11l11_l1_})
	del l11ll1lll11_l1_
	PAGINATION(l1l11l11l11_l1_,l11ll111ll1_l1_,l11l11lllll_l1_,719,groups+l11ll1_l1_,search+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧ㥮"))
	return
def PAGINATION(l1l11l11l11_l1_,l11ll111ll1_l1_,l11l11lllll_l1_,mode,total,text):
	if not l11ll111ll1_l1_: l11ll111ll1_l1_ = l11l1l_l1_ (u"ࠪ࠵ࠬ㥯")
	if l11ll111ll1_l1_!=l11l1l_l1_ (u"ࠫ࠶࠭㥰"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㥱"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ㥲")+str(1),l11l11lllll_l1_,mode,l11l1l_l1_ (u"ࠧࠨ㥳"),str(1),text,l11l1l_l1_ (u"ࠨࠩ㥴"),{l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㥵"):l1l11l11l11_l1_})
	if not total: total = 0
	l1l1l1l11_l1_ = int(total/100)+1
	for l11lll1_l1_ in range(2,l1l1l1l11_l1_):
		l1l1111l1ll_l1_ = (l11lll1_l1_%10==0 or int(l11ll111ll1_l1_)-4<l11lll1_l1_<int(l11ll111ll1_l1_)+4)
		l11ll1ll1ll_l1_ = (l1l1111l1ll_l1_ and int(l11ll111ll1_l1_)-40<l11lll1_l1_<int(l11ll111ll1_l1_)+40)
		if str(l11lll1_l1_)!=l11ll111ll1_l1_ and (l11lll1_l1_%100==0 or l11ll1ll1ll_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㥶"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ㥷")+str(l11lll1_l1_),l11l11lllll_l1_,mode,l11l1l_l1_ (u"ࠬ࠭㥸"),str(l11lll1_l1_),text,l11l1l_l1_ (u"࠭ࠧ㥹"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㥺"):l1l11l11l11_l1_})
	if str(l1l1l1l11_l1_)!=l11ll111ll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㥻"),l1111l_l1_+l11l1l_l1_ (u"ࠩฦาึࠦีโฯฬࠤࠬ㥼")+str(l1l1l1l11_l1_),l11l11lllll_l1_,mode,l11l1l_l1_ (u"ࠪࠫ㥽"),str(l1l1l1l11_l1_),text,l11l1l_l1_ (u"ࠫࠬ㥾"),{l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㥿"):l1l11l11l11_l1_})
	return
def GET_DBFILE_NAME(l1l11l11l11_l1_,l11l11lllll_l1_):
	#if l11l1l_l1_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭㦀") in l11l11lllll_l1_ or l11l1l_l1_ (u"ࠧࡗࡑࡇࡣࡔࡘࡉࡈࡋࡑࡅࡑ࠭㦁") in l11l11lllll_l1_: l1l1l1l11l_l1_ = iptv2_dbfile
	#else: l1l1l1l11l_l1_ = iptv1_dbfile
	l1l1l1l11l_l1_ = l11l1l1l1ll_l1_.replace(l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ㦂"),l11l1l_l1_ (u"ࠩࡢࠫ㦃")+l1l11l11l11_l1_)
	return l1l1l1l11l_l1_
def l1l1111l11l_l1_(l1l11l11l11_l1_):
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠪࠫ㦄"))
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ㦅"),l11l1l_l1_ (u"ࠬ࠭㦆"),l11l1l_l1_ (u"࠭ࠧ㦇"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㦈"),l11l1l_l1_ (u"ࠨ฻่่๏ฯࠠอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠠใัࠣฮาะวอࠢ฼ำฮࠦฯใษษๆࠥ࠴่ࠠๆࠣฮึ๐ฯࠡล้ࠤฯาไษࠢส่๊๊แศฬࠣห้ศๆࠡมࠪ㦉"))
	if l1ll111111_l1_!=1: return
	l1l11l11l1l_l1_(l1l11l11l11_l1_,False)
	counts = [0]
	for seq in range(1,l11ll1ll1l1_l1_+1):
		l1l111llll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳ࠳ࡶ࠰ࡸࡶࡱࡥࠧ㦊")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠪࡣࠬ㦋")+str(seq))
		if l1l111llll1_l1_: CREATE_STREAMS(l1l11l11l11_l1_,str(seq))
		counts.append(0)
	for l11l11lllll_l1_ in l11lll1111l_l1_:
		l11ll111l1l_l1_,l11ll11l11l_l1_,l1l11l1ll1l_l1_,l11ll1l1l11_l1_,l11ll111l11_l1_ = 0,{},[],[],[]
		for seq in range(1,l11ll1ll1l1_l1_+1):
			l1l111l1lll_l1_ = l11l11lllll_l1_+l11l1l_l1_ (u"ࠫࡤ࠭㦌")+str(seq)
			l11lll1lll1_l1_ = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠬࡪࡩࡤࡶࠪ㦍"),l1l111l1lll_l1_)
			try:
				l1l11l11ll1_l1_ = l11lll1lll1_l1_[l11l1l_l1_ (u"࠭࡟ࡠࡉࡕࡓ࡚ࡖࡓࡠࡡࠪ㦎")]
				count = l11lll1lll1_l1_[l11l1l_l1_ (u"ࠧࡠࡡࡆࡓ࡚ࡔࡔࡠࡡࠪ㦏")]
			except:
				l1l11l11ll1_l1_ = []
				count = l11l1l_l1_ (u"ࠨ࠲ࠪ㦐")
			for tuple in l1l11l11ll1_l1_:
				group,l111_l1_ = tuple
				l11lll11ll1_l1_ = l11lll1lll1_l1_[group]
				if group not in l11ll1l1l11_l1_:
					l11ll1l1l11_l1_.append(group)
					l11ll111l11_l1_.append(tuple)
					l11ll11l11l_l1_[group] = []
				l11ll11l11l_l1_[group] += l11lll11ll1_l1_
			DELETE_FROM_SQL3(l1l1l1l11l_l1_,l1l111l1lll_l1_)
			WRITE_TO_SQL3(l1l1l1l11l_l1_,l1l111l1lll_l1_,l11l1l_l1_ (u"ࠩࡢࡣࡈࡕࡕࡏࡖࡢࡣࠬ㦑"),count,PERMANENT_CACHE)
			counts[seq] += int(count)
		for group in l11ll1l1l11_l1_:
			l11lll11ll1_l1_ = list(set(l11ll11l11l_l1_[group]))
			l11ll111l1l_l1_ += len(l11lll11ll1_l1_)
			l1l11l1ll1l_l1_.append(l11lll11ll1_l1_)
		WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l11lllll_l1_,l11l1l_l1_ (u"ࠪࡣࡤࡉࡏࡖࡐࡗࡣࡤ࠭㦒"),str(l11ll111l1l_l1_),PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l11lllll_l1_,l11l1l_l1_ (u"ࠫࡤࡥࡇࡓࡑࡘࡔࡘࡥ࡟ࠨ㦓"),l11ll111l11_l1_,PERMANENT_CACHE)
		WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l11lllll_l1_,l11ll1l1l11_l1_,l1l11l1ll1l_l1_,PERMANENT_CACHE,True)
	l11llll1lll_l1_ = False
	for seq in range(1,l11ll1ll1l1_l1_+1):
		if int(counts[seq])>0:
			l1l111llll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡯࠶ࡹ࠳ࡻࡲ࡭ࡡࠪ㦔")+l1l11l11l11_l1_+l11l1l_l1_ (u"࠭࡟ࠨ㦕")+str(seq))
			WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠧࡍࡋࡑࡏࡤ࠭㦖")+str(seq),l11l1l_l1_ (u"ࠨࡡࡢࡐࡎࡔࡋࡠࡡࠪ㦗"),l1l111llll1_l1_,PERMANENT_CACHE)
			l11llll1lll_l1_ = True
	WRITE_TO_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠩࡇ࡙ࡒࡓ࡙ࠨ㦘"),l11l1l_l1_ (u"ࠪࡣࡤࡊࡕࡎࡏ࡜ࡣࡤ࠭㦙"),l11l1l_l1_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ㦚"),PERMANENT_CACHE)
	if l11llll1lll_l1_:
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㦛"),l11l1l_l1_ (u"࠭ࠧ㦜"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㦝"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ㦞")+l11l1l_l1_ (u"ࠩอ้ࠥาไษ่่ࠢๆอสࠡโࡐ࠷࡚ࠦฬะ์าอࠬ㦟")+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㦠"))
		l11lllll111_l1_(l1l11l11l11_l1_)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ㦡"))
	else: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㦢"),l11l1l_l1_ (u"࠭ࠧ㦣"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㦤"),l11l1l_l1_ (u"ࠨใื่ࠥฮำฮส้้ࠣ็วหࠢใࡑ࠸࡛ࠠ࠯ࠢฦัฯ๋วๅࠢิ์ฬฮืࠡโࡐ࠷࡚ࠦวๅฬํࠤศ์สࠡลูๅฯํวࠡๆ็ฬึ์วๆฮࠣ฾๏ืࠠึฯํัฮࠦ࠮࠯ࠢ฼่๊อࠠฤ่๋ࠣีํࠠศๆัำ๊ฯࠠหฯอหัࠦๅ็ๅࠣว๋ࠦสื์ไࠤฬ๊ัศสฺࠤอ์แิๅ่้ࠣฮั็ษ่ะࠥฮวิฬัำฬ๋ࠠใษษ้ฮࠦเࡎ࠵ࡘࠤฬ๊ๅ้ฮ๋ำฮࠦศ่าสࠤฬ๊ศา่ส้ั࠭㦥"))
	return
def l11lllll111_l1_(l1l11l11l11_l1_):
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ㦦"))
	if not CHECK_TABLES_EXIST(l1l11l11l11_l1_,True): return
	for seq in range(1,l11ll1ll1l1_l1_+1):
		l1l111llll1_l1_ = READ_FROM_SQL3(l1l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ㦧"),l11l1l_l1_ (u"ࠫࡑࡏࡎࡌࡡࠪ㦨")+str(seq),l11l1l_l1_ (u"ࠬࡥ࡟ࡍࡋࡑࡏࡤࡥࠧ㦩"))
		if l1l111llll1_l1_: l11ll111lll_l1_ = COUNTS(l1l11l11l11_l1_,str(seq))
	COUNTS(l1l11l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ㦪"))
	return
def l1l11l11l1l_l1_(l1l11l11l11_l1_,l1ll_l1_):
	if l1ll_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ㦫"),l11l1l_l1_ (u"ࠨࠩ㦬"),l11l1l_l1_ (u"ࠩࠪ㦭"),l11l1l_l1_ (u"ุ้ࠪำࠠๆๆไหฯࠦเࡎ࠵ࡘࠫ㦮"),l11l1l_l1_ (u"ࠫ์๊ࠠหำํำࠥอไรุ่้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢส่๊ิา็หࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠡมࠤࠤ࠳࠴ฺࠠๆ่หࠥอๆไࠢอืฯ฽ฺ๊ࠢไ๎ࠥษ๊๊ࠡๅฮࠥอไะะ๋่ࠥหไ๊ࠢๅหห๋ษࠡโࡐ࠷่࡚ࠦอๆหࠤ๊๊แศฬࠣไࡒ࠹ࡕࠡฮา๎ิฯࠧ㦯"))
		if l1ll111111_l1_!=1: return
	#for seq in range(1,l11ll1ll1l1_l1_+1):
	#	DELETE_FILES(str(seq),False)
	#DELETE_FILES(l11l1l_l1_ (u"ࠬ࠭㦰"),False)
	l1l1l1l11l_l1_ = GET_DBFILE_NAME(l1l11l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ㦱"))
	try: os.remove(l1l1l1l11l_l1_)
	except: pass
	for seq in range(1,l11ll1ll1l1_l1_+1):
		filename = l1l1111llll_l1_.replace(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ㦲"),l11l1l_l1_ (u"ࠨࡡࠪ㦳")+l1l11l11l11_l1_+l11l1l_l1_ (u"ࠩࡢࠫ㦴")+str(seq))
		l1l11l11lll_l1_ = os.path.join(addoncachefolder,filename)
		try: os.remove(l1l11l11lll_l1_)
		except: pass
	if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㦵"),l11l1l_l1_ (u"ࠫࠬ㦶"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㦷"),l11l1l_l1_ (u"࠭สๆ่ࠢืาࠦฬๆ์฼ࠤ๊๊แศฬࠣไࡒ࠹ࡕࠨ㦸"))
	return
COUNTRIES_CODES = {
 l11l1l_l1_ (u"ࠧࡂࡈࠪ㦹"):l11l1l_l1_ (u"ࠨࡃࡩ࡫࡭ࡧ࡮ࡪࡵࡷࡥࡳ࠭㦺")
,l11l1l_l1_ (u"ࠩࡄࡐࠬ㦻"):l11l1l_l1_ (u"ࠪࡅࡱࡨࡡ࡯࡫ࡤࠫ㦼")
,l11l1l_l1_ (u"ࠫࡉࡠࠧ㦽"):l11l1l_l1_ (u"ࠬࡇ࡬ࡨࡧࡵ࡭ࡦ࠭㦾")
,l11l1l_l1_ (u"࠭ࡁࡔࠩ㦿"):l11l1l_l1_ (u"ࠧࡂ࡯ࡨࡶ࡮ࡩࡡ࡯ࠢࡖࡥࡲࡵࡡࠨ㧀")
,l11l1l_l1_ (u"ࠨࡃࡇࠫ㧁"):l11l1l_l1_ (u"ࠩࡄࡲࡩࡵࡲࡳࡣࠪ㧂")
,l11l1l_l1_ (u"ࠪࡅࡔ࠭㧃"):l11l1l_l1_ (u"ࠫࡆࡴࡧࡰ࡮ࡤࠫ㧄")
,l11l1l_l1_ (u"ࠬࡇࡉࠨ㧅"):l11l1l_l1_ (u"࠭ࡁ࡯ࡩࡸ࡭ࡱࡲࡡࠨ㧆")
,l11l1l_l1_ (u"ࠧࡂࡓࠪ㧇"):l11l1l_l1_ (u"ࠨࡃࡱࡸࡦࡸࡣࡵ࡫ࡦࡥࠬ㧈")
,l11l1l_l1_ (u"ࠩࡄࡋࠬ㧉"):l11l1l_l1_ (u"ࠪࡅࡳࡺࡩࡨࡷࡤࠤࡦࡴࡤࠡࡄࡤࡶࡧࡻࡤࡢࠩ㧊")
,l11l1l_l1_ (u"ࠫࡆࡘࠧ㧋"):l11l1l_l1_ (u"ࠬࡇࡲࡨࡧࡱࡸ࡮ࡴࡡࠨ㧌")
,l11l1l_l1_ (u"࠭ࡁࡎࠩ㧍"):l11l1l_l1_ (u"ࠧࡂࡴࡰࡩࡳ࡯ࡡࠨ㧎")
,l11l1l_l1_ (u"ࠨࡃ࡚ࠫ㧏"):l11l1l_l1_ (u"ࠩࡄࡶࡺࡨࡡࠨ㧐")
,l11l1l_l1_ (u"ࠪࡅ࡚࠭㧑"):l11l1l_l1_ (u"ࠫࡆࡻࡳࡵࡴࡤࡰ࡮ࡧࠧ㧒")
,l11l1l_l1_ (u"ࠬࡇࡔࠨ㧓"):l11l1l_l1_ (u"࠭ࡁࡶࡵࡷࡶ࡮ࡧࠧ㧔")
,l11l1l_l1_ (u"ࠧࡂ࡜ࠪ㧕"):l11l1l_l1_ (u"ࠨࡃࡽࡩࡷࡨࡡࡪ࡬ࡤࡲࠬ㧖")
,l11l1l_l1_ (u"ࠩࡅࡗࠬ㧗"):l11l1l_l1_ (u"ࠪࡆࡦ࡮ࡡ࡮ࡣࡶࠫ㧘")
,l11l1l_l1_ (u"ࠫࡇࡎࠧ㧙"):l11l1l_l1_ (u"ࠬࡈࡡࡩࡴࡤ࡭ࡳ࠭㧚")
,l11l1l_l1_ (u"࠭ࡂࡅࠩ㧛"):l11l1l_l1_ (u"ࠧࡃࡣࡱ࡫ࡱࡧࡤࡦࡵ࡫ࠫ㧜")
,l11l1l_l1_ (u"ࠨࡄࡅࠫ㧝"):l11l1l_l1_ (u"ࠩࡅࡥࡷࡨࡡࡥࡱࡶࠫ㧞")
,l11l1l_l1_ (u"ࠪࡆ࡞࠭㧟"):l11l1l_l1_ (u"ࠫࡇ࡫࡬ࡢࡴࡸࡷࠬ㧠")
,l11l1l_l1_ (u"ࠬࡈࡅࠨ㧡"):l11l1l_l1_ (u"࠭ࡂࡦ࡮ࡪ࡭ࡺࡳࠧ㧢")
,l11l1l_l1_ (u"ࠧࡃ࡜ࠪ㧣"):l11l1l_l1_ (u"ࠨࡄࡨࡰ࡮ࢀࡥࠨ㧤")
,l11l1l_l1_ (u"ࠩࡅࡎࠬ㧥"):l11l1l_l1_ (u"ࠪࡆࡪࡴࡩ࡯ࠩ㧦")
,l11l1l_l1_ (u"ࠫࡇࡓࠧ㧧"):l11l1l_l1_ (u"ࠬࡈࡥࡳ࡯ࡸࡨࡦ࠭㧨")
,l11l1l_l1_ (u"࠭ࡂࡕࠩ㧩"):l11l1l_l1_ (u"ࠧࡃࡪࡸࡸࡦࡴࠧ㧪")
,l11l1l_l1_ (u"ࠨࡄࡒࠫ㧫"):l11l1l_l1_ (u"ࠩࡅࡳࡱ࡯ࡶࡪࡣࠪ㧬")
,l11l1l_l1_ (u"ࠪࡆࡖ࠭㧭"):l11l1l_l1_ (u"ࠫࡇࡵ࡮ࡢ࡫ࡵࡩࠬ㧮")
,l11l1l_l1_ (u"ࠬࡈࡁࠨ㧯"):l11l1l_l1_ (u"࠭ࡂࡰࡵࡱ࡭ࡦࠦࡡ࡯ࡦࠣࡌࡪࡸࡺࡦࡩࡲࡺ࡮ࡴࡡࠨ㧰")
,l11l1l_l1_ (u"ࠧࡃ࡙ࠪ㧱"):l11l1l_l1_ (u"ࠨࡄࡲࡸࡸࡽࡡ࡯ࡣࠪ㧲")
,l11l1l_l1_ (u"ࠩࡅ࡚ࠬ㧳"):l11l1l_l1_ (u"ࠪࡆࡴࡻࡶࡦࡶࠣࡍࡸࡲࡡ࡯ࡦࠪ㧴")
,l11l1l_l1_ (u"ࠫࡇࡘࠧ㧵"):l11l1l_l1_ (u"ࠬࡈࡲࡢࡼ࡬ࡰࠬ㧶")
,l11l1l_l1_ (u"࠭ࡉࡐࠩ㧷"):l11l1l_l1_ (u"ࠧࡃࡴ࡬ࡸ࡮ࡹࡨࠡࡋࡱࡨ࡮ࡧ࡮ࠡࡑࡦࡩࡦࡴࠠࡕࡧࡵࡶ࡮ࡺ࡯ࡳࡻࠪ㧸")
,l11l1l_l1_ (u"ࠨࡘࡊࠫ㧹"):l11l1l_l1_ (u"ࠩࡅࡶ࡮ࡺࡩࡴࡪ࡚ࠣ࡮ࡸࡧࡪࡰࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ㧺")
,l11l1l_l1_ (u"ࠪࡆࡓ࠭㧻"):l11l1l_l1_ (u"ࠫࡇࡸࡵ࡯ࡧ࡬ࠫ㧼")
,l11l1l_l1_ (u"ࠬࡈࡇࠨ㧽"):l11l1l_l1_ (u"࠭ࡂࡶ࡮ࡪࡥࡷ࡯ࡡࠨ㧾")
,l11l1l_l1_ (u"ࠧࡃࡈࠪ㧿"):l11l1l_l1_ (u"ࠨࡄࡸࡶࡰ࡯࡮ࡢࠢࡉࡥࡸࡵࠧ㨀")
,l11l1l_l1_ (u"ࠩࡅࡍࠬ㨁"):l11l1l_l1_ (u"ࠪࡆࡺࡸࡵ࡯ࡦ࡬ࠫ㨂")
,l11l1l_l1_ (u"ࠫࡐࡎࠧ㨃"):l11l1l_l1_ (u"ࠬࡉࡡ࡮ࡤࡲࡨ࡮ࡧࠧ㨄")
,l11l1l_l1_ (u"࠭ࡃࡎࠩ㨅"):l11l1l_l1_ (u"ࠧࡄࡣࡰࡩࡷࡵ࡯࡯ࠩ㨆")
,l11l1l_l1_ (u"ࠨࡅࡄࠫ㨇"):l11l1l_l1_ (u"ࠩࡆࡥࡳࡧࡤࡢࠩ㨈")
,l11l1l_l1_ (u"ࠪࡇ࡛࠭㨉"):l11l1l_l1_ (u"ࠫࡈࡧࡰࡦ࡙ࠢࡩࡷࡪࡥࠨ㨊")
,l11l1l_l1_ (u"ࠬࡑ࡙ࠨ㨋"):l11l1l_l1_ (u"࠭ࡃࡢࡻࡰࡥࡳࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㨌")
,l11l1l_l1_ (u"ࠧࡄࡈࠪ㨍"):l11l1l_l1_ (u"ࠨࡅࡨࡲࡹࡸࡡ࡭ࠢࡄࡪࡷ࡯ࡣࡢࡰࠣࡖࡪࡶࡵࡣ࡮࡬ࡧࠬ㨎")
,l11l1l_l1_ (u"ࠩࡗࡈࠬ㨏"):l11l1l_l1_ (u"ࠪࡇ࡭ࡧࡤࠨ㨐")
,l11l1l_l1_ (u"ࠫࡈࡒࠧ㨑"):l11l1l_l1_ (u"ࠬࡉࡨࡪ࡮ࡨࠫ㨒")
,l11l1l_l1_ (u"࠭ࡃࡏࠩ㨓"):l11l1l_l1_ (u"ࠧࡄࡪ࡬ࡲࡦ࠭㨔")
,l11l1l_l1_ (u"ࠨࡅ࡛ࠫ㨕"):l11l1l_l1_ (u"ࠩࡆ࡬ࡷ࡯ࡳࡵ࡯ࡤࡷࠥࡏࡳ࡭ࡣࡱࡨࠬ㨖")
,l11l1l_l1_ (u"ࠪࡇࡈ࠭㨗"):l11l1l_l1_ (u"ࠫࡈࡵࡣࡰࡵࠣࠬࡐ࡫ࡥ࡭࡫ࡱ࡫࠮ࠦࡉࡴ࡮ࡤࡲࡩࡹࠧ㨘")
,l11l1l_l1_ (u"ࠬࡉࡏࠨ㨙"):l11l1l_l1_ (u"࠭ࡃࡰ࡮ࡲࡱࡧ࡯ࡡࠨ㨚")
,l11l1l_l1_ (u"ࠧࡌࡏࠪ㨛"):l11l1l_l1_ (u"ࠨࡅࡲࡱࡴࡸ࡯ࡴࠩ㨜")
,l11l1l_l1_ (u"ࠩࡆࡏࠬ㨝"):l11l1l_l1_ (u"ࠪࡇࡴࡵ࡫ࠡࡋࡶࡰࡦࡴࡤࡴࠩ㨞")
,l11l1l_l1_ (u"ࠫࡈࡘࠧ㨟"):l11l1l_l1_ (u"ࠬࡉ࡯ࡴࡶࡤࠤࡗ࡯ࡣࡢࠩ㨠")
,l11l1l_l1_ (u"࠭ࡈࡓࠩ㨡"):l11l1l_l1_ (u"ࠧࡄࡴࡲࡥࡹ࡯ࡡࠨ㨢")
,l11l1l_l1_ (u"ࠨࡅࡘࠫ㨣"):l11l1l_l1_ (u"ࠩࡆࡹࡧࡧࠧ㨤")
,l11l1l_l1_ (u"ࠪࡇ࡜࠭㨥"):l11l1l_l1_ (u"ࠫࡈࡻࡲࡢࡥࡤࡳࠬ㨦")
,l11l1l_l1_ (u"ࠬࡉ࡙ࠨ㨧"):l11l1l_l1_ (u"࠭ࡃࡺࡲࡵࡹࡸ࠭㨨")
,l11l1l_l1_ (u"ࠧࡄ࡜ࠪ㨩"):l11l1l_l1_ (u"ࠨࡅࡽࡩࡨ࡮ࠠࡓࡧࡳࡹࡧࡲࡩࡤࠩ㨪")
,l11l1l_l1_ (u"ࠩࡆࡈࠬ㨫"):l11l1l_l1_ (u"ࠪࡈࡪࡳ࡯ࡤࡴࡤࡸ࡮ࡩࠠࡓࡧࡳࡹࡧࡲࡩࡤࠢࡲࡪࠥࡺࡨࡦࠢࡆࡳࡳ࡭࡯ࠨ㨬")
,l11l1l_l1_ (u"ࠫࡉࡑࠧ㨭"):l11l1l_l1_ (u"ࠬࡊࡥ࡯࡯ࡤࡶࡰ࠭㨮")
,l11l1l_l1_ (u"࠭ࡄࡋࠩ㨯"):l11l1l_l1_ (u"ࠧࡅ࡬࡬ࡦࡴࡻࡴࡪࠩ㨰")
,l11l1l_l1_ (u"ࠨࡆࡐࠫ㨱"):l11l1l_l1_ (u"ࠩࡇࡳࡲ࡯࡮ࡪࡥࡤࠫ㨲")
,l11l1l_l1_ (u"ࠪࡈࡔ࠭㨳"):l11l1l_l1_ (u"ࠫࡉࡵ࡭ࡪࡰ࡬ࡧࡦࡴࠠࡓࡧࡳࡹࡧࡲࡩࡤࠩ㨴")
,l11l1l_l1_ (u"࡚ࠬࡌࠨ㨵"):l11l1l_l1_ (u"࠭ࡅࡢࡵࡷࠤ࡙࡯࡭ࡰࡴࠪ㨶")
,l11l1l_l1_ (u"ࠧࡆࡅࠪ㨷"):l11l1l_l1_ (u"ࠨࡇࡦࡹࡦࡪ࡯ࡳࠩ㨸")
,l11l1l_l1_ (u"ࠩࡈࡋࠬ㨹"):l11l1l_l1_ (u"ࠪࡉ࡬ࡿࡰࡵࠩ㨺")
,l11l1l_l1_ (u"ࠫࡘ࡜ࠧ㨻"):l11l1l_l1_ (u"ࠬࡋ࡬ࠡࡕࡤࡰࡻࡧࡤࡰࡴࠪ㨼")
,l11l1l_l1_ (u"࠭ࡇࡒࠩ㨽"):l11l1l_l1_ (u"ࠧࡆࡳࡸࡥࡹࡵࡲࡪࡣ࡯ࠤࡌࡻࡩ࡯ࡧࡤࠫ㨾")
,l11l1l_l1_ (u"ࠨࡇࡕࠫ㨿"):l11l1l_l1_ (u"ࠩࡈࡶ࡮ࡺࡲࡦࡣࠪ㩀")
,l11l1l_l1_ (u"ࠪࡉࡊ࠭㩁"):l11l1l_l1_ (u"ࠫࡊࡹࡴࡰࡰ࡬ࡥࠬ㩂")
,l11l1l_l1_ (u"ࠬࡋࡔࠨ㩃"):l11l1l_l1_ (u"࠭ࡅࡵࡪ࡬ࡳࡵ࡯ࡡࠨ㩄")
,l11l1l_l1_ (u"ࠧࡇࡍࠪ㩅"):l11l1l_l1_ (u"ࠨࡈࡤࡰࡰࡲࡡ࡯ࡦࠣࡍࡸࡲࡡ࡯ࡦࡶࠫ㩆")
,l11l1l_l1_ (u"ࠩࡉࡓࠬ㩇"):l11l1l_l1_ (u"ࠪࡊࡦࡸ࡯ࡦࠢࡌࡷࡱࡧ࡮ࡥࡵࠪ㩈")
,l11l1l_l1_ (u"ࠫࡋࡐࠧ㩉"):l11l1l_l1_ (u"ࠬࡌࡩ࡫࡫ࠪ㩊")
,l11l1l_l1_ (u"࠭ࡆࡊࠩ㩋"):l11l1l_l1_ (u"ࠧࡇ࡫ࡱࡰࡦࡴࡤࠨ㩌")
,l11l1l_l1_ (u"ࠨࡈࡕࠫ㩍"):l11l1l_l1_ (u"ࠩࡉࡶࡦࡴࡣࡦࠩ㩎")
,l11l1l_l1_ (u"ࠪࡋࡋ࠭㩏"):l11l1l_l1_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠤࡌࡻࡩࡢࡰࡤࠫ㩐")
,l11l1l_l1_ (u"ࠬࡖࡆࠨ㩑"):l11l1l_l1_ (u"࠭ࡆࡳࡧࡱࡧ࡭ࠦࡐࡰ࡮ࡼࡲࡪࡹࡩࡢࠩ㩒")
,l11l1l_l1_ (u"ࠧࡕࡈࠪ㩓"):l11l1l_l1_ (u"ࠨࡈࡵࡩࡳࡩࡨࠡࡕࡲࡹࡹ࡮ࡥࡳࡰࠣࡘࡪࡸࡲࡪࡶࡲࡶ࡮࡫ࡳࠨ㩔")
,l11l1l_l1_ (u"ࠩࡊࡅࠬ㩕"):l11l1l_l1_ (u"ࠪࡋࡦࡨ࡯࡯ࠩ㩖")
,l11l1l_l1_ (u"ࠫࡌࡓࠧ㩗"):l11l1l_l1_ (u"ࠬࡍࡡ࡮ࡤ࡬ࡥࠬ㩘")
,l11l1l_l1_ (u"࠭ࡇࡆࠩ㩙"):l11l1l_l1_ (u"ࠧࡈࡧࡲࡶ࡬࡯ࡡࠨ㩚")
,l11l1l_l1_ (u"ࠨࡆࡈࠫ㩛"):l11l1l_l1_ (u"ࠩࡊࡩࡷࡳࡡ࡯ࡻࠪ㩜")
,l11l1l_l1_ (u"ࠪࡋࡍ࠭㩝"):l11l1l_l1_ (u"ࠫࡌ࡮ࡡ࡯ࡣࠪ㩞")
,l11l1l_l1_ (u"ࠬࡍࡉࠨ㩟"):l11l1l_l1_ (u"࠭ࡇࡪࡤࡵࡥࡱࡺࡡࡳࠩ㩠")
,l11l1l_l1_ (u"ࠧࡈࡔࠪ㩡"):l11l1l_l1_ (u"ࠨࡉࡵࡩࡪࡩࡥࠨ㩢")
,l11l1l_l1_ (u"ࠩࡊࡐࠬ㩣"):l11l1l_l1_ (u"ࠪࡋࡷ࡫ࡥ࡯࡮ࡤࡲࡩ࠭㩤")
,l11l1l_l1_ (u"ࠫࡌࡊࠧ㩥"):l11l1l_l1_ (u"ࠬࡍࡲࡦࡰࡤࡨࡦ࠭㩦")
,l11l1l_l1_ (u"࠭ࡇࡑࠩ㩧"):l11l1l_l1_ (u"ࠧࡈࡷࡤࡨࡪࡲ࡯ࡶࡲࡨࠫ㩨")
,l11l1l_l1_ (u"ࠨࡉࡘࠫ㩩"):l11l1l_l1_ (u"ࠩࡊࡹࡦࡳࠧ㩪")
,l11l1l_l1_ (u"ࠪࡋ࡙࠭㩫"):l11l1l_l1_ (u"ࠫࡌࡻࡡࡵࡧࡰࡥࡱࡧࠧ㩬")
,l11l1l_l1_ (u"ࠬࡍࡇࠨ㩭"):l11l1l_l1_ (u"࠭ࡇࡶࡧࡵࡲࡸ࡫ࡹࠨ㩮")
,l11l1l_l1_ (u"ࠧࡈࡐࠪ㩯"):l11l1l_l1_ (u"ࠨࡉࡸ࡭ࡳ࡫ࡡࠨ㩰")
,l11l1l_l1_ (u"ࠩࡊ࡛ࠬ㩱"):l11l1l_l1_ (u"ࠪࡋࡺ࡯࡮ࡦࡣ࠰ࡆ࡮ࡹࡳࡢࡷࠪ㩲")
,l11l1l_l1_ (u"ࠫࡌ࡟ࠧ㩳"):l11l1l_l1_ (u"ࠬࡍࡵࡺࡣࡱࡥࠬ㩴")
,l11l1l_l1_ (u"࠭ࡈࡕࠩ㩵"):l11l1l_l1_ (u"ࠧࡉࡣ࡬ࡸ࡮࠭㩶")
,l11l1l_l1_ (u"ࠨࡊࡐࠫ㩷"):l11l1l_l1_ (u"ࠩࡋࡩࡦࡸࡤࠡࡋࡶࡰࡦࡴࡤࠡࡣࡱࡨࠥࡓࡣࡅࡱࡱࡥࡱࡪࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㩸")
,l11l1l_l1_ (u"ࠪࡌࡓ࠭㩹"):l11l1l_l1_ (u"ࠫࡍࡵ࡮ࡥࡷࡵࡥࡸ࠭㩺")
,l11l1l_l1_ (u"ࠬࡎࡋࠨ㩻"):l11l1l_l1_ (u"࠭ࡈࡰࡰࡪࠤࡐࡵ࡮ࡨࠩ㩼")
,l11l1l_l1_ (u"ࠧࡉࡗࠪ㩽"):l11l1l_l1_ (u"ࠨࡊࡸࡲ࡬ࡧࡲࡺࠩ㩾")
,l11l1l_l1_ (u"ࠩࡌࡗࠬ㩿"):l11l1l_l1_ (u"ࠪࡍࡨ࡫࡬ࡢࡰࡧࠫ㪀")
,l11l1l_l1_ (u"ࠫࡎࡔࠧ㪁"):l11l1l_l1_ (u"ࠬࡏ࡮ࡥ࡫ࡤࠫ㪂")
,l11l1l_l1_ (u"࠭ࡉࡅࠩ㪃"):l11l1l_l1_ (u"ࠧࡊࡰࡧࡳࡳ࡫ࡳࡪࡣࠪ㪄")
,l11l1l_l1_ (u"ࠨࡋࡕࠫ㪅"):l11l1l_l1_ (u"ࠩࡌࡶࡦࡴࠧ㪆")
,l11l1l_l1_ (u"ࠪࡍࡖ࠭㪇"):l11l1l_l1_ (u"ࠫࡎࡸࡡࡲࠩ㪈")
,l11l1l_l1_ (u"ࠬࡏࡅࠨ㪉"):l11l1l_l1_ (u"࠭ࡉࡳࡧ࡯ࡥࡳࡪࠧ㪊")
,l11l1l_l1_ (u"ࠧࡊࡏࠪ㪋"):l11l1l_l1_ (u"ࠨࡋࡶࡰࡪࠦ࡯ࡧࠢࡐࡥࡳ࠭㪌")
,l11l1l_l1_ (u"ࠩࡌࡐࠬ㪍"):l11l1l_l1_ (u"ࠪࡍࡸࡸࡡࡦ࡮ࠪ㪎")
,l11l1l_l1_ (u"ࠫࡎ࡚ࠧ㪏"):l11l1l_l1_ (u"ࠬࡏࡴࡢ࡮ࡼࠫ㪐")
,l11l1l_l1_ (u"࠭ࡃࡊࠩ㪑"):l11l1l_l1_ (u"ࠧࡊࡸࡲࡶࡾࠦࡃࡰࡣࡶࡸࠬ㪒")
,l11l1l_l1_ (u"ࠨࡌࡐࠫ㪓"):l11l1l_l1_ (u"ࠩࡍࡥࡲࡧࡩࡤࡣࠪ㪔")
,l11l1l_l1_ (u"ࠪࡎࡕ࠭㪕"):l11l1l_l1_ (u"ࠫࡏࡧࡰࡢࡰࠪ㪖")
,l11l1l_l1_ (u"ࠬࡐࡅࠨ㪗"):l11l1l_l1_ (u"࠭ࡊࡦࡴࡶࡩࡾ࠭㪘")
,l11l1l_l1_ (u"ࠧࡋࡑࠪ㪙"):l11l1l_l1_ (u"ࠨࡌࡲࡶࡩࡧ࡮ࠨ㪚")
,l11l1l_l1_ (u"ࠩࡎ࡞ࠬ㪛"):l11l1l_l1_ (u"ࠪࡏࡦࢀࡡ࡬ࡪࡶࡸࡦࡴࠧ㪜")
,l11l1l_l1_ (u"ࠫࡐࡋࠧ㪝"):l11l1l_l1_ (u"ࠬࡑࡥ࡯ࡻࡤࠫ㪞")
,l11l1l_l1_ (u"࠭ࡋࡊࠩ㪟"):l11l1l_l1_ (u"ࠧࡌ࡫ࡵ࡭ࡧࡧࡴࡪࠩ㪠")
,l11l1l_l1_ (u"ࠨ࡚ࡎࠫ㪡"):l11l1l_l1_ (u"ࠩࡎࡳࡸࡵࡶࡰࠩ㪢")
,l11l1l_l1_ (u"ࠪࡏ࡜࠭㪣"):l11l1l_l1_ (u"ࠫࡐࡻࡷࡢ࡫ࡷࠫ㪤")
,l11l1l_l1_ (u"ࠬࡑࡇࠨ㪥"):l11l1l_l1_ (u"࠭ࡋࡺࡴࡪࡽࡿࡹࡴࡢࡰࠪ㪦")
,l11l1l_l1_ (u"ࠧࡍࡃࠪ㪧"):l11l1l_l1_ (u"ࠨࡎࡤࡳࡸ࠭㪨")
,l11l1l_l1_ (u"ࠩࡏ࡚ࠬ㪩"):l11l1l_l1_ (u"ࠪࡐࡦࡺࡶࡪࡣࠪ㪪")
,l11l1l_l1_ (u"ࠫࡑࡈࠧ㪫"):l11l1l_l1_ (u"ࠬࡒࡥࡣࡣࡱࡳࡳ࠭㪬")
,l11l1l_l1_ (u"࠭ࡌࡔࠩ㪭"):l11l1l_l1_ (u"ࠧࡍࡧࡶࡳࡹ࡮࡯ࠨ㪮")
,l11l1l_l1_ (u"ࠨࡎࡕࠫ㪯"):l11l1l_l1_ (u"ࠩࡏ࡭ࡧ࡫ࡲࡪࡣࠪ㪰")
,l11l1l_l1_ (u"ࠪࡐ࡞࠭㪱"):l11l1l_l1_ (u"ࠫࡑ࡯ࡢࡺࡣࠪ㪲")
,l11l1l_l1_ (u"ࠬࡒࡉࠨ㪳"):l11l1l_l1_ (u"࠭ࡌࡪࡧࡦ࡬ࡹ࡫࡮ࡴࡶࡨ࡭ࡳ࠭㪴")
,l11l1l_l1_ (u"ࠧࡍࡖࠪ㪵"):l11l1l_l1_ (u"ࠨࡎ࡬ࡸ࡭ࡻࡡ࡯࡫ࡤࠫ㪶")
,l11l1l_l1_ (u"ࠩࡏ࡙ࠬ㪷"):l11l1l_l1_ (u"ࠪࡐࡺࡾࡥ࡮ࡤࡲࡹࡷ࡭ࠧ㪸")
,l11l1l_l1_ (u"ࠫࡒࡕࠧ㪹"):l11l1l_l1_ (u"ࠬࡓࡡࡤࡣࡲࠫ㪺")
,l11l1l_l1_ (u"࠭ࡍࡈࠩ㪻"):l11l1l_l1_ (u"ࠧࡎࡣࡧࡥ࡬ࡧࡳࡤࡣࡵࠫ㪼")
,l11l1l_l1_ (u"ࠨࡏ࡚ࠫ㪽"):l11l1l_l1_ (u"ࠩࡐࡥࡱࡧࡷࡪࠩ㪾")
,l11l1l_l1_ (u"ࠪࡑ࡞࠭㪿"):l11l1l_l1_ (u"ࠫࡒࡧ࡬ࡢࡻࡶ࡭ࡦ࠭㫀")
,l11l1l_l1_ (u"ࠬࡓࡖࠨ㫁"):l11l1l_l1_ (u"࠭ࡍࡢ࡮ࡧ࡭ࡻ࡫ࡳࠨ㫂")
,l11l1l_l1_ (u"ࠧࡎࡎࠪ㫃"):l11l1l_l1_ (u"ࠨࡏࡤࡰ࡮࠭㫄")
,l11l1l_l1_ (u"ࠩࡐࡘࠬ㫅"):l11l1l_l1_ (u"ࠪࡑࡦࡲࡴࡢࠩ㫆")
,l11l1l_l1_ (u"ࠫࡒࡎࠧ㫇"):l11l1l_l1_ (u"ࠬࡓࡡࡳࡵ࡫ࡥࡱࡲࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㫈")
,l11l1l_l1_ (u"࠭ࡍࡒࠩ㫉"):l11l1l_l1_ (u"ࠧࡎࡣࡵࡸ࡮ࡴࡩࡲࡷࡨࠫ㫊")
,l11l1l_l1_ (u"ࠨࡏࡕࠫ㫋"):l11l1l_l1_ (u"ࠩࡐࡥࡺࡸࡩࡵࡣࡱ࡭ࡦ࠭㫌")
,l11l1l_l1_ (u"ࠪࡑ࡚࠭㫍"):l11l1l_l1_ (u"ࠫࡒࡧࡵࡳ࡫ࡷ࡭ࡺࡹࠧ㫎")
,l11l1l_l1_ (u"ࠬ࡟ࡔࠨ㫏"):l11l1l_l1_ (u"࠭ࡍࡢࡻࡲࡸࡹ࡫ࠧ㫐")
,l11l1l_l1_ (u"ࠧࡎ࡚ࠪ㫑"):l11l1l_l1_ (u"ࠨࡏࡨࡼ࡮ࡩ࡯ࠨ㫒")
,l11l1l_l1_ (u"ࠩࡉࡑࠬ㫓"):l11l1l_l1_ (u"ࠪࡑ࡮ࡩࡲࡰࡰࡨࡷ࡮ࡧࠧ㫔")
,l11l1l_l1_ (u"ࠫࡒࡊࠧ㫕"):l11l1l_l1_ (u"ࠬࡓ࡯࡭ࡦࡲࡺࡦ࠭㫖")
,l11l1l_l1_ (u"࠭ࡍࡄࠩ㫗"):l11l1l_l1_ (u"ࠧࡎࡱࡱࡥࡨࡵࠧ㫘")
,l11l1l_l1_ (u"ࠨࡏࡑࠫ㫙"):l11l1l_l1_ (u"ࠩࡐࡳࡳ࡭࡯࡭࡫ࡤࠫ㫚")
,l11l1l_l1_ (u"ࠪࡑࡊ࠭㫛"):l11l1l_l1_ (u"ࠫࡒࡵ࡮ࡵࡧࡱࡩ࡬ࡸ࡯ࠨ㫜")
,l11l1l_l1_ (u"ࠬࡓࡓࠨ㫝"):l11l1l_l1_ (u"࠭ࡍࡰࡰࡷࡷࡪࡸࡲࡢࡶࠪ㫞")
,l11l1l_l1_ (u"ࠧࡎࡃࠪ㫟"):l11l1l_l1_ (u"ࠨࡏࡲࡶࡴࡩࡣࡰࠩ㫠")
,l11l1l_l1_ (u"ࠩࡐ࡞ࠬ㫡"):l11l1l_l1_ (u"ࠪࡑࡴࢀࡡ࡮ࡤ࡬ࡵࡺ࡫ࠧ㫢")
,l11l1l_l1_ (u"ࠫࡒࡓࠧ㫣"):l11l1l_l1_ (u"ࠬࡓࡹࡢࡰࡰࡥࡷࠦࠨࡃࡷࡵࡱࡦ࠯ࠧ㫤")
,l11l1l_l1_ (u"࠭ࡎࡂࠩ㫥"):l11l1l_l1_ (u"ࠧࡏࡣࡰ࡭ࡧ࡯ࡡࠨ㫦")
,l11l1l_l1_ (u"ࠨࡐࡕࠫ㫧"):l11l1l_l1_ (u"ࠩࡑࡥࡺࡸࡵࠨ㫨")
,l11l1l_l1_ (u"ࠪࡒࡕ࠭㫩"):l11l1l_l1_ (u"ࠫࡓ࡫ࡰࡢ࡮ࠪ㫪")
,l11l1l_l1_ (u"ࠬࡔࡌࠨ㫫"):l11l1l_l1_ (u"࠭ࡎࡦࡶ࡫ࡩࡷࡲࡡ࡯ࡦࡶࠫ㫬")
,l11l1l_l1_ (u"ࠧࡏࡅࠪ㫭"):l11l1l_l1_ (u"ࠨࡐࡨࡻࠥࡉࡡ࡭ࡧࡧࡳࡳ࡯ࡡࠨ㫮")
,l11l1l_l1_ (u"ࠩࡑ࡞ࠬ㫯"):l11l1l_l1_ (u"ࠪࡒࡪࡽ࡛ࠠࡧࡤࡰࡦࡴࡤࠨ㫰")
,l11l1l_l1_ (u"ࠫࡓࡏࠧ㫱"):l11l1l_l1_ (u"ࠬࡔࡩࡤࡣࡵࡥ࡬ࡻࡡࠨ㫲")
,l11l1l_l1_ (u"࠭ࡎࡆࠩ㫳"):l11l1l_l1_ (u"ࠧࡏ࡫ࡪࡩࡷ࠭㫴")
,l11l1l_l1_ (u"ࠨࡐࡊࠫ㫵"):l11l1l_l1_ (u"ࠩࡑ࡭࡬࡫ࡲࡪࡣࠪ㫶")
,l11l1l_l1_ (u"ࠪࡒ࡚࠭㫷"):l11l1l_l1_ (u"ࠫࡓ࡯ࡵࡦࠩ㫸")
,l11l1l_l1_ (u"ࠬࡔࡆࠨ㫹"):l11l1l_l1_ (u"࠭ࡎࡰࡴࡩࡳࡱࡱࠠࡊࡵ࡯ࡥࡳࡪࠧ㫺")
,l11l1l_l1_ (u"ࠧࡌࡒࠪ㫻"):l11l1l_l1_ (u"ࠨࡐࡲࡶࡹ࡮ࠠࡌࡱࡵࡩࡦ࠭㫼")
,l11l1l_l1_ (u"ࠩࡐࡏࠬ㫽"):l11l1l_l1_ (u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ㫾")
,l11l1l_l1_ (u"ࠫࡒࡖࠧ㫿"):l11l1l_l1_ (u"ࠬࡔ࡯ࡳࡶ࡫ࡩࡷࡴࠠࡎࡣࡵ࡭ࡦࡴࡡࠡࡋࡶࡰࡦࡴࡤࡴࠩ㬀")
,l11l1l_l1_ (u"࠭ࡎࡐࠩ㬁"):l11l1l_l1_ (u"ࠧࡏࡱࡵࡻࡦࡿࠧ㬂")
,l11l1l_l1_ (u"ࠨࡑࡐࠫ㬃"):l11l1l_l1_ (u"ࠩࡒࡱࡦࡴࠧ㬄")
,l11l1l_l1_ (u"ࠪࡔࡐ࠭㬅"):l11l1l_l1_ (u"ࠫࡕࡧ࡫ࡪࡵࡷࡥࡳ࠭㬆")
,l11l1l_l1_ (u"ࠬࡖࡗࠨ㬇"):l11l1l_l1_ (u"࠭ࡐࡢ࡮ࡤࡹࠬ㬈")
,l11l1l_l1_ (u"ࠧࡑࡕࠪ㬉"):l11l1l_l1_ (u"ࠨࡒࡤࡰࡪࡹࡴࡪࡰࡨࠫ㬊")
,l11l1l_l1_ (u"ࠩࡓࡅࠬ㬋"):l11l1l_l1_ (u"ࠪࡔࡦࡴࡡ࡮ࡣࠪ㬌")
,l11l1l_l1_ (u"ࠫࡕࡍࠧ㬍"):l11l1l_l1_ (u"ࠬࡖࡡࡱࡷࡤࠤࡓ࡫ࡷࠡࡉࡸ࡭ࡳ࡫ࡡࠨ㬎")
,l11l1l_l1_ (u"࠭ࡐ࡚ࠩ㬏"):l11l1l_l1_ (u"ࠧࡑࡣࡵࡥ࡬ࡻࡡࡺࠩ㬐")
,l11l1l_l1_ (u"ࠨࡒࡈࠫ㬑"):l11l1l_l1_ (u"ࠩࡓࡩࡷࡻࠧ㬒")
,l11l1l_l1_ (u"ࠪࡔࡍ࠭㬓"):l11l1l_l1_ (u"ࠫࡕ࡮ࡩ࡭࡫ࡳࡴ࡮ࡴࡥࡴࠩ㬔")
,l11l1l_l1_ (u"ࠬࡖࡎࠨ㬕"):l11l1l_l1_ (u"࠭ࡐࡪࡶࡦࡥ࡮ࡸ࡮ࠡࡋࡶࡰࡦࡴࡤࡴࠩ㬖")
,l11l1l_l1_ (u"ࠧࡑࡎࠪ㬗"):l11l1l_l1_ (u"ࠨࡒࡲࡰࡦࡴࡤࠨ㬘")
,l11l1l_l1_ (u"ࠩࡓࡘࠬ㬙"):l11l1l_l1_ (u"ࠪࡔࡴࡸࡴࡶࡩࡤࡰࠬ㬚")
,l11l1l_l1_ (u"ࠫࡕࡘࠧ㬛"):l11l1l_l1_ (u"ࠬࡖࡵࡦࡴࡷࡳࠥࡘࡩࡤࡱࠪ㬜")
,l11l1l_l1_ (u"࠭ࡑࡂࠩ㬝"):l11l1l_l1_ (u"ࠧࡒࡣࡷࡥࡷ࠭㬞")
,l11l1l_l1_ (u"ࠨࡅࡊࠫ㬟"):l11l1l_l1_ (u"ࠩࡕࡩࡵࡻࡢ࡭࡫ࡦࠤࡴ࡬ࠠࡵࡪࡨࠤࡈࡵ࡮ࡨࡱࠪ㬠")
,l11l1l_l1_ (u"ࠪࡖࡔ࠭㬡"):l11l1l_l1_ (u"ࠫࡗࡵ࡭ࡢࡰ࡬ࡥࠬ㬢")
,l11l1l_l1_ (u"ࠬࡘࡕࠨ㬣"):l11l1l_l1_ (u"࠭ࡒࡶࡵࡶ࡭ࡦ࠭㬤")
,l11l1l_l1_ (u"ࠧࡓ࡙ࠪ㬥"):l11l1l_l1_ (u"ࠨࡔࡺࡥࡳࡪࡡࠨ㬦")
,l11l1l_l1_ (u"ࠩࡕࡉࠬ㬧"):l11l1l_l1_ (u"ࠪࡖ࣮ࡻ࡮ࡪࡱࡱࠫ㬨")
,l11l1l_l1_ (u"ࠫࡇࡒࠧ㬩"):l11l1l_l1_ (u"࡙ࠬࡡࡪࡰࡷࠤࡇࡧࡲࡵࡪ࣬ࡰࡪࡳࡹࠨ㬪")
,l11l1l_l1_ (u"࠭ࡓࡉࠩ㬫"):l11l1l_l1_ (u"ࠧࡔࡣ࡬ࡲࡹࠦࡈࡦ࡮ࡨࡲࡦ࠭㬬")
,l11l1l_l1_ (u"ࠨࡍࡑࠫ㬭"):l11l1l_l1_ (u"ࠩࡖࡥ࡮ࡴࡴࠡࡍ࡬ࡸࡹࡹࠠࡢࡰࡧࠤࡓ࡫ࡶࡪࡵࠪ㬮")
,l11l1l_l1_ (u"ࠪࡐࡈ࠭㬯"):l11l1l_l1_ (u"ࠫࡘࡧࡩ࡯ࡶࠣࡐࡺࡩࡩࡢࠩ㬰")
,l11l1l_l1_ (u"ࠬࡓࡆࠨ㬱"):l11l1l_l1_ (u"࠭ࡓࡢ࡫ࡱࡸࠥࡓࡡࡳࡶ࡬ࡲࠬ㬲")
,l11l1l_l1_ (u"ࠧࡑࡏࠪ㬳"):l11l1l_l1_ (u"ࠨࡕࡤ࡭ࡳࡺࠠࡑ࡫ࡨࡶࡷ࡫ࠠࡢࡰࡧࠤࡒ࡯ࡱࡶࡧ࡯ࡳࡳ࠭㬴")
,l11l1l_l1_ (u"࡙ࠩࡇࠬ㬵"):l11l1l_l1_ (u"ࠪࡗࡦ࡯࡮ࡵ࡙ࠢ࡭ࡳࡩࡥ࡯ࡶࠣࡥࡳࡪࠠࡵࡪࡨࠤࡌࡸࡥ࡯ࡣࡧ࡭ࡳ࡫ࡳࠨ㬶")
,l11l1l_l1_ (u"ࠫ࡜࡙ࠧ㬷"):l11l1l_l1_ (u"࡙ࠬࡡ࡮ࡱࡤࠫ㬸")
,l11l1l_l1_ (u"࠭ࡓࡎࠩ㬹"):l11l1l_l1_ (u"ࠧࡔࡣࡱࠤࡒࡧࡲࡪࡰࡲࠫ㬺")
,l11l1l_l1_ (u"ࠨࡕࡄࠫ㬻"):l11l1l_l1_ (u"ࠩࡖࡥࡺࡪࡩࠡࡃࡵࡥࡧ࡯ࡡࠨ㬼")
,l11l1l_l1_ (u"ࠪࡗࡓ࠭㬽"):l11l1l_l1_ (u"ࠫࡘ࡫࡮ࡦࡩࡤࡰࠬ㬾")
,l11l1l_l1_ (u"ࠬࡘࡓࠨ㬿"):l11l1l_l1_ (u"࠭ࡓࡦࡴࡥ࡭ࡦ࠭㭀")
,l11l1l_l1_ (u"ࠧࡔࡅࠪ㭁"):l11l1l_l1_ (u"ࠨࡕࡨࡽࡨ࡮ࡥ࡭࡮ࡨࡷࠬ㭂")
,l11l1l_l1_ (u"ࠩࡖࡐࠬ㭃"):l11l1l_l1_ (u"ࠪࡗ࡮࡫ࡲࡳࡣࠣࡐࡪࡵ࡮ࡦࠩ㭄")
,l11l1l_l1_ (u"ࠫࡘࡍࠧ㭅"):l11l1l_l1_ (u"࡙ࠬࡩ࡯ࡩࡤࡴࡴࡸࡥࠨ㭆")
,l11l1l_l1_ (u"࠭ࡓ࡙ࠩ㭇"):l11l1l_l1_ (u"ࠧࡔ࡫ࡱࡸࠥࡓࡡࡢࡴࡷࡩࡳ࠭㭈")
,l11l1l_l1_ (u"ࠨࡕࡎࠫ㭉"):l11l1l_l1_ (u"ࠩࡖࡰࡴࡼࡡ࡬࡫ࡤࠫ㭊")
,l11l1l_l1_ (u"ࠪࡗࡎ࠭㭋"):l11l1l_l1_ (u"ࠫࡘࡲ࡯ࡷࡧࡱ࡭ࡦ࠭㭌")
,l11l1l_l1_ (u"࡙ࠬࡂࠨ㭍"):l11l1l_l1_ (u"࠭ࡓࡰ࡮ࡲࡱࡴࡴࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㭎")
,l11l1l_l1_ (u"ࠧࡔࡑࠪ㭏"):l11l1l_l1_ (u"ࠨࡕࡲࡱࡦࡲࡩࡢࠩ㭐")
,l11l1l_l1_ (u"ࠩ࡝ࡅࠬ㭑"):l11l1l_l1_ (u"ࠪࡗࡴࡻࡴࡩࠢࡄࡪࡷ࡯ࡣࡢࠩ㭒")
,l11l1l_l1_ (u"ࠫࡌ࡙ࠧ㭓"):l11l1l_l1_ (u"࡙ࠬ࡯ࡶࡶ࡫ࠤࡌ࡫࡯ࡳࡩ࡬ࡥࠥࡧ࡮ࡥࠢࡷ࡬ࡪࠦࡓࡰࡷࡷ࡬࡙ࠥࡡ࡯ࡦࡺ࡭ࡨ࡮ࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㭔")
,l11l1l_l1_ (u"࠭ࡋࡓࠩ㭕"):l11l1l_l1_ (u"ࠧࡔࡱࡸࡸ࡭ࠦࡋࡰࡴࡨࡥࠬ㭖")
,l11l1l_l1_ (u"ࠨࡕࡖࠫ㭗"):l11l1l_l1_ (u"ࠩࡖࡳࡺࡺࡨࠡࡕࡸࡨࡦࡴࠧ㭘")
,l11l1l_l1_ (u"ࠪࡉࡘ࠭㭙"):l11l1l_l1_ (u"ࠫࡘࡶࡡࡪࡰࠪ㭚")
,l11l1l_l1_ (u"ࠬࡒࡋࠨ㭛"):l11l1l_l1_ (u"࠭ࡓࡳ࡫ࠣࡐࡦࡴ࡫ࡢࠩ㭜")
,l11l1l_l1_ (u"ࠧࡔࡆࠪ㭝"):l11l1l_l1_ (u"ࠨࡕࡸࡨࡦࡴࠧ㭞")
,l11l1l_l1_ (u"ࠩࡖࡖࠬ㭟"):l11l1l_l1_ (u"ࠪࡗࡺࡸࡩ࡯ࡣࡰࡩࠬ㭠")
,l11l1l_l1_ (u"ࠫࡘࡐࠧ㭡"):l11l1l_l1_ (u"࡙ࠬࡶࡢ࡮ࡥࡥࡷࡪࠠࡢࡰࡧࠤࡏࡧ࡮ࠡࡏࡤࡽࡪࡴࠧ㭢")
,l11l1l_l1_ (u"࠭ࡓ࡛ࠩ㭣"):l11l1l_l1_ (u"ࠧࡔࡹࡤࡾ࡮ࡲࡡ࡯ࡦࠪ㭤")
,l11l1l_l1_ (u"ࠨࡕࡈࠫ㭥"):l11l1l_l1_ (u"ࠩࡖࡻࡪࡪࡥ࡯ࠩ㭦")
,l11l1l_l1_ (u"ࠪࡇࡍ࠭㭧"):l11l1l_l1_ (u"ࠫࡘࡽࡩࡵࡼࡨࡶࡱࡧ࡮ࡥࠩ㭨")
,l11l1l_l1_ (u"࡙࡙ࠬࠨ㭩"):l11l1l_l1_ (u"࠭ࡓࡺࡴ࡬ࡥࠬ㭪")
,l11l1l_l1_ (u"ࠧࡔࡖࠪ㭫"):l11l1l_l1_ (u"ࠨࡕࣦࡳ࡚ࠥ࡯࡮࣫ࠣࡥࡳࡪࠠࡑࡴࣰࡲࡨ࡯ࡰࡦࠩ㭬")
,l11l1l_l1_ (u"ࠩࡗ࡛ࠬ㭭"):l11l1l_l1_ (u"ࠪࡘࡦ࡯ࡷࡢࡰࠪ㭮")
,l11l1l_l1_ (u"࡙ࠫࡐࠧ㭯"):l11l1l_l1_ (u"࡚ࠬࡡ࡫࡫࡮࡭ࡸࡺࡡ࡯ࠩ㭰")
,l11l1l_l1_ (u"࠭ࡔ࡛ࠩ㭱"):l11l1l_l1_ (u"ࠧࡕࡣࡱࡾࡦࡴࡩࡢࠩ㭲")
,l11l1l_l1_ (u"ࠨࡖࡋࠫ㭳"):l11l1l_l1_ (u"ࠩࡗ࡬ࡦ࡯࡬ࡢࡰࡧࠫ㭴")
,l11l1l_l1_ (u"ࠪࡘࡌ࠭㭵"):l11l1l_l1_ (u"࡙ࠫࡵࡧࡰࠩ㭶")
,l11l1l_l1_ (u"࡚ࠬࡋࠨ㭷"):l11l1l_l1_ (u"࠭ࡔࡰ࡭ࡨࡰࡦࡻࠧ㭸")
,l11l1l_l1_ (u"ࠧࡕࡑࠪ㭹"):l11l1l_l1_ (u"ࠨࡖࡲࡲ࡬ࡧࠧ㭺")
,l11l1l_l1_ (u"ࠩࡗࡘࠬ㭻"):l11l1l_l1_ (u"ࠪࡘࡷ࡯࡮ࡪࡦࡤࡨࠥࡧ࡮ࡥࠢࡗࡳࡧࡧࡧࡰࠩ㭼")
,l11l1l_l1_ (u"࡙ࠫࡔࠧ㭽"):l11l1l_l1_ (u"࡚ࠬࡵ࡯࡫ࡶ࡭ࡦ࠭㭾")
,l11l1l_l1_ (u"࠭ࡔࡓࠩ㭿"):l11l1l_l1_ (u"ࠧࡕࡷࡵ࡯ࡪࡿࠧ㮀")
,l11l1l_l1_ (u"ࠨࡖࡐࠫ㮁"):l11l1l_l1_ (u"ࠩࡗࡹࡷࡱ࡭ࡦࡰ࡬ࡷࡹࡧ࡮ࠨ㮂")
,l11l1l_l1_ (u"ࠪࡘࡈ࠭㮃"):l11l1l_l1_ (u"࡙ࠫࡻࡲ࡬ࡵࠣࡥࡳࡪࠠࡄࡣ࡬ࡧࡴࡹࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㮄")
,l11l1l_l1_ (u"࡚ࠬࡖࠨ㮅"):l11l1l_l1_ (u"࠭ࡔࡶࡸࡤࡰࡺ࠭㮆")
,l11l1l_l1_ (u"ࠧࡖࡏࠪ㮇"):l11l1l_l1_ (u"ࠨࡗ࠱ࡗ࠳ࠦࡍࡪࡰࡲࡶࠥࡕࡵࡵ࡮ࡼ࡭ࡳ࡭ࠠࡊࡵ࡯ࡥࡳࡪࡳࠨ㮈")
,l11l1l_l1_ (u"࡙ࠩࡍࠬ㮉"):l11l1l_l1_ (u"࡙ࠪ࠳࡙࠮ࠡࡘ࡬ࡶ࡬࡯࡮ࠡࡋࡶࡰࡦࡴࡤࡴࠩ㮊")
,l11l1l_l1_ (u"࡚ࠫࡍࠧ㮋"):l11l1l_l1_ (u"࡛ࠬࡧࡢࡰࡧࡥࠬ㮌")
,l11l1l_l1_ (u"࠭ࡕࡂࠩ㮍"):l11l1l_l1_ (u"ࠧࡖ࡭ࡵࡥ࡮ࡴࡥࠨ㮎")
,l11l1l_l1_ (u"ࠨࡃࡈࠫ㮏"):l11l1l_l1_ (u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡄࡶࡦࡨࠠࡆ࡯࡬ࡶࡦࡺࡥࡴࠩ㮐")
,l11l1l_l1_ (u"࡙ࠪࡐ࠭㮑"):l11l1l_l1_ (u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬ㮒")
,l11l1l_l1_ (u"࡛ࠬࡓࠨ㮓"):l11l1l_l1_ (u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡓࡵࡣࡷࡩࡸ࠭㮔")
,l11l1l_l1_ (u"ࠧࡖ࡛ࠪ㮕"):l11l1l_l1_ (u"ࠨࡗࡵࡹ࡬ࡻࡡࡺࠩ㮖")
,l11l1l_l1_ (u"ࠩࡘ࡞ࠬ㮗"):l11l1l_l1_ (u"࡙ࠪࡿࡨࡥ࡬࡫ࡶࡸࡦࡴࠧ㮘")
,l11l1l_l1_ (u"࡛࡛ࠫࠧ㮙"):l11l1l_l1_ (u"ࠬ࡜ࡡ࡯ࡷࡤࡸࡺ࠭㮚")
,l11l1l_l1_ (u"࠭ࡖࡂࠩ㮛"):l11l1l_l1_ (u"ࠧࡗࡣࡷ࡭ࡨࡧ࡮ࠡࡅ࡬ࡸࡾ࠭㮜")
,l11l1l_l1_ (u"ࠨࡘࡈࠫ㮝"):l11l1l_l1_ (u"࡙ࠩࡩࡳ࡫ࡺࡶࡧ࡯ࡥࠬ㮞")
,l11l1l_l1_ (u"࡚ࠪࡓ࠭㮟"):l11l1l_l1_ (u"࡛ࠫ࡯ࡥࡵࡰࡤࡱࠬ㮠")
,l11l1l_l1_ (u"ࠬ࡝ࡆࠨ㮡"):l11l1l_l1_ (u"࠭ࡗࡢ࡮࡯࡭ࡸࠦࡡ࡯ࡦࠣࡊࡺࡺࡵ࡯ࡣࠪ㮢")
,l11l1l_l1_ (u"ࠧࡆࡊࠪ㮣"):l11l1l_l1_ (u"ࠨ࡙ࡨࡷࡹ࡫ࡲ࡯ࠢࡖࡥ࡭ࡧࡲࡢࠩ㮤")
,l11l1l_l1_ (u"ࠩ࡜ࡉࠬ㮥"):l11l1l_l1_ (u"ࠪ࡝ࡪࡳࡥ࡯ࠩ㮦")
,l11l1l_l1_ (u"ࠫ࡟ࡓࠧ㮧"):l11l1l_l1_ (u"ࠬࡠࡡ࡮ࡤ࡬ࡥࠬ㮨")
,l11l1l_l1_ (u"࡚࠭ࡘࠩ㮩"):l11l1l_l1_ (u"࡛ࠧ࡫ࡰࡦࡦࡨࡷࡦࠩ㮪")
,l11l1l_l1_ (u"ࠨࡃ࡛ࠫ㮫"):l11l1l_l1_ (u"ࠩࣈࡰࡦࡴࡤࠨ㮬")
}
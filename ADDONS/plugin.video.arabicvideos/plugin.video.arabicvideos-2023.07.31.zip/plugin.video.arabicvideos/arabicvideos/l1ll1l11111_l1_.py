# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ⡁")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡊࡏ࡙࡟ࠨ⡂")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠪห้ะี็์ไหฯ࠭⡃"),l11l1l_l1_ (u"ࠫฬ์ิศรࠣัุอศࠨ⡄"),l11l1l_l1_ (u"ࠬ฽ไษษอࠤฬ๊า้๓สีࠬ⡅")]
#headers = {l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ⡆"):l11l1l_l1_ (u"ࠧࠨ⡇")}
def MAIN(mode,url,text):
	if   mode==390: results = MENU()
	elif mode==391: results = l1lllll_l1_(url,text)
	elif mode==392: results = PLAY(url)
	elif mode==393: results = l1lll1l1_l1_(url)
	elif mode==399: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡈"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⡉"),l11l1l_l1_ (u"ࠪࠫ⡊"),399,l11l1l_l1_ (u"ࠫࠬ⡋"),l11l1l_l1_ (u"ࠬ࠭⡌"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⡍"))
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⡎"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⡏"),l11l1l_l1_ (u"ࠩࠪ⡐"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ⡑"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ⡒"),l11l1l_l1_ (u"ࠬ࠭⡓"),l11l1l_l1_ (u"࠭ࠧ⡔"),l11l1l_l1_ (u"ࠧࠨ⡕"),l11l1l_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⡖"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⡗"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⡘"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⡙")+l1111l_l1_+title,l11l11_l1_,391,l11l1l_l1_ (u"ࠬ࠭⡚"),l11l1l_l1_ (u"࠭ࠧ⡛"),l11l1l_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⡜")+str(seq))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⡝"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⡞")+l1111l_l1_+l11l1l_l1_ (u"้ࠪำะวาษอࠤ฾ฺ่ศศํอࠬ⡟"),l11l11_l1_,391,l11l1l_l1_ (u"ࠫࠬ⡠"),l11l1l_l1_ (u"ࠬ࠭⡡"),l11l1l_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡹࠧ⡢"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⡣"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⡤")+l1111l_l1_+l11l1l_l1_ (u"ࠩฦ฽้๏ࠠศๆฦๅ้อๅࠡฬๅ๎๏๋ว์ࠩ⡥"),l11l11_l1_,391,l11l1l_l1_ (u"ࠪࠫ⡦"),l11l1l_l1_ (u"ࠫࠬ⡧"),l11l1l_l1_ (u"ࠬࡺ࡯ࡱࡡ࡬ࡱࡩࡨ࡟࡮ࡱࡹ࡭ࡪࡹࠧ⡨"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⡩"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⡪")+l1111l_l1_+l11l1l_l1_ (u"ࠨล฼่๎ࠦวๅ็ึุ่๊วหࠢอๆ๏๐ๅศํࠪ⡫"),l11l11_l1_,391,l11l1l_l1_ (u"ࠩࠪ⡬"),l11l1l_l1_ (u"ࠪࠫ⡭"),l11l1l_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥࡳࡦࡴ࡬ࡩࡸ࠭⡮"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⡯"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⡰")+l1111l_l1_+l11l1l_l1_ (u"ࠧฤใ็ห๊ࠦๅๆ์ีอࠬ⡱"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ⡲"),391,l11l1l_l1_ (u"ࠩࠪ⡳"),l11l1l_l1_ (u"ࠪࠫ⡴"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⡵"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⡶"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⡷")+l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧ⡸"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵࠪ⡹"),391,l11l1l_l1_ (u"ࠩࠪ⡺"),l11l1l_l1_ (u"ࠪࠫ⡻"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡴࡷࡵ࡫ࡳࡼࡹࠧ⡼"))
	block = l11l1l_l1_ (u"ࠬ࠭⡽")
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡰࡰࡷࡩࡳ࡫ࡤࡰࡴࠥࠫ⡾"),html,re.DOTALL)
	if l1l11l1_l1_: block += l1l11l1_l1_[0]
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⡿"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ⢀"),l11l1l_l1_ (u"ࠩࠪ⢁"),l11l1l_l1_ (u"ࠪࠫ⢂"),l11l1l_l1_ (u"ࠫࠬ⢃"),l11l1l_l1_ (u"ࠬ࠭⢄"),l11l1l_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ⢅"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡧ࡯ࡩࡦࡹࡥࡴࠤࠫ࠲࠯ࡅࠩࡢࡵ࡬ࡨࡪ࠭⢆"),html,re.DOTALL)
	if l1l11l1_l1_: block += l1l11l1_l1_[0]
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⢇"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⢈"),l11l1l_l1_ (u"ࠪࠫ⢉"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⢊"),block,re.DOTALL)
	first = True
	for l1llll1_l1_,title in items:
		title = unescapeHTML(title)
		if title==l11l1l_l1_ (u"ࠬอไฤ฻็ํ๋ࠥิศ้าอࠬ⢋"):
			if first:
				title = l11l1l_l1_ (u"࠭วๅษไ่ฬ๋ࠠࠨ⢌")+title
				first = False
			else: title = l11l1l_l1_ (u"ࠧศๆ่ืู้ไศฬࠣࠫ⢍")+title
		if title not in l1l111_l1_:
			if title==l11l1l_l1_ (u"ࠨลไ่ฬ๋ࠧ⢎"): addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⢏"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⢐")+l1111l_l1_+title,l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⢑"),391,l11l1l_l1_ (u"ࠬ࠭⢒"),l11l1l_l1_ (u"࠭ࠧ⢓"),l11l1l_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⢔"))
			elif title==l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ⢕"): addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⢖"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⢗")+l1111l_l1_+title,l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠭⢘"),391,l11l1l_l1_ (u"ࠬ࠭⢙"),l11l1l_l1_ (u"࠭ࠧ⢚"),l11l1l_l1_ (u"ࠧࡢ࡮࡯ࡣࡲࡵࡶࡪࡧࡶࡣࡹࡼࡳࡩࡱࡺࡷࠬ⢛"))
			else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⢜"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ⢝")+l1111l_l1_+title,l1llll1_l1_,391)
	return html
def l1lllll_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ⢞"),l11l1l_l1_ (u"ࠫࠬ⢟"),url,type)
	#WRITE_THIS(html)
	block,items = [],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⢠"),url,l11l1l_l1_ (u"࠭ࠧ⢡"),l11l1l_l1_ (u"ࠧࠨ⢢"),l11l1l_l1_ (u"ࠨࠩ⢣"),l11l1l_l1_ (u"ࠩࠪ⢤"),l11l1l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ⢥"))
	html = response.content
	if type in [l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⢦"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⢧")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡤࡶࡨ࡮ࡩࡷࡧ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࠬ⢨"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ⢩"),l11l1l_l1_ (u"ࠨࠩ⢪"),url,block)
	elif type==l11l1l_l1_ (u"ࠩࡤࡰࡱࡥ࡭ࡰࡸ࡬ࡩࡸࡥࡴࡷࡵ࡫ࡳࡼࡹࠧ⢫"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࡢࡴࡦ࡬࡮ࡼࡥ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬ⢬"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif type==l11l1l_l1_ (u"ࠫࡹࡵࡰࡠ࡫ࡰࡨࡧࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⢭"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩ࡬ࡢࡵࡶࡁࠬࡺ࡯ࡱ࠯࡬ࡱࡩࡨ࠭࡭࡫ࡶࡸࠥࡺ࡬ࡦࡨࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠨࡶࡲࡴ࠲࡯࡭ࡥࡤ࠰ࡰ࡮ࡹࡴࠡࡶࡵ࡭࡬࡮ࡴࠣ⢮"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ⢯"),l11l1l_l1_ (u"ࠧࠨ⢰"),str(len(block)),type)
			items = re.findall(l11l1l_l1_ (u"ࠣ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ⢱"),block,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠩࡷࡳࡵࡥࡩ࡮ࡦࡥࡣࡸ࡫ࡲࡪࡧࡶࠫ⢲"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠥࡧࡱࡧࡳࡴ࠿ࠪࡸࡴࡶ࠭ࡪ࡯ࡧࡦ࠲ࡲࡩࡴࡶࠣࡸࡷ࡯ࡧࡩࡶࠫ࠲࠯ࡅࠩࡧࡱࡲࡸࡪࡸࠢ⢳"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ⢴"),l11l1l_l1_ (u"ࠬ࠭⢵"),str(len(block)),type)
			items = re.findall(l11l1l_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⢶"),block,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⢷"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡥࡷࡩࡨ࠮ࡲࡤ࡫ࡪࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡸ࡯ࡤࡦࡤࡤࡶࠬ⢸"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⢹"),block,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠪࡷ࡮ࡪࡥࡳࠩ⢺"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼ࡯ࡤࡨࡧࡷࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࡬ࡨ࡬࡫ࡴࠨ⢻"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		l11111_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢼"),block,re.DOTALL)
		l1lll1_l1_,l11llllll_l1_,l1ll1ll1_l1_ = zip(*l11111_l1_)
		items = zip(l11llllll_l1_,l1lll1_l1_,l1ll1ll1_l1_)
	elif type==l11l1l_l1_ (u"࠭ࡲࡢࡰࡧࡳࡲࡹࠧ⢽"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡸࡲࡩࡥࡧࡵ࠱ࡲࡵࡶࡪࡧࡶ࠱ࡹࡼࡳࡩࡱࡺࡷࠧ࠮࠮ࠫࡁࠬࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⢾"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⢿"),block,re.DOTALL)
	elif l11l1l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ⣀") in type:
		seq = int(type[-1:])
		html = html.replace(l11l1l_l1_ (u"ࠪࡀ࡭࡫ࡡࡥࡧࡵࡂࠬ⣁"),l11l1l_l1_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡷࡹࡧࡲࡵࡀࠪ⣂"))
		html = html.replace(l11l1l_l1_ (u"ࠬࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⣃"),l11l1l_l1_ (u"࠭࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀࡪࡴࡤ࠿ࠩ⣄"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡷࡥࡷࡺ࠾ࠩ࠰࠭ࡃ࠮ࡂࡥ࡯ࡦࡁࠫ⣅"),html,re.DOTALL)
		block = l1l11l1_l1_[seq]
		if seq==6:
			l11111_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⣆"),block,re.DOTALL)
			l11llllll_l1_,l1ll1ll1_l1_,l1lll1_l1_ = zip(*l11111_l1_)
			items = zip(l11llllll_l1_,l1lll1_l1_,l1ll1ll1_l1_)
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࠪࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࢂࡳࡪࡦࡨࡦࡦࡸࠩࠨ⣇"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0][0]
			if l11l1l_l1_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ⣈") in url:
				items = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⣉"),block,re.DOTALL)
			elif l11l1l_l1_ (u"ࠬ࠵ࡱࡶࡣ࡯࡭ࡹࡿ࠯ࠨ⣊") in url:
				items = re.findall(l11l1l_l1_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⣋"),block,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ⣌"),l11l1l_l1_ (u"ࠨࠩ⣍"),str(len(items)),type)
	if not items and block:
		items = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ⣎"),block,re.DOTALL)
	l11l_l1_ = []
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠨ⣏") in title: continue
		if l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࠪ⣐") in title:
			title = re.findall(l11l1l_l1_ (u"ࠬࡤࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡵࡨࡶ࡮࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⣑"),title,re.DOTALL)
			title = title[0][1]#+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ⣒")+title[0][0]
			if title in l11l_l1_: continue
			l11l_l1_.append(title)
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭⣓")+title
		l1lll11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡠࠫ࠲࠯ࡅࠩ࠽ࠩ⣔"),title,re.DOTALL)
		if l1lll11l1_l1_: title = l1lll11l1_l1_[0]
		title = unescapeHTML(title)
		if l11l1l_l1_ (u"ࠩ࠲ࡸࡻࡹࡨࡰࡹࡶ࠳ࠬ⣕") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣖"),l1111l_l1_+title,l1llll1_l1_,393,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪࡹ࠯ࠨ⣗") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣘"),l1111l_l1_+title,l1llll1_l1_,393,l1ll1l_l1_)
		elif l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࡳ࠰ࠩ⣙") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⣚"),l1111l_l1_+title,l1llll1_l1_,393,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ⣛") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣜"),l1111l_l1_+title,l1llll1_l1_,391,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⣝"),l1111l_l1_+title,l1llll1_l1_,392,l1ll1l_l1_)
	if type not in [l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⣞"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨ⣟")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⣠"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⣡"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⣢"),l1111l_l1_+l11l1l_l1_ (u"ุࠩๅาฯࠠࠨ⣣")+title,l1llll1_l1_,391,l11l1l_l1_ (u"ࠪࠫ⣤"),l11l1l_l1_ (u"ࠫࠬ⣥"),type)
	return
def l1lll1l1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⣦"),l11l1l_l1_ (u"࠭ࠧ⣧"),l11l1l_l1_ (u"ࠧࠨ⣨"),url)
	server = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ⣩"))
	url = url.replace(server,l11l11_l1_)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭⣪"),url,l11l1l_l1_ (u"ࠪࠫ⣫"),l11l1l_l1_ (u"ࠫࠬ⣬"),l11l1l_l1_ (u"ࠬ࠭⣭"),l11l1l_l1_ (u"࠭ࠧ⣮"),l11l1l_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⣯"))
	html = response.content
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⣰"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡹࡱࠦࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡯࡯ࡴࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࠫ⣱"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⣲"),block,re.DOTALL)
		for l1ll1l_l1_,l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⣳"),l1111l_l1_+title,l1llll1_l1_,392,l1ll1l_l1_)
	return
def PLAY(url):
	html = l1ll11ll11_l1_(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⣴"),url,l11l1l_l1_ (u"࠭ࠧ⣵"),l11l1l_l1_ (u"ࠧࠨ⣶"),l11l1l_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⣷"))
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭⣸"),url,l11l1l_l1_ (u"ࠪࠫ⣹"),l11l1l_l1_ (u"ࠫࠬ⣺"),l11l1l_l1_ (u"ࠬ࠭⣻"),l11l1l_l1_ (u"࠭ࠧ⣼"),l11l1l_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⣽"))
	#html = response.content
	if kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭⣾"),l11l1l_l1_ (u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ⣿"))
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࠥࡸࡡࡵࡧࡧࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⤀"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	l1lll1_l1_ = []
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲ࠮ࡱࡳࡸ࡮ࡵ࡮࠮࠳ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡜ࠤࡿࡠࠬࡣࠨࡴࡪࡨࡥࡩ࡫ࡲࡽࡲࡤ࡫ࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠩ࡜ࠤࡿࡠࠬࡣࠧ⤁"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0][0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡸࡾࡶࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭ࡱࡱࡶࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡤࡢࡶࡤ࠱ࡳࡻ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡼࡩࡥࡡࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⤂"),block,re.DOTALL)
		for type,l1lll11_l1_,l1ll1l1111l_l1_,title in items:
			#l1llll1_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡲࡻ࠳ࡧ࡬ࡧࡣ࡭ࡩࡷࡺࡶ࠯ࡥࡲࡱ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࡢࡦࡰ࡭ࡳ࠳ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࠨ⤃")
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡹࡳ࠱ࡦࡪ࡭ࡪࡰ࠲ࡥࡩࡳࡩ࡯࠯ࡤ࡮ࡦࡾ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡩࡵ࡯ࡠࡲ࡯ࡥࡾ࡫ࡲࡠࡣ࡭ࡥࡽࠬࡰࡰࡵࡷࡁࠬ⤄")+l1lll11_l1_+l11l1l_l1_ (u"ࠨࠨࡱࡹࡲ࡫࠽ࠨ⤅")+l1ll1l1111l_l1_+l11l1l_l1_ (u"ࠩࠩࡸࡾࡶࡥ࠾ࠩ⤆")+type
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⤇")+title+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⤈")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	#WRITE_THIS(html)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡯ࡤ࠾ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫࠥࡩ࡬ࡢࡵࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡜࡞ࠥࢀࠬࡣࡳࡣࡱࡻ࡟ࡡࠨࡼࠨ࡟ࠥ⤉"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁࠨ⤊"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ⤋"),l11l1l_l1_ (u"ࠨࠩ⤌"),str(items),str(block))
		for l1ll1l_l1_,l1llll1_l1_,l111ll11_l1_,l1ll1l111l1_l1_ in items:
			if l11l1l_l1_ (u"ࠩࡀࠫ⤍") in l1ll1l_l1_:
				host = l1ll1l_l1_.split(l11l1l_l1_ (u"ࠪࡁࠬ⤎"))[1]
				title = SERVER(host,l11l1l_l1_ (u"ࠫ࡭ࡵࡳࡵࠩ⤏"))
			else: title = l11l1l_l1_ (u"ࠬ࠭⤐")
			title = l1ll1l111l1_l1_+l11l1l_l1_ (u"࠭ࠠࠨ⤑")+title
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⤒")+title+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡥ࡟ࡠࠩ⤓")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⤔"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⤕"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ⤖"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭⤗"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ⤘"),l11l1l_l1_ (u"ࠧࠬࠩ⤙"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡂࡷࡂ࠭⤚")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩ⤛"))
	return
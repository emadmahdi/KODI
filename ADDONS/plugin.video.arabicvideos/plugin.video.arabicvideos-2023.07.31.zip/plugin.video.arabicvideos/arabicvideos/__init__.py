# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟ࠧ撊")
contentsDICT = {}
menuItemsLIST = []
if kodi_version>18.99:
	l111111llll1_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡼࡧࡳࡣࠨ撋"))
	l1l11l1lll_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ撌"))
	l111llll1111_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭撍"))
	l1llll11ll111_l1_ = xbmcvfs.translatePath(l11l1l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫ撎"))
	l111l1111lll_l1_ = xbmc.LOGINFO
	l1l111ll1l1l_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭撏"),l11l1l_l1_ (u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧ撐"),l11l1l_l1_ (u"࠭ࡁࡥࡦࡲࡲࡸ࠹࠳࠯ࡦࡥࠫ撑"))
	l111ll1111l1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩ撒"),l11l1l_l1_ (u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪ撓"),l11l1l_l1_ (u"࡙ࠩ࡭ࡪࡽࡍࡰࡦࡨࡷ࠻࠴ࡤࡣࠩ撔"))
	l1ll11111l_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ撕"),l11l1l_l1_ (u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭撖"),l11l1l_l1_ (u"࡚ࠬࡥࡹࡶࡸࡶࡪࡹ࠱࠴࠰ࡧࡦࠬ撗"))
	ltr,rtl = l11l1l_l1_ (u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡧࠧ撘"),l11l1l_l1_ (u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡢࠨ撙")
	half_triangular_colon = l11l1l_l1_ (u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ撚")
	from urllib.parse import quote as _1lllll1ll11l_l1_
	from urllib.parse import unquote as _111ll11l11l_l1_
else:
	l111111llll1_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪ撛"))
	l1l11l1lll_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ撜"))
	l111llll1111_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨ撝"))
	l1llll11ll111_l1_ = xbmc.translatePath(l11l1l_l1_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭撞"))
	l111l1111lll_l1_ = xbmc.LOGNOTICE
	l1l111ll1l1l_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ撟"),l11l1l_l1_ (u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ撠"),l11l1l_l1_ (u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭撡"))
	l111ll1111l1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ撢"),l11l1l_l1_ (u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ撣"),l11l1l_l1_ (u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ撤"))
	l1ll11111l_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ撥"),l11l1l_l1_ (u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ撦"),l11l1l_l1_ (u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧ撧"))
	ltr,rtl = l11l1l_l1_ (u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩ撨").encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ撩")),l11l1l_l1_ (u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫ撪").encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ撫"))
	half_triangular_colon = l11l1l_l1_ (u"ࡺ࠭࡜ࡶ࠲࠵ࡨ࠶࠭撬").encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ播"))
	from urllib import quote as _1lllll1ll11l_l1_
	from urllib import unquote as _111ll11l11l_l1_
addon_handle = int(sys.argv[1])
addon_id = sys.argv[0].split(l11l1l_l1_ (u"ࠧ࠰ࠩ撮"))[2]	# plugin.video.l11111111ll1_l1_
l1lll11ll1lll_l1_ = addon_id.split(l11l1l_l1_ (u"ࠨ࠰ࠪ撯"))[2]		# l11111111ll1_l1_
addon_path = sys.argv[2]				# ?mode=12&url=http://test.com
#l111lll1l111_l1_ = sys.argv[0]+addon_path		# plugin://plugin.video.l11111111ll1_l1_/?mode=12&url=http://test.com
#addon_path = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡋࡵ࡬ࡥࡧࡵࡔࡦࡺࡨࠨ撰"))
addon_version = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡘࡨࡶࡸ࡯࡯࡯ࠪࠪ撱")+addon_id+l11l1l_l1_ (u"ࠫ࠮࠭撲"))
settings = xbmcaddon.Addon(id=addon_id)
dest_lang = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡧࡴࡪࡥࠨ撳"))
do_trans = False if not dest_lang or dest_lang==l11l1l_l1_ (u"࠭ࡡࡳࡣࠪ撴") else True
l1l11l11ll1l_l1_ = os.path.join(l111llll1111_l1_,l11l1l_l1_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ撵"))
l11ll1l11l11_l1_ = os.path.join(l111llll1111_l1_,l11l1l_l1_ (u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭ࠧ撶"))
l1l11lll1lll_l1_ = [l11l1l_l1_ (u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ撷"),l11l1l_l1_ (u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫ撸"),l11l1l_l1_ (u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫ࠧ撹"),l11l1l_l1_ (u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧ撺"),l11l1l_l1_ (u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࠧ撻"),l11l1l_l1_ (u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࠫ撼")]
l1l111ll11ll_l1_ = l1l11lll1lll_l1_+[l11l1l_l1_ (u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪ撽"),l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ撾"),l11l1l_l1_ (u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩ撿"),l11l1l_l1_ (u"ࠫࡸࡱࡩ࡯࠰ࡳ࡬ࡪࡴ࡯࡮ࡧࡱࡥࡱࡋࡍࡂࡆࠪ擀")]		# ,l11l1l_l1_ (u"ࠬࡹ࡫ࡪࡰ࠱࡭ࡳࡹࡴࡢ࡮࡯ࡉࡒࡇࡄࠨ擁")
addoncachefolder = os.path.join(l1llll11ll111_l1_,addon_id)
main_dbfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"࠭࡭ࡢ࡫ࡱࡨࡦࡺࡡ࠯ࡦࡥࠫ擂"))
iptv1_dbfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠧࡪࡲࡷࡺ࠶ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ擃"))
iptv2_dbfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠨ࡫ࡳࡸࡻ࠸ࡤࡢࡶࡤࡣࡤࡥ࠮ࡥࡤࠪ擄"))
l11l1l1l1ll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠩࡰ࠷ࡺࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩ擅"))
l11l111l11l_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠪࡰࡦࡹࡴࡷ࡫ࡧࡩࡴࡹ࠮ࡥࡣࡷࠫ擆"))
#l1lllllllll11_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠫࡱࡧࡳࡵ࡯ࡨࡲࡺ࠴ࡤࡢࡶࠪ擇"))
favoritesfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠬ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰ࡧࡥࡹ࠭擈"))
#dummyiptvfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"࠭ࡤࡶ࡯ࡰࡽ࡮ࡶࡴࡷ࠰ࡧࡥࡹ࠭擉"))
fulliptvfile = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ擊"))
l1l1111llll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ擋"))
l1l11ll111ll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡩࡧࡴࠨ擌"))
l1ll1lll1llll_l1_ = os.path.join(addoncachefolder,l11l1l_l1_ (u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡢ࠴࠵࠶࠰ࡠ࠰ࡳࡲ࡬࠭操"))
addonfolder = xbmcaddon.Addon().getAddonInfo(l11l1l_l1_ (u"ࠫࡵࡧࡴࡩࠩ擎"))
defaulticon = os.path.join(addonfolder,l11l1l_l1_ (u"ࠬ࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧ擏"))
defaultthumb = os.path.join(addonfolder,l11l1l_l1_ (u"࠭ࡴࡩࡷࡰࡦ࠳ࡶ࡮ࡨࠩ擐"))
defaultfanart = os.path.join(addonfolder,l11l1l_l1_ (u"ࠧࡧࡣࡱࡥࡷࡺ࠮࡫ࡲࡪࠫ擑"))
l1l11111l1l1_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠨࡥ࡫ࡥࡳ࡭ࡥ࡭ࡱࡪ࠲ࡹࡾࡴࠨ擒"))
l1ll11l11l_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ擓"))
l11ll1lll1ll_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ擔"),l11l1l_l1_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ擕"),addon_id,l11l1l_l1_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫ擖"))
l11111l1l1ll_l1_ = os.path.join(l111111llll1_l1_,l11l1l_l1_ (u"࠭࡭ࡦࡦ࡬ࡥࠬ擗"),l11l1l_l1_ (u"ࠧࡇࡱࡱࡸࡸ࠭擘"),l11l1l_l1_ (u"ࠨࡣࡵ࡭ࡦࡲ࠮ࡵࡶࡩࠫ擙"))
l1l11l11ll11_l1_ = [l11l1l_l1_ (u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫ據"),l11l1l_l1_ (u"ࠪࡖࡊࡖࡏࡓࡖࡖࠫ擛"),l11l1l_l1_ (u"ࠫࡊࡓࡁࡊࡎࡖࠫ擜"),l11l1l_l1_ (u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ擝"),l11l1l_l1_ (u"࠭ࡉࡔࡎࡄࡑࡎࡉࡓࠨ擞"),l11l1l_l1_ (u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ擟"),l11l1l_l1_ (u"ࠨࡍࡑࡓ࡜ࡔࡅࡓࡔࡒࡖࡘ࠭擠")]
l111l11lll1l_l1_ = [l11l1l_l1_ (u"ࠩࡄࡈࡉࡕࡎࡔࠩ擡"),l11l1l_l1_ (u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬ擢"),l11l1l_l1_ (u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭擣")]
FOLDERS_COUNT = 5
text_numbers = [l11l1l_l1_ (u"ࠬ฻แาࠩ擤"),l11l1l_l1_ (u"࠭ร้ๆࠪ擥"),l11l1l_l1_ (u"ࠧฬษ้๎ࠬ擦"),l11l1l_l1_ (u"ࠨอส่ะ࠭擧"),l11l1l_l1_ (u"ࠩิหอ฿ࠧ擨"),l11l1l_l1_ (u"ࠪาฬ๋ำࠨ擩"),l11l1l_l1_ (u"ุࠫอฯิࠩ擪"),l11l1l_l1_ (u"ูࠬวษ฻ࠪ擫"),l11l1l_l1_ (u"࠭หศ็้ࠫ擬"),l11l1l_l1_ (u"ࠧหษึ฽ࠬ擭"),l11l1l_l1_ (u"ࠨ฻สุึ࠭擮")]
l11ll11lllll_l1_ = l11l1l_l1_ (u"ࠩ⸾ࠤ⼢ࠦ⸪ࠡ⸽ࠪ擯")
now = int(time.time())
l111llll1l11_l1_ = 60
HOUR = 60*l111llll1l11_l1_
l1ll1ll1ll1l1_l1_ = 24*HOUR
l1111ll1111l_l1_ = 30*l1ll1ll1ll1l1_l1_
NO_CACHE = 0
l1111ll1l11_l1_ = 30*l111llll1l11_l1_
l1ll1l1ll_l1_ = 2*HOUR
REGULAR_CACHE = 16*HOUR
l1llll11_l1_ = 3*l1ll1ll1ll1l1_l1_
VERYLONG_CACHE = 30*l1ll1ll1ll1l1_l1_
PERMANENT_CACHE = 12*l1111ll1111l_l1_
l11ll1ll11ll_l1_ = 1*HOUR
l1lll11ll1l11_l1_ = [l11l1l_l1_ (u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬ擰"),l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖࠪ擱")]
l1lllllllllll_l1_ = [l11l1l_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ擲")]
l111111lll1l_l1_ = [l11l1l_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚ࠨ擳"),l11l1l_l1_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪ擴"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ擵"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ擶"),l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭擷"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡔ࠶ࡘࠫ擸"),l11l1l_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ擹")]
l111111lll1l_l1_ += [l11l1l_l1_ (u"࠭ࡈࡆࡎࡄࡐࠬ擺"),l11l1l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭擻"),l11l1l_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ擼"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ擽"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ擾"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ擿"),l11l1l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ攀")]
l1ll1ll1lllll_l1_ = [l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ攁"),l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ攂"),l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭攃"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ攄")]
l1ll1ll1lllll_l1_ += [l11l1l_l1_ (u"ࠪࡑ࠸࡛ࠧ攅"),l11l1l_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭攆"),l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ攇"),l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ攈")]
l1ll1ll1lllll_l1_ += [l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭攉"),l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ攊"),l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ攋")]
l1ll1ll1lllll_l1_ += [l11l1l_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ攌"),l11l1l_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ攍"),l11l1l_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ攎"),l11l1l_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ攏")]		# l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ攐")
l1ll1ll1lllll_l1_ += [l11l1l_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ攑"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ攒"),l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ攓"),l11l1l_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ攔"),l11l1l_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠷ࠧ攕"),l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ攖")]
#l1ll1ll1lllll_l1_ += [l11l1l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭攗"),l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ攘"),l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡕࡈࡖࡎࡋࡓࠨ攙"),l11l1l_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭攚")]
#l1ll1ll1lllll_l1_ += [l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ攛"),l11l1l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡃࡘࡈࡎࡕࡓࠨ攜"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡓࡉࡗ࡙ࡏࡏࡕࠪ攝"),l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅࡑࡈࡕࡎࡕࠪ攞")]
l1l1ll1lll1_l1_ = [l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ攟"),l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࠪ攠"),l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ攡"),l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ攢")]
l1l1ll1lll1_l1_ += [l11l1l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ攣"),l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ攤"),l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ攥"),l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ攦"),l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ攧")]
l1l1lll1lll_l1_ = [l11l1l_l1_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭攨"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ攩"),l11l1l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭攪"),l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ攫"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫ攬"),l11l1l_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪ攭")]
l1l1lll1lll_l1_ += [l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴ࡖࠩ攮"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ支"),l11l1l_l1_ (u"࡙ࠫ࡜ࡆࡖࡐࠪ攰"),l11l1l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ攱")]
#l1l1lll1lll_l1_ += [l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒࠪ攲"),l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ攳")]
l1ll11l1111_l1_ = [l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ攴"),l11l1l_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ攵"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ收"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧ攷"),l11l1l_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ攸"),l11l1l_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ改"),l11l1l_l1_ (u"ࠧࡂࡊ࡚ࡅࡐ࠭攺"),l11l1l_l1_ (u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ攻")]	# ,l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘࠩ攼")
l1ll11l1111_l1_ += [l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ攽"),l11l1l_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ放"),l11l1l_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ政"),l11l1l_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ敀"),l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ敁"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ敂"),l11l1l_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ敃")]
#l1ll11l1111_l1_ += [l11l1l_l1_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ敄"),l11l1l_l1_ (u"ࠫࡍࡋࡌࡂࡎࠪ故"),l11l1l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗ࠹࡝ࡁࡕࡅࡋࠫ敆"),l11l1l_l1_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ敇"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡈࡒࡕࡑࠩ效"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ敉"),l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ敊")]
l1lll1llllll1_l1_  = [l11l1l_l1_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ敋"),l11l1l_l1_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ敌"),l11l1l_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏࠧ敍"),l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ敎"),l11l1l_l1_ (u"ࠧࡃࡑࡎࡖࡆ࠭敏"),l11l1l_l1_ (u"ࠨࡃࡎࡓࡆࡓࠧ敐"),l11l1l_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ救"),l11l1l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ敒")]
l1lll1llllll1_l1_ += [l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ敓"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ敔"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩ敕"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ敖"),l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ敗"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭敘"),l11l1l_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ教"),l11l1l_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ敚"),l11l1l_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭敛")]
l1lll1llllll1_l1_ += [l11l1l_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ敜"),l11l1l_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ敝"),l11l1l_l1_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ敞")]		# l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ敟"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ敠"),l11l1l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭敡")
l1lll1llllll1_l1_ += [l11l1l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭敢"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ散"),l11l1l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ敤"),l11l1l_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠧ敥"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ敦"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆࠬ敧"),l11l1l_l1_ (u"ࠫࡘࡎࡏࡇࡊࡄࠫ敨")]
l1lll1llllll1_l1_ += [l11l1l_l1_ (u"ࠬࡈࡒࡔࡖࡈࡎࠬ敩"),l11l1l_l1_ (u"࡙࠭ࡂࡓࡒࡘࠬ敪"),l11l1l_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆࠩ敫"),l11l1l_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩ敬"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ敭"),l11l1l_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ敮"),l11l1l_l1_ (u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ敯")]
l1lll11l111l1_l1_  = [l11l1l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪ数"),l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ敱"),l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ敲"),l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭敳")]
l1lll11l111l1_l1_ += [l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨ整"),l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ敵")]
l1lll11l111l1_l1_ += [l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬ敶"),l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ敷"),l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ數")]
l1lll11l111l1_l1_ += [l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ敹"),l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛࠳ࡍࡐࡘࡌࡉࡘ࠭敺"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡔࡇࡕࡍࡊ࡙ࠧ敻")]
l1lll11l111l1_l1_ += [l11l1l_l1_ (u"ࠪࡑ࠸࡛࠭ࡍࡋ࡙ࡉࠬ敼"),l11l1l_l1_ (u"ࠫࡒ࠹ࡕ࠮ࡏࡒ࡚ࡎࡋࡓࠨ敽"),l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ敾")]
#l1lll11l111l1_l1_ += [l11l1l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬ敿"),l11l1l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘ࠭斀")]
#l1lll11l111l1_l1_ += [l11l1l_l1_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱ࡕࡋࡒࡔࡑࡑࡗࠬ斁"),l11l1l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡌࡃࡗࡐࡗࠬ斂"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡁࡖࡆࡌࡓࡘ࠭斃")]
l1lll1l11111l_l1_ = [l11l1l_l1_ (u"ࠫࡒ࠹ࡕࠨ斄"),l11l1l_l1_ (u"ࠬࡏࡐࡕࡘࠪ斅"),l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑࠫ斆"),l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠭文"),l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ斈")]		# l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ斉"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭斊")
l1ll11111l1_l1_ = l1lll1llllll1_l1_+l1lll11l111l1_l1_
l111l111111_l1_ = l1lll1llllll1_l1_+l1lll1l11111l_l1_
l111ll11lll_l1_ = l1lll1llllll1_l1_+l1lll1l11111l_l1_+l1lll11ll1l11_l1_
l1ll111111l_l1_ = l1ll1ll1lllll_l1_+l1l1lll1lll_l1_+l1ll11l1111_l1_+l1l1ll1lll1_l1_
l111l1l1lll1_l1_ = [ l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡖࡒࡐ࡚࡜ࡣ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭斋")
				,l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡉࡖࡗࡔࡘࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ斌")
				,l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩ斍")
				,l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ斎")
				,l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠲ࡵࡷࠫ斏")
				,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ斐")
				,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠳ࡶࡸࠬ斑")
				,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠵ࡲࡩ࠭斒")
				,l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠷ࡷࡪࠧ斓")
				,l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡄࡊࡈࡇࡐࡥࡈࡕࡖࡓࡗࡤࡖࡒࡐ࡚ࡌࡉࡘ࠳࠱ࡴࡶࠪ斔")
				,l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷࠫ斕")
				,l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭斖")
				,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡑࡔࡒ࡜ࡎࡋࡓࡠࡎࡌࡗ࡙࠳࠱ࡴࡶࠪ斗")
				,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ斘")
				,l11l1l_l1_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡈࡕࡖࡓࡗࡤ࡚ࡅࡔࡖ࠰࠵ࡸࡺࠧ料")
				,l11l1l_l1_ (u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡕࡇࡖࡘࡤࡇࡌࡍࡡ࡚ࡉࡇ࡙ࡉࡕࡇࡖ࠱࠶ࡹࡴࠨ斚")
				,l11l1l_l1_ (u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠸࡮ࡥࠩ斛")
				,l11l1l_l1_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡘࡗࡆࡍࡅࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ斜")
				,l11l1l_l1_ (u"ࠨࡏࡈࡒ࡚࡙࠭ࡔࡊࡒ࡛ࡤࡓࡅࡔࡕࡄࡋࡊ࡙࠭࠲ࡵࡷࠫ斝")
				,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ斞")
				,l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔ࠮࠳ࡶࡸࠬ斟")
				,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧ斠")
				#,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ斡")
				#,l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘࡥࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ斢")
				#,l11l1l_l1_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ斣")
				#,l11l1l_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ斤")
				#,l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫ斥")
				#,l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡍࡅࡕࡡࡏࡅ࡙ࡋࡓࡕࡡ࡙ࡉࡗ࡙ࡉࡐࡐࡢࡒ࡚ࡓࡂࡆࡔࡖ࠱࠶ࡹࡴࠨ斦")
				#,l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ斧")
				#,l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ斨")
				#,l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ斩")
				]
# l11111111l11_l1_ will not show l1111l1l11l1_l1_ errors
l1111lll1l1l_l1_ = [
						 l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡉࡈࡆࡅࡎࡣࡆࡉࡃࡐࡗࡑࡘ࠲࠷ࡳࡵࠩ斪")
						,l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ斫")
						,l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ斬")
						,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ断")
						,l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡈࡎࡈࡣࡓࡋࡗࡠࡊࡒࡗ࡙ࡔࡁࡎࡇ࠰࠵ࡸࡺࠧ斮")
						,l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡒࡂࡐࡇࡓࡒࡥࡕࡔࡇࡕࡅࡌࡋࡎࡕ࠯࠴ࡷࡹ࠭斯")
						,l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪ新")
						,l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ斱")
						,l11l1l_l1_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡏࡈࡎࡈ࡙ࡘࡋࡒࡄࡑࡑࡘࡊࡔࡔ࠮࠳ࡶࡸࠬ斲")
						]
l11ll1llll1l_l1_ = [l11l1l_l1_ (u"ࠩ࠻࠲࠽࠴࠸࠯࠺ࠪ斳"),l11l1l_l1_ (u"ࠪ࠵࠳࠷࠮࠲࠰࠴ࠫ斴"),l11l1l_l1_ (u"ࠫ࠶࠴࠰࠯࠲࠱࠵ࠬ斵"),l11l1l_l1_ (u"ࠬ࠾࠮࠹࠰࠷࠲࠹࠭斶"),l11l1l_l1_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠴࠱࠶࠷࠸ࠧ斷"),l11l1l_l1_ (u"ࠧ࠳࠲࠻࠲࠻࠽࠮࠳࠴࠳࠲࠷࠸࠰ࠨ斸")]
l1l1l1l_l1_ = {
			#,l11l1l_l1_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ方")	:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡵࡡ࡮࠰ࡦࡥࡲ࠭斺")]
			#,l11l1l_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭斻")	:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡰࡰࡧࡷࡵࡪࡤࡶࡹࡼ࠮ࡪࡴࠪ於")]
			#,l11l1l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧ施")	:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡱࡩࡹ࠭斾")]
			#,l11l1l_l1_ (u"ࠧࡆࡉ࡜࠸ࡇࡋࡓࡕࠩ斿")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ旀")]
			#,l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ旁")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨ旂")]
			#,l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ旃")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ旄")]
			#,l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭旅")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡫ࡧࡺࡰࡲࡻ࠳ࡲࡩࡷࡧࠪ旆")]
			#,l11l1l_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ旇")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࠸࡭࡫࡬ࡢ࡮࠱ࡱࡪ࠭旈")]
			#,l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭旉")	:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࡱࡱࡰ࡮ࡴࡥࠨ旊"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨࠫ旋")]
			#,l11l1l_l1_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭旌")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡳ࡯ࡷࡵ࠷ࡹ࠳ࡽࡳࠨ旍")]
			#,l11l1l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ旎")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡾࡩࡩ࡮ࡣ࠱ࡧࡴ࠭族")]
			#,l11l1l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉࠩ旐"):[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫࠲ࡳ࡫ࡴࠨ旑")]
			#,l11l1l_l1_ (u"࡙ࠬࡈࡊࡃ࡙ࡓࡎࡉࡅࠨ旒")	:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠱ࡧࡴࡳࠧ旓")]
			#,l11l1l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩ旔")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࠲ࡸ࡮࡯ࡰࡨࡳࡶࡴ࠴࡯࡯࡮࡬ࡲࡪ࠭旕")]    #	l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧࡲࡵࡳ࠳ࡩ࡯࡮ࠩ旖")
			 l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ旗")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡫ࡰࡣࡰ࠲ࡳ࡫ࡴࠨ旘")]
			,l11l1l_l1_ (u"ࠬࡇࡈࡘࡃࡎࠫ旙")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥ࡭ࡽࡡ࡬ࡶࡹ࠲ࡳ࡫ࡴࠨ旚")]
			,l11l1l_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭旛")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸࠬ旜")]
			,l11l1l_l1_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ旝")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡵࡤ࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬ旞")]
			,l11l1l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭旟")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬ࡧࡣࡷ࡭ࡲ࡯࠮ࡵࡸࠪ无")]
			,l11l1l_l1_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ旡")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡯ࡱࡦࡧࡲࡦࡨ࠱ࡧ࡭࠭既")]
			,l11l1l_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭旣")	:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡳࡣࡥ࡭ࡨ࠳ࡴࡰࡱࡱࡷ࠳ࡩ࡯࡮ࠩ旤")]
			,l11l1l_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ日")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡢࡤࡶࡩࡪࡪ࠮࡯ࡧࡷࠫ旦")]
			,l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ旧")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡩࡱࡲࡪࡻࡵࡤ࠯ࡥࡲࡱࠬ旨")]
			,l11l1l_l1_ (u"ࠧࡃࡔࡖࡘࡊࡐࠧ早")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥࡶࡸࡺࡥ࡫࠰ࡦࡳࡲ࠭旪")]
			,l11l1l_l1_ (u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ旫")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠶࠳࠴࠳ࡩ࡯࡮ࠩ旬")]
			,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ旭")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠱ࡤ࡫ࡰࡥ࠹ࡻ࠮ࡤࡱࡰࠫ旮")]
			,l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ旯")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦࡧࡢࡥࡱ࠱ࡧࡴࡳࠧ旰")]
			,l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ旱")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡨ࠴ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡹࡲࡶࡰ࠭旲")]
			,l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬ旳")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠰ࡧࡱࡻࡢ࠯࡫ࡲࠫ旴")]
			,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧ旵")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰ࡯ࠪ时")]
			,l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪ旷")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸ࠳ࡩ࡯࡮ࠩ旸")]
			,l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ旹")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠯ࡱࡳࡼ࠴ࡣࡰ࡯ࠪ旺")]
			,l11l1l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ旻")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬ旼"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ旽")]
			,l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ旾")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡧ࠳ࡪࡲࡢ࡯ࡤࡷ࠼࠴ࡣࡰ࡯ࠪ旿")]
			,l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪ昀")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪ昁")]
			,l11l1l_l1_ (u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭昂")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬ昃")]
			,l11l1l_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇࠧ昄")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨ࠺ࡥࡧ࠴ࡡࡻࡷࡵࡩࡪࡪࡧࡦ࠰ࡱࡩࡹ࠭昅")]
			,l11l1l_l1_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫ昆")	:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧ昇")]
			,l11l1l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ昈")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡺ࡮ࡶࠧ昉")]
			,l11l1l_l1_ (u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧ昊")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠱ࡧࡱࡵࡵࡥࠩ昋")]
			,l11l1l_l1_ (u"ࠧࡇࡑࡖࡘࡆ࠭昌")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡳࡸࡺࡡ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨ昍")]
			,l11l1l_l1_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ明")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡧ࡬ࡢࡥ࡬ࡱࡦ࠴ࡵࡴࠩ昏")]
			,l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏࠪ昐")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱࡭ࡷ࠭昑"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ昒"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ易"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪ昔"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠼࠷࠳࠷࠹࠱࠰࠵࠸࠳࠷࠲࠳ࠩ昕")]
			,l11l1l_l1_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭昖")	:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱࡡࡳࡤࡤࡰࡦ࠳ࡴࡷ࠰࡬ࡵࠬ昗")]
			,l11l1l_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ昘")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡰࡧࡴ࡬ࡱࡸࡸࡪ࠴ࡣࡰ࡯ࠪ昙")]
			,l11l1l_l1_ (u"ࠧࡌࡑࡇࡍࡊࡓࡁࡅࡡࡄࡔࡕ࠭昚")	:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡷ࡭ࡳࡿ࠮ࡤࡥ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ昛"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦ࡮ࡺ࠮࡭ࡻ࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨࠬ昜")]
			,l11l1l_l1_ (u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ昝")		:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳ࡵ࡮ࡦࠩ昞")]
			,l11l1l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭星")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯ࡥࡤࡱࠬ映")]
			,l11l1l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭昡")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡡ࡯ࡧࡷ࠲ࡨࡵ࠮ࡪ࡮ࠪ昢")]
			,l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ昣")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩࡧࡧ࠸ࡺ࠴ࡢࡦࡶࠪ昤")]
			,l11l1l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ春")	:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫ昦")]
			,l11l1l_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭昧")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࠱ࡷ࡭ࡵࡦࡩࡣ࠱ࡸࡻ࠭昨")]
			,l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ昩")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ昪"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ昫"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ昬")]
			,l11l1l_l1_ (u"࡚ࠬࡖࡇࡗࡑࠫ昭")		:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨࠫ昮")]
			,l11l1l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇࠧ是")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡨ࡯࡭ࡢ࠰ࡷࡹࡧ࡫ࠧ昰")]
			,l11l1l_l1_ (u"ࠩ࡜ࡅࡖࡕࡔࠨ昱")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨ昲")]
			,l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ昳")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ昴")]
			#,l11l1l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭昵")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱࡬ࡪࡸ࡯࡬ࡷࡤࡴࡵ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ昶"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲࡭࡫ࡲࡰ࡭ࡸࡥࡵࡶ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ昷"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳࡮ࡥࡳࡱ࡮ࡹࡦࡶࡰ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ昸"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡨࡦࡴࡲ࡯ࡺࡧࡰࡱ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ昹"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡩࡧࡵࡳࡰࡻࡡࡱࡲ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ昺"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡪࡨࡶࡴࡱࡵࡢࡲࡳ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ昻"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰࡫ࡩࡷࡵ࡫ࡶࡣࡳࡴ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ昼")]
			#,l11l1l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ昽")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱࡯࡭ࡸࡺࡰ࡭ࡣࡼࠫ显"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡹࡸࡧࡧࡦࡴࡨࡴࡴࡸࡴࠨ昿"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳ࡸ࡫࡮ࡥࡧࡰࡥ࡮ࡲࠧ晀"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡯ࡨࡷࡸࡧࡧࡦࡵࠪ晁"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡬ࡷࡱࡧ࡭ࡪࡥࠪ時"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭晃"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡰࡴ࡯ࡸࡰࡨࡶࡷࡵࡲࡴࠩ晄")]
			#,l11l1l_l1_ (u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ晅")		:[l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠶࠳ࡧࡰࡱࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬ晆"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠷࠴ࡡࡱࡲࡶࡴࡴࡺ࠮ࡤࡱࡰ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩ晇"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠸࠮ࡢࡲࡳࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ晈"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠲࠯ࡣࡳࡴࡸࡶ࡯ࡵ࠰ࡦࡳࡲ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ晉"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠳࠰ࡤࡴࡵࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ晊"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠴࠱ࡥࡵࡶࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ晋"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠵࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ晌")]
			#,l11l1l_l1_ (u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ晍")		:[l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭晎"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ晏"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ晐"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬ晑"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬ晒"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ晓"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫ晔")]
			#,l11l1l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖࠧ晕")	:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ晖"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ晗"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ晘"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭晙"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭晚"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ晛"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ晜")]
			,l11l1l_l1_ (u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ晝")		:[l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ晞"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ晟"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ晠"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭晡"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭晢"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩ晣"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ晤")]
			,l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ晥")	:[l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ晦"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭晧"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ晨"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ晩"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ晪"),l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ晫"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ晬")]
			,l11l1l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ晭")		:[l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ普"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬ景"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭晰")]
			,l11l1l_l1_ (u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭晱")	:[l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ晲"),l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ晳"),l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ晴")]
			,l11l1l_l1_ (u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨ晵")		:[l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡯ࡴࡪࡩࠨ晶"),l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮࠯࡬ࡱࡧ࡭ࠬ晷"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠭晸")]
			}
class l1lllll1l1l1l_l1_(): pass
class l1111lll11l1_l1_(l1lllll1l1l1l_l1_):
	def __init__(self):
		self.code = -99
		self.reason = l11l1l_l1_ (u"ࠫࠬ晹")
		self.content = l11l1l_l1_ (u"ࠬ࠭智")
		self.succeeded = False
		self.headers 	= {}
		self.cookies 	= {}
		self.url     	= l11l1l_l1_ (u"࠭ࠧ晻")
class l111l11llll1_l1_(xbmcgui.WindowXMLDialog):
	def __init__(self,*args,**kwargs):
		self.l11l111111l1_l1_ = -1
	def onClick(self,l11111l1lll1_l1_):
		if l11111l1lll1_l1_>=9010: self.l11l111111l1_l1_ = l11111l1lll1_l1_-9010
		self.delete()
	def l111l11ll1ll_l1_(self,*args):
		#self.getControl(9001).l1l1l11l111_l1_(header)
		#self.getControl(9009).l11ll11l1l11_l1_(text)
		#self.getControl(9010).l1l1l11l111_l1_(l1111l11ll11_l1_)
		#self.getControl(9011).l1l1l11l111_l1_(l1lll11ll1l1l_l1_)
		#self.getControl(9012).l1l1l11l111_l1_(l1111l1l111l_l1_)
		self.l1111l11ll11_l1_,self.l1lll11ll1l1l_l1_,self.l1111l1l111l_l1_ = args[0],args[1],args[2]
		self.header,self.text = args[3],args[4]
		self.l1111l1lll11_l1_,self.l11ll1llllll_l1_ = args[5],args[6]
		self.l1llll11l11l1_l1_,self.l1ll1ll1ll11l_l1_,self.l1lll1111l1ll_l1_ = args[7],args[8],args[9]
		if self.l1ll1ll1ll11l_l1_>0 or self.l1lll1111l1ll_l1_>0: self.l1lll1lll1l1l_l1_ = True
		else: self.l1lll1lll1l1l_l1_ = False
		self.l11111111lll_l1_,self.l111l11111ll_l1_ = l1lll111l111l_l1_(self.l1111l11ll11_l1_,self.l1lll11ll1l1l_l1_,self.l1111l1l111l_l1_,self.header,self.text,self.l1111l1lll11_l1_,self.l11ll1llllll_l1_,self.l1llll11l11l1_l1_,self.l1lll1lll1l1l_l1_)
		self.show()
		self.getControl(9050).setImage(self.l11111111lll_l1_)
		self.getControl(9050).setHeight(self.l111l11111ll_l1_)
		if not self.l1lll11ll1l1l_l1_ and self.l1111l11ll11_l1_ and self.l1111l1l111l_l1_: self.getControl(9012).setPosition(-220,0)
		return self.l11111111lll_l1_,self.l111l11111ll_l1_
	def l111lllllll1_l1_(self):
		if self.l1ll1ll1ll11l_l1_:
			import threading
			self.l1lll1ll11lll_l1_ = threading.Thread(target=self.l1llll1l11l1l_l1_,args=())
			self.l1lll1ll11lll_l1_.start()
			#self.l1lll1ll11lll_l1_.join()
		else: self.enableButtons()
	def l1llll1l11l1l_l1_(self):
		self.getControl(9020).setEnabled(True)
		for l11l1l1ll1_l1_ in range(1,self.l1ll1ll1ll11l_l1_+1):
			time.sleep(1)
			l1ll1ll1lll1l_l1_ = int(100*l11l1l1ll1_l1_/self.l1ll1ll1ll11l_l1_)
			self.l1lllll1lll1l_l1_(l1ll1ll1lll1l_l1_)
			if self.l11l111111l1_l1_>0: break
		self.enableButtons()
	def l111lll11ll1_l1_(self):
		if self.l1lll1111l1ll_l1_:
			import threading
			self.l1lll1ll1l111_l1_ = threading.Thread(target=self.l1111111ll11_l1_,args=())
			self.l1lll1ll1l111_l1_.start()
			#self.l1lll1ll1l111_l1_.join()
		else: self.enableButtons()
	def l1111111ll11_l1_(self):
		self.getControl(9020).setEnabled(True)
		time.sleep(self.l1ll1ll1ll11l_l1_)
		for l11l1l1ll1_l1_ in range(self.l1lll1111l1ll_l1_-1,-1,-1):
			time.sleep(1)
			l1ll1ll1lll1l_l1_ = int(100*l11l1l1ll1_l1_/self.l1lll1111l1ll_l1_)
			self.l1lllll1lll1l_l1_(l1ll1ll1lll1l_l1_)
			if self.l11l111111l1_l1_>0: break
		if self.l1lll1111l1ll_l1_>0: self.l11l111111l1_l1_ = 10
		self.delete()
	def l1lllll1lll1l_l1_(self,l1ll1ll1lll1l_l1_):
		self.l111111111l1_l1_ = l1ll1ll1lll1l_l1_
		self.getControl(9020).setPercent(self.l111111111l1_l1_)
	def enableButtons(self):
		if self.l1111l11ll11_l1_!=l11l1l_l1_ (u"ࠧࠨ晼"): self.getControl(9010).setEnabled(True)
		if self.l1lll11ll1l1l_l1_!=l11l1l_l1_ (u"ࠨࠩ晽"): self.getControl(9011).setEnabled(True)
		if self.l1111l1l111l_l1_!=l11l1l_l1_ (u"ࠩࠪ晾"): self.getControl(9012).setEnabled(True)
	def delete(self):
		self.close()
		try: os.remove(self.l11111111lll_l1_)
		except: pass
		#del self
	l11l1l_l1_ (u"ࠥࠦࠧࠓࠊࠊࡦࡨࡪࠥࡻࡰࡥࡣࡷࡩ࠭ࡹࡥ࡭ࡨ࠯ࡴࡪࡸࡣࡦࡰࡷ࠰࠯ࡧࡲࡨࡵࠬ࠾ࠒࠐࠉࠊࡶࡨࡼࡹࠦ࠽ࠡࡣࡵ࡫ࡸࡡ࠰࡞ࠏࠍࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡧࡲࡨࡵࠬࡂ࠶ࡀࠠࡵࡧࡻࡸࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࡡࡳࡩࡶ࡟࠶ࡣࠍࠋࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡥࡷ࡭ࡳࠪࡀ࠵࠾ࠥࡺࡥࡹࡶࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࡦࡸࡧࡴ࡝࠵ࡡࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡰࡦࡴࡦࡩࡳࡺࠬࡴࡧ࡯ࡪ࠳ࡺࡥࡹࡶࠣࡁࠥࡶࡥࡳࡥࡨࡲࡹ࠲ࡴࡦࡺࡷࠑࠏࠏࠉࡴࡧ࡯ࡪ࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠲ࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢ࡬ࡪ࡯ࡧࡩࡶࠣࡁࠥࡹࡥ࡭ࡨ࠱ࡧࡷ࡫ࡡࡵࡧࡖ࡬ࡴࡽࡉ࡮ࡣࡪࡩ࠭ࡹࡥ࡭ࡨ࠱ࡦࡺࡺࡴࡰࡰ࠳࠰ࡸ࡫࡬ࡧ࠰ࡥࡹࡹࡺ࡯࡯࠳࠯ࡷࡪࡲࡦ࠯ࡤࡸࡸࡹࡵ࡮࠳࠮ࡶࡩࡱ࡬࠮ࡩࡧࡤࡨࡪࡸࠬࡴࡧ࡯ࡪ࠳ࡺࡥࡹࡶ࠯ࡷࡪࡲࡦ࠯ࡲࡵࡳ࡫࡯࡬ࡦ࠮ࡶࡩࡱ࡬࠮ࡥ࡫ࡵࡩࡨࡺࡩࡰࡰ࠯ࡷࡪࡲࡦ࠯࡫ࡰࡥ࡬࡫࡟ࡸ࡫ࡧࡸ࡭࠲ࡳࡦ࡮ࡩ࠲ࡧࡻࡴࡵࡱࡱࡷࡹ࡯࡭ࡦࡱࡸࡸ࠱ࡹࡥ࡭ࡨ࠱ࡧࡱࡵࡳࡦࡶ࡬ࡱࡪࡵࡵࡵࠫࠐࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡺࡶࡤࡢࡶࡨࡔࡷࡵࡧࡳࡧࡶࡷࡇࡧࡲࠩࡲࡨࡶࡨ࡫࡮ࡵࠫࠐࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࡳࡦ࡮ࡩ࠲࡮ࡳࡡࡨࡧࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠱ࡹࡥ࡭ࡨ࠱࡭ࡲࡧࡧࡦࡡ࡫ࡩ࡮࡭ࡨࡵࠏࠍࠍࠧࠨࠢ晿")
class l1llll1l1lll1_l1_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l11l1l_l1_ (u"ࠫࠬ暀")
		if l11lll1lll11_l1_(l11l1l_l1_ (u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭暁")) or not l11lll1lll11_l1_(l11l1l_l1_ (u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧ暂")): self.status = l11l1l_l1_ (u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ暃")
	def onPlayBackStopped(self):
		self.status=l11l1l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ暄")
	def onPlayBackStarted(self):
		self.status = l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ暅")
		time.sleep(1)
	def onPlayBackError(self):
		self.status = l11l1l_l1_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ暆")
	def onPlayBackEnded(self):
		self.status = l11l1l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ暇")
class l1llll111l1l_l1_():
	def __init__(self,l1ll_l1_=False,l1lll1lll1lll_l1_=True):
		self.l1ll_l1_ = l1ll_l1_
		self.l1lll1lll1lll_l1_ = l1lll1lll1lll_l1_
		self.l111l1l11lll_l1_,self.l11l111l1111_l1_ = [],[]
		self.l11111l1llll_l1_,self.l1llllll1l1l1_l1_ = {},{}
		self.l1111ll1ll1l_l1_ = []
		self.l11111l1l11l_l1_,self.l1lll1111111l_l1_,self.l111lllll111_l1_ = {},{},{}
	def l111l11l1111_l1_(self,id,func,*args):
		id = str(id)
		self.l11111l1llll_l1_[id] = l11l1l_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭暈")
		if self.l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"࠭ࠧ暉"),id)
		# l1l11l1l1ll1_l1_ 2
		# import thread
		# thread.start_new_thread(self.run,(id,func,args))
		# l1l11l1l1ll1_l1_ 2 & 3
		import threading
		l11l11111l1l_l1_ = threading.Thread(target=self.run,args=(id,func,args))
		self.l1111ll1ll1l_l1_.append(l11l11111l1l_l1_)
		#l11l11111l1l_l1_.start()
		return l11l11111l1l_l1_
	def start_new_thread(self,id,func,*args):
		l11l11111l1l_l1_ = self.l111l11l1111_l1_(id,func,*args)
		l11l11111l1l_l1_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l11111l1l11l_l1_[id] = time.time()
		#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ暊"),l11l1l_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢ࡬ࡨ࠿ࠦࠧ暋")+id)
		try:
			#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ暌"),l11l1l_l1_ (u"ࠪࡉࡒࡇࡄ࠻࠼ࠣࠫ暍")+str(func))
			self.l1llllll1l1l1_l1_[id] = func(*args)
			if l11l1l_l1_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࠬ暎") in str(func) and not self.l1llllll1l1l1_l1_[id].succeeded:
				l111111l1lll_l1_(l11l1l_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡸ࡭ࡸࡥࡢࡦࡨࡨࠥࡕࡐࡆࡐࡘࡖࡑࠦࡦࡢ࡫࡯ࠫ暏"))
			self.l111l1l11lll_l1_.append(id)
			self.l11111l1llll_l1_[id] = l11l1l_l1_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࠨ暐")
			#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ暑"),l11l1l_l1_ (u"ࠨࡶ࡫ࡶࡪࡧࡤࠡࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠣ࡭ࡩࡀࠠࠨ暒")+id)
		except Exception as err:
			#LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ暓"),l11l1l_l1_ (u"ࠪࡸ࡭ࡸࡥࡢࡦࠣࡪࡦ࡯࡬ࡦࡦࠣ࡭ࡩࡀࠠࠨ暔")+id)
			if self.l1lll1lll1lll_l1_:
				l1ll1lllll1l_l1_ = traceback.format_exc()
				sys.stderr.write(l1ll1lllll1l_l1_)
				#traceback.print_exc(file=sys.stderr)
			self.l11l111l1111_l1_.append(id)
			self.l11111l1llll_l1_[id] = l11l1l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ暕")
		self.l1lll1111111l_l1_[id] = time.time()
		self.l111lllll111_l1_[id] = self.l1lll1111111l_l1_[id] - self.l11111l1l11l_l1_[id]
	def l1lll1lll1ll1_l1_(self):
		for proc in self.l1111ll1ll1l_l1_:
			proc.start()
	def l1ll1lll1111l_l1_(self):
		while l11l1l_l1_ (u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭暖") in list(self.l11111l1llll_l1_.values()): time.sleep(1.000)
def l1llll1111ll1_l1_():
	l1lll1l1l1lll_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ暗"))
	if l1lll1l1l1lll_l1_==addon_version:
		status = l11l1l_l1_ (u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪ暘")
	elif not os.path.exists(addoncachefolder):
		status = l11l1l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭暙")
		os.makedirs(addoncachefolder)
	#elif os.path.exists(main_dbfile):
	#	status = l11l1l_l1_ (u"ࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩ暚")
	else:
		status = l11l1l_l1_ (u"ࠪࡊ࡚ࡒࡌࡠࡗࡓࡈࡆ࡚ࡅࠨ暛")
		l111ll11111l_l1_ = [l11l1l_l1_ (u"ࠫ࠽࠴࠵࠯࠲ࠪ暜"),l11l1l_l1_ (u"ࠬ࠸࠰࠳࠳࠱࠵࠵࠴࠱࠺ࠩ暝"),l11l1l_l1_ (u"࠭࠲࠱࠴࠴࠲࠶࠷࠮࠳࠶ࡤࠫ暞"),l11l1l_l1_ (u"ࠧ࠳࠲࠵࠵࠳࠷࠲࠯࠵࠳ࠫ暟"),l11l1l_l1_ (u"ࠨ࠴࠳࠶࠷࠴࠰࠳࠰࠳࠶ࠬ暠"),l11l1l_l1_ (u"ࠩ࠵࠴࠷࠸࠮࠲࠲࠱࠶࠷࠭暡"),l11l1l_l1_ (u"ࠪ࠶࠵࠸࠳࠯࠲࠶࠲࠵࠼ࠧ暢"),l11l1l_l1_ (u"ࠫ࠷࠶࠲࠴࠰࠳࠹࠳࠷࠶ࠨ暣"),l11l1l_l1_ (u"ࠬ࠸࠰࠳࠵࠱࠴࠻࠴࠰࠷ࠩ暤")]
		l1lllll1lllll_l1_ = l111ll11111l_l1_[-1]
		l1111l1l1l1l_l1_ = l1ll1ll1lll11_l1_(l1lllll1lllll_l1_)
		l1lllll1111l1_l1_ = l1ll1ll1lll11_l1_(addon_version)
		if l1lllll1111l1_l1_>l1111l1l1l1l_l1_:
			status = l11l1l_l1_ (u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭暥")
			l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎࠏࠉࡧ࡫࡯ࡩࡸࠦ࠽ࠡࡱࡶ࠲ࡱ࡯ࡳࡵࡦ࡬ࡶ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲࠪࠏࠍࠍࠎࠏࡦࡪ࡮ࡨࡷࠥࡃࠠࡴࡱࡵࡸࡪࡪࠨࡧ࡫࡯ࡩࡸ࠲ࡲࡦࡸࡨࡶࡸ࡫࠽ࡕࡴࡸࡩ࠮ࠓࠊࠊࠋࠌࡪࡴࡸࠠࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠢ࡬ࡲࠥ࡬ࡩ࡭ࡧࡶ࠾ࠒࠐࠉࠊࠋࠌ࡭࡫ࠦࠧࡥࡣࡷࡥࡤ࠭ࠠࡪࡰࠣࡪ࡮ࡲࡥ࡯ࡣࡰࡩࠥࡧ࡮ࡥࠢࠪ࠲ࡩࡨࠧࠡ࡫ࡱࠤ࡫࡯࡬ࡦࡰࡤࡱࡪࡀࠍࠋࠋࠌࠍࠎࠏ࡯࡭ࡦࡢࡺࡪࡸࡳࡪࡱࡱࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡧࡴࡢࡡࠫ࠲࠯ࡅࠩ࡝࠰ࡧࡦࠬ࠲ࡦࡪ࡮ࡨࡲࡦࡳࡥ࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࠢࡀࠤࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯࡝࠳ࡡࠒࠐࠉࠊࠋࠌࠍࡴࡲࡤࡠࡸࡨࡶࡸ࡯࡯࡯ࡡࡦࡳࡲࡶࡡࡳࡧࠣࡁࠥ࡜ࡅࡓࡕࡌࡓࡓࡥࡃࡐࡏࡓࡅࡗࡋ࡟ࡑࡃࡕࡗࡊࡘࠨࡰ࡮ࡧࡣࡻ࡫ࡲࡴ࡫ࡲࡲ࠮ࠓࠊࠊࠋࠌࠍࠎ࡯ࡦࠡࠩࡰࡥ࡮ࡴࡤࡢࡶࡤࡣࠬࠦࡩ࡯ࠢࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠾ࠒࠐࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡼࡥࡳࡵ࡬ࡳࡳࡥࡣࡰ࡯ࡳࡥࡷ࡫࠾࠾࡮ࡤࡷࡹ࡬ࡵ࡭࡮ࡢࡺࡪࡸࡳࡪࡱࡱࡣࡨࡵ࡭ࡱࡣࡵࡩ࠿ࠓࠊࠊࠋࠌࠍࠎࠏࠉࡰ࡮ࡧࡣࡩࡨࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡧࡤࡥࡱࡱࡧࡦࡩࡨࡦࡨࡲࡰࡩ࡫ࡲ࠭ࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࡺࡲࡺ࠼ࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎ࡯ࡦࠡࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩࠦࡃ࡭ࡢ࡫ࡱࡣࡩࡨࡦࡪ࡮ࡨ࠾ࠥࡵࡳ࠯ࡴࡨࡲࡦࡳࡥࠩࡱ࡯ࡨࡤࡪࡢࡧ࡫࡯ࡩ࠱ࡳࡡࡪࡰࡢࡨࡧ࡬ࡩ࡭ࡧࠬࠑࠏࠏࠉࠊࠋࠌࠍࠎࠏࡳࡵࡣࡷࡹࡸࠦ࠽ࠡࠩࡖࡍࡒࡖࡌࡆࡡࡘࡔࡉࡇࡔࡆࠩࠐࠎࠎࠏࠉࠊࠋࠌࠍࠎࡨࡲࡦࡣ࡮ࠑࠏࠏࠉࠊࠋࠌࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠑࠏࠏࠉࠊࠤࠥࠦ暦")
	return status
def l111111l1l1l_l1_():
	l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡏࡄࡍࡓࡓࡅࡏࡗࠪ暧")
	succeeded,l11111lll111_l1_,l111ll1lll11_l1_ = True,False,False
	l1l1llll1ll_l1_ = EXTRACT_KODI_PATH(addon_path)
	type,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,mode,l1lll111ll1ll_l1_,l1llllllll111_l1_,text,context,l1ll1l1l1l1_l1_ = l1l1llll1ll_l1_
	l1lll11l11lll_l1_ = type,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,mode,l1lll111ll1ll_l1_,l1llllllll111_l1_,text,l11l1l_l1_ (u"ࠩࠪ暨"),l1ll1l1l1l1_l1_
	l1lll1ll1ll1l_l1_ = int(mode)
	l111l1111l1l_l1_ = int(l1lll1ll1ll1l_l1_%10)
	l111l1ll1l1_l1_ = int(l1lll1ll1ll1l_l1_/10)
	#l11l1l11ll_l1_ = l11l11ll11_l1_()
	l1ll11l1l111_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ暩"))
	l1ll11l1l111_l1_ = l1ll11l1l111_l1_.replace(ltr,l11l1l_l1_ (u"ࠫࠬ暪")).replace(rtl,l11l1l_l1_ (u"ࠬ࠭暫"))
	if l1lll1ll1ll1l_l1_==260: message = l11l1l_l1_ (u"࡙࠭ࠠࠡࠢࡩࡷࡹࡩࡰࡰ࠽ࠤࡠࠦࠧ暬")+addon_version+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡑ࡯ࡥ࡫࠽ࠤࡠࠦࠧ暭")+kodi_release+l11l1l_l1_ (u"ࠨࠢࡠࠫ暮")
	else:
		l111lll1llll_l1_ = l1llll_l1_(addon_path).replace(l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ暯"),l11l1l_l1_ (u"ࠪࠫ暰")).replace(l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ暱"),l11l1l_l1_ (u"ࠬ࠭暲"))
		l111lll1llll_l1_ = l111lll1llll_l1_.replace(l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ暳"),l11l1l_l1_ (u"ࠧࠨ暴")).strip(l11l1l_l1_ (u"ࠨࠢࠪ暵"))
		l111lll1llll_l1_ = l111lll1llll_l1_.replace(l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ暶"),l11l1l_l1_ (u"ࠪࠤࠬ暷")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ暸"),l11l1l_l1_ (u"ࠬࠦࠧ暹")).replace(l11l1l_l1_ (u"࠭ࠠࠡࠩ暺"),l11l1l_l1_ (u"ࠧࠡࠩ暻"))
		message = l11l1l_l1_ (u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧ暼")+l1ll11l1l111_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩ暽")+mode+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ暾")+l111lll1llll_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ暿")
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ曀"),LOGGING(l1ll1_l1_)+message)
	#text = text.replace(l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ曁"),l11l1l_l1_ (u"ࠧࠨ曂"))
	l1l11l1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ曃"))
	l11ll1lll1l1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡳࡥ࡯ࡷࡶࡣࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ曄"))
	l11l1l11ll_l1_ = RESTORE_PATH_NAME(l1ll11l1l111_l1_)
	l111l1ll1l11_l1_ = RESTORE_PATH_NAME(l111l1ll1l11_l1_)
	l111111ll11l_l1_ = [0,15,17,19,26,34,50,53]
	l1llll11l1111_l1_ = [0,15,17,19,26,34,50,53]
	l111llllll11_l1_ = l111l1ll1l1_l1_ not in l1llll11l1111_l1_
	l1ll1lll111ll_l1_ = l111l1ll1l1_l1_ in [23,28,71,72]
	l1llll1ll1l11_l1_ = l1lll1ll1ll1l_l1_ in [265,270]
	l1lllllll111l_l1_ = (l111llllll11_l1_ or l1ll1lll111ll_l1_) and not l1llll1ll1l11_l1_
	l11l11111ll1_l1_ = l1l11l1l1l_l1_!=l11l1l_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭曅") and (l1l11l1l1l_l1_!=l11l1l_l1_ (u"ࠫࠬ曆") or context==l11l1l_l1_ (u"ࠬ࠭曇"))
	l1lll1lll11ll_l1_ = l11l1l_l1_ (u"࠭ࡴࡺࡲࡨࡁࠬ曈") in l1l11l1l1l_l1_
	l1111ll1111_l1_ = l1lll1ll1ll1l_l1_ in [161,162,163,164,165,166,167]
	SEARCH = l111l1111l1l_l1_==9 or l1lll1ll1ll1l_l1_ in [145,516,523]
	l111lll1l11l_l1_ = not l1111ll1111_l1_
	l111l1l11l11_l1_ = not SEARCH
	l1111111l1l1_l1_ = l11l1l11ll_l1_ in [l11l1l_l1_ (u"ࠧࠨ曉"),l11l1l_l1_ (u"ࠨ࠰࠱ࠫ曊")]
	l11l111l11ll_l1_ = l1111111l1l1_l1_ or l111lll1l11l_l1_
	l111111lll11_l1_ = l1111111l1l1_l1_ or l111l1l11l11_l1_ or l1lll1lll11ll_l1_
	l1lll11111l1l_l1_ = l1lll1ll1ll1l_l1_ not in [260,265,270,330,540]
	if l11ll1lll1l1_l1_: l1111l11ll1l_l1_ = SEARCH or l1111ll1111_l1_
	else: l1111l11ll1l_l1_ = True
	l1l1l11lll_l1_ = l111l1ll1l1_l1_ in [74,75]
	l1111l1llll1_l1_ = not l1l1l11lll_l1_ and not l1ll1lll111ll_l1_
	l11111lll1ll_l1_ = l11l111l11ll_l1_ and l111111lll11_l1_ and l1lll11111l1l_l1_ and l1111l11ll1l_l1_ and l1111l1llll1_l1_
	l1llll11l111l_l1_ = l1lll11111l1l_l1_ and l1111l11ll1l_l1_ and l1111l1llll1_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ曋"),l11l1l_l1_ (u"ࠪࠫ曌"),l11l1l_l1_ (u"ࠫࠬ曍"),type+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ曎")+l1l11l1l1l_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ曏")+str(l1llll11l111l_l1_))
	if 1 and l11l11111ll1_l1_ and l11111lll1ll_l1_:
		l1llllll11lll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ曐"),l11l1l_l1_ (u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊ࠭曑"),l1lll11l11lll_l1_)
		if l1llllll11lll_l1_:
			#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠩࠪ曒"),l11l1l_l1_ (u"ࠪࡶࡪࡧࡤࡪࡰࡪࠤࡨࡧࡣࡩࡧࠪ曓"),l11l1l_l1_ (u"ࠫࠬ曔"),100,False)
			#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭曕"),l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠡࠢࠣࡖࡪࡧࡤࡪࡰࡪࠤࡨࡧࡣࡩࡧࡧࠤࡲ࡫࡮ࡶࠩ曖"))
			if 1 and l1lll1lll11ll_l1_:
				#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠧࠨ曗"),l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡹࡪࡰࡪࠤ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࠧ曘"),l11l1l_l1_ (u"ࠩࠪ曙"),100,False)
				l111lll11l11_l1_ = []
				import l11l11l11ll_l1_,FAVORITES
				l1llll1llll11_l1_ = l11l11l11ll_l1_.l11l11ll111_l1_
				l111lll11111_l1_ = FAVORITES.GET_ALL_FAVORITES()
				l11111ll1111_l1_ = l1l11l1l1l_l1_
				l111l11lllll_l1_,l111l1l1l111_l1_,l111lll111l_l1_,l1lll1ll11ll1_l1_,l1lll111l11l1_l1_,l111111l11l1_l1_,l111l1l1l11l_l1_,l1llll11l1lll_l1_,l1111111lll1_l1_ = EXTRACT_KODI_PATH(l11111ll1111_l1_)
				l1llll1lllll1_l1_ = l111l11lllll_l1_,l111l1l1l111_l1_,l111lll111l_l1_,l1lll1ll11ll1_l1_,l1lll111l11l1_l1_,l111111l11l1_l1_,l111l1l1l11l_l1_,l11l1l_l1_ (u"ࠪࠫ曚"),l1111111lll1_l1_
				#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ曛"),str(l1llll1lllll1_l1_))
				for l1llll1111111_l1_ in l1llllll11lll_l1_:
					l1lll1l111l1l_l1_ = l1llll1111111_l1_[l11l1l_l1_ (u"ࠬࡳࡥ࡯ࡷࡌࡸࡪࡳࠧ曜")]
					#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ曝"),str(l1lll1l111l1l_l1_))
					if l1lll1l111l1l_l1_==l1llll1lllll1_l1_ or l1llll1111111_l1_[l11l1l_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ曞")] in [265,270]:
						l1llll1111111_l1_ = GET_LIST_ITEM(l1lll1l111l1l_l1_,l1llll1llll11_l1_,l111lll11111_l1_)
						if l1llll1111111_l1_[l11l1l_l1_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫ曟")]:
							#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠩࠪ曠"),l11l1l_l1_ (u"ࠪࡹࡵࡪࡡࡵ࡫ࡱ࡫ࠥࡩ࡯࡯ࡶࡨࡼࡹ࠭曡"),l11l1l_l1_ (u"ࠫࠬ曢"),100,False)
							l1lll1l1ll111_l1_ = FAVORITES.GET_FAVORITES_CONTEXT_MENU(l111lll11111_l1_,l1lll1l111l1l_l1_,l1llll1111111_l1_[l11l1l_l1_ (u"ࠬࡴࡥࡸࡲࡤࡸ࡭࠭曣")])
							#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ曤"),str(l1lll1l1ll111_l1_))
							#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ曥"),str(l1llll1111111_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧ曦")]))
							l1llll1111111_l1_[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨ曧")] = l1lll1l1ll111_l1_+l1llll1111111_l1_[l11l1l_l1_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࡣࡲ࡫࡮ࡶࠩ曨")]
					l111lll11l11_l1_.append(l1llll1111111_l1_)
				settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡳࡧࡩࡶࡪࡹࡨ࠯ࡵࡷࡥࡹࡻࡳࠨ曩"),l11l1l_l1_ (u"ࠬ࠭曪"))
				if type==l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曫"): WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡇࡑ࡙ࡘࡥࡃࡂࡅࡋࡉࠬ曬"),l1lll11l11lll_l1_,l111lll11l11_l1_,REGULAR_CACHE)
			else: l111lll11l11_l1_ = l1llllll11lll_l1_
			if type==l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ曭") and l11l1l11ll_l1_!=l11l1l_l1_ (u"ࠩ࠱࠲ࠬ曮") and l1lllllll111l_l1_: l1111l111lll_l1_()
			l111l1ll11l1_l1_ = CREATE_KODI_MENU(l1lll11l11lll_l1_,l111lll11l11_l1_,succeeded,l11111lll111_l1_,l111ll1lll11_l1_)
			#xbmcgui.Dialog().notification(l11l1l_l1_ (u"ࠪࠫ曯"),l11l1l_l1_ (u"ࠫࡨࡸࡥࡢࡶ࡬ࡲ࡬ࠦ࡭ࡦࡰࡸࠫ曰"),l11l1l_l1_ (u"ࠬ࠭曱"),100,False)
			return
	elif type==l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭曲") and l1l11l1l1l_l1_==l11l1l_l1_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡆࡆࠪ曳") and l1llll11l111l_l1_:
		#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ更"),l11l1l_l1_ (u"ࠩ࠱ࠤࠥࠦࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࠤࠥࠦࡄࡦ࡮ࡨࡸ࡮ࡴࡧࠡࡱ࡯ࡨࠥࡩࡡࡤࡪࡨࡨࠥࡳࡥ࡯ࡷࠪ曵"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ曶"),l1lll11l11lll_l1_)
	#context = l11l1l_l1_ (u"ࠫࠬ曷")
	if l11l1l_l1_ (u"ࠬࡥࠧ書") in context: l1llll11l11ll_l1_,l111ll1l1111_l1_ = context.split(l11l1l_l1_ (u"࠭࡟ࠨ曹"),1)
	else: l1llll11l11ll_l1_,l111ll1l1111_l1_ = context,l11l1l_l1_ (u"ࠧࠨ曺")
	if l1llll11l11ll_l1_ in [l11l1l_l1_ (u"ࠨ࠳ࠪ曻"),l11l1l_l1_ (u"ࠩ࠵ࠫ曼"),l11l1l_l1_ (u"ࠪ࠷ࠬ曽"),l11l1l_l1_ (u"ࠫ࠹࠭曾"),l11l1l_l1_ (u"ࠬ࠻ࠧ替")] and l111ll1l1111_l1_:
		import FAVORITES
		FAVORITES.FAVORITES_DISPATCHER(context)
		#l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ最") l11l1111ll_l1_ l1lll11l11ll1_l1_ l1ll1lllll1l1_l1_ is no addon_handle l1l111l11_l1_ to l111l1llll1l_l1_ for l1lllllll1l11_l1_ directory
		#l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠪ朁") l11l1111ll_l1_ to open a menu list using l1lll11l1l1ll_l1_ addon_path
		#xbmc.executebuiltin(l11l1l_l1_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ朂")+sys.argv[0]+addon_path.split(l11l1l_l1_ (u"ࠩࠩࡧࡴࡴࡴࡦࡺࡷࡁࠬ會"))[0]+l11l1l_l1_ (u"ࠪࠪࡨࡵ࡮ࡵࡧࡻࡸࡂ࠶ࠧ朄")+l11l1l_l1_ (u"ࠦ࠮ࠨ朅"))
		#xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ朆")+addon_id+l11l1l_l1_ (u"࠭࠯ࡀࡶࡨࡼࡹࡃ࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠪࠩ朇"))
		# l11111l11l_l1_ not remove addon_path .. it is needed to update l1lll1l1ll11l_l1_ status
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡶࡪ࡬ࡲࡦࡵ࡫࠲ࡸࡺࡡࡵࡷࡶࠫ月"),addon_path)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬ有"))
		return
	elif l1llll11l11ll_l1_==l11l1l_l1_ (u"ࠩ࠹ࠫ朊"):
		if l111ll1l1111_l1_==l11l1l_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ朋"): l1llll1l_l1_(l11l1l_l1_ (u"ࠫ๏ืฬ๊ࠢส่ฬ์สูษิࠫ朌"),l11l1l_l1_ (u"ࠬาวา์ࠣๅา฻ࠠๆๆไࠤฬ๊สฮ็ํ่ࠬ服"))
		elif l111ll1l1111_l1_==l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊ࠭朎"): mode = 334
		results = l111l111l1l_l1_(type,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,mode,l1lll111ll1ll_l1_,l1llllllll111_l1_,text,context,l1ll1l1l1l1_l1_)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ朏"))
		return
	elif context==l11l1l_l1_ (u"ࠨ࠹ࠪ朐"):
		import l1lll1111ll_l1_
		l1lll1111ll_l1_.l1l1llll111_l1_()
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭朑"))
		return
	elif context==l11l1l_l1_ (u"ࠪ࠼ࠬ朒"):
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ朓")+addon_id+l11l1l_l1_ (u"ࠬࡅ࡭ࡰࡦࡨࡁࠬ朔")+str(mode)+l11l1l_l1_ (u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭朕"))
		return
	elif context==l11l1l_l1_ (u"ࠧ࠺ࠩ朖"):
		# l1lll1lllllll_l1_ update the l1ll1lll1l1ll_l1_ menu
		#results = l111l111l1l_l1_(type,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,mode,l1lll111ll1ll_l1_,l1llllllll111_l1_,text,context,l1ll1l1l1l1_l1_)
		# l1lll1lllllll_l1_ update the l1llll1lll11l_l1_ menu
		settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ朗"),l11l1l_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ朘"))
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧ朙"))
		return
	if settings.getSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡤࡣࡦ࡬ࡪ࠴ࡳࡵࡣࡷࡹࡸ࠭朚")) not in [l11l1l_l1_ (u"ࠬࡇࡕࡕࡑࠪ望"),l11l1l_l1_ (u"࠭ࡓࡕࡑࡓࠫ朜"),l11l1l_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ朝")]: settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ朞"),l11l1l_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ期"))
	if not settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡪࡸࡶࡦࡴࠪ朠")): settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ朡"),l11ll1llll1l_l1_[0])
	l11111llll1l_l1_ = l1llll1111ll1_l1_()
	l1111l11l111_l1_ = l11111llll1l_l1_!=l11l1l_l1_ (u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨ朢")
	if l1111l11l111_l1_:
		DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ朣"),l11l1l_l1_ (u"ࠧࠨ朤"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ朥"),l11l1l_l1_ (u"ࠩอ้ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦแ๋ࠢฯ๋ฬุใ࡝ࡰศ่๎ࠦวๅวุำฬืࠠาไ่࠾ࡡࡴ࡜࡯ࠩ朦")+addon_version)
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭朧"),l11l1l_l1_ (u"ࠫࠬ木"))
		settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬ朩"),l11l1l_l1_ (u"࠭ࠧ未"))
		settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡤࡦࡷࡧ࡫ࡢࠩ末"),l11l1l_l1_ (u"ࠨࠩ本"))
		settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ札"),l11l1l_l1_ (u"ࠪࠫ朮"))
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭术"),l11l1l_l1_ (u"ࠬ࠭朰"))
		settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ朱"),l11l1l_l1_ (u"ࠧࠨ朲"))
		settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡺࡹࡥࡳ࠰ࡳࡶ࡮ࡼࡳࠨ朳"),l11l1l_l1_ (u"ࠩࠪ朴"))
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡩ࡯ࡨࡲࡷ࠳ࡶࡥࡳ࡫ࡲࡨࠬ朵"),l11l1l_l1_ (u"ࠫࠬ朶"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ朷"),l11l1l_l1_ (u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩ朸"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ朹"),l11l1l_l1_ (u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩ机"))
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ朻"),l11l1l_l1_ (u"ࠪࡅ࡚࡚ࡈࠨ朼"))
		if not l11ll1lll1l1_l1_: settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡮ࡧࡱࡹࡸࡥࡣࡢࡥ࡫ࡩ࠳ࡹࡴࡢࡶࡸࡷࠬ朽"),l11l1l_l1_ (u"ࠬ࠭朾"))
		#l1lll1l1l1lll_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪ朿"))
		#if l1lll1l1l1lll_l1_:
		#	settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ杀"),l11l1l_l1_ (u"ࠨࠩ杁"))
		#	xbmc.executebuiltin(l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭杂"))
		#	return
		#l11lllll111l_l1_([main_dbfile])
		if l11111llll1l_l1_==l11l1l_l1_ (u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ权"):
			LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ杄"),l11l1l_l1_ (u"ࠬ࠴ࠠࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡕࡌࡑࡕࡒࡅࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ杅")+addon_path+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ杆"))
			DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ杇"),l11l1l_l1_ (u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࠩ杈"))
			for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
				DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ杉"),l11l1l_l1_ (u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࡢࠫ杊")+str(l1l11l11l11_l1_))
				DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ杋"),l11l1l_l1_ (u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࡣࠬ杌")+str(l1l11l11l11_l1_))
		else:
			LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭杍"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ李")+addon_path+l11l1l_l1_ (u"ࠨࠢࡠࠫ杏"))
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ材"),l11l1l_l1_ (u"ࠪࠫ村"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ杒"),l11l1l_l1_ (u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤฬ๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤศ๎ࠠห็ุ้ࠣำࠠไษืࠤฬ๊ศา่ส้ัࠦ࡜࡯࡞ࡱࠤุ๐โ้็ࠣห้ศๆࠡษ็ฬึ์วๆฮࠣฬอ฿ึࠡษ็ๅา๎ีศฬ่ࠣ฻๋ว็ࠢ฼้้ࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠึฯํัฮ่ࠦๆฬๆห๊๊ษࠨ杓"))
			l11lllll111l_l1_()
			FIX_ALL_DATABASES(False)
			l111l11l1ll1_l1_ = l1l11ll1lll_l1_(32)
			import l1l1l1ll1l1l_l1_
			l1l1l1ll1l1l_l1_.l1l11111l11l_l1_()
			l1l1l1ll1l1l_l1_.l1l11l11l1ll_l1_()
			l1l1l1ll1l1l_l1_.l1l1111lllll_l1_(l11l1l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭杔"),False)
			l1l1l1ll1l1l_l1_.l1l1111lllll_l1_(l11l1l_l1_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠪ杕"),False)
			l1l1l1ll1l1l_l1_.l1l11l111ll1_l1_(False)
			l1l1l1ll1l1l_l1_.l1l111lll11l_l1_(False)
			l1l1l1ll1l1l_l1_.l1l11l11l111_l1_(l11l1l_l1_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭杖"),l11l1l_l1_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࠩ杗"),False)
			l11l1l_l1_ (u"ࠥࠦࠧࠓࠊࠊࠋࠌࡸࡷࡿ࠺ࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳࡧ࡫࡯ࡩ࠷ࠦ࠽ࠡࡱࡶ࠲ࡵࡧࡴࡩ࠰࡭ࡳ࡮ࡴࠨࡶࡵࡨࡶ࡫ࡵ࡬ࡥࡧࡵ࠰ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ࠭ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࠬࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨ࠮ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠬࠑࠏࠏࠉࠊࠋࡶࡩࡹࡺࡩ࡯ࡩࡶ࠶ࠥࡃࠠࡹࡤࡰࡧࡦࡪࡤࡰࡰ࠱ࡅࡩࡪ࡯࡯ࠪ࡬ࡨࡂ࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭ࠩࠎࠌࠌࠍࠎࠏࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠳࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧ࡬ࡱࡧ࡭ࡴࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡱࡶࡣ࡯࡭ࡹࡿ࠮ࡢࡵ࡮ࠫ࠱࠭ࡴࡳࡷࡨࠫ࠮ࠓࠊࠊࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠏࠍࠍࠎࠏࠢࠣࠤ杘")
			try:
				l111l1ll1ll1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭杙"),l11l1l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ杚"),l11l1l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡲࡦࡵࡲࡰࡻ࡫ࡵࡳ࡮ࠪ杛"),l11l1l_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭杜"))
				l1ll1llll1ll1_l1_ = xbmcaddon.Addon(id=l11l1l_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬ杝"))
				l1ll1llll1ll1_l1_.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡧࡵࡵࡱࡢࡴ࡮ࡩ࡫ࠨ杞"),l11l1l_l1_ (u"ࠪࡪࡦࡲࡳࡦࠩ束"))
			except: pass
			try:
				l111l1ll1ll1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭杠"),l11l1l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ条"),l11l1l_l1_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡰࡦࡸࡰࡪ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥ࡮ࠪ杢"),l11l1l_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭杣"))
				l1ll1llll1ll1_l1_ = xbmcaddon.Addon(id=l11l1l_l1_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡧࡰࠬ杤"))
				l1ll1llll1ll1_l1_.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡼࡩࡥࡧࡲࡣࡶࡻࡡ࡭࡫ࡷࡽࠬ来"),l11l1l_l1_ (u"ࠪ࠷ࠬ杦"))
			except: pass
			try:
				l111l1ll1ll1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭杧"),l11l1l_l1_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ杨"),l11l1l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭杩"),l11l1l_l1_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭杪"))
				l1ll1llll1ll1_l1_ = xbmcaddon.Addon(id=l11l1l_l1_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ杫"))
				l1ll1llll1ll1_l1_.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡙ࡔࡓࡇࡄࡑࡘࡋࡌࡆࡅࡗࡍࡔࡔࠧ杬"),l11l1l_l1_ (u"ࠪ࠶ࠬ杭"))
			except: pass
			#if os.path.exists(dummyiptvfile):
			#	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ杮"),l11l1l_l1_ (u"ࠬ࠭杯"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ杰"),l11l1l_l1_ (u"ࠧฦาสࠤ่์สࠡฬึฮำีๅࠡะา้ฮࠦเࡊࡒࡗ࡚ࠥอไๆ๊ฯ์ิฯࠠโ์๋ࠣีอࠠศๆหี๋อๅอࠢไืํ็๋ࠠไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥะไใษษ๎ฬࠦศอๆหࠤ๊๊แศฬࠣไࡎࡖࡔࡗࠢฯำ๏ีษࠨ東"))
			#	import IPTV
			#	IPTV.CREATE_STREAMS()
			#if os.path.exists(l1l1111l1l1_l1_):
			#	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ杲"),l11l1l_l1_ (u"ࠩࠪ杳"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭杴"),l11l1l_l1_ (u"ࠫสึวࠡๅ้ฮࠥะำหะา้ࠥิฯๆหࠣไࡒ࠹ࡕࠡษ็้ํา่ะหࠣๅ๏ࠦ็ัษࠣห้ฮั็ษ่ะࠥ็ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡฬ็ๆฬฬ๊ศࠢหะ้ฮࠠๆๆไหฯࠦเࡎ࠵ࡘࠤัี๊ะหࠪ杵"))
			#	import l1l111l1l1l_l1_
			#	l1l111l1l1l_l1_.CREATE_STREAMS()
		data = FIX_AND_GET_FILE_CONTENTS(l11l111l11l_l1_)
		data = FIX_AND_GET_FILE_CONTENTS(favoritesfile)
		data = FIX_AND_GET_FILE_CONTENTS(l1l11ll111ll_l1_)
		settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩ杶"),addon_version)
		return
	l11111111111_l1_ = l111111l1l11_l1_(settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡳࡥࡴࡵࡤ࡫ࡪࡹࠧ杷")))
	l11111111111_l1_ = 0 if not l11111111111_l1_ else int(l11111111111_l1_)
	if not l11111111111_l1_ or now-l11111111111_l1_<=0 or now-l11111111111_l1_>REGULAR_CACHE:
		#l11lllll111l_l1_([main_dbfile,iptv1_dbfile,iptv2_dbfile])
		#settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡱࡪࡹࡳࡢࡩࡨࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ杸"),l11l1l_l1_ (u"ࠨࠩ杹"))
		l11l111lll1_l1_ = l11l111ll1l_l1_(False)
	l111lllll11l_l1_ = l111111l1l11_l1_(settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳࡯࡮ࡧࡱࡶ࠲ࡵ࡫ࡲࡪࡱࡧࠫ杺")))
	l111lllll11l_l1_ = 0 if not l111lllll11l_l1_ else int(l111lllll11l_l1_)
	l111l1l11l1l_l1_ = l111111l1l11_l1_(settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ杻")))
	l111l1l11l1l_l1_ = 0 if not l111l1l11l1l_l1_ else int(l111l1l11l1l_l1_)
	if not l111lllll11l_l1_ or not l111l1l11l1l_l1_ or now-l111l1l11l1l_l1_<0 or now-l111l1l11l1l_l1_>l111lllll11l_l1_:
		auth = 1
		if not l11lll1lll11_l1_(l11l1l_l1_ (u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬ杼")):
			# https://l1l1l1l111l_l1_.l11111l11l1l_l1_.com/l1lll11l1llll_l1_/l1111lllllll_l1_
			# unescapeHTML(l11l1l_l1_ (u"ࠬࠦࠦࠤࡺ࠵࠺࠸ࡈ࠻ࠡࠨࠦࡼ࠷࠽࠱ࡅ࠽ࠣࠪࠨࡾ࠲࠷࠴ࡄ࠿ࠥࠬࠣࡹ࠴࠹࠷ࡇࡁࠧ杽"))
			#l1lllll111111_l1_ = l11l1l_l1_ (u"࠭⸻ࠡ⼟ࠣࠤ⾏ࠦࠠ⸫ࠢ⸾ࠫ松")
			#l1llll1llllll_l1_ = l11l1l_l1_ (u"ࠧ⸼ࠢ⼠ࠤࠥ⾑ࠠࠡ⸬ࠣ⸿ࠬ板")
			l1l111lll1ll_l1_ = l1l11l11l1l1_l1_()
			if len(l1l111lll1ll_l1_)>1:
				LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ枀"),l11l1l_l1_ (u"ࠩ࠱ࠤࠥࠦࡓࡩࡱࡺ࡭ࡳ࡭ࠠࡒࡷࡨࡷࡹ࡯࡯࡯ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭极")+addon_path+l11l1l_l1_ (u"ࠪࠤࡢ࠭枂"))
				id,l1l1111l1111_l1_,l1l11ll1lll1_l1_,l11l1ll11l1_l1_,l11ll11llll1_l1_,reason = l1l111lll1ll_l1_[0]
				#if l11l1l_l1_ (u"ࠫࡡࡴ࠻࠼ࠩ枃") in reason: l1llll111l11l_l1_,l1llll111l1l1_l1_,l1llll111l1ll_l1_ = reason.split(l11l1l_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ构"),2)
				#else: l1llll111l11l_l1_,l1llll111l1l1_l1_,l1llll111l1ll_l1_ = reason,reason,reason
				l11llll111ll_l1_,l1l11l1ll1l1_l1_ = l11l1ll11l1_l1_.split(l11l1l_l1_ (u"࠭࡜࡯࠽࠾ࠫ枅"))
				del l1l111lll1ll_l1_[0]
				l1lll1ll1lll1_l1_ = random.sample(l1l111lll1ll_l1_,1)
				id,l1l1111l1111_l1_,l1l11ll1lll1_l1_,l11l1ll11l1_l1_,l11ll11llll1_l1_,reason = l1lll1ll1lll1_l1_[0]
				l1l11ll1lll1_l1_ = l11l1l_l1_ (u"ࠧ࡜ࡔࡗࡐࡢࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝ࠡ࠼ࠣࠫ枆")+id+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ枇")+l1l11ll1lll1_l1_
				l1111l11ll11_l1_,l1lll11ll1l1l_l1_ = l11l1ll11l1_l1_,l11ll11llll1_l1_
				l111llll_l1_ = [l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l11ll11lllll_l1_]
				choice = -9
				while choice<0:
					l111l1l1ll1l_l1_ = random.sample(l111llll_l1_,3)
					choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࠪ枈"),l111l1l1ll1l_l1_[0],l111l1l1ll1l_l1_[1],l111l1l1ll1l_l1_[2],l11llll111ll_l1_,l1l11ll1lll1_l1_,5,60)
					if choice==10: break
					if choice>=0 and l111l1l1ll1l_l1_[choice]==l111llll_l1_[1]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠪࠫ枉"),l11l1l_l1_ (u"ࠫࠬ枊"),l11l1l_l1_ (u"ࠬ฿่ะหࠪ枋"),l11l1l_l1_ (u"࠭ࠧ枌"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ枍"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้า่ศสࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰࠪ枎")+reason,20)
						if choice>=0: choice = -9
					elif choice>=0 and l111l1l1ll1l_l1_[choice]==l111llll_l1_[2]:
						choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠩࠪ枏"),l11l1l_l1_ (u"ࠪࠫ析"),l11ll11lllll_l1_,l11l1l_l1_ (u"ࠫࠬ枑"),l11llll111ll_l1_,l1l11ll1lll1_l1_+l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬ枒")+l111llll_l1_[0]+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ枓"),30)
					if choice==-1: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ枔"),l11l1l_l1_ (u"ࠨࠩ枕"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ枖"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢิั้ฮࠣา฼ษ࡛࠰ࡅࡒࡐࡔࡘ࡝࡝ࡰ็่ำื่อࠢสฺ่ำ๊ฮࠢฦาฯื้ࠠษะำ๋ࠥๆࠡษ็วั๎ศสࠢส่๊ะ่โำฬࠫ林"))
				auth = 1
			else: auth = 0
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ枘"),l11l1l_l1_ (u"ࠬࡇࡕࡕࡊࠪ枙"),auth,PERMANENT_CACHE)
	if l1111l11l111_l1_: l1l1l1ll1l1l_l1_.l1l111l1l1ll_l1_(False)
	# l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ枚")	l111l1llll1l_l1_ file to read/write the l111l11llll_l1_ menu list
	# l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ枛")		no l1111l11l11_l1_ l1lll11l11l1l_l1_ to the l111l11llll_l1_ menu list
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡓࡊࡖࡈࡗࡤ࡙ࡅࡂࡔࡆࡌࡤࡓࡏࡅࡇࡖࠤࡂࠦࡓࡊࡖࡈࡗࡤࡓࡏࡅࡇࡖࠤࡦࡴࡤࠡ࡯ࡲࡨࡪ࠷࠽࠾࠻ࠐࠎࠎࡕࡔࡉࡇࡕࡣࡘࡋࡁࡓࡅࡋࡣࡒࡕࡄࡆࡕࠣࡁࠥࡳ࡯ࡥࡧ࠳ࠤ࡮ࡴࠠ࡜࠳࠷࠹࠱࠻࠱࠷࠮࠸࠶࠸ࡣࠍࠋࠋࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡ࠿ࠣࡗࡎ࡚ࡅࡔࡡࡖࡉࡆࡘࡃࡉࡡࡐࡓࡉࡋࡓࠡࡱࡵࠤࡔ࡚ࡈࡆࡔࡢࡗࡊࡇࡒࡄࡊࡢࡑࡔࡊࡅࡔࠏࠍࠍࡗࡇࡎࡅࡑࡐࡣࡒࡕࡄࡆࡕࠣࡁࠥࡳ࡯ࡥࡧ࠵ࡁࡂ࠷࠶ࠡࡣࡱࡨࠥࡳ࡯ࡥࡧ࠳ࠥࡂ࠷࠶࠱ࠏࠍࠍ࡞ࡕࡕࡕࡗࡅࡉࡤࡓࡅࡏࡗࡖࠤࡂࠦ࡭ࡰࡦࡨ࠴ࠥ࡯࡮ࠡ࡝࠴࠸࠹ࡣࠍࠋࠋࠦࡲࡦࡳࡥࡠࠢࡀࠤࡈࡒࡅࡂࡐࡢࡑࡊࡔࡕࡠࡎࡄࡆࡊࡒࠨ࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࡱࡥࡲ࡫࡟ࠡ࠿ࠣࡖࡊ࡙ࡔࡐࡔࡈࡣࡕࡇࡔࡉࡡࡑࡅࡒࡋࠨ࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࡕࡉࡒࡋࡍࡃࡇࡕࡣࡗࡋࡓࡖࡎࡗࡗࡤࡓࡏࡅࡇࡖࠤࡂࠦࡓࡆࡃࡕࡇࡍࡥࡍࡐࡆࡈࡗࠥࡵࡲࠡࡔࡄࡒࡉࡕࡍࡠࡏࡒࡈࡊ࡙ࠠࡰࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࡣࡒࡋࡎࡖࡕࠐࠎࠎ࡯ࡦࠡࡔࡈࡑࡊࡓࡂࡆࡔࡢࡖࡊ࡙ࡕࡍࡖࡖࡣࡒࡕࡄࡆࡕ࠽ࠑࠏࠏࠉࠤ࡫ࡩࠤࡗࡇࡎࡅࡑࡐࡣࡒࡕࡄࡆࡕ࠽ࠤࡨࡵ࡮ࡥ࠳ࠣࡁࠥ࠮࡭ࡦࡰࡸࡣࡱࡧࡢࡦ࡮ࠣ࡭ࡳ࡛ࠦࠨ࠰࠱ࠫ࠱࠭ࡍࡢ࡫ࡱࠤࡒ࡫࡮ࡶࠩࡠ࠭ࠒࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡔࡇࡄࡖࡈࡎ࡟ࡎࡑࡇࡉࡘࡀࠠࡤࡱࡱࡨ࠶ࠦ࠽ࠡࠪࡰࡩࡳࡻ࡟࡭ࡣࡥࡩࡱࠧ࠽࡯ࡣࡰࡩࡤ࠯ࠍࠋࠋࠌ࡭࡫ࠦࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫࠥ࡯࡮ࠡࡶࡨࡼࡹࠦࡡ࡯ࡦࠣࡱࡪࡴࡵࡠ࡮ࡤࡦࡪࡲࠡ࠾ࡰࡤࡱࡪࡥࠠࡢࡰࡧࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳࡫ࡸࡪࡵࡷࡷ࠭ࡲࡡࡴࡶࡰࡩࡳࡻࡦࡪ࡮ࡨ࠭࠿ࠓࠊࠊࠋࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࠨ࠰ࠣࠤࠥࡘࡥࡢࡦ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ࠫࡢࡦࡧࡳࡳࡥࡰࡢࡶ࡫࠯ࠬࠦ࡝ࠨࠫࠐࠎࠎࠏࠉࡰ࡮ࡧࡊࡎࡒࡅࠡ࠿ࠣࡳࡵ࡫࡮ࠩ࡮ࡤࡷࡹࡳࡥ࡯ࡷࡩ࡭ࡱ࡫ࠬࠨࡴࡥࠫ࠮࠴ࡲࡦࡣࡧࠬ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡵ࡬ࡥࡈࡌࡐࡊࠦ࠽ࠡࡱ࡯ࡨࡋࡏࡌࡆ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠐࠎࠎࠏࠉ࡮ࡧࡱࡹࡎࡺࡥ࡮ࡵࡏࡍࡘ࡚࡛࠻࡟ࠣࡁࠥࡋࡖࡂࡎࠫࠫࡱ࡯ࡳࡵࠩ࠯ࡳࡱࡪࡆࡊࡎࡈ࠭ࠒࠐࠉࠊࡧ࡯ࡷࡪࡀࠍࠋࠋࠌࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࡏࡑࡗࡍࡈࡋࠧ࠭ࠩ࠱ࠤࠥࠦࡗࡳ࡫ࡷ࡭ࡳ࡭ࠠ࡭ࡣࡶࡸࠥࡳࡥ࡯ࡷࠣࠤࠥࡖࡡࡵࡪ࠽ࠤࡠࠦࠧࠬࡣࡧࡨࡴࡴ࡟ࡱࡣࡷ࡬࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࠊࡴࡨࡷࡺࡲࡴࡴࠢࡀࠤࡒࡇࡉࡏࡡࡇࡍࡘࡖࡁࡕࡅࡋࡉࡗ࠮ࡴࡺࡲࡨ࠰ࡳࡧ࡭ࡦࡡ࠯ࡹࡷࡲ࡟࠭࡯ࡲࡨࡪ࠲ࡩ࡮ࡣࡪࡩࡤ࠲ࡰࡢࡩࡨࡣ࠱ࡺࡥࡹࡶ࠯ࡧࡴࡴࡴࡦࡺࡷ࠰࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠯ࠍࠋࠋࠌࠍࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠࡴࡶࡵࠬࡲ࡫࡮ࡶࡋࡷࡩࡲࡹࡌࡊࡕࡗ࠭ࠒࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡳ࡫ࡷࡇࡋࡏࡉࠥࡃࠠ࡯ࡧࡺࡊࡎࡒࡅ࠯ࡧࡱࡧࡴࡪࡥࠩࠩࡸࡸ࡫࠾ࠧࠪࠏࠍࠍࠎࠏ࡯ࡱࡧࡱࠬࡱࡧࡳࡵ࡯ࡨࡲࡺ࡬ࡩ࡭ࡧ࠯ࠫࡼࡨࠧࠪ࠰ࡺࡶ࡮ࡺࡥࠩࡰࡨࡻࡋࡏࡌࡆࠫࠐࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡃࠠࡎࡃࡌࡒࡤࡊࡉࡔࡒࡄࡘࡈࡎࡅࡓࠪࡷࡽࡵ࡫ࠬ࡯ࡣࡰࡩࡤ࠲ࡵࡳ࡮ࡢ࠰ࡲࡵࡤࡦ࠮࡬ࡱࡦ࡭ࡥࡠ࠮ࡳࡥ࡬࡫࡟࠭ࡶࡨࡼࡹ࠲ࡣࡰࡰࡷࡩࡽࡺࠬࡪࡰࡩࡳࡩ࡯ࡣࡵࠫࠐࠎࠎࠨࠢࠣ果")
	results = l111l111l1l_l1_(type,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,mode,l1lll111ll1ll_l1_,l1llllllll111_l1_,text,context,l1ll1l1l1l1_l1_)
	# l1llll1l1lll_l1_ l111lll1l1ll_l1_: succeeded,l11111lll111_l1_,l111ll1lll11_l1_ = True,False,True
	# l11111lll111_l1_ = True => l1ll1l1111l1_l1_ this list is l1lll1l1llll1_l1_ and will exit to main menu
	# l11111lll111_l1_ = False => l1ll1l1111l1_l1_ this list is l1111lll111l_l1_ and will exit to l111l11llll_l1_ menu
	# l111ll1lll11_l1_ = True => will cause the l1lll1lll111l_l1_ status to l1llllllll1l1_l1_ l1lll1ll1llll_l1_
	# l111ll1lll11_l1_ = False => will l1lll1ll1l11l_l1_ the l1lll1lll111l_l1_ status to l111l1lll1ll_l1_ l1111l1l11ll_l1_
	#succeeded,l11111lll111_l1_,l111ll1lll11_l1_ = True,False,True
	#if not l11l1111ll11_l1_: l111ll1lll11_l1_ = False
	if l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ枝") in text: l11111lll111_l1_ = True
	if type==l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ枞"):
		if l11l1l11ll_l1_!=l11l1l_l1_ (u"ࠫ࠳࠴ࠧ枟") and l1lllllll111l_l1_: l1111l111lll_l1_()
		if addon_handle>-1:
			if (READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬ࡯࡮ࡵࠩ枠"),l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ枡"),l11l1l_l1_ (u"ࠧࡂࡗࡗࡌࠬ枢")) or l1lll1ll1ll1l_l1_ not in l111111ll11l_l1_) and not l11lll1lll11_l1_(l11l1l_l1_ (u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ枣")):
				import l11l11l11ll_l1_
				l1llllll11lll_l1_ = GET_ALL_LIST_ITEMS(l11l11l11ll_l1_.l11l11ll111_l1_)
				l111l1ll11l1_l1_ = CREATE_KODI_MENU(l1lll11l11lll_l1_,l1llllll11lll_l1_,succeeded,l11111lll111_l1_,l111ll1lll11_l1_)
				if 1 and l1llllll11lll_l1_ and l1llll11l111l_l1_:
					WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡐࡉࡓ࡛ࡓࡠࡅࡄࡇࡍࡋࠧ枤"),l1lll11l11lll_l1_,l1llllll11lll_l1_,REGULAR_CACHE)
				#elif 1 and not l1llllll11lll_l1_:
				#	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࠨ枥"),l1lll11l11lll_l1_)
			else:
				xbmcplugin.addDirectoryItem(addon_handle,l11l1l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ枦")+addon_id+l11l1l_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴ࠬ枧"),xbmcgui.ListItem(l11l1l_l1_ (u"࠭ไะ์ๆࠤฺ๊ใๅห้๋ࠣࠦฬ่ษี็ࠬ枨")))
				xbmcplugin.addDirectoryItem(addon_handle,l11l1l_l1_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪ枩")+addon_id+l11l1l_l1_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾࡮࡬ࡲࡰࠬ࡭ࡰࡦࡨࡁ࠺࠶࠰ࠨ枪"),xbmcgui.ListItem(l11l1l_l1_ (u"ࠩฦๅฯำࠠๅฬๅีศࠦวๅฬไหฺ๐ไࠨ枫")))
			xbmcplugin.endOfDirectory(addon_handle,succeeded,l11111lll111_l1_,l111ll1lll11_l1_)
	return
def l111l111l1l_l1_(type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_):
	l1lll1ll1ll1l_l1_ = int(mode)
	l111l1ll1l1_l1_ = int(l1lll1ll1ll1l_l1_//10)
	if   l111l1ll1l1_l1_==0:  import l1l1l1ll1l1l_l1_ 	; results = l1l1l1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,text)
	elif l111l1ll1l1_l1_==1:  import l1111l1l_l1_ 		; results = l1111l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==2:  import l1l1ll1l1ll_l1_ 		; results = l1l1ll1l1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,l11lll1_l1_,text)
	elif l111l1ll1l1_l1_==3:  import l111ll1llll_l1_ 		; results = l111ll1llll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,l11lll1_l1_,text)
	elif l111l1ll1l1_l1_==4:  import l1l1l11l1_l1_ 	; results = l1l1l11l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==5:  import l11l1lll1111_l1_ 	; results = l11l1lll1111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==6:  import l1ll1111l_l1_ 	; results = l1ll1111l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==7:  import l11ll1l_l1_ 		; results = l11ll1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==8:  import l1l1ll1ll11_l1_ 	; results = l1l1ll1ll11_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==9:  import l1ll1l1l11_l1_		; results = l1ll1l1l11_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==10: import l1l11ll1ll1_l1_ 		; results = l1l11ll1ll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url)
	elif l111l1ll1l1_l1_==11: import l1l1ll1lll11_l1_ 	; results = l1l1ll1lll11_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==12: import l11111111l_l1_ 		; results = l11111111l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,l11lll1_l1_,text)
	elif l111l1ll1l1_l1_==13: import l1l1l11ll_l1_	; results = l1l1l11ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,l11lll1_l1_,text)
	elif l111l1ll1l1_l1_==14: import l1111111lll_l1_ 		; results = l1111111lll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_,name,l111_l1_)
	elif l111l1ll1l1_l1_==15: import l1l1l1ll1l1l_l1_ 	; results = l1l1l1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,text)
	elif l111l1ll1l1_l1_==16: import l1111ll1111_l1_	 	; results = l1111ll1111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,l11lll1_l1_,l1ll1l1l1l1_l1_)
	elif l111l1ll1l1_l1_==17: import l1l1l1ll1l1l_l1_ 	; results = l1l1l1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,text)
	elif l111l1ll1l1_l1_==18: import l111llllll1_l1_	; results = l111llllll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==19: import l1l1l1ll1l1l_l1_ 	; results = l1l1l1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,text)
	elif l111l1ll1l1_l1_==20: import l111l1l11_l1_		; results = l111l1l11_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==21: import l1lll1ll1l1l_l1_ ; results = l1lll1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==22: import l1lll1ll1ll_l1_ 	; results = l1lll1ll1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,l11lll1_l1_,text)
	elif l111l1ll1l1_l1_==23: import IPTV 		; results = IPTV.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_,l1ll1l1l1l1_l1_)
	elif l111l1ll1l1_l1_==24: import l1lll1ll_l1_ 		; results = l1lll1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==25: import l11l1111l_l1_ 	; results = l11l1111l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==26: import l11l11l11ll_l1_ 		; results = l11l11l11ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==27: import FAVORITES 	; results = FAVORITES.MAIN(l1lll1ll1ll1l_l1_,context)
	elif l111l1ll1l1_l1_==28: import IPTV 		; results = IPTV.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_,l1ll1l1l1l1_l1_)
	elif l111l1ll1l1_l1_==29: import l11l111l1l1l_l1_	; results = l11l111l1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,l11lll1_l1_,text)
	elif l111l1ll1l1_l1_==30: import l1ll11llll_l1_		; results = l1ll11llll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==31: import l11l1llllll1_l1_	; results = l11l1llllll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==32: import l1l1l1l11l1_l1_	; results = l1l1l1l11l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==33: import l111lll1ll_l1_		; results = l111lll1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url)
	elif l111l1ll1l1_l1_==34: import l1l1l1ll1l1l_l1_ 	; results = l1l1l1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,text)
	elif l111l1ll1l1_l1_==35: import l1l111ll_l1_		; results = l1l111ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==36: import l111lll1111_l1_		; results = l111lll1111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==37: import l11111111_l1_		; results = l11111111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==38: import l111lll11l1_l1_ 		; results = l111lll11l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==39: import l1ll1l11111_l1_	; results = l1ll1l11111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==40: import l11ll1l1ll_l1_	; results = l11ll1l1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_)
	elif l111l1ll1l1_l1_==41: import l11ll1l1ll_l1_	; results = l11ll1l1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_)
	elif l111l1ll1l1_l1_==42: import l1llll1ll1_l1_		; results = l1llll1ll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==43: import l1lll1l11l1_l1_		; results = l1lll1l11l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==44: import l1lll1l11ll_l1_		; results = l1lll1l11ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==45: import l1l11ll11ll_l1_		; results = l1l11ll11ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==46: import l1ll1ll11ll1_l1_		; results = l1ll1ll11ll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==47: import l1ll1l1111_l1_	; results = l1ll1l1111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==48: import l1l1ll11111l_l1_		; results = l1l1ll11111l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==49: import l1ll1lll11_l1_		; results = l1ll1lll11_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==50: import l1l1l1ll1l1l_l1_ 	; results = l1l1l1ll1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,text)
	elif l111l1ll1l1_l1_==51: import l1lll1111l1_l1_ 	; results = l1lll1111l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==52: import l1lll1111l1_l1_ 	; results = l1lll1111l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==53: import l11l11l11ll_l1_ 		; results = l11l11l11ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==54: import l1lll1111ll_l1_	; results = l1lll1111ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,l11lll1_l1_)
	elif l111l1ll1l1_l1_==55: import l1ll1lllll_l1_ 	; results = l1ll1lllll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==56: import l1l1lll111l1_l1_		; results = l1l1lll111l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==57: import l1ll11llll1_l1_		; results = l1ll11llll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==58: import l11ll11111ll_l1_	; results = l11ll11111ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==59: import l1ll11l1lll_l1_		; results = l1ll11l1lll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==60: import l1ll11l1l1l_l1_		; results = l1ll11l1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==61: import l1ll111_l1_		; results = l1ll111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==62: import l1ll1l11l11_l1_		; results = l1ll1l11l11_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==63: import l1ll1lll1l_l1_		; results = l1ll1lll1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==64: import l11l1llll1ll_l1_		; results = l11l1llll1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==65: import l1lllll11l_l1_		; results = l1lllll11l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==66: import l11l1ll11ll1_l1_		; results = l11l1ll11ll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==67: import l1l1l11l1ll_l1_		; results = l1l1l11l1ll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==68: import l111l1lll1_l1_		; results = l111l1lll1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==69: import l1lllll111_l1_		; results = l1lllll111_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==70: import l1l11lll1l1_l1_		; results = l1l11lll1l1_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==71: import l1l111l1l1l_l1_			; results = l1l111l1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_,l1ll1l1l1l1_l1_)
	elif l111l1ll1l1_l1_==72: import l1l111l1l1l_l1_			; results = l1l111l1l1l_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text,type,l11lll1_l1_,l1ll1l1l1l1_l1_)
	elif l111l1ll1l1_l1_==73: import l1l111lll_l1_	; results = l1l111lll_l1_.MAIN(l1lll1ll1ll1l_l1_,url,text)
	elif l111l1ll1l1_l1_==74: import l1l1l11lll_l1_		; results = l1l1l11lll_l1_.MAIN(l1lll1ll1ll1l_l1_)
	elif l111l1ll1l1_l1_==75: import l1l1l11lll_l1_		; results = l1l1l11lll_l1_.MAIN(l1lll1ll1ll1l_l1_)
	else: results = None
	return results
def l11l11ll11_l1_(name=l11l1l_l1_ (u"ࠪࠫ枬")):
	if not name: name = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ枭"))
	name = name.replace(l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ枮"),l11l1l_l1_ (u"࠭ࠧ枯"))
	name = name.replace(l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠬ枰"),l11l1l_l1_ (u"ࠨࠢࠪ枱")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭枲"),l11l1l_l1_ (u"ࠪࠤࠬ枳")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ枴"),l11l1l_l1_ (u"ࠬࠦࠧ枵")).strip(l11l1l_l1_ (u"࠭ࠠࠨ架"))
	name = name.replace(l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ枷"),l11l1l_l1_ (u"ࠨࠩ枸")).replace(l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ枹"),l11l1l_l1_ (u"ࠪࠫ枺"))
	tmp = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠࠨ枻"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	if not name: name = l11l1l_l1_ (u"ࠬࡓࡡࡪࡰࠣࡑࡪࡴࡵࠨ枼")
	return name
def l1llllll11l11_l1_(code,reason,source,l1ll_l1_):
	if l11l1l_l1_ (u"࠭࠭ࠨ枽") in source: l1l1llllll1_l1_ = source.split(l11l1l_l1_ (u"ࠧ࠮ࠩ枾"),1)[0]
	else: l1l1llllll1_l1_ = source
	l111l1ll1l1l_l1_ = code in [7,11001,11002,10054]
	l1ll1lll11l1l_l1_ = reason.lower()
	l1lllll1l11ll_l1_ = code in [0,104,10061,111]
	l1lllll1l11l1_l1_ = l11l1l_l1_ (u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ枿") in l1ll1lll11l1l_l1_
	l1lllll1l111l_l1_ = l11l1l_l1_ (u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ柀") in l1ll1lll11l1l_l1_
	l1lllll1l1111_l1_ = l11l1l_l1_ (u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪ柁") in l1ll1lll11l1l_l1_
	l1lllll11llll_l1_ = l11l1l_l1_ (u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠥࡹࡥࡤࡷࡵ࡭ࡹࡿࠠࡤࡪࡨࡧࡰ࠭柂") in l1ll1lll11l1l_l1_
	l1lll11l1ll1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ柃"))
	l1lll111l1ll1_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭柄"))
	l11111l111l1_l1_ = l11l1l_l1_ (u"ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ柅")
	l1lll1l1111ll_l1_ = l11l1l_l1_ (u"ࠨࡇࡵࡶࡴࡸࠠࠨ柆")+str(code)+l11l1l_l1_ (u"ࠩ࠽ࠤࠬ柇")+reason
	l1lll1l1111ll_l1_ = l1llll_l1_(l1lll1l1111ll_l1_)
	if l1lllll1l11ll_l1_ or l1lllll1l11l1_l1_ or l1lllll1l111l_l1_ or l1lllll1l1111_l1_ or l1lllll11llll_l1_:
		l11111l111l1_l1_ += l11l1l_l1_ (u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ柈")
	if l111l1ll1l1l_l1_: l11111l111l1_l1_ += l11l1l_l1_ (u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ柉")
	l1lll1l1111ll_l1_ = l11l1l_l1_ (u"ࠬࡢ࡮࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ柊")+l1lll1l1111ll_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ柋")
	if l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠧࡂࡕࡎࠫ柌") or l1lll111l1ll1_l1_==l11l1l_l1_ (u"ࠨࡃࡖࡏࠬ柍"):
		l11111l111l1_l1_ += l11l1l_l1_ (u"ࠩ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤศีๆศ้ࠣรࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭柎")
	l111llll11l1_l1_ = False
	if l1ll_l1_:
		if l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ柏") or l1lll111l1ll1_l1_==l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ某"):
			#if kodi_version<19: l1lll1l1111ll_l1_ = l1lll1l1111ll_l1_.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ柑"))
			l111llll11l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭柒"),l11l1l_l1_ (u"ࠧࠨ染"),l11l1l_l1_ (u"ࠨࠩ柔"),l1l1llllll1_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭柕")+TRANSLATE(l1l1llllll1_l1_),l11111l111l1_l1_,l1lll1l1111ll_l1_)
		else: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ柖"),l11l1l_l1_ (u"ࠫࠬ柗"),l1l1llllll1_l1_+l11l1l_l1_ (u"ࠬࠦࠠࠡࠩ柘")+TRANSLATE(l1l1llllll1_l1_),l11111l111l1_l1_,l1lll1l1111ll_l1_)
	if reason.endswith(l11l1l_l1_ (u"࠭ࠠࠪࠩ柙")): reason = reason.rsplit(l11l1l_l1_ (u"ࠧ࡝ࡰࠪ柚"))[0]
	#if l111llll11l1_l1_: LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭柛"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ柜")+str(code)+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ柝")+reason+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭柞")+source+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡅࡗࡇࡂࡊࡅ࠽ࠤࡠࠦࠧ柟")+l11111l111l1_l1_+l11l1l_l1_ (u"࠭ࠠ࡞࡟ࠣࠤࠥࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ柠")+l1lll1l1111ll_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ柡"))
	return l111llll11l1_l1_
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢࡧࡲࡸࠦ࡯ࡳࠢࡥࡰࡴࡩ࡫ࡦࡦ࠴ࠤࡴࡸࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠳ࠢࡲࡶࠥࡨ࡬ࡰࡥ࡮ࡩࡩ࠹࠺ࠎࠌࠌࠍࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥࡃࠠࠨ่๋฽๋ࠥๆࠡษ็ััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆ࠲ࠬࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠤࡧࡲ࡯ࡤ࡭ࡢࡱࡪ࡫ࡳࡴࡣࡪࡩࠥ࠱࠽๋้ࠡࠩࠣࠦสา์าࠤฯ็วึ์็ࠤฬ้หาࠢยࠫࠒࠐࠉࠊ࡫ࡩࠤࡩࡴࡳ࠻ࠏࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽ࠡࠩ็ำ๏้ࠠฯูฦࠤࡉࡔࡓ๊่ࠡ฽๋อ็ࠡฬ฼ิึࠦสาฮ่อࠥอำๆࠢส่๊๎โฺࠢศ่๎ࠦัใ็๊ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄࠢ࠮ࡁ้ࠥ࠭ࠠษ็ือฮࠠใัࠣ๎่๎ๆࠡࠩ࠮ࡦࡱࡵࡣ࡬ࡡࡰࡩࡪࡹࡳࡢࡩࡨࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈࠦ࠽๊ࠡࠩิฬࠦวๅ็๋ๆ฾ࠦแ๋้ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠓࠊࠊࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡰࡷࡵࡧࡪ࠱ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧࠬࡵࡷࡶ࠭ࡩ࡯ࡥࡧࠬ࠯ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧࠬࡴࡨࡥࡸࡵ࡮ࠬࠩࠣࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ࠰ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠰࠭ࠠ࡞࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ࠯ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠰࠭ࠠ࡞ࠩࠬࠑࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠏࠍࠍࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࠬࡩࡥ࡯ࡶࡨࡶࠬ࠲ࡳࡪࡶࡨ࠯ࠬࠦࠠࠡࠩ࠮ࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠮ࡳࡪࡶࡨ࠭࠱ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠱ࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍࠎ࡯ࡦࠡࡻࡨࡷࡂࡃ࠱࠻ࠢ࡬ࡱࡵࡵࡲࡵࠢࡖࡉࡗ࡜ࡉࡄࡇࡖࠤࡀࠦࡓࡆࡔ࡙ࡍࡈࡋࡓ࠯ࡏࡄࡍࡓ࠮࠱࠺࠷ࠬࠑࠏࠏࡥ࡭࡫ࡩࠤࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠼ࠐࠎࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠠ࠾ࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠭ࠪࠤ࠳ࠦ็ๅࠢอี๏ีࠠๆ฻ิๅฮࠦวๅลึฬฬฮ้ࠠษ็ั้๎ไࠡมࠪࠑࠏࠏࠉࡺࡧࡶࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥ࡙ࡆࡕࡑࡓ࠭࠭ࡣࡦࡰࡷࡩࡷ࠭ࠬࡴ࡫ࡷࡩ࠰࠭ࠠࠡࠢࠪ࠯࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋࠨࡴ࡫ࡷࡩ࠮࠲࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠬ࡮ࡧࡶࡷࡦ࡭ࡥࡆࡐࡊࡐࡎ࡙ࡈ࠭ࠩࠪ࠰้ࠬไศࠩ࠯๋ࠫ฿ๅࠨࠫࠐࠎࠎࠏࡩࡧࠢࡼࡩࡸࡃ࠽࠲࠼ࠐࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠿ࠣࠫ็ี๋ࠠๅ๋๊ࠥํๆศๅ๊ࠣํ฿ࠠๆ่ࠣห้ำฬษࠢ฼๊ิ้ࠧࠎࠌࠌࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࡊࡅࡕࡃࡌࡐࡘࠦࠫ࠾ࠢࠪࡠࡳ࠭ࠫࠨล๋ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัๆࠤ๊็ี้ๆฬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠๅษࠣ๎฾๋ไࠡ฻้ำ่࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡ฼ํีࠥํะ่ࠢสฺ่็อส๋ࠢห้๋ศา็ฯࠤ้อ๋ࠠ฻็้ࠬࠓࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࡠࡳ࠭ࠫࠨฮิฬ๋ࠥำฮࠢส่่อิ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣวึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠪࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะ࠮࠭ࠍࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠำๅࠤึ็ูࠡษ็ััฮࠠࠩ็ฮ่ฬࠦࡖࡑࡐࠣ࠰ࠥࡖࡲࡰࡺࡼࠤ࠱ࠦࡄࡏࡕࠬࠫࠒࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣ࠯ࡂࠦࠧ࡝ࡰࠪ࠯ࠬษ่ࠡฮิฬࠥ฽ไษ๊ࠢิฬࠦวๅ็๋ๆ฾ࠦไศฯๅหࠬࠓࠊࠊࠋࠌࡈࡎࡇࡌࡐࡉࡢࡘࡊ࡞ࡔࡗࡋࡈ࡛ࡊࡘࠨࠨใื่ࠥ็๊ࠡีะฬࠥอไึใะอ๋ࠥๆࠡษ็ษ๋ะั็ฬࠪ࠰ࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗ࠮ࠓࠊࠊࠤࠥࠦ柢")
def l11lllll111l_l1_(l1lll111l1111_l1_=False):
	l11111l11lll_l1_ = [l11l111l11l_l1_,favoritesfile,l1l11ll111ll_l1_]
	for filename in os.listdir(addoncachefolder):
		if l1lll111l1111_l1_ and (filename.startswith(l11l1l_l1_ (u"ࠩ࡬ࡴࡹࡼࠧ柣")) or filename.startswith(l11l1l_l1_ (u"ࠪࡱ࠸ࡻࠧ柤"))): continue
		if filename.startswith(l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡦࡡࠪ查")): continue
		l1l11l11lll_l1_ = os.path.join(addoncachefolder,filename)
		if l1l11l11lll_l1_ in l11111l11lll_l1_: continue
		try: os.remove(l1l11l11lll_l1_)
		except: pass
	time.sleep(1)
	return
def EXTRACT_KODI_PATH(l1lll1ll11111_l1_=addon_path):
	l1111llll11l_l1_ = {l11l1l_l1_ (u"ࠬࡺࡹࡱࡧࠪ柦"):l11l1l_l1_ (u"࠭ࠧ柧"),l11l1l_l1_ (u"ࠧ࡮ࡱࡧࡩࠬ柨"):l11l1l_l1_ (u"ࠨࠩ柩"),l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭柪"):l11l1l_l1_ (u"ࠪࠫ柫"),l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࠩ柬"):l11l1l_l1_ (u"ࠬ࠭柭"),l11l1l_l1_ (u"࠭ࡰࡢࡩࡨࠫ柮"):l11l1l_l1_ (u"ࠧࠨ柯"),l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭柰"):l11l1l_l1_ (u"ࠩࠪ柱"),l11l1l_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ柲"):l11l1l_l1_ (u"ࠫࠬ柳"),l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭柴"):l11l1l_l1_ (u"࠭ࠧ柵"),l11l1l_l1_ (u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ柶"):l11l1l_l1_ (u"ࠨࠩ柷")}
	if l11l1l_l1_ (u"ࠩࡂࠫ柸") in l1lll1ll11111_l1_: l1lll1ll11111_l1_ = l1lll1ll11111_l1_.split(l11l1l_l1_ (u"ࠪࡃࠬ柹"),1)[1]
	l111l1l_l1_,l1111llll111_l1_ = l1lll111l1_l1_(l1lll1ll11111_l1_)
	args = dict(list(l1111llll11l_l1_.items())+list(l1111llll111_l1_.items()))
	l1lll1l1lll1l_l1_ = args[l11l1l_l1_ (u"ࠫࡲࡵࡤࡦࠩ柺")]
	l1llll1l1l1ll_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ査")])
	l111l1ll11ll_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࠫ柼")])
	l1llllllll111_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠧࡱࡣࡪࡩࠬ柽")])
	l11l11l1ll1_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠨࡶࡼࡴࡪ࠭柾")])
	l111l1ll1l11_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ柿")])
	l1lll111ll1ll_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ栀")])
	l1ll1lll11111_l1_ = args[l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬ栁")]
	l1llll1l11l11_l1_ = l1llll_l1_(args[l11l1l_l1_ (u"ࠬ࡯࡮ࡧࡱࡧ࡭ࡨࡺࠧ栂")])
	if l1llll1l11l11_l1_: l1llll1l11l11_l1_ = eval(l1llll1l11l11_l1_)
	else: l1llll1l11l11_l1_ = {}
	#name = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ栃"))
	#l111_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ栄"))
	if not l1lll1l1lll1l_l1_: l11l11l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ栅") ; l1lll1l1lll1l_l1_ = l11l1l_l1_ (u"ࠩ࠵࠺࠵࠭栆")
	return l11l11l1ll1_l1_,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,l1lll1l1lll1l_l1_,l1lll111ll1ll_l1_,l1llllllll111_l1_,l111l1ll11ll_l1_,l1ll1lll11111_l1_,l1llll1l11l11_l1_
def l1llll1l1ll1l_l1_(proxy,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1ll1l1_l1_=True,l1llll1111l1l_l1_=True):
	l1lll11llllll_l1_,l1llll1l1llll_l1_ = proxy.split(l11l1l_l1_ (u"ࠪ࠾ࠬ标"))
	#l1llll1l_l1_(l11l1l_l1_ (u"ฺ๊ࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ栈"),l11l1l_l1_ (u"ูࠬรอำหࠤࠬ栉")+name,time=2000)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭栊"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࠫ栋")+name+l11l1l_l1_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ栌")+proxy+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ栍")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭栎"))
	url = url+l11l1l_l1_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ栏")+proxy
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1ll1l1_l1_,l1llll1111l1l_l1_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ栐"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࠪ树")+name+l11l1l_l1_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭栒")+proxy+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ栓")+url+l11l1l_l1_ (u"ࠩࠣࡡࠬ栔"))
		l111111l1lll_l1_(l11l1l_l1_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ栕"))
	#else: LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ栖"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ栗")+proxy+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ栘")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ栙"))
	return response
def l1lll111l11ll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ栚"),url,l11l1l_l1_ (u"ࠩࠪ栛"),l11l1l_l1_ (u"ࠪࠫ栜"),True,l11l1l_l1_ (u"ࠫࠬ栝"),l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭栞"),True,False)
	l1111l11lll1_l1_ = []
	if response.succeeded:
		html = response.content
		# needed for l111l1ll1lll_l1_
		l1lll1llll1ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩ栟"),html)
		#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ栠"),str(l1lll1llll1ll_l1_))
		if l1lll1llll1ll_l1_: html = l11l1l_l1_ (u"ࠨ࡞ࡱࠫ校").join(l1lll1llll1ll_l1_)
		proxies = html.replace(l11l1l_l1_ (u"ࠩ࡟ࡶࠬ栢"),l11l1l_l1_ (u"ࠪࠫ栣")).strip(l11l1l_l1_ (u"ࠫࡡࡴࠧ栤")).split(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ栥"))
		l1111l11lll1_l1_ = []
		for proxy in proxies:
			if proxy.count(l11l1l_l1_ (u"࠭࠮ࠨ栦"))==3: l1111l11lll1_l1_.append(proxy)
	return l1111l11lll1_l1_
def l111ll1ll1ll_l1_(*args):
	#l1llll111ll1l_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠵࠷࠱࠷࠸࠴࠱࠸࠰࠴࠶࠼࠵ࡡࡱ࡫࠲ࡴࡷࡵࡸࡺࡁࡷࡽࡵ࡫࠽ࡩࡶࡷࡴࠫࡹࡰࡦࡧࡧࡁ࠶࠶ࠦ࡭ࡣࡶࡸࡤࡩࡨࡦࡥ࡮ࡁ࠶࠶ࠦࡩࡶࡷࡴࡸࡃࡴࡳࡷࡨࠪࡵࡵࡳࡵ࠿ࡷࡶࡺ࡫ࠦࡧࡱࡵࡱࡦࡺ࠽ࡵࡺࡷࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ栧")
	l111lllll1l1_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ栨")
	l1lllll1ll1l1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭栩")
	#l1111l11llll_l1_ = l1lll111l11ll_l1_(l1llll111ll1l_l1_)
	l1111l11llll_l1_ = l1lll111l11ll_l1_(l1lllll1ll1l1_l1_)
	l1111l11lll1_l1_ = l1lll111l11ll_l1_(l111lllll1l1_l1_)
	l11l11111lll_l1_ = l1111l11llll_l1_+l1111l11lll1_l1_
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ株"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ栫")+str(len(l1111l11llll_l1_))+l11l1l_l1_ (u"ࠬ࠱ࠧ栬")+str(len(l1111l11lll1_l1_))+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栭"))
	proxy = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ栮"))
	response = l1111lll11l1_l1_()
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ栯"),l11l1l_l1_ (u"ࠩࠪ栰"))
	if proxy or l11l11111lll_l1_:
		id,timeout = 0,10
		l1lll11l1l111_l1_ = len(l11l11111lll_l1_)
		l1111lllll1l_l1_ = timeout
		if l1lll11l1l111_l1_>l1111lllll1l_l1_: counts = l1111lllll1l_l1_
		else: counts = l1lll11l1l111_l1_
		l111l1l1ll11_l1_ = random.sample(l11l11111lll_l1_,counts)
		if proxy: l111l1l1ll11_l1_ = [proxy]+l111l1l1ll11_l1_
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ栱"),str(l111l1l1ll11_l1_))
		threads = l1llll111l1l_l1_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l111l1l11lll_l1_:
			if id<counts:
				proxy = l111l1l1ll11_l1_[id]
				threads.start_new_thread(id,l1llll1l1ll1l_l1_,proxy,*args)
			time.sleep(1)
			id += 1
			LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ栲"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡖࡵࡽ࡮ࡴࡧ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ栳")+proxy+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栴"))
		l111l1l11lll_l1_ = threads.l111l1l11lll_l1_
		if l111l1l11lll_l1_:
			l1llllll1l1l1_l1_ = threads.l1llllll1l1l1_l1_
			l111111l111l_l1_ = l111l1l11lll_l1_[0]
			response = l1llllll1l1l1_l1_[l111111l111l_l1_]
			proxy = l111l1l1ll11_l1_[int(l111111l111l_l1_)]
			settings.setSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ栵"),proxy)
			if l111111l111l_l1_!=0: LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ栶"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ样")+proxy+l11l1l_l1_ (u"ࠪࠤࡢ࠭核"))
			else: LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ根"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡙ࠥࡡࡷࡧࡧࠤࡵࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ栺")+proxy+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ栻"))
		#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ格"),l11l1l_l1_ (u"ࠨࡲࡵࡳࡽ࡯ࡥࡴࡎࡌࡗ࡙࠸ࠠ࠻࠼ࠣࠫ栽")+str(l111l1l1ll11_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ栾"),l11l1l_l1_ (u"ࠪࡴࡷࡵࡸࡪࡧࡶࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ栿")+str(l11l11111lll_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ桀"),l11l1l_l1_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ桁")+str(threads.l111l1l11lll_l1_))
		#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭桂"),l11l1l_l1_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࡌࡊࡕࡗࠤ࠿ࡀࠠࠨ桃")+str(threads.l11l111l1111_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ桄"),l11l1l_l1_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࡵࡇࡍࡈ࡚ࠠ࠻࠼ࠣࠫ桅")+str(threads.l1llllll1l1l1_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ框"),l11l1l_l1_ (u"ࠫࡪࡲࡰࡢࡵࡨࡨࡹ࡯࡭ࡦࡆࡌࡇ࡙ࠦ࠺࠻ࠢࠪ桇")+str(threads.l111lllll111_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ案"),l11l1l_l1_ (u"࠭ࡳࡰࡴࡷࡩࡩࡒࡉࡔࡖࠣ࠾࠿ࠦࠧ桉")+str(l1ll1ll1l1l1_l1_))
		#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ桊"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࠬ桋")+l1lll11l1111l_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭桌")+str(l1ll1ll1l1l1_l1_))
	return response
def l1ll1llllll11_l1_(connection,l1ll1lll1ll1l_l1_):
	l111l11l11ll_l1_ = connection.create_connection
	def l1lll1l11l11l_l1_(address,*args,**kwargs):
		host,port = address
		l1l1lllllll1_l1_ = DNS_RESOLVER(host,l1ll1lll1ll1l_l1_)
		if l1l1lllllll1_l1_: host = l1l1lllllll1_l1_[0]
		else:
			if l1ll1lll1ll1l_l1_ in l11ll1llll1l_l1_: l11ll1llll1l_l1_.remove(l1ll1lll1ll1l_l1_)
			if l11ll1llll1l_l1_:
				l1111ll1llll_l1_ = l11ll1llll1l_l1_[0]
				#LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ桍"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡅࡐࡖࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡗࡪ࡮࡯ࠤࡹࡸࡹࠡࡶ࡫ࡩࠥࡵࡴࡩࡧࡵࠤࡉࡔࡓ࠻࡝ࠣࠫ桎")+l1111ll1llll_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡌࡴࡹࡴ࠻࡝ࠣࠫ桏")+str(host)+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ桐"))
				l1l1lllllll1_l1_ = DNS_RESOLVER(host,l1111ll1llll_l1_)
				if l1l1lllllll1_l1_: host = l1l1lllllll1_l1_[0]
		address = (host,port)
		return l111l11l11ll_l1_(address,*args,**kwargs)
	connection.create_connection = l1lll1l11l11l_l1_
	return l111l11l11ll_l1_
def l1ll11ll11_l1_(l1l1l1llll11_l1_,method,url,data,headers,source):
	html = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡴࡶࡵࠫ桑"),l11l1l_l1_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩ桒"),(method,url,data,headers,source))
	if html:
		l1llll1ll1l1l_l1_(True,url,data,headers,source,l11l1l_l1_ (u"ࠩࠪ桓"))
		return html
	html = l1llll1111_l1_(method,url,data,headers,source)
	if html: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫ桔"),(method,url,data,headers,source),html,l1l1l1llll11_l1_)
	return html
def l1llll1111_l1_(method,url,data=l11l1l_l1_ (u"ࠫࠬ桕"),headers=l11l1l_l1_ (u"ࠬ࠭桖"),source=l11l1l_l1_ (u"࠭ࠧ桗")):
	l1llll1ll1l1l_l1_(False,url,data,headers,source,l11l1l_l1_ (u"ࠧࠨ桘"))
	if kodi_version>18.99: import urllib.request as l1lll11l1l1l1_l1_
	else: import urllib2 as l1lll11l1l1l1_l1_
	if not headers: headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ桙"):l11l1l_l1_ (u"ࠩࠪ桚")}
	if not data: data = {}
	if method==l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ桛"):
		url = url+l11l1l_l1_ (u"ࠫࡄ࠭桜")+l1ll11ll1_l1_(data)
		data = None
	try:
		req = l1lll11l1l1l1_l1_.Request(url,headers=headers,data=data)
		http_response = l1lll11l1l1l1_l1_.urlopen(req)
		html = http_response.read()
	except: html = l11l1l_l1_ (u"ࠬ࠭桝")
	#try:
	#	req = l1lll11l1l1l1_l1_.Request(url)
	#	for key in list(headers.keys()):
	#		req.add_header(key,headers[key])
	#	http_response = l1lll11l1l1l1_l1_.urlopen(req)
	#	html = http_response.read()
	#except: html = l11l1l_l1_ (u"࠭ࠧ桞")
	return html
def l1ll1lll1l111_l1_(url):
	l111l1lllll1_l1_,l111ll11l111_l1_ = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ桟"))[2],80
	if l11l1l_l1_ (u"ࠨ࠼ࠪ桠") in l111l1lllll1_l1_: l111l1lllll1_l1_,l111ll11l111_l1_ = l111l1lllll1_l1_.split(l11l1l_l1_ (u"ࠩ࠽ࠫ桡"))
	l111l111l1l1_l1_ = l11l1l_l1_ (u"ࠪ࠳ࠬ桢")+l11l1l_l1_ (u"ࠫ࠴࠭档").join(url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ桤"))[3:])
	request = l11l1l_l1_ (u"࠭ࡇࡆࡖࠣࠫ桥")+l111l111l1l1_l1_+l11l1l_l1_ (u"ࠧࠡࡊࡗࡘࡕ࠵࠱࠯࠳࡟ࡶࡡࡴࠧ桦")
	#request += l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸ࠿ࠦ࡜ࡳ࡞ࡱࠫ桧")
	request += l11l1l_l1_ (u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ桨")+l111l1lllll1_l1_+l11l1l_l1_ (u"ࠪࡠࡷࡢ࡮ࠨ桩")
	request += l11l1l_l1_ (u"ࠫࡡࡸ࡜࡯ࠩ桪")
	import socket
	try:
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect((l111l1lllll1_l1_,l111ll11l111_l1_))
		client.send(request.encode())
		http_response = client.recv(4096*1024)
		html = repr(http_response)
	except: html = l11l1l_l1_ (u"ࠬ࠭桫")
	return html
def SERVER(l1llll1_l1_,type):
	# url:	http://l1l1l1l111l_l1_.l1111l1l1lll_l1_.com
	# host:	l1l1l1l111l_l1_.l1111l1l1lll_l1_.com
	# name:	l1111l1l1lll_l1_
	#server = l11l1l_l1_ (u"࠭࠯ࠨ桬").join(l1llll1_l1_.split(l11l1l_l1_ (u"ࠧ࠰ࠩ桭"))[:3])
	if l11l1l_l1_ (u"ࠨ࠰ࠪ桮") not in l1llll1_l1_: return l1llll1_l1_
	l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ桯")
	l11l1lll111_l1_,l11l1l111l1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪ࠲ࠬ桰"),1)
	l1lll1l1l11ll_l1_,l1lll1l1l11l1_l1_ = l11l1l111l1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭桱"),1)
	server = l11l1lll111_l1_+l11l1l_l1_ (u"ࠬ࠴ࠧ桲")+l1lll1l1l11ll_l1_
	if type in [l11l1l_l1_ (u"࠭ࡨࡰࡵࡷࠫ桳"),l11l1l_l1_ (u"ࠧ࡯ࡣࡰࡩࠬ桴")] and l11l1l_l1_ (u"ࠨ࠱ࠪ桵") in server: server = server.rsplit(l11l1l_l1_ (u"ࠩ࠲ࠫ桶"),1)[1]
	if type==l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ桷") and l11l1l_l1_ (u"ࠫ࠳࠭桸") in server:
		l1lll11llll1l_l1_ = server.split(l11l1l_l1_ (u"ࠬ࠴ࠧ桹"))
		length = len(l1lll11llll1l_l1_)
		if length<=2 or l11l1l_l1_ (u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫ桺") in server: l1lll11llll1l_l1_ = l1lll11llll1l_l1_[0]
		elif length>=3: l1lll11llll1l_l1_ = l1lll11llll1l_l1_[1]
		if len(l1lll11llll1l_l1_)>1: server = l1lll11llll1l_l1_
	return server
	l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥ࠭࠯ࠨ࠭ࡸࡶࡱ࠸ࠫࠨ࠱ࠪࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡯ࡧࡷ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤࡱࡰ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡰࡴࡪ࠳ࠬ࠲ࠧ࠰ࠩࠬࠑࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡭࡫ࡹࡩ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡶࡹ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡸࡵ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡴࡰ࠱ࠪ࠰ࠬ࠵ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡳࡥ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡨࡵ࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠍࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡸࡶࡱ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡶࡺ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡦࡥࡲ࠵ࠧ࠭ࠩ࠲ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪࠏࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡲࡩࡷࡧ࠲ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠴ࡣ࡭ࡷࡥ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡭࡫ࡩࡩ࠴࠭ࠬࠨ࠱ࠪ࠭ࠒࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯࡯ࡻ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡪࡰ࠲ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡷࡸࡹ࠱ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵࡭࠯ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠳ࡪࡳࡢࡦࡦ࠱ࠫ࠱࠭࠯ࠨࠫࠐࠎࠎࠨࠢࠣ桻")
def l1111lll11l_l1_(l11l11l111ll_l1_):
	l11l111ll1l1_l1_ = repr(l11l11l111ll_l1_.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭桼"))).replace(l11l1l_l1_ (u"ࠤࠪࠦ桽"),l11l1l_l1_ (u"ࠪࠫ桾"))
	return l11l111ll1l1_l1_
def l1l1l1111l1_l1_(string):
	#if l11l1l_l1_ (u"ࠫࡡࡻࠧ桿") in string:
	#	string = string.decode(l11l1l_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭梀"))
	#	l1lllllll1lll_l1_=re.findall(l11l1l_l1_ (u"ࡸࠧ࡝ࡷ࡞࠴࠲࠿ࡁ࠮ࡈࡠࠫ梁"),string)
	#	for unicode in l1lllllll1lll_l1_
	#		char = l1ll1ll1l1ll1_l1_(
	#		replace(    , char)
	#if isinstance(string,bytes): string = string.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ梂"))
	l1ll1lllllll1_l1_ = l11l1l_l1_ (u"ࠨࠩ梃")
	if kodi_version<19: string = string.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ梄"))
	import unicodedata
	for l1l1l111111_l1_ in string:
		if   l1l1l111111_l1_==l11l1l_l1_ (u"ࡸࠫว࠭梅"): l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠫࡡࡢࡵ࠱࠸࠵࠶ࠬ梆")
		elif l1l1l111111_l1_==l11l1l_l1_ (u"ࡺ࠭รࠨ梇"): l111111ll1ll_l1_ = l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠷࠹ࠧ梈")
		elif l1l1l111111_l1_==l11l1l_l1_ (u"ࡵࠨฦࠪ梉"): l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠨ࡞࡟ࡹ࠵࠼࠲࠵ࠩ梊")
		elif l1l1l111111_l1_==l11l1l_l1_ (u"ࡷࠪษࠬ梋"): l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠪࡠࡡࡻ࠰࠷࠴࠸ࠫ梌")
		elif l1l1l111111_l1_==l11l1l_l1_ (u"ࡹࠬฬࠧ梍"): l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹࠶࠻࠭梎")
		else:
			l1ll1ll1l111l_l1_ = unicodedata.decomposition(l1l1l111111_l1_)
			if l11l1l_l1_ (u"࠭ࠠࠨ梏") in l1ll1ll1l111l_l1_: l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠧ࡝࡞ࡸࠫ梐")+l1ll1ll1l111l_l1_.split(l11l1l_l1_ (u"ࠨࠢࠪ梑"),1)[1]
			else:
				l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠩ࠳࠴࠵࠶ࠧ梒")+hex(ord(l1l1l111111_l1_)).replace(l11l1l_l1_ (u"ࠪ࠴ࡽ࠭梓"),l11l1l_l1_ (u"ࠫࠬ梔"))
				l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠬࡢ࡜ࡶࠩ梕")+l111111ll1ll_l1_[-4:]
			#if ord(l1l1l111111_l1_)<256: l111111ll1ll_l1_ = l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠴ࠬ梖")+l1lll1l1l1ll1_l1_
			#elif ord(l1l1l111111_l1_)<4096: l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠧ࡝࡞ࡸ࠴ࠬ梗")+l1lll1l1l1ll1_l1_
			#elif l11l1l_l1_ (u"ࠨࠢࠪ梘") in l1ll1ll1l111l_l1_: l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠩ࡟ࡠࡺ࠭梙")+l1ll1ll1l111l_l1_.split(l11l1l_l1_ (u"ࠪࠤࠬ梚"),1)[1]
			#else: l111111ll1ll_l1_ = l11l1l_l1_ (u"ࠫࡡࡢࡵࠨ梛")+l1lll1l1l1ll1_l1_
		l1ll1lllllll1_l1_ += l111111ll1ll_l1_
	l1ll1lllllll1_l1_ = l1ll1lllllll1_l1_.replace(l11l1l_l1_ (u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭梜"),l11l1l_l1_ (u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧ條"))
	if kodi_version<19: l1ll1lllllll1_l1_ = l1ll1lllllll1_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ梞")).encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭梟"))
	else: l1ll1lllllll1_l1_ = l1ll1lllllll1_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ梠")).decode(l11l1l_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ梡"))
	return l1ll1lllllll1_l1_
def OPEN_KEYBOARD(header=l11l1l_l1_ (u"้ࠫ๎อสࠢส่๊็วห์ะࠫ梢"),default=l11l1l_l1_ (u"ࠬ࠭梣"),l1111llll1ll_l1_=False,source=l11l1l_l1_ (u"࠭ࠧ梤")):
	text = l111ll11l1ll_l1_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ梥"),l11l1l_l1_ (u"ࠨࠢࠪ梦")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ梧"),l11l1l_l1_ (u"ࠪࠤࠬ梨")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ梩"),l11l1l_l1_ (u"ࠬࠦࠧ梪"))
	if not text and not l1111llll1ll_l1_:
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭梫"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠺ࠡࠢࠣࠦࠬ梬")+text+l11l1l_l1_ (u"ࠨࠤࠪ梭"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ梮"),l11l1l_l1_ (u"ࠪࠫ梯"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ械"),l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨ梱"))
		return l11l1l_l1_ (u"࠭ࠧ梲")
	if text not in [l11l1l_l1_ (u"ࠧࠨ梳"),l11l1l_l1_ (u"ࠨࠢࠪ梴")]:
		text = text.strip(l11l1l_l1_ (u"ࠩࠣࠫ梵"))
		text = l1l1l1111l1_l1_(text)
	if source!=l11l1l_l1_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗࠬ梶") and l11l111_l1_(l11l1l_l1_ (u"ࠫࡐࡋ࡙ࡃࡑࡄࡖࡉ࠭梷"),l11l1l_l1_ (u"ࠬ࠭梸"),[text],False):
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭梹"),l11l1l_l1_ (u"ࠧ࠯ࠢࠣࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫ梺")+text+l11l1l_l1_ (u"ࠨࠤࠪ梻"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ梼"),l11l1l_l1_ (u"ࠪࠫ梽"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ梾"),l11l1l_l1_ (u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧ梿"))
		return l11l1l_l1_ (u"࠭ࠧ检")
	LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ棁"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡡ࡭࡮ࡲࡻࡪࡪ࠺ࠡࠢࠣࠦࠬ棂")+text+l11l1l_l1_ (u"ࠩࠥࠫ棃"))
	return text
def l1111l111lll_l1_():
	type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_ = EXTRACT_KODI_PATH(addon_path)
	tmp = re.findall(l11l1l_l1_ (u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦ࡜࡜࠱ࡆࡓࡑࡕࡒ࡝࡟ࠪ棄"),name,re.DOTALL)
	if tmp: name = name.split(tmp[0],1)[1]
	datetime = time.strftime(l11l1l_l1_ (u"ࠫࡤࠫ࡭࠯ࠧࡧࡣࠪࡎ࠺ࠦࡏࡢࠫ棅"),time.localtime(now))
	name = name+datetime
	l1l1llll1ll_l1_ = type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_
	if os.path.exists(l11l111l11l_l1_):
		l11lll1l1ll1_l1_ = open(l11l111l11l_l1_,l11l1l_l1_ (u"ࠬࡸࡢࠨ棆")).read()
		if kodi_version>18.99: l11lll1l1ll1_l1_ = l11lll1l1ll1_l1_.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ棇"))
		l11lll1l1ll1_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ棈"),l11lll1l1ll1_l1_)
	else: l11lll1l1ll1_l1_ = {}
	l11ll1ll1l1l_l1_ = {}
	for l1lll11l1lll1_l1_ in list(l11lll1l1ll1_l1_.keys()):
		if l1lll11l1lll1_l1_!=type: l11ll1ll1l1l_l1_[l1lll11l1lll1_l1_] = l11lll1l1ll1_l1_[l1lll11l1lll1_l1_]
		else:
			if name and name!=l11l1l_l1_ (u"ࠨ࠰࠱ࠫ棉"):
				l1111111ll1l_l1_ = l11lll1l1ll1_l1_[l1lll11l1lll1_l1_]
				if l1l1llll1ll_l1_ in l1111111ll1l_l1_:
					index = l1111111ll1l_l1_.index(l1l1llll1ll_l1_)
					del l1111111ll1l_l1_[index]
				l1lll1lll11_l1_ = [l1l1llll1ll_l1_]+l1111111ll1l_l1_
				l1lll1lll11_l1_ = l1lll1lll11_l1_[:50]
				l11ll1ll1l1l_l1_[l1lll11l1lll1_l1_] = l1lll1lll11_l1_
			else: l11ll1ll1l1l_l1_[l1lll11l1lll1_l1_] = l11lll1l1ll1_l1_[l1lll11l1lll1_l1_]
	if type not in list(l11ll1ll1l1l_l1_.keys()): l11ll1ll1l1l_l1_[type] = [l1l1llll1ll_l1_]
	l11ll1ll1l1l_l1_ = str(l11ll1ll1l1l_l1_)
	if kodi_version>18.99: l11ll1ll1l1l_l1_ = l11ll1ll1l1l_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ棊"))
	open(l11l111l11l_l1_,l11l1l_l1_ (u"ࠪࡻࡧ࠭棋")).write(l11ll1ll1l1l_l1_)
	return
def l11l1ll1ll_l1_(l111l1l_l1_,headers={}):
	#if headers[l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ棌")]==l11l1l_l1_ (u"ࠬ࠭棍"): headers[l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ棎")] = l11l1l_l1_ (u"ࠧࠡࠩ棏")
	#l1lllllllll1l_l1_ = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ棐") : l11l1l_l1_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠷࠶࠰࠳࠲࠸࠽࠷࠱࠰࠴࠸࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭棑") }
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡪ࠸࠵࠰ࡰࡽࡨࡪ࡮࠯࡯ࡨ࠳ࡻ࡯ࡤࡦࡱ࠱ࡱ࠸ࡻ࠸ࠨ棒")
	#open(l11l1l_l1_ (u"ࠫࡘࡀ࡜࡝ࡶࡨࡷࡹ࠸࠮࡮࠵ࡸ࠼ࠬ棓"), l11l1l_l1_ (u"ࠬࡸࠧ棔")).read()
	url,params = l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ棕")
	if l11l1l_l1_ (u"ࠧࡽࠩ棖") in l111l1l_l1_:
		url,params = l111l1l_l1_.split(l11l1l_l1_ (u"ࠨࡾࠪ棗"),1)
		if l11l1l_l1_ (u"ࠩࡀࠫ棘") not in params: url,params = l111l1l_l1_,l11l1l_l1_ (u"ࠪࠫ棙")
	response = OPENURL_REQUESTS_CACHED(l1111ll1l11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ棚"),url,l11l1l_l1_ (u"ࠬ࠭棛"),headers,l11l1l_l1_ (u"࠭ࠧ棜"),l11l1l_l1_ (u"ࠧࠨ棝"),l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬ棞"),False,False)
	html = response.content
	if l11l1l_l1_ (u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭棟") not in html: return [l11l1l_l1_ (u"ࠪ࠱࠶࠭棠")],[l111l1l_l1_]
	#	if l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ棡") in list(headers.keys()): del headers[l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ棢")]
	#	else: headers[l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ棣")] = l11l1l_l1_ (u"ࠧࠨ棤")
	#	response = OPENURL_REQUESTS_CACHED(l1111ll1l11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ棥"),url,l11l1l_l1_ (u"ࠩࠪ棦"),headers,l11l1l_l1_ (u"ࠪࠫ棧"),l11l1l_l1_ (u"ࠫࠬ棨"),l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠸࡮ࡥࠩ棩"),False,False)
	#	html = response.content
	if l11l1l_l1_ (u"࠭ࡔ࡚ࡒࡈࡁࡆ࡛ࡄࡊࡑࠪ棪") in html: return [l11l1l_l1_ (u"ࠧ࠮࠳ࠪ棫")],[l111l1l_l1_]
	if l11l1l_l1_ (u"ࠨࡖ࡜ࡔࡊࡃࡖࡊࡆࡈࡓࠬ棬") in html: return [l11l1l_l1_ (u"ࠩ࠰࠵ࠬ棭")],[l111l1l_l1_]
	#if l11l1l_l1_ (u"ࠪࡘ࡞ࡖࡅ࠾ࡕࡘࡆ࡙ࡏࡔࡍࡇࡖࠫ森") in html: return [l11l1l_l1_ (u"ࠫ࠲࠷ࠧ棯")],[l111l1l_l1_]
	l1ll1ll1_l1_,l1lll1_l1_,l1111l1ll1ll_l1_,l1llll111ll11_l1_ = [],[],[],[]
	lines = re.findall(l11l1l_l1_ (u"ࠬࡢࠣࡆ࡚ࡗ࠱࡝࠳ࡓࡕࡔࡈࡅࡒ࠳ࡉࡏࡈ࠽ࠬ࠳࠰࠿ࠪ࡝࡟ࡲࡡࡸ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ棰"),html+l11l1l_l1_ (u"࠭࡜࡯࡞ࡵࠫ棱"),re.DOTALL)
	if not lines: return [l11l1l_l1_ (u"ࠧ࠮࠳ࠪ棲")],[l111l1l_l1_]
	for line,l1llll1_l1_ in lines:
		l1ll1llll1lll_l1_,l1lllllll111_l1_,l111ll11_l1_ = {},-1,-1
		title = l11l1l_l1_ (u"ࠨࠩ棳")
		#hostname = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ棴"))
		#title = title+l11l1l_l1_ (u"ࠪࠤࠥ࠭棵")+hostname+l11l1l_l1_ (u"ࠫࠥࠦࠧ棶")
		#line = line.lower()
		items = line.split(l11l1l_l1_ (u"ࠬ࠲ࠧ棷"))
		for item in items:
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ棸"),l11l1l_l1_ (u"ࠧࠨ棹"),item,l11l1l_l1_ (u"ࠨࠩ棺"))
			#if l11l1l_l1_ (u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ棻") in item: l1ll1llll1lll_l1_[key] = value
			if l11l1l_l1_ (u"ࠪࡁࠬ棼") in item:
				key,value = item.split(l11l1l_l1_ (u"ࠫࡂ࠭棽"),1)
				l1ll1llll1lll_l1_[key.lower()] = value
		if l11l1l_l1_ (u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ棾") in line.lower():
			l1lllllll111_l1_ = int(l1ll1llll1lll_l1_[l11l1l_l1_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ棿")])//1024
			#title += l11l1l_l1_ (u"ࠧࡂࡸࡪࡆ࡜ࡀࠠࠨ椀")+str(l1lllllll111_l1_)+l11l1l_l1_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ椁")
			title += str(l1lllllll111_l1_)+l11l1l_l1_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ椂")
		elif l11l1l_l1_ (u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭椃") in line.lower():
			l1lllllll111_l1_ = int(l1ll1llll1lll_l1_[l11l1l_l1_ (u"ࠫࡧࡧ࡮ࡥࡹ࡬ࡨࡹ࡮ࠧ椄")])//1024
			#title += l11l1l_l1_ (u"ࠬࡈࡗ࠻ࠢࠪ椅")+str(l1lllllll111_l1_)+l11l1l_l1_ (u"࠭࡫ࡣࡲࡶࠤࠥ࠭椆")
			title += str(l1lllllll111_l1_)+l11l1l_l1_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ椇")
		if l11l1l_l1_ (u"ࠨࡴࡨࡷࡴࡲࡵࡵ࡫ࡲࡲࠬ椈") in line.lower():
			l111ll11_l1_ = int(l1ll1llll1lll_l1_[l11l1l_l1_ (u"ࠩࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭椉")].split(l11l1l_l1_ (u"ࠪࡼࠬ椊"))[1])
			#title += l11l1l_l1_ (u"ࠫࡗ࡫ࡳ࠻ࠢࠪ椋")+str(l111ll11_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠨ椌")
			title += str(l111ll11_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠩ植")
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠢࠪ椎"))
		if not title: title = l11l1l_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ椏")
		if not l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ椐")):
			if l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠪ࠳࠴࠭椑")): l1llll1_l1_ = url.split(l11l1l_l1_ (u"ࠫ࠿࠭椒"),1)[0]+l11l1l_l1_ (u"ࠬࡀࠧ椓")+l1llll1_l1_
			elif l1llll1_l1_.startswith(l11l1l_l1_ (u"࠭࠯ࠨ椔")): l1llll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ椕"))+l1llll1_l1_
			else: l1llll1_l1_ = url.rsplit(l11l1l_l1_ (u"ࠨ࠱ࠪ椖"),1)[0]+l11l1l_l1_ (u"ࠩ࠲ࠫ椗")+l1llll1_l1_
		if params!=l11l1l_l1_ (u"ࠪࠫ椘"): l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࢁ࠭椙")+params
		if l11l1l_l1_ (u"ࠬࡶࡲࡰࡩࡵࡩࡸࡹࡩࡷࡧ࠰ࡹࡷ࡯ࠧ椚") in list(l1ll1llll1lll_l1_.keys()):
			l1llll11l1_l1_ = l1ll1llll1lll_l1_[l11l1l_l1_ (u"࠭ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠱ࡺࡸࡩࠨ椛")]
			l1llll11l1_l1_ = l1llll11l1_l1_.replace(l11l1l_l1_ (u"ࠧࠣࠩ検"),l11l1l_l1_ (u"ࠨࠩ椝")).replace(l11l1l_l1_ (u"ࠤࠪࠦ椞"),l11l1l_l1_ (u"ࠪࠫ椟")).split(l11l1l_l1_ (u"ࠫࠨ࠭椠"),1)[0]
			l111ll1111_l1_ = l11l1l11l1_l1_(l1llll11l1_l1_)
			if l111ll1111_l1_: l1lll11l1_l1_ = title+l11l1l_l1_ (u"ࠬࠦࠠࠨ椡")+l111ll1111_l1_
			else: l1lll11l1_l1_ = title
			l1lll11l1_l1_ = l1lll11l1_l1_+l11l1l_l1_ (u"࠭ࠠࠡࡒࡵࡳ࡬ࡸࡥࡴࡵ࡬ࡺࡪ࠭椢")
			l1lll11l1_l1_ = l1lll11l1_l1_+l11l1l_l1_ (u"ࠧࠡࠢࠪ椣")+SERVER(l1llll11l1_l1_,l11l1l_l1_ (u"ࠨࡰࡤࡱࡪ࠭椤"))
			l1ll1ll1_l1_.append(l1lll11l1_l1_)
			l1lll1_l1_.append(l1llll11l1_l1_)
			l1111l1ll1ll_l1_.append(l111ll11_l1_)
			l1llll111ll11_l1_.append(l1lllllll111_l1_)
		l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠩࠦࠫ椥"),1)[0]
		l111ll1111_l1_ = l11l1l11l1_l1_(l1llll1_l1_)
		if l111ll1111_l1_: title = title+l11l1l_l1_ (u"ࠪࠤࠥ࠭椦")+l111ll1111_l1_
		title = title+l11l1l_l1_ (u"ࠫࠥࠦࠧ椧")+SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࠪ椨"))
		l1ll1ll1_l1_.append(title)
		l1lll1_l1_.append(l1llll1_l1_)
		l1111l1ll1ll_l1_.append(l111ll11_l1_)
		l1llll111ll11_l1_.append(l1lllllll111_l1_)
	zz = list(zip(l1ll1ll1_l1_,l1lll1_l1_,l1111l1ll1ll_l1_,l1llll111ll11_l1_))
	#zz = set(zz)
	zz = sorted(zz, reverse=True, key=lambda key: key[3])
	l1ll1ll1_l1_,l1lll1_l1_,l1111l1ll1ll_l1_,l1llll111ll11_l1_ = list(zip(*zz))
	l1ll1ll1_l1_,l1lll1_l1_ = list(l1ll1ll1_l1_),list(l1lll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭ࠧ椩"), l1ll1ll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧࠨ椪"), l1lll1_l1_)
	return l1ll1ll1_l1_,l1lll1_l1_
mac = l11l1l_l1_ (u"ࠨࠩ椫")
def l11111ll1l11_l1_():
	global mac
	import getmac
	mac = getmac.get_mac_address()
	return
def l1l11ll1lll_l1_(length=32):
	l11ll1llll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭椬"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭椭"),l11l1l_l1_ (u"ࠫࡈࡒࡉࡆࡐࡗࡍࡉ࠭椮"))
	if l11ll1llll_l1_: return l11ll1llll_l1_
	global mac
	length = length//2
	#import uuid
	#node = str(uuid.getnode())
	import threading
	l1lll1ll11lll_l1_ = threading.Thread(target=l11111ll1l11_l1_,args=())
	l1lll1ll11lll_l1_.start()
	for l11l1l1ll1_l1_ in range(10):
		time.sleep(0.5)
		if mac: break
	if not mac: node = l11l1l_l1_ (u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨ椯")
	else:
		mac = mac.replace(l11l1l_l1_ (u"࠭࠺ࠨ椰"),l11l1l_l1_ (u"ࠧࠨ椱"))
		node = str(int(mac,16))
	node = re.findall(l11l1l_l1_ (u"ࠨ࡝࠳࠱࠾ࡣࠫࠨ椲"),node,re.DOTALL)
	node = length*l11l1l_l1_ (u"ࠩ࠳ࠫ椳")+node[0]
	node = node[-length:]
	mm,ss = l11l1l_l1_ (u"ࠪࠫ椴"),l11l1l_l1_ (u"ࠫࠬ椵")
	l111llll1lll_l1_ = str(int(l11l1l_l1_ (u"ࠬ࠿ࠧ椶")*(length+1))-int(node))[-length:]
	for l11l1l1ll1_l1_ in list(range(0,length,4)):
		l1ll1ll1llll1_l1_ = l111llll1lll_l1_[l11l1l1ll1_l1_:l11l1l1ll1_l1_+4]
		mm += l1ll1ll1llll1_l1_+l11l1l_l1_ (u"࠭࠭ࠨ椷")
		ss += str(sum(map(int,node[l11l1l1ll1_l1_:l11l1l1ll1_l1_+4]))%10)
	l11ll1llll_l1_ = mm+ss
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ椸"),l11l1l_l1_ (u"ࠨࡅࡏࡍࡊࡔࡔࡊࡆࠪ椹"),l11ll1llll_l1_,PERMANENT_CACHE)
	return l11ll1llll_l1_
def DNS_RESOLVER(host,l1ll1lll1ll1l_l1_=l11ll1llll1l_l1_[0]):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ椺"),l11l1l_l1_ (u"ࠪࠫ椻"),str(l1ll1lll1ll1l_l1_),str(host))
	if host.replace(l11l1l_l1_ (u"ࠫ࠳࠭椼"),l11l1l_l1_ (u"ࠬ࠭椽")).isdigit(): return [host]
	import struct,socket
	try:
		l111l1l11111_l1_ = struct.pack(l11l1l_l1_ (u"ࠨ࠾ࡉࠤ椾"), 12049)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠢ࠿ࡊࠥ椿"), 256)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠣࡀࡋࠦ楀"), 1)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠤࡁࡌࠧ楁"), 0)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠥࡂࡍࠨ楂"), 0)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠦࡃࡎࠢ楃"), 0)
		if kodi_version>18.99: l1llllll111ll_l1_ = host.split(l11l1l_l1_ (u"ࠬ࠴ࠧ楄"))
		else: l1llllll111ll_l1_ = host.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ楅")).split(l11l1l_l1_ (u"ࠧ࠯ࠩ楆"))
		for part in l1llllll111ll_l1_:
			parts = part.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭楇"))
			l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠤࡅࠦ楈"), len(part))
			for l11111llllll_l1_ in part:
				l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠥࡧࠧ楉"), l11111llllll_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ楊")))
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠧࡈࠢ楋"), 0)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠨ࠾ࡉࠤ楌"), 1)
		l111l1l11111_l1_ += struct.pack(l11l1l_l1_ (u"ࠢ࠿ࡊࠥ楍"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(l111l1l11111_l1_), (l1ll1lll1ll1l_l1_, 53))
		sock.settimeout(6)
		data, addr = sock.recvfrom(1024)
		sock.close()
		l111l1ll111l_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠣࡀࡋࡌࡍࡎࡈࡉࠤ楎"), data, 0)
		l1111ll1l1l1_l1_ = l111l1ll111l_l1_[3]
		offset = len(host)+18
		l11l1ll11l1_l1_ = []
		for _ in range(l1111ll1l1l1_l1_):
			l1111l1ll11l_l1_ = offset
			l1llll1ll1ll1_l1_ = 1
			l11111l1111l_l1_ = False
			while True:
				l11111llllll_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠤࡁࡆࠧ楏"), data, l1111l1ll11l_l1_)[0]
				if l11111llllll_l1_ == 0:
					l1111l1ll11l_l1_ += 1
					break
				# l1lll1l11llll_l1_ the field l1lll11lll1l1_l1_ the first l111l1lll11l_l1_ bits l1lll1lll11l1_l1_ to 1, l1lll1ll1111_l1_ a pointer
				if l11111llllll_l1_ >= 192:
					l11111lll11l_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠥࡂࡇࠨ楐"), data, l1111l1ll11l_l1_ + 1)[0]
					# l1ll1llll1111_l1_ the pointer
					l1111l1ll11l_l1_ = ((l11111llllll_l1_ << 8) + l11111lll11l_l1_ - 0xc000) - 1
					l11111l1111l_l1_ = True
				l1111l1ll11l_l1_ += 1
				if l11111l1111l_l1_ == False: l1llll1ll1ll1_l1_ += 1
			if l11111l1111l_l1_ == True: l1llll1ll1ll1_l1_ += 1
			offset = offset + l1llll1ll1ll1_l1_
			l11l111111ll_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠦࡃࡎࡈࡊࡊࠥ楑"), data, offset)
			offset = offset + 10
			l111l1lll1l1_l1_ = l11l111111ll_l1_[0]
			l11111l111ll_l1_ = l11l111111ll_l1_[3]
			if l111l1lll1l1_l1_ == 1: # l111l11l1l1l_l1_ type
				l1111l111111_l1_ = struct.unpack_from(l11l1l_l1_ (u"ࠧࡄࠢ楒")+l11l1l_l1_ (u"ࠨࡂࠣ楓")*l11111l111ll_l1_, data, offset)
				l1l1lllllll1_l1_ = l11l1l_l1_ (u"ࠧࠨ楔")
				for l11111llllll_l1_ in l1111l111111_l1_: l1l1lllllll1_l1_ += str(l11111llllll_l1_) + l11l1l_l1_ (u"ࠨ࠰ࠪ楕")
				l1l1lllllll1_l1_ = l1l1lllllll1_l1_[0:-1]
				l11l1ll11l1_l1_.append(l1l1lllllll1_l1_)
			if l111l1lll1l1_l1_ in [1,2,5,6,15,28]: offset = offset + l11111l111ll_l1_
	except: l11l1ll11l1_l1_ = []
	if not l11l1ll11l1_l1_: LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ楖"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡉࡱࡶࡸ࠿࡛ࠦࠡࠩ楗")+host+l11l1l_l1_ (u"ࠫࠥࡣࠧ楘"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭楙"),l11l1l_l1_ (u"࠭ࠧ楚"),str(host),str(l11l1ll11l1_l1_))
	return l11l1ll11l1_l1_
def l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_,l1ll_l1_=True):
	if l11l11l_l1_:
		l111l1l1llll_l1_ = [l11l1l_l1_ (u"ࠧไสสีࠬ楛"),l11l1l_l1_ (u"ࠨสส่฿࠭楜"),l11l1l_l1_ (u"ࠩࡤࡨࡺࡲࡴࠨ楝"),l11l1l_l1_ (u"ࠪࡼࡽ࠭楞"),l11l1l_l1_ (u"ࠫࡸ࡫ࡸࠨ楟")]
		if l1ll1_l1_!=l11l1l_l1_ (u"ࠬࡈࡏࡌࡔࡄࠫ楠"):
			l111l1l1llll_l1_ += [l11l1l_l1_ (u"࠭ࡲ࠻ࠩ楡"),l11l1l_l1_ (u"ࠧࡳ࠯ࠪ楢"),l11l1l_l1_ (u"ࠨ࠯ࡰࡥࠬ楣")]
			l111l1l1llll_l1_ += [l11l1l_l1_ (u"ࠩ࠽ࡶࠬ楤"),l11l1l_l1_ (u"ࠪ࠱ࡷ࠭楥"),l11l1l_l1_ (u"ࠫࡲࡧ࠭ࠨ楦")]
		for l1ll1l111l_l1_ in l11l11l_l1_:
			if l11l1l_l1_ (u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ楧") in l1ll1l111l_l1_: continue
			if l11l1l_l1_ (u"࠭อๅไฬࠫ楨") in l1ll1l111l_l1_: continue
			l1ll1l111l_l1_ = l1ll1l111l_l1_.lower()
			if kodi_version<19: l1ll1l111l_l1_ = l1ll1l111l_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ楩")).encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭楪"))
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ楫"),l11l1l_l1_ (u"ࠪࠫ楬"),l11l1l_l1_ (u"ࠫࠬ業"),str(l1ll1l111l_l1_))
			#l1111ll11l11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡤࠨ࠲࡝࠹࠱࠾ࡣࡼ࠳࡝࠳࠱࠾ࡣࠩࠥࠩ楮"),l1ll1l111l_l1_,re.DOTALL)
			#l1111ll11ll1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡞࡝࠭ࠫ࠵ࡠ࠼࠭࠺࡟ࡿ࠶ࡠ࠶࠭࠺࡟ࠬࠨࠬ楯"),l1ll1l111l_l1_,re.DOTALL)
			#l1111ll11l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡟ࠪ࠴࡟࠻࠳࠹࡞ࡾ࠵࡟࠵࠳࠹࡞ࠫ࡟࠯ࠩ࠭楰"),l1ll1l111l_l1_,re.DOTALL)
			#l111l11l111l_l1_ = any(l1111ll11l11_l1_,l1111ll11ll1_l1_,l1111ll11l1l_l1_,l1111ll111l1_l1_)
			l1ll1l111l_l1_ = l1ll1l111l_l1_.replace(l11l1l_l1_ (u"ࠨ࠼ࠪ楱"),l11l1l_l1_ (u"ࠩࠪ楲"))
			l111l11l111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠶ࡡ࠵࠮࠻ࡠ࠯ࢁ࠸࡛࠱࠯࠶ࡡ࠰࠯ࠧ楳"),l1ll1l111l_l1_,re.DOTALL)
			l1llll111llll_l1_ = False
			for digits in l111l11l111l_l1_:
				if len(digits)==2:
					l1llll111llll_l1_ = True
					break
			if l11l1l_l1_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ楴") in l1ll1l111l_l1_: continue
			elif l11l1l_l1_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭極") in l1ll1l111l_l1_: continue
			elif l11l1l_l1_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ楶") in l1ll1l111l_l1_: continue
			elif l11lll1lll11_l1_(l11l1l_l1_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ楷")): continue
			elif l1ll1l111l_l1_ in [l11l1l_l1_ (u"ࠨࡴࠪ楸")] or l1llll111llll_l1_ or any(value in l1ll1l111l_l1_ for value in l111l1l1llll_l1_):
				LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ楹"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ楺")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ楻"))
				if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ楼"),l11l1l_l1_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ楽"))
				return True
	return False
def l1ll11ll1_l1_(data):
	if kodi_version>18.99: import urllib.parse as l11l11111l11_l1_
	else: import urllib as l11l11111l11_l1_
	l1111llllll1_l1_ = l11l11111l11_l1_.urlencode(data)
	return l1111llllll1_l1_
def l1lll111l1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ楾"),l11l1l_l1_ (u"ࠨࠩ楿"),url,l11l1l_l1_ (u"ࠩࡘࡖࡑࡊࡅࡄࡑࡇࡉࠬ榀"))
	if l11l1l_l1_ (u"ࠪࡁࠬ榁") in url:
		if l11l1l_l1_ (u"ࠫࡄ࠭概") in url: l111l1l_l1_,filters = url.split(l11l1l_l1_ (u"ࠬࡅࠧ榃"))
		else: l111l1l_l1_,filters = l11l1l_l1_ (u"࠭ࠧ榄"),url
		filters = filters.split(l11l1l_l1_ (u"ࠧࠧࠩ榅"))
		l11l1llll_l1_ = {}
		for filter in filters:
			#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ榆"),l11l1l_l1_ (u"ࠩࠪ榇"),filter,str(filters))
			key,value = filter.split(l11l1l_l1_ (u"ࠪࡁࠬ榈"))
			l11l1llll_l1_[key] = value
	else: l111l1l_l1_,l11l1llll_l1_ = url,{}
	return l111l1l_l1_,l11l1llll_l1_
def l1lll11111111_l1_(l111ll1_l1_,l1l11lll_l1_=l11l1l_l1_ (u"ࠫࠬ榉"),l11l11l1ll1_l1_=l11l1l_l1_ (u"ࠬ࠭榊")):
	global l111l1111111_l1_
	import threading
	l1lll1ll11lll_l1_ = threading.Thread(target=l1111ll11111_l1_,args=(l111ll1_l1_,l1l11lll_l1_,l11l11l1ll1_l1_))
	l1lll1ll11lll_l1_.start()
	l1lll1ll11lll_l1_.join()
	return l111l1111111_l1_
def PLAY_VIDEO(l111ll1_l1_,l1l11lll_l1_=l11l1l_l1_ (u"࠭ࠧ榋"),l11l11l1ll1_l1_=l11l1l_l1_ (u"ࠧࠨ榌")):
	global l111l1111111_l1_
	if not l11l11l1ll1_l1_: l11l11l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ榍")
	l111l1111111_l1_,l111l1lll111_l1_,httpd = l11l1l_l1_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧ࠴ࠬ榎"),l11l1l_l1_ (u"ࠪࠫ榏"),l11l1l_l1_ (u"ࠫࠬ榐")
	if len(l111ll1_l1_)==3:
		url,l1llll1l1111l_l1_,httpd = l111ll1_l1_
		if l1llll1l1111l_l1_: l111l1lll111_l1_ = l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ榑")+l1llll1l1111l_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ榒")
	else: url,l1llll1l1111l_l1_,httpd = l111ll1_l1_,l11l1l_l1_ (u"ࠧࠨ榓"),l11l1l_l1_ (u"ࠨࠩ榔")
	#url = l1llll_l1_(url)		# cause l1ll1ll1ll111_l1_ for l1ll1l1l1_l1_ l1lll1l1l_l1_ l1lllll111ll_l1_ l11lll11ll1_l1_
	url = url.replace(l11l1l_l1_ (u"ࠩࠨ࠶࠵࠭榕"),l11l1l_l1_ (u"ࠪࠤࠬ榖"))	# needed for l1l1l1l1ll1l_l1_
	l111ll1111_l1_ = l11l1l11l1_l1_(url,l1l11lll_l1_)
	if l1l11lll_l1_ not in [l11l1l_l1_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭榗"),l11l1l_l1_ (u"ࠬࡏࡐࡕࡘࠪ榘")]:
		if l1l11lll_l1_!=l11l1l_l1_ (u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ榙"): url = url.replace(l11l1l_l1_ (u"ࠧࠡࠩ榚"),l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬ榛"))
		LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ榜"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡐࡳࡧࡳࡥࡷ࡯࡮ࡨࠢࡷࡳࠥࡶ࡬ࡢࡻ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ榝")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ榞")+l111l1lll111_l1_)
		if l111ll1111_l1_==l11l1l_l1_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ榟") and l1l11lll_l1_ not in [l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ榠"),l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ榡")]:
			headers = {l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ榢"):l11l1l_l1_ (u"ࠩࠪ榣")}
			l1ll1ll1_l1_,l1lll1_l1_ = l11l1ll1ll_l1_(url,headers)
			count = len(l1lll1_l1_)
			if count>1:
				l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠢࠫࠫ榤")+str(count)+l11l1l_l1_ (u"๋ࠫࠥไโࠫࠪ榥"), l1ll1ll1_l1_)
				if l1l_l1_ == -1:
					l1llll1l_l1_(l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวࠠศๆอุ฿๐ไࠨ榦"),l11l1l_l1_ (u"࠭ࠧ榧"))
					return l111l1111111_l1_
			else: l1l_l1_ = 0
			url = l1lll1_l1_[l1l_l1_]
			if l1ll1ll1_l1_[0]!=l11l1l_l1_ (u"ࠧ࠮࠳ࠪ榨"):
				LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ榩"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ榪")+l1ll1ll1_l1_[l1l_l1_]+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ榫")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ榬"))
		#url = url+l11l1l_l1_ (u"ࠬࠬࡲࡢࡰࡪࡩࡂ࠶࠭࠲࠳࠻࠺࠵࠶࠰࠱ࠩ榭")
		#url = url+l11l1l_l1_ (u"࠭ࡼࡅࡐࡗࡁ࠶ࠬࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥ࠾ࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠶ࠨࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࡁ࡬ࢀࡩࡱ࠮ࠣࡨࡪ࡬࡬ࡢࡶࡨࠪࡆࡩࡣࡦࡲࡷࡁ࠯࠵ࠪࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬࡑ࡯࡮ࡶࡺ࠾ࠤࡆࡴࡤࡳࡱ࡬ࡨࠥ࠽࠮࠱࠽ࠣࡗࡒ࠳ࡇ࠹࠻࠵ࡅࠥࡈࡵࡪ࡮ࡧ࠳ࡓࡘࡄ࠺࠲ࡐ࠿ࠥࡽࡶࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠯࠵࠰࠳ࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠽࠮࠱࠰࠶࠷࠾࠼࠮࠹࠹ࠣࡑࡴࡨࡩ࡭ࡧࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ榮")
		if l11l1l_l1_ (u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ榯") in url: url = url+l11l1l_l1_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ榰")
		elif l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ榱") in url.lower() and l11l1l_l1_ (u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ榲") not in url and l11l1l_l1_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ榳") not in url:
			if l11l1l_l1_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࠪ榴") not in url and l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࠨ榵") in url.lower():
				if l11l1l_l1_ (u"ࠧࡽࠩ榶") not in url: url = url+l11l1l_l1_ (u"ࠨࡾࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬ榷")
				else: url = url+l11l1l_l1_ (u"ࠩࠩࡺࡪࡸࡩࡧࡻࡳࡩࡪࡸ࠽ࡧࡣ࡯ࡷࡪ࠭榸")
			if l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲ࠮ࡣࡪࡩࡳࡺࠧ榹") not in url.lower() and l1l11lll_l1_ not in [l11l1l_l1_ (u"ࠫࡎࡖࡔࡗࠩ榺"),l11l1l_l1_ (u"ࠬࡓ࠳ࡖࠩ榻")]:
				if l11l1l_l1_ (u"࠭ࡼࠨ榼") not in url: url = url+l11l1l_l1_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧ榽")
				else: url = url+l11l1l_l1_ (u"ࠨࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ榾")
		#url = url.replace(l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ榿"),l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫ槀"))
	LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ槁"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡉࡲࡸࠥ࡬ࡩ࡯ࡣ࡯ࠤࡺࡸ࡬࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ槂")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ槃"))
	l1ll1ll1l11ll_l1_ = xbmcgui.ListItem()
	#l1ll1ll1l11ll_l1_ = xbmcgui.ListItem(l11l1l_l1_ (u"ࠧࡵࡧࡶࡸࠬ槄"))
	l11l11l1ll1_l1_,l111l1ll1l11_l1_,l1llll1l1l1ll_l1_,l1lll1l1lll1l_l1_,l1lll111ll1ll_l1_,l1llllllll111_l1_,l111l1ll11ll_l1_,l1ll1lll11111_l1_,l1llll1l11l11_l1_ = EXTRACT_KODI_PATH(addon_path)
	if l1l11lll_l1_ not in [l11l1l_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ槅"),l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜ࠧ槆")]:
		if kodi_version<19: l1ll1ll1l1lll_l1_ = l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭ࡢࡦࡧࡳࡳ࠭槇")
		else: l1ll1ll1l1lll_l1_ = l11l1l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࠩ槈")
		#l1ll1ll1l11ll_l1_ = xbmcgui.ListItem(path=url)
		l1ll1ll1l11ll_l1_.setProperty(l1ll1ll1l1lll_l1_, l11l1l_l1_ (u"ࠬ࠭槉"))
		l1ll1ll1l11ll_l1_.setMimeType(l11l1l_l1_ (u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ槊"))
		if kodi_version<20: l1ll1ll1l11ll_l1_.setInfo(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭構"),{l11l1l_l1_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ槌"):l11l1l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ槍")})
		else:
			l1lll1111l11l_l1_ = l1ll1ll1l11ll_l1_.getVideoInfoTag()
			l1lll1111l11l_l1_.setMediaType(l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ槎"))
		#l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡩࡤࡱࡱࠫ槏"))
		#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭槐"),l11l1l_l1_ (u"࠭ࡅࡎࡃࡇ࠾࠿ࡀ࠺࠻ࠢࠪ槑")+l111_l1_)
		#l1ll1ll1l11ll_l1_.setArt({l11l1l_l1_ (u"ࠧࡪࡥࡲࡲࠬ槒"):l111_l1_,l11l1l_l1_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ槓"):l111_l1_,l11l1l_l1_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ槔"):l111_l1_})
		l1ll1ll1l11ll_l1_.setArt({l11l1l_l1_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ槕"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫ槖"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ槗"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭様"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩ槙"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫ槚"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ槛"):l1lll111ll1ll_l1_,l11l1l_l1_ (u"ࠪ࡭ࡨࡵ࡮ࠨ槜"):l1lll111ll1ll_l1_})
		#l1ll1ll1l11ll_l1_.setInfo(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ槝"),{l11l1l_l1_ (u"࡚ࠬࡩࡵ࡮ࡨࠫ槞"):name})
		#name = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ槟"))
		#name = name.strip(l11l1l_l1_ (u"ࠧࠡࠩ槠"))
		# when set to l11l1l_l1_ (u"ࠣࡈࡤࡰࡸ࡫ࠢ槡") it l111ll111lll_l1_ l1lll1ll1ll11_l1_ l1ll11l1ll1l_l1_ and l1lll1ll1l11l_l1_ l111l111l1ll_l1_ l1ll1llll1l11_l1_ l1l1ll11ll_l1_
		if l111ll1111_l1_ in [l11l1l_l1_ (u"ࠩ࠱ࡱࡵࡪࠧ槢"),l11l1l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ槣")]: l1ll1ll1l11ll_l1_.setContentLookup(True)
		else: l1ll1ll1l11ll_l1_.setContentLookup(False)
		#if l111ll1111_l1_ in [l11l1l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ槤")]: l1ll1ll1l11ll_l1_.setContentLookup(False)
		if l11l1l_l1_ (u"ࠬࡸࡴ࡮ࡲࠪ槥") in url:
			import l1l1l1ll1l1l_l1_
			l1l1l1ll1l1l_l1_.l1l1111lllll_l1_(l11l1l_l1_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩ槦"),False)
		elif l111ll1111_l1_==l11l1l_l1_ (u"ࠧ࠯࡯ࡳࡨࠬ槧") or l11l1l_l1_ (u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ槨") in url:
			import l1l1l1ll1l1l_l1_
			l1l1l1ll1l1l_l1_.l1l1111lllll_l1_(l11l1l_l1_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ槩"),False)
			l1ll1ll1l11ll_l1_.setProperty(l1ll1ll1l1lll_l1_,l11l1l_l1_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ槪"))
			l1ll1ll1l11ll_l1_.setProperty(l11l1l_l1_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠲ࡲࡧ࡮ࡪࡨࡨࡷࡹࡥࡴࡺࡲࡨࠫ槫"),l11l1l_l1_ (u"ࠬࡳࡰࡥࠩ槬"))
			#l1ll1ll1l11ll_l1_.setMimeType(l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡩࡧࡳࡩ࠭ࡻࡱࡱ࠭槭"))
			#l1ll1ll1l11ll_l1_.setContentLookup(False)
		if l1llll1l1111l_l1_:
			l1ll1ll1l11ll_l1_.setSubtitles([l1llll1l1111l_l1_])
			#xbmc.log(LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠥࠦࡁࡥࡦࡨࡨࠥࡹࡵࡣࡶ࡬ࡸࡱ࡫ࠠࡵࡱࠣࡺ࡮ࡪࡥࡰࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀ࡛ࠨ槮")+l1llll1l1111l_l1_+l11l1l_l1_ (u"ࠨ࡟ࠪ槯"), level=xbmc.LOGNOTICE)
	if l11l11l1ll1_l1_==l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ槰") and l1l11lll_l1_==l11l1l_l1_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬ槱"):
		l111l1111111_l1_ = l11l1l_l1_ (u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ槲")
		l1l11lll_l1_ = l11l1l_l1_ (u"ࠬࡖࡌࡂ࡛ࡢࡈࡑࡥࡆࡊࡎࡈࡗࠬ槳")
	elif l11l11l1ll1_l1_==l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ槴") and l1ll1lll11111_l1_.startswith(l11l1l_l1_ (u"ࠧ࠷ࠩ槵")):
		l111l1111111_l1_ = l11l1l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ槶")
		l1l11lll_l1_ = l1l11lll_l1_+l11l1l_l1_ (u"ࠩࡢࡈࡑ࠭槷")
	# l111111111ll_l1_ l1llllll1l111_l1_
	#	l1lll1111l111_l1_ = l1llll1l1lll1_l1_() is needed for both setResolvedUrl() and Player()
	#	and should be l11l1111ll_l1_ with xbmc.sleep(step*1000)
	if l111l1111111_l1_!=l11l1l_l1_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ槸"): l1111l111lll_l1_()
	l1lll1111l111_l1_ = l1llll1l1lll1_l1_()
	if l1lll1111l111_l1_.status:
		l111l1111111_l1_ == l11l1l_l1_ (u"ࠫࠬ槹")
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭槺"),l11l1l_l1_ (u"࠭ࠧ槻"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ槼"),l11l1l_l1_ (u"ࠨๆๅำ่ࠥวๆࠢส่๊ฮัๆฮࠣฬส๐โศใࠣฮูเ๊ๅ๋ࠢฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋๊ࠢิฬࠦวๅฮ๊หื࠭槽"))
	elif l11l11l1ll1_l1_==l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ槾") and not l1ll1lll11111_l1_.startswith(l11l1l_l1_ (u"ࠪ࠺ࠬ槿")):
		#title = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡪࡶ࡯ࡩࠬ樀"))
		#l1ll1ll1l11ll_l1_.setInfo(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ樁"),{l11l1l_l1_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ樂"): 3600})
		#xbmcplugin.setContent(addon_handle,l11l1l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ樃"))
		#l1ll1ll1l11ll_l1_.setInfo(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ樄"),{l11l1l_l1_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ樅"):l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ樆")})
		#l1ll1ll1l11ll_l1_.setProperty(l11l1l_l1_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨ樇"),l11l1l_l1_ (u"ࠬࡺࡲࡶࡧࠪ樈"))
		#l1ll1ll1l11ll_l1_.setInfo(type=l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ樉"),l1lll111111ll_l1_={l11l1l_l1_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ樊"):l11l1l_l1_ (u"ࠨࡪࡨࡰࡱࡵࠠࡸࡱࡵࡰࡩ࠭樋")})
		l1ll1ll1l11ll_l1_.setPath(url)
		LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ樌"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ樍")+url+l11l1l_l1_ (u"ࠫࠥࡣࠧ樎"))
		xbmcplugin.setResolvedUrl(addon_handle,True,l1ll1ll1l11ll_l1_)
	elif l11l11l1ll1_l1_==l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ樏"):
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭樐"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ樑")+url+l11l1l_l1_ (u"ࠨࠢࡠࠫ樒"))
		l1lll1111l111_l1_.play(url,l1ll1ll1l11ll_l1_)
		#xbmc.Player().play(url,l1ll1ll1l11ll_l1_)
	succeeded = False
	if l111l1111111_l1_==l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ樓"):
		import l111lll1ll_l1_
		succeeded = l111lll1ll_l1_.l11l11111l_l1_(url,l111ll1111_l1_,l1l11lll_l1_)
		if succeeded: l1111l111lll_l1_()
	else:
		timeout,l111l1111111_l1_ = 10,l11l1l_l1_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ樔")
		for l11l1l1ll1_l1_ in range(timeout):
			# l111111111ll_l1_ l1llllll1l111_l1_
			#	if using time.sleep() l111l1l1111_l1_ of xbmc.sleep() l1111lll1111_l1_ the l1l1lllll1ll_l1_ status
			#	l11l1l_l1_ (u"ࠦࡲࡿࡰ࡭ࡣࡼࡩࡷ࠴ࡳࡵࡣࡷࡹࡸࠨ樕") will stop l111l1llll11_l1_ for both setResolvedUrl() and Player()
			xbmc.sleep(1000)
			l111l1111111_l1_ = l1lll1111l111_l1_.status
			if l111l1111111_l1_==l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭樖"):
				l1llll1l_l1_(l11l1l_l1_ (u"࠭วๅใํำ๏๎๋ࠠ฻่่ࠬ樗"),l11l1l_l1_ (u"ࠧࠨ樘"),time=500)
				LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࡠࡎࡌࡒࡊ࡙ࠧ標"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࡷ࡫ࡧࡩࡴࠦࡩࡴࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭樚")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭樛")+l111l1lll111_l1_)
				break
			elif l111l1111111_l1_==l11l1l_l1_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ樜"):
				LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ樝"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ樞")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ樟")+l111l1lll111_l1_)
				l1llll1l_l1_(l11l1l_l1_ (u"ࠨษ็ๅ๏ี๊้ࠢ็้ࠥ๐ูๆๆࠪ樠"),l11l1l_l1_ (u"ࠩࠪ模"),time=500)
				break
			l1llll1l_l1_(l11l1l_l1_ (u"ࠪะฬื๊ࠡฬื฾๏๊ࠠศๆไ๎ิ๐่ࠨ樢"),l11l1l_l1_ (u"ࠫออโ๋ࠢࠪ樣")+str(timeout-l11l1l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦหศ่ํอࠬ樤"))
		else:
			l1llll1l_l1_(l11l1l_l1_ (u"࠭วๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠨ樥"),l11l1l_l1_ (u"ࠧࠨ樦"),time=500)
			if l111l1111111_l1_: LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭樧"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡊࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡤ࡯ࡳࡨࡱࡥࡥࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ樨")+url+l11l1l_l1_ (u"ࠪࠤࡢ࠭権")+l111l1lll111_l1_)
			else: LOG_THIS(l11l1l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ横"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡖ࡬ࡱࡪࡵࡵࡵࠢࡸࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ樫")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ樬")+l111l1lll111_l1_)
			l111l1111111_l1_ = l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ樭")
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡩࡧࠢ࡫ࡸࡹࡶࡤ࠻ࠏࠍࠍࠎࠩࠠࡩࡶࡷࡴ࠿࠵࠯࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽࠹࠺࠶࠵࠶࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡧࡱ࡯ࡣ࡬ࠢࡲ࡯ࠥࡺ࡯ࠡࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠣࡸ࡭࡫ࠠࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠬ࠯ࠍࠋࠋࠌࠧ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠵ࡵࡪࠪ࠭ࠒࠐࠉࠊࡶ࡬ࡱࡪ࠴ࡳ࡭ࡧࡨࡴ࠭࠷ࠩࠎࠌࠌࠍ࡭ࡺࡴࡱࡦ࠱ࡷ࡭ࡻࡴࡥࡱࡺࡲ࠭࠯ࠍࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࠧࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠥ࡯ࡳࠡࡦࡲࡻࡳ࠭ࠬࠨࠩࠬࠑࠏࠏࠢࠣࠤ樮")
	if l111l1111111_l1_ in [l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡩ࡯ࡩࠪ樯"),l11l1l_l1_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ樰")] or succeeded: response = l11l1111l11l_l1_(l1l11lll_l1_)
	else: l1lll1111l111_l1_.stop()
	#if l111l1111111_l1_ in [l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭樱"),l11l1l_l1_ (u"ࠬࡺࡲࡪࡧࡧࠫ樲"),l11l1l_l1_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭樳"),l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ樴"),l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ樵")]: l111ll111111_l1_(l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡑࡇ࡙ࡠࡘࡌࡈࡊࡕ࠭࠳ࡰࡧࠫ樶"),False)
	#l111ll111111_l1_(l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏ࠮࠵ࡵࡨࠬ樷"))
	#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭樸") in url and l111l1111111_l1_ in [l11l1l_l1_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ樹"),l11l1l_l1_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ樺")]:
	#	l111l1llll11_l1_ = HTTPS(False)
	#	if not l111l1llll11_l1_:
	#		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ樻"),l11l1l_l1_ (u"ࠨࠩ樼"),l11l1l_l1_ (u"ࠩส่ฬะีศๆู้ࠣ็ัࠨ樽"),l11l1l_l1_ (u"ู้้ࠪไสࠢ࠱࠲࠳ࠦ็ัษࠣห้็๊ะ์๋ࠤ๏ำสศฮࠣห้๏ࠠศฬุห้ࠦๅีใิࠤ࠭ืศุุ่ࠢๆื๊ࠩࠡ็็๋ࠦไๅลึๅࠥอไศฬุห้ࠦวๅ็ืๅึࠦไศࠢํ฽ฺ๊๊ࠠๆ์ࠤัํวำๅࠪ樾"))
	#		return l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ樿")
	#sys.exit()
	if 0 and l111l1111111_l1_==l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭橀"):
		LOG_THIS(l11l1l_l1_ (u"࠭ࠧ橁"),l11l1l_l1_ (u"ࠧࡑࡎࡄ࡝ࡤ࡙ࡔࡂࡖࡘࡗ࠿ࡀࠠࠡࠢࠪ橂")+l11l1l_l1_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩ橃"))
		while True:
			l111l1111111_l1_ = l1lll1111l111_l1_.status
			#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ橄"),l11l1l_l1_ (u"ࠪࡔࡑࡇ࡙ࡠࡕࡗࡅ࡙࡛ࡓ࠻࠼ࠣࠤࠥ࠭橅")+l111l1111111_l1_)
			if l111l1111111_l1_!=l11l1l_l1_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ橆"): break
			xbmc.sleep(1000)
		LOG_THIS(l11l1l_l1_ (u"ࠬ࠭橇"),l11l1l_l1_ (u"࠭ࡐࡍࡃ࡜ࡣࡘ࡚ࡁࡕࡗࡖ࠾࠿ࠦࠠࠡࠩ橈")+l11l1l_l1_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ橉"))
	return l111l1111111_l1_
def DIALOG_OK(*args,**kwargs):
	if args:
		l11ll1llllll_l1_ = args[0]
		l11l111l_l1_ = args[1]
		if not l11ll1llllll_l1_: l11ll1llllll_l1_ = l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ橊")
		if not l11l111l_l1_: l11l111l_l1_ = l11l1l_l1_ (u"ࠩสืฯ๋ัศำࠪ橋")
		header = args[2]
		text = l11l1l_l1_ (u"ࠪࡠࡳ࠭橌").join(args[3:])
	else: l11ll1llllll_l1_,l11l111l_l1_,header,text = l11l1l_l1_ (u"ࠫࠬ橍"),l11l1l_l1_ (u"ࠬࡕࡋࠨ橎"),l11l1l_l1_ (u"࠭ࠧ橏"),l11l1l_l1_ (u"ࠧࠨ橐")
	DIALOG_THREEBUTTONS_TIMEOUT(l11ll1llllll_l1_,l11l1l_l1_ (u"ࠨࠩ橑"),l11l111l_l1_,l11l1l_l1_ (u"ࠩࠪ橒"),header,text)
	return
	#return xbmcgui.Dialog().ok(*args,**kwargs)
def DIALOG_YESNO(*args,**kwargs):
	l11ll1llllll_l1_ = args[0]
	l1lllll11l111_l1_ = args[1]
	l1llll1ll11l1_l1_ = args[2]
	if l1llll1ll11l1_l1_ or l1lllll11l111_l1_: l1lllll1111ll_l1_ = True
	else: l1lllll1111ll_l1_ = False
	header = args[3]
	text = args[4]
	if not l11ll1llllll_l1_: l11ll1llllll_l1_ = l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ橓")
	if not l1lllll11l111_l1_: l1lllll11l111_l1_ = l11l1l_l1_ (u"่๊ࠫวࠨ橔")
	if not l1llll1ll11l1_l1_: l1llll1ll11l1_l1_ = l11l1l_l1_ (u"ࠬ์ูๆࠩ橕")
	if len(args)>=6: text += l11l1l_l1_ (u"࠭࡜࡯ࠩ橖")+args[5]
	if len(args)>=7: text += l11l1l_l1_ (u"ࠧ࡝ࡰࠪ橗")+args[6]
	choice = DIALOG_THREEBUTTONS_TIMEOUT(l11ll1llllll_l1_,l1lllll11l111_l1_,l11l1l_l1_ (u"ࠨࠩ橘"),l1llll1ll11l1_l1_,header,text)
	if choice==-1 and l1lllll1111ll_l1_: choice = -1
	elif choice==-1 and not l1lllll1111ll_l1_: choice = False
	elif choice==0: choice = False
	elif choice==2: choice = True
	return choice
	#return xbmcgui.Dialog().l111111ll1l1_l1_(*args,**kwargs)
def DIALOG_SELECT(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1llll1l_l1_(*args,**kwargs):
	header = args[0]
	text = args[1]
	if l11l1l_l1_ (u"ࠩࡷ࡭ࡲ࡫ࠧ橙") in list(kwargs.keys()): l11l1111lll1_l1_ = kwargs[l11l1l_l1_ (u"ࠪࡸ࡮ࡳࡥࠨ橚")]
	else: l11l1111lll1_l1_ = 1000
	if len(args)>2 and l11l1l_l1_ (u"ࠫࡹ࡯࡭ࡦࠩ橛") not in args[2]: l1111l1lll11_l1_ = args[2]
	else: l1111l1lll11_l1_ = l11l1l_l1_ (u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠫ橜")
	l1l1111111ll_l1_ = xbmcgui.WindowXMLDialog(l11l1l_l1_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭橝"),addonfolder,l11l1l_l1_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ橞"),l11l1l_l1_ (u"ࠨ࠹࠵࠴ࡵ࠭機"))
	l11111111lll_l1_,l111l11111ll_l1_ = l1lll111l111l_l1_(l11l1l_l1_ (u"ࠩࠪ橠"),l11l1l_l1_ (u"ࠪࠫ橡"),l11l1l_l1_ (u"ࠫࠬ橢"),header,text,l1111l1lll11_l1_,l11l1l_l1_ (u"ࠬࡲࡥࡧࡶࠪ橣"),720,False)
	#time.sleep(0.200)
	l1l1111111ll_l1_.show()
	if l1111l1lll11_l1_==l11l1l_l1_ (u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡺࡷࡰࡪࡤࡰ࡫ࡹࠧ橤"):
		l1l1111111ll_l1_.getControl(9040).setHeight(215)
		l1l1111111ll_l1_.getControl(9040).setPosition(55,-80)
		l1l1111111ll_l1_.getControl(9050).setPosition(120,-60)
		l1l1111111ll_l1_.getControl(400).setPosition(90,-35)
	l1l1111111ll_l1_.getControl(401).setVisible(False)
	l1l1111111ll_l1_.getControl(402).setVisible(False)
	l1l1111111ll_l1_.getControl(9050).setImage(l11111111lll_l1_)
	l1l1111111ll_l1_.getControl(9050).setHeight(l111l11111ll_l1_)
	import threading
	l11l11111l1l_l1_ = threading.Thread(target=l1ll1llllllll_l1_,args=(l1l1111111ll_l1_,l11111111lll_l1_,l11l1111lll1_l1_))
	l11l11111l1l_l1_.start()
	#l11l11111l1l_l1_.join()
	return
	#return xbmcgui.Dialog().notification(l1llll11111l1_l1_=False,*args,**kwargs)
def l1ll1llllllll_l1_(l1l1111111ll_l1_,l11111111lll_l1_,l11l1111lll1_l1_):
	time.sleep(l11l1111lll1_l1_//1000.0)
	time.sleep(0.100)
	if os.path.exists(l11111111lll_l1_):
		try: os.remove(l11111111lll_l1_)
		except: pass
	#del l1l1111111ll_l1_
	return
def DIALOG_TEXTVIEWER(*args,**kwargs):
	header,text,l1111l1lll11_l1_,l11ll1llllll_l1_ = l11l1l_l1_ (u"ࠧࠨ橥"),l11l1l_l1_ (u"ࠨࠩ橦"),l11l1l_l1_ (u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ橧"),l11l1l_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ橨")
	if len(args)>=1: header = args[0]
	if len(args)>=2: text = args[1]
	if len(args)>=3: l1111l1lll11_l1_ = args[2]
	if len(args)>=4: l11ll1llllll_l1_ = args[3]
	return l11l1llll1_l1_(l11ll1llllll_l1_,header,text,l1111l1lll11_l1_)
	#return xbmcgui.Dialog().l1lllll1l1ll1_l1_(*args,**kwargs)
def DIALOG_CONTEXTMENU(*args,**kwargs):
	return xbmcgui.Dialog().l1lll1l1l1l1l_l1_(*args,**kwargs)
def l11l111ll1_l1_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l111ll11l1ll_l1_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def DIALOG_PROGRESS(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
	#l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l1111l1l111l_l1_,header,text,l1111l1lll11_l1_,l11ll1llllll_l1_ = args[0],args[1],args[2],args[3],args[4],args[5],args[6]
	#l1l1111111ll_l1_ = l111l11llll1_l1_(l11l1l_l1_ (u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭橩"),addonfolder,l11l1l_l1_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭橪"),l11l1l_l1_ (u"࠭࠷࠳࠲ࡳࠫ橫"))
	#l1l1111111ll_l1_.l111l11ll1ll_l1_(l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l1111l1l111l_l1_,header,text,l1111l1lll11_l1_,l11ll1llllll_l1_,855)
	#return l1l1111111ll_l1_
	l11l1l_l1_ (u"ࠢࠣࠤࠐࠎࠎ࡯ࡦࠡࡶ࡬ࡱࡪࡵࡵࡵࡀ࠳࠾ࠥࡪࡩࡢ࡮ࡲ࡫࠳ࡹࡴࡢࡴࡷࡆࡺࡺࡴࡰࡰࡶࡘ࡮ࡳࡥࡰࡷࡷࠬࡹ࡯࡭ࡦࡱࡸࡸ࠮ࠓࠊࠊࡧ࡯ࡷࡪࡀࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡦࡰࡤࡦࡱ࡫ࡂࡶࡶࡷࡳࡳࡹࠨࠪࠏࠍࠍࠨࡪࡩࡢ࡮ࡲ࡫࠳ࡻࡰࡥࡣࡷࡩࡕࡸ࡯ࡨࡴࡨࡷࡸࡈࡡࡳࠪ࠺࠴࠮ࠏࠣࠡ࠹࠳ࠩࠒࠐࠉࡥ࡫ࡤࡰࡴ࡭࠮ࡥࡱࡐࡳࡩࡧ࡬ࠩࠫࠐࠎࠎࡩࡨࡰ࡫ࡦࡩࠥࡃࠠࡥ࡫ࡤࡰࡴ࡭࠮ࡤࡪࡲ࡭ࡨ࡫ࡉࡅࠏࠍࠍࡹࡸࡹ࠻ࠢࡲࡷ࠳ࡸࡥ࡮ࡱࡹࡩ࠭ࡪࡩࡢ࡮ࡲ࡫࠳࡯࡭ࡢࡩࡨࡣ࡫࡯࡬ࡦࡰࡤࡱࡪ࠯ࠍࠋࠋࡨࡼࡨ࡫ࡰࡵ࠼ࠣࡴࡦࡹࡳࠎࠌࠌࠧࡩ࡫࡬ࠡࡦ࡬ࡥࡱࡵࡧࠎࠌࠌࡶࡪࡺࡵࡳࡰࠣࡧ࡭ࡵࡩࡤࡧࠐࠎࠎࠨࠢࠣ橬")
def l1l1lllll_l1_(l1llll1l11lll_l1_):
	if kodi_version>17.99: l1l1111111ll_l1_ = l11l1l_l1_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭橭")
	else: l1l1111111ll_l1_ = l11l1l_l1_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭橮")
	l1llll1l11lll_l1_ = l1llll1l11lll_l1_.lower()
	if l1llll1l11lll_l1_==l11l1l_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ橯"): xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭橰")+l1l1111111ll_l1_+l11l1l_l1_ (u"ࠬ࠯ࠧ橱"))
	elif l1llll1l11lll_l1_==l11l1l_l1_ (u"࠭ࡳࡵࡱࡳࠫ橲"): xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࠧ橳")+l1l1111111ll_l1_+l11l1l_l1_ (u"ࠨࠫࠪ橴"))
	return
def DIALOG_THREEBUTTONS_TIMEOUT(l11ll1llllll_l1_,l1111l11ll11_l1_=l11l1l_l1_ (u"ࠩࠪ橵"),l1lll11ll1l1l_l1_=l11l1l_l1_ (u"ࠪࠫ橶"),l1111l1l111l_l1_=l11l1l_l1_ (u"ࠫࠬ橷"),header=l11l1l_l1_ (u"ࠬ࠭橸"),text=l11l1l_l1_ (u"࠭ࠧ橹"),l1lllll11111l_l1_=0,l1lll1ll1l1l1_l1_=0,l1111l1lll11_l1_=l11l1l_l1_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ橺")):
	if not l11ll1llllll_l1_: l11ll1llllll_l1_ = l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ橻")
	l1l1111111ll_l1_ = l111l11llll1_l1_(l11l1l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫ橼"),addonfolder,l11l1l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ橽"),l11l1l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ橾"))
	l1l1111111ll_l1_.l111l11ll1ll_l1_(l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l1111l1l111l_l1_,header,text,l1111l1lll11_l1_,l11ll1llllll_l1_,900,l1lllll11111l_l1_,l1lll1ll1l1l1_l1_)
	if l1lllll11111l_l1_>0: l1l1111111ll_l1_.l111lllllll1_l1_()
	if l1lll1ll1l1l1_l1_>0: l1l1111111ll_l1_.l111lll11ll1_l1_()
	if l1lllll11111l_l1_==0 and l1lll1ll1l1l1_l1_==0: l1l1111111ll_l1_.enableButtons()
	l1l1111111ll_l1_.doModal()
	choice = l1l1111111ll_l1_.l11l111111l1_l1_
	return choice
def l11l1llll1_l1_(l11ll1llllll_l1_,header,text,l1111l1lll11_l1_=l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭橿")):
	if not l11ll1llllll_l1_: l11ll1llllll_l1_ = l11l1l_l1_ (u"࠭࡬ࡦࡨࡷࠫ檀")
	#text = l11l1l_l1_ (u"ࠧ࡝ࡰࠪ檁").join(text.splitlines()[:480])	#730=30k , 610= 25k , 480=20k
	#header = l11l1l_l1_ (u"ࠨࠩ檂")
	l1l1111111ll_l1_ = xbmcgui.WindowXMLDialog(l11l1l_l1_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬ檃"),addonfolder,l11l1l_l1_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫ檄"),l11l1l_l1_ (u"ࠫ࠼࠸࠰ࡱࠩ檅"))
	l11111111lll_l1_,l111l11111ll_l1_ = l1lll111l111l_l1_(l11l1l_l1_ (u"ࠬ࠭檆"),l11l1l_l1_ (u"࠭ࠧ檇"),l11l1l_l1_ (u"ࠧࠨ檈"),header,text,l1111l1lll11_l1_,l11ll1llllll_l1_,1270,False)
	l1l1111111ll_l1_.show()
	#time.sleep(1)
	#l1l1111111ll_l1_.getControl(9050).l1l111l11lll_l1_(1270-60)
	l1l1111111ll_l1_.getControl(9050).setHeight(l111l11111ll_l1_)
	l1l1111111ll_l1_.getControl(9050).setImage(l11111111lll_l1_)
	result = l1l1111111ll_l1_.doModal()
	#del l1l1111111ll_l1_
	try: os.remove(l11111111lll_l1_)
	except: pass
	return result
def l11llll11_l1_(l1lll1l1ll1ll_l1_=True):
	if l1lll1l1ll1ll_l1_:
		l111ll111l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡵࡷࡶࠬ檉"),l11l1l_l1_ (u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬ檊"),l11l1l_l1_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭檋"))
		if l111ll111l_l1_: return l111ll111l_l1_
	#LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ檌"),l11l1l_l1_ (u"ࠬࡋࡍࡂࡆࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࠥࡻࡳࡦࡴࡤ࡫ࡪࡴࡴ࠻ࠢࠪ檍")+results)
	# l11l1111111l_l1_ and l111111111_l1_ common user l1llll11ll1l1_l1_ (l111l1lll1ll_l1_ l111llllllll_l1_)
	text = l11l1l_l1_ (u"࠭ࠧ檎")
	url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡨࡧ࡭ࡨ࡬ࡰࡩ࠱ࡻ࡮ࡲ࡬ࡴࡪࡲࡹࡸ࡫࠮ࡤࡱࡰ࠳࠷࠶࠱࠳࠱࠳࠵࠴࠶࠳࠰࡯ࡲࡷࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡵࡴࡧࡵ࠱ࡦ࡭ࡥ࡯ࡶࡶ࠳ࠬ檏")
	headers = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ檐"):url}
	response = OPENURL_REQUESTS_CACHED(VERYLONG_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭檑"),url,l11l1l_l1_ (u"ࠪࠫ檒"),headers,l11l1l_l1_ (u"ࠫࠬ檓"),l11l1l_l1_ (u"ࠬ࠭檔"),l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡃࡑࡈࡔࡓ࡟ࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠰࠵ࡸࡺࠧ檕"),False,False)
	if response.succeeded:
		html = response.content
		count = html.count(l11l1l_l1_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡࠨ檖"))
		if count>80:
			text = re.findall(l11l1l_l1_ (u"ࠨࡩࡨࡸ࠲ࡺࡨࡦ࠯࡯࡭ࡸࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ檗"),html,re.DOTALL)
			text = text[0]
			#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ檘"),l11l1l_l1_ (u"ࠪࠫ檙"),l11l1l_l1_ (u"ࠫࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚ࠧ檚"),l11l1l_l1_ (u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩ࡙ࠣࡘࡋࡒ࠮ࡃࡊࡉࡓ࡚ࡓࠡࡵࡸࡧࡨ࡫ࡳࡴࡨࡸࡰࠬ檛"))
	if not text:
		l1llllll111l1_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ檜"),l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨ檝"))
		text = open(l1llllll111l1_l1_,l11l1l_l1_ (u"ࠨࡴࡥࠫ檞")).read()
		if kodi_version>18.99: text = text.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ檟"))
		text = text.replace(l11l1l_l1_ (u"ࠪࡠࡷ࠭檠"),l11l1l_l1_ (u"ࠫࠬ檡"))
	l1llllllll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡍࡰࡼ࡬ࡰࡱࡧ࠮ࠫࡁࠬࡠࡳ࠭檢"),text,re.DOTALL)
	l111ll1ll111_l1_ = []
	for line in l1llllllll11l_l1_:
		l1llll1l1ll11_l1_ = line.lower()
		if l11l1l_l1_ (u"࠭ࡡ࡯ࡦࡵࡳ࡮ࡪࠧ檣") in l1llll1l1ll11_l1_: continue
		if l11l1l_l1_ (u"ࠧࡶࡤࡸࡲࡹࡻࠧ檤") in l1llll1l1ll11_l1_: continue
		#if l11l1l_l1_ (u"ࠨࡪࡷࡱࡱ࠭檥") in l1llll1l1ll11_l1_: continue
		l111ll1ll111_l1_.append(line)
	l111ll111l_l1_ = random.sample(l111ll1ll111_l1_,1)
	l111ll111l_l1_ = l111ll111l_l1_[0]
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ檦"),l11l1l_l1_ (u"ࠪࠫ檧"),str(len(l1llllllll11l_l1_)),l111ll111l_l1_)
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ檨"),l11l1l_l1_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ檩"),l111ll111l_l1_,l1ll1l1ll_l1_)
	return l111ll111l_l1_
def l111l1l1111l_l1_(l1ll1lllll1l_l1_):
	#if l11l1l_l1_ (u"࠭ࡦࡰࡴࡦࡩࡩࠦࡥࡹ࡫ࡷࠫ檪") in str(error).lower(): return
	#l1ll1lllll1l_l1_ = traceback.format_exc()
	sys.stderr.write(l1ll1lllll1l_l1_)
	lines = l1ll1lllll1l_l1_.splitlines()
	error = lines[-1]
	l1111l1ll1l1_l1_ = open(l1l11l11ll1l_l1_,l11l1l_l1_ (u"ࠧࡳࡤࠪ檫")).read()
	if kodi_version>18.99: l1111l1ll1l1_l1_ = l1111l1ll1l1_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭檬"))
	l1111l1ll1l1_l1_ = l1111l1ll1l1_l1_[-8000:]
	sep = l11l1l_l1_ (u"ࠩࡀࠫ檭")*100
	if sep in l1111l1ll1l1_l1_: l1111l1ll1l1_l1_ = l1111l1ll1l1_l1_.rsplit(sep,1)[1]
	if error in l1111l1ll1l1_l1_: l1111l1ll1l1_l1_ = l1111l1ll1l1_l1_.rsplit(error,1)[0]
	#l11l1llll1_l1_(l11l1l_l1_ (u"ࠪࠫ檮"),error,l1111l1ll1l1_l1_)
	#l111lll1l1l1_l1_ = l1111l1ll1l1_l1_.splitlines()
	#for line in reversed(l111lll1l1l1_l1_):
	#	if l11l1l_l1_ (u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹࠧ檯") in line or l11l1l_l1_ (u"ࠬࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱࠬ檰") in line: continue
	#	if l11l1l_l1_ (u"࠭ࡍࡰࡦࡨ࠾ࠥࡡࠧ檱") not in line: continue
	l1l1lll11l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭檲"),l1111l1ll1l1_l1_,re.DOTALL)
	for typ,source in reversed(l1l1lll11l11_l1_):
		#if l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࠪ檳") in source: continue
		#if l11l1l_l1_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࠬ檴") in source: continue
		if source: break
	else: source = l11l1l_l1_ (u"ࠪࡒࡔ࡚ࠠࡔࡒࡈࡇࡎࡌࡉࡆࡆࠪ檵")
	#l11l1llll1_l1_(l11l1l_l1_ (u"ࠫࠬ檶"),source,str(l1l1lll11l11_l1_))
	file,line,func = l11l1l_l1_ (u"ࠬ࠭檷"),l11l1l_l1_ (u"࠭ࠧ檸"),l11l1l_l1_ (u"ࠧࠨ檹")
	l1llllll1l11_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ษ็า฼ษ࠺ࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ檺")+error
	l1l1ll1l1ll1_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊฻ฯา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭檻")+source
	for l1lllll111l1l_l1_ in reversed(lines):
		if l11l1l_l1_ (u"ࠪࡊ࡮ࡲࡥࠡࠤࠪ檼") in l1lllll111l1l_l1_ and l11l1l_l1_ (u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ檽") in l1lllll111l1l_l1_: break
	l1lllll111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ檾"),l1lllll111l1l_l1_,re.DOTALL)
	if l1lllll111l1l_l1_:
		file,line,func = l1lllll111l1l_l1_[0]
		if l11l1l_l1_ (u"࠭࠯ࠨ檿") in file: file = file.rsplit(l11l1l_l1_ (u"ࠧ࠰ࠩ櫀"),1)[1]
		else: file = file.rsplit(l11l1l_l1_ (u"ࠨ࡞࡟ࠫ櫁"),1)[1]
		l1lll11111l11_l1_ = l11l1l_l1_ (u"ࠩ࡞ࡖ࡙ࡒ࡝࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ส่๊๊แ࠻ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ櫂")+file
		line2 = l11l1l_l1_ (u"ࠪ࡟ࡗ࡚ࡌ࡞࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠหู้ืา࠼ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭櫃")+line
		l11l11111111_l1_ = l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡฬ๊ๅไษ้࠾࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ櫄")+func
		l1111l1lll1l_l1_ = l1lll11111l11_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ櫅")+line2+l11l1l_l1_ (u"࠭࡜࡯ࠩ櫆")+l11l11111111_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ櫇")+l1l1ll1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ櫈")+l1llllll1l11_l1_
		l1llll11lll1l_l1_ = line2+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ櫉")+l1l1ll1l1ll1_l1_+l11l1l_l1_ (u"ࠪࡠࡳ࠭櫊")+l1llllll1l11_l1_+l11l1l_l1_ (u"ࠫࡡࡴࠧ櫋")+l1lll11111l11_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ櫌")+l11l11111111_l1_
		l111lll111l1_l1_ = line2+l11l1l_l1_ (u"࠭࡜࡯ࠩ櫍")+l1llllll1l11_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ櫎")+l1lll11111l11_l1_+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ櫏")+l11l11111111_l1_
	else:
		l1lll11111l11_l1_,line2,l11l11111111_l1_ = l11l1l_l1_ (u"ࠩࠪ櫐"),l11l1l_l1_ (u"ࠪࠫ櫑"),l11l1l_l1_ (u"ࠫࠬ櫒")
		l1111l1lll1l_l1_ = l1l1ll1l1ll1_l1_+l11l1l_l1_ (u"ࠬࡢ࡮࡝ࡰࠪ櫓")+l1llllll1l11_l1_
		l1llll11lll1l_l1_ = l1l1ll1l1ll1_l1_+l11l1l_l1_ (u"࠭࡜࡯࡞ࡱࠫ櫔")+l1llllll1l11_l1_
		l111lll111l1_l1_ = l1llllll1l11_l1_
	#l1llll1l_l1_(file+line+func,error,l11l1l_l1_ (u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡴࡸࡱ࡫ࡥࡱ࡬ࡳࠨ櫕"),time=2000)
	l111l11lll11_l1_ = l11l1l_l1_ (u"ࠨฯาฯࠥิืฤࠢ฽๎ึࠦๅใื๋ำࠬ櫖")+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ櫗")
	addons = l1111llll1l1_l1_()
	l1lllll1ll111_l1_ = []
	results = addons[l11l1l_l1_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ櫘")]
	l1lllll1111l1_l1_ = l1ll1ll1lll11_l1_(addon_version)
	if l11l1l_l1_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ櫙") in list(addons.keys()):
		for l1lll1l1l1lll_l1_,l11111ll11ll_l1_,l111ll1l111l_l1_ in results: l1lllll1ll111_l1_ = max(l1lllll1ll111_l1_,l11111ll11ll_l1_)
		if l1lllll1111l1_l1_<l1lllll1ll111_l1_:
			header = l11l1l_l1_ (u"่ࠬๅࠡสอัิ๐หࠡษ็ฬึ์วๆฮࠣๆอ๊ࠠฦำึห้ࠦวๅลั฻ฬวࠠๅๆ่ฬึ๋ฬࠨ櫚")
			choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ櫛"),l11l1l_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ櫜"),l11l1l_l1_ (u"ࠨฬะำ๏ัࠧ櫝"),l11l1l_l1_ (u"ࠩัีําࠧ櫞"),l111l11lll11_l1_+header,l1111l1lll1l_l1_)
			if choice==0:
				l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ櫟"),l11l1l_l1_ (u"ࠫำื่อࠩ櫠"),l11l1l_l1_ (u"ࠬะอะ์ฮࠫ櫡"),l11l1l_l1_ (u"࠭ࠧ櫢"),header)
				if l1ll111111_l1_==1: choice = 1
			if choice==1:
				import l1l1l1ll1l1l_l1_
				l1l1l1ll1l1l_l1_.l1l1111l1ll1_l1_()
			return
	l1ll1ll1l11l1_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ櫣"),l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ櫤"),l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ櫥"))
	if not l1ll1ll1l11l1_l1_: l1ll1ll1l11l1_l1_ = []
	l1llll11lll1l_l1_ = l1llll11lll1l_l1_.replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭櫦"),l11l1l_l1_ (u"ࠫࡡࡢ࡮ࠨ櫧")).replace(l11l1l_l1_ (u"ࠬࡡࡒࡕࡎࡠࠫ櫨"),l11l1l_l1_ (u"࠭ࠧ櫩")).replace(l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ櫪"),l11l1l_l1_ (u"ࠨࠩ櫫")).replace(l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ櫬"),l11l1l_l1_ (u"ࠪࠫ櫭"))
	l111lll111l1_l1_ = l111lll111l1_l1_.replace(l11l1l_l1_ (u"ࠫࡡࡴࠧ櫮"),l11l1l_l1_ (u"ࠬࡢ࡜࡯ࠩ櫯")).replace(l11l1l_l1_ (u"࡛࠭ࡓࡖࡏࡡࠬ櫰"),l11l1l_l1_ (u"ࠧࠨ櫱")).replace(l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ櫲"),l11l1l_l1_ (u"ࠩࠪ櫳")).replace(l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ櫴"),l11l1l_l1_ (u"ࠫࠬ櫵"))
	l1ll1lll11l11_l1_ = addon_version+l11l1l_l1_ (u"ࠬࡀ࠺ࠨ櫶")+l111lll111l1_l1_
	if l1ll1lll11l11_l1_ in l1ll1ll1l11l1_l1_:
		header = l11l1l_l1_ (u"࠭ไใัࠣๆ๊ะࠠศ่อࠤุอศใษࠣฬสืำศๆ๋ࠣีอࠠศๆั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠫ櫷")
		#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹ࠭櫸"),l11l1l_l1_ (u"ࠨะิ์ั࠭櫹"),l11l1l_l1_ (u"ࠩศีุอไࠡว็ํࠥอไๆสิ้ั࠭櫺"),l111l11lll11_l1_+header,l1111l1lll1l_l1_)
		#if l1ll111111_l1_==1: DIALOG_OK(l11l1l_l1_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ櫻"),l11l1l_l1_ (u"ࠫำื่อࠩ櫼"),l11l1l_l1_ (u"ࠬ࠭櫽"),header)
		DIALOG_OK(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ櫾"),l11l1l_l1_ (u"ࠧࠨ櫿"),l111l11lll11_l1_+header,l1111l1lll1l_l1_)
		return
	l1ll1lll1ll11_l1_ = str(kodi_version).split(l11l1l_l1_ (u"ࠨ࠰ࠪ欀"))[0]
	#l111lll11l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ欁"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭欂"),l11l1l_l1_ (u"ࠫࡆࡒࡌࡠࡍࡑࡓ࡜ࡔ࡟ࡆࡔࡕࡓࡗ࡙ࠧ欃"))
	url = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ欄")][6]
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ欅"),url,l11l1l_l1_ (u"ࠧࠨ欆"),l11l1l_l1_ (u"ࠨࠩ欇"),l11l1l_l1_ (u"ࠩࠪ欈"),l11l1l_l1_ (u"ࠪࠫ欉"),l11l1l_l1_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕ࠰࠵ࡸࡺࠧ權"),False,False)
	html = response.content
	l111lll11l1l_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠬࡔࡂࡔࡗ࠾࠿࡙ࡔࡂࡔࡗ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮࠾࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࡉࡓࡊ࠺࠻ࡇࡑࡈࠬ欋"),html,re.DOTALL)
	#WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ欌"),l11l1l_l1_ (u"ࠧࡂࡎࡏࡣࡐࡔࡏࡘࡐࡢࡉࡗࡘࡏࡓࡕࠪ欍"),l111lll11l1l_l1_,REGULAR_CACHE)
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ欎"),line+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭欏")+error+l11l1l_l1_ (u"ࠪࠤࠥࠦࠧ欐")+addon_version+l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ欑")+l1ll1lll1ll11_l1_)
	for l111l11ll1l1_l1_,l111ll11llll_l1_,l1111111llll_l1_,l1llll11lll11_l1_ in l111lll11l1l_l1_:
		l111l11ll1l1_l1_ = l111l11ll1l1_l1_.split(l11l1l_l1_ (u"ࠬ࠱ࠧ欒"))
		l1111111llll_l1_ = l1111111llll_l1_.split(l11l1l_l1_ (u"࠭ࠫࠨ欓"))
		l1llll11lll11_l1_ = l1llll11lll11_l1_.split(l11l1l_l1_ (u"ࠧࠬࠩ欔"))
		#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ欕"),str(l111l11ll1l1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭欖")+l111ll11llll_l1_+l11l1l_l1_ (u"ࠪࠤࠥࠦࠧ欗")+str(l1111111llll_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ欘")+str(l1llll11lll11_l1_))
		if line in l111l11ll1l1_l1_ and error==l111ll11llll_l1_ and addon_version in l1111111llll_l1_ and l1ll1lll1ll11_l1_ in l1llll11lll11_l1_:
			header = l11l1l_l1_ (u"ࠬํะศࠢส่ำ฽รࠡ็฼ีํ็้ࠠีํ฽ฬ๊ฬࠡสส่ส฻ฯศำࠣห้่วะ็ࠪ欙")
			l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ欚"),l11l1l_l1_ (u"ࠧฯำ๋ะࠬ欛"),l11l1l_l1_ (u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ欜"),l111l11lll11_l1_+header,l1111l1lll1l_l1_)
			if l1ll111111_l1_==1: DIALOG_OK(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ欝"),l11l1l_l1_ (u"ࠪࠫ欞"),l11l1l_l1_ (u"ࠫࠬ欟"),header)
			return
	header = l11l1l_l1_ (u"ࠬอไาฮสลࠥหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ欠")
	DIALOG_OK(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ次"),l11l1l_l1_ (u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫ欢"),l111l11lll11_l1_+header,l1111l1lll1l_l1_)
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ欣"),l11l1l_l1_ (u"ࠩๆ่ฬ࠭欤"),l11l1l_l1_ (u"๊ࠪ฾๋ࠧ欥"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ欦"),l11l1l_l1_ (u"ู่ࠬโࠢํฮ๊ࠦลาีสู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะ๊ࠥใ๋ࠢํ฽ึ็ࠠศๆ่ฬึ๋ฬࠡลํ๊ࠥ๎ๅห๋ࠣ์่๐แ๊ࠡ็้ฬึวࠡฯุ่ฯࠦ็ั้ࠣห้๋ิไๆฬࠤ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦวึๆสั๋ࠥิไๆฬࠤํํ่ࠡๆสࠤ๏฿ัโࠢๆ๎ๆุ่ࠦำอࠤํ๊ๅศาสࠤ฽ํัห๋้ࠢฯ๏ู้ࠠิฮࠥํะ่ࠢสฺ่๊ใๅหࠣ࠲ࠥํไࠡฬิ๎ิࠦราีส่ࠥอไิฮ็ࠤฤ࠭欧"))
	if l1ll111111_l1_==1: l1l1l11lll1l_l1_ = l11l1l_l1_ (u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ欨")
	else:
		DIALOG_OK(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ欩"),l11l1l_l1_ (u"ࠨࠩ欪"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ欫"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࡠ࠵ࡃࡐࡎࡒࡖࡢࡢ࡮ๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢศู้ออࠡษ็า฼ษࠠษัู๋๊ࠥฬๅࠢส่ศิืศรࠣห้ึ๊ࠡ็ๆฮํฮࠠโ์๊ࠤัฺ๋๊ࠢอๅฬ฻๊ๅ๊ࠢิฬࠦวๅะฺวࠥ๎ฺ๋ำ๊ࠤ๊์ࠠศๆฦา฼อมࠨ欬"))
		return
	message = l1llll11lll1l_l1_
	l1ll11l1lll1_l1_ = l11l1l_l1_ (u"ࠫࡆ࡜࠺ࠡࠩ欭")+l1l11ll1lll_l1_(32)+l11l1l_l1_ (u"ࠬ࠳ࡅࡳࡴࡲࡶࡸ࠭欮")
	import l1l1l1ll1l1l_l1_
	succeeded = l1l1l1ll1l1l_l1_.l1llll1l1l11_l1_(l1ll11l1lll1_l1_,message,True,l11l1l_l1_ (u"࠭ࠧ欯"),l11l1l_l1_ (u"ࠧࡆࡏࡄࡍࡑ࠳ࡆࡓࡑࡐ࠱ࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔࠩ欰"),l1l1l11lll1l_l1_)
	if succeeded and l1l1l11lll1l_l1_:
		l1ll1ll1l11l1_l1_.append(l1ll1lll11l11_l1_)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ欱"),l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖࠫ欲"),l1ll1ll1l11l1_l1_,PERMANENT_CACHE)
	return
def l11lll1lll11_l1_(l1lllllll1111_l1_):
	l111l1l11ll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ欳"))
	#l1lllllll1111_l1_ = l1lllllll1111_l1_.encode(l11l1l_l1_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ欴")).replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ欵"),l11l1l_l1_ (u"࠭ࠧ欶"))
	user = l1l11ll1lll_l1_(32)
	import hashlib
	md5 = hashlib.md5((l11l1l_l1_ (u"࡙ࠧ࠳࠼ࠫ欷")+l1lllllll1111_l1_+l11l1l_l1_ (u"ࠨ࠳࠻ࡁࠬ欸")+user).encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ欹"))).hexdigest()[0:32]
	if md5 in l111l1l11ll1_l1_: return True
	return False
def WRITE_THIS(l111lll111_l1_,data):
	if kodi_version>18.99: data = data.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ欺"))
	if l111lll111_l1_==l11l1l_l1_ (u"ࠫࠬ欻"): filename = l11l1l_l1_ (u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲ࡩࡧࡴࠨ欼")
	else: filename = l11l1l_l1_ (u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭欽")+str(now)+l11l1l_l1_ (u"ࠧ࠯ࡦࡤࡸࠬ款")
	open(filename,l11l1l_l1_ (u"ࠨࡹࡥࠫ欿")).write(data)
	return
def l1l11l11l1l1_l1_():
	l1l111lll1ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ歀"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭歁"),l11l1l_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ歂"))
	if l1l111lll1ll_l1_: return l1l111lll1ll_l1_
	url = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ歃")][5]
	l1lll111ll1l1_l1_ = l1l11ll1lll_l1_(32)
	l11llll1l111_l1_ = l11ll11ll111_l1_()
	l11lll1l1ll_l1_ = l11llll1l111_l1_.split(l11l1l_l1_ (u"࠭ࠬࠨ歄"))[2]
	l1llll11111ll_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭歅"))
	l111l11111l1_l1_ = 0
	if os.path.exists(l1llll11111ll_l1_):
		for l1l111ll11_l1_ in os.listdir(l1llll11111ll_l1_):
			l1l111l1l1_l1_ = os.path.join(l1llll11111ll_l1_,l1l111ll11_l1_)
			if os.path.isfile(l1l111l1l1_l1_):
				size,count = l1l11llll1_l1_(l1l111l1l1_l1_)
				l111l11111l1_l1_ += size
	payload = {l11l1l_l1_ (u"ࠨࡷࡶࡩࡷ࠭歆"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ歇"):addon_version,l11l1l_l1_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ歈"):l11lll1l1ll_l1_,l11l1l_l1_ (u"ࠫ࡮ࡪࡳࠨ歉"):l1lll1lllll1l_l1_(l111l11111l1_l1_)}
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ歊"),url,payload,l11l1l_l1_ (u"࠭ࠧ歋"),l11l1l_l1_ (u"ࠧࠨ歌"),l11l1l_l1_ (u"ࠨࠩ歍"),l11l1l_l1_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧ歎"))
	if not response.succeeded: return []
	html = response.content
	l1l111lll1ll_l1_ = html.replace(l11l1l_l1_ (u"ࠪࡠࡡࡸࠧ歏"),l11l1l_l1_ (u"ࠫࡡࡴࠧ歐")).replace(l11l1l_l1_ (u"ࠬࡢ࡜࡯ࠩ歑"),l11l1l_l1_ (u"࠭࡜࡯ࠩ歒")).replace(l11l1l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ歓"),l11l1l_l1_ (u"ࠨ࡞ࡱࠫ歔")).replace(l11l1l_l1_ (u"ࠩ࡟ࡶࠬ歕"),l11l1l_l1_ (u"ࠪࡠࡳ࠭歖"))
	l1l111lll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࠽࠾࠭ࡢࡤࠬࠫ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲ࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡋࡎࡅ࠼࠽ࡉࡓࡊࠧ歗"),l1l111lll1ll_l1_,re.DOTALL)
	if not l1l111lll1ll_l1_: return []
	l1l111lll1ll_l1_ = sorted(l1l111lll1ll_l1_,reverse=False,key=lambda key: int(key[0]))
	id,l1l1111l1111_l1_,l1l11ll1lll1_l1_,l11l1ll11l1_l1_,l11ll11llll1_l1_,reason = l1l111lll1ll_l1_[0]
	#if l11l1l_l1_ (u"ࠬࡢ࡮࠼࠽ࠪ歘") in reason: l1llll111l11l_l1_,l1llll111l1l1_l1_,l1llll111l1ll_l1_ = reason.split(l11l1l_l1_ (u"࠭࡜࡯࠽࠾ࠫ歙"),2)
	#else: l1llll111l11l_l1_,l1llll111l1l1_l1_,l1llll111l1ll_l1_ = reason,reason,reason
	l1llll11llll1_l1_ = reason if l11lll1lll11_l1_(l11l1l_l1_ (u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭歚")) else l1l11ll1lll1_l1_
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲࡮ࡴࡦࡰࡵ࠱ࡴࡪࡸࡩࡰࡦࠪ歛"),l1llll11llll1_l1_)
	settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ歜"),l1lll1lllll1l_l1_(now))
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭歝"),l11l1l_l1_ (u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ歞"),l1l111lll1ll_l1_,REGULAR_CACHE)
	return l1l111lll1ll_l1_
def SPLIT_BIGLIST(items,l11ll1l1111_l1_=0,l1llllll1l11l_l1_=0):
	if l11ll1l1111_l1_ and not l1llllll1l11l_l1_: l1llllll1l11l_l1_ = len(items)//l11ll1l1111_l1_
	l1ll111111ll_l1_,l11l1l1ll1_l1_,l11llll11l1_l1_ = [],-1,0
	for item in items:
		if l11llll11l1_l1_%l1llllll1l11l_l1_==0:
			l11l1l1ll1_l1_ += 1
			l1ll111111ll_l1_.append([])
		l1ll111111ll_l1_[l11l1l1ll1_l1_].append(item)
		l11llll11l1_l1_ += 1
	return l1ll111111ll_l1_
	l11l1l_l1_ (u"ࠧࠨࠢࠎࠌࠌࡰࡪࡴࡧࡵࡪࠣࡁࠥࡲࡥ࡯ࠪࡥ࡭࡬ࡲࡩࡴࡶࠬࠑࠏࠏࡳࡱ࡮࡬ࡸࡹ࡫ࡤࠡ࠿ࠣ࡟ࡢࠓࠊࠊࡨࡲࡶࠥ࡯ࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫ࠵࠱ࡹࡰ࡭࡫ࡷࡷࡤࡩ࡯ࡶࡰࡷ࠯࠶࠯࠺ࠎࠌࠌࠍ࡮࡬ࠠࡪ࡫ࠤࡁࡸࡶ࡬ࡪࡶࡶࡣࡨࡵࡵ࡯ࡶ࠽ࠑࠏࠏࠉࠊ࡮࡬ࡲࡪࡹ࠰ࠡ࠿ࠣࡦ࡮࡭࡬ࡪࡵࡷ࡟࠵ࡀࡩ࡯ࡶࠫࡰࡪࡴࡧࡵࡪ࠲ࡷࡵࡲࡩࡵࡵࡢࡧࡴࡻ࡮ࡵࠫࡠࠑࠏࠏࠉࠊࡦࡨࡰࠥࡨࡩࡨ࡮࡬ࡷࡹࡡ࠰࠻࡫ࡱࡸ࠭ࡲࡥ࡯ࡩࡷ࡬࠴ࡹࡰ࡭࡫ࡷࡷࡤࡩ࡯ࡶࡰࡷ࠭ࡢࠏࠍࠋࠋࠌࡩࡱࡹࡥ࠻ࠏࠍࠍࠎࠏ࡬ࡪࡰࡨࡷ࠵ࠦ࠽ࠡࡤ࡬࡫ࡱ࡯ࡳࡵࠏࠍࠍࠎࠏࡤࡦ࡮ࠣࡦ࡮࡭࡬ࡪࡵࡷࠑࠏࠏࠉࡴࡲ࡯࡭ࡹࡺࡥࡥ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳ࡫ࡳ࠱ࠫࠐࠎࠎࠏࡤࡦ࡮ࠣࡰ࡮ࡴࡥࡴ࠲ࠐࠎࠎࡸࡥࡵࡷࡵࡲࠥࡹࡰ࡭࡫ࡷࡸࡪࠓࠊࠊࠤࠥࠦ歟")
def l1111lll11ll_l1_(filename,data):
	filepath = os.path.join(addoncachefolder,filename)
	#setattr(dummy,l11l1l_l1_ (u"࠭ࡤࡶ࡯ࡰࡽࡳࡧ࡭ࡦࠩ歠"),data)
	#text = pickle.dumps(dummy)
	if 1 or l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚ࡤ࠭歡") not in filename or l11l1l_l1_ (u"ࠨࡏ࠶࡙ࡤ࠭止") not in filename: text = str(data)
	else:
		l1ll111111ll_l1_ = SPLIT_BIGLIST(data,8)
		text = l11l1l_l1_ (u"ࠩࠪ正")
		for split in l1ll111111ll_l1_:
			text += str(split)+l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ此")
		text = text.strip(l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ步"))
	l111ll1l1l1l_l1_ = zlib.compress(text)
	open(filepath,l11l1l_l1_ (u"ࠬࡽࡢࠨ武")).write(l111ll1l1l1l_l1_)
	return
def l111ll1l1ll1_l1_(l1lll111ll11l_l1_,filename):
	if l1lll111ll11l_l1_==l11l1l_l1_ (u"࠭ࡤࡪࡥࡷࠫ歧"): data = {}
	elif l1lll111ll11l_l1_==l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ歨"): data = []
	elif l1lll111ll11l_l1_==l11l1l_l1_ (u"ࠨࡵࡷࡶࠬ歩"): data = l11l1l_l1_ (u"ࠩࠪ歪")
	elif l1lll111ll11l_l1_==l11l1l_l1_ (u"ࠪ࡭ࡳࡺࠧ歫"): data = 0
	else: data = None
	filepath = os.path.join(addoncachefolder,filename)
	l111ll1l1l1l_l1_ = open(filepath,l11l1l_l1_ (u"ࠫࡷࡨࠧ歬")).read()
	text = zlib.decompress(l111ll1l1l1l_l1_)
	#open(l11l1l_l1_ (u"ࠬࡹ࠺࡝࡞ࡌࡔ࡙࡜࠱࠯ࡶࡻࡸࠬ歭"),l11l1l_l1_ (u"࠭ࡷࡣࠩ歮")).write(text)
	#dummy = pickle.loads(text)
	#data = getattr(dummy,l11l1l_l1_ (u"ࠧࡥࡷࡰࡱࡾࡴࡡ࡮ࡧࠪ歯"))
	#if l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ歰") not in text: data = EVAL(l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭歱"),text)
	if l11l1l_l1_ (u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩ歲") not in text: data = eval(text)
	else:
		l1ll111111ll_l1_ = text.split(l11l1l_l1_ (u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ歳"))
		del text
		data = []
		l111l1l1l1ll_l1_ = l1llll111l1l_l1_()
		id = 0
		for split in l1ll111111ll_l1_:
			#data += EVAL(l11l1l_l1_ (u"ࠬࡹࡴࡳࠩ歴"),split)
			l111l1l1l1ll_l1_.l111l11l1111_l1_(str(id),eval,split)
			id += 1
		del l1ll111111ll_l1_
		l111l1l1l1ll_l1_.l1lll1lll1ll1_l1_()
		l111l1l1l1ll_l1_.l1ll1lll1111l_l1_()
		l1ll1lllll11l_l1_ = list(l111l1l1l1ll_l1_.l1llllll1l1l1_l1_.keys())
		l1lll11l11l11_l1_ = sorted(l1ll1lllll11l_l1_,reverse=False,key=lambda key: int(key))
		for id in l1lll11l11l11_l1_:
			data += l111l1l1l1ll_l1_.l1llllll1l1l1_l1_[id]
	return data
def l1llll1ll111l_l1_(addon_id):
	l111ll111ll1_l1_ = os.path.join(l1l11l1lll_l1_,l11l1l_l1_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭歵"),addon_id,l11l1l_l1_ (u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ歶"))
	try: l1lllllll1ll1_l1_ = open(l111ll111ll1_l1_,l11l1l_l1_ (u"ࠨࡴࡥࠫ歷")).read()
	except:
		l1llll1l1l11l_l1_ = os.path.join(l111111llll1_l1_,l11l1l_l1_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩ歸"),addon_id,l11l1l_l1_ (u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭歹"))
		try: l1lllllll1ll1_l1_ = open(l1llll1l1l11l_l1_,l11l1l_l1_ (u"ࠫࡷࡨࠧ歺")).read()
		except: return l11l1l_l1_ (u"ࠬ࠭死"),[]
	if kodi_version>18.99: l1lllllll1ll1_l1_ = l1lllllll1ll1_l1_.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ歼"))
	version = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀ࠲࠯ࡅࡶࡦࡴࡶ࡭ࡴࡴ࠽࡜࡞ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠢ࡝ࠩࡠࠫ歽"),l1lllllll1ll1_l1_,re.DOTALL|re.IGNORECASE)
	if not version: return l11l1l_l1_ (u"ࠨࠩ歾"),[]
	l11l1111l1l1_l1_,l111l111ll1l_l1_ = version[0],l1ll1ll1lll11_l1_(version[0])
	return l11l1111l1l1_l1_,l111l111ll1l_l1_
def l1111llll1l1_l1_():
	l1111l11l11l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡧ࡭ࡨࡺࠧ歿"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭殀"),l11l1l_l1_ (u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ殁"))
	if l1111l11l11l_l1_: return l1111l11l11l_l1_
	addons,l1111l11l11l_l1_ = {},{}
	l1l1lll11l11_l1_ = [l1l1l1l_l1_[l11l1l_l1_ (u"ࠬࡘࡅࡑࡑࡖࠫ殂")][0]]
	if kodi_version>17.99: l1l1lll11l11_l1_.append(l1l1l1l_l1_[l11l1l_l1_ (u"࠭ࡒࡆࡒࡒࡗࠬ殃")][1])
	if kodi_version>18.99: l1l1lll11l11_l1_.append(l1l1l1l_l1_[l11l1l_l1_ (u"ࠧࡓࡇࡓࡓࡘ࠭殄")][2])
	for l1lll11ll111l_l1_ in l1l1lll11l11_l1_:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ殅"),l1lll11ll111l_l1_,l11l1l_l1_ (u"ࠩࠪ殆"),l11l1l_l1_ (u"ࠪࠫ殇"),l11l1l_l1_ (u"ࠫࠬ殈"),l11l1l_l1_ (u"ࠬ࠭殉"),l11l1l_l1_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪ殊"))
		if response.succeeded:
			html = response.content
			l1ll1lll1l1l1_l1_ = l1lll11ll111l_l1_.rsplit(l11l1l_l1_ (u"ࠧ࠰ࠩ残"),1)[0]
			l1111l11l1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ殌"),html,re.DOTALL|re.IGNORECASE)
			for addon_id,l1111ll1lll1_l1_ in l1111l11l1ll_l1_:
				l111l111lll1_l1_ = l1ll1lll1l1l1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ殍")+addon_id+l11l1l_l1_ (u"ࠪ࠳ࠬ殎")+addon_id+l11l1l_l1_ (u"ࠫ࠲࠭殏")+l1111ll1lll1_l1_+l11l1l_l1_ (u"ࠬ࠴ࡺࡪࡲࠪ殐")
				if addon_id not in list(addons.keys()):
					addons[addon_id] = []
					l1111l11l11l_l1_[addon_id] = []
				l1llll1ll11ll_l1_ = l1ll1ll1lll11_l1_(l1111ll1lll1_l1_)
				addons[addon_id].append((l1111ll1lll1_l1_,l1llll1ll11ll_l1_,l111l111lll1_l1_))
	for addon_id in list(addons.keys()):
		#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ殑"),str(addon_id)+l11l1l_l1_ (u"ࠧࠡࠢ࠱ࠤࠥ࠭殒")+str(addons[addon_id]))
		l1111l11l11l_l1_[addon_id] = sorted(addons[addon_id],reverse=True,key=lambda key: key[1])
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ殓"),l11l1l_l1_ (u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ殔"),l1111l11l11l_l1_,REGULAR_CACHE)
	return l1111l11l11l_l1_
	l11l1l_l1_ (u"ࠥࠦࠧࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ࠮ࠓࠊࠊࡵࡲࡹࡷࡩࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧࠪࠏࠍࠍࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠭ࠬࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡪࡸࡦࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡧࡴࡪࡥࡣࡧࡵ࡫ࠬ࠲ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡲࡨࡪࡨࡥࡳࡩ࠱ࡳࡷ࡭࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡨࡲࡢࡰࡦ࡬࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࡴࡱࡸࡶࡨ࡫ࡳ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫ࠱࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷࡩࡦ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰ࡤࡵࡥࡳࡩࡨ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ࠮ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠴ࡑࡏࡅࡋ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧ࡞ࠫࠐࠎࠎࡹ࡯ࡶࡴࡦࡩࡸ࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡳࡹ࡮ࡥࡳࡵࠪ࠰ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧࡪࡶ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠵ࡋࡐࡆࡌ࠳ࡷࡧࡷ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬࡣࠩࠎࠌࠌࡷࡴࡻࡲࡤࡧࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧ࠭ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡥࡦ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠲࠰ࡴࡤࡻ࠴ࡳࡡࡴࡶࡨࡶ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩࡠ࠭ࠒࠐࠉࠣࠤࠥ殕")
def l1ll1ll1lll11_l1_(l1111ll1lll1_l1_):
	l1llll1ll11ll_l1_ = []
	l1ll11ll1l1_l1_ = l1111ll1lll1_l1_.split(l11l1l_l1_ (u"ࠫ࠳࠭殖"))
	for l11lllll11_l1_ in l1ll11ll1l1_l1_:
		parts = re.findall(l11l1l_l1_ (u"ࠬࡢࡤࠬࡾ࡞ࡠ࠰ࡢ࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠩ殗"),l11lllll11_l1_,re.DOTALL)
		l11ll1111l11_l1_ = []
		for part in parts:
			if part.isdigit(): part = int(part)
			l11ll1111l11_l1_.append(part)
		l1llll1ll11ll_l1_.append(l11ll1111l11_l1_)
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧ殘"),str(l1111ll1lll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢ࠱ࠤࠥ࠭殙")+str(l1llll1ll11ll_l1_))
	return l1llll1ll11ll_l1_
def l1llll11l1l1l_l1_(l1llll1ll11ll_l1_):
	l1111ll1lll1_l1_ = l11l1l_l1_ (u"ࠨࠩ殚")
	for l11lllll11_l1_ in l1llll1ll11ll_l1_:
		for part in l11lllll11_l1_: l1111ll1lll1_l1_ += str(part)
		l1111ll1lll1_l1_ += l11l1l_l1_ (u"ࠩ࠱ࠫ殛")
	l1111ll1lll1_l1_ = l1111ll1lll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠲ࠬ殜"))
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ殝"),str(l1llll1ll11ll_l1_)+l11l1l_l1_ (u"ࠬࠦࠠ࠯ࠢࠣࠫ殞")+str(l1111ll1lll1_l1_))
	return l1111ll1lll1_l1_
def l11llllllll1_l1_(l111ll1l11ll_l1_=l1l111ll11ll_l1_):
	# l1lll1l1111l1_l1_ not l111l1llll1l_l1_ l1lll1lll1l11_l1_ l1lll11l11ll1_l1_ addons status l1lllll111l_l1_ l111lll1l1_l1_ l111l111ll_l1_ l111l1111l11_l1_
	#l1l1l1l111ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡤࡪࡥࡷࠫ殟"),l11l1l_l1_ (u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪ殠"),l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࡥࡁࡅࡆࡒࡒࡘࡥࡄࡆࡖࡄࡍࡑ࡙ࠧ殡"))
	#if l1l1l1l111ll_l1_: return l1l1l1l111ll_l1_
	l1l1l1l111ll_l1_ = {}
	addons = l1111llll1l1_l1_()
	l1l111llll11_l1_ = l11lll111l11_l1_(l111ll1l11ll_l1_)
	for addon_id in l111ll1l11ll_l1_:
		if addon_id not in list(addons.keys()): continue
		#if not addons[addon_id]: continue
		l1111l11l11l_l1_ = addons[addon_id]
		l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l11ll111ll1l_l1_ = l1111l11l11l_l1_[0]
		#l1l111111lll_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡄࡨࡩࡵ࡮ࡗࡧࡵࡷ࡮ࡵ࡮ࠩࠩ殢")+addon_id+l11l1l_l1_ (u"ࠪ࠭ࠬ殣"))
		l1l111111lll_l1_,l1l11l1llll1_l1_ = l1llll1ll111l_l1_(addon_id)
		l1l111ll1lll_l1_,l1l11l1ll11l_l1_ = l1l111llll11_l1_[addon_id]
		l111llll1l1l_l1_ = l1l11ll1ll1l_l1_>l1l11l1llll1_l1_ and l1l111ll1lll_l1_
		l11l11l1l1l_l1_ = True
		if not l1l111ll1lll_l1_: l1l111l1l1l1_l1_ = l11l1l_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ殤")
		elif not l1l11l1ll11l_l1_: l1l111l1l1l1_l1_ = l11l1l_l1_ (u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧ殥")
		elif l111llll1l1l_l1_: l1l111l1l1l1_l1_ = l11l1l_l1_ (u"࠭࡯࡭ࡦࠪ殦")
		else:
			l1l111l1l1l1_l1_ = l11l1l_l1_ (u"ࠧࡨࡱࡲࡨࠬ殧")
			l11l11l1l1l_l1_ = False
		l1l1l1l111ll_l1_[addon_id] = (l11l11l1l1l_l1_,l1l111111lll_l1_,l1l11l1llll1_l1_,l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l1l111l1l1l1_l1_,l11ll111ll1l_l1_)
	#WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ殨"),l11l1l_l1_ (u"ࠩࡈࡑࡆࡊ࡟ࡂࡆࡇࡓࡓ࡙࡟ࡅࡇࡗࡅࡎࡒࡓࠨ殩"),l1l1l1l111ll_l1_,REGULAR_CACHE)
	return l1l1l1l111ll_l1_
	l11l1l_l1_ (u"ࠥࠦࠧࠓࠊࠊࠥ࡬ࡪࠥࡼࡥࡳࡵ࡬ࡳࡳࡀࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࡢࡺࡪࡸࠬࡪࡵࡢࡩࡽ࡯ࡳࡵ࠮࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡ࠿ࠣࡺࡪࡸࡳࡪࡱࡱ࠰࡙ࡸࡵࡦ࠮ࡗࡶࡺ࡫ࠍࠋࠋࠦࡩࡱࡹࡥ࠻ࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࡤࡼࡥࡳ࠮࡬ࡷࡤ࡫ࡸࡪࡵࡷ࠰࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡁࠥ࠭ࠧ࠭ࡈࡤࡰࡸ࡫ࠬࡇࡣ࡯ࡷࡪࠓࠊࠊࠥ࡬ࡷࡤ࡫ࡸࡪࡵࡷࠤࡂࠦࠨࡹࡤࡰࡧ࠳࡭ࡥࡵࡅࡲࡲࡩ࡜ࡩࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠪࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭࠭ࠫࡢࡦࡧࡳࡳࡥࡩࡥ࠭ࠪ࠭ࠬ࠯࠽࠾࠳ࠬࠑࠏࠏࠣࡪࡵࡢ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦ࠽ࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡻ࡫ࡲ࠿ࠩࠪࠑࠏࠏࠣࡪࡨࠣ࡯ࡴࡪࡩࡠࡸࡨࡶࡸ࡯࡯࡯ࡀ࠴࠼࠳࠿࠹࠻ࠢ࡬ࡷࡤ࡫࡮ࡢࡤ࡯ࡩࡩࠦ࠽ࠡࠪࡻࡦࡲࡩ࠮ࡨࡧࡷࡇࡴࡴࡤࡗ࡫ࡶ࡭ࡧ࡯࡬ࡪࡶࡼ࡙ࠬࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱࡍࡸࡋ࡮ࡢࡤ࡯ࡩࡩ࠮ࠧࠬࡣࡧࡨࡴࡴ࡟ࡪࡦ࠮ࠫ࠮࠭ࠩ࠾࠿࠴࠭ࠒࠐࠉࠤࡧ࡯ࡷࡪࡀࠠࡪࡵࡢࡩࡳࡧࡢ࡭ࡧࡧࠤࡂࠦ࡮ࡰࡶࠣࠬ࡮ࡹ࡟ࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡥࡳࡪࠠ࡯ࡱࡷࠤ࡮ࡹ࡟ࡦࡺ࡬ࡷࡹ࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡭࡯ࡧࡩࡧࡶࡸࡤࡧࡶࡢ࡫࡯ࡥࡧࡲࡥࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪࠏࠉࠨ࠭ࡶࡸࡷ࠮ࡨࡪࡩ࡫ࡩࡸࡺ࡟ࡢࡸࡤ࡭ࡱࡧࡢ࡭ࡧࡢࡺࡪࡸ࡟ࡤࡱࡰࡴࡦࡸࡥࠪࠫࠐࠎࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡷࡧࡵࡣࡨࡵ࡭ࡱࡣࡵࡩࠎࠏࠧࠬࡵࡷࡶ࠭࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶࡤࡩ࡯࡮ࡲࡤࡶࡪ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࡬ࡷࡤ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠩࠪࠏࠍࠍࡑࡕࡇࡠࡖࡋࡍࡘ࠮ࠧࠨ࠮ࠪ࡭ࡸࡥࡥ࡯ࡣࡥࡰࡪࡪࠉࠊࠋࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡴࡡࡣ࡮ࡨࡨ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡶࡣ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡰ࡮ࡧࠍࠬ࠱ࡳࡵࡴࠫ࡭ࡸࡥࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࡡࡲࡰࡩ࠯ࠩࠎࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩࡱࡩࡪࡪ࡟ࡶࡲࡧࡥࡹ࡫ࠉࠊࠩ࠮ࡷࡹࡸࠨ࡯ࡧࡨࡨࡤࡻࡰࡥࡣࡷࡩ࠮࠯ࠍࠋࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࡣࡸࡺࡡࡵࡷࡶࠍࠎ࠭ࠫࡴࡶࡵࠬ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪ࡟ࡴࡶࡤࡸࡺࡹࠩࠪࠏࠍࠍࠨࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࠩ࠯ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࡸࡀࠠࠡࠩ࠮ࡷࡹࡸࠨࡢࡦࡧࡳࡳࡥࡩࡥࠫ࠮ࠫࠥࠦࠧࠬࡵࡷࡶ࠭࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࡠࡸࡨࡶ࠮࠱ࠧࠡࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡶࡣࡪࡾࡩࡴࡶࠬ࠯ࠬࠦࠠࠨ࠭ࡶࡸࡷ࠮ࡩࡴࡡࡨࡲࡦࡨ࡬ࡦࡦࠬ࠭ࠒࠐࠉࠣࠤࠥ殪")
def PROGRESS_UPDATE(l11l11ll1l_l1_,l11111l1ll1l_l1_,l111l11ll11l_l1_=l11l1l_l1_ (u"ࠫࠬ殫"),line2=l11l1l_l1_ (u"ࠬ࠭殬"),l111l11ll1l1_l1_=l11l1l_l1_ (u"࠭ࠧ殭")):
	if kodi_version<19: l11l11ll1l_l1_.update(l11111l1ll1l_l1_,l111l11ll11l_l1_,line2,l111l11ll1l1_l1_)
	else: l11l11ll1l_l1_.update(l11111l1ll1l_l1_,l111l11ll11l_l1_+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ殮")+line2+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ殯")+l111l11ll1l1_l1_)
	return
def l1l1llllllll_l1_(l1ll11l1llll_l1_):
	# l111l1llll1l_l1_ it for this:  function(p,a,c,k,e,d)
	# l1l1ll1l1lll_l1_ l1lll1l1l1111_l1_:  https://l1lllll111l11_l1_.io
	def l1lllllll1l1l_l1_(num,b,l1lll1l1lllll_l1_=l11l1l_l1_ (u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛ࠤ殰")):
		return ((num == 0) and l1lll1l1lllll_l1_[0]) or (l1lllllll1l1l_l1_(num // b, b, l1lll1l1lllll_l1_).lstrip(l1lll1l1lllll_l1_[0]) + l1lll1l1lllll_l1_[num % b])
	def unpack(p, a, c, k, e=None, d=None):
		while (c):
			c-=1
			if (k[c]): p = re.sub(l11l1l_l1_ (u"ࠥࡠࡡࡨࠢ殱") + l1lllllll1l1l_l1_(c, a) + l11l1l_l1_ (u"ࠦࡡࡢࡢࠣ殲"),  k[c], p)
		return p
	l1ll11l1llll_l1_ = l1ll11l1llll_l1_.split(l11l1l_l1_ (u"ࠬࢃࠨࠨ殳"))[1][:-1]
	l1l1lll1lll1_l1_ = eval(l11l1l_l1_ (u"࠭ࡵ࡯ࡲࡤࡧࡰ࠮ࠧ殴")+l1ll11l1llll_l1_,{l11l1l_l1_ (u"ࠧࡣࡣࡶࡩࡓ࠭段"):l1lllllll1l1l_l1_,l11l1l_l1_ (u"ࠨࡷࡱࡴࡦࡩ࡫ࠨ殶"):unpack})   #,locals())
	return l1l1lll1lll1_l1_
def l1ll11lll1_l1_(url,l1llll1lll1l1_l1_=l11l1l_l1_ (u"ࠩࠪ殷")):
	if l1llll1lll1l1_l1_==l11l1l_l1_ (u"ࠪࡰࡴࡽࡥࡳࠩ殸"): url = re.sub(l11l1l_l1_ (u"ࡶ࡛ࠬࠫ࠱࠯࠼ࡅ࠲ࡠ࡝ࡼ࠴ࢀࠫ殹"),lambda l111llllll1l_l1_: l111llllll1l_l1_.group(0).lower(),url)
	elif l1llll1lll1l1_l1_==l11l1l_l1_ (u"ࠬࡻࡰࡱࡧࡵࠫ殺"): url = re.sub(l11l1l_l1_ (u"ࡸࠧࠦ࡝࠳࠱࠾ࡧ࠭ࡻ࡟ࡾ࠶ࢂ࠭殻"),lambda l111llllll1l_l1_: l111llllll1l_l1_.group(0).upper(),url)
	return url
def l11lll111l11_l1_(l111ll1l11ll_l1_):
	installed,l111111lllll_l1_ = False,False
	#import sqlite3
	conn = sqlite3.connect(l1l111ll1l1l_l1_)
	conn.text_factory = str
	cc = conn.cursor()
	if len(l111ll1l11ll_l1_)==1: l1lllll1lll11_l1_ = l11l1l_l1_ (u"ࠧࠩࠤࠪ殼")+l111ll1l11ll_l1_[0]+l11l1l_l1_ (u"ࠨࠤࠬࠫ殽")
	else: l1lllll1lll11_l1_ = str(tuple(l111ll1l11ll_l1_))
	cc.execute(l11l1l_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡩࡳࡧࡢ࡭ࡧࡧࠤࡋࡘࡏࡎࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡏࡎࠡࠩ殾")+l1lllll1lll11_l1_+l11l1l_l1_ (u"ࠪࠤࡀ࠭殿"))
	l11llll1l1ll_l1_ = cc.fetchall()
	l1l111llll11_l1_ = {}
	for addon_id in l111ll1l11ll_l1_: l1l111llll11_l1_[addon_id] = (False,False)
	for addon_id,l111111lllll_l1_ in l11llll1l1ll_l1_:
		installed = True
		l111111lllll_l1_ = l111111lllll_l1_==1
		l1l111llll11_l1_[addon_id] = (installed,l111111lllll_l1_)
	conn.close()
	return l1l111llll11_l1_
def FIX_AND_GET_FILE_CONTENTS(file):
	if file==l1l11ll111ll_l1_: results = []
	else: results = {}
	if os.path.exists(file):
		l11lll1l1ll1_l1_ = open(file,l11l1l_l1_ (u"ࠫࡷࡨࠧ毀")).read()
		if kodi_version>18.99: l11lll1l1ll1_l1_ = l11lll1l1ll1_l1_.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ毁"))
		if file==l1l11ll111ll_l1_: results = EVAL(l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫ毂"),l11lll1l1ll1_l1_)
		else:
			l11111lllll1_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ毃"),l11lll1l1ll1_l1_)
			if l11111lllll1_l1_:
				for key in l11111lllll1_l1_.keys():
					results[key] = []
					for l1111111111l_l1_ in l11111lllll1_l1_[key]:
						type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_ = l11l1l_l1_ (u"ࠨࠩ毄"),l11l1l_l1_ (u"ࠩࠪ毅"),l11l1l_l1_ (u"ࠪࠫ毆"),l11l1l_l1_ (u"ࠫࠬ毇"),l11l1l_l1_ (u"ࠬ࠭毈"),l11l1l_l1_ (u"࠭ࠧ毉"),l11l1l_l1_ (u"ࠧࠨ毊"),l11l1l_l1_ (u"ࠨࠩ毋"),l11l1l_l1_ (u"ࠩࠪ毌")
						type = l1111111111l_l1_[0]
						name = l1111111111l_l1_[1]
						name = RESTORE_PATH_NAME(name)
						url = l1111111111l_l1_[2]
						mode = l1111111111l_l1_[3]
						l111_l1_ = l1111111111l_l1_[4]
						l11lll1_l1_ = l1111111111l_l1_[5]
						if len(l1111111111l_l1_)>6: text = l1111111111l_l1_[6]
						if len(l1111111111l_l1_)>7: context = l1111111111l_l1_[7]
						if len(l1111111111l_l1_)>8: l1ll1l1l1l1_l1_ = l1111111111l_l1_[8]
						if file==favoritesfile: l1ll1llll11ll_l1_ = type,name,url,mode,l111_l1_,l11lll1_l1_,text,l11l1l_l1_ (u"ࠪࠫ母"),l1ll1l1l1l1_l1_
						else: l1ll1llll11ll_l1_ = type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_
						results[key].append(l1ll1llll11ll_l1_)
		l11ll1ll1l1l_l1_ = str(results)
		if kodi_version>18.99: l11ll1ll1l1l_l1_ = l11ll1ll1l1l_l1_.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ毎"))
		open(file,l11l1l_l1_ (u"ࠬࡽࡢࠨ每")).write(l11ll1ll1l1l_l1_)
	return results
def l1l1lll111l_l1_(l1l1llllll1_l1_):
	l1l1lll1ll1_l1_ = l1l1llllll1_l1_.split(l11l1l_l1_ (u"࠭࠭ࠨ毐"),1)[0]
	l1l1lll1l1l_l1_,l1l1lllll1l_l1_,l1ll11l11ll_l1_ = l11l1l_l1_ (u"ࠧࠨ毑"),l11l1l_l1_ (u"ࠨࠩ毒"),l11l1l_l1_ (u"ࠩࠪ毓")
	if   l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎࠩ比")		:	from l11ll1l_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭毕")	:	from l1l111ll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ毖")		:	from l1lll1ll_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭毗")	:	from l1111l1l_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩ毘")	:	from l1ll1111l_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ毙")	: 	from l1l1l11ll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ毚")	:	from l1l1l11l1_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ毛")	:	from l11l1111l_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ毜")		:	from l11111111_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡉࡉࡎࡃ࠷࡙ࠬ毝")	:	from l1llll1ll1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡐࠨ毞")	:	from l1ll1lll11_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ毟")	:	from l1ll1l1l11_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫ毠")	:	from l1ll1l1111_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭毡"):	from l11ll11111ll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡊࡔ࡙ࡔࡂࠩ毢")		:	from l1ll11l1l1l_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪ毣")		:	from l1ll111_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭毤")	:	from l1ll1l11l11_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨ毥")	:	from l1ll1lll1l_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ毦")	:	from l11l1llll1ll_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡅࡌࡑࡆ࠺࠰࠱ࠩ毧")	:	from l1lllll111_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ毨")	:	from l1l11lll1l1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡆࡗ࡙ࡔࡆࡌࠪ毩")	:	from l1lllll11l_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ毪")		:	from l11l1ll11ll1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧ毫")	:	from l1l1l11l1ll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫ毬"):	from l1l111lll_l1_	import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ毭")	:	from l111l1lll1_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ毮")	:	from l1ll11llll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ毯"):	from l11ll1l1ll_l1_	import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ毰")	:	from l11111111l_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ毱")	:	from l1lll1l11ll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ毲")	:	from l1lll1l11l1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ毳")	:	from l1ll1l11111_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩ毴")	:	from l1l1ll1ll11_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪ毵")	:	from l1ll1lllll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍࠨ毶")		:	from l1l1ll1l1ll_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖࠨ毷")		:	from IPTV			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,menu_namee as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫࡒ࠹ࡕࠨ毸")		:	from l1l111l1l1l_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ毹")	:	from l1l1l1l11l1_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡌࡐࡆ࡜ࡒࡊ࡚ࠧ毺")	:	from l1l11ll11ll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡎࡑ࡙ࡗ࠹࡛ࠧ毻")	:	from l111lll11l1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ毼")	:	from l111lll1111_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࡚ࠩࡉࡈࡏࡍࡂࠩ毽")	:	from l1l1lll111l1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ毾")	:	from l1ll11llll1_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭毿")	:	from l1ll11l1lll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬࡖࡁࡏࡇࡗࠫ氀")		:	from l111ll1llll_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ氁")	:	from l1l1ll1lll11_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ氂")	:	from l11l1llllll1_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ氃")	:	from l11l1lll1111_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ氄")	:	from l1l1ll11111l_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ氅")		:	from l1ll1ll11ll1_l1_			import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ氆")	:	from l1111111lll_l1_		import MENU as l1l1lll1l1l_l1_,SEARCH as l1l1lllll1l_l1_,l1111l_l1_ as l1ll11l11ll_l1_
	elif l1l1lll1ll1_l1_==l11l1l_l1_ (u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ氇"):	from l11l111l1l1l_l1_	import MENU as l1l1lll1l1l_l1_
	return l1l1lll1l1l_l1_,l1l1lllll1l_l1_,l1ll11l11ll_l1_
def DOWNLOAD_USING_PROGRESSBAR(l1ll1ll1l1111_l1_,headers={},l1ll_l1_=True):
	#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"࠭ࠧ氈"),l11l1l_l1_ (u"ࠧࠨ氉"),l11l1l_l1_ (u"ࠨࠩ氊"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ氋"),l11l1l_l1_ (u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆู็์อࠦๅ็ࠢส่ส์สา่อࠤํ่ฯࠡ์ๆ์๋ࠦใษ์ิࠤํ่ฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬࠣ࠲ࠥํไࠡฬิ๎ิࠦวๅษึฮ๊ืวาࠢยࠥࠬ氌"))
	#if l1ll111111_l1_!=1: return l11l1l_l1_ (u"ࠫࠬ氍")
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ氎"),l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧ࠻ࠢ࡞ࠤࠬ氏")+l1ll1ll1l1111_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪ氐")+str(headers)+l11l1l_l1_ (u"ࠨࠢࡠࠫ民"))
	l11l11ll1l_l1_ = DIALOG_PROGRESS()
	l11l11ll1l_l1_.create(l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ氒"),l11l1l_l1_ (u"ࠪ๎ัื๊ࠡษ็ฦ๋ࠦแฮืࠣห้๋ไโࠢส่๊฽ไ้สࠣฮา๋๊ๅ้ࠣ์อ฿ฯ่ษࠣืํ็ࠠหสาวࠥ฿ๅๅ์ฬࠤั๊ศࠡษ็้้็ࠠๆ่ࠣห้หๆหำ้ฮࠬ氓"))
	l11l1ll1l1_l1_ = 1024*1024
	l111ll11ll11_l1_ = bytes()
	chunk_size = 1*l11l1ll1l1_l1_
	import requests
	l1l1l1ll1_l1_ = headers
	l1l1l1ll1_l1_[l11l1l_l1_ (u"ࠫࡗࡧ࡮ࡨࡧࠪ气")] = l11l1l_l1_ (u"ࠬࡨࡹࡵࡧࡶࡁ࠵࠳ࠧ氕")
	response = requests.get(l1ll1ll1l1111_l1_,stream=True,headers=l1l1l1ll1_l1_,timeout=120)
	if l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ氖") not in list(response.headers.keys()):
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ気"),l11l1l_l1_ (u"ࠨࠩ氘"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ氙"),l11l1l_l1_ (u"ࠪห้ฮั็ษ่ะ๊ࠥๅࠡ์อ้่์ࠠๆ่ࠣฮา๋๊ๅࠢส่๊๊แࠡษ็้฼๊่ษ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣ฽๋ีใࠡ็ื็้ฯࠠโ์ࠣห้หๆหำ้ฮࠥอไฯษุࠤอ้ࠠ࠯ࠢฯีอࠦสฮ็ํ่ࠥอไๆๆไࠤ๊ืษࠡลัี๎࠭氚"))
		l11l11ll1l_l1_.close()
		return l11l1l_l1_ (u"ࠫࠬ氛")
	filesize = int(response.headers[l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭氜")])
	l11l1l1l11_l1_ = str(int(1000*filesize/l11l1ll1l1_l1_)/1000.0)
	l111llllll_l1_ = int(filesize/chunk_size)+1
	if l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡓࡣࡱ࡫ࡪ࠭氝") in list(response.headers.keys()) and filesize>l11l1ll1l1_l1_:
		l1lll11ll11l1_l1_ = True
		ranges = []
		l1lll1l111111_l1_ = 10
		ranges.append(str(0*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠧ࠮ࠩ氞")+str(1*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(1*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠨ࠯ࠪ氟")+str(2*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(2*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠩ࠰ࠫ氠")+str(3*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(3*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠪ࠱ࠬ氡")+str(4*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(4*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠫ࠲࠭氢")+str(5*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(5*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠬ࠳ࠧ氣")+str(6*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(6*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"࠭࠭ࠨ氤")+str(7*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(7*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠧ࠮ࠩ氥")+str(8*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(8*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠨ࠯ࠪ氦")+str(9*filesize//l1lll1l111111_l1_-1))
		ranges.append(str(9*filesize//l1lll1l111111_l1_)+l11l1l_l1_ (u"ࠩ࠰ࠫ氧"))
		l111ll1lll1l_l1_ = float(l111llllll_l1_)/l1lll1l111111_l1_
		l111111l1111_l1_ = l111ll1lll1l_l1_/int(1+l111ll1lll1l_l1_)
	else:
		l1lll11ll11l1_l1_ = False
		l1lll1l111111_l1_ = 1
		l111111l1111_l1_ = 1
	response.close()
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ氨"),l11l1l_l1_ (u"ࠫ࠳ࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡹࡸ࡯࡮ࡨࠢࡵࡥࡳ࡭ࡥࡴ࠼ࠣ࡟ࠥ࠭氩")+str(l1lll11ll11l1_l1_)+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡹࡩࡻࡧ࠽ࠤࡠࠦࠧ氪")+str(filesize)+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ氫"))
	l11l1l1ll1_l1_ = 0
	#t1 = time.time()-30
	for l11llll11l1_l1_ in range(l1lll1l111111_l1_):
		l1l1l1ll1_l1_ = headers
		if l1lll11ll11l1_l1_: l1l1l1ll1_l1_[l11l1l_l1_ (u"ࠧࡓࡣࡱ࡫ࡪ࠭氬")] = l11l1l_l1_ (u"ࠨࡤࡼࡸࡪࡹ࠽ࠨ氭")+ranges[l11llll11l1_l1_]
		response = requests.get(l1ll1ll1l1111_l1_,stream=True,headers=l1l1l1ll1_l1_,timeout=120)
		for chunk in response.iter_content(chunk_size=chunk_size):
			if l11l11ll1l_l1_.iscanceled():
				response.close()
				LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ氮"),l11l1l_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫ氯"))
				break
			l11l1l1ll1_l1_ += l111111l1111_l1_
			PROGRESS_UPDATE(l11l11ll1l_l1_,0+int(100*l11l1l1ll1_l1_/l111llllll_l1_),l11l1l_l1_ (u"ࠫั๊ศࠡษ็้้็࠺࠮ࠢส่ัุมࠡำๅ้ࠬ氰"),str(int(l11l1l1ll1_l1_*chunk_size//l11l1ll1l1_l1_))+l11l1l_l1_ (u"ࠬࠦ࠯ࠡࠩ氱")+l11l1l1l11_l1_+l11l1l_l1_ (u"࠭ࠠࡎࡄࠪ氲"))
			l111ll11ll11_l1_ += chunk
			#PROGRESS_UPDATE(l11l11ll1l_l1_,0+int(35*l11l1l1ll1_l1_/l111llllll_l1_),l11l1l_l1_ (u"ࠧอๆหࠤฬ๊ๅๅใࠣห้ืฦ๋ีํ࠾࠲ࠦวๅฮีลࠥืโๆࠩ氳")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ水")+str(l11l1l1ll1_l1_*chunksize/l11l1ll1l1_l1_)+l11l1l_l1_ (u"ࠩࠣ࠳ࠥ࠭氵")+l11l1l1l11_l1_+l11l1l_l1_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨ氶")+time.strftime(l11l1l_l1_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ氷")+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ永")+time.gmtime(l111lll11l_l1_))+l11l1l_l1_ (u"࠭ࠠแࠩ氹"))
			#l111ll1ll1_l1_ = time.time()
			#l111ll11l1_l1_ = l111ll1ll1_l1_-t1
			#l111ll1l1l_l1_ = l111ll11l1_l1_/l11l1l1ll1_l1_
			#l11l111lll_l1_ = l111ll1l1l_l1_*(l111llllll_l1_+1)
			#l111lll11l_l1_ = l11l111lll_l1_-l111ll11l1_l1_
		response.close()
	l11l11ll1l_l1_.close()
	if len(l111ll11ll11_l1_)<filesize:
		LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ氺"),l11l1l_l1_ (u"ࠨ࠰ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡰࡴࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥࡧࡴ࠻ࠢ࡞ࠤࠬ氻")+str(len(l111ll11ll11_l1_)//l11l1ll1l1_l1_)+l11l1l_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡊࡷࡵ࡭ࠡࡶࡲࡸࡦࡲࠠࡰࡨ࠽ࠤࡠࠦࠧ氼")+l11l1l1l11_l1_+l11l1l_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠩ氽"))
		choice = DIALOG_THREEBUTTONS_TIMEOUT(l11l1l_l1_ (u"ࠫࠬ氾"),l11l1l_l1_ (u"ࠬหไ฻ษฤࠤํิั้ฮࠪ氿"),l11l1l_l1_ (u"࠭วิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺ࠭汀"),l11l1l_l1_ (u"ࠧฦ฻สำฮࠦฬๅสࠣห้๋ไโࠩ汁"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ求"),l11l1l_l1_ (u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦวๅ็็ๅࠥࡢ࡮ࠡๆ็วุ็ࠠฮัฮࠤำ฽รࠡใํࠤฯำๅ๋ๆࠣห้๋ไโࠢ࡟ࡲࠥะๅࠡฮ็ฬࠥ࠭汃")+str(len(l111ll11ll11_l1_)//l11l1ll1l1_l1_)+l11l1l_l1_ (u"ࠪࠤ๊๐ฺศสส๎ฯࠦๅ็่ࠢะ๊๎ูࠡࠩ汄")+l11l1l1l11_l1_+l11l1l_l1_ (u"๋๊ࠫࠥ฻ษหห๏ะࠠ࡝ࡰࠣะึฮࠠอๆหࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠥࡢ࡮้ࠡ็ࠤฯื๊ะࠢสืฯิฯศ็ࠣห้๋ไโࠢส่๋อโึࠢยࠥࠦ࠭汅"))
		if choice==2: l111ll11ll11_l1_ = DOWNLOAD_USING_PROGRESSBAR(l1ll1ll1l1111_l1_,headers)
		elif choice==1: LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ汆"),l11l1l_l1_ (u"࠭࠮ࠡࠢࠣࡒࡴࡺࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࡦࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡪࡪࠠࡧ࡫࡯ࡩࠥ࡯ࡳࠡࡣࡦࡧࡪࡶࡴࡦࡦࠣࡥࡳࡪࠠࡸ࡫࡯ࡰࠥࡨࡥࠡࡷࡶࡩࡩ࠭汇"))
		else: return l11l1l_l1_ (u"ࠧࠨ汈")
		if not l111ll11ll11_l1_: return l11l1l_l1_ (u"ࠨࠩ汉")
	else: LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ汊"),l11l1l_l1_ (u"ࠪ࠲ࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨ࠳ࠦࠠࠡࡈ࡬ࡰࡪࠦࡓࡪࡼࡨ࠾ࠥࡡࠠࠨ汋")+l11l1l1l11_l1_+l11l1l_l1_ (u"ࠫࠥࡓࡂࠡ࡟ࠪ汌"))
	return l111ll11ll11_l1_
def l11l1111l11l_l1_(l1ll1_l1_,l111ll1ll1l1_l1_=True,l1llll1111l1l_l1_=True):
	l1ll1lll11lll_l1_ = str(random.randrange(111111111111,999999999999))
	#l11lllllll11_l1_ = l11ll11ll111_l1_()
	#l111llll1ll1_l1_ = l11lllllll11_l1_.split(l11l1l_l1_ (u"ࠬ࠲ࠧ汍"),1)[0]
	headers = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ汎"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡰࡳࡰࡰࠪ汏")}
	data = {l11l1l_l1_ (u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤ汐"):l11l1l_l1_ (u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧ汑"),
			l11l1l_l1_ (u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨ汒"):l1ll1lll11lll_l1_,
			l11l1l_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡶࠦ汓"): [{
				l11l1l_l1_ (u"ࠧࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠥ汔"):addon_version,
				l11l1l_l1_ (u"ࠨ࡯ࡴࡡࡹࡩࡷࡹࡩࡰࡰࠥ汕"):str(kodi_version),
				l11l1l_l1_ (u"ࠢࡪࡲࠥ汖"): l11l1l_l1_ (u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤ汗"),
				#l11l1l_l1_ (u"ࠤ࡬ࡴࡤࡧࡤࡥࡴࡨࡷࡸࠨ汘"):l111llll1ll1_l1_,
				l11l1l_l1_ (u"ࠥࡹࡸ࡫ࡲࡠ࡫ࡧࠦ汙"):l1l11ll1lll_l1_(32),
				l11l1l_l1_ (u"ࠦࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠣ汚"):l1ll1_l1_,
				l11l1l_l1_ (u"ࠧࡶ࡬ࡢࡶࡩࡳࡷࡳࠢ汛"): l11l1l_l1_ (u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨ汜"),
				l11l1l_l1_ (u"ࠢࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ汝"):{l11l1l_l1_ (u"ࠣࡧࡹࡩࡳࡺ࡟࡯ࡣࡰࡩࠧ汞"):l1ll1_l1_},
				#l11l1l_l1_ (u"ࠤࡸࡷࡪࡸ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠦ江"): {l11l1l_l1_ (u"ࠥࡷࡴࡻࡲࡤࡧࠥ池"):l11l1l_l1_ (u"ࠦࡆࡘࡁࡃࡋࡆࡣ࡛ࡏࡄࡆࡑࡖࠦ污")},
				l11l1l_l1_ (u"ࠧࠪࡳ࡬࡫ࡳࡣࡺࡹࡥࡳࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࡥࡳࡺࡰࡦࠦ汢"):False
			}]
		}
	url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ汣")
	import json
	data = json.dumps(data)
	response = l1lll1111111_l1_(l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ汤"),url,data,headers,l11l1l_l1_ (u"ࠨࠩ汥"),l11l1l_l1_ (u"ࠩࠪ汦"),l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ汧"))
	return response
def l111111l11ll_l1_(l1ll1_l1_,l111ll1ll1l1_l1_=True,l1llll1111l1l_l1_=True):
	# old l11111l11111_l1_ l1llll1llll1l_l1_ l1l1llll11ll_l1_
	# hit method:    https://l1ll1ll1ll1ll_l1_.l1l1ll1l1111_l1_.com/l1lllll111ll1_l1_/l1llllll11l1l_l1_/l111l11l11l1_l1_/protocol/l1l1llll11ll_l1_/l1llllll1lll1_l1_
	#url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲ࡨࡵ࡭࠰ࡥࡲࡰࡱ࡫ࡣࡵࡁࡹࡁ࠶ࠬࡴࡪࡦࡀ࡙ࡆ࠳࠱࠳࠹࠳࠸࠺࠷࠰࠵࠯࠸ࠪࡨ࡯ࡤ࠾ࠩ汨")+l1l11ll1lll_l1_(32)+l11l1l_l1_ (u"ࠬࠬࡴ࠾ࡧࡹࡩࡳࡺࠦࡴࡥࡀࡩࡳࡪࠦࡦࡥࡀࠫ汩")+addon_version+l11l1l_l1_ (u"࠭ࠦࡢࡸࡀࠫ汪")+addon_version+l11l1l_l1_ (u"ࠧࠧࡣࡱࡁࡆࡘࡁࡃࡋࡆࡣ࡛ࡏࡄࡆࡑࡖࡣࡓࡋࡗࡄࡎࡌࡉࡓ࡚ࡉࡅࠨࡨࡥࡂ࠭汫")+l1ll1_l1_+l11l1l_l1_ (u"ࠨࠨࡨࡰࡂ࠭汬")+str(kodi_version)+l11l1l_l1_ (u"ࠩࠩࡾࡂ࠭汭")+l1ll1lll11lll_l1_
	#response = l1lll1111111_l1_(l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ汮"),url,l11l1l_l1_ (u"ࠫࠬ汯"),l11l1l_l1_ (u"ࠬ࠭汰"),l11l1l_l1_ (u"࠭ࠧ汱"),l11l1l_l1_ (u"ࠧࠨ汲"),l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭汳"))
	# new l1llllllll1ll_l1_ l1llll1llll1l_l1_ 4
	# l1lll1ll1111l_l1_ test:    https://l1l11lll111l_l1_-l11lll11ll11_l1_-l11llll1llll_l1_.l1l1ll1l1111_l1_/l1llll11lllll_l1_/l1111l1l1l11_l1_-l1lll1l1l1l11_l1_
	# l1lll1ll1111l_l1_ json method:    https://l1ll1ll1ll1ll_l1_.l1l1ll1l1111_l1_.com/l1lllll111ll1_l1_/l1llllll11l1l_l1_/l111l11l11l1_l1_/protocol/l1llll11lllll_l1_/l1lllll11l11l_l1_/l1lll1ll1111l_l1_
	# l1lll1ll1111l_l1_ json method:    https://l1ll1ll1ll1ll_l1_.l1l1ll1l1111_l1_.com/l1lllll111ll1_l1_/l1llllll11l1l_l1_/l111l11l11l1_l1_/protocol/l1llll11lllll_l1_/l1lllll11l11l_l1_?l1lll111lll11_l1_=l1ll1lllll1ll_l1_
	# l1lll1ll1111l_l1_ hit method:   https://l1l1l1l111l_l1_.l11111ll11l1_l1_.com/l1llll11lllll_l1_-l1111l1l1ll1_l1_-protocol-l1111111l1ll_l1_
	# l1lll1ll1111l_l1_ hit method:   https://l1l1l1l111l_l1_.l11111ll11l1_l1_.com/l1lllll1l1l1_l1_-l1lll1ll111ll_l1_-l1l1ll1l1111_l1_-l1lllll111ll1_l1_-l1111l1l1ll1_l1_-protocol-version-2
	# l1lll1ll1111l_l1_ params:  https://data.l1lll1111l1l1_l1_.com
	# l1lll1l1lll11_l1_ json method
	#url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠭ࡢࡰࡤࡰࡾࡺࡩࡤࡵ࠱ࡧࡴࡳ࠯࡮ࡲ࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡦࡶࡩࡠࡵࡨࡧࡷ࡫ࡴ࠾࠲࠰ࡺ࠶࠻ࡁࡥࡥࡕࡋࡦࡖࡧࡲࡴࡲ࡫ࡱ࠻࠹ࡌࡃࠩࡱࡪࡧࡳࡶࡴࡨࡱࡪࡴࡴࡠ࡫ࡧࡁࡌ࠳ࡒࡑ࠹ࡔ࡝ࡊࡐ࠹ࡈ࠻ࠪ汴")
	#headers = {l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ汵"):l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧ汶")}
	#params = {l11l1l_l1_ (u"ࠬࡧࡰࡱࡡࡹࡩࡷࡹࡩࡰࡰࠪ汷"):addon_version,l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ汸"):kodi_version}
	#data = {l11l1l_l1_ (u"ࠧࡤ࡮࡬ࡩࡳࡺ࡟ࡪࡦࠪ汹"):l1l11ll1lll_l1_(32),l11l1l_l1_ (u"ࠨࡧࡹࡩࡳࡺࡳࠨ決"):[{l11l1l_l1_ (u"ࠩࡱࡥࡲ࡫ࠧ汻"):l1ll1_l1_,l11l1l_l1_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ汼"):params}]}
	#response = l1lll1111111_l1_(l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ汽"),url,str(data),headers,l11l1l_l1_ (u"ࠬ࠭汾"),l11l1l_l1_ (u"࠭ࠧ汿"),l11l1l_l1_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡕࡈࡒࡉࡥࡁࡏࡃࡏ࡝࡙ࡏࡃࡔࡡࡈ࡚ࡊࡔࡔ࠮࠳ࡶࡸࠬ沀"))
	l11l1l_l1_ (u"ࠣࠤࠥࠑࠏࠏࡥࡷࡧࡱࡸࡓࡧ࡭ࡦࠏࠍࠍࡦࡶࡰࡗࡧࡵࡷ࡮ࡵ࡮ࠎࠌࠌࡳࡵ࡫ࡲࡢࡶ࡬ࡲ࡬࡙ࡹࡴࡶࡨࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠒࠐࠉࡶࡣࡳࡺࠒࠐࠉࡶࡵࡨࡶࡤ࡯ࡤࠎࠌࠌࡥࡵࡶ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠎࠌࠌࡴࡱࡧࡴࡧࡱࡵࡱࡤࡼࡥࡳࡵ࡬ࡳࡳࠓࠊࠊࡧࡹࡩࡳࡺ࡟࡯ࡣࡰࡩࠒࠐࠉࠣࠤࠥ沁")
	# l1lll1l1lll11_l1_ hit method (l11l1111ll_l1_ l1111l1l1111_l1_ l1lll111ll111_l1_)
	#url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠭ࡢࡰࡤࡰࡾࡺࡩࡤࡵ࠱ࡧࡴࡳ࠯ࡨ࠱ࡦࡳࡱࡲࡥࡤࡶࡂࡺࡂ࠸ࠦࡵ࡫ࡧࡁࡌ࠳ࡒࡑ࠹ࡔ࡝ࡊࡐ࠹ࡈ࠻ࠩࡧ࡮ࡪ࠽ࠨ沂")+l1l11ll1lll_l1_(32)+l11l1l_l1_ (u"ࠪࠪࡤࡹ࠽࠲ࠨࡨࡲࡂ࠭沃")+l1ll1_l1_+l11l1l_l1_ (u"ࠫࠫࡻࡰ࠯ࡣࡹࡣࡻ࡫ࡲ࠾ࠩ沄")+addon_version+l11l1l_l1_ (u"ࠬࠬࡵࡱ࠰࡮ࡳࡩ࡯࡟ࡷࡧࡵࡁࠬ沅")+str(kodi_version)
	#url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡰࡤࡰࡾࡺࡩࡤࡵ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡨ࠱ࡦࡳࡱࡲࡥࡤࡶࡂࡺࡂ࠸ࠦࡵ࡫ࡧࡁࡌ࠳ࡒࡑ࠹ࡔ࡝ࡊࡐ࠹ࡈ࠻ࠩࡣࡩࡨࡧ࠾࠳ࠩࡧ࡮ࡪ࠽࠲࠺࠸࠺࠵࠺࠸࠵࠻࠺࠲࠶࠼࠹࠱࠳࠷࠹࠹࠻࠷ࠨ沆")
	#l1ll1lll11lll_l1_ = str(random.randrange(1111111111,9999999999))
	#url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱࡥࡱࡿࡴࡪࡥࡶ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡩ࠲ࡧࡴࡲ࡬ࡦࡥࡷࡃࡻࡃ࠲ࠧࡶ࡬ࡨࡂࡍ࠭ࡓࡒ࠺ࡕ࡞ࡋࡊ࠺ࡉ࠼ࠪࡤࡪࡢࡨ࠿࠴ࠪࡨ࡯ࡤ࠾ࠩ沇")+str(l1ll1lll11lll_l1_)+l11l1l_l1_ (u"ࠨ࠰ࠪ沈")+str(int(time.time()))
	#url += l11l1l_l1_ (u"ࠩࠩࡹࡦࡶࡶ࠾࠳࠼࠲࠶ࠬࡤࡵ࠿ࡎࡓࡉࡏࠥ࠳࠲ࡈࡑࡆࡊࠦࡦࡰࡀࡴࡦ࡭ࡥࡠࡸ࡬ࡩࡼࠬ࡟ࡦࡧࡀ࠵ࠫࡻࡩࡥ࠿࠵࠶࠷࠸࠭࠳࠴࠵࠶࠲࠹࠳࠴࠵ࠩࡣࡸࡹ࠽࠲ࠩ沉")
	#response = l1lll1111111_l1_(l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ沊"),url,l11l1l_l1_ (u"ࠫࠬ沋"),l11l1l_l1_ (u"ࠬ࠭沌"),l11l1l_l1_ (u"࠭ࠧ沍"),l11l1l_l1_ (u"ࠧࠨ沎"),l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕ࠯࠴ࡷࡹ࠭沏"))
	# l1lll1l1lll11_l1_ modified (not good l1llllll1l1ll_l1_)
	#l1ll1lll11lll_l1_ = str(random.randrange(111111111111,999999999999))
	#url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠭ࡢࡰࡤࡰࡾࡺࡩࡤࡵ࠱ࡧࡴࡳ࠯ࡨ࠱ࡦࡳࡱࡲࡥࡤࡶࡂࡺࡂ࠸ࠦࡵ࡫ࡧࡁࡌ࠳ࡒࡑ࠹ࡔ࡝ࡊࡐ࠹ࡈ࠻ࠩࡧ࡮ࡪ࠽ࠨ沐")+l1l11ll1lll_l1_(32)+l11l1l_l1_ (u"ࠪࠪࡤࡹ࠽࠲ࠨࡨࡲࡂ࠭沑")+l1ll1_l1_+l11l1l_l1_ (u"ࠫࠫࡻࡰ࠯ࡣࡹࡣࡻ࡫ࡲ࠾ࠩ沒")+addon_version+l11l1l_l1_ (u"ࠬࠬࡵࡢࡲࡹࡁࠬ沓")+str(kodi_version)+l11l1l_l1_ (u"࠭ࠦࡠࡲࡀࠫ沔")+l1ll1lll11lll_l1_
	#l11lllllll11_l1_ = l11ll11ll111_l1_()
	#l1l1lllllll1_l1_ = l11lllllll11_l1_.split(l11l1l_l1_ (u"ࠧ࠭ࠩ沕"),1)[0]
	return response
def l11ll11ll111_l1_(l1l1lllllll1_l1_=l11l1l_l1_ (u"ࠨࠩ沖")):
	l1lll11llll11_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭沗"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭沘"),l11l1l_l1_ (u"ࠫࡎࡖࡌࡐࡅࡄࡘࡎࡕࡎࠨ沙"))
	if l1lll11llll11_l1_: return l1lll11llll11_l1_
	# url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡱ࡮ࡲࡧࡦࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ沚")
	# l1l1llll11ll_l1_   url = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࡯ࡳ࠯ࡣࡳࡴ࠴ࡰࡳࡰࡰ࠲ࠫ沛")+l1l1lllllll1_l1_
	# l1lll1l1ll1l1_l1_   url = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲࡺ࡬ࡴ࠴ࡩࡴ࠱ࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡸࡥࡨ࡫ࡲࡲ࠱ࡩࡩࡵࡻ࠯ࡸ࡮ࡳࡥࡻࡱࡱࡩࠬ沜")
	l1l1lllllll1_l1_,l1lll1l111l11_l1_,l11lll1l1ll_l1_,l11l1111ll1l_l1_,l1llll1l1l111_l1_,l1111l111l11_l1_,timezone = l11l1l_l1_ (u"ࠨࠩ沝"),l11l1l_l1_ (u"ࠩࠪ沞"),l11l1l_l1_ (u"ࠪࠫ沟"),l11l1l_l1_ (u"ࠫࠬ沠"),l11l1l_l1_ (u"ࠬ࠭没"),l11l1l_l1_ (u"࠭ࠧ沢"),l11l1l_l1_ (u"ࠧࠨ沣")
	url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫ࡳࡻ࡭ࡵ࠮ࡪࡵ࠲ࠫ沤")+l1l1lllllll1_l1_+l11l1l_l1_ (u"ࠩࡂࡳࡺࡺࡰࡶࡶࡀ࡮ࡸࡵ࡮ࠧࡨ࡬ࡩࡱࡪࡳ࠾࡫ࡳ࠰ࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠬࡤࡱࡸࡲࡹࡸࡹ࠭ࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠬࡳࡧࡪ࡭ࡴࡴࠬࡤ࡫ࡷࡽ࠱ࡺࡩ࡮ࡧࡽࡳࡳ࡫ࠧ沥")
	response = l1lll1111111_l1_(l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ沦"),url,l11l1l_l1_ (u"ࠫࠬ沧"),l11l1l_l1_ (u"ࠬ࠭沨"),l11l1l_l1_ (u"࠭ࠧ沩"),l11l1l_l1_ (u"ࠧࠨ沪"),l11l1l_l1_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉࡔࡒࡏࡄࡃࡗࡍࡔࡔ࠭࠲ࡵࡷࠫ沫"))
	if not response.succeeded: l11llll1l111_l1_ = l1l1lllllll1_l1_+l11l1l_l1_ (u"ࠩ࠯ࠫ沬")+l1lll1l111l11_l1_+l11l1l_l1_ (u"ࠪ࠰ࠬ沭")+l11lll1l1ll_l1_+l11l1l_l1_ (u"ࠫ࠱࠭沮")+l1llll1l1l111_l1_+l11l1l_l1_ (u"ࠬ࠲ࠧ沯")+l1111l111l11_l1_+l11l1l_l1_ (u"࠭ࠬࠨ沰")+timezone
	else:
		html = response.content
		l111l11l1l11_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡥ࡫ࡦࡸࠬ沱"),html)
		if l11l1l_l1_ (u"ࠨ࡫ࡳࠫ沲") in list(l111l11l1l11_l1_.keys()): l1l1lllllll1_l1_ = l111l11l1l11_l1_[l11l1l_l1_ (u"ࠩ࡬ࡴࠬ河")]
		if l11l1l_l1_ (u"ࠪࡧࡴࡴࡴࡪࡰࡨࡲࡹ࠭沴") in list(l111l11l1l11_l1_.keys()): l1lll1l111l11_l1_ = l111l11l1l11_l1_[l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡩࡳࡺࠧ沵")]
		if l11l1l_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭沶") in list(l111l11l1l11_l1_.keys()): l11lll1l1ll_l1_ = l111l11l1l11_l1_[l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ沷")]
		if l11l1l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪ࠭沸") in list(l111l11l1l11_l1_.keys()): l11l1111ll1l_l1_ = l111l11l1l11_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࡡࡦࡳࡩ࡫ࠧ油")]
		if l11l1l_l1_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ沺") in list(l111l11l1l11_l1_.keys()): l1llll1l1l111_l1_ = l111l11l1l11_l1_[l11l1l_l1_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࠪ治")]
		if l11l1l_l1_ (u"ࠫࡨ࡯ࡴࡺࠩ沼") in list(l111l11l1l11_l1_.keys()): l1111l111l11_l1_ = l111l11l1l11_l1_[l11l1l_l1_ (u"ࠬࡩࡩࡵࡻࠪ沽")]
		if l11l1l_l1_ (u"࠭ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨ沾") in list(l111l11l1l11_l1_.keys()):
			timezone = l111l11l1l11_l1_[l11l1l_l1_ (u"ࠧࡵ࡫ࡰࡩࡿࡵ࡮ࡦࠩ沿")][l11l1l_l1_ (u"ࠨࡷࡷࡧࠬ泀")]
			if timezone[0] not in [l11l1l_l1_ (u"ࠩ࠰ࠫ況"),l11l1l_l1_ (u"ࠪ࠯ࠬ泂")]: timezone = l11l1l_l1_ (u"ࠫ࠰࠭泃")+timezone
		l11llll1l111_l1_ = l1l1lllllll1_l1_+l11l1l_l1_ (u"ࠬ࠲ࠧ泄")+l1lll1l111l11_l1_+l11l1l_l1_ (u"࠭ࠬࠨ泅")+l11lll1l1ll_l1_+l11l1l_l1_ (u"ࠧ࠭ࠩ泆")+l1llll1l1l111_l1_+l11l1l_l1_ (u"ࠨ࠮ࠪ泇")+l1111l111l11_l1_+l11l1l_l1_ (u"ࠩ࠯ࠫ泈")+timezone
		if kodi_version>18.99: l11llll1l111_l1_ = l11llll1l111_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ泉")).decode(l11l1l_l1_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ泊"))
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨ泋"),l11l1l_l1_ (u"࠭ࡉࡑࡎࡒࡇࡆ࡚ࡉࡐࡐࠪ泌"),l11llll1l111_l1_,l1ll1l1ll_l1_)
	return l11llll1l111_l1_
def SEARCH_OPTIONS(search):
	options,l1ll_l1_ = l11l1l_l1_ (u"ࠧࠨ泍"),True
	if search.count(l11l1l_l1_ (u"ࠨࡡࠪ泎"))>=2:
		search,options = search.split(l11l1l_l1_ (u"ࠩࡢࠫ泏"),1)
		options = l11l1l_l1_ (u"ࠪࡣࠬ泐")+options
		if l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩ泑") in options: l1ll_l1_ = False
		else: l1ll_l1_ = True
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭泒"),l11l1l_l1_ (u"࠭ࠧ泓"),search,options)
	return search,options,l1ll_l1_
def l11l111ll1l_l1_(l1ll_l1_):
	url = l1l1l1l_l1_[l11l1l_l1_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ泔")][3]
	l1lll111ll1l1_l1_ = l1l11ll1lll_l1_(32)
	l11llll1l111_l1_ = l11ll11ll111_l1_()
	l11lll1l1ll_l1_ = l11llll1l111_l1_.split(l11l1l_l1_ (u"ࠨ࠮ࠪ法"))[2]
	l1llll11111ll_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ泖"))
	l111l11111l1_l1_ = 0
	if os.path.exists(l1llll11111ll_l1_):
		for l1l111ll11_l1_ in os.listdir(l1llll11111ll_l1_):
			l1l111l1l1_l1_ = os.path.join(l1llll11111ll_l1_,l1l111ll11_l1_)
			if os.path.isfile(l1l111l1l1_l1_):
				size,count = l1l11llll1_l1_(l1l111l1l1_l1_)
				l111l11111l1_l1_ += size
	payload = {l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ泗"):l1lll111ll1l1_l1_,l11l1l_l1_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬ泘"):addon_version,l11l1l_l1_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭泙"):l11lll1l1ll_l1_,l11l1l_l1_ (u"࠭ࡩࡥࡵࠪ泚"):l1lll1lllll1l_l1_(l111l11111l1_l1_)}
	if l1ll_l1_: DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ泛"),(l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭泜"),url,payload,l11l1l_l1_ (u"ࠩࠪ泝"),l11l1l_l1_ (u"ࠪࠫ泞"),l11l1l_l1_ (u"ࠫࠬ泟")))
	settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡷࡶࡩࡷ࠴ࡰࡳ࡫ࡹࡷࠬ泠"),l11l1l_l1_ (u"࠭ࠧ泡"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ波"),url,payload,l11l1l_l1_ (u"ࠨࠩ泣"),l11l1l_l1_ (u"ࠩࠪ泤"),l11l1l_l1_ (u"ࠪࠫ泥"),l11l1l_l1_ (u"ࠫࡒࡋࡎࡖࡕ࠰ࡗࡍࡕࡗࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ泦"),True,True)
	if not response.succeeded: l11l111lll1_l1_ = l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࠫ泧")
	else:
		l111l1l11ll1_l1_,l11111lll1l1_l1_,l1111l1111ll_l1_,l11111llll11_l1_ = l11l1l_l1_ (u"࠭ࠧ注"),l11l1l_l1_ (u"ࠧࠨ泩"),l11l1l_l1_ (u"ࠨࠩ泪"),[]
		newfile = response.content
		if newfile:
			l11111llll11_l1_ = EVAL(l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ泫"),newfile)
			for l1lllll1llll1_l1_,l1lll1l111lll_l1_,message in l11111llll11_l1_:
				if kodi_version>18.99: message = message.encode(l11l1l_l1_ (u"ࠪࡶࡦࡽ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ泬")).decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ泭"))
				if l1lllll1llll1_l1_==l11l1l_l1_ (u"ࠬ࠶ࠧ泮"): l111l1l11ll1_l1_ += message+l11l1l_l1_ (u"࠭࠺࠻ࠩ泯")
				else: l11111lll1l1_l1_ += message+l11l1l_l1_ (u"ࠧ࡝ࡰࠪ泰")
			l11111lll1l1_l1_ = l11111lll1l1_l1_.strip(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ泱"))
			l111l1l11ll1_l1_ = l111l1l11ll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠽࠾ࠬ泲"))
		settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ泳"),l111l1l11ll1_l1_)
		settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬ泴"),l1lll1lllll1l_l1_(now))
		if os.path.exists(l1l11ll111ll_l1_): l1111l1111ll_l1_ = open(l1l11ll111ll_l1_,l11l1l_l1_ (u"ࠬࡸࡢࠨ泵")).read()
		if kodi_version>18.99: l11111lll1l1_l1_ = l11111lll1l1_l1_.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ泶"))
		if l11111lll1l1_l1_==l1111l1111ll_l1_: l11l111lll1_l1_ = l11l1l_l1_ (u"ࠧࡐࡎࡇࠫ泷")
		else:
			l11l111lll1_l1_ = l11l1l_l1_ (u"ࠨࡐࡈ࡛ࠬ泸")
			open(l1l11ll111ll_l1_,l11l1l_l1_ (u"ࠩࡺࡦࠬ泹")).write(l11111lll1l1_l1_)
		if l1ll_l1_:
			l11l111lll1_l1_ = l11l1l_l1_ (u"ࠪࡓࡑࡊࠧ泺")
			l11111llll11_l1_ = sorted(l11111llll11_l1_,reverse=True,key=lambda key: int(key[0]))
			l1l1111ll1ll_l1_ = l11l1l_l1_ (u"ࠫࠬ泻")
			for l1lllll1llll1_l1_,l1lll1l111lll_l1_,message in l11111llll11_l1_:
				if kodi_version>18.99: message = message.encode(l11l1l_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ泼")).decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ泽"))
				if l1l1111ll1ll_l1_: l1l1111ll1ll_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡰ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࡠࡳࡢ࡮ࠨ泾")
				if l1lllll1llll1_l1_==l11l1l_l1_ (u"ࠨ࠲ࠪ泿"): continue
				date = message.split(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ洀"))[0]
				l1lll111l_l1_ = l11l1l_l1_ (u"ࠪࠫ洁")
				if l1lll1l111lll_l1_:
					l1lll111l_l1_ = l11l1l_l1_ (u"ࠫึูวๅหࠣาฬ฻ษࠡๆๆࠤๆ่ืࠨ洂")
					if kodi_version>18.99: l1lll111l_l1_ = l1lll111l_l1_.encode(l11l1l_l1_ (u"ࠬࡸࡡࡸࡡࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ洃")).decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ洄"))
				l1l1111ll1ll_l1_ += message.replace(date,l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ洅")+date+l1lll111l_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ洆"))+l11l1l_l1_ (u"ࠩ࡟ࡲࠬ洇")
			l1l1111ll1ll_l1_ = escapeUNICODE(l1l1111ll1ll_l1_)
			l11l1llll1_l1_(l11l1l_l1_ (u"ࠪࡶ࡮࡭ࡨࡵࠩ洈"),l11l1l_l1_ (u"ࠫึูววๆ้๋ࠣࠦวๅ็หี๊าࠠฦๆ์ࠤู๊สฯั่๎ࠥอไษำ้ห๊าࠧ洉"),l1l1111ll1ll_l1_,l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࡠ࡮ࡲࡲ࡬࠭洊"))
	settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡰࡩࡸࡹࡡࡨࡧࡶ࠲ࡸࡺࡡࡵࡷࡶࠫ洋"),l11l111lll1_l1_)
	xbmc.executebuiltin(l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫ洌"))
	return l11l111lll1_l1_
def l111ll11ll1l_l1_(type):
	if type==l11l1l_l1_ (u"ࠨࡦ࡬ࡧࡹ࠭洍"): data = {}
	elif type==l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ洎"): data = []
	elif type==l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ洏"): data = l11l1l_l1_ (u"ࠫࠬ洐")
	elif type==l11l1l_l1_ (u"ࠬ࡯࡮ࡵࠩ洑"): data = 0
	elif type==l11l1l_l1_ (u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨ洒"): data = l1111lll11l1_l1_()
	elif not type: data = None
	else: data = None
	return data
def l11l1l11l1_l1_(url,l1l11lll_l1_=l11l1l_l1_ (u"ࠧࠨ洓")):
	l111ll1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࡟࠲ࡦࡼࡩࡽ࡞࠱ࡸࡸࢂ࡜࠯࡯ࡳ࠸ࢁࡢ࠮࡮࠵ࡸࢀࡡ࠴࡭࠴ࡷ࠻ࢀࡡ࠴࡭ࡱࡦࡿࡠ࠳ࡳ࡫ࡷࡾ࡟࠲࡫ࡲࡶࡽ࡞࠱ࡱࡵ࠹ࡼ࡝࠰ࡺࡩࡧࡳࠩࠩࡾ࡟ࡃ࠳࠰࠿ࡽ࠱࡟ࡃ࠳࠰࠿ࡽ࡞ࡿ࠲࠯ࡅࠩࠥࠩ洔"),url.lower(),re.DOTALL|re.IGNORECASE)
	if l111ll1111_l1_: l111ll1111_l1_ = l111ll1111_l1_[0][0]
	else: l111ll1111_l1_ = l11l1l_l1_ (u"ࠩࠪ洕")
	return l111ll1111_l1_
	#elif not l111ll1111_l1_ and l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫ洖") in l1l11lll_l1_: l111ll1111_l1_ = l11l1l_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩ洗")
	#elif not l111ll1111_l1_ and l11l1l_l1_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ洘") in l1l11lll_l1_: l111ll1111_l1_ = l11l1l_l1_ (u"࠭࠮࡮ࡲ࠷ࠫ洙")
def PING(host,port):
	import socket
	sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
	sock.settimeout(1)
	l11l11ll1ll1_l1_,resp = True,0
	t1 = time.time()
	try: sock.connect((host,port))
	except: l11l11ll1ll1_l1_ = False
	l111ll1ll1_l1_ = time.time()
	if l11l11ll1ll1_l1_: resp = l111ll1ll1_l1_-t1
	return resp
def FIX_ALL_DATABASES(l1ll_l1_):
	if l1ll_l1_:
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨ洚"),l11l1l_l1_ (u"ࠨࠩ洛"),l11l1l_l1_ (u"ࠩࠪ洜"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭洝"),l11l1l_l1_ (u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪ洞"))
	else: l1ll111111_l1_ = True
	if l1ll111111_l1_==1:
		for filename in os.listdir(addoncachefolder):
			if filename.endswith(l11l1l_l1_ (u"ࠬ࠴ࡤࡣࠩ洟")) and l11l1l_l1_ (u"࠭ࡤࡢࡶࡤࠫ洠") in filename:
				l1l1l1l11l_l1_ = os.path.join(addoncachefolder,filename)
				conn = sqlite3.connect(l1l1l1l11l_l1_)
				cc = conn.cursor()
				l111llll11ll_l1_(cc)
				cc.execute(l11l1l_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡪࡰࡷࡩ࡬ࡸࡩࡵࡻࡢࡧ࡭࡫ࡣ࡬࠽ࠪ洡"))
				cc.execute(l11l1l_l1_ (u"ࠨࡒࡕࡅࡌࡓࡁࠡࡱࡳࡸ࡮ࡳࡩࡻࡧ࠾ࠫ洢"))
				cc.execute(l11l1l_l1_ (u"࡙ࠩࡅࡈ࡛ࡕࡎ࠽ࠪ洣"))
				conn.commit()
				conn.close()
		if l1ll_l1_:
			DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ洤"),l11l1l_l1_ (u"ࠫࠬ津"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ洦"),l11l1l_l1_ (u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧ洧"))
	return
def EVAL(l1lll111ll11l_l1_,text):
	#text = text.replace(l11l1l_l1_ (u"ࠢࡶࠩࠥ洨"),l11l1l_l1_ (u"ࠣࠩࠥ洩"))
	text = text.replace(l11l1l_l1_ (u"ࠩࡱࡹࡱࡲࠧ洪"),l11l1l_l1_ (u"ࠪࡒࡴࡴࡥࠨ洫"))
	text = text.replace(l11l1l_l1_ (u"ࠫࡹࡸࡵࡦࠩ洬"),l11l1l_l1_ (u"࡚ࠬࡲࡶࡧࠪ洭"))
	text = text.replace(l11l1l_l1_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ洮"),l11l1l_l1_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭洯"))
	try: l1l1l11l11_l1_ = eval(text)
	except: l1l1l11l11_l1_ = l111ll11ll1l_l1_(l1lll111ll11l_l1_)
	return l1l1l11l11_l1_
def l1llll111111l_l1_(word):
	if l11l1l_l1_ (u"ࠨ࡝ࠪ洰") in word and l11l1l_l1_ (u"ࠩࡠࠫ洱") in word:
		l1llll1lll1ll_l1_ = [l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ洲"),l11l1l_l1_ (u"ࠫࡠ࠵ࡒࡕࡎࡠࠫ洳"),l11l1l_l1_ (u"ࠬࡡ࠯ࡍࡇࡉࡘࡢ࠭洴"),l11l1l_l1_ (u"࡛࠭࠰ࡔࡌࡋࡍ࡚࡝ࠨ洵"),l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡉࡓ࡚ࡅࡓ࡟ࠪ洶"),l11l1l_l1_ (u"ࠨ࡝ࡕࡘࡑࡣࠧ洷"),l11l1l_l1_ (u"ࠩ࡞ࡐࡊࡌࡔ࡞ࠩ洸"),l11l1l_l1_ (u"ࠪ࡟ࡗࡏࡇࡉࡖࡠࠫ洹"),l11l1l_l1_ (u"ࠫࡠࡉࡅࡏࡖࡈࡖࡢ࠭洺")]
		l111ll111l11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡢ࡛ࡄࡑࡏࡓࡗࠦ࠮ࠫࡁ࡟ࡡࠬ活"),word,re.DOTALL)
		l111ll111l1l_l1_ = re.findall(l11l1l_l1_ (u"࠭࡜࡜ࡅࡒࡐࡔࡘࠣࠤࠥ࠱࠮ࡄࡢ࡝ࠨ洼"),word,re.DOTALL)
		l1lll1l111ll1_l1_ = l1llll1lll1ll_l1_+l111ll111l11_l1_+l111ll111l1l_l1_
		for tag in l1lll1l111ll1_l1_: word = word.replace(tag,l11l1l_l1_ (u"ࠧࠨ洽"))
	return word
def l1llllll1111l_l1_(l11l111l111l_l1_,l11111l11ll1_l1_,l1llll1lll111_l1_,l1lll1ll111l1_l1_):
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	l111ll1l1l11_l1_,l111l1l111ll_l1_,l1lll111l1l1l_l1_ = l11l1l_l1_ (u"ࠨࠩ派"),0,15000
	l11l111l111l_l1_ = l11l111l111l_l1_.replace(l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࠪ洿"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠦࠧࠨ࠭浀"))
	l1ll1llll111l_l1_ = PIL.ImageFont.truetype(l11111l1l1ll_l1_,size=l11111l11ll1_l1_)
	txt = PIL.Image.new(l11l1l_l1_ (u"ࠫࡗࡍࡂࡂࠩ流"),(l1llll1lll111_l1_,99),(255,255,255,0))
	l1111lll1l11_l1_ = PIL.ImageDraw.Draw(txt)
	l1llll1lll111_l1_ -= l11111l11ll1_l1_
	for l1lll11ll1111_l1_ in l11l111l111l_l1_.splitlines():
		l111l1l111ll_l1_ += l1lll1ll111l1_l1_
		l11111l1l1l1_l1_,newline = 0,l11l1l_l1_ (u"ࠬ࠭浂")
		for word in l1lll11ll1111_l1_.split(l11l1l_l1_ (u"࠭ࠠࠨ浃")):
			l1111l1lllll_l1_ = l1llll111111l_l1_(l11l1l_l1_ (u"ࠧࠡࠩ浄")+word)
			l1lll1l11l111_l1_,l1111ll11lll_l1_ = l1111lll1l11_l1_.textsize(l1111l1lllll_l1_,font=l1ll1llll111l_l1_)
			if l11111l1l1l1_l1_+l1lll1l11l111_l1_<l1llll1lll111_l1_:
				if not newline: newline += word
				else: newline += l11l1l_l1_ (u"ࠨࠢࠪ浅")+word
				l11111l1l1l1_l1_ += l1lll1l11l111_l1_
			else:
				if l1lll1l11l111_l1_<l1llll1lll111_l1_:
					newline += l11l1l_l1_ (u"ࠩ࡟ࡲࠥ࠭浆")+word
					l111l1l111ll_l1_ += l1lll1ll111l1_l1_
					l11111l1l1l1_l1_ = l1lll1l11l111_l1_
				else:
					while l1lll1l11l111_l1_>=l1llll1lll111_l1_:
						for l11l1l1ll1_l1_ in range(1,len(l11l1l_l1_ (u"ࠪࠤࠬ浇")+word),1):
							l1111lll1lll_l1_ = l11l1l_l1_ (u"ࠫࠥ࠭浈")+word[:l11l1l1ll1_l1_]
							l1111111l1_l1_ = word[l11l1l1ll1_l1_:]
							l1lll11111lll_l1_ = l1llll111111l_l1_(l1111lll1lll_l1_)
							l111ll11lll1_l1_,l1111l11l1l1_l1_ = l1111lll1l11_l1_.textsize(l1lll11111lll_l1_,font=l1ll1llll111l_l1_)
							if l11111l1l1l1_l1_+l111ll11lll1_l1_>=l1llll1lll111_l1_:
								l1llll1l11ll1_l1_ = l1lll1l11l111_l1_-l111ll11lll1_l1_
								newline += l1111lll1lll_l1_+l11l1l_l1_ (u"ࠬࡢ࡮ࠨ浉")
								l111l1l111ll_l1_ += l1lll1ll111l1_l1_
								l1lll1l11l111_l1_ = l1llll1l11ll1_l1_
								if l1llll1l11ll1_l1_>=l1llll1lll111_l1_:
									l11111l1l1l1_l1_ = 0
									word = l1111111l1_l1_
								else:
									l11111l1l1l1_l1_ = l1llll1l11ll1_l1_
									newline += l1111111l1_l1_
								break
				if l111l1l111ll_l1_>l1lll111l1l1l_l1_: break
		l111ll1l1l11_l1_ += l11l1l_l1_ (u"࠭࡜࡯ࠩ浊")+newline
		if l111l1l111ll_l1_>l1lll111l1l1l_l1_: break
	l111ll1l1l11_l1_ = l111ll1l1l11_l1_[1:]
	l111ll1l1l11_l1_ = l111ll1l1l11_l1_.replace(l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠣࠤࠥࠪ测"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ浌"))
	return l111ll1l1l11_l1_
def l111l1ll1111_l1_(text):
	text = text.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ浍"),l11l1l_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ济"))
	text = text.replace(l11l1l_l1_ (u"ࠫࡠࡘࡔࡍ࡟ࠪ浏"),l11l1l_l1_ (u"ࠬࡥࡳࡴࡵࡢࡣࡱ࡯࡮ࡦࡴࡷࡰࡤ࠭浐"))
	text = text.replace(l11l1l_l1_ (u"࡛࠭ࡍࡇࡉࡘࡢ࠭浑"),l11l1l_l1_ (u"ࠧࡠࡵࡶࡷࡤࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ浒"))
	text = text.replace(l11l1l_l1_ (u"ࠨ࡝ࡕࡍࡌࡎࡔ࡞ࠩ浓"),l11l1l_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡸࡩࡨࡪࡷࡣࠬ浔"))
	text = text.replace(l11l1l_l1_ (u"ࠪ࡟ࡈࡋࡎࡕࡇࡕࡡࠬ浕"),l11l1l_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡤࡧࡱࡸࡪࡸ࡟ࠨ浖"))
	text = text.replace(l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ浗"),l11l1l_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤ࡫࡮ࡥࡥࡲࡰࡴࡸ࡟ࠨ浘"))
	l1lllllll11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡝࡝ࡆࡓࡑࡕࡒࠡࠪ࠱࠮ࡄ࠯࡜࡞ࠩ浙"),text,re.DOTALL)
	for l1llll1l11111_l1_ in l1lllllll11ll_l1_: text = text.replace(l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࠩ浚")+l1llll1l11111_l1_+l11l1l_l1_ (u"ࠩࡠࠫ浛"),l11l1l_l1_ (u"ࠪࡣࡸࡹࡳࡠࡡࡱࡩࡼࡩ࡯࡭ࡱࡵࠫ浜")+l1llll1l11111_l1_+l11l1l_l1_ (u"ࠫࡤ࠭浝"))
	return text
def l1lll111l111l_l1_(l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l1111l1l111l_l1_,header,text,l1111l1lll11_l1_,l111ll1l11l1_l1_,l1llll11l11l1_l1_,l1lll1lll1l1l_l1_):
	l1lll11l1l11l_l1_ = [l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l1111l1l111l_l1_,header,text]
	table_keyy = str(addon_version)+l11l1l_l1_ (u"ࠬࡥ࡟ࠨ浞")+str(dest_lang)+l11l1l_l1_ (u"࠭࡟ࡠࠩ浟")+str(l1lll11l1l11l_l1_)
	contents = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ浠"),l11l1l_l1_ (u"ࠨࡖࡕࡅࡓ࡙ࡌࡂࡖࡈࡈࡤࡊࡉࡂࡎࡒࡋࡘ࠭浡"),table_keyy)
	if not contents:
		if do_trans:
			contents = REVERSO_TRANSLATE(l1lll11l1l11l_l1_)
			WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩࡗࡖࡆࡔࡓࡍࡃࡗࡉࡉࡥࡄࡊࡃࡏࡓࡌ࡙ࠧ浢"),table_keyy,contents,VERYLONG_CACHE)
	if contents: [l1111l11ll11_l1_,l1lll11ll1l1l_l1_,l1111l1l111l_l1_,header,text] = contents
	import PIL.ImageDraw,PIL.ImageFont,PIL.Image
	import arabic_reshaper
	if kodi_version<19:
		text = text.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ浣"))
		header = header.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ浤"))
		l1111l11ll11_l1_ = l1111l11ll11_l1_.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ浥"))
		l1lll11ll1l1l_l1_ = l1lll11ll1l1l_l1_.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ浦"))
		l1111l1l111l_l1_ = l1111l1l111l_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ浧"))
	l1111ll1l1ll_l1_ = 5
	l1ll1lll1lll1_l1_ = 20
	l1lllll1l1l11_l1_ = 20
	l1llll1l1l1l1_l1_ = 0
	l11l111l11l1_l1_ = l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ浨")
	l1lll1111ll1l_l1_ = 0
	l1lll11l11111_l1_ = 19
	l111l1l111l1_l1_ = 30
	l1lllll11ll1l_l1_ = 8
	l1llll1l111ll_l1_ = True
	l1lll11ll1ll1_l1_ = 375
	l1ll1lllll111_l1_ = 410
	l1llllll1ll1l_l1_ = 50
	l1lll1ll11l1l_l1_ = 280
	l1111l11111l_l1_ = 28
	l1lll11111ll1_l1_ = 5
	l111l1111ll1_l1_ = 0
	l1llll1ll1lll_l1_ = 31
	l111l111l11l_l1_ = [36,32,28]
	if l1111l1lll11_l1_ in [l11l1l_l1_ (u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨ浩"),l11l1l_l1_ (u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡷࡻࡴ࡮ࡡ࡭ࡨࡶࠫ浪")]:
		if l1111l1lll11_l1_==l11l1l_l1_ (u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡸࡼࡵࡨࡢ࡮ࡩࡷࠬ浫"):
			l11l1111llll_l1_ = l11l1l_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ浬")
			l11l111l11l1_l1_ = l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࠬ浭")
			l1llll1l111ll_l1_ = True
			l1llll1l1l1l1_l1_ = 10
		else:
			l11l1111llll_l1_ = 97+20
			l11l111l11l1_l1_ = l11l1l_l1_ (u"ࠧ࡭ࡧࡩࡸࠬ浮")
			l1llll1l111ll_l1_ = False
		l111l111l11l_l1_ = [33,33,33]
		l1lllll1l1l11_l1_ = 20
		l1ll1lll1lll1_l1_ = 0
		l111l1l111l1_l1_ = 20
		l1lll11l11111_l1_ = 25+10
	elif l1111l1lll11_l1_==l11l1l_l1_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ浯"): l11l1111llll_l1_ = 500
	elif l1111l1lll11_l1_==l11l1l_l1_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭浰"): l111l111l11l_l1_ = [28,23,18] ; l11l1111llll_l1_ = 500
	elif l1111l1lll11_l1_==l11l1l_l1_ (u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭浱"): l11l1111llll_l1_ = 740
	elif l1111l1lll11_l1_==l11l1l_l1_ (u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ浲"): l11l1111llll_l1_ = l11l1l_l1_ (u"࡛ࠬࡐࡑࡇࡕࠫ浳")
	elif l1111l1lll11_l1_==l11l1l_l1_ (u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡵࡰࡥࡱࡲࡦࡰࡰࡷࠫ浴"): l111l111l11l_l1_ = [28,23,18] ; l11l1111llll_l1_ = 740
	elif l1111l1lll11_l1_==l11l1l_l1_ (u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ浵"): l111l111l11l_l1_ = [28,23,18] ; l11l1111llll_l1_ = l11l1l_l1_ (u"ࠨࡗࡓࡔࡊࡘࠧ浶")
	l11111l11l11_l1_ = l111l111l11l_l1_[0]
	l111l11ll111_l1_ = l111l111l11l_l1_[1]
	l11l1111l1ll_l1_ = l111l111l11l_l1_[2]
	l11111l1ll11_l1_ = PIL.ImageFont.truetype(l11111l1l1ll_l1_,size=l11111l11l11_l1_)
	l1lllll1ll1ll_l1_ = PIL.ImageFont.truetype(l11111l1l1ll_l1_,size=l111l11ll111_l1_)
	l1lllllll11l1_l1_ = PIL.ImageFont.truetype(l11111l1l1ll_l1_,size=l11l1111l1ll_l1_)
	txt = PIL.Image.new(l11l1l_l1_ (u"ࠩࡕࡋࡇࡇࠧ海"),(100,100),(255,255,255,0))
	l1111lll1l11_l1_ = PIL.ImageDraw.Draw(txt)
	l1111ll111ll_l1_,l1llll1111l11_l1_ = l1111lll1l11_l1_.textsize(l11l1l_l1_ (u"ࠪࡌࡍࡎࠠࡃࡄࡅࠤ࠽࠾࠸ࠡ࠲࠳࠴ࠬ浸"),font=l1lllll1ll1ll_l1_)
	l1111111l11l_l1_,l1111l111ll1_l1_ = l1111lll1l11_l1_.textsize(l11l1l_l1_ (u"ࠫࡍࡎࡈࠡࡄࡅࡆࠥ࠾࠸࠹ࠢ࠳࠴࠵࠭浹"),font=l11111l1ll11_l1_)
	l1lll1111llll_l1_ = header.count(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ浺"))+1
	l1lll1llll111_l1_ = l1ll1lll1lll1_l1_+l1lll1111llll_l1_*(l1111l111ll1_l1_+l1llll1l1l1l1_l1_)-l1llll1l1l1l1_l1_
	l1llll11l1ll1_l1_ = {l11l1l_l1_ (u"࠭ࡤࡦ࡮ࡨࡸࡪࡥࡨࡢࡴࡤ࡯ࡦࡺࠧ浻"):False,l11l1l_l1_ (u"ࠧࡴࡷࡳࡴࡴࡸࡴࡠ࡮࡬࡫ࡦࡺࡵࡳࡧࡶࠫ浼"):True,l11l1l_l1_ (u"ࠨࡃࡕࡅࡇࡏࡃࠡࡎࡌࡋࡆ࡚ࡕࡓࡇࠣࡅࡑࡒࡁࡉࠩ浽"):False}
	l111ll11l1l1_l1_ = arabic_reshaper.ArabicReshaper(configuration=l1llll11l1ll1_l1_)
	if text:
		l11l1111l111_l1_ = l1llll11l11l1_l1_-l111l1l111l1_l1_*2
		l1lll111llll1_l1_ = l1llll1111l11_l1_+l1lllll11ll1l_l1_
		l1llll11ll1ll_l1_ = l111ll11l1l1_l1_.reshape(text)
		if l1llll1l111ll_l1_:
			l1ll1ll1l1l11_l1_ = l1llllll1111l_l1_(l1llll11ll1ll_l1_,l111l11ll111_l1_,l11l1111l111_l1_,l1lll111llll1_l1_)
			l1111111l111_l1_ = l1llll111111l_l1_(l1ll1ll1l1l11_l1_)
			l1llll11l1l11_l1_ = l1111111l111_l1_.count(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ浾"))+1
			if l1llll11l1l11_l1_<6:
				if l1llll11l1l11_l1_<4: l1lll11lll11l_l1_ = int(0.8*l11l1111l111_l1_)
				else: l1lll11lll11l_l1_ = int(0.9*l11l1111l111_l1_)
				l1ll1ll1l1l11_l1_ = l1llllll1111l_l1_(l1llll11ll1ll_l1_,l111l11ll111_l1_,l1lll11lll11l_l1_,l1lll111llll1_l1_)
				l1111111l111_l1_ = l1llll111111l_l1_(l1ll1ll1l1l11_l1_)
				l1llll11l1l11_l1_ = l1111111l111_l1_.count(l11l1l_l1_ (u"ࠪࡠࡳ࠭浿"))+1
			l111lll111ll_l1_ = l1lll11l11111_l1_+l1llll11l1l11_l1_*l1lll111llll1_l1_-l1lllll11ll1l_l1_
		else:
			l111lll111ll_l1_ = l1lll11l11111_l1_+l1llll1111l11_l1_
			l1111111l111_l1_ = l1llll11ll1ll_l1_.split(l11l1l_l1_ (u"ࠫࡡࡴࠧ涀"))[0]
			l1ll1ll1l1l11_l1_ = l1llll11ll1ll_l1_.split(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ涁"))[0]
	else: l111lll111ll_l1_ = l1lll11l11111_l1_
	l1llll1ll1111_l1_ = l111l1111ll1_l1_+l1llll1ll1lll_l1_
	if l1lll1lll1l1l_l1_:
		l1lll1l1l111l_l1_ = l1ll1lllll111_l1_-l1lll11ll1ll1_l1_
		l1llll1ll1111_l1_ += l1lll1l1l111l_l1_
	else: l1lll1l1l111l_l1_ = 0
	if l1111l11ll11_l1_ or l1lll11ll1l1l_l1_ or l1111l1l111l_l1_: l1llll1ll1111_l1_ += l1llllll1ll1l_l1_
	if l11l1111llll_l1_!=l11l1l_l1_ (u"࠭ࡕࡑࡒࡈࡖࠬ涂"): l111l11111ll_l1_ = l11l1111llll_l1_
	else: l111l11111ll_l1_ = l1lll1llll111_l1_+l111lll111ll_l1_+l1llll1ll1111_l1_
	l1llllllllll1_l1_ = l111l11111ll_l1_-l1lll1llll111_l1_-l1llll1ll1111_l1_-l1lll11l11111_l1_
	txt = PIL.Image.new(l11l1l_l1_ (u"ࠧࡓࡉࡅࡅࠬ涃"),(l1llll11l11l1_l1_,l111l11111ll_l1_),(255,255,255,0))
	l1111lll1l11_l1_ = PIL.ImageDraw.Draw(txt)
	if not l1lll11ll1l1l_l1_ and l1111l11ll11_l1_ and l1111l1l111l_l1_:
		l1111l11111l_l1_ += 105
		l1lll11111ll1_l1_ -= 110
	if header:
		l1111ll1ll11_l1_ = l1ll1lll1lll1_l1_
		header = bidi.algorithm.get_display(l111ll11l1l1_l1_.reshape(header))
		lines = header.splitlines()
		for line in lines:
			if line:
				width,l1l111llll1l_l1_ = l1111lll1l11_l1_.textsize(line,font=l11111l1ll11_l1_)
				if l11l111l11l1_l1_==l11l1l_l1_ (u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ涄"): l1lll11lllll1_l1_ = l1111ll1l1ll_l1_+(l1llll11l11l1_l1_-width)/2
				elif l11l111l11l1_l1_==l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ涅"): l1lll11lllll1_l1_ = l1111ll1l1ll_l1_+l1llll11l11l1_l1_-width-l1lllll1l1l11_l1_
				elif l11l111l11l1_l1_==l11l1l_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ涆"): l1lll11lllll1_l1_ = l1111ll1l1ll_l1_+l1lllll1l1l11_l1_
				l1111lll1l11_l1_.text((l1lll11lllll1_l1_,l1111ll1ll11_l1_),line,font=l11111l1ll11_l1_,fill=l11l1l_l1_ (u"ࠫࡾ࡫࡬࡭ࡱࡺࠫ涇"))
			l1111ll1ll11_l1_ += l11111l11l11_l1_+l1llll1l1l1l1_l1_
	if l1111l11ll11_l1_ or l1lll11ll1l1l_l1_ or l1111l1l111l_l1_:
		l1111l1111l1_l1_ = l1lll1llll111_l1_+l1llllllllll1_l1_+l1lll11l11111_l1_+l1lll1l1l111l_l1_+l111l1111ll1_l1_
		if l1111l11ll11_l1_:
			l1111l11ll11_l1_ = bidi.algorithm.get_display(l111ll11l1l1_l1_.reshape(l1111l11ll11_l1_))
			l1llll111l111_l1_,l111l111111l_l1_ = l1111lll1l11_l1_.textsize(l1111l11ll11_l1_,font=l1lllllll11l1_l1_)
			l111l111l111_l1_ = l1111l11111l_l1_+0*(l1lll11111ll1_l1_+l1lll1ll11l1l_l1_)+(l1lll1ll11l1l_l1_-l1llll111l111_l1_)/2
			l1111lll1l11_l1_.text((l111l111l111_l1_,l1111l1111l1_l1_),l1111l11ll11_l1_,font=l1lllllll11l1_l1_,fill=l11l1l_l1_ (u"ࠬࡿࡥ࡭࡮ࡲࡻࠬ消"))
		if l1lll11ll1l1l_l1_:
			l1lll11ll1l1l_l1_ = bidi.algorithm.get_display(l111ll11l1l1_l1_.reshape(l1lll11ll1l1l_l1_))
			l1lllll11lll1_l1_,l111ll1ll11l_l1_ = l1111lll1l11_l1_.textsize(l1lll11ll1l1l_l1_,font=l1lllllll11l1_l1_)
			l111l11l1lll_l1_ = l1111l11111l_l1_+1*(l1lll11111ll1_l1_+l1lll1ll11l1l_l1_)+(l1lll1ll11l1l_l1_-l1lllll11lll1_l1_)/2
			l1111lll1l11_l1_.text((l111l11l1lll_l1_,l1111l1111l1_l1_),l1lll11ll1l1l_l1_,font=l1lllllll11l1_l1_,fill=l11l1l_l1_ (u"࠭ࡹࡦ࡮࡯ࡳࡼ࠭涉"))
		if l1111l1l111l_l1_:
			l1111l1l111l_l1_ = bidi.algorithm.get_display(l111ll11l1l1_l1_.reshape(l1111l1l111l_l1_))
			l111l1llllll_l1_,l1111l111l1l_l1_ = l1111lll1l11_l1_.textsize(l1111l1l111l_l1_,font=l1lllllll11l1_l1_)
			l111111ll111_l1_ = l1111l11111l_l1_+2*(l1lll11111ll1_l1_+l1lll1ll11l1l_l1_)+(l1lll1ll11l1l_l1_-l111l1llllll_l1_)/2
			l1111lll1l11_l1_.text((l111111ll111_l1_,l1111l1111l1_l1_),l1111l1l111l_l1_,font=l1lllllll11l1_l1_,fill=l11l1l_l1_ (u"ࠧࡺࡧ࡯ࡰࡴࡽࠧ涊"))
	if text:
		l1ll1lll1l11l_l1_,l111ll1111ll_l1_ = [],[]
		l1ll1ll1l1l11_l1_ = l111l1ll1111_l1_(l1ll1ll1l1l11_l1_)
		l1lll111lllll_l1_ = l1ll1ll1l1l11_l1_.split(l11l1l_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࡯ࡧࡺࡰ࡮ࡴࡥࡠࠩ涋"))
		for l1ll1llllll1l_l1_ in l1lll111lllll_l1_:
			l111lll11lll_l1_ = l111ll1l11l1_l1_
			if   l11l1l_l1_ (u"ࠩࡢࡷࡸࡹ࡟ࡠ࡮࡬ࡲࡪࡲࡥࡧࡶࡢࠫ涌") in l1ll1llllll1l_l1_: l111lll11lll_l1_ = l11l1l_l1_ (u"ࠪࡰࡪ࡬ࡴࠨ涍")
			elif l11l1l_l1_ (u"ࠫࡤࡹࡳࡴࡡࡢࡰ࡮ࡴࡥࡳ࡫ࡪ࡬ࡹࡥࠧ涎") in l1ll1llllll1l_l1_: l111lll11lll_l1_ = l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ涏")
			elif l11l1l_l1_ (u"࠭࡟ࡴࡵࡶࡣࡤࡲࡩ࡯ࡧࡦࡩࡳࡺࡥࡳࡡࠪ涐") in l1ll1llllll1l_l1_: l111lll11lll_l1_ = l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ涑")
			l111lll1lll1_l1_ = l1ll1llllll1l_l1_
			l1llll1lll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡡࡶࡷࡸࡥ࡟࠯ࠬࡂࡣࠬ涒"),l1ll1llllll1l_l1_,re.DOTALL)
			for tag in l1llll1lll1ll_l1_: l111lll1lll1_l1_ = l111lll1lll1_l1_.replace(tag,l11l1l_l1_ (u"ࠩࠪ涓"))
			if l111lll1lll1_l1_==l11l1l_l1_ (u"ࠪࠫ涔"): width,l1l111llll1l_l1_ = 0,l1lll111llll1_l1_
			else: width,l1l111llll1l_l1_ = l1111lll1l11_l1_.textsize(l111lll1lll1_l1_,font=l1lllll1ll1ll_l1_)
			if   l111lll11lll_l1_==l11l1l_l1_ (u"ࠫࡱ࡫ࡦࡵࠩ涕"): l11111ll1ll1_l1_ = l1lll1111ll1l_l1_+l111l1l111l1_l1_
			elif l111lll11lll_l1_==l11l1l_l1_ (u"ࠬࡸࡩࡨࡪࡷࠫ涖"): l11111ll1ll1_l1_ = l1lll1111ll1l_l1_+l111l1l111l1_l1_+l11l1111l111_l1_-width
			elif l111lll11lll_l1_==l11l1l_l1_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭涗"): l11111ll1ll1_l1_ = l1lll1111ll1l_l1_+l111l1l111l1_l1_+(l11l1111l111_l1_-width)/2
			if l11111ll1ll1_l1_<l111l1l111l1_l1_: l11111ll1ll1_l1_ = l1lll1111ll1l_l1_+l111l1l111l1_l1_
			l1ll1lll1l11l_l1_.append(l11111ll1ll1_l1_)
			l111ll1111ll_l1_.append(width)
		l11111ll1ll1_l1_ = l1ll1lll1l11l_l1_[0]
		l1lll11lll1ll_l1_ = l1ll1ll1l1l11_l1_.split(l11l1l_l1_ (u"ࠧࡠࡵࡶࡷࡤ࠭涘"))
		l111lllll1ll_l1_ = (255,255,255,255)
		l1llllll11111_l1_ = l111lllll1ll_l1_
		l1lll111lll1l_l1_,l1lllll111lll_l1_ = 0,0
		l111111l1ll1_l1_ = False
		l1111l1ll111_l1_ = 0
		l1lll1111lll1_l1_ = l1lll1llll111_l1_+l1lll11l11111_l1_/2
		if l111lll111ll_l1_<(l1llllllllll1_l1_+l1lll11l11111_l1_):
			l1111ll1l111_l1_ = (l1llllllllll1_l1_+l1lll11l11111_l1_-l111lll111ll_l1_)/2
			l1lll1111lll1_l1_ = l1lll1llll111_l1_+l1lll11l11111_l1_+l1111ll1l111_l1_-l1llll1111l11_l1_/2
		for line in l1lll11lll1ll_l1_:
			if not line or (line and ord(line[0])==65279): continue
			l1lll1l11ll11_l1_ = line.split(l11l1l_l1_ (u"ࠨࡡࡱࡩࡼࡲࡩ࡯ࡧࡢࠫ涙"),1)
			l1lll1l11ll1l_l1_ = line.split(l11l1l_l1_ (u"ࠩࡢࡲࡪࡽࡣࡰ࡮ࡲࡶࠬ涚"),1)
			l1lll1l11lll1_l1_ = line.split(l11l1l_l1_ (u"ࠪࡣࡪࡴࡤࡤࡱ࡯ࡳࡷࡥࠧ涛"),1)
			l1llllll1ll11_l1_ = line.split(l11l1l_l1_ (u"ࠫࡤࡲࡩ࡯ࡧࡵࡸࡱࡥࠧ涜"),1)
			l1llllll1llll_l1_ = line.split(l11l1l_l1_ (u"ࠬࡥ࡬ࡪࡰࡨࡰࡪ࡬ࡴࡠࠩ涝"),1)
			l1lll1l11l1l1_l1_ = line.split(l11l1l_l1_ (u"࠭࡟࡭࡫ࡱࡩࡷ࡯ࡧࡩࡶࡢࠫ涞"),1)
			l1lll1l11l1ll_l1_ = line.split(l11l1l_l1_ (u"ࠧࡠ࡮࡬ࡲࡪࡩࡥ࡯ࡶࡨࡶࡤ࠭涟"),1)
			if len(l1lll1l11ll11_l1_)>1:
				l1111l1ll111_l1_ += 1
				line = l1lll1l11ll11_l1_[1]
				l1lll111lll1l_l1_ = 0
				l11111ll1ll1_l1_ = l1ll1lll1l11l_l1_[l1111l1ll111_l1_]
				l1lllll111lll_l1_ += l1lll111llll1_l1_
				l111111l1ll1_l1_ = False
			elif len(l1lll1l11ll1l_l1_)>1:
				line = l1lll1l11ll1l_l1_[1]
				l1llllll11111_l1_ = line[0:8]
				l1llllll11111_l1_ = l11l1l_l1_ (u"ࠨࠥࠪ涠")+l1llllll11111_l1_[2:]
				line = line[9:]
			elif len(l1lll1l11lll1_l1_)>1:
				line = l1lll1l11lll1_l1_[1]
				l1llllll11111_l1_ = l111lllll1ll_l1_
			elif len(l1llllll1ll11_l1_)>1:
				line = l1llllll1ll11_l1_[1]
				l111111l1ll1_l1_ = True
				l1lll111lll1l_l1_ = l111ll1111ll_l1_[l1111l1ll111_l1_]
			elif len(l1llllll1llll_l1_)>1:
				line = l1llllll1llll_l1_[1]
			elif len(l1lll1l11l1l1_l1_)>1:
				line = l1lll1l11l1l1_l1_[1]
			elif len(l1lll1l11l1ll_l1_)>1:
				line = l1lll1l11l1ll_l1_[1]
			if line:
				l1lll1ll11l11_l1_ = l1lll1111lll1_l1_+l1lllll111lll_l1_
				line = bidi.algorithm.get_display(line)
				width,l1l111llll1l_l1_ = l1111lll1l11_l1_.textsize(line,font=l1lllll1ll1ll_l1_)
				if l111111l1ll1_l1_: l1lll111lll1l_l1_ -= width
				l11111ll1l1l_l1_ = l11111ll1ll1_l1_+l1lll111lll1l_l1_
				l1111lll1l11_l1_.text((l11111ll1l1l_l1_,l1lll1ll11l11_l1_),line,font=l1lllll1ll1ll_l1_,fill=l1llllll11111_l1_)
				if not l111111l1ll1_l1_: l1lll111lll1l_l1_ += width
				if l1lll1ll11l11_l1_>l1llllllllll1_l1_+l1lll111llll1_l1_: break
	l11111111lll_l1_ = l1ll1lll1llll_l1_.replace(l11l1l_l1_ (u"ࠩࡢ࠴࠵࠶࠰ࡠࠩ涡"),l11l1l_l1_ (u"ࠪࡣࠬ涢")+str(time.time())+l11l1l_l1_ (u"ࠫࡤ࠭涣"))
	l11111111lll_l1_ = l11111111lll_l1_.replace(l11l1l_l1_ (u"ࠬࡢ࡜ࠨ涤"),l11l1l_l1_ (u"࠭࡜࡝࡞࡟ࠫ涥")).replace(l11l1l_l1_ (u"ࠧ࠰࠱ࠪ润"),l11l1l_l1_ (u"ࠨ࠱࠲࠳࠴࠭涧"))
	if not os.path.exists(addoncachefolder): os.makedirs(addoncachefolder)
	txt.save(l11111111lll_l1_)
	return l11111111lll_l1_,l111l11111ll_l1_
def l111llll11ll_l1_(cc):
	cc.execute(l11l1l_l1_ (u"ࠩࡓࡖࡆࡍࡍࡂࠢࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡧࡤ࡯࡮ࡥࡧࡻࡁࡳࡵ࠻ࠨ涨"))
	cc.execute(l11l1l_l1_ (u"ࠪࡔࡗࡇࡇࡎࡃࠣࡪࡴࡸࡥࡪࡩࡱࡣࡰ࡫ࡹࡴ࠿ࡱࡳࡀ࠭涩"))
	cc.execute(l11l1l_l1_ (u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭涪"))
	cc.execute(l11l1l_l1_ (u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩ涫"))
	cc.execute(l11l1l_l1_ (u"࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࡀࡑࡊࡓࡏࡓ࡛࠾ࠫ涬"))
	cc.execute(l11l1l_l1_ (u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪ涭"))
	return
def WRITE_TO_SQL3(l1l1l1l11l_l1_,table,l1lll1111ll11_l1_,data,l1l1l1llll11_l1_,l1lllll1l1lll_l1_=False):
	cache = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡨࡧࡣࡩࡧ࠱ࡷࡹࡧࡴࡶࡵࠪ涮"))
	if cache==l11l1l_l1_ (u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ涯") and l1l1l1llll11_l1_>l11ll1ll11ll_l1_: l1l1l1llll11_l1_ = l11ll1ll11ll_l1_
	if l1lllll1l1lll_l1_:
		l11l1l11l_l1_,l11l1l1l1_l1_ = [],[]
		for l11l1l1ll1_l1_ in range(len(l1lll1111ll11_l1_)):
			text = pickle.dumps(data[l11l1l1ll1_l1_])
			l1ll1lll111l1_l1_ = zlib.compress(text)
			l11l1l11l_l1_.append((l1lll1111ll11_l1_[l11l1l1ll1_l1_],))
			l11l1l1l1_l1_.append((l1l1l1llll11_l1_+now,str(l1lll1111ll11_l1_[l11l1l1ll1_l1_]),l1ll1lll111l1_l1_))
	else:
		text = pickle.dumps(data)
		l111ll1l1l1l_l1_ = zlib.compress(text)
	conn = sqlite3.connect(l1l1l1l11l_l1_)
	cc = conn.cursor()
	l111llll11ll_l1_(cc)
	conn.text_factory = str
	while True:
		try:
			cc.execute(l11l1l_l1_ (u"ࠪࡆࡊࡍࡉࡏࠢࡌࡑࡒࡋࡄࡊࡃࡗࡉ࡚ࠥࡒࡂࡐࡖࡅࡈ࡚ࡉࡐࡐࠣ࠿ࠬ涰"))
			break
		except: time.sleep(0.5)
	cc.execute(l11l1l_l1_ (u"ࠫࡈࡘࡅࡂࡖࡈࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡎࡐࡖࠣࡉ࡝ࡏࡓࡕࡕࠣࠦࠬ涱")+table+l11l1l_l1_ (u"ࠬࠨࠠࠩࡧࡻࡴ࡮ࡸࡹ࠭ࡥࡲࡰࡺࡳ࡮࠭ࡦࡤࡸࡦ࠯ࠠ࠼ࠩ液"))
	if l1lllll1l1lll_l1_:
		cc.executemany(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭涳")+table+l11l1l_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ涴"),l11l1l11l_l1_)
		cc.executemany(l11l1l_l1_ (u"ࠨࡋࡑࡗࡊࡘࡔࠡࡋࡑࡘࡔࠦࠢࠨ涵")+table+l11l1l_l1_ (u"ࠩࠥࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠭ࠥࡁࠧ涶"),l11l1l1l1_l1_)
	else:
		if l1l1l1llll11_l1_:
			tt = (str(l1lll1111ll11_l1_),)
			cc.execute(l11l1l_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ涷")+table+l11l1l_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ涸"),tt)
			tt = (l1l1l1llll11_l1_+now,str(l1lll1111ll11_l1_),l111ll1l1l1l_l1_)
			cc.execute(l11l1l_l1_ (u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ涹")+table+l11l1l_l1_ (u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ涺"),tt)
		else:
			tt = (l111ll1l1l1l_l1_,str(l1lll1111ll11_l1_))
			cc.execute(l11l1l_l1_ (u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࠣࠩ涻")+table+l11l1l_l1_ (u"ࠨࠤࠣࡗࡊ࡚ࠠࡥࡣࡷࡥࠥࡃࠠࡀ࡚ࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ涼"),tt)
	conn.commit()
	conn.close()
	return
def READ_FROM_SQL3(l1l1l1l11l_l1_,l1lll111ll11l_l1_,table,l1lll1111ll11_l1_=None):
	data = l111ll11ll1l_l1_(l1lll111ll11l_l1_)
	l1l11l1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡸࡥࡧࡴࡨࡷ࡭࠴ࡳࡵࡣࡷࡹࡸ࠭涽"))
	if l1l11l1l1l_l1_==l11l1l_l1_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࡉࡉ࠭涾") and table!=l11l1l_l1_ (u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ涿") and l1l1l1l11l_l1_==main_dbfile:
		DELETE_FROM_SQL3(l1l1l1l11l_l1_,table,l1lll1111ll11_l1_)
		return data
	l11l111l1l11_l1_ = 0
	cache = settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡥࡤࡧ࡭࡫࠮ࡴࡶࡤࡸࡺࡹࠧ淀"))
	if cache==l11l1l_l1_ (u"࠭ࡓࡕࡑࡓࠫ淁"): return data
	elif cache==l11l1l_l1_ (u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ淂"): l11l111l1l11_l1_ = l11ll1ll11ll_l1_
	conn = sqlite3.connect(l1l1l1l11l_l1_)
	cc = conn.cursor()
	l111llll11ll_l1_(cc)
	conn.text_factory = str
	l1llll1l111l1_l1_ = True
	try: cc.execute(l11l1l_l1_ (u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠤࠪ淃")+table+l11l1l_l1_ (u"ࠩࠥࠤࡑࡏࡍࡊࡖࠣ࠵ࠥࡁࠧ淄"))
	except: l1llll1l111l1_l1_ = False
	if l1llll1l111l1_l1_:
		if l11l111l1l11_l1_: cc.execute(l11l1l_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ淅")+table+l11l1l_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥ࡫ࡸࡱ࡫ࡵࡽࡃ࠭淆")+str(now+l11l111l1l11_l1_)+l11l1l_l1_ (u"ࠬࠦ࠻ࠨ淇"))
		conn.commit()
		cc.execute(l11l1l_l1_ (u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭淈")+table+l11l1l_l1_ (u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡧࡻࡴ࡮ࡸࡹ࠽ࠩ淉")+str(now)+l11l1l_l1_ (u"ࠨࠢ࠾ࠫ淊"))
		conn.commit()
		if l1lll1111ll11_l1_:
			tt = (str(l1lll1111ll11_l1_),)
			cc.execute(l11l1l_l1_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ淋")+table+l11l1l_l1_ (u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ淌"),tt)
			l11llll1l1ll_l1_ = cc.fetchall()
			if l11llll1l1ll_l1_:
				try:
					text = zlib.decompress(l11llll1l1ll_l1_[0][0])
					data = pickle.loads(text)
				except: pass
		else:
			cc.execute(l11l1l_l1_ (u"ࠫࡘࡋࡌࡆࡅࡗࠤࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩ淍")+table+l11l1l_l1_ (u"ࠬࠨࠠ࠼ࠩ淎"))
			l11llll1l1ll_l1_ = cc.fetchall()
			if l11llll1l1ll_l1_:
				data,l1llllll11ll1_l1_ = {},[]
				for l1lllll11ll11_l1_,l11l1llll_l1_ in l11llll1l1ll_l1_:
					l1l1l11l11_l1_ = zlib.decompress(l11l1llll_l1_)
					l11l1llll_l1_ = pickle.loads(l1l1l11l11_l1_)
					data[l1lllll11ll11_l1_] = l11l1llll_l1_
					l1llllll11ll1_l1_.append(l1lllll11ll11_l1_)
				if l1llllll11ll1_l1_:
					data[l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ淏")] = l1llllll11ll1_l1_
					if l1lll111ll11l_l1_==l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬ淐"): data = l1llllll11ll1_l1_
	conn.close()
	return data
def DELETE_FROM_SQL3(l1l1l1l11l_l1_,table,l1lll1111ll11_l1_=None):
	conn = sqlite3.connect(l1l1l1l11l_l1_)
	cc = conn.cursor()
	l111llll11ll_l1_(cc)
	conn.text_factory = str
	if l1lll1111ll11_l1_==None: cc.execute(l11l1l_l1_ (u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪ淑")+table+l11l1l_l1_ (u"ࠩࠥࠤࡀ࠭淒"))
	else:
		tt = (str(l1lll1111ll11_l1_),)
		try: cc.execute(l11l1l_l1_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ淓")+table+l11l1l_l1_ (u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ淔"),tt)
		except: pass
	conn.commit()
	conn.close()
	return
def l1lll1111111_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1ll1l1_l1_=True,l1llll1111l1l_l1_=True):
	# should l1l11111llll_l1_ ==l11l1l_l1_ (u"ࠬ࠭淕") l11111l11l_l1_ not l111lll1l1_l1_ it to l11l1l_l1_ (u"࠭࡮ࡰࡶࠪ淖")
	if allow_redirects==l11l1l_l1_ (u"ࠧࠨ淗"): allow_redirects = True
	if l1ll_l1_==l11l1l_l1_ (u"ࠨࠩ淘"): l1ll_l1_ = True
	if l111ll1ll1l1_l1_==l11l1l_l1_ (u"ࠩࠪ淙"): l111ll1ll1l1_l1_ = True
	if l1llll1111l1l_l1_==l11l1l_l1_ (u"ࠪࠫ淚"): l1llll1111l1l_l1_ = True
	if not data: data = {}
	if not headers: headers = {}
	if l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ淛") not in list(headers.keys()): headers[l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ淜")] = l11l1l_l1_ (u"࠭ࡀࡁࡂࡖࡏࡎࡖ࡟ࡉࡇࡄࡈࡊࡘࡀࡁࡂࠪ淝")
	l111l1l_l1_,l1lll11l111ll_l1_,l1llll1111lll_l1_,l1llll11ll11l_l1_ = l1lll11ll11ll_l1_(url)
	l1ll1lll1ll1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡨࡳࡹ࠮ࡴࡧࡵࡺࡪࡸࠧ淞"))
	l1lll111l1ll1_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ淟"))
	l1lll11l1ll1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ淠"))
	l1ll1llll1l1l_l1_ = (l1lll11l111ll_l1_==None and l1llll1111lll_l1_==None and l1llll11ll11l_l1_==None)
	l1111ll1l11l_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"ࠪࡔ࡞࡚ࡈࡐࡐࠪ淡")]
	l1lll111l1l11_l1_ = l111l1l_l1_ in l1111ll1l11l_l1_
	l1111lll1ll1_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"ࠫࡗࡋࡐࡐࡕࠪ淢")]
	l111ll1llll1_l1_ = l111l1l_l1_ in l1111lll1ll1_l1_
	l1111lllll11_l1_ = l1lll111l1l11_l1_ or l111ll1llll1_l1_
	if l1ll1llll1l1l_l1_ and l1111lllll11_l1_:
		if l1lll111l1l11_l1_:
			l1ll1lll11ll1_l1_ = l1111ll1l11l_l1_.index(l111l1l_l1_)
			l11111ll1lll_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩ淣")][l1ll1lll11ll1_l1_]
			l1111l1l1l11_l1_ = l1l11l11ll11_l1_[l1ll1lll11ll1_l1_]
		elif l111ll1llll1_l1_:
			l1ll1lll11ll1_l1_ = l1111lll1ll1_l1_.index(l111l1l_l1_)
			l11111ll1lll_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩ淤")][l1ll1lll11ll1_l1_]
			l1111l1l1l11_l1_ = l111l11lll1l_l1_[l1ll1lll11ll1_l1_]
	if l1llll1111lll_l1_==l11l1l_l1_ (u"ࠧࠨ淥"): l1llll1111lll_l1_ = l1ll1lll1ll1l_l1_
	elif l1llll1111lll_l1_==None and l1lll111l1ll1_l1_ in [l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭淦"),l11l1l_l1_ (u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫ淧")] and l111ll1ll1l1_l1_: l1llll1111lll_l1_ = l1ll1lll1ll1l_l1_
	if l1lll111l1l11_l1_ or l111ll1llll1_l1_: timeout = 10
	elif l11l1l_l1_ (u"ࠪࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠭淨") in source: timeout = 15
	elif l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ淩") in source: timeout = 25
	elif l11l1l_l1_ (u"ࠬࡇࡋࡘࡃࡐࠫ淪") in source: timeout = 20
	elif source in l1111lll1l1l_l1_: timeout = 5
	else: timeout = 10
	if l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ淫") in source and not data and l11l1l_l1_ (u"ࠧࠧࠩ淬") not in l111l1l_l1_ and l11l1l_l1_ (u"ࠨࡁࠪ淭") not in l111l1l_l1_: l111l1l_l1_ = l111l1l_l1_.rstrip(l11l1l_l1_ (u"ࠩ࠲ࠫ淮"))+l11l1l_l1_ (u"ࠪ࠳ࠬ淯")
	l111lll1111l_l1_ = (l1lll11l111ll_l1_!=None)
	l1lll1lllll11_l1_ = (l1llll1111lll_l1_!=None and l1lll111l1ll1_l1_!=l11l1l_l1_ (u"ࠫࡘ࡚ࡏࡑࠩ淰"))
	if l111lll1111l_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠬะแฺ์็ࠤอื่ไีํࠤึ่ๅࠨ深"),l1lll11l111ll_l1_)
	elif l1lll1lllll11_l1_: l1llll1l_l1_(l11l1l_l1_ (u"࠭สโ฻ํ่ࠥࡊࡎࡔࠢิๆ๊࠭淲"),l1llll1111lll_l1_)
	if l111lll1111l_l1_:
		proxies = {l11l1l_l1_ (u"ࠢࡩࡶࡷࡴࠧ淳"):l1lll11l111ll_l1_,l11l1l_l1_ (u"ࠣࡪࡷࡸࡵࡹࠢ淴"):l1lll11l111ll_l1_}
		l11111111l1l_l1_ = l1lll11l111ll_l1_
	else: proxies,l11111111l1l_l1_ = {},l11l1l_l1_ (u"ࠩࠪ淵")
	if l1lll1lllll11_l1_:
		import urllib3.util.connection as connection
		l111l11l11ll_l1_ = l1ll1llllll11_l1_(connection,l1ll1lll1ll1l_l1_)
	verify = True
	l1lll11lll111_l1_,l1l1ll1l1ll1_l1_,l11l1ll1l_l1_,l111lll1ll1l_l1_,l111ll1lllll_l1_ = allow_redirects,source,method,False,False
	if l1111lllll11_l1_ or (method==l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ淶") and allow_redirects): l1lll11lll111_l1_ = False
	if l1lll111l1l11_l1_: l11l1ll1l_l1_ = l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ混")
	import requests
	for l11l1l1ll1_l1_ in range(7):
		succeeded = False
		try:
			if l11l1l1ll1_l1_: l1l1ll1l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࠯࠴ࡷࡹ࠭淸")
			if not l111lll1111l_l1_: l1llll1ll1l1l_l1_(False,l111l1l_l1_,data,headers,l1l1ll1l1ll1_l1_,l11l1ll1l_l1_)
			try: response.close()
			except: pass
			l111ll1_l1_ = l111l1l_l1_
			response = requests.request(l11l1ll1l_l1_,l111l1l_l1_,data=data,headers=headers,verify=verify,allow_redirects=l1lll11lll111_l1_,timeout=timeout,proxies=proxies)
			if 300<=response.status_code<=399:
				if not l111lll1ll1l_l1_:
					if l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ淹") in list(response.headers.keys()): l111l1l_l1_ = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ淺")]
					elif l11l1l_l1_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪ添") in list(response.headers.keys()): l111l1l_l1_ = response.headers[l11l1l_l1_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫ淼")]
					else: l111lll1ll1l_l1_ = True
					if l1111lllll11_l1_ and response.status_code==307:
						l1lll11lll111_l1_ = allow_redirects
						l11l1ll1l_l1_ = method
						l111lll1ll1l_l1_ = True
						continue
				if not l111lll1ll1l_l1_ or allow_redirects:
					if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ淽") not in l111l1l_l1_:
						server = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ淾"))
						l111l1l_l1_ = server+l111l1l_l1_
				if not l111lll1ll1l_l1_ and allow_redirects:
					l111ll1111_l1_ = l11l1l11l1_l1_(l111l1l_l1_)
					if l111ll1111_l1_ not in [l11l1l_l1_ (u"ࠬ࠴ࡡࡷ࡫ࠪ淿"),l11l1l_l1_ (u"࠭࠮ࡵࡵࠪ渀"),l11l1l_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ渁"),l11l1l_l1_ (u"ࠨ࠰ࡰ࡯ࡻ࠭渂"),l11l1l_l1_ (u"ࠩ࠱ࡪࡱࡼࠧ渃"),l11l1l_l1_ (u"ࠪ࠲ࡲࡶ࠳ࠨ渄"),l11l1l_l1_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪ清")]: continue
			elif 550<=response.status_code<=599:
				response.reason = response.content
				l111ll1lllll_l1_ = True
			l111ll1_l1_ = response.url
			code = response.status_code
			reason = response.reason
			# raise_for_status will write a log line: l11l1l_l1_ (u"ࠧࡔ࡯࡯ࡧࡗࡽࡵ࡫࠺ࠡࡐࡲࡲࡪࠨ渆")
			response.raise_for_status()
			succeeded = True
		except requests.exceptions.HTTPError as err:
			pass
		except requests.exceptions.Timeout as err:
			code = -1
			if kodi_version<19: reason = str(err.message).split(l11l1l_l1_ (u"࠭࠺ࠡࠩ渇"))[1]
			else: reason = str(err).split(l11l1l_l1_ (u"ࠧ࠻ࠢࠪ済"))[1]
		except requests.exceptions.ConnectionError as err:
			code = -1
			reason = l11l1l_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ渉")
			try:
				error = err.message[0]
				reason = error
				if l11l1l_l1_ (u"ࠩࡈࡶࡷࡴ࡯ࠨ渊") in error: code,reason = re.findall(l11l1l_l1_ (u"ࠥࡠࡠࡋࡲࡳࡰࡲࠤ࠭ࡢࡤࠬࠫ࡟ࡡࠥ࠮࠮ࠫࡁࠬࠫࠧ渋"),error)[0]
				elif l11l1l_l1_ (u"ࠫ࠱ࠦࡥࡳࡴࡲࡶ࠭࠭渌") in error: code,reason = re.findall(l11l1l_l1_ (u"ࠧ࠲ࠠࡦࡴࡵࡳࡷࡢࠨࠩ࡞ࡧ࠯࠮࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣ渍"),error)[0]
				elif error.count(l11l1l_l1_ (u"࠭࠺ࠨ渎"))>=2: reason,code = re.findall(l11l1l_l1_ (u"ࠧ࠻ࠢࠫ࠲࠯ࡅࠩ࠻࠰࠭ࡃ࠭ࡢࡤࠬࠫࠪ渏"),error)[0]
			except: pass
		except requests.exceptions.RequestException as err:
			code = -1
			if kodi_version<19: reason = err.message
			else: reason = str(err)
		except:
			code = -1
			reason = l11l1l_l1_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ渐")
		if l1111lllll11_l1_ and not l111ll1lllll_l1_ and code!=200:
			l111l1l_l1_ = l11111ll1lll_l1_
			l111ll1lllll_l1_ = True
			continue
		break
	if l1llll1111lll_l1_!=None and l1lll111l1ll1_l1_!=l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ渑"): connection.create_connection = l111l11l11ll_l1_
	if l1lll111l1ll1_l1_==l11l1l_l1_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ渒") and l111ll1ll1l1_l1_: l1llll1111lll_l1_ = None
	if not succeeded and l1lll11l111ll_l1_==None and source not in l1111lll1l1l_l1_:
		l1ll1lllll1l_l1_ = traceback.format_exc()
		sys.stderr.write(l1ll1lllll1l_l1_)
	else: pass
	code = int(code)
	l1l1llll1_l1_ = l1111lll11l1_l1_()
	l1l1llll1_l1_.code = code
	l1l1llll1_l1_.reason = reason
	try: l1l1llll1_l1_.content = response.content
	except: l1l1llll1_l1_.content = l11l1l_l1_ (u"ࠫࠬ渓")
	if kodi_version>18.99:
		try: l1l1llll1_l1_.content = l1l1llll1_l1_.content.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ渔"))
		except: pass
	l1lll111l1lll_l1_ = l11l1l_l1_ (u"࠭ࠧ渕")
	if kodi_version<19 or isinstance(l1l1llll1_l1_.content,str):
		l1lll111l1lll_l1_ = l1l1llll1_l1_.content.lower()
	if succeeded:
		l1l1llll1_l1_.succeeded = True
		l1l1llll1_l1_.headers 	= response.headers
		l1l1llll1_l1_.cookies 	= response.cookies
		l1l1llll1_l1_.url 	= l111ll1_l1_
	try: response.close()
	except: pass
	l1l1111l1ll_l1_ = (l11l1l_l1_ (u"ࠧࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ渖") in l1lll111l1lll_l1_ or l11l1l_l1_ (u"ࠨࡩࡲࡳ࡬ࡲࡥࠨ渗") in l1lll111l1lll_l1_) and l1lll111l1lll_l1_.count(l11l1l_l1_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ渘"))>2 and l11l1l_l1_ (u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ渙") not in source
	if code==200 and l1l1111l1ll_l1_: l1l1llll1_l1_.succeeded = False
	#WRITE_THIS(l11l1l_l1_ (u"ࠫࠬ渚"),l1lll111l1lll_l1_)
	if not l1l1llll1_l1_.succeeded and l1ll1llll1l1l_l1_:
		if l1111lllll11_l1_:
			l1l1lll1l_l1_ = l11l1111l11l_l1_(l1111l1l1l11_l1_,l111ll1ll1l1_l1_,l1llll1111l1l_l1_)
		if source in l1111lll1l1l_l1_:
			LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ減"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡘࡲ࡮ࡳࡰࡰࡴࡷࡥࡳࡺࠠࡳࡧࡴࡹࡪࡹࡴࠡࡨࡤ࡭ࡱ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ渜")+l111l1l_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ渝")+source+l11l1l_l1_ (u"ࠨࠢࡠࠫ渞"))
		else:
			l11ll1ll1ll_l1_ = (l11l1l_l1_ (u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭渟") in l1lll111l1lll_l1_ and l11l1l_l1_ (u"ࠪࡶࡦࡿࠠࡪࡦ࠽ࠤࠬ渠") in l1lll111l1lll_l1_)
			l11111ll111l_l1_ = (l11l1l_l1_ (u"ࠫ࠺ࠦࡳࡦࡥࠪ渡") in l1lll111l1lll_l1_ and l11l1l_l1_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭渢") in l1lll111l1lll_l1_)
			l1lllll11l1l1_l1_ = (code in [403] and l11l1l_l1_ (u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩ渣") in l1lll111l1lll_l1_)
			l1lllll11l1ll_l1_ = (l11l1l_l1_ (u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩ渤") in l1lll111l1lll_l1_ and l11l1l_l1_ (u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬ渥") in l1lll111l1lll_l1_)
			if   l1l1111l1ll_l1_: reason = l11l1l_l1_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩ渦")
			elif l11ll1ll1ll_l1_: reason = l11l1l_l1_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ渧")
			elif l11111ll111l_l1_: reason = l11l1l_l1_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ渨")
			elif l1lllll11l1l1_l1_: reason = l11l1l_l1_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡡࡤࡥࡨࡷࡸࠦࡤࡦࡰ࡬ࡩࡩ࠭温")
			elif l1lllll11l1ll_l1_: reason = l11l1l_l1_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨ渪")
			else: reason = str(reason)
			if l11l1l_l1_ (u"ࠧࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗࠫ渫") not in source:
				LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭測"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭渭")+str(code)+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ渮")+reason+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭港")+source+l11l1l_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ渰")+l111l1l_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ渱"))
			l11111l1l111_l1_ = l1llll_l1_(l111l1l_l1_)
			if kodi_version<19 and isinstance(l11111l1l111_l1_,unicode): l11111l1l111_l1_ = l11111l1l111_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ渲"))
			if l1111lllll11_l1_: l11111l1l111_l1_ = l11111l1l111_l1_.split(l11l1l_l1_ (u"ࠨ࠱ࠪ渳"))[-1]
			reason = str(reason)+l11l1l_l1_ (u"ࠩ࡟ࡲ࠭ࠦࠧ渴")+l11111l1l111_l1_+l11l1l_l1_ (u"ࠪࠤ࠮࠭渵")
			if l1l1111l1ll_l1_ or l11ll1ll1ll_l1_ or l11111ll111l_l1_ or l1lllll11l1l1_l1_ or l1lllll11l1ll_l1_:
				code = -2
				l1l1llll1_l1_.code = code
				l1l1llll1_l1_.reason = reason
			l1ll111111_l1_ = True
			if (l1lll111l1ll1_l1_==l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ渶") or l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠬࡇࡓࡌࠩ渷")) and source not in l1111lll1l1l_l1_:
				l1ll111111_l1_ = l1llllll11l11_l1_(code,reason,source,l1ll_l1_)
				if l1ll111111_l1_ and l1lll111l1ll1_l1_==l11l1l_l1_ (u"࠭ࡁࡔࡍࠪ游"): l1lll111l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ渹")
				else: l1lll111l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ渺")
				if l1ll111111_l1_ and l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠩࡄࡗࡐ࠭渻"): l1lll11l1ll1l_l1_ = l11l1l_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ渼")
				else: l1lll11l1ll1l_l1_ = l11l1l_l1_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭渽")
				settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ渾"),l1lll111l1ll1_l1_)
				settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ渿"),l1lll11l1ll1l_l1_)
			if l1ll111111_l1_:
				l1ll1llll11l1_l1_ = True
				if code==8 and l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭湀") in l111l1l_l1_ and l1ll1llll11l1_l1_:
					if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠨฬไ฽๏๊ࠠโฯุࠤูํวะหࠣห้ะิโ์ิࠤࡘ࡙ࡌࠨ湁"),l11l1l_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ湂"),time=2000)
					l111ll1_l1_ = l111l1l_l1_+l11l1l_l1_ (u"ࠪࢀࢁࡓࡹࡔࡕࡏ࡙ࡷࡲ࠽ࠨ湃")
					l1l1lll1l_l1_ = l1lll1111111_l1_(method,l111ll1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
					if l1l1lll1l_l1_.succeeded:
						l1l1llll1_l1_ = l1l1lll1l_l1_
						LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ湄"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧࠤࡺࡹࡩ࡯ࡩࠣࡗࡘࡒ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ湅")+source+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ湆")+url+l11l1l_l1_ (u"ࠧࠡ࡟ࠪ湇"))
						if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠨ่ฯหาࠦศศีอาิอๅࠡࡕࡖࡐࠬ湈"),l11l1l_l1_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ湉"),time=2000)
					else:
						LOG_THIS(l11l1l_l1_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ湊"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡓࡔࡎ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ湋")+source+l11l1l_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ湌")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ湍"))
						if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠧโึ็ࠤออำหะาห๊ࠦࡓࡔࡎࠪ湎"),l11l1l_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ湏"),time=2000)
				if not l1l1llll1_l1_.succeeded and l1lll11l1ll1l_l1_ in [l11l1l_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ湐"),l11l1l_l1_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ湑")] and l1llll1111l1l_l1_:
					if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาษอࠤอื่ไีํࠫ湒"),l11l1l_l1_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ湓"),time=2000)
					l1l1lll1l_l1_ = l111ll1ll1ll_l1_(method,l111l1l_l1_,data,headers,allow_redirects,l1ll_l1_,source)
					if l1l1lll1l_l1_.succeeded:
						l1l1llll1_l1_ = l1l1lll1l_l1_
						LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ湔"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ湕")+source+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ湖")+url+l11l1l_l1_ (u"ࠩࠣࡡࠬ湗"))
						if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩ湘"),l11l1l_l1_ (u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭湙"),time=2000)
					else:
						LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ湚"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡓࡶࡴࡾࡩࡦࡵࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ湛")+source+l11l1l_l1_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭湜")+url+l11l1l_l1_ (u"ࠨࠢࡠࠫ湝"))
						if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠩไุ้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧ湞"),l11l1l_l1_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ湟"),time=2000)
				if not l1l1llll1_l1_.succeeded and l1lll111l1ll1_l1_ in [l11l1l_l1_ (u"ࠫࡆ࡛ࡔࡐࠩ湠"),l11l1l_l1_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ湡")] and l111ll1ll1l1_l1_:
					if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"࠭สโ฻ํู่๊ࠥาใิࠤࡉࡔࡓࠨ湢"),l11l1l_l1_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ湣"),time=2000)
					l111ll1_l1_ = l111l1l_l1_+l11l1l_l1_ (u"ࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭湤")
					l1l1lll1l_l1_ = l1lll1111111_l1_(method,l111ll1_l1_,data,headers,allow_redirects,l1ll_l1_,source)
					if l1l1lll1l_l1_.succeeded:
						l1l1llll1_l1_ = l1l1lll1l_l1_
						LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ湥"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࡀࠠࠡࠢࡇࡒࡘࡀࠠ࡜ࠢࠪ湦")+l1ll1lll1ll1l_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭湧")+source+l11l1l_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ湨")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ湩"))
						if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠧ็ฮสัู๊ࠥาใิࠤࡉࡔࡓࠨ湪"),l11l1l_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ湫"),time=2000)
					else:
						LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ湬"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧ湭")+l1ll1lll1ll1l_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭湮")+source+l11l1l_l1_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ湯")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ湰"))
						if l1ll_l1_: l1llll1l_l1_(l11l1l_l1_ (u"ࠧโึ็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧ湱"),l11l1l_l1_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ湲"),time=2000)
			if l1lll11l1ll1l_l1_==l11l1l_l1_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ湳") or l1lll111l1ll1_l1_==l11l1l_l1_ (u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬ湴"): l1ll_l1_ = False
			if not l1l1llll1_l1_.succeeded:
				if l1ll_l1_: l111llll11l1_l1_ = l1llllll11l11_l1_(code,reason,source,l1ll_l1_)
				if code!=200 and source not in l111l1l1lll1_l1_ and l11l1l_l1_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨ湵") not in source:
					l111111l1lll_l1_(l11l1l_l1_ (u"ࠬࡌ࡯ࡳࡥࡨࡨࠥ࡫ࡸࡪࡶࠣࡨࡺ࡫ࠠࡵࡱࠣࡲࡪࡺࡷࡰࡴ࡮ࠤ࡮ࡹࡳࡶࡧࡶࠤࡼ࡯ࡴࡩ࠼ࠣࠫ湶")+source)
	if settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭湷")) not in [l11l1l_l1_ (u"ࠧࡂࡗࡗࡓࠬ湸"),l11l1l_l1_ (u"ࠨࡕࡗࡓࡕ࠭湹"),l11l1l_l1_ (u"ࠩࡄࡗࡐ࠭湺")]: settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ湻"),l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ湼"))
	if settings.getSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮ࡴࡶࡤࡸࡺࡹࠧ湽")) not in [l11l1l_l1_ (u"࠭ࡁࡖࡖࡒࠫ湾"),l11l1l_l1_ (u"ࠧࡔࡖࡒࡔࠬ湿"),l11l1l_l1_ (u"ࠨࡃࡖࡏࠬ満")]: settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡶࡲࡰࡺࡼ࠲ࡸࡺࡡࡵࡷࡶࠫ溁"),l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ溂"))
	return l1l1llll1_l1_
def OPENURL_REQUESTS_CACHED(l1l1l1llll11_l1_,method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1ll1l1_l1_=True,l1llll1111l1l_l1_=True):
	item = method,url,data,headers,allow_redirects,l1ll_l1_
	response = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭溃"),l11l1l_l1_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ溄"),item)
	if response.succeeded:
		l1llll1ll1l1l_l1_(True,url,data,headers,source,method)
		return response
	response = l1lll1111111_l1_(method,url,data,headers,allow_redirects,l1ll_l1_,source,l111ll1ll1l1_l1_,l1llll1111l1l_l1_)
	if response.succeeded:
		if l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧ溅") in source: response.content = DECODE_ADILBO_HTML(response.content)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪ溆"),item,response,l1l1l1llll11_l1_)
	return response
def OPENURL_CACHED(l1l1l1llll11_l1_,url,data,headers,l1ll_l1_,source):
	if not data or isinstance(data,dict): method = l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ溇")
	else:
		method = l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ溈")
		data = l1llll_l1_(data)
		dummy,data = l1lll111l1_l1_(data)
	response = OPENURL_REQUESTS_CACHED(l1l1l1llll11_l1_,method,url,data,headers,True,l1ll_l1_,source)
	html = response.content
	#html = html.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ溉"))
	html = str(html)
	return html
def l1lll11ll11ll_l1_(url):
	l1lll11l1ll11_l1_ = url.split(l11l1l_l1_ (u"ࠫࢁࢂࠧ溊"))
	l111l1l_l1_,l1lll11l111ll_l1_,l1llll1111lll_l1_,l1llll11ll11l_l1_ = l1lll11l1ll11_l1_[0],None,None,None
	for item in l1lll11l1ll11_l1_:
		if l11l1l_l1_ (u"ࠬࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪ溋") in item: l1lll11l111ll_l1_ = item.split(l11l1l_l1_ (u"࠭࠽ࠨ溌"))[1]
		elif l11l1l_l1_ (u"ࠧࡎࡻࡇࡒࡘ࡛ࡲ࡭࠿ࠪ溍") in item: l1llll1111lll_l1_ = item.split(l11l1l_l1_ (u"ࠨ࠿ࠪ溎"))[1]
		elif l11l1l_l1_ (u"ࠩࡐࡽࡘ࡙ࡌࡖࡴ࡯ࡁࠬ溏") in item: l1llll11ll11l_l1_ = item.split(l11l1l_l1_ (u"ࠪࡁࠬ源"))[1]
	return l111l1l_l1_,l1lll11l111ll_l1_,l1llll1111lll_l1_,l1llll11ll11l_l1_
def RESTORE_PATH_NAME(name):
	start,l1l1llllll1_l1_,modified = l11l1l_l1_ (u"ࠫࠬ溑"),l11l1l_l1_ (u"ࠬ࠭溒"),l11l1l_l1_ (u"࠭ࠧ溓")
	name = name.replace(ltr,l11l1l_l1_ (u"ࠧࠨ溔")).replace(rtl,l11l1l_l1_ (u"ࠨࠩ溕"))
	tmp = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠮ࡢ࡛ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡝࡟ࠫࡠࡼࡢࡷ࡝ࡹࠬࠤ࠰ࡢ࡛࡝࠱ࡆࡓࡑࡕࡒ࡝࡟ࠫ࠲࠯ࡅࠩࠥࠩ準"),name,re.DOTALL)
	if tmp: start,l1l1llllll1_l1_,name = tmp[0]
	if start not in [l11l1l_l1_ (u"ࠪࠤࠬ溗"),l11l1l_l1_ (u"ࠫ࠱࠭溘"),l11l1l_l1_ (u"ࠬ࠭溙")]: modified = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ溚")
	if l1l1llllll1_l1_: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠧࡠࠩ溛")+l1l1llllll1_l1_+l11l1l_l1_ (u"ࠨࡡࠪ溜")
	#datetime = re.findall(l11l1l_l1_ (u"ࠩࠫࡣࡡࡪ࡜ࡥ࡞࠱ࡠࡩࡢࡤࡠ࡞ࡧࡠࡩࡢ࠺࡝ࡦ࡟ࡨࡤ࠯ࠧ溝"),name,re.DOTALL)
	#if datetime: name = name.replace(datetime[0],l11l1l_l1_ (u"ࠪࠫ溞"))
	name = l1l1llllll1_l1_+modified+name
	return name
def l1ll1l111ll_l1_(l1l11lll_l1_,l1lll1ll1l1ll_l1_,l1lll1llll11l_l1_):
	l111llll111l_l1_ = l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭溟")+l1lll1ll1l1ll_l1_
	l1l1ll1_l1_ = settings.getSetting(l111llll111l_l1_)
	if not l1l1ll1_l1_: l1l1ll1_l1_ = l1l11lll_l1_
	for l11l1l1ll1_l1_ in range(3):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ溠"),l1l1ll1_l1_,l11l1l_l1_ (u"࠭ࠧ溡"),l11l1l_l1_ (u"ࠧࠨ溢"),l11l1l_l1_ (u"ࠨࠩ溣"),l11l1l_l1_ (u"ࠩࠪ溤"),l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠴ࡷࡹ࠭溥"))
		if response.succeeded: break
		else:
			url = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩ溦")+l1lll1llll11l_l1_
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ溧"),url,l11l1l_l1_ (u"࠭ࠧ溨"),l11l1l_l1_ (u"ࠧࠨ溩"),l11l1l_l1_ (u"ࠨࠩ溪"),l11l1l_l1_ (u"ࠩࠪ溫"),l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭溬"))
			if response.succeeded:
				html = response.content
				if kodi_version>18.99: html = html.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ溭"),l11l1l_l1_ (u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ溮"))
				l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡨࡏ࡬࠴ࠥࡱࡃࡳ࡛ࡗࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࡝࠱ࡸࡶࡱࡢ࠿ࡲ࠿ࠫ࠲࠯ࡅࠩࠣࠩ溯"),html,re.DOTALL)
				if l1llll1_l1_:
					l1l111l1llll_l1_ = SERVER(l1llll1_l1_[0],l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ溰"))
					if l1l111l1llll_l1_!=l1l1ll1_l1_:
						LOG_THIS(l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭溱"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡍ࡯ࡰࡩ࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࡳ࡫ࡷࠡࡪࡲࡷࡹࡴࡡ࡮ࡧࠣࠤ࡙ࠥࡩࡵࡧ࠽ࠤࡠࠦࠧ溲")+l1lll1ll1l1ll_l1_+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡐࡨࡻ࠿࡛ࠦࠡࠩ溳")+l1l111l1llll_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩ溴")+l1l1ll1_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠨ溵"))
						l1l1ll1_l1_ = l1l111l1llll_l1_
						settings.setSetting(l111llll111l_l1_,l1l111l1llll_l1_)
	return l1l1ll1_l1_
def LOG_THIS(level,message):
	l1lll1lll1111_l1_ = l111l1111lll_l1_
	lines = [l11l1l_l1_ (u"࠭ࠧ溶"),l11l1l_l1_ (u"ࠧࠨ溷")]
	if level:
		message = message.replace(l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠࠫ溸"),l11l1l_l1_ (u"ࠩࠪ溹")).replace(l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭溺"),l11l1l_l1_ (u"ࠫࠬ溻"))
		message = message.replace(l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ溼"),l11l1l_l1_ (u"࠭ࠧ溽"))
	else: level = l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ溾")
	if level==l11l1l_l1_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭溿"):
		l1lll1lll1111_l1_ = xbmc.LOGERROR
		lines = message.strip(l11l1l_l1_ (u"ࠩ࠱ࠤࠥࠦࠧ滀")).split(l11l1l_l1_ (u"ࠪࠤࠥࠦࠧ滁"))
	elif level==l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ滂"):
		lines = message.strip(l11l1l_l1_ (u"ࠬ࠴ࠠࠡࠢࠪ滃")).split(l11l1l_l1_ (u"࠭ࠠࠡࠢࠪ滄"))
	elif level==l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ滅"):
		lines = message.split(l11l1l_l1_ (u"ࠨࠢࠣࠤࠥ࠭滆"))
	l111l111l1_l1_ = l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ滇")
	l1ll1ll1l1l1l_l1_ = l111l111l1_l1_+l111l111l1_l1_+l111l111l1_l1_
	shift = l1ll1ll1l1l1l_l1_+l1ll1ll1l1l1l_l1_
	if kodi_version>17.99: shift = shift+l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠨ滈")
	l111lll1l1l1_l1_ = lines[0]
	for line in lines[1:]:
		if l11l1l_l1_ (u"ࠫࡡࡴࠧ滉") in line: line = line.replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ滊"),l11l1l_l1_ (u"࠭࡜࡯ࠩ滋")+l111l111l1_l1_+l111l111l1_l1_)
		l1ll1ll1l1l1l_l1_ = l1ll1ll1l1l1l_l1_+l111l111l1_l1_
		l111lll1l1l1_l1_ += l11l1l_l1_ (u"ࠧ࡝ࡴࠪ滌")+shift+l1ll1ll1l1l1l_l1_+line
	l111lll1l1l1_l1_ += l11l1l_l1_ (u"ࠨࠢࡢࠫ滍")
	if l11l1l_l1_ (u"ࠩࠨࠫ滎") in l111lll1l1l1_l1_: l111lll1l1l1_l1_ = l1llll_l1_(l111lll1l1l1_l1_)
	xbmc.log(l111lll1l1l1_l1_,level=l1lll1lll1111_l1_)
	return
def l1llll1ll1l1l_l1_(l111l1l1l1l1_l1_,url,data,headers,source,method):
	l1l1l1ll1_l1_ = str(headers)[0:250].replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭滏"),l11l1l_l1_ (u"ࠫࡡࡢ࡮ࠨ滐")).replace(l11l1l_l1_ (u"ࠬࡢࡲࠨ滑"),l11l1l_l1_ (u"࠭࡜࡝ࡴࠪ滒")).replace(l11l1l_l1_ (u"ࠧࠡࠢࠣࠤࠬ滓"),l11l1l_l1_ (u"ࠨࠢࠪ滔")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠥ࠭滕"),l11l1l_l1_ (u"ࠪࠤࠬ滖"))
	if len(str(headers))>250: l1l1l1ll1_l1_ = l1l1l1ll1_l1_+l11l1l_l1_ (u"ࠫࠥ࠴࠮࠯ࠩ滗")
	l11l1llll_l1_ = str(data)[0:250].replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ滘"),l11l1l_l1_ (u"࠭࡜࡝ࡰࠪ滙")).replace(l11l1l_l1_ (u"ࠧ࡝ࡴࠪ滚"),l11l1l_l1_ (u"ࠨ࡞࡟ࡶࠬ滛")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠥࠦࠧ滜"),l11l1l_l1_ (u"ࠪࠤࠬ滝")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠠࠨ滞"),l11l1l_l1_ (u"ࠬࠦࠧ滟"))
	if len(str(data))>250: l11l1llll_l1_ = l11l1llll_l1_+l11l1l_l1_ (u"࠭ࠠ࠯࠰࠱ࠫ滠")
	if l111l1l1l1l1_l1_: LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ满"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡗ࡫ࡡࡥ࡫ࡱ࡫ࠥࡉࡁࡄࡊࡈ࠾ࠥࡡࠠࠨ滢")+url+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ滣")+source+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡨࡸ࡭ࡵࡤ࠻ࠢ࡞ࠤࠬ滤")+method+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ滥")+str(l1l1l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡦࡺࡡ࠻ࠢ࡞ࠤࠬ滦")+l11l1llll_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ滧"))
	else: LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ滨"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࠤࡔࡶࡥ࡯࡫ࡱ࡫࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭滩")+url+l11l1l_l1_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ滪")+source+l11l1l_l1_ (u"ࠪࠤࡢࠦࠠࠡࡏࡨࡸ࡭ࡵࡤ࠻ࠢ࡞ࠤࠬ滫")+method+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ滬")+str(l1l1l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡦࡺࡡ࠻ࠢ࡞ࠤࠬ滭")+l11l1llll_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ滮"))
	return
def TRANSLATE(text):
	dict = {
	 l11l1l_l1_ (u"ࠧࡰ࡮ࡧࠫ滯")			:l11l1l_l1_ (u"ࠨไา๎๊࠭滰")
	,l11l1l_l1_ (u"ࠩࡧ࡭ࡸࡧࡢ࡭ࡧࡧࠫ滱")		:l11l1l_l1_ (u"้ࠪฯ๎โโࠩ滲")
	,l11l1l_l1_ (u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ滳")		:l11l1l_l1_ (u"๋ࠬแใ๊าࠫ滴")
	,l11l1l_l1_ (u"࠭ࡧࡰࡱࡧࠫ滵")			:l11l1l_l1_ (u"ࠧอ์าࠫ滶")
	,l11l1l_l1_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ滷")		:l11l1l_l1_ (u"ࠩไุ้࠭滸")
	,l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ滹")		:l11l1l_l1_ (u"๊ࠫาไะࠩ滺")
	,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ滻")		:l11l1l_l1_ (u"࠭แ๋ัํ์ࠬ滼")
	,l11l1l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ滽")			:l11l1l_l1_ (u"ࠨไ้หฮ࠭滾")
	,l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍࠨ滿")		:l11l1l_l1_ (u"้ࠪํู่ࠡลๆ์ฬ๋ࠠศๆๅำ๏๋ࠧ漀")
	,l11l1l_l1_ (u"ࠫࡆࡑࡗࡂࡏࠪ漁")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣว่๎วๆࠢส่ัี๊ะࠩ漂")
	,l11l1l_l1_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨ漃")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤ่อๅࠨ漄")
	,l11l1l_l1_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ漅")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠไๆࠣห้฿ัษࠩ漆")
	,l11l1l_l1_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ漇")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢส่๊์ศาࠢส่ๆอืๆ์ࠪ漈")
	,l11l1l_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ漉")	:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤ็์วสࠢส่่๎หาࠩ漊")
	,l11l1l_l1_ (u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩ漋")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤฬ๊ๅฺษิๅࠬ漌")
	,l11l1l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝ࠫ漍")		:l11l1l_l1_ (u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫ漎")
	,l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨ漏")	:l11l1l_l1_ (u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦࡶࡪࡲࠪ漐")
	,l11l1l_l1_ (u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨ漑")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥอไิ์้้ฬ࠭漒")
	,l11l1l_l1_ (u"ࠨࡊࡈࡐࡆࡒࠧ漓")		:l11l1l_l1_ (u"่ࠩ์็฿่ࠠๆส่ࠥ๐่ห์๋ฬࠬ演")
	,l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬ漕")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬ漖")
	,l11l1l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ漗")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨ漘")
	,l11l1l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ漙")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨ漚")
	,l11l1l_l1_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫ漛")		:l11l1l_l1_ (u"้ࠪํู่ࠡ฻ิฬู๊๋ࠥัࠪ漜")
	,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ漝")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣื๏๋ว่ࠡส์ࠬ漞")
	,l11l1l_l1_ (u"࠭ࡋࡂࡔࡅࡅࡑࡇࡔࡗࠩ漟")	:l11l1l_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪ漠")
	,l11l1l_l1_ (u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ漡")	:l11l1l_l1_ (u"่ࠩ์ฬู่ࠡ์๋ฮ๏๎ศࠨ漢")
	,l11l1l_l1_ (u"ࠪࡑ࡞ࡉࡉࡎࡃࠪ漣")		:l11l1l_l1_ (u"๊ࠫ๎โฺ่ࠢห๏ࠦำ๋็สࠫ漤")
	,l11l1l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅࠬ漥")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤํ๐ࠠิ์่หࠬ漦")
	,l11l1l_l1_ (u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩ漧")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊ร้ๆࠪ漨")
	,l11l1l_l1_ (u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ漩")		:l11l1l_l1_ (u"้ࠪํู่ࠡใสู้ࠦวๅอส๊๏࠭漪")
	,l11l1l_l1_ (u"ࠫࡇࡕࡋࡓࡃࠪ漫")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣฬ่ืวࠨ漬")
	,l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ漭")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨ漮")
	,l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖࠨ漯")		:l11l1l_l1_ (u"่่ࠩๆ࠭漰")
	,l11l1l_l1_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜ࠫ漱")		:l11l1l_l1_ (u"๊๊ࠫแࠨ漲")
	,l11l1l_l1_ (u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ漳")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤ๊๎แำࠢไ์ึ๐่ࠨ漴")
	,l11l1l_l1_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ漵")	:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦแอำุࠣํ࠭漶")
	,l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ漷")		:l11l1l_l1_ (u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠫ漸")
	,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ漹")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧ漺")
	,l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡑࡓ࡜࠭漻")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥห๊อ์๊ࠣฬ๎ࠧ漼")
	,l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩ漽")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠฦ์ฯ๎ࠥี๊ะࠩ漾")
	,l11l1l_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬ漿")		:l11l1l_l1_ (u"๊ࠫ๎โฺ๊่ࠢฬࠦำ๋็สࠫ潀")
	,l11l1l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭潁")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬ潂")
	,l11l1l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠭潃")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨ潄")
	,l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ潅")	:l11l1l_l1_ (u"้ࠪํู่ࠡีํ้ฬࠦไศ์อࠫ潆")
	,l11l1l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ潇")	:l11l1l_l1_ (u"๋่ࠬใ฻ุࠣฬํฯ่ࠡํ์ื࠭潈")
	,l11l1l_l1_ (u"࠭ࡆࡐࡕࡗࡅࠬ潉")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥ็่ิฬสࠫ潊")
	,l11l1l_l1_ (u"ࠨࡃࡋ࡛ࡆࡑࠧ潋")		:l11l1l_l1_ (u"่ࠩ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫ潌")
	,l11l1l_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ潍")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢไฬึ้ษࠨ潎")
	,l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ潏")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧ潐")
	,l11l1l_l1_ (u"ࠧࡔࡊࡒࡊࡍࡇࠧ潑")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦิ้ใ๊หࠥะ๊โ์ࠪ潒")
	,l11l1l_l1_ (u"ࠩࡅࡖࡘ࡚ࡅࡋࠩ潓")		:l11l1l_l1_ (u"้ࠪํู่ࠡสิืฯ๐ฬࠨ潔")
	,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬ潕")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡ࠶࠳࠴ࠬ潖")
	,l11l1l_l1_ (u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭潗")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽๊ࠥวา๊ีหࠬ潘")
	,l11l1l_l1_ (u"ࠨ࡛ࡄࡕࡔ࡚ࠧ潙")		:l11l1l_l1_ (u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭潚")
	,l11l1l_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬ潛")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢๆฮ่๎สࠨ潜")
	,l11l1l_l1_ (u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪ潝")	:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨ潞")
	,l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨ潟")		:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦฯาษ่หࠥ฻อࠨ潠")
	,l11l1l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡑࡔࡒࠫ潡")		:l11l1l_l1_ (u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩ潢")
	,l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭潣")		:l11l1l_l1_ (u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭潤")
	,l11l1l_l1_ (u"࠭ࡉࡇࡋࡏࡑࠬ潥")				:l11l1l_l1_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫ潦")
	,l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ潧")			:l11l1l_l1_ (u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํู่๊ࠦาสํࠫ潨")
	,l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪ潩")		:l11l1l_l1_ (u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡษ้ะ้๐า๋ࠩ潪")
	,l11l1l_l1_ (u"ࠬࡏࡐࡕࡘࠪ潫")					:l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙ࠫ潬")
	,l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚࠲ࡒࡉࡗࡇࠪ潭")			:l11l1l_l1_ (u"ࠨࡋࡓࡘ࡛ࠦโ็๊สฮࠬ潮")
	,l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ潯")			:l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖࠡลไ่ฬ๋ࠧ潰")
	,l11l1l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ潱")			:l11l1l_l1_ (u"ࠬࡏࡐࡕࡘุ้๊ࠣำๅษอࠫ潲")
	,l11l1l_l1_ (u"࠭ࡍ࠴ࡗࠪ潳")					:l11l1l_l1_ (u"ࠧࡎ࠵ࡘࠫ潴")
	,l11l1l_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ潵")				:l11l1l_l1_ (u"ࠩࡐ࠷࡚ࠦโ็๊สฮࠬ潶")
	,l11l1l_l1_ (u"ࠪࡑ࠸࡛࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ潷")			:l11l1l_l1_ (u"ࠫࡒ࠹ࡕࠡลไ่ฬ๋ࠧ潸")
	,l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡖࡉࡗࡏࡅࡔࠩ潹")			:l11l1l_l1_ (u"࠭ࡍ࠴ࡗุ้๊ࠣำๅษอࠫ潺")
	,l11l1l_l1_ (u"ࠧࡑࡃࡑࡉ࡙࠭潻")				:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠬ潼")
	,l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡏࡒ࡚ࡎࡋࡓࠨ潽")			:l11l1l_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠠศใ็ห๊࠭潾")
	,l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡘࡉࡆࡕࠪ潿")			:l11l1l_l1_ (u"๋่ࠬใ฻ࠣฬฬ์๊ห่ࠢืู้ไศฬࠪ澀")
	,l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ澁")				:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬ澂")
	,l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯࡙ࡍࡉࡋࡏࡔࠩ澃")		:l11l1l_l1_ (u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩ澄")
	,l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ澅")	:l11l1l_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨ澆")
	,l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ澇")		:l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็์่ศฬࠪ澈")
	,l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ澉")			:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠪ澊")
	,l11l1l_l1_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘ࠭澋")	:l11l1l_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อ่ࠥวาศࠪ澌")
	,l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡂࡎࡅ࡙ࡒ࡙ࠧ澍")		:l11l1l_l1_ (u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭澎")
	,l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄ࡙ࡉࡏࡏࡔࠩ澏")		:l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩ澐")
	,l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭澑")			:l11l1l_l1_ (u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠪ澒")
	,l11l1l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ澓")	:l11l1l_l1_ (u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧ澔")
	,l11l1l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭澕"):l11l1l_l1_ (u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠠใ๊สส๊࠭澖")
	,l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ澗")	:l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็ࠢๅ๊ํอสࠨ澘")
	,l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡕࡑࡓࡍࡈ࡙ࠧ澙")	:l11l1l_l1_ (u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ๊๎วื์฼ࠫ澚")
	}
	if text in list(dict.keys()): return dict[text]
	return l11l1l_l1_ (u"ࠫࠬ澛")
def LOGGING(l1ll1_l1_):
	l1llll111lll1_l1_ = sys._getframe(1).f_code.co_name
	if l1ll1_l1_==l11l1l_l1_ (u"ࠬࡓࡁࡊࡐࡐࡉࡓ࡛ࠧ澜") and l1llll111lll1_l1_==l11l1l_l1_ (u"࠭ࡍࡂࡋࡑࡑࡊࡔࡕࠨ澝"):
		return l11l1l_l1_ (u"ࠧ࡜ࠢࠪ澞")+l1lll11ll1lll_l1_.upper()+l11l1l_l1_ (u"ࠨ࠯ࠪ澟")+addon_version+l11l1l_l1_ (u"ࠩ࠰ࠫ澠")+l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠱ࠬ澡")+l1llll111lll1_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ澢")
	return l11l1l_l1_ (u"ࠬ࠴ࠠࠡࠢࠪ澣")+l1llll111lll1_l1_
def l111111l1lll_l1_(message):
	l1lll1llll1l1_l1_(l11l1l_l1_ (u"࠭࡟ࡠࡈࡒࡖࡈࡋࡄࡠࡇ࡛ࡍ࡙ࡥ࡟ࠨ澤")+message)
	sys.exit()
	return
def QUOTE(urll,exceptions=l11l1l_l1_ (u"ࠧ࠻࠱ࠪ澥")):
	return _1lllll1ll11l_l1_(urll,exceptions)
	#return urllib2.quote(urll,ignore)
def l1llll_l1_(urll):
	return _111ll11l11l_l1_(urll)
	#return urllib2.unquote(urll)
def l111l111ll11_l1_(l1l111l11_l1_):
	if l1l111l11_l1_ in [l11l1l_l1_ (u"ࠨࠩ澦"),l11l1l_l1_ (u"ࠩ࠳ࠫ澧"),0]: return l11l1l_l1_ (u"ࠪࠫ澨")
	l1l111l11_l1_ = int(l1l111l11_l1_)
	first = l1l111l11_l1_^l1llll11_l1_
	second = l1l111l11_l1_^REGULAR_CACHE
	l1ll1ll11_l1_ = l1l111l11_l1_^l1ll1l1ll_l1_
	result = str(first)+str(second)+str(l1ll1ll11_l1_)
	return result
def l1lll111111l1_l1_(l1l111l11_l1_):
	if l1l111l11_l1_ in [l11l1l_l1_ (u"ࠫࠬ澩"),l11l1l_l1_ (u"ࠬ࠶ࠧ澪"),0]: return l11l1l_l1_ (u"࠭ࠧ澫")
	l1l111l11_l1_ = str(l1l111l11_l1_)
	result = l11l1l_l1_ (u"ࠧࠨ澬")
	if len(l1l111l11_l1_)==15:
		first,second,l1ll1ll11_l1_ = l1l111l11_l1_[0:4],l1l111l11_l1_[4:9],l1l111l11_l1_[9:]
		first = int(first)^l1ll1l1ll_l1_
		second = int(second)^REGULAR_CACHE
		l1ll1ll11_l1_ = int(l1ll1ll11_l1_)^l1llll11_l1_
		if first==second==l1ll1ll11_l1_: result = str(first*60)
	return result
def l1lll1lllll1l_l1_(l1l111l11_l1_):
	if l1l111l11_l1_ in [l11l1l_l1_ (u"ࠨࠩ澭"),l11l1l_l1_ (u"ࠩ࠳ࠫ澮"),0]: return l11l1l_l1_ (u"ࠪࠫ澯")
	l1l111l11_l1_ = int(l1l111l11_l1_)+63841823
	first = l1l111l11_l1_^l1llll11_l1_
	second = l1l111l11_l1_^REGULAR_CACHE
	l1ll1ll11_l1_ = l1l111l11_l1_^l1ll1l1ll_l1_
	result = str(first)+str(second)+str(l1ll1ll11_l1_)
	return result
def l111111l1l11_l1_(l1l111l11_l1_):
	if l1l111l11_l1_ in [l11l1l_l1_ (u"ࠫࠬ澰"),l11l1l_l1_ (u"ࠬ࠶ࠧ澱"),0]: return l11l1l_l1_ (u"࠭ࠧ澲")
	l1l111l11_l1_ = str(l1l111l11_l1_)
	length = int(len(l1l111l11_l1_)/3)
	first = int(l1l111l11_l1_[0:length])^l1llll11_l1_
	second = int(l1l111l11_l1_[length:2*length])^REGULAR_CACHE
	l1ll1ll11_l1_ = int(l1l111l11_l1_[2*length:3*length])^l1ll1l1ll_l1_
	result = l11l1l_l1_ (u"ࠧࠨ澳")
	if first==second==l1ll1ll11_l1_: result = str(int(first)-63841823)
	return result
def l11l11l1111_l1_(l111ll1l11ll_l1_):
	addons = l1111llll1l1_l1_()
	l11l11l1l1l_l1_ = False
	for addon_id in l111ll1l11ll_l1_:
		if addon_id not in list(addons.keys()): continue
		l1111l11l11l_l1_ = addons[addon_id]
		l1l111l1ll1l_l1_,l1l11ll1ll1l_l1_,l11ll111ll1l_l1_ = l1111l11l11l_l1_[0]
		l1l111111lll_l1_,l1l11l1llll1_l1_ = l1llll1ll111l_l1_(addon_id)
		if not l1l111111lll_l1_:
			l11l11l1l1l_l1_ = True
			break
		else:
			l111llll1l1l_l1_ = l1l11ll1ll1l_l1_>l1l11l1llll1_l1_
			if l111llll1l1l_l1_:
				l11l11l1l1l_l1_ = True
				break
	return l11l11l1l1l_l1_
def l1l11llll1_l1_(file):
	size,count = 0,0
	if os.path.exists(file):
		try: size = os.path.getsize(file)
		except: pass
		if not size:
			try: size = os.stat(file).st_size
			except: pass
		if not size:
			try:
				import pathlib
				size = pathlib.Path(file).stat().st_size
			except: pass
		if size: count = 1
	return size,count
def l1lll1llll1l1_l1_(l1ll1lllll1l_l1_):
	l1l1lllll_l1_(l11l1l_l1_ (u"ࠨࡵࡷࡳࡵ࠭澴"))
	if l1ll1lllll1l_l1_:
		if l11l1l_l1_ (u"ࠩࡢࡣࡋࡕࡒࡄࡇࡇࡣࡊ࡞ࡉࡕࡡࡢࠫ澵") in l1ll1lllll1l_l1_:
			message  = l1ll1lllll1l_l1_.split(l11l1l_l1_ (u"ࠪࡣࡤࡌࡏࡓࡅࡈࡈࡤࡋࡘࡊࡖࡢࡣࠬ澶"))[1]
			LOG_THIS(l11l1l_l1_ (u"ࠫࠬ澷"),l11l1l_l1_ (u"ࠬࡌࡏࡓࡅࡈࡈࠥࡋࡘࡊࡖࠣࠤࠥࠦ࠮ࠡࠢࠣࠫ澸")+message)
			#sys.stderr.write(l11l1l_l1_ (u"࠭ࡆࡐࡔࡆࡉࡉࠦࡅ࡙ࡋࡗ࠾ࡡࡴࠧ澹")+message+l11l1l_l1_ (u"ࠧ࡝ࡰࡢࠫ澺"))
		else: l111l1l1111l_l1_(l1ll1lllll1l_l1_)
	l1l11l1l1l_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡷ࡫ࡦࡳࡧࡶ࡬࠳ࡹࡴࡢࡶࡸࡷࠬ澻"))
	if l1l11l1l1l_l1_==l11l1l_l1_ (u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡈࡈࠬ澼"): settings.setSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡲࡦࡨࡵࡩࡸ࡮࠮ࡴࡶࡤࡸࡺࡹࠧ澽"),l11l1l_l1_ (u"ࠫࡗࡋࡆࡓࡇࡖࡌࡊࡊࠧ澾"))
	elif l1l11l1l1l_l1_==l11l1l_l1_ (u"ࠬࡘࡅࡇࡔࡈࡗࡍࡋࡄࠨ澿"): settings.setSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡵࡩ࡫ࡸࡥࡴࡪ࠱ࡷࡹࡧࡴࡶࡵࠪ激"),l11l1l_l1_ (u"ࠧࠨ濁"))
	if settings.getSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡩࡴࡳ࠯ࡵࡷࡥࡹࡻࡳࠨ濂")) not in [l11l1l_l1_ (u"ࠩࡄ࡙࡙ࡕࠧ濃"),l11l1l_l1_ (u"ࠪࡗ࡙ࡕࡐࠨ濄"),l11l1l_l1_ (u"ࠫࡆ࡙ࡋࠨ濅")]: settings.setSetting(l11l1l_l1_ (u"ࠬࡧࡶ࠯ࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ濆"),l11l1l_l1_ (u"࠭ࡁࡔࡍࠪ濇"))
	if settings.getSetting(l11l1l_l1_ (u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ濈")) not in [l11l1l_l1_ (u"ࠨࡃࡘࡘࡔ࠭濉"),l11l1l_l1_ (u"ࠩࡖࡘࡔࡖࠧ濊"),l11l1l_l1_ (u"ࠪࡅࡘࡑࠧ濋")]: settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴ࡳࡵࡣࡷࡹࡸ࠭濌"),l11l1l_l1_ (u"ࠬࡇࡓࡌࠩ濍"))
	l1l11l1l111l_l1_ = settings.getSetting(l11l1l_l1_ (u"࠭ࡡࡷ࠰ࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩ濎"))
	l11ll1l1l1l1_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢࡾࡿࠪ濏"))
	if l11l1l_l1_ (u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ濐") in str(l11ll1l1l1l1_l1_) and l1l11l1l111l_l1_ in [l11l1l_l1_ (u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬ濑"),l11l1l_l1_ (u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ濒")]:
		#l1llll1l_l1_(l11l1l_l1_ (u"ࠫࠬ濓"),l1l11l1l111l_l1_)
		time.sleep(0.100)
		xbmc.executebuiltin(l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩ濔"))
	#l111ll1l1lll_l1_ = sys.version_info[0]
	#l111l111llll_l1_ = sys.version_info[1]
	#if l111ll1l1lll_l1_==2: python_version = l11l1l_l1_ (u"࠭࠲࠸ࠩ濕")
	#else: python_version = str(l111ll1l1lll_l1_)+str(l111l111llll_l1_)
	#l111lll1ll11_l1_ = os.path.join(addonfolder,l11l1l_l1_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ濖")+python_version)
	if 0 and addon_handle>-1:
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ濗"),l11l1l_l1_ (u"ࠩࠪ濘"),l11l1l_l1_ (u"ࠪࠫ濙"),str(addon_handle))
		xbmcplugin.setResolvedUrl(addon_handle,False,xbmcgui.ListItem())
		succeeded,l11111lll111_l1_,l111ll1lll11_l1_ = False,False,False
		xbmcplugin.endOfDirectory(addon_handle,succeeded,l11111lll111_l1_,l111ll1lll11_l1_)
	return
if __name__==l11l1l_l1_ (u"ࠫࡤࡥ࡭ࡢ࡫ࡱࡣࡤ࠭濚"):
	# should l1111llll1_l1_ l1l1l1ll_l1_ when l1ll1ll11llll_l1_
	LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ濛"),l11l1l_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠫ濜"))
	l1ll1lllll1l_l1_ = l11l1l_l1_ (u"ࠧࠨ濝")
	if 0:
		url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡢࡵࡨࡰ࡭ࡪ࠮ࡰࡰࡨ࠳ࡻ࡯ࡤࡦࡱࡢࡴࡱࡧࡹࡦࡴࡂࡹ࡮ࡪ࠽࠱ࠨࡹ࡭ࡩࡃࡦࡧࡤ࠺࠴࠽ࡩ࠱࠺࠴ࡦ࠶࠽ࡪ࠱࠲࠴࠳࠶ࡦࡪ࠱࠹ࡦࡧ࠵࠷ࡩ࠶࠹࠲࠹ࠫ濞")
		import ll_l1_
		a,b,c = ll_l1_.l1ll11llll1_l1_(url)
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ濟"),l11l1l_l1_ (u"ࠪࠫ濠"),l11l1l_l1_ (u"ࠫࠬ濡"),str(c))
		l1l1l11llll_l1_ = c[0][0]
		#LOG_THIS(l11l1l_l1_ (u"ࠬ࠭濢"),l1l1l11llll_l1_)
		l1l1l11llll_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳ࠴࠶࠱࠲ࡨ࡫ࡺࡥࡩࡧࡱࡰ࠮ࡤ࠰ࡶࡧࡩࡴ࠮ࡵࡱ࠲ࡷࡹࡸࡥࡢ࡯࠲ࡺ࠶࠵ࡨ࡭ࡵ࠲࠷ࡩ࡛ࡔࡇ࠹࡜࠻ࡊࡈࡇ࡭ࡗࡵ࡚ࡏࡐࡴ࠳ࡍ࡚࡫࠴࠷࠶࠹࠵࠹࠽࠾࠸࠹࠵࠱ࡤࡰࡱ࠵ࡡ࡭࡮࠲࠵࠵࠽࠮࠲࠷࠼࠲࠶࠺࠮࠵࠵࠲ࡽࡪࡹ࠯ࡄࡃ࠲࠴࠴࠶࠶࠮࠲࠵࠳࠷࠵ࡦࡧࡤ࠺࠴࠽ࡩ࠱࠺࠴ࡦ࠶࠽ࡪ࠱࠲࠴࠳࠶ࡦࡪ࠱࠹ࡦࡧ࠵࠷ࡩ࠶࠹࠲࠹࠳࠶࠻࠵ࡠࡪࡧ࠻࠷࠶ࡢࡠࡲ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡱ࠸ࡻ࠸ࠨ濣")
		#PLAY_VIDEO(l1l1l11llll_l1_)
		l1ll1ll1l11ll_l1_ = xbmcgui.ListItem()
		#l1ll1ll1l11ll_l1_.setPath(l1l1l11llll_l1_)
		#xbmcplugin.setResolvedUrl(addon_handle,True,l1ll1ll1l11ll_l1_)
		xbmc.Player().play(l1l1l11llll_l1_,l1ll1ll1l11ll_l1_)
	else:
		l1l1lllll_l1_(l11l1l_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭濤"))
		try: l111111l1l1l_l1_()
		except Exception as error: l1ll1lllll1l_l1_ = traceback.format_exc()
	l1lll1llll1l1_l1_(l1ll1lllll1l_l1_)
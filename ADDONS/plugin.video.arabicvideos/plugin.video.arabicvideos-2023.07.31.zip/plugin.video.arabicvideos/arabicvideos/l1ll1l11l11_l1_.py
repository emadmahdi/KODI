# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ❪")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡌࡂࡌࡡࠪ❫")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧ❬"),l11l1l_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧ❭")]
def MAIN(mode,url,text):
	if   mode==620: results = MENU()
	elif mode==621: results = l1lllll_l1_(url,text)
	elif mode==622: results = PLAY(url)
	elif mode==623: results = l1111_l1_(url,text)
	elif mode==624: results = l11lll_l1_(url)
	elif mode==629: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1l1ll1_l1_ = l1ll1l111ll_l1_(l11l11_l1_,l11l1l_l1_ (u"ࠧࡧࡣࡥࡶࡦࡱࡡࠨ❮"),l11l1l_l1_ (u"ࠨใหี่ฯࠠࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧ❯"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭❰"),l1l1ll1_l1_,l11l1l_l1_ (u"ࠪࠫ❱"),l11l1l_l1_ (u"ࠫࠬ❲"),l11l1l_l1_ (u"ࠬ࠭❳"),l11l1l_l1_ (u"࠭ࠧ❴"),l11l1l_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ❵"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ❶"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ❷"),l11l1l_l1_ (u"ࠪࠫ❸"),629,l11l1l_l1_ (u"ࠫࠬ❹"),l11l1l_l1_ (u"ࠬ࠭❺"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ❻"))
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ❼"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ❽"),l11l1l_l1_ (u"ࠩࠪ❾"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ❿"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭➀")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆ็ํึฮ࠭➁"),l11l11_l1_,621,l11l1l_l1_ (u"࠭ࠧ➂"),l11l1l_l1_ (u"ࠧࠨ➃"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ➄"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➅"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ➆")+l1111l_l1_+l11l1l_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪ➇"),l11l11_l1_,621,l11l1l_l1_ (u"ࠬ࠭➈"),l11l1l_l1_ (u"࠭ࠧ➉"),l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭➊"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ➋"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ➌")+l1111l_l1_+l11l1l_l1_ (u"ࠪะิ๐ฯࠡษ็วๆ๊วๆࠩ➍"),l11l11_l1_,621,l11l1l_l1_ (u"ࠫࠬ➎"),l11l1l_l1_ (u"ࠬ࠭➏"),l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ➐"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ➑"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ➒")+l1111l_l1_+l11l1l_l1_ (u"ࠩสู่๊ไิๆสฮࠥอไๆ็ํึฮ࠭➓"),l11l11_l1_,621,l11l1l_l1_ (u"ࠪࠫ➔"),l11l1l_l1_ (u"ࠫࠬ➕"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ➖"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➗"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➘"),l11l1l_l1_ (u"ࠨࠩ➙"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡽࡲࡢࡲࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ➚"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ➛"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ➜"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ➝")+l1111l_l1_+title,l1llll1_l1_,624)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➞"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➟"),l11l1l_l1_ (u"ࠨࠩ➠"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭➡"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣ➢"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠫࠬ➣"))
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ➤"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭➥"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ➦")+l1111l_l1_+title,l1llll1_l1_,624)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ➧"),url,l11l1l_l1_ (u"ࠩࠪ➨"),l11l1l_l1_ (u"ࠪࠫ➩"),l11l1l_l1_ (u"ࠫࠬ➪"),l11l1l_l1_ (u"ࠬ࠭➫"),l11l1l_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ➬"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡥࡤࡶࡪࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ➭"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠨࠤࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠣࠩ➮"),l11l1l_l1_ (u"ࠩ࠿࠳ࡺࡲ࠾ࠨ➯"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡨࡦࡣࡧࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ➰"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠫࠬ➱"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ➲"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢไีืࠦร้ࠢไ่ฯืࠠฤ๊ࠣฮึะ๊ษࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ➳"),l11l1l_l1_ (u"ࠧࠨ➴"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭➵"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠩ࠽ࠤࠬ➶")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ➷"),l1111l_l1_+title,l1llll1_l1_,621)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶ࡭࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠰ࡷࡺࡨࡣࡢࡶࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ➸"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ➹"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ➺"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ➻"),l11l1l_l1_ (u"ࠨࠩ➼"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ➽"),l1111l_l1_+title,l1llll1_l1_,621)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠪࠫ➾")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ➿"),l11l1l_l1_ (u"ࠬ࠭⟀"),request,url)
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ⟁"):
		url,search = url.split(l11l1l_l1_ (u"ࠧࡀࠩ⟂"),1)
		data = l11l1l_l1_ (u"ࠨࡳࡸࡩࡷࡿࡓࡵࡴ࡬ࡲ࡬ࡃࠧ⟃")+search
		headers = {l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ⟄"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ⟅")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ⟆"),url,data,headers,l11l1l_l1_ (u"ࠬ࠭⟇"),l11l1l_l1_ (u"࠭ࠧ⟈"),l11l1l_l1_ (u"ࠧࡇࡃࡅࡖࡆࡑࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⟉"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⟊"),url,l11l1l_l1_ (u"ࠩࠪ⟋"),l11l1l_l1_ (u"ࠪࠫ⟌"),l11l1l_l1_ (u"ࠫࠬ⟍"),l11l1l_l1_ (u"ࠬ࠭⟎"),l11l1l_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫ⟏"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠧࠨ⟐"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ⟑"))
	if request==l11l1l_l1_ (u"ࠩࡤ࡮ࡦࡾ࠭ࡴࡧࡤࡶࡨ࡮ࠧ⟒"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ⟓"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠫࠬ⟔"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⟕"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡯࠰ࡺ࡮ࡪࡥࡰ࠯ࡺࡥࡹࡩࡨ࠮ࡨࡨࡥࡹࡻࡲࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⟖"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭⟗"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⟘"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥ࡭ࡰࡸ࡬ࡩࡸ࠭⟙"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⟚"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⟛"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡨࡰ࡯ࡨ࠱ࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡛࡝ࡶࡿࡠࡳࡣࠪ࠽࠱ࡧ࡭ࡻࡄࠧ⟜"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ⟝"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠧࠨ⟞"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨ࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⟟"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦࡥ࡫ࡳࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⟠"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ู้ࠪอ็ะหࠪ⟡"),l11l1l_l1_ (u"ࠫๆ๐ไๆࠩ⟢"),l11l1l_l1_ (u"ࠬอฺ็์ฬࠫ⟣"),l11l1l_l1_ (u"࠭ใๅ์หࠫ⟤"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭⟥"),l11l1l_l1_ (u"ࠨ้าหๆ࠭⟦"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩ⟧"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧ⟨"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫ⟩"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫ⟪"),l11l1l_l1_ (u"࠭ๅิำะ๎ฮ࠭⟫")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠧ࠰ࠩ⟬"))
		#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭⟭") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ⟮")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ⟯"))
		#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⟰") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ⟱")+l1ll1l_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ⟲"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ⟳"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠࠩษ็ั้่ษࡽฯ็ๆฮ࠯࠮࡝ࡦ࠮ࠫ⟴"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⟵"),l1111l_l1_+title,l1llll1_l1_,622,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⟶"):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⟷"),l1111l_l1_+title,l1llll1_l1_,622,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⟸") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⟹"),l1111l_l1_+title,l1llll1_l1_,623,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬ⟺") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⟻"),l1111l_l1_+title,l1llll1_l1_,621,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⟼"),l1111l_l1_+title,l1llll1_l1_,623,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ⟽"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭⟾")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⟿"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⠀"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠧࠤࠩ⠁"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ⠂")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ⠃"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⠄"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ⠅")+title,l1llll1_l1_,621)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⠆"),l11l1l_l1_ (u"࠭ࠧ⠇"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⠈"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⠉"),url,l11l1l_l1_ (u"ࠩࠪ⠊"),l11l1l_l1_ (u"ࠪࠫ⠋"),l11l1l_l1_ (u"ࠫࠬ⠌"),l11l1l_l1_ (u"ࠬ࠭⠍"),l11l1l_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭⠎"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡕࡨࡥࡸࡵ࡮ࡴࡄࡲࡼࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰࠪ⠏"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡶࡩࡷ࡯ࡥࡴ࠯࡫ࡩࡦࡪࡥࡳࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⠐"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠩࠪ⠑")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࠫࠬࡵ࡮ࡤ࡮࡬ࡧࡰࡃࠢࡰࡲࡨࡲࡈ࡯ࡴࡺ࡞ࠫࡩࡻ࡫࡮ࡵ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࡠ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡣࡷࡷࡸࡴࡴ࠾ࠨࠩࠪ⠒"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠫࠨ࠭⠓"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⠔"),l1111l_l1_+title,url,623,l1ll1l_l1_,l11l1l_l1_ (u"࠭ࠧ⠕"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࠬ⠖")+l1l11_l1_+l11l1l_l1_ (u"ࠨࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⠗"),html,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿࠾࡯࡭ࡃࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠣ⠘"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠪࠦࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⠙"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭⠚")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ⠛"))
			title = title.replace(l11l1l_l1_ (u"࠭࠼࠰ࡧࡰࡂࡁࡹࡰࡢࡰࡁࠫ⠜"),l11l1l_l1_ (u"ࠧࠡࠩ⠝"))
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⠞"),l1111l_l1_+title,l1llll1_l1_,622,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ⠟"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ⠠") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭⠡")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ⠢"))
		#		addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ⠣"),l1111l_l1_+title,l1llll1_l1_,622,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⠤"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ⠥"),url,l11l1l_l1_ (u"ࠩࠪ⠦"),l11l1l_l1_ (u"ࠪࠫ⠧"),l11l1l_l1_ (u"ࠫࠬ⠨"),l11l1l_l1_ (u"ࠬ࠭⠩"),l11l1l_l1_ (u"࠭ࡆࡂࡄࡕࡅࡐࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⠪"))
	html = response.content
	# l1ll1ll_l1_ l11lll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⠫"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	l1lll11_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡃࠧ⠬"))[1]
	l1lll11_l1_ = base64.b64decode(l1lll11_l1_)
	if kodi_version>18.99: l1lll11_l1_ = l1lll11_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ⠭"))
	l1lll11_l1_ = l1lll11_l1_.replace(l11l1l_l1_ (u"ࠪࡠ࠴࠭⠮"),l11l1l_l1_ (u"ࠫ࠴࠭⠯"))
	l1lll11_l1_ = EVAL(l11l1l_l1_ (u"ࠬࡪࡩࡤࡶࠪ⠰"),l1lll11_l1_)
	l1l1_l1_ = l1lll11_l1_[l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡹࠧ⠱")]
	l11ll1_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l11111_l1_ = zip(l11ll1_l1_,l1l1_l1_)
	for title,l1llll1_l1_ in l11111_l1_:
		l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ⠲")+title+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ⠳")
		l1lll1_l1_.append(l1llll1_l1_)
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࠣࡪࡨࠣࡰ࡮ࡴ࡫ࠡࡣࡱࡨࠥ࠭ࡨࡵࡶࡳࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡱ࡯࡮࡬ࠢࡀࠤࠬ࡮ࡴࡵࡲ࠽ࠫ࠰ࡲࡩ࡯࡭ࠍࠍ࡭ࡧࡳࡩࠢࡀࠤࡱ࡯࡮࡬࠰ࡶࡴࡱ࡯ࡴࠩࠩ࡫ࡥࡸ࡮࠽ࠨࠫ࡞࠵ࡢࠐࠉࡱࡣࡵࡸࡸࠦ࠽ࠡࡪࡤࡷ࡭࠴ࡳࡱ࡮࡬ࡸ࠭࠭࡟ࡠࠩࠬࠎࠎࡴࡥࡸࡡࡳࡥࡷࡺࡳࠡ࠿ࠣ࡟ࡢࠐࠉࡧࡱࡵࠤࡵࡧࡲࡵࠢ࡬ࡲࠥࡶࡡࡳࡶࡶ࠾ࠏࠏࠉࡵࡴࡼ࠾ࠏࠏࠉࠊࡲࡤࡶࡹࠦ࠽ࠡࡤࡤࡷࡪ࠼࠴࠯ࡤ࠹࠸ࡩ࡫ࡣࡰࡦࡨࠬࡵࡧࡲࡵ࠭ࠪࡁࠬ࠯ࠊࠊࠋࠌ࡭࡫ࠦ࡫ࡰࡦ࡬ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࡃ࠷࠸࠯࠻࠼࠾ࠥࡶࡡࡳࡶࠣࡁࠥࡶࡡࡳࡶ࠱ࡨࡪࡩ࡯ࡥࡧࠫࠫࡺࡺࡦ࠹ࠩࠬࠎࠎࠏࠉ࡯ࡧࡺࡣࡵࡧࡲࡵࡵ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡴࡦࡸࡴࠪࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠥࡶࡡࡴࡵࠍࠍࡱ࡯࡮࡬ࡵࠣࡁࠥ࠭࠾ࠨ࠰࡭ࡳ࡮ࡴࠨ࡯ࡧࡺࡣࡵࡧࡲࡵࡵࠬࠎࠎࡲࡩ࡯࡭ࡶࠤࡂࠦ࡬ࡪࡰ࡮ࡷ࠳ࡹࡰ࡭࡫ࡷࡰ࡮ࡴࡥࡴࠪࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱ࠲ࠡ࡫ࡱࠤࡿࢀࡺ࠻ࠌࠌࠍࡹ࡯ࡴ࡭ࡧ࠯ࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠳࠰ࡶࡴࡱ࡯ࡴࠩࠩࠣࡁࡃࠦࠧࠪࠌࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ࠊࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠧࠨࠢ⠴")
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ⠵"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⠶"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭⠷"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ⠸"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ⠹"),l11l1l_l1_ (u"ࠨ࠭ࠪ⠺"))
	l1l1ll1_l1_ = l1ll1l111ll_l1_(l11l11_l1_,l11l1l_l1_ (u"ࠩࡩࡥࡧࡸࡡ࡬ࡣࠪ⠻"),l11l1l_l1_ (u"ࠪๅอืใสࠢࡤࡾࡺࡸࡥࡦࡦࡪࡩ࠳ࡴࡥࡵࠩ⠼"))
	url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ⠽")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⠾"))
	#url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ⠿")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ⡀"))
	return
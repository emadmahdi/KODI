# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡆࡎࡗࡂࡍࠪࠀ")
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥࡁࡉࡍࡢࠫࠁ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨࠂ"),l11l1l_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨࠃ")]
def MAIN(mode,url,text):
	if   mode==610: results = MENU()
	elif mode==611: results = l1lllll_l1_(url,text)
	elif mode==612: results = PLAY(url)
	elif mode==613: results = l1111_l1_(url,text)
	elif mode==614: results = l11lll_l1_(url)
	elif mode==619: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬࠄ"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪࠅ"),l11l1l_l1_ (u"ࠪࠫࠆ"),l11l1l_l1_ (u"ࠫࠬࠇ"),l11l1l_l1_ (u"ࠬ࠭ࠈ"),l11l1l_l1_ (u"࠭ࡁࡉ࡙ࡄࡏ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧࠉ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࠊ"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨࠋ"),l11l1l_l1_ (u"ࠩࠪࠌ"),619,l11l1l_l1_ (u"ࠪࠫࠍ"),l11l1l_l1_ (u"ࠫࠬࠎ"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠏ"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫࠐ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࠑ"),l11l1l_l1_ (u"ࠨࠩࠒ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠓ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬࠔ")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬࠕ"),l11l11_l1_,611,l11l1l_l1_ (u"ࠬ࠭ࠖ"),l11l1l_l1_ (u"࠭ࠧࠗ"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ࠘"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࠙"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫࠚ")+l1111l_l1_+l11l1l_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩࠛ"),l11l11_l1_,611,l11l1l_l1_ (u"ࠫࠬࠜ"),l11l1l_l1_ (u"ࠬ࠭ࠝ"),l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬࠞ"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࠟ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪࠠ")+l1111l_l1_+l11l1l_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨࠡ"),l11l11_l1_,611,l11l1l_l1_ (u"ࠪࠫࠢ"),l11l1l_l1_ (u"ࠫࠬࠣ"),l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩࠤ"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠥ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩࠦ")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬࠧ"),l11l11_l1_,611,l11l1l_l1_ (u"ࠩࠪࠨ"),l11l1l_l1_ (u"ࠪࠫࠩ"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭ࠪ"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪࠫ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬ"),l11l1l_l1_ (u"ࠧࠨ࠭"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡼࡸࡡࡱࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭࠮"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ࠯"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ࠰"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭࠱")+l1111l_l1_+title,l1llll1_l1_,614)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ࠲"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠳"),l11l1l_l1_ (u"ࠧࠨ࠴"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠲ࡵ࡮ࡰࠣࡀࠫ࠲࠯ࡅࠩࠣࡰࡤࡺࡸࡲࡩࡥࡧ࠰ࡨ࡮ࡼࡩࡥࡧࡵࠦࠬ࠵"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠤࠪࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡳࡥ࡯ࡷࠪࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠢ࠶"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠪࠫ࠷"))
	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ࠸"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࠹"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ࠺")+l1111l_l1_+title,l1llll1_l1_,614)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ࠻"),url,l11l1l_l1_ (u"ࠨࠩ࠼"),l11l1l_l1_ (u"ࠩࠪ࠽"),l11l1l_l1_ (u"ࠪࠫ࠾"),l11l1l_l1_ (u"ࠫࠬ࠿"),l11l1l_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩࡀ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡣࡵࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪࡁ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠧࠣࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠢࠨࡂ"),l11l1l_l1_ (u"ࠨ࠾࠲ࡹࡱࡄࠧࡃ"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲࡮ࡥࡢࡦࡨࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࡄ"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠪࠫࡅ"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩࡆ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡใิึࠥษ่ࠡใ็ฮึࠦร้ࠢอีฯ๐ศࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡇ"),l11l1l_l1_ (u"࠭ࠧࡈ"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬࡉ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠨ࠼ࠣࠫࡊ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࡋ"),l1111l_l1_+title,l1llll1_l1_,611)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡳ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠯ࡶࡹࡧࡩࡡࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧࡌ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ࡍ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪࡎ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡏ"),l11l1l_l1_ (u"ࠧࠨࡐ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࡑ"),l1111l_l1_+title,l1llll1_l1_,611)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠩࠪࡒ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫࡓ"),l11l1l_l1_ (u"ࠫࠬࡔ"),request,url)
	if request==l11l1l_l1_ (u"ࠬࡧࡪࡢࡺ࠰ࡷࡪࡧࡲࡤࡪࠪࡕ"):
		url,search = url.split(l11l1l_l1_ (u"࠭࠿ࠨࡖ"),1)
		data = l11l1l_l1_ (u"ࠧࡲࡷࡨࡶࡾ࡙ࡴࡳ࡫ࡱ࡫ࡂ࠭ࡗ")+search
		headers = {l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࡘ"):l11l1l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹࡙ࠩ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡔࡔ࡙ࡔࠨ࡚"),url,data,headers,l11l1l_l1_ (u"࡛ࠫࠬ"),l11l1l_l1_ (u"ࠬ࠭࡜"),l11l1l_l1_ (u"࠭ࡁࡉ࡙ࡄࡏ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ࡝"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ࡞"),url,l11l1l_l1_ (u"ࠨࠩ࡟"),l11l1l_l1_ (u"ࠩࠪࡠ"),l11l1l_l1_ (u"ࠪࠫࡡ"),l11l1l_l1_ (u"ࠫࠬࡢ"),l11l1l_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱࡙ࡏࡔࡍࡇࡖ࠱࠷ࡴࡤࠨࡣ"))
	html = response.content
	block,items = l11l1l_l1_ (u"࠭ࠧࡤ"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫࡥ"))
	if request==l11l1l_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭ࡦ"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫࡧ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠪࠫࡨ"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ࡩ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰ࡮࠯ࡹ࡭ࡩ࡫࡯࠮ࡹࡤࡸࡨ࡮࠭ࡧࡧࡤࡸࡺࡸࡥࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࡪ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ࡫"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ࡬"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ࡭"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࡮"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ࡯"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡮࡯࡮ࡧ࠰ࡷࡪࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜ࡵࡾ࡟ࡲࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ࡰ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧࡱ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"࠭ࠧࡲ"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨࡳ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥࡤࡪࡲࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩࡴ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩࡵ"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨࡶ"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪࡷ"),l11l1l_l1_ (u"้ࠬไ๋สࠪࡸ"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬࡹ"),l11l1l_l1_ (u"่ࠧัสๅࠬࡺ"),l11l1l_l1_ (u"ࠨ็หหึอษࠨࡻ"),l11l1l_l1_ (u"ࠩ฼ี฻࠭ࡼ"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪࡽ"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪࡾ"),l11l1l_l1_ (u"๋ࠬำาฯํอࠬࡿ")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"࠭࠯ࠨࢀ"))
		#if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬࢁ") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪࢂ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫࢃ"))
		#if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨࢄ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭ࢅ")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧࢆ"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨࢇ"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪ࢈"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧࢉ"),l1111l_l1_+title,l1llll1_l1_,612,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࢊ"):
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩࢋ"),l1111l_l1_+title,l1llll1_l1_,612,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪࢌ") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࢍ"),l1111l_l1_+title,l1llll1_l1_,613,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"࠭࠯࡮ࡱࡹࡷࡪࡸࡩࡦࡵ࠲ࠫࢎ") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࢏"),l1111l_l1_+title,l1llll1_l1_,611,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࢐"),l1111l_l1_+title,l1llll1_l1_,613,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࢑"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬ࢒")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࢓"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ࢔"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"࠭ࠣࠨ࢕"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ࢖")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪࢗ"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࢘"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษ࢙ࠡࠩ")+title,l1llll1_l1_,611)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"࢚ࠫࠬ"),l11l1l_l1_ (u"࢛ࠬ࠭"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ࢜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ࢝"),url,l11l1l_l1_ (u"ࠨࠩ࢞"),l11l1l_l1_ (u"ࠩࠪ࢟"),l11l1l_l1_ (u"ࠪࠫࢠ"),l11l1l_l1_ (u"ࠫࠬࢡ"),l11l1l_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪࢢ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡔࡧࡤࡷࡴࡴࡳࡃࡱࡻࠦ࠭࠴ࠪࡀࠫࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯ࠩࢣ"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢤ"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠨࠩࢥ")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࠪࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨ࡯ࡱࡧࡱࡇ࡮ࡺࡹ࡝ࠪࡨࡺࡪࡴࡴ࠭ࠢࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧࠨࠩࢦ"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠪࠧࠬࢧ"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࢨ"),l1111l_l1_+title,url,613,l1ll1l_l1_,l11l1l_l1_ (u"ࠬ࠭ࢩ"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࠫࢪ")+l1l11_l1_+l11l1l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬࢫ"),html,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠣࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾࠽࡮࡬ࡂࡁ࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠢࢬ"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠩࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢭ"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬࢮ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ࢯ"))
			title = title.replace(l11l1l_l1_ (u"ࠬࡂ࠯ࡦ࡯ࡁࡀࡸࡶࡡ࡯ࡀࠪࢰ"),l11l1l_l1_ (u"࠭ࠠࠨࢱ"))
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ࢲ"),l1111l_l1_+title,l1llll1_l1_,612,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩࢳ"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧࢴ") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬࢵ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ࢶ"))
		#		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫࢷ"),l1111l_l1_+title,l1llll1_l1_,612,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪࢸ"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫࢹ"),url,l11l1l_l1_ (u"ࠨࠩࢺ"),l11l1l_l1_ (u"ࠩࠪࢻ"),l11l1l_l1_ (u"ࠪࠫࢼ"),l11l1l_l1_ (u"ࠫࠬࢽ"),l11l1l_l1_ (u"ࠬࡇࡈࡘࡃࡎ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ࢾ"))
	html = response.content
	# l1ll1ll_l1_ l11lll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࢿ"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	l1lll11_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠧࡱࡱࡶࡸࡂ࠭ࣀ"))[1]
	l1lll11_l1_ = base64.b64decode(l1lll11_l1_)
	if kodi_version>18.99: l1lll11_l1_ = l1lll11_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ࣁ"))
	l1lll11_l1_ = l1lll11_l1_.replace(l11l1l_l1_ (u"ࠩ࡟࠳ࠬࣂ"),l11l1l_l1_ (u"ࠪ࠳ࠬࣃ"))
	l1lll11_l1_ = EVAL(l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩࣄ"),l1lll11_l1_)
	l1l1_l1_ = l1lll11_l1_[l11l1l_l1_ (u"ࠬࡹࡥࡳࡸࡨࡶࡸ࠭ࣅ")]
	l11ll1_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l11111_l1_ = zip(l11ll1_l1_,l1l1_l1_)
	for title,l1llll1_l1_ in l11111_l1_:
		l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧࣆ")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨࣇ")
		l1lll1_l1_.append(l1llll1_l1_)
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࠩࡩࡧࠢ࡯࡭ࡳࡱࠠࡢࡰࡧࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪ࠯ࡱ࡯࡮࡬ࠌࠌ࡬ࡦࡹࡨࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡵࡳࡰ࡮ࡺࠨࠨࡪࡤࡷ࡭ࡃࠧࠪ࡝࠴ࡡࠏࠏࡰࡢࡴࡷࡷࠥࡃࠠࡩࡣࡶ࡬࠳ࡹࡰ࡭࡫ࡷࠬࠬࡥ࡟ࠨࠫࠍࠍࡳ࡫ࡷࡠࡲࡤࡶࡹࡹࠠ࠾ࠢ࡞ࡡࠏࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡱࡣࡵࡸࠥࡃࠠࡣࡣࡶࡩ࠻࠺࠮ࡣ࠸࠷ࡨࡪࡩ࡯ࡥࡧࠫࡴࡦࡸࡴࠬࠩࡀࠫ࠮ࠐࠉࠊࠋ࡬ࡪࠥࡱ࡯ࡥ࡫ࡢࡺࡪࡸࡳࡪࡱࡱࡂ࠶࠾࠮࠺࠻࠽ࠤࡵࡧࡲࡵࠢࡀࠤࡵࡧࡲࡵ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠸ࠨࠫࠍࠍࠎࠏ࡮ࡦࡹࡢࡴࡦࡸࡴࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡳࡥࡷࡺࠩࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠤࡵࡧࡳࡴࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࠬࡄࠧ࠯࡬ࡲ࡭ࡳ࠮࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠫࠍࠍࡱ࡯࡮࡬ࡵࠣࡁࠥࡲࡩ࡯࡭ࡶ࠲ࡸࡶ࡬ࡪࡶ࡯࡭ࡳ࡫ࡳࠩࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠸ࠠࡪࡰࠣࡾࡿࢀ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠲࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࡀࡂࠥ࠭ࠩࠋࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫ࠬࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ࠯ࡹ࡯ࡴ࡭ࡧ࠮ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬࠐࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠦࠧࠨࣈ")
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧࣉ"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ࣊"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ࣋"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭࣌"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ࣍"),l11l1l_l1_ (u"ࠧࠬࠩ࣎"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࡫ࡦࡻࡺࡳࡷࡪࡳ࠾࣏ࠩ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩ࣐ࠩ"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅ࣑ࠧ")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࣒ࠩ"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ㏾")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡒࡄࡏࡡࠪ㏿")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠬอไาศํื๏ฯࠧ㐀"),l11l1l_l1_ (u"࠭วิฬไืฬืสไ็ࠣ์ࠥอไุๆหหฯ࠭㐁")]
def MAIN(mode,url,text):
	if   mode==450: results = MENU()
	elif mode==451: results = l1lllll_l1_(url,text)
	elif mode==452: results = PLAY(url)
	elif mode==453: results = l1lll11ll1_l1_(url)
	elif mode==454: results = l1lll1l1_l1_(url)
	elif mode==459: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ㐂"),l11l11_l1_,l11l1l_l1_ (u"ࠨࠩ㐃"),l11l1l_l1_ (u"ࠩࠪ㐄"),l11l1l_l1_ (u"ࠪࠫ㐅"),l11l1l_l1_ (u"ࠫࠬ㐆"),l11l1l_l1_ (u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ㐇"))
	html = response.content
	l1l1ll1_l1_ = SERVER(l11l11_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ㐈"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㐉"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ㐊"),l11l1l_l1_ (u"ࠩࠪ㐋"),459,l11l1l_l1_ (u"ࠪࠫ㐌"),l11l1l_l1_ (u"ࠫࠬ㐍"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㐎"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㐏"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㐐")+l1111l_l1_+l11l1l_l1_ (u"ࠨ็ฮฬฯอสࠡๆ๋ำ๏ࠦๆหࠩ㐑"),l1l1ll1_l1_,451,l11l1l_l1_ (u"ࠩࠪ㐒"),l11l1l_l1_ (u"ࠪࠫ㐓"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭㐔"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㐕"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ㐖")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭㐗"),l1l1ll1_l1_,451,l11l1l_l1_ (u"ࠨࠩ㐘"),l11l1l_l1_ (u"ࠩࠪ㐙"),l11l1l_l1_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪ㐚"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㐛"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㐜")+l1111l_l1_+l11l1l_l1_ (u"࠭ๅๆอ็๎๋࠭㐝"),l1l1ll1_l1_,451,l11l1l_l1_ (u"ࠧࠨ㐞"),l11l1l_l1_ (u"ࠨࠩ㐟"),l11l1l_l1_ (u"ࠩࡤࡧࡹࡵࡲࡴࠩ㐠"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㐡"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㐢")+l1111l_l1_+l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦ็็ัํอࠬ㐣"),l1l1ll1_l1_,451,l11l1l_l1_ (u"࠭ࠧ㐤"),l11l1l_l1_ (u"ࠧࠨ㐥"),l11l1l_l1_ (u"ࠨ࠲ࠪ㐦"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㐧"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㐨")+l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥํๆะ์ฬࠤ๊ีศๅฮฬࠫ㐩"),l1l1ll1_l1_,451,l11l1l_l1_ (u"ࠬ࠭㐪"),l11l1l_l1_ (u"࠭ࠧ㐫"),l11l1l_l1_ (u"ࠧ࠲ࠩ㐬"))
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㐭"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㐮")+l1111l_l1_+l11l1l_l1_ (u"ࠪหๆ๊วๆ๊๊ࠢิ๐ษࠨ㐯"),l1l1ll1_l1_,451,l11l1l_l1_ (u"ࠫࠬ㐰"),l11l1l_l1_ (u"ࠬ࠭㐱"),l11l1l_l1_ (u"࠭࠲ࠨ㐲"))
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㐳"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ㐴"),l11l1l_l1_ (u"ࠩࠪ㐵"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡒࡧࡩ࡯ࡏࡨࡲࡺࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠪ㐶"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㐷"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l1llll1_l1_==l11l1l_l1_ (u"ࠬࠩࠧ㐸"): continue
			if title in l1l111_l1_: continue
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㐹"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ㐺")+l1111l_l1_+title,l1llll1_l1_,451)
	return
def l1lllll_l1_(url,l1lll111ll_l1_=l11l1l_l1_ (u"ࠨࠩ㐻")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㐼"),l11l1l_l1_ (u"ࠪࠫ㐽"),url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ㐾"),url,l11l1l_l1_ (u"ࠬ࠭㐿"),l11l1l_l1_ (u"࠭ࠧ㑀"),l11l1l_l1_ (u"ࠧࠨ㑁"),l11l1l_l1_ (u"ࠨࠩ㑂"),l11l1l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ㑃"))
	html = response.content
	if l1lll111ll_l1_==l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ㑄"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠫࠧࡩࡵࡧࡖࡰ࡮ࡪࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡹࡤࡺࡪࡹࠢࠨ㑅"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
	elif l1lll111ll_l1_==l11l1l_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㑆"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡓࡧࡦࡩࡳࡺࡐࡰࡵࡷࡷࠧ࠮࠮ࠫࡁࠬࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠣࠩ㑇"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
	elif l11l1l_l1_ (u"ࠧࠣࡃࡦࡸࡴࡸࡳࡍ࡫ࡶࡸࠧ࠭㑈") in html:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡄࡧࡹࡵࡲࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࠧࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠢࠨ㑉"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࠨࡁࡤࡶࡲࡶࡓࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㑊"),block,re.DOTALL)
	elif l1lll111ll_l1_ in [l11l1l_l1_ (u"ࠪ࠴ࠬ㑋"),l11l1l_l1_ (u"ࠫ࠶࠭㑌"),l11l1l_l1_ (u"ࠬ࠸ࠧ㑍")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡔࡧࡦࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࡁ࠵ࡵ࡭ࡀࠪ㑎"),html,re.DOTALL)
		block = l1l11l1_l1_[int(l1lll111ll_l1_)]
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࠦࡹ࡫ࡸࡵ࠱࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹࠨࠧ㑏"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࡀࠪ㑐"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩ㑑"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ㑒"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪ㑓"),l11l1l_l1_ (u"ࠬษฺ็์ฬࠫ㑔"),l11l1l_l1_ (u"࠭ใๅ์หࠫ㑕"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭㑖"),l11l1l_l1_ (u"ࠨ้าหๆ࠭㑗"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩ㑘"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧ㑙"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫ㑚"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫ㑛")]
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if l11l1l_l1_ (u"࠭ࠢࡂࡥࡷࡳࡷࡹࡌࡪࡵࡷࠦࠬ㑜") in html and l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠬ㑝") in l1ll1l_l1_:
			l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㑞"),l1ll1l_l1_,re.DOTALL)
			l1ll1l_l1_ = l1ll1l_l1_[0]
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ㑟"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢะ่็ฯࠠ࡝ࡦ࠮ࠫ㑠"),title,re.DOTALL)
		if not l1ll11l_l1_: l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ㑡"),title,re.DOTALL)
		#if any(value in title for value in l1ll11_l1_):
		if set(title.split()) & set(l1ll11_l1_) and l11l1l_l1_ (u"๋ࠬำๅี็ࠫ㑢") not in title:
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ㑣"),l1111l_l1_+title,l1llll1_l1_,452,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠧฮๆๅอࠬ㑤") in title:
			title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ㑥") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㑦"),l1111l_l1_+title,l1llll1_l1_,453,l1ll1l_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㑧"),l1111l_l1_+title,l1llll1_l1_,453,l1ll1l_l1_)
	if l1lll111ll_l1_ in [l11l1l_l1_ (u"ࠫࠬ㑨"),l11l1l_l1_ (u"ࠬࡲࡡࡵࡧࡶࡸࠬ㑩")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㑪"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㑫"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				#if l1llll1_l1_==l11l1l_l1_ (u"ࠣࠤ㑬"): continue
				title = unescapeHTML(title)
				#if title!=l11l1l_l1_ (u"ࠩࠪ㑭"):
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㑮"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ㑯")+title,l1llll1_l1_,451)
	return
def l1lll11ll1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ㑰"),url,l11l1l_l1_ (u"࠭ࠧ㑱"),l11l1l_l1_ (u"ࠧࠨ㑲"),l11l1l_l1_ (u"ࠨࠩ㑳"),l11l1l_l1_ (u"ࠩࠪ㑴"),l11l1l_l1_ (u"ࠪࡐࡔࡊ࡙ࡏࡇࡗ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ㑵"))
	html = response.content
	# l1lll1l_l1_
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡉࡡࡵࡧࡪࡳࡷࡿࡓࡶࡤࡏ࡭ࡳࡱࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㑶"),html,re.DOTALL)
	if l1l1111_l1_ and l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠫ㑷") in str(l1l1111_l1_):
		title = re.findall(l11l1l_l1_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭࠲࠭㑸"),html,re.DOTALL)
		title = title[0].strip(l11l1l_l1_ (u"ࠧࠡࠩ㑹"))
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㑺"),l1111l_l1_+title,url,454)
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㑻"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㑼"),l1111l_l1_+title,l1llll1_l1_,454)
	else: l1lll1l1_l1_(url)
	return
def l1lll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ㑽"),url,l11l1l_l1_ (u"ࠬ࠭㑾"),l11l1l_l1_ (u"࠭ࠧ㑿"),l11l1l_l1_ (u"ࠧࠨ㒀"),l11l1l_l1_ (u"ࠨࠩ㒁"),l11l1l_l1_ (u"ࠩࡏࡓࡉ࡟ࡎࡆࡖ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ㒂"))
	html = response.content
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡅࡷ࡫ࡡࠣࠪ࠱࠮ࡄ࠯ࠢࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵࠤࠪ㒃"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠶ࡃ࠭㒄"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㒅"),l1111l_l1_+title,l1llll1_l1_,452,l1ll1l_l1_)
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ㒆"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㒇"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				#if l1llll1_l1_==l11l1l_l1_ (u"ࠣࠤ㒈"): continue
				title = unescapeHTML(title)
				#if title!=l11l1l_l1_ (u"ࠩࠪ㒉"):
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㒊"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ㒋")+title,l1llll1_l1_,454)
	return
def PLAY(url):
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ㒌"),l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥ࡭ࡰࡸ࡬ࡩࡸ࠵ࠧ㒍"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ㒎"),l11l1l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡠࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫ㒏"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭㒐"),l111l1l_l1_,l11l1l_l1_ (u"ࠪࠫ㒑"),l11l1l_l1_ (u"ࠫࠬ㒒"),l11l1l_l1_ (u"ࠬ࠭㒓"),l11l1l_l1_ (u"࠭ࠧ㒔"),l11l1l_l1_ (u"ࠧࡍࡑࡇ࡝ࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㒕"))
	html = response.content
	l1l1ll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ㒖"))
	l1lll1_l1_ = []
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࡛ࠩࠥࡦࡺࡣࡩࡖ࡬ࡸࡱ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡵ࡬ࡨࡪࡄࠧ㒗"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ㒘"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㒙")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㒚")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡅࡱࡺࡲࡱࡵࡡࡥࡎ࡬ࡲࡰࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡳࡦ࡮ࡤࡶࡾࠨࠧ㒛"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭㒜"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			name = unescapeHTML(name)
			l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡞ࡧࡠࡩࡢࡤࠬࠩ㒝"),name,re.DOTALL)
			if l111ll11_l1_:
				l111ll11_l1_ = l11l1l_l1_ (u"ࠩࡢࡣࡤࡥࠧ㒞")+l111ll11_l1_[0]
				name = l11l1l_l1_ (u"ࠪࠫ㒟")
			else: l111ll11_l1_ = l11l1l_l1_ (u"ࠫࠬ㒠")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㒡")+name+l11l1l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㒢")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ㒣"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㒤"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪ㒥"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫ㒦"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭㒧"),l11l1l_l1_ (u"ࠬ࠱ࠧ㒨"))
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ㒩")+search
	l1lllll_l1_(url)
	return
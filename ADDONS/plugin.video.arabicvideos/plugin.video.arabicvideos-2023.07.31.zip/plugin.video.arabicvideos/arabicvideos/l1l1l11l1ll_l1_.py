# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡏࡆ࡚ࡋࡐࡗࡗࡉࠬれ")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡑࡔࡌࡡࠪろ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠬอไึใะอࠥอไาศํื๏ฯࠧゎ"),l11l1l_l1_ (u"࠭ࡓࡪࡩࡱࠤ࡮ࡴࠧわ"),l11l1l_l1_ (u"ࠧศๆฦๆุอๅࠨゐ")]
def MAIN(mode,url,text):
	if   mode==670: results = MENU()
	elif mode==671: results = l1lllll_l1_(url,text)
	elif mode==672: results = PLAY(url)
	elif mode==673: results = l1111_l1_(url,text)
	elif mode==674: results = l11lll_l1_(url)
	elif mode==679: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬゑ"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪを"),l11l1l_l1_ (u"ࠪࠫん"),l11l1l_l1_ (u"ࠫࠬゔ"),l11l1l_l1_ (u"ࠬ࠭ゕ"),l11l1l_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪゖ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ゗"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ゘"),l11l1l_l1_ (u"゙ࠩࠪ"),679,l11l1l_l1_ (u"゚ࠪࠫ"),l11l1l_l1_ (u"ࠫࠬ゛"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ゜"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫゝ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧゞ"),l11l1l_l1_ (u"ࠨࠩゟ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ゠"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬァ")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬア"),l11l11_l1_,671,l11l1l_l1_ (u"ࠬ࠭ィ"),l11l1l_l1_ (u"࠭ࠧイ"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩゥ"))
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨウ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫェ")+l1111l_l1_+l11l1l_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩエ"),l11l11_l1_,671,l11l1l_l1_ (u"ࠫࠬォ"),l11l1l_l1_ (u"ࠬ࠭オ"),l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬカ"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧガ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪキ")+l1111l_l1_+l11l1l_l1_ (u"ࠩฯำ๏ีࠠศๆฦๅ้อๅࠨギ"),l11l11_l1_,671,l11l1l_l1_ (u"ࠪࠫク"),l11l1l_l1_ (u"ࠫࠬグ"),l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡰࡳࡻ࡯ࡥࡴࠩケ"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ゲ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩコ")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ุ้๊ำๅษอࠤฬ๊ๅๆ์ีอࠬゴ"),l11l11_l1_,671,l11l1l_l1_ (u"ࠩࠪサ"),l11l1l_l1_ (u"ࠪࠫザ"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡳࡦࡴ࡬ࡩࡸ࠭シ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪジ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ス"),l11l1l_l1_ (u"ࠧࠨズ"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩセ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫゼ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		if title==l11l1l_l1_ (u"ࠪห้ษโิษ่ࠫソ"): mode = 675
		else: mode = 674
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫゾ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧタ")+l1111l_l1_+title,l1llll1_l1_,mode)
	#addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫダ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧチ"),l11l1l_l1_ (u"ࠨࠩヂ"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠳ࡶࡨࡱࠤࡁࠬ࠳࠰࠿ࠪࠤࡱࡥࡻࡹ࡬ࡪࡦࡨ࠱ࡩ࡯ࡶࡪࡦࡨࡶࠧ࠭ッ"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠥࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠫ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠣツ"),html,re.DOTALL)
	#for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠫࠬヅ"))
	#items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪテ"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭デ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩト")+l1111l_l1_+title,l1llll1_l1_,674)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ド"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩナ"),l11l1l_l1_ (u"ࠪࠫニ"),9999)
	items = CATEGORIES(l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࡧࡸ࡯ࡸࡵࡨ࠲࡭ࡺ࡭࡭ࠩヌ"))
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬネ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨノ")+l1111l_l1_+title,l1llll1_l1_,674,l1ll1l_l1_)
	return
def CATEGORIES(url):
	l1ll11l1l1_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࠬハ"),l11l1l_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇࠪバ"),l11l1l_l1_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭パ"))
	if l1ll11l1l1_l1_: return l1ll11l1l1_l1_
	#DIALOG_OK()
	l1ll11l1l1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧヒ"),url,l11l1l_l1_ (u"ࠫࠬビ"),l11l1l_l1_ (u"ࠬ࠭ピ"),l11l1l_l1_ (u"࠭ࠧフ"),l11l1l_l1_ (u"ࠧࠨブ"),l11l1l_l1_ (u"ࠨࡍࡄࡘࡐࡕࡕࡕࡇ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫプ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡦࡺࡥࡨࡱࡵࡽ࠲࡮ࡥࡢࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࡫ࡵ࡯ࡵࡧࡵࡂࠬヘ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1ll11l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧベ"),block,re.DOTALL)
		if l1ll11l1l1_l1_: WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠭ペ"),l11l1l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩホ"),l1ll11l1l1_l1_,l1llll11_l1_)
	return l1ll11l1l1_l1_
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪボ"),url,l11l1l_l1_ (u"ࠧࠨポ"),l11l1l_l1_ (u"ࠨࠩマ"),l11l1l_l1_ (u"ࠩࠪミ"),l11l1l_l1_ (u"ࠪࠫム"),l11l1l_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫメ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡢࡴࡨࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩモ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"࠭ࠢࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠨࠧャ"),l11l1l_l1_ (u"ࠧ࠽࠱ࡸࡰࡃ࠭ヤ"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡧࡶࡴࡶࡤࡰࡹࡱ࠱࡭࡫ࡡࡥࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬュ"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠩࠪユ"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨョ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠโำีࠤศ๎ࠠโๆอีࠥษ่ࠡฬิฮ๏ฮࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩヨ"),l11l1l_l1_ (u"ࠬ࠭ラ"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫリ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠧ࠻ࠢࠪル")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨレ"),l1111l_l1_+title,l1llll1_l1_,671)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡲ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠮ࡵࡸࡦࡨࡧࡴࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ロ"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬヮ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩワ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬヰ"),l11l1l_l1_ (u"࠭ࠧヱ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧヲ"),l1111l_l1_+title,l1llll1_l1_,671)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠨࠩン")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪヴ"),l11l1l_l1_ (u"ࠪࠫヵ"),request,url)
	if request==l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩヶ"):
		url,search = url.split(l11l1l_l1_ (u"ࠬࡅࠧヷ"),1)
		data = l11l1l_l1_ (u"࠭ࡱࡶࡧࡵࡽࡘࡺࡲࡪࡰࡪࡁࠬヸ")+search
		headers = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ヹ"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨヺ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ・"),url,data,headers,l11l1l_l1_ (u"ࠪࠫー"),l11l1l_l1_ (u"ࠫࠬヽ"),l11l1l_l1_ (u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫヾ"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪヿ"),url,l11l1l_l1_ (u"ࠧࠨ㄀"),l11l1l_l1_ (u"ࠨࠩ㄁"),l11l1l_l1_ (u"ࠩࠪ㄂"),l11l1l_l1_ (u"ࠪࠫ㄃"),l11l1l_l1_ (u"ࠫࡐࡇࡔࡌࡑࡘࡘࡊ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ㄄"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠬ࠭ㄅ"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪㄆ"))
	if request==l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬㄇ"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪㄈ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠩࠪㄉ"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬㄊ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡸࡣࡷࡧ࡭࠳ࡦࡦࡣࡷࡹࡷ࡫ࡤࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬㄋ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫㄌ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡳࡱࡺࠤࡵࡳ࠭ࡶ࡮࠰ࡦࡷࡵࡷࡴࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ㄍ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡲࡵࡶࡪࡧࡶࠫㄎ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡵࡳࡼࠦࡰ࡮࠯ࡸࡰ࠲ࡨࡲࡰࡹࡶࡩ࠲ࡼࡩࡥࡧࡲࡷ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨㄏ"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࡣࡸ࡫ࡲࡪࡧࡶࠫㄐ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦ࡭ࡵ࡭ࡦ࠯ࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡠࡢࡴࡽ࡞ࡱࡡ࠯ࡂ࠯ࡥ࡫ࡹࡂࠬㄑ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ㄒ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠬ࠭ㄓ"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧㄔ"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨㄕ"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠨ็ืห์ีษࠨㄖ"),l11l1l_l1_ (u"ࠩไ๎้๋ࠧㄗ"),l11l1l_l1_ (u"ࠪห฿์๊สࠩㄘ"),l11l1l_l1_ (u"่๊๊ࠫษࠩㄙ"),l11l1l_l1_ (u"ࠬอูๅษ้ࠫㄚ"),l11l1l_l1_ (u"࠭็ะษไࠫㄛ"),l11l1l_l1_ (u"ࠧๆสสีฬฯࠧㄜ"),l11l1l_l1_ (u"ࠨ฻ิฺࠬㄝ"),l11l1l_l1_ (u"่๋ࠩึาว็ࠩㄞ"),l11l1l_l1_ (u"ࠪห้ฮ่ๆࠩㄟ"),l11l1l_l1_ (u"ู๊ࠫัฮ์ฬࠫㄠ"),l11l1l_l1_ (u"ࠬ็ไๆࠩㄡ")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"࠭࠯ࠨㄢ"))
		#if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬㄣ") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪㄤ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫㄥ"))
		#if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨㄦ") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭ㄧ")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧㄨ"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨㄩ"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼฮๆๅอ࠮࠴࡜ࡥ࠭ࠪㄪ"),title,re.DOTALL)
		#addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧㄫ"),l1111l_l1_+title,l1llll1_l1_,672,l1ll1l_l1_)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㄬ"),l1111l_l1_+title,l1llll1_l1_,672,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩㄭ"):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪㄮ"),l1111l_l1_+title,l1llll1_l1_,672,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫㄯ") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㄰"),l1111l_l1_+title,l1llll1_l1_,673,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺࡸ࡫ࡲࡪࡧࡶ࠳ࠬㄱ") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㄲ"),l1111l_l1_+title,l1llll1_l1_,671,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㄳ"),l1111l_l1_+title,l1llll1_l1_,673,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫㄴ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩㄵ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l1llll1_l1_==l11l1l_l1_ (u"ࠬࠩࠧㄶ"): continue
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫㄷ") not in l1llll1_l1_:
				l111l1l_l1_ = url.rsplit(l11l1l_l1_ (u"ࠧ࠰ࠩㄸ"),1)[0]
				l1llll1_l1_ = l111l1l_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪㄹ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫㄺ"))
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㄻ"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪㄼ")+title,l1llll1_l1_,671,l11l1l_l1_ (u"ࠬ࠭ㄽ"),l11l1l_l1_ (u"࠭ࠧㄾ"),request)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨㄿ"),l11l1l_l1_ (u"ࠨࠩㅀ"),l1l11_l1_,url)
	addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨㅁ"),l1111l_l1_+l11l1l_l1_ (u"ࠪฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪㅂ"),url,672)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩㅃ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬㅄ"),l11l1l_l1_ (u"࠭ࠧㅅ"),9999)
	l1ll11l1l1_l1_ = CATEGORIES(l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡣࡴࡲࡻࡸ࡫࠮ࡩࡶࡰࡰࠬㅆ"))
	l1l1l11l11l_l1_,l1l1l11l1l1_l1_,l1l1l1l1111_l1_ = zip(*l1ll11l1l1_l1_)
	l1l1l11ll11_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬㅇ"),url,l11l1l_l1_ (u"ࠩࠪㅈ"),l11l1l_l1_ (u"ࠪࠫㅉ"),l11l1l_l1_ (u"ࠫࠬㅊ"),l11l1l_l1_ (u"ࠬ࠭ㅋ"),l11l1l_l1_ (u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧㅌ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡸ࡬ࡨࡪࡵ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡱࡧࡹࡦࡴࠥࠫㅍ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡼࡆࡺࡺࡴࡰࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾ࠪㅎ"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1l1l11l11l_l1_:
				item = (l1llll1_l1_,title)
				l1l1l11ll11_l1_.append(item)
		if len(l1l1l11ll11_l1_)==1:
			l1llll1_l1_,title = l1l1l11ll11_l1_[0]
			l1lllll_l1_(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㅏ"))
			return
		else:
			for l1llll1_l1_,title in l1l1l11ll11_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪㅐ"),l1111l_l1_+title,l1llll1_l1_,671,l11l1l_l1_ (u"ࠫࠬㅑ"),l11l1l_l1_ (u"ࠬ࠭ㅒ"),l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬㅓ"))
	if not l1l1l11ll11_l1_: l1lllll_l1_(url,l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ㅔ"))
	return
#https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l11l1lll11_l1_.l1ll1l1ll1_l1_?l1l1l11llll_l1_=l1l1l11lll1_l1_
#https://l1l1l1l111l_l1_.l1l1l11ll1l_l1_.com/l11l11lll_l1_/l1l1111l1_l1_.l1ll1l1ll1_l1_?l1l1l11llll_l1_=l1l1l11lll1_l1_
def PLAY(url):
	l1lll11l_l1_ = []
	#url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡡࡵ࡭ࡲࡹࡹ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪ࠲ๅ๏๊ๅ࠮ๅิฮํ์࠭ษษิฬ๏࠳แ๋࠯่฾ฬ๋ัส࠯่ฮ้ษไวห࠰้ิฮ࡟ࡥ࠻࠺࠹ࡨࡨ࠷࠶࠵࠱࡬ࡹࡳ࡬ࠨㅕ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ㅖ"),url,l11l1l_l1_ (u"ࠪࠫㅗ"),l11l1l_l1_ (u"ࠫࠬㅘ"),l11l1l_l1_ (u"ࠬ࠭ㅙ"),l11l1l_l1_ (u"࠭ࠧㅚ"),l11l1l_l1_ (u"ࠧࡌࡃࡗࡏࡔ࡛ࡔࡆ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫㅛ"))
	html = response.content
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼ࠫ࠲࠯ࡅࠩࡧ࡮ࡤࡷ࡭ࡶ࡬ࡢࡻࡨࡶࠬㅜ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡩ࡭ࡱ࡫࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬㅝ"),block,re.DOTALL)
		for l1llll1_l1_,l111ll11_l1_ in l1l1_l1_:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࡣࡤ࠭ㅞ")+l111ll11_l1_
			l1lll11l_l1_.append(l1llll1_l1_)
	# l1l1111l1_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡫࡭ࡣࡧࡧࡨࡪࡪ࠭ࡷ࡫ࡧࡩࡴࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧㅟ"),html,re.DOTALL)
	if not l1l1_l1_: l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࡬ࡩ࡭ࡧ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧㅠ"),html,re.DOTALL)
	if l1l1_l1_:
		l1llll1_l1_ = l1l1_l1_[0]
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫㅡ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭ㅢ")+l1llll1_l1_
		l1lll11l_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࠩㅣ"))
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧㅤ"),l1lll11l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll11l_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩㅥ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬㅦ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭ㅧ"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨㅨ"),l11l1l_l1_ (u"ࠧࠬࠩㅩ"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡱࡥࡺࡹࡲࡶࡩࡹ࠽ࠨㅪ")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩㅫ"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩ࠰ࡳ࡬ࡵࡅࠧㅬ")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩㅭ"))
	return
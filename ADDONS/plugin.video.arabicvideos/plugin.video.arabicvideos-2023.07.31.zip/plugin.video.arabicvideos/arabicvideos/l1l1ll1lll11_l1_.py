# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ博")
headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ卛") : l11l1l_l1_ (u"ࠫࠬ卜") }
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥࡓࡉ࠶ࡢࠫ卝")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ู࠭าู๊ࠤ๊฻วา฻ฬࠫ卞"),l11l1l_l1_ (u"ࠧศๆๆ่ࠬ卟"),l11l1l_l1_ (u"ࠨษไ่ฬ๋ࠧ占"),l11l1l_l1_ (u"ࠩ࡭ࡥࡻࡧࡳࡤࡴ࡬ࡴࡹ࠭卡"),l11l1l_l1_ (u"ฺ้ࠪอัฺหࠣัึฯࠧ卢")]
def MAIN(mode,url,text):
	if   mode==110: results = MENU()
	elif mode==111: results = l1lllll_l1_(url,text)
	elif mode==112: results = PLAY(url)
	elif mode==113: results = l1lll1l1_l1_(url,True)
	elif mode==114: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠫࡋ࡛ࡌࡍࡡࡉࡍࡑ࡚ࡅࡓࡡࡢࡣࠬ卣")+text)
	elif mode==115: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ卤")+text)
	elif mode==116: results = l1lll1l1_l1_(url,False)
	elif mode==119: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	l1l1ll1_l1_ = l1ll1l111ll_l1_(l11l11_l1_,l11l1l_l1_ (u"࠭ࡳࡩࡣ࡫࡭ࡩ࠺ࡵࠨ卥"),l11l1l_l1_ (u"ࠧีษ๊ำࠥ็่าࠢํ์ࠥ࠳ࠠࡔࡪࡤ࡬࡮ࡪ࠴ࡶࠩ卦"))
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ卧"),l1l1ll1_l1_,l11l1l_l1_ (u"ࠩࠪ卨"),headers,l11l1l_l1_ (u"ࠪࠫ卩"),l11l1l_l1_ (u"ࠫࠬ卪"),l11l1l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ卫"))
	html = response.content
	l11l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ卬"),html,re.DOTALL)
	if l11l1111_l1_: l11l1111_l1_ = l11l1111_l1_[0].strip(l11l1l_l1_ (u"ࠧ࠰ࠩ卭"))
	else: l11l1111_l1_ = l11l11_l1_
	l1l1ll1_l1_ = SERVER(l11l1111_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ卮"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ卯"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ印"),l11l1l_l1_ (u"ࠫࠬ危"),119,l11l1l_l1_ (u"ࠬ࠭卲"),l11l1l_l1_ (u"࠭ࠧ即"),l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ却"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ卵"),l1111l_l1_+l11l1l_l1_ (u"ࠩไ่ฯืࠠๆฯาำࠬ卶"),l11l1111_l1_,115)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ卷"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ卸"),l11l1111_l1_,114)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ卹"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭卺"),l11l1l_l1_ (u"ࠧࠨ卻"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ卼"),l11l1111_l1_,l11l1l_l1_ (u"ࠩࠪ卽"),headers,l11l1l_l1_ (u"ࠪࠫ卾"),l11l1l_l1_ (u"ࠫࠬ卿"),l11l1l_l1_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠭ࡎࡇࡑ࡙࠲࠸࡮ࡥࠩ厀"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡸࡦࡨࡳࠩ࠰࠭ࡃ࠮ࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡴࡧࡤࡶࡨ࡮ࠧ厁"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡭ࡥࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ厂"),block,re.DOTALL)
		for filter,title in items:
			#url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡓࡩࡣ࡫࡭ࡩ࠺ࡵ࠰ࡃ࡭ࡥࡽࡧࡴ࠰ࡊࡲࡱࡪ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨࡊࡲࡱࡪ࠴ࡰࡩࡲࠪ厃")
			#url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡈࡰ࡯ࡨ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࡈࡰ࡯ࡨ࠲ࡵ࡮ࡰࠨ厄")
			url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࠧ厅")+filter
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ历"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ厇")+l1111l_l1_+title,url,111,l11l1l_l1_ (u"࠭ࠧ厈"),l11l1l_l1_ (u"ࠧࠨ厉"),filter)
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭厊"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ压"),l11l1l_l1_ (u"ࠪࠫ厌"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮࠮࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ厍"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ厎"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title in l1l111_l1_: continue
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ厏") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ厐"))
			if l11l1l_l1_ (u"ࠨࡰࡨࡸ࡫ࡲࡩࡹࠩ厑") in l1llll1_l1_: title = l11l1l_l1_ (u"้ࠩ๎ฯ็ไไีࠪ厒")
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ厓"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭厔")+l1111l_l1_+title,l1llll1_l1_,111)
	return html
def l1lllll_l1_(url,l1lll111ll_l1_=l11l1l_l1_ (u"ࠬ࠭厕")):
	if l11l1l_l1_ (u"࠭࠯ࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡖ࡬ࡴࡽࡳ࠯ࡲ࡫ࡴࡄ࠭厖") in url:
		url,data = l1lll111l1_l1_(url)
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭厗"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ厘"),l11l1l_l1_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ厙"):l11l1l_l1_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ厚")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ厛"),url,data,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠬ࠭厜"),l11l1l_l1_ (u"࠭ࠧ厝"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭厞"))
		html = response.content
		block = html
	elif l11l1l_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡌࡴࡳࡥ࠯ࡲ࡫ࡴࠬ原") in url:
		data = {l11l1l_l1_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ厠"):l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡧࡲ࡯ࡤ࡭ࠪ厡"),l11l1l_l1_ (u"ࠫࡰ࡫ࡹࠨ厢"):l1lll111ll_l1_}
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ厣"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ厤")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ厥"),url,data,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ厦"),l11l1l_l1_ (u"ࠩࠪ厧"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠸࡮ࡥࠩ厨"))
		html = response.content
		block = html
	elif l11l1l_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧ厩") in url:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ厪"),url,l11l1l_l1_ (u"࠭ࠧ厫"),l11l1l_l1_ (u"ࠧࠨ厬"),l11l1l_l1_ (u"ࠨࠩ厭"),l11l1l_l1_ (u"ࠩࠪ厮"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠹ࡲࡥࠩ厯"))
		html = response.content
		block = html
	else:
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ厰"):l11l1l_l1_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭厱")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ厲"),url,l11l1l_l1_ (u"ࠧࠨ厳"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ厴"),l11l1l_l1_ (u"ࠩࠪ厵"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲࡚ࡉࡕࡎࡈࡗ࠲࠺ࡴࡩࠩ厶"))
		html = response.content
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩࡵࡣࡪࡷ࠲ࡩ࡬ࡰࡷࡧࠫ厷"),html,re.DOTALL)
		if not l1l11l1_l1_: return
		block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ厸"),block,re.DOTALL)
	items = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡤࡲࡼࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭࡝ࡹ࠮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ厹"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧ厺"),l11l1l_l1_ (u"ࠨใํ่๊࠭去"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨ厼"),l11l1l_l1_ (u"ࠪ็้๐ศࠨ厽"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪ厾"),l11l1l_l1_ (u"ࠬํฯศใࠪ县"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭叀"),l11l1l_l1_ (u"ฺࠧำูࠫ叁"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨ参"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ參")]
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if l11l1l_l1_ (u"ࠪ࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠧ叄") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭叅") in l1llll1_l1_: continue
		#l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࠬࠣ࠱࠵࠻࠿ࠬ叆"),l11l1l_l1_ (u"࠭ࠦࠨ叇"))
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠧ࠰ࠩ又"))
		title = unescapeHTML(title)
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ叉"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬ及"),title,re.DOTALL)
		if l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ友") in l1llll1_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ双"),l1111l_l1_+title,l1llll1_l1_,112,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠬอไฮๆๅอࠬ反") in title and l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ収") not in url:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭叏") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ叐"),l1111l_l1_+title,l1llll1_l1_,113,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠩ࠲ࡥࡨࡺ࡯ࡳ࠱ࠪ发") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ叒"),l1111l_l1_+title,l1llll1_l1_,111,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭叓") in l1llll1_l1_ and l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷࠫ叔") not in url:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ叕")
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ取"),l1111l_l1_+title,l1llll1_l1_,111,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨ࠱࡯࡭ࡸࡺࠧ受") in url and l11l1l_l1_ (u"ࠩะ่็ฯࠧ变") in title:
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ叙"),l1111l_l1_+title,l1llll1_l1_,112,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ叚"),l1111l_l1_+title,l1llll1_l1_,113,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡫ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ叛"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ叜"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭叝"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠨษ็ูๆำษࠡࠩ叞"),l11l1l_l1_ (u"ࠩࠪ叟"))
			if title!=l11l1l_l1_ (u"ࠪࠫ叠"): addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ叡"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ叢")+title,l1llll1_l1_,111)
	l1lll1llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ口"),html,re.DOTALL)
	if l1lll1llll_l1_:
		l1llll1_l1_ = l1lll1llll_l1_[0]
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ古"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ句"),l1llll1_l1_,111)
	return
def l1lll1l1_l1_(url,l11ll111ll11_l1_):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭另"),url,l11l1l_l1_ (u"ࠪࠫ叧"),headers,l11l1l_l1_ (u"ࠫࠬ叨"),l11l1l_l1_ (u"ࠬ࠭叩"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ只"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࠢ࡬ࡨࡂࠨࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡺࡡࡨࡵ࠰ࡧࡱࡵࡵࡥࠩ叫"),html,re.DOTALL)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡳ࡭ࡸࡵࡤࡦࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ召"),html,re.DOTALL)
	if l1l1111_l1_:
		# l1lll1l_l1_
		if l1l1111_l1_ and l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫ叭") not in url:
			block = l1l1111_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯࡟ࡻ࠰ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭叮"),block,re.DOTALL)
			if items:
				for l1llll1_l1_,l1ll1l_l1_,title in items:
					title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭可"))
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ台"),l1111l_l1_+title,l1llll1_l1_,116,l1ll1l_l1_)
		# l11ll_l1_
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡢࡷࠬ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭叱"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ史"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ右"),l1111l_l1_+title,l1llll1_l1_,112,l1ll1l_l1_)
	else:
		# l1lll1l_l1_ & l11ll_l1_
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡶࡴࡽࠠࡨࡷࡷࡸࡪࡸ࠭ࡴ࡯ࡤࡰࡱࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ叴"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1:
			if l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ叵") in l1l11l1_l1_[0]: l1lll1l_l1_,l11ll_l1_ = l1l11l1_l1_[0],l1l11l1_l1_[1]
			else: l1lll1l_l1_,l11ll_l1_ = l1l11l1_l1_[1],l1l11l1_l1_[0]
		else: l1lll1l_l1_,l11ll_l1_ = l1l11l1_l1_[0],l1l11l1_l1_[0]
		for l11l1l1ll1_l1_ in range(2):
			if l11ll111ll11_l1_: mode,type,name,block = 116,l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ叶"),l11l1l_l1_ (u"ࠬอไๆ๊ึ้ࠥ࠭号"),l1lll1l_l1_
			else: mode,type,name,block = 112,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ司"),l11l1l_l1_ (u"ࠧศๆะ่็ฯࠠࠨ叹"),l11ll_l1_
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ叺"),block,re.DOTALL)
			if l11ll111ll11_l1_ and len(items)<2:
				l11ll111ll11_l1_ = False
				continue
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ叻"))
				title = name+title
				addMenuItem(type,l1111l_l1_+title,l1llll1_l1_,mode)
			break
	# l11ll_l1_ l11l111l_l1_
	if not items and l11l1l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ叼") in html:
		l1l11ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡸࡥࡢࡦࡦࡶࡺࡳࡢࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭叽"),html,re.DOTALL)
		if l1l11ll11_l1_:
			block = l1l11ll11_l1_[0]
			l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ叾"),block,re.DOTALL)
			if len(l1l1_l1_)>2:
				l1llll1_l1_ = l1l1_l1_[2]+l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࠫ叿")
				l1lllll_l1_(l1llll1_l1_)
	return
def PLAY(url):
	l1lll1_l1_ = []
	l1llll1ll_l1_ = url.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ吀"))
	hostname = SERVER(l1llll1ll_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ吁"))
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭吂"),l1llll1ll_l1_,l11l1l_l1_ (u"ࠪࠫ吃"),headers,l11l1l_l1_ (u"ࠫࠬ各"),l11l1l_l1_ (u"ࠬ࠭吅"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ吆"))
	html = response.content#.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ吇"))
	id = re.findall(l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡏࡤ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ合"),html,re.DOTALL)
	if not id: id = re.findall(l11l1l_l1_ (u"ࠩࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠤࠪ吉"),html,re.DOTALL)
	if not id: id = re.findall(l11l1l_l1_ (u"ࠪࡴࡴࡹࡴ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ吊"),html,re.DOTALL)
	if id: id = id[0]
	else: id = l11l1l_l1_ (u"ࠫࠬ吋")
	#else: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭同"),l11l1l_l1_ (u"࠭ࠧ名"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ后"),l11l1l_l1_ (u"ࠨ์ิะ๎ࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ吏"))
	if l11l1l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠥࠫ吐") in html:
		#parts = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ向"))
		#l111l1l_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠫࡼࡧࡴࡤࡪࠪ吒"))
		l111l1l_l1_ = l1llll1ll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬ࠬ吓")
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ吔"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ吕"),headers,l11l1l_l1_ (u"ࠨࠩ吖"),l11l1l_l1_ (u"ࠩࠪ吗"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ吘"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ吙"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡹ࠭࡭࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ吚"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11l1_l1_: l1l1lll_l1_ = l1l11l1_l1_[0]
		else: l1l1lll_l1_ = l11ll111_l1_
		if not id:
			id = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡃࠢ࠱ࠤࠣࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ君"),l1l1lll_l1_,re.DOTALL)
			if id: id = id[0]
			else: id = l11l1l_l1_ (u"ࠧࠨ吜")
		l11111l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ吝"),l11ll111_l1_,re.DOTALL)
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪ吞"),l11ll111_l1_,re.DOTALL)
		l11111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ吟"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬ吠"),l11ll111_l1_)
		l1111111l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭吡"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		l1111llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ吢"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		l11ll111l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲࡯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ吣"),l1l1lll_l1_,re.DOTALL|re.IGNORECASE)
		l11ll1111lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬ吤"),l1l1lll_l1_,re.DOTALL|re.IGNORECASE)
		items = l11111l11_l1_+l1l11ll_l1_+l11111l1l_l1_+l111111l1_l1_+l1111111l_l1_+l1111llll_l1_+l11ll111l11l_l1_+l11ll1111lll_l1_
		if not items:
			items = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ吥"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠪࡠࡹ࠭否"),l11l1l_l1_ (u"ࠫࠬ吧")).replace(l11l1l_l1_ (u"ࠬࡢ࡮ࠨ吨"),l11l1l_l1_ (u"࠭ࠧ吩")).strip(l11l1l_l1_ (u"ࠧࠡࠩ吪"))
			#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ含"),title)
			if l11l1l_l1_ (u"ࠩ࠱ࡴࡳ࡭ࠧ听") in server: continue
			if l11l1l_l1_ (u"ࠪ࠲࡯ࡶࡧࠨ吭") in server: continue
			if l11l1l_l1_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ吮") in server: continue
			l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭启"),title,re.DOTALL)
			if l111ll11_l1_:
				l111ll11_l1_ = l111ll11_l1_[0]
				if l111ll11_l1_ in title: title = title.replace(l111ll11_l1_+l11l1l_l1_ (u"࠭ࡰࠨ吰"),l11l1l_l1_ (u"ࠧࠨ吱")).replace(l111ll11_l1_,l11l1l_l1_ (u"ࠨࠩ吲")).strip(l11l1l_l1_ (u"ࠩࠣࠫ吳"))
				l111ll11_l1_ = l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ吴")+l111ll11_l1_
			else: l111ll11_l1_ = l11l1l_l1_ (u"ࠫࠬ吵")
			if server.isdigit(): l1llll1_l1_ = hostname+l11l1l_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨ吶")+id+l11l1l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪ吷")+server+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ吸")+title+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ吹")+l111ll11_l1_
			else:
				if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ吺") not in server: server = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ吻")+server
				l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ吼"),title,re.DOTALL)
				if l111ll11_l1_: l111ll11_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ吽")+l111ll11_l1_[0]
				else: l111ll11_l1_ = l11l1l_l1_ (u"࠭ࠧ吾")
				l1llll1_l1_ = server+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨ吿")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭呀"),l1lll1_l1_)
	#l1lll1_l1_ = []
	if l11l1l_l1_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴ࠨࠧ呁") in html:
		#parts = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ呂"))
		#l111l1l_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭呃"))
		l111l1l_l1_ = l1llll1ll_l1_+l11l1l_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨ呄")
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ呅"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ呆"),headers,l11l1l_l1_ (u"ࠨࠩ呇"),l11l1l_l1_ (u"ࠩࠪ呈"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ呉"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ告"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡳࡥࡥ࡫ࡤ࠱ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠮࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠫ࠱ࡀ࠴ࡪࡩࡷࡀࠪ呋"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		if l1l11l1_l1_: l1l1lll_l1_ = l1l11l1_l1_[0]
		else: l1l1lll_l1_ = l11ll111_l1_
		l111111_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡩ࠵࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ呌"),l1l1lll_l1_,re.DOTALL)
		for title,block in l111111_l1_:
			title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ呍"))
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡲࡦࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ呎"),block,re.DOTALL)
			for l1llll1_l1_,name,l111ll11_l1_ in items:
				l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡟ࡨ࠰࠭呏"),l111ll11_l1_,re.DOTALL)
				if l111ll11_l1_: l111ll11_l1_ = l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ呐")+l111ll11_l1_[0]
				else:
					l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪࠫࠨ呑"),title,re.DOTALL)
					if l111ll11_l1_: l111ll11_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ呒")+l111ll11_l1_[0]
					else: l111ll11_l1_ = l11l1l_l1_ (u"࠭ࠧ呓")
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ呔")+name+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ呕")+l111ll11_l1_
				l1lll1_l1_.append(l1llll1_l1_)
		if not l111111_l1_:
			#l111l1l_l1_ = hostname +l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡔࡪࡤ࡬࡮ࡪ࠴ࡶ࠱ࡄ࡮ࡦࡾࡡࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡵ࡮ࡰࠨ呖")
			l111l1l_l1_ = hostname +l11l1l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡅࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵ࠭呗")
			l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ员"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ呙")}
			l11l1llll_l1_ = {l11l1l_l1_ (u"࠭ࡩࡥࠩ呚"):id}
			response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ呛"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩ呜"),l11l1l_l1_ (u"ࠩࠪ呝"),l11l1l_l1_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧ呞"))
			l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ呟"))
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ呠"),l11ll111_l1_,re.DOTALL)
			for l1llll1_l1_,name,l111ll11_l1_ in items:
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ呡")+name+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ呢")+l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭呣")+l111ll11_l1_
				l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ呤"),l1lll1_l1_)
	elif l11l1l_l1_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡓࡵࡷࠨ呥") in html:
		l1l1l1ll1_l1_ = { l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ呦"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ呧") }
		l111l1l_l1_ = l1llll1ll_l1_.replace(parts[3],l11l1l_l1_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ周"))
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ呩"),l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ呪"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠩࠪ呫"),l11l1l_l1_ (u"ࠪࠫ呬"),l11l1l_l1_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨ呭"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ呮"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ呯"),l11ll111_l1_,re.DOTALL)
		for block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩ呰"),block,re.DOTALL)
			for l1llll1_l1_,name,l111ll11_l1_ in items:
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ呱")+name+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭呲")+l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨ味")+l111ll11_l1_
				l1lll1_l1_.append(l1llll1_l1_)
	elif l11l1l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ呴") in html:
		l1l1l1ll1_l1_ = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ呵"):l11l1l_l1_ (u"࠭ࠧ呶") , l11l1l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ呷"):l11l1l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩ呸") }
		l111l1l_l1_ = hostname + l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬ呹")+id
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ呺"),l111l1l_l1_,l11l1l_l1_ (u"ࠫࠬ呻"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠬ࠭呼"),l11l1l_l1_ (u"࠭ࠧ命"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠷ࡶ࡫ࠫ呾"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭呿"))
		if l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱ࡧࡺ࡮ࡴࠩ咀") in l11ll111_l1_:
			l11111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ咁"),l11ll111_l1_,re.DOTALL)
			for l111ll1_l1_ in l11111l1l_l1_:
				if l11l1l_l1_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ咂") not in l111ll1_l1_ and l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ咃") in l111ll1_l1_:
					l111ll1_l1_ = l111ll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ咄")
					l1lll1_l1_.append(l111ll1_l1_)
				elif l11l1l_l1_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧ咅") in l111ll1_l1_:
					l111ll11_l1_ = l11l1l_l1_ (u"ࠨࠩ咆")
					response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭咇"),l111ll1_l1_,l11l1l_l1_ (u"ࠪࠫ咈"),headers,l11l1l_l1_ (u"ࠫࠬ咉"),l11l1l_l1_ (u"ࠬ࠭咊"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡒࡏࡅ࡞࠳࠷ࡵࡪࠪ咋"))
					l1111l1l1_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬ和"))
					l111111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠿ࡷࡹࡸ࡯࡯ࡩࡁ࠲࠯ࡅࠩ࠮࠯࠰࠱࠲࠭咍"),l1111l1l1_l1_,re.DOTALL)
					for l111l1lll_l1_ in l111111_l1_:
						l1111ll11_l1_ = l11l1l_l1_ (u"ࠩࠪ咎")
						l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬ咏"),l111l1lll_l1_,re.DOTALL)
						for l111l111l_l1_ in l111111l1_l1_:
							item = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ咐"),l111l111l_l1_,re.DOTALL)
							if item:
								l111ll11_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ咑")+item[0]
								break
						for l111l111l_l1_ in reversed(l111111l1_l1_):
							item = re.findall(l11l1l_l1_ (u"࠭࡜ࡸ࡞ࡺ࠯ࠬ咒"),l111l111l_l1_,re.DOTALL)
							if item:
								l1111ll11_l1_ = item[0]
								break
						l1111111l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭咓"),l111l1lll_l1_,re.DOTALL)
						for l1111lll1_l1_ in l1111111l_l1_:
							l1111lll1_l1_ = l1111lll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ咔")+l1111ll11_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭咕")+l111ll11_l1_
							l1lll1_l1_.append(l1111lll1_l1_)
		elif l11l1l_l1_ (u"ࠪࡷࡱࡵࡷ࠮࡯ࡲࡸ࡮ࡵ࡮ࠨ咖") in l11ll111_l1_:
			l11ll111_l1_ = l11ll111_l1_.replace(l11l1l_l1_ (u"ࠫࡁ࡮࠶ࠡࠩ咗"),l11l1l_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂࠦ࠽࠾ࡕࡗࡅࡗ࡚࠽࠾ࠩ咘"))+l11l1l_l1_ (u"࠭࠽࠾ࡇࡑࡈࡂࡃࠧ咙")
			l11ll111_l1_ = l11ll111_l1_.replace(l11l1l_l1_ (u"ࠧ࠽ࡪ࠶ࠤࠬ咚"),l11l1l_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬ咛"))+l11l1l_l1_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪ咜")
			l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡁࡂ࡙ࡔࡂࡔࡗࡁࡂ࠮࠮ࠫࡁࠬࡁࡂࡋࡎࡅ࠿ࡀࠫ咝"),l11ll111_l1_,re.DOTALL)
			if l111111ll_l1_:
				for l111l1lll_l1_ in l111111ll_l1_:
					if l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠪ咞") not in l111l1lll_l1_: continue
					l111l11l1_l1_ = l11l1l_l1_ (u"ࠬ࠭咟")
					l111111l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ咠"),l111l1lll_l1_,re.DOTALL)
					for l111l111l_l1_ in l111111l1_l1_:
						item = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ咡"),l111l111l_l1_,re.DOTALL)
						if item:
							l111l11l1_l1_ = l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭咢")+item[0]
							break
					l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ咣"),l111l1lll_l1_,re.DOTALL)
					if l111111l1_l1_:
						for l1111ll11_l1_,l1111ll1l_l1_ in l111111l1_l1_:
							l1111ll1l_l1_ = l1111ll1l_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ咤")+l1111ll11_l1_+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ咥")+l111l11l1_l1_
							l1lll1_l1_.append(l1111ll1l_l1_)
					else:
						l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ咦"),l111l1lll_l1_,re.DOTALL)
						for l1111ll1l_l1_,l1111ll11_l1_ in l111111l1_l1_:
							l1111ll1l_l1_ = l1111ll1l_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠨ咧"))+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ咨")+l1111ll11_l1_+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ咩")+l111l11l1_l1_
							l1lll1_l1_.append(l1111ll1l_l1_)
			else:
				l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭ࡢࡷࠬࠫ࠿ࠫ咪"),l11ll111_l1_,re.DOTALL)
				for l1111ll1l_l1_,l1111ll11_l1_ in l111111l1_l1_:
					l1111ll1l_l1_ = l1111ll1l_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ咫"))+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ咬")+l1111ll11_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ咭")
					l1lll1_l1_.append(l1111ll1l_l1_)
	if l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭࠵ࠧ咮") in html:
		# l11l11lll_l1_
		l11ll111l1l1_l1_ = url.split(l11l1l_l1_ (u"ࠧ࠰ࠩ咯"))[3]
		l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠨ࠱ࠪ咰")+l11ll111l1l1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ咱"),l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ咲"))
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ咳"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭咴"),l11l1l_l1_ (u"࠭ࠧ咵"),l11l1l_l1_ (u"ࠧࠨ咶"),l11l1l_l1_ (u"ࠨࠩ咷"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠻ࡸ࡭࠭咸"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ咹"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡹࡥࡳࡸࡨࡶࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ咺"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		l1l1lll_l1_ = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡂ࡬ࡪ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ咻"),l1l1lll_l1_,re.DOTALL)
		for server,title in items:
			title = title.replace(l11l1l_l1_ (u"࠭࡜ࡵࠩ咼"),l11l1l_l1_ (u"ࠧࠨ咽")).replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ咾"),l11l1l_l1_ (u"ࠩࠪ咿")).strip(l11l1l_l1_ (u"ࠪࠤࠬ哀"))
			l111l1l_l1_ = hostname+l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡳࡦࡴࡹࡩࡷࠬ࡟ࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠩ品")+id+l11l1l_l1_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ哂")+server
			l1llll1_l1_ = l111l1l_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ哃")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ哄")
			l1lll1_l1_.append(l1llll1_l1_)
		# l1l1111l1_l1_
		l1l1111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ哅"),l11ll111_l1_,re.DOTALL)
		if l1l1111l1_l1_:
			l1llll1_l1_ = l1l1111l1_l1_[0]+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࡢࡣࡪࡳࡢࡦࡦࠪ哆")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ哇"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ哈"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ哉"),l11l1l_l1_ (u"࠭ࠫࠨ哊"))
	if 0 and l1ll_l1_:
		l1111l1ll_l1_ = [l11l1l_l1_ (u"ࠧศใ็ห๊࠭哋"),l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ哌"),l11l1l_l1_ (u"่้ࠩะ๊๊็ࠩ响"),l11l1l_l1_ (u"ࠪห้้ไࠨ哎")]
		l1l1lll11_l1_ = [l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ哏"),l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ哐"),l11l1l_l1_ (u"࠭ࡡࡤࡶࡲࡶࠬ哑"),l11l1l_l1_ (u"ࠧࠨ哒")]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨ็๋ๆ฾ࠦิศ้าࠤๆ๎ั๋๊ࠣ࠱ࠥอฮหำࠣห้็ไหำࠣห้๋ๆศีหࠫ哓"), l1111l1ll_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lll11_l1_[l1l_l1_]
	else: type = l11l1l_l1_ (u"ࠩࠪ哔")
	l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡍࡑࡑࡋࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡪࡲࡱࡪ࠭ࠬࠨࠩ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ࠭ࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠯ࡥࡲࡲࡹ࡫࡮ࡵࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡰࡤࡱࡪࡃࠢࡵࡻࡳࡩࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨࠩ࠯ࠫࠬ࠲ࡳࡵࡴࠫࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳࠪ࠮ࡶࡸࡷ࠮࡬ࡦࡰࠫ࡬ࡹࡳ࡬ࠪࠫࠬࠎࠎ࡯ࡦࠡࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸࠦࡡ࡯ࡦࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠱࡬ࡩ࡭ࡶࡨࡶࡑࡏࡓࡕࠢࡀࠤࡠࡣࠬ࡜࡟ࠍࠍࠎ࡬࡯ࡳࠢࡦࡥࡹ࡫ࡧࡰࡴࡼ࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠ࡜ࠩ฼ีํ฼ࠠๆืสี฾ฯࠧ࡞࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࡨࡰࡸ࡫࠺ࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥ࠭ࠧࠋࠋࠦࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠤࠥࠦ哕")
	l1l1ll1_l1_ = l1ll1l111ll_l1_(l11l11_l1_,l11l1l_l1_ (u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭哖"),l11l1l_l1_ (u"ฺࠬว่ัࠣๅํื๋๊ࠠࠣ࠱࡙ࠥࡨࡢࡪ࡬ࡨ࠹ࡻࠧ哗"))
	#url = l1l1ll1_l1_ + l11l1l_l1_ (u"࠭࠯ࡀࡵࡀࠫ哘")+search+l11l1l_l1_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧ哙")+type
	url = l1l1ll1_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ哚")+search
	l1lllll_l1_(url)
	return
# ===========================================
#     l1lll1l111_l1_ l1lll11lll_l1_ l1lll1l11l_l1_
# ===========================================
def l1llll1l1l_l1_(url):
	url = url.split(l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭哛"))[0]
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ哜"),url,l11l1l_l1_ (u"ࠫࠬ哝"),headers,l11l1l_l1_ (u"ࠬ࠭哞"),l11l1l_l1_ (u"࠭ࠧ哟"),l11l1l_l1_ (u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯ࡊࡉ࡙ࡥࡆࡊࡎࡗࡉࡗ࡙࡟ࡃࡎࡒࡇࡐ࡙࠭࠲ࡵࡷࠫ哠"))
	html = response.content
	# all l111111_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡤࡨࡻࡧ࡮ࡤࡧࡧ࠱ࡸ࡫ࡡࡳࡥ࡫ࠦ࠭࠴ࠪࡀࠫ࠿࠳࡫ࡵࡲ࡮ࡀࠪ員"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		# name + category + options block
		l1ll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡳࡻ࠮ࠫࡁࡵࡳࡺࡴࡤࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡩ࡯ࡲࡸࡸࠥࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ哢"),block,re.DOTALL)
		return l1ll1l11_l1_
	return []
def l1lll1ll11_l1_(block):
	# id + title
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡥࡤࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡥ࡫ࡩࡨࡱ࡭ࡢࡴ࡮࠱ࡧࡵ࡬ࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ哣"),block,re.DOTALL)
	return items
def l11ll1111ll1_l1_(url):
	url = url.replace(l11l1l_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ哤"),l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ哥"))
	if l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ哦") not in url: url = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ哧")
	l1llll11ll_l1_ = url.split(l11l1l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ哨"))[0]
	l1lll1lll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭哩"))
	url = url.replace(l1llll11ll_l1_,l1lll1lll1_l1_)
	#url = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ哪"),l11l1l_l1_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡖ࡬ࡦ࡮ࡩࡥ࠶ࡸ࠳ࡆࡰࡡࡹࡣࡷ࠳ࡍࡵ࡭ࡦ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࡘ࡮࡯ࡸࡵ࠱ࡴ࡭ࡶ࠿ࠨ哫"))
	#url = url.replace(l11l1l_l1_ (u"ࠬ࠵ࡳ࡮ࡣࡵࡸࡪࡳࡡࡥࡨ࡬ࡰࡹ࡫ࡲࡀࠩ哬"),l11l1l_l1_ (u"࠭࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡹ࡮ࡥ࡮ࡧࡶ࠳ࡹ࡮ࡥ࡮ࡧ࠲ࡅ࡯ࡧࡸࡢࡶ࠲ࡌࡴࡳࡥ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡗ࡭ࡵࡷࡴ࠰ࡳ࡬ࡵࡅࠧ哭"))
	url = url.replace(l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ哮"),l11l1l_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬ哯"))
	return url
l11ll111l111_l1_ = [l11l1l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ哰"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ哱"),l11l1l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ哲"),l11l1l_l1_ (u"ࠬࡩࡡࡵࠩ哳")]
l11ll111l1ll_l1_ = [l11l1l_l1_ (u"࠭ࡣࡢࡶࠪ哴"),l11l1l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭哵"),l11l1l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ哶")]
def l1ll1l1l_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ哷"),l11l1l_l1_ (u"ࠪࠫ哸"))
	url = url.split(l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ哹"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩ哺"),1)
	if filter==l11l1l_l1_ (u"࠭ࠧ哻"): l1l11111_l1_,l11lllll_l1_ = l11l1l_l1_ (u"ࠧࠨ哼"),l11l1l_l1_ (u"ࠨࠩ哽")
	else: l1l11111_l1_,l11lllll_l1_ = filter.split(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭哾"))
	if type==l11l1l_l1_ (u"ࠪࡈࡊࡌࡉࡏࡇࡇࡣࡋࡏࡌࡕࡇࡕࠫ哿"):
		if l11ll111l1ll_l1_[0]+l11l1l_l1_ (u"ࠫࡂ࠭唀") not in l1l11111_l1_: category = l11ll111l1ll_l1_[0]
		for i in range(len(l11ll111l1ll_l1_[0:-1])):
			if l11ll111l1ll_l1_[i]+l11l1l_l1_ (u"ࠬࡃࠧ唁") in l1l11111_l1_: category = l11ll111l1ll_l1_[i+1]
		l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"࠭ࠦࠨ唂")+category+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ唃")
		l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠨࠨࠪ唄")+category+l11l1l_l1_ (u"ࠩࡀ࠴ࠬ唅")
		l1l11l11_l1_ = l1l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬ唆"))+l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ唇")+l1l1l1l1_l1_.strip(l11l1l_l1_ (u"ࠬࠬࠧ唈"))
		l11lll11_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ唉"))
		l111l1l_l1_ = url+l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ唊")+l11lll11_l1_
	elif type==l11l1l_l1_ (u"ࠨࡈࡘࡐࡑࡥࡆࡊࡎࡗࡉࡗ࠭唋"):
		l11l1lll_l1_ = l11lll1l_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ唌"))
		l11l1lll_l1_ = l1llll_l1_(l11l1lll_l1_)
		if l11lllll_l1_!=l11l1l_l1_ (u"ࠪࠫ唍"): l11lllll_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ唎"))
		if l11lllll_l1_==l11l1l_l1_ (u"ࠬ࠭唏"): l111l1l_l1_ = url
		else: l111l1l_l1_ = url+l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ唐")+l11lllll_l1_
		l111ll1_l1_ = l11ll1111ll1_l1_(l111l1l_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ唑"),l1111l_l1_+l11l1l_l1_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ唒"),l111ll1_l1_,111)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ唓"),l1111l_l1_+l11l1l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ唔")+l11l1lll_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ唕"),l111ll1_l1_,111)
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ唖"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭唗"),l11l1l_l1_ (u"ࠧࠨ唘"),9999)
	l1ll1l11_l1_ = l1llll1l1l_l1_(url)
	dict = {}
	for name,l1ll11l1_l1_,block in l1ll1l11_l1_:
		name = name.replace(l11l1l_l1_ (u"ࠨ࠯࠰ࠫ唙"),l11l1l_l1_ (u"ࠩࠪ唚"))
		items = l1lll1ll11_l1_(block)
		if l11l1l_l1_ (u"ࠪࡁࠬ唛") not in l111l1l_l1_: l111l1l_l1_ = url
		if type==l11l1l_l1_ (u"ࠫࡉࡋࡆࡊࡐࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬ唜"):
			if category!=l1ll11l1_l1_: continue
			elif len(items)<2:
				if l1ll11l1_l1_==l11ll111l1ll_l1_[-1]:
					l111ll1_l1_ = l11ll1111ll1_l1_(l111l1l_l1_)
					l1lllll_l1_(l111ll1_l1_)
				else: l1ll1l1l_l1_(l111l1l_l1_,l11l1l_l1_ (u"ࠬࡊࡅࡇࡋࡑࡉࡉࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ唝")+l1l11l11_l1_)
				return
			else:
				if l1ll11l1_l1_==l11ll111l1ll_l1_[-1]:
					l111ll1_l1_ = l11ll1111ll1_l1_(l111l1l_l1_)
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭唞"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠠࠨ唟"),l111ll1_l1_,111)
				else: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ唠"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪ唡"),l111l1l_l1_,115,l11l1l_l1_ (u"ࠪࠫ唢"),l11l1l_l1_ (u"ࠫࠬ唣"),l1l11l11_l1_)
		elif type==l11l1l_l1_ (u"ࠬࡌࡕࡍࡎࡢࡊࡎࡒࡔࡆࡔࠪ唤"):
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"࠭ࠦࠨ唥")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠧ࠾࠲ࠪ唦")
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠨࠨࠪ唧")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠩࡀ࠴ࠬ唨")
			l1l11l11_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ唩")+l1l1l1l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ唪"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠥࡀࠧ唫")+name,l111l1l_l1_,114,l11l1l_l1_ (u"࠭ࠧ唬"),l11l1l_l1_ (u"ࠧࠨ唭"),l1l11l11_l1_)		# +l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ售"))
		dict[l1ll11l1_l1_] = {}
		for value,option in items:
			if value==l11l1l_l1_ (u"ࠩ࠴࠽࠻࠻࠳࠴ࠩ唯"): option = l11l1l_l1_ (u"ࠪวๆ๊วๆ้ࠢ๎ฯ็ไไีࠪ唰")
			elif value==l11l1l_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠴ࠫ唱"): option = l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦๆ๋ฬไู่่ࠧ唲")
			if option in l1l111_l1_: continue
			#if l11l1l_l1_ (u"࠭ࡶࡢ࡮ࡸࡩࠬ唳") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"ࠧࠣࠪ࠱࠮ࡄ࠯ࠢࠨ唴"),value,re.DOTALL)[0]
			dict[l1ll11l1_l1_][value] = option
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪ唵")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠩࡀࠫ唶")+option
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠪࠪࠬ唷")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠫࡂ࠭唸")+value
			l1ll111l_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩ唹")+l1l1l1l1_l1_
			title = option+l11l1l_l1_ (u"࠭ࠠ࠻ࠩ唺")#+dict[l1ll11l1_l1_][l11l1l_l1_ (u"ࠧ࠱ࠩ唻")]
			title = option+l11l1l_l1_ (u"ࠨࠢ࠽ࠫ唼")+name
			if type==l11l1l_l1_ (u"ࠩࡉ࡙ࡑࡒ࡟ࡇࡋࡏࡘࡊࡘࠧ唽"): addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ唾"),l1111l_l1_+title,url,114,l11l1l_l1_ (u"ࠫࠬ唿"),l11l1l_l1_ (u"ࠬ࠭啀"),l1ll111l_l1_)		# +l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ啁"))
			elif type==l11l1l_l1_ (u"ࠧࡅࡇࡉࡍࡓࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ啂") and l11ll111l1ll_l1_[-2]+l11l1l_l1_ (u"ࠨ࠿ࠪ啃") in l1l11111_l1_:
				l11lll11_l1_ = l11lll1l_l1_(l1l1l1l1_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ啄"))
				l111l1l_l1_ = url+l11l1l_l1_ (u"ࠪ࠳ࡸࡳࡡࡳࡶࡨࡱࡦࡪࡦࡪ࡮ࡷࡩࡷࡅࠧ啅")+l11lll11_l1_
				l111ll1_l1_ = l11ll1111ll1_l1_(l111l1l_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ商"),l1111l_l1_+title,l111ll1_l1_,111)
			else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ啇"),l1111l_l1_+title,url,115,l11l1l_l1_ (u"࠭ࠧ啈"),l11l1l_l1_ (u"ࠧࠨ啉"),l1ll111l_l1_)
	return
def l11lll1l_l1_(filters,mode):
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ啊")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ values
	# mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ啋")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ filters
	# mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ啌")					all l1l1l111_l1_ & l1llll111l_l1_ filters
	filters = filters.replace(l11l1l_l1_ (u"ࠫࡂࠬࠧ啍"),l11l1l_l1_ (u"ࠬࡃ࠰ࠧࠩ啎"))
	filters = filters.strip(l11l1l_l1_ (u"࠭ࠦࠨ問"))
	l1l1111l_l1_ = {}
	if l11l1l_l1_ (u"ࠧ࠾ࠩ啐") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠨࠨࠪ啑"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠩࡀࠫ啒"))
			l1l1111l_l1_[var] = value
	l1ll1111_l1_ = l11l1l_l1_ (u"ࠪࠫ啓")
	for key in l11ll111l111_l1_:
		if key in list(l1l1111l_l1_.keys()): value = l1l1111l_l1_[key]
		else: value = l11l1l_l1_ (u"ࠫ࠵࠭啔")
		if l11l1l_l1_ (u"ࠬࠫࠧ啕") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ啖") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩ啗"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠨࠢ࠮ࠤࠬ啘")+value
		elif mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ啙") and value!=l11l1l_l1_ (u"ࠪ࠴ࠬ啚"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠫࠫ࠭啛")+key+l11l1l_l1_ (u"ࠬࡃࠧ啜")+value
		elif mode==l11l1l_l1_ (u"࠭ࡡ࡭࡮ࠪ啝"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠧࠧࠩ啞")+key+l11l1l_l1_ (u"ࠨ࠿ࠪ啟")+value
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠩࠣ࠯ࠥ࠭啠"))
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬ啡"))
	l1ll1111_l1_ = l1ll1111_l1_.replace(l11l1l_l1_ (u"ࠫࡂ࠶ࠧ啢"),l11l1l_l1_ (u"ࠬࡃࠧ啣"))
	return l1ll1111_l1_
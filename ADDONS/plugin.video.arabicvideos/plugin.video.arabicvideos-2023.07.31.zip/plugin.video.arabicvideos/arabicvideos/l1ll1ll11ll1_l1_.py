# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡘ࡛ࡌࡕࡏࠩ奊")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤ࡚ࡖࡇࡡࠪ奋")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠬฮหࠡ็หหูืࠧ奌")]
def MAIN(mode,url,text):
	if   mode==460: results = MENU()
	elif mode==461: results = l1lllll_l1_(url,text)
	elif mode==462: results = PLAY(url)
	elif mode==463: results = l1lll1l1_l1_(url)
	elif mode==469: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ奍"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ奎"),l11l1l_l1_ (u"ࠨࠩ奏"),l11l1l_l1_ (u"ࠩࠪ奐"),l11l1l_l1_ (u"ࠪࠫ契"),l11l1l_l1_ (u"࡙ࠫ࡜ࡆࡖࡐ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ奒"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ奓"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭奔"),l11l1l_l1_ (u"ࠧࠨ奕"),469,l11l1l_l1_ (u"ࠨࠩ奖"),l11l1l_l1_ (u"ࠩࠪ套"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ奘"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ奙"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ奚")+l1111l_l1_+l11l1l_l1_ (u"࠭รฯำࠣห้ำไใษอࠫ奛"),l11l11_l1_,461,l11l1l_l1_ (u"ࠧࠨ奜"),l11l1l_l1_ (u"ࠨࠩ奝"),l11l1l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࠩ奞"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ奟"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ奠"),l11l1l_l1_ (u"ࠬ࠭奡"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢ࡮ࡧࡱࡹ࠲ࡨࡴ࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭奢"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭奣"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#if l1llll1_l1_==l11l1l_l1_ (u"ࠨࠥࠪ奤"): continue
			if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ奥") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if title==l11l1l_l1_ (u"ࠪห้ืฦ๋ีํอࠬ奦"): title = l11l1l_l1_ (u"ࠫัี๊ะࠢะ่็อสࠡฬํๅ๏ࠦแศ่ࠪ奧")
			if title in l1l111_l1_: continue
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ奨"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ奩")+l1111l_l1_+title,l1llll1_l1_,461)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡈࡲࡳࡹ࡫ࡲࡄࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ奪"),html,re.DOTALL)
	#if l1l11l1_l1_:
	#	block = l1l11l1_l1_[0]
	#	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ奫"),block,re.DOTALL)
	#	for l1llll1_l1_,title in items:
	#		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ奬"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ奭")+l1111l_l1_+title,l1llll1_l1_,461)
	return
def l1lllll_l1_(url,l1lll111ll_l1_=l11l1l_l1_ (u"ࠫࠬ奮")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭奯"),l11l1l_l1_ (u"࠭ࠧ奰"),l1lll111ll_l1_,url)
	items = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ奱"),url,l11l1l_l1_ (u"ࠨࠩ奲"),l11l1l_l1_ (u"ࠩࠪ女"),l11l1l_l1_ (u"ࠪࠫ奴"),l11l1l_l1_ (u"ࠫࠬ奵"),l11l1l_l1_ (u"࡚ࠬࡖࡇࡗࡑ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ奶"))
	html = response.content
	#if l1lll111ll_l1_==l11l1l_l1_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠭奷"): l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧฤะิࠤฬ๊อๅไสฮ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡦࡰࡱࡷࡩࡷࠨࠧ奸"),html,re.DOTALL)
	#else:
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡪࡨࡥࡩ࠳ࡴࡪࡶ࡯ࡩࠧ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢࡧࡱࡲࡸࡪࡸࠢࠨ她"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ奺"),block,re.DOTALL)
		l11l_l1_ = []
		l1ll11_l1_ = [l11l1l_l1_ (u"ู้ࠪอ็ะหࠪ奻"),l11l1l_l1_ (u"ࠫๆ๐ไๆࠩ奼"),l11l1l_l1_ (u"ࠬอฺ็์ฬࠫ好"),l11l1l_l1_ (u"࠭ใๅ์หࠫ奾"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭奿"),l11l1l_l1_ (u"ࠨ้าหๆ࠭妀"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩ妁"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧ如"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫ妃"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫ妄")]
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ妅") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)	#.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ妆"))
			l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ妇"),title,re.DOTALL)
			if any(value in title for value in l1ll11_l1_):
				addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ妈"),l1111l_l1_+title,l1llll1_l1_,462,l1ll1l_l1_)
			elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠪห้ำไใหࠪ妉") in title:
				title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ妊") + l1ll11l_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ妋"),l1111l_l1_+title,l1llll1_l1_,463,l1ll1l_l1_)
					l11l_l1_.append(title)
			else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭妌"),l1111l_l1_+title,l1llll1_l1_,463,l1ll1l_l1_)
	if l1lll111ll_l1_!=l11l1l_l1_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ妍"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ妎"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ妏"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ妐"))
				if l1llll1_l1_==l11l1l_l1_ (u"ࠦࠧ妑"): continue
				if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ妒") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
				#title = unescapeHTML(title)
				if title!=l11l1l_l1_ (u"࠭ࠧ妓"): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妔"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ妕")+title,l1llll1_l1_,461)
	return
def l1lll1l1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ妖"),l11l1l_l1_ (u"ࠪࠫ妗"),l11l1l_l1_ (u"ࠫࡊࡖࡉࡔࡑࡇࡉࡘ࠭妘"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ妙"),url,l11l1l_l1_ (u"࠭ࠧ妚"),l11l1l_l1_ (u"ࠧࠨ妛"),l11l1l_l1_ (u"ࠨࠩ妜"),l11l1l_l1_ (u"ࠩࠪ妝"),l11l1l_l1_ (u"ࠪࡘ࡛ࡌࡕࡏ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ妞"))
	html = response.content
	# l11ll_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥ࠯ࡷ࡭ࡹࡲࡥࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡪࡴࡵࡴࡦࡴࠥࠫ妟"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡶ࡯ࡥࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭妠"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ妡") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭妢"),l1111l_l1_+title,l1llll1_l1_,462,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ妣"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ妤"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ妥"))
			if l1llll1_l1_==l11l1l_l1_ (u"ࠦࠧ妦"): continue
			if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ妧") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			#title = unescapeHTML(title)
			if title!=l11l1l_l1_ (u"࠭ࠧ妨"): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ妩"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ妪")+title,l1llll1_l1_,463)
	return
def PLAY(url):
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭妫"),url,l11l1l_l1_ (u"ࠪࠫ妬"),l11l1l_l1_ (u"ࠫࠬ妭"),l11l1l_l1_ (u"ࠬ࠭妮"),l11l1l_l1_ (u"࠭ࠧ妯"),l11l1l_l1_ (u"ࠧࡕࡘࡉ࡙ࡓ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ妰"))
	html = response.content
	# l1l1111l1_l1_ l1llll1_l1_
	l11111l111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡨࡱࡧ࡫ࡤࡖࡴ࡯ࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ妱"),html,re.DOTALL)
	if l11111l111_l1_:
		l11111l111_l1_ = l11111l111_l1_[0]
		if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ妲") not in l11111l111_l1_:
			if l11l1l_l1_ (u"ࠪ࠳࠴࠭妳") in l11111l111_l1_: l11111l111_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ妴")+l11111l111_l1_
			else: l11111l111_l1_ = l11l11_l1_+l11111l111_l1_
		l11111l111_l1_ = l11111l111_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭妵")
		l1lll1_l1_.append(l11111l111_l1_)
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡢ࠲࠷࠽ࡦࡪ࡬࡯ࡳࡧࠫ࠲࠯ࡅࠩࡴ࡯ࡤࡰࡱ࠴ࠪࡀࠤ࡙࡭ࡩ࡫࡯ࡔࡧࡵࡺࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡑ࡮ࡤࡽࠧ࠭妶"),html,re.DOTALL)
	if l1l11l1_l1_:
		l11l1ll1l111_l1_,l11l1ll1l11l_l1_ = l1l11l1_l1_[0]
		names = re.findall(l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ妷"),l11l1ll1l111_l1_,re.DOTALL)
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠣࡵࡨࡸ࡛࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ妸"),l11l1ll1l11l_l1_,re.DOTALL)
		l11l1ll11lll_l1_ = zip(names,l1l1_l1_)
		for name,l1l1l1l1l111_l1_ in l11l1ll11lll_l1_:
			l1l1l1l1l111_l1_ = l1l1l1l1l111_l1_[2:]
			if kodi_version<19: l1l1l1l1l111_l1_ = l1l1l1l1l111_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧ妹"))
			l1l1l1l1l111_l1_ = base64.b64decode(l1l1l1l1l111_l1_)
			if kodi_version>18.99: l1l1l1l1l111_l1_ = l1l1l1l1l111_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ妺"))
			l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ妻"),l1l1l1l1l111_l1_,re.DOTALL)
			l1llll1_l1_ = l1llll1_l1_[0]
		if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ妼") not in l1llll1_l1_:
			if l11l1l_l1_ (u"࠭࠯࠰ࠩ妽") in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴ࠿࠭妾")+l1llll1_l1_
			else: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ妿")+name+l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ姀")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ姁"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ姂"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	if l11l1l_l1_ (u"ࠬࠦࠧ姃") in search:
		if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ姄"),l11l1l_l1_ (u"ࠧࠨ姅"),l11l1l_l1_ (u"ࠨࡖ࡙ࡊ࡚ࡔࠠๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧ姆"),l11l1l_l1_ (u"ࠩ็่ศูแࠡษ็ฬาัࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠๅษࠣ๎฾๋ไࠡ฻้ำࠥ฽ไษࠢฦ็ะืࠠๆ่ࠣ็้๋ษ๊ࠡสัิฯࠠ࠯࠰࠱ࠤ๏ืฬ๊ࠢส่อำหࠡ฻้ࠤ่๊ๅส๋ࠢหาีษࠡใๅ฻ࠬ姇"))
		return
	#search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬ姈"),l11l1l_l1_ (u"ࠫ࠲࠭姉"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭姊")+search
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡲ࠱ࠪ始")+search+l11l1l_l1_ (u"ࠧ࠰ࠩ姌")
	l1lllll_l1_(url)
	return
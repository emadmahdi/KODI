﻿# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#import unicodedata,simplejson
def MAIN(mode,l1l1l111ll1_l1_):
	if l1l1l111ll1_l1_==l11l1l_l1_ (u"ࠬ࠭ㅮ"): return
	if mode==1:
		l1l1l111l1l_l1_ = xbmcgui.l1l1l111l11_l1_()
		l1l1l1111ll_l1_ = xbmcgui.l1l11lll1ll_l1_(l1l1l111l1l_l1_)
		l1l1l111ll1_l1_ = l1l1l1111l1_l1_(l1l1l111ll1_l1_)
		l1l1l1111ll_l1_.getControl(311).l1l1l11l111_l1_(l1l1l111ll1_l1_)
	if mode==0:
		#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧㅯ"))
		#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬㅰ"))
		#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ㅱ"))
		l1l11llll1l_l1_=l11l1l_l1_ (u"࡛ࠩࠫㅲ")
		if kodi_version>18.99: check = isinstance(l1l1l111ll1_l1_,str)
		else: check = isinstance(l1l1l111ll1_l1_,unicode)
		if check==True: l1l11llll1l_l1_=l11l1l_l1_ (u"࡙ࠪࠬㅳ")
		l1l11llll11_l1_=str(type(l1l1l111ll1_l1_))+l11l1l_l1_ (u"ࠫࠥ࠭ㅴ")+l1l1l111ll1_l1_+l11l1l_l1_ (u"ࠬࠦࠧㅵ")+l1l11llll1l_l1_+l11l1l_l1_ (u"࠭ࠠࠨㅶ")
		for i in range(0,len(l1l1l111ll1_l1_),1):
			l1l11llll11_l1_ += hex(ord(l1l1l111ll1_l1_[i])).replace(l11l1l_l1_ (u"ࠧ࠱ࡺࠪㅷ"),l11l1l_l1_ (u"ࠨࠩㅸ"))+l11l1l_l1_ (u"ࠩࠣࠫㅹ")
		l1l1l111ll1_l1_ = l1l1l1111l1_l1_(l1l1l111ll1_l1_)
		#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨㅺ"))
		l1l11llll1l_l1_=l11l1l_l1_ (u"ࠫ࡝࠭ㅻ")
		if kodi_version>18.99: check = isinstance(l1l1l111ll1_l1_, str)
		else: check = isinstance(l1l1l111ll1_l1_, unicode)
		if check==True: l1l11llll1l_l1_=l11l1l_l1_ (u"࡛ࠬࠧㅼ")
		l1l11lllll1_l1_=str(type(l1l1l111ll1_l1_))+l11l1l_l1_ (u"࠭ࠠࠨㅽ")+l1l1l111ll1_l1_+l11l1l_l1_ (u"ࠧࠡࠩㅾ")+l1l11llll1l_l1_+l11l1l_l1_ (u"ࠨࠢࠪㅿ")
		for i in range(0,len(l1l1l111ll1_l1_),1):
			l1l11lllll1_l1_ += hex(ord(l1l1l111ll1_l1_[i])).replace(l11l1l_l1_ (u"ࠩ࠳ࡼࠬㆀ"),l11l1l_l1_ (u"ࠪࠫㆁ"))+l11l1l_l1_ (u"ࠫࠥ࠭ㆂ")
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ㆃ"),l11l1l_l1_ (u"࠭ࠧㆄ"),l1l11llll11_l1_,l1l11lllll1_l1_)
	return
	#for i in range(0,len(l1l1l111ll1_l1_)-2,3):
	#	string=hex(ord(l1l1l111ll1_l1_[i+0]))+l11l1l_l1_ (u"ࠧࠡࠢࠪㆅ")+hex(ord(l1l1l111ll1_l1_[i+1]))+l11l1l_l1_ (u"ࠨࠢࠣࠫㆆ")+hex(ord(l1l1l111ll1_l1_[i+2]))
	#	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪㆇ"),l11l1l_l1_ (u"ࠪࠫㆈ"),l11l1l_l1_ (u"ࠫࠬㆉ"),string)
	#return
	#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪㆊ"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧㆋ"),l11l1l_l1_ (u"ࠧࠨㆌ"),l11l1l_l1_ (u"ࠨࠩㆍ"),l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l1l1l1111l1_l1_(l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㆎ"))
	#l1l1l111ll1_l1_ = unicodedata.normalize(l11l1l_l1_ (u"ࠪࡒࡋࡑࡄࠨ㆏"),l1l1l111ll1_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㆐"),l11l1l_l1_ (u"ࠬ࠭㆑"),l11l1l_l1_ (u"࠭ࠧ㆒"),   hex(  unicodedata.combining(l1l1l111ll1_l1_[0])  )   )
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㆓"),l11l1l_l1_ (u"ࠨࠩ㆔"),l1l1l111ll1_l1_,   hex(ord(  l1l1l111ll1_l1_[0]  ))   )
	#new = l11l1l_l1_ (u"ࠩࠪ㆕")
	#for l1l1l111111_l1_ in l1l1l111ll1_l1_:
	#	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㆖"),l11l1l_l1_ (u"ࠫࠬ㆗"),l11l1l_l1_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ㆘"),unicodedata.decomposition(l1l1l111111_l1_) )
	#	new += l11l1l_l1_ (u"࠭࡜ࡶ࠲ࠪ㆙") + hex(ord(l1l1l111111_l1_)).replace(l11l1l_l1_ (u"ࠧ࠱ࡺࠪ㆚"),l11l1l_l1_ (u"ࠨࠩ㆛"))
	#l1l1l111ll1_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㆜"),l11l1l_l1_ (u"ࠪࠫ㆝"),l11l1l_l1_ (u"ࠫࠬ㆞"),l1l1l111ll1_l1_)
	#new = l11l1l_l1_ (u"ࠬ࠭㆟")
	#for i in range(len(l1l1l111ll1_l1_)-6,-5,-6):
	#	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧㆠ"),l11l1l_l1_ (u"ࠧࠨㆡ"),l11l1l_l1_ (u"ࠨࠩㆢ"),str(i))
	#	new += l1l1l111ll1_l1_[i] + l1l1l111ll1_l1_[i+1] + l1l1l111ll1_l1_[i+2] + l1l1l111ll1_l1_[i+3] + l1l1l111ll1_l1_[i+4] + l1l1l111ll1_l1_[i+5]
	#l1l1l111ll1_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪㆣ"),l11l1l_l1_ (u"ࠪࠫㆤ"),l11l1l_l1_ (u"ࠫࠬㆥ"),l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ㆦ"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧㆧ"),l11l1l_l1_ (u"ࠧࠨㆨ"),l11l1l_l1_ (u"ࠨࠩㆩ"),l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㆪ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫㆫ"),l11l1l_l1_ (u"ࠫࠬㆬ"),l11l1l_l1_ (u"ࠬ࠭ㆭ"),l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l11l1l_l1_ (u"࠭ࡥ࡮ࡣࡧࠫㆮ")
	#l1l1l11111l_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡉ࡯ࡲࡸࡸ࠳࡙ࡥ࡯ࡦࡗࡩࡽࡺࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠭ㆯ")+l1l1l111ll1_l1_+l11l1l_l1_ (u"ࠨࠤ࠯ࠦࡩࡵ࡮ࡦࠤ࠽ࡪࡦࡲࡳࡦࡿ࠯ࠦ࡮ࡪࠢ࠻࠳ࢀࠫㆰ"))
	#simplejson.loads(l1l1l11111l_l1_)
	#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧㆱ"))
	#new = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫㆲ"))
	#l1l1l111ll1_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬㆳ"),l11l1l_l1_ (u"ࠬ࠭ㆴ"),l11l1l_l1_ (u"࠭ࠧㆵ"),l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l1l1l1111l1_l1_(l1l1l111ll1_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨㆶ"),l11l1l_l1_ (u"ࠨࠩㆷ"),l11l1l_l1_ (u"ࠩࠪㆸ"),l1l1l111ll1_l1_)
	#new = l11l1l_l1_ (u"ࠪࠫㆹ")
	#for i in range(len(l1l1l111ll1_l1_)-2,-1,-2):
	#	new += l1l1l111ll1_l1_[i] + l1l1l111ll1_l1_[i+1]
	#l1l1l111ll1_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬㆺ"),l11l1l_l1_ (u"ࠬ࠭ㆻ"),l11l1l_l1_ (u"࠭ࠧㆼ"),l1l1l111ll1_l1_)
	#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬㆽ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩㆾ"),l11l1l_l1_ (u"ࠩࠪㆿ"),l11l1l_l1_ (u"ࠪࠫ㇀"),l1l1l111ll1_l1_)
	#new = l11l1l_l1_ (u"ࠫࠬ㇁")
	#for i in range(len(l1l1l111ll1_l1_)-2,-1,-2):
	#	new += l1l1l111ll1_l1_[i] + l1l1l111ll1_l1_[i+1]
	#l1l1l111ll1_l1_ = new
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㇂"),l11l1l_l1_ (u"࠭ࠧ㇃"),l11l1l_l1_ (u"ࠧࠨ㇄"),l1l1l111ll1_l1_)
		#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.replace(l11l1l_l1_ (u"ࠨࠢࠪ㇅"),l11l1l_l1_ (u"ࠩࠪ㇆"))
		#new = l11l1l_l1_ (u"ࠪࠫ㇇")
		#for i in range(len(l1l1l111ll1_l1_)-3,-2,-3):
		#	new += l1l1l111ll1_l1_[i] + l1l1l111ll1_l1_[i+1] + l1l1l111ll1_l1_[i+2]
		#l1l1l111ll1_l1_ = new
		#new = l11l1l_l1_ (u"ࠫࠬ㇈")
		#for i in range(len(l1l1l111ll1_l1_)-2,-1,-2):
		#	new += l1l1l111ll1_l1_[i] + l1l1l111ll1_l1_[i+1]
		#l1l1l111ll1_l1_ = new
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㇉"),l11l1l_l1_ (u"࠭ࠧ㇊"),l11l1l_l1_ (u"ࠧࠨ㇋"),l1l1l111ll1_l1_)
		#l1l1l111ll1_l1_ = l1l1l111ll1_l1_.l1l1l111lll_l1_(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭㇌"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㇍"),l11l1l_l1_ (u"ࠪࠫ㇎"),str(ord(l1l1l111ll1_l1_[0]))+l11l1l_l1_ (u"ࠫࠥ࠭㇏")+str(ord(l1l1l111ll1_l1_[1]))+l11l1l_l1_ (u"ࠬࠦࠧ㇐")+str(ord(l1l1l111ll1_l1_[2])),str(len(l1l1l111ll1_l1_)))
		#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㇑"),l11l1l_l1_ (u"ࠧࠨ㇒"),l11l1l_l1_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠡࡎࡨࡸࡹ࡫ࡲࡴࠩ㇓"),l1l1l111ll1_l1_)
		#new = l11l1l_l1_ (u"ࠩࠪ㇔")
		#for i in range(len(l1l1l111ll1_l1_)-2,-1,-2):
		#	new += l1l1l111ll1_l1_[i] + l1l1l111ll1_l1_[i+1]
		#l1l1l111ll1_l1_ = new
		#new = l1l1l111ll1_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ㇕"))
		#new = new.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇖"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㇗"),l11l1l_l1_ (u"࠭ࠧ㇘"),l11l1l_l1_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ㇙"),new )
		#l1l11llll11_l1_ = l11l1l_l1_ (u"ࠨࠩ㇚")
		#for l1l1l111111_l1_ in new:
		#	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㇛"),l11l1l_l1_ (u"ࠪࠫ㇜"),l11l1l_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㇝"),unicodedata.decomposition(l1l1l111111_l1_) )
		#	l1l11llll11_l1_ += l11l1l_l1_ (u"ࠬࡢࡵࠨ㇞") + hex(ord(l1l1l111111_l1_)).replace(l11l1l_l1_ (u"࠭ࡸࠨ㇟"),l11l1l_l1_ (u"ࠧࠨ㇠"))
		#l1l11llll11_l1_ = l1l11llll11_l1_.decode(l11l1l_l1_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ㇡"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㇢"),l11l1l_l1_ (u"ࠪࠫ㇣"),l11l1l_l1_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ㇤"),l1l11llll11_l1_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1l1l1111l1_l1_(new)
		#l1l1l111ll1_l1_ = new.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ㇥"))
		#new = new.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ㇦")) #.decode(l11l1l_l1_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ㇧"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㇨"),l11l1l_l1_ (u"ࠩࠪ㇩"),l11l1l_l1_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ㇪"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㇫")))   )
		#l1l1l111ll1_l1_ = l1l1l1111l1_l1_(new)
		#l1l1l111ll1_l1_ = l1l1l1111l1_l1_(l1l1l111ll1_l1_)
		#method=l11l1l_l1_ (u"ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨ㇬")
		#params=l11l1l_l1_ (u"࠭ࡻࠣࡶࡨࡼࡹࠨ࠺ࠣࠧࡶࠦ࠱ࠦࠢࡥࡱࡱࡩࠧࡀࡦࡢ࡮ࡶࡩࢂ࠭㇭") % l1l1l111ll1_l1_
		#l1l1l11111l_l1_ = xbmc.executeJSONRPC(l11l1l_l1_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠥࠨ࠲࠯࠲ࠥ࠰ࠥࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠡࠤࠨࡷࠧ࠲ࠠࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࠣࠩࡸ࠲ࠠࠣ࡫ࡧࠦ࠿ࠦ࠱ࡾࠩ㇮") % (method, params))
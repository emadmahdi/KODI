# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#l11l11_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡭ࡪ࠮࠵ࡪࡨࡰࡦࡲ࠮ࡵࡸࠪᦛ")
#l11l11_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠺ࡨࡦ࡮ࡤࡰ࠳ࡺࡶࠨᦜ")
#l11l11_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࠸࡭࡫࡬ࡢ࡮࠱ࡸࡻ࠭ᦝ")
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓࠨᦞ")
headers = { l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᦟ") : l11l1l_l1_ (u"ࠨࠩᦠ") }
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡇࡒࡌ࡟ࠨᦡ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,text):
	if   mode==90: results = MENU()
	elif mode==91: results = ITEMS(url)
	elif mode==92: results = PLAY(url)
	elif mode==94: results = l1llll111_l1_()
	elif mode==95: results = l1lll1l1_l1_(url)
	elif mode==99: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦢ"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫᦣ"),l11l1l_l1_ (u"ࠬ࠭ᦤ"),99,l11l1l_l1_ (u"࠭ࠧᦥ"),l11l1l_l1_ (u"ࠧࠨᦦ"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᦧ"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᦨ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᦩ"),l11l1l_l1_ (u"ࠫࠬᦪ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦫ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᦬")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭᦭"),l11l1l_l1_ (u"ࠨࠩ᦮"),94)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᦯"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᦰ")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊รฮัฮࠫᦱ"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡡࡵࡧࡶࡸࠬᦲ"),91)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦳ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᦴ")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ว฾๊้ࠡฬๅ๎๊อ๋ࠨᦵ"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡬ࡱࡩࡨࠧᦶ"),91)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦷ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᦸ")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไฤๅฮี๋ࠥิศ้าอࠬᦹ"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࡶࡪࡧࡺࠫᦺ"),91)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᦻ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᦼ")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่๊ัศหࠩᦽ"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡴ࡮ࡴࠧᦾ"),91)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦿ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᧀ")+l1111l_l1_+l11l1l_l1_ (u"࠭ฬะ์าࠤฬ๊รโๆส้ࠬᧁ"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡯ࡧࡺࡑࡴࡼࡩࡦࡵࠪᧂ"),91)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᧃ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᧄ")+l1111l_l1_+l11l1l_l1_ (u"ࠪะิ๐ฯࠡษ็ั้่วหࠩᧅ"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡳ࡫ࡷࡆࡲ࡬ࡷࡴࡪࡥࡴࠩᧆ"),91)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᧇ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᧈ"),l11l1l_l1_ (u"ࠧࠨᧉ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧊"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ᧋")+l1111l_l1_+l11l1l_l1_ (u"ࠪะิ๐ฯࠡษ็้ํู่ࠨ᧌"),l11l11_l1_,91)
	html = OPENURL_CACHED(l1llll11_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ᧍"),headers,l11l1l_l1_ (u"ࠬ࠭᧎"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡊࡆࡔࡓ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ᧏"))
	#upper menu
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࡮ࡢࡸࠪ᧐"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᧑"),block,re.DOTALL)
	l1l111_l1_ = [l11l1l_l1_ (u"ࠩสๅ้อๅࠡๆ็็ออัࠡใๅ฻ࠬ᧒")]
	for l1llll1_l1_,title in items:
		title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ᧓"))
		if not any(value in title for value in l1l111_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᧔"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᧕")+l1111l_l1_+title,l1llll1_l1_,91)
	return html
def ITEMS(url):
	if l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࠫ᧖") in url:
		url,search = url.split(l11l1l_l1_ (u"ࠧࡀࡶࡀࠫ᧗"))
		headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᧘") : l11l1l_l1_ (u"ࠩࠪ᧙") , l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ᧚") : l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ᧛") }
		data = { l11l1l_l1_ (u"ࠬࡺࠧ᧜") : search }
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ᧝"),url,data,headers,l11l1l_l1_ (u"ࠧࠨ᧞"),l11l1l_l1_ (u"ࠨࠩ᧟"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ᧠"))
		html = response.content
	else:
		headers = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᧡") : l11l1l_l1_ (u"ࠫࠬ᧢") }
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭᧣"),headers,l11l1l_l1_ (u"࠭ࠧ᧤"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡌࡘࡊࡓࡓ࠮࠴ࡱࡨࠬ᧥"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡳ࡯ࡷ࡫ࡨࡷ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࡬࡯ࡰࡶࠥࠫ᧦"),html,re.DOTALL)
	if l1l11l1_l1_: block = l1l11l1_l1_[0]
	else: block = l11l1l_l1_ (u"ࠩࠪ᧧")
	items = re.findall(l11l1l_l1_ (u"ࠪࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡯ࡲࡺ࡮࡫࠭ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ᧨"),block,re.DOTALL)
	l11l_l1_ = []
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠫฬ๊อๅไฬࠫ᧩") in title and l11l1l_l1_ (u"ࠬ࠵ࡣ࠰ࠩ᧪") not in url and l11l1l_l1_ (u"࠭࠯ࡤࡣࡷ࠳ࠬ᧫") not in url:
			l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮ࡛ࠦ࠱࠯࠼ࡡ࠰࠭᧬"),title,re.DOTALL)
			if l1ll11l_l1_:
				title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ᧭")+l1ll11l_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᧮"),l1111l_l1_+title,l1llll1_l1_,95,l1ll1l_l1_)
					l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠲ࠫ᧯") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᧰"),l1111l_l1_+title,l1llll1_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᧱"),l1111l_l1_+title,l1llll1_l1_,91,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ᧲"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ᧳"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠨษ็ูๆำษࠡࠩ᧴"),l11l1l_l1_ (u"ࠩࠪ᧵"))
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᧶"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ᧷")+title,l1llll1_l1_,91)
	return
def l1lll1l1_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭᧸"),headers,l11l1l_l1_ (u"࠭ࠧ᧹"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨ᧺"))
	l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᧻"),html,re.DOTALL)
	l1ll1l_l1_ = l1ll1l_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ᧼"),html,re.DOTALL)
	if l1l11l1_l1_:
		name = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᧽"),html,re.DOTALL)
		if name: name = name[1]
		else:
			name = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬ᧾"))
			if l11l1l_l1_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᧿") in name: name = name.split(l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᨀ"),1)[1]
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡰࡤࡱࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᨁ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᨂ"),l1111l_l1_+name+l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭ᨃ")+title,l1llll1_l1_,92,l1ll1l_l1_)
	else:
		tmp = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡱࡴࡼࡩࡦࡶ࡬ࡸࡱ࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᨄ"),html,re.DOTALL)
		if tmp: l1llll1_l1_,title = tmp[0]
		else: l1llll1_l1_,title = url,name
		addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᨅ"),l1111l_l1_+title,l1llll1_l1_,92,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1ll1l11ll_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭ᨆ"),headers,l11l1l_l1_ (u"࠭ࠧᨇ"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫᨈ"))
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡶࡨࡼࡹ࠳ࡳࡩࡣࡧࡳࡼࡀࠠ࡯ࡱࡱࡩࡀࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᨉ"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨ࡬ࡪࡰ࡮ࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᨊ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᨋ"),block,re.DOTALL)
		for l1llll1_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩᨌ")
			l1lll1_l1_.append(l1llll1_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡴࡡࡷ࠯ࡷࡥࡧࡹࠢࠩ࠰࠭ࡃ࠮ࡼࡩࡥࡧࡲ࠱ࡵࡧ࡮ࡦ࡮࠰ࡱࡴࡸࡥࠨᨍ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		# l11l11lll_l1_ l1l1_l1_
		items = re.findall(l11l1l_l1_ (u"࠭ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡫࡭ࡣࡧࡧࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᨎ"),block,re.DOTALL)
		for id,l1llll1_l1_ in items:
			title = l11l1l_l1_ (u"ࠧิ์ิๅึࠦࠧᨏ")+id
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᨐ")+title+l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᨑ")
			l1lll1_l1_.append(l1llll1_l1_)
		# other l1l1_l1_
		items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᨒ"),block,re.DOTALL)
		for l1llll1_l1_ in items:
			if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᨓ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᨔ")+l1llll1_l1_
			l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
			l1lll1_l1_.append(l1llll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬᨕ"),url)
	return
def l1llll111_l1_():
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠧࠨᨖ"),headers,l11l1l_l1_ (u"ࠨࠩᨗ"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨᨘ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࡪࡰࡧࡩࡽ࠳࡬ࡢࡵࡷ࠱ࡲࡵࡶࡪࡧࠫ࠲࠯ࡅࠩࡪࡦࡀࠦ࡮ࡴࡤࡦࡺ࠰ࡷࡱ࡯ࡤࡦࡴ࠰ࡱࡴࡼࡩࡦࠩᨙ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᨚ"),block,re.DOTALL)
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠴࠭ᨛ") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ᨜"),l1111l_l1_+title,l1llll1_l1_,92,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᨝"),l1111l_l1_+title,l1llll1_l1_,91,l1ll1l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠨࠩ᨞"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠩࠪ᨟"): return
	search = search.replace(l11l1l_l1_ (u"ࠪࠤࠬᨠ"),l11l1l_l1_ (u"ࠫ࠰࠭ᨡ"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡸࡂ࠭ᨢ")+search
	ITEMS(url)
	return
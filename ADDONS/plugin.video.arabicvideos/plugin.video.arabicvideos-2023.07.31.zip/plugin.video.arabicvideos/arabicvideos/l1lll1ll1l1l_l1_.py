# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊࠪ一")
headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ丁") : l11l1l_l1_ (u"࠭ࠧ丂") }
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡕࡉ࡛ࡤ࠭七")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,text):
	if   mode==210: results = MENU()
	elif mode==211: results = l1lllll_l1_(url)
	elif mode==212: results = PLAY(url)
	elif mode==213: results = l1lll1l1_l1_(url)
	elif mode==214: results = l1l11llll1ll_l1_(url)
	elif mode==215: results = l1l11lllll11_l1_(url)
	elif mode==218: results = l11l11111l1_l1_()
	elif mode==219: results = SEARCH(text)
	else: results = False
	return results
def l11l11111l1_l1_():
	message = l11l1l_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭丄")
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ丅"),l11l1l_l1_ (u"ࠪࠫ丆"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ万"),l11l1l_l1_ (u"ࠬอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠫ丈"),message)
	return
def MENU():
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭三"),l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ上"),l11l1l_l1_ (u"ࠨࠩ下"),219,l11l1l_l1_ (u"ࠩࠪ丌"),l11l1l_l1_ (u"ࠪࠫ不"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ与"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ丏"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠫ丐"),l11l1l_l1_ (u"ࠧࠨ丑"),114,l11l11_l1_)
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡔ࡮ࡴ࠿ࡵࡻࡳࡩࡂࡵ࡮ࡦࠨࡧࡥࡹࡧ࠽ࡱ࡫ࡱࠪࡱ࡯࡭ࡪࡶࡀ࠶࠺࠭丒")
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ专"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ且")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ丕"),url,211)
	html = OPENURL_CACHED(l1llll11_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭世"),headers,l11l1l_l1_ (u"࠭ࠧ丗"),l11l1l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ丘"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡲࡴࡄࡸࡸࡹࡵ࡮ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭丙"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡨࡧࡷࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ业"),block,re.DOTALL)
	for l1llll1_l1_,title in items:#[1:-1]:
		url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࡴࡺࡲࡨࡁࡴࡴࡥࠧࡦࡤࡸࡦࡃࠧ丛")+l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ东"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ丝")+l1111l_l1_+title,url,211)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰ࠰ࡱࡪࡴࡵࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ丞"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ丟"),block,re.DOTALL)
	l1l111_l1_ = [l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠢส๊๊๐ࠧ丠"),l11l1l_l1_ (u"ࠩส่ึฬ๊ิ์ฬࠫ両")]
	#l1111l11l_l1_ = [l11l1l_l1_ (u"ุ้๊ࠪำๅษอࠤࠬ丢"),l11l1l_l1_ (u"ࠫฬ็ไศ็ࠣࠫ丣"),l11l1l_l1_ (u"ࠬฮัศ็ฯࠫ两"),l11l1l_l1_ (u"ู࠭าู๊ࠫ严"),l11l1l_l1_ (u"ࠧไๆํฬฬะࠧ並"),l11l1l_l1_ (u"ࠨษ฽ห๋๏ࠧ丧")]
	for l1llll1_l1_,title in items:
		title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ丨"))
		if not any(value in title for value in l1l111_l1_):
		#	if any(value in title for value in l1111l11l_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ丩"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭个")+l1111l_l1_+title,l1llll1_l1_,211)
	return html
def l1lllll_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭丫"),headers,l11l1l_l1_ (u"࠭ࠧ丬"),l11l1l_l1_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ中"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ丮"),l11l1l_l1_ (u"ࠩࠪ丯"),url,html)
	if l11l1l_l1_ (u"ࠪ࡫ࡪࡺࡰࡰࡵࡷࡷࠬ丰") in url or l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ丱") in url: block = html
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡓࡥࡥ࡫ࡤࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ串"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		else: return
	items = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ丳"),block,re.DOTALL)
	l11l_l1_ = []
	l111l1l1l_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧ临"),l11l1l_l1_ (u"ࠨใํ่๊࠭丵"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨ丶"),l11l1l_l1_ (u"ࠪ็้๐ศࠨ丷"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪ丸"),l11l1l_l1_ (u"ࠬํฯศใࠪ丹"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭为"),l11l1l_l1_ (u"ฺࠧำูࠫ主"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨ丼"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ丽")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ举") in l1llll1_l1_: continue
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠫ࠴࠭丿"))
		title = unescapeHTML(title)
		title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ乀"))
		if l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭乁") in l1llll1_l1_ or any(value in title for value in l111l1l1l_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭乂"),l1111l_l1_+title,l1llll1_l1_,212,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ乃") in l1llll1_l1_ and l11l1l_l1_ (u"ࠩส่า๊โสࠩ乄") in title:
			l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭久"),title,re.DOTALL)
			if l1ll11l_l1_:
				title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ乆") + l1ll11l_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乇"),l1111l_l1_+title,l1llll1_l1_,213,l1ll1l_l1_)
					l11l_l1_.append(title)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭么"),l1111l_l1_+title,l1llll1_l1_,213,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ义"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ乊"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠩสฺ่็อสࠢࠪ之"),l11l1l_l1_ (u"ࠪࠫ乌"))
			if title!=l11l1l_l1_ (u"ࠫࠬ乍"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乎"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ乏")+title,l1llll1_l1_,211)
	return
def l1lll1l1_l1_(url):
	l111ll111_l1_,items,l1111l11_l1_ = -1,[],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠧࠨ乐"),headers,l11l1l_l1_ (u"ࠨࠩ乑"),l11l1l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ乒"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ乓"),html,re.DOTALL)
	if l1l11l1_l1_:
		l111111_l1_ = l11l1l_l1_ (u"ࠫࠬ乔").join(l1l11l1_l1_)
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ乕"),l111111_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ乖"))
	for l1llll1_l1_ in items:
		l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ乗"))
		title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ乘") + l1llll1_l1_.split(l11l1l_l1_ (u"ࠩ࠲ࠫ乙"))[-1].replace(l11l1l_l1_ (u"ࠪ࠱ࠬ乚"),l11l1l_l1_ (u"ࠫࠥ࠭乛"))
		l111l111_l1_ = re.findall(l11l1l_l1_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫ乜"),l1llll1_l1_.split(l11l1l_l1_ (u"࠭࠯ࠨ九"))[-1],re.DOTALL)
		if l111l111_l1_: l111l111_l1_ = l111l111_l1_[0]
		else: l111l111_l1_ = l11l1l_l1_ (u"ࠧ࠱ࠩ乞")
		l1111l11_l1_.append([l1llll1_l1_,title,l111l111_l1_])
	items = sorted(l1111l11_l1_, reverse=False, key=lambda key: int(key[2]))
	l111l1ll1_l1_ = str(items).count(l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ也"))
	l111ll111_l1_ = str(items).count(l11l1l_l1_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ习"))
	if l111l1ll1_l1_>1 and l111ll111_l1_>0 and l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ乡") not in url:
		for l1llll1_l1_,title,l111l111_l1_ in items:
			if l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭乢") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ乣"),l1111l_l1_+title,l1llll1_l1_,213)
	else:
		for l1llll1_l1_,title,l111l111_l1_ in items:
			if l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ乤") not in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭乥"),l1111l_l1_+title,l1llll1_l1_,212)
	return
def PLAY(url):
	l1lll1_l1_ = []
	parts = url.split(l11l1l_l1_ (u"ࠨ࠱ࠪ书"))
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠩࠪ乧"),headers,l11l1l_l1_ (u"ࠪࠫ乨"),l11l1l_l1_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ乩"))
	# l11l11lll_l1_ l1l1_l1_
	if l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭乪") in html:
		l111l1l_l1_ = url.replace(parts[3],l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ乫"))
		l11ll111_l1_ = OPENURL_CACHED(l1llll11_l1_,l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ乬"),headers,l11l1l_l1_ (u"ࠨࠩ乭"),l11l1l_l1_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ乮"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭乯"),l11ll111_l1_,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ买"),block,re.DOTALL)
			if items:
				id = re.findall(l11l1l_l1_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭乱"),l11ll111_l1_,re.DOTALL)
				if id:
					l11ll1l1l1_l1_ = id[0]
					for l1llll1_l1_,title in items:
						l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠩ乲")+l11ll1l1l1_l1_+l11l1l_l1_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ乳")+l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ乴")+title+l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ乵")
						l1lll1_l1_.append(l1llll1_l1_)
			else:
				# https://l1l11lllll1l_l1_.tv/l11l11lll_l1_/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࠤࡿࠪࡶࡻ࡯ࡵ࠽ࠬࠫ乶"),block,re.DOTALL)
				for l1llll1_l1_,dummy in items:
					l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	if l11l1l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ乷") in html:
		l111l1l_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ乸"))
		l11ll111_l1_ = OPENURL_CACHED(l1llll11_l1_,l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ乹"),headers,l11l1l_l1_ (u"ࠧࠨ乺"),l11l1l_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ乻"))
		id = re.findall(l11l1l_l1_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ乼"),l11ll111_l1_,re.DOTALL)
		if id:
			l11ll1l1l1_l1_ = id[0]
			l1l1l1ll1_l1_ = { l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ乽"):l11l1l_l1_ (u"ࠫࠬ乾") , l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ乿"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ亀") }
			l111l1l_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡴ࡫ࡴࠨࡳࡳࡸࡺࡉࡥ࠿ࠪ亁")+l11ll1l1l1_l1_
			l11ll111_l1_ = OPENURL_CACHED(l1llll11_l1_,l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ亂"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠩࠪ亃"),l11l1l_l1_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ亄"))
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁ࡮࠳࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭亅"),l11ll111_l1_,re.DOTALL)
			if l1l11l1_l1_:
				for resolution,block in l1l11l1_l1_:
					items = re.findall(l11l1l_l1_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ了"),block,re.DOTALL)
					for name,l1llll1_l1_ in items:
						l1lll1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ亇")+name+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ予")+l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭争")+resolution)
			else:
				l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿࡬࠻࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ亊"),l11ll111_l1_,re.DOTALL)
				if not l1l11l1_l1_: l1l11l1_l1_ = [l11ll111_l1_]
				for block in l1l11l1_l1_:
					l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࠊࠋࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡩࡷࡼࡥࡳࡵࡗ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࠎࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠋࠋࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩࡠ࠳࠱࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫฬ๊ฯใหࠣࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋࠌࠍ࡮࡬ࠠ࡯ࡣࡰࡩࠦࡃࠧࠨ࠼ࠣࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥࠡ࠭ࠣࠫࠥๆࠠࠨࠌࠌࠍࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦࠧࠨࠌࠌࠍࠎࠏࠉࠣࠤࠥ事")
					name = l11l1l_l1_ (u"ࠫࠬ二")
					items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ亍"),block,re.DOTALL)
					for l1llll1_l1_ in items:
						server = l11l1l_l1_ (u"࠭ࠦࠧࠩ于") + l1llll1_l1_.split(l11l1l_l1_ (u"ࠧ࠰ࠩ亏"))[2].lower() + l11l1l_l1_ (u"ࠨࠨࠩࠫ亐")
						server = server.replace(l11l1l_l1_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ云"),l11l1l_l1_ (u"ࠪࠫ互")).replace(l11l1l_l1_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ亓"),l11l1l_l1_ (u"ࠬ࠭五"))
						server = server.replace(l11l1l_l1_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭井"),l11l1l_l1_ (u"ࠧࠨ亖")).replace(l11l1l_l1_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ亗"),l11l1l_l1_ (u"ࠩࠪ亘"))
						server = server.replace(l11l1l_l1_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ亙"),l11l1l_l1_ (u"ࠫࠬ亚")).replace(l11l1l_l1_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ些"),l11l1l_l1_ (u"࠭ࠧ亜"))
						server = server.replace(l11l1l_l1_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭亝"),l11l1l_l1_ (u"ࠨࠩ亞")).replace(l11l1l_l1_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ亟"),l11l1l_l1_ (u"ࠪࠫ亠"))
						server = server.replace(l11l1l_l1_ (u"ࠫࠫࠬࠧ亡"),l11l1l_l1_ (u"ࠬ࠭亢"))
						l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ亣") + name + server + l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ交")
						l1lll1_l1_.append(l1llll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ亥"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪ亦"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫ产"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭亨"),l11l1l_l1_ (u"ࠬ࠱ࠧ亩"))
	url = l11l11_l1_ + l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ亪")+search
	l1lllll_l1_(url)
	return
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡡࡥࡸࡤࡲࡨ࡫ࡤ࠮ࡵࡨࡥࡷࡩࡨࠡࡵࡨࡧࡴࡴࡤࡢࡴࡼࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡯ࡦࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣ࠰ࡧࡦࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧ࡭࡫ࡣ࡬࡯ࡤࡶࡰ࠳ࡢࡰ࡮ࡧࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࠮ࡩ࡭ࡱࡺࡥࡳࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠊࠊࠋࡩࡳࡷࠦࡣࡢࡶࡨ࡫ࡴࡸࡹ࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡩࡡࡵࡧࡪࡳࡷࡿࠩࠋࠋࠌࠍ࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡶ࡬ࡸࡱ࡫ࠩࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩ࠯ࠤ࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔࠪࠌࠌࠍ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࠣࡁࡂࠦ࠭࠲ࠢ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠎࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣࡧࡦࡺࡥࡨࡱࡵࡽࡑࡏࡓࡕ࡝ࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡢࠐࠉࠊࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪ࠯ࡸ࡫ࡡࡳࡥ࡫࠯ࠬࠬࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ࠮ࡧࡦࡺࡥࡨࡱࡵࡽࠏࠏࠉࡕࡋࡗࡐࡊ࡙ࠨࡶࡴ࡯࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠐࠉࠣࠤࠥ享")
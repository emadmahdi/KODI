# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙ࠪ⎁")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡋࡇࡏࡡࠪ⎂")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ⎃"),l11l1l_l1_ (u"࠭วๅๅ็ࠫ⎄"),l11l1l_l1_ (u"ࠧ࡯࠱ࡄࠫ⎅"),l11l1l_l1_ (u"ࠨษ็้ื๐ฯࠨ⎆"),l11l1l_l1_ (u"ࠩๅูฮูࠦีไࠪ⎇")]
def MAIN(mode,url,text):
	if   mode==430: results = MENU()
	elif mode==431: results = l1lllll_l1_(url,text)
	elif mode==432: results = PLAY(url)
	elif mode==433: results = l1lll1l1_l1_(url)
	elif mode==434: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗࡥ࡟ࡠࠩ⎈")+text)
	elif mode==435: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠫࡘࡖࡅࡄࡋࡉࡍࡊࡊ࡟ࡇࡋࡏࡘࡊࡘ࡟ࡠࡡࠪ⎉")+text)
	elif mode==436: results = l11lll_l1_(url)
	elif mode==437: results = l1lll1l1l1_l1_(url)
	elif mode==439: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⎊"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭⎋"),l11l1l_l1_ (u"ࠧࠨ⎌"),l11l1l_l1_ (u"ࠨࠩ⎍"),l11l1l_l1_ (u"ࠩࠪ⎎"),l11l1l_l1_ (u"ࠪࠫ⎏"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⎐"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⎑"),html,re.DOTALL)
	l1l1ll1_l1_ = l1l1ll1_l1_[0].strip(l11l1l_l1_ (u"࠭࠯ࠨ⎒"))
	l1l1ll1_l1_ = SERVER(l1l1ll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⎓"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⎔"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ⎕"),l11l1l_l1_ (u"ࠪࠫ⎖"),439,l11l1l_l1_ (u"ࠫࠬ⎗"),l11l1l_l1_ (u"ࠬ࠭⎘"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⎙"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎚"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ⎛"),l1l1ll1_l1_,435)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎜"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭⎝"),l1l1ll1_l1_,434)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⎞"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⎟"),l11l1l_l1_ (u"࠭ࠧ⎠"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎡"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎢")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่๊฼วโࠢะำ๏ัวࠨ⎣"),l1l1ll1_l1_,431)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎤"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⎥")+l1111l_l1_+l11l1l_l1_ (u"ࠬอแๅษ่ࠤฬ๎ๆࠡๆส๎๋࠭⎦"),l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠷ࠧ⎧"),436)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⎨"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⎩")+l1111l_l1_+l11l1l_l1_ (u"่ࠩืู้ไศฬࠣหํ์ࠠๅษํ๊ࠬ⎪"),l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠱ࡦࡲ࡬࠲ࠩ⎫"),436)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎬"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⎭")+l1111l_l1_+l11l1l_l1_ (u"࠭โศศ่อࠥะแึ์็๎ฮ࠭⎮"),l1l1ll1_l1_,437)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⎯"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⎰"),l11l1l_l1_ (u"ࠩࠪ⎱"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⎲"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⎳")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆ็ํึฮ࠭⎴"),l1l1ll1_l1_,431,l11l1l_l1_ (u"࠭ࠧ⎵"),l11l1l_l1_ (u"ࠧࠨ⎶"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⎷"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⎸"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⎹")+l1111l_l1_+l11l1l_l1_ (u"ࠫศ็ไศ็ࠪ⎺"),l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡷ࠴࠭⎻"),436)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⎼"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⎽")+l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ⎾"),l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠰࠵࠴࠭⎿"),436)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡘ࡯ࡴࡦࡐࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࠦࡘ࡫ࡡࡳࡥ࡫ࠦࠬ⏀"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⏁"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		#if title==l11l1l_l1_ (u"ࠬอไาศํื๏ฯࠧ⏂"): title = l11l1l_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ⏃")
		if title in l1l111_l1_: continue
		if title==l11l1l_l1_ (u"ࠧศๆิส๏ู๊สࠩ⏄"): continue
		if l11l1l_l1_ (u"ࠨษ๋๊๊ࠥว๋่ࠪ⏅") in title: continue
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏆"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⏇")+l1111l_l1_+title,l1llll1_l1_,431)
	return
def l1lll1l1l1_l1_(l1l11lll_l1_=l11l1l_l1_ (u"ࠫࠬ⏈")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⏉"),l1l11lll_l1_+l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭⏊"),l11l1l_l1_ (u"ࠧࠨ⏋"),l11l1l_l1_ (u"ࠨࠩ⏌"),l11l1l_l1_ (u"ࠩࠪ⏍"),l11l1l_l1_ (u"ࠪࠫ⏎"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭⏏"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡢࡰࡲࡲ࡮ࡩࡡ࡭ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⏐"),html,re.DOTALL)
	l1l1ll1_l1_ = l1l1ll1_l1_[0].strip(l11l1l_l1_ (u"࠭࠯ࠨ⏑"))
	l1l1ll1_l1_ = SERVER(l1l1ll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⏒"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡏ࡭ࡸࡺࡄࡳࡱࡳࡩࡩࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡴࡦ࡬࡮ࡴࡧࡎࡣࡶࡸࡪࡸࠢࠨ⏓"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡣࡻࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡸࡪࡸ࡭࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡧࡥࡹࡧ࠭࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⏔"),block,re.DOTALL)
	for category,value,title in items:
		if title in l1l111_l1_: continue
		l1llll1_l1_ = l1l11lll_l1_+l11l1l_l1_ (u"ࠪ࠳ࡪࡾࡰ࡭ࡱࡵࡩ࠴ࡅࠧ⏕")+category+l11l1l_l1_ (u"ࠫࡂ࠭⏖")+value
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⏗"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⏘")+l1111l_l1_+title,l1llll1_l1_,431)
	return
def	l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ⏙"),l11l1l_l1_ (u"ࠨࠩ⏚"),l11l1l_l1_ (u"ࠩࡖ࡙ࡇࡓࡅࡏࡗࠪ⏛"),url)
	#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ⏜"),l1llll1_l1_)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ⏝"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⏞"),url,l11l1l_l1_ (u"࠭ࠧ⏟"),l11l1l_l1_ (u"ࠧࠨ⏠"),l11l1l_l1_ (u"ࠨࠩ⏡"),l11l1l_l1_ (u"ࠩࠪ⏢"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡎࡐ࡙࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⏣"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⏤"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠬ⏥"),url,431)
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭⏦"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭⏧"),block,re.DOTALL)
	for l1lll111ll_l1_,title in items:
		if title in l1l111_l1_: continue
		l111l1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅࡨࡻࡑࡳࡼࡈࡹࡆ࡮ࡶ࡬ࡦ࡯࡫ࡩ࠱ࡄ࡮ࡦࡾࡴ࠰ࡏࡲࡺ࡮࡫ࡳ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࡂ࡯ࡪࡿ࠽ࠨ⏨")+l1lll111ll_l1_
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⏩"),l1111l_l1_+title,l111l1l_l1_,431)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⏪"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⏫"),l11l1l_l1_ (u"ࠬ࠭⏬"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡊࡰࡱࡩࡷࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠭⏭"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ⏮"),block,re.DOTALL)
	#for category,value,title in items:
	#	if title in l1l111_l1_: continue
	#	if l11l1l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳ࠰ࠩ⏯") in url: l111l1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡐࡳࡻ࡯ࡥࡴ࠱ࡗࡩࡷࡳࡳ࠯ࡲ࡫ࡴࡄ࠭⏰")+category+l11l1l_l1_ (u"ࠪࡁࠬ⏱")+value
	#	elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠲࠭⏲") in url: l111l1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡉ࡬ࡿࡎࡰࡹࡅࡽࡊࡲࡳࡩࡣ࡬࡯࡭࠵ࡁ࡫ࡣࡻࡸ࠴࡙ࡥࡳ࡫ࡨࡷ࠴ࡍࡥࡵ࠰ࡳ࡬ࡵࡅࠧ⏳")+category+l11l1l_l1_ (u"࠭࠽ࠨ⏴")+value
	#	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⏵"),l1111l_l1_+title,l111l1l_l1_,431)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠨࠩ⏶")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ⏷"),l11l1l_l1_ (u"ࠪࠫ⏸"),request,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ⏹"))
	items = []
	if l11l1l_l1_ (u"ࠬ࠵ࡔࡦࡴࡰࡷ࠳ࡶࡨࡱࠩ⏺") in url or l11l1l_l1_ (u"࠭࠯ࡈࡧࡷ࠲ࡵ࡮ࡰࠨ⏻") in url or l11l1l_l1_ (u"ࠧ࠰ࡍࡨࡽࡸ࠴ࡰࡩࡲࠪ⏼") in url:
		l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ⏽"):l11l1l_l1_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ⏾"),l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⏿"):l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ␀")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ␁"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"࠭ࠧ␂"),l11l1l_l1_ (u"ࠧࠨ␃"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ␄"))
		html = response.content
		block = html
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ␅"):
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ␆"),url,l11l1l_l1_ (u"ࠫࠬ␇"),l11l1l_l1_ (u"ࠬ࠭␈"),l11l1l_l1_ (u"࠭ࠧ␉"),l11l1l_l1_ (u"ࠧࠨ␊"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡓࡕࡗ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ␋"))
		html = response.content
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࠨࡍࡢࡶࡦ࡬ࡪࡹࡔࡢࡤ࡯ࡩࠧ࠭␌"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭␍"),block,re.DOTALL)
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ␎"),url,l11l1l_l1_ (u"ࠬ࠭␏"),l11l1l_l1_ (u"࠭ࠧ␐"),l11l1l_l1_ (u"ࠧࠨ␑"),l11l1l_l1_ (u"ࠨࠩ␒"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭␓"))
		html = response.content
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠪ␔"),html,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡈ࡬ࡰࡥ࡮ࡷࡑ࡯ࡳࡵࠤࠫ࠲࠯ࡅࠩࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࡃࡰࡰࠥࠫ␕"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ␖"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"࠭ๅีษ๊ำฮ࠭␗"),l11l1l_l1_ (u"ࠧโ์็้ࠬ␘"),l11l1l_l1_ (u"ࠨษ฽๊๏ฯࠧ␙"),l11l1l_l1_ (u"ࠩๆ่๏ฮࠧ␚"),l11l1l_l1_ (u"ࠪห฾๊ว็ࠩ␛"),l11l1l_l1_ (u"ࠫ์ีวโࠩ␜"),l11l1l_l1_ (u"๋ࠬศศำสอࠬ␝"),l11l1l_l1_ (u"ู࠭าุࠪ␞"),l11l1l_l1_ (u"ࠧๆ้ิะฬ์ࠧ␟"),l11l1l_l1_ (u"ࠨษ็ฬํ๋ࠧ␠")]
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ␡"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ␢"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣห้ำไใหࠣࡠࡩ࠱ࠧ␣"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ␤"),l1111l_l1_+title,l1llll1_l1_,432,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"࠭วๅฯ็ๆฮ࠭␥") in title:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭␦") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ␧"),l1111l_l1_+title,l1llll1_l1_,433,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ␨") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␩"),l1111l_l1_+title,l1llll1_l1_,431,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ␪"),l1111l_l1_+title,l1llll1_l1_,433,l1ll1l_l1_)
	if request!=l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ␫"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡑࡣࡪ࡭ࡳࡧࡴࡦࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭␬"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭␭"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭␮") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l1llll1_l1_
				l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
				title = unescapeHTML(title)
				if title!=l11l1l_l1_ (u"ࠩࠪ␯"): addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ␰"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ␱")+title,l1llll1_l1_,431)
		l1lll1llll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡨࡰࡹࡰࡳࡷ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ␲"),html,re.DOTALL)
		if l1lll1llll_l1_:
			l1llll1_l1_ = l1lll1llll_l1_[0]
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭␳"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆึส๋ิฯࠠศๆ่ึ๏ีࠧ␴"),l1llll1_l1_,431)
	return
def l1lll1l1_l1_(url):
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ␵"),l11l1l_l1_ (u"ࠩ࠴࠵࠶࠷ࠠࠡࠩ␶")+url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ␷"))
	l1l1111_l1_,l11llll_l1_ = [],[]
	if l11l1l_l1_ (u"ࠫࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰࡩࡲࠪ␸") in url:
		l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ␹"):l11l1l_l1_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ␺"),l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭␻"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ␼")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ␽"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠪࠫ␾"),l11l1l_l1_ (u"ࠫࠬ␿"),l11l1l_l1_ (u"ࠬࡋࡇ࡚ࡐࡒ࡛࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⑀"))
		html = response.content
		l11llll_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ⑁"),url,l11l1l_l1_ (u"ࠧࠨ⑂"),l11l1l_l1_ (u"ࠨࠩ⑃"),l11l1l_l1_ (u"ࠩࠪ⑄"),l11l1l_l1_ (u"ࠪࠫ⑅"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡏࡑ࡚࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ⑆"))
		html = response.content
		l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡓࡦࡣࡶࡳࡳࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⑇"),html,re.DOTALL)
		l11llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡆࡲ࡬ࡷࡴࡪࡥࡴࡎ࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ⑈"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l1111_l1_:
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡱࡪ࠾࡮ࡳࡡࡨࡧࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⑉"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡧࡳࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⑊"),block,re.DOTALL)
		for l1lll11_l1_,l1lll1l1111_l1_,title in items:
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡆࡩࡼࡒࡴࡽࡂࡺࡇ࡯ࡷ࡭ࡧࡩ࡬ࡪ࠲ࡅ࡯ࡧࡸࡵ࠱ࡖ࡭ࡳ࡭࡬ࡦ࠱ࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠲ࡵ࡮ࡰࡀࠩ⑋")+l11l1l_l1_ (u"ࠪࡷࡪࡧࡳࡰࡰࡀࠫ⑌")+l1lll1l1111_l1_+l11l1l_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ⑍")+l1lll11_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⑎"),l1111l_l1_+title,l1llll1_l1_,433,l1ll1l_l1_)
	# l11ll_l1_
	elif l11llll_l1_:
		l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠧ⑏"))
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀࡪࡳ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡦ࡯ࡁࠫ⑐"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll11l_l1_ in items:
			title = title+l11l1l_l1_ (u"ࠨࠢࠪ⑑")+l1ll11l_l1_
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⑒"),l1111l_l1_+title,l1llll1_l1_,432,l1ll1l_l1_)
	return
def PLAY(url):
	l111l1l_l1_ = url+l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ⑓")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ⑔"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭⑕"),l11l1l_l1_ (u"࠭ࠧ⑖"),l11l1l_l1_ (u"ࠧࠨ⑗"),l11l1l_l1_ (u"ࠨࠩ⑘"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⑙"))
	html = response.content
	l1lll1_l1_ = []
	l1l1ll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ⑚"))
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠮ࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⑛"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1ll1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⑜"),block,re.DOTALL)
		if l1ll1l1lll_l1_:
			l1ll1l1lll_l1_ = l1ll1l1lll_l1_[0]
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ⑝"),l11l1l_l1_ (u"ࠧࠨ⑞"),l11l1l_l1_ (u"ࠨࠩ⑟"),l1ll1l1lll_l1_)
			items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡧࡵࡺࡪࡸ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ①"),block,re.DOTALL)
			for server,title in items:
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡇࡪࡽࡓࡵࡷࡃࡻࡈࡰࡸ࡮ࡡࡪ࡭࡫࠳ࡆࡰࡡࡹࡶ࠲ࡗ࡮ࡴࡧ࡭ࡧ࠲ࡗࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶ࠿ࡴࡧࡵࡺࡪࡸ࠽ࠨ②")+server+l11l1l_l1_ (u"ࠫࠫࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ③")+l1ll1l1lll_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭④")+title+l11l1l_l1_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ⑤")
				l1lll1_l1_.append(l1llll1_l1_)
	# l1l1111l1_l1_ l1llll1_l1_
	l1l1111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡥࡲࡲࡹࡧࡩ࡯ࡧࡵ࠱࡮࡬ࡲࡢ࡯ࡨࠦࡃࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⑥"),html,re.DOTALL)
	if l1l1111l1_l1_:
		l1l1111l1_l1_ = l1l1111l1_l1_[0].replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ⑦"),l11l1l_l1_ (u"ࠩࠪ⑧"))
		title = SERVER(l1l1111l1_l1_,l11l1l_l1_ (u"ࠪࡲࡦࡳࡥࠨ⑨"))
		l1llll1_l1_ = l1l1111l1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ⑩")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡦ࡯ࡥࡩࡩ࠭⑪")
		l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ⑫"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⑬"),block,re.DOTALL)
		for l1llll1_l1_,title,l111ll11_l1_ in items:
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫ⑭"),l11l1l_l1_ (u"ࠩࠪ⑮"))
			if l111ll11_l1_!=l11l1l_l1_ (u"ࠪࠫ⑯"): l111ll11_l1_ = l11l1l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩ⑰")+l111ll11_l1_
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭⑱")+title+l11l1l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⑲")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠧฤะอีࠥอไษฯฮࠤฬ๊ๅ็ษึฬࠬ⑳"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⑴"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪ⑵"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫ⑶"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭⑷"),l11l1l_l1_ (u"ࠬࠫ࠲࠱ࠩ⑸"))
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡀࡵࡀࠫ⑹")+search
	l1lllll_l1_(url)
	return
# ===========================================
#     l1lll1l111_l1_ l1lll11lll_l1_ l1lll1l11l_l1_
# ===========================================
def l1llll1l1l_l1_(url):
	url = url.split(l11l1l_l1_ (u"ࠧ࠰ࡵࡰࡥࡷࡺࡥ࡮ࡣࡧࡪ࡮ࡲࡴࡦࡴࡂࠫ⑺"))[0]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ⑻"))
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭⑼"),l1l1ll1_l1_,l11l1l_l1_ (u"ࠪࠫ⑽"),l11l1l_l1_ (u"ࠫࠬ⑾"),l11l1l_l1_ (u"ࠬ࠭⑿"),l11l1l_l1_ (u"࠭ࠧ⒀"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡒࡔ࡝࠭ࡈࡇࡗࡣࡋࡏࡌࡕࡇࡕࡗࡤࡈࡌࡐࡅࡎࡗ࠲࠷ࡳࡵࠩ⒁"))
	html = response.content
	# all l111111_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀࠫࠥࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࡓࡡࡴࡶࡨࡶࠧ࠭⒂"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	# name + options block + category
	l1ll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡨࡷࡵࡰࡥࡱࡺࡲ࠲ࡨࡵࡵࡶࡲࡲࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠬࠫ⒃"),block,re.DOTALL)
	return l1ll1l11_l1_
def l1lll1ll11_l1_(block):
	# value + name
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠠࡥࡣࡷࡥ࠲ࡴࡡ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⒄"),block,re.DOTALL)
	return items
def l1lll1ll1l_l1_(url):
	#url = url.replace(l11l1l_l1_ (u"ࠫࡨࡧࡴ࠾ࠩ⒅"),l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ⒆"))
	l1llll11ll_l1_ = url.split(l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⒇"))[0]
	l1lll1lll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ⒈"))
	url = url.replace(l1llll11ll_l1_,l1lll1lll1_l1_)
	url = url.replace(l11l1l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⒉"),l11l1l_l1_ (u"ࠩ࠲ࡩࡽࡶ࡬ࡰࡴࡨ࠳ࡄ࠭⒊"))
	return url
def l1lll1l111l_l1_(l1l1l1l1_l1_,url):
	l11lll11_l1_ = l11lll1l_l1_(l1l1l1l1_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭⒋")) # l1lllll111l_l1_ be l1lllll1l1l_l1_
	l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴ࡹ࡭ࡢࡴࡷࡩࡲࡧࡤࡧ࡫࡯ࡸࡪࡸ࠿ࠨ⒌")+l11lll11_l1_
	l111ll1_l1_ = l1lll1ll1l_l1_(l111ll1_l1_)
	return l111ll1_l1_
l1l111l1_l1_ = [l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⒍"),l11l1l_l1_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ⒎"),l11l1l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭⒏"),l11l1l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ⒐")]
l1l1lll1_l1_ = [l11l1l_l1_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ⒑"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ⒒"),l11l1l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ⒓"),l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ⒔"),l11l1l_l1_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨ⒕"),l11l1l_l1_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ⒖")]
def l1ll1l1l_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⒗"),l11l1l_l1_ (u"ࠩࠪ⒘"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ⒙"),l11l1l_l1_ (u"ࠫࠬ⒚"),filter,url)
	if l11l1l_l1_ (u"ࠬࡅࠧ⒛") in url: url = url.split(l11l1l_l1_ (u"࠭࠯ࡴ࡯ࡤࡶࡹ࡫࡭ࡢࡦࡩ࡭ࡱࡺࡥࡳࡁࠪ⒜"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ⒝"),1)
	if filter==l11l1l_l1_ (u"ࠨࠩ⒞"): l1l11111_l1_,l11lllll_l1_ = l11l1l_l1_ (u"ࠩࠪ⒟"),l11l1l_l1_ (u"ࠪࠫ⒠")
	else: l1l11111_l1_,l11lllll_l1_ = filter.split(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ⒡"))
	if type==l11l1l_l1_ (u"࡙ࠬࡐࡆࡅࡌࡊࡎࡋࡄࡠࡈࡌࡐ࡙ࡋࡒࠨ⒢"):
		if l1l111l1_l1_[0]+l11l1l_l1_ (u"࠭࠽ࠨ⒣") not in l1l11111_l1_: category = l1l111l1_l1_[0]
		for i in range(len(l1l111l1_l1_[0:-1])):
			if l1l111l1_l1_[i]+l11l1l_l1_ (u"ࠧ࠾ࠩ⒤") in l1l11111_l1_: category = l1l111l1_l1_[i+1]
		l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪ⒥")+category+l11l1l_l1_ (u"ࠩࡀ࠴ࠬ⒦")
		l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠪࠪࠬ⒧")+category+l11l1l_l1_ (u"ࠫࡂ࠶ࠧ⒨")
		l1l11l11_l1_ = l1l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠬࠬࠧ⒩"))+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ⒪")+l1l1l1l1_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠩ⒫"))
		l11lll11_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⒬")) # l1lllll1111_l1_ l11111l11l_l1_ not l111lll1l1_l1_
		l111l1l_l1_ = url+l11l1l_l1_ (u"ࠩ࠲ࡷࡲࡧࡲࡵࡧࡰࡥࡩ࡬ࡩ࡭ࡶࡨࡶࡄ࠭⒭")+l11lll11_l1_
	elif type==l11l1l_l1_ (u"ࠪࡅࡑࡒ࡟ࡊࡖࡈࡑࡘࡥࡆࡊࡎࡗࡉࡗ࠭⒮"):
		l11l1lll_l1_ = l11lll1l_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⒯")) # l1lllll1111_l1_ l11111l11l_l1_ not l111lll1l1_l1_
		l11l1lll_l1_ = l1llll_l1_(l11l1lll_l1_)
		if l11lllll_l1_!=l11l1l_l1_ (u"ࠬ࠭⒰"): l11lllll_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⒱")) # l1lllll1111_l1_ l11111l11l_l1_ not l111lll1l1_l1_
		if l11lllll_l1_==l11l1l_l1_ (u"ࠧࠨ⒲"): l111l1l_l1_ = url
		else: l111l1l_l1_ = url+l11l1l_l1_ (u"ࠨ࠱ࡶࡱࡦࡸࡴࡦ࡯ࡤࡨ࡫࡯࡬ࡵࡧࡵࡃࠬ⒳")+l11lllll_l1_
		l111l1l_l1_ = l1lll1ll1l_l1_(l111l1l_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⒴"),l1111l_l1_+l11l1l_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭⒵"),l111l1l_l1_,431)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⒶ"),l1111l_l1_+l11l1l_l1_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬⒷ")+l11l1lll_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠢࡠࡡࠬⒸ"),l111l1l_l1_,431)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⒹ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨⒺ"),l11l1l_l1_ (u"ࠩࠪⒻ"),9999)
	l1ll1l11_l1_ = l1llll1l1l_l1_(url)
	dict = {}
	for name,block,l1ll11l1_l1_ in l1ll1l11_l1_:
		name = name.replace(l11l1l_l1_ (u"ࠪ࠱࠲࠭Ⓖ"),l11l1l_l1_ (u"ࠫࠬⒽ"))
		items = l1lll1ll11_l1_(block)
		if l11l1l_l1_ (u"ࠬࡃࠧⒾ") not in l111l1l_l1_: l111l1l_l1_ = url
		if type==l11l1l_l1_ (u"࠭ࡓࡑࡇࡆࡍࡋࡏࡅࡅࡡࡉࡍࡑ࡚ࡅࡓࠩⒿ"):
			if category!=l1ll11l1_l1_: continue
			elif len(items)<2:
				if l1ll11l1_l1_==l1l111l1_l1_[-1]:
					url = l1lll1ll1l_l1_(url)
					l1lllll_l1_(url)
				else: l1ll1l1l_l1_(l111l1l_l1_,l11l1l_l1_ (u"ࠧࡔࡒࡈࡇࡎࡌࡉࡆࡆࡢࡊࡎࡒࡔࡆࡔࡢࡣࡤ࠭Ⓚ")+l1l11l11_l1_)
				return
			else:
				l111l1l_l1_ = l1lll1ll1l_l1_(l111l1l_l1_)
				if l1ll11l1_l1_==l1l111l1_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⓁ"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠢࠪⓂ"),l111l1l_l1_,431)
				else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⓃ"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤࠬⓄ"),l111l1l_l1_,435,l11l1l_l1_ (u"ࠬ࠭Ⓟ"),l11l1l_l1_ (u"࠭ࠧⓆ"),l1l11l11_l1_)
		elif type==l11l1l_l1_ (u"ࠧࡂࡎࡏࡣࡎ࡚ࡅࡎࡕࡢࡊࡎࡒࡔࡆࡔࠪⓇ"):
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠪⓈ")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠩࡀ࠴ࠬⓉ")
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠪࠪࠬⓊ")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠫࡂ࠶ࠧⓋ")
			l1l11l11_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡠࠩⓌ")+l1l1l1l1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⓧ"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠠ࠻ࠩⓎ")+name,l111l1l_l1_,434,l11l1l_l1_ (u"ࠨࠩⓏ"),l11l1l_l1_ (u"ࠩࠪⓐ"),l1l11l11_l1_)		# +l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬⓑ"))
		dict[l1ll11l1_l1_] = {}
		for value,option in items:
			if value==l11l1l_l1_ (u"ࠫ࠶࠿࠶࠶࠵࠶ࠫⓒ"): option = l11l1l_l1_ (u"ࠬษแๅษ่ࠤ๋๐สโๆๆืࠬⓓ")
			elif value==l11l1l_l1_ (u"࠭࠱࠺࠸࠸࠷࠶࠭ⓔ"): option = l11l1l_l1_ (u"ࠧๆี็ื้อส่ࠡํฮๆ๊ใิࠩⓕ")
			if option in l1l111_l1_: continue
			#if l11l1l_l1_ (u"ࠨࡸࡤࡰࡺ࡫ࠧⓖ") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪⓗ"),value,re.DOTALL)[0]
			dict[l1ll11l1_l1_][value] = option
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠪࠪࠬⓘ")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠫࡂ࠭ⓙ")+option
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠬࠬࠧⓚ")+l1ll11l1_l1_+l11l1l_l1_ (u"࠭࠽ࠨⓛ")+value
			l1ll111l_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠧࡠࡡࡢࠫⓜ")+l1l1l1l1_l1_
			title = option+l11l1l_l1_ (u"ࠨࠢ࠽ࠫⓝ")#+dict[l1ll11l1_l1_][l11l1l_l1_ (u"ࠩ࠳ࠫⓞ")]
			title = option+l11l1l_l1_ (u"ࠪࠤ࠿࠭ⓟ")+name
			if type==l11l1l_l1_ (u"ࠫࡆࡒࡌࡠࡋࡗࡉࡒ࡙࡟ࡇࡋࡏࡘࡊࡘࠧⓠ"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⓡ"),l1111l_l1_+title,url,434,l11l1l_l1_ (u"࠭ࠧⓢ"),l11l1l_l1_ (u"ࠧࠨⓣ"),l1ll111l_l1_)		# +l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪⓤ"))
			elif type==l11l1l_l1_ (u"ࠩࡖࡔࡊࡉࡉࡇࡋࡈࡈࡤࡌࡉࡍࡖࡈࡖࠬⓥ") and l1l111l1_l1_[-2]+l11l1l_l1_ (u"ࠪࡁࠬⓦ") in l1l11111_l1_:
				l111ll1_l1_ = l1lll1l111l_l1_(l1l1l1l1_l1_,url)
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⓧ"),l1111l_l1_+title,l111ll1_l1_,431)
			else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⓨ"),l1111l_l1_+title,url,435,l11l1l_l1_ (u"࠭ࠧⓩ"),l11l1l_l1_ (u"ࠧࠨ⓪"),l1ll111l_l1_)
	return
def l11lll1l_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ⓫"),l11l1l_l1_ (u"ࠩࠪ⓬"),filters,l11l1l_l1_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫ⓭"))
	# mode==l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭⓮")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ values
	# mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⓯")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ filters
	# mode==l11l1l_l1_ (u"࠭ࡡ࡭࡮ࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ⓰")			all l1l1l111_l1_ & l1llll111l_l1_ filters
	filters = filters.replace(l11l1l_l1_ (u"ࠧ࠾ࠨࠪ⓱"),l11l1l_l1_ (u"ࠨ࠿࠳ࠪࠬ⓲"))
	filters = filters.strip(l11l1l_l1_ (u"ࠩࠩࠫ⓳"))
	l1l1111l_l1_ = {}
	if l11l1l_l1_ (u"ࠪࡁࠬ⓴") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠫࠫ࠭⓵"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠬࡃࠧ⓶"))
			l1l1111l_l1_[var] = value
	l1ll1111_l1_ = l11l1l_l1_ (u"࠭ࠧ⓷")
	for key in l1l1lll1_l1_:
		if key in list(l1l1111l_l1_.keys()): value = l1l1111l_l1_[key]
		else: value = l11l1l_l1_ (u"ࠧ࠱ࠩ⓸")
		if l11l1l_l1_ (u"ࠨࠧࠪ⓹") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ⓺") and value!=l11l1l_l1_ (u"ࠪ࠴ࠬ⓻"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠫࠥ࠱ࠠࠨ⓼")+value
		elif mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ⓽") and value!=l11l1l_l1_ (u"࠭࠰ࠨ⓾"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠧࠧࠩ⓿")+key+l11l1l_l1_ (u"ࠨ࠿ࠪ─")+value
		elif mode==l11l1l_l1_ (u"ࠩࡤࡰࡱࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ━"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠪࠪࠬ│")+key+l11l1l_l1_ (u"ࠫࡂ࠭┃")+value
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠫࠡࠩ┄"))
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"࠭ࠦࠨ┅"))
	l1ll1111_l1_ = l1ll1111_l1_.replace(l11l1l_l1_ (u"ࠧ࠾࠲ࠪ┆"),l11l1l_l1_ (u"ࠨ࠿ࠪ┇"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ┈"),l11l1l_l1_ (u"ࠪࠫ┉"),filters,l11l1l_l1_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠵࠶ࠬ┊"))
	return l1ll1111_l1_
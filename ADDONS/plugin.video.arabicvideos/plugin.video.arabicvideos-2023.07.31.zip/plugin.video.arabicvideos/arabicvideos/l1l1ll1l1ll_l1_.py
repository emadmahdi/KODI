# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎࠩ⺾")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡏࡆࡍࡡࠪ⺿")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l11lll11ll_l1_ = l1l1l1l_l1_[l1ll1_l1_][1]
l1l1l1lllll_l1_ = l1l1l1l_l1_[l1ll1_l1_][2]
l1l1ll1111l_l1_ = l1l1l1l_l1_[l1ll1_l1_][3]
#l1l1ll11lll_l1_  = l1l1l1l_l1_[l1ll1_l1_][4]
#l1l1ll11lll_l1_  = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,l11lll1_l1_,text):
	if   mode==20: results = l1l1ll111l1_l1_()
	elif mode==21: results = MENU(url)
	elif mode==22: results = l1lllll_l1_(url,l11lll1_l1_)
	elif mode==23: results = l1lll1l1_l1_(url,l11lll1_l1_)
	elif mode==24: results = PLAY(url,text)
	elif mode==25: results = l1l1l1l1ll1_l1_(url)
	elif mode==27: results = l1l1ll111_l1_(url)
	elif mode==28: results = l1l1ll11l1l_l1_()
	elif mode==29: results = SEARCH(text)
	else: results = False
	return results
def l1l1ll111l1_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻀"),l1111l_l1_+l11l1l_l1_ (u"ู࠭าสํࠫ⻁"),l11l11_l1_,21,l11l1l_l1_ (u"ࠧࠨ⻂"),l11l1l_l1_ (u"ࠨ࠳࠳࠵ࠬ⻃"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⻄"),l1111l_l1_+l11l1l_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⻅"),l11lll11ll_l1_,21,l11l1l_l1_ (u"ࠫࠬ⻆"),l11l1l_l1_ (u"ࠬ࠷࠰࠲ࠩ⻇"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻈"),l1111l_l1_+l11l1l_l1_ (u"ࠧโษิื๎࠭⻉"),l1l1l1lllll_l1_,21,l11l1l_l1_ (u"ࠨࠩ⻊"),l11l1l_l1_ (u"ࠩ࠴࠴࠶࠭⻋"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⻌"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆอัิ๋ࠣ࠶ࠬ⻍"),l1l1ll1111l_l1_,21,l11l1l_l1_ (u"ࠬ࠭⻎"),l11l1l_l1_ (u"࠭࠱࠱࠳ࠪ⻏"))
	return
def l1l1ll11l1l_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ⻐"),l1111l_l1_+l11l1l_l1_ (u"ࠨ฻ิฬ๏࠭⻑"),l11l11_l1_,27)
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⻒"),l1111l_l1_+l11l1l_l1_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫ⻓"),l11lll11ll_l1_,27)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ⻔"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็วาี์ࠫ⻕"),l1l1l1lllll_l1_,27)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫ⻖"),l1111l_l1_+l11l1l_l1_ (u"ࠧโษิื๎ࠦ࠲ࠨ⻗"),l1l1ll1111l_l1_,27)
	return
def MENU(l1l1ll11ll1_l1_):
	l1ll1_l1_ = l1l1ll11ll1_l1_
	if l1l1ll11ll1_l1_==l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧ⻘"): l1l1ll11ll1_l1_ = l11l11_l1_
	elif l1l1ll11ll1_l1_==l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩ⻙"): l1l1ll11ll1_l1_ = l11lll11ll_l1_
	else: l1ll1_l1_ = l11l1l_l1_ (u"ࠪࠫ⻚")
	l1ll1l111l1_l1_ = l1l1ll1l111_l1_(l1l1ll11ll1_l1_)
	if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠫࡦࡸࠧ⻛") or l1ll1_l1_==l11l1l_l1_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡆࡘࡁࡃࡋࡆࠫ⻜"):
		l1l1l1ll111_l1_ = l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⻝")
		l1l1l1l1lll_l1_ = l11l1l_l1_ (u"ࠧๆี็ื้อสࠡ࠯ࠣัฬ๊๊สࠩ⻞")
		l1ll1ll1111_l1_ = l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠢ࠰ࠤศำฯฬࠩ⻟")
		l1l1l1ll11l_l1_ = l11l1l_l1_ (u"่ࠩืู้ไศฬࠣ࠱ࠥษศอัํࠫ⻠")
		l1l1l1ll1ll_l1_ = l11l1l_l1_ (u"ࠪฬะࠦอ๋ࠢล๎ࠥ็๊ๅ็ࠪ⻡")
		l1l1l1ll1l1_l1_ = l11l1l_l1_ (u"ࠫศ็ไศ็ࠪ⻢")
		l1l1l1lll1l_l1_ = l11l1l_l1_ (u"๋่ࠬิ์ๅํࠬ⻣")
		l1l1l1lll11_l1_ = l11l1l_l1_ (u"࠭ศาษ่ะࠬ⻤")
	elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠧࡦࡰࠪ⻥") or l1ll1_l1_==l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡐࡊࡐࡎ࡙ࡈࠨ⻦"):
		l1l1l1ll111_l1_ = l11l1l_l1_ (u"ࠩࡖࡩࡦࡸࡣࡩࠢ࡬ࡲࠥࡹࡩࡵࡧࠪ⻧")
		l1l1l1l1lll_l1_ = l11l1l_l1_ (u"ࠪࡗࡪࡸࡩࡦࡵࠣ࠱ࠥࡉࡵࡳࡴࡨࡲࡹ࠭⻨")
		l1ll1ll1111_l1_ = l11l1l_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠤ࠲ࠦࡌࡢࡶࡨࡷࡹ࠭⻩")
		l1l1l1ll11l_l1_ = l11l1l_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠥ࠳ࠠࡂ࡮ࡳ࡬ࡦࡨࡥࡵࠩ⻪")
		l1l1l1ll1ll_l1_ = l11l1l_l1_ (u"࠭ࡌࡪࡸࡨࠤ࡮ࡌࡩ࡭࡯ࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࠫ⻫")
		l1l1l1ll1l1_l1_ = l11l1l_l1_ (u"ࠧࡎࡱࡹ࡭ࡪࡹࠧ⻬")
		l1l1l1lll1l_l1_ = l11l1l_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⻭")
		l1l1l1lll11_l1_ = l11l1l_l1_ (u"ࠩࡖ࡬ࡴࡽࡳࠨ⻮")
	elif l1ll1l111l1_l1_ in [l11l1l_l1_ (u"ࠪࡪࡦ࠭⻯"),l11l1l_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⻰")]:
		l1l1l1ll111_l1_ = l11l1l_l1_ (u"ࠬาำหฮ๋ࠤิืࠠิษ໏ฮࠬ⻱")
		l1l1l1l1lll_l1_ = l11l1l_l1_ (u"࠭ำา์ส่ࠥ࠳ࠠอษิ໐ࠬ⻲")
		l1ll1ll1111_l1_ = l11l1l_l1_ (u"ࠧิำํห้ࠦ࠭ࠡฤัี໑์ࠧ⻳")
		l1l1l1ll11l_l1_ = l11l1l_l1_ (u"ࠨีิ๎ฬ๊ࠠ࠮ࠢส่ๆฮวࠨ⻴")
		l1l1l1ll1ll_l1_ = l11l1l_l1_ (u"ࠩກาูࠦา็ั๊ࠤฬ๐ࠠโ์็้ࠬ⻵")
		l1l1l1ll1l1_l1_ = l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ⻶")
		l1l1l1lll1l_l1_ = l11l1l_l1_ (u"๊ࠫ๎ำ๋ไ์ࠫ⻷")
		l1l1l1lll11_l1_ = l11l1l_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠨ⻸")
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⻹"),l1111l_l1_+l1l1l1ll111_l1_,l1l1ll11ll1_l1_,29,l11l1l_l1_ (u"ࠧࠨ⻺"),l11l1l_l1_ (u"ࠨࠩ⻻"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭⻼"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ⻽"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭⻾")+l1111l_l1_+l1l1l1ll1ll_l1_,l1l1ll11ll1_l1_,27)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⻿"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠳ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥ࠷࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⼀"),l11l1l_l1_ (u"ࠧࠨ⼁"),9999)
	menu = [l11l1l_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⼂"),l11l1l_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⼃"),l11l1l_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⼄")]
	html = OPENURL_CACHED(l1llll11_l1_,l1l1ll11ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࡮࡯࡮ࡧࠪ⼅"),l11l1l_l1_ (u"ࠬ࠭⼆"),l11l1l_l1_ (u"࠭ࠧ⼇"),l11l1l_l1_ (u"ࠧࠨ⼈"),l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⼉"))
	l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠩࡥࡹࡹࡺ࡯࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭࠴ࡉ࡯࡯ࡶࡤࡧࡹ࠭⼊"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⼋"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if any(value in l1llll1_l1_ for value in menu):
				url = l1l1ll11ll1_l1_+l1llll1_l1_
				if l11l1l_l1_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ⼌") in l1llll1_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼍"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ⼎")+l1111l_l1_+l1l1l1l1lll_l1_,url,22,l11l1l_l1_ (u"ࠧࠨ⼏"),l11l1l_l1_ (u"ࠨ࠳࠳࠴ࠬ⼐"))
					addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼑"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⼒")+l1111l_l1_+l1ll1ll1111_l1_,url,22,l11l1l_l1_ (u"ࠫࠬ⼓"),l11l1l_l1_ (u"ࠬ࠷࠰࠲ࠩ⼔"))
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⼕"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⼖")+l1111l_l1_+l1l1l1ll11l_l1_,url,22,l11l1l_l1_ (u"ࠨࠩ⼗"),l11l1l_l1_ (u"ࠩ࠵࠴࠶࠭⼘"))
				elif l11l1l_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⼙") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼚"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ⼛")+l1111l_l1_+l1l1l1ll1l1_l1_,url,22,l11l1l_l1_ (u"࠭ࠧ⼜"),l11l1l_l1_ (u"ࠧ࠲࠲࠳ࠫ⼝"))
				elif l11l1l_l1_ (u"ࠨࡏࡸࡷ࡮ࡩࠧ⼞") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼟"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ⼠")+l1111l_l1_+l1l1l1lll1l_l1_,url,25,l11l1l_l1_ (u"ࠫࠬ⼡"),l11l1l_l1_ (u"ࠬ࠷࠰࠲ࠩ⼢"))
				elif l11l1l_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⼣") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼤"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⼥")+l1111l_l1_+l1l1l1lll11_l1_,url,22,l11l1l_l1_ (u"ࠩࠪ⼦"),l11l1l_l1_ (u"ࠪ࠵࠵࠷ࠧ⼧"))
	return html
def l1l1l1l1ll1_l1_(url):
	l1l1ll11ll1_l1_ = l1l1l1llll1_l1_(url)
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠫࠬ⼨"),l11l1l_l1_ (u"ࠬ࠭⼩"),l11l1l_l1_ (u"࠭ࠧ⼪"),l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡍࡖࡕࡌࡇࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⼫"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡏࡸࡷ࡮ࡩ࠭ࡵࡱࡲࡰࡸ࠳ࡨࡦࡣࡧࡩࡷ࠮࠮ࠫࡁࠬࡑࡺࡹࡩࡤ࠯ࡥࡳࡩࡿࠧ⼬"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	title = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡴࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ⼭"),block,re.DOTALL)[0]
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼮"),l1111l_l1_+title,url,22,l11l1l_l1_ (u"ࠫࠬ⼯"),l11l1l_l1_ (u"ࠬ࠷࠰࠲ࠩ⼰"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⼱"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l1l1ll11ll1_l1_ + l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼲"),l1111l_l1_+title,l1llll1_l1_,23,l11l1l_l1_ (u"ࠨࠩ⼳"),l11l1l_l1_ (u"ࠩ࠴࠴࠶࠭⼴"))
	return
def l1lllll_l1_(url,l11lll1_l1_):
	l1l1ll11ll1_l1_ = l1l1l1llll1_l1_(url)
	l1ll1l111l1_l1_ = l1l1ll1l111_l1_(url)
	type = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ⼵"))[-1]
	l1l1l1l11ll_l1_ = str(int(l11lll1_l1_)//100)
	l11lll1_l1_ = str(int(l11lll1_l1_)%100)
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ⼶"),l11l1l_l1_ (u"ࠬ࠭⼷"),url, type)
	if type==l11l1l_l1_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭⼸") and l11lll1_l1_==l11l1l_l1_ (u"ࠧ࠱ࠩ⼹"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠨࠩ⼺"),l11l1l_l1_ (u"ࠩࠪ⼻"),l11l1l_l1_ (u"ࠪࠫ⼼"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ⼽"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠫ⼾"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁ࠭࠴ࠪࡀࠫࡁ࠲࠯ࡅࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⼿"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			title = escapeUNICODE(title)
			title = unescapeHTML(title)
			l1llll1_l1_ = l1l1ll11ll1_l1_ + l1llll1_l1_
			l1ll1l_l1_ = l1l1ll11ll1_l1_ + QUOTE(l1ll1l_l1_)
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⽀"),l1111l_l1_+title,l1llll1_l1_,23,l1ll1l_l1_,l1l1l1l11ll_l1_+l11l1l_l1_ (u"ࠨ࠲࠴ࠫ⽁"))
	l1l1l1l1l11_l1_=0
	if type==l11l1l_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩ⽂"): category=l11l1l_l1_ (u"ࠪ࠷ࠬ⽃")
	if type==l11l1l_l1_ (u"ࠫࡋ࡯࡬࡮ࠩ⽄"): category=l11l1l_l1_ (u"ࠬ࠻ࠧ⽅")
	if type==l11l1l_l1_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ⽆"): category=l11l1l_l1_ (u"ࠧ࠸ࠩ⽇")
	if type in [l11l1l_l1_ (u"ࠨࡕࡨࡶ࡮࡫ࡳࠨ⽈"),l11l1l_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⽉"),l11l1l_l1_ (u"ࠪࡊ࡮ࡲ࡭ࠨ⽊")] and l11lll1_l1_!=l11l1l_l1_ (u"ࠫ࠵࠭⽋"):
		l111l1l_l1_ = l1l1ll11ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡕࡧࡧࡦ࡫ࡱ࡫ࡎࡺࡥ࡮ࡁࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬ⽌")+category+l11l1l_l1_ (u"࠭ࠦࡱࡣࡪࡩࡂ࠭⽍")+l11lll1_l1_+l11l1l_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡲࡶࡩ࡫ࡲࡣࡻࡀࠫ⽎")+l1l1l1l11ll_l1_
		html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ⽏"),l11l1l_l1_ (u"ࠩࠪ⽐"),l11l1l_l1_ (u"ࠪࠫ⽑"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧ⽒"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⽓"),l11l1l_l1_ (u"࠭ࠧ⽔"),l111l1l_l1_, html)
		items = re.findall(l11l1l_l1_ (u"ࠧࠣࡋࡧࠦ࠿࠮࠮ࠫࡁࠬ࠰࡚ࠧࡩࡵ࡮ࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠱࠿ࠣࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⽕"),html,re.DOTALL)
		for id,title,l1ll1l_l1_ in items:
			title = escapeUNICODE(title)
			title = title.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠫ⽖"),l11l1l_l1_ (u"ࠩࠪ⽗"))
			title = title.replace(l11l1l_l1_ (u"ࠪࠦࠬ⽘"),l11l1l_l1_ (u"ࠫࠬ⽙"))
			l1l1l1l1l11_l1_ += 1
			l1llll1_l1_ = l1l1ll11ll1_l1_ + l11l1l_l1_ (u"ࠬ࠵ࠧ⽚") + type + l11l1l_l1_ (u"࠭࠯ࡄࡱࡱࡸࡪࡴࡴ࠰ࠩ⽛") + id
			l1ll1l_l1_ = l1l1ll11ll1_l1_ + QUOTE(l1ll1l_l1_)
			if type==l11l1l_l1_ (u"ࠧࡇ࡫࡯ࡱࠬ⽜"): addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⽝"),l1111l_l1_+title,l1llll1_l1_,24,l1ll1l_l1_,l1l1l1l11ll_l1_+l11l1l_l1_ (u"ࠩ࠳࠵ࠬ⽞"))
			else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⽟"),l1111l_l1_+title,l1llll1_l1_,23,l1ll1l_l1_,l1l1l1l11ll_l1_+l11l1l_l1_ (u"ࠫ࠵࠷ࠧ⽠"))
	if type==l11l1l_l1_ (u"ࠬࡓࡵࡴ࡫ࡦࠫ⽡"):
		html = OPENURL_CACHED(REGULAR_CACHE,l1l1ll11ll1_l1_+l11l1l_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡉ࡯ࡦࡨࡼࡄࡶࡡࡨࡧࡀࠫ⽢")+l11lll1_l1_,l11l1l_l1_ (u"ࠧࠨ⽣"),l11l1l_l1_ (u"ࠨࠩ⽤"),l11l1l_l1_ (u"ࠩࠪ⽥"),l11l1l_l1_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭⽦"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࠮ࡦࡨࡱࡴ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴ࠭ࡥࡧࡰࡳࠬ⽧"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧ⽨"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			l1l1l1l1l11_l1_ += 1
			l1ll1l_l1_ = l1l1ll11ll1_l1_ + l1ll1l_l1_
			l1llll1_l1_ = l1l1ll11ll1_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⽩"),l1111l_l1_+title,l1llll1_l1_,23,l1ll1l_l1_,l11l1l_l1_ (u"ࠧ࠲࠲࠴ࠫ⽪"))
	if l1l1l1l1l11_l1_>20:
		title=l11l1l_l1_ (u"ࠨืไัฮࠦࠧ⽫")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠩࡨࡲࠬ⽬"): title = l11l1l_l1_ (u"ࠪࡔࡦ࡭ࡥࠡࠩ⽭")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠫ࡫ࡧࠧ⽮"): title = l11l1l_l1_ (u"ࠬ฻แฮ้ࠣࠫ⽯")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"࠭ࡦࡢ࠴ࠪ⽰"): title = l11l1l_l1_ (u"ࠧึใะ๋ࠥ࠭⽱")
		for l1l1ll11111_l1_ in range(1,11) :
			if not l11lll1_l1_==str(l1l1ll11111_l1_):
				l1l1l1l1l1l_l1_ = l11l1l_l1_ (u"ࠨ࠲ࠪ⽲")+str(l1l1ll11111_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽳"),l1111l_l1_+title+str(l1l1ll11111_l1_),url,22,l11l1l_l1_ (u"ࠪࠫ⽴"),l1l1l1l11ll_l1_+l1l1l1l1l1l_l1_[-2:])
	return
def l1lll1l1_l1_(url,l11lll1_l1_):
	if not l11lll1_l1_: l11lll1_l1_ = 0
	l1l1ll11ll1_l1_ = l1l1l1llll1_l1_(url)
	l1l1ll11lll_l1_ = l1l1l1llll1_l1_(url)
	l1ll1l111l1_l1_ = l1l1ll1l111_l1_(url)
	parts = url.split(l11l1l_l1_ (u"ࠫ࠴࠭⽵"))
	id,type = parts[-1],parts[3]
	l1l1l1l11ll_l1_ = str(int(l11lll1_l1_)//100)
	l11lll1_l1_ = str(int(l11lll1_l1_)%100)
	l1l1l1l1l11_l1_ = 0
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭⽶"),l11l1l_l1_ (u"࠭ࠧ⽷"),url, type)
	if type==l11l1l_l1_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧ⽸"):
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠨࠩ⽹"),l11l1l_l1_ (u"ࠩࠪ⽺"),l11l1l_l1_ (u"ࠪࠫ⽻"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ⽼"))
		items = re.findall(l11l1l_l1_ (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡥࡰࡢࡰࡨࡰࡤࡏࡴࡦ࡯࠱࠮ࡄࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࡩ࠯࠭ࡂࡺࡦࡸࠠࡪࡰࡷࡩࡷࡥࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨࠩ⽽"),html,re.DOTALL)
		title = l11l1l_l1_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪ⽾")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠧࡦࡰࠪ⽿"): title = l11l1l_l1_ (u"ࠨࠢ࠰ࠤࡊࡶࡩࡴࡱࡧࡩࠥ࠭⾀")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠩࡩࡥࠬ⾁"): title = l11l1l_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ⾂")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠫ࡫ࡧ࠲ࠨ⾃"): title = l11l1l_l1_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧ⾄")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"࠭ࡦࡢࠩ⾅"): l1l1ll111ll_l1_ = l11l1l_l1_ (u"ࠧࠨ⾆")
		else: l1l1ll111ll_l1_ = l1ll1l111l1_l1_
		l1l1ll1l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ⾇"),html,re.DOTALL)
		for name,count,l1ll1l_l1_,l1llll1_l1_ in items:
			for l1ll11l_l1_ in range(int(count),0,-1):
				l1l11l11l_l1_ = l1ll1l_l1_ + l1l1ll111ll_l1_ + id + l11l1l_l1_ (u"ࠩ࠲ࠫ⾈") + str(l1ll11l_l1_) + l11l1l_l1_ (u"ࠪ࠲ࡵࡴࡧࠨ⾉")
				#l1ll1ll1lll_l1_ = l1l1ll1l11l_l1_[0][0]+l1ll1l111l1_l1_+id+l11l1l_l1_ (u"ࠫ࠴࠲ࠧ⾊")+str(l1ll11l_l1_)+l11l1l_l1_ (u"ࠬ࠲ࠧ⾋")+str(l1ll11l_l1_)+l11l1l_l1_ (u"࠭࡟ࠨ⾌")+l1l1ll1l11l_l1_[0][2]
				l1l1l1l1lll_l1_ = name + title + str(l1ll11l_l1_)
				l1l1l1l1lll_l1_ = unescapeHTML(l1l1l1l1lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⾍"),l1111l_l1_+l1l1l1l1lll_l1_,url,24,l1l11l11l_l1_,l11l1l_l1_ (u"ࠨࠩ⾎"),str(l1ll11l_l1_))
	elif type==l11l1l_l1_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠪ⾏"):
		l111l1l_l1_ = l1l1ll11ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡓࡥ࡬࡫ࡩ࡯ࡩࡄࡸࡹࡧࡣࡩ࡯ࡨࡲࡹࡏࡴࡦ࡯ࡂ࡭ࡩࡃࠧ⾐")+str(id)+l11l1l_l1_ (u"ࠫࠫࡶࡡࡨࡧࡀࠫ⾑")+l11lll1_l1_+l11l1l_l1_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡰࡴࡧࡩࡷࡨࡹ࠾࠳ࠪ⾒")
		html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ⾓"),l11l1l_l1_ (u"ࠧࠨ⾔"),l11l1l_l1_ (u"ࠨࠩ⾕"),l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ⾖"))
		items = re.findall(l11l1l_l1_ (u"ࠪࡉࡵ࡯ࡳࡰࡦࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡆ࡬ࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⾗"),html,re.DOTALL)
		title = l11l1l_l1_ (u"ࠫࠥ࠳ࠠศๆะ่็ฯࠠࠨ⾘")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠬ࡫࡮ࠨ⾙"): title = l11l1l_l1_ (u"࠭ࠠ࠮ࠢࡈࡴ࡮ࡹ࡯ࡥࡧࠣࠫ⾚")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠧࡧࡣࠪ⾛"): title = l11l1l_l1_ (u"ࠨࠢ࠰ࠤ็ูๅหࠢࠪ⾜")
		if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠩࡩࡥ࠷࠭⾝"): title = l11l1l_l1_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬ⾞")
		for l1ll11l_l1_,l1ll1l_l1_,l1llll1_l1_,desc,name in items:
			l1l1l1l1l11_l1_ += 1
			l1l11l11l_l1_ = l1l1ll11lll_l1_ + QUOTE(l1ll1l_l1_)
			#l1ll1ll1lll_l1_ = l1l1ll11lll_l1_ + QUOTE(l1llll1_l1_)
			name = escapeUNICODE(name)
			l1l1l1l1lll_l1_ = name + title + str(l1ll11l_l1_)
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⾟"),l1111l_l1_+l1l1l1l1lll_l1_,l111l1l_l1_,24,l1l11l11l_l1_,l11l1l_l1_ (u"ࠬ࠭⾠"),str(l1l1l1l1l11_l1_))
	elif type==l11l1l_l1_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ⾡"):
		if l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴࠨ⾢") in url and l11l1l_l1_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ⾣") not in url:
			l111l1l_l1_ = l1l1ll11ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀࠫ⾤")+str(id)+l11l1l_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ⾥")+l11lll1_l1_+l11l1l_l1_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠵࠭⾦")
			html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭⾧"),l11l1l_l1_ (u"࠭ࠧ⾨"),l11l1l_l1_ (u"ࠧࠨ⾩"),l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠶ࡶࡩ࠭⾪"))
			items = re.findall(l11l1l_l1_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⾫"),html,re.DOTALL)
			for l1ll1l_l1_,l1llll1_l1_,name,title in items:
				l1l1l1l1l11_l1_ += 1
				l1l11l11l_l1_ = l1l1ll11lll_l1_ + QUOTE(l1ll1l_l1_)
				#l1ll1ll1lll_l1_ = l1l1ll11lll_l1_ + QUOTE(l1llll1_l1_)
				l1l1l1l1lll_l1_ = name + l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧ⾬") + title
				l1l1l1l1lll_l1_ = l1l1l1l1lll_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭⾭"))
				l1l1l1l1lll_l1_ = escapeUNICODE(l1l1l1l1lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⾮"),l1111l_l1_+l1l1l1l1lll_l1_,l111l1l_l1_,24,l1l11l11l_l1_,l11l1l_l1_ (u"࠭ࠧ⾯"),str(l1l1l1l1l11_l1_))
		elif l11l1l_l1_ (u"ࠧࡄ࡮࡬ࡴࡸ࠭⾰") in url:
			l111l1l_l1_ = l1l1ll11ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡉࡨࡸ࡙ࡸࡡࡤ࡭ࡶࡆࡾࡅࡩࡥ࠿࠳ࠪࡵࡧࡧࡦ࠿ࠪ⾱")+l11lll1_l1_+l11l1l_l1_ (u"ࠩࠩࡷ࡮ࢀࡥ࠾࠵࠳ࠪࡹࡿࡰࡦ࠿࠴࠹ࠬ⾲")
			html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠪࠫ⾳"),l11l1l_l1_ (u"ࠫࠬ⾴"),l11l1l_l1_ (u"ࠬ࠭⾵"),l11l1l_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠵ࡶ࡫ࠫ⾶"))
			items = re.findall(l11l1l_l1_ (u"ࠧࡊ࡯ࡤ࡫ࡪࡇࡤࡥࡴࡨࡷࡸࡥࡓࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡉࡡࡱࡶ࡬ࡳࡳࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚࡮ࡪࡥࡰࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⾷"),html,re.DOTALL)
			for l1ll1l_l1_,title,l1llll1_l1_ in items:
				l1l1l1l1l11_l1_ += 1
				l1l11l11l_l1_ = l1l1ll11lll_l1_ + QUOTE(l1ll1l_l1_)
				#l1ll1ll1lll_l1_ = l1l1ll11lll_l1_ + QUOTE(l1llll1_l1_)
				l1l1l1l1lll_l1_ = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ⾸"))
				l1l1l1l1lll_l1_ = escapeUNICODE(l1l1l1l1lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⾹"),l1111l_l1_+l1l1l1l1lll_l1_,l111l1l_l1_,24,l1l11l11l_l1_,l11l1l_l1_ (u"ࠪࠫ⾺"),str(l1l1l1l1l11_l1_))
		elif l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭⾻") in url:
			if l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠷ࠩ⾼") in url:
				l111l1l_l1_ = l1l1ll11ll1_l1_+l11l1l_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⾽")+l11lll1_l1_+l11l1l_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠷ࠩ⾾")
				html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ⾿"),l11l1l_l1_ (u"ࠩࠪ⿀"),l11l1l_l1_ (u"ࠪࠫ⿁"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠻ࡴࡩࠩ⿂"))
			elif l11l1l_l1_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࠽࠵ࠩ⿃") in url:
				l111l1l_l1_ = l1l1ll11ll1_l1_+l11l1l_l1_ (u"࠭࠯ࡎࡷࡶ࡭ࡨ࠵ࡇࡦࡶࡗࡶࡦࡩ࡫ࡴࡄࡼࡃ࡮ࡪ࠽࠱ࠨࡳࡥ࡬࡫࠽ࠨ⿄")+l11lll1_l1_+l11l1l_l1_ (u"ࠧࠧࡵ࡬ࡾࡪࡃ࠳࠱ࠨࡷࡽࡵ࡫࠽࠵ࠩ⿅")
				html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ⿆"),l11l1l_l1_ (u"ࠩࠪ⿇"),l11l1l_l1_ (u"ࠪࠫ⿈"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠼ࡴࡩࠩ⿉"))
			items = re.findall(l11l1l_l1_ (u"ࠬࡏ࡭ࡢࡩࡨࡅࡩࡪࡲࡦࡵࡶࡣࡘࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡚ࡴ࡯ࡣࡦࡃࡧࡨࡷ࡫ࡳࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡃࡢࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ⿊"),html,re.DOTALL)
			for l1ll1l_l1_,l1llll1_l1_,name,title in items:
				l1l1l1l1l11_l1_ += 1
				l1l11l11l_l1_ = l1l1ll11lll_l1_ + QUOTE(l1ll1l_l1_)
				#l1ll1ll1lll_l1_ = l1l1ll11lll_l1_ + QUOTE(l1llll1_l1_)
				l1l1l1l1lll_l1_ = name + l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ⿋") + title
				l1l1l1l1lll_l1_ = l1l1l1l1lll_l1_.strip(l11l1l_l1_ (u"ࠧࠡࠩ⿌"))
				l1l1l1l1lll_l1_ = escapeUNICODE(l1l1l1l1lll_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⿍"),l1111l_l1_+l1l1l1l1lll_l1_,l111l1l_l1_,24,l1l11l11l_l1_,l11l1l_l1_ (u"ࠩࠪ⿎"),str(l1l1l1l1l11_l1_))
	if type==l11l1l_l1_ (u"ࠪࡑࡺࡹࡩࡤࠩ⿏") or type==l11l1l_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ⿐"):
		if l1l1l1l1l11_l1_>25:
			title=l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ⿑")
			if l1ll1l111l1_l1_==l11l1l_l1_ (u"࠭ࡥ࡯ࠩ⿒"): title = l11l1l_l1_ (u"ࠧࠡࡒࡤ࡫ࡪࠦࠧ⿓")
			if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠨࡨࡤࠫ⿔"): title = l11l1l_l1_ (u"ูࠩࠣๆำ็ࠡࠩ⿕")
			if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠪࡪࡦ࠸ࠧ⿖"): title = l11l1l_l1_ (u"ࠫࠥ฻แฮ้ࠣࠫ⿗")
			for l1l1ll11111_l1_ in range(1,11):
				if not l11lll1_l1_==str(l1l1ll11111_l1_):
					l1l1l1l1l1l_l1_ = l11l1l_l1_ (u"ࠬ࠶ࠧ⿘")+str(l1l1ll11111_l1_)
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⿙"),l1111l_l1_+title+str(l1l1ll11111_l1_),url,23,l11l1l_l1_ (u"ࠧࠨ⿚"),l1l1l1l11ll_l1_+l1l1l1l1l1l_l1_[-2:])
	return
def PLAY(url,l1ll11l_l1_):
	l1l1ll11lll_l1_ = l1l1l1llll1_l1_(url)
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠨࠩ⿛"),l11l1l_l1_ (u"ࠩࠪ⿜"),l11l1l_l1_ (u"ࠪࠫ⿝"),l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ⿞"))
	# l11ll_l1_ l1lll1l1l_l1_ l1l1_l1_
	items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠪ࡟ࠫ࠳࠰࠿࡝ࠩࡢ࠭࠭࠴ࠪࡀࠫࠥࡂࠬ⿟"),html,re.DOTALL)
	if items:
		l1ll1l111l1_l1_ = l1l1ll1l111_l1_(url)
		parts = url.split(l11l1l_l1_ (u"࠭࠯ࠨ⿠"))
		id,type = parts[-1],parts[3]
		l1llll1_l1_ = items[0][0]+l1ll1l111l1_l1_+id+l11l1l_l1_ (u"ࠧ࠰࠮ࠪ⿡")+l1ll11l_l1_+l11l1l_l1_ (u"ࠨ࠮ࠪ⿢")+l1ll11l_l1_+l11l1l_l1_ (u"ࠩࡢࠫ⿣")+items[0][2]
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠪࡱ࠸ࡻ࠸ࠨ⿤"))
		l1lll1_l1_.append(l1llll1_l1_)
	# l11ll_l1_ l11111l1_l1_ url
	items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡸࡶࡱࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࡠࠬ࠴ࠪࡀ࡞ࠪ࠭࠭ࡢ࠮࠯ࠬࡂ࠭ࠧ࠭⿥"),html,re.DOTALL)
	if items:
		l1ll1l111l1_l1_ = l1l1ll1l111_l1_(url)
		parts = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ⿦"))
		id,type = parts[-1],parts[3]
		l1llll1_l1_ = items[0][0]+l1ll1l111l1_l1_+id+l11l1l_l1_ (u"࠭࠯ࠨ⿧")+l1ll11l_l1_+items[0][2]
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠧ࡮ࡲ࠷ࠤࡺࡸ࡬ࠨ⿨"))
		l1lll1_l1_.append(l1llll1_l1_)
	# l11ll_l1_ l11111l1_l1_ src
	items = re.findall(l11l1l_l1_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⿩"),html,re.DOTALL)
	for l1llll1_l1_ in items:
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠩ࠲࠳ࠬ⿪"),l11l1l_l1_ (u"ࠪ࠳ࠬ⿫"))
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠫࡲࡶ࠴ࠡࡵࡵࡧࠬ⿬"))
		l1lll1_l1_.append(l1llll1_l1_)
	# l1l1ll11l11_l1_ l11111l1_l1_ l1l1_l1_
	items = re.findall(l11l1l_l1_ (u"ࠬ࡜ࡩࡥࡧࡲࡅࡩࡪࡲࡦࡵࡶࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⿭"),html,re.DOTALL)
	if items:
		l1llll1_l1_ = items[int(l1ll11l_l1_)-1]
		l1llll1_l1_ = l1l1ll11lll_l1_+QUOTE(l1llll1_l1_)
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"࠭࡭ࡱ࠶ࠣࡥࡩࡪࡲࡦࡵࡶࠫ⿮"))
		l1lll1_l1_.append(l1llll1_l1_)
	# l1l1ll11l11_l1_ l1l1ll1l1l1_l1_ l1l1_l1_
	items = re.findall(l11l1l_l1_ (u"ࠧࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⿯"),html,re.DOTALL)
	if items:
		l1llll1_l1_ = items[int(l1ll11l_l1_)-1]
		l1llll1_l1_ = l1l1ll11lll_l1_+QUOTE(l1llll1_l1_)
		l1ll1ll1_l1_.append(l11l1l_l1_ (u"ࠨ࡯ࡳ࠷ࠥࡧࡤࡥࡴࡨࡷࡸ࠭⿰"))
		l1lll1_l1_.append(l1llll1_l1_)
	# l1l_l1_
	if len(l1lll1_l1_)==1: l1llll1_l1_ = l1lll1_l1_[0]
	else:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩสาฯืࠠศๆไ๎ิ๐่ࠡษ็้๋อำษ࠼ࠪ⿱"), l1ll1ll1_l1_)
		if l1l_l1_ == -1 : return
		l1llll1_l1_ = l1lll1_l1_[l1l_l1_]
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⿲"))
	return
def l1l1l1llll1_l1_(url):
	if l11l11_l1_ in url: l1l1llllll1_l1_ = l11l11_l1_
	elif l11lll11ll_l1_ in url: l1l1llllll1_l1_ = l11lll11ll_l1_
	elif l1l1l1lllll_l1_ in url: l1l1llllll1_l1_ = l1l1l1lllll_l1_
	elif l1l1ll1111l_l1_ in url: l1l1llllll1_l1_ = l1l1ll1111l_l1_
	else: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠫࠬ⿳")
	return l1l1llllll1_l1_
def l1l1ll1l111_l1_(url):
	if   l11l11_l1_ in url: l1ll1l111l1_l1_ = l11l1l_l1_ (u"ࠬࡧࡲࠨ⿴")
	elif l11lll11ll_l1_ in url: l1ll1l111l1_l1_ = l11l1l_l1_ (u"࠭ࡥ࡯ࠩ⿵")
	elif l1l1l1lllll_l1_ in url: l1ll1l111l1_l1_ = l11l1l_l1_ (u"ࠧࡧࡣࠪ⿶")
	elif l1l1ll1111l_l1_ in url: l1ll1l111l1_l1_ = l11l1l_l1_ (u"ࠨࡨࡤ࠶ࠬ⿷")
	else: l1ll1l111l1_l1_ = l11l1l_l1_ (u"ࠩࠪ⿸")
	return l1ll1l111l1_l1_
def l1l1ll111_l1_(url):
	l1ll1l111l1_l1_ = l1l1ll1l111_l1_(url)
	l111l1l_l1_ = url + l11l1l_l1_ (u"ࠪ࠳ࡍࡵ࡭ࡦ࠱ࡏ࡭ࡻ࡫ࠧ⿹")
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ⿺"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭⿻"),l11l1l_l1_ (u"࠭ࠧ⿼"),l11l1l_l1_ (u"ࠧࠨ⿽"),l11l1l_l1_ (u"ࠨࠩ⿾"),l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪ⿿"))
	html = response.content
	items = re.findall(l11l1l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ　"),html,re.DOTALL)
	l111ll1_l1_ = items[0]
	PLAY_VIDEO(l111ll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ、"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ。"),l11l1l_l1_ (u"࠭ࠫࠨ〃"))
	if l1ll_l1_:
		l1ll1l11ll_l1_ = [ l11l11_l1_ , l11lll11ll_l1_ , l1l1l1lllll_l1_ , l1l1ll1111l_l1_ ]
		l1l111ll1_l1_ = [ l11l1l_l1_ (u"ฺࠧำห๎ࠬ〄") , l11l1l_l1_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ々") , l11l1l_l1_ (u"ࠩไหึู้ࠨ〆") , l11l1l_l1_ (u"ࠪๅฬืำ๊ࠢ࠵ࠫ〇") ]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่้เษࠡษ็้๋อำษห࠽ࠫ〈"), l1l111ll1_l1_)
		if l1l_l1_ == -1 : return
		l1l11lll_l1_ = l1ll1l11ll_l1_[l1l_l1_]
	else:
		if l11l1l_l1_ (u"ࠬࡥࡉࡇࡋࡏࡑ࠲ࡇࡒࡂࡄࡌࡇࡤ࠭〉") in options: l1l11lll_l1_ = l11l11_l1_
		elif l11l1l_l1_ (u"࠭࡟ࡊࡈࡌࡐࡒ࠳ࡅࡏࡉࡏࡍࡘࡎ࡟ࠨ《") in options: l1l11lll_l1_ = l11lll11ll_l1_
		else: l1l11lll_l1_ = l11l1l_l1_ (u"ࠧࠨ》")
	if not l1l11lll_l1_: return
	l1ll1l111l1_l1_ = l1l1ll1l111_l1_(l1l11lll_l1_)
	l111l1l_l1_ = l1l11lll_l1_ + l11l1l_l1_ (u"ࠣ࠱ࡋࡳࡲ࡫࠯ࡔࡧࡤࡶࡨ࡮࠿ࡴࡧࡤࡶࡨ࡮ࡳࡵࡴ࡬ࡲ࡬ࡃࠢ「") + l11111l_l1_
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ」"),l11l1l_l1_ (u"ࠪࠫ『"),l1ll1l111l1_l1_,l111l1l_l1_)
	html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠫࠬ』"),l11l1l_l1_ (u"ࠬ࠭【"),l11l1l_l1_ (u"࠭ࠧ】"),l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ〒"))
	items = re.findall(l11l1l_l1_ (u"ࠨࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠬ〓"),html,re.DOTALL)
	if items:
		for l1ll1l_l1_,category,id,title in items:
			#if category in [l11l1l_l1_ (u"ࠩ࠶ࠫ〔"),l11l1l_l1_ (u"ࠪ࠹ࠬ〕"),l11l1l_l1_ (u"ࠫ࠼࠭〖")]:
			if category in [l11l1l_l1_ (u"ࠬ࠹ࠧ〗"),l11l1l_l1_ (u"࠭࠷ࠨ〘")]:
				title = title.replace(l11l1l_l1_ (u"ࠧ࡝࡞ࠪ〙"),l11l1l_l1_ (u"ࠨࠩ〚"))
				title = title.replace(l11l1l_l1_ (u"ࠩࠥࠫ〛"),l11l1l_l1_ (u"ࠪࠫ〜"))
				if category==l11l1l_l1_ (u"ࠫ࠸࠭〝"):
					type = l11l1l_l1_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ〞")
					if l1ll1l111l1_l1_==l11l1l_l1_ (u"࠭ࡡࡳࠩ〟"): name = l11l1l_l1_ (u"ࠧๆี็ื้ࠦ࠺ࠡࠩ〠")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠨࡧࡱࠫ〡"): name = l11l1l_l1_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠢ࠽ࠤࠬ〢")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠪࡪࡦ࠭〣"): name = l11l1l_l1_ (u"ุࠫื๊ศๆ๋ࠣฬࠦ࠺ࠡࠩ〤")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠬ࡬ࡡ࠳ࠩ〥"): name = l11l1l_l1_ (u"࠭ำา์ส่ࠥํวࠡ࠼ࠣࠫ〦")
				elif category==l11l1l_l1_ (u"ࠧ࠶ࠩ〧"):
					type = l11l1l_l1_ (u"ࠨࡈ࡬ࡰࡲ࠭〨")
					if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠩࡤࡶࠬ〩"): name = l11l1l_l1_ (u"ࠪๅ๏๊ๅࠡ࠼〪ࠣࠫ")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠫࡪࡴ〫ࠧ"): name = l11l1l_l1_ (u"ࠬࡓ࡯ࡷ࡫ࡨࠤ࠿ࠦࠧ〬")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"࠭ࡦࡢ〭ࠩ"): name = l11l1l_l1_ (u"ࠧโ์็้ࠥࡀࠠࠨ〮")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠨࡨࡤ࠶〯ࠬ"): name = l11l1l_l1_ (u"ࠩไ่๊ࠦ็ศࠢ࠽ࠤࠬ〰")
				elif category==l11l1l_l1_ (u"ࠪ࠻ࠬ〱"):
					type = l11l1l_l1_ (u"ࠫࡕࡸ࡯ࡨࡴࡤࡱࠬ〲")
					if l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠬࡧࡲࠨ〳"): name = l11l1l_l1_ (u"࠭ศา่ส้ัࠦ࠺ࠡࠩ〴")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠧࡦࡰࠪ〵"): name = l11l1l_l1_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠢ࠽ࠤࠬ〶")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠩࡩࡥࠬ〷"): name = l11l1l_l1_ (u"ࠪฬึ์วๆ้๋ࠣฬࠦ࠺ࠡࠩ〸")
					elif l1ll1l111l1_l1_==l11l1l_l1_ (u"ࠫ࡫ࡧ࠲ࠨ〹"): name = l11l1l_l1_ (u"ࠬฮั็ษ่๋ࠥํวࠡ࠼ࠣࠫ〺")
				title = name + title
				l1llll1_l1_ = l1l11lll_l1_ + l11l1l_l1_ (u"࠭࠯ࠨ〻") + type + l11l1l_l1_ (u"ࠧ࠰ࡅࡲࡲࡹ࡫࡮ࡵ࠱ࠪ〼") + id
				l1ll1l_l1_ = QUOTE(l1ll1l_l1_)
				l1ll1l_l1_ = l1l11lll_l1_+l1ll1l_l1_
				#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ〽"),l1ll1l_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ〾"),l1111l_l1_+title,l1llll1_l1_,23,l1ll1l_l1_,l11l1l_l1_ (u"ࠪ࠵࠵࠷ࠧ〿"))
	#else: DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ぀"),l11l1l_l1_ (u"ࠬ࠭ぁ"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩあ"),,لا توجد نتائج للبحث')
	return
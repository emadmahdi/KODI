# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ⸠")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡊࡏࡇࡤ࠭⸡")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨ็ุหึ฿ษࠨ⸢"),l11l1l_l1_ (u"ࠩสัิัࠠศๆหีฬ๋ฬࠨ⸣"),l11l1l_l1_ (u"ࠪหาีหࠡษ็ห้฿วษࠩ⸤"),l11l1l_l1_ (u"ࠫฬำฯฬࠢส่ฬเว็๋ࠪ⸥")]
def MAIN(mode,url,text):
	if   mode==80: results = MENU()
	elif mode==81: results = l1lllll_l1_(url,text)
	elif mode==82: results = PLAY(url)
	elif mode==83: results = l1lll1l1_l1_(url)
	elif mode==89: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ⸦"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ⸧"),l11l1l_l1_ (u"ࠧࠨ⸨"),l11l1l_l1_ (u"ࠨࠩ⸩"),l11l1l_l1_ (u"ࠩࠪ⸪"),l11l1l_l1_ (u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⸫"))
	html = response.content
	l1l1ll1_l1_ = SERVER(l11l11_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ⸬"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⸭"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⸮"),l11l1l_l1_ (u"ࠧࠨⸯ"),89,l11l1l_l1_ (u"ࠨࠩ⸰"),l11l1l_l1_ (u"ࠩࠪ⸱"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⸲"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸳"),l1111l_l1_+l11l1l_l1_ (u"ࠬอฮหำ้ห๊ࠥใࠨ⸴"),l1l1ll1_l1_,81,l11l1l_l1_ (u"࠭ࠧ⸵"),l11l1l_l1_ (u"ࠧࠨ⸶"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⸷"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡰࡥ࡮ࡴ࠭ࡤࡱࡱࡸࡪࡴࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ⸸"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡰࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⸹"),block,re.DOTALL)
	for l1lll111ll_l1_,title in items:
		l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡫ࡪࡺࡉࡵࡧࡰࡃ࡮ࡺࡥ࡮࠿ࠪ⸺")+l1lll111ll_l1_+l11l1l_l1_ (u"ࠬࠬࡁ࡫ࡣࡻࡁ࠶࠭⸻")
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸼"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⸽")+l1111l_l1_+title,l1llll1_l1_,81)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⸾"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⸿"),l11l1l_l1_ (u"ࠪࠫ⹀"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡴࡡࡷ࠯ࡰࡥ࡮ࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡹࡂࠬ⹁"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⹂"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l1llll1_l1_==l11l1l_l1_ (u"࠭ࠣࠨ⹃"): continue
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⹄"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⹅")+l1111l_l1_+title,l1llll1_l1_,81)
	return
def l1lllll_l1_(url,l1lll111ll_l1_=l11l1l_l1_ (u"ࠩࠪ⹆")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ⹇"),l11l1l_l1_ (u"ࠫࠬ⹈"),url)
	items = []
	# l1lll11111_l1_ l1lll1111l_l1_
	if l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬ⹉") in url or l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴ࡲ࡯ࡢࡦࡐࡳࡷ࡫ࠧ⹊") in url:
		l111l1l_l1_,l11l1llll_l1_ = l1lll111l1_l1_(url)
		l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭⹋"):l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨ⹌")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡓࡓࡘ࡚ࠧ⹍"),l111l1l_l1_,l11l1llll_l1_,l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠪࠫ⹎"),l11l1l_l1_ (u"ࠫࠬ⹏"),l11l1l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ⹐"))
		html = response.content
		l1l11l1_l1_ = [html]
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ⹑"),url,l11l1l_l1_ (u"ࠧࠨ⹒"),l11l1l_l1_ (u"ࠨࠩ⹓"),l11l1l_l1_ (u"ࠩࠪ⹔"),l11l1l_l1_ (u"ࠪࠫ⹕"),l11l1l_l1_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠲࡯ࡦࠪ⹖"))
		html = response.content
		# l1lll111ll_l1_ items
		if l1lll111ll_l1_==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧ⹗"):
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠬ࠳࠰࠿ࠪࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶࠧ࠭⹘"),html,re.DOTALL)
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭⹙"),block,re.DOTALL)
			#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ⹚"),l11l1l_l1_ (u"ࠩࠪ⹛"),l11l1l_l1_ (u"ࠪࠫ⹜"))
		# l1lll1l1ll_l1_ l1111lll_l1_
		elif l11l1l_l1_ (u"ࠫࠧࡹࡥࡤࡶ࡬ࡳࡳ࠳ࡰࡰࡵࡷࠤࡲࡨ࠭࠲࠲ࠥࠫ⹝") in html:
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡥࡷ࡭ࡴࡴ࠭ࡱࡱࡶࡸࠥࡳࡢ࠮࠳࠳ࠦ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⹞"),html,re.DOTALL)
		else:
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ⹟"),html,re.DOTALL)
	if not l1l11l1_l1_: return
	block = l1l11l1_l1_[0]
	if not items:
		items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳࡯ࡳ࡫ࡪ࡭ࡳࡧ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⹠"),block,re.DOTALL)
		if not items: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⹡"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩ⹢"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ⹣"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪ⹤"),l11l1l_l1_ (u"้ࠬไ๋สࠪ⹥"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬ⹦"),l11l1l_l1_ (u"่ࠧัสๅࠬ⹧"),l11l1l_l1_ (u"ࠨ็หหึอษࠨ⹨"),l11l1l_l1_ (u"ࠩ฼ี฻࠭⹩"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪ⹪"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪ⹫")]
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧ⹬"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ⹭"),title,re.DOTALL)
		if l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⹮") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹯"),l1111l_l1_+title,l1llll1_l1_,83,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠩึ่ฬูไࠨ⹰") not in url and any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⹱"),l1111l_l1_+title,l1llll1_l1_,82,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠫฬ๊อๅไฬࠫ⹲") in title:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ⹳") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⹴"),l1111l_l1_+title,l1llll1_l1_,83,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ⹵") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹶"),l1111l_l1_+title,l1llll1_l1_,81,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⹷"),l1111l_l1_+title,l1llll1_l1_,83,l1ll1l_l1_)
	if l1lll111ll_l1_==l11l1l_l1_ (u"ࠪࠫ⹸"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲࠨ⹹"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⹺"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠨࠢ⹻"): continue
				#title = unescapeHTML(title)
				if title!=l11l1l_l1_ (u"ࠧࠨ⹼"): addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⹽"),l1111l_l1_+l11l1l_l1_ (u"ุࠩๅาฯࠠࠨ⹾")+title,l1llll1_l1_,81)
	if l11l1l_l1_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪ⹿") in url or l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬ⺀") in url:
		if l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡊࡶࡨࡱࠬ⺁") in url:
			url = url.replace(l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡋࡷࡩࡲ࠭⺂"),l11l1l_l1_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵࡬ࡰࡣࡧࡑࡴࡸࡥࠨ⺃"))+l11l1l_l1_ (u"ࠨࠨࡲࡪ࡫ࡹࡥࡵ࠿࠵࠴ࠬ⺄")
		elif l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰࡮ࡲࡥࡩࡓ࡯ࡳࡧࠪ⺅") in url:
			url,offset = url.split(l11l1l_l1_ (u"ࠪࠪࡴ࡬ࡦࡴࡧࡷࡁࠬ⺆"))
			offset = int(offset)+20
			url = url+l11l1l_l1_ (u"ࠫࠫࡵࡦࡧࡵࡨࡸࡂ࠭⺇")+str(offset)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⺈"),l1111l_l1_+l11l1l_l1_ (u"࠭็็ษๆࠤฬ๊ๅำ์าࠫ⺉"),url,81)
	return
def l1lll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⺊"),url,l11l1l_l1_ (u"ࠨࠩ⺋"),l11l1l_l1_ (u"ࠩࠪ⺌"),l11l1l_l1_ (u"ࠪࠫ⺍"),l11l1l_l1_ (u"ࠫࠬ⺎"),l11l1l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⺏"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࡆࡾ࡙ࡥࡳ࡫ࡨࡷ࠭࠴ࠪࡀࠫࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠨࠧ⺐"),html,re.DOTALL)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣ࡮࡬ࡷࡹ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠣࠪ࠱࠮ࡄ࠯ࠢࡤࡱࡱࡸࡦ࡯࡮ࡦࡴࠥࠫ⺑"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l1111_l1_ and l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪ⺒") not in url:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⺓"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⺔"),l1111l_l1_+title,l1llll1_l1_,83,l1ll1l_l1_)
	# l11ll_l1_
	elif l11llll_l1_:
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡯࡭ࡢࡩࡨࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⺕"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺖"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#title = title.replace(l11l1l_l1_ (u"࠭࡜࡯ࠩ⺗"),l11l1l_l1_ (u"ࠧࠨ⺘")).strip(l11l1l_l1_ (u"ࠨࠢࠪ⺙"))
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⺚"),l1111l_l1_+title,l1llll1_l1_,82,l1ll1l_l1_)
	return
def PLAY(url):
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶ࠳ࠬ⺛"),l11l1l_l1_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡣࡲࡵࡶࡪࡧࡶ࠳ࠬ⺜"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⺝"),l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ⺞"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ⺟"),l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ⺠"),l11l1l_l1_ (u"ࠩࠪ⺡"),l11l1l_l1_ (u"ࠪࠫ⺢"),l11l1l_l1_ (u"ࠫࠬ⺣"),l11l1l_l1_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ⺤"))
	html = response.content
	l1l1ll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ⺥"))
	l1lll1_l1_ = []
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡵࡨࡶࡻ࡫ࡲࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭⺦"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l11ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡲࡲࡷࡹࡏࡄࠡ࠿ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ⺧"),html,re.DOTALL)
		l11ll11l_l1_ = l11ll11l_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠤࡪࡩࡹࡖ࡬ࡢࡻࡨࡶࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ⺨"),block,re.DOTALL)
		for server,title in items:
			title = title.replace(l11l1l_l1_ (u"ࠪࡠࡳ࠭⺩"),l11l1l_l1_ (u"ࠫࠬ⺪")).strip(l11l1l_l1_ (u"ࠬࠦࠧ⺫"))
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡭ࡥࡵࡒ࡯ࡥࡾ࡫ࡲࡀࡵࡨࡶࡻ࡫ࡲ࠾ࠩ⺬")+server+l11l1l_l1_ (u"ࠧࠧࡲࡲࡷࡹࡏࡄ࠾ࠩ⺭")+l11ll11l_l1_+l11l1l_l1_ (u"ࠨࠨࡄ࡮ࡦࡾ࠽࠲ࠩ⺮")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⺯")+title+l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⺰")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡪ࡯ࡸࡰࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ⺱"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺲"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⺳")+name+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⺴")
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭⺵"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⺶"),url)
	return
l11l1l_l1_ (u"ࠥࠦࠧࠐࡤࡦࡨࠣࡔࡑࡇ࡙ࡠࡑࡏࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎࡪࡡࡵࡣࠣࡁࠥࢁࠧࡗ࡫ࡨࡻࠬࡀ࠱ࡾࠌࠌ࡬ࡪࡧࡤࡦࡴࡶࠤࡂࠦࡻࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ࠻ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨࡿࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࠬࡖࡏࡔࡖࠪ࠰ࡺࡸ࡬࠭ࡦࡤࡸࡦ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡ࡝ࡠࠎࠎࠩࠠࡸࡣࡷࡧ࡭ࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡽࡡࡵࡥ࡫ࡅࡷ࡫ࡡࡎࡣࡶࡸࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠱ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡼࡧࡴࡤࡪࠪࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠦࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࡬ࡪࡰ࡮ࡷࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡪ࡯࡯ࡹ࡯ࡳࡦࡪ࠭ࡴࡧࡵࡺࡪࡸࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡵࡨࡶ࠲ࡴࡡ࡮ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡂࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡸ࡮ࡺ࡬ࡦ࠮ࡴࡹࡦࡲࡩࡵࡻ࠯ࡰ࡮ࡴ࡫ࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠ࡭࡫ࡱ࡯࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡰࠪ࠰ࠬ࠭ࠩࠋࠋࠌࠍࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠭ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ࠰ࡺࡩࡵ࡮ࡨ࠯ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ࠮ࠫࡤࡥ࡟ࡠࠩ࠮ࡵࡺࡧ࡬ࡪࡶࡼࠎࠎࠏࠉ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠬࠎࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩ࠾࠿࠳࠾ࠥࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࠱࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ํࠠโ์า๎ํ࠭ࠩࠋࠋࡨࡰࡸ࡫࠺ࠋࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠐࠉࠊࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠲ࡕࡒࡁ࡚ࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠱࠭ࡶࡪࡦࡨࡳࠬ࠲ࡵࡳ࡮ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠨࠢࠣ⺷")
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ⺸"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭⺹"): return
	search = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ⺺"),l11l1l_l1_ (u"ࠧ࠮ࠩ⺻"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ⺼")+search+l11l1l_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ⺽")
	l1lllll_l1_(url)
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪị")
def MAIN(mode,url):
	if   mode==330: results = l11l1ll11l_l1_()
	elif mode==331: results = PLAY(url)
	elif mode==332: results = l11l111l11_l1_()
	elif mode==333: results = l111ll11ll_l1_()
	elif mode==334: results = l1l1llll11_l1_(url)
	else: results = False
	return results
def l1l1llll11_l1_(l11l11l11l_l1_):
	try: os.remove(l11l11l11l_l1_.decode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧỌ")))
	except: os.remove(l11l11l11l_l1_)
	return
def PLAY(url):
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩọ"))
	return
def l111ll11ll_l1_():
	message = l11l1l_l1_ (u"ࠫศึ็ษࠢศ่๎ࠦัศสฺࠤฬ๊แ๋ัํ์ࠥษ่ࠡษ็ูํะࠠโ์ࠣห้๋่ใ฻ࠣห้๋ืๅ๊หࠤะ๋ࠠฤุ฽฻ࠥ฿ไ๊ࠢีีࠥอไใษษ้ฮࠦวๅ์่๎๋ࠦหๆࠢฦาฯอัࠡࠤอั๊๐ไࠡ็็ๅฬะࠠโ์า๎ํࠨࠠฬ็ࠣหำะวาࠢาๆฮࠦวๅื๋ีฮ่ࠦศะอหึࠦๆ้฻้้ࠣ็ࠠศๆุ์ึฯ้ࠠส฼ำ์อࠠิ๊ไࠤ๏ฮฯฤࠢส่ฯำๅ๋ๆࠪỎ")
	DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ỏ"),l11l1l_l1_ (u"࠭ࠧỐ"),l11l1l_l1_ (u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ố"),message)
	return
def l11l1ll11l_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ồ"),l11l1l_l1_ (u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧồ"),l11l1l_l1_ (u"ࠪࠫỔ"),333)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩổ"),l11l1l_l1_ (u"ࠬะฺ๋์ิࠤ๊้ว็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬỖ"),l11l1l_l1_ (u"࠭ࠧỗ"),332)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬỘ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨộ"),l11l1l_l1_ (u"ࠩࠪỚ"),9999)
	l11l11llll_l1_ = l11l1111l1_l1_()
	mtime = os.stat(l11l11llll_l1_).st_mtime
	files = []
	if kodi_version>18.99: l11l11lll1_l1_ = os.listdir(l11l11llll_l1_.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨớ")))
	else: l11l11lll1_l1_ = os.listdir(l11l11llll_l1_.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩỜ")))
	for filename in l11l11lll1_l1_:
		if kodi_version>18.99: filename = filename.decode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪờ"))
		if not filename.startswith(l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡨࡣࠬỞ")): continue
		filepath = os.path.join(l11l11llll_l1_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11l1l1l1l_l1_
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		if kodi_version<19:
			try: filename = filename.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬở"))
			except: pass
			filename = filename.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭Ỡ"))
		filepath = os.path.join(l11l11llll_l1_,filename)
		addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨỡ"),filename,filepath,331)
	return
def l11l1111l1_l1_():
	l11l11llll_l1_ = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭Ợ"))
	if l11l11llll_l1_: return l11l11llll_l1_
	settings.setSetting(l11l1l_l1_ (u"ࠫࡦࡼ࠮ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧợ"),addoncachefolder)
	return addoncachefolder
def l11l111l11_l1_():
	l11l11llll_l1_ = l11l1111l1_l1_()
	l111lll1l1_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬỤ"),l11l1l_l1_ (u"࠭ࠧụ"),l11l1l_l1_ (u"ࠧࠨỦ"),l11l11llll_l1_,l11l1l_l1_ (u"ࠨ้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬủ"))
	if l111lll1l1_l1_==1:
		newpath = l11l111ll1_l1_(3,l11l1l_l1_ (u"่ࠩ็ฬ์ࠠหฯ่๎้ࠦๅๅใสฮࠥอไโ์า๎ํ࠭Ứ"),l11l1l_l1_ (u"ࠪࡰࡴࡩࡡ࡭ࠩứ"),l11l1l_l1_ (u"ࠫࠬỪ"),False,True,l11l11llll_l1_)
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬừ"),l11l1l_l1_ (u"࠭ࠧỬ"),l11l1l_l1_ (u"ࠧࠨử"),newpath,l11l1l_l1_ (u"ࠨ้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬỮ"))
		if l1ll111111_l1_==1:
			settings.setSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬữ"),newpath)
			DIALOG_OK(l11l1l_l1_ (u"ࠪࠫỰ"),l11l1l_l1_ (u"ࠫࠬự"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨỲ"),l11l1l_l1_ (u"࠭สๆࠢอ฾๏๐ัࠡ็ๆห๋ࠦสฯิํ๊ࠥอไๆๆไหฯࠦวๅ็ะ้้ฯࠧỳ"))
	#if not l111lll1l1_l1_ or not l1ll111111_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨỴ"),l11l1l_l1_ (u"ࠨࠩỵ"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬỶ"),l11l1l_l1_ (u"ࠪฮ๊ࠦวๅ฼สลࠥอไฺ็็๎ฮ࠭ỷ"))
	return
def l11l111l1l_l1_(filename):
	l11l1ll111_l1_ = l11l1l_l1_ (u"ࠫࠬỸ").join(l11l1l1ll1_l1_ for l11l1l1ll1_l1_ in filename if l11l1l1ll1_l1_ not in l11l1l_l1_ (u"ࠬࡢ࠯ࠣ࠼࠭ࡃࡁࡄࡼࠨỹ")+half_triangular_colon)
	return l11l1ll111_l1_
def l11l11111l_l1_(url,l111ll1111_l1_=l11l1l_l1_ (u"࠭ࠧỺ"),l1l11lll_l1_=l11l1l_l1_ (u"ࠧࠨỻ")):
	#l1llll1l_l1_(l11l1l_l1_ (u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨỼ"),l11l1l_l1_ (u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩỽ"))
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪỾ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫỿ")+url+l11l1l_l1_ (u"ࠬࠦ࡝ࠨἀ"))
	if not l111ll1111_l1_: l111ll1111_l1_ = l11l1l11l1_l1_(url,l1l11lll_l1_)
	#if not l111ll1111_l1_:
	#	DIALOG_OK(l11l1l_l1_ (u"࠭ࠧἁ"),l11l1l_l1_ (u"ࠧࠨἂ"),l11l1l_l1_ (u"ࠨฬ้ึ๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬἃ"),l11l1l_l1_ (u"ࠩส่๊๊แࠡ็้ࠤ๋๎ูࠡࠩἄ")+l111ll1111_l1_+l11l1l_l1_ (u"ࠪࠤํอไษำ้ห๊าࠠฮษ็๎ฬฺ๋ࠦำࠣะฬําࠡๆอั๊๐ไ้ࠡำหࠥอไ็๊฼ࠤ๊์ࠠศๆ่่ๆอสࠨἅ"))
	#	LOG_THIS(l11l1l_l1_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩἆ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡵࡻࡳࡩ࠴࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࠡ࡫ࡶࠤࡳࡵࡴࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧἇ")+url+l11l1l_l1_ (u"࠭ࠠ࡞ࠩἈ"))
	#	return False
	l11l11llll_l1_ = l11l1111l1_l1_()
	l11l1l11ll_l1_ = l11l11ll11_l1_()
	filename = l11l1l11ll_l1_.replace(l11l1l_l1_ (u"ࠧࠡࠩἉ"),l11l1l_l1_ (u"ࠨࡡࠪἊ"))
	filename = l11l111l1l_l1_(filename)
	#l111ll1111_l1_ = l111ll1111_l1_.encode(l11l1l_l1_ (u"ࠩࡸࡸ࡫࠾ࠧἋ"))
	filename = l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡥࡠࠩἌ")+str(int(now))[-4:]+l11l1l_l1_ (u"ࠫࡤ࠭Ἅ")+filename+l111ll1111_l1_
	l111ll1l11_l1_ = os.path.join(l11l11llll_l1_,filename)
	headers = {}
	headers[l11l1l_l1_ (u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧἎ")] = l11l1l_l1_ (u"࠭ࠧἏ")
	headers[l11l1l_l1_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧἐ")] = l11l1l_l1_ (u"ࠨࠬ࠲࠮ࠬἑ")
	url = url.replace(l11l1l_l1_ (u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬἒ"),l11l1l_l1_ (u"ࠪࠫἓ"))
	if l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩἔ") in url:
		l111l1l_l1_,l111ll111l_l1_ = url.rsplit(l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪἕ"),1)
		l111ll111l_l1_ = l111ll111l_l1_.replace(l11l1l_l1_ (u"࠭ࡼࠨ἖"),l11l1l_l1_ (u"ࠧࠨ἗")).replace(l11l1l_l1_ (u"ࠨࠨࠪἘ"),l11l1l_l1_ (u"ࠩࠪἙ"))
	else: l111l1l_l1_,l111ll111l_l1_ = url,None
	if not l111ll111l_l1_: l111ll111l_l1_ = l11llll11_l1_()
	if l111ll111l_l1_: headers[l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧἚ")] = l111ll111l_l1_
	if l11l1l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭Ἓ") in l111l1l_l1_: l111l1l_l1_,l111llll1l_l1_ = l111l1l_l1_.rsplit(l11l1l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷࡃࠧἜ"),1)
	else: l111l1l_l1_,l111llll1l_l1_ = l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧἝ")
	l111l1l_l1_ = l111l1l_l1_.strip(l11l1l_l1_ (u"ࠧࡽࠩ἞")).strip(l11l1l_l1_ (u"ࠨࠨࠪ἟")).strip(l11l1l_l1_ (u"ࠩࡿࠫἠ")).strip(l11l1l_l1_ (u"ࠪࠪࠬἡ"))
	l111llll1l_l1_ = l111llll1l_l1_.replace(l11l1l_l1_ (u"ࠫࢁ࠭ἢ"),l11l1l_l1_ (u"ࠬ࠭ἣ")).replace(l11l1l_l1_ (u"࠭ࠦࠨἤ"),l11l1l_l1_ (u"ࠧࠨἥ"))
	if l111llll1l_l1_:	headers[l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩἦ")] = l111llll1l_l1_
	LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩἧ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫἨ")+l111l1l_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧἩ")+str(headers)+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬἪ")+l111ll1l11_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩἫ"))
	l11l1ll1l1_l1_ = 1024*1024
	l11l1l111l_l1_ = 0
	try:
		l11l1l1111_l1_ =	xbmc.getInfoLabel(l11l1l_l1_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪἬ"))
		l11l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡞ࡧ࠯ࠬἭ"),l11l1l1111_l1_)
		l11l1l111l_l1_ = int(l11l1l1111_l1_[0])
	except: pass
	if not l11l1l111l_l1_:
		try:
			l11l11l1l1_l1_ = os.l111l1llll_l1_(l11l11llll_l1_)
			l11l1l111l_l1_ = l11l11l1l1_l1_.f_frsize*l11l11l1l1_l1_.f_bavail//l11l1ll1l1_l1_
		except: pass
	if not l11l1l111l_l1_:
		try:
			l11l11l1l1_l1_ = os.l11l1l1lll_l1_(l11l11llll_l1_)
			l11l1l111l_l1_ = l11l11l1l1_l1_.f_frsize*l11l11l1l1_l1_.f_bavail//l11l1ll1l1_l1_
		except: pass
	if not l11l1l111l_l1_:
		try:
			import shutil
			total,l11l1111ll_l1_,l11l111111_l1_ = shutil.l11l1lll1l_l1_(l11l11llll_l1_)
			l11l1l111l_l1_ = l11l111111_l1_//l11l1ll1l1_l1_
		except: pass
	if not l11l1l111l_l1_:
		l11l1llll1_l1_(l11l1l_l1_ (u"ࠩࡵ࡭࡬࡮ࡴࠨἮ"),l11l1l_l1_ (u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪἯ"),l11l1l_l1_ (u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨἰ"),l11l1l_l1_ (u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨἱ"))
		LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫἲ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࡙ࠧࠡࠢࠣࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡷ࡬ࡪࠦࡤࡪࡵ࡮ࠤ࡫ࡸࡥࡦࠢࡶࡴࡦࡩࡥࠨἳ"))
		return False
	import requests
	if l111ll1111_l1_==l11l1l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧἴ"):
		l1ll1ll1_l1_,l1lll1_l1_ = l11l1ll1ll_l1_(l111l1l_l1_,headers)
		#DIALOG_SELECT(l11l1l_l1_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧἵ"), l1ll1ll1_l1_)
		#DIALOG_SELECT(l11l1l_l1_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨἶ"), l1lll1_l1_)
		if len(l1ll1ll1_l1_)==0:
			l1llll1l_l1_(l11l1l_l1_ (u"ࠫๆฺไࠡใํࠤส๐ฬศั้้ࠣ็ࠠศๆอั๊๐ไࠨἷ"),l11l1l_l1_ (u"ࠬ࠭Ἰ"))
			return False
		elif len(l1ll1ll1_l1_)==1: l1l_l1_ = 0
		elif len(l1ll1ll1_l1_)>1:
			l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫἹ"), l1ll1ll1_l1_)
			if l1l_l1_ == -1 :
				l1llll1l_l1_(l11l1l_l1_ (u"ࠧห็ࠣษ้เวยࠢส่ฯำๅ๋ๆࠪἺ"),l11l1l_l1_ (u"ࠨࠩἻ"))
				return False
		l111l1l_l1_ = l1lll1_l1_[l1l_l1_]
	filesize = 0
	if l111ll1111_l1_==l11l1l_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨἼ"):
		l111ll1l11_l1_ = l111ll1l11_l1_.rsplit(l11l1l_l1_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩἽ"))[0]+l11l1l_l1_ (u"ࠫ࠳ࡳࡰ࠵ࠩἾ")
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩἿ"),l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧὀ"),headers,l11l1l_l1_ (u"ࠧࠨὁ"),l11l1l_l1_ (u"ࠨࠩὂ"),l11l1l_l1_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ࠱ࡉࡕࡗࡏࡎࡒࡅࡉࡥࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩὃ"))
		l1lll1l1l_l1_ = response.content
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡠࠨࡋࡘࡕࡋࡑࡊ࠿࠴ࠪࡀ࡝࡟ࡲࡡࡸ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬὄ"),l1lll1l1l_l1_+l11l1l_l1_ (u"ࠫࡡࡴ࡜ࡳࠩὅ"),re.DOTALL)
		if not l1l1_l1_:
			LOG_THIS(l11l1l_l1_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ὆"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡗ࡬ࡪࠦ࡭࠴ࡷ࠻ࠤ࡫࡯࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣ࡬ࡦࡼࡥࠡࡶ࡫ࡩࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠ࡭࡫ࡱ࡯ࡸࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ὇")+l111l1l_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪὈ"))
			return False
		l1llll1_l1_ = l1l1_l1_[0]
		if not l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭Ὁ")):
			if l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠩ࠲࠳ࠬὊ")): l1llll1_l1_ = l111l1l_l1_.split(l11l1l_l1_ (u"ࠪ࠾ࠬὋ"),1)[0]+l11l1l_l1_ (u"ࠫ࠿࠭Ὄ")+l1llll1_l1_
			elif l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠬ࠵ࠧὍ")): l1llll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ὎"))+l1llll1_l1_
			else: l1llll1_l1_ = l111l1l_l1_.rsplit(l11l1l_l1_ (u"ࠧ࠰ࠩ὏"),1)[0]+l11l1l_l1_ (u"ࠨ࠱ࠪὐ")+l1llll1_l1_
		response = requests.request(l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ὑ"),l1llll1_l1_,headers=headers,verify=False)
		chunk = response.content
		chunksize = len(chunk)
		l111llllll_l1_ = len(l1l1_l1_)
		filesize = chunksize*l111llllll_l1_
	else:
		chunksize = 1*l11l1ll1l1_l1_
		response = requests.request(l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧὒ"),l111l1l_l1_,headers=headers,verify=False,stream=True)
		if l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬὓ") in response.headers: filesize = int(response.headers[l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ὔ")])
		l111llllll_l1_ = int(filesize//chunksize)
	#l11l1l1l11_l1_ = l111llllll_l1_+1
	l11l1l1l11_l1_ = int(filesize//l11l1ll1l1_l1_)+1
	if filesize<21000:
		LOG_THIS(l11l1l_l1_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫὕ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡸࡴࡵࠠࡴ࡯ࡤࡰࡱࠦ࡯ࡳࠢ࡬ࡸࠥ࡯ࡳࠡ࡯࠶ࡹ࠽ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩὖ")+l111l1l_l1_+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬὗ")+str(l11l1l1l11_l1_)+l11l1l_l1_ (u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ὘")+str(l11l1l111l_l1_)+l11l1l_l1_ (u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭Ὑ")+l111ll1l11_l1_+l11l1l_l1_ (u"ࠫࠥࡣࠧ὚"))
		DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭Ὓ"),l11l1l_l1_ (u"࠭ࠧ὜"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪὝ"),l11l1l_l1_ (u"ࠨใื่ࠥ็๊ࠡ็฼ีๆฯࠠฮฮ่ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢฦ์ࠥอไๆๆไࠤฺเ๊าࠢฯำฬ่ࠦๅ้ำห๊ࠥวࠡ์่็๋ࠦไๅสิ๊ฬ๋ฬࠡฬะ้๏๊่ࠠาสࠤฬ๊ๅๅใࠪ὞"))
		return False
	l111llll11_l1_ = 400
	l111ll1lll_l1_ = l11l1l111l_l1_-l11l1l1l11_l1_
	if l111ll1lll_l1_<l111llll11_l1_:
		LOG_THIS(l11l1l_l1_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧὟ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠪࠤࠥࠦࡎࡰࡶࠣࡩࡳࡵࡵࡨࡪࠣࡨ࡮ࡹ࡫ࠡࡵࡳࡥࡨ࡫ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩὠ")+l111l1l_l1_+l11l1l_l1_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨὡ")+str(l11l1l1l11_l1_)+l11l1l_l1_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫὢ")+str(l11l1l111l_l1_)+l11l1l_l1_ (u"࠭ࠠࡎࡄࠣ࠱ࠥ࠭ὣ")+str(l111llll11_l1_)+l11l1l_l1_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪὤ")+l111ll1l11_l1_+l11l1l_l1_ (u"ࠨࠢࡠࠫὥ"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪὦ"),l11l1l_l1_ (u"ࠪࠫὧ"),l11l1l_l1_ (u"้ࠫอ๋๊ࠠฯำ๋ࠥำศฯฬࠤ่อแ๋ห่้ࠣะอๆ์็ࠫὨ"),l11l1l_l1_ (u"ࠬอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥะอๆ์็๋ࠥำฬๆ้ࠣࠫὩ")+str(l11l1l1l11_l1_)+l11l1l_l1_ (u"࠭ࠠๆ์฽หออ๊ห๋ࠢะ์อาไࠢไ๎์ࠦๅิษะอࠥ็วา฼ฬࠤࠬὪ")+str(l11l1l111l_l1_)+l11l1l_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์้๊ๅฮษไ฼ฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศะ๊้ࠤฺ๊วไๆࠣ๎ัฮࠠฦสๅหฦࠦࠧὫ")+str(l111llll11_l1_)+l11l1l_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦร็ࠢฯ๋ฬุใࠡๆสࠤฯ๎ฬะࠢไ๎์ࠦๅิษะอ้ࠥวโ์ฬࠤ้ะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้สࠪὬ"))
		return False
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩὭ"),l11l1l_l1_ (u"ࠪࠫὮ"),l11l1l_l1_ (u"ࠫࠬὯ"),l11l1l_l1_ (u"ࠬํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฤ࠭ὰ"),l11l1l_l1_ (u"࠭วๅ็็ๅࠥอไๆู็์อࠦออ็๊ࠤฯ่ั๋สสࠤࠬά")+str(l11l1l1l11_l1_)+l11l1l_l1_ (u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อࠥะโา์หหࠥ࠭ὲ")+str(l11l1l111l_l1_)+l11l1l_l1_ (u"ࠨ่ࠢ๎฿อศศ์อࠤํํะศࠢส่๊๊แࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦไๅฬะ้๏๊ࠠๆ่ࠣห้หๆหำ้ฮࠥหไ๊ࠢฯ๋ฬุใࠡ࠰๋้ࠣࠦว็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡษ็หุะๅาษิࠤอะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢยࠫέ"))
	if l1ll111111_l1_!=1:
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪὴ"),l11l1l_l1_ (u"ࠪࠫή"),l11l1l_l1_ (u"ࠫࠬὶ"),l11l1l_l1_ (u"ࠬะๅࠡว็฾ฬวฺࠠ็็๎ฮࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪί"))
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ὸ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡴࡨࡪࡺࡹࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡳ࡫ࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪό")+l111l1l_l1_+l11l1l_l1_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨὺ")+l111ll1l11_l1_+l11l1l_l1_ (u"ࠩࠣࡡࠬύ"))
		return False
	LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪὼ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡅࡱࡺࡲࡱࡵࡡࡥࠢࡶࡸࡦࡸࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠩώ"))
	l11l11ll1l_l1_ = DIALOG_PROGRESS()
	l11l11ll1l_l1_.create(l111ll1l11_l1_,l11l1l_l1_ (u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭὾"))
	l111lllll1_l1_ = True
	t1 = time.time()
	if kodi_version>18.99: file = open(l111ll1l11_l1_,l11l1l_l1_ (u"࠭ࡷࡣࠩ὿"))
	else: file = open(l111ll1l11_l1_.decode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬᾀ")),l11l1l_l1_ (u"ࠨࡹࡥࠫᾁ"))
	if l111ll1111_l1_==l11l1l_l1_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᾂ"): # l11l1111ll_l1_ for l1lll1l1l_l1_ and l111lll111_l1_ chunks video files such as .l11l11l1ll_l1_
		for l11l1l1ll1_l1_ in range(1,l111llllll_l1_+1):
			l1llll1_l1_ = l1l1_l1_[l11l1l1ll1_l1_-1]
			if not l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨᾃ")):
				if l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠫ࠴࠵ࠧᾄ")): l1llll1_l1_ = l111l1l_l1_.split(l11l1l_l1_ (u"ࠬࡀࠧᾅ"),1)[0]+l11l1l_l1_ (u"࠭࠺ࠨᾆ")+l1llll1_l1_
				elif l1llll1_l1_.startswith(l11l1l_l1_ (u"ࠧ࠰ࠩᾇ")): l1llll1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬᾈ"))+l1llll1_l1_
				else: l1llll1_l1_ = l111l1l_l1_.rsplit(l11l1l_l1_ (u"ࠩ࠲ࠫᾉ"),1)[0]+l11l1l_l1_ (u"ࠪ࠳ࠬᾊ")+l1llll1_l1_
			response = requests.request(l11l1l_l1_ (u"ࠫࡌࡋࡔࠨᾋ"),l1llll1_l1_,headers=headers,verify=False)
			chunk = response.content
			response.close()
			file.write(chunk)
			l111ll1ll1_l1_ = time.time()
			l111ll11l1_l1_ = l111ll1ll1_l1_-t1
			l111ll1l1l_l1_ = l111ll11l1_l1_//l11l1l1ll1_l1_
			l11l111lll_l1_ = l111ll1l1l_l1_*(l111llllll_l1_+1)
			l111lll11l_l1_ = l11l111lll_l1_-l111ll11l1_l1_
			PROGRESS_UPDATE(l11l11ll1l_l1_,int(100*l11l1l1ll1_l1_//(l111llllll_l1_+1)),l11l1l_l1_ (u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ᾌ"),l11l1l_l1_ (u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭ᾍ"),str(l11l1l1ll1_l1_*chunksize//l11l1ll1l1_l1_)+l11l1l_l1_ (u"ࠧ࠰ࠩᾎ")+str(l11l1l1l11_l1_)+l11l1l_l1_ (u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭ᾏ")+time.strftime(l11l1l_l1_ (u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦᾐ"),time.gmtime(l111lll11l_l1_))+l11l1l_l1_ (u"ࠪࠤๅ࠭ᾑ"))
			if l11l11ll1l_l1_.iscanceled():
				l111lllll1_l1_ = False
				break
	else: # l11111l1_l1_ and other l11l11l111_l1_ file l11l1lll11_l1_
		l11l1l1ll1_l1_ = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			l11l1l1ll1_l1_ = l11l1l1ll1_l1_+1
			l111ll1ll1_l1_ = time.time()
			l111ll11l1_l1_ = l111ll1ll1_l1_-t1
			l111ll1l1l_l1_ = l111ll11l1_l1_/l11l1l1ll1_l1_
			l11l111lll_l1_ = l111ll1l1l_l1_*(l111llllll_l1_+1)
			l111lll11l_l1_ = l11l111lll_l1_-l111ll11l1_l1_
			PROGRESS_UPDATE(l11l11ll1l_l1_,int(100*l11l1l1ll1_l1_/(l111llllll_l1_+1)),l11l1l_l1_ (u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬᾒ"),l11l1l_l1_ (u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬᾓ"),str(l11l1l1ll1_l1_*chunksize//l11l1ll1l1_l1_)+l11l1l_l1_ (u"࠭࠯ࠨᾔ")+str(l11l1l1l11_l1_)+l11l1l_l1_ (u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬᾕ")+time.strftime(l11l1l_l1_ (u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᾖ"),time.gmtime(l111lll11l_l1_))+l11l1l_l1_ (u"ࠩࠣไࠬᾗ"))
			if l11l11ll1l_l1_.iscanceled():
				l111lllll1_l1_ = False
				break
		response.close()
	file.close()
	l11l11ll1l_l1_.close()
	if not l111lllll1_l1_:
		LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᾘ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪ࠯ࡪࡰࡷࡩࡷࡸࡵࡱࡶࡨࡨࠥࡺࡨࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡵࡸ࡯ࡤࡧࡶࡷࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᾙ")+l111l1l_l1_+l11l1l_l1_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᾚ")+l111ll1l11_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩᾛ"))
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨᾜ"),l11l1l_l1_ (u"ࠨࠩᾝ"),l11l1l_l1_ (u"ࠩࠪᾞ"),l11l1l_l1_ (u"ࠪฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᾟ"))
		return True
	LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᾠ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᾡ")+l111l1l_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ᾢ")+l111ll1l11_l1_+l11l1l_l1_ (u"ࠧࠡ࡟ࠪᾣ"))
	DIALOG_OK(l11l1l_l1_ (u"ࠨࠩᾤ"),l11l1l_l1_ (u"ࠩࠪᾥ"),l11l1l_l1_ (u"ࠪࠫᾦ"),l11l1l_l1_ (u"ࠫฯ๋ࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤอ์ฬศฯࠪᾧ"))
	return True
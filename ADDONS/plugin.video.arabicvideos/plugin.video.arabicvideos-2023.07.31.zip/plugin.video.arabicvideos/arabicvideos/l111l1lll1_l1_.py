# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ᾨ")
l1111l_l1_ = l11l1l_l1_ (u"࠭࡟ࡅࡔ࠺ࡣࠬᾩ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩᾪ"),l11l1l_l1_ (u"ࠨࡕ࡬࡫ࡳࠦࡩ࡯ࠩᾫ"),l11l1l_l1_ (u"ࠩอืั๐ไࠨᾬ")]
def MAIN(mode,url,text):
	if   mode==680: results = MENU()
	elif mode==681: results = l1lllll_l1_(url,text)
	elif mode==682: results = PLAY(url)
	elif mode==683: results = l1111_l1_(url,text)
	elif mode==684: results = l11lll_l1_(url)
	elif mode==689: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᾭ"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬᾮ"),l11l1l_l1_ (u"ࠬ࠭ᾯ"),l11l1l_l1_ (u"࠭ࠧᾰ"),l11l1l_l1_ (u"ࠧࠨᾱ"),l11l1l_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᾲ"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᾳ"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪᾴ"),l11l1l_l1_ (u"ࠫࠬ᾵"),689,l11l1l_l1_ (u"ࠬ࠭ᾶ"),l11l1l_l1_ (u"࠭ࠧᾷ"),l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᾸ"))
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ᾱ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᾺ"),l11l1l_l1_ (u"ࠪࠫΆ"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᾼ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ᾽")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็่๎ืฯࠧι"),l11l11_l1_,681,l11l1l_l1_ (u"ࠧࠨ᾿"),l11l1l_l1_ (u"ࠨࠩ῀"),l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ῁"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῂ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ῃ")+l1111l_l1_+l11l1l_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫῄ"),l11l11_l1_,681,l11l1l_l1_ (u"࠭ࠧ῅"),l11l1l_l1_ (u"ࠧࠨῆ"),l11l1l_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬῇ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩῈ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬΈ")+l1111l_l1_+l11l1l_l1_ (u"ࠫัี๊ะࠢส่า๊โศฬࠪῊ"),l11l11_l1_,681,l11l1l_l1_ (u"ࠬ࠭Ή"),l11l1l_l1_ (u"࠭ࠧῌ"),l11l1l_l1_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭῍"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ῎"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ῏")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ำๅี็หฯࠦวๅ็่๎ืฯࠧῐ"),l11l11_l1_,681,l11l1l_l1_ (u"ࠫࠬῑ"),l11l1l_l1_ (u"ࠬ࠭ῒ"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨΐ"))
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ῔"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ῕"),l11l1l_l1_ (u"ࠩࠪῖ"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡷࡳࡣࡳࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨῗ"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬῘ"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬῙ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨῚ")+l1111l_l1_+title,l1llll1_l1_,684)
	#addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬΊ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ῜"),l11l1l_l1_ (u"ࠩࠪ῝"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠴ࡰࡩࡲࠥࡂ࠭࠴ࠪࡀࠫࠥࡲࡦࡼࡳ࡭࡫ࡧࡩ࠲ࡪࡩࡷ࡫ࡧࡩࡷࠨࠧ῞"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠦࠬࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹࠬ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠤ῟"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠬ࠭ῠ"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫῡ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧῢ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪΰ")+l1111l_l1_+title,l1llll1_l1_,684)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ῤ"),url,l11l1l_l1_ (u"ࠪࠫῥ"),l11l1l_l1_ (u"ࠫࠬῦ"),l11l1l_l1_ (u"ࠬ࠭ῧ"),l11l1l_l1_ (u"࠭ࠧῨ"),l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭Ῡ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬῪ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠩࠥࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࠤࠪΎ"),l11l1l_l1_ (u"ࠪࡀ࠴ࡻ࡬࠿ࠩῬ"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭ࡩࡧࡤࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ῭"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠬ࠭΅"),block)]
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ`"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣๅึุࠠฤ๊ࠣๅ้ะัࠡล๋ࠤฯืส๋สࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ῰"),l11l1l_l1_ (u"ࠨࠩ῱"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧῲ"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠪ࠾ࠥ࠭ῳ")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫῴ"),l1111l_l1_+title,l1llll1_l1_,681)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡰ࡮࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠱ࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ῵"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨῶ"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬῷ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨῸ"),l11l1l_l1_ (u"ࠩࠪΌ"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῺ"),l1111l_l1_+title,l1llll1_l1_,681)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠫࠬΏ")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ῼ"),l11l1l_l1_ (u"࠭ࠧ´"),request,url)
	if request==l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ῾"):
		url,search = url.split(l11l1l_l1_ (u"ࠨࡁࠪ῿"),1)
		data = l11l1l_l1_ (u"ࠩࡴࡹࡪࡸࡹࡔࡶࡵ࡭ࡳ࡭࠽ࠨ ")+search
		headers = {l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ "):l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫ ")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ "),url,data,headers,l11l1l_l1_ (u"࠭ࠧ "),l11l1l_l1_ (u"ࠧࠨ "),l11l1l_l1_ (u"ࠨࡆࡕࡅࡒࡇࡓ࠸࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ "))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ "),url,l11l1l_l1_ (u"ࠪࠫ "),l11l1l_l1_ (u"ࠫࠬ "),l11l1l_l1_ (u"ࠬ࠭ "),l11l1l_l1_ (u"࠭ࠧ​"),l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ‌"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠨࠩ‍"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭‎"))
	if request==l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ‏"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭‐"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠬ࠭‑"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ‒"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡻࡦࡺࡣࡩ࠯ࡩࡩࡦࡺࡵࡳࡧࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ–"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠨࡰࡨࡻࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ—"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡶࡴࡽࠠࡱ࡯࠰ࡹࡱ࠳ࡢࡳࡱࡺࡷࡪ࠳ࡶࡪࡦࡨࡳࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ―"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ‖"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡸ࡯ࡸࠢࡳࡱ࠲ࡻ࡬࠮ࡤࡵࡳࡼࡹࡥ࠮ࡸ࡬ࡨࡪࡵࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ‗"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ‘"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡩࡱࡰࡩ࠲ࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࡜࡞ࡷࢀࡡࡴ࡝ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨ’"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ‚"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠨࠩ‛"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ“"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ”"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠫ„"),l11l1l_l1_ (u"ࠬ็๊ๅ็ࠪ‟"),l11l1l_l1_ (u"࠭ว฻่ํอࠬ†"),l11l1l_l1_ (u"ࠧไๆํฬࠬ‡"),l11l1l_l1_ (u"ࠨษ฼่ฬ์ࠧ•"),l11l1l_l1_ (u"๊ࠩำฬ็ࠧ‣"),l11l1l_l1_ (u"้ࠪออัศหࠪ․"),l11l1l_l1_ (u"ࠫ฾ืึࠨ‥"),l11l1l_l1_ (u"๋ࠬ็าฮส๊ࠬ…"),l11l1l_l1_ (u"࠭วๅส๋้ࠬ‧"),l11l1l_l1_ (u"ࠧๆีิั๏ฯࠧ ")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠨ࠱ࠪ "))
		#if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ‪") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ‫")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭‬"))
		#if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ‭") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࠨ‮")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ "))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ‰"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾะ่็ฯࠩ࠯࡞ࡧ࠯ࠬ‱"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ′"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ″"):
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ‴"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ‵") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ‶"),l1111l_l1_+title,l1llll1_l1_,683,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭‷") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ‸"),l1111l_l1_+title,l1llll1_l1_,681,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ‹"),l1111l_l1_+title,l1llll1_l1_,683,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ›"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ※")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ‼"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ‽"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠨࠥࠪ‾"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ‿")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ⁀"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⁁"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ⁂")+title,l1llll1_l1_,681)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ⁃"),l11l1l_l1_ (u"ࠧࠨ⁄"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ⁅"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭⁆"),url,l11l1l_l1_ (u"ࠪࠫ⁇"),l11l1l_l1_ (u"ࠫࠬ⁈"),l11l1l_l1_ (u"ࠬ࠭⁉"),l11l1l_l1_ (u"࠭ࠧ⁊"),l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ⁋"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡖࡩࡦࡹ࡯࡯ࡵࡅࡳࡽࠨࠨ࠯ࠬࡂ࡙࠭ࠧࡥࡢࡵࡲࡲࡸࡋࡰࡪࡵࡲࡨࡪࡹࡍࡢ࡫ࡱࠫ⁌"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡷࡪࡸࡩࡦࡵ࠰࡬ࡪࡧࡤࡦࡴࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⁍"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠪࠫ⁎")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࠬ࠭࡯࡯ࡥ࡯࡭ࡨࡱ࠽ࠣࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩࠪࠫ⁏"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠬࠩࠧ⁐"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⁑"),l1111l_l1_+title,url,683,l1ll1l_l1_,l11l1l_l1_ (u"ࠧࠨ⁒"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧ࠭⁓")+l1l11_l1_+l11l1l_l1_ (u"ࠩࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ⁔"),html,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠥ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࡀ࠿ࡰ࡮ࡄ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠤ⁕"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		if not items: items = re.findall(l11l1l_l1_ (u"ࠫࠧࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⁖"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ⁗")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ⁘"))
			title = title.replace(l11l1l_l1_ (u"ࠧ࠽࠱ࡨࡱࡃࡂࡳࡱࡣࡱࡂࠬ⁙"),l11l1l_l1_ (u"ࠨࠢࠪ⁚"))
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⁛"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫ⁜"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ⁝") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ⁞")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ "))
		#		addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⁠"),l1111l_l1_+title,l1llll1_l1_,682,l1ll1l_l1_)
	return
def PLAY(url):
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠨࡷࡵࡰࠬ⁡"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭⁢"),url,l11l1l_l1_ (u"ࠪࠫ⁣"),l11l1l_l1_ (u"ࠫࠬ⁤"),l11l1l_l1_ (u"ࠬ࠭⁥"),l11l1l_l1_ (u"࠭ࠧ⁦"),l11l1l_l1_ (u"ࠧࡅࡔࡄࡑࡆ࡙࠷࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ⁧"))
	html = response.content
	# l1ll1ll_l1_ l11lll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⁨"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	l1lll11_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠩࡳࡳࡸࡺ࠽ࠨ⁩"))[1]
	l1lll11_l1_ = base64.b64decode(l1lll11_l1_)
	if kodi_version>18.99: l1lll11_l1_ = l1lll11_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ⁪"))
	l1lll11_l1_ = l1lll11_l1_.replace(l11l1l_l1_ (u"ࠫࡡ࠵ࠧ⁫"),l11l1l_l1_ (u"ࠬ࠵ࠧ⁬"))
	l1lll11_l1_ = EVAL(l11l1l_l1_ (u"࠭ࡤࡪࡥࡷࠫ⁭"),l1lll11_l1_)
	l1l1_l1_ = l1lll11_l1_[l11l1l_l1_ (u"ࠧࡴࡧࡵࡺࡪࡸࡳࠨ⁮")]
	l11ll1_l1_ = list(l1l1_l1_.keys())
	l1l1_l1_ = list(l1l1_l1_.values())
	l11111_l1_ = zip(l11ll1_l1_,l1l1_l1_)
	for title,l1llll1_l1_ in l11111_l1_:
		l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⁯")+title+l11l1l_l1_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ⁰")
		l1lll1_l1_.append(l1llll1_l1_)
	l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࠤ࡫ࡩࠤࡱ࡯࡮࡬ࠢࡤࡲࡩࠦࠧࡩࡶࡷࡴࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠥࡲࡩ࡯࡭ࠣࡁࠥ࠭ࡨࡵࡶࡳ࠾ࠬ࠱࡬ࡪࡰ࡮ࠎࠎ࡮ࡡࡴࡪࠣࡁࠥࡲࡩ࡯࡭࠱ࡷࡵࡲࡩࡵࠪࠪ࡬ࡦࡹࡨ࠾ࠩࠬ࡟࠶ࡣࠊࠊࡲࡤࡶࡹࡹࠠ࠾ࠢ࡫ࡥࡸ࡮࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡠࡡࠪ࠭ࠏࠏ࡮ࡦࡹࡢࡴࡦࡸࡴࡴࠢࡀࠤࡠࡣࠊࠊࡨࡲࡶࠥࡶࡡࡳࡶࠣ࡭ࡳࠦࡰࡢࡴࡷࡷ࠿ࠐࠉࠊࡶࡵࡽ࠿ࠐࠉࠊࠋࡳࡥࡷࡺࠠ࠾ࠢࡥࡥࡸ࡫࠶࠵࠰ࡥ࠺࠹ࡪࡥࡤࡱࡧࡩ࠭ࡶࡡࡳࡶ࠮ࠫࡂ࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠ࡬ࡱࡧ࡭ࡤࡼࡥࡳࡵ࡬ࡳࡳࡄ࠱࠹࠰࠼࠽࠿ࠦࡰࡢࡴࡷࠤࡂࠦࡰࡢࡴࡷ࠲ࡩ࡫ࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࠉࠊࡰࡨࡻࡤࡶࡡࡳࡶࡶ࠲ࡦࡶࡰࡦࡰࡧࠬࡵࡧࡲࡵࠫࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡰࡢࡵࡶࠎࠎࡲࡩ࡯࡭ࡶࠤࡂࠦࠧ࠿ࠩ࠱࡮ࡴ࡯࡮ࠩࡰࡨࡻࡤࡶࡡࡳࡶࡶ࠭ࠏࠏ࡬ࡪࡰ࡮ࡷࠥࡃࠠ࡭࡫ࡱ࡯ࡸ࠴ࡳࡱ࡮࡬ࡸࡱ࡯࡮ࡦࡵࠫ࠭ࠏࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠳ࠢ࡬ࡲࠥࢀࡺࡻ࠼ࠍࠍࠎࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬ࠢࡀࠤࡱ࡯࡮࡬࠴࠱ࡷࡵࡲࡩࡵࠪࠪࠤࡂࡄࠠࠨࠫࠍࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡲࡩ࡯࡭࠮ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ࠱ࡴࡪࡶ࡯ࡩ࠰࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧࠋࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠨࠢࠣⁱ")
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩ⁲"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ⁳"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"࠭ࠧ⁴"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠧࠨ⁵"): return
	search = search.replace(l11l1l_l1_ (u"ࠨࠢࠪ⁶"),l11l1l_l1_ (u"ࠩ࠮ࠫ⁷"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀ࡭ࡨࡽࡼࡵࡲࡥࡵࡀࠫ⁸")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ⁹"))
	#url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫࠲ࡵ࡮ࡰࡀࠩ⁺")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ⁻"))
	return
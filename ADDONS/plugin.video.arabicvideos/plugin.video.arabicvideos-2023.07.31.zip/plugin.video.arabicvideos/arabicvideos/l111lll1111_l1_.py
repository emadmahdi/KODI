# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ䀽")
headers = {l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䀾"):l11l1l_l1_ (u"ࠫࠬ䀿")}
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥࡍࡄࡏࡢࠫ䁀")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"࠭ๅึษิ฽ฮࠦอาหࠪ䁁"),l11l1l_l1_ (u"ࠧࡸࡹࡨࠫ䁂")]
def MAIN(mode,url,text):
	if   mode==360: results = MENU()
	elif mode==361: results = l1lllll_l1_(url,text)
	elif mode==362: results = PLAY(url)
	elif mode==363: results = l1lll1l1_l1_(url,text)
	elif mode==364: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ䁃")+text)
	elif mode==365: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭䁄")+text)
	elif mode==366: results = l11lll_l1_(url)
	elif mode==369: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ䁅"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ䁆"),l11l1l_l1_ (u"ࠬ࠭䁇"),False,l11l1l_l1_ (u"࠭ࠧ䁈"),l11l1l_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䁉"))
	#hostname = response.headers[l11l1l_l1_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ䁊")]
	#hostname = hostname.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ䁋"))
	#l1l1ll1_l1_ = l11l11_l1_
	#url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ䁌")
	#url = l1l1ll1_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䁍"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭䁎"),l11l1l_l1_ (u"࠭ࠧ䁏"),l11l1l_l1_ (u"ࠧࠨ䁐"),l11l1l_l1_ (u"ࠨࠩ䁑"),l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ䁒"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䁓"),l1111l_l1_+l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣ็ัษࠣห้๋่ใ฻้ࠣ฿๊โ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䁔"),l11l1l_l1_ (u"ࠬ࠭䁕"),8)
	#addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䁖"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䁗"),l11l1l_l1_ (u"ࠨࠩ䁘"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䁙"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ䁚"),l11l11_l1_,369,l11l1l_l1_ (u"ࠫࠬ䁛"),l11l1l_l1_ (u"ࠬ࠭䁜"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䁝"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䁞"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ็ฮึࠦๅฮัาࠫ䁟"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ䁠"),364)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁡"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ䁢"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䁣"),365)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ䁤"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䁥"),l11l1l_l1_ (u"ࠨࠩ䁦"),9999)
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ䁧"):hostname,l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ䁨"):l11l1l_l1_ (u"ࠫࠬ䁩")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11l1l_l1_ (u"ࠬࡢ࠯ࠨ䁪"),l11l1l_l1_ (u"࠭࠯ࠨ䁫"))
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡳ࡫ࡪ࡬ࡹࡨࡡࡳࠪ࠱࠮ࡄ࠯ࡦࡪ࡮ࡷࡩࡷ࠭䁬"),html,re.DOTALL)
	#if l1l11l1_l1_:
	#	block = l1l11l1_l1_[0]
	#	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁭"),block,re.DOTALL)
	#	for l1llll1_l1_,title in items:
	#		if l11l1l_l1_ (u"ࠩࠨࡨ࠾ࠫ࠸࠶ࠧࡧ࠼ࠪࡨ࠵ࠦࡦ࠻ࠩࡦ࠽ࠥࡥ࠺ࠨࡦ࠶ࠫࡤ࠹ࠧࡥ࠽ࠪࡪ࠸ࠦࡣ࠼࠱ࠪࡪ࠸ࠦࡣࡧࠩࡩ࠾ࠥࡣ࠳ࠨࡨ࠽ࠫࡡ࠺ࠩ䁮") in l1llll1_l1_: continue
	#		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䁯"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䁰")+l1111l_l1_+title,l1llll1_l1_,366)
	#	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䁱"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䁲"),l11l1l_l1_ (u"ࠧࠨ䁳"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䁴"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ䁵"),l11l1l_l1_ (u"ࠪࠫ䁶"),l11l1l_l1_ (u"ࠫࠬ䁷"),l11l1l_l1_ (u"ࠬ࠭䁸"),l11l1l_l1_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ䁹"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡏࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡑࡪࡴࡵࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡐࡳࡱࡧࡹࡨࡺࡩࡰࡰࡶࡐ࡮ࡹࡴࡃࡷࡷࡸࡴࡴࠢࠨ䁺"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䁻"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䁼") not in l1llll1_l1_:
			#	server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ䁽"))
			#	l1llll1_l1_ = l1llll1_l1_.replace(server,l1l1ll1_l1_)
			if title==l11l1l_l1_ (u"ࠫࠬ䁾"): continue
			if any(value in title.lower() for value in l1l111_l1_): continue
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䁿"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䂀")+l1111l_l1_+title,l1llll1_l1_,366)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䂁"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䂂"),l11l1l_l1_ (u"ࠩࠪ䂃"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡴࡼࡥࡳࡣࡥࡰࡪࠦࡡࡤࡶ࡬ࡺࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩࠬ䂄"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬ࠲࠯ࡅࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䂅"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂆"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䂇")+l1111l_l1_+title,l1llll1_l1_,366,l1ll1l_l1_)
	return html
def l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䂈"),l11l1l_l1_ (u"ࠨࠩ䂉"),url,l11l1l_l1_ (u"ࠩࠪ䂊"))
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ䂋"):url,l11l1l_l1_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䂌"):l11l1l_l1_ (u"ࠬ࠭䂍")}
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ䂎"),url,l11l1l_l1_ (u"ࠧࠨ䂏"),l11l1l_l1_ (u"ࠨࠩ䂐"),l11l1l_l1_ (u"ࠩࠪ䂑"),l11l1l_l1_ (u"ࠪࠫ䂒"),l11l1l_l1_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱ࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䂓"))
	html = response.content
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂔"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠤ๊ำฯะࠩ䂕"),url,364)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䂖"),l1111l_l1_+l11l1l_l1_ (u"ࠨใ็ฮึࠦใศ็็ࠫ䂗"),url,365)
	if l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡖࡰ࡮ࡪࡥࡳ࠯࠰ࡋࡷ࡯ࡤࠣࠩ䂘") in html:
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂙"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬ䂚"),url,361,l11l1l_l1_ (u"ࠬ࠭䂛"),l11l1l_l1_ (u"࠭ࠧ䂜"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ䂝"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ䂞"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡀࠬ䂟"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂠"),l1111l_l1_+title,l1llll1_l1_,361)
	return
def l1lllll_l1_(l111lll111l_l1_,type=l11l1l_l1_ (u"ࠫࠬ䂡")):
	if l11l1l_l1_ (u"ࠬࡀ࠺ࠨ䂢") in l111lll111l_l1_:
		l111ll1_l1_,url = l111lll111l_l1_.split(l11l1l_l1_ (u"࠭࠺࠻ࠩ䂣"))
		server = SERVER(l111ll1_l1_,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ䂤"))
		url = server+url
	else: url,l111ll1_l1_ = l111lll111l_l1_,l111lll111l_l1_
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ䂥"):l111ll1_l1_,l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䂦"):l11l1l_l1_ (u"ࠪࠫ䂧")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䂨"),url,l11l1l_l1_ (u"ࠬ࠭䂩"),l11l1l_l1_ (u"࠭ࠧ䂪"),l11l1l_l1_ (u"ࠧࠨ䂫"),l11l1l_l1_ (u"ࠨࠩ䂬"),l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭䂭"))
	html = response.content
	if type==l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ䂮"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡘࡲࡩࡥࡧࡵ࠱࠲ࡍࡲࡪࡦࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡮࡬ࡷࡹ࠳࠭ࡕࡣࡥࡷࡺ࡯ࠢࠨ䂯"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䂰"):
		l1l11l1_l1_ = [html.replace(l11l1l_l1_ (u"࠭࡜࡝࠱ࠪ䂱"),l11l1l_l1_ (u"ࠧ࠰ࠩ䂲")).replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠦࠬ䂳"),l11l1l_l1_ (u"ࠩࠥࠫ䂴"))]
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡋࡷ࡯ࡤ࠮࠯ࡐࡽࡨ࡯࡭ࡢࡒࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࡀ࠴ࡻ࡬࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧ䂵"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡌࡸࡩࡥࡋࡷࡩࡲࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ䂶"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l1l111_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11l1l_l1_ (u"๋ࠬิศ้าอࠥ࠭䂷"),l11l1l_l1_ (u"࠭ࠧ䂸"))
			if l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ䂹") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䂺"),l1111l_l1_+title,l1llll1_l1_,363,l1ll1l_l1_)
			elif l11l1l_l1_ (u"ࠩะ่็ฯࠧ䂻") in title:
				l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢ࠮ั้่ษࠡ࠭࡟ࡨ࠰࠭䂼"),title,re.DOTALL)
				if l1ll11l_l1_: title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䂽") + l1ll11l_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䂾"),l1111l_l1_+title,l1llll1_l1_,363,l1ll1l_l1_)
			else:
				addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䂿"),l1111l_l1_+title,l1llll1_l1_,362,l1ll1l_l1_)
		if type==l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䃀"):
			l1ll11ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡰࡳࡷ࡫࡟ࡣࡷࡷࡸࡴࡴ࡟ࡱࡣࡪࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠭䃁"),block,re.DOTALL)
			if l1ll11ll111_l1_:
				count = l1ll11ll111_l1_[0]
				l1llll1_l1_ = url+l11l1l_l1_ (u"ࠩ࠲ࡳ࡫࡬ࡳࡦࡶ࠲ࠫ䃂")+count
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃃"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢฦาึ๏ࠧ䃄"),l1llll1_l1_,361,l11l1l_l1_ (u"ࠬ࠭䃅"),l11l1l_l1_ (u"࠭ࠧ䃆"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䃇"))
		elif type==l11l1l_l1_ (u"ࠨࠩ䃈"):
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ䃉"),html,re.DOTALL)
			if l1l11l1_l1_:
				block = l1l11l1_l1_[0]
				items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䃊"),block,re.DOTALL)
				for l1llll1_l1_,title in items:
					title = l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ䃋")+unescapeHTML(title)
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䃌"),l1111l_l1_+title,l1llll1_l1_,361)
	return
def l1lll1l1_l1_(url,type=l11l1l_l1_ (u"࠭ࠧ䃍")):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䃎"),url,l11l1l_l1_ (u"ࠨࠩ䃏"),l11l1l_l1_ (u"ࠩࠪ䃐"),l11l1l_l1_ (u"ࠪࠫ䃑"),l11l1l_l1_ (u"ࠫࠬ䃒"),l11l1l_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ䃓"))
	html = response.content
	html = l1llll_l1_(html)
	name = re.findall(l11l1l_l1_ (u"࠭ࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤ࡬ࡸࡪࡳࠢࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂ࠳ࡸ࡫ࡲࡪࡧࡶ࠳࠭࠴ࠪࡀࠫࠥࠫ䃔"),html,re.DOTALL)
	if name: name = name[-1].replace(l11l1l_l1_ (u"ࠧ࠮ࠩ䃕"),l11l1l_l1_ (u"ࠨࠢࠪ䃖")).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ䃗"))
	if l11l1l_l1_ (u"้ࠪํูๅࠨ䃘") in name and type==l11l1l_l1_ (u"ࠫࠬ䃙"):
		name = name.split(l11l1l_l1_ (u"๋่ࠬิ็ࠪ䃚"))[0]
		name = name.replace(l11l1l_l1_ (u"࠭ๅีษ๊ำฮ࠭䃛"),l11l1l_l1_ (u"ࠧࠨ䃜")).strip(l11l1l_l1_ (u"ࠨࠢࠪ䃝"))
	elif l11l1l_l1_ (u"ࠩะ่็ฯࠧ䃞") in name:
		name = name.split(l11l1l_l1_ (u"ࠪั้่ษࠨ䃟"))[0]
		name = name.replace(l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠫ䃠"),l11l1l_l1_ (u"ࠬ࠭䃡")).strip(l11l1l_l1_ (u"࠭ࠠࠨ䃢"))
	else: name = name
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔࡧࡤࡷࡴࡴࡳ࠮࠯ࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡯࡮ࡨ࡮ࡨࡷࡪࡩࡴࡪࡱࡱࠫ䃣"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		if type==l11l1l_l1_ (u"ࠨࠩ䃤"):
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ䃥"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴࠩ䃦") in title: continue
				if l11l1l_l1_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬ䃧") in title: continue
				title = name+l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩ䃨")+title
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃩"),l1111l_l1_+title,l1llll1_l1_,363,l11l1l_l1_ (u"ࠧࠨ䃪"),l11l1l_l1_ (u"ࠨࠩ䃫"),l11l1l_l1_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ䃬"))
		if len(menuItemsLIST)==0:
			l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡉࡵ࡯ࡳࡰࡦࡨࡷ࠲࠳ࡓࡦࡣࡶࡳࡳࡹ࠭࠮ࡇࡳ࡭ࡸࡵࡤࡦࡵࠥࠬ࠳࠰࠿ࠪࠨࠩࠫ䃭"),block+l11l1l_l1_ (u"ࠫࠫࠬࠧ䃮"),re.DOTALL)
			if l1l1lll_l1_: block = l1l1lll_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦࡲ࡬ࡷࡴࡪࡥࡕ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䃯"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ䃰"))
				title = name+l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫ䃱")+title
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䃲"),l1111l_l1_+title,l1llll1_l1_,362)
	if len(menuItemsLIST)==0:
		title = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䃳"),html,re.DOTALL)
		if title: title = title[0].replace(l11l1l_l1_ (u"ࠪࠤ࠲ࠦๅศ์ࠣื๏๋วࠨ䃴"),l11l1l_l1_ (u"ࠫࠬ䃵")).replace(l11l1l_l1_ (u"๋ࠬิศ้าอࠥ࠭䃶"),l11l1l_l1_ (u"࠭ࠧ䃷"))
		else: title = l11l1l_l1_ (u"ࠧๆๆไࠤฬ๊สี฼ํ่ࠬ䃸")
		addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䃹"),l1111l_l1_+title,url,362)
	return
def PLAY(url):
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䃺"),url,l11l1l_l1_ (u"ࠪࠫ䃻"),l11l1l_l1_ (u"ࠫࠬ䃼"),l11l1l_l1_ (u"ࠬ࠭䃽"),l11l1l_l1_ (u"࠭ࠧ䃾"),l11l1l_l1_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ䃿"))
	html = response.content
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䄀"),html,re.DOTALL)
	if l11l11l_l1_:
		l11l11l_l1_ = [l11l11l_l1_[0][0],l11l11l_l1_[0][1]]
		if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ䄁"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䄂"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䄃") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if name==l11l1l_l1_ (u"ู๊ࠬาใิࠤ๊อ๊ࠡีํ้ฬ࠭䄄"): name = l11l1l_l1_ (u"࠭࡭ࡺࡥ࡬ࡱࡦ࠭䄅")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ䄆")+name+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ䄇")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡏ࡭ࡸࡺ࠭࠮ࡆࡲࡻࡳࡲ࡯ࡢࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ䄈"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䄉"),block,re.DOTALL)
		for l1llll1_l1_,l111ll11_l1_ in items:
			if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ䄊") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭䄋"),l111ll11_l1_,re.DOTALL)
			if l111ll11_l1_: l111ll11_l1_ = l11l1l_l1_ (u"࠭࡟ࡠࡡࡢࠫ䄌")+l111ll11_l1_[0]
			else: l111ll11_l1_ = l11l1l_l1_ (u"ࠧࠨ䄍")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾࡯ࡼࡧ࡮ࡳࡡࠨ䄎")+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭䄏")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䄐"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䄑"),url)
	return
def SEARCH(search,hostname=l11l1l_l1_ (u"ࠬ࠭䄒")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"࠭ࠧ䄓"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠧࠨ䄔"): return
	search = search.replace(l11l1l_l1_ (u"ࠨࠢࠪ䄕"),l11l1l_l1_ (u"ࠩ࠮ࠫ䄖"))
	l1lll1_l1_ = [l11l1l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵࠩ䄗"),l11l1l_l1_ (u"ࠫ࠴࠭䄘"),l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡸ࡫ࡲࡪࡧࡶࠫ䄙"),l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸ࠴ࡧ࡮ࡪ࡯ࡨࠫ䄚"),l11l1l_l1_ (u"ࠧ࠰࡮࡬ࡷࡹ࠵ࡴࡷࠩ䄛")]
	l1l111ll1_l1_ = [l11l1l_l1_ (u"ࠨษ็็้࠭䄜"),l11l1l_l1_ (u"ࠩส่ศ็ไศ็ࠪ䄝"),l11l1l_l1_ (u"ࠪห้๋ำๅี็หฯ࠭䄞"),l11l1l_l1_ (u"ࠫฬ๊ว็์่๎ࠥ๎ࠠศๆๆีฯ๎ๆࠨ䄟"),l11l1l_l1_ (u"ࠬอไษำส้ัࠦสๅ์ไึ๏๎ๆ๋หࠪ䄠")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊ๆ้฻ࠣห้๋ืๅ๊ห࠾ࠬ䄡"), l1l111ll1_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if hostname==l11l1l_l1_ (u"ࠧࠨ䄢"):
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䄣"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ䄤"),l11l1l_l1_ (u"ࠪࠫ䄥"),False,l11l1l_l1_ (u"ࠫࠬ䄦"),l11l1l_l1_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩ䄧"))
		hostname = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ䄨")]
		hostname = hostname.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ䄩"))
	l111l1l_l1_ = hostname+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪ䄪")+search+l1lll1_l1_[l1l_l1_]
	l1lllll_l1_(l111l1l_l1_)
	return
def l1ll1l1l_l1_(l111lll111l_l1_,filter):
	if l11l1l_l1_ (u"ࠩࡂࡃࠬ䄫") in l111lll111l_l1_: url = l111lll111l_l1_.split(l11l1l_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䄬"))[0]
	else: url = l111lll111l_l1_
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ䄭"):l111lll111l_l1_,l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ䄮"):l11l1l_l1_ (u"࠭ࠧ䄯")}
	filter = filter.replace(l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䄰"),l11l1l_l1_ (u"ࠨࠩ䄱"))
	type,filter = filter.split(l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭䄲"),1)
	if filter==l11l1l_l1_ (u"ࠪࠫ䄳"): l1l11111_l1_,l11lllll_l1_ = l11l1l_l1_ (u"ࠫࠬ䄴"),l11l1l_l1_ (u"ࠬ࠭䄵")
	else: l1l11111_l1_,l11lllll_l1_ = filter.split(l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ䄶"))
	if type==l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ䄷"):
		if l1l11111l_l1_[0]+l11l1l_l1_ (u"ࠨ࠿ࡀࠫ䄸") not in l1l11111_l1_: category = l1l11111l_l1_[0]
		for i in range(len(l1l11111l_l1_[0:-1])):
			if l1l11111l_l1_[i]+l11l1l_l1_ (u"ࠩࡀࡁࠬ䄹") in l1l11111_l1_: category = l1l11111l_l1_[i+1]
		l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭䄺")+category+l11l1l_l1_ (u"ࠫࡂࡃ࠰ࠨ䄻")
		l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ䄼")+category+l11l1l_l1_ (u"࠭࠽࠾࠲ࠪ䄽")
		l1l11l11_l1_ = l1l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ䄾"))+l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ䄿")+l1l1l1l1_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠪࠬ䅀"))
		l11lll11_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䅁"))
		l111l1l_l1_ = url+l11l1l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ䅂")+l11lll11_l1_
	elif type==l11l1l_l1_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭䅃"):
		l11l1lll_l1_ = l11lll1l_l1_(l1l11111_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䅄"))
		l11l1lll_l1_ = l1llll_l1_(l11l1lll_l1_)
		if l11lllll_l1_!=l11l1l_l1_ (u"ࠧࠨ䅅"): l11lllll_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䅆"))
		if l11lllll_l1_==l11l1l_l1_ (u"ࠩࠪ䅇"): l111l1l_l1_ = url
		else: l111l1l_l1_ = url+l11l1l_l1_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩ䅈")+l11lllll_l1_
		l1llll1ll_l1_ = l11ll11l1_l1_(l111l1l_l1_,l111lll111l_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䅉"),l1111l_l1_+l11l1l_l1_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨ䅊"),l1llll1ll_l1_,361,l11l1l_l1_ (u"࠭ࠧ䅋"),l11l1l_l1_ (u"ࠧࠨ䅌"),l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ䅍"))
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䅎"),l1111l_l1_+l11l1l_l1_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ䅏")+l11l1lll_l1_+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ䅐"),l1llll1ll_l1_,361,l11l1l_l1_ (u"ࠬ࠭䅑"),l11l1l_l1_ (u"࠭ࠧ䅒"),l11l1l_l1_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨ䅓"))
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䅔"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䅕"),l11l1l_l1_ (u"ࠪࠫ䅖"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ䅗"),url,l11l1l_l1_ (u"ࠬ࠭䅘"),l11l1l_l1_ (u"࠭ࠧ䅙"),l11l1l_l1_ (u"ࠧࠨ䅚"),l11l1l_l1_ (u"ࠨࠩ䅛"),l11l1l_l1_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ䅜"))
	html = response.content
	html = html.replace(l11l1l_l1_ (u"ࠪࡠࡡࠨࠧ䅝"),l11l1l_l1_ (u"ࠫࠧ࠭䅞")).replace(l11l1l_l1_ (u"ࠬࡢ࡜࠰ࠩ䅟"),l11l1l_l1_ (u"࠭࠯ࠨ䅠"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࠪ࠱࠮ࡄ࠯࠼࠰࡯ࡼࡧ࡮ࡳࡡ࠮࠯ࡩ࡭ࡱࡺࡥࡳࡀࠪ䅡"),html,re.DOTALL)
	if not l1l11l1_l1_: return
	block = l1l11l1_l1_[0]
	l1ll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡶࡤࡼࡴࡴ࡯࡮ࡻࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䅢"),block+l11l1l_l1_ (u"ࠩ࠿ࡪ࡮ࡲࡴࡦࡴࡥࡳࡽ࠭䅣"),re.DOTALL)
	dict = {}
	for l1ll11l1_l1_,name,block in l1ll1l11_l1_:
		name = escapeUNICODE(name)
		if l11l1l_l1_ (u"ࠪ࡭ࡳࡺࡥࡳࡧࡶࡸࠬ䅤") in l1ll11l1_l1_: continue
		items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡷࡩࡷࡳ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡹࡾࡴ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡻࡸࡃ࠭䅥"),block,re.DOTALL)
		if l11l1l_l1_ (u"ࠬࡃ࠽ࠨ䅦") not in l111l1l_l1_: l111l1l_l1_ = url
		if type==l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ䅧"):
			if category!=l1ll11l1_l1_: continue
			elif len(items)<=1:
				if l1ll11l1_l1_==l1l11111l_l1_[-1]: l1lllll_l1_(l111l1l_l1_)
				else: l1ll1l1l_l1_(l111l1l_l1_,l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ䅨")+l1l11l11_l1_)
				return
			else:
				l1llll1ll_l1_ = l11ll11l1_l1_(l111l1l_l1_,l111lll111l_l1_)
				if l1ll11l1_l1_==l1l11111l_l1_[-1]:
					addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䅩"),l1111l_l1_+l11l1l_l1_ (u"ࠩส่ัฺ๋๊ࠩ䅪"),l1llll1ll_l1_,361,l11l1l_l1_ (u"ࠪࠫ䅫"),l11l1l_l1_ (u"ࠫࠬ䅬"),l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䅭"))
				else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䅮"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠧ䅯"),l111l1l_l1_,364,l11l1l_l1_ (u"ࠨࠩ䅰"),l11l1l_l1_ (u"ࠩࠪ䅱"),l1l11l11_l1_)
		elif type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䅲"):
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫࠬࠧ䅳")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠬࡃ࠽࠱ࠩ䅴")
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"࠭ࠦࠧࠩ䅵")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠧ࠾࠿࠳ࠫ䅶")
			l1l11l11_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠨࡡࡢࡣࠬ䅷")+l1l1l1l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䅸"),l1111l_l1_+name+l11l1l_l1_ (u"ࠪ࠾ࠥอไอ็ํ฽ࠬ䅹"),l111l1l_l1_,365,l11l1l_l1_ (u"ࠫࠬ䅺"),l11l1l_l1_ (u"ࠬ࠭䅻"),l1l11l11_l1_+l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䅼"))
		dict[l1ll11l1_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11l1l_l1_ (u"ࠧࡳࠩ䅽") or value==l11l1l_l1_ (u"ࠨࡰࡦ࠱࠶࠽ࠧ䅾"): continue
			if any(value in option.lower() for value in l1l111_l1_): continue
			if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ䅿") in option: continue
			if l11l1l_l1_ (u"ࠪห้้ไࠨ䆀") in option: continue
			if l11l1l_l1_ (u"ࠫࡳ࠳ࡡࠨ䆁") in value: continue
			#if value in [l11l1l_l1_ (u"ࠬࡸࠧ䆂"),l11l1l_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ䆃"),l11l1l_l1_ (u"ࠧࡵࡸ࠰ࡱࡦ࠭䆄")]: continue
			#if l1ll11l1_l1_==l11l1l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䆅"): option = value
			if option==l11l1l_l1_ (u"ࠩࠪ䆆"): option = value
			l11l11l1l_l1_ = option
			l1l1l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀࡳࡧ࡭ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡱࡥࡲ࡫࠾ࠨ䆇"),option,re.DOTALL)
			if l1l1l1l1lll_l1_: l11l11l1l_l1_ = l1l1l1l1lll_l1_[0]
			l1lll11l1_l1_ = name+l11l1l_l1_ (u"ࠫ࠿ࠦࠧ䆈")+l11l11l1l_l1_
			dict[l1ll11l1_l1_][value] = l1lll11l1_l1_
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ䆉")+l1ll11l1_l1_+l11l1l_l1_ (u"࠭࠽࠾ࠩ䆊")+l11l11l1l_l1_
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠧࠧࠨࠪ䆋")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠨ࠿ࡀࠫ䆌")+value
			l1ll111l_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭䆍")+l1l1l1l1_l1_
			if type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ䆎"):
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆏"),l1111l_l1_+l1lll11l1_l1_,url,365,l11l1l_l1_ (u"ࠬ࠭䆐"),l11l1l_l1_ (u"࠭ࠧ䆑"),l1ll111l_l1_+l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䆒"))
			elif type==l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ䆓") and l1l11111l_l1_[-2]+l11l1l_l1_ (u"ࠩࡀࡁࠬ䆔") in l1l11111_l1_:
				l11lll11_l1_ = l11lll1l_l1_(l1l1l1l1_l1_,l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䆕"))
				#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ䆖"),l11l1l_l1_ (u"ࠬ࠭䆗"),l11lll11_l1_,l1l1l1l1_l1_)
				l111ll1_l1_ = url+l11l1l_l1_ (u"࠭࠯࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡃࠬ䆘")+l11lll11_l1_
				l1llll1ll_l1_ = l11ll11l1_l1_(l111ll1_l1_,l111lll111l_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䆙"),l1111l_l1_+l1lll11l1_l1_,l1llll1ll_l1_,361,l11l1l_l1_ (u"ࠨࠩ䆚"),l11l1l_l1_ (u"ࠩࠪ䆛"),l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䆜"))
			else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆝"),l1111l_l1_+l1lll11l1_l1_,url,364,l11l1l_l1_ (u"ࠬ࠭䆞"),l11l1l_l1_ (u"࠭ࠧ䆟"),l1ll111l_l1_)
	return
l1l11111l_l1_ = [l11l1l_l1_ (u"ࠧࡨࡧࡱࡶࡪ࠭䆠"),l11l1l_l1_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䆡"),l11l1l_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ䆢")]
l11llll1l_l1_ = [l11l1l_l1_ (u"ࠪࡱࡵࡧࡡࠨ䆣"),l11l1l_l1_ (u"ࠫ࡬࡫࡮ࡳࡧࠪ䆤"),l11l1l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫ䆥"),l11l1l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ䆦"),l11l1l_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨ䆧"),l11l1l_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ䆨"),l11l1l_l1_ (u"ࠩࡱࡥࡹ࡯࡯࡯ࠩ䆩"),l11l1l_l1_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬ䆪")]
def l11ll11l1_l1_(l111l1l_l1_,l111ll1_l1_):
	if l11l1l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ䆫") in l111l1l_l1_: l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠬ࠵ࡁ࡫ࡣࡻࡇࡪࡴࡴࡦࡴ࠲ࡖ࡮࡭ࡨࡵࡄࡤࡶࠬ䆬"),l11l1l_l1_ (u"࠭࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭ࠧ䆭"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭䆮"),l11l1l_l1_ (u"ࠨ࠼࠽࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪ࠳ࠬ䆯"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠩࡀࡁࠬ䆰"),l11l1l_l1_ (u"ࠪ࠳ࠬ䆱"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠫࠫࠬࠧ䆲"),l11l1l_l1_ (u"ࠬ࠵ࠧ䆳"))
	return l111l1l_l1_
def l11lll1l_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䆴"),l11l1l_l1_ (u"ࠧࠨ䆵"),filters,l11l1l_l1_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨ䆶")+mode)
	# mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ䆷")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ values
	# mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭䆸")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ filters
	# mode==l11l1l_l1_ (u"ࠫࡦࡲ࡬ࠨ䆹")					all filters (l11ll1l1_l1_ l1l1l111_l1_ filter)
	filters = filters.strip(l11l1l_l1_ (u"ࠬࠬࠦࠨ䆺"))
	l1l1111l_l1_,l1ll1111_l1_ = {},l11l1l_l1_ (u"࠭ࠧ䆻")
	if l11l1l_l1_ (u"ࠧ࠾࠿ࠪ䆼") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠨࠨࠩࠫ䆽"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠩࡀࡁࠬ䆾"))
			l1l1111l_l1_[var] = value
	for key in l11llll1l_l1_:
		if key in list(l1l1111l_l1_.keys()): value = l1l1111l_l1_[key]
		else: value = l11l1l_l1_ (u"ࠪ࠴ࠬ䆿")
		if l11l1l_l1_ (u"ࠫࠪ࠭䇀") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ䇁") and value!=l11l1l_l1_ (u"࠭࠰ࠨ䇂"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠧࠡ࠭ࠣࠫ䇃")+value
		elif mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ䇄") and value!=l11l1l_l1_ (u"ࠩ࠳ࠫ䇅"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭䇆")+key+l11l1l_l1_ (u"ࠫࡂࡃࠧ䇇")+value
		elif mode==l11l1l_l1_ (u"ࠬࡧ࡬࡭ࠩ䇈"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"࠭ࠦࠧࠩ䇉")+key+l11l1l_l1_ (u"ࠧ࠾࠿ࠪ䇊")+value
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠨࠢ࠮ࠤࠬ䇋"))
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠩࠩࠪࠬ䇌"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䇍"),l11l1l_l1_ (u"ࠫࠬ䇎"),l1ll1111_l1_,l11l1l_l1_ (u"ࠬࡕࡕࡕࠩ䇏"))
	return l1ll1111_l1_
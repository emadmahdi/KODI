# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#l11l11_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿ࠮ࡣࡧࡶࡸࠬ≓")
#l11l11_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹ࠲࠰ࡥࡩࡸࡺࠧ≔")
#l11l11_l1_ = l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠷࠮ࡤࡱࡰࠫ≕")
#l11l11_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ≖")
#l11l11_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼ࠸ࡧ࡫ࡳࡵ࠰ࡦࡳࡲ࠭≗")
#l11l11_l1_ = l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠯ࡹ࡭ࡵ࠴ࡳࡩࡱࡩࡨࡦ࠴ࡣࡰ࡯ࠪ≘")
#l11l11_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡳࡲ࡫࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡰ࡯ࠫ≙")
#l11l11_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࠫ≚")
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠧ≛")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡋࡇࡗࡡࠪ≜")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,l11lll1_l1_,text):
	if   mode==220: results = MENU()
	elif mode==221: results = l1lllll_l1_(url,l11lll1_l1_)
	elif mode==222: results = l11lll_l1_(url)
	elif mode==223: results = PLAY(url)
	elif mode==224: results = l1ll1l1l_l1_(url)
	elif mode==229: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ≝"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭≞"),l11l1l_l1_ (u"ࠧࠨ≟"),229,l11l1l_l1_ (u"ࠨࠩ≠"),l11l1l_l1_ (u"ࠩࠪ≡"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ≢"))
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ≣"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ≤"),l11l11_l1_,226,l11l1l_l1_ (u"࠭ࠧ≥"),l11l1l_l1_ (u"ࠧࠨ≦"),l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ≧"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ≨"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭≩"),l11l11_l1_,226,l11l1l_l1_ (u"ࠫࠬ≪"),l11l1l_l1_ (u"ࠬ࠭≫"),l11l1l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪ≬"))
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ≭"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ≮"),l11l1l_l1_ (u"ࠩࠪ≯"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ≰"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ≱"),l11l1l_l1_ (u"ࠬ࠭≲"),l11l1l_l1_ (u"࠭ࠧ≳"),l11l1l_l1_ (u"ࠧࠨ≴"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ≵"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࠤ࡮࠳ࡨࡰ࡯ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ≶"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ≷"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠩ≸") in title: title = title.split(l11l1l_l1_ (u"ࠬࡂ࠯ࡪࡀࠪ≹"))[1]
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭≺"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ≻")+l1111l_l1_+title,l1llll1_l1_,222)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭≼"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ≽"),l11l1l_l1_ (u"ࠪࠫ≾"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡧࡧࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࠬ≿"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬࡶࡤࡢࠢࡥࡨࡧࠨ࠾࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⊀"),html,re.DOTALL)
	for title,l1llll1_l1_ in items:
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⊁"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ⊂")+l1111l_l1_+title,l1llll1_l1_,221)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⊃"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⊄"),l11l1l_l1_ (u"ࠪࠫ⊅"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⊆"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠬ࡮ࡴ࡮࡮ࠪ⊇") not in l1llll1_l1_: continue
		if not l1llll1_l1_.endswith(l11l1l_l1_ (u"࠭࠯ࠨ⊈")): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⊉"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ⊊")+l1111l_l1_+title,l1llll1_l1_,221)
	return html
	l11l1l_l1_ (u"ࠤࠥࠦࠏࠏࠣࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฬ฼ฺุ๊๊ࠢฬࠦไศุสๅฮࠦวิ็ࠣำำ๎ไ๊ࠡๆ่๊ฯࠠศๆึีࠬ࠲ࠧࠨ࠮࠵࠶࠺࠯ࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭สฮาํีࠬ࠲ࠧࠨ࠮࠵࠶࠻࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠬࠡࡪࡷࡱࡱ࠯ࠊࠊࠥ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰࡏࡳࡦࡪࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠥ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪࡀࠫ࠲࠯ࡅࠩ࡝ࡰࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠥࡩࡳࡷࠦࡵࡳ࡮࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠣࠊ࡫ࡩࠤࡺࡸ࡬ࠢ࠿ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭ࡷࡵࡰ࠱࠸࠲࠵ࠫࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ࠮ࠪࠫ࠱࠸࠲࠺࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࠯ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็ว่ััࠡ็ืห์ีษࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰࠭࠯ࡵࡴࡨࡲࡩ࡯࡮ࡨࠩ࠯࠶࠷࠷ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࠯ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨษ็หๆ๊วๆࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨ࠮࠵࠶࠹࠯ࠊࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭ࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠱ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ࠮ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧศๆ่ืู้ไศฬࠪ࠰ࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡷࡺࠬ࠲࠲࠳࠶ࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡱ࡯࡮࡬ࠩ࠯ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠱࠭ࠧ࠭࠻࠼࠽࠾࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡦࠦ࡭ࡨࡤࠫ࠲࠯ࡅࠩ࠿ࡇࡪࡽࡇ࡫ࡳࡵ࠾࠲ࡥࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ࠯ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌࡶࡪࡺࡵࡳࡰࠣ࡬ࡹࡳ࡬ࠋࠋࠦࠤࡪ࡭ࡹࡣࡧࡶࡸ࠶࠴ࡣࡰ࡯ࠍࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡪࡦࡀࠦࡲ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠤ࡫ࡷࡩࡲࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋ࡬ࡸࡪࡳࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡟࠶࠵࡝࡜࡫ࠥࡡࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨࡶࡲࡶࡷ࡫࡮ࡵࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡲࡡࡴࡵࡀࠦࡨࡧࡲࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࡩࡧࠢࠪࡸࡴࡸࡲࡦࡰࡷࠫࠥࡴ࡯ࡵࠢ࡬ࡲࠥࡲࡩ࡯࡭࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌࠦࠧࠨ⊋")
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ⊌"),url,l11l1l_l1_ (u"ࠫࠬ⊍"),l11l1l_l1_ (u"ࠬ࠭⊎"),l11l1l_l1_ (u"࠭ࠧ⊏"),l11l1l_l1_ (u"ࠧࠨ⊐"),l11l1l_l1_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⊑"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡷࡤࡹࡣࡳࡱ࡯ࡰࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⊒"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ⊓"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⊔"),l1111l_l1_+title,l1llll1_l1_,224)
	return
def l1ll1l1l_l1_(url):
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⊕"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅฮ่๎฾࠭⊖"),url,221)
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠧࠨ⊗"),l11l1l_l1_ (u"ࠨࠩ⊘"),l11l1l_l1_ (u"ࠩࠪ⊙"),l11l1l_l1_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⊚"))
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡮ࡪ࠽ࠣ࡯ࡤ࡭ࡳࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࠤࠥࠦ⊛")
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣࡡࡱࡥࡻ࠮࠮ࠫࡁࠬ࡭ࡩࡃࠢ࡮ࡱࡹ࡭ࡪࡹࠧ⊜"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⊝"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l1llll1_l1_==l11l1l_l1_ (u"ࠧࠤࠩ⊞"): name = title
			else:
				title = title + l11l1l_l1_ (u"ࠨࠢࠣ࠾ࠥࠦࠧ⊟") + l11l1l_l1_ (u"ࠩไ่ฯืࠠࠨ⊠") + name
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⊡"),l1111l_l1_+title,l1llll1_l1_,221)
	else: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,l11lll1_l1_=l11l1l_l1_ (u"ࠫ࠶࠭⊢")):
	if l11lll1_l1_==l11l1l_l1_ (u"ࠬ࠭⊣"): l11lll1_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ⊤")
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ⊥"),l11l1l_l1_ (u"ࠨࠩ⊦"),str(url), str(l11lll1_l1_))
	if l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪ⊧") in url or l11l1l_l1_ (u"ࠪࡃࠬ⊨") in url: l111l1l_l1_ = url + l11l1l_l1_ (u"ࠫࠫ࠭⊩")
	else: l111l1l_l1_ = url + l11l1l_l1_ (u"ࠬࡅࠧ⊪")
	#l111l1l_l1_ = l111l1l_l1_ + l11l1l_l1_ (u"࠭࡯ࡶࡶࡳࡹࡹࡥࡦࡰࡴࡰࡥࡹࡃࡪࡴࡱࡱࠪࡴࡻࡴࡱࡷࡷࡣࡲࡵࡤࡦ࠿ࡰࡳࡻ࡯ࡥࡴࡡ࡯࡭ࡸࡺࠦࡱࡣࡪࡩࡂ࠭⊫")+l11lll1_l1_
	l111l1l_l1_ = l111l1l_l1_ + l11l1l_l1_ (u"ࠧࡱࡣࡪࡩࡂ࠭⊬") + l11lll1_l1_
	html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩ⊭"),l11l1l_l1_ (u"ࠩࠪ⊮"),l11l1l_l1_ (u"ࠪࠫ⊯"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ⊰"))
	#name = l11l1l_l1_ (u"ࠬ࠭⊱")
	#if l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࠧ⊲") in url:
	#	name = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⊳"),html,re.DOTALL)
	#	if name: name = escapeUNICODE(name[0]).strip(l11l1l_l1_ (u"ࠨࠢࠪ⊴")) + l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭⊵")
	#	else: name = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦ⊶") ) + l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨ⊷")
	if l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠭⊸") in url:
		l1l11l1_l1_=re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡥࡣࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬ⊹"),html,re.DOTALL)
		block = l1l11l1_l1_[-1]
	# l1lll1l1lll_l1_ l1lll1l_l1_
	elif l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ⊺") in url:
		l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠠࡰࡹ࡯࠱ࡨࡧࡲࡰࡷࡶࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧ⊻"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
	else:
		l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⊼"),html,re.DOTALL)
		block = l1l11l1_l1_[-1]
	items = re.findall(l11l1l_l1_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⊽"),block,re.DOTALL)
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴࡧࡵ࡭ࡪࡹࠧࠡ࡫ࡱࠤࡺࡸ࡬ࠡࡣࡱࡨࠥ࠭࠯ࡴࡧࡤࡷࡴࡴࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡥࡳࡪࠠࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࠭ࠬࠨࠩ࠯ࡸ࡮ࡺ࡬ࡦ࠮ࠣࡷࡹࡸࠨ࡭࡫ࡱ࡯࠮࠯ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡲࡦࡳࡥࠡ࠭ࠣࡩࡸࡩࡡࡱࡧࡘࡒࡎࡉࡏࡅࡇࠫࡸ࡮ࡺ࡬ࡦࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠥࠦࠧ⊾")
		title = unescapeHTML(title)
		l11l1l_l1_ (u"ࠧࠨࠢࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࠎ࡯࡭ࡨࠢࡀࠤ࡮ࡳࡧ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪࡨࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣ࡭ࡲ࡭࠺ࠡ࡫ࡰ࡫ࠥࡃࠠࠨࡪࡷࡸࡵࡀࠧࠡ࠭ࠣ࡭ࡲ࡭ࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡒࡔ࡚ࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠪ࡬ࡱ࡬࠲ࠧࠨࠫࠍࠍࠎࡻࡲ࡭࠴ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠦࠧࠨ⊿")
		if l11l1l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵ࠧ⋀") in l1llll1_l1_ or l11l1l_l1_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࠩ⋁") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⋂"),l1111l_l1_+title,l1llll1_l1_.rstrip(l11l1l_l1_ (u"ࠩ࠲ࠫ⋃")),223,l1ll1l_l1_)
		else:
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋄"),l1111l_l1_+title,l1llll1_l1_,221,l1ll1l_l1_)
	if len(items)>=16:
		l11111llll_l1_ = [l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ⋅"),l11l1l_l1_ (u"ࠬ࠵ࡴࡷࠩ⋆"),l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ⋇"),l11l1l_l1_ (u"ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ⋈")]
		l11lll1_l1_ = int(l11lll1_l1_)
		if any(value in url for value in l11111llll_l1_):
			for n in range(0,1000,100):
				if int(l11lll1_l1_/100)*100==n:
					for i in range(n,n+100,10):
						if int(l11lll1_l1_/10)*10==i:
							for j in range(i,i+10,1):
								if not l11lll1_l1_==j and j!=0:
									addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⋉"),l1111l_l1_+l11l1l_l1_ (u"ุࠩๅาฯࠠࠨ⋊")+str(j),url,221,l11l1l_l1_ (u"ࠪࠫ⋋"),str(j))
						elif i!=0: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⋌"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ⋍")+str(i),url,221,l11l1l_l1_ (u"࠭ࠧ⋎"),str(i))
						else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⋏"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ⋐")+str(1),url,221,l11l1l_l1_ (u"ࠩࠪ⋑"),str(1))
				elif n!=0: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⋒"),l1111l_l1_+l11l1l_l1_ (u"ฺࠫ็อสࠢࠪ⋓")+str(n),url,221,l11l1l_l1_ (u"ࠬ࠭⋔"),str(n))
				else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⋕"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭⋖")+str(1),url,221)
	return
def PLAY(url):
	#global l11l1l_l1_ (u"ࠨࠩ⋗")
	l1ll1ll1_l1_,l1lll1_l1_ = [],[]
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ⋘"),l11l1l_l1_ (u"ࠪࠫ⋙"),url, url[-45:])
	# https://l1llll111l1_l1_.com/l1llll11lll_l1_/فيلم-the-l1llll1l1ll_l1_-l1lll1ll111_l1_-2019-مترجم
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠫࠬ⋚"),l11l1l_l1_ (u"ࠬ࠭⋛"),l11l1l_l1_ (u"࠭ࠧ⋜"),l11l1l_l1_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭⋝"))
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡷࡨࡃอไหื้๎ๆࡂ࠯ࡵࡦࡁ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⋞"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	# https://l1111lll11_l1_.l1lll1l1ll1_l1_/l1llll11lll_l1_/فيلم-the-l1llll1l1ll_l1_-l1lll1ll111_l1_-2019-مترجم
	l111lll1l_l1_,l11ll11ll_l1_ = l11l1l_l1_ (u"ࠩࠪ⋟"),l11l1l_l1_ (u"ࠪࠫ⋠")
	l1llll1ll11_l1_,l1lll1lllll_l1_ = html,html
	l1llll11l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸ࡮࡯ࡸࡡࡧࡰࠥࡧࡰࡪࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⋡"),html,re.DOTALL)
	if l1llll11l11_l1_:
		for l1llll1_l1_ in l1llll11l11_l1_:
			if l11l1l_l1_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭⋢") in l1llll1_l1_: l111lll1l_l1_ = l1llll1_l1_
			elif l11l1l_l1_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ⋣") in l1llll1_l1_: l11ll11ll_l1_ = l1llll1_l1_
		if l111lll1l_l1_!=l11l1l_l1_ (u"ࠧࠨ⋤"): l1llll1ll11_l1_ = OPENURL_CACHED(l1llll11_l1_,l111lll1l_l1_,l11l1l_l1_ (u"ࠨࠩ⋥"),l11l1l_l1_ (u"ࠩࠪ⋦"),l11l1l_l1_ (u"ࠪࠫ⋧"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ⋨"))
		if l11ll11ll_l1_!=l11l1l_l1_ (u"ࠬ࠭⋩"): l1lll1lllll_l1_ = OPENURL_CACHED(l1llll11_l1_,l11ll11ll_l1_,l11l1l_l1_ (u"࠭ࠧ⋪"),l11l1l_l1_ (u"ࠧࠨ⋫"),l11l1l_l1_ (u"ࠨࠩ⋬"),l11l1l_l1_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ⋭"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ⋮"),l11l1l_l1_ (u"ࠫࠬ⋯"),l11ll11ll_l1_,l111lll1l_l1_)
	# https://l1lll1llll1_l1_.l1111lll11_l1_.download/?id=__1llll1l1l1_l1_
	l1llll11l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡹ࡭ࡩ࡫࡯ࠣ࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⋰"),l1llll1ll11_l1_,re.DOTALL)
	if l1llll11l1l_l1_:
		l111l1l_l1_ = l1llll11l1l_l1_[0]#+l11l1l_l1_ (u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࡮ࡴࡵࡲ࠽࠳࠴࠽࠹࠯࠳࠹࠹࠳࠸࠴࠳࠰࠻࠸࠿࠺࠱࠵࠷ࠪ⋱")
		if l111l1l_l1_!=l11l1l_l1_ (u"ࠧࠨ⋲") and l11l1l_l1_ (u"ࠨࡷࡳࡰࡴࡧࡤࡦࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⋳") in l111l1l_l1_ and l11l1l_l1_ (u"ࠩ࠲ࡃ࡮ࡪ࠽ࡠࠩ⋴") not in l111l1l_l1_:
			l11ll111_l1_ = OPENURL_CACHED(l1llll11_l1_,l111l1l_l1_,l11l1l_l1_ (u"ࠪࠫ⋵"),l11l1l_l1_ (u"ࠫࠬ⋶"),l11l1l_l1_ (u"ࠬ࠭⋷"),l11l1l_l1_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ⋸"))
			l1lll1l1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⋹"),l11ll111_l1_,re.DOTALL)
			if l1lll1l1l11_l1_:
				for l1llll1_l1_,l111ll11_l1_ in l1lll1l1l11_l1_:
					l1lll1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡧࡧ࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡪ࡯ࡠࡡࡺࡥࡹࡩࡨࡠࡡࡰࡴ࠹ࡥ࡟ࠨ⋺")+l111ll11_l1_)
			else:
				server = l111l1l_l1_.split(l11l1l_l1_ (u"ࠩ࠲ࠫ⋻"))[2]
				l1lll1_l1_.append(l111l1l_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⋼")+server+l11l1l_l1_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ⋽"))
		elif l111l1l_l1_!=l11l1l_l1_ (u"ࠬ࠭⋾"):
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ⋿"),l11l1l_l1_ (u"ࠧࠨ⌀"),l111l1l_l1_,str(l1llll11l1l_l1_))
			server = l111l1l_l1_.split(l11l1l_l1_ (u"ࠨ࠱ࠪ⌁"))[2]
			l1lll1_l1_.append(l111l1l_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⌂")+server+l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ⌃"))
	# https://l1lll1ll1l1_l1_.cc/l1llll1l11l_l1_
	# https://l1llll11ll1_l1_.l1lll1ll11l_l1_/l1llll1l11l_l1_
	l1lll1lll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡺࡡࡣ࡮ࡨࠤࡨࡲࡡࡴࡵࡀࠦࡩࡲࡳࡠࡶࡤࡦࡱ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭⌄"),l1lll1lllll_l1_,re.DOTALL)
	if l1lll1lll1l_l1_:
		l1lll1lll1l_l1_ = l1lll1lll1l_l1_[0]
		l1llll111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡴࡥࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⌅"),l1lll1lll1l_l1_,re.DOTALL)
		if l1llll111ll_l1_:
			for l111ll11_l1_,l1llll1_l1_ in l1llll111ll_l1_:
				if l11l1l_l1_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ⌆") not in l1llll1_l1_: continue
				if l1llll1_l1_.count(l11l1l_l1_ (u"ࠧ࠰ࠩ⌇"))>=2:
					server = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨ࠱ࠪ⌈"))[2]
					l1lll1_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ⌉")+server+l11l1l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠ࡯ࡳ࠸ࡤࡥࠧ⌊")+l111ll11_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫฬิสาࠢส่ๆ๐ฯ๋๊ࠣห้๋ๆศีห࠾ࠬ⌋"), l1lll1_l1_)
	#if l1l_l1_ == -1 : return
	l1lll1lll11_l1_ = []
	for l1llll1_l1_ in l1lll1_l1_:
		# faselhd	https://l1lll1l1ll_l1_.l1111lll11_l1_.l1lll1l1ll1_l1_/l1llll11lll_l1_/l11l11lll_l1_/فيلم-the-l1llll1l111_l1_-l1llll1111l_l1_-l1lll1l1l1l_l1_-2017-مترجم/l1llll11111_l1_
		#if l11l1l_l1_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭⌌") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠮ࡷ࡫ࡳࡃࡳࡧ࡭ࡦࠩ⌍") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬ⌎") in l1llll1_l1_: continue
		#if l11l1l_l1_ (u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ⌏") not in l1llll1_l1_: continue
		l1lll1lll11_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ⌐"), l1lll1lll11_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1lll11_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⌑"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠫࠬ⌒"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠬ࠭⌓"): return
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"࠭ࠠࠨ⌔"),l11l1l_l1_ (u"ࠧࠬࠩ⌕"))
	html = OPENURL_CACHED(l1ll1l1ll_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠨࠩ⌖"),l11l1l_l1_ (u"ࠩࠪ⌗"),l11l1l_l1_ (u"ࠪࠫ⌘"),l11l1l_l1_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ⌙"))
	token = re.findall(l11l1l_l1_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡤࡺ࡯࡬ࡧࡱࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ⌚"),html,re.DOTALL)
	if token:
		url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿ࡠࡶࡲ࡯ࡪࡴ࠽ࠨ⌛")+token[0]+l11l1l_l1_ (u"ࠧࠧࡳࡀࠫ⌜")+l11111l_l1_
		l1lllll_l1_(url)
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ⌝"),l11l1l_l1_ (u"ࠩࠪ⌞"),l11l1l_l1_ (u"ࠪࠫ⌟"), l11l1l_l1_ (u"ࠫࠬ⌠"))
	return
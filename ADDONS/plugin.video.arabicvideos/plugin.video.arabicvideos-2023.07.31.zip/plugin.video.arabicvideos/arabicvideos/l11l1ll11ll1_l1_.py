# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫ࡞ࡇࡑࡐࡖࠪ孑")
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡙ࡒࡖࡢࠫ孒")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"࠭วๅืไัฮࠦวๅำษ๎ุ๐ษࠨ孓"),l11l1l_l1_ (u"ࠧࡔ࡫ࡪࡲࠥ࡯࡮ࠨ孔"),l11l1l_l1_ (u"ࠨฬึะ๏๊ࠧ孕"),l11l1l_l1_ (u"ࠩอืั๐ไࠡษ็ำำ๎ไࠨ孖"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠠศๆ่ึ๏ีࠧ字")]
def MAIN(mode,url,text):
	if   mode==660: results = MENU()
	elif mode==661: results = l1lllll_l1_(url,text)
	elif mode==662: results = PLAY(url)
	elif mode==663: results = l1111_l1_(url,text)
	elif mode==664: results = l11lll_l1_(url)
	elif mode==669: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ存"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭孙"),l11l1l_l1_ (u"࠭ࠧ孚"),l11l1l_l1_ (u"ࠧࠨ孛"),l11l1l_l1_ (u"ࠨࠩ孜"),l11l1l_l1_ (u"ࠩ࡜ࡅࡖࡕࡔ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ孝"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ孞"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ孟"),l11l1l_l1_ (u"ࠬ࠭孠"),669,l11l1l_l1_ (u"࠭ࠧ孡"),l11l1l_l1_ (u"ࠧࠨ孢"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ季"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ孤"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ孥"),l11l1l_l1_ (u"ࠫࠬ学"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ孧"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ孨")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่้๏ุษࠨ孩"),l11l11_l1_,661,l11l1l_l1_ (u"ࠨࠩ孪"),l11l1l_l1_ (u"ࠩࠪ孫"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ孬"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ孭"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ孮")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ูหๆࠦอะ์ฮหࠬ孯"),l11l11_l1_,661,l11l1l_l1_ (u"ࠧࠨ孰"),l11l1l_l1_ (u"ࠨࠩ孱"),l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ孲"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ孳"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭孴")+l1111l_l1_+l11l1l_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ孵"),l11l11_l1_,661,l11l1l_l1_ (u"࠭ࠧ孶"),l11l1l_l1_ (u"ࠧࠨ孷"),l11l1l_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ學"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ孹"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ孺")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ孻"),l11l11_l1_,661,l11l1l_l1_ (u"ࠬ࠭孼"),l11l1l_l1_ (u"࠭ࠧ孽"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ孾"))
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭孿"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ宀"),l11l1l_l1_ (u"ࠪࠫ宁"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ宂"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭它"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宄"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ宅")+l1111l_l1_+title,l1llll1_l1_,664)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭宆"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ宇"),l11l1l_l1_ (u"ࠪࠫ守"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ安"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ宊"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ宋"))
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ完"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		title = title.replace(l11l1l_l1_ (u"ࠨ࠾ࡥࡂࠬ宍"),l11l1l_l1_ (u"ࠩࠪ宎")).replace(l11l1l_l1_ (u"ࠪࡀ࠴ࡨ࠾ࠨ宏"),l11l1l_l1_ (u"ࠫࠬ宐")).replace(l11l1l_l1_ (u"ࠬࡂࡢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡶࡪࡺࠢ࠿ࠩ宑"),l11l1l_l1_ (u"࠭ࠧ宒")).replace(l11l1l_l1_ (u"ࠧ࠽ࡤࡁࠫ宓"),l11l1l_l1_ (u"ࠨࠩ宔")).strip(l11l1l_l1_ (u"ࠩࠣࠫ宕"))
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ宖"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭宗")+l1111l_l1_+title,l1llll1_l1_,664)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ官"),url,l11l1l_l1_ (u"࠭ࠧ宙"),l11l1l_l1_ (u"ࠧࠨ定"),l11l1l_l1_ (u"ࠨࠩ宛"),l11l1l_l1_ (u"ࠩࠪ宜"),l11l1l_l1_ (u"ࠪ࡝ࡆࡗࡏࡕ࠯ࡖ࡙ࡇࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ宝"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭实"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠬࠨࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࠧ࠭実"),l11l1l_l1_ (u"࠭࠼࠰ࡷ࡯ࡂࠬ宠"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰࡬ࡪࡧࡤࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ审"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠨࠩ客"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ宣"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦแาิࠣวํࠦแๅฬิࠤศ๎ࠠหำอ๎อ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ室"),l11l1l_l1_ (u"ࠫࠬ宥"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ宦"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"࠭࠺ࠡࠩ宧")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ宨"),l1111l_l1_+title,l1llll1_l1_,661)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡩࡡࡵࡧࡪࡳࡷࡿ࠭ࡴࡷࡥࡧࡦࡺࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ宩"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ宪"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ宫"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ宬"),l11l1l_l1_ (u"ࠬ࠭宭"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭宮"),l1111l_l1_+title,l1llll1_l1_,661)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠧࠨ宯")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ宰"),l11l1l_l1_ (u"ࠩࠪ宱"),request,url)
	if request==l11l1l_l1_ (u"ࠪࡥ࡯ࡧࡸ࠮ࡵࡨࡥࡷࡩࡨࠨ宲"):
		url,search = url.split(l11l1l_l1_ (u"ࠫࡄ࠭害"),1)
		data = l11l1l_l1_ (u"ࠬࡷࡵࡦࡴࡼࡗࡹࡸࡩ࡯ࡩࡀࠫ宴")+search
		headers = {l11l1l_l1_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ宵"):l11l1l_l1_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ家")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭宷"),url,data,headers,l11l1l_l1_ (u"ࠩࠪ宸"),l11l1l_l1_ (u"ࠪࠫ容"),l11l1l_l1_ (u"ࠫ࡞ࡇࡑࡐࡖ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ宺"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ宻"),url,l11l1l_l1_ (u"࠭ࠧ宼"),l11l1l_l1_ (u"ࠧࠨ宽"),l11l1l_l1_ (u"ࠨࠩ宾"),l11l1l_l1_ (u"ࠩࠪ宿"),l11l1l_l1_ (u"ࠪ࡝ࡆࡗࡏࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭寀"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠫࠬ寁"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ寂"))
	if request==l11l1l_l1_ (u"࠭ࡡ࡫ࡣࡻ࠱ࡸ࡫ࡡࡳࡥ࡫ࠫ寃"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ寄"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠨࠩ寅"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ密"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡵࡳ࠭ࡷ࡫ࡧࡩࡴ࠳ࡷࡢࡶࡦ࡬࠲࡬ࡥࡢࡶࡸࡶࡪࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ寇"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ寈"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ寉"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡱࡴࡼࡩࡦࡵࠪ寊"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡲࡻࠥࡶ࡭࠮ࡷ࡯࠱ࡧࡸ࡯ࡸࡵࡨ࠱ࡻ࡯ࡤࡦࡱࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ寋"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ富"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥ࡬ࡴࡳࡥ࠮ࡵࡨࡶ࡮࡫ࡳ࠮࡮࡬ࡷࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࡟ࡡࡺࡼ࡝ࡰࡠ࠮ࡁ࠵ࡤࡪࡸࡁࠫ寍"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ寎"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠫࠬ寏"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭寐"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ寑"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠧๆึส๋ิฯࠧ寒"),l11l1l_l1_ (u"ࠨใํ่๊࠭寓"),l11l1l_l1_ (u"ࠩส฾๋๐ษࠨ寔"),l11l1l_l1_ (u"ࠪ็้๐ศࠨ寕"),l11l1l_l1_ (u"ࠫฬ฿ไศ่ࠪ寖"),l11l1l_l1_ (u"ࠬํฯศใࠪ寗"),l11l1l_l1_ (u"࠭ๅษษิหฮ࠭寘"),l11l1l_l1_ (u"ฺࠧำูࠫ寙"),l11l1l_l1_ (u"ࠨ็๊ีัอๆࠨ寚"),l11l1l_l1_ (u"ࠩส่อ๎ๅࠨ寛"),l11l1l_l1_ (u"ุ้ࠪือ๋หࠪ寜")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		title = title.replace(l11l1l_l1_ (u"ࠫฬ๎ๆࠡๆส๎๋ࠦࠧ寝"),l11l1l_l1_ (u"ࠬ࠭寞")).replace(l11l1l_l1_ (u"࠭ว้่็ห๏์ࠠࠨ察"),l11l1l_l1_ (u"ࠧࠨ寠")).replace(l11l1l_l1_ (u"ࠨ็ืห์ีษࠡࠩ寡"),l11l1l_l1_ (u"ࠩࠪ寢"))
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠪ࠳ࠬ寣"))
		#if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ寤") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ寥")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ實"))
		#if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬ寧") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ寨")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠩ࠲ࠫ審"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ寪"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀา๊โสࠫ࠱ࡠࡩ࠱ࠧ寫"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ寬"),l1111l_l1_+title,l1llll1_l1_,662,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ寭"):
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭寮"),l1111l_l1_+title,l1llll1_l1_,662,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ寯") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ寰"),l1111l_l1_+title,l1llll1_l1_,663,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡶࡴࡧࡵ࡭ࡪࡹ࠯ࠨ寱") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ寲"),l1111l_l1_+title,l1llll1_l1_,661,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ寳"),l1111l_l1_+title,l1llll1_l1_,663,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"࠭࡮ࡦࡹࡢࡩࡵ࡯ࡳࡰࡦࡨࡷࠬ寴"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ寵")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ寶"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ寷"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠪࠧࠬ寸"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭对")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ寺"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭寻"),l1111l_l1_+l11l1l_l1_ (u"ࠧึใะอࠥ࠭导")+title,l1llll1_l1_,661)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ寽"),l11l1l_l1_ (u"ࠩࠪ対"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ寿"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ尀"),url,l11l1l_l1_ (u"ࠬ࠭封"),l11l1l_l1_ (u"࠭ࠧ専"),l11l1l_l1_ (u"ࠧࠨ尃"),l11l1l_l1_ (u"ࠨࠩ射"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨ尅"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡇࡵࡸࠣࠪ࠱࠮ࡄ࠯ࠢࡔࡧࡤࡷࡴࡴࡳࡆࡲ࡬ࡷࡴࡪࡥࡴࡏࡤ࡭ࡳ࠭将"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡹࡥࡳ࡫ࡨࡷ࠲࡮ࡥࡢࡦࡨࡶࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭將"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠬ࠭專")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡪࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ尉"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"ࠧࠤࠩ尊"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ尋"),l1111l_l1_+title,url,663,l1ll1l_l1_,l11l1l_l1_ (u"ࠩࠪ尌"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡘ࡫ࡡࡴࡱࡱࡷࡊࡶࡩࡴࡱࡧࡩࡸࡓࡡࡪࡰ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠫ對")+l1l11_l1_+l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ導"),html,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡦ࡯ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ小"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		#if not items: items = re.findall(l11l1l_l1_ (u"࠭ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ尐"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ少")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠰࠲ࠫ尒"))
			title = title.replace(l11l1l_l1_ (u"ࠩ࠿࠳ࡪࡳ࠾࠽ࡵࡳࡥࡳࡄࠧ尓"),l11l1l_l1_ (u"ࠪࠤࠬ尔"))
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ尕"),l1111l_l1_+title,l1llll1_l1_,662,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠭尖"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ尗") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ尘")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ尙"))
		#		addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ尚"),l1111l_l1_+title,l1llll1_l1_,662,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111ll1_l1_,l1lll11l_l1_ = [],[],[]
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧ尛"),l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ尜"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ尝"),l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ尞"),l11l1l_l1_ (u"ࠧࠨ尟"),l11l1l_l1_ (u"ࠨࠩ尠"),l11l1l_l1_ (u"ࠩࠪ尡"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ尢"))
	html = response.content
	# l1l1111l1_l1_ l1llll1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ尣"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ尤"),block,re.DOTALL)
		if l1llll1_l1_:
			l1llll1_l1_ = l1llll1_l1_[0]
			l1l111ll1_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡧࡰࡦࡪࡪࠧ尥"))
			l1lll1_l1_.append(l1llll1_l1_)
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ尦"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࠲ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡤࡸࡸࡹࡵ࡮࠿ࠩ尧"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ尨")+title+l11l1l_l1_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ尩"))
				l1lll1_l1_.append(l1llll1_l1_)
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࠥࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡲࡩ࡯࡭ࡶࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴ࡼࡩࡥࡧࡲ࠲ࡵ࡮ࡰࠨ࠮ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࡹ࠮ࡱࡪࡳࠫ࠮ࠐࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲ࡵࡳ࡮࠵࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧࠪࠌࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡯࡭ࡳࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠ࡭࡫ࡱ࡯ࡸࡀࠊࠊࠋࠌ࡭࡫ࠦ࡬ࡪࡰ࡮ࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡀࠊࠊࠋࠌࠍࡳࡧ࡭ࡦࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ࠭ࡷ࡭ࡹࡲࡥࠬࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ࠩࠋࠋࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠣࠤࠥ尪")
	l11111_l1_ = zip(l1lll1_l1_,l1l111ll1_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll11l_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ尫"),l1lll11l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll11l_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ尬"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ尭"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ尮"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ尯"),l11l1l_l1_ (u"ࠪ࠯ࠬ尰"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ就")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ尲"))
	#url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ尳")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ尴"))
	return
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࠩ⭨")
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤࡍࡌࡔࡡࠪ⭩")
def MAIN(mode,url,text,l11lll1_l1_):
	if   mode==540: results = MENU()
	elif mode==541: results = l1ll111l111_l1_(text)
	elif mode==542: results = l1l1lllll11_l1_(text,url,l11lll1_l1_)
	elif mode==549: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⭪"),l11l1l_l1_ (u"࠭ศฮอࠣะิ๐ฯࠨ⭫"),l11l1l_l1_ (u"ࠧࠨ⭬"),549)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭⭭"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾ࠢๆ่๊อสࠡ็ัึ๋ฯࠠ࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⭮"),l11l1l_l1_ (u"ࠪࠫ⭯"),9999)
	l1ll11111ll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ⭰"),l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⭱"))
	if l1ll11111ll_l1_:
		l1ll11111ll_l1_ = l1ll11111ll_l1_[l11l1l_l1_ (u"࠭࡟ࡠࡕࡈࡕ࡚ࡋࡎࡄࡇࡇࡣࡈࡕࡌࡖࡏࡑࡗࡤࡥࠧ⭲")]
		for search in reversed(l1ll11111ll_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⭳"),search,l11l1l_l1_ (u"ࠨࠩ⭴"),549,l11l1l_l1_ (u"ࠩࠪ⭵"),l11l1l_l1_ (u"ࠪࠫ⭶"),search)
	return
def SEARCH(search):
	#search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1llll11l_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	l1lll11l111_l1_ = search.replace(l1111l_l1_,l11l1l_l1_ (u"ࠫࠬ⭷"))
	l1l1lll1l11_l1_(l1lll11l111_l1_)
	#l1l1ll1llll_l1_ = search+options+l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⭸")
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ⭹"),l11l1l_l1_ (u"ฺࠧ็็ࠤอำหࠡฮ่ห฾๐ࠠ࠮ࠢࠪ⭺")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡵ࡬ࡸࡪࡹࠧ⭻"),542,l11l1l_l1_ (u"ࠩࠪ⭼"),l11l1l_l1_ (u"ࠪࠫ⭽"),l1lll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ⭾"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⭿"),l11l1l_l1_ (u"࠭ࠧ⮀"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⮁"),l11l1l_l1_ (u"ࠨ่อหหาࠠศๆหัะࠦๅโื็อࠥ࠳ࠠࠨ⮂")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࡲࡴࡪࡴࡥࡥࡡࡶ࡭ࡹ࡫ࡳࠨ⮃"),542,l11l1l_l1_ (u"ࠪࠫ⮄"),l11l1l_l1_ (u"ࠫࠬ⮅"),l1lll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⮆"),l11l1l_l1_ (u"࠭ๆหษษะࠥอไษฯฮࠤ๊่ำๆหࠣ࠱ࠥ࠭⮇")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⮈"),542,l11l1l_l1_ (u"ࠨࠩ⮉"),l11l1l_l1_ (u"ࠩࠪ⮊"),l1lll11l111_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⮋"),l11l1l_l1_ (u"ࠫอำหࠡ็้ๅึีࠠ࠮ࠢࠪ⮌")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠬ࠭⮍"),541,l11l1l_l1_ (u"࠭ࠧ⮎"),l11l1l_l1_ (u"ࠧࠨ⮏"),l1lll11l111_l1_)
	return
def l1l1lll1l11_l1_(l1ll111ll1l_l1_):
	l1ll111llll_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⮐"),l11l1l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡌࡘࡊ࡙ࠧ⮑"),l1ll111ll1l_l1_)
	l1ll111lll1_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ⮒"),l11l1l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩ⮓"),l1111l_l1_+l1ll111ll1l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪ⮔"),l1ll111ll1l_l1_)
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮕"),l1111l_l1_+l1ll111ll1l_l1_)
	old_value = l1ll111llll_l1_+l1ll111lll1_l1_
	if old_value: l1ll111ll1l_l1_ = l1111l_l1_+l1ll111ll1l_l1_
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡊࡖࡈࡗࠬ⮖"),l1ll111ll1l_l1_,old_value,VERYLONG_CACHE)
	return
def l1l1llll111_l1_():
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠨࠩ⮗"),l11l1l_l1_ (u"ࠩࠪ⮘"),l11l1l_l1_ (u"ࠪࠫ⮙"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⮚"),l11l1l_l1_ (u"ࠬํไࠡฬิ๎ิࠦๅิฯࠣะ๊๐ูࠡๅ็้ฬะࠠศๆหัะࠦวๅ็ัึ๋ฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠡࠢࠩ⮛"))
	if l1ll111111_l1_!=1: return
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫ⮜"))
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡏࡑࡇࡑࡉࡉ࠭⮝"))
	DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡄࡎࡒࡗࡊࡊࠧ⮞"))
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ⮟"),l11l1l_l1_ (u"ࠪࠫ⮠"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⮡"),l11l1l_l1_ (u"ࠬะๅࠡส้ะฬำࠠๆีะࠤัฺ๋๊ࠢๆ่๊อสࠡษ็ฬาัࠠศๆ่าื์ษࠡใํࠤฬ๊ศา่ส้ั࠭⮢"))
	return
def l1l1lllll11_l1_(l1l1llll11l_l1_,action,l1l1llllll1_l1_=l11l1l_l1_ (u"࠭ࠧ⮣")):
	l1l1lllllll_l1_,l1ll1111111_l1_,l1ll1111l1l_l1_,l1l1ll1ll1l_l1_,l1l1lll1111_l1_,l1ll1111l11_l1_,threads = [],[],[],{},{},{},{}
	if action!=l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡴ࡫ࡷࡩࡸ࠭⮤"):
		if action==l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧ⮥"): l1ll1111l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ⮦"),l11l1l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡖࡍ࡙ࡋࡓࠨ⮧"),l1111l_l1_+l1l1llll11l_l1_)
		elif action==l11l1l_l1_ (u"ࠫࡴࡶࡥ࡯ࡧࡧࡣࡸ࡯ࡴࡦࡵࠪ⮨"): l1ll1111l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ⮩"),l11l1l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤࡕࡐࡆࡐࡈࡈࠬ⮪"),l1l1llll11l_l1_)
		elif action==l11l1l_l1_ (u"ࠧࡤ࡮ࡲࡷࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭⮫"): l1ll1111l1l_l1_ = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹ࠭⮬"),l11l1l_l1_ (u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡅࡏࡓࡘࡋࡄࠨ⮭"),(l1l1llllll1_l1_,l1l1llll11l_l1_))
	if not l1ll1111l1l_l1_:
		l1ll111l11l_l1_ = l11l1l_l1_ (u"๋ࠪีอࠠศๆหัะฺ๋ࠦำ้ࠣํา่ะࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤࡡࡴ࡜࡯࡞ࡱࠫ⮮")
		l1ll111l1l1_l1_ = l11l1l_l1_ (u"ࠫ์๊ࠠหำํำࠥอไร่ࠣห้ฮอฬࠢไ๎ࠥาๅ๋฻ࠣห้๋่ศไ฼ࠤ฾์ࠠ࡝ࡰࠣࠦࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠠࠨ⮯")+l1l1llll11l_l1_+l11l1l_l1_ (u"࡛ࠬࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠣࠢ࡟ࡲࠥ฿ไๆษࠣว๋ࠦ็ัษࠣห้ฮอฬࠢๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠧ⮰")
		if action==l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡳࡪࡶࡨࡷࠬ⮱"): message = l1ll111l1l1_l1_
		else: message = l1ll111l11l_l1_+l1ll111l1l1_l1_
		l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࠨ⮲"),l11l1l_l1_ (u"ࠨࠩ⮳"),l11l1l_l1_ (u"ࠩࠪ⮴"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⮵"),message)
		if l1ll111111_l1_!=1: return
		LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⮶"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩ⮷")+l1l1llll11l_l1_+l11l1l_l1_ (u"࠭ࠠ࡞ࠩ⮸"))
		#global menuItemsLIST
		import threading
		#l1ll11111l1_l1_ = [l11l1l_l1_ (u"ࠧࡂࡍ࡚ࡅࡒ࠭⮹"),l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ⮺"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪ⮻")]
		l1ll11l1l11_l1_ = 1
		for l1l1llllll1_l1_ in l1ll11111l1_l1_:
			l1l1ll1ll1l_l1_[l1l1llllll1_l1_] = []
			options = l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ⮼")
			if l11l1l_l1_ (u"ࠫ࠲࠭⮽") in l1l1llllll1_l1_: options = options+l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࠪ⮾")+l1l1llllll1_l1_+l11l1l_l1_ (u"࠭࡟ࠨ⮿")
			l1l1lll1l1l_l1_,l1l1lllll1l_l1_,l1ll11l11ll_l1_ = l1l1lll111l_l1_(l1l1llllll1_l1_)
			if l1ll11l1l11_l1_:
				threads[l1l1llllll1_l1_] = threading.Thread(target=l1l1lllll1l_l1_,args=(l1l1llll11l_l1_+options,))
				threads[l1l1llllll1_l1_].start()
			else: l1l1lllll1l_l1_(l1l1llll11l_l1_+options)
			l1llll1l_l1_(TRANSLATE(l1l1llllll1_l1_),l11l1l_l1_ (u"ࠧࠨ⯀"),time=1000)
		if l1ll11l1l11_l1_:
			time.sleep(2)
			for l1l1llllll1_l1_ in l1ll11111l1_l1_:
				threads[l1l1llllll1_l1_].join(10)
			time.sleep(2)
		#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ⯁"),l11l1l_l1_ (u"ࠩࠪ⯂"),l11l1l_l1_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠢࡩࡳࡺࡴࡤࡦࡦ࠽ࠫ⯃"),str(len(menuItemsLIST)))
		for l1l1llllll1_l1_ in l1ll11111l1_l1_:
			l1l1lll1l1l_l1_,l1l1lllll1l_l1_,l1ll11l11ll_l1_ = l1l1lll111l_l1_(l1l1llllll1_l1_)
			for l1l1llll1ll_l1_ in menuItemsLIST:
				type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_ = l1l1llll1ll_l1_
				if l1ll11l11ll_l1_ in name:
					if l11l1l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࠪ⯄") in l1l1llllll1_l1_ and (239>=mode>=230 or 289>=mode>=280):
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡐࡎ࡜ࡅࠨ⯅")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡒࡕࡖࡊࡇࡖࠫ⯆")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ⯇")]: continue
						if l11l1l_l1_ (u"ࠨืไัฮ࠭⯈") not in name:
							if   type==l11l1l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⯉"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭⯊")
							elif type==l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ⯋"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠬࡏࡐࡕࡘ࠰ࡑࡔ࡜ࡉࡆࡕࠪ⯌")
							elif type==l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⯍"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚࠲࡙ࡅࡓࡋࡈࡗࠬ⯎")
						else:
							if   l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࠭⯏") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ⯐")
							elif l11l1l_l1_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪ⯑") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ⯒")
							elif l11l1l_l1_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬ⯓") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"࠭ࡉࡑࡖ࡙࠱ࡘࡋࡒࡊࡇࡖࠫ⯔")
					elif l11l1l_l1_ (u"ࠧࡎ࠵ࡘ࠱ࠬ⯕") in l1l1llllll1_l1_ and 729>=mode>=710:
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠨࡏ࠶࡙࠲ࡒࡉࡗࡇࠪ⯖")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠩࡐ࠷࡚࠳ࡍࡐࡘࡌࡉࡘ࠭⯗")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯘")]: continue
						if l11l1l_l1_ (u"ฺࠫ็อสࠩ⯙") not in name:
							if   type==l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ⯚"): l1l1llllll1_l1_ = l11l1l_l1_ (u"࠭ࡍ࠴ࡗ࠰ࡐࡎ࡜ࡅࠨ⯛")
							elif type==l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⯜"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ⯝")
							elif type==l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⯞"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠪࡑ࠸࡛࠭ࡔࡇࡕࡍࡊ࡙ࠧ⯟")
						else:
							if   l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࠩ⯠") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ⯡")
							elif l11l1l_l1_ (u"࠭ࡍࡐࡘࡌࡉࡘ࠭⯢") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠧࡎ࠵ࡘ࠱ࡒࡕࡖࡊࡇࡖࠫ⯣")
							elif l11l1l_l1_ (u"ࠨࡕࡈࡖࡎࡋࡓࠨ⯤") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭⯥")
					elif l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࠬ⯦") in l1l1llllll1_l1_ and 149>=mode>=140:
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ⯧")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⯨")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯩")]: continue
						if l11l1l_l1_ (u"ࠧึใะอࠥษฮา๋ࠪ⯪") in name or l11l1l_l1_ (u"ࠨ࠼࠽ࠤࠬ⯫") in name:
							continue
							#if   l111_l1_==l11l1l_l1_ (u"ࠩࡆࡌࡆࡔࡎࡆࡎࡖࠫ⯬"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⯭")
							#elif l111_l1_==l11l1l_l1_ (u"ࠫࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧ⯮"): l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⯯")
							#else: l1l1llllll1_l1_ = l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯰")
						else:
							if   mode==144 and l11l1l_l1_ (u"ࠧࡖࡕࡈࡖࠬ⯱") in name: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ⯲")
							elif mode==144 and l11l1l_l1_ (u"ࠩࡆࡌࡓࡒࠧ⯳") in name: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⯴")
							elif mode==144 and l11l1l_l1_ (u"ࠫࡑࡏࡓࡕࠩ⯵") in name: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⯶")
							elif mode==143: l1l1llllll1_l1_ = l11l1l_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ⯷")
							else: continue
					elif l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠭⯸") in l1l1llllll1_l1_ and 419>=mode>=400:
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩ⯹")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ⯺")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡘࡌࡈࡊࡕࡓࠨ⯻")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡗࡓࡕࡏࡃࡔࠩ⯼")]: continue
						if   mode in [401,405]: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭⯽")
						elif mode in [402,406]: l1l1llllll1_l1_ = l11l1l_l1_ (u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭⯾")
						elif mode in [403,404]: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࡜ࡉࡅࡇࡒࡗࠬ⯿")
						elif mode in [412,413]: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡔࡐࡒࡌࡇࡘ࠭Ⰰ")
					elif l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࠩⰁ") in l1l1llllll1_l1_ and 39>=mode>=30:
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡗࡏࡅࡔࠩⰂ")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡑࡔ࡜ࡉࡆࡕࠪⰃ")]: continue
						if   mode in [32,39]: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡘࡋࡒࡊࡇࡖࠫⰄ")
						elif mode in [33,39]: l1l1llllll1_l1_ = l11l1l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡓࡏࡗࡋࡈࡗࠬⰅ")
					elif l11l1l_l1_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࠧⰆ") in l1l1llllll1_l1_ and 29>=mode>=20:
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡂࡔࡄࡆࡎࡉࠧⰇ")]: continue
						if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l11l1l_l1_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࠩⰈ")]: continue
						if   l11l1l_l1_ (u"ࠪ࠳ࡦࡸ࠮ࠨⰉ") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪⰊ")
						elif l11l1l_l1_ (u"ࠬ࠵ࡥ࡯࠰ࠪⰋ") in url: l1l1llllll1_l1_ = l11l1l_l1_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡋࡎࡈࡎࡌࡗࡍ࠭Ⰼ")
					#elif l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࠫⰍ") in l1l1llllll1_l1_ and 319>=mode>=310:
					#	if l1l1llll1ll_l1_ in l1l1ll1ll1l_l1_[l1l1llllll1_l1_]: continue
					#	if mode==312: l1l1llllll1_l1_ = l1l1lll1ll1_l1_+l11l1l_l1_ (u"ࠨ࠯ࡄ࡙ࡉࡏࡏࡔࠩⰎ")
					#	elif l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺ࠭ࠨⰏ") in url: l1l1llllll1_l1_ = l1l1lll1ll1_l1_+l11l1l_l1_ (u"ࠪ࠱ࡆࡒࡂࡖࡏࡖࠫⰐ")
					#	else: l1l1llllll1_l1_ = l1l1lll1ll1_l1_+l11l1l_l1_ (u"ࠫ࠲ࡖࡅࡓࡕࡒࡒࡘ࠭Ⱁ")
					l1l1ll1ll1l_l1_[l1l1llllll1_l1_].append(l1l1llll1ll_l1_)
		menuItemsLIST[:] = []
		for l1l1llllll1_l1_ in list(l1l1ll1ll1l_l1_.keys()):
			l1l1lll1111_l1_[l1l1llllll1_l1_] = []
			l1ll1111l11_l1_[l1l1llllll1_l1_] = []
			for type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_ in l1l1ll1ll1l_l1_[l1l1llllll1_l1_]:
				l1l1llll1ll_l1_ = (type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_)
				if l11l1l_l1_ (u"ࠬ฻แฮหࠪⰒ") in name and type==l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ⱃ"): l1ll1111l11_l1_[l1l1llllll1_l1_].append(l1l1llll1ll_l1_)
				else: l1l1lll1111_l1_[l1l1llllll1_l1_].append(l1l1llll1ll_l1_)
		l1ll1111lll_l1_ = [(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬⰔ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠ้ํอโฺࠢึ๎ึ็ัศฬࠣาฬ฻ษࠡ࠯ࠣๆ้๐ไสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰕ"),l11l1l_l1_ (u"ࠩࠪⰖ"),157,l11l1l_l1_ (u"ࠪࠫⰗ"),l11l1l_l1_ (u"ࠫࠬⰘ"),l11l1l_l1_ (u"ࠬ࠭Ⱉ"),l11l1l_l1_ (u"࠭ࠧⰚ"),l11l1l_l1_ (u"ࠧࠨⰛ"))]
		for l1l1llllll1_l1_ in l1ll111111l_l1_:
			if l1l1llllll1_l1_==l1l1lll1lll_l1_[0]: l1ll1111lll_l1_ = [(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭Ⱌ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡ๊๎วใ฻ࠣื๏ืแาษอࠤำอีส๋ࠢ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆ࡞࠳ࡈࡕࡌࡐࡔࡠࠫⰝ"),l11l1l_l1_ (u"ࠪࠫⰞ"),157,l11l1l_l1_ (u"ࠫࠬⰟ"),l11l1l_l1_ (u"ࠬ࠭Ⱐ"),l11l1l_l1_ (u"࠭ࠧⰡ"),l11l1l_l1_ (u"ࠧࠨⰢ"),l11l1l_l1_ (u"ࠨࠩⰣ"))]
			elif l1l1llllll1_l1_==l1ll11l1111_l1_[0]: l1ll1111lll_l1_ = [(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧⰤ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ๋่ศไ฼ࠤุ๐ัโำสฮࠥ฿วๆหࠣ࠱้ࠥห๋ำฬࠤฬ๊ๅีษๆ่ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ⱕ"),l11l1l_l1_ (u"ࠫࠬⰦ"),157,l11l1l_l1_ (u"ࠬ࠭Ⱗ"),l11l1l_l1_ (u"࠭ࠧⰨ"),l11l1l_l1_ (u"ࠧࠨⰩ"),l11l1l_l1_ (u"ࠨࠩⰪ"),l11l1l_l1_ (u"ࠩࠪⰫ"))]
			elif l1l1llllll1_l1_==l1l1ll1lll1_l1_[0]: l1ll1111lll_l1_ = [(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨⰬ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣๅ้ษๅ฽ู๊ࠥาใิหฯࠦฮศืฬࠤ࠲ࠦโๅ์็อࠥอไๆึส็้ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰭ"),l11l1l_l1_ (u"ࠬ࠭Ⱞ"),157,l11l1l_l1_ (u"࠭ࠧⰯ"),l11l1l_l1_ (u"ࠧࠨⰰ"),l11l1l_l1_ (u"ࠨࠩⰱ"),l11l1l_l1_ (u"ࠩࠪⰲ"),l11l1l_l1_ (u"ࠪࠫⰳ"))]
			if l1l1llllll1_l1_ not in l1l1lll1111_l1_.keys(): continue
			if l1l1lll1111_l1_[l1l1llllll1_l1_]:
				l1l1lll11ll_l1_ = TRANSLATE(l1l1llllll1_l1_)
				l1l1llll1l1_l1_ = [(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⰴ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝࠾࠿ࡀࡁࡂࠦࠧⰵ")+l1l1lll11ll_l1_+l11l1l_l1_ (u"࠭ࠠ࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧⰶ"),l11l1l_l1_ (u"ࠧࠨⰷ"),9999,l11l1l_l1_ (u"ࠨࠩⰸ"),l11l1l_l1_ (u"ࠩࠪⰹ"),l11l1l_l1_ (u"ࠪࠫⰺ"),l11l1l_l1_ (u"ࠫࠬⰻ"),l11l1l_l1_ (u"ࠬ࠭ⰼ"))]
				if 0:
					l1ll11l111l_l1_ = l1l1llll11l_l1_+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪⰽ")+l11l1l_l1_ (u"ࠧษฯฮࠫⰾ")+l11l1l_l1_ (u"ࠨࠢࠪⰿ")+l1l1lll11ll_l1_
				else:
					l1ll11l111l_l1_ = l11l1l_l1_ (u"ࠩหัะ࠭ⱀ")+l11l1l_l1_ (u"ࠪࠤࠬⱁ")+l1l1lll11ll_l1_+l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨⱂ")+l1l1llll11l_l1_
				if len(l1l1lll1111_l1_[l1l1llllll1_l1_])<8: l1ll1111ll1_l1_ = []
				else:
					l1ll11l11l1_l1_ = l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨⱃ")+l1ll11l111l_l1_+l11l1l_l1_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨⱄ")
					l1ll1111ll1_l1_ = [(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱅ"),l1111l_l1_+l1ll11l11l1_l1_,l11l1l_l1_ (u"ࠨࡥ࡯ࡳࡸ࡫ࡤࡠࡵ࡬ࡸࡪࡹࠧⱆ"),542,l11l1l_l1_ (u"ࠩࠪⱇ"),l1l1llllll1_l1_,l1l1llll11l_l1_,l11l1l_l1_ (u"ࠪࠫⱈ"),l11l1l_l1_ (u"ࠫࠬⱉ"))]
				l1ll111l1ll_l1_ = l1l1lll1111_l1_[l1l1llllll1_l1_]+l1ll1111l11_l1_[l1l1llllll1_l1_]
				l1ll1111111_l1_ += l1ll1111lll_l1_+l1l1llll1l1_l1_+l1ll111l1ll_l1_[:7]+l1ll1111ll1_l1_
				l1l1lll11l1_l1_ = [(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱊ"),l1111l_l1_+l1ll11l111l_l1_,l11l1l_l1_ (u"࠭ࡣ࡭ࡱࡶࡩࡩࡥࡳࡪࡶࡨࡷࠬⱋ"),542,l11l1l_l1_ (u"ࠧࠨⱌ"),l1l1llllll1_l1_,l1l1llll11l_l1_,l11l1l_l1_ (u"ࠨࠩⱍ"),l11l1l_l1_ (u"ࠩࠪⱎ"))]
				l1l1lllllll_l1_ += l1ll1111lll_l1_+l1l1lll11l1_l1_
				l1ll1111lll_l1_ = []
				WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡋࡑࡕࡂࡂࡎࡖࡉࡆࡘࡃࡉࡡࡆࡐࡔ࡙ࡅࡅࠩⱏ"),(l1l1llllll1_l1_,l1l1llll11l_l1_),l1ll111l1ll_l1_,VERYLONG_CACHE)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡓࡕࡋࡎࡆࡆࠪⱐ"),l1l1llll11l_l1_,l1ll1111111_l1_,VERYLONG_CACHE)
		DELETE_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡍࡌࡐࡄࡄࡐࡘࡋࡁࡓࡅࡋࡣࡘࡏࡔࡆࡕࠪⱑ"),l1l1llll11l_l1_)
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡇࡍࡑࡅࡅࡑ࡙ࡅࡂࡔࡆࡌࡤ࡙ࡉࡕࡇࡖࠫⱒ"),l1111l_l1_+l1l1llll11l_l1_,l1l1lllllll_l1_,VERYLONG_CACHE)
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨⱓ"),l11l1l_l1_ (u"ࠨࠩⱔ"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⱕ"),l11l1l_l1_ (u"ࠪห้ฮอฬࠢส่ั๋วฺ์ࠣห๋ะ็๊ࠢห๊ัออࠡ࡞ࡱࡠࡳࠦสๆࠢอาื๐ๆࠡษ็๊ฯอฦอࠢไ๎้ࠥวีࠢส่อืๆศ็ฯࠤ้๋ฯสࠢฮ่ฬั๊็ࠢํ์๊ࠦไไ์ࠣฮุะื๋฻ࠣห้฿่ะหࠣษ้๐็ศࠢหำํ์ฺࠠ็็ࠤอำหࠡฮา๎ิ࠭ⱖ"))
		if action==l11l1l_l1_ (u"ࠫࡱ࡯ࡳࡵࡧࡧࡣࡸ࡯ࡴࡦࡵࠪⱗ") and l1l1lllllll_l1_: l1ll1111l1l_l1_ = l1l1lllllll_l1_
		else: l1ll1111l1l_l1_ = l1ll1111111_l1_
	if action!=l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡹࡩࡵࡧࡶࠫⱘ"):
		for type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_ in l1ll1111l1l_l1_:
			if action in [l11l1l_l1_ (u"࠭࡬ࡪࡵࡷࡩࡩࡥࡳࡪࡶࡨࡷࠬⱙ"),l11l1l_l1_ (u"ࠧࡰࡲࡨࡲࡪࡪ࡟ࡴ࡫ࡷࡩࡸ࠭ⱚ")] and l11l1l_l1_ (u"ࠨืไัฮ࠭ⱛ") in name and type==l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⱜ"): continue
			addMenuItem(type,name,url,mode,l111_l1_,l11lll1_l1_,text,context,l1ll1l1l1l1_l1_)
	return
def l1ll111l111_l1_(l1l1llll11l_l1_=l11l1l_l1_ (u"ࠪࠫⱝ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(l1l1llll11l_l1_)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
		search = search.lower()
	LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⱞ"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡕࡨࡥࡷࡩࡨࠡࡈࡲࡶ࠿࡛ࠦࠡࠩⱟ")+search+l11l1l_l1_ (u"࠭ࠠ࡞ࠩⱠ"))
	l11111l_l1_ = search+options
	if 0:
		l1ll111ll11_l1_,l1lll11l111_l1_ = search+l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫⱡ"),l11l1l_l1_ (u"ࠨࠩⱢ")
	else:
		l1ll111ll11_l1_,l1lll11l111_l1_ = l11l1l_l1_ (u"ࠩࠪⱣ"),l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧⱤ")+search
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⱥ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ࠳ࠠใๆํ่ฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⱦ"),l11l1l_l1_ (u"࠭ࠧⱧ"),157)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⱨ"),l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧⱩ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦࡍ࠴ࡗࠪⱪ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫⱫ"),719,l11l1l_l1_ (u"ࠫࠬⱬ"),l11l1l_l1_ (u"ࠬ࠭Ɑ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭Ɱ"),l11l1l_l1_ (u"ࠧࡠࡋࡓࡘࡤ࠭Ɐ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯࠥࡏࡐࡕࡘࠪⱰ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪⱱ"),239,l11l1l_l1_ (u"ࠪࠫⱲ"),l11l1l_l1_ (u"ࠫࠬⱳ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⱴ"),l11l1l_l1_ (u"࠭࡟ࡃࡍࡕࡣࠬⱵ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢห็ึอࠧⱶ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠨࠩⱷ"),379,l11l1l_l1_ (u"ࠩࠪⱸ"),l11l1l_l1_ (u"ࠪࠫⱹ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⱺ"),l11l1l_l1_ (u"ࠬࡥࡐࡏࡖࡢࠫⱻ")+l1ll111ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡสส๊๏ะࠧⱼ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠧࠨⱽ"),39,l11l1l_l1_ (u"ࠨࠩⱾ"),l11l1l_l1_ (u"ࠩࠪⱿ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲀ"),l11l1l_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪⲁ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯࠦวโๆส้ࠬⲂ"),l11l1l_l1_ (u"࠭ࠧⲃ"),39,l11l1l_l1_ (u"ࠧࠨⲄ"),l11l1l_l1_ (u"ࠨࠩⲅ"),l11111l_l1_+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡑࡃࡑࡉ࡙࠳ࡍࡐࡘࡌࡉࡘࡥࠧⲆ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲇ"),l11l1l_l1_ (u"ࠫࡤࡖࡎࡕࡡࠪⲈ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษษ้๎ฯࠦๅิๆึ่ฬะࠧⲉ"),l11l1l_l1_ (u"࠭ࠧⲊ"),39,l11l1l_l1_ (u"ࠧࠨⲋ"),l11l1l_l1_ (u"ࠨࠩⲌ"),l11111l_l1_+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟ࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘࡥࠧⲍ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲎ"),l11l1l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪⲏ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠโ์า๎ํํวหࠩⲐ"),l11l1l_l1_ (u"࠭ࠧⲑ"),149,l11l1l_l1_ (u"ࠧࠨⲒ"),l11l1l_l1_ (u"ࠨࠩⲓ"),l11111l_l1_+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࡠࠩⲔ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲕ"),l11l1l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪⲖ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠใ๊สส๊࠭ⲗ"),l11l1l_l1_ (u"࠭ࠧⲘ"),149,l11l1l_l1_ (u"ࠧࠨⲙ"),l11l1l_l1_ (u"ࠨࠩⲚ"),l11111l_l1_+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࡣࠬⲛ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲜ"),l11l1l_l1_ (u"ࠫࡤ࡟ࡕࡕࡡࠪⲝ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭Ⲟ"),l11l1l_l1_ (u"࠭ࠧⲟ"),149,l11l1l_l1_ (u"ࠧࠨⲠ"),l11l1l_l1_ (u"ࠨࠩⲡ"),l11111l_l1_+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥ࡟࡚ࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࡢࠫⲢ"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⲣ"),l11l1l_l1_ (u"ࠫࡤࡑࡌࡂࡡࠪⲤ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠไๆࠣห้฿ัษࠩⲥ")+l1lll11l111_l1_,l11l1l_l1_ (u"࠭ࠧⲦ"),19,l11l1l_l1_ (u"ࠧࠨⲧ"),l11l1l_l1_ (u"ࠨࠩⲨ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⲩ"),l11l1l_l1_ (u"ࠪࡣࡆࡘࡔࡠࠩⲪ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪⲫ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠬ࠭Ⲭ"),739,l11l1l_l1_ (u"࠭ࠧⲭ"),l11l1l_l1_ (u"ࠧࠨⲮ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⲯ"),l11l1l_l1_ (u"ࠩࡢࡏࡗࡈ࡟ࠨⲰ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪⲱ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬⲲ"),329,l11l1l_l1_ (u"ࠬ࠭ⲳ"),l11l1l_l1_ (u"࠭ࠧⲴ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⲵ"),l11l1l_l1_ (u"ࠨࡡࡉࡌ࠶ࡥࠧⲶ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨⲷ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫⲸ"),579,l11l1l_l1_ (u"ࠫࠬⲹ"),l11l1l_l1_ (u"ࠬ࠭Ⲻ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⲻ"),l11l1l_l1_ (u"ࠧࡠࡇࡊࡆࡤ࠭Ⲽ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣห๏า๊ࠡสํืฯ࠭ⲽ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪⲾ"),129,l11l1l_l1_ (u"ࠪࠫⲿ"),l11l1l_l1_ (u"ࠫࠬⳀ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳁ"),l11l1l_l1_ (u"࠭࡟ࡅࡎࡐࡣࠬⳂ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢา๎้๐ࠠๆ๊ื๊ࠥ็๊ะ์๋๋ฬะࠧⳃ"),l11l1l_l1_ (u"ࠨࠩⳄ"),409,l11l1l_l1_ (u"ࠩࠪⳅ"),l11l1l_l1_ (u"ࠪࠫⳆ"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙࡟ࠨⳇ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳈ"),l11l1l_l1_ (u"࠭࡟ࡅࡎࡐࡣࠬⳉ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢา๎้๐ࠠๆ๊ื๊่่ࠥศศ่ࠫⳊ"),l11l1l_l1_ (u"ࠨࠩⳋ"),409,l11l1l_l1_ (u"ࠩࠪⳌ"),l11l1l_l1_ (u"ࠪࠫⳍ"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࡢࠫⳎ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳏ"),l11l1l_l1_ (u"࠭࡟ࡅࡎࡐࡣࠬⳐ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢา๎้๐ࠠๆ๊ื๊่ࠥๆ้ษอࠫⳑ"),l11l1l_l1_ (u"ࠨࠩⳒ"),409,l11l1l_l1_ (u"ࠩࠪⳓ"),l11l1l_l1_ (u"ࠪࠫⳔ"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪⳕ"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳖ"),l11l1l_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬⳗ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠧࠡࠢหัะࠦๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠪⳘ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠨࠢࠣࠫⳙ"),l11l1l_l1_ (u"ࠩࠪⳚ"),29,l11l1l_l1_ (u"ࠪࠫⳛ"),l11l1l_l1_ (u"ࠫࠬⳜ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳝ"),l11l1l_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬⳞ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ฻ิฬ๏࠭ⳟ"),l11l1l_l1_ (u"ࠨࠩⳠ"),29,l11l1l_l1_ (u"ࠩࠪⳡ"),l11l1l_l1_ (u"ࠪࠫⳢ"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࡠࠩⳣ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳤ"),l11l1l_l1_ (u"࠭࡟ࡊࡈࡏࡣࠬ⳥")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡษ้ะ้๐า๋ࠩ⳦"),l11l1l_l1_ (u"ࠨࠩ⳧"),29,l11l1l_l1_ (u"ࠩࠪ⳨"),l11l1l_l1_ (u"ࠪࠫ⳩"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡌࡊࡎࡒࡍ࠮ࡇࡑࡋࡑࡏࡓࡉࡡࠪ⳪"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⳫ"),l11l1l_l1_ (u"࠭࡟ࡂࡍࡒࡣࠬⳬ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨⳭ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠨࠩⳮ"),79,l11l1l_l1_ (u"ࠩࠪ⳯"),l11l1l_l1_ (u"ࠪࠫ⳰"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⳱"),l11l1l_l1_ (u"ࠬࡥࡁࡌ࡙ࡢࠫⳲ")+l1ll111ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡลๆ์ฬ๋ࠠศๆฯำ๏ีࠧⳳ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠧࠨ⳴"),249,l11l1l_l1_ (u"ࠨࠩ⳵"),l11l1l_l1_ (u"ࠩࠪ⳶"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⳷"),l11l1l_l1_ (u"ࠫࡤࡓࡒࡇࠩ⳸")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠใ่สอࠥอไๆ฻สีๆ࠭⳹"),l11l1l_l1_ (u"࠭ࠧ⳺"),49,l11l1l_l1_ (u"ࠧࠨ⳻"),l11l1l_l1_ (u"ࠨࠩ⳼"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⳽"),l11l1l_l1_ (u"ࠪࡣࡘࡎࡍࡠࠩ⳾")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิ้ใ้ࠣฬ้ำࠨ⳿")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠬ࠭ⴀ"),59,l11l1l_l1_ (u"࠭ࠧⴁ"),l11l1l_l1_ (u"ࠧࠨⴂ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴃ"),l11l1l_l1_ (u"ࠩࡢࡊ࡙ࡓ࡟ࠨⴄ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭ⴅ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬⴆ"),69,l11l1l_l1_ (u"ࠬ࠭ⴇ"),l11l1l_l1_ (u"࠭ࠧⴈ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴉ"),l11l1l_l1_ (u"ࠨࡡࡎ࡛࡙ࡥࠧⴊ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ็์วสࠢส่่๎หาࠩⴋ"),l11l1l_l1_ (u"ࠪࠫⴌ"),139,l11l1l_l1_ (u"ࠫࠬⴍ"),l11l1l_l1_ (u"ࠬ࠭ⴎ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⴏ"),l11l1l_l1_ (u"ࠧࡠࡕࡋ࡚ࡤ࠭ⴐ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ูࠣํะࠠศๆื๎฾ฯࠧⴑ"),l11l1l_l1_ (u"ࠩࠪⴒ"),319,l11l1l_l1_ (u"ࠪࠫⴓ"),l11l1l_l1_ (u"ࠫࠬⴔ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴕ"),l11l1l_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬⴖ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦโศำษࠫⴗ"),l11l1l_l1_ (u"ࠨࠩⴘ"),319,l11l1l_l1_ (u"ࠩࠪⴙ"),l11l1l_l1_ (u"ࠪࠫⴚ"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡖࡅࡓࡕࡒࡒࡘࡥࠧⴛ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴜ"),l11l1l_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬⴝ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦๅอๆาࠫⴞ"),l11l1l_l1_ (u"ࠨࠩⴟ"),319,l11l1l_l1_ (u"ࠩࠪⴠ"),l11l1l_l1_ (u"ࠪࠫⴡ"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡌࡃࡗࡐࡗࡤ࠭ⴢ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⴣ"),l11l1l_l1_ (u"࠭࡟ࡔࡊ࡙ࡣࠬⴤ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺุࠢ์ฯࠦวๅึํ฽ฮࠦี้ฬํหฯ࠭ⴥ"),l11l1l_l1_ (u"ࠨࠩ⴦"),319,l11l1l_l1_ (u"ࠩࠪⴧ"),l11l1l_l1_ (u"ࠪࠫ⴨"),l11111l_l1_+l11l1l_l1_ (u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࡡࡖࡌࡎࡇࡖࡐࡋࡆࡉ࠲ࡇࡕࡅࡋࡒࡗࡤ࠭⴩"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⴪"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮฺ่ࠦษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⴫"),l11l1l_l1_ (u"ࠧࠨ⴬"),157)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⴭ"),l11l1l_l1_ (u"ࠩࡢࡏ࡙ࡑ࡟ࠨ⴮")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽้ࠥสไ๊อࠫ⴯")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬⴰ"),679,l11l1l_l1_ (u"ࠬ࠭ⴱ"),l11l1l_l1_ (u"࠭ࠧⴲ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴳ"),l11l1l_l1_ (u"ࠨࡡࡉࡎࡘࡥࠧⴴ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩࠣฬาัࠠๆ๊ๅ฽ࠥ็ฬาࠢื์ࠬⴵ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠪࠤࠬⴶ"),l11l1l_l1_ (u"ࠫࠬⴷ"),399,l11l1l_l1_ (u"ࠬ࠭ⴸ"),l11l1l_l1_ (u"࠭ࠧⴹ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⴺ"),l11l1l_l1_ (u"ࠨࡡࡗ࡚ࡋࡥࠧⴻ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤฯ๐แ๋ࠢไห๋࠭ⴼ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫⴽ"),469,l11l1l_l1_ (u"ࠫࠬⴾ"),l11l1l_l1_ (u"ࠬ࠭ⴿ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⵀ"),l11l1l_l1_ (u"ࠧࡠࡎࡇࡒࡤ࠭ⵁ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻่ࠣํี๊่ࠡอࠫⵂ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪⵃ"),459,l11l1l_l1_ (u"ࠪࠫⵄ"),l11l1l_l1_ (u"ࠫࠬⵅ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⵆ"),l11l1l_l1_ (u"࠭࡟ࡄࡏࡑࡣࠬⵇ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อࠠ็ษ๋ࠫⵈ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠨࠩⵉ"),309,l11l1l_l1_ (u"ࠩࠪⵊ"),l11l1l_l1_ (u"ࠪࠫⵋ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⵌ"),l11l1l_l1_ (u"ࠬࡥࡗࡄࡏࡢࠫⵍ")+l1ll111ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่๊ࠡํࠤุ๐ๅศࠩⵎ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠧࠨⵏ"),569,l11l1l_l1_ (u"ࠨࠩⵐ"),l11l1l_l1_ (u"ࠩࠪⵑ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵒ"),l11l1l_l1_ (u"ࠫࡤ࡙ࡈࡏࡡࠪⵓ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠีษ๊ำࠥ์๊้ิࠪⵔ")+l1lll11l111_l1_,l11l1l_l1_ (u"࠭ࠧⵕ"),589,l11l1l_l1_ (u"ࠧࠨⵖ"),l11l1l_l1_ (u"ࠨࠩⵗ"),l11111l_l1_+l11l1l_l1_ (u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧⵘ"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⵙ"),l11l1l_l1_ (u"ࠫࡤࡓࡃࡎࡡࠪⵚ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠๆษํࠤุ๐ๅศࠩⵛ")+l1lll11l111_l1_,l11l1l_l1_ (u"࠭ࠧⵜ"),369,l11l1l_l1_ (u"ࠧࠨⵝ"),l11l1l_l1_ (u"ࠨࠩⵞ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⵟ"),l11l1l_l1_ (u"ࠪࡣࡘࡎࡐࡠࠩⵠ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦิ้ใࠣฬึ๎ࠧⵡ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠬ࠭ⵢ"),489,l11l1l_l1_ (u"࠭ࠧⵣ"),l11l1l_l1_ (u"ࠧࠨⵤ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⵥ"),l11l1l_l1_ (u"ࠩࡢࡅࡗ࡙࡟ࠨⵦ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ฿ัษࠢึ๎๏ีࠧⵧ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬ⵨"),259,l11l1l_l1_ (u"ࠬ࠭⵩"),l11l1l_l1_ (u"࠭ࠧ⵪"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⵫"),l11l1l_l1_ (u"ࠨࡡࡆ࠸࡚ࡥࠧ⵬")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢไ์ึ๐่ࠨ⵭")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫ⵮"),429,l11l1l_l1_ (u"ࠫࠬⵯ"),l11l1l_l1_ (u"ࠬ࠭⵰"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵱"),l11l1l_l1_ (u"ࠧࡠࡕࡋ࠸ࡤ࠭⵲")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ุࠣฬํฯࠡใ๋ี๏๎ࠧ⵳")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪ⵴"),119,l11l1l_l1_ (u"ࠪࠫ⵵"),l11l1l_l1_ (u"ࠫࠬ⵶"),l11111l_l1_+l11l1l_l1_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ⵷"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⵸"),l11l1l_l1_ (u"ࠧࡠࡏ࠷࡙ࡤ࠭⵹")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻้ࠣํ็าࠡใ๋ี๏๎ࠧ⵺"),l11l1l_l1_ (u"ࠩࠪ⵻"),389,l11l1l_l1_ (u"ࠪࠫ⵼"),l11l1l_l1_ (u"ࠫࠬ⵽"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⵾"),l11l1l_l1_ (u"࠭࡟ࡆࡉ࡙ࡣ⵿ࠬ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢศ๎ั๐ࠠษ์ึฮࠥࡼࡩࡱࠩⶀ"),l11l1l_l1_ (u"ࠨࠩⶁ"),229,l11l1l_l1_ (u"ࠩࠪⶂ"),l11l1l_l1_ (u"ࠪࠫⶃ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩⶄ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ๆ๊สๆ฾ࠦำ๋ำไีฬะฺࠠษ่อࠥ࠳ࠠไอํีฮࠦวๅ็ืห่๊࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨⶅ"),l11l1l_l1_ (u"࠭ࠧⶆ"),157)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶇ"),l11l1l_l1_ (u"ࠨࡡࡏࡖ࡟ࡥࠧⶈ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤ้อั้ิสࠫⶉ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫⶊ"),709,l11l1l_l1_ (u"ࠫࠬⶋ"),l11l1l_l1_ (u"ࠬ࠭ⶌ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⶍ"),l11l1l_l1_ (u"ࠧࡠࡈࡖࡘࡤ࠭ⶎ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅํูสศࠩⶏ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪⶐ"),609,l11l1l_l1_ (u"ࠪࠫⶑ"),l11l1l_l1_ (u"ࠫࠬⶒ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶓ"),l11l1l_l1_ (u"࠭࡟ࡇࡄࡎࡣࠬⶔ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢไฬึ้ษࠨⶕ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠨࠩⶖ"),629,l11l1l_l1_ (u"ࠩࠪ⶗"),l11l1l_l1_ (u"ࠪࠫ⶘"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⶙"),l11l1l_l1_ (u"ࠬࡥ࡙ࡒࡖࡢࠫ⶚")+l1ll111ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡ์สๆํะࠧ⶛")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠧࠨ⶜"),669,l11l1l_l1_ (u"ࠨࠩ⶝"),l11l1l_l1_ (u"ࠩࠪ⶞"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⶟"),l11l1l_l1_ (u"ࠫࡤࡈࡒࡔࡡࠪⶠ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠษำึฮ๏าࠧⶡ")+l1lll11l111_l1_,l11l1l_l1_ (u"࠭ࠧⶢ"),659,l11l1l_l1_ (u"ࠧࠨⶣ"),l11l1l_l1_ (u"ࠨࠩⶤ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⶥ"),l11l1l_l1_ (u"ࠪࡣࡍࡒࡃࡠࠩⶦ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨ⶧")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠬ࠭ⶨ"),89,l11l1l_l1_ (u"࠭ࠧⶩ"),l11l1l_l1_ (u"ࠧࠨⶪ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⶫ"),l11l1l_l1_ (u"ࠩࡢࡈࡗ࠽࡟ࠨⶬ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥีัศ็สࠤฺำࠧⶭ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬⶮ"),689,l11l1l_l1_ (u"ࠬ࠭⶯"),l11l1l_l1_ (u"࠭ࠧⶰ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⶱ"),l11l1l_l1_ (u"ࠨࡡࡆࡑࡋࡥࠧⶲ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧⶳ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫⶴ"),99,l11l1l_l1_ (u"ࠫࠬⶵ"),l11l1l_l1_ (u"ࠬ࠭ⶶ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⶷"),l11l1l_l1_ (u"ࠧࡠࡅࡐࡐࡤ࠭ⶸ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ⶹ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪⶺ"),479,l11l1l_l1_ (u"ࠪࠫⶻ"),l11l1l_l1_ (u"ࠫࠬⶼ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⶽ"),l11l1l_l1_ (u"࠭࡟ࡂࡄࡇࡣࠬⶾ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢึ๎๊อฺࠠสา์ࠬ⶿")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠨࠩⷀ"),559,l11l1l_l1_ (u"ࠩࠪⷁ"),l11l1l_l1_ (u"ࠪࠫⷂ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷃ"),l11l1l_l1_ (u"ࠬࡥࡃ࠵ࡊࡢࠫⷄ")+l1ll111ll11_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪⷅ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠧࠨⷆ"),699,l11l1l_l1_ (u"ࠨࠩ⷇"),l11l1l_l1_ (u"ࠩࠪⷈ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷉ"),l11l1l_l1_ (u"ࠫࡤࡇࡈࡌࡡࠪⷊ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫⷋ")+l1lll11l111_l1_,l11l1l_l1_ (u"࠭ࠧⷌ"),619,l11l1l_l1_ (u"ࠧࠨⷍ"),l11l1l_l1_ (u"ࠨࠩⷎ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⷏"),l11l1l_l1_ (u"ࠪࡣࡈࡉࡂࡠࠩⷐ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ࠦำ๋็สࠤ่๊่ษࠩⷑ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠬ࠭ⷒ"),639,l11l1l_l1_ (u"࠭ࠧⷓ"),l11l1l_l1_ (u"ࠧࠨⷔ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷕ"),l11l1l_l1_ (u"ࠩࡢࡗࡍ࡚࡟ࠨⷖ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩ⷗")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬⷘ"),649,l11l1l_l1_ (u"ࠬ࠭ⷙ"),l11l1l_l1_ (u"࠭ࠧⷚ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷛ"),l11l1l_l1_ (u"ࠨࡡࡈࡋࡓࡥࠧⷜ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭ⷝ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫⷞ"),439,l11l1l_l1_ (u"ࠫࠬ⷟"),l11l1l_l1_ (u"ࠬ࠭ⷠ"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷡ"),l11l1l_l1_ (u"ࠧࡠࡈࡋ࠶ࡤ࠭ⷢ")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻ࠣๅฬ฻ไࠡษ็ฯฬ์๊ࠨⷣ")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠩࠪⷤ"),599,l11l1l_l1_ (u"ࠪࠫⷥ"),l11l1l_l1_ (u"ࠫࠬⷦ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷧ"),l11l1l_l1_ (u"࠭࡟ࡆࡉࡇࡣࠬⷨ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠧษฯฮࠤ๊๎โฺࠢศ๎ั๐ࠠะ์าࠫⷩ"),l11l1l_l1_ (u"ࠨࠩⷪ"),449,l11l1l_l1_ (u"ࠩࠪⷫ"),l11l1l_l1_ (u"ࠪࠫⷬ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫⷭ"),l11l1l_l1_ (u"ࠬࡥࡁࡌࡅࡢࠫⷮ")+l1lll11l111_l1_+l11l1l_l1_ (u"࠭ศฮอ้ࠣํู่ࠡษๆ์ฬ๋ࠠไษ่ࠫⷯ"),l11l1l_l1_ (u"ࠧࠨⷰ"),359,l11l1l_l1_ (u"ࠨࠩⷱ"),l11l1l_l1_ (u"ࠩࠪⷲ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷳ"),l11l1l_l1_ (u"ࠫࡤࡉࡍࡄࡡࠪⷴ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠬฮอฬ่ࠢ์็฿ࠠิ์่ห้ࠥไ้สࠪⷵ"),l11l1l_l1_ (u"࠭ࠧⷶ"),499,l11l1l_l1_ (u"ࠧࠨⷷ"),l11l1l_l1_ (u"ࠨࠩⷸ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷹ"),l11l1l_l1_ (u"ࠪࡣࡆࡘࡌࡠࠩⷺ")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠫอำหࠡ็๋ๆ฾ูࠦาส่ࠣ๏๎ๆำࠩⷻ"),l11l1l_l1_ (u"ࠬ࠭ⷼ"),209,l11l1l_l1_ (u"࠭ࠧⷽ"),l11l1l_l1_ (u"ࠧࠨⷾ"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷿ"),l11l1l_l1_ (u"ࠩࡢࡌࡊࡒ࡟ࠨ⸀")+l1lll11l111_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥํไศๆࠣ๎ํะ๊้สࠪ⸁"),l11l1l_l1_ (u"ࠫࠬ⸂"),99,l11l1l_l1_ (u"ࠬ࠭⸃"),l11l1l_l1_ (u"࠭ࠧ⸄"),l11111l_l1_)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸅"),l11l1l_l1_ (u"ࠨࡡࡖࡊ࡜ࡥࠧ⸆")+search+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤุ๐ั๋ีࠣๅํื้ࠠฬืࠫ⸇"),l11l1l_l1_ (u"ࠪࠫ⸈"),218,l11l1l_l1_ (u"ࠫࠬ⸉"),l11l1l_l1_ (u"ࠬ࠭⸊"),search) # 219
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⸋"),l11l1l_l1_ (u"ࠧࡠࡏ࡙࡞ࡤ࠭⸌")+search+l11l1l_l1_ (u"ࠨสะฯ๋่ࠥใ฻้ࠣํ็๊ำࠢ็ห๋ีࠧ⸍"),l11l1l_l1_ (u"ࠩࠪ⸎"),188,l11l1l_l1_ (u"ࠪࠫ⸏"),l11l1l_l1_ (u"ࠫࠬ⸐"),search)# 189
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ⸑"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞็๋ห็฿ࠠิ์ิๅึอสࠡะสูฮࠦ࠭ࠡไ็๎้ฯࠠศๆุ่ฬ้ไ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⸒"),l11l1l_l1_ (u"ࠧࠨ⸓"),157)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸔"),l11l1l_l1_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ⸕")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠪฬาัࠠๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬ⸖")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠫࠬ⸗"),149,l11l1l_l1_ (u"ࠬ࠭⸘"),l11l1l_l1_ (u"࠭ࠧ⸙"),l11111l_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸚"),l11l1l_l1_ (u"ࠨࡡࡇࡐࡒࡥࠧ⸛")+l1ll111ll11_l1_+l11l1l_l1_ (u"ࠩหัะࠦๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์ࠧ⸜")+l1lll11l111_l1_,l11l1l_l1_ (u"ࠪࠫ⸝"),409,l11l1l_l1_ (u"ࠫࠬ⸞"),l11l1l_l1_ (u"ࠬ࠭⸟"),l11111l_l1_)
	return
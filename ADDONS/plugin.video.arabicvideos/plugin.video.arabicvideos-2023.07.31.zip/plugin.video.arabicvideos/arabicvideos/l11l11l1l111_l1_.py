# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ弉")
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ弊")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
#headers = l11l1l_l1_ (u"࠭ࠧ弋")
#headers = {l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ弌"):l11l1l_l1_ (u"ࠨࠩ弍")}
def MAIN(mode,url,text,type,l11lll1_l1_):
	if	 mode==140: results = MENU()
	#elif mode==141: results = l11llll11l_l1_(url)
	#elif mode==142: results = l11l11l11l11_l1_(url,text)
	elif mode==143: results = PLAY(url,type)
	elif mode==144: results = ITEMS(url,text,l11lll1_l1_)
	elif mode==145: results = l11l1ll11111_l1_(url)
	elif mode==146: results = l11l111lll1l_l1_(url)
	elif mode==147: results = l11l1l11ll11_l1_()
	elif mode==148: results = l11l1l11lll1_l1_()
	elif mode==149: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	#url = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂࡖࡌࡅ࠵࡛ࡧ࡝ࡑࡂࡖࡵࡽࡰࡇࡺࡍࡔࡹࡉࡪ࡟ࡠࡖࡕࡎࡓࡏࡿࢀࡰࡳࡺࡒࡗࠬ弎")
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ式"),l1111l_l1_+l11l1l_l1_ (u"࡙ࠫࡋࡓࡕࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠪ弐"),url,144)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弑"),l1111l_l1_+l11l1l_l1_ (u"࠭࡯࡭ࡦࡨࡶࠥࡶ࡬ࡢࡻ࡯࡭ࡸࡺࠠ࡯ࡱࡷࠤࡱ࡯ࡳࡵ࡫ࡱ࡫ࠥࡴࡥࡸࡧࡵࠤࡵࡲࡹࡢ࡮࡬ࡷࡹ࠭弒"),l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁ࡝ࡌࡰࡲࡧ࡜ࡾ࡝ࡠࡦ࡬ࠨ࡯࡭ࡸࡺ࠽ࡓࡆࡔࡑ࠻࠹ࡶࡉ࡬ࡓ࠴࡭࡫ࡔࡴࠩ弓"),144)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弔"),l1111l_l1_+l11l1l_l1_ (u"่ࠩ์็฿ࠠโษิ฾ࠬ引"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࡛ࡃࡵࡑࡹࡳࡳࡰ࠴ࡈࡻࡲࡴࡒ࡚ࡍࡃࡣ࠵࠷ࡶ࡛ࡣࡸࠩ弖"),144)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弗"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ弘"),l11l1l_l1_ (u"࠭ࠧ弙"),149,l11l1l_l1_ (u"ࠧࠨ弚"),l11l1l_l1_ (u"ࠨࠩ弛"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭弜"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ弝"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭弞")+l11l1l_l1_ (u"ࠬࡥ࡙ࡕࡅࡢࠫ弟")+l11l1l_l1_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬࠦวๅ็หี๊าࠧ张"),l11l1l_l1_ (u"ࠧࠨ弡"),290)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ弢"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弣")+l1111l_l1_+l11l1l_l1_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣ๎ํะ๊้สࠪ弤"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲࡫ࡺ࡯ࡤࡦࡡࡥࡹ࡮ࡲࡤࡦࡴࠪ弥"),144)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弦"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ弧")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆุๅาฯࠠศๆิส๏ู๊สࠩ弨"),l11l11_l1_,144,l11l1l_l1_ (u"ࠨࠩ弩"),l11l1l_l1_ (u"ࠩࠪ弪"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ弫"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弬"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弭")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ะฮํ๏ࠠศๆิหหาࠧ弮"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡴࡳࡧࡱࡨ࡮ࡴࡧࠨ弯"),146)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭弰"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ弱"),l11l1l_l1_ (u"ࠪࠫ弲"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ弳"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ弴")+l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤ็์่ศฬࠣ฽ึฮ๊สࠩ張"),l11l1l_l1_ (u"ࠧࠨ弶"),147)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ強"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ弸")+l1111l_l1_+l11l1l_l1_ (u"ࠪฬาั࠺ࠡไ้์ฬะࠠฤฮ้ฬ๏ฯࠧ弹"),l11l1l_l1_ (u"ࠫࠬ强"),148)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ弻"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ弼")+l1111l_l1_+l11l1l_l1_ (u"ࠧษฯฮ࠾ࠥอแๅษ่ࠤ฾ืศ๋หࠪ弽"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ไ๎้๋ࠧ弾"),144)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ弿"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ彀")+l1111l_l1_+l11l1l_l1_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ彁"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ彂"),144)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭彃"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ彄")+l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯ࠿ࠦๅิำะ๎ฬะฺࠠำห๎ฮ࠭彅"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀุ้ือ๋หࠪ彆"),144)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ彇"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭彈")+l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬ࠼ุ้๊ࠣำๅษอࠤ฾ืศ๋หࠪ彉"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ๆี็ื้ࠬࡳࡱ࠿ࡈ࡫ࡎࡗࡁࡸ࠿ࡀࠫ彊"),144)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ彋"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ彌")+l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡษฯ๊อ๐ษࠨ彍"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁࡸ࡫ࡲࡪࡧࡶࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ彎"),144)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ彏"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ彐")+l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮ้ࠥวาฬ๋๊ࠬ彑"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ๅสีฯ๎ๆࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭归"),144)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ当"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ彔")+l1111l_l1_+l11l1l_l1_ (u"ࠪฬาั࠺ࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ录"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ่ๆศห࠮็ึฮไศร࠮ห้็ึศศํอ࠰ิืษห࠮ห้าๅฺหࠩࡷࡵࡃࡃࡂࡋࡖࡅ࡭ࡇࡂࠨ彖"),144)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ彗"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ彘")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ฼ีฬ่ࠠฯูหอࠥอไๆำฯ฽๏ฯࠧ彙"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐ࠹ࡰࡕࡲ࠸ࡳࡲࡌ࠹࠶ࡒ࡬ࡸ࡜ࡉ࡮ࡎ࡯ࡋ࡯ࡶ࡮ࡻࡺࡳࡱࡗࡊࡹࡳࡦࡳࠩ彚"),144)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ彛"),l1111l_l1_+l11l1l_l1_ (u"ࠪห฾ีวะษอࠤฬ฼วโหࠣ๎ํะ๊้สࠪ彜"),l11l1l_l1_ (u"ࠫࠬ彝"),144)
	#l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ彞"),l11l1l_l1_ (u"࠭็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ彟"),l11l1l_l1_ (u"่ࠧาสࠤฬ๊วฯฬํหึࠦำ้ใࠣ๎ำืฬไ่๊ࠢࠥอไษำ้ห๊าࠧ彠"),l11l1l_l1_ (u"ࠨๆฦ๊์ࠦำ้ใࠣ๎็๎ๅࠡสอุ฿๐ไࠡสิ๊ฬ๋ฬࠡ์๋ฮ๏๎ศࠨ彡"))
	#if l1ll111111_l1_==1:
	#	url = l11l1l_l1_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ形")
	#	xbmc.executebuiltin(l11l1l_l1_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ彣"))
	#	xbmc.executebuiltin(l11l1l_l1_ (u"ࠫࡗ࡫ࡰ࡭ࡣࡦࡩ࡜࡯࡮ࡥࡱࡺࠬࡻ࡯ࡤࡦࡱࡶ࠰ࠬ彤")+url+l11l1l_l1_ (u"ࠬ࠯ࠧ彥"))
	#	#xbmc.executebuiltin(l11l1l_l1_ (u"࠭ࡒࡶࡰࡄࡨࡩࡵ࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠪࠩ彦"))
	return
l11l1l_l1_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡎࡃࡌࡒࡕࡇࡇࡆࠪࡸࡶࡱ࠯࠺ࠋࠋ࡫ࡸࡲࡲࠬࡤࡥ࠯ࡨࡦࡺࡡࠡ࠿ࠣࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃࠫࡹࡷࡲࠩࠋࠋ࡬ࡪࠥ࠭ࡒࡦࡨࡤࡥࡹࠦࡁ࡭࠯ࡊࡥࡲࡳࡡ࡭ࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠥࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࠪ࠰ࠬ࠭ࠬࡶࡴ࡯࠰ࠬࡿࡥࡴࠩࠬࠎࠎࡪࡤࠡ࠿ࠣࡧࡨࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹࡧࡢࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡲࡪࡥ࡫ࡋࡷ࡯ࡤࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣ࡛ࠨࡨࡨࡩࡩࡌࡩ࡭ࡶࡨࡶࡈ࡮ࡩࡱࡄࡤࡶࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠐࠉࡧࡱࡵࠤ࡮ࠦࡩ࡯ࠢࡵࡲࡦ࡭ࡥࠩ࡮ࡨࡲ࠭ࡪࡤࠪࠫ࠽ࠎࠎࠏࡩࡵࡧࡰࠤࡂࠦࡤࡥ࡝࡬ࡡࠏࠏࠉࡊࡐࡖࡉࡗ࡚࡟ࡊࡖࡈࡑࡤ࡚ࡏࡠࡏࡈࡒ࡚࠮ࡩࡵࡧࡰ࠭ࠏࠏࡉࡕࡇࡐࡗ࠭ࡻࡲ࡭ࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢ彧")
def l11l1l11ll11_l1_():
	ITEMS(l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ彨"))
	return
def l11l1l11lll1_l1_():
	ITEMS(l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ彩"))
	return
def PLAY(url,type):
	#url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࡨࡪࡎ࠻ࡈࡲ࠳ࡵ࠶࠻࡫ࠬ彪")
	#items = re.findall(l11l1l_l1_ (u"ࠫࡻࡃࠨ࠯ࠬࡂ࠭ࠩ࠭彫"),url,re.DOTALL)
	#id = items[0]
	#l1llll1_l1_ = l11l1l_l1_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫࠯ࡱ࡮ࡤࡽ࠴ࡅࡶࡪࡦࡨࡳࡤ࡯ࡤ࠾ࠩ彬")+id
	#PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ彭"))
	#return
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠊࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࡭ࡨࡌ࠹ࡆࡰ࠸ࡺ࠴࠹ࡩࠪࠎࠎ࡫ࡲࡳࡱࡵࡷ࠱ࡺࡩࡵ࡮ࡨࡷ࠱ࡲࡩ࡯࡭ࡶࠤࡂࠦࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠰ࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠩࡷࡵࡰ࠮ࠐࠉࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࠭ࠫࠬ࠭࠮࠯࠰ࠦࠠࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡷ࠮࠯ࠊࠊࡧࡵࡶࡴࡸࡳ࠭ࡶ࡬ࡸࡱ࡫ࡳ࠭࡮࡬ࡲࡰࡹࠠ࠾ࠢࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠳ࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠬࡺࡸ࡬ࠪࠌࠌࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࠧ࠭ࠩ࠮࠯࠰࠱ࠫࠬࠢࠣࠫ࠰ࡹࡴࡳࠪ࡯࡭ࡳࡱࡳࠪࠫࠍࠍࡕࡒࡁ࡚ࡡ࡙ࡍࡉࡋࡏࠩ࡮࡬ࡲࡰࡹ࡛࠱࡟࠯ࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥ࠭ࡶࡼࡴࡪ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ彮")
	import ll_l1_
	ll_l1_.l11_l1_([url],l1ll1_l1_,type,url)
	return
def l11l111lll1l_l1_(url):
	html,cc,data = l11l1l111lll_l1_(url)
	dd = cc[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ彯")][l11l1l_l1_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ彰")][l11l1l_l1_ (u"ࠪࡸࡦࡨࡳࠨ影")]
	for l11l1l1ll1_l1_ in range(len(dd)):
		item = dd[l11l1l1ll1_l1_]
		l11l1l1ll1ll_l1_(item,url,str(l11l1l1ll1_l1_))
	ee = dd[0][l11l1l_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ彲")][l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭彳")][l11l1l_l1_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ彴")][l11l1l_l1_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ彵")]
	s = 0
	for l11l1l1ll1_l1_ in range(len(ee)):
		item = ee[l11l1l1ll1_l1_][l11l1l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彶")][l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ彷")][0]
		if list(item[l11l1l_l1_ (u"ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ彸")][l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ役")].keys())[0]==l11l1l_l1_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ彺"): continue
		succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_ = l11l1ll11l11_l1_(item)
		if not title:
			s += 1
			title = l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡำสสัฯࠠࠨ彻")+str(s)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ彼"),l1111l_l1_+title,url,144,l11l1l_l1_ (u"ࠨࠩ彽"),str(l11l1l1ll1_l1_))
	key = re.findall(l11l1l_l1_ (u"ࠩࠥ࡭ࡳࡴࡥࡳࡶࡸࡦࡪࡇࡰࡪࡍࡨࡽࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ彾"),html,re.DOTALL)
	l111l1l_l1_ = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡹࡰࡷࡷࡹࡧ࡫ࡩ࠰ࡸ࠴࠳࡬ࡻࡩࡥࡧࡂ࡯ࡪࡿ࠽ࠨ彿")+key[0]
	html,cc,l11l1llll_l1_ = l11l1l111lll_l1_(l111l1l_l1_)
	for l11llll11l1_l1_ in range(3,4):
		dd = cc[l11l1l_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ往")][l11llll11l1_l1_][l11l1l_l1_ (u"ࠬ࡭ࡵࡪࡦࡨࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬ征")][l11l1l_l1_ (u"࠭ࡩࡵࡧࡰࡷࠬ徂")]
		for l11l1l1ll1_l1_ in range(len(dd)):
			item = dd[l11l1l1ll1_l1_]
			if l11l1l_l1_ (u"࡚ࠧࡱࡸࡘࡺࡨࡥࠡࡒࡵࡩࡲ࡯ࡵ࡮ࠩ徃") in str(item): continue
			l11l1l1ll1ll_l1_(item)
	return
def ITEMS(url,data=l11l1l_l1_ (u"ࠨࠩ径"),index=0):
	global settings
	if not data: data = settings.getSetting(l11l1l_l1_ (u"ࠩࡤࡺ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤࡢࡶࡤࠫ待"))
	if index: index = int(index)
	else: index = 0
	data = data.replace(l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ徆"),l11l1l_l1_ (u"ࠫࠬ徇"))
	html,cc,l11l1llll_l1_ = l11l1l111lll_l1_(url,data)
	l11lll1ll1_l1_,ff = l11l1l_l1_ (u"ࠬ࠭很"),l11l1l_l1_ (u"࠭ࠧ徉")
	#if l11l1l_l1_ (u"ࠧࡰࡹࡱࡩࡷ࠭徊") in html.lower(): DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ律"),l11l1l_l1_ (u"ࠩࠪ後"),l11l1l_l1_ (u"ࠪࡳࡼࡴࡥࡳࠢࡨࡼ࡮ࡹࡴࠨ徍"),l11l1l_l1_ (u"ࠫ࡮ࡴࠠࡩࡶࡰࡰࠬ徎"))
	owner = re.findall(l11l1l_l1_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ徏"),html,re.DOTALL)
	if not owner: owner = re.findall(l11l1l_l1_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ徐"),html,re.DOTALL)
	if not owner: owner = re.findall(l11l1l_l1_ (u"ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ徑"),html,re.DOTALL)
	if owner:
		l11lll1ll1_l1_ = l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ徒")+owner[0][0]+l11l1l_l1_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ従")
		l1llll1_l1_ = owner[0][1]
		if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ徔") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		#if l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ徕") in url and l11l1l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ徖") not in url and l11l1l_l1_ (u"࠭࠯ࡤ࠱ࠪ得") not in url and l11l1l_l1_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ徘") not in url:
		if l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ徙") in url: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ徚"),l1111l_l1_+l11lll1ll1_l1_,l1llll1_l1_,144)
	#if cc==l11l1l_l1_ (u"ࠪࠫ徛"): l11l11l111l1_l1_(url,html) ; return
	l11l11l11111_l1_ = [l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ徜"),l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭徝"),l11l1l_l1_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ從"),l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ徟"),l11l1l_l1_ (u"ࠨ࠱ࡩࡩࡦࡺࡵࡳࡧࡧࠫ徠"),l11l1l_l1_ (u"ࠩࡶࡷࡂ࠭御"),l11l1l_l1_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ徢"),l11l1l_l1_ (u"ࠫࡰ࡫ࡹ࠾ࠩ徣"),l11l1l_l1_ (u"ࠬࡨࡰ࠾ࠩ徤"),l11l1l_l1_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ徥")]
	l11l111ll1ll_l1_ = not any(value in url for value in l11l11l11111_l1_)
	if l11l111ll1ll_l1_ and l11lll1ll1_l1_:
		l11l11l1l_l1_ = l11l1l_l1_ (u"ࠧศๆหัะ࠭徦")
		l1lll11l1_l1_ = l11l1l_l1_ (u"ࠨไ๋หห๋ࠠศๆอุ฿๐ไࠨ徧")
		l11l11l11_l1_ = l11l1l_l1_ (u"ࠩส่ๆ๐ฯ๋๊๊หฯ࠭徨")
		l11l111lll11_l1_ = l11l1l_l1_ (u"ࠪห้่ๆ้ษอࠫ復")
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ循"),l1111l_l1_+l11lll1ll1_l1_,url,9999)
		if l11l1l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢษฯฮࠦࠬ徫") in html: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徬"),l1111l_l1_+l11l11l1l_l1_,url,145,l11l1l_l1_ (u"ࠧࠨ徭"),l11l1l_l1_ (u"ࠨࠩ微"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭徯"))
		if l11l1l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾่่ࠧศศ่ࠤฬ๊สี฼ํ่ࠧ࠭徰") in html: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徱"),l1111l_l1_+l1lll11l1_l1_,url+l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ徲"),144)
		if l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣษ็ๅ๏ี๊้้สฮࠧ࠭徳") in html: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ徴"),l1111l_l1_+l11l11l11_l1_,url+l11l1l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ徵"),144)
		if l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦฬ๊โ็๊สฮࠧ࠭徶") in html: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ德"),l1111l_l1_+l11l111lll11_l1_,url+l11l1l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ徸"),144)
		if l11l1l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡔࡧࡤࡶࡨ࡮ࠢࠨ徹") in html: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭徺"),l1111l_l1_+l11l11l1l_l1_,url,145,l11l1l_l1_ (u"ࠧࠨ徻"),l11l1l_l1_ (u"ࠨࠩ徼"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭徽"))
		if l11l1l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ徾") in html: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ徿"),l1111l_l1_+l1lll11l1_l1_,url+l11l1l_l1_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠩ忀"),144)
		if l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ忁") in html: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ忂"),l1111l_l1_+l11l11l11_l1_,url+l11l1l_l1_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ心"),144)
		if l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࡈ࡮ࡡ࡯ࡰࡨࡰࡸࠨࠧ忄") in html: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ必"),l1111l_l1_+l11l111lll11_l1_,url+l11l1l_l1_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ忆"),144)
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ忇"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭忈"),l11l1l_l1_ (u"ࠧࠨ忉"),9999)
	if l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ忊") in url:
		dd = cc[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ忋")][l11l1l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭忌")][l11l1l_l1_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭忍")][l11l1l_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ忎")][l11l1l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ忏")]
		l11l111ll11l_l1_ = 0
		for i in range(len(dd)):
			if l11l1l_l1_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭忐") in list(dd[i].keys()):
				l11l111ll111_l1_ = dd[i][l11l1l_l1_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忑")]
				length = len(str(l11l111ll111_l1_))
				if length>l11l111ll11l_l1_:
					l11l111ll11l_l1_ = length
					ff = l11l111ll111_l1_
		if l11l111ll11l_l1_==0: return
	elif l11l1l_l1_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ忒") in url or l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ忓") in url or l11l1l_l1_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ忔") in url or l11l1l_l1_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭忕") in url or l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ忖") in url or url==l11l11_l1_:
		l11l11ll11l1_l1_ = []
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ志"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ忘"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ忙"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ忚"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ忛"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠭࠲࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ応"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ忝"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲ࡜ࡧࡴࡤࡪࡑࡩࡽࡺࡒࡦࡵࡸࡰࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࠧ忞"))
		l11l111lllll_l1_,ff = l11l11l11lll_l1_(cc,l11l1l_l1_ (u"ࠨࠩ忟"),l11l11ll11l1_l1_)
	if not ff:
		try:
			dd = cc[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ忠")][l11l1l_l1_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭忡")][l11l1l_l1_ (u"ࠫࡹࡧࡢࡴࠩ忢")]
			l1l1111l1ll_l1_ = l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭忣") in url or l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ忤") in url or l11l1l_l1_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ忥") in url
			l11l11l1l1ll_l1_ = l11l1l_l1_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥห้็๊ะ์๋๋ฬะࠢࠨ忦") in html or l11l1l_l1_ (u"ࠩࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦ็๎วว็ࠣห้ะิ฻์็ࠦࠬ忧") in html or l11l1l_l1_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไใ่๋หฯࠨࠧ忨") in html
			l11l11l1l1l1_l1_ = l11l1l_l1_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡖࡪࡦࡨࡳࡸࠨࠧ忩") in html or l11l1l_l1_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠥࠫ忪") in html or l11l1l_l1_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠥࠫ快") in html
			if l1l1111l1ll_l1_ and (l11l11l1l1ll_l1_ or l11l11l1l1l1_l1_):
				for l11l1l1ll1_l1_ in range(len(dd)):
					if l11l1l_l1_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ忬") not in list(dd[l11l1l1ll1_l1_].keys()): continue
					ee = dd[l11l1l1ll1_l1_][l11l1l_l1_ (u"ࠨࡶࡤࡦࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭忭")]
					try: gg = ee[l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ忮")][l11l1l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ忯")][l11l1l_l1_ (u"ࠫࡸࡻࡢࡎࡧࡱࡹࠬ忰")][l11l1l_l1_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ忱")][l11l1l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡔࡺࡲࡨࡗࡺࡨࡍࡦࡰࡸࡍࡹ࡫࡭ࡴࠩ忲")][l11l1l1ll1_l1_]
					except: gg = ee
					try: l1llll1_l1_ = gg[l11l1l_l1_ (u"ࠧࡦࡰࡧࡴࡴ࡯࡮ࡵࠩ忳")][l11l1l_l1_ (u"ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪ忴")][l11l1l_l1_ (u"ࠩࡺࡩࡧࡉ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ念")][l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ忶")]
					except: continue
					if   l11l1l_l1_ (u"ࠫ࠴ࡼࡩࡥࡧࡲࡷࠬ忷")		in l1llll1_l1_	and l11l1l_l1_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭忸")		in url: ee = dd[l11l1l1ll1_l1_] ; break
					elif l11l1l_l1_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ忹")	in l1llll1_l1_	and l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ忺")	in url: ee = dd[l11l1l1ll1_l1_] ; break
					elif l11l1l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ忻")	in l1llll1_l1_	and l11l1l_l1_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ忼")		in url: ee = dd[l11l1l1ll1_l1_] ; break
					else: ee = dd[0]
			elif l11l1l_l1_ (u"ࠪࡦࡵࡃࠧ忽") in url: ee = dd[index]
			else: ee = dd[0]
			ff = ee[l11l1l_l1_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ忾")][l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭忿")]
		except: pass
	if not ff: return
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ怀"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡏࡲࡺ࡮࡫ࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨ࡫ࡷࡩࡲࡹࠧ࡞ࠤ态"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ怂"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ怃"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ怄"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡧࡲࡥࡵࠪࡡࠧ怅"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡳ࡫ࡦ࡬ࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࠧ怆"))
	if l11l1l_l1_ (u"࠭ࡶࡪࡧࡺࡁࠬ怇") not in url: l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡳࡶࡤࡐࡩࡳࡻࠧ࡞࡝ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡗࡺࡨࡍࡦࡰࡸࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫࡢࠨ怈"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡨࡩ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫࡸ࡮ࡥ࡭ࡨࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡩࡩ࡙ࡨࡦ࡮ࡩࡇࡴࡴࡴࡦࡰࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ怉"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࡠ࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬ࡭ࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡪࡶࡨࡱࡸ࠭࡝ࠣ怊"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡪ࡫ࡡࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠࠦ怋"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦ࡫࡬࡛ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ怌"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡬ࡦ࡜ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝ࠣ怍"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡦࡧ࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ怎"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡧࡨ࡞ࠫࡷ࡯ࡣࡩࡉࡵ࡭ࡩࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣࠢ怏"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡨࡩ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠤ怐"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡩࡪࠧ怑"))
	l11l11l111ll_l1_ = l1111lll11l_l1_(l11l1l_l1_ (u"ࡸ่๊ࠫࠠใ๊สส๊ࠦวๅฬื฾๏๊ࠧ怒"))
	l11l111ll1l1_l1_ = l1111lll11l_l1_(l11l1l_l1_ (u"ࡹ้ࠬไࠡษ็ๅ๏ี๊้้สฮࠬ怓"))
	l11l111llll1_l1_ = l1111lll11l_l1_(l11l1l_l1_ (u"ࡺ࠭ใๅࠢส่็์่ศฬࠪ怔"))
	l111l11l111_l1_ = [l11l11l111ll_l1_,l11l111ll1l1_l1_,l11l111llll1_l1_,l11l1l_l1_ (u"࠭ࡁ࡭࡮ࠣࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭怕"),l11l1l_l1_ (u"ࠧࡂ࡮࡯ࠤࡻ࡯ࡤࡦࡱࡶࠫ怖"),l11l1l_l1_ (u"ࠨࡃ࡯ࡰࠥࡩࡨࡢࡰࡱࡩࡱࡹࠧ怗")]
	l11l11l1111l_l1_,gg = l11l11l11lll_l1_(ff,index,l11l11ll11l1_l1_)
	if l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ怘") in str(type(gg)) and any(value in str(gg[0]) for value in l111l11l111_l1_): del gg[0]
	for index2 in range(len(gg)):
		l11l11ll11l1_l1_ = []
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡨࡦࡣࡧࡩࡷ࠭࡝ࠣ怙"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ怚"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡃࡢࡴࡧࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬ࡮ࡥࡢࡦࡨࡶࠬࡣࠢ怛"))
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࠨ怜"))		#4
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬࡸࡩࡤࡪࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡟ࠥ思"))		#7
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡲࡪࡥ࡫ࡍࡹ࡫࡭ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ怞"))		#6
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡨࡣࡰࡩࡈࡧࡲࡥࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡧࡢ࡯ࡨࠫࡢࠨ怟"))		#5
		l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣࠢ怠"))
		l11l111lllll_l1_,item = l11l11l11lll_l1_(gg,index2,l11l11ll11l1_l1_)
		#if l11l111lllll_l1_ not in [l11l1l_l1_ (u"ࠫ࠷࠭怡"),l11l1l_l1_ (u"ࠬ࠺ࠧ怢"),l11l1l_l1_ (u"࠭࠵ࠨ怣")]: l11l1l1ll1ll_l1_(item)		# 2,4,7
		#else: l11l1l1ll1ll_l1_(item,url,str(index2))
		l11l1l1ll1ll_l1_(item,url,str(index2))
		if l11l111lllll_l1_==l11l1l_l1_ (u"ࠧ࠵ࠩ怤"):
			try:
				hh = item[l11l1l_l1_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ急")][l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ怦")][l11l1l_l1_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ性")][l11l1l_l1_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ怨")]
				for l11l1l11l1l1_l1_ in range(len(hh)):
					l11l11l11l1l_l1_ = hh[l11l1l11l1l1_l1_]
					l11l1l1ll1ll_l1_(l11l11l11l1l_l1_)
			except: pass
	l11l11lll1ll_l1_ = False
	if l11l1l_l1_ (u"ࠬࡼࡩࡦࡹࡀࠫ怩") not in url and l11l11l1111l_l1_==l11l1l_l1_ (u"࠭࠸ࠨ怪"): l11l11lll1ll_l1_ = True
	if l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ怫") in l11l1llll_l1_: l11l1l1l11ll_l1_,key,l11l1l1l111l_l1_,l11l1l11ll1l_l1_,token,l11l11llllll_l1_ = l11l1llll_l1_.split(l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ怬"))
	else: l11l1l1l11ll_l1_,key,l11l1l1l111l_l1_,l11l1l11ll1l_l1_,token,l11l11llllll_l1_ = l11l1l_l1_ (u"ࠩࠪ怭"),l11l1l_l1_ (u"ࠪࠫ怮"),l11l1l_l1_ (u"ࠫࠬ怯"),l11l1l_l1_ (u"ࠬ࠭怰"),l11l1l_l1_ (u"࠭ࠧ怱"),l11l1l_l1_ (u"ࠧࠨ怲")
	l111l1l_l1_,l1ll11ll111_l1_ = l11l1l_l1_ (u"ࠨࠩ怳"),l11l1l_l1_ (u"ࠩࠪ怴")
	if menuItemsLIST:
		l11l11l1l11l_l1_ = str(menuItemsLIST[-1][1])
		if   l1111l_l1_+l11l1l_l1_ (u"ࠪࡇࡍࡔࡌࠨ怵") in l11l11l1l11l_l1_: l1ll11ll111_l1_ = l11l1l_l1_ (u"ࠫࡈࡎࡁࡏࡐࡈࡐࡘ࠭怶")
		elif l1111l_l1_+l11l1l_l1_ (u"࡛ࠬࡓࡆࡔࠪ怷") in l11l11l1l11l_l1_: l1ll11ll111_l1_ = l11l1l_l1_ (u"࠭ࡃࡉࡃࡑࡒࡊࡒࡓࠨ怸")
		elif l1111l_l1_+l11l1l_l1_ (u"ࠧࡍࡋࡖࡘࠬ怹") in l11l11l1l11l_l1_: l1ll11ll111_l1_ = l11l1l_l1_ (u"ࠨࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ怺")
	if l11l1l_l1_ (u"ࠩࠥࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠥࠫ总") in html and l11l1l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ怼") not in url and not l11l11lll1ll_l1_ and l11l1l_l1_ (u"ࠫࡸ࡮ࡥ࡭ࡨࡢ࡭ࡩ࠭怽") not in url:	# and (index!=l11l1l_l1_ (u"ࠬ࠭怾") or l11l1l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ怿") in url or l11l1l_l1_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭恀") in url or l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡳࡸࡩࡷࡿ࠽ࠨ恁") in url or l11l1l_l1_ (u"ࠩࡹ࡭ࡪࡽ࠽ࠨ恂") in url):
		l111l1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ恃")+l11l1l1l111l_l1_
	elif l11l1l_l1_ (u"ࠫࠧࡺ࡯࡬ࡧࡱࠦࠬ恄") in html and l11l1l_l1_ (u"ࠬࡨࡰ࠾ࠩ恅") not in url and l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ恆") in url or l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ恇") in url:
		l111l1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ恈")+key
	elif l11l1l_l1_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤࠪ恉") in html and l11l1l_l1_ (u"ࠪࡦࡵࡃࠧ恊") not in url:
		l111l1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࡯࠯ࡷ࠳࠲ࡦࡷࡵࡷࡴࡧࡂ࡯ࡪࡿ࠽ࠨ恋")+key
	if l111l1l_l1_: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ恌"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤศิั๊ࠩ恍"),l111l1l_l1_,144,l1ll11ll111_l1_,l11l1l_l1_ (u"ࠧࠨ恎"),l11l1llll_l1_)
	return
def l11l11l11lll_l1_(l111lll1ll1_l1_,l11l11111ll_l1_,l11l11llll11_l1_):
	cc = l111lll1ll1_l1_
	ff,index = l111lll1ll1_l1_,l11l11111ll_l1_
	gg,index2 = l111lll1ll1_l1_,l11l11111ll_l1_
	item,render = l111lll1ll1_l1_,l11l11111ll_l1_
	count = len(l11l11llll11_l1_)
	for l11l1l1ll1_l1_ in range(count):
		try:
			out = eval(l11l11llll11_l1_[l11l1l1ll1_l1_])
			#if isinstance(out,dict): out = l11l1l_l1_ (u"ࠨࠩ恏")
			return str(l11l1l1ll1_l1_+1),out
		except: pass
	return l11l1l_l1_ (u"ࠩࠪ恐"),l11l1l_l1_ (u"ࠪࠫ恑")
def l11l1ll11l11_l1_(item):
	try: l11l1l1l1lll_l1_ = list(item.keys())[0]
	except: return False,l11l1l_l1_ (u"ࠫࠬ恒"),l11l1l_l1_ (u"ࠬ࠭恓"),l11l1l_l1_ (u"࠭ࠧ恔"),l11l1l_l1_ (u"ࠧࠨ恕"),l11l1l_l1_ (u"ࠨࠩ恖"),l11l1l_l1_ (u"ࠩࠪ恗"),l11l1l_l1_ (u"ࠪࠫ恘")
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_ = False,l11l1l_l1_ (u"ࠫࠬ恙"),l11l1l_l1_ (u"ࠬ࠭恚"),l11l1l_l1_ (u"࠭ࠧ恛"),l11l1l_l1_ (u"ࠧࠨ恜"),l11l1l_l1_ (u"ࠨࠩ恝"),l11l1l_l1_ (u"ࠩࠪ恞"),l11l1l_l1_ (u"ࠪࠫ恟")
	#WRITE_THIS(l11l1l_l1_ (u"ࠫࠬ恠"),str(item))
	render = item[l11l1l1l1lll_l1_]
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡵ࡯ࡲ࡯ࡥࡾࡧࡢ࡭ࡧࡗࡩࡽࡺࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恡"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡧࡱࡵࡱࡦࡺࡴࡦࡦࡗ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ恢"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠧ࡞ࠤ恣"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡷࡻ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡶࡨࡼࡹ࠭࡝ࠣ恤"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ恥"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ恦"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ恧"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡹ࡯ࡴ࡭ࡧࠪࡡࠧ恨"))
	l11l111lllll_l1_,title = l11l11l11lll_l1_(item,render,l11l11ll11l1_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ恩"),l11l1l_l1_ (u"ࠧࠨ恪"),l11l1l_l1_ (u"ࠨࠩ恫"),title)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ恬"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡳࡧࡶࡪࡩࡤࡸ࡮ࡵ࡮ࡆࡰࡧࡴࡴ࡯࡮ࡵࠩࡠ࡟ࠬࡩ࡯࡮࡯ࡤࡲࡩࡓࡥࡵࡣࡧࡥࡹࡧࠧ࡞࡝ࠪࡻࡪࡨࡃࡰ࡯ࡰࡥࡳࡪࡍࡦࡶࡤࡨࡦࡺࡡࠨ࡟࡞ࠫࡺࡸ࡬ࠨ࡟ࠥ恭"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬ࡫࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ恮"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧ࡯ࡴࡦ࡯࡞ࠫࡪࡴࡤࡱࡱ࡬ࡲࡹ࠭࡝࡜ࠩࡦࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡸࡧࡥࡇࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡷࡵࡰࠬࡣࠢ息")) # required for l111ll11ll1_l1_ l11l11lll1ll_l1_
	l11l111lllll_l1_,l1llll1_l1_ = l11l11l11lll_l1_(item,render,l11l11ll11l1_l1_)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ恰"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ恱"))
	l11l111lllll_l1_,l1ll1l_l1_ = l11l11l11lll_l1_(item,render,l11l11ll11l1_l1_)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ恲"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ恳"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ恴"))
	l11l111lllll_l1_,count = l11l11l11lll_l1_(item,render,l11l11ll11l1_l1_)
	l11l11ll11l1_l1_ = []
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ恵"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ恶"))
	l11l11ll11l1_l1_.append(l11l1l_l1_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ恷"))
	l11l111lllll_l1_,l1l11l1ll_l1_ = l11l11l11lll_l1_(item,render,l11l11ll11l1_l1_)
	if l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉࠬ恸") in l1l11l1ll_l1_: l1l11l1ll_l1_,l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠨࠩ恹"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ恺")
	if l11l1l_l1_ (u"้ࠪออิาࠩ恻") in l1l11l1ll_l1_: l1l11l1ll_l1_,l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠫࠬ恼"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭恽")
	if l11l1l_l1_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭恾") in list(render.keys()):
		l11l1l1lll11_l1_ = str(render[l11l1l_l1_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ恿")])
		if l11l1l_l1_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ悀") in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠩࠧ࠾ࠬ悁")
		if l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࠡࡐࡒ࡛ࠬ悂") in l11l1l1lll11_l1_: l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ悃")
		if l11l1l_l1_ (u"ࠬࡈࡵࡺࠩ悄") in l11l1l1lll11_l1_ or l11l1l_l1_ (u"࠭ࡒࡦࡰࡷࠫ悅") in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠧࠥࠦ࠽ࠫ悆")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡶ่ࠩฬฬฺัࠨ悇")) in l11l1l1lll11_l1_: l1lllll111ll_l1_ = l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ悈")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡸูࠫืวยࠩ悉")) in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠫࠩࠪ࠺ࠨ悊")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡺ࠭วิฬษะฬืࠧ悋")) in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"࠭ࠤࠥ࠼ࠪ悌")
		if l1111lll11l_l1_(l11l1l_l1_ (u"ࡵࠨว฼่ฬ์วหࠩ悍")) in l11l1l1lll11_l1_: l11l1l11l111_l1_ = l11l1l_l1_ (u"ࠨࠦ࠽ࠫ悎")
	l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
	if l1llll1_l1_ and l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ悏") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
	l1ll1l_l1_ = l1ll1l_l1_.split(l11l1l_l1_ (u"ࠪࡃࠬ悐"))[0]
	if  l1ll1l_l1_ and l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ悑") not in l1ll1l_l1_: l1ll1l_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬ悒")+l1ll1l_l1_
	title = escapeUNICODE(title)
	if l11l1l11l111_l1_: title = l11l1l11l111_l1_+l11l1l_l1_ (u"࠭ࠠࠡࠩ悓")+title
	#title = unescapeHTML(title)
	l1l11l1ll_l1_ = l1l11l1ll_l1_.replace(l11l1l_l1_ (u"ࠧ࠭ࠩ悔"),l11l1l_l1_ (u"ࠨࠩ悕"))
	count = count.replace(l11l1l_l1_ (u"ࠩ࠯ࠫ悖"),l11l1l_l1_ (u"ࠪࠫ悗"))
	count = re.findall(l11l1l_l1_ (u"ࠫࡡࡪࠫࠨ悘"),count)
	if count: count = count[0]
	else: count = l11l1l_l1_ (u"ࠬ࠭悙")
	return True,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_
def l11l1l1ll1ll_l1_(item,url=l11l1l_l1_ (u"࠭ࠧ悚"),index=l11l1l_l1_ (u"ࠧࠨ悛")):
	succeeded,title,l1llll1_l1_,l1ll1l_l1_,count,l1l11l1ll_l1_,l1lllll111ll_l1_,l11l1l11l111_l1_ = l11l1ll11l11_l1_(item)
	#if l11l1l_l1_ (u"ࠨ࠱ࡩࡩࡪࡪ࠯ࡨࡷ࡬ࡨࡪࡥࡢࡶ࡫࡯ࡨࡪࡸࠧ悜") in url and index==l11l1l_l1_ (u"ࠩ࠳ࠫ悝"):
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悞"),l1111l_l1_+title,url,144)
	#	return
	if not succeeded: return
	elif l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ悟") in str(item): return	# l11l1l1l111l_l1_ not items
	elif l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡕࡿࡶࡓࡧࡱࡨࡪࡸࡥࡳࠩ悠") in str(item): return			# l11l1l1ll11l_l1_ not items
	elif not l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࠬ悡") in url: return			# separator l11l111l1lll_l1_ list not items
	elif title and not l1llll1_l1_ and (l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭悢") in url or l11l1l_l1_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ患") in str(item) or url==l11l11_l1_):
		title = l11l1l_l1_ (u"ࠩࡀࡁࡂࠦࠧ悤")+title+l11l1l_l1_ (u"ࠪࠤࡂࡃ࠽ࠨ悥")
		addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ悦"),l1111l_l1_+title,l11l1l_l1_ (u"ࠬ࠭悧"),9999)
	elif title and l11l1l_l1_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ您") in str(item):
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ悩"),l1111l_l1_+title,l11l1l_l1_ (u"ࠨࠩ悪"),9999)
	elif l11l1l_l1_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ悫") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悬"),l1111l_l1_+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	elif not title: return
	elif l1lllll111ll_l1_: addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ悭"),l1111l_l1_+l1lllll111ll_l1_+title,l1llll1_l1_,143,l1ll1l_l1_)
	#elif l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࡀࠫ悮") in l1llll1_l1_ and l11l1l_l1_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭悯") not in l1llll1_l1_ and l11l1l_l1_ (u"ࠧࡵ࠿࠳ࠫ悰") not in l1llll1_l1_:
	#	l11l1l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡮࡬ࡷࡹࡃࠨ࠯ࠬࡂ࠭ࠩ࠭悱"),l1llll1_l1_,re.DOTALL)
	#	l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࠫ悲")+l11l1l11l11l_l1_[0]
	#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ悳"),l1111l_l1_+l11l1l_l1_ (u"ࠫࡑࡏࡓࡕࠩ悴")+count+l11l1l_l1_ (u"ࠬࡀࠠࠡࠩ悵")+title,l1llll1_l1_,144,l1ll1l_l1_)
	elif l11l1l_l1_ (u"࠭ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠨ悶") in l1llll1_l1_ or l11l1l_l1_ (u"ࠧ࠰ࡵ࡫ࡳࡷࡺࡳ࠰ࠩ悷") in l1llll1_l1_:
		if l11l1l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ悸") in l1llll1_l1_ and l11l1l_l1_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ悹") not in l1llll1_l1_:
			l11l1l11l11l_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪࠪࡱ࡯ࡳࡵ࠿ࠪ悺"),1)[1]
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭悻")+l11l1l11l11l_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ悼"),l1111l_l1_+l11l1l_l1_ (u"࠭ࡌࡊࡕࡗࠫ悽")+count+l11l1l_l1_ (u"ࠧ࠻ࠢࠣࠫ悾")+title,l1llll1_l1_,144,l1ll1l_l1_)
		else:
			l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠨࠨ࡯࡭ࡸࡺ࠽ࠨ悿"),1)[0]
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ惀"),l1111l_l1_+title,l1llll1_l1_,143,l1ll1l_l1_,l1l11l1ll_l1_)
	else:
		type = l11l1l_l1_ (u"ࠪࠫ惁")
		if not l1llll1_l1_: l1llll1_l1_ = url
		#if l11l1l_l1_ (u"ࠫࡸࡹ࠽ࠨ惂") in l1llll1_l1_: l1llll1_l1_ = url
		#elif l11l1l_l1_ (u"ࠬࡹࡨࡦ࡮ࡩࡣ࡮ࡪ࠽ࠨ惃") in l1llll1_l1_: l1llll1_l1_ = url		# not needed it will stop l11l11l11ll1_l1_ l111ll11ll1_l1_ l11l11lll1ll_l1_
		elif not any(value in l1llll1_l1_ for value in [l11l1l_l1_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ惄"),l11l1l_l1_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ情"),l11l1l_l1_ (u"ࠨ࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ惆"),l11l1l_l1_ (u"ࠩ࠲ࡪࡪࡧࡴࡶࡴࡨࡨࠬ惇"),l11l1l_l1_ (u"ࠪࡷࡸࡃࠧ惈"),l11l1l_l1_ (u"ࠫࡧࡶ࠽ࠨ惉")]):
			if l11l1l_l1_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ惊")	in l1llll1_l1_ or l11l1l_l1_ (u"࠭࠯ࡤ࠱ࠪ惋") in l1llll1_l1_: type = l11l1l_l1_ (u"ࠧࡄࡊࡑࡐࠬ惌")+count+l11l1l_l1_ (u"ࠨ࠼ࠣࠤࠬ惍")
			if l11l1l_l1_ (u"ࠩ࠲ࡹࡸ࡫ࡲ࠰ࠩ惎") in l1llll1_l1_: type = l11l1l_l1_ (u"࡙ࠪࡘࡋࡒࠨ惏")+count+l11l1l_l1_ (u"ࠫ࠿ࠦࠠࠨ惐")
			index,l11l1ll111ll_l1_ = l11l1l_l1_ (u"ࠬ࠭惑"),l11l1l_l1_ (u"࠭ࠧ惒")
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ惓"),l1111l_l1_+type+title,l1llll1_l1_,144,l1ll1l_l1_,index)
	return
def l11l1l111lll_l1_(url,data=l11l1l_l1_ (u"ࠨࠩ惔"),request=l11l1l_l1_ (u"ࠩࠪ惕")):
	global settings
	if not data: data = settings.getSetting(l11l1l_l1_ (u"ࠪࡥࡻ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡥࡣࡷࡥࠬ惖"))
	#if l11l1l_l1_ (u"ࠫࡤࡥࠧ惗") in l11l1ll111ll_l1_: l11l1ll111ll_l1_ = l11l1l_l1_ (u"ࠬ࠭惘")
	#if l11l1l_l1_ (u"࠭ࡳࡴ࠿ࠪ惙") in url: url = url.split(l11l1l_l1_ (u"ࠧࡴࡵࡀࠫ惚"))[0]
	if request==l11l1l_l1_ (u"ࠨࠩ惛"): request = l11l1l_l1_ (u"ࠩࡼࡸࡎࡴࡩࡵ࡫ࡤࡰࡉࡧࡴࡢࠩ惜")
	l111ll111l_l1_ = l11llll11_l1_()
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ惝"):l111ll111l_l1_,l11l1l_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ惞"):l11l1l_l1_ (u"ࠬࡖࡒࡆࡈࡀ࡬ࡱࡃࡡࡳࠩ惟")}
	#l1l1l1ll1_l1_ = headers.copy()
	if l11l1l_l1_ (u"࠭࠺࠻࠼ࠪ惠") in data: l11l1l1l11ll_l1_,key,l11l1l1l111l_l1_,l11l1l11ll1l_l1_,token,l11l11llllll_l1_ = data.split(l11l1l_l1_ (u"ࠧ࠻࠼࠽ࠫ惡"))
	else: l11l1l1l11ll_l1_,key,l11l1l1l111l_l1_,l11l1l11ll1l_l1_,token,l11l11llllll_l1_ = l11l1l_l1_ (u"ࠨࠩ惢"),l11l1l_l1_ (u"ࠩࠪ惣"),l11l1l_l1_ (u"ࠪࠫ惤"),l11l1l_l1_ (u"ࠫࠬ惥"),l11l1l_l1_ (u"ࠬ࠭惦"),l11l1l_l1_ (u"࠭ࠧ惧")
	if l11l1l_l1_ (u"ࠧࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ惨") in url:
		l11l1llll_l1_ = {}
		l11l1llll_l1_[l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ惩")] = {l11l1l_l1_ (u"ࠤࡦࡰ࡮࡫࡮ࡵࠤ惪"):{l11l1l_l1_ (u"ࠥ࡬ࡱࠨ惫"):l11l1l_l1_ (u"ࠦࡦࡸࠢ惬"),l11l1l_l1_ (u"ࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ惭"):l11l1l_l1_ (u"ࠨࡗࡆࡄࠥ惮"),l11l1l_l1_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡖࡦࡴࡶ࡭ࡴࡴࠢ惯"):l11l1l11ll1l_l1_}}
		l11l1llll_l1_ = str(l11l1llll_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭惰"),url,l11l1llll_l1_,l1l1l1ll1_l1_,True,True,l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠵ࡸࡺࠧ惱"))
	elif l11l1l_l1_ (u"ࠪ࡯ࡪࡿ࠽ࠨ惲") in url and l11l1l1l11ll_l1_:
		l11l1llll_l1_ = {l11l1l_l1_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪ想"):token}
		l11l1llll_l1_[l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭惴")] = {l11l1l_l1_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࠨ惵"):{l11l1l_l1_ (u"ࠢࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠧ惶"):l11l1l1l11ll_l1_,l11l1l_l1_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧ惷"):l11l1l_l1_ (u"ࠤ࡚ࡉࡇࠨ惸"),l11l1l_l1_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ惹"):l11l1l11ll1l_l1_}}
		l11l1llll_l1_ = str(l11l1llll_l1_)
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ惺"),url,l11l1llll_l1_,l1l1l1ll1_l1_,True,True,l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡇࡆࡖࡢࡔࡆࡍࡅࡠࡆࡄࡘࡆ࠳࠲࡯ࡦࠪ惻"))
	elif l11l1l_l1_ (u"࠭ࡣࡵࡱ࡮ࡩࡳࡃࠧ惼") in url and l11l11llllll_l1_:
		l1l1l1ll1_l1_.update({l11l1l_l1_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ惽"):l11l1l_l1_ (u"ࠨ࠳ࠪ惾"),l11l1l_l1_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭惿"):l11l1l11ll1l_l1_})
		l1l1l1ll1_l1_.update({l11l1l_l1_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ愀"):l11l1l_l1_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ愁")+l11l11llllll_l1_})
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ愂"),url,l11l1l_l1_ (u"࠭ࠧ愃"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠧࠨ愄"),l11l1l_l1_ (u"ࠨࠩ愅"),l11l1l_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠷ࡷࡪࠧ愆"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ愇"),url,l11l1l_l1_ (u"ࠫࠬ愈"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠬ࠭愉"),l11l1l_l1_ (u"࠭ࠧ愊"),l11l1l_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠶ࡷ࡬ࠬ愋"))
	html = response.content
	tmp = re.findall(l11l1l_l1_ (u"ࠨࠤ࡬ࡲࡳ࡫ࡲࡵࡷࡥࡩࡆࡶࡩࡌࡧࡼࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ愌"),html,re.DOTALL|re.I)
	if tmp: key = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡻ࡫ࡲࠣ࠰࠭ࡃࠧࡼࡡ࡭ࡷࡨࠦ࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ愍"),html,re.DOTALL|re.I)
	if tmp: l11l1l11ll1l_l1_ = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠪࠦࡹࡵ࡫ࡦࡰࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ愎"),html,re.DOTALL|re.I)
	if tmp: token = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠫࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧ意"),html,re.DOTALL|re.I)
	if tmp: l11l1l1l11ll_l1_ = tmp[0]
	tmp = re.findall(l11l1l_l1_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ愐"),html,re.DOTALL|re.I)
	if tmp: l11l1l1l111l_l1_ = tmp[0]
	cookies = response.cookies.get_dict()
	if l11l1l_l1_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ愑") in list(cookies.keys()): l11l11llllll_l1_ = cookies[l11l1l_l1_ (u"ࠧࡗࡋࡖࡍ࡙ࡕࡒࡠࡋࡑࡊࡔ࠷࡟ࡍࡋ࡙ࡉࠬ愒")]
	data = l11l1l1l11ll_l1_+l11l1l_l1_ (u"ࠨ࠼࠽࠾ࠬ愓")+key+l11l1l_l1_ (u"ࠩ࠽࠾࠿࠭愔")+l11l1l1l111l_l1_+l11l1l_l1_ (u"ࠪ࠾࠿ࡀࠧ愕")+l11l1l11ll1l_l1_+l11l1l_l1_ (u"ࠫ࠿ࡀ࠺ࠨ愖")+token+l11l1l_l1_ (u"ࠬࡀ࠺࠻ࠩ愗")+l11l11llllll_l1_
	if request==l11l1l_l1_ (u"࠭ࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦ࠭愘") and l11l1l_l1_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ愙") in html:
		l111l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡹ࡬ࡲࡩࡵࡷ࡝࡝ࠥࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠥࡠࡢࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ愚"),html,re.DOTALL)
		if not l111l1ll1l_l1_: l111l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡹࡥࡷࠦࡹࡵࡋࡱ࡭ࡹ࡯ࡡ࡭ࡆࡤࡸࡦࠦ࠽ࠡࠪࡾ࠲࠯ࡅࡽࠪ࠽ࠪ愛"),html,re.DOTALL)
		l11l11ll11ll_l1_ = EVAL(l11l1l_l1_ (u"ࠪࡷࡹࡸࠧ愜"),l111l1ll1l_l1_[0])
	elif request==l11l1l_l1_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ愝") and l11l1l_l1_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ愞") in html:
		l111l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ感"),html,re.DOTALL)
		l11l11ll11ll_l1_ = EVAL(l11l1l_l1_ (u"ࠧࡴࡶࡵࠫ愠"),l111l1ll1l_l1_[0])
	elif l11l1l_l1_ (u"ࠨ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ愡") not in html: l11l11ll11ll_l1_ = EVAL(l11l1l_l1_ (u"ࠩࡶࡸࡷ࠭愢"),html)
	else: l11l11ll11ll_l1_ = l11l1l_l1_ (u"ࠪࠫ愣")
	#open(l11l1l_l1_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡮ࡸࡵ࡮ࠨ愤"),l11l1l_l1_ (u"ࠬࡽࠧ愥")).write(str(l11l11ll11ll_l1_))
	#open(l11l1l_l1_ (u"࠭ࡓ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ愦"),l11l1l_l1_ (u"ࠧࡸࠩ愧")).write(html)
	settings.setSetting(l11l1l_l1_ (u"ࠨࡣࡹ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡪࡡࡵࡣࠪ愨"),data)
	return html,l11l11ll11ll_l1_,data
def l11l1ll11111_l1_(url):
	search = OPEN_KEYBOARD()
	if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ愩"),l11l1l_l1_ (u"ࠪ࠯ࠬ愪"))
	l111l1l_l1_ = url+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷࡵࡦࡴࡼࡁࠬ愫")+search
	ITEMS(l111l1l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ愬"),l11l1l_l1_ (u"࠭ࠫࠨ愭"))
	l111l1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ愮")+search
	if not l1ll_l1_:
		if l11l1l_l1_ (u"ࠨࡡ࡜ࡓ࡚࡚ࡕࡃࡇ࠰࡚ࡎࡊࡅࡐࡕࡢࠫ愯") in options: l11l1l11111l_l1_ = l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡅࡨࡋࡔࡅࡖࠫ࠲࠶࠵ࡇࠩ࠷࠻࠳ࡅࠩ愰")
		elif l11l1l_l1_ (u"ࠪࡣ࡞ࡕࡕࡕࡗࡅࡉ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࡠࠩ愱") in options: l11l1l11111l_l1_ = l11l1l_l1_ (u"ࠫࠫࡹࡰ࠾ࡇࡪࡍࡖࡇࡷࠦ࠴࠸࠷ࡉࠫ࠲࠶࠵ࡇࠫ愲")
		elif l11l1l_l1_ (u"ࠬࡥ࡙ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࡡࠪ愳") in options: l11l1l11111l_l1_ = l11l1l_l1_ (u"࠭ࠦࡴࡲࡀࡉ࡬ࡏࡑࡂࡩࠨ࠶࠺࠹ࡄࠦ࠴࠸࠷ࡉ࠭愴")
		l111ll1_l1_ = l111l1l_l1_+l11l1l11111l_l1_
	else:
		l11l1l111111_l1_,l11l11l1llll_l1_,l1lll11l1_l1_ = [],[],l11l1l_l1_ (u"ࠧࠨ愵")
		l11l11ll111l_l1_ = [l11l1l_l1_ (u"ࠨสา์๋ࠦสาฬํฬࠬ愶"),l11l1l_l1_ (u"ࠩอีฯ๐ศࠡฯึฬ๋ࠥฯ๊ࠢสฺ่๊ษࠨ愷"),l11l1l_l1_ (u"ࠪฮึะ๊ษࠢะือࠦสศำําࠥอไหฯ่๎้࠭愸"),l11l1l_l1_ (u"ࠫฯืส๋สࠣัุฮฺࠠัาࠤฬ๊ๅีษ๊ำฬะࠧ愹"),l11l1l_l1_ (u"ࠬะัห์หࠤาูศࠡษ็ฮ็๐๊ๆࠩ愺")]
		l11l1l1ll111_l1_ = [l11l1l_l1_ (u"࠭ࠧ愻"),l11l1l_l1_ (u"ࠧࠧࡵࡳࡁࡈࡇࡁࠦ࠴࠸࠷ࡉ࠭愼"),l11l1l_l1_ (u"ࠨࠨࡶࡴࡂࡉࡁࡊࠧ࠵࠹࠸ࡊࠧ愽"),l11l1l_l1_ (u"ࠩࠩࡷࡵࡃࡃࡂࡏࠨ࠶࠺࠹ࡄࠨ愾"),l11l1l_l1_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡈࠩ࠷࠻࠳ࡅࠩ愿")]
		l11l1l1lll1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢ࠰ࠤฬิสาࠢส่ฯืส๋สࠪ慀"),l11l11ll111l_l1_)
		if l11l1l1lll1l_l1_ == -1: return
		l11l11lllll1_l1_ = l11l1l1ll111_l1_[l11l1l1lll1l_l1_]
		html,c,data = l11l1l111lll_l1_(l111l1l_l1_+l11l11lllll1_l1_)
		if c:
			d = c[l11l1l_l1_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ慁")][l11l1l_l1_ (u"࠭ࡴࡸࡱࡆࡳࡱࡻ࡭࡯ࡕࡨࡥࡷࡩࡨࡓࡧࡶࡹࡱࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ慂")][l11l1l_l1_ (u"ࠧࡱࡴ࡬ࡱࡦࡸࡹࡄࡱࡱࡸࡪࡴࡴࡴࠩ慃")][l11l1l_l1_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ慄")][l11l1l_l1_ (u"ࠩࡶࡹࡧࡓࡥ࡯ࡷࠪ慅")][l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࡖࡹࡧࡓࡥ࡯ࡷࡕࡩࡳࡪࡥࡳࡧࡵࠫ慆")][l11l1l_l1_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡶࠫ慇")]
			for l11l11l1lll1_l1_ in range(len(d)):
				group = d[l11l11l1lll1_l1_][l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡋ࡯࡬ࡵࡧࡵࡋࡷࡵࡵࡱࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ慈")][l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ慉")]
				for l11l1ll1111l_l1_ in range(len(group)):
					render = group[l11l1ll1111l_l1_][l11l1l_l1_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡆࡪ࡮ࡷࡩࡷࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ慊")]
					if l11l1l_l1_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲࡊࡴࡤࡱࡱ࡬ࡲࡹ࠭態") in list(render.keys()):
						l1llll1_l1_ = render[l11l1l_l1_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ慌")][l11l1l_l1_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ慍")][l11l1l_l1_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ慎")][l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠩ慏")]
						l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"࠭࡜ࡶ࠲࠳࠶࠻࠭慐"),l11l1l_l1_ (u"ࠧࠧࠩ慑"))
						title = render[l11l1l_l1_ (u"ࠨࡶࡲࡳࡱࡺࡩࡱࠩ慒")]
						title = title.replace(l11l1l_l1_ (u"ࠩส่อำหࠡ฻้ࠤࠬ慓"),l11l1l_l1_ (u"ࠪࠫ慔"))
						if l11l1l_l1_ (u"ࠫสุวๅหࠣห้็ไหำࠪ慕") in title: continue
						if l11l1l_l1_ (u"่ࠬวว็ฬࠤฯฺฺ๋ๆࠪ慖") in title:
							title = l11l1l_l1_ (u"࠭ฬ๋ั่้๋ࠣำๅี็หฯࠦࠧ慗")+title
							l1lll11l1_l1_ = title
							l1llll11l1_l1_ = l1llll1_l1_
						if l11l1l_l1_ (u"ࠧหำอ๎อࠦอิสࠪ慘") in title: continue
						title = title.replace(l11l1l_l1_ (u"ࠨࡕࡨࡥࡷࡩࡨࠡࡨࡲࡶࠥ࠭慙"),l11l1l_l1_ (u"ࠩࠪ慚"))
						if l11l1l_l1_ (u"ࠪࡖࡪࡳ࡯ࡷࡧࠪ慛") in title: continue
						if l11l1l_l1_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹ࠭慜") in title:
							title = l11l1l_l1_ (u"ࠬา๊ะࠢ็ู่๊ไิๆสฮࠥ࠭慝")+title
							l1lll11l1_l1_ = title
							l1llll11l1_l1_ = l1llll1_l1_
						if l11l1l_l1_ (u"࠭ࡓࡰࡴࡷࠤࡧࡿࠧ慞") in title: continue
						l11l1l111111_l1_.append(escapeUNICODE(title))
						l11l11l1llll_l1_.append(l1llll1_l1_)
		if not l1lll11l1_l1_: l11l1l1l1l1l_l1_ = l11l1l_l1_ (u"ࠧࠨ慟")
		else:
			l11l1l111111_l1_ = [l11l1l_l1_ (u"ࠨสา์๋ࠦแๅฬิࠫ慠"),l1lll11l1_l1_]+l11l1l111111_l1_
			l11l11l1llll_l1_ = [l11l1l_l1_ (u"ࠩࠪ慡"),l1llll11l1_l1_]+l11l11l1llll_l1_
			l11l1l1lllll_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡ࠯ࠣหำะัࠡษ็ๅ้ะัࠨ慢"),l11l1l111111_l1_)
			if l11l1l1lllll_l1_ == -1: return
			l11l1l1l1l1l_l1_ = l11l11l1llll_l1_[l11l1l1lllll_l1_]
		if l11l1l1l1l1l_l1_: l111ll1_l1_ = l11l11_l1_+l11l1l1l1l1l_l1_
		elif l11l11lllll1_l1_: l111ll1_l1_ = l111l1l_l1_+l11l11lllll1_l1_
		else: l111ll1_l1_ = l111l1l_l1_
		l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࠋࡨࡰࡸ࡫࠺ࠋࠋࠌࠍ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡩ࡭ࡱࡺࡥࡳ࠯ࡧࡶࡴࡶࡤࡰࡹࡱࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡳࡦࡥࡷ࡭ࡴࡴࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡢ࡭ࡱࡦ࡯ࠥࡃࠠࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡠ࠶࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡕࡩࡲࡵࡶࡦࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠫ࠱࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡱࡵࡸࠥࡨࡹࠨ࠮ࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡔࡱࡧࡹ࡭࡫ࡶࡸࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠢࡷ࡭ࡹࡲࡥࠡ࠿ࠣࠫั๐ฯࠡๆ็ุ้๊ำๅษอࠤࠬ࠱ࡴࡪࡶ࡯ࡩࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢ࡯࡭ࡳࡱ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࡟ࡹ࠵࠶࠲࠷ࠩ࠯ࠫࠫ࠭ࠩࠋࠋࠌࠍࠎ࡯ࡦࠡࠩࡖࡩࡦࡸࡣࡩࠢࡩࡳࡷࡀࠠࠡࠩࠣ࡭ࡳࠦࡴࡪࡶ࡯ࡩ࠿ࠐࠉࠊࠋࠌࠍ࡫࡯࡬ࡦࡶࡨࡶࡑࡏࡓࡕࡡࡶࡩࡦࡸࡣࡩ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡨࡷࡨࡧࡰࡦࡗࡑࡍࡈࡕࡄࡆࠪࡷ࡭ࡹࡲࡥࠪࠫࠍࠍࠎࠏࠉࠊ࡮࡬ࡲࡰࡒࡉࡔࡖࡢࡷࡪࡧࡲࡤࡪ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡰ࡮ࡴ࡫ࠪࠌࠌࠍࠎࠏࡩࡧࠢࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࠋࡩ࡭ࡱ࡫ࡴࡦࡴࡏࡍࡘ࡚࡟ࡴࡱࡵࡸ࠳ࡧࡰࡱࡧࡱࡨ࠭࡫ࡳࡤࡣࡳࡩ࡚ࡔࡉࡄࡑࡇࡉ࠭ࡺࡩࡵ࡮ࡨ࠭࠮ࠐࠉࠊࠋࠌࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠨࠢࠣ慣")
	ITEMS(l111ll1_l1_)
	return
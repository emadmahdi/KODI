# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊࠩമ")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡉࡘࡒࡥࠧയ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1ll11l11_l1_ = [l11l1l_l1_ (u"ࠩ࠴࠶࠸࠿ࠧര"),l11l1l_l1_ (u"ࠪ࠵࠷࠻࠰ࠨറ"),l11l1l_l1_ (u"ࠫ࠶࠸࠴࠶ࠩല"),l11l1l_l1_ (u"ࠬ࠸࠰ࠨള"),l11l1l_l1_ (u"࠭࠱࠳࠷࠼ࠫഴ"),l11l1l_l1_ (u"ࠧ࠳࠳࠻ࠫവ"),l11l1l_l1_ (u"ࠨ࠶࠻࠹ࠬശ"),l11l1l_l1_ (u"ࠩ࠴࠶࠸࠾ࠧഷ"),l11l1l_l1_ (u"ࠪ࠵࠷࠻࠸ࠨസ"),l11l1l_l1_ (u"ࠫ࠷࠿࠲ࠨഹ")]
l1ll111ll_l1_ = [l11l1l_l1_ (u"ࠬ࠹࠰࠴࠲ࠪഺ"),l11l1l_l1_ (u"࠭࠶࠳࠺഻ࠪ")]
def MAIN(mode,url,text):
	if   mode==60: results = MENU()
	elif mode==61: results = l1lllll_l1_(url,text)
	elif mode==62: results = l1lll1l1_l1_(url)
	elif mode==63: results = PLAY(url)
	elif mode==64: results = l1ll11l1l_l1_(text)
	elif mode==69: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ഼ࠧ"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨഽ"),l11l1l_l1_ (u"ࠩࠪാ"),69,l11l1l_l1_ (u"ࠪࠫി"),l11l1l_l1_ (u"ࠫࠬീ"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩു"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ൂ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩൃ")+l1111l_l1_+l11l1l_l1_ (u"ࠨ็สࠤ๏ะๅࠡ็ืห์ีส่ࠢส่ฬ์ࠧൄ"),l11l11_l1_,64,l11l1l_l1_ (u"ࠩࠪ൅"),l11l1l_l1_ (u"ࠪࠫെ"),l11l1l_l1_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡣࡻ࡯ࡥࡸࡧࡧࡣࡻ࡯ࡤࡴࠩേ"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬൈ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ൉")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆส็ะืࠠๆึส๋ิฯࠧൊ"),l11l11_l1_,64,l11l1l_l1_ (u"ࠨࠩോ"),l11l1l_l1_ (u"ࠩࠪൌ"),l11l1l_l1_ (u"ࠪࡱࡴࡹࡴࡠࡸ࡬ࡩࡼ࡫ࡤࡠࡸ࡬ࡨࡸ്࠭"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫൎ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ൏")+l1111l_l1_+l11l1l_l1_ (u"࠭วื์ไฮ๋ࠥฤฯำสࠫ൐"),l11l11_l1_,64,l11l1l_l1_ (u"ࠧࠨ൑"),l11l1l_l1_ (u"ࠨࠩ൒"),l11l1l_l1_ (u"ࠩࡵࡩࡨ࡫࡮ࡵ࡮ࡼࡣࡦࡪࡤࡦࡦࡢࡺ࡮ࡪࡳࠨ൓"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪൔ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ൕ")+l1111l_l1_+l11l1l_l1_ (u"ࠬ็๊ะ์๋ࠤ฾ฺ่ศศํࠫൖ"),l11l11_l1_,64,l11l1l_l1_ (u"࠭ࠧൗ"),l11l1l_l1_ (u"ࠧࠨ൘"),l11l1l_l1_ (u"ࠨࡴࡤࡲࡩࡵ࡭ࡠࡸ࡬ࡨࡸ࠭൙"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ൚"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ൛")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ็ไศ็ࠣ์ู๊ไิๆสฮࠬ൜"),l11l11_l1_,61,l11l1l_l1_ (u"ࠬ࠭൝"),l11l1l_l1_ (u"࠭ࠧ൞"),l11l1l_l1_ (u"ࠧ࠮࠳ࠪൟ"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨൠ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫൡ")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊ฯ๋่ํอࠬൢ"),l11l11_l1_,61,l11l1l_l1_ (u"ࠫࠬൣ"),l11l1l_l1_ (u"ࠬ࠭൤"),l11l1l_l1_ (u"࠭࠭࠳ࠩ൥"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ൦"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ൧")+l1111l_l1_+l11l1l_l1_ (u"ࠩࡈࡲ࡬ࡲࡩࡴࡪ࡚ࠣ࡮ࡪࡥࡰࡵࠪ൨"),l11l11_l1_,61,l11l1l_l1_ (u"ࠪࠫ൩"),l11l1l_l1_ (u"ࠫࠬ൪"),l11l1l_l1_ (u"ࠬ࠳࠳ࠨ൫"))
	return l11l1l_l1_ (u"࠭ࠧ൬")
def l1lllll_l1_(url,category):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ൭"),l11l1l_l1_ (u"ࠨࠩ൮"),l11l1l_l1_ (u"ࠩࠪ൯"), category)
	cat = l11l1l_l1_ (u"ࠪࠫ൰")
	if category not in [l11l1l_l1_ (u"ࠫ࠲࠷ࠧ൱"),l11l1l_l1_ (u"ࠬ࠳࠲ࠨ൲"),l11l1l_l1_ (u"࠭࠭࠴ࠩ൳")]: cat = l11l1l_l1_ (u"ࠧࡀࡥࡤࡸࡂ࠭൴")+category
	l111l1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡰࡩࡳࡻ࡟࡭ࡧࡹࡩࡱ࠴ࡰࡩࡲࠪ൵")+cat
	html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠩࠪ൶"),l11l1l_l1_ (u"ࠪࠫ൷"),l11l1l_l1_ (u"ࠫࠬ൸"),l11l1l_l1_ (u"ࠬࡇࡌࡇࡃࡗࡍࡒࡏ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ൹"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬൺ"),html,re.DOTALL)
	l1ll111l1_l1_,l1ll1l111_l1_ = False,False
	for l1llll1_l1_,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩൻ"))
		if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ർ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨൽ")+l1llll1_l1_
		cat = re.findall(l11l1l_l1_ (u"ࠪࡧࡦࡺ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧൾ"),l1llll1_l1_,re.DOTALL)[0]
		if category==cat: l1ll111l1_l1_ = True
		elif l1ll111l1_l1_ 	or (category==l11l1l_l1_ (u"ࠫ࠲࠷ࠧൿ") and cat in l1ll11l11_l1_) \
						or (category==l11l1l_l1_ (u"ࠬ࠳࠲ࠨ඀") and cat not in l1ll111ll_l1_ and cat not in l1ll11l11_l1_) \
						or (category==l11l1l_l1_ (u"࠭࠭࠴ࠩඁ") and cat in l1ll111ll_l1_):
							if count==l11l1l_l1_ (u"ࠧ࠲ࠩං"): addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧඃ"),l1111l_l1_+title,l1llll1_l1_,63)
							else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ඄"),l1111l_l1_+title,l1llll1_l1_,61,l11l1l_l1_ (u"ࠪࠫඅ"),l11l1l_l1_ (u"ࠫࠬආ"),cat)
							l1ll1l111_l1_ = True
	if not l1ll1l111_l1_: l1lll1l1_l1_(url)
	return
def l1lll1l1_l1_(url):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭ඇ"),l11l1l_l1_ (u"࠭ࠧඈ"),True,l11l1l_l1_ (u"ࠧࡂࡎࡉࡅ࡙ࡏࡍࡊ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨඉ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩඊ"),l11l1l_l1_ (u"ࠩࠪඋ"),url , html)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡨࡲࡳࡹ࡫ࡲࠨඌ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫ࡬ࡸࡩࡥࡡࡹ࡭ࡪࡽ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠲࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩඍ"),block,re.DOTALL)
	l1llll1_l1_ = l11l1l_l1_ (u"ࠬ࠭ඎ")
	for l1ll1l_l1_,title,l1llll1_l1_ in items:
		title = title.replace(l11l1l_l1_ (u"࠭ࡁࡥࡦࠪඏ"),l11l1l_l1_ (u"ࠧࠨඐ")).replace(l11l1l_l1_ (u"ࠨࡶࡲࠤࡖࡻࡩࡤ࡭࡯࡭ࡸࡺࠧඑ"),l11l1l_l1_ (u"ࠩࠪඒ")).strip(l11l1l_l1_ (u"ࠪࠤࠬඓ"))
		if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩඔ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫඕ")+l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬඖ"),l1111l_l1_+title,l1llll1_l1_,63,l1ll1l_l1_)
	l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩ඗"),block,re.DOTALL)
	block=l1l11l1_l1_[0]
	block=re.findall(l11l1l_l1_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ඘"),html,re.DOTALL)[0]
	items=re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ඙"),block,re.DOTALL)
	l111l1l_l1_ = url.split(l11l1l_l1_ (u"ࠪࡃࠬක"))[0]
	for l1llll1_l1_,l1ll11111_l1_ in items:
		l1llll1_l1_ = l111l1l_l1_ + l1llll1_l1_
		title = unescapeHTML(l1ll11111_l1_)
		title = l11l1l_l1_ (u"ฺࠫ็อสࠢࠪඛ") + title
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬග"),l1111l_l1_+title,l1llll1_l1_,62)
	return l1llll1_l1_
def PLAY(url):
	if l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࡸ࠴ࡰࡩࡲࠪඝ") in url: url = l1lll1l1_l1_(url)
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠧࠨඞ"),l11l1l_l1_ (u"ࠨࠩඟ"),True,l11l1l_l1_ (u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ච"))
	items = re.findall(l11l1l_l1_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸ࡫࡯࡬ࡦ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪඡ"),html,re.DOTALL)
	url = items[0]
	if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩජ") not in url: url = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫඣ")+url
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬඤ"))
	return
def l1ll11l1l_l1_(category):
	payload = { l11l1l_l1_ (u"ࠧ࡮ࡱࡧࡩࠬඥ") : category }
	url = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡪࡦࡺࡩ࡮࡫࠱ࡸࡻ࠵ࡡ࡫ࡣࡻ࠲ࡵ࡮ࡰࠨඦ")
	headers = { l11l1l_l1_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨට") : l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩඨ") }
	data = l1ll11ll1_l1_(payload)
	html = OPENURL_CACHED(l1ll1l1ll_l1_,url,data,headers,True,l11l1l_l1_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠳ࡍࡐࡕࡗࡗ࠲࠷ࡳࡵࠩඩ"))
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫࠭ඪ"),html,re.DOTALL)
	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨණ"))
		if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬඬ") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀࠧත")+l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨථ"),l1111l_l1_+title,l1llll1_l1_,63,l1ll1l_l1_)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠪࠫද"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠫࠬධ"): return
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭න"),l11l1l_l1_ (u"࠭ࠧ඲"),search, l11l11_l1_)
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"ࠧࠡࠩඳ"),l11l1l_l1_ (u"ࠨ࠭ࠪප"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡢࡶࡪࡹࡵ࡭ࡶ࠱ࡴ࡭ࡶ࠿ࡲࡷࡨࡶࡾࡃࠧඵ") + l11111l_l1_ # + l11l1l_l1_ (u"ࠪࠪࡵࡧࡧࡦ࠿࠴ࠫබ")
	l1lll1l1_l1_(url)
	return
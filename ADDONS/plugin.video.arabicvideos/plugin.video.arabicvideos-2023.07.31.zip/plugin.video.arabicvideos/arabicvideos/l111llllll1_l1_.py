# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ㺾")
headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㺿") : l11l1l_l1_ (u"࠭ࠧ㻀") }
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡏ࡙࡞ࡤ࠭㻁")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l11lll11ll_l1_ = l1l1l1l_l1_[l1ll1_l1_][1]
def MAIN(mode,url,text):
	if   mode==180: results = MENU()
	elif mode==181: results = l1lllll_l1_(url,text)
	elif mode==182: results = PLAY(url)
	elif mode==183: results = l1lll1l1_l1_(url)
	elif mode==188: results = l11l11111l1_l1_()
	elif mode==189: results = SEARCH(text)
	else: results = False
	return results
def l11l11111l1_l1_():
	message = l11l1l_l1_ (u"ࠨ้ำหࠥอไๆ๊ๅ฽ࠥะฺ๋ำࠣฬฬ๊ใศ็็ࠤ࠳࠴࠮๊ࠡหัฬาษࠡษ็ํࠥอูศัฬࠤอืๅอห้๋ࠣࠦวๅืไีࠥ࠴࠮࠯๋ࠢห้๋ศา็ฯࠤาอไ๋ษู้ࠣเ่ๅ๋ࠢ๎฾อๆ๋่๊ࠢࠥ๎ูไหูࠣา๐ษࠡ࠰࠱࠲ࠥ๎ไ่าสࠤุ๎แࠡ์หๆ๎ࠦวๅ็๋ๆ฾ࠦๅ฻ๆๅࠤฬ๊้ࠡ็สࠤูอมࠡษ็่์࠭㻂")
	DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㻃"),l11l1l_l1_ (u"ࠪࠫ㻄"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㻅"),message)
	return
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㻆"),l1111l_l1_+l11l1l_l1_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㻇"),l11l1l_l1_ (u"ࠧࠨ㻈"),189,l11l1l_l1_ (u"ࠨࠩ㻉"),l11l1l_l1_ (u"ࠩࠪ㻊"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㻋"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㻌"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ㻍")+l1111l_l1_+l11l1l_l1_ (u"࠭ศ้ๅึࠤฬ๎แ๋ี้ࠣํ็๊ำࠢ็ห๋ีࠧ㻎"),l11l11_l1_,181,l11l1l_l1_ (u"ࠧࠨ㻏"),l11l1l_l1_ (u"ࠨࠩ㻐"),l11l1l_l1_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭㻑"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㻒"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㻓")+l1111l_l1_+l11l1l_l1_ (u"ࠬษอะอࠣห้อแๅษ่ࠫ㻔"),l11l11_l1_,181,l11l1l_l1_ (u"࠭ࠧ㻕"),l11l1l_l1_ (u"ࠧࠨ㻖"),l11l1l_l1_ (u"ࠨ࡮ࡤࡸࡪࡹࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨ㻗"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㻘"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ㻙")+l1111l_l1_+l11l1l_l1_ (u"ࠫฯ๊๊โิํ์๋ࠦๅ้ใํึ๊ࠥว็ัࠪ㻚"),l11l11_l1_,181,l11l1l_l1_ (u"ࠬ࠭㻛"),l11l1l_l1_ (u"࠭ࠧ㻜"),l11l1l_l1_ (u"ࠧࡵࡸࠪ㻝"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㻞"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ㻟")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้อใฬำู้ࠣอ็ะหࠪ㻠"),l11l11_l1_,181,l11l1l_l1_ (u"ࠫࠬ㻡"),l11l1l_l1_ (u"ࠬ࠭㻢"),l11l1l_l1_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ㻣"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㻤"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ㻥")+l1111l_l1_+l11l1l_l1_ (u"ࠩฦๆํ๏ࠠศๆสๅ้อๅࠡษ็ัฬ๊๊สࠩ㻦"),l11l11_l1_,181,l11l1l_l1_ (u"ࠪࠫ㻧"),l11l1l_l1_ (u"ࠫࠬ㻨"),l11l1l_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㻩"))
	html = OPENURL_CACHED(l1llll11_l1_,l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ㻪"),headers,l11l1l_l1_ (u"ࠧࠨ㻫"),l11l1l_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㻬"))
	items = re.findall(l11l1l_l1_ (u"ࠩ࠿࡬࠷ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㻭"),html,re.DOTALL)
	for l1llll1_l1_,title in items:
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㻮"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭㻯")+l1111l_l1_+title,l1llll1_l1_,181)
	return html
def l1lllll_l1_(url,type=l11l1l_l1_ (u"ࠬ࠭㻰")):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"࠭ࠧ㻱"),headers,l11l1l_l1_ (u"ࠧࠨ㻲"),l11l1l_l1_ (u"ࠨࡏࡒ࡚ࡎࡠࡌࡂࡐࡇ࠱ࡎ࡚ࡅࡎࡕ࠰࠵ࡸࡺࠧ㻳"))
	if type==l11l1l_l1_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵ࠯ࡰࡳࡻ࡯ࡥࡴࠩ㻴"): block = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁวาีหࠡษ็วๆ๊วๆ࠾࠲࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࡮࠱ࠨ㻵"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"ࠫࡧࡵࡸ࠮ࡱࡩࡪ࡮ࡩࡥࠨ㻶"): block = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࡗࡪࡩࡴࡪࡱࡱࠦࡃฮ่ไีࠣหํ็๊ิ่ࠢ์ๆ๐าࠡๆส๊ิࡂ࠯ࡩ࠳ࡁࠬ࠳࠰࠿ࠪ࠾࡫࠵ࠬ㻷"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ㻸"): block = re.findall(l11l1l_l1_ (u"ࠧࡣࡶࡱ࠱࠷࠳࡯ࡷࡧࡵࡰࡦࡿࠨ࠯ࠬࡂ࠭ࡁࡹࡴࡺ࡮ࡨࡂࠬ㻹"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ㻺"): block = re.findall(l11l1l_l1_ (u"ࠩࡥࡸࡳ࠳࠱ࠡࡤࡷࡲ࠲ࡧࡢࡴࡱ࡯ࡽ࠭࠴ࠪࡀࠫࡥࡸࡳ࠳࠲ࠡࡤࡷࡲ࠲ࡧࡢࡴࡱ࡯ࡽࠬ㻻"),html,re.DOTALL)[0]
	elif type==l11l1l_l1_ (u"ࠪࡸࡻ࠭㻼"): block = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࠥࡂฯ๊๊โิํ์๋ࠦๅ้ใํึ๊ࠥว็ั࠿࠳࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱ࡫ࠧ࠭㻽"),html,re.DOTALL)[0]
	else: block = html
	if type in [l11l1l_l1_ (u"ࠬࡺ࡯ࡱ࠯ࡹ࡭ࡪࡽࡳࠨ㻾"),l11l1l_l1_ (u"࠭ࡴࡰࡲ࠰ࡱࡴࡼࡩࡦࡵࠪ㻿")]:
		items = re.findall(l11l1l_l1_ (u"ࠧࡴࡶࡼࡰࡪࡃࠢࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡤࡲࡸࡹࡵ࡭࠮ࡶ࡬ࡸࡱ࡫࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㼀"),block,re.DOTALL)
	else: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡨ࡭࡬࡮ࡴ࠾ࠤ࠶࡟࠵࠳࠹࡞࠭ࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡵࡴࡵࡱࡰ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㼁"),block,re.DOTALL)
	l11l_l1_ = []
	l111l1l1l_l1_ = [l11l1l_l1_ (u"ࠩไ๎้๋ࠧ㼂"),l11l1l_l1_ (u"ࠪห้ำไใหࠪ㼃"),l11l1l_l1_ (u"ࠫฬ๊อๅไ๊ࠫ㼄"),l11l1l_l1_ (u"ࠬ฿ัืࠩ㼅"),l11l1l_l1_ (u"࠭ࡒࡢࡹࠪ㼆"),l11l1l_l1_ (u"ࠧࡔ࡯ࡤࡧࡰࡊ࡯ࡸࡰࠪ㼇"),l11l1l_l1_ (u"ࠨษ฼่ฬ์ࠧ㼈"),l11l1l_l1_ (u"ࠩสะือมࠨ㼉")]
	for l1ll1l_l1_,l111lll1ll1_l1_,l11l11111ll_l1_,l11l1111l11_l1_ in items:
		if type in [l11l1l_l1_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭㼊"),l11l1l_l1_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ㼋")]:
			l1ll1l_l1_,l1llll1_l1_,l1llll11l1_l1_,title = l1ll1l_l1_,l111lll1ll1_l1_,l11l11111ll_l1_,l11l1111l11_l1_
		else: l1ll1l_l1_,title,l1llll1_l1_,l1llll11l1_l1_ = l1ll1l_l1_,l111lll1ll1_l1_,l11l11111ll_l1_,l11l1111l11_l1_
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠬࡅࡶࡪࡧࡺࡁࡹࡸࡵࡦࠩ㼌"),l11l1l_l1_ (u"࠭ࠧ㼍"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㼎"),l11l1l_l1_ (u"ࠨࠩ㼏"),l1llll1_l1_,l1llll11l1_l1_)
		title = unescapeHTML(title)
		#l1lll11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠩสฯ์ิฯࡼษฮ๋ำ์࠯ࠧ㼐"),title,re.DOTALL)
		#if l1lll11l1_l1_: title = l1lll11l1_l1_[0][0]
		if l11l1l_l1_ (u"ࠪฬั๎ฯสࠢࠪ㼑") in title or l11l1l_l1_ (u"ࠫอา่ะ้ࠣࠫ㼒") in title:
			title = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㼓") + title.replace(l11l1l_l1_ (u"࠭ศอ๊าอࠥ࠭㼔"),l11l1l_l1_ (u"ࠧࠨ㼕")).replace(l11l1l_l1_ (u"ࠨสฯ์ิํࠠࠨ㼖"),l11l1l_l1_ (u"ࠩࠪ㼗"))
		title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ㼘"))
		if l11l1l_l1_ (u"ࠫฬ๊อๅไฬࠫ㼙") in title or l11l1l_l1_ (u"ࠬอไฮๆๅ๋ࠬ㼚") in title:
			l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥ࠮วๅฯ็ๆฮࢂวๅฯ็ๆ์࠯ࠠ࡝ࡦ࠮ࠫ㼛"),title,re.DOTALL)
			if l1ll11l_l1_:
				title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㼜") + l1ll11l_l1_[0][0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㼝"),l1111l_l1_+title,l1llll1_l1_,183,l1ll1l_l1_)
					l11l_l1_.append(title)
		elif any(value in title for value in l111l1l1l_l1_):
			l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ㼞") + l1llll11l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㼟"),l1111l_l1_+title,l1llll1_l1_,182,l1ll1l_l1_)
		else:
			l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"ࠫࡄࡹࡥࡳࡸࡨࡶࡸࡃࠧ㼠") + l1llll11l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㼡"),l1111l_l1_+title,l1llll1_l1_,183,l1ll1l_l1_)
	if type==l11l1l_l1_ (u"࠭ࠧ㼢"):
		items = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡰ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㼣"),html,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠨษ็ูๆำษࠡࠩ㼤"),l11l1l_l1_ (u"ࠩࠪ㼥"))
			if title!=l11l1l_l1_ (u"ࠪࠫ㼦"):
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㼧"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ㼨")+title,l1llll1_l1_,181)
	return
def l1lll1l1_l1_(url):
	l111l1l_l1_ = url.split(l11l1l_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ㼩"))[0]
	html = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ㼪"),headers,l11l1l_l1_ (u"ࠨࠩ㼫"),l11l1l_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ㼬"))
	block = re.findall(l11l1l_l1_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸ࡮ࡺ࡬ࡦࡀ࠱࠮ࡄ࡮ࡥࡪࡩ࡫ࡸࡂࠨࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㼭"),html,re.DOTALL)
	title,dummy,l1ll1l_l1_ = block[0]
	name = re.findall(l11l1l_l1_ (u"ࠫ࠭࠴ࠪࡀࠫࠣࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥࡡ࠰࠮࠻ࡠ࠯ࠬ㼮"),title,re.DOTALL)
	if name: name = l11l1l_l1_ (u"ࠬࡥࡍࡐࡆࡢࠫ㼯") + name[0][0]
	else: name = title
	items = []
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳࡏࡷࡰࡦࡪࡸࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㼰"),html,re.DOTALL)
	if l1l11l1_l1_:
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㼱"),l11l1l_l1_ (u"ࠨࠩ㼲"),l111l1l_l1_,str(l1l11l1_l1_))
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㼳"),block,re.DOTALL)
		for l1llll1_l1_ in items:
			l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
			title = re.findall(l11l1l_l1_ (u"ࠪࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭࠲࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ㼴"),l1llll1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭㼵"))[-2],re.DOTALL)
			if not title: title = re.findall(l11l1l_l1_ (u"ࠬ࠮ࠩ࠮ࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ㼶"),l1llll1_l1_.split(l11l1l_l1_ (u"࠭࠯ࠨ㼷"))[-2],re.DOTALL)
			if title: title = l11l1l_l1_ (u"ࠧࠡࠩ㼸") + title[0][1]
			else: title = l11l1l_l1_ (u"ࠨࠩ㼹")
			title = name + l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭㼺") + l11l1l_l1_ (u"ࠪห้ำไใหࠪ㼻") + title
			title = unescapeHTML(title)
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㼼"),l1111l_l1_+title,l1llll1_l1_,182,l1ll1l_l1_)
	if not items:
		title = unescapeHTML(title)
		if l11l1l_l1_ (u"ࠬฮฬ้ัฬࠤࠬ㼽") in title or l11l1l_l1_ (u"࠭ศอ๊า๋ࠥ࠭㼾") in title:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭㼿") + title.replace(l11l1l_l1_ (u"ࠨสฯ์ิฯࠠࠨ㽀"),l11l1l_l1_ (u"ࠩࠪ㽁")).replace(l11l1l_l1_ (u"ࠪฬั๎ฯ่ࠢࠪ㽂"),l11l1l_l1_ (u"ࠫࠬ㽃"))
		addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ㽄"),l1111l_l1_+title,url,182,l1ll1l_l1_)
	return
def PLAY(url):
	l11l1111l1l_l1_ = url.split(l11l1l_l1_ (u"࠭࠿ࡴࡧࡵࡺࡪࡸࡳ࠾ࠩ㽅"))
	l111l1l_l1_ = l11l1111l1l_l1_[0]
	del l11l1111l1l_l1_[0]
	html = OPENURL_CACHED(l1llll11_l1_,l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ㽆"),headers,l11l1l_l1_ (u"ࠨࠩ㽇"),l11l1l_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㽈"))
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡪࡴࡴࡴ࠮ࡵ࡬ࡾࡪࡀࠠ࠳࠷ࡳࡼࡀࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㽉"),html,re.DOTALL)[0]
	if l1llll1_l1_ not in l11l1111l1l_l1_: l11l1111l1l_l1_.append(l1llll1_l1_)
	l1lll1_l1_ = []
	# l111lllllll_l1_
	for l1llll1_l1_ in l11l1111l1l_l1_:
		if l11l1l_l1_ (u"ࠫ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࠪ㽊") in l1llll1_l1_:
			l111lllllll_l1_ = l1llll1_l1_
			l1lll1_l1_.append(l111lllllll_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡓࡡࡪࡰࠪ㽋"))
	# l111lllll1l_l1_
	for l1llll1_l1_ in l11l1111l1l_l1_:
		if l11l1l_l1_ (u"࠭࠺࠰࠱ࡹࡦ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠩ㽌") in l1llll1_l1_:
			html = OPENURL_CACHED(l1llll11_l1_,l1llll1_l1_,l11l1l_l1_ (u"ࠧࠨ㽍"),headers,l11l1l_l1_ (u"ࠨࠩ㽎"),l11l1l_l1_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ㽏"))
			html = html.decode(l11l1l_l1_ (u"ࠪࡻ࡮ࡴࡤࡰࡹࡶ࠱࠶࠸࠵࠷ࠩ㽐")).encode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ㽑"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></l111lll1l1l_l1_><l111llll11l_l1_ /><l111lll1l1l_l1_ l11l111111l_l1_=l11l1l_l1_ (u"ࠧࡩࡥ࡯ࡶࡨࡶࠧ㽒")>(\*\*\*\*\*\*\*\*|13721411411.l111lll11ll_l1_|)
			html = html.replace(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡺࡶ࠮࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦ࠱ࡧࡴࡳ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㽓"),l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㽔"))
			html = html.replace(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㽕"),l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠭㽖"))
			html = html.replace(l11l1l_l1_ (u"ࠪࡀ࠴ࡧ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡣࡴࠣ࠳ࡃࡂࡤࡪࡸࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࡂࠬ㽗"),l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ㽘"))
			html = html.replace(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡢࡰࡴࡧࡩࡷࠨࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠨ㽙"),l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠩ㽚"))
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠯ࠧ㽛"),html,re.DOTALL)
			if l1l11l1_l1_:
				#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㽜"),l11l1l_l1_ (u"ࠩࠪ㽝"),url,str(len(l1l11l1_l1_)))
				l111lll1l11_l1_,l111lllll11_l1_ = [],[]
				if len(l1l11l1_l1_)==1:
					title = l11l1l_l1_ (u"ࠪࠫ㽞")
					block = html
				else:
					for block in l1l11l1_l1_:
						l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨ࠮ࠫࡁ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠰࠭ࡃࡡ࠰࡜ࠫ࡞࠭ࡠ࠯ࡢࠪ࡝ࠬ࡟࠮࠰࠮࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠮࠭㽟"),block,re.DOTALL)
						if l1l1lll_l1_: block = l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࠧ㽠") + l1l1lll_l1_[0][1]
						l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴ࠤࠣ࠳ࡃ࠮࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࡟࠲࠳࠰࠿࠰࡞ࡺ࠯࠳࡮ࡴ࡮࡮ࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠫࠪ㽡"),block,re.DOTALL)
						if l1l1lll_l1_: block = l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࠩ㽢") + l1l1lll_l1_[0]
						l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃ࠮ࡂࡨࡳࠢࡶ࡭ࡿ࡫࠽ࠣ࠳ࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳࠼ࠢࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡣࡰ࡮ࡲࡶ࠿ࠩ࠳࠴࠵ࠥࠤ࠴ࡄ࠮ࠫࡁࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ㽣"),block,re.DOTALL)
						if l1l1lll_l1_: block = l1l1lll_l1_[0] + l11l1l_l1_ (u"ࠩࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ㽤")
						l11l1111111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡀ࠭࠴ࠪࡀࠫ࡫ࡸࡹࡶ࠺࠰࠱ࡸࡴ࠳ࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤ࠯ࠪࡲࡲࡱ࡯࡮ࡦࡾࡦࡳࡲ࠯࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰ࠩ㽥"),block,re.DOTALL)
						title = re.findall(l11l1l_l1_ (u"ࠫࡃࠦࠪࠩ࡝ࡡࡀࡃࡣࠫࠪࠢ࠭ࡀࠬ㽦"),l11l1111111_l1_[0][0],re.DOTALL)
						title = l11l1l_l1_ (u"ࠬࠦࠧ㽧").join(title)
						title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ㽨"))
						title = title.replace(l11l1l_l1_ (u"ࠧࠡࠢࠪ㽩"),l11l1l_l1_ (u"ࠨࠢࠪ㽪")).replace(l11l1l_l1_ (u"ࠩࠣࠤࠬ㽫"),l11l1l_l1_ (u"ࠪࠤࠬ㽬")).replace(l11l1l_l1_ (u"ࠫࠥࠦࠧ㽭"),l11l1l_l1_ (u"ࠬࠦࠧ㽮")).replace(l11l1l_l1_ (u"࠭ࠠࠡࠩ㽯"),l11l1l_l1_ (u"ࠧࠡࠩ㽰")).replace(l11l1l_l1_ (u"ࠨࠢࠣࠫ㽱"),l11l1l_l1_ (u"ࠩࠣࠫ㽲"))
						l111lll1l11_l1_.append(title)
					l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ๅ๏ี๊้ࠢส่๊฽ไ้ส࠽ࠫ㽳"), l111lll1l11_l1_)
					if l1l_l1_ == -1 : return
					title = l111lll1l11_l1_[l1l_l1_]
					block = l1l11l1_l1_[l1l_l1_]
				l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦࡢ࠮࠯ࠬࡂ࠳ࡡࡽࠫ࠯ࡪࡷࡱࡱ࠯ࠢࠨ㽴"),block,re.DOTALL)
				l111llll1l1_l1_ = l1llll1_l1_[0]
				l1lll1_l1_.append(l111llll1l1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡌ࡯ࡳࡷࡰࠫ㽵"))
				block = block.replace(l11l1l_l1_ (u"࠭เࠨ㽶"),l11l1l_l1_ (u"ࠧࠨ㽷"))
				block = block.replace(l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡵࡱ࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠶࠳࠺࠸࠶࠸࠱࠸࠷࠵࠽࠻࠴ࡰ࡯ࡩࠥࠫ㽸"),l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡣࡱࡷ࡬ࠧࠦࠠ࡝ࡰࠣࠤࠬ㽹"))
				block = block.replace(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࡤࡱࡰ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ㽺"),l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡥࡳࡹ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ㽻"))
				block = block.replace(l11l1l_l1_ (u"ู๊ࠬาใิหฯࠦวๅฬะ้๏๊ࠧ㽼"),l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࠨࠠࠡ࡞ࡱࠤࠥ࠭㽽"))
				block = block.replace(l11l1l_l1_ (u"ࠧา๊สฬ฼ࠦวๅฬะ้๏๊ࠧ㽾"),l11l1l_l1_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡤࡰࡹࡱࡰࡴࡧࡤࠣࠢࠣࡠࡳࠦࠠࠨ㽿"))
				block = block.replace(l11l1l_l1_ (u"ࠩึ๎ึ็ัศฬࠣห้๋ิศ้าࠫ㾀"),l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡹࡤࡸࡨ࡮ࠢࠡࠢ࡟ࡲࠥࠦࠧ㾁"))
				block = block.replace(l11l1l_l1_ (u"ࠫึ๎วษูࠣห้๋ิศ้าࠫ㾂"),l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡻࡦࡺࡣࡩࠤࠣࠤࡡࡴࠠࠡࠩ㾃"))
				l111lll1lll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࡞ࡧ࠯ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ㾄"),block,re.DOTALL)
				for l111llll1ll_l1_ in l111lll1lll_l1_:
					#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ㾅"),l11l1l_l1_ (u"ࠨࠩ㾆"),l11l1l_l1_ (u"ࠩࠪ㾇"),str(l111llll1ll_l1_))
					type = re.findall(l11l1l_l1_ (u"ࠪࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࠨ㾈"),l111llll1ll_l1_)
					if type:
						if type[0]!=l11l1l_l1_ (u"ࠫࡧࡵࡴࡩࠩ㾉"): type = l11l1l_l1_ (u"ࠬࡥ࡟ࠨ㾊")+type[0]
						else: type = l11l1l_l1_ (u"࠭ࠧ㾋")
					items = re.findall(l11l1l_l1_ (u"ࠧࠩࡁ࠿ࠥ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰ࠫࠫࡠࡼ࠱࡛ࠡ࡞ࡺࡡ࠯ࡂ࠯ࡧࡱࡱࡸࡃ࠴ࠪࡀࡾ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮ࡁࡨࡲࠡ࠱ࡁ࠲࠯ࡅࠩࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠵࠯ࡦ࠷ࡷࡷࡦࡸ࠮ࡤࡱࡰ࠳࠳࠰࠿ࠪࠤࠪ㾌"),l111llll1ll_l1_,re.DOTALL)
					for l111llll111_l1_,l1llll1_l1_ in items:
						title = re.findall(l11l1l_l1_ (u"ࠨࠪ࡟ࡻ࠰ࡡࠠ࡝ࡹࡠ࠮࠮ࡂࠧ㾍"),l111llll111_l1_)
						title = title[-1]
						l1llll1_l1_ = l1llll1_l1_ + l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ㾎") + title + type
						l1lll1_l1_.append(l1llll1_l1_)
	# l11l1111ll1_l1_
	l111ll1_l1_ = l111l1l_l1_.replace(l11l11_l1_,l11lll11ll_l1_)
	html = OPENURL_CACHED(l1llll11_l1_,l111ll1_l1_,l11l1l_l1_ (u"ࠪࠫ㾏"),headers,l11l1l_l1_ (u"ࠫࠬ㾐"),l11l1l_l1_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㾑"))
	items = re.findall(l11l1l_l1_ (u"࠭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㾒"),html,re.DOTALL)
	#l11ll1l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤࡠ࠳࠴ࠪࡀ࠱ࡨࡱࡧ࡫ࡤࡎ࠯ࠫࡠࡼ࠱ࠩ࠮࠰࠭ࡃ࠳࡮ࡴ࡮࡮ࠬࠫ㾓"),html,re.DOTALL)
	#if l11ll1l1l1_l1_:
	if items:
		#l11l1111ll1_l1_ = l11l1l_l1_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ㾔") + l11ll1l1l1_l1_[-1] + l11l1l_l1_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ㾕")
		l11l1111ll1_l1_ = items[-1]
		l1lll1_l1_.append(l11l1111ll1_l1_+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡑࡴࡨࡩ࡭ࡧࠪ㾖"))
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㾗"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭㾘"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ㾙"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ㾚"),l11l1l_l1_ (u"ࠨ࠭ࠪ㾛"))
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ㾜"),headers,l11l1l_l1_ (u"ࠪࠫ㾝"),l11l1l_l1_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊ࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ㾞"))
	items = re.findall(l11l1l_l1_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡯ࡱࡶ࡬ࡳࡳࡄࠧ㾟"),html,re.DOTALL)
	l111l11ll_l1_ = [ l11l1l_l1_ (u"࠭ࠧ㾠") ]
	l1111l1ll_l1_ = [ l11l1l_l1_ (u"ࠧศๆๆ่ࠥ๎ศะ๊้ࠤๆ๊สาࠩ㾡") ]
	for category,title in items:
		l111l11ll_l1_.append(category)
		l1111l1ll_l1_.append(title)
	if category:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ㾢"), l1111l1ll_l1_)
		if l1l_l1_ == -1 : return
		category = l111l11ll_l1_[l1l_l1_]
	else: category = l11l1l_l1_ (u"ࠩࠪ㾣")
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠪ࠳ࡄࡹ࠽ࠨ㾤")+search+l11l1l_l1_ (u"ࠫࠫࡳࡣࡢࡶࡀࠫ㾥")+category
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭㾦"),l11l1l_l1_ (u"࠭ࠧ㾧"),url,url)
	l1lllll_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ垖")
l1111l_l1_ = l11l1l_l1_ (u"ࠩࡢࡗࡍࡓ࡟ࠨ垗")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l11lll11ll_l1_ = l1l1l1l_l1_[l1ll1_l1_][1]
l1l1l1lllll_l1_ = l1l1l1l_l1_[l1ll1_l1_][2]
def MAIN(mode,url,text):
	if   mode==50: results = MENU()
	elif mode==51: results = l1lllll_l1_(url)
	elif mode==52: results = l1lll1l1_l1_(url)
	elif mode==53: results = PLAY(url)
	elif mode==55: results = l11l1llll1l1_l1_()
	elif mode==56: results = l11l1lll1l1l_l1_()
	elif mode==57: results = l11l1lll1ll1_l1_(url,1)
	elif mode==58: results = l11l1lll1ll1_l1_(url,2)
	elif mode==59: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垘"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ垙"),l11l1l_l1_ (u"ࠬ࠭垚"),59,l11l1l_l1_ (u"࠭ࠧ垛"),l11l1l_l1_ (u"ࠧࠨ垜"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ垝"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ垞"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ垟"),l11l1l_l1_ (u"ࠫࠬ垠"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ垡"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ垢")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่ืู้ไศฬࠪ垣"),l11l1l_l1_ (u"ࠨࠩ垤"),56)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垥"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ垦")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊วโๆส้ࠬ垧"),l11l1l_l1_ (u"ࠬ࠭垨"),55)
	return l11l1l_l1_ (u"࠭ࠧ垩")
def l11l1llll1l1_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垪"),l1111l_l1_+l11l1l_l1_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ垫"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ垬"),51)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ垭"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ垮"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ垯"),51)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭垰"),l1111l_l1_+l11l1l_l1_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ垱"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ垲"),51)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ垳"),l1111l_l1_+l11l1l_l1_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ垴"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ垵"),51)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ垶"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭垷"),l11l1l_l1_ (u"ࠧࠨ垸"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ垹"),l1111l_l1_+l11l1l_l1_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭垺"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ垻"),57)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ垼"),l1111l_l1_+l11l1l_l1_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ垽"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ垾"),57)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ垿"),l1111l_l1_+l11l1l_l1_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ埀"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ埁"),57)
	return
def l11l1lll1l1l_l1_():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ埂"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ埃"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ埄"),51)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭埅"),l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ埆"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ埇"),51)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ埈"),l1111l_l1_+l11l1l_l1_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ埉"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ埊"),51)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ埋"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ埌"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ埍"),51)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭城"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ埏"),l11l1l_l1_ (u"ࠪࠫ埐"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ埑"),l1111l_l1_+l11l1l_l1_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ埒"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭埓"),57)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ埔"),l1111l_l1_+l11l1l_l1_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ埕"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ埖"),57)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ埗"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ埘"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ埙"),57)
	return
def l1lllll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ埚"),l11l1l_l1_ (u"ࠧࠨ埛"),url,url)
	if l11l1l_l1_ (u"ࠨࡁࠪ埜") in url:
		parts = url.split(l11l1l_l1_ (u"ࠩࡂࠫ埝"))
		url = parts[0]
		filter = l11l1l_l1_ (u"ࠪࡃࠬ埞") + QUOTE(parts[1],l11l1l_l1_ (u"ࠫࡂࠬ࠺࠰ࠧࠪ域"))
	else: filter = l11l1l_l1_ (u"ࠬ࠭埠")
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ埡"),l11l1l_l1_ (u"ࠧࠨ埢"),filter,l11l1l_l1_ (u"ࠨࠩ埣"))
	parts = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ埤"))
	sort,l11lll1_l1_,type = parts[-1],parts[-2],parts[-3]
	if sort in [l11l1l_l1_ (u"ࠪࡽࡴࡶࠧ埥"),l11l1l_l1_ (u"ࠫࡷ࡫ࡶࡪࡧࡺࠫ埦"),l11l1l_l1_ (u"ࠬࡼࡩࡦࡹࡶࠫ埧")]:
		if type==l11l1l_l1_ (u"࠭࡭ࡰࡸ࡬ࡩࠬ埨"): l11ll1l1l_l1_=l11l1l_l1_ (u"ࠧโ์็้ࠬ埩")
		elif type==l11l1l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ埪"): l11ll1l1l_l1_=l11l1l_l1_ (u"่ࠩืู้ไࠨ埫")
		#url = l11l11_l1_ + l11l1l_l1_ (u"ࠪ࠳࡫࡯࡬ࡵࡧࡵ࠱ࡵࡸ࡯ࡨࡴࡤࡱࡸ࠵ࠧ埬") + QUOTE(l11ll1l1l_l1_) + l11l1l_l1_ (u"ࠫ࠴࠭埭") + l11lll1_l1_ + l11l1l_l1_ (u"ࠬ࠵ࠧ埮") + sort + filter
		url = l11l11_l1_ + l11l1l_l1_ (u"࠭࠯ࡨࡧࡱࡶࡪ࠵ࡦࡪ࡮ࡷࡩࡷ࠵ࠧ埯") + QUOTE(l11ll1l1l_l1_) + l11l1l_l1_ (u"ࠧ࠰ࠩ埰") + l11lll1_l1_ + l11l1l_l1_ (u"ࠨ࠱ࠪ埱") + sort + filter
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ埲"),l11l1l_l1_ (u"ࠪࠫ埳"),l11l1l_l1_ (u"ࠫࠬ埴"),url)
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠬ࠭埵"),l11l1l_l1_ (u"࠭ࠧ埶"),l11l1l_l1_ (u"ࠧࠨ執"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ埸"))
		#items = re.findall(l11l1l_l1_ (u"ࠩࠥࡶࡪ࡬ࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠱࠿ࠣࡰࡸࡱࡪࡶࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬࠣࡴࡨࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ培"),html,re.DOTALL)
		items = re.findall(l11l1l_l1_ (u"ࠪࠦࡵ࡯ࡤࠣ࠼ࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡶࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࠥࡴࡪࡶࡩࡴࡱࡧࡩࡸࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡱࡴࡨࡷࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ基"),html,re.DOTALL)
		l1l1l1l1l11_l1_=0
		for id,title,l11l1lll111l_l1_,l1ll1l_l1_ in items:
			l1l1l1l1l11_l1_ += 1
			#l1ll1l_l1_ = l11lll11ll_l1_ + l11l1l_l1_ (u"ࠫ࠴࡯࡭ࡨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ埻") + l1ll1l_l1_ + l11l1l_l1_ (u"ࠬ࠳࠲࠯࡬ࡳ࡫ࠬ埼")
			l1ll1l_l1_ = l1l1l1lllll_l1_ + l11l1l_l1_ (u"࠭࠯ࡷ࠴࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰࡯ࡤ࡭ࡳ࠵ࠧ埽") + l1ll1l_l1_ + l11l1l_l1_ (u"ࠧ࠮࠴࠱࡮ࡵ࡭ࠧ埾")
			l1llll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ埿") + id
			if type==l11l1l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ堀"): addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ堁"),l1111l_l1_+title,l1llll1_l1_,53,l1ll1l_l1_)
			if type==l11l1l_l1_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ堂"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堃"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ࠥ࠭堄")+title,l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡧࡳࡁࠬ堅")+l11l1lll111l_l1_+l11l1l_l1_ (u"ࠨ࠿ࠪ堆")+title+l11l1l_l1_ (u"ࠩࡀࠫ堇")+l1ll1l_l1_,52,l1ll1l_l1_)
	else:
		if type==l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࠩ堈"): l11ll1l1l_l1_=l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ堉")
		elif type==l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ堊"): l11ll1l1l_l1_=l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭堋")
		url = l11lll11ll_l1_ + l11l1l_l1_ (u"ࠧ࠰࡬ࡶࡳࡳ࠵ࡳࡦ࡮ࡨࡧࡹ࡫ࡤ࠰ࠩ堌") + sort + l11l1l_l1_ (u"ࠨ࠯ࠪ堍") + l11ll1l1l_l1_ + l11l1l_l1_ (u"ࠩ࠰࡛࡜࠴ࡪࡴࡱࡱࠫ堎")
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠪࠫ堏"),l11l1l_l1_ (u"ࠫࠬ堐"),l11l1l_l1_ (u"ࠬ࠭堑"),l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ堒"))
		items = re.findall(l11l1l_l1_ (u"ࠧࠣࡴࡨࡪࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡥࡱࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡦࡦࡹࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ堓"),html,re.DOTALL)
		l1l1l1l1l11_l1_=0
		for id,l11l1lll111l_l1_,l1ll1l_l1_,title in items:
			l1l1l1l1l11_l1_ += 1
			l1ll1l_l1_ = l11lll11ll_l1_ + l11l1l_l1_ (u"ࠨ࠱࡬ࡱ࡬࠵ࡰࡳࡱࡪࡶࡦࡳ࠯ࠨ堔") + l1ll1l_l1_ + l11l1l_l1_ (u"ࠩ࠰࠶࠳ࡰࡰࡨࠩ堕")
			l1llll1_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭堖") + id
			if type==l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ堗"): addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ堘"),l1111l_l1_+title,l1llll1_l1_,53,l1ll1l_l1_)
			elif type==l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭堙"): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ堚"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊ࠠࠨ堛")+title,l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡩࡵࡃࠧ堜")+l11l1lll111l_l1_+l11l1l_l1_ (u"ࠪࡁࠬ堝")+title+l11l1l_l1_ (u"ࠫࡂ࠭堞")+l1ll1l_l1_,52,l1ll1l_l1_)
	title=l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ堟")
	if l1l1l1l1l11_l1_==16:
		for l1l1ll11111_l1_ in range(1,13) :
			if not l11lll1_l1_==str(l1l1ll11111_l1_):
				#url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡸࡪࡸ࠭ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠱ࠪ堠")+type+l11l1l_l1_ (u"ࠧ࠰ࠩ堡")+str(l1l1ll11111_l1_)+l11l1l_l1_ (u"ࠨ࠱ࠪ堢")+sort + filter
				url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠱ࠪ堣")+type+l11l1l_l1_ (u"ࠪ࠳ࠬ堤")+str(l1l1ll11111_l1_)+l11l1l_l1_ (u"ࠫ࠴࠭堥")+sort + filter
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ堦"),l1111l_l1_+title+str(l1l1ll11111_l1_),url,51)
	return
def l1lll1l1_l1_(url):
	parts = url.split(l11l1l_l1_ (u"࠭࠽ࠨ堧"))
	l11l1lll111l_l1_ = int(parts[1])
	name = l1llll_l1_(parts[2])
	name = name.replace(l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ๋ำๅี็ࠤࠬ堨"),l11l1l_l1_ (u"ࠨࠩ堩"))
	l1ll1l_l1_ = parts[3]
	url = url.split(l11l1l_l1_ (u"ࠩࡂࠫ堪"))[0]
	if l11l1lll111l_l1_==0:
		html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠪࠫ堫"),l11l1l_l1_ (u"ࠫࠬ堬"),l11l1l_l1_ (u"ࠬ࠭堭"),l11l1l_l1_ (u"࠭ࡓࡉࡑࡒࡊࡒࡇࡘ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ堮"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡨࡰࡪࡩࡴࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡧ࡯ࡩࡨࡺ࠾ࠨ堯"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ堰"),block,re.DOTALL)
		l11l1lll111l_l1_ = int(items[-1])
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ報"),l11l1l_l1_ (u"ࠪࠫ堲"),l11l1lll111l_l1_,l11l1l_l1_ (u"ࠫࠬ堳"))
	#name = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠧࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡕ࡫ࡷࡰࡪࠨ場") )
	#l1ll1l_l1_ = xbmc.getInfoLabel( l11l1l_l1_ (u"ࠨࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡖ࡫ࡹࡲࡨࠢ堵") )
	for l1ll11l_l1_ in range(l11l1lll111l_l1_,0,-1):
		l1llll1_l1_ = url + l11l1l_l1_ (u"ࠧࡀࡧࡳࡁࠬ堶") + str(l1ll11l_l1_)
		title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭堷")+name+l11l1l_l1_ (u"ࠩࠣ࠱ࠥอไฮๆๅอࠥ࠭堸")+str(l1ll11l_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ堹"),l1111l_l1_+title,l1llll1_l1_,53,l1ll1l_l1_)
	return
def PLAY(url):
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠫࠬ堺"),l11l1l_l1_ (u"ࠬ࠭堻"),l11l1l_l1_ (u"࠭ࠧ堼"),l11l1l_l1_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ堽"))
	l11l1lll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨ็อ์ๆืฺࠠๆ์ࠤู๎แࠡ็ส็ุࠦศฺั࠱࠮ࡄࡳ࡯࡮ࡧࡱࡸࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ堾"),html,re.DOTALL)
	if l11l1lll1l11_l1_:
		time = l11l1lll1l11_l1_[1].replace(l11l1l_l1_ (u"ࠩࡗࠫ堿"),l11l1l_l1_ (u"ࠪࠤࠥࠦࠠࠨ塀"))
		DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ塁"),l11l1l_l1_ (u"ࠬ࠭塂"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠨ塃"),l11l1l_l1_ (u"่ࠧาสࠤฬ๊แ๋ัํ์ู๊ࠥไ๊้ࠤ๊ะ่โำࠣ฽้๏ࠠี๊ไࠤ๊อใิࠢห฽ิࠦ็ัษࠣห้๎โหࠩ塄")+l11l1l_l1_ (u"ࠨ࡞ࡱࠫ塅")+time)
		return
	#if l11l1l_l1_ (u"้ࠩ฽ฯึัࠡ฻็ํࠥ๎โ้฻ࠣา฼ษࠧ塆") in html:
	#	DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ塇"),l11l1l_l1_ (u"ࠫࠬ塈"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่์็฿ࠠศๆฦู้๐ࠧ塉"),l11l1l_l1_ (u"࠭ๆฺฬำีࠥ฿ไ๊๋ࠢๆํ฿ࠠฯูฦࠫ塊"))
	#	return
	l11l1ll1llll_l1_,l11l1lll1lll_l1_ = [],[]
	l11l1llll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡷࡣࡵࠤࡴࡸࡩࡨ࡫ࡱࡣࡱ࡯࡮࡬ࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ塋"),html,re.DOTALL)[0]
	l11l1lll11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡸࡤࡶࠥࡨࡡࡤ࡭ࡸࡴࡤࡵࡲࡪࡩ࡬ࡲࡤࡲࡩ࡯࡭ࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭塌"),html,re.DOTALL)[0]
	# l1lll1l1l_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡰࡸࡀࠠࠩ࠰࠭ࡃ࠮ࡥ࡬ࡪࡰ࡮ࡠ࠰ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭塍"),html,re.DOTALL)
	for server,l1llll1_l1_ in l1l1_l1_:
		if l11l1l_l1_ (u"ࠪࡦࡦࡩ࡫ࡶࡲࠪ塎") in server:
			server = l11l1l_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠤࡸ࡫ࡲࡷࡧࡵࠫ塏")
			url = l11l1lll11ll_l1_ + l1llll1_l1_
		else:
			server = l11l1l_l1_ (u"ࠬࡳࡡࡪࡰࠣࡷࡪࡸࡶࡦࡴࠪ塐")
			url = l11l1llll11l_l1_ + l1llll1_l1_
		if l11l1l_l1_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ塑") in url:
			l11l1ll1llll_l1_.append(url)
			l11l1lll1lll_l1_.append(l11l1l_l1_ (u"ࠧ࡮࠵ࡸ࠼ࠥࠦࠧ塒")+server)
		l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࠏࡩࡧࠢࠪ࠲ࡲ࠹ࡵ࠹ࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠯ࡰ࡮ࡴ࡫ࡍࡋࡖࡘࠥࡃࠠࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠮ࡵࡳ࡮ࠬࠎࠎࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙ࡡ࠰࡞࠿ࡀࠫ࠲࠷ࠧ࠻ࠌࠌࠍࠎࠏࡩࡵࡧࡰࡷࡤࡻࡲ࡭࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠯ࠊࠊࠋࠌࠍ࡮ࡺࡥ࡮ࡵࡢࡲࡦࡳࡥ࠯ࡣࡳࡴࡪࡴࡤࠩࠩࡰ࠷ࡺ࠾ࠠࠡࠩ࠮ࡷࡪࡸࡶࡦࡴࠬࠎࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࠋࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸࡡ࡯ࡩࡨࠬࡱ࡫࡮ࠩࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠭࠮ࡀࠊࠊࠋࠌࠍࠎ࡯ࡴࡦ࡯ࡶࡣࡺࡸ࡬࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰࡒࡉࡔࡖ࡞࡭ࡢ࠯ࠊࠊࠋࠌࠍࠎ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥࡍࡋࡖࡘࡠ࡯࡝࠯ࡵࡳࡰ࡮ࡺࠨࠨࠢࠪ࠭ࡠ࠶࡝ࠋࠋࠌࠍࠎࠏࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࡞࡭ࡢ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࡧ࡫࡯ࡩࡹࡿࡰࡦ࠮ࠪࠫ࠮࠴ࡳࡵࡴ࡬ࡴ࠭࠭ࠠࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠦࠠࠡࠩ࠯ࠫࠥࠦࠧࠪࠌࠌࠍࠎࠏࠉࡪࡶࡨࡱࡸࡥ࡮ࡢ࡯ࡨ࠲ࡦࡶࡰࡦࡰࡧࠬ࡫࡯࡬ࡦࡶࡼࡴࡪ࠱ࠧࠡࠢࠪ࠯ࡸ࡫ࡲࡷࡧࡵ࠯ࠬࠦࠠࠨ࠭ࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠧࠨࠢ塓")
	# l11111l1_l1_ l1l1_l1_
	l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡰࡴ࠹ࡀ࠮ࠫࡁࡢࡰ࡮ࡴ࡫࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ塔"),html,re.DOTALL)
	l1l1_l1_ += re.findall(l11l1l_l1_ (u"ࠪࡱࡵ࠺࠺࠯ࠬࡂࡠࡹ࠮࠮ࠫࡁࠬࡣࡱ࡯࡮࡬࡞࠮ࠦ࠭࠴ࠪࡀࠫࠥࠫ塕"),html,re.DOTALL)
	for server,l1llll1_l1_ in l1l1_l1_:
		filename = l1llll1_l1_.split(l11l1l_l1_ (u"ࠫ࠴࠭塖"))[-1]
		filename = filename.replace(l11l1l_l1_ (u"ࠬ࡬ࡡ࡭࡮ࡥࡥࡨࡱࠧ塗"),l11l1l_l1_ (u"࠭ࠧ塘"))
		filename = filename.replace(l11l1l_l1_ (u"ࠧ࠯࡯ࡳ࠸ࠬ塙"),l11l1l_l1_ (u"ࠨࠩ塚"))
		filename = filename.replace(l11l1l_l1_ (u"ࠩ࠰ࠫ塛"),l11l1l_l1_ (u"ࠪࠫ塜"))
		if l11l1l_l1_ (u"ࠫࡧࡧࡣ࡬ࡷࡳࠫ塝") in server:
			server = l11l1l_l1_ (u"ࠬࡨࡡࡤ࡭ࡸࡴࠥࡹࡥࡳࡸࡨࡶࠬ塞")
			url = l11l1lll11ll_l1_ + l1llll1_l1_
		else:
			server = l11l1l_l1_ (u"࠭࡭ࡢ࡫ࡱࠤࡸ࡫ࡲࡷࡧࡵࠫ塟")
			url = l11l1llll11l_l1_ + l1llll1_l1_
		l11l1ll1llll_l1_.append(url)
		l11l1lll1lll_l1_.append(l11l1l_l1_ (u"ࠧ࡮ࡲ࠷ࠤࠥ࠭塠")+server+l11l1l_l1_ (u"ࠨࠢࠣࠫ塡")+filename)
	l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩࡖࡩࡱ࡫ࡣࡵ࡙ࠢ࡭ࡩ࡫࡯ࠡࡓࡸࡥࡱ࡯ࡴࡺ࠼ࠪ塢"), l11l1lll1lll_l1_)
	if l1l_l1_ == -1 : return
	url = l11l1ll1llll_l1_[l1l_l1_]
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ塣"))
	return
def l11l1lll1ll1_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ塤"),l11l1l_l1_ (u"ࠬ࠭塥"),url,url)
	if l11l1l_l1_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭塦") in url: l111l1l_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰ࡩࡨࡲࡷ࡫࠯ๆี็ื้࠭塧")
	else: l111l1l_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠱ࡪࡩࡳࡸࡥ࠰ใํ่๊࠭塨")
	l111l1l_l1_ = QUOTE(l111l1l_l1_)
	html = OPENURL_CACHED(l1llll11_l1_,l111l1l_l1_,l11l1l_l1_ (u"ࠩࠪ塩"),l11l1l_l1_ (u"ࠪࠫ塪"),l11l1l_l1_ (u"ࠫࠬ填"),l11l1l_l1_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡇࡋࡏࡘࡊࡘࡓ࠮࠳ࡶࡸࠬ塬"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ塭"),l11l1l_l1_ (u"ࠧࠨ塮"),url,html)
	if type==1: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ塯"),html,re.DOTALL)
	elif type==2: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ塰"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ塱"),block,re.DOTALL)
	if type==1:
		for l11l1llll111_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ塲"),l1111l_l1_+title,url+l11l1l_l1_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ塳")+l11l1llll111_l1_,58)
	elif type==2:
		url,l11l1llll111_l1_ = url.split(l11l1l_l1_ (u"࠭࠿ࠨ塴"))
		for l11lll1l1ll_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ塵"),l1111l_l1_+title,url+l11l1l_l1_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ塶")+l11lll1l1ll_l1_+l11l1l_l1_ (u"ࠩࠩࠫ塷")+l11l1llll111_l1_,51)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search: search = OPEN_KEYBOARD()
	if not search: return
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ塸"),l11l1l_l1_ (u"ࠫࠬ塹"),search,search)
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"ࠬࠦࠧ塺"),l11l1l_l1_ (u"࠭ࠥ࠳࠲ࠪ塻"))
	#response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ塼"), l11l11_l1_, l11l1l_l1_ (u"ࠨࠩ塽"), l11l1l_l1_ (u"ࠩࠪ塾"), True,l11l1l_l1_ (u"ࠪࠫ塿"),l11l1l_l1_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ墀"))
	#html = response.content
	#cookies = response.cookies.get_dict()
	#l11l111ll_l1_ = cookies[l11l1l_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳ࠭墁")]
	#l11l1lll11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡥࡣࡴࡴࡩࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭墂"),html,re.DOTALL)
	#l11l1lll11l1_l1_ = l11l1lll11l1_l1_[0]
	#payload = l11l1l_l1_ (u"ࠧࡠࡥࡶࡶ࡫ࡃࠧ境") + l11l1lll11l1_l1_ + l11l1l_l1_ (u"ࠨࠨࡴࡁࠬ墄") + QUOTE(l11111l_l1_)
	#headers = { l11l1l_l1_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ墅"):l11l1l_l1_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ墆") , l11l1l_l1_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ墇"):l11l1l_l1_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡃࠧ墈")+l11l111ll_l1_ }
	#url = l11l11_l1_ + l11l1l_l1_ (u"ࠨ࠯ࡴࡧࡤࡶࡨ࡮ࠢ墉")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ墊"), url, payload, headers, True,l11l1l_l1_ (u"ࠨࠩ墋"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨ墌"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧ墍")+l11111l_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ墎"),url,l11l1l_l1_ (u"ࠬ࠭墏"),l11l1l_l1_ (u"࠭ࠧ墐"),True,l11l1l_l1_ (u"ࠧࠨ墑"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚࠰ࡗࡊࡇࡒࡄࡊ࠰࠶ࡳࡪࠧ墒"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡪࡩࡳ࡫ࡲࡢ࡮࠰ࡦࡴࡪࡹࠩ࠰࠭ࡃ࠮ࡹࡥࡢࡴࡦ࡬࠲ࡨ࡯ࡵࡶࡲࡱ࠲ࡶࡡࡥࡦ࡬ࡲ࡬࠭墓"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ墔"),block,re.DOTALL)
	if items:
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			#title = title.decode(l11l1l_l1_ (u"ࠫࡺࡺࡦ࠹ࠩ墕")).encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪ墖"))
			url = l11l11_l1_ + l1llll1_l1_
			if l11l1l_l1_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ増") in url:
				if l11l1l_l1_ (u"ࠧࡀࡧࡳࡁࠬ墘") in url:
					title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥๅิๆึ่ࠥ࠭墙")+title
					url = url.replace(l11l1l_l1_ (u"ࠩࡂࡩࡵࡃ࠱ࠨ墚"),l11l1l_l1_ (u"ࠪࡃࡪࡶ࠽࠱ࠩ墛"))
					url = url+l11l1l_l1_ (u"ࠫࡂ࠭墜")+QUOTE(title)+l11l1l_l1_ (u"ࠬࡃࠧ墝")+l1ll1l_l1_
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭增"),l1111l_l1_+title,url,52,l1ll1l_l1_)
				else:
					title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ็๊ๅ็ࠣࠫ墟")+title
					addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ墠"),l1111l_l1_+title,url,53,l1ll1l_l1_)
	#else: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ墡"),l11l1l_l1_ (u"ࠪࠫ墢"),l11l1l_l1_ (u"ࠫࡳࡵࠠࡳࡧࡶࡹࡱࡺࡳࠨ墣"),l11l1l_l1_ (u"๊ࠬวࠡฬ๋ะิࠦๆหษษะ๊ࠥไษฯฮࠫ墤"))
	return
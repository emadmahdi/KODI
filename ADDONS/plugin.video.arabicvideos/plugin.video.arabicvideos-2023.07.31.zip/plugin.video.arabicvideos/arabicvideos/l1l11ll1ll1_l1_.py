# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚ࠬ㋡")
l11l11_l1_ = l1l1l1l_l1_[l11l1l_l1_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭㋢")][0]
def MAIN(mode,url):
	if   mode==100: results = MENU()
	elif mode==101: results = ITEMS(l11l1l_l1_ (u"ࠧ࠱ࠩ㋣"),True)
	elif mode==102: results = ITEMS(l11l1l_l1_ (u"ࠨ࠳ࠪ㋤"),True)
	elif mode==103: results = ITEMS(l11l1l_l1_ (u"ࠩ࠵ࠫ㋥"),True)
	elif mode==104: results = ITEMS(l11l1l_l1_ (u"ࠪ࠷ࠬ㋦"),True)
	elif mode==105: results = PLAY(url)
	elif mode==106: results = ITEMS(l11l1l_l1_ (u"ࠫ࠹࠭㋧"),True)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㋨"),l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ㋩")+l11l1l_l1_ (u"ࠧๅๆุ่ฯืใ๋่ࠣฬำีๅสࠢࡐ࠷࡚࠭㋪"),l11l1l_l1_ (u"ࠨࠩ㋫"),710)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㋬"),l11l1l_l1_ (u"ࠪࡣࡎࡖࡔࡠࠩ㋭")+l11l1l_l1_ (u"้๊ࠫๅีฬิ็๏์ࠠษะา้ฮࠦࡉࡑࡖ࡙ࠫ㋮"),l11l1l_l1_ (u"ࠬ࠭㋯"),230)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㋰"),l11l1l_l1_ (u"ࠧࡠࡖ࡙࠴ࡤ࠭㋱")+l11l1l_l1_ (u"ࠨไ้์ฬะࠠๆ่้ࠣํอโฺ้สࠤฬ๊รึๆํอࠬ㋲"),l11l1l_l1_ (u"ࠩࠪ㋳"),101)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㋴"),l11l1l_l1_ (u"ࠫࡤ࡚ࡖ࠵ࡡࠪ㋵")+l11l1l_l1_ (u"่ࠬๆ้ษอࠤ๊ิสศำฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㋶"),l11l1l_l1_ (u"࠭ࠧ㋷"),106)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㋸"),l11l1l_l1_ (u"ࠨࡡ࡜࡙࡙ࡥࠧ㋹")+l11l1l_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ㋺"),l11l1l_l1_ (u"ࠪࠫ㋻"),147)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㋼"),l11l1l_l1_ (u"ࠬࡥ࡙ࡖࡖࡢࠫ㋽")+l11l1l_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ㋾"),l11l1l_l1_ (u"ࠧࠨ㋿"),148)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㌀"),l11l1l_l1_ (u"ࠩࡢࡍࡋࡒ࡟ࠨ㌁")+l11l1l_l1_ (u"ࠪࠤ่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ๊์ࠠๆ๊ๅ฽์๋ࠠࠡࠩ㌂"),l11l1l_l1_ (u"ࠫࠬ㌃"),28)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ㌄"),l11l1l_l1_ (u"࠭࡟ࡎࡔࡉࡣࠬ㌅")+l11l1l_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ㌆"),l11l1l_l1_ (u"ࠨࠩ㌇"),41)
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㌈"),l11l1l_l1_ (u"ࠪࡣࡐ࡝ࡔࡠࠩ㌉")+l11l1l_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ㌊"),l11l1l_l1_ (u"ࠬ࠭㌋"),135)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫ㌌"),l11l1l_l1_ (u"ࠧࡠࡒࡑࡘࡤ࠭㌍")+l11l1l_l1_ (u"ࠨไ้หฮࠦ็ๅษ้๋ࠣࠦๅ้ไ฼ࠤออๆ๋ฬࠪ㌎"),l11l1l_l1_ (u"ࠩࠪ㌏"),38)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㌐"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㌑"),l11l1l_l1_ (u"ࠬ࠭㌒"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㌓"),l11l1l_l1_ (u"ࠧࡠࡖ࡙࠵ࡤ࠭㌔")+l11l1l_l1_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋หࠣ฽ฬ๋ษࠨ㌕"),l11l1l_l1_ (u"ࠩࠪ㌖"),102)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㌗"),l11l1l_l1_ (u"ࠫࡤ࡚ࡖ࠳ࡡࠪ㌘")+l11l1l_l1_ (u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊๏ฯࠠฯษุอࠬ㌙"),l11l1l_l1_ (u"࠭ࠧ㌚"),103)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㌛"),l11l1l_l1_ (u"ࠨࡡࡗ࡚࠸ࡥࠧ㌜")+l11l1l_l1_ (u"ࠩๅ๊ํอสࠡฬ็ๅื๐่็์ฬࠤ้๊แฮืࠪ㌝"),l11l1l_l1_ (u"ࠪࠫ㌞"),104)
	return
def ITEMS(menu,l1ll_l1_=True):
	l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤ࡚ࡖࠨ㌟")+menu+l11l1l_l1_ (u"ࠬࡥࠧ㌠")
	client = l1l11ll1lll_l1_(32)
	payload = {l11l1l_l1_ (u"࠭ࡩࡥࠩ㌡"):l11l1l_l1_ (u"ࠧࠨ㌢"),l11l1l_l1_ (u"ࠨࡷࡶࡩࡷ࠭㌣"):client,l11l1l_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㌤"):l11l1l_l1_ (u"ࠪࡰ࡮ࡹࡴࠨ㌥"),l11l1l_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㌦"):menu}
	#data = l1ll11ll1_l1_(payload)
	#LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㌧"),str(payload))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㌨"),str(data))
	#response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㌩"), l11l11_l1_, payload, l11l1l_l1_ (u"ࠨࠩ㌪"), True,l11l1l_l1_ (u"ࠩࠪ㌫"),l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡕࡘ࠰ࡍ࡙ࡋࡍࡔ࠯࠴ࡷࡹ࠭㌬"))
	#html = response.content
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㌭"),l11l11_l1_,payload,l11l1l_l1_ (u"ࠬ࠭㌮"),l11l1l_l1_ (u"࠭ࠧ㌯"),l11l1l_l1_ (u"ࠧࠨ㌰"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫ㌱"))
	html = response.content
	#html = html.replace(l11l1l_l1_ (u"ࠩ࡟ࡶࠬ㌲"),l11l1l_l1_ (u"ࠪࠫ㌳"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ㌴"),l11l1l_l1_ (u"ࠬ࠭㌵"),html,html)
	#file = open(l11l1l_l1_ (u"࠭ࡳ࠻࠱ࡨࡱࡦࡪ࠮ࡩࡶࡰࡰࠬ㌶"), l11l1l_l1_ (u"ࠧࡸࠩ㌷"))
	#file.write(html)
	#file.close()
	items = re.findall(l11l1l_l1_ (u"ࠨࠪ࡞ࡢࡀࡢࡲ࡝ࡰࡠ࠯ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠪ࠱࠮ࡄ࠯࠻࠼ࠩ㌸"),html,re.DOTALL)
	if items:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l11l1l_l1_ (u"ࠩࡤࡰࠬ㌹"),l11l1l_l1_ (u"ࠪࡅࡱ࠭㌺"))
			start = start.replace(l11l1l_l1_ (u"ࠫࡊࡲࠧ㌻"),l11l1l_l1_ (u"ࠬࡇ࡬ࠨ㌼"))
			start = start.replace(l11l1l_l1_ (u"࠭ࡁࡍࠩ㌽"),l11l1l_l1_ (u"ࠧࡂ࡮ࠪ㌾"))
			start = start.replace(l11l1l_l1_ (u"ࠨࡇࡏࠫ㌿"),l11l1l_l1_ (u"ࠩࡄࡰࠬ㍀"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l11l1l_l1_ (u"ࠪࡅࡱ࠳ࠧ㍁"),l11l1l_l1_ (u"ࠫࡆࡲࠧ㍂"))
			start = start.replace(l11l1l_l1_ (u"ࠬࡇ࡬ࠡࠩ㍃"),l11l1l_l1_ (u"࠭ࡁ࡭ࠩ㍄"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l11ll1l1l1_l1_,name,l1ll1l_l1_ in items:
			if l11l1l_l1_ (u"ࠧࠤࠩ㍅") in source: continue
			#if source in [l11l1l_l1_ (u"ࠨࡐࡗࠫ㍆"),l11l1l_l1_ (u"ࠩ࡜࡙ࠬ㍇"),l11l1l_l1_ (u"࡛ࠪࡘ࠶ࠧ㍈"),l11l1l_l1_ (u"ࠫࡗࡒ࠱ࠨ㍉"),l11l1l_l1_ (u"ࠬࡘࡌ࠳ࠩ㍊")]: continue
			if source!=l11l1l_l1_ (u"࠭ࡕࡓࡎࠪ㍋"): name = name+l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤࠥ࠭㍌")+source+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㍍")
			url = source+l11l1l_l1_ (u"ࠩ࠾࠿ࠬ㍎")+server+l11l1l_l1_ (u"ࠪ࠿ࡀ࠭㍏")+l11ll1l1l1_l1_+l11l1l_l1_ (u"ࠫࡀࡁࠧ㍐")+menu
			addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ㍑"),l1111l_l1_+l11l1l_l1_ (u"࠭ࠧ㍒")+name,url,105,l1ll1l_l1_)
	else:
		if l1ll_l1_: addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㍓"),l1111l_l1_+l11l1l_l1_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ㍔"),l11l1l_l1_ (u"ࠩࠪ㍕"),9999)
		#if l1ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㍖"),l11l1l_l1_ (u"ࠫࠬ㍗"),l11l1l_l1_ (u"ࠬ࠭㍘"),l11l1l_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㍙"))
		#addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ㍚"),l1111l_l1_+l11l1l_l1_ (u"ࠨๆ็วุ็ࠠๅษࠣฮําฯࠡไ้์ฬะࠠหๆไึํ์๊สࠢ็็ࠬ㍛"),l11l1l_l1_ (u"ࠩࠪ㍜"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㍝"),l1111l_l1_+l11l1l_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆสๆึฮวย๋ࠢห้อีะไสลࠥ็โุࠩ㍞"),l11l1l_l1_ (u"ࠬ࠭㍟"),9999)
		#addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ㍠"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㍡"),l11l1l_l1_ (u"ࠨࠩ㍢"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ㍣"),l1111l_l1_+l11l1l_l1_ (u"࡙ࠪࡳ࡬࡯ࡳࡶࡸࡲࡦࡺࡥ࡭ࡻ࠯ࠤࡳࡵࠠࡕࡘࠣࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠥ࡬࡯ࡳࠢࡼࡳࡺ࠭㍤"),l11l1l_l1_ (u"ࠫࠬ㍥"),9999)
		#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ㍦"),l1111l_l1_+l11l1l_l1_ (u"࠭ࡉࡵࠢ࡬ࡷࠥ࡬࡯ࡳࠢࡵࡩࡱࡧࡴࡪࡸࡨࡷࠥࠬࠠࡧࡴ࡬ࡩࡳࡪࡳࠡࡱࡱࡰࡾ࠭㍧"),l11l1l_l1_ (u"ࠧࠨ㍨"),9999)
	return
def PLAY(id):
	source,server,l11ll1l1l1_l1_,menu = id.split(l11l1l_l1_ (u"ࠨ࠽࠾ࠫ㍩"))
	url = l11l1l_l1_ (u"ࠩࠪ㍪")
	if source==l11l1l_l1_ (u"࡙ࠪࡗࡒࠧ㍫"): url = l11ll1l1l1_l1_
	elif source==l11l1l_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ㍬"):
		url = l1l1l1l_l1_[l11l1l_l1_ (u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭㍭")][0]+l11l1l_l1_ (u"࠭࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ㍮")+l11ll1l1l1_l1_
		import ll_l1_
		ll_l1_.l11_l1_([url],l1ll1_l1_,l11l1l_l1_ (u"ࠧ࡭࡫ࡹࡩࠬ㍯"),url)
		return
	elif source==l11l1l_l1_ (u"ࠨࡉࡄࠫ㍰"):
		payload = { l11l1l_l1_ (u"ࠩ࡬ࡨࠬ㍱") : l11l1l_l1_ (u"ࠪࠫ㍲"), l11l1l_l1_ (u"ࠫࡺࡹࡥࡳࠩ㍳") : l1l11ll1lll_l1_(32) , l11l1l_l1_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ㍴") : l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࡋࡆ࠷ࠧ㍵") , l11l1l_l1_ (u"ࠧ࡮ࡧࡱࡹࠬ㍶") : l11l1l_l1_ (u"ࠨࠩ㍷") }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭㍸"),l11l11_l1_,payload,l11l1l_l1_ (u"ࠪࠫ㍹"),False,l11l1l_l1_ (u"ࠫࠬ㍺"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ㍻"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㍼"),l11l1l_l1_ (u"ࠧࠨ㍽"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㍾"),l11l1l_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㍿"))
			return
		html = response.content
		cookies = response.cookies.get_dict()
		l1l11ll1l1l_l1_ = cookies[l11l1l_l1_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪࠧ㎀")]
		url = response.headers[l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㎁")]
		payload = { l11l1l_l1_ (u"ࠬ࡯ࡤࠨ㎂") : l11ll1l1l1_l1_ , l11l1l_l1_ (u"࠭ࡵࡴࡧࡵࠫ㎃") : l1l11ll1lll_l1_(32) , l11l1l_l1_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ㎄") : l11l1l_l1_ (u"ࠨࡲ࡯ࡥࡾࡍࡁ࠳ࠩ㎅") , l11l1l_l1_ (u"ࠩࡰࡩࡳࡻࠧ㎆") : l11l1l_l1_ (u"ࠪࠫ㎇") }
		headers = { l11l1l_l1_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ㎈") : l11l1l_l1_ (u"ࠬࡇࡓࡑ࠰ࡑࡉ࡙ࡥࡓࡦࡵࡶ࡭ࡴࡴࡉࡥ࠿ࠪ㎉")+l1l11ll1l1l_l1_ }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ㎊"),l11l11_l1_,payload,headers,l11l1l_l1_ (u"ࠧࠨ㎋"),l11l1l_l1_ (u"ࠨࠩ㎌"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠳ࡰࡧࠫ㎍"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㎎"),l11l1l_l1_ (u"ࠫࠬ㎏"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㎐"),l11l1l_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㎑"))
			return
		html = response.content
		url = re.findall(l11l1l_l1_ (u"ࠧࡳࡧࡶࡴࠧࡀࠢࠩࡪࡷࡸࡵ࠴ࠪࡀ࡯࠶ࡹ࠽࠯ࠨ࠯ࠬࡂ࠭ࠧ࠭㎒"),html,re.DOTALL)
		l1llll1_l1_ = url[0][0]
		params = url[0][1]
		#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ㎓"),l11l1l_l1_ (u"ࠩ࠮࠯࠰࠱ࠫࠬࠢࠪ㎔")+l1llll1_l1_)
		#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ㎕"),l11l1l_l1_ (u"ࠫ࠰࠱ࠫࠬ࠭࠮ࠤࠬ㎖")+params)
		l1l11ll1l11_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠹࠸࠯ࠩ㎗")+server+l11l1l_l1_ (u"࠭࠷࠸࠹࠲ࠫ㎘")+l11ll1l1l1_l1_+l11l1l_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㎙")+params
		l1l11lll11l_l1_ = l1l11ll1l11_l1_.replace(l11l1l_l1_ (u"ࠨ࠵࠹࠾࠼࠭㎚"),l11l1l_l1_ (u"ࠩ࠷࠴࠿࠽ࠧ㎛")).replace(l11l1l_l1_ (u"ࠪࡣࡍࡊ࠮࡮࠵ࡸ࠼ࠬ㎜"),l11l1l_l1_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㎝"))
		l1l11lll111_l1_ = l1l11ll1l11_l1_.replace(l11l1l_l1_ (u"ࠬ࠹࠶࠻࠹ࠪ㎞"),l11l1l_l1_ (u"࠭࠴࠳࠼࠺ࠫ㎟")).replace(l11l1l_l1_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ㎠"),l11l1l_l1_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ㎡"))
		l1ll1ll1_l1_ = [l11l1l_l1_ (u"ࠩࡋࡈࠬ㎢"),l11l1l_l1_ (u"ࠪࡗࡉ࠷ࠧ㎣"),l11l1l_l1_ (u"ࠫࡘࡊ࠲ࠨ㎤")]
		l1lll1_l1_ = [l1l11ll1l11_l1_,l1l11lll11l_l1_,l1l11lll111_l1_]
		l1l_l1_ = 0
		#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ㎥"), l1ll1ll1_l1_)
		if l1l_l1_ == -1: return
		else: url = l1lll1_l1_[l1l_l1_]
	elif source==l11l1l_l1_ (u"࠭ࡎࡕࠩ㎦"):
		headers = { l11l1l_l1_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㎧") : l11l1l_l1_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㎨") }
		payload = { l11l1l_l1_ (u"ࠩ࡬ࡨࠬ㎩") : l11ll1l1l1_l1_ , l11l1l_l1_ (u"ࠪࡹࡸ࡫ࡲࠨ㎪") : l1l11ll1lll_l1_(32) , l11l1l_l1_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭㎫") : l11l1l_l1_ (u"ࠬࡶ࡬ࡢࡻࡑࡘࠬ㎬") , l11l1l_l1_ (u"࠭࡭ࡦࡰࡸࠫ㎭") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ㎮"), l11l11_l1_, payload, headers, False,l11l1l_l1_ (u"ࠨࠩ㎯"),l11l1l_l1_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ㎰"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ㎱"),l11l1l_l1_ (u"ࠫࠬ㎲"),l11l1l_l1_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㎳"),l11l1l_l1_ (u"࠭็ั้ࠣห้ิฯๆห้ࠣำ฻ีสࠢ็่๊ฮัๆฮࠣๅ็฽ࠧ㎴"))
			return
		html = response.content
		url = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ㎵")]
		url = url.replace(l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬ㎶"),l11l1l_l1_ (u"ࠩࠣࠫ㎷"))
		url = url.replace(l11l1l_l1_ (u"ࠪࠩ࠸ࡊࠧ㎸"),l11l1l_l1_ (u"ࠫࡂ࠭㎹"))
		if l11l1l_l1_ (u"ࠬࡒࡥࡢࡴࡱࠫ㎺") in l11ll1l1l1_l1_:
			url = url.replace(l11l1l_l1_ (u"࠭ࡎࡕࡐࡑ࡭ࡱ࡫ࠧ㎻"),l11l1l_l1_ (u"ࠧࠨ㎼"))
			url = url.replace(l11l1l_l1_ (u"ࠨ࡮ࡨࡥࡷࡴࡩ࡯ࡩ࠴ࠫ㎽"),l11l1l_l1_ (u"ࠩࡏࡩࡦࡸ࡮ࡪࡰࡪࠫ㎾"))
	elif source==l11l1l_l1_ (u"ࠪࡔࡑ࠭㎿"):
		#headers = { l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㏀") : l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㏁") }
		payload = { l11l1l_l1_ (u"࠭ࡩࡥࠩ㏂") : l11ll1l1l1_l1_ , l11l1l_l1_ (u"ࠧࡶࡵࡨࡶࠬ㏃") : l1l11ll1lll_l1_(32) , l11l1l_l1_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ㏄") : l11l1l_l1_ (u"ࠩࡳࡰࡦࡿࡐࡍࠩ㏅") , l11l1l_l1_ (u"ࠪࡱࡪࡴࡵࠨ㏆") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠫࡕࡕࡓࡕࠩ㏇"), l11l11_l1_, payload, l11l1l_l1_ (u"ࠬ࠭㏈"),False,l11l1l_l1_ (u"࠭ࠧ㏉"),l11l1l_l1_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ㏊"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ㏋"),l11l1l_l1_ (u"ࠩࠪ㏌"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㏍"),l11l1l_l1_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ㏎"))
			return
		html = response.content
		url = response.headers[l11l1l_l1_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㏏")]
		headers = {l11l1l_l1_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ㏐"):response.headers[l11l1l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ㏑")]}
		response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭㏒"),url, l11l1l_l1_ (u"ࠩࠪ㏓"),headers , l11l1l_l1_ (u"ࠪࠫ㏔"),l11l1l_l1_ (u"ࠫࠬ㏕"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠹ࡹ࡮ࠧ㏖"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ㏗"),l11l1l_l1_ (u"ࠧࠨ㏘"),l11l1l_l1_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㏙"),l11l1l_l1_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ㏚"))
			return
		html = response.content
		items = re.findall(l11l1l_l1_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㏛"),html,re.DOTALL)
		url = items[0]
	elif source in [l11l1l_l1_ (u"࡙ࠫࡇࠧ㏜"),l11l1l_l1_ (u"ࠬࡌࡍࠨ㏝"),l11l1l_l1_ (u"࡙࠭ࡖࠩ㏞"),l11l1l_l1_ (u"ࠧࡘࡕ࠴ࠫ㏟"),l11l1l_l1_ (u"ࠨ࡙ࡖ࠶ࠬ㏠"),l11l1l_l1_ (u"ࠩࡕࡐ࠶࠭㏡"),l11l1l_l1_ (u"ࠪࡖࡑ࠸ࠧ㏢")]:
		if source==l11l1l_l1_ (u"࡙ࠫࡇࠧ㏣"): l11ll1l1l1_l1_ = id
		headers = { l11l1l_l1_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ㏤") : l11l1l_l1_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ㏥") }
		payload = { l11l1l_l1_ (u"ࠧࡪࡦࠪ㏦") : l11ll1l1l1_l1_ , l11l1l_l1_ (u"ࠨࡷࡶࡩࡷ࠭㏧") : l1l11ll1lll_l1_(32) , l11l1l_l1_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ㏨") : l11l1l_l1_ (u"ࠪࡴࡱࡧࡹࠨ㏩")+source , l11l1l_l1_ (u"ࠫࡲ࡫࡮ࡶࠩ㏪") : menu }
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡖࡏࡔࡖࠪ㏫"),l11l11_l1_,payload,headers,l11l1l_l1_ (u"࠭ࠧ㏬"),l11l1l_l1_ (u"ࠧࠨ㏭"),l11l1l_l1_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠶ࡵࡪࠪ㏮"))
		if not response.succeeded:
			DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ㏯"),l11l1l_l1_ (u"ࠪࠫ㏰"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㏱"),l11l1l_l1_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭㏲"))
			return
		html = response.content
		url = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㏳")]
		if source==l11l1l_l1_ (u"ࠧࡇࡏࠪ㏴"):
			response = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ㏵"), url, l11l1l_l1_ (u"ࠩࠪ㏶"), l11l1l_l1_ (u"ࠪࠫ㏷"), False,l11l1l_l1_ (u"ࠫࠬ㏸"),l11l1l_l1_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠻ࡹ࡮ࠧ㏹"))
			url = response.headers[l11l1l_l1_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㏺")]
			url = url.replace(l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࡸ࠭㏻"),l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭㏼"))
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㏽"))
	return
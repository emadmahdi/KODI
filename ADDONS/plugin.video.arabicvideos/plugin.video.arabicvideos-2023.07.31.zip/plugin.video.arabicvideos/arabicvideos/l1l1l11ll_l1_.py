# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧභ")
l1111l_l1_ = l11l1l_l1_ (u"ࠬࡥࡋࡘࡖࡢࠫම")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,l11lll1_l1_,text):
	if   mode==130: results = MENU()
	elif mode==131: results = l1lllll_l1_(url)
	elif mode==132: results = CATEGORIES(url)
	elif mode==133: results = l1lll1l1_l1_(url,l11lll1_l1_)
	elif mode==134: results = PLAY(url)
	elif mode==135: results = l1l1ll111_l1_()
	elif mode==139: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫඹ"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆหฯࠥอไฮ์่ࠣ็์วสࠢส่่๎หาࠩය"),l11l1l_l1_ (u"ࠨࠩර"),135)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ඼"),l1111l_l1_+l11l1l_l1_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪල"),l11l1l_l1_ (u"ࠫࠬ඾"),139,l11l1l_l1_ (u"ࠬ࠭඿"),l11l1l_l1_ (u"࠭ࠧව"),l11l1l_l1_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫශ"))
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭ෂ"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩස"),l11l1l_l1_ (u"ࠪࠫහ"),9999)
	html = OPENURL_CACHED(REGULAR_CACHE,l11l11_l1_,l11l1l_l1_ (u"ࠫࠬළ"),l11l1l_l1_ (u"ࠬ࠭ෆ"),True,l11l1l_l1_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ෇"))
	l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳ࡴࡰࡩࡪࡰࡪ࠭෈"),html,re.DOTALL)
	block = l1l11l1_l1_[1]
	items=re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ෉"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠩ࠲ࡧࡴࡴࡤࡶࡥࡷࡳࡷ්࠭") in l1llll1_l1_: continue
		title = title.strip(l11l1l_l1_ (u"ࠪࠤࠬ෋"))
		#l1l1lll11_l1_ = [l11l1l_l1_ (u"ࠫ࠴ࡸࡥ࡭࡫ࡪ࡭ࡴࡻࡳࠨ෌"),l11l1l_l1_ (u"ࠬ࠵ࡳࡰࡥ࡬ࡥࡱ࠭෍"),l11l1l_l1_ (u"࠭࠯ࡱࡱ࡯࡭ࡹ࡯ࡣࡢ࡮ࠪ෎")]
		#if any(value in l1llll1_l1_ for value in l1l1lll11_l1_):
		#	title = l11l1l_l1_ (u"ࠧศๆหีฬ๋ฬࠡࠩා")+title
		url = l11l11_l1_+l1llll1_l1_
		if l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࠬැ") in url: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩෑ"),l1111l_l1_+title,url,132)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪි"),l1111l_l1_+title,url,131)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩී"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬු"),l11l1l_l1_ (u"࠭ࠧ෕"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧූ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ෗")+l1111l_l1_+l11l1l_l1_ (u"ࠩสู่๊ไิๆสฮࠬෘ"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠵࠵ࠪෙ"),132,l11l1l_l1_ (u"ࠫࠬේ"),l11l1l_l1_ (u"ࠬ࠷ࠧෛ"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ො"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩෝ")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็วๆ๊วๆࠩෞ"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠼࠲࠹ࠩෟ"),132,l11l1l_l1_ (u"ࠪࠫ෠"),l11l1l_l1_ (u"ࠫ࠶࠭෡"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ෢"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ෣")+l1111l_l1_+l11l1l_l1_ (u"ࠧษำส้ัࠦวๅื฽หึ่ࠦศๆืฬฬฮࠧ෤"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠷࠷ࠨ෥"),132,l11l1l_l1_ (u"ࠩࠪ෦"),l11l1l_l1_ (u"ࠪ࠵ࠬ෧"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ෨"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ෩")+l1111l_l1_+l11l1l_l1_ (u"࠭วษำีࠤฬ๊ศาษ่ะࠬ෪"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠵࠼࠼࠳ࠨ෫"),132,l11l1l_l1_ (u"ࠨࠩ෬"),l11l1l_l1_ (u"ࠩ࠴ࠫ෭"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෮"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭෯")+l1111l_l1_+l11l1l_l1_ (u"ࠬอไๆฯสฺึอสࠨ෰"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠼࠸࠸࠭෱"),132,l11l1l_l1_ (u"ࠧࠨෲ"),l11l1l_l1_ (u"ࠨ࠳ࠪෳ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ෴"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ෵")+l1111l_l1_+l11l1l_l1_ (u"ࠫ฾อิ้ำสลࠬ෶"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠳࠶࠹࠸࠭෷"),132,l11l1l_l1_ (u"࠭ࠧ෸"),l11l1l_l1_ (u"ࠧ࠲ࠩ෹"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ෺"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ෻")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้ฮัศ็ฯࠤฬ๊วอฬ่ห฾๐ษࠨ෼"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠶࠲࠴ࠫ෽"),132,l11l1l_l1_ (u"ࠬ࠭෾"),l11l1l_l1_ (u"࠭࠱ࠨ෿"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ฀"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪก")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่อืวๆฮࠣห้ี๊็์ฬࠫข"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠱࠻ࠪฃ"),132,l11l1l_l1_ (u"ࠫࠬค"),l11l1l_l1_ (u"ࠬ࠷ࠧฅ"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ฆ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩง")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ฬึอๅอࠢส่ํัววไํอࠬจ"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠵࠴ࠩฉ"),132,l11l1l_l1_ (u"ࠪࠫช"),l11l1l_l1_ (u"ࠫ࠶࠭ซ"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฌ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨญ")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆหีฬ๋ฬࠡษ็ื๏อำ๋หࠪฎ"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠺࠵ࠨฏ"),132,l11l1l_l1_ (u"ࠩࠪฐ"),l11l1l_l1_ (u"ࠪ࠵ࠬฑ"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫฒ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧณ")+l1111l_l1_+l11l1l_l1_ (u"࠭ใหสࠪด"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠶࠾࠷ࠧต"),132,l11l1l_l1_ (u"ࠨࠩถ"),l11l1l_l1_ (u"ࠩ࠴ࠫท"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪธ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭น")+l1111l_l1_+l11l1l_l1_ (u"ࠬะูๅ็ࠣห้็วาีํอࠬบ"),l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠻࠼ࠬป"),132,l11l1l_l1_ (u"ࠧࠨผ"),l11l1l_l1_ (u"ࠨ࠳ࠪฝ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩพ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬฟ")+l1111l_l1_+l11l1l_l1_ (u"ࠫศืิ๋ใࠣห้ฮัศ็ฯࠫภ"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠳࠵࠻࠾࠭ม"),132,l11l1l_l1_ (u"࠭ࠧย"),l11l1l_l1_ (u"ࠧ࠲ࠩร"))
	return
def l1lllll_l1_(url):
	l1l1lll11_l1_ = [l11l1l_l1_ (u"ࠨ࠱ࡵࡩࡱ࡯ࡧࡪࡱࡸࡷࠬฤ"),l11l1l_l1_ (u"ࠩ࠲ࡷࡴࡩࡩࡢ࡮ࠪล"),l11l1l_l1_ (u"ࠪ࠳ࡵࡵ࡬ࡪࡶ࡬ࡧࡦࡲࠧฦ"),l11l1l_l1_ (u"ࠫ࠴࡬ࡩ࡭࡯ࡶࠫว"),l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠭ศ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"࠭ࠧษ"),l11l1l_l1_ (u"ࠧࠨส"),True,l11l1l_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨห"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡷ࡭ࡹࡲࡥࡣࡣࡵࠬ࠳࠰࠿ࠪࡶ࡬ࡸࡱ࡫ࡢࡢࡴࠪฬ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	if any(value in url for value in l1l1lll11_l1_):
		items = re.findall(l11l1l_l1_ (u"ࠥࡷࡷࡩ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠧอ"),block,re.DOTALL)
		for l1ll1l_l1_,l1llll1_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭ฮ"))
			l1llll1_l1_ = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฯ"),l1111l_l1_+title,l1llll1_l1_,133,l1ll1l_l1_,l11l1l_l1_ (u"࠭࠱ࠨะ"))
	elif l11l1l_l1_ (u"ࠧ࠰ࡦࡲࡧࡸ࠭ั") in url:
		items = re.findall(l11l1l_l1_ (u"ࠣࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀ࠾࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩࠥา"),block,re.DOTALL)
		for l1ll1l_l1_,title,l1llll1_l1_ in items:
			title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫำ"))
			l1llll1_l1_ = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪิ"),l1111l_l1_+title,l1llll1_l1_,133,l1ll1l_l1_,l11l1l_l1_ (u"ࠫ࠶࠭ี"))
	return
def CATEGORIES(url):
	category = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧึ"))[-1]
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"࠭ࠧื"),l11l1l_l1_ (u"ࠧࠨุ"),True,l11l1l_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓ࠮࠳ࡶࡸูࠬ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡳࡥࡷ࡫࡮ࡵࡥࡤࡸ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ฺࠩ"),html,re.DOTALL)
	if not l1l11l1_l1_:
		l1lll1l1_l1_(url,l11l1l_l1_ (u"ࠪ࠵ࠬ฻"))
		return
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠦ࡭ࡸࡥࡧ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁࠨ฼"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		#l1l1ll1ll_l1_ = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ฽"))[-1]
		#if category==l1l1ll1ll_l1_: continue
		title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨ฾"))
		l1llll1_l1_ = l11l11_l1_ + l1llll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ฿"),l1111l_l1_+title,l1llll1_l1_,132,l11l1l_l1_ (u"ࠨࠩเ"),l11l1l_l1_ (u"ࠩ࠴ࠫแ"))
	return
def l1lll1l1_l1_(url,l11lll1_l1_):
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠪࠫโ"),l11l1l_l1_ (u"ࠫࠬใ"),True,l11l1l_l1_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧไ"))
	items = re.findall(l11l1l_l1_ (u"࠭ࡴࡰࡶࡤࡰࡵࡧࡧࡦࡥࡲࡹࡳࡺ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩๅ"),html,re.DOTALL)
	if not items:
		url = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡺࡷ࠲ࡪࡥࡵࡣ࡬ࡰ࠲ࡨ࡯ࡥࡻࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬๆ"),html,re.DOTALL)
		url = url[0]
		title = l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ็") + l11l1l_l1_ (u"่่ࠩๆࠦวๅฬื฾๏๊่ࠧ")
		if url: addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰ้ࠩ"),l1111l_l1_+title,url,134)
		else: DIALOG_OK(l11l1l_l1_ (u"๊ࠫࠬ"),l11l1l_l1_ (u"๋ࠬ࠭"),l11l1l_l1_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ์"),l11l1l_l1_ (u"ࠧๅษࠣ๎ําฯࠡฯส่๏อࠠๆๆไหฯࠦแ๋ัํ์ࠥ็๊้ࠡำหࠥอไโำ฼ࠫํ"))
		return
	l1l1ll11l_l1_ = int(items[0])
	name = re.findall(l11l1l_l1_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠽࠱ࡤࡂࠥࡄࠨ࠯ࠬࡂ࠭ࡁ࠭๎"),html,re.DOTALL)
	if name: name = name[0].strip(l11l1l_l1_ (u"ࠩࠣࠫ๏"))
	else: name = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ๐"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ๑"),l11l1l_l1_ (u"ࠬ࠭๒"),name, str(l11l1l_l1_ (u"࠭ࠧ๓")))
	if l11l1l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫ๔") in url or l11l1l_l1_ (u"ࠨࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ๕") in url:
		category = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫ๖"))[-1]
		if l11lll1_l1_==l11l1l_l1_ (u"ࠪࠫ๗"): l111l1l_l1_ = url
		else: l111l1l_l1_ = l11l11_l1_ + l11l1l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ๘") + category + l11l1l_l1_ (u"ࠬ࠵ࠧ๙") + l11lll1_l1_
		l11ll111_l1_ = OPENURL_CACHED(REGULAR_CACHE,l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ๚"),l11l1l_l1_ (u"ࠧࠨ๛"),True,l11l1l_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠲࡯ࡦࠪ๜"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡳࡥ࡬࡫࡮ࡶ࡯ࡥࡩࡷ࠮࠮ࠫࡁࠬࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧ๝"),l11ll111_l1_,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡪࡺࡲ࡬ࠩ࠰࠭ࡃ࠮ࡄ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ๞"),block,re.DOTALL)
		for l1ll1l_l1_,type,l1llll1_l1_,title in items:
			if l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ๟") not in type: continue
			if l11l1l_l1_ (u"๋ࠬำๅี็ࠫ๠") in title and l11l1l_l1_ (u"࠭อๅไฬࠫ๡") not in title: continue
			title = title.replace(l11l1l_l1_ (u"ࠧ࡝ࡴ࡟ࡲࠬ๢"),l11l1l_l1_ (u"ࠨࠩ๣"))
			title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ๤"))
			if l11l1l_l1_ (u"ุ้๊ࠪำๅࠩ๥") in name and l11l1l_l1_ (u"ࠫา๊โสࠩ๦") in title and l11l1l_l1_ (u"๋ࠬำๅี็ࠫ๧") not in title:
				title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ๨") + name + l11l1l_l1_ (u"ࠧࠡ࠯ࠣࠫ๩") + title
			l1llll1_l1_ = l11l11_l1_ + l1llll1_l1_
			if category==l11l1l_l1_ (u"ࠨ࠸࠵࠼ࠬ๪"): addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ๫"),l1111l_l1_+title,l1llll1_l1_,133,l1ll1l_l1_,l11l1l_l1_ (u"ࠪ࠵ࠬ๬"))
			else: addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ๭"),l1111l_l1_+title,l1llll1_l1_,134,l1ll1l_l1_)
	elif l11l1l_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ๮") in url:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡩ࡯࡭࠯ࡰࡨ࠲࠷࠲ࠨ๯"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠢࡷ࡫ࡧࡩࡴ࠳ࡴࡳࡣࡦ࡯࠲ࡺࡥࡹࡶ࠱࠮ࡄࡲ࡯ࡢࡦ࡙࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠢ๰"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ๱"))
				addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ๲"),l1111l_l1_+title,l1llll1_l1_,134,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠶࠳࠺ࠪ๳") in html:
				title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ๴") + l11l1l_l1_ (u"๋ࠬไโࠢส่ฯฺฺ๋ๆࠪ๵")
				addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ๶"),l1111l_l1_+title,url,134)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦࡈࡧࡴࡦࡩࡲࡶ࡮࡫ࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫ๷"),html,re.DOTALL)
			category = items[0].split(l11l1l_l1_ (u"ࠨ࠱ࠪ๸"))[-1]
			url = l11l11_l1_ + l11l1l_l1_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭๹") + category
			CATEGORIES(url)
			return
		l11l1l_l1_ (u"ࠥࠦࠧࠐࠉࠊࡶࡲࡸࡦࡲࡰࡢࡩࡨࡷࠥࡃࠠ࠱ࠌࠌࠍࠎ࡫ࡰࡪࡵࡲࡨࡪࡏࡄࠡ࠿ࠣࡹࡷࡲ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬ࡟࠲࠷࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢࡄࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪ࡝࠰࠵ࡢࠐࠉࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡤ࡮ࡦࡾ࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪࠤ࠰ࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠭ࠣࠫ࠴࠭ࠠࠬࠢࡳࡥ࡬࡫ࠊࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠳࠮ࠪࠫ࠱࠭ࠧ࠭ࡖࡵࡹࡪ࠲ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠹ࡲࡥࠩࠬࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࠦ࠼ࡩ࠷ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩ࡮ࡩ࠯ࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠏࠉࡦࡲ࡬ࡷࡴࡪࡥࡊࡆࡱࡩࡼࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫ࡞࠱࠶ࡣࠊࠊࠋࠌࠍ࡮࡬ࠠࡦࡲ࡬ࡷࡴࡪࡥࡊࡆࡱࡩࡼࡃ࠽ࡦࡲ࡬ࡷࡴࡪࡥࡊࡆ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠵࠸࠺ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠣࠤࠥ๺")
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊࡨࡲࡶࠥ࡯ࠠࡪࡰࠣࡶࡦࡴࡧࡦࠪ࠴࠰࠶࠱ࡴࡰࡶࡤࡰࡵࡧࡧࡦࡵࠬ࠾ࠏࠏࠉࡪࡨࠣࡴࡦ࡭ࡥࠢ࠿ࡶࡸࡷ࠮ࡩࠪ࠼ࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦู࠭ࠪๆำษࠡࠩ࠮ࡷࡹࡸࠨࡪࠫ࠯ࡹࡷࡲࠬ࠲࠵࠶࠰ࠬ࠭ࠬࡴࡶࡵࠬ࡮࠯ࠩࠋࠋࠥࠦࠧ๻")
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭๼"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1l1l1l11_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ๽"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1l1l11_l1_:
			l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠧࠧࡣࡰࡴࡀ࠭๾"),l11l1l_l1_ (u"ࠨࠨࠪ๿"))
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ຀"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩກ")+title,l1llll1_l1_,133)
	return
def PLAY(url):
	if l11l1l_l1_ (u"ࠫ࠴ࡴࡥࡸࡵ࠲ࠫຂ") in url or l11l1l_l1_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ຃") in url:
		html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"࠭ࠧຄ"),l11l1l_l1_ (u"ࠧࠨ຅"),True,l11l1l_l1_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ຆ"))
		items = re.findall(l11l1l_l1_ (u"ࠤࡰࡳࡧ࡯࡬ࡦࡸ࡬ࡨࡪࡵࡰࡢࡶ࡫࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨງ"),html,re.DOTALL)
		if items: url = items[0]
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩຈ"))
	return
def l1l1ll111_l1_():
	#l1l1lllll_l1_(l11l1l_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪຉ"))
	#l1llll1l_l1_(l11l1l_l1_ (u"ࠬาวา์ࠣฮูเ๊ๅࠢส่็์วสࠩຊ"),l11l1l_l1_ (u"࠭ࠧ຋"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰࡮࡬ࡺࡪ࠭ຌ")
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠨࠩຍ"),l11l1l_l1_ (u"ࠩࠪຎ"),True,l11l1l_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨຏ"))
	l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬຐ"),html,re.DOTALL)
	l111l1l_l1_ = l111l1l_l1_[0]
	l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ຑ"):l11l11_l1_}
	l1l1llll1_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪຒ"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨຓ"),l1l1l1ll1_l1_,l11l1l_l1_ (u"ࠨࠩດ"),True,l11l1l_l1_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡒࡉࡗࡇ࠰࠶ࡳࡪࠧຕ"))
	l11ll111_l1_ = l1l1llll1_l1_.content
	token = re.findall(l11l1l_l1_ (u"ࠪࡧࡸࡸࡦ࠮ࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪຖ"),l11ll111_l1_,re.DOTALL)
	token = token[0]
	l1l1ll1l1_l1_ = SERVER(l111l1l_l1_,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨທ"))
	l111ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡶ࡬ࡢࡻࡘࡶࡱࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤຘ"),l11ll111_l1_,re.DOTALL)
	l111ll1_l1_ = l1l1ll1l1_l1_+l111ll1_l1_[0]
	#LOG_THIS(l11l1l_l1_ (u"࠭ࠧນ"),l111ll1_l1_)
	l1l1l1l1l_l1_ = {l11l1l_l1_ (u"࡙ࠧ࠯ࡆࡗࡗࡌ࠭ࡕࡑࡎࡉࡓ࠭ບ"):token}
	l1l1lll1l_l1_ = OPENURL_REQUESTS_CACHED(NO_CACHE,l11l1l_l1_ (u"ࠨࡒࡒࡗ࡙࠭ປ"),l111ll1_l1_,l11l1l_l1_ (u"ࠩࠪຜ"),l1l1l1l1l_l1_,False,True,l11l1l_l1_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠸ࡸࡤࠨຝ"))
	l1l1l1lll_l1_ = l1l1lll1l_l1_.content
	l1llll1ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬພ"),l1l1l1lll_l1_,re.DOTALL)
	l1llll1ll_l1_ = l1llll1ll_l1_[0].replace(l11l1l_l1_ (u"ࠬࡢ࠯ࠨຟ"),l11l1l_l1_ (u"࠭࠯ࠨຠ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨມ"),l11l1l_l1_ (u"ࠨࠩຢ"),url,html)
	#l1l1lllll_l1_(l11l1l_l1_ (u"ࠩࡶࡸࡴࡶࠧຣ"))
	PLAY_VIDEO(l1llll1ll_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ຤"))
	return
def SEARCH(search,url=l11l1l_l1_ (u"ࠫࠬລ")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if url==l11l1l_l1_ (u"ࠬ࠭຦"):
		if search==l11l1l_l1_ (u"࠭ࠧວ"): search = OPEN_KEYBOARD()
		if search==l11l1l_l1_ (u"ࠧࠨຨ"): return
		#search = search.replace(l11l1l_l1_ (u"ࠨࠢࠪຩ"),l11l1l_l1_ (u"ࠩ࠮ࠫສ"))
		#search = l11l1l_l1_ (u"ࠪ࠱ࡹࡧࡧࠡࡦࡲࡧࡸࠦࡏࡓࠢࡩ࡭ࡱࡳࡳࠡࡑࡕࠤࡸ࡫ࡲࡪࡧࡶࠤࡔࡘࠠࡦࡲ࡬ࡷࡴࡪࡥࠡࡑࡕࠤࡪࡶࡩࡴࡱࡧࡩࡸࠦࡏࡓࠢࡦࡥࡹ࡫ࡧࡰࡴࡼࠤࡔࡘࠠ࡯ࡧࡺࡷࠥࡳࡰ࠵ࠢࠪຫ")+search
		#search = l11l1l_l1_ (u"ࠫࠧࡳࡰ࠵ࠤࠣࠫຬ")+search
		search = QUOTE(search)
		url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩອ")+search
		l1lll1l1_l1_(url,l11l1l_l1_ (u"࠭ࠧຮ"))
		return
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠭ࠩࠪ࠰ࠬ࠭ࠬࡕࡴࡸࡩ࠱࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ࠩࠋࠋࠌࡧࡽࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭ࠨࡶࡢࡴࠣࡧࡽࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࡠ࠶࡝ࠋࠋࠌࡹࡷࡲࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡨࡥࡶࡩ࠳ࡹࡲࡤࠢࡀࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩ࡜࠲ࡠࠎࠎࠏࡵࡳ࡮ࠣࡁࠥࡻࡲ࡭࠭ࡦࡼࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡕࡋࡓࡗ࡚࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࠧࠨ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡘࡋࡁࡓࡅࡋ࠱࠷ࡴࡤࠨࠫࠍࠍࠎࡩࡳࡦࡡࡷࡳࡰ࡫࡮ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡶࡩࡤࡺ࡯࡬ࡧࡱࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫ࡞࠴ࡢࠐࠉࠊࡥࡶࡩࡱ࡯ࡢࡗࡧࡵࡷ࡮ࡵ࡮ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥࡶࡩࡱ࡯ࡢࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯࡛࠱࡟ࠍࠍࠎࡸࡡ࡯ࡦࡲࡱࡆࡖࡉࠡ࠿ࠣࡷࡹࡸࠨࡳࡣࡱࡨࡴࡳ࠮ࡳࡣࡱࡨ࡮ࡴࡴࠩ࠳࠴࠵࠶࠲࠹࠺࠻࠼࠭࠮ࠐࠉࠊࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡷࡪ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡧࡸ࡫࠯ࡦ࡮ࡨࡱࡪࡴࡴ࠰ࡸ࠴ࡃࡷࡹࡺ࠾ࡨ࡬ࡰࡹ࡫ࡲࡦࡦࡢࡧࡸ࡫ࠦ࡯ࡷࡰࡁ࠶࠶ࠦࡩ࡮ࡀࡥࡷࠬࡳࡰࡷࡵࡧࡪࡃࡧࡤࡵࡦࠪ࡬ࡹࡳ࠾࠰ࡦࡳࡲࠬࡣࡴࡧ࡯࡭ࡧࡼ࠽ࠨ࠭ࡦࡷࡪࡲࡩࡣࡘࡨࡶࡸ࡯࡯࡯࠭ࠪࠪࡨࡾ࠽ࠨ࠭ࡦࡼ࠰࠭ࠦࡲ࠿ࠪ࠯ࡸ࡫ࡡࡳࡥ࡫࠯ࠬࠬࡳࡢࡨࡨࡁࡴ࡬ࡦࠧࡥࡶࡩࡤࡺ࡯࡬࠿ࠪ࠯ࡨࡹࡥࡠࡶࡲ࡯ࡪࡴࠫࠨࠨࡶࡳࡷࡺ࠽ࠧࡧࡻࡴࡂࡩࡳࡲࡴ࠯ࡧࡨࠬࡣࡢ࡮࡯ࡦࡦࡩ࡫࠾ࡩࡲࡳ࡬ࡲࡥ࠯ࡵࡨࡥࡷࡩࡨ࠯ࡥࡶࡩ࠳ࡧࡰࡪࠩ࠮ࡶࡦࡴࡤࡰ࡯ࡄࡔࡎ࠱ࠧࠧࡵࡷࡥࡷࡺ࠽࠱ࠩࠍࠍࡺࡹࡥࡳࡣࡪࡩࡳࡺࠠ࠾ࠢࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠭࠯ࠊࠊࡪࡨࡥࡩ࡫ࡲࡴࠢࡀࠤࢀ࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠾ࡺࡹࡥࡳࡣࡪࡩࡳࡺࡽࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡗࡶࡺ࡫ࠬࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡘࡋࡁࡓࡅࡋ࠱࠸ࡸࡤࠨࠫࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡦࡩࡨࡦࡗࡵࡰࠧࡀ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡷࡵࡰࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡲ࡫ࡴࡢࡶࡤ࡫ࡸࠨ࠺ࠡࡽࠫ࠲࠯ࡅࠩࡾࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡦࡰࡴࠣࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬࡵࡣࡪࡷࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌ࡭࡫ࠦࠧࡷ࡫ࡧࡩࡴ࠭ࠠ࡯ࡱࡷࠤ࡮ࡴࠠࡵࡣࡪࡷ࠿ࠦࡣࡰࡰࡷ࡭ࡳࡻࡥࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡺࡴࡥࡴࡥࡤࡴࡪࡎࡔࡎࡎࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࡝ࡷ࠳࠴࠸ࡩࠧ࠭ࠩ࠿ࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞ࡸ࠴࠵࠹ࡥࠨ࠮ࠪࡂࠬ࠯ࠊࠊࠋࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁࡨ࠾ࠨ࠮ࠪࠫ࠮࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠾࠲ࡦࡃ࠭ࠬࠨࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠠࠡࠩ࠯ࠫࠥ࠭ࠩࠋࠋࠌ࡭࡫ࠦࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠉࠤࠢࡲࡶࠥ࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩࠣ࡭ࡳࠦ࡬ࡪࡰ࡮࠾ࠏࠏࠉࠊࡸࡤࡶࡸࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣࡺࡦࡸࡳ࡜࠶ࡠࠎࠎࠏࠉࡶࡴ࡯ࠤࡂࠦࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢࠢ࠮ࠤࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩࠣ࠯ࠥࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡺࡦࡸࡳࠪࡀ࠸࠾ࠏࠏࠉࠊࠋࡳࡥ࡬࡫࠱ࠡ࠿ࠣࡺࡦࡸࡳ࡜࠷ࡠࠎࠎࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࡹ࡯ࡴ࡭ࡧ࠯ࡹࡷࡲࠬ࠲࠵࠶࠰ࠬ࠭ࠬࡱࡣࡪࡩ࠶࠯ࠊࠊࠋࠌࡩࡱࡹࡥ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡺࡸ࡬࠭࠳࠶࠶࠮ࠐࠉࠊࡧ࡯࡭࡫ࠦࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦ࠱ࠪࠤ࡮ࡴࠠ࡭࡫ࡱ࡯࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠱࠴࠵࠯ࠫࠬ࠲ࠧ࠲ࠩࠬࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫࡻ࡯ࡤࡦࡱࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠹࠴ࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡰࡦࡨࡥ࡭ࠤ࠽ࠤ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅࠢࡴࡶࡤࡶࡹࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࡩࡧࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࠥࡧࡺࡸࡲࡦࡰࡷࡔࡦ࡭ࡥࡊࡰࡧࡩࡽࠨ࠺ࠡࠪ࠱࠮ࡄ࠯ࠬࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡣࡶࡴࡵࡩࡳࡺࡐࡢࡩࡨࠤࡂࠦࡳࡵࡴࠫ࡭ࡳࡺࠨࡤࡷࡵࡶࡪࡴࡴࡑࡣࡪࡩࡠ࠶࡝ࠪ࠭࠴࠭ࠏࠏࠉࡧࡱࡵࠤࡹ࡯ࡴ࡭ࡧ࠯ࡷࡹࡧࡲࡵࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡀࡁࡨࡻࡲࡳࡧࡱࡸࡕࡧࡧࡦ࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠊࡷࡵࡰࠥࡃࠠࡶࡴ࡯࠲ࡸࡶ࡬ࡪࡶࠫࠫࡸࡺࡡࡳࡶࡀࠫ࠮ࡡ࠰࡞࠭ࠪࡷࡹࡧࡲࡵ࠿ࠪ࠯ࡸࡺࡡࡳࡶࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦู࠭ࠪๆำษࠡࠩ࠮ࡸ࡮ࡺ࡬ࡦ࠮ࡸࡶࡱ࠲࠱࠴࠻ࠬࠎࠎࡸࡥࡵࡷࡵࡲࠏࠏࠢࠣࠤຯ")
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
headers = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࣓ࠩ") : l11l1l_l1_ (u"࠭ࠧࣔ") }
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠭ࣕ")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡄࡏࡔࡥࠧࣖ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l11l1ll_l1_ = [l11l1l_l1_ (u"ࠩไ๎้๋ࠧࣗ"),l11l1l_l1_ (u"ࠪ็้๐ศࠨࣘ"),l11l1l_l1_ (u"ࠫฬู๊าุࠣห้อำษ๊฼๎ࠬࣙ"),l11l1l_l1_ (u"๋ࠬำาฯํอࠬࣚ"),l11l1l_l1_ (u"࠭ๅิำะ๎์࠭ࣛ"),l11l1l_l1_ (u"ࠧศ฼้๎ฮ࠭ࣜ"),l11l1l_l1_ (u"ࠨษ฼่ฬ์ࠧࣝ"),l11l1l_l1_ (u"ࠩ็ๆฬวࠧࣞ")]
def MAIN(mode,url,text):
	if   mode==70: results = MENU()
	elif mode==71: results = CATEGORIES(url)
	elif mode==72: results = l1lllll_l1_(url,text)
	elif mode==73: results = l1ll1lll_l1_(url)
	elif mode==74: results = PLAY(url)
	elif mode==79: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪࣟ"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ࣠"),l11l1l_l1_ (u"ࠬ࠭࣡"),79,l11l1l_l1_ (u"࠭ࠧ࣢"),l11l1l_l1_ (u"ࠧࠨࣣ"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬࣤ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣥ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࣦࠬ")+l1111l_l1_+l11l1l_l1_ (u"ุ๊ࠫำๅหࠣหๆ๊วๆࠩࣧ"),l11l1l_l1_ (u"ࠬ࠭ࣨ"),79,l11l1l_l1_ (u"ࣩ࠭ࠧ"),l11l1l_l1_ (u"ࠧࠨ࣪"),l11l1l_l1_ (u"ࠨี็ื้ฯࠠศใ็ห๊࠭࣫"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࣬"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣ࣭ࠬ")+l1111l_l1_+l11l1l_l1_ (u"ุ๊ࠫวิๆ้๋ࠣ๎ูส࣮ࠩ"),l11l1l_l1_ (u"࣯ࠬ࠭"),79,l11l1l_l1_ (u"ࣰ࠭ࠧ"),l11l1l_l1_ (u"ࠧࠨࣱ"),l11l1l_l1_ (u"ࠨี็ื้ฯࣲࠧ"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣳ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬࣴ")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅๆ์ีอࠬࣵ"),l11l11_l1_,72,l11l1l_l1_ (u"ࣶࠬ࠭"),l11l1l_l1_ (u"࠭ࠧࣷ"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩࣸ"))
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࣹ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࣺࠫ")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋า๋ัࠪࣻ"),l11l11_l1_,72,l11l1l_l1_ (u"ࠫࠬࣼ"),l11l1l_l1_ (u"ࠬ࠭ࣽ"),l11l1l_l1_ (u"࠭࡭ࡰࡴࡨࠫࣾ"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࣿ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪऀ")+l1111l_l1_+l11l1l_l1_ (u"ࠩส่ศิศศำࠪँ"),l11l11_l1_,72,l11l1l_l1_ (u"ࠪࠫं"),l11l1l_l1_ (u"ࠫࠬः"),l11l1l_l1_ (u"ࠬࡴࡥࡸࡵࠪऄ"))
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭अ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩआ")+l1111l_l1_+l11l1l_l1_ (u"ࠨษ็วำฮวาࠩइ"),l11l11_l1_,72,l11l1l_l1_ (u"ࠩࠪई"),l11l1l_l1_ (u"ࠪࠫउ"),l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡴࠩऊ"))
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪऋ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ऌ"),l11l1l_l1_ (u"ࠧࠨऍ"),9999)
	l1l111_l1_ = [l11l1l_l1_ (u"ࠨษ็็ฯฮ้ࠠࠢส่ฬฮอศอࠪऎ"),l11l1l_l1_ (u"ࠩส่่๎ัิษอࠤฬ๊สฺๆํ้๏ฯࠧए"),l11l1l_l1_ (u"ࠪห้ษไฺษหࠫऐ"),l11l1l_l1_ (u"ࠫฬ๊ศาษ่ะࠬऑ"),l11l1l_l1_ (u"ࠬอไศฮ๊ึฮࠦวๅๆ๋ั๏ฯࠧऒ"),l11l1l_l1_ (u"࠭วๅื๋ีࠥ๎ࠠศๆั่ๆ๐วหࠩओ"),l11l1l_l1_ (u"ࠧศๆู่ฬืูสࠢส่าืษࠨऔ")]
	html = OPENURL_CACHED(l1llll11_l1_,l11l11_l1_,l11l1l_l1_ (u"ࠨࠩक"),headers,l11l1l_l1_ (u"ࠩࠪख"),l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫग"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡵࡧࡲࡵ࡫ࡲࡲࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪघ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫङ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title not in l1l111_l1_:
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭च"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩछ")+l1111l_l1_+title,l1llll1_l1_,71)
	return html
def CATEGORIES(url):
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠨࠩज"),headers,l11l1l_l1_ (u"ࠩࠪझ"),l11l1l_l1_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶࠪञ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸ࡫ࡣࡵࡡࡳࡥࡷࡺࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬट"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧठ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨड"))
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧढ"),l1111l_l1_+title,l1llll1_l1_,72)
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨण"),l1111l_l1_+l11l1l_l1_ (u"ࠩฯ้๏฿ࠠศๆไีํ฿ࠧत"),url,72)
	else: l1lllll_l1_(url,l11l1l_l1_ (u"ࠪࠫथ"))
	return
def l1lllll_l1_(url,type):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬद"),l11l1l_l1_ (u"ࠬ࠭ध"),url,type)
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"࠭ࠧन"),headers,True,l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪऩ"))
	items = []
	if type==l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪप"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡢࡸ࡮ࡺ࡬ࡦࠢࡩࡩࡦࡺࡵࡳࡧࡧࡣࡹ࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩࡴࡷࡥ࡮ࡪࡩࡴࡴ࠯ࡦࡶࡴࡻࡳࡦ࡮ࠪफ"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴࡷࡥ࡮ࡪࡩࡴࡠࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫब"),block,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫभ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡧ࡫ࡰࡣࡰࡣࡷ࡫ࡳࡶ࡮ࡷࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࠩम"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡂࡨ࠲ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠵ࡃ࠭य"),block,re.DOTALL)
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨर"),l11l1l_l1_ (u"ࠨࠩऱ"),str(len(items)),block)
	elif type==l11l1l_l1_ (u"ࠩࡰࡳࡷ࡫ࠧल"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡪࡩࡴࡪࡱࡱࡣࡹ࡯ࡴ࡭ࡧࠣࡱࡴࡸࡥࡠࡶ࡬ࡸࡱ࡫ࠨ࠯ࠬࡂ࠭࡫ࡵ࡯ࡵࡧࡵࡣࡧࡵࡴࡵࡱࡰࡣࡸ࡫ࡲࡷ࡫ࡦࡩࡸ࠭ळ"),html,re.DOTALL)
	#elif type==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡴࠩऴ"):
	#	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡥࡴࡪࡶ࡯ࡩࠥࡴࡥࡸࡵࡢࡸ࡮ࡺ࡬ࡦࠪ࠱࠮ࡄ࠯࡮ࡦࡹࡶࡣࡲࡵࡲࡦࡡࡦ࡬ࡴ࡯ࡣࡦࡵࠪव"),html,re.DOTALL)
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽ࡵࡦࡶ࡮ࡶࡴࠨश"),html,re.DOTALL)
	if not items and l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡸࡻࡢ࡫ࡧࡦࡸࡤࡨ࡯ࡹ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩष"),block,re.DOTALL)
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		if l11l1l_l1_ (u"ࠨฬฺ๋๏ำ่ࠠษ่ࠫस") in title: continue
		title = title.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬह"),l11l1l_l1_ (u"ࠪࠫऺ")).strip(l11l1l_l1_ (u"ࠫࠥ࠭ऻ"))
		title = unescapeHTML(title)
		if any(value in title for value in l11l1ll_l1_): addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲ़ࠫ"),l1111l_l1_+title,l1llll1_l1_,73,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ऽ"),l1111l_l1_+title,l1llll1_l1_,73,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨा"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠣ࠾࠲ࡰ࡮ࡄ࠼࡭࡫ࠣࡂ࠳࠰࠿ࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࡄࠨ࠯ࠬࡂ࠭ࡁࠨि"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩी"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡࠩु")+title,l1llll1_l1_,72,l11l1l_l1_ (u"ࠫࠬू"),l11l1l_l1_ (u"ࠬ࠭ृ"),type)
	return
def l1111l1_l1_(url):
	html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"࠭ࠧॄ"),headers,True,l11l1l_l1_ (u"ࠧࡂࡍࡒࡅࡒ࠳ࡓࡆࡅࡗࡍࡔࡔࡓ࠮࠴ࡱࡨࠬॅ"))
	l111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩॆ"),html,re.DOTALL)
	l111l1l_l1_ = l111l1l_l1_[1]
	return l111l1l_l1_
def l1ll1lll_l1_(url):
	#l111l11_l1_ = [l11l1l_l1_ (u"ࠩࡽ࡭ࡵ࠭े"),l11l1l_l1_ (u"ࠪࡶࡦࡸࠧै"),l11l1l_l1_ (u"ࠫࡹࡾࡴࠨॉ"),l11l1l_l1_ (u"ࠬࡶࡤࡧࠩॊ"),l11l1l_l1_ (u"࠭ࡨࡵ࡯ࠪो"),l11l1l_l1_ (u"ࠧࡵࡣࡵࠫौ"),l11l1l_l1_ (u"ࠨ࡫ࡶࡳ्ࠬ"),l11l1l_l1_ (u"ࠩ࡫ࡸࡲࡲࠧॎ")]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠪࠫॏ"),headers,True,l11l1l_l1_ (u"ࠫࡆࡑࡏࡂࡏ࠰ࡗࡊࡉࡔࡊࡑࡑࡗ࠲࠷ࡳࡵࠩॐ"))
	l1lllll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸ࠰࠺࠰࠱ࡤ࡯ࡼࡧ࡭࠯ࡰࡨࡸ࠴ࡢࡷࠬ࠰࠭ࡃ࠮ࠨࠧ॑"),html,re.DOTALL)
	l1llllll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࠩࡪࡷࡸࡵࡹࠪ࠻࠱࠲ࡹࡳࡪࡥࡳࡷࡵࡰ࠳ࡩ࡯࡮࠱࡟ࡻ࠰࠴ࠪࡀ॒ࠫࠥࠫ"),html,re.DOTALL)
	if l1lllll1_l1_ or l1llllll_l1_:
		if l1lllll1_l1_: l111ll1_l1_ = l1lllll1_l1_[0]
		elif l1llllll_l1_: l111ll1_l1_ = l1111l1_l1_(l1llllll_l1_[0])
		l111ll1_l1_ = l1llll_l1_(l111ll1_l1_)
		import l1lll1ll_l1_
		if l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩ॓") in l111ll1_l1_ or l11l1l_l1_ (u"ࠨ࠱ࡶ࡬ࡴࡽࡳ࠰ࠩ॔") in l111ll1_l1_: l1lll1ll_l1_.l1lll1l1_l1_(l111ll1_l1_)
		else: l1lll1ll_l1_.PLAY(l111ll1_l1_)
		return
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"่ࠩัฯ๎้ࠡษ็ๅ๏๊ๅ࠯ࠬࡂࡂ࠳࠰࠿ࠩ࡞ࡺ࠮ࡄ࠯࡜ࡘࠬࡂࡀࠬॕ"),html,re.DOTALL)
	if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	items = re.findall(l11l1l_l1_ (u"ࠪࡀࡧࡸࠠ࠰ࡀ࡟ࡲࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪॖ"),html,re.DOTALL)
	for l1llll1_l1_,title in items:
		title = unescapeHTML(title)
		addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫॗ"),l1111l_l1_+title,l1llll1_l1_,73)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣࡡࡷ࡭ࡹࡲࡥࠣ࠰࠭ࡃࡁ࡮࠱࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡱࡦ࡯࡮ࡠ࡫ࡰ࡫ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣࡧ࠱࠸࠶࠰࠮࠴࠸࠴࠭࠴ࠪࡀࠫࡤ࡯ࡴ࠳ࡦࡦࡧࡧࡦࡦࡩ࡫ࠨक़"),html,re.DOTALL)
	if not l1l11l1_l1_:
		l1llll1l_l1_(l11l1l_l1_ (u"࠭ฮุลࠣาฬืฬ๋ࠩख़"),l11l1l_l1_ (u"ࠧๅษࠣ๎ําฯࠡ็็ๅࠥ็๊ะ์๋ࠫग़"))
		return
	name,l1ll1l_l1_,block = l1l11l1_l1_[0]
	name = name.strip(l11l1l_l1_ (u"ࠨࠢࠪज़"))
	if l11l1l_l1_ (u"ࠩࡶࡹࡧࡥࡥࡱࡵ࡬ࡳࡩ࡫࡟ࡵ࡫ࡷࡰࡪ࠭ड़") in block:
		items = re.findall(l11l1l_l1_ (u"ࠪࡷࡺࡨ࡟ࡦࡲࡶ࡭ࡴࡪࡥࡠࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂ࠳࠰࠿ࡴࡷࡥࡣ࡫࡯࡬ࡦࡡࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫढ़"),block,re.DOTALL)
	else:
		filenames = re.findall(l11l1l_l1_ (u"ࠫࡸࡻࡢࡠࡨ࡬ࡰࡪࡥࡴࡪࡶ࡯ࡩࡡ࠭࠾ࠩ࠰࠭ࡃ࠮ࠦ࠭ࠡ࠾࡬ࡂࠬफ़"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l11l1l_l1_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫय़"),filename) )
	if not items: items = [ (l11l1l_l1_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬॠ"),l11l1l_l1_ (u"ࠧࠨॡ")) ]
	count = 0
	l1ll1ll1_l1_,l1111ll_l1_ = [],[]
	size = len(items)
	for title,filename in items:
		l11ll11_l1_ = l11l1l_l1_ (u"ࠨࠩॢ")
		if l11l1l_l1_ (u"ࠩࠣ࠱ࠥ࠭ॣ") in filename: filename = filename.split(l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧ।"))[0]
		else: filename = l11l1l_l1_ (u"ࠫࡩࡻ࡭࡮ࡻ࠱ࡾ࡮ࡶࠧ॥")
		if l11l1l_l1_ (u"ࠬ࠴ࠧ०") in filename: l11ll11_l1_ = filename.split(l11l1l_l1_ (u"࠭࠮ࠨ१"))[-1]
		#if any(value in l11ll11_l1_ for value in l111l11_l1_):
		#	if l11l1l_l1_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭२") not in title: title = title + l11l1l_l1_ (u"ࠨ࠼ࠪ३")
		title = title.replace(l11l1l_l1_ (u"ࠩ࡟ࡲࠬ४"),l11l1l_l1_ (u"ࠪࠫ५")).strip(l11l1l_l1_ (u"ࠫࠥ࠭६"))
		l1ll1ll1_l1_.append(title)
		l1111ll_l1_.append(count)
		count += 1
	if size>0:
		if any(value in name for value in l11l1ll_l1_):
			if size==1:
				l1l_l1_ = 0
			else:
				#DIALOG_SELECT(l11l1l_l1_ (u"ࠬ࠭७"),l1ll1ll1_l1_)
				l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ८"), l1ll1ll1_l1_)
				if l1l_l1_ == -1: return
			PLAY(url+l11l1l_l1_ (u"ࠧࡀࡵࡨࡧࡹ࡯࡯࡯࠿ࠪ९")+str(1+l1111ll_l1_[size-l1l_l1_-1]))
		else:
			for i in reversed(range(size)):
				#if l11l1l_l1_ (u"ࠨ࠼ࠪ॰") in l1ll1ll1_l1_[i]: title = l1ll1ll1_l1_[i].strip(l11l1l_l1_ (u"ࠩ࠽ࠫॱ")) + l11l1l_l1_ (u"ࠪࠤ࠲ࠦๅๅใࠣห้็๊ะ์๋ࠤ฿๐ัࠡ็๋ะํีࠧॲ")
				#else: title = name + l11l1l_l1_ (u"ࠫࠥ࠳ࠠࠨॳ") + l1ll1ll1_l1_[i]
				title = name + l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩॴ") + l1ll1ll1_l1_[i]
				title = title.replace(l11l1l_l1_ (u"࠭࡜࡯ࠩॵ"),l11l1l_l1_ (u"ࠧࠨॶ")).strip(l11l1l_l1_ (u"ࠨࠢࠪॷ"))
				l1llll1_l1_ = url + l11l1l_l1_ (u"ࠩࡂࡷࡪࡩࡴࡪࡱࡱࡁࠬॸ")+str(size-i)
				addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩॹ"),l1111l_l1_+title,l1llll1_l1_,74,l1ll1l_l1_)
	else:
		addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪॺ"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไาษห฻๊๊ࠥิࠢไ๎ิ๐่ࠨॻ"),l11l1l_l1_ (u"࠭ࠧॼ"),9999,l1ll1l_l1_)
		#l1llll1l_l1_(l11l1l_l1_ (u"ࠧฯูฦࠤำอัอ์ࠪॽ"),l11l1l_l1_ (u"ࠨษ็ีฬฮืࠡๆํืࠥ็๊ะ์๋ࠫॾ"))
	return
def PLAY(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪॿ"),l11l1l_l1_ (u"ࠪࠫঀ"),url,l11l1l_l1_ (u"ࠫࠬঁ"))
	l111l1l_l1_,l1ll11l_l1_ = url.split(l11l1l_l1_ (u"ࠬࡅࡳࡦࡥࡷ࡭ࡴࡴ࠽ࠨং"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪঃ"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨ঄"),headers,True,l11l1l_l1_ (u"ࠨࠩঅ"),l11l1l_l1_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡒࡏࡅ࡞ࡥࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩআ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡥࡩ࠳࠳࠱࠲࠰࠶࠺࠶࠮ࠫࡁࡤࡨ࠲࠹࠰࠱࠯࠵࠹࠵࠮࠮ࠫࡁࠬࡥࡰࡵ࠭ࡧࡧࡨࡨࡧࡧࡣ࡬ࠩই"),html,re.DOTALL)
	l111lll_l1_ = l1l11l1_l1_[0].replace(l11l1l_l1_ (u"ࠦࠬࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࡢࡦࡴࡾࠢঈ"),l11l1l_l1_ (u"ࠬࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠡࡧࡳࡷࡴ࡯ࡤࡦࡡࡥࡳࡽ࠭উ"))
	l111lll_l1_ = l111lll_l1_ + l11l1l_l1_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠨঊ")
	l111111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡦࡲࡶࡳ࡮ࡪࡥࡠࡤࡲࡼ࠭࠴ࠪࡀࠫࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࡟ࡣࡱࡻࠫঋ"),l111lll_l1_,re.DOTALL)
	l1ll11l_l1_ = len(l111111_l1_)-int(l1ll11l_l1_)
	block = l111111_l1_[l1ll11l_l1_]
	l1lll11l_l1_ = []
	l1lll111_l1_ = {l11l1l_l1_ (u"ࠨ࠳࠷࠶࠸࠶࠷࠶࠺࠹࠶ࠬঌ"):l11l1l_l1_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ঍"),l11l1l_l1_ (u"ࠪ࠵࠹࠽࠷࠵࠺࠺࠺࠵࠷ࠧ঎"):l11l1l_l1_ (u"ࠫࡪࡹࡴࡳࡧࡤࡱࠬএ"),l11l1l_l1_ (u"ࠬ࠷࠵࠱࠷࠶࠶࠽࠺࠰࠵ࠩঐ"):l11l1l_l1_ (u"࠭ࡳࡵࡴࡨࡥࡲࡧ࡮ࡨࡱࠪ঑"),
		l11l1l_l1_ (u"ࠧ࠲࠶࠵࠷࠵࠾࠰࠱࠳࠸ࠫ঒"):l11l1l_l1_ (u"ࠨࡨ࡯ࡥࡸ࡮ࡸࠨও"),l11l1l_l1_ (u"ࠩ࠴࠸࠺࠾࠱࠲࠹࠵࠽࠺࠭ঔ"):l11l1l_l1_ (u"ࠪࡳࡵ࡫࡮࡭ࡱࡤࡨࠬক"),l11l1l_l1_ (u"ࠫ࠶࠺࠲࠴࠲࠺࠽࠸࠶࠶ࠨখ"):l11l1l_l1_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬগ"),l11l1l_l1_ (u"࠭࠱࠵࠵࠳࠴࠺࠸࠳࠸࠳ࠪঘ"):l11l1l_l1_ (u"ࠧࡰ࡭࠱ࡶࡺ࠭ঙ"),
		l11l1l_l1_ (u"ࠨ࠳࠷࠻࠼࠺࠸࠹࠴࠴࠷ࠬচ"):l11l1l_l1_ (u"ࠩࡷ࡬ࡪࡼࡩࡥࠩছ"),l11l1l_l1_ (u"ࠪ࠵࠺࠻࠸࠳࠹࠻࠴࠵࠼ࠧজ"):l11l1l_l1_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫঝ"),l11l1l_l1_ (u"ࠬ࠷࠴࠸࠹࠷࠼࠼࠿࠹࠱ࠩঞ"):l11l1l_l1_ (u"࠭ࡶࡪࡦࡷࡳࡩࡵࠧট")}
	items = re.findall(l11l1l_l1_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡥࡸࡳ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭ࠢঠ"),block,re.DOTALL)
	for l1llll1_l1_ in items:
		l1lll11l_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨড"))
	items = re.findall(l11l1l_l1_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨঢ"),block,re.DOTALL)
	for l11l1l1_l1_,l1llll1_l1_ in items:
		l11l1l1_l1_ = l11l1l1_l1_.split(l11l1l_l1_ (u"ࠪ࠳ࠬণ"))[-1]
		l11l1l1_l1_ = l11l1l1_l1_.split(l11l1l_l1_ (u"ࠫ࠳࠭ত"))[0]
		if l11l1l1_l1_ in l1lll111_l1_:
			l1lll11l_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭থ")+l1lll111_l1_[l11l1l1_l1_]+l11l1l_l1_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡢ࡭ࡲࡥࡲ࠭দ"))
		else: l1lll11l_l1_.append(l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨধ")+l11l1l1_l1_+l11l1l_l1_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨন"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ঩"),l11l1l_l1_ (u"ࠪࠫপ"),url,str(l1lll11l_l1_))
	if not l1lll11l_l1_:
		message = re.findall(l11l1l_l1_ (u"ࠫࡸࡻࡢ࠮ࡰࡲ࠱࡫࡯࡬ࡦ࠰࠭ࡃࡡࡴࠨ࠯ࠬࡂ࠭ࡡࡴࠧফ"),block,re.DOTALL)
		if message: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ব"),l11l1l_l1_ (u"࠭ࠧভ"),l11l1l_l1_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩম"),message[0])
	else:
		import ll_l1_
		ll_l1_.l11_l1_(l1lll11l_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧয"),url)
	return
def SEARCH(search):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪর"),l11l1l_l1_ (u"ࠪࠫ঱"),search,l11l1l_l1_ (u"ࠫࠬল"))
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭঳"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ঴"): return
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ঵"),l11l1l_l1_ (u"ࠨࠧ࠵࠴ࠬশ"))
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠲ࠫষ")+l11111l_l1_
	results = l1lllll_l1_(url,l11l1l_l1_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪস"))
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
#l11l11_l1_ = l11l1l_l1_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭䇐")
headers = {l11l1l_l1_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ䇑"):l11l1l_l1_ (u"ࠨࠩ䇒")}
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡓࡅࡓࡋࡔࠨ䇓")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡕࡔࡔࡠࠩ䇔")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
def MAIN(mode,url,l11lll1_l1_,text):
	if   mode==30: results = MENU()
	elif mode==31: results = CATEGORIES(url,l11l1l_l1_ (u"ࠫ࠸࠭䇕"))
	elif mode==32: results = ITEMS(url)
	elif mode==33: results = PLAY(url)
	elif mode==35: results = CATEGORIES(url,l11l1l_l1_ (u"ࠬ࠷ࠧ䇖"))
	elif mode==36: results = CATEGORIES(url,l11l1l_l1_ (u"࠭࠲ࠨ䇗"))
	elif mode==37: results = CATEGORIES(url,l11l1l_l1_ (u"ࠧ࠵ࠩ䇘"))
	elif mode==38: results = l1l1ll111_l1_()
	elif mode==39: results = SEARCH(text,l11lll1_l1_)
	else: results = False
	return results
def MENU():
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇙"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䇚"),l11l1l_l1_ (u"ࠪࠫ䇛"),39,l11l1l_l1_ (u"ࠫࠬ䇜"),l11l1l_l1_ (u"ࠬ࠭䇝"),l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䇞"))
	#addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䇟"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ䇠"),l11l1l_l1_ (u"ࠩࠪ䇡"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡼࡥࠨ䇢"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭䇣")+l1111l_l1_+l11l1l_l1_ (u"่ࠬๆศห๋้ࠣอࠠๆ่้ࠣํู่ࠡสส๊๏ะࠧ䇤"),l11l1l_l1_ (u"࠭ࠧ䇥"),38)
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇦"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ䇧")+l1111l_l1_+l11l1l_l1_ (u"่ࠩืู้ไศฬࠣ์อืวๆฮࠪ䇨"),l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䇩"),31)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇪"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ䇫")+l1111l_l1_+l11l1l_l1_ (u"࠭วๅ็ึุ่๊วหࠢส่ฬ้หาุ่ࠢฬํฯสࠩ䇬"),l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䇭"),37)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇮"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ䇯")+l1111l_l1_+l11l1l_l1_ (u"ࠪหๆ๊วๆࠢะือࠦวๅ่๋฽ࠬ䇰"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬ䇱"),35)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇲"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ䇳")+l1111l_l1_+l11l1l_l1_ (u"ࠧศใ็ห๊ࠦอิสࠣห้๋ๅฬๆࠪ䇴"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩ䇵"),36)
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇶"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ䇷")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬำฯฬࠢส่ฬ็ไศ็ࠪ䇸"),l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭䇹"),32)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䇺"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ䇻")+l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึีา๐วหࠩ䇼"),l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲࡫ࡪࡴࡲࡦ࠱࠷࠳࠶࠭䇽"),32)
	return l11l1l_l1_ (u"ࠪࠫ䇾")
def CATEGORIES(url,select=l11l1l_l1_ (u"ࠫࠬ䇿")):
	type = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧ䈀"))[3]
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䈁"),l11l1l_l1_ (u"ࠧࠨ䈂"),type, url)
	if type==l11l1l_l1_ (u"ࠨ࡯ࡲࡷࡦࡲࡳࡢ࡮ࡤࡸࠬ䈃"):
		html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"ࠩࠪ䈄"),headers,l11l1l_l1_ (u"ࠪࠫ䈅"),l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠲ࡵࡷࠫ䈆"))
		if select==l11l1l_l1_ (u"ࠬ࠹ࠧ䈇"):
			l1l11l1_l1_=re.findall(l11l1l_l1_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵࡐࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡸ࡫ࡲࡪࡧࡶࡊࡴࡸ࡭ࠨ䈈"),html,re.DOTALL)
			block= l1l11l1_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䈉"),block,re.DOTALL)
			for l1llll1_l1_,name in items:
				if l11l1l_l1_ (u"ࠨๅ็๎ออสࠡ็ูั่ฯࠧ䈊") in name: continue
				url = l11l11_l1_ + l1llll1_l1_
				name = name.strip(l11l1l_l1_ (u"ࠩࠣࠫ䈋"))
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䈌"),l1111l_l1_+name,url,32)
		if select==l11l1l_l1_ (u"ࠫ࠹࠭䈍"):
			l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡩ࡫ࡴࡢ࡫࡯ࡷ࠲ࡶࡡ࡯ࡧ࡯ࠬ࠳࠰࠿ࠪࡸࡁࡀ࠴ࡧ࠾࠽࠱ࡧ࡭ࡻࡄࠧ䈎"),html,re.DOTALL)
			block= l1l11l1_l1_[0]
			items=re.findall(l11l1l_l1_ (u"࠭ࡰࡢࡰࡨࡸ࠲ࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䈏"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				url = l11l11_l1_ + l1llll1_l1_
				title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ䈐"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䈑"),l1111l_l1_+title,url,32,l1ll1l_l1_)
		#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䈒"),l11l1l_l1_ (u"ࠪࠫ䈓"),url,l11l1l_l1_ (u"ࠫࠬ䈔"))
	if type==l11l1l_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䈕"):
		html = OPENURL_CACHED(l1llll11_l1_,url,l11l1l_l1_ (u"࠭ࠧ䈖"),headers,l11l1l_l1_ (u"ࠧࠨ䈗"),l11l1l_l1_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠷ࡴࡤࠨ䈘"))
		if select==l11l1l_l1_ (u"ࠩ࠴ࠫ䈙"):
			l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠪࡱࡴࡼࡩࡦࡵࡊࡩࡳࡪࡥࡳࠪ࠱࠮ࡄ࠯ࡳࡦ࡮ࡨࡧࡹ࠭䈚"),html,re.DOTALL)
			block = l1l11l1_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠫࡴࡶࡴࡪࡱࡱࡂࡁࡵࡰࡵ࡫ࡲࡲࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䈛"),block,re.DOTALL)
			for value,name in items:
				url = l11l11_l1_ + l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡧࡦࡰࡵࡩ࠴࠭䈜") + value
				name = name.strip(l11l1l_l1_ (u"࠭ࠠࠨ䈝"))
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䈞"),l1111l_l1_+name,url,32)
		elif select==l11l1l_l1_ (u"ࠨ࠴ࠪ䈟"):
			l1l11l1_l1_=re.findall(l11l1l_l1_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࡃࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭ࡸ࡫࡬ࡦࡥࡷࠫ䈠"),html,re.DOTALL)
			block = l1l11l1_l1_[0]
			items=re.findall(l11l1l_l1_ (u"ࠪࡳࡵࡺࡩࡰࡰࡁࡀࡴࡶࡴࡪࡱࡱࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䈡"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l11l1l_l1_ (u"ࠫࠥ࠭䈢"))
				url = l11l11_l1_ + l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠵ࡡࡤࡶࡲࡶ࠴࠭䈣") + value
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈤"),l1111l_l1_+name,url,32)
	return
def ITEMS(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䈥"),l11l1l_l1_ (u"ࠨࠩ䈦"),url,l11l1l_l1_ (u"ࠩࠪ䈧"))
	type = url.split(l11l1l_l1_ (u"ࠪ࠳ࠬ䈨"))[3]
	html = OPENURL_CACHED(REGULAR_CACHE,url,l11l1l_l1_ (u"ࠫࠬ䈩"),headers,l11l1l_l1_ (u"ࠬ࠭䈪"),l11l1l_l1_ (u"࠭ࡐࡂࡐࡈࡘ࠲ࡏࡔࡆࡏࡖ࠱࠶ࡹࡴࠨ䈫"))
	if l11l1l_l1_ (u"ࠧࡩࡱࡰࡩࠬ䈬") in url: type=l11l1l_l1_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࡵࠪ䈭")
	if type==l11l1l_l1_ (u"ࠩࡰࡳࡸࡧ࡬ࡴࡣ࡯ࡥࡹ࠭䈮"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠮࠮ࠫࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭䈯"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫࠶ࡃ࠮࠮ࠫࡁࠬࡀࠬ䈰"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,name in items:
				url = l11l11_l1_ + l1llll1_l1_
				name = name.strip(l11l1l_l1_ (u"ࠬࠦࠧ䈱"))
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䈲"),l1111l_l1_+name,url,32,l1ll1l_l1_)
	if type==l11l1l_l1_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ䈳"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠭࠴ࠫࡀࠫࡳࡥࡳ࡫ࡴ࠮ࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ䈴"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠭䈵"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,name in items:
			name = name.strip(l11l1l_l1_ (u"ࠪࠤࠬ䈶"))
			url = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䈷"),l1111l_l1_+name,url,33,l1ll1l_l1_)
	if type==l11l1l_l1_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧ䈸"):
		l11lll1_l1_ = url.split(l11l1l_l1_ (u"࠭࠯ࠨ䈹"))[-1]
		#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䈺"),l11l1l_l1_ (u"ࠨࠩ䈻"),url,l11l1l_l1_ (u"ࠩࠪ䈼"))
		if l11lll1_l1_==l11l1l_l1_ (u"ࠪ࠵ࠬ䈽"):
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠩ࠰࠮ࡃ࠮ࡧࡤࡷࡄࡤࡶࡒࡧࡲࡴࠩ䈾"),html,re.DOTALL)
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠬࡶࡡ࡯ࡧࡷ࠱ࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡰࡢࡰࡨࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻ࠭䈿"),block,re.DOTALL)
			count = 0
			for l1llll1_l1_,l1ll1l_l1_,l1ll11l_l1_,title in items:
				count += 1
				if count==10: break
				name = title + l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ䉀") + l1ll11l_l1_
				url = l11l11_l1_ + l1llll1_l1_
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䉁"),l1111l_l1_+name,url,33,l1ll1l_l1_)
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡣࡧࡺࡇࡧࡲࡎࡣࡵࡷ࠳࠰࠿ࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶࠬ࠳࠱࠿ࠪࡲࡤࡲࡪࡺ࠭ࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䉂"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱࡮ࡴࡦࡰࠤࡁࡀ࡭࠸࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠴ࠪ䉃"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title,l1ll11l_l1_ in items:
			l1ll11l_l1_ = l1ll11l_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ䉄"))
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭䉅"))
			name = title + l11l1l_l1_ (u"ࠬࠦ࠭ࠡࠩ䉆") + l1ll11l_l1_
			url = l11l11_l1_ + l1llll1_l1_
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ䉇"),l1111l_l1_+name,url,33,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡨ࡮ࡼࡴ࡭࡯ࡣࡰࡰ࠰ࡧ࡭࡫ࡶࡳࡱࡱ࠱ࡷ࡯ࡧࡩࡶࠫ࠲࠰ࡅࠩࡥࡣࡷࡥ࠲ࡸࡥࡷ࡫ࡹࡩ࠲ࢀ࡯࡯ࡧ࡬ࡨࡂࠨ࠴ࠣࠩ䉈"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䉉"),block,re.DOTALL)
	for l1llll1_l1_,l11lll1_l1_ in items:
		url = l11l11_l1_ + l1llll1_l1_
		name = l11l1l_l1_ (u"ุࠩๅาฯࠠࠨ䉊") + l11lll1_l1_
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䉋"),l1111l_l1_+name,url,32)
	return
def PLAY(url):
	if l11l1l_l1_ (u"ࠫࡲࡵࡳࡢ࡮ࡶࡥࡱࡧࡴࠨ䉌") in url:
		url = l11l11_l1_ + l11l1l_l1_ (u"ࠬ࠵࡭ࡰࡵࡤࡰࡸࡧ࡬ࡢࡶ࠲ࡺ࠶࠵ࡳࡦࡴ࡬ࡩࡸࡒࡩ࡯࡭࠲ࠫ䉍") + url.split(l11l1l_l1_ (u"࠭࠯ࠨ䉎"))[-1]
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ䉏"),url,l11l1l_l1_ (u"ࠨࠩ䉐"),headers,l11l1l_l1_ (u"ࠩࠪ䉑"),l11l1l_l1_ (u"ࠪࠫ䉒"),l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ䉓"))
		html = response.content
		items = re.findall(l11l1l_l1_ (u"ࠬࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䉔"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l11l1l_l1_ (u"࠭࡜࠰ࠩ䉕"),l11l1l_l1_ (u"ࠧ࠰ࠩ䉖"))
	else:
		response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ䉗"),url,l11l1l_l1_ (u"ࠩࠪ䉘"),headers,l11l1l_l1_ (u"ࠪࠫ䉙"),l11l1l_l1_ (u"ࠫࠬ䉚"),l11l1l_l1_ (u"ࠬࡖࡁࡏࡇࡗ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭䉛"))
		html = response.content
		items = re.findall(l11l1l_l1_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡕࡓࡎࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䉜"),html,re.DOTALL)
		url = items[0]
	PLAY_VIDEO(url,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䉝"))
	return
def SEARCH(search,l11lll1_l1_=l11l1l_l1_ (u"ࠨࠩ䉞")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	l11111l_l1_ = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ䉟"),l11l1l_l1_ (u"ࠪࠩ࠷࠶ࠧ䉠"))
	l1l1lll11_l1_ = [l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ䉡"),l11l1l_l1_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䉢")]
	if not l11lll1_l1_: l11lll1_l1_ = l11l1l_l1_ (u"࠭࠱ࠨ䉣")
	else: l11lll1_l1_,type = l11lll1_l1_.split(l11l1l_l1_ (u"ࠧ࠰ࠩ䉤"))
	if l1ll_l1_:
		l1l111ll1_l1_ = [ l11l1l_l1_ (u"ࠨสะฯࠥ฿ๆࠡษไ่ฬ๋ࠧ䉥") , l11l1l_l1_ (u"ࠩหัะูࠦ็่ࠢืู้ไศฬࠪ䉦")]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡสส๊๏ะࠠ࠮ࠢสาฯืࠠศๆหัะ࠭䉧"), l1l111ll1_l1_)
		if l1l_l1_ == -1 : return
		type = l1l1lll11_l1_[l1l_l1_]
	else:
		if l11l1l_l1_ (u"ࠫࡤࡖࡁࡏࡇࡗ࠱ࡒࡕࡖࡊࡇࡖࡣࠬ䉨") in options: type = l11l1l_l1_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䉩")
		elif l11l1l_l1_ (u"࠭࡟ࡑࡃࡑࡉ࡙࠳ࡓࡆࡔࡌࡉࡘࡥࠧ䉪") in options: type = l11l1l_l1_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䉫")
		else: return
	headers[l11l1l_l1_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ䉬")] = l11l1l_l1_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩ䉭")
	data = {l11l1l_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࠩ䉮"):l11111l_l1_ , l11l1l_l1_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡈࡴࡳࡡࡪࡰࠪ䉯"):type}
	if l11lll1_l1_!=l11l1l_l1_ (u"ࠬ࠷ࠧ䉰"): data[l11l1l_l1_ (u"࠭ࡦࡳࡱࡰࠫ䉱")] = l11lll1_l1_
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡑࡑࡖࡘࠬ䉲"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ䉳"),data,headers,l11l1l_l1_ (u"ࠩࠪ䉴"),l11l1l_l1_ (u"ࠪࠫ䉵"),l11l1l_l1_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ䉶"))
	html = response.content
	items=re.findall(l11l1l_l1_ (u"ࠬࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䉷"),html,re.DOTALL)
	if items:
		for title,l1llll1_l1_ in items:
			url = l11l11_l1_ + l1llll1_l1_.replace(l11l1l_l1_ (u"࠭࡜࠰ࠩ䉸"),l11l1l_l1_ (u"ࠧ࠰ࠩ䉹"))
			if l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࠪ䉺") in url: addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䉻"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ๏๊ๅࠡࠩ䉼")+title,url,33)
			elif l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭䉽") in url:
				url = url.replace(l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠧ䉾"),l11l1l_l1_ (u"࠭࠯࡮ࡱࡶࡥࡱࡹࡡ࡭ࡣࡷ࠳ࠬ䉿"))
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊀"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ึุ่๊ࠠࠨ䊁")+title,url+l11l1l_l1_ (u"ࠩ࠲࠵ࠬ䊂"),32)
	count=re.findall(l11l1l_l1_ (u"ࠪࠦࡹࡵࡴࡢ࡮ࠥ࠾࠭࠴ࠪࡀࠫࢀࠫ䊃"),html,re.DOTALL)
	if count:
		l1l1l1l11_l1_ = int(  (int(count[0])+9)   /10 )+1
		for l1ll11111_l1_ in range(1,l1l1l1l11_l1_):
			l1ll11111_l1_ = str(l1ll11111_l1_)
			if l1ll11111_l1_!=l11lll1_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䊄"),l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ䊅")+l1ll11111_l1_,l11l1l_l1_ (u"࠭ࠧ䊆"),39,l11l1l_l1_ (u"ࠧࠨ䊇"),l1ll11111_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ䊈")+type,search)
	return
def l1l1ll111_l1_():
	l1llll1_l1_ = l11l1l_l1_ (u"ࠩࡤࡌࡗ࠶ࡣࡅࡱࡹࡐ࠷ࡪࡺࡥࡊࡍࡰ࡞࡝࠰࠱ࡎࡱࡆ࡭ࡨ࡭ࡗ࠲ࡏࡱࡓࡼࡌ࡮࡮ࡶࡐ࠷࡜࡫࡛࠴࡙ࡪ࡞࡝ࡊࡺࡎ࠵࡬࡭ࡨࡇࡇࡗ࡙࡭࠾ࡽࡢࡈࡈ࠸ࡦࡌࡲࡺࡥࡅ࠸ࡸࡒ࠹ࡕ࠵ࠩ䊉")
	l1llll1_l1_ = base64.b64decode(l1llll1_l1_)
	l1llll1_l1_ = l1llll1_l1_.decode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ䊊"))
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䊋"))
	return
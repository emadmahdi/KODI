# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠࠧᅛ")
headers = { l11l1l_l1_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᅜ") : l11l1l_l1_ (u"ࠧࠨᅝ") }
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡄࡖࡑࡥࠧᅞ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠩ฼ีํ฼ࠠศๆู่ฬืูสࠩᅟ"),l11l1l_l1_ (u"ࠪห้้ไࠨᅠ"),l11l1l_l1_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭ᅡ"),l11l1l_l1_ (u"ࠬอไฺษหࠫᅢ"),l11l1l_l1_ (u"࠭ศาษ่ะ้ࠥๅษ์๋ฮึ࠭ᅣ"),l11l1l_l1_ (u"ࠧๆ๊หห๏๊้ࠠࠢฯ์ฬ๊ࠧᅤ"),l11l1l_l1_ (u"ࠨษ็ๆุ๋ࠠศๆสื้อๅ๋ࠩᅥ")]
def MAIN(mode,url,text):
	if   mode==200: results = MENU()
	elif mode==201: results = l1lllll_l1_(url)
	elif mode==202: results = PLAY(url)
	elif mode==203: results = l1lll1l1_l1_(url)
	elif mode==204: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭ᅦ")+text)
	elif mode==205: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪᅧ")+text)
	elif mode==209: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅨ"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᅩ"),l11l1l_l1_ (u"࠭ࠧᅪ"),209,l11l1l_l1_ (u"ࠧࠨᅫ"),l11l1l_l1_ (u"ࠨࠩᅬ"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᅭ"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅮ"),l1111l_l1_+l11l1l_l1_ (u"ࠫๆ๊สา่ࠢัิีࠧᅯ"),l11l11_l1_,205)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᅰ"),l1111l_l1_+l11l1l_l1_ (u"࠭แๅฬิࠤ่อๅๅࠩᅱ"),l11l11_l1_,204)
	addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᅲ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᅳ"),l11l1l_l1_ (u"ࠩࠪᅴ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᅵ"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭ᅶ")+l1111l_l1_+l11l1l_l1_ (u"๋ࠬๅ๋ิฬࠫᅷ"),l11l11_l1_+l11l1l_l1_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࠪᅸ"),201)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅹ"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪᅺ")+l1111l_l1_+l11l1l_l1_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧᅻ"),l11l11_l1_+l11l1l_l1_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᅼ"),201)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᅽ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᅾ")+l1111l_l1_+l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠠๆ็ํึฮ࠭ᅿ"),l11l11_l1_+l11l1l_l1_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࡣࡸ࡫ࡲࡪࡧࡶࠫᆀ"),201)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᆁ"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫᆂ")+l1111l_l1_+l11l1l_l1_ (u"ࠪห้฻แฮหࠣห้ืฦ๋ีํอࠬᆃ"),l11l11_l1_+l11l1l_l1_ (u"ࠫࡄࡅ࡭ࡢ࡫ࡱࡴࡦ࡭ࡥࠨᆄ"),201)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩᆅ"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧᆆ"),headers,True,l11l1l_l1_ (u"ࠧࠨᆇ"),l11l1l_l1_ (u"ࠨࡃࡕࡆࡑࡏࡏࡏ࡜࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᆈ"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳ࡴࡢࡤࡶࠬ࠳࠰࠿ࠪࡏࡤ࡭ࡳࡘ࡯ࡸࠩᆉ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡩࡨࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᆊ"),block,re.DOTALL)
		for filter,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲࡬ࡴࡳࡥ࠰࡯ࡲࡶࡪࡅࡦࡪ࡮ࡷࡩࡷࡃࠧᆋ")+filter
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆌ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᆍ")+l1111l_l1_+title,l1llll1_l1_,201)
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬᆎ"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࡁࡂ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᆏ"),l11l1l_l1_ (u"ࠩࠪᆐ"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷ࡭ࡴࡴ࠭࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᆑ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᆒ"),block,re.DOTALL)
	#l1111l11l_l1_ = [l11l1l_l1_ (u"๋ࠬำๅี็หฯࠦࠧᆓ"),l11l1l_l1_ (u"࠭วโๆส้ࠥ࠭ᆔ"),l11l1l_l1_ (u"ࠧษำส้ั࠭ᆕ"),l11l1l_l1_ (u"ࠨ฻ิ์฻࠭ᆖ"),l11l1l_l1_ (u"ࠩๆ่๏ฮวหࠩᆗ"),l11l1l_l1_ (u"ࠪห฿อๆ๊ࠩᆘ")]
	for l1llll1_l1_,title in items:
		if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩᆙ") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧᆚ"))
		if not any(value in title for value in l1l111_l1_):
			addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᆛ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᆜ")+l1111l_l1_+title,l1llll1_l1_,201)
	return html
def l1lllll_l1_(url):
	l11l1l_l1_ (u"ࠣࠤࠥࠎࠎࠩࠠࡧࡱࡵࠤࡕࡕࡓࡕࠢࡩ࡭ࡱࡺࡥࡳ࠼ࠍࠍ࡮࡬ࠠࠨ࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࠬࠦࡩ࡯ࠢࡸࡶࡱࡀࠊࠊࠋࡸࡶࡱ࠸ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠳ࠢࡀࠤࡺࡸ࡬࠯ࡵࡳࡰ࡮ࡺࠨࠨࡁࠪ࠭ࠏࠏࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࠪ࠰ࠬ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠫ࠮ࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࠩࠪ࠰ࡺࡸ࡬࠳࠮ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠭ࠏࠏࠉࡥࡣࡷࡥ࠷ࠦ࠽ࠡࡽࠪࡪࡴࡸ࡭ࠨ࠼ࡩ࡭ࡱࡺࡥࡳࡵ࠵࠰ࠬࡌࡩ࡭ࡶࡨࡶ࡜ࡵࡲࡥ࠿ࠪ࠾ࠬ࠭ࡽࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࠥࡃࠠࡩࡧࡤࡨࡪࡸࡳࠋࠋࠌ࡬ࡪࡧࡤࡦࡴࡶ࠶ࡠ࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬࡣࠠ࠾ࠢࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪࠎࠎࠏࡨࡦࡣࡧࡩࡷࡹ࠲࡜࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬࡣࠠ࠾ࠢࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪ࡜࠲ࡉࡓࡓࡈ࠰ࡘࡔࡑࡅࡏࠩࡠࠤࡂࠦࠧࡈ࡜࠷ࡓࡩ࠶࡮࡫ࡖࡆࡥࡌࡽࡣࡈࡳ࠷ࡍࡿࡍࡱࡉࡇࡵ࡝࠵ࡻ࡚ࡰࡣࡘ࡜࡟ࡉ࠶ࡉࡧ࡛ࡼࡽ࠭ࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵ࠵࡟ࠬࡉ࡯ࡰ࡭࡬ࡩࠬࡣࠠ࠾ࠢࠪࡻࡦࡸࡢ࡭࡫ࡲࡲࡿࡺࡶࡠࡵࡨࡷࡸ࡯࡯࡯࠿ࡨࡽࡏࡶࡤࡪࡋ࠹ࡍࡲࡘ࠰ࡎ࡚ࡑࡎ࡞ࡲࡒࡍࡓ࡭ࡨࡦࡔࡄ࡬ࡺ࡙ࡲࡩࡍ࡚࠲ࡄ࠵࡝ࡱࡋ࠹ࡑࡕࡌࡷࡎࡴ࡚ࡩࡤࡋ࡚ࡱࡏࡪࡰ࡫ࡔࡘࡗࡘࡖ࡙ࡏ࠴࡙࡯ࡲࡇࡣࡈࡉࡶࡦ࡛ࡆ࡬ࡑࡈࡼࡊࡕࡕࡗࡓ࡜࡙࠹࠷ࡤ࠲ࡐ࡚ࡩࡍࡩࡷࡦࡰࡐࡽ࡛࡝ࡒࡇࡓࡰࡰ࠷࡛ࡘࡊ࠲ࡧ࡯ࡽࡲ࡚࠲ࡄࡱࡥ࠸ࡶࡘࡔ࠳ࡅ࡛ࡧ࡚ࡁ࠴ࡕࡰࡒ࡯ࡪࡆࡥ࠵࡚ࡇࡎࡹࡉ࡮࠳࡫࡝ࡾࡏ࠶ࡊ࡬ࡘࡼ࡟࡚ࡧࡺࡐࡰࡑࡾࡕࡇࡆࡻࡐ࡮ࡎ࠶ࡎࡅࡐ࡯࡞࡯࡮࡬ࡏ࠴ࡑ࡯࡟࡚ࡂ࡮ࡐ࡭ࡨࡲ࡟ࡺࡂ࠲ࡑ࡮ࡆࡽࡍࡕࡌ࡮ࡑࡿࡠࡪࡐࡆࡌࡾࡓ࡚࡙ࡺࡏࡽ࡯࠵ࡔࡄࡤ࠷ࡐࡘࡇࡰࡎࡘࡋࡼࡓ࡙ࡲࡪࡏ࡬ࡪ࡭࡫ࡗ࠽࠾ࠩࠍࠍࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱࠭ࡐࡐࡕࡗࠫ࠱ࡻࡲ࡭࠴࠯ࡨࡦࡺࡡ࠳࠮࡫ࡩࡦࡪࡥࡳࡵ࠵࠰࡙ࡸࡵࡦ࠮ࠪࠫ࠱࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸࠨ࠴ࡥ࡯ࡥࡲࡨࡪ࠮ࠧࡶࡶࡩ࠼ࠬ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠤࠥࠦᆝ")
	if l11l1l_l1_ (u"ࠩࡂࡃࠬᆞ") in url: url,type = url.split(l11l1l_l1_ (u"ࠪࡃࡄ࠭ᆟ"))
	else: type = l11l1l_l1_ (u"ࠫࠬᆠ")
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᆡ"),l11l1l_l1_ (u"࠭ࠧᆢ"),url,type)
	#if url==l11l11_l1_: url = url+l11l1l_l1_ (u"ࠧ࠰ࡣ࡯ࡾࠬᆣ")
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩᆤ"),l11l1l_l1_ (u"ࠩࠪᆥ"),url,l11l1l_l1_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪᆦ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨᆧ"),url,l11l1l_l1_ (u"ࠬ࠭ᆨ"),headers,True,l11l1l_l1_ (u"࠭ࠧᆩ"),l11l1l_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ᆪ"))
	html = response.content#.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭ᆫ"))
	#WRITE_THIS(html)
	if l11l1l_l1_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫᆬ") in url: l1l11l1_l1_ = [html]
	elif type==l11l1l_l1_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬᆭ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡒࡧࡳࡵࡧࡵࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ᆮ"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧᆯ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠱ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬᆰ"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩᆱ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠴ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧᆲ"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠩ࠴࠵࠶ࡳࡡࡪࡰࡳࡥ࡬࡫ࠧᆳ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨࡳࠣࠩᆴ"),html,re.DOTALL)
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲ࠲࡬࡯ࡰࡶࡨࡶࠬᆵ"),html,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ᆶ"),l11l1l_l1_ (u"࠭ࠧᆷ"),l11l1l_l1_ (u"ࠧࠨᆸ"),str(l1l11l1_l1_))
	if not l1l11l1_l1_: return
	block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡲࡼ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬᆹ"),block,re.DOTALL)
	l111l1l1l_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩᆺ"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨᆻ"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪᆼ"),l11l1l_l1_ (u"้ࠬไ๋สࠪᆽ"),l11l1l_l1_ (u"࠭วฺๆส๊ࠬᆾ"),l11l1l_l1_ (u"่ࠧัสๅࠬᆿ"),l11l1l_l1_ (u"ࠨ็หหึอษࠨᇀ"),l11l1l_l1_ (u"ࠩ฼ี฻࠭ᇁ"),l11l1l_l1_ (u"้ࠪ์ืฬศ่ࠪᇂ"),l11l1l_l1_ (u"ࠫฬ๊ศ้็ࠪᇃ")]
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪᇄ"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᇅ"),l11l1l_l1_ (u"ࠧࠨᇆ"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡥࡳࡽࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᇇ"),block,re.DOTALL)
	if not items:
		items = re.findall(l11l1l_l1_ (u"ࠩࡖࡰ࡮ࡪࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁ࡮࠲࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᇈ"),block,re.DOTALL)
		l1l1_l1_,l1111l111_l1_,l11ll1_l1_ = zip(*items)
		items = zip(l1111l111_l1_,l1l1_l1_,l11ll1_l1_)
	l11l_l1_ = []
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = escapeUNICODE(l1llll1_l1_)
		#l1llll1_l1_ = QUOTE(l1llll1_l1_)
		if l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᇉ") in l1llll1_l1_: continue
		l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭ᇊ"))
		title = unescapeHTML(title)
		title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧᇋ"))
		if l11l1l_l1_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭ᇌ") in l1llll1_l1_ or any(value in title for value in l111l1l1l_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᇍ"),l1111l_l1_+title,l1llll1_l1_,202,l1ll1l_l1_)
		elif l11l1l_l1_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫᇎ") in l1llll1_l1_ and l11l1l_l1_ (u"ࠩส่า๊โสࠩᇏ") in title:
			l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭ᇐ"),title,re.DOTALL)
			if l1ll11l_l1_:
				title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪᇑ") + l1ll11l_l1_[0]
				if title not in l11l_l1_:
					addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᇒ"),l1111l_l1_+title,l1llll1_l1_,203,l1ll1l_l1_)
					l11l_l1_.append(title)
		elif l11l1l_l1_ (u"࠭࠯ࡱࡣࡦ࡯࠴࠭ᇓ") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇔ"),l1111l_l1_+title,l1llll1_l1_+l11l1l_l1_ (u"ࠨ࠱ࡩ࡭ࡱࡳࡳࠨᇕ"),201,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᇖ"),l1111l_l1_+title,l1llll1_l1_,203,l1ll1l_l1_)
	if type in [l11l1l_l1_ (u"ࠪࠫᇗ"),l11l1l_l1_ (u"ࠫࡲࡧࡩ࡯ࡲࡤ࡫ࡪ࠭ᇘ")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᇙ"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᇚ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
				title = unescapeHTML(title)
				title = title.replace(l11l1l_l1_ (u"ࠧศๆุๅาฯࠠࠨᇛ"),l11l1l_l1_ (u"ࠨࠩᇜ"))
				if l11l1l_l1_ (u"ࠩࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬᇝ") in url:
					l11111ll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩᇞ"))[1]
					l111l1111_l1_ = url.split(l11l1l_l1_ (u"ࠫࡵࡧࡧࡦ࠿ࠪᇟ"))[1]
					l1llll1_l1_ = url.replace(l11l1l_l1_ (u"ࠬࡶࡡࡨࡧࡀࠫᇠ")+l111l1111_l1_,l11l1l_l1_ (u"࠭ࡰࡢࡩࡨࡁࠬᇡ")+l11111ll1_l1_)
				if title!=l11l1l_l1_ (u"ࠧࠨᇢ"): addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᇣ"),l1111l_l1_+l11l1l_l1_ (u"ุࠩๅาฯࠠࠨᇤ")+title,l1llll1_l1_,201)
	return
def l1lll1l1_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠪࠫᇥ"),l11l1l_l1_ (u"ࠫࠬᇦ"),url,l11l1l_l1_ (u"ࠬ࠭ᇧ"))
	l111ll111_l1_,items,l1111l11_l1_ = -1,[],[]
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᇨ"),url,l11l1l_l1_ (u"ࠧࠨᇩ"),headers,True,l11l1l_l1_ (u"ࠨࠩᇪ"),l11l1l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪᇫ"))
	html = response.content#.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨᇬ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡹ࡯࠭࡭࡫ࡶࡸ࠲ࡴࡵ࡮ࡤࡨࡶࡪࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᇭ"),html,re.DOTALL)
	if l1l11l1_l1_:
		l1111l11_l1_ = []
		l111111_l1_ = l11l1l_l1_ (u"ࠬ࠭ᇮ").join(l1l11l1_l1_)
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᇯ"),l111111_l1_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨᇰ"))
	for l1llll1_l1_ in items:
		l1llll1_l1_ = l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪᇱ"))
		title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᇲ") + l1llll1_l1_.split(l11l1l_l1_ (u"ࠪ࠳ࠬᇳ"))[-1].replace(l11l1l_l1_ (u"ࠫ࠲࠭ᇴ"),l11l1l_l1_ (u"ࠬࠦࠧᇵ"))
		l111l111_l1_ = re.findall(l11l1l_l1_ (u"࠭วๅฯ็ๆฮ࠳ࠨ࡝ࡦ࠮࠭ࠬᇶ"),l1llll1_l1_.split(l11l1l_l1_ (u"ࠧ࠰ࠩᇷ"))[-1],re.DOTALL)
		if l111l111_l1_: l111l111_l1_ = l111l111_l1_[0]
		else: l111l111_l1_ = l11l1l_l1_ (u"ࠨ࠲ࠪᇸ")
		l1111l11_l1_.append([l1llll1_l1_,title,l111l111_l1_])
	items = sorted(l1111l11_l1_, reverse=False, key=lambda key: int(key[2]))
	l111l1ll1_l1_ = str(items).count(l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰ࠲ࠫᇹ"))
	l111ll111_l1_ = str(items).count(l11l1l_l1_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩ࠴࠭ᇺ"))
	if l111l1ll1_l1_>1 and l111ll111_l1_>0 and l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭ᇻ") not in url:
		for l1llll1_l1_,title,l111l111_l1_ in items:
			if l11l1l_l1_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧᇼ") in l1llll1_l1_:
				#l1llll1_l1_ = QUOTE(l1llll1_l1_)
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇽ"),l1111l_l1_+title,l1llll1_l1_,203)
	else:
		for l1llll1_l1_,title,l111l111_l1_ in items:
			if l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩᇾ") not in l1llll1_l1_:
				#if l11l1l_l1_ (u"ࠨࠧࠪᇿ") not in l1llll1_l1_: l1llll1_l1_ = QUOTE(l1llll1_l1_)
				#else: l1llll1_l1_ = QUOTE(l1llll_l1_(l1llll1_l1_))
				#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_)
				title = l1llll_l1_(title)
				addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨሀ"),l1111l_l1_+title,l1llll1_l1_,202)
	return
def PLAY(url):
	#LOG_THIS(l11l1l_l1_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪሁ"),l11l1l_l1_ (u"ࠫࡊࡓࡁࡅࠢ࠴࠵࠶࠭ሂ"))
	l1lll1_l1_ = []
	parts = url.split(l11l1l_l1_ (u"ࠬ࠵ࠧሃ"))
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧሄ"),l11l1l_l1_ (u"ࠧࠨህ"),url,l11l1l_l1_ (u"ࠨࡒࡏࡅ࡞࠳࠱ࡴࡶࠪሆ"))
	#url = l1llll_l1_(QUOTE(url))
	hostname = l11l11_l1_
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ሇ"),url,l11l1l_l1_ (u"ࠪࠫለ"),headers,True,True,l11l1l_l1_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨሉ"))
	html = response.content#.encode(l11l1l_l1_ (u"ࠬࡻࡴࡧ࠺ࠪሊ"))
	id = re.findall(l11l1l_l1_ (u"࠭ࡰࡰࡵࡷࡍࡩࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧላ"),html,re.DOTALL)
	if not id: id = re.findall(l11l1l_l1_ (u"ࠧࡱࡱࡶࡸࡤ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠢࠨሌ"),html,re.DOTALL)
	if not id: id = re.findall(l11l1l_l1_ (u"ࠨࡲࡲࡷࡹ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪል"),html,re.DOTALL)
	if id: id = id[0]
	#else: DIALOG_OK(l11l1l_l1_ (u"ࠩࠪሎ"),l11l1l_l1_ (u"ࠪࠫሏ"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧሐ"),l11l1l_l1_ (u"ࠬ๐ัอ๋ࠣษึูวๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥࠦๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠩሑ"))
	#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሒ"),l11l1l_l1_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠶࠷࠱ࠨሓ"))
	if l11l1l_l1_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩሔ") in html:
		#parts = url.split(l11l1l_l1_ (u"ࠩ࠲ࠫሕ"))
		l111l1l_l1_ = url.replace(parts[3],l11l1l_l1_ (u"ࠪࡻࡦࡺࡣࡩࠩሖ"))
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨሗ"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭መ"),headers,True,True,l11l1l_l1_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪሙ"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠧࡶࡶࡩ࠼ࠬሚ"))
		l11111l11_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧማ"),l11ll111_l1_,re.DOTALL)
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡦ࡯ࡥࡩࡩࡪ࠽ࠣ࠰࠭ࡃ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠨࠣࡾࠩࡵࡺࡵࡴ࠼ࠫࠪሜ"),l11ll111_l1_,re.DOTALL)
		l11111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡷࡷࡩ࠽ࠧࡳࡸࡳࡹࡁࠨ࠯ࠬࡂ࠭ࠫࡷࡵࡰࡶ࠾࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧም"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡳ࠰࠮ࠫࡁࡶࡩࡷࡼࡥࡳࡡ࡬ࡱࡦ࡭ࡥࠣࡀ࡟ࡲ࠭࠴ࠪࡀࠫ࡟ࡲࠬሞ"),l11ll111_l1_)
		l1111111l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡹࡲࡤ࠿ࠩࡵࡺࡵࡴ࠼ࠪ࠱࠮ࡄ࠯ࠦࡲࡷࡲࡸࡀ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ሟ"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		l1111llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡦࡴࡹࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠨሠ"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
		items = l11111l11_l1_+l1l11ll_l1_+l11111l1l_l1_+l111111l1_l1_+l1111111l_l1_+l1111llll_l1_
		#LOG_THIS(l11l1l_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧሡ"),l11l1l_l1_ (u"ࠨࡇࡐࡅࡉࠦࡓࡕࡃࡕࡘ࡚ࠥࡉࡎࡋࡑࡋࠥ࠺࠴࠵ࠩሢ"))
		if not items:
			items = re.findall(l11l1l_l1_ (u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሣ"),l11ll111_l1_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l11l1l_l1_ (u"ࠪ࠲ࡵࡴࡧࠨሤ") in server: continue
			if l11l1l_l1_ (u"ࠫ࠳ࡰࡰࡨࠩሥ") in server: continue
			if l11l1l_l1_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬሦ") in server: continue
			l111ll11_l1_ = re.findall(l11l1l_l1_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧሧ"),title,re.DOTALL)
			if l111ll11_l1_:
				l111ll11_l1_ = l111ll11_l1_[0]
				if l111ll11_l1_ in title: title = title.replace(l111ll11_l1_+l11l1l_l1_ (u"ࠧࡱࠩረ"),l11l1l_l1_ (u"ࠨࠩሩ")).replace(l111ll11_l1_,l11l1l_l1_ (u"ࠩࠪሪ")).strip(l11l1l_l1_ (u"ࠪࠤࠬራ"))
				l111ll11_l1_ = l11l1l_l1_ (u"ࠫࡤࡥ࡟ࡠࠩሬ")+l111ll11_l1_
			else: l111ll11_l1_ = l11l1l_l1_ (u"ࠬ࠭ር")
			#LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ሮ"),l11l1l_l1_ (u"ࠧ࡜ࠩሯ")+str(id)+l11l1l_l1_ (u"ࠨ࡟ࠣࠤࡠ࠭ሰ")+str(hostname)+l11l1l_l1_ (u"ࠩࡠࠤࠥࡡࠧሱ")+str(title)+l11l1l_l1_ (u"ࠪࡡ࡛ࠥࠦࠨሲ")+str(l111ll11_l1_)+l11l1l_l1_ (u"ࠫࡢ࠭ሳ"))
			if server.isdigit():
				l1llll1_l1_ = hostname+l11l1l_l1_ (u"ࠬ࠵࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠨሴ")+id+l11l1l_l1_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪስ")+server+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨሶ")+title+l11l1l_l1_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩሷ")+l111ll11_l1_
			else:
				if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧሸ") not in server: server = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩሹ")+server
				l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬሺ"),title,re.DOTALL)
				if l111ll11_l1_: l111ll11_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪሻ")+l111ll11_l1_[0]
				else: l111ll11_l1_ = l11l1l_l1_ (u"࠭ࠧሼ")
				l1llll1_l1_ = server+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡺࡥࡹࡩࡨࠨሽ")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨሾ"),l11l1l_l1_ (u"ࠩ࡞ࠫሿ")+l111ll11_l1_+l11l1l_l1_ (u"ࠪࡡࠥࠦࠠࠡ࡝ࠪቀ")+title+l11l1l_l1_ (u"ࠫࡢ࠭ቁ"))
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪቂ"), l1lll1_l1_)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧቃ"),l11l1l_l1_ (u"ࠧࠨቄ"),l11l1l_l1_ (u"ࠨࡹࡤࡸࡨ࡮ࠠ࠲ࠩቅ"),	str(len(items)))
	if l11l1l_l1_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࡒࡴࡽࠧቆ") in html:
		l1l1l1ll1_l1_ = { l11l1l_l1_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩቇ"):l11l1l_l1_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫቈ") }
		l111l1l_l1_ = url+l11l1l_l1_ (u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠨ቉")
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪቊ"),l111l1l_l1_,l11l1l_l1_ (u"ࠧࠨቋ"),l1l1l1ll1_l1_,True,l11l1l_l1_ (u"ࠨࠩቌ"),l11l1l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ቍ"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨ቎"))
		#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ቏"),l11l1l_l1_ (u"ࠬ࠭ቐ"),l111l1l_l1_,l11ll111_l1_)
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲࡯ࡴࡦ࡯ࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧቑ"),l11ll111_l1_,re.DOTALL)
		for block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡱࡀࠫ࠲࠯ࡅࠩ࠽ࠩቒ"),block,re.DOTALL)
			for l1llll1_l1_,name,l111ll11_l1_ in items:
				l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩቓ")+name+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ቔ")+l11l1l_l1_ (u"ࠪࡣࡤࡥ࡟ࠨቕ")+l111ll11_l1_
				l1lll1_l1_.append(l1llll1_l1_)
	elif l11l1l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨቖ") in html:
		l1l1l1ll1_l1_ = { l11l1l_l1_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ቗"):l11l1l_l1_ (u"࠭ࠧቘ") , l11l1l_l1_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ቙"):l11l1l_l1_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩቚ") }
		l111l1l_l1_ = hostname + l11l1l_l1_ (u"ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡩࡵࡷ࡯࡮ࡲࡥࡩࡲࡩ࡯࡭ࡶࠪࡵࡵࡳࡵࡋࡧࡁࠬቛ")+id
		response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧቜ"),l111l1l_l1_,l11l1l_l1_ (u"ࠫࠬቝ"),l1l1l1ll1_l1_,True,True,l11l1l_l1_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ቞"))
		l11ll111_l1_ = response.content#.encode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ቟"))
		if l11l1l_l1_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡥࡸࡳࡹࠧበ") in l11ll111_l1_:
			l11111l1l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧቡ"),l11ll111_l1_,re.DOTALL)
			for l111ll1_l1_ in l11111l1l_l1_:
				if l11l1l_l1_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠩቢ") not in l111ll1_l1_ and l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨባ") in l111ll1_l1_:
					l111ll1_l1_ = l111ll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨቤ")
					l1lll1_l1_.append(l111ll1_l1_)
				elif l11l1l_l1_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬብ") in l111ll1_l1_:
					l111ll11_l1_ = l11l1l_l1_ (u"࠭ࠧቦ")
					response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫቧ"),l111ll1_l1_,l11l1l_l1_ (u"ࠨࠩቨ"),headers,True,True,l11l1l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠸ࡸ࡭࠭ቩ"))
					l1111l1l1_l1_ = response.content#.encode(l11l1l_l1_ (u"ࠪࡹࡹ࡬࠸ࠨቪ"))
					l111111_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠭ࡂࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁࠬ࠱࠲࠳࠭࠮ࠩቫ"),l1111l1l1_l1_,re.DOTALL)
					for l111l1lll_l1_ in l111111_l1_:
						l1111ll11_l1_ = l11l1l_l1_ (u"ࠬ࠭ቬ")
						l111111l1_l1_ = re.findall(l11l1l_l1_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾ࠨቭ"),l111l1lll_l1_,re.DOTALL)
						for l111l111l_l1_ in l111111l1_l1_:
							item = re.findall(l11l1l_l1_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨቮ"),l111l111l_l1_,re.DOTALL)
							if item:
								l111ll11_l1_ = l11l1l_l1_ (u"ࠨࡡࡢࡣࡤ࠭ቯ")+item[0]
								break
						for l111l111l_l1_ in reversed(l111111l1_l1_):
							item = re.findall(l11l1l_l1_ (u"ࠩ࡟ࡻࡡࡽࠫࠨተ"),l111l111l_l1_,re.DOTALL)
							if item:
								l1111ll11_l1_ = item[0]
								break
						l1111111l_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩቱ"),l111l1lll_l1_,re.DOTALL)
						for l1111lll1_l1_ in l1111111l_l1_:
							l1111lll1_l1_ = l1111lll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬቲ")+l1111ll11_l1_+l11l1l_l1_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩታ")+l111ll11_l1_
							l1lll1_l1_.append(l1111lll1_l1_)
			#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧቴ"),l11l1l_l1_ (u"ࠧࠨት"),l11l1l_l1_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵ࠬቶ"),	str(len(l1lll1_l1_))	)
		elif l11l1l_l1_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧቷ") in l11ll111_l1_:
			l11ll111_l1_ = l11ll111_l1_.replace(l11l1l_l1_ (u"ࠪࡀ࡭࠼ࠠࠨቸ"),l11l1l_l1_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨቹ"))+l11l1l_l1_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭ቺ")
			l11ll111_l1_ = l11ll111_l1_.replace(l11l1l_l1_ (u"࠭࠼ࡩ࠵ࠣࠫቻ"),l11l1l_l1_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫቼ"))+l11l1l_l1_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩች")
			#LOG_THIS(l11l1l_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩቾ"),l11ll111_l1_)
			#open(l11l1l_l1_ (u"ࠪࡷ࠿ࡢ࡜ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪቿ"),l11l1l_l1_ (u"ࠫࡼ࠭ኀ")).write(l11ll111_l1_)
			l111111ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ኁ"),l11ll111_l1_,re.DOTALL)
			if l111111ll_l1_:
				for l111l1lll_l1_ in l111111ll_l1_:
					if l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠬኂ") not in l111l1lll_l1_: continue
					#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨኃ"),l11l1l_l1_ (u"ࠨࠩኄ"),l11l1l_l1_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠤ࠶࠷࠱ࠨኅ"),	l111l1lll_l1_	)
					l111l11l1_l1_ = l11l1l_l1_ (u"ࠪࠫኆ")
					l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡲ࡯ࡸ࠯ࡰࡳࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪኇ"),l111l1lll_l1_,re.DOTALL)
					for l111l111l_l1_ in l111111l1_l1_:
						item = re.findall(l11l1l_l1_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ኈ"),l111l111l_l1_,re.DOTALL)
						if item:
							l111l11l1_l1_ = l11l1l_l1_ (u"࠭࡟ࡠࡡࡢࠫ኉")+item[0]
							break
					l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ኊ"),l111l1lll_l1_,re.DOTALL)
					if l111111l1_l1_:
						for l1111ll11_l1_,l1111ll1l_l1_ in l111111l1_l1_:
							l1111ll1l_l1_ = l1111ll1l_l1_+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩኋ")+l1111ll11_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ኌ")+l111l11l1_l1_
							l1lll1_l1_.append(l1111ll1l_l1_)
					else:
						l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪኍ"),l111l1lll_l1_,re.DOTALL)
						for l1111ll1l_l1_,l1111ll11_l1_ in l111111l1_l1_:
							l1111ll1l_l1_ = l1111ll1l_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭኎"))+l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭኏")+l1111ll11_l1_+l11l1l_l1_ (u"࠭࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪነ")+l111l11l1_l1_
							l1lll1_l1_.append(l1111ll1l_l1_)
			else:
				l111111l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫࡠࡼ࠱ࠩ࠽ࠩኑ"),l11ll111_l1_,re.DOTALL)
				for l1111ll1l_l1_,l1111ll11_l1_ in l111111l1_l1_:
					l1111ll1l_l1_ = l1111ll1l_l1_.strip(l11l1l_l1_ (u"ࠨࠢࠪኒ"))+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪና")+l1111ll11_l1_+l11l1l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧኔ")
					l1lll1_l1_.append(l1111ll1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩን"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫኖ"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"࠭ࠧኗ"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠧࠨኘ"): return
	search = search.replace(l11l1l_l1_ (u"ࠨࠢࠪኙ"),l11l1l_l1_ (u"ࠩ࠮ࠫኚ"))
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧኛ"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡧ࡬ࡻࠩኜ"),l11l1l_l1_ (u"ࠬ࠭ኝ"),headers,True,l11l1l_l1_ (u"࠭ࠧኞ"),l11l1l_l1_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ኟ"))
	html = response.content#.encode(l11l1l_l1_ (u"ࠨࡷࡷࡪ࠽࠭አ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡷࡪࡲࡥࡤࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧኡ"),html,re.DOTALL)
	if l1ll_l1_ and l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ኢ"),block,re.DOTALL)
		l111l11ll_l1_,l1111l1ll_l1_ = [],[]
		for category,title in items:
			#if title in [l11l1l_l1_ (u"ࠫึ๐วืหࠣ์๋ࠥีศำ฼๋ࠬኣ")]: continue
			l111l11ll_l1_.append(category)
			l1111l1ll_l1_.append(title)
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬኤ"), l1111l1ll_l1_)
		if l1l_l1_ == -1 : return
		category = l111l11ll_l1_[l1l_l1_]
	else: category = l11l1l_l1_ (u"࠭ࠧእ")
	url = l11l11_l1_ + l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡵࡀࠫኦ")+search+l11l1l_l1_ (u"ࠨࠨࡦࡥࡹ࡫ࡧࡰࡴࡼࡁࠬኧ")+category+l11l1l_l1_ (u"ࠩࠩࡴࡦ࡭ࡥ࠾࠳ࠪከ")
	l1lllll_l1_(url)
	return
def l1ll1l1l_l1_(url,filter):
	#filter = filter.replace(l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬኩ"),l11l1l_l1_ (u"ࠫࠬኪ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭ካ"),l11l1l_l1_ (u"࠭ࠧኬ"),filter,url)
	# for l11111lll_l1_ filter:		l1l111l1_l1_ = [l11l1l_l1_ (u"ࠧࡄࡣࡷࡩ࡬ࡵࡲࡺࡅ࡫ࡩࡨࡱࡂࡰࡺࠪክ"),l11l1l_l1_ (u"ࠨ࡛ࡨࡥࡷࡉࡨࡦࡥ࡮ࡆࡴࡾࠧኮ"),l11l1l_l1_ (u"ࠩࡊࡩࡳࡸࡥࡄࡪࡨࡧࡰࡈ࡯ࡹࠩኯ"),l11l1l_l1_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬኰ")]
	l1l111l1_l1_ = [l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭኱"),l11l1l_l1_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫኲ"),l11l1l_l1_ (u"࠭ࡧࡦࡰࡵࡩࠬኳ"),l11l1l_l1_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠨኴ")]
	if l11l1l_l1_ (u"ࠨࡁࠪኵ") in url: url = url.split(l11l1l_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭኶"))[0]
	type,filter = filter.split(l11l1l_l1_ (u"ࠪࡣࡤࡥࠧ኷"),1)
	if filter==l11l1l_l1_ (u"ࠫࠬኸ"): l1l11111_l1_,l11lllll_l1_ = l11l1l_l1_ (u"ࠬ࠭ኹ"),l11l1l_l1_ (u"࠭ࠧኺ")
	else: l1l11111_l1_,l11lllll_l1_ = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫኻ"))
	if type==l11l1l_l1_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬኼ"):
		if l1l111l1_l1_[0]+l11l1l_l1_ (u"ࠩࡀࠫኽ") not in l1l11111_l1_: category = l1l111l1_l1_[0]
		for i in range(len(l1l111l1_l1_[0:-1])):
			if l1l111l1_l1_[i]+l11l1l_l1_ (u"ࠪࡁࠬኾ") in l1l11111_l1_: category = l1l111l1_l1_[i+1]
		l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠫࠫ࠭኿")+category+l11l1l_l1_ (u"ࠬࡃ࠰ࠨዀ")
		l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"࠭ࠦࠨ዁")+category+l11l1l_l1_ (u"ࠧ࠾࠲ࠪዂ")
		l1l11l11_l1_ = l1l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠨࠨࠪዃ"))+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭ዄ")+l1l1l1l1_l1_.strip(l11l1l_l1_ (u"ࠪࠪࠬዅ"))
		l11lll11_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ዆"))
		l111l1l_l1_ = url+l11l1l_l1_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩ዇")+l11lll11_l1_
	elif type==l11l1l_l1_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧወ"):
		l11l1lll_l1_ = l11lll1l_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩዉ"))
		l11l1lll_l1_ = l1llll_l1_(l11l1lll_l1_)
		if l11lllll_l1_!=l11l1l_l1_ (u"ࠨࠩዊ"): l11lllll_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬዋ"))
		if l11lllll_l1_==l11l1l_l1_ (u"ࠪࠫዌ"): l111l1l_l1_ = url
		else: l111l1l_l1_ = url+l11l1l_l1_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨው")+l11lllll_l1_
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዎ"),l1111l_l1_+l11l1l_l1_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠡࠩዏ"),l111l1l_l1_,201)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዐ"),l1111l_l1_+l11l1l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨዑ")+l11l1lll_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨዒ"),l111l1l_l1_,201)
		addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨዓ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫዔ"),l11l1l_l1_ (u"ࠬ࠭ዕ"),9999)
	html = OPENURL_CACHED(l1llll11_l1_,url+l11l1l_l1_ (u"࠭࠯ࡢ࡮ࡽࠫዖ"),l11l1l_l1_ (u"ࠧࠨ዗"),headers,l11l1l_l1_ (u"ࠨࠩዘ"),l11l1l_l1_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧዙ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡅ࡯ࡧࡸࡇ࡫࡯ࡸࡪࡸࡩ࡯ࡩࡇࡥࡹࡧࠨ࠯ࠬࡂ࠭ࡋ࡯࡬ࡵࡧࡵ࡛ࡴࡸࡤࠨዚ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	# for l11111lll_l1_ filter:		l1ll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼ࡩ࠴ࠪዛ"),block,re.DOTALL)
	l1ll1l11_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡩࡧࡴࡢ࠯ࡩࡳࡷ࡚ࡡࡹ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽ࡪ࠵ࠫዜ"),block,re.DOTALL)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧዝ"),l11l1l_l1_ (u"ࠧࠨዞ"),l11l1l_l1_ (u"ࠨࠩዟ"),str(l1ll1l11_l1_))
	dict = {}
	for name,l1ll11l1_l1_,block in l1ll1l11_l1_:
		#name = name.replace(l11l1l_l1_ (u"ࠩ࠰࠱ࠬዠ"),l11l1l_l1_ (u"ࠪࠫዡ"))
		name = name.replace(l11l1l_l1_ (u"ࠫฬิส๋ษิࠤࠬዢ"),l11l1l_l1_ (u"ࠬ࠭ዣ"))
		name = name.replace(l11l1l_l1_ (u"࠭ำ็หࠣห้หๆหษฯࠫዤ"),l11l1l_l1_ (u"ࠧศๆึ๊ฮ࠭ዥ"))
		items = re.findall(l11l1l_l1_ (u"ࠨࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽ࠩዦ"),block,re.DOTALL)
		if l11l1l_l1_ (u"ࠩࡀࠫዧ") not in l111l1l_l1_: l111l1l_l1_ = url
		if type==l11l1l_l1_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧየ"):
			if category!=l1ll11l1_l1_: continue
			elif len(items)<=1:
				if l1ll11l1_l1_==l1l111l1_l1_[-1]: l1lllll_l1_(l111l1l_l1_)
				else: l1ll1l1l_l1_(l111l1l_l1_,l11l1l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫዩ")+l1l11l11_l1_)
				return
			else:
				if l1ll11l1_l1_==l1l111l1_l1_[-1]: addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬዪ"),l1111l_l1_+l11l1l_l1_ (u"࠭วๅฮ่๎฾ࠦࠧያ"),l111l1l_l1_,201)
				else: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧዬ"),l1111l_l1_+l11l1l_l1_ (u"ࠨษ็ะ๊๐ูࠡࠩይ"),l111l1l_l1_,205,l11l1l_l1_ (u"ࠩࠪዮ"),l11l1l_l1_ (u"ࠪࠫዯ"),l1l11l11_l1_)
		elif type==l11l1l_l1_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬደ"):
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠬࠬࠧዱ")+l1ll11l1_l1_+l11l1l_l1_ (u"࠭࠽࠱ࠩዲ")
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠧࠧࠩዳ")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠨ࠿࠳ࠫዴ")
			l1l11l11_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠩࡢࡣࡤ࠭ድ")+l1l1l1l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዶ"),l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭ዷ")+name,l111l1l_l1_,204,l11l1l_l1_ (u"ࠬ࠭ዸ"),l11l1l_l1_ (u"࠭ࠧዹ"),l1l11l11_l1_)		# +l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩዺ"))
		dict[l1ll11l1_l1_] = {}
		for value,option in items:
			option = option.replace(l11l1l_l1_ (u"ࠨ࡞ࡱࠫዻ"),l11l1l_l1_ (u"ࠩࠪዼ"))
			if option in l1l111_l1_: continue
			#if option==l11l1l_l1_ (u"ࠪห้้ไࠨዽ"): continue
			#option = l11l1l_l1_ (u"ࠫࡠ࠭ዾ")+option+l11l1l_l1_ (u"ࠬࡣࠧዿ")
			#if l11l1l_l1_ (u"࠭วๅๅ็ࠫጀ") in option: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨጁ"),l11l1l_l1_ (u"ࠨࠩጂ"),l11l1l_l1_ (u"ࠩࠪጃ"),l11l1l_l1_ (u"ࠪ࡟ࠬጄ")+str(option)+l11l1l_l1_ (u"ࠫࡢ࠭ጅ"))
			#if l11l1l_l1_ (u"ࠬࡼࡡ࡭ࡷࡨࠫጆ") not in value: value = option
			#else: value = re.findall(l11l1l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧጇ"),value,re.DOTALL)[0]
			dict[l1ll11l1_l1_][value] = option
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠧࠧࠩገ")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠨ࠿ࠪጉ")+option
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠩࠩࠫጊ")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠪࡁࠬጋ")+value
			l1ll111l_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨጌ")+l1l1l1l1_l1_
			title = option+l11l1l_l1_ (u"ࠬࠦ࠺ࠨግ")#+dict[l1ll11l1_l1_][l11l1l_l1_ (u"࠭࠰ࠨጎ")]
			title = option+l11l1l_l1_ (u"ࠧࠡ࠼ࠪጏ")+name
			if type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩጐ"): addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ጑"),l1111l_l1_+title,url,204,l11l1l_l1_ (u"ࠪࠫጒ"),l11l1l_l1_ (u"ࠫࠬጓ"),l1ll111l_l1_)		# +l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧጔ"))
			elif type==l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪጕ") and l1l111l1_l1_[-2]+l11l1l_l1_ (u"ࠧ࠾ࠩ጖") in l1l11111_l1_:
				l11lll11_l1_ = l11lll1l_l1_(l1l1l1l1_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ጗"))
				l111ll1_l1_ = url+l11l1l_l1_ (u"ࠩ࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄ࠭ጘ")+l11lll11_l1_
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪጙ"),l1111l_l1_+title,l111ll1_l1_,201)
			else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጚ"),l1111l_l1_+title,url,205,l11l1l_l1_ (u"ࠬ࠭ጛ"),l11l1l_l1_ (u"࠭ࠧጜ"),l1ll111l_l1_)
	return
def l11lll1l_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨጝ"),l11l1l_l1_ (u"ࠨࠩጞ"),filters,l11l1l_l1_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪጟ"))
	# mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬጠ")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ values
	# mode==l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧጡ")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ filters
	# mode==l11l1l_l1_ (u"ࠬࡧ࡬࡭ࠩጢ")					all filters (l11ll1l1_l1_ l1l1l111_l1_ filter)
	filters = filters.replace(l11l1l_l1_ (u"࠭࠽ࠧࠩጣ"),l11l1l_l1_ (u"ࠧ࠾࠲ࠩࠫጤ"))
	filters = filters.strip(l11l1l_l1_ (u"ࠨࠨࠪጥ"))
	l1l1111l_l1_ = {}
	if l11l1l_l1_ (u"ࠩࡀࠫጦ") in filters:
		items = filters.split(l11l1l_l1_ (u"ࠪࠪࠬጧ"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠫࡂ࠭ጨ"))
			l1l1111l_l1_[var] = value
	l1ll1111_l1_ = l11l1l_l1_ (u"ࠬ࠭ጩ")
	# for l11111lll_l1_ filter:		l1l1lll1_l1_ = [l11l1l_l1_ (u"࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩጪ"),l11l1l_l1_ (u"࡚ࠧࡧࡤࡶࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ጫ"),l11l1l_l1_ (u"ࠨࡉࡨࡲࡷ࡫ࡃࡩࡧࡦ࡯ࡇࡵࡸࠨጬ"),l11l1l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫጭ")]
	l1l1lll1_l1_ = [l11l1l_l1_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬጮ"),l11l1l_l1_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪጯ"),l11l1l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫጰ"),l11l1l_l1_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧጱ")]
	for key in l1l1lll1_l1_:
		if key in list(l1l1111l_l1_.keys()): value = l1l1111l_l1_[key]
		else: value = l11l1l_l1_ (u"ࠧ࠱ࠩጲ")
		if l11l1l_l1_ (u"ࠨࠧࠪጳ") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫጴ") and value!=l11l1l_l1_ (u"ࠪ࠴ࠬጵ"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠫࠥ࠱ࠠࠨጶ")+value
		elif mode==l11l1l_l1_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨጷ") and value!=l11l1l_l1_ (u"࠭࠰ࠨጸ"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠧࠧࠩጹ")+key+l11l1l_l1_ (u"ࠨ࠿ࠪጺ")+value
		elif mode==l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭ጻ"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠪࠪࠬጼ")+key+l11l1l_l1_ (u"ࠫࡂ࠭ጽ")+value
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠬࠦࠫࠡࠩጾ"))
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"࠭ࠦࠨጿ"))
	l1ll1111_l1_ = l1ll1111_l1_.replace(l11l1l_l1_ (u"ࠧ࠾࠲ࠪፀ"),l11l1l_l1_ (u"ࠨ࠿ࠪፁ"))
	l1ll1111_l1_ = l1ll1111_l1_.replace(l11l1l_l1_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠪፂ"),l11l1l_l1_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫፃ"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬፄ"),l11l1l_l1_ (u"ࠬ࠭ፅ"),filters,l11l1l_l1_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧፆ"))
	return l1ll1111_l1_
l11l1l_l1_ (u"ࠢࠣࠤࠍࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠎ࠷ࡳࡵࠢࡰࡩࡹ࡮࡯ࡥࠋࠌࠬࡺࡹࡥࡥࠢࡱࡳࡼࠦࡩ࡯ࠢࡺࡩࡧࡹࡩࡵࡧࠬࠎࡦࡪࡤࡪࡰࡪࠤ࡫࡯࡬ࡵࡧࡵࠤࡹࡵࠠࡴࡧࡤࡶࡨ࡮ࠊࡑࡑࡖࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠎࠎࡪࡡࡵࡣ࠽ࠍࡠ࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪ࠰ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡀࠉࡄࡱࡲ࡯࡮࡫࡛ࠠࠬࠢࡖࡊࡌ࠭ࡕࡑࡎࡉࡓࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠶ࡳࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠍࠎ࠮ࡵࡴࡧࡧࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡲࡷࡤࡰ࡮ࡺࡹ࠾࡙ࡈࡆ࠲ࡊࡌࠧࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠽࠳࠲࠵࠴ࠏࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠷ࡷࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲ࠰࠴࠳࠵࠾ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠺ࡋࠦ࠴࠳ࡆࡱࡻࡒࡢࡻࠍࠦࠧࠨፇ")
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
#
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠭䊌")
l1111l_l1_ = l11l1l_l1_ (u"࠭࡟ࡍࡕࡗࡣࠬ䊍")
l111ll1111l_l1_ = 5
l111l1l11ll_l1_ = 10
def MAIN(mode,url,text,l11lll1_l1_,l1ll1l1l1l1_l1_):
	try: l1l11l11l11_l1_ = str(l1ll1l1l1l1_l1_[l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊎")])
	except: l1l11l11l11_l1_ = l11l1l_l1_ (u"ࠨࠩ䊏")
	if   mode==160: results = MENU()
	elif mode==161: results = l111ll1lll1_l1_(text)
	elif mode==162: results = l111l111ll1_l1_(text,162)
	elif mode==163: results = l111l111ll1_l1_(text,163)
	elif mode==164: results = l111ll1ll11_l1_(text)
	elif mode==165: results = l111l1llll1_l1_(l1l11l11l11_l1_,text,l11lll1_l1_)
	elif mode==166: results = l111ll11l1l_l1_(url,text)
	elif mode==167: results = l1111lll111_l1_(url,text)
	elif mode==168: results = l1111l1l1ll_l1_(url,text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䊐"),l11l1l_l1_ (u"ࠪๆ๋๎วหࠢอ่ๆุ๊้่ࠣ฽ู๎วว์ฬࠫ䊑"),l11l1l_l1_ (u"ࠫࠬ䊒"),161,l11l1l_l1_ (u"ࠬ࠭䊓"),l11l1l_l1_ (u"࠭ࠧ䊔"),l11l1l_l1_ (u"ࠧࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䊕"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䊖"),l11l1l_l1_ (u"ࠩๅืู๊ࠦี๊สส๏࠭䊗"),l11l1l_l1_ (u"ࠪࠫ䊘"),162,l11l1l_l1_ (u"ࠫࠬ䊙"),l11l1l_l1_ (u"ࠬ࠭䊚"),l11l1l_l1_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䊛"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊜"),l11l1l_l1_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ䊝"),l11l1l_l1_ (u"ࠩࠪ䊞"),163,l11l1l_l1_ (u"ࠪࠫ䊟"),l11l1l_l1_ (u"ࠫࠬ䊠"),l11l1l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䊡"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊢"),l11l1l_l1_ (u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭䊣"),l11l1l_l1_ (u"ࠨࠩ䊤"),164,l11l1l_l1_ (u"ࠩࠪ䊥"),l11l1l_l1_ (u"ࠪࠫ䊦"),l11l1l_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䊧"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊨"),l11l1l_l1_ (u"࠭แ๋ัํ์์อสࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ䊩"),l11l1l_l1_ (u"ࠧࠨ䊪"),165,l11l1l_l1_ (u"ࠨࠩ䊫"),l11l1l_l1_ (u"ࠩࠪ䊬"),l11l1l_l1_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࡣࡗࡇࡎࡅࡑࡐࡣࠬ䊭"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䊮"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䊯"),l11l1l_l1_ (u"࠭ࠧ䊰"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䊱"),l11l1l_l1_ (u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ䊲"),l11l1l_l1_ (u"ࠩࠪ䊳"),163,l11l1l_l1_ (u"ࠪࠫ䊴"),l11l1l_l1_ (u"ࠫࠬ䊵"),l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࡣࡑࡏࡖࡆࡡࡢࡖࡆࡔࡄࡐࡏࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䊶"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䊷"),l11l1l_l1_ (u"ࠧโ์า๎ํํวหࠢࡐ࠷ู࡚ࠦี๊สส๏ฯࠧ䊸"),l11l1l_l1_ (u"ࠨࠩ䊹"),163,l11l1l_l1_ (u"ࠩࠪ䊺"),l11l1l_l1_ (u"ࠪࠫ䊻"),l11l1l_l1_ (u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䊼"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䊽"),l11l1l_l1_ (u"࠭โิ็ࠣๆ๋๎วหࠢࡐ࠷ู࡚ࠦี๊สส๏࠭䊾"),l11l1l_l1_ (u"ࠧࠨ䊿"),162,l11l1l_l1_ (u"ࠨࠩ䋀"),l11l1l_l1_ (u"ࠩࠪ䋁"),l11l1l_l1_ (u"ࠪࡣࡒ࠹ࡕࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䋂"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋃"),l11l1l_l1_ (u"่ࠬำๆࠢไ๎ิ๐่ࠡࡏ࠶࡙ࠥ฿ิ้ษษ๎ࠬ䋄"),l11l1l_l1_ (u"࠭ࠧ䋅"),162,l11l1l_l1_ (u"ࠧࠨ䋆"),l11l1l_l1_ (u"ࠨࠩ䋇"),l11l1l_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䋈"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋉"),l11l1l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣฬาัฺࠠึ๋หห๐ࠧ䋊"),l11l1l_l1_ (u"ࠬ࠭䋋"),164,l11l1l_l1_ (u"࠭ࠧ䋌"),l11l1l_l1_ (u"ࠧࠨ䋍"),l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䋎"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋏"),l11l1l_l1_ (u"ࠪๅ๏ี๊้้สฮࠥࡓ࠳ࡖࠢ฼ุํอฦ๋ห้๋ࠣࠦโิ็ࠪ䋐"),l11l1l_l1_ (u"ࠫࠬ䋑"),165,l11l1l_l1_ (u"ࠬ࠭䋒"),l11l1l_l1_ (u"࠭ࠧ䋓"),l11l1l_l1_ (u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䋔"))
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䋕"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䋖"),l11l1l_l1_ (u"ࠪࠫ䋗"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋘"),l11l1l_l1_ (u"่ࠬๆ้ษอࠤࡎࡖࡔࡗࠢ฼ุํอฦ๋หࠪ䋙"),l11l1l_l1_ (u"࠭ࠧ䋚"),163,l11l1l_l1_ (u"ࠧࠨ䋛"),l11l1l_l1_ (u"ࠨࠩ䋜"),l11l1l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡏࡍ࡛ࡋ࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䋝"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䋞"),l11l1l_l1_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ䋟"),l11l1l_l1_ (u"ࠬ࠭䋠"),163,l11l1l_l1_ (u"࠭ࠧ䋡"),l11l1l_l1_ (u"ࠧࠨ䋢"),l11l1l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䋣"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋤"),l11l1l_l1_ (u"ࠪๆุ๋ࠠใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํࠫ䋥"),l11l1l_l1_ (u"ࠫࠬ䋦"),162,l11l1l_l1_ (u"ࠬ࠭䋧"),l11l1l_l1_ (u"࠭ࠧ䋨"),l11l1l_l1_ (u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䋩"))
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䋪"),l11l1l_l1_ (u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪ䋫"),l11l1l_l1_ (u"ࠪࠫ䋬"),162,l11l1l_l1_ (u"ࠫࠬ䋭"),l11l1l_l1_ (u"ࠬ࠭䋮"),l11l1l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡖࡐࡆࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䋯"))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䋰"),l11l1l_l1_ (u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡสะฯࠥ฿ิ้ษษ๎ࠬ䋱"),l11l1l_l1_ (u"ࠩࠪ䋲"),164,l11l1l_l1_ (u"ࠪࠫ䋳"),l11l1l_l1_ (u"ࠫࠬ䋴"),l11l1l_l1_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࡤࡘࡁࡏࡆࡒࡑࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䋵"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䋶"),l11l1l_l1_ (u"ࠧโ์า๎ํํวหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ษࠡ็้ࠤ็ูๅࠨ䋷"),l11l1l_l1_ (u"ࠨࠩ䋸"),165,l11l1l_l1_ (u"ࠩࠪ䋹"),l11l1l_l1_ (u"ࠪࠫ䋺"),l11l1l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࡣࡗࡇࡎࡅࡑࡐࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䋻"))
	return
def l111ll1lll1_l1_(options):
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䋼"),l11l1l_l1_ (u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩ䋽"),l11l1l_l1_ (u"ࠧࠨ䋾"),161,l11l1l_l1_ (u"ࠨࠩ䋿"),l11l1l_l1_ (u"ࠩࠪ䌀"),l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡎࡌ࡚ࡊ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࠪ䌁"))
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ䌂"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䌃"),l11l1l_l1_ (u"࠭ࠧ䌄"),9999)
	l111l11llll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䌅"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤ࡞࡛ࡔࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䌆")+l11l1l_l1_ (u"ࠩๅ๊ํอสࠡ฻ิฬ๏ฯࠠๆ่ࠣ๎ํะ๊้สࠪ䌇"),l11l1l_l1_ (u"ࠪࠫ䌈"),147)
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䌉"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䌊")+l11l1l_l1_ (u"࠭โ็๊สฮࠥษฬ็สํอ๋ࠥๆࠡ์๋ฮ๏๎ศࠨ䌋"),l11l1l_l1_ (u"ࠧࠨ䌌"),148)
	#addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䌍"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡏࡆࡍࠢࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ䌎")+l11l1l_l1_ (u"ࠪๆ๋อษࠡฤํࠤๆ๐ไๆ่๊๋่ࠢࠥใ฻๊้ࠬ䌏"),l11l1l_l1_ (u"ࠫࠬ䌐"),28)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩࡷࡧࠪ䌑"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡐࡖࡋࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䌒")+l11l1l_l1_ (u"ࠧใ่สอࠥอไๆ฻สีๆࠦๅ็่ࠢ์็฿็ๆࠩ䌓"),l11l1l_l1_ (u"ࠨࠩ䌔"),41)
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡻ࡫ࠧ䌕"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡋࡘࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䌖")+l11l1l_l1_ (u"ࠫ็์วสࠢส่่๎หา่๊๋่ࠢࠥใ฻๊้ࠬ䌗"),l11l1l_l1_ (u"ࠬ࠭䌘"),135)
	import l1l11ll1ll1_l1_
	l1l11ll1ll1_l1_.ITEMS(l11l1l_l1_ (u"࠭࠰ࠨ䌙"),False)
	l1l11ll1ll1_l1_.ITEMS(l11l1l_l1_ (u"ࠧ࠲ࠩ䌚"),False)
	l1l11ll1ll1_l1_.ITEMS(l11l1l_l1_ (u"ࠨ࠴ࠪ䌛"),False)
	#l1l11ll1ll1_l1_.ITEMS(l11l1l_l1_ (u"ࠩ࠶ࠫ䌜"),False)
	if l11l1l_l1_ (u"ࠪࡣࡗࡇࡎࡅࡑࡐࡣࠬ䌝") in options:
		menuItemsLIST[:] = l111l11l11l_l1_(menuItemsLIST)
		if len(menuItemsLIST)>l111ll1111l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l111ll1111l_l1_)
	menuItemsLIST[:] = l111l11llll_l1_+menuItemsLIST
	return
def l111ll1ll11_l1_(options):
	options = options.replace(l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䌞"),l11l1l_l1_ (u"ࠬ࠭䌟")).replace(l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䌠"),l11l1l_l1_ (u"ࠧࠨ䌡"))
	headers = { l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ䌢") : l11l1l_l1_ (u"ࠩࠪ䌣") }
	url = l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩ䌤")
	payload = { l11l1l_l1_ (u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭䌥") : l11l1l_l1_ (u"ࠬ࠻࠰ࠨ䌦") }
	data = l1ll11ll1_l1_(payload)
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ䌧"),l11l1l_l1_ (u"ࠧࠨ䌨"),l11l1l_l1_ (u"ࠨࠩ䌩"),str(data))
	response = OPENURL_REQUESTS_CACHED(l1111ll1l11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭䌪"),url,data,headers,l11l1l_l1_ (u"ࠪࠫ䌫"),l11l1l_l1_ (u"ࠫࠬ䌬"),l11l1l_l1_ (u"ࠬࡘࡁࡏࡆࡒࡑࡘ࠳ࡒࡂࡐࡇࡓࡒࡥࡖࡊࡆࡈࡓࡘࡥࡆࡓࡑࡐࡣ࡜ࡕࡒࡅࡕ࠰࠵ࡸࡺࠧ䌭"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡩ࡬ࡦࡣࡵࡪ࡮ࡾࠢࠨ䌮"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ䌯"),block,re.DOTALL)
	l1111l1l111_l1_,l1111ll1ll1_l1_ = list(zip(*items))
	l111l1lll1l_l1_ = []
	l111ll1l1ll_l1_ = [l11l1l_l1_ (u"ࠨࠢࠪ䌰"),l11l1l_l1_ (u"ࠩࠥࠫ䌱"),l11l1l_l1_ (u"ࠪࡤࠬ䌲"),l11l1l_l1_ (u"ࠫ࠱࠭䌳"),l11l1l_l1_ (u"ࠬ࠴ࠧ䌴"),l11l1l_l1_ (u"࠭࠺ࠨ䌵"),l11l1l_l1_ (u"ࠧ࠼ࠩ䌶"),l11l1l_l1_ (u"ࠣࠩࠥ䌷"),l11l1l_l1_ (u"ࠩ࠰ࠫ䌸")]
	l111l11111l_l1_ = l1111ll1ll1_l1_+l1111l1l111_l1_
	for word in l111l11111l_l1_:
		if word in l1111ll1ll1_l1_: l111l1l1ll1_l1_ = 2
		if word in l1111l1l111_l1_: l111l1l1ll1_l1_ = 4
		l111ll1l111_l1_ = [i in word for i in l111ll1l1ll_l1_]
		if any(l111ll1l111_l1_):
			index = l111ll1l111_l1_.index(True)
			l1111llll11_l1_ = l111ll1l1ll_l1_[index]
			l111ll111ll_l1_ = l11l1l_l1_ (u"ࠪࠫ䌹")
			if word.count(l1111llll11_l1_)>1: l111ll11l11_l1_,l111ll111l1_l1_,l111ll111ll_l1_ = word.split(l1111llll11_l1_,2)
			else: l111ll11l11_l1_,l111ll111l1_l1_ = word.split(l1111llll11_l1_,1)
			if len(l111ll11l11_l1_)>l111l1l1ll1_l1_: l111l1lll1l_l1_.append(l111ll11l11_l1_.lower())
			if len(l111ll111l1_l1_)>l111l1l1ll1_l1_: l111l1lll1l_l1_.append(l111ll111l1_l1_.lower())
			if len(l111ll111ll_l1_)>l111l1l1ll1_l1_: l111l1lll1l_l1_.append(l111ll111ll_l1_.lower())
		elif len(word)>l111l1l1ll1_l1_: l111l1lll1l_l1_.append(word.lower())
	for i in range(9): random.shuffle(l111l1lll1l_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l111l1lll1l_l1_)),l111l1lll1l_l1_)
	l11l1l_l1_ (u"ࠦࠧࠨࠊࠊ࡮࡬ࡷࡹࠦ࠽ࠡ࡝ࠪ็้๋วหࠢ฼ุํอฦ๋หࠣ฽ึฮ๊สࠩ࠯่๊ࠫๅศฬࠣ฽ู๎วว์ฬࠤส์ใๅ์ี๎ฮ࠭࡝ࠋࠋࠦࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠵࠭ࠏࠏ࡬ࡪࡵࡷ࠵ࠥࡃࠠ࡜࡟ࠍࠍࡨࡵࡵ࡯ࡶࡶࠤࡂࠦ࡬ࡦࡰࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡩ࡯ࡶࡰࡷࡷ࠯࠻ࠩ࠻ࠢࡵࡥࡳࡪ࡯࡮࠰ࡶ࡬ࡺ࡬ࡦ࡭ࡧࠫࡰ࡮ࡹࡴ࠳ࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡲࡢࡰࡪࡩ࠭ࡲࡥ࡯ࡩࡷ࡬࠮ࡀࠠ࡭࡫ࡶࡸ࠶࠴ࡡࡱࡲࡨࡲࡩ࠮ࠧไๆ่อࠥ฿ิ้ษษ๎ฮࠦัใ็ࠣࠫ࠰ࡹࡴࡳࠪ࡬࠭࠮ࠐࠉࡸࡪ࡬ࡰࡪࠦࡔࡳࡷࡨ࠾ࠏࠏࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอีࠥอไๅ฼ฬ࠾ࠬ࠲ࠠ࡭࡫ࡶࡸ࠮ࠐࠉࠊࠥ࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࠌࠧࡪࡲࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࡂࡃ࠰࠻ࠢ࡯࡭ࡸࡺ࠲ࠡ࠿ࠣࡥࡷࡨࡌࡊࡕࡗࠎࠎࠏࠣࡦ࡮ࡶࡩ࠿ࠦ࡬ࡪࡵࡷ࠶ࠥࡃࠠࡦࡰࡪࡐࡎ࡙ࡔࠋࠋࠌࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽ࠡࡆࡌࡅࡑࡕࡇࡠࡕࡈࡐࡊࡉࡔࠩࠩสาฯืࠠไๆ่อ๊ࠥไษฯฮࠤ฾์็ศ࠼ࠪ࠰ࠥࡲࡩࡴࡶ࠴࠭ࠏࠏࠉࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦࠡ࠾ࠢ࠰࠵࠿ࠦࡢࡳࡧࡤ࡯ࠏࠏࠉࡦ࡮࡬ࡪࠥࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࡀࠤ࠲࠷࠺ࠡࡴࡨࡸࡺࡸ࡮ࠋࠋࡶࡩࡦࡸࡣࡩࠢࡀࠤࡱ࡯ࡳࡵ࠴࡞ࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࡣࠊࠊࠤࠥࠦ䌺")
	if l11l1l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䌻") in options:
		l111l11lll1_l1_ = l111l111111_l1_
	elif l11l1l_l1_ (u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭䌼") in options:
		l111l11lll1_l1_ = [l11l1l_l1_ (u"ࠧࡊࡒࡗ࡚ࠬ䌽")]
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠨࠩ䌾"),True): return
	elif l11l1l_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䌿") in options:
		l111l11lll1_l1_ = [l11l1l_l1_ (u"ࠪࡑ࠸࡛ࠧ䍀")]
		import l1l111l1l1l_l1_
		if not l1l111l1l1l_l1_.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠫࠬ䍁"),True): return
	count,l1111l1l11l_l1_ = 0,0
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䍂"),l11l1l_l1_ (u"࠭วๅสะฯࠥ฿ๆࠡ࠼ࠣ࡟ࠥࠦ࡝ࠨ䍃"),l11l1l_l1_ (u"ࠧࠨ䍄"),164,l11l1l_l1_ (u"ࠨࠩ䍅"),l11l1l_l1_ (u"ࠩࠪ䍆"),l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䍇")+options)
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䍈"),l11l1l_l1_ (u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬ䍉"),l11l1l_l1_ (u"࠭ࠧ䍊"),164,l11l1l_l1_ (u"ࠧࠨ䍋"),l11l1l_l1_ (u"ࠨࠩ䍌"),l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䍍")+options)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䍎"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䍏"),l11l1l_l1_ (u"ࠬ࠭䍐"),9999)
	l1111l11lll_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	l111ll1l1l1_l1_ = []
	for word in l111l1lll1l_l1_:
		l111ll111l1_l1_ = re.findall(l11l1l_l1_ (u"࡛࠭ࠡ࡞࠯ࡠࡀࡢ࠺࡝࠯࡟࠯ࡡࡃ࡜ࠣ࡞ࠪࡠࡠࡢ࡝࡝ࠪ࡟࠭ࡡࢁ࡜ࡾ࡞ࠤࡠࡅࡢࠣ࡝ࠦ࡟ࠩࡡࡤ࡜ࠧ࡞࠭ࡠࡤࡢ࠼࡝ࡀࡠࠫ䍑"),word,re.DOTALL)
		if l111ll111l1_l1_: word = word.split(l111ll111l1_l1_[0],1)[0]
		l111l1lll11_l1_ = word.replace(l11l1l_l1_ (u"ࠧ๒ࠩ䍒"),l11l1l_l1_ (u"ࠨࠩ䍓")).replace(l11l1l_l1_ (u"ࠩ๑ࠫ䍔"),l11l1l_l1_ (u"ࠪࠫ䍕")).replace(l11l1l_l1_ (u"ࠫ๐࠭䍖"),l11l1l_l1_ (u"ࠬ࠭䍗")).replace(l11l1l_l1_ (u"࠭๏ࠨ䍘"),l11l1l_l1_ (u"ࠧࠨ䍙")).replace(l11l1l_l1_ (u"ࠨ๎ࠪ䍚"),l11l1l_l1_ (u"ࠩࠪ䍛"))
		l111l1lll11_l1_ = l111l1lll11_l1_.replace(l11l1l_l1_ (u"ࠪ๔ࠬ䍜"),l11l1l_l1_ (u"ࠫࠬ䍝")).replace(l11l1l_l1_ (u"ࠬ๓ࠧ䍞"),l11l1l_l1_ (u"࠭ࠧ䍟")).replace(l11l1l_l1_ (u"ࠧ๓ࠩ䍠"),l11l1l_l1_ (u"ࠨࠩ䍡")).replace(l11l1l_l1_ (u"ࠩฏࠫ䍢"),l11l1l_l1_ (u"ࠪࠫ䍣")).replace(l11l1l_l1_ (u"ࠫๅ࠭䍤"),l11l1l_l1_ (u"ࠬ࠭䍥"))
		if l111l1lll11_l1_: l111ll1l1l1_l1_.append(l111l1lll11_l1_)
	#l1l_l1_ = DIALOG_SELECT(str(len(l111ll1l1l1_l1_)),l111ll1l1l1_l1_)
	l111l1ll11l_l1_ = []
	for l11l1l1ll1_l1_ in range(0,20):
		search = random.sample(l111ll1l1l1_l1_,1)[0]
		if search in l111l1ll11l_l1_: continue
		l111l1ll11l_l1_.append(search)
		l1l1llllll1_l1_ = random.sample(l111l11lll1_l1_,1)[0]
		LOG_THIS(l11l1l_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭䍦"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯࡚ࠣ࡮ࡪࡥࡰࠢࡖࡩࡦࡸࡣࡩࠢࠣࠤࡸ࡯ࡴࡦ࠼ࠪ䍧")+str(l1l1llllll1_l1_)+l11l1l_l1_ (u"ࠨࠢࠣࡷࡪࡧࡲࡤࡪ࠽ࠫ䍨")+search)
		#results = l111l111l1l_l1_(l11l1l_l1_ (u"ࠩࠪ䍩"),l11l1l_l1_ (u"ࠪࠫ䍪"),l11l1l_l1_ (u"ࠫࠬ䍫"),l1l1llllll1_l1_,l11l1l_l1_ (u"ࠬ࠭䍬"),l11l1l_l1_ (u"࠭ࠧ䍭"),search+l11l1l_l1_ (u"ࠧࡠࡐࡒࡈࡎࡇࡌࡐࡉࡖࡣࠬ䍮"),l11l1l_l1_ (u"ࠨࠩ䍯"),l11l1l_l1_ (u"ࠩࠪ䍰"))
		l1l1lll1l1l_l1_,l1l1lllll1l_l1_,l1ll11l11ll_l1_ = l1l1lll111l_l1_(l1l1llllll1_l1_)
		l1l1lllll1l_l1_(search+l11l1l_l1_ (u"ࠪࡣࡓࡕࡄࡊࡃࡏࡓࡌ࡙࡟ࠨ䍱"))
		if len(menuItemsLIST)>0: break
	search = search.replace(l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䍲"),l11l1l_l1_ (u"ࠬ࠭䍳"))
	l1111l11lll_l1_[0][1] = l11l1l_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䍴")+search+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่อำหࠡ฻้ࠤ࠿࡛ࠦࠡࠩ䍵")
	menuItemsLIST[:] = l111l11l11l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>l111ll1111l_l1_: menuItemsLIST[:] = random.sample(menuItemsLIST,l111ll1111l_l1_)
	menuItemsLIST[:] = l1111l11lll_l1_+menuItemsLIST
	#import l1lll1111ll_l1_
	#l1lll1111ll_l1_.SEARCH(search)
	return
def l111ll1l11l_l1_(l1l1llllll1_l1_):
	l1l1lll1l1l_l1_,l1l1lllll1l_l1_,l1ll11l11ll_l1_ = l1l1lll111l_l1_(l1l1llllll1_l1_)
	try:
		if l11l1l_l1_ (u"ࠨࡋࡉࡍࡑࡓࠧ䍶") in l1l1llllll1_l1_: l1l1lll1l1l_l1_(l1l1llllll1_l1_)
		else: l1l1lll1l1l_l1_()
		l111l1ll111_l1_ = False
	except: l111l1ll111_l1_ = True
	if l111l1ll111_l1_: l1llll1l_l1_(l1l1llllll1_l1_,l11l1l_l1_ (u"ࠩไุ้ࠦศ่าสࠤฬ๊ๅ้ไ฼ࠫ䍷"),time=2000)
	else: l1llll1l_l1_(l1l1llllll1_l1_,l11l1l_l1_ (u"ࠪฮ๊ࠦฬๅสࠣห้ษโิษ่ࠫ䍸"),time=2000)
	return l111l1ll111_l1_
def l1111l1lll1_l1_(l111l1l1l11_l1_=True):
	if not l111l1l1l11_l1_:
		global contentsDICT
		results = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠫࡩ࡯ࡣࡵࠩ䍹"),l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䍺"),l11l1l_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ䍻"))
		if results:
			contentsDICT = results
			return
	l1ll111111_l1_ = DIALOG_YESNO(l11l1l_l1_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧ䍼"),l11l1l_l1_ (u"ࠨࠩ䍽"),l11l1l_l1_ (u"ࠩࠪ䍾"),l11l1l_l1_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭䍿"),l11l1l_l1_ (u"้้๊ࠫࠡฬ่่หࠦ็ั้ࠣห้่วว็ฬࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ะฮฬาࠠฤ่ࠣ๎ๆำีࠡฮ่๎฾ࠦๅ้ษๅ฽ࠥอไโ์า๎ํࠦวๅฬํࠤๆ๐ࠠศๆหี๋อๅอࠢ็็๏๊ࠦิฬัีัࠦๅ็้สࠤๆ่ืࠡษ็ว็ูวๆࠢส่ึฬ๊ิ์ฬࠤ࠳ࠦหๆࠢํๆํ๋ࠠศๆหี๋อๅอࠢหาื์่ࠠา๊ࠤฬ๊รใีส้ࠥำส๊ࠢ็หࠥะอหษฯࠤศ์ࠠห็็ส์อࠠๆำฬࠤศิั๊ࠢ࠱ࠤ฾๋ไ๋ห้้ࠣฬࠠอ็ํ฽ࠥอไฤไึห๊ࠦสฮฬสะࠥ฿วะหࠣว็๊ࠠๆ่ࠣ࠷ࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮัู๋ࠡไสส๊ฯࠠศๆฦๆุอๅࠡษ็ฦ๋ࠦฟࠨ䎀"))
	if l1ll111111_l1_!=1: return
	l1111ll111l_l1_ = menuItemsLIST[:]
	l111l11ll11_l1_,l111l11l1l1_l1_ = 0,l11l1l_l1_ (u"ࠬ࠭䎁")
	for l1l1llllll1_l1_ in l111ll11lll_l1_:
		l111l1ll111_l1_ = l111ll1l11l_l1_(l1l1llllll1_l1_)
		if l111l1ll111_l1_:
			l111l11ll11_l1_ += 1
			l111l11l1l1_l1_ += l11l1l_l1_ (u"࠭ࠠࠨ䎂")+l1l1llllll1_l1_
			if l111l11ll11_l1_>=l111l1l11ll_l1_: break
	menuItemsLIST[:] = l1111ll111l_l1_
	if l111l11ll11_l1_>=l111l1l11ll_l1_: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䎃"),l11l1l_l1_ (u"ࠨࠩ䎄"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䎅"),l11l1l_l1_ (u"่ࠪิ๐ใࠡ็ื็้ฯࠠโ์ࠣࠫ䎆")+str(l111l11ll11_l1_)+l11l1l_l1_ (u"๋่ࠫࠥศไ฼ࠤ๊์ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱࠲ࠥ๎ำษส๊ห่ࠥฯࠡ์ๆ์ู๋ࠦะ็ࠣ์ั๎ฯࠡว้ฮึ์๊หࠢไ๎ࠥา็ศิๆࠤํํ๊࠻ࠩ䎇")+l111l11l1l1_l1_)
	else:
		WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ䎈"),l11l1l_l1_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ࡙ࠧ䎉"),contentsDICT,PERMANENT_CACHE)
		DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䎊"),l11l1l_l1_ (u"ࠨࠩ䎋"),l11l1l_l1_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ䎌"),l11l1l_l1_ (u"ࠪฮ๊ࠦฬๅสࠣะ๊๐ูࠡษ็ว็ูวๆࠢส่๊ะ่โำฬࠤๆ๐ࠠศๆหี๋อๅอࠩ䎍"))
	return
def l111l1111ll_l1_(l1l11l11l11_l1_,options):
	if l11l1l_l1_ (u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩ䎎") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠬࡲࡩࡴࡶࠪ䎏"),l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䎐"),l11l1l_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ䎑")+l1l11l11l11_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11l1l_l1_ (u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭䎒")
	import IPTV
	if l11l1l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䎓") in options and l11l1l_l1_ (u"ࠪࡣࡑࡏࡖࡆࡡࠪ䎔") not in options:
		try: IPTV.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䎕"),l11l1l_l1_ (u"ࠬ࠭䎖"),l11l1l_l1_ (u"࠭ࠧ䎗"),options+l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䎘"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䎙"),l11l1l_l1_ (u"ࠩࠪ䎚"),l11l1l_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䎛"),message)
		try: IPTV.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䎜"),l11l1l_l1_ (u"ࠬ࠭䎝"),l11l1l_l1_ (u"࠭ࠧ䎞"),options+l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䎟"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䎠"),l11l1l_l1_ (u"ࠩࠪ䎡"),l11l1l_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䎢"),message)
		try: IPTV.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䎣"),l11l1l_l1_ (u"ࠬ࠭䎤"),l11l1l_l1_ (u"࠭ࠧ䎥"),options+l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䎦"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ䎧"),l11l1l_l1_ (u"ࠩࠪ䎨"),l11l1l_l1_ (u"้ࠪํู่ࠡโࡌࡔ࡙࡜ࠠๅๆไ๎ิ๐่่ษอࠫ䎩"),message)
	if l11l1l_l1_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ䎪") in options and l11l1l_l1_ (u"ࠬࡥࡖࡐࡆࡢࠫ䎫") not in options:
		try: IPTV.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡍࡒࡐࡗࡓࡉࡉ࠭䎬"),l11l1l_l1_ (u"ࠧࠨ䎭"),l11l1l_l1_ (u"ࠨࠩ䎮"),options+l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䎯"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䎰"),l11l1l_l1_ (u"ࠫࠬ䎱"),l11l1l_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ䎲"),message)
		try: IPTV.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"࠭ࡌࡊࡘࡈࡣࡌࡘࡏࡖࡒࡈࡈࠬ䎳"),l11l1l_l1_ (u"ࠧࠨ䎴"),l11l1l_l1_ (u"ࠨࠩ䎵"),options+l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䎶"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠪࠫ䎷"),l11l1l_l1_ (u"ࠫࠬ䎸"),l11l1l_l1_ (u"๋่ࠬใ฻ࠣไࡎࡖࡔࡗࠢ็่็์่ศฬࠪ䎹"),message)
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ䎺"),l11l1l_l1_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜࡟ࠨ䎻")+l1l11l11l11_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l111l1l111l_l1_(l1l11l11l11_l1_,options):
	if l11l1l_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䎼") not in options:
		results = READ_FROM_SQL3(main_dbfile,l11l1l_l1_ (u"ࠩ࡯࡭ࡸࡺࠧ䎽"),l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䎾"),l11l1l_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ䎿")+l1l11l11l11_l1_)
		if results: menuItemsLIST[:] = results ; return
	message = l11l1l_l1_ (u"๊ࠬไฤีไࠤ้ี๊ไุ่่๊ࠢษࠡใํࠤ์ึวࠡษ็้ํู่ࠡ࠰ࠣ์ึูวๅหࠣห้ิืฤࠢๆห๋ࠦแ๋้สࠤฯ็วึ์็ࠤฬ๊ๅีๅ็อࠥ࠴ࠠฤาสࠤฬ๊ๅีๅ็อ๊๊ࠥิฬࠣััฮࠠโฮิฬࠥหัิษ็ࠤ์ึ็ࠡษ็ู้้ไสࠢศ่๎ࠦวๅ็หี๊าࠠๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠪ䏀")
	import l1l111l1l1l_l1_
	if l11l1l_l1_ (u"࠭࡟ࡎ࠵ࡘࡣࠬ䏁") in options and l11l1l_l1_ (u"ࠧࡠࡎࡌ࡚ࡊࡥࠧ䏂") not in options:
		try: l1l111l1l1l_l1_.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧ䏃"),l11l1l_l1_ (u"ࠩࠪ䏄"),l11l1l_l1_ (u"ࠪࠫ䏅"),options+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䏆"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䏇"),l11l1l_l1_ (u"࠭ࠧ䏈"),l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䏉"),message)
		try: l1l111l1l1l_l1_.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䏊"),l11l1l_l1_ (u"ࠩࠪ䏋"),l11l1l_l1_ (u"ࠪࠫ䏌"),options+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䏍"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䏎"),l11l1l_l1_ (u"࠭ࠧ䏏"),l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䏐"),message)
		try: l1l111l1l1l_l1_.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉ࠭䏑"),l11l1l_l1_ (u"ࠩࠪ䏒"),l11l1l_l1_ (u"ࠪࠫ䏓"),options+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䏔"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭䏕"),l11l1l_l1_ (u"࠭ࠧ䏖"),l11l1l_l1_ (u"ࠧๆ๊ๅ฽ࠥๆࡍ࠴ࡗ่้ࠣ็๊ะ์๋๋ฬะࠧ䏗"),message)
	if l11l1l_l1_ (u"ࠨࡡࡐ࠷࡚ࡥࠧ䏘") in options and l11l1l_l1_ (u"ࠩࡢ࡚ࡔࡊ࡟ࠨ䏙") not in options:
		try: l1l111l1l1l_l1_.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࠪ䏚"),l11l1l_l1_ (u"ࠫࠬ䏛"),l11l1l_l1_ (u"ࠬ࠭䏜"),options+l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䏝"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䏞"),l11l1l_l1_ (u"ࠨࠩ䏟"),l11l1l_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭䏠"),message)
		try: l1l111l1l1l_l1_.GROUPS(l1l11l11l11_l1_,l11l1l_l1_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩ䏡"),l11l1l_l1_ (u"ࠫࠬ䏢"),l11l1l_l1_ (u"ࠬ࠭䏣"),options+l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䏤"),False)
		except: DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ䏥"),l11l1l_l1_ (u"ࠨࠩ䏦"),l11l1l_l1_ (u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭䏧"),message)
	WRITE_TO_SQL3(main_dbfile,l11l1l_l1_ (u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭䏨"),l11l1l_l1_ (u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡍ࠴ࡗࡢࠫ䏩")+l1l11l11l11_l1_,menuItemsLIST,PERMANENT_CACHE)
	return
def l111l1llll1_l1_(l1l11l11l11_l1_,options,l1111lll1ll_l1_):
	if l11l1l_l1_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤ࠭䏪") in options:
		if l11l1l_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䏫") in options and l1111lll1ll_l1_==l11l1l_l1_ (u"ࠧࠨ䏬"): l1111l1lll1_l1_(True)
		elif l1111lll1ll_l1_: l1111l1lll1_l1_(False)
		#if contentsDICT=={}: return
	l111l1l1l1l_l1_ = options.replace(l11l1l_l1_ (u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭䏭"),l11l1l_l1_ (u"ࠩࠪ䏮")).replace(l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䏯"),l11l1l_l1_ (u"ࠫࠬ䏰")).replace(l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䏱"),l11l1l_l1_ (u"࠭ࠧ䏲"))
	if not l1111lll1ll_l1_:
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䏳"),l11l1l_l1_ (u"ࠨฬะำ๏ั่ࠠา๊ࠤฬ๊โศศ่อࠬ䏴"),l11l1l_l1_ (u"ࠩࠪ䏵"),165,l11l1l_l1_ (u"ࠪࠫ䏶"),l11l1l_l1_ (u"ࠫࠬ䏷"),l11l1l_l1_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ䏸")+l111l1l1l1l_l1_,l11l1l_l1_ (u"࠭ࠧ䏹"),{l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䏺"):l1l11l11l11_l1_})
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䏻"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䏼"),l11l1l_l1_ (u"ࠪࠫ䏽"),9999)
	if l11l1l_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ䏾") in options:
		l1ll11l1l1_l1_ = [l11l1l_l1_ (u"ࠬษแๅษ่ࠫ䏿"),l11l1l_l1_ (u"࠭ๅิๆึ่ฬะࠧ䐀"),l11l1l_l1_ (u"ࠧๆีิั๏อสࠨ䐁"),l11l1l_l1_ (u"ࠨสิห๊าࠧ䐂"),l11l1l_l1_ (u"ࠩฦ฻ๆอไ๊ࠡๆีฯ๎ๆࠨ䐃"),l11l1l_l1_ (u"ࠪี๊฼ว็ࠩ䐄"),l11l1l_l1_ (u"ࠫศำฯฬ࠯ฦาึ࠭䐅"),l11l1l_l1_ (u"ูࠬไศี็ࠫ䐆"),l11l1l_l1_ (u"࠭ๅ้ีํๆ๎࠭䐇"),l11l1l_l1_ (u"ࠧฤึ๊ี࠲ษใฬำࠪ䐈"),l11l1l_l1_ (u"ࠨษ็ฦ๋࠭䐉"),l11l1l_l1_ (u"ูࠩั่࠭䐊"),l11l1l_l1_ (u"ࠪี๏อึสࠩ䐋"),l11l1l_l1_ (u"๋ࠫ๐สโๆๆืࠬ䐌"),l11l1l_l1_ (u"๋ࠬๅฬๆํ๊ࠬ䐍"),l11l1l_l1_ (u"࠭ศฬࠢะ๎ࠬ䐎"),l11l1l_l1_ (u"ࠧะ์้๎ฮ࠭䐏"),l11l1l_l1_ (u"ࠨี้์ฬะࠧ䐐"),l11l1l_l1_ (u"ࠩฦาึ๏ࠧ䐑")]
		l1111ll11l1_l1_ = [l11l1l_l1_ (u"ࠪหๆ๊วๆࠩ䐒"),l11l1l_l1_ (u"ࠫࡲࡵࡶࡪࡧࠪ䐓"),l11l1l_l1_ (u"ࠬ็๊ๅ็ࠪ䐔"),l11l1l_l1_ (u"࠭แๅ็ࠪ䐕")]
		l111ll11111_l1_ = [l11l1l_l1_ (u"ࠧๆี็ื้࠭䐖"),l11l1l_l1_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䐗")]
		l111ll1ll1l_l1_ = [l11l1l_l1_ (u"่ࠩืฬือࠨ䐘"),l11l1l_l1_ (u"ุ้ࠪือ๋ษอࠫ䐙")]
		l1111llll1l_l1_ = [l11l1l_l1_ (u"ࠫอืวๆฮࠪ䐚"),l11l1l_l1_ (u"ࠬࡹࡨࡰࡹࠪ䐛"),l11l1l_l1_ (u"࠭สๅใี๎ํ์ࠧ䐜"),l11l1l_l1_ (u"ࠧหๆํๅื๐่็ࠩ䐝")]
		l111l1ll1ll_l1_ = [l11l1l_l1_ (u"ࠨษ้้๏࠭䐞"),l11l1l_l1_ (u"ࠩๆีฯ๎ๆࠨ䐟"),l11l1l_l1_ (u"ࠪ็ฬืส้่ࠪ䐠"),l11l1l_l1_ (u"ࠫࡰ࡯ࡤࡴࠩ䐡"),l11l1l_l1_ (u"ࠬ฽แๅࠩ䐢"),l11l1l_l1_ (u"࠭วุใส่ࠬ䐣")]
		l11111ll_l1_ = [l11l1l_l1_ (u"ࠧา็ูห๋࠭䐤")]
		l1llll111_l1_ = [l11l1l_l1_ (u"ࠨษะำะ࠭䐥"),l11l1l_l1_ (u"ࠩสาึ࠭䐦"),l11l1l_l1_ (u"้ࠪํิัࠨ䐧"),l11l1l_l1_ (u"ࠫัี๊ะࠩ䐨"),l11l1l_l1_ (u"๋ࠬึศใࠪ䐩"),l11l1l_l1_ (u"࠭อะ์ฮࠫ䐪")]
		l111l111l11_l1_ = [l11l1l_l1_ (u"ࠧิๆสื้࠭䐫"),l11l1l_l1_ (u"ࠨี็ื้ํࠧ䐬")]
		l1111l1l1l1_l1_ = [l11l1l_l1_ (u"ࠩส฾ฬ์๊ࠨ䐭"),l11l1l_l1_ (u"้ࠪํู๊ใ๋ࠪ䐮"),l11l1l_l1_ (u"่๊๊ࠫษࠩ䐯"),l11l1l_l1_ (u"ࠬำแๅࠩ䐰"),l11l1l_l1_ (u"࠭࡭ࡶࡵ࡬ࡧࠬ䐱")]
		l1lllll1ll_l1_ = [l11l1l_l1_ (u"ࠧศๅฮีࠬ䐲"),l11l1l_l1_ (u"ࠨษื๋ึ࠭䐳"),l11l1l_l1_ (u"่้ࠩ๏ุ็ࠨ䐴"),l11l1l_l1_ (u"ࠪห฾๊้ࠨ䐵"),l11l1l_l1_ (u"๊ࠫิสศำ๊ࠫ䐶"),l11l1l_l1_ (u"๋ࠬฮหษิหฯ࠭䐷"),l11l1l_l1_ (u"࠭วใ๊์ࠫ䐸")]
		l1111l1llll_l1_ = [l11l1l_l1_ (u"ࠧศๆส๊ࠬ䐹"),l11l1l_l1_ (u"ࠨฯส่๏࠭䐺"),l11l1l_l1_ (u"่ࠩฯอะࠧ䐻"),l11l1l_l1_ (u"ࠪีฬฬฬࠨ䐼")]
		l1111l1ll1l_l1_ = [l11l1l_l1_ (u"ࠫ฻ำใࠨ䐽"),l11l1l_l1_ (u"้่ࠬๆ์า๎ࠬ䐾")]
		l1111ll11ll_l1_ = [l11l1l_l1_ (u"࠭ั๋ษู๋ࠬ䐿"),l11l1l_l1_ (u"ࠧไ๊ิ๋ࠬ䑀"),l11l1l_l1_ (u"ࠨ็ุหึ฿็ࠨ䑁"),l11l1l_l1_ (u"ࠩื์ฯ࠭䑂"),l11l1l_l1_ (u"ࠪี๏อึสࠩ䑃")]
		l111l1l1lll_l1_ = [l11l1l_l1_ (u"๋ࠫ๐สโๆๆืࠬ䑄"),l11l1l_l1_ (u"ࠬࡴࡥࡵࡨ࡯࡭ࡽ࠭䑅"),l11l1l_l1_ (u"࠭ๆ๋ฬไ่๏้ำࠨ䑆")]
		l1111lllll1_l1_ = [l11l1l_l1_ (u"ࠧๆ็ฮ่๏์ࠧ䑇"),l11l1l_l1_ (u"ࠨษืาฬ฻ࠧ䑈"),l11l1l_l1_ (u"้ࠩะํ๋ࠧ䑉")]
		l1l1ll111_l1_ = [l11l1l_l1_ (u"ࠪฬะࠦอ๋ࠩ䑊"),l11l1l_l1_ (u"ࠫࡱ࡯ࡶࡦࠩ䑋"),l11l1l_l1_ (u"่ࠬๆศ้ࠪ䑌"),l11l1l_l1_ (u"࠭โ็๊สฮࠬ䑍")]
		l111l1l11l1_l1_ = [l11l1l_l1_ (u"ࠧะ์้ࠫ䑎"),l11l1l_l1_ (u"ࠨษา฽๏ํࠧ䑏"),l11l1l_l1_ (u"ࠩี๎ฬืวหࠩ䑐"),l11l1l_l1_ (u"่ࠪ฼๋๊ศฬࠪ䑑"),l11l1l_l1_ (u"ࠫิ฿วยࠩ䑒"),l11l1l_l1_ (u"่ࠬัศ่ࠪ䑓"),l11l1l_l1_ (u"࠭โึษษำࠬ䑔"),l11l1l_l1_ (u"ࠧาอสลࠬ䑕"),l11l1l_l1_ (u"ࠨ็ิะ฾๐็ࠨ䑖"),l11l1l_l1_ (u"ࠩสิฬ์ࠧ䑗"),l11l1l_l1_ (u"ࠪหุ๊วๆࠩ䑘"),l11l1l_l1_ (u"ࠫฯ๎วี์ะࠫ䑙"),l11l1l_l1_ (u"ࠬิืษࠩ䑚"),l11l1l_l1_ (u"࠭อ้ิ๋๎ࠬ䑛"),l11l1l_l1_ (u"ฺࠧฬหหฯ࠭䑜"),l11l1l_l1_ (u"ࠨ็๋ห้๐ฯࠨ䑝"),l11l1l_l1_ (u"้ࠩ์ฬ฿๊ࠨ䑞"),l11l1l_l1_ (u"ࠪ฽็อฦะࠩ䑟"),l11l1l_l1_ (u"ࠫฬ์วี์าࠫ䑠")]
		l111l1lllll_l1_ = [l11l1l_l1_ (u"ࠬ࠷࠹ࠨ䑡"),l11l1l_l1_ (u"࠭࠲࠱ࠩ䑢"),l11l1l_l1_ (u"ࠧ࠳࠳ࠪ䑣"),l11l1l_l1_ (u"ࠨ࠴࠵ࠫ䑤"),l11l1l_l1_ (u"ࠩ࠵࠷ࠬ䑥"),l11l1l_l1_ (u"ࠪ࠶࠹࠭䑦"),l11l1l_l1_ (u"ࠫ࠷࠻ࠧ䑧"),l11l1l_l1_ (u"ࠬ࠸࠶ࠨ䑨")]
		if not l1111lll1ll_l1_:
			l1111lll1ll_l1_ = 0
			for l111l11ll1l_l1_ in l1ll11l1l1_l1_:
				l1111lll1ll_l1_ += 1
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䑩"),l1111l_l1_+l111l11ll1l_l1_,l11l1l_l1_ (u"ࠧࠨ䑪"),165,l11l1l_l1_ (u"ࠨࠩ䑫"),str(l1111lll1ll_l1_),l111l1l1l1l_l1_,l11l1l_l1_ (u"ࠩࠪ䑬"),{l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䑭"):l1l11l11l11_l1_})
		else:
			for name in sorted(list(contentsDICT.keys())):
				l1ll1ll1111_l1_ = name.lower()
				category = []
				if any(value in l1ll1ll1111_l1_ for value in l1111ll11l1_l1_): category.append(1)
				if any(value in l1ll1ll1111_l1_ for value in l111ll11111_l1_): category.append(2)
				if any(value in l1ll1ll1111_l1_ for value in l111ll1ll1l_l1_): category.append(3)
				if any(value in l1ll1ll1111_l1_ for value in l1111llll1l_l1_): category.append(4)
				if any(value in l1ll1ll1111_l1_ for value in l111l1ll1ll_l1_): category.append(5)
				if any(value in l1ll1ll1111_l1_ for value in l11111ll_l1_): category.append(6)
				if any(value in l1ll1ll1111_l1_ for value in l1llll111_l1_) and l1ll1ll1111_l1_ not in [l11l1l_l1_ (u"ࠫฬิั๊ࠩ䑮")]: category.append(7)
				if any(value in l1ll1ll1111_l1_ for value in l111l111l11_l1_): category.append(8)
				if any(value in l1ll1ll1111_l1_ for value in l1111l1l1l1_l1_): category.append(9)
				if any(value in l1ll1ll1111_l1_ for value in l1lllll1ll_l1_): category.append(10)
				if any(value in l1ll1ll1111_l1_ for value in l1111l1llll_l1_): category.append(11)
				if any(value in l1ll1ll1111_l1_ for value in l1111l1ll1l_l1_): category.append(12)
				if any(value in l1ll1ll1111_l1_ for value in l1111ll11ll_l1_): category.append(13)
				if any(value in l1ll1ll1111_l1_ for value in l111l1l1lll_l1_): category.append(14)
				if any(value in l1ll1ll1111_l1_ for value in l1111lllll1_l1_): category.append(15)
				if any(value in l1ll1ll1111_l1_ for value in l1l1ll111_l1_): category.append(16)
				if any(value in l1ll1ll1111_l1_ for value in l111l1l11l1_l1_): category.append(17)
				if any(value in l1ll1ll1111_l1_ for value in l111l1lllll_l1_): category.append(18)
				if not category: category = [19]
				for cat in category:
					if str(cat)==l1111lll1ll_l1_:
						addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䑯"),l1111l_l1_+name,name,166,l11l1l_l1_ (u"࠭ࠧ䑰"),l11l1l_l1_ (u"ࠧࠨ䑱"),l111l1l1l1l_l1_+l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䑲"))
	elif l11l1l_l1_ (u"ࠩࡢࡍࡕ࡚ࡖࡠࠩ䑳") in options:
		import IPTV
		#if l11l1l_l1_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ䑴") in options:
		l1111l1ll11_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1l11l11l11_l1_:
			if not IPTV.CHECK_TABLES_EXIST(l1l11l11l11_l1_,True): return
			l111l1111ll_l1_(l1l11l11l11_l1_,options)
		else:
			if not IPTV.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠫࠬ䑵"),True): return
			for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
				l111l1111ll_l1_(str(l1l11l11l11_l1_),options)
			#else: l1111l1ll11_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l1111l1ll11_l1_+menuItemsLIST[:]
	elif l11l1l_l1_ (u"ࠬࡥࡍ࠴ࡗࡢࠫ䑶") in options:
		import l1l111l1l1l_l1_
		#if l11l1l_l1_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ䑷") in options:
		l1111l1ll11_l1_ = menuItemsLIST[:]
		menuItemsLIST[:] = []
		if l1l11l11l11_l1_:
			if not l1l111l1l1l_l1_.CHECK_TABLES_EXIST(l1l11l11l11_l1_,True): return
			l111l1l111l_l1_(l1l11l11l11_l1_,options)
		else:
			if not l1l111l1l1l_l1_.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠧࠨ䑸"),True): return
			for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
				l111l1l111l_l1_(str(l1l11l11l11_l1_),options)
			#else: l1111l1ll11_l1_ = []
			menuItemsLIST[:] = sorted(menuItemsLIST,reverse=False,key=lambda key: key[1].lower())
		menuItemsLIST[:] = l1111l1ll11_l1_+menuItemsLIST[:]
	return
def l111ll11l1l_l1_(l1111lll1l1_l1_,options):
	l1111lll1l1_l1_ = l1111lll1l1_l1_.replace(l11l1l_l1_ (u"ࠨࡡࡐࡓࡉࡥࠧ䑹"),l11l1l_l1_ (u"ࠩࠪ䑺"))
	options = options.replace(l11l1l_l1_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䑻"),l11l1l_l1_ (u"ࠫࠬ䑼")).replace(l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䑽"),l11l1l_l1_ (u"࠭ࠧ䑾"))
	l1111l1lll1_l1_(False)
	if contentsDICT=={}: return
	if l11l1l_l1_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ䑿") in options:
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䒀"),l11l1l_l1_ (u"ࠩ࡞ࠤࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ䒁")+l1111lll1l1_l1_+l11l1l_l1_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥอไใี่ࠤ࠿࡛ࠦࠡࠩ䒂"),l1111lll1l1_l1_,166,l11l1l_l1_ (u"ࠫࠬ䒃"),l11l1l_l1_ (u"ࠬ࠭䒄"),l11l1l_l1_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䒅")+options)
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䒆"),l11l1l_l1_ (u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧ䒇"),l1111lll1l1_l1_,166,l11l1l_l1_ (u"ࠩࠪ䒈"),l11l1l_l1_ (u"ࠪࠫ䒉"),l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䒊")+options)
		addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ䒋"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䒌"),l11l1l_l1_ (u"ࠧࠨ䒍"),9999)
	for l1l11lll_l1_ in sorted(list(contentsDICT[l1111lll1l1_l1_].keys())):
		type,name,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_ = contentsDICT[l1111lll1l1_l1_][l1l11lll_l1_]
		if l11l1l_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䒎") in options or len(contentsDICT[l1111lll1l1_l1_])==1:
			l111l111l1l_l1_(type,l11l1l_l1_ (u"ࠩࠪ䒏"),url,l111l1ll1l1_l1_,l11l1l_l1_ (u"ࠪࠫ䒐"),l11lll1_l1_,text,l11l1l_l1_ (u"ࠫࠬ䒑"),l11l1l_l1_ (u"ࠬ࠭䒒"))
			menuItemsLIST[:] = l111l11l11l_l1_(menuItemsLIST)
			l1111l1ll11_l1_,l1lll1lll11_l1_ = menuItemsLIST[:3],menuItemsLIST[3:]
			for i in range(9): random.shuffle(l1lll1lll11_l1_)
			if l11l1l_l1_ (u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨ䒓") in options: menuItemsLIST[:] = l1111l1ll11_l1_+l1lll1lll11_l1_[:l111ll1111l_l1_]
			else: menuItemsLIST[:] = l1111l1ll11_l1_+l1lll1lll11_l1_
		elif l11l1l_l1_ (u"ࠧࡠࡕࡌࡘࡊ࡙࡟ࠨ䒔") in options: addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䒕"),l1l11lll_l1_,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_)
	return
def l111l111ll1_l1_(options,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ䒖"),l11l1l_l1_ (u"ࠪࠫ䒗"),str(mode),options)
	options = options.replace(l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭䒘"),l11l1l_l1_ (u"ࠬ࠭䒙")).replace(l11l1l_l1_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䒚"),l11l1l_l1_ (u"ࠧࠨ䒛"))
	name,l111l1111l1_l1_ = l11l1l_l1_ (u"ࠨࠩ䒜"),[]
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䒝"),l11l1l_l1_ (u"ࠪ࡟ࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ䒞")+name+l11l1l_l1_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢࠦวๅไึ้ࠥࡀࠠ࡜ࠢࠪ䒟"),l11l1l_l1_ (u"ࠬ࠭䒠"),mode,l11l1l_l1_ (u"࠭ࠧ䒡"),l11l1l_l1_ (u"ࠧࠨ䒢"),l11l1l_l1_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䒣")+options)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䒤"),l11l1l_l1_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโิ็ࠣ฽ู๎วว์ࠪ䒥"),l11l1l_l1_ (u"ࠫࠬ䒦"),mode,l11l1l_l1_ (u"ࠬ࠭䒧"),l11l1l_l1_ (u"࠭ࠧ䒨"),l11l1l_l1_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ䒩")+options)
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭䒪"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䒫"),l11l1l_l1_ (u"ࠪࠫ䒬"),9999)
	l1111l1ll11_l1_ = menuItemsLIST[:]
	menuItemsLIST[:] = []
	if l11l1l_l1_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ䒭") in options:
		l1111l1lll1_l1_(False)
		if contentsDICT=={}: return
		l111l11l111_l1_ = list(contentsDICT.keys())
		l1111lll1l1_l1_ = random.sample(l111l11l111_l1_,1)[0]
		l111l1lll1l_l1_ = list(contentsDICT[l1111lll1l1_l1_].keys())
		l1l11lll_l1_ = random.sample(l111l1lll1l_l1_,1)[0]
		type,name,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_ = contentsDICT[l1111lll1l1_l1_][l1l11lll_l1_]
		LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䒮"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦࡷࡦࡤࡶ࡭ࡹ࡫࠺ࠡࠩ䒯")+l1l11lll_l1_+l11l1l_l1_ (u"ࠧࠡࠢࠣࡲࡦࡳࡥ࠻ࠢࠪ䒰")+name+l11l1l_l1_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ䒱")+url+l11l1l_l1_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ䒲")+str(l111l1ll1l1_l1_))
	elif l11l1l_l1_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ䒳") in options:
		import IPTV
		if not IPTV.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠫࠬ䒴"),True): return
		for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
			l111l1111ll_l1_(str(l1l11l11l11_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11l1l_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ䒵"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"࠭ࠠࠡࠢࡕࡥࡳࡪ࡯࡮ࠢࡆࡥࡹ࡫ࡧࡰࡴࡼࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭䒶")+name+l11l1l_l1_ (u"ࠧࠡࠢࠣࡹࡷࡲ࠺ࠡࠩ䒷")+url+l11l1l_l1_ (u"ࠨࠢࠣࠤࡲࡵࡤࡦ࠼ࠣࠫ䒸")+str(l111l1ll1l1_l1_))
	elif l11l1l_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䒹") in options:
		import l1l111l1l1l_l1_
		if not l1l111l1l1l_l1_.CHECK_TABLES_EXIST(l11l1l_l1_ (u"ࠪࠫ䒺"),True): return
		for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
			l111l1l111l_l1_(str(l1l11l11l11_l1_),options)
		if not menuItemsLIST: return
		type,name,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_ = random.sample(menuItemsLIST,1)[0]
		LOG_THIS(l11l1l_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䒻"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠬࠦࠠࠡࡔࡤࡲࡩࡵ࡭ࠡࡅࡤࡸࡪ࡭࡯ࡳࡻࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ䒼")+name+l11l1l_l1_ (u"࠭ࠠࠡࠢࡸࡶࡱࡀࠠࠨ䒽")+url+l11l1l_l1_ (u"ࠧࠡࠢࠣࡱࡴࡪࡥ࠻ࠢࠪ䒾")+str(l111l1ll1l1_l1_))
	l1111llllll_l1_ = name
	l111l11l1ll_l1_ = []
	for i in range(0,10):
		if i>0: LOG_THIS(l11l1l_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ䒿"),LOGGING(l1ll1_l1_)+l11l1l_l1_ (u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡱࡥࡲ࡫࠺ࠡࠩ䓀")+name+l11l1l_l1_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ䓁")+url+l11l1l_l1_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ䓂")+str(l111l1ll1l1_l1_))
		menuItemsLIST[:] = []
		if l111l1ll1l1_l1_==234 and l11l1l_l1_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䓃") in text: l111l1ll1l1_l1_ = 233
		if l111l1ll1l1_l1_==714 and l11l1l_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䓄") in text: l111l1ll1l1_l1_ = 713
		if l111l1ll1l1_l1_==144: l111l1ll1l1_l1_ = 291
		html = l111l111l1l_l1_(type,name,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_)
		#if l11l1l_l1_ (u"ࠧࡠࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࡣࠬ䓅") in html: l111l111ll1_l1_(options,mode)
		if l11l1l_l1_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࠨ䓆") in options and l111l1ll1l1_l1_==167: del menuItemsLIST[:3]
		if l11l1l_l1_ (u"ࠩࡢࡑ࠸࡛࡟ࠨ䓇") in options and l111l1ll1l1_l1_==168: del menuItemsLIST[:3]
		l111l1111l1_l1_[:] = l111l11l11l_l1_(menuItemsLIST)
		if l111l11l1ll_l1_ and l1111lll11l_l1_(l11l1l_l1_ (u"ࡸࠫา๊โสࠩ䓈")) in str(l111l1111l1_l1_) or l1111lll11l_l1_(l11l1l_l1_ (u"ࡹࠬำไใ้ࠪ䓉")) in str(l111l1111l1_l1_):
			name = l1111llllll_l1_
			l111l1111l1_l1_[:] = l111l11l1ll_l1_
			break
		l1111llllll_l1_ = name
		l111l11l1ll_l1_ = l111l1111l1_l1_[:]
		if str(l111l1111l1_l1_).count(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ䓊"))>0: break
		if str(l111l1111l1_l1_).count(l11l1l_l1_ (u"࠭࡬ࡪࡸࡨࠫ䓋"))>0: break
		if l111l1ll1l1_l1_==233: break	# iptv l1111lll_l1_ names l111l1l1111_l1_ of l11ll_l1_ name
		if l111l1ll1l1_l1_==713: break	# l1111ll1lll_l1_ l1111lll_l1_ names l111l1l1111_l1_ of l11ll_l1_ name
		if l111l1ll1l1_l1_==291: break	# l1ll1l1l1_l1_ l111ll11ll1_l1_ names l111l1l1111_l1_ of l1ll1l1l1_l1_ l111ll11ll1_l1_ contents
		if l111l1111l1_l1_: type,name,url,l111l1ll1l1_l1_,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_ = random.sample(l111l1111l1_l1_,1)[0]
	if not name: name = l11l1l_l1_ (u"ࠧ࠯࠰࠱࠲ࠬ䓌")
	elif name.count(l11l1l_l1_ (u"ࠨࡡࠪ䓍"))>1: name = name.split(l11l1l_l1_ (u"ࠩࡢࠫ䓎"),2)[2]
	name = name.replace(l11l1l_l1_ (u"࡙ࠪࡓࡑࡎࡐ࡙ࡑ࠾ࠥ࠭䓏"),l11l1l_l1_ (u"ࠫࠬ䓐"))#.replace(l11l1l_l1_ (u"ࠬ࠲ࡍࡐࡘࡌࡉࡘࡀࠠࠨ䓑"),l11l1l_l1_ (u"࠭ࠧ䓒")).replace(l11l1l_l1_ (u"ࠧ࠭ࡕࡈࡖࡎࡋࡓ࠻ࠢࠪ䓓"),l11l1l_l1_ (u"ࠨࠩ䓔")).replace(l11l1l_l1_ (u"ࠩ࠯ࡐࡎ࡜ࡅ࠻ࠢࠪ䓕"),l11l1l_l1_ (u"ࠪࠫ䓖"))
	name = name.replace(l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ䓗"),l11l1l_l1_ (u"ࠬ࠭䓘"))
	l1111l1ll11_l1_[0][1] = l11l1l_l1_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ䓙")+name+l11l1l_l1_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭䓚")
	for i in range(9): random.shuffle(l111l1111l1_l1_)
	if l11l1l_l1_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ䓛") in options: menuItemsLIST[:] = l1111l1ll11_l1_+l111l1111l1_l1_[:l111ll1111l_l1_]
	else: menuItemsLIST[:] = l1111l1ll11_l1_+l111l1111l1_l1_
	return
def l1111lll111_l1_(l11l11lllll_l1_,l11ll1llll1_l1_):
	l11ll1llll1_l1_ = l11ll1llll1_l1_.replace(l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䓜"),l11l1l_l1_ (u"ࠪࠫ䓝")).replace(l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䓞"),l11l1l_l1_ (u"ࠬ࠭䓟"))
	l111l111lll_l1_ = l11ll1llll1_l1_
	if l11l1l_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䓠") in l11ll1llll1_l1_:
		l111l111lll_l1_ = l11ll1llll1_l1_.split(l11l1l_l1_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ䓡"))[0]
		type = l11l1l_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ䓢")
	elif l11l1l_l1_ (u"࡙ࠩࡓࡉ࠭䓣") in l11l11lllll_l1_: type = l11l1l_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭䓤")
	elif l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࠩ䓥") in l11l11lllll_l1_: type = l11l1l_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭䓦")
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䓧"),l11l1l_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䓨")+type+l111l111lll_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ䓩"),l11l11lllll_l1_,167,l11l1l_l1_ (u"ࠩࠪ䓪"),l11l1l_l1_ (u"ࠪࠫ䓫"),l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䓬")+l11ll1llll1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䓭"),l11l1l_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䓮"),l11l11lllll_l1_,167,l11l1l_l1_ (u"ࠧࠨ䓯"),l11l1l_l1_ (u"ࠨࠩ䓰"),l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䓱")+l11ll1llll1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䓲"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䓳"),l11l1l_l1_ (u"ࠬ࠭䓴"),9999)
	import IPTV
	for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
		if l11l1l_l1_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䓵") in l11ll1llll1_l1_: IPTV.GROUPS(str(l1l11l11l11_l1_),l11l11lllll_l1_,l11ll1llll1_l1_,l11l1l_l1_ (u"ࠧࠨ䓶"),False)
		else: IPTV.ITEMS(str(l1l11l11l11_l1_),l11l11lllll_l1_,l11ll1llll1_l1_,l11l1l_l1_ (u"ࠨࠩ䓷"),False)
	menuItemsLIST[:] = l111l11l11l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l111ll1111l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l111ll1111l_l1_)
	return
def l1111l1l1ll_l1_(l11l11lllll_l1_,l11ll1llll1_l1_):
	l11ll1llll1_l1_ = l11ll1llll1_l1_.replace(l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ䓸"),l11l1l_l1_ (u"ࠪࠫ䓹")).replace(l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䓺"),l11l1l_l1_ (u"ࠬ࠭䓻"))
	l111l111lll_l1_ = l11ll1llll1_l1_
	if l11l1l_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䓼") in l11ll1llll1_l1_:
		l111l111lll_l1_ = l11ll1llll1_l1_.split(l11l1l_l1_ (u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ䓽"))[0]
		type = l11l1l_l1_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ䓾")
	elif l11l1l_l1_ (u"࡙ࠩࡓࡉ࠭䓿") in l11l11lllll_l1_: type = l11l1l_l1_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭䔀")
	elif l11l1l_l1_ (u"ࠫࡑࡏࡖࡆࠩ䔁") in l11l11lllll_l1_: type = l11l1l_l1_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭䔂")
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䔃"),l11l1l_l1_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ䔄")+type+l111l111lll_l1_+l11l1l_l1_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ䔅"),l11l11lllll_l1_,168,l11l1l_l1_ (u"ࠩࠪ䔆"),l11l1l_l1_ (u"ࠪࠫ䔇"),l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䔈")+l11ll1llll1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䔉"),l11l1l_l1_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ䔊"),l11l11lllll_l1_,168,l11l1l_l1_ (u"ࠧࠨ䔋"),l11l1l_l1_ (u"ࠨࠩ䔌"),l11l1l_l1_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ䔍")+l11ll1llll1_l1_)
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨ䔎"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䔏"),l11l1l_l1_ (u"ࠬ࠭䔐"),9999)
	import l1l111l1l1l_l1_
	for l1l11l11l11_l1_ in range(FOLDERS_COUNT):
		if l11l1l_l1_ (u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭䔑") in l11ll1llll1_l1_: l1l111l1l1l_l1_.GROUPS(str(l1l11l11l11_l1_),l11l11lllll_l1_,l11ll1llll1_l1_,l11l1l_l1_ (u"ࠧࠨ䔒"),False)
		else: l1l111l1l1l_l1_.ITEMS(str(l1l11l11l11_l1_),l11l11lllll_l1_,l11ll1llll1_l1_,l11l1l_l1_ (u"ࠨࠩ䔓"),False)
	menuItemsLIST[:] = l111l11l11l_l1_(menuItemsLIST)
	if len(menuItemsLIST)>(l111ll1111l_l1_+3): menuItemsLIST[:] = menuItemsLIST[:3]+random.sample(menuItemsLIST[3:],l111ll1111l_l1_)
	return
def l111l11l11l_l1_(menuItemsLIST):
	l111l1111l1_l1_ = []
	for type,name,url,mode,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_ in menuItemsLIST:
		if l11l1l_l1_ (u"ุࠩๅาฯࠧ䔔") in name or l11l1l_l1_ (u"ูࠪๆำ็ࠨ䔕") in name or l11l1l_l1_ (u"ࠫࡵࡧࡧࡦࠩ䔖") in name.lower(): continue
		l111l1111l1_l1_.append([type,name,url,mode,l111_l1_,l11lll1_l1_,text,l1111ll1l1l_l1_,l1ll1l1l1l1_l1_])
	return l111l1111l1_l1_
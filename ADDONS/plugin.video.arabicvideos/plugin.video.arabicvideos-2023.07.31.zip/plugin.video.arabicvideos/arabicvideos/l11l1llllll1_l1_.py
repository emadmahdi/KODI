# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ嘍")
l1111l_l1_ = l11l1l_l1_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ嘎")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭嘏"):None}
def MAIN(mode,url,text):
	if   mode==310: results = MENU()
	elif mode==311: results = l1lllll_l1_(url)
	elif mode==312: results = PLAY(url)
	elif mode==313: results = l11l1lllll1l_l1_(url)
	elif mode==314: results = l1llll111_l1_(text)
	elif mode==319: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘐"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ嘑"),l11l1l_l1_ (u"ࠬ࠭嘒"),319,l11l1l_l1_ (u"࠭ࠧ嘓"),l11l1l_l1_ (u"ࠧࠨ嘔"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ嘕"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嘖"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠨ嘗"),l11l1l_l1_ (u"ࠫࠬ嘘"),114,l11l11_l1_)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ嘙"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧ嘚"),l11l1l_l1_ (u"ࠧࠨ嘛"),l11l1l_l1_ (u"ࠨࠩ嘜"),l11l1l_l1_ (u"ࠩࠪ嘝"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ嘞"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣ࡯ࡨࡲࡺࡲࡩ࡯࡭ࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ嘟"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ嘠"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭嘡"),l11l1l_l1_ (u"ࠧࠨ嘢"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠨ࠾࡫࠹ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠵࠿ࠩ嘣"),html,re.DOTALL|re.IGNORECASE)
	for seq in range(len(items)):
		title = items[seq].strip(l11l1l_l1_ (u"ࠩࠣࠫ嘤"))
		addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嘥"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭嘦")+l1111l_l1_+title,l11l11_l1_,314,l11l1l_l1_ (u"ࠬ࠭嘧"),l11l1l_l1_ (u"࠭ࠧ嘨"),str(seq+1))
	addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嘩"),l1ll1_l1_+l11l1l_l1_ (u"ࠨࡡࡖࡇࡗࡏࡐࡕࡡࠪ嘪")+l1111l_l1_+l11l1l_l1_ (u"่ࠩๆฬ฽ูࠡึ๊ีࠬ嘫"),l11l11_l1_,314,l11l1l_l1_ (u"ࠪࠫ嘬"),l11l1l_l1_ (u"ࠫࠬ嘭"),l11l1l_l1_ (u"ࠬ࠶ࠧ嘮"))
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嘯"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嘰"),l11l1l_l1_ (u"ࠨࠩ嘱"),9999)
	items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡇࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡂ࠿ࠩ嘲"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ嘳")+l1llll1_l1_
		#title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭嘴"))
		#url = l11l11_l1_+l11l1l_l1_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡇ࡮ࡳࡡࡏࡱࡺ࠳ࡎࡴࡴࡦࡴࡩࡥࡨ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠮ࡱࡪࡳࠫ嘵")
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嘶"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ嘷")+l1111l_l1_+title,l1llll1_l1_,311)
	return html
def l1llll111_l1_(seq):
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ嘸"),l11l11_l1_,l11l1l_l1_ (u"ࠩࠪ嘹"),l11l1l_l1_ (u"ࠪࠫ嘺"),l11l1l_l1_ (u"ࠫࠬ嘻"),l11l1l_l1_ (u"ࠬ࠭嘼"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡏࡅ࡙ࡋࡓࡕ࠯࠴ࡷࡹ࠭嘽"))
	html = response.content
	if seq==l11l1l_l1_ (u"ࠧ࠱ࠩ嘾"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡢࡤ࡯ࡩࡃ࠭嘿"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ噀"),block,re.DOTALL)
		for l1llll1_l1_,name,title in items:
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ噁")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭噂"))
			name = name.strip(l11l1l_l1_ (u"ࠬࠦࠧ噃"))
			title = title+l11l1l_l1_ (u"࠭ࠠࠩࠩ噄")+name+l11l1l_l1_ (u"ࠧࠪࠩ噅")
			addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ噆"),l1111l_l1_+title,l1llll1_l1_,312)
	elif seq in [l11l1l_l1_ (u"ࠩ࠴ࠫ噇"),l11l1l_l1_ (u"ࠪ࠶ࠬ噈"),l11l1l_l1_ (u"ࠫ࠸࠭噉")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫ࠬ噊"),html,re.DOTALL)
		l11l1lllll11_l1_ = int(seq)-1
		block = l1l11l1_l1_[l11l1lllll11_l1_]
		if seq==l11l1l_l1_ (u"࠭࠱ࠨ噋"): items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ噌"),block,re.DOTALL)
		else: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ噍"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title,name in items:
			l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ噎")+l1ll1l_l1_
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ噏")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠫࠥ࠭噐"))
			name = name.strip(l11l1l_l1_ (u"ࠬࠦࠧ噑"))
			title = title+l11l1l_l1_ (u"࠭ࠠࠩࠩ噒")+name+l11l1l_l1_ (u"ࠧࠪࠩ噓")
			addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ噔"),l1111l_l1_+title,l1llll1_l1_,311,l1ll1l_l1_)
	elif seq in [l11l1l_l1_ (u"ࠩ࠷ࠫ噕"),l11l1l_l1_ (u"ࠪ࠹ࠬ噖"),l11l1l_l1_ (u"ࠫ࠻࠭噗")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠮࠼ࡩ࠷ࡁ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩ噘"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1l11l1_l1_[seq]
		items = re.findall(l11l1l_l1_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠮ࠫࡁ࠰ࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ噙"),block,re.DOTALL)
		for l1ll1l_l1_,l1llll1_l1_,l1l1l1l1lll_l1_,title,l1ll1ll1111_l1_ in items:
			l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ噚")+l1ll1l_l1_
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࠪ噛")+l1llll1_l1_
			title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ噜"))
			l1l1l1l1lll_l1_ = l1l1l1l1lll_l1_.strip(l11l1l_l1_ (u"ࠪࠤࠬ噝"))
			l1ll1ll1111_l1_ = l1ll1ll1111_l1_.strip(l11l1l_l1_ (u"ࠫࠥ࠭噞"))
			if l1l1l1l1lll_l1_: name = l1l1l1l1lll_l1_
			else: name = l1ll1ll1111_l1_
			title = title+l11l1l_l1_ (u"ࠬࠦࠨࠨ噟")+name+l11l1l_l1_ (u"࠭ࠩࠨ噠")
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭噡"),l1111l_l1_+title,l1llll1_l1_,312,l1ll1l_l1_)
	return
def l1lllll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ噢"),url,l11l1l_l1_ (u"ࠩࠪ噣"),l11l1l_l1_ (u"ࠪࠫ噤"),l11l1l_l1_ (u"ࠫࠬ噥"),l11l1l_l1_ (u"ࠬ࠭噦"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭噧"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡤࡲࡼ࠲࡮ࡥࡢࡦ࡬ࡲ࡬ࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡫ࡲ࡯ࡢࡶ࠰ࡶ࡮࡭ࡨࡵࠩ器"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	if l11l1l_l1_ (u"ࠨࡥࡤࡸࡸࡻ࡭࠮࡯ࡲࡦ࡮ࡲࡥࠨ噩") in block:
		items = re.findall(l11l1l_l1_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ噪"),block,re.DOTALL)
		if items:
			for l1ll1l_l1_,l1llll1_l1_,title,count in items:
				l1ll1l_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ噫")+l1ll1l_l1_
				l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴࠭噬")+l1llll1_l1_
				count = count.replace(l11l1l_l1_ (u"ࠬࠦวๅื๋ฮ๏ฯ࠺ࠡࠩ噭"),l11l1l_l1_ (u"࠭࠺ࠨ噮"))
				title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ噯"))
				title = title+l11l1l_l1_ (u"ࠨࠢࠫࠫ噰")+count+l11l1l_l1_ (u"ࠩࠬࠫ噱")
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ噲"),l1111l_l1_+title,l1llll1_l1_,311,l1ll1l_l1_)
	else:
		items = re.findall(l11l1l_l1_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿࠽ࡵࡳࡥࡳ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ噳"),block,re.DOTALL)
		for l1llll1_l1_,title,l11l1lllllll_l1_,l1l11l1ll_l1_ in items:
			if title==l11l1l_l1_ (u"ࠬ࠭噴") or l11l1lllllll_l1_==l11l1l_l1_ (u"࠭ࠧ噵"): continue
			l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ噶")+l1llll1_l1_
			title = title+l11l1l_l1_ (u"ࠨࠢࠫࠫ噷")+l1l11l1ll_l1_+l11l1l_l1_ (u"ࠩࠬࠫ噸")
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ噹"),l1111l_l1_+title,l1llll1_l1_,312)
	if not items: l1lll1l1_l1_(html)
	return
def l1lll1l1_l1_(html):
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬ噺"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡨ࡫࡬࡭ࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ噻"),block,re.DOTALL)
	for l1llll1_l1_,title,name,count,l1l11l1ll_l1_ in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࠨ噼")+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩ噽"))
		name = name.strip(l11l1l_l1_ (u"ࠨࠢࠪ噾"))
		title = title+l11l1l_l1_ (u"ࠩࠣࠬࠬ噿")+name+l11l1l_l1_ (u"ࠪ࠭ࠬ嚀")
		addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ嚁"),l1111l_l1_+title,l1llll1_l1_,312,l11l1l_l1_ (u"ࠬ࠭嚂"),l1l11l1ll_l1_)
	return
def l11l1lllll1l_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ嚃"),url,l11l1l_l1_ (u"ࠧࠨ嚄"),l11l1l_l1_ (u"ࠨࠩ嚅"),l11l1l_l1_ (u"ࠩࠪ嚆"),l11l1l_l1_ (u"ࠪࠫ嚇"),l11l1l_l1_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡔࡇࡄࡖࡈࡎ࡟ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ嚈"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡢࡰࡺ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡵ࠳࠱ࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡣࡱࡻ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭嚉"),html,re.DOTALL)
	if not l1l11l1_l1_:
		l1lllll_l1_(url)
		return
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ嚊"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		l1llll1_l1_ = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ嚋")+l1llll1_l1_
		title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ嚌"))
		if l11l1l_l1_ (u"ࠩ࠲ࡴࡱࡧࡹ࠮ࠩ嚍") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ嚎"),l1111l_l1_+title,l1llll1_l1_,312)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嚏"),l1111l_l1_+title,l1llll1_l1_,311)
	return
def PLAY(url):
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ嚐"),url,l11l1l_l1_ (u"࠭ࠧ嚑"),l11l1l_l1_ (u"ࠧࠨ嚒"),l11l1l_l1_ (u"ࠨࠩ嚓"),l11l1l_l1_ (u"ࠩࠪ嚔"),l11l1l_l1_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ嚕"))
	html = response.content
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嚖"),html,re.DOTALL)
	if not l1llll1_l1_: l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ嚗"),html,re.DOTALL)
	l1llll1_l1_ = l11l11_l1_+l1llll1_l1_[0]
	PLAY_VIDEO(l1llll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嚘"))
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ嚙"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ嚚"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ嚛"),l11l1l_l1_ (u"ࠪ࠯ࠬ嚜"))
	l11ll1ll111_l1_ = [l11l1l_l1_ (u"ࠫࠫࡺ࠽ࡢࠩ嚝"),l11l1l_l1_ (u"ࠬࠬࡴ࠾ࡥࠪ嚞"),l11l1l_l1_ (u"࠭ࠦࡵ࠿ࡶࠫ嚟")]
	if l1ll_l1_:
		l11llllll11_l1_ = [l11l1l_l1_ (u"ࠧใษิสࠬ嚠"),l11l1l_l1_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ嚡"),l11l1l_l1_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ嚢")]
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ࠳ࠠฤะอีࠥอไษฯฮࠫ嚣"), l11llllll11_l1_)
		if l1l_l1_ == -1: return
	elif l11l1l_l1_ (u"ࠫࡤ࡙ࡈࡊࡃ࡙ࡓࡎࡉࡅ࠮ࡒࡈࡖࡘࡕࡎࡔࡡࠪ嚤") in options: l1l_l1_ = 0
	elif l11l1l_l1_ (u"ࠬࡥࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡄࡐࡇ࡛ࡍࡔࡡࠪ嚥") in options: l1l_l1_ = 1
	elif l11l1l_l1_ (u"࠭࡟ࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡅ࡚ࡊࡉࡐࡕࡢࠫ嚦") in options: l1l_l1_ = 2
	else: return
	type = l11ll1ll111_l1_[l1l_l1_]
	url = l11l11_l1_+l11l1l_l1_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨ嚧")+search+type
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ嚨"),url,l11l1l_l1_ (u"ࠩࠪ嚩"),l11l1l_l1_ (u"ࠪࠫ嚪"),l11l1l_l1_ (u"ࠫࠬ嚫"),l11l1l_l1_ (u"ࠬ࠭嚬"),l11l1l_l1_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭嚭"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡪࡤࡲࡼ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠫ嚮"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		if l1l_l1_ in [0,1]:
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ嚯"),block,re.DOTALL)
			for l1llll1_l1_,l1ll1l_l1_,title,name in items:
				title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ嚰"))
				name = name.strip(l11l1l_l1_ (u"ࠪࠤࠬ嚱"))
				title = title+l11l1l_l1_ (u"ࠫࠥ࠮ࠧ嚲")+name+l11l1l_l1_ (u"ࠬ࠯ࠧ嚳")
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嚴"),l1111l_l1_+title,l1llll1_l1_,313,l1ll1l_l1_)
		elif l1l_l1_==2:
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠭嚵"),block,re.DOTALL)
			for l1llll1_l1_,title,name in items:
				title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ嚶"))
				name = name.strip(l11l1l_l1_ (u"ࠩࠣࠫ嚷"))
				title = title+l11l1l_l1_ (u"ࠪࠤ࠭࠭嚸")+name+l11l1l_l1_ (u"ࠫ࠮࠭嚹")
				addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ嚺"),l1111l_l1_+title,l1llll1_l1_,312)
	return
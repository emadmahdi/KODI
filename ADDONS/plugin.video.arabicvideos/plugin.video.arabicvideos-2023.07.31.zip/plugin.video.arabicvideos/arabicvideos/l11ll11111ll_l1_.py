# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪ啤")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡕࡋࡒࡤ࠭啥")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨไ้์ฬะࠠโุสส๏ฯࠧ啦"),l11l1l_l1_ (u"ࠩไหึูใ้ࠩ啧"),l11l1l_l1_ (u"ࠪࡗ࡭ࡵࡷࠡ࡯ࡲࡶࡪ࠭啨")]
def MAIN(mode,url,text):
	if   mode==580: results = MENU()
	elif mode==581: results = l1lllll_l1_(url,text)
	elif mode==582: results = PLAY(url)
	elif mode==583: results = l1lll1l1_l1_(url,text)
	elif mode==584: results = l11lll_l1_(url)
	elif mode==589: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ啩"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭啪"),l11l1l_l1_ (u"࠭ࠧ啫"),l11l1l_l1_ (u"ࠧࠨ啬"),l11l1l_l1_ (u"ࠨࠩ啭"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ啮"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ啯"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ啰"),l11l1l_l1_ (u"ࠬ࠭啱"),589,l11l1l_l1_ (u"࠭ࠧ啲"),l11l1l_l1_ (u"ࠧࠨ啳"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ啴"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ啵"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ啶"),l11l1l_l1_ (u"ࠫࠬ啷"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠯ࡲ࡫ࡴࠧࡄࠨ࠯ࠬࡂ࠭ࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡥ࡫ࡹ࡭ࡩ࡫ࡲࠣࠩ啸"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠧࡥࡴࡲࡴࡩࡵࡷ࡯࠯ࡰࡩࡳࡻࠧࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠦ啹"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠧࠨ啺"))
	items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭啻"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ啼"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ啽")+l1111l_l1_+title,l1llll1_l1_,584)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ啾"),url,l11l1l_l1_ (u"ࠬ࠭啿"),l11l1l_l1_ (u"࠭ࠧ喀"),l11l1l_l1_ (u"ࠧࠨ喁"),l11l1l_l1_ (u"ࠨࠩ喂"),l11l1l_l1_ (u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ喃"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡨࡧࡲࡦࡶࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ善"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠫࠧࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࠦࠬ喅"),l11l1l_l1_ (u"ࠬࡂ࠯ࡶ࡮ࡁࠫ喆"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡥࡴࡲࡴࡩࡵࡷ࡯࠯࡫ࡩࡦࡪࡥࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ喇"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"ࠧࠨ喈"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭喉"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ็ัำࠢฦ์ࠥ็ไหำࠣวํࠦสาฬํฬࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ喊"),l11l1l_l1_ (u"ࠪࠫ喋"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ喌"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠬࡀࠠࠨ喍")
			for l1llll1_l1_,title in items:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喎"),l1111l_l1_+title,l1llll1_l1_,581)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡰ࠱ࡨࡧࡴࡦࡩࡲࡶࡾ࠳ࡳࡶࡤࡦࡥࡹࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ喏"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ喐"),block,re.DOTALL)
		if len(items)<30:
			addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ喑"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ喒"),l11l1l_l1_ (u"ࠫࠬ喓"),9999)
			for l1llll1_l1_,title in items:
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喔"),l1111l_l1_+title,l1llll1_l1_,581)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"࠭ࠧ喕")):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ喖"),l11l1l_l1_ (u"ࠨࠩ喗"),request,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭喘"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ喙"),url,l11l1l_l1_ (u"ࠫࠬ喚"),l11l1l_l1_ (u"ࠬ࠭喛"),l11l1l_l1_ (u"࠭ࠧ喜"),l11l1l_l1_ (u"ࠧࠨ喝"),l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲࡚ࡉࡕࡎࡈࡗ࠲࠷ࡳࡵࠩ喞"))
	html = response.content
	items = []
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ喟"),html,re.DOTALL)
	if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡇࡲ࡯ࡤ࡭ࡶࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯ࠢࡵ࡫ࡷࡰࡪ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࠤࠪ喠"),html,re.DOTALL)
	if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡮ࡪ࠽ࠣࡲࡰ࠱࡬ࡸࡩࡥࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭喡"),html,re.DOTALL)
	if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࡳࡱ࠲ࡸࡥ࡭ࡣࡷࡩࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ喢"),html,re.DOTALL)
	if not l1l11l1_l1_: return
	block = l1l11l1_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"࠭ࡤࡢࡶࡤ࠱ࡪࡩࡨࡰ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ喣"),block,re.DOTALL)
	if not items: items = re.findall(l11l1l_l1_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ喤"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ࠨ็ืห์ีษࠨ喥"),l11l1l_l1_ (u"ࠩไ๎้๋ࠧ喦"),l11l1l_l1_ (u"ࠪห฿์๊สࠩ喧"),l11l1l_l1_ (u"่๊๊ࠫษࠩ喨"),l11l1l_l1_ (u"ࠬอูๅษ้ࠫ喩"),l11l1l_l1_ (u"࠭็ะษไࠫ喪"),l11l1l_l1_ (u"ࠧๆสสีฬฯࠧ喫"),l11l1l_l1_ (u"ࠨ฻ิฺࠬ喬"),l11l1l_l1_ (u"่๋ࠩึาว็ࠩ喭"),l11l1l_l1_ (u"ࠪห้ฮ่ๆࠩ單"),l11l1l_l1_ (u"ู๊ࠫัฮ์ฬࠫ喯")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠬ࠵ࠧ喰"))
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ喱") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ喲")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ喳"))
		if l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶࠧ喴") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ喵")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭営"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ喷"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ喸"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭喹"),l1111l_l1_+title,l1llll1_l1_,582,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠨษ็ั้่ษࠨ喺") in title:
			title = l11l1l_l1_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ喻") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ喼"),l1111l_l1_+title,l1llll1_l1_,583,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠫ࠴ࡳ࡯ࡷࡵࡨࡶ࡮࡫ࡳ࠰ࠩ喽") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ喾"),l1111l_l1_+title,l1llll1_l1_,581,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭喿"),l1111l_l1_+title,l1llll1_l1_,583,l1ll1l_l1_)
	if request not in [l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩ嗀"),l11l1l_l1_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࡢࡷࡪࡸࡩࡦࡵࠪ嗁")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ嗂"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ嗃"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠫࠨ࠭嗄"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ嗅")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ嗆"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗇"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ嗈")+title,l1llll1_l1_,581)
		l1lll1llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡶ࡬ࡴࡽ࡭ࡰࡴࡨࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ嗉"),html,re.DOTALL)
		if l1lll1llll_l1_:
			l1llll1_l1_ = l1lll1llll_l1_[0]
			addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ嗊"),l1111l_l1_+l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤฬ๊ๅำ์าࠫ嗋"),l1llll1_l1_,581)
	return
def l1lll1l1_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠬ࠭嗌"),l11l1l_l1_ (u"࠭ࠧ嗍"),l1l11_l1_,url)
	#LOG_THIS(l11l1l_l1_ (u"ࠧࠨ嗎"),l11l1l_l1_ (u"ࠨ࠳࠴࠵࠶ࠦࠠࠨ嗏")+url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭嗐"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ嗑"),url,l11l1l_l1_ (u"ࠫࠬ嗒"),l11l1l_l1_ (u"ࠬ࠭嗓"),l11l1l_l1_ (u"࠭ࠧ嗔"),l11l1l_l1_ (u"ࠧࠨ嗕"),l11l1l_l1_ (u"ࠨࡕࡋࡅࡍࡏࡄࡏࡇ࡚ࡗ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠳ࡰࡧࠫ嗖"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡱࡥࡻ࠳ࡳࡦࡣࡶࡳࡳࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ嗗"),html,re.DOTALL)
	#LOG_THIS(l11l1l_l1_ (u"ࠪࠫ嗘"),str(l1l11_l1_))
	#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ嗙"),str(l11llll_l1_))
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ嗚"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"࠭ࠣࠨ嗛"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嗜"),l1111l_l1_+title,url,583,l11l1l_l1_ (u"ࠨࠩ嗝"),l11l1l_l1_ (u"ࠩࠪ嗞"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡭ࡩࡃࠢࠨ嗟")+l1l11_l1_+l11l1l_l1_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ嗠"),html,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ嗡"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,title in items:
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࠨ嗢")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ嗣"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ嗤"),l1111l_l1_+title,l1llll1_l1_,582)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪ嗥"),block,re.DOTALL)
			for l1llll1_l1_,title,l1ll1l_l1_ in items:
				if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ嗦") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭嗧")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ嗨"))
				addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ嗩"),l1111l_l1_+title,l1llll1_l1_,582)
	return
def PLAY(url):
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ嗪"))
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ嗫"),url,l11l1l_l1_ (u"ࠩࠪ嗬"),l11l1l_l1_ (u"ࠪࠫ嗭"),l11l1l_l1_ (u"ࠫࠬ嗮"),l11l1l_l1_ (u"ࠬ࠭嗯"),l11l1l_l1_ (u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ嗰"))
	html = response.content
	# l1ll1ll_l1_ l11lll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡒ࡯ࡥࡾ࡫ࡲࡩࡱ࡯ࡨࡪࡸࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ嗱"),html,re.DOTALL)
	l1llll1_l1_ = l1llll1_l1_[0]
	if l1llll1_l1_ and l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭嗲") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ嗳")+l1llll1_l1_
	#//l1l1l1l111l_l1_.l11ll111111l_l1_.l11ll1111111_l1_/l11ll11111l1_l1_/?l11ll1111l1l_l1_&hash=2LPZitix2YHYsSAxID0__IGh0dHBzOi8vdi5hZmxhbS5uZXdzL2VtYmVkLWlncHNzYmZzMmF3bC5odG1sCtiz2YrYsdmB2LEgMiA9PiBodHRwczovL3cuYW5hbW92LmFydC9lbWJlZC1xZGxhZnB5ZnRob3AuaHRtbArYs9mK2LHZgdixIDMgPT4gaHR0cHM6Ly92aWRvYmEuY2MvZW1iZWQtM3RxOGRvazNmYXJpLmh0bWwK2LPZitix2YHYsSA0ID0__IGh0dHBzOi8vdmlkc3BlZWQuY2MvZW1iZWQtcDc4cWI4aHNuMjd0Lmh0bWwK2LPZitix2YHYsSA1ID0__IGh0dHBzOi8vb2sucnUvdmlkZW9lbWJlZC80OTI0NjE0MDUyNDc4P2F1dG9wbGF5PTE=
	hash = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪ࡬ࡦࡹࡨ࠾ࠩ嗴"))[1]
	parts = hash.split(l11l1l_l1_ (u"ࠫࡤࡥࠧ嗵"))
	l11ll1111l11_l1_ = []
	for part in parts:
		try:
			part = base64.b64decode(part+l11l1l_l1_ (u"ࠬࡃࠧ嗶"))
			if kodi_version>18.99: part = part.decode(l11l1l_l1_ (u"࠭ࡵࡵࡨ࠻ࠫ嗷"))
			l11ll1111l11_l1_.append(part)
		except: pass
	l1l1_l1_ = l11l1l_l1_ (u"ࠧ࠿ࠩ嗸").join(l11ll1111l11_l1_)
	l1l1_l1_ = l1l1_l1_.splitlines()
	#LOG_THIS(l11l1l_l1_ (u"ࠨࠩ嗹"),str(l1l1_l1_))
	if l11l1l_l1_ (u"ࠩࡩࡥࡷࡹ࡯࡭ࠩ嗺") not in str(l1l1_l1_):
		for l1llll1_l1_ in l1l1_l1_:
			title,l1llll1_l1_ = l1llll1_l1_.split(l11l1l_l1_ (u"ࠪࠤࡂࡄࠠࠨ嗻"))
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ嗼")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭嗽")
			l1lll1_l1_.append(l1llll1_l1_)
		#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"࠭รฯฬิࠤฬ๊ศฮอࠣห้๋ๆศีหࠫ嗾"),l1lll1_l1_)
		import ll_l1_
		ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭嗿"),url)
	else:
		title,l1llll1_l1_ = l1l1_l1_[0].split(l11l1l_l1_ (u"ࠨࠢࡀࡂࠥ࠭嘀"))
		DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ嘁"),l11l1l_l1_ (u"ࠪࠫ嘂"),l11l1l_l1_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ嘃"),l11l1l_l1_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫ嘄")+l11l1l_l1_ (u"࠭࡜࡯ࠩ嘅")+l11l1l_l1_ (u"๋ࠧำฯํࠥอไๆฯส์้ฯࠠๅษะๆฬ࠭嘆")+l11l1l_l1_ (u"ࠨ࡞ࡱࡠࡳ࠭嘇")+title)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠩࠪ嘈"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠪࠫ嘉"): return
	search = search.replace(l11l1l_l1_ (u"ࠫࠥ࠭嘊"),l11l1l_l1_ (u"ࠬ࠱ࠧ嘋"))
	url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࡃࡰ࡫ࡹࡸࡱࡵࡨࡸࡃࠧ嘌")+search
	l1lllll_l1_(url)
	return
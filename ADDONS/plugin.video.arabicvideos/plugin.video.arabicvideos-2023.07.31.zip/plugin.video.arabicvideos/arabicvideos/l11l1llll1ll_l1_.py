# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡓࡉࡑࡉࡌࡆ࠭嚻")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡕࡋࡘࡤ࠭嚼")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ嚽"),l11l1l_l1_ (u"ࠩࡖ࡭࡬ࡴࠠࡪࡰࠪ嚾"),l11l1l_l1_ (u"ࠪวๆ๊วๆࠢ็่่ฮวาࠢไๆ฼࠭嚿")]
def MAIN(mode,url,text):
	if   mode==640: results = MENU()
	elif mode==641: results = l1lllll_l1_(url,text)
	elif mode==642: results = PLAY(url)
	elif mode==643: results = l1111_l1_(url,text)
	elif mode==644: results = l11lll_l1_(url)
	elif mode==649: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ囀"),l11l11_l1_,l11l1l_l1_ (u"ࠬ࠭囁"),l11l1l_l1_ (u"࠭ࠧ囂"),l11l1l_l1_ (u"ࠧࠨ囃"),l11l1l_l1_ (u"ࠨࠩ囄"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ囅"))
	html = response.content
	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ囆"),l1111l_l1_+l11l1l_l1_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ囇"),l11l1l_l1_ (u"ࠬ࠭囈"),649,l11l1l_l1_ (u"࠭ࠧ囉"),l11l1l_l1_ (u"ࠧࠨ囊"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ囋"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ囌"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ囍"),l11l1l_l1_ (u"ࠫࠬ囎"),9999)
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ囏"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ囐")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆ่้๏ุษࠨ囑"),l11l11_l1_,641,l11l1l_l1_ (u"ࠨࠩ囒"),l11l1l_l1_ (u"ࠩࠪ囓"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬ囔"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ囕"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ囖")+l1111l_l1_+l11l1l_l1_ (u"࠭ฬะ์าࠤฬ๊ๅ้ไ฼ࠫ囗"),l11l11_l1_,641,l11l1l_l1_ (u"ࠧࠨ囘"),l11l1l_l1_ (u"ࠨࠩ囙"),l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ囚"))
	#addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ四"),l1ll1_l1_+l11l1l_l1_ (u"ࠫࡤ࡙ࡃࡓࡋࡓࡘࡤ࠭囜")+l1111l_l1_+l11l1l_l1_ (u"ࠬาฯ๋ัࠣห้ษแๅษ่ࠫ囝"),l11l11_l1_,641,l11l1l_l1_ (u"࠭ࠧ回"),l11l1l_l1_ (u"ࠧࠨ囟"),l11l1l_l1_ (u"ࠨࡰࡨࡻࡤࡳ࡯ࡷ࡫ࡨࡷࠬ因"))
	#addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ囡"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ团")+l1111l_l1_+l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠨ団"),l11l11_l1_,641,l11l1l_l1_ (u"ࠬ࠭囤"),l11l1l_l1_ (u"࠭ࠧ囥"),l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡶࡩࡷ࡯ࡥࡴࠩ囦"))
	addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭囧"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ囨"),l11l1l_l1_ (u"ࠪࠫ囩"),9999)
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡴࡡࡷࡵ࡯࡭ࡩ࡫࠭ࡸࡴࡤࡴࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ囪"),html,re.DOTALL)
	#block = l1l11l1_l1_[0]
	#items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭囫"),block,re.DOTALL)
	#for l1llll1_l1_,title in items:
	#	if title in l1l111_l1_: continue
	#	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭囬"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩ园")+l1111l_l1_+title,l1llll1_l1_,644)
	#addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭囮"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ囯"),l11l1l_l1_ (u"ࠪࠫ困"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠮ࡱࡪࡳࠦࡃ࠮࠮ࠫࡁࠬࠦࡳࡧࡶࡴ࡮࡬ࡨࡪ࠳ࡤࡪࡸ࡬ࡨࡪࡸࠢࠨ囱"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠭ࡤࡳࡱࡳࡨࡴࡽ࡮࠮࡯ࡨࡲࡺ࠭ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠥ囲"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_: block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"࠭ࠧ図"))
	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ围"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ囵"),l1ll1_l1_+l11l1l_l1_ (u"ࠩࡢࡗࡈࡘࡉࡑࡖࡢࠫ囶")+l1111l_l1_+title,l1llll1_l1_,644)
	return
def l11lll_l1_(url):
	l11111l11_l1_ = []
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ囷"),url,l11l1l_l1_ (u"ࠫࠬ囸"),l11l1l_l1_ (u"ࠬ࠭囹"),l11l1l_l1_ (u"࠭ࠧ固"),l11l1l_l1_ (u"ࠧࠨ囻"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭囼"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭国"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		block = block.replace(l11l1l_l1_ (u"ࠪࠦࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠥࠫ图"),l11l1l_l1_ (u"ࠫࡁ࠵ࡵ࡭ࡀࠪ囿"))
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡤࡳࡱࡳࡨࡴࡽ࡮࠮ࡪࡨࡥࡩ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ圀"),block,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = [(l11l1l_l1_ (u"࠭ࠧ圁"),block)]
		addMenuItem(l11l1l_l1_ (u"ࠧ࡭࡫ࡱ࡯ࠬ圂"),l11l1l_l1_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠤๆืาࠡล๋ࠤๆ๊สาࠢฦ์ࠥะัห์หࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭圃"),l11l1l_l1_ (u"ࠩࠪ圄"),9999)
		for l111l1_l1_,block in l1l11l1_l1_:
			l11111l11_l1_ = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ圅"),block,re.DOTALL)
			if l111l1_l1_: l111l1_l1_ = l111l1_l1_+l11l1l_l1_ (u"ࠫ࠿ࠦࠧ圆")
			for l1llll1_l1_,title in l11111l11_l1_:
				title = l111l1_l1_+title
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ圇"),l1111l_l1_+title,l1llll1_l1_,641)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱ࡯࠰ࡧࡦࡺࡥࡨࡱࡵࡽ࠲ࡹࡵࡣࡥࡤࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ圈"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ圉"),block,re.DOTALL)
		if len(l1l11ll_l1_)<30:
			if l11111l11_l1_: addMenuItem(l11l1l_l1_ (u"ࠨ࡮࡬ࡲࡰ࠭圊"),l11l1l_l1_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥࡃ࠽࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ國"),l11l1l_l1_ (u"ࠪࠫ圌"),9999)
			for l1llll1_l1_,title in l1l11ll_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ圍"),l1111l_l1_+title,l1llll1_l1_,641)
	if not l1l1111_l1_ and not l11llll_l1_: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"ࠬ࠭圎")):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ圏"),l11l1l_l1_ (u"ࠧࠨ圐"),request,url)
	if request==l11l1l_l1_ (u"ࠨࡣ࡭ࡥࡽ࠳ࡳࡦࡣࡵࡧ࡭࠭圑"):
		url,search = url.split(l11l1l_l1_ (u"ࠩࡂࠫ園"),1)
		data = l11l1l_l1_ (u"ࠪࡵࡺ࡫ࡲࡺࡕࡷࡶ࡮ࡴࡧ࠾ࠩ圓")+search
		headers = {l11l1l_l1_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ圔"):l11l1l_l1_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ圕")}
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡐࡐࡕࡗࠫ圖"),url,data,headers,l11l1l_l1_ (u"ࠧࠨ圗"),l11l1l_l1_ (u"ࠨࠩ團"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭圙"))
	else:
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ圚"),url,l11l1l_l1_ (u"ࠫࠬ圛"),l11l1l_l1_ (u"ࠬ࠭圜"),l11l1l_l1_ (u"࠭ࠧ圝"),l11l1l_l1_ (u"ࠧࠨ圞"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠴ࡱࡨࠬ土"))
	html = response.content
	block,items = l11l1l_l1_ (u"ࠩࠪ圠"),[]
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ圡"))
	if request==l11l1l_l1_ (u"ࠫࡦࡰࡡࡹ࠯ࡶࡩࡦࡸࡣࡩࠩ圢"):
		block = html
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ圣"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"࠭ࠧ圤"),l1llll1_l1_,title))
	elif request==l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ圥"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡳࡱ࠲ࡼࡩࡥࡧࡲ࠱ࡼࡧࡴࡤࡪ࠰ࡪࡪࡧࡴࡶࡴࡨࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ圦"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ圧"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡷࡵࡷࠡࡲࡰ࠱ࡺࡲ࠭ࡣࡴࡲࡻࡸ࡫࠭ࡷ࡫ࡧࡩࡴࡹࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ在"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	elif request==l11l1l_l1_ (u"ࠫࡳ࡫ࡷࡠ࡯ࡲࡺ࡮࡫ࡳࠨ圩"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡲࡰࡹࠣࡴࡲ࠳ࡵ࡭࠯ࡥࡶࡴࡽࡳࡦ࠯ࡹ࡭ࡩ࡫࡯ࡴࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ圪"),html,re.DOTALL)
		if len(l1l11l1_l1_)>1: block = l1l11l1_l1_[1]
	elif request==l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ圫"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡪࡲࡱࡪ࠳ࡳࡦࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࡝࡟ࡸࢁࡢ࡮࡞ࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩ圬"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ圭"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l11l1l_l1_ (u"ࠩࠪ圮"),l1llll1_l1_,title))
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ圯"),html,re.DOTALL)
		if l1l11l1_l1_: block = l1l11l1_l1_[0]
	if block and not items: items = re.findall(l11l1l_l1_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡧ࡭ࡵ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭地"),block,re.DOTALL)
	if not items: return
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"๋ࠬิศ้าอࠬ圱"),l11l1l_l1_ (u"࠭แ๋ๆ่ࠫ圲"),l11l1l_l1_ (u"ࠧศ฼้๎ฮ࠭圳"),l11l1l_l1_ (u"ࠨๅ็๎อ࠭圴"),l11l1l_l1_ (u"ࠩส฽้อๆࠨ圵"),l11l1l_l1_ (u"๋ࠪิอแࠨ圶"),l11l1l_l1_ (u"๊ࠫฮวาษฬࠫ圷"),l11l1l_l1_ (u"ࠬ฿ัืࠩ圸"),l11l1l_l1_ (u"࠭ๅ่ำฯห๋࠭圹"),l11l1l_l1_ (u"ࠧศๆห์๊࠭场"),l11l1l_l1_ (u"ࠨ็ึีา๐ษࠨ圻")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		#l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ圼"))
		#if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ圽") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭圾")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ圿"))
		#if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ址") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ坁")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ坂"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ坃"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢࠫห้ำไใหࡿั้่ษࠪ࠰࡟ࡨ࠰࠭坄"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ坅"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
		elif request==l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ坆"):
			addMenuItem(l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ均"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
		elif l1ll11l_l1_:
			title = l11l1l_l1_ (u"ࠧࡠࡏࡒࡈࡤ࠭坈") + l1ll11l_l1_[0][0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ坉"),l1111l_l1_+title,l1llll1_l1_,643,l1ll1l_l1_)
				l11l_l1_.append(title)
		#elif l11l1l_l1_ (u"ࠩ࠲ࡱࡴࡼࡳࡦࡴ࡬ࡩࡸ࠵ࠧ坊") in l1llll1_l1_:
		#	addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ坋"),l1111l_l1_+title,l1llll1_l1_,641,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ坌"),l1111l_l1_+title,l1llll1_l1_,643,l1ll1l_l1_)
	if 1: #if request not in [l11l1l_l1_ (u"ࠬࡴࡥࡸࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ坍"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡵࡨࡶ࡮࡫ࡳࠨ坎")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ坏"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭坐"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠩࠦࠫ坑"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠪ࠳ࠬ坒")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠫ࠴࠭坓"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ坔"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬ坕")+title,l1llll1_l1_,641)
	return
def l1111_l1_(url,l1l11_l1_):
	#DIALOG_OK(l11l1l_l1_ (u"ࠧࠨ坖"),l11l1l_l1_ (u"ࠨࠩ块"),l1l11_l1_,url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭坘"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ坙"),url,l11l1l_l1_ (u"ࠫࠬ坚"),l11l1l_l1_ (u"ࠬ࠭坛"),l11l1l_l1_ (u"࠭ࠧ坜"),l11l1l_l1_ (u"ࠧࠨ坝"),l11l1l_l1_ (u"ࠨࡕࡋࡓࡋࡎࡁ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠶ࡳࡪࠧ坞"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡆࡴࡾࠢࠩ࠰࠭ࡃ࠮ࠨࡓࡦࡣࡶࡳࡳࡹࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡎࡣ࡬ࡲࠬ坟"),html,re.DOTALL)
	l111_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡸ࡫ࡲࡪࡧࡶ࠱࡭࡫ࡡࡥࡧࡵࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ坠"),html,re.DOTALL)
	if l111_l1_: l1ll1l_l1_ = l111_l1_[0]
	else: l1ll1l_l1_ = l11l1l_l1_ (u"ࠫࠬ坡")
	items = []
	# l1lll1l_l1_
	l111l_l1_ = False
	if l1l1111_l1_ and not l1l11_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡩࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ坢"),block,re.DOTALL)
		for l1l11_l1_,title in items:
			l1l11_l1_ = l1l11_l1_.strip(l11l1l_l1_ (u"࠭ࠣࠨ坣"))
			if len(items)>1: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ坤"),l1111l_l1_+title,url,643,l1ll1l_l1_,l11l1l_l1_ (u"ࠨࠩ坥"),l1l11_l1_)
			else: l111l_l1_ = True
	else: l111l_l1_ = True
	# l11ll_l1_
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡗࡪࡧࡳࡰࡰࡶࡉࡵ࡯ࡳࡰࡦࡨࡷࡒࡧࡩ࡯࠰࠭ࡃࡩࡧࡴࡢ࠯ࡶࡩࡷ࡯ࡥ࠾ࠤࠪ坦")+l1l11_l1_+l11l1l_l1_ (u"ࠪࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ坧"),html,re.DOTALL)
	if l11llll_l1_ and l111l_l1_:
		block = l11llll_l1_[0]
		l1l11ll_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡨࡱࡃ࠭坨"),block,re.DOTALL)
		items = []
		for l1llll1_l1_,title in l1l11ll_l1_: items.append((l1llll1_l1_,title,l1ll1l_l1_))
		#if not items: items = re.findall(l11l1l_l1_ (u"ࠬࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ坩"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࠨ坪")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ坫"))
			title = title.replace(l11l1l_l1_ (u"ࠨ࠾࠲ࡷࡵࡧ࡮࠿࠾ࡨࡱࡃ࠭坬"),l11l1l_l1_ (u"ࠩࠣࠫ坭"))
			addMenuItem(l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ坮"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
		#else:
		#	items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬ坯"),block,re.DOTALL)
		#	for l1llll1_l1_,title,l1ll1l_l1_ in items:
		#		if l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲࠪ坰") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"࠭࠯ࠨ坱")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠧ࠰ࠩ坲"))
		#		addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ坳"),l1111l_l1_+title,l1llll1_l1_,642,l1ll1l_l1_)
	return
def PLAY(url):
	l1lll1_l1_,l1l111ll1_l1_,l1lll11l_l1_ = [],[],[]
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠩ࠲ࡻࡦࡺࡣࡩ࠰ࡳ࡬ࡵ࠭坴"),l11l1l_l1_ (u"ࠪ࠳ࡻ࡯ࡥࡸ࠰ࡳ࡬ࡵ࠭坵"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨ坶"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭坷"),l11l1l_l1_ (u"࠭ࠧ坸"),l11l1l_l1_ (u"ࠧࠨ坹"),l11l1l_l1_ (u"ࠨࠩ坺"),l11l1l_l1_ (u"ࠩࡖࡌࡔࡌࡈࡂ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ坻"))
	html = response.content
	# l1l1111l1_l1_ l1llll1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡪࡳࡢࡦࡦࡧࡩࡩ࠳ࡶࡪࡦࡨࡳࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ坼"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ坽"),block,re.DOTALL)
		if l1l1_l1_:
			l1llll1_l1_ = l1l1_l1_[0]
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂࡥ࡟ࡦ࡯ࡥࡩࡩ࠭坾"))
				l1lll1_l1_.append(l1llll1_l1_)
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡘࡣࡷࡧ࡭࡙ࡥࡳࡸࡨࡶࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧ坿"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1llllll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢࡶࡶࡷࡳࡳࡄࠧ垀"),block,re.DOTALL)
		block = block.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠦࠬ垁"),l11l1l_l1_ (u"ࠩࠥࠫ垂")).replace(l11l1l_l1_ (u"ࠪࡠ࠴࠭垃"),l11l1l_l1_ (u"ࠫ࠴࠭垄"))
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨ࠼ࡪࡨࡵࡥࡲ࡫࠮ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ垅"),block,re.DOTALL)
		if len(l1llllll1l_l1_)==len(l1l1_l1_):
			for id,title in l1llllll1l_l1_:
				l1llll1_l1_ = l1l1_l1_[int(id)]
				if l1llll1_l1_ not in l1lll1_l1_:
					l1l111ll1_l1_.append(l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ垆")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ垇"))
					l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡗࡪࡸࡶࡦࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ垈"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l1l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ垉"),block,re.DOTALL)
		for l1llll1_l1_,title in l1l1_l1_:
			if l1llll1_l1_ not in l1lll1_l1_:
				l1l111ll1_l1_.append(l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ垊")+title+l11l1l_l1_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ型"))
				l1lll1_l1_.append(l1llll1_l1_)
	l11111_l1_ = zip(l1lll1_l1_,l1l111ll1_l1_)
	for l1llll1_l1_,name in l11111_l1_: l1lll11l_l1_.append(l1llll1_l1_+name)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ垌"),l1lll11l_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll11l_l1_,l1ll1_l1_,l11l1l_l1_ (u"࠭ࡶࡪࡦࡨࡳࠬ垍"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠧࠨ垎"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"ࠨࠩ垏"): return
	search = search.replace(l11l1l_l1_ (u"ࠩࠣࠫ垐"),l11l1l_l1_ (u"ࠪ࠯ࠬ垑"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁ࡮ࡩࡾࡽ࡯ࡳࡦࡶࡁࠬ垒")+search
	l1lllll_l1_(url,l11l1l_l1_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ垓"))
	#url = l11l11_l1_+l11l1l_l1_ (u"࠭࠯ࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࠪ垔")+search
	#l1lllll_l1_(url,l11l1l_l1_ (u"ࠧࡢ࡬ࡤࡼ࠲ࡹࡥࡢࡴࡦ࡬ࠬ垕"))
	return
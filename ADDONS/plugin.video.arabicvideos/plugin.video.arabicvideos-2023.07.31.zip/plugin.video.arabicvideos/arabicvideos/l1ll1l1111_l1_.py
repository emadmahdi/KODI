# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩᨣ")
l1111l_l1_ = l11l1l_l1_ (u"ࠧࡠࡅࡐࡐࡤ࠭ᨤ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"ࠨไ้์ฬะࠠโุสส๏ฯࠧᨥ")]
def MAIN(mode,url,text):
	if   mode==470: results = MENU()
	elif mode==471: results = l1lllll_l1_(url,text)
	elif mode==472: results = PLAY(url)
	elif mode==473: results = l1lll1l1_l1_(url,text)
	elif mode==474: results = l11lll_l1_(url)
	elif mode==479: results = SEARCH(text)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭ᨦ"),l11l11_l1_,l11l1l_l1_ (u"ࠪࠫᨧ"),l11l1l_l1_ (u"ࠫࠬᨨ"),l11l1l_l1_ (u"ࠬ࠭ᨩ"),l11l1l_l1_ (u"࠭ࠧᨪ"),l11l1l_l1_ (u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᨫ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩᨬ"),html,re.DOTALL)
	l1l1ll1_l1_ = l1l1ll1_l1_[0].strip(l11l1l_l1_ (u"ࠩ࠲ࠫᨭ"))
	l1l1ll1_l1_ = SERVER(l1l1ll1_l1_,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧᨮ"))
	addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᨯ"),l1111l_l1_+l11l1l_l1_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᨰ"),l11l1l_l1_ (u"࠭ࠧᨱ"),479,l11l1l_l1_ (u"ࠧࠨᨲ"),l11l1l_l1_ (u"ࠨࠩᨳ"),l11l1l_l1_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᨴ"))
	addMenuItem(l11l1l_l1_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨵ"),l11l1l_l1_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᨶ"),l11l1l_l1_ (u"ࠬ࠭ᨷ"),9999)
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨸ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᨹ")+l1111l_l1_+l11l1l_l1_ (u"ࠨลไ่ฬ๋ࠠๆ็ํึฮ࠭ᨺ"),l1l1ll1_l1_,471,l11l1l_l1_ (u"ࠩࠪᨻ"),l11l1l_l1_ (u"ࠪࠫᨼ"),l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭ᨽ"))
	addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᨾ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨᨿ")+l1111l_l1_+l11l1l_l1_ (u"ࠧๆี็ื้อสࠡ็่๎ืฯࠧᩀ"),l1l1ll1_l1_,471,l11l1l_l1_ (u"ࠨࠩᩁ"),l11l1l_l1_ (u"ࠩࠪᩂ"),l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᩃ"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡩ࡯࡯ࡶࡨࡲࡹࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᩄ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾ࠪᩅ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		title = title.strip(l11l1l_l1_ (u"࠭ࠠࠨᩆ"))
		#if title in l1l111_l1_: continue
		l1llll1_l1_ = l1llll1_l1_.replace(l11l1l_l1_ (u"ࠧࡤࡣࡷࡁࡴࡴ࡬ࡪࡰࡨ࠱ࡲࡵࡶࡪࡧࡶ࠵ࠬᩇ"),l11l1l_l1_ (u"ࠨࡥࡤࡸࡂࡵ࡮࡭࡫ࡱࡩ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬᩈ"))
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᩉ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᩊ")+l1111l_l1_+title,l1llll1_l1_,474)
	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩᩋ"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᩌ"),l11l1l_l1_ (u"࠭ࠧᩍ"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠢ࠿ࠪ࠱࠮ࡄ࠯ࠢ࡯ࡣࡹࡷࡱ࡯ࡤࡦ࠯ࡧ࡭ࡻ࡯ࡤࡦࡴࠥࠫᩎ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠣࠩࡧࡶࡴࡶࡤࡰࡹࡱ࠱ࡲ࡫࡮ࡶࠩࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃࠨᩏ"),html,re.DOTALL)
	for l1l1lll_l1_ in l1l11l1_l1_:
		block = block.replace(l1l1lll_l1_,l11l1l_l1_ (u"ࠩࠪᩐ"))
	items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᩑ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if title in l1l111_l1_: continue
		#l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࡫ࡸࡱ࡮ࡲࡶࡪ࠵࠿ࠨᩒ")+category+l11l1l_l1_ (u"ࠬࡃࠧᩓ")+value
		addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᩔ"),l1ll1_l1_+l11l1l_l1_ (u"ࠧࡠࡕࡆࡖࡎࡖࡔࡠࠩᩕ")+l1111l_l1_+title,l1llll1_l1_,474)
	return
def l11lll_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᩖ"),url,l11l1l_l1_ (u"ࠩࠪᩗ"),l11l1l_l1_ (u"ࠪࠫᩘ"),l11l1l_l1_ (u"ࠫࠬᩙ"),l11l1l_l1_ (u"ࠬ࠭ᩚ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᩛ"))
	html = response.content
	if l11l1l_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶࠧᩜ") in url: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡥࡷ࡫ࡴࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡴࡲ࠳ࡧࡳ࡫ࡧࠦࠬᩝ"),html,re.DOTALL)
	else: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡧࡦࡸࡥࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ᩞ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ᩟"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if l11l1l_l1_ (u"ࠫࡹࡵࡰࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳ᩠ࠫ") in l1llll1_l1_:
				if l11l1l_l1_ (u"ࠬࡺ࡯ࡱࡸ࡬ࡨࡪࡵࡳ࠯ࡲ࡫ࡴࡄࡩ࠽ࡦࡰࡪࡰ࡮ࡹࡨ࠮࡯ࡲࡺ࡮࡫ࡳࠨᩡ") in l1llll1_l1_: continue
				if l11l1l_l1_ (u"࠭ࡴࡰࡲࡹ࡭ࡩ࡫࡯ࡴ࠰ࡳ࡬ࡵࡅࡣ࠾ࡱࡱࡰ࡮ࡴࡥ࠮࡯ࡲࡺ࡮࡫ࡳ࠲ࠩᩢ") in l1llll1_l1_: continue
				if l11l1l_l1_ (u"ࠧࡵࡱࡳࡺ࡮ࡪࡥࡰࡵ࠱ࡴ࡭ࡶ࠿ࡤ࠿ࡰ࡭ࡸࡩࠧᩣ") in l1llll1_l1_: continue
				if l11l1l_l1_ (u"ࠨࡶࡲࡴࡻ࡯ࡤࡦࡱࡶ࠲ࡵ࡮ࡰࡀࡥࡀࡸࡻ࠳ࡣࡩࡣࡱࡲࡪࡲࠧᩤ") in l1llll1_l1_: continue
				if l11l1l_l1_ (u"่๊ࠩีࠦวๅสาห๏ฯࠧᩥ") in title and l11l1l_l1_ (u"ࠪࡨࡴࡃࡲࡢࡶ࡬ࡲ࡬࠭ᩦ") not in l1llll1_l1_: continue
			else: title = l11l1l_l1_ (u"ࠫฯืส๋สࠣฬฬูสฯัส้࠿ࠦࠠࠨᩧ")+title
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᩨ"),l1111l_l1_+title,l1llll1_l1_,471)
	else: l1lllll_l1_(url)
	return
def l1lllll_l1_(url,request=l11l1l_l1_ (u"࠭ࠧᩩ")):
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫᩪ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬᩫ"),url,l11l1l_l1_ (u"ࠩࠪᩬ"),l11l1l_l1_ (u"ࠪࠫᩭ"),l11l1l_l1_ (u"ࠫࠬᩮ"),l11l1l_l1_ (u"ࠬ࠭ᩯ"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ᩰ"))
	html = response.content
	items = []
	if request==l11l1l_l1_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩᩱ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡦࡳࡳࡺࡡࡪࡰࡨࡶ࠲࡬࡬ࡶ࡫ࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᩲ"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿࠰࠭ࡃ࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮࠭ᩳ"),block,re.DOTALL)
		l1l1_l1_,l11ll1_l1_,l1ll1l11l1_l1_ = zip(*items)
		items = zip(l1ll1l11l1_l1_,l1l1_l1_,l11ll1_l1_)
	elif request==l11l1l_l1_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡹࡥࡳ࡫ࡨࡷࠬᩴ"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ่้๏ุษࠩ࠰࠭ࡃ࠮ࡂࡳࡵࡻ࡯ࡩࡃ࠭᩵"),html,re.DOTALL)
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪ᩶"),block,re.DOTALL)
		l1l1_l1_,l11ll1_l1_,l1ll1l11l1_l1_ = zip(*items)
		items = zip(l1ll1l11l1_l1_,l1l1_l1_,l11ll1_l1_)
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠨࡥࡣࡷࡥ࠲࡫ࡣࡩࡱࡀࠦ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᩷"),html,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࠦࡹ࡯ࡴ࡭ࡧࡖࡩࡨࡺࡩࡰࡰࡆࡳࡳࠨࠧ᩸"),html,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡩࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ᩹"),html,re.DOTALL)
		if not l1l11l1_l1_: l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡬ࡨࡂࠨࡰ࡮࠯ࡵࡩࡱࡧࡴࡦࡦࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᩺"),html,re.DOTALL)
		if not l1l11l1_l1_: return
		block = l1l11l1_l1_[0]
	if not items: items = re.findall(l11l1l_l1_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡦ࡬ࡴࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᩻"),block,re.DOTALL)
	if not items: items = re.findall(l11l1l_l1_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᩼"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"๋ࠬิศ้าอࠬ᩽"),l11l1l_l1_ (u"࠭แ๋ๆ่ࠫ᩾"),l11l1l_l1_ (u"ࠧศ฼้๎ฮ᩿࠭"),l11l1l_l1_ (u"ࠨๅ็๎อ࠭᪀"),l11l1l_l1_ (u"ࠩส฽้อๆࠨ᪁"),l11l1l_l1_ (u"๋ࠪิอแࠨ᪂"),l11l1l_l1_ (u"๊ࠫฮวาษฬࠫ᪃"),l11l1l_l1_ (u"ࠬ฿ัืࠩ᪄"),l11l1l_l1_ (u"࠭ๅ่ำฯห๋࠭᪅"),l11l1l_l1_ (u"ࠧศๆห์๊࠭᪆"),l11l1l_l1_ (u"ࠨ็ึีา๐ษࠨ᪇")]
	for l1ll1l_l1_,l1llll1_l1_,title in items:
		l1llll1_l1_ = l1llll_l1_(l1llll1_l1_).strip(l11l1l_l1_ (u"ࠩ࠲ࠫ᪈"))
		if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ᪉") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠫ࠴࠭᪊")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ᪋"))
		if l11l1l_l1_ (u"࠭ࡨࡵࡶࡳࠫ᪌") not in l1ll1l_l1_: l1ll1l_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰ࠩ᪍")+l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ᪎"))
		#l1llll1_l1_ = unescapeHTML(l1llll1_l1_)
		#title = unescapeHTML(title)
		#title = title.strip(l11l1l_l1_ (u"ࠩࠣࠫ᪏"))
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭᪐"),title,re.DOTALL)
		if any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᪑"),l1111l_l1_+title,l1llll1_l1_,472,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠬอไฮๆๅอࠬ᪒") in title:
			title = l11l1l_l1_ (u"࠭࡟ࡎࡑࡇࡣࠬ᪓") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪔"),l1111l_l1_+title,l1llll1_l1_,473,l1ll1l_l1_)
				l11l_l1_.append(title)
		elif l11l1l_l1_ (u"ࠨ࠱ࡰࡳࡻࡹࡥࡳ࡫ࡨࡷ࠴࠭᪕") in l1llll1_l1_:
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᪖"),l1111l_l1_+title,l1llll1_l1_,471,l1ll1l_l1_)
		else: addMenuItem(l11l1l_l1_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᪗"),l1111l_l1_+title,l1llll1_l1_,473,l1ll1l_l1_)
	if request not in [l11l1l_l1_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥ࡭ࡰࡸ࡬ࡩࡸ࠭᪘"),l11l1l_l1_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡴࡧࡵ࡭ࡪࡹࠧ᪙")]:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ᪚"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ᪛"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				if l1llll1_l1_==l11l1l_l1_ (u"ࠨࠥࠪ᪜"): continue
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࠫ᪝")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠪ࠳ࠬ᪞"))
				title = unescapeHTML(title)
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᪟"),l1111l_l1_+l11l1l_l1_ (u"ࠬ฻แฮหࠣࠫ᪠")+title,l1llll1_l1_,471)
		l1lll1llll_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡳࡩࡱࡺࡱࡴࡸࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᪡"),html,re.DOTALL)
		if l1lll1llll_l1_:
			l1llll1_l1_ = l1lll1llll_l1_[0]
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᪢"),l1111l_l1_+l11l1l_l1_ (u"ࠨ็ืห์ีษࠡษ็้ื๐ฯࠨ᪣"),l1llll1_l1_,471)
	return
def l1lll1l1_l1_(url,l1l11_l1_):
	#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ᪤"),l11l1l_l1_ (u"ࠪ࠵࠶࠷࠱ࠡࠢࠪ᪥")+url)
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠫࡺࡸ࡬ࠨ᪦"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩᪧ"),url,l11l1l_l1_ (u"࠭ࠧ᪨"),l11l1l_l1_ (u"ࠧࠨ᪩"),l11l1l_l1_ (u"ࠨࠩ᪪"),l11l1l_l1_ (u"ࠩࠪ᪫"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠴ࡱࡨࠬ᪬"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"࡙ࠫࠧࡥࡢࡵࡲࡲࡸࡈ࡯ࡹࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ᪭"),html,re.DOTALL)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠬ࡯ࡤ࠾ࠤࠪ᪮")+l1l11_l1_+l11l1l_l1_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ᪯"),html,re.DOTALL)
	items = []
	# l1lll1l_l1_
	if l1l1111_l1_ and not l1l11_l1_:
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡵࡨࡶ࡮࡫ࡳ࠮ࡪࡨࡥࡩ࡫ࡲࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᪰"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡱࡳࡩࡳࡉࡩࡵࡻ࡟ࠬࡪࡼࡥ࡯ࡶ࡟࠰ࠥࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡻࡴࡵࡱࡱࡂࠬ᪱"),block,re.DOTALL)
		for l1l11_l1_,title in items: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᪲"),l1111l_l1_+title,url,473,l1ll1l_l1_,l11l1l_l1_ (u"ࠪࠫ᪳"),l1l11_l1_)
	# l11ll_l1_
	elif l11llll_l1_:
		#l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡩࡷࡰࡦࠬ᪴"))
		l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡳࡦࡴ࡬ࡩࡸ࠳ࡨࡦࡣࡧࡩࡷࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ᪵ࠧ"),html,re.DOTALL)
		l1ll1l_l1_ = l1ll1l_l1_[0]
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡴࡪࡶ࡯ࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠦࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁ᪶ࠬࠫࠧ"),block,re.DOTALL)
		if items:
			for title,l1llll1_l1_ in items:
				l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠧ࠰᪷ࠩ")+l1llll1_l1_.strip(l11l1l_l1_ (u"ࠨ࠱᪸ࠪ"))
				addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᪹"),l1111l_l1_+title,l1llll1_l1_,472,l1ll1l_l1_)
		else:
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡩ࡮ࡣࡪࡩ࠿ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞᪺ࠬࠫ"),block,re.DOTALL)
			for l1llll1_l1_,title,l1ll1l_l1_ in items:
				if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᪻") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࠧ᪼")+l1llll1_l1_.strip(l11l1l_l1_ (u"࠭࠯ࠨ᪽"))
				addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭᪾"),l1111l_l1_+title,l1llll1_l1_,472,l1ll1l_l1_)
	if l11l1l_l1_ (u"ࠨ࡫ࡧࡁࠧࡶ࡭࠮ࡴࡨࡰࡦࡺࡥࡥࠤᪿࠪ") in html:
		if items: addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱᫀࠧ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᫁"),l11l1l_l1_ (u"ࠫࠬ᫂"),9999)
		addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ᫃ࠬ"),l1111l_l1_+l11l1l_l1_ (u"࠭ๅ้ษู๎฾ࠦะศฬู้ࠣฯ᫄ࠧ"),url,471)
	#else: l1lllll_l1_(url)
	return
def PLAY(url):
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠧࡶࡴ࡯ࠫ᫅"))
	l1lll1_l1_ = []
	# l1ll1l111l_l1_ check
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ᫆"),url,l11l1l_l1_ (u"ࠩࠪ᫇"),l11l1l_l1_ (u"ࠪࠫ᫈"),l11l1l_l1_ (u"ࠫࠬ᫉"),l11l1l_l1_ (u"᫊ࠬ࠭"),l11l1l_l1_ (u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ᫋"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡰ࠱ࡻ࡯ࡤࡦࡱ࠰ࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡯ࡂࠬᫌ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᫍ"),block,re.DOTALL)
		if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_,True): return
	# default l11l11lll_l1_ l1llll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᫎ"),html,re.DOTALL)
	if l1llll1_l1_:
		l1llll1_l1_ = l1llll1_l1_[0]+l11l1l_l1_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫ᫏")
		if l11l1l_l1_ (u"ࠫ࡭ࡺࡴࡱࠩ᫐") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ᫑")+l1llll1_l1_
		l1lll1_l1_.append(l1llll1_l1_)
	# l1l1111l1_l1_ l11l11lll_l1_ l1llll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩ࡛ࡒࡍࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᫒"),html,re.DOTALL)
	if l1llll1_l1_:
		l1llll1_l1_ = l1llll1_l1_[0]+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡠࡡࡨࡱࡧ࡫ࡤࠨ᫓")
		if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭᫔") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᫕")+l1llll1_l1_
		l1lll1_l1_.append(l1llll1_l1_)
	# l11l11lll_l1_ l1l1_l1_
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ᫖"),l11l1l_l1_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࠱ࡴ࡭ࡶࠧ᫗"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ᫘"),l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ᫙"),l11l1l_l1_ (u"ࠧࠨ᫚"),l11l1l_l1_ (u"ࠨࠩ᫛"),l11l1l_l1_ (u"ࠩࠪ᫜"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ᫝"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧ࡝ࡡࡵࡥ࡫ࡐ࡮ࡹࡴࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ᫞"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡹࡸ࡯࡯ࡩࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡹࡸ࡯࡯ࡩࡁࠫ᫟"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ᫠")+title+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ᫡")
			if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭᫢") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᫣")+l1llll1_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l111l1l_l1_ = url.replace(l11l1l_l1_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧ᫤"),l11l1l_l1_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡪࡳࠫ᫥"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ᫦"),l111l1l_l1_,l11l1l_l1_ (u"࠭ࠧ᫧"),l11l1l_l1_ (u"ࠧࠨ᫨"),l11l1l_l1_ (u"ࠨࠩ᫩"),l11l1l_l1_ (u"ࠩࠪ᫪"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ᫫"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠫࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡬ࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ᫬"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠬࡪࡡࡵࡣ࠰ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ᫭"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ᫮")+title+l11l1l_l1_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ᫯")
			if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭᫰") not in l1llll1_l1_: l1llll1_l1_ = l11l1l_l1_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᫱")+l1llll1_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ᫲"),l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ᫳"),url)
	return
def SEARCH(search):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭᫴"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ᫵"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ᫶"),l11l1l_l1_ (u"ࠨ࠭ࠪ᫷"))
	url = l11l11_l1_+l11l1l_l1_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪ࠱ࡴ࡭ࡶ࠿࡬ࡧࡼࡻࡴࡸࡤࡴ࠿ࠪ᫸")+search
	l1lllll_l1_(url)
	return
# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫᣤ")
l1111l_l1_ = l11l1l_l1_ (u"ࠪࡣࡈࡓࡃࡠࠩᣥ")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"๊ࠫ๎โฺ้ࠢฮๆ๊๊ไีࠪᣦ")]
def MAIN(mode,url,text):
	if   mode==490: results = MENU()
	elif mode==491: results = l1lllll_l1_(url,text)
	elif mode==492: results = PLAY(url)
	elif mode==493: results = l1lll1l1_l1_(url)
	elif mode==494: results = l11lll_l1_(url)
	elif mode==499: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩᣧ"),l11l11_l1_,l11l1l_l1_ (u"࠭ࠧᣨ"),l11l1l_l1_ (u"ࠧࠨᣩ"),l11l1l_l1_ (u"ࠨࠩᣪ"),l11l1l_l1_ (u"ࠩࠪᣫ"),l11l1l_l1_ (u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧᣬ"))
	html = response.content
	l1l1ll1_l1_ = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᣭ"),html,re.DOTALL)
	l1l1ll1_l1_ = l1l1ll1_l1_[0].strip(l11l1l_l1_ (u"ࠬ࠵ࠧᣮ"))
	l1l1ll1_l1_ = SERVER(l1l1ll1_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪᣯ"))
	#addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᣰ"),l1111l_l1_+l11l1l_l1_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨᣱ"),l1l1ll1_l1_,499,l11l1l_l1_ (u"ࠩࠪᣲ"),l11l1l_l1_ (u"ࠪࠫᣳ"),l11l1l_l1_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᣴ"))
	#addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᣵ"),l1ll1_l1_+l11l1l_l1_ (u"࠭࡟ࡔࡅࡕࡍࡕ࡚࡟ࠨ᣶")+l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ࠭᣷"),l1l1ll1_l1_,491,l11l1l_l1_ (u"ࠨࠩ᣸"),l11l1l_l1_ (u"ࠩࠪ᣹"),l11l1l_l1_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ᣺"))
	#addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ᣻"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᣼"),l11l1l_l1_ (u"࠭ࠧ᣽"),9999)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡨ࡬ࡰࡹ࡫ࡲࠡࡃ࡭ࡥࡽ࡯ࡦࡺࡈ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭᣾"),html,re.DOTALL)
	if l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡦࡤࡸࡦ࠳ࡦࡪ࡮ࡷࡩࡷࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᣿"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title in l1l111_l1_: continue
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡰ࡮ࡧ࠳࡫࡯࡬ࡵࡧࡵ࠳ࠬᤀ")+l1llll1_l1_+l11l1l_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨᤁ")
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᤂ"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧᤃ")+l1111l_l1_+title,l1llll1_l1_,491)
	addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫᤄ"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᤅ"),l11l1l_l1_ (u"ࠨࠩᤆ"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤇ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᤈ")+l1111l_l1_+l11l1l_l1_ (u"ࠫศ็ไศ็ࠪᤉ"),l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษไ่ฬ๋࠭࡮ࡱࡹ࡭ࡪࡹ࠭ࡧ࡫࡯ࡱࡪ࠵ࡦࡰࡴࡨ࡭࡬ࡴ࠭ࡩࡦ࠰หๆ๊วๆ࠯สะ๋ฮ้࠮࠴ࠪᤊ"),494,l11l1l_l1_ (u"࠭ࠧᤋ"),l11l1l_l1_ (u"ࠧࠨᤌ"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᤍ"))
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤎ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᤏ")+l1111l_l1_+l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠬᤐ"),l1l1ll1_l1_+l11l1l_l1_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰็ึุ่๊วห࠱่ืู้ไศฬ࠰หั์ศ๊ࠩᤑ"),494,l11l1l_l1_ (u"࠭ࠧᤒ"),l11l1l_l1_ (u"ࠧࠨᤓ"),l11l1l_l1_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᤔ"))
	addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧᤕ"),l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦ࠽࠾࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࡃ࠽ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᤖ"),l11l1l_l1_ (u"ࠫࠬᤗ"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯࠯ࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫᤘ"),html,re.DOTALL)
	block = l1l11l1_l1_[0]
	items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᤙ"),block,re.DOTALL)
	for l1llll1_l1_,title in items:
		if l1llll1_l1_==l11l1l_l1_ (u"ࠧ࠰ࠩᤚ"): continue
		if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭ᤛ") not in l1llll1_l1_: l1llll1_l1_ = l1l1ll1_l1_+l1llll1_l1_
		if title in l1l111_l1_: continue
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᤜ"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬᤝ")+l1111l_l1_+title,l1llll1_l1_,491)
	return html
def l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬᤞ"),l11l1l_l1_ (u"ࠬ࠭᤟"),url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪᤠ"),url,l11l1l_l1_ (u"ࠧࠨᤡ"),l11l1l_l1_ (u"ࠨࠩᤢ"),l11l1l_l1_ (u"ࠩࠪᤣ"),l11l1l_l1_ (u"ࠪࠫᤤ"),l11l1l_l1_ (u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠳ࡓࡖࡄࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᤥ"))
	html = response.content
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡦࡪ࡮ࡷࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᤦ"),html,re.DOTALL)
	if l1l1111_l1_:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᤧ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			if title in l1l111_l1_: continue
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᤨ"),l1111l_l1_+title,l1llll1_l1_,491)
	return
def l1lllll_l1_(url,l1lll111ll_l1_=l11l1l_l1_ (u"ࠨࠩᤩ")):
	items = []
	#l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭ᤪ"))
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧᤫ"),url,l11l1l_l1_ (u"ࠫࠬ᤬"),l11l1l_l1_ (u"ࠬ࠭᤭"),l11l1l_l1_ (u"࠭ࠧ᤮"),l11l1l_l1_ (u"ࠧࠨ᤯"),l11l1l_l1_ (u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧᤰ"))
	html = response.content
	block = l11l1l_l1_ (u"ࠩࠪᤱ")
	if l11l1l_l1_ (u"ࠪ࠲ࡵ࡮ࡰࠨᤲ") in url: block = html
	elif l11l1l_l1_ (u"ࠫࡄࡹ࠽ࠨᤳ") in url:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࠨࡢ࡭ࡱࡦ࡯ࡸ࠮࠮ࠫࡁࠬࠦࡲࡧ࡮ࡪࡨࡨࡷࡹࠨࠧᤴ"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᤵ"),block,re.DOTALL)
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡄ࡯ࡳࡨࡱࡳࠩ࠰࠭ࡃ࠮ࠨ࡭ࡢࡰ࡬ࡪࡪࡹࡴࠣࠩᤶ"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
	if not block: return
	#if not items: items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡱࡦ࡭ࡥ࡝࠼ࡸࡶࡱࡢࠨࠩ࠰࠭ࡃ࠮ࡢࠩ࠯ࠬࡂࠦࡧࡵࡸࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᤷ"),block,re.DOTALL)
	l11l_l1_ = []
	l1ll11_l1_ = [l11l1l_l1_ (u"ุ่ࠩฬํฯสࠩᤸ"),l11l1l_l1_ (u"ࠪๅ๏๊ๅࠨ᤹"),l11l1l_l1_ (u"ࠫฬเๆ๋หࠪ᤺"),l11l1l_l1_ (u"ࠬษฺ็์ฬ᤻ࠫ"),l11l1l_l1_ (u"࠭ใๅ์หࠫ᤼"),l11l1l_l1_ (u"ࠧศ฻็ห๋࠭᤽"),l11l1l_l1_ (u"ࠨ้าหๆ࠭᤾"),l11l1l_l1_ (u"่ࠩฬฬืวสࠩ᤿"),l11l1l_l1_ (u"ࠪ฽ึ฼ࠧ᥀"),l11l1l_l1_ (u"๊ࠫํัอษ้ࠫ᥁"),l11l1l_l1_ (u"ࠬอไษ๊่ࠫ᥂"),l11l1l_l1_ (u"࠭ๅิำะ๎ฮ࠭᥃")]
	for l1llll1_l1_,l1ll1l_l1_,title in items:
		title = unescapeHTML(title)
		l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦอๅไฬࠤࡡࡪࠫࠨ᥄"),title,re.DOTALL)
		if not l1ll11l_l1_: l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫ᥅"),title,re.DOTALL)
		if not l1ll11l_l1_ or any(value in title for value in l1ll11_l1_):
			addMenuItem(l11l1l_l1_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ᥆"),l1111l_l1_+title,l1llll1_l1_,492,l1ll1l_l1_)
		elif l1ll11l_l1_ and l11l1l_l1_ (u"ࠪั้่ษࠨ᥇") in title:
			title = l11l1l_l1_ (u"ࠫࡤࡓࡏࡅࡡࠪ᥈") + l1ll11l_l1_[0]
			if title not in l11l_l1_:
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᥉"),l1111l_l1_+title,l1llll1_l1_,493,l1ll1l_l1_)
				l11l_l1_.append(title)
		else: addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᥊"),l1111l_l1_+title,l1llll1_l1_,493,l1ll1l_l1_)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᥋"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᥌"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			title = unescapeHTML(title)
			title = title.replace(l11l1l_l1_ (u"ࠩสฺ่็อสࠢࠪ᥍"),l11l1l_l1_ (u"ࠪࠫ᥎"))
			if title!=l11l1l_l1_ (u"ࠫࠬ᥏"): addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥐ"),l1111l_l1_+l11l1l_l1_ (u"࠭ีโฯฬࠤࠬᥑ")+title,l1llll1_l1_,491)
	return
def l1lll1l1_l1_(url):
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫᥒ"),url,l11l1l_l1_ (u"ࠨࠩᥓ"),l11l1l_l1_ (u"ࠩࠪᥔ"),l11l1l_l1_ (u"ࠪࠫᥕ"),l11l1l_l1_ (u"ࠫࠬᥖ"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᥗ"))
	html = response.content
	l111l1l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡃࡷࡷࡸࡴࡴࡳࡃࡣࡵࡇࡴࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᥘ"),html,re.DOTALL)
	if l111l1l_l1_:
		l111l1l_l1_ = l111l1l_l1_[0]
		response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫᥙ"),l111l1l_l1_,l11l1l_l1_ (u"ࠨࠩᥚ"),l11l1l_l1_ (u"ࠩࠪᥛ"),l11l1l_l1_ (u"ࠪࠫᥜ"),l11l1l_l1_ (u"ࠫࠬᥝ"),l11l1l_l1_ (u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ᥞ"))
		html = response.content
	l1ll1l_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡪ࡯ࡪ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᥟ"),html,re.DOTALL)
	if l1ll1l_l1_: l1ll1l_l1_ = l1ll1l_l1_[0]
	else: l1ll1l_l1_ = xbmc.getInfoLabel(l11l1l_l1_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡗ࡬ࡺࡳࡢࠨᥠ"))
	l1l1111_l1_ = re.findall(l11l1l_l1_ (u"ࠨࠤࡩ࡭ࡱࡺࡥࡳࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᥡ"),html,re.DOTALL)
	l11llll_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡆࡱࡵࡣ࡬ࡵࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦࠬᥢ"),html,re.DOTALL)
	# l1lll1l_l1_
	if l1l1111_l1_ and l11l1l_l1_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬᥣ") not in url:
		block = l1l1111_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᥤ"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥥ"),l1111l_l1_+title,l1llll1_l1_,493,l1ll1l_l1_)
	# l11ll_l1_
	elif l11llll_l1_:
		block = l11llll_l1_[0]
		items = re.findall(l11l1l_l1_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡪ࡯ࡤ࡫ࡪࡢ࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࠤࡥࡳࡽࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᥦ"),block,re.DOTALL)
		if items:
			for l1llll1_l1_,l1ll1l_l1_,title in items:
				title = title.strip(l11l1l_l1_ (u"ࠧࠡࠩᥧ"))
				addMenuItem(l11l1l_l1_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᥨ"),l1111l_l1_+title,l1llll1_l1_,492,l1ll1l_l1_)
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬᥩ"),html,re.DOTALL)
		if l1l11l1_l1_:
			block = l1l11l1_l1_[0]
			items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᥪ"),block,re.DOTALL)
			for l1llll1_l1_,title in items:
				title = unescapeHTML(title)
				title = title.replace(l11l1l_l1_ (u"ࠫฬ๊ีโฯฬࠤࠬᥫ"),l11l1l_l1_ (u"ࠬ࠭ᥬ"))
				if title!=l11l1l_l1_ (u"࠭ࠧᥭ"): addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᥮"),l1111l_l1_+l11l1l_l1_ (u"ࠨืไัฮࠦࠧ᥯")+title,l1llll1_l1_,491)
	return
def PLAY(url):
	l111l1l_l1_ = url.strip(l11l1l_l1_ (u"ࠩ࠲ࠫᥰ"))+l11l1l_l1_ (u"ࠪ࠳ࡄࡼࡩࡦࡹࡀ࠵ࠬᥱ")
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨᥲ"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭ᥳ"),l11l1l_l1_ (u"࠭ࠧᥴ"),l11l1l_l1_ (u"ࠧࠨ᥵"),l11l1l_l1_ (u"ࠨࠩ᥶"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭᥷"))
	html = response.content
	l1lll1_l1_ = []
	l1l1ll1_l1_ = SERVER(url,l11l1l_l1_ (u"ࠪࡹࡷࡲࠧ᥸"))
	l1ll1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠦࡩࡧࡴࡢ࠼ࠣࠫࡶࡃࠨ࠯ࠬࡂ࠭ࠫࠨ᥹"),html,re.DOTALL)
	#if not l1ll1l1lll_l1_: l1ll1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡢࠨࡵࡪ࡬ࡷࡡ࠴ࡩࡥ࡞࠯࠴ࡡ࠲ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ᥺"),html,re.DOTALL)
	l1ll1l1lll_l1_ = l1ll1l1lll_l1_[0]
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ᥻"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ᥼"),block,re.DOTALL)
		for l1ll1ll1ll_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠨࠢࠪ᥽"))
			l1llll1_l1_ = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡰ࡮ࡧ࠳ࡸ࡫ࡲࡷࡧࡵࡷ࠴ࡹࡥࡳࡸࡨࡶ࠳ࡶࡨࡱࡁࡴࡁࠬ᥾")+l1ll1l1lll_l1_+l11l1l_l1_ (u"ࠪࠪ࡮ࡃࠧ᥿")+l1ll1ll1ll_l1_+l11l1l_l1_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᦀ")+title+l11l1l_l1_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭ᦁ")
			l1lll1_l1_.append(l1llll1_l1_)
	# l1l1111l1_l1_ l11l11lll_l1_ l1llll1_l1_
	l1llll1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࠢࡦ࡯ࡥࡩࡩ࡙ࡥࡳࡸࡨࡶࠧ࠴ࠪࡀࡕࡕࡇࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᦂ"),html,re.DOTALL)
	if l1llll1_l1_:
		title = l11l1l_l1_ (u"ࠧๆใู่ࠬᦃ")
		l1llll1_l1_ = l1llll1_l1_[0]+l11l1l_l1_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡩࡲࡨࡥࡥࡡࡢࠫᦄ")+title
		l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	#l111l1l_l1_ = url.strip(l11l1l_l1_ (u"ࠩ࠲ࠫᦅ"))+l11l1l_l1_ (u"ࠪ࠳ࡄࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠽࠲ࠩᦆ")
	#response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠫࡌࡋࡔࠨᦇ"),l111l1l_l1_,l11l1l_l1_ (u"ࠬ࠭ᦈ"),l11l1l_l1_ (u"࠭ࠧᦉ"),l11l1l_l1_ (u"ࠧࠨᦊ"),l11l1l_l1_ (u"ࠨࠩᦋ"),l11l1l_l1_ (u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ᦌ"))
	#html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࠦࡩࡵࡷ࡯࡮ࡲࡥࡩࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᦍ"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᦎ"),block,re.DOTALL)
		for title,l1llll1_l1_ in items:
			title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧᦏ"))
			if l11l1l_l1_ (u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧᦐ") in l1llll1_l1_: l1lll11l1_l1_ = l11l1l_l1_ (u"ࠧࡠࡡัหฺ࠭ᦑ")
			else: l1lll11l1_l1_ = l11l1l_l1_ (u"ࠨࠩᦒ")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᦓ")+title+l11l1l_l1_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧᦔ")+l1lll11l1_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᦕ"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫᦖ"),url)
	return
def SEARCH(search,l1l1ll1_l1_=l11l1l_l1_ (u"࠭ࠧᦗ")):
	if not l1l1ll1_l1_: l1l1ll1_l1_ = l11l11_l1_
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if not search:
		search = OPEN_KEYBOARD()
		if not search: return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩᦘ"),l11l1l_l1_ (u"ࠨ࠭ࠪᦙ"))
	url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵࡅࡳ࠾ࠩᦚ")+search
	l1lllll_l1_(url)
	return
#   search is l11l1l1ll_l1_ l11ll1lll_l1_ in l1lllll_l1_()
#   https://l1ll1ll111_l1_.l1ll1ll11l_l1_-l1ll1ll1l1_l1_.l1ll1ll1l1_l1_/?s=the+l1ll1l1l1l_l1_
#   https://l1ll1ll111_l1_.l1ll1ll11l_l1_-l1ll1ll1l1_l1_.l1ll1ll1l1_l1_/search/the+l1ll1l1l1l_l1_/
#   https://l1ll1ll111_l1_.l1ll1ll11l_l1_-l1ll1ll1l1_l1_.l1ll1ll1l1_l1_/index.l1ll1l1ll1_l1_?s=the+l1ll1l1l1l_l1_
#	https://l1ll1ll11l_l1_-l1ll1ll1l1_l1_.io/index.l1ll1l1ll1_l1_?s=the+l1ll1l1l1l_l1_
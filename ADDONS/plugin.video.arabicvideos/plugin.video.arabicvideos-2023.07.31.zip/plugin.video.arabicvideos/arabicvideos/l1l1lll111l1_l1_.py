# -*- coding: utf-8 -*-
import sys
l1l11l_l1_ = sys.version_info [0] == 2
l1lll_l1_ = 2048
l11l1_l1_ = 7
def l11l1l_l1_ (l1_l1_):
    global l1l111l_l1_
    l1l1l11_l1_ = ord (l1_l1_ [-1])
    l1l1l1_l1_ = l1_l1_ [:-1]
    l1l1l_l1_ = l1l1l11_l1_ % len (l1l1l1_l1_)
    l1ll1l1_l1_ = l1l1l1_l1_ [:l1l1l_l1_] + l1l1l1_l1_ [l1l1l_l1_:]
    if l1l11l_l1_:
        l111ll_l1_ = unicode () .join ([unichr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    else:
        l111ll_l1_ = str () .join ([chr (ord (char) - l1lll_l1_ - (l1l1ll_l1_ + l1l1l11_l1_) % l11l1_l1_) for l1l1ll_l1_, char in enumerate (l1ll1l1_l1_)])
    return eval (l111ll_l1_)
from EXCLUDES import *
l1ll1_l1_ = l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁࠨ姍")
headers = {l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭姎"):l11l1l_l1_ (u"ࠪࠫ姏")}
l1111l_l1_ = l11l1l_l1_ (u"ࠫࡤ࡝ࡃࡎࡡࠪ姐")
l11l11_l1_ = l1l1l1l_l1_[l1ll1_l1_][0]
l1l111_l1_ = [l11l1l_l1_ (u"๋ࠬีศำ฼อࠥำัสࠩ姑"),l11l1l_l1_ (u"࠭ࡷࡸࡧࠪ姒")]
def MAIN(mode,url,text):
	if   mode==560: results = MENU()
	elif mode==561: results = l1lllll_l1_(url,text)
	elif mode==562: results = PLAY(url)
	elif mode==563: results = l1lll1l1_l1_(url,text)
	elif mode==564: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧ姓")+text)
	elif mode==565: results = l1ll1l1l_l1_(url,l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ委")+text)
	elif mode==566: results = l11lll_l1_(url)
	elif mode==569: results = SEARCH(text,url)
	else: results = False
	return results
def MENU():
	#response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭姕"),l11l11_l1_,l11l1l_l1_ (u"ࠪࠫ姖"),l11l1l_l1_ (u"ࠫࠬ姗"),False,l11l1l_l1_ (u"ࠬ࠭姘"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ姙"))
	#hostname = response.headers[l11l1l_l1_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ姚")]
	#hostname = hostname.strip(l11l1l_l1_ (u"ࠨ࠱ࠪ姛"))
	#l1l1ll1_l1_ = l11l11_l1_
	#url = l1l1ll1_l1_+l11l1l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ姜")
	#url = l1l1ll1_l1_
	#response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ姝"),l11l11_l1_,l11l1l_l1_ (u"ࠫࠬ姞"),l11l1l_l1_ (u"ࠬ࠭姟"),l11l1l_l1_ (u"࠭ࠧ姠"),l11l1l_l1_ (u"ࠧࠨ姡"),l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ姢"))
	#addMenuItem(l11l1l_l1_ (u"ࠩ࡯࡭ࡳࡱࠧ姣"),l1111l_l1_+l11l1l_l1_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢํะศࠢส่๊๎โฺ่ࠢ฾้่࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ姤"),l11l1l_l1_ (u"ࠫࠬ姥"),8)
	#addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ姦"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭姧"),l11l1l_l1_ (u"ࠧࠨ姨"),9999)
	addMenuItem(l11l1l_l1_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ姩"),l1111l_l1_+l11l1l_l1_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ姪"),l11l11_l1_,569,l11l1l_l1_ (u"ࠪࠫ姫"),l11l1l_l1_ (u"ࠫࠬ姬"),l11l1l_l1_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ姭"))
	addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭姮"),l1111l_l1_+l11l1l_l1_ (u"ࠧโๆอี๋ࠥอะัࠪ姯"),l11l11_l1_+l11l1l_l1_ (u"ࠨ࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡒࡪࡩ࡫ࡸࡇࡧࡲࠨ姰"),564)
	addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姱"),l1111l_l1_+l11l1l_l1_ (u"ࠪๅ้ะัࠡๅส้้࠭姲"),l11l11_l1_+l11l1l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ姳"),565)
	addMenuItem(l11l1l_l1_ (u"ࠬࡲࡩ࡯࡭ࠪ姴"),l11l1l_l1_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭姵"),l11l1l_l1_ (u"ࠧࠨ姶"),9999)
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ姷"):hostname,l11l1l_l1_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭姸"):l11l1l_l1_ (u"ࠪࠫ姹")}
	#html = response.content
	#html = escapeUNICODE(html)
	#html = html.replace(l11l1l_l1_ (u"ࠫࡡ࠵ࠧ姺"),l11l1l_l1_ (u"ࠬ࠵ࠧ姻"))
	#l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡲࡪࡩ࡫ࡸࡧࡧࡲࠩ࠰࠭ࡃ࠮࡬ࡩ࡭ࡶࡨࡶࠬ姼"),html,re.DOTALL)
	#if l1l11l1_l1_:
	#	block = l1l11l1_l1_[0]
	#	items = re.findall(l11l1l_l1_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭姽"),block,re.DOTALL)
	#	for l1llll1_l1_,title in items:
	#		if l11l1l_l1_ (u"ࠨࠧࡧ࠽ࠪ࠾࠵ࠦࡦ࠻ࠩࡧ࠻ࠥࡥ࠺ࠨࡥ࠼ࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡤ࠼ࠩࡩ࠾ࠥࡢ࠻࠰ࠩࡩ࠾ࠥࡢࡦࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡧ࠹ࠨ姾") in l1llll1_l1_: continue
	#		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ姿"),l1ll1_l1_+l11l1l_l1_ (u"ࠪࡣࡘࡉࡒࡊࡒࡗࡣࠬ娀")+l1111l_l1_+title,l1llll1_l1_,566)
	#	addMenuItem(l11l1l_l1_ (u"ࠫࡱ࡯࡮࡬ࠩ威"),l11l1l_l1_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠡ࠿ࡀࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽࠾࠿ࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ娂"),l11l1l_l1_ (u"࠭ࠧ娃"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠧࡈࡇࡗࠫ娄"),l11l11_l1_,l11l1l_l1_ (u"ࠨࠩ娅"),l11l1l_l1_ (u"ࠩࠪ娆"),l11l1l_l1_ (u"ࠪࠫ娇"),l11l1l_l1_ (u"ࠫࠬ娈"),l11l1l_l1_ (u"ࠬ࡝ࡅࡄࡋࡐࡅ࠲ࡓࡅࡏࡗ࠰࠶ࡳࡪࠧ娉"))
	html = response.content
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡎࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡐࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡩ࡬ࡢࡵࡶࡁࠧࡖࡲࡰࡦࡸࡧࡹ࡯࡯࡯ࡵࡏ࡭ࡸࡺࡂࡶࡶࡷࡳࡳࠨࠧ娊"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠲࡯ࡴࡦ࡯࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ娋"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			#if l11l1l_l1_ (u"ࠨࡪࡷࡸࡵ࠭娌") not in l1llll1_l1_:
			#	server = SERVER(l1llll1_l1_,l11l1l_l1_ (u"ࠩࡸࡶࡱ࠭娍"))
			#	l1llll1_l1_ = l1llll1_l1_.replace(server,l1l1ll1_l1_)
			if title==l11l1l_l1_ (u"ࠪࠫ娎"): continue
			if any(value in title.lower() for value in l1l111_l1_): continue
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娏"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ娐")+l1111l_l1_+title,l1llll1_l1_,566)
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ娑"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ娒"),l11l1l_l1_ (u"ࠨࠩ娓"),9999)
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮࡮࡯ࡷࡧࡵࡥࡧࡲࡥࠡࡣࡦࡸ࡮ࡼࡡࡣ࡮ࡨࠫ娔"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫ࠱࠮ࡄࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠪ娕"),block,re.DOTALL)
		for l1llll1_l1_,l1ll1l_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娖"),l1ll1_l1_+l11l1l_l1_ (u"ࠬࡥࡓࡄࡔࡌࡔ࡙ࡥࠧ娗")+l1111l_l1_+title,l1llll1_l1_,566,l1ll1l_l1_)
	return html
def l11lll_l1_(url):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ娘"),l11l1l_l1_ (u"ࠧࠨ娙"),url,l11l1l_l1_ (u"ࠨࠩ娚"))
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ娛"):url,l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ娜"):l11l1l_l1_ (u"ࠫࠬ娝")}
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠬࡍࡅࡕࠩ娞"),url,l11l1l_l1_ (u"࠭ࠧ娟"),l11l1l_l1_ (u"ࠧࠨ娠"),l11l1l_l1_ (u"ࠨࠩ娡"),l11l1l_l1_ (u"ࠩࠪ娢"),l11l1l_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗ࡚ࡈࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ娣"))
	html = response.content
	#addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ娤"),l1111l_l1_+l11l1l_l1_ (u"ࠬ็ไหำ้ࠣาีฯࠨ娥"),url,564)
	#addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭娦"),l1111l_l1_+l11l1l_l1_ (u"ࠧโๆอี้ࠥวๆๆࠪ娧"),url,565)
	if l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕ࡯࡭ࡩ࡫ࡲ࠮࠯ࡊࡶ࡮ࡪࠢࠨ娨") in html:
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娩"),l1111l_l1_+l11l1l_l1_ (u"ࠪห้๋ๅ๋ิฬࠫ娪"),url,561,l11l1l_l1_ (u"ࠫࠬ娫"),l11l1l_l1_ (u"ࠬ࠭娬"),l11l1l_l1_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ娭"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨ娮"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ娯"),block,re.DOTALL)
		for l1llll1_l1_,title in items:
			addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ娰"),l1111l_l1_+title,l1llll1_l1_,561)
	return
def l1lllll_l1_(l111lll111l_l1_,type=l11l1l_l1_ (u"ࠪࠫ娱")):
	if l11l1l_l1_ (u"ࠫ࠿ࡀࠧ娲") in l111lll111l_l1_:
		l111ll1_l1_,url = l111lll111l_l1_.split(l11l1l_l1_ (u"ࠬࡀ࠺ࠨ娳"))
		server = SERVER(l111ll1_l1_,l11l1l_l1_ (u"࠭ࡵࡳ࡮ࠪ娴"))
		url = server+url
	else: url,l111ll1_l1_ = l111lll111l_l1_,l111lll111l_l1_
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ娵"):l111ll1_l1_,l11l1l_l1_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ娶"):l11l1l_l1_ (u"ࠩࠪ娷")}
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠪࡋࡊ࡚ࠧ娸"),url,l11l1l_l1_ (u"ࠫࠬ娹"),l11l1l_l1_ (u"ࠬ࠭娺"),l11l1l_l1_ (u"࠭ࠧ娻"),l11l1l_l1_ (u"ࠧࠨ娼"),l11l1l_l1_ (u"ࠨ࡙ࡈࡇࡎࡓࡁ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ娽"))
	html = response.content
	if type==l11l1l_l1_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ娾"):
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲࠳ࡔࡢࡤࡶࡹ࡮ࠨࠧ娿"),html,re.DOTALL)
	elif type==l11l1l_l1_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ婀"):
		l1l11l1_l1_ = [html.replace(l11l1l_l1_ (u"ࠬࡢ࡜࠰ࠩ婁"),l11l1l_l1_ (u"࠭࠯ࠨ婂")).replace(l11l1l_l1_ (u"ࠧ࡝࡞ࠥࠫ婃"),l11l1l_l1_ (u"ࠨࠤࠪ婄"))]
	else:
		l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡊࡶ࡮ࡪ࠭࠮࡙ࡨࡧ࡮ࡳࡡࡑࡱࡶࡸࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀ࠿࠳ࡺࡲ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃ࠭婅"),html,re.DOTALL)
	l11l_l1_ = []
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠪࡋࡷ࡯ࡤࡊࡶࡨࡱࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩ婆"),block,re.DOTALL)
		for l1llll1_l1_,title,l1ll1l_l1_ in items:
			if any(value in title.lower() for value in l1l111_l1_): continue
			l1ll1l_l1_ = escapeUNICODE(l1ll1l_l1_)
			title = unescapeHTML(title)
			title = escapeUNICODE(title)
			title = title.replace(l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ婇"),l11l1l_l1_ (u"ࠬ࠭婈"))
			if l11l1l_l1_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ婉") in l1llll1_l1_: addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ婊"),l1111l_l1_+title,l1llll1_l1_,563,l1ll1l_l1_)
			elif l11l1l_l1_ (u"ࠨฯ็ๆฮ࠭婋") in title:
				l1ll11l_l1_ = re.findall(l11l1l_l1_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࠭ะ่็ฯࠠࠬ࡞ࡧ࠯ࠬ婌"),title,re.DOTALL)
				if l1ll11l_l1_: title = l11l1l_l1_ (u"ࠪࡣࡒࡕࡄࡠࠩ婍") + l1ll11l_l1_[0]
				if title not in l11l_l1_:
					l11l_l1_.append(title)
					addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婎"),l1111l_l1_+title,l1llll1_l1_,563,l1ll1l_l1_)
			else:
				addMenuItem(l11l1l_l1_ (u"ࠬࡼࡩࡥࡧࡲࠫ婏"),l1111l_l1_+title,l1llll1_l1_,562,l1ll1l_l1_)
		if type==l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ婐"):
			l1ll11ll111_l1_ = re.findall(l11l1l_l1_ (u"ࠧࠣ࡯ࡲࡶࡪࡥࡢࡶࡶࡷࡳࡳࡥࡰࡢࡩࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬ婑"),block,re.DOTALL)
			if l1ll11ll111_l1_:
				count = l1ll11ll111_l1_[0]
				l1llll1_l1_ = url+l11l1l_l1_ (u"ࠨ࠱ࡲࡪ࡫ࡹࡥࡵ࠱ࠪ婒")+count
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ婓"),l1111l_l1_+l11l1l_l1_ (u"ูࠪๆำษࠡลัี๎࠭婔"),l1llll1_l1_,561,l11l1l_l1_ (u"ࠫࠬ婕"),l11l1l_l1_ (u"ࠬ࠭婖"),l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ婗"))
		elif type==l11l1l_l1_ (u"ࠧࠨ婘"):
			l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ婙"),html,re.DOTALL)
			if l1l11l1_l1_:
				block = l1l11l1_l1_[0]
				items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ婚"),block,re.DOTALL)
				for l1llll1_l1_,title in items:
					title = l11l1l_l1_ (u"ูࠪๆำษࠡࠩ婛")+unescapeHTML(title)
					addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婜"),l1111l_l1_+title,l1llll1_l1_,561)
	return
def l1lll1l1_l1_(url,type=l11l1l_l1_ (u"ࠬ࠭婝")):
	#DIALOG_OK(l11l1l_l1_ (u"࠭ࠧ婞"),l11l1l_l1_ (u"ࠧࠨ婟"),type,url)
	response = OPENURL_REQUESTS_CACHED(REGULAR_CACHE,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ婠"),url,l11l1l_l1_ (u"ࠩࠪ婡"),l11l1l_l1_ (u"ࠪࠫ婢"),l11l1l_l1_ (u"ࠫࠬ婣"),l11l1l_l1_ (u"ࠬ࠭婤"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ婥"))
	html = response.content
	html = l1llll_l1_(html)
	l11l1l_l1_ (u"ࠢࠣࠤࠍࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࠧ࡯ࡴࡦ࡯ࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅ࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦ࡮ࡢ࡯ࡨ࡟࠲࠷࡝࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠱ࠬ࠲ࠧࠡࠩࠬ࠲ࡸࡺࡲࡪࡲࠫࠫ࠴࠭ࠩࠋࠋ࡬ࡪࠥ࠭ๅ้ี่ࠫࠥ࡯࡮ࠡࡰࡤࡱࡪࠦࡡ࡯ࡦࠣࡲࡴࡺࠠࡵࡻࡳࡩ࠿ࠐࠉࠊࡰࡤࡱࡪࠦ࠽ࠡࡰࡤࡱࡪ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ๅ้ี่ࠫ࠮ࡡ࠰࡞ࠌࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡳࡧ࡭ࡦ࠰ࡵࡩࡵࡲࡡࡤࡧฺ๊ࠫࠫว่ัฬࠫ࠱࠭ࠧࠪ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࡦ࡮࡬ࡪࠥ࠭อๅไฬࠫࠥ࡯࡮ࠡࡰࡤࡱࡪࡀࠊࠊࠋࡱࡥࡲ࡫ࠠ࠾ࠢࡱࡥࡲ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࠧฮๆๅอࠬ࠯࡛࠱࡟ࠍࠍࠎࡴࡡ࡮ࡧࠣࡁࠥࡴࡡ࡮ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨ๋ࠬࠬิศ้าอࠬ࠲ࠧࠨࠫ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠤࠥࠦ婦")
	# l1lll1l_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ婧"),html,re.DOTALL)
	if not type and l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ婨"),block,re.DOTALL)
		if len(items)>1:
			for l1llll1_l1_,title in items:
				#title = name+l11l1l_l1_ (u"ࠪࠤ࠲ࠦࠧ婩")+title
				addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ婪"),l1111l_l1_+title,l1llll1_l1_,563,l11l1l_l1_ (u"ࠬ࠭婫"),l11l1l_l1_ (u"࠭ࠧ婬"),l11l1l_l1_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ婭"))
			return
	# l11ll_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡇࡳ࡭ࡸࡵࡤࡦࡵ࠰࠱ࡘ࡫ࡡࡴࡱࡱࡷ࠲࠳ࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࡳ࠿ࠩ婮"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		#LOG_THIS(l11l1l_l1_ (u"ࠩࠪ婯"),block)
		items = re.findall(l11l1l_l1_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡫ࡰࡪࡵࡲࡨࡪ࡚ࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡶࡩࡴࡱࡧࡩ࡙࡯ࡴ࡭ࡧࡁࠫ婰"),block,re.DOTALL|re.IGNORECASE)
		#LOG_THIS(l11l1l_l1_ (u"ࠫࠬ婱"),str(items))
		for l1llll1_l1_,title in items:
			title = title.strip(l11l1l_l1_ (u"ࠬࠦࠧ婲"))
			#title = name+l11l1l_l1_ (u"࠭ࠠ࠮ࠢࠪ婳")+title
			addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭婴"),l1111l_l1_+title,l1llll1_l1_,562)
	if not menuItemsLIST:
		title = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡷ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ婵"),html,re.DOTALL)
		if title: title = title[0].replace(l11l1l_l1_ (u"ࠩࠣ࠱๋ࠥว๋ࠢึ๎๊อࠧ婶"),l11l1l_l1_ (u"ࠪࠫ婷")).replace(l11l1l_l1_ (u"ฺ๊ࠫว่ัฬࠤࠬ婸"),l11l1l_l1_ (u"ࠬ࠭婹"))
		else: title = l11l1l_l1_ (u"࠭ๅๅใࠣห้ะิ฻์็ࠫ婺")
		addMenuItem(l11l1l_l1_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭婻"),l1111l_l1_+title,url,562)
	return
def PLAY(url):
	l1lll1_l1_ = []
	response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"ࠨࡉࡈࡘࠬ婼"),url,l11l1l_l1_ (u"ࠩࠪ婽"),l11l1l_l1_ (u"ࠪࠫ婾"),l11l1l_l1_ (u"ࠫࠬ婿"),l11l1l_l1_ (u"ࠬ࠭媀"),l11l1l_l1_ (u"࠭ࡗࡆࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ媁"))
	html = response.content
	l11l11l_l1_ = re.findall(l11l1l_l1_ (u"ࠧ࠽ࡵࡳࡥࡳࡄวๅฬุ๊๏็࠼࠯ࠬࡂࡀࡦ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ媂"),html,re.DOTALL)
	if l11l11l_l1_:
		l11l11l_l1_ = [l11l11l_l1_[0][0],l11l11l_l1_[0][1]]
		if l11l11l_l1_ and l11l111_l1_(l1ll1_l1_,url,l11l11l_l1_): return
	# l11l11lll_l1_ l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽࡙ࠣࡤࡸࡨ࡮ࡓࡦࡴࡹࡩࡷࡹࡌࡪࡵࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡆ࡯ࡥࡩࡩࠨࠧ媃"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡴ࡯ࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ媄"),block,re.DOTALL)
		for l1llll1_l1_,name in items:
			if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ媅") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			if name==l11l1l_l1_ (u"ุࠫ๐ัโำࠣ์๏ࠦำ๋็สࠫ媆"): name = l11l1l_l1_ (u"ࠬࡽࡥࡤ࡫ࡰࡥࠬ媇")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ媈")+name+l11l1l_l1_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ媉")
			l1lll1_l1_.append(l1llll1_l1_)
	# download l1l1_l1_
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭媊"),html,re.DOTALL)
	if l1l11l1_l1_:
		block = l1l11l1_l1_[0]
		items = re.findall(l11l1l_l1_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ媋"),block,re.DOTALL)
		for l1llll1_l1_,l111ll11_l1_ in items:
			if l11l1l_l1_ (u"ࠪ࡬ࡹࡺࡰࠨ媌") not in l1llll1_l1_: l1llll1_l1_ = l11l11_l1_+l1llll1_l1_
			l111ll11_l1_ = re.findall(l11l1l_l1_ (u"ࠫࡡࡪ࡜ࡥ࡞ࡧ࠯ࠬ媍"),l111ll11_l1_,re.DOTALL)
			if l111ll11_l1_: l111ll11_l1_ = l11l1l_l1_ (u"ࠬࡥ࡟ࡠࡡࠪ媎")+l111ll11_l1_[0]
			else: l111ll11_l1_ = l11l1l_l1_ (u"࠭ࠧ媏")
			l1llll1_l1_ = l1llll1_l1_+l11l1l_l1_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡸࡧࡦ࡭ࡲࡧࠧ媐")+l11l1l_l1_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ媑")+l111ll11_l1_
			l1lll1_l1_.append(l1llll1_l1_)
	#l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ媒"), l1lll1_l1_)
	import ll_l1_
	ll_l1_.l11_l1_(l1lll1_l1_,l1ll1_l1_,l11l1l_l1_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ媓"),url)
	return
def SEARCH(search,hostname=l11l1l_l1_ (u"ࠫࠬ媔")):
	search,options,l1ll_l1_ = SEARCH_OPTIONS(search)
	if search==l11l1l_l1_ (u"ࠬ࠭媕"): search = OPEN_KEYBOARD()
	if search==l11l1l_l1_ (u"࠭ࠧ媖"): return
	search = search.replace(l11l1l_l1_ (u"ࠧࠡࠩ媗"),l11l1l_l1_ (u"ࠨ࠭ࠪ媘"))
	l1lll1_l1_ = [l11l1l_l1_ (u"ࠩ࠲ࠫ媙"),l11l1l_l1_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ媚"),l11l1l_l1_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ媛"),l11l1l_l1_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ媜"),l11l1l_l1_ (u"࠭࠯࡭࡫ࡶࡸࠬ媝")]
	l1l111ll1_l1_ = [l11l1l_l1_ (u"ࠧฤใ็ห๊࠭媞"),l11l1l_l1_ (u"ࠨ็ึุ่๊วหࠩ媟"),l11l1l_l1_ (u"ࠩฦ๊๏๋๊๊ࠡๆีฯ๎ๆࠨ媠"),l11l1l_l1_ (u"ࠪฬึอๅอࠢอ่๏็า๋๊้ࠫ媡"),l11l1l_l1_ (u"ู๊ࠫไิๆสฮࠥ๎ร็์่๎ࠬ媢")]
	if l1ll_l1_:
		l1l_l1_ = DIALOG_SELECT(l11l1l_l1_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ媣"), l1l111ll1_l1_)
		if l1l_l1_==-1: return
	else: l1l_l1_ = 0
	if not hostname:
		hostname = l11l11_l1_
		#response = OPENURL_REQUESTS_CACHED(l1ll1l1ll_l1_,l11l1l_l1_ (u"࠭ࡇࡆࡖࠪ媤"),l11l11_l1_,l11l1l_l1_ (u"ࠧࠨ媥"),l11l1l_l1_ (u"ࠨࠩ媦"),False,l11l1l_l1_ (u"ࠩࠪ媧"),l11l1l_l1_ (u"࡛ࠪࡊࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ媨"))
		#hostname = response.headers[l11l1l_l1_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭媩")]
		#hostname = response.url
		#hostname = hostname.strip(l11l1l_l1_ (u"ࠬ࠵ࠧ媪"))
	l111l1l_l1_ = hostname+l11l1l_l1_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨ媫")+search+l1lll1_l1_[l1l_l1_]
	l1lllll_l1_(l111l1l_l1_)
	return
def l1ll1l1l_l1_(l111lll111l_l1_,filter):
	if l11l1l_l1_ (u"ࠧࡀࡁࠪ媬") in l111lll111l_l1_: url = l111lll111l_l1_.split(l11l1l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ媭"))[0]
	else: url = l111lll111l_l1_
	#l1l1l1ll1_l1_ = {l11l1l_l1_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ媮"):l111lll111l_l1_,l11l1l_l1_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ媯"):l11l1l_l1_ (u"ࠫࠬ媰")}
	filter = filter.replace(l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ媱"),l11l1l_l1_ (u"࠭ࠧ媲"))
	type,filter = filter.split(l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ媳"),1)
	if filter==l11l1l_l1_ (u"ࠨࠩ媴"): l1l11111_l1_,l11lllll_l1_ = l11l1l_l1_ (u"ࠩࠪ媵"),l11l1l_l1_ (u"ࠪࠫ媶")
	else: l1l11111_l1_,l11lllll_l1_ = filter.split(l11l1l_l1_ (u"ࠫࡤࡥ࡟ࠨ媷"))
	if type==l11l1l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ媸"):
		if l1l11111l_l1_[0]+l11l1l_l1_ (u"࠭࠽࠾ࠩ媹") not in l1l11111_l1_: category = l1l11111l_l1_[0]
		for i in range(len(l1l11111l_l1_[0:-1])):
			if l1l11111l_l1_[i]+l11l1l_l1_ (u"ࠧ࠾࠿ࠪ媺") in l1l11111_l1_: category = l1l11111l_l1_[i+1]
		l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ媻")+category+l11l1l_l1_ (u"ࠩࡀࡁ࠵࠭媼")
		l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭媽")+category+l11l1l_l1_ (u"ࠫࡂࡃ࠰ࠨ媾")
		l1l11l11_l1_ = l1l1ll1l_l1_.strip(l11l1l_l1_ (u"ࠬࠬࠦࠨ媿"))+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ嫀")+l1l1l1l1_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ嫁"))
		l11lll11_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嫂"))
		l111l1l_l1_ = url+l11l1l_l1_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ嫃")+l11lll11_l1_
	elif type==l11l1l_l1_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ嫄"):
		l11l1lll_l1_ = l11lll1l_l1_(l1l11111_l1_,l11l1l_l1_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭嫅"))
		l11l1lll_l1_ = l1llll_l1_(l11l1lll_l1_)
		if l11lllll_l1_!=l11l1l_l1_ (u"ࠬ࠭嫆"): l11lllll_l1_ = l11lll1l_l1_(l11lllll_l1_,l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嫇"))
		if l11lllll_l1_==l11l1l_l1_ (u"ࠧࠨ嫈"): l111l1l_l1_ = url
		else: l111l1l_l1_ = url+l11l1l_l1_ (u"ࠨ࠱࠲࡫ࡪࡺࡰࡰࡵࡷࡷࡄࡅࠧ嫉")+l11lllll_l1_
		l1llll1ll_l1_ = l11ll11l1_l1_(l111l1l_l1_,l111lll111l_l1_)
		addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嫊"),l1111l_l1_+l11l1l_l1_ (u"ࠪว฽ํวาࠢๅหห๋ษࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠห็ࠣหำะ๊ศำ๊หࠥ࠭嫋"),l1llll1ll_l1_,561,l11l1l_l1_ (u"ࠫࠬ嫌"),l11l1l_l1_ (u"ࠬ࠭嫍"),l11l1l_l1_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ嫎"))
		addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫏"),l1111l_l1_+l11l1l_l1_ (u"ࠨࠢ࡞࡟ࠥࠦࠠࠨ嫐")+l11l1lll_l1_+l11l1l_l1_ (u"ࠩࠣࠤࠥࡣ࡝ࠨ嫑"),l1llll1ll_l1_,561,l11l1l_l1_ (u"ࠪࠫ嫒"),l11l1l_l1_ (u"ࠫࠬ嫓"),l11l1l_l1_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭嫔"))
		addMenuItem(l11l1l_l1_ (u"࠭࡬ࡪࡰ࡮ࠫ嫕"),l11l1l_l1_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡁࡂࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࡀࡁࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ嫖"),l11l1l_l1_ (u"ࠨࠩ嫗"),9999)
	response = OPENURL_REQUESTS_CACHED(l1llll11_l1_,l11l1l_l1_ (u"ࠩࡊࡉ࡙࠭嫘"),url,l11l1l_l1_ (u"ࠪࠫ嫙"),l11l1l_l1_ (u"ࠫࠬ嫚"),l11l1l_l1_ (u"ࠬ࠭嫛"),l11l1l_l1_ (u"࠭ࠧ嫜"),l11l1l_l1_ (u"ࠧࡘࡇࡆࡍࡒࡇ࠭ࡇࡋࡏࡘࡊࡘࡓࡠࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ嫝"))
	html = response.content
	html = html.replace(l11l1l_l1_ (u"ࠨ࡞࡟ࠦࠬ嫞"),l11l1l_l1_ (u"ࠩࠥࠫ嫟")).replace(l11l1l_l1_ (u"ࠪࡠࡡ࠵ࠧ嫠"),l11l1l_l1_ (u"ࠫ࠴࠭嫡"))
	l1l11l1_l1_ = re.findall(l11l1l_l1_ (u"ࠬࡂࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡷࡦࡥ࡬ࡱࡦ࠳࠭ࡧ࡫࡯ࡸࡪࡸ࠾ࠨ嫢"),html,re.DOTALL)
	if not l1l11l1_l1_: return
	block = l1l11l1_l1_[0]
	l1ll1l11_l1_ = re.findall(l11l1l_l1_ (u"࠭ࡴࡢࡺࡲࡲࡴࡳࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾ࠫ࠲࠯ࡅࠩ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ嫣"),block+l11l1l_l1_ (u"ࠧ࠽ࡨ࡬ࡰࡹ࡫ࡲࡣࡱࡻࠫ嫤"),re.DOTALL)
	dict = {}
	for l1ll11l1_l1_,name,block in l1ll1l11_l1_:
		name = escapeUNICODE(name)
		if l11l1l_l1_ (u"ࠨ࡫ࡱࡸࡪࡸࡥࡴࡶࠪ嫥") in l1ll11l1_l1_: continue
		items = re.findall(l11l1l_l1_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡧࡵࡱࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡷࡼࡹࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡹࡶࡁࠫ嫦"),block,re.DOTALL)
		if l11l1l_l1_ (u"ࠪࡁࡂ࠭嫧") not in l111l1l_l1_: l111l1l_l1_ = url
		if type==l11l1l_l1_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࠨ嫨"):
			if category!=l1ll11l1_l1_: continue
			elif len(items)<=1:
				if l1ll11l1_l1_==l1l11111l_l1_[-1]: l1lllll_l1_(l111l1l_l1_)
				else: l1ll1l1l_l1_(l111l1l_l1_,l11l1l_l1_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࡡࡢࡣࠬ嫩")+l1l11l11_l1_)
				return
			else:
				l1llll1ll_l1_ = l11ll11l1_l1_(l111l1l_l1_,l111lll111l_l1_)
				if l1ll11l1_l1_==l1l11111l_l1_[-1]:
					addMenuItem(l11l1l_l1_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭嫪"),l1111l_l1_+l11l1l_l1_ (u"ࠧศๆฯ้๏฿ࠧ嫫"),l1llll1ll_l1_,561,l11l1l_l1_ (u"ࠨࠩ嫬"),l11l1l_l1_ (u"ࠩࠪ嫭"),l11l1l_l1_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ嫮"))
				else: addMenuItem(l11l1l_l1_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ嫯"),l1111l_l1_+l11l1l_l1_ (u"ࠬอไอ็ํ฽ࠬ嫰"),l111l1l_l1_,564,l11l1l_l1_ (u"࠭ࠧ嫱"),l11l1l_l1_ (u"ࠧࠨ嫲"),l1l11l11_l1_)
		elif type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ嫳"):
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠩࠩࠪࠬ嫴")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠪࡁࡂ࠶ࠧ嫵")
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠫࠫࠬࠧ嫶")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠬࡃ࠽࠱ࠩ嫷")
			l1l11l11_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"࠭࡟ࡠࡡࠪ嫸")+l1l1l1l1_l1_
			addMenuItem(l11l1l_l1_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ嫹"),l1111l_l1_+name+l11l1l_l1_ (u"ࠨ࠼ࠣห้าๅ๋฻ࠪ嫺"),l111l1l_l1_,565,l11l1l_l1_ (u"ࠩࠪ嫻"),l11l1l_l1_ (u"ࠪࠫ嫼"),l1l11l11_l1_+l11l1l_l1_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭嫽"))
		dict[l1ll11l1_l1_] = {}
		for value,option in items:
			name = escapeUNICODE(name)
			option = escapeUNICODE(option)
			if value==l11l1l_l1_ (u"ࠬࡸࠧ嫾") or value==l11l1l_l1_ (u"࠭࡮ࡤ࠯࠴࠻ࠬ嫿"): continue
			if any(value in option.lower() for value in l1l111_l1_): continue
			if l11l1l_l1_ (u"ࠧࡩࡶࡷࡴࠬ嬀") in option: continue
			if l11l1l_l1_ (u"ࠨษ็็้࠭嬁") in option: continue
			if l11l1l_l1_ (u"ࠩࡱ࠱ࡦ࠭嬂") in value: continue
			#if value in [l11l1l_l1_ (u"ࠪࡶࠬ嬃"),l11l1l_l1_ (u"ࠫࡳࡩ࠭࠲࠹ࠪ嬄"),l11l1l_l1_ (u"ࠬࡺࡶ࠮࡯ࡤࠫ嬅")]: continue
			#if l1ll11l1_l1_==l11l1l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ嬆"): option = value
			if option==l11l1l_l1_ (u"ࠧࠨ嬇"): option = value
			l11l11l1l_l1_ = option
			l1l1l1l1lll_l1_ = re.findall(l11l1l_l1_ (u"ࠨ࠾ࡱࡥࡲ࡫࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡯ࡣࡰࡩࡃ࠭嬈"),option,re.DOTALL)
			if l1l1l1l1lll_l1_: l11l11l1l_l1_ = l1l1l1l1lll_l1_[0]
			l1lll11l1_l1_ = name+l11l1l_l1_ (u"ࠩ࠽ࠤࠬ嬉")+l11l11l1l_l1_
			dict[l1ll11l1_l1_][value] = l1lll11l1_l1_
			l1l1ll1l_l1_ = l1l11111_l1_+l11l1l_l1_ (u"ࠪࠪࠫ࠭嬊")+l1ll11l1_l1_+l11l1l_l1_ (u"ࠫࡂࡃࠧ嬋")+l11l11l1l_l1_
			l1l1l1l1_l1_ = l11lllll_l1_+l11l1l_l1_ (u"ࠬࠬࠦࠨ嬌")+l1ll11l1_l1_+l11l1l_l1_ (u"࠭࠽࠾ࠩ嬍")+value
			l1ll111l_l1_ = l1l1ll1l_l1_+l11l1l_l1_ (u"ࠧࡠࡡࡢࠫ嬎")+l1l1l1l1_l1_
			if type==l11l1l_l1_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ嬏"):
				addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬐"),l1111l_l1_+l1lll11l1_l1_,url,565,l11l1l_l1_ (u"ࠪࠫ嬑"),l11l1l_l1_ (u"ࠫࠬ嬒"),l1ll111l_l1_+l11l1l_l1_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ嬓"))
			elif type==l11l1l_l1_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ嬔") and l1l11111l_l1_[-2]+l11l1l_l1_ (u"ࠧ࠾࠿ࠪ嬕") in l1l11111_l1_:
				l11lll11_l1_ = l11lll1l_l1_(l1l1l1l1_l1_,l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嬖"))
				#DIALOG_OK(l11l1l_l1_ (u"ࠩࠪ嬗"),l11l1l_l1_ (u"ࠪࠫ嬘"),l11lll11_l1_,l1l1l1l1_l1_)
				l111ll1_l1_ = url+l11l1l_l1_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ嬙")+l11lll11_l1_
				l1llll1ll_l1_ = l11ll11l1_l1_(l111ll1_l1_,l111lll111l_l1_)
				addMenuItem(l11l1l_l1_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ嬚"),l1111l_l1_+l1lll11l1_l1_,l1llll1ll_l1_,561,l11l1l_l1_ (u"࠭ࠧ嬛"),l11l1l_l1_ (u"ࠧࠨ嬜"),l11l1l_l1_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ嬝"))
			else: addMenuItem(l11l1l_l1_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ嬞"),l1111l_l1_+l1lll11l1_l1_,url,564,l11l1l_l1_ (u"ࠪࠫ嬟"),l11l1l_l1_ (u"ࠫࠬ嬠"),l1ll111l_l1_)
	return
l1l11111l_l1_ = [l11l1l_l1_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫ嬡"),l11l1l_l1_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬ嬢"),l11l1l_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ嬣")]
l11llll1l_l1_ = [l11l1l_l1_ (u"ࠨ࡯ࡳࡥࡦ࠭嬤"),l11l1l_l1_ (u"ࠩࡪࡩࡳࡸࡥࠨ嬥"),l11l1l_l1_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ嬦"),l11l1l_l1_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭嬧"),l11l1l_l1_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾ࠭嬨"),l11l1l_l1_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨ嬩"),l11l1l_l1_ (u"ࠧ࡯ࡣࡷ࡭ࡴࡴࠧ嬪"),l11l1l_l1_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪ嬫")]
def l11ll11l1_l1_(l111l1l_l1_,l111ll1_l1_):
	if l11l1l_l1_ (u"ࠩ࠲ࡅ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠯ࡓ࡫ࡪ࡬ࡹࡈࡡࡳࠩ嬬") in l111l1l_l1_: l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠪ࠳ࡆࡰࡡࡹࡅࡨࡲࡹ࡫ࡲ࠰ࡔ࡬࡫࡭ࡺࡂࡢࡴࠪ嬭"),l11l1l_l1_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡉ࡭ࡱࡺࡥࡳ࡫ࡱ࡫ࠬ嬮"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫ嬯"),l11l1l_l1_ (u"࠭࠺࠻࠱ࡄ࡮ࡦࡾࡃࡦࡰࡷࡩࡷ࠵ࡆࡪ࡮ࡷࡩࡷ࡯࡮ࡨ࠱ࠪ嬰"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠧ࠾࠿ࠪ嬱"),l11l1l_l1_ (u"ࠨ࠱ࠪ嬲"))
	l111l1l_l1_ = l111l1l_l1_.replace(l11l1l_l1_ (u"ࠩࠩࠪࠬ嬳"),l11l1l_l1_ (u"ࠪ࠳ࠬ嬴"))
	return l111l1l_l1_
def l11lll1l_l1_(filters,mode):
	#DIALOG_OK(l11l1l_l1_ (u"ࠫࠬ嬵"),l11l1l_l1_ (u"ࠬ࠭嬶"),filters,l11l1l_l1_ (u"࠭ࡉࡏࠢࠣࠤࠥ࠭嬷")+mode)
	# mode==l11l1l_l1_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩ嬸")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ values
	# mode==l11l1l_l1_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫ嬹")		l1l1l1ll_l1_ l1l11ll1_l1_ l1l1l111_l1_ filters
	# mode==l11l1l_l1_ (u"ࠩࡤࡰࡱ࠭嬺")					all filters (l11ll1l1_l1_ l1l1l111_l1_ filter)
	filters = filters.strip(l11l1l_l1_ (u"ࠪࠪࠫ࠭嬻"))
	l1l1111l_l1_,l1ll1111_l1_ = {},l11l1l_l1_ (u"ࠫࠬ嬼")
	if l11l1l_l1_ (u"ࠬࡃ࠽ࠨ嬽") in filters:
		items = filters.split(l11l1l_l1_ (u"࠭ࠦࠧࠩ嬾"))
		for item in items:
			var,value = item.split(l11l1l_l1_ (u"ࠧ࠾࠿ࠪ嬿"))
			l1l1111l_l1_[var] = value
	for key in l11llll1l_l1_:
		if key in list(l1l1111l_l1_.keys()): value = l1l1111l_l1_[key]
		else: value = l11l1l_l1_ (u"ࠨ࠲ࠪ孀")
		if l11l1l_l1_ (u"ࠩࠨࠫ孁") not in value: value = QUOTE(value)
		if mode==l11l1l_l1_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬ孂") and value!=l11l1l_l1_ (u"ࠫ࠵࠭孃"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠬࠦࠫࠡࠩ孄")+value
		elif mode==l11l1l_l1_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ孅") and value!=l11l1l_l1_ (u"ࠧ࠱ࠩ孆"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠨࠨࠩࠫ孇")+key+l11l1l_l1_ (u"ࠩࡀࡁࠬ孈")+value
		elif mode==l11l1l_l1_ (u"ࠪࡥࡱࡲࠧ孉"): l1ll1111_l1_ = l1ll1111_l1_+l11l1l_l1_ (u"ࠫࠫࠬࠧ孊")+key+l11l1l_l1_ (u"ࠬࡃ࠽ࠨ孋")+value
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"࠭ࠠࠬࠢࠪ孌"))
	l1ll1111_l1_ = l1ll1111_l1_.strip(l11l1l_l1_ (u"ࠧࠧࠨࠪ孍"))
	#DIALOG_OK(l11l1l_l1_ (u"ࠨࠩ孎"),l11l1l_l1_ (u"ࠩࠪ孏"),l1ll1111_l1_,l11l1l_l1_ (u"ࠪࡓ࡚࡚ࠧ子"))
	return l1ll1111_l1_
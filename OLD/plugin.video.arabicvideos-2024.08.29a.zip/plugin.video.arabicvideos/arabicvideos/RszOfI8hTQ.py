# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'ALARAB'
headers = {'User-Agent':eHdDoxhJCEPMZFVa2fg}
r07r9xeEFASJXluImT = '_KLA_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==10: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==11: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	elif mode==12: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==13: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==14: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = Cynto6K3SVucskU()
	elif mode==15: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = vQ2FPqHcKjItxLuRNlbB()
	elif mode==16: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = llfMmBhQsvWcDI6Gwa4S()
	elif mode==19: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,19,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'آخر الإضافات',eHdDoxhJCEPMZFVa2fg,14)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مسلسلات رمضان',eHdDoxhJCEPMZFVa2fg,15)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'ALARAB-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('id="nav-slider"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	GJcex8Cf4P1HEXOZTqMt36Llb = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',GJcex8Cf4P1HEXOZTqMt36Llb,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,11)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="navbar"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	KUTgdRBshwIZcbuv0LVC4 = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',KUTgdRBshwIZcbuv0LVC4,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,11)
	return nR2B1Wye7luXb5
def vQ2FPqHcKjItxLuRNlbB():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'جميع المسلسلات العربية',q3QVhZaDEuo8t2ASj5vkn+'/view-8/مسلسلات-عربية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات السنة الأخيرة',eHdDoxhJCEPMZFVa2fg,16)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان الأخيرة 1',q3QVhZaDEuo8t2ASj5vkn+'/view-8/مسلسلات-رمضان-2022',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان الأخيرة 2',q3QVhZaDEuo8t2ASj5vkn+'/view-8/مسلسلات-رمضان-2023',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2023',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2023/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2022',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2022/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2021',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2021/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2020',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2020/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2019',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2019/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2018',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2018/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2017',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2017/مصرية',11)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات رمضان 2016',q3QVhZaDEuo8t2ASj5vkn+'/ramadan2016/مصرية',11)
	return
def Cynto6K3SVucskU():
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,True,'ALARAB-LATEST-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('heading-top(.*?)div class=',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]+RRztfCIs16MGxEHLJ25vDNAa7hpWT[1]
	items=cBawilJXvK1m.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		url = q3QVhZaDEuo8t2ASj5vkn + apOKrFbP9IYHDyUVm7
		if 'series' in url: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,11,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,url,12,PeLqCN5Ek8bB)
	return
def zRK9ruIt0ZFV4bgi(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,True,True,'ALARAB-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('video-category(.*?)right_content',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	PrQyXW5TAoS = False
	items = cBawilJXvK1m.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz,WBqvysRxwNEk = [],[]
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		if title==eHdDoxhJCEPMZFVa2fg: title = apOKrFbP9IYHDyUVm7.split('/')[-1].replace('-',avcfIls8w7gk69hYUErHxzQTXtm24j)
		VVhKsWQ0jvAS = cBawilJXvK1m.findall('(\d+)',title,cBawilJXvK1m.DOTALL)
		if VVhKsWQ0jvAS: VVhKsWQ0jvAS = int(VVhKsWQ0jvAS[0])
		else: VVhKsWQ0jvAS = 0
		WBqvysRxwNEk.append([PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title,VVhKsWQ0jvAS])
	WBqvysRxwNEk = sorted(WBqvysRxwNEk, reverse=True, key=lambda key: key[3])
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title,VVhKsWQ0jvAS in WBqvysRxwNEk:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn + apOKrFbP9IYHDyUVm7
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('عالية على العرب',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('مشاهدة مباشرة',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('اون لاين',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('اونلاين',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('بجودة عالية',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('جودة عالية',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('بدون تحميل',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('على العرب',eHdDoxhJCEPMZFVa2fg)
		title = title.replace('مباشرة',eHdDoxhJCEPMZFVa2fg)
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		title = '_MOD_'+title
		uVpKOk8ZM0LvQ6UI = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
			if vQ2LDF3UyXZbhu97Y: uVpKOk8ZM0LvQ6UI = vQ2LDF3UyXZbhu97Y[0]
		if uVpKOk8ZM0LvQ6UI not in adU3exogvimBLnCQOwz:
			adU3exogvimBLnCQOwz.append(uVpKOk8ZM0LvQ6UI)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,apOKrFbP9IYHDyUVm7,13,PeLqCN5Ek8bB)
				PrQyXW5TAoS = True
			elif 'series' in apOKrFbP9IYHDyUVm7:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,11,PeLqCN5Ek8bB)
				PrQyXW5TAoS = True
			else:
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,12,PeLqCN5Ek8bB)
				PrQyXW5TAoS = True
	if PrQyXW5TAoS:
		items = cBawilJXvK1m.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,clAzmREWwXf6Gk in items:
			url = q3QVhZaDEuo8t2ASj5vkn + apOKrFbP9IYHDyUVm7
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+clAzmREWwXf6Gk,url,11)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,True,'ALARAB-EPISODES-1st')
	vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73 = cBawilJXvK1m.findall('href="(/series.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73[0]
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(E1Viom5L3684CTOFJ)
	return
def bbmQeYGSTIv(url):
	ppQOjlq2gaPkW = []
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,True,'ALARAB-PLAY-1st')
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('class="resp-iframe" src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if E1Viom5L3684CTOFJ:
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[0]
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('^(http.*?)(http.*?)$',E1Viom5L3684CTOFJ,cBawilJXvK1m.DOTALL)
		if JCZVK86QTYwX4mfgOrod:
			HLjG0evOkWzBoa3F5UXdTi = JCZVK86QTYwX4mfgOrod[0][0]
			oPgEjIWlNLqC4e,nFspgtmrfTMK5Dx = JCZVK86QTYwX4mfgOrod[0][1].rsplit('/',1)
			ajHR9ABQl2buvm = oPgEjIWlNLqC4e+'?named=__watch'
			ppQOjlq2gaPkW.append(ajHR9ABQl2buvm)
			FFZmdCYeVfKwBkMn4qyvcX = HLjG0evOkWzBoa3F5UXdTi+nFspgtmrfTMK5Dx
		else:
			L3f4VRFXh0Sb1xwKPzoi = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,False,'ALARAB-PLAY-2nd')
			E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('"src": "(.*?)"',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			if E1Viom5L3684CTOFJ:
				E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[0]+'?named=__watch__m3u8'
				ppQOjlq2gaPkW.append(E1Viom5L3684CTOFJ)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('searchBox(.*?)<style>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if E1Viom5L3684CTOFJ:
			E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[0]+'?named=__watch'
			ppQOjlq2gaPkW.append(E1Viom5L3684CTOFJ)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def llfMmBhQsvWcDI6Gwa4S():
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,True,'ALARAB-RAMADAN-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="content_sec"(.*?)id="left_content"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	ofmJVwjHC2z4YMNvTthbZ97eEPgs = cBawilJXvK1m.findall('/ramadan([0-9]+)/',str(items),cBawilJXvK1m.DOTALL)
	ofmJVwjHC2z4YMNvTthbZ97eEPgs = ofmJVwjHC2z4YMNvTthbZ97eEPgs[0]
	for apOKrFbP9IYHDyUVm7,title in items:
		url = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)+avcfIls8w7gk69hYUErHxzQTXtm24j+ofmJVwjHC2z4YMNvTthbZ97eEPgs
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,11)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn + "/q/" + diojk6J5vzuRNDKmw
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	return
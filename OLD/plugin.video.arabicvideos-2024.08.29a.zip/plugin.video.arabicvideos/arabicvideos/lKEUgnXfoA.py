# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'BOKRA'
r07r9xeEFASJXluImT = '_BKR_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
headers = {'User-Agent':eHdDoxhJCEPMZFVa2fg}
IVD2kBKhW8FeQLvxUm = ['افلام للكبار','بكرا TV']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==370: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==371: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==372: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==374: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = TOMRqyo9NI1FDfx(url)
	elif mode==375: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = WWASncKJU42IiGCsEpM(url)
	elif mode==376: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = IOzxNVU4jo7kMLXwGeW(0,url)
	elif mode==377: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = IOzxNVU4jo7kMLXwGeW(1,url)
	elif mode==379: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-MENU-1st')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,379,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'قنوات تلفزيونية',q3QVhZaDEuo8t2ASj5vkn+'/al_1103560_1',371)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('right-side(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
				qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المميزة',q3QVhZaDEuo8t2ASj5vkn,375)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الأحدث',q3QVhZaDEuo8t2ASj5vkn,376)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'قائمة الممثلين',q3QVhZaDEuo8t2ASj5vkn,374)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="container"(.*?)top-menu',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items[7:]:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
				qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371)
		for apOKrFbP9IYHDyUVm7,title in items[0:7]:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
				qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371)
	return
def TOMRqyo9NI1FDfx(website=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-ACTORSMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="row cat Tags"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if 'http' in apOKrFbP9IYHDyUVm7: continue
			else: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
				qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371)
	return
def WWASncKJU42IiGCsEpM(website=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-FEATURED-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"MainContent"(.*?)main-title2',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
				PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('://',':///').replace('//','/').replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
				qfpnsHw19BiaSktcXWbGA('video',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,372,PeLqCN5Ek8bB)
	return
def IOzxNVU4jo7kMLXwGeW(id,website=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-WATCHINGNOW-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-title2(.*?)class="row',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[id]
		items = cBawilJXvK1m.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
				PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('://',':///').replace('//','/').replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
				qfpnsHw19BiaSktcXWbGA('video',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,372,PeLqCN5Ek8bB)
	return
def zRK9ruIt0ZFV4bgi(url,kcWMPsL8rTBgnQEoRpmd9yOjXC=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if 'vidpage_' in url:
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('href="(/Album-.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7[0]
			zRK9ruIt0ZFV4bgi(apOKrFbP9IYHDyUVm7)
			return
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class=" subcats"(.*?)class="col-md-3',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if kcWMPsL8rTBgnQEoRpmd9yOjXC==eHdDoxhJCEPMZFVa2fg and RRztfCIs16MGxEHLJ25vDNAa7hpWT and RRztfCIs16MGxEHLJ25vDNAa7hpWT[0].count('href')>1:
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',url,371,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'titles')
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371)
	else:
		adU3exogvimBLnCQOwz = []
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="col-md-3(.*?)col-xs-12',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="col-sm-8"(.*?)col-xs-12',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
				apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('://',':///').replace('//','/').replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
				if '/al_' in apOKrFbP9IYHDyUVm7:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371,PeLqCN5Ek8bB)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) - +الحلقة +\d+',title,cBawilJXvK1m.DOTALL)
					if vQ2LDF3UyXZbhu97Y: title = '_MOD_مسلسل '+vQ2LDF3UyXZbhu97Y[0]
					if title not in adU3exogvimBLnCQOwz:
						adU3exogvimBLnCQOwz.append(title)
						qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371,PeLqCN5Ek8bB)
				else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,372,PeLqCN5Ek8bB)
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="pagination(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('class="".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
				title = 'صفحة '+zJRbA1YW2Eor(title)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,371,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'titles')
	return
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	i2qmOCHN5goZ = cBawilJXvK1m.findall('label-success mrg-btm-5 ">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	ajHR9ABQl2buvm = eHdDoxhJCEPMZFVa2fg
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('var url = "(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[0]
	else: E1Viom5L3684CTOFJ = url.replace('/vidpage_','/Play/')
	if 'http' not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+E1Viom5L3684CTOFJ
	E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.strip('-')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'BOKRA-PLAY-2nd')
	L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
	ajHR9ABQl2buvm = cBawilJXvK1m.findall('src="(.*?)"',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
	if ajHR9ABQl2buvm:
		ajHR9ABQl2buvm = ajHR9ABQl2buvm[-1]
		if 'http' not in ajHR9ABQl2buvm: ajHR9ABQl2buvm = 'http:'+ajHR9ABQl2buvm
		if '/PLAY/' not in E1Viom5L3684CTOFJ:
			if 'embed.min.js' in ajHR9ABQl2buvm:
				mEC2f4s1SGhZg9VAqnpO = cBawilJXvK1m.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
				if mEC2f4s1SGhZg9VAqnpO:
					P8PCKzNBjS7nhJMa, JP5Ns0MciGROXb4aoz2E6Vxngyd = mEC2f4s1SGhZg9VAqnpO[0]
					ajHR9ABQl2buvm = b31wAB8mhaz2rXHoJFlfvDugtsOj(ajHR9ABQl2buvm,'url')+'/v2/'+P8PCKzNBjS7nhJMa+'/config/'+JP5Ns0MciGROXb4aoz2E6Vxngyd+'.json'
		import SOnwRtkA74
		SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA([ajHR9ABQl2buvm],EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/Search/'+search
	zRK9ruIt0ZFV4bgi(url)
	return
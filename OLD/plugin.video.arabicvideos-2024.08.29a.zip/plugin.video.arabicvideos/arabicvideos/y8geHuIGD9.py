# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'TVFUN'
r07r9xeEFASJXluImT = '_TVF_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['بث مباشر']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==460: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==461: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==462: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==463: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==469: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'TVFUN-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,469,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"menu-btn"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in IVD2kBKhW8FeQLvxUm: continue
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,461)
	return
def zRK9ruIt0ZFV4bgi(url,ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=eHdDoxhJCEPMZFVa2fg):
	items = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'TVFUN-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="head-title"(.*?)id="footer"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		adU3exogvimBLnCQOwz = []
		L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			title = '_MOD_'+title.replace('<br>',avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,462,PeLqCN5Ek8bB)
			elif vQ2LDF3UyXZbhu97Y and 'الحلقة' in title:
				title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
				if title not in adU3exogvimBLnCQOwz:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,463,PeLqCN5Ek8bB)
					adU3exogvimBLnCQOwz.append(title)
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,463,PeLqCN5Ek8bB)
	if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR!='latest':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('<a href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				if apOKrFbP9IYHDyUVm7=="": continue
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
				if title!=eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,461)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'TVFUN-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="head-title"(.*?)id="footer"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('class="thumb.*?href="(.*?)".*?src="(.*?)".*?">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if items:
			for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
				title = '_MOD_'+title.replace('<br>',avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,462,PeLqCN5Ek8bB)
		else:
			items = cBawilJXvK1m.findall('class="episode.*?href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,462)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if apOKrFbP9IYHDyUVm7=="": continue
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if title!=eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,463)
	return
def bbmQeYGSTIv(url):
	ppQOjlq2gaPkW = []
	E1Viom5L3684CTOFJ = url.replace('/video/','/watch/')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'TVFUN-PLAY-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('VideoServers"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for t35lCdQaSIhWZ8r4npj,name in JCZVK86QTYwX4mfgOrod:
			t35lCdQaSIhWZ8r4npj = t35lCdQaSIhWZ8r4npj[2:]
			if lHfbysRrUV7m4CLSdkxc382n: t35lCdQaSIhWZ8r4npj = t35lCdQaSIhWZ8r4npj.decode(m6PFtLblInpNZ8x)
			t35lCdQaSIhWZ8r4npj = HHP76VFiKDS2xphlGsqN48j1.b64decode(t35lCdQaSIhWZ8r4npj)
			if WHjh1POtMKlmgiy68RSqb: t35lCdQaSIhWZ8r4npj = t35lCdQaSIhWZ8r4npj.decode(m6PFtLblInpNZ8x)
			apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('src="(.*?)"',t35lCdQaSIhWZ8r4npj,cBawilJXvK1m.DOTALL)
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
			if 'http' not in apOKrFbP9IYHDyUVm7:
				if '//' in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
				else: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			if apOKrFbP9IYHDyUVm7 not in ppQOjlq2gaPkW:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+name+'__watch'
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	if avcfIls8w7gk69hYUErHxzQTXtm24j in search:
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = q3QVhZaDEuo8t2ASj5vkn+'/q/'+search+'/'
	zRK9ruIt0ZFV4bgi(url)
	return
# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from dIxmaLQn3F import *
EERWJf1adv67 = I5bUBGpPXn0W6(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨॼ")
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(tWi3JH8rRhxcgnYuMVUK,bkA4Xjzw7mJa=eHdDoxhJCEPMZFVa2fg):
	if   tWi3JH8rRhxcgnYuMVUK==HkiMU0QrdzW3l6gwnT(u"࠱ౝ"): XDVL1fTdwRsZA7iWIn(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==LyOR7f69iA(u"࠳౞"): pass
	elif tWi3JH8rRhxcgnYuMVUK==KW5bYS20wTF1LyCs9(u"࠵౟"): kExW7f8PlyVi34NbOYXd(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠷ౠ"): HsdI7rJfXyDajB()
	elif tWi3JH8rRhxcgnYuMVUK==LTN6DPEmrwehtZMy(u"࠹ౡ"): BLz9sPWkqKcpnaEJhiyT8d3gojY7mA(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠻ౢ"): NDBtXxOp05sJ3F48IEwHMhqPa()
	elif tWi3JH8rRhxcgnYuMVUK==J7divaGOCgq2SLfXpDzZYN58wc(u"࠶ౣ"): R0DwTL8OCnWbP3aSoYF2()
	elif tWi3JH8rRhxcgnYuMVUK==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠸౤"): O0NLWgDywb3tZpYdjuM1c()
	elif tWi3JH8rRhxcgnYuMVUK==LTN6DPEmrwehtZMy(u"࠺౥"): TEcDqAKpHm7rwByS5lGf8NoWPbhj6()
	elif tWi3JH8rRhxcgnYuMVUK==jUcmHhgVvW0EdYOIfXeaDF(u"࠼౦"): A3X4IBQDaVzsf()
	elif tWi3JH8rRhxcgnYuMVUK==I5bUBGpPXn0W6(u"࠵࠺࠶౧"): GihVylwKIxma019czL8kTuW()
	elif tWi3JH8rRhxcgnYuMVUK==XugxFprC26zGM(u"࠶࠻࠱౨"): EElnUxkvM8p()
	elif tWi3JH8rRhxcgnYuMVUK==bP01xn84BiQN(u"࠷࠵࠳౩"): jgudbODHEasWyxFIceqpQNrB9wP()
	elif tWi3JH8rRhxcgnYuMVUK==KQ3sCe9Pzh(u"࠱࠶࠵౪"): bGsIrdyjE9k6Vh()
	elif tWi3JH8rRhxcgnYuMVUK==Cp6c5tZe8I0PxnAW(u"࠲࠷࠷౫"): uKh8rUFTHSGi1tEvIpo32BXN95Jy()
	elif tWi3JH8rRhxcgnYuMVUK==RqLvTrID0yMVeClpYcnZ16i3X(u"࠳࠸࠹౬"): JCFXSBNPu809MniR7OAEf1zebK3()
	elif tWi3JH8rRhxcgnYuMVUK==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴࠹࠻౭"): Tbzw54Kc8JBgtA()
	elif tWi3JH8rRhxcgnYuMVUK==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠵࠺࠽౮"): VFjcJd0ZROysuEAxt7lf6()
	elif tWi3JH8rRhxcgnYuMVUK==CKUiyEe28zsZ(u"࠶࠻࠸౯"): R9ABWE5Vw7OazD2k0M()
	elif tWi3JH8rRhxcgnYuMVUK==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠷࠵࠺౰"): wzPWYBIF8EsxJjog3DQpetGv9407h(YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==KQ3sCe9Pzh(u"࠱࠸࠲౱"): ttoCNWqlOrS7MFb2dH()
	elif tWi3JH8rRhxcgnYuMVUK==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠲࠹࠴౲"): clHVSyZfYezbpMhd8B()
	elif tWi3JH8rRhxcgnYuMVUK==wY1p9mP03S8drbcH64t5WQkv(u"࠳࠺࠶౳"): kF1GfABotWd([bkA4Xjzw7mJa],YchIv6N09BaWPEj4tieAnluKZrRXT,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
	elif tWi3JH8rRhxcgnYuMVUK==I5bUBGpPXn0W6(u"࠴࠻࠸౴"): oIUetMrjGswW21QNiHSJgK3mnCd0D(XugxFprC26zGM(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧॽ"),YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠵࠼࠺౵"): oIUetMrjGswW21QNiHSJgK3mnCd0D(ilBWK5nXxg1do4jENGC07Zq(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠫॾ"),YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==ietolwsjpIPK7Fr(u"࠶࠽࠵౶"): P8P3BbMSNTe5()
	elif tWi3JH8rRhxcgnYuMVUK==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠷࠷౷"): zYlxb0KydPUaqw7WGh134QFNZjL()
	elif tWi3JH8rRhxcgnYuMVUK==KW5bYS20wTF1LyCs9(u"࠱࠸࠹౸"): ezW8AjIMi2mLFBGPuUT4o5Y73VZO(jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭ॿ"))
	elif tWi3JH8rRhxcgnYuMVUK==LyOR7f69iA(u"࠲࠹࠻౹"): ezW8AjIMi2mLFBGPuUT4o5Y73VZO(HkiMU0QrdzW3l6gwnT(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲࠪঀ"))
	elif tWi3JH8rRhxcgnYuMVUK==ehfEsaiJBSvbcULtNPVgykA2(u"࠳࠺࠽౺"): ezW8AjIMi2mLFBGPuUT4o5Y73VZO(ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫঁ"))
	elif tWi3JH8rRhxcgnYuMVUK==w2vjZmdJuY7c(u"࠴࠽࠵౻"): k8B273ZKPbostnFNRDVf()
	elif tWi3JH8rRhxcgnYuMVUK==ehfEsaiJBSvbcULtNPVgykA2(u"࠵࠾࠷౼"): EP2ZUvDOb6hoa4GLnVFqyCH()
	elif tWi3JH8rRhxcgnYuMVUK==NxXMrsTC5FniYuRBOK8(u"࠶࠿࠲౽"): CdJ6uvjN1HP497fD5EzcXOkTBx()
	elif tWi3JH8rRhxcgnYuMVUK==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠹࠴౾"): LsVaoqUXzKMeQr()
	elif tWi3JH8rRhxcgnYuMVUK==eNEhtuoi9gK8JaTpIXj(u"࠱࠺࠶౿"): qyOVGw4i8xTKXMZBS02bz7s1Irgo()
	elif tWi3JH8rRhxcgnYuMVUK==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠲࠻࠸ಀ"): w8wafJRQI1rx()
	elif tWi3JH8rRhxcgnYuMVUK==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠳࠼࠺ಁ"): b8UtiZFoxan()
	elif tWi3JH8rRhxcgnYuMVUK==EX25Y0l8ILvz7QcRC(u"࠴࠽࠼ಂ"): XJdD17jzA6PYM9hGlyUi0osWep3()
	elif tWi3JH8rRhxcgnYuMVUK==KQ3sCe9Pzh(u"࠵࠾࠾ಃ"): JLtVuawiI3rBxAj()
	elif tWi3JH8rRhxcgnYuMVUK==XugxFprC26zGM(u"࠶࠿࠹಄"): pkNuKl7BxPhGI5Zd6A()
	elif tWi3JH8rRhxcgnYuMVUK==wY1p9mP03S8drbcH64t5WQkv(u"࠹࠴࠱ಅ"): Irw8xd6mzk9nbjcsVEt3lqTQYLJKZ(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳࠵࠳ಆ"): Zfw4yEWTN5ImUb1()
	elif tWi3JH8rRhxcgnYuMVUK==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠴࠶࠵ಇ"): Aj7yzac3Q80r9BEWUReqZPgk6FLus()
	elif tWi3JH8rRhxcgnYuMVUK==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠵࠷࠷ಈ"): HZ31MlfKwuBiVNOzdWGSgx6L()
	elif tWi3JH8rRhxcgnYuMVUK==HkiMU0QrdzW3l6gwnT(u"࠶࠸࠹ಉ"): UmpHKfuB5Z9R(YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠹࠻ಊ"): vuPnztZ9xRm8Fdo2wy54()
	elif tWi3JH8rRhxcgnYuMVUK==S8i3sBYoHWdTURpAgN(u"࠸࠺࠶ಋ"): JaCYQh0Kf29q7LbmT5geG(rDceXBpHkfVUYRJ3tIx95Z)
	elif tWi3JH8rRhxcgnYuMVUK==I5bUBGpPXn0W6(u"࠹࠴࠸ಌ"): bo8mpKfd5eaERB32vGz(YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==I5bUBGpPXn0W6(u"࠳࠵࠺಍"): HFNcyvKhjXJWqlCbaoU1Y()
	elif tWi3JH8rRhxcgnYuMVUK==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴࠶࠼ಎ"): ookShtBC417XNw(eNEhtuoi9gK8JaTpIXj(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪং"),YchIv6N09BaWPEj4tieAnluKZrRXT,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==jUcmHhgVvW0EdYOIfXeaDF(u"࠷࠳࠴ಏ"): Qs1kdXS74HZvD()
	elif tWi3JH8rRhxcgnYuMVUK==w2vjZmdJuY7c(u"࠸࠴࠶ಐ"): tzjPl3G2n5U9pMcsSeXv6quh()
	elif tWi3JH8rRhxcgnYuMVUK==RqLvTrID0yMVeClpYcnZ16i3X(u"࠹࠵࠸಑"): Fpxmz3y9f6YTPrtn8Olv41XiGEI()
	elif tWi3JH8rRhxcgnYuMVUK==ehfEsaiJBSvbcULtNPVgykA2(u"࠺࠶࠳ಒ"): mUStRJZCOVXhxLp2NEq(s4FvMNOledIt)
	elif tWi3JH8rRhxcgnYuMVUK==XugxFprC26zGM(u"࠻࠰࠵ಓ"): mUStRJZCOVXhxLp2NEq(CCknZTXVNbG9Px0ds1hpQSMKB)
	elif tWi3JH8rRhxcgnYuMVUK==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠵࠱࠷ಔ"): e5efEgoWkFrniQMOH0TdIy8xR()
	elif tWi3JH8rRhxcgnYuMVUK==LyOR7f69iA(u"࠶࠲࠹ಕ"): wJ0l2uCDMF8IiEzsvykhP(YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠷࠳࠻ಖ"): pass
	elif tWi3JH8rRhxcgnYuMVUK==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠸࠴࠽ಗ"): ac4LiOnJPmEK()
	elif tWi3JH8rRhxcgnYuMVUK==S8i3sBYoHWdTURpAgN(u"࠹࠵࠿ಘ"): E2BwJXI0jLYMNkRmrFofgec()
	return
def E2BwJXI0jLYMNkRmrFofgec():
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩঃ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"่ࠧๆࠣฮึ๐ฯࠡใ฼่ฬࠦๅิฯࠣะ๊๐ูࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤ࠳࠴้ࠠ็ึัࠥาๅ๋฻้้ࠣ็วหࠢส่อืๆศ็ฯࠤฬ๊โะ์่อࠥ࠴࠮ࠡๆๆ๎ࠥ๐ู้ัࠣห้ฮั็ษ่ะࠥหไ๊ࠢะห้ฯࠠศๆุๅึࠦ࠮࠯ࠢํ฽๋๐ࠠหฮา๎ิࠦวๅสิ๊ฬ๋ฬ๊ࠡอูๆ๐ั่๋ࠢ์฻฿็ࠡสะห้ฯࠠศๆู่๋฿ࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะࠥลࠡࠢࠩ঄"))
	if zf7iFX1auw0bQU:
		UmpHKfuB5Z9R(rDceXBpHkfVUYRJ3tIx95Z)
		ycgRbjNoPLQSnx(oX9h2wrQe5,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫঅ"),NxXMrsTC5FniYuRBOK8(u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤฬ๊ๅึ่฼ࠫআ"))
	return
def e5efEgoWkFrniQMOH0TdIy8xR():
	k5L96NenKBwpSYWv(pyifuNFdxe,KQ3sCe9Pzh(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ই"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧঈ"))
	pg2HKT7OyfiMWL6 = K89FakvRdrtXhmnDE7O(rDceXBpHkfVUYRJ3tIx95Z)
	Q5PpO4GlMX9hno08rzxyWA = kDUv7ouWrcgMe6OipQJm
	LuT4b0C67reXdZh = OR97bMGecfgDCqux3YdAZ6y+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩউ")+Nat0Dx9puRUWCsgz6JyFhY3
	bxhTo102knrI7a45B8XQYMp9WdEw = kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+I5bUBGpPXn0W6(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪঊ")+Nat0Dx9puRUWCsgz6JyFhY3+XugxFprC26zGM(u"ࠧ࡝ࡰ࡟ࡲࠬঋ")
	for id,pcG48moFZkRT1Iz7DJaYOqtB,YSrPiRzTntg3kwsH86xvm0oZf9,Geo8WC6xHmhPAwQMXpZd,vR5ZcIituWPYQLwyeab2oOsg,reason in reversed(pg2HKT7OyfiMWL6):
		if id==LyOR7f69iA(u"ࠨ࠲ࠪঌ"):
			yjD0T8Ye32coaKrR5Z679,l91ODotRve30i64 = Geo8WC6xHmhPAwQMXpZd.split(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩ࡟ࡲࡀࡁࠧ঍"))
			continue
		if Q5PpO4GlMX9hno08rzxyWA!=kDUv7ouWrcgMe6OipQJm: Q5PpO4GlMX9hno08rzxyWA += bxhTo102knrI7a45B8XQYMp9WdEw
		z7zRKcweSZAk = bP01xn84BiQN(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ঎")+OR97bMGecfgDCqux3YdAZ6y+id+LyOR7f69iA(u"ࠫࠥࡀࠠࠨএ")+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬอไิฦส่ࠥࡀࠠࠨঐ")+Nat0Dx9puRUWCsgz6JyFhY3+YSrPiRzTntg3kwsH86xvm0oZf9
		bYrLlO9uMs5tm0IGFhK2v = ietolwsjpIPK7Fr(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧ঑")+OR97bMGecfgDCqux3YdAZ6y+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪ঒")+Nat0Dx9puRUWCsgz6JyFhY3+Geo8WC6xHmhPAwQMXpZd
		i25MesXmlJoQNOgLPbIqDrVvG9 = S8i3sBYoHWdTURpAgN(u"ࠨ࡝ࡕࡘࡑࡣࠧও")+OR97bMGecfgDCqux3YdAZ6y+KQ3sCe9Pzh(u"ࠩส่ำ฽รࠡ࠼ࠣࠫঔ")+Nat0Dx9puRUWCsgz6JyFhY3+vR5ZcIituWPYQLwyeab2oOsg
		NtYlMGwxjLczOC41yKSv = NxXMrsTC5FniYuRBOK8(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫক")+OR97bMGecfgDCqux3YdAZ6y+S8i3sBYoHWdTURpAgN(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭খ")+Nat0Dx9puRUWCsgz6JyFhY3+reason
		Q5PpO4GlMX9hno08rzxyWA += z7zRKcweSZAk+bYrLlO9uMs5tm0IGFhK2v+kDUv7ouWrcgMe6OipQJm+LuT4b0C67reXdZh+kDUv7ouWrcgMe6OipQJm+i25MesXmlJoQNOgLPbIqDrVvG9+NtYlMGwxjLczOC41yKSv+kDUv7ouWrcgMe6OipQJm
	YTUtDCvHs6eQEPi1FJ(KW5bYS20wTF1LyCs9(u"ࠬࡸࡩࡨࡪࡷࠫগ"),l91ODotRve30i64,Q5PpO4GlMX9hno08rzxyWA,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧঘ"))
	return
def mUStRJZCOVXhxLp2NEq(file):
	if file==CCknZTXVNbG9Px0ds1hpQSMKB: MvtFVlGzBu0Ro = KQ3sCe9Pzh(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧঙ")
	elif file==s4FvMNOledIt: MvtFVlGzBu0Ro = S8i3sBYoHWdTURpAgN(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨচ")
	iL3sKTVC7EZgM9kDajU1FYGBqWrdc = vKD1rqZCXUbcR7n38VyatMSEL(egY8Jti0smdLM3h1VQRSW(u"ࠩࡦࡩࡳࡺࡥࡳࠩছ"),LyOR7f69iA(u"ุ้ࠪำࠧজ"),ietolwsjpIPK7Fr(u"ࠫส฻ไศฯࠪঝ"),S8i3sBYoHWdTURpAgN(u"ࠬิั้ฮࠪঞ"),t3coAp06zvHrTl49bUVgx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩট"),eNEhtuoi9gK8JaTpIXj(u"่ࠧๆࠣฮึ๐ฯࠡวุ่ฬำࠠๆๆไࠤࠬঠ")+MvtFVlGzBu0Ro+NxXMrsTC5FniYuRBOK8(u"ࠨࠢฦ้ࠥะั๋ัุ้ࠣำࠠศๆ่่ๆࠦฟࠨড"))
	if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠵ಙ"):
		if RRydns1CErYlIhwSx7.path.exists(file):
			try: RRydns1CErYlIhwSx7.remove(file)
			except: pass
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬঢ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪฮ๊ࠦๅิฯ้้ࠣ็ࠠࠨণ")+MvtFVlGzBu0Ro)
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==f90fGrlSEObDsuiA3U(u"࠷ಚ"):
		data = ssIBAWh7QmzOoXqk8w(file)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧত"),bP01xn84BiQN(u"ࠬะๅࠡวุ่ฬำࠠๆๆไࠤࠬথ")+MvtFVlGzBu0Ro)
	return
def tzjPl3G2n5U9pMcsSeXv6quh():
	if YB5Segc7IQ<S8i3sBYoHWdTURpAgN(u"࠱࠹ಛ"):
		sh3cDaZzUkKQFEAl74OryuPtGqJ = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ไๅลึๅࠥษๆหࠢอืฯิฯๆࠢศูิอัࠡๅ๋ำ๏ࠦโะ์่ࠤึ่ๅࠡࠩদ")+str(YB5Segc7IQ)+NxXMrsTC5FniYuRBOK8(u"๊ࠧࠡ็๋ีอࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢ็หࠥะูๆๆࠣ฽๋ีใࠡ࠰๋ࠣีํࠠศๆ่๎ืฯࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦวๅใํำ๏๎็ศฬࠣๅ๏ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠡ࠰่ࠣส฻ไศฯࠣห้๋ิไๆฬࠤ็๋ࠠษฬะำ๏ัࠠษำ้ห๊าࠠไ๊า๎ࠥหไ๊ࠢศ๎ࠥหีะษิࠤึ่ๅ่ࠢฦ฽้๏ࠠๆ่ࠣ࠵࠽࠴࠰ࠨধ")
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫন"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
		return
	SjmNBbHlIezGr2URoEp3f = ccwRLKk3hs0E.executeJSONRPC(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡋࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡬ࡰࡱ࡮ࡥࡳࡪࡦࡦࡧ࡯࠲ࡸࡱࡩ࡯ࠤࢀࢁࠬ঩"))
	H8hMP0qweGaor3OJjWBVzT = w1HecvLmKCBrR95ASN([TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩপ")])
	VVe7Ii8ZmuK6,bNwg0h1Ck3dO,DMhZuzftA7SqiELpPJjl59GYd,CKR50BlaJw6FEv2xV,iKxpIgQ3c70oYfaMqG52Stnhd9,TwIq7nXyl1jJW9S5u,ZZdbpjXLNf0RSC76 = H8hMP0qweGaor3OJjWBVzT[KQ3sCe9Pzh(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪফ")]
	if VVe7Ii8ZmuK6 or wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫব") not in str(SjmNBbHlIezGr2URoEp3f):
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩভ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠧศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬম"))
		gZdOM2jYEfV = Fpxmz3y9f6YTPrtn8Olv41XiGEI()
		if not gZdOM2jYEfV: return
	jIr2tJV5b1xG3RueTMD9NcBdz4k(YchIv6N09BaWPEj4tieAnluKZrRXT)
	return
def jIr2tJV5b1xG3RueTMD9NcBdz4k(showDialogs=YchIv6N09BaWPEj4tieAnluKZrRXT):
	SjmNBbHlIezGr2URoEp3f = ccwRLKk3hs0E.executeJSONRPC(HkiMU0QrdzW3l6gwnT(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫয"))
	if HkiMU0QrdzW3l6gwnT(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨর") not in str(SjmNBbHlIezGr2URoEp3f):
		if showDialogs:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭঱"),ilBWK5nXxg1do4jENGC07Zq(u"้๊ࠫริใࠣะ์อาไࠢ็หࠥ๐ำหะา้ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦสฺ็็ࠤๆ่ืࠡ็฼ࠤั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰๋ࠣีํࠠศๆๅ์ฬฬๅࠡฬ่็๋้ࠠๆ่ࠣีษ๐ษࠡไ๋หห๋ࠠษำ้ห๊าฺࠠ็สำࠥฮิไๆูࠣํืࠠษั็ห๋ࠥๆࠡษ็็ฯอศสࠩল"))
		return
	yevnk9wTLxN1Ps = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,f90fGrlSEObDsuiA3U(u"ࠬࡧࡤࡥࡱࡱࡷࠬ঳"),eNEhtuoi9gK8JaTpIXj(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬ঴"),Cp6c5tZe8I0PxnAW(u"ࠧ࠸࠴࠳ࡴࠬ঵"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡏࡼ࡚࡮ࡪࡥࡰࡐࡤࡺ࠳ࡾ࡭࡭ࠩশ"))
	if not RRydns1CErYlIhwSx7.path.exists(yevnk9wTLxN1Ps): return
	xV71kwLiJqS9UjdKEbun0OZG8TlA = open(yevnk9wTLxN1Ps,t3coAp06zvHrTl49bUVgx(u"ࠩࡵࡦࠬষ")).read()
	if WHjh1POtMKlmgiy68RSqb: xV71kwLiJqS9UjdKEbun0OZG8TlA = xV71kwLiJqS9UjdKEbun0OZG8TlA.decode(m6PFtLblInpNZ8x)
	qGiUHuXba1 = cBawilJXvK1m.findall(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡀࡻ࡯ࡥࡸࡵࡁࠬࡡࡪࠫ࠭࡞ࡧ࠯࠱ࡢࡤࠬࠫ࠯ࠬ࠳࠰࠿ࠪ࠾࠲ࡺ࡮࡫ࡷࡴࡀࠪস"),xV71kwLiJqS9UjdKEbun0OZG8TlA,cBawilJXvK1m.DOTALL)
	Q6D81tKiZmqIsMfXajuBxRyr,xiwfZsQCWDtKopAR = qGiUHuXba1[x1Oa8bBf36EwsLMirtFc]
	YuBQtS7I2sk4xf = CKUiyEe28zsZ(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬহ")+Q6D81tKiZmqIsMfXajuBxRyr+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬ࠲ࠧ঺")+xiwfZsQCWDtKopAR+KQ3sCe9Pzh(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨ঻")
	if showDialogs:
		IRndo3NKebXm2FvEau = ccwRLKk3hs0E.getInfoLabel(jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡚࡮࡫ࡷ࡮ࡱࡧࡩ়ࠬ"))
		if IRndo3NKebXm2FvEau==f90fGrlSEObDsuiA3U(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫঽ"): SlrwkhXv4QePoxDst = I5bUBGpPXn0W6(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩা")
		elif IRndo3NKebXm2FvEau==CKUiyEe28zsZ(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩি"): SlrwkhXv4QePoxDst = NxXMrsTC5FniYuRBOK8(u"ࠫ็๎วว็ࠣห้฻่าࠩী")
		else: SlrwkhXv4QePoxDst = LyOR7f69iA(u"่่ࠬศศ่ࠤศิั๊ࠩু")
		iL3sKTVC7EZgM9kDajU1FYGBqWrdc = vKD1rqZCXUbcR7n38VyatMSEL(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ূ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧใ๊สส๊ࠦรฯำ์ࠫৃ"),ietolwsjpIPK7Fr(u"ࠨไ๋หห๋ࠠศๆๆฮฬฮษࠨৄ"),XugxFprC26zGM(u"ࠩๅ์ฬฬๅࠡษ็ูํืࠧ৅"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪห๋ะࠠฮษ็๎ฬࠦสิฬัำ๊ࠦࠧ৆")+SlrwkhXv4QePoxDst,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫฬ์สࠡษ็ฦ๋ࠦสิฬัำ๊ࠦวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴้้ࠠำหู๋ࠥ็ษ๊ࠤฬ์ใࠡฬึฮ฼๐ูࠡษึฮำีวๆࠢส่็๎วว็ࠣห้๋ี้ำฬࠤอีไศ่๊่่ࠢࠥศศ่ࠤฬ๊ใหษหอࠥ࠴้ࠠลํฺฬࠦสิฬฺ๎฾ࠦล๋ไสๅ์อࠠโ์ࠣว๏่ࠦใฬࠣฮูอมࠡ࡞ࡱࡠࡳࠦࠧে")+OR97bMGecfgDCqux3YdAZ6y+egY8Jti0smdLM3h1VQRSW(u"ࠬࠦรฯฬิࠤฬ๊ย็้ࠢ์฾ࠦวๅไ๋หห๋ࠠศๆอ๎ࠥะั๋ัࠣวุะฮะษ่๋ฬࠦฟࠢࠩৈ")+Nat0Dx9puRUWCsgz6JyFhY3)
		if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==LTN6DPEmrwehtZMy(u"࠲ಜ"): IU0GzOjnmS = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ৉")
		elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==KQ3sCe9Pzh(u"࠴ಝ"): IU0GzOjnmS = KW5bYS20wTF1LyCs9(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭৊")
		else: IU0GzOjnmS = eHdDoxhJCEPMZFVa2fg
	else:
		IRndo3NKebXm2FvEau = MoO74hKeqm8fFka.getSetting(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭ো"))
		if   IRndo3NKebXm2FvEau==eHdDoxhJCEPMZFVa2fg: iL3sKTVC7EZgM9kDajU1FYGBqWrdc = RqLvTrID0yMVeClpYcnZ16i3X(u"࠳ಞ")
		elif IRndo3NKebXm2FvEau==Cp6c5tZe8I0PxnAW(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬৌ"): iL3sKTVC7EZgM9kDajU1FYGBqWrdc = LTN6DPEmrwehtZMy(u"࠵ಟ")
		elif IRndo3NKebXm2FvEau==KW5bYS20wTF1LyCs9(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺ্ࠩ"): iL3sKTVC7EZgM9kDajU1FYGBqWrdc = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠷ಠ")
		IU0GzOjnmS = IRndo3NKebXm2FvEau
	if   iL3sKTVC7EZgM9kDajU1FYGBqWrdc==HkiMU0QrdzW3l6gwnT(u"࠶ಡ"): tS8BcuTjZOvG3gfMEhU5rmJb = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫ࠺࠻ࠬ࠶࠶࠷࠰࠺࠻࠵ࠨৎ")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠱ಢ"): tS8BcuTjZOvG3gfMEhU5rmJb = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬ࠻࠴࠵࠮࠸࠹࠺࠲࠵࠶ࠩ৏")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==S8i3sBYoHWdTURpAgN(u"࠳ಣ"): tS8BcuTjZOvG3gfMEhU5rmJb = S8i3sBYoHWdTURpAgN(u"࠭࠵࠶࠷࠯࠹࠺࠲࠵࠵࠶ࠪ৐")
	else: return
	MoO74hKeqm8fFka.setSetting(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬ৑"),IU0GzOjnmS)
	tiwckF9g5v3sMayn4x = ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࠾ࡹ࡭ࡪࡽࡳ࠿ࠩ৒")+tS8BcuTjZOvG3gfMEhU5rmJb+ehfEsaiJBSvbcULtNPVgykA2(u"ࠩ࠯ࠫ৓")+xiwfZsQCWDtKopAR+KQ3sCe9Pzh(u"ࠪࡀ࠴ࡼࡩࡦࡹࡶࡂࠬ৔")
	tYuVyvxLPqAg1r = xV71kwLiJqS9UjdKEbun0OZG8TlA.replace(YuBQtS7I2sk4xf,tiwckF9g5v3sMayn4x)
	if WHjh1POtMKlmgiy68RSqb: tYuVyvxLPqAg1r = tYuVyvxLPqAg1r.encode(m6PFtLblInpNZ8x)
	open(yevnk9wTLxN1Ps,jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡼࡨࠧ৕")).write(tYuVyvxLPqAg1r)
	vR9cOpMtk51j(iwIlVQsgYezu,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬ࠴࡜ࡵࡕ࡮࡭ࡳࠦࡄࡦࡨࡤࡹࡱࡺࠠࡗ࡫ࡨࡻࡸࡀࠠ࡜ࠢࠪ৖")+tS8BcuTjZOvG3gfMEhU5rmJb+EX25Y0l8ILvz7QcRC(u"࠭ࠠ࡞ࠩৗ"))
	if showDialogs: ccwRLKk3hs0E.executebuiltin(KW5bYS20wTF1LyCs9(u"ࠧࡓࡧ࡯ࡳࡦࡪࡓ࡬࡫ࡱࠬ࠮࠭৘"))
	return
def Qs1kdXS74HZvD():
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ৙"),S8i3sBYoHWdTURpAgN(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧ৚"))
	if zf7iFX1auw0bQU==egY8Jti0smdLM3h1VQRSW(u"࠳ತ"): O0NLWgDywb3tZpYdjuM1c()
	return
def TEcDqAKpHm7rwByS5lGf8NoWPbhj6():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭৛"),ilBWK5nXxg1do4jENGC07Zq(u"ࠫ์ึวࠡษ็้ํู่ࠡ็฽่็ࠦๅ็ࠢส่๊฻ฯา๋ࠢ฾๏ืࠠๆ฻ิ์ๆࠦๅห์ࠣ๎ึาูࠡๆ็฽๊๊ࠧড়"))
	return
def HFNcyvKhjXJWqlCbaoU1Y():
	z7zRKcweSZAk = OR97bMGecfgDCqux3YdAZ6y+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬะูะษาࠤู๐ูสࠢล่๋ࠥอๆัุ่ࠣ์ษࠡ࠴࠳࠶࠶ࠦ࠺ࠡࠩঢ়")+Nat0Dx9puRUWCsgz6JyFhY3
	z7zRKcweSZAk += ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭วๅ็๋ๆ฾ࠦระ่ส๋ࠥ็๊่ࠢศัฺอฦ๋ห่ࠣ฾ีฯࠡษ็ุ๏฿ษࠡใํࠤฬู๊ศๆ่ࠤฯ๋ࠠอ็฼๋ฬࠦๅ็ࠢฯ้๏฿ࠠศๆู่ฬีัࠡษ็้ฯ๎แาหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็ๆิ๐ๅส๋ࠢห้าฯ๋ัฬࠤฬ๊อไ๊่๎ฮ่ࠦศๆ฽๎ึࠦอไ๊่๎ฮ่ࠦๆ่ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥัๅࠡฬ่ࠤฯ๎อ๋ั๊หࠥ๎อิษหࠤฬ๊ๅฺั็ࠤาูศࠡีๆห๋ࠦฯ้ๆࠣห้฿วๅ็ุ่ࠣ์ษࠡ࠴࠳࠶࠶่่ࠦ์ࠣห้หอึษษ๎ฮࠦวๅละำะ่ࠦศๆฦุ๊๊ࠠศๆอ๎ࠥะๅࠡ฻่่์อࠠโ์ࠣหู้ๆ้ษอࠤฬู๊ีำฬࠤฬ๊ๅศุํอࠬ৞")
	z7zRKcweSZAk += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱ࡶ࡬࡮ࡧࡣࡰࡷࡱࡸࠬয়")+Nat0Dx9puRUWCsgz6JyFhY3
	bYrLlO9uMs5tm0IGFhK2v = OR97bMGecfgDCqux3YdAZ6y+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨสิ๊ฬ๋ฬࠡึิ๎฼ࠦวๅ็ึ่๊ࠦ࠺ࠡࠩৠ")+Nat0Dx9puRUWCsgz6JyFhY3
	bYrLlO9uMs5tm0IGFhK2v += Cp6c5tZe8I0PxnAW(u"๊ࠩ์ࠥ฿ศศำฬࠤ฾์ࠠษำ้ห๊า๋๊ࠠไีู๋ࠥๅ๊่หฯࠦอิษห๎ฮࠦใฬ์ิอࠥะ็ๆࠢฯ้๏฿ࠠศๆ่ื้๋๊็่ࠢฯ้ࠦร้ไสฮࠥอไึๆสอࠥ๎ร้ไสฮࠥอไไี๋ๅࠥ๎วๅะึ์ๆ่ࠦีๅ็ࠤฬ๊โๆำࠣ์ศ๎โศฬࠣห้่ๅา๋ࠢว๏฼วࠡ์๋ๅึࠦัล์ฬࠤฬ๊็ๅษ็ࠤๆ๐ࠠอ็ํ฽ࠥี่ๅࠢส่฾อไๆ๋ࠢว๏฼วࠡใํ๋ࠥะโ้์่ࠤ๊๐ไศัํࠤํํฬา์ࠣ์ๆ๐็ࠡลํฺฬࠦศฮอࠣ์็ืวยหࠣห้่ัร่ࠣ์ศ๐ึศࠢไ๎์ࠦวิฬัหึฯ้ࠠฬไหษ๊้ࠠใํ๋ࠥษโ้ษ็ࠤ๊์ำ้สฬࠤ้๊รๆษ่ࠤ฾๊๊๊ࠡฦ้ํืࠠฤะิํࠥะ็ๆࠢๆ่๋ࠥำๅ็ࠣ࠲ࠥอไษำ้ห๊าࠠๆๅอ์อࠦศๅ฼ฬࠤัอแศࠢึ็ึฮส๊ࠡํืฯิฯๆ้ࠢ฼ฬ๋้ࠠ์้ำํุࠠหฯอࠤอ๐ฦส๋ࠢ๎๋ี่ำࠢๆหั๐ส๊่ࠡาฺ฻ࠠโไฺࠤ้ษฬ่ิฬࠤฬ๊่๋่า์ืࠦ࠮ࠡษ็้ํู่ࠡษ็ีุ๋๊ࠡๆ็ฬึ์วๆฮ๋ࠣํ࠭ৡ")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡳࡵࡴ࡮࡬ࡱࡷࡻ࡬ࡦࡴࠪৢ")+Nat0Dx9puRUWCsgz6JyFhY3
	sh3cDaZzUkKQFEAl74OryuPtGqJ = f90fGrlSEObDsuiA3U(u"ࠫࡠࡘࡔࡍ࡟ࠪৣ")+z7zRKcweSZAk+t3coAp06zvHrTl49bUVgx(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡠࡘࡔࡍ࡟ࠪ৤")+bYrLlO9uMs5tm0IGFhK2v
	YTUtDCvHs6eQEPi1FJ(dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡲࡪࡩ࡫ࡸࠬ৥"),eHdDoxhJCEPMZFVa2fg,sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def JaCYQh0Kf29q7LbmT5geG(ssGzSv5CKWmpbITxfqjE6D4n0leo):
	RD8m0SxQnJ(ZAl2gePWifs3IXG)
	pg2HKT7OyfiMWL6 = K89FakvRdrtXhmnDE7O(ssGzSv5CKWmpbITxfqjE6D4n0leo)
	Fs8cz0DmIrRPSltf71GLpQ(S8i3sBYoHWdTURpAgN(u"ࠧࡅࡑࡑࡅ࡙ࡏࡏࡏࡕࠪ০"))
	id,pcG48moFZkRT1Iz7DJaYOqtB,YSrPiRzTntg3kwsH86xvm0oZf9,Geo8WC6xHmhPAwQMXpZd,vR5ZcIituWPYQLwyeab2oOsg,reason = pg2HKT7OyfiMWL6[x1Oa8bBf36EwsLMirtFc]
	yjD0T8Ye32coaKrR5Z679,l91ODotRve30i64 = Geo8WC6xHmhPAwQMXpZd.split(I5bUBGpPXn0W6(u"ࠨ࡞ࡱ࠿ࡀ࠭১"))
	bYrLlO9uMs5tm0IGFhK2v,i25MesXmlJoQNOgLPbIqDrVvG9,NtYlMGwxjLczOC41yKSv = vR5ZcIituWPYQLwyeab2oOsg.split(jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࡟ࡲࡀࡁࠧ২"))
	t8RAjyNpbH2rzwF6WUXBVuQh5G = YchIv6N09BaWPEj4tieAnluKZrRXT
	while t8RAjyNpbH2rzwF6WUXBVuQh5G:
		FP4Q81xmXqMIp7rzS5KiY = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠪาึ๎ฬࠨ৩"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫสืำศๆࠣีุอไสࠢ็่๊ฮัๆฮࠪ৪"),eNEhtuoi9gK8JaTpIXj(u"่ࠬวว็ฬࠤฬ๊สษำ฼หฯ࠭৫"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ไฦ์ๅหๆࠦวๅว฼่ฬ์วหࠢ࠽ࠤࠥะศา฻ࠣวํࠦวๆีะࠤฬ๊ศา่ส้ั࠭৬"),bYrLlO9uMs5tm0IGFhK2v)
		if FP4Q81xmXqMIp7rzS5KiY==RqLvTrID0yMVeClpYcnZ16i3X(u"࠵ಥ"): b9by0a7JAmsHS2pihjcgkt5nwKoXN3 = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ฺ๊ࠧาอࠬ৭"),eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠨ็หำศࠦวๅฬหี฾ฺ๋ࠦำࠣๆฬฮไࠡๆ็๊็อิࠨ৮"),i25MesXmlJoQNOgLPbIqDrVvG9,CKUiyEe28zsZ(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡷࡲࡧ࡬࡭ࡨࡲࡲࡹ࠭৯"))
		elif FP4Q81xmXqMIp7rzS5KiY==KQ3sCe9Pzh(u"࠵ದ"): kExW7f8PlyVi34NbOYXd()
		else: t8RAjyNpbH2rzwF6WUXBVuQh5G = rDceXBpHkfVUYRJ3tIx95Z
	if ssGzSv5CKWmpbITxfqjE6D4n0leo: AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def UmpHKfuB5Z9R(showDialogs):
	zf7iFX1auw0bQU = YchIv6N09BaWPEj4tieAnluKZrRXT
	if showDialogs: zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡧࡪࡴࡴࡦࡴࠪৰ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ุࠫสวๅࠩৱ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬํไࠡล้ฮ๋ࠥสฤๅาࠤํะั๋ัุ้ࠣำ้ࠠฬุๅ๏ืࠠอ็ํ฽ࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠢ࠱ࠤา๐หࠡฬ฼์ิࠦฬๆ์฼ࠤฬ๊ลฺัสำฬะࠠฦๆ์ࠤํ฼ู๋หࠣฮะฮ๊หࠢส่อืๆศ็ฯࠤฤ࠭৲"))
	if zf7iFX1auw0bQU:
		gZdOM2jYEfV = YchIv6N09BaWPEj4tieAnluKZrRXT
		if RRydns1CErYlIhwSx7.path.exists(BqL5WyVsJH31zGuD47YPSe):
			try: RRydns1CErYlIhwSx7.remove(BqL5WyVsJH31zGuD47YPSe)
			except: gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
		if showDialogs:
			if gZdOM2jYEfV: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"࠭สๆࠢห๊ัออࠡ็ึัࠥ๎สึใํี๋ࠥไโࠢศ฽ิอฯศฬࠣฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭৳"))
			else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠧๅๆฦืๆࠦแีๆอࠤ฾๋ไ๋หุ้ࠣำࠠๆๆไࠤฬ๊ลฺัสำฬะࠧ৴"))
	return
def vuPnztZ9xRm8Fdo2wy54():
	k8B273ZKPbostnFNRDVf()
	pRNWrx8629vSyus7JKg = MoO74hKeqm8fFka.getSetting(EX25Y0l8ILvz7QcRC(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ৵"))
	sh3cDaZzUkKQFEAl74OryuPtGqJ = {}
	sh3cDaZzUkKQFEAl74OryuPtGqJ[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡄ࡙࡙ࡕࠧ৶")] = NxXMrsTC5FniYuRBOK8(u"ࠪห้้วีࠢส่ฯ๊โศศํࠤ๏฿ๅๅࠩ৷")
	sh3cDaZzUkKQFEAl74OryuPtGqJ[Cp6c5tZe8I0PxnAW(u"ࠫࡘ࡚ࡏࡑࠩ৸")] = LyOR7f69iA(u"ࠬอไไษืࠤ๊ะ่ใใࠣฮ๊อๅศ๋ࠢฬฬ๊ใศ็็ࠫ৹")
	sh3cDaZzUkKQFEAl74OryuPtGqJ[dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧ৺")] = jUcmHhgVvW0EdYOIfXeaDF(u"ࠧไษืࠤัีวࠡไุ๎ึࠦวๅ็าํࠥ࠴ࠠࠨ৻")+str(xHs1lKmBbG5PT9LwN/LyOR7f69iA(u"࠻࠶ಧ"))+I5bUBGpPXn0W6(u"ࠨࠢาๆ๏่ษࠡใๅ฻ࠬৼ")
	LLcylM6rGqtsuADwia = sh3cDaZzUkKQFEAl74OryuPtGqJ[pRNWrx8629vSyus7JKg]
	iL3sKTVC7EZgM9kDajU1FYGBqWrdc = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠩๆหูࠦࠧ৽")+str(xHs1lKmBbG5PT9LwN/S8i3sBYoHWdTURpAgN(u"࠼࠰ನ"))+ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࠤิ่๊ใหࠪ৾"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ৿"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬห๊ใษไࠤ่อๅๅࠩ਀"),LLcylM6rGqtsuADwia,I5bUBGpPXn0W6(u"࠭็ๅࠢอี๏ีࠠศีอาิอๅࠡษ็็ฬฺࠠศๆำ็๏ࠦวๅฬ็ๆฬฬ๊ࠡล่ࠤฯื๊ะࠢศ๎็อแࠡษ็็ฬฺࠠษษ็็ฬ๋ไࠡล่ࠤฯื๊ะࠢๆหููࠦๆำ๊ࠤ็฻๊าࠢฯำฬࠦฟࠢࠩਁ"))
	if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==ilBWK5nXxg1do4jENGC07Zq(u"࠰಩"): uuaBg1YZe52RUI7jwOiQEWp63z = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨਂ")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==HkiMU0QrdzW3l6gwnT(u"࠲ಪ"): uuaBg1YZe52RUI7jwOiQEWp63z = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡃࡘࡘࡔ࠭ਃ")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==t3coAp06zvHrTl49bUVgx(u"࠴ಫ"): uuaBg1YZe52RUI7jwOiQEWp63z = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡖࡘࡔࡖࠧ਄")
	else: uuaBg1YZe52RUI7jwOiQEWp63z = eHdDoxhJCEPMZFVa2fg
	if uuaBg1YZe52RUI7jwOiQEWp63z:
		MoO74hKeqm8fFka.setSetting(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩਅ"),uuaBg1YZe52RUI7jwOiQEWp63z)
		LcYnPUj8wJ = sh3cDaZzUkKQFEAl74OryuPtGqJ[uuaBg1YZe52RUI7jwOiQEWp63z]
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LcYnPUj8wJ)
	return
def HZ31MlfKwuBiVNOzdWGSgx6L():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = {}
	sh3cDaZzUkKQFEAl74OryuPtGqJ[TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡆ࡛ࡔࡐࠩਆ")] = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ู๊ࠬาใิࠤࡉࡔࡓࠡษ็ฮ้่วว์ࠣ๎฾๋ไ࠻ࠢࠪਇ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ[eNEhtuoi9gK8JaTpIXj(u"࠭ࡁࡔࡍࠪਈ")] = w2vjZmdJuY7c(u"ࠧิ์ิๅึࠦࡄࡏࡕࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่࠼ࠣࠫਉ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ[f90fGrlSEObDsuiA3U(u"ࠨࡕࡗࡓࡕ࠭ਊ")] = ehfEsaiJBSvbcULtNPVgykA2(u"ࠩึ๎ึ็ัࠡࡆࡑࡗ๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬ਋")
	wNnZu2pyhiSfcT7rdJmD = MoO74hKeqm8fFka.getSetting(f90fGrlSEObDsuiA3U(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪ਌"))
	pRNWrx8629vSyus7JKg = MoO74hKeqm8fFka.getSetting(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧ਍"))
	LLcylM6rGqtsuADwia = sh3cDaZzUkKQFEAl74OryuPtGqJ[pRNWrx8629vSyus7JKg]+wNnZu2pyhiSfcT7rdJmD
	iL3sKTVC7EZgM9kDajU1FYGBqWrdc = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠬะิ฻์็ࠤ฾์ฯࠡษ็้ํอแใหࠪ਎"),egY8Jti0smdLM3h1VQRSW(u"࠭สี฼ํ่ࠥะไใษษ๎ࠬਏ"),bP01xn84BiQN(u"ࠧฦ์ๅหๆࠦใศ็็ࠫਐ"),LLcylM6rGqtsuADwia,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨีํีๆืࠠࡅࡐࡖࠤ์๎ࠠอ้สึࠥ็๊ࠡษ็ษ๋ะั็์อࠤ๏่่ๆࠢหฮา๎๊ๅࠢฦื๊อมࠡษ็้ํอโฺ๋ࠢหู้๊าใิหฯࠦลๅ๋ࠣวึ่วๆ๋ࠢ฽๋ีࠠษ฻ูࠤฬ๊ๆศีࠣ๎็๎ๅࠡสะะอ่ࠦๆ่฼ࠤํำึาࠢห฽฻ࠦวๅ็๋ห็฿ࠠ࠯ࠢ็ฮูเ๊ๅࠢึ๎ึ็ัࠡࡆࡑࡗ่ࠥๅࠡสสาฯ๐วาࠢสุ่๐ัโำࠣห้๋ๆศีหࠤศ๎ࠠใ็ࠣฬส๐โศใ๊ࠤออไไษ่่ࠬ਑"))
	if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳ಬ"): uuaBg1YZe52RUI7jwOiQEWp63z = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡄࡗࡐ࠭਒")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==KW5bYS20wTF1LyCs9(u"࠵ಭ"): uuaBg1YZe52RUI7jwOiQEWp63z = S8i3sBYoHWdTURpAgN(u"ࠪࡅ࡚࡚ࡏࠨਓ")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠷ಮ"): uuaBg1YZe52RUI7jwOiQEWp63z = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡘ࡚ࡏࡑࠩਔ")
	if iL3sKTVC7EZgM9kDajU1FYGBqWrdc in [ehfEsaiJBSvbcULtNPVgykA2(u"࠰ರ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷ಯ")]:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬਕ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ำ๋ำไี࠿ࠦࠧਖ")+MOnQlAXkSV8vb2sDyWdtPzBU1ea[NSudqlOzja],wY1p9mP03S8drbcH64t5WQkv(u"ࠧิ์ิๅึࡀࠠࠨਗ")+MOnQlAXkSV8vb2sDyWdtPzBU1ea[x1Oa8bBf36EwsLMirtFc],eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠨลัฮฬืࠠิ์ิๅึࠦࡄࡏࡕࠣห้๋ๆศีหࠤ้้ࠧਘ"))
		if zf7iFX1auw0bQU==S8i3sBYoHWdTURpAgN(u"࠲ಱ"): gbcySDjuoT2V9qAJMUOfFa34L7zmQ = MOnQlAXkSV8vb2sDyWdtPzBU1ea[x1Oa8bBf36EwsLMirtFc]
		else: gbcySDjuoT2V9qAJMUOfFa34L7zmQ = MOnQlAXkSV8vb2sDyWdtPzBU1ea[NSudqlOzja]
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==wY1p9mP03S8drbcH64t5WQkv(u"࠴ಲ"): gbcySDjuoT2V9qAJMUOfFa34L7zmQ = eHdDoxhJCEPMZFVa2fg
	else: uuaBg1YZe52RUI7jwOiQEWp63z = eHdDoxhJCEPMZFVa2fg
	if uuaBg1YZe52RUI7jwOiQEWp63z:
		MoO74hKeqm8fFka.setSetting(w2vjZmdJuY7c(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬਙ"),uuaBg1YZe52RUI7jwOiQEWp63z)
		MoO74hKeqm8fFka.setSetting(NxXMrsTC5FniYuRBOK8(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪਚ"),gbcySDjuoT2V9qAJMUOfFa34L7zmQ)
		LcYnPUj8wJ = sh3cDaZzUkKQFEAl74OryuPtGqJ[uuaBg1YZe52RUI7jwOiQEWp63z]+gbcySDjuoT2V9qAJMUOfFa34L7zmQ
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LcYnPUj8wJ)
	return
def Aj7yzac3Q80r9BEWUReqZPgk6FLus():
	pRNWrx8629vSyus7JKg = MoO74hKeqm8fFka.getSetting(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩਛ"))
	sh3cDaZzUkKQFEAl74OryuPtGqJ = {}
	sh3cDaZzUkKQFEAl74OryuPtGqJ[f90fGrlSEObDsuiA3U(u"ࠬࡇࡕࡕࡑࠪਜ")] = HkiMU0QrdzW3l6gwnT(u"࠭วๅสิ์ู่๊ࠡษ็ฮ้่วว์ࠣะฬําࠡๆ็฽๊๊ࠧਝ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ[f90fGrlSEObDsuiA3U(u"ࠧࡂࡕࡎࠫਞ")] = XugxFprC26zGM(u"ࠨษ็ฬึ๎ใิ์ࠣื๏฿ๅๅࠢห฽ิࠦวๅี่หาࠦไ่ࠩਟ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ[bP01xn84BiQN(u"ࠩࡖࡘࡔࡖࠧਠ")] = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪห้ฮั้ๅึ๎๋ࠥส้ไไࠤฯ๋วๆษࠣ์ออไไษ่่ࠬਡ")
	LLcylM6rGqtsuADwia = sh3cDaZzUkKQFEAl74OryuPtGqJ[pRNWrx8629vSyus7JKg]
	iL3sKTVC7EZgM9kDajU1FYGBqWrdc = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫฯฺฺ๋ๆࠣ฽๋ีࠠศๆ่์ฬ็โสࠩਢ"),CKUiyEe28zsZ(u"ࠬะิ฻์็ࠤฯ๊โศศํࠫਣ"),jUcmHhgVvW0EdYOIfXeaDF(u"࠭ล๋ไสๅ้ࠥวๆๆࠪਤ"),LLcylM6rGqtsuADwia,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧศๆหีํ้ำ๋๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํ฽๊๊้ࠠีํ฻ࠥฮ๊็ࠢฯ๋ฬุใ๊ࠡส่ส์สา่ํฮࠥ࠴่๊ࠠࠣ๎ุะไๆฺ่ࠢออสไ๋ࠢ๎็๎ๅࠡสึัอํวࠡสา่ฬࠦๅ็ๅࠣฯ๊๊ࠦษ฻ฮ๋ฬࠦไไࠢ࠱ࠤ์๊ࠠหำํำࠥะิ฻์็ࠤศ๋ࠠฦ์ๅหๆࠦวๅสิ์ู่๊ࠡมࠪਥ"))
	if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==ehfEsaiJBSvbcULtNPVgykA2(u"࠳ಳ"): uuaBg1YZe52RUI7jwOiQEWp63z = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡃࡖࡏࠬਦ")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==LTN6DPEmrwehtZMy(u"࠵಴"): uuaBg1YZe52RUI7jwOiQEWp63z = CKUiyEe28zsZ(u"ࠩࡄ࡙࡙ࡕࠧਧ")
	elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==LTN6DPEmrwehtZMy(u"࠷ವ"): uuaBg1YZe52RUI7jwOiQEWp63z = NxXMrsTC5FniYuRBOK8(u"ࠪࡗ࡙ࡕࡐࠨਨ")
	else: uuaBg1YZe52RUI7jwOiQEWp63z = eHdDoxhJCEPMZFVa2fg
	if uuaBg1YZe52RUI7jwOiQEWp63z:
		MoO74hKeqm8fFka.setSetting(CKUiyEe28zsZ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩ਩"),uuaBg1YZe52RUI7jwOiQEWp63z)
		LcYnPUj8wJ = sh3cDaZzUkKQFEAl74OryuPtGqJ[uuaBg1YZe52RUI7jwOiQEWp63z]
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LcYnPUj8wJ)
	return
def ac4LiOnJPmEK():
	Nfldwbam6eUnIK4EukgBPDGAjRrso = MoO74hKeqm8fFka.getSetting(KW5bYS20wTF1LyCs9(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬਪ"))
	if Nfldwbam6eUnIK4EukgBPDGAjRrso==S8i3sBYoHWdTURpAgN(u"࠭ࡓࡕࡑࡓࠫਫ"): header = f90fGrlSEObDsuiA3U(u"ࠧหะี๎๋ࠦวๅไ๋หห๋ࠠๆฬ๋ๆๆ࠭ਬ")
	else: header = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ็ไ฽้࠭ਭ")
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠩศ๎็อแࠨਮ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪฮๆ฿๊ๅࠩਯ"),header,KW5bYS20wTF1LyCs9(u"ࠫ็๎วว็ࠣห้ฮั็ษ่ะࠥ๐สๆࠢอัิ๐ห่ษࠣวํะ่ๆษอ๎่๐วࠡส฼ำࠥ࠷࠶ࠡีส฽ฮࠦๅ็ࠢฦ์้ࠦริฬัำฬ๋ࠠ࠯࠰ࠣ์ส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠣ๎ษี๊ࠡว็ํࠥะอะ์ฮ๋ฬࠦแ๋ࠢๆ่๋ࠥัสࠢํฮ๊ࠦวิฬัำฬ๋ࠠศๆๅ์ฬฬๅࠡ࠰࠱ࠤํํะศࠢํือฮࠠษูษࠤๆ๐ࠠโฬะࠤ็๎วว็ࠣห้ฮั็ษ่ะࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅࠢฦ้ࠥห๊ใษไࠤฯิา๋่ࠣห้่่ศศ่ࠤฤࠧࠡࠨਰ"))
	if zf7iFX1auw0bQU==-J7divaGOCgq2SLfXpDzZYN58wc(u"࠷ಶ"): return
	elif zf7iFX1auw0bQU:
		MoO74hKeqm8fFka.setSetting(f90fGrlSEObDsuiA3U(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬ਱"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡁࡖࡖࡒࠫਲ"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਲ਼"),bP01xn84BiQN(u"ࠨฬ่ࠤฯ็ู๋ๆࠣฮำุ๊็ࠢส่็๎วว็ࠪ਴"))
	else:
		MoO74hKeqm8fFka.setSetting(LTN6DPEmrwehtZMy(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩਵ"),LyOR7f69iA(u"ࠪࡗ࡙ࡕࡐࠨਸ਼"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ਷"),EX25Y0l8ILvz7QcRC(u"ࠬะๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧਸ"))
	return
def XDVL1fTdwRsZA7iWIn(bkA4Xjzw7mJa):
	if bkA4Xjzw7mJa!=eHdDoxhJCEPMZFVa2fg:
		bkA4Xjzw7mJa = iVAXFDQ0NpolPYOZ(bkA4Xjzw7mJa)
		bkA4Xjzw7mJa = bkA4Xjzw7mJa.decode(m6PFtLblInpNZ8x).encode(m6PFtLblInpNZ8x)
		RK364usNdcL98AE7YofBGaFpi0U2Cb = dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠱࠱࠳࠳࠷ಷ")
		xL3IUZRst4F8 = VVZgPQ2kYLoKe6jic5AEzqupG.Window(RK364usNdcL98AE7YofBGaFpi0U2Cb)
		xL3IUZRst4F8.getControl(LyOR7f69iA(u"࠴࠳࠴ಸ")).setLabel(bkA4Xjzw7mJa)
	return
cQBnumoTOKxWd4tX = [
			 LTN6DPEmrwehtZMy(u"ࠨࡥࡹࡶࡨࡲࡸ࡯࡯࡯ࠢࡤࡺࡸࡶࡡࡤࡧࡶ࠴ࠥ࡯ࡳࠡࡰࡲࡸࠥࡩࡵࡳࡴࡨࡲࡹࡲࡹࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧࠦਹ")
			,LyOR7f69iA(u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡩࡳࡷࠦࡍࡢ࡮࡬ࡧ࡮ࡵࡵࡴࠢࡶࡧࡷ࡯ࡰࡵࡵࠪ਺")
			,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡒ࡙ࡖࠥࡏࡐࡕࡘࠣࡗ࡮ࡳࡰ࡭ࡧࠣࡇࡱ࡯ࡥ࡯ࡶࠪ਻")
			,ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰ࡚ࠣ࡮ࡪࡥࡰࠢࡌࡲ࡫ࡵࠠࡌࡧࡼ਼ࠫ")
			,I5bUBGpPXn0W6(u"ࠪࡸ࡭࡯ࡳࠡࡪࡤࡷ࡭ࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡ࡫ࡶࠤࡧࡸ࡯࡬ࡧࡱࠫ਽")
			,I5bUBGpPXn0W6(u"ࠫࡺࡹࡥࡴࠢࡳࡰࡦ࡯࡮ࠡࡊࡗࡘࡕࠦࡦࡰࡴࠣࡥࡩࡪ࠭ࡰࡰࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࡸ࠭ਾ")
			,ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡧࡤࡷࡣࡱࡧࡪࡪ࠭ࡶࡵࡤ࡫ࡪ࠴ࡨࡵ࡯࡯ࠫਿ")+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࠣࠨੀ")+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡴࡵ࡯࠱ࡼࡧࡲ࡯࡫ࡱ࡫ࡸ࠭ੁ")
			,XugxFprC26zGM(u"ࠨࡋࡱࡷࡪࡩࡵࡳࡧࡕࡩࡶࡻࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩ࠯ࠫੂ")
			,NxXMrsTC5FniYuRBOK8(u"ࠩࡈࡶࡷࡵࡲࠡࡩࡨࡸࡹ࡯࡮ࡨࠢࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆ࠲ࡃࡲࡵࡤࡦࡧࡀ࠴ࠫࡺࡥࡹࡶࡷࡁࠬ੃")
			,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡻࡦࡸ࡮ࡪࡰࡪࡷ࠳ࡽࡡࡳࡰࠫࠫ੄")
			,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡣࡤ࡞࡟ࡠࠪ੅")
			,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦࡳ࡬࡫ࡱࠤ࡫࡯࡬ࡦ࠼ࠪ੆")
			]
def OOPp1ETlztb9WAQwX(g6DoPQHrhS):
	if dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡌࡰࡣࡧ࡭ࡳ࡭ࠠࡴ࡭࡬ࡲࠥ࡬ࡩ࡭ࡧ࠽ࠫੇ") in g6DoPQHrhS and S8i3sBYoHWdTURpAgN(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬੈ") in g6DoPQHrhS: return YchIv6N09BaWPEj4tieAnluKZrRXT
	for bkA4Xjzw7mJa in cQBnumoTOKxWd4tX:
		if bkA4Xjzw7mJa in g6DoPQHrhS: return YchIv6N09BaWPEj4tieAnluKZrRXT
	return rDceXBpHkfVUYRJ3tIx95Z
def QQOAfeWZrw(data):
	dSMxlbEvPa925hLHpyqCDTZA = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠺಺") if WHjh1POtMKlmgiy68RSqb else I5bUBGpPXn0W6(u"࠳࠸ಹ")
	data = data.replace(ilBWK5nXxg1do4jENGC07Zq(u"࠷࠵಻")*avcfIls8w7gk69hYUErHxzQTXtm24j,dSMxlbEvPa925hLHpyqCDTZA*avcfIls8w7gk69hYUErHxzQTXtm24j)
	data = data.replace(eNEhtuoi9gK8JaTpIXj(u"ࠨࠢ࠿࡫ࡪࡴࡥࡳࡣ࡯ࡂ࠿ࠦࠧ੉"),ietolwsjpIPK7Fr(u"ࠩ࠽ࠤࠬ੊"))
	LbAmEhrdt7eRV2Y = eHdDoxhJCEPMZFVa2fg
	for g6DoPQHrhS in data.splitlines():
		opVbMj6LnO = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠪࠤࠥࠦࠠࠡࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴ࠰ࠬࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩੋ"),g6DoPQHrhS,cBawilJXvK1m.DOTALL)
		if opVbMj6LnO: g6DoPQHrhS = g6DoPQHrhS.replace(opVbMj6LnO[x1Oa8bBf36EwsLMirtFc],eHdDoxhJCEPMZFVa2fg)
		LbAmEhrdt7eRV2Y += kDUv7ouWrcgMe6OipQJm+g6DoPQHrhS
	return LbAmEhrdt7eRV2Y
def Irw8xd6mzk9nbjcsVEt3lqTQYLJKZ(fPO7p8sG3dBibK5NctyjF):
	if ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡔࡒࡄࠨੌ") in fPO7p8sG3dBibK5NctyjF:
		JqCNv21osiM = KdV8utLBIYob1F7S25MqpN4xJ
		header = ilBWK5nXxg1do4jENGC07Zq(u"่ࠬัศรฬࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣร੍ࠬ")
	else:
		JqCNv21osiM = SSI5kBG0Y2JpF
		header = XugxFprC26zGM(u"࠭โาษฤอࠥอไิฮ็ࠤฬ๊อศๆํࠤฤ࠭੎")
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,header,bP01xn84BiQN(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๐อห๊ํࠤศ๐ึศࠢ฼่๎ࠦำอๆࠣห้อำหะาห๊ࠦ࠮๊ࠡส่ฬัๆฺ๋่ࠣึ๎ั๋ห่๊ࠣ฿ัโหࠣ็๏็ࠠฮัฮฮࠥอไๆึๆ่ฮ่ࠦๆษ๋ࠣํࠦวๅ็ๆห๋ࠦวๅาํࠤุฮศࠡฯา์ะࠦวๅ็ื็้ฯࠠ࠯ࠢๆ์ิ๐๋ࠠฯอๅ฽ࠦศิฮ็๎๋ࠦ࠮ࠡษ็วํ๊่๊ࠠࠣหู้ฬๅࠢส่าอไ๋๋ࠢๅ๏ํࠠๆ฻็์๊อสࠡฬหำศࠦๅ็าࠣฬิอ๊สࠢส่ฯฺฺ๋ๆࠣห้ำวๅ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋ࠢห้๏ࠠศๆล๊ࠥ࠴ࠠฤ็สࠤฬ๊ำอๆࠣห้่ฯ๋็ࠣๅ์๎ࠠศๆึะ้ࠦวๅีสฬ็ࠦวๅาํࠤฯ๋ࠠอ็฼๋๋ࠥๆࠡสิ๊ฬ๋ฬࠡๅ๋ำ๏ࠦโษๆࠣฦำืࠠฦูไหฦࠦไ่ࠢ࠱ࠤ์๊ࠠหำํำࠥอไศีอ้ึอัࠡมࠪ੏"))
	if zf7iFX1auw0bQU!=ilBWK5nXxg1do4jENGC07Zq(u"࠶಼"): return
	nJID9RhYQwL4MbxPK18dU,ww8qbZ4QgUcmjEYkiL73OCozha1 = [],XugxFprC26zGM(u"࠶ಽ")
	size,count = tSCWKXTbwog4L(JqCNv21osiM)
	file = open(JqCNv21osiM,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡴࡥࠫ੐"))
	if size>EX25Y0l8ILvz7QcRC(u"࠲࠲࠳࠶࠵࠶ಿ"): file.seek(-iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠱࠱࠲࠴࠴࠵ಾ"),RRydns1CErYlIhwSx7.SEEK_END)
	data = file.read()
	file.close()
	if WHjh1POtMKlmgiy68RSqb: data = data.decode(m6PFtLblInpNZ8x)
	data = QQOAfeWZrw(data)
	a0VHgjbCY1KfuI6o = data.split(kDUv7ouWrcgMe6OipQJm)
	for g6DoPQHrhS in reversed(a0VHgjbCY1KfuI6o):
		eOdHYNo34v5nSVhXiUgq = OOPp1ETlztb9WAQwX(g6DoPQHrhS)
		if eOdHYNo34v5nSVhXiUgq: continue
		g6DoPQHrhS = g6DoPQHrhS.replace(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡢࠫੑ"),OR97bMGecfgDCqux3YdAZ6y+CKUiyEe28zsZ(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭੒")+Nat0Dx9puRUWCsgz6JyFhY3)
		g6DoPQHrhS = g6DoPQHrhS.replace(KW5bYS20wTF1LyCs9(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫ੓"),eNEhtuoi9gK8JaTpIXj(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈ࠳࠴࠵࠶࡝ࠨ੔")+t3coAp06zvHrTl49bUVgx(u"࠭ࡅࡓࡔࡒࡖ࠿࠭੕")+Nat0Dx9puRUWCsgz6JyFhY3)
		kDauNIWGtl2Fydfoj = eHdDoxhJCEPMZFVa2fg
		n7Rj1wVCYUqyDoJ3F8eWZL = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧ੖"),g6DoPQHrhS,cBawilJXvK1m.DOTALL)
		if n7Rj1wVCYUqyDoJ3F8eWZL:
			g6DoPQHrhS = g6DoPQHrhS.replace(n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc],n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][NSudqlOzja]).replace(n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][FB0pIzAoK8wqgd3UiY5],eHdDoxhJCEPMZFVa2fg)
			kDauNIWGtl2Fydfoj = n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][NSudqlOzja]
		else:
			n7Rj1wVCYUqyDoJ3F8eWZL = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨ੗"),g6DoPQHrhS,cBawilJXvK1m.DOTALL)
			if n7Rj1wVCYUqyDoJ3F8eWZL:
				g6DoPQHrhS = g6DoPQHrhS.replace(n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][NSudqlOzja],eHdDoxhJCEPMZFVa2fg)
				kDauNIWGtl2Fydfoj = n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc]
		if kDauNIWGtl2Fydfoj: g6DoPQHrhS = g6DoPQHrhS.replace(kDauNIWGtl2Fydfoj,SbyWQGMDnV+kDauNIWGtl2Fydfoj+Nat0Dx9puRUWCsgz6JyFhY3)
		nJID9RhYQwL4MbxPK18dU.append(g6DoPQHrhS)
		if len(str(nJID9RhYQwL4MbxPK18dU))>ehfEsaiJBSvbcULtNPVgykA2(u"࠷࠳࠵࠵࠶ೀ"): break
	nJID9RhYQwL4MbxPK18dU = reversed(nJID9RhYQwL4MbxPK18dU)
	KZfbsjMdlVTvBRnFauPJ = kDUv7ouWrcgMe6OipQJm.join(nJID9RhYQwL4MbxPK18dU)
	YTUtDCvHs6eQEPi1FJ(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡯ࡩ࡫ࡺࠧ੘"),LyOR7f69iA(u"ࠪฦำืࠠฤีฺีูࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠧਖ਼"),KZfbsjMdlVTvBRnFauPJ,eNEhtuoi9gK8JaTpIXj(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧਗ਼"))
	return
def pkNuKl7BxPhGI5Zd6A():
	lexViLsprOUIn7RMvQFmJwzuWGjk = open(PP4inxmZ2aEyzRUSLTVtbYHvqejJ,KQ3sCe9Pzh(u"ࠬࡸࡢࠨਜ਼")).read()
	if WHjh1POtMKlmgiy68RSqb: lexViLsprOUIn7RMvQFmJwzuWGjk = lexViLsprOUIn7RMvQFmJwzuWGjk.decode(m6PFtLblInpNZ8x)
	lexViLsprOUIn7RMvQFmJwzuWGjk = lexViLsprOUIn7RMvQFmJwzuWGjk.replace(f90fGrlSEObDsuiA3U(u"࠭࡜ࡵࠩੜ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࠡࠢࠣࠤࠥࠦࠠࠡࠩ੝"))
	H8hMP0qweGaor3OJjWBVzT = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠨࠪࡹࡠࡩ࠴ࠪࡀࠫ࡞ࡠࡳࡢࡲ࡞ࠩਫ਼"),lexViLsprOUIn7RMvQFmJwzuWGjk,cBawilJXvK1m.DOTALL)
	for g6DoPQHrhS in H8hMP0qweGaor3OJjWBVzT:
		lexViLsprOUIn7RMvQFmJwzuWGjk = lexViLsprOUIn7RMvQFmJwzuWGjk.replace(g6DoPQHrhS,OR97bMGecfgDCqux3YdAZ6y+g6DoPQHrhS+Nat0Dx9puRUWCsgz6JyFhY3)
	lZGwNzPT1m9i2XJEW4tqKeDjA75a(KW5bYS20wTF1LyCs9(u"ࠩส่ฯเ๊๋ำสฮࠥอไฤะํีฮࠦแ๋ࠢส่อืวๆฮࠪ੟"),lexViLsprOUIn7RMvQFmJwzuWGjk)
	return
def JLtVuawiI3rBxAj():
	z7zRKcweSZAk = I5bUBGpPXn0W6(u"ࠪฬ฾฼ࠠศๆฦึึอัࠡ฻็ํࠥอไา์่์ฯࠦใ้่อีํ๊ࠠห๊ไีࠥหๅไษ้๎ฮࠦสใัํ้ࠥ๎สฤะํีࠥอไโ์า๎ํ่่ࠦา๊ࠤฬ๊รำำสีࠥํ๊ࠡษ็วุํๅ๊ࠡส่ศืโศ็้ࠣ฾ࠦศฺุࠣ์่อไหษ็๎ࠬ੠")
	bYrLlO9uMs5tm0IGFhK2v = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"้ࠫะโะ์่ࠤฬ๊แ๋ัํ์ࠥอำหะา้ࠥอไิ้่ࠤฬ๊๊ๆ์้ࠤํ๊สฤะํี์ࠦวิฬัำ๊ࠦวๅี๊้ࠥอไ๋ีสีࠥ࠴ࠠฤ็สࠤ฾ีษࠡษึ๋๊ࠦๅหฬส่๏ฯࠠโ้ำ๋ࠥะโ้็ࠣฬฯำั๋ๅࠣห้็๊ะ์๋ࠤอ๎โหࠢส็อืࠠๆ่ࠣ์็ะࠠศๆึ๋๊ࠦวๅ๊สัิࠦ࠮ࠡล่หࠥอไิ้่ࠤฬ๊รฺๆ์ࠤํอไฤีไ่ࠥ็็้ࠢํัึ้ࠠศๆไ๎ิ๐่ࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥ๎ไไ่ࠣฬ็็าสࠢๆฬ๏ืษࠨ੡")
	i25MesXmlJoQNOgLPbIqDrVvG9 = KQ3sCe9Pzh(u"ࠬษๅศࠢส่ศืโศ็ࠣๅ์๐ࠠหีอาิ๋ࠠๅๆอๆิ๐ๅ๊ࠡส่ฯษฮ๋ำࠣ์้้ๆࠡส่ๆิอัࠡ฻าำࠥอไฬ๊ส๊๏่ࠦศๆาๆฬฬโࠡ࠰้ࠣะ๊วࠡำๅ้ࠥ࠻࠴࠵ࠢอ฽๋๐ࠠ࠶ࠢาๆฬฬโ๊ࠡࠣ࠸࠹ࠦหศ่ํอࠥหไ๊ࠢส่ศ๋วๆࠢฦ์ࠥหไ๊ࠢส่ํืวยࠢหัุฮࠠศีอาิอๅไࠢ็ุ่ํๅࠡษ็๎๊๐ๆࠡล๋ࠤุํๅࠡษ็๎ุอัࠨ੢")
	sh3cDaZzUkKQFEAl74OryuPtGqJ = z7zRKcweSZAk+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭࠺ࠡࠩ੣")+bYrLlO9uMs5tm0IGFhK2v+ietolwsjpIPK7Fr(u"ࠧࠡ࠰ࠣࠫ੤")+i25MesXmlJoQNOgLPbIqDrVvG9
	YTUtDCvHs6eQEPi1FJ(XugxFprC26zGM(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ੥"),HkiMU0QrdzW3l6gwnT(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ੦"),sh3cDaZzUkKQFEAl74OryuPtGqJ,LTN6DPEmrwehtZMy(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭੧"))
	return
def CpsdhEGBHQZYJcS23wjrxzn(type,sh3cDaZzUkKQFEAl74OryuPtGqJ,showDialogs=YchIv6N09BaWPEj4tieAnluKZrRXT,url=eHdDoxhJCEPMZFVa2fg,Oyg3pZGAHdws7RWm4e6S=eHdDoxhJCEPMZFVa2fg,bkA4Xjzw7mJa=eHdDoxhJCEPMZFVa2fg,GPmHKrpXaBEzbI10f8Vcylw=eHdDoxhJCEPMZFVa2fg):
	AtLiFYDwI37SKhXbWxRsH1J0VBl = YchIv6N09BaWPEj4tieAnluKZrRXT
	if not ePJWDdHsX8Tokv31yL:
		if showDialogs:
			T6fnrzqeXil0EvoDNw9OpCK = (w2vjZmdJuY7c(u"ࠫฬ๊ำุำ࠽ࠫ੨") in sh3cDaZzUkKQFEAl74OryuPtGqJ and Cp6c5tZe8I0PxnAW(u"ࠬอไๆๅส๊࠿࠭੩") in sh3cDaZzUkKQFEAl74OryuPtGqJ and dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭วๅ็็ๅ࠿࠭੪") in sh3cDaZzUkKQFEAl74OryuPtGqJ and QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧศๆั฻ศ࠭੫") in sh3cDaZzUkKQFEAl74OryuPtGqJ and XugxFprC26zGM(u"ࠨษ็ฺ้ีั࠻ࠩ੬") in sh3cDaZzUkKQFEAl74OryuPtGqJ)
			if not T6fnrzqeXil0EvoDNw9OpCK: AtLiFYDwI37SKhXbWxRsH1J0VBl = VinwUNFtrZTh0oPs2zm(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡦࡩࡳࡺࡥࡳࠩ੭"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"๋้ࠪࠦสาี็ࠤ์ึ็ࠡษ็ีุอไสࠢศ่๎ࠦวๅ็หี๊าࠧ੮"),sh3cDaZzUkKQFEAl74OryuPtGqJ.replace(bP01xn84BiQN(u"ࠫࡡࡢ࡮ࠨ੯"),kDUv7ouWrcgMe6OipQJm))
	elif showDialogs:
		sh3cDaZzUkKQFEAl74OryuPtGqJ = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࠬੰ")
		bxPEVMTSmwu = VinwUNFtrZTh0oPs2zm(NxXMrsTC5FniYuRBOK8(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ੱ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧੲ")+ilBWK5nXxg1do4jENGC07Zq(u"ࠨࠢࠣ࠵࠴࠻ࠧੳ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧੴ"))
		S9Z8JLRDaW2jyMuUIVf4xkT7rnwmsN = VinwUNFtrZTh0oPs2zm(XugxFprC26zGM(u"ࠪࡧࡪࡴࡴࡦࡴࠪੵ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ੶")+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࠦࠠ࠳࠱࠸ࠫ੷"),XugxFprC26zGM(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ੸"))
		SWfyP7xYM8rANGDb4XCgjsBJom = VinwUNFtrZTh0oPs2zm(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡤࡧࡱࡸࡪࡸࠧ੹"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ੺")+ietolwsjpIPK7Fr(u"ࠩࠣࠤ࠸࠵࠵ࠨ੻"),S8i3sBYoHWdTURpAgN(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ੼"))
		VEcn5A6YDs8JrRK0ZeCHvfu1S7Mmz = VinwUNFtrZTh0oPs2zm(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ੽"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ੾")+jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࠠࠡ࠶࠲࠹ࠬ੿"),HkiMU0QrdzW3l6gwnT(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ઀"))
		AtLiFYDwI37SKhXbWxRsH1J0VBl = VinwUNFtrZTh0oPs2zm(Cp6c5tZe8I0PxnAW(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨઁ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩં")+t3coAp06zvHrTl49bUVgx(u"ࠪࠤࠥ࠻࠯࠶ࠩઃ"),KQ3sCe9Pzh(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩ઄"))
	pcG48moFZkRT1Iz7DJaYOqtB = edpM3qtgTJIz8PWN6lvin(rDceXBpHkfVUYRJ3tIx95Z)
	dNvRhlVX5B = f90fGrlSEObDsuiA3U(u"ࠬࡇࡖ࠻ࠢࠪઅ")+pcG48moFZkRT1Iz7DJaYOqtB+eNEhtuoi9gK8JaTpIXj(u"࠭࠭ࠨઆ")+type
	asme31FSC5c8 = YchIv6N09BaWPEj4tieAnluKZrRXT if NxXMrsTC5FniYuRBOK8(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪઇ") in bkA4Xjzw7mJa else rDceXBpHkfVUYRJ3tIx95Z
	if not AtLiFYDwI37SKhXbWxRsH1J0VBl:
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫઈ"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩอ้ࠥหไ฻ษฤࠤฬ๊ลาีส่ࠥฮๆศรࠣ฽้๏ุࠠๆห็ࠬઉ"))
		return rDceXBpHkfVUYRJ3tIx95Z
	srhOGxpmY1Ff9 = ccwRLKk3hs0E.getInfoLabel(S8i3sBYoHWdTURpAgN(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡊࡷ࡯ࡥ࡯ࡦ࡯ࡽࡓࡧ࡭ࡦࠩઊ"))
	sh3cDaZzUkKQFEAl74OryuPtGqJ += KQ3sCe9Pzh(u"ࠫࠥࡢ࡜࡯࡞࡟ࡲࡂࡃ࠽࠾ࠢࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࠥࡢ࡜࡯ࡃࡧࡨࡴࡴࠠࡗࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠪઋ")+MCrWtwnF2TViZOD7z0pXgqI4+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࠦ࠺࡝࡞ࡱࠫઌ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡅ࡮ࡣ࡬ࡰ࡙ࠥࡥ࡯ࡦࡨࡶ࠿ࠦࠧઍ")+pcG48moFZkRT1Iz7DJaYOqtB+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࠡ࠼࡟ࡠࡳࡑ࡯ࡥ࡫࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭઎")+UBgvOF9CZQSexLVGYKuNER+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࠢ࠽ࡠࡡࡴࠧએ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += ietolwsjpIPK7Fr(u"ࠩࡎࡳࡩ࡯ࠠࡏࡣࡰࡩ࠿ࠦࠧઐ")+srhOGxpmY1Ff9
	J4JZ8HDlxfUjO0 = hpCAb2IZHvVy5Wc8l0m7qw()
	J4JZ8HDlxfUjO0 = vFDQstemyYANa(J4JZ8HDlxfUjO0)
	if J4JZ8HDlxfUjO0: sh3cDaZzUkKQFEAl74OryuPtGqJ += RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࠤ࠿ࡢ࡜࡯ࡎࡲࡧࡦࡺࡩࡰࡰ࠽ࠤࠬઑ")+J4JZ8HDlxfUjO0
	if url: sh3cDaZzUkKQFEAl74OryuPtGqJ += XugxFprC26zGM(u"ࠫࠥࡀ࡜࡝ࡰࡘࡖࡑࡀࠠࠨ઒")+url
	if Oyg3pZGAHdws7RWm4e6S: sh3cDaZzUkKQFEAl74OryuPtGqJ += QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࠦ࠺࡝࡞ࡱࡗࡴࡻࡲࡤࡧ࠽ࠤࠬઓ")+Oyg3pZGAHdws7RWm4e6S
	sh3cDaZzUkKQFEAl74OryuPtGqJ += ilBWK5nXxg1do4jENGC07Zq(u"࠭ࠠ࠻࡞࡟ࡲࠬઔ")
	if showDialogs: dqKGMYgJxSF8Ub1kotlsP936Ww7B(w2vjZmdJuY7c(u"ࠧอษิ๎ࠥอไฦำึห้࠭ક"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨษ็ีัอมࠡษ็ห๋ะุศำࠪખ"))
	if GPmHKrpXaBEzbI10f8Vcylw:
		KZfbsjMdlVTvBRnFauPJ = GPmHKrpXaBEzbI10f8Vcylw
		if WHjh1POtMKlmgiy68RSqb: KZfbsjMdlVTvBRnFauPJ = KZfbsjMdlVTvBRnFauPJ.encode(m6PFtLblInpNZ8x)
		KZfbsjMdlVTvBRnFauPJ = HHP76VFiKDS2xphlGsqN48j1.b64encode(KZfbsjMdlVTvBRnFauPJ)
	elif asme31FSC5c8:
		if f90fGrlSEObDsuiA3U(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࡔࡒࡄࡠࠩગ") in bkA4Xjzw7mJa: ynThUQeIcYdpxjZfgJ = KdV8utLBIYob1F7S25MqpN4xJ
		else: ynThUQeIcYdpxjZfgJ = SSI5kBG0Y2JpF
		if not RRydns1CErYlIhwSx7.path.exists(ynThUQeIcYdpxjZfgJ):
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ઘ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ุࠫาไࠡษ็วำ฽วย๋ࠢห้อำหะาหฺ๊๋ࠦำ้ࠣํา่ะࠩઙ"))
			return rDceXBpHkfVUYRJ3tIx95Z
		vR9cOpMtk51j(iwIlVQsgYezu,I5bUBGpPXn0W6(u"ࠬ࠴࡜ࡵࡒࡵࡩࡵࡧࡲࡪࡰࡪࠤࡹࡵࠠࡴࡧࡱࡨࠥࡺࡨࡦࠢ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪચ"))
		nJID9RhYQwL4MbxPK18dU,ww8qbZ4QgUcmjEYkiL73OCozha1 = [],EX25Y0l8ILvz7QcRC(u"࠳ು")
		file = open(ynThUQeIcYdpxjZfgJ,wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡲࡣࠩછ"))
		size,count = tSCWKXTbwog4L(ynThUQeIcYdpxjZfgJ)
		if size>jUcmHhgVvW0EdYOIfXeaDF(u"࠷࠵࠷࠰࠱࠲ೂ"): file.seek(-jUcmHhgVvW0EdYOIfXeaDF(u"࠷࠵࠷࠰࠱࠲ೂ"),RRydns1CErYlIhwSx7.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(m6PFtLblInpNZ8x)
		data = QQOAfeWZrw(data)
		a0VHgjbCY1KfuI6o = data.splitlines()
		for g6DoPQHrhS in reversed(a0VHgjbCY1KfuI6o):
			eOdHYNo34v5nSVhXiUgq = OOPp1ETlztb9WAQwX(g6DoPQHrhS)
			if eOdHYNo34v5nSVhXiUgq: continue
			n7Rj1wVCYUqyDoJ3F8eWZL = cBawilJXvK1m.findall(EX25Y0l8ILvz7QcRC(u"ࠧ࡟ࠪ࡟ࡨ࠰࠳ࠨ࡝ࡦ࠮࠱ࡡࡪࠫࠡ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠮࠮ࠠࡕ࠼࡟ࡨ࠰࠯ࠧજ"),g6DoPQHrhS,cBawilJXvK1m.DOTALL)
			if n7Rj1wVCYUqyDoJ3F8eWZL:
				g6DoPQHrhS = g6DoPQHrhS.replace(n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc],n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][NSudqlOzja]).replace(n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][FB0pIzAoK8wqgd3UiY5],eHdDoxhJCEPMZFVa2fg)
			else:
				n7Rj1wVCYUqyDoJ3F8eWZL = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠨࡠࠫࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠨࠡࡖ࠽ࡠࡩ࠱ࠩࠨઝ"),g6DoPQHrhS,cBawilJXvK1m.DOTALL)
				if n7Rj1wVCYUqyDoJ3F8eWZL: g6DoPQHrhS = g6DoPQHrhS.replace(n7Rj1wVCYUqyDoJ3F8eWZL[x1Oa8bBf36EwsLMirtFc][NSudqlOzja],eHdDoxhJCEPMZFVa2fg)
			nJID9RhYQwL4MbxPK18dU.append(g6DoPQHrhS)
			if len(str(nJID9RhYQwL4MbxPK18dU))>XugxFprC26zGM(u"࠷࠻࠱࠱࠲࠳ೃ"): break
		nJID9RhYQwL4MbxPK18dU = reversed(nJID9RhYQwL4MbxPK18dU)
		KZfbsjMdlVTvBRnFauPJ = w2vjZmdJuY7c(u"ࠩ࡟ࡶࡡࡴࠧઞ").join(nJID9RhYQwL4MbxPK18dU)
		KZfbsjMdlVTvBRnFauPJ = KZfbsjMdlVTvBRnFauPJ.encode(m6PFtLblInpNZ8x)
		KZfbsjMdlVTvBRnFauPJ = HHP76VFiKDS2xphlGsqN48j1.b64encode(KZfbsjMdlVTvBRnFauPJ)
	else: KZfbsjMdlVTvBRnFauPJ = eHdDoxhJCEPMZFVa2fg
	url = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪટ")][FB0pIzAoK8wqgd3UiY5]
	j6KOlzWGugZqmx0sPS = {KQ3sCe9Pzh(u"ࠫࡸࡻࡢ࡫ࡧࡦࡸࠬઠ"):dNvRhlVX5B,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ડ"):sh3cDaZzUkKQFEAl74OryuPtGqJ,ehfEsaiJBSvbcULtNPVgykA2(u"࠭࡬ࡰࡩࡩ࡭ࡱ࡫ࠧઢ"):KZfbsjMdlVTvBRnFauPJ}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,KQ3sCe9Pzh(u"ࠧࡑࡑࡖࡘࠬણ"),url,j6KOlzWGugZqmx0sPS,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡊࡔࡄࡠࡇࡐࡅࡎࡒ࠭࠲ࡵࡷࠫત"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if eNEhtuoi9gK8JaTpIXj(u"ࠩࠥࡷࡺࡩࡣࡦࡧࡧࡩࡩࠨ࠺ࠡ࠳࠯ࠫથ") in nR2B1Wye7luXb5: gZdOM2jYEfV = YchIv6N09BaWPEj4tieAnluKZrRXT
	else: gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
	if showDialogs:
		if gZdOM2jYEfV:
			dqKGMYgJxSF8Ub1kotlsP936Ww7B(w2vjZmdJuY7c(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭દ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡘࡻࡣࡤࡧࡶࡷࠬધ"))
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠫન"),KQ3sCe9Pzh(u"࠭สๆࠢศีุอไࠡษ็ีุอไสࠢห๊ัออࠨ઩"))
		else:
			dqKGMYgJxSF8Ub1kotlsP936Ww7B(I5bUBGpPXn0W6(u"ࠧๅๆฦืๆࠦแีๆࠣห้หัิษ็ࠫપ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡈࡤ࡭ࡱࡻࡲࡦࠩફ"))
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬબ"),w2vjZmdJuY7c(u"ࠪา฼ษ้ࠠใื่ࠥ็๊ࠡวิืฬ๊ࠠศๆิืฬ๊ษࠨભ"))
	return gZdOM2jYEfV
def EElnUxkvM8p():
	z7zRKcweSZAk = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࠶࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡁࡳࡣࡥ࡭ࡨࠦࡴࡦࡺࡷࡸࠥࡺࡨࡦࡰࠣ࡫ࡴࠦࡴࡰࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡢࡰࡧࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡨࡲࡲࡹࠦࡴࡰࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪમ")
	bYrLlO9uMs5tm0IGFhK2v = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬ࠷࠮ࠡࠢࠣษีอࠠๅัํ็๋ࠥิไๆฬࠤๆ๐ࠠศๆฦัึ็ࠠศๆ฼ีอ๐ษࠡใสิ์ฮࠠฦๆ์ࠤส฿ฯศัสฮࠥ๎วอ้ฬࠤ่๎ฯ๋ࠢฮ้ࠥเ๊าࠢส่ำ฽ࠠศๆ่ืฯิฯๆࠢศ่๎ࠦࠢࡂࡴ࡬ࡥࡱࠨࠧય")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡁࡳࡣࡥ࡭ࡨࠦࡐࡳࡱࡥࡰࡪࡳࠧર"),z7zRKcweSZAk+LTN6DPEmrwehtZMy(u"ࠧ࡝ࡰ࡟ࡲࠬ઱")+bYrLlO9uMs5tm0IGFhK2v)
	z7zRKcweSZAk = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨ࠴࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡣࡢࡰ࡟ࠫࡹࠦࡦࡪࡰࡧࠤࠧࡇࡲࡪࡣ࡯ࠦࠥ࡬࡯࡯ࡶࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥࡹ࡫ࡪࡰࠣࡥࡳࡪࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡩࡳࡳࡺࠧલ")
	bYrLlO9uMs5tm0IGFhK2v = jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࠵࠲ࠥࠦࠠฦาสࠤ้๋ࠠหฮาࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣๅ็๋ࠠษฬ฽๎๏ืࠠศๆฯ่ิࠦหๆࠢๅ้ࠥฮส฻์ิࠤฬ๊ฮุࠢสู่๊สฯั่ࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠩળ")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠪࡊࡴࡴࡴࠡࡒࡵࡳࡧࡲࡥ࡮ࠩ઴"),z7zRKcweSZAk+f90fGrlSEObDsuiA3U(u"ࠫࡡࡴ࡜࡯ࠩવ")+bYrLlO9uMs5tm0IGFhK2v)
	z7zRKcweSZAk = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࠹࠮ࠡࠢࠣࡍ࡫ࠦࡹࡰࡷࠣࡨࡴࡴ࡜ࠨࡶࠣ࡬ࡦࡼࡥࠡࡃࡵࡥࡧ࡯ࡣࠡࡍࡨࡽࡧࡵࡡࡳࡦࠣࡸ࡭࡫࡮ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡧ࡮ࡥࠢࡦ࡬ࡦࡴࡧࡦࠢࡷ࡬ࡪࠦࡲࡦࡩ࡬ࡳࡳࡧ࡬ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠪશ")
	bYrLlO9uMs5tm0IGFhK2v = f90fGrlSEObDsuiA3U(u"࠭࠳࠯ࠢࠣࠤสึวࠡๆ่ࠤ๏้ๆࠡๆา๎่ࠦไ้ฯฬࠤ๊็วห์ะࠤ฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦลฺัสำฬะ้ࠠษฯ๋ฮࠦใ้ัํࠤะ๋ࠠ฻์ิࠤส฿ฯศัสฮࠥอไๆฺ่ๆฮࠦวๅฮ฽ีฬ็๊สࠩષ")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡇࡱࡱࡸࠥࡖࡲࡰࡤ࡯ࡩࡲ࠭સ"),z7zRKcweSZAk+I5bUBGpPXn0W6(u"ࠨ࡞ࡱࡠࡳ࠭હ")+bYrLlO9uMs5tm0IGFhK2v)
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(NxXMrsTC5FniYuRBOK8(u"ࠩࡦࡩࡳࡺࡥࡳࠩ઺"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡊࡴࡴࡴࠡࡵࡨࡸࡹ࡯࡮ࡨࡵࠪ઻"),t3coAp06zvHrTl49bUVgx(u"ࠫࡉࡵࠠࡺࡱࡸࠤࡼࡧ࡮ࡵࠢࡷࡳࠥ࡭࡯ࠡࡶࡲࠤࠧࡑ࡯ࡥ࡫ࠣࡍࡳࡺࡥࡳࡨࡤࡧࡪࠦࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠣࠢࡱࡳࡼࠦ࠿ࠨ઼")+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡢ࡮࡝ࡰࠪઽ")+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭็ๅࠢอี๏ีࠠศๆำ๋ฬฮࠠฦๆ์ࠤ้๎อสࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฤๆล๊ฤ࠭ા"))
	if zf7iFX1auw0bQU==XugxFprC26zGM(u"࠷ೄ"): R0DwTL8OCnWbP3aSoYF2()
	return
def bGsIrdyjE9k6Vh():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪિ"),I5bUBGpPXn0W6(u"ࠨ฼ส่ออࠠศๆึฬอࠦ็้่๊ࠢࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥอไๆ฼ำ๎๊ࠥไษำ้ห๊า้ࠠๆ็ฮศ้ฯࠡไ่ࠤอะิ฻์็ࠤฬ๊ัศสฺࠤฬ๊ะ๋ࠢ็หࠥ๐ูๆๆࠣฯ๊ࠦโๆࠢหษึูวๅุ่่๊ࠢษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢส่็อฦๆหࠣห้ืฦ๋ีํอ๊ࠥไษำ้ห๊าࠧી"))
	return
def uKh8rUFTHSGi1tEvIpo32BXN95Jy():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡ็ัฺูࠦแใู่้ࠣเษࠡษ็฽ึฮ๊ส๋่่ࠢ์่ࠠาสࠤ้อ๋ࠠ็้฽ࠥ๎ฬ้ั้ࠣํอโฺࠢไ๎์อࠠฤใ็ห๊่ࠦๆี็ื้อสࠡ็อีั๋ษࠡล๋ࠤ๊ีศๅฮฬࠤส๊้ࠡษ็่฿ฯࠠศๆ฼ีอ๐ษ๊ࠡส่๎ࠦไ฻ษอࠤฬิั๊๋่ࠢฬ๊้ࠦฮาࠤุฮศࠡๆ็ฮ่ืวาࠩુ")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ૂ"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def JCFXSBNPu809MniR7OAEf1zebK3():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = wY1p9mP03S8drbcH64t5WQkv(u"ࠫฬ๊ั้ษห฻ࠥอไษูํสฮࠦไศࠢ฼่ฬ่ษࠡๆ๊หࠥฮวๅสิ๊ฬ๋ฬ๊ࠡ฽ห้ฮวࠡษ็ือฮ่๊้๋ࠠࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦวๅ็฽ิ๏ࠦไๅสิ๊ฬ๋ฬࠨૃ")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨૄ"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def Tbzw54Kc8JBgtA():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = jUcmHhgVvW0EdYOIfXeaDF(u"࠭็๋ࠢึ๎ึ็ัศฬ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡษึฮำีวๆ้สࠤอูศษࠢๆ์๋ํวࠡ็ะ้๏ฯࠠๆ่ࠣห้๋ีะำࠣวํࠦศฮษฯอࠥหไ๊ࠢสุฯืวไࠢิื๊๐ࠠฤ๊ࠣะิ๐ฯสࠢฦ์๊ࠥวࠡ์฼ีๆํวࠡษ็ฬึ์วๆฮࠪૅ")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ૆"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨีํีๆืวหࠢึ๎หฯࠠฤ๊้ࠣัํ่ๅหࠪે"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def VFjcJd0ZROysuEAxt7lf6():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = bP01xn84BiQN(u"ࠩสุ่๐ัโำสฮࠥอไฺษ่อࠥํ๊ࠡีํีๆืวหࠢัหึา๊ส๋ࠢ฾๏ืࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦอ็ํ฽ࠥอไๆ๊สๆ฾ࠦสิฬัำ๊ํว๊ࠡ฼หิฯࠠหๅ๋๊๋ࠥฬศ่ํอࠥ๎ๅีษๆ่์อࠠไอํีฮࠦไศ่ࠣห้็๊ะ์๋๋ฬะࠠโ์๊หࠥหๅศࠢห฻๏ฬษࠡล๋ࠤ๊๋ๆ้฻ฬࠤศ๎ࠠๆฯำ์ๆฯࠠฤ๊ࠣๅ๏ํวࠡ็ื็้ฯࠠฮไ๋ๆࠥอไๆๆๆ๎ฮࡢ࡮࡝ࡰ࡟ࡲฬ๊ำ๋ำไีฬะࠠศๆัหฺฯ่ࠠ์ࠣื๏ืแาษอࠤฯอศฺห่้๋่ࠣใ฻ࠣห้ษีๅ์ࠣ์ู๊สฯั่อࠥ็๊ࠡ็๋ห็฿ࠠใๆํ่ฮࠦฬะษࠣ์฾อฯสࠢอ็ํ์ࠠๆัไ์฾ฯࠠศๆฦะึࠦร้ࠢํ้้้็ศࠢส่๊๎โฺࠢส่ศ฻ไ๋๋่ࠢ์ึวࠡใ๊๎ࠥา๊ะหุ๊ࠣฮ๊ศ๋ࠢืึ๐ูสู๋้ࠢอใๅ้สࠤ็๊๊ๅหࠣะิอࠧૈ")
	YTUtDCvHs6eQEPi1FJ(ietolwsjpIPK7Fr(u"ࠪࡧࡪࡴࡴࡦࡴࠪૉ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ૊"),sh3cDaZzUkKQFEAl74OryuPtGqJ,LTN6DPEmrwehtZMy(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨો"))
	return
def R9ABWE5Vw7OazD2k0M():
	z7zRKcweSZAk = HkiMU0QrdzW3l6gwnT(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧૌ")
	bYrLlO9uMs5tm0IGFhK2v = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹્ࠩ")
	i25MesXmlJoQNOgLPbIqDrVvG9 = NxXMrsTC5FniYuRBOK8(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩ૎")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૏"),z7zRKcweSZAk,bYrLlO9uMs5tm0IGFhK2v,i25MesXmlJoQNOgLPbIqDrVvG9)
	return
def k8B273ZKPbostnFNRDVf():
	bYrLlO9uMs5tm0IGFhK2v = HkiMU0QrdzW3l6gwnT(u"ࠪห้้วี๊ࠢ์๋ࠥฮำ่้ࠣษ่สࠡๆ็้฾๊่ๆษอࠤ๏ูสฯั่๋ࠥอไษำ้ห๊าࠠๅะี๊ࠥ฻แฮษอࠤฬ๊ล็ฬิ๊๏ะ้ࠠำ๋หอ฽ࠠศๆไ๎ิ๐่่ษอࠤ้๊่ึ๊็ࠤส๊๊่ษࠣฬุืูส๋ࠢฬิ๎ๆࠡว้ฮึ์๊ห๋ࠢห้ฮั็ษ่ะࠥ๐ๅิฯ๊หࠥะไใษษ๎ฬࠦศฺัࠣห๋ะ็ศรࠣ฽๊ื็ศ๋ࠢว๏฼วࠡ฻้ำࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦ࠮๊๊ࠡิฬࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡีห฽ฮࠦร็๊ส฽ู๊ࠥๆำࠣห้้วีࠢ࠽ࠫૐ")
	bYrLlO9uMs5tm0IGFhK2v += jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡡࡴ࡜࡯ࠩ૑") + iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬ࠷࠮ࠡอสฬฯࠦไๅืไัฬะࠠศๆอ๎ู๋ࠥา๊ไࠤศ์็ศࠢ็หࠥะส฻์ิࠤ๋ํวว์สࠤํ๋ฯห้ࠣࠫ૒") + str(ICRfWub2vqlor0Q/eNEhtuoi9gK8JaTpIXj(u"࠶࠱೅")/eNEhtuoi9gK8JaTpIXj(u"࠶࠱೅")/XugxFprC26zGM(u"࠳࠶ೆ")/ietolwsjpIPK7Fr(u"࠵࠳ೇ")) + iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࠠี้ิࠫ૓")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm + ehfEsaiJBSvbcULtNPVgykA2(u"ࠧ࠳࠰ࠣะิอุ๊ࠠํ่ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไๆใิ์฻ࠦร็้สࠤ้อࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭૔") + str(oTdjz7uhFYDxOvgaRnJcP5X/t3coAp06zvHrTl49bUVgx(u"࠹࠴ೈ")/t3coAp06zvHrTl49bUVgx(u"࠹࠴ೈ")/RqLvTrID0yMVeClpYcnZ16i3X(u"࠶࠹೉")) + LyOR7f69iA(u"ࠨࠢํ์๊࠭૕")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm + ietolwsjpIPK7Fr(u"ࠩ࠶࠲ࠥ฽่๋ๆࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊่ࠡสำึอࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭૖") + str(c4cPSX2jOIm8KCQlfW5wM/NxXMrsTC5FniYuRBOK8(u"࠻࠶ೊ")/NxXMrsTC5FniYuRBOK8(u"࠻࠶ೊ")/RqLvTrID0yMVeClpYcnZ16i3X(u"࠸࠴ೋ")) + KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࠤ๏๎ๅࠨ૗")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm + S8i3sBYoHWdTURpAgN(u"ࠫ࠹࠴ࠠๆฬ๋ื฼ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ็ีࠠหฬ฽๎ึ่ࠦๆัอ๋ࠥ࠭૘") + str(bbfreYhcgwZlKEGVx7zRU/eNEhtuoi9gK8JaTpIXj(u"࠶࠱ೌ")/eNEhtuoi9gK8JaTpIXj(u"࠶࠱ೌ")) + jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࠦำศ฻ฬࠫ૙")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm + J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࠵࠯ࠢๅู๏ืࠠศๆ่ำ๎ࠦไๅืไัฬะࠠศๆอ๎ࠥะส฻์ิࠤิอฦๆษࠣ์๊ีส่ࠢࠪ૚") + str(srU0Sl1oOC29FB6gHTYX/TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠲್")/TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠲್")) + Cp6c5tZe8I0PxnAW(u"ࠧࠡีส฽ฮ࠭૛")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm + LTN6DPEmrwehtZMy(u"ࠨ࠸࠱ࠤัีวࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣ็ะ๐ัศ๋้ࠢิะ็ࠡࠩ૜") + str(OclpauhMYPIx502SgUe1X7EWd/egY8Jti0smdLM3h1VQRSW(u"࠸࠳೎")) + jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࠣำ็๐โสࠩ૝")
	bYrLlO9uMs5tm0IGFhK2v += kDUv7ouWrcgMe6OipQJm + KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪ࠻࠳ࠦศะ๊้ࠤ่อิࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦศิำ฼อࠥ๎ๅะฬ๊ࠤࠬ૞") + str(ZAl2gePWifs3IXG) + iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࠥีโ๋ไฬࠫ૟")
	bYrLlO9uMs5tm0IGFhK2v += KW5bYS20wTF1LyCs9(u"ࠬࡢ࡮࡝ࡰࠪૠ") + J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ๅฬๆส࠾ࠥ฻แฮษอࠤ็๎วว็ࠣห้ษแๅษ่ࠤํอไๆี็ื้อส๊ࠡส่า๊โศฬࠣ฽๊ื็ศࠢࠪૡ") + str(bbfreYhcgwZlKEGVx7zRU/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")) + ilBWK5nXxg1do4jENGC07Zq(u"ࠧࠡีส฽ฮࠦ࠮ࠡล่ห่่ࠥศศ่ࠤศ์่ศ฻ࠣห้็๊ะ์๋๋ฬะࠠโ฻่ี์อࠠࠨૢ") + str(c4cPSX2jOIm8KCQlfW5wM/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")/wY1p9mP03S8drbcH64t5WQkv(u"࠶࠹೐")) + wY1p9mP03S8drbcH64t5WQkv(u"ࠨࠢฦ๎ฬ๋ࠠ࠯ࠢฦ้ฬࠦๅๅใสฮࠥอไโ์า๎ํࠦแฺ็ิ๋ฬࠦࠧૣ") + str(srU0Sl1oOC29FB6gHTYX/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")) + w2vjZmdJuY7c(u"ࠩࠣืฬ฿ษࠡใๅ฻ࠥ࠴ࠠฤ็สࠤๆำีࠡำๅ้ࠥอไฦืาหึࠦแฺ็ิ๋ࠥ࠭૤") + str(OclpauhMYPIx502SgUe1X7EWd/QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠴೏")) + ietolwsjpIPK7Fr(u"ࠪࠤิ่๊ใหࠣ࠲ࠥษๅศࠢไัฺࠦวีฬิห่ࠦเࡊࡒࡗ࡚ࠥ็ูๆำ๊ࠤࠬ૥") + str(ZAl2gePWifs3IXG) + XugxFprC26zGM(u"ࠫࠥีโ๋ไฬࠫ૦")
	YTUtDCvHs6eQEPi1FJ(w2vjZmdJuY7c(u"ࠬࡸࡩࡨࡪࡷࠫ૧"),KW5bYS20wTF1LyCs9(u"࠭ๅศ๊ࠢ์ࠥอไไษืࠤฬ๊ๅิฬัำ๊ࠦแ๋ࠢส่อืๆศ็ฯࠫ૨"),bYrLlO9uMs5tm0IGFhK2v,t3coAp06zvHrTl49bUVgx(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ૩"))
	return
def EP2ZUvDOb6hoa4GLnVFqyCH():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = ietolwsjpIPK7Fr(u"ࠨษ็ๅฬ฻ไสࠢอ฽๋๐ࠠๆฮ็ำࠥฮๆโีࠣหุ๋็ࠡษ็วฺ๊๊๊ࠡส่๋่ืสࠢอ฽๋๐ࠠฤ่ࠣห้อำๆࠢส่ศ฻ไ๋ࠢอ้ࠥะูะ์็๋ࠥ๎แศื็อࠥ๎ๆใูฬࠤฯ฿ๆ๊่ࠢะ้ี้ࠠฬ่ࠤฯ฿ฯ๋ๆࠣหุ๋็๊ࠡหำํ์ฺࠠๆส้ฮࠦสฺ่ํࠤ๊๊แࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠫ૪")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ૫"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def CdJ6uvjN1HP497fD5EzcXOkTBx():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = I5bUBGpPXn0W6(u"ࠪษีอ้ࠠษฯ๋ฯ้ࠠๆึๆ่ฮࠦแ๋ࠢสู่ฮใส๋ࠢฮ๊ࠦอๅ้สࠤ࠳࠴࠮ࠡล๋ࠤฬ์ใࠡฬ฻๊ࠥษๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡๅส๊ࠥ็ุ๊่่่๊ࠢษࠡ็วๆฯํ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦแฦา้ࠤัืศࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสฺ่อࠦวๅืไัฮࠦวๅืะ๎าฯ้ࠠฬัึ๏์็ศࠢหำ้อࠠๆ่ࠣห้฻แฮหࠣห้่ฯ๋็ฬࠫ૬")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ૭"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def LsVaoqUXzKMeQr():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = HkiMU0QrdzW3l6gwnT(u"ࠬอไ฻ำูࠤ๊์ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่๊๊ࠠࠣอๆࠡืะอࠥ๎ำา์ฬࠤฬ๊ๅฺๆ๋้ฬะࠠศๆ่ฮออฯๅหࠣฬ๏์ࠠศๆหี๋อๅอ๋ࠢห้๋่ใ฻ࠣห้๋ิโำࠣ์์ึวࠡษ็ฺ๊อๆࠡ฼ํี๋ࠥืๅ๊หࠤํ๊วࠡฯสะฮࠦไ่ࠢ฼๊ิࠦวๅษอูฬ๊ࠠศ๊ࠣห้ืศุ่ࠢ฽๋่ࠥศไ฼ࠤฬ๊แ๋ัํ์์อสࠡษ็ู้็ัสࠩ૮")
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ૯"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
	return
def qyOVGw4i8xTKXMZBS02bz7s1Irgo():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ૰"),LTN6DPEmrwehtZMy(u"ࠨๆๆ๎ࠥ๐ูๆๆ๋ࠣีอࠠศๆ้์฾ࠦๅ็ࠢส่ๆ๐ฯ๋๊๊หฯࠦ࡜࡯ࠢํะอࠦสโ฻ํ่ࠥหึศใฬࠤฬูๅ่ษࠣࡠࡳࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭૱"))
	oIUetMrjGswW21QNiHSJgK3mnCd0D(NxXMrsTC5FniYuRBOK8(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ૲"),YchIv6N09BaWPEj4tieAnluKZrRXT)
	return
def w8wafJRQI1rx():
	sh3cDaZzUkKQFEAl74OryuPtGqJ  = ietolwsjpIPK7Fr(u"้ࠪษิัศࠢๅห๊ะࠠษ฻ูࠤูืใศฬࠣห้หๆหำ้ฮࠥอไะ๊็๎ࠥฮ่ื฻ࠣ฽ฬฬโุࠡาࠤฬ๊ศาษ่ะ๋ࠥหๅࠢๆ์ิ๐ࠠๅฬึ้าࠦแใู่ࠣอ฿ึࠡ็ึฮำีๅ๋ࠢส่๊ะีโฯࠣฬฬ๊ฯฯ๊็ࠤ้๋่ศไ฼ࠤฬ๊แ๋ัํ์ࠬ૳")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += CKUiyEe28zsZ(u"ࠫࠥ๎ๆห์ฯอ๊ࠥ็ัษࠣห้฿ววไࠣๅฬ์็ࠡฬๅี๏ฮวࠡฮ่๎฾ࠦๅิฬัำ๊๐ࠠษำ้ห๊าࠠไ๊า๎๊ࠥวࠡ์ึฮ฼๐ู้่ࠣห้ีฮ้ๆ่ࠣัฺ๋๊่ࠢ์ฬู่ࠡษ็ฬึ์วๆฮࠣัฯ๏ࠠๆ฻ࠣหุะฮะษ่ࠫ૴")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+LTN6DPEmrwehtZMy(u"ࠬๆࠠࠡࡘࡓࡒࠥࠦร้ࠢࠣࡔࡷࡵࡸࡺࠢࠣวํࠦࠠࡅࡐࡖࠤࠥษ่ࠡลํࠤา๊ࠠษีํ฻ࠥศฮาࠩ૵")+Nat0Dx9puRUWCsgz6JyFhY3+kDUv7ouWrcgMe6OipQJm
	sh3cDaZzUkKQFEAl74OryuPtGqJ += NxXMrsTC5FniYuRBOK8(u"࠭࡜࡯ๆส๊ࠥํะศࠢ็๊ࠥ๐อๅࠢสฺ่๊ใๅหࠣ์ส์ๅศࠢไๆ฼ࠦำ๋ไ๋้ࠥฮลึๆสัࠥฮูืࠢส่๊๎วใ฻ࠣ์ส฿วให้ࠣํอโฺࠢสาึ๏ࠠไษ้ฮࠥะูๆๆࠣืฬฮโศࠢหำํ์ࠠๆึส็้࠭૶")
	YTUtDCvHs6eQEPi1FJ(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭૷"),wY1p9mP03S8drbcH64t5WQkv(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ૸"),sh3cDaZzUkKQFEAl74OryuPtGqJ,t3coAp06zvHrTl49bUVgx(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬૹ"))
	sh3cDaZzUkKQFEAl74OryuPtGqJ = TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪห้๋่ศไ฼ࠤฬ๊ส๋ࠢอวะืสࠡสส่฾อฦใࠢ฼๊ิࠦศฺุࠣห้์วิ๊ࠢ๎࠿࠭ૺ")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+eNEhtuoi9gK8JaTpIXj(u"ࠫࡦࡱ࡯ࡢ࡯ࠣࠤࡪ࡭ࡹࡣࡧࡶࡸࠥࠦࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠣࠤࡲࡵࡶࡪࡼ࡯ࡥࡳࡪࠠࠡࡵࡨࡶ࡮࡫ࡳ࠵ࡹࡤࡸࡨ࡮ࠠࠡࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪૻ")+Nat0Dx9puRUWCsgz6JyFhY3
	sh3cDaZzUkKQFEAl74OryuPtGqJ += CKUiyEe28zsZ(u"ࠬࡢ࡮࡝ࡰࠪૼ")+CKUiyEe28zsZ(u"࠭วๅั๋่ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ૽")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+CKUiyEe28zsZ(u"ࠧๆืิࠤࠥอไไ๊ํฮࠥࠦรๆ์ิ็ฬࠦࠠไ่าหࠥࠦแา่ึหࠥࠦวๅ์๋๊ฬ์ࠠࠡสิ๎฼อๆ๋ษࠣห้หๅศำสฮࠥษไๆษ้๎ฬࠦั้ีํหࠥอไ๋ษหห๋ࠦวๅี฼์ิ๐ษࠡำ๋้ฬ์๊ศ๊ࠢ์้์ฯศࠩ૾")+Nat0Dx9puRUWCsgz6JyFhY3
	sh3cDaZzUkKQFEAl74OryuPtGqJ += ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨ࡞ࡱࡠࡳ࠭૿")+f90fGrlSEObDsuiA3U(u"ࠩส่๊ฮัๆฮࠣ์ัีุࠠำํๆฮࠦไหฮส์ืࠦวๅ฻สส็่ࠦๅๅ้๋ฬࠦสฮฬสะࠥา็ะࠢๆฬ๏ื้ࠠษ็้อืๅอࠢํ฼๋ࠦวๅ็ื็้ฯࠠึ฼ํีฮ่ࠦๅษࠣฮุะอใࠢส่ฯ฿ศࠡใศิฬࠦไะ์ๆࠤฺ๊ใๅหࠣฬฬ๊ฯฯ๊็ࠤ้ฮูืࠢส่๊๎วใ฻ࠣ์ศ๐ึศࠢ็็๏๊ࠦหุะࠤาาๅࠡษ็ู้้ไสࠢࠪ଀")
	sh3cDaZzUkKQFEAl74OryuPtGqJ += SbyWQGMDnV+CKUiyEe28zsZ(u"ࠪหึูไࠡำึห้ฯࠠๆฦาฬฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอใหสࠣๅ๏ํวࠡษึ้ࠥฮไะๅࠣ์ศูๅศรࠣห้๋่ศไ฼ࠤฬ๊ส๋ࠢ็หࠥะำหูํ฽ࠥีฮ้ๆ๊หࠬଁ")+Nat0Dx9puRUWCsgz6JyFhY3
	YTUtDCvHs6eQEPi1FJ(LyOR7f69iA(u"ࠫࡷ࡯ࡧࡩࡶࠪଂ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨଃ"),sh3cDaZzUkKQFEAl74OryuPtGqJ,KQ3sCe9Pzh(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ଄"))
	return
def b8UtiZFoxan():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧଅ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢัำ๊อส้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫଆ")+SbyWQGMDnV+HkiMU0QrdzW3l6gwnT(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࠫଇ")+Nat0Dx9puRUWCsgz6JyFhY3+f90fGrlSEObDsuiA3U(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢࠪଈ")+SbyWQGMDnV+w2vjZmdJuY7c(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪଉ")+Nat0Dx9puRUWCsgz6JyFhY3)
	return
def A3X4IBQDaVzsf():
	k8B273ZKPbostnFNRDVf()
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଊ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭็ๅࠢอี๏ีࠠๆีะࠤัฺ๋๊ࠢส่่อิࠡมࠪଋ"),KW5bYS20wTF1LyCs9(u"ࠧศๆๆหู๊ࠦิำ฼ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣ์ู๊อ่ࠢํ฽๏ีࠠิฯหࠤฬ๊ีโฯสฮ๋ࠥๆࠡษ็ษ๋ะั็ฬࠣ฽๋ีࠠศๆะหัฯࠠฦๆํ๋ฬ่ࠦศๆ่ืา๊ࠦห็ࠣฮ้่วว์สࠤ฾์ฯࠡษ้ฮ์อมࠡ฻่ีࠥอไึใะหฯ่ࠦศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧଌ"))
	if zf7iFX1auw0bQU==ilBWK5nXxg1do4jENGC07Zq(u"࠶೑"):
		nwXsRUtrkb4gDOMV8N6ZHTl(YchIv6N09BaWPEj4tieAnluKZrRXT)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠨฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠษษ็็ฬ๋ไࠨ଍"),I5bUBGpPXn0W6(u"ࠩศิฬࠦใศ่อࠤ฾์ฯไุ่่๊ࠢษࠡใํࠤฬำฯࠡษ็้ํอโฺࠢไะึฮࠠศๆ่์็฿ࠠศๆล๊ࠥ࠴࠮࠯๋ࠢวีอࠠศๆุ่่๊ษࠡ็ึฮ๊ืษࠡใศิ๋ࠦวาี็ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪ଎"))
	return zf7iFX1auw0bQU
def BLz9sPWkqKcpnaEJhiyT8d3gojY7mA(showDialogs=YchIv6N09BaWPEj4tieAnluKZrRXT):
	if not showDialogs: showDialogs = YchIv6N09BaWPEj4tieAnluKZrRXT
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,ietolwsjpIPK7Fr(u"ࠪࡋࡊ࡚ࠧଏ"),bP01xn84BiQN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡸࡢ࡯ࡳࡰࡪ࠴ࡣࡰ࡯ࠪଐ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,RqLvTrID0yMVeClpYcnZ16i3X(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ଑"))
	if not aP8bLqZJsQlH3ivWKc.succeeded:
		jDUYVzvN4HJdGqahAK = rDceXBpHkfVUYRJ3tIx95Z
		wEiDnMUNsWC = r17Z5qKTw3gQ()
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࠠࠡࠢࡋࡘ࡙ࡖࡓࠡࡈࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡐࡦࡨࡥ࡭࠼࡞ࠫ଒")+wEiDnMUNsWC+wY1p9mP03S8drbcH64t5WQkv(u"ࠧ࡞ࠩଓ"))
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫଔ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩไัฺࠦวๅษอูฬ๊ࠠศๆุ่ๆืࠠ࠯࠰࠱ࠤฺ๊ใๅหࠣ࠲࠳࠴ࠠศๆสฮฺอไࠡษ็ู้็ัࠡࠪส่ึฮืࠡษ็ู้็ัࠪࠢ็หࠥ๐ูๆๆࠣ฽๋ีใࠡ฻็ํ้่ࠥะ์ࠣ࠲࠳࠴้ࠠ฻้ำ่ࠦใ้ัํࠤ฿๐ัࠡไสำึูࠦๅ๋ࠣหุะฮะษ่ࠤฬ๊ๅ้ษๅ฽ࠥอไๆึไีฮ࠭କ"))
	else:
		jDUYVzvN4HJdGqahAK = YchIv6N09BaWPEj4tieAnluKZrRXT
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଖ"),Cp6c5tZe8I0PxnAW(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨଗ"))
	if not jDUYVzvN4HJdGqahAK and showDialogs: jgudbODHEasWyxFIceqpQNrB9wP()
	return jDUYVzvN4HJdGqahAK
def jgudbODHEasWyxFIceqpQNrB9wP():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨଘ"),LyOR7f69iA(u"࠭ศฺุࠣห้๋่ศไ฼ࠤฯำสศฮࠣีอ฽ࠠๆึไีࠥ๎โะࠢํ็ํ์ࠠอ้สึฺ่๋ࠦำࠣๆฬีัࠡ฻็ํࠥอไาสฺࠤฬ๊ๅีใิࠤศ๎่่ࠠส็๋ࠥิไๆฬࠤๆ๐ࠠี้สำฮࠦวๅฬืๅ๏ืࠠศๆัหฺฯࠠษๅ๋ำ๏ูࠦ็ัๆࠤ฾๊ๅศࠢส๊์ࠦสๆࠢไัฺࠦวๅสิ๊ฬ๋ฬࠡ฻็ํ้่ࠥะ์ࠣห้หีะษิหฯࠦ࡜࡯ࠢ࠴࠻࠳࠼ࠠࠡࠨࠣࠤ࠶࠾࠮࡜࠲࠰࠽ࡢࠦࠠࠧࠢࠣ࠵࠾࠴࡛࠱࠯࠶ࡡࠬଙ"))
	NprJzMKLvDbs9YP3ew2hUiQ()
	return
def kExW7f8PlyVi34NbOYXd(bkA4Xjzw7mJa=eHdDoxhJCEPMZFVa2fg):
	asme31FSC5c8 = YchIv6N09BaWPEj4tieAnluKZrRXT
	if XugxFprC26zGM(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪଚ") not in bkA4Xjzw7mJa:
		asme31FSC5c8 = rDceXBpHkfVUYRJ3tIx95Z
		iL3sKTVC7EZgM9kDajU1FYGBqWrdc = vKD1rqZCXUbcR7n38VyatMSEL(ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨଛ"),XugxFprC26zGM(u"ࠩัีําࠧଜ"),f90fGrlSEObDsuiA3U(u"ࠪษึูวๅุ่่๊ࠢษࠨଝ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠫสืำศๆࠣีุอไสࠩଞ"),w2vjZmdJuY7c(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨଟ"),jUcmHhgVvW0EdYOIfXeaDF(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣฮึูไࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢฦ๊ࠥะัิๆู้้ࠣไส่ࠢ์ั๎ฯสࠢไ๎ࠥอไษำ้ห๊าࠠภࠩଠ"))
		if iL3sKTVC7EZgM9kDajU1FYGBqWrdc in [-LyOR7f69iA(u"࠷೒"),RqLvTrID0yMVeClpYcnZ16i3X(u"࠰೓")]: return
		elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==jUcmHhgVvW0EdYOIfXeaDF(u"࠲೔"):
			asme31FSC5c8 = YchIv6N09BaWPEj4tieAnluKZrRXT
			bkA4Xjzw7mJa = t3coAp06zvHrTl49bUVgx(u"ࠧࡠࡒࡕࡓࡇࡒࡅࡎࡡࠪଡ")
	if asme31FSC5c8:
		if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡡࡓࡖࡔࡈࡌࡆࡏࡢࡓࡑࡊ࡟ࠨଢ") not in bkA4Xjzw7mJa:
			zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(NxXMrsTC5FniYuRBOK8(u"ࠩࡦࡩࡳࡺࡥࡳࠩଣ"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪ์฻฿ࠠศๆุ่่๊ษࠡใํࠤฬ๊ำอๆࠪତ"),LTN6DPEmrwehtZMy(u"ࠫ็ฮไࠡวิืฬ๊ࠠศๆึะู้ࠦๅ์ๆࠤศ์ࠠหๅิีࠥࠦๆโีࠣห้็ูๅࠢส่ี๐ࠠฤ฻ฺห่ࠦวๅ็ื็้ฯࠠ࠯ࠢ็็๏๊ࠦห็ࠣฮุา๊ๅ๊ࠢิ์ࠦวๅ็ื็้ฯࠠโ์ࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠥ࠴้ࠠสา์๋ࠦ็ัษࠣห้ะำอ์็ࠤุ๎แࠡฬิื้ࠦๅๅใ่ࠣฬࠦแศศาอ๋ࠥๆ่ࠢ็ษ๋ํࠠๅษࠣ๎าะ่๋ࠢ฼่๎ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะั๋ัࠣห๋ะࠠศๆศฬ้อฺࠡ฻้๋ฬࠦ࠮้ࠡ็ࠤ็๋สࠡสอ็ึอัࠡษ็ู้้ไสࠢยࠫଥ"))
			if zf7iFX1auw0bQU!=KQ3sCe9Pzh(u"࠳ೕ"):
				dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠨଦ"),NxXMrsTC5FniYuRBOK8(u"࠭ไๅลึๅࠥฮฯ้่ࠣฮุา๊ๅࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡใส๊ࠥอไๆสิ้ัࠦไศࠢํืฯ฽ฺ๊่ࠢ฽ึ็ษࠡษ็ู้้ไส๋่ࠢฬࠦอๅ้สࠤ้อๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩଧ"))
				return
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪନ"),HkiMU0QrdzW3l6gwnT(u"ࠨใํࠤฬ๊ิศึฬࠤฬ๊โศั่อࠥำว้ๆࠣว๋ࠦสไฬหࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ๊ࠡสุึำࠠโ์๊หࠥอไๆึๆ่ฮࠦร้ࠢส่๊๎ึ้฻ࠣ์สึวࠡลิำฯࠦฬ้ษหࠤ๊์ࠠศๆ่ฬึ๋ฬࠡใศิ๋ࠦรไฬหࠤ฾์่ศ่ࠣฬึ๐ฯไࠢฦ่ส๊ใหำ๋๊๏ࠦวๅวํ้๏๊้ࠠฬำ็ึ่ࠦๅษࠣฮู๋้ࠡล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬ଩"))
	search = mJ1lHWKUPcZGezML7X2u9S(header=QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࡚ࠩࡶ࡮ࡺࡥࠡࡣࠣࡱࡪࡹࡳࡢࡩࡨࡩࠥࠦࠠศๅอฬࠥืำศๆฬࠫପ"),source=EERWJf1adv67)
	if not search: return
	sh3cDaZzUkKQFEAl74OryuPtGqJ = search
	if asme31FSC5c8: type = ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠫଫ")
	else: type = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠬବ")
	gZdOM2jYEfV = CpsdhEGBHQZYJcS23wjrxzn(type,sh3cDaZzUkKQFEAl74OryuPtGqJ,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠬࡋࡍࡂࡋࡏ࠱ࡋࡘࡏࡎ࠯ࡘࡗࡊࡘࡓࠨଭ"),bkA4Xjzw7mJa)
	return
def HsdI7rJfXyDajB():
	bkA4Xjzw7mJa = LyOR7f69iA(u"࠭็ัษࠣห้ฮั็ษ่ะ๊ࠥวࠡ์๋ะิࠦไ่ࠢฦ๎ู๊ࠥาใิࠤ๏ูสื์ไࠤศ๐ࠠๆฯอ์๏อส࠯ࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤึ๎วษูࠣ์ฯ฼ๅ๋่่๊ࠣำส้์สฮ๋ࠥัโ๊฼อࠥ฿ไ๊ࠢึ๎ึ็ัศฬࠣาฬืฬ๋ห࠱ࠤฬ๊ศา่ส้ัฺ๋ࠦำุ้ࠣส่ๅࠢ฼๊ࠥษ๊ࠡ็ะฮํ๐วหࠢอ้ࠥะอๆ์็๋ฬูࠦๅ๋ࠣื๏ืแาษอࠤํ๋่ศไ฼ࠤำอัอ์ฬࠤ๋่ࠧศไ฼ࠤ฼ืแࠡอส่ะࠨ࠮ࠡฮ่๎฾ࠦวๅลึ้ฬว้ࠠษ็้ฬืใศฬࠣ์ฬ๊ี้ำࠣ์ฬ๊ๅ็ึ๋ีฬะ่ࠠ์ࠣาฬ฻ษࠡสสูาอศ่ษ࠱ࠤฬ๊ศา่ส้ัࠦไศࠢํ๊ฯํใࠡฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠡࡆࡐࡇࡆࠦลัษࠣ็ฬ์ࠠๅัํ็ฺࠥใ้๋ࠣาฬ฻ษࠡสส่ึ๎วษูࠣ์ฬ๊สืษ่๎๋ࠦวๅะสีั๐ษࠡใส่ึาวยࠢส่ฯ๎วึๆ้ࠣ฾ࠦละษิอࠥํะ่ࠢสุ่๐ัโำสฮࠥ๎วๅ็๋ห็฿ࠠศๆัหึา๊ส࠰๋ࠣีอࠠศๆหี๋อๅอ๊ࠢ์ࠥฮศิษฺอ๋ࠥสึใะࠤ้๋่ศไ฼ࠤฬ๊่๋สࠪମ")
	YTUtDCvHs6eQEPi1FJ(LTN6DPEmrwehtZMy(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ଯ"),t3coAp06zvHrTl49bUVgx(u"ࠨฯๅ์็ࠦวๅูห฽ࠥ๎วๅ่ืีࠥ๎โศ่๋๊ࠥอไฤๆไ๎ฮࠦไๅ็็็๏ฯࠠศๆิๆ๊๐ษࠨର"),bkA4Xjzw7mJa,bP01xn84BiQN(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ଱"))
	bkA4Xjzw7mJa = NxXMrsTC5FniYuRBOK8(u"ࠪࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤ࡭ࡵࡳࡵࠢࡤࡲࡾࠦࡣࡰࡰࡷࡩࡳࡺࠠࡰࡰࠣࡥࡳࡿࠠࡴࡧࡵࡺࡪࡸ࠮ࠡࡋࡷࠤࡴࡴ࡬ࡺࠢࡸࡷࡪࡹࠠ࡭࡫ࡱ࡯ࡸࠦࡴࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡨࡵ࡮ࡵࡧࡱࡸࠥࡺࡨࡢࡶࠣࡻࡦࡹࠠࡶࡲ࡯ࡳࡦࡪࡥࡥࠢࡷࡳࠥࡶ࡯ࡱࡷ࡯ࡥࡷࠦ࡯࡯࡮࡬ࡲࡪࠦࡶࡪࡦࡨࡳࠥ࡮࡯ࡴࡶ࡬ࡲ࡬ࠦࡳࡪࡶࡨࡷ࠳ࠦࡁ࡭࡮ࠣࡸࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠬࠡࡸ࡬ࡨࡪࡵࡳ࠭ࠢࡷࡶࡦࡪࡥࠡࡰࡤࡱࡪࡹࠬࠡࡵࡨࡶࡻ࡯ࡣࡦࠢࡰࡥࡷࡱࡳ࠭ࠢࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࡪࡪࠠࡸࡱࡵ࡯࠱ࠦ࡬ࡰࡩࡲࡷࠥࡸࡥࡧࡧࡵࡩࡳࡩࡥࡥࠢ࡫ࡩࡷ࡫ࡩ࡯ࠢࡥࡩࡱࡵ࡮ࡨࠢࡷࡳࠥࡺࡨࡦ࡫ࡵࠤࡷ࡫ࡳࡱࡧࡦࡸ࡮ࡼࡥࠡࡱࡺࡲࡪࡸࡳࠡ࠱ࠣࡧࡴࡳࡰࡢࡰ࡬ࡩࡸ࠴ࠠࡕࡪࡨࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡰࡲࡸࠥࡸࡥࡴࡲࡲࡲࡸ࡯ࡢ࡭ࡧࠣࡪࡴࡸࠠࡸࡪࡤࡸࠥࡵࡴࡩࡧࡵࠤࡵ࡫࡯ࡱ࡮ࡨࠤࡺࡶ࡬ࡰࡣࡧࠤࡹࡵࠠ࠴ࡴࡧࠤࡵࡧࡲࡵࡻࠣࡷ࡮ࡺࡥࡴ࠰࡛ࠣࡪࠦࡵࡳࡩࡨࠤࡦࡲ࡬ࠡࡥࡲࡴࡾࡸࡩࡨࡪࡷࠤࡴࡽ࡮ࡦࡴࡶ࠰ࠥࡺ࡯ࠡࡴࡨࡧࡴ࡭࡮ࡪࡼࡨࠤࡹ࡮ࡡࡵࠢࡷ࡬ࡪࠦ࡬ࡪࡰ࡮ࡷࠥࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡤࠡࡹ࡬ࡸ࡭࡯࡮ࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡢࡴࡨࠤࡱࡵࡣࡢࡶࡨࡨࠥࡹ࡯࡮ࡧࡺ࡬ࡪࡸࡥࠡࡧ࡯ࡷࡪࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡳࡷࠦࡶࡪࡦࡨࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡢࡴࡨࠤ࡫ࡸ࡯࡮ࠢࡲࡸ࡭࡫ࡲࠡࡸࡤࡶ࡮ࡵࡵࡴࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡌࡪࠥࡿ࡯ࡶࠢ࡫ࡥࡻ࡫ࠠࡢࡰࡼࠤࡱ࡫ࡧࡢ࡮ࠣ࡭ࡸࡹࡵࡦࡵࠣࡴࡱ࡫ࡡࡴࡧࠣࡧࡴࡴࡴࡢࡥࡷࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡰࡩࡩ࡯ࡡࠡࡨ࡬ࡰࡪࠦ࡯ࡸࡰࡨࡶࡸࠦ࠯ࠡࡪࡲࡷࡹ࡫ࡲࡴ࠰ࠣࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡹࡩ࡮ࡲ࡯ࡽࠥࡧࠠࡸࡧࡥࠤࡧࡸ࡯ࡸࡵࡨࡶ࠳࠭ଲ")
	YTUtDCvHs6eQEPi1FJ(LyOR7f69iA(u"ࠫࡱ࡫ࡦࡵࠩଳ"),KW5bYS20wTF1LyCs9(u"ࠬࡊࡩࡨ࡫ࡷࡥࡱࠦࡍࡪ࡮࡯ࡩࡳࡴࡩࡶ࡯ࠣࡇࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦࡁࡤࡶࠣࠬࡉࡓࡃࡂࠫࠪ଴"),bkA4Xjzw7mJa,NxXMrsTC5FniYuRBOK8(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩଵ"))
	return
def clHVSyZfYezbpMhd8B():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪଶ"),HkiMU0QrdzW3l6gwnT(u"ࠨษ็ฬึ์วๆฮ่ࠣฬ๊ࠦโฯุࠤูํวะหࠣห้ะิโ์ิࠤ฾์ฯࠡษ็หฯ฻วๅࠢหห้๋่ศไ฼ࠤฬ๊ๅีใิอࠥ๎ไ่าสࠤๆ๐ࠠฮษ็ࠤํา่ะࠢื๋ฬีษࠡ฼ํีࠥ฻อ๋ฯฬࠤศ๎ࠠๆ่อ๋๏ฯࠠศๆุ่ฬำ๊สࠢฦ์๋ࠥา๋ใฬࠤๆอๆ้ࠡำห๊ࠥๆࠡ์๋ๆๆࠦวๅำห฻ࠥอไๆึไีࠥ๎ไ็ࠢํ์็็ฺࠠ็็ࠤฬ๊ศา่ส้ั࠭ଷ"))
	LsVaoqUXzKMeQr()
	return
def zYlxb0KydPUaqw7WGh134QFNZjL():
	z7zRKcweSZAk,bYrLlO9uMs5tm0IGFhK2v,i25MesXmlJoQNOgLPbIqDrVvG9,NtYlMGwxjLczOC41yKSv,El7SQuMxRV98deFfHLKa5t,eBSdh2ymEjfoG6z5kpQNuibcMgl,tq8Vc5CnhymiWOGZ2ebrE6KwuR = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	j6KOlzWGugZqmx0sPS,HCjxAisvIBTfMZ072YmLwU5r6oc,bbaLgSHKXyCjxV,suw4BUxQH5jAMLC9dgzeZFr = {bP01xn84BiQN(u"ࠩࡤࠫସ"):S8i3sBYoHWdTURpAgN(u"ࠪࡥࠬହ")},{},[],{}
	url = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[S8i3sBYoHWdTURpAgN(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ଺")][NSudqlOzja]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(OclpauhMYPIx502SgUe1X7EWd,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡖࡏࡔࡖࠪ଻"),url,j6KOlzWGugZqmx0sPS,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡗࡖࡅࡌࡋ࡟ࡓࡇࡓࡓࡗ࡚࠭࠲ࡵࡷ଼ࠫ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(LTN6DPEmrwehtZMy(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡔࡶࡤࡸࡪࡹࠧଽ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡗࡖࡅࠬା"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(LTN6DPEmrwehtZMy(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡎ࡭ࡳ࡭ࡤࡰ࡯ࠪି"),bP01xn84BiQN(u"࡙ࠪࡐ࠭ୀ"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(wY1p9mP03S8drbcH64t5WQkv(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡆࡸࡡࡣࠢࡈࡱ࡮ࡸࡡࡵࡧࡶࠫୁ"),I5bUBGpPXn0W6(u"࡛ࠬࡁࡆࠩୂ"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡓࡢࡷࡧ࡭ࠥࡇࡲࡢࡤ࡬ࡥࠬୃ"),KW5bYS20wTF1LyCs9(u"ࠧࡌࡕࡄࠫୄ"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(ietolwsjpIPK7Fr(u"ࠨࡐࡲࡶࡹ࡮ࠠࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪ୅"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡑ࠲ࡒࡧࡣࡦࡦࡲࡲ࡮ࡧࠧ୆"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(RqLvTrID0yMVeClpYcnZ16i3X(u"࡛ࠪࡪࡹࡴࡦࡴࡱࠤࡘࡧࡨࡢࡴࡤࠫେ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫ࡜࠴ࡓࡢࡪࡤࡶࡦ࠭ୈ"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡥ࡟ࡠࠩ୉"),KwJyZLDzC4FbHhXgTfI)
	try: RR6YlXOc9Foa2TqPgdSzsHCtwJK = DIpuHqsKGS3ErJvk9taCRiX80(dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭࡬ࡪࡵࡷࠫ୊"),nR2B1Wye7luXb5)
	except:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪୋ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨใื่ࠥ็๊ࠡฮ็ฬ๋ࠥอห๊ํหฯࠦสใำํีࠥอไศีอาิอๅࠨୌ"))
		return
	yyH2MZpRVk,fcy2k0rzTbhx5PU8anX3dEwjZ9,b7aVT61xE239 = RR6YlXOc9Foa2TqPgdSzsHCtwJK
	suw4BUxQH5jAMLC9dgzeZFr = {}
	T5raWMb3R1Az6e = [KQ3sCe9Pzh(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࡌࡈ୍ࠬ"),egY8Jti0smdLM3h1VQRSW(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡘࡔࡑࡅࡏࠩ୎")]
	ZQLtkAhRsCITxXNBofUelY3d70P1 = [EX25Y0l8ILvz7QcRC(u"ࠫࡆࡒࡌࠨ୏"),KW5bYS20wTF1LyCs9(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ୐"),LTN6DPEmrwehtZMy(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ୑"),LyOR7f69iA(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫ୒"),NxXMrsTC5FniYuRBOK8(u"ࠨࡔࡈࡔࡔ࡙ࠧ୓")]+T5raWMb3R1Az6e+jf6T7xMX5EFuz1Do8OhVpByYak+qKxXzgTdEs3ImAyrNu2DZviRW0
	for uujC2KDqoT3rGHzPpAW1mf,oOY4nAPVU8dsC9MSm,guLwC0Bf9SiTx in fcy2k0rzTbhx5PU8anX3dEwjZ9:
		guLwC0Bf9SiTx = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(guLwC0Bf9SiTx)
		guLwC0Bf9SiTx = guLwC0Bf9SiTx.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).strip(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࠣ࠲ࠬ୔"))
		NtYlMGwxjLczOC41yKSv += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+uujC2KDqoT3rGHzPpAW1mf+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪ࠾ࠥ࠭୕")+Nat0Dx9puRUWCsgz6JyFhY3+guLwC0Bf9SiTx+kDUv7ouWrcgMe6OipQJm
		if oOY4nAPVU8dsC9MSm.isdigit():
			suw4BUxQH5jAMLC9dgzeZFr[uujC2KDqoT3rGHzPpAW1mf] = int(oOY4nAPVU8dsC9MSm)
			if int(oOY4nAPVU8dsC9MSm)>TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠴࠴࠵ೖ"): oOY4nAPVU8dsC9MSm = eNEhtuoi9gK8JaTpIXj(u"ࠫ࡭࡯ࡧࡩࡷࡶࡥ࡬࡫ࠧୖ")
			else: oOY4nAPVU8dsC9MSm = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡲ࡯ࡸࡷࡶࡥ࡬࡫ࠧୗ")
		if uujC2KDqoT3rGHzPpAW1mf not in ZQLtkAhRsCITxXNBofUelY3d70P1:
			if   oOY4nAPVU8dsC9MSm==f90fGrlSEObDsuiA3U(u"࠭ࡨࡪࡩ࡫ࡹࡸࡧࡧࡦࠩ୘"): z7zRKcweSZAk += KwJyZLDzC4FbHhXgTfI+uujC2KDqoT3rGHzPpAW1mf
			elif oOY4nAPVU8dsC9MSm==EX25Y0l8ILvz7QcRC(u"ࠧ࡭ࡱࡺࡹࡸࡧࡧࡦࠩ୙"): bYrLlO9uMs5tm0IGFhK2v += KwJyZLDzC4FbHhXgTfI+uujC2KDqoT3rGHzPpAW1mf
	wmlyhcIbxYNKrApDCjOaJWsP4,RwEe58KodAFHtXZ6B9TyYOg3piuVJ,WdUXmY3tgFuERNjq1vT7HL = list(zip(*fcy2k0rzTbhx5PU8anX3dEwjZ9))
	for uujC2KDqoT3rGHzPpAW1mf in sorted(LSPX4bazoBtC9kh):
		if uujC2KDqoT3rGHzPpAW1mf not in wmlyhcIbxYNKrApDCjOaJWsP4:
			NtYlMGwxjLczOC41yKSv += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+uujC2KDqoT3rGHzPpAW1mf+KQ3sCe9Pzh(u"ࠨ࠼ࠣࠫ୚")+Nat0Dx9puRUWCsgz6JyFhY3+wY1p9mP03S8drbcH64t5WQkv(u"ࠩ็หࠥ๐่อัࠪ୛")+t3coAp06zvHrTl49bUVgx(u"ࠪࡠࡳࡢ࡮ࠨଡ଼")
			if uujC2KDqoT3rGHzPpAW1mf not in ZQLtkAhRsCITxXNBofUelY3d70P1: i25MesXmlJoQNOgLPbIqDrVvG9 += KwJyZLDzC4FbHhXgTfI+uujC2KDqoT3rGHzPpAW1mf
	for guLwC0Bf9SiTx,ww8qbZ4QgUcmjEYkiL73OCozha1 in yyH2MZpRVk:
		guLwC0Bf9SiTx = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(guLwC0Bf9SiTx)
		El7SQuMxRV98deFfHLKa5t += guLwC0Bf9SiTx+w2vjZmdJuY7c(u"ࠫ࠿ࠦࠧଢ଼")+SbyWQGMDnV+str(ww8qbZ4QgUcmjEYkiL73OCozha1)+Nat0Dx9puRUWCsgz6JyFhY3+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࠦࠠࠡࠩ୞")
	z7zRKcweSZAk = z7zRKcweSZAk.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	bYrLlO9uMs5tm0IGFhK2v = bYrLlO9uMs5tm0IGFhK2v.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	i25MesXmlJoQNOgLPbIqDrVvG9 = i25MesXmlJoQNOgLPbIqDrVvG9.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	ffltMmc18vHTK37qkn = z7zRKcweSZAk+KwJyZLDzC4FbHhXgTfI+bYrLlO9uMs5tm0IGFhK2v
	kYTnbXx86lUR3rCQBuPE9G  = NxXMrsTC5FniYuRBOK8(u"࠭ๅ้ษๅ฽ࠥ์ฬฮࠢส่อืๆศ็ฯࠤอะิ฻์็ࠤๆ๐ฯ๋๊๊หฯࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠪୟ")+kDUv7ouWrcgMe6OipQJm+LTN6DPEmrwehtZMy(u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠬୠ")+kDUv7ouWrcgMe6OipQJm
	kYTnbXx86lUR3rCQBuPE9G += SbyWQGMDnV+ffltMmc18vHTK37qkn+Nat0Dx9puRUWCsgz6JyFhY3+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨ࡞ࡱࡠࡳ࠭ୡ")
	kYTnbXx86lUR3rCQBuPE9G += t3coAp06zvHrTl49bUVgx(u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅࠢส่อืๆศ็ฯࠤ๊์็ศࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨୢ")+kDUv7ouWrcgMe6OipQJm+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊ࠠไสํีࠥ๎ฬ้ัู้้ࠣไสࠢไ๎ࠥอไษำ้ห๊าࠧୣ")+kDUv7ouWrcgMe6OipQJm
	kYTnbXx86lUR3rCQBuPE9G += SbyWQGMDnV+i25MesXmlJoQNOgLPbIqDrVvG9+Nat0Dx9puRUWCsgz6JyFhY3
	ksTcd1nRtVYHq,v6mDCTL1YHwWasS7KtV38EBNeob,lUC7ruHnJVO1tyAecZQs9Tbmd,xDPhsjZVXyg = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴೗"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴೗"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴೗"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴೗")
	all = suw4BUxQH5jAMLC9dgzeZFr[ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡆࡒࡌࠨ୤")]
	if ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ୥") in list(suw4BUxQH5jAMLC9dgzeZFr.keys()): ksTcd1nRtVYHq = suw4BUxQH5jAMLC9dgzeZFr[EX25Y0l8ILvz7QcRC(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭୦")]
	if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨ୧") in list(suw4BUxQH5jAMLC9dgzeZFr.keys()): v6mDCTL1YHwWasS7KtV38EBNeob = suw4BUxQH5jAMLC9dgzeZFr[HkiMU0QrdzW3l6gwnT(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩ୨")]
	if w2vjZmdJuY7c(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭୩") in list(suw4BUxQH5jAMLC9dgzeZFr.keys()): lUC7ruHnJVO1tyAecZQs9Tbmd = suw4BUxQH5jAMLC9dgzeZFr[LyOR7f69iA(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ୪")]
	if HkiMU0QrdzW3l6gwnT(u"ࠫࡗࡋࡐࡐࡕࠪ୫") in list(suw4BUxQH5jAMLC9dgzeZFr.keys()): xDPhsjZVXyg = suw4BUxQH5jAMLC9dgzeZFr[EX25Y0l8ILvz7QcRC(u"ࠬࡘࡅࡑࡑࡖࠫ୬")]
	soLjMVe4A7J6q0liv9DtaP = all-ksTcd1nRtVYHq-v6mDCTL1YHwWasS7KtV38EBNeob-lUC7ruHnJVO1tyAecZQs9Tbmd-xDPhsjZVXyg
	ppxnlrkDsXUmKQWFt,bhUjo8GyFMTXPlAr1ftuqvxaSs = b7aVT61xE239[x1Oa8bBf36EwsLMirtFc]
	ppxnlrkDsXUmKQWFt,UlrYayT1zZ = b7aVT61xE239[NSudqlOzja]
	PjI7GO1ztiuRE6ce3lWUsTJfp0Lg2 = bhUjo8GyFMTXPlAr1ftuqvxaSs-UlrYayT1zZ
	tq8Vc5CnhymiWOGZ2ebrE6KwuR += OR97bMGecfgDCqux3YdAZ6y+str(UlrYayT1zZ)+Nat0Dx9puRUWCsgz6JyFhY3+bP01xn84BiQN(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪ୭")
	tq8Vc5CnhymiWOGZ2ebrE6KwuR += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(PjI7GO1ztiuRE6ce3lWUsTJfp0Lg2)+Nat0Dx9puRUWCsgz6JyFhY3+bP01xn84BiQN(u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫ୮")
	tq8Vc5CnhymiWOGZ2ebrE6KwuR += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(bhUjo8GyFMTXPlAr1ftuqvxaSs)+Nat0Dx9puRUWCsgz6JyFhY3+egY8Jti0smdLM3h1VQRSW(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩ୯")
	tq8Vc5CnhymiWOGZ2ebrE6KwuR += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(len(b7aVT61xE239[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠷೘"):]))+Nat0Dx9puRUWCsgz6JyFhY3+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧ୰")
	for CNqlQiod9T4Z,pcG48moFZkRT1Iz7DJaYOqtB in b7aVT61xE239[HkiMU0QrdzW3l6gwnT(u"࠸೙"):]:
		CNqlQiod9T4Z = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(CNqlQiod9T4Z)
		CNqlQiod9T4Z = CNqlQiod9T4Z.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).strip(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࠤ࠳࠭ୱ"))
		tq8Vc5CnhymiWOGZ2ebrE6KwuR += CNqlQiod9T4Z+wY1p9mP03S8drbcH64t5WQkv(u"ࠫ࠿ࠦࠧ୲")+SbyWQGMDnV+str(pcG48moFZkRT1Iz7DJaYOqtB)+Nat0Dx9puRUWCsgz6JyFhY3+f90fGrlSEObDsuiA3U(u"ࠬࠦࠠࠡࠩ୳")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += OR97bMGecfgDCqux3YdAZ6y+str(soLjMVe4A7J6q0liv9DtaP)+Nat0Dx9puRUWCsgz6JyFhY3+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭แ๋ัํ์์อสࠡษืฮ฿๊สࠡ࠼ࠣࠫ୴")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(ksTcd1nRtVYHq)+Nat0Dx9puRUWCsgz6JyFhY3+wY1p9mP03S8drbcH64t5WQkv(u"ุࠧๆหหฯࠦำ๋ำไีࠥฮว๋อ๋๊ࠥࡀࠠࠨ୵")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(xDPhsjZVXyg)+Nat0Dx9puRUWCsgz6JyFhY3+XugxFprC26zGM(u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫ୶")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(v6mDCTL1YHwWasS7KtV38EBNeob)+Nat0Dx9puRUWCsgz6JyFhY3+ehfEsaiJBSvbcULtNPVgykA2(u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭୷")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(lUC7ruHnJVO1tyAecZQs9Tbmd)+Nat0Dx9puRUWCsgz6JyFhY3+KW5bYS20wTF1LyCs9(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩ୸")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+str(len(yyH2MZpRVk))+Nat0Dx9puRUWCsgz6JyFhY3+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫ୹")
	eBSdh2ymEjfoG6z5kpQNuibcMgl += t3coAp06zvHrTl49bUVgx(u"ࠬࡢ࡮࡝ࡰࠪ୺")+El7SQuMxRV98deFfHLKa5t
	YTUtDCvHs6eQEPi1FJ(ietolwsjpIPK7Fr(u"࠭ࡣࡦࡰࡷࡩࡷ࠭୻"),f90fGrlSEObDsuiA3U(u"ฺࠧัาࠤฬ๊รอ้ีอࠥอไห์ࠣหุะฮะ็อࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ୼"),tq8Vc5CnhymiWOGZ2ebrE6KwuR,ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ୽"))
	YTUtDCvHs6eQEPi1FJ(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡦࡩࡳࡺࡥࡳࠩ୾"),ilBWK5nXxg1do4jENGC07Zq(u"ࠪ฽ิีࠠศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢื฾้ํว้ࠡำหࠥอไษำ้ห๊าࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠไๆ๊ࠫ୿"),eBSdh2ymEjfoG6z5kpQNuibcMgl,jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ஀"))
	YTUtDCvHs6eQEPi1FJ(Cp6c5tZe8I0PxnAW(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ஁"),S8i3sBYoHWdTURpAgN(u"࠭ๅ้ษๅ฽ࠥอิห฼็ฮࠥ็๊ࠡ࠵ࠣว๏อๅࠡษ็้ฬ฼๊สࠢไ๎ࠥอไฺษ็้้ࠥไ่ࠩஂ"),kYTnbXx86lUR3rCQBuPE9G,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪஃ"))
	YTUtDCvHs6eQEPi1FJ(t3coAp06zvHrTl49bUVgx(u"ࠨ࡮ࡨࡪࡹ࠭஄"),KW5bYS20wTF1LyCs9(u"ࠩฦ฽้๏ࠠศๆา์้ࠦวๅฬํࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡษึฮำีๅหࠢส่อืๆศ็ฯࠫஅ"),NtYlMGwxjLczOC41yKSv,ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫஆ"))
	return
def XJdD17jzA6PYM9hGlyUi0osWep3():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = S8i3sBYoHWdTURpAgN(u"ࠫ์ึวࠡษ็ฬึ์วๆฮࠣ๎฾๋ไࠡษไฺ้ࠦศศีอาิอๅࠡฮ็ำ้่ࠥะ์ࠣࠬࡐࡵࡤࡪࠢࡖ࡯࡮ࡴࠩࠡษ็ิ๏ࠦวิ็๊ࡠࡳ࠭இ")+OR97bMGecfgDCqux3YdAZ6y+bP01xn84BiQN(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫஈ")+Nat0Dx9puRUWCsgz6JyFhY3+CKUiyEe28zsZ(u"࠭࡜࡯࡞ࡱࡠࡳ่ࠦๆ็ๆ๊ࠥะหษ์อ๋ࠥฮวิฬัำฬ๋ࠠๆีอ์ิ฿ฺࠠ็สำࠥࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠠฤ๊ࠣฮา๋๊ๅ้้๋ࠣࡢ࡮ࠨஉ")+OR97bMGecfgDCqux3YdAZ6y+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯ࠨஊ")+Nat0Dx9puRUWCsgz6JyFhY3+bP01xn84BiQN(u"ࠨ࡞ࡱࡠࡳࡢ࡮้ࠡำ๋ࠥอไาีส่ฮ่ࠦ฻์ิ๋ฬࠦใฬ์ิࠤ๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥอไษำ้ห๊า้ࠠษ็้ื๐ฯࠡลํฺฬࠦๅ้ฮ๋ำࠥ็๊ࠡไสส๊ฯࠠฤฮ๋ฬฮࠦวๅสิ๊ฬ๋ฬࠨ஋")
	YTUtDCvHs6eQEPi1FJ(t3coAp06zvHrTl49bUVgx(u"ࠩࡦࡩࡳࡺࡥࡳࠩ஌"),eNEhtuoi9gK8JaTpIXj(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭஍"),sh3cDaZzUkKQFEAl74OryuPtGqJ,ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧஎ"))
	return
def Zfw4yEWTN5ImUb1():
	sh3cDaZzUkKQFEAl74OryuPtGqJ = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬอไาษห฻๏์ࠠฤั้ห์ࠦแ๋้่หࠥะืษ์ๅࠤ่๎ฯ๋ࠢ฼้ฬี้้๋ࠠࠤ฾ฮวาหࠣ฽๋ࠦสฬสํฮ้ࠥวๆๆࠣหํะ่ๆษอ๎่๐ࠠๅสิ๊ฬ๋ฬࠡๅ๋ำ๏่ࠦๆ฻๊ࠤฬ฼วโหࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ่ࠦๆ฻๊ࠤฬ฼วโหࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬี้ࠠ็฼๋ࠥอึศใฬࠤู๊ส้ั฼ࠤ฾๋วะ๋ࠢๅ๏ํࠠฤ์ูหࠥาๅ๋฻ࠣห฾ีวะฬࠣ็ํี๊ࠡษ็้฼๊่ษห่ࠣ฾๋ไࠡสิ๊ฬ๋ฬࠡ฻่หิ่ࠦไๆ๊หࠥะสๆࠢส์ฯ๎ๅศฬํ็๏อ้ࠠๆสࠤฯำสศฮࠣว๏ࠦๆ้฻้๋ࠣࠦวๅะหีฮࠦแ๋ࠢๆ์ิ๐ࠠฤ๊ࠣห้ิศาหࠣๅ๏ࠦสฬสํฮࠥษึศใสฮ้่ࠥะ์ࠪஏ")+kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬஐ")][x1Oa8bBf36EwsLMirtFc]+Nat0Dx9puRUWCsgz6JyFhY3+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࠡࠢࠣࠤࠥࠦร้ࠢࠣࠤࠥࠦࠠࠨ஑")+SbyWQGMDnV+VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[eNEhtuoi9gK8JaTpIXj(u"ࠨࡍࡒࡈࡎࡋࡍࡂࡆࡢࡅࡕࡖࠧஒ")][NSudqlOzja]+Nat0Dx9puRUWCsgz6JyFhY3
	sh3cDaZzUkKQFEAl74OryuPtGqJ += eNEhtuoi9gK8JaTpIXj(u"ࠩ࡟ࡲࡡࡴ࡜࡯ษ็ีฬฮืࠡลา๊ฬํ่๊ࠠࠣหู้่าีࠣห้ึ๊ࠡ์ะฮฬา็ࠡ็า๎ึࠦๅๅใสฮ้่ࠥะ์่ࠣฯัศ๋ฬࠣฬึ์วๆฮࠣ฽๊อฯࠡสส่฼ื๊ใหࠣห้ะโๅ์า๎ฮࠦวๅไา๎๊ฯ࡜࡯ࠩஓ")+SbyWQGMDnV+VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[KQ3sCe9Pzh(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫஔ")][NSudqlOzja]+Nat0Dx9puRUWCsgz6JyFhY3
	sh3cDaZzUkKQFEAl74OryuPtGqJ += eNEhtuoi9gK8JaTpIXj(u"ࠫࡡࡴ࡜࡯࡞ࡱะ๊๐ูࠡ็็ๅฬะฺࠠ็สำ๋่ࠥอ๊าอࠥ็๊ࠡษ็้ํู่ࠡลา๊ฬํࠧக")+kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[TMKXOwyLdzhDj1Q6PmoigsbV4(u"࡙ࠬࡏࡖࡔࡆࡉࡘ࠭஖")][FB0pIzAoK8wqgd3UiY5]+Nat0Dx9puRUWCsgz6JyFhY3
	YTUtDCvHs6eQEPi1FJ(I5bUBGpPXn0W6(u"࠭ࡣࡦࡰࡷࡩࡷ࠭஗"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧศๆ่์ฬู่ࠡษ็ีุ๋๊สࠢ็ฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮ࠭஘"),sh3cDaZzUkKQFEAl74OryuPtGqJ,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫங"))
	return
def ezW8AjIMi2mLFBGPuUT4o5Y73VZO(SNCfmrpeH2xi5EA9):
	ccwRLKk3hs0E.executebuiltin(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࠨச")+SNCfmrpeH2xi5EA9+f90fGrlSEObDsuiA3U(u"ࠪ࠭ࠬ஛"), YchIv6N09BaWPEj4tieAnluKZrRXT)
	return
def R0DwTL8OCnWbP3aSoYF2():
	mOoylMuTX7VUjNJq6YK4(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡸࡺ࡯ࡱࠩஜ"))
	ccwRLKk3hs0E.executebuiltin(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡇࡣࡵ࡫ࡹࡥࡹ࡫ࡗࡪࡰࡧࡳࡼ࠮ࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࡕࡨࡸࡹ࡯࡮ࡨࡵࠬࠦ஝"))
	return
def NDBtXxOp05sJ3F48IEwHMhqPa():
	ccwRLKk3hs0E.executebuiltin(w2vjZmdJuY7c(u"࠭ࡁࡥࡦࡲࡲ࠳ࡕࡰࡦࡰࡖࡩࡹࡺࡩ࡯ࡩࡶࠬ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠭ࠬஞ"), YchIv6N09BaWPEj4tieAnluKZrRXT)
	return
def ttoCNWqlOrS7MFb2dH():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪட"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨๆ่ืาࠦๅฮฬ๋๎ฬะࠠใษษ้ฮࠦ࠮ࠡษำ๋อࠦลๅ๋ࠣห้่วว็ฬࠤฬ๊ส๋ࠢอี๏ีࠠๆีะ๋ฬ่ࠦๅษࠣฮิิไࠡว็๎์อ้ࠠๆๆ๊ࠥฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥษ่ࠡษึฮำีๅࠡࠤส่่๐ศ้ำาࠦࠥ๎วื฼ฺࠤ฾๊้ࠡฯิๅࠥࠨࡃࠣࠢฦ์ࠥ฿ไ๊ࠢสฺ฿฽ฺࠠๆ์ࠤืืࠠࠣษ็ๆฬฬๅสࠤࠣห้ึ๊ࠡใํࠤัํษࠡษ็๎๊๐ๆࠨ஠"))
	return
def GihVylwKIxma019czL8kTuW():
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ஡"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"่้ࠪะูศ็็ࠤ๊฿ࠠศๆ่ๅ฻๊ษࠡ࠰ࠣหีํศࠡว็ํࠥอไาษห฻ࠥอไั์ࠣฮึ๐ฯࠡวูหๆะ็ࠡล๋ࠤู๊อ่่๊ࠢࠥࠦโศศ่อࠥอไๆใู่ฮ่ࠦๅๅ้ࠤ้อࠠห่ๅีࠥ฿ไ๋้ࠣ์้อࠠหึ฽่์ࠦ࠮๊ࠡหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํษๅศࠢหหุะฮะษ่ࠤࠧอไไ์ห์ึีࠢࠡใสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํุࠥัࠡࠤส่็อฦๆหࠥࠤฬ๊ะ๋ࠢไ๎ࠥา็สࠢส่๏๋๊็ࠢ࠱ࠤํ์แิࠢส่่๊วๆ๋ࠢห้฽ั๋ไฬࠤ฾์ฯࠡษ็ฮ฾อๅๅ่ࠢ฽๋ࠥอห๊ํหฯࠦโ้ษษ้ࠥอไๆใู่ฮ࠭஢"))
	return
def Fpxmz3y9f6YTPrtn8Olv41XiGEI(KKXmvMoA65VS4ECyT=bP01xn84BiQN(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪண"),showDialogs=YchIv6N09BaWPEj4tieAnluKZrRXT):
	SjmNBbHlIezGr2URoEp3f = ccwRLKk3hs0E.executeJSONRPC(NxXMrsTC5FniYuRBOK8(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨத"))
	import json as Z9rkmwbQ7V2DvgoR0XOLTquNKPls
	data = Z9rkmwbQ7V2DvgoR0XOLTquNKPls.loads(SjmNBbHlIezGr2URoEp3f)
	VWq4zoTHiJSZRMN05Lj91Kudwl7P = data[XugxFprC26zGM(u"࠭ࡲࡦࡵࡸࡰࡹ࠭஥")][ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡷࡣ࡯ࡹࡪ࠭஦")]
	if lHfbysRrUV7m4CLSdkxc382n: VWq4zoTHiJSZRMN05Lj91Kudwl7P = VWq4zoTHiJSZRMN05Lj91Kudwl7P.encode(m6PFtLblInpNZ8x)
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ஧"),egY8Jti0smdLM3h1VQRSW(u"๊่ࠩࠥะั๋ัࠣฮ฿๐๊าࠢฯ่ิࠦࠧந")+VWq4zoTHiJSZRMN05Lj91Kudwl7P+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࠤฬ๊ะ๋่ࠢืฯิฯๆࠢส่ว์ࠠโ์ࠣ็ํี๊ࠡว็ํࠥอไฦืาหึࠦวๅลั๎ึࠦไอๆาࠤࠬன")+KKXmvMoA65VS4ECyT+HkiMU0QrdzW3l6gwnT(u"ࠫࠥลࠡࠨப"))
		if zf7iFX1auw0bQU!=egY8Jti0smdLM3h1VQRSW(u"࠱೚"): return rDceXBpHkfVUYRJ3tIx95Z
	gZdOM2jYEfV,om1vMzaYHt,ttAlMoGjXU8DzW = JYLugbHop1x6V7mqhNGXd3Bk8icEZ(KKXmvMoA65VS4ECyT,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	if gZdOM2jYEfV:
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ஫"),LTN6DPEmrwehtZMy(u"࠭สๆฬࠣ฽๊๊๊สࠢอฯอ๐สࠡษ็ะ้ีࠠศๆฯำ๏ี้้๋ࠠࠤัอ็ำࠢ็่ฬูสฯัส้ࠥ࠴ࠠิ๊ไࠤ๏ะๅࠡษ็ฦ๋ࠦส฻์ํีࠥหูะษาหฯࠦใ้ัํࠤ้้๊ࠡ์ึฮ฾๋ไࠡษ็ะ้ีࠠศๆฯำ๏ีࠠษั็ห๋ࠥๆࠡษ็ๆิ๐ๅࠨ஬"))
		zbiGC4DUKEx = ccwRLKk3hs0E.executeJSONRPC(wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵ࡯࡬ࡣࡱࡨ࡫࡫ࡥ࡭࠰ࡶ࡯࡮ࡴࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼ࠥࠫ஭")+KKXmvMoA65VS4ECyT+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࠤࢀࢁࠬம"))
		gZdOM2jYEfV = YchIv6N09BaWPEj4tieAnluKZrRXT if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࡒࡏࠬய") in zbiGC4DUKEx else rDceXBpHkfVUYRJ3tIx95Z
		b8bLFaejUB.sleep(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠲೛"))
		ccwRLKk3hs0E.executebuiltin(ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪர"))
	elif showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧற"),XugxFprC26zGM(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧல"))
	return gZdOM2jYEfV
def NprJzMKLvDbs9YP3ew2hUiQ():
	url = t3coAp06zvHrTl49bUVgx(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫள")
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,t3coAp06zvHrTl49bUVgx(u"ࠧࡈࡇࡗࠫழ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫவ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	cERVSMpW26L1amr4oqHd7XU9Dw = cBawilJXvK1m.findall(ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨஶ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cERVSMpW26L1amr4oqHd7XU9Dw = cERVSMpW26L1amr4oqHd7XU9Dw[x1Oa8bBf36EwsLMirtFc].split(ilBWK5nXxg1do4jENGC07Zq(u"ࠪ࠱ࠬஷ"))[x1Oa8bBf36EwsLMirtFc]
	nO0Agh3J5RSfsdkUYMb = str(YB5Segc7IQ)
	NtYlMGwxjLczOC41yKSv = wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ஸ")+OR97bMGecfgDCqux3YdAZ6y+cERVSMpW26L1amr4oqHd7XU9Dw+Nat0Dx9puRUWCsgz6JyFhY3
	NtYlMGwxjLczOC41yKSv += ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡢ࡮࡝ࡰࠪஹ")+jUcmHhgVvW0EdYOIfXeaDF(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ஺")+OR97bMGecfgDCqux3YdAZ6y+nO0Agh3J5RSfsdkUYMb+Nat0Dx9puRUWCsgz6JyFhY3
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ஻"),NtYlMGwxjLczOC41yKSv)
	return
def iQBr8OKptGFMIHay():
	d4Ce7kGoRbJ31ctYlv,PrxDQFKcNZBlTb0HefOkVy,MMQsdtvDhBmzHoRCeKu = rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	hC6SDtWdlz4B1KH7jonmiTfAOr,IG1hQWm3ulMjVfFrTBqvPZ,KFCZd01Uuvn329L5fqo8TB = rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	GFXuYIaiM4DNTjOVRg0oSsLn7p = [ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭஼"),EX25Y0l8ILvz7QcRC(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫ஽"),NxXMrsTC5FniYuRBOK8(u"ࠪࡷࡰ࡯࡮࠯࡯ࡨࡸࡷࡵࡰࡰ࡮࡬ࡷࡊࡓࡁࡅࠩா")]
	H8hMP0qweGaor3OJjWBVzT = w1HecvLmKCBrR95ASN(GFXuYIaiM4DNTjOVRg0oSsLn7p)
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E in GFXuYIaiM4DNTjOVRg0oSsLn7p:
		if L1BnkG7RhvcXZoWfjdDHq3Uzu2E not in list(H8hMP0qweGaor3OJjWBVzT.keys()): continue
		VVe7Ii8ZmuK6,nS2sOfpTLZxdc8HK7IJ6,GGXUERJrl89BLTt5Dyn14bYZOQ,Q3pvnWLzmMi4ofbXPH,uME79trWK4kbQPp26lOiCw5Rayz,SrfGcYwzl6XxMWqT91F,EHn6CXxDe3LYQ8vS9ZscK5hWJt = H8hMP0qweGaor3OJjWBVzT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E]
		if L1BnkG7RhvcXZoWfjdDHq3Uzu2E==dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩி"):
			hC6SDtWdlz4B1KH7jonmiTfAOr = VVe7Ii8ZmuK6
			IG1hQWm3ulMjVfFrTBqvPZ = t3coAp06zvHrTl49bUVgx(u"ࠬ࠮ࠧீ")+nS2sOfpTLZxdc8HK7IJ6+avcfIls8w7gk69hYUErHxzQTXtm24j+v9vBX6ZiQ0UHxfze8EjG4nmRW(SrfGcYwzl6XxMWqT91F)+RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࠩࠨு")
			KFCZd01Uuvn329L5fqo8TB = Q3pvnWLzmMi4ofbXPH
		elif L1BnkG7RhvcXZoWfjdDHq3Uzu2E==LTN6DPEmrwehtZMy(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩூ"):
			d4Ce7kGoRbJ31ctYlv = d4Ce7kGoRbJ31ctYlv or VVe7Ii8ZmuK6
			PrxDQFKcNZBlTb0HefOkVy += KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࠢࠣ࠰ࠥࠦࠨࠨ௃")+nS2sOfpTLZxdc8HK7IJ6+avcfIls8w7gk69hYUErHxzQTXtm24j+v9vBX6ZiQ0UHxfze8EjG4nmRW(SrfGcYwzl6XxMWqT91F)+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࠬࠫ௄")
			MMQsdtvDhBmzHoRCeKu += iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࠤࠥ࠲ࠠࠡࠩ௅")+Q3pvnWLzmMi4ofbXPH
		elif L1BnkG7RhvcXZoWfjdDHq3Uzu2E==TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪெ"):
			AJLfq4HvGSwRQEY1hZOo = VVe7Ii8ZmuK6
			UuFjfvagLh520Vkop6K8E4CPiS = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬ࠮ࠧே")+nS2sOfpTLZxdc8HK7IJ6+avcfIls8w7gk69hYUErHxzQTXtm24j+v9vBX6ZiQ0UHxfze8EjG4nmRW(SrfGcYwzl6XxMWqT91F)+HkiMU0QrdzW3l6gwnT(u"࠭ࠩࠨை")
			IIfndM0N8YslqDW4FEwSVLh = Q3pvnWLzmMi4ofbXPH
	PrxDQFKcNZBlTb0HefOkVy = PrxDQFKcNZBlTb0HefOkVy.strip(Cp6c5tZe8I0PxnAW(u"ࠧࠡࠢ࠯ࠤࠥ࠭௉"))
	MMQsdtvDhBmzHoRCeKu = MMQsdtvDhBmzHoRCeKu.strip(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࠢࠣ࠰ࠥࠦࠧொ"))
	PPiv9JZlB4ymq1pRzknXW0  = Cp6c5tZe8I0PxnAW(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧோ")+OR97bMGecfgDCqux3YdAZ6y+KFCZd01Uuvn329L5fqo8TB+Nat0Dx9puRUWCsgz6JyFhY3
	PPiv9JZlB4ymq1pRzknXW0 += kDUv7ouWrcgMe6OipQJm+w2vjZmdJuY7c(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬௌ")+OR97bMGecfgDCqux3YdAZ6y+IG1hQWm3ulMjVfFrTBqvPZ+Nat0Dx9puRUWCsgz6JyFhY3
	PPiv9JZlB4ymq1pRzknXW0 += TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡡࡴ࡜࡯்ࠩ")+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪ௎")+OR97bMGecfgDCqux3YdAZ6y+MMQsdtvDhBmzHoRCeKu+Nat0Dx9puRUWCsgz6JyFhY3
	PPiv9JZlB4ymq1pRzknXW0 += kDUv7ouWrcgMe6OipQJm+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨ௏")+OR97bMGecfgDCqux3YdAZ6y+PrxDQFKcNZBlTb0HefOkVy+Nat0Dx9puRUWCsgz6JyFhY3
	PPiv9JZlB4ymq1pRzknXW0 += S8i3sBYoHWdTURpAgN(u"ࠧ࡝ࡰ࡟ࡲࠬௐ")+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬ௑")+OR97bMGecfgDCqux3YdAZ6y+IIfndM0N8YslqDW4FEwSVLh+Nat0Dx9puRUWCsgz6JyFhY3
	PPiv9JZlB4ymq1pRzknXW0 += kDUv7ouWrcgMe6OipQJm+eNEhtuoi9gK8JaTpIXj(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪ௒")+OR97bMGecfgDCqux3YdAZ6y+UuFjfvagLh520Vkop6K8E4CPiS+Nat0Dx9puRUWCsgz6JyFhY3
	VVe7Ii8ZmuK6 = hC6SDtWdlz4B1KH7jonmiTfAOr or d4Ce7kGoRbJ31ctYlv
	if VVe7Ii8ZmuK6:
		header = w2vjZmdJuY7c(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬ௓")
		krdDRZKFsomBxzPNvAOyXJu6 = I5bUBGpPXn0W6(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬ௔")
	else:
		header = XugxFprC26zGM(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭௕")
		krdDRZKFsomBxzPNvAOyXJu6 = f90fGrlSEObDsuiA3U(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨ௖")
	v0AURbLhlNT9xYaZ3fK = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨௗ")
	W0z8CHBK5pfIu1ZGc4wgQ = PPiv9JZlB4ymq1pRzknXW0+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨ࡞ࡱࡠࡳ࠭௘")+krdDRZKFsomBxzPNvAOyXJu6+wY1p9mP03S8drbcH64t5WQkv(u"ࠩ࡟ࡲࡡࡴࠧ௙")+v0AURbLhlNT9xYaZ3fK
	YTUtDCvHs6eQEPi1FJ(eNEhtuoi9gK8JaTpIXj(u"ࠪࡶ࡮࡭ࡨࡵࠩ௚"),header,W0z8CHBK5pfIu1ZGc4wgQ,S8i3sBYoHWdTURpAgN(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ௛"))
	return VVe7Ii8ZmuK6
def YJFCmkrw9Z7aLP3gOzQv1f2n0WEVB(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,EHn6CXxDe3LYQ8vS9ZscK5hWJt,showDialogs):
	gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ௜"),egY8Jti0smdLM3h1VQRSW(u"࠭ำ้ใࠣ๎ฯ๋ࠠศๆล๊ࠥาไษࠢส่๊๊แࠡษ็้฻เุ่ࠢ็่ส฼วโหࠣห้๋ืๅ๊หอ๊ࠥใ๋ࠢํฮ๊ࠦสฬสํฮ์ูࠦๅ๋ࠣ็ํี๊ࠡ࠰ࠣห้๋ไโࠢๅำࠥ๐ใ้่ࠣ็อ๐ั๊ࠡๅำࠥ๐อหษฯࠤอ฿ึࠡษ็์็ะࠠ࠯๊่ࠢࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡษ็ฦ๋ࠦฟࠢࠩ௝"))
		if zf7iFX1auw0bQU!=ilBWK5nXxg1do4jENGC07Zq(u"࠳೜"): return rDceXBpHkfVUYRJ3tIx95Z
	LfQ9ztOaxYpUMl057brcnWX3Syo = L7IPyDUvXQwA2e9fChNruZcYM50(EHn6CXxDe3LYQ8vS9ZscK5hWJt,{},showDialogs)
	if LfQ9ztOaxYpUMl057brcnWX3Syo:
		RLDMZP5egEVtaIdzyX2KQwjlcU = RRydns1CErYlIhwSx7.path.join(IIzGues0tMAEHi1jYoTvdFCZK,L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
		ycgRbjNoPLQSnx(RLDMZP5egEVtaIdzyX2KQwjlcU,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
		import zipfile as BgP1eq2U4iSNWrvLlOGjxVfXhJR,io as YjK3UhqGMlto4nrb29CIix1Z0L
		v58vBMqJU3wTNZ2 = YjK3UhqGMlto4nrb29CIix1Z0L.BytesIO(LfQ9ztOaxYpUMl057brcnWX3Syo)
		try:
			LB6me53apMGFEjYz0UyNxvQW = BgP1eq2U4iSNWrvLlOGjxVfXhJR.ZipFile(v58vBMqJU3wTNZ2)
			LB6me53apMGFEjYz0UyNxvQW.extractall(IIzGues0tMAEHi1jYoTvdFCZK)
			b8bLFaejUB.sleep(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠴ೝ"))
			ccwRLKk3hs0E.executebuiltin(ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ௞"))
			b8bLFaejUB.sleep(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠵ೞ"))
			gZdOM2jYEfV = MMDBVkgTuY4C28eQF6AtRNWj(L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
		except: gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
	if showDialogs:
		if gZdOM2jYEfV: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ௟"),f90fGrlSEObDsuiA3U(u"ࠩอ้ࠥฮๆอษะࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭௠"))
		else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭௡"),CKUiyEe28zsZ(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠหอห๎ฯࠦวๅวูหๆฯࠠศๆ่฻้๎ศสࠩ௢"))
	return gZdOM2jYEfV
def oIUetMrjGswW21QNiHSJgK3mnCd0D(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,showDialogs=YchIv6N09BaWPEj4tieAnluKZrRXT):
	if showDialogs==eHdDoxhJCEPMZFVa2fg: showDialogs = YchIv6N09BaWPEj4tieAnluKZrRXT
	PCvw9dVF0748NOkHtYgj5K1a = hUsDr25MwJBp([L1BnkG7RhvcXZoWfjdDHq3Uzu2E])
	nnLE3baWTV9sDh05pevgAxM,yyZvhUkrLW1uoKzD = PCvw9dVF0748NOkHtYgj5K1a[L1BnkG7RhvcXZoWfjdDHq3Uzu2E]
	if yyZvhUkrLW1uoKzD:
		gZdOM2jYEfV = YchIv6N09BaWPEj4tieAnluKZrRXT
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ௣"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭แฮืࠣห้หึศใฬࠤࡡࡴࠠࠨ௤")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠๆ๊ฯ์ิฯ้ࠠ็ไ฽้ฯ้ࠠฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪ௥"))
	else:
		gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(bP01xn84BiQN(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ௦"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ௧"),eHdDoxhJCEPMZFVa2fg+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+bP01xn84BiQN(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅࠣ฾๏ืࠠๆใ฼่ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮࠦ࠮ࠡ์ฯฬࠥะหษ์อ๋ฬ่ࠦหใ฼๎้ํวࠡๆๆ๎ࠥ๐ูๆๆࠣห้ฮั็ษ่ะࠥ฿ๆะๅࠣฬฺ๎ัสุࠢั๏ำษࠡ࠰๋้ࠣࠦสา์าࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆ๋ࠣีํࠠศๆศฺฬ็ษࠡษ็ฦ๋ࠦฟࠨ௨"))
		if zf7iFX1auw0bQU==KW5bYS20wTF1LyCs9(u"࠶೟"):
			ccwRLKk3hs0E.executebuiltin(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫࠫ௩")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+LTN6DPEmrwehtZMy(u"ࠬ࠯ࠧ௪"))
			b8bLFaejUB.sleep(J7divaGOCgq2SLfXpDzZYN58wc(u"࠷ೠ"))
			ccwRLKk3hs0E.executebuiltin(t3coAp06zvHrTl49bUVgx(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭௫"))
			b8bLFaejUB.sleep(I5bUBGpPXn0W6(u"࠱ೡ"))
			while ccwRLKk3hs0E.getCondVisibility(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ௬")): b8bLFaejUB.sleep(eNEhtuoi9gK8JaTpIXj(u"࠲ೢ"))
			gZdOM2jYEfV = MMDBVkgTuY4C28eQF6AtRNWj(L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
			if showDialogs and gZdOM2jYEfV: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ௭"),Cp6c5tZe8I0PxnAW(u"ࠩอ้ࠥ็อึࠢฦ์ࠥะหษ์อࠤศ๎ࠠหใ฼๎้ࠦร้ࠢอัิ๐หࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠤํํ๊ࠡษ็ฦ๋ࠦฬศ้ีอ๊ࠥไศีอาิอๅࠨ௮"))
			elif showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭௯"),f90fGrlSEObDsuiA3U(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭௰"))
	return gZdOM2jYEfV
def wzPWYBIF8EsxJjog3DQpetGv9407h(showDialogs):
	if not showDialogs: zf7iFX1auw0bQU = YchIv6N09BaWPEj4tieAnluKZrRXT
	else: zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(LyOR7f69iA(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ௱"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ௲"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧษำ้ห๊าࠠไ๊า๎ࠥ๐โ้็ࠣฬ฾๋ไ๋หࠣฮาี๊ฬࠢฯ้๏฿ࠠศๆศฺฬ็วหࠢอ่็อฦ๋ษࠣ็้ࠦ࠲࠵ࠢึห฾ฯ้ࠠๆๆ๊๋ࠥๅไ่ࠣษัืวย้สࠤฬ๊ย็ࠢ࠱ࠤ์๊ࠠหำํำࠥะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠศๆล๊ࠥลࠧ௳"))
	if zf7iFX1auw0bQU==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳ೣ"):
		ccwRLKk3hs0E.executebuiltin(S8i3sBYoHWdTURpAgN(u"ࠨࡗࡳࡨࡦࡺࡥࡂࡦࡧࡳࡳࡘࡥࡱࡱࡶࠫ௴"))
		if showDialogs:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ௵"),Cp6c5tZe8I0PxnAW(u"ࠪฮ๊ࠦลาีส่ࠥ฽ไษࠢศ่๎ࠦศา่ส้ัࠦใ้ัํࠤฬ๊ะ๋ࠢไ๎ࠥา็ศิๆࠤ้้๊ࠡ์ๅ์๊ࠦศหฯา๎ะࠦฬๆ์฼ࠤส฼วโษอࠤ่๎ฯ๋ࠢ࠱ࠤอ๋วࠡใํ๋ฬࠦสฮัํฯࠥํะศࠢส่อืๆศ็ฯࠤํะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠢ࠱ࠤ๏ืฬ๊ࠢศ฽฼อมࠡๅ๋ำ๏ࠦ࠵ࠡัๅหห่ࠠฤ๊ࠣว่ััࠡๆๆ๎ࠥ๐ๆ่์ࠣ฽๊๊๊สࠢส่ฯำฯ๋อࠪ௶"))
	return
def O0NLWgDywb3tZpYdjuM1c():
	k5L96NenKBwpSYWv(pyifuNFdxe,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ௷"),CKUiyEe28zsZ(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭௸"))
	NprJzMKLvDbs9YP3ew2hUiQ()
	VVe7Ii8ZmuK6 = iQBr8OKptGFMIHay()
	if VVe7Ii8ZmuK6:
		bo8mpKfd5eaERB32vGz(YchIv6N09BaWPEj4tieAnluKZrRXT)
		wzPWYBIF8EsxJjog3DQpetGv9407h(YchIv6N09BaWPEj4tieAnluKZrRXT)
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def MMDBVkgTuY4C28eQF6AtRNWj(L1BnkG7RhvcXZoWfjdDHq3Uzu2E):
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ccwRLKk3hs0E.executeJSONRPC(ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ௹")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿ࡺࡲࡶࡧࢀࢁࠬ௺"))
	succeeded = YchIv6N09BaWPEj4tieAnluKZrRXT if ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡑࡎࠫ௻") in JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 else rDceXBpHkfVUYRJ3tIx95Z
	return succeeded
def h2G6rHt3zf5Kobx(L1BnkG7RhvcXZoWfjdDHq3Uzu2E):
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ccwRLKk3hs0E.executeJSONRPC(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡃࡧࡨࡴࡴࡳ࠯ࡕࡨࡸࡆࡪࡤࡰࡰࡈࡲࡦࡨ࡬ࡦࡦࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡣࡧࡨࡴࡴࡩࡥࠤ࠽ࠦࠬ௼")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+egY8Jti0smdLM3h1VQRSW(u"ࠪࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡨࡤࡰࡸ࡫ࡽࡾࠩ௽"))
	succeeded = YchIv6N09BaWPEj4tieAnluKZrRXT if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡔࡑࠧ௾") in JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 else rDceXBpHkfVUYRJ3tIx95Z
	return succeeded
def JYLugbHop1x6V7mqhNGXd3Bk8icEZ(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,showDialogs,MSeJdhcn8xtwC,H8hMP0qweGaor3OJjWBVzT=None):
	zf7iFX1auw0bQU,succeeded,om1vMzaYHt,nS2sOfpTLZxdc8HK7IJ6 = YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ௿"),eHdDoxhJCEPMZFVa2fg
	if not H8hMP0qweGaor3OJjWBVzT: H8hMP0qweGaor3OJjWBVzT = w1HecvLmKCBrR95ASN([L1BnkG7RhvcXZoWfjdDHq3Uzu2E])
	if L1BnkG7RhvcXZoWfjdDHq3Uzu2E in list(H8hMP0qweGaor3OJjWBVzT.keys()):
		VVe7Ii8ZmuK6,nS2sOfpTLZxdc8HK7IJ6,GGXUERJrl89BLTt5Dyn14bYZOQ,Q3pvnWLzmMi4ofbXPH,uME79trWK4kbQPp26lOiCw5Rayz,SrfGcYwzl6XxMWqT91F,EHn6CXxDe3LYQ8vS9ZscK5hWJt = H8hMP0qweGaor3OJjWBVzT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E]
		if SrfGcYwzl6XxMWqT91F==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡧࡰࡱࡧࠫఀ"):
			succeeded,om1vMzaYHt = YchIv6N09BaWPEj4tieAnluKZrRXT,KW5bYS20wTF1LyCs9(u"ࠧ࡯ࡱࡷ࡬࡮ࡴࡧࠨఁ")
			if MSeJdhcn8xtwC and showDialogs:
				zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫం"),S8i3sBYoHWdTURpAgN(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦใ้ัํࠤ๏ูสฯั่ࠤศิัࠡวุำฬืࠠๆฬ๋ๅึࠦแ๋่ࠢ์ฬู่ࠡ็ึฮํีูࠡ฻่หิࠦไ่า๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩః")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+egY8Jti0smdLM3h1VQRSW(u"ࠪࡠࡳࡢ࡮่ๆࠣฮึ๐ฯࠡว฼หิฯࠠหอห๎ฯࠦ็ั้ࠣห้หึศใฬࠤ๊ืษࠡลัี๎࠭ఄ"))
				if zf7iFX1auw0bQU:
					succeeded = YJFCmkrw9Z7aLP3gOzQv1f2n0WEVB(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,EHn6CXxDe3LYQ8vS9ZscK5hWJt,rDceXBpHkfVUYRJ3tIx95Z)
					if succeeded:
						om1vMzaYHt = KQ3sCe9Pzh(u"ࠫࡷ࡫ࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩఅ")
						if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨఆ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢ์ั๎ฯสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮลฺษาอࠥะหษ์อ๋ฬࡢ࡮࡝ࡰࠪఇ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
					else:
						om1vMzaYHt = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧఈ")
						dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫఉ"),S8i3sBYoHWdTURpAgN(u"ࠩ็่ศูแࠡ࠰࠱ࠤฬ๊ศา่ส้ัࠦไๆࠢํืฯ฽ฺ๊ࠢศ฽ฬีษࠡฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࡡࡴ࡜࡯ࠩఊ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
		else:
			if showDialogs:
				if SrfGcYwzl6XxMWqT91F==egY8Jti0smdLM3h1VQRSW(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬఋ"): sh3cDaZzUkKQFEAl74OryuPtGqJ = bP01xn84BiQN(u"๊ࠫะ่ใใฬࠫఌ")
				elif SrfGcYwzl6XxMWqT91F==HkiMU0QrdzW3l6gwnT(u"ࠬࡵ࡬ࡥࠩ఍"): sh3cDaZzUkKQFEAl74OryuPtGqJ = ietolwsjpIPK7Fr(u"࠭โะ์่อࠬఎ")
				elif SrfGcYwzl6XxMWqT91F==NxXMrsTC5FniYuRBOK8(u"ࠧ࡮࡫ࡶࡷ࡮ࡴࡧࠨఏ"): sh3cDaZzUkKQFEAl74OryuPtGqJ = w2vjZmdJuY7c(u"ࠨ฼ํี๋ࠥหษฬฬࠫఐ")
				zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ఑"),S8i3sBYoHWdTURpAgN(u"๋ࠪีํࠠศๆศฺฬ็ษࠡࠩఒ")+sh3cDaZzUkKQFEAl74OryuPtGqJ+t3coAp06zvHrTl49bUVgx(u"ࠫࠥ࠴࠮้ࠡ็ࠤฯื๊ะࠢศู้ออ้ࠡำ๋ࠥอไๆึๆ่ฮࠦฟࠢ࡞ࡱࡠࡳ࠭ఓ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
			if not zf7iFX1auw0bQU: om1vMzaYHt = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧఔ")
			else:
				if SrfGcYwzl6XxMWqT91F==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨక"):
					succeeded = MMDBVkgTuY4C28eQF6AtRNWj(L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
					if succeeded:
						om1vMzaYHt = eNEhtuoi9gK8JaTpIXj(u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨఖ")
						if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫగ"),CKUiyEe28zsZ(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧఘ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
					elif showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ఙ"),S8i3sBYoHWdTURpAgN(u"้๊ࠫริใࠣ࠲࠳ࠦวๅวูหๆฯࠠๆฬ๋ๆๆฯࠠ࠯࠰ࠣ์้๋๋ࠠีอ฻๏฿ࠠศๆหี๋อๅอࠢอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧచ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
				elif SrfGcYwzl6XxMWqT91F in [w2vjZmdJuY7c(u"ࠬࡵ࡬ࡥࠩఛ"),bP01xn84BiQN(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧజ")]:
					succeeded = YJFCmkrw9Z7aLP3gOzQv1f2n0WEVB(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,EHn6CXxDe3LYQ8vS9ZscK5hWJt,rDceXBpHkfVUYRJ3tIx95Z)
					if succeeded:
						if SrfGcYwzl6XxMWqT91F==XugxFprC26zGM(u"ࠧࡰ࡮ࡧࠫఝ"): om1vMzaYHt = TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩఞ")
						elif SrfGcYwzl6XxMWqT91F==wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪట"): om1vMzaYHt = Cp6c5tZe8I0PxnAW(u"ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭ఠ")
						nS2sOfpTLZxdc8HK7IJ6 = Q3pvnWLzmMi4ofbXPH
						if showDialogs:
							if om1vMzaYHt==KQ3sCe9Pzh(u"ࠫࡺࡶࡤࡢࡶࡨࡨࠬడ"): dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨఢ"),wY1p9mP03S8drbcH64t5WQkv(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆหࠢๅำ๏๋ษࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะอะ์ฮ๋ฬࡢ࡮࡝ࡰࠪణ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
							elif om1vMzaYHt==ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪత"): dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫథ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠๅ็ࠣฮ่์ࠠๆ๊ฯ์ิฯࠠโ์ࠣ็ํี๊ࠡ࠰࠱ࠤํอไษำ้ห๊าࠠใษ่ࠤอะหษ์อ๋ฬࡢ࡮࡝ࡰࠪద")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
					elif showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ధ"),bP01xn84BiQN(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤฯำฯ๋อࠣวํࠦสฬสํฮࠥํะ่ࠢส่ส฼วโห࡟ࡲࡡࡴࠧన")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
	elif showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ఩"),ietolwsjpIPK7Fr(u"࠭ไๅลึๅࠥ࠴࠮้ࠡำ๋ࠥอไฦุสๅฮฺ๋ࠦำ้ࠣํา่ะหࠣๅ๏ࠦๅิฬ๋ำ฾ูࠦๆษาࠤ࠳࠴้ࠠๆ๊ิฬࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤศ์๋ࠠไ๋้ࠥฮสฬสํฮࠥํะ่ࠢส่ส฼วโหࠣวํࠦสฮัํฯ์อ࡜࡯࡞ࡱࠫప")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
	return succeeded,om1vMzaYHt,nS2sOfpTLZxdc8HK7IJ6
def ookShtBC417XNw(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,showDialogs,zzX2m748AVDMHOsadwyjbIGukcEF,S3DM0BqRK4fLaIiFGX1PQAY=None,O4OfQzkx1KmeIHrjT97E0byA=None):
	KNyTAdkuI9BagweZ = YchIv6N09BaWPEj4tieAnluKZrRXT if S3DM0BqRK4fLaIiFGX1PQAY else rDceXBpHkfVUYRJ3tIx95Z
	if not KNyTAdkuI9BagweZ:
		S3DM0BqRK4fLaIiFGX1PQAY = ANKVD4WrwZCuUEl.connect(kpLM6WSIQ0X29nAT1gGDEa)
		S3DM0BqRK4fLaIiFGX1PQAY.text_factory = str
		O4OfQzkx1KmeIHrjT97E0byA = S3DM0BqRK4fLaIiFGX1PQAY.cursor()
	succeeded,X7XmwFoyedZN3IhRBM01QtKL = YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z
	try:
		jo0ZNmfgAdCLOn6IisrctKTRkJ9b = I5bUBGpPXn0W6(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥࠩఫ")
		O4OfQzkx1KmeIHrjT97E0byA.execute(egY8Jti0smdLM3h1VQRSW(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡱࡵ࡭࡬࡯࡮ࠡࡈࡕࡓࡒࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࡚ࠢࡌࡊࡘࡅࠡࡣࡧࡨࡴࡴࡉࡅࠢࡀࠤࠧ࠭బ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+NxXMrsTC5FniYuRBOK8(u"ࠩࠥࠤࡀ࠭భ"))
		WLSfkYNla6rzo8K = O4OfQzkx1KmeIHrjT97E0byA.fetchall()
		if WLSfkYNla6rzo8K and jo0ZNmfgAdCLOn6IisrctKTRkJ9b not in str(WLSfkYNla6rzo8K): O4OfQzkx1KmeIHrjT97E0byA.execute(CKUiyEe28zsZ(u"࡙ࠪࡕࡊࡁࡕࡇࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡓࡆࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡁࠥࠨࠧమ")+jo0ZNmfgAdCLOn6IisrctKTRkJ9b+jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪయ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+LyOR7f69iA(u"ࠬࠨࠠ࠼ࠩర"))
		j4VQ7MWaNkw6 = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡢ࡭ࡣࡦ࡯ࡱ࡯ࡳࡵࠩఱ") if lHfbysRrUV7m4CLSdkxc382n else ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡶࡲࡧࡥࡹ࡫࡟ࡳࡷ࡯ࡩࡸ࠭ల")
		O4OfQzkx1KmeIHrjT97E0byA.execute(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡕࡈࡐࡊࡉࡔࠡࠬࠣࡊࡗࡕࡍࠡࠩళ")+j4VQ7MWaNkw6+Cp6c5tZe8I0PxnAW(u"࡛ࠩࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧఴ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+egY8Jti0smdLM3h1VQRSW(u"ࠪࠦࠥࡁࠧవ"))
		WLSfkYNla6rzo8K = O4OfQzkx1KmeIHrjT97E0byA.fetchall()
		if WLSfkYNla6rzo8K:
			if showDialogs: zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧశ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬอไหฯา๎ะࠦวๅล๋ฮํ๋วห์ๆ๎๊ࠥลืษไอࠥࡢ࡮ࠡࠩష")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+LyOR7f69iA(u"࠭ࠠ࡝ࡰ࡟ࡲࠥ࠭స")+SbyWQGMDnV+egY8Jti0smdLM3h1VQRSW(u"ࠧࠡ็อ์็็้ࠠๆสࠤ๏฿ๅๅࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦสโ฻ํ่์ࠦวๅฤ้ࠤฤࠧࠡࠡࠩహ")+Nat0Dx9puRUWCsgz6JyFhY3+KW5bYS20wTF1LyCs9(u"ࠨࠢ࡟ࡲࡡࡴࠠหีอ฻๏฿ࠠฦ์ๅหๆํࠠษี๊์้ฯฺ่ࠠาࠤฬู๊้ัฬࠤส๊้้ࠡำ๋ࠥอไีษือࠥอไๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡสิ๊ฬ๋ฬࠡ฻่หิ࠭఺"))
			else: zf7iFX1auw0bQU = NSudqlOzja
			if zf7iFX1auw0bQU==NSudqlOzja:
				X7XmwFoyedZN3IhRBM01QtKL = YchIv6N09BaWPEj4tieAnluKZrRXT
				O4OfQzkx1KmeIHrjT97E0byA.execute(Cp6c5tZe8I0PxnAW(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠨ఻")+j4VQ7MWaNkw6+ietolwsjpIPK7Fr(u"ࠪࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ఼")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+EX25Y0l8ILvz7QcRC(u"ࠫࠧࠦ࠻ࠨఽ"))
		elif zzX2m748AVDMHOsadwyjbIGukcEF:
			if showDialogs: zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨా"),I5bUBGpPXn0W6(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪి")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+I5bUBGpPXn0W6(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧీ")+SbyWQGMDnV+egY8Jti0smdLM3h1VQRSW(u"ࠨ่ࠢๅ฾๊้ࠠ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโ้ࠣห้ศๆࠡมࠤࠥࠥ࠭ు")+Nat0Dx9puRUWCsgz6JyFhY3+CKUiyEe28zsZ(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหࠣาิ๋วหࠢหี๋อๅอࠢ฼้ฬีࠧూ"))
			else: zf7iFX1auw0bQU = NSudqlOzja
			if zf7iFX1auw0bQU==NSudqlOzja:
				X7XmwFoyedZN3IhRBM01QtKL = YchIv6N09BaWPEj4tieAnluKZrRXT
				if lHfbysRrUV7m4CLSdkxc382n: O4OfQzkx1KmeIHrjT97E0byA.execute(I5bUBGpPXn0W6(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩృ")+j4VQ7MWaNkw6+KW5bYS20wTF1LyCs9(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫౄ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+wY1p9mP03S8drbcH64t5WQkv(u"ࠬࠨࠩࠡ࠽ࠪ౅"))
				else: O4OfQzkx1KmeIHrjT97E0byA.execute(XugxFprC26zGM(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬె")+j4VQ7MWaNkw6+w2vjZmdJuY7c(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫే")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨై"))
	except: succeeded = rDceXBpHkfVUYRJ3tIx95Z
	if showDialogs and X7XmwFoyedZN3IhRBM01QtKL:
		if succeeded: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ౉"),egY8Jti0smdLM3h1VQRSW(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫొ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
		else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧో"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢศู้ออࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡ࡞ࡱࡠࡳ࠭ౌ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
	if not KNyTAdkuI9BagweZ:
		S3DM0BqRK4fLaIiFGX1PQAY.commit()
		S3DM0BqRK4fLaIiFGX1PQAY.close()
		if X7XmwFoyedZN3IhRBM01QtKL:
			b8bLFaejUB.sleep(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠴೤"))
			ccwRLKk3hs0E.executebuiltin(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵ్ࠪ"))
			b8bLFaejUB.sleep(KW5bYS20wTF1LyCs9(u"࠵೥"))
	return X7XmwFoyedZN3IhRBM01QtKL
def kF1GfABotWd(GFXuYIaiM4DNTjOVRg0oSsLn7p,showDialogs,MSeJdhcn8xtwC,zzX2m748AVDMHOsadwyjbIGukcEF):
	S3DM0BqRK4fLaIiFGX1PQAY = ANKVD4WrwZCuUEl.connect(kpLM6WSIQ0X29nAT1gGDEa)
	S3DM0BqRK4fLaIiFGX1PQAY.text_factory = str
	O4OfQzkx1KmeIHrjT97E0byA = S3DM0BqRK4fLaIiFGX1PQAY.cursor()
	H8hMP0qweGaor3OJjWBVzT = w1HecvLmKCBrR95ASN(GFXuYIaiM4DNTjOVRg0oSsLn7p)
	TTcI5CeJBK7bmPy = rDceXBpHkfVUYRJ3tIx95Z
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E in GFXuYIaiM4DNTjOVRg0oSsLn7p:
		succeeded,om1vMzaYHt,nS2sOfpTLZxdc8HK7IJ6 = JYLugbHop1x6V7mqhNGXd3Bk8icEZ(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,showDialogs,MSeJdhcn8xtwC,H8hMP0qweGaor3OJjWBVzT)
		X7XmwFoyedZN3IhRBM01QtKL = ookShtBC417XNw(L1BnkG7RhvcXZoWfjdDHq3Uzu2E,showDialogs,zzX2m748AVDMHOsadwyjbIGukcEF,S3DM0BqRK4fLaIiFGX1PQAY,O4OfQzkx1KmeIHrjT97E0byA)
		if X7XmwFoyedZN3IhRBM01QtKL: TTcI5CeJBK7bmPy = YchIv6N09BaWPEj4tieAnluKZrRXT
	S3DM0BqRK4fLaIiFGX1PQAY.commit()
	S3DM0BqRK4fLaIiFGX1PQAY.close()
	if TTcI5CeJBK7bmPy:
		b8bLFaejUB.sleep(ilBWK5nXxg1do4jENGC07Zq(u"࠶೦"))
		ccwRLKk3hs0E.executebuiltin(ietolwsjpIPK7Fr(u"ࠧࡖࡲࡧࡥࡹ࡫ࡌࡰࡥࡤࡰࡆࡪࡤࡰࡰࡶࠫ౎"))
		b8bLFaejUB.sleep(Cp6c5tZe8I0PxnAW(u"࠷೧"))
	if showDialogs:
		if len(GFXuYIaiM4DNTjOVRg0oSsLn7p)>LTN6DPEmrwehtZMy(u"࠱೨"): dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ౏"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩอ้ࠥฮๆอษะࠤๆำีࠡฮ่๎฾ࠦวๅวูหๆอสࠨ౐"))
		else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭౑"),CKUiyEe28zsZ(u"ࠫฯ๋ࠠษ่ฯหาࠦแฮืࠣห้หึศใฬࡠࡳࡢ࡮ࠨ౒")+GFXuYIaiM4DNTjOVRg0oSsLn7p[t3coAp06zvHrTl49bUVgx(u"࠱೩")])
	return
def bo8mpKfd5eaERB32vGz(showDialogs):
	zNuVyR3PaFHx97eshMEA0 = [eNEhtuoi9gK8JaTpIXj(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ౓"),KQ3sCe9Pzh(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨ౔"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ౕࠫ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨౖ")]
	a0BweyoAxFQ = [w2vjZmdJuY7c(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲ࡴࡺࡨࡦࡴࡶࠫ౗"),HkiMU0QrdzW3l6gwnT(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡨࠫౘ"),XugxFprC26zGM(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫ࠧౙ"),f90fGrlSEObDsuiA3U(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡨ࡫ࡷ࡬ࡺࡨࠧౚ"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪࡧࠧ౛"),KQ3sCe9Pzh(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡦࡳࡩ࡫ࡢࡦࡴࡪࠫ౜")]
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E in a0BweyoAxFQ: h2G6rHt3zf5Kobx(L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
	kF1GfABotWd(zNuVyR3PaFHx97eshMEA0,showDialogs,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	return
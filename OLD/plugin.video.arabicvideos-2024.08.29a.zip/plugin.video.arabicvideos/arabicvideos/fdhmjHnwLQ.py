# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'GLOBALSEARCH'
r07r9xeEFASJXluImT = '_GLS_'
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(tWi3JH8rRhxcgnYuMVUK,Nn360bq79W2kzUt,bkA4Xjzw7mJa,clAzmREWwXf6Gk):
	if   tWi3JH8rRhxcgnYuMVUK==540: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif tWi3JH8rRhxcgnYuMVUK==541: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zepClw1kfUPmRNq4D3QZr7nLoO0A(bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==542: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = WWRwK7djhH08GJAOBZoIYlmSs(bkA4Xjzw7mJa,Nn360bq79W2kzUt,clAzmREWwXf6Gk)
	elif tWi3JH8rRhxcgnYuMVUK==549: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(bkA4Xjzw7mJa)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder','بحث جديد',eHdDoxhJCEPMZFVa2fg,549)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008]==== كلمات مخزنة ====[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	CshwWQT5bydXEGjnIOYeApJHfZt2R1 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'dict','GLOBALSEARCH_SITES')
	if CshwWQT5bydXEGjnIOYeApJHfZt2R1:
		CshwWQT5bydXEGjnIOYeApJHfZt2R1 = CshwWQT5bydXEGjnIOYeApJHfZt2R1['__SEQUENCED_COLUMNS__']
		for ZrzxY0D21f9ACB65S in reversed(CshwWQT5bydXEGjnIOYeApJHfZt2R1):
			qfpnsHw19BiaSktcXWbGA('folder',ZrzxY0D21f9ACB65S,eHdDoxhJCEPMZFVa2fg,549,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ZrzxY0D21f9ACB65S)
	return
def ZZG8yFCkvXnPTgR6Jc(ZrzxY0D21f9ACB65S):
	if not ZrzxY0D21f9ACB65S:
		ZrzxY0D21f9ACB65S = mJ1lHWKUPcZGezML7X2u9S()
		if not ZrzxY0D21f9ACB65S: return
		ZrzxY0D21f9ACB65S = ZrzxY0D21f9ACB65S.lower()
	BZsDGR7weXK = ZrzxY0D21f9ACB65S.replace(r07r9xeEFASJXluImT,eHdDoxhJCEPMZFVa2fg)
	y1nx6SrCqYfjpUeZN5l0s(BZsDGR7weXK)
	qfpnsHw19BiaSktcXWbGA('link','عمل بحث جماعي - '+BZsDGR7weXK,'search_sites',542,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,BZsDGR7weXK)
	qfpnsHw19BiaSktcXWbGA('folder','عمل بحث منفرد - '+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,541,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,BZsDGR7weXK)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder','نتائج البحث مفصلة - '+BZsDGR7weXK,'opened_sites',542,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,BZsDGR7weXK)
	qfpnsHw19BiaSktcXWbGA('folder','نتائج البحث مقسمة - '+BZsDGR7weXK,'listed_sites',542,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,BZsDGR7weXK)
	return
def y1nx6SrCqYfjpUeZN5l0s(dOuQFjlmK5AbsCZX2GSI7nk4qWp):
	zzhUSoeGjZM01WYPgmvHD4F = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','GLOBALSEARCH_SITES',dOuQFjlmK5AbsCZX2GSI7nk4qWp)
	GeBUNjvXQSnq8aiIY3DPWksmy = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','GLOBALSEARCH_SITES',r07r9xeEFASJXluImT+dOuQFjlmK5AbsCZX2GSI7nk4qWp)
	k5L96NenKBwpSYWv(pyifuNFdxe,'GLOBALSEARCH_SITES',dOuQFjlmK5AbsCZX2GSI7nk4qWp)
	k5L96NenKBwpSYWv(pyifuNFdxe,'GLOBALSEARCH_SITES',r07r9xeEFASJXluImT+dOuQFjlmK5AbsCZX2GSI7nk4qWp)
	nnd2lfrPpFa6hjgCqcYKbs = zzhUSoeGjZM01WYPgmvHD4F+GeBUNjvXQSnq8aiIY3DPWksmy
	if nnd2lfrPpFa6hjgCqcYKbs: dOuQFjlmK5AbsCZX2GSI7nk4qWp = r07r9xeEFASJXluImT+dOuQFjlmK5AbsCZX2GSI7nk4qWp
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'GLOBALSEARCH_SITES',dOuQFjlmK5AbsCZX2GSI7nk4qWp,nnd2lfrPpFa6hjgCqcYKbs,oTdjz7uhFYDxOvgaRnJcP5X)
	return
def QUOtV6uyKNJp8xLhv2CY():
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if zf7iFX1auw0bQU!=1: return
	k5L96NenKBwpSYWv(pyifuNFdxe,'GLOBALSEARCH_SITES')
	k5L96NenKBwpSYWv(pyifuNFdxe,'GLOBALSEARCH_OPENED')
	k5L96NenKBwpSYWv(pyifuNFdxe,'GLOBALSEARCH_CLOSED')
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def WWRwK7djhH08GJAOBZoIYlmSs(VuZLqpUP843axBlnbt,KKnvYO25B0LUNMfxXWAeFurbEcyJp7,uujC2KDqoT3rGHzPpAW1mf=eHdDoxhJCEPMZFVa2fg):
	llEzcZMAFweXBCVW1Skqhs,kk8XYyr1vOIQK2Asgdmuh5RN,RMgZ5tuLwSB2c9DmNVeCh8Gq,xgdP3j7ZvHBDba,qqFLyZ4PIl9EVAhDRo3eNGji7wJbc,Wo2e5iO1CayIR0Fgn4UAlZDS,dWpNKnGlcgOzVHm6CU7texM4u = [],[],[],{},{},{},{}
	if KKnvYO25B0LUNMfxXWAeFurbEcyJp7!='search_sites':
		if KKnvYO25B0LUNMfxXWAeFurbEcyJp7=='listed_sites': RMgZ5tuLwSB2c9DmNVeCh8Gq = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','GLOBALSEARCH_SITES',r07r9xeEFASJXluImT+VuZLqpUP843axBlnbt)
		elif KKnvYO25B0LUNMfxXWAeFurbEcyJp7=='opened_sites': RMgZ5tuLwSB2c9DmNVeCh8Gq = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','GLOBALSEARCH_OPENED',VuZLqpUP843axBlnbt)
		elif KKnvYO25B0LUNMfxXWAeFurbEcyJp7=='closed_sites': RMgZ5tuLwSB2c9DmNVeCh8Gq = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','GLOBALSEARCH_CLOSED',(uujC2KDqoT3rGHzPpAW1mf,VuZLqpUP843axBlnbt))
	if not RMgZ5tuLwSB2c9DmNVeCh8Gq:
		z7zRKcweSZAk = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		bYrLlO9uMs5tm0IGFhK2v = 'هل تريد الآن البحث في جميع المواقع عن \n "[COLOR FFFFFF00] '+VuZLqpUP843axBlnbt+' [/COLOR]" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if KKnvYO25B0LUNMfxXWAeFurbEcyJp7=='search_sites': sh3cDaZzUkKQFEAl74OryuPtGqJ = bYrLlO9uMs5tm0IGFhK2v
		else: sh3cDaZzUkKQFEAl74OryuPtGqJ = z7zRKcweSZAk+bYrLlO9uMs5tm0IGFhK2v
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		if zf7iFX1auw0bQU!=1: return
		Rpfbit9Qjk4zYoMu0q(False,False,False)
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Search For: [ '+VuZLqpUP843axBlnbt+' ]')
		uWDwFgA42Y3IoHJhjLti7NMqpvC = 1
		for uujC2KDqoT3rGHzPpAW1mf in naG7EqUw8YHRZpyL5vitx0QSB:
			xgdP3j7ZvHBDba[uujC2KDqoT3rGHzPpAW1mf] = []
			j2TA4h0FekYb3a5B = '_NODIALOGS_'
			if '-' in uujC2KDqoT3rGHzPpAW1mf: j2TA4h0FekYb3a5B = j2TA4h0FekYb3a5B+'_REMEMBERRESULTS__'+uujC2KDqoT3rGHzPpAW1mf+'_'
			aw3VMqrfJ4,rKXOTbZdRQ,UadpNT27E9xXy0KHqGrSw5nPgJjQk = VqR1T8ZyLenuDtvEXz2Psip(uujC2KDqoT3rGHzPpAW1mf)
			if uWDwFgA42Y3IoHJhjLti7NMqpvC:
				b8bLFaejUB.sleep(0.75)
				dWpNKnGlcgOzVHm6CU7texM4u[uujC2KDqoT3rGHzPpAW1mf] = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=rKXOTbZdRQ,args=(VuZLqpUP843axBlnbt+j2TA4h0FekYb3a5B,))
				dWpNKnGlcgOzVHm6CU7texM4u[uujC2KDqoT3rGHzPpAW1mf].start()
			else: rKXOTbZdRQ(VuZLqpUP843axBlnbt+j2TA4h0FekYb3a5B)
			dqKGMYgJxSF8Ub1kotlsP936Ww7B(v9vBX6ZiQ0UHxfze8EjG4nmRW(uujC2KDqoT3rGHzPpAW1mf),eHdDoxhJCEPMZFVa2fg,b8bLFaejUB=1000)
		if uWDwFgA42Y3IoHJhjLti7NMqpvC:
			b8bLFaejUB.sleep(2)
			for uujC2KDqoT3rGHzPpAW1mf in naG7EqUw8YHRZpyL5vitx0QSB:
				dWpNKnGlcgOzVHm6CU7texM4u[uujC2KDqoT3rGHzPpAW1mf].join(10)
			b8bLFaejUB.sleep(2)
		for uujC2KDqoT3rGHzPpAW1mf in naG7EqUw8YHRZpyL5vitx0QSB:
			aw3VMqrfJ4,rKXOTbZdRQ,UadpNT27E9xXy0KHqGrSw5nPgJjQk = VqR1T8ZyLenuDtvEXz2Psip(uujC2KDqoT3rGHzPpAW1mf)
			for XGx97cJZhV5m6v in JXSlk8x495HmgiD:
				IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA = XGx97cJZhV5m6v
				if UadpNT27E9xXy0KHqGrSw5nPgJjQk in Pe9ETSvwUGBnkC1hO:
					if 'IPTV-' in uujC2KDqoT3rGHzPpAW1mf and (239>=tWi3JH8rRhxcgnYuMVUK>=230 or 289>=tWi3JH8rRhxcgnYuMVUK>=280):
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['IPTV-LIVE']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['IPTV-MOVIES']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['IPTV-SERIES']: continue
						if 'صفحة' not in Pe9ETSvwUGBnkC1hO:
							if   IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='live': uujC2KDqoT3rGHzPpAW1mf = 'IPTV-LIVE'
							elif IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='video': uujC2KDqoT3rGHzPpAW1mf = 'IPTV-MOVIES'
							elif IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder': uujC2KDqoT3rGHzPpAW1mf = 'IPTV-SERIES'
						else:
							if   'LIVE' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'IPTV-LIVE'
							elif 'MOVIES' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'IPTV-MOVIES'
							elif 'SERIES' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'IPTV-SERIES'
					elif 'M3U-' in uujC2KDqoT3rGHzPpAW1mf and 729>=tWi3JH8rRhxcgnYuMVUK>=710:
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['M3U-LIVE']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['M3U-MOVIES']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['M3U-SERIES']: continue
						if 'صفحة' not in Pe9ETSvwUGBnkC1hO:
							if   IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='live': uujC2KDqoT3rGHzPpAW1mf = 'M3U-LIVE'
							elif IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='video': uujC2KDqoT3rGHzPpAW1mf = 'M3U-MOVIES'
							elif IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder': uujC2KDqoT3rGHzPpAW1mf = 'M3U-SERIES'
						else:
							if   'LIVE' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'M3U-LIVE'
							elif 'MOVIES' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'M3U-MOVIES'
							elif 'SERIES' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'M3U-SERIES'
					elif 'YOUTUBE-' in uujC2KDqoT3rGHzPpAW1mf and 149>=tWi3JH8rRhxcgnYuMVUK>=140:
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['YOUTUBE-CHANNELS']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['YOUTUBE-PLAYLISTS']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in Pe9ETSvwUGBnkC1hO or ':: ' in Pe9ETSvwUGBnkC1hO:
							continue
						else:
							if   tWi3JH8rRhxcgnYuMVUK==144 and 'USER' in Pe9ETSvwUGBnkC1hO: uujC2KDqoT3rGHzPpAW1mf = 'YOUTUBE-CHANNELS'
							elif tWi3JH8rRhxcgnYuMVUK==144 and 'CHNL' in Pe9ETSvwUGBnkC1hO: uujC2KDqoT3rGHzPpAW1mf = 'YOUTUBE-CHANNELS'
							elif tWi3JH8rRhxcgnYuMVUK==144 and 'LIST' in Pe9ETSvwUGBnkC1hO: uujC2KDqoT3rGHzPpAW1mf = 'YOUTUBE-PLAYLISTS'
							elif tWi3JH8rRhxcgnYuMVUK==143: uujC2KDqoT3rGHzPpAW1mf = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in uujC2KDqoT3rGHzPpAW1mf and 419>=tWi3JH8rRhxcgnYuMVUK>=400:
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['DAILYMOTION-PLAYLISTS']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['DAILYMOTION-CHANNELS']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['DAILYMOTION-VIDEOS']: continue
						if   tWi3JH8rRhxcgnYuMVUK in [401,405]: uujC2KDqoT3rGHzPpAW1mf = 'DAILYMOTION-PLAYLISTS'
						elif tWi3JH8rRhxcgnYuMVUK in [402,406]: uujC2KDqoT3rGHzPpAW1mf = 'DAILYMOTION-CHANNELS'
						elif tWi3JH8rRhxcgnYuMVUK in [404]: uujC2KDqoT3rGHzPpAW1mf = 'DAILYMOTION-VIDEOS'
						elif tWi3JH8rRhxcgnYuMVUK in [415]: uujC2KDqoT3rGHzPpAW1mf = 'DAILYMOTION-LIVES'
					elif 'PANET-' in uujC2KDqoT3rGHzPpAW1mf and 39>=tWi3JH8rRhxcgnYuMVUK>=30:
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['PANET-SERIES']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['PANET-MOVIES']: continue
						if   tWi3JH8rRhxcgnYuMVUK in [32,39]: uujC2KDqoT3rGHzPpAW1mf = 'PANET-SERIES'
						elif tWi3JH8rRhxcgnYuMVUK in [33,39]: uujC2KDqoT3rGHzPpAW1mf = 'PANET-MOVIES'
					elif 'IFILM-' in uujC2KDqoT3rGHzPpAW1mf and 29>=tWi3JH8rRhxcgnYuMVUK>=20:
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['IFILM-ARABIC']: continue
						if XGx97cJZhV5m6v in xgdP3j7ZvHBDba['IFILM-ENGLISH']: continue
						if   '/ar.' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'IFILM-ARABIC'
						elif '/en.' in Nn360bq79W2kzUt: uujC2KDqoT3rGHzPpAW1mf = 'IFILM-ENGLISH'
					xgdP3j7ZvHBDba[uujC2KDqoT3rGHzPpAW1mf].append(XGx97cJZhV5m6v)
		JXSlk8x495HmgiD[:] = []
		for uujC2KDqoT3rGHzPpAW1mf in list(xgdP3j7ZvHBDba.keys()):
			qqFLyZ4PIl9EVAhDRo3eNGji7wJbc[uujC2KDqoT3rGHzPpAW1mf] = []
			Wo2e5iO1CayIR0Fgn4UAlZDS[uujC2KDqoT3rGHzPpAW1mf] = []
			for IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in xgdP3j7ZvHBDba[uujC2KDqoT3rGHzPpAW1mf]:
				XGx97cJZhV5m6v = (IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA)
				if 'صفحة' in Pe9ETSvwUGBnkC1hO and IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder': Wo2e5iO1CayIR0Fgn4UAlZDS[uujC2KDqoT3rGHzPpAW1mf].append(XGx97cJZhV5m6v)
				else: qqFLyZ4PIl9EVAhDRo3eNGji7wJbc[uujC2KDqoT3rGHzPpAW1mf].append(XGx97cJZhV5m6v)
		k0734q8AGwepK = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
		for uujC2KDqoT3rGHzPpAW1mf in Iwfn8xNC4dR5GSF9brk3Ohg:
			if uujC2KDqoT3rGHzPpAW1mf==uMRh32KD1apXJFsqYUIGOS9ot[0]: k0734q8AGwepK = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
			elif uujC2KDqoT3rGHzPpAW1mf==xBi8l0OAwMmsWTkcgD5[0]: k0734q8AGwepK = [('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
			elif uujC2KDqoT3rGHzPpAW1mf==UhOybXi0K5[0]: k0734q8AGwepK = [('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
			if uujC2KDqoT3rGHzPpAW1mf not in qqFLyZ4PIl9EVAhDRo3eNGji7wJbc.keys(): continue
			if qqFLyZ4PIl9EVAhDRo3eNGji7wJbc[uujC2KDqoT3rGHzPpAW1mf]:
				bYmjM5zdBxwCWNSyO3Z = v9vBX6ZiQ0UHxfze8EjG4nmRW(uujC2KDqoT3rGHzPpAW1mf)
				lvTXH6EsnrWQtxi5pUMBwu1jbV = [('link','[COLOR FFFFFF00]===== '+bYmjM5zdBxwCWNSyO3Z+' =====[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
				if 0: UKFhs0tW4IJuwaOncrkCXqD3oVTy = VuZLqpUP843axBlnbt+' - '+'بحث'+avcfIls8w7gk69hYUErHxzQTXtm24j+bYmjM5zdBxwCWNSyO3Z
				else: UKFhs0tW4IJuwaOncrkCXqD3oVTy = 'بحث'+avcfIls8w7gk69hYUErHxzQTXtm24j+bYmjM5zdBxwCWNSyO3Z+' - '+VuZLqpUP843axBlnbt
				if len(qqFLyZ4PIl9EVAhDRo3eNGji7wJbc[uujC2KDqoT3rGHzPpAW1mf])<8: l3qGb5yRm60rAM = []
				else:
					gMr1FsAZRKTD3 = SbyWQGMDnV+UKFhs0tW4IJuwaOncrkCXqD3oVTy+Nat0Dx9puRUWCsgz6JyFhY3
					l3qGb5yRm60rAM = [('folder',r07r9xeEFASJXluImT+gMr1FsAZRKTD3,'closed_sites',542,eHdDoxhJCEPMZFVa2fg,uujC2KDqoT3rGHzPpAW1mf,VuZLqpUP843axBlnbt,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
				jjcdWbvKL67IpeOHkBGAEPYNgrCMDJ = qqFLyZ4PIl9EVAhDRo3eNGji7wJbc[uujC2KDqoT3rGHzPpAW1mf]+Wo2e5iO1CayIR0Fgn4UAlZDS[uujC2KDqoT3rGHzPpAW1mf]
				kk8XYyr1vOIQK2Asgdmuh5RN += k0734q8AGwepK+lvTXH6EsnrWQtxi5pUMBwu1jbV+jjcdWbvKL67IpeOHkBGAEPYNgrCMDJ[:7]+l3qGb5yRm60rAM
				btK1qhYHV5S0 = [('folder',r07r9xeEFASJXluImT+UKFhs0tW4IJuwaOncrkCXqD3oVTy,'closed_sites',542,eHdDoxhJCEPMZFVa2fg,uujC2KDqoT3rGHzPpAW1mf,VuZLqpUP843axBlnbt,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)]
				llEzcZMAFweXBCVW1Skqhs += k0734q8AGwepK+btK1qhYHV5S0
				k0734q8AGwepK = []
				CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'GLOBALSEARCH_CLOSED',(uujC2KDqoT3rGHzPpAW1mf,VuZLqpUP843axBlnbt),jjcdWbvKL67IpeOHkBGAEPYNgrCMDJ,oTdjz7uhFYDxOvgaRnJcP5X)
		CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'GLOBALSEARCH_OPENED',VuZLqpUP843axBlnbt,kk8XYyr1vOIQK2Asgdmuh5RN,oTdjz7uhFYDxOvgaRnJcP5X)
		k5L96NenKBwpSYWv(pyifuNFdxe,'GLOBALSEARCH_SITES',VuZLqpUP843axBlnbt)
		CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'GLOBALSEARCH_SITES',r07r9xeEFASJXluImT+VuZLqpUP843axBlnbt,llEzcZMAFweXBCVW1Skqhs,oTdjz7uhFYDxOvgaRnJcP5X)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		if KKnvYO25B0LUNMfxXWAeFurbEcyJp7=='listed_sites' and llEzcZMAFweXBCVW1Skqhs: RMgZ5tuLwSB2c9DmNVeCh8Gq = llEzcZMAFweXBCVW1Skqhs
		else: RMgZ5tuLwSB2c9DmNVeCh8Gq = kk8XYyr1vOIQK2Asgdmuh5RN
	if KKnvYO25B0LUNMfxXWAeFurbEcyJp7!='search_sites':
		for IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA in RMgZ5tuLwSB2c9DmNVeCh8Gq:
			if KKnvYO25B0LUNMfxXWAeFurbEcyJp7 in ['listed_sites','opened_sites'] and 'صفحة' in Pe9ETSvwUGBnkC1hO and IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder': continue
			qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,bkA4Xjzw7mJa,YvJZXDaqbN,ruWSoIZkeKA)
	Rpfbit9Qjk4zYoMu0q(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)
	return
def zepClw1kfUPmRNq4D3QZr7nLoO0A(VuZLqpUP843axBlnbt=eHdDoxhJCEPMZFVa2fg):
	ZrzxY0D21f9ACB65S,j2TA4h0FekYb3a5B,showDialogs = F1T64yBoQa5b(VuZLqpUP843axBlnbt)
	if not ZrzxY0D21f9ACB65S:
		ZrzxY0D21f9ACB65S = mJ1lHWKUPcZGezML7X2u9S()
		if not ZrzxY0D21f9ACB65S: return
		ZrzxY0D21f9ACB65S = ZrzxY0D21f9ACB65S.lower()
	vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   Search For: [ '+ZrzxY0D21f9ACB65S+' ]')
	diojk6J5vzuRNDKmw = ZrzxY0D21f9ACB65S+j2TA4h0FekYb3a5B
	if 0: zTA9KUqbcojvMYdw,BZsDGR7weXK = ZrzxY0D21f9ACB65S+' - ',eHdDoxhJCEPMZFVa2fg
	else: zTA9KUqbcojvMYdw,BZsDGR7weXK = eHdDoxhJCEPMZFVa2fg,' - '+ZrzxY0D21f9ACB65S
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157)
	qfpnsHw19BiaSktcXWbGA('folder','_M3U_'+zTA9KUqbcojvMYdw+'بحث M3U'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,719,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_IPT_'+zTA9KUqbcojvMYdw+'بحث IPTV'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,239,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_BKR_'+zTA9KUqbcojvMYdw+'بحث موقع بكرا'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,379,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_ART_'+zTA9KUqbcojvMYdw+'بحث موقع تونز عربية'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,739,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_KRB_'+zTA9KUqbcojvMYdw+'بحث موقع قناة كربلاء'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,329,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FH1_'+zTA9KUqbcojvMYdw+'بحث موقع فاصل الأول'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,579,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FH2_'+zTA9KUqbcojvMYdw+'بحث موقع فاصل الثاني'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,599,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_KTV_'+zTA9KUqbcojvMYdw+'بحث موقع كتكوت تيفي'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,819,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_EB1_'+zTA9KUqbcojvMYdw+'بحث موقع ايجي بيست 1'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,779,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_EB2_'+zTA9KUqbcojvMYdw+'بحث موقع ايجي بيست 2'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,789,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_IFL_'+zTA9KUqbcojvMYdw+'  بحث موقع قناة آي فيلم'+BZsDGR7weXK+KwJyZLDzC4FbHhXgTfI,eHdDoxhJCEPMZFVa2fg,29,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_AKO_'+zTA9KUqbcojvMYdw+'بحث موقع أكوام القديم'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,79,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_AKW_'+zTA9KUqbcojvMYdw+'بحث موقع أكوام الجديد'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,249,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_MRF_'+zTA9KUqbcojvMYdw+'بحث موقع قناة المعارف'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,49,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_SHM_'+zTA9KUqbcojvMYdw+'بحث موقع شوف ماكس'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,59,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008]مواقع سيرفرات خاصة وعامة - كثيرة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157)
	qfpnsHw19BiaSktcXWbGA('folder','_LRZ_'+zTA9KUqbcojvMYdw+'بحث موقع لاروزا'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,709,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FJS_'+zTA9KUqbcojvMYdw+' بحث موقع فجر شو'+BZsDGR7weXK+avcfIls8w7gk69hYUErHxzQTXtm24j,eHdDoxhJCEPMZFVa2fg,399,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_TVF_'+zTA9KUqbcojvMYdw+'بحث موقع تيفي فان'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,469,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_LDN_'+zTA9KUqbcojvMYdw+'بحث موقع لودي نت'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,459,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_CMN_'+zTA9KUqbcojvMYdw+'بحث موقع سيما ناو'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,309,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_WCM_'+zTA9KUqbcojvMYdw+'بحث موقع وي سيما'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,569,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_SHN_'+zTA9KUqbcojvMYdw+'بحث موقع شاهد نيوز'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,589,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw+'_NODIALOGS_')
	qfpnsHw19BiaSktcXWbGA('folder','_ARS_'+zTA9KUqbcojvMYdw+'بحث موقع عرب سييد'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,259,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_CCB_'+zTA9KUqbcojvMYdw+'بحث موقع سيما كلوب'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,829,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_SH4_'+zTA9KUqbcojvMYdw+'بحث موقع شاهد فوريو'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,119,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw+'_NODIALOGS_')
	qfpnsHw19BiaSktcXWbGA('folder','_SHT_'+zTA9KUqbcojvMYdw+'بحث موقع شوفها تيفي'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,649,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008]مواقع سيرفرات عامة - كثيرة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157)
	qfpnsHw19BiaSktcXWbGA('folder','_TKT_'+zTA9KUqbcojvMYdw+'بحث موقع تكات'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,949,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FST_'+zTA9KUqbcojvMYdw+'بحث موقع فوستا'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,609,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FBK_'+zTA9KUqbcojvMYdw+'بحث موقع فبركة'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,629,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_YQT_'+zTA9KUqbcojvMYdw+'بحث موقع ياقوت'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,669,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_SHB_'+zTA9KUqbcojvMYdw+'بحث موقع شبكتي'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,969,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_VRB_'+zTA9KUqbcojvMYdw+'بحث موقع فاربون'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,879,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_BRS_'+zTA9KUqbcojvMYdw+'بحث موقع برستيج'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,659,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_KRM_'+zTA9KUqbcojvMYdw+'بحث موقع كرمالك'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,929,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_ANZ_'+zTA9KUqbcojvMYdw+'بحث موقع انمي زد'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,979,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FSK_'+zTA9KUqbcojvMYdw+'بحث موقع فاريسكو'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,999,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_HLC_'+zTA9KUqbcojvMYdw+'بحث موقع هلا سيما'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,89,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_MST_'+zTA9KUqbcojvMYdw+'بحث موقع المصطبة'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,869,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_SNT_'+zTA9KUqbcojvMYdw+'بحث موقع شوف نت'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,849,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_DR7_'+zTA9KUqbcojvMYdw+'بحث موقع دراما صح'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,689,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_CFR_'+zTA9KUqbcojvMYdw+'بحث موقع سيما فري'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,839,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_CMF_'+zTA9KUqbcojvMYdw+'بحث موقع سيما فانز'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,99,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_CML_'+zTA9KUqbcojvMYdw+'بحث موقع سيما لايت'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,479,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_C4H_'+zTA9KUqbcojvMYdw+'بحث موقع سيما 400'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,699,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_ABD_'+zTA9KUqbcojvMYdw+'بحث موقع سيما عبدو'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,559,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_AKT_'+zTA9KUqbcojvMYdw+'بحث موقع اكوام تيوب'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,859,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_DCF_'+zTA9KUqbcojvMYdw+'بحث موقع دراما كافيه'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,939,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FTV_'+zTA9KUqbcojvMYdw+'بحث موقع فوشار تيفي'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,919,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_CWB_'+zTA9KUqbcojvMYdw+'بحث موقع سيما وبس'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,989,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_AHK_'+zTA9KUqbcojvMYdw+'بحث موقع أهواك تيفي'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,619,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_SRT_'+zTA9KUqbcojvMYdw+'بحث موقع سيريس تايم'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,899,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_FVD_'+zTA9KUqbcojvMYdw+'بحث موقع فوشار فيديو'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,909,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_C4P_'+zTA9KUqbcojvMYdw+'بحث موقع سيما فور بي'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,889,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_EB4_'+zTA9KUqbcojvMYdw+'بحث موقع ايجي بيست 4'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,809,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008]مواقع سيرفرات خاصة - قليلة المشاكل[/COLOR]',eHdDoxhJCEPMZFVa2fg,157)
	qfpnsHw19BiaSktcXWbGA('folder','_YUT_'+zTA9KUqbcojvMYdw+'بحث موقع يوتيوب'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,149,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	qfpnsHw19BiaSktcXWbGA('folder','_DLM_'+zTA9KUqbcojvMYdw+'بحث موقع ديلي موشن'+BZsDGR7weXK,eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,diojk6J5vzuRNDKmw)
	return
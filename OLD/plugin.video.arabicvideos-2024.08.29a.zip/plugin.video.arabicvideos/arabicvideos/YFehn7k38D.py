# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'SERIES4WATCH'
headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
r07r9xeEFASJXluImT = '_SFW_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==210: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==211: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	elif mode==212: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==213: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==214: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = O9iz7SkKZG5WgqecaExNvUCod43A8(url)
	elif mode==215: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = n31GIgfZYs(url)
	elif mode==218: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EPrFofs5u9vKkD()
	elif mode==219: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def EPrFofs5u9vKkD():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,219,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	url = q3QVhZaDEuo8t2ASj5vkn+'/getpostsPin?type=one&data=pin&limit=25'
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المميزة',url,211)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('FiltersButtons(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('data-get="(.*?)".*?</i>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		url = q3QVhZaDEuo8t2ASj5vkn+'/getposts?type=one&data='+apOKrFbP9IYHDyUVm7
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,url,211)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('navigation-menu(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(http.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	IVD2kBKhW8FeQLvxUm = ['مسلسلات انمي','الرئيسية']
	for apOKrFbP9IYHDyUVm7,title in items:
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm):
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,211)
	return nR2B1Wye7luXb5
def zRK9ruIt0ZFV4bgi(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: cOUiow273ytu1GC5N0FJh = nR2B1Wye7luXb5
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('MediaGrid"(.*?)class="pagination"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		else: return
	items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	uL2aUQ5PtsyCRG = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		if '/series/' in apOKrFbP9IYHDyUVm7: continue
		apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7).strip('/')
		title = zJRbA1YW2Eor(title)
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if '/film/' in apOKrFbP9IYHDyUVm7 or any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in uL2aUQ5PtsyCRG):
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,212,PeLqCN5Ek8bB)
		elif '/episode/' in apOKrFbP9IYHDyUVm7 and 'الحلقة' in title:
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
			if vQ2LDF3UyXZbhu97Y:
				title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
				if title not in adU3exogvimBLnCQOwz:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,213,PeLqCN5Ek8bB)
					adU3exogvimBLnCQOwz.append(title)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,213,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="pagination(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = zJRbA1YW2Eor(apOKrFbP9IYHDyUVm7)
			title = zJRbA1YW2Eor(title)
			title = title.replace('الصفحة ',eHdDoxhJCEPMZFVa2fg)
			if title!=eHdDoxhJCEPMZFVa2fg: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,211)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	g86dz4vMSCfIucKXR,items,WBqvysRxwNEk = -1,[],[]
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-EPISODES-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('ti-list-numbered(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		ekNMoIJzswUSDVQf564 = eHdDoxhJCEPMZFVa2fg.join(RRztfCIs16MGxEHLJ25vDNAa7hpWT)
		items = cBawilJXvK1m.findall('href="(.*?)"',ekNMoIJzswUSDVQf564,cBawilJXvK1m.DOTALL)
	items.append(url)
	items = set(items)
	for apOKrFbP9IYHDyUVm7 in items:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.strip('/')
		title = '_MOD_' + apOKrFbP9IYHDyUVm7.split('/')[-1].replace('-',avcfIls8w7gk69hYUErHxzQTXtm24j)
		VVhKsWQ0jvAS = cBawilJXvK1m.findall('الحلقة-(\d+)',apOKrFbP9IYHDyUVm7.split('/')[-1],cBawilJXvK1m.DOTALL)
		if VVhKsWQ0jvAS: VVhKsWQ0jvAS = VVhKsWQ0jvAS[0]
		else: VVhKsWQ0jvAS = '0'
		WBqvysRxwNEk.append([apOKrFbP9IYHDyUVm7,title,VVhKsWQ0jvAS])
	items = sorted(WBqvysRxwNEk, reverse=False, key=lambda key: int(key[2]))
	yKXbNJwtEiR8cD3xsIFhd = str(items).count('/season/')
	g86dz4vMSCfIucKXR = str(items).count('/episode/')
	if yKXbNJwtEiR8cD3xsIFhd>1 and g86dz4vMSCfIucKXR>0 and '/season/' not in url:
		for apOKrFbP9IYHDyUVm7,title,VVhKsWQ0jvAS in items:
			if '/season/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,213)
	else:
		for apOKrFbP9IYHDyUVm7,title,VVhKsWQ0jvAS in items:
			if '/season/' not in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,212)
	return
def bbmQeYGSTIv(url):
	ppQOjlq2gaPkW = []
	dezG4T3itVrAKvX9 = url.split('/')
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in nR2B1Wye7luXb5:
		E1Viom5L3684CTOFJ = url.replace(dezG4T3itVrAKvX9[3],'watch')
		L3f4VRFXh0Sb1xwKPzoi = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-PLAY-2nd')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="servers-list(.*?)</div>',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if items:
				id = cBawilJXvK1m.findall('post_id=(.*?)"',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
				if id:
					bAQX4RoUJYDEVqKMgLW56F7Zh9z = id[0]
					for apOKrFbP9IYHDyUVm7,title in items:
						apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/?postid='+bAQX4RoUJYDEVqKMgLW56F7Zh9z+'&serverid='+apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
						ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
			else:
				items = cBawilJXvK1m.findall('data-embedd=".*?(http.*?)("|&quot;)',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				for apOKrFbP9IYHDyUVm7,ppxnlrkDsXUmKQWFt in items:
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if '/download/' in nR2B1Wye7luXb5:
		E1Viom5L3684CTOFJ = url.replace(dezG4T3itVrAKvX9[3],'download')
		L3f4VRFXh0Sb1xwKPzoi = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-PLAY-3rd')
		id = cBawilJXvK1m.findall('postId:"(.*?)"',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if id:
			bAQX4RoUJYDEVqKMgLW56F7Zh9z = id[0]
			W9PzsMeLJTc83mS45G17n = { 'User-Agent':eHdDoxhJCEPMZFVa2fg , 'X-Requested-With':'XMLHttpRequest' }
			E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn + '/ajaxCenter?_action=getdownloadlinks&postId='+bAQX4RoUJYDEVqKMgLW56F7Zh9z
			L3f4VRFXh0Sb1xwKPzoi = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,'SERIES4WATCH-PLAY-4th')
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<h3.*?(\d+)(.*?)</div>',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
				for IUfWHuARFLN4bqGO9ntcBaV,cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
					items = cBawilJXvK1m.findall('<td>(.*?)<.*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
					for name,apOKrFbP9IYHDyUVm7 in items:
						ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7+'?named='+name+'__download'+'____'+IUfWHuARFLN4bqGO9ntcBaV)
			else:
				RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<h6(.*?)</table>',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
				if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: RRztfCIs16MGxEHLJ25vDNAa7hpWT = [L3f4VRFXh0Sb1xwKPzoi]
				for cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
					name = eHdDoxhJCEPMZFVa2fg
					items = cBawilJXvK1m.findall('href="(http.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
					for apOKrFbP9IYHDyUVm7 in items:
						GfhcsvCWIon = '&&' + apOKrFbP9IYHDyUVm7.split('/')[2].lower() + '&&'
						GfhcsvCWIon = GfhcsvCWIon.replace('.com&&',eHdDoxhJCEPMZFVa2fg).replace('.co&&',eHdDoxhJCEPMZFVa2fg)
						GfhcsvCWIon = GfhcsvCWIon.replace('.net&&',eHdDoxhJCEPMZFVa2fg).replace('.org&&',eHdDoxhJCEPMZFVa2fg)
						GfhcsvCWIon = GfhcsvCWIon.replace('.live&&',eHdDoxhJCEPMZFVa2fg).replace('.online&&',eHdDoxhJCEPMZFVa2fg)
						GfhcsvCWIon = GfhcsvCWIon.replace('&&hd.',eHdDoxhJCEPMZFVa2fg).replace('&&www.',eHdDoxhJCEPMZFVa2fg)
						GfhcsvCWIon = GfhcsvCWIon.replace('&&',eHdDoxhJCEPMZFVa2fg)
						apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7 + '?named=' + name + GfhcsvCWIon + '__download'
						ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn + '/search?s='+search
	zRK9ruIt0ZFV4bgi(url)
	return
# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from dIxmaLQn3F import *
EERWJf1adv67 = XugxFprC26zGM(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
r07r9xeEFASJXluImT = Cp6c5tZe8I0PxnAW(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
tPw6V3BsLYyZ9 = RRydns1CErYlIhwSx7.path.join(IIzGues0tMAEHi1jYoTvdFCZK,w2vjZmdJuY7c(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
zYixoWkc1VeJu7GbI6h3 = RRydns1CErYlIhwSx7.path.join(IIzGues0tMAEHi1jYoTvdFCZK,Cp6c5tZe8I0PxnAW(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
Wcezi2Z16v3no8JtDAlKa = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),EX25Y0l8ILvz7QcRC(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
ATtBfM6vQrhp = wQMEslno6XmBUVDCLg90Z43aOHhRSr
CTditnUH6OKyR2Qc41ZNjIXWM = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
sOqDXEIm7gnpTMZul4tY = ilBWK5nXxg1do4jENGC07Zq(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
A7OuSQ6Pv9q0ryfTHIKLEZnlxD = jUcmHhgVvW0EdYOIfXeaDF(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
PfVpMK9ImijqosdLwnbO6YhT2HBx = NxXMrsTC5FniYuRBOK8(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
YYDc0LRjz1fyKuBtM2HOkNZGE9mVaP = NxXMrsTC5FniYuRBOK8(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
ttGr9TUI40uxXn6iwm = LyOR7f69iA(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(tWi3JH8rRhxcgnYuMVUK):
	if   tWi3JH8rRhxcgnYuMVUK==ietolwsjpIPK7Fr(u"࠻࠹࠶ࡾ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = KzCfg7I6VAc1tUn8X()
	elif tWi3JH8rRhxcgnYuMVUK==LTN6DPEmrwehtZMy(u"࠼࠺࠱ࡿ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(tPw6V3BsLYyZ9,YchIv6N09BaWPEj4tieAnluKZrRXT,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==NxXMrsTC5FniYuRBOK8(u"࠽࠴࠳ࢀ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(zYixoWkc1VeJu7GbI6h3,YchIv6N09BaWPEj4tieAnluKZrRXT,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==J7divaGOCgq2SLfXpDzZYN58wc(u"࠷࠵࠵ࢁ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(Wcezi2Z16v3no8JtDAlKa,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==egY8Jti0smdLM3h1VQRSW(u"࠸࠶࠷ࢂ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tWydrj1TzVl9k7MxF4SgO6u8Cs(ATtBfM6vQrhp,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠹࠷࠹ࢃ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = yaFL8bPgQGne3HtW24ZERUvXMKciB(YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==EX25Y0l8ILvz7QcRC(u"࠺࠹࠵ࢄ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = QQXNOyTKMnZ69Hspk()
	elif tWi3JH8rRhxcgnYuMVUK==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠻࠺࠷ࢅ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(CTditnUH6OKyR2Qc41ZNjIXWM,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==RqLvTrID0yMVeClpYcnZ16i3X(u"࠼࠻࠲ࢆ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(sOqDXEIm7gnpTMZul4tY,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠽࠵࠴ࢇ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(A7OuSQ6Pv9q0ryfTHIKLEZnlxD,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==ehfEsaiJBSvbcULtNPVgykA2(u"࠷࠶࠶࢈"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(PfVpMK9ImijqosdLwnbO6YhT2HBx,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==LyOR7f69iA(u"࠸࠷࠸ࢉ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(YYDc0LRjz1fyKuBtM2HOkNZGE9mVaP,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠹࠸࠺ࢊ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ycgRbjNoPLQSnx(ttGr9TUI40uxXn6iwm,rDceXBpHkfVUYRJ3tIx95Z,YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==I5bUBGpPXn0W6(u"࠺࠹࠼ࢋ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = MYg93lB0o6hyc2K5OWpIejbzT(YchIv6N09BaWPEj4tieAnluKZrRXT)
	elif tWi3JH8rRhxcgnYuMVUK==KQ3sCe9Pzh(u"࠻࠺࠾ࢌ"): JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZXu7rt3lWjPeS46IGUvxgKQaHkzM()
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = rDceXBpHkfVUYRJ3tIx95Z
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def KzCfg7I6VAc1tUn8X():
	wwc2ZHy6GYdfMg13r,zS2kMh0dq5wmy7BAxIcHXpioP = YBXwd82kNWnVpK4ZihMQ(tPw6V3BsLYyZ9)
	DpXgO2urKcNGox9h5yJef,b8E9XywiKlAMCqsUYhDcGVJfg = YBXwd82kNWnVpK4ZihMQ(zYixoWkc1VeJu7GbI6h3)
	ddgVrqWChNj8,QGhtNm0u5Ro4wbaElHCBI = YBXwd82kNWnVpK4ZihMQ(Wcezi2Z16v3no8JtDAlKa)
	zMWHnt6x3CkV9o,hyN2HPVIXLSbZ = tSCWKXTbwog4L(ATtBfM6vQrhp)
	zMWHnt6x3CkV9o -= KQ3sCe9Pzh(u"࠸࠼࠸࠷࠶ࢍ")
	hyN2HPVIXLSbZ -= t3coAp06zvHrTl49bUVgx(u"࠷ࢎ")
	PPiv9JZlB4ymq1pRzknXW0 = EX25Y0l8ILvz7QcRC(u"ࠩࠣࠬࠬࠌ")+ywqVLdt7hkabsxT3QnHFjJCr91KU(wwc2ZHy6GYdfMg13r)+NxXMrsTC5FniYuRBOK8(u"ࠪࠤ࠲ࠦࠧࠍ")+str(zS2kMh0dq5wmy7BAxIcHXpioP)+I5bUBGpPXn0W6(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	krdDRZKFsomBxzPNvAOyXJu6 = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࠦࠨࠨࠏ")+ywqVLdt7hkabsxT3QnHFjJCr91KU(DpXgO2urKcNGox9h5yJef)+KW5bYS20wTF1LyCs9(u"࠭ࠠ࠮ࠢࠪࠐ")+str(b8E9XywiKlAMCqsUYhDcGVJfg)+LTN6DPEmrwehtZMy(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	v0AURbLhlNT9xYaZ3fK = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࠢࠫࠫࠒ")+ywqVLdt7hkabsxT3QnHFjJCr91KU(ddgVrqWChNj8)+S8i3sBYoHWdTURpAgN(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(QGhtNm0u5Ro4wbaElHCBI)+eNEhtuoi9gK8JaTpIXj(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	W0z8CHBK5pfIu1ZGc4wgQ = KW5bYS20wTF1LyCs9(u"ࠫࠥ࠮ࠧࠕ")+ywqVLdt7hkabsxT3QnHFjJCr91KU(zMWHnt6x3CkV9o)+LyOR7f69iA(u"ࠬ࠯ࠧࠖ")
	XubTe2QUcEMpA7z = wwc2ZHy6GYdfMg13r+DpXgO2urKcNGox9h5yJef+ddgVrqWChNj8+zMWHnt6x3CkV9o
	czAy10w728nRUoaYfdNJPjStpq = zS2kMh0dq5wmy7BAxIcHXpioP+b8E9XywiKlAMCqsUYhDcGVJfg+QGhtNm0u5Ro4wbaElHCBI+hyN2HPVIXLSbZ
	bkA4Xjzw7mJa = ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࠠࠩࠩࠗ")+ywqVLdt7hkabsxT3QnHFjJCr91KU(XubTe2QUcEMpA7z)+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧࠡ࠯ࠣࠫ࠘")+str(czAy10w728nRUoaYfdNJPjStpq)+egY8Jti0smdLM3h1VQRSW(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	qfpnsHw19BiaSktcXWbGA(KW5bYS20wTF1LyCs9(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),r07r9xeEFASJXluImT+XugxFprC26zGM(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠵࠷࢏"))
	qfpnsHw19BiaSktcXWbGA(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),SbyWQGMDnV+ilBWK5nXxg1do4jENGC07Zq(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"࠺࠻࠼࠽࢐"))
	qfpnsHw19BiaSktcXWbGA(eNEhtuoi9gK8JaTpIXj(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),r07r9xeEFASJXluImT+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+PPiv9JZlB4ymq1pRzknXW0,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"࠹࠷࠵࢑"))
	qfpnsHw19BiaSktcXWbGA(eNEhtuoi9gK8JaTpIXj(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),r07r9xeEFASJXluImT+CKUiyEe28zsZ(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+krdDRZKFsomBxzPNvAOyXJu6,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"࠺࠸࠷࢒"))
	qfpnsHw19BiaSktcXWbGA(bP01xn84BiQN(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),r07r9xeEFASJXluImT+RqLvTrID0yMVeClpYcnZ16i3X(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+v0AURbLhlNT9xYaZ3fK,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠻࠹࠹࢓"))
	qfpnsHw19BiaSktcXWbGA(egY8Jti0smdLM3h1VQRSW(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),r07r9xeEFASJXluImT+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+W0z8CHBK5pfIu1ZGc4wgQ,eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"࠼࠺࠴࢔"))
	MoO74hKeqm8fFka.setSetting(egY8Jti0smdLM3h1VQRSW(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),eHdDoxhJCEPMZFVa2fg)
	return
def QQXNOyTKMnZ69Hspk():
	HhgmOi6kM8 = YchIv6N09BaWPEj4tieAnluKZrRXT if w2vjZmdJuY7c(u"ࠨ࠱ࠪࠧ") in jXg4GKQS3sy9ipunzTwkY7N2085dR else rDceXBpHkfVUYRJ3tIx95Z
	if not HhgmOi6kM8:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),XugxFprC26zGM(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	hy985bf3gkpaz2Q076dvAoDjFxi = MoO74hKeqm8fFka.getSetting(w2vjZmdJuY7c(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not hy985bf3gkpaz2Q076dvAoDjFxi: ZXu7rt3lWjPeS46IGUvxgKQaHkzM()
	wwc2ZHy6GYdfMg13r,zS2kMh0dq5wmy7BAxIcHXpioP = YBXwd82kNWnVpK4ZihMQ(CTditnUH6OKyR2Qc41ZNjIXWM)
	DpXgO2urKcNGox9h5yJef,b8E9XywiKlAMCqsUYhDcGVJfg = YBXwd82kNWnVpK4ZihMQ(sOqDXEIm7gnpTMZul4tY)
	ddgVrqWChNj8,QGhtNm0u5Ro4wbaElHCBI = YBXwd82kNWnVpK4ZihMQ(A7OuSQ6Pv9q0ryfTHIKLEZnlxD)
	zMWHnt6x3CkV9o,hyN2HPVIXLSbZ = YBXwd82kNWnVpK4ZihMQ(PfVpMK9ImijqosdLwnbO6YhT2HBx)
	vplgCksrYF,LEjXPvlB0RoaHYZqgCAd6wUs = YBXwd82kNWnVpK4ZihMQ(YYDc0LRjz1fyKuBtM2HOkNZGE9mVaP)
	EIX3kGZSymYPCz4UxrgfteDWu9lQjT,BFR1GWTVNnS5l6HcxZtUp8AsLJMDva = YBXwd82kNWnVpK4ZihMQ(ttGr9TUI40uxXn6iwm)
	PPiv9JZlB4ymq1pRzknXW0 = t3coAp06zvHrTl49bUVgx(u"ࠬࠦࠨࠨࠫ")+ywqVLdt7hkabsxT3QnHFjJCr91KU(wwc2ZHy6GYdfMg13r)+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࠠ࠮ࠢࠪࠬ")+str(zS2kMh0dq5wmy7BAxIcHXpioP)+w2vjZmdJuY7c(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	krdDRZKFsomBxzPNvAOyXJu6 = LyOR7f69iA(u"ࠨࠢࠫࠫ࠮")+ywqVLdt7hkabsxT3QnHFjJCr91KU(DpXgO2urKcNGox9h5yJef)+LTN6DPEmrwehtZMy(u"ࠩࠣ࠱ࠥ࠭࠯")+str(b8E9XywiKlAMCqsUYhDcGVJfg)+w2vjZmdJuY7c(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	v0AURbLhlNT9xYaZ3fK = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࠥ࠮ࠧ࠱")+ywqVLdt7hkabsxT3QnHFjJCr91KU(ddgVrqWChNj8)+HkiMU0QrdzW3l6gwnT(u"ࠬࠦ࠭ࠡࠩ࠲")+str(QGhtNm0u5Ro4wbaElHCBI)+ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	W0z8CHBK5pfIu1ZGc4wgQ = I5bUBGpPXn0W6(u"ࠧࠡࠪࠪ࠴")+ywqVLdt7hkabsxT3QnHFjJCr91KU(zMWHnt6x3CkV9o)+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࠢ࠰ࠤࠬ࠵")+str(hyN2HPVIXLSbZ)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	uuXBtwQU9Dy8Eo5caAeZn = f90fGrlSEObDsuiA3U(u"ࠪࠤ࠭࠭࠷")+ywqVLdt7hkabsxT3QnHFjJCr91KU(vplgCksrYF)+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࠥ࠳ࠠࠨ࠸")+str(LEjXPvlB0RoaHYZqgCAd6wUs)+Cp6c5tZe8I0PxnAW(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	YZJoHkhGwpOqQUMdPWCFzs = Cp6c5tZe8I0PxnAW(u"࠭ࠠࠩࠩ࠺")+ywqVLdt7hkabsxT3QnHFjJCr91KU(EIX3kGZSymYPCz4UxrgfteDWu9lQjT)+S8i3sBYoHWdTURpAgN(u"ࠧࠡ࠯ࠣࠫ࠻")+str(BFR1GWTVNnS5l6HcxZtUp8AsLJMDva)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	XubTe2QUcEMpA7z = wwc2ZHy6GYdfMg13r+DpXgO2urKcNGox9h5yJef+ddgVrqWChNj8+zMWHnt6x3CkV9o+vplgCksrYF+EIX3kGZSymYPCz4UxrgfteDWu9lQjT
	czAy10w728nRUoaYfdNJPjStpq = zS2kMh0dq5wmy7BAxIcHXpioP+b8E9XywiKlAMCqsUYhDcGVJfg+QGhtNm0u5Ro4wbaElHCBI+hyN2HPVIXLSbZ+LEjXPvlB0RoaHYZqgCAd6wUs+BFR1GWTVNnS5l6HcxZtUp8AsLJMDva
	bkA4Xjzw7mJa = ilBWK5nXxg1do4jENGC07Zq(u"ࠩࠣࠬࠬ࠽")+ywqVLdt7hkabsxT3QnHFjJCr91KU(XubTe2QUcEMpA7z)+KW5bYS20wTF1LyCs9(u"ࠪࠤ࠲ࠦࠧ࠾")+str(czAy10w728nRUoaYfdNJPjStpq)+Cp6c5tZe8I0PxnAW(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	qfpnsHw19BiaSktcXWbGA(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),r07r9xeEFASJXluImT+egY8Jti0smdLM3h1VQRSW(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"࠽࠵࠹࢕"))
	qfpnsHw19BiaSktcXWbGA(egY8Jti0smdLM3h1VQRSW(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),r07r9xeEFASJXluImT+LTN6DPEmrwehtZMy(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷࠶࠹࢖"))
	qfpnsHw19BiaSktcXWbGA(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),SbyWQGMDnV+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"࠺࠻࠼࠽ࢗ"))
	qfpnsHw19BiaSktcXWbGA(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),r07r9xeEFASJXluImT+dEwyQDiz0nhjV6MovaH7tIWYel92(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+PPiv9JZlB4ymq1pRzknXW0,eHdDoxhJCEPMZFVa2fg,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠹࠸࠵࢘"))
	qfpnsHw19BiaSktcXWbGA(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),r07r9xeEFASJXluImT+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+krdDRZKFsomBxzPNvAOyXJu6,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"࠺࠹࠷࢙"))
	qfpnsHw19BiaSktcXWbGA(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),r07r9xeEFASJXluImT+ietolwsjpIPK7Fr(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+v0AURbLhlNT9xYaZ3fK,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"࠻࠺࠹࢚"))
	qfpnsHw19BiaSktcXWbGA(egY8Jti0smdLM3h1VQRSW(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),r07r9xeEFASJXluImT+t3coAp06zvHrTl49bUVgx(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+W0z8CHBK5pfIu1ZGc4wgQ,eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠼࠻࠴࢛"))
	qfpnsHw19BiaSktcXWbGA(EX25Y0l8ILvz7QcRC(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),r07r9xeEFASJXluImT+CKUiyEe28zsZ(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+uuXBtwQU9Dy8Eo5caAeZn,eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"࠽࠵࠶࢜"))
	qfpnsHw19BiaSktcXWbGA(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),r07r9xeEFASJXluImT+Cp6c5tZe8I0PxnAW(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+YZJoHkhGwpOqQUMdPWCFzs,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"࠷࠶࠸࢝"))
	MoO74hKeqm8fFka.setSetting(NxXMrsTC5FniYuRBOK8(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),eHdDoxhJCEPMZFVa2fg)
	return
def ZXu7rt3lWjPeS46IGUvxgKQaHkzM():
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),CKUiyEe28zsZ(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if zf7iFX1auw0bQU==-LyOR7f69iA(u"࠲࢞"): return
	if zf7iFX1auw0bQU:
		import subprocess as iStzq5Y4pIblh7NcFXsf08CHZ
		try:
			iStzq5Y4pIblh7NcFXsf08CHZ.Popen(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡹࡵࠨࡕ"))
			CyE1bazsVXpMHflLOcS3UA6jJ = YchIv6N09BaWPEj4tieAnluKZrRXT
		except: CyE1bazsVXpMHflLOcS3UA6jJ = rDceXBpHkfVUYRJ3tIx95Z
		if CyE1bazsVXpMHflLOcS3UA6jJ:
			sFdGYtiJgrmM73 = CTditnUH6OKyR2Qc41ZNjIXWM+avcfIls8w7gk69hYUErHxzQTXtm24j+sOqDXEIm7gnpTMZul4tY+avcfIls8w7gk69hYUErHxzQTXtm24j+A7OuSQ6Pv9q0ryfTHIKLEZnlxD+avcfIls8w7gk69hYUErHxzQTXtm24j+PfVpMK9ImijqosdLwnbO6YhT2HBx+avcfIls8w7gk69hYUErHxzQTXtm24j+YYDc0LRjz1fyKuBtM2HOkNZGE9mVaP+avcfIls8w7gk69hYUErHxzQTXtm24j+ttGr9TUI40uxXn6iwm
			Ok1qyGpKnBaADzhCU8s = iStzq5Y4pIblh7NcFXsf08CHZ.Popen(XugxFprC26zGM(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+sFdGYtiJgrmM73+eNEhtuoi9gK8JaTpIXj(u"ࠧࠣࠩࡗ"),shell=YchIv6N09BaWPEj4tieAnluKZrRXT,stdin=iStzq5Y4pIblh7NcFXsf08CHZ.PIPE,stdout=iStzq5Y4pIblh7NcFXsf08CHZ.PIPE,stderr=iStzq5Y4pIblh7NcFXsf08CHZ.PIPE)
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
		else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),t3coAp06zvHrTl49bUVgx(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def ywqVLdt7hkabsxT3QnHFjJCr91KU(XubTe2QUcEMpA7z):
	for zJXiTW43hwos8qFOQfa9C0RkeB5MIm in [TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡈࠧ࡜"),EX25Y0l8ILvz7QcRC(u"࠭ࡋࡃࠩ࡝"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡎࡄࠪ࡞"),LTN6DPEmrwehtZMy(u"ࠨࡉࡅࠫ࡟"),KW5bYS20wTF1LyCs9(u"ࠩࡗࡆࠬࡠ")]:
		if XubTe2QUcEMpA7z<ilBWK5nXxg1do4jENGC07Zq(u"࠳࠳࠶࠹࢟"): break
		else: XubTe2QUcEMpA7z /= KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠴࠴࠷࠺࠮࠱ࢠ")
	bkA4Xjzw7mJa = LyOR7f69iA(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(XubTe2QUcEMpA7z,zJXiTW43hwos8qFOQfa9C0RkeB5MIm)
	return bkA4Xjzw7mJa
def YBXwd82kNWnVpK4ZihMQ(HHMPLTordzV7BghjtqEwfx=ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫ࠳࠭ࡢ")):
	global b5sitzw7gunLPTAOZqVo9,MWmxJXv1ekKZQ4hcsl9LF7I6
	b5sitzw7gunLPTAOZqVo9,MWmxJXv1ekKZQ4hcsl9LF7I6 = LTN6DPEmrwehtZMy(u"࠴ࢡ"),LTN6DPEmrwehtZMy(u"࠴ࢡ")
	def sqx3o7By5HpZU(HHMPLTordzV7BghjtqEwfx):
		global b5sitzw7gunLPTAOZqVo9,MWmxJXv1ekKZQ4hcsl9LF7I6
		if RRydns1CErYlIhwSx7.path.exists(HHMPLTordzV7BghjtqEwfx):
			if J7divaGOCgq2SLfXpDzZYN58wc(u"࠵ࢢ") and t3coAp06zvHrTl49bUVgx(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(RRydns1CErYlIhwSx7):
				for Jsun6gkpWSPvYQdt in RRydns1CErYlIhwSx7.scandir(HHMPLTordzV7BghjtqEwfx):
					if Jsun6gkpWSPvYQdt.is_dir(follow_symlinks=rDceXBpHkfVUYRJ3tIx95Z):
						sqx3o7By5HpZU(Jsun6gkpWSPvYQdt.path)
					elif Jsun6gkpWSPvYQdt.is_file(follow_symlinks=rDceXBpHkfVUYRJ3tIx95Z):
						b5sitzw7gunLPTAOZqVo9 += Jsun6gkpWSPvYQdt.stat().st_size
						MWmxJXv1ekKZQ4hcsl9LF7I6 += QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷ࢣ")
			else:
				for Jsun6gkpWSPvYQdt in RRydns1CErYlIhwSx7.listdir(HHMPLTordzV7BghjtqEwfx):
					u5wesnAHzbZU81EXCK = RRydns1CErYlIhwSx7.path.abspath(RRydns1CErYlIhwSx7.path.join(HHMPLTordzV7BghjtqEwfx,Jsun6gkpWSPvYQdt))
					if RRydns1CErYlIhwSx7.path.isdir(u5wesnAHzbZU81EXCK):
						sqx3o7By5HpZU(u5wesnAHzbZU81EXCK)
					elif RRydns1CErYlIhwSx7.path.isfile(u5wesnAHzbZU81EXCK):
						XubTe2QUcEMpA7z,czAy10w728nRUoaYfdNJPjStpq = tSCWKXTbwog4L(u5wesnAHzbZU81EXCK)
						b5sitzw7gunLPTAOZqVo9 += XubTe2QUcEMpA7z
						MWmxJXv1ekKZQ4hcsl9LF7I6 += czAy10w728nRUoaYfdNJPjStpq
		return
	try: sqx3o7By5HpZU(HHMPLTordzV7BghjtqEwfx)
	except: pass
	return b5sitzw7gunLPTAOZqVo9,MWmxJXv1ekKZQ4hcsl9LF7I6
def wn8LDTtVW6UKlf(txIGzjN3Vw,showDialogs):
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),txIGzjN3Vw+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࡝ࡰ࡟ࡲࠬࡥ")+SbyWQGMDnV+f90fGrlSEObDsuiA3U(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢยࠥࠬࡦ")+Nat0Dx9puRUWCsgz6JyFhY3)
		if zf7iFX1auw0bQU!=ilBWK5nXxg1do4jENGC07Zq(u"࠱ࢤ"): return
	vHlM0XVQRyP3hYkoF = rDceXBpHkfVUYRJ3tIx95Z
	if RRydns1CErYlIhwSx7.path.exists(txIGzjN3Vw):
		try: RRydns1CErYlIhwSx7.remove(txIGzjN3Vw)
		except Exception as HUVK1SwONb5DaCEJP:
			if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡧ"),str(HUVK1SwONb5DaCEJP))
			vHlM0XVQRyP3hYkoF = YchIv6N09BaWPEj4tieAnluKZrRXT
	if showDialogs and not vHlM0XVQRyP3hYkoF:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),HkiMU0QrdzW3l6gwnT(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def yaFL8bPgQGne3HtW24ZERUvXMKciB(showDialogs):
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),SbyWQGMDnV+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭็ๅࠢอี๏ีࠠๆีะࠫ࡫")+kDUv7ouWrcgMe6OipQJm+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭࡬")+kDUv7ouWrcgMe6OipQJm+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨมࠤࠥࠬ࡭")+Nat0Dx9puRUWCsgz6JyFhY3)
		if zf7iFX1auw0bQU!=HkiMU0QrdzW3l6gwnT(u"࠲ࢥ"): return
	ycgRbjNoPLQSnx(tPw6V3BsLYyZ9,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(zYixoWkc1VeJu7GbI6h3,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(Wcezi2Z16v3no8JtDAlKa,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	tWydrj1TzVl9k7MxF4SgO6u8Cs(ATtBfM6vQrhp,rDceXBpHkfVUYRJ3tIx95Z)
	if showDialogs:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),f90fGrlSEObDsuiA3U(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def MYg93lB0o6hyc2K5OWpIejbzT(showDialogs):
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),SbyWQGMDnV+ehfEsaiJBSvbcULtNPVgykA2(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠩࡱ")+kDUv7ouWrcgMe6OipQJm+egY8Jti0smdLM3h1VQRSW(u"࠭ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠣ࠲࠳ࠦࡤࡳࡱࡳࡦࡴࡾࠠ࠯࠰ࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠠ࠯࠰ࠣࡰࡴ࡭ࡧࡦࡴࠣ࠲࠳ࠦ࡬ࡰࡩࠣ࠲࠳ࠦࡡ࡯ࡴࠪࡲ")+kDUv7ouWrcgMe6OipQJm+eNEhtuoi9gK8JaTpIXj(u"ࠧࡀࠣࠤࠫࡳ")+Nat0Dx9puRUWCsgz6JyFhY3)
		if zf7iFX1auw0bQU!=EX25Y0l8ILvz7QcRC(u"࠳ࢦ"): return
	ycgRbjNoPLQSnx(CTditnUH6OKyR2Qc41ZNjIXWM,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(sOqDXEIm7gnpTMZul4tY,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(A7OuSQ6Pv9q0ryfTHIKLEZnlxD,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(PfVpMK9ImijqosdLwnbO6YhT2HBx,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(YYDc0LRjz1fyKuBtM2HOkNZGE9mVaP,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	ycgRbjNoPLQSnx(ttGr9TUI40uxXn6iwm,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	if showDialogs:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡴ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࡵ"))
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def tWydrj1TzVl9k7MxF4SgO6u8Cs(zHOEFk27fChwMr0GKXWSy19URm4,showDialogs):
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),SbyWQGMDnV+f90fGrlSEObDsuiA3U(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่ࠢัฯ๎๊ศฬ้้ࠣ็ࠠึ๊ิࠤฬ๊ฬๅัࠣรࠦࠧࠧࡷ")+Nat0Dx9puRUWCsgz6JyFhY3)
		if zf7iFX1auw0bQU!=TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠴ࢧ"): return
	Mh2SmYKyRLsevXCJpTajHZbi0Gf = ANKVD4WrwZCuUEl.connect(zHOEFk27fChwMr0GKXWSy19URm4)
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.text_factory = str
	O4OfQzkx1KmeIHrjT97E0byA = Mh2SmYKyRLsevXCJpTajHZbi0Gf.cursor()
	O4OfQzkx1KmeIHrjT97E0byA.execute(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࡸ"))
	O4OfQzkx1KmeIHrjT97E0byA.execute(LTN6DPEmrwehtZMy(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࡹ"))
	O4OfQzkx1KmeIHrjT97E0byA.execute(XugxFprC26zGM(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࡺ"))
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.commit()
	O4OfQzkx1KmeIHrjT97E0byA.execute(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࡻ"))
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.close()
	if showDialogs:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),w2vjZmdJuY7c(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫࡽ"))
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
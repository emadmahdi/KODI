# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'SHOOFMAX'
r07r9xeEFASJXluImT = '_SHM_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][1]
v2as4pXGlNC0xRiztVLFEoeM = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][2]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==50: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==51: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	elif mode==52: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==53: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==55: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ceXDtwmR7iKd()
	elif mode==56: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = CjsaIRmGkfJlYBU6rS0ebhNEiX8KnO()
	elif mode==57: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VVa2bIQAByFNdqMRiD0ZprsCUnl(url,1)
	elif mode==58: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VVa2bIQAByFNdqMRiD0ZprsCUnl(url,2)
	elif mode==59: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,59,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المسلسلات',eHdDoxhJCEPMZFVa2fg,56)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الافلام',eHdDoxhJCEPMZFVa2fg,55)
	return eHdDoxhJCEPMZFVa2fg
def ceXDtwmR7iKd():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أفلام مرتبة بسنة الإنتاج',q3QVhZaDEuo8t2ASj5vkn+'/movie/1/yop',57)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أفلام مرتبة بالأفضل تقييم',q3QVhZaDEuo8t2ASj5vkn+'/movie/1/review',57)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أفلام مرتبة بالأكثر مشاهدة',q3QVhZaDEuo8t2ASj5vkn+'/movie/1/views',57)
	return
def CjsaIRmGkfJlYBU6rS0ebhNEiX8KnO():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات مرتبة بسنة الإنتاج',q3QVhZaDEuo8t2ASj5vkn+'/series/1/yop',57)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات مرتبة بالأفضل تقييم',q3QVhZaDEuo8t2ASj5vkn+'/series/1/review',57)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسلات مرتبة بالأكثر مشاهدة',q3QVhZaDEuo8t2ASj5vkn+'/series/1/views',57)
	return
def zRK9ruIt0ZFV4bgi(url):
	if '?' in url:
		dezG4T3itVrAKvX9 = url.split('?')
		url = dezG4T3itVrAKvX9[0]
		filter = '?' + vFDQstemyYANa(dezG4T3itVrAKvX9[1],'=&:/%')
	else: filter = eHdDoxhJCEPMZFVa2fg
	type,clAzmREWwXf6Gk,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': kcWMPsL8rTBgnQEoRpmd9yOjXC='فيلم'
		elif type=='series': kcWMPsL8rTBgnQEoRpmd9yOjXC='مسلسل'
		url = q3QVhZaDEuo8t2ASj5vkn + '/genre/filter/' + vFDQstemyYANa(kcWMPsL8rTBgnQEoRpmd9yOjXC) + '/' + clAzmREWwXf6Gk + '/' + sort + filter
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOOFMAX-TITLES-1st')
		items = cBawilJXvK1m.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		peAJFoZLMcPuskI=0
		for id,title,uuJIOLrWPN,PeLqCN5Ek8bB in items:
			peAJFoZLMcPuskI += 1
			PeLqCN5Ek8bB = v2as4pXGlNC0xRiztVLFEoeM + '/v2/img/program/main/' + PeLqCN5Ek8bB + '-2.jpg'
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn + '/program/' + id
			if type=='movie': qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,53,PeLqCN5Ek8bB)
			if type=='series': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسل '+title,apOKrFbP9IYHDyUVm7+'?ep='+uuJIOLrWPN+'='+title+'='+PeLqCN5Ek8bB,52,PeLqCN5Ek8bB)
	else:
		if type=='movie': kcWMPsL8rTBgnQEoRpmd9yOjXC='movies'
		elif type=='series': kcWMPsL8rTBgnQEoRpmd9yOjXC='series'
		url = hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c + '/json/selected/' + sort + '-' + kcWMPsL8rTBgnQEoRpmd9yOjXC + '-WW.json'
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOOFMAX-TITLES-2nd')
		items = cBawilJXvK1m.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		peAJFoZLMcPuskI=0
		for id,uuJIOLrWPN,PeLqCN5Ek8bB,title in items:
			peAJFoZLMcPuskI += 1
			PeLqCN5Ek8bB = hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c + '/img/program/' + PeLqCN5Ek8bB + '-2.jpg'
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn + '/program/' + id
			if type=='movie': qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,53,PeLqCN5Ek8bB)
			elif type=='series': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'مسلسل '+title,apOKrFbP9IYHDyUVm7+'?ep='+uuJIOLrWPN+'='+title+'='+PeLqCN5Ek8bB,52,PeLqCN5Ek8bB)
	title='صفحة '
	if peAJFoZLMcPuskI==16:
		for yMow8gGil5unXPdDQFv in range(1,13) :
			if not clAzmREWwXf6Gk==str(yMow8gGil5unXPdDQFv):
				url = q3QVhZaDEuo8t2ASj5vkn+'/genre/filter/'+type+'/'+str(yMow8gGil5unXPdDQFv)+'/'+sort+filter
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title+str(yMow8gGil5unXPdDQFv),url,51)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	dezG4T3itVrAKvX9 = url.split('=')
	uuJIOLrWPN = int(dezG4T3itVrAKvX9[1])
	name = zrHeZWCqQMOymk1d7anKpu0vEx8(dezG4T3itVrAKvX9[2])
	name = name.replace('_MOD_مسلسل ',eHdDoxhJCEPMZFVa2fg)
	PeLqCN5Ek8bB = dezG4T3itVrAKvX9[3]
	url = url.split('?')[0]
	if uuJIOLrWPN==0:
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOOFMAX-EPISODES-1st')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<select(.*?)</select>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('option value="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		uuJIOLrWPN = int(items[-1])
	for vQ2LDF3UyXZbhu97Y in range(uuJIOLrWPN,0,-1):
		apOKrFbP9IYHDyUVm7 = url + '?ep=' + str(vQ2LDF3UyXZbhu97Y)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(vQ2LDF3UyXZbhu97Y)
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,53,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOOFMAX-PLAY-1st')
	Vy6zBh5f8W4seqNH = cBawilJXvK1m.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if Vy6zBh5f8W4seqNH:
		b8bLFaejUB = Vy6zBh5f8W4seqNH[1].replace('T',h597x8jYiAIBDzcedPslw6pQy)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+kDUv7ouWrcgMe6OipQJm+b8bLFaejUB)
		return
	rWdgs0iNwm82,Fu6PcZ98DpRCYEGzmn1w2HxUB5T = [],[]
	h1HNOIzUPnX = cBawilJXvK1m.findall('var origin_link = "(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	uCfXWBra2ZzxFUQmhiP = cBawilJXvK1m.findall('var backup_origin_link = "(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('hls: (.*?)_link\+"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for GfhcsvCWIon,apOKrFbP9IYHDyUVm7 in JCZVK86QTYwX4mfgOrod:
		if 'backup' in GfhcsvCWIon:
			GfhcsvCWIon = 'backup server'
			url = uCfXWBra2ZzxFUQmhiP + apOKrFbP9IYHDyUVm7
		else:
			GfhcsvCWIon = 'main server'
			url = h1HNOIzUPnX + apOKrFbP9IYHDyUVm7
		if '.m3u8' in url:
			rWdgs0iNwm82.append(url)
			Fu6PcZ98DpRCYEGzmn1w2HxUB5T.append('m3u8  '+GfhcsvCWIon)
	JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	JCZVK86QTYwX4mfgOrod += cBawilJXvK1m.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for GfhcsvCWIon,apOKrFbP9IYHDyUVm7 in JCZVK86QTYwX4mfgOrod:
		filename = apOKrFbP9IYHDyUVm7.split('/')[-1]
		filename = filename.replace('fallback',eHdDoxhJCEPMZFVa2fg)
		filename = filename.replace('.mp4',eHdDoxhJCEPMZFVa2fg)
		filename = filename.replace('-',eHdDoxhJCEPMZFVa2fg)
		if 'backup' in GfhcsvCWIon:
			GfhcsvCWIon = 'backup server'
			url = uCfXWBra2ZzxFUQmhiP + apOKrFbP9IYHDyUVm7
		else:
			GfhcsvCWIon = 'main server'
			url = h1HNOIzUPnX + apOKrFbP9IYHDyUVm7
		rWdgs0iNwm82.append(url)
		Fu6PcZ98DpRCYEGzmn1w2HxUB5T.append('mp4  '+GfhcsvCWIon+KwJyZLDzC4FbHhXgTfI+filename)
	iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('Select Video Quality:', Fu6PcZ98DpRCYEGzmn1w2HxUB5T)
	if iLcCSnPyKYWs3xkQ0p14 == -1 : return
	url = rWdgs0iNwm82[iLcCSnPyKYWs3xkQ0p14]
	IZkpyKSFVarcHwG1g6emqQv70h(url,EERWJf1adv67,'video')
	return
def VVa2bIQAByFNdqMRiD0ZprsCUnl(url,type):
	if 'series' in url: E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn + '/genre/مسلسل'
	else: E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn + '/genre/فيلم'
	E1Viom5L3684CTOFJ = vFDQstemyYANa(E1Viom5L3684CTOFJ)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHOOFMAX-FILTERS-1st')
	if type==1: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('subgenre(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	elif type==2: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('country(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('option value="(.*?)">(.*?)</option',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if type==1:
		for R6i8moZd2OwtJvs47fqHYG1xgSI,title in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url+'?subgenre='+R6i8moZd2OwtJvs47fqHYG1xgSI,58)
	elif type==2:
		url,R6i8moZd2OwtJvs47fqHYG1xgSI = url.split('?')
		for CNqlQiod9T4Z,title in items:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url+'?country='+CNqlQiod9T4Z+'&'+R6i8moZd2OwtJvs47fqHYG1xgSI,51)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search: search = mJ1lHWKUPcZGezML7X2u9S()
	if not search: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search?q='+diojk6J5vzuRNDKmw
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,True,eHdDoxhJCEPMZFVa2fg,'SHOOFMAX-SEARCH-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('general-body(.*?)search-bottom-padding',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if items:
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			url = q3QVhZaDEuo8t2ASj5vkn + apOKrFbP9IYHDyUVm7
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+vFDQstemyYANa(title)+'='+PeLqCN5Ek8bB
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,52,PeLqCN5Ek8bB)
				else:
					title = '_MOD_فيلم '+title
					qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,url,53,PeLqCN5Ek8bB)
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'ARABICTOONS'
r07r9xeEFASJXluImT = '_ART_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==730: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==731: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url)
	elif mode==732: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==733: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==734: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = NxDLljV4rIktoGKgiaSfCMs7(url)
	elif mode==735: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = hDSs4YztEU5HbP8nR7Zw23qgB(url)
	elif mode==739: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,739,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مسلسلات مميزة',q3QVhZaDEuo8t2ASj5vkn+'/top.php',735)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'مسلسلات',q3QVhZaDEuo8t2ASj5vkn+'/cartoon.php',734)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'افلام',q3QVhZaDEuo8t2ASj5vkn+'/movies.php',731)
	return
def NxDLljV4rIktoGKgiaSfCMs7(url):
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الكل',url,731)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABICTOONS-SERIES_SUBMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('label="navigation"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall("href='(.*?)'>(.*?)</a>",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = 'حرف '+title
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,731)
	return
def hDSs4YztEU5HbP8nR7Zw23qgB(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABICTOONS-SERIES_FEATURED-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="slider"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			PeLqCN5Ek8bB = q3QVhZaDEuo8t2ASj5vkn+'/'+PeLqCN5Ek8bB
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,733,PeLqCN5Ek8bB)
	return
def zRK9ruIt0ZFV4bgi(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABICTOONS-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("class='moviesBlocks(.*?)navigation",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
		PeLqCN5Ek8bB = q3QVhZaDEuo8t2ASj5vkn+'/'+PeLqCN5Ek8bB
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'movies.php' in url: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,732,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,733,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[-1]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			title = zJRbA1YW2Eor(title)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,731)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABICTOONS-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall("class='moviesBlocks(.*?)script",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for title,apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,tkO4UJRvnMqS29mIs56GzTDP in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
			PeLqCN5Ek8bB = q3QVhZaDEuo8t2ASj5vkn+'/'+PeLqCN5Ek8bB
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			title = title+avcfIls8w7gk69hYUErHxzQTXtm24j+tkO4UJRvnMqS29mIs56GzTDP.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,732,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	wROf6m4Ix73jtsdnZ1vpCDuV = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABICTOONS-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('source src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if JCZVK86QTYwX4mfgOrod:
		apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[0]
		if 'Referer=' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'|Referer=https://www.arabic-toons.com'
		wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named=__embed')
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
	ppQOjlq2gaPkW = [eHdDoxhJCEPMZFVa2fg,'m']
	zzSnQP3O5HIVpmji10gC4tY = ['مسلسلات','افلام']
	if showDialogs:
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('اختر النوع المطلوب:', zzSnQP3O5HIVpmji10gC4tY)
		if iLcCSnPyKYWs3xkQ0p14==-1: return
	else: iLcCSnPyKYWs3xkQ0p14 = 0
	type = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	url = q3QVhZaDEuo8t2ASj5vkn+'/livesearch.php?'+type+'&q='+search
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABICTOONS-SEARCH-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if type=='m': qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,732)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,733)
	return
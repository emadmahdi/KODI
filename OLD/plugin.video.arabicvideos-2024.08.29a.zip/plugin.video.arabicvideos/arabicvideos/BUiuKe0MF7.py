# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'EGYBEST1'
r07r9xeEFASJXluImT = '_EB1_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['مكتبتي','ايجي بست']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,clAzmREWwXf6Gk,text):
	if   mode==770: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==771: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk)
	elif mode==772: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==773: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==774: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'FULL_FILTER___'+text)
	elif mode==775: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'DEFINED_FILTER___'+text)
	elif mode==776: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = CCi1Vt9vmrcFqODjkT72l3E0KNBIHM(url,clAzmREWwXf6Gk)
	elif mode==779: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text,url)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,779,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST1-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('nav-list(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm): continue
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,771)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-article(.*?)social-box',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('main-title.*?">(.*?)<.*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for title,apOKrFbP9IYHDyUVm7 in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,771,eHdDoxhJCEPMZFVa2fg,'mainmenu')
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-menu(.*?)</div></div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,771)
	return nR2B1Wye7luXb5
def CCi1Vt9vmrcFqODjkT72l3E0KNBIHM(url,type=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST1-SEASONS_EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-article".*?">(.*?)<(.*?)article',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		MMHTKqYVvSrLojUt,Tfo9biLauWAQBSXw3GmeqkV,items = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,[]
		for name,cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			if 'حلقات' in name: Tfo9biLauWAQBSXw3GmeqkV = cOUiow273ytu1GC5N0FJh
			if 'مواسم' in name: MMHTKqYVvSrLojUt = cOUiow273ytu1GC5N0FJh
		if MMHTKqYVvSrLojUt and not type:
			items = cBawilJXvK1m.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',MMHTKqYVvSrLojUt,cBawilJXvK1m.DOTALL)
			if len(items)>1:
				for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,776,PeLqCN5Ek8bB,'season')
		if Tfo9biLauWAQBSXw3GmeqkV and len(items)<2:
			items = cBawilJXvK1m.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',Tfo9biLauWAQBSXw3GmeqkV,cBawilJXvK1m.DOTALL)
			if items:
				for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
					qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,773,PeLqCN5Ek8bB)
			else:
				items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',Tfo9biLauWAQBSXw3GmeqkV,cBawilJXvK1m.DOTALL)
				for apOKrFbP9IYHDyUVm7,title in items:
					qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,773)
	return
def zRK9ruIt0ZFV4bgi(url,type=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST1-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items,sCVKdvo76plYG9hkz,yTtrwivOXY68ECP7ZHQgNdJ1 = [],False,False
	if not type:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-content(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?</i>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,771,eHdDoxhJCEPMZFVa2fg,'submenu')
				sCVKdvo76plYG9hkz = True
	if not type and 'p=' not in url:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('searchform(.*?)</form>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			if sCVKdvo76plYG9hkz: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر محدد',url,775,eHdDoxhJCEPMZFVa2fg,'filter')
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر كامل',url,774,eHdDoxhJCEPMZFVa2fg,'filter')
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث',url,779)
			qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
			yTtrwivOXY68ECP7ZHQgNdJ1 = True
	if not sCVKdvo76plYG9hkz:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('blocks(.*?)article',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
				PeLqCN5Ek8bB = PeLqCN5Ek8bB.strip(kDUv7ouWrcgMe6OipQJm)
				apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
				if '/serie/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,776,PeLqCN5Ek8bB,'season')
				else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,773,PeLqCN5Ek8bB)
			clAzmREWwXf6Gk = '1'
			if 'p=' in url: url,clAzmREWwXf6Gk = url.split('p=',1)
			Mh2SmYKyRLsevXCJpTajHZbi0Gf = '&' if '?' in url else '?'
			url = url+Mh2SmYKyRLsevXCJpTajHZbi0Gf
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(clAzmREWwXf6Gk)+1)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الصفحة التالية',url,771)
			elif clAzmREWwXf6Gk!='1':
				url = url+'p='+str(int(clAzmREWwXf6Gk)-1)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الصفحة السابقة',url,771)
	return
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST1-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	i2qmOCHN5goZ = cBawilJXvK1m.findall('<label>التصنيف</label>.*?">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV,ZVrJl8DdFKBimq46Eyu2QItUex9P = [],[],[]
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('download-section.*?action="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
		if apOKrFbP9IYHDyUVm7 not in ZVrJl8DdFKBimq46Eyu2QItUex9P:
			ZVrJl8DdFKBimq46Eyu2QItUex9P.append(apOKrFbP9IYHDyUVm7)
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named=__embed______'+vFDQstemyYANa(url))
	ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall('WatchServers(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall("url='(.*?)'.*?>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,GfhcsvCWIon in JCZVK86QTYwX4mfgOrod:
			if apOKrFbP9IYHDyUVm7 not in ZVrJl8DdFKBimq46Eyu2QItUex9P:
				ZVrJl8DdFKBimq46Eyu2QItUex9P.append(apOKrFbP9IYHDyUVm7)
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__both______'+vFDQstemyYANa(url))
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search,url=eHdDoxhJCEPMZFVa2fg):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search: search = mJ1lHWKUPcZGezML7X2u9S()
	if not search: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'%20')
	if not url: url = q3QVhZaDEuo8t2ASj5vkn+'/search?query='+diojk6J5vzuRNDKmw
	else: url = url+'?title='+diojk6J5vzuRNDKmw+'&genre=&year=&lang='
	zRK9ruIt0ZFV4bgi(url,'search')
	return
def FADrXnGJYOuZlzU4t(url):
	url = url.split('/smartemadfilter?')[0]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('form-row(.*?)</form>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		IVnCEBUYx5s3oleJkmdr2zWa0Ni = cBawilJXvK1m.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		V12b0HtGrWMkPqABj5nvioJZQ,yZOpoR4Ph53fHFAJbzv,ekNMoIJzswUSDVQf564 = zip(*IVnCEBUYx5s3oleJkmdr2zWa0Ni)
		IVnCEBUYx5s3oleJkmdr2zWa0Ni = zip(yZOpoR4Ph53fHFAJbzv,V12b0HtGrWMkPqABj5nvioJZQ,ekNMoIJzswUSDVQf564)
	return IVnCEBUYx5s3oleJkmdr2zWa0Ni
def SeP2jVnzMQ37(cOUiow273ytu1GC5N0FJh):
	items = cBawilJXvK1m.findall('value="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	return items
def f5BCGNS0nFwMbpsZLtv9VJz(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
o0rBAEigunZKbdl7YhQ4eLxX = ['year','lang','genre']
vmQWHaV17urZ = ['year','lang','genre']
def bbkDE5p9zlX6aV(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==eHdDoxhJCEPMZFVa2fg: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	else: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = filter.split('___')
	if type=='DEFINED_FILTER':
		if vmQWHaV17urZ[0]+'=' not in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = vmQWHaV17urZ[0]
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(vmQWHaV17urZ[0:-1])):
			if vmQWHaV17urZ[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+'=' in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = vmQWHaV17urZ[dhcGSyo8Kn1mHZwvEAkzJ7NUq+1]
		aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+U3d2hkuwDIj56+'=0'
		e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+U3d2hkuwDIj56+'=0'
		r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7.strip('&')+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM.strip('&')
		jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'all')
		E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
	elif type=='FULL_FILTER':
		aSF3HMlugcs9G7Yz = QRKwbZae0G3m(goUS2aiGbZX1OQ,'modified_values')
		aSF3HMlugcs9G7Yz = zrHeZWCqQMOymk1d7anKpu0vEx8(aSF3HMlugcs9G7Yz)
		if JVw3Ug6xQykdj2oM50: JVw3Ug6xQykdj2oM50 = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'all')
		if not JVw3Ug6xQykdj2oM50: E1Viom5L3684CTOFJ = url
		else: E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+JVw3Ug6xQykdj2oM50
		ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أظهار قائمة الفيديو التي تم اختيارها ',ajHR9ABQl2buvm,771,eHdDoxhJCEPMZFVa2fg,'filter')
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' [[   '+aSF3HMlugcs9G7Yz+'   ]]',ajHR9ABQl2buvm,771,eHdDoxhJCEPMZFVa2fg,'filter')
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = FADrXnGJYOuZlzU4t(url)
	dict = {}
	for name,BYy2jD5CQfh3rdxTAFzJ84Vk6E,cOUiow273ytu1GC5N0FJh in IVnCEBUYx5s3oleJkmdr2zWa0Ni:
		name = name.replace('كل ',eHdDoxhJCEPMZFVa2fg)
		items = SeP2jVnzMQ37(cOUiow273ytu1GC5N0FJh)
		if '=' not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = url
		if type=='DEFINED_FILTER':
			if U3d2hkuwDIj56!=BYy2jD5CQfh3rdxTAFzJ84Vk6E: continue
			elif len(items)<2:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==vmQWHaV17urZ[-1]:
					ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
					zRK9ruIt0ZFV4bgi(ajHR9ABQl2buvm)
				else: bbkDE5p9zlX6aV(E1Viom5L3684CTOFJ,'DEFINED_FILTER___'+r3bWKiRBqwE54ayCf0utvhDlx)
				return
			else:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==vmQWHaV17urZ[-1]:
					ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع ',ajHR9ABQl2buvm,771,eHdDoxhJCEPMZFVa2fg,'filter')
				else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع ',E1Viom5L3684CTOFJ,775,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		elif type=='FULL_FILTER':
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع :'+name,E1Viom5L3684CTOFJ,774,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E] = {}
		for q5qDOCzEe0Lv4ZyJbWnaPcpVsB,gW0v8nMxdq2 in items:
			if not q5qDOCzEe0Lv4ZyJbWnaPcpVsB: continue
			if gW0v8nMxdq2 in IVD2kBKhW8FeQLvxUm: continue
			dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E][q5qDOCzEe0Lv4ZyJbWnaPcpVsB] = gW0v8nMxdq2
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+gW0v8nMxdq2
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
			nSjP8erv4yop = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			title = gW0v8nMxdq2+' :'#+dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E]['0']
			title = gW0v8nMxdq2+' :'+name
			if type=='FULL_FILTER': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,774,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
			elif type=='DEFINED_FILTER' and vmQWHaV17urZ[-2]+'=' in goUS2aiGbZX1OQ:
				jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(e2mXDvCIA45Hp81FPKhaiWJGuM,'modified_filters')
				E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
				ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,ajHR9ABQl2buvm,771,eHdDoxhJCEPMZFVa2fg,'filter')
			elif type=='DEFINED_FILTER': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,775,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
	return
def QRKwbZae0G3m(yTtrwivOXY68ECP7ZHQgNdJ1,mode):
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.replace('=&','=0&')
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.strip('&')
	f8TRa4pzuVmo7c9gZ1j6rtPYOXqe = {}
	if '=' in yTtrwivOXY68ECP7ZHQgNdJ1:
		items = yTtrwivOXY68ECP7ZHQgNdJ1.split('&')
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			WW4LlMgICSbVYDfXKQdtzik,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split('=')
			f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[WW4LlMgICSbVYDfXKQdtzik] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = eHdDoxhJCEPMZFVa2fg
	for key in o0rBAEigunZKbdl7YhQ4eLxX:
		if key in list(f8TRa4pzuVmo7c9gZ1j6rtPYOXqe.keys()): q5qDOCzEe0Lv4ZyJbWnaPcpVsB = f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[key]
		else: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = '0'
		if '%' not in q5qDOCzEe0Lv4ZyJbWnaPcpVsB: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = vFDQstemyYANa(q5qDOCzEe0Lv4ZyJbWnaPcpVsB)
		if mode=='modified_values' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+' + '+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='modified_filters' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='all': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip(' + ')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip('&')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.replace('=0','=')
	return Q2OrNnmvR5HfY
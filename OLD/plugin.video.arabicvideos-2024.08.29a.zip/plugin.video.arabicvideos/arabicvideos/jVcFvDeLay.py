# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
FO8SKWr40dDexHgbfRUGBi = 'M3U'
pWmZEI8VqwO3eS5H1BizLCAy = '_M3U_'
ga2Cxd7Bulrb = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
hPjydHiuqQc75KFp = 4
def wt29MA4RWa8NOedvnpocQEfC1Hg(tWi3JH8rRhxcgnYuMVUK,Nn360bq79W2kzUt,bkA4Xjzw7mJa,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,d9c6BWV3J2bQDMRELgX,ICOyNkVjwdXS5TFKH6WgZAn4):
	global pWmZEI8VqwO3eS5H1BizLCAy
	try:
		C47G3hXaRMFLfOAEpV = str(ICOyNkVjwdXS5TFKH6WgZAn4['folder'])
		pWmZEI8VqwO3eS5H1BizLCAy = '_MU'+C47G3hXaRMFLfOAEpV+'_'
	except: C47G3hXaRMFLfOAEpV = eHdDoxhJCEPMZFVa2fg
	try: dZSIYCvz3jfL = str(ICOyNkVjwdXS5TFKH6WgZAn4['sequence'])
	except: dZSIYCvz3jfL = eHdDoxhJCEPMZFVa2fg
	if   tWi3JH8rRhxcgnYuMVUK==710: pGiyauNHUVlRTnP = RaBNy15ftbPcOWj3()
	elif tWi3JH8rRhxcgnYuMVUK==711: pGiyauNHUVlRTnP = CCGFfNl9ruHDtn(C47G3hXaRMFLfOAEpV,dZSIYCvz3jfL)
	elif tWi3JH8rRhxcgnYuMVUK==712: pGiyauNHUVlRTnP = rkzyXPstow(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==713: pGiyauNHUVlRTnP = qGLa71o5AwfKDdeIbPsQBUTC3(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa,d9c6BWV3J2bQDMRELgX)
	elif tWi3JH8rRhxcgnYuMVUK==714: pGiyauNHUVlRTnP = EGoutUTNgihIRDYqyAn798cS4(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa,d9c6BWV3J2bQDMRELgX)
	elif tWi3JH8rRhxcgnYuMVUK==715: pGiyauNHUVlRTnP = bbmQeYGSTIv(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9)
	elif tWi3JH8rRhxcgnYuMVUK==716: pGiyauNHUVlRTnP = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,True)
	elif tWi3JH8rRhxcgnYuMVUK==717: pGiyauNHUVlRTnP = L3cBMQ4uyYzoJCvxrG(C47G3hXaRMFLfOAEpV,True)
	elif tWi3JH8rRhxcgnYuMVUK==718: pGiyauNHUVlRTnP = yCRcxseONua57QS4In3lt(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,bkA4Xjzw7mJa)
	elif tWi3JH8rRhxcgnYuMVUK==719: pGiyauNHUVlRTnP = A1AxPpad9tTLBbeIiOSQs2yq87hFW(bkA4Xjzw7mJa,C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,d9c6BWV3J2bQDMRELgX)
	elif tWi3JH8rRhxcgnYuMVUK==720: pGiyauNHUVlRTnP = ZZUK8FJ4RTYCoVeg(C47G3hXaRMFLfOAEpV,True)
	elif tWi3JH8rRhxcgnYuMVUK==721: pGiyauNHUVlRTnP = UUEtRXweFlzgISL1MGdTDHN(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==722: pGiyauNHUVlRTnP = mX9BxIuzQT0Ld7pw4(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==723: pGiyauNHUVlRTnP = bb9ikrhNVoXypm0f(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==726: pGiyauNHUVlRTnP = UMXb9i8NgvdGcQDpxnHE1l(C47G3hXaRMFLfOAEpV)
	elif tWi3JH8rRhxcgnYuMVUK==729: pGiyauNHUVlRTnP = dwS0voDrOHFbWN7TkJVRIfM(bkA4Xjzw7mJa,C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,d9c6BWV3J2bQDMRELgX)
	else: pGiyauNHUVlRTnP = False
	return pGiyauNHUVlRTnP
def RaBNy15ftbPcOWj3():
	for C47G3hXaRMFLfOAEpV in range(1,II0HXSngDhlLOuNQ9Vi+1):
		pWmZEI8VqwO3eS5H1BizLCAy = '_MU'+str(C47G3hXaRMFLfOAEpV)+'_'
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قائمة مجلد '+Fv7ouzCZdqTc95fJKBXA[C47G3hXaRMFLfOAEpV],eHdDoxhJCEPMZFVa2fg,720,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	return
def ZZUK8FJ4RTYCoVeg(C47G3hXaRMFLfOAEpV=eHdDoxhJCEPMZFVa2fg,UzF4sIShoZEgRjc7LK8w=eHdDoxhJCEPMZFVa2fg):
	if C47G3hXaRMFLfOAEpV:
		XfMk7rHsRnFqtvUQGoTAw31SEuz = {'folder':C47G3hXaRMFLfOAEpV}
		bb6cBW5yweZGvuXo0NQlM = eHdDoxhJCEPMZFVa2fg
	else:
		XfMk7rHsRnFqtvUQGoTAw31SEuz = eHdDoxhJCEPMZFVa2fg
		bb6cBW5yweZGvuXo0NQlM = eHdDoxhJCEPMZFVa2fg
	KKtj56DpzRl13Oe9dFCVLox = ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w)
	if not KKtj56DpzRl13Oe9dFCVLox:
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFFFFF00] إضافة وتغيير رابط'+bb6cBW5yweZGvuXo0NQlM+avcfIls8w7gk69hYUErHxzQTXtm24j+Fv7ouzCZdqTc95fJKBXA[1]+' [/COLOR]',eHdDoxhJCEPMZFVa2fg,711,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV,'sequence':1})
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFFFFF00] جلب ملفات'+bb6cBW5yweZGvuXo0NQlM+' [/COLOR]',eHdDoxhJCEPMZFVa2fg,712,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	else:
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'بحث في الملفات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,729,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_',eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'LIVE_GROUPED_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة من القسم'+bb6cBW5yweZGvuXo0NQlM,'LIVE_FROM_GROUP_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة من الاسم'+bb6cBW5yweZGvuXo0NQlM,'LIVE_FROM_NAME_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مصنفة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'LIVE_GROUPED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'LIVE_ORIGINAL_GROUPED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مجهولة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'LIVE_UNKNOWN_GROUPED_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'قنوات مجهولة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'LIVE_UNKNOWN_GROUPED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'VOD_ORIGINAL_GROUPED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مصنفة القسم'+bb6cBW5yweZGvuXo0NQlM,'VOD_FROM_GROUP_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مصنفة من الاسم'+bb6cBW5yweZGvuXo0NQlM,'VOD_FROM_NAME_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مجهولة بلا ترتيب'+bb6cBW5yweZGvuXo0NQlM,'VOD_UNKNOWN_GROUPED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'فيديوهات مجهولة مرتبة'+bb6cBW5yweZGvuXo0NQlM,'VOD_UNKNOWN_GROUPED_SORTED',713,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in range(1,hPjydHiuqQc75KFp+1):
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'إضافة وتغيير رابط'+bb6cBW5yweZGvuXo0NQlM+avcfIls8w7gk69hYUErHxzQTXtm24j+Fv7ouzCZdqTc95fJKBXA[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2],eHdDoxhJCEPMZFVa2fg,711,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV,'sequence':Wb5BrDZcyQsjJf17PSCnX4EYN6wv2})
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'جلب ملفات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,712,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'مسح ملفات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,717,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'عدد فيديوهات'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,721,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'Referer تغيير'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,726,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'User-Agent تغيير'+bb6cBW5yweZGvuXo0NQlM,eHdDoxhJCEPMZFVa2fg,723,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XfMk7rHsRnFqtvUQGoTAw31SEuz)
	return
def kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w=True):
	AlPsWV4GxSn,lWQtTG59CI1fxdgLZpHU = False,eHdDoxhJCEPMZFVa2fg
	sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV)
	if aKnyXZfMFDJViN1OtpLk==eHdDoxhJCEPMZFVa2fg: return False,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	bJ4IumHdZTPlG6 = vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV)
	if Z4qAYlatIBdvQ9HbkoK1ewSnM:
		W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'GET',Z4qAYlatIBdvQ9HbkoK1ewSnM,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,False,eHdDoxhJCEPMZFVa2fg,'M3U-CHECK_ACCOUNT-1st')
		yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
		if W1B5olYNHxq03IShy.succeeded:
			LdNw5aPHVpf,CKna7WLojgpR,bcAijs0KItM9d21lzQBToY,zzYa3rdb7IAuSTBOKZXghDeQ,HtpDeK3un29q1kTc4dzlA5LVWPU = 0,0,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
			try:
				wzDS1uGyNR = DIpuHqsKGS3ErJvk9taCRiX80('dict',yu26R85ckHMoK3reLVwSd)
				lWQtTG59CI1fxdgLZpHU = wzDS1uGyNR['user_info']['status']
				AlPsWV4GxSn = True
				bcAijs0KItM9d21lzQBToY = wzDS1uGyNR['server_info']['time_now']
			except: pass
			if bcAijs0KItM9d21lzQBToY:
				try:
					kkdSqXlNpHzJPsoa = b8bLFaejUB.strptime(bcAijs0KItM9d21lzQBToY,'%Y.%m.%d %H:%M:%S')
					LdNw5aPHVpf = int(b8bLFaejUB.mktime(kkdSqXlNpHzJPsoa))
					CKna7WLojgpR = int(a8HLTkO2ns49yGNgiroS-LdNw5aPHVpf)
					CKna7WLojgpR = int((CKna7WLojgpR+900)/1800)*1800
				except: pass
				try:
					kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(int(wzDS1uGyNR['user_info']['created_at']))
					zzYa3rdb7IAuSTBOKZXghDeQ = b8bLFaejUB.strftime('%Y.%m.%d %H:%M:%S',kkdSqXlNpHzJPsoa)
				except: pass
				try:
					kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(int(wzDS1uGyNR['user_info']['exp_date']))
					HtpDeK3un29q1kTc4dzlA5LVWPU = b8bLFaejUB.strftime('%Y.%m.%d %H:%M:%S',kkdSqXlNpHzJPsoa)
				except: pass
			MoO74hKeqm8fFka.setSetting('av.m3u.timestamp_'+C47G3hXaRMFLfOAEpV,str(a8HLTkO2ns49yGNgiroS))
			MoO74hKeqm8fFka.setSetting('av.m3u.timediff_'+C47G3hXaRMFLfOAEpV,str(CKna7WLojgpR))
			try:
				sWni2tcQXN9CK5r1 = '"server_info":'+yu26R85ckHMoK3reLVwSd.split('"server_info":')[1]
				sWni2tcQXN9CK5r1 = sWni2tcQXN9CK5r1.replace(':',': ').replace(',',', ').replace('}}','}')
				LnsdGf5Fxm10zEhWBoRYy7kgIDO923 = cBawilJXvK1m.findall('"url": "(.*?)", "port": "(.*?)"',sWni2tcQXN9CK5r1,cBawilJXvK1m.DOTALL)
				sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = LnsdGf5Fxm10zEhWBoRYy7kgIDO923[0]
			except: AlPsWV4GxSn = False
			if AlPsWV4GxSn and UzF4sIShoZEgRjc7LK8w:
				max = wzDS1uGyNR['user_info']['max_connections']
				ygOxvQwUiAFl8RDcNKdnbV = wzDS1uGyNR['user_info']['active_cons']
				notjG1dg0QfY8VlJ7IZc3mPxK4B = wzDS1uGyNR['user_info']['is_trial']
				kg8NQEiLAFDbf4JjzquICPWO2Vshyd = Z4qAYlatIBdvQ9HbkoK1ewSnM.split('?',1)
				sh3cDaZzUkKQFEAl74OryuPtGqJ = 'URL:  [COLOR FFC89008]'+Z4qAYlatIBdvQ9HbkoK1ewSnM+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\nStatus:  '+SbyWQGMDnV+lWQtTG59CI1fxdgLZpHU+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nTrial:    '+SbyWQGMDnV+str(notjG1dg0QfY8VlJ7IZc3mPxK4B=='1')+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nCreated  At:  '+SbyWQGMDnV+zzYa3rdb7IAuSTBOKZXghDeQ+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nExpiry Date:  '+SbyWQGMDnV+HtpDeK3un29q1kTc4dzlA5LVWPU+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nConnections   ( Active / Maximum ) :  '+SbyWQGMDnV+ygOxvQwUiAFl8RDcNKdnbV+' / '+max+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\nAllowed Outputs:   '+SbyWQGMDnV+" , ".join(wzDS1uGyNR['user_info']['allowed_output_formats'])+Nat0Dx9puRUWCsgz6JyFhY3
				sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\n'+sWni2tcQXN9CK5r1
				if lWQtTG59CI1fxdgLZpHU=='Active': lZGwNzPT1m9i2XJEW4tqKeDjA75a('الاشتراك يعمل بدون مشاكل',sh3cDaZzUkKQFEAl74OryuPtGqJ)
				else: lZGwNzPT1m9i2XJEW4tqKeDjA75a('يبدو أن هناك مشكلة في الاشتراك',sh3cDaZzUkKQFEAl74OryuPtGqJ)
	if Z4qAYlatIBdvQ9HbkoK1ewSnM and AlPsWV4GxSn and lWQtTG59CI1fxdgLZpHU=='Active':
		vR9cOpMtk51j(iwIlVQsgYezu,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+Z4qAYlatIBdvQ9HbkoK1ewSnM+' ]')
		UUQjG45NHzSqZuDe2vYIdTMlJOyc = True
	else:
		vR9cOpMtk51j(bGQ2Ok7RNi,'Checking M3U URL   [ Does not work ]   [ '+Z4qAYlatIBdvQ9HbkoK1ewSnM+' ]')
		if UzF4sIShoZEgRjc7LK8w: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		UUQjG45NHzSqZuDe2vYIdTMlJOyc = False
	return UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM
def EGoutUTNgihIRDYqyAn798cS4(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH,sxFw3Wz7DhVL,UzF4sIShoZEgRjc7LK8w=True):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
	KcogByxTmuNDInYwXALarEjUli7eOR = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list',PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH)
	pphAT0S9wnjNGsQUfl6WExoc7b = int(sxFw3Wz7DhVL)*100
	i5YMPKuS1WUQ4xctTE6rbJvD = pphAT0S9wnjNGsQUfl6WExoc7b-100
	for GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in KcogByxTmuNDInYwXALarEjUli7eOR[i5YMPKuS1WUQ4xctTE6rbJvD:pphAT0S9wnjNGsQUfl6WExoc7b]:
		E2tAkO0pMVgD = ('GROUPED' in PiD9gwCG7zxRHVKkaeldoUbZr or PiD9gwCG7zxRHVKkaeldoUbZr=='ALL')
		res2HUZzg4opdqQai7KSGyctLBY0 = ('GROUPED' not in PiD9gwCG7zxRHVKkaeldoUbZr and PiD9gwCG7zxRHVKkaeldoUbZr!='ALL')
		if E2tAkO0pMVgD or res2HUZzg4opdqQai7KSGyctLBY0:
			if   'ARCHIVED'  in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,718,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,'ARCHIVED',eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
			elif 'EPG' 		 in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,718,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,'FULL_EPG',eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
			elif 'TIMESHIFT' in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['folder',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,718,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,'TIMESHIFT',eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
			elif 'LIVE' 	 in PiD9gwCG7zxRHVKkaeldoUbZr: JXSlk8x495HmgiD.append(['live',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,715,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GsPYQbREvLAFw3aJ5XghmV,{'folder':C47G3hXaRMFLfOAEpV}])
			else: JXSlk8x495HmgiD.append(['video',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,715,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV}])
	RVOyUD2s8Bk9FLCwu4MSKJgt = len(KcogByxTmuNDInYwXALarEjUli7eOR)
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,714,RVOyUD2s8Bk9FLCwu4MSKJgt,lUXjebduy9AOMcg0rmQDkVH)
	return
def WK4nH6mpNaD31d8QsBXvTqxjuV(WWbrKSHUmJw1dZngOpFxlz):
	qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+'هذه القائمة إما فارغة أو غير موجودة',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+'أو الخدمة غير موجودة في اشتراكك',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+'أو رابط M3U الذي أنت أضفته غير صحيح',eHdDoxhJCEPMZFVa2fg,9999)
	return
def qGLa71o5AwfKDdeIbPsQBUTC3(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,lUXjebduy9AOMcg0rmQDkVH,sxFw3Wz7DhVL,IGajwMJYPOUdL8oK=eHdDoxhJCEPMZFVa2fg,UzF4sIShoZEgRjc7LK8w=True):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	WWbrKSHUmJw1dZngOpFxlz = pWmZEI8VqwO3eS5H1BizLCAy
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return False
	if '__SERIES__' in lUXjebduy9AOMcg0rmQDkVH: KKJiXTerDa7VhBbdLY82AklNzp,TN1zgbcDXFLGhokjZYH8297 = lUXjebduy9AOMcg0rmQDkVH.split('__SERIES__')
	else: KKJiXTerDa7VhBbdLY82AklNzp,TN1zgbcDXFLGhokjZYH8297 = lUXjebduy9AOMcg0rmQDkVH,eHdDoxhJCEPMZFVa2fg
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
	gHekBtYzlJoCFOwK = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list',PiD9gwCG7zxRHVKkaeldoUbZr,'__GROUPS__')
	if not gHekBtYzlJoCFOwK: return False
	apqKdVHu4nWY9 = []
	for L5DdYNZBtexX29zGHgQVoCiEJ,Ufd6obSCcXF in gHekBtYzlJoCFOwK:
		if '===== ===== =====' in L5DdYNZBtexX29zGHgQVoCiEJ:
			qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,9999)
			qfpnsHw19BiaSktcXWbGA('link',WWbrKSHUmJw1dZngOpFxlz+L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,9999)
			continue
		if IGajwMJYPOUdL8oK:
			if '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: WWbrKSHUmJw1dZngOpFxlz = 'SERIES'
			elif '!!__UNKNOWN__!!' in L5DdYNZBtexX29zGHgQVoCiEJ: WWbrKSHUmJw1dZngOpFxlz = 'UNKNOWN'
			elif 'LIVE' in PiD9gwCG7zxRHVKkaeldoUbZr: WWbrKSHUmJw1dZngOpFxlz = 'LIVE'
			else: WWbrKSHUmJw1dZngOpFxlz = 'VIDEOS'
			WWbrKSHUmJw1dZngOpFxlz = ',[COLOR FFC89008]'+WWbrKSHUmJw1dZngOpFxlz+': [/COLOR]'
		if '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: RqP1jLcQ0Z7pik,XskPiv4uWLdOyohJZqgI6UC7 = L5DdYNZBtexX29zGHgQVoCiEJ.split('__SERIES__')
		else: RqP1jLcQ0Z7pik,XskPiv4uWLdOyohJZqgI6UC7 = L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg
		if not lUXjebduy9AOMcg0rmQDkVH:
			if RqP1jLcQ0Z7pik in apqKdVHu4nWY9: continue
			apqKdVHu4nWY9.append(RqP1jLcQ0Z7pik)
			if 'RANDOM' in IGajwMJYPOUdL8oK: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+RqP1jLcQ0Z7pik,PiD9gwCG7zxRHVKkaeldoUbZr,168,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			elif '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+RqP1jLcQ0Z7pik,PiD9gwCG7zxRHVKkaeldoUbZr,713,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			else: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+RqP1jLcQ0Z7pik,PiD9gwCG7zxRHVKkaeldoUbZr,714,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
		elif '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ and RqP1jLcQ0Z7pik==KKJiXTerDa7VhBbdLY82AklNzp:
			if XskPiv4uWLdOyohJZqgI6UC7 in apqKdVHu4nWY9: continue
			apqKdVHu4nWY9.append(XskPiv4uWLdOyohJZqgI6UC7)
			if 'RANDOM' in IGajwMJYPOUdL8oK: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+XskPiv4uWLdOyohJZqgI6UC7,PiD9gwCG7zxRHVKkaeldoUbZr,168,eHdDoxhJCEPMZFVa2fg,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			else: qfpnsHw19BiaSktcXWbGA('folder',WWbrKSHUmJw1dZngOpFxlz+XskPiv4uWLdOyohJZqgI6UC7,PiD9gwCG7zxRHVKkaeldoUbZr,714,Ufd6obSCcXF,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	JXSlk8x495HmgiD[:] = sorted(JXSlk8x495HmgiD,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[1].lower())
	if not IGajwMJYPOUdL8oK:
		pphAT0S9wnjNGsQUfl6WExoc7b = int(sxFw3Wz7DhVL)*100
		i5YMPKuS1WUQ4xctTE6rbJvD = pphAT0S9wnjNGsQUfl6WExoc7b-100
		RVOyUD2s8Bk9FLCwu4MSKJgt = len(JXSlk8x495HmgiD)
		JXSlk8x495HmgiD[:] = JXSlk8x495HmgiD[i5YMPKuS1WUQ4xctTE6rbJvD:pphAT0S9wnjNGsQUfl6WExoc7b]
		dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,713,RVOyUD2s8Bk9FLCwu4MSKJgt,lUXjebduy9AOMcg0rmQDkVH)
	return True
def yCRcxseONua57QS4In3lt(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,FStg5PE8Vmy):
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,True): return
	bJ4IumHdZTPlG6 = vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV)
	LdNw5aPHVpf = MoO74hKeqm8fFka.getSetting('av.m3u.timestamp_'+C47G3hXaRMFLfOAEpV)
	if not LdNw5aPHVpf or a8HLTkO2ns49yGNgiroS-int(LdNw5aPHVpf)>24*xvjre5b4yREScf:
		UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,False)
		if not UUQjG45NHzSqZuDe2vYIdTMlJOyc: return
	CKna7WLojgpR = int(MoO74hKeqm8fFka.getSetting('av.m3u.timediff_'+C47G3hXaRMFLfOAEpV))
	YJ6CzR2VT4ckFjPySvqUpWGgI = MoO74hKeqm8fFka.getSetting('av.m3u.server_'+C47G3hXaRMFLfOAEpV)
	aKnyXZfMFDJViN1OtpLk = MoO74hKeqm8fFka.getSetting('av.m3u.username_'+C47G3hXaRMFLfOAEpV)
	gojXxJqFmu6f = MoO74hKeqm8fFka.getSetting('av.m3u.password_'+C47G3hXaRMFLfOAEpV)
	bjCEsJdIwZ83mcGTepPAMvl9 = Nn360bq79W2kzUt.split('/')
	bb9EjiWfS3Zt62 = bjCEsJdIwZ83mcGTepPAMvl9[-1].replace('.ts',eHdDoxhJCEPMZFVa2fg).replace('.m3u8',eHdDoxhJCEPMZFVa2fg)
	if FStg5PE8Vmy=='SHORT_EPG': BD34N6e0tzJcfbkFG = 'get_short_epg'
	else: BD34N6e0tzJcfbkFG = 'get_simple_data_table'
	Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f = IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV)
	if not aKnyXZfMFDJViN1OtpLk: return
	HHsbIdpC2e1TNcZvi8VK = Z4qAYlatIBdvQ9HbkoK1ewSnM+'&action='+BD34N6e0tzJcfbkFG+'&stream_id='+bb9EjiWfS3Zt62
	yu26R85ckHMoK3reLVwSd = jwIOCa53Eb(ZAl2gePWifs3IXG,HHsbIdpC2e1TNcZvi8VK,eHdDoxhJCEPMZFVa2fg,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,'M3U-EPG_ITEMS-2nd')
	BzPQ14LFmMeDw = DIpuHqsKGS3ErJvk9taCRiX80('dict',yu26R85ckHMoK3reLVwSd)
	bv74hDozKXOM3ifInlAUekjyR = BzPQ14LFmMeDw['epg_listings']
	b8yfIWt2q7hedP3AjukmU0MQOT = []
	if FStg5PE8Vmy in ['ARCHIVED','TIMESHIFT']:
		for wzDS1uGyNR in bv74hDozKXOM3ifInlAUekjyR:
			if wzDS1uGyNR['has_archive']==1:
				b8yfIWt2q7hedP3AjukmU0MQOT.append(wzDS1uGyNR)
				if FStg5PE8Vmy in ['TIMESHIFT']: break
		if not b8yfIWt2q7hedP3AjukmU0MQOT: return
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFC89008]الملفات الأولي بهذه القائمة قد لا تعمل[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		if FStg5PE8Vmy in ['TIMESHIFT']:
			gKqRJds7nmDhb = 2
			ZURVzForc0AL = gKqRJds7nmDhb*xvjre5b4yREScf
			b8yfIWt2q7hedP3AjukmU0MQOT = []
			njS0D1VfWqZ2mYoIA3PR = int(int(wzDS1uGyNR['start_timestamp'])/ZURVzForc0AL)*ZURVzForc0AL
			OuV8JivWNP9DFMH = a8HLTkO2ns49yGNgiroS+ZURVzForc0AL
			LqBi8hP6pR1cfUNAQtwY0njW5bar = int((OuV8JivWNP9DFMH-njS0D1VfWqZ2mYoIA3PR)/xvjre5b4yREScf)
			for czAy10w728nRUoaYfdNJPjStpq in range(LqBi8hP6pR1cfUNAQtwY0njW5bar):
				if czAy10w728nRUoaYfdNJPjStpq>=6:
					if czAy10w728nRUoaYfdNJPjStpq%gKqRJds7nmDhb!=0: continue
					slaTNFr0xXbBPyG5ndKCevfZ = ZURVzForc0AL
				else: slaTNFr0xXbBPyG5ndKCevfZ = ZURVzForc0AL//2
				stZaKcdPJMyCf4wHpb = njS0D1VfWqZ2mYoIA3PR+czAy10w728nRUoaYfdNJPjStpq*xvjre5b4yREScf
				wzDS1uGyNR = {}
				wzDS1uGyNR['title'] = eHdDoxhJCEPMZFVa2fg
				kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(stZaKcdPJMyCf4wHpb-CKna7WLojgpR-xvjre5b4yREScf)
				wzDS1uGyNR['start'] = b8bLFaejUB.strftime('%Y.%m.%d %H:%M:%S',kkdSqXlNpHzJPsoa)
				wzDS1uGyNR['start_timestamp'] = str(stZaKcdPJMyCf4wHpb)
				wzDS1uGyNR['stop_timestamp'] = str(stZaKcdPJMyCf4wHpb+slaTNFr0xXbBPyG5ndKCevfZ)
				b8yfIWt2q7hedP3AjukmU0MQOT.append(wzDS1uGyNR)
	elif FStg5PE8Vmy in ['SHORT_EPG','FULL_EPG']: b8yfIWt2q7hedP3AjukmU0MQOT = bv74hDozKXOM3ifInlAUekjyR
	if FStg5PE8Vmy=='FULL_EPG' and len(b8yfIWt2q7hedP3AjukmU0MQOT)>0:
		qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+'[COLOR FFC89008]هذه قائمة برامج القنوات (جدول فقط)ـ[/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	gJWDbVRpSe2n1F8l6jLKH = []
	Ufd6obSCcXF = ccwRLKk3hs0E.getInfoLabel('ListItem.Icon')
	for wzDS1uGyNR in b8yfIWt2q7hedP3AjukmU0MQOT:
		hgE9MlmDou = HHP76VFiKDS2xphlGsqN48j1.b64decode(wzDS1uGyNR['title'])
		if WHjh1POtMKlmgiy68RSqb: hgE9MlmDou = hgE9MlmDou.decode(m6PFtLblInpNZ8x)
		stZaKcdPJMyCf4wHpb = int(wzDS1uGyNR['start_timestamp'])
		BGEXq7PRMi1CcklZHKFeN6bUVvy3 = int(wzDS1uGyNR['stop_timestamp'])
		O9zB32Advt7E = str(int((BGEXq7PRMi1CcklZHKFeN6bUVvy3-stZaKcdPJMyCf4wHpb+59)/60))
		F0QgXY4bw6HIk9zonWfCcU5jvxK81a = wzDS1uGyNR['start'].replace(avcfIls8w7gk69hYUErHxzQTXtm24j,':')
		kkdSqXlNpHzJPsoa = b8bLFaejUB.localtime(stZaKcdPJMyCf4wHpb-xvjre5b4yREScf)
		wNnGJfLil5ry2BETMkV4bHvu8 = b8bLFaejUB.strftime('%H:%M',kkdSqXlNpHzJPsoa)
		U5iRE2rcZ3lIgHtzfPsj9 = b8bLFaejUB.strftime('%a',kkdSqXlNpHzJPsoa)
		if FStg5PE8Vmy=='SHORT_EPG': hgE9MlmDou = OR97bMGecfgDCqux3YdAZ6y+wNnGJfLil5ry2BETMkV4bHvu8+' ـ '+hgE9MlmDou+Nat0Dx9puRUWCsgz6JyFhY3
		elif FStg5PE8Vmy=='TIMESHIFT': hgE9MlmDou = U5iRE2rcZ3lIgHtzfPsj9+avcfIls8w7gk69hYUErHxzQTXtm24j+wNnGJfLil5ry2BETMkV4bHvu8+' ('+O9zB32Advt7E+'min)'
		else: hgE9MlmDou = U5iRE2rcZ3lIgHtzfPsj9+avcfIls8w7gk69hYUErHxzQTXtm24j+wNnGJfLil5ry2BETMkV4bHvu8+' ('+O9zB32Advt7E+'min)   '+hgE9MlmDou+' ـ'
		if FStg5PE8Vmy in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			IvU9e6f0Mu47wpFYz3Holx = YJ6CzR2VT4ckFjPySvqUpWGgI+'/timeshift/'+aKnyXZfMFDJViN1OtpLk+'/'+gojXxJqFmu6f+'/'+O9zB32Advt7E+'/'+F0QgXY4bw6HIk9zonWfCcU5jvxK81a+'/'+bb9EjiWfS3Zt62+'.m3u8'
			if FStg5PE8Vmy=='FULL_EPG': qfpnsHw19BiaSktcXWbGA('link',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,IvU9e6f0Mu47wpFYz3Holx,9999,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
			else: qfpnsHw19BiaSktcXWbGA('video',pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,IvU9e6f0Mu47wpFYz3Holx,715,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
		gJWDbVRpSe2n1F8l6jLKH.append(hgE9MlmDou)
	if FStg5PE8Vmy=='SHORT_EPG' and gJWDbVRpSe2n1F8l6jLKH: lOtGFrbsSEDVNw2 = ToWx9yLluKgEASQDt(gJWDbVRpSe2n1F8l6jLKH)
	return gJWDbVRpSe2n1F8l6jLKH
def mX9BxIuzQT0Ld7pw4(C47G3hXaRMFLfOAEpV):
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,True): return
	YJ6CzR2VT4ckFjPySvqUpWGgI,mnGPhFpUN9BakfO6g8Yw375jLeIJAb,II9aoztRxlVXCmdyLwGH3EFe0hf = eHdDoxhJCEPMZFVa2fg,0,0
	UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = kk4B3AM1iJUXWe58n(C47G3hXaRMFLfOAEpV,False)
	if UUQjG45NHzSqZuDe2vYIdTMlJOyc:
		XnjARw7MEty2q = yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(sVvnE3SLxqUc2iQ1dNe)
		mnGPhFpUN9BakfO6g8Yw375jLeIJAb = vd3T7NboyCKmIhSZLAukRGn8Et(XnjARw7MEty2q[0],int(sVNw9Jv7gtH5aC4QjcWAYUM))
		vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'LIVE_GROUPED')
		E2ELD9hkvJfmeOo075IS1 = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list','LIVE_GROUPED')
		KcogByxTmuNDInYwXALarEjUli7eOR = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list','LIVE_GROUPED',E2ELD9hkvJfmeOo075IS1[1])
		Nn360bq79W2kzUt = KcogByxTmuNDInYwXALarEjUli7eOR[0][2]
		BBP5JWgHVesyaEU3Ozl = cBawilJXvK1m.findall('://(.*?)/',Nn360bq79W2kzUt,cBawilJXvK1m.DOTALL)
		BBP5JWgHVesyaEU3Ozl = BBP5JWgHVesyaEU3Ozl[0]
		if ':' in BBP5JWgHVesyaEU3Ozl: hb4vaRmE7UPwrY0IAFy6kgfsjcW3,hx6vrZYEAodzjW0tpL8DH = BBP5JWgHVesyaEU3Ozl.split(':')
		else: hb4vaRmE7UPwrY0IAFy6kgfsjcW3,hx6vrZYEAodzjW0tpL8DH = BBP5JWgHVesyaEU3Ozl,'80'
		sJAEDoz75iPduFtHjI = yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(hb4vaRmE7UPwrY0IAFy6kgfsjcW3)
		II9aoztRxlVXCmdyLwGH3EFe0hf = vd3T7NboyCKmIhSZLAukRGn8Et(sJAEDoz75iPduFtHjI[0],int(hx6vrZYEAodzjW0tpL8DH))
	if mnGPhFpUN9BakfO6g8Yw375jLeIJAb and II9aoztRxlVXCmdyLwGH3EFe0hf:
		sh3cDaZzUkKQFEAl74OryuPtGqJ = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\n'+'وقت ضائع في السيرفر الأصلي'+kDUv7ouWrcgMe6OipQJm+str(int(II9aoztRxlVXCmdyLwGH3EFe0hf*1000))+' ملي ثانية'
		sh3cDaZzUkKQFEAl74OryuPtGqJ += '\n\n'+'وقت ضائع في السيرفر البديل'+kDUv7ouWrcgMe6OipQJm+str(int(mnGPhFpUN9BakfO6g8Yw375jLeIJAb*1000))+' ملي ثانية'
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',sh3cDaZzUkKQFEAl74OryuPtGqJ)
		if kMnoXVxN5byYJSzPrsu==1 and mnGPhFpUN9BakfO6g8Yw375jLeIJAb<II9aoztRxlVXCmdyLwGH3EFe0hf: YJ6CzR2VT4ckFjPySvqUpWGgI = sVvnE3SLxqUc2iQ1dNe+':'+sVNw9Jv7gtH5aC4QjcWAYUM
	else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	MoO74hKeqm8fFka.setSetting('av.m3u.server_'+C47G3hXaRMFLfOAEpV,YJ6CzR2VT4ckFjPySvqUpWGgI)
	return
def bbmQeYGSTIv(C47G3hXaRMFLfOAEpV,Nn360bq79W2kzUt,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9):
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV)
	T4JSyRP1bD25NGq8lOc7XhkA0iudt = MoO74hKeqm8fFka.getSetting('av.m3u.referer_'+C47G3hXaRMFLfOAEpV)
	if dCKxX4PEzlZ6bNO7aB1nYqQLv835o or T4JSyRP1bD25NGq8lOc7XhkA0iudt:
		Nn360bq79W2kzUt += '|'
		if dCKxX4PEzlZ6bNO7aB1nYqQLv835o: Nn360bq79W2kzUt += '&User-Agent='+dCKxX4PEzlZ6bNO7aB1nYqQLv835o
		if T4JSyRP1bD25NGq8lOc7XhkA0iudt: Nn360bq79W2kzUt += '&Referer='+T4JSyRP1bD25NGq8lOc7XhkA0iudt
		Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace('|&','|')
	IZkpyKSFVarcHwG1g6emqQv70h(Nn360bq79W2kzUt,FO8SKWr40dDexHgbfRUGBi,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9)
	return
def bb9ikrhNVoXypm0f(C47G3hXaRMFLfOAEpV):
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV)
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center','استخدام الأصلي','تعديل القديم',dCKxX4PEzlZ6bNO7aB1nYqQLv835o,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if EU3GmLta4FcQPY9rOlpSe6uh7==1: dCKxX4PEzlZ6bNO7aB1nYqQLv835o = mJ1lHWKUPcZGezML7X2u9S('أكتب ـM3U User-Agent جديد',dCKxX4PEzlZ6bNO7aB1nYqQLv835o,True)
	else: dCKxX4PEzlZ6bNO7aB1nYqQLv835o = 'Unknown'
	if dCKxX4PEzlZ6bNO7aB1nYqQLv835o==avcfIls8w7gk69hYUErHxzQTXtm24j:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dCKxX4PEzlZ6bNO7aB1nYqQLv835o,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if EU3GmLta4FcQPY9rOlpSe6uh7!=1:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم الإلغاء')
		return
	MoO74hKeqm8fFka.setSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV,dCKxX4PEzlZ6bNO7aB1nYqQLv835o)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def UMXb9i8NgvdGcQDpxnHE1l(C47G3hXaRMFLfOAEpV):
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	T4JSyRP1bD25NGq8lOc7XhkA0iudt = MoO74hKeqm8fFka.getSetting('av.m3u.referer_'+C47G3hXaRMFLfOAEpV)
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center','استخدام الأصلي','تعديل القديم',T4JSyRP1bD25NGq8lOc7XhkA0iudt,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if EU3GmLta4FcQPY9rOlpSe6uh7==1: T4JSyRP1bD25NGq8lOc7XhkA0iudt = mJ1lHWKUPcZGezML7X2u9S('أكتب ـM3U Referer جديد',T4JSyRP1bD25NGq8lOc7XhkA0iudt,True)
	else: T4JSyRP1bD25NGq8lOc7XhkA0iudt = eHdDoxhJCEPMZFVa2fg
	if T4JSyRP1bD25NGq8lOc7XhkA0iudt==avcfIls8w7gk69hYUErHxzQTXtm24j:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,T4JSyRP1bD25NGq8lOc7XhkA0iudt,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if EU3GmLta4FcQPY9rOlpSe6uh7!=1:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم الإلغاء')
		return
	MoO74hKeqm8fFka.setSetting('av.m3u.referer_'+C47G3hXaRMFLfOAEpV,T4JSyRP1bD25NGq8lOc7XhkA0iudt)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def IXyO1KRtkocdw7i(C47G3hXaRMFLfOAEpV,Gornc7Skx4flLi=eHdDoxhJCEPMZFVa2fg):
	if not wRUJByW08AaXQohuegIqbGp: wRUJByW08AaXQohuegIqbGp = MoO74hKeqm8fFka.getSetting('av.m3u.url_'+C47G3hXaRMFLfOAEpV)
	YJ6CzR2VT4ckFjPySvqUpWGgI = b31wAB8mhaz2rXHoJFlfvDugtsOj(wRUJByW08AaXQohuegIqbGp,'url')
	aKnyXZfMFDJViN1OtpLk = cBawilJXvK1m.findall('username=(.*?)&',wRUJByW08AaXQohuegIqbGp+'&',cBawilJXvK1m.DOTALL)
	gojXxJqFmu6f = cBawilJXvK1m.findall('password=(.*?)&',wRUJByW08AaXQohuegIqbGp+'&',cBawilJXvK1m.DOTALL)
	if not aKnyXZfMFDJViN1OtpLk or not gojXxJqFmu6f:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	aKnyXZfMFDJViN1OtpLk = aKnyXZfMFDJViN1OtpLk[0]
	gojXxJqFmu6f = gojXxJqFmu6f[0]
	Z4qAYlatIBdvQ9HbkoK1ewSnM = YJ6CzR2VT4ckFjPySvqUpWGgI+'/player_api.php?username='+aKnyXZfMFDJViN1OtpLk+'&password='+gojXxJqFmu6f
	JIR9i57ld1yOUPcjzVv = YJ6CzR2VT4ckFjPySvqUpWGgI+'/get.php?username='+aKnyXZfMFDJViN1OtpLk+'&password='+gojXxJqFmu6f+'&type=m3u_plus'
	return Z4qAYlatIBdvQ9HbkoK1ewSnM,JIR9i57ld1yOUPcjzVv,YJ6CzR2VT4ckFjPySvqUpWGgI,aKnyXZfMFDJViN1OtpLk,gojXxJqFmu6f
def l9byZ04Phe6E8tvGRnS5HcNj(C47G3hXaRMFLfOAEpV,TWo6cYv7ZdHIqjFRDwaL=eHdDoxhJCEPMZFVa2fg):
	YYx8Ik4ETmW = TWo6cYv7ZdHIqjFRDwaL.replace('/','_').replace(':','_').replace('.','_')
	YYx8Ik4ETmW = YYx8Ik4ETmW.replace('?','_').replace('=','_').replace('&','_')
	YYx8Ik4ETmW = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,YYx8Ik4ETmW).strip('.m3u')+'.m3u'
	return YYx8Ik4ETmW
def CCGFfNl9ruHDtn(C47G3hXaRMFLfOAEpV,dZSIYCvz3jfL):
	PPkjeglVstfCUqK1 = MoO74hKeqm8fFka.getSetting('av.m3u.url_'+C47G3hXaRMFLfOAEpV+'_'+dZSIYCvz3jfL)
	ccHod7fq84uXZRkEx = True
	if PPkjeglVstfCUqK1:
		EU3GmLta4FcQPY9rOlpSe6uh7 = vKD1rqZCXUbcR7n38VyatMSEL('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',SbyWQGMDnV+PPkjeglVstfCUqK1+Nat0Dx9puRUWCsgz6JyFhY3+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if EU3GmLta4FcQPY9rOlpSe6uh7==-1: return
		elif EU3GmLta4FcQPY9rOlpSe6uh7==0: PPkjeglVstfCUqK1 = eHdDoxhJCEPMZFVa2fg
		elif EU3GmLta4FcQPY9rOlpSe6uh7==2:
			EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if EU3GmLta4FcQPY9rOlpSe6uh7 in [-1,0]: return
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح الرابط')
			ccHod7fq84uXZRkEx = False
			OOi8lyrfzvSkgQUT1jDbo0LCVXB3 = eHdDoxhJCEPMZFVa2fg
	if ccHod7fq84uXZRkEx:
		OOi8lyrfzvSkgQUT1jDbo0LCVXB3 = mJ1lHWKUPcZGezML7X2u9S('اكتب رابط M3U كاملا',PPkjeglVstfCUqK1)
		OOi8lyrfzvSkgQUT1jDbo0LCVXB3 = OOi8lyrfzvSkgQUT1jDbo0LCVXB3.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if not OOi8lyrfzvSkgQUT1jDbo0LCVXB3:
			EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if EU3GmLta4FcQPY9rOlpSe6uh7 in [-1,0]: return
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح الرابط')
		else:
			sh3cDaZzUkKQFEAl74OryuPtGqJ = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			EU3GmLta4FcQPY9rOlpSe6uh7 = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'الرابط الجديد هو:',SbyWQGMDnV+OOi8lyrfzvSkgQUT1jDbo0LCVXB3+Nat0Dx9puRUWCsgz6JyFhY3+'\n\n'+sh3cDaZzUkKQFEAl74OryuPtGqJ)
			if EU3GmLta4FcQPY9rOlpSe6uh7!=1:
				dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم الإلغاء')
				return
	MoO74hKeqm8fFka.setSetting('av.m3u.url_'+C47G3hXaRMFLfOAEpV+'_'+dZSIYCvz3jfL,OOi8lyrfzvSkgQUT1jDbo0LCVXB3)
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV)
	if not dCKxX4PEzlZ6bNO7aB1nYqQLv835o: MoO74hKeqm8fFka.setSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV,'Unknown')
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def OOUVS5wbcN(xp7ejmzyYGO9ShDsid6RZ,ult1ETRQCWc7dILqY4eDVF9wikx3h,wPnNdxH34ZaC0mOlGsf,OiFse6HmrT1Iga9D0XwMfR,bsr1VEvZf7wR,GWv6itIHy0RUwgQzxbMN,JIR9i57ld1yOUPcjzVv):
	KcogByxTmuNDInYwXALarEjUli7eOR,ME9eavOwmHNguFlL = [],[]
	VfIUnK9OoPN7yFXsrD = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		if GWv6itIHy0RUwgQzxbMN%473==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,40+int(10*GWv6itIHy0RUwgQzxbMN/bsr1VEvZf7wR),'قراءة الفيديوهات','الفيديو رقم:-',str(GWv6itIHy0RUwgQzxbMN)+' / '+str(bsr1VEvZf7wR))
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return None,None,None
		Nn360bq79W2kzUt = cBawilJXvK1m.findall('^(.*?)\n+((http|https|rtmp).*?)$',KyujWR9edp0HVxJ,cBawilJXvK1m.DOTALL)
		if Nn360bq79W2kzUt:
			KyujWR9edp0HVxJ,Nn360bq79W2kzUt,bRaH8UFOVKAN1MBX3J05ynuGqjeIf = Nn360bq79W2kzUt[0]
			Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg)
			KyujWR9edp0HVxJ = KyujWR9edp0HVxJ.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg)
		else:
			ME9eavOwmHNguFlL.append({'line':KyujWR9edp0HVxJ})
			continue
		QwzsWf9dISmA0eMxr2G,GsPYQbREvLAFw3aJ5XghmV,L5DdYNZBtexX29zGHgQVoCiEJ,hgE9MlmDou,IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,knmtBWZsi0fg2pwyFu = {},eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,False
		try:
			KyujWR9edp0HVxJ,hgE9MlmDou = KyujWR9edp0HVxJ.rsplit('",',1)
			KyujWR9edp0HVxJ = KyujWR9edp0HVxJ+'"'
		except:
			try: KyujWR9edp0HVxJ,hgE9MlmDou = KyujWR9edp0HVxJ.rsplit('1,',1)
			except: hgE9MlmDou = eHdDoxhJCEPMZFVa2fg
		QwzsWf9dISmA0eMxr2G['url'] = Nn360bq79W2kzUt
		dd27rpAXR8FhuHDqoSecZwBC3Qsy = cBawilJXvK1m.findall(' (.*?)="(.*?)"',KyujWR9edp0HVxJ,cBawilJXvK1m.DOTALL)
		for ddmHpyREIePbf5wAU,iS0cNMfBdTqAmJX3zh8nr4Y9 in dd27rpAXR8FhuHDqoSecZwBC3Qsy:
			ddmHpyREIePbf5wAU = ddmHpyREIePbf5wAU.replace('"',eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			QwzsWf9dISmA0eMxr2G[ddmHpyREIePbf5wAU] = iS0cNMfBdTqAmJX3zh8nr4Y9.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		iVxlvCL28w = list(QwzsWf9dISmA0eMxr2G.keys())
		if not hgE9MlmDou:
			if 'name' in iVxlvCL28w and QwzsWf9dISmA0eMxr2G['name']: hgE9MlmDou = QwzsWf9dISmA0eMxr2G['name']
		QwzsWf9dISmA0eMxr2G['title'] = hgE9MlmDou.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'logo' in iVxlvCL28w:
			QwzsWf9dISmA0eMxr2G['img'] = QwzsWf9dISmA0eMxr2G['logo']
			del QwzsWf9dISmA0eMxr2G['logo']
		else: QwzsWf9dISmA0eMxr2G['img'] = eHdDoxhJCEPMZFVa2fg
		if 'group' in iVxlvCL28w and QwzsWf9dISmA0eMxr2G['group']: L5DdYNZBtexX29zGHgQVoCiEJ = QwzsWf9dISmA0eMxr2G['group']
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in Nn360bq79W2kzUt.lower() for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in VfIUnK9OoPN7yFXsrD):
			knmtBWZsi0fg2pwyFu = True if 'm3u' not in Nn360bq79W2kzUt else False
		if knmtBWZsi0fg2pwyFu or '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ or '__MOVIES__' in L5DdYNZBtexX29zGHgQVoCiEJ:
			IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'VOD'
			if '__SERIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_SERIES'
			elif '__MOVIES__' in L5DdYNZBtexX29zGHgQVoCiEJ: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_MOVIES'
			else: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_UNKNOWN'
			L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.replace('__SERIES__',eHdDoxhJCEPMZFVa2fg).replace('__MOVIES__',eHdDoxhJCEPMZFVa2fg)
		else:
			IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'LIVE'
			if hgE9MlmDou in ult1ETRQCWc7dILqY4eDVF9wikx3h: GsPYQbREvLAFw3aJ5XghmV = GsPYQbREvLAFw3aJ5XghmV+'_EPG'
			if hgE9MlmDou in wPnNdxH34ZaC0mOlGsf: GsPYQbREvLAFw3aJ5XghmV = GsPYQbREvLAFw3aJ5XghmV+'_ARCHIVED'
			if not L5DdYNZBtexX29zGHgQVoCiEJ: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+'_UNKNOWN'
			else: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9+GsPYQbREvLAFw3aJ5XghmV
		L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ.strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'LIVE_UNKNOWN' in IIheJZ2dTAzKtwkMCUlmOGX6PuNR9: L5DdYNZBtexX29zGHgQVoCiEJ = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in IIheJZ2dTAzKtwkMCUlmOGX6PuNR9: L5DdYNZBtexX29zGHgQVoCiEJ = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in IIheJZ2dTAzKtwkMCUlmOGX6PuNR9:
			Fxr4eJsb70QZ = cBawilJXvK1m.findall('(.*?) [Ss]\d+ +[Ee]\d+',QwzsWf9dISmA0eMxr2G['title'],cBawilJXvK1m.DOTALL)
			if Fxr4eJsb70QZ: Fxr4eJsb70QZ = Fxr4eJsb70QZ[0]
			else: Fxr4eJsb70QZ = '!!__UNKNOWN_SERIES__!!'
			L5DdYNZBtexX29zGHgQVoCiEJ = L5DdYNZBtexX29zGHgQVoCiEJ+'__SERIES__'+Fxr4eJsb70QZ
		if 'id' in iVxlvCL28w: del QwzsWf9dISmA0eMxr2G['id']
		if 'ID' in iVxlvCL28w: del QwzsWf9dISmA0eMxr2G['ID']
		if 'name' in iVxlvCL28w: del QwzsWf9dISmA0eMxr2G['name']
		hgE9MlmDou = QwzsWf9dISmA0eMxr2G['title']
		hgE9MlmDou = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(hgE9MlmDou)
		hgE9MlmDou = QCVBvbhYerZWxHumPIa8i1kGq(hgE9MlmDou)
		oit8rylYd3Q6ReqxHDOU2vXsgA,L5DdYNZBtexX29zGHgQVoCiEJ = I79o6neSfOlXmL(L5DdYNZBtexX29zGHgQVoCiEJ)
		HdmksvabBKMuS,hgE9MlmDou = I79o6neSfOlXmL(hgE9MlmDou)
		QwzsWf9dISmA0eMxr2G['type'] = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9
		QwzsWf9dISmA0eMxr2G['context'] = GsPYQbREvLAFw3aJ5XghmV
		QwzsWf9dISmA0eMxr2G['group'] = L5DdYNZBtexX29zGHgQVoCiEJ.upper()
		QwzsWf9dISmA0eMxr2G['title'] = hgE9MlmDou.upper()
		QwzsWf9dISmA0eMxr2G['country'] = HdmksvabBKMuS.upper()
		QwzsWf9dISmA0eMxr2G['language'] = oit8rylYd3Q6ReqxHDOU2vXsgA.upper()
		KcogByxTmuNDInYwXALarEjUli7eOR.append(QwzsWf9dISmA0eMxr2G)
		GWv6itIHy0RUwgQzxbMN += 1
	return KcogByxTmuNDInYwXALarEjUli7eOR,GWv6itIHy0RUwgQzxbMN,ME9eavOwmHNguFlL
def QCVBvbhYerZWxHumPIa8i1kGq(hgE9MlmDou):
	hgE9MlmDou = hgE9MlmDou.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	hgE9MlmDou = hgE9MlmDou.replace('||','|').replace('___',':').replace('--','-')
	hgE9MlmDou = hgE9MlmDou.replace('[[','[').replace(']]',']')
	hgE9MlmDou = hgE9MlmDou.replace('((','(').replace('))',')')
	hgE9MlmDou = hgE9MlmDou.replace('<<','<').replace('>>','>')
	hgE9MlmDou = hgE9MlmDou.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	return hgE9MlmDou
def l1dv7FkD8BN0Ay32KMGaiTfW4uJ(gLoId1uPvFDK,OiFse6HmrT1Iga9D0XwMfR,dZSIYCvz3jfL):
	aaH5voLOlVU8F = {}
	for PcwEmo0dXj7vu8zypFefxDMr in ga2Cxd7Bulrb: aaH5voLOlVU8F[PcwEmo0dXj7vu8zypFefxDMr+'_'+dZSIYCvz3jfL] = []
	bsr1VEvZf7wR = len(gLoId1uPvFDK)
	VVLvyiKDt0eoW = str(bsr1VEvZf7wR)
	GWv6itIHy0RUwgQzxbMN = 0
	ME9eavOwmHNguFlL = []
	for QwzsWf9dISmA0eMxr2G in gLoId1uPvFDK:
		if GWv6itIHy0RUwgQzxbMN%873==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,50+int(5*GWv6itIHy0RUwgQzxbMN/bsr1VEvZf7wR),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(GWv6itIHy0RUwgQzxbMN)+' / '+VVLvyiKDt0eoW)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return None,None
		L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF = QwzsWf9dISmA0eMxr2G['group'],QwzsWf9dISmA0eMxr2G['context'],QwzsWf9dISmA0eMxr2G['title'],QwzsWf9dISmA0eMxr2G['url'],QwzsWf9dISmA0eMxr2G['img']
		HdmksvabBKMuS,oit8rylYd3Q6ReqxHDOU2vXsgA,PcwEmo0dXj7vu8zypFefxDMr = QwzsWf9dISmA0eMxr2G['country'],QwzsWf9dISmA0eMxr2G['language'],QwzsWf9dISmA0eMxr2G['type']
		u5g2qtGyeaocXSp4Mn = (L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		EVfiWGwHpCReXt4x3PU7cMmyhBJ = False
		if 'LIVE' in PcwEmo0dXj7vu8zypFefxDMr:
			if 'UNKNOWN' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_UNKNOWN_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			elif 'LIVE' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			else: EVfiWGwHpCReXt4x3PU7cMmyhBJ = True
			aaH5voLOlVU8F['LIVE_ORIGINAL_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
		elif 'VOD' in PcwEmo0dXj7vu8zypFefxDMr:
			if 'UNKNOWN' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_UNKNOWN_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			elif 'MOVIES' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_MOVIES_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			elif 'SERIES' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_SERIES_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			else: EVfiWGwHpCReXt4x3PU7cMmyhBJ = True
			aaH5voLOlVU8F['VOD_ORIGINAL_GROUPED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
		else: EVfiWGwHpCReXt4x3PU7cMmyhBJ = True
		if EVfiWGwHpCReXt4x3PU7cMmyhBJ: ME9eavOwmHNguFlL.append(QwzsWf9dISmA0eMxr2G)
		GWv6itIHy0RUwgQzxbMN += 1
	uypTh5gjEmkGSNPo2QeJZYRiFM = sorted(gLoId1uPvFDK,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU['title'].lower())
	del gLoId1uPvFDK
	VVLvyiKDt0eoW = str(bsr1VEvZf7wR)
	GWv6itIHy0RUwgQzxbMN = 0
	for QwzsWf9dISmA0eMxr2G in uypTh5gjEmkGSNPo2QeJZYRiFM:
		GWv6itIHy0RUwgQzxbMN += 1
		if GWv6itIHy0RUwgQzxbMN%873==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,55+int(5*GWv6itIHy0RUwgQzxbMN/bsr1VEvZf7wR),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(GWv6itIHy0RUwgQzxbMN)+' / '+VVLvyiKDt0eoW)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return None,None
		PcwEmo0dXj7vu8zypFefxDMr = QwzsWf9dISmA0eMxr2G['type']
		L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF = QwzsWf9dISmA0eMxr2G['group'],QwzsWf9dISmA0eMxr2G['context'],QwzsWf9dISmA0eMxr2G['title'],QwzsWf9dISmA0eMxr2G['url'],QwzsWf9dISmA0eMxr2G['img']
		HdmksvabBKMuS,oit8rylYd3Q6ReqxHDOU2vXsgA = QwzsWf9dISmA0eMxr2G['country'],QwzsWf9dISmA0eMxr2G['language']
		OO0R75zfjaSAEVGyYtpe6kK = (L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV+'_TIMESHIFT',hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		u5g2qtGyeaocXSp4Mn = (L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		Q8wpZlFh0NzC = (HdmksvabBKMuS,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		mrBwnbvZVGSahquMf7PE3yXCt = (oit8rylYd3Q6ReqxHDOU2vXsgA,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF)
		if 'LIVE' in PcwEmo0dXj7vu8zypFefxDMr:
			if 'UNKNOWN' in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_UNKNOWN_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			else: aaH5voLOlVU8F['LIVE_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			if 'EPG'		in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_EPG_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			if 'ARCHIVED'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_ARCHIVED_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			if 'ARCHIVED'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['LIVE_TIMESHIFT_GROUPED_SORTED_'+dZSIYCvz3jfL].append(OO0R75zfjaSAEVGyYtpe6kK)
			aaH5voLOlVU8F['LIVE_FROM_NAME_SORTED_'+dZSIYCvz3jfL].append(Q8wpZlFh0NzC)
			aaH5voLOlVU8F['LIVE_FROM_GROUP_SORTED_'+dZSIYCvz3jfL].append(mrBwnbvZVGSahquMf7PE3yXCt)
		elif 'VOD' in PcwEmo0dXj7vu8zypFefxDMr:
			if   'UNKNOWN'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_UNKNOWN_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			elif 'MOVIES'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_MOVIES_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			elif 'SERIES'	in PcwEmo0dXj7vu8zypFefxDMr: aaH5voLOlVU8F['VOD_SERIES_GROUPED_SORTED_'+dZSIYCvz3jfL].append(u5g2qtGyeaocXSp4Mn)
			aaH5voLOlVU8F['VOD_FROM_NAME_SORTED_'+dZSIYCvz3jfL].append(Q8wpZlFh0NzC)
			aaH5voLOlVU8F['VOD_FROM_GROUP_SORTED_'+dZSIYCvz3jfL].append(mrBwnbvZVGSahquMf7PE3yXCt)
	return aaH5voLOlVU8F,ME9eavOwmHNguFlL
def I79o6neSfOlXmL(hgE9MlmDou):
	if len(hgE9MlmDou)<3: return hgE9MlmDou,hgE9MlmDou
	TsH70GYWil9bp3MCEXQc,CuF4Ef9vHh15ULo68rJmxyAbnW = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	qF1gt9sVAvQOpUHBR6rLfx0X = hgE9MlmDou
	NBAPne0hvwuSM6L32ot7Jrmdbq = hgE9MlmDou[:1]
	XX3juewvVBR2iQg8lnGHP = hgE9MlmDou[1:]
	if   NBAPne0hvwuSM6L32ot7Jrmdbq=='(': CuF4Ef9vHh15ULo68rJmxyAbnW = ')'
	elif NBAPne0hvwuSM6L32ot7Jrmdbq=='[': CuF4Ef9vHh15ULo68rJmxyAbnW = ']'
	elif NBAPne0hvwuSM6L32ot7Jrmdbq=='<': CuF4Ef9vHh15ULo68rJmxyAbnW = '>'
	elif NBAPne0hvwuSM6L32ot7Jrmdbq=='|': CuF4Ef9vHh15ULo68rJmxyAbnW = '|'
	if CuF4Ef9vHh15ULo68rJmxyAbnW and (CuF4Ef9vHh15ULo68rJmxyAbnW in XX3juewvVBR2iQg8lnGHP):
		urfMB9ZIJX8e1kWibaNoEd,EXbh38gFq1wJoVRvckO0Mi = XX3juewvVBR2iQg8lnGHP.split(CuF4Ef9vHh15ULo68rJmxyAbnW,1)
		TsH70GYWil9bp3MCEXQc = urfMB9ZIJX8e1kWibaNoEd
		qF1gt9sVAvQOpUHBR6rLfx0X = NBAPne0hvwuSM6L32ot7Jrmdbq+urfMB9ZIJX8e1kWibaNoEd+CuF4Ef9vHh15ULo68rJmxyAbnW+avcfIls8w7gk69hYUErHxzQTXtm24j+EXbh38gFq1wJoVRvckO0Mi
	elif hgE9MlmDou.count('|')>=2:
		urfMB9ZIJX8e1kWibaNoEd,EXbh38gFq1wJoVRvckO0Mi = hgE9MlmDou.split('|',1)
		TsH70GYWil9bp3MCEXQc = urfMB9ZIJX8e1kWibaNoEd
		qF1gt9sVAvQOpUHBR6rLfx0X = urfMB9ZIJX8e1kWibaNoEd+' |'+EXbh38gFq1wJoVRvckO0Mi
	else:
		CuF4Ef9vHh15ULo68rJmxyAbnW = cBawilJXvK1m.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
		if not CuF4Ef9vHh15ULo68rJmxyAbnW: CuF4Ef9vHh15ULo68rJmxyAbnW = cBawilJXvK1m.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
		if not CuF4Ef9vHh15ULo68rJmxyAbnW: CuF4Ef9vHh15ULo68rJmxyAbnW = cBawilJXvK1m.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',hgE9MlmDou,cBawilJXvK1m.DOTALL)
		if CuF4Ef9vHh15ULo68rJmxyAbnW:
			urfMB9ZIJX8e1kWibaNoEd,EXbh38gFq1wJoVRvckO0Mi = hgE9MlmDou.split(CuF4Ef9vHh15ULo68rJmxyAbnW[0],1)
			TsH70GYWil9bp3MCEXQc = urfMB9ZIJX8e1kWibaNoEd
			qF1gt9sVAvQOpUHBR6rLfx0X = urfMB9ZIJX8e1kWibaNoEd+avcfIls8w7gk69hYUErHxzQTXtm24j+CuF4Ef9vHh15ULo68rJmxyAbnW[0]+avcfIls8w7gk69hYUErHxzQTXtm24j+EXbh38gFq1wJoVRvckO0Mi
	qF1gt9sVAvQOpUHBR6rLfx0X = qF1gt9sVAvQOpUHBR6rLfx0X.replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	TsH70GYWil9bp3MCEXQc = TsH70GYWil9bp3MCEXQc.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	if not TsH70GYWil9bp3MCEXQc: TsH70GYWil9bp3MCEXQc = '!!__UNKNOWN__!!'
	TsH70GYWil9bp3MCEXQc = TsH70GYWil9bp3MCEXQc.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	qF1gt9sVAvQOpUHBR6rLfx0X = qF1gt9sVAvQOpUHBR6rLfx0X.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	return TsH70GYWil9bp3MCEXQc,qF1gt9sVAvQOpUHBR6rLfx0X
def vIQ4kMWTHsP2N(C47G3hXaRMFLfOAEpV):
	bJ4IumHdZTPlG6 = {}
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV)
	if dCKxX4PEzlZ6bNO7aB1nYqQLv835o: bJ4IumHdZTPlG6['User-Agent'] = dCKxX4PEzlZ6bNO7aB1nYqQLv835o
	T4JSyRP1bD25NGq8lOc7XhkA0iudt = MoO74hKeqm8fFka.getSetting('av.m3u.referer_'+C47G3hXaRMFLfOAEpV)
	if T4JSyRP1bD25NGq8lOc7XhkA0iudt: bJ4IumHdZTPlG6['Referer'] = T4JSyRP1bD25NGq8lOc7XhkA0iudt
	return bJ4IumHdZTPlG6
def IIXfKPZEkUOFwLR4mxQ05jnH(C47G3hXaRMFLfOAEpV,dZSIYCvz3jfL):
	global OiFse6HmrT1Iga9D0XwMfR,aaH5voLOlVU8F,k8zbSQC9Hy,EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG,wAUgWxSDf75O6eyvkVRj8KFnc
	JIR9i57ld1yOUPcjzVv = MoO74hKeqm8fFka.getSetting('av.m3u.url_'+C47G3hXaRMFLfOAEpV+'_'+dZSIYCvz3jfL)
	dCKxX4PEzlZ6bNO7aB1nYqQLv835o = MoO74hKeqm8fFka.getSetting('av.m3u.useragent_'+C47G3hXaRMFLfOAEpV)
	bJ4IumHdZTPlG6 = {'User-Agent':dCKxX4PEzlZ6bNO7aB1nYqQLv835o}
	YYx8Ik4ETmW = zzxr5UY1CkyZG48A9NEPFHhKTD6wc.replace('___','_'+C47G3hXaRMFLfOAEpV+'_'+dZSIYCvz3jfL)
	if 1:
		UUQjG45NHzSqZuDe2vYIdTMlJOyc,sVvnE3SLxqUc2iQ1dNe,sVNw9Jv7gtH5aC4QjcWAYUM = True,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
		if not UUQjG45NHzSqZuDe2vYIdTMlJOyc:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not JIR9i57ld1yOUPcjzVv: vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+'   No M3U URL found to download M3U files')
			else: vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(FO8SKWr40dDexHgbfRUGBi)+'   Failed to download M3U files')
			return
		UbmXqGrFh9wPWxaTD80ysegdQut = L7IPyDUvXQwA2e9fChNruZcYM50(JIR9i57ld1yOUPcjzVv,bJ4IumHdZTPlG6,True)
		if not UbmXqGrFh9wPWxaTD80ysegdQut: return
		open(YYx8Ik4ETmW,'wb').write(UbmXqGrFh9wPWxaTD80ysegdQut)
	else: UbmXqGrFh9wPWxaTD80ysegdQut = open(YYx8Ik4ETmW,'rb').read()
	if WHjh1POtMKlmgiy68RSqb and UbmXqGrFh9wPWxaTD80ysegdQut: UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.decode(m6PFtLblInpNZ8x)
	OiFse6HmrT1Iga9D0XwMfR = R62V7GXNPvf8()
	OiFse6HmrT1Iga9D0XwMfR.create('جلب ملفات M3U جديدة',eHdDoxhJCEPMZFVa2fg)
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,15,'تنظيف الملف الرئيسي',eHdDoxhJCEPMZFVa2fg)
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('"tvg-','" tvg-')
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('َ',eHdDoxhJCEPMZFVa2fg).replace('ً',eHdDoxhJCEPMZFVa2fg).replace('ُ',eHdDoxhJCEPMZFVa2fg).replace('ٌ',eHdDoxhJCEPMZFVa2fg)
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('ّ',eHdDoxhJCEPMZFVa2fg).replace('ِ',eHdDoxhJCEPMZFVa2fg).replace('ٍ',eHdDoxhJCEPMZFVa2fg).replace('ْ',eHdDoxhJCEPMZFVa2fg)
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace('group-title=','group=').replace('tvg-',eHdDoxhJCEPMZFVa2fg)
	wPnNdxH34ZaC0mOlGsf,ult1ETRQCWc7dILqY4eDVF9wikx3h = [],[]
	UbmXqGrFh9wPWxaTD80ysegdQut = UbmXqGrFh9wPWxaTD80ysegdQut.replace(y1fVB2E63aLnJgkWeCZHujY,kDUv7ouWrcgMe6OipQJm)
	xp7ejmzyYGO9ShDsid6RZ = cBawilJXvK1m.findall('NF:(.+?)'+'#'+'EXTI',UbmXqGrFh9wPWxaTD80ysegdQut+'\n+'+'#'+'EXTINF:',cBawilJXvK1m.DOTALL)
	if not xp7ejmzyYGO9ShDsid6RZ:
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(FO8SKWr40dDexHgbfRUGBi)+'   Folder:'+C47G3hXaRMFLfOAEpV+'  Sequence:'+dZSIYCvz3jfL+'   No video links found in M3U file')
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+'مجلد رقم '+C47G3hXaRMFLfOAEpV+'      رابط رقم '+dZSIYCvz3jfL+Nat0Dx9puRUWCsgz6JyFhY3)
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	uumEKnHI2SDRTZx4 = []
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		SzCEBbNDsAXcpa83fgJo6vQ1TOZ74U = KyujWR9edp0HVxJ.lower()
		if 'adult' in SzCEBbNDsAXcpa83fgJo6vQ1TOZ74U: continue
		if 'xxx' in SzCEBbNDsAXcpa83fgJo6vQ1TOZ74U: continue
		uumEKnHI2SDRTZx4.append(KyujWR9edp0HVxJ)
	xp7ejmzyYGO9ShDsid6RZ = uumEKnHI2SDRTZx4
	del uumEKnHI2SDRTZx4
	if 'iptv-org' in JIR9i57ld1yOUPcjzVv:
		uumEKnHI2SDRTZx4,ccna6s18WuQwJTriSdCN = [],[]
		for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
			E2ELD9hkvJfmeOo075IS1 = cBawilJXvK1m.findall('group="(.*?)"',KyujWR9edp0HVxJ,cBawilJXvK1m.DOTALL)
			if E2ELD9hkvJfmeOo075IS1:
				E2ELD9hkvJfmeOo075IS1 = E2ELD9hkvJfmeOo075IS1[0]
				ggorpqK2ea = E2ELD9hkvJfmeOo075IS1.split(';')
				if 'region' in JIR9i57ld1yOUPcjzVv: DezUrSO94taMjhI35W = '1_'
				elif 'category' in JIR9i57ld1yOUPcjzVv: DezUrSO94taMjhI35W = '2_'
				elif 'language' in JIR9i57ld1yOUPcjzVv: DezUrSO94taMjhI35W = '3_'
				elif 'country' in JIR9i57ld1yOUPcjzVv: DezUrSO94taMjhI35W = '4_'
				else: DezUrSO94taMjhI35W = '5_'
				nNdw3EMAmfOVDgG0Iqx9orR1zHUt = KyujWR9edp0HVxJ.replace('group="'+E2ELD9hkvJfmeOo075IS1+'"','group="'+DezUrSO94taMjhI35W+'~[COLOR FFC89008] ===== ===== ===== [/COLOR]'+'"')
				uumEKnHI2SDRTZx4.append(nNdw3EMAmfOVDgG0Iqx9orR1zHUt)
				for L5DdYNZBtexX29zGHgQVoCiEJ in ggorpqK2ea:
					nNdw3EMAmfOVDgG0Iqx9orR1zHUt = KyujWR9edp0HVxJ.replace('group="'+E2ELD9hkvJfmeOo075IS1+'"','group="'+DezUrSO94taMjhI35W+L5DdYNZBtexX29zGHgQVoCiEJ+'"')
					uumEKnHI2SDRTZx4.append(nNdw3EMAmfOVDgG0Iqx9orR1zHUt)
			else: uumEKnHI2SDRTZx4.append(KyujWR9edp0HVxJ)
		xp7ejmzyYGO9ShDsid6RZ = uumEKnHI2SDRTZx4
		del uumEKnHI2SDRTZx4,ccna6s18WuQwJTriSdCN
	KNTh6j0Zz7JysSbq8vYHAg = 1024*1024
	HCqy9hx1AjMb = 1+len(UbmXqGrFh9wPWxaTD80ysegdQut)//KNTh6j0Zz7JysSbq8vYHAg//10
	del UbmXqGrFh9wPWxaTD80ysegdQut
	kHo1zyqQnOXeKYBvVf = len(xp7ejmzyYGO9ShDsid6RZ)
	ccna6s18WuQwJTriSdCN = OyNBvcZVXKnLsJbupPQzm0rAES6g7(xp7ejmzyYGO9ShDsid6RZ,HCqy9hx1AjMb)
	del xp7ejmzyYGO9ShDsid6RZ
	for eMVgaSfkty1AwQT6Obo in range(HCqy9hx1AjMb):
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,35+int(5*eMVgaSfkty1AwQT6Obo/HCqy9hx1AjMb),'تقطيع الملف الرئيسي','الجزء رقم:-',str(eMVgaSfkty1AwQT6Obo+1)+' / '+str(HCqy9hx1AjMb))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		cn4JlBthS58RGbNVkzLWgyfjI0q = str(ccna6s18WuQwJTriSdCN[eMVgaSfkty1AwQT6Obo])
		if WHjh1POtMKlmgiy68RSqb: cn4JlBthS58RGbNVkzLWgyfjI0q = cn4JlBthS58RGbNVkzLWgyfjI0q.encode(m6PFtLblInpNZ8x)
		open(YYx8Ik4ETmW+'.00'+str(eMVgaSfkty1AwQT6Obo),'wb').write(cn4JlBthS58RGbNVkzLWgyfjI0q)
	del ccna6s18WuQwJTriSdCN,cn4JlBthS58RGbNVkzLWgyfjI0q
	YAotNvdI7EQ,gLoId1uPvFDK,GWv6itIHy0RUwgQzxbMN = [],[],0
	for eMVgaSfkty1AwQT6Obo in range(HCqy9hx1AjMb):
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		cn4JlBthS58RGbNVkzLWgyfjI0q = open(YYx8Ik4ETmW+'.00'+str(eMVgaSfkty1AwQT6Obo),'rb').read()
		b8bLFaejUB.sleep(1)
		try: RRydns1CErYlIhwSx7.remove(YYx8Ik4ETmW+'.00'+str(eMVgaSfkty1AwQT6Obo))
		except: pass
		if WHjh1POtMKlmgiy68RSqb: cn4JlBthS58RGbNVkzLWgyfjI0q = cn4JlBthS58RGbNVkzLWgyfjI0q.decode(m6PFtLblInpNZ8x)
		LDByuEM3xXdFfvQAz = DIpuHqsKGS3ErJvk9taCRiX80('list',cn4JlBthS58RGbNVkzLWgyfjI0q)
		del cn4JlBthS58RGbNVkzLWgyfjI0q
		KcogByxTmuNDInYwXALarEjUli7eOR,GWv6itIHy0RUwgQzxbMN,ME9eavOwmHNguFlL = OOUVS5wbcN(LDByuEM3xXdFfvQAz,ult1ETRQCWc7dILqY4eDVF9wikx3h,wPnNdxH34ZaC0mOlGsf,OiFse6HmrT1Iga9D0XwMfR,kHo1zyqQnOXeKYBvVf,GWv6itIHy0RUwgQzxbMN,JIR9i57ld1yOUPcjzVv)
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		if not KcogByxTmuNDInYwXALarEjUli7eOR:
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
		gLoId1uPvFDK += KcogByxTmuNDInYwXALarEjUli7eOR
		YAotNvdI7EQ += ME9eavOwmHNguFlL
	del LDByuEM3xXdFfvQAz,KcogByxTmuNDInYwXALarEjUli7eOR
	aaH5voLOlVU8F,ME9eavOwmHNguFlL = l1dv7FkD8BN0Ay32KMGaiTfW4uJ(gLoId1uPvFDK,OiFse6HmrT1Iga9D0XwMfR,dZSIYCvz3jfL)
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
		OiFse6HmrT1Iga9D0XwMfR.close()
		return
	YAotNvdI7EQ += ME9eavOwmHNguFlL
	del gLoId1uPvFDK,ME9eavOwmHNguFlL
	EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG = {},{},{},0,0
	npBKIJvWu7dtoaOMEHGFzqQc32 = list(aaH5voLOlVU8F.keys())
	wAUgWxSDf75O6eyvkVRj8KFnc = len(npBKIJvWu7dtoaOMEHGFzqQc32)*3
	if 1:
		dWpNKnGlcgOzVHm6CU7texM4u = {}
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr] = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=XMWRpq7Zo1IQrDVmCdKncUT9xawHgh,args=(PiD9gwCG7zxRHVKkaeldoUbZr,))
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].start()
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].join()
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
	else:
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			XMWRpq7Zo1IQrDVmCdKncUT9xawHgh(PiD9gwCG7zxRHVKkaeldoUbZr)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return
	wAYOZDQ2dPyL9GW14HBa0ImT(C47G3hXaRMFLfOAEpV,dZSIYCvz3jfL,False)
	npBKIJvWu7dtoaOMEHGFzqQc32 = list(EVtvDQNMeaWTjYrfc.keys())
	k8zbSQC9Hy = 0
	if 1:
		dWpNKnGlcgOzVHm6CU7texM4u = {}
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr] = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=l8C3RMLkBVaNdOX,args=(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr))
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].start()
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			dWpNKnGlcgOzVHm6CU7texM4u[PiD9gwCG7zxRHVKkaeldoUbZr].join()
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
			OiFse6HmrT1Iga9D0XwMfR.close()
			return
	else:
		for PiD9gwCG7zxRHVKkaeldoUbZr in npBKIJvWu7dtoaOMEHGFzqQc32:
			l8C3RMLkBVaNdOX(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return
	eMVgaSfkty1AwQT6Obo = 0
	eesaApIdPixtmo84 = len(YAotNvdI7EQ)
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'IGNORED')
	for DEQjoMf425u in YAotNvdI7EQ:
		if eMVgaSfkty1AwQT6Obo%27==0:
			evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,95+int(5*eMVgaSfkty1AwQT6Obo//eesaApIdPixtmo84),'تخزين المهملة','الفيديو رقم:-',str(eMVgaSfkty1AwQT6Obo)+' / '+str(eesaApIdPixtmo84))
			if OiFse6HmrT1Iga9D0XwMfR.iscanceled():
				OiFse6HmrT1Iga9D0XwMfR.close()
				return
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'IGNORED_'+dZSIYCvz3jfL,str(DEQjoMf425u),eHdDoxhJCEPMZFVa2fg,ICRfWub2vqlor0Q)
		eMVgaSfkty1AwQT6Obo += 1
	CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'IGNORED_'+dZSIYCvz3jfL,'__COUNT__',str(eesaApIdPixtmo84),ICRfWub2vqlor0Q)
	OiFse6HmrT1Iga9D0XwMfR.close()
	b8bLFaejUB.sleep(1)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	return
def XMWRpq7Zo1IQrDVmCdKncUT9xawHgh(PiD9gwCG7zxRHVKkaeldoUbZr):
	global OiFse6HmrT1Iga9D0XwMfR,aaH5voLOlVU8F,k8zbSQC9Hy,EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG,wAUgWxSDf75O6eyvkVRj8KFnc
	EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr] = {}
	NYnyxQmgDj5olfO,mWI4dnz0eLRfvSOwPcTNlxFi = {},[]
	cciVhzZTlebn3gJ0LRd8PsQxMr = len(aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr])
	EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr]['__COUNT__'] = cciVhzZTlebn3gJ0LRd8PsQxMr
	if cciVhzZTlebn3gJ0LRd8PsQxMr>0:
		XdpkxWuNMV,GdVXLWH1FCx,XH21YrVwGz7JBim0o,sCdaDQGUPubiWqcZ12IHJNOVmpRn,JKS31UGHTnPC0fOAFIR6vwikobMsmu = zip(*aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr])
		del GdVXLWH1FCx,XH21YrVwGz7JBim0o,sCdaDQGUPubiWqcZ12IHJNOVmpRn
		ggorpqK2ea = list(set(XdpkxWuNMV))
		for L5DdYNZBtexX29zGHgQVoCiEJ in ggorpqK2ea:
			NYnyxQmgDj5olfO[L5DdYNZBtexX29zGHgQVoCiEJ] = eHdDoxhJCEPMZFVa2fg
			EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr][L5DdYNZBtexX29zGHgQVoCiEJ] = []
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,60+int(15*bb0VqFsOEBAIjG//wAUgWxSDf75O6eyvkVRj8KFnc),'تصنيع القوائم','الجزء رقم:-',str(bb0VqFsOEBAIjG)+' / '+str(wAUgWxSDf75O6eyvkVRj8KFnc))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
		bb0VqFsOEBAIjG += 1
		Xy4EgaIKekwGYFphn8 = len(ggorpqK2ea)
		del ggorpqK2ea
		mWI4dnz0eLRfvSOwPcTNlxFi = list(set(zip(XdpkxWuNMV,JKS31UGHTnPC0fOAFIR6vwikobMsmu)))
		del XdpkxWuNMV,JKS31UGHTnPC0fOAFIR6vwikobMsmu
		for L5DdYNZBtexX29zGHgQVoCiEJ,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV in mWI4dnz0eLRfvSOwPcTNlxFi:
			if not NYnyxQmgDj5olfO[L5DdYNZBtexX29zGHgQVoCiEJ] and Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV: NYnyxQmgDj5olfO[L5DdYNZBtexX29zGHgQVoCiEJ] = Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,60+int(15*bb0VqFsOEBAIjG//wAUgWxSDf75O6eyvkVRj8KFnc),'تصنيع القوائم','الجزء رقم:-',str(bb0VqFsOEBAIjG)+' / '+str(wAUgWxSDf75O6eyvkVRj8KFnc))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
		bb0VqFsOEBAIjG += 1
		UfOnBo6t5LcwvD23 = list(NYnyxQmgDj5olfO.keys())
		vg1CXkFzB5IZe = list(NYnyxQmgDj5olfO.values())
		del NYnyxQmgDj5olfO
		mWI4dnz0eLRfvSOwPcTNlxFi = list(zip(UfOnBo6t5LcwvD23,vg1CXkFzB5IZe))
		del UfOnBo6t5LcwvD23,vg1CXkFzB5IZe
		mWI4dnz0eLRfvSOwPcTNlxFi = sorted(mWI4dnz0eLRfvSOwPcTNlxFi)
	else: bb0VqFsOEBAIjG += 2
	EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr]['__GROUPS__'] = mWI4dnz0eLRfvSOwPcTNlxFi
	del mWI4dnz0eLRfvSOwPcTNlxFi
	for L5DdYNZBtexX29zGHgQVoCiEJ,GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr]:
		EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr][L5DdYNZBtexX29zGHgQVoCiEJ].append((GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF))
	evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,60+int(15*bb0VqFsOEBAIjG//wAUgWxSDf75O6eyvkVRj8KFnc),'تصنيع القوائم','الجزء رقم:-',str(bb0VqFsOEBAIjG)+' / '+str(wAUgWxSDf75O6eyvkVRj8KFnc))
	if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
	bb0VqFsOEBAIjG += 1
	del aaH5voLOlVU8F[PiD9gwCG7zxRHVKkaeldoUbZr]
	E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr] = list(EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr].keys())
	erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr] = len(E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr])
	bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j += erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr]
	return
def l8C3RMLkBVaNdOX(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr):
	global OiFse6HmrT1Iga9D0XwMfR,aaH5voLOlVU8F,k8zbSQC9Hy,EVtvDQNMeaWTjYrfc,erJHjDyKhNGIVZz59nuMAQLo0S1i7B,E2ELD9hkvJfmeOo075IS1,bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j,bb0VqFsOEBAIjG,wAUgWxSDf75O6eyvkVRj8KFnc
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr)
	for GWv6itIHy0RUwgQzxbMN in range(1+erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr]//273):
		TpLkUNGBs9q = []
		zzstBhr73YXEqRVH0UZDg = E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr][0:273]
		for L5DdYNZBtexX29zGHgQVoCiEJ in zzstBhr73YXEqRVH0UZDg:
			TpLkUNGBs9q.append(EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr][L5DdYNZBtexX29zGHgQVoCiEJ])
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,PiD9gwCG7zxRHVKkaeldoUbZr,zzstBhr73YXEqRVH0UZDg,TpLkUNGBs9q,ICRfWub2vqlor0Q,True)
		k8zbSQC9Hy += len(zzstBhr73YXEqRVH0UZDg)
		evP9UQfyEcG5hBwVzl(OiFse6HmrT1Iga9D0XwMfR,75+int(20*k8zbSQC9Hy//bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j),'تخزين القوائم','القائمة رقم:-',str(k8zbSQC9Hy)+' / '+str(bWwmc1R8Ohufn2dlyYBaxrQ9DkHT6j))
		if OiFse6HmrT1Iga9D0XwMfR.iscanceled(): return
		del E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr][0:273]
	del EVtvDQNMeaWTjYrfc[PiD9gwCG7zxRHVKkaeldoUbZr],E2ELD9hkvJfmeOo075IS1[PiD9gwCG7zxRHVKkaeldoUbZr],erJHjDyKhNGIVZz59nuMAQLo0S1i7B[PiD9gwCG7zxRHVKkaeldoUbZr]
	return
def Z64SKTPMIHg9YX(C47G3hXaRMFLfOAEpV,dZSIYCvz3jfL,UzF4sIShoZEgRjc7LK8w=True):
	Vs8fbBNJaykLqQvg1Y5IFoGWj6d0 = 'عدد فيديوهات جميع الروابط'
	f0fp9q1PHnwTjraIxBC5c7d = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'LIVE_ORIGINAL_GROUPED')
	bWnMG2tvludPcH = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'VOD_ORIGINAL_GROUPED')
	if dZSIYCvz3jfL:
		Vs8fbBNJaykLqQvg1Y5IFoGWj6d0 = 'عدد فيديوهات رابط '+Fv7ouzCZdqTc95fJKBXA[int(dZSIYCvz3jfL)]
		dZSIYCvz3jfL = '_'+dZSIYCvz3jfL
	eesaApIdPixtmo84 = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','IGNORED'+dZSIYCvz3jfL,'__COUNT__')
	bBsVrfxLyMK2ia3gX = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','LIVE_ORIGINAL_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	oQp0jiDc9WPbHnL7f8rtkFG4yMZ = EeZHTwQUW2BuvJyIh(bWnMG2tvludPcH,'int','VOD_ORIGINAL_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	KbUCLf2FYW0 = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','LIVE_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	gNC246pFbMUJGP1KOzwVDkmEZ = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','LIVE_UNKNOWN_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	LLo7SuZ9JbXE3nxPY2DWVAq = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','VOD_MOVIES_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	DXjEwvTW9UJgnQ = EeZHTwQUW2BuvJyIh(bWnMG2tvludPcH,'int','VOD_SERIES_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	dO2VQ4ixR76HrqUIBSsfJuozF = EeZHTwQUW2BuvJyIh(f0fp9q1PHnwTjraIxBC5c7d,'int','VOD_UNKNOWN_GROUPED'+dZSIYCvz3jfL,'__COUNT__')
	E2ELD9hkvJfmeOo075IS1 = EeZHTwQUW2BuvJyIh(bWnMG2tvludPcH,'list','VOD_SERIES_GROUPED'+dZSIYCvz3jfL,'__GROUPS__')
	wwbYcPyiLgGH8kIUzZ = []
	for L5DdYNZBtexX29zGHgQVoCiEJ,Ufd6obSCcXF in E2ELD9hkvJfmeOo075IS1:
		GGA495Cqbj = L5DdYNZBtexX29zGHgQVoCiEJ.split('__SERIES__')[1]
		wwbYcPyiLgGH8kIUzZ.append(GGA495Cqbj)
	BJ2hqwH93uKI = len(wwbYcPyiLgGH8kIUzZ)
	RVOyUD2s8Bk9FLCwu4MSKJgt = int(LLo7SuZ9JbXE3nxPY2DWVAq)+int(DXjEwvTW9UJgnQ)+int(dO2VQ4ixR76HrqUIBSsfJuozF)+int(gNC246pFbMUJGP1KOzwVDkmEZ)+int(KbUCLf2FYW0)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY = eHdDoxhJCEPMZFVa2fg
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += 'قنوات: '+str(KbUCLf2FYW0)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   أفلام: '+str(LLo7SuZ9JbXE3nxPY2DWVAq)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\nمسلسلات: '+str(BJ2hqwH93uKI)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   حلقات: '+str(DXjEwvTW9UJgnQ)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\nقنوات مجهولة: '+str(gNC246pFbMUJGP1KOzwVDkmEZ)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   فيدوهات مجهولة: '+str(dO2VQ4ixR76HrqUIBSsfJuozF)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\nمجموع القنوات: '+str(bBsVrfxLyMK2ia3gX)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   مجموع الفيديوهات: '+str(oQp0jiDc9WPbHnL7f8rtkFG4yMZ)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '\n\nمجموع المضافة: '+str(RVOyUD2s8Bk9FLCwu4MSKJgt)
	NTtEhHMqpnBZwWguVLab7l2x8KRiY += '   .   مجموع المهملة: '+str(eesaApIdPixtmo84)
	if UzF4sIShoZEgRjc7LK8w: dXINKZJp6Tbu7wmS('center',eHdDoxhJCEPMZFVa2fg,Vs8fbBNJaykLqQvg1Y5IFoGWj6d0,NTtEhHMqpnBZwWguVLab7l2x8KRiY)
	FAQoDZUr0CEYdO1eHXS5hLft8sGPKb = NTtEhHMqpnBZwWguVLab7l2x8KRiY.replace('\n\n',kDUv7ouWrcgMe6OipQJm)
	if not dZSIYCvz3jfL: dZSIYCvz3jfL = 'All'
	else: dZSIYCvz3jfL = dZSIYCvz3jfL[1]
	vR9cOpMtk51j(iwIlVQsgYezu,'.\tCounts of M3U videos   Folder: '+C47G3hXaRMFLfOAEpV+'   Sequence: '+dZSIYCvz3jfL+kDUv7ouWrcgMe6OipQJm+FAQoDZUr0CEYdO1eHXS5hLft8sGPKb)
	return NTtEhHMqpnBZwWguVLab7l2x8KRiY
def wAYOZDQ2dPyL9GW14HBa0ImT(C47G3hXaRMFLfOAEpV,dZSIYCvz3jfL,UzF4sIShoZEgRjc7LK8w=True):
	if UzF4sIShoZEgRjc7LK8w:
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if kMnoXVxN5byYJSzPrsu!=1: return
		zzPjQDgvuq = zzxr5UY1CkyZG48A9NEPFHhKTD6wc.replace('___','_'+C47G3hXaRMFLfOAEpV+'_'+dZSIYCvz3jfL)
		try: RRydns1CErYlIhwSx7.remove(zzPjQDgvuq)
		except: pass
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	if dZSIYCvz3jfL:
		vdxk1iFWq2EsNVmT5rK6 = []
		for wbVBXodaQk in ga2Cxd7Bulrb:
			vdxk1iFWq2EsNVmT5rK6.append(wbVBXodaQk+'_'+dZSIYCvz3jfL)
		k5L96NenKBwpSYWv(vXSV4tIkDzNC,'LINK_'+dZSIYCvz3jfL)
	else:
		vdxk1iFWq2EsNVmT5rK6 = ga2Cxd7Bulrb
		k5L96NenKBwpSYWv(vXSV4tIkDzNC,'DUMMY')
		k5L96NenKBwpSYWv(vXSV4tIkDzNC,'GROUPS')
		k5L96NenKBwpSYWv(vXSV4tIkDzNC,'ITEMS')
		k5L96NenKBwpSYWv(vXSV4tIkDzNC,'SEARCH')
	k5L96NenKBwpSYWv(pyifuNFdxe,'SECTIONS_M3U','SECTIONS_M3U_'+C47G3hXaRMFLfOAEpV)
	k5L96NenKBwpSYWv(pyifuNFdxe,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for PiD9gwCG7zxRHVKkaeldoUbZr in vdxk1iFWq2EsNVmT5rK6:
		k5L96NenKBwpSYWv(vXSV4tIkDzNC,PiD9gwCG7zxRHVKkaeldoUbZr)
	wJ0l2uCDMF8IiEzsvykhP(False)
	F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV)
	if UzF4sIShoZEgRjc7LK8w: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def ffdr02bStCnz(C47G3hXaRMFLfOAEpV=eHdDoxhJCEPMZFVa2fg,UzF4sIShoZEgRjc7LK8w=True):
	if C47G3hXaRMFLfOAEpV:
		vXSV4tIkDzNC = K0sLrB3qvJn9Edt(str(C47G3hXaRMFLfOAEpV),'DUMMY')
		bRaH8UFOVKAN1MBX3J05ynuGqjeIf = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'str','DUMMY','__DUMMY__')
		if bRaH8UFOVKAN1MBX3J05ynuGqjeIf: return True
	else:
		C47G3hXaRMFLfOAEpV = '1'
		for bb6cBW5yweZGvuXo0NQlM in range(1,II0HXSngDhlLOuNQ9Vi+1):
			vXSV4tIkDzNC = K0sLrB3qvJn9Edt(str(bb6cBW5yweZGvuXo0NQlM),'DUMMY')
			bRaH8UFOVKAN1MBX3J05ynuGqjeIf = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'str','DUMMY','__DUMMY__')
			if bRaH8UFOVKAN1MBX3J05ynuGqjeIf: return True
	if UzF4sIShoZEgRjc7LK8w:
		MtOmS3J8acLZYfbACknvDh = 'https://iptv-org.github.io/iptv/index.region.m3u'
		eoc7lXMPYRQKFID = 'https://iptv-org.github.io/iptv/index.category.m3u'
		ez5SA2oHrEN = 'https://iptv-org.github.io/iptv/index.language.m3u'
		QFZX084Er6NKYMsibaeGgH = 'https://iptv-org.github.io/iptv/index.country.m3u'
		Y3uIrHzbGQg5lFOJade0ESyBx6 = MtOmS3J8acLZYfbACknvDh+kDUv7ouWrcgMe6OipQJm+eoc7lXMPYRQKFID+kDUv7ouWrcgMe6OipQJm+ez5SA2oHrEN+kDUv7ouWrcgMe6OipQJm+QFZX084Er6NKYMsibaeGgH
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n [COLOR FFC89008]http://github.com/iptv-org/iptv[/COLOR]\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n [COLOR FFC89008]'+Y3uIrHzbGQg5lFOJade0ESyBx6+Nat0Dx9puRUWCsgz6JyFhY3,profile='confirm_mediumfont')
		if kMnoXVxN5byYJSzPrsu==1:
			MoO74hKeqm8fFka.setSetting('av.m3u.url_'+str(C47G3hXaRMFLfOAEpV)+'_1',MtOmS3J8acLZYfbACknvDh)
			MoO74hKeqm8fFka.setSetting('av.m3u.url_'+str(C47G3hXaRMFLfOAEpV)+'_2',eoc7lXMPYRQKFID)
			MoO74hKeqm8fFka.setSetting('av.m3u.url_'+str(C47G3hXaRMFLfOAEpV)+'_3',ez5SA2oHrEN)
			MoO74hKeqm8fFka.setSetting('av.m3u.url_'+str(C47G3hXaRMFLfOAEpV)+'_4',QFZX084Er6NKYMsibaeGgH)
			kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if kMnoXVxN5byYJSzPrsu==1:
				sabzYk3MRiu01l8vGK7UqJXD = rkzyXPstow(C47G3hXaRMFLfOAEpV)
				return sabzYk3MRiu01l8vGK7UqJXD
		else:
			Vs8fbBNJaykLqQvg1Y5IFoGWj6d0 = 'إضافة وتغيير رابط '+Fv7ouzCZdqTc95fJKBXA[1]+' (مجلد '+Fv7ouzCZdqTc95fJKBXA[int(C47G3hXaRMFLfOAEpV)]+')'
			kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Vs8fbBNJaykLqQvg1Y5IFoGWj6d0,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if kMnoXVxN5byYJSzPrsu==1: CCGFfNl9ruHDtn(C47G3hXaRMFLfOAEpV,'1')
	return False
def A1AxPpad9tTLBbeIiOSQs2yq87hFW(m0Qu6qaroU,C47G3hXaRMFLfOAEpV=eHdDoxhJCEPMZFVa2fg,PiD9gwCG7zxRHVKkaeldoUbZr=eHdDoxhJCEPMZFVa2fg,sxFw3Wz7DhVL=eHdDoxhJCEPMZFVa2fg):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	ZrzxY0D21f9ACB65S,j2TA4h0FekYb3a5B,UzF4sIShoZEgRjc7LK8w = F1T64yBoQa5b(m0Qu6qaroU)
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	if not ZrzxY0D21f9ACB65S:
		ZrzxY0D21f9ACB65S = mJ1lHWKUPcZGezML7X2u9S()
		if not ZrzxY0D21f9ACB65S: return
	Liao5DfByHKGuW = [eHdDoxhJCEPMZFVa2fg,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not PiD9gwCG7zxRHVKkaeldoUbZr:
		if not UzF4sIShoZEgRjc7LK8w:
			if   '_M3U-LIVE_' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[1]
			elif '_M3U-MOVIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[2]
			elif '_M3U-SERIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[3]
			else: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[0]
		else:
			hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			iL3sKTVC7EZgM9kDajU1FYGBqWrdc = ZZhzstQTSCXRg('أختر البحث المناسب', hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ)
			if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==-1: return
			PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[iL3sKTVC7EZgM9kDajU1FYGBqWrdc]
	ZrzxY0D21f9ACB65S = ZrzxY0D21f9ACB65S+'_NODIALOGS_'
	if C47G3hXaRMFLfOAEpV: dwS0voDrOHFbWN7TkJVRIfM(ZrzxY0D21f9ACB65S,C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr,sxFw3Wz7DhVL)
	else:
		for C47G3hXaRMFLfOAEpV in range(1,II0HXSngDhlLOuNQ9Vi+1):
			dwS0voDrOHFbWN7TkJVRIfM(ZrzxY0D21f9ACB65S,str(C47G3hXaRMFLfOAEpV),PiD9gwCG7zxRHVKkaeldoUbZr,sxFw3Wz7DhVL)
		JXSlk8x495HmgiD[:] = sorted(JXSlk8x495HmgiD,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[1].lower())
	return
def dwS0voDrOHFbWN7TkJVRIfM(m0Qu6qaroU,C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr=eHdDoxhJCEPMZFVa2fg,sxFw3Wz7DhVL=eHdDoxhJCEPMZFVa2fg):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	ZrzxY0D21f9ACB65S,j2TA4h0FekYb3a5B,UzF4sIShoZEgRjc7LK8w = F1T64yBoQa5b(m0Qu6qaroU)
	if not C47G3hXaRMFLfOAEpV: return
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w): return
	if not ZrzxY0D21f9ACB65S:
		ZrzxY0D21f9ACB65S = mJ1lHWKUPcZGezML7X2u9S()
		if not ZrzxY0D21f9ACB65S: return
	Liao5DfByHKGuW = [eHdDoxhJCEPMZFVa2fg,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not PiD9gwCG7zxRHVKkaeldoUbZr:
		if not UzF4sIShoZEgRjc7LK8w:
			if   '_M3U-LIVE_' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[1]
			elif '_M3U-MOVIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[2]
			elif '_M3U-SERIES' in j2TA4h0FekYb3a5B: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[3]
			else: PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[0]
		else:
			hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			iL3sKTVC7EZgM9kDajU1FYGBqWrdc = ZZhzstQTSCXRg('أختر البحث المناسب', hwWgpV1OXAJ2KdM8FTzjqEoek3uamQ)
			if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==-1: return
			PiD9gwCG7zxRHVKkaeldoUbZr = Liao5DfByHKGuW[iL3sKTVC7EZgM9kDajU1FYGBqWrdc]
	ef4gxwCU2PzmJsSYtbA5 = ZrzxY0D21f9ACB65S.lower()
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,'SEARCH')
	pGiyauNHUVlRTnP = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list','SEARCH',(PiD9gwCG7zxRHVKkaeldoUbZr,ef4gxwCU2PzmJsSYtbA5))
	if not pGiyauNHUVlRTnP:
		y8aJjOzEMdX,Inuo5YDT9b14cqeZJdVWKt860jE = [],[]
		if not PiD9gwCG7zxRHVKkaeldoUbZr: GKXgtfTnhRzHe0ZkJVdQ5ouE2y = [1,2,3,4,5]
		else: GKXgtfTnhRzHe0ZkJVdQ5ouE2y = [Liao5DfByHKGuW.index(PiD9gwCG7zxRHVKkaeldoUbZr)]
		for eMVgaSfkty1AwQT6Obo in GKXgtfTnhRzHe0ZkJVdQ5ouE2y:
			if eMVgaSfkty1AwQT6Obo!=3:
				KcogByxTmuNDInYwXALarEjUli7eOR = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'dict',Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo])
				del KcogByxTmuNDInYwXALarEjUli7eOR['__COUNT__']
				del KcogByxTmuNDInYwXALarEjUli7eOR['__GROUPS__']
				del KcogByxTmuNDInYwXALarEjUli7eOR['__SEQUENCED_COLUMNS__']
				E2ELD9hkvJfmeOo075IS1 = list(KcogByxTmuNDInYwXALarEjUli7eOR.keys())
				for L5DdYNZBtexX29zGHgQVoCiEJ in E2ELD9hkvJfmeOo075IS1:
					for GsPYQbREvLAFw3aJ5XghmV,hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in KcogByxTmuNDInYwXALarEjUli7eOR[L5DdYNZBtexX29zGHgQVoCiEJ]:
						if ef4gxwCU2PzmJsSYtbA5 in hgE9MlmDou.lower(): Inuo5YDT9b14cqeZJdVWKt860jE.append((hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF))
					del KcogByxTmuNDInYwXALarEjUli7eOR[L5DdYNZBtexX29zGHgQVoCiEJ]
				del KcogByxTmuNDInYwXALarEjUli7eOR
			else: E2ELD9hkvJfmeOo075IS1 = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'list',Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo],'__GROUPS__')
			for L5DdYNZBtexX29zGHgQVoCiEJ in E2ELD9hkvJfmeOo075IS1:
				try: L5DdYNZBtexX29zGHgQVoCiEJ,Ufd6obSCcXF = L5DdYNZBtexX29zGHgQVoCiEJ
				except: Ufd6obSCcXF = eHdDoxhJCEPMZFVa2fg
				if ef4gxwCU2PzmJsSYtbA5 in L5DdYNZBtexX29zGHgQVoCiEJ.lower():
					if eMVgaSfkty1AwQT6Obo!=3: Tc3yt7NQUCfpqb9ueB2HrO = L5DdYNZBtexX29zGHgQVoCiEJ
					else:
						RqP1jLcQ0Z7pik,XskPiv4uWLdOyohJZqgI6UC7 = L5DdYNZBtexX29zGHgQVoCiEJ.split('__SERIES__')
						if ef4gxwCU2PzmJsSYtbA5 in RqP1jLcQ0Z7pik.lower(): Tc3yt7NQUCfpqb9ueB2HrO = RqP1jLcQ0Z7pik
						else: Tc3yt7NQUCfpqb9ueB2HrO = XskPiv4uWLdOyohJZqgI6UC7
					y8aJjOzEMdX.append((L5DdYNZBtexX29zGHgQVoCiEJ,Tc3yt7NQUCfpqb9ueB2HrO,Liao5DfByHKGuW[eMVgaSfkty1AwQT6Obo],Ufd6obSCcXF))
			del E2ELD9hkvJfmeOo075IS1
		y8aJjOzEMdX = set(y8aJjOzEMdX)
		Inuo5YDT9b14cqeZJdVWKt860jE = set(Inuo5YDT9b14cqeZJdVWKt860jE)
		y8aJjOzEMdX = sorted(y8aJjOzEMdX,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[1])
		Inuo5YDT9b14cqeZJdVWKt860jE = sorted(Inuo5YDT9b14cqeZJdVWKt860jE,reverse=False,key=lambda ddmHpyREIePbf5wAU: ddmHpyREIePbf5wAU[0])
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'SEARCH',(PiD9gwCG7zxRHVKkaeldoUbZr,ef4gxwCU2PzmJsSYtbA5),(y8aJjOzEMdX,Inuo5YDT9b14cqeZJdVWKt860jE),ICRfWub2vqlor0Q)
	else: y8aJjOzEMdX,Inuo5YDT9b14cqeZJdVWKt860jE = pGiyauNHUVlRTnP
	E2ELD9hkvJfmeOo075IS1 = len(y8aJjOzEMdX)
	FFQP9MfNAi4IqcnvwZ = len(Inuo5YDT9b14cqeZJdVWKt860jE)
	d9c6BWV3J2bQDMRELgX = int(sxFw3Wz7DhVL)
	fH97sVgW5RJ6jxrChUqFz8Ymb = max(0,(d9c6BWV3J2bQDMRELgX-1)*100)
	NzgKbhHGdmEAZD = max(0,d9c6BWV3J2bQDMRELgX*100)
	Guk3tVX9l7wKJmy6c2bvS5N = max(0,fH97sVgW5RJ6jxrChUqFz8Ymb-E2ELD9hkvJfmeOo075IS1)
	rYsUwADyic2fTMZECmK = max(0,NzgKbhHGdmEAZD-E2ELD9hkvJfmeOo075IS1)
	for L5DdYNZBtexX29zGHgQVoCiEJ,Tc3yt7NQUCfpqb9ueB2HrO,PPNwoZhRrODFpXQVcKA,Ufd6obSCcXF in y8aJjOzEMdX[fH97sVgW5RJ6jxrChUqFz8Ymb:NzgKbhHGdmEAZD]:
		qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+Tc3yt7NQUCfpqb9ueB2HrO,PPNwoZhRrODFpXQVcKA,714,Ufd6obSCcXF,'1',L5DdYNZBtexX29zGHgQVoCiEJ,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	del y8aJjOzEMdX
	for hgE9MlmDou,Nn360bq79W2kzUt,Ufd6obSCcXF in Inuo5YDT9b14cqeZJdVWKt860jE[Guk3tVX9l7wKJmy6c2bvS5N:rYsUwADyic2fTMZECmK]:
		GBxY7Qljt3nUmeNwyg = llr1C3SIFjViqLDtZP(Nn360bq79W2kzUt)
		IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'live'
		if '.mkv' in GBxY7Qljt3nUmeNwyg or 'VOD' in PiD9gwCG7zxRHVKkaeldoUbZr: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = 'video'
		qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,pWmZEI8VqwO3eS5H1BizLCAy+hgE9MlmDou,Nn360bq79W2kzUt,715,Ufd6obSCcXF,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	del Inuo5YDT9b14cqeZJdVWKt860jE
	dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,719,E2ELD9hkvJfmeOo075IS1+FFQP9MfNAi4IqcnvwZ,ZrzxY0D21f9ACB65S+'_NODIALOGS_')
	return
def dCpDJKyatOq5AwvVo7iTY31lEBmMs(C47G3hXaRMFLfOAEpV,sxFw3Wz7DhVL,PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,RVOyUD2s8Bk9FLCwu4MSKJgt,bkA4Xjzw7mJa):
	if not sxFw3Wz7DhVL: sxFw3Wz7DhVL = '1'
	if sxFw3Wz7DhVL!='1': qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'صفحة '+str(1),PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,str(1),bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	if not RVOyUD2s8Bk9FLCwu4MSKJgt: RVOyUD2s8Bk9FLCwu4MSKJgt = 0
	aNbi0e4uvl6CrW8ZB7 = int(RVOyUD2s8Bk9FLCwu4MSKJgt/100)+1
	for d9c6BWV3J2bQDMRELgX in range(2,aNbi0e4uvl6CrW8ZB7):
		E2tAkO0pMVgD = (d9c6BWV3J2bQDMRELgX%10==0 or int(sxFw3Wz7DhVL)-4<d9c6BWV3J2bQDMRELgX<int(sxFw3Wz7DhVL)+4)
		res2HUZzg4opdqQai7KSGyctLBY0 = (E2tAkO0pMVgD and int(sxFw3Wz7DhVL)-40<d9c6BWV3J2bQDMRELgX<int(sxFw3Wz7DhVL)+40)
		if str(d9c6BWV3J2bQDMRELgX)!=sxFw3Wz7DhVL and (d9c6BWV3J2bQDMRELgX%100==0 or res2HUZzg4opdqQai7KSGyctLBY0):
			qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'صفحة '+str(d9c6BWV3J2bQDMRELgX),PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,str(d9c6BWV3J2bQDMRELgX),bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	if str(aNbi0e4uvl6CrW8ZB7)!=sxFw3Wz7DhVL: qfpnsHw19BiaSktcXWbGA('folder',pWmZEI8VqwO3eS5H1BizLCAy+'أخر صفحة '+str(aNbi0e4uvl6CrW8ZB7),PiD9gwCG7zxRHVKkaeldoUbZr,tWi3JH8rRhxcgnYuMVUK,eHdDoxhJCEPMZFVa2fg,str(aNbi0e4uvl6CrW8ZB7),bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,{'folder':C47G3hXaRMFLfOAEpV})
	return
def K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,PiD9gwCG7zxRHVKkaeldoUbZr):
	vXSV4tIkDzNC = X7DcIRbSTJPoeWvVfjMFi.replace('___','_'+C47G3hXaRMFLfOAEpV)
	return vXSV4tIkDzNC
def rkzyXPstow(C47G3hXaRMFLfOAEpV):
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if kMnoXVxN5byYJSzPrsu!=1: return False
	L3cBMQ4uyYzoJCvxrG(C47G3hXaRMFLfOAEpV,False)
	sZ3jCkmJIyMiXD2GLlf85SVEWc9Kn = [0]
	for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in range(1,hPjydHiuqQc75KFp+1):
		TWo6cYv7ZdHIqjFRDwaL = MoO74hKeqm8fFka.getSetting('av.m3u.url_'+C47G3hXaRMFLfOAEpV+'_'+str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
		if TWo6cYv7ZdHIqjFRDwaL: IIXfKPZEkUOFwLR4mxQ05jnH(C47G3hXaRMFLfOAEpV,str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
		sZ3jCkmJIyMiXD2GLlf85SVEWc9Kn.append(0)
	for PiD9gwCG7zxRHVKkaeldoUbZr in ga2Cxd7Bulrb:
		vTua7b4HqGYDy3,hnIiqeo5uPwGmUgNyD1pbHMJAEz,ddtrVDPwZHEGOMSqUc9,sNFQZ4bkOzWdwJ5TCjcUSB,NYnyxQmgDj5olfO = 0,{},[],[],[]
		for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in range(1,hPjydHiuqQc75KFp+1):
			PPNwoZhRrODFpXQVcKA = PiD9gwCG7zxRHVKkaeldoUbZr+'_'+str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2)
			aaH5voLOlVU8F = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'dict',PPNwoZhRrODFpXQVcKA)
			try:
				fRMkjOSgmUQPrX5I4KbCw6t = aaH5voLOlVU8F['__GROUPS__']
				czAy10w728nRUoaYfdNJPjStpq = aaH5voLOlVU8F['__COUNT__']
			except: fRMkjOSgmUQPrX5I4KbCw6t,czAy10w728nRUoaYfdNJPjStpq = [],'0'
			for ebFl3ZUd9cIHwgfnAJPzv28DsEYiB in fRMkjOSgmUQPrX5I4KbCw6t:
				L5DdYNZBtexX29zGHgQVoCiEJ,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV = ebFl3ZUd9cIHwgfnAJPzv28DsEYiB
				KcogByxTmuNDInYwXALarEjUli7eOR = aaH5voLOlVU8F[L5DdYNZBtexX29zGHgQVoCiEJ]
				if L5DdYNZBtexX29zGHgQVoCiEJ not in sNFQZ4bkOzWdwJ5TCjcUSB:
					sNFQZ4bkOzWdwJ5TCjcUSB.append(L5DdYNZBtexX29zGHgQVoCiEJ)
					NYnyxQmgDj5olfO.append(ebFl3ZUd9cIHwgfnAJPzv28DsEYiB)
					hnIiqeo5uPwGmUgNyD1pbHMJAEz[L5DdYNZBtexX29zGHgQVoCiEJ] = []
				hnIiqeo5uPwGmUgNyD1pbHMJAEz[L5DdYNZBtexX29zGHgQVoCiEJ] += KcogByxTmuNDInYwXALarEjUli7eOR
			k5L96NenKBwpSYWv(vXSV4tIkDzNC,PPNwoZhRrODFpXQVcKA)
			CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,PPNwoZhRrODFpXQVcKA,'__COUNT__',czAy10w728nRUoaYfdNJPjStpq,ICRfWub2vqlor0Q)
			sZ3jCkmJIyMiXD2GLlf85SVEWc9Kn[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] += int(czAy10w728nRUoaYfdNJPjStpq)
		for L5DdYNZBtexX29zGHgQVoCiEJ in sNFQZ4bkOzWdwJ5TCjcUSB:
			KcogByxTmuNDInYwXALarEjUli7eOR = list(set(hnIiqeo5uPwGmUgNyD1pbHMJAEz[L5DdYNZBtexX29zGHgQVoCiEJ]))
			if 'SORTED' in PiD9gwCG7zxRHVKkaeldoUbZr: KcogByxTmuNDInYwXALarEjUli7eOR = sorted(KcogByxTmuNDInYwXALarEjUli7eOR,reverse=False,key=lambda key: key[1].lower())
			vTua7b4HqGYDy3 += len(KcogByxTmuNDInYwXALarEjUli7eOR)
			ddtrVDPwZHEGOMSqUc9.append(KcogByxTmuNDInYwXALarEjUli7eOR)
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,PiD9gwCG7zxRHVKkaeldoUbZr,'__COUNT__',str(vTua7b4HqGYDy3),ICRfWub2vqlor0Q)
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,PiD9gwCG7zxRHVKkaeldoUbZr,'__GROUPS__',NYnyxQmgDj5olfO,ICRfWub2vqlor0Q)
		CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,PiD9gwCG7zxRHVKkaeldoUbZr,sNFQZ4bkOzWdwJ5TCjcUSB,ddtrVDPwZHEGOMSqUc9,ICRfWub2vqlor0Q,True)
	DN3p9FBn4kOI8tZGRePoESChwcH = False
	for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in range(1,hPjydHiuqQc75KFp+1):
		if int(sZ3jCkmJIyMiXD2GLlf85SVEWc9Kn[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2])>0:
			TWo6cYv7ZdHIqjFRDwaL = MoO74hKeqm8fFka.getSetting('av.m3u.url_'+C47G3hXaRMFLfOAEpV+'_'+str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
			CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'LINK_'+str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2),'__LINK__',TWo6cYv7ZdHIqjFRDwaL,ICRfWub2vqlor0Q)
			DN3p9FBn4kOI8tZGRePoESChwcH = True
	CbR3IdmoLYPcOqfuGNyWit6Xg(vXSV4tIkDzNC,'DUMMY','__DUMMY__','DUMMY',ICRfWub2vqlor0Q)
	if not DN3p9FBn4kOI8tZGRePoESChwcH:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	UUEtRXweFlzgISL1MGdTDHN(C47G3hXaRMFLfOAEpV)
	wJ0l2uCDMF8IiEzsvykhP(False)
	AOwqYZ30sN1Mp(False)
	return True
def UUEtRXweFlzgISL1MGdTDHN(C47G3hXaRMFLfOAEpV):
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	if not ffdr02bStCnz(C47G3hXaRMFLfOAEpV,True): return
	for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in range(1,hPjydHiuqQc75KFp+1):
		TWo6cYv7ZdHIqjFRDwaL = EeZHTwQUW2BuvJyIh(vXSV4tIkDzNC,'str','LINK_'+str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2),'__LINK__')
		if TWo6cYv7ZdHIqjFRDwaL: NTtEhHMqpnBZwWguVLab7l2x8KRiY = Z64SKTPMIHg9YX(C47G3hXaRMFLfOAEpV,str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
	Z64SKTPMIHg9YX(C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	return
def L3cBMQ4uyYzoJCvxrG(C47G3hXaRMFLfOAEpV,UzF4sIShoZEgRjc7LK8w):
	if UzF4sIShoZEgRjc7LK8w:
		kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if kMnoXVxN5byYJSzPrsu!=1: return
	vXSV4tIkDzNC = K0sLrB3qvJn9Edt(C47G3hXaRMFLfOAEpV,eHdDoxhJCEPMZFVa2fg)
	try: RRydns1CErYlIhwSx7.remove(vXSV4tIkDzNC)
	except: pass
	for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in range(1,hPjydHiuqQc75KFp+1):
		cepLvEox93aUI = zzxr5UY1CkyZG48A9NEPFHhKTD6wc.replace('___','_'+C47G3hXaRMFLfOAEpV+'_'+str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
		fHtX0KQCx6PWT = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,cepLvEox93aUI)
		try: RRydns1CErYlIhwSx7.remove(fHtX0KQCx6PWT)
		except: pass
	k5L96NenKBwpSYWv(pyifuNFdxe,'SECTIONS_M3U','SECTIONS_M3U_'+C47G3hXaRMFLfOAEpV)
	k5L96NenKBwpSYWv(pyifuNFdxe,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if UzF4sIShoZEgRjc7LK8w:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		AOwqYZ30sN1Mp(False)
	return
def F9R7PzKHXeJjC5fBioZ6WVgsYE(C47G3hXaRMFLfOAEpV):
	eyx7SQN1RLtvjIkHcd5m436rBKOb = MoO74hKeqm8fFka.getSetting('av.language.provider')
	QRW3ABgXKOzL51VdTsP = MoO74hKeqm8fFka.getSetting('av.language.code')
	k5L96NenKBwpSYWv(pyifuNFdxe,'MENUS_CACHE_'+eyx7SQN1RLtvjIkHcd5m436rBKOb+'_'+QRW3ABgXKOzL51VdTsP,'%_MU'+C47G3hXaRMFLfOAEpV+'_%')
	return
l5VeRUJf8EkqPHuN2mTy = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
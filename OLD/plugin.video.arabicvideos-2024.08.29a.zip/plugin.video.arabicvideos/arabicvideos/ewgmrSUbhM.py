# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'MOVIZLAND'
headers = { 'User-Agent' : eHdDoxhJCEPMZFVa2fg }
r07r9xeEFASJXluImT = '_MVZ_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][1]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==180: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==181: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==182: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==183: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==188: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = EPrFofs5u9vKkD()
	elif mode==189: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def EPrFofs5u9vKkD():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج',message)
	return
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,189,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'بوكس اوفيس موفيز لاند',q3QVhZaDEuo8t2ASj5vkn,181,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'box-office')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أحدث الافلام',q3QVhZaDEuo8t2ASj5vkn,181,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'latest-movies')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'تليفزيون موفيز لاند',q3QVhZaDEuo8t2ASj5vkn,181,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'tv')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الاكثر مشاهدة',q3QVhZaDEuo8t2ASj5vkn,181,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'top-views')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'أقوى الافلام الحالية',q3QVhZaDEuo8t2ASj5vkn,181,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'top-movies')
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-MENU-1st')
	items = cBawilJXvK1m.findall('<h2><a href="(.*?)".*?">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,181)
	return nR2B1Wye7luXb5
def zRK9ruIt0ZFV4bgi(url,type=eHdDoxhJCEPMZFVa2fg):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': cOUiow273ytu1GC5N0FJh = cBawilJXvK1m.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	elif type=='box-office': cOUiow273ytu1GC5N0FJh = cBawilJXvK1m.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	elif type=='top-movies': cOUiow273ytu1GC5N0FJh = cBawilJXvK1m.findall('btn-2-overlay(.*?)<style>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	elif type=='top-views': cOUiow273ytu1GC5N0FJh = cBawilJXvK1m.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	elif type=='tv': cOUiow273ytu1GC5N0FJh = cBawilJXvK1m.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	else: cOUiow273ytu1GC5N0FJh = nR2B1Wye7luXb5
	if type in ['top-views','top-movies']:
		items = cBawilJXvK1m.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	else: items = cBawilJXvK1m.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	uL2aUQ5PtsyCRG = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for PeLqCN5Ek8bB,DDY4vSW3UQ,pxVBnJRzq0,BBvAXnziVTKwRfDUx2a in items:
		if type in ['top-views','top-movies']:
			PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,bmsN7D3kPQ8Beh5RS0M4ng2FcY,title = PeLqCN5Ek8bB,DDY4vSW3UQ,pxVBnJRzq0,BBvAXnziVTKwRfDUx2a
		else: PeLqCN5Ek8bB,title,apOKrFbP9IYHDyUVm7,bmsN7D3kPQ8Beh5RS0M4ng2FcY = PeLqCN5Ek8bB,DDY4vSW3UQ,pxVBnJRzq0,BBvAXnziVTKwRfDUx2a
		apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('?view=true',eHdDoxhJCEPMZFVa2fg)
		title = zJRbA1YW2Eor(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',eHdDoxhJCEPMZFVa2fg).replace('بجوده ',eHdDoxhJCEPMZFVa2fg)
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'الحلقة' in title or 'الحلقه' in title:
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) (الحلقة|الحلقه) \d+',title,cBawilJXvK1m.DOTALL)
			if vQ2LDF3UyXZbhu97Y:
				title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0][0]
				if title not in adU3exogvimBLnCQOwz:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,183,PeLqCN5Ek8bB)
					adU3exogvimBLnCQOwz.append(title)
		elif any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in uL2aUQ5PtsyCRG):
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7 + '?servers=' + bmsN7D3kPQ8Beh5RS0M4ng2FcY
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,182,PeLqCN5Ek8bB)
		else:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7 + '?servers=' + bmsN7D3kPQ8Beh5RS0M4ng2FcY
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,183,PeLqCN5Ek8bB)
	if type==eHdDoxhJCEPMZFVa2fg:
		items = cBawilJXvK1m.findall('\n<li><a href="(.*?)".*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = zJRbA1YW2Eor(title)
			title = title.replace('الصفحة ',eHdDoxhJCEPMZFVa2fg)
			if title!=eHdDoxhJCEPMZFVa2fg:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,181)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	E1Viom5L3684CTOFJ = url.split('?servers=')[0]
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-EPISODES-1st')
	cOUiow273ytu1GC5N0FJh = cBawilJXvK1m.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	title,ppxnlrkDsXUmKQWFt,PeLqCN5Ek8bB = cOUiow273ytu1GC5N0FJh[0]
	name = cBawilJXvK1m.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,cBawilJXvK1m.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="episodesNumbers"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7 in items:
			apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
			title = cBawilJXvK1m.findall('(الحلقة|الحلقه)-([0-9]+)',apOKrFbP9IYHDyUVm7.split('/')[-2],cBawilJXvK1m.DOTALL)
			if not title: title = cBawilJXvK1m.findall('()-([0-9]+)',apOKrFbP9IYHDyUVm7.split('/')[-2],cBawilJXvK1m.DOTALL)
			if title: title = avcfIls8w7gk69hYUErHxzQTXtm24j + title[0][1]
			else: title = eHdDoxhJCEPMZFVa2fg
			title = name + ' - ' + 'الحلقة' + title
			title = zJRbA1YW2Eor(title)
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,182,PeLqCN5Ek8bB)
	if not items:
		title = zJRbA1YW2Eor(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',eHdDoxhJCEPMZFVa2fg).replace('بجوده ',eHdDoxhJCEPMZFVa2fg)
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,url,182,PeLqCN5Ek8bB)
	return
def bbmQeYGSTIv(url):
	yoPm1UMpR0VCchze6nZkTArEWlNv3s = url.split('?servers=')
	E1Viom5L3684CTOFJ = yoPm1UMpR0VCchze6nZkTArEWlNv3s[0]
	del yoPm1UMpR0VCchze6nZkTArEWlNv3s[0]
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-PLAY-1st')
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('font-size: 25px;" href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	if apOKrFbP9IYHDyUVm7 not in yoPm1UMpR0VCchze6nZkTArEWlNv3s: yoPm1UMpR0VCchze6nZkTArEWlNv3s.append(apOKrFbP9IYHDyUVm7)
	ppQOjlq2gaPkW = []
	for apOKrFbP9IYHDyUVm7 in yoPm1UMpR0VCchze6nZkTArEWlNv3s:
		if '://moshahda.' in apOKrFbP9IYHDyUVm7:
			LGxnewFPT2YXpDCz = apOKrFbP9IYHDyUVm7
			ppQOjlq2gaPkW.append(LGxnewFPT2YXpDCz+'?named=Main')
	for apOKrFbP9IYHDyUVm7 in yoPm1UMpR0VCchze6nZkTArEWlNv3s:
		if '://vb.movizland.' in apOKrFbP9IYHDyUVm7:
			nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-PLAY-2nd')
			nR2B1Wye7luXb5 = nR2B1Wye7luXb5.decode('windows-1256').encode(m6PFtLblInpNZ8x)
			nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
				qqVw1UMpJmejYh5ioKIbnFGH,e8UJpoK72tOlWfr0wRs3BA9xn = [],[]
				if len(RRztfCIs16MGxEHLJ25vDNAa7hpWT)==1:
					title = eHdDoxhJCEPMZFVa2fg
					cOUiow273ytu1GC5N0FJh = nR2B1Wye7luXb5
				else:
					for cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
						KUTgdRBshwIZcbuv0LVC4 = cBawilJXvK1m.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
						if KUTgdRBshwIZcbuv0LVC4: cOUiow273ytu1GC5N0FJh = 'src="/uploads/13721411411.png"  \n  ' + KUTgdRBshwIZcbuv0LVC4[0][1]
						KUTgdRBshwIZcbuv0LVC4 = cBawilJXvK1m.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
						if KUTgdRBshwIZcbuv0LVC4: cOUiow273ytu1GC5N0FJh = 'src="/uploads/13721411411.png"  \n  ' + KUTgdRBshwIZcbuv0LVC4[0]
						KUTgdRBshwIZcbuv0LVC4 = cBawilJXvK1m.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
						if KUTgdRBshwIZcbuv0LVC4: cOUiow273ytu1GC5N0FJh = KUTgdRBshwIZcbuv0LVC4[0] + '  \n  src="/uploads/13721411411.png"'
						hr78jDIzPy50eaVHF3BJ = cBawilJXvK1m.findall('<(.*?)http://up.movizland.(online|com)/uploads/',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
						title = cBawilJXvK1m.findall('> *([^<>]+) *<',hr78jDIzPy50eaVHF3BJ[0][0],cBawilJXvK1m.DOTALL)
						title = avcfIls8w7gk69hYUErHxzQTXtm24j.join(title)
						title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
						title = title.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
						qqVw1UMpJmejYh5ioKIbnFGH.append(title)
					iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('أختر الفيديو المطلوب:', qqVw1UMpJmejYh5ioKIbnFGH)
					if iLcCSnPyKYWs3xkQ0p14 == -1 : return
					title = qqVw1UMpJmejYh5ioKIbnFGH[iLcCSnPyKYWs3xkQ0p14]
					cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[iLcCSnPyKYWs3xkQ0p14]
				apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('href="(http://moshahda\..*?/\w+.html)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				a4ays3plW7mUhFg0TH = apOKrFbP9IYHDyUVm7[0]
				ppQOjlq2gaPkW.append(a4ays3plW7mUhFg0TH+'?named=Forum')
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('ـ',eHdDoxhJCEPMZFVa2fg)
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				sq7B8Zzi9yVDCK1INlOSUvbHpxhcT = cBawilJXvK1m.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				for aa9MoXH4EiLsetpNQ078C in sq7B8Zzi9yVDCK1INlOSUvbHpxhcT:
					type = cBawilJXvK1m.findall(' typetype="(.*?)" ',aa9MoXH4EiLsetpNQ078C)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = eHdDoxhJCEPMZFVa2fg
					items = cBawilJXvK1m.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',aa9MoXH4EiLsetpNQ078C,cBawilJXvK1m.DOTALL)
					for VMIEbH5U0DL9Kjln2Bxtpqs,apOKrFbP9IYHDyUVm7 in items:
						title = cBawilJXvK1m.findall('(\w+[ \w]*)<',VMIEbH5U0DL9Kjln2Bxtpqs)
						title = title[-1]
						apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7 + '?named=' + title + type
						ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	ajHR9ABQl2buvm = E1Viom5L3684CTOFJ.replace(q3QVhZaDEuo8t2ASj5vkn,hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,ajHR9ABQl2buvm,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-PLAY-3rd')
	items = cBawilJXvK1m.findall('" href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		YAkhGqeVLcnIFgR4piZXUW0oS = items[-1]
		ppQOjlq2gaPkW.append(YAkhGqeVLcnIFgR4piZXUW0oS+'?named=Mobile')
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,'MOVIZLAND-SEARCH-1st')
	items = cBawilJXvK1m.findall('<option value="(.*?)">(.*?)</option>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	hFSUpnBXHDeAf3o = [ eHdDoxhJCEPMZFVa2fg ]
	lAu7wW0nzirJd8LQMmCDvqEIKSV5Ph = [ 'الكل وبدون فلتر' ]
	for U3d2hkuwDIj56,title in items:
		hFSUpnBXHDeAf3o.append(U3d2hkuwDIj56)
		lAu7wW0nzirJd8LQMmCDvqEIKSV5Ph.append(title)
	if U3d2hkuwDIj56:
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('اختر الفلتر المناسب:', lAu7wW0nzirJd8LQMmCDvqEIKSV5Ph)
		if iLcCSnPyKYWs3xkQ0p14 == -1 : return
		U3d2hkuwDIj56 = hFSUpnBXHDeAf3o[iLcCSnPyKYWs3xkQ0p14]
	else: U3d2hkuwDIj56 = eHdDoxhJCEPMZFVa2fg
	url = q3QVhZaDEuo8t2ASj5vkn + '/?s='+search+'&mcat='+U3d2hkuwDIj56
	zRK9ruIt0ZFV4bgi(url)
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'EGYBESTVIP'
r07r9xeEFASJXluImT = '_EGV_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,clAzmREWwXf6Gk,text):
	if   mode==220: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==221: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk)
	elif mode==222: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==223: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==224: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url)
	elif mode==229: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,229,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="i i-home"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)"(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,222)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="ba(.*?)<script',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for title,apOKrFbP9IYHDyUVm7 in items:
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,221)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if 'html' not in apOKrFbP9IYHDyUVm7: continue
			if not apOKrFbP9IYHDyUVm7.endswith('/'): qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,221)
	return nR2B1Wye7luXb5
def VrWsaTmY2qZ(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-SUBMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="rs_scroll"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)".*?</i>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,224)
	return
def bbkDE5p9zlX6aV(url):
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',url,221)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-FILTERS_MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="sub_nav(.*?)id="movies',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".+?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if apOKrFbP9IYHDyUVm7=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,221)
	else: zRK9ruIt0ZFV4bgi(url)
	return
def zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk='1'):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	if '/search' in url or '?' in url: E1Viom5L3684CTOFJ = url + '&'
	else: E1Viom5L3684CTOFJ = url + '?'
	E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ + 'page=' + clAzmREWwXf6Gk
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('class="pda"(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[-1]
	elif '/series/' in url:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('class="owl-carousel owl-carousel(.*?)div',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('id="movies(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[-1]
	items = cBawilJXvK1m.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		title = zJRbA1YW2Eor(title)
		if '/movie/' in apOKrFbP9IYHDyUVm7 or '/episode' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7.rstrip('/'),223,PeLqCN5Ek8bB)
		else:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,221,PeLqCN5Ek8bB)
	if len(items)>=16:
		b8gDA9fBXmkcwjWni7xsSov = ['/movies','/tv','/search','/trending']
		clAzmREWwXf6Gk = int(clAzmREWwXf6Gk)
		if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in url for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in b8gDA9fBXmkcwjWni7xsSov):
			for DtojFpCJKdPOTMgVh3SYrN5 in range(0,1000,100):
				if int(clAzmREWwXf6Gk/100)*100==DtojFpCJKdPOTMgVh3SYrN5:
					for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(DtojFpCJKdPOTMgVh3SYrN5,DtojFpCJKdPOTMgVh3SYrN5+100,10):
						if int(clAzmREWwXf6Gk/10)*10==dhcGSyo8Kn1mHZwvEAkzJ7NUq:
							for bbAvLuM5lUWf4akiRdCTtsjqEH in range(dhcGSyo8Kn1mHZwvEAkzJ7NUq,dhcGSyo8Kn1mHZwvEAkzJ7NUq+10,1):
								if not clAzmREWwXf6Gk==bbAvLuM5lUWf4akiRdCTtsjqEH and bbAvLuM5lUWf4akiRdCTtsjqEH!=0:
									qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+str(bbAvLuM5lUWf4akiRdCTtsjqEH),url,221,eHdDoxhJCEPMZFVa2fg,str(bbAvLuM5lUWf4akiRdCTtsjqEH))
						elif dhcGSyo8Kn1mHZwvEAkzJ7NUq!=0: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+str(dhcGSyo8Kn1mHZwvEAkzJ7NUq),url,221,eHdDoxhJCEPMZFVa2fg,str(dhcGSyo8Kn1mHZwvEAkzJ7NUq))
						else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+str(1),url,221,eHdDoxhJCEPMZFVa2fg,str(1))
				elif DtojFpCJKdPOTMgVh3SYrN5!=0: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+str(DtojFpCJKdPOTMgVh3SYrN5),url,221,eHdDoxhJCEPMZFVa2fg,str(DtojFpCJKdPOTMgVh3SYrN5))
				else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+str(1),url,221)
	return
def bbmQeYGSTIv(url):
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-PLAY-1st')
	i2qmOCHN5goZ = cBawilJXvK1m.findall('<td>التصنيف</td>.*?">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	T0oYA6DCGmBtc95fPapFLVOhM,wJpuIhq6xtRGQSEe5HA = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	eflrxc3kdo2mJQ9,wMINW24mi3or = nR2B1Wye7luXb5,nR2B1Wye7luXb5
	jDAdKZvOp3f = cBawilJXvK1m.findall('show_dl api" href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if jDAdKZvOp3f:
		for apOKrFbP9IYHDyUVm7 in jDAdKZvOp3f:
			if '/watch/' in apOKrFbP9IYHDyUVm7: T0oYA6DCGmBtc95fPapFLVOhM = apOKrFbP9IYHDyUVm7
			elif '/download/' in apOKrFbP9IYHDyUVm7: wJpuIhq6xtRGQSEe5HA = apOKrFbP9IYHDyUVm7
		if T0oYA6DCGmBtc95fPapFLVOhM!=eHdDoxhJCEPMZFVa2fg: eflrxc3kdo2mJQ9 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,T0oYA6DCGmBtc95fPapFLVOhM,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-PLAY-2nd')
		if wJpuIhq6xtRGQSEe5HA!=eHdDoxhJCEPMZFVa2fg: wMINW24mi3or = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,wJpuIhq6xtRGQSEe5HA,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-PLAY-3rd')
	X7VpBWvMqTH = cBawilJXvK1m.findall('id="video".*?data-src="(.*?)"',eflrxc3kdo2mJQ9,cBawilJXvK1m.DOTALL)
	if X7VpBWvMqTH:
		E1Viom5L3684CTOFJ = X7VpBWvMqTH[0]
		if E1Viom5L3684CTOFJ!=eHdDoxhJCEPMZFVa2fg and 'uploaded.egybest.download' in E1Viom5L3684CTOFJ and '/?id=_' not in E1Viom5L3684CTOFJ:
			L3f4VRFXh0Sb1xwKPzoi = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-PLAY-4th')
			VV8QydPspx3oJ45qiMWZbA2naeEG = cBawilJXvK1m.findall('source src="(.*?)" title="(.*?)"',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			if VV8QydPspx3oJ45qiMWZbA2naeEG:
				for apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3 in VV8QydPspx3oJ45qiMWZbA2naeEG:
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7+'?named=ed.egybest.do__watch__mp4__'+s0s2bIZtWx8w3)
			else:
				GfhcsvCWIon = E1Viom5L3684CTOFJ.split('/')[2]
				ppQOjlq2gaPkW.append(E1Viom5L3684CTOFJ+'?named='+GfhcsvCWIon+'__watch')
		elif E1Viom5L3684CTOFJ!=eHdDoxhJCEPMZFVa2fg:
			GfhcsvCWIon = E1Viom5L3684CTOFJ.split('/')[2]
			ppQOjlq2gaPkW.append(E1Viom5L3684CTOFJ+'?named='+GfhcsvCWIon+'__watch')
	o2UgpKfNHJaZdM7v = cBawilJXvK1m.findall('<table class="dls_table(.*?)</table>',wMINW24mi3or,cBawilJXvK1m.DOTALL)
	if o2UgpKfNHJaZdM7v:
		o2UgpKfNHJaZdM7v = o2UgpKfNHJaZdM7v[0]
		po1P6vHkMmQXYKLbDSg5rzu4 = cBawilJXvK1m.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',o2UgpKfNHJaZdM7v,cBawilJXvK1m.DOTALL)
		if po1P6vHkMmQXYKLbDSg5rzu4:
			for s0s2bIZtWx8w3,apOKrFbP9IYHDyUVm7 in po1P6vHkMmQXYKLbDSg5rzu4:
				if 'myegyvip' not in apOKrFbP9IYHDyUVm7: continue
				if apOKrFbP9IYHDyUVm7.count('/')>=2:
					GfhcsvCWIon = apOKrFbP9IYHDyUVm7.split('/')[2]
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__download__mp4__'+s0s2bIZtWx8w3)
	W1vLcHR5lO = []
	for apOKrFbP9IYHDyUVm7 in ppQOjlq2gaPkW:
		W1vLcHR5lO.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(W1vLcHR5lO,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBESTVIP-SEARCH-1st')
	L6GuZYmNyAEUBi1sQ = cBawilJXvK1m.findall('name="_token" value="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if L6GuZYmNyAEUBi1sQ:
		url = q3QVhZaDEuo8t2ASj5vkn+'/search?_token='+L6GuZYmNyAEUBi1sQ[0]+'&q='+diojk6J5vzuRNDKmw
		zRK9ruIt0ZFV4bgi(url)
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'EGYBEST3'
r07r9xeEFASJXluImT = '_EB3_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,clAzmREWwXf6Gk,text):
	if   mode==790: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==791: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk)
	elif mode==792: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url)
	elif mode==793: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==796: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = CCi1Vt9vmrcFqODjkT72l3E0KNBIHM(url,clAzmREWwXf6Gk)
	elif mode==799: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST3-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('list-pages(.*?)fa-folder',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm): continue
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,791)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-article(.*?)social-box',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('main-title.*?">(.*?)<.*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for title,apOKrFbP9IYHDyUVm7 in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm): continue
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,791,eHdDoxhJCEPMZFVa2fg,'mainmenu')
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-menu(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in IVD2kBKhW8FeQLvxUm): continue
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,791)
	return nR2B1Wye7luXb5
def CCi1Vt9vmrcFqODjkT72l3E0KNBIHM(url,type=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST3-SEASONS_EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-article".*?">(.*?)<(.*?)article',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		MMHTKqYVvSrLojUt,Tfo9biLauWAQBSXw3GmeqkV,items = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,[]
		for name,cOUiow273ytu1GC5N0FJh in RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			if 'حلقات' in name: Tfo9biLauWAQBSXw3GmeqkV = cOUiow273ytu1GC5N0FJh
			if 'مواسم' in name: MMHTKqYVvSrLojUt = cOUiow273ytu1GC5N0FJh
		if MMHTKqYVvSrLojUt and not type:
			items = cBawilJXvK1m.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',MMHTKqYVvSrLojUt,cBawilJXvK1m.DOTALL)
			if len(items)>1:
				for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,796,PeLqCN5Ek8bB,'season')
		if Tfo9biLauWAQBSXw3GmeqkV and len(items)<2:
			items = cBawilJXvK1m.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',Tfo9biLauWAQBSXw3GmeqkV,cBawilJXvK1m.DOTALL)
			if items:
				for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
					qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,793,PeLqCN5Ek8bB)
			else:
				items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',Tfo9biLauWAQBSXw3GmeqkV,cBawilJXvK1m.DOTALL)
				for apOKrFbP9IYHDyUVm7,title in items:
					qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,793)
	return
def zRK9ruIt0ZFV4bgi(url,type=eHdDoxhJCEPMZFVa2fg):
	e6q9xwbgQ4tR8BO,start,FyWTVmEXrYwtpUBujRMxZb,select,Zh81GRBkfW6Iv = 0,0,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if 'pagination' in type:
		r0TAhyGDsgNSVjWM,data = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(url)
		e6q9xwbgQ4tR8BO = int(data['limit'])
		start = int(data['start'])
		FyWTVmEXrYwtpUBujRMxZb = data['type']
		select = data['select']
		LbAmEhrdt7eRV2Y = 'limit='+str(e6q9xwbgQ4tR8BO)+'&start='+str(start)+'&type='+FyWTVmEXrYwtpUBujRMxZb+'&select='+select
		W9PzsMeLJTc83mS45G17n = {'Content-Type':'application/x-www-form-urlencoded'}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',r0TAhyGDsgNSVjWM,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST3-TITLES-1st')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		L3f4VRFXh0Sb1xwKPzoi = 'blocks'+nR2B1Wye7luXb5+'article'
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST3-TITLES-2nd')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		L3f4VRFXh0Sb1xwKPzoi = nR2B1Wye7luXb5
		code = cBawilJXvK1m.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if code:
			code = code[0].replace('var',eHdDoxhJCEPMZFVa2fg).replace(avcfIls8w7gk69hYUErHxzQTXtm24j,eHdDoxhJCEPMZFVa2fg).replace("'",eHdDoxhJCEPMZFVa2fg).replace(';','&')
			ppxnlrkDsXUmKQWFt,data = ZZOBwdspmUJWtNH9KPyj0TI5V68hv('?'+code)
			e6q9xwbgQ4tR8BO = int(data['limit'])
			start = int(data['start'])
			FyWTVmEXrYwtpUBujRMxZb = data['type']
			select = data['select']
			Zh81GRBkfW6Iv = data['ajaxurl']
			LbAmEhrdt7eRV2Y = 'limit='+str(e6q9xwbgQ4tR8BO)+'&start='+str(start)+'&type='+FyWTVmEXrYwtpUBujRMxZb+'&select='+select
			r0TAhyGDsgNSVjWM = q3QVhZaDEuo8t2ASj5vkn+Zh81GRBkfW6Iv
			W9PzsMeLJTc83mS45G17n = {'Content-Type':'application/x-www-form-urlencoded'}
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',r0TAhyGDsgNSVjWM,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST3-TITLES-3rd')
			L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
			L3f4VRFXh0Sb1xwKPzoi = 'blocks'+L3f4VRFXh0Sb1xwKPzoi+'article'
	items,sCVKdvo76plYG9hkz,yTtrwivOXY68ECP7ZHQgNdJ1 = [],False,False
	if not type:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-content(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?</i>(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,791,eHdDoxhJCEPMZFVa2fg,'submenu')
				sCVKdvo76plYG9hkz = True
	if not type:
		yTtrwivOXY68ECP7ZHQgNdJ1 = VVa2bIQAByFNdqMRiD0ZprsCUnl(nR2B1Wye7luXb5)
	if not sCVKdvo76plYG9hkz and not yTtrwivOXY68ECP7ZHQgNdJ1:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('blocks(.*?)article',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
				PeLqCN5Ek8bB = PeLqCN5Ek8bB.strip(kDUv7ouWrcgMe6OipQJm)
				apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
				if '/selary/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,791,PeLqCN5Ek8bB)
				elif 'مسلسل' in apOKrFbP9IYHDyUVm7 and 'حلقة' not in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,796,PeLqCN5Ek8bB)
				elif 'موسم' in apOKrFbP9IYHDyUVm7 and 'حلقة' not in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,796,PeLqCN5Ek8bB)
				else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,793,PeLqCN5Ek8bB)
		R2apkdt0qg41 = 12
		data = cBawilJXvK1m.findall('class="(load-more.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if len(items)==R2apkdt0qg41 and (data or 'pagination' in type):
			LbAmEhrdt7eRV2Y = 'limit='+str(R2apkdt0qg41)+'&start='+str(start+R2apkdt0qg41)+'&type='+FyWTVmEXrYwtpUBujRMxZb+'&select='+select
			E1Viom5L3684CTOFJ = r0TAhyGDsgNSVjWM+'?next=page&'+LbAmEhrdt7eRV2Y
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'المزيد',E1Viom5L3684CTOFJ,791,eHdDoxhJCEPMZFVa2fg,'pagination_'+type)
	return
def VVa2bIQAByFNdqMRiD0ZprsCUnl(nR2B1Wye7luXb5):
	yTtrwivOXY68ECP7ZHQgNdJ1 = False
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('main-article(.*?)article',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if ekNMoIJzswUSDVQf564: qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
		for U3d2hkuwDIj56,name,cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
			name = name.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,q5qDOCzEe0Lv4ZyJbWnaPcpVsB in items:
				title = name+':  '+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,791,eHdDoxhJCEPMZFVa2fg,'filter')
				yTtrwivOXY68ECP7ZHQgNdJ1 = True
	return yTtrwivOXY68ECP7ZHQgNdJ1
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'EGYBEST3-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	wROf6m4Ix73jtsdnZ1vpCDuV,ZVrJl8DdFKBimq46Eyu2QItUex9P = [],[]
	items = cBawilJXvK1m.findall('server-item.*?data-code="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for nsYDMdHLCaNZgz in items:
		ccSWvb1twsPoYu42TpdVaDE3K = HHP76VFiKDS2xphlGsqN48j1.b64decode(nsYDMdHLCaNZgz)
		if WHjh1POtMKlmgiy68RSqb: ccSWvb1twsPoYu42TpdVaDE3K = ccSWvb1twsPoYu42TpdVaDE3K.decode(m6PFtLblInpNZ8x)
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('src="(.*?)"',ccSWvb1twsPoYu42TpdVaDE3K,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
			if apOKrFbP9IYHDyUVm7 not in ZVrJl8DdFKBimq46Eyu2QItUex9P:
				ZVrJl8DdFKBimq46Eyu2QItUex9P.append(apOKrFbP9IYHDyUVm7)
				GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__watch')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="downloads(.*?)</section>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for s0s2bIZtWx8w3,apOKrFbP9IYHDyUVm7 in items:
			if apOKrFbP9IYHDyUVm7 not in ZVrJl8DdFKBimq46Eyu2QItUex9P:
				if '/?url=' in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split('/?url=')[1]
				ZVrJl8DdFKBimq46Eyu2QItUex9P.append(apOKrFbP9IYHDyUVm7)
				GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+GfhcsvCWIon+'__download____'+s0s2bIZtWx8w3)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(text):
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'SERIESTIME'
r07r9xeEFASJXluImT = '_SRT_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['الرئيسية','يلا شوت']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==890: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==891: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==892: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==893: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = Fl2VaUu6noQ9chyIPZG1YeSmsw4X5N(url)
	elif mode==899: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SERIESTIME-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,899,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"list-categories"(.*?)</u',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+apOKrFbP9IYHDyUVm7.lstrip('/')
			if title in IVD2kBKhW8FeQLvxUm: continue
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,891)
	return
def zRK9ruIt0ZFV4bgi(url,type=eHdDoxhJCEPMZFVa2fg):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SERIESTIME-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"home-content"(.*?)"footer"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh.replace('"overlay"','"duration"><')
		items = cBawilJXvK1m.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		adU3exogvimBLnCQOwz = []
		for PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1,apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = vFDQstemyYANa(apOKrFbP9IYHDyUVm7)
			title = title.strip(' ')
			title = zJRbA1YW2Eor(title)
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) (الحلقة|حلقة).\d+',title,cBawilJXvK1m.DOTALL)
			if 'episodes' not in type and vQ2LDF3UyXZbhu97Y:
				title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0][0]
				title = title.replace('اون لاين',eHdDoxhJCEPMZFVa2fg)
				if title not in adU3exogvimBLnCQOwz:
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,893,PeLqCN5Ek8bB)
					adU3exogvimBLnCQOwz.append(title)
			else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,892,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('''["']pagination["'](.*?)["']footer["']''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = zJRbA1YW2Eor(title)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,891,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	else:
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('load-next-button" href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة جديدة',apOKrFbP9IYHDyUVm7[0],891,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	return
def Fl2VaUu6noQ9chyIPZG1YeSmsw4X5N(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SERIESTIME-SERIES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="eplist"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		Tfo9biLauWAQBSXw3GmeqkV = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in Tfo9biLauWAQBSXw3GmeqkV:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,892)
	else:
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('"category".*?href="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0]
			zRK9ruIt0ZFV4bgi(apOKrFbP9IYHDyUVm7,'episodes')
	return
def bbmQeYGSTIv(url):
	wROf6m4Ix73jtsdnZ1vpCDuV = []
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SERIESTIME-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if 'hash=' in nR2B1Wye7luXb5:
		HH4KgQNSIT3DOo6Jd7 = cBawilJXvK1m.findall('hash=(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		HH4KgQNSIT3DOo6Jd7 = list(set(HH4KgQNSIT3DOo6Jd7))
		for V5VgYoCK6sT in HH4KgQNSIT3DOo6Jd7:
			jjqr1Rt6Xlhp = []
			dezG4T3itVrAKvX9 = V5VgYoCK6sT.split('__')
			for IsefnDRrqBWv in dezG4T3itVrAKvX9:
				try:
					IsefnDRrqBWv = HHP76VFiKDS2xphlGsqN48j1.b64decode(IsefnDRrqBWv+'=')
					if WHjh1POtMKlmgiy68RSqb: IsefnDRrqBWv = IsefnDRrqBWv.decode(m6PFtLblInpNZ8x)
					jjqr1Rt6Xlhp.append(IsefnDRrqBWv)
				except: pass
			JCZVK86QTYwX4mfgOrod = '>'.join(jjqr1Rt6Xlhp)
			JCZVK86QTYwX4mfgOrod = JCZVK86QTYwX4mfgOrod.splitlines()
			for apOKrFbP9IYHDyUVm7 in JCZVK86QTYwX4mfgOrod:
				if ' => ' in apOKrFbP9IYHDyUVm7:
					title,apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split(' => ')
					apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	elif 'post_id' in nR2B1Wye7luXb5:
		CJAVOZo730iHxPXp = cBawilJXvK1m.findall("post_id = '(.*?)'",nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if CJAVOZo730iHxPXp:
			CJAVOZo730iHxPXp = CJAVOZo730iHxPXp[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			V7ZHYcKbMl6dPqLOuS = q3QVhZaDEuo8t2ASj5vkn+'/wp-admin/admin-ajax.php?action=video_info&post_id='+CJAVOZo730iHxPXp
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',V7ZHYcKbMl6dPqLOuS,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SERIESTIME-PLAY-2nd')
			tqaEF7mzvCZleBQ = aP8bLqZJsQlH3ivWKc.content
			IxFyL2zj5aAXlWwg0JPY8SdqTZ = cBawilJXvK1m.findall('"name":"(.*?)","src":"(.*?)"',tqaEF7mzvCZleBQ,cBawilJXvK1m.DOTALL)
			if not IxFyL2zj5aAXlWwg0JPY8SdqTZ:
				IxFyL2zj5aAXlWwg0JPY8SdqTZ = cBawilJXvK1m.findall('"src":"(.*?)"',tqaEF7mzvCZleBQ,cBawilJXvK1m.DOTALL)
				if IxFyL2zj5aAXlWwg0JPY8SdqTZ:
					jck6RU3TpO = ['']*len(IxFyL2zj5aAXlWwg0JPY8SdqTZ)
					IxFyL2zj5aAXlWwg0JPY8SdqTZ = list(zip(jck6RU3TpO,IxFyL2zj5aAXlWwg0JPY8SdqTZ))
			for name,apOKrFbP9IYHDyUVm7 in IxFyL2zj5aAXlWwg0JPY8SdqTZ:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('\\/','/')
				apOKrFbP9IYHDyUVm7 = vFDQstemyYANa(apOKrFbP9IYHDyUVm7)
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7+'?named='+name+'__watch')
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/?s='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'MOVS4U'
r07r9xeEFASJXluImT = '_M4U_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['انواع افلام','جودات افلام']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==380: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==381: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==382: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==383: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==389: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,389,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المميزة',q3QVhZaDEuo8t2ASj5vkn,381,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الجانبية',q3QVhZaDEuo8t2ASj5vkn,381,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'sider')
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'MOVS4U-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items = cBawilJXvK1m.findall('<header>.*?<h2>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for SDZB9uCEYwg4osN in range(len(items)):
		title = items[SDZB9uCEYwg4osN]
		qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,q3QVhZaDEuo8t2ASj5vkn,381,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'latest'+str(SDZB9uCEYwg4osN))
	cOUiow273ytu1GC5N0FJh = eHdDoxhJCEPMZFVa2fg
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="menu"(.*?)id="contenedor"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh += RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="sidebar(.*?)aside',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT: cOUiow273ytu1GC5N0FJh += RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	HLjG0evOkWzBoa3F5UXdTi = True
	for apOKrFbP9IYHDyUVm7,title in items:
		title = zJRbA1YW2Eor(title)
		if title=='الأعلى مشاهدة':
			if HLjG0evOkWzBoa3F5UXdTi:
				title = 'الافلام '+title
				HLjG0evOkWzBoa3F5UXdTi = False
			else: title = 'المسلسلات '+title
		if title not in IVD2kBKhW8FeQLvxUm:
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,381)
	return nR2B1Wye7luXb5
def zRK9ruIt0ZFV4bgi(url,type):
	cOUiow273ytu1GC5N0FJh,items = [],[]
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'MOVS4U-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if type=='search':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="search-page"(.*?)class="sidebar',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif type=='sider':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="widget(.*?)class="widget',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		F58yI79lLjtsoNpAhJVkefUxE1XaYM = cBawilJXvK1m.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		ppQOjlq2gaPkW,JN1MdQFh5iArSHPsEquaxO0CG6U,FBITEXGDfe2mcCxnQs6ktMdy9HJh = zip(*F58yI79lLjtsoNpAhJVkefUxE1XaYM)
		items = zip(JN1MdQFh5iArSHPsEquaxO0CG6U,ppQOjlq2gaPkW,FBITEXGDfe2mcCxnQs6ktMdy9HJh)
	elif type=='featured':
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('id="slider-movies-tvshows"(.*?)<header>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	elif 'latest' in type:
		SDZB9uCEYwg4osN = int(type[-1:])
		nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('<header>','<end><start>')
		nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace('<div class="sidebar','<end><div class="sidebar')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('<start>(.*?)<end>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[SDZB9uCEYwg4osN]
		if SDZB9uCEYwg4osN==2: items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="content"(.*?)class="(pagination|sidebar)',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][0]
			if '/collection/' in url:
				items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			elif '/quality/' in url:
				items = cBawilJXvK1m.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	if not items and cOUiow273ytu1GC5N0FJh:
		items = cBawilJXvK1m.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		if 'serie' in title:
			title = cBawilJXvK1m.findall('^(.*?)<.*?serie">(.*?)<',title,cBawilJXvK1m.DOTALL)
			title = title[0][1]
			if title in adU3exogvimBLnCQOwz: continue
			adU3exogvimBLnCQOwz.append(title)
			title = '_MOD_'+title
		uVpKOk8ZM0LvQ6UI = cBawilJXvK1m.findall('^(.*?)<',title,cBawilJXvK1m.DOTALL)
		if uVpKOk8ZM0LvQ6UI: title = uVpKOk8ZM0LvQ6UI[0]
		title = zJRbA1YW2Eor(title)
		if '/tvshows/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,383,PeLqCN5Ek8bB)
		elif '/episodes/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,383,PeLqCN5Ek8bB)
		elif '/seasons/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,383,PeLqCN5Ek8bB)
		elif '/collection/' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,381,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,382,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		fknDWX2ev5tBJ67hr = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][0]
		Tsm8AcLfOy1z6 = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][1]
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][2]
		items = cBawilJXvK1m.findall("href='(.*?)'.*?>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if title==eHdDoxhJCEPMZFVa2fg or title==Tsm8AcLfOy1z6: continue
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,381,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('/page/'+title+'/','/page/'+Tsm8AcLfOy1z6+'/')
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'اخر صفحة '+Tsm8AcLfOy1z6,apOKrFbP9IYHDyUVm7,381,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'MOVS4U-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	i2qmOCHN5goZ = cBawilJXvK1m.findall('class="C rated".*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ,False):
		qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+'المسلسل للكبار والمبرمج منعه',eHdDoxhJCEPMZFVa2fg,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall('''class='item'><a href="(.*?)"''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if E1Viom5L3684CTOFJ:
			E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[1]
			tcJeirkgjMal25ofbE8zF4nxmOBw(E1Viom5L3684CTOFJ)
			return
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('''class='episodios'(.*?)id="cast"''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for PeLqCN5Ek8bB,vQ2LDF3UyXZbhu97Y,apOKrFbP9IYHDyUVm7,name in items:
			title = vQ2LDF3UyXZbhu97Y+' : '+name+' الحلقة'
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,382)
	return
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'MOVS4U-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	i2qmOCHN5goZ = cBawilJXvK1m.findall('class="C rated".*?>(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if i2qmOCHN5goZ and ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,url,i2qmOCHN5goZ): return
	ppQOjlq2gaPkW = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0][0]
		items = cBawilJXvK1m.findall("data-url='(.*?)'.*?class='server'>(.*?)<",cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="remodal"(.*?)class="remodal-close"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__download'
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/?s='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
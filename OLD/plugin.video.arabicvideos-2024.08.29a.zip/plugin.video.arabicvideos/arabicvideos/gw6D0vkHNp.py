# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
FO8SKWr40dDexHgbfRUGBi = 'EXCLUDES'
def UUPfIh4zdlVx1GMuT(Pe9ETSvwUGBnkC1hO,uuwei53S0EcsJfjM7IZD2PNXn):
	uuwei53S0EcsJfjM7IZD2PNXn = uuwei53S0EcsJfjM7IZD2PNXn.replace(SbyWQGMDnV,eHdDoxhJCEPMZFVa2fg).replace(' [/COLOR]',eHdDoxhJCEPMZFVa2fg)[1:]
	vbYx78LQCjkKHq1A0cZ = cBawilJXvK1m.findall('[a-zA-Z]',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
	if 'بحث IPTV - ' in Pe9ETSvwUGBnkC1hO: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace('بحث IPTV - ',EigLDrG278jQVcmy+'بحث IPTV - '+EigLDrG278jQVcmy)
	elif ' IPTV' in Pe9ETSvwUGBnkC1hO and uuwei53S0EcsJfjM7IZD2PNXn=='IPT': Pe9ETSvwUGBnkC1hO = EigLDrG278jQVcmy+Pe9ETSvwUGBnkC1hO
	elif 'بحث M3U - ' in Pe9ETSvwUGBnkC1hO: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace('بحث M3U - ',EigLDrG278jQVcmy+'بحث M3U - '+EigLDrG278jQVcmy)
	elif ' M3U' in Pe9ETSvwUGBnkC1hO and uuwei53S0EcsJfjM7IZD2PNXn=='M3U': Pe9ETSvwUGBnkC1hO = EigLDrG278jQVcmy+Pe9ETSvwUGBnkC1hO
	elif 'بحث ' in Pe9ETSvwUGBnkC1hO and ' - ' in Pe9ETSvwUGBnkC1hO: Pe9ETSvwUGBnkC1hO = EigLDrG278jQVcmy+Pe9ETSvwUGBnkC1hO
	elif not vbYx78LQCjkKHq1A0cZ:
		rrDuvJy4Z7 = cBawilJXvK1m.findall('^( *?)(.*?)( *?)$',Pe9ETSvwUGBnkC1hO)
		ztEgUvkMJr0Nab4nqIFh,neQZOHiac1FmUgphWC3AVt,NTpnqi3GHZAxu7kbU8t = rrDuvJy4Z7[0]
		iNTIRZScKp3YHE9jst71fg = cBawilJXvK1m.findall('^([!-~])',neQZOHiac1FmUgphWC3AVt)
		if iNTIRZScKp3YHE9jst71fg: Pe9ETSvwUGBnkC1hO = ztEgUvkMJr0Nab4nqIFh+Gd4fNUpaveYtQDxi+neQZOHiac1FmUgphWC3AVt+NTpnqi3GHZAxu7kbU8t
		else: Pe9ETSvwUGBnkC1hO = NTpnqi3GHZAxu7kbU8t+EigLDrG278jQVcmy+neQZOHiac1FmUgphWC3AVt+ztEgUvkMJr0Nab4nqIFh
	else:
		import bidi.algorithm as QQXsP3duLNJl5eK0ixBbcmwAo
		if 1:
			yuD7Sp8eVg4 = Pe9ETSvwUGBnkC1hO
			VVyhUEWGYS8IJpbrakcKi = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(Pe9ETSvwUGBnkC1hO,base_dir='L')
			if lHfbysRrUV7m4CLSdkxc382n: yuD7Sp8eVg4 = yuD7Sp8eVg4.decode(m6PFtLblInpNZ8x)
			if lHfbysRrUV7m4CLSdkxc382n: VVyhUEWGYS8IJpbrakcKi = VVyhUEWGYS8IJpbrakcKi.decode(m6PFtLblInpNZ8x)
			EEmOpBXtLJxKylHvY = yuD7Sp8eVg4.split(avcfIls8w7gk69hYUErHxzQTXtm24j)
			TLJstwHDXrmq7d8l2SbGChBZo = VVyhUEWGYS8IJpbrakcKi.split(avcfIls8w7gk69hYUErHxzQTXtm24j)
			DrSwtmACg87iW9j6akvBZRp,LdZNMlpYI5qj9Og1JGDs,OuRNjXcHPvs,AWo36Xasv9N0ugFDnQdxRH = [],[],eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
			hyMqnreIP9Zmtf4lzjObSB = zip(EEmOpBXtLJxKylHvY,TLJstwHDXrmq7d8l2SbGChBZo)
			for WX0EBQvKms28Uj7AfJnzqrLep6,DDqzUAluviytcPX3M in hyMqnreIP9Zmtf4lzjObSB:
				if WX0EBQvKms28Uj7AfJnzqrLep6==DDqzUAluviytcPX3M==eHdDoxhJCEPMZFVa2fg and AWo36Xasv9N0ugFDnQdxRH:
					OuRNjXcHPvs += avcfIls8w7gk69hYUErHxzQTXtm24j
					continue
				if WX0EBQvKms28Uj7AfJnzqrLep6==DDqzUAluviytcPX3M:
					TsH70GYWil9bp3MCEXQc = 'EN'
					if AWo36Xasv9N0ugFDnQdxRH==TsH70GYWil9bp3MCEXQc: OuRNjXcHPvs += avcfIls8w7gk69hYUErHxzQTXtm24j+WX0EBQvKms28Uj7AfJnzqrLep6
					elif WX0EBQvKms28Uj7AfJnzqrLep6:
						if OuRNjXcHPvs:
							LdZNMlpYI5qj9Og1JGDs.append(OuRNjXcHPvs)
							DrSwtmACg87iW9j6akvBZRp.append(eHdDoxhJCEPMZFVa2fg)
						OuRNjXcHPvs = WX0EBQvKms28Uj7AfJnzqrLep6
				else:
					TsH70GYWil9bp3MCEXQc = 'AR'
					if AWo36Xasv9N0ugFDnQdxRH==TsH70GYWil9bp3MCEXQc: OuRNjXcHPvs += avcfIls8w7gk69hYUErHxzQTXtm24j+WX0EBQvKms28Uj7AfJnzqrLep6
					elif WX0EBQvKms28Uj7AfJnzqrLep6:
						if OuRNjXcHPvs:
							DrSwtmACg87iW9j6akvBZRp.append(OuRNjXcHPvs)
							LdZNMlpYI5qj9Og1JGDs.append(eHdDoxhJCEPMZFVa2fg)
						OuRNjXcHPvs = WX0EBQvKms28Uj7AfJnzqrLep6
				AWo36Xasv9N0ugFDnQdxRH = TsH70GYWil9bp3MCEXQc
			if TsH70GYWil9bp3MCEXQc=='EN':
				DrSwtmACg87iW9j6akvBZRp.append(OuRNjXcHPvs)
				LdZNMlpYI5qj9Og1JGDs.append(eHdDoxhJCEPMZFVa2fg)
			else:
				LdZNMlpYI5qj9Og1JGDs.append(OuRNjXcHPvs)
				DrSwtmACg87iW9j6akvBZRp.append(eHdDoxhJCEPMZFVa2fg)
			pWS2wR71GzXUFyV = eHdDoxhJCEPMZFVa2fg
			hyMqnreIP9Zmtf4lzjObSB = zip(DrSwtmACg87iW9j6akvBZRp,LdZNMlpYI5qj9Og1JGDs)
			import bidi.mirror as m9qbptwFMHT0GfEVn5rzOgXy
			for L5kHlN8FoxqdX4GUET,TA1hdM9nO6VDSeHoxEPYjK in hyMqnreIP9Zmtf4lzjObSB:
				if L5kHlN8FoxqdX4GUET: pWS2wR71GzXUFyV += avcfIls8w7gk69hYUErHxzQTXtm24j+L5kHlN8FoxqdX4GUET
				else:
					iNTIRZScKp3YHE9jst71fg = cBawilJXvK1m.findall('([!-~]) *$',TA1hdM9nO6VDSeHoxEPYjK)
					if iNTIRZScKp3YHE9jst71fg:
						iNTIRZScKp3YHE9jst71fg = iNTIRZScKp3YHE9jst71fg[0]
						try:
							xxhi1IewD5b8j = m9qbptwFMHT0GfEVn5rzOgXy.MIRRORED[iNTIRZScKp3YHE9jst71fg]
							rrDuvJy4Z7 = cBawilJXvK1m.findall('^( *?)(.*?)( *?)$',TA1hdM9nO6VDSeHoxEPYjK)
							if rrDuvJy4Z7: ztEgUvkMJr0Nab4nqIFh,TA1hdM9nO6VDSeHoxEPYjK,NTpnqi3GHZAxu7kbU8t = rrDuvJy4Z7[0]
							TA1hdM9nO6VDSeHoxEPYjK = ztEgUvkMJr0Nab4nqIFh+xxhi1IewD5b8j+TA1hdM9nO6VDSeHoxEPYjK[:-1]+NTpnqi3GHZAxu7kbU8t
						except: pass
					pWS2wR71GzXUFyV += avcfIls8w7gk69hYUErHxzQTXtm24j+TA1hdM9nO6VDSeHoxEPYjK
			Pe9ETSvwUGBnkC1hO = pWS2wR71GzXUFyV[1:]
			if lHfbysRrUV7m4CLSdkxc382n: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.encode(m6PFtLblInpNZ8x)
		else:
			if lHfbysRrUV7m4CLSdkxc382n: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.decode(m6PFtLblInpNZ8x)
			Pe9ETSvwUGBnkC1hO = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(Pe9ETSvwUGBnkC1hO)
			yuD7Sp8eVg4,VVyhUEWGYS8IJpbrakcKi = Pe9ETSvwUGBnkC1hO,Pe9ETSvwUGBnkC1hO
			if 1:
				AWo36Xasv9N0ugFDnQdxRH,O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C = eHdDoxhJCEPMZFVa2fg,[]
				zTMdkZNXAW8uP1 = Pe9ETSvwUGBnkC1hO.split(avcfIls8w7gk69hYUErHxzQTXtm24j)
				for ZAgYyldXkFa6ehErN1 in zTMdkZNXAW8uP1:
					if not ZAgYyldXkFa6ehErN1:
						if O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C: O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1] += avcfIls8w7gk69hYUErHxzQTXtm24j
						else: O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C.append(eHdDoxhJCEPMZFVa2fg)
						continue
					bbPj1cWQXzne5y = cBawilJXvK1m.findall('[!-~]',ZAgYyldXkFa6ehErN1[0])
					if bbPj1cWQXzne5y==AWo36Xasv9N0ugFDnQdxRH and O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C: O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1] += avcfIls8w7gk69hYUErHxzQTXtm24j+ZAgYyldXkFa6ehErN1
					else:
						if O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C:
							qT0snkVeQ6GZgLjC3B7E = cBawilJXvK1m.findall('[^!-~]',O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1])
							if qT0snkVeQ6GZgLjC3B7E:
								O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1] = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1])
								VdgbxBP96Mcku8T = cBawilJXvK1m.findall('^ +',O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1])
								if VdgbxBP96Mcku8T: O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1] = O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1].lstrip(avcfIls8w7gk69hYUErHxzQTXtm24j)+VdgbxBP96Mcku8T[0]
						O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C.append(ZAgYyldXkFa6ehErN1)
					AWo36Xasv9N0ugFDnQdxRH = bbPj1cWQXzne5y
				if O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C: O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1] = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C[-1])
				Pe9ETSvwUGBnkC1hO = avcfIls8w7gk69hYUErHxzQTXtm24j.join(O1lMbXVgABeK5ZDPr9afjQ4Rck6Y0C)
			if lHfbysRrUV7m4CLSdkxc382n: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.encode(m6PFtLblInpNZ8x)
	return Pe9ETSvwUGBnkC1hO
def OlBdSZrE3IyjiauAPLv(fZ5HWDazKBS4,Xxln0f9uEpZMkeh8VyQ2F1j5NzYA,nPIDxSkR36ab):
	IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,IH0pbTJuEG3isdZSnq8mXoY1,uG7Dqf4cRgCUor2x0QhKekE,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 = fZ5HWDazKBS4
	tWi3JH8rRhxcgnYuMVUK = int(tWi3JH8rRhxcgnYuMVUK)
	ppHBxNFyag2fnhbLQvGEI60jPzs = cBawilJXvK1m.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
	if ppHBxNFyag2fnhbLQvGEI60jPzs:
		ppHBxNFyag2fnhbLQvGEI60jPzs,z8eWxBmkrfKwilSbtpaZALVR,urFonl8djW0vbAz45 = ppHBxNFyag2fnhbLQvGEI60jPzs[0]
		Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(ppHBxNFyag2fnhbLQvGEI60jPzs,eHdDoxhJCEPMZFVa2fg)
	Ha6k1j2ucy = Pe9ETSvwUGBnkC1hO
	uuwei53S0EcsJfjM7IZD2PNXn = cBawilJXvK1m.findall('^_(\w\w\w)_(.*?)$',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
	if uuwei53S0EcsJfjM7IZD2PNXn:
		uuwei53S0EcsJfjM7IZD2PNXn,Pe9ETSvwUGBnkC1hO = uuwei53S0EcsJfjM7IZD2PNXn[0]
		Xgr2EYqJy9LVvujC63HkmpfnI = '_MOD_' in Pe9ETSvwUGBnkC1hO
		C47G3hXaRMFLfOAEpV = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder'
		if Xgr2EYqJy9LVvujC63HkmpfnI and C47G3hXaRMFLfOAEpV: i5YMPKuS1WUQ4xctTE6rbJvD = ';'
		elif Xgr2EYqJy9LVvujC63HkmpfnI and not C47G3hXaRMFLfOAEpV: i5YMPKuS1WUQ4xctTE6rbJvD = cUKTayqdnW0
		elif not Xgr2EYqJy9LVvujC63HkmpfnI and C47G3hXaRMFLfOAEpV: i5YMPKuS1WUQ4xctTE6rbJvD = ','
		elif not Xgr2EYqJy9LVvujC63HkmpfnI and not C47G3hXaRMFLfOAEpV: i5YMPKuS1WUQ4xctTE6rbJvD = avcfIls8w7gk69hYUErHxzQTXtm24j
		Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace('_MOD_',eHdDoxhJCEPMZFVa2fg)
		uuwei53S0EcsJfjM7IZD2PNXn = i5YMPKuS1WUQ4xctTE6rbJvD+SbyWQGMDnV+uuwei53S0EcsJfjM7IZD2PNXn+' [/COLOR]'
	else: uuwei53S0EcsJfjM7IZD2PNXn = eHdDoxhJCEPMZFVa2fg
	if ppHBxNFyag2fnhbLQvGEI60jPzs:
		if lHfbysRrUV7m4CLSdkxc382n:
			ppHBxNFyag2fnhbLQvGEI60jPzs = OR97bMGecfgDCqux3YdAZ6y+z8eWxBmkrfKwilSbtpaZALVR+avcfIls8w7gk69hYUErHxzQTXtm24j+urFonl8djW0vbAz45+Nat0Dx9puRUWCsgz6JyFhY3
			if uuwei53S0EcsJfjM7IZD2PNXn: Pe9ETSvwUGBnkC1hO = ppHBxNFyag2fnhbLQvGEI60jPzs+avcfIls8w7gk69hYUErHxzQTXtm24j+EigLDrG278jQVcmy+uuwei53S0EcsJfjM7IZD2PNXn+Pe9ETSvwUGBnkC1hO
			else: Pe9ETSvwUGBnkC1hO = ppHBxNFyag2fnhbLQvGEI60jPzs+EigLDrG278jQVcmy+Pe9ETSvwUGBnkC1hO+avcfIls8w7gk69hYUErHxzQTXtm24j
		elif WHjh1POtMKlmgiy68RSqb:
			if uuwei53S0EcsJfjM7IZD2PNXn:
				ppHBxNFyag2fnhbLQvGEI60jPzs = OR97bMGecfgDCqux3YdAZ6y+z8eWxBmkrfKwilSbtpaZALVR+avcfIls8w7gk69hYUErHxzQTXtm24j+urFonl8djW0vbAz45+Nat0Dx9puRUWCsgz6JyFhY3
				Pe9ETSvwUGBnkC1hO = ppHBxNFyag2fnhbLQvGEI60jPzs+avcfIls8w7gk69hYUErHxzQTXtm24j+uuwei53S0EcsJfjM7IZD2PNXn+Pe9ETSvwUGBnkC1hO
			else:
				ppHBxNFyag2fnhbLQvGEI60jPzs = OR97bMGecfgDCqux3YdAZ6y+urFonl8djW0vbAz45+avcfIls8w7gk69hYUErHxzQTXtm24j+z8eWxBmkrfKwilSbtpaZALVR+Nat0Dx9puRUWCsgz6JyFhY3
				Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO+avcfIls8w7gk69hYUErHxzQTXtm24j+EigLDrG278jQVcmy+ppHBxNFyag2fnhbLQvGEI60jPzs
	elif uuwei53S0EcsJfjM7IZD2PNXn:
		Pe9ETSvwUGBnkC1hO = UUPfIh4zdlVx1GMuT(Pe9ETSvwUGBnkC1hO,uuwei53S0EcsJfjM7IZD2PNXn)
		Pe9ETSvwUGBnkC1hO = uuwei53S0EcsJfjM7IZD2PNXn+Pe9ETSvwUGBnkC1hO
	fZ5HWDazKBS4 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Ha6k1j2ucy,Nn360bq79W2kzUt,str(tWi3JH8rRhxcgnYuMVUK),Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,IH0pbTJuEG3isdZSnq8mXoY1,uG7Dqf4cRgCUor2x0QhKekE,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4
	zm0RvASoVYrQWxdOUbM = {'type':eHdDoxhJCEPMZFVa2fg,'mode':eHdDoxhJCEPMZFVa2fg,'url':eHdDoxhJCEPMZFVa2fg,'text':eHdDoxhJCEPMZFVa2fg,'page':eHdDoxhJCEPMZFVa2fg,'name':eHdDoxhJCEPMZFVa2fg,'image':eHdDoxhJCEPMZFVa2fg,'context':eHdDoxhJCEPMZFVa2fg,'infodict':eHdDoxhJCEPMZFVa2fg}
	zm0RvASoVYrQWxdOUbM['name'] = vFDQstemyYANa(Ha6k1j2ucy)
	zm0RvASoVYrQWxdOUbM['type'] = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	zm0RvASoVYrQWxdOUbM['mode'] = str(tWi3JH8rRhxcgnYuMVUK).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder' and IH0pbTJuEG3isdZSnq8mXoY1: zm0RvASoVYrQWxdOUbM['page'] = vFDQstemyYANa(IH0pbTJuEG3isdZSnq8mXoY1.strip(avcfIls8w7gk69hYUErHxzQTXtm24j))
	if GsPYQbREvLAFw3aJ5XghmV: zm0RvASoVYrQWxdOUbM['context'] = GsPYQbREvLAFw3aJ5XghmV.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	if uG7Dqf4cRgCUor2x0QhKekE: zm0RvASoVYrQWxdOUbM['text'] = vFDQstemyYANa(uG7Dqf4cRgCUor2x0QhKekE.strip(avcfIls8w7gk69hYUErHxzQTXtm24j))
	if Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV: zm0RvASoVYrQWxdOUbM['image'] = vFDQstemyYANa(Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV.strip(avcfIls8w7gk69hYUErHxzQTXtm24j))
	if ICOyNkVjwdXS5TFKH6WgZAn4:
		ICOyNkVjwdXS5TFKH6WgZAn4 = str(ICOyNkVjwdXS5TFKH6WgZAn4)
		zm0RvASoVYrQWxdOUbM['infodict'] = vFDQstemyYANa(ICOyNkVjwdXS5TFKH6WgZAn4.strip(avcfIls8w7gk69hYUErHxzQTXtm24j))
		ICOyNkVjwdXS5TFKH6WgZAn4 = eval(ICOyNkVjwdXS5TFKH6WgZAn4)
	else: ICOyNkVjwdXS5TFKH6WgZAn4 = {}
	if Nn360bq79W2kzUt: zm0RvASoVYrQWxdOUbM['url'] = vFDQstemyYANa(Nn360bq79W2kzUt.strip(avcfIls8w7gk69hYUErHxzQTXtm24j))
	u89Kby5RflP = {'name':eHdDoxhJCEPMZFVa2fg,'context_menu':eHdDoxhJCEPMZFVa2fg,'plot':eHdDoxhJCEPMZFVa2fg,'stars':eHdDoxhJCEPMZFVa2fg,'image':eHdDoxhJCEPMZFVa2fg,'type':eHdDoxhJCEPMZFVa2fg,'isFolder':eHdDoxhJCEPMZFVa2fg,'newpath':eHdDoxhJCEPMZFVa2fg,'duration':eHdDoxhJCEPMZFVa2fg}
	i8PWSQgJeyRGcutMNHdjrmT7aOY = []
	vRoPaF3rshnDHilOSW2Y0t8Bx = 'plugin://'+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+'/?type='+zm0RvASoVYrQWxdOUbM['type']+'&mode='+zm0RvASoVYrQWxdOUbM['mode']
	if zm0RvASoVYrQWxdOUbM['page']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&page='+zm0RvASoVYrQWxdOUbM['page']
	if zm0RvASoVYrQWxdOUbM['name']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&name='+zm0RvASoVYrQWxdOUbM['name']
	if zm0RvASoVYrQWxdOUbM['text']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&text='+zm0RvASoVYrQWxdOUbM['text']
	if zm0RvASoVYrQWxdOUbM['infodict']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&infodict='+zm0RvASoVYrQWxdOUbM['infodict']
	if zm0RvASoVYrQWxdOUbM['image']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&image='+zm0RvASoVYrQWxdOUbM['image']
	if zm0RvASoVYrQWxdOUbM['url']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&url='+zm0RvASoVYrQWxdOUbM['url']
	if tWi3JH8rRhxcgnYuMVUK!=265: u89Kby5RflP['favorites'] = True
	else: u89Kby5RflP['favorites'] = False
	if zm0RvASoVYrQWxdOUbM['context']: vRoPaF3rshnDHilOSW2Y0t8Bx += '&context='+zm0RvASoVYrQWxdOUbM['context']
	if tWi3JH8rRhxcgnYuMVUK in [235,238] and IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='live' and 'EPG' in GsPYQbREvLAFw3aJ5XghmV:
		yy1rNcUIMW4DK8Gbk = 'plugin://'+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+'?mode=238&text=SHORT_EPG&url='+Nn360bq79W2kzUt
		J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]البرامج القادمة[/COLOR]'
		SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
		i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	if tWi3JH8rRhxcgnYuMVUK==265:
		bsr1VEvZf7wR = Xxln0f9uEpZMkeh8VyQ2F1j5NzYA(uG7Dqf4cRgCUor2x0QhKekE,True)
		if bsr1VEvZf7wR>0:
			yy1rNcUIMW4DK8Gbk = 'plugin://'+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+'?mode=266&text='+uG7Dqf4cRgCUor2x0QhKekE
			J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]مسح قائمة آخر 50 '+v9vBX6ZiQ0UHxfze8EjG4nmRW(uG7Dqf4cRgCUor2x0QhKekE)+Nat0Dx9puRUWCsgz6JyFhY3
			SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
			i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='video' and tWi3JH8rRhxcgnYuMVUK!=331:
		yy1rNcUIMW4DK8Gbk = vRoPaF3rshnDHilOSW2Y0t8Bx+'&context=6_DOWNLOAD'
		J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]تحميل ملف الفيديو[/COLOR]'
		SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
		i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	if tWi3JH8rRhxcgnYuMVUK==331:
		yy1rNcUIMW4DK8Gbk = vRoPaF3rshnDHilOSW2Y0t8Bx+'&context=6_DELETE'
		J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]حذف ملف الفيديو[/COLOR]'
		SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
		i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder' and tWi3JH8rRhxcgnYuMVUK==540:
		MMvaxyP8wumXzkhQZO9G = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','GLOBALSEARCH_SITES')
		if MMvaxyP8wumXzkhQZO9G:
			yy1rNcUIMW4DK8Gbk = 'plugin://'+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+'?context=7'
			J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]مسح جميع كلمات البحث[/COLOR]'
			SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
			i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	bVs3m8BXrpg1uGv = [9990,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762]
	if tWi3JH8rRhxcgnYuMVUK not in bVs3m8BXrpg1uGv:
		yy1rNcUIMW4DK8Gbk = 'plugin://'+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+'?context=8&mode=260'
		J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]القائمة الرئيسية[/COLOR]'
		SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
		i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	T53SRCOV7unM1 = [0,150,160,170,190,260,280,330,340,410,500,520,530,560,760]
	if tWi3JH8rRhxcgnYuMVUK%10 and tWi3JH8rRhxcgnYuMVUK!=9990:
		L54pmX0DWON = tWi3JH8rRhxcgnYuMVUK-tWi3JH8rRhxcgnYuMVUK%10
		if L54pmX0DWON==280: L54pmX0DWON = 230
		if L54pmX0DWON==410: L54pmX0DWON = 400
		if L54pmX0DWON==520: L54pmX0DWON = 510
		if L54pmX0DWON not in T53SRCOV7unM1:
			yy1rNcUIMW4DK8Gbk = 'plugin://'+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+'?context=8&mode='+str(L54pmX0DWON)
			J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]قائمة الموقع[/COLOR]'
			SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
			i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	yy1rNcUIMW4DK8Gbk = vRoPaF3rshnDHilOSW2Y0t8Bx+'&context=9'
	J8JpjAWBGZtV3oYdIaQRiFleLM20S = '[COLOR FFFFFF00]تحديث القائمة[/COLOR]'
	SduM4J6G9tv8BAor1WqnhEiz7Kxw0X = (J8JpjAWBGZtV3oYdIaQRiFleLM20S,'RunPlugin('+yy1rNcUIMW4DK8Gbk+')')
	i8PWSQgJeyRGcutMNHdjrmT7aOY.append(SduM4J6G9tv8BAor1WqnhEiz7Kxw0X)
	if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 in ['link','video','live']: HHVC1R09zBAPyhMoprkFXfU3WnEIwD = False
	elif IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='folder': HHVC1R09zBAPyhMoprkFXfU3WnEIwD = True
	u89Kby5RflP['name'] = Pe9ETSvwUGBnkC1hO
	u89Kby5RflP['context_menu'] = i8PWSQgJeyRGcutMNHdjrmT7aOY
	if 'plot' in list(ICOyNkVjwdXS5TFKH6WgZAn4.keys()): u89Kby5RflP['plot'] = ICOyNkVjwdXS5TFKH6WgZAn4['plot']
	if 'stars' in list(ICOyNkVjwdXS5TFKH6WgZAn4.keys()): u89Kby5RflP['stars'] = ICOyNkVjwdXS5TFKH6WgZAn4['stars']
	if Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV: u89Kby5RflP['image'] = Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV
	if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='video' and IH0pbTJuEG3isdZSnq8mXoY1:
		slaTNFr0xXbBPyG5ndKCevfZ = cBawilJXvK1m.findall('[\d:]+',IH0pbTJuEG3isdZSnq8mXoY1,cBawilJXvK1m.DOTALL)
		if slaTNFr0xXbBPyG5ndKCevfZ:
			slaTNFr0xXbBPyG5ndKCevfZ = '0:0:0:0:0:'+slaTNFr0xXbBPyG5ndKCevfZ[0]
			bRaH8UFOVKAN1MBX3J05ynuGqjeIf,nHBLcs17mVutGxYZf,LB59lcSWoZsG4X,ZCEbm6lnKTyrGNDO5AoIJvxS9V,uaQzZlIxhcMHSsCG8N = slaTNFr0xXbBPyG5ndKCevfZ.rsplit(':',4)
			Hp0uxAokwmGyStMjg9daEf12U = int(nHBLcs17mVutGxYZf)*24*xvjre5b4yREScf+int(LB59lcSWoZsG4X)*xvjre5b4yREScf+int(ZCEbm6lnKTyrGNDO5AoIJvxS9V)*60+int(uaQzZlIxhcMHSsCG8N)
			u89Kby5RflP['duration'] = Hp0uxAokwmGyStMjg9daEf12U
	u89Kby5RflP['type'] = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9
	u89Kby5RflP['isFolder'] = HHVC1R09zBAPyhMoprkFXfU3WnEIwD
	u89Kby5RflP['newpath'] = vRoPaF3rshnDHilOSW2Y0t8Bx
	u89Kby5RflP['menuItem'] = fZ5HWDazKBS4
	u89Kby5RflP['mode'] = tWi3JH8rRhxcgnYuMVUK
	return u89Kby5RflP
def PkJErZ3g15uonzOeUhl2McQR(Xxln0f9uEpZMkeh8VyQ2F1j5NzYA):
	RKjNUOt0aV = []
	from GIBQakgutV import KKbRPTZDQAqiVfHyN,S31TlKtJyE4oU
	nPIDxSkR36ab = KKbRPTZDQAqiVfHyN()
	for fZ5HWDazKBS4 in JXSlk8x495HmgiD:
		u89Kby5RflP = OlBdSZrE3IyjiauAPLv(fZ5HWDazKBS4,Xxln0f9uEpZMkeh8VyQ2F1j5NzYA,nPIDxSkR36ab)
		if u89Kby5RflP['favorites']:
			T5APh3iFCuKYHfp1zX9rBbe2 = S31TlKtJyE4oU(nPIDxSkR36ab,u89Kby5RflP['menuItem'],u89Kby5RflP['newpath'])
			u89Kby5RflP['context_menu'] = T5APh3iFCuKYHfp1zX9rBbe2+u89Kby5RflP['context_menu']
		RKjNUOt0aV.append(u89Kby5RflP)
	return RKjNUOt0aV
def meauliOvdyRxbE(xp7ejmzyYGO9ShDsid6RZ):
	i5YMPKuS1WUQ4xctTE6rbJvD,ggYhVSZ9ITL7Rpm3NAtqPzE, = [],eHdDoxhJCEPMZFVa2fg
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		if not KyujWR9edp0HVxJ: i5YMPKuS1WUQ4xctTE6rbJvD.append(eHdDoxhJCEPMZFVa2fg)
		else: break
	xp7ejmzyYGO9ShDsid6RZ = xp7ejmzyYGO9ShDsid6RZ[len(i5YMPKuS1WUQ4xctTE6rbJvD):]
	bkA4Xjzw7mJa = '\n\n\n\n'.join(xp7ejmzyYGO9ShDsid6RZ)
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('===== ===== =====','000001')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(SbyWQGMDnV,'000002')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(OR97bMGecfgDCqux3YdAZ6y,'000003')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(Nat0Dx9puRUWCsgz6JyFhY3,'000004')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[RIGHT]','000005')
	Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 = 100000
	I76uY2MoSZENOnVzst = {}
	KUJN9cwsjWEa04 = cBawilJXvK1m.findall('http.*?[\r\n ]',bkA4Xjzw7mJa,cBawilJXvK1m.DOTALL)
	for Br7TtWjxmMOsq in KUJN9cwsjWEa04:
		Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 += 1
		bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(Br7TtWjxmMOsq,str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
		I76uY2MoSZENOnVzst[str(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2)] = Br7TtWjxmMOsq
	for eMVgaSfkty1AwQT6Obo in range(0,len(bkA4Xjzw7mJa),4800):
		TOGmEIlboD = bkA4Xjzw7mJa[eMVgaSfkty1AwQT6Obo:eMVgaSfkty1AwQT6Obo+4800]
		QRW3ABgXKOzL51VdTsP = MoO74hKeqm8fFka.getSetting('av.language.code')
		Nn360bq79W2kzUt = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+QRW3ABgXKOzL51VdTsP
		bJ4IumHdZTPlG6 = {'Content-Type':'text/plain'}
		qqbgyNjsMHL23nV7euGfJQ = TOGmEIlboD.encode(m6PFtLblInpNZ8x)
		W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'POST',Nn360bq79W2kzUt,qqbgyNjsMHL23nV7euGfJQ,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if W1B5olYNHxq03IShy.succeeded:
			yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
			m0CuTNHnpFRxahs3 = DIpuHqsKGS3ErJvk9taCRiX80('str',yu26R85ckHMoK3reLVwSd)
			if m0CuTNHnpFRxahs3:
				m0CuTNHnpFRxahs3 = m0CuTNHnpFRxahs3['translation']
				m0CuTNHnpFRxahs3 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(m0CuTNHnpFRxahs3)
				for GWv6itIHy0RUwgQzxbMN in range(len(m0CuTNHnpFRxahs3)):
					ggYhVSZ9ITL7Rpm3NAtqPzE += m0CuTNHnpFRxahs3[GWv6itIHy0RUwgQzxbMN][0]
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000001','===== ===== =====')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000002',SbyWQGMDnV)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000003',OR97bMGecfgDCqux3YdAZ6y)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000004',Nat0Dx9puRUWCsgz6JyFhY3)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000005','[RIGHT]')
	for Wb5BrDZcyQsjJf17PSCnX4EYN6wv2 in list(I76uY2MoSZENOnVzst.keys()):
		Br7TtWjxmMOsq = I76uY2MoSZENOnVzst[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2]
		ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace(Wb5BrDZcyQsjJf17PSCnX4EYN6wv2,Br7TtWjxmMOsq)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.split('\n\n\n\n')
	return i5YMPKuS1WUQ4xctTE6rbJvD+ggYhVSZ9ITL7Rpm3NAtqPzE
def XHKfomhjsncT0pYquC5(xp7ejmzyYGO9ShDsid6RZ):
	i5YMPKuS1WUQ4xctTE6rbJvD,ggYhVSZ9ITL7Rpm3NAtqPzE, = [],eHdDoxhJCEPMZFVa2fg
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		if not KyujWR9edp0HVxJ: i5YMPKuS1WUQ4xctTE6rbJvD.append(eHdDoxhJCEPMZFVa2fg)
		else: break
	xp7ejmzyYGO9ShDsid6RZ = xp7ejmzyYGO9ShDsid6RZ[len(i5YMPKuS1WUQ4xctTE6rbJvD):]
	bkA4Xjzw7mJa = '\\n\\n\\n\\n'.join(xp7ejmzyYGO9ShDsid6RZ)
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('كلا','no')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('استمرار','continue')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('===== ===== =====','000001')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(SbyWQGMDnV,'000002')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(OR97bMGecfgDCqux3YdAZ6y,'000003')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(Nat0Dx9puRUWCsgz6JyFhY3,'000004')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[RIGHT]','000005')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[CENTER]','000006')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[RTL]','000007')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace("'","\\\\\\'")
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('"','\\\\\\"')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(kDUv7ouWrcgMe6OipQJm,'\\n')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(y1fVB2E63aLnJgkWeCZHujY,'\\\\r')
	for eMVgaSfkty1AwQT6Obo in range(0,len(bkA4Xjzw7mJa),4800):
		TOGmEIlboD = bkA4Xjzw7mJa[eMVgaSfkty1AwQT6Obo:eMVgaSfkty1AwQT6Obo+4800]
		Nn360bq79W2kzUt = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		bJ4IumHdZTPlG6 = {'Content-Type':'application/x-www-form-urlencoded'}
		QRW3ABgXKOzL51VdTsP = MoO74hKeqm8fFka.getSetting('av.language.code')
		qqbgyNjsMHL23nV7euGfJQ = 'f.req='+vFDQstemyYANa('[[["MkEWBc","[[\\"'+TOGmEIlboD+'\\",\\"ar\\",\\"'+QRW3ABgXKOzL51VdTsP+'\\",1],[]]",null,"generic"]]]',eHdDoxhJCEPMZFVa2fg)
		qqbgyNjsMHL23nV7euGfJQ = qqbgyNjsMHL23nV7euGfJQ.replace('%5Cn','%5C%5Cn')
		W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'POST',Nn360bq79W2kzUt,qqbgyNjsMHL23nV7euGfJQ,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if W1B5olYNHxq03IShy.succeeded:
			yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
			yu26R85ckHMoK3reLVwSd = yu26R85ckHMoK3reLVwSd.split(kDUv7ouWrcgMe6OipQJm)[-1]
			m0CuTNHnpFRxahs3 = DIpuHqsKGS3ErJvk9taCRiX80('str',yu26R85ckHMoK3reLVwSd)[0][2]
			if m0CuTNHnpFRxahs3:
				m0CuTNHnpFRxahs3 = DIpuHqsKGS3ErJvk9taCRiX80('str',m0CuTNHnpFRxahs3)[1][0][0][5]
				m0CuTNHnpFRxahs3 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(m0CuTNHnpFRxahs3)
				for GWv6itIHy0RUwgQzxbMN in range(len(m0CuTNHnpFRxahs3)):
					ggYhVSZ9ITL7Rpm3NAtqPzE += m0CuTNHnpFRxahs3[GWv6itIHy0RUwgQzxbMN][0]
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('00000','0000').replace('0000','000')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0001','===== ===== =====')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0002',SbyWQGMDnV)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0003',OR97bMGecfgDCqux3YdAZ6y)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0004',Nat0Dx9puRUWCsgz6JyFhY3)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0005','[RIGHT]')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0006','[CENTER]')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0007','[RTL]')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.split('\n\n\n\n')
	return i5YMPKuS1WUQ4xctTE6rbJvD+ggYhVSZ9ITL7Rpm3NAtqPzE
def X01YZ5LnEdzRSCIA2OgKrm(xp7ejmzyYGO9ShDsid6RZ):
	i5YMPKuS1WUQ4xctTE6rbJvD,lh4xNwFefZP82LDJCX0MoUO = [],[]
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		if not KyujWR9edp0HVxJ: i5YMPKuS1WUQ4xctTE6rbJvD.append(eHdDoxhJCEPMZFVa2fg)
		else: break
	xp7ejmzyYGO9ShDsid6RZ = xp7ejmzyYGO9ShDsid6RZ[len(i5YMPKuS1WUQ4xctTE6rbJvD):]
	bkA4Xjzw7mJa = '\n\n\n\n'.join(xp7ejmzyYGO9ShDsid6RZ)
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('كلا','no')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('استمرار','continue')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('أدناه','below')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(SbyWQGMDnV,'00001')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(OR97bMGecfgDCqux3YdAZ6y,'00002')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(Nat0Dx9puRUWCsgz6JyFhY3,'00003')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('=====','00004')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(',','00005')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[RTL]','00009')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[CENTER]','0000A')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(y1fVB2E63aLnJgkWeCZHujY,'0000B')
	xp7ejmzyYGO9ShDsid6RZ = bkA4Xjzw7mJa.split(kDUv7ouWrcgMe6OipQJm)
	bkA4Xjzw7mJa,ggYhVSZ9ITL7Rpm3NAtqPzE = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
		if len(bkA4Xjzw7mJa+KyujWR9edp0HVxJ)<1800: bkA4Xjzw7mJa += kDUv7ouWrcgMe6OipQJm+KyujWR9edp0HVxJ
		else:
			lh4xNwFefZP82LDJCX0MoUO.append(bkA4Xjzw7mJa)
			bkA4Xjzw7mJa = KyujWR9edp0HVxJ
	lh4xNwFefZP82LDJCX0MoUO.append(bkA4Xjzw7mJa)
	import json as Z9rkmwbQ7V2DvgoR0XOLTquNKPls
	for KyujWR9edp0HVxJ in lh4xNwFefZP82LDJCX0MoUO:
		bJ4IumHdZTPlG6 = {'Content-Type':'application/json','User-Agent':eHdDoxhJCEPMZFVa2fg}
		Nn360bq79W2kzUt = 'https://api.reverso.net/translate/v1/translation'
		QRW3ABgXKOzL51VdTsP = MoO74hKeqm8fFka.getSetting('av.language.code')
		qqbgyNjsMHL23nV7euGfJQ = {"format":"text","from":"ara","to":QRW3ABgXKOzL51VdTsP,"input":KyujWR9edp0HVxJ,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		qqbgyNjsMHL23nV7euGfJQ = Z9rkmwbQ7V2DvgoR0XOLTquNKPls.dumps(qqbgyNjsMHL23nV7euGfJQ)
		W1B5olYNHxq03IShy = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,'POST',Nn360bq79W2kzUt,qqbgyNjsMHL23nV7euGfJQ,bJ4IumHdZTPlG6,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'LIBRARY-REVERSO_TRANSLATE-1st')
		if W1B5olYNHxq03IShy.succeeded:
			yu26R85ckHMoK3reLVwSd = W1B5olYNHxq03IShy.content
			yu26R85ckHMoK3reLVwSd = DIpuHqsKGS3ErJvk9taCRiX80('dict',yu26R85ckHMoK3reLVwSd)
			ggYhVSZ9ITL7Rpm3NAtqPzE += kDUv7ouWrcgMe6OipQJm+eHdDoxhJCEPMZFVa2fg.join(yu26R85ckHMoK3reLVwSd['translation'])
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE[2:]
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000000','00000').replace('00000','0000').replace('0000','000')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0001',SbyWQGMDnV)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0002',OR97bMGecfgDCqux3YdAZ6y)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0003',Nat0Dx9puRUWCsgz6JyFhY3)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0004','=====')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0005',',')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('0009','[RTL]')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000A','[CENTER]')
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.replace('000B',y1fVB2E63aLnJgkWeCZHujY)
	ggYhVSZ9ITL7Rpm3NAtqPzE = ggYhVSZ9ITL7Rpm3NAtqPzE.split('\n\n\n\n')
	return i5YMPKuS1WUQ4xctTE6rbJvD+ggYhVSZ9ITL7Rpm3NAtqPzE
def D7bPxVELdU1J5pRC6vaQt(xp7ejmzyYGO9ShDsid6RZ):
	A50idMBcCI2y = MoO74hKeqm8fFka.getSetting('av.language.translate')
	if not A50idMBcCI2y or not xp7ejmzyYGO9ShDsid6RZ: return xp7ejmzyYGO9ShDsid6RZ
	eyx7SQN1RLtvjIkHcd5m436rBKOb = MoO74hKeqm8fFka.getSetting('av.language.provider')
	QRW3ABgXKOzL51VdTsP = MoO74hKeqm8fFka.getSetting('av.language.code')
	qR2NXUPnL8tbHxW0ViOs = QRW3ABgXKOzL51VdTsP+'__'+str(xp7ejmzyYGO9ShDsid6RZ)
	MoO74hKeqm8fFka.setSetting('av.language.translate',eHdDoxhJCEPMZFVa2fg)
	ggYhVSZ9ITL7Rpm3NAtqPzE = EeZHTwQUW2BuvJyIh(pyifuNFdxe,'list','TRANSLATE_'+eyx7SQN1RLtvjIkHcd5m436rBKOb,qR2NXUPnL8tbHxW0ViOs)
	if not ggYhVSZ9ITL7Rpm3NAtqPzE:
		if eyx7SQN1RLtvjIkHcd5m436rBKOb=='GOOGLE': ggYhVSZ9ITL7Rpm3NAtqPzE = XHKfomhjsncT0pYquC5(xp7ejmzyYGO9ShDsid6RZ)
		elif eyx7SQN1RLtvjIkHcd5m436rBKOb=='REVERSO': ggYhVSZ9ITL7Rpm3NAtqPzE = X01YZ5LnEdzRSCIA2OgKrm(xp7ejmzyYGO9ShDsid6RZ)
		elif eyx7SQN1RLtvjIkHcd5m436rBKOb=='GLOSBE': ggYhVSZ9ITL7Rpm3NAtqPzE = meauliOvdyRxbE(xp7ejmzyYGO9ShDsid6RZ)
		if len(xp7ejmzyYGO9ShDsid6RZ)==len(ggYhVSZ9ITL7Rpm3NAtqPzE):
			CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,'TRANSLATE_'+eyx7SQN1RLtvjIkHcd5m436rBKOb,qR2NXUPnL8tbHxW0ViOs,ggYhVSZ9ITL7Rpm3NAtqPzE,oTdjz7uhFYDxOvgaRnJcP5X)
		else:
			ggYhVSZ9ITL7Rpm3NAtqPzE = xp7ejmzyYGO9ShDsid6RZ
			dqKGMYgJxSF8Ub1kotlsP936Ww7B('الترجمة فشلت','Translation Failed')
	MoO74hKeqm8fFka.setSetting('av.language.translate','1')
	return ggYhVSZ9ITL7Rpm3NAtqPzE
def Dh6UHaz9c37Rf2lQ(fZ5HWDazKBS4,RKjNUOt0aV,UUQjG45NHzSqZuDe2vYIdTMlJOyc,pQ3Xx0g8HmhPUrnD179syf,doinL6ur8UyzPh3Dv):
	IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 = fZ5HWDazKBS4
	E6RvGJokqCaIyOVS0Z4ezh = []
	A50idMBcCI2y = MoO74hKeqm8fFka.getSetting('av.language.translate')
	if A50idMBcCI2y:
		v4vnxVs3akN1j,G3TfmezBnNL0FwdiuX5AgYJ,L8SEm57FY1oikpaQrsdc = [],[],[]
		if not E6RvGJokqCaIyOVS0Z4ezh:
			for u89Kby5RflP in RKjNUOt0aV:
				Pe9ETSvwUGBnkC1hO = u89Kby5RflP['name'].replace(EigLDrG278jQVcmy,eHdDoxhJCEPMZFVa2fg).replace(Gd4fNUpaveYtQDxi,eHdDoxhJCEPMZFVa2fg)
				ppHBxNFyag2fnhbLQvGEI60jPzs = cBawilJXvK1m.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
				if ppHBxNFyag2fnhbLQvGEI60jPzs:
					i5YMPKuS1WUQ4xctTE6rbJvD,z8eWxBmkrfKwilSbtpaZALVR,urFonl8djW0vbAz45,pphAT0S9wnjNGsQUfl6WExoc7b,Pe9ETSvwUGBnkC1hO = ppHBxNFyag2fnhbLQvGEI60jPzs[0]
					ppHBxNFyag2fnhbLQvGEI60jPzs = i5YMPKuS1WUQ4xctTE6rbJvD+z8eWxBmkrfKwilSbtpaZALVR+avcfIls8w7gk69hYUErHxzQTXtm24j+urFonl8djW0vbAz45+pphAT0S9wnjNGsQUfl6WExoc7b+avcfIls8w7gk69hYUErHxzQTXtm24j
				else:
					ppHBxNFyag2fnhbLQvGEI60jPzs = cBawilJXvK1m.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
					if ppHBxNFyag2fnhbLQvGEI60jPzs:
						Pe9ETSvwUGBnkC1hO,i5YMPKuS1WUQ4xctTE6rbJvD,urFonl8djW0vbAz45,z8eWxBmkrfKwilSbtpaZALVR,pphAT0S9wnjNGsQUfl6WExoc7b = ppHBxNFyag2fnhbLQvGEI60jPzs[0]
						ppHBxNFyag2fnhbLQvGEI60jPzs = i5YMPKuS1WUQ4xctTE6rbJvD+z8eWxBmkrfKwilSbtpaZALVR+avcfIls8w7gk69hYUErHxzQTXtm24j+urFonl8djW0vbAz45+pphAT0S9wnjNGsQUfl6WExoc7b+avcfIls8w7gk69hYUErHxzQTXtm24j
					else: ppHBxNFyag2fnhbLQvGEI60jPzs = eHdDoxhJCEPMZFVa2fg
				uuwei53S0EcsJfjM7IZD2PNXn = cBawilJXvK1m.findall('^(.\[COLOR FFC89008\]\w\w\w \[/COLOR\])(.*?)$',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
				if uuwei53S0EcsJfjM7IZD2PNXn: uuwei53S0EcsJfjM7IZD2PNXn,Pe9ETSvwUGBnkC1hO = uuwei53S0EcsJfjM7IZD2PNXn[0]
				else: uuwei53S0EcsJfjM7IZD2PNXn = eHdDoxhJCEPMZFVa2fg
				v4vnxVs3akN1j.append(ppHBxNFyag2fnhbLQvGEI60jPzs+uuwei53S0EcsJfjM7IZD2PNXn)
				G3TfmezBnNL0FwdiuX5AgYJ.append(Pe9ETSvwUGBnkC1hO)
			L8SEm57FY1oikpaQrsdc = D7bPxVELdU1J5pRC6vaQt(G3TfmezBnNL0FwdiuX5AgYJ)
			if L8SEm57FY1oikpaQrsdc:
				for eMVgaSfkty1AwQT6Obo in range(len(RKjNUOt0aV)):
					u89Kby5RflP = RKjNUOt0aV[eMVgaSfkty1AwQT6Obo]
					u89Kby5RflP['name'] = v4vnxVs3akN1j[eMVgaSfkty1AwQT6Obo]+L8SEm57FY1oikpaQrsdc[eMVgaSfkty1AwQT6Obo]
					E6RvGJokqCaIyOVS0Z4ezh.append(u89Kby5RflP)
	if E6RvGJokqCaIyOVS0Z4ezh: RKjNUOt0aV = E6RvGJokqCaIyOVS0Z4ezh
	TTXd1Q7xIBHZEroA,fEInN1cG62xej0vQmWM3BOhJtX,c3suof4rVNJ0L7 = [],0,0
	WPkdKHvyzcVFtxTbBIE = MoO74hKeqm8fFka.getSetting('av.status.menusimages')
	if WPkdKHvyzcVFtxTbBIE!='STOP':
		ZXzpQo2fBi = RRydns1CErYlIhwSx7.path.join(e8j3fyIi05dcPOpkmq,tWi3JH8rRhxcgnYuMVUK)
		try: ot60iUe57CDBJ2qIfH = RRydns1CErYlIhwSx7.listdir(ZXzpQo2fBi)
		except:
			if not RRydns1CErYlIhwSx7.path.exists(ZXzpQo2fBi):
				try: RRydns1CErYlIhwSx7.makedirs(ZXzpQo2fBi)
				except: pass
			ot60iUe57CDBJ2qIfH = []
	DyKFIjg8PhQ6JxTi,U57UGQlLoP3FiObzRMSeN2CfIyw8 = [],0
	for u89Kby5RflP in RKjNUOt0aV:
		if u89Kby5RflP['image']: U57UGQlLoP3FiObzRMSeN2CfIyw8 += 1
		name = u89Kby5RflP['name']
		if name not in DyKFIjg8PhQ6JxTi: DyKFIjg8PhQ6JxTi.append(name)
	aWYCuxRh0gj64I7J8oP3UQ = len(DyKFIjg8PhQ6JxTi)-U57UGQlLoP3FiObzRMSeN2CfIyw8
	if aWYCuxRh0gj64I7J8oP3UQ>=len(ot60iUe57CDBJ2qIfH)+5: dqKGMYgJxSF8Ub1kotlsP936Ww7B('إضافة الكتابة لصور القائمة','انتظار',b8bLFaejUB=500)
	lGO9sfdxm4 = ngMYhROj0pfAaKkHUlDXZEuw('menu_item')
	for u89Kby5RflP in RKjNUOt0aV:
		Pe9ETSvwUGBnkC1hO = u89Kby5RflP['name']
		i8PWSQgJeyRGcutMNHdjrmT7aOY = u89Kby5RflP['context_menu']
		JG3fXI54rxdTsvNpY1kROhAZba7FH = u89Kby5RflP['plot']
		KFhRjPixUZ = u89Kby5RflP['stars']
		Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV = u89Kby5RflP['image']
		IIheJZ2dTAzKtwkMCUlmOGX6PuNR9 = u89Kby5RflP['type']
		slaTNFr0xXbBPyG5ndKCevfZ = u89Kby5RflP['duration']
		HHVC1R09zBAPyhMoprkFXfU3WnEIwD = u89Kby5RflP['isFolder']
		vRoPaF3rshnDHilOSW2Y0t8Bx = u89Kby5RflP['newpath']
		NPxEpoQjdc5XtyBbiuD = VVZgPQ2kYLoKe6jic5AEzqupG.ListItem(Pe9ETSvwUGBnkC1hO)
		NPxEpoQjdc5XtyBbiuD.addContextMenuItems(i8PWSQgJeyRGcutMNHdjrmT7aOY)
		TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe = False if WPkdKHvyzcVFtxTbBIE!='STOP' else True
		if Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV:
			NPxEpoQjdc5XtyBbiuD.setArt({'icon':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'thumb':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'fanart':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'banner':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'clearart':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'poster':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'clearlogo':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,'landscape':Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV})
			TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe = False
		elif not TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe:
			TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe = True
			Pe9ETSvwUGBnkC1hO = r17Z5qKTw3gQ(Pe9ETSvwUGBnkC1hO)
			Pe9ETSvwUGBnkC1hO = gTFGf5IRwYWns8QHcKzoBAvC(Pe9ETSvwUGBnkC1hO)
			uuzSdMsb6KOvRoL4NHX9JQU8 = Pe9ETSvwUGBnkC1hO+'.png'
			iCNFcAtsn8g5VbJ = RRydns1CErYlIhwSx7.path.join(ZXzpQo2fBi,uuzSdMsb6KOvRoL4NHX9JQU8)
			if uuzSdMsb6KOvRoL4NHX9JQU8 in ot60iUe57CDBJ2qIfH:
				NPxEpoQjdc5XtyBbiuD.setArt({'icon':iCNFcAtsn8g5VbJ,'thumb':iCNFcAtsn8g5VbJ,'fanart':iCNFcAtsn8g5VbJ,'banner':iCNFcAtsn8g5VbJ,'clearart':iCNFcAtsn8g5VbJ,'poster':iCNFcAtsn8g5VbJ,'clearlogo':iCNFcAtsn8g5VbJ,'landscape':iCNFcAtsn8g5VbJ})
				TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe = False
			elif fEInN1cG62xej0vQmWM3BOhJtX<50 and c3suof4rVNJ0L7<=3:
				try:
					S5V6pBQn3aXl7ehgstwTdRm4Muc = vbNuHUABJx(lGO9sfdxm4,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Pe9ETSvwUGBnkC1hO,'menu_item','center',False,iCNFcAtsn8g5VbJ)
					NPxEpoQjdc5XtyBbiuD.setArt({'icon':iCNFcAtsn8g5VbJ,'thumb':iCNFcAtsn8g5VbJ,'fanart':iCNFcAtsn8g5VbJ,'banner':iCNFcAtsn8g5VbJ,'clearart':iCNFcAtsn8g5VbJ,'poster':iCNFcAtsn8g5VbJ,'clearlogo':iCNFcAtsn8g5VbJ,'landscape':iCNFcAtsn8g5VbJ})
					fEInN1cG62xej0vQmWM3BOhJtX += 1
					TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe = False
					ot60iUe57CDBJ2qIfH.append(uuzSdMsb6KOvRoL4NHX9JQU8)
				except: c3suof4rVNJ0L7 += 1
		if TTw3mPx5HOjh7XgR9yQVnYrJs6MUZe:
			NPxEpoQjdc5XtyBbiuD.setArt({'icon':E7SBs6g9e82c,'thumb':E7SBs6g9e82c,'fanart':E7SBs6g9e82c,'banner':E7SBs6g9e82c,'clearart':E7SBs6g9e82c,'poster':E7SBs6g9e82c,'clearlogo':E7SBs6g9e82c,'landscape':E7SBs6g9e82c})
		if YB5Segc7IQ<20:
			if JG3fXI54rxdTsvNpY1kROhAZba7FH: NPxEpoQjdc5XtyBbiuD.setInfo('video',{'Plot':JG3fXI54rxdTsvNpY1kROhAZba7FH,'PlotOutline':JG3fXI54rxdTsvNpY1kROhAZba7FH})
			if KFhRjPixUZ: NPxEpoQjdc5XtyBbiuD.setInfo('video',{'Rating':KFhRjPixUZ})
			if not Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV:
				NPxEpoQjdc5XtyBbiuD.setInfo('video',{'Title':Pe9ETSvwUGBnkC1hO})
			if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='video':
				NPxEpoQjdc5XtyBbiuD.setInfo('video',{'mediatype':'movie'})
				if slaTNFr0xXbBPyG5ndKCevfZ: NPxEpoQjdc5XtyBbiuD.setInfo('video',{'duration':slaTNFr0xXbBPyG5ndKCevfZ})
				NPxEpoQjdc5XtyBbiuD.setProperty('IsPlayable','true')
		else:
			jjG5PaEY07zhuqlr8tUnp6Q = NPxEpoQjdc5XtyBbiuD.getVideoInfoTag()
			if KFhRjPixUZ: jjG5PaEY07zhuqlr8tUnp6Q.setRating(float(KFhRjPixUZ))
			if not Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV:
				jjG5PaEY07zhuqlr8tUnp6Q.setTitle(Pe9ETSvwUGBnkC1hO)
			if IIheJZ2dTAzKtwkMCUlmOGX6PuNR9=='video':
				jjG5PaEY07zhuqlr8tUnp6Q.setMediaType('tvshow')
				if slaTNFr0xXbBPyG5ndKCevfZ: jjG5PaEY07zhuqlr8tUnp6Q.setDuration(slaTNFr0xXbBPyG5ndKCevfZ)
				NPxEpoQjdc5XtyBbiuD.setProperty('IsPlayable','true')
		TTXd1Q7xIBHZEroA.append((vRoPaF3rshnDHilOSW2Y0t8Bx,NPxEpoQjdc5XtyBbiuD,HHVC1R09zBAPyhMoprkFXfU3WnEIwD))
	bCfjxP8yo4Qn3trXKNgW1AUl.setContent(ZFsK7DtIkrHGnWQYhUM8P,'tvshows')
	qMV7B13eRXvmOx0A5Gz2aIgfcdH = bCfjxP8yo4Qn3trXKNgW1AUl.addDirectoryItems(ZFsK7DtIkrHGnWQYhUM8P,TTXd1Q7xIBHZEroA)
	bCfjxP8yo4Qn3trXKNgW1AUl.endOfDirectory(ZFsK7DtIkrHGnWQYhUM8P,UUQjG45NHzSqZuDe2vYIdTMlJOyc,pQ3Xx0g8HmhPUrnD179syf,doinL6ur8UyzPh3Dv)
	return qMV7B13eRXvmOx0A5Gz2aIgfcdH
def qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV=eHdDoxhJCEPMZFVa2fg,d9c6BWV3J2bQDMRELgX=eHdDoxhJCEPMZFVa2fg,bkA4Xjzw7mJa=eHdDoxhJCEPMZFVa2fg,GsPYQbREvLAFw3aJ5XghmV=eHdDoxhJCEPMZFVa2fg,ICOyNkVjwdXS5TFKH6WgZAn4={}):
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg).replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace('\t',eHdDoxhJCEPMZFVa2fg)
	Nn360bq79W2kzUt = Nn360bq79W2kzUt.replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg).replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace('\t',eHdDoxhJCEPMZFVa2fg)
	if '_SCRIPT_' in Pe9ETSvwUGBnkC1hO: FO8SKWr40dDexHgbfRUGBi,Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.split('_SCRIPT_',1)
	else: FO8SKWr40dDexHgbfRUGBi,Pe9ETSvwUGBnkC1hO = eHdDoxhJCEPMZFVa2fg,Pe9ETSvwUGBnkC1hO
	if FO8SKWr40dDexHgbfRUGBi:
		NxO8ET5GbgB9MhlRWaP0Udmec = Pe9ETSvwUGBnkC1hO
		if not NxO8ET5GbgB9MhlRWaP0Udmec: NxO8ET5GbgB9MhlRWaP0Udmec = '....'
		elif NxO8ET5GbgB9MhlRWaP0Udmec.count('_')>1: NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.split('_',2)[2]
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace(' ',eHdDoxhJCEPMZFVa2fg)
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('ـ',eHdDoxhJCEPMZFVa2fg).replace('ة','ه').replace('ؤ','و')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('َ',eHdDoxhJCEPMZFVa2fg).replace('ً',eHdDoxhJCEPMZFVa2fg).replace('ُ',eHdDoxhJCEPMZFVa2fg).replace('ٌ',eHdDoxhJCEPMZFVa2fg)
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('ِ',eHdDoxhJCEPMZFVa2fg).replace('ٍ',eHdDoxhJCEPMZFVa2fg).replace('ْ',eHdDoxhJCEPMZFVa2fg).replace('ّ',eHdDoxhJCEPMZFVa2fg)
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('|',eHdDoxhJCEPMZFVa2fg).replace('~',eHdDoxhJCEPMZFVa2fg)
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('اون لاين',eHdDoxhJCEPMZFVa2fg).replace('سيما لايت',eHdDoxhJCEPMZFVa2fg)
		QfFp4CUq89lbnuXSVIwAZzy = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(iS0cNMfBdTqAmJX3zh8nr4Y9 in NxO8ET5GbgB9MhlRWaP0Udmec for iS0cNMfBdTqAmJX3zh8nr4Y9 in QfFp4CUq89lbnuXSVIwAZzy): NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('ال',eHdDoxhJCEPMZFVa2fg)
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		NxO8ET5GbgB9MhlRWaP0Udmec = NxO8ET5GbgB9MhlRWaP0Udmec.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		FO8SKWr40dDexHgbfRUGBi = '_LST_'+v9vBX6ZiQ0UHxfze8EjG4nmRW(FO8SKWr40dDexHgbfRUGBi)
		if NxO8ET5GbgB9MhlRWaP0Udmec not in list(r3gYWiShzyHFb9MnPD1G8kfBvjp.keys()): r3gYWiShzyHFb9MnPD1G8kfBvjp[NxO8ET5GbgB9MhlRWaP0Udmec] = {}
		r3gYWiShzyHFb9MnPD1G8kfBvjp[NxO8ET5GbgB9MhlRWaP0Udmec][FO8SKWr40dDexHgbfRUGBi] = [IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4]
	JXSlk8x495HmgiD.append([IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4])
	return
def zJRbA1YW2Eor(wvrOB3T7GpdoPnicUgxtjb46AEJCSq):
	if WHjh1POtMKlmgiy68RSqb: from html import unescape as _P7dHraguO0FsTDcGRp
	else:
		from HTMLParser import HTMLParser as w67wkn8VOPFqa3
		_P7dHraguO0FsTDcGRp = w67wkn8VOPFqa3().unescape
	if '&' in wvrOB3T7GpdoPnicUgxtjb46AEJCSq and ';' in wvrOB3T7GpdoPnicUgxtjb46AEJCSq:
		if lHfbysRrUV7m4CLSdkxc382n: wvrOB3T7GpdoPnicUgxtjb46AEJCSq = wvrOB3T7GpdoPnicUgxtjb46AEJCSq.decode(m6PFtLblInpNZ8x)
		wvrOB3T7GpdoPnicUgxtjb46AEJCSq = _P7dHraguO0FsTDcGRp(wvrOB3T7GpdoPnicUgxtjb46AEJCSq)
		if lHfbysRrUV7m4CLSdkxc382n: wvrOB3T7GpdoPnicUgxtjb46AEJCSq = wvrOB3T7GpdoPnicUgxtjb46AEJCSq.encode(m6PFtLblInpNZ8x)
	return wvrOB3T7GpdoPnicUgxtjb46AEJCSq
def XXcKxHD7jfmMoyQ0dZRCV1sPzv2(wvrOB3T7GpdoPnicUgxtjb46AEJCSq):
	if '\\u' in wvrOB3T7GpdoPnicUgxtjb46AEJCSq:
		if lHfbysRrUV7m4CLSdkxc382n: wvrOB3T7GpdoPnicUgxtjb46AEJCSq = wvrOB3T7GpdoPnicUgxtjb46AEJCSq.decode('unicode_escape','ignore').encode(m6PFtLblInpNZ8x)
		elif WHjh1POtMKlmgiy68RSqb: wvrOB3T7GpdoPnicUgxtjb46AEJCSq = wvrOB3T7GpdoPnicUgxtjb46AEJCSq.encode(m6PFtLblInpNZ8x).decode('unicode_escape','ignore')
	return wvrOB3T7GpdoPnicUgxtjb46AEJCSq
def Ge4XfaYx3t1(lAhrwzFeLkvnE6xpyfm,zzn5GhdpemvMfHYA,OIjgT4MxL37tuf9DpwYVqa,oYOSQfs6RaLnHhlGjp23C,bkA4Xjzw7mJa,t0tqOadibTQjFXgYDcu91e,hRNITKbg3ZXj,h2TSmLBKxd7optlMNvZF,PfmFrK9L7UpD3k5CJzWOMba):
	IEdKqCVnWbY829 = RRydns1CErYlIhwSx7.path.dirname(PfmFrK9L7UpD3k5CJzWOMba)
	if not RRydns1CErYlIhwSx7.path.exists(IEdKqCVnWbY829):
		try: RRydns1CErYlIhwSx7.makedirs(IEdKqCVnWbY829)
		except: pass
	MVRO510tk39isT = ngMYhROj0pfAaKkHUlDXZEuw(t0tqOadibTQjFXgYDcu91e)
	S5V6pBQn3aXl7ehgstwTdRm4Muc = vbNuHUABJx(MVRO510tk39isT,lAhrwzFeLkvnE6xpyfm,zzn5GhdpemvMfHYA,OIjgT4MxL37tuf9DpwYVqa,oYOSQfs6RaLnHhlGjp23C,bkA4Xjzw7mJa,t0tqOadibTQjFXgYDcu91e,hRNITKbg3ZXj,h2TSmLBKxd7optlMNvZF,PfmFrK9L7UpD3k5CJzWOMba)
	return S5V6pBQn3aXl7ehgstwTdRm4Muc
def ngMYhROj0pfAaKkHUlDXZEuw(t0tqOadibTQjFXgYDcu91e):
	xxDMVlwE6QYy = 5
	x8cuLmWsa5J1lv90ENKPqGQo7gZrR = 20
	QCexIvpwhOoRtXkFHJq51Bz9AK = 20
	EMZpy0QeH7JxwL = 0
	R80CJKru3BAQDxh4UPck = 'center'
	oiSnx50OWLDQGc9YvNBf = 0
	XogTpwVLvNQiY = 19
	oJkazmZlrWRN3M4d7hsDYjAp6T = 30
	Sh5OEWgcKnktXF7UGPVB = 8
	b4Wvg92C3LXJycN = True
	REbQpLO4BZSnXcFgK = 375
	D3xJ0LgaNEm86Fi1ZlYSqjh = 410
	kmP4A28DMcgC1UNeJhYyR = 50
	VVdEoH58SBYmyaJMtrQRAzCF = 280
	Y6Ndq3RtDH80L2VlT = 28
	OZ3J7WEpQrNDHKj = 5
	yyDLeV1cafXj = 0
	gguBiKE8I5vkM1ZwTCRlUb0n9qd = 31
	TxhSCdwGJvUumNs5c = [36,32,28]
	from PIL import ImageDraw as H28fb4Yg1GA3,ImageFont as UcrOzDRH470eTvC6dKF5mAf9PV,Image as aQhjb3I1CW
	if 'notification' in t0tqOadibTQjFXgYDcu91e:
		if t0tqOadibTQjFXgYDcu91e=='notification_regular':
			sMiXmBtcnRpADrwhGbx3jK0gadWo = 117
			R80CJKru3BAQDxh4UPck = 'left'
			b4Wvg92C3LXJycN = False
		elif t0tqOadibTQjFXgYDcu91e=='notification_auto':
			sMiXmBtcnRpADrwhGbx3jK0gadWo = 'UPPER'
			R80CJKru3BAQDxh4UPck = 'right'
			EMZpy0QeH7JxwL = 10
		IaEYVOlc6t2oDi0z3NsMLShQnC = 720
		TxhSCdwGJvUumNs5c = [33,33,33]
		QCexIvpwhOoRtXkFHJq51Bz9AK = 20
		x8cuLmWsa5J1lv90ENKPqGQo7gZrR = 0
		oJkazmZlrWRN3M4d7hsDYjAp6T = 20
		XogTpwVLvNQiY = 35
	elif t0tqOadibTQjFXgYDcu91e=='menu_item':
		TxhSCdwGJvUumNs5c,IaEYVOlc6t2oDi0z3NsMLShQnC,sMiXmBtcnRpADrwhGbx3jK0gadWo = [30,30,30],200,250
		oiSnx50OWLDQGc9YvNBf,oJkazmZlrWRN3M4d7hsDYjAp6T,XogTpwVLvNQiY, = 0,-10,-30
		x8cuLmWsa5J1lv90ENKPqGQo7gZrR = 0
		klpqsTbM34jHhm96tBGZC21eu = aQhjb3I1CW.open(E7SBs6g9e82c)
		qqGSHJPUXazWw = aQhjb3I1CW.new('RGBA',(IaEYVOlc6t2oDi0z3NsMLShQnC,sMiXmBtcnRpADrwhGbx3jK0gadWo),(255,0,0,255))
	elif t0tqOadibTQjFXgYDcu91e=='confirm_smallfont': TxhSCdwGJvUumNs5c,sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = [28,24,20],500,900
	elif t0tqOadibTQjFXgYDcu91e=='confirm_mediumfont': TxhSCdwGJvUumNs5c,sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = [32,28,24],500,900
	elif t0tqOadibTQjFXgYDcu91e=='confirm_bigfont': TxhSCdwGJvUumNs5c,sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = [36,32,28],500,900
	elif t0tqOadibTQjFXgYDcu91e=='textview_bigfont': sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = 740,1270
	elif t0tqOadibTQjFXgYDcu91e=='textview_bigfont_long': sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = 'UPPER',1270
	elif t0tqOadibTQjFXgYDcu91e=='textview_smallfont': TxhSCdwGJvUumNs5c,sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = [28,23,18],740,1270
	elif t0tqOadibTQjFXgYDcu91e=='textview_smallfont_long': TxhSCdwGJvUumNs5c,sMiXmBtcnRpADrwhGbx3jK0gadWo,IaEYVOlc6t2oDi0z3NsMLShQnC = [28,23,18],'UPPER',1270
	D5GK1iBuXfwZp7QT8vnWIsrEh,hhUiZBn7Feb1Iw,j2v7WrqAQ1Nnm6xwKs = TxhSCdwGJvUumNs5c
	mdub5Ua39AhyoPK1G2gfnJslqLWO = UcrOzDRH470eTvC6dKF5mAf9PV.truetype(yyeQJMcPdvbC0,size=D5GK1iBuXfwZp7QT8vnWIsrEh)
	Ho8lwgctJQ6WXK3 = UcrOzDRH470eTvC6dKF5mAf9PV.truetype(yyeQJMcPdvbC0,size=hhUiZBn7Feb1Iw)
	kWUR6ztA8vngKsqmu19l = UcrOzDRH470eTvC6dKF5mAf9PV.truetype(yyeQJMcPdvbC0,size=j2v7WrqAQ1Nnm6xwKs)
	XZpR4u3Q9xmLko0VhCcHvKr1zI2 = IaEYVOlc6t2oDi0z3NsMLShQnC-oJkazmZlrWRN3M4d7hsDYjAp6T*2
	U7UXFLVIMKrO = aQhjb3I1CW.new('RGBA',(XZpR4u3Q9xmLko0VhCcHvKr1zI2,100),(255,255,255,0))
	x9him6LyA05DkbWaISJ = H28fb4Yg1GA3.Draw(U7UXFLVIMKrO)
	dhyqbXKAzpPxCSWJ76VHO,ATh2DvXBmHOUNKs3cMGw6WRJ7VLl = x9him6LyA05DkbWaISJ.textsize('HHH BBB 888 000',font=mdub5Ua39AhyoPK1G2gfnJslqLWO)
	ViTogZ81BApaSdKMLvEyh3D6I2NJ,xVcLlIk97mGfjPJ8E3WqzN4QH = x9him6LyA05DkbWaISJ.textsize('HHH BBB 888 000',font=Ho8lwgctJQ6WXK3)
	ulgOTW1hebIMXnUCPc43 = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as cfSlvaouQtPVHi
	eqpQ1zjHZ9kRv2XT3xnC80awYdUc = cfSlvaouQtPVHi(configuration=ulgOTW1hebIMXnUCPc43)
	MVRO510tk39isT = {}
	XXJdexCrYqzOhVgPNscQT3WpkoK = locals()
	for ddmHpyREIePbf5wAU in XXJdexCrYqzOhVgPNscQT3WpkoK: MVRO510tk39isT[ddmHpyREIePbf5wAU] = XXJdexCrYqzOhVgPNscQT3WpkoK[ddmHpyREIePbf5wAU]
	return MVRO510tk39isT
def vbNuHUABJx(MVRO510tk39isT,lAhrwzFeLkvnE6xpyfm,zzn5GhdpemvMfHYA,OIjgT4MxL37tuf9DpwYVqa,oYOSQfs6RaLnHhlGjp23C,bkA4Xjzw7mJa,t0tqOadibTQjFXgYDcu91e,hRNITKbg3ZXj,h2TSmLBKxd7optlMNvZF,PfmFrK9L7UpD3k5CJzWOMba):
	for ddmHpyREIePbf5wAU in MVRO510tk39isT: globals()[ddmHpyREIePbf5wAU] = MVRO510tk39isT[ddmHpyREIePbf5wAU]
	global Y6Ndq3RtDH80L2VlT,OZ3J7WEpQrNDHKj
	if t0tqOadibTQjFXgYDcu91e!='menu_item':
		A50idMBcCI2y = MoO74hKeqm8fFka.getSetting('av.language.translate')
		if A50idMBcCI2y:
			if lAhrwzFeLkvnE6xpyfm=='نعم  Yes': lAhrwzFeLkvnE6xpyfm = 'Yes'
			elif lAhrwzFeLkvnE6xpyfm=='كلا  No': lAhrwzFeLkvnE6xpyfm = 'No'
			if zzn5GhdpemvMfHYA=='نعم  Yes': zzn5GhdpemvMfHYA = 'Yes'
			elif zzn5GhdpemvMfHYA=='كلا  No': zzn5GhdpemvMfHYA = 'No'
			if OIjgT4MxL37tuf9DpwYVqa=='نعم  Yes': OIjgT4MxL37tuf9DpwYVqa = 'Yes'
			elif OIjgT4MxL37tuf9DpwYVqa=='كلا  No': OIjgT4MxL37tuf9DpwYVqa = 'No'
			pGiyauNHUVlRTnP = D7bPxVELdU1J5pRC6vaQt([lAhrwzFeLkvnE6xpyfm,zzn5GhdpemvMfHYA,OIjgT4MxL37tuf9DpwYVqa,oYOSQfs6RaLnHhlGjp23C,bkA4Xjzw7mJa])
			if pGiyauNHUVlRTnP: lAhrwzFeLkvnE6xpyfm,zzn5GhdpemvMfHYA,OIjgT4MxL37tuf9DpwYVqa,oYOSQfs6RaLnHhlGjp23C,bkA4Xjzw7mJa = pGiyauNHUVlRTnP
	if lHfbysRrUV7m4CLSdkxc382n:
		bkA4Xjzw7mJa = bkA4Xjzw7mJa.decode(m6PFtLblInpNZ8x)
		oYOSQfs6RaLnHhlGjp23C = oYOSQfs6RaLnHhlGjp23C.decode(m6PFtLblInpNZ8x)
		lAhrwzFeLkvnE6xpyfm = lAhrwzFeLkvnE6xpyfm.decode(m6PFtLblInpNZ8x)
		zzn5GhdpemvMfHYA = zzn5GhdpemvMfHYA.decode(m6PFtLblInpNZ8x)
		OIjgT4MxL37tuf9DpwYVqa = OIjgT4MxL37tuf9DpwYVqa.decode(m6PFtLblInpNZ8x)
	MvLhOux4kVwHC2 = oYOSQfs6RaLnHhlGjp23C.count(kDUv7ouWrcgMe6OipQJm)+1
	B1DEYNOelpy2Mq7o0siuwI5LdhU = x8cuLmWsa5J1lv90ENKPqGQo7gZrR+MvLhOux4kVwHC2*(ATh2DvXBmHOUNKs3cMGw6WRJ7VLl+EMZpy0QeH7JxwL)-EMZpy0QeH7JxwL
	if bkA4Xjzw7mJa:
		rB5zofuaRwcXSH8n0iktU4bFAxdKG = xVcLlIk97mGfjPJ8E3WqzN4QH+Sh5OEWgcKnktXF7UGPVB
		t0jhTbEO5Q8oDB = eqpQ1zjHZ9kRv2XT3xnC80awYdUc.reshape(bkA4Xjzw7mJa)
		if b4Wvg92C3LXJycN:
			aaAPuU6O9h = DE8vlVTC4kRGstK(x9him6LyA05DkbWaISJ,Ho8lwgctJQ6WXK3,t0jhTbEO5Q8oDB,hhUiZBn7Feb1Iw,XZpR4u3Q9xmLko0VhCcHvKr1zI2,rB5zofuaRwcXSH8n0iktU4bFAxdKG)
			JHasDe3wR98mhLIdCYjGTqFx = PZ10RqzaDAgmLfNknU7wjdtulb(aaAPuU6O9h)
			NHb3zifpIuOWLD7MCS1n = JHasDe3wR98mhLIdCYjGTqFx.count(kDUv7ouWrcgMe6OipQJm)+1
			yyHZwCt1dMjBEiANsUP0mGKXa5Y = XogTpwVLvNQiY+NHb3zifpIuOWLD7MCS1n*rB5zofuaRwcXSH8n0iktU4bFAxdKG-Sh5OEWgcKnktXF7UGPVB
		else:
			yyHZwCt1dMjBEiANsUP0mGKXa5Y = XogTpwVLvNQiY+xVcLlIk97mGfjPJ8E3WqzN4QH
			JHasDe3wR98mhLIdCYjGTqFx = t0jhTbEO5Q8oDB.split(kDUv7ouWrcgMe6OipQJm)[0]
			aaAPuU6O9h = t0jhTbEO5Q8oDB.split(kDUv7ouWrcgMe6OipQJm)[0]
	else: yyHZwCt1dMjBEiANsUP0mGKXa5Y = XogTpwVLvNQiY
	ifk7rM89WVKupx = yyDLeV1cafXj+gguBiKE8I5vkM1ZwTCRlUb0n9qd
	if h2TSmLBKxd7optlMNvZF:
		eepTBwArjD = D3xJ0LgaNEm86Fi1ZlYSqjh-REbQpLO4BZSnXcFgK
		ifk7rM89WVKupx += eepTBwArjD
	else: eepTBwArjD = 0
	if lAhrwzFeLkvnE6xpyfm or zzn5GhdpemvMfHYA or OIjgT4MxL37tuf9DpwYVqa: ifk7rM89WVKupx += kmP4A28DMcgC1UNeJhYyR
	S5V6pBQn3aXl7ehgstwTdRm4Muc = sMiXmBtcnRpADrwhGbx3jK0gadWo if sMiXmBtcnRpADrwhGbx3jK0gadWo!='UPPER' else B1DEYNOelpy2Mq7o0siuwI5LdhU+yyHZwCt1dMjBEiANsUP0mGKXa5Y+ifk7rM89WVKupx
	U7UXFLVIMKrO = aQhjb3I1CW.new('RGBA',(IaEYVOlc6t2oDi0z3NsMLShQnC,S5V6pBQn3aXl7ehgstwTdRm4Muc),(255,255,255,0))
	jjBWRZGdvzpaXm5q0y = H28fb4Yg1GA3.Draw(U7UXFLVIMKrO)
	GLOrB8wyh3outbmgS1HvE = S5V6pBQn3aXl7ehgstwTdRm4Muc-B1DEYNOelpy2Mq7o0siuwI5LdhU-ifk7rM89WVKupx-XogTpwVLvNQiY
	if not zzn5GhdpemvMfHYA and lAhrwzFeLkvnE6xpyfm and OIjgT4MxL37tuf9DpwYVqa:
		Y6Ndq3RtDH80L2VlT += 105
		OZ3J7WEpQrNDHKj -= 110
	import bidi.algorithm as QQXsP3duLNJl5eK0ixBbcmwAo
	if oYOSQfs6RaLnHhlGjp23C:
		snmBEq0P1yu8 = x8cuLmWsa5J1lv90ENKPqGQo7gZrR
		oYOSQfs6RaLnHhlGjp23C = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(eqpQ1zjHZ9kRv2XT3xnC80awYdUc.reshape(oYOSQfs6RaLnHhlGjp23C))
		xp7ejmzyYGO9ShDsid6RZ = oYOSQfs6RaLnHhlGjp23C.splitlines()
		for KyujWR9edp0HVxJ in xp7ejmzyYGO9ShDsid6RZ:
			if KyujWR9edp0HVxJ:
				ykBsfXG1SEnhi5mde,hNpfJjgcmeUWkrTSFx = jjBWRZGdvzpaXm5q0y.textsize(KyujWR9edp0HVxJ,font=mdub5Ua39AhyoPK1G2gfnJslqLWO)
				if R80CJKru3BAQDxh4UPck=='center': pt6xfO2HcrGd7lDXjyB5YwqZ9A = xxDMVlwE6QYy+(IaEYVOlc6t2oDi0z3NsMLShQnC-ykBsfXG1SEnhi5mde)/2
				elif R80CJKru3BAQDxh4UPck=='right': pt6xfO2HcrGd7lDXjyB5YwqZ9A = xxDMVlwE6QYy+IaEYVOlc6t2oDi0z3NsMLShQnC-ykBsfXG1SEnhi5mde-QCexIvpwhOoRtXkFHJq51Bz9AK
				elif R80CJKru3BAQDxh4UPck=='left': pt6xfO2HcrGd7lDXjyB5YwqZ9A = xxDMVlwE6QYy+QCexIvpwhOoRtXkFHJq51Bz9AK
				jjBWRZGdvzpaXm5q0y.text((pt6xfO2HcrGd7lDXjyB5YwqZ9A,snmBEq0P1yu8),KyujWR9edp0HVxJ,font=mdub5Ua39AhyoPK1G2gfnJslqLWO,fill='yellow')
			snmBEq0P1yu8 += D5GK1iBuXfwZp7QT8vnWIsrEh+EMZpy0QeH7JxwL
	if lAhrwzFeLkvnE6xpyfm or zzn5GhdpemvMfHYA or OIjgT4MxL37tuf9DpwYVqa:
		FkuOPEVLn0IRWBGA5rCtQhMK = B1DEYNOelpy2Mq7o0siuwI5LdhU+GLOrB8wyh3outbmgS1HvE+XogTpwVLvNQiY+eepTBwArjD+yyDLeV1cafXj
		if lAhrwzFeLkvnE6xpyfm:
			lAhrwzFeLkvnE6xpyfm = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(eqpQ1zjHZ9kRv2XT3xnC80awYdUc.reshape(lAhrwzFeLkvnE6xpyfm))
			g9keijWLtHr74wuIpGzK,pjC8NaDAo4qPEzS9Xrl = jjBWRZGdvzpaXm5q0y.textsize(lAhrwzFeLkvnE6xpyfm,font=kWUR6ztA8vngKsqmu19l)
			ShDj5bcVYJ9yZirnGEg2owfMelzv8t = Y6Ndq3RtDH80L2VlT+0*(OZ3J7WEpQrNDHKj+VVdEoH58SBYmyaJMtrQRAzCF)+(VVdEoH58SBYmyaJMtrQRAzCF-g9keijWLtHr74wuIpGzK)/2
			jjBWRZGdvzpaXm5q0y.text((ShDj5bcVYJ9yZirnGEg2owfMelzv8t,FkuOPEVLn0IRWBGA5rCtQhMK),lAhrwzFeLkvnE6xpyfm,font=kWUR6ztA8vngKsqmu19l,fill='yellow')
		if zzn5GhdpemvMfHYA:
			zzn5GhdpemvMfHYA = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(eqpQ1zjHZ9kRv2XT3xnC80awYdUc.reshape(zzn5GhdpemvMfHYA))
			gavG4sPDMhTEczWIXYFiUlk6dS,lU1wOYya7N4RFDEco6 = jjBWRZGdvzpaXm5q0y.textsize(zzn5GhdpemvMfHYA,font=kWUR6ztA8vngKsqmu19l)
			KqI3ABV6fz = Y6Ndq3RtDH80L2VlT+1*(OZ3J7WEpQrNDHKj+VVdEoH58SBYmyaJMtrQRAzCF)+(VVdEoH58SBYmyaJMtrQRAzCF-gavG4sPDMhTEczWIXYFiUlk6dS)/2
			jjBWRZGdvzpaXm5q0y.text((KqI3ABV6fz,FkuOPEVLn0IRWBGA5rCtQhMK),zzn5GhdpemvMfHYA,font=kWUR6ztA8vngKsqmu19l,fill='yellow')
		if OIjgT4MxL37tuf9DpwYVqa:
			OIjgT4MxL37tuf9DpwYVqa = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(eqpQ1zjHZ9kRv2XT3xnC80awYdUc.reshape(OIjgT4MxL37tuf9DpwYVqa))
			AeDqwZarBy,teP4LW5hYlViFX = jjBWRZGdvzpaXm5q0y.textsize(OIjgT4MxL37tuf9DpwYVqa,font=kWUR6ztA8vngKsqmu19l)
			Y54abjRXFByD6TGpEUmtCsMi19 = Y6Ndq3RtDH80L2VlT+2*(OZ3J7WEpQrNDHKj+VVdEoH58SBYmyaJMtrQRAzCF)+(VVdEoH58SBYmyaJMtrQRAzCF-AeDqwZarBy)/2
			jjBWRZGdvzpaXm5q0y.text((Y54abjRXFByD6TGpEUmtCsMi19,FkuOPEVLn0IRWBGA5rCtQhMK),OIjgT4MxL37tuf9DpwYVqa,font=kWUR6ztA8vngKsqmu19l,fill='yellow')
	if bkA4Xjzw7mJa:
		TxOX5Z6Fp09wjaflr,F2byOaPWmcr5KE6AGRqtUiHSvz = [],[]
		aaAPuU6O9h = VxCyGmwQjYfJksShgFTMKNnziLqW6(aaAPuU6O9h)
		Cu2JvMXoUE1gVbqjPc = aaAPuU6O9h.split('_sss__newline_')
		for kDgl6p3y7cnWbBzdF in Cu2JvMXoUE1gVbqjPc:
			xpKqdIyhljsgArwGX03MCZm5fDNL = hRNITKbg3ZXj
			if   '_sss__lineleft_' in kDgl6p3y7cnWbBzdF: xpKqdIyhljsgArwGX03MCZm5fDNL = 'left'
			elif '_sss__lineright_' in kDgl6p3y7cnWbBzdF: xpKqdIyhljsgArwGX03MCZm5fDNL = 'right'
			elif '_sss__linecenter_' in kDgl6p3y7cnWbBzdF: xpKqdIyhljsgArwGX03MCZm5fDNL = 'center'
			ux0szaclHYPMwvUydqGgZptkeRF2 = kDgl6p3y7cnWbBzdF
			lmaNyZjh3Pp4B1WSIgT0iVfr = cBawilJXvK1m.findall('_sss__.*?_',kDgl6p3y7cnWbBzdF,cBawilJXvK1m.DOTALL)
			for dMS1sDVhOGTbZI6HJmj in lmaNyZjh3Pp4B1WSIgT0iVfr: ux0szaclHYPMwvUydqGgZptkeRF2 = ux0szaclHYPMwvUydqGgZptkeRF2.replace(dMS1sDVhOGTbZI6HJmj,eHdDoxhJCEPMZFVa2fg)
			if ux0szaclHYPMwvUydqGgZptkeRF2==eHdDoxhJCEPMZFVa2fg: ykBsfXG1SEnhi5mde,hNpfJjgcmeUWkrTSFx = 0,rB5zofuaRwcXSH8n0iktU4bFAxdKG
			else: ykBsfXG1SEnhi5mde,hNpfJjgcmeUWkrTSFx = jjBWRZGdvzpaXm5q0y.textsize(ux0szaclHYPMwvUydqGgZptkeRF2,font=Ho8lwgctJQ6WXK3)
			if   xpKqdIyhljsgArwGX03MCZm5fDNL=='left': rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo = oiSnx50OWLDQGc9YvNBf+oJkazmZlrWRN3M4d7hsDYjAp6T
			elif xpKqdIyhljsgArwGX03MCZm5fDNL=='right': rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo = oiSnx50OWLDQGc9YvNBf+oJkazmZlrWRN3M4d7hsDYjAp6T+XZpR4u3Q9xmLko0VhCcHvKr1zI2-ykBsfXG1SEnhi5mde
			elif xpKqdIyhljsgArwGX03MCZm5fDNL=='center': rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo = oiSnx50OWLDQGc9YvNBf+oJkazmZlrWRN3M4d7hsDYjAp6T+(XZpR4u3Q9xmLko0VhCcHvKr1zI2-ykBsfXG1SEnhi5mde)/2
			if rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo<oJkazmZlrWRN3M4d7hsDYjAp6T: rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo = oiSnx50OWLDQGc9YvNBf+oJkazmZlrWRN3M4d7hsDYjAp6T
			TxOX5Z6Fp09wjaflr.append(rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo)
			F2byOaPWmcr5KE6AGRqtUiHSvz.append(ykBsfXG1SEnhi5mde)
		rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo = TxOX5Z6Fp09wjaflr[0]
		ZBNmpPj7VC8fDYMg = aaAPuU6O9h.split('_sss_')
		IIxk2OoKmiDfdw4juFhAZc6RQGv = (255,255,255,255)
		ooxLigInpG8UfyDJ12M7rldYE = IIxk2OoKmiDfdw4juFhAZc6RQGv
		dRFzKANcMeioDL8huj7yrHlICZpOX,KKJbyV7t9j3Z4qYWHAO0 = 0,0
		QAFdgHmINroV43hz0j18xZOWqsLkRy = False
		PJvEcaszWi5BOSkRZqL3yCe2 = 0
		baozKAWZm3HORd5fFBCJ4hDkwv = B1DEYNOelpy2Mq7o0siuwI5LdhU+XogTpwVLvNQiY/2
		if yyHZwCt1dMjBEiANsUP0mGKXa5Y<(GLOrB8wyh3outbmgS1HvE+XogTpwVLvNQiY):
			U6UoWdAlsmCzbpV0 = (GLOrB8wyh3outbmgS1HvE+XogTpwVLvNQiY-yyHZwCt1dMjBEiANsUP0mGKXa5Y)/2
			baozKAWZm3HORd5fFBCJ4hDkwv = B1DEYNOelpy2Mq7o0siuwI5LdhU+XogTpwVLvNQiY+U6UoWdAlsmCzbpV0-xVcLlIk97mGfjPJ8E3WqzN4QH/2
		for KyujWR9edp0HVxJ in ZBNmpPj7VC8fDYMg:
			if not KyujWR9edp0HVxJ or (KyujWR9edp0HVxJ and ord(KyujWR9edp0HVxJ[0])==65279): continue
			L4T6cByUz30ErghCSDM9ZidAb7G = KyujWR9edp0HVxJ.split('_newline_',1)
			f425uLegbdYQkM8ShXwpJR = KyujWR9edp0HVxJ.split('_newcolor',1)
			eMdFLvGzEpiW50rAym = KyujWR9edp0HVxJ.split('_endcolor_',1)
			gBKCQ968ykIfGJ = KyujWR9edp0HVxJ.split('_linertl_',1)
			yz8kZjE53hSTWP4u = KyujWR9edp0HVxJ.split('_lineleft_',1)
			rmFPyAJ7tnGz6q = KyujWR9edp0HVxJ.split('_lineright_',1)
			qi2zFmcXu5DIkWfrAhHRvYV = KyujWR9edp0HVxJ.split('_linecenter_',1)
			if len(L4T6cByUz30ErghCSDM9ZidAb7G)>1:
				PJvEcaszWi5BOSkRZqL3yCe2 += 1
				KyujWR9edp0HVxJ = L4T6cByUz30ErghCSDM9ZidAb7G[1]
				dRFzKANcMeioDL8huj7yrHlICZpOX = 0
				rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo = TxOX5Z6Fp09wjaflr[PJvEcaszWi5BOSkRZqL3yCe2]
				KKJbyV7t9j3Z4qYWHAO0 += rB5zofuaRwcXSH8n0iktU4bFAxdKG
				QAFdgHmINroV43hz0j18xZOWqsLkRy = False
			elif len(f425uLegbdYQkM8ShXwpJR)>1:
				KyujWR9edp0HVxJ = f425uLegbdYQkM8ShXwpJR[1]
				ooxLigInpG8UfyDJ12M7rldYE = KyujWR9edp0HVxJ[0:8]
				ooxLigInpG8UfyDJ12M7rldYE = '#'+ooxLigInpG8UfyDJ12M7rldYE[2:]
				KyujWR9edp0HVxJ = KyujWR9edp0HVxJ[9:]
			elif len(eMdFLvGzEpiW50rAym)>1:
				KyujWR9edp0HVxJ = eMdFLvGzEpiW50rAym[1]
				ooxLigInpG8UfyDJ12M7rldYE = IIxk2OoKmiDfdw4juFhAZc6RQGv
			elif len(gBKCQ968ykIfGJ)>1:
				KyujWR9edp0HVxJ = gBKCQ968ykIfGJ[1]
				QAFdgHmINroV43hz0j18xZOWqsLkRy = True
				dRFzKANcMeioDL8huj7yrHlICZpOX = F2byOaPWmcr5KE6AGRqtUiHSvz[PJvEcaszWi5BOSkRZqL3yCe2]
			elif len(yz8kZjE53hSTWP4u)>1: KyujWR9edp0HVxJ = yz8kZjE53hSTWP4u[1]
			elif len(rmFPyAJ7tnGz6q)>1: KyujWR9edp0HVxJ = rmFPyAJ7tnGz6q[1]
			elif len(qi2zFmcXu5DIkWfrAhHRvYV)>1: KyujWR9edp0HVxJ = qi2zFmcXu5DIkWfrAhHRvYV[1]
			if KyujWR9edp0HVxJ:
				CApqJN3KD6F9dwjvO8yskzagnPrL = baozKAWZm3HORd5fFBCJ4hDkwv+KKJbyV7t9j3Z4qYWHAO0
				KyujWR9edp0HVxJ = QQXsP3duLNJl5eK0ixBbcmwAo.get_display(KyujWR9edp0HVxJ)
				ykBsfXG1SEnhi5mde,hNpfJjgcmeUWkrTSFx = jjBWRZGdvzpaXm5q0y.textsize(KyujWR9edp0HVxJ,font=Ho8lwgctJQ6WXK3)
				if QAFdgHmINroV43hz0j18xZOWqsLkRy: dRFzKANcMeioDL8huj7yrHlICZpOX -= ykBsfXG1SEnhi5mde
				DxLnPTEKG3WoBbjO6q7gszi = rG6IsLBC8gTHMjkbaz7Q9P2wZy4cJo+dRFzKANcMeioDL8huj7yrHlICZpOX
				jjBWRZGdvzpaXm5q0y.text((DxLnPTEKG3WoBbjO6q7gszi,CApqJN3KD6F9dwjvO8yskzagnPrL),KyujWR9edp0HVxJ,font=Ho8lwgctJQ6WXK3,fill=ooxLigInpG8UfyDJ12M7rldYE)
				if t0tqOadibTQjFXgYDcu91e=='menu_item':
					jjBWRZGdvzpaXm5q0y.text((DxLnPTEKG3WoBbjO6q7gszi+1,CApqJN3KD6F9dwjvO8yskzagnPrL+1),KyujWR9edp0HVxJ,font=Ho8lwgctJQ6WXK3,fill=ooxLigInpG8UfyDJ12M7rldYE)
				if not QAFdgHmINroV43hz0j18xZOWqsLkRy: dRFzKANcMeioDL8huj7yrHlICZpOX += ykBsfXG1SEnhi5mde
				if CApqJN3KD6F9dwjvO8yskzagnPrL>GLOrB8wyh3outbmgS1HvE+rB5zofuaRwcXSH8n0iktU4bFAxdKG: break
	if t0tqOadibTQjFXgYDcu91e=='menu_item':
		hhpqMvD2c3mbKaegAf4U0lS5JxjRGE = klpqsTbM34jHhm96tBGZC21eu.copy()
		hhpqMvD2c3mbKaegAf4U0lS5JxjRGE.paste(qqGSHJPUXazWw,(0,0),mask=U7UXFLVIMKrO)
	else: hhpqMvD2c3mbKaegAf4U0lS5JxjRGE = U7UXFLVIMKrO
	if lHfbysRrUV7m4CLSdkxc382n: PfmFrK9L7UpD3k5CJzWOMba = PfmFrK9L7UpD3k5CJzWOMba.decode(m6PFtLblInpNZ8x)
	try: hhpqMvD2c3mbKaegAf4U0lS5JxjRGE.save(PfmFrK9L7UpD3k5CJzWOMba)
	except UnicodeError:
		if lHfbysRrUV7m4CLSdkxc382n:
			PfmFrK9L7UpD3k5CJzWOMba = PfmFrK9L7UpD3k5CJzWOMba.encode(m6PFtLblInpNZ8x)
			hhpqMvD2c3mbKaegAf4U0lS5JxjRGE.save(PfmFrK9L7UpD3k5CJzWOMba)
	return S5V6pBQn3aXl7ehgstwTdRm4Muc
def DE8vlVTC4kRGstK(x9him6LyA05DkbWaISJ,Ho8lwgctJQ6WXK3,aR2nqUMepLENVbcx,qnipZFgVL1,XZpR4u3Q9xmLko0VhCcHvKr1zI2,QLdfuH1UzPyAKgDCkY):
	ca2l49OMCEt,U7TVPzZC9GjuwYBIfso,qIJ7Ne4iSFBck = eHdDoxhJCEPMZFVa2fg,0,15000
	aR2nqUMepLENVbcx = aR2nqUMepLENVbcx.replace('[COLOR ','[COLOR:::')
	dpAYky8mewV5KTzS6W2BqHPbZ = XZpR4u3Q9xmLko0VhCcHvKr1zI2-qnipZFgVL1*2
	for K85slnG6gqxAzCLZ in aR2nqUMepLENVbcx.splitlines():
		U7TVPzZC9GjuwYBIfso += QLdfuH1UzPyAKgDCkY
		PYE5p4nz7icV8h9DNb6oCa,xu0ht6F5Ssoqp = 0,eHdDoxhJCEPMZFVa2fg
		for ZAgYyldXkFa6ehErN1 in K85slnG6gqxAzCLZ.split(avcfIls8w7gk69hYUErHxzQTXtm24j):
			OEWLZBIGYHXr9dzUpQVKn8 = PZ10RqzaDAgmLfNknU7wjdtulb(avcfIls8w7gk69hYUErHxzQTXtm24j+ZAgYyldXkFa6ehErN1)
			atKAQdB7FcL,Nwtj4erAW05Sn1QxhYuszVMpUCdRX = x9him6LyA05DkbWaISJ.textsize(OEWLZBIGYHXr9dzUpQVKn8,font=Ho8lwgctJQ6WXK3)
			if PYE5p4nz7icV8h9DNb6oCa+atKAQdB7FcL<dpAYky8mewV5KTzS6W2BqHPbZ:
				if not xu0ht6F5Ssoqp: xu0ht6F5Ssoqp += ZAgYyldXkFa6ehErN1
				else: xu0ht6F5Ssoqp += avcfIls8w7gk69hYUErHxzQTXtm24j+ZAgYyldXkFa6ehErN1
				PYE5p4nz7icV8h9DNb6oCa += atKAQdB7FcL
			else:
				if atKAQdB7FcL<dpAYky8mewV5KTzS6W2BqHPbZ:
					xu0ht6F5Ssoqp += '\n '+ZAgYyldXkFa6ehErN1
					U7TVPzZC9GjuwYBIfso += QLdfuH1UzPyAKgDCkY
					PYE5p4nz7icV8h9DNb6oCa = atKAQdB7FcL
				else:
					while atKAQdB7FcL>dpAYky8mewV5KTzS6W2BqHPbZ:
						for eMVgaSfkty1AwQT6Obo in range(1,len(avcfIls8w7gk69hYUErHxzQTXtm24j+ZAgYyldXkFa6ehErN1),1):
							UUqmHJchIT4LAzX = avcfIls8w7gk69hYUErHxzQTXtm24j+ZAgYyldXkFa6ehErN1[:eMVgaSfkty1AwQT6Obo]
							v1fEbk70xCyrugD3BdVZa = ZAgYyldXkFa6ehErN1[eMVgaSfkty1AwQT6Obo:]
							YmFu1eEX7wRpqfP6MLrCIdhlDxgH = PZ10RqzaDAgmLfNknU7wjdtulb(UUqmHJchIT4LAzX)
							iQMc4YpSDbFjv3,K6pwvlEy4hBMUjcrLIsXHAP = x9him6LyA05DkbWaISJ.textsize(YmFu1eEX7wRpqfP6MLrCIdhlDxgH,font=Ho8lwgctJQ6WXK3)
							if PYE5p4nz7icV8h9DNb6oCa+iQMc4YpSDbFjv3>dpAYky8mewV5KTzS6W2BqHPbZ:
								VDGOcE4gowX = atKAQdB7FcL-iQMc4YpSDbFjv3
								xu0ht6F5Ssoqp += UUqmHJchIT4LAzX+kDUv7ouWrcgMe6OipQJm
								U7TVPzZC9GjuwYBIfso += QLdfuH1UzPyAKgDCkY
								atKAQdB7FcL = VDGOcE4gowX
								if VDGOcE4gowX>dpAYky8mewV5KTzS6W2BqHPbZ:
									PYE5p4nz7icV8h9DNb6oCa = 0
									ZAgYyldXkFa6ehErN1 = v1fEbk70xCyrugD3BdVZa
								else:
									PYE5p4nz7icV8h9DNb6oCa = VDGOcE4gowX
									xu0ht6F5Ssoqp += v1fEbk70xCyrugD3BdVZa
								break
				if U7TVPzZC9GjuwYBIfso>qIJ7Ne4iSFBck: break
		ca2l49OMCEt += kDUv7ouWrcgMe6OipQJm+xu0ht6F5Ssoqp
		if U7TVPzZC9GjuwYBIfso>qIJ7Ne4iSFBck: break
	ca2l49OMCEt = ca2l49OMCEt[1:]
	ca2l49OMCEt = ca2l49OMCEt.replace('[COLOR:::','[COLOR ')
	return ca2l49OMCEt
def PZ10RqzaDAgmLfNknU7wjdtulb(ZAgYyldXkFa6ehErN1):
	if '[' in ZAgYyldXkFa6ehErN1 and ']' in ZAgYyldXkFa6ehErN1:
		lmaNyZjh3Pp4B1WSIgT0iVfr = [Nat0Dx9puRUWCsgz6JyFhY3,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		QEvdwlF1gaZM0OKH9tiS8qPGzuyTD = cBawilJXvK1m.findall('\[COLOR .*?\]',ZAgYyldXkFa6ehErN1,cBawilJXvK1m.DOTALL)
		QmcIr7MZivNzR5LYSe4p2 = cBawilJXvK1m.findall('\[COLOR:::.*?\]',ZAgYyldXkFa6ehErN1,cBawilJXvK1m.DOTALL)
		d4QZo3nK6iwujAsPCVghTGR2 = lmaNyZjh3Pp4B1WSIgT0iVfr+QEvdwlF1gaZM0OKH9tiS8qPGzuyTD+QmcIr7MZivNzR5LYSe4p2
		for dMS1sDVhOGTbZI6HJmj in d4QZo3nK6iwujAsPCVghTGR2: ZAgYyldXkFa6ehErN1 = ZAgYyldXkFa6ehErN1.replace(dMS1sDVhOGTbZI6HJmj,eHdDoxhJCEPMZFVa2fg)
	return ZAgYyldXkFa6ehErN1
def VxCyGmwQjYfJksShgFTMKNnziLqW6(bkA4Xjzw7mJa):
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(kDUv7ouWrcgMe6OipQJm,'_sss__newline_')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[RTL]','_sss__linertl_')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[LEFT]','_sss__lineleft_')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[RIGHT]','_sss__lineright_')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[CENTER]','_sss__linecenter_')
	bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace(Nat0Dx9puRUWCsgz6JyFhY3,'_sss__endcolor_')
	siaySbvnetMlPX46T = cBawilJXvK1m.findall('\[COLOR (.*?)\]',bkA4Xjzw7mJa,cBawilJXvK1m.DOTALL)
	for V432JrP5nd6vL0RiOsIabHx1MD in siaySbvnetMlPX46T: bkA4Xjzw7mJa = bkA4Xjzw7mJa.replace('[COLOR '+V432JrP5nd6vL0RiOsIabHx1MD+']','_sss__newcolor'+V432JrP5nd6vL0RiOsIabHx1MD+'_')
	return bkA4Xjzw7mJa
def r17Z5qKTw3gQ(Pe9ETSvwUGBnkC1hO=eHdDoxhJCEPMZFVa2fg):
	if not Pe9ETSvwUGBnkC1hO: Pe9ETSvwUGBnkC1hO = ccwRLKk3hs0E.getInfoLabel('ListItem.Label')
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg)
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(h597x8jYiAIBDzcedPslw6pQy,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(OR97bMGecfgDCqux3YdAZ6y,eHdDoxhJCEPMZFVa2fg).replace(SbyWQGMDnV,eHdDoxhJCEPMZFVa2fg)
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)
	nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1 = cBawilJXvK1m.findall('\d\d:\d\d ',Pe9ETSvwUGBnkC1hO,cBawilJXvK1m.DOTALL)
	if nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1: Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.split(nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1[0],1)[1]
	if not Pe9ETSvwUGBnkC1hO: Pe9ETSvwUGBnkC1hO = 'Main Menu'
	return Pe9ETSvwUGBnkC1hO
def gTFGf5IRwYWns8QHcKzoBAvC(cepLvEox93aUI):
	XgSCM1kEK2PaRUVuNsoZJdbF = eHdDoxhJCEPMZFVa2fg.join(eMVgaSfkty1AwQT6Obo for eMVgaSfkty1AwQT6Obo in cepLvEox93aUI if eMVgaSfkty1AwQT6Obo not in '\/":*?<>|'+cUKTayqdnW0)
	return XgSCM1kEK2PaRUVuNsoZJdbF
def br73AglSQ0i(d9c6BWV3J2bQDMRELgX):
	qqbgyNjsMHL23nV7euGfJQ = cBawilJXvK1m.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",d9c6BWV3J2bQDMRELgX,cBawilJXvK1m.S)
	if qqbgyNjsMHL23nV7euGfJQ:
		b3N6J28ElF7,jGE4BS2lZRFMD5J1UsICKfhueNd8 = qqbgyNjsMHL23nV7euGfJQ[0]
		b3N6J28ElF7 = cBawilJXvK1m.findall("=[\r\n\s\t]+'(.*?)';", b3N6J28ElF7, cBawilJXvK1m.S)[0]
		if b3N6J28ElF7 and jGE4BS2lZRFMD5J1UsICKfhueNd8:
			F7PpkESCB5brIWtdsa1Ro8Aiyl = b3N6J28ElF7.replace("'",eHdDoxhJCEPMZFVa2fg).replace("+",eHdDoxhJCEPMZFVa2fg).replace("\n",eHdDoxhJCEPMZFVa2fg).replace("\r",eHdDoxhJCEPMZFVa2fg)
			jj3rKTU9huIDwxLcQAGO = F7PpkESCB5brIWtdsa1Ro8Aiyl.split('.')
			d9c6BWV3J2bQDMRELgX = eHdDoxhJCEPMZFVa2fg
			for cstNijek6ESqlzfTmOw0dhIg8U1p in jj3rKTU9huIDwxLcQAGO:
				PPD1IpSs2Wh4 = HHP76VFiKDS2xphlGsqN48j1.b64decode(cstNijek6ESqlzfTmOw0dhIg8U1p+'==').decode(m6PFtLblInpNZ8x)
				AAalwHR9z6pNMBcf3ng5W = cBawilJXvK1m.findall('\d+', PPD1IpSs2Wh4, cBawilJXvK1m.S)
				if AAalwHR9z6pNMBcf3ng5W:
					ppk01A6PnM = int(AAalwHR9z6pNMBcf3ng5W[0])
					ppk01A6PnM += int(jGE4BS2lZRFMD5J1UsICKfhueNd8)
					d9c6BWV3J2bQDMRELgX = d9c6BWV3J2bQDMRELgX + chr(ppk01A6PnM)
			if WHjh1POtMKlmgiy68RSqb: d9c6BWV3J2bQDMRELgX = d9c6BWV3J2bQDMRELgX.encode('iso-8859-1').decode(m6PFtLblInpNZ8x)
	return d9c6BWV3J2bQDMRELgX
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
FO8SKWr40dDexHgbfRUGBi = 'FAVORITES'
def wt29MA4RWa8NOedvnpocQEfC1Hg(tWi3JH8rRhxcgnYuMVUK,v8Gz24bnMF9klmi):
	if   tWi3JH8rRhxcgnYuMVUK==270: pGiyauNHUVlRTnP = ZZUK8FJ4RTYCoVeg(v8Gz24bnMF9klmi)
	else: pGiyauNHUVlRTnP = False
	return pGiyauNHUVlRTnP
def yXofqcVp1Mhk(GsPYQbREvLAFw3aJ5XghmV,v8Gz24bnMF9klmi,wnzF4fCNvhJq7by9m):
	if not GsPYQbREvLAFw3aJ5XghmV: return
	if   wnzF4fCNvhJq7by9m=='UP1'	: hypzkG94xlEB0vuaNfTH2A5PZo1n(v8Gz24bnMF9klmi,True,1)
	elif wnzF4fCNvhJq7by9m=='DOWN1'	: hypzkG94xlEB0vuaNfTH2A5PZo1n(v8Gz24bnMF9klmi,False,1)
	elif wnzF4fCNvhJq7by9m=='UP4'	: hypzkG94xlEB0vuaNfTH2A5PZo1n(v8Gz24bnMF9klmi,True,4)
	elif wnzF4fCNvhJq7by9m=='DOWN4'	: hypzkG94xlEB0vuaNfTH2A5PZo1n(v8Gz24bnMF9klmi,False,4)
	elif wnzF4fCNvhJq7by9m=='ADD1'	: CC18A9ksfWpna(v8Gz24bnMF9klmi)
	elif wnzF4fCNvhJq7by9m=='REMOVE1': iwYkTI1VNau(v8Gz24bnMF9klmi)
	elif wnzF4fCNvhJq7by9m=='DELETELIST': JnEur5ICWMjfe3RFbAhi(v8Gz24bnMF9klmi)
	return
def ZZUK8FJ4RTYCoVeg(v8Gz24bnMF9klmi):
	WqADZlte1gnuapNLV = KKbRPTZDQAqiVfHyN()
	if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()):
		try:
			Oz9PcBy8Nj7iapHgb = WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]
			for IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 in Oz9PcBy8Nj7iapHgb:
				qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4)
		except:
			WqADZlte1gnuapNLV = ssIBAWh7QmzOoXqk8w(CCknZTXVNbG9Px0ds1hpQSMKB)
			Oz9PcBy8Nj7iapHgb = WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]
			for IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 in Oz9PcBy8Nj7iapHgb:
				qfpnsHw19BiaSktcXWbGA(IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4)
	return
def CC18A9ksfWpna(v8Gz24bnMF9klmi):
	IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 = udpczrlynT3vQ98HhDYqgFw2SWo4MG(H4ys6we0jDn)
	fZ5HWDazKBS4 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,ICOyNkVjwdXS5TFKH6WgZAn4
	WqADZlte1gnuapNLV = KKbRPTZDQAqiVfHyN()
	p7OC0QT9DSWRb = {}
	for esc9tbYNWnFg4hDo in list(WqADZlte1gnuapNLV.keys()):
		if esc9tbYNWnFg4hDo!=v8Gz24bnMF9klmi: p7OC0QT9DSWRb[esc9tbYNWnFg4hDo] = WqADZlte1gnuapNLV[esc9tbYNWnFg4hDo]
		else:
			if Pe9ETSvwUGBnkC1hO and Pe9ETSvwUGBnkC1hO!='..':
				kfiuhj4GREUasrBWCLpKxo6SeJA = WqADZlte1gnuapNLV[esc9tbYNWnFg4hDo]
				if fZ5HWDazKBS4 in kfiuhj4GREUasrBWCLpKxo6SeJA:
					AU4Sr0nEz2VXQBHuceh = kfiuhj4GREUasrBWCLpKxo6SeJA.index(fZ5HWDazKBS4)
					del kfiuhj4GREUasrBWCLpKxo6SeJA[AU4Sr0nEz2VXQBHuceh]
				bFKx8yQRg0edizGM6o9NnOJamp3ErZ = kfiuhj4GREUasrBWCLpKxo6SeJA+[fZ5HWDazKBS4]
				p7OC0QT9DSWRb[esc9tbYNWnFg4hDo] = bFKx8yQRg0edizGM6o9NnOJamp3ErZ
			else: p7OC0QT9DSWRb[esc9tbYNWnFg4hDo] = WqADZlte1gnuapNLV[esc9tbYNWnFg4hDo]
	if v8Gz24bnMF9klmi not in list(p7OC0QT9DSWRb.keys()): p7OC0QT9DSWRb[v8Gz24bnMF9klmi] = [fZ5HWDazKBS4]
	OVbnqQMSIi7oEH4zJj2auw6h1FBX = str(p7OC0QT9DSWRb)
	if WHjh1POtMKlmgiy68RSqb: OVbnqQMSIi7oEH4zJj2auw6h1FBX = OVbnqQMSIi7oEH4zJj2auw6h1FBX.encode(m6PFtLblInpNZ8x)
	open(CCknZTXVNbG9Px0ds1hpQSMKB,'wb').write(OVbnqQMSIi7oEH4zJj2auw6h1FBX)
	return
def iwYkTI1VNau(v8Gz24bnMF9klmi):
	IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 = udpczrlynT3vQ98HhDYqgFw2SWo4MG(H4ys6we0jDn)
	fZ5HWDazKBS4 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,ICOyNkVjwdXS5TFKH6WgZAn4
	WqADZlte1gnuapNLV = KKbRPTZDQAqiVfHyN()
	if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()) and fZ5HWDazKBS4 in WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]:
		WqADZlte1gnuapNLV[v8Gz24bnMF9klmi].remove(fZ5HWDazKBS4)
		if len(WqADZlte1gnuapNLV[v8Gz24bnMF9klmi])==0: del WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]
		OVbnqQMSIi7oEH4zJj2auw6h1FBX = str(WqADZlte1gnuapNLV)
		if WHjh1POtMKlmgiy68RSqb: OVbnqQMSIi7oEH4zJj2auw6h1FBX = OVbnqQMSIi7oEH4zJj2auw6h1FBX.encode(m6PFtLblInpNZ8x)
		open(CCknZTXVNbG9Px0ds1hpQSMKB,'wb').write(OVbnqQMSIi7oEH4zJj2auw6h1FBX)
	return
def hypzkG94xlEB0vuaNfTH2A5PZo1n(v8Gz24bnMF9klmi,rrzgNwiJvQTIB9KSfLF6st7GdDmuUo,rhNeF0R65cKACsxnQ):
	IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 = udpczrlynT3vQ98HhDYqgFw2SWo4MG(H4ys6we0jDn)
	fZ5HWDazKBS4 = IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,eHdDoxhJCEPMZFVa2fg,ICOyNkVjwdXS5TFKH6WgZAn4
	WqADZlte1gnuapNLV = KKbRPTZDQAqiVfHyN()
	if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()):
		kfiuhj4GREUasrBWCLpKxo6SeJA = WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]
		if fZ5HWDazKBS4 not in kfiuhj4GREUasrBWCLpKxo6SeJA: return
		XubTe2QUcEMpA7z = len(kfiuhj4GREUasrBWCLpKxo6SeJA)
		for eMVgaSfkty1AwQT6Obo in range(0,rhNeF0R65cKACsxnQ):
			i6obdFCcLp4tKNSzQekhXmqWgu = kfiuhj4GREUasrBWCLpKxo6SeJA.index(fZ5HWDazKBS4)
			if rrzgNwiJvQTIB9KSfLF6st7GdDmuUo: TZmMJVaQs9LzBKphScY2w = i6obdFCcLp4tKNSzQekhXmqWgu-1
			else: TZmMJVaQs9LzBKphScY2w = i6obdFCcLp4tKNSzQekhXmqWgu+1
			if TZmMJVaQs9LzBKphScY2w>=XubTe2QUcEMpA7z: TZmMJVaQs9LzBKphScY2w = TZmMJVaQs9LzBKphScY2w-XubTe2QUcEMpA7z
			if TZmMJVaQs9LzBKphScY2w<0: TZmMJVaQs9LzBKphScY2w = TZmMJVaQs9LzBKphScY2w+XubTe2QUcEMpA7z
			kfiuhj4GREUasrBWCLpKxo6SeJA.insert(TZmMJVaQs9LzBKphScY2w, kfiuhj4GREUasrBWCLpKxo6SeJA.pop(i6obdFCcLp4tKNSzQekhXmqWgu))
		WqADZlte1gnuapNLV[v8Gz24bnMF9klmi] = kfiuhj4GREUasrBWCLpKxo6SeJA
		OVbnqQMSIi7oEH4zJj2auw6h1FBX = str(WqADZlte1gnuapNLV)
		if WHjh1POtMKlmgiy68RSqb: OVbnqQMSIi7oEH4zJj2auw6h1FBX = OVbnqQMSIi7oEH4zJj2auw6h1FBX.encode(m6PFtLblInpNZ8x)
		open(CCknZTXVNbG9Px0ds1hpQSMKB,'wb').write(OVbnqQMSIi7oEH4zJj2auw6h1FBX)
	return
def JnEur5ICWMjfe3RFbAhi(v8Gz24bnMF9klmi):
	kMnoXVxN5byYJSzPrsu = VinwUNFtrZTh0oPs2zm('center',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة المفضلة '+v8Gz24bnMF9klmi+' ؟!')
	if kMnoXVxN5byYJSzPrsu!=1: return
	WqADZlte1gnuapNLV = KKbRPTZDQAqiVfHyN()
	if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()):
		del WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]
		OVbnqQMSIi7oEH4zJj2auw6h1FBX = str(WqADZlte1gnuapNLV)
		if WHjh1POtMKlmgiy68RSqb: OVbnqQMSIi7oEH4zJj2auw6h1FBX = OVbnqQMSIi7oEH4zJj2auw6h1FBX.encode(m6PFtLblInpNZ8x)
		open(CCknZTXVNbG9Px0ds1hpQSMKB,'wb').write(OVbnqQMSIi7oEH4zJj2auw6h1FBX)
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','تم مسح جميع محتويات قائمة المفضلة '+v8Gz24bnMF9klmi)
	return
def KKbRPTZDQAqiVfHyN():
	WqADZlte1gnuapNLV = {}
	if RRydns1CErYlIhwSx7.path.exists(CCknZTXVNbG9Px0ds1hpQSMKB):
		Ix3O7G0rqE = open(CCknZTXVNbG9Px0ds1hpQSMKB,'rb').read()
		if WHjh1POtMKlmgiy68RSqb: Ix3O7G0rqE = Ix3O7G0rqE.decode(m6PFtLblInpNZ8x)
		WqADZlte1gnuapNLV = DIpuHqsKGS3ErJvk9taCRiX80('dict',Ix3O7G0rqE)
	return WqADZlte1gnuapNLV
def S31TlKtJyE4oU(WqADZlte1gnuapNLV,fZ5HWDazKBS4,WmrCSiERsYxp5b9oJI0P):
	IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,Pe9ETSvwUGBnkC1hO,Nn360bq79W2kzUt,tWi3JH8rRhxcgnYuMVUK,Ev2Aw5Yyr3I4hHDoj718ZCpFSMQKV,d9c6BWV3J2bQDMRELgX,bkA4Xjzw7mJa,GsPYQbREvLAFw3aJ5XghmV,ICOyNkVjwdXS5TFKH6WgZAn4 = fZ5HWDazKBS4
	if not tWi3JH8rRhxcgnYuMVUK: IIheJZ2dTAzKtwkMCUlmOGX6PuNR9,tWi3JH8rRhxcgnYuMVUK = 'folder','260'
	zykZEUeC5IiSKD,v8Gz24bnMF9klmi = [],eHdDoxhJCEPMZFVa2fg
	if 'context=' in H4ys6we0jDn:
		nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1 = cBawilJXvK1m.findall('context=(\d+)',H4ys6we0jDn,cBawilJXvK1m.DOTALL)
		if nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1: v8Gz24bnMF9klmi = str(nmvlJEhVa4c3qBoS0NTDIZ5rM8uFA1[0])
	if tWi3JH8rRhxcgnYuMVUK=='270':
		v8Gz24bnMF9klmi = GsPYQbREvLAFw3aJ5XghmV
		if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()):
			zykZEUeC5IiSKD.append(('مسح قائمة مفضلة '+v8Gz24bnMF9klmi,'RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_DELETELIST'+')'))
	else:
		if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()):
			count = len(WqADZlte1gnuapNLV[v8Gz24bnMF9klmi])
			if count>1: zykZEUeC5IiSKD.append(('تحريك 1 للأعلى','RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_UP1)'))
			if count>4: zykZEUeC5IiSKD.append(('تحريك 4 للأعلى','RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_UP4)'))
			if count>1: zykZEUeC5IiSKD.append(('تحريك 1 للأسفل','RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_DOWN1)'))
			if count>4: zykZEUeC5IiSKD.append(('تحريك 4 للأسفل','RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_DOWN4)'))
		for v8Gz24bnMF9klmi in ['1','2','3','4','5']:
			if v8Gz24bnMF9klmi in list(WqADZlte1gnuapNLV.keys()) and fZ5HWDazKBS4 in WqADZlte1gnuapNLV[v8Gz24bnMF9klmi]:
				zykZEUeC5IiSKD.append(('مسح من مفضلة '+v8Gz24bnMF9klmi,'RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_REMOVE1)'))
			else: zykZEUeC5IiSKD.append(('إضافة لمفضلة '+v8Gz24bnMF9klmi,'RunPlugin('+WmrCSiERsYxp5b9oJI0P+'&context='+v8Gz24bnMF9klmi+'_ADD1)'))
	MzGCIci7tYK28nF = []
	for agD18bNh9dlkcYI,AAeNzsQjaolV8wSGWcIp2FhZ6XO in zykZEUeC5IiSKD:
		agD18bNh9dlkcYI = OR97bMGecfgDCqux3YdAZ6y+agD18bNh9dlkcYI+Nat0Dx9puRUWCsgz6JyFhY3
		MzGCIci7tYK28nF.append((agD18bNh9dlkcYI,AAeNzsQjaolV8wSGWcIp2FhZ6XO,))
	return MzGCIci7tYK28nF
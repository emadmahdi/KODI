# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'IFILM'
r07r9xeEFASJXluImT = '_IFL_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][1]
v2as4pXGlNC0xRiztVLFEoeM = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][2]
AGa4PFvZo8QjuiEz6ymB = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][3]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,clAzmREWwXf6Gk,text):
	if   mode==20: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = mcfKbtMrnSF()
	elif mode==21: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj(url)
	elif mode==22: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk)
	elif mode==23: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url,clAzmREWwXf6Gk)
	elif mode==24: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url,text)
	elif mode==25: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = gg8EjdplucZsWDLYtOFy7VBQoiI24(url)
	elif mode==27: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ozPjuMtH32DEISFKQl(url)
	elif mode==28: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = fxE4MdWUnoF5mbVsjPzraSGvpgOIh0()
	elif mode==29: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def mcfKbtMrnSF():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'عربي',q3QVhZaDEuo8t2ASj5vkn,21,eHdDoxhJCEPMZFVa2fg,'101')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'English',hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c,21,eHdDoxhJCEPMZFVa2fg,'101')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فارسى',v2as4pXGlNC0xRiztVLFEoeM,21,eHdDoxhJCEPMZFVa2fg,'101')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فارسى 2',AGa4PFvZo8QjuiEz6ymB,21,eHdDoxhJCEPMZFVa2fg,'101')
	return
def fxE4MdWUnoF5mbVsjPzraSGvpgOIh0():
	qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+'عربي',q3QVhZaDEuo8t2ASj5vkn,27)
	qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+'English',hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c,27)
	qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+'فارسى',v2as4pXGlNC0xRiztVLFEoeM,27)
	qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+'فارسى 2',AGa4PFvZo8QjuiEz6ymB,27)
	return
def pDomkPy18JGi7xQ302dYVqHLM9WTCj(oGqutYr9UleWM):
	EERWJf1adv67 = oGqutYr9UleWM
	if oGqutYr9UleWM=='IFILM-ARABIC': oGqutYr9UleWM = q3QVhZaDEuo8t2ASj5vkn
	elif oGqutYr9UleWM=='IFILM-ENGLISH': oGqutYr9UleWM = hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c
	else: EERWJf1adv67 = eHdDoxhJCEPMZFVa2fg
	qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(oGqutYr9UleWM)
	if qStMGnRJL0exKZjiW6dC19p5=='ar' or EERWJf1adv67=='IFILM-ARABIC':
		vueaOnGf5qxAKk83 = 'بحث في الموقع'
		qWG25bhluDH8xzJLytcISf1 = 'مسلسلات - حالية'
		TR3DAb6GkCsva1 = 'مسلسلات - أحدث'
		DwEKN8lLU6x1dCr2c9kXIH0sFGmZi = 'مسلسلات - أبجدي'
		tI2ymJwMR8U403Ch9d5sWlqE7ZgD = 'بث حي آي فيلم'
		QGYdTm8PnOKb07 = 'أفلام'
		fByzxmquhDb3K6QaPXGOdrCMigl9TI = 'موسيقى'
		t2jZlxmQH8DLTFA34OqznfUi = 'برامج'
	elif qStMGnRJL0exKZjiW6dC19p5=='en' or EERWJf1adv67=='IFILM-ENGLISH':
		vueaOnGf5qxAKk83 = 'Search in site'
		qWG25bhluDH8xzJLytcISf1 = 'Series - Current'
		TR3DAb6GkCsva1 = 'Series - Latest'
		DwEKN8lLU6x1dCr2c9kXIH0sFGmZi = 'Series - Alphabet'
		tI2ymJwMR8U403Ch9d5sWlqE7ZgD = 'Live iFilm channel'
		QGYdTm8PnOKb07 = 'Movies'
		fByzxmquhDb3K6QaPXGOdrCMigl9TI = 'Music'
		t2jZlxmQH8DLTFA34OqznfUi = 'Shows'
	elif qStMGnRJL0exKZjiW6dC19p5 in ['fa','fa2']:
		vueaOnGf5qxAKk83 = 'جستجو در سایت'
		qWG25bhluDH8xzJLytcISf1 = 'سريال - جاری'
		TR3DAb6GkCsva1 = 'سريال - آخرین'
		DwEKN8lLU6x1dCr2c9kXIH0sFGmZi = 'سريال - الفبا'
		tI2ymJwMR8U403Ch9d5sWlqE7ZgD = 'پخش زنده اي فيلم'
		QGYdTm8PnOKb07 = 'فيلم'
		fByzxmquhDb3K6QaPXGOdrCMigl9TI = 'موسيقى'
		t2jZlxmQH8DLTFA34OqznfUi = 'برنامه ها'
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+vueaOnGf5qxAKk83,oGqutYr9UleWM,29,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('live',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+tI2ymJwMR8U403Ch9d5sWlqE7ZgD,oGqutYr9UleWM,27)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	H0zbLoi34hNU = ['Series','Program','Music']
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,oGqutYr9UleWM+'/home',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('button-menu(.*?)/Contact',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in apOKrFbP9IYHDyUVm7 for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in H0zbLoi34hNU):
				url = oGqutYr9UleWM+apOKrFbP9IYHDyUVm7
				if 'Series' in apOKrFbP9IYHDyUVm7:
					qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+qWG25bhluDH8xzJLytcISf1,url,22,eHdDoxhJCEPMZFVa2fg,'100')
					qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+TR3DAb6GkCsva1,url,22,eHdDoxhJCEPMZFVa2fg,'101')
					qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+DwEKN8lLU6x1dCr2c9kXIH0sFGmZi,url,22,eHdDoxhJCEPMZFVa2fg,'201')
				elif 'Film' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+QGYdTm8PnOKb07,url,22,eHdDoxhJCEPMZFVa2fg,'100')
				elif 'Music' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+fByzxmquhDb3K6QaPXGOdrCMigl9TI,url,25,eHdDoxhJCEPMZFVa2fg,'101')
				elif 'Program' in apOKrFbP9IYHDyUVm7: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+t2jZlxmQH8DLTFA34OqznfUi,url,22,eHdDoxhJCEPMZFVa2fg,'101')
	return nR2B1Wye7luXb5
def gg8EjdplucZsWDLYtOFy7VBQoiI24(url):
	oGqutYr9UleWM = YjuSRTL3xCKG1hlecdbFgf9avkP(url)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-MUSIC_MENU-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('Music-tools-header(.*?)Music-body',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	title = cBawilJXvK1m.findall('<p>(.*?)</p>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)[0]
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,22,eHdDoxhJCEPMZFVa2fg,'101')
	items = cBawilJXvK1m.findall('href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in items:
		apOKrFbP9IYHDyUVm7 = oGqutYr9UleWM + apOKrFbP9IYHDyUVm7
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,23,eHdDoxhJCEPMZFVa2fg,'101')
	return
def zRK9ruIt0ZFV4bgi(url,clAzmREWwXf6Gk):
	oGqutYr9UleWM = YjuSRTL3xCKG1hlecdbFgf9avkP(url)
	qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(url)
	type = url.split('/')[-1]
	V3ntAURQL9G4 = str(int(clAzmREWwXf6Gk)//100)
	clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)%100)
	if type=='Series' and clAzmREWwXf6Gk=='0':
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-TITLES-1st')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('serial-body(.*?)class="row',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
			title = zJRbA1YW2Eor(title)
			apOKrFbP9IYHDyUVm7 = oGqutYr9UleWM + apOKrFbP9IYHDyUVm7
			PeLqCN5Ek8bB = oGqutYr9UleWM + vFDQstemyYANa(PeLqCN5Ek8bB)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,23,PeLqCN5Ek8bB,V3ntAURQL9G4+'01')
	peAJFoZLMcPuskI=0
	if type=='Series': U3d2hkuwDIj56='3'
	if type=='Film': U3d2hkuwDIj56='5'
	if type=='Program': U3d2hkuwDIj56='7'
	if type in ['Series','Program','Film'] and clAzmREWwXf6Gk!='0':
		E1Viom5L3684CTOFJ = oGqutYr9UleWM+'/Home/PageingItem?category='+U3d2hkuwDIj56+'&page='+clAzmREWwXf6Gk+'&size=30&orderby='+V3ntAURQL9G4
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-TITLES-2nd')
		items = cBawilJXvK1m.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for id,title,PeLqCN5Ek8bB in items:
			title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
			title = title.replace('\\',eHdDoxhJCEPMZFVa2fg)
			title = title.replace('"',eHdDoxhJCEPMZFVa2fg)
			peAJFoZLMcPuskI += 1
			apOKrFbP9IYHDyUVm7 = oGqutYr9UleWM + '/' + type + '/Content/' + id
			PeLqCN5Ek8bB = oGqutYr9UleWM + vFDQstemyYANa(PeLqCN5Ek8bB)
			if type=='Film': qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,24,PeLqCN5Ek8bB,V3ntAURQL9G4+'01')
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,23,PeLqCN5Ek8bB,V3ntAURQL9G4+'01')
	if type=='Music':
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,oGqutYr9UleWM+'/Music/Index?page='+clAzmREWwXf6Gk,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-TITLES-3rd')
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('pagination-demo(.*?)pagination-demo',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
			peAJFoZLMcPuskI += 1
			PeLqCN5Ek8bB = oGqutYr9UleWM + PeLqCN5Ek8bB
			apOKrFbP9IYHDyUVm7 = oGqutYr9UleWM + apOKrFbP9IYHDyUVm7
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,23,PeLqCN5Ek8bB,'101')
	if peAJFoZLMcPuskI>20:
		title='صفحة '
		if qStMGnRJL0exKZjiW6dC19p5=='en': title = 'Page '
		if qStMGnRJL0exKZjiW6dC19p5=='fa': title = 'صفحه '
		if qStMGnRJL0exKZjiW6dC19p5=='fa2': title = 'صفحه '
		for yMow8gGil5unXPdDQFv in range(1,11) :
			if not clAzmREWwXf6Gk==str(yMow8gGil5unXPdDQFv):
				M9gUm6tqLPSxFAshC7Vc1EndHXR8v = '0'+str(yMow8gGil5unXPdDQFv)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title+str(yMow8gGil5unXPdDQFv),url,22,eHdDoxhJCEPMZFVa2fg,V3ntAURQL9G4+M9gUm6tqLPSxFAshC7Vc1EndHXR8v[-2:])
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url,clAzmREWwXf6Gk):
	if not clAzmREWwXf6Gk: clAzmREWwXf6Gk = 0
	oGqutYr9UleWM = YjuSRTL3xCKG1hlecdbFgf9avkP(url)
	Ph6lazTI975srx = YjuSRTL3xCKG1hlecdbFgf9avkP(url)
	qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(url)
	dezG4T3itVrAKvX9 = url.split('/')
	id,type = dezG4T3itVrAKvX9[-1],dezG4T3itVrAKvX9[3]
	V3ntAURQL9G4 = str(int(clAzmREWwXf6Gk)//100)
	clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)%100)
	peAJFoZLMcPuskI = 0
	if type=='Series':
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-EPISODES-1st')
		items = cBawilJXvK1m.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		title = ' - الحلقة '
		if qStMGnRJL0exKZjiW6dC19p5=='en': title = ' - Episode '
		if qStMGnRJL0exKZjiW6dC19p5=='fa': title = ' - قسمت '
		if qStMGnRJL0exKZjiW6dC19p5=='fa2': title = ' - قسمت '
		if qStMGnRJL0exKZjiW6dC19p5=='fa': CdnfH2k9jpPUq3J0NT = eHdDoxhJCEPMZFVa2fg
		else: CdnfH2k9jpPUq3J0NT = qStMGnRJL0exKZjiW6dC19p5
		bVwi07d69NYjP = cBawilJXvK1m.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for name,count,PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7 in items:
			for vQ2LDF3UyXZbhu97Y in range(int(count),0,-1):
				LLuBCcEji0gRvlsxypDeNSM7f3X4hP = PeLqCN5Ek8bB + CdnfH2k9jpPUq3J0NT + id + '/' + str(vQ2LDF3UyXZbhu97Y) + '.png'
				qWG25bhluDH8xzJLytcISf1 = name + title + str(vQ2LDF3UyXZbhu97Y)
				qWG25bhluDH8xzJLytcISf1 = zJRbA1YW2Eor(qWG25bhluDH8xzJLytcISf1)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+qWG25bhluDH8xzJLytcISf1,url,24,LLuBCcEji0gRvlsxypDeNSM7f3X4hP,eHdDoxhJCEPMZFVa2fg,str(vQ2LDF3UyXZbhu97Y))
	elif type=='Program':
		E1Viom5L3684CTOFJ = oGqutYr9UleWM+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+clAzmREWwXf6Gk+'&size=30&orderby=1'
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-EPISODES-2nd')
		items = cBawilJXvK1m.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		title = ' - الحلقة '
		if qStMGnRJL0exKZjiW6dC19p5=='en': title = ' - Episode '
		if qStMGnRJL0exKZjiW6dC19p5=='fa': title = ' - قسمت '
		if qStMGnRJL0exKZjiW6dC19p5=='fa2': title = ' - قسمت '
		for vQ2LDF3UyXZbhu97Y,PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,N2xZO9FDE8A1YnRcMrLUQGJ,name in items:
			peAJFoZLMcPuskI += 1
			LLuBCcEji0gRvlsxypDeNSM7f3X4hP = Ph6lazTI975srx + vFDQstemyYANa(PeLqCN5Ek8bB)
			name = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(name)
			qWG25bhluDH8xzJLytcISf1 = name + title + str(vQ2LDF3UyXZbhu97Y)
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+qWG25bhluDH8xzJLytcISf1,E1Viom5L3684CTOFJ,24,LLuBCcEji0gRvlsxypDeNSM7f3X4hP,eHdDoxhJCEPMZFVa2fg,str(peAJFoZLMcPuskI))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			E1Viom5L3684CTOFJ = oGqutYr9UleWM+'/Music/GetTracksBy?id='+str(id)+'&page='+clAzmREWwXf6Gk+'&size=30&type=0'
			nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-EPISODES-3rd')
			items = cBawilJXvK1m.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,name,title in items:
				peAJFoZLMcPuskI += 1
				LLuBCcEji0gRvlsxypDeNSM7f3X4hP = Ph6lazTI975srx + vFDQstemyYANa(PeLqCN5Ek8bB)
				qWG25bhluDH8xzJLytcISf1 = name + ' - ' + title
				qWG25bhluDH8xzJLytcISf1 = qWG25bhluDH8xzJLytcISf1.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qWG25bhluDH8xzJLytcISf1 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(qWG25bhluDH8xzJLytcISf1)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+qWG25bhluDH8xzJLytcISf1,E1Viom5L3684CTOFJ,24,LLuBCcEji0gRvlsxypDeNSM7f3X4hP,eHdDoxhJCEPMZFVa2fg,str(peAJFoZLMcPuskI))
		elif 'Clips' in url:
			E1Viom5L3684CTOFJ = oGqutYr9UleWM+'/Music/GetTracksBy?id=0&page='+clAzmREWwXf6Gk+'&size=30&type=15'
			nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-EPISODES-4th')
			items = cBawilJXvK1m.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			for PeLqCN5Ek8bB,title,apOKrFbP9IYHDyUVm7 in items:
				peAJFoZLMcPuskI += 1
				LLuBCcEji0gRvlsxypDeNSM7f3X4hP = Ph6lazTI975srx + vFDQstemyYANa(PeLqCN5Ek8bB)
				qWG25bhluDH8xzJLytcISf1 = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qWG25bhluDH8xzJLytcISf1 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(qWG25bhluDH8xzJLytcISf1)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+qWG25bhluDH8xzJLytcISf1,E1Viom5L3684CTOFJ,24,LLuBCcEji0gRvlsxypDeNSM7f3X4hP,eHdDoxhJCEPMZFVa2fg,str(peAJFoZLMcPuskI))
		elif 'category' in url:
			if 'category=6' in url:
				E1Viom5L3684CTOFJ = oGqutYr9UleWM+'/Music/GetTracksBy?id=0&page='+clAzmREWwXf6Gk+'&size=30&type=6'
				nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				E1Viom5L3684CTOFJ = oGqutYr9UleWM+'/Music/GetTracksBy?id=0&page='+clAzmREWwXf6Gk+'&size=30&type=4'
				nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-EPISODES-6th')
			items = cBawilJXvK1m.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,name,title in items:
				peAJFoZLMcPuskI += 1
				LLuBCcEji0gRvlsxypDeNSM7f3X4hP = Ph6lazTI975srx + vFDQstemyYANa(PeLqCN5Ek8bB)
				qWG25bhluDH8xzJLytcISf1 = name + ' - ' + title
				qWG25bhluDH8xzJLytcISf1 = qWG25bhluDH8xzJLytcISf1.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				qWG25bhluDH8xzJLytcISf1 = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(qWG25bhluDH8xzJLytcISf1)
				qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+qWG25bhluDH8xzJLytcISf1,E1Viom5L3684CTOFJ,24,LLuBCcEji0gRvlsxypDeNSM7f3X4hP,eHdDoxhJCEPMZFVa2fg,str(peAJFoZLMcPuskI))
	if type=='Music' or type=='Program':
		if peAJFoZLMcPuskI>25:
			title='صفحة '
			if qStMGnRJL0exKZjiW6dC19p5=='en': title = ' Page '
			if qStMGnRJL0exKZjiW6dC19p5=='fa': title = ' صفحه '
			if qStMGnRJL0exKZjiW6dC19p5=='fa2': title = ' صفحه '
			for yMow8gGil5unXPdDQFv in range(1,11):
				if not clAzmREWwXf6Gk==str(yMow8gGil5unXPdDQFv):
					M9gUm6tqLPSxFAshC7Vc1EndHXR8v = '0'+str(yMow8gGil5unXPdDQFv)
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title+str(yMow8gGil5unXPdDQFv),url,23,eHdDoxhJCEPMZFVa2fg,V3ntAURQL9G4+M9gUm6tqLPSxFAshC7Vc1EndHXR8v[-2:])
	return
def bbmQeYGSTIv(url,vQ2LDF3UyXZbhu97Y):
	Ph6lazTI975srx = YjuSRTL3xCKG1hlecdbFgf9avkP(url)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-PLAY-1st')
	items = cBawilJXvK1m.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(url)
		dezG4T3itVrAKvX9 = url.split('/')
		id,type = dezG4T3itVrAKvX9[-1],dezG4T3itVrAKvX9[3]
		apOKrFbP9IYHDyUVm7 = items[0][0]+qStMGnRJL0exKZjiW6dC19p5+id+'/,'+vQ2LDF3UyXZbhu97Y+','+vQ2LDF3UyXZbhu97Y+'_'+items[0][2]
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append('m3u8')
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	items = cBawilJXvK1m.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(url)
		dezG4T3itVrAKvX9 = url.split('/')
		id,type = dezG4T3itVrAKvX9[-1],dezG4T3itVrAKvX9[3]
		apOKrFbP9IYHDyUVm7 = items[0][0]+qStMGnRJL0exKZjiW6dC19p5+id+'/'+vQ2LDF3UyXZbhu97Y+items[0][2]
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append('mp4 url')
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	items = cBawilJXvK1m.findall('source src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7 in items:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('//','/')
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append('mp4 src')
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	items = cBawilJXvK1m.findall('VideoAddress":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		apOKrFbP9IYHDyUVm7 = items[int(vQ2LDF3UyXZbhu97Y)-1]
		apOKrFbP9IYHDyUVm7 = Ph6lazTI975srx+vFDQstemyYANa(apOKrFbP9IYHDyUVm7)
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append('mp4 address')
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	items = cBawilJXvK1m.findall('VoiceAddress":"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		apOKrFbP9IYHDyUVm7 = items[int(vQ2LDF3UyXZbhu97Y)-1]
		apOKrFbP9IYHDyUVm7 = Ph6lazTI975srx+vFDQstemyYANa(apOKrFbP9IYHDyUVm7)
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append('mp3 address')
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if len(ppQOjlq2gaPkW)==1: apOKrFbP9IYHDyUVm7 = ppQOjlq2gaPkW[0]
	else:
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('اختر الفيديو المناسب:', FBITEXGDfe2mcCxnQs6ktMdy9HJh)
		if iLcCSnPyKYWs3xkQ0p14 == -1 : return
		apOKrFbP9IYHDyUVm7 = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	IZkpyKSFVarcHwG1g6emqQv70h(apOKrFbP9IYHDyUVm7,EERWJf1adv67,'video')
	return
def YjuSRTL3xCKG1hlecdbFgf9avkP(url):
	if q3QVhZaDEuo8t2ASj5vkn in url: uujC2KDqoT3rGHzPpAW1mf = q3QVhZaDEuo8t2ASj5vkn
	elif hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c in url: uujC2KDqoT3rGHzPpAW1mf = hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c
	elif v2as4pXGlNC0xRiztVLFEoeM in url: uujC2KDqoT3rGHzPpAW1mf = v2as4pXGlNC0xRiztVLFEoeM
	elif AGa4PFvZo8QjuiEz6ymB in url: uujC2KDqoT3rGHzPpAW1mf = AGa4PFvZo8QjuiEz6ymB
	else: uujC2KDqoT3rGHzPpAW1mf = eHdDoxhJCEPMZFVa2fg
	return uujC2KDqoT3rGHzPpAW1mf
def kkRaJUx3oCtHO4PbBnYeTgdS(url):
	if   q3QVhZaDEuo8t2ASj5vkn in url: qStMGnRJL0exKZjiW6dC19p5 = 'ar'
	elif hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c in url: qStMGnRJL0exKZjiW6dC19p5 = 'en'
	elif v2as4pXGlNC0xRiztVLFEoeM in url: qStMGnRJL0exKZjiW6dC19p5 = 'fa'
	elif AGa4PFvZo8QjuiEz6ymB in url: qStMGnRJL0exKZjiW6dC19p5 = 'fa2'
	else: qStMGnRJL0exKZjiW6dC19p5 = eHdDoxhJCEPMZFVa2fg
	return qStMGnRJL0exKZjiW6dC19p5
def ozPjuMtH32DEISFKQl(url):
	qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(url)
	E1Viom5L3684CTOFJ = url + '/Home/Live'
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-LIVE-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	items = cBawilJXvK1m.findall('source src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	ajHR9ABQl2buvm = items[0]
	IZkpyKSFVarcHwG1g6emqQv70h(ajHR9ABQl2buvm,EERWJf1adv67,'live')
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	if showDialogs:
		j54hMaE2YWq = [ q3QVhZaDEuo8t2ASj5vkn , hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c , v2as4pXGlNC0xRiztVLFEoeM , AGa4PFvZo8QjuiEz6ymB ]
		zzSnQP3O5HIVpmji10gC4tY = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('اختر اللغة المناسبة:', zzSnQP3O5HIVpmji10gC4tY)
		if iLcCSnPyKYWs3xkQ0p14 == -1 : return
		website = j54hMaE2YWq[iLcCSnPyKYWs3xkQ0p14]
	else:
		if '_IFILM-ARABIC_' in WWLbVhETM9ZCwm85f: website = q3QVhZaDEuo8t2ASj5vkn
		elif '_IFILM-ENGLISH_' in WWLbVhETM9ZCwm85f: website = hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c
		else: website = eHdDoxhJCEPMZFVa2fg
	if not website: return
	qStMGnRJL0exKZjiW6dC19p5 = kkRaJUx3oCtHO4PbBnYeTgdS(website)
	E1Viom5L3684CTOFJ = website + "/Home/Search?searchstring=" + diojk6J5vzuRNDKmw
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'IFILM-SEARCH-1st')
	items = cBawilJXvK1m.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		for PeLqCN5Ek8bB,U3d2hkuwDIj56,id,title in items:
			if U3d2hkuwDIj56 in ['3','7']:
				title = title.replace('\\',eHdDoxhJCEPMZFVa2fg)
				title = title.replace('"',eHdDoxhJCEPMZFVa2fg)
				if U3d2hkuwDIj56=='3':
					type = 'Series'
					if qStMGnRJL0exKZjiW6dC19p5=='ar': name = 'مسلسل : '
					elif qStMGnRJL0exKZjiW6dC19p5=='en': name = 'Series : '
					elif qStMGnRJL0exKZjiW6dC19p5=='fa': name = 'سريال ها : '
					elif qStMGnRJL0exKZjiW6dC19p5=='fa2': name = 'سريال ها : '
				elif U3d2hkuwDIj56=='5':
					type = 'Film'
					if qStMGnRJL0exKZjiW6dC19p5=='ar': name = 'فيلم : '
					elif qStMGnRJL0exKZjiW6dC19p5=='en': name = 'Movie : '
					elif qStMGnRJL0exKZjiW6dC19p5=='fa': name = 'فيلم : '
					elif qStMGnRJL0exKZjiW6dC19p5=='fa2': name = 'فلم ها : '
				elif U3d2hkuwDIj56=='7':
					type = 'Program'
					if qStMGnRJL0exKZjiW6dC19p5=='ar': name = 'برنامج : '
					elif qStMGnRJL0exKZjiW6dC19p5=='en': name = 'Program : '
					elif qStMGnRJL0exKZjiW6dC19p5=='fa': name = 'برنامه ها : '
					elif qStMGnRJL0exKZjiW6dC19p5=='fa2': name = 'برنامه ها : '
				title = name + title
				apOKrFbP9IYHDyUVm7 = website + '/' + type + '/Content/' + id
				PeLqCN5Ek8bB = vFDQstemyYANa(PeLqCN5Ek8bB)
				PeLqCN5Ek8bB = website+PeLqCN5Ek8bB
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,23,PeLqCN5Ek8bB,'101')
	return
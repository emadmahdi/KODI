# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
import xbmc as ccwRLKk3hs0E,re as cBawilJXvK1m,sys as jjO4Xf7GBW8Dx2HR0tdP,xbmcaddon as Z1ZPVbLUsHgxd7X,random as GljITSOwLKW36,os as RRydns1CErYlIhwSx7,xbmcvfs as vUiXo5fLMYs4Ku0yRtrI8CZDz,time as b8bLFaejUB,pickle as F7pgAanycjuNEB6GVXR,zlib as vGPgxMCUnVTb6fDsXkRS,xbmcgui as VVZgPQ2kYLoKe6jic5AEzqupG,xbmcplugin as bCfjxP8yo4Qn3trXKNgW1AUl,sqlite3 as ANKVD4WrwZCuUEl,traceback as Wf01HbdyEtp5N4BUKCcY7,threading as fFkWcdnY8bEHhXMNpCjx6Ia7VAze,hashlib as TOjyaHnYozURG
EERWJf1adv67 = LTN6DPEmrwehtZMy(u"ࠩࡏࡍࡇ࡙ࡏࡏࡇࠪॣ")
eHdDoxhJCEPMZFVa2fg = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࠫ।")
avcfIls8w7gk69hYUErHxzQTXtm24j = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࠥ࠭॥")
KwJyZLDzC4FbHhXgTfI = avcfIls8w7gk69hYUErHxzQTXtm24j*w2vjZmdJuY7c(u"࠷૙")
D8OnEGLjecaXw = avcfIls8w7gk69hYUErHxzQTXtm24j*egY8Jti0smdLM3h1VQRSW(u"࠹૚")
h597x8jYiAIBDzcedPslw6pQy = avcfIls8w7gk69hYUErHxzQTXtm24j*EX25Y0l8ILvz7QcRC(u"࠴૛")
YchIv6N09BaWPEj4tieAnluKZrRXT = ilBWK5nXxg1do4jENGC07Zq(u"ࡕࡴࡸࡩଛ")
rDceXBpHkfVUYRJ3tIx95Z = J7divaGOCgq2SLfXpDzZYN58wc(u"ࡈࡤࡰࡸ࡫ଜ")
x1Oa8bBf36EwsLMirtFc = jUcmHhgVvW0EdYOIfXeaDF(u"࠱૜")
NSudqlOzja = t3coAp06zvHrTl49bUVgx(u"࠳૝")
FB0pIzAoK8wqgd3UiY5 = bP01xn84BiQN(u"࠵૞")
bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1 = RqLvTrID0yMVeClpYcnZ16i3X(u"࠷૟")
BSw5mizCOsKxWrRDvtJuFajY = I5bUBGpPXn0W6(u"࠹ૠ")
SbyWQGMDnV = ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ०")
OR97bMGecfgDCqux3YdAZ6y = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩ१")
Nat0Dx9puRUWCsgz6JyFhY3 = RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ२")
m6PFtLblInpNZ8x = ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡷࡷࡪ࠽࠭३")
iwIlVQsgYezu = wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ४")
eQb20ZUHIjXE3xqsCWLfkghRGBFaNY = egY8Jti0smdLM3h1VQRSW(u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ५")
yqSNdm93iAa5CfwE1sL = CKUiyEe28zsZ(u"ࠫࡊࡘࡒࡐࡔࠪ६")
bGQ2Ok7RNi = egY8Jti0smdLM3h1VQRSW(u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ७")
kDUv7ouWrcgMe6OipQJm = ilBWK5nXxg1do4jENGC07Zq(u"࠭࡜࡯ࠩ८")
y1fVB2E63aLnJgkWeCZHujY = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧ࡝ࡴࠪ९")
lAf7eTIozDOK0arHsmWx = Z1ZPVbLUsHgxd7X.Addon().getAddonInfo(LyOR7f69iA(u"ࠨࡲࡤࡸ࡭࠭॰"))
fI7nHo5s1m = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,LTN6DPEmrwehtZMy(u"ࠩࡳࡥࡨࡱࡡࡨࡧࡶࠫॱ"))
jjO4Xf7GBW8Dx2HR0tdP.path.append(fI7nHo5s1m)
UBgvOF9CZQSexLVGYKuNER = ccwRLKk3hs0E.getInfoLabel(f90fGrlSEObDsuiA3U(u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡆࡺ࡯࡬ࡥࡘࡨࡶࡸ࡯࡯࡯ࠤॲ"))
YB5Segc7IQ = cBawilJXvK1m.findall(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫ࠭ࡢࡤ࡝ࡦ࡟࠲ࡡࡪࠩࠨॳ"),UBgvOF9CZQSexLVGYKuNER,cBawilJXvK1m.DOTALL)
YB5Segc7IQ = float(YB5Segc7IQ[x1Oa8bBf36EwsLMirtFc])
jqIwWfpDc0F8MYey6ACXi2xduZrl = ccwRLKk3hs0E.Player
kUJmKtWGNH8p5OjA2MPrZQ9I0zeTVa = VVZgPQ2kYLoKe6jic5AEzqupG.WindowXMLDialog
lHfbysRrUV7m4CLSdkxc382n = YB5Segc7IQ<KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠷࠹ૡ")
WHjh1POtMKlmgiy68RSqb = YB5Segc7IQ>eNEhtuoi9gK8JaTpIXj(u"࠱࠹࠰࠼࠽ૢ")
if WHjh1POtMKlmgiy68RSqb:
	oc9p6nGmUDgxHAXQ7K5qiMREZFa = ccwRLKk3hs0E.LOGINFO
	Gd4fNUpaveYtQDxi,EigLDrG278jQVcmy = EX25Y0l8ILvz7QcRC(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭ॴ"),egY8Jti0smdLM3h1VQRSW(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧॵ")
	H87log1SiQZyvWptwqu5saUx6KfR9A = vUiXo5fLMYs4Ku0yRtrI8CZDz.translatePath(wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨॶ"))
	from urllib.parse import unquote as _ckXDpdLgzWweCu
else:
	oc9p6nGmUDgxHAXQ7K5qiMREZFa = ccwRLKk3hs0E.LOGNOTICE
	Gd4fNUpaveYtQDxi,EigLDrG278jQVcmy = KW5bYS20wTF1LyCs9(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡢࠩॷ").encode(m6PFtLblInpNZ8x),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࡷࠪࡠࡺ࠸࠰࠳ࡤࠪॸ").encode(m6PFtLblInpNZ8x)
	H87log1SiQZyvWptwqu5saUx6KfR9A = ccwRLKk3hs0E.translatePath(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡴࡦ࡯ࡳࠫॹ"))
	from urllib import unquote as _ckXDpdLgzWweCu
oomLAB9uhfF1R = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷࠲ૣ")
xvjre5b4yREScf = bP01xn84BiQN(u"࠸࠳૤")*oomLAB9uhfF1R
Fn5oVSaCmIHciWzEy1Leht0qwXQMT = jUcmHhgVvW0EdYOIfXeaDF(u"࠵࠸૥")*xvjre5b4yREScf
s01vIrJYTDlBpRzGnZLN = HkiMU0QrdzW3l6gwnT(u"࠷࠵૦")*Fn5oVSaCmIHciWzEy1Leht0qwXQMT
ZAl2gePWifs3IXG = x1Oa8bBf36EwsLMirtFc
OclpauhMYPIx502SgUe1X7EWd = t3coAp06zvHrTl49bUVgx(u"࠸࠶૧")*oomLAB9uhfF1R
srU0Sl1oOC29FB6gHTYX = FB0pIzAoK8wqgd3UiY5*xvjre5b4yREScf
bbfreYhcgwZlKEGVx7zRU = eNEhtuoi9gK8JaTpIXj(u"࠷࠶૨")*xvjre5b4yREScf
c4cPSX2jOIm8KCQlfW5wM = bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1*Fn5oVSaCmIHciWzEy1Leht0qwXQMT
oTdjz7uhFYDxOvgaRnJcP5X = t3coAp06zvHrTl49bUVgx(u"࠳࠱૩")*Fn5oVSaCmIHciWzEy1Leht0qwXQMT
ICRfWub2vqlor0Q = egY8Jti0smdLM3h1VQRSW(u"࠲࠴૪")*s01vIrJYTDlBpRzGnZLN
xHs1lKmBbG5PT9LwN = xvjre5b4yREScf
L1BnkG7RhvcXZoWfjdDHq3Uzu2E = jjO4Xf7GBW8Dx2HR0tdP.argv[x1Oa8bBf36EwsLMirtFc].split(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫ࠴࠭ॺ"))[FB0pIzAoK8wqgd3UiY5]
ZFsK7DtIkrHGnWQYhUM8P = int(jjO4Xf7GBW8Dx2HR0tdP.argv[NSudqlOzja])
H4ys6we0jDn = jjO4Xf7GBW8Dx2HR0tdP.argv[FB0pIzAoK8wqgd3UiY5]
v1Qo2asXtSrN7xuU = L1BnkG7RhvcXZoWfjdDHq3Uzu2E.split(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬ࠴ࠧॻ"))[FB0pIzAoK8wqgd3UiY5]
MCrWtwnF2TViZOD7z0pXgqI4 = ccwRLKk3hs0E.getInfoLabel(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡁࡥࡦࡲࡲ࡛࡫ࡲࡴ࡫ࡲࡲ࠭࠭ॼ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+bP01xn84BiQN(u"ࠧࠪࠩॽ"))
oX9h2wrQe5 = RRydns1CErYlIhwSx7.path.join(H87log1SiQZyvWptwqu5saUx6KfR9A,L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
pyifuNFdxe = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,ilBWK5nXxg1do4jENGC07Zq(u"ࠨ࡯ࡤ࡭ࡳࡪࡡࡵࡣ࠱ࡨࡧ࠭ॾ"))
s4FvMNOledIt = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩ࡯ࡥࡸࡺࡶࡪࡦࡨࡳࡸ࠴ࡤࡢࡶࠪॿ"))
a8HLTkO2ns49yGNgiroS = int(b8bLFaejUB.time())
MoO74hKeqm8fFka = Z1ZPVbLUsHgxd7X.Addon(id=L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
gUt6FLhYsHfDxywcqlGrRQzI5KZTVM = MoO74hKeqm8fFka.getSetting(egY8Jti0smdLM3h1VQRSW(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧঀ"))
tJWbQ0cyZoe = rDceXBpHkfVUYRJ3tIx95Z if gUt6FLhYsHfDxywcqlGrRQzI5KZTVM==MCrWtwnF2TViZOD7z0pXgqI4 else YchIv6N09BaWPEj4tieAnluKZrRXT
def ZZOBwdspmUJWtNH9KPyj0TI5V68hv(FeTJrG4SkMf09iVys8A,zoe6jlvGVJnuW3gLPq=Cp6c5tZe8I0PxnAW(u"ࠫࡄ࠭ঁ")):
	if ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡃࠧং") in FeTJrG4SkMf09iVys8A:
		if zoe6jlvGVJnuW3gLPq in FeTJrG4SkMf09iVys8A: E1Viom5L3684CTOFJ,VJrBK52c0Pi1qeAvMX8TszFSOulZ = FeTJrG4SkMf09iVys8A.split(zoe6jlvGVJnuW3gLPq,ietolwsjpIPK7Fr(u"࠳૫"))
		else: E1Viom5L3684CTOFJ,VJrBK52c0Pi1qeAvMX8TszFSOulZ = eHdDoxhJCEPMZFVa2fg,FeTJrG4SkMf09iVys8A
		VJrBK52c0Pi1qeAvMX8TszFSOulZ = VJrBK52c0Pi1qeAvMX8TszFSOulZ.split(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࠦࠨঃ"))
		LbAmEhrdt7eRV2Y = {}
		for XnjvmsIw71pPQTFSHfROLo in VJrBK52c0Pi1qeAvMX8TszFSOulZ:
			rBw5YZ31M7HOv,zwLjnRNHpA6a = XnjvmsIw71pPQTFSHfROLo.split(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧ࠾ࠩ঄"),bP01xn84BiQN(u"࠴૬"))
			LbAmEhrdt7eRV2Y[rBw5YZ31M7HOv] = zwLjnRNHpA6a
	else: E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = FeTJrG4SkMf09iVys8A,{}
	return E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y
def O8pF1bNVh2BTZDAawLJmyXul75jfk(d8De716ZlA2):
	uW15CNBHr2UeTjvz9p,uujC2KDqoT3rGHzPpAW1mf,GGrWxJjBuhcgpyNFToq = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	d8De716ZlA2 = d8De716ZlA2.replace(Gd4fNUpaveYtQDxi,eHdDoxhJCEPMZFVa2fg).replace(EigLDrG278jQVcmy,eHdDoxhJCEPMZFVa2fg)
	hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠨࠪ࠱࠭ࡡࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡜࡞ࠪ࡟ࡻࡡࡽ࡜ࡸࠫࠣ࠯ࡡࡡ࡜࠰ࡅࡒࡐࡔࡘ࡜࡞ࠪ࠱࠮ࡄ࠯ࠤࠨঅ"),d8De716ZlA2,cBawilJXvK1m.DOTALL)
	if hPYnfjbqWDJNSAeyQaBrOZt68: uW15CNBHr2UeTjvz9p,uujC2KDqoT3rGHzPpAW1mf,d8De716ZlA2 = hPYnfjbqWDJNSAeyQaBrOZt68[x1Oa8bBf36EwsLMirtFc]
	if uW15CNBHr2UeTjvz9p not in [avcfIls8w7gk69hYUErHxzQTXtm24j,XugxFprC26zGM(u"ࠩ࠯ࠫআ"),eHdDoxhJCEPMZFVa2fg]: GGrWxJjBuhcgpyNFToq = XugxFprC26zGM(u"ࠪࡣࡒࡕࡄࡠࠩই")
	if uujC2KDqoT3rGHzPpAW1mf: uujC2KDqoT3rGHzPpAW1mf = jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡤ࠭ঈ")+uujC2KDqoT3rGHzPpAW1mf+LTN6DPEmrwehtZMy(u"ࠬࡥࠧউ")
	d8De716ZlA2 = uujC2KDqoT3rGHzPpAW1mf+GGrWxJjBuhcgpyNFToq+d8De716ZlA2
	return d8De716ZlA2
def zrHeZWCqQMOymk1d7anKpu0vEx8(FeTJrG4SkMf09iVys8A):
	return _ckXDpdLgzWweCu(FeTJrG4SkMf09iVys8A)
def udpczrlynT3vQ98HhDYqgFw2SWo4MG(jYrhe2DlgPp9x0I):
	IeuNTCO7bgqFrWv3A9c62kLnZpsJRP = {TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡴࡺࡲࡨࠫঊ"):eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠧ࡮ࡱࡧࡩࠬঋ"):eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡷࡵࡰࠬঌ"):eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠩࡷࡩࡽࡺࠧ঍"):eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠪࡴࡦ࡭ࡥࠨ঎"):eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠫࡳࡧ࡭ࡦࠩএ"):eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠬ࡯࡭ࡢࡩࡨࠫঐ"):eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"࠭ࡣࡰࡰࡷࡩࡽࡺࠧ঑"):eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡪࡰࡩࡳࡩ࡯ࡣࡵࠩ঒"):eHdDoxhJCEPMZFVa2fg}
	if ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡁࠪও") in jYrhe2DlgPp9x0I: jYrhe2DlgPp9x0I = jYrhe2DlgPp9x0I.split(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡂࠫঔ"),NSudqlOzja)[NSudqlOzja]
	E1Viom5L3684CTOFJ,Au5gIC7EelW9snQpKOotaLVr = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(jYrhe2DlgPp9x0I)
	aargs = dict(list(IeuNTCO7bgqFrWv3A9c62kLnZpsJRP.items())+list(Au5gIC7EelW9snQpKOotaLVr.items()))
	RoSzmHKdiUqnsx = aargs[t3coAp06zvHrTl49bUVgx(u"ࠪࡱࡴࡪࡥࠨক")]
	Tv4kxUQzM86cK1nCmP = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[f90fGrlSEObDsuiA3U(u"ࠫࡺࡸ࡬ࠨখ")])
	rHM3ovhRVt8Qp4W0xIigdN = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡺࡥࡹࡶࠪগ")])
	zz3BeUfyNow7kZ0nvtxhKqWr4P = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡰࡢࡩࡨࠫঘ")])
	kPsKXxVnAmE7YDH = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[t3coAp06zvHrTl49bUVgx(u"ࠧࡵࡻࡳࡩࠬঙ")])
	JqZhbG9Le2NQvziaPCx8wI = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡰࡤࡱࡪ࠭চ")])
	u1INEBX5oqPx = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡬ࡱࡦ࡭ࡥࠨছ")])
	OyUZmAVsn1NWrBwbD = aargs[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫজ")]
	kUCr63DJOKy71AqLI2w5v8tb = zrHeZWCqQMOymk1d7anKpu0vEx8(aargs[HkiMU0QrdzW3l6gwnT(u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ঝ")])
	if kUCr63DJOKy71AqLI2w5v8tb: kUCr63DJOKy71AqLI2w5v8tb = eval(kUCr63DJOKy71AqLI2w5v8tb)
	else: kUCr63DJOKy71AqLI2w5v8tb = {}
	if not RoSzmHKdiUqnsx: kPsKXxVnAmE7YDH = TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬঞ") ; RoSzmHKdiUqnsx = EX25Y0l8ILvz7QcRC(u"࠭࠲࠷࠲ࠪট")
	return kPsKXxVnAmE7YDH,JqZhbG9Le2NQvziaPCx8wI,Tv4kxUQzM86cK1nCmP,RoSzmHKdiUqnsx,u1INEBX5oqPx,zz3BeUfyNow7kZ0nvtxhKqWr4P,rHM3ovhRVt8Qp4W0xIigdN,OyUZmAVsn1NWrBwbD,kUCr63DJOKy71AqLI2w5v8tb
def WMyqfm31ka2jICwiE(EERWJf1adv67):
	FTOeJ3jwKdNm5W = jjO4Xf7GBW8Dx2HR0tdP._getframe(NSudqlOzja).f_code.co_name
	if not EERWJf1adv67 or not FTOeJ3jwKdNm5W or FTOeJ3jwKdNm5W==HkiMU0QrdzW3l6gwnT(u"ࠧ࠽࡯ࡲࡨࡺࡲࡥ࠿ࠩঠ"):
		return KW5bYS20wTF1LyCs9(u"ࠨ࡝ࠣࠫড")+v1Qo2asXtSrN7xuU.upper()+LTN6DPEmrwehtZMy(u"ࠩ࠰ࠫঢ")+MCrWtwnF2TViZOD7z0pXgqI4+eNEhtuoi9gK8JaTpIXj(u"ࠪ࠱ࠬণ")+str(YB5Segc7IQ)+Cp6c5tZe8I0PxnAW(u"ࠫࠥࡣࠧত")
	return Cp6c5tZe8I0PxnAW(u"ࠬ࠴࡜ࡵࠩথ")+FTOeJ3jwKdNm5W
def vR9cOpMtk51j(EtzJ6C0kTPVKWpeGQ,bOEZeag9A1qL206uh3o75):
	if lHfbysRrUV7m4CLSdkxc382n: bOEZeag9A1qL206uh3o75 = bOEZeag9A1qL206uh3o75.decode(m6PFtLblInpNZ8x).encode(m6PFtLblInpNZ8x)
	V6Aq8XJugydFlv0KtcUZkh1LeH3MP = oc9p6nGmUDgxHAXQ7K5qiMREZFa
	a0VHgjbCY1KfuI6o = [eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg]
	if EtzJ6C0kTPVKWpeGQ: bOEZeag9A1qL206uh3o75 = bOEZeag9A1qL206uh3o75.replace(OR97bMGecfgDCqux3YdAZ6y,eHdDoxhJCEPMZFVa2fg).replace(SbyWQGMDnV,eHdDoxhJCEPMZFVa2fg).replace(Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg)
	else: EtzJ6C0kTPVKWpeGQ = iwIlVQsgYezu
	ljQza5sHUDXVt0N,zoe6jlvGVJnuW3gLPq = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭࡜ࡵࠩদ"),D8OnEGLjecaXw
	Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg = EX25Y0l8ILvz7QcRC(u"࠹࠸૮")*avcfIls8w7gk69hYUErHxzQTXtm24j if WHjh1POtMKlmgiy68RSqb else iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠷࠶૭")*avcfIls8w7gk69hYUErHxzQTXtm24j
	cQji0G1dfKpnWmlRhV = BSw5mizCOsKxWrRDvtJuFajY*ljQza5sHUDXVt0N
	if bOEZeag9A1qL206uh3o75.startswith(HkiMU0QrdzW3l6gwnT(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨধ")): bOEZeag9A1qL206uh3o75 = NxXMrsTC5FniYuRBOK8(u"ࠨ࠰࡟ࡸࠬন")+bOEZeag9A1qL206uh3o75
	if yqSNdm93iAa5CfwE1sL in EtzJ6C0kTPVKWpeGQ: V6Aq8XJugydFlv0KtcUZkh1LeH3MP = ccwRLKk3hs0E.LOGERROR
	if EtzJ6C0kTPVKWpeGQ in [iwIlVQsgYezu,yqSNdm93iAa5CfwE1sL]: a0VHgjbCY1KfuI6o = [bOEZeag9A1qL206uh3o75]
	elif EtzJ6C0kTPVKWpeGQ==bGQ2Ok7RNi: a0VHgjbCY1KfuI6o = bOEZeag9A1qL206uh3o75.split(zoe6jlvGVJnuW3gLPq)
	elif EtzJ6C0kTPVKWpeGQ==eQb20ZUHIjXE3xqsCWLfkghRGBFaNY:
		ge4hFRp51QsUPtGTnBuzka = bOEZeag9A1qL206uh3o75.split(zoe6jlvGVJnuW3gLPq)
		a0VHgjbCY1KfuI6o = [ge4hFRp51QsUPtGTnBuzka[x1Oa8bBf36EwsLMirtFc]]
		for HIlROZrLU1bpzD0KPGqja7BVc in range(NSudqlOzja,len(ge4hFRp51QsUPtGTnBuzka),FB0pIzAoK8wqgd3UiY5):
			try: ObLBvMRVloJzsmy1Zd = ge4hFRp51QsUPtGTnBuzka[HIlROZrLU1bpzD0KPGqja7BVc]+zoe6jlvGVJnuW3gLPq+ge4hFRp51QsUPtGTnBuzka[HIlROZrLU1bpzD0KPGqja7BVc+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠷૯")]
			except: ObLBvMRVloJzsmy1Zd = ge4hFRp51QsUPtGTnBuzka[HIlROZrLU1bpzD0KPGqja7BVc]
			a0VHgjbCY1KfuI6o.append(ObLBvMRVloJzsmy1Zd)
	jTm0nCEA83h = a0VHgjbCY1KfuI6o[x1Oa8bBf36EwsLMirtFc]
	for RFs8k3UxnlTaNu4EGBJderbK1X in a0VHgjbCY1KfuI6o[NSudqlOzja:]:
		if EtzJ6C0kTPVKWpeGQ in [bGQ2Ok7RNi,eQb20ZUHIjXE3xqsCWLfkghRGBFaNY]: cQji0G1dfKpnWmlRhV += ljQza5sHUDXVt0N
		jTm0nCEA83h += y1fVB2E63aLnJgkWeCZHujY+Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg+cQji0G1dfKpnWmlRhV+RFs8k3UxnlTaNu4EGBJderbK1X
	jTm0nCEA83h += QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࠣࡣࠬ঩")
	if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࠩࠬপ") in jTm0nCEA83h: jTm0nCEA83h = zrHeZWCqQMOymk1d7anKpu0vEx8(jTm0nCEA83h)
	ccwRLKk3hs0E.log(jTm0nCEA83h,level=V6Aq8XJugydFlv0KtcUZkh1LeH3MP)
	return
def EnU1P9x4k7DF6ie5TWAKChB0mSzrN(zHOEFk27fChwMr0GKXWSy19URm4):
	Mh2SmYKyRLsevXCJpTajHZbi0Gf = ANKVD4WrwZCuUEl.connect(zHOEFk27fChwMr0GKXWSy19URm4)
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.text_factory = str
	O4OfQzkx1KmeIHrjT97E0byA = Mh2SmYKyRLsevXCJpTajHZbi0Gf.cursor()
	O4OfQzkx1KmeIHrjT97E0byA.execute(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡩ࡟ࡪࡰࡧࡩࡽࡃ࡮ࡰ࠽ࠪফ"))
	O4OfQzkx1KmeIHrjT97E0byA.execute(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡖࡒࡂࡉࡐࡅࠥ࡯ࡧ࡯ࡱࡵࡩࡤࡩࡨࡦࡥ࡮ࡣࡨࡵ࡮ࡴࡶࡵࡥ࡮ࡴࡴࡴ࠿ࡼࡩࡸࡁࠧব"))
	O4OfQzkx1KmeIHrjT97E0byA.execute(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡪࡰࡷࡵࡲࡦࡲ࡟࡮ࡱࡧࡩࡂࡕࡆࡇ࠽ࠪভ"))
	O4OfQzkx1KmeIHrjT97E0byA.execute(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡴࡻࡱࡧ࡭ࡸ࡯࡯ࡱࡸࡷࡂࡕࡆࡇ࠽ࠪম"))
	return Mh2SmYKyRLsevXCJpTajHZbi0Gf,O4OfQzkx1KmeIHrjT97E0byA
def k5L96NenKBwpSYWv(zHOEFk27fChwMr0GKXWSy19URm4,ea5ZizEDufroHsSybP1,uun0dP1mChlsjbX2HW59oI=None):
	try: Mh2SmYKyRLsevXCJpTajHZbi0Gf,O4OfQzkx1KmeIHrjT97E0byA = EnU1P9x4k7DF6ie5TWAKChB0mSzrN(zHOEFk27fChwMr0GKXWSy19URm4)
	except: return
	if uun0dP1mChlsjbX2HW59oI==None: O4OfQzkx1KmeIHrjT97E0byA.execute(NxXMrsTC5FniYuRBOK8(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪয")+ea5ZizEDufroHsSybP1+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࠥࠤࡀ࠭র"))
	else:
		Tp4umHFyBg1avosQZnGClRxPVf = (str(uun0dP1mChlsjbX2HW59oI),)
		try:
			if I5bUBGpPXn0W6(u"ࠪࠩࠬ঱") in uun0dP1mChlsjbX2HW59oI: O4OfQzkx1KmeIHrjT97E0byA.execute(t3coAp06zvHrTl49bUVgx(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫল")+ea5ZizEDufroHsSybP1+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࡬ࡪ࡭ࡨࠤࡄࠦ࠻ࠨ঳"),Tp4umHFyBg1avosQZnGClRxPVf)
			else: O4OfQzkx1KmeIHrjT97E0byA.execute(XugxFprC26zGM(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭঴")+ea5ZizEDufroHsSybP1+egY8Jti0smdLM3h1VQRSW(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࠿ࠣࡃࠥࡁࠧ঵"),Tp4umHFyBg1avosQZnGClRxPVf)
		except: pass
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.commit()
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.close()
	return
class N4QdARPf58yWHEosk7mJ(): pass
class maQf4xXLtV2(N4QdARPf58yWHEosk7mJ):
	def __init__(HdFhWUe2bNoCMA0):
		HdFhWUe2bNoCMA0.url = eHdDoxhJCEPMZFVa2fg
		HdFhWUe2bNoCMA0.code = -S8i3sBYoHWdTURpAgN(u"࠹࠺૰")
		HdFhWUe2bNoCMA0.reason = eHdDoxhJCEPMZFVa2fg
		HdFhWUe2bNoCMA0.content = eHdDoxhJCEPMZFVa2fg
		HdFhWUe2bNoCMA0.headers = {}
		HdFhWUe2bNoCMA0.cookies = {}
		HdFhWUe2bNoCMA0.succeeded = rDceXBpHkfVUYRJ3tIx95Z
def dkBvNuEQn7zOSeCxJyY56i(fW4iNwld6COELJ10):
	if fW4iNwld6COELJ10==XugxFprC26zGM(u"ࠨࡦ࡬ࡧࡹ࠭শ"): KhGpZcMqsnrbv = {}
	elif fW4iNwld6COELJ10==w2vjZmdJuY7c(u"ࠩ࡯࡭ࡸࡺࠧষ"): KhGpZcMqsnrbv = []
	elif fW4iNwld6COELJ10==EX25Y0l8ILvz7QcRC(u"ࠪࡷࡹࡸࠧস"): KhGpZcMqsnrbv = eHdDoxhJCEPMZFVa2fg
	elif fW4iNwld6COELJ10==t3coAp06zvHrTl49bUVgx(u"ࠫ࡮ࡴࡴࠨহ"): KhGpZcMqsnrbv = x1Oa8bBf36EwsLMirtFc
	elif fW4iNwld6COELJ10==KW5bYS20wTF1LyCs9(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ঺"): KhGpZcMqsnrbv = maQf4xXLtV2()
	elif not fW4iNwld6COELJ10: KhGpZcMqsnrbv = None
	else: KhGpZcMqsnrbv = None
	return KhGpZcMqsnrbv
def BoGNtDIVHAyw(KgajBwQOvh8l1CEJGc9otkdr54e3X):
	XoM1pBVAJe7cq96ndgwI32H5KSLG = MoO74hKeqm8fFka.getSetting(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩ঻"))
	BAhwu5Uvt7 = ZylBO1ktRGvdJ0.splitlines()
	hgIkBLqWiYA2QXMode = x1Oa8bBf36EwsLMirtFc
	R2apkdt0qg41 = len(KgajBwQOvh8l1CEJGc9otkdr54e3X)
	r6eWEITzJptGYLD = [rDceXBpHkfVUYRJ3tIx95Z]*R2apkdt0qg41
	for DjS2JALPlvkFph in [a8HLTkO2ns49yGNgiroS,a8HLTkO2ns49yGNgiroS-srU0Sl1oOC29FB6gHTYX]:
		nhg2KUmxC6IsPOdw8BLr1yzGVXjR = str(DjS2JALPlvkFph*KW5bYS20wTF1LyCs9(u"࠳࠳࠴࠵࠶࠰࠯࠲૲")/jUcmHhgVvW0EdYOIfXeaDF(u"࠵࠵࠵࠴࠵࠶૱"))[x1Oa8bBf36EwsLMirtFc:XugxFprC26zGM(u"࠷૳")]
		if nhg2KUmxC6IsPOdw8BLr1yzGVXjR!=hgIkBLqWiYA2QXMode:
			for HIlROZrLU1bpzD0KPGqja7BVc in range(R2apkdt0qg41):
				if not r6eWEITzJptGYLD[HIlROZrLU1bpzD0KPGqja7BVc]:
					dlu49cgYnN7fW2OaKzJsiSX8Qw = rDceXBpHkfVUYRJ3tIx95Z
					for ACJ5vmV1LDT in BAhwu5Uvt7:
						tGPueD8J42BASNIQ67r = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࡙ࠧ࠳࠼়ࠫ")+KgajBwQOvh8l1CEJGc9otkdr54e3X[HIlROZrLU1bpzD0KPGqja7BVc]+egY8Jti0smdLM3h1VQRSW(u"ࠨ࠳࠻ࡁࠬঽ")+ACJ5vmV1LDT[-TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠶࠹૴"):]+MCrWtwnF2TViZOD7z0pXgqI4+nhg2KUmxC6IsPOdw8BLr1yzGVXjR
						tGPueD8J42BASNIQ67r = TOjyaHnYozURG.md5(tGPueD8J42BASNIQ67r.encode(m6PFtLblInpNZ8x)).hexdigest()[:KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠸࠸૵")]
						if tGPueD8J42BASNIQ67r in XoM1pBVAJe7cq96ndgwI32H5KSLG:
							dlu49cgYnN7fW2OaKzJsiSX8Qw = YchIv6N09BaWPEj4tieAnluKZrRXT
							break
					r6eWEITzJptGYLD[HIlROZrLU1bpzD0KPGqja7BVc] = dlu49cgYnN7fW2OaKzJsiSX8Qw
		hgIkBLqWiYA2QXMode = nhg2KUmxC6IsPOdw8BLr1yzGVXjR
	return r6eWEITzJptGYLD
def EeZHTwQUW2BuvJyIh(zHOEFk27fChwMr0GKXWSy19URm4,HtsU1JmF0cn3fgGraqwRYNIdlhESj,ea5ZizEDufroHsSybP1,uun0dP1mChlsjbX2HW59oI=None):
	KhGpZcMqsnrbv = dkBvNuEQn7zOSeCxJyY56i(HtsU1JmF0cn3fgGraqwRYNIdlhESj)
	JEvXRNInqCF = MoO74hKeqm8fFka.getSetting(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳࡮ࡴࡵࡲࡦࡥࡨ࡮ࡥࠨা"))
	if ea5ZizEDufroHsSybP1 not in [jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ি"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡌࡒࡏࡃࡃࡏࡗࡊࡇࡒࡄࡊࡢࡗࡎ࡚ࡅࡔࠩী")] and zHOEFk27fChwMr0GKXWSy19URm4==pyifuNFdxe and uun0dP1mChlsjbX2HW59oI!=ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧু"):
		if JEvXRNInqCF==S8i3sBYoHWdTURpAgN(u"࠭ࡓࡕࡑࡓࠫূ"): return KhGpZcMqsnrbv
		hy985bf3gkpaz2Q076dvAoDjFxi = MoO74hKeqm8fFka.getSetting(jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫৃ"))
		if hy985bf3gkpaz2Q076dvAoDjFxi==ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨৄ"):
			k5L96NenKBwpSYWv(zHOEFk27fChwMr0GKXWSy19URm4,ea5ZizEDufroHsSybP1,uun0dP1mChlsjbX2HW59oI)
			return KhGpZcMqsnrbv
	yzonueArHlJT = x1Oa8bBf36EwsLMirtFc
	if JEvXRNInqCF==dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ৅"): yzonueArHlJT = xHs1lKmBbG5PT9LwN
	try: Mh2SmYKyRLsevXCJpTajHZbi0Gf,O4OfQzkx1KmeIHrjT97E0byA = EnU1P9x4k7DF6ie5TWAKChB0mSzrN(zHOEFk27fChwMr0GKXWSy19URm4)
	except: return KhGpZcMqsnrbv
	OxofTzUm0FuCyBJilh3t = YchIv6N09BaWPEj4tieAnluKZrRXT
	try: O4OfQzkx1KmeIHrjT97E0byA.execute(LTN6DPEmrwehtZMy(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠦࠬ৆")+ea5ZizEDufroHsSybP1+CKUiyEe28zsZ(u"ࠫࠧࠦࡌࡊࡏࡌࡘࠥ࠷ࠠ࠼ࠩে"))
	except: OxofTzUm0FuCyBJilh3t = rDceXBpHkfVUYRJ3tIx95Z
	if OxofTzUm0FuCyBJilh3t:
		if yzonueArHlJT: O4OfQzkx1KmeIHrjT97E0byA.execute(w2vjZmdJuY7c(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬৈ")+ea5ZizEDufroHsSybP1+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠾ࠨ৉")+str(a8HLTkO2ns49yGNgiroS+yzonueArHlJT)+ilBWK5nXxg1do4jENGC07Zq(u"ࠧࠡ࠽ࠪ৊"))
		Mh2SmYKyRLsevXCJpTajHZbi0Gf.commit()
		O4OfQzkx1KmeIHrjT97E0byA.execute(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨো")+ea5ZizEDufroHsSybP1+I5bUBGpPXn0W6(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻ࠿ࠫৌ")+str(a8HLTkO2ns49yGNgiroS)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࠤࡀ্࠭"))
		Mh2SmYKyRLsevXCJpTajHZbi0Gf.commit()
		if uun0dP1mChlsjbX2HW59oI:
			Tp4umHFyBg1avosQZnGClRxPVf = (str(uun0dP1mChlsjbX2HW59oI),)
			O4OfQzkx1KmeIHrjT97E0byA.execute(S8i3sBYoHWdTURpAgN(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡩࡧࡴࡢࠢࡉࡖࡔࡓࠠࠣࠩৎ")+ea5ZizEDufroHsSybP1+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬ৏"),Tp4umHFyBg1avosQZnGClRxPVf)
			WLSfkYNla6rzo8K = O4OfQzkx1KmeIHrjT97E0byA.fetchall()
			if WLSfkYNla6rzo8K:
				try:
					oh8Z06rUdqJ = vGPgxMCUnVTb6fDsXkRS.decompress(WLSfkYNla6rzo8K[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc])
					KhGpZcMqsnrbv = F7pgAanycjuNEB6GVXR.loads(oh8Z06rUdqJ)
				except: pass
		else:
			O4OfQzkx1KmeIHrjT97E0byA.execute(bP01xn84BiQN(u"࠭ࡓࡆࡎࡈࡇ࡙ࠦࡣࡰ࡮ࡸࡱࡳ࠲ࡤࡢࡶࡤࠤࡋࡘࡏࡎࠢࠥࠫ৐")+ea5ZizEDufroHsSybP1+HkiMU0QrdzW3l6gwnT(u"ࠧࠣࠢ࠾ࠫ৑"))
			WLSfkYNla6rzo8K = O4OfQzkx1KmeIHrjT97E0byA.fetchall()
			if WLSfkYNla6rzo8K:
				KhGpZcMqsnrbv,XM2meWnOhBqr6dCIEjgQLbwp = {},[]
				for mmHJFj8kQSyud1Xw9aL,LbAmEhrdt7eRV2Y in WLSfkYNla6rzo8K:
					krdDRZKFsomBxzPNvAOyXJu6 = vGPgxMCUnVTb6fDsXkRS.decompress(LbAmEhrdt7eRV2Y)
					LbAmEhrdt7eRV2Y = F7pgAanycjuNEB6GVXR.loads(krdDRZKFsomBxzPNvAOyXJu6)
					KhGpZcMqsnrbv[mmHJFj8kQSyud1Xw9aL] = LbAmEhrdt7eRV2Y
					XM2meWnOhBqr6dCIEjgQLbwp.append(mmHJFj8kQSyud1Xw9aL)
				if XM2meWnOhBqr6dCIEjgQLbwp:
					KhGpZcMqsnrbv[HkiMU0QrdzW3l6gwnT(u"ࠨࡡࡢࡗࡊࡗࡕࡆࡐࡆࡉࡉࡥࡃࡐࡎࡘࡑࡓ࡙࡟ࡠࠩ৒")] = XM2meWnOhBqr6dCIEjgQLbwp
					if HtsU1JmF0cn3fgGraqwRYNIdlhESj==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩ࡯࡭ࡸࡺࠧ৓"): KhGpZcMqsnrbv = XM2meWnOhBqr6dCIEjgQLbwp
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.close()
	return KhGpZcMqsnrbv
class s1Yw7hoqdZBap20gW8zi(jqIwWfpDc0F8MYey6ACXi2xduZrl):
	def __init__(HdFhWUe2bNoCMA0): pass
	def qvsFoP7fcrGbe2Nd3j9W(HdFhWUe2bNoCMA0,VZ6JH90iKsljnkgGm5e):
		HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = t3coAp06zvHrTl49bUVgx(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫ৔") if ePJWDdHsX8Tokv31yL else eHdDoxhJCEPMZFVa2fg
		HdFhWUe2bNoCMA0.VZ6JH90iKsljnkgGm5e = VZ6JH90iKsljnkgGm5e
		if not wwNbXe9taWdRiFHzyB2MZ:
			import dIxmaLQn3F
			dIxmaLQn3F.RD8m0SxQnJ(OclpauhMYPIx502SgUe1X7EWd)
	def onPlayBackStopped(HdFhWUe2bNoCMA0): HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = f90fGrlSEObDsuiA3U(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ৕")
	def onPlayBackError(HdFhWUe2bNoCMA0): HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = I5bUBGpPXn0W6(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ৖")
	def onPlayBackEnded(HdFhWUe2bNoCMA0): HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ৗ")
	def onPlayBackStarted(HdFhWUe2bNoCMA0):
		HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = eNEhtuoi9gK8JaTpIXj(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ৘")
		cFa2uhVk7R8mzYn = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=HdFhWUe2bNoCMA0.Kokn1YHEf48Amer5FObgtBxh2,args=())
		cFa2uhVk7R8mzYn.start()
	def onAVStarted(HdFhWUe2bNoCMA0):
		if wwNbXe9taWdRiFHzyB2MZ: HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = XugxFprC26zGM(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ৙")
		else: HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = t3coAp06zvHrTl49bUVgx(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ৚")
	def Kokn1YHEf48Amer5FObgtBxh2(HdFhWUe2bNoCMA0):
		import dIxmaLQn3F
		dIxmaLQn3F.mOoylMuTX7VUjNJq6YK4(NxXMrsTC5FniYuRBOK8(u"ࠪࡷࡹࡵࡰࠨ৛"))
		Gdt5Zkmzwb8yfVpaQx0jDv79MAT = x1Oa8bBf36EwsLMirtFc
		while not eval(LyOR7f69iA(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࡖࡪࡦࡨࡳ࠭࠯ࠧড়"),{QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡾࡢ࡮ࡥࠪঢ়"):ccwRLKk3hs0E}) and HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡳࡵࡣࡵࡸࡪࡪࠧ৞"):
			ccwRLKk3hs0E.sleep(w2vjZmdJuY7c(u"࠷࠰࠱࠲૶"))
			Gdt5Zkmzwb8yfVpaQx0jDv79MAT += NSudqlOzja
			if Gdt5Zkmzwb8yfVpaQx0jDv79MAT>I5bUBGpPXn0W6(u"࠶࠱૷"): return
		if ePJWDdHsX8Tokv31yL: HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = eNEhtuoi9gK8JaTpIXj(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨয়")
		elif wwNbXe9taWdRiFHzyB2MZ: HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = KQ3sCe9Pzh(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩৠ")
		elif ot06iq3huYHVAfBszvP1FjG:
			HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪৡ")
			LG3QyMvjlx8J0VFRawcBWNIS7t = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=dIxmaLQn3F.F2FQEqPicybxmHgIN,args=(HdFhWUe2bNoCMA0.VZ6JH90iKsljnkgGm5e,))
			LG3QyMvjlx8J0VFRawcBWNIS7t.start()
			LxmnUPqzh0jKykCI1gYQolcr = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=dIxmaLQn3F.ddRIn8cZ1GyW4LqBN,args=())
			LxmnUPqzh0jKykCI1gYQolcr.start()
		else: HdFhWUe2bNoCMA0.hmBXOtAQZFebaWy8l92sjDCK = ietolwsjpIPK7Fr(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫৢ")
def iZKgrsLSFq():
	XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	oTmxd82hDvO0Pyf = ccwRLKk3hs0E.getInfoLabel(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡋࡸࡩࡦࡰࡧࡰࡾࡔࡡ࡮ࡧࠪৣ"))
	try:
		Kd1wMDAUJvEBIgn = open(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࠵ࡰࡳࡱࡦ࠳ࡨࡶࡵࡪࡰࡩࡳࠬ৤"),RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡲࡣࠩ৥")).read()
		if WHjh1POtMKlmgiy68RSqb: Kd1wMDAUJvEBIgn = Kd1wMDAUJvEBIgn.decode(m6PFtLblInpNZ8x)
		kOLIiwsNQzv9 = cBawilJXvK1m.findall(ietolwsjpIPK7Fr(u"ࠧࡔࡧࡵ࡭ࡦࡲ࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫࠧࠫ০"),Kd1wMDAUJvEBIgn,cBawilJXvK1m.IGNORECASE)
		if kOLIiwsNQzv9: XPTkNeH9SqJbCc0h7BAuLiWy = kOLIiwsNQzv9[x1Oa8bBf36EwsLMirtFc]
	except: pass
	try:
		import subprocess as iStzq5Y4pIblh7NcFXsf08CHZ
		LnC36HmzOpYWreP1yVo7IQgKtu = iStzq5Y4pIblh7NcFXsf08CHZ.Popen(ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡞ࠠࠣࠢ࠲ࡷࡹࡵࡲࡢࡩࡨ࠳ࡪࡳࡵ࡭ࡣࡷࡩࡩ࠵࠰ࠡ࠽ࠣࡷࡹࡧࡴࠡ࠯ࡦࠤࠧࠦࠥࡘࠢࠥࠤ࠴ࡼࡡࡳ࠱࡯ࡳ࡬࠭১"),shell=YchIv6N09BaWPEj4tieAnluKZrRXT,stdin=iStzq5Y4pIblh7NcFXsf08CHZ.PIPE,stdout=iStzq5Y4pIblh7NcFXsf08CHZ.PIPE,stderr=iStzq5Y4pIblh7NcFXsf08CHZ.PIPE)
		CegTbcvrXIQuZBF72GHpmktjsdlU3 = LnC36HmzOpYWreP1yVo7IQgKtu.stdout.read()
		if CegTbcvrXIQuZBF72GHpmktjsdlU3:
			if WHjh1POtMKlmgiy68RSqb:
				CegTbcvrXIQuZBF72GHpmktjsdlU3 = CegTbcvrXIQuZBF72GHpmktjsdlU3.decode(m6PFtLblInpNZ8x,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩ২"))
			pp1xKG7P43W6TgOUjheFa = cBawilJXvK1m.findall(eNEhtuoi9gK8JaTpIXj(u"ࠪࠤ࠭ࡢࡤࡼ࠳࠳ࢁ࠮ࠦࠧ৩"),CegTbcvrXIQuZBF72GHpmktjsdlU3,cBawilJXvK1m.IGNORECASE)
			if pp1xKG7P43W6TgOUjheFa: HHcmRzwY7N = min(pp1xKG7P43W6TgOUjheFa)
	except: pass
	return oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N
def edpM3qtgTJIz8PWN6lvin(HrXEug1coAf0G83YPMUV4y5b=YchIv6N09BaWPEj4tieAnluKZrRXT,ZwQ23eJ6vt=RqLvTrID0yMVeClpYcnZ16i3X(u"࠴࠴૸")):
	wirYHdz3kQJVNSPFoKt = YchIv6N09BaWPEj4tieAnluKZrRXT
	if HrXEug1coAf0G83YPMUV4y5b:
		EBUe6sS04GXQzdFZjtkvAPICh9l7Wn = EeZHTwQUW2BuvJyIh(pyifuNFdxe,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡱ࡯ࡳࡵࠩ৪"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ৫"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫ৬"))
		if EBUe6sS04GXQzdFZjtkvAPICh9l7Wn:
			BAhwu5Uvt7,lnTSNWsGfDRBv12JXjmqCQ5AFEZKr,x9oEPOzpKe4BfJnT8bItWHmY1RwSFk,Wr7KwCbv81gF6XqpZQB = EBUe6sS04GXQzdFZjtkvAPICh9l7Wn
			wirYHdz3kQJVNSPFoKt = EeZHTwQUW2BuvJyIh(pyifuNFdxe,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧ࡭࡫ࡶࡸࠬ৭"),I5bUBGpPXn0W6(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ৮"),w2vjZmdJuY7c(u"ࠩࡖࡍ࡙ࡋࡓࡠࡘࡈࡖࡎࡌ࡙ࠨ৯"))
			if wirYHdz3kQJVNSPFoKt: oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N = wirYHdz3kQJVNSPFoKt
			else: oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N = iZKgrsLSFq()
			if (lnTSNWsGfDRBv12JXjmqCQ5AFEZKr,x9oEPOzpKe4BfJnT8bItWHmY1RwSFk,Wr7KwCbv81gF6XqpZQB)==(oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N): return kDUv7ouWrcgMe6OipQJm.join(BAhwu5Uvt7)
	if wirYHdz3kQJVNSPFoKt: oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N = iZKgrsLSFq()
	global v45cYAFrZBTil0kdwx3S8UNt1ga,nPmbxIfDzKF3AE
	v45cYAFrZBTil0kdwx3S8UNt1ga,nPmbxIfDzKF3AE,r39iV2YsGuRwQcnoHIx = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	ZwQ23eJ6vt = ZwQ23eJ6vt//FB0pIzAoK8wqgd3UiY5
	fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=K9Z6hot728Ywyl1Jrd).start()
	fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=KIG3NuOXkVUboTJxM).start()
	for gMmB3iopS0ZXrOFewhcxt in range(S8i3sBYoHWdTURpAgN(u"࠳࠳ૹ")):
		b8bLFaejUB.sleep(ietolwsjpIPK7Fr(u"࠳࠲࠺ૺ"))
		if not r39iV2YsGuRwQcnoHIx:
			try:
				rYxsQLi9V84eM = ccwRLKk3hs0E.getInfoLabel(eNEhtuoi9gK8JaTpIXj(u"ࠪࡒࡪࡺࡷࡰࡴ࡮࠲ࡒࡧࡣࡂࡦࡧࡶࡪࡹࡳࠨৰ"))
				if rYxsQLi9V84eM.count(S8i3sBYoHWdTURpAgN(u"ࠫ࠿࠭ৱ"))==ietolwsjpIPK7Fr(u"࠺ૼ") and rYxsQLi9V84eM.count(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬ࠶ࠧ৲"))<wY1p9mP03S8drbcH64t5WQkv(u"࠽ૻ"):
					rYxsQLi9V84eM = rYxsQLi9V84eM.lower().replace(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࠺ࠨ৳"),eHdDoxhJCEPMZFVa2fg)
					r39iV2YsGuRwQcnoHIx = str(int(rYxsQLi9V84eM,eNEhtuoi9gK8JaTpIXj(u"࠷࠶૽")))
			except: pass
		if v45cYAFrZBTil0kdwx3S8UNt1ga and nPmbxIfDzKF3AE and r39iV2YsGuRwQcnoHIx: break
	S5FVtOsQWPo6vbkYG0 = [v45cYAFrZBTil0kdwx3S8UNt1ga,nPmbxIfDzKF3AE,r39iV2YsGuRwQcnoHIx,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"ࠧ࠱࠲࠴࠵࠷࠸࠳࠴࠶࠷࠹࠺࠼࠶࠸࠹ࠪ৴")]
	if XPTkNeH9SqJbCc0h7BAuLiWy or HHcmRzwY7N:
		W6hJiATBrMDZ3R = [(BSw5mizCOsKxWrRDvtJuFajY,XPTkNeH9SqJbCc0h7BAuLiWy),(XugxFprC26zGM(u"࠵૾"),HHcmRzwY7N)]
		for rBw5YZ31M7HOv,zwLjnRNHpA6a in W6hJiATBrMDZ3R:
			zwLjnRNHpA6a = zwLjnRNHpA6a.strip(KQ3sCe9Pzh(u"ࠨ࠲ࠪ৵"))
			if zwLjnRNHpA6a:
				if WHjh1POtMKlmgiy68RSqb: zwLjnRNHpA6a = zwLjnRNHpA6a.encode(m6PFtLblInpNZ8x)
				zwLjnRNHpA6a = str(int(TOjyaHnYozURG.md5(zwLjnRNHpA6a).hexdigest(),EX25Y0l8ILvz7QcRC(u"࠴࠸૿")))
				jdXreIGkU15F0t = [int(zwLjnRNHpA6a[emFMt467qWDgnG1jAYplva9HkboNB:emFMt467qWDgnG1jAYplva9HkboNB+f90fGrlSEObDsuiA3U(u"࠴࠹ଁ")]) for emFMt467qWDgnG1jAYplva9HkboNB in range(len(zwLjnRNHpA6a)) if emFMt467qWDgnG1jAYplva9HkboNB%f90fGrlSEObDsuiA3U(u"࠴࠹ଁ")==XugxFprC26zGM(u"࠲଀")]
				S5FVtOsQWPo6vbkYG0[rBw5YZ31M7HOv-NSudqlOzja] = str(sum(jdXreIGkU15F0t))
	BAhwu5Uvt7,MQKvnWe3par0UsHwcuz = [],rDceXBpHkfVUYRJ3tIx95Z
	for zniOJl91VRKt23CkoT8I0ZvQ4UAD7 in range(len(S5FVtOsQWPo6vbkYG0)):
		jdXreIGkU15F0t = S5FVtOsQWPo6vbkYG0[zniOJl91VRKt23CkoT8I0ZvQ4UAD7]
		if not jdXreIGkU15F0t: continue
		if MQKvnWe3par0UsHwcuz and jdXreIGkU15F0t==S5FVtOsQWPo6vbkYG0[-NSudqlOzja]: continue
		MQKvnWe3par0UsHwcuz = YchIv6N09BaWPEj4tieAnluKZrRXT
		jdXreIGkU15F0t = HkiMU0QrdzW3l6gwnT(u"ࠩ࠳ࠫ৶")*ZwQ23eJ6vt+jdXreIGkU15F0t
		jdXreIGkU15F0t = jdXreIGkU15F0t[-ZwQ23eJ6vt:]
		hzw9GUY7KFi4ZkdHLWOgfnbvjE38,YADJ4Ro7suKP = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
		eOGrlsRKAn4 = str(int(NxXMrsTC5FniYuRBOK8(u"ࠪ࠽ࠬ৷")*(ZwQ23eJ6vt+NSudqlOzja))-int(jdXreIGkU15F0t))[-ZwQ23eJ6vt:]
		for HIlROZrLU1bpzD0KPGqja7BVc in list(range(x1Oa8bBf36EwsLMirtFc,ZwQ23eJ6vt,BSw5mizCOsKxWrRDvtJuFajY)):
			hzw9GUY7KFi4ZkdHLWOgfnbvjE38 += eOGrlsRKAn4[HIlROZrLU1bpzD0KPGqja7BVc:HIlROZrLU1bpzD0KPGqja7BVc+BSw5mizCOsKxWrRDvtJuFajY]+jUcmHhgVvW0EdYOIfXeaDF(u"ࠫ࠲࠭৸")
			YADJ4Ro7suKP += str(sum(map(int,jdXreIGkU15F0t[HIlROZrLU1bpzD0KPGqja7BVc:HIlROZrLU1bpzD0KPGqja7BVc+BSw5mizCOsKxWrRDvtJuFajY]))%XugxFprC26zGM(u"࠵࠵ଂ"))
		ACJ5vmV1LDT = str(zniOJl91VRKt23CkoT8I0ZvQ4UAD7)+hzw9GUY7KFi4ZkdHLWOgfnbvjE38+YADJ4Ro7suKP
		BAhwu5Uvt7.append(ACJ5vmV1LDT)
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ৹"),HkiMU0QrdzW3l6gwnT(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ৺"),[oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N],bbfreYhcgwZlKEGVx7zRU)
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,I5bUBGpPXn0W6(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ৻"),KQ3sCe9Pzh(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ৼ"),[BAhwu5Uvt7,oTmxd82hDvO0Pyf,XPTkNeH9SqJbCc0h7BAuLiWy,HHcmRzwY7N],c4cPSX2jOIm8KCQlfW5wM)
	return kDUv7ouWrcgMe6OipQJm.join(BAhwu5Uvt7)
def NEI8AGXDS73KmBvT54o6L(fW4iNwld6COELJ10,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Oyg3pZGAHdws7RWm4e6S,tWILFaVZ5E6rdoRXNGApOiJ3Ss0):
	W9PzsMeLJTc83mS45G17n = str(kkMFwqXnC9v0y)[x1Oa8bBf36EwsLMirtFc:w2vjZmdJuY7c(u"࠷࠻࠰ଃ")].replace(kDUv7ouWrcgMe6OipQJm,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩ࡟ࡠࡳ࠭৽")).replace(y1fVB2E63aLnJgkWeCZHujY,I5bUBGpPXn0W6(u"ࠪࡠࡡࡸࠧ৾")).replace(h597x8jYiAIBDzcedPslw6pQy,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j)
	if len(str(kkMFwqXnC9v0y))>ehfEsaiJBSvbcULtNPVgykA2(u"࠸࠵࠱଄"): W9PzsMeLJTc83mS45G17n = W9PzsMeLJTc83mS45G17n+KQ3sCe9Pzh(u"ࠫࠥ࠴࠮࠯ࠩ৿")
	LbAmEhrdt7eRV2Y = str(KhGpZcMqsnrbv)[x1Oa8bBf36EwsLMirtFc:J7divaGOCgq2SLfXpDzZYN58wc(u"࠲࠶࠲ଅ")].replace(kDUv7ouWrcgMe6OipQJm,EX25Y0l8ILvz7QcRC(u"ࠬࡢ࡜࡯ࠩ਀")).replace(y1fVB2E63aLnJgkWeCZHujY,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࡜࡝ࡴࠪਁ")).replace(h597x8jYiAIBDzcedPslw6pQy,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(D8OnEGLjecaXw,avcfIls8w7gk69hYUErHxzQTXtm24j)
	if len(str(KhGpZcMqsnrbv))>KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠳࠷࠳ଆ"): LbAmEhrdt7eRV2Y = LbAmEhrdt7eRV2Y+t3coAp06zvHrTl49bUVgx(u"ࠧࠡ࠰࠱࠲ࠬਂ")
	vR9cOpMtk51j(iwIlVQsgYezu,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࠪਃ")+fW4iNwld6COELJ10+t3coAp06zvHrTl49bUVgx(u"ࠩࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ਄")+FeTJrG4SkMf09iVys8A+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬਅ")+Oyg3pZGAHdws7RWm4e6S+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࠥࡣࠠࠡࠢࡐࡩࡹ࡮࡯ࡥ࠼ࠣ࡟ࠥ࠭ਆ")+tWILFaVZ5E6rdoRXNGApOiJ3Ss0+jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࠦ࡝ࠡࠢࠣࡌࡪࡧࡤࡦࡴࡶ࠾ࠥࡡࠠࠨਇ")+str(W9PzsMeLJTc83mS45G17n)+ietolwsjpIPK7Fr(u"࠭ࠠ࡞ࠢࠣࠤࡉࡧࡴࡢ࠼ࠣ࡟ࠥ࠭ਈ")+LbAmEhrdt7eRV2Y+KW5bYS20wTF1LyCs9(u"ࠧࠡ࡟ࠪਉ"))
	return
def K9Z6hot728Ywyl1Jrd():
	global v45cYAFrZBTil0kdwx3S8UNt1ga
	import getmac82 as Y5N30LaoW9JwRfiM
	try:
		UwkqIKFQfH8e02Z9W1X6zmc = Y5N30LaoW9JwRfiM.get_mac_address()
		if UwkqIKFQfH8e02Z9W1X6zmc.count(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨ࠼ࠪਊ"))==w2vjZmdJuY7c(u"࠸ଈ") and UwkqIKFQfH8e02Z9W1X6zmc.count(eNEhtuoi9gK8JaTpIXj(u"ࠩ࠳ࠫ਋"))<ietolwsjpIPK7Fr(u"࠻ଇ"):
			UwkqIKFQfH8e02Z9W1X6zmc = UwkqIKFQfH8e02Z9W1X6zmc.lower().replace(jUcmHhgVvW0EdYOIfXeaDF(u"ࠪ࠾ࠬ਌"),eHdDoxhJCEPMZFVa2fg)
			v45cYAFrZBTil0kdwx3S8UNt1ga = str(int(UwkqIKFQfH8e02Z9W1X6zmc,LTN6DPEmrwehtZMy(u"࠵࠻ଉ")))
	except: pass
	return
def KIG3NuOXkVUboTJxM():
	global nPmbxIfDzKF3AE
	import getmac94 as RzxoKpLnuGhiT1
	try:
		hide3Cca1wrfT = RzxoKpLnuGhiT1.get_mac_address()
		if hide3Cca1wrfT.count(f90fGrlSEObDsuiA3U(u"ࠫ࠿࠭਍"))==J7divaGOCgq2SLfXpDzZYN58wc(u"࠻ଋ") and hide3Cca1wrfT.count(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࠶ࠧ਎"))<Cp6c5tZe8I0PxnAW(u"࠾ଊ"):
			hide3Cca1wrfT = hide3Cca1wrfT.lower().replace(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࠺ࠨਏ"),eHdDoxhJCEPMZFVa2fg)
			nPmbxIfDzKF3AE = str(int(hide3Cca1wrfT,NxXMrsTC5FniYuRBOK8(u"࠱࠷ଌ")))
	except: pass
	return
def JPm1l6479KjXST0(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv=eHdDoxhJCEPMZFVa2fg,kkMFwqXnC9v0y=eHdDoxhJCEPMZFVa2fg,Oyg3pZGAHdws7RWm4e6S=eHdDoxhJCEPMZFVa2fg):
	NEI8AGXDS73KmBvT54o6L(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡖࡔࡏࡐࡎࡈ࡜ࡵ࡞ࡷࡓࡕࡋࡎࡠࡗࡕࡐࠬਐ"),FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Oyg3pZGAHdws7RWm4e6S,tWILFaVZ5E6rdoRXNGApOiJ3Ss0)
	if WHjh1POtMKlmgiy68RSqb: import urllib.request as Fw0hjrg9u3AsK
	else: import urllib2 as Fw0hjrg9u3AsK
	if not kkMFwqXnC9v0y: kkMFwqXnC9v0y = {ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ਑"):eHdDoxhJCEPMZFVa2fg}
	if not KhGpZcMqsnrbv: KhGpZcMqsnrbv = {}
	if tWILFaVZ5E6rdoRXNGApOiJ3Ss0==ietolwsjpIPK7Fr(u"ࠩࡊࡉ࡙࠭਒"):
		FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A+XugxFprC26zGM(u"ࠪࡃࠬਓ")+GHIgY9AomX(KhGpZcMqsnrbv)
		KhGpZcMqsnrbv = None
	elif tWILFaVZ5E6rdoRXNGApOiJ3Ss0==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡕࡕࡓࡕࠩਔ") and ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡰࡳࡰࡰࠪਕ") in str(kkMFwqXnC9v0y):
		from json import dumps as H8R1hcBI3zjJdlMiESVvTtaZb
		KhGpZcMqsnrbv = H8R1hcBI3zjJdlMiESVvTtaZb(KhGpZcMqsnrbv)
		KhGpZcMqsnrbv = str(KhGpZcMqsnrbv).encode(m6PFtLblInpNZ8x)
	elif tWILFaVZ5E6rdoRXNGApOiJ3Ss0==CKUiyEe28zsZ(u"࠭ࡐࡐࡕࡗࠫਖ"):
		KhGpZcMqsnrbv = GHIgY9AomX(KhGpZcMqsnrbv)
		KhGpZcMqsnrbv = KhGpZcMqsnrbv.encode(m6PFtLblInpNZ8x)
	try:
		OjmrF6VRyY = Fw0hjrg9u3AsK.Request(FeTJrG4SkMf09iVys8A,headers=kkMFwqXnC9v0y,data=KhGpZcMqsnrbv)
		qldY3LPe0pDiuyoM8vIH = Fw0hjrg9u3AsK.urlopen(OjmrF6VRyY)
		a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.read()
		O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6 = ilBWK5nXxg1do4jENGC07Zq(u"࠳࠲࠳଍"),KQ3sCe9Pzh(u"ࠧࡐࡍࠪਗ")
	except:
		a3glxPAGFXm2kzq = eHdDoxhJCEPMZFVa2fg
		O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6 = -NSudqlOzja,eNEhtuoi9gK8JaTpIXj(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨਘ")
	vR9cOpMtk51j(iwIlVQsgYezu,EX25Y0l8ILvz7QcRC(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄ࡟ࡸࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫਙ")+str(O1WFus64LiEAmzpnPIT8jgZHN)+KQ3sCe9Pzh(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬਚ")+RCrFOws8DlH6+ilBWK5nXxg1do4jENGC07Zq(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ਛ")+Oyg3pZGAHdws7RWm4e6S+Cp6c5tZe8I0PxnAW(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫਜ")+FeTJrG4SkMf09iVys8A+XugxFprC26zGM(u"࠭ࠠ࡞ࠩਝ"))
	if a3glxPAGFXm2kzq and WHjh1POtMKlmgiy68RSqb: a3glxPAGFXm2kzq = a3glxPAGFXm2kzq.decode(m6PFtLblInpNZ8x)
	return a3glxPAGFXm2kzq
def uubfnFKgCq(SSQyO2tTfJhu):
	ypQiaCol2xEskGO4bdMqt79U = {
		ietolwsjpIPK7Fr(u"ࠢࡶࡵࡨࡶࡤ࡯ࡤࠣਞ"):RnrFhIUdq8Wmp7V5HLxZjvwye6YK,
		LTN6DPEmrwehtZMy(u"ࠣࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠧਟ"):str(YB5Segc7IQ),
		NxXMrsTC5FniYuRBOK8(u"ࠤࡤࡴࡵࡥࡶࡦࡴࡶ࡭ࡴࡴࠢਠ"):MCrWtwnF2TViZOD7z0pXgqI4,
		EX25Y0l8ILvz7QcRC(u"ࠥࡨࡪࡼࡩࡤࡧࡢࡪࡦࡳࡩ࡭ࡻࠥਡ"):MCrWtwnF2TViZOD7z0pXgqI4,
		eNEhtuoi9gK8JaTpIXj(u"ࠦࡵࡲࡡࡵࡨࡲࡶࡲࠨਢ"): MCrWtwnF2TViZOD7z0pXgqI4,
		LTN6DPEmrwehtZMy(u"ࠧࡩࡡࡳࡴ࡬ࡩࡷࠨਣ"):ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡁࡓࡃࡅࡍࡈࡥࡖࡊࡆࡈࡓࡘࠨਤ"),
		LyOR7f69iA(u"ࠢࡪࡲࠥਥ"): Cp6c5tZe8I0PxnAW(u"ࠣࠦࡵࡩࡲࡵࡴࡦࠤਦ"),
		TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠤࠧࡷࡰ࡯ࡰࡠࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࡢࡷࡾࡴࡣࠣਧ"):rDceXBpHkfVUYRJ3tIx95Z
	}
	bn56v3hGqkdt7x1iyNY = []
	for RLepADMmoBQqVnlT5t in SSQyO2tTfJhu:
		X9XxmHBLWPz = ypQiaCol2xEskGO4bdMqt79U.copy()
		X9XxmHBLWPz[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧਨ")] = RLepADMmoBQqVnlT5t
		X9XxmHBLWPz[dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡪࡼࡥ࡯ࡶࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧ਩")] = {KQ3sCe9Pzh(u"ࠧࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤਪ"):RLepADMmoBQqVnlT5t}
		X9XxmHBLWPz[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡵࡴࡧࡵࡣࡵࡸ࡯ࡱࡧࡵࡸ࡮࡫ࡳࠨਫ")] = {KW5bYS20wTF1LyCs9(u"ࠢࡖࡵࡨࡶࡤࡋࡶࡦࡰࡷࡣࡓࡧ࡭ࡦࠤਬ"):RLepADMmoBQqVnlT5t}
		bn56v3hGqkdt7x1iyNY.append(X9XxmHBLWPz)
	qKDTx8GhyBXpCH3vtbfZI2W5SNg4 = str(GljITSOwLKW36.randrange(t3coAp06zvHrTl49bUVgx(u"࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶࠷଎"),egY8Jti0smdLM3h1VQRSW(u"࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ଏ")))
	KhGpZcMqsnrbv = {
		EX25Y0l8ILvz7QcRC(u"ࠣࡣࡳ࡭ࡤࡱࡥࡺࠤਭ"):S8i3sBYoHWdTURpAgN(u"ࠩ࠵࠹࠹ࡪࡤ࠴ࡣ࠷࠴࠾ࡪ࠸ࡣ࠸࠻࠵ࡩ࠺ࡥ࠲࠳࠺ࡩࡪ࠽࠸ࡤࡧࡥࡪ࠷࠿ࠧਮ"),
		bP01xn84BiQN(u"ࠥ࡭ࡳࡹࡥࡳࡶࡢ࡭ࡩࠨਯ"):qKDTx8GhyBXpCH3vtbfZI2W5SNg4,
		GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠦࡪࡼࡥ࡯ࡶࡶࠦਰ"): bn56v3hGqkdt7x1iyNY
	}
	kkMFwqXnC9v0y = {ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ਱"):ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩਲ")}
	FeTJrG4SkMf09iVys8A = I5bUBGpPXn0W6(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠷࠴ࡡ࡮ࡲ࡯࡭ࡹࡻࡤࡦ࠰ࡦࡳࡲ࠵࠲࠰ࡪࡷࡸࡵࡧࡰࡪࠩਲ਼")
	a3glxPAGFXm2kzq = JPm1l6479KjXST0(jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡒࡒࡗ࡙࠭਴"),FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Cp6c5tZe8I0PxnAW(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨਵ"))
	return a3glxPAGFXm2kzq
def DIpuHqsKGS3ErJvk9taCRiX80(HtsU1JmF0cn3fgGraqwRYNIdlhESj,oh8Z06rUdqJ):
	oh8Z06rUdqJ = oh8Z06rUdqJ.replace(KQ3sCe9Pzh(u"ࠪࡲࡺࡲ࡬ࠨਸ਼"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡓࡵ࡮ࡦࠩ਷"))
	oh8Z06rUdqJ = oh8Z06rUdqJ.replace(jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡺࡲࡶࡧࠪਸ"),EX25Y0l8ILvz7QcRC(u"࠭ࡔࡳࡷࡨࠫਹ"))
	oh8Z06rUdqJ = oh8Z06rUdqJ.replace(wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡧࡣ࡯ࡷࡪ࠭਺"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡈࡤࡰࡸ࡫ࠧ਻"))
	oh8Z06rUdqJ = oh8Z06rUdqJ.replace(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩ࡟࠳਼ࠬ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪ࠳ࠬ਽"))
	try: krdDRZKFsomBxzPNvAOyXJu6 = eval(oh8Z06rUdqJ)
	except: krdDRZKFsomBxzPNvAOyXJu6 = dkBvNuEQn7zOSeCxJyY56i(HtsU1JmF0cn3fgGraqwRYNIdlhESj)
	return krdDRZKFsomBxzPNvAOyXJu6
def G0ejOgq24ovDFbNc():
	fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA = udpczrlynT3vQ98HhDYqgFw2SWo4MG(H4ys6we0jDn)
	hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡡࡪ࡜ࡥ࠼࡟ࡨࡡࡪࠠ࡝࡝࠲ࡇࡔࡒࡏࡓ࡞ࡠࠫਾ"),d8De716ZlA2,cBawilJXvK1m.DOTALL)
	if hPYnfjbqWDJNSAeyQaBrOZt68: d8De716ZlA2 = d8De716ZlA2.split(hPYnfjbqWDJNSAeyQaBrOZt68[x1Oa8bBf36EwsLMirtFc],EX25Y0l8ILvz7QcRC(u"࠵ଐ"))[NSudqlOzja]
	SNaoWCmLHFk = b8bLFaejUB.strftime(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡥࠥ࡮࠰ࠨࡨࡤࠫࡈ࠻ࠧࡐࡣࠬਿ"),b8bLFaejUB.localtime(a8HLTkO2ns49yGNgiroS))
	d8De716ZlA2 = d8De716ZlA2+SNaoWCmLHFk
	XGx97cJZhV5m6v = fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA
	if RRydns1CErYlIhwSx7.path.exists(s4FvMNOledIt):
		xV71kwLiJqS9UjdKEbun0OZG8TlA = open(s4FvMNOledIt,jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡲࡣࠩੀ")).read()
		if WHjh1POtMKlmgiy68RSqb: xV71kwLiJqS9UjdKEbun0OZG8TlA = xV71kwLiJqS9UjdKEbun0OZG8TlA.decode(m6PFtLblInpNZ8x)
		xV71kwLiJqS9UjdKEbun0OZG8TlA = DIpuHqsKGS3ErJvk9taCRiX80(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡥ࡫ࡦࡸࠬੁ"),xV71kwLiJqS9UjdKEbun0OZG8TlA)
	else: xV71kwLiJqS9UjdKEbun0OZG8TlA = {}
	tYuVyvxLPqAg1r = {}
	for pmwi4683sFflz in list(xV71kwLiJqS9UjdKEbun0OZG8TlA.keys()):
		if pmwi4683sFflz!=fW4iNwld6COELJ10: tYuVyvxLPqAg1r[pmwi4683sFflz] = xV71kwLiJqS9UjdKEbun0OZG8TlA[pmwi4683sFflz]
		else:
			if d8De716ZlA2 and d8De716ZlA2!=QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨ࠰࠱ࠫੂ"):
				UDZg6pxA9M8iN0yFO1 = xV71kwLiJqS9UjdKEbun0OZG8TlA[pmwi4683sFflz]
				if XGx97cJZhV5m6v in UDZg6pxA9M8iN0yFO1:
					WmUKzewgdt7nOa3VlBC19 = UDZg6pxA9M8iN0yFO1.index(XGx97cJZhV5m6v)
					del UDZg6pxA9M8iN0yFO1[WmUKzewgdt7nOa3VlBC19]
				W1vLcHR5lO = [XGx97cJZhV5m6v]+UDZg6pxA9M8iN0yFO1
				W1vLcHR5lO = W1vLcHR5lO[:dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠺࠶଑")]
				tYuVyvxLPqAg1r[pmwi4683sFflz] = W1vLcHR5lO
			else: tYuVyvxLPqAg1r[pmwi4683sFflz] = xV71kwLiJqS9UjdKEbun0OZG8TlA[pmwi4683sFflz]
	if fW4iNwld6COELJ10 not in list(tYuVyvxLPqAg1r.keys()): tYuVyvxLPqAg1r[fW4iNwld6COELJ10] = [XGx97cJZhV5m6v]
	tYuVyvxLPqAg1r = str(tYuVyvxLPqAg1r)
	if WHjh1POtMKlmgiy68RSqb: tYuVyvxLPqAg1r = tYuVyvxLPqAg1r.encode(m6PFtLblInpNZ8x)
	open(s4FvMNOledIt,ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡺࡦࠬ੃")).write(tYuVyvxLPqAg1r)
	return
def CbR3IdmoLYPcOqfuGNyWit6Xg(zHOEFk27fChwMr0GKXWSy19URm4,ea5ZizEDufroHsSybP1,uun0dP1mChlsjbX2HW59oI,KhGpZcMqsnrbv,gXU5SKA1bjDEPi7JoWt89NhVry0,EHUFqMPD0hdv=rDceXBpHkfVUYRJ3tIx95Z):
	JEvXRNInqCF = MoO74hKeqm8fFka.getSetting(w2vjZmdJuY7c(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ੄"))
	if JEvXRNInqCF==egY8Jti0smdLM3h1VQRSW(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ੅") and gXU5SKA1bjDEPi7JoWt89NhVry0>xHs1lKmBbG5PT9LwN: gXU5SKA1bjDEPi7JoWt89NhVry0 = xHs1lKmBbG5PT9LwN
	if EHUFqMPD0hdv:
		B0ZiepTkgjAq8lWxCKyX1,CCbge5YqUNRrZXMz1K7u0h6mId = [],[]
		for gMmB3iopS0ZXrOFewhcxt in range(len(uun0dP1mChlsjbX2HW59oI)):
			oh8Z06rUdqJ = F7pgAanycjuNEB6GVXR.dumps(KhGpZcMqsnrbv[gMmB3iopS0ZXrOFewhcxt])
			jEzOxRWdqKF0y7v = vGPgxMCUnVTb6fDsXkRS.compress(oh8Z06rUdqJ)
			B0ZiepTkgjAq8lWxCKyX1.append((uun0dP1mChlsjbX2HW59oI[gMmB3iopS0ZXrOFewhcxt],))
			CCbge5YqUNRrZXMz1K7u0h6mId.append((gXU5SKA1bjDEPi7JoWt89NhVry0+a8HLTkO2ns49yGNgiroS,str(uun0dP1mChlsjbX2HW59oI[gMmB3iopS0ZXrOFewhcxt]),jEzOxRWdqKF0y7v))
	else:
		oh8Z06rUdqJ = F7pgAanycjuNEB6GVXR.dumps(KhGpZcMqsnrbv)
		kkxCyVKfNPR1W0JBOHjLnMmE = vGPgxMCUnVTb6fDsXkRS.compress(oh8Z06rUdqJ)
	try: Mh2SmYKyRLsevXCJpTajHZbi0Gf,O4OfQzkx1KmeIHrjT97E0byA = EnU1P9x4k7DF6ie5TWAKChB0mSzrN(zHOEFk27fChwMr0GKXWSy19URm4)
	except: return
	while YchIv6N09BaWPEj4tieAnluKZrRXT:
		try:
			O4OfQzkx1KmeIHrjT97E0byA.execute(w2vjZmdJuY7c(u"ࠬࡈࡅࡈࡋࡑࠤࡎࡓࡍࡆࡆࡌࡅ࡙ࡋࠠࡕࡔࡄࡒࡘࡇࡃࡕࡋࡒࡒࠥࡁࠧ੆"))
			break
		except: b8bLFaejUB.sleep(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠶࠮࠶଒"))
	O4OfQzkx1KmeIHrjT97E0byA.execute(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡃࡓࡇࡄࡘࡊࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡐࡒࡘࠥࡋࡘࡊࡕࡗࡗࠥࠨࠧੇ")+ea5ZizEDufroHsSybP1+ilBWK5nXxg1do4jENGC07Zq(u"ࠧࠣࠢࠫࡩࡽࡶࡩࡳࡻ࠯ࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠪࠢ࠾ࠫੈ"))
	if EHUFqMPD0hdv:
		O4OfQzkx1KmeIHrjT97E0byA.executemany(jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ੉")+ea5ZizEDufroHsSybP1+NxXMrsTC5FniYuRBOK8(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ੊"),B0ZiepTkgjAq8lWxCKyX1)
		O4OfQzkx1KmeIHrjT97E0byA.executemany(KW5bYS20wTF1LyCs9(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠤࠪੋ")+ea5ZizEDufroHsSybP1+EX25Y0l8ILvz7QcRC(u"ࠫࠧࠦࡖࡂࡎࡘࡉࡘࠦࠨࡀ࠮ࡂ࠰ࡄ࠯ࠠ࠼ࠩੌ"),CCbge5YqUNRrZXMz1K7u0h6mId)
	else:
		if gXU5SKA1bjDEPi7JoWt89NhVry0:
			Tp4umHFyBg1avosQZnGClRxPVf = (str(uun0dP1mChlsjbX2HW59oI),)
			O4OfQzkx1KmeIHrjT97E0byA.execute(t3coAp06zvHrTl49bUVgx(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏ੍ࠣࠦࠬ")+ea5ZizEDufroHsSybP1+CKUiyEe28zsZ(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭੎"),Tp4umHFyBg1avosQZnGClRxPVf)
			Tp4umHFyBg1avosQZnGClRxPVf = (gXU5SKA1bjDEPi7JoWt89NhVry0+a8HLTkO2ns49yGNgiroS,str(uun0dP1mChlsjbX2HW59oI),kkxCyVKfNPR1W0JBOHjLnMmE)
			O4OfQzkx1KmeIHrjT97E0byA.execute(eNEhtuoi9gK8JaTpIXj(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ੏")+ea5ZizEDufroHsSybP1+ietolwsjpIPK7Fr(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭੐"),Tp4umHFyBg1avosQZnGClRxPVf)
		else:
			Tp4umHFyBg1avosQZnGClRxPVf = (kkxCyVKfNPR1W0JBOHjLnMmE,str(uun0dP1mChlsjbX2HW59oI))
			O4OfQzkx1KmeIHrjT97E0byA.execute(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡘࡔࡉࡇࡔࡆࠢࠥࠫੑ")+ea5ZizEDufroHsSybP1+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࡙ࠪࠦࠥࡅࡕࠢࡧࡥࡹࡧࠠ࠾ࠢࡂࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ੒"),Tp4umHFyBg1avosQZnGClRxPVf)
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.commit()
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.close()
	return
def GHIgY9AomX(KhGpZcMqsnrbv):
	if WHjh1POtMKlmgiy68RSqb: import urllib.parse as nPqGoV71bOIU8fXRz
	else: import urllib as nPqGoV71bOIU8fXRz
	CSVngtR0AGk56KIqZBTUN3PO = nPqGoV71bOIU8fXRz.urlencode(KhGpZcMqsnrbv)
	return CSVngtR0AGk56KIqZBTUN3PO
def IZkpyKSFVarcHwG1g6emqQv70h(ajHR9ABQl2buvm,Ph6lazTI975srx=eHdDoxhJCEPMZFVa2fg,kPsKXxVnAmE7YDH=eHdDoxhJCEPMZFVa2fg):
	F23RLB1XhMiY0 = Ph6lazTI975srx not in [t3coAp06zvHrTl49bUVgx(u"ࠫࡒ࠹ࡕࠨ੓"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡏࡐࡕࡘࠪ੔")]
	global hmBXOtAQZFebaWy8l92sjDCK
	if not kPsKXxVnAmE7YDH: kPsKXxVnAmE7YDH = eNEhtuoi9gK8JaTpIXj(u"࠭ࡶࡪࡦࡨࡳࠬ੕")
	hmBXOtAQZFebaWy8l92sjDCK,L7LuDp2N4SKFOArfsqnxCPcRQ,mULbdy5G0DZOTpaMvRrwWEAN2 = w2vjZmdJuY7c(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥ࠲ࠪ੖"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if len(ajHR9ABQl2buvm)==bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1:
		FeTJrG4SkMf09iVys8A,DZPSUqijpK9s16wQ38zyol,mULbdy5G0DZOTpaMvRrwWEAN2 = ajHR9ABQl2buvm
		if DZPSUqijpK9s16wQ38zyol: L7LuDp2N4SKFOArfsqnxCPcRQ = Cp6c5tZe8I0PxnAW(u"ࠨࠢࠣࠤࡘࡻࡢࡵ࡫ࡷࡰࡪࡀࠠ࡜ࠢࠪ੗")+DZPSUqijpK9s16wQ38zyol+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࠣࡡࠬ੘")
	else: FeTJrG4SkMf09iVys8A,DZPSUqijpK9s16wQ38zyol,mULbdy5G0DZOTpaMvRrwWEAN2 = ajHR9ABQl2buvm,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A.replace(jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࠩ࠷࠶ࠧਖ਼"),avcfIls8w7gk69hYUErHxzQTXtm24j)
	JGtX1fiayl9R = llr1C3SIFjViqLDtZP(FeTJrG4SkMf09iVys8A)
	if Ph6lazTI975srx not in [GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ਗ਼"),eNEhtuoi9gK8JaTpIXj(u"ࠬࡏࡐࡕࡘࠪਜ਼")]:
		if Ph6lazTI975srx!=eNEhtuoi9gK8JaTpIXj(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨੜ"): FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,I5bUBGpPXn0W6(u"ࠧࠦ࠴࠳ࠫ੝"))
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+KW5bYS20wTF1LyCs9(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡴࡱࡧࡹ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧਫ਼")+FeTJrG4SkMf09iVys8A+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࠣࡡࠬ੟")+L7LuDp2N4SKFOArfsqnxCPcRQ)
		if JGtX1fiayl9R==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ੠") and Ph6lazTI975srx not in [KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡎࡖࡔࡗࠩ੡"),NxXMrsTC5FniYuRBOK8(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭੢")]:
			from dIxmaLQn3F import YY02fhEdJNI5cCpw1nUMj,ZZhzstQTSCXRg,dqKGMYgJxSF8Ub1kotlsP936Ww7B
			FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = YY02fhEdJNI5cCpw1nUMj(FeTJrG4SkMf09iVys8A)
			ZlJIRM4voWapmOU8ykibgT5D1cd = len(ppQOjlq2gaPkW)
			if ZlJIRM4voWapmOU8ykibgT5D1cd>NSudqlOzja:
				iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠥ࠮ࠧ੣")+str(ZlJIRM4voWapmOU8ykibgT5D1cd)+w2vjZmdJuY7c(u"ࠧࠡ็็ๅ࠮࠭੤"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
				if iLcCSnPyKYWs3xkQ0p14==-NSudqlOzja:
					dqKGMYgJxSF8Ub1kotlsP936Ww7B(bP01xn84BiQN(u"ࠨว็฾ฬวฺࠠ็็๎ฮࠦสี฼ํ่ࠥอไโ์า๎ํ࠭੥"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡆࡥࡳࡩࡥ࡭ࠩ੦"))
					return hmBXOtAQZFebaWy8l92sjDCK
			else: iLcCSnPyKYWs3xkQ0p14 = x1Oa8bBf36EwsLMirtFc
			FeTJrG4SkMf09iVys8A = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
			if FBITEXGDfe2mcCxnQs6ktMdy9HJh[x1Oa8bBf36EwsLMirtFc]!=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪ࠱࠶࠭੧"):
				vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶ࡬ࡳࡳࡀࠠ࡜ࠢࠪ੨")+FBITEXGDfe2mcCxnQs6ktMdy9HJh[iLcCSnPyKYWs3xkQ0p14]+eNEhtuoi9gK8JaTpIXj(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭੩")+FeTJrG4SkMf09iVys8A+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࠠ࡞ࠩ੪"))
		if t3coAp06zvHrTl49bUVgx(u"ࠧ࠰࡫ࡩ࡭ࡱࡳ࠯ࠨ੫") in FeTJrG4SkMf09iVys8A: FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A+eNEhtuoi9gK8JaTpIXj(u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠦࠨ੬")
		elif S8i3sBYoHWdTURpAgN(u"ࠩ࡫ࡸࡹࡶࠧ੭") in FeTJrG4SkMf09iVys8A.lower() and RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪ࠳ࡩࡧࡳࡩ࠱ࠪ੮") not in FeTJrG4SkMf09iVys8A and I5bUBGpPXn0W6(u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ੯") not in FeTJrG4SkMf09iVys8A:
			FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࢂࠧੰ") if S8i3sBYoHWdTURpAgN(u"࠭ࡼࠨੱ") not in FeTJrG4SkMf09iVys8A else FeTJrG4SkMf09iVys8A+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࠧࠩੲ")
			if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࠭ੳ") not in FeTJrG4SkMf09iVys8A and f90fGrlSEObDsuiA3U(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫੴ") in FeTJrG4SkMf09iVys8A.lower(): FeTJrG4SkMf09iVys8A += 'verifypeer=false&'
			if egY8Jti0smdLM3h1VQRSW(u"ࠫࡺࡹࡥࡳ࠯ࡤ࡫ࡪࡴࡴ࠾ࠩ੶") not in FeTJrG4SkMf09iVys8A.lower() and Ph6lazTI975srx not in [ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡏࡐࡕࡘࠪ੷"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡍ࠴ࡗࠪ੸")]: FeTJrG4SkMf09iVys8A += EX25Y0l8ILvz7QcRC(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭੹")
			if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡴࡨࡪࡪࡸࡥࡳ࠿ࠪ੺") not in FeTJrG4SkMf09iVys8A.lower(): FeTJrG4SkMf09iVys8A += S8i3sBYoHWdTURpAgN(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀ࡬ࡹࡺࡰࠧࠩ੻")
	vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+XugxFprC26zGM(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡪ࡮ࡴࡡ࡭ࠢࡸࡶࡱࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ੼")+FeTJrG4SkMf09iVys8A+ietolwsjpIPK7Fr(u"ࠫࠥࡣࠧ੽"))
	FdHDcKChfua5Ryi6lj = VVZgPQ2kYLoKe6jic5AEzqupG.ListItem()
	kPsKXxVnAmE7YDH,JqZhbG9Le2NQvziaPCx8wI,Tv4kxUQzM86cK1nCmP,RoSzmHKdiUqnsx,u1INEBX5oqPx,zz3BeUfyNow7kZ0nvtxhKqWr4P,rHM3ovhRVt8Qp4W0xIigdN,OyUZmAVsn1NWrBwbD,kUCr63DJOKy71AqLI2w5v8tb = udpczrlynT3vQ98HhDYqgFw2SWo4MG(H4ys6we0jDn)
	if Ph6lazTI975srx not in [GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੾"),t3coAp06zvHrTl49bUVgx(u"࠭ࡉࡑࡖ࡙ࠫ੿")]:
		if lHfbysRrUV7m4CLSdkxc382n: s5O4L68DqcR9vXhYJiMCN0reI3gS = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱࡦࡪࡤࡰࡰࠪ઀")
		else: s5O4L68DqcR9vXhYJiMCN0reI3gS = HkiMU0QrdzW3l6gwnT(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠭ઁ")
		FdHDcKChfua5Ryi6lj.setProperty(s5O4L68DqcR9vXhYJiMCN0reI3gS, eHdDoxhJCEPMZFVa2fg)
		FdHDcKChfua5Ryi6lj.setMimeType(egY8Jti0smdLM3h1VQRSW(u"ࠩࡰ࡭ࡲ࡫࠯ࡹ࠯ࡷࡽࡵ࡫ࠧં"))
		if YB5Segc7IQ<t3coAp06zvHrTl49bUVgx(u"࠲࠱ଓ"): FdHDcKChfua5Ryi6lj.setInfo(t3coAp06zvHrTl49bUVgx(u"ࠪࡺ࡮ࡪࡥࡰࠩઃ"),{XugxFprC26zGM(u"ࠫࡲ࡫ࡤࡪࡣࡷࡽࡵ࡫ࠧ઄"):CKUiyEe28zsZ(u"ࠬࡳ࡯ࡷ࡫ࡨࠫઅ")})
		else:
			jkalmzTfeKo = FdHDcKChfua5Ryi6lj.getVideoInfoTag()
			jkalmzTfeKo.setMediaType(ilBWK5nXxg1do4jENGC07Zq(u"࠭࡭ࡰࡸ࡬ࡩࠬઆ"))
		FdHDcKChfua5Ryi6lj.setArt({HkiMU0QrdzW3l6gwnT(u"ࠧࡵࡪࡸࡱࡧ࠭ઇ"):u1INEBX5oqPx,ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡲࡲࡷࡹ࡫ࡲࠨઈ"):u1INEBX5oqPx,HkiMU0QrdzW3l6gwnT(u"ࠩࡥࡥࡳࡴࡥࡳࠩઉ"):u1INEBX5oqPx,ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡪࡦࡴࡡࡳࡶࠪઊ"):u1INEBX5oqPx,I5bUBGpPXn0W6(u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ઋ"):u1INEBX5oqPx,EX25Y0l8ILvz7QcRC(u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨઌ"):u1INEBX5oqPx,HkiMU0QrdzW3l6gwnT(u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩઍ"):u1INEBX5oqPx,HkiMU0QrdzW3l6gwnT(u"ࠧࡪࡥࡲࡲࠬ઎"):u1INEBX5oqPx})
		if JGtX1fiayl9R in [I5bUBGpPXn0W6(u"ࠨ࠰ࡰࡴࡩ࠭એ"),KQ3sCe9Pzh(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨઐ")]: FdHDcKChfua5Ryi6lj.setContentLookup(YchIv6N09BaWPEj4tieAnluKZrRXT)
		else: FdHDcKChfua5Ryi6lj.setContentLookup(rDceXBpHkfVUYRJ3tIx95Z)
		from YmtfK6LolI import oIUetMrjGswW21QNiHSJgK3mnCd0D
		if I5bUBGpPXn0W6(u"ࠪࡶࡹࡳࡰࠨઑ") in FeTJrG4SkMf09iVys8A:
			oIUetMrjGswW21QNiHSJgK3mnCd0D(LTN6DPEmrwehtZMy(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡵࡸࡲࡶࠧ઒"),rDceXBpHkfVUYRJ3tIx95Z)
		elif JGtX1fiayl9R==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬ࠴࡭ࡱࡦࠪઓ") or KW5bYS20wTF1LyCs9(u"࠭࠯ࡥࡣࡶ࡬࠴࠭ઔ") in FeTJrG4SkMf09iVys8A:
			oIUetMrjGswW21QNiHSJgK3mnCd0D(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧક"),rDceXBpHkfVUYRJ3tIx95Z)
			FdHDcKChfua5Ryi6lj.setProperty(s5O4L68DqcR9vXhYJiMCN0reI3gS,XugxFprC26zGM(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨખ"))
			FdHDcKChfua5Ryi6lj.setProperty(EX25Y0l8ILvz7QcRC(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦ࠰ࡰࡥࡳ࡯ࡦࡦࡵࡷࡣࡹࡿࡰࡦࠩગ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡱࡵࡪࠧઘ"))
		if DZPSUqijpK9s16wQ38zyol:
			FdHDcKChfua5Ryi6lj.setSubtitles([DZPSUqijpK9s16wQ38zyol])
	if kPsKXxVnAmE7YDH==bP01xn84BiQN(u"ࠫࡻ࡯ࡤࡦࡱࠪઙ") and Ph6lazTI975srx==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧચ"):
		hmBXOtAQZFebaWy8l92sjDCK = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡰ࡭ࡣࡼࡣࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭છ")
		Ph6lazTI975srx = wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡑࡎࡄ࡝ࡤࡊࡌࡠࡈࡌࡐࡊ࡙ࠧજ")
	elif kPsKXxVnAmE7YDH==EX25Y0l8ILvz7QcRC(u"ࠨࡸ࡬ࡨࡪࡵࠧઝ") and OyUZmAVsn1NWrBwbD.startswith(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩ࠹ࠫઞ")):
		hmBXOtAQZFebaWy8l92sjDCK = S8i3sBYoHWdTURpAgN(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬટ")
		Ph6lazTI975srx = Ph6lazTI975srx+CKUiyEe28zsZ(u"ࠫࡤࡊࡌࠨઠ")
	if hmBXOtAQZFebaWy8l92sjDCK!=S8i3sBYoHWdTURpAgN(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧડ"): G0ejOgq24ovDFbNc()
	PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt = s1Yw7hoqdZBap20gW8zi()
	PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.qvsFoP7fcrGbe2Nd3j9W(Ph6lazTI975srx)
	if PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK: return NxXMrsTC5FniYuRBOK8(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠧઢ")
	if kPsKXxVnAmE7YDH==CKUiyEe28zsZ(u"ࠧࡷ࡫ࡧࡩࡴ࠭ણ") and not OyUZmAVsn1NWrBwbD.startswith(egY8Jti0smdLM3h1VQRSW(u"ࠨ࠸ࠪત")):
		FdHDcKChfua5Ryi6lj.setPath(FeTJrG4SkMf09iVys8A)
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+Cp6c5tZe8I0PxnAW(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡵࡨࡸࡗ࡫ࡳࡰ࡮ࡹࡩࡩ࡛ࡲ࡭ࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩથ")+FeTJrG4SkMf09iVys8A+w2vjZmdJuY7c(u"ࠪࠤࡢ࠭દ"))
		bCfjxP8yo4Qn3trXKNgW1AUl.setResolvedUrl(ZFsK7DtIkrHGnWQYhUM8P,YchIv6N09BaWPEj4tieAnluKZrRXT,FdHDcKChfua5Ryi6lj)
	elif kPsKXxVnAmE7YDH==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡱ࡯ࡶࡦࠩધ"):
		vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࠦࠠࠡࡎ࡬ࡺࡪࠦࡰ࡭ࡣࡼࠤࡺࡹࡩ࡯ࡩࠣࡴࡱࡧࡹࠩࠫࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨન")+FeTJrG4SkMf09iVys8A+LTN6DPEmrwehtZMy(u"࠭ࠠ࡞ࠩ઩"))
		PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.play(FeTJrG4SkMf09iVys8A,FdHDcKChfua5Ryi6lj)
	gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
	if hmBXOtAQZFebaWy8l92sjDCK==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩપ"):
		from dmXYZhFJCL import u2VEfGDOpbW0rCJ6
		gZdOM2jYEfV = u2VEfGDOpbW0rCJ6(FeTJrG4SkMf09iVys8A,JGtX1fiayl9R,Ph6lazTI975srx)
		if gZdOM2jYEfV: G0ejOgq24ovDFbNc()
	else:
		MbacDJogKp5ElfIi,hmBXOtAQZFebaWy8l92sjDCK,nPBIxOkFqQNrGuMs,hWMvLgTQYXrF7Z2oD8P,aaAFPUcb6WNO = x1Oa8bBf36EwsLMirtFc,ietolwsjpIPK7Fr(u"ࠨࡶࡵ࡭ࡪࡪࠧફ"),rDceXBpHkfVUYRJ3tIx95Z,KW5bYS20wTF1LyCs9(u"࠳࠳࠴࠵କ"),egY8Jti0smdLM3h1VQRSW(u"࠵࠷࠳࠴࠵ଔ")
		if F23RLB1XhMiY0: from dIxmaLQn3F import dqKGMYgJxSF8Ub1kotlsP936Ww7B
		while MbacDJogKp5ElfIi<aaAFPUcb6WNO:
			ccwRLKk3hs0E.sleep(hWMvLgTQYXrF7Z2oD8P)
			MbacDJogKp5ElfIi += hWMvLgTQYXrF7Z2oD8P
			if PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK==eNEhtuoi9gK8JaTpIXj(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪબ") and not nPBIxOkFqQNrGuMs:
				if F23RLB1XhMiY0: dqKGMYgJxSF8Ub1kotlsP936Ww7B(CKUiyEe28zsZ(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦ์ฯหิࠦวๅใํำ๏๎ࠧભ"),bP01xn84BiQN(u"ࠫࡘࡻࡣࡤࡧࡶࡷࠬમ"),b8bLFaejUB=GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠺࠹࠵ଖ"))
				vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤ࡛࡯ࡤࡦࡱࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩય")+FeTJrG4SkMf09iVys8A+KQ3sCe9Pzh(u"࠭ࠠ࡞ࠩર")+L7LuDp2N4SKFOArfsqnxCPcRQ)
				nPBIxOkFqQNrGuMs = YchIv6N09BaWPEj4tieAnluKZrRXT
			elif PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK in [J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ઱"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩલ")]:
				vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࡘ࡬ࡨࡪࡵࠠࡱ࡮ࡤࡽ࡮ࡴࡧ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ળ")+FeTJrG4SkMf09iVys8A+jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࠤࡢ࠭઴")+L7LuDp2N4SKFOArfsqnxCPcRQ)
				break
			elif PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK==t3coAp06zvHrTl49bUVgx(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫવ"):
				vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+f90fGrlSEObDsuiA3U(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࡹ࡭ࡩ࡫࡯࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭શ")+FeTJrG4SkMf09iVys8A+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࠠ࡞ࠩષ")+L7LuDp2N4SKFOArfsqnxCPcRQ)
				if F23RLB1XhMiY0: dqKGMYgJxSF8Ub1kotlsP936Ww7B(eNEhtuoi9gK8JaTpIXj(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫસ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡈࡤ࡭ࡱࡻࡲࡦࠩહ"),b8bLFaejUB=ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠻࠺࠶ଗ"))
				break
			elif PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK==CKUiyEe28zsZ(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ઺"):
				vR9cOpMtk51j(yqSNdm93iAa5CfwE1sL,WMyqfm31ka2jICwiE(EERWJf1adv67)+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࠤࠥࠦࡄࡦࡸ࡬ࡧࡪࠦࡩࡴࠢࡥࡰࡴࡩ࡫ࡦࡦࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ઻")+FeTJrG4SkMf09iVys8A+I5bUBGpPXn0W6(u"ࠫࠥࡣ઼ࠧ"))
				break
		else:
			if F23RLB1XhMiY0: dqKGMYgJxSF8Ub1kotlsP936Ww7B(CKUiyEe28zsZ(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩઽ"),ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧા"),b8bLFaejUB=KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠼࠻࠰ଘ"))
			vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+LyOR7f69iA(u"ࠧࠡࠢࠣࡘ࡮ࡳࡥࡰࡷࡷ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡱࡴࡲࡦࡱ࡫࡭࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭િ")+FeTJrG4SkMf09iVys8A+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࠢࡠࠫી")+L7LuDp2N4SKFOArfsqnxCPcRQ)
			hmBXOtAQZFebaWy8l92sjDCK = KQ3sCe9Pzh(u"ࠩࡷ࡭ࡲ࡫࡯ࡶࡶࠪુ")
	if hmBXOtAQZFebaWy8l92sjDCK in [NxXMrsTC5FniYuRBOK8(u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪૂ")] or PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK in [eNEhtuoi9gK8JaTpIXj(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬૃ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ૄ")] or gZdOM2jYEfV: Fs8cz0DmIrRPSltf71GLpQ(Ph6lazTI975srx)
	else: exec(f90fGrlSEObDsuiA3U(u"࠭ࡩ࡮ࡲࡲࡶࡹࠦࡸࡣ࡯ࡦ࠿ࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠫૅ"))
	return PPlaRuFwOJDGmIoZQSMyfYHbNTvAEt.hmBXOtAQZFebaWy8l92sjDCK
def llr1C3SIFjViqLDtZP(FeTJrG4SkMf09iVys8A):
	if WHjh1POtMKlmgiy68RSqb: from urllib.parse import urlparse as YSZpGyD3PgHhbzLJfQXOsIxE2ie
	else: from urlparse import urlparse as YSZpGyD3PgHhbzLJfQXOsIxE2ie
	path = YSZpGyD3PgHhbzLJfQXOsIxE2ie(FeTJrG4SkMf09iVys8A).path
	sjO4eaE2tKzulCf9GdnkPWvgB8 = eHdDoxhJCEPMZFVa2fg if XugxFprC26zGM(u"ࠧ࠯ࠩ૆") not in path else path.rsplit(LyOR7f69iA(u"ࠨ࠰ࠪે"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷ଙ"))[NSudqlOzja]
	if sjO4eaE2tKzulCf9GdnkPWvgB8 in [GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡤࡺ࡮࠭ૈ"),egY8Jti0smdLM3h1VQRSW(u"ࠪࡸࡸ࠭ૉ"),LTN6DPEmrwehtZMy(u"ࠫࡦࡧࡣࠨ૊"),CKUiyEe28zsZ(u"ࠬࡳࡰ࠵ࠩો"),ehfEsaiJBSvbcULtNPVgykA2(u"࠭࡭࠴ࡷࠪૌ"),KQ3sCe9Pzh(u"ࠧ࡮࠵ࡸ࠼્ࠬ"),LTN6DPEmrwehtZMy(u"ࠨ࡯ࡳࡨࠬ૎"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡰ࡯ࡻ࠭૏"),KQ3sCe9Pzh(u"ࠪࡪࡱࡼࠧૐ"),Cp6c5tZe8I0PxnAW(u"ࠫࡲࡶ࠳ࠨ૑"),w2vjZmdJuY7c(u"ࠬࡽࡥࡣ࡯ࠪ૒")]: return ietolwsjpIPK7Fr(u"࠭࠮ࠨ૓")+sjO4eaE2tKzulCf9GdnkPWvgB8
	return eHdDoxhJCEPMZFVa2fg
def Fs8cz0DmIrRPSltf71GLpQ(X9XxmHBLWPz):
	global RNtanOkdbsT0
	if not wwNbXe9taWdRiFHzyB2MZ: X9XxmHBLWPz += NxXMrsTC5FniYuRBOK8(u"ࠧࡠࡖࡖࠫ૔")
	RNtanOkdbsT0.append(X9XxmHBLWPz)
	return
RNtanOkdbsT0 = []
hmBXOtAQZFebaWy8l92sjDCK = eHdDoxhJCEPMZFVa2fg
ZylBO1ktRGvdJ0 = edpM3qtgTJIz8PWN6lvin()
RnrFhIUdq8Wmp7V5HLxZjvwye6YK = ZylBO1ktRGvdJ0.splitlines()[x1Oa8bBf36EwsLMirtFc][-LTN6DPEmrwehtZMy(u"࠲࠵ଚ"):]
ePJWDdHsX8Tokv31yL,wwNbXe9taWdRiFHzyB2MZ,ot06iq3huYHVAfBszvP1FjG,EDNRGMfBk3H2FAtQI578ubU6cXw0hn = BoGNtDIVHAyw([KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡅࡗࡉ࠾ࡊࡓ࠲࠻࡙࡙࠵࡜ࡓ࡙ࠩ૕"),ilBWK5nXxg1do4jENGC07Zq(u"࡚ࠩࡗ࡚ࡘࡆࡕ࠳࠼ࡕ࡙ࡋࡆ࡛࡚ࠪ૖"),eNEhtuoi9gK8JaTpIXj(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽࡚ࡘࡖࡏࡗࡖ࡙࠺ࡎࡘࠨ૗"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡔ࡚࠱࠺ࡌࡘ࠴ࡽࡈࡔࡖ࡮ࡇ࡜ࠬ૘")])
XJGTegisjUW34EymYo8KNRrSdn = eHdDoxhJCEPMZFVa2fg
N1vK7PznWC6ka = rDceXBpHkfVUYRJ3tIx95Z
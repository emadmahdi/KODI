# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from FUL4oWn9vq import *
import base64 as HHP76VFiKDS2xphlGsqN48j1
EERWJf1adv67 = XugxFprC26zGM(u"ࠪࡐࡎࡈࡓࡕ࡙ࡒࠫଝ")
r3gYWiShzyHFb9MnPD1G8kfBvjp = {}
JXSlk8x495HmgiD = []
XJZYzUxcCNq31 = rDceXBpHkfVUYRJ3tIx95Z
oLfID72TXPO5SkEnW = rDceXBpHkfVUYRJ3tIx95Z
DrA6vCjKTVhS2Qc,idcNRIJPWfTElku4yx3A2,Waw4OEoBpYT0xMqX8dyiCV = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
gcBtx3HrPuOK5sf = {}
WuT0eE8LCKoP,fhKnRUV6FBdvMZ0E8uTYt = [x1Oa8bBf36EwsLMirtFc],[x1Oa8bBf36EwsLMirtFc]
if WHjh1POtMKlmgiy68RSqb:
	RhIUBP3G59lWmTQxAzdMwc = vUiXo5fLMYs4Ku0yRtrI8CZDz.translatePath(egY8Jti0smdLM3h1VQRSW(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡹࡤࡰࡧࠬଞ"))
	jXg4GKQS3sy9ipunzTwkY7N2085dR = vUiXo5fLMYs4Ku0yRtrI8CZDz.translatePath(ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ଟ"))
	MxlQzTmHaWNYt = vUiXo5fLMYs4Ku0yRtrI8CZDz.translatePath(w2vjZmdJuY7c(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪଠ"))
	kpLM6WSIQ0X29nAT1gGDEa = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩଡ"),LTN6DPEmrwehtZMy(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪଢ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡄࡨࡩࡵ࡮ࡴ࠵࠶࠲ࡩࡨࠧଣ"))
	U21Ugqwxbhz5yNuCoBEs = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,KW5bYS20wTF1LyCs9(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬତ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡉࡧࡴࡢࡤࡤࡷࡪ࠭ଥ"),bP01xn84BiQN(u"ࠬ࡜ࡩࡦࡹࡐࡳࡩ࡫ࡳ࠷࠰ࡧࡦࠬଦ"))
	wQMEslno6XmBUVDCLg90Z43aOHhRSr = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,NxXMrsTC5FniYuRBOK8(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨଧ"),CKUiyEe28zsZ(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩନ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡖࡨࡼࡹࡻࡲࡦࡵ࠴࠷࠳ࡪࡢࠨ଩"))
	cUKTayqdnW0 = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࡷࠪࡠࡺ࠶࠲ࡥ࠳ࠪପ")
	from urllib.parse import quote as _LYbmcMgweaJdxriZ4No56US9CjVOp
else:
	RhIUBP3G59lWmTQxAzdMwc = ccwRLKk3hs0E.translatePath(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫଫ"))
	jXg4GKQS3sy9ipunzTwkY7N2085dR = ccwRLKk3hs0E.translatePath(jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬବ"))
	MxlQzTmHaWNYt = ccwRLKk3hs0E.translatePath(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩଭ"))
	kpLM6WSIQ0X29nAT1gGDEa = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,ietolwsjpIPK7Fr(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨମ"),KQ3sCe9Pzh(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩଯ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡃࡧࡨࡴࡴࡳ࠳࠹࠱ࡨࡧ࠭ର"))
	U21Ugqwxbhz5yNuCoBEs = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ଱"),ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬଲ"),LTN6DPEmrwehtZMy(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫଳ"))
	wQMEslno6XmBUVDCLg90Z43aOHhRSr = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,EX25Y0l8ILvz7QcRC(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ଴"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨଵ"),w2vjZmdJuY7c(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧଶ"))
	cUKTayqdnW0 = I5bUBGpPXn0W6(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩଷ").encode(m6PFtLblInpNZ8x)
	from urllib import quote as _LYbmcMgweaJdxriZ4No56US9CjVOp
SSI5kBG0Y2JpF = RRydns1CErYlIhwSx7.path.join(MxlQzTmHaWNYt,eNEhtuoi9gK8JaTpIXj(u"ࠩ࡮ࡳࡩ࡯࠮࡭ࡱࡪࠫସ"))
KdV8utLBIYob1F7S25MqpN4xJ = RRydns1CErYlIhwSx7.path.join(MxlQzTmHaWNYt,LyOR7f69iA(u"ࠪ࡯ࡴࡪࡩ࠯ࡱ࡯ࡨ࠳ࡲ࡯ࡨࠩହ"))
wAR4O5i9os3q = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,LTN6DPEmrwehtZMy(u"ࠫ࡮ࡶࡴࡷ࠳ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭଺"))
lsZrOnAhvFNgoWXi7Czd2q8YpIDE = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,KW5bYS20wTF1LyCs9(u"ࠬ࡯ࡰࡵࡸ࠵ࡨࡦࡺࡡࡠࡡࡢ࠲ࡩࡨࠧ଻"))
X7DcIRbSTJPoeWvVfjMFi = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭࡭࠴ࡷࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ଼࠭"))
CCknZTXVNbG9Px0ds1hpQSMKB = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡧࡣࡹࡳࡺࡸࡩࡵࡧࡶ࠲ࡩࡧࡴࠨଽ"))
MvwZCzPqKXpJoeIHxmnBs976 = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,NxXMrsTC5FniYuRBOK8(u"ࠨ࡫ࡳࡸࡻ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪା"))
zzxr5UY1CkyZG48A9NEPFHhKTD6wc = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,LyOR7f69iA(u"ࠩࡰ࠷ࡺ࡬ࡩ࡭ࡧࡢࡣࡤ࠴ࡤࡢࡶࠪି"))
e8j3fyIi05dcPOpkmq = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪ࡭ࡲࡧࡧࡦࡵࠪୀ"))
xxbf0iMz9QoN7X1n3CkVlwj6qSBZHU = RRydns1CErYlIhwSx7.path.join(e8j3fyIi05dcPOpkmq,LTN6DPEmrwehtZMy(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡷࠬୁ"))
eejL7TCmrFBoyaq = RRydns1CErYlIhwSx7.path.join(e8j3fyIi05dcPOpkmq,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡷࠬୂ"))
gnIVwMHOs8FutBi34RhpT1lbUrL9K = RRydns1CErYlIhwSx7.path.join(xxbf0iMz9QoN7X1n3CkVlwj6qSBZHU,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡥ࠰࠱࠲࠳ࡣ࠳ࡶ࡮ࡨࠩୃ"))
lAf7eTIozDOK0arHsmWx = Z1ZPVbLUsHgxd7X.Addon().getAddonInfo(HkiMU0QrdzW3l6gwnT(u"ࠧࡱࡣࡷ࡬ࠬୄ"))
ZZofrXBSKL1Tu = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,LyOR7f69iA(u"ࠨ࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪ୅"))
CUEeOdPnXQomtWBS2Y4u = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,NxXMrsTC5FniYuRBOK8(u"ࠩࡷ࡬ࡺࡳࡢ࠯ࡲࡱ࡫ࠬ୆"))
jIxzagZKsudDSnqwBbRyT7 = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,XugxFprC26zGM(u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧେ"))
wHNzlXhu4y1YqkUtS9F = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡧࡧ࡮࡯ࡧࡵ࠲ࡵࡴࡧࠨୈ"))
x7JtVu9SHjMbdzfrhWQgkiO13 = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,XugxFprC26zGM(u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥ࠯ࡲࡱ࡫ࠬ୉"))
xLzqafBJjK = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,w2vjZmdJuY7c(u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ୊"))
pItizd2r71bTcQ9XJW = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,eNEhtuoi9gK8JaTpIXj(u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱ࠱ࡴࡳ࡭ࠧୋ"))
UU7dEx8O51wJ4mGhrysoLuZnHv = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,bP01xn84BiQN(u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ࠱ࡴࡳ࡭ࠧୌ"))
E7SBs6g9e82c = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,f90fGrlSEObDsuiA3U(u"ࠩࡰࡩࡳࡻ࡟ࡳࡧࡧࡣ࠷࠶࠰ࡹ࠴࠸࠴࠳ࡶ࡮ࡨ୍ࠩ"))
PP4inxmZ2aEyzRUSLTVtbYHvqejJ = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,eNEhtuoi9gK8JaTpIXj(u"ࠪࡧ࡭ࡧ࡮ࡨࡧ࡯ࡳ࡬࠴ࡴࡹࡶࠪ୎"))
IIzGues0tMAEHi1jYoTvdFCZK = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,CKUiyEe28zsZ(u"ࠫࡦࡪࡤࡰࡰࡶࠫ୏"))
BqL5WyVsJH31zGuD47YPSe = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,t3coAp06zvHrTl49bUVgx(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ୐"),t3coAp06zvHrTl49bUVgx(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ୑"),L1BnkG7RhvcXZoWfjdDHq3Uzu2E,KW5bYS20wTF1LyCs9(u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭୒"))
yyeQJMcPdvbC0 = RRydns1CErYlIhwSx7.path.join(RhIUBP3G59lWmTQxAzdMwc,ilBWK5nXxg1do4jENGC07Zq(u"ࠨ࡯ࡨࡨ࡮ࡧࠧ୓"),t3coAp06zvHrTl49bUVgx(u"ࠩࡉࡳࡳࡺࡳࠨ୔"),egY8Jti0smdLM3h1VQRSW(u"ࠪࡥࡷ࡯ࡡ࡭࠰ࡷࡸ࡫࠭୕"))
II0HXSngDhlLOuNQ9Vi = ietolwsjpIPK7Fr(u"࠶ኼ")
Fv7ouzCZdqTc95fJKBXA = [bP01xn84BiQN(u"ฺࠫ็ัࠨୖ"),w2vjZmdJuY7c(u"ࠬษ่ๅࠩୗ"),KQ3sCe9Pzh(u"࠭หศ่ํࠫ୘"),egY8Jti0smdLM3h1VQRSW(u"ࠧฬษ็ฯࠬ୙"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨำสฬ฾࠭୚"),wY1p9mP03S8drbcH64t5WQkv(u"ࠩัหู๊ࠧ୛"),t3coAp06zvHrTl49bUVgx(u"ࠪืฬีำࠨଡ଼"),jUcmHhgVvW0EdYOIfXeaDF(u"ุࠫอศฺࠩଢ଼"),bP01xn84BiQN(u"ࠬัวๆ่ࠪ୞"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭สศี฼ࠫୟ"),w2vjZmdJuY7c(u"ฺࠧษืีࠬୠ")]
ppNt754RaZ2COG = HkiMU0QrdzW3l6gwnT(u"ࠨ⸽ࠣ⼡ࠥ⸰ࠠ⸼ࠩୡ")
YD0dXLgEm7jKFAqkvz = [LTN6DPEmrwehtZMy(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨୢ")]
QFbgwyCRLTtq = [QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬୣ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ୤"),Cp6c5tZe8I0PxnAW(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ୥"),XugxFprC26zGM(u"࠭ࡅࡈ࡛ࡇࡉࡆࡊࠧ୦"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ୧"),XugxFprC26zGM(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ୨"),I5bUBGpPXn0W6(u"ࠩࡐ࡝ࡈࡏࡍࡂࠩ୩"),w2vjZmdJuY7c(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ୪"),ietolwsjpIPK7Fr(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠸࠭୫"),wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡇࡌࡂࡔࡄࡆࠬ୬")]
QFbgwyCRLTtq += [LTN6DPEmrwehtZMy(u"࠭ࡈࡆࡎࡄࡐࠬ୭"),LTN6DPEmrwehtZMy(u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭୮"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏࠪ୯"),wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ୰"),ietolwsjpIPK7Fr(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡔࠬୱ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡊࡍ࡙ࡏࡑ࡚ࠫ୲"),w2vjZmdJuY7c(u"࡙ࠬࡈࡐࡑࡉࡔࡗࡕࠧ୳"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡐࡂࡐࡈࡘࠬ୴"),NxXMrsTC5FniYuRBOK8(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧ୵"),LyOR7f69iA(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧ୶")]
qh7loPmHLGdF1zrOTK = [LyOR7f69iA(u"ࠩࡌࡔ࡙࡜ࠧ୷"),KQ3sCe9Pzh(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭୸"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩ୹"),HkiMU0QrdzW3l6gwnT(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪ୺")]
qh7loPmHLGdF1zrOTK += [GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡍ࠴ࡗࠪ୻"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩ୼"),eNEhtuoi9gK8JaTpIXj(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬ୽"),t3coAp06zvHrTl49bUVgx(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭୾")]
qh7loPmHLGdF1zrOTK += [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡍࡋࡏࡌࡎࠩ୿"),HkiMU0QrdzW3l6gwnT(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ஀"),bP01xn84BiQN(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ஁")]
qh7loPmHLGdF1zrOTK += [J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡁࡌ࡙ࡄࡑࠬஂ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩஃ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ஄"),ietolwsjpIPK7Fr(u"ࠩࡄࡏࡔࡇࡍࠨஅ"),eNEhtuoi9gK8JaTpIXj(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬஆ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡘࡎࡏࡐࡈࡑࡉ࡙࠭இ")]
qh7loPmHLGdF1zrOTK += [TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨஈ"),LTN6DPEmrwehtZMy(u"࠭ࡂࡐࡍࡕࡅࠬஉ"),w2vjZmdJuY7c(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩஊ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭஋"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠴ࠫ஌"),w2vjZmdJuY7c(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ஍")]
UhOybXi0K5 = [bP01xn84BiQN(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬஎ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭ஏ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪஐ"),RqLvTrID0yMVeClpYcnZ16i3X(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪ஑")]
UhOybXi0K5 += [jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ஒ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡗࡋࡇࡉࡔ࡙ࠧஓ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫஔ"),NxXMrsTC5FniYuRBOK8(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫக"),S8i3sBYoHWdTURpAgN(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡐࡎ࡜ࡅࡔࠩ஖"),ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡍࡇࡓࡉࡖࡄࡋࡘ࠭஗")]
uMRh32KD1apXJFsqYUIGOS9ot = [w2vjZmdJuY7c(u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ஘"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩங"),I5bUBGpPXn0W6(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪச"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡅࡗࡇࡂࡔࡇࡈࡈࠬ஛"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨஜ")]
uMRh32KD1apXJFsqYUIGOS9ot += [CKUiyEe28zsZ(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧ஝"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡔࡗࡈࡘࡒࠬஞ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡘࡇࡆࡍࡒࡇࠧட"),ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ஠"),w2vjZmdJuY7c(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ஡")]
xBi8l0OAwMmsWTkcgD5 = [iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬ஢"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡈࡏࡍࡂࡈࡄࡒࡘ࠭ண"),wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨத"),CKUiyEe28zsZ(u"࠭ࡆࡐࡕࡗࡅࠬ஥"),HkiMU0QrdzW3l6gwnT(u"ࠧࡂࡊ࡚ࡅࡐ࠭஦"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ஧"),ietolwsjpIPK7Fr(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫந"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬன"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"࡛ࠫࡇࡒࡃࡑࡑࠫப"),I5bUBGpPXn0W6(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩ஫")]
xBi8l0OAwMmsWTkcgD5 += [iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡓࡉࡑࡉࡌࡆ࠭஬"),KQ3sCe9Pzh(u"ࠧࡃࡔࡖࡘࡊࡐࠧ஭"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨ࡛ࡄࡕࡔ࡚ࠧம"),I5bUBGpPXn0W6(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪய"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫர"),w2vjZmdJuY7c(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠹࠭ற"),w2vjZmdJuY7c(u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧல"),wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩள"),wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨழ"),I5bUBGpPXn0W6(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨவ"),CKUiyEe28zsZ(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪஶ")]
xBi8l0OAwMmsWTkcgD5 += [ietolwsjpIPK7Fr(u"ࠪࡊ࡚࡙ࡈࡂࡔ࡙ࡍࡉࡋࡏࠨஷ"),ietolwsjpIPK7Fr(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ஸ"),eNEhtuoi9gK8JaTpIXj(u"ࠬࡑࡉࡓࡏࡄࡐࡐ࠭ஹ"),XugxFprC26zGM(u"࠭ࡄࡓࡃࡐࡅࡈࡇࡆࡆࠩ஺"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧ஻"),wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ஼"),XugxFprC26zGM(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫ஽"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡇࡎࡓࡁࡘࡄࡄࡗࠬா")]
BYNI789mFEh30cl5  = [TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡆࡑࡗࡂࡏࠪி"),ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧீ"),KQ3sCe9Pzh(u"࠭ࡂࡐࡍࡕࡅࠬு"),EX25Y0l8ILvz7QcRC(u"ࠧࡂࡍࡒࡅࡒ࠭ூ"),EX25Y0l8ILvz7QcRC(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ௃"),w2vjZmdJuY7c(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ௄"),XugxFprC26zGM(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ௅"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠷࠭ெ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡉࡉࡎࡃࡉࡖࡊࡋࠧே"),Cp6c5tZe8I0PxnAW(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭ை")]
BYNI789mFEh30cl5 += [t3coAp06zvHrTl49bUVgx(u"ࠧࡄࡋࡐࡅࡋࡇࡎࡔࠩ௉"),LyOR7f69iA(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫொ"),w2vjZmdJuY7c(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪோ"),XugxFprC26zGM(u"࡛ࠪࡊࡉࡉࡎࡃࠪௌ"),f90fGrlSEObDsuiA3U(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨ்"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡌࡏࡔࡖࡄࠫ௎"),jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡁࡉ࡙ࡄࡏࠬ௏"),KW5bYS20wTF1LyCs9(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩௐ"),egY8Jti0smdLM3h1VQRSW(u"ࠨࡕࡈࡖࡎࡋࡓࡕࡋࡐࡉࠬ௑")]
BYNI789mFEh30cl5 += [TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬ௒"),LTN6DPEmrwehtZMy(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭௓"),S8i3sBYoHWdTURpAgN(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭௔"),LyOR7f69iA(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧ௕"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨ௖"),f90fGrlSEObDsuiA3U(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩௗ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫ௘"),LTN6DPEmrwehtZMy(u"ࠩࡉࡅࡗࡋࡓࡌࡑࠪ௙")]
BYNI789mFEh30cl5 += [t3coAp06zvHrTl49bUVgx(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫ௚"),bP01xn84BiQN(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭௛"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ௜"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡔࡗࡈࡘࡒࠬ௝"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩ௞"),f90fGrlSEObDsuiA3U(u"ࠨࡕࡋࡓࡋࡎࡁࠨ௟"),S8i3sBYoHWdTURpAgN(u"࡙ࠩࡅࡗࡈࡏࡏࠩ௠"),Cp6c5tZe8I0PxnAW(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫ௡")]
BYNI789mFEh30cl5 += [I5bUBGpPXn0W6(u"ࠫࡇࡘࡓࡕࡇࡍࠫ௢"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠬ࡟ࡁࡒࡑࡗࠫ௣"),KQ3sCe9Pzh(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ௤"),I5bUBGpPXn0W6(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ௥"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭௦"),t3coAp06zvHrTl49bUVgx(u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉࠫ௧"),I5bUBGpPXn0W6(u"ࠪࡏࡆ࡚ࡋࡐࡖࡗ࡚ࠬ௨"),I5bUBGpPXn0W6(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ௩")]
BYNI789mFEh30cl5 += [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡌࡕࡔࡊࡄࡖ࡛ࡏࡄࡆࡑࠪ௪"),LyOR7f69iA(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨ௫"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨ௬"),bP01xn84BiQN(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ௭"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡗࡍࡐࡇࡁࡕࠩ௮"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭௯"),ietolwsjpIPK7Fr(u"ࠫࡆࡔࡉࡎࡇ࡝ࡍࡉ࠭௰"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧ௱")]
Xn7wGqCpmJ5z6xkNQRaMo2f4vTb  = [LyOR7f69iA(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱࡛ࡏࡄࡆࡑࡖࠫ௲"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡖࡌࡂ࡛ࡏࡍࡘ࡚ࡓࠨ௳"),CKUiyEe28zsZ(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡃࡉࡃࡑࡒࡊࡒࡓࠨ௴"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡍࡋ࡙ࡉࡘ࠭௵"),Cp6c5tZe8I0PxnAW(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡊࡄࡗࡍ࡚ࡁࡈࡕࠪ௶")]
Xn7wGqCpmJ5z6xkNQRaMo2f4vTb += [egY8Jti0smdLM3h1VQRSW(u"ࠫࡎࡌࡉࡍࡏ࠰ࡅࡗࡇࡂࡊࡅࠪ௷"),S8i3sBYoHWdTURpAgN(u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡔࡇࡍࡋࡖࡌࠬ௸")]
Xn7wGqCpmJ5z6xkNQRaMo2f4vTb += [dEwyQDiz0nhjV6MovaH7tIWYel92(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡗࡋࡇࡉࡔ࡙ࠧ௹"),XugxFprC26zGM(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡖࠫ௺"),t3coAp06zvHrTl49bUVgx(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࠫ௻")]
Xn7wGqCpmJ5z6xkNQRaMo2f4vTb += [TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡌࡔ࡙࡜࠭ࡍࡋ࡙ࡉࠬ௼"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡍࡕ࡚ࡖ࠮ࡏࡒ࡚ࡎࡋࡓࠨ௽"),NxXMrsTC5FniYuRBOK8(u"ࠫࡎࡖࡔࡗ࠯ࡖࡉࡗࡏࡅࡔࠩ௾")]
Xn7wGqCpmJ5z6xkNQRaMo2f4vTb += [XugxFprC26zGM(u"ࠬࡓ࠳ࡖ࠯ࡏࡍ࡛ࡋࠧ௿"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡍ࠴ࡗ࠰ࡑࡔ࡜ࡉࡆࡕࠪఀ"),KQ3sCe9Pzh(u"ࠧࡎ࠵ࡘ࠱ࡘࡋࡒࡊࡇࡖࠫఁ")]
lkoFvjQ4EYH7JnD2Wd5fCziLUGZ = [ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡏ࠶࡙ࠬం"),KW5bYS20wTF1LyCs9(u"ࠩࡌࡔ࡙࡜ࠧః"),KQ3sCe9Pzh(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨఄ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡎࡌࡉࡍࡏࠪఅ"),Cp6c5tZe8I0PxnAW(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ఆ")]
naG7EqUw8YHRZpyL5vitx0QSB = BYNI789mFEh30cl5+Xn7wGqCpmJ5z6xkNQRaMo2f4vTb
LSPX4bazoBtC9kh = BYNI789mFEh30cl5+lkoFvjQ4EYH7JnD2Wd5fCziLUGZ
I75YTtmVrWsBxHO = BYNI789mFEh30cl5+Xn7wGqCpmJ5z6xkNQRaMo2f4vTb
Iwfn8xNC4dR5GSF9brk3Ohg = qh7loPmHLGdF1zrOTK+uMRh32KD1apXJFsqYUIGOS9ot+xBi8l0OAwMmsWTkcgD5+UhOybXi0K5
JUgvml72z0B35 = [
						ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠶ࡹࡴࠨఇ")
						,NxXMrsTC5FniYuRBOK8(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠸࡮ࡥࠩఈ")
						,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡛ࡌࡕࡋࡢ࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩఉ")
						]
IuLpt4BK7yjad0vMW63Ql = [
						ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡊࡔࡄࡠࡃࡑࡅࡑ࡟ࡔࡊࡅࡖࡣࡊ࡜ࡅࡏࡖࡖ࠱࠶ࡹࡴࠨఊ")
						,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡊ࡞ࡔࡓࡃࡆࡘࡤࡓ࠳ࡖ࠺࠰࠵ࡸࡺࠧఋ")
						,bP01xn84BiQN(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡁࡏࡆࡒࡑࡤ࡛ࡓࡆࡔࡄࡋࡊࡔࡔ࠮࠳ࡶࡸࠬఌ")
						,NxXMrsTC5FniYuRBOK8(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭఍")
						,KQ3sCe9Pzh(u"࠭ࡉࡑࡖ࡙࠱ࡈࡎࡅࡄࡍࡢࡅࡈࡉࡏࡖࡐࡗ࠱࠶ࡹࡴࠨఎ")
						,ietolwsjpIPK7Fr(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡈࡓࡑࡕࡃࡂࡖࡌࡓࡓ࠳࠱ࡴࡶࠪఏ")
						,KW5bYS20wTF1LyCs9(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬఐ")
						,I5bUBGpPXn0W6(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭఑")
						,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧఒ")
						,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡈࡑࡒࡋࡑࡋࡕࡔࡇࡕࡇࡔࡔࡔࡆࡐࡗ࠱࠶ࡹࡴࠨఓ")
						,KW5bYS20wTF1LyCs9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠵ࡵࡨࠬఔ")
						,Cp6c5tZe8I0PxnAW(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠸ࡸ࡭࠭క")
						,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭ఖ")
						,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪగ")
						,ietolwsjpIPK7Fr(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠳ࡰࡧࠫఘ")
						]
cSqXLrU3vfn6Ke = IuLpt4BK7yjad0vMW63Ql+[
				 KW5bYS20wTF1LyCs9(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡕࡘࡏ࡙࡛ࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬఙ")
				,bP01xn84BiQN(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡈࡕࡖࡓࡗࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩచ")
				,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨఛ")
				,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙ࡋࡈࡗ࠲࠸࡮ࡥࠩజ")
				,LyOR7f69iA(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠱ࡴࡶࠪఝ")
				,jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛࡝࡙ࡕ࠭࠳ࡰࡧࠫఞ")
				,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠲ࡵࡷࠫట")
				,CKUiyEe28zsZ(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠴ࡱࡨࠬఠ")
				,KQ3sCe9Pzh(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡋࡑࡔࡒ࡜࡞ࡉࡏࡎ࠯࠶ࡶࡩ࠭డ")
				,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡃࡉࡇࡆࡏࡤࡎࡔࡕࡒࡖࡣࡕࡘࡏ࡙ࡋࡈࡗ࠲࠷ࡳࡵࠩఢ")
				,CKUiyEe28zsZ(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡊࡗࡘࡕ࡙࡟ࡕࡇࡖࡘ࠲࠷ࡳࡵࠩణ")
				,HkiMU0QrdzW3l6gwnT(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠱ࡴࡶࠪత")
				,LTN6DPEmrwehtZMy(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠳ࡰࡧࠫథ")
				,f90fGrlSEObDsuiA3U(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡚࡙ࡁࡈࡇࡢࡖࡊࡖࡏࡓࡖ࠰࠵ࡸࡺࠧద")
				,HkiMU0QrdzW3l6gwnT(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡕࡏࡈࡎࡈࡣ࡙ࡘࡁࡏࡕࡏࡅ࡙ࡋ࠭࠲ࡵࡷࠫధ")
				,w2vjZmdJuY7c(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭న")
				]
MOnQlAXkSV8vb2sDyWdtPzBU1ea = [HkiMU0QrdzW3l6gwnT(u"ࠬ࠾࠮࠹࠰࠻࠲࠽࠭఩"),CKUiyEe28zsZ(u"࠭࠱࠯࠳࠱࠵࠳࠷ࠧప"),KQ3sCe9Pzh(u"ࠧ࠲࠰࠳࠲࠵࠴࠱ࠨఫ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨ࠺࠱࠼࠳࠺࠮࠵ࠩబ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠷࠴࠲࠳࠴ࠪభ"),eNEhtuoi9gK8JaTpIXj(u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠶࠮࠳࠴࠳ࠫమ")]
VtgEUvxaDeTMuPlwi3HAQchFpIOJ9 = {
			 w2vjZmdJuY7c(u"ࠫࡆࡎࡗࡂࡍࠪయ")		:[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧర")]
			,NxXMrsTC5FniYuRBOK8(u"࠭ࡁࡌ࡙ࡄࡑࠬఱ")		:[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼࠧల")]
			,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫళ")	:[wY1p9mP03S8drbcH64t5WQkv(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭࠳ࡧ࡫ࡸࡣࡰ࠲ࡹࡻࡢࡦࠩఴ")]
			,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡅࡑࡓࡁࡂࡔࡈࡊࠬవ")		:[ehfEsaiJBSvbcULtNPVgykA2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡬࡮ࡣࡤࡶࡪ࡬࠮ࡤࡪࠪశ")]
			,EX25Y0l8ILvz7QcRC(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ష")		:[NxXMrsTC5FniYuRBOK8(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡦࡲ࡭ࡴࡶࡥࡥ࠳ࡺࡶࠨస")]
			,ietolwsjpIPK7Fr(u"ࠧࡂࡐࡌࡑࡊࡠࡉࡅࠩహ")		:[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲ࡮ࡳࡥࡻ࡫ࡧ࠲ࡸ࡮࡯ࡸࠩ఺")]
			,XugxFprC26zGM(u"ࠩࡄࡖࡆࡈࡉࡄࡖࡒࡓࡓ࡙ࠧ఻")	:[w2vjZmdJuY7c(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡢࡴࡤࡦ࡮ࡩ࠭ࡵࡱࡲࡲࡸ࠴ࡣࡰ࡯఼ࠪ")]
			,ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ఽ")		:[S8i3sBYoHWdTURpAgN(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡣࡥࡷࡪ࡫ࡤ࠯ࡰࡨࡸࠬా")]
			,RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡂࡐࡍࡕࡅࠬి")		:[LyOR7f69iA(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡼ࡯ࡥ࠰ࡦࡳࡲ࠭ీ")]
			,egY8Jti0smdLM3h1VQRSW(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨు")		:[f90fGrlSEObDsuiA3U(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡷࡹࡴࡦ࡬࠱ࡧࡴࡳࠧూ")]
			,ietolwsjpIPK7Fr(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫృ")		:[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠷࠴࠵࠴ࡣࡰ࡯ࠪౄ")]
			,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬ౅")		:[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡦ࡭ࡲࡧ࠴ࡱ࠰ࡦࡳࡲ࠭ె")]
			,NxXMrsTC5FniYuRBOK8(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧే")		:[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠴ࡧ࡮ࡳࡡ࠵ࡷ࠱ࡧࡴࡳࠧై")]
			,NxXMrsTC5FniYuRBOK8(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫ౉")		:[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠵ࡥࡨࡴ࠴ࡣࡰ࡯ࠪొ")]
			,KW5bYS20wTF1LyCs9(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ో")		:[I5bUBGpPXn0W6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡹࡤࡸࡨ࡮ࠧౌ")]
			,KQ3sCe9Pzh(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏ్ࠬ")	:[egY8Jti0smdLM3h1VQRSW(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡹࡺ࠳ࡩࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡴࡪࡲࡴࠬ౎")]
			,EX25Y0l8ILvz7QcRC(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ౏")		:[bP01xn84BiQN(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭౐")]
			,NxXMrsTC5FniYuRBOK8(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬ౑")		:[f90fGrlSEObDsuiA3U(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡩࡶࡪ࡫࠮ࡷ࡫ࡳࠫ౒")]
			,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨ౓")	:[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠴࠺࠲ࡲࡿ࠭ࡤ࡫ࡰࡥ࠳ࡴࡥࡵ࠱ࡰࡽࡨ࠷ࠧ౔")]
			,w2vjZmdJuY7c(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨౕ")		:[EX25Y0l8ILvz7QcRC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࡮ࡰࡹ࠱ࡧࡨౖ࠭")]
			,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫ౗")		:[wY1p9mP03S8drbcH64t5WQkv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡹࡥࡥࡸ࠴࡭ࡺࡥ࡬ࡱࡦ࠴ࡣࡤࠩౘ")]
			,EX25Y0l8ILvz7QcRC(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩౙ")	:[LyOR7f69iA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬౚ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ౛")]
			,f90fGrlSEObDsuiA3U(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪ౜")	:[bP01xn84BiQN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠺࠴ࡤࡳࡣࡰࡥࡨࡧࡦࡦ࠯ࡷࡺ࠳ࡩ࡯࡮ࠩౝ")]
			,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ౞")		:[CKUiyEe28zsZ(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡩ࠮ࡥࡴࡤࡱࡦࡹ࠷࠯ࡥࡲࡱࠬ౟")]
			,LyOR7f69iA(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ౠ")		:[TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡧࡷࡱࠫౡ")]
			,CKUiyEe28zsZ(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨౢ")		:[KW5bYS20wTF1LyCs9(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡺࡩࡧࡩࡡ࡮ࠩౣ")]
			,KW5bYS20wTF1LyCs9(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ౤")		:[XugxFprC26zGM(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡨࡩࡥࠩ౥")]
			,Cp6c5tZe8I0PxnAW(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ౦")		:[eNEhtuoi9gK8JaTpIXj(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺ࠯ࡥࡩࡸࡺ࠮࡯ࡧࡷࠫ౧")]
			,LTN6DPEmrwehtZMy(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭౨")		:[J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡨࡪࡧࡤ࠯࡮࡬ࡺࡪ࠭౩")]
			,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ౪")		:[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡰࡨ࡯࡮ࡦ࡯ࡤ࠲ࡨࡵ࡭ࠨ౫")]
			,S8i3sBYoHWdTURpAgN(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪ౬")		:[bP01xn84BiQN(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧࡢࡳ࡭ࡤ࠲ࡨࡵ࡭ࠨ౭")]
			,wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ౮")	:[ietolwsjpIPK7Fr(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࡬ࡨࡶ࠳ࡹࡨࡰࡹࠪ౯")]
			,wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ౰")		:[KW5bYS20wTF1LyCs9(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡴ࠳࡬ࡡࡳࡧࡶ࡯ࡴ࠴࡮ࡦࡶࠪ౱")]
			,ietolwsjpIPK7Fr(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪ౲")		:[eNEhtuoi9gK8JaTpIXj(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡣࡶࡩࡱ࡮ࡤࡴ࠰ࡦࡥࡷ࡫ࠧ౳")]
			,HkiMU0QrdzW3l6gwnT(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ౴")		:[bP01xn84BiQN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࡭ࡣ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪ౵")]
			,bP01xn84BiQN(u"ࠬࡌࡏࡔࡖࡄࠫ౶")		:[I5bUBGpPXn0W6(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹ࡭࠲࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴࡮ࡦࡶࠪ౷")]
			,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ౸")		:[EX25Y0l8ILvz7QcRC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡥ࠲࡫ࡻࡳࡩࡣࡵ࠱ࡹࡼ࠮ࡤࡱࡰࠫ౹")]
			,KQ3sCe9Pzh(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧ౺")	:[jUcmHhgVvW0EdYOIfXeaDF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡦࡶࡵ࡫ࡥࡷ࠴ࡶࡪࡦࡨࡳࠬ౻")]
			,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭౼")		:[KW5bYS20wTF1LyCs9(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡨࡢ࡮ࡤࡧ࡮ࡳࡡ࠯࡯ࡨࡨ࡮ࡧࠧ౽")]
			,RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡉࡇࡋࡏࡑࠬ౾")		:[w2vjZmdJuY7c(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨ౿"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩಀ"),NxXMrsTC5FniYuRBOK8(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪಁ"),EX25Y0l8ILvz7QcRC(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡧ࠲࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬಂ"),KW5bYS20wTF1LyCs9(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠾࠹࠮࠲࠻࠳࠲࠷࠺࠮࠲࠴࠵ࠫಃ")]
			,KQ3sCe9Pzh(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨ಄")	:[w2vjZmdJuY7c(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡣࡵࡦࡦࡲࡡ࠮ࡶࡹ࠲࡮ࡷࠧಅ")]
			,jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡌࡃࡗࡏࡔ࡚ࡔࡗࠩಆ")		:[t3coAp06zvHrTl49bUVgx(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪࡳࡴ࠴࡫ࡪࡶ࡮ࡳࡹ࠴ࡴࡷࠩಇ")]
			,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪಈ")		:[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡻ࠮࡬࡫ࡵࡱࡦࡲ࡫࠯ࡥࡲࡱࠬಉ")]
			,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪಊ")	:[I5bUBGpPXn0W6(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥࠩಋ"),LTN6DPEmrwehtZMy(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠷࠶࠱࠹࠰ࡩࡻࡸ࠴ࡳࡵࡱࡵࡩࠬಌ")]
			,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡍࡃࡕࡓ࡟ࡇࠧ಍")		:[S8i3sBYoHWdTURpAgN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡯ࡥࡷࡵࡺࡢ࠰࡬ࡲ࡫ࡵࠧಎ")]
			,t3coAp06zvHrTl49bUVgx(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪಏ")		:[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵࡤࡺࡰࡨࡸ࠳ࡲࡩ࡯࡭ࠪಐ")]
			,wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡕࡇࡎࡆࡖࠪ಑")		:[HkiMU0QrdzW3l6gwnT(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡥࡳ࡫ࡴ࠯ࡥࡲ࠲࡮ࡲࠧಒ")]
			,KQ3sCe9Pzh(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪಓ")	:[dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬಔ")]
			,S8i3sBYoHWdTURpAgN(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫಕ")	:[KQ3sCe9Pzh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥ࠳࡙ࡈࡂࡄࡄࡏࡆ࡚࡙࠯ࡸ࡬ࡴࠬಖ")]
			,LTN6DPEmrwehtZMy(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬಗ")		:[Cp6c5tZe8I0PxnAW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡷ࡫ࡳ࠲ࡨࡧ࡭ࠨಘ")]
			,LyOR7f69iA(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩಙ")	:[w2vjZmdJuY7c(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࠰ࡶ࡬࠹ࡻ࠮࡯ࡧࡺࡷࠬಚ")]
			,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡔࡊࡒࡊࡍࡇࠧಛ")		:[eNEhtuoi9gK8JaTpIXj(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡳࡩࡱࡩ࡬ࡦ࠴ࡴࡷࠩಜ")]
			,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫಝ")		:[I5bUBGpPXn0W6(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪಞ"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡤࡱࡰࠫಟ"),t3coAp06zvHrTl49bUVgx(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡣࡽࡹࡷ࡫ࡥࡥࡩࡨ࠲ࡳ࡫ࡴࠨಠ")]
			,ietolwsjpIPK7Fr(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨಡ")		:[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡶ࠲ࡸ࡮࡯ࡰࡨࡱࡩࡹ࠴࡯࡯࡮࡬ࡲࡪ࠭ಢ")]
			,bP01xn84BiQN(u"ࠨࡖࡌࡏࡆࡇࡔࠨಣ")		:[NxXMrsTC5FniYuRBOK8(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡵ࡫࡮ࡥࡦࡺ࠮࡯ࡧࡷࠫತ")]
			,LyOR7f69iA(u"ࠪࡘ࡛ࡌࡕࡏࠩಥ")		:[KQ3sCe9Pzh(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡩࡹࡳ࠴࡭ࡦࠩದ")]
			,S8i3sBYoHWdTURpAgN(u"ࠬ࡜ࡁࡓࡄࡒࡒࠬಧ")		:[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡹࡥࡷࡨ࡯࡯࠰ࡦࡥࡲ࠭ನ")]
			,CKUiyEe28zsZ(u"ࠧࡘࡇࡆࡍࡒࡇࠧ಩")		:[jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡻࡲ࠲࠳࠭࠮࠯࠰ࡲࡿ࡫ࡢࡤࡣ࠸࡫ࡩ࠽࡯ࡥࡧ࠳ࡦ࡮࡭࡬ࡩ࠰ࡰࡽࡨ࡯ࡩ࡮ࡣ࠰ࡻࡪࡩࡩࡪ࡯ࡤ࠲ࡸ࡮࡯ࡱࠩಪ")]
			,LTN6DPEmrwehtZMy(u"ࠩ࡜ࡅࡖࡕࡔࠨಫ")		:[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾ࠴ࡹࡢࡳࡲࡸ࠳ࡺࡶࠨಬ")]
			,ietolwsjpIPK7Fr(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬಭ")		:[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨಮ")]
			,NxXMrsTC5FniYuRBOK8(u"࠭ࡒࡆࡒࡒࡗࠬಯ")		:[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡲࡪࡺ࡬ࡪࡨࡼ࠲ࡦࡶࡰ࠰ࡍࡒࡈࡎࡘࡅࡑࡑ࠲ࡅࡉࡊࡏࡏࡕ࠲ࡥࡩࡪ࡯࡯ࡵ࠱ࡼࡲࡲࠧರ"),EX25Y0l8ILvz7QcRC(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱ࠱ࡎࡓࡉࡏࡒࡆࡒࡒ࠳ࡆࡊࡄࡐࡐࡖ࠵࠽࠵ࡡࡥࡦࡲࡲࡸ࠷࠸࠯ࡺࡰࡰࠬಱ"),t3coAp06zvHrTl49bUVgx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡴࡥࡵ࡮࡬ࡪࡾ࠴ࡡࡱࡲ࠲ࡏࡔࡊࡉࡓࡇࡓࡓ࠴ࡇࡄࡅࡑࡑࡗ࠶࠿࠯ࡢࡦࡧࡳࡳࡹ࠱࠺࠰ࡻࡱࡱ࠭ಲ")]
			,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠭ಳ")	:[S8i3sBYoHWdTURpAgN(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ಴"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧವ"),NxXMrsTC5FniYuRBOK8(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨಶ")]
			,NxXMrsTC5FniYuRBOK8(u"ࠧࡔࡑࡘࡖࡈࡋࡓࠨಷ")		:[f90fGrlSEObDsuiA3U(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡯ࡴࡪࡩࠨಸ"),KW5bYS20wTF1LyCs9(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡹࡵࡳࡩࡨ࠲ࡸ࡮ࠧಹ"),XugxFprC26zGM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠭಺")]
			}
if NSudqlOzja:
	VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ಻")] = [RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡲࡩࡴࡶࡳࡰࡦࡿ಼ࠧ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫಽ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪಾ"),XugxFprC26zGM(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭ಿ"),LTN6DPEmrwehtZMy(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ೀ"),ietolwsjpIPK7Fr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩು"),ilBWK5nXxg1do4jENGC07Zq(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬೂ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ೃ"),w2vjZmdJuY7c(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧೄ"),EX25Y0l8ILvz7QcRC(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ೅")]
	VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔࠬೆ")] = [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬೇ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩೈ"),Cp6c5tZe8I0PxnAW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨ೉"),I5bUBGpPXn0W6(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫೊ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫೋ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧೌ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵ್ࠪ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲ࡧࡦࡶࡴࡤࡪࡤࠫ೎"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ೏"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪ೐")]
else:
	VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ೑")] = [egY8Jti0smdLM3h1VQRSW(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ೒"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭೓"),I5bUBGpPXn0W6(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ೔"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨೕ"),f90fGrlSEObDsuiA3U(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨೖ"),CKUiyEe28zsZ(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ೗"),bP01xn84BiQN(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ೘"),egY8Jti0smdLM3h1VQRSW(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ೙"),ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ೚"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ೛")]
	VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[t3coAp06zvHrTl49bUVgx(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠭೜")] = [NxXMrsTC5FniYuRBOK8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭ೝ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪೞ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ೟"),EX25Y0l8ILvz7QcRC(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬೠ"),t3coAp06zvHrTl49bUVgx(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬೡ"),eNEhtuoi9gK8JaTpIXj(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨೢ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫೣ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬ೤"),w2vjZmdJuY7c(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭೥"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫ೦")]
jf6T7xMX5EFuz1Do8OhVpByYak = [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨ೧"),t3coAp06zvHrTl49bUVgx(u"ࠧࡓࡇࡓࡓࡗ࡚ࡓࠨ೨"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡇࡐࡅࡎࡒࡓࠨ೩"),EX25Y0l8ILvz7QcRC(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫ೪"),Cp6c5tZe8I0PxnAW(u"ࠪࡍࡘࡒࡁࡎࡋࡆࡗࠬ೫"),NxXMrsTC5FniYuRBOK8(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ೬"),bP01xn84BiQN(u"ࠬࡑࡎࡐ࡙ࡑࡉࡗࡘࡏࡓࡕࠪ೭"),f90fGrlSEObDsuiA3U(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧ೮"),t3coAp06zvHrTl49bUVgx(u"ࠧࡕࡇࡖࡘࡎࡔࡇࠨ೯"),NxXMrsTC5FniYuRBOK8(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪ೰")]
qKxXzgTdEs3ImAyrNu2DZviRW0 = [GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡄࡈࡉࡕࡎࡔࠩೱ"),w2vjZmdJuY7c(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠼ࠬೲ"),I5bUBGpPXn0W6(u"ࠫࡆࡊࡄࡐࡐࡖ࠵࠾࠭ೳ")]
class powlCmxIzivj6GL(kUJmKtWGNH8p5OjA2MPrZQ9I0zeTVa):
	def __init__(HdFhWUe2bNoCMA0,*aargs,**kkwargs):
		HdFhWUe2bNoCMA0.choiceID = -NSudqlOzja
	def onClick(HdFhWUe2bNoCMA0,ur8GxN3kHf2pK4vJgjUdLOtQlAXsC):
		if ur8GxN3kHf2pK4vJgjUdLOtQlAXsC>=Cp6c5tZe8I0PxnAW(u"࠻࠳࠵࠵ኽ"): HdFhWUe2bNoCMA0.choiceID = ur8GxN3kHf2pK4vJgjUdLOtQlAXsC-Cp6c5tZe8I0PxnAW(u"࠻࠳࠵࠵ኽ")
		HdFhWUe2bNoCMA0.opVbMj6LnO()
	def f4fahsHcwJLdtSvP0r6yF5NqbAp1(HdFhWUe2bNoCMA0,*aargs):
		HdFhWUe2bNoCMA0.button0,HdFhWUe2bNoCMA0.button1,HdFhWUe2bNoCMA0.button2 = aargs[x1Oa8bBf36EwsLMirtFc],aargs[NSudqlOzja],aargs[FB0pIzAoK8wqgd3UiY5]
		HdFhWUe2bNoCMA0.header,HdFhWUe2bNoCMA0.text = aargs[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1],aargs[BSw5mizCOsKxWrRDvtJuFajY]
		HdFhWUe2bNoCMA0.profile,HdFhWUe2bNoCMA0.direction = aargs[J7divaGOCgq2SLfXpDzZYN58wc(u"࠸ኾ")],aargs[RqLvTrID0yMVeClpYcnZ16i3X(u"࠺኿")]
		HdFhWUe2bNoCMA0.buttonstimeout,HdFhWUe2bNoCMA0.closetimeout = aargs[CKUiyEe28zsZ(u"࠽዁")],aargs[TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠽ዀ")]
		if HdFhWUe2bNoCMA0.buttonstimeout>x1Oa8bBf36EwsLMirtFc or HdFhWUe2bNoCMA0.closetimeout>eNEhtuoi9gK8JaTpIXj(u"࠰ዂ"): HdFhWUe2bNoCMA0.enable_progressbar = YchIv6N09BaWPEj4tieAnluKZrRXT
		else: HdFhWUe2bNoCMA0.enable_progressbar = rDceXBpHkfVUYRJ3tIx95Z
		HdFhWUe2bNoCMA0.image_filename = gnIVwMHOs8FutBi34RhpT1lbUrL9K.replace(KQ3sCe9Pzh(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬ೴"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭࡟ࠨ೵")+str(b8bLFaejUB.time())+Cp6c5tZe8I0PxnAW(u"ࠧࡠࠩ೶"))
		HdFhWUe2bNoCMA0.image_filename = HdFhWUe2bNoCMA0.image_filename.replace(ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࡞࡟ࠫ೷"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࡟ࡠࡡࡢࠧ೸")).replace(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪ࠳࠴࠭೹"),EX25Y0l8ILvz7QcRC(u"ࠫ࠴࠵࠯࠰ࠩ೺"))
		HdFhWUe2bNoCMA0.image_height = Ge4XfaYx3t1(HdFhWUe2bNoCMA0.button0,HdFhWUe2bNoCMA0.button1,HdFhWUe2bNoCMA0.button2,HdFhWUe2bNoCMA0.header,HdFhWUe2bNoCMA0.text,HdFhWUe2bNoCMA0.profile,HdFhWUe2bNoCMA0.direction,HdFhWUe2bNoCMA0.enable_progressbar,HdFhWUe2bNoCMA0.image_filename)
		HdFhWUe2bNoCMA0.show()
		HdFhWUe2bNoCMA0.getControl(jUcmHhgVvW0EdYOIfXeaDF(u"࠺࠲࠸࠴ዃ")).setImage(HdFhWUe2bNoCMA0.image_filename)
		HdFhWUe2bNoCMA0.getControl(egY8Jti0smdLM3h1VQRSW(u"࠻࠳࠹࠵ዄ")).setHeight(HdFhWUe2bNoCMA0.image_height)
		if not HdFhWUe2bNoCMA0.button1 and HdFhWUe2bNoCMA0.button0 and HdFhWUe2bNoCMA0.button2: HdFhWUe2bNoCMA0.getControl(w2vjZmdJuY7c(u"࠽࠵࠷࠲዆")).setPosition(-J7divaGOCgq2SLfXpDzZYN58wc(u"࠷࠸࠰዇"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠳ዅ"))
		return HdFhWUe2bNoCMA0.image_filename,HdFhWUe2bNoCMA0.image_height
	def gm1J9RpCIl(HdFhWUe2bNoCMA0):
		if HdFhWUe2bNoCMA0.buttonstimeout:
			HdFhWUe2bNoCMA0.th1 = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=HdFhWUe2bNoCMA0.MdBSXcH42E8GZUsLRgIoNymTfe6YK,args=())
			HdFhWUe2bNoCMA0.th1.start()
		else: HdFhWUe2bNoCMA0.qW0PXcHxyFSLRhN8oTDnCBdzu()
	def MdBSXcH42E8GZUsLRgIoNymTfe6YK(HdFhWUe2bNoCMA0):
		HdFhWUe2bNoCMA0.getControl(jUcmHhgVvW0EdYOIfXeaDF(u"࠿࠰࠳࠲ወ")).setEnabled(YchIv6N09BaWPEj4tieAnluKZrRXT)
		for gMmB3iopS0ZXrOFewhcxt in range(NSudqlOzja,HdFhWUe2bNoCMA0.buttonstimeout+NSudqlOzja):
			b8bLFaejUB.sleep(NSudqlOzja)
			ZZS3nVlGI4xosPjXCwDygBm = int(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠱࠱࠲ዉ")*gMmB3iopS0ZXrOFewhcxt/HdFhWUe2bNoCMA0.buttonstimeout)
			HdFhWUe2bNoCMA0.SkhfG51W7Pi0bZ8jELawmAtRzTr6Vl(ZZS3nVlGI4xosPjXCwDygBm)
			if HdFhWUe2bNoCMA0.choiceID>NxXMrsTC5FniYuRBOK8(u"࠱ዊ"): break
		HdFhWUe2bNoCMA0.qW0PXcHxyFSLRhN8oTDnCBdzu()
	def WoST0bqreDlvp(HdFhWUe2bNoCMA0):
		if HdFhWUe2bNoCMA0.closetimeout:
			HdFhWUe2bNoCMA0.th2 = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=HdFhWUe2bNoCMA0.Xl6PuvTb0hn1geLxiC8JcVjIB,args=())
			HdFhWUe2bNoCMA0.th2.start()
		else: HdFhWUe2bNoCMA0.qW0PXcHxyFSLRhN8oTDnCBdzu()
	def Xl6PuvTb0hn1geLxiC8JcVjIB(HdFhWUe2bNoCMA0):
		HdFhWUe2bNoCMA0.getControl(w2vjZmdJuY7c(u"࠻࠳࠶࠵ዋ")).setEnabled(YchIv6N09BaWPEj4tieAnluKZrRXT)
		b8bLFaejUB.sleep(HdFhWUe2bNoCMA0.buttonstimeout)
		for gMmB3iopS0ZXrOFewhcxt in range(HdFhWUe2bNoCMA0.closetimeout-NSudqlOzja,-NSudqlOzja,-NSudqlOzja):
			b8bLFaejUB.sleep(NSudqlOzja)
			ZZS3nVlGI4xosPjXCwDygBm = int(ehfEsaiJBSvbcULtNPVgykA2(u"࠴࠴࠵ዌ")*gMmB3iopS0ZXrOFewhcxt/HdFhWUe2bNoCMA0.closetimeout)
			HdFhWUe2bNoCMA0.SkhfG51W7Pi0bZ8jELawmAtRzTr6Vl(ZZS3nVlGI4xosPjXCwDygBm)
			if HdFhWUe2bNoCMA0.choiceID>x1Oa8bBf36EwsLMirtFc: break
		if HdFhWUe2bNoCMA0.closetimeout>x1Oa8bBf36EwsLMirtFc: HdFhWUe2bNoCMA0.choiceID = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠵࠵ው")
		HdFhWUe2bNoCMA0.opVbMj6LnO()
	def SkhfG51W7Pi0bZ8jELawmAtRzTr6Vl(HdFhWUe2bNoCMA0,ZZS3nVlGI4xosPjXCwDygBm):
		HdFhWUe2bNoCMA0.precent = ZZS3nVlGI4xosPjXCwDygBm
		HdFhWUe2bNoCMA0.getControl(LTN6DPEmrwehtZMy(u"࠾࠶࠲࠱ዎ")).setPercent(HdFhWUe2bNoCMA0.precent)
	def qW0PXcHxyFSLRhN8oTDnCBdzu(HdFhWUe2bNoCMA0):
		if HdFhWUe2bNoCMA0.button0: HdFhWUe2bNoCMA0.getControl(CKUiyEe28zsZ(u"࠿࠰࠲࠲ዏ")).setEnabled(YchIv6N09BaWPEj4tieAnluKZrRXT)
		if HdFhWUe2bNoCMA0.button1: HdFhWUe2bNoCMA0.getControl(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠹࠱࠳࠴ዐ")).setEnabled(YchIv6N09BaWPEj4tieAnluKZrRXT)
		if HdFhWUe2bNoCMA0.button2: HdFhWUe2bNoCMA0.getControl(HkiMU0QrdzW3l6gwnT(u"࠺࠲࠴࠶ዑ")).setEnabled(YchIv6N09BaWPEj4tieAnluKZrRXT)
	def opVbMj6LnO(HdFhWUe2bNoCMA0):
		HdFhWUe2bNoCMA0.close()
		try: RRydns1CErYlIhwSx7.remove(HdFhWUe2bNoCMA0.image_filename)
		except: pass
class NLZqC35dHIcYei6Tpr4wms():
	def __init__(HdFhWUe2bNoCMA0,showDialogs=rDceXBpHkfVUYRJ3tIx95Z,logErrors=YchIv6N09BaWPEj4tieAnluKZrRXT):
		HdFhWUe2bNoCMA0.showDialogs = showDialogs
		HdFhWUe2bNoCMA0.logErrors = logErrors
		HdFhWUe2bNoCMA0.finishedLIST,HdFhWUe2bNoCMA0.failedLIST = [],[]
		HdFhWUe2bNoCMA0.statusDICT,HdFhWUe2bNoCMA0.resultsDICT = {},{}
		HdFhWUe2bNoCMA0.processesLIST = []
		HdFhWUe2bNoCMA0.starttimeDICT,HdFhWUe2bNoCMA0.finishtimeDICT,HdFhWUe2bNoCMA0.elpasedtimeDICT = {},{},{}
	def vvsdh9VR7afIEJOWec3KoZUy(HdFhWUe2bNoCMA0,vvTGOs9zmKUeP35iILrC4,EBLD1GdcWPmk523zxhwIye6VRv,*aargs):
		vvTGOs9zmKUeP35iILrC4 = str(vvTGOs9zmKUeP35iILrC4)
		HdFhWUe2bNoCMA0.statusDICT[vvTGOs9zmKUeP35iILrC4] = f90fGrlSEObDsuiA3U(u"ࠬࡸࡵ࡯ࡰ࡬ࡲ࡬࠭೻")
		if HdFhWUe2bNoCMA0.showDialogs: dqKGMYgJxSF8Ub1kotlsP936Ww7B(eHdDoxhJCEPMZFVa2fg,vvTGOs9zmKUeP35iILrC4)
		MX7jv1alGO3chAgBzTSCIqVpk = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=HdFhWUe2bNoCMA0.fDmtX4dCEk8eLGKwFR,args=(vvTGOs9zmKUeP35iILrC4,EBLD1GdcWPmk523zxhwIye6VRv,aargs))
		HdFhWUe2bNoCMA0.processesLIST.append(MX7jv1alGO3chAgBzTSCIqVpk)
		return MX7jv1alGO3chAgBzTSCIqVpk
	def zuhp2kCsanALdD(HdFhWUe2bNoCMA0,vvTGOs9zmKUeP35iILrC4,EBLD1GdcWPmk523zxhwIye6VRv,*aargs):
		MX7jv1alGO3chAgBzTSCIqVpk = HdFhWUe2bNoCMA0.vvsdh9VR7afIEJOWec3KoZUy(vvTGOs9zmKUeP35iILrC4,EBLD1GdcWPmk523zxhwIye6VRv,*aargs)
		MX7jv1alGO3chAgBzTSCIqVpk.start()
	def fDmtX4dCEk8eLGKwFR(HdFhWUe2bNoCMA0,vvTGOs9zmKUeP35iILrC4,EBLD1GdcWPmk523zxhwIye6VRv,aargs):
		vvTGOs9zmKUeP35iILrC4 = str(vvTGOs9zmKUeP35iILrC4)
		HdFhWUe2bNoCMA0.starttimeDICT[vvTGOs9zmKUeP35iILrC4] = b8bLFaejUB.time()
		try:
			HdFhWUe2bNoCMA0.resultsDICT[vvTGOs9zmKUeP35iILrC4] = EBLD1GdcWPmk523zxhwIye6VRv(*aargs)
			if ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧ೼") in str(EBLD1GdcWPmk523zxhwIye6VRv) and not HdFhWUe2bNoCMA0.resultsDICT[vvTGOs9zmKUeP35iILrC4].succeeded: ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
			HdFhWUe2bNoCMA0.finishedLIST.append(vvTGOs9zmKUeP35iILrC4)
			HdFhWUe2bNoCMA0.statusDICT[vvTGOs9zmKUeP35iILrC4] = KW5bYS20wTF1LyCs9(u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩ೽")
		except Exception as IsHj3gPMl06:
			if HdFhWUe2bNoCMA0.logErrors:
				pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
				if pw9fgsSRmnKId80YbU1PA!=KQ3sCe9Pzh(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫ೾"): jjO4Xf7GBW8Dx2HR0tdP.stderr.write(pw9fgsSRmnKId80YbU1PA)
			HdFhWUe2bNoCMA0.failedLIST.append(vvTGOs9zmKUeP35iILrC4)
			HdFhWUe2bNoCMA0.statusDICT[vvTGOs9zmKUeP35iILrC4] = w2vjZmdJuY7c(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ೿")
		HdFhWUe2bNoCMA0.finishtimeDICT[vvTGOs9zmKUeP35iILrC4] = b8bLFaejUB.time()
		HdFhWUe2bNoCMA0.elpasedtimeDICT[vvTGOs9zmKUeP35iILrC4] = HdFhWUe2bNoCMA0.finishtimeDICT[vvTGOs9zmKUeP35iILrC4] - HdFhWUe2bNoCMA0.starttimeDICT[vvTGOs9zmKUeP35iILrC4]
	def NUJvdXjoBcy4HVPSEiwh(HdFhWUe2bNoCMA0):
		for LnC36HmzOpYWreP1yVo7IQgKtu in HdFhWUe2bNoCMA0.processesLIST:
			LnC36HmzOpYWreP1yVo7IQgKtu.start()
	def veoCrXsKJSu3Il85nmpgqyafjDz7wO(HdFhWUe2bNoCMA0):
		while eNEhtuoi9gK8JaTpIXj(u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠫഀ") in list(HdFhWUe2bNoCMA0.statusDICT.values()): b8bLFaejUB.sleep(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳ዒ"))
def qmxJj9IPRgL4FwaB1SH7lVY6u3():
	if not tJWbQ0cyZoe: return eNEhtuoi9gK8JaTpIXj(u"ࠫࡓࡕ࡟ࡖࡒࡇࡅ࡙ࡋࠧഁ")
	try: RRydns1CErYlIhwSx7.makedirs(oX9h2wrQe5)
	except: pass
	drBy4Yqjl9fTPzRLKgktVbE = ietolwsjpIPK7Fr(u"ࠬࡌࡕࡍࡎࡢ࡙ࡕࡊࡁࡕࡇࠪം")
	gamul25dRi7Nz6 = [J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࠸࠯࠷࠱࠴ࠬഃ"),bP01xn84BiQN(u"ࠧ࠳࠲࠵࠵࠳࠷࠰࠯࠳࠼ࠫഄ"),EX25Y0l8ILvz7QcRC(u"ࠨ࠴࠳࠶࠶࠴࠱࠲࠰࠵࠸ࡦ࠭അ"),t3coAp06zvHrTl49bUVgx(u"ࠩ࠵࠴࠷࠷࠮࠲࠴࠱࠷࠵࠭ആ"),egY8Jti0smdLM3h1VQRSW(u"ࠪ࠶࠵࠸࠲࠯࠲࠵࠲࠵࠸ࠧഇ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠫ࠷࠶࠲࠳࠰࠴࠴࠳࠸࠲ࠨഈ"),CKUiyEe28zsZ(u"ࠬ࠸࠰࠳࠵࠱࠴࠸࠴࠰࠷ࠩഉ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࠲࠱࠴࠶࠲࠵࠻࠮࠲࠸ࠪഊ"),w2vjZmdJuY7c(u"ࠧ࠳࠲࠵࠷࠳࠶࠶࠯࠲࠹ࠫഋ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠨ࠴࠳࠶࠸࠴࠱࠱࠰࠵࠼ࠬഌ"),KQ3sCe9Pzh(u"ࠩ࠵࠴࠷࠺࠮࠱࠳࠱࠵࠹࠭഍"),f90fGrlSEObDsuiA3U(u"ࠪ࠶࠵࠸࠴࠯࠲࠺࠲࠷࠶ࠧഎ")]
	mMN45IBHa1 = gamul25dRi7Nz6[-NSudqlOzja]
	LGjmYz352wobuRxhgTZrVSK = rrT0wO5a2JDl4UmbiRcWhpjSCMoyd(mMN45IBHa1)
	FxO1KHoEDyGq9UrRT2Ytpcv = rrT0wO5a2JDl4UmbiRcWhpjSCMoyd(MCrWtwnF2TViZOD7z0pXgqI4)
	if FxO1KHoEDyGq9UrRT2Ytpcv>LGjmYz352wobuRxhgTZrVSK:
		drBy4Yqjl9fTPzRLKgktVbE = ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫഏ")
	return drBy4Yqjl9fTPzRLKgktVbE
def W2Q1Tm7IoUSvLEF5l():
	MWmxJXv1ekKZQ4hcsl9LF7I6 = x1Oa8bBf36EwsLMirtFc
	for LLFAhzJsub5,Cr9fechZPyT0bNxmzvRk,FefZKgxmYVLjkWN4yhod79 in RRydns1CErYlIhwSx7.walk(e8j3fyIi05dcPOpkmq,topdown=rDceXBpHkfVUYRJ3tIx95Z):
		MWmxJXv1ekKZQ4hcsl9LF7I6 += len(FefZKgxmYVLjkWN4yhod79)
	if MWmxJXv1ekKZQ4hcsl9LF7I6>LyOR7f69iA(u"࠹࠴࠵࠶ዓ"): ycgRbjNoPLQSnx(e8j3fyIi05dcPOpkmq,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
	return
def zlSqaMRcYWs(ssGzSv5CKWmpbITxfqjE6D4n0leo):
	global oLfID72TXPO5SkEnW
	global VtgEUvxaDeTMuPlwi3HAQchFpIOJ9,WuT0eE8LCKoP
	XB52unH19h6 = eHdDoxhJCEPMZFVa2fg
	if ssGzSv5CKWmpbITxfqjE6D4n0leo: XB52unH19h6 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡹࡴࡳࠩഐ"),ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ഑"),KQ3sCe9Pzh(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩഒ"))
	if not XB52unH19h6 and not oLfID72TXPO5SkEnW:
		FeTJrG4SkMf09iVys8A = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[NxXMrsTC5FniYuRBOK8(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨഓ")][t3coAp06zvHrTl49bUVgx(u"࠽ዔ")]
		zo8KfmNxYVlhGZ0A6bEM7igIa5 = {KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡸࡷࡪࡸࠧഔ"):ZylBO1ktRGvdJ0,I5bUBGpPXn0W6(u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫക"):MCrWtwnF2TViZOD7z0pXgqI4}
		qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,XugxFprC26zGM(u"ࠫࡕࡕࡓࡕࠩഖ"),FeTJrG4SkMf09iVys8A,zo8KfmNxYVlhGZ0A6bEM7igIa5,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡤࡖ࡙ࡕࡊࡒࡒࡤࡉࡏࡅࡇ࠰࠵ࡸࡺࠧഗ"))
		if qldY3LPe0pDiuyoM8vIH.succeeded:
			XB52unH19h6 = qldY3LPe0pDiuyoM8vIH.content
			CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩഘ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡆ࡚ࡗࡖࡆࡖ࡙ࡕࡊࡒࡒࡈࡕࡄࡆࠩങ"),XB52unH19h6,ICRfWub2vqlor0Q)
			oLfID72TXPO5SkEnW = YchIv6N09BaWPEj4tieAnluKZrRXT
	if XB52unH19h6:
		global NEW_SITESURLS,fhKnRUV6FBdvMZ0E8uTYt
		exec(XB52unH19h6,globals(),locals())
		VtgEUvxaDeTMuPlwi3HAQchFpIOJ9.update(NEW_SITESURLS)
		WuT0eE8LCKoP = fhKnRUV6FBdvMZ0E8uTYt
	return
def vxiKO2enuRVHYW3dT():
	zrvPLm8KV23EwRWiBk0s = qmxJj9IPRgL4FwaB1SH7lVY6u3()
	if zrvPLm8KV23EwRWiBk0s==Cp6c5tZe8I0PxnAW(u"ࠨࡕࡌࡑࡕࡒࡅࡠࡗࡓࡈࡆ࡚ࡅࠨച"): vR9cOpMtk51j(iwIlVQsgYezu,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࠱ࡠࡹࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶࠤ࡚ࡶࡤࡢࡶࡨࠤ࡙ࡿࡰࡦ࠼ࠣࠤࡘࡏࡍࡑࡎࡈࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨഛ")+H4ys6we0jDn+KQ3sCe9Pzh(u"ࠪࠤࡢ࠭ജ"))
	else: vR9cOpMtk51j(iwIlVQsgYezu,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡆࡖࡎࡏࠤ࡚ࡖࡄࡂࡖࡈࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨഝ")+H4ys6we0jDn+bP01xn84BiQN(u"ࠬࠦ࡝ࠨഞ"))
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩട"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧห็ࠣฮาี๊ฬࠢส่อืๆศ็ฯࠤๆ๐ࠠอ้สึ่ࡢ࡮ฦๆ์ࠤฬ๊ลึัสีࠥืโๆ࠼࡟ࡲࡡࡴࠧഠ")+MCrWtwnF2TViZOD7z0pXgqI4)
	dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫഡ"),KQ3sCe9Pzh(u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬഢ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,NxXMrsTC5FniYuRBOK8(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ണ"),I5bUBGpPXn0W6(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧത"))
	k5L96NenKBwpSYWv(pyifuNFdxe,LyOR7f69iA(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࠨഥ"),ietolwsjpIPK7Fr(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧദ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,w2vjZmdJuY7c(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪധ"),I5bUBGpPXn0W6(u"ࠨࡈࡒࡖ࡜ࡇࡒࡅࡕࠪന"))
	k5L96NenKBwpSYWv(pyifuNFdxe,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬഩ"),f90fGrlSEObDsuiA3U(u"ࠪࡗࡎ࡚ࡅࡔࡡࡑࡅࡒࡋࡓࠨപ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,f90fGrlSEObDsuiA3U(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧഫ"),KW5bYS20wTF1LyCs9(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪബ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩഭ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭മ"))
	MoO74hKeqm8fFka.setSetting(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡳࡸࡺࡡࠨയ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡪࡦࡨࡲࡢ࡭ࡤࠫര"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭റ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧല"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(f90fGrlSEObDsuiA3U(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨള"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(Cp6c5tZe8I0PxnAW(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠳ࠩഴ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡢࡸ࠱ࡴࡪࡸࡩࡰࡦ࠱࡭ࡳ࡬࡯ࡴࠩവ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹ࠭ശ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩഷ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(t3coAp06zvHrTl49bUVgx(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰࡯ࡳࡳ࡭ࠧസ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬഹ"),eHdDoxhJCEPMZFVa2fg)
	MoO74hKeqm8fFka.setSetting(egY8Jti0smdLM3h1VQRSW(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧഺ"),eHdDoxhJCEPMZFVa2fg)
	k5L96NenKBwpSYWv(pyifuNFdxe,KQ3sCe9Pzh(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ഻࡙ࠧ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜഼ࠧ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧഽ"))
	k5L96NenKBwpSYWv(pyifuNFdxe,NxXMrsTC5FniYuRBOK8(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࡣࡘ࡚ࡁࡕࡗࡖࠫാ"))
	wJ0l2uCDMF8IiEzsvykhP(rDceXBpHkfVUYRJ3tIx95Z)
	import YmtfK6LolI
	YmtfK6LolI.bo8mpKfd5eaERB32vGz(YchIv6N09BaWPEj4tieAnluKZrRXT)
	if zrvPLm8KV23EwRWiBk0s==KQ3sCe9Pzh(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪി"):
		nwXsRUtrkb4gDOMV8N6ZHTl(YchIv6N09BaWPEj4tieAnluKZrRXT,[pyifuNFdxe])
	else:
		nwXsRUtrkb4gDOMV8N6ZHTl(rDceXBpHkfVUYRJ3tIx95Z,[])
		YmtfK6LolI.Zfw4yEWTN5ImUb1()
		YmtfK6LolI.oIUetMrjGswW21QNiHSJgK3mnCd0D(S8i3sBYoHWdTURpAgN(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫീ"),rDceXBpHkfVUYRJ3tIx95Z)
		YmtfK6LolI.oIUetMrjGswW21QNiHSJgK3mnCd0D(bP01xn84BiQN(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨു"),rDceXBpHkfVUYRJ3tIx95Z)
		YmtfK6LolI.BLz9sPWkqKcpnaEJhiyT8d3gojY7mA(rDceXBpHkfVUYRJ3tIx95Z)
		try:
			o3ceiqfhUCA5mNP = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,S8i3sBYoHWdTURpAgN(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨൂ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫൃ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡴࡨࡷࡴࡲࡶࡦࡷࡵࡰࠬൄ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ൅"))
			BBzVAtKaL8TPO3d4WX9xNfSo = Z1ZPVbLUsHgxd7X.Addon(id=LyOR7f69iA(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧെ"))
			BBzVAtKaL8TPO3d4WX9xNfSo.setSetting(jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡦࡼ࠮ࡢࡷࡷࡳࡤࡶࡩࡤ࡭ࠪേ"),bP01xn84BiQN(u"ࠬࡌࡡ࡭ࡵࡨࠫൈ"))
		except: pass
		try:
			o3ceiqfhUCA5mNP = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ൉"),bP01xn84BiQN(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫൊ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯࡯ࡲࡨࡺࡲࡥ࠯ࡻࡷ࠱ࡩࡲࡰࠨോ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨൌ"))
			BBzVAtKaL8TPO3d4WX9xNfSo = Z1ZPVbLUsHgxd7X.Addon(id=S8i3sBYoHWdTURpAgN(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡹ࠳ࡤ࡭ࡲ്ࠪ"))
			BBzVAtKaL8TPO3d4WX9xNfSo.setSetting(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡦࡼ࠮ࡷ࡫ࡧࡩࡴࡥࡱࡶࡣ࡯࡭ࡹࡿࠧൎ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࠹ࠧ൏"))
		except: pass
		try:
			o3ceiqfhUCA5mNP = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ൐"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫ൑"),bP01xn84BiQN(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ൒"),t3coAp06zvHrTl49bUVgx(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨ൓"))
			BBzVAtKaL8TPO3d4WX9xNfSo = Z1ZPVbLUsHgxd7X.Addon(id=LyOR7f69iA(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪൔ"))
			BBzVAtKaL8TPO3d4WX9xNfSo.setSetting(NxXMrsTC5FniYuRBOK8(u"ࠫࡦࡼ࠮ࡔࡖࡕࡉࡆࡓࡓࡆࡎࡈࡇ࡙ࡏࡏࡏࠩൕ"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬ࠸ࠧൖ"))
		except: pass
	KhGpZcMqsnrbv = ssIBAWh7QmzOoXqk8w(s4FvMNOledIt)
	KhGpZcMqsnrbv = ssIBAWh7QmzOoXqk8w(CCknZTXVNbG9Px0ds1hpQSMKB)
	YmtfK6LolI.jIr2tJV5b1xG3RueTMD9NcBdz4k(rDceXBpHkfVUYRJ3tIx95Z)
	MoO74hKeqm8fFka.setSetting(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡡࡷ࠰ࡹࡩࡷࡹࡩࡰࡰࠪൗ"),MCrWtwnF2TViZOD7z0pXgqI4)
	AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def I26IRUE53zjd9qbA():
	y8rplSunYEmKa0e3M5HOJoNBc4hD = txpHLlmaGzNqcTYWPoeS3MK5F8k(MoO74hKeqm8fFka.getSetting(w2vjZmdJuY7c(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬ൘")))
	y8rplSunYEmKa0e3M5HOJoNBc4hD = x1Oa8bBf36EwsLMirtFc if not y8rplSunYEmKa0e3M5HOJoNBc4hD else int(y8rplSunYEmKa0e3M5HOJoNBc4hD)
	if not y8rplSunYEmKa0e3M5HOJoNBc4hD or not x1Oa8bBf36EwsLMirtFc<=a8HLTkO2ns49yGNgiroS-y8rplSunYEmKa0e3M5HOJoNBc4hD<=srU0Sl1oOC29FB6gHTYX:
		MoO74hKeqm8fFka.setSetting(eNEhtuoi9gK8JaTpIXj(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡴࡪࡲࡶࡹ࠭൙"),VarSZWbo4B6y3htcxuifmD9FYqnLvp(a8HLTkO2ns49yGNgiroS))
		RD8m0SxQnJ(ZAl2gePWifs3IXG)
		hvmy7AolBenj94zsXZx25tQgqPiY1 = txpHLlmaGzNqcTYWPoeS3MK5F8k(MoO74hKeqm8fFka.getSetting(ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡴࡨ࡫ࡺࡲࡡࡳࠩ൚")))
		hvmy7AolBenj94zsXZx25tQgqPiY1 = x1Oa8bBf36EwsLMirtFc if not hvmy7AolBenj94zsXZx25tQgqPiY1 else int(hvmy7AolBenj94zsXZx25tQgqPiY1)
		if not hvmy7AolBenj94zsXZx25tQgqPiY1 or not x1Oa8bBf36EwsLMirtFc<=a8HLTkO2ns49yGNgiroS-hvmy7AolBenj94zsXZx25tQgqPiY1<=bbfreYhcgwZlKEGVx7zRU:
			MoO74hKeqm8fFka.setSetting(LyOR7f69iA(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪ൛"),VarSZWbo4B6y3htcxuifmD9FYqnLvp(a8HLTkO2ns49yGNgiroS))
			zlSqaMRcYWs(rDceXBpHkfVUYRJ3tIx95Z)
		WrBxeibNuPQR0cZaJojKUtnmk4S = txpHLlmaGzNqcTYWPoeS3MK5F8k(MoO74hKeqm8fFka.getSetting(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨ൜")))
		WrBxeibNuPQR0cZaJojKUtnmk4S = x1Oa8bBf36EwsLMirtFc if not WrBxeibNuPQR0cZaJojKUtnmk4S else int(WrBxeibNuPQR0cZaJojKUtnmk4S)
		if not WrBxeibNuPQR0cZaJojKUtnmk4S or not x1Oa8bBf36EwsLMirtFc<=a8HLTkO2ns49yGNgiroS-WrBxeibNuPQR0cZaJojKUtnmk4S<=c4cPSX2jOIm8KCQlfW5wM:
			MoO74hKeqm8fFka.setSetting(LyOR7f69iA(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩ൝"),VarSZWbo4B6y3htcxuifmD9FYqnLvp(a8HLTkO2ns49yGNgiroS))
			MX7jv1alGO3chAgBzTSCIqVpk = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=W2Q1Tm7IoUSvLEF5l)
			MX7jv1alGO3chAgBzTSCIqVpk.start()
	lhSETtsVK0ncOvy6IYG7WMbj2xwq = txpHLlmaGzNqcTYWPoeS3MK5F8k(MoO74hKeqm8fFka.getSetting(S8i3sBYoHWdTURpAgN(u"࠭ࡡࡷ࠰ࡳࡩࡷ࡯࡯ࡥ࠰࡬ࡲ࡫ࡵࡳࠨ൞")))
	lhSETtsVK0ncOvy6IYG7WMbj2xwq = x1Oa8bBf36EwsLMirtFc if not lhSETtsVK0ncOvy6IYG7WMbj2xwq else int(lhSETtsVK0ncOvy6IYG7WMbj2xwq)
	Lfw1QjSbW3UHqu = txpHLlmaGzNqcTYWPoeS3MK5F8k(MoO74hKeqm8fFka.getSetting(egY8Jti0smdLM3h1VQRSW(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩൟ")))
	Lfw1QjSbW3UHqu = x1Oa8bBf36EwsLMirtFc if not Lfw1QjSbW3UHqu else int(Lfw1QjSbW3UHqu)
	if not lhSETtsVK0ncOvy6IYG7WMbj2xwq or not Lfw1QjSbW3UHqu or not x1Oa8bBf36EwsLMirtFc<=a8HLTkO2ns49yGNgiroS-Lfw1QjSbW3UHqu<=lhSETtsVK0ncOvy6IYG7WMbj2xwq:
		BGIFzrSY3d()
	return
def BGIFzrSY3d():
	MVKCY1T6FsP = NSudqlOzja
	WDbSkcMfmovYAg0xs = rDceXBpHkfVUYRJ3tIx95Z if EDNRGMfBk3H2FAtQI578ubU6cXw0hn else YchIv6N09BaWPEj4tieAnluKZrRXT
	if WDbSkcMfmovYAg0xs:
		pg2HKT7OyfiMWL6 = K89FakvRdrtXhmnDE7O(YchIv6N09BaWPEj4tieAnluKZrRXT)
		if len(pg2HKT7OyfiMWL6)>NSudqlOzja:
			vR9cOpMtk51j(iwIlVQsgYezu,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨ࠰࡟ࡸࡘ࡮࡯ࡸ࡫ࡱ࡫ࠥࡗࡵࡦࡵࡷ࡭ࡴࡴࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫൠ")+H4ys6we0jDn+KW5bYS20wTF1LyCs9(u"ࠩࠣࡡࠬൡ"))
			vvTGOs9zmKUeP35iILrC4,pcG48moFZkRT1Iz7DJaYOqtB,YSrPiRzTntg3kwsH86xvm0oZf9,Geo8WC6xHmhPAwQMXpZd,vR5ZcIituWPYQLwyeab2oOsg,RCrFOws8DlH6 = pg2HKT7OyfiMWL6[x1Oa8bBf36EwsLMirtFc]
			yjD0T8Ye32coaKrR5Z679,l91ODotRve30i64 = Geo8WC6xHmhPAwQMXpZd.split(KW5bYS20wTF1LyCs9(u"ࠪࡠࡳࡁ࠻ࠨൢ"))
			del pg2HKT7OyfiMWL6[x1Oa8bBf36EwsLMirtFc]
			RRVq8sgU3SKPCyJr7W = GljITSOwLKW36.sample(pg2HKT7OyfiMWL6,NSudqlOzja)
			vvTGOs9zmKUeP35iILrC4,pcG48moFZkRT1Iz7DJaYOqtB,YSrPiRzTntg3kwsH86xvm0oZf9,Geo8WC6xHmhPAwQMXpZd,vR5ZcIituWPYQLwyeab2oOsg,RCrFOws8DlH6 = RRVq8sgU3SKPCyJr7W[x1Oa8bBf36EwsLMirtFc]
			YSrPiRzTntg3kwsH86xvm0oZf9 = wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡠࡘࡔࡍ࡟ࠪൣ")+OR97bMGecfgDCqux3YdAZ6y+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࠦ࠺ࠡࠩ൤")+vvTGOs9zmKUeP35iILrC4+Nat0Dx9puRUWCsgz6JyFhY3+YSrPiRzTntg3kwsH86xvm0oZf9
			vR5ZcIituWPYQLwyeab2oOsg = RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ลาีส่ࠥืำศๆฬࠤ้๊ๅษำ่ะࠬ൥")
			ppNt754RaZ2COG = TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧศๆอฬึ฿วหࠩ൦")
			button0,button1 = Geo8WC6xHmhPAwQMXpZd,vR5ZcIituWPYQLwyeab2oOsg
			qcWnziRSuQpBdX50DsMV1lH7htvUmb = [button0,button1,ppNt754RaZ2COG]
			AJyVPgZ29YOGjw = NSudqlOzja if wwNbXe9taWdRiFHzyB2MZ else KQ3sCe9Pzh(u"࠶࠶ዕ")
			jF1DqR2Y3VrIShwBeOpco = -w2vjZmdJuY7c(u"࠿ዖ")
			while jF1DqR2Y3VrIShwBeOpco<x1Oa8bBf36EwsLMirtFc:
				PjrKIMYZOE = GljITSOwLKW36.sample(qcWnziRSuQpBdX50DsMV1lH7htvUmb,bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1)
				jF1DqR2Y3VrIShwBeOpco = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,PjrKIMYZOE[x1Oa8bBf36EwsLMirtFc],PjrKIMYZOE[NSudqlOzja],PjrKIMYZOE[FB0pIzAoK8wqgd3UiY5],yjD0T8Ye32coaKrR5Z679,YSrPiRzTntg3kwsH86xvm0oZf9,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ൧"),AJyVPgZ29YOGjw,I5bUBGpPXn0W6(u"࠶࠱዗"))
				if jF1DqR2Y3VrIShwBeOpco==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠲࠲ዘ"): break
				import YmtfK6LolI
				if jF1DqR2Y3VrIShwBeOpco>=x1Oa8bBf36EwsLMirtFc and PjrKIMYZOE[jF1DqR2Y3VrIShwBeOpco]==qcWnziRSuQpBdX50DsMV1lH7htvUmb[NSudqlOzja]:
					YmtfK6LolI.kExW7f8PlyVi34NbOYXd()
					if jF1DqR2Y3VrIShwBeOpco>=x1Oa8bBf36EwsLMirtFc: jF1DqR2Y3VrIShwBeOpco = -iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠻ዙ")
				elif jF1DqR2Y3VrIShwBeOpco>=x1Oa8bBf36EwsLMirtFc and PjrKIMYZOE[jF1DqR2Y3VrIShwBeOpco]==qcWnziRSuQpBdX50DsMV1lH7htvUmb[FB0pIzAoK8wqgd3UiY5]:
					YmtfK6LolI.JaCYQh0Kf29q7LbmT5geG(rDceXBpHkfVUYRJ3tIx95Z)
				if jF1DqR2Y3VrIShwBeOpco==-NSudqlOzja: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ൨"),OR97bMGecfgDCqux3YdAZ6y+wY1p9mP03S8drbcH64t5WQkv(u"ࠪาึ๎ฬࠡะฺวࠬ൩")+Nat0Dx9puRUWCsgz6JyFhY3+bP01xn84BiQN(u"ࠫࡡࡴࠠๅๆัีําࠠศๆุั๏ำࠠฤะอีࠥ๎วฮั้๋ࠣࠦวๅลฯ์อฯࠠศๆ่ฮํ็ัสࠩ൪"))
			MVKCY1T6FsP = NSudqlOzja
		else: MVKCY1T6FsP = x1Oa8bBf36EwsLMirtFc
	MoO74hKeqm8fFka.setSetting(XugxFprC26zGM(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ൫"),VarSZWbo4B6y3htcxuifmD9FYqnLvp(a8HLTkO2ns49yGNgiroS))
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,f90fGrlSEObDsuiA3U(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ൬"),LyOR7f69iA(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬ൭"),MVKCY1T6FsP,ICRfWub2vqlor0Q)
	return
def ou9xEXbMlN8zgmah(fW4iNwld6COELJ10,d8De716ZlA2,Tv4kxUQzM86cK1nCmP,zVg9Tax3sjPSAvRJF7XHGy5hK8,u1INEBX5oqPx,zz3BeUfyNow7kZ0nvtxhKqWr4P,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA,nP6tjJH5O17yGvYB38IaEVb,jZHGcWxXpdVO038fnt,gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX):
	aayCQXxFgAKjY3Zq = int(nP6tjJH5O17yGvYB38IaEVb%HkiMU0QrdzW3l6gwnT(u"࠴࠴ዚ"))
	JvfrAebh43x5cTipPjdLF0s17tO = int(nP6tjJH5O17yGvYB38IaEVb/EX25Y0l8ILvz7QcRC(u"࠵࠵ዛ"))
	kytUo7ix2uZFWgbT5DJQ = fW4iNwld6COELJ10,d8De716ZlA2,Tv4kxUQzM86cK1nCmP,zVg9Tax3sjPSAvRJF7XHGy5hK8,u1INEBX5oqPx,zz3BeUfyNow7kZ0nvtxhKqWr4P,oh8Z06rUdqJ,eHdDoxhJCEPMZFVa2fg,ruWSoIZkeKA
	Nfldwbam6eUnIK4EukgBPDGAjRrso = MoO74hKeqm8fFka.getSetting(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨ൮"))
	if not Nfldwbam6eUnIK4EukgBPDGAjRrso: MoO74hKeqm8fFka.setSetting(S8i3sBYoHWdTURpAgN(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡳࡥ࡯ࡷࡶࡧࡦࡩࡨࡦࠩ൯"),KQ3sCe9Pzh(u"ࠪࡅ࡚࡚ࡏࠨ൰"))
	hy985bf3gkpaz2Q076dvAoDjFxi = MoO74hKeqm8fFka.getSetting(LTN6DPEmrwehtZMy(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ൱"))
	wEiDnMUNsWC = O8pF1bNVh2BTZDAawLJmyXul75jfk(jZHGcWxXpdVO038fnt)
	GRdMmxPqtcES = [x1Oa8bBf36EwsLMirtFc,I5bUBGpPXn0W6(u"࠷࠵ዝ"),CKUiyEe28zsZ(u"࠱࠸ዞ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠲࠻ዟ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠷࠼ዜ"),Cp6c5tZe8I0PxnAW(u"࠷࠹ዢ"),XugxFprC26zGM(u"࠷࠳ዠ"),w2vjZmdJuY7c(u"࠸࠷ዡ")]
	mksGWzhyDRpauj6XNUPJL9gf = JvfrAebh43x5cTipPjdLF0s17tO not in GRdMmxPqtcES
	bb9xUv3EHwgosFYnJI0XDk7r = JvfrAebh43x5cTipPjdLF0s17tO in [J7divaGOCgq2SLfXpDzZYN58wc(u"࠳࠵ዦ"),XugxFprC26zGM(u"࠷࠾ዣ"),eNEhtuoi9gK8JaTpIXj(u"࠷࠲ዥ"),NxXMrsTC5FniYuRBOK8(u"࠽࠲ዤ")]
	s5bFvKnmRTrEw = nP6tjJH5O17yGvYB38IaEVb in [I5bUBGpPXn0W6(u"࠵࠺࠺የ"),LyOR7f69iA(u"࠴࠺࠴ዧ")]
	MM1zgeJDN4TBi83thwKLW = (mksGWzhyDRpauj6XNUPJL9gf or bb9xUv3EHwgosFYnJI0XDk7r) and not s5bFvKnmRTrEw
	NaxyTjqSu0C7V89iFvGrl = hy985bf3gkpaz2Q076dvAoDjFxi!=GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬ൲") and (hy985bf3gkpaz2Q076dvAoDjFxi or not YvJZXDaqbN)
	gX0GsbKO6Y = Cp6c5tZe8I0PxnAW(u"࠭ࡴࡺࡲࡨࡁࠬ൳") in hy985bf3gkpaz2Q076dvAoDjFxi
	rAnWqyKwHE = nP6tjJH5O17yGvYB38IaEVb in [Cp6c5tZe8I0PxnAW(u"࠱࠷࠳ዳ"),EX25Y0l8ILvz7QcRC(u"࠲࠸࠵ዴ"),I5bUBGpPXn0W6(u"࠳࠹࠷ድ"),S8i3sBYoHWdTURpAgN(u"࠴࠺࠹ዯ"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠵࠻࠻ደ"),egY8Jti0smdLM3h1VQRSW(u"࠶࠼࠶ዱ"),wY1p9mP03S8drbcH64t5WQkv(u"࠷࠶࠸ዲ"),w2vjZmdJuY7c(u"࠳࠹࠼ዮ"),KW5bYS20wTF1LyCs9(u"࠽࠶࠲ያ"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠻࠻࠸ዩ"),wY1p9mP03S8drbcH64t5WQkv(u"࠼࠼࠳ዪ"),Cp6c5tZe8I0PxnAW(u"࠷࠷࠶ዬ"),RqLvTrID0yMVeClpYcnZ16i3X(u"࠸࠸࠸ይ")]
	ZZG8yFCkvXnPTgR6Jc = aayCQXxFgAKjY3Zq==w2vjZmdJuY7c(u"࠼ዶ") or nP6tjJH5O17yGvYB38IaEVb in [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠶࠺࠵ዸ"),wY1p9mP03S8drbcH64t5WQkv(u"࠵࠲࠸ዺ"),egY8Jti0smdLM3h1VQRSW(u"࠻࠲࠴ዹ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠸࠺ዷ")]
	ey0XfhctYk = not rAnWqyKwHE
	HPQIN8UfeDvqZ = not ZZG8yFCkvXnPTgR6Jc
	bC6NfOdhAvzasK2nM0c = wEiDnMUNsWC in [eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧ࠯࠰ࠪ൴")]
	slD6JjBf3wha4YAVN7Wi8 = bC6NfOdhAvzasK2nM0c or ey0XfhctYk
	ZfMTswam9cIdB7lWviVune = bC6NfOdhAvzasK2nM0c or HPQIN8UfeDvqZ or gX0GsbKO6Y
	FjlQGiXLakWPN4MyRchAortn9S8s = nP6tjJH5O17yGvYB38IaEVb not in [dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠷࠼࠰ዿ"),KW5bYS20wTF1LyCs9(u"࠳࠸࠴ዻ"),egY8Jti0smdLM3h1VQRSW(u"࠸࠶࠶ጀ"),wY1p9mP03S8drbcH64t5WQkv(u"࠵࠻࠵ዽ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠵࠶࠴ዼ"),NxXMrsTC5FniYuRBOK8(u"࠹࠹࠶ዾ")]
	if Nfldwbam6eUnIK4EukgBPDGAjRrso==wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡕࡗࡓࡕ࠭൵"): r5TGDyRZaiAY9gl7bpqMv3t = ZZG8yFCkvXnPTgR6Jc or rAnWqyKwHE
	else: r5TGDyRZaiAY9gl7bpqMv3t = YchIv6N09BaWPEj4tieAnluKZrRXT
	fGYcAvgd93 = JvfrAebh43x5cTipPjdLF0s17tO in [iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠸࠶ጂ"),CKUiyEe28zsZ(u"࠷࠶ጁ")]
	wIHBpP5gUboQSJfys4mY0FderNOk = nP6tjJH5O17yGvYB38IaEVb in [CKUiyEe28zsZ(u"࠴࠻࠴ጃ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠺࠶࠵ጄ")]
	fv8UnxMXEzp2PqdQ7sh0HITkyRGN = not fGYcAvgd93 and not wIHBpP5gUboQSJfys4mY0FderNOk
	g0cXdupRosCEH4Yjq7vV = slD6JjBf3wha4YAVN7Wi8 and ZfMTswam9cIdB7lWviVune and FjlQGiXLakWPN4MyRchAortn9S8s and r5TGDyRZaiAY9gl7bpqMv3t and fv8UnxMXEzp2PqdQ7sh0HITkyRGN
	uzKhA6XFb3B450Vkyio1NreT = FjlQGiXLakWPN4MyRchAortn9S8s and r5TGDyRZaiAY9gl7bpqMv3t and fv8UnxMXEzp2PqdQ7sh0HITkyRGN
	lanbGdcVCStjLheY = uzKhA6XFb3B450Vkyio1NreT
	U9BwS27VhZxJc6boe3vY1MIWqRr = MoO74hKeqm8fFka.getSetting(KQ3sCe9Pzh(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡱࡴࡲࡺ࡮ࡪࡥࡳࠩ൶"))
	L6jB5TmSV2eGrE7I8hDipFf = MoO74hKeqm8fFka.getSetting(ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡥࡲࡨࡪ࠭൷"))
	kU1ZunWewoDl7LKjAyJiOmP8z5tMTf = rDceXBpHkfVUYRJ3tIx95Z
	if NaxyTjqSu0C7V89iFvGrl and g0cXdupRosCEH4Yjq7vV:
		vS7x6qYCUd = EeZHTwQUW2BuvJyIh(pyifuNFdxe,eNEhtuoi9gK8JaTpIXj(u"ࠫࡱ࡯ࡳࡵࠩ൸"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫ൹")+U9BwS27VhZxJc6boe3vY1MIWqRr+Cp6c5tZe8I0PxnAW(u"࠭࡟ࠨൺ")+L6jB5TmSV2eGrE7I8hDipFf,kytUo7ix2uZFWgbT5DJQ)
		if vS7x6qYCUd:
			vR9cOpMtk51j(eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧ࠯࡞ࡷࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩൻ")+U9BwS27VhZxJc6boe3vY1MIWqRr+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡡࠪർ")+L6jB5TmSV2eGrE7I8hDipFf+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࠣࠤࠥࡒ࡯ࡢࡦ࡬ࡲ࡬ࠦ࡭ࡦࡰࡸࠤ࡫ࡸ࡯࡮ࠢࡦࡥࡨ࡮ࡥࠨൽ"))
			if gX0GsbKO6Y:
				vIa4iofQ8uZjCU = []
				from Y2s1VRIgrT import k9CjzAbN6BhGZrisO45cp
				from GIBQakgutV import KKbRPTZDQAqiVfHyN,S31TlKtJyE4oU
				cc2hsbwVLgjB0PeWQM6 = k9CjzAbN6BhGZrisO45cp
				TLP21xHs3JnWSENMb6KqXFYAkfi = KKbRPTZDQAqiVfHyN()
				baGuhRUEwgqFSx9L1 = hy985bf3gkpaz2Q076dvAoDjFxi
				TPBO3QupYEav,WW29KQcstiM8PdhYb,gZhB9t2FO4Q,zzELDo68pNhHTWuRcn9F,BAVb7Izhvxd0GuRE,Wgt8KVsjDEvLi4coNwH,pnx7ywYHKeZuhtRBNPAjvS31LsqF0r,lr219Js5wuRibVfxyCX8En,iiKEAjmYVF = udpczrlynT3vQ98HhDYqgFw2SWo4MG(baGuhRUEwgqFSx9L1)
				KIhfd2y37DrYJkV89Qamc = TPBO3QupYEav,WW29KQcstiM8PdhYb,gZhB9t2FO4Q,zzELDo68pNhHTWuRcn9F,BAVb7Izhvxd0GuRE,Wgt8KVsjDEvLi4coNwH,pnx7ywYHKeZuhtRBNPAjvS31LsqF0r,eHdDoxhJCEPMZFVa2fg,iiKEAjmYVF
				for sQb2hGrFKm5CqJVkUvB in vS7x6qYCUd:
					gg4qEWyTeb8rlYMI0wC9PfvGZAt = sQb2hGrFKm5CqJVkUvB[I5bUBGpPXn0W6(u"ࠪࡱࡪࡴࡵࡊࡶࡨࡱࠬൾ")]
					if gg4qEWyTeb8rlYMI0wC9PfvGZAt==KIhfd2y37DrYJkV89Qamc or sQb2hGrFKm5CqJVkUvB[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡲࡵࡤࡦࠩൿ")] in [egY8Jti0smdLM3h1VQRSW(u"࠷࠼࠵ጆ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠶࠼࠶ጅ")]:
						sQb2hGrFKm5CqJVkUvB = OlBdSZrE3IyjiauAPLv(gg4qEWyTeb8rlYMI0wC9PfvGZAt,cc2hsbwVLgjB0PeWQM6,TLP21xHs3JnWSENMb6KqXFYAkfi)
						if sQb2hGrFKm5CqJVkUvB[jUcmHhgVvW0EdYOIfXeaDF(u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࠨ඀")]:
							d20sCREIk9b1DPOZ = S31TlKtJyE4oU(TLP21xHs3JnWSENMb6KqXFYAkfi,gg4qEWyTeb8rlYMI0wC9PfvGZAt,sQb2hGrFKm5CqJVkUvB[dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭࡮ࡦࡹࡳࡥࡹ࡮ࠧඁ")])
							sQb2hGrFKm5CqJVkUvB[Cp6c5tZe8I0PxnAW(u"ࠧࡤࡱࡱࡸࡪࡾࡴࡠ࡯ࡨࡲࡺ࠭ං")] = d20sCREIk9b1DPOZ+sQb2hGrFKm5CqJVkUvB[egY8Jti0smdLM3h1VQRSW(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧඃ")]
					vIa4iofQ8uZjCU.append(sQb2hGrFKm5CqJVkUvB)
				MoO74hKeqm8fFka.setSetting(KQ3sCe9Pzh(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭඄"),eHdDoxhJCEPMZFVa2fg)
				if fW4iNwld6COELJ10==ietolwsjpIPK7Fr(u"ࠪࡪࡴࡲࡤࡦࡴࠪඅ"): CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,f90fGrlSEObDsuiA3U(u"ࠫࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪආ")+U9BwS27VhZxJc6boe3vY1MIWqRr+HkiMU0QrdzW3l6gwnT(u"ࠬࡥࠧඇ")+L6jB5TmSV2eGrE7I8hDipFf,kytUo7ix2uZFWgbT5DJQ,vIa4iofQ8uZjCU,bbfreYhcgwZlKEGVx7zRU)
			else: vIa4iofQ8uZjCU = vS7x6qYCUd
			if fW4iNwld6COELJ10==S8i3sBYoHWdTURpAgN(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ඈ") and wEiDnMUNsWC!=XugxFprC26zGM(u"ࠧ࠯࠰ࠪඉ") and MM1zgeJDN4TBi83thwKLW: G0ejOgq24ovDFbNc()
			kU1ZunWewoDl7LKjAyJiOmP8z5tMTf = Dh6UHaz9c37Rf2lQ(kytUo7ix2uZFWgbT5DJQ,vIa4iofQ8uZjCU,gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX)
	elif fW4iNwld6COELJ10==CKUiyEe28zsZ(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨඊ") and hy985bf3gkpaz2Q076dvAoDjFxi==TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩඋ") and uzKhA6XFb3B450Vkyio1NreT:
		k5L96NenKBwpSYWv(pyifuNFdxe,XugxFprC26zGM(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩඌ")+U9BwS27VhZxJc6boe3vY1MIWqRr+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡤ࠭ඍ")+L6jB5TmSV2eGrE7I8hDipFf,kytUo7ix2uZFWgbT5DJQ)
	return kU1ZunWewoDl7LKjAyJiOmP8z5tMTf,hy985bf3gkpaz2Q076dvAoDjFxi,kytUo7ix2uZFWgbT5DJQ,wEiDnMUNsWC,MM1zgeJDN4TBi83thwKLW,lanbGdcVCStjLheY,U9BwS27VhZxJc6boe3vY1MIWqRr,L6jB5TmSV2eGrE7I8hDipFf
def ubskl1LEVzw(fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA,JqZhbG9Le2NQvziaPCx8wI,nP6tjJH5O17yGvYB38IaEVb,ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F):
	if ye7Oa1nIcm9FVxw3vjQsDuKb6 in [I5bUBGpPXn0W6(u"ࠬ࠷ࠧඎ"),EX25Y0l8ILvz7QcRC(u"࠭࠲ࠨඏ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧ࠴ࠩඐ"),NxXMrsTC5FniYuRBOK8(u"ࠨ࠶ࠪඑ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩ࠸ࠫඒ")] and SSN0rt6VGqc4fOnQijpb2F:
		import GIBQakgutV
		GIBQakgutV.yXofqcVp1Mhk(YvJZXDaqbN,ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F)
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z,H4ys6we0jDn)
	elif ye7Oa1nIcm9FVxw3vjQsDuKb6==KQ3sCe9Pzh(u"ࠪ࠺ࠬඓ"):
		import dIxmaLQn3F
		if SSN0rt6VGqc4fOnQijpb2F==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ඔ"): dIxmaLQn3F.dqKGMYgJxSF8Ub1kotlsP936Ww7B(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬඕ"),KW5bYS20wTF1LyCs9(u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭ඖ"),b8bLFaejUB=f90fGrlSEObDsuiA3U(u"࠷࠵࠱࠲ጇ"))
		elif SSN0rt6VGqc4fOnQijpb2F==EX25Y0l8ILvz7QcRC(u"ࠧࡅࡇࡏࡉ࡙ࡋࠧ඗"): nP6tjJH5O17yGvYB38IaEVb = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠳࠴࠶ገ")
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = dIxmaLQn3F.AsMupEf5dOTc1BvrnUatLiX3P4(fW4iNwld6COELJ10,JqZhbG9Le2NQvziaPCx8wI,FeTJrG4SkMf09iVys8A,nP6tjJH5O17yGvYB38IaEVb,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA)
		if SSN0rt6VGqc4fOnQijpb2F==jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪ඘"): ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	elif YvJZXDaqbN==J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩ࠺ࠫ඙"):
		import fdhmjHnwLQ
		fdhmjHnwLQ.QUOtV6uyKNJp8xLhv2CY()
	elif YvJZXDaqbN==ilBWK5nXxg1do4jENGC07Zq(u"ࠪ࠼ࠬක"):
		ccwRLKk3hs0E.executebuiltin(egY8Jti0smdLM3h1VQRSW(u"ࠫࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠪඛ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+egY8Jti0smdLM3h1VQRSW(u"ࠬࡅ࡭ࡰࡦࡨࡁࠬග")+str(zVg9Tax3sjPSAvRJF7XHGy5hK8)+LTN6DPEmrwehtZMy(u"࠭ࠦࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶ࠮࠭ඝ"))
	elif YvJZXDaqbN==w2vjZmdJuY7c(u"ࠧ࠺ࠩඞ"):
		AOwqYZ30sN1Mp(YchIv6N09BaWPEj4tieAnluKZrRXT)
		ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	return
def EWm9I6yoTUgp7FLfJDOtYzdKs5M84(fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA,JqZhbG9Le2NQvziaPCx8wI,nP6tjJH5O17yGvYB38IaEVb,ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F,jZHGcWxXpdVO038fnt):
	if tJWbQ0cyZoe: vxiKO2enuRVHYW3dT()
	if YvJZXDaqbN: ubskl1LEVzw(fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA,JqZhbG9Le2NQvziaPCx8wI,nP6tjJH5O17yGvYB38IaEVb,ye7Oa1nIcm9FVxw3vjQsDuKb6,SSN0rt6VGqc4fOnQijpb2F)
	I26IRUE53zjd9qbA()
	zlSqaMRcYWs(YchIv6N09BaWPEj4tieAnluKZrRXT)
	gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX = YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z
	sMcu1aCyPzhOt7Q = ou9xEXbMlN8zgmah(fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA,nP6tjJH5O17yGvYB38IaEVb,jZHGcWxXpdVO038fnt,gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX)
	kU1ZunWewoDl7LKjAyJiOmP8z5tMTf,hy985bf3gkpaz2Q076dvAoDjFxi,kytUo7ix2uZFWgbT5DJQ,wEiDnMUNsWC,MM1zgeJDN4TBi83thwKLW,lanbGdcVCStjLheY,U9BwS27VhZxJc6boe3vY1MIWqRr,L6jB5TmSV2eGrE7I8hDipFf = sMcu1aCyPzhOt7Q
	if kU1ZunWewoDl7LKjAyJiOmP8z5tMTf: return
	if hy985bf3gkpaz2Q076dvAoDjFxi==ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨඟ"): RD8m0SxQnJ(ZAl2gePWifs3IXG)
	mOoylMuTX7VUjNJq6YK4(w2vjZmdJuY7c(u"ࠩࡶࡸࡦࡸࡴࠨච"))
	if MoO74hKeqm8fFka.getSetting(I5bUBGpPXn0W6(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩඡ")) not in [dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡆ࡛ࡔࡐࠩජ"),f90fGrlSEObDsuiA3U(u"࡙ࠬࡔࡐࡒࠪඣ"),w2vjZmdJuY7c(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧඤ")]:
		MoO74hKeqm8fFka.setSetting(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭ඥ"),NxXMrsTC5FniYuRBOK8(u"ࠨࡃࡘࡘࡔ࠭ඦ"))
	if not MoO74hKeqm8fFka.getSetting(LTN6DPEmrwehtZMy(u"ࠩࡤࡺ࠳ࡪ࡮ࡴࠩට")): MoO74hKeqm8fFka.setSetting(CKUiyEe28zsZ(u"ࠪࡥࡻ࠴ࡤ࡯ࡵࠪඨ"),MOnQlAXkSV8vb2sDyWdtPzBU1ea[x1Oa8bBf36EwsLMirtFc])
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = AsMupEf5dOTc1BvrnUatLiX3P4(fW4iNwld6COELJ10,JqZhbG9Le2NQvziaPCx8wI,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA)
	if S8i3sBYoHWdTURpAgN(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ඩ") in oh8Z06rUdqJ: gp9QOLWo4ICu8vPXfFlVK0RM16 = YchIv6N09BaWPEj4tieAnluKZrRXT
	if fW4iNwld6COELJ10==TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬඪ"):
		if wEiDnMUNsWC!=ietolwsjpIPK7Fr(u"࠭࠮࠯ࠩණ") and MM1zgeJDN4TBi83thwKLW: G0ejOgq24ovDFbNc()
		if ZFsK7DtIkrHGnWQYhUM8P>-NSudqlOzja:
			kko1BRJf8CvVZjxqbE = [x1Oa8bBf36EwsLMirtFc,LTN6DPEmrwehtZMy(u"࠳࠸ጊ"),ilBWK5nXxg1do4jENGC07Zq(u"࠴࠻ጋ"),I5bUBGpPXn0W6(u"࠵࠾ጌ"),ilBWK5nXxg1do4jENGC07Zq(u"࠳࠸ጉ"),ilBWK5nXxg1do4jENGC07Zq(u"࠳࠵ጏ"),t3coAp06zvHrTl49bUVgx(u"࠺࠶ግ"),KQ3sCe9Pzh(u"࠻࠳ጎ")]
			if (EeZHTwQUW2BuvJyIh(pyifuNFdxe,NxXMrsTC5FniYuRBOK8(u"ࠧࡪࡰࡷࠫඬ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫත"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧථ")) or nP6tjJH5O17yGvYB38IaEVb not in kko1BRJf8CvVZjxqbE) and not ePJWDdHsX8Tokv31yL:
				from Y2s1VRIgrT import k9CjzAbN6BhGZrisO45cp
				vS7x6qYCUd = PkJErZ3g15uonzOeUhl2McQR(k9CjzAbN6BhGZrisO45cp)
				kU1ZunWewoDl7LKjAyJiOmP8z5tMTf = Dh6UHaz9c37Rf2lQ(kytUo7ix2uZFWgbT5DJQ,vS7x6qYCUd,gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX)
				if vS7x6qYCUd and lanbGdcVCStjLheY:
					CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡑࡊࡔࡕࡔࡡࡆࡅࡈࡎࡅࡠࠩද")+U9BwS27VhZxJc6boe3vY1MIWqRr+S8i3sBYoHWdTURpAgN(u"ࠫࡤ࠭ධ")+L6jB5TmSV2eGrE7I8hDipFf,kytUo7ix2uZFWgbT5DJQ,vS7x6qYCUd,bbfreYhcgwZlKEGVx7zRU)
			else:
				bCfjxP8yo4Qn3trXKNgW1AUl.addDirectoryItem(ZFsK7DtIkrHGnWQYhUM8P,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨන")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+KQ3sCe9Pzh(u"࠭࠯ࡀࡶࡼࡴࡪࡃ࡬ࡪࡰ࡮ࠪࡲࡵࡤࡦ࠿࠸࠴࠵࠭඲"),VVZgPQ2kYLoKe6jic5AEzqupG.ListItem(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧๅัํ็๋ࠥิไๆฬࠤ๊์ࠠอ้สึ่࠭ඳ")))
				bCfjxP8yo4Qn3trXKNgW1AUl.addDirectoryItem(ZFsK7DtIkrHGnWQYhUM8P,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫප")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+w2vjZmdJuY7c(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱ࠩඵ"),VVZgPQ2kYLoKe6jic5AEzqupG.ListItem(EX25Y0l8ILvz7QcRC(u"ࠪวๆะอࠡๆอๆึษࠠศๆอๅฬ฻๊ๅࠩබ")))
			bCfjxP8yo4Qn3trXKNgW1AUl.endOfDirectory(ZFsK7DtIkrHGnWQYhUM8P,gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX)
	return
def RD8m0SxQnJ(vJ8IuHSrVGfgW1ao7ihmQzNK2qpU):
	qCKovwUD0J5f46xOXQ = rDceXBpHkfVUYRJ3tIx95Z if vJ8IuHSrVGfgW1ao7ihmQzNK2qpU else YchIv6N09BaWPEj4tieAnluKZrRXT
	if not qCKovwUD0J5f46xOXQ:
		yvaCpWNwO0z27VUFcJgRe = txpHLlmaGzNqcTYWPoeS3MK5F8k(MoO74hKeqm8fFka.getSetting(ietolwsjpIPK7Fr(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡱࡪࡹࡳࡢࡩࡨࡷࠬභ")))
		yvaCpWNwO0z27VUFcJgRe = x1Oa8bBf36EwsLMirtFc if not yvaCpWNwO0z27VUFcJgRe else int(yvaCpWNwO0z27VUFcJgRe)
		if not yvaCpWNwO0z27VUFcJgRe or not x1Oa8bBf36EwsLMirtFc<=a8HLTkO2ns49yGNgiroS-yvaCpWNwO0z27VUFcJgRe<=vJ8IuHSrVGfgW1ao7ihmQzNK2qpU: qCKovwUD0J5f46xOXQ = YchIv6N09BaWPEj4tieAnluKZrRXT
	if not qCKovwUD0J5f46xOXQ:
		YsBuUELaqd4fSoNHiVnJmrCO = MoO74hKeqm8fFka.getSetting(jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪම"))
		if YsBuUELaqd4fSoNHiVnJmrCO in [eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬඹ"),eNEhtuoi9gK8JaTpIXj(u"ࠧࡏࡇ࡚ࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ය")]: qCKovwUD0J5f46xOXQ = YchIv6N09BaWPEj4tieAnluKZrRXT
	if not qCKovwUD0J5f46xOXQ:
		GAuPaNDw6bIWlTMCsOv3YEJZ8Xd = MoO74hKeqm8fFka.getSetting(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫර"))
		v3NtoHLrk2x = MoO74hKeqm8fFka.getSetting(S8i3sBYoHWdTURpAgN(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠶ࠬ඼"))
		RFi2SjVJsh6xkmID9HwTBzYCdXE = TOjyaHnYozURG.md5(f90fGrlSEObDsuiA3U(u"࠶ጐ")*GAuPaNDw6bIWlTMCsOv3YEJZ8Xd.encode(m6PFtLblInpNZ8x)).hexdigest()
		RFi2SjVJsh6xkmID9HwTBzYCdXE = TOjyaHnYozURG.md5(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠳࠷጑")*RFi2SjVJsh6xkmID9HwTBzYCdXE.encode(m6PFtLblInpNZ8x)).hexdigest()
		RFi2SjVJsh6xkmID9HwTBzYCdXE = TOjyaHnYozURG.md5(J7divaGOCgq2SLfXpDzZYN58wc(u"࠴࠽ጒ")*RFi2SjVJsh6xkmID9HwTBzYCdXE.encode(m6PFtLblInpNZ8x)).hexdigest()
		if RFi2SjVJsh6xkmID9HwTBzYCdXE!=v3NtoHLrk2x: qCKovwUD0J5f46xOXQ = YchIv6N09BaWPEj4tieAnluKZrRXT
	if qCKovwUD0J5f46xOXQ: qP0u35ob92fkOYMJLUtdecR(rDceXBpHkfVUYRJ3tIx95Z)
	return
def AsMupEf5dOTc1BvrnUatLiX3P4(fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA):
	nP6tjJH5O17yGvYB38IaEVb = int(zVg9Tax3sjPSAvRJF7XHGy5hK8)
	JvfrAebh43x5cTipPjdLF0s17tO = int(nP6tjJH5O17yGvYB38IaEVb//jUcmHhgVvW0EdYOIfXeaDF(u"࠵࠵ጓ"))
	if   JvfrAebh43x5cTipPjdLF0s17tO==x1Oa8bBf36EwsLMirtFc:  from YmtfK6LolI 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==NSudqlOzja:  from RszOfI8hTQ 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==FB0pIzAoK8wqgd3UiY5:  from y6MJSXaz5D 			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1:  from llZ9YqkM8N 			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==BSw5mizCOsKxWrRDvtJuFajY:  from DEzRowHVl5 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,clAzmREWwXf6Gk)
	elif JvfrAebh43x5cTipPjdLF0s17tO==f90fGrlSEObDsuiA3U(u"࠺ጔ"):  from oIOSBNqcit 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==EX25Y0l8ILvz7QcRC(u"࠼ጕ"):  from cn6ikqxB7E 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ehfEsaiJBSvbcULtNPVgykA2(u"࠷጖"):  from Fea5Jby2kR 			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==J7divaGOCgq2SLfXpDzZYN58wc(u"࠹጗"):  from VkzL4nFWeO 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==f90fGrlSEObDsuiA3U(u"࠻ጘ"):  from tqjdgu536L		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==w2vjZmdJuY7c(u"࠴࠴ጙ"): from EZ6VKpTQse 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A)
	elif JvfrAebh43x5cTipPjdLF0s17tO==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠵࠶ጚ"): from Wuqtfv8FCG 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==egY8Jti0smdLM3h1VQRSW(u"࠶࠸ጛ"): from jTiokqLutZ 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==XugxFprC26zGM(u"࠷࠳ጜ"): from ECczxuoKNU		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==Cp6c5tZe8I0PxnAW(u"࠱࠵ጝ"): from e27zOM5Tmb 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk,d8De716ZlA2,e3XtKs70ifmRQY8VTLnpMdyr6)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KQ3sCe9Pzh(u"࠲࠷ጞ"): from YmtfK6LolI 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠳࠹ጟ"): from rAnWqyKwHE		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,clAzmREWwXf6Gk,ruWSoIZkeKA)
	elif JvfrAebh43x5cTipPjdLF0s17tO==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠴࠻ጠ"): from YmtfK6LolI 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==bP01xn84BiQN(u"࠵࠽ጡ"): from ewgmrSUbhM		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ilBWK5nXxg1do4jENGC07Zq(u"࠶࠿ጢ"): from YmtfK6LolI 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==eNEhtuoi9gK8JaTpIXj(u"࠸࠰ጣ"): from bbrLcgqASe		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==XugxFprC26zGM(u"࠲࠲ጤ"): from YFehn7k38D	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==RqLvTrID0yMVeClpYcnZ16i3X(u"࠳࠴ጥ"): from rRsjDxq3wS		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==Cp6c5tZe8I0PxnAW(u"࠴࠶ጦ"): from oocDvzUeSu			import wt29MA4RWa8NOedvnpocQEfC1Hg; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wt29MA4RWa8NOedvnpocQEfC1Hg(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk,ruWSoIZkeKA)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠵࠸ጧ"): from CUTcRwrWs9 			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠶࠺ጨ"): from wLhCnjZVsc 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LTN6DPEmrwehtZMy(u"࠷࠼ጩ"): from Y2s1VRIgrT 			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LyOR7f69iA(u"࠸࠷ጪ"): from GIBQakgutV		import wt29MA4RWa8NOedvnpocQEfC1Hg; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wt29MA4RWa8NOedvnpocQEfC1Hg(nP6tjJH5O17yGvYB38IaEVb,YvJZXDaqbN)
	elif JvfrAebh43x5cTipPjdLF0s17tO==EX25Y0l8ILvz7QcRC(u"࠲࠹ጫ"): from oocDvzUeSu			import wt29MA4RWa8NOedvnpocQEfC1Hg; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wt29MA4RWa8NOedvnpocQEfC1Hg(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk,ruWSoIZkeKA)
	elif JvfrAebh43x5cTipPjdLF0s17tO==J7divaGOCgq2SLfXpDzZYN58wc(u"࠳࠻ጬ"): from aEYz21xswN	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==egY8Jti0smdLM3h1VQRSW(u"࠵࠳ጭ"): from iiyOUr0L5P		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠶࠵ጮ"): from fqcWFkVrY5		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==egY8Jti0smdLM3h1VQRSW(u"࠷࠷ጯ"): from EsDtGZ51Bw		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==J7divaGOCgq2SLfXpDzZYN58wc(u"࠸࠹ጰ"): from dmXYZhFJCL		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A)
	elif JvfrAebh43x5cTipPjdLF0s17tO==CKUiyEe28zsZ(u"࠹࠴ጱ"): from YmtfK6LolI 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==bP01xn84BiQN(u"࠳࠶ጲ"): from RRXJPG8pa2		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴࠸ጳ"): from QoJZN84LHx			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LyOR7f69iA(u"࠵࠺ጴ"): from lKEUgnXfoA			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KQ3sCe9Pzh(u"࠶࠼ጵ"): from YCszToelGr 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠷࠾ጶ"): from bwc3If0s54		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠹࠶ጷ"): from xp3idWHVor	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk)
	elif JvfrAebh43x5cTipPjdLF0s17tO==RqLvTrID0yMVeClpYcnZ16i3X(u"࠺࠱ጸ"): from xp3idWHVor	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠴࠳ጹ"): from hYSQu6oesZ			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==S8i3sBYoHWdTURpAgN(u"࠵࠵ጺ"): from rNYwsf7vbW			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==J7divaGOCgq2SLfXpDzZYN58wc(u"࠶࠷ጻ"): from EiK31qe2fV		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠷࠹ጼ"): from CCMsTqwfJg		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LTN6DPEmrwehtZMy(u"࠸࠻ጽ"): from y8geHuIGD9			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠹࠽ጾ"): from HH3fO9vDLW		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠺࠸ጿ"): from jAQcYTetKX		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==t3coAp06zvHrTl49bUVgx(u"࠴࠺ፀ"): from jjR5Cdrlzi		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LTN6DPEmrwehtZMy(u"࠶࠲ፁ"): from YmtfK6LolI 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==t3coAp06zvHrTl49bUVgx(u"࠷࠴ፂ"): from ttojwI7EGg 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KW5bYS20wTF1LyCs9(u"࠸࠶ፃ"): from ttojwI7EGg 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ilBWK5nXxg1do4jENGC07Zq(u"࠹࠸ፄ"): from Y2s1VRIgrT 			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==RqLvTrID0yMVeClpYcnZ16i3X(u"࠺࠺ፅ"): from fdhmjHnwLQ	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,clAzmREWwXf6Gk)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ehfEsaiJBSvbcULtNPVgykA2(u"࠻࠵ፆ"): from GPkJLhHnO3 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠵࠷ፇ"): from l5ikFnmCqh			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==S8i3sBYoHWdTURpAgN(u"࠶࠹ፈ"): from UR8FgEY7kJ		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==w2vjZmdJuY7c(u"࠷࠻ፉ"): from j9zf52GVYr		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠸࠽ፊ"): from zFvwOqQyVL		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==J7divaGOCgq2SLfXpDzZYN58wc(u"࠺࠵ፋ"): from fEkoiGHytd			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KW5bYS20wTF1LyCs9(u"࠻࠷ፌ"): from AYXlyJHNEu			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==bP01xn84BiQN(u"࠼࠲ፍ"): from MNzu2YTQV1		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠶࠴ፎ"): from HHOUuDZCbl	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==jUcmHhgVvW0EdYOIfXeaDF(u"࠷࠶ፏ"): from Zm95OxkaWF			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==w2vjZmdJuY7c(u"࠸࠸ፐ"): from bAG2uJTBPr			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LyOR7f69iA(u"࠹࠺ፑ"): from ndKe3a9G5o			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺࠼ፒ"): from ySw97VLqvm		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==EX25Y0l8ILvz7QcRC(u"࠻࠾ፓ"): from zzJkBAFluL		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==t3coAp06zvHrTl49bUVgx(u"࠼࠹ፔ"): from o86agSUXJP		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠷࠱ፕ"): from ulF3fqkQYR			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KW5bYS20wTF1LyCs9(u"࠸࠳ፖ"): from jVcFvDeLay			import wt29MA4RWa8NOedvnpocQEfC1Hg; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wt29MA4RWa8NOedvnpocQEfC1Hg(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk,ruWSoIZkeKA)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KW5bYS20wTF1LyCs9(u"࠹࠵ፗ"): from jVcFvDeLay			import wt29MA4RWa8NOedvnpocQEfC1Hg; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wt29MA4RWa8NOedvnpocQEfC1Hg(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,fW4iNwld6COELJ10,clAzmREWwXf6Gk,ruWSoIZkeKA)
	elif JvfrAebh43x5cTipPjdLF0s17tO==jUcmHhgVvW0EdYOIfXeaDF(u"࠺࠷ፘ"): from oOpkzLXbqE	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==jUcmHhgVvW0EdYOIfXeaDF(u"࠻࠹ፙ"): from fGYcAvgd93		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb)
	elif JvfrAebh43x5cTipPjdLF0s17tO==EX25Y0l8ILvz7QcRC(u"࠼࠻ፚ"): from fGYcAvgd93		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb)
	elif JvfrAebh43x5cTipPjdLF0s17tO==egY8Jti0smdLM3h1VQRSW(u"࠽࠶፛"): from rAnWqyKwHE		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ,clAzmREWwXf6Gk,ruWSoIZkeKA)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠷࠸፜"): from BUiuKe0MF7 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==wY1p9mP03S8drbcH64t5WQkv(u"࠸࠺፝"): from SS58wEJpds 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠹࠼፞"): from EELl8BIS4h 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KQ3sCe9Pzh(u"࠻࠴፟"): from TYaLP7hqv8 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==LTN6DPEmrwehtZMy(u"࠼࠶፠"): from vflsZo8aGn 		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠽࠸፡"): from fHC5Ku3jMg		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,clAzmREWwXf6Gk,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ietolwsjpIPK7Fr(u"࠾࠳።"): from KKSnTapYrA		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==I5bUBGpPXn0W6(u"࠸࠵፣"): from MR1UTOtlLc		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠹࠷፤"): from U3aGTmdeyr		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==RqLvTrID0yMVeClpYcnZ16i3X(u"࠺࠹፥"): from hKeTC741rb		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==bP01xn84BiQN(u"࠻࠻፦"): from Yy5BNqdfX3			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==eNEhtuoi9gK8JaTpIXj(u"࠼࠽፧"): from QNrMSWRecB			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==ietolwsjpIPK7Fr(u"࠽࠿፨"): from bbzAeV1IUE		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==Cp6c5tZe8I0PxnAW(u"࠿࠰፩"): from reKSbLqHZA	import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠹࠲፪"): from wA61q20Uth		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==KQ3sCe9Pzh(u"࠺࠴፫"): from klhVCY4fya		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠻࠶፬"): from vvgKHYMqlI		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==CKUiyEe28zsZ(u"࠼࠸፭"): from xg6MXmBYdS			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==wY1p9mP03S8drbcH64t5WQkv(u"࠽࠺፮"): from xEA0bpI9wa			import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==HkiMU0QrdzW3l6gwnT(u"࠾࠼፯"): from BG3AgUIsF5		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==XugxFprC26zGM(u"࠿࠷፰"): from nnV7pwMtzZ		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==J7divaGOCgq2SLfXpDzZYN58wc(u"࠹࠹፱"): from mmbZG23Fxl		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	elif JvfrAebh43x5cTipPjdLF0s17tO==CKUiyEe28zsZ(u"࠺࠻፲"): from BYuk1Ms75w		import alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX	; JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(nP6tjJH5O17yGvYB38IaEVb,FeTJrG4SkMf09iVys8A,oh8Z06rUdqJ)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = None
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def WS035ndUBmeHMi9I4A(O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6,Oyg3pZGAHdws7RWm4e6S,showDialogs):
	uujC2KDqoT3rGHzPpAW1mf = Oyg3pZGAHdws7RWm4e6S.split(ehfEsaiJBSvbcULtNPVgykA2(u"ࠪ࠱ࠬල"),NSudqlOzja)[x1Oa8bBf36EwsLMirtFc] if dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫ࠲࠭඾") in Oyg3pZGAHdws7RWm4e6S else Oyg3pZGAHdws7RWm4e6S
	if not showDialogs or Oyg3pZGAHdws7RWm4e6S in IuLpt4BK7yjad0vMW63Ql: return rDceXBpHkfVUYRJ3tIx95Z
	UqZNbxJRlo1re9yYjSVvkIf = MoO74hKeqm8fFka.getSetting(NxXMrsTC5FniYuRBOK8(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭඿"))
	MoO74hKeqm8fFka.setSetting(KW5bYS20wTF1LyCs9(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧව"),eHdDoxhJCEPMZFVa2fg)
	bVrN9QKj6f = O1WFus64LiEAmzpnPIT8jgZHN in [GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠼፶"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴࠵࠵࠶࠱፴"),XugxFprC26zGM(u"࠳࠴࠴࠵࠸፳"),eNEhtuoi9gK8JaTpIXj(u"࠵࠵࠶࠵࠵፵")]
	RUiyOD0VcPCxpm7rMet6BsGJ9Zfg = RCrFOws8DlH6.lower()
	UaGudf8EePCY795A4nsmvFBxcwlIy = O1WFus64LiEAmzpnPIT8jgZHN in [x1Oa8bBf36EwsLMirtFc,egY8Jti0smdLM3h1VQRSW(u"࠲࠲࠷፹"),KW5bYS20wTF1LyCs9(u"࠷࠰࠱࠸࠴፷"),NxXMrsTC5FniYuRBOK8(u"࠱࠲࠳፸")]
	XZyR8iKuz1NlhT9gDc = KQ3sCe9Pzh(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨශ") in RUiyOD0VcPCxpm7rMet6BsGJ9Zfg
	hGXV03ONwdmUb = LyOR7f69iA(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥ࠻ࠠࡴࡧࡦࡳࡳࡪࡳࠡࡤࡵࡳࡼࡹࡥࡳࠢࡦ࡬ࡪࡩ࡫ࠨෂ") in RUiyOD0VcPCxpm7rMet6BsGJ9Zfg
	LEHKAOlrmPZ = EX25Y0l8ILvz7QcRC(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩස") in RUiyOD0VcPCxpm7rMet6BsGJ9Zfg
	E71xdUY2fj = wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠤࡸ࡫ࡣࡶࡴ࡬ࡸࡾࠦࡣࡩࡧࡦ࡯ࠬහ") in RUiyOD0VcPCxpm7rMet6BsGJ9Zfg
	fDRjs72vQu5O9ThqLKkB = MoO74hKeqm8fFka.getSetting(LTN6DPEmrwehtZMy(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩළ"))
	UbNnVwsHjAoSYQ = MoO74hKeqm8fFka.getSetting(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨෆ"))
	vv18goOy0YrU = bP01xn84BiQN(u"࠭แีๆࠣๅ๏ࠦำฮสࠣห้฻แฮห้๋ࠣࠦวๅว้ฮึ์สࠨ෇")
	hh395jmAEXb2HG = ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡆࡴࡵࡳࡷࠦࠧ෈")+str(O1WFus64LiEAmzpnPIT8jgZHN)+eNEhtuoi9gK8JaTpIXj(u"ࠨ࠼ࠣࠫ෉")+RCrFOws8DlH6
	hh395jmAEXb2HG = zrHeZWCqQMOymk1d7anKpu0vEx8(hh395jmAEXb2HG)
	if UaGudf8EePCY795A4nsmvFBxcwlIy or XZyR8iKuz1NlhT9gDc or hGXV03ONwdmUb or LEHKAOlrmPZ or E71xdUY2fj: vv18goOy0YrU += GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࠣ࠲ࠥอไๆ๊ๅ฽ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐ࠠๆืาี์ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦศศๆ่์็฿࡜࡯්ࠩ")
	if bVrN9QKj6f: vv18goOy0YrU += ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࠤ࠳ࠦไะ์ๆࠤำ฽รࠡࡆࡑࡗࠥ๎ๅฺ่ส๋ࠥะูัำࠣฮึาๅสࠢสื๊ࠦวๅ็๋ๆ฾ࠦลๅ๋ࠣี็๋็࡝ࡰࠪ෋")
	hh395jmAEXb2HG = kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+hh395jmAEXb2HG+Nat0Dx9puRUWCsgz6JyFhY3
	if fDRjs72vQu5O9ThqLKkB==I5bUBGpPXn0W6(u"ࠫࡆ࡙ࡋࠨ෌") or UbNnVwsHjAoSYQ==I5bUBGpPXn0W6(u"ࠬࡇࡓࡌࠩ෍"):
		vv18goOy0YrU += kDUv7ouWrcgMe6OipQJm+OR97bMGecfgDCqux3YdAZ6y+XugxFprC26zGM(u"࠭็ๅࠢอี๏ีࠠฤ่ࠣ๎าอ่ๅࠢส่อืๆศ็ฯࠤส฻ไศฯࠣห้๋ิไๆฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦร้ࠢั฻ศࠦลๅ๋ࠣห้๋ศา็ฯࠤฤࠧࠡࠨ෎")+Nat0Dx9puRUWCsgz6JyFhY3
	ikPnsZcmLjwHvWST50V61u = rDceXBpHkfVUYRJ3tIx95Z
	if fDRjs72vQu5O9ThqLKkB==t3coAp06zvHrTl49bUVgx(u"ࠧࡂࡕࡎࠫා") or UbNnVwsHjAoSYQ==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡃࡖࡏࠬැ"):
		jF1DqR2Y3VrIShwBeOpco = vKD1rqZCXUbcR7n38VyatMSEL(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡦࡩࡳࡺࡥࡳࠩෑ"),w2vjZmdJuY7c(u"ࠪาึ๎ฬࠨි"),ilBWK5nXxg1do4jENGC07Zq(u"ࠫสืำศๆ่้๋ࠣศา็ฯࠫී"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬะีๅ์ะࠤฬ๊ๅีๅ็อࠬු"),uujC2KDqoT3rGHzPpAW1mf+D8OnEGLjecaXw+v9vBX6ZiQ0UHxfze8EjG4nmRW(uujC2KDqoT3rGHzPpAW1mf),vv18goOy0YrU+kDUv7ouWrcgMe6OipQJm+hh395jmAEXb2HG)
		if jF1DqR2Y3VrIShwBeOpco==NSudqlOzja:
			from YmtfK6LolI import kExW7f8PlyVi34NbOYXd
			kExW7f8PlyVi34NbOYXd()
		elif jF1DqR2Y3VrIShwBeOpco==FB0pIzAoK8wqgd3UiY5: ikPnsZcmLjwHvWST50V61u = YchIv6N09BaWPEj4tieAnluKZrRXT
	else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,uujC2KDqoT3rGHzPpAW1mf+D8OnEGLjecaXw+v9vBX6ZiQ0UHxfze8EjG4nmRW(uujC2KDqoT3rGHzPpAW1mf),vv18goOy0YrU,hh395jmAEXb2HG)
	MoO74hKeqm8fFka.setSetting(S8i3sBYoHWdTURpAgN(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ෕"),UqZNbxJRlo1re9yYjSVvkIf)
	return ikPnsZcmLjwHvWST50V61u
def nwXsRUtrkb4gDOMV8N6ZHTl(qgrDfmiLbaXFuQVK96BzjIGR1pOP=rDceXBpHkfVUYRJ3tIx95Z,lUoCtLyPX423pIbHrc06fSgO=[]):
	w4jTioaLNWhsbmyBH0EOAPIJDuRXlp = [s4FvMNOledIt,CCknZTXVNbG9Px0ds1hpQSMKB]+lUoCtLyPX423pIbHrc06fSgO
	for dyablPViz25TGKJ in RRydns1CErYlIhwSx7.listdir(oX9h2wrQe5):
		if qgrDfmiLbaXFuQVK96BzjIGR1pOP and (dyablPViz25TGKJ.startswith(egY8Jti0smdLM3h1VQRSW(u"ࠧࡪࡲࡷࡺࠬූ")) or dyablPViz25TGKJ.startswith(ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࡯࠶ࡹࠬ෗"))): continue
		if dyablPViz25TGKJ.startswith(KQ3sCe9Pzh(u"ࠩࡩ࡭ࡱ࡫࡟ࠨෘ")): continue
		cIrGhlniFK3VazvkyNdBUELtj = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,dyablPViz25TGKJ)
		if cIrGhlniFK3VazvkyNdBUELtj in w4jTioaLNWhsbmyBH0EOAPIJDuRXlp: continue
		try: RRydns1CErYlIhwSx7.remove(cIrGhlniFK3VazvkyNdBUELtj)
		except: pass
	if e8j3fyIi05dcPOpkmq not in w4jTioaLNWhsbmyBH0EOAPIJDuRXlp: ycgRbjNoPLQSnx(e8j3fyIi05dcPOpkmq,YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
	b8bLFaejUB.sleep(CKUiyEe28zsZ(u"࠳፺"))
	return
def RRPHsbDCfgT(MjaZBsDAwRfhtiI7,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s=YchIv6N09BaWPEj4tieAnluKZrRXT,nLNrPvpjiES2hJ=YchIv6N09BaWPEj4tieAnluKZrRXT):
	FeTJrG4SkMf09iVys8A = FeTJrG4SkMf09iVys8A+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪෙ")+MjaZBsDAwRfhtiI7
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s,nLNrPvpjiES2hJ)
	if FeTJrG4SkMf09iVys8A in qldY3LPe0pDiuyoM8vIH.content: qldY3LPe0pDiuyoM8vIH.succeeded = rDceXBpHkfVUYRJ3tIx95Z
	if not qldY3LPe0pDiuyoM8vIH.succeeded:
		ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	return qldY3LPe0pDiuyoM8vIH
def gqYhOzIn1JA(FeTJrG4SkMf09iVys8A):
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡌࡋࡔࠨේ"),FeTJrG4SkMf09iVys8A,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡖࡢࡔࡗࡕࡘࡊࡇࡖࡣࡑࡏࡓࡕ࠯࠴ࡷࡹ࠭ෛ"),YchIv6N09BaWPEj4tieAnluKZrRXT,rDceXBpHkfVUYRJ3tIx95Z)
	fWqJCH1s3uMm9NZlxt0S7QBOV2L = []
	if qldY3LPe0pDiuyoM8vIH.succeeded:
		a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
		nnRvkpzxUSs17I8tEPcreyumJ = cBawilJXvK1m.findall(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࡥࡽ࠴࠰࠸ࢃ࡭ࡴࠩො"),a3glxPAGFXm2kzq)
		if nnRvkpzxUSs17I8tEPcreyumJ: a3glxPAGFXm2kzq = kDUv7ouWrcgMe6OipQJm.join(nnRvkpzxUSs17I8tEPcreyumJ)
		q6vKWbwG7xps = a3glxPAGFXm2kzq.replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg).strip(kDUv7ouWrcgMe6OipQJm).split(kDUv7ouWrcgMe6OipQJm)
		fWqJCH1s3uMm9NZlxt0S7QBOV2L = []
		for MjaZBsDAwRfhtiI7 in q6vKWbwG7xps:
			if MjaZBsDAwRfhtiI7.count(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࠯ࠩෝ"))==bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1: fWqJCH1s3uMm9NZlxt0S7QBOV2L.append(MjaZBsDAwRfhtiI7)
	return fWqJCH1s3uMm9NZlxt0S7QBOV2L
def BE0oV2mYXjd1(*aargs):
	lZMLU5uhj2PDOY = jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡴ࡮࠴ࡰࡳࡱࡻࡽࡸࡩࡲࡢࡲࡨ࠲ࡨࡵ࡭࠰ࡸ࠵࠳ࡄࡸࡥࡲࡷࡨࡷࡹࡃࡤࡪࡵࡳࡰࡦࡿࡰࡳࡱࡻ࡭ࡪࡹࠦࡱࡴࡲࡼࡾࡺࡹࡱࡧࡀ࡬ࡹࡺࡰࠧࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠴࠵࠶࠰ࠧࡵࡶࡰࡂࡿࡥࡴࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩෞ")
	KGfj7wbeny4ZA38WERQv = w2vjZmdJuY7c(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡲࡳࡸࡺࡥࡳ࡭࡬ࡨ࠴ࡵࡰࡦࡰࡳࡶࡴࡾࡹ࡭࡫ࡶࡸ࠴ࡳࡡࡪࡰ࠲ࡌ࡙࡚ࡐࡔ࠰ࡷࡼࡹ࠭ෟ")
	apo7hwJ2AUQmL = gqYhOzIn1JA(KGfj7wbeny4ZA38WERQv)
	fWqJCH1s3uMm9NZlxt0S7QBOV2L = gqYhOzIn1JA(lZMLU5uhj2PDOY)
	vsBqmtWZKoblkLjC = apo7hwJ2AUQmL+fWqJCH1s3uMm9NZlxt0S7QBOV2L
	vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+egY8Jti0smdLM3h1VQRSW(u"ࠪࠤࠥࠦࡇࡰࡶࠣࡴࡷࡵࡸࡪࡧࡶࠤࡱ࡯ࡳࡵࠢࠣࠤ࠶ࡹࡴࠬ࠴ࡱࡨ࠿࡛ࠦࠡࠩ෠")+str(len(apo7hwJ2AUQmL))+eNEhtuoi9gK8JaTpIXj(u"ࠫ࠰࠭෡")+str(len(fWqJCH1s3uMm9NZlxt0S7QBOV2L))+NxXMrsTC5FniYuRBOK8(u"ࠬࠦ࡝ࠨ෢"))
	MjaZBsDAwRfhtiI7 = MoO74hKeqm8fFka.getSetting(jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡡࡷ࠰ࡳࡶࡴࡾࡹ࠯࡮ࡤࡷࡹ࠭෣"))
	qldY3LPe0pDiuyoM8vIH = maQf4xXLtV2()
	MoO74hKeqm8fFka.setSetting(t3coAp06zvHrTl49bUVgx(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ෤"),eHdDoxhJCEPMZFVa2fg)
	if MjaZBsDAwRfhtiI7 or vsBqmtWZKoblkLjC:
		vvTGOs9zmKUeP35iILrC4,MbacDJogKp5ElfIi = x1Oa8bBf36EwsLMirtFc,I5bUBGpPXn0W6(u"࠴࠴፻")
		t2USacF0YuiJPROgpje14bs = len(vsBqmtWZKoblkLjC)
		ArQWBs8Z06qjuDS3yPiL1pRJdKvwUF = MbacDJogKp5ElfIi
		if t2USacF0YuiJPROgpje14bs>ArQWBs8Z06qjuDS3yPiL1pRJdKvwUF: k3wq6ygAI5KndZCj4fBo8l7SDe = ArQWBs8Z06qjuDS3yPiL1pRJdKvwUF
		else: k3wq6ygAI5KndZCj4fBo8l7SDe = t2USacF0YuiJPROgpje14bs
		UBqsZrMLhg0byOvDdXwWE1FYINmtRp = GljITSOwLKW36.sample(vsBqmtWZKoblkLjC,k3wq6ygAI5KndZCj4fBo8l7SDe)
		if MjaZBsDAwRfhtiI7: UBqsZrMLhg0byOvDdXwWE1FYINmtRp = [MjaZBsDAwRfhtiI7]+UBqsZrMLhg0byOvDdXwWE1FYINmtRp
		YG0x4UjZDcmq = NLZqC35dHIcYei6Tpr4wms(rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
		B0ZiepTkgjAq8lWxCKyX1 = b8bLFaejUB.time()
		while b8bLFaejUB.time()-B0ZiepTkgjAq8lWxCKyX1<=MbacDJogKp5ElfIi and not YG0x4UjZDcmq.finishedLIST:
			if vvTGOs9zmKUeP35iILrC4<k3wq6ygAI5KndZCj4fBo8l7SDe:
				MjaZBsDAwRfhtiI7 = UBqsZrMLhg0byOvDdXwWE1FYINmtRp[vvTGOs9zmKUeP35iILrC4]
				YG0x4UjZDcmq.zuhp2kCsanALdD(vvTGOs9zmKUeP35iILrC4,RRPHsbDCfgT,MjaZBsDAwRfhtiI7,*aargs)
			b8bLFaejUB.sleep(jUcmHhgVvW0EdYOIfXeaDF(u"࠴࠳࠽࠵፼"))
			vvTGOs9zmKUeP35iILrC4 += NSudqlOzja
			vR9cOpMtk51j(iwIlVQsgYezu,WMyqfm31ka2jICwiE(EERWJf1adv67)+wY1p9mP03S8drbcH64t5WQkv(u"ࠨࠢࠣࠤ࡙ࡸࡹࡪࡰࡪ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ෥")+MjaZBsDAwRfhtiI7+ilBWK5nXxg1do4jENGC07Zq(u"ࠩࠣࡡࠬ෦"))
		finishedLIST = YG0x4UjZDcmq.finishedLIST
		if finishedLIST:
			resultsDICT = YG0x4UjZDcmq.resultsDICT
			MQU3HOu2KVShvg4fCncqFIomWYex = finishedLIST[x1Oa8bBf36EwsLMirtFc]
			qldY3LPe0pDiuyoM8vIH = resultsDICT[MQU3HOu2KVShvg4fCncqFIomWYex]
			MjaZBsDAwRfhtiI7 = UBqsZrMLhg0byOvDdXwWE1FYINmtRp[int(MQU3HOu2KVShvg4fCncqFIomWYex)]
			MoO74hKeqm8fFka.setSetting(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡥࡻ࠴ࡰࡳࡱࡻࡽ࠳ࡲࡡࡴࡶࠪ෧"),MjaZBsDAwRfhtiI7)
			if MQU3HOu2KVShvg4fCncqFIomWYex!=x1Oa8bBf36EwsLMirtFc: vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+ilBWK5nXxg1do4jENGC07Zq(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ෨")+MjaZBsDAwRfhtiI7+I5bUBGpPXn0W6(u"ࠬࠦ࡝ࠨ෩"))
			else: vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+ietolwsjpIPK7Fr(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥࠦࡓࡢࡸࡨࡨࠥࡶࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ෪")+MjaZBsDAwRfhtiI7+Cp6c5tZe8I0PxnAW(u"ࠧࠡ࡟ࠪ෫"))
	return qldY3LPe0pDiuyoM8vIH
def FR0Qkbq3GE(RybZs8Phmu5S2To,uJinrVBe7MAY3):
	R7aojIruSQvgLMdqHBx43 = RybZs8Phmu5S2To.create_connection
	def D4WCgS7YIZp35kjr89LxaMdqR0KAHu(i5QykLl70fpqjWzv,*aargs,**kkwargs):
		RgkzMx9Fc3ZtUJmrG1pqIEf,ssihyIe9fm8vVzSLpMc = i5QykLl70fpqjWzv
		ip = yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(RgkzMx9Fc3ZtUJmrG1pqIEf,uJinrVBe7MAY3)
		if ip: RgkzMx9Fc3ZtUJmrG1pqIEf = ip[x1Oa8bBf36EwsLMirtFc]
		else:
			if uJinrVBe7MAY3 in MOnQlAXkSV8vb2sDyWdtPzBU1ea: MOnQlAXkSV8vb2sDyWdtPzBU1ea.remove(uJinrVBe7MAY3)
			if MOnQlAXkSV8vb2sDyWdtPzBU1ea:
				UVxI9sRKcPyBmTqEwnp2ig = MOnQlAXkSV8vb2sDyWdtPzBU1ea[x1Oa8bBf36EwsLMirtFc]
				ip = yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(RgkzMx9Fc3ZtUJmrG1pqIEf,UVxI9sRKcPyBmTqEwnp2ig)
				if ip: RgkzMx9Fc3ZtUJmrG1pqIEf = ip[x1Oa8bBf36EwsLMirtFc]
		i5QykLl70fpqjWzv = (RgkzMx9Fc3ZtUJmrG1pqIEf,ssihyIe9fm8vVzSLpMc)
		return R7aojIruSQvgLMdqHBx43(i5QykLl70fpqjWzv,*aargs,**kkwargs)
	RybZs8Phmu5S2To.create_connection = D4WCgS7YIZp35kjr89LxaMdqR0KAHu
	return R7aojIruSQvgLMdqHBx43
def TKCtWqcx8IwhBidE5(FeTJrG4SkMf09iVys8A):
	glK7ax9RGem,MMrICAlxh18syGRXNWQYm = FeTJrG4SkMf09iVys8A.split(bP01xn84BiQN(u"ࠨ࠱ࠪ෬"))[FB0pIzAoK8wqgd3UiY5],J7divaGOCgq2SLfXpDzZYN58wc(u"࠽࠶፽")
	if S8i3sBYoHWdTURpAgN(u"ࠩ࠽ࠫ෭") in glK7ax9RGem: glK7ax9RGem,MMrICAlxh18syGRXNWQYm = glK7ax9RGem.split(f90fGrlSEObDsuiA3U(u"ࠪ࠾ࠬ෮"))
	fpdEwGbAma3eNgoI0v2JWMBFUktzYi = jUcmHhgVvW0EdYOIfXeaDF(u"ࠫ࠴࠭෯")+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࠵ࠧ෰").join(FeTJrG4SkMf09iVys8A.split(XugxFprC26zGM(u"࠭࠯ࠨ෱"))[RqLvTrID0yMVeClpYcnZ16i3X(u"࠹፾"):])
	mzfT1LoKkCy7g9wuSqV = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡈࡇࡗࠤࠬෲ")+fpdEwGbAma3eNgoI0v2JWMBFUktzYi+ilBWK5nXxg1do4jENGC07Zq(u"ࠨࠢࡋࡘ࡙ࡖ࠯࠲࠰࠴ࡠࡷࡢ࡮ࠨෳ")
	mzfT1LoKkCy7g9wuSqV += NxXMrsTC5FniYuRBOK8(u"ࠩࡋࡳࡸࡺ࠺ࠡࠩ෴")+glK7ax9RGem+NxXMrsTC5FniYuRBOK8(u"ࠪࡠࡷࡢ࡮ࠨ෵")
	mzfT1LoKkCy7g9wuSqV += ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡡࡸ࡜࡯ࠩ෶")
	from socket import socket as d8ERXc2O9NADu,AF_INET as H28fb4Yg1GA3,SOCK_STREAM as UcrOzDRH470eTvC6dKF5mAf9PV
	try:
		egrlSKwa5bNHIP = d8ERXc2O9NADu(H28fb4Yg1GA3,UcrOzDRH470eTvC6dKF5mAf9PV)
		egrlSKwa5bNHIP.connect((glK7ax9RGem,MMrICAlxh18syGRXNWQYm))
		egrlSKwa5bNHIP.send(mzfT1LoKkCy7g9wuSqV.encode(m6PFtLblInpNZ8x))
		uVGBTR7SQ9UWDEhkZO = egrlSKwa5bNHIP.recv(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠵࠲࠼࠺ᎀ")*J7divaGOCgq2SLfXpDzZYN58wc(u"࠱࠱࠴࠷፿"))
		a3glxPAGFXm2kzq = repr(uVGBTR7SQ9UWDEhkZO)
	except: a3glxPAGFXm2kzq = eHdDoxhJCEPMZFVa2fg
	return a3glxPAGFXm2kzq
def b31wAB8mhaz2rXHoJFlfvDugtsOj(GUk97EVcihOnsxQgJ8W,fW4iNwld6COELJ10):
	if LTN6DPEmrwehtZMy(u"ࠬ࠴ࠧ෷") not in GUk97EVcihOnsxQgJ8W: return GUk97EVcihOnsxQgJ8W
	GUk97EVcihOnsxQgJ8W = GUk97EVcihOnsxQgJ8W+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭࠯ࠨ෸")
	yxWz142HqX3wIKZidpT5A8MBePJRtu,Gco1fCp4tX7sOmuMxWJPz = GUk97EVcihOnsxQgJ8W.split(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࠯ࠩ෹"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠳ᎁ"))
	o0vHqWdgm3fiuUs4CXDESMBGxLI,o6UQVkBrHD5jy4amYiM = Gco1fCp4tX7sOmuMxWJPz.split(wY1p9mP03S8drbcH64t5WQkv(u"ࠨ࠱ࠪ෺"),NxXMrsTC5FniYuRBOK8(u"࠴ᎂ"))
	n6DL1XJTHQbi0ctSZksurjo5zOg = yxWz142HqX3wIKZidpT5A8MBePJRtu+wY1p9mP03S8drbcH64t5WQkv(u"ࠩ࠱ࠫ෻")+o0vHqWdgm3fiuUs4CXDESMBGxLI
	if fW4iNwld6COELJ10 in [ehfEsaiJBSvbcULtNPVgykA2(u"ࠪ࡬ࡴࡹࡴࠨ෼"),eNEhtuoi9gK8JaTpIXj(u"ࠫࡳࡧ࡭ࡦࠩ෽")] and eNEhtuoi9gK8JaTpIXj(u"ࠬ࠵ࠧ෾") in n6DL1XJTHQbi0ctSZksurjo5zOg: n6DL1XJTHQbi0ctSZksurjo5zOg = n6DL1XJTHQbi0ctSZksurjo5zOg.rsplit(t3coAp06zvHrTl49bUVgx(u"࠭࠯ࠨ෿"),wY1p9mP03S8drbcH64t5WQkv(u"࠵ᎃ"))[NSudqlOzja]
	if fW4iNwld6COELJ10==HkiMU0QrdzW3l6gwnT(u"ࠧ࡯ࡣࡰࡩࠬ฀") and f90fGrlSEObDsuiA3U(u"ࠨ࠰ࠪก") in n6DL1XJTHQbi0ctSZksurjo5zOg:
		lEuc0pmr45fHaTgwQ2VKA73WP9hzI = n6DL1XJTHQbi0ctSZksurjo5zOg.split(bP01xn84BiQN(u"ࠩ࠱ࠫข"))
		ZwQ23eJ6vt = len(lEuc0pmr45fHaTgwQ2VKA73WP9hzI)
		if ZwQ23eJ6vt<=FB0pIzAoK8wqgd3UiY5 or KW5bYS20wTF1LyCs9(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨฃ") in n6DL1XJTHQbi0ctSZksurjo5zOg: lEuc0pmr45fHaTgwQ2VKA73WP9hzI = lEuc0pmr45fHaTgwQ2VKA73WP9hzI[x1Oa8bBf36EwsLMirtFc]
		elif ZwQ23eJ6vt>=bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1: lEuc0pmr45fHaTgwQ2VKA73WP9hzI = lEuc0pmr45fHaTgwQ2VKA73WP9hzI[NSudqlOzja]
		if len(lEuc0pmr45fHaTgwQ2VKA73WP9hzI)>NSudqlOzja: n6DL1XJTHQbi0ctSZksurjo5zOg = lEuc0pmr45fHaTgwQ2VKA73WP9hzI
	return n6DL1XJTHQbi0ctSZksurjo5zOg
def ZJPiId12qkesLNTvQW9H(PPtp5MCB7VaXlx6gvA):
	FUYe2Pr8dBGVo5fSm9nMyi = repr(PPtp5MCB7VaXlx6gvA.encode(m6PFtLblInpNZ8x)).replace(egY8Jti0smdLM3h1VQRSW(u"ࠦࠬࠨค"),eHdDoxhJCEPMZFVa2fg)
	return FUYe2Pr8dBGVo5fSm9nMyi
def iVAXFDQ0NpolPYOZ(I38h4BfysWbaMU):
	tAnDMWLq8xsKoZvP96u2EUOgTC = eHdDoxhJCEPMZFVa2fg
	if lHfbysRrUV7m4CLSdkxc382n: I38h4BfysWbaMU = I38h4BfysWbaMU.decode(m6PFtLblInpNZ8x)
	from unicodedata import decomposition as aQhjb3I1CW
	for WHqlF1n5zfQCBiukA in I38h4BfysWbaMU:
		if   WHqlF1n5zfQCBiukA==t3coAp06zvHrTl49bUVgx(u"ࡺ࠭ยࠨฅ"): Svq6Tgbx3GICMBrUtDk2fJNehcZ = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࡜࡝ࡷ࠳࠺࠷࠸ࠧฆ")
		elif WHqlF1n5zfQCBiukA==S8i3sBYoHWdTURpAgN(u"ࡵࠨลࠪง"): Svq6Tgbx3GICMBrUtDk2fJNehcZ = ietolwsjpIPK7Fr(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠴ࠩจ")
		elif WHqlF1n5zfQCBiukA==ehfEsaiJBSvbcULtNPVgykA2(u"ࡷࠪศࠬฉ"): Svq6Tgbx3GICMBrUtDk2fJNehcZ = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡠࡡࡻ࠰࠷࠴࠷ࠫช")
		elif WHqlF1n5zfQCBiukA==wY1p9mP03S8drbcH64t5WQkv(u"ࡹࠬหࠧซ"): Svq6Tgbx3GICMBrUtDk2fJNehcZ = NxXMrsTC5FniYuRBOK8(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠺࠭ฌ")
		elif WHqlF1n5zfQCBiukA==wY1p9mP03S8drbcH64t5WQkv(u"ࡻࠧวࠩญ"): Svq6Tgbx3GICMBrUtDk2fJNehcZ = RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠶ࠨฎ")
		else:
			MRfp3dCnhW = aQhjb3I1CW(WHqlF1n5zfQCBiukA)
			if avcfIls8w7gk69hYUErHxzQTXtm24j in MRfp3dCnhW: Svq6Tgbx3GICMBrUtDk2fJNehcZ = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨ࡞࡟ࡹࠬฏ")+MRfp3dCnhW.split(avcfIls8w7gk69hYUErHxzQTXtm24j,NSudqlOzja)[NSudqlOzja]
			else:
				Svq6Tgbx3GICMBrUtDk2fJNehcZ = wY1p9mP03S8drbcH64t5WQkv(u"ࠩ࠳࠴࠵࠶ࠧฐ")+hex(ord(WHqlF1n5zfQCBiukA)).replace(ehfEsaiJBSvbcULtNPVgykA2(u"ࠪ࠴ࡽ࠭ฑ"),eHdDoxhJCEPMZFVa2fg)
				Svq6Tgbx3GICMBrUtDk2fJNehcZ = KQ3sCe9Pzh(u"ࠫࡡࡢࡵࠨฒ")+Svq6Tgbx3GICMBrUtDk2fJNehcZ[-BSw5mizCOsKxWrRDvtJuFajY:]
		tAnDMWLq8xsKoZvP96u2EUOgTC += Svq6Tgbx3GICMBrUtDk2fJNehcZ
	tAnDMWLq8xsKoZvP96u2EUOgTC = tAnDMWLq8xsKoZvP96u2EUOgTC.replace(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡢ࡜ࡶ࠲࠹ࡇࡈ࠭ณ"),J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࡜࡝ࡷ࠳࠺࠹࠿ࠧด"))
	if lHfbysRrUV7m4CLSdkxc382n: tAnDMWLq8xsKoZvP96u2EUOgTC = tAnDMWLq8xsKoZvP96u2EUOgTC.decode(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨต")).encode(m6PFtLblInpNZ8x)
	else: tAnDMWLq8xsKoZvP96u2EUOgTC = tAnDMWLq8xsKoZvP96u2EUOgTC.encode(m6PFtLblInpNZ8x).decode(ietolwsjpIPK7Fr(u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩถ"))
	return tAnDMWLq8xsKoZvP96u2EUOgTC
def mJ1lHWKUPcZGezML7X2u9S(header=KQ3sCe9Pzh(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠩท"),c5tymh3W6Ba1OP=eHdDoxhJCEPMZFVa2fg,K2KZnJwbqASQNzprC=rDceXBpHkfVUYRJ3tIx95Z,source=eHdDoxhJCEPMZFVa2fg):
	oh8Z06rUdqJ = tjsH350uy7kAoFVGpriCXZ(header,c5tymh3W6Ba1OP,type=VVZgPQ2kYLoKe6jic5AEzqupG.INPUT_ALPHANUM)
	oh8Z06rUdqJ = oh8Z06rUdqJ.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	if not oh8Z06rUdqJ and not K2KZnJwbqASQNzprC:
		vR9cOpMtk51j(iwIlVQsgYezu,ietolwsjpIPK7Fr(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡤࡣࡱࡧࡪࡲࡥࡥ࠼ࠣࠤࠥࠨࠧธ")+oh8Z06rUdqJ+I5bUBGpPXn0W6(u"ࠫࠧ࠭น"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨบ"),LyOR7f69iA(u"࠭สๆࠢศ่฿อมࠡษ็ษิิวๅࠩป"))
		return eHdDoxhJCEPMZFVa2fg
	if oh8Z06rUdqJ not in [eHdDoxhJCEPMZFVa2fg,avcfIls8w7gk69hYUErHxzQTXtm24j]:
		oh8Z06rUdqJ = oh8Z06rUdqJ.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		oh8Z06rUdqJ = iVAXFDQ0NpolPYOZ(oh8Z06rUdqJ)
	if source!=KW5bYS20wTF1LyCs9(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔࠩผ") and ooJRESltFWHp5cxGOZMm61Ybr07(bP01xn84BiQN(u"ࠨࡍࡈ࡝ࡇࡕࡁࡓࡆࠪฝ"),eHdDoxhJCEPMZFVa2fg,[oh8Z06rUdqJ],rDceXBpHkfVUYRJ3tIx95Z):
		vR9cOpMtk51j(iwIlVQsgYezu,eNEhtuoi9gK8JaTpIXj(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠺ࠡࠢࠣࠦࠬพ")+oh8Z06rUdqJ+S8i3sBYoHWdTURpAgN(u"ࠪࠦࠬฟ"))
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧภ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧม"))
		return eHdDoxhJCEPMZFVa2fg
	vR9cOpMtk51j(iwIlVQsgYezu,ietolwsjpIPK7Fr(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩย")+oh8Z06rUdqJ+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࠣࠩร"))
	return oh8Z06rUdqJ
def YY02fhEdJNI5cCpw1nUMj(E1Viom5L3684CTOFJ,W9PzsMeLJTc83mS45G17n={}):
	FeTJrG4SkMf09iVys8A,RlwAKPOWevzUXQD,W4S9yzhJlXj3,f4GSARFs5WCJUVjdTQ31zc9guKb = E1Viom5L3684CTOFJ,{},{},eHdDoxhJCEPMZFVa2fg
	if Cp6c5tZe8I0PxnAW(u"ࠨࡾࠪฤ") in E1Viom5L3684CTOFJ: FeTJrG4SkMf09iVys8A,RlwAKPOWevzUXQD = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(E1Viom5L3684CTOFJ,I5bUBGpPXn0W6(u"ࠩࡿࠫล"))
	IIaRnouGj4 = list(set(list(W9PzsMeLJTc83mS45G17n.keys())+list(RlwAKPOWevzUXQD.keys())))
	for rBw5YZ31M7HOv in IIaRnouGj4:
		if rBw5YZ31M7HOv in list(RlwAKPOWevzUXQD.keys()): W4S9yzhJlXj3[rBw5YZ31M7HOv] = RlwAKPOWevzUXQD[rBw5YZ31M7HOv]
		else: W4S9yzhJlXj3[rBw5YZ31M7HOv] = W9PzsMeLJTc83mS45G17n[rBw5YZ31M7HOv]
	if ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧฦ") not in IIaRnouGj4: W4S9yzhJlXj3[w2vjZmdJuY7c(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨว")] = qq62QA8h3pGxzCwWVeXIF7glKf()
	if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ศ") not in IIaRnouGj4: W4S9yzhJlXj3[ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧษ")] = b31wAB8mhaz2rXHoJFlfvDugtsOj(FeTJrG4SkMf09iVys8A,KQ3sCe9Pzh(u"ࠧࡶࡴ࡯ࠫส"))
	if S8i3sBYoHWdTURpAgN(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪห") not in IIaRnouGj4: W4S9yzhJlXj3[KQ3sCe9Pzh(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫฬ")] = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼ࠫอ")
	for rBw5YZ31M7HOv in list(W4S9yzhJlXj3.keys()): f4GSARFs5WCJUVjdTQ31zc9guKb += w2vjZmdJuY7c(u"ࠫࠫ࠭ฮ")+rBw5YZ31M7HOv+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡃࠧฯ")+W4S9yzhJlXj3[rBw5YZ31M7HOv]
	if f4GSARFs5WCJUVjdTQ31zc9guKb: f4GSARFs5WCJUVjdTQ31zc9guKb = f90fGrlSEObDsuiA3U(u"࠭ࡼࠨะ")+f4GSARFs5WCJUVjdTQ31zc9guKb[NSudqlOzja:]
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(OclpauhMYPIx502SgUe1X7EWd,NxXMrsTC5FniYuRBOK8(u"ࠧࡈࡇࡗࠫั"),FeTJrG4SkMf09iVys8A,eHdDoxhJCEPMZFVa2fg,W4S9yzhJlXj3,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬา"),rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
	if bP01xn84BiQN(u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭ำ") not in a3glxPAGFXm2kzq: return [dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪ࠱࠶࠭ิ")],[FeTJrG4SkMf09iVys8A+f4GSARFs5WCJUVjdTQ31zc9guKb]
	if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࡙ࠫ࡟ࡐࡆ࠿ࡄ࡙ࡉࡏࡏࠨี") in a3glxPAGFXm2kzq: return [egY8Jti0smdLM3h1VQRSW(u"ࠬ࠳࠱ࠨึ")],[FeTJrG4SkMf09iVys8A+f4GSARFs5WCJUVjdTQ31zc9guKb]
	if TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡔ࡚ࡒࡈࡁ࡛ࡏࡄࡆࡑࠪื") in a3glxPAGFXm2kzq: return [CKUiyEe28zsZ(u"ࠧ࠮࠳ุࠪ")],[FeTJrG4SkMf09iVys8A+f4GSARFs5WCJUVjdTQ31zc9guKb]
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,nbgWP2BCuiQA4xZOKl67YXvTdwGpE,jfus7z2teU81m3bNGkMvWJwShX = [],[],[],[]
	a0VHgjbCY1KfuI6o = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠨࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ูࠬࠩ"),a3glxPAGFXm2kzq+kDUv7ouWrcgMe6OipQJm,cBawilJXvK1m.DOTALL)
	if not a0VHgjbCY1KfuI6o: return [CKUiyEe28zsZ(u"ࠩ࠰࠵ฺࠬ")],[FeTJrG4SkMf09iVys8A+f4GSARFs5WCJUVjdTQ31zc9guKb]
	for RFs8k3UxnlTaNu4EGBJderbK1X,GUk97EVcihOnsxQgJ8W in a0VHgjbCY1KfuI6o:
		PpEkBVayfCmHLSFg,PHrtMU1sgahiE,s0s2bIZtWx8w3 = {},-GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠶ᎄ"),-GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠶ᎄ")
		BgIDUST0X1 = eHdDoxhJCEPMZFVa2fg
		Ty8qgdR02arW1VpLSHefNXbhF = RFs8k3UxnlTaNu4EGBJderbK1X.split(HkiMU0QrdzW3l6gwnT(u"ࠪ࠰ࠬ฻"))
		for KKeiYLQO4vH3yskhbG in Ty8qgdR02arW1VpLSHefNXbhF:
			if t3coAp06zvHrTl49bUVgx(u"ࠫࡂ࠭฼") in KKeiYLQO4vH3yskhbG:
				rBw5YZ31M7HOv,zwLjnRNHpA6a = KKeiYLQO4vH3yskhbG.split(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡃࠧ฽"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠷ᎅ"))
				PpEkBVayfCmHLSFg[rBw5YZ31M7HOv.lower()] = zwLjnRNHpA6a
		if ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ฾") in RFs8k3UxnlTaNu4EGBJderbK1X.lower():
			PHrtMU1sgahiE = int(PpEkBVayfCmHLSFg[f90fGrlSEObDsuiA3U(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ฿")])//LyOR7f69iA(u"࠱࠱࠴࠷ᎆ")
			BgIDUST0X1 += str(PHrtMU1sgahiE)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨเ")
		elif w2vjZmdJuY7c(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬแ") in RFs8k3UxnlTaNu4EGBJderbK1X.lower():
			PHrtMU1sgahiE = int(PpEkBVayfCmHLSFg[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭โ")])//Cp6c5tZe8I0PxnAW(u"࠲࠲࠵࠸ᎇ")
			BgIDUST0X1 += str(PHrtMU1sgahiE)+ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡰࡨࡰࡴࠢࠣࠫใ")
		if bP01xn84BiQN(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩไ") in RFs8k3UxnlTaNu4EGBJderbK1X.lower():
			s0s2bIZtWx8w3 = int(PpEkBVayfCmHLSFg[XugxFprC26zGM(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰࠪๅ")].split(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡹࠩๆ"))[NSudqlOzja])
			BgIDUST0X1 += str(s0s2bIZtWx8w3)+KwJyZLDzC4FbHhXgTfI
		BgIDUST0X1 = BgIDUST0X1.strip(KwJyZLDzC4FbHhXgTfI)
		if not BgIDUST0X1: BgIDUST0X1 = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩ็")
		if not GUk97EVcihOnsxQgJ8W.startswith(ehfEsaiJBSvbcULtNPVgykA2(u"ࠩ࡫ࡸࡹࡶ่ࠧ")):
			if GUk97EVcihOnsxQgJ8W.startswith(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪ࠳࠴้࠭")): GUk97EVcihOnsxQgJ8W = FeTJrG4SkMf09iVys8A.split(CKUiyEe28zsZ(u"ࠫ࠿๊࠭"),NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]+ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡀ๋ࠧ")+GUk97EVcihOnsxQgJ8W
			elif GUk97EVcihOnsxQgJ8W.startswith(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭࠯ࠨ์")): GUk97EVcihOnsxQgJ8W = b31wAB8mhaz2rXHoJFlfvDugtsOj(FeTJrG4SkMf09iVys8A,HkiMU0QrdzW3l6gwnT(u"ࠧࡶࡴ࡯ࠫํ"))+GUk97EVcihOnsxQgJ8W
			else: GUk97EVcihOnsxQgJ8W = FeTJrG4SkMf09iVys8A.rsplit(jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ࠱ࠪ๎"),NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]+jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࠲ࠫ๏")+GUk97EVcihOnsxQgJ8W
		if XugxFprC26zGM(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ๐") in list(PpEkBVayfCmHLSFg.keys()):
			bmsN7D3kPQ8Beh5RS0M4ng2FcY = PpEkBVayfCmHLSFg[XugxFprC26zGM(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭๑")]
			bmsN7D3kPQ8Beh5RS0M4ng2FcY = bmsN7D3kPQ8Beh5RS0M4ng2FcY.replace(KQ3sCe9Pzh(u"ࠬࠨࠧ๒"),eHdDoxhJCEPMZFVa2fg).replace(XugxFprC26zGM(u"ࠨࠧࠣ๓"),eHdDoxhJCEPMZFVa2fg).split(Cp6c5tZe8I0PxnAW(u"ࠧࠤࠩ๔"),NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]
			JGtX1fiayl9R = llr1C3SIFjViqLDtZP(bmsN7D3kPQ8Beh5RS0M4ng2FcY)
			if JGtX1fiayl9R: uVpKOk8ZM0LvQ6UI = BgIDUST0X1+KwJyZLDzC4FbHhXgTfI+JGtX1fiayl9R
			else: uVpKOk8ZM0LvQ6UI = BgIDUST0X1
			uVpKOk8ZM0LvQ6UI = uVpKOk8ZM0LvQ6UI+ietolwsjpIPK7Fr(u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨ๕")
			uVpKOk8ZM0LvQ6UI = uVpKOk8ZM0LvQ6UI+KwJyZLDzC4FbHhXgTfI+b31wAB8mhaz2rXHoJFlfvDugtsOj(bmsN7D3kPQ8Beh5RS0M4ng2FcY,Cp6c5tZe8I0PxnAW(u"ࠩࡱࡥࡲ࡫ࠧ๖"))
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(uVpKOk8ZM0LvQ6UI)
			ppQOjlq2gaPkW.append(bmsN7D3kPQ8Beh5RS0M4ng2FcY)
			nbgWP2BCuiQA4xZOKl67YXvTdwGpE.append(s0s2bIZtWx8w3)
			jfus7z2teU81m3bNGkMvWJwShX.append(PHrtMU1sgahiE)
		GUk97EVcihOnsxQgJ8W = GUk97EVcihOnsxQgJ8W.split(bP01xn84BiQN(u"ࠪࠧࠬ๗"),NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]
		JGtX1fiayl9R = llr1C3SIFjViqLDtZP(GUk97EVcihOnsxQgJ8W)
		if JGtX1fiayl9R: BgIDUST0X1 = BgIDUST0X1+KwJyZLDzC4FbHhXgTfI+JGtX1fiayl9R
		BgIDUST0X1 = BgIDUST0X1+KwJyZLDzC4FbHhXgTfI+b31wAB8mhaz2rXHoJFlfvDugtsOj(GUk97EVcihOnsxQgJ8W,NxXMrsTC5FniYuRBOK8(u"ࠫࡳࡧ࡭ࡦࠩ๘"))
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(BgIDUST0X1)
		ppQOjlq2gaPkW.append(GUk97EVcihOnsxQgJ8W)
		nbgWP2BCuiQA4xZOKl67YXvTdwGpE.append(s0s2bIZtWx8w3)
		jfus7z2teU81m3bNGkMvWJwShX.append(PHrtMU1sgahiE)
	FbL9lHaTVANMPd7hDJcw2o8QEX1mqu = list(zip(FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,nbgWP2BCuiQA4xZOKl67YXvTdwGpE,jfus7z2teU81m3bNGkMvWJwShX))
	FbL9lHaTVANMPd7hDJcw2o8QEX1mqu = sorted(FbL9lHaTVANMPd7hDJcw2o8QEX1mqu, reverse=YchIv6N09BaWPEj4tieAnluKZrRXT, key=lambda key: key[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1])
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,nbgWP2BCuiQA4xZOKl67YXvTdwGpE,jfus7z2teU81m3bNGkMvWJwShX = list(zip(*FbL9lHaTVANMPd7hDJcw2o8QEX1mqu))
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = list(FBITEXGDfe2mcCxnQs6ktMdy9HJh),list(ppQOjlq2gaPkW)
	e8UJpoK72tOlWfr0wRs3BA9xn = []
	for GUk97EVcihOnsxQgJ8W in ppQOjlq2gaPkW: e8UJpoK72tOlWfr0wRs3BA9xn.append(GUk97EVcihOnsxQgJ8W+f4GSARFs5WCJUVjdTQ31zc9guKb)
	return FBITEXGDfe2mcCxnQs6ktMdy9HJh,e8UJpoK72tOlWfr0wRs3BA9xn
def yyjtMgopD2QqA9J1Ki3E8WzcUlx4uB(RgkzMx9Fc3ZtUJmrG1pqIEf,uJinrVBe7MAY3=eHdDoxhJCEPMZFVa2fg):
	if not uJinrVBe7MAY3: uJinrVBe7MAY3 = MOnQlAXkSV8vb2sDyWdtPzBU1ea[x1Oa8bBf36EwsLMirtFc]
	if RgkzMx9Fc3ZtUJmrG1pqIEf.replace(NxXMrsTC5FniYuRBOK8(u"ࠬ࠴ࠧ๙"),eHdDoxhJCEPMZFVa2fg).isdigit(): return [RgkzMx9Fc3ZtUJmrG1pqIEf]
	from struct import pack as cfSlvaouQtPVHi,unpack_from as yUuwhYLbDNSmxHgX
	from socket import socket as d8ERXc2O9NADu,AF_INET as H28fb4Yg1GA3,SOCK_DGRAM as T7XSaWCLsME
	try:
		U03f2nxRoWE8crzhMF1Sq = cfSlvaouQtPVHi(t3coAp06zvHrTl49bUVgx(u"ࠨ࠾ࡉࠤ๚"), dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠳࠵࠴࠹࠿ᎈ"))
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(f90fGrlSEObDsuiA3U(u"ࠢ࠿ࡊࠥ๛"), RqLvTrID0yMVeClpYcnZ16i3X(u"࠵࠹࠻ᎉ"))
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠣࡀࡋࠦ๜"), NSudqlOzja)
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(NxXMrsTC5FniYuRBOK8(u"ࠤࡁࡌࠧ๝"), x1Oa8bBf36EwsLMirtFc)
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(ilBWK5nXxg1do4jENGC07Zq(u"ࠥࡂࡍࠨ๞"), x1Oa8bBf36EwsLMirtFc)
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠦࡃࡎࠢ๟"), x1Oa8bBf36EwsLMirtFc)
		if WHjh1POtMKlmgiy68RSqb: cgTks1L9wBHWeGUKCQ2S7mihI0PxRV = RgkzMx9Fc3ZtUJmrG1pqIEf.split(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬ࠴ࠧ๠"))
		else: cgTks1L9wBHWeGUKCQ2S7mihI0PxRV = RgkzMx9Fc3ZtUJmrG1pqIEf.decode(m6PFtLblInpNZ8x).split(eNEhtuoi9gK8JaTpIXj(u"࠭࠮ࠨ๡"))
		for DIkSzwOoy7FnmBT6Rga in cgTks1L9wBHWeGUKCQ2S7mihI0PxRV:
			sgAtq5bOkc = DIkSzwOoy7FnmBT6Rga.encode(m6PFtLblInpNZ8x)
			U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(NxXMrsTC5FniYuRBOK8(u"ࠢࡃࠤ๢"), len(DIkSzwOoy7FnmBT6Rga))
			for U40PWHphtoaucjOGzYKAJyV7BLnCEs in DIkSzwOoy7FnmBT6Rga:
				U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠣࡥࠥ๣"), U40PWHphtoaucjOGzYKAJyV7BLnCEs.encode(m6PFtLblInpNZ8x))
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(w2vjZmdJuY7c(u"ࠤࡅࠦ๤"), x1Oa8bBf36EwsLMirtFc)
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠥࡂࡍࠨ๥"), NSudqlOzja)
		U03f2nxRoWE8crzhMF1Sq += cfSlvaouQtPVHi(eNEhtuoi9gK8JaTpIXj(u"ࠦࡃࡎࠢ๦"), NSudqlOzja)
		Y8Ytw7g42Tl1NB5is9fnJL = d8ERXc2O9NADu(H28fb4Yg1GA3,T7XSaWCLsME)
		Y8Ytw7g42Tl1NB5is9fnJL.sendto(bytes(U03f2nxRoWE8crzhMF1Sq), (uJinrVBe7MAY3, ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠹࠸ᎊ")))
		Y8Ytw7g42Tl1NB5is9fnJL.settimeout(KW5bYS20wTF1LyCs9(u"࠻ᎋ"))
		KhGpZcMqsnrbv, PfcvqOZS2RCkoEj7im0hYIg4n = Y8Ytw7g42Tl1NB5is9fnJL.recvfrom(f90fGrlSEObDsuiA3U(u"࠷࠰࠳࠶ᎌ"))
		Y8Ytw7g42Tl1NB5is9fnJL.close()
		Q7VojP2HTSgqxum135I9d = yUuwhYLbDNSmxHgX(ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡄࡈࡉࡊࡋࡌࡍࠨ๧"), KhGpZcMqsnrbv, x1Oa8bBf36EwsLMirtFc)
		rgyGEBsOLkh27ImwJlH4 = Q7VojP2HTSgqxum135I9d[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
		oimSThujJ4wkD3XGERWUNpPQfv7Iea = len(RgkzMx9Fc3ZtUJmrG1pqIEf)+f90fGrlSEObDsuiA3U(u"࠱࠹ᎍ")
		Geo8WC6xHmhPAwQMXpZd = []
		for _EaNMBeWzgqn3pyYZ9D6lhoT in range(rgyGEBsOLkh27ImwJlH4):
			ElUQgcKMos836DkB = oimSThujJ4wkD3XGERWUNpPQfv7Iea
			h0tvKU3XF6ZMPNQaB1bx = NSudqlOzja
			MMNQoWLcKwJ5 = rDceXBpHkfVUYRJ3tIx95Z
			while YchIv6N09BaWPEj4tieAnluKZrRXT:
				U40PWHphtoaucjOGzYKAJyV7BLnCEs = yUuwhYLbDNSmxHgX(NxXMrsTC5FniYuRBOK8(u"ࠨ࠾ࡃࠤ๨"), KhGpZcMqsnrbv, ElUQgcKMos836DkB)[x1Oa8bBf36EwsLMirtFc]
				if U40PWHphtoaucjOGzYKAJyV7BLnCEs == x1Oa8bBf36EwsLMirtFc:
					ElUQgcKMos836DkB += NSudqlOzja
					break
				if U40PWHphtoaucjOGzYKAJyV7BLnCEs >= ehfEsaiJBSvbcULtNPVgykA2(u"࠲࠻࠵ᎎ"):
					lSKZsRN6JoDjfp2btdnIc = yUuwhYLbDNSmxHgX(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠢ࠿ࡄࠥ๩"), KhGpZcMqsnrbv, ElUQgcKMos836DkB + NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]
					ElUQgcKMos836DkB = ((U40PWHphtoaucjOGzYKAJyV7BLnCEs << GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠺ᎏ")) + lSKZsRN6JoDjfp2btdnIc - 0xc000) - NSudqlOzja
					MMNQoWLcKwJ5 = YchIv6N09BaWPEj4tieAnluKZrRXT
				ElUQgcKMos836DkB += NSudqlOzja
				if MMNQoWLcKwJ5 == rDceXBpHkfVUYRJ3tIx95Z: h0tvKU3XF6ZMPNQaB1bx += NSudqlOzja
			if MMNQoWLcKwJ5 == YchIv6N09BaWPEj4tieAnluKZrRXT: h0tvKU3XF6ZMPNQaB1bx += NSudqlOzja
			oimSThujJ4wkD3XGERWUNpPQfv7Iea = oimSThujJ4wkD3XGERWUNpPQfv7Iea + h0tvKU3XF6ZMPNQaB1bx
			FWAX4qVGmH = yUuwhYLbDNSmxHgX(NxXMrsTC5FniYuRBOK8(u"ࠣࡀࡋࡌࡎࡎࠢ๪"), KhGpZcMqsnrbv, oimSThujJ4wkD3XGERWUNpPQfv7Iea)
			oimSThujJ4wkD3XGERWUNpPQfv7Iea = oimSThujJ4wkD3XGERWUNpPQfv7Iea + jUcmHhgVvW0EdYOIfXeaDF(u"࠴࠴᎐")
			HcuXt2YzTwD = FWAX4qVGmH[x1Oa8bBf36EwsLMirtFc]
			llHUurzw75XvLspqZ9PJOkA = FWAX4qVGmH[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
			if HcuXt2YzTwD == NSudqlOzja:
				Z2Am0pr8cNYElFC3G4x = yUuwhYLbDNSmxHgX(jUcmHhgVvW0EdYOIfXeaDF(u"ࠤࡁࠦ๫")+I5bUBGpPXn0W6(u"ࠥࡆࠧ๬")*llHUurzw75XvLspqZ9PJOkA, KhGpZcMqsnrbv, oimSThujJ4wkD3XGERWUNpPQfv7Iea)
				ip = eHdDoxhJCEPMZFVa2fg
				for U40PWHphtoaucjOGzYKAJyV7BLnCEs in Z2Am0pr8cNYElFC3G4x: ip += str(U40PWHphtoaucjOGzYKAJyV7BLnCEs) + EX25Y0l8ILvz7QcRC(u"ࠫ࠳࠭๭")
				ip = ip[x1Oa8bBf36EwsLMirtFc:-NSudqlOzja]
				Geo8WC6xHmhPAwQMXpZd.append(ip)
			if HcuXt2YzTwD in [NSudqlOzja,FB0pIzAoK8wqgd3UiY5,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠻᎓"),t3coAp06zvHrTl49bUVgx(u"࠶᎔"),NxXMrsTC5FniYuRBOK8(u"࠶࠻᎒"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠶࠽᎑")]: oimSThujJ4wkD3XGERWUNpPQfv7Iea = oimSThujJ4wkD3XGERWUNpPQfv7Iea + llHUurzw75XvLspqZ9PJOkA
	except: Geo8WC6xHmhPAwQMXpZd = []
	if not Geo8WC6xHmhPAwQMXpZd: vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࠦࠠࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠠࡧࡣ࡬ࡰࡪࡪࠠࠡࠢࡋࡳࡸࡺ࠺ࠡ࡝ࠣࠫ๮")+RgkzMx9Fc3ZtUJmrG1pqIEf+jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࠠ࡞ࠩ๯"))
	return Geo8WC6xHmhPAwQMXpZd
def ooJRESltFWHp5cxGOZMm61Ybr07(EERWJf1adv67,FeTJrG4SkMf09iVys8A,i2qmOCHN5goZ,showDialogs=YchIv6N09BaWPEj4tieAnluKZrRXT):
	if i2qmOCHN5goZ:
		awFlDk4qm0xz6McUu13pQrJSfP = [w2vjZmdJuY7c(u"ࠧไสสีࠬ๰"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠨสส่฿࠭๱"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡤࡨࡺࡲࡴࠨ๲"),eNEhtuoi9gK8JaTpIXj(u"ࠪࡼࡽ࠭๳"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡸ࡫ࡸࠨ๴")]
		if EERWJf1adv67!=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡈࡏࡌࡔࡄࠫ๵"):
			awFlDk4qm0xz6McUu13pQrJSfP += [KQ3sCe9Pzh(u"࠭ࡲ࠻ࠩ๶"),HkiMU0QrdzW3l6gwnT(u"ࠧࡳ࠯ࠪ๷"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨ࠯ࡰࡥࠬ๸")]
			awFlDk4qm0xz6McUu13pQrJSfP += [wY1p9mP03S8drbcH64t5WQkv(u"ࠩ࠽ࡶࠬ๹"),LyOR7f69iA(u"ࠪ࠱ࡷ࠭๺"),bP01xn84BiQN(u"ࠫࡲࡧ࠭ࠨ๻")]
		for FTiGWEHst5zpjKmwN1yRge in i2qmOCHN5goZ:
			if f90fGrlSEObDsuiA3U(u"ࠬ࡭ࡥࡵ࠰ࡳ࡬ࡵࡅࠧ๼") in FTiGWEHst5zpjKmwN1yRge: continue
			if ietolwsjpIPK7Fr(u"࠭อๅไฬࠫ๽") in FTiGWEHst5zpjKmwN1yRge: continue
			FTiGWEHst5zpjKmwN1yRge = FTiGWEHst5zpjKmwN1yRge.lower()
			if lHfbysRrUV7m4CLSdkxc382n: FTiGWEHst5zpjKmwN1yRge = FTiGWEHst5zpjKmwN1yRge.decode(m6PFtLblInpNZ8x).encode(m6PFtLblInpNZ8x)
			FTiGWEHst5zpjKmwN1yRge = FTiGWEHst5zpjKmwN1yRge.replace(S8i3sBYoHWdTURpAgN(u"ࠧ࠻ࠩ๾"),eHdDoxhJCEPMZFVa2fg)
			qWGgUiNb1eOcFBV = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠨࠪ࠴࡟࠺࠳࠹࡞࠭ࡿ࠶ࡠ࠶࠭࠴࡟࠮࠭ࠬ๿"),FTiGWEHst5zpjKmwN1yRge,cBawilJXvK1m.DOTALL)
			tyLlwpSr1MZHQvKjfVm0ahY3g = rDceXBpHkfVUYRJ3tIx95Z
			for lL96kyw4DTzPorJuBKIvqgtfe in qWGgUiNb1eOcFBV:
				if len(lL96kyw4DTzPorJuBKIvqgtfe)==FB0pIzAoK8wqgd3UiY5:
					tyLlwpSr1MZHQvKjfVm0ahY3g = YchIv6N09BaWPEj4tieAnluKZrRXT
					break
			if RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡱࡳࡹࠦࡲࡢࡶࡨࡨࠬ຀") in FTiGWEHst5zpjKmwN1yRge: continue
			elif S8i3sBYoHWdTURpAgN(u"ࠪࡹࡳࡸࡡࡵࡧࡧࠫກ") in FTiGWEHst5zpjKmwN1yRge: continue
			elif egY8Jti0smdLM3h1VQRSW(u"ࠫ฿๐ัࠡ็ุ๊ๆ࠭ຂ") in FTiGWEHst5zpjKmwN1yRge: continue
			elif BoGNtDIVHAyw([NxXMrsTC5FniYuRBOK8(u"ࠬࡈࡔࡆࡺࡓ࡚࠶࠿ࡓࡓࡘࡑ࡙࡚ࡲࡖࡅࡘࡈ࡚ࡊ࡞ࠧ຃")])[x1Oa8bBf36EwsLMirtFc]: continue
			elif FTiGWEHst5zpjKmwN1yRge in [iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡲࠨຄ")] or tyLlwpSr1MZHQvKjfVm0ahY3g or any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in FTiGWEHst5zpjKmwN1yRge for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in awFlDk4qm0xz6McUu13pQrJSfP):
				vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࠡࠢࠣࡆࡱࡵࡣ࡬ࡧࡧࠤࡦࡪࡵ࡭ࡶࡶࠤࡻ࡯ࡤࡦࡱࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭຅")+FeTJrG4SkMf09iVys8A+KW5bYS20wTF1LyCs9(u"ࠨࠢࡠࠫຆ"))
				if showDialogs: dqKGMYgJxSF8Ub1kotlsP936Ww7B(KQ3sCe9Pzh(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬງ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪห้็๊ะ์๋ࠤ้๊ใษษิࠤๆ่ื๊ࠡฦ๊ฬࠦๅ็฻อ๋ࠬຈ"))
				return YchIv6N09BaWPEj4tieAnluKZrRXT
	return rDceXBpHkfVUYRJ3tIx95Z
def dXINKZJp6Tbu7wmS(*aargs,**kkwargs):
	if aargs:
		direction = aargs[x1Oa8bBf36EwsLMirtFc]
		jtvkg7nKcpCuofIG2E8ybd5zrL4x = aargs[NSudqlOzja]
		if not direction: direction = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫຉ")
		if not jtvkg7nKcpCuofIG2E8ybd5zrL4x: jtvkg7nKcpCuofIG2E8ybd5zrL4x = LyOR7f69iA(u"ࠬอำห็ิหึ࠭ຊ")
		HXJqSAUvb6Zuw7VEiN4RKeP25L = aargs[FB0pIzAoK8wqgd3UiY5]
		oh8Z06rUdqJ = kDUv7ouWrcgMe6OipQJm.join(aargs[TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠴᎕"):])
	else: direction,jtvkg7nKcpCuofIG2E8ybd5zrL4x,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ = eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡏࡌࠩ຋"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	vKD1rqZCXUbcR7n38VyatMSEL(direction,eHdDoxhJCEPMZFVa2fg,jtvkg7nKcpCuofIG2E8ybd5zrL4x,eHdDoxhJCEPMZFVa2fg,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,**kkwargs)
	return
def VinwUNFtrZTh0oPs2zm(*aargs,**kkwargs):
	direction = aargs[x1Oa8bBf36EwsLMirtFc]
	wwojSriWpGh9HZ = aargs[NSudqlOzja]
	cluODSUqmT2aAFhXNkg = aargs[FB0pIzAoK8wqgd3UiY5]
	if cluODSUqmT2aAFhXNkg or wwojSriWpGh9HZ: vvKkopXNhHV3n5JeEAwFSPg8Yy = YchIv6N09BaWPEj4tieAnluKZrRXT
	else: vvKkopXNhHV3n5JeEAwFSPg8Yy = rDceXBpHkfVUYRJ3tIx95Z
	HXJqSAUvb6Zuw7VEiN4RKeP25L = aargs[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
	oh8Z06rUdqJ = aargs[BSw5mizCOsKxWrRDvtJuFajY]
	if not direction: direction = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧࡤࡧࡱࡸࡪࡸࠧຌ")
	if not wwojSriWpGh9HZ: wwojSriWpGh9HZ = LyOR7f69iA(u"ࠨๅ็หࠥࠦࡎࡰࠩຍ")
	if not cluODSUqmT2aAFhXNkg: cluODSUqmT2aAFhXNkg = bP01xn84BiQN(u"้ࠩ฽๊࡚ࠦࠠࡧࡶࠫຎ")
	if len(aargs)>=LyOR7f69iA(u"࠹᎗"): oh8Z06rUdqJ += kDUv7ouWrcgMe6OipQJm+aargs[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷᎖")]
	if len(aargs)>=ietolwsjpIPK7Fr(u"࠻᎘"): oh8Z06rUdqJ += kDUv7ouWrcgMe6OipQJm+aargs[EX25Y0l8ILvz7QcRC(u"࠻᎙")]
	jF1DqR2Y3VrIShwBeOpco = vKD1rqZCXUbcR7n38VyatMSEL(direction,wwojSriWpGh9HZ,eHdDoxhJCEPMZFVa2fg,cluODSUqmT2aAFhXNkg,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,**kkwargs)
	if jF1DqR2Y3VrIShwBeOpco==-egY8Jti0smdLM3h1VQRSW(u"࠷᎚") and vvKkopXNhHV3n5JeEAwFSPg8Yy: jF1DqR2Y3VrIShwBeOpco = -NSudqlOzja
	elif jF1DqR2Y3VrIShwBeOpco==-NSudqlOzja and not vvKkopXNhHV3n5JeEAwFSPg8Yy: jF1DqR2Y3VrIShwBeOpco = rDceXBpHkfVUYRJ3tIx95Z
	elif jF1DqR2Y3VrIShwBeOpco==x1Oa8bBf36EwsLMirtFc: jF1DqR2Y3VrIShwBeOpco = rDceXBpHkfVUYRJ3tIx95Z
	elif jF1DqR2Y3VrIShwBeOpco==FB0pIzAoK8wqgd3UiY5: jF1DqR2Y3VrIShwBeOpco = YchIv6N09BaWPEj4tieAnluKZrRXT
	return jF1DqR2Y3VrIShwBeOpco
def ZZhzstQTSCXRg(*aargs,**kkwargs):
	return VVZgPQ2kYLoKe6jic5AEzqupG.Dialog().select(*aargs,**kkwargs)
def dqKGMYgJxSF8Ub1kotlsP936Ww7B(*aargs,**kkwargs):
	HXJqSAUvb6Zuw7VEiN4RKeP25L = aargs[x1Oa8bBf36EwsLMirtFc]
	oh8Z06rUdqJ = aargs[NSudqlOzja]
	SSMd3j4XuVm9 = kkwargs[ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡸ࡮ࡳࡥࠨຏ")] if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡹ࡯࡭ࡦࠩຐ") in list(kkwargs.keys()) else eNEhtuoi9gK8JaTpIXj(u"࠱࠱࠲࠳᎛")
	dDGYI9w0cmViU4JyrL7pNHSZPufh = aargs[FB0pIzAoK8wqgd3UiY5] if len(aargs)>FB0pIzAoK8wqgd3UiY5 and bP01xn84BiQN(u"ࠬࡺࡩ࡮ࡧࠪຑ") not in aargs[FB0pIzAoK8wqgd3UiY5] else LTN6DPEmrwehtZMy(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤࡸࡥࡨࡷ࡯ࡥࡷ࠭ຒ")
	MX7jv1alGO3chAgBzTSCIqVpk = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=l3qFQZDhdjreszCi8a6kXToSPnLYHJ,args=(HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,dDGYI9w0cmViU4JyrL7pNHSZPufh,SSMd3j4XuVm9))
	MX7jv1alGO3chAgBzTSCIqVpk.start()
	return
def l3qFQZDhdjreszCi8a6kXToSPnLYHJ(HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,dDGYI9w0cmViU4JyrL7pNHSZPufh,SSMd3j4XuVm9):
	aD4JUECo7BAlOwjzVTPrR52ey8imZk = dDGYI9w0cmViU4JyrL7pNHSZPufh.replace(KW5bYS20wTF1LyCs9(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࠧຓ"),eHdDoxhJCEPMZFVa2fg)
	name = r17Z5qKTw3gQ(aD4JUECo7BAlOwjzVTPrR52ey8imZk+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࠢ࠰ࠤࠬດ")+HXJqSAUvb6Zuw7VEiN4RKeP25L+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࠣ࠱ࠥ࠭ຕ")+oh8Z06rUdqJ)
	name = gTFGf5IRwYWns8QHcKzoBAvC(name)
	image_filename = RRydns1CErYlIhwSx7.path.join(eejL7TCmrFBoyaq,name+Cp6c5tZe8I0PxnAW(u"ࠪ࠲ࡵࡴࡧࠨຖ"))
	if RRydns1CErYlIhwSx7.path.exists(image_filename):
		if dDGYI9w0cmViU4JyrL7pNHSZPufh==ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡶࡪ࡭ࡵ࡭ࡣࡵࠫທ"): image_height = wY1p9mP03S8drbcH64t5WQkv(u"࠲࠳࠺᎜")
		elif dDGYI9w0cmViU4JyrL7pNHSZPufh==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡦࡻࡴࡰࠩຘ"): image_height = egY8Jti0smdLM3h1VQRSW(u"࠴࠴࠴᎝")
	else: image_height = Ge4XfaYx3t1(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,dDGYI9w0cmViU4JyrL7pNHSZPufh,KW5bYS20wTF1LyCs9(u"࠭࡬ࡦࡨࡷࠫນ"),rDceXBpHkfVUYRJ3tIx95Z,image_filename)
	HjZfiB1INbTGuQ = kUJmKtWGNH8p5OjA2MPrZQ9I0zeTVa(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡎࡳࡡࡨࡧ࠱ࡼࡲࡲࠧບ"),lAf7eTIozDOK0arHsmWx,S8i3sBYoHWdTURpAgN(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩປ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩ࠺࠶࠵ࡶࠧຜ"))
	HjZfiB1INbTGuQ.show()
	if dDGYI9w0cmViU4JyrL7pNHSZPufh==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡤࡹࡹࡵࠧຝ"):
		HjZfiB1INbTGuQ.getControl(jUcmHhgVvW0EdYOIfXeaDF(u"࠽࠵࠺࠰᎟")).setHeight(t3coAp06zvHrTl49bUVgx(u"࠵࠵࠺᎞"))
		HjZfiB1INbTGuQ.getControl(RqLvTrID0yMVeClpYcnZ16i3X(u"࠹࠱࠶࠳Ꭲ")).setPosition(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠺࠻Ꭰ"),-I5bUBGpPXn0W6(u"࠾࠰Ꭱ"))
		HjZfiB1INbTGuQ.getControl(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠺࠲࠸࠴Ꭳ")).setPosition(Cp6c5tZe8I0PxnAW(u"࠳࠵࠴Ꭴ"),-TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠹࠴Ꭵ"))
		HjZfiB1INbTGuQ.getControl(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠺࠰࠱Ꭸ")).setPosition(J7divaGOCgq2SLfXpDzZYN58wc(u"࠽࠵Ꭶ"),-ilBWK5nXxg1do4jENGC07Zq(u"࠸࠻Ꭷ"))
	HjZfiB1INbTGuQ.getControl(J7divaGOCgq2SLfXpDzZYN58wc(u"࠴࠱࠳Ꭹ")).setVisible(rDceXBpHkfVUYRJ3tIx95Z)
	HjZfiB1INbTGuQ.getControl(S8i3sBYoHWdTURpAgN(u"࠵࠲࠵Ꭺ")).setVisible(rDceXBpHkfVUYRJ3tIx95Z)
	HjZfiB1INbTGuQ.getControl(NxXMrsTC5FniYuRBOK8(u"࠻࠳࠹࠵Ꭻ")).setImage(image_filename)
	HjZfiB1INbTGuQ.getControl(f90fGrlSEObDsuiA3U(u"࠼࠴࠺࠶Ꭼ")).setHeight(image_height)
	b8bLFaejUB.sleep(SSMd3j4XuVm9//J7divaGOCgq2SLfXpDzZYN58wc(u"࠵࠵࠶࠰࠯࠲Ꭽ"))
	return
def lZGwNzPT1m9i2XJEW4tqKeDjA75a(*aargs,**kkwargs):
	HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,profile,direction = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬພ"),CKUiyEe28zsZ(u"ࠬࡲࡥࡧࡶࠪຟ")
	if len(aargs)>=NSudqlOzja: HXJqSAUvb6Zuw7VEiN4RKeP25L = aargs[x1Oa8bBf36EwsLMirtFc]
	if len(aargs)>=FB0pIzAoK8wqgd3UiY5: oh8Z06rUdqJ = aargs[NSudqlOzja]
	if len(aargs)>=bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1: profile = aargs[FB0pIzAoK8wqgd3UiY5]
	if len(aargs)>=BSw5mizCOsKxWrRDvtJuFajY: direction = aargs[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
	return YTUtDCvHs6eQEPi1FJ(direction,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,profile)
def ToWx9yLluKgEASQDt(*aargs,**kkwargs):
	return VVZgPQ2kYLoKe6jic5AEzqupG.Dialog().contextmenu(*aargs,**kkwargs)
def QQXiBT8HLl4PY(*aargs,**kkwargs):
	return VVZgPQ2kYLoKe6jic5AEzqupG.Dialog().browseSingle(*aargs,**kkwargs)
def tjsH350uy7kAoFVGpriCXZ(*aargs,**kkwargs):
	return VVZgPQ2kYLoKe6jic5AEzqupG.Dialog().input(*aargs,**kkwargs)
def R62V7GXNPvf8(*aargs,**kkwargs):
	return VVZgPQ2kYLoKe6jic5AEzqupG.DialogProgress(*aargs,**kkwargs)
def mOoylMuTX7VUjNJq6YK4(mmVLwCF48UBTcf3NyO5Rq):
	global XJZYzUxcCNq31
	ZEihvxcN7XBjIrT4YytVmFgP1 = mmVLwCF48UBTcf3NyO5Rq==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡳࡵࡣࡵࡸࠬຠ") and not XJZYzUxcCNq31
	HHVLQX4TlGu9m = mmVLwCF48UBTcf3NyO5Rq==LyOR7f69iA(u"ࠧࡴࡶࡲࡴࠬມ") and XJZYzUxcCNq31
	if ZEihvxcN7XBjIrT4YytVmFgP1:
		HjZfiB1INbTGuQ = KW5bYS20wTF1LyCs9(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭ຢ") if YB5Segc7IQ>f90fGrlSEObDsuiA3U(u"࠶࠽࠮࠺࠻Ꭾ") else iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭ຣ")
		ccwRLKk3hs0E.executebuiltin(egY8Jti0smdLM3h1VQRSW(u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬ຤")+HjZfiB1INbTGuQ+Cp6c5tZe8I0PxnAW(u"ࠫ࠮࠭ລ"))
		XJZYzUxcCNq31 = YchIv6N09BaWPEj4tieAnluKZrRXT
	elif HHVLQX4TlGu9m:
		HjZfiB1INbTGuQ = Cp6c5tZe8I0PxnAW(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪ຦") if YB5Segc7IQ>I5bUBGpPXn0W6(u"࠷࠷࠯࠻࠼Ꭿ") else TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪວ")
		ccwRLKk3hs0E.executebuiltin(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࠧຨ")+HjZfiB1INbTGuQ+t3coAp06zvHrTl49bUVgx(u"ࠨࠫࠪຩ"))
		XJZYzUxcCNq31 = rDceXBpHkfVUYRJ3tIx95Z
	return
def vKD1rqZCXUbcR7n38VyatMSEL(direction,button0=eHdDoxhJCEPMZFVa2fg,button1=eHdDoxhJCEPMZFVa2fg,button2=eHdDoxhJCEPMZFVa2fg,HXJqSAUvb6Zuw7VEiN4RKeP25L=eHdDoxhJCEPMZFVa2fg,oh8Z06rUdqJ=eHdDoxhJCEPMZFVa2fg,profile=TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡦ࡮࡭ࡦࡰࡰࡷࠫສ"),sQnXyx4khUWCg389bIBrtVY=x1Oa8bBf36EwsLMirtFc,Gnm5t8MbSh0OAoDzQk2EWvZr1jqVa=x1Oa8bBf36EwsLMirtFc):
	if not direction: direction = t3coAp06zvHrTl49bUVgx(u"ࠪࡧࡪࡴࡴࡦࡴࠪຫ")
	HjZfiB1INbTGuQ = powlCmxIzivj6GL(LTN6DPEmrwehtZMy(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡇࡴࡴࡦࡪࡴࡰࡘ࡭ࡸࡥࡦࡄࡸࡸࡹࡵ࡮ࡴ࠰ࡻࡱࡱ࠭ຬ"),lAf7eTIozDOK0arHsmWx,t3coAp06zvHrTl49bUVgx(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ອ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭࠷࠳࠲ࡳࠫຮ"))
	HjZfiB1INbTGuQ.f4fahsHcwJLdtSvP0r6yF5NqbAp1(button0,button1,button2,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,profile,direction,sQnXyx4khUWCg389bIBrtVY,Gnm5t8MbSh0OAoDzQk2EWvZr1jqVa)
	if sQnXyx4khUWCg389bIBrtVY>x1Oa8bBf36EwsLMirtFc: HjZfiB1INbTGuQ.gm1J9RpCIl()
	if Gnm5t8MbSh0OAoDzQk2EWvZr1jqVa>x1Oa8bBf36EwsLMirtFc: HjZfiB1INbTGuQ.WoST0bqreDlvp()
	if sQnXyx4khUWCg389bIBrtVY==x1Oa8bBf36EwsLMirtFc and Gnm5t8MbSh0OAoDzQk2EWvZr1jqVa==x1Oa8bBf36EwsLMirtFc: HjZfiB1INbTGuQ.qW0PXcHxyFSLRhN8oTDnCBdzu()
	HjZfiB1INbTGuQ.doModal()
	jF1DqR2Y3VrIShwBeOpco = HjZfiB1INbTGuQ.choiceID
	return jF1DqR2Y3VrIShwBeOpco
def YTUtDCvHs6eQEPi1FJ(direction,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,profile=ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨຯ")):
	if not direction: direction = I5bUBGpPXn0W6(u"ࠨ࡮ࡨࡪࡹ࠭ະ")
	HjZfiB1INbTGuQ = kUJmKtWGNH8p5OjA2MPrZQ9I0zeTVa(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡖࡨࡼࡹ࡜ࡩࡦࡹࡨࡶࡋࡻ࡬࡭ࡕࡦࡶࡪ࡫࡮࠯ࡺࡰࡰࠬັ"),lAf7eTIozDOK0arHsmWx,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫາ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠫ࠼࠸࠰ࡱࠩຳ"))
	image_filename = gnIVwMHOs8FutBi34RhpT1lbUrL9K.replace(eNEhtuoi9gK8JaTpIXj(u"ࠬࡥ࠰࠱࠲࠳ࡣࠬິ"),HkiMU0QrdzW3l6gwnT(u"࠭࡟ࠨີ")+str(b8bLFaejUB.time())+f90fGrlSEObDsuiA3U(u"ࠧࡠࠩຶ"))
	image_filename = image_filename.replace(bP01xn84BiQN(u"ࠨ࡞࡟ࠫື"),HkiMU0QrdzW3l6gwnT(u"ࠩ࡟ࡠࡡࡢຸࠧ")).replace(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪ࠳࠴ູ࠭"),KQ3sCe9Pzh(u"ࠫ࠴࠵࠯࠰຺ࠩ"))
	image_height = Ge4XfaYx3t1(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HXJqSAUvb6Zuw7VEiN4RKeP25L,oh8Z06rUdqJ,profile,direction,rDceXBpHkfVUYRJ3tIx95Z,image_filename)
	HjZfiB1INbTGuQ.show()
	HjZfiB1INbTGuQ.getControl(ietolwsjpIPK7Fr(u"࠹࠱࠷࠳Ꮀ")).setHeight(image_height)
	HjZfiB1INbTGuQ.getControl(EX25Y0l8ILvz7QcRC(u"࠺࠲࠸࠴Ꮁ")).setImage(image_filename)
	eCjMavt0mlhgB = HjZfiB1INbTGuQ.doModal()
	try: RRydns1CErYlIhwSx7.remove(image_filename)
	except: pass
	return eCjMavt0mlhgB
def qq62QA8h3pGxzCwWVeXIF7glKf(ggtchD3X48isfJykIQHB0me=YchIv6N09BaWPEj4tieAnluKZrRXT):
	if ggtchD3X48isfJykIQHB0me:
		PPOaXI9Tr1fAD7luhFGYpKJ5q = EeZHTwQUW2BuvJyIh(pyifuNFdxe,XugxFprC26zGM(u"ࠬࡹࡴࡳࠩົ"),RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩຼ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪຽ"))
		if PPOaXI9Tr1fAD7luhFGYpKJ5q: return PPOaXI9Tr1fAD7luhFGYpKJ5q
	oh8Z06rUdqJ = eHdDoxhJCEPMZFVa2fg
	if x1Oa8bBf36EwsLMirtFc and qldY3LPe0pDiuyoM8vIH.succeeded:
		a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
		ZlJIRM4voWapmOU8ykibgT5D1cd = a3glxPAGFXm2kzq.count(t3coAp06zvHrTl49bUVgx(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢࠩ຾"))
		if ZlJIRM4voWapmOU8ykibgT5D1cd>GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠺࠳Ꮂ"):
			oh8Z06rUdqJ = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠩࡪࡩࡹ࠳ࡴࡩࡧ࠰ࡰ࡮ࡹࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ຿"),a3glxPAGFXm2kzq,cBawilJXvK1m.DOTALL)
			oh8Z06rUdqJ = oh8Z06rUdqJ[x1Oa8bBf36EwsLMirtFc]
	if not oh8Z06rUdqJ:
		ZuTKbwXjIsvky8pGAH7BfmOVr5 = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,XugxFprC26zGM(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩເ"),f90fGrlSEObDsuiA3U(u"ࠫࡺࡹࡥࡳࡣࡪࡩࡳࡺࡳ࠯ࡶࡻࡸࠬແ"))
		oh8Z06rUdqJ = open(ZuTKbwXjIsvky8pGAH7BfmOVr5,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡸࡢࠨໂ")).read()
		if WHjh1POtMKlmgiy68RSqb: oh8Z06rUdqJ = oh8Z06rUdqJ.decode(m6PFtLblInpNZ8x)
		oh8Z06rUdqJ = oh8Z06rUdqJ.replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)
	yy5OEnu0Xo2gSpKwkAZiNLQP = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࠨࡎࡱࡽ࡭ࡱࡲࡡ࠯ࠬࡂ࠭ࡡࡴࠧໃ"),oh8Z06rUdqJ,cBawilJXvK1m.DOTALL)
	OC3TaInQSi5B6RxDsAyMYt9Ufw2GNv = []
	for RFs8k3UxnlTaNu4EGBJderbK1X in yy5OEnu0Xo2gSpKwkAZiNLQP:
		Eg8BAYrqaCKXWO2wu7bvFRLS9Tkej = RFs8k3UxnlTaNu4EGBJderbK1X.lower()
		if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡢࡰࡧࡶࡴ࡯ࡤࠨໄ") in Eg8BAYrqaCKXWO2wu7bvFRLS9Tkej: continue
		if XugxFprC26zGM(u"ࠨࡷࡥࡹࡳࡺࡵࠨ໅") in Eg8BAYrqaCKXWO2wu7bvFRLS9Tkej: continue
		if CKUiyEe28zsZ(u"ࠩ࡬ࡴ࡭ࡵ࡮ࡦࠩໆ") in Eg8BAYrqaCKXWO2wu7bvFRLS9Tkej: continue
		if egY8Jti0smdLM3h1VQRSW(u"ࠪࡧࡷࡵࡳࠨ໇") in Eg8BAYrqaCKXWO2wu7bvFRLS9Tkej: continue
		OC3TaInQSi5B6RxDsAyMYt9Ufw2GNv.append(RFs8k3UxnlTaNu4EGBJderbK1X)
	PPOaXI9Tr1fAD7luhFGYpKJ5q = GljITSOwLKW36.sample(OC3TaInQSi5B6RxDsAyMYt9Ufw2GNv,NSudqlOzja)
	PPOaXI9Tr1fAD7luhFGYpKJ5q = PPOaXI9Tr1fAD7luhFGYpKJ5q[x1Oa8bBf36EwsLMirtFc]
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,w2vjZmdJuY7c(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ່ࠧ"),ehfEsaiJBSvbcULtNPVgykA2(u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ້"),PPOaXI9Tr1fAD7luhFGYpKJ5q,bbfreYhcgwZlKEGVx7zRU)
	return PPOaXI9Tr1fAD7luhFGYpKJ5q
def CCq2PhsRVwMmeL4YpcE7QxaWjoAlv(pw9fgsSRmnKId80YbU1PA=eHdDoxhJCEPMZFVa2fg):
	if not pw9fgsSRmnKId80YbU1PA: pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
	if NxXMrsTC5FniYuRBOK8(u"࠭ࡓࡺࡵࡷࡩࡲࡋࡸࡪࡶ໊ࠪ") in pw9fgsSRmnKId80YbU1PA or w2vjZmdJuY7c(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡ໋ࠪ") in pw9fgsSRmnKId80YbU1PA: return
	if pw9fgsSRmnKId80YbU1PA!=KW5bYS20wTF1LyCs9(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫ໌"): jjO4Xf7GBW8Dx2HR0tdP.stderr.write(pw9fgsSRmnKId80YbU1PA)
	a0VHgjbCY1KfuI6o = pw9fgsSRmnKId80YbU1PA.splitlines()
	ACbjkvGL7Udh4RuToXPmeFVy = a0VHgjbCY1KfuI6o[-ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴Ꮃ")]
	j9SyWpkKVMfNcs7eDZU3nP8qr5 = open(SSI5kBG0Y2JpF,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡵࡦࠬໍ")).read()
	if WHjh1POtMKlmgiy68RSqb: j9SyWpkKVMfNcs7eDZU3nP8qr5 = j9SyWpkKVMfNcs7eDZU3nP8qr5.decode(m6PFtLblInpNZ8x)
	j9SyWpkKVMfNcs7eDZU3nP8qr5 = j9SyWpkKVMfNcs7eDZU3nP8qr5[-QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠼࠵࠶࠰Ꮄ"):]
	zoe6jlvGVJnuW3gLPq = S8i3sBYoHWdTURpAgN(u"ࠪࡁࠬ໎")*EX25Y0l8ILvz7QcRC(u"࠶࠶࠰Ꮅ")
	if zoe6jlvGVJnuW3gLPq in j9SyWpkKVMfNcs7eDZU3nP8qr5: j9SyWpkKVMfNcs7eDZU3nP8qr5 = j9SyWpkKVMfNcs7eDZU3nP8qr5.rsplit(zoe6jlvGVJnuW3gLPq,NSudqlOzja)[NSudqlOzja]
	if ACbjkvGL7Udh4RuToXPmeFVy in j9SyWpkKVMfNcs7eDZU3nP8qr5: j9SyWpkKVMfNcs7eDZU3nP8qr5 = j9SyWpkKVMfNcs7eDZU3nP8qr5.rsplit(ACbjkvGL7Udh4RuToXPmeFVy,NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]
	eON9EFpwMaBf1iCYk0WG42V3KSLh = cBawilJXvK1m.findall(S8i3sBYoHWdTURpAgN(u"࡙ࠫ࠭࡯ࡶࡴࡦࡩࢁࡓ࡯ࡥࡧࠬ࠾ࠥࡢ࡛ࠡࠪ࠱࠮ࡄ࠯ࠠ࡝࡟ࠪ໏"),j9SyWpkKVMfNcs7eDZU3nP8qr5,cBawilJXvK1m.DOTALL)
	for jizUSElpkPmbI3n7vTMcJt,Oyg3pZGAHdws7RWm4e6S in reversed(eON9EFpwMaBf1iCYk0WG42V3KSLh):
		if Oyg3pZGAHdws7RWm4e6S: break
	else: Oyg3pZGAHdws7RWm4e6S = EX25Y0l8ILvz7QcRC(u"ࠬࡔࡏࡕࠢࡖࡔࡊࡉࡉࡇࡋࡈࡈࠬ໐")
	aNocw8R7zKPnyAfrF5vV1mp4DSlYM,RFs8k3UxnlTaNu4EGBJderbK1X,EBLD1GdcWPmk523zxhwIye6VRv = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	vi8o3sylQRMP = RqLvTrID0yMVeClpYcnZ16i3X(u"࡛࠭ࡓࡖࡏࡡࠬ໑")+OR97bMGecfgDCqux3YdAZ6y+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧศๆั฻ศࡀࠠࠡࠩ໒")+Nat0Dx9puRUWCsgz6JyFhY3+ACbjkvGL7Udh4RuToXPmeFVy
	wGp3f1bmBdPS5icYFqDNZxj2UEzoM = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨ࡝ࡕࡘࡑࡣࠧ໓")+OR97bMGecfgDCqux3YdAZ6y+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩส่๊฻ฯา࠼ࠣࠤࠬ໔")+Nat0Dx9puRUWCsgz6JyFhY3+Oyg3pZGAHdws7RWm4e6S
	for fu1HyeXgO8i2ZQpIVwLYzjak in reversed(a0VHgjbCY1KfuI6o):
		if S8i3sBYoHWdTURpAgN(u"ࠪࡊ࡮ࡲࡥࠡࠤࠪ໕") in fu1HyeXgO8i2ZQpIVwLYzjak and ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ໖") in fu1HyeXgO8i2ZQpIVwLYzjak: break
	fu1HyeXgO8i2ZQpIVwLYzjak = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠬࡌࡩ࡭ࡧࠣࠦ࠭࠴ࠪࡀࠫࠥࡠ࠱ࠦ࡬ࡪࡰࡨࠤ࠭࠴ࠪࡀࠫ࡟࠰ࠥ࡯࡮ࠡࠪ࠱࠮ࡄ࠯ࠤࠨ໗"),fu1HyeXgO8i2ZQpIVwLYzjak,cBawilJXvK1m.DOTALL)
	if fu1HyeXgO8i2ZQpIVwLYzjak:
		aNocw8R7zKPnyAfrF5vV1mp4DSlYM,RFs8k3UxnlTaNu4EGBJderbK1X,EBLD1GdcWPmk523zxhwIye6VRv = fu1HyeXgO8i2ZQpIVwLYzjak[x1Oa8bBf36EwsLMirtFc]
		if Cp6c5tZe8I0PxnAW(u"࠭࠯ࠨ໘") in aNocw8R7zKPnyAfrF5vV1mp4DSlYM: aNocw8R7zKPnyAfrF5vV1mp4DSlYM = aNocw8R7zKPnyAfrF5vV1mp4DSlYM.rsplit(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧ࠰ࠩ໙"),NSudqlOzja)[NSudqlOzja]
		else: aNocw8R7zKPnyAfrF5vV1mp4DSlYM = aNocw8R7zKPnyAfrF5vV1mp4DSlYM.rsplit(eNEhtuoi9gK8JaTpIXj(u"ࠨ࡞࡟ࠫ໚"),NSudqlOzja)[NSudqlOzja]
		iUuKI92FalzEARomThCw4gJPyYSp = EX25Y0l8ILvz7QcRC(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ໛")+OR97bMGecfgDCqux3YdAZ6y+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪห้๋ไโ࠼ࠣࠤࠬໜ")+Nat0Dx9puRUWCsgz6JyFhY3+aNocw8R7zKPnyAfrF5vV1mp4DSlYM
		OP7eyzv2QSYgmrnu = CKUiyEe28zsZ(u"ࠫࡠࡘࡔࡍ࡟ࠪໝ")+OR97bMGecfgDCqux3YdAZ6y+eNEhtuoi9gK8JaTpIXj(u"ࠬอไิูิ࠾ࠥࠦࠧໞ")+Nat0Dx9puRUWCsgz6JyFhY3+RFs8k3UxnlTaNu4EGBJderbK1X
		mmkqrycfuE1G = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࡛࠭ࡓࡖࡏࡡࠬໟ")+OR97bMGecfgDCqux3YdAZ6y+ilBWK5nXxg1do4jENGC07Zq(u"ࠧศๆ่็ฬ์࠺ࠡࠢࠪ໠")+Nat0Dx9puRUWCsgz6JyFhY3+EBLD1GdcWPmk523zxhwIye6VRv
		XoZtFdeDUgQbPKn1u7y43M5ij = iUuKI92FalzEARomThCw4gJPyYSp+kDUv7ouWrcgMe6OipQJm+OP7eyzv2QSYgmrnu+kDUv7ouWrcgMe6OipQJm+mmkqrycfuE1G+kDUv7ouWrcgMe6OipQJm+wGp3f1bmBdPS5icYFqDNZxj2UEzoM+kDUv7ouWrcgMe6OipQJm+vi8o3sylQRMP
		MSAmJslbk8ati2jI = OP7eyzv2QSYgmrnu+kDUv7ouWrcgMe6OipQJm+wGp3f1bmBdPS5icYFqDNZxj2UEzoM+kDUv7ouWrcgMe6OipQJm+vi8o3sylQRMP+kDUv7ouWrcgMe6OipQJm+iUuKI92FalzEARomThCw4gJPyYSp+kDUv7ouWrcgMe6OipQJm+mmkqrycfuE1G
		JyTqfAWbBnxZgUea60NEv5pd = OP7eyzv2QSYgmrnu+kDUv7ouWrcgMe6OipQJm+vi8o3sylQRMP+kDUv7ouWrcgMe6OipQJm+iUuKI92FalzEARomThCw4gJPyYSp+kDUv7ouWrcgMe6OipQJm+mmkqrycfuE1G
	else:
		iUuKI92FalzEARomThCw4gJPyYSp,OP7eyzv2QSYgmrnu,mmkqrycfuE1G = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
		XoZtFdeDUgQbPKn1u7y43M5ij = wGp3f1bmBdPS5icYFqDNZxj2UEzoM+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨ࡞ࡱࡠࡳ࠭໡")+vi8o3sylQRMP
		MSAmJslbk8ati2jI = wGp3f1bmBdPS5icYFqDNZxj2UEzoM+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩ࡟ࡲࡡࡴࠧ໢")+vi8o3sylQRMP
		JyTqfAWbBnxZgUea60NEv5pd = vi8o3sylQRMP
	ABoR26mQ9v3iwkMuSY51F8ZUNpPj = wY1p9mP03S8drbcH64t5WQkv(u"ࠪัิัࠠฯูฦࠤ฿๐ัࠡ็ๅูํีࠧ໣")+kDUv7ouWrcgMe6OipQJm
	wmNWjvkgRT = EUFxlTArZpSsgD0()
	XH76JjQtSG5ycYOWR9x = []
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = wmNWjvkgRT[KQ3sCe9Pzh(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩ໤")]
	FxO1KHoEDyGq9UrRT2Ytpcv = rrT0wO5a2JDl4UmbiRcWhpjSCMoyd(MCrWtwnF2TViZOD7z0pXgqI4)
	if f90fGrlSEObDsuiA3U(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ໥") in list(wmNWjvkgRT.keys()):
		for gUt6FLhYsHfDxywcqlGrRQzI5KZTVM,qTAmctLJnpChKxaQD,HgfpzA4BsldWaxJ in JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
			XH76JjQtSG5ycYOWR9x = max(XH76JjQtSG5ycYOWR9x,qTAmctLJnpChKxaQD)
		if FxO1KHoEDyGq9UrRT2Ytpcv<XH76JjQtSG5ycYOWR9x:
			HXJqSAUvb6Zuw7VEiN4RKeP25L = eNEhtuoi9gK8JaTpIXj(u"࠭โๆࠢหฮาี๊ฬࠢส่อืๆศ็ฯࠤ็ฮไࠡวิืฬ๊ࠠศๆฦา฼อมࠡๆ็้อืๅอࠩ໦")
			jF1DqR2Y3VrIShwBeOpco = vKD1rqZCXUbcR7n38VyatMSEL(egY8Jti0smdLM3h1VQRSW(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭໧"),KQ3sCe9Pzh(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ໨"),KQ3sCe9Pzh(u"ࠩอัิ๐หࠨ໩"),f90fGrlSEObDsuiA3U(u"ࠪาึ๎ฬࠨ໪"),ABoR26mQ9v3iwkMuSY51F8ZUNpPj+HXJqSAUvb6Zuw7VEiN4RKeP25L,XoZtFdeDUgQbPKn1u7y43M5ij)
			if jF1DqR2Y3VrIShwBeOpco==NSudqlOzja:
				import YmtfK6LolI
				YmtfK6LolI.bo8mpKfd5eaERB32vGz(YchIv6N09BaWPEj4tieAnluKZrRXT)
				ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
			elif jF1DqR2Y3VrIShwBeOpco==FB0pIzAoK8wqgd3UiY5: ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	Ldo3g2JEO7hCFX = EeZHTwQUW2BuvJyIh(pyifuNFdxe,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡱ࡯ࡳࡵࠩ໫"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ໬"),t3coAp06zvHrTl49bUVgx(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨ໭"))
	if not Ldo3g2JEO7hCFX: Ldo3g2JEO7hCFX = []
	MSAmJslbk8ati2jI = MSAmJslbk8ati2jI.replace(kDUv7ouWrcgMe6OipQJm,w2vjZmdJuY7c(u"ࠧ࡝࡞ࡱࠫ໮")).replace(S8i3sBYoHWdTURpAgN(u"ࠨ࡝ࡕࡘࡑࡣࠧ໯"),eHdDoxhJCEPMZFVa2fg).replace(OR97bMGecfgDCqux3YdAZ6y,eHdDoxhJCEPMZFVa2fg).replace(Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg)
	JyTqfAWbBnxZgUea60NEv5pd = JyTqfAWbBnxZgUea60NEv5pd.replace(kDUv7ouWrcgMe6OipQJm,LTN6DPEmrwehtZMy(u"ࠩ࡟ࡠࡳ࠭໰")).replace(bP01xn84BiQN(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ໱"),eHdDoxhJCEPMZFVa2fg).replace(OR97bMGecfgDCqux3YdAZ6y,eHdDoxhJCEPMZFVa2fg).replace(Nat0Dx9puRUWCsgz6JyFhY3,eHdDoxhJCEPMZFVa2fg)
	R0b3EPrgwTZzfqNyYDmlFX9 = MCrWtwnF2TViZOD7z0pXgqI4+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫ࠿ࡀࠧ໲")+JyTqfAWbBnxZgUea60NEv5pd
	if R0b3EPrgwTZzfqNyYDmlFX9 in Ldo3g2JEO7hCFX:
		HXJqSAUvb6Zuw7VEiN4RKeP25L = egY8Jti0smdLM3h1VQRSW(u"๊ࠬโะࠢๅ้ฯࠦว็ฬࠣืฬฮโศࠢหษึูวๅ๊ࠢิฬࠦวๅะฺวࠥหไ๊ࠢส่๊ฮัๆฮࠪ໳")
		dXINKZJp6Tbu7wmS(ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡲࡪࡩ࡫ࡸࠬ໴"),eHdDoxhJCEPMZFVa2fg,ABoR26mQ9v3iwkMuSY51F8ZUNpPj+HXJqSAUvb6Zuw7VEiN4RKeP25L,XoZtFdeDUgQbPKn1u7y43M5ij)
		return
	FCTPDboIuXrdlhO1wsB3E2MHyZKRni = str(YB5Segc7IQ).split(Cp6c5tZe8I0PxnAW(u"ࠧ࠯ࠩ໵"))[x1Oa8bBf36EwsLMirtFc]
	FeTJrG4SkMf09iVys8A = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ໶")][ietolwsjpIPK7Fr(u"࠼Ꮆ")]
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,LTN6DPEmrwehtZMy(u"ࠩࡓࡓࡘ࡚ࠧ໷"),FeTJrG4SkMf09iVys8A,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡎࡏࡘࡡࡈ࡜ࡎ࡚࡟ࡆࡔࡕࡓࡗ࡙࠭࠲ࡵࡷࠫ໸"),rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
	PPjDwIlEb8SBvU = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠫࡘ࡚ࡁࡓࡖ࠽࠾ࡘ࡚ࡁࡓࡖ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭࠽࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࡈࡒࡉࡀ࠺ࡆࡐࡇࠫ໹"),a3glxPAGFXm2kzq,cBawilJXvK1m.DOTALL)
	for zaUrQALuBIOJej,nnCP7Jik4rGgmtqYzsjoKS,i9P2doxs4jJMrZ,FFvB2MLEHPsZGRdAjx0Y1h in PPjDwIlEb8SBvU:
		zaUrQALuBIOJej = zaUrQALuBIOJej.split(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࠱ࠧ໺"))
		i9P2doxs4jJMrZ = i9P2doxs4jJMrZ.split(egY8Jti0smdLM3h1VQRSW(u"࠭ࠫࠨ໻"))
		FFvB2MLEHPsZGRdAjx0Y1h = FFvB2MLEHPsZGRdAjx0Y1h.split(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࠬࠩ໼"))
		if RFs8k3UxnlTaNu4EGBJderbK1X in zaUrQALuBIOJej and ACbjkvGL7Udh4RuToXPmeFVy==nnCP7Jik4rGgmtqYzsjoKS and MCrWtwnF2TViZOD7z0pXgqI4 in i9P2doxs4jJMrZ and FCTPDboIuXrdlhO1wsB3E2MHyZKRni in FFvB2MLEHPsZGRdAjx0Y1h:
			HXJqSAUvb6Zuw7VEiN4RKeP25L = KQ3sCe9Pzh(u"ࠨ้ำหࠥอไฯูฦࠤ๊฿ั้ใࠣ์ุ๐ูศๆฯࠤออไฦืาหึࠦวๅไสำ๊࠭໽")
			zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(LTN6DPEmrwehtZMy(u"ࠩࡵ࡭࡬࡮ࡴࠨ໾"),f90fGrlSEObDsuiA3U(u"ࠪาึ๎ฬࠨ໿"),eNEhtuoi9gK8JaTpIXj(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨༀ"),ABoR26mQ9v3iwkMuSY51F8ZUNpPj+HXJqSAUvb6Zuw7VEiN4RKeP25L,XoZtFdeDUgQbPKn1u7y43M5ij)
			if zf7iFX1auw0bQU==NSudqlOzja: dXINKZJp6Tbu7wmS(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ༁"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,HXJqSAUvb6Zuw7VEiN4RKeP25L)
			return
	HXJqSAUvb6Zuw7VEiN4RKeP25L = egY8Jti0smdLM3h1VQRSW(u"࠭วๅำฯหฦࠦลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭༂")
	IzkxUR2e5d96Jj = vKD1rqZCXUbcR7n38VyatMSEL(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭༃"),LyOR7f69iA(u"ࠨวิืฬ๊ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬ༄"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩอัิ๐หࠡฮีส๏࠭༅"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪฮาี๊ฬࠢส่อืๆศ็ฯࠫ༆"),ABoR26mQ9v3iwkMuSY51F8ZUNpPj+HXJqSAUvb6Zuw7VEiN4RKeP25L,XoZtFdeDUgQbPKn1u7y43M5ij)
	if IzkxUR2e5d96Jj==NSudqlOzja:
		if not oLfID72TXPO5SkEnW:
			zlSqaMRcYWs(rDceXBpHkfVUYRJ3tIx95Z)
			dqKGMYgJxSF8Ub1kotlsP936Ww7B(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"๋ࠫาอหࠢ฼้้๐ษࠡษ็ฮาี๊ฬࠢส่ัุฦ๋ࠩ༇"),ilBWK5nXxg1do4jENGC07Zq(u"ࠬ๓ࡓࡶࡥࡦࡩࡸࡹࠧ༈"),b8bLFaejUB=bP01xn84BiQN(u"࠷࠶࠲Ꮇ"))
		ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	elif IzkxUR2e5d96Jj==FB0pIzAoK8wqgd3UiY5:
		import YmtfK6LolI
		YmtfK6LolI.bo8mpKfd5eaERB32vGz(YchIv6N09BaWPEj4tieAnluKZrRXT)
		ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(LyOR7f69iA(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༉"),eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ༊"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨี๋ๅࠥ๐สๆࠢศีุอไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐ูาใࠣห้๋ศา็ฯࠤศ๐ๆ๊่ࠡฮ๎่ࠦไ์ไࠤํ๊ๅศาสࠤา฻ไห๊ࠢิ์ࠦวๅ็ื็้ฯࠠๅล้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠥ๎ไศࠢํืฯ฽ฺ๊ࠢสู้ออࠡ็ื็้ฯ้้๋ࠠࠤ้อ๋ࠠ฻ิๅ้๊ࠥโࠢ฻๋ึะ้ࠠๆ่หีอู้ࠠิฮࠥ๎ๅห๋ࠣ฼์ืส้ࠡำ๋ࠥอไๆึๆ่ฮࠦ࠮้ࠡ็ࠤฯื๊ะࠢฦีุอไࠡษ็ืั๊ࠠภࠩ་"))
	if zf7iFX1auw0bQU==NSudqlOzja: asme31FSC5c8 = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡢࡔࡗࡕࡂࡍࡇࡐࡣࠬ༌")
	else:
		dXINKZJp6Tbu7wmS(NxXMrsTC5FniYuRBOK8(u"ࠪࡧࡪࡴࡴࡦࡴࠪ།"),eHdDoxhJCEPMZFVa2fg,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ༎"),OR97bMGecfgDCqux3YdAZ6y+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࠬ༏")+Nat0Dx9puRUWCsgz6JyFhY3+EX25Y0l8ILvz7QcRC(u"࠭࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ༐"))
		return
	bOEZeag9A1qL206uh3o75 = MSAmJslbk8ati2jI
	import YmtfK6LolI
	gZdOM2jYEfV = YmtfK6LolI.CpsdhEGBHQZYJcS23wjrxzn(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡆࡴࡵࡳࡷࡹࠧ༑"),bOEZeag9A1qL206uh3o75,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨ༒"),asme31FSC5c8)
	if gZdOM2jYEfV and asme31FSC5c8:
		Ldo3g2JEO7hCFX.append(R0b3EPrgwTZzfqNyYDmlFX9)
		CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ༓"),egY8Jti0smdLM3h1VQRSW(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ༔"),Ldo3g2JEO7hCFX,ICRfWub2vqlor0Q)
	return
def RRlnr3SCQPh6yakLZYVXM5GfxmsA(KhGpZcMqsnrbv,filename=None):
	if WHjh1POtMKlmgiy68RSqb: KhGpZcMqsnrbv = KhGpZcMqsnrbv.encode(m6PFtLblInpNZ8x)
	if not filename: dyablPViz25TGKJ = jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ༕")+str(b8bLFaejUB.time())+ietolwsjpIPK7Fr(u"ࠬ࠴ࡤࡢࡶࠪ༖")
	else: dyablPViz25TGKJ = HkiMU0QrdzW3l6gwnT(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭༗")+filename+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧ࠯ࡦࡤࡸ༘ࠬ")
	open(dyablPViz25TGKJ,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡹࡥ༙ࠫ")).write(KhGpZcMqsnrbv)
	return
def K89FakvRdrtXhmnDE7O(ssGzSv5CKWmpbITxfqjE6D4n0leo):
	if ssGzSv5CKWmpbITxfqjE6D4n0leo:
		pg2HKT7OyfiMWL6 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࡯࡭ࡸࡺࠧ༚"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭༛"),CKUiyEe28zsZ(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ༜"))
		if pg2HKT7OyfiMWL6: return pg2HKT7OyfiMWL6
	FeTJrG4SkMf09iVys8A = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ༝")][EX25Y0l8ILvz7QcRC(u"࠶Ꮈ")]
	pcG48moFZkRT1Iz7DJaYOqtB = edpM3qtgTJIz8PWN6lvin(rDceXBpHkfVUYRJ3tIx95Z) if not ssGzSv5CKWmpbITxfqjE6D4n0leo else ZylBO1ktRGvdJ0
	J4JZ8HDlxfUjO0 = hpCAb2IZHvVy5Wc8l0m7qw()
	CNqlQiod9T4Z = J4JZ8HDlxfUjO0.split(LyOR7f69iA(u"࠭ࠬࠨ༞"))[FB0pIzAoK8wqgd3UiY5]
	ptoTgEv6Kly = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭༟"))
	N0NUlnZHtbJMmCoGSQzsOYT8 = DucliOC0wXs()
	zo8KfmNxYVlhGZ0A6bEM7igIa5 = {dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡷࡶࡩࡷ࠭༠"):pcG48moFZkRT1Iz7DJaYOqtB,egY8Jti0smdLM3h1VQRSW(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪ༡"):MCrWtwnF2TViZOD7z0pXgqI4,bP01xn84BiQN(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫ༢"):CNqlQiod9T4Z,I5bUBGpPXn0W6(u"ࠫ࡮ࡪࡳࠨ༣"):VarSZWbo4B6y3htcxuifmD9FYqnLvp(N0NUlnZHtbJMmCoGSQzsOYT8)}
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,XugxFprC26zGM(u"ࠬࡖࡏࡔࡖࠪ༤"),FeTJrG4SkMf09iVys8A,zo8KfmNxYVlhGZ0A6bEM7igIa5,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࠭࠲ࡵࡷࠫ༥"))
	pg2HKT7OyfiMWL6 = []
	if qldY3LPe0pDiuyoM8vIH.succeeded:
		a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
		pg2HKT7OyfiMWL6 = a3glxPAGFXm2kzq.replace(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧ࡝࡞ࡵࠫ༦"),kDUv7ouWrcgMe6OipQJm).replace(ietolwsjpIPK7Fr(u"ࠨ࡞࡟ࡲࠬ༧"),kDUv7ouWrcgMe6OipQJm).replace(eNEhtuoi9gK8JaTpIXj(u"ࠩ࡟ࡶࡡࡴࠧ༨"),kDUv7ouWrcgMe6OipQJm).replace(y1fVB2E63aLnJgkWeCZHujY,kDUv7ouWrcgMe6OipQJm)
		pg2HKT7OyfiMWL6 = cBawilJXvK1m.findall(egY8Jti0smdLM3h1VQRSW(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭༩"),pg2HKT7OyfiMWL6,cBawilJXvK1m.DOTALL)
		if pg2HKT7OyfiMWL6:
			pg2HKT7OyfiMWL6 = sorted(pg2HKT7OyfiMWL6,reverse=rDceXBpHkfVUYRJ3tIx95Z,key=lambda key: int(key[x1Oa8bBf36EwsLMirtFc]))
			vvTGOs9zmKUeP35iILrC4,pcG48moFZkRT1Iz7DJaYOqtB,YSrPiRzTntg3kwsH86xvm0oZf9,Geo8WC6xHmhPAwQMXpZd,vR5ZcIituWPYQLwyeab2oOsg,RCrFOws8DlH6 = pg2HKT7OyfiMWL6[x1Oa8bBf36EwsLMirtFc]
			epEk52AOIUh7SxKFmbwRPrq3Na = RCrFOws8DlH6 if BoGNtDIVHAyw([eNEhtuoi9gK8JaTpIXj(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪ༪")])[x1Oa8bBf36EwsLMirtFc] else YSrPiRzTntg3kwsH86xvm0oZf9
			MoO74hKeqm8fFka.setSetting(ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ༫"),epEk52AOIUh7SxKFmbwRPrq3Na)
			CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,KW5bYS20wTF1LyCs9(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ༬"),I5bUBGpPXn0W6(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ༭"),pg2HKT7OyfiMWL6,bbfreYhcgwZlKEGVx7zRU)
			MoO74hKeqm8fFka.setSetting(NxXMrsTC5FniYuRBOK8(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ༮"),VarSZWbo4B6y3htcxuifmD9FYqnLvp(a8HLTkO2ns49yGNgiroS))
	return pg2HKT7OyfiMWL6
def OyNBvcZVXKnLsJbupPQzm0rAES6g7(Ty8qgdR02arW1VpLSHefNXbhF,hWoQPErC3gSfJXuqVsGd=x1Oa8bBf36EwsLMirtFc,wzlVxqg9HSry5Z=x1Oa8bBf36EwsLMirtFc):
	if hWoQPErC3gSfJXuqVsGd and not wzlVxqg9HSry5Z: wzlVxqg9HSry5Z = len(Ty8qgdR02arW1VpLSHefNXbhF)//hWoQPErC3gSfJXuqVsGd
	mrUblQW6cXkAnB94JtKSYjMdeH0ps,gMmB3iopS0ZXrOFewhcxt,nxNPDeuVwTb3 = [],-NSudqlOzja,x1Oa8bBf36EwsLMirtFc
	for KKeiYLQO4vH3yskhbG in Ty8qgdR02arW1VpLSHefNXbhF:
		if nxNPDeuVwTb3%wzlVxqg9HSry5Z==x1Oa8bBf36EwsLMirtFc:
			gMmB3iopS0ZXrOFewhcxt += NSudqlOzja
			mrUblQW6cXkAnB94JtKSYjMdeH0ps.append([])
		mrUblQW6cXkAnB94JtKSYjMdeH0ps[gMmB3iopS0ZXrOFewhcxt].append(KKeiYLQO4vH3yskhbG)
		nxNPDeuVwTb3 += NSudqlOzja
	return mrUblQW6cXkAnB94JtKSYjMdeH0ps
def fcwWV0nAgu74Cjh3TNelG(dyablPViz25TGKJ,KhGpZcMqsnrbv):
	x98xK06O7rpdTwPI2jQAgZV = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,dyablPViz25TGKJ)
	if NSudqlOzja or iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡌࡔ࡙࡜࡟ࠨ༯") not in dyablPViz25TGKJ or TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡑ࠸࡛࡟ࠨ༰") not in dyablPViz25TGKJ: oh8Z06rUdqJ = str(KhGpZcMqsnrbv)
	else:
		mrUblQW6cXkAnB94JtKSYjMdeH0ps = OyNBvcZVXKnLsJbupPQzm0rAES6g7(KhGpZcMqsnrbv,XugxFprC26zGM(u"࠺Ꮉ"))
		oh8Z06rUdqJ = eHdDoxhJCEPMZFVa2fg
		for gqyU2c0NtJeMxfCBzWY3Ko in mrUblQW6cXkAnB94JtKSYjMdeH0ps:
			oh8Z06rUdqJ += str(gqyU2c0NtJeMxfCBzWY3Ko)+KW5bYS20wTF1LyCs9(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪ༱")
		oh8Z06rUdqJ = oh8Z06rUdqJ.strip(LyOR7f69iA(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫ༲"))
	kkxCyVKfNPR1W0JBOHjLnMmE = vGPgxMCUnVTb6fDsXkRS.compress(oh8Z06rUdqJ)
	open(x98xK06O7rpdTwPI2jQAgZV,NxXMrsTC5FniYuRBOK8(u"࠭ࡷࡣࠩ༳")).write(kkxCyVKfNPR1W0JBOHjLnMmE)
	return
def HHsDVbYwdfPQcFga1W4y7p8XhBKn5(HtsU1JmF0cn3fgGraqwRYNIdlhESj,dyablPViz25TGKJ):
	if HtsU1JmF0cn3fgGraqwRYNIdlhESj==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧࡥ࡫ࡦࡸࠬ༴"): KhGpZcMqsnrbv = {}
	elif HtsU1JmF0cn3fgGraqwRYNIdlhESj==ietolwsjpIPK7Fr(u"ࠨ࡮࡬ࡷࡹ༵࠭"): KhGpZcMqsnrbv = []
	elif HtsU1JmF0cn3fgGraqwRYNIdlhESj==w2vjZmdJuY7c(u"ࠩࡶࡸࡷ࠭༶"): KhGpZcMqsnrbv = eHdDoxhJCEPMZFVa2fg
	elif HtsU1JmF0cn3fgGraqwRYNIdlhESj==ilBWK5nXxg1do4jENGC07Zq(u"ࠪ࡭ࡳࡺ༷ࠧ"): KhGpZcMqsnrbv = x1Oa8bBf36EwsLMirtFc
	else: KhGpZcMqsnrbv = None
	x98xK06O7rpdTwPI2jQAgZV = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,dyablPViz25TGKJ)
	kkxCyVKfNPR1W0JBOHjLnMmE = open(x98xK06O7rpdTwPI2jQAgZV,LyOR7f69iA(u"ࠫࡷࡨࠧ༸")).read()
	oh8Z06rUdqJ = vGPgxMCUnVTb6fDsXkRS.decompress(kkxCyVKfNPR1W0JBOHjLnMmE)
	if KW5bYS20wTF1LyCs9(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱ༹ࠫ") not in oh8Z06rUdqJ: KhGpZcMqsnrbv = eval(oh8Z06rUdqJ)
	else:
		mrUblQW6cXkAnB94JtKSYjMdeH0ps = oh8Z06rUdqJ.split(jUcmHhgVvW0EdYOIfXeaDF(u"࠭࡜࡯࡞ࡱࡁࡂࡃ࠽࡝ࡰ࡟ࡲࠬ༺"))
		del oh8Z06rUdqJ
		KhGpZcMqsnrbv = []
		ODkns4woFmSHI3W9hU = NLZqC35dHIcYei6Tpr4wms()
		vvTGOs9zmKUeP35iILrC4 = x1Oa8bBf36EwsLMirtFc
		for gqyU2c0NtJeMxfCBzWY3Ko in mrUblQW6cXkAnB94JtKSYjMdeH0ps:
			ODkns4woFmSHI3W9hU.vvsdh9VR7afIEJOWec3KoZUy(str(vvTGOs9zmKUeP35iILrC4),eval,gqyU2c0NtJeMxfCBzWY3Ko)
			vvTGOs9zmKUeP35iILrC4 += NSudqlOzja
		del mrUblQW6cXkAnB94JtKSYjMdeH0ps
		ODkns4woFmSHI3W9hU.NUJvdXjoBcy4HVPSEiwh()
		ODkns4woFmSHI3W9hU.veoCrXsKJSu3Il85nmpgqyafjDz7wO()
		x2xoDBACZHyqztRj = list(ODkns4woFmSHI3W9hU.resultsDICT.keys())
		wroQygnVdUFT = sorted(x2xoDBACZHyqztRj,reverse=rDceXBpHkfVUYRJ3tIx95Z,key=lambda key: int(key))
		for vvTGOs9zmKUeP35iILrC4 in wroQygnVdUFT:
			KhGpZcMqsnrbv += ODkns4woFmSHI3W9hU.resultsDICT[vvTGOs9zmKUeP35iILrC4]
	return KhGpZcMqsnrbv
def IMsN2iOXlhF8trdn(L1BnkG7RhvcXZoWfjdDHq3Uzu2E):
	gPXLBl40nxJDHtUi8Fwjo5ZR = RRydns1CErYlIhwSx7.path.join(jXg4GKQS3sy9ipunzTwkY7N2085dR,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡢࡦࡧࡳࡳࡹࠧ༻"),L1BnkG7RhvcXZoWfjdDHq3Uzu2E,LyOR7f69iA(u"ࠨࡣࡧࡨࡴࡴ࠮ࡹ࡯࡯ࠫ༼"))
	try: rpJZCmTfDLylb8Vjdq5KzNhvw43YMa = open(gPXLBl40nxJDHtUi8Fwjo5ZR,S8i3sBYoHWdTURpAgN(u"ࠩࡵࡦࠬ༽")).read()
	except:
		KFQ3nY6XlU8uT = RRydns1CErYlIhwSx7.path.join(RhIUBP3G59lWmTQxAzdMwc,EX25Y0l8ILvz7QcRC(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ༾"),L1BnkG7RhvcXZoWfjdDHq3Uzu2E,NxXMrsTC5FniYuRBOK8(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ༿"))
		try: rpJZCmTfDLylb8Vjdq5KzNhvw43YMa = open(KFQ3nY6XlU8uT,ietolwsjpIPK7Fr(u"ࠬࡸࡢࠨཀ")).read()
		except: return eHdDoxhJCEPMZFVa2fg,[]
	if WHjh1POtMKlmgiy68RSqb: rpJZCmTfDLylb8Vjdq5KzNhvw43YMa = rpJZCmTfDLylb8Vjdq5KzNhvw43YMa.decode(m6PFtLblInpNZ8x)
	FEcMQ6WIXB10HG8t = cBawilJXvK1m.findall(ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡩࡥ࠿࠱࠮ࡄࡼࡥࡳࡵ࡬ࡳࡳࡃ࡛࡝ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡࠨ࡜ࠨ࡟ࠪཁ"),rpJZCmTfDLylb8Vjdq5KzNhvw43YMa,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
	if not FEcMQ6WIXB10HG8t: return eHdDoxhJCEPMZFVa2fg,[]
	BCtvdgTIGmDq,CCAgTaLGNHZ6st0F8X7kPVpQm = FEcMQ6WIXB10HG8t[x1Oa8bBf36EwsLMirtFc],rrT0wO5a2JDl4UmbiRcWhpjSCMoyd(FEcMQ6WIXB10HG8t[x1Oa8bBf36EwsLMirtFc])
	return BCtvdgTIGmDq,CCAgTaLGNHZ6st0F8X7kPVpQm
def EUFxlTArZpSsgD0():
	dbZojKRgtLahS0 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,t3coAp06zvHrTl49bUVgx(u"ࠧࡥ࡫ࡦࡸࠬག"),w2vjZmdJuY7c(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫགྷ"),bP01xn84BiQN(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪང"))
	if dbZojKRgtLahS0: return dbZojKRgtLahS0
	wmNWjvkgRT,dbZojKRgtLahS0 = {},{}
	eON9EFpwMaBf1iCYk0WG42V3KSLh = [VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[KW5bYS20wTF1LyCs9(u"ࠪࡖࡊࡖࡏࡔࠩཅ")][x1Oa8bBf36EwsLMirtFc]]
	if YB5Segc7IQ>bP01xn84BiQN(u"࠴࠻࠳࠿࠹Ꮊ"): eON9EFpwMaBf1iCYk0WG42V3KSLh.append(VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[Cp6c5tZe8I0PxnAW(u"ࠫࡗࡋࡐࡐࡕࠪཆ")][NSudqlOzja])
	if WHjh1POtMKlmgiy68RSqb: eON9EFpwMaBf1iCYk0WG42V3KSLh.append(VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡘࡅࡑࡑࡖࠫཇ")][FB0pIzAoK8wqgd3UiY5])
	for xct3TqAD1WSzRyL2Ys in eON9EFpwMaBf1iCYk0WG42V3KSLh:
		qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,KQ3sCe9Pzh(u"࠭ࡇࡆࡖࠪ཈"),xct3TqAD1WSzRyL2Ys,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈࡅࡉࡥࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒ࠭࠲ࡵࡷࠫཉ"))
		if qldY3LPe0pDiuyoM8vIH.succeeded:
			a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
			yy7A08WtUIwH15gRPFl4NYb = xct3TqAD1WSzRyL2Ys.rsplit(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨ࠱ࠪཊ"),NxXMrsTC5FniYuRBOK8(u"࠵Ꮋ"))[x1Oa8bBf36EwsLMirtFc]
			HHoIGmjpzavNr6ZD8beT = cBawilJXvK1m.findall(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪཋ"),a3glxPAGFXm2kzq,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
			for L1BnkG7RhvcXZoWfjdDHq3Uzu2E,VlbpYdhoMwfNWIC in HHoIGmjpzavNr6ZD8beT:
				cl2Nwu9goQBKG4AYPW0n = yy7A08WtUIwH15gRPFl4NYb+I5bUBGpPXn0W6(u"ࠪ࠳ࠬཌ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+NxXMrsTC5FniYuRBOK8(u"ࠫ࠴࠭ཌྷ")+L1BnkG7RhvcXZoWfjdDHq3Uzu2E+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬ࠳ࠧཎ")+VlbpYdhoMwfNWIC+Cp6c5tZe8I0PxnAW(u"࠭࠮ࡻ࡫ࡳࠫཏ")
				if L1BnkG7RhvcXZoWfjdDHq3Uzu2E not in list(wmNWjvkgRT.keys()):
					wmNWjvkgRT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E] = []
					dbZojKRgtLahS0[L1BnkG7RhvcXZoWfjdDHq3Uzu2E] = []
				nxOgpQ0KvHr3cTju8IBEz4A = rrT0wO5a2JDl4UmbiRcWhpjSCMoyd(VlbpYdhoMwfNWIC)
				wmNWjvkgRT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E].append((VlbpYdhoMwfNWIC,nxOgpQ0KvHr3cTju8IBEz4A,cl2Nwu9goQBKG4AYPW0n))
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E in list(wmNWjvkgRT.keys()):
		dbZojKRgtLahS0[L1BnkG7RhvcXZoWfjdDHq3Uzu2E] = sorted(wmNWjvkgRT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E],reverse=YchIv6N09BaWPEj4tieAnluKZrRXT,key=lambda key: key[NSudqlOzja])
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪཐ"),egY8Jti0smdLM3h1VQRSW(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩད"),dbZojKRgtLahS0,bbfreYhcgwZlKEGVx7zRU)
	return dbZojKRgtLahS0
def rrT0wO5a2JDl4UmbiRcWhpjSCMoyd(VlbpYdhoMwfNWIC):
	nxOgpQ0KvHr3cTju8IBEz4A = []
	IyqSwnbGtU95r3 = VlbpYdhoMwfNWIC.split(KW5bYS20wTF1LyCs9(u"ࠩ࠱ࠫདྷ"))
	for RBHSwGignYmu2 in IyqSwnbGtU95r3:
		sgAtq5bOkc = cBawilJXvK1m.findall(HkiMU0QrdzW3l6gwnT(u"ࠪࡠࡩ࠱ࡼ࡜࡞࠮ࡠ࠲ࡧ࠭ࡻࡃ࠰࡞ࡢ࠱ࠧན"),RBHSwGignYmu2,cBawilJXvK1m.DOTALL)
		jjqr1Rt6Xlhp = []
		for DIkSzwOoy7FnmBT6Rga in sgAtq5bOkc:
			if DIkSzwOoy7FnmBT6Rga.isdigit(): DIkSzwOoy7FnmBT6Rga = int(DIkSzwOoy7FnmBT6Rga)
			jjqr1Rt6Xlhp.append(DIkSzwOoy7FnmBT6Rga)
		nxOgpQ0KvHr3cTju8IBEz4A.append(jjqr1Rt6Xlhp)
	return nxOgpQ0KvHr3cTju8IBEz4A
def d5bw8zQCjcPixt9GXeBymMnLp(nxOgpQ0KvHr3cTju8IBEz4A):
	VlbpYdhoMwfNWIC = eHdDoxhJCEPMZFVa2fg
	for RBHSwGignYmu2 in nxOgpQ0KvHr3cTju8IBEz4A:
		for DIkSzwOoy7FnmBT6Rga in RBHSwGignYmu2: VlbpYdhoMwfNWIC += str(DIkSzwOoy7FnmBT6Rga)
		VlbpYdhoMwfNWIC += NxXMrsTC5FniYuRBOK8(u"ࠫ࠳࠭པ")
	VlbpYdhoMwfNWIC = VlbpYdhoMwfNWIC.strip(Cp6c5tZe8I0PxnAW(u"ࠬ࠴ࠧཕ"))
	return VlbpYdhoMwfNWIC
def w1HecvLmKCBrR95ASN(GFXuYIaiM4DNTjOVRg0oSsLn7p):
	H8hMP0qweGaor3OJjWBVzT = {}
	wmNWjvkgRT = EUFxlTArZpSsgD0()
	PCvw9dVF0748NOkHtYgj5K1a = hUsDr25MwJBp(GFXuYIaiM4DNTjOVRg0oSsLn7p)
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E in GFXuYIaiM4DNTjOVRg0oSsLn7p:
		if L1BnkG7RhvcXZoWfjdDHq3Uzu2E not in list(wmNWjvkgRT.keys()): continue
		dbZojKRgtLahS0 = wmNWjvkgRT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E]
		Q3pvnWLzmMi4ofbXPH,uME79trWK4kbQPp26lOiCw5Rayz,EHn6CXxDe3LYQ8vS9ZscK5hWJt = dbZojKRgtLahS0[x1Oa8bBf36EwsLMirtFc]
		nS2sOfpTLZxdc8HK7IJ6,GGXUERJrl89BLTt5Dyn14bYZOQ = IMsN2iOXlhF8trdn(L1BnkG7RhvcXZoWfjdDHq3Uzu2E)
		nnLE3baWTV9sDh05pevgAxM,yyZvhUkrLW1uoKzD = PCvw9dVF0748NOkHtYgj5K1a[L1BnkG7RhvcXZoWfjdDHq3Uzu2E]
		ZYv2TeVXEhCtr8b19qfg4jJ7mOl = uME79trWK4kbQPp26lOiCw5Rayz>GGXUERJrl89BLTt5Dyn14bYZOQ and nnLE3baWTV9sDh05pevgAxM
		VVe7Ii8ZmuK6 = YchIv6N09BaWPEj4tieAnluKZrRXT
		if not nnLE3baWTV9sDh05pevgAxM: UUIz4Oo2NX1Zh = CKUiyEe28zsZ(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧབ")
		elif not yyZvhUkrLW1uoKzD: UUIz4Oo2NX1Zh = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩབྷ")
		elif ZYv2TeVXEhCtr8b19qfg4jJ7mOl: UUIz4Oo2NX1Zh = S8i3sBYoHWdTURpAgN(u"ࠨࡱ࡯ࡨࠬམ")
		else:
			UUIz4Oo2NX1Zh = jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡪࡳࡴࡪࠧཙ")
			VVe7Ii8ZmuK6 = rDceXBpHkfVUYRJ3tIx95Z
		H8hMP0qweGaor3OJjWBVzT[L1BnkG7RhvcXZoWfjdDHq3Uzu2E] = VVe7Ii8ZmuK6,nS2sOfpTLZxdc8HK7IJ6,GGXUERJrl89BLTt5Dyn14bYZOQ,Q3pvnWLzmMi4ofbXPH,uME79trWK4kbQPp26lOiCw5Rayz,UUIz4Oo2NX1Zh,EHn6CXxDe3LYQ8vS9ZscK5hWJt
	return H8hMP0qweGaor3OJjWBVzT
def evP9UQfyEcG5hBwVzl(nNHfB2iT893EUZtSd,SVzI5LXyYBcDEC0,PEl2LgmK7kpfjzFMXTr6Jw=eHdDoxhJCEPMZFVa2fg,OP7eyzv2QSYgmrnu=eHdDoxhJCEPMZFVa2fg,zaUrQALuBIOJej=eHdDoxhJCEPMZFVa2fg):
	if lHfbysRrUV7m4CLSdkxc382n: nNHfB2iT893EUZtSd.update(SVzI5LXyYBcDEC0,PEl2LgmK7kpfjzFMXTr6Jw,OP7eyzv2QSYgmrnu,zaUrQALuBIOJej)
	else: nNHfB2iT893EUZtSd.update(SVzI5LXyYBcDEC0,PEl2LgmK7kpfjzFMXTr6Jw+kDUv7ouWrcgMe6OipQJm+OP7eyzv2QSYgmrnu+kDUv7ouWrcgMe6OipQJm+zaUrQALuBIOJej)
	return
def XPBZo1pUak(TWPUiXfNzJDF32e90KuRQgMl):
	def eMkWCHNS0RA31bs285xpJdLmiQ(zzAxdvkoMgaPy0,MdADX78ZcjEt2g1uqiS09WQUJP,mj9IefsJ5TNR0pGUOgk=jUcmHhgVvW0EdYOIfXeaDF(u"ࠥ࠴࠶࠸࠳࠵࠷࠹࠻࠽࠿ࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࠥཚ")):
		return ((zzAxdvkoMgaPy0 == x1Oa8bBf36EwsLMirtFc) and mj9IefsJ5TNR0pGUOgk[x1Oa8bBf36EwsLMirtFc]) or (eMkWCHNS0RA31bs285xpJdLmiQ(zzAxdvkoMgaPy0 // MdADX78ZcjEt2g1uqiS09WQUJP, MdADX78ZcjEt2g1uqiS09WQUJP, mj9IefsJ5TNR0pGUOgk).lstrip(mj9IefsJ5TNR0pGUOgk[x1Oa8bBf36EwsLMirtFc]) + mj9IefsJ5TNR0pGUOgk[zzAxdvkoMgaPy0 % MdADX78ZcjEt2g1uqiS09WQUJP])
	def xasv1eUcmCNybitRnG8TW6Qh7(ZD0hLsgMQXnvd2UK9oTY3br5Rtyul6, SZW6GRbrjFacLndM, ZMx0IJnBmA3T, U3uWoyOS8vgxwsLCt6E, adBVnbDCX3gjovSEftTlOs=None, OE9QR6mXSAri7Ngx38tB5Mn0jP=None, qqnFzXbCQKZ7xu=None):
		while (ZMx0IJnBmA3T):
			ZMx0IJnBmA3T-=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠶Ꮌ")
			if (U3uWoyOS8vgxwsLCt6E[ZMx0IJnBmA3T]): ZD0hLsgMQXnvd2UK9oTY3br5Rtyul6 = cBawilJXvK1m.sub(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠦࡡࡢࡢࠣཛ") + eMkWCHNS0RA31bs285xpJdLmiQ(ZMx0IJnBmA3T, SZW6GRbrjFacLndM) + ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡢ࡜ࡣࠤཛྷ"),  U3uWoyOS8vgxwsLCt6E[ZMx0IJnBmA3T], ZD0hLsgMQXnvd2UK9oTY3br5Rtyul6)
		return ZD0hLsgMQXnvd2UK9oTY3br5Rtyul6
	TWPUiXfNzJDF32e90KuRQgMl = TWPUiXfNzJDF32e90KuRQgMl.split(w2vjZmdJuY7c(u"࠭ࡽࠩࠩཝ"))[NSudqlOzja]
	TWPUiXfNzJDF32e90KuRQgMl = TWPUiXfNzJDF32e90KuRQgMl.rsplit(CKUiyEe28zsZ(u"ࠧࡴࡲ࡯࡭ࡹ࠭ཞ"))[x1Oa8bBf36EwsLMirtFc]+ehfEsaiJBSvbcULtNPVgykA2(u"ࠣࡵࡳࡰ࡮ࡺࠨࠨࡾࠪ࠭࠮ࠨཟ")
	kijEAOvZclmKhY7NJwe8S = eval(EX25Y0l8ILvz7QcRC(u"ࠩࡸࡲࡵࡧࡣ࡬ࠪࠪའ")+TWPUiXfNzJDF32e90KuRQgMl,{KW5bYS20wTF1LyCs9(u"ࠪࡦࡦࡹࡥࡏࠩཡ"):eMkWCHNS0RA31bs285xpJdLmiQ,LTN6DPEmrwehtZMy(u"ࠫࡺࡴࡰࡢࡥ࡮ࠫར"):xasv1eUcmCNybitRnG8TW6Qh7})
	return kijEAOvZclmKhY7NJwe8S
def z7CnJ4SVOIabe9tqjgPGhKfu1i6Uo2(code):
	_SxJayEP6opihcHml9f3ek=KW5bYS20wTF1LyCs9(u"ࠧ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞࠰࠵ࠢལ")
	def wOePjuqHWGsQ3SIztxTVlMY(OE9QR6mXSAri7Ngx38tB5Mn0jP,adBVnbDCX3gjovSEftTlOs,Nvh7KfmGjrVYs):
		ocQyFj2VxGaN0On = list(_SxJayEP6opihcHml9f3ek)
		pSEYCIZov3PFA2JGmrbMdh8u = ocQyFj2VxGaN0On[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠶Ꮍ"):adBVnbDCX3gjovSEftTlOs]
		dhcGSyo8Kn1mHZwvEAkzJ7NUq = ocQyFj2VxGaN0On[CKUiyEe28zsZ(u"࠰Ꮎ"):Nvh7KfmGjrVYs]
		OE9QR6mXSAri7Ngx38tB5Mn0jP = list(OE9QR6mXSAri7Ngx38tB5Mn0jP)[::-Cp6c5tZe8I0PxnAW(u"࠲Ꮏ")]
		bbAvLuM5lUWf4akiRdCTtsjqEH = I5bUBGpPXn0W6(u"࠲Ꮐ")
		for ZMx0IJnBmA3T,MdADX78ZcjEt2g1uqiS09WQUJP in enumerate(OE9QR6mXSAri7Ngx38tB5Mn0jP):
			if MdADX78ZcjEt2g1uqiS09WQUJP in pSEYCIZov3PFA2JGmrbMdh8u: bbAvLuM5lUWf4akiRdCTtsjqEH = bbAvLuM5lUWf4akiRdCTtsjqEH + pSEYCIZov3PFA2JGmrbMdh8u.index(MdADX78ZcjEt2g1uqiS09WQUJP)*adBVnbDCX3gjovSEftTlOs**ZMx0IJnBmA3T
		U3uWoyOS8vgxwsLCt6E = EX25Y0l8ILvz7QcRC(u"ࠨࠢཤ")
		while bbAvLuM5lUWf4akiRdCTtsjqEH > XugxFprC26zGM(u"࠳Ꮑ"):
			U3uWoyOS8vgxwsLCt6E = dhcGSyo8Kn1mHZwvEAkzJ7NUq[bbAvLuM5lUWf4akiRdCTtsjqEH%Nvh7KfmGjrVYs] + U3uWoyOS8vgxwsLCt6E
			bbAvLuM5lUWf4akiRdCTtsjqEH = (bbAvLuM5lUWf4akiRdCTtsjqEH - (bbAvLuM5lUWf4akiRdCTtsjqEH%Nvh7KfmGjrVYs))//Nvh7KfmGjrVYs
		return int(U3uWoyOS8vgxwsLCt6E) or RqLvTrID0yMVeClpYcnZ16i3X(u"࠴Ꮒ")
	def O4cSWZnDKBUkfvwg8mld(pSEYCIZov3PFA2JGmrbMdh8u,u,DtojFpCJKdPOTMgVh3SYrN5,SieKphYcXAaZN,adBVnbDCX3gjovSEftTlOs,qqnFzXbCQKZ7xu):
		qqnFzXbCQKZ7xu = ilBWK5nXxg1do4jENGC07Zq(u"ࠢࠣཥ");
		dhcGSyo8Kn1mHZwvEAkzJ7NUq = t3coAp06zvHrTl49bUVgx(u"࠵Ꮓ")
		while dhcGSyo8Kn1mHZwvEAkzJ7NUq < len(pSEYCIZov3PFA2JGmrbMdh8u):
			bbAvLuM5lUWf4akiRdCTtsjqEH = f90fGrlSEObDsuiA3U(u"࠶Ꮔ")
			wXz6YAZITjhHUK7 = w2vjZmdJuY7c(u"ࠣࠤས")
			while pSEYCIZov3PFA2JGmrbMdh8u[dhcGSyo8Kn1mHZwvEAkzJ7NUq] is not DtojFpCJKdPOTMgVh3SYrN5[adBVnbDCX3gjovSEftTlOs]:
				wXz6YAZITjhHUK7 = NxXMrsTC5FniYuRBOK8(u"ࠩࠪཧ").join([wXz6YAZITjhHUK7,pSEYCIZov3PFA2JGmrbMdh8u[dhcGSyo8Kn1mHZwvEAkzJ7NUq]])
				dhcGSyo8Kn1mHZwvEAkzJ7NUq = dhcGSyo8Kn1mHZwvEAkzJ7NUq + Cp6c5tZe8I0PxnAW(u"࠱Ꮕ")
			while bbAvLuM5lUWf4akiRdCTtsjqEH < len(DtojFpCJKdPOTMgVh3SYrN5):
				wXz6YAZITjhHUK7 = wXz6YAZITjhHUK7.replace(DtojFpCJKdPOTMgVh3SYrN5[bbAvLuM5lUWf4akiRdCTtsjqEH],str(bbAvLuM5lUWf4akiRdCTtsjqEH))
				bbAvLuM5lUWf4akiRdCTtsjqEH = bbAvLuM5lUWf4akiRdCTtsjqEH + LTN6DPEmrwehtZMy(u"࠲Ꮖ")
			qqnFzXbCQKZ7xu = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࠫཨ").join([qqnFzXbCQKZ7xu,ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࠬཀྵ").join(map(chr, [wOePjuqHWGsQ3SIztxTVlMY(wXz6YAZITjhHUK7,adBVnbDCX3gjovSEftTlOs,I5bUBGpPXn0W6(u"࠳࠳Ꮗ")) - SieKphYcXAaZN]))])
			dhcGSyo8Kn1mHZwvEAkzJ7NUq = dhcGSyo8Kn1mHZwvEAkzJ7NUq + KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠴Ꮘ")
		return qqnFzXbCQKZ7xu
	code = code.replace(XugxFprC26zGM(u"ࠬࡢ࡮ࠨཪ"),LTN6DPEmrwehtZMy(u"࠭ࠧཫ")).replace(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧ࡝ࡴࠪཬ"),XugxFprC26zGM(u"ࠨࠩ཭"))
	tuF2MLq3bwehmQJ5P = cBawilJXvK1m.findall(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩ࡟ࢁࡡ࠮ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠢࠩ࡞ࡺ࠯࠮ࠨࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭࠱࠮࡜ࡥ࠭ࠬࡠ࠮ࡢࠩࠨ཮"),code,cBawilJXvK1m.DOTALL)
	if tuF2MLq3bwehmQJ5P:
		tuF2MLq3bwehmQJ5P = list(tuF2MLq3bwehmQJ5P[ehfEsaiJBSvbcULtNPVgykA2(u"࠴Ꮙ")])
		for kcDJHZ2Mr1wbaI3d,code in enumerate(tuF2MLq3bwehmQJ5P):
			if code.isdigit(): tuF2MLq3bwehmQJ5P[kcDJHZ2Mr1wbaI3d] = int(code)
			else: tuF2MLq3bwehmQJ5P[kcDJHZ2Mr1wbaI3d] = code.replace(eNEhtuoi9gK8JaTpIXj(u"ࠪࡠࠧ࠭཯"),XugxFprC26zGM(u"ࠫࠬ཰"))
		PgFq0JyO1mavd72H9njDNrAi = O4cSWZnDKBUkfvwg8mld(*tuF2MLq3bwehmQJ5P)
		return PgFq0JyO1mavd72H9njDNrAi
	return t3coAp06zvHrTl49bUVgx(u"ཱࠬ࠭")
def i18i5WQ40awcSPFmjvEHqnfdV(FeTJrG4SkMf09iVys8A,ObP9xgNMRaWhev8c0YJfCu1lw=eHdDoxhJCEPMZFVa2fg):
	if ObP9xgNMRaWhev8c0YJfCu1lw==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭࡬ࡰࡹࡨࡶིࠬ"): FeTJrG4SkMf09iVys8A = cBawilJXvK1m.sub(eNEhtuoi9gK8JaTpIXj(u"ࡲࠨࠧ࡞࠴࠲࠿ࡁ࠮࡜ࡠࡿ࠷ࢃཱིࠧ"),lambda PqHBzDOWFiAc: PqHBzDOWFiAc.group(x1Oa8bBf36EwsLMirtFc).lower(),FeTJrG4SkMf09iVys8A)
	elif ObP9xgNMRaWhev8c0YJfCu1lw==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡷࡳࡴࡪࡸུࠧ"): FeTJrG4SkMf09iVys8A = cBawilJXvK1m.sub(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࡴࠪࠩࡠ࠶࠭࠺ࡣ࠰ࡾࡢࢁ࠲ࡾཱུࠩ"),lambda PqHBzDOWFiAc: PqHBzDOWFiAc.group(x1Oa8bBf36EwsLMirtFc).upper(),FeTJrG4SkMf09iVys8A)
	return FeTJrG4SkMf09iVys8A
def hUsDr25MwJBp(GFXuYIaiM4DNTjOVRg0oSsLn7p):
	jjzAxaCchmP,JQ3BC07KEcDZ = rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z
	Mh2SmYKyRLsevXCJpTajHZbi0Gf = ANKVD4WrwZCuUEl.connect(kpLM6WSIQ0X29nAT1gGDEa)
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.text_factory = str
	O4OfQzkx1KmeIHrjT97E0byA = Mh2SmYKyRLsevXCJpTajHZbi0Gf.cursor()
	if len(GFXuYIaiM4DNTjOVRg0oSsLn7p)==NSudqlOzja: Eifm4Cu5Yrxay6FwcZl = f90fGrlSEObDsuiA3U(u"ࠪࠬࠧ࠭ྲྀ")+GFXuYIaiM4DNTjOVRg0oSsLn7p[x1Oa8bBf36EwsLMirtFc]+bP01xn84BiQN(u"ࠫࠧ࠯ࠧཷ")
	else: Eifm4Cu5Yrxay6FwcZl = str(tuple(GFXuYIaiM4DNTjOVRg0oSsLn7p))
	O4OfQzkx1KmeIHrjT97E0byA.execute(RqLvTrID0yMVeClpYcnZ16i3X(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡧࡤࡥࡱࡱࡍࡉ࠲ࡥ࡯ࡣࡥࡰࡪࡪࠠࡇࡔࡒࡑࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࡙ࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡࡋࡑࠤࠬླྀ")+Eifm4Cu5Yrxay6FwcZl+KQ3sCe9Pzh(u"࠭ࠠ࠼ࠩཹ"))
	WLSfkYNla6rzo8K = O4OfQzkx1KmeIHrjT97E0byA.fetchall()
	PCvw9dVF0748NOkHtYgj5K1a = {}
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E in GFXuYIaiM4DNTjOVRg0oSsLn7p: PCvw9dVF0748NOkHtYgj5K1a[L1BnkG7RhvcXZoWfjdDHq3Uzu2E] = (rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	for L1BnkG7RhvcXZoWfjdDHq3Uzu2E,JQ3BC07KEcDZ in WLSfkYNla6rzo8K:
		jjzAxaCchmP = YchIv6N09BaWPEj4tieAnluKZrRXT
		JQ3BC07KEcDZ = JQ3BC07KEcDZ==NSudqlOzja
		PCvw9dVF0748NOkHtYgj5K1a[L1BnkG7RhvcXZoWfjdDHq3Uzu2E] = (jjzAxaCchmP,JQ3BC07KEcDZ)
	Mh2SmYKyRLsevXCJpTajHZbi0Gf.close()
	return PCvw9dVF0748NOkHtYgj5K1a
def ssIBAWh7QmzOoXqk8w(aNocw8R7zKPnyAfrF5vV1mp4DSlYM):
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = eHdDoxhJCEPMZFVa2fg
	if RRydns1CErYlIhwSx7.path.exists(aNocw8R7zKPnyAfrF5vV1mp4DSlYM):
		xV71kwLiJqS9UjdKEbun0OZG8TlA = open(aNocw8R7zKPnyAfrF5vV1mp4DSlYM,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡳࡤེࠪ")).read()
		if WHjh1POtMKlmgiy68RSqb: xV71kwLiJqS9UjdKEbun0OZG8TlA = xV71kwLiJqS9UjdKEbun0OZG8TlA.decode(m6PFtLblInpNZ8x)
		hlJ60Ifm9C3U = DIpuHqsKGS3ErJvk9taCRiX80(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡦ࡬ࡧࡹཻ࠭"),xV71kwLiJqS9UjdKEbun0OZG8TlA)
		if hlJ60Ifm9C3U:
			JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = {}
			for rBw5YZ31M7HOv in hlJ60Ifm9C3U.keys():
				JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1[rBw5YZ31M7HOv] = []
				for fq1RhxdGrgt4NOyToEImZ6alF in hlJ60Ifm9C3U[rBw5YZ31M7HOv]:
					fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
					fW4iNwld6COELJ10 = fq1RhxdGrgt4NOyToEImZ6alF[x1Oa8bBf36EwsLMirtFc]
					d8De716ZlA2 = fq1RhxdGrgt4NOyToEImZ6alF[NSudqlOzja]
					d8De716ZlA2 = O8pF1bNVh2BTZDAawLJmyXul75jfk(d8De716ZlA2)
					FeTJrG4SkMf09iVys8A = fq1RhxdGrgt4NOyToEImZ6alF[FB0pIzAoK8wqgd3UiY5]
					zVg9Tax3sjPSAvRJF7XHGy5hK8 = fq1RhxdGrgt4NOyToEImZ6alF[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
					e3XtKs70ifmRQY8VTLnpMdyr6 = fq1RhxdGrgt4NOyToEImZ6alF[BSw5mizCOsKxWrRDvtJuFajY]
					clAzmREWwXf6Gk = fq1RhxdGrgt4NOyToEImZ6alF[EX25Y0l8ILvz7QcRC(u"࠺Ꮚ")]
					if len(fq1RhxdGrgt4NOyToEImZ6alF)>eNEhtuoi9gK8JaTpIXj(u"࠼Ꮛ"): oh8Z06rUdqJ = fq1RhxdGrgt4NOyToEImZ6alF[eNEhtuoi9gK8JaTpIXj(u"࠼Ꮛ")]
					if len(fq1RhxdGrgt4NOyToEImZ6alF)>ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷Ꮜ"): YvJZXDaqbN = fq1RhxdGrgt4NOyToEImZ6alF[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷Ꮜ")]
					if len(fq1RhxdGrgt4NOyToEImZ6alF)>w2vjZmdJuY7c(u"࠹Ꮝ"): ruWSoIZkeKA = fq1RhxdGrgt4NOyToEImZ6alF[w2vjZmdJuY7c(u"࠹Ꮝ")]
					if aNocw8R7zKPnyAfrF5vV1mp4DSlYM==CCknZTXVNbG9Px0ds1hpQSMKB: e9eOLTElnu2wtabG7g06IpNS1i = fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,eHdDoxhJCEPMZFVa2fg,ruWSoIZkeKA
					else: e9eOLTElnu2wtabG7g06IpNS1i = fW4iNwld6COELJ10,d8De716ZlA2,FeTJrG4SkMf09iVys8A,zVg9Tax3sjPSAvRJF7XHGy5hK8,e3XtKs70ifmRQY8VTLnpMdyr6,clAzmREWwXf6Gk,oh8Z06rUdqJ,YvJZXDaqbN,ruWSoIZkeKA
					JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1[rBw5YZ31M7HOv].append(e9eOLTElnu2wtabG7g06IpNS1i)
		tYuVyvxLPqAg1r = str(JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1)
		if WHjh1POtMKlmgiy68RSqb: tYuVyvxLPqAg1r = tYuVyvxLPqAg1r.encode(m6PFtLblInpNZ8x)
		open(aNocw8R7zKPnyAfrF5vV1mp4DSlYM,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡺࡦོࠬ")).write(tYuVyvxLPqAg1r)
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def VqR1T8ZyLenuDtvEXz2Psip(uujC2KDqoT3rGHzPpAW1mf):
	uUz19AE7Qi685kKHVRso3 = uujC2KDqoT3rGHzPpAW1mf.split(LTN6DPEmrwehtZMy(u"ࠪ࠱ཽࠬ"),NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]
	aw3VMqrfJ4,rKXOTbZdRQ,UadpNT27E9xXy0KHqGrSw5nPgJjQk = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if   uUz19AE7Qi685kKHVRso3==LTN6DPEmrwehtZMy(u"ࠫࡆࡎࡗࡂࡍࠪཾ")		:	from AYXlyJHNEu			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==HkiMU0QrdzW3l6gwnT(u"ࠬࡇࡋࡐࡃࡐࠫཿ")		:	from Fea5Jby2kR			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==I5bUBGpPXn0W6(u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍࠨྀ")	:	from RRXJPG8pa2		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==EX25Y0l8ILvz7QcRC(u"ࠧࡂࡍ࡚ࡅࡒཱྀ࠭")		:	from CUTcRwrWs9			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫྂ")	:	from U3aGTmdeyr		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡄࡐࡆࡘࡁࡃࠩྃ")	:	from RszOfI8hTQ			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==f90fGrlSEObDsuiA3U(u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ྄ࠬ")	:	from cn6ikqxB7E		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==t3coAp06zvHrTl49bUVgx(u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ྅")	: 	from ECczxuoKNU		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==egY8Jti0smdLM3h1VQRSW(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ྆")	:	from DEzRowHVl5		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡁࡍࡏࡖࡘࡇࡇࠧ྇")	:	from hKeTC741rb		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==XugxFprC26zGM(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬྈ"):	from oOpkzLXbqE	import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪྉ")	:	from wLhCnjZVsc		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡅࡓࡐࡘࡁࠨྊ")		:	from lKEUgnXfoA			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪྋ")	:	from bAG2uJTBPr			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==S8i3sBYoHWdTURpAgN(u"ࠫࡈࡏࡍࡂ࠶࠳࠴ࠬྌ")	:	from o86agSUXJP		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡉࡉࡎࡃ࠷࡙ࠬྍ")	:	from hYSQu6oesZ			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨྎ")	:	from GPkJLhHnO3		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==egY8Jti0smdLM3h1VQRSW(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩྏ"):		from fHC5Ku3jMg		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==LTN6DPEmrwehtZMy(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄ࡚ࡓࡗࡑࠧྐ"):	from HHOUuDZCbl	import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==t3coAp06zvHrTl49bUVgx(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡓࠫྑ")	:	from jjR5Cdrlzi		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==CKUiyEe28zsZ(u"ࠪࡇࡎࡓࡁࡇࡃࡑࡗࠬྒ")	:	from tqjdgu536L		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡈࡏࡍࡂࡈࡕࡉࡊ࠭ྒྷ")	:	from KKSnTapYrA		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==t3coAp06zvHrTl49bUVgx(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨྔ")	:	from HH3fO9vDLW		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ietolwsjpIPK7Fr(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧྕ")	:	from iiyOUr0L5P		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==bP01xn84BiQN(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬྖ"):	from xp3idWHVor	import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==NxXMrsTC5FniYuRBOK8(u"ࠨࡆࡕࡅࡒࡇࡓ࠸ࠩྗ")	:	from zzJkBAFluL		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==eNEhtuoi9gK8JaTpIXj(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ྘")	:	from jTiokqLutZ		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==f90fGrlSEObDsuiA3U(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬྙ")	:	from BUiuKe0MF7		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭ྚ")	:	from SS58wEJpds		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==NxXMrsTC5FniYuRBOK8(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧྛ")	:	from EELl8BIS4h		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==bP01xn84BiQN(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠴ࠨྜ")	:	from TYaLP7hqv8		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==LTN6DPEmrwehtZMy(u"ࠧࡆࡉ࡜ࡈࡊࡇࡄࠨྜྷ")	:	from EiK31qe2fV		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==EX25Y0l8ILvz7QcRC(u"ࠨࡇࡊ࡝ࡓࡕࡗࠨྞ")	:	from rNYwsf7vbW			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡉࡅࡇࡘࡁࡌࡃࠪྟ")	:	from MNzu2YTQV1		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ྠ")	:	from bwc3If0s54		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ྡ")	:	from UR8FgEY7kJ		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==LyOR7f69iA(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧྡྷ")	:	from zFvwOqQyVL		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==Cp6c5tZe8I0PxnAW(u"࠭ࡆࡐࡕࡗࡅࠬྣ")		:	from fEkoiGHytd			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==eNEhtuoi9gK8JaTpIXj(u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩྤ")	:	from VkzL4nFWeO		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==I5bUBGpPXn0W6(u"ࠨࡋࡉࡍࡑࡓࠧྥ")		:	from y6MJSXaz5D			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==Cp6c5tZe8I0PxnAW(u"ࠩࡌࡔ࡙࡜ࠧྦ")		:	from oocDvzUeSu			import ZZUK8FJ4RTYCoVeg as aw3VMqrfJ4,A1AxPpad9tTLBbeIiOSQs2yq87hFW as rKXOTbZdRQ,pWmZEI8VqwO3eS5H1BizLCAy as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭ྦྷ")	:	from EsDtGZ51Bw		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==I5bUBGpPXn0W6(u"ࠫࡐࡇࡔࡌࡑࡗࡘ࡛࠭ྨ")	:	from vflsZo8aGn		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ietolwsjpIPK7Fr(u"ࠬࡑࡁࡕࡍࡒ࡙࡙ࡋࠧྩ")	:	from ySw97VLqvm		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ྪ")	:	from ulF3fqkQYR			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡍࡑࡇ࡝ࡓࡋࡔࠨྫ")	:	from CCMsTqwfJg		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡏ࠶࡙ࠬྫྷ")		:	from jVcFvDeLay			import ZZUK8FJ4RTYCoVeg as aw3VMqrfJ4,A1AxPpad9tTLBbeIiOSQs2yq87hFW as rKXOTbZdRQ,pWmZEI8VqwO3eS5H1BizLCAy as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡐࡓ࡛࡙࠴ࡖࠩྭ")	:	from YCszToelGr			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==Cp6c5tZe8I0PxnAW(u"ࠪࡑ࡞ࡉࡉࡎࡃࠪྮ")	:	from QoJZN84LHx			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡕࡇࡎࡆࡖࠪྯ")		:	from llZ9YqkM8N			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==Cp6c5tZe8I0PxnAW(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧྰ")	:	from Wuqtfv8FCG		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==egY8Jti0smdLM3h1VQRSW(u"࠭ࡓࡉࡃࡋࡍࡉࡔࡅࡘࡕࠪྱ"):	from j9zf52GVYr		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪྲ")	:	from fqcWFkVrY5		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡕࡋࡓࡋࡎࡁࠨླ")	:	from Zm95OxkaWF			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ietolwsjpIPK7Fr(u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫྴ")	:	from oIOSBNqcit		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==KQ3sCe9Pzh(u"ࠪࡗࡍࡕࡏࡇࡐࡈࡘࠬྵ")	:	from MR1UTOtlLc		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==EX25Y0l8ILvz7QcRC(u"ࠫࡘࡎࡏࡐࡈࡓࡖࡔ࠭ྶ")	:	from jAQcYTetKX		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ietolwsjpIPK7Fr(u"࡚ࠬࡖࡇࡗࡑࠫྷ")		:	from y8geHuIGD9			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡖࡂࡔࡅࡓࡓ࠭ྸ")	:	from Yy5BNqdfX3			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==XugxFprC26zGM(u"ࠧࡕࡘࡉ࡙ࡓ࠭ྐྵ")		:	from y8geHuIGD9			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡅࡌࡑࡆ࠺ࡐࠨྺ")	:	from QNrMSWRecB			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==Cp6c5tZe8I0PxnAW(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭ྻ"):	from bbzAeV1IUE		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==eNEhtuoi9gK8JaTpIXj(u"࡛ࠪࡊࡉࡉࡎࡃࠪྼ")	:	from l5ikFnmCqh			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==w2vjZmdJuY7c(u"ࠫ࡞ࡇࡑࡐࡖࠪ྽")		:	from ndKe3a9G5o			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==bP01xn84BiQN(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭྾")	:	from e27zOM5Tmb		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==LyOR7f69iA(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫ྿"):	from reKSbLqHZA	import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==S8i3sBYoHWdTURpAgN(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ࿀")	:	from wA61q20Uth		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩ࿁")	:	from klhVCY4fya		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==I5bUBGpPXn0W6(u"ࠩࡇࡖࡆࡓࡁࡄࡃࡉࡉࠬ࿂")	:	from vvgKHYMqlI		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡘࡎࡑࡁࡂࡖࠪ࿃")	:	from xg6MXmBYdS			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==eNEhtuoi9gK8JaTpIXj(u"ࠫࡖࡌࡉࡍࡏࠪ࿄")		:	from xEA0bpI9wa			import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==KQ3sCe9Pzh(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ࿅")	:	from BG3AgUIsF5		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==LyOR7f69iA(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨ࿆")	:	from nnV7pwMtzZ		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==I5bUBGpPXn0W6(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ࿇")	:	from mmbZG23Fxl		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==ietolwsjpIPK7Fr(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩ࿈")	:	from BYuk1Ms75w		import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4,ZZG8yFCkvXnPTgR6Jc as rKXOTbZdRQ,r07r9xeEFASJXluImT as UadpNT27E9xXy0KHqGrSw5nPgJjQk
	elif uUz19AE7Qi685kKHVRso3==t3coAp06zvHrTl49bUVgx(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨ࿉"):	from aEYz21xswN	import pDomkPy18JGi7xQ302dYVqHLM9WTCj as aw3VMqrfJ4
	return aw3VMqrfJ4,rKXOTbZdRQ,UadpNT27E9xXy0KHqGrSw5nPgJjQk
def L7IPyDUvXQwA2e9fChNruZcYM50(sn9KybUtqNivPWZDdE4Ck2,kkMFwqXnC9v0y,showDialogs):
	vR9cOpMtk51j(iwIlVQsgYezu,I5bUBGpPXn0W6(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨ࿊")+sn9KybUtqNivPWZDdE4Ck2+HkiMU0QrdzW3l6gwnT(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧ࿋")+str(kkMFwqXnC9v0y)+I5bUBGpPXn0W6(u"ࠬࠦ࡝ࠨ࿌"))
	nNHfB2iT893EUZtSd = R62V7GXNPvf8()
	nNHfB2iT893EUZtSd.create(ilBWK5nXxg1do4jENGC07Zq(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ࿍"),KQ3sCe9Pzh(u"๋ࠧฮิ๎ࠥอไร่ࠣๅา฻ࠠศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํ้ࠠส฼ำ์อࠠิ๊ไࠤฯฮฯฤࠢ฼้้๐ษࠡฮ็ฬࠥอไๆๆไࠤ๊์ࠠศๆศ๊ฯืๆหࠩ࿎"))
	PRdz7Yfy1GOgBV98KDbt0SvUj = jUcmHhgVvW0EdYOIfXeaDF(u"࠳࠳࠶࠹Ꮞ")*jUcmHhgVvW0EdYOIfXeaDF(u"࠳࠳࠶࠹Ꮞ")
	nUoa1bRj5d7OlKJfv9q36Z4mT = LTN6DPEmrwehtZMy(u"࠴Ꮟ")*PRdz7Yfy1GOgBV98KDbt0SvUj
	import requests as sOGcCTIoQ85ARH6
	qldY3LPe0pDiuyoM8vIH = sOGcCTIoQ85ARH6.get(sn9KybUtqNivPWZDdE4Ck2,stream=YchIv6N09BaWPEj4tieAnluKZrRXT,headers=kkMFwqXnC9v0y)
	D0mZ51kIs83Yclj4 = qldY3LPe0pDiuyoM8vIH.headers
	qldY3LPe0pDiuyoM8vIH.close()
	ECoJNwHrIvlBeUy8 = bytes()
	if not D0mZ51kIs83Yclj4:
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ࿏"),t3coAp06zvHrTl49bUVgx(u"ࠩส่อืๆศ็ฯࠤ้๋๋ࠠฬ่็๋ࠦๅ็ࠢอั๊๐ไࠡษ็้้็ࠠศๆ่฻้๎ศ๊ࠡสุ่ฮศࠡไาࠤ๏้่็ࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦ࠮ࠡฮิฬࠥะอๆ์็ࠤฬ๊ๅๅใ้ࠣึฯࠠฤะิํࠬ࿐"))
		nNHfB2iT893EUZtSd.close()
	else:
		if CKUiyEe28zsZ(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫ࿑") not in list(D0mZ51kIs83Yclj4.keys()): uUK0yLvEsgQJ31XND = x1Oa8bBf36EwsLMirtFc
		else: uUK0yLvEsgQJ31XND = int(D0mZ51kIs83Yclj4[bP01xn84BiQN(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡒࡥ࡯ࡩࡷ࡬ࠬ࿒")])
		ylMUSErbOBa = str(int(LyOR7f69iA(u"࠶࠶࠰࠱Ꮡ")*uUK0yLvEsgQJ31XND/PRdz7Yfy1GOgBV98KDbt0SvUj)/ehfEsaiJBSvbcULtNPVgykA2(u"࠵࠵࠶࠰࠯࠲Ꮠ"))
		c5gG4NyMTUzL = int(uUK0yLvEsgQJ31XND/nUoa1bRj5d7OlKJfv9q36Z4mT)+NSudqlOzja
		if ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡒࡢࡰࡪࡩࠬ࿓") in list(D0mZ51kIs83Yclj4.keys()) and uUK0yLvEsgQJ31XND>PRdz7Yfy1GOgBV98KDbt0SvUj:
			raRQqbtxAZG = YchIv6N09BaWPEj4tieAnluKZrRXT
			QUpkoH9a4JbO6m5sz = []
			uK7EIBhznLmoC2qZR = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠷࠰Ꮢ")
			QUpkoH9a4JbO6m5sz.append(str(x1Oa8bBf36EwsLMirtFc*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+HkiMU0QrdzW3l6gwnT(u"࠭࠭ࠨ࿔")+str(NSudqlOzja*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(NSudqlOzja*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧ࠮ࠩ࿕")+str(FB0pIzAoK8wqgd3UiY5*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(FB0pIzAoK8wqgd3UiY5*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+KW5bYS20wTF1LyCs9(u"ࠨ࠯ࠪ࿖")+str(bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࠰ࠫ࿗")+str(BSw5mizCOsKxWrRDvtJuFajY*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(BSw5mizCOsKxWrRDvtJuFajY*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪ࠱ࠬ࿘")+str(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠵Ꮣ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(J7divaGOCgq2SLfXpDzZYN58wc(u"࠶Ꮤ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+KW5bYS20wTF1LyCs9(u"ࠫ࠲࠭࿙")+str(XugxFprC26zGM(u"࠸Ꮥ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(ietolwsjpIPK7Fr(u"࠺Ꮧ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+KW5bYS20wTF1LyCs9(u"ࠬ࠳ࠧ࿚")+str(ilBWK5nXxg1do4jENGC07Zq(u"࠺Ꮦ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(RqLvTrID0yMVeClpYcnZ16i3X(u"࠽Ꮩ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭࠭ࠨ࿛")+str(wY1p9mP03S8drbcH64t5WQkv(u"࠽Ꮨ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(ehfEsaiJBSvbcULtNPVgykA2(u"࠹Ꮫ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧ࠮ࠩ࿜")+str(S8i3sBYoHWdTURpAgN(u"࠹Ꮪ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR-NSudqlOzja))
			QUpkoH9a4JbO6m5sz.append(str(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠻Ꮬ")*uUK0yLvEsgQJ31XND//uK7EIBhznLmoC2qZR)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ࠯ࠪ࿝"))
			DD4dJj1r6LnsX59ct = float(c5gG4NyMTUzL)/uK7EIBhznLmoC2qZR
			RVq0UnW1O63dskCE2elXT = DD4dJj1r6LnsX59ct/int(NSudqlOzja+DD4dJj1r6LnsX59ct)
		else:
			raRQqbtxAZG = rDceXBpHkfVUYRJ3tIx95Z
			uK7EIBhznLmoC2qZR = NSudqlOzja
			RVq0UnW1O63dskCE2elXT = NSudqlOzja
		vR9cOpMtk51j(iwIlVQsgYezu,t3coAp06zvHrTl49bUVgx(u"ࠩ࠱ࡠࡹࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡲࡢࡰࡪࡩࡸࡀࠠ࡜ࠢࠪ࿞")+str(raRQqbtxAZG)+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࠤࡢࠦࠠࠡࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬ࿟")+str(uUK0yLvEsgQJ31XND)+I5bUBGpPXn0W6(u"ࠫࠥࡣࠧ࿠"))
		gMmB3iopS0ZXrOFewhcxt,kUqJu8ZfV5NPsDR = x1Oa8bBf36EwsLMirtFc,x1Oa8bBf36EwsLMirtFc
		for nxNPDeuVwTb3 in range(uK7EIBhznLmoC2qZR):
			W9PzsMeLJTc83mS45G17n = kkMFwqXnC9v0y.copy()
			if raRQqbtxAZG: W9PzsMeLJTc83mS45G17n[I5bUBGpPXn0W6(u"ࠬࡘࡡ࡯ࡩࡨࠫ࿡")] = J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡢࡺࡶࡨࡷࡂ࠭࿢")+QUpkoH9a4JbO6m5sz[nxNPDeuVwTb3]
			qldY3LPe0pDiuyoM8vIH = sOGcCTIoQ85ARH6.get(sn9KybUtqNivPWZDdE4Ck2,stream=YchIv6N09BaWPEj4tieAnluKZrRXT,headers=W9PzsMeLJTc83mS45G17n,timeout=HkiMU0QrdzW3l6gwnT(u"࠶࠴࠵Ꮭ"))
			for eh5Z93tqmpNIWlfOrgi06MnjEB8Rd in qldY3LPe0pDiuyoM8vIH.iter_content(chunk_size=nUoa1bRj5d7OlKJfv9q36Z4mT):
				if nNHfB2iT893EUZtSd.iscanceled():
					vR9cOpMtk51j(iwIlVQsgYezu,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡉࡡ࡯ࡥࡨࡰࡪࡪࠧ࿣"))
					break
				gMmB3iopS0ZXrOFewhcxt += RVq0UnW1O63dskCE2elXT
				ECoJNwHrIvlBeUy8 += eh5Z93tqmpNIWlfOrgi06MnjEB8Rd
				if not kUqJu8ZfV5NPsDR: kUqJu8ZfV5NPsDR = len(eh5Z93tqmpNIWlfOrgi06MnjEB8Rd)
				if uUK0yLvEsgQJ31XND: evP9UQfyEcG5hBwVzl(nNHfB2iT893EUZtSd,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠵࠵࠶Ꮮ")*gMmB3iopS0ZXrOFewhcxt//c5gG4NyMTUzL,egY8Jti0smdLM3h1VQRSW(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲ࠦวๅฮีลࠥืโๆࠩ࿤"),str(egY8Jti0smdLM3h1VQRSW(u"࠶࠶࠰࠯࠲Ꮯ")*kUqJu8ZfV5NPsDR*gMmB3iopS0ZXrOFewhcxt//nUoa1bRj5d7OlKJfv9q36Z4mT//egY8Jti0smdLM3h1VQRSW(u"࠶࠶࠰࠯࠲Ꮯ"))+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࠣ࠳ࠥ࠭࿥")+ylMUSErbOBa+ietolwsjpIPK7Fr(u"ࠪࠤࡒࡈࠧ࿦"))
				else: evP9UQfyEcG5hBwVzl(nNHfB2iT893EUZtSd,kUqJu8ZfV5NPsDR*gMmB3iopS0ZXrOFewhcxt//nUoa1bRj5d7OlKJfv9q36Z4mT,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫั๊ศࠡษ็้้็࠺࠮ࠩ࿧"),str(Cp6c5tZe8I0PxnAW(u"࠷࠰࠱࠰࠳Ꮰ")*kUqJu8ZfV5NPsDR*gMmB3iopS0ZXrOFewhcxt//nUoa1bRj5d7OlKJfv9q36Z4mT//Cp6c5tZe8I0PxnAW(u"࠷࠰࠱࠰࠳Ꮰ"))+Cp6c5tZe8I0PxnAW(u"ࠬࠦࡍࡃࠩ࿨"))
			qldY3LPe0pDiuyoM8vIH.close()
		nNHfB2iT893EUZtSd.close()
		if len(ECoJNwHrIvlBeUy8)<uUK0yLvEsgQJ31XND and uUK0yLvEsgQJ31XND>x1Oa8bBf36EwsLMirtFc:
			vR9cOpMtk51j(iwIlVQsgYezu,eNEhtuoi9gK8JaTpIXj(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡴࡸࠠࡤࡣࡱࡧࡪࡲࡥࡥࠢࡤࡸ࠿࡛ࠦࠡࠩ࿩")+str(len(ECoJNwHrIvlBeUy8)//PRdz7Yfy1GOgBV98KDbt0SvUj)+f90fGrlSEObDsuiA3U(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈࡵࡳࡲࠦࡴࡰࡶࡤࡰࠥࡵࡦ࠻ࠢ࡞ࠤࠬ࿪")+ylMUSErbOBa+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࠢࡐࡆࠥࡣࠧ࿫"))
			jF1DqR2Y3VrIShwBeOpco = vKD1rqZCXUbcR7n38VyatMSEL(eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠩศ่฿อม๊ࠡัีําࠧ࿬"),NxXMrsTC5FniYuRBOK8(u"ࠪหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠪ࿭"),NxXMrsTC5FniYuRBOK8(u"ࠫส฿วะหࠣะ้ฮࠠศๆ่่ๆ࠭࿮"),NxXMrsTC5FniYuRBOK8(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࿯"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭แีๆࠣๅ๏ࠦฬๅสࠣห้๋ไโࠢ࡟ࡲ๊ࠥไฤีไࠤาีหࠡะฺวࠥ็๊ࠡฬะ้๏๊ࠠศๆ่่ๆࠦ࡜࡯ࠢอ้ࠥาไษࠢࠪ࿰")+str(len(ECoJNwHrIvlBeUy8)//PRdz7Yfy1GOgBV98KDbt0SvUj)+XugxFprC26zGM(u"ࠧࠡ็ํ฾ฬฮว๋ฬ้๋ࠣࠦๅอ็๋฽ࠥ࠭࿱")+ylMUSErbOBa+ietolwsjpIPK7Fr(u"ࠨ่ࠢ๎฿อศศ์อࠤࡡࡴࠠอำหࠤั๊ศࠡษ็้้็ࠠๆำฬࠤศิั๊ࠢ࡟ࡲࠥํไࠡฬิ๎ิࠦวิฬัำฬ๋ࠠศๆ่่ๆࠦวๅ่สๆฺࠦฟࠢࠣࠪ࿲"))
			if jF1DqR2Y3VrIShwBeOpco==FB0pIzAoK8wqgd3UiY5: ECoJNwHrIvlBeUy8 = L7IPyDUvXQwA2e9fChNruZcYM50(sn9KybUtqNivPWZDdE4Ck2,kkMFwqXnC9v0y,showDialogs)
			elif jF1DqR2Y3VrIShwBeOpco==NSudqlOzja: vR9cOpMtk51j(iwIlVQsgYezu,ehfEsaiJBSvbcULtNPVgykA2(u"ࠩ࠱ࡠࡹࡔ࡯ࡵࠢࡦࡳࡲࡶ࡬ࡦࡶࡨࡨࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡥࡥࠢࡩ࡭ࡱ࡫ࠠࡪࡵࠣࡥࡨࡩࡥࡱࡶࡨࡨࠥࡧ࡮ࡥࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡤࠨ࿳"))
			else: return eHdDoxhJCEPMZFVa2fg
			if not ECoJNwHrIvlBeUy8: return eHdDoxhJCEPMZFVa2fg
		else: vR9cOpMtk51j(iwIlVQsgYezu,ehfEsaiJBSvbcULtNPVgykA2(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠲ࠥࠦࠠࡇ࡫࡯ࡩ࡙ࠥࡩࡻࡧ࠽ࠤࡠࠦࠧ࿴")+ylMUSErbOBa+wY1p9mP03S8drbcH64t5WQkv(u"ࠫࠥࡓࡂࠡ࡟ࠪ࿵"))
	return ECoJNwHrIvlBeUy8
def LF4IOmvXDg(EERWJf1adv67):
	return qldY3LPe0pDiuyoM8vIH
def hpCAb2IZHvVy5Wc8l0m7qw(ip=eHdDoxhJCEPMZFVa2fg):
	global XJGTegisjUW34EymYo8KNRrSdn
	if XJGTegisjUW34EymYo8KNRrSdn: return XJGTegisjUW34EymYo8KNRrSdn
	tkpD7ol8FE,CNqlQiod9T4Z,vCJQ4d5P79NhZD8r,KmNQ9zW8o7RSAkvJgj,MniJroCaBgupsIwyvqhS9VlRE,zn6e71rRTsYZvjKlBGaydpt0 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	FeTJrG4SkMf09iVys8A = ietolwsjpIPK7Fr(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯ࡰࡸࡪࡲ࠲࡮ࡹ࠯ࠨ࿶")+ip+HkiMU0QrdzW3l6gwnT(u"࠭࠿ࡰࡷࡷࡴࡺࡺ࠽࡫ࡵࡲࡲࠫ࡬ࡩࡦ࡮ࡧࡷࡂ࡯ࡰ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡥࡣࡰࡦࡨ࠰ࡷ࡫ࡧࡪࡱࡱ࠰ࡨ࡯ࡴࡺ࠮ࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫ࿷")
	kkMFwqXnC9v0y = {KW5bYS20wTF1LyCs9(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࿸"):eHdDoxhJCEPMZFVa2fg}
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡉࡈࡘࠬ࿹"),FeTJrG4SkMf09iVys8A,eHdDoxhJCEPMZFVa2fg,kkMFwqXnC9v0y,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊࡕࡌࡐࡅࡄࡘࡎࡕࡎ࠮࠳ࡶࡸࠬ࿺"))
	if not qldY3LPe0pDiuyoM8vIH.succeeded: XJGTegisjUW34EymYo8KNRrSdn = ip+bP01xn84BiQN(u"ࠪ࠰ࠬ࿻")+tkpD7ol8FE+f90fGrlSEObDsuiA3U(u"ࠫ࠱࠭࿼")+CNqlQiod9T4Z+ehfEsaiJBSvbcULtNPVgykA2(u"ࠬ࠲ࠧ࿽")+KmNQ9zW8o7RSAkvJgj+wY1p9mP03S8drbcH64t5WQkv(u"࠭ࠬࠨ࿾")+MniJroCaBgupsIwyvqhS9VlRE+XugxFprC26zGM(u"ࠧ࠭ࠩ࿿")+zn6e71rRTsYZvjKlBGaydpt0
	else:
		a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
		a3glxPAGFXm2kzq = cBawilJXvK1m.findall(CKUiyEe28zsZ(u"ࠨ࡞ࡾ࠲࠯ࡅ࡜ࡾ࡞ࢀࠫက"),a3glxPAGFXm2kzq,cBawilJXvK1m.DOTALL)
		if a3glxPAGFXm2kzq:
			a3glxPAGFXm2kzq = a3glxPAGFXm2kzq[x1Oa8bBf36EwsLMirtFc]
			ElPy6ApVB1qsDk5ICZ = DIpuHqsKGS3ErJvk9taCRiX80(LyOR7f69iA(u"ࠩࡧ࡭ࡨࡺࠧခ"),a3glxPAGFXm2kzq)
			iZhe9H4FNpngaBqV8vO = list(ElPy6ApVB1qsDk5ICZ.keys())
			if iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪ࡭ࡵ࠭ဂ") in iZhe9H4FNpngaBqV8vO: ip = ElPy6ApVB1qsDk5ICZ[eNEhtuoi9gK8JaTpIXj(u"ࠫ࡮ࡶࠧဃ")]
			if jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴࠨင") in iZhe9H4FNpngaBqV8vO: tkpD7ol8FE = ElPy6ApVB1qsDk5ICZ[wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩစ")]
			if HkiMU0QrdzW3l6gwnT(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨဆ") in iZhe9H4FNpngaBqV8vO: CNqlQiod9T4Z = ElPy6ApVB1qsDk5ICZ[EX25Y0l8ILvz7QcRC(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩဇ")]
			if t3coAp06zvHrTl49bUVgx(u"ࠩࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥࠨဈ") in iZhe9H4FNpngaBqV8vO: vCJQ4d5P79NhZD8r = ElPy6ApVB1qsDk5ICZ[Cp6c5tZe8I0PxnAW(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩဉ")]
			if KW5bYS20wTF1LyCs9(u"ࠫࡷ࡫ࡧࡪࡱࡱࠫည") in iZhe9H4FNpngaBqV8vO: KmNQ9zW8o7RSAkvJgj = ElPy6ApVB1qsDk5ICZ[S8i3sBYoHWdTURpAgN(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬဋ")]
			if bP01xn84BiQN(u"࠭ࡣࡪࡶࡼࠫဌ") in iZhe9H4FNpngaBqV8vO: MniJroCaBgupsIwyvqhS9VlRE = ElPy6ApVB1qsDk5ICZ[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡤ࡫ࡷࡽࠬဍ")]
			if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪဎ") in iZhe9H4FNpngaBqV8vO:
				zn6e71rRTsYZvjKlBGaydpt0 = ElPy6ApVB1qsDk5ICZ[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫဏ")][eNEhtuoi9gK8JaTpIXj(u"ࠪࡹࡹࡩࠧတ")]
				if zn6e71rRTsYZvjKlBGaydpt0[x1Oa8bBf36EwsLMirtFc] not in [eNEhtuoi9gK8JaTpIXj(u"ࠫ࠲࠭ထ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬ࠱ࠧဒ")]: zn6e71rRTsYZvjKlBGaydpt0 = bP01xn84BiQN(u"࠭ࠫࠨဓ")+zn6e71rRTsYZvjKlBGaydpt0
			XJGTegisjUW34EymYo8KNRrSdn = ip+ilBWK5nXxg1do4jENGC07Zq(u"ࠧ࠭ࠩန")+tkpD7ol8FE+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨ࠮ࠪပ")+CNqlQiod9T4Z+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩ࠯ࠫဖ")+KmNQ9zW8o7RSAkvJgj+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪ࠰ࠬဗ")+MniJroCaBgupsIwyvqhS9VlRE+KW5bYS20wTF1LyCs9(u"ࠫ࠱࠭ဘ")+zn6e71rRTsYZvjKlBGaydpt0
			if WHjh1POtMKlmgiy68RSqb: XJGTegisjUW34EymYo8KNRrSdn = XJGTegisjUW34EymYo8KNRrSdn.encode(m6PFtLblInpNZ8x).decode(Cp6c5tZe8I0PxnAW(u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭မ"))
	XJGTegisjUW34EymYo8KNRrSdn = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(XJGTegisjUW34EymYo8KNRrSdn)
	return XJGTegisjUW34EymYo8KNRrSdn
def F1T64yBoQa5b(jb9ilIMvRJuEY):
	ijIbeRAdlvSOcaLKVDrC4Y,showDialogs = eHdDoxhJCEPMZFVa2fg,YchIv6N09BaWPEj4tieAnluKZrRXT
	if jb9ilIMvRJuEY.count(ilBWK5nXxg1do4jENGC07Zq(u"࠭࡟ࠨယ"))>=FB0pIzAoK8wqgd3UiY5:
		jb9ilIMvRJuEY,ijIbeRAdlvSOcaLKVDrC4Y = jb9ilIMvRJuEY.split(eNEhtuoi9gK8JaTpIXj(u"ࠧࡠࠩရ"),NSudqlOzja)
		ijIbeRAdlvSOcaLKVDrC4Y = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡡࠪလ")+ijIbeRAdlvSOcaLKVDrC4Y
		if NxXMrsTC5FniYuRBOK8(u"ࠩࡢࡒࡔࡊࡉࡂࡎࡒࡋࡘࡥࠧဝ") in ijIbeRAdlvSOcaLKVDrC4Y: showDialogs = rDceXBpHkfVUYRJ3tIx95Z
		else: showDialogs = YchIv6N09BaWPEj4tieAnluKZrRXT
	return jb9ilIMvRJuEY,ijIbeRAdlvSOcaLKVDrC4Y,showDialogs
def DucliOC0wXs():
	ptoTgEv6Kly = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,LTN6DPEmrwehtZMy(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩသ"))
	N0NUlnZHtbJMmCoGSQzsOYT8 = x1Oa8bBf36EwsLMirtFc
	if RRydns1CErYlIhwSx7.path.exists(ptoTgEv6Kly):
		for dyablPViz25TGKJ in RRydns1CErYlIhwSx7.listdir(ptoTgEv6Kly):
			if bP01xn84BiQN(u"ࠫ࠳ࡶࡹࡰࠩဟ") in dyablPViz25TGKJ: continue
			if t3coAp06zvHrTl49bUVgx(u"ࠬࡥ࡟ࡱࡻࡦࡥࡨ࡮ࡥࡠࡡࠪဠ") in dyablPViz25TGKJ: continue
			u5wesnAHzbZU81EXCK = RRydns1CErYlIhwSx7.path.join(ptoTgEv6Kly,dyablPViz25TGKJ)
			UlRHxvXC3bD2dJi8,ZlJIRM4voWapmOU8ykibgT5D1cd = tSCWKXTbwog4L(u5wesnAHzbZU81EXCK)
			N0NUlnZHtbJMmCoGSQzsOYT8 += UlRHxvXC3bD2dJi8
	return N0NUlnZHtbJMmCoGSQzsOYT8
def qP0u35ob92fkOYMJLUtdecR(showDialogs):
	it48RVP61xTNFmnD = MoO74hKeqm8fFka.getSetting(HkiMU0QrdzW3l6gwnT(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫအ"))
	wXuKJCVzh48ceNRDva = EeZHTwQUW2BuvJyIh(pyifuNFdxe,w2vjZmdJuY7c(u"ࠧࡴࡶࡵࠫဢ"),CKUiyEe28zsZ(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫဣ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫဤ"))
	kBDhXd3JHw9nVpE0g8,c0pWzdJoL6Ss3b = it48RVP61xTNFmnD,wXuKJCVzh48ceNRDva
	hExiXtnp6emUHOf5yaC1sk7uY,r6eWEITzJptGYLD = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if NSudqlOzja:
		FeTJrG4SkMf09iVys8A = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪဥ")][bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
		J4JZ8HDlxfUjO0 = hpCAb2IZHvVy5Wc8l0m7qw()
		CNqlQiod9T4Z = J4JZ8HDlxfUjO0.split(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫ࠱࠭ဦ"))[FB0pIzAoK8wqgd3UiY5]
		N0NUlnZHtbJMmCoGSQzsOYT8 = DucliOC0wXs()
		zo8KfmNxYVlhGZ0A6bEM7igIa5 = {QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡻࡳࡦࡴࠪဧ"):ZylBO1ktRGvdJ0,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧဨ"):MCrWtwnF2TViZOD7z0pXgqI4,LyOR7f69iA(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨဩ"):CNqlQiod9T4Z,I5bUBGpPXn0W6(u"ࠨ࡫ࡧࡷࠬဪ"):VarSZWbo4B6y3htcxuifmD9FYqnLvp(N0NUlnZHtbJMmCoGSQzsOYT8)}
		qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,KQ3sCe9Pzh(u"ࠩࡓࡓࡘ࡚ࠧါ"),FeTJrG4SkMf09iVys8A,zo8KfmNxYVlhGZ0A6bEM7igIa5,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧာ"))
		if not qldY3LPe0pDiuyoM8vIH.succeeded:
			if it48RVP61xTNFmnD in [eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡓࡋࡗࠨိ")]: kBDhXd3JHw9nVpE0g8 = jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫီ")
			elif it48RVP61xTNFmnD==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡏࡍࡆࠪု"): kBDhXd3JHw9nVpE0g8 = t3coAp06zvHrTl49bUVgx(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ူ")
		else:
			rrD7WQj6Nm9zEBgZOy3Ta = qldY3LPe0pDiuyoM8vIH.content
			rrD7WQj6Nm9zEBgZOy3Ta = DIpuHqsKGS3ErJvk9taCRiX80(w2vjZmdJuY7c(u"ࠨ࡮࡬ࡷࡹ࠭ေ"),rrD7WQj6Nm9zEBgZOy3Ta)
			rrD7WQj6Nm9zEBgZOy3Ta = sorted(rrD7WQj6Nm9zEBgZOy3Ta,reverse=YchIv6N09BaWPEj4tieAnluKZrRXT,key=lambda key: int(key[x1Oa8bBf36EwsLMirtFc]))
			r6eWEITzJptGYLD,c0pWzdJoL6Ss3b = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
			for Ac3YgwmVxlvfaWRsZHp8zNoeGyd,Adz2SwtyGCF,bOEZeag9A1qL206uh3o75 in rrD7WQj6Nm9zEBgZOy3Ta:
				if Ac3YgwmVxlvfaWRsZHp8zNoeGyd==ilBWK5nXxg1do4jENGC07Zq(u"ࠩ࠳ࠫဲ"):
					r6eWEITzJptGYLD += bOEZeag9A1qL206uh3o75+t3coAp06zvHrTl49bUVgx(u"ࠪ࠾࠿࠭ဳ")
					continue
				if c0pWzdJoL6Ss3b: c0pWzdJoL6Ss3b += kDUv7ouWrcgMe6OipQJm+SbyWQGMDnV+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪဴ")+Nat0Dx9puRUWCsgz6JyFhY3+wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡢ࡮࡝ࡰࠪဵ")
				hh9a2nubgOHLGp7Vo = bOEZeag9A1qL206uh3o75.split(kDUv7ouWrcgMe6OipQJm)[x1Oa8bBf36EwsLMirtFc]
				IITWl8rZUFOqDJdvxQMe1askm40i = HkiMU0QrdzW3l6gwnT(u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪံ") if Adz2SwtyGCF else eHdDoxhJCEPMZFVa2fg
				c0pWzdJoL6Ss3b += bOEZeag9A1qL206uh3o75.replace(hh9a2nubgOHLGp7Vo,OR97bMGecfgDCqux3YdAZ6y+hh9a2nubgOHLGp7Vo+IITWl8rZUFOqDJdvxQMe1askm40i+Nat0Dx9puRUWCsgz6JyFhY3)+kDUv7ouWrcgMe6OipQJm
			c0pWzdJoL6Ss3b = kDUv7ouWrcgMe6OipQJm+c0pWzdJoL6Ss3b+NxXMrsTC5FniYuRBOK8(u"ࠧ࡝ࡰ࡟ࡲ့ࠬ")
			r6eWEITzJptGYLD = r6eWEITzJptGYLD.strip(HkiMU0QrdzW3l6gwnT(u"ࠨ࠼࠽ࠫး"))
			hExiXtnp6emUHOf5yaC1sk7uY = MoO74hKeqm8fFka.getSetting(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵္ࠬ"))
			if c0pWzdJoL6Ss3b==wXuKJCVzh48ceNRDva and it48RVP61xTNFmnD in [QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡓࡑࡊ်ࠧ"),KQ3sCe9Pzh(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪျ")]: kBDhXd3JHw9nVpE0g8 = Cp6c5tZe8I0PxnAW(u"ࠬࡕࡌࡅࠩြ")
			else: kBDhXd3JHw9nVpE0g8 = XugxFprC26zGM(u"࠭ࡎࡆ࡙ࠪွ")
			CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪှ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪဿ"),c0pWzdJoL6Ss3b,ICRfWub2vqlor0Q)
			MoO74hKeqm8fFka.setSetting(f90fGrlSEObDsuiA3U(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ၀"),VarSZWbo4B6y3htcxuifmD9FYqnLvp(a8HLTkO2ns49yGNgiroS))
			MoO74hKeqm8fFka.setSetting(LyOR7f69iA(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭၁"),r6eWEITzJptGYLD)
			RFi2SjVJsh6xkmID9HwTBzYCdXE = TOjyaHnYozURG.md5(bP01xn84BiQN(u"࠵Ꮱ")*r6eWEITzJptGYLD.encode(m6PFtLblInpNZ8x)).hexdigest()
			RFi2SjVJsh6xkmID9HwTBzYCdXE = TOjyaHnYozURG.md5(NxXMrsTC5FniYuRBOK8(u"࠲࠶Ꮲ")*RFi2SjVJsh6xkmID9HwTBzYCdXE.encode(m6PFtLblInpNZ8x)).hexdigest()
			RFi2SjVJsh6xkmID9HwTBzYCdXE = TOjyaHnYozURG.md5(ilBWK5nXxg1do4jENGC07Zq(u"࠳࠼Ꮳ")*RFi2SjVJsh6xkmID9HwTBzYCdXE.encode(m6PFtLblInpNZ8x)).hexdigest()
			MoO74hKeqm8fFka.setSetting(S8i3sBYoHWdTURpAgN(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠸ࠧ၂"),RFi2SjVJsh6xkmID9HwTBzYCdXE)
	if showDialogs:
		if kBDhXd3JHw9nVpE0g8 in [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ၃"),wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ၄")]:
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ၅"),f90fGrlSEObDsuiA3U(u"ࠨ้้ห่ࠦๅีๅ็อࠥ็๊ࠡฮ๊หื้้้ࠠํࠤ้๐ำห่๊ࠢࠥอไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆุ่่๊ษࠡไาࠤ๏้่็ࠢึฬอํวࠡษ็ษ๋ะั็ฬࠣห้ิวึࠢห็ࠥษ่ࠡษ็ีฬ๎สาࠢส่ำอีࠡสๆࠤศ๎ࠠๆึๆ่ฮࠦแ๋ࠢส่ศูไศๅࠣ฽๋ีใࠨ၆"))
		else:
			YTUtDCvHs6eQEPi1FJ(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡵ࡭࡬࡮ࡴࠨ၇"),XugxFprC26zGM(u"ࠪีุอฦๅ่๊ࠢࠥอไๆสิ้ัࠦลๅุ๋้ࠣะฮะ็ํࠤฬ๊ศา่ส้ั࠭၈"),c0pWzdJoL6Ss3b,bP01xn84BiQN(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬ၉"))
			kBDhXd3JHw9nVpE0g8 = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡕࡌࡅࠩ၊")
	if kBDhXd3JHw9nVpE0g8!=it48RVP61xTNFmnD:
		MoO74hKeqm8fFka.setSetting(KW5bYS20wTF1LyCs9(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ။"),kBDhXd3JHw9nVpE0g8)
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	naWCmJDgf7jN5F2GvS4s3OIUt = YchIv6N09BaWPEj4tieAnluKZrRXT if r6eWEITzJptGYLD!=hExiXtnp6emUHOf5yaC1sk7uY else rDceXBpHkfVUYRJ3tIx95Z
	if naWCmJDgf7jN5F2GvS4s3OIUt:
		global ePJWDdHsX8Tokv31yL,wwNbXe9taWdRiFHzyB2MZ,ot06iq3huYHVAfBszvP1FjG,EDNRGMfBk3H2FAtQI578ubU6cXw0hn
		ePJWDdHsX8Tokv31yL,wwNbXe9taWdRiFHzyB2MZ,ot06iq3huYHVAfBszvP1FjG,EDNRGMfBk3H2FAtQI578ubU6cXw0hn = BoGNtDIVHAyw([w2vjZmdJuY7c(u"ࠧࡄࡖࡈ࠽ࡉ࡙࠱࠺ࡘࡘ࠴࡛࡙ࡘࠨ၌"),ilBWK5nXxg1do4jENGC07Zq(u"ࠨ࡙ࡖ࡙ࡗࡌࡔ࠲࠻ࡔࡘࡊࡌ࡚࡙ࠩ၍"),f90fGrlSEObDsuiA3U(u"ࠩࡅࡘࡊࡾࡐࡗ࠳࠼࡙ࡗ࡜ࡎࡖࡕࡘ࠹ࡍ࡞ࠧ၎"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡓ࡙࠷࠹ࡋࡗ࠳ࡼࡇ࡚ࡕ࡭ࡆ࡛ࠫ၏")])
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def vd3T7NboyCKmIhSZLAukRGn8Et(RgkzMx9Fc3ZtUJmrG1pqIEf,ssihyIe9fm8vVzSLpMc):
	from socket import socket as d8ERXc2O9NADu,AF_INET as H28fb4Yg1GA3,SOCK_STREAM as UcrOzDRH470eTvC6dKF5mAf9PV
	Y8Ytw7g42Tl1NB5is9fnJL = d8ERXc2O9NADu(H28fb4Yg1GA3,UcrOzDRH470eTvC6dKF5mAf9PV)
	Y8Ytw7g42Tl1NB5is9fnJL.settimeout(NSudqlOzja)
	dlu49cgYnN7fW2OaKzJsiSX8Qw,sXcYICky8REVhbH = YchIv6N09BaWPEj4tieAnluKZrRXT,x1Oa8bBf36EwsLMirtFc
	B0ZiepTkgjAq8lWxCKyX1 = b8bLFaejUB.time()
	try: Y8Ytw7g42Tl1NB5is9fnJL.connect((RgkzMx9Fc3ZtUJmrG1pqIEf,ssihyIe9fm8vVzSLpMc))
	except: dlu49cgYnN7fW2OaKzJsiSX8Qw = rDceXBpHkfVUYRJ3tIx95Z
	ihnG1xOrTuDwRmQKVMAkb3ELZq = b8bLFaejUB.time()
	if dlu49cgYnN7fW2OaKzJsiSX8Qw: sXcYICky8REVhbH = ihnG1xOrTuDwRmQKVMAkb3ELZq-B0ZiepTkgjAq8lWxCKyX1
	return sXcYICky8REVhbH
def wJ0l2uCDMF8IiEzsvykhP(showDialogs):
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧၐ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫၑ"))
	else: zf7iFX1auw0bQU = YchIv6N09BaWPEj4tieAnluKZrRXT
	if zf7iFX1auw0bQU==NSudqlOzja:
		for dyablPViz25TGKJ in RRydns1CErYlIhwSx7.listdir(oX9h2wrQe5):
			if dyablPViz25TGKJ.endswith(CKUiyEe28zsZ(u"࠭࠮ࡥࡤࠪၒ")) and ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡥࡣࡷࡥࠬၓ") in dyablPViz25TGKJ:
				zHOEFk27fChwMr0GKXWSy19URm4 = RRydns1CErYlIhwSx7.path.join(oX9h2wrQe5,dyablPViz25TGKJ)
				try: Mh2SmYKyRLsevXCJpTajHZbi0Gf,O4OfQzkx1KmeIHrjT97E0byA = EnU1P9x4k7DF6ie5TWAKChB0mSzrN(zHOEFk27fChwMr0GKXWSy19URm4)
				except: return
				O4OfQzkx1KmeIHrjT97E0byA.execute(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫၔ"))
				O4OfQzkx1KmeIHrjT97E0byA.execute(KW5bYS20wTF1LyCs9(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧၕ"))
				O4OfQzkx1KmeIHrjT97E0byA.execute(ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭ࡳࡺࡥࡨࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࡀ࠭ၖ"))
				O4OfQzkx1KmeIHrjT97E0byA.execute(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡴࡶࡴࡪ࡯࡬ࡾࡪࡁࠧၗ"))
				O4OfQzkx1KmeIHrjT97E0byA.execute(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ၘ"))
				Mh2SmYKyRLsevXCJpTajHZbi0Gf.commit()
				Mh2SmYKyRLsevXCJpTajHZbi0Gf.close()
		if showDialogs: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩၙ"),bP01xn84BiQN(u"ࠧห็อࠤอ์ฬศฯࠣ฽๊๊๊สࠢศู้ออ๊ࠡอ๊฽๐แࠡฮ่๎฾ࠦโ้ษ฼ำࠥอไษ์ส๊ฬะ้ࠠษ็็ฬฺࠠศๆ่ืฯิฯๆหࠣๅ๏ࠦวๅสิ๊ฬ๋ฬࠨၚ"))
	return
def Rpfbit9Qjk4zYoMu0q(LPNrAuKqbv,fuq8Rvb2Ne1oagk3EXcdm0CnQi,showDialogs):
	if LPNrAuKqbv!=None:
		global DrA6vCjKTVhS2Qc
		DrA6vCjKTVhS2Qc = LPNrAuKqbv
	if fuq8Rvb2Ne1oagk3EXcdm0CnQi!=None:
		global idcNRIJPWfTElku4yx3A2
		idcNRIJPWfTElku4yx3A2 = fuq8Rvb2Ne1oagk3EXcdm0CnQi
	if showDialogs!=None:
		global Waw4OEoBpYT0xMqX8dyiCV
		Waw4OEoBpYT0xMqX8dyiCV = showDialogs
	return
def goiGJ6Qua8VT0HLeqtAhzw(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,data,headers,allow_redirects,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s,nLNrPvpjiES2hJ):
	if showDialogs==eHdDoxhJCEPMZFVa2fg: jlqny86ozgIiXuaexRrJK23LSk = YchIv6N09BaWPEj4tieAnluKZrRXT if Waw4OEoBpYT0xMqX8dyiCV==eHdDoxhJCEPMZFVa2fg else Waw4OEoBpYT0xMqX8dyiCV
	else: jlqny86ozgIiXuaexRrJK23LSk = YchIv6N09BaWPEj4tieAnluKZrRXT if showDialogs else rDceXBpHkfVUYRJ3tIx95Z
	if nLNrPvpjiES2hJ==eHdDoxhJCEPMZFVa2fg: ppxEXy6I3Fr9 = YchIv6N09BaWPEj4tieAnluKZrRXT if idcNRIJPWfTElku4yx3A2==eHdDoxhJCEPMZFVa2fg else idcNRIJPWfTElku4yx3A2
	else: ppxEXy6I3Fr9 = YchIv6N09BaWPEj4tieAnluKZrRXT if nLNrPvpjiES2hJ else rDceXBpHkfVUYRJ3tIx95Z
	if ra8qpfiOm4xhQJZ96evUctL1s==eHdDoxhJCEPMZFVa2fg: A1KWRPGNsTqkLlu7oODg26zhYtvMx = YchIv6N09BaWPEj4tieAnluKZrRXT if DrA6vCjKTVhS2Qc==eHdDoxhJCEPMZFVa2fg else DrA6vCjKTVhS2Qc
	else: A1KWRPGNsTqkLlu7oODg26zhYtvMx = YchIv6N09BaWPEj4tieAnluKZrRXT if ra8qpfiOm4xhQJZ96evUctL1s else rDceXBpHkfVUYRJ3tIx95Z
	if allow_redirects==eHdDoxhJCEPMZFVa2fg: u1ek4lEhrINBALc2xa = YchIv6N09BaWPEj4tieAnluKZrRXT
	else: u1ek4lEhrINBALc2xa = YchIv6N09BaWPEj4tieAnluKZrRXT if allow_redirects else rDceXBpHkfVUYRJ3tIx95Z
	W9PzsMeLJTc83mS45G17n = {} if headers==eHdDoxhJCEPMZFVa2fg else headers
	LbAmEhrdt7eRV2Y = {} if data==eHdDoxhJCEPMZFVa2fg else data
	SSngP2KAZJvWbwefMFIYqhjEl0m = list(W9PzsMeLJTc83mS45G17n.keys())
	if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩၛ") not in SSngP2KAZJvWbwefMFIYqhjEl0m: W9PzsMeLJTc83mS45G17n[ietolwsjpIPK7Fr(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪၜ")] = RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪ࡬ࡹࡺࡰࠨၝ")
	if eNEhtuoi9gK8JaTpIXj(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨၞ") not in SSngP2KAZJvWbwefMFIYqhjEl0m: W9PzsMeLJTc83mS45G17n[egY8Jti0smdLM3h1VQRSW(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩၟ")] = qq62QA8h3pGxzCwWVeXIF7glKf(YchIv6N09BaWPEj4tieAnluKZrRXT)
	return tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,A1KWRPGNsTqkLlu7oODg26zhYtvMx,ppxEXy6I3Fr9
def aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s=eHdDoxhJCEPMZFVa2fg,nLNrPvpjiES2hJ=eHdDoxhJCEPMZFVa2fg):
	Cnb6hvgaBtGw8yuJd0xW9A = goiGJ6Qua8VT0HLeqtAhzw(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s,nLNrPvpjiES2hJ)
	tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,A1KWRPGNsTqkLlu7oODg26zhYtvMx,ppxEXy6I3Fr9 = Cnb6hvgaBtGw8yuJd0xW9A
	E1Viom5L3684CTOFJ,O3m8areAPTfgLbXts,GGyD8Bnmuv49whkr5FzQ3qJIZxoesp,fntdCl29AwQROPKvj = dfqLZkHznMvtIoBpFaQx6Nb(FeTJrG4SkMf09iVys8A)
	uJinrVBe7MAY3 = MoO74hKeqm8fFka.getSetting(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭ၠ"))
	UbNnVwsHjAoSYQ = MoO74hKeqm8fFka.getSetting(NxXMrsTC5FniYuRBOK8(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪၡ"))
	fDRjs72vQu5O9ThqLKkB = MoO74hKeqm8fFka.getSetting(EX25Y0l8ILvz7QcRC(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ၢ"))
	YYmjwBsRS4MaDQkTKxWpLlhNec1 = [wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬၣ"),f90fGrlSEObDsuiA3U(u"ࠪࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯ࠧၤ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩၥ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬၦ"),NxXMrsTC5FniYuRBOK8(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨၧ"),f90fGrlSEObDsuiA3U(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱࠪၨ")]
	RucYSIXzNZPtfkgU7jxH = YchIv6N09BaWPEj4tieAnluKZrRXT if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in FeTJrG4SkMf09iVys8A for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in YYmjwBsRS4MaDQkTKxWpLlhNec1) else rDceXBpHkfVUYRJ3tIx95Z
	if LyOR7f69iA(u"ࠨࠨࡸࡶࡱࡃࠧၩ") in E1Viom5L3684CTOFJ and RucYSIXzNZPtfkgU7jxH: DGYSRVesiW0hIB6FrM = E1Viom5L3684CTOFJ.rsplit(t3coAp06zvHrTl49bUVgx(u"ࠩࠩࡹࡷࡲ࠽ࠨၪ"),S8i3sBYoHWdTURpAgN(u"࠴Ꮴ"))[NSudqlOzja]
	else: DGYSRVesiW0hIB6FrM = eHdDoxhJCEPMZFVa2fg
	d36FYWURmNy7sBLp9kCPV4MTGfnHjA = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[t3coAp06zvHrTl49bUVgx(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪၫ")]
	SpgAebMzBKw6uo4Gs1dOFRhilr5H = E1Viom5L3684CTOFJ in d36FYWURmNy7sBLp9kCPV4MTGfnHjA or DGYSRVesiW0hIB6FrM in d36FYWURmNy7sBLp9kCPV4MTGfnHjA
	uV3dv8GmW4csoHlCar5wpAgTN = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[I5bUBGpPXn0W6(u"ࠫࡗࡋࡐࡐࡕࠪၬ")]
	ViMgKt3soG = E1Viom5L3684CTOFJ in uV3dv8GmW4csoHlCar5wpAgTN or DGYSRVesiW0hIB6FrM in uV3dv8GmW4csoHlCar5wpAgTN
	ojqpuJ0adf = SpgAebMzBKw6uo4Gs1dOFRhilr5H or ViMgKt3soG
	XxKBmM4ChyP5 = rDceXBpHkfVUYRJ3tIx95Z
	lFT6fjM5dor8aRhzm3 = YchIv6N09BaWPEj4tieAnluKZrRXT
	ljQMzGmd94A1L67bv = O3m8areAPTfgLbXts==None and GGyD8Bnmuv49whkr5FzQ3qJIZxoesp==None and not RucYSIXzNZPtfkgU7jxH
	if ljQMzGmd94A1L67bv and ojqpuJ0adf:
		if SpgAebMzBKw6uo4Gs1dOFRhilr5H:
			lIBROt80rD6hpjaVqygsdZJLWT = d36FYWURmNy7sBLp9kCPV4MTGfnHjA.index(E1Viom5L3684CTOFJ)
			oLtZ5MG7bl = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[CKUiyEe28zsZ(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩၭ")][lIBROt80rD6hpjaVqygsdZJLWT]
			RLepADMmoBQqVnlT5t = jf6T7xMX5EFuz1Do8OhVpByYak[lIBROt80rD6hpjaVqygsdZJLWT]
			if RLepADMmoBQqVnlT5t==bP01xn84BiQN(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨၮ"): A1KWRPGNsTqkLlu7oODg26zhYtvMx,ppxEXy6I3Fr9,lFT6fjM5dor8aRhzm3 = rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z
			elif RLepADMmoBQqVnlT5t==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨၯ"): XxKBmM4ChyP5 = YchIv6N09BaWPEj4tieAnluKZrRXT
		elif ViMgKt3soG:
			lIBROt80rD6hpjaVqygsdZJLWT = uV3dv8GmW4csoHlCar5wpAgTN.index(E1Viom5L3684CTOFJ)
			oLtZ5MG7bl = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫၰ")][lIBROt80rD6hpjaVqygsdZJLWT]
			RLepADMmoBQqVnlT5t = qKxXzgTdEs3ImAyrNu2DZviRW0[lIBROt80rD6hpjaVqygsdZJLWT]
	if GGyD8Bnmuv49whkr5FzQ3qJIZxoesp==eHdDoxhJCEPMZFVa2fg: GGyD8Bnmuv49whkr5FzQ3qJIZxoesp = uJinrVBe7MAY3
	elif GGyD8Bnmuv49whkr5FzQ3qJIZxoesp==None and UbNnVwsHjAoSYQ in [LTN6DPEmrwehtZMy(u"ࠩࡄ࡙࡙ࡕࠧၱ"),eNEhtuoi9gK8JaTpIXj(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬၲ")] and A1KWRPGNsTqkLlu7oODg26zhYtvMx: GGyD8Bnmuv49whkr5FzQ3qJIZxoesp = uJinrVBe7MAY3
	if SpgAebMzBKw6uo4Gs1dOFRhilr5H or ViMgKt3soG: MbacDJogKp5ElfIi = LTN6DPEmrwehtZMy(u"࠵࠺Ꮵ")
	elif RucYSIXzNZPtfkgU7jxH: MbacDJogKp5ElfIi = eNEhtuoi9gK8JaTpIXj(u"࠻࠶Ꮶ")
	elif Oyg3pZGAHdws7RWm4e6S in IuLpt4BK7yjad0vMW63Ql: MbacDJogKp5ElfIi = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷࠰Ꮷ")
	elif Oyg3pZGAHdws7RWm4e6S==NxXMrsTC5FniYuRBOK8(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ၳ"): MbacDJogKp5ElfIi = egY8Jti0smdLM3h1VQRSW(u"࠲࠱Ꮸ")
	elif Oyg3pZGAHdws7RWm4e6S==ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ၴ"): MbacDJogKp5ElfIi = egY8Jti0smdLM3h1VQRSW(u"࠳࠲Ꮹ")
	elif XugxFprC26zGM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍࠨၵ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = CKUiyEe28zsZ(u"࠹࠳Ꮺ")
	elif HkiMU0QrdzW3l6gwnT(u"ࠧࡔࡊࡒࡊࡍࡇࠧၶ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺࠹Ꮻ")
	elif egY8Jti0smdLM3h1VQRSW(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨၷ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = NxXMrsTC5FniYuRBOK8(u"࠶࠺Ꮼ")
	elif egY8Jti0smdLM3h1VQRSW(u"ࠩࡄࡌ࡜ࡇࡋࠨၸ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = wY1p9mP03S8drbcH64t5WQkv(u"࠷࠶Ꮽ")
	elif KQ3sCe9Pzh(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ၹ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = t3coAp06zvHrTl49bUVgx(u"࠸࠰Ꮾ")
	elif Cp6c5tZe8I0PxnAW(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪၺ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳࠱Ꮿ")
	elif ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡇࡋࡐࡃࡐࠫၻ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = S8i3sBYoHWdTURpAgN(u"࠳࠷Ᏸ")
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡁࡌ࡙ࡄࡑࠬၼ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = KQ3sCe9Pzh(u"࠵࠳Ᏹ")
	elif t3coAp06zvHrTl49bUVgx(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩၽ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = eNEhtuoi9gK8JaTpIXj(u"࠵࠴Ᏺ")
	elif S8i3sBYoHWdTURpAgN(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪၾ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠺࠵Ᏻ")
	elif ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫၿ") in Oyg3pZGAHdws7RWm4e6S: MbacDJogKp5ElfIi = w2vjZmdJuY7c(u"࠹࠶Ᏼ")
	else: MbacDJogKp5ElfIi = eNEhtuoi9gK8JaTpIXj(u"࠷࠵Ᏽ")
	PStAHbdhMca7IgB3 = (O3m8areAPTfgLbXts!=None)
	nLTUPIuqV03Qw7Fhy = (GGyD8Bnmuv49whkr5FzQ3qJIZxoesp!=None and UbNnVwsHjAoSYQ!=ietolwsjpIPK7Fr(u"ࠪࡗ࡙ࡕࡐࠨႀ"))
	if PStAHbdhMca7IgB3 and not RucYSIXzNZPtfkgU7jxH: dqKGMYgJxSF8Ub1kotlsP936Ww7B(jUcmHhgVvW0EdYOIfXeaDF(u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧႁ"),O3m8areAPTfgLbXts)
	elif nLTUPIuqV03Qw7Fhy: dqKGMYgJxSF8Ub1kotlsP936Ww7B(KQ3sCe9Pzh(u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬႂ"),GGyD8Bnmuv49whkr5FzQ3qJIZxoesp)
	if PStAHbdhMca7IgB3:
		q6vKWbwG7xps = {Cp6c5tZe8I0PxnAW(u"ࠨࡨࡵࡶࡳࠦႃ"):O3m8areAPTfgLbXts,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠢࡩࡶࡷࡴࡸࠨႄ"):O3m8areAPTfgLbXts}
		n7Khb9DMwTju3to0Xye = O3m8areAPTfgLbXts
	else: q6vKWbwG7xps,n7Khb9DMwTju3to0Xye = {},eHdDoxhJCEPMZFVa2fg
	if nLTUPIuqV03Qw7Fhy:
		import urllib3.util.connection as RybZs8Phmu5S2To
		R7aojIruSQvgLMdqHBx43 = FR0Qkbq3GE(RybZs8Phmu5S2To,uJinrVBe7MAY3)
	XklY8WvxLTZ1HafcQq,wGp3f1bmBdPS5icYFqDNZxj2UEzoM,Rp6j2ZoUKzOitrQDca5JIgbS4TEw,im6gBOAhFD41zdbPp79Kaqo,mD8LOK4rXAEFa,verify = u1ek4lEhrINBALc2xa,Oyg3pZGAHdws7RWm4e6S,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z,fntdCl29AwQROPKvj
	if XxKBmM4ChyP5: mD8LOK4rXAEFa = YchIv6N09BaWPEj4tieAnluKZrRXT
	if ojqpuJ0adf or u1ek4lEhrINBALc2xa: XklY8WvxLTZ1HafcQq = rDceXBpHkfVUYRJ3tIx95Z
	if SpgAebMzBKw6uo4Gs1dOFRhilr5H: Rp6j2ZoUKzOitrQDca5JIgbS4TEw = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡒࡒࡗ࡙࠭ႅ")
	O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6 = -NSudqlOzja,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡉࡷࡸ࡯ࡳࠩႆ")
	BB8rsaiMVxXlSRcv6JfFQ7Cyhje = rDceXBpHkfVUYRJ3tIx95Z
	global gcBtx3HrPuOK5sf
	if not gcBtx3HrPuOK5sf: gcBtx3HrPuOK5sf = EeZHTwQUW2BuvJyIh(pyifuNFdxe,Cp6c5tZe8I0PxnAW(u"ࠪࡨ࡮ࡩࡴࠨႇ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧႈ"),NxXMrsTC5FniYuRBOK8(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧႉ"))
	a6hVgir2wld0xtv5BsqXf7T9nKQHj = []
	while E1Viom5L3684CTOFJ not in a6hVgir2wld0xtv5BsqXf7T9nKQHj and E1Viom5L3684CTOFJ in list(gcBtx3HrPuOK5sf.keys()):
		a6hVgir2wld0xtv5BsqXf7T9nKQHj.append(E1Viom5L3684CTOFJ)
		E1Viom5L3684CTOFJ = gcBtx3HrPuOK5sf[E1Viom5L3684CTOFJ]
	import requests as sOGcCTIoQ85ARH6
	for gMmB3iopS0ZXrOFewhcxt in range(ilBWK5nXxg1do4jENGC07Zq(u"࠹᏶")):
		P8hKnieVvlHOypNYaAwmBWTU = YchIv6N09BaWPEj4tieAnluKZrRXT
		gZdOM2jYEfV = rDceXBpHkfVUYRJ3tIx95Z
		try:
			if gMmB3iopS0ZXrOFewhcxt: wGp3f1bmBdPS5icYFqDNZxj2UEzoM = RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠵ࡸࡺࠧႊ")
			if RucYSIXzNZPtfkgU7jxH or not PStAHbdhMca7IgB3: NEI8AGXDS73KmBvT54o6L(wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࡞ࡷࡓࡕࡋࡎࡠࡗࡕࡐࠬႋ"),E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,wGp3f1bmBdPS5icYFqDNZxj2UEzoM,Rp6j2ZoUKzOitrQDca5JIgbS4TEw)
			try: qldY3LPe0pDiuyoM8vIH.close()
			except: pass
			ajHR9ABQl2buvm = E1Viom5L3684CTOFJ
			qldY3LPe0pDiuyoM8vIH = sOGcCTIoQ85ARH6.request(Rp6j2ZoUKzOitrQDca5JIgbS4TEw,E1Viom5L3684CTOFJ,data=LbAmEhrdt7eRV2Y,headers=W9PzsMeLJTc83mS45G17n,verify=verify,allow_redirects=XklY8WvxLTZ1HafcQq,timeout=MbacDJogKp5ElfIi,proxies=q6vKWbwG7xps)
			if iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴࠲࠳᏷")<=qldY3LPe0pDiuyoM8vIH.status_code<=LTN6DPEmrwehtZMy(u"࠵࠼࠽ᏸ"):
				if not im6gBOAhFD41zdbPp79Kaqo:
					XEugvUfKmRN = list(qldY3LPe0pDiuyoM8vIH.headers.keys())
					if ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪႌ") in XEugvUfKmRN: E1Viom5L3684CTOFJ = qldY3LPe0pDiuyoM8vIH.headers[w2vjZmdJuY7c(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱႍࠫ")]
					elif RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬႎ") in XEugvUfKmRN: E1Viom5L3684CTOFJ = qldY3LPe0pDiuyoM8vIH.headers[ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ႏ")]
					else: im6gBOAhFD41zdbPp79Kaqo = YchIv6N09BaWPEj4tieAnluKZrRXT
					if not im6gBOAhFD41zdbPp79Kaqo: E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.encode(egY8Jti0smdLM3h1VQRSW(u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭႐"),KQ3sCe9Pzh(u"࠭ࡩࡨࡰࡲࡶࡪ࠭႑")).decode(m6PFtLblInpNZ8x,ietolwsjpIPK7Fr(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ႒"))
					if ojqpuJ0adf and qldY3LPe0pDiuyoM8vIH.status_code==ietolwsjpIPK7Fr(u"࠶࠴࠼ᏹ"):
						XklY8WvxLTZ1HafcQq = u1ek4lEhrINBALc2xa
						Rp6j2ZoUKzOitrQDca5JIgbS4TEw = tWILFaVZ5E6rdoRXNGApOiJ3Ss0
						im6gBOAhFD41zdbPp79Kaqo = YchIv6N09BaWPEj4tieAnluKZrRXT
						Zt9uJzyFPXBKaHljAcnUwxE
				if not im6gBOAhFD41zdbPp79Kaqo or u1ek4lEhrINBALc2xa:
					if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡪࡷࡸࡵ࠭႓") not in E1Viom5L3684CTOFJ:
						n6DL1XJTHQbi0ctSZksurjo5zOg = b31wAB8mhaz2rXHoJFlfvDugtsOj(ajHR9ABQl2buvm,ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡸࡶࡱ࠭႔"))
						E1Viom5L3684CTOFJ = n6DL1XJTHQbi0ctSZksurjo5zOg+egY8Jti0smdLM3h1VQRSW(u"ࠪ࠳ࠬ႕")+E1Viom5L3684CTOFJ.lstrip(KW5bYS20wTF1LyCs9(u"ࠫ࠴࠭႖"))
				if E1Viom5L3684CTOFJ!=ajHR9ABQl2buvm:
					gcBtx3HrPuOK5sf[ajHR9ABQl2buvm] = E1Viom5L3684CTOFJ
					BB8rsaiMVxXlSRcv6JfFQ7Cyhje = YchIv6N09BaWPEj4tieAnluKZrRXT
				if not im6gBOAhFD41zdbPp79Kaqo and u1ek4lEhrINBALc2xa and not llr1C3SIFjViqLDtZP(E1Viom5L3684CTOFJ): Zt9uJzyFPXBKaHljAcnUwxE
			elif LTN6DPEmrwehtZMy(u"࠺࠻࠰ᏻ")<=qldY3LPe0pDiuyoM8vIH.status_code<=J7divaGOCgq2SLfXpDzZYN58wc(u"࠹࠾࠿ᏺ"):
				qldY3LPe0pDiuyoM8vIH.reason = qldY3LPe0pDiuyoM8vIH.content
				mD8LOK4rXAEFa = YchIv6N09BaWPEj4tieAnluKZrRXT
			ajHR9ABQl2buvm = qldY3LPe0pDiuyoM8vIH.url
			O1WFus64LiEAmzpnPIT8jgZHN = qldY3LPe0pDiuyoM8vIH.status_code
			RCrFOws8DlH6 = qldY3LPe0pDiuyoM8vIH.reason
			qldY3LPe0pDiuyoM8vIH.raise_for_status()
			gZdOM2jYEfV = YchIv6N09BaWPEj4tieAnluKZrRXT
		except sOGcCTIoQ85ARH6.exceptions.HTTPError as IsHj3gPMl06:
			pass
		except sOGcCTIoQ85ARH6.exceptions.Timeout as IsHj3gPMl06:
			if lHfbysRrUV7m4CLSdkxc382n: RCrFOws8DlH6 = str(IsHj3gPMl06.message).split(CKUiyEe28zsZ(u"ࠬࡀࠠࠨ႗"))[NSudqlOzja]
			else: RCrFOws8DlH6 = str(IsHj3gPMl06).split(wY1p9mP03S8drbcH64t5WQkv(u"࠭࠺ࠡࠩ႘"))[NSudqlOzja]
		except sOGcCTIoQ85ARH6.exceptions.ConnectionError as IsHj3gPMl06:
			try: ACbjkvGL7Udh4RuToXPmeFVy = IsHj3gPMl06.message[x1Oa8bBf36EwsLMirtFc]
			except: ACbjkvGL7Udh4RuToXPmeFVy = str(IsHj3gPMl06)
			NWeJmPkp7ngR5MDsl62QoVqu0ZrT = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤ႙"),ACbjkvGL7Udh4RuToXPmeFVy)
			if not NWeJmPkp7ngR5MDsl62QoVqu0ZrT: NWeJmPkp7ngR5MDsl62QoVqu0ZrT = cBawilJXvK1m.findall(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠣ࠮ࠣࡩࡷࡸ࡯ࡳ࡞ࠫࠬࡡࡪࠫࠪ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦႚ"),ACbjkvGL7Udh4RuToXPmeFVy)
			if not NWeJmPkp7ngR5MDsl62QoVqu0ZrT:
				ljy8t6cIxpPJrKaHMZ3gQiASY = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠤ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠿ࠨႛ"),ACbjkvGL7Udh4RuToXPmeFVy)
				if ljy8t6cIxpPJrKaHMZ3gQiASY: NWeJmPkp7ngR5MDsl62QoVqu0ZrT = [ljy8t6cIxpPJrKaHMZ3gQiASY[x1Oa8bBf36EwsLMirtFc][NSudqlOzja],ljy8t6cIxpPJrKaHMZ3gQiASY[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc]]
			if not NWeJmPkp7ngR5MDsl62QoVqu0ZrT: NWeJmPkp7ngR5MDsl62QoVqu0ZrT = cBawilJXvK1m.findall(egY8Jti0smdLM3h1VQRSW(u"ࠥ࠾࠭ࡢࡤࠬࠫ࠽ࠤ࠭࠴ࠪࡀࠫࠪࠦႜ"),ACbjkvGL7Udh4RuToXPmeFVy)
			if not NWeJmPkp7ngR5MDsl62QoVqu0ZrT: NWeJmPkp7ngR5MDsl62QoVqu0ZrT = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠦࠥ࠮࡜ࡥ࠭ࠬࡡࠥ࠮࠮ࠫࡁࠬࠫࠧႝ"),ACbjkvGL7Udh4RuToXPmeFVy)
			try: O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6 = NWeJmPkp7ngR5MDsl62QoVqu0ZrT[x1Oa8bBf36EwsLMirtFc]
			except: O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6 = -GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠸ᏼ"),ACbjkvGL7Udh4RuToXPmeFVy
		except sOGcCTIoQ85ARH6.exceptions.RequestException as IsHj3gPMl06:
			if lHfbysRrUV7m4CLSdkxc382n: RCrFOws8DlH6 = IsHj3gPMl06.message
			else: RCrFOws8DlH6 = str(IsHj3gPMl06)
		except:
			P8hKnieVvlHOypNYaAwmBWTU = rDceXBpHkfVUYRJ3tIx95Z
			try: O1WFus64LiEAmzpnPIT8jgZHN = qldY3LPe0pDiuyoM8vIH.status_code
			except: pass
			try: RCrFOws8DlH6 = qldY3LPe0pDiuyoM8vIH.reason
			except: pass
		RCrFOws8DlH6 = str(RCrFOws8DlH6)
		vR9cOpMtk51j(iwIlVQsgYezu,w2vjZmdJuY7c(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࡝ࡶࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ႞")+str(O1WFus64LiEAmzpnPIT8jgZHN)+S8i3sBYoHWdTURpAgN(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ႟")+RCrFOws8DlH6+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩႠ")+Oyg3pZGAHdws7RWm4e6S+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧႡ")+FeTJrG4SkMf09iVys8A+LyOR7f69iA(u"ࠩࠣࡡࠬႢ"))
		if ljQMzGmd94A1L67bv and ojqpuJ0adf and P8hKnieVvlHOypNYaAwmBWTU and not mD8LOK4rXAEFa and O1WFus64LiEAmzpnPIT8jgZHN!=NxXMrsTC5FniYuRBOK8(u"࠲࠱࠲ᏽ"):
			E1Viom5L3684CTOFJ = oLtZ5MG7bl
			mD8LOK4rXAEFa = YchIv6N09BaWPEj4tieAnluKZrRXT
			continue
		if P8hKnieVvlHOypNYaAwmBWTU: break
	if not gZdOM2jYEfV and a6hVgir2wld0xtv5BsqXf7T9nKQHj:
		for url in a6hVgir2wld0xtv5BsqXf7T9nKQHj: del gcBtx3HrPuOK5sf[url]
		BB8rsaiMVxXlSRcv6JfFQ7Cyhje = YchIv6N09BaWPEj4tieAnluKZrRXT
	if BB8rsaiMVxXlSRcv6JfFQ7Cyhje:
		CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,CKUiyEe28zsZ(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭Ⴃ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡋࡕࡒࡘࡃࡕࡈࡘ࠭Ⴄ"),gcBtx3HrPuOK5sf,ICRfWub2vqlor0Q)
		gcBtx3HrPuOK5sf = {}
	if GGyD8Bnmuv49whkr5FzQ3qJIZxoesp!=None and UbNnVwsHjAoSYQ!=wY1p9mP03S8drbcH64t5WQkv(u"࡙ࠬࡔࡐࡒࠪႥ"): RybZs8Phmu5S2To.create_connection = R7aojIruSQvgLMdqHBx43
	if UbNnVwsHjAoSYQ==NxXMrsTC5FniYuRBOK8(u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭Ⴆ") and A1KWRPGNsTqkLlu7oODg26zhYtvMx: GGyD8Bnmuv49whkr5FzQ3qJIZxoesp = None
	if not gZdOM2jYEfV and O3m8areAPTfgLbXts==None and Oyg3pZGAHdws7RWm4e6S not in IuLpt4BK7yjad0vMW63Ql:
		pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
		if pw9fgsSRmnKId80YbU1PA!=HkiMU0QrdzW3l6gwnT(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪႧ"): jjO4Xf7GBW8Dx2HR0tdP.stderr.write(pw9fgsSRmnKId80YbU1PA)
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = maQf4xXLtV2()
	if RucYSIXzNZPtfkgU7jxH: ajHR9ABQl2buvm = DGYSRVesiW0hIB6FrM
	if not ajHR9ABQl2buvm: ajHR9ABQl2buvm = E1Viom5L3684CTOFJ
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.url = ajHR9ABQl2buvm
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.scrape = RucYSIXzNZPtfkgU7jxH
	try: tMjw4TgPuofOsKh6FIzHmJ = qldY3LPe0pDiuyoM8vIH.content
	except: tMjw4TgPuofOsKh6FIzHmJ = eHdDoxhJCEPMZFVa2fg
	try: W4S9yzhJlXj3 = qldY3LPe0pDiuyoM8vIH.headers
	except: W4S9yzhJlXj3 = {}
	try: uKmp4gQ8YbH9SlIGdy2Miw7O = qldY3LPe0pDiuyoM8vIH.cookies.get_dict()
	except: uKmp4gQ8YbH9SlIGdy2Miw7O = {}
	try: qldY3LPe0pDiuyoM8vIH.close()
	except: pass
	if WHjh1POtMKlmgiy68RSqb:
		try: tMjw4TgPuofOsKh6FIzHmJ = tMjw4TgPuofOsKh6FIzHmJ.decode(m6PFtLblInpNZ8x)
		except: pass
	O1WFus64LiEAmzpnPIT8jgZHN = int(O1WFus64LiEAmzpnPIT8jgZHN)
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.code = O1WFus64LiEAmzpnPIT8jgZHN
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.reason = RCrFOws8DlH6
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.content = tMjw4TgPuofOsKh6FIzHmJ
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.headers = W4S9yzhJlXj3
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.cookies = uKmp4gQ8YbH9SlIGdy2Miw7O
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded = gZdOM2jYEfV
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.scrapernumber = eHdDoxhJCEPMZFVa2fg
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.scraperserver = eHdDoxhJCEPMZFVa2fg
	NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.scraperurl = eHdDoxhJCEPMZFVa2fg
	if lHfbysRrUV7m4CLSdkxc382n or isinstance(NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.content,str): THOD2Nwp0Mdbyzni7geojAChQ = NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.content.lower()
	else: THOD2Nwp0Mdbyzni7geojAChQ = eHdDoxhJCEPMZFVa2fg
	ZEihvxcN7XBjIrT4YytVmFgP1 = (KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬႨ") in THOD2Nwp0Mdbyzni7geojAChQ or S8i3sBYoHWdTURpAgN(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩႩ") in THOD2Nwp0Mdbyzni7geojAChQ) and THOD2Nwp0Mdbyzni7geojAChQ.count(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭Ⴊ"))>KQ3sCe9Pzh(u"࠳᏾") and J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭Ⴋ") not in Oyg3pZGAHdws7RWm4e6S and RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴࠧႬ") not in THOD2Nwp0Mdbyzni7geojAChQ and not RucYSIXzNZPtfkgU7jxH
	if O1WFus64LiEAmzpnPIT8jgZHN==RqLvTrID0yMVeClpYcnZ16i3X(u"࠴࠳࠴᏿") and ZEihvxcN7XBjIrT4YytVmFgP1: NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded = rDceXBpHkfVUYRJ3tIx95Z
	if NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded and ljQMzGmd94A1L67bv and ojqpuJ0adf:
		X9XxmHBLWPz = ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧႭ")+LbAmEhrdt7eRV2Y[Cp6c5tZe8I0PxnAW(u"ࠧ࡫ࡱࡥࠫႮ")].upper().replace(t3coAp06zvHrTl49bUVgx(u"ࠨࡉࡈࡘࠬႯ"),eHdDoxhJCEPMZFVa2fg) if XxKBmM4ChyP5 else RLepADMmoBQqVnlT5t
		Fs8cz0DmIrRPSltf71GLpQ(X9XxmHBLWPz)
	if not NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded and ljQMzGmd94A1L67bv:
		HHVLQX4TlGu9m = (KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭Ⴐ") in THOD2Nwp0Mdbyzni7geojAChQ and QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡶࡦࡿࠠࡪࡦ࠽ࠤࠬႱ") in THOD2Nwp0Mdbyzni7geojAChQ)
		t6TYhwIiFPmDHxN5LRVer9B = (ietolwsjpIPK7Fr(u"ࠫ࠺ࠦࡳࡦࡥࠪႲ") in THOD2Nwp0Mdbyzni7geojAChQ and eNEhtuoi9gK8JaTpIXj(u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭Ⴓ") in THOD2Nwp0Mdbyzni7geojAChQ)
		YYqOwUn0j3pLiG1myR6K8g = (O1WFus64LiEAmzpnPIT8jgZHN in [KW5bYS20wTF1LyCs9(u"࠷࠴࠸᐀")] and KW5bYS20wTF1LyCs9(u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩႴ") in THOD2Nwp0Mdbyzni7geojAChQ)
		kAMaNUJW5gpdZ2S = (Cp6c5tZe8I0PxnAW(u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩႵ") in THOD2Nwp0Mdbyzni7geojAChQ and dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬႶ") in THOD2Nwp0Mdbyzni7geojAChQ)
		if   ZEihvxcN7XBjIrT4YytVmFgP1: RCrFOws8DlH6 = LyOR7f69iA(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩႷ")
		elif HHVLQX4TlGu9m: RCrFOws8DlH6 = Cp6c5tZe8I0PxnAW(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫႸ")
		elif t6TYhwIiFPmDHxN5LRVer9B: RCrFOws8DlH6 = NxXMrsTC5FniYuRBOK8(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫႹ")
		elif YYqOwUn0j3pLiG1myR6K8g: RCrFOws8DlH6 = LTN6DPEmrwehtZMy(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡡࡤࡥࡨࡷࡸࠦࡤࡦࡰ࡬ࡩࡩ࠭Ⴚ")
		elif kAMaNUJW5gpdZ2S: RCrFOws8DlH6 = I5bUBGpPXn0W6(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨႻ")
		else: RCrFOws8DlH6 = str(RCrFOws8DlH6)
		if Oyg3pZGAHdws7RWm4e6S in JUgvml72z0B35: pass
		elif Oyg3pZGAHdws7RWm4e6S in IuLpt4BK7yjad0vMW63Ql:
			vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+egY8Jti0smdLM3h1VQRSW(u"ࠧࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪႼ")+str(O1WFus64LiEAmzpnPIT8jgZHN)+S8i3sBYoHWdTURpAgN(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪႽ")+RCrFOws8DlH6+t3coAp06zvHrTl49bUVgx(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫႾ")+Oyg3pZGAHdws7RWm4e6S+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩႿ")+E1Viom5L3684CTOFJ+eNEhtuoi9gK8JaTpIXj(u"ࠫࠥࡣࠧჀ"))
		else: vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+wY1p9mP03S8drbcH64t5WQkv(u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩჁ")+str(O1WFus64LiEAmzpnPIT8jgZHN)+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨჂ")+RCrFOws8DlH6+t3coAp06zvHrTl49bUVgx(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩჃ")+Oyg3pZGAHdws7RWm4e6S+LyOR7f69iA(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧჄ")+E1Viom5L3684CTOFJ+eNEhtuoi9gK8JaTpIXj(u"ࠩࠣࡡࠬჅ"))
		Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv = DGYSRVesiW0hIB6FrM if RucYSIXzNZPtfkgU7jxH else zrHeZWCqQMOymk1d7anKpu0vEx8(E1Viom5L3684CTOFJ)
		if lHfbysRrUV7m4CLSdkxc382n and isinstance(Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv,unicode): Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv = Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv.encode(m6PFtLblInpNZ8x)
		if ojqpuJ0adf: Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv = Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv.split(wY1p9mP03S8drbcH64t5WQkv(u"ࠪ࠳ࠬ჆"))[-NSudqlOzja]
		RUVczdaTtmv4CZGsjwJAgYkB = str(RCrFOws8DlH6)+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡡࡴࠨࠡࠩჇ")+Jy8r37gqzLbIOVdtiPaWD6cjmU0Bv+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࠦࠩࠨ჈")
		if O1WFus64LiEAmzpnPIT8jgZHN in [-NSudqlOzja,-FB0pIzAoK8wqgd3UiY5] or ZEihvxcN7XBjIrT4YytVmFgP1 or HHVLQX4TlGu9m or t6TYhwIiFPmDHxN5LRVer9B or YYqOwUn0j3pLiG1myR6K8g or kAMaNUJW5gpdZ2S:
			NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.code = -bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1
			NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.reason = RCrFOws8DlH6
			if ppxEXy6I3Fr9:
				SS27hYfXGuHs3N94wdgOre5PpvCB = GtawReTLOBjr2DbcZ07nUQJ9k(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6)
				if SS27hYfXGuHs3N94wdgOre5PpvCB.succeeded: return SS27hYfXGuHs3N94wdgOre5PpvCB
		zf7iFX1auw0bQU = YchIv6N09BaWPEj4tieAnluKZrRXT
		if (UbNnVwsHjAoSYQ==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡁࡔࡍࠪ჉") or fDRjs72vQu5O9ThqLKkB==EX25Y0l8ILvz7QcRC(u"ࠧࡂࡕࡎࠫ჊")) and (A1KWRPGNsTqkLlu7oODg26zhYtvMx or ppxEXy6I3Fr9):
			zf7iFX1auw0bQU = WS035ndUBmeHMi9I4A(O1WFus64LiEAmzpnPIT8jgZHN,RUVczdaTtmv4CZGsjwJAgYkB,Oyg3pZGAHdws7RWm4e6S,jlqny86ozgIiXuaexRrJK23LSk)
			if zf7iFX1auw0bQU and UbNnVwsHjAoSYQ==ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡃࡖࡏࠬ჋"): UbNnVwsHjAoSYQ = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫ჌")
			else: UbNnVwsHjAoSYQ = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬჍ")
			if zf7iFX1auw0bQU and fDRjs72vQu5O9ThqLKkB==ietolwsjpIPK7Fr(u"ࠫࡆ࡙ࡋࠨ჎"): fDRjs72vQu5O9ThqLKkB = KW5bYS20wTF1LyCs9(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ჏")
			else: fDRjs72vQu5O9ThqLKkB = eNEhtuoi9gK8JaTpIXj(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨა")
			MoO74hKeqm8fFka.setSetting(ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪბ"),UbNnVwsHjAoSYQ)
			MoO74hKeqm8fFka.setSetting(CKUiyEe28zsZ(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭გ"),fDRjs72vQu5O9ThqLKkB)
		if zf7iFX1auw0bQU:
			if O1WFus64LiEAmzpnPIT8jgZHN==LyOR7f69iA(u"࠼ᐁ") and GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩ࡫ࡸࡹࡶࡳࠨდ") in E1Viom5L3684CTOFJ and lFT6fjM5dor8aRhzm3:
				if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(CKUiyEe28zsZ(u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪე"),NxXMrsTC5FniYuRBOK8(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ვ"),b8bLFaejUB=ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠷࠶࠰࠱ᐂ"))
				ajHR9ABQl2buvm = E1Viom5L3684CTOFJ+XugxFprC26zGM(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬზ")
				Le8ZQrNpM4wYODqChJ0dA7Fi = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,ajHR9ABQl2buvm,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,jlqny86ozgIiXuaexRrJK23LSk,CKUiyEe28zsZ(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧთ"))
				if Le8ZQrNpM4wYODqChJ0dA7Fi.succeeded:
					NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = Le8ZQrNpM4wYODqChJ0dA7Fi
					vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩი")+Oyg3pZGAHdws7RWm4e6S+KW5bYS20wTF1LyCs9(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧკ")+FeTJrG4SkMf09iVys8A+HkiMU0QrdzW3l6gwnT(u"ࠩࠣࡡࠬლ"))
					if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(ehfEsaiJBSvbcULtNPVgykA2(u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧმ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ნ"),b8bLFaejUB=Cp6c5tZe8I0PxnAW(u"࠸࠰࠱࠲ᐃ"))
				else:
					vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫო")+Oyg3pZGAHdws7RWm4e6S+Cp6c5tZe8I0PxnAW(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬპ")+FeTJrG4SkMf09iVys8A+KW5bYS20wTF1LyCs9(u"ࠧࠡ࡟ࠪჟ"))
					if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(LyOR7f69iA(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫრ"),f90fGrlSEObDsuiA3U(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫს"),b8bLFaejUB=TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠲࠱࠲࠳ᐄ"))
			if not NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded and fDRjs72vQu5O9ThqLKkB in [LyOR7f69iA(u"ࠪࡅ࡚࡚ࡏࠨტ"),f90fGrlSEObDsuiA3U(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭უ")] and ppxEXy6I3Fr9:
				if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬფ"),KQ3sCe9Pzh(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨქ"),b8bLFaejUB=wY1p9mP03S8drbcH64t5WQkv(u"࠳࠲࠳࠴ᐅ"))
				Le8ZQrNpM4wYODqChJ0dA7Fi = BE0oV2mYXjd1(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S)
				if Le8ZQrNpM4wYODqChJ0dA7Fi.succeeded:
					NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = Le8ZQrNpM4wYODqChJ0dA7Fi
					vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+w2vjZmdJuY7c(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧღ")+Oyg3pZGAHdws7RWm4e6S+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧყ")+FeTJrG4SkMf09iVys8A+t3coAp06zvHrTl49bUVgx(u"ࠩࠣࡡࠬშ"))
					if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(ietolwsjpIPK7Fr(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩჩ"),wY1p9mP03S8drbcH64t5WQkv(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ც"),b8bLFaejUB=I5bUBGpPXn0W6(u"࠴࠳࠴࠵ᐆ"))
				else:
					vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+LyOR7f69iA(u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩძ")+Oyg3pZGAHdws7RWm4e6S+CKUiyEe28zsZ(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬწ")+FeTJrG4SkMf09iVys8A+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࠡ࡟ࠪჭ"))
					if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨใืู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ხ"),XugxFprC26zGM(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫჯ"),b8bLFaejUB=TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠵࠴࠵࠶ᐇ"))
			if not NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded and UbNnVwsHjAoSYQ in [J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡅ࡚࡚ࡏࠨჰ"),eNEhtuoi9gK8JaTpIXj(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ჱ")] and A1KWRPGNsTqkLlu7oODg26zhYtvMx:
				if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(eNEhtuoi9gK8JaTpIXj(u"ࠬะแฺ์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧჲ"),NxXMrsTC5FniYuRBOK8(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨჳ"),b8bLFaejUB=KW5bYS20wTF1LyCs9(u"࠶࠵࠶࠰ᐈ"))
				ajHR9ABQl2buvm = E1Viom5L3684CTOFJ+HkiMU0QrdzW3l6gwnT(u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬჴ")
				Le8ZQrNpM4wYODqChJ0dA7Fi = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,ajHR9ABQl2buvm,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,jlqny86ozgIiXuaexRrJK23LSk,LTN6DPEmrwehtZMy(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠺ࡴࡩࠩჵ"))
				if Le8ZQrNpM4wYODqChJ0dA7Fi.succeeded:
					NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = Le8ZQrNpM4wYODqChJ0dA7Fi
					vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩჶ")+uJinrVBe7MAY3+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬჷ")+Oyg3pZGAHdws7RWm4e6S+eNEhtuoi9gK8JaTpIXj(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪჸ")+FeTJrG4SkMf09iVys8A+I5bUBGpPXn0W6(u"ࠬࠦ࡝ࠨჹ"))
					if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(CKUiyEe28zsZ(u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧჺ"),w2vjZmdJuY7c(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ჻"),b8bLFaejUB=ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷࠶࠰࠱ᐉ"))
				else:
					vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+KQ3sCe9Pzh(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬჼ")+uJinrVBe7MAY3+f90fGrlSEObDsuiA3U(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫჽ")+Oyg3pZGAHdws7RWm4e6S+jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩჾ")+FeTJrG4SkMf09iVys8A+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࠥࡣࠧჿ"))
					if jlqny86ozgIiXuaexRrJK23LSk: dqKGMYgJxSF8Ub1kotlsP936Ww7B(LyOR7f69iA(u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬᄀ"),CKUiyEe28zsZ(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᄁ"),b8bLFaejUB=t3coAp06zvHrTl49bUVgx(u"࠸࠰࠱࠲ᐊ"))
		if fDRjs72vQu5O9ThqLKkB==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᄂ") or UbNnVwsHjAoSYQ==I5bUBGpPXn0W6(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᄃ"): jlqny86ozgIiXuaexRrJK23LSk = rDceXBpHkfVUYRJ3tIx95Z
		if not NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded:
			if jlqny86ozgIiXuaexRrJK23LSk: ikPnsZcmLjwHvWST50V61u = WS035ndUBmeHMi9I4A(O1WFus64LiEAmzpnPIT8jgZHN,RUVczdaTtmv4CZGsjwJAgYkB,Oyg3pZGAHdws7RWm4e6S,jlqny86ozgIiXuaexRrJK23LSk)
			if O1WFus64LiEAmzpnPIT8jgZHN!=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠲࠱࠲ᐋ") and Oyg3pZGAHdws7RWm4e6S not in cSqXLrU3vfn6Ke and dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭ᄄ") not in Oyg3pZGAHdws7RWm4e6S: ZZoguXCt0Edzipr8R1G7yQsNnS3FVW()
	if MoO74hKeqm8fFka.getSetting(wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᄅ")) not in [KW5bYS20wTF1LyCs9(u"ࠫࡆ࡛ࡔࡐࠩᄆ"),EX25Y0l8ILvz7QcRC(u"࡙ࠬࡔࡐࡒࠪᄇ"),J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡁࡔࡍࠪᄈ")]: MoO74hKeqm8fFka.setSetting(w2vjZmdJuY7c(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᄉ"),XugxFprC26zGM(u"ࠨࡃࡖࡏࠬᄊ"))
	if MoO74hKeqm8fFka.getSetting(jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᄋ")) not in [J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡅ࡚࡚ࡏࠨᄌ"),KQ3sCe9Pzh(u"ࠫࡘ࡚ࡏࡑࠩᄍ"),ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡇࡓࡌࠩᄎ")]: MoO74hKeqm8fFka.setSetting(eNEhtuoi9gK8JaTpIXj(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᄏ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡂࡕࡎࠫᄐ"))
	return NNdthm8Tc71DVUrXyCkFJ2QKwlfBa
def XX4qxWOGTdFm(website,WPkSfFge10VDvyrbIjd,iZTpe0Bdm8ojf2aHEuJUctkCz5bK=None):
	OFtX16T5ufjMDgRJq = RqLvTrID0yMVeClpYcnZ16i3X(u"࠺ᐌ")
	CAJ7FRt9bv1Gwrl5yoOiM6Na34x = [bP01xn84BiQN(u"࠳ᐍ"),bP01xn84BiQN(u"࠳ᐍ"),bP01xn84BiQN(u"࠳ᐍ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠴࠴ᐎ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠹ᐏ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠴࠴ᐎ"),bP01xn84BiQN(u"࠳ᐍ"),bP01xn84BiQN(u"࠳ᐍ"),bP01xn84BiQN(u"࠳ᐍ")]
	je4Vb9Ad8tzHWIuKT = WuT0eE8LCKoP
	HpfIWDszEPZVKw9AkG13Ml = []
	PPawZIk12mNHTxdsgtnuOoe7GhY = [Cp6c5tZe8I0PxnAW(u"࠵ᐐ")]*OFtX16T5ufjMDgRJq
	yyMLZh9cVxaNozIYtG = EeZHTwQUW2BuvJyIh(pyifuNFdxe,EX25Y0l8ILvz7QcRC(u"ࠨࡦ࡬ࡧࡹ࠭ᄑ"),S8i3sBYoHWdTURpAgN(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࡣࡘ࡚ࡁࡕࡗࡖࠫᄒ"))
	for VteqJFj6Zcof1h in list(yyMLZh9cVxaNozIYtG.keys()):
		if website not in VteqJFj6Zcof1h: continue
		uujC2KDqoT3rGHzPpAW1mf,jnOHSDKuokQyEfL0Gwh93p2Wtvm = VteqJFj6Zcof1h.split(KQ3sCe9Pzh(u"ࠪࡣࡤ࠭ᄓ"))
		PPawZIk12mNHTxdsgtnuOoe7GhY[int(jnOHSDKuokQyEfL0Gwh93p2Wtvm)] = yyMLZh9cVxaNozIYtG[VteqJFj6Zcof1h]
	for HIlROZrLU1bpzD0KPGqja7BVc in range(OFtX16T5ufjMDgRJq):
		if HIlROZrLU1bpzD0KPGqja7BVc in je4Vb9Ad8tzHWIuKT+WPkSfFge10VDvyrbIjd: continue
		if HIlROZrLU1bpzD0KPGqja7BVc==iZTpe0Bdm8ojf2aHEuJUctkCz5bK: PPawZIk12mNHTxdsgtnuOoe7GhY[HIlROZrLU1bpzD0KPGqja7BVc] = PPawZIk12mNHTxdsgtnuOoe7GhY[HIlROZrLU1bpzD0KPGqja7BVc]+ehfEsaiJBSvbcULtNPVgykA2(u"࠷ᐑ")
		if PPawZIk12mNHTxdsgtnuOoe7GhY[HIlROZrLU1bpzD0KPGqja7BVc]<t3coAp06zvHrTl49bUVgx(u"࠳ᐒ"): HpfIWDszEPZVKw9AkG13Ml += [HIlROZrLU1bpzD0KPGqja7BVc]*CAJ7FRt9bv1Gwrl5yoOiM6Na34x[HIlROZrLU1bpzD0KPGqja7BVc]
	if not HpfIWDszEPZVKw9AkG13Ml:
		for HIlROZrLU1bpzD0KPGqja7BVc in range(OFtX16T5ufjMDgRJq):
			PPawZIk12mNHTxdsgtnuOoe7GhY[HIlROZrLU1bpzD0KPGqja7BVc] = S8i3sBYoHWdTURpAgN(u"࠱ᐓ")
			if HIlROZrLU1bpzD0KPGqja7BVc in je4Vb9Ad8tzHWIuKT+WPkSfFge10VDvyrbIjd: continue
			HpfIWDszEPZVKw9AkG13Ml += [HIlROZrLU1bpzD0KPGqja7BVc]*CAJ7FRt9bv1Gwrl5yoOiM6Na34x[HIlROZrLU1bpzD0KPGqja7BVc]
	for HIlROZrLU1bpzD0KPGqja7BVc in je4Vb9Ad8tzHWIuKT: PPawZIk12mNHTxdsgtnuOoe7GhY[HIlROZrLU1bpzD0KPGqja7BVc] = NxXMrsTC5FniYuRBOK8(u"࠻࠼࠽࠾ᐔ")
	dhaqkuOUTvIpsj5YH2z0LF6wSAZC = []
	for HIlROZrLU1bpzD0KPGqja7BVc in range(OFtX16T5ufjMDgRJq): dhaqkuOUTvIpsj5YH2z0LF6wSAZC.append(website+EX25Y0l8ILvz7QcRC(u"ࠫࡤࡥࠧᄔ")+str(HIlROZrLU1bpzD0KPGqja7BVc))
	CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࡙ࠬࡃࡓࡃࡓࡉࡗ࡙࡟ࡔࡖࡄࡘ࡚࡙ࠧᄕ"),dhaqkuOUTvIpsj5YH2z0LF6wSAZC,PPawZIk12mNHTxdsgtnuOoe7GhY,Fn5oVSaCmIHciWzEy1Leht0qwXQMT*LyOR7f69iA(u"࠸ᐕ"),YchIv6N09BaWPEj4tieAnluKZrRXT)
	return HpfIWDszEPZVKw9AkG13Ml
def GtawReTLOBjr2DbcZ07nUQJ9k(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6,WPkSfFge10VDvyrbIjd=[]):
	dqKGMYgJxSF8Ub1kotlsP936Ww7B(ehfEsaiJBSvbcULtNPVgykA2(u"࠭ศะลอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᄖ"),eHdDoxhJCEPMZFVa2fg,b8bLFaejUB=KW5bYS20wTF1LyCs9(u"࠻࠺࠶ᐖ"))
	vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+ilBWK5nXxg1do4jENGC07Zq(u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᄗ")+str(O1WFus64LiEAmzpnPIT8jgZHN)+bP01xn84BiQN(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᄘ")+RCrFOws8DlH6+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᄙ")+Oyg3pZGAHdws7RWm4e6S+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࠤࡢࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᄚ")+E1Viom5L3684CTOFJ+egY8Jti0smdLM3h1VQRSW(u"ࠫࠥࡣࠧᄛ"))
	website = Oyg3pZGAHdws7RWm4e6S.split(eNEhtuoi9gK8JaTpIXj(u"ࠬ࠳ࠧᄜ"))[x1Oa8bBf36EwsLMirtFc]
	YYmjwBsRS4MaDQkTKxWpLlhNec1 = XX4qxWOGTdFm(website,WPkSfFge10VDvyrbIjd)
	ge4hFRp51QsUPtGTnBuzka = []
	if website==HkiMU0QrdzW3l6gwnT(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᄝ"):
		if x1Oa8bBf36EwsLMirtFc in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [x1Oa8bBf36EwsLMirtFc]
		if NSudqlOzja in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [NSudqlOzja]
		if FB0pIzAoK8wqgd3UiY5 in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [FB0pIzAoK8wqgd3UiY5]
		if bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1 in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]*RqLvTrID0yMVeClpYcnZ16i3X(u"࠶࠶ᐗ")
		if BSw5mizCOsKxWrRDvtJuFajY in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [BSw5mizCOsKxWrRDvtJuFajY]*ietolwsjpIPK7Fr(u"࠻ᐘ")
		if bP01xn84BiQN(u"࠶ᐚ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [bP01xn84BiQN(u"࠶ᐚ")]*ietolwsjpIPK7Fr(u"࠱࠱ᐙ")
		if dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠸ᐛ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠸ᐛ")]
		if TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺ᐜ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺ᐜ")]
	elif website==eNEhtuoi9gK8JaTpIXj(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᄞ"):
		if bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1 in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]*f90fGrlSEObDsuiA3U(u"࠵࠵ᐝ")
	elif website==ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪᄟ"):
		if NSudqlOzja in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [NSudqlOzja]
		if BSw5mizCOsKxWrRDvtJuFajY in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [BSw5mizCOsKxWrRDvtJuFajY]*J7divaGOCgq2SLfXpDzZYN58wc(u"࠺ᐞ")
		if ietolwsjpIPK7Fr(u"࠵ᐠ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [ietolwsjpIPK7Fr(u"࠵ᐠ")]*ilBWK5nXxg1do4jENGC07Zq(u"࠷࠰ᐟ")
		if egY8Jti0smdLM3h1VQRSW(u"࠷ᐡ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [egY8Jti0smdLM3h1VQRSW(u"࠷ᐡ")]
		if ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠹ᐢ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠹ᐢ")]
	elif website==t3coAp06zvHrTl49bUVgx(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬᄠ"):
		if BSw5mizCOsKxWrRDvtJuFajY in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [BSw5mizCOsKxWrRDvtJuFajY]*CKUiyEe28zsZ(u"࠸ᐣ")
		if S8i3sBYoHWdTURpAgN(u"࠺ᐥ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [S8i3sBYoHWdTURpAgN(u"࠺ᐥ")]*GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠵࠵ᐤ")
	elif website==CKUiyEe28zsZ(u"࡛ࠪࡊࡉࡉࡎࡃࠪᄡ"):
		if x1Oa8bBf36EwsLMirtFc in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [x1Oa8bBf36EwsLMirtFc]
		if NSudqlOzja in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [NSudqlOzja]
		if t3coAp06zvHrTl49bUVgx(u"࠼ᐦ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [t3coAp06zvHrTl49bUVgx(u"࠼ᐦ")]
		if bP01xn84BiQN(u"࠷ᐧ") in YYmjwBsRS4MaDQkTKxWpLlhNec1: ge4hFRp51QsUPtGTnBuzka += [bP01xn84BiQN(u"࠷ᐧ")]
	if ge4hFRp51QsUPtGTnBuzka: YYmjwBsRS4MaDQkTKxWpLlhNec1 = ge4hFRp51QsUPtGTnBuzka
	if YYmjwBsRS4MaDQkTKxWpLlhNec1:
		HxAMR3EBT5OkJWCuS6gFmNVY2n = GljITSOwLKW36.sample(YYmjwBsRS4MaDQkTKxWpLlhNec1,NSudqlOzja)[x1Oa8bBf36EwsLMirtFc]
	else: HxAMR3EBT5OkJWCuS6gFmNVY2n = -NSudqlOzja
	update = YchIv6N09BaWPEj4tieAnluKZrRXT
	if HxAMR3EBT5OkJWCuS6gFmNVY2n==x1Oa8bBf36EwsLMirtFc:
		scraperserver = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠱ࠨᄢ")
		uut40hmT6ZQoXny7OJAR = LyOR7f69iA(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡭ࡨࡩࡵࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩ࠳ࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭࠼࠴࠹࠵ࡪ࠲࠳ࡨ࠴࠱ࡨ࠻࠸ࡢ࠯࠷࠴࠷࠷࠭ࡢࡣ࠻࠸࠲࡫࠹࠳࠵ࡦࡥ࡫࠾࠵࠹࠵࠷ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴ࡩࡰ࠼࠸࠷࠺࠹ࠧᄣ")
		FFZmdCYeVfKwBkMn4qyvcX = E1Viom5L3684CTOFJ+KQ3sCe9Pzh(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᄤ")+uut40hmT6ZQoXny7OJAR+XugxFprC26zGM(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᄥ")
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==NSudqlOzja:
		scraperserver = S8i3sBYoHWdTURpAgN(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠶ࠬᄦ")
		uut40hmT6ZQoXny7OJAR = jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠳࠺࠻࠴ࡩ࠾ࡩ࠵࠮࠹ࡨࡩ࠸࠳࠴ࡦࡧ࠵࠱࠽࠺ࡣ࠱࠯ࡩࡨ࠼࠿࠲ࡣࡣࡧࡨ࠸ࡪ࠵ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫᄧ")
		FFZmdCYeVfKwBkMn4qyvcX = E1Viom5L3684CTOFJ+wY1p9mP03S8drbcH64t5WQkv(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᄨ")+uut40hmT6ZQoXny7OJAR+EX25Y0l8ILvz7QcRC(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᄩ")
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==FB0pIzAoK8wqgd3UiY5:
		scraperserver = XugxFprC26zGM(u"ࠬࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪࠩᄪ")
		uut40hmT6ZQoXny7OJAR = Cp6c5tZe8I0PxnAW(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫࠱࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠮ࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪࡃࡩ࡭࠼࠺࠺ࡧ࠺ࡦࡤ࠵࠷ࡪࡨࡪ࠱࠺ࡦ࠼ࡧ࠺࠻ࡡ࠲࠷ࡩ࠷࠻࠶࠴ࡤࡦ࠼࠵࠹ࡩࡀࡱࡴࡲࡼࡾ࠳ࡳࡦࡴࡹࡩࡷ࠴ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫࠱ࡧࡴࡳ࠺࠹࠲࠳࠵ࠬᄫ")
		FFZmdCYeVfKwBkMn4qyvcX = E1Viom5L3684CTOFJ+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᄬ")+uut40hmT6ZQoXny7OJAR+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᄭ")
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1:
		scraperserver = LyOR7f69iA(u"ࠩࡶࡧࡷࡧࡰࡦࡷࡳࠫᄮ")
		ajHR9ABQl2buvm = E1Viom5L3684CTOFJ.replace(ietolwsjpIPK7Fr(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬᄯ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬᄰ"))
		FFZmdCYeVfKwBkMn4qyvcX = egY8Jti0smdLM3h1VQRSW(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡦࡷࡳ࠲ࡨࡵ࡭࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠵࡛ࡔࡳࡎࡶࡏ࠵ࡴࡈࡒ࡙࡭ࡖࡒࡈࡨࡃࡎࡌ࠴ࡏ࡝࡟ࡊ࡫࡬࠳ࡨ࡯ࡠࡷࠧ࡭ࡨࡩࡵࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡇࡣ࡯ࡷࡪࠬࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࡂ࡯࡬ࠧࡷࡵࡰࡂ࠭ᄱ")+ajHR9ABQl2buvm
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(ietolwsjpIPK7Fr(u"࠭ࡇࡆࡖࠪᄲ"),FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==BSw5mizCOsKxWrRDvtJuFajY:
		scraperserver = HkiMU0QrdzW3l6gwnT(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺࠧᄳ")
		FFZmdCYeVfKwBkMn4qyvcX = bP01xn84BiQN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸ࠳ࡩ࡯࡮࠱ࡂࡸࡴࡱࡥ࡯࠿ࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠪࡵࡸ࡯ࡹࡻࡆࡳࡺࡴࡴࡳࡻࡀࡍࡑࠬࡵࡳ࡮ࡀࠫᄴ")+vFDQstemyYANa(E1Viom5L3684CTOFJ)
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(KQ3sCe9Pzh(u"ࠩࡊࡉ࡙࠭ᄵ"),FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
		try:
			SS27hYfXGuHs3N94wdgOre5PpvCB.content = DIpuHqsKGS3ErJvk9taCRiX80(egY8Jti0smdLM3h1VQRSW(u"ࠪࡨ࡮ࡩࡴࠨᄶ"),SS27hYfXGuHs3N94wdgOre5PpvCB.content)
			SS27hYfXGuHs3N94wdgOre5PpvCB.content = SS27hYfXGuHs3N94wdgOre5PpvCB.content[eNEhtuoi9gK8JaTpIXj(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᄷ")]
		except: pass
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==Cp6c5tZe8I0PxnAW(u"࠶ᐨ"):
		scraperserver = I5bUBGpPXn0W6(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶࠪᄸ")
		uut40hmT6ZQoXny7OJAR = eNEhtuoi9gK8JaTpIXj(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷࠪࡵࡸ࡯ࡹࡻࡢࡧࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡣࡴࡲࡻࡸ࡫ࡲ࠾ࡈࡤࡰࡸ࡫ࠦࡧࡱࡵࡻࡦࡸࡤࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠺࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵ࠰ࡦࡳࡲࡀ࠸࠱࠺࠳ࠫᄹ")
		FFZmdCYeVfKwBkMn4qyvcX = E1Viom5L3684CTOFJ+LTN6DPEmrwehtZMy(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᄺ")+uut40hmT6ZQoXny7OJAR+ietolwsjpIPK7Fr(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᄻ")
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==HkiMU0QrdzW3l6gwnT(u"࠸ᐩ"):
		scraperserver = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠶࠭ᄼ")
		uut40hmT6ZQoXny7OJAR = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧࠩ࡫ࡪࡵࡃࡰࡦࡨࡁ࡮ࡲࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧᄽ")
		FFZmdCYeVfKwBkMn4qyvcX = E1Viom5L3684CTOFJ+XugxFprC26zGM(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᄾ")+uut40hmT6ZQoXny7OJAR+HkiMU0QrdzW3l6gwnT(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᄿ")
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==egY8Jti0smdLM3h1VQRSW(u"࠺ᐪ"):
		scraperserver = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠴ࠪᅀ")
		uut40hmT6ZQoXny7OJAR = Cp6c5tZe8I0PxnAW(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲ࡥ࠶ࡨ࠸ࡧࡥ࠲࠺࠸ࡨ࡫࠺ࡢࡧ࠸ࡤࡪ࠺࠹࠳ࡤ࠹࠳࠸࠵ࡨ࠳࠵࠹ࡦ࠽ࡪ࠿࠹ࡣࡧ࠷࠺࠻ࡧࡥ࠺࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫᅁ")
		FFZmdCYeVfKwBkMn4qyvcX = E1Viom5L3684CTOFJ+CKUiyEe28zsZ(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᅂ")+uut40hmT6ZQoXny7OJAR+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᅃ")
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	elif HxAMR3EBT5OkJWCuS6gFmNVY2n==NxXMrsTC5FniYuRBOK8(u"࠼ᐫ"):
		scraperserver = bP01xn84BiQN(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠹ࠧᅄ")
		FFZmdCYeVfKwBkMn4qyvcX = Cp6c5tZe8I0PxnAW(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠲ࡺ࠶࠵࠿ࡢࡲ࡬ࡣࡰ࡫ࡹ࠾࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲࠦࡶࡴ࡯ࡁࠬᅅ")+E1Viom5L3684CTOFJ
		SS27hYfXGuHs3N94wdgOre5PpvCB = aZOozWEtm3ifLwelvb(I5bUBGpPXn0W6(u"ࠬࡍࡅࡕࠩᅆ"),FFZmdCYeVfKwBkMn4qyvcX,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	else:
		scraperserver,FFZmdCYeVfKwBkMn4qyvcX = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
		SS27hYfXGuHs3N94wdgOre5PpvCB = maQf4xXLtV2()
		update = rDceXBpHkfVUYRJ3tIx95Z
	if update and not SS27hYfXGuHs3N94wdgOre5PpvCB.succeeded:
		XX4qxWOGTdFm(website,[],HxAMR3EBT5OkJWCuS6gFmNVY2n)
		if len(list(set(YYmjwBsRS4MaDQkTKxWpLlhNec1)))>NSudqlOzja:
			zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᅇ"),CKUiyEe28zsZ(u"ࠧๅๆฦืๆࠦำ๋ำไีู๋ࠥศๆฯอࠥอไฮฮหࠤึ่ๅࠡࠩᅈ")+str(HxAMR3EBT5OkJWCuS6gFmNVY2n)+f90fGrlSEObDsuiA3U(u"ࠨࠢไุ้ࠦแ๋ࠢ฼้้๐ษࠡฬฯหํุࠠศๆะะอࠦ࠮࠯๊่ࠢࠥะั๋ั้ࠣาอ่ๅหࠣฮัอ่ำࠢส่าาศࠡ็ิอࠥษฮา๋ࠣฬฬูสฯัสู้๊ࠥาใิࠤ๊ิสๅใࠣรࠦ࠭ᅉ"))
			if zf7iFX1auw0bQU==NSudqlOzja:
				WPkSfFge10VDvyrbIjd.append(HxAMR3EBT5OkJWCuS6gFmNVY2n)
				SS27hYfXGuHs3N94wdgOre5PpvCB = GtawReTLOBjr2DbcZ07nUQJ9k(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,u1ek4lEhrINBALc2xa,jlqny86ozgIiXuaexRrJK23LSk,Oyg3pZGAHdws7RWm4e6S,O1WFus64LiEAmzpnPIT8jgZHN,RCrFOws8DlH6,WPkSfFge10VDvyrbIjd)
				return SS27hYfXGuHs3N94wdgOre5PpvCB
	SS27hYfXGuHs3N94wdgOre5PpvCB.scrapernumber = str(HxAMR3EBT5OkJWCuS6gFmNVY2n)
	SS27hYfXGuHs3N94wdgOre5PpvCB.scraperserver = scraperserver
	SS27hYfXGuHs3N94wdgOre5PpvCB.scraperurl = FFZmdCYeVfKwBkMn4qyvcX
	YKpBwgZzX1sv0xlSeM4P = RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩึ๎ึ็ัࠡำๅ้ࠥ࠭ᅊ")+SS27hYfXGuHs3N94wdgOre5PpvCB.scrapernumber
	if SS27hYfXGuHs3N94wdgOre5PpvCB.succeeded:
		vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+CKUiyEe28zsZ(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡥࡽࡵࡧࡳࡴࠢࡥࡰࡴࡩ࡫ࡪࡰࡪࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪᅋ")+scraperserver+EX25Y0l8ILvz7QcRC(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᅌ")+Oyg3pZGAHdws7RWm4e6S+EX25Y0l8ILvz7QcRC(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᅍ")+E1Viom5L3684CTOFJ+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࠠ࡞ࠩᅎ"))
		dqKGMYgJxSF8Ub1kotlsP936Ww7B(egY8Jti0smdLM3h1VQRSW(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᅏ"),YKpBwgZzX1sv0xlSeM4P,b8bLFaejUB=QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠼࠻࠰ᐬ"))
	else:
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡧࡿࡰࡢࡵࡶࠤࡧࡲ࡯ࡤ࡭࡬ࡲ࡬ࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬᅐ")+scraperserver+NxXMrsTC5FniYuRBOK8(u"ࠩࠣࡡࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᅑ")+str(SS27hYfXGuHs3N94wdgOre5PpvCB.code)+ietolwsjpIPK7Fr(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᅒ")+SS27hYfXGuHs3N94wdgOre5PpvCB.reason+LTN6DPEmrwehtZMy(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᅓ")+Oyg3pZGAHdws7RWm4e6S+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᅔ")+E1Viom5L3684CTOFJ+ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࠠ࡞ࠩᅕ"))
		dqKGMYgJxSF8Ub1kotlsP936Ww7B(ilBWK5nXxg1do4jENGC07Zq(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤฯาว้ิࠣห้ำฬษࠩᅖ"),YKpBwgZzX1sv0xlSeM4P,b8bLFaejUB=GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠽࠵࠱ᐭ"))
	return SS27hYfXGuHs3N94wdgOre5PpvCB
def aaxj45TqfRm38HepJy7C(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s=eHdDoxhJCEPMZFVa2fg,nLNrPvpjiES2hJ=eHdDoxhJCEPMZFVa2fg):
	E1Viom5L3684CTOFJ,O3m8areAPTfgLbXts,GGyD8Bnmuv49whkr5FzQ3qJIZxoesp,fntdCl29AwQROPKvj = dfqLZkHznMvtIoBpFaQx6Nb(FeTJrG4SkMf09iVys8A)
	try: r7iCTyjmW9REoe4KHl = kkMFwqXnC9v0y.copy()
	except: r7iCTyjmW9REoe4KHl = kkMFwqXnC9v0y
	KKeiYLQO4vH3yskhbG = tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,KhGpZcMqsnrbv,r7iCTyjmW9REoe4KHl,vV5c82MFznU1HTX6
	if JEvXRNInqCF:
		qldY3LPe0pDiuyoM8vIH = EeZHTwQUW2BuvJyIh(pyifuNFdxe,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪᅗ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬᅘ"),KKeiYLQO4vH3yskhbG)
		if qldY3LPe0pDiuyoM8vIH.succeeded:
			NEI8AGXDS73KmBvT54o6L(I5bUBGpPXn0W6(u"ࠪࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࡒࡆࡃࡇࡣࡈࡇࡃࡉࡇࠪᅙ"),E1Viom5L3684CTOFJ,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Oyg3pZGAHdws7RWm4e6S,tWILFaVZ5E6rdoRXNGApOiJ3Ss0)
			return qldY3LPe0pDiuyoM8vIH
	qldY3LPe0pDiuyoM8vIH = aZOozWEtm3ifLwelvb(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,vV5c82MFznU1HTX6,showDialogs,Oyg3pZGAHdws7RWm4e6S,ra8qpfiOm4xhQJZ96evUctL1s,nLNrPvpjiES2hJ)
	if qldY3LPe0pDiuyoM8vIH.succeeded:
		if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬᅚ") in Oyg3pZGAHdws7RWm4e6S: qldY3LPe0pDiuyoM8vIH.content = br73AglSQ0i(qldY3LPe0pDiuyoM8vIH.content)
		if qldY3LPe0pDiuyoM8vIH.scrape: JEvXRNInqCF = c4cPSX2jOIm8KCQlfW5wM
		if JEvXRNInqCF and qldY3LPe0pDiuyoM8vIH.content: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᅛ"),KKeiYLQO4vH3yskhbG,qldY3LPe0pDiuyoM8vIH,JEvXRNInqCF)
	return qldY3LPe0pDiuyoM8vIH
def jczXhd47kwrWFoEg8lVSCR2eZfLIQT(JEvXRNInqCF,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,showDialogs,Oyg3pZGAHdws7RWm4e6S):
	if not KhGpZcMqsnrbv or isinstance(KhGpZcMqsnrbv,dict): tWILFaVZ5E6rdoRXNGApOiJ3Ss0 = KQ3sCe9Pzh(u"࠭ࡇࡆࡖࠪᅜ")
	else:
		tWILFaVZ5E6rdoRXNGApOiJ3Ss0 = ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡑࡑࡖࡘࠬᅝ")
		KhGpZcMqsnrbv = zrHeZWCqQMOymk1d7anKpu0vEx8(KhGpZcMqsnrbv)
		qnYrouTAEPke3tgRB8awGNfM,KhGpZcMqsnrbv = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(KhGpZcMqsnrbv)
	qldY3LPe0pDiuyoM8vIH = aaxj45TqfRm38HepJy7C(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,YchIv6N09BaWPEj4tieAnluKZrRXT,showDialogs,Oyg3pZGAHdws7RWm4e6S)
	a3glxPAGFXm2kzq = qldY3LPe0pDiuyoM8vIH.content
	a3glxPAGFXm2kzq = str(a3glxPAGFXm2kzq)
	return a3glxPAGFXm2kzq
def dfqLZkHznMvtIoBpFaQx6Nb(FeTJrG4SkMf09iVys8A):
	aN1kSPxc8h0ofR9tnU56lTGD = FeTJrG4SkMf09iVys8A.split(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡾࡿࠫᅞ"))
	E1Viom5L3684CTOFJ,O3m8areAPTfgLbXts,GGyD8Bnmuv49whkr5FzQ3qJIZxoesp,fntdCl29AwQROPKvj = aN1kSPxc8h0ofR9tnU56lTGD[x1Oa8bBf36EwsLMirtFc],None,None,YchIv6N09BaWPEj4tieAnluKZrRXT
	for KKeiYLQO4vH3yskhbG in aN1kSPxc8h0ofR9tnU56lTGD:
		if dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᅟ") in KKeiYLQO4vH3yskhbG: O3m8areAPTfgLbXts = KKeiYLQO4vH3yskhbG[jUcmHhgVvW0EdYOIfXeaDF(u"࠱࠲ᐮ"):]
		elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ᅠ") in KKeiYLQO4vH3yskhbG: GGyD8Bnmuv49whkr5FzQ3qJIZxoesp = KKeiYLQO4vH3yskhbG[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠺ᐯ"):]
		elif egY8Jti0smdLM3h1VQRSW(u"ࠫࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᅡ") in KKeiYLQO4vH3yskhbG: fntdCl29AwQROPKvj = rDceXBpHkfVUYRJ3tIx95Z
	return E1Viom5L3684CTOFJ,O3m8areAPTfgLbXts,GGyD8Bnmuv49whkr5FzQ3qJIZxoesp,fntdCl29AwQROPKvj
def k1qJOMsQKf(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,eV1WqZKLHkp,GGKoy3bmQpTDizXt0Bnd6YehlOwE,M6MlPEocWdCDX2ti,kkMFwqXnC9v0y=eHdDoxhJCEPMZFVa2fg):
	bZXw6BdOE0sPW1AmeNrRoviMcL9TG = b31wAB8mhaz2rXHoJFlfvDugtsOj(FeTJrG4SkMf09iVys8A,S8i3sBYoHWdTURpAgN(u"ࠬࡻࡲ࡭ࠩᅢ"))
	gbcySDjuoT2V9qAJMUOfFa34L7zmQ = MoO74hKeqm8fFka.getSetting(KW5bYS20wTF1LyCs9(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨᅣ")+eV1WqZKLHkp)
	if bZXw6BdOE0sPW1AmeNrRoviMcL9TG==gbcySDjuoT2V9qAJMUOfFa34L7zmQ: MoO74hKeqm8fFka.setSetting(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᅤ")+eV1WqZKLHkp,eHdDoxhJCEPMZFVa2fg)
	if gbcySDjuoT2V9qAJMUOfFa34L7zmQ: ajHR9ABQl2buvm = FeTJrG4SkMf09iVys8A.replace(bZXw6BdOE0sPW1AmeNrRoviMcL9TG,gbcySDjuoT2V9qAJMUOfFa34L7zmQ)
	else:
		ajHR9ABQl2buvm = FeTJrG4SkMf09iVys8A
		gbcySDjuoT2V9qAJMUOfFa34L7zmQ = bZXw6BdOE0sPW1AmeNrRoviMcL9TG
	Le8ZQrNpM4wYODqChJ0dA7Fi = aaxj45TqfRm38HepJy7C(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,ajHR9ABQl2buvm,eHdDoxhJCEPMZFVa2fg,kkMFwqXnC9v0y,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠳ࡶࡸࠬᅥ"))
	a3glxPAGFXm2kzq = Le8ZQrNpM4wYODqChJ0dA7Fi.content
	if WHjh1POtMKlmgiy68RSqb:
		try: a3glxPAGFXm2kzq = a3glxPAGFXm2kzq.decode(m6PFtLblInpNZ8x,I5bUBGpPXn0W6(u"ࠩ࡬࡫ࡳࡵࡲࡦࠩᅦ"))
		except: pass
	if not Le8ZQrNpM4wYODqChJ0dA7Fi.succeeded or M6MlPEocWdCDX2ti not in a3glxPAGFXm2kzq:
		GGKoy3bmQpTDizXt0Bnd6YehlOwE = GGKoy3bmQpTDizXt0Bnd6YehlOwE.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,ietolwsjpIPK7Fr(u"ࠪ࠯ࠬᅧ"))
		E1Viom5L3684CTOFJ = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡱ࠾ࠩᅨ")+GGKoy3bmQpTDizXt0Bnd6YehlOwE
		W9PzsMeLJTc83mS45G17n = {I5bUBGpPXn0W6(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᅩ"):eHdDoxhJCEPMZFVa2fg}
		NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = aaxj45TqfRm38HepJy7C(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠲࡯ࡦࠪᅪ"))
		if NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.succeeded:
			a3glxPAGFXm2kzq = NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.content
			if WHjh1POtMKlmgiy68RSqb:
				try: a3glxPAGFXm2kzq = a3glxPAGFXm2kzq.decode(m6PFtLblInpNZ8x,LyOR7f69iA(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᅫ"))
				except: pass
			JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡡࡽࠪ࡝ࡁ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᅬ"),a3glxPAGFXm2kzq,cBawilJXvK1m.DOTALL)
			o6tZEyQbKTm9cj = [gbcySDjuoT2V9qAJMUOfFa34L7zmQ]
			OOnoPaYgjUXSh7QR0v = [ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡤࡴࡰ࠭ᅭ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࠪᅮ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡹࡽࡩࡵࡶࡨࡶࠬᅯ"),t3coAp06zvHrTl49bUVgx(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ᅰ"),HkiMU0QrdzW3l6gwnT(u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨᅱ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡱࡪࡳࠫᅲ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡣࡷࡰࡦࡷࠧᅳ"),w2vjZmdJuY7c(u"ࠩࡶ࡭ࡹ࡫ࡩ࡯ࡦ࡬ࡧࡪࡹࠧᅴ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡷࡺࡸ࠮࡭ࡻࠪᅵ"),Cp6c5tZe8I0PxnAW(u"ࠫࡧࡲ࡯ࡨࡵࡳࡳࡹ࠭ᅶ"),EX25Y0l8ILvz7QcRC(u"ࠬ࡯࡮ࡧࡱࡵࡱࡪࡸࠧᅷ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡳࡪࡶࡨࡰ࡮ࡱࡥࠨᅸ"),eNEhtuoi9gK8JaTpIXj(u"ࠧࡪࡰࡶࡸࡦ࡭ࡲࡢ࡯ࠪᅹ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡵࡱࡥࡵࡩࡨࡢࡶࠪᅺ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࡫ࡸࡹࡶ࠭ࡦࡳࡸ࡭ࡻ࠭ᅻ"),CKUiyEe28zsZ(u"ࠪࡪࡦࡹࡥ࡭ࡲ࡯ࡹࡸ࠭ᅼ")]
			for GUk97EVcihOnsxQgJ8W in JCZVK86QTYwX4mfgOrod:
				if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in GUk97EVcihOnsxQgJ8W for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in OOnoPaYgjUXSh7QR0v): continue
				gbcySDjuoT2V9qAJMUOfFa34L7zmQ = b31wAB8mhaz2rXHoJFlfvDugtsOj(GUk97EVcihOnsxQgJ8W,S8i3sBYoHWdTURpAgN(u"ࠫࡺࡸ࡬ࠨᅽ"))
				if gbcySDjuoT2V9qAJMUOfFa34L7zmQ in o6tZEyQbKTm9cj: continue
				if len(o6tZEyQbKTm9cj)==eNEhtuoi9gK8JaTpIXj(u"࠻ᐰ"):
					vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࠦࠠࠡࡉࡲࡳ࡬ࡲࡥࠡࡦ࡬ࡨࠥࡴ࡯ࡵࠢࡩ࡭ࡳࡪࠠࡢࠢࡱࡩࡼࠦࡨࡰࡵࡷࡲࡦࡳࡥࠡࠢࠣࡗ࡮ࡺࡥ࠻ࠢ࡞ࠤࠬᅾ")+eV1WqZKLHkp+egY8Jti0smdLM3h1VQRSW(u"࠭ࠠ࡞ࠢࠣࡓࡱࡪ࠺ࠡ࡝ࠣࠫᅿ")+bZXw6BdOE0sPW1AmeNrRoviMcL9TG+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࠡ࡟ࠪᆀ"))
					MoO74hKeqm8fFka.setSetting(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࠪᆁ")+eV1WqZKLHkp,eHdDoxhJCEPMZFVa2fg)
					break
				o6tZEyQbKTm9cj.append(gbcySDjuoT2V9qAJMUOfFa34L7zmQ)
				ajHR9ABQl2buvm = FeTJrG4SkMf09iVys8A.replace(bZXw6BdOE0sPW1AmeNrRoviMcL9TG,gbcySDjuoT2V9qAJMUOfFa34L7zmQ)
				Le8ZQrNpM4wYODqChJ0dA7Fi = aaxj45TqfRm38HepJy7C(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,ajHR9ABQl2buvm,eHdDoxhJCEPMZFVa2fg,kkMFwqXnC9v0y,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠶ࡶࡩ࠭ᆂ"))
				a3glxPAGFXm2kzq = Le8ZQrNpM4wYODqChJ0dA7Fi.content
				if Le8ZQrNpM4wYODqChJ0dA7Fi.succeeded and M6MlPEocWdCDX2ti in a3glxPAGFXm2kzq:
					vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+w2vjZmdJuY7c(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡦࡰࡷࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪᆃ")+eV1WqZKLHkp+w2vjZmdJuY7c(u"ࠫࠥࡣࠠࠡࠢࡑࡩࡼࡀࠠ࡜ࠢࠪᆄ")+gbcySDjuoT2V9qAJMUOfFa34L7zmQ+jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࠦ࡝ࠡࠢࡒࡰࡩࡀࠠ࡜ࠢࠪᆅ")+bZXw6BdOE0sPW1AmeNrRoviMcL9TG+eNEhtuoi9gK8JaTpIXj(u"࠭ࠠ࡞ࠩᆆ"))
					MoO74hKeqm8fFka.setSetting(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࠩᆇ")+eV1WqZKLHkp,gbcySDjuoT2V9qAJMUOfFa34L7zmQ)
					break
	return gbcySDjuoT2V9qAJMUOfFa34L7zmQ,ajHR9ABQl2buvm,Le8ZQrNpM4wYODqChJ0dA7Fi
def v9vBX6ZiQ0UHxfze8EjG4nmRW(oh8Z06rUdqJ):
	WTlymR1DtfjcHqGUKF5YkZ2N = {
	 eNEhtuoi9gK8JaTpIXj(u"ࠨࡣ࡫ࡻࡦࡱࠧᆈ")				:wY1p9mP03S8drbcH64t5WQkv(u"่ࠩ์็฿ࠠฤ้๋ห่ࠦส๋ใํࠫᆉ")
	,KW5bYS20wTF1LyCs9(u"ࠪࡥࡰࡵࡡ࡮ࠩᆊ")				:KW5bYS20wTF1LyCs9(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨᆋ")
	,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡧ࡫ࡰࡣࡰࡧࡦࡳࠧᆌ")				:NxXMrsTC5FniYuRBOK8(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣ็ฬ๋ࠧᆍ")
	,w2vjZmdJuY7c(u"ࠧࡢ࡭ࡺࡥࡲ࠭ᆎ")				:jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ็๋ๆ฾ࠦรไ๊ส้ࠥอไอัํำࠬᆏ")
	,KQ3sCe9Pzh(u"ࠩࡤ࡯ࡼࡧ࡭ࡵࡷࡥࡩࠬᆐ")			:LTN6DPEmrwehtZMy(u"้ࠪํู่ࠡษๆ์ฬ๋ࠠห์๋ฬࠬᆑ")
	,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡦࡲࡡࡳࡣࡥࠫᆒ")				:EX25Y0l8ILvz7QcRC(u"๋่ࠬใ฻ࠣ็้ࠦวๅ฻ิฬࠬᆓ")
	,TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡡ࡭ࡨࡤࡸ࡮ࡳࡩࠨᆔ")				:LyOR7f69iA(u"ࠧๆ๊ๅ฽ࠥอไๆ่หีࠥอไโษฺ้๏࠭ᆕ")
	,LyOR7f69iA(u"ࠨࡣ࡯࡯ࡦࡽࡴࡩࡣࡵࠫᆖ")			:ilBWK5nXxg1do4jENGC07Zq(u"่ࠩ์็฿ࠠใ่สอࠥอไไ๊ฮีࠬᆗ")
	,KQ3sCe9Pzh(u"ࠪࡥࡱࡳࡡࡢࡴࡨࡪࠬᆘ")				:GGn0oFgBITbethla4qXL9sfkdMZNPH(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠศๆ่฽ฬืแࠨᆙ")
	,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡧ࡬࡮ࡵࡷࡦࡦ࠭ᆚ")				:ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ๅ้ไ฼ࠤฬ๊ๅึูหอࠬᆛ")
	,Cp6c5tZe8I0PxnAW(u"ࠧࡢࡴࡤࡦ࡮ࡩࡴࡰࡱࡱࡷࠬᆜ")			:I5bUBGpPXn0W6(u"ࠨ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪᆝ")
	,NxXMrsTC5FniYuRBOK8(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫᆞ")				:I5bUBGpPXn0W6(u"้ࠪํู่ࠡ฻ิฬู๊๋ࠥัࠪᆟ")
	,wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡦࡸࡢ࡭࡫ࡲࡲࡿ࠭ᆠ")				:eNEhtuoi9gK8JaTpIXj(u"๋่ࠬใ฻ࠣ฽ึฮࠠๅ์๋๊ื࠭ᆡ")
	,I5bUBGpPXn0W6(u"࠭ࡢࡰ࡭ࡵࡥࠬᆢ")				:LyOR7f69iA(u"ࠧๆ๊ๅ฽ࠥฮใาษࠪᆣ")
	,NxXMrsTC5FniYuRBOK8(u"ࠨࡨࡸࡷ࡭ࡧࡲࡷ࡫ࡧࡩࡴ࠭ᆤ")			:iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"่ࠩ์็฿ࠠโ๊ืหึࠦแ๋ัํ์ࠬᆥ")
	,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡪࡺࡹࡨࡢࡴࡷࡺࠬᆦ")				:dEwyQDiz0nhjV6MovaH7tIWYel92(u"๊ࠫ๎โฺࠢไ์ูอัࠡฬํๅ๏࠭ᆧ")
	,I5bUBGpPXn0W6(u"ࠬࡱࡩࡳ࡯ࡤࡰࡰ࠭ᆨ")				:HkiMU0QrdzW3l6gwnT(u"࠭ๅ้ไ฼ࠤ่ืๅศๆๆࠫᆩ")
	,EX25Y0l8ILvz7QcRC(u"ࠧࡥࡴࡤࡱࡦࡩࡡࡧࡧࠪᆪ")			:t3coAp06zvHrTl49bUVgx(u"ࠨ็๋ๆ฾ࠦฯาษ่ห้ࠥวโ์๊ࠫᆫ")
	,t3coAp06zvHrTl49bUVgx(u"ࠩࡷ࡭ࡰࡧࡡࡵࠩᆬ")				:ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"้ࠪํู่ࠡฬๆหฯ࠭ᆭ")
	,egY8Jti0smdLM3h1VQRSW(u"ࠫࡶ࡬ࡩ࡭࡯ࠪᆮ")				:wY1p9mP03S8drbcH64t5WQkv(u"๋่ࠬใ฻ࠣ็๏๎ࠠโ์็้ࠬᆯ")
	,KQ3sCe9Pzh(u"࠭ࡳࡩࡣࡥࡥࡰࡧࡴࡺࠩᆰ")			:NxXMrsTC5FniYuRBOK8(u"ࠧๆ๊ๅ฽ฺࠥศไฬํࠫᆱ")
	,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡣࡱ࡭ࡲ࡫ࡺࡪࡦࠪᆲ")				:RqLvTrID0yMVeClpYcnZ16i3X(u"่ࠩ์็฿ࠠศ่่๎ุࠥฯࠨᆳ")
	,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡦࡷࡹࡴࡦ࡬ࠪᆴ")				:KQ3sCe9Pzh(u"๊ࠫ๎โฺࠢหีุะ๊อࠩᆵ")
	,eNEhtuoi9gK8JaTpIXj(u"ࠬࡹࡥࡳ࡫ࡨࡷࡹ࡯࡭ࡦࠩᆶ")			:LyOR7f69iA(u"࠭ๅ้ไ฼ࠤุ๐ั๋ีࠣฮฬ๐ๅࠨᆷ")
	,S8i3sBYoHWdTURpAgN(u"ࠧࡤ࡫ࡰࡥ࠹ࡶࠧᆸ")				:iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ัࠡสํࠫᆹ")
	,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡦ࡭ࡲࡧ࠴࠱࠲ࠪᆺ")				:J7divaGOCgq2SLfXpDzZYN58wc(u"้ࠪํู่ࠡีํ้ฬࠦ࠴࠱࠲ࠪᆻ")
	,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡨ࡯࡭ࡢ࠶ࡸࠫᆼ")				:f90fGrlSEObDsuiA3U(u"๋่ࠬใ฻ࠣื๏๋วࠡใ๋ี๏๎ࠧᆽ")
	,ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨᆾ")				:S8i3sBYoHWdTURpAgN(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ฽อี่ࠨᆿ")
	,w2vjZmdJuY7c(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࠪᇀ")				:EX25Y0l8ILvz7QcRC(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪᇁ")
	,wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡦࡼࡵࡲ࡬ࠩᇂ")			:QQM0uTLKsZWel6m1arpjVz4vwcSN(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠥ฿ๅๅࠩᇃ")
	,HkiMU0QrdzW3l6gwnT(u"ࠬࡩࡩ࡮ࡣࡦࡰࡺࡶࠧᇄ")				:QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢๆ่ํฮࠧᇅ")
	,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴࠩᇆ")				:TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆอๆำࠩᇇ")
	,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡦ࡭ࡲࡧࡦࡳࡧࡨࠫᇈ")				:RqLvTrID0yMVeClpYcnZ16i3X(u"้ࠪํู่ࠡีํ้ฬࠦแา์ࠪᇉ")
	,CKUiyEe28zsZ(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧᇊ")			:CKUiyEe28zsZ(u"๋่ࠬใ฻ࠣื๏๋วࠡๆส๎ฯ࠭ᇋ")
	,LyOR7f69iA(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧᇌ")				:LyOR7f69iA(u"ࠧๆ๊ๅ฽ู๊ࠥๆษ๊ࠣฬ๎ࠧᇍ")
	,f90fGrlSEObDsuiA3U(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ᇎ")			:w2vjZmdJuY7c(u"่ࠩ์็฿ࠠะ์็๎๋่ࠥี่ࠪᇏ")
	,bP01xn84BiQN(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪᇐ")	:Cp6c5tZe8I0PxnAW(u"๊ࠫ๎โฺࠢา๎้๐ࠠๆ๊ื๊๋ࠥำหะา้๏์ࠧᇑ")
	,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰࡬ࡦࡹࡨࡵࡣࡪࡷࠬᇒ")	:J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ๅ้ไ฼ࠤิ๐ไ๋่ࠢ์ู์่ࠠษืฮฬ้ࠧᇓ")
	,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡲࡩࡷࡧࡶࠫᇔ")	:J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨ็๋ๆ฾ࠦฯ๋ๆํࠤ๊๎ิ็่ࠢฬฬฺัࠨᇕ")
	,CKUiyEe28zsZ(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪᇖ"):w2vjZmdJuY7c(u"้ࠪํู่ࠡัํ่๏ࠦๅ้ึ้ࠤ็๎วว็ࠪᇗ")
	,KW5bYS20wTF1LyCs9(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡷࡳࡵ࡯ࡣࡴࠩᇘ")	:ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"๋่ࠬใ฻ࠣำ๏๊๊ࠡ็ุ๋๋ࠦๅ้ษู๎฾࠭ᇙ")
	,HkiMU0QrdzW3l6gwnT(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡻ࡯ࡤࡦࡱࡶࠫᇚ")	:XugxFprC26zGM(u"ࠧๆ๊ๅ฽ࠥี๊ๅ์้ࠣํฺๆࠡใํำ๏๎็ศฬࠪᇛ")
	,HkiMU0QrdzW3l6gwnT(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪᇜ")				:egY8Jti0smdLM3h1VQRSW(u"่ࠩฮํ่แࠨᇝ")
	,NxXMrsTC5FniYuRBOK8(u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫᇞ")				:f90fGrlSEObDsuiA3U(u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫᇟ")
	,egY8Jti0smdLM3h1VQRSW(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ᇠ")				:LTN6DPEmrwehtZMy(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧᇡ")
	,KQ3sCe9Pzh(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩᇢ")				:LTN6DPEmrwehtZMy(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫᇣ")
	,I5bUBGpPXn0W6(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫᇤ")				:CKUiyEe28zsZ(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭ᇥ")
	,LTN6DPEmrwehtZMy(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ᇦ")				:RqLvTrID0yMVeClpYcnZ16i3X(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨᇧ")
	,w2vjZmdJuY7c(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨᇨ")				:f90fGrlSEObDsuiA3U(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪᇩ")
	,ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬᇪ")			:XugxFprC26zGM(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧᇫ")
	,ietolwsjpIPK7Fr(u"ࠪࡩ࡬ࡿࡤࡦࡣࡧࠫᇬ")				:w2vjZmdJuY7c(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠะ์าࠫᇭ")
	,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬ࡬ࡡࡳࡧࡶ࡯ࡴ࠭ᇮ")				:I5bUBGpPXn0W6(u"࠭ๅ้ไ฼ࠤๆอั๋ีๆ์ࠬᇯ")
	,XugxFprC26zGM(u"ࠧࡦࡩࡼࡲࡴࡽࠧᇰ")				:bP01xn84BiQN(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤ๋อ่ࠨᇱ")
	,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫᇲ")				:HkiMU0QrdzW3l6gwnT(u"้ࠪํู่ࠡษ็ื๏์ๅศࠩᇳ")
	,LyOR7f69iA(u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬᇴ")				:Cp6c5tZe8I0PxnAW(u"๋่ࠬใ฻ࠣๅอืใสࠩᇵ")
	,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡣࡪ࡯ࡤࡻࡧࡧࡳࠨᇶ")				:egY8Jti0smdLM3h1VQRSW(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ์อูࠧᇷ")
	,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᇸ")				:Cp6c5tZe8I0PxnAW(u"ࠩไุ้࠭ᇹ")
	,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭ᇺ")			:bP01xn84BiQN(u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩᇻ")
	,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧᇼ")				:KW5bYS20wTF1LyCs9(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨᇽ")
	,LTN6DPEmrwehtZMy(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩᇾ")				:KW5bYS20wTF1LyCs9(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫᇿ")
	,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࡩࡳࡱࡪࡥࡳࠩሀ")				:iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"้ࠪั๊ฯࠨሁ")
	,EX25Y0l8ILvz7QcRC(u"ࠫ࡫ࡵࡳࡵࡣࠪሂ")				:I5bUBGpPXn0W6(u"๋่ࠬใ฻ࠣๅํูสศࠩሃ")
	,bP01xn84BiQN(u"࠭ࡧࡰࡱࡧࠫሄ")					:w2vjZmdJuY7c(u"ࠧอ์าࠫህ")
	,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪሆ")				:RqLvTrID0yMVeClpYcnZ16i3X(u"่ࠩ์็฿่ࠠๆสࠤุ๐ๅศࠩሇ")
	,LyOR7f69iA(u"ࠪ࡬ࡪࡲࡡ࡭ࠩለ")				:ehfEsaiJBSvbcULtNPVgykA2(u"๊ࠫ๎โฺ๊่ࠢฬ๊๋๊ࠠอ๎ํฮࠧሉ")
	,ilBWK5nXxg1do4jENGC07Zq(u"ࠬ࡯ࡦࡪ࡮ࡰࠫሊ")				:f90fGrlSEObDsuiA3U(u"࠭ๅ้ไ฼ࠤ็์วสࠢล๎ࠥ็๊ๅ็ࠪላ")
	,CKUiyEe28zsZ(u"ࠧࡪࡨ࡬ࡰࡲ࠳ࡡࡳࡣࡥ࡭ࡨ࠭ሌ")			:NxXMrsTC5FniYuRBOK8(u"ࠨ็๋ๆ฾ࠦโ็ษฬࠤว๐ࠠโ์็้ࠥ฿ัษ์ࠪል")
	,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࡬ࡪ࡮ࡲ࡭࠮ࡧࡱ࡫ࡱ࡯ࡳࡩࠩሎ")		:ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"้ࠪํู่ࠡไ้หฮࠦย๋ࠢไ๎้๋ࠠศ่ฯ่๏ุ๊ࠨሏ")
	,NxXMrsTC5FniYuRBOK8(u"ࠫ࡮ࡶࡴࡷࠩሐ")					:XugxFprC26zGM(u"ࠬࡏࡐࡕࡘࠪሑ")
	,EX25Y0l8ILvz7QcRC(u"࠭ࡩࡱࡶࡹ࠱ࡱ࡯ࡶࡦࠩሒ")			:KW5bYS20wTF1LyCs9(u"ࠧࡊࡒࡗ่࡚ࠥๆ้ษอࠫሓ")
	,wY1p9mP03S8drbcH64t5WQkv(u"ࠨ࡫ࡳࡸࡻ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ሔ")			:jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡌࡔ࡙࡜ࠠฤใ็ห๊࠭ሕ")
	,wY1p9mP03S8drbcH64t5WQkv(u"ࠪ࡭ࡵࡺࡶ࠮ࡵࡨࡶ࡮࡫ࡳࠨሖ")			:QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡎࡖࡔࡗ่ࠢืู้ไศฬࠪሗ")
	,ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡱࡡࡳࡤࡤࡰࡦࡺࡶࠨመ")			:J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ๅ้ไ฼ࠤ็์วสࠢๆีอ๊วยࠩሙ")
	,I5bUBGpPXn0W6(u"ࠧ࡬ࡣࡷ࡯ࡴࡺࡴࡷࠩሚ")				:ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨ็๋ๆ฾ࠦใหๅ๋ฮࠥะ๊โ์ࠪማ")
	,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࡮ࡥࡹࡱ࡯ࡶࡶࡨࠫሜ")				:KW5bYS20wTF1LyCs9(u"้ࠪํู่ࠡๅอ็ํะࠧም")
	,ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡱࡧࡲࡰࡼࡤࠫሞ")				:t3coAp06zvHrTl49bUVgx(u"๋่ࠬใ฻่ࠣฬื่ำษࠪሟ")
	,S8i3sBYoHWdTURpAgN(u"࠭࡬ࡪࡤࡵࡥࡷࡿࠧሠ")				:CKUiyEe28zsZ(u"ࠧๆๆไࠫሡ")
	,XugxFprC26zGM(u"ࠨ࡮࡬ࡺࡪ࠭ሢ")					:ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩๅ๊ฬฯࠧሣ")
	,LTN6DPEmrwehtZMy(u"ࠪࡰ࡮ࡼࡥࡵࡸࠪሤ")				:KW5bYS20wTF1LyCs9(u"๊๊ࠫแࠨሥ")
	,wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡲ࡯ࡥࡻࡱࡩࡹ࠭ሦ")				:w2vjZmdJuY7c(u"࠭ๅ้ไ฼ࠤ้๎ฯ๋้ࠢฮࠬሧ")
	,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧ࡮࠵ࡸࠫረ")					:egY8Jti0smdLM3h1VQRSW(u"ࠨࡏ࠶࡙ࠬሩ")
	,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࡰ࠷ࡺ࠳࡬ࡪࡸࡨࠫሪ")				:I5bUBGpPXn0W6(u"ࠪࡑ࠸࡛ࠠใ่๋หฯ࠭ራ")
	,ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡲ࠹ࡵ࠮࡯ࡲࡺ࡮࡫ࡳࠨሬ")			:bP01xn84BiQN(u"ࠬࡓ࠳ࡖࠢฦๅ้อๅࠨር")
	,ilBWK5nXxg1do4jENGC07Zq(u"࠭࡭࠴ࡷ࠰ࡷࡪࡸࡩࡦࡵࠪሮ")			:RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡎ࠵ࡘࠤู๊ไิๆสฮࠬሯ")
	,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩሰ")				:GGn0oFgBITbethla4qXL9sfkdMZNPH(u"่ࠩๅ็๎ฯࠨሱ")
	,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪሲ")				:GGn0oFgBITbethla4qXL9sfkdMZNPH(u"๊ࠫ๎โฺ่ࠢ์ๆุࠠโ๊ิ๎ํ࠭ሳ")
	,Cp6c5tZe8I0PxnAW(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬሴ")				:HkiMU0QrdzW3l6gwnT(u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭ስ")
	,LyOR7f69iA(u"ࠧࡰ࡮ࡧࠫሶ")					:t3coAp06zvHrTl49bUVgx(u"ࠨไา๎๊࠭ሷ")
	,EX25Y0l8ILvz7QcRC(u"ࠩࡳࡥࡳ࡫ࡴࠨሸ")				:w2vjZmdJuY7c(u"้ࠪํู่ࠡสส๊๏ะࠧሹ")
	,egY8Jti0smdLM3h1VQRSW(u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡱࡴࡼࡩࡦࡵࠪሺ")			:LyOR7f69iA(u"๋่ࠬใ฻ࠣฬฬ์๊หࠢสๅ้อๅࠨሻ")
	,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡰࡢࡰࡨࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠬሼ")			:ehfEsaiJBSvbcULtNPVgykA2(u"ࠧๆ๊ๅ฽ࠥฮว็์อࠤู๊ไิๆสฮࠬሽ")
	,KQ3sCe9Pzh(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪሾ")				:Cp6c5tZe8I0PxnAW(u"่ࠩ์็฿ࠠีษ๊ำࠥ็่า์๋ࠫሿ")
	,egY8Jti0smdLM3h1VQRSW(u"ࠪࡷ࡭ࡧࡨࡪࡦࡱࡩࡼࡹࠧቀ")			:f90fGrlSEObDsuiA3U(u"๊ࠫ๎โฺࠢืห์ีࠠ็์๋ึࠬቁ")
	,egY8Jti0smdLM3h1VQRSW(u"ࠬࡹࡨࡪࡣࡹࡳ࡮ࡩࡥࠨቂ")			:XugxFprC26zGM(u"࠭ๅ้ไ฼ࠤฺ๎สࠡษ็ุ๏฿ษࠨቃ")
	,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡴࡪ࡬ࡥࡻࡵࡩࡤࡧ࠰ࡥࡱࡨࡵ࡮ࡵࠪቄ")		:jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ็๋ๆ฾ࠦี้ฬࠣหฺฺ้๊หࠣห้ฮ่ๆࠩቅ")
	,ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩ࠲ࡧࡵࡥ࡫ࡲࡷࠬቆ")		:bP01xn84BiQN(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠥ฻่ห์สฮࠬቇ")
	,ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡱࡧࡵࡷࡴࡴࡳࠨቈ")	:eNEhtuoi9gK8JaTpIXj(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠใษิสࠬ቉")
	,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡳࡩࡱࡩ࡬ࡦ࠭ቊ")				:iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧๆ๊ๅ฽ฺ่ࠥโ้สࠤฯ๐แ๋ࠩቋ")
	,f90fGrlSEObDsuiA3U(u"ࠨࡵ࡫ࡳࡴ࡬࡭ࡢࡺࠪቌ")				:EX25Y0l8ILvz7QcRC(u"่ࠩ์็฿ࠠี๊ไࠤ๊อใิࠩቍ")
	,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡷ࡭ࡵ࡯ࡧࡰࡨࡸࠬ቎")				:KKOXx3uWLqpTSahNUHiBF87PcZoe(u"๊ࠫ๎โฺࠢื์ๆࠦๆหࠩ቏")
	,NxXMrsTC5FniYuRBOK8(u"ࠬࡹࡨࡰࡱࡩࡴࡷࡵࠧቐ")				:Cp6c5tZe8I0PxnAW(u"࠭ๅ้ไ฼ࠤู๎แࠡสิ์ࠬቑ")
	,HkiMU0QrdzW3l6gwnT(u"ࠧࡵࡸࡩࡹࡳ࠭ቒ")				:f90fGrlSEObDsuiA3U(u"ࠨ็๋ๆ฾ࠦส๋ใํࠤๆอๆࠨቓ")
	,NxXMrsTC5FniYuRBOK8(u"ࠩࡹࡥࡷࡨ࡯࡯ࠩቔ")				:KQ3sCe9Pzh(u"้ࠪํู่ࠡใสีอ๎ๆࠨቕ")
	,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡻ࡯ࡤࡦࡱࠪቖ")				:XugxFprC26zGM(u"ࠬ็๊ะ์๋ࠫ቗")
	,XugxFprC26zGM(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭ቘ")				:egY8Jti0smdLM3h1VQRSW(u"ࠧๆ๊ๅ฽ࠥ๎๊ࠡีํ้ฬ࠭቙")
	,CKUiyEe28zsZ(u"ࠨࡻࡤࡵࡴࡺࠧቚ")				:jUcmHhgVvW0EdYOIfXeaDF(u"่ࠩ์็฿๋ࠠษๅ์ฯ࠭ቛ")
	,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫቜ")				:ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠩቝ")
	,HkiMU0QrdzW3l6gwnT(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨ቞")		:NxXMrsTC5FniYuRBOK8(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤ็์่ศฬࠪ቟")
	,CKUiyEe28zsZ(u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫበ")	:bP01xn84BiQN(u"ࠨ็๋ๆ฾๊้ࠦฬํ์อࠦโ้ษษ้ࠬቡ")
	,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠰ࡺ࡮ࡪࡥࡰࡵࠪቢ")		:HkiMU0QrdzW3l6gwnT(u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠡใํำ๏๎็ศฬࠪባ")
	,t3coAp06zvHrTl49bUVgx(u"ࠫࡾࡺࡢࡠࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪቤ")			:HkiMU0QrdzW3l6gwnT(u"๋่ࠬศไ฼ࠤ๏๎ส๋๊หࠫብ")
	}
	try: eCjMavt0mlhgB = WTlymR1DtfjcHqGUKF5YkZ2N[oh8Z06rUdqJ.lower()]
	except: eCjMavt0mlhgB = eHdDoxhJCEPMZFVa2fg
	return eCjMavt0mlhgB
def ZZoguXCt0Edzipr8R1G7yQsNnS3FVW():
	raise ValueError(ilBWK5nXxg1do4jENGC07Zq(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩቦ"))
def AOwqYZ30sN1Mp(VV8R9z1cZhD4b6pClMI,eKG9F3yZXvRn051OuMWIw=eHdDoxhJCEPMZFVa2fg):
	global N1vK7PznWC6ka
	N1vK7PznWC6ka = YchIv6N09BaWPEj4tieAnluKZrRXT
	if not eKG9F3yZXvRn051OuMWIw and VV8R9z1cZhD4b6pClMI: eKG9F3yZXvRn051OuMWIw = LTN6DPEmrwehtZMy(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨቧ")
	MoO74hKeqm8fFka.setSetting(t3coAp06zvHrTl49bUVgx(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬቨ"),eKG9F3yZXvRn051OuMWIw)
	return
def vFDQstemyYANa(FeTJrG4SkMf09iVys8A,AdlI9LbzMYWGeZjOHsXSCo=KQ3sCe9Pzh(u"ࠩ࠽࠳ࠬቩ")):
	return _LYbmcMgweaJdxriZ4No56US9CjVOp(FeTJrG4SkMf09iVys8A,AdlI9LbzMYWGeZjOHsXSCo)
def NOxa7SXgrAhQyRjf21TzYL4M0(tkO4UJRvnMqS29mIs56GzTDP):
	if tkO4UJRvnMqS29mIs56GzTDP in [eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠪ࠴ࠬቪ"),x1Oa8bBf36EwsLMirtFc]: return eHdDoxhJCEPMZFVa2fg
	tkO4UJRvnMqS29mIs56GzTDP = int(tkO4UJRvnMqS29mIs56GzTDP)
	Vs0YoWuv26lECeIL1 = tkO4UJRvnMqS29mIs56GzTDP^c4cPSX2jOIm8KCQlfW5wM
	FDeUbdfxY35l6W7Js4Nc8nO = tkO4UJRvnMqS29mIs56GzTDP^bbfreYhcgwZlKEGVx7zRU
	nFspgtmrfTMK5Dx = tkO4UJRvnMqS29mIs56GzTDP^srU0Sl1oOC29FB6gHTYX
	eCjMavt0mlhgB = str(Vs0YoWuv26lECeIL1)+str(FDeUbdfxY35l6W7Js4Nc8nO)+str(nFspgtmrfTMK5Dx)
	return eCjMavt0mlhgB
def YYfkqCeyl6BrHPiDuF47(tkO4UJRvnMqS29mIs56GzTDP):
	if tkO4UJRvnMqS29mIs56GzTDP in [eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠫ࠵࠭ቫ"),x1Oa8bBf36EwsLMirtFc]: return eHdDoxhJCEPMZFVa2fg
	tkO4UJRvnMqS29mIs56GzTDP = str(tkO4UJRvnMqS29mIs56GzTDP)
	eCjMavt0mlhgB = eHdDoxhJCEPMZFVa2fg
	if len(tkO4UJRvnMqS29mIs56GzTDP)==J7divaGOCgq2SLfXpDzZYN58wc(u"࠴࠹ᐱ"):
		Vs0YoWuv26lECeIL1,FDeUbdfxY35l6W7Js4Nc8nO,nFspgtmrfTMK5Dx = tkO4UJRvnMqS29mIs56GzTDP[x1Oa8bBf36EwsLMirtFc:BSw5mizCOsKxWrRDvtJuFajY],tkO4UJRvnMqS29mIs56GzTDP[BSw5mizCOsKxWrRDvtJuFajY:egY8Jti0smdLM3h1VQRSW(u"࠽ᐲ")],tkO4UJRvnMqS29mIs56GzTDP[egY8Jti0smdLM3h1VQRSW(u"࠽ᐲ"):]
		Vs0YoWuv26lECeIL1 = int(Vs0YoWuv26lECeIL1)^srU0Sl1oOC29FB6gHTYX
		FDeUbdfxY35l6W7Js4Nc8nO = int(FDeUbdfxY35l6W7Js4Nc8nO)^bbfreYhcgwZlKEGVx7zRU
		nFspgtmrfTMK5Dx = int(nFspgtmrfTMK5Dx)^c4cPSX2jOIm8KCQlfW5wM
		if Vs0YoWuv26lECeIL1==FDeUbdfxY35l6W7Js4Nc8nO==nFspgtmrfTMK5Dx: eCjMavt0mlhgB = str(Vs0YoWuv26lECeIL1*QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠻࠶ᐳ"))
	return eCjMavt0mlhgB
def VarSZWbo4B6y3htcxuifmD9FYqnLvp(tkO4UJRvnMqS29mIs56GzTDP,Y7UvCTznAZHacg10KIyNl=NxXMrsTC5FniYuRBOK8(u"ࠬ࠼࠳࠹࠶࠴࠼࠷࠹ࠧቬ")):
	if tkO4UJRvnMqS29mIs56GzTDP==eHdDoxhJCEPMZFVa2fg: return eHdDoxhJCEPMZFVa2fg
	tkO4UJRvnMqS29mIs56GzTDP = int(tkO4UJRvnMqS29mIs56GzTDP)+int(Y7UvCTznAZHacg10KIyNl)
	Vs0YoWuv26lECeIL1 = tkO4UJRvnMqS29mIs56GzTDP^c4cPSX2jOIm8KCQlfW5wM
	FDeUbdfxY35l6W7Js4Nc8nO = tkO4UJRvnMqS29mIs56GzTDP^bbfreYhcgwZlKEGVx7zRU
	nFspgtmrfTMK5Dx = tkO4UJRvnMqS29mIs56GzTDP^srU0Sl1oOC29FB6gHTYX
	eCjMavt0mlhgB = str(Vs0YoWuv26lECeIL1)+str(FDeUbdfxY35l6W7Js4Nc8nO)+str(nFspgtmrfTMK5Dx)
	return eCjMavt0mlhgB
def txpHLlmaGzNqcTYWPoeS3MK5F8k(tkO4UJRvnMqS29mIs56GzTDP,Y7UvCTznAZHacg10KIyNl=QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࠶࠴࠺࠷࠵࠽࠸࠳ࠨቭ")):
	if tkO4UJRvnMqS29mIs56GzTDP==eHdDoxhJCEPMZFVa2fg: return eHdDoxhJCEPMZFVa2fg
	tkO4UJRvnMqS29mIs56GzTDP = str(tkO4UJRvnMqS29mIs56GzTDP)
	ZwQ23eJ6vt = int(len(tkO4UJRvnMqS29mIs56GzTDP)/bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1)
	Vs0YoWuv26lECeIL1 = int(tkO4UJRvnMqS29mIs56GzTDP[x1Oa8bBf36EwsLMirtFc:ZwQ23eJ6vt])^c4cPSX2jOIm8KCQlfW5wM
	FDeUbdfxY35l6W7Js4Nc8nO = int(tkO4UJRvnMqS29mIs56GzTDP[ZwQ23eJ6vt:FB0pIzAoK8wqgd3UiY5*ZwQ23eJ6vt])^bbfreYhcgwZlKEGVx7zRU
	nFspgtmrfTMK5Dx = int(tkO4UJRvnMqS29mIs56GzTDP[FB0pIzAoK8wqgd3UiY5*ZwQ23eJ6vt:bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1*ZwQ23eJ6vt])^srU0Sl1oOC29FB6gHTYX
	eCjMavt0mlhgB = eHdDoxhJCEPMZFVa2fg
	if Vs0YoWuv26lECeIL1==FDeUbdfxY35l6W7Js4Nc8nO==nFspgtmrfTMK5Dx: eCjMavt0mlhgB = str(int(Vs0YoWuv26lECeIL1)-int(Y7UvCTznAZHacg10KIyNl))
	return eCjMavt0mlhgB
def F2FQEqPicybxmHgIN(VZ6JH90iKsljnkgGm5e):
	uQPbpBte8rwJz = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[KW5bYS20wTF1LyCs9(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧቮ")][CKUiyEe28zsZ(u"࠾ᐴ")]
	DMWHA01nGbSVOfoLIdZPUyts3Q = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫቯ"),w2vjZmdJuY7c(u"ࠩࡶ࡯࡮ࡴࡳࠨተ"),f90fGrlSEObDsuiA3U(u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࠫቱ"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࠼࠸࠰ࡱࠩቲ"),LyOR7f69iA(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡈࡵ࡮ࡧ࡫ࡵࡱ࡙࡮ࡲࡦࡧࡅࡹࡹࡺ࡯࡯ࡵ࠱ࡼࡲࡲࠧታ"))
	qE09LpObUJDKQs,w1xT5cK2dBk = tSCWKXTbwog4L(DMWHA01nGbSVOfoLIdZPUyts3Q)
	qE09LpObUJDKQs = VarSZWbo4B6y3htcxuifmD9FYqnLvp(qE09LpObUJDKQs,egY8Jti0smdLM3h1VQRSW(u"࠭࠱࠳࠳࠻࠷࠶࠾࠵࠴ࠩቴ"))
	thlCN7zF8u = {ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡪࡦࡶࠫት"):ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡆࡌࡅࡑࡕࡇࠨቶ"),bP01xn84BiQN(u"ࠩࡸࡷࡷ࠭ቷ"):ZylBO1ktRGvdJ0,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡺࡪࡸࠧቸ"):MCrWtwnF2TViZOD7z0pXgqI4,NxXMrsTC5FniYuRBOK8(u"ࠫࡸࡩࡲࠨቹ"):VZ6JH90iKsljnkgGm5e,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡹࡩࡻࠩቺ"):qE09LpObUJDKQs}
	AleHRd4V7DsvMFXf0 = {ietolwsjpIPK7Fr(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬቻ"):KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭ቼ")}
	GnEt0qhWr82UjlsXTc9Q4 = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,ietolwsjpIPK7Fr(u"ࠨࡒࡒࡗ࡙࠭ች"),uQPbpBte8rwJz,thlCN7zF8u,AleHRd4V7DsvMFXf0,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡗࡍࡕࡗࡠࡒࡏࡅ࡞ࡥࡄࡊࡃࡏࡓࡌ࠳࠱ࡴࡶࠪቾ"))
	EafPgv7ixFdZyW9j0 = GnEt0qhWr82UjlsXTc9Q4.content
	try:
		if not EafPgv7ixFdZyW9j0: DcudCy8jWbXh2wgTeIqONfkHLQ
		mQ96EZhKJjALpUS0nXFed47klM = DIpuHqsKGS3ErJvk9taCRiX80(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡨ࡮ࡩࡴࠨቿ"),EafPgv7ixFdZyW9j0)
		jD6mGty3wK = mQ96EZhKJjALpUS0nXFed47klM[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡲࡹࡧࠨኀ")]
		Q9YO46fnLdMkgh0aIUKyei = mQ96EZhKJjALpUS0nXFed47klM[ietolwsjpIPK7Fr(u"ࠬࡹࡥࡤࠩኁ")]
		TpOnwFs8hbt = mQ96EZhKJjALpUS0nXFed47klM[Cp6c5tZe8I0PxnAW(u"࠭ࡳࡵࡲࠪኂ")]
		Q9YO46fnLdMkgh0aIUKyei = int(txpHLlmaGzNqcTYWPoeS3MK5F8k(Q9YO46fnLdMkgh0aIUKyei,LyOR7f69iA(u"ࠧ࠲࠴࠴࠼࠸࠷࠸࠶࠵ࠪኃ")))
		TpOnwFs8hbt = int(txpHLlmaGzNqcTYWPoeS3MK5F8k(TpOnwFs8hbt,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫኄ")))
		for mXi91dI2LysZFcEwY05RCtN7k in range(Q9YO46fnLdMkgh0aIUKyei,x1Oa8bBf36EwsLMirtFc,-TpOnwFs8hbt):
			if not eval(Cp6c5tZe8I0PxnAW(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࡛࡯ࡤࡦࡱࠫ࠭ࠬኅ"),{ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡼࡧࡳࡣࠨኆ"):ccwRLKk3hs0E}): DcudCy8jWbXh2wgTeIqONfkHLQ
			dqKGMYgJxSF8Ub1kotlsP936Ww7B(LTN6DPEmrwehtZMy(u"ࠫออโ๋ࠢ็่ฯาัษหࠣ์ฬ๊แฮืࠪኇ"),str(mXi91dI2LysZFcEwY05RCtN7k)+egY8Jti0smdLM3h1VQRSW(u"ࠬࠦࠠฬษ้๎ฮ࠭ኈ"),b8bLFaejUB=dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠳࠱࠲ᐵ")*TpOnwFs8hbt)
			ccwRLKk3hs0E.sleep(w2vjZmdJuY7c(u"࠲࠲࠳࠴ᐶ")*TpOnwFs8hbt)
		if eval(f90fGrlSEObDsuiA3U(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࡘ࡬ࡨࡪࡵࠨࠪࠩ኉"),{TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡹࡤࡰࡧࠬኊ"):ccwRLKk3hs0E}):
			jD6mGty3wK = jD6mGty3wK.replace(kDUv7ouWrcgMe6OipQJm,S8i3sBYoHWdTURpAgN(u"ࠨ࡞࡟ࡲࠬኋ")).replace(y1fVB2E63aLnJgkWeCZHujY,ilBWK5nXxg1do4jENGC07Zq(u"ࠩ࡟ࡠࡷ࠭ኌ"))
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪาึ๎ฬࠨኍ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ኎"),jD6mGty3wK)
		DcudCy8jWbXh2wgTeIqONfkHLQ
	except: exec(S8i3sBYoHWdTURpAgN(u"ࠬࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ኏"),{HkiMU0QrdzW3l6gwnT(u"࠭ࡸࡣ࡯ࡦࠫነ"):ccwRLKk3hs0E})
	return
def ddRIn8cZ1GyW4LqBN():
	exec(KW5bYS20wTF1LyCs9(u"ࠧࠨࠩࠐࠎࡹࡸࡹ࠻ࠏࠍࠍࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹ࠠ࠾ࠢࡻࡦࡲࡩࡧࡶ࡫࠱࡛࡮ࡴࡤࡰࡹࠫ࠵࠵࠶࠲࠶ࠫࠐࠎࠎࡽࡨࡪ࡮ࡨࠤࡦࡼࡢࡰࡱ࡯ࡩࡦࡴࡳࡵࡴࡸࡩ࠿ࠓࠊࠊࠋࡻࡦࡲࡩ࠮ࡴ࡮ࡨࡩࡵ࠮࠱࠱࠲࠳࠭ࠒࠐࠉࠊࡶࡵࡽ࠿ࠦࡷࡪࡰࡧࡳࡼ࠷࠲࠴࠰ࡪࡩࡹࡌ࡯ࡤࡷࡶࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡤࡵࡩࡦࡱࠍࠋࠋࡽࡧࡷ࡫ࡡࡵࡧࡢࡩࡷࡵࡲࡳࠏࠍࡩࡽࡩࡥࡱࡶ࠽ࠤࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡸࡺ࡯ࡱࠪࠬࠑࠏ࠭ࠧࠨኑ"),{I5bUBGpPXn0W6(u"ࠨࡺࡥࡱࡨ࡭ࡵࡪࠩኒ"):VVZgPQ2kYLoKe6jic5AEzqupG,HkiMU0QrdzW3l6gwnT(u"ࠩࡻࡦࡲࡩࠧና"):ccwRLKk3hs0E})
	return
def tSCWKXTbwog4L(aNocw8R7zKPnyAfrF5vV1mp4DSlYM):
	UlRHxvXC3bD2dJi8,ZlJIRM4voWapmOU8ykibgT5D1cd = x1Oa8bBf36EwsLMirtFc,x1Oa8bBf36EwsLMirtFc
	if RRydns1CErYlIhwSx7.path.exists(aNocw8R7zKPnyAfrF5vV1mp4DSlYM):
		try: UlRHxvXC3bD2dJi8 = RRydns1CErYlIhwSx7.path.getsize(aNocw8R7zKPnyAfrF5vV1mp4DSlYM)
		except: pass
		if not UlRHxvXC3bD2dJi8:
			try: UlRHxvXC3bD2dJi8 = RRydns1CErYlIhwSx7.stat(aNocw8R7zKPnyAfrF5vV1mp4DSlYM).st_size
			except: pass
		if not UlRHxvXC3bD2dJi8:
			try:
				from pathlib import Path as TZJsxM1UbpQ
				UlRHxvXC3bD2dJi8 = TZJsxM1UbpQ(aNocw8R7zKPnyAfrF5vV1mp4DSlYM).stat().st_size
			except: pass
		if UlRHxvXC3bD2dJi8: ZlJIRM4voWapmOU8ykibgT5D1cd = NSudqlOzja
	return UlRHxvXC3bD2dJi8,ZlJIRM4voWapmOU8ykibgT5D1cd
def ycgRbjNoPLQSnx(qSm6YO4tbzvBo02esflA5ZJGpc,IU2zyr1FA4ao5SdgkxMWGHjXqQevl,showDialogs):
	if showDialogs:
		zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ኔ"),qSm6YO4tbzvBo02esflA5ZJGpc+LyOR7f69iA(u"ࠫࡡࡴ࡜࡯ࠩን")+SbyWQGMDnV+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่ะ้ีࠠภࠣࠪኖ")+Nat0Dx9puRUWCsgz6JyFhY3)
		if zf7iFX1auw0bQU!=NSudqlOzja: return
	ACbjkvGL7Udh4RuToXPmeFVy = rDceXBpHkfVUYRJ3tIx95Z
	if RRydns1CErYlIhwSx7.path.exists(qSm6YO4tbzvBo02esflA5ZJGpc):
		for LLFAhzJsub5,Cr9fechZPyT0bNxmzvRk,FefZKgxmYVLjkWN4yhod79 in RRydns1CErYlIhwSx7.walk(qSm6YO4tbzvBo02esflA5ZJGpc,topdown=rDceXBpHkfVUYRJ3tIx95Z):
			for aNocw8R7zKPnyAfrF5vV1mp4DSlYM in FefZKgxmYVLjkWN4yhod79:
				x98xK06O7rpdTwPI2jQAgZV = RRydns1CErYlIhwSx7.path.join(LLFAhzJsub5,aNocw8R7zKPnyAfrF5vV1mp4DSlYM)
				try: RRydns1CErYlIhwSx7.remove(x98xK06O7rpdTwPI2jQAgZV)
				except Exception as IsHj3gPMl06:
					if showDialogs and not ACbjkvGL7Udh4RuToXPmeFVy: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩኗ"),str(IsHj3gPMl06))
					ACbjkvGL7Udh4RuToXPmeFVy = YchIv6N09BaWPEj4tieAnluKZrRXT
			if IU2zyr1FA4ao5SdgkxMWGHjXqQevl:
				for dir in Cr9fechZPyT0bNxmzvRk:
					RLDMZP5egEVtaIdzyX2KQwjlcU = RRydns1CErYlIhwSx7.path.join(LLFAhzJsub5,dir)
					try: RRydns1CErYlIhwSx7.rmdir(RLDMZP5egEVtaIdzyX2KQwjlcU)
					except: pass
		if IU2zyr1FA4ao5SdgkxMWGHjXqQevl:
			try: RRydns1CErYlIhwSx7.rmdir(LLFAhzJsub5)
			except: pass
	if showDialogs and not ACbjkvGL7Udh4RuToXPmeFVy:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪኘ"),bP01xn84BiQN(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩኙ"))
		AOwqYZ30sN1Mp(rDceXBpHkfVUYRJ3tIx95Z)
	return
def FRPXKYtorIBuMJkZp(pw9fgsSRmnKId80YbU1PA=eHdDoxhJCEPMZFVa2fg):
	if pw9fgsSRmnKId80YbU1PA:
		if dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬኚ") in pw9fgsSRmnKId80YbU1PA: vR9cOpMtk51j(eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ኛ"))
		else:
			UqZNbxJRlo1re9yYjSVvkIf = MoO74hKeqm8fFka.getSetting(eNEhtuoi9gK8JaTpIXj(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬኜ"))
			MoO74hKeqm8fFka.setSetting(Cp6c5tZe8I0PxnAW(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭ኝ"),eHdDoxhJCEPMZFVa2fg)
			CCq2PhsRVwMmeL4YpcE7QxaWjoAlv(pw9fgsSRmnKId80YbU1PA)
			MoO74hKeqm8fFka.setSetting(CKUiyEe28zsZ(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧኞ"),UqZNbxJRlo1re9yYjSVvkIf)
	mOoylMuTX7VUjNJq6YK4(NxXMrsTC5FniYuRBOK8(u"ࠧࡴࡶࡲࡴࠬኟ"))
	hy985bf3gkpaz2Q076dvAoDjFxi = MoO74hKeqm8fFka.getSetting(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬአ"))
	if hy985bf3gkpaz2Q076dvAoDjFxi==egY8Jti0smdLM3h1VQRSW(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡢࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪኡ"): MoO74hKeqm8fFka.setSetting(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧኢ"),KW5bYS20wTF1LyCs9(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫኣ"))
	elif hy985bf3gkpaz2Q076dvAoDjFxi==LyOR7f69iA(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬኤ"): MoO74hKeqm8fFka.setSetting(LyOR7f69iA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪእ"),eHdDoxhJCEPMZFVa2fg)
	if MoO74hKeqm8fFka.getSetting(Cp6c5tZe8I0PxnAW(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪኦ")) not in [KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡃࡘࡘࡔ࠭ኧ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡖࡘࡔࡖࠧከ"),CKUiyEe28zsZ(u"ࠪࡅࡘࡑࠧኩ")]: MoO74hKeqm8fFka.setSetting(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡨࡳࡹࠧኪ"),ietolwsjpIPK7Fr(u"ࠬࡇࡓࡌࠩካ"))
	if MoO74hKeqm8fFka.getSetting(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫኬ")) not in [RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡂࡗࡗࡓࠬክ"),NxXMrsTC5FniYuRBOK8(u"ࠨࡕࡗࡓࡕ࠭ኮ"),CKUiyEe28zsZ(u"ࠩࡄࡗࡐ࠭ኯ")]: MoO74hKeqm8fFka.setSetting(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨኰ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡆ࡙ࡋࠨ኱"))
	SlrwkhXv4QePoxDst = MoO74hKeqm8fFka.getSetting(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡧࡶ࠯࡯ࡼࡷࡰ࡯࡮࠯ࡸ࡬ࡩࡼࡳ࡯ࡥࡧࠪኲ"))
	SjmNBbHlIezGr2URoEp3f = ccwRLKk3hs0E.executeJSONRPC(RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡰࡴࡵ࡫ࡢࡰࡧࡪࡪ࡫࡬࠯ࡵ࡮࡭ࡳࠨࡽࡾࠩኳ"))
	if egY8Jti0smdLM3h1VQRSW(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ኴ") in str(SjmNBbHlIezGr2URoEp3f) and SlrwkhXv4QePoxDst in [S8i3sBYoHWdTURpAgN(u"ࠨࡇࡐࡅࡉࠦࡌࡪࡵࡷࠫኵ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡈࡑࡆࡊࠠࡈࡣ࡯ࡰࡪࡸࡹࠨ኶")]:
		b8bLFaejUB.sleep(w2vjZmdJuY7c(u"࠲࠱࠵࠵࠶ᐷ"))
		ccwRLKk3hs0E.executebuiltin(I5bUBGpPXn0W6(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡓࡦࡶ࡙࡭ࡪࡽࡍࡰࡦࡨࠬ࠵࠯ࠧ኷"))
	if x1Oa8bBf36EwsLMirtFc and ZFsK7DtIkrHGnWQYhUM8P>-NSudqlOzja:
		bCfjxP8yo4Qn3trXKNgW1AUl.setResolvedUrl(ZFsK7DtIkrHGnWQYhUM8P,rDceXBpHkfVUYRJ3tIx95Z,VVZgPQ2kYLoKe6jic5AEzqupG.ListItem())
		gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX = rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z
		bCfjxP8yo4Qn3trXKNgW1AUl.endOfDirectory(ZFsK7DtIkrHGnWQYhUM8P,gZdOM2jYEfV,gp9QOLWo4ICu8vPXfFlVK0RM16,jgDRUY9SVkhmX)
	return
def KRSoWMhk08fzBe(JEvXRNInqCF,tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Oyg3pZGAHdws7RWm4e6S):
	E1Viom5L3684CTOFJ,O3m8areAPTfgLbXts,GGyD8Bnmuv49whkr5FzQ3qJIZxoesp,fntdCl29AwQROPKvj = dfqLZkHznMvtIoBpFaQx6Nb(FeTJrG4SkMf09iVys8A)
	KKeiYLQO4vH3yskhbG = tWILFaVZ5E6rdoRXNGApOiJ3Ss0,E1Viom5L3684CTOFJ,KhGpZcMqsnrbv,kkMFwqXnC9v0y
	if JEvXRNInqCF:
		a3glxPAGFXm2kzq = EeZHTwQUW2BuvJyIh(pyifuNFdxe,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡸࡺࡲࠨኸ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ኹ"),KKeiYLQO4vH3yskhbG)
		if a3glxPAGFXm2kzq:
			NEI8AGXDS73KmBvT54o6L(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡕࡓࡎࡏࡍࡇࠦࠠࡓࡇࡄࡈࡤࡉࡁࡄࡊࡈࠫኺ"),FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Oyg3pZGAHdws7RWm4e6S,tWILFaVZ5E6rdoRXNGApOiJ3Ss0)
			return a3glxPAGFXm2kzq
	a3glxPAGFXm2kzq = JPm1l6479KjXST0(tWILFaVZ5E6rdoRXNGApOiJ3Ss0,FeTJrG4SkMf09iVys8A,KhGpZcMqsnrbv,kkMFwqXnC9v0y,Oyg3pZGAHdws7RWm4e6S)
	if a3glxPAGFXm2kzq and JEvXRNInqCF: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,w2vjZmdJuY7c(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨኻ"),KKeiYLQO4vH3yskhbG,a3glxPAGFXm2kzq,JEvXRNInqCF)
	return a3glxPAGFXm2kzq
from gw6D0vkHNp import *
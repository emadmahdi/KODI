# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'DAILYMOTION'
r07r9xeEFASJXluImT = '_DLM_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][1]
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text,type,clAzmREWwXf6Gk):
	if	 mode==400: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==401: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = QXUtxErob3m(url,text)
	elif mode==402: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bE5OdGmi9TaxgelRfBA0upty3S(url,text)
	elif mode==403: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url,text)
	elif mode==404: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = P1kMIba5xKhjZW6cHozUmirn8V(text,clAzmREWwXf6Gk)
	elif mode==405: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = WAQ0yLVDYNZJST2(text,clAzmREWwXf6Gk)
	elif mode==406: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = DnhyKEwkjGB8Ou9JpfYC6g(text,clAzmREWwXf6Gk)
	elif mode==407: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = OOKkUtMg8EYAW(url,clAzmREWwXf6Gk)
	elif mode==408: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = BmNWI4MacRSsZUJYwz(url,clAzmREWwXf6Gk)
	elif mode==409: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text,clAzmREWwXf6Gk)
	elif mode==411: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = iRwjF6yPv1Sld9xmfKuIYH8t5Wq(url,text)
	elif mode==414: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZgYo4cprsnG9N(text)
	elif mode==415: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zcJuRB04MtlQhYqI(text,clAzmREWwXf6Gk)
	elif mode==416: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = eJDvGtKbE17jl5i94X8gVW(text,clAzmREWwXf6Gk)
	elif mode==417: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = Gjswx4bAt1LKY(url,clAzmREWwXf6Gk)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الرئيسية',eHdDoxhJCEPMZFVa2fg,414)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن فيديوهات',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'videos?sortBy=','_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن آخر الفيديوهات',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن الفيديوهات الأكثر مشاهدة',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن قوائم التشغيل',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'playlists','_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن مستخدم',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'channels','_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن بث حي',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'lives','_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث عن هاشتاك',eHdDoxhJCEPMZFVa2fg,409,eHdDoxhJCEPMZFVa2fg,'hashtags','_REMEMBERRESULTS_')
	return
def bE5OdGmi9TaxgelRfBA0upty3S(url,dEQ6I4ixalFU):
	if '/dm_' in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,False,eHdDoxhJCEPMZFVa2fg,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = aP8bLqZJsQlH3ivWKc.headers
		if 'Location' in list(headers.keys()): url = q3QVhZaDEuo8t2ASj5vkn+headers['Location']
	dEQ6I4ixalFU = SbyWQGMDnV+dEQ6I4ixalFU+Nat0Dx9puRUWCsgz6JyFhY3
	dEQ6I4ixalFU = hmKJ0MUI6nyZQCRD37E1kscHWxl8(dEQ6I4ixalFU)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: بث حي',url,411,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'channel_lives_now')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: آخر الفيديوهات',url+'/videos',408)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: المميزة',url,411,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'channel_featured_videos')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: قوائم التشغيل',url+'/playlists',407)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+':: قنوات ذات صلة',url,411,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'channel_related_channel')
	return
def hmKJ0MUI6nyZQCRD37E1kscHWxl8(title):
	title = title.rstrip('\\').strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace('\\\\','\\')
	title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
	return title
def bbmQeYGSTIv(url,lPbeIkcm9Ows2U54NhGFL):
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA([url],EERWJf1adv67,'video',url)
	return
def P1kMIba5xKhjZW6cHozUmirn8V(search,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = eHdDoxhJCEPMZFVa2fg
	search = search.split('/videos')[0]
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysearchwords',search)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	if sort==eHdDoxhJCEPMZFVa2fg: mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysortmethod',eHdDoxhJCEPMZFVa2fg)
	else: mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'/videos'
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"videos"(.*?)"VideoConnection"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for id,title,l93v15ds7keEcOMjxVK6bh,dEQ6I4ixalFU,WWPgm9fvlH2oIOnrD1,PeLqCN5Ek8bB in items:
			if '"' in id: id = id.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in title: title = title.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in l93v15ds7keEcOMjxVK6bh: l93v15ds7keEcOMjxVK6bh = l93v15ds7keEcOMjxVK6bh.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in dEQ6I4ixalFU: dEQ6I4ixalFU = dEQ6I4ixalFU.replace('"',eHdDoxhJCEPMZFVa2fg)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+id
			title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
			lPbeIkcm9Ows2U54NhGFL = l93v15ds7keEcOMjxVK6bh+'::'+dEQ6I4ixalFU
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1,lPbeIkcm9Ows2U54NhGFL)
		if '"hasNextPage":true' in nR2B1Wye7luXb5:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,404,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,search)
	return
def WAQ0yLVDYNZJST2(search,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysearchwords',search)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'/playlists'
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search)
	items = cBawilJXvK1m.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for id,name,AfPeUOmzRlWuZq9QVTnk7C,l93v15ds7keEcOMjxVK6bh,dEQ6I4ixalFU,PeLqCN5Ek8bB,count in items:
		if '"' in AfPeUOmzRlWuZq9QVTnk7C: AfPeUOmzRlWuZq9QVTnk7C = AfPeUOmzRlWuZq9QVTnk7C.replace('"',eHdDoxhJCEPMZFVa2fg)
		if '"' in l93v15ds7keEcOMjxVK6bh: l93v15ds7keEcOMjxVK6bh = l93v15ds7keEcOMjxVK6bh.replace('"',eHdDoxhJCEPMZFVa2fg)
		if '"' in dEQ6I4ixalFU: dEQ6I4ixalFU = dEQ6I4ixalFU.replace('"',eHdDoxhJCEPMZFVa2fg)
		if '"' in id: id = id.replace('"',eHdDoxhJCEPMZFVa2fg)
		if '"' in name: name = name.replace('"',eHdDoxhJCEPMZFVa2fg)
		if '"' in PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('"',eHdDoxhJCEPMZFVa2fg)
		if '"' in count: count = count.replace('"',eHdDoxhJCEPMZFVa2fg)
		apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
		lPbeIkcm9Ows2U54NhGFL = l93v15ds7keEcOMjxVK6bh+'::'+dEQ6I4ixalFU
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,401,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,lPbeIkcm9Ows2U54NhGFL)
	if '"hasNextPage":true' in nR2B1Wye7luXb5:
		clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,405,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,search)
	return
def DnhyKEwkjGB8Ou9JpfYC6g(search,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysearchwords',search)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'/channels'
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"channels"(.*?)"ChannelConnection"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for id,name,PeLqCN5Ek8bB in items:
			if '"' in id: id = id.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in name: name = name.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('"',eHdDoxhJCEPMZFVa2fg)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+id
			title = 'USER:  '+name
			title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,402,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,name)
		if '"hasNextPage":true' in nR2B1Wye7luXb5:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,406,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,search)
	return
def ZgYo4cprsnG9N(vKOrY5HfLkbGVXmFq):
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	zULDufV4d3mQ = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	if zULDufV4d3mQ:
		LLhisn1IxoAHc8KRDj = DIpuHqsKGS3ErJvk9taCRiX80('dict',zULDufV4d3mQ)
		ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = LLhisn1IxoAHc8KRDj['data']['home']['neon']['sections']['edges']
		if not vKOrY5HfLkbGVXmFq:
			tKdPL1Y96UqgryEAzxBWcwGOas = []
			for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
				RBHSwGignYmu2 = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['title']
				if RBHSwGignYmu2 not in tKdPL1Y96UqgryEAzxBWcwGOas: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+RBHSwGignYmu2,eHdDoxhJCEPMZFVa2fg,414,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,RBHSwGignYmu2)
				tKdPL1Y96UqgryEAzxBWcwGOas.append(RBHSwGignYmu2)
		else:
			for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
				RBHSwGignYmu2 = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['title']
				if RBHSwGignYmu2==vKOrY5HfLkbGVXmFq:
					TMvbixoJ7ztLpc45Dw0EYVgR = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['components']['edges']
					for AHS7zisPk20 in TMvbixoJ7ztLpc45Dw0EYVgR:
						WWPgm9fvlH2oIOnrD1 = str(AHS7zisPk20['node']['duration'])
						title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(AHS7zisPk20['node']['title'])
						title = title.replace('\/','/')
						Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = AHS7zisPk20['node']['xid']
						PeLqCN5Ek8bB = AHS7zisPk20['node']['thumbnailx480']
						PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('\/','/')
						apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
						qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
	return
def zcJuRB04MtlQhYqI(search,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysearchwords',search)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'/lives'
	zULDufV4d3mQ = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search)
	if zULDufV4d3mQ:
		LLhisn1IxoAHc8KRDj = DIpuHqsKGS3ErJvk9taCRiX80('dict',zULDufV4d3mQ)
		try: ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = LLhisn1IxoAHc8KRDj['data']['search']['lives']['edges']
		except: ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = []
		for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
			name = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['title']
			name = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(name)
			Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['xid']
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
			qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+'LIVE: '+name,apOKrFbP9IYHDyUVm7,403)
		if '"hasNextPage":true' in zULDufV4d3mQ:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,415,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,search)
	return
def T54ZWbxhHvJIpKYqwjR(search,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysearchwords',search)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'/topics'
	zULDufV4d3mQ = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search)
	if zULDufV4d3mQ:
		LLhisn1IxoAHc8KRDj = DIpuHqsKGS3ErJvk9taCRiX80('dict',zULDufV4d3mQ)
		try: ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = LLhisn1IxoAHc8KRDj['data']['search']['topics']['edges']
		except: ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = []
		for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
			name = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['name']
			Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['xid']
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/topic/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'TOPIC: '+name,apOKrFbP9IYHDyUVm7,413)
		if '"hasNextPage":true' in zULDufV4d3mQ:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,412,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,search)
	return
def j8lFWoITS5c1V6U7H(url,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = url.split('/')[-1]
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mytopicid',Yuq9jeGaUL4zVTEFcfkmxDAPvhJ)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	zULDufV4d3mQ = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	if zULDufV4d3mQ:
		LLhisn1IxoAHc8KRDj = DIpuHqsKGS3ErJvk9taCRiX80('dict',zULDufV4d3mQ)
		ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = LLhisn1IxoAHc8KRDj['data']['topic']['videos']['edges']
		for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
			WWPgm9fvlH2oIOnrD1 = str(d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['duration'])
			title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['title'])
			title = title.replace('\/','/')
			Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['xid']
			PeLqCN5Ek8bB = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['thumbnailx480']
			PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('\/','/')
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
		if '"hasNextPage":true' in zULDufV4d3mQ:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,413,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk)
	return
def QXUtxErob3m(url,lPbeIkcm9Ows2U54NhGFL):
	id = url.split('/')[-1]
	l93v15ds7keEcOMjxVK6bh,dEQ6I4ixalFU = lPbeIkcm9Ows2U54NhGFL.split('::',1)
	apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+l93v15ds7keEcOMjxVK6bh
	dEQ6I4ixalFU = hmKJ0MUI6nyZQCRD37E1kscHWxl8(dEQ6I4ixalFU)
	title = '[COLOR FFC89008]OWNER:  '+dEQ6I4ixalFU+Nat0Dx9puRUWCsgz6JyFhY3
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,402,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEQ6I4ixalFU)
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('myplaylistid',id)
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"collection_videos"(.*?)"SectionEdge"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for id,title,WWPgm9fvlH2oIOnrD1,PeLqCN5Ek8bB,l93v15ds7keEcOMjxVK6bh,dEQ6I4ixalFU in items:
			if '"' in id: id = id.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in title: title = title.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in l93v15ds7keEcOMjxVK6bh: l93v15ds7keEcOMjxVK6bh = l93v15ds7keEcOMjxVK6bh.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in dEQ6I4ixalFU: dEQ6I4ixalFU = dEQ6I4ixalFU.replace('"',eHdDoxhJCEPMZFVa2fg)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+id
			title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
			lPbeIkcm9Ows2U54NhGFL = l93v15ds7keEcOMjxVK6bh+'::'+dEQ6I4ixalFU
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1,lPbeIkcm9Ows2U54NhGFL)
	return
def BmNWI4MacRSsZUJYwz(url,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	bAQX4RoUJYDEVqKMgLW56F7Zh9z = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mychannelid',bAQX4RoUJYDEVqKMgLW56F7Zh9z)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysortmethod',sort)
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for id,title,WWPgm9fvlH2oIOnrD1,l93v15ds7keEcOMjxVK6bh,dEQ6I4ixalFU,PeLqCN5Ek8bB in items:
			if '"' in id: id = id.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in title: title = title.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in WWPgm9fvlH2oIOnrD1: WWPgm9fvlH2oIOnrD1 = WWPgm9fvlH2oIOnrD1.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in l93v15ds7keEcOMjxVK6bh: l93v15ds7keEcOMjxVK6bh = l93v15ds7keEcOMjxVK6bh.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in dEQ6I4ixalFU: dEQ6I4ixalFU = dEQ6I4ixalFU.replace('"',eHdDoxhJCEPMZFVa2fg)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+id
			title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
			lPbeIkcm9Ows2U54NhGFL = l93v15ds7keEcOMjxVK6bh+'::'+dEQ6I4ixalFU
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1,lPbeIkcm9Ows2U54NhGFL)
		if '"hasNextPage":true' in nR2B1Wye7luXb5:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,408,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk)
	return
def OOKkUtMg8EYAW(url,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	bAQX4RoUJYDEVqKMgLW56F7Zh9z = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mychannelid',bAQX4RoUJYDEVqKMgLW56F7Zh9z)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysortmethod',sort)
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for id,name,PeLqCN5Ek8bB,count,AfPeUOmzRlWuZq9QVTnk7C,l93v15ds7keEcOMjxVK6bh,dEQ6I4ixalFU in items:
			if '"' in id: id = id.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in name: name = name.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in PeLqCN5Ek8bB: PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in count: count = count.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in AfPeUOmzRlWuZq9QVTnk7C: AfPeUOmzRlWuZq9QVTnk7C = AfPeUOmzRlWuZq9QVTnk7C.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in l93v15ds7keEcOMjxVK6bh: l93v15ds7keEcOMjxVK6bh = l93v15ds7keEcOMjxVK6bh.replace('"',eHdDoxhJCEPMZFVa2fg)
			if '"' in dEQ6I4ixalFU: dEQ6I4ixalFU = dEQ6I4ixalFU.replace('"',eHdDoxhJCEPMZFVa2fg)
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
			lPbeIkcm9Ows2U54NhGFL = l93v15ds7keEcOMjxVK6bh+'::'+dEQ6I4ixalFU
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,401,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,lPbeIkcm9Ows2U54NhGFL)
		if '"hasNextPage":true' in nR2B1Wye7luXb5:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,407,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk)
	return
def iRwjF6yPv1Sld9xmfKuIYH8t5Wq(url,i8CSoE7d3IQPqY):
	bAQX4RoUJYDEVqKMgLW56F7Zh9z = url.split('/')[3]
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mychannelid',bAQX4RoUJYDEVqKMgLW56F7Zh9z)
	nR2B1Wye7luXb5 = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	import json as Z9rkmwbQ7V2DvgoR0XOLTquNKPls
	T6nXEObye0KMWjt = Z9rkmwbQ7V2DvgoR0XOLTquNKPls.loads(nR2B1Wye7luXb5)
	try: items = T6nXEObye0KMWjt['data']['channel'][i8CSoE7d3IQPqY]['edges']
	except: items = []
	if not items: qfpnsHw19BiaSktcXWbGA('link',r07r9xeEFASJXluImT+'لا توجد نتائج',eHdDoxhJCEPMZFVa2fg,9999)
	else:
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			qZkvValQDT7rnKoHgFYXdRNO = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ['node']
			Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = qZkvValQDT7rnKoHgFYXdRNO['xid']
			keys = list(qZkvValQDT7rnKoHgFYXdRNO.keys())
			qJWb4nTm6ue1938XhLFIxPksRZ2y5 = qZkvValQDT7rnKoHgFYXdRNO['__typename'].lower()
			if qJWb4nTm6ue1938XhLFIxPksRZ2y5=='channel':
				name = qZkvValQDT7rnKoHgFYXdRNO['name']
				NTev3BmchzaLdZo7MyQiDSH1bX = qZkvValQDT7rnKoHgFYXdRNO['displayName']
				title = 'USER:  '+NTev3BmchzaLdZo7MyQiDSH1bX
				PeLqCN5Ek8bB = qZkvValQDT7rnKoHgFYXdRNO['coverURLx375']
			else:
				name = qZkvValQDT7rnKoHgFYXdRNO['channel']['name']
				NTev3BmchzaLdZo7MyQiDSH1bX = qZkvValQDT7rnKoHgFYXdRNO['channel']['displayName']
				title = qZkvValQDT7rnKoHgFYXdRNO['title']
				PeLqCN5Ek8bB = qZkvValQDT7rnKoHgFYXdRNO['thumbnailx360']
				if qJWb4nTm6ue1938XhLFIxPksRZ2y5=='live': title = 'LIVE:  '+title
			title = hmKJ0MUI6nyZQCRD37E1kscHWxl8(title)
			lPbeIkcm9Ows2U54NhGFL = name+'::'+NTev3BmchzaLdZo7MyQiDSH1bX
			if lHfbysRrUV7m4CLSdkxc382n:
				title = title.encode(m6PFtLblInpNZ8x)
				lPbeIkcm9Ows2U54NhGFL = lPbeIkcm9Ows2U54NhGFL.encode(m6PFtLblInpNZ8x)
			if qJWb4nTm6ue1938XhLFIxPksRZ2y5=='channel':
				apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,402,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,lPbeIkcm9Ows2U54NhGFL)
			else:
				if qJWb4nTm6ue1938XhLFIxPksRZ2y5=='video': WWPgm9fvlH2oIOnrD1 = str(qZkvValQDT7rnKoHgFYXdRNO['duration'])
				else: WWPgm9fvlH2oIOnrD1 = eHdDoxhJCEPMZFVa2fg
				apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
				qfpnsHw19BiaSktcXWbGA(qJWb4nTm6ue1938XhLFIxPksRZ2y5,r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1,lPbeIkcm9Ows2U54NhGFL)
	return
def eJDvGtKbE17jl5i94X8gVW(search,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mysearchwords',search)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagelimit','40')
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	url = q3QVhZaDEuo8t2ASj5vkn+'/search/'+search+'/hashtags'
	zULDufV4d3mQ = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search)
	if zULDufV4d3mQ:
		LLhisn1IxoAHc8KRDj = DIpuHqsKGS3ErJvk9taCRiX80('dict',zULDufV4d3mQ)
		try: ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = LLhisn1IxoAHc8KRDj['data']['search']['hashtags']['edges']
		except: ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = []
		for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
			name = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['name']
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/hashtag/'+name[1:]
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'HSHTG: '+name,apOKrFbP9IYHDyUVm7,417)
		if '"hasNextPage":true' in zULDufV4d3mQ:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,416,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,search)
	return
def Gjswx4bAt1LKY(url,clAzmREWwXf6Gk=eHdDoxhJCEPMZFVa2fg):
	if clAzmREWwXf6Gk==eHdDoxhJCEPMZFVa2fg: clAzmREWwXf6Gk = '1'
	name = url.split('/')[-1]
	mzfT1LoKkCy7g9wuSqV = '{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('myhashtagname',name)
	mzfT1LoKkCy7g9wuSqV = mzfT1LoKkCy7g9wuSqV.replace('mypagenumber',clAzmREWwXf6Gk)
	zULDufV4d3mQ = aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV)
	if zULDufV4d3mQ:
		LLhisn1IxoAHc8KRDj = DIpuHqsKGS3ErJvk9taCRiX80('dict',zULDufV4d3mQ)
		ddRLZIcNuvlKJ7e6CbDjxWrXBM0os = LLhisn1IxoAHc8KRDj['data']['contentFeed']['edges']
		for d0BaAkVHMwcTljrNbS3DzZiLfIhOE in ddRLZIcNuvlKJ7e6CbDjxWrXBM0os:
			WWPgm9fvlH2oIOnrD1 = str(d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['post']['duration'])
			title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['post']['title'])
			title = title.replace('\/','/')
			Yuq9jeGaUL4zVTEFcfkmxDAPvhJ = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['post']['xid']
			PeLqCN5Ek8bB = d0BaAkVHMwcTljrNbS3DzZiLfIhOE['node']['post']['thumbnailx480']
			PeLqCN5Ek8bB = PeLqCN5Ek8bB.replace('\/','/')
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+'/video/'+Yuq9jeGaUL4zVTEFcfkmxDAPvhJ
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,403,PeLqCN5Ek8bB,WWPgm9fvlH2oIOnrD1)
		if '"hasNextPage":true' in zULDufV4d3mQ:
			clAzmREWwXf6Gk = str(int(clAzmREWwXf6Gk)+1)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+clAzmREWwXf6Gk,url,416,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk)
	return
def aaR5wNX3ildpLqTPAmoVu(mzfT1LoKkCy7g9wuSqV,search=eHdDoxhJCEPMZFVa2fg):
	if WHjh1POtMKlmgiy68RSqb and search:
		fqBiOzxTroQjIDJKWSn6hY = cBawilJXvK1m.findall('[a-zA-Z]',search,cBawilJXvK1m.DOTALL)
		if not fqBiOzxTroQjIDJKWSn6hY: mzfT1LoKkCy7g9wuSqV += ' }'
	YR4kadt2SpO9WmM6UoXwieJ3EZBhxA = fL67xTUEIgtrQaClb1W()
	headers = {"Authorization":YR4kadt2SpO9WmM6UoXwieJ3EZBhxA,"Origin":q3QVhZaDEuo8t2ASj5vkn,'Content-Type':'application/json'}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',hP7uJ4Bo9OaeWXwHTKjz8ifkCv5c,mzfT1LoKkCy7g9wuSqV,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'DAILYMOTION-GET_PAGEDATA-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	return nR2B1Wye7luXb5
def fL67xTUEIgtrQaClb1W():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'DAILYMOTION-GET_AUTHINTICATION-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	ppcHsNSTInqxAF90JbDhiUdC24fo3 = cBawilJXvK1m.findall('var r="(.*?)",o="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	nEJarYGTgfF7hmzckOjl8ts0U9X3LP,tIQhZa1Vk52Ws0OpUNjlHyczA7x = ppcHsNSTInqxAF90JbDhiUdC24fo3[-1]
	Eq7JWM6VdRj5BuvlxTcQZ9p = 'https://graphql.api.dailymotion.com/oauth/token'
	KHZEh5lRitVycLBWM4xjI9COAfNF = 'client_credentials'
	data = {'client_id':nEJarYGTgfF7hmzckOjl8ts0U9X3LP,'client_secret':tIQhZa1Vk52Ws0OpUNjlHyczA7x,'grant_type':KHZEh5lRitVycLBWM4xjI9COAfNF}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,'POST',Eq7JWM6VdRj5BuvlxTcQZ9p,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	ppcHsNSTInqxAF90JbDhiUdC24fo3 = cBawilJXvK1m.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	XEHRFJt5dvO98bI2AloVkK7x4,bMHw59JP82fzW = ppcHsNSTInqxAF90JbDhiUdC24fo3[0]
	YR4kadt2SpO9WmM6UoXwieJ3EZBhxA = bMHw59JP82fzW+" "+XEHRFJt5dvO98bI2AloVkK7x4
	return YR4kadt2SpO9WmM6UoXwieJ3EZBhxA
def ZZG8yFCkvXnPTgR6Jc(search,type=eHdDoxhJCEPMZFVa2fg):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not type and showDialogs:
		QXdUxtrE91oKPjin = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg('موقع ديلي موشن - اختر البحث',QXdUxtrE91oKPjin)
		if iLcCSnPyKYWs3xkQ0p14==-1: return
		elif iLcCSnPyKYWs3xkQ0p14==0: type = 'videos?sortBy='
		elif iLcCSnPyKYWs3xkQ0p14==1: type = 'videos?sortBy=RECENT'
		elif iLcCSnPyKYWs3xkQ0p14==2: type = 'videos?sortBy=VIEW_COUNT'
		elif iLcCSnPyKYWs3xkQ0p14==3: type = 'playlists'
		elif iLcCSnPyKYWs3xkQ0p14==4: type = 'channels'
		elif iLcCSnPyKYWs3xkQ0p14==5: type = 'lives'
		elif iLcCSnPyKYWs3xkQ0p14==6: type = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in WWLbVhETM9ZCwm85f: type = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in WWLbVhETM9ZCwm85f: type = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in WWLbVhETM9ZCwm85f: type = 'channels'
	elif '_DAILYMOTION-LIVES_' in WWLbVhETM9ZCwm85f: type = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in WWLbVhETM9ZCwm85f: type = 'hashtags'
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	if 'videos' in type: P1kMIba5xKhjZW6cHozUmirn8V(search+'/'+type)
	elif 'playlists' in type: WAQ0yLVDYNZJST2(search)
	elif 'channels' in type: DnhyKEwkjGB8Ou9JpfYC6g(search)
	elif 'lives' in type: zcJuRB04MtlQhYqI(search)
	elif 'hashtags' in type: eJDvGtKbE17jl5i94X8gVW(search)
	return
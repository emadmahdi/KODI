﻿# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'ALMAAREF'
headers = {'User-Agent':eHdDoxhJCEPMZFVa2fg}
r07r9xeEFASJXluImT = '_MRF_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text,clAzmREWwXf6Gk):
	if   mode==40: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==41: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ozPjuMtH32DEISFKQl()
	elif mode==42: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = HQEevq9SkWsKAnlJiN1(text,clAzmREWwXf6Gk)
	elif mode==43: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==44: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(text,clAzmREWwXf6Gk)
	elif mode==49: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,49)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('live',r07r9xeEFASJXluImT+'البث الحي لقناة المعارف',eHdDoxhJCEPMZFVa2fg,41)
	HQEevq9SkWsKAnlJiN1(eHdDoxhJCEPMZFVa2fg,'1')
	return
def WbfaEhN87UGuzFcS1LR2mw9(WWLbVhETM9ZCwm85f,RPemUkECGrf7cJMNVq0z3dBv6n4pYI):
	search,sort,vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73,U3d2hkuwDIj56,l9FokOX2ajg46HL1senbpCy = eHdDoxhJCEPMZFVa2fg,[],[],[],[]
	ppxnlrkDsXUmKQWFt,ZgLzhrRXcfTPu = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(WWLbVhETM9ZCwm85f)
	for gW0v8nMxdq2 in list(ZgLzhrRXcfTPu.keys()):
		q5qDOCzEe0Lv4ZyJbWnaPcpVsB = ZgLzhrRXcfTPu[gW0v8nMxdq2]
		if not q5qDOCzEe0Lv4ZyJbWnaPcpVsB: continue
		if   gW0v8nMxdq2=='sort': sort = [q5qDOCzEe0Lv4ZyJbWnaPcpVsB]
		elif gW0v8nMxdq2=='series': vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73 = [q5qDOCzEe0Lv4ZyJbWnaPcpVsB]
		elif gW0v8nMxdq2=='search': search = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif gW0v8nMxdq2=='category': U3d2hkuwDIj56 = [q5qDOCzEe0Lv4ZyJbWnaPcpVsB]
		elif gW0v8nMxdq2=='specialist': l9FokOX2ajg46HL1senbpCy = [q5qDOCzEe0Lv4ZyJbWnaPcpVsB]
	j6KOlzWGugZqmx0sPS = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":U3d2hkuwDIj56,"specialist":l9FokOX2ajg46HL1senbpCy,"series":vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(RPemUkECGrf7cJMNVq0z3dBv6n4pYI)}}
	import json as Z9rkmwbQ7V2DvgoR0XOLTquNKPls
	j6KOlzWGugZqmx0sPS = Z9rkmwbQ7V2DvgoR0XOLTquNKPls.dumps(j6KOlzWGugZqmx0sPS)
	apOKrFbP9IYHDyUVm7 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'POST',apOKrFbP9IYHDyUVm7,j6KOlzWGugZqmx0sPS,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	data = DIpuHqsKGS3ErJvk9taCRiX80('dict',nR2B1Wye7luXb5)
	return data
def HQEevq9SkWsKAnlJiN1(WWLbVhETM9ZCwm85f,level):
	ekNMoIJzswUSDVQf564 = WbfaEhN87UGuzFcS1LR2mw9(WWLbVhETM9ZCwm85f,'1')
	cOUiow273ytu1GC5N0FJh = ekNMoIJzswUSDVQf564['facets']
	if level=='1':
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh['video_categories']
		items = cBawilJXvK1m.findall('<div(.*?)/div>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ+'<',cBawilJXvK1m.DOTALL)
			if not hPYnfjbqWDJNSAeyQaBrOZt68: hPYnfjbqWDJNSAeyQaBrOZt68 = cBawilJXvK1m.findall('data-value=\\"(.*?)\\">(.*?)<',AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ+'<',cBawilJXvK1m.DOTALL)
			U3d2hkuwDIj56,title = hPYnfjbqWDJNSAeyQaBrOZt68[0]
			if lHfbysRrUV7m4CLSdkxc382n: title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
			if not WWLbVhETM9ZCwm85f: qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,42,eHdDoxhJCEPMZFVa2fg,'2','?category='+U3d2hkuwDIj56)
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,42,eHdDoxhJCEPMZFVa2fg,'2',WWLbVhETM9ZCwm85f+'&category='+U3d2hkuwDIj56)
	if level=='2':
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh['specialist']
		items = cBawilJXvK1m.findall('value="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for l9FokOX2ajg46HL1senbpCy,title in items:
			if lHfbysRrUV7m4CLSdkxc382n: title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
			if not l9FokOX2ajg46HL1senbpCy: title = title = 'الجميع'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,42,eHdDoxhJCEPMZFVa2fg,'3',WWLbVhETM9ZCwm85f+'&specialist='+l9FokOX2ajg46HL1senbpCy)
	elif level=='3':
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh['series']
		items = cBawilJXvK1m.findall('value="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73,title in items:
			if lHfbysRrUV7m4CLSdkxc382n: title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
			if not vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73: title = title = 'الجميع'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,42,eHdDoxhJCEPMZFVa2fg,'4',WWLbVhETM9ZCwm85f+'&series='+vvHdlX6tkbWVQKhBm92zcZ1nOTpJ73)
	elif level=='4':
		cOUiow273ytu1GC5N0FJh = cOUiow273ytu1GC5N0FJh['sort_video']
		items = cBawilJXvK1m.findall('value="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for sort,title in items:
			if not sort: continue
			if lHfbysRrUV7m4CLSdkxc382n: title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,eHdDoxhJCEPMZFVa2fg,44,eHdDoxhJCEPMZFVa2fg,'1',WWLbVhETM9ZCwm85f+'&sort='+sort)
	return
def zRK9ruIt0ZFV4bgi(WWLbVhETM9ZCwm85f,RPemUkECGrf7cJMNVq0z3dBv6n4pYI):
	ekNMoIJzswUSDVQf564 = WbfaEhN87UGuzFcS1LR2mw9(WWLbVhETM9ZCwm85f,RPemUkECGrf7cJMNVq0z3dBv6n4pYI)
	cOUiow273ytu1GC5N0FJh = ekNMoIJzswUSDVQf564['template']
	items = cBawilJXvK1m.findall('src="(.*?)".*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for PeLqCN5Ek8bB,apOKrFbP9IYHDyUVm7,title in items:
		if lHfbysRrUV7m4CLSdkxc382n: title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,43,PeLqCN5Ek8bB)
	cOUiow273ytu1GC5N0FJh = ekNMoIJzswUSDVQf564['facets']['pagination']
	items = cBawilJXvK1m.findall('data-page="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	for clAzmREWwXf6Gk,title in items:
		if RPemUkECGrf7cJMNVq0z3dBv6n4pYI==clAzmREWwXf6Gk: continue
		if lHfbysRrUV7m4CLSdkxc382n: title = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(title)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,eHdDoxhJCEPMZFVa2fg,44,eHdDoxhJCEPMZFVa2fg,clAzmREWwXf6Gk,WWLbVhETM9ZCwm85f)
	return
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ALMAAREF-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('<video src="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall('youtube_url.*?(http.*?)&',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	wROf6m4Ix73jtsdnZ1vpCDuV = []
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[0].replace('\/','/')
		wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,EERWJf1adv67,'video',url)
	return
def ozPjuMtH32DEISFKQl():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn+'/بث-مباشر',eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ALMAAREF-LIVE-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	url = cBawilJXvK1m.findall('"svpPlayer".*?(http.*?)&',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	url = url[0].replace('\\',eHdDoxhJCEPMZFVa2fg)
	IZkpyKSFVarcHwG1g6emqQv70h(url,EERWJf1adv67,'live')
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	JchsD5N1Etm4ai2rZgPO8MjAL = False
	if search==eHdDoxhJCEPMZFVa2fg:
		search = mJ1lHWKUPcZGezML7X2u9S()
		JchsD5N1Etm4ai2rZgPO8MjAL = True
	if search==eHdDoxhJCEPMZFVa2fg: return
	if not JchsD5N1Etm4ai2rZgPO8MjAL: zRK9ruIt0ZFV4bgi('?search='+search,'1')
	else: HQEevq9SkWsKAnlJiN1('?search='+search,'1')
	return
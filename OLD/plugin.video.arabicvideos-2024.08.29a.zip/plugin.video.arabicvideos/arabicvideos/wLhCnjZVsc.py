# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'ARABSEED'
headers = {'User-Agent':qq62QA8h3pGxzCwWVeXIF7glKf()}
r07r9xeEFASJXluImT = '_ARS_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==250: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==251: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==252: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==253: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==254: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'CATEGORIES___'+text)
	elif mode==255: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'FILTERS___'+text)
	elif mode==256: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = VrWsaTmY2qZ(url,text)
	elif mode==259: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',q3QVhZaDEuo8t2ASj5vkn+'/main',eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,259,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر محدد',q3QVhZaDEuo8t2ASj5vkn+'/category/اخرى',254)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر كامل',q3QVhZaDEuo8t2ASj5vkn+'/category/اخرى',255)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'المميزة',q3QVhZaDEuo8t2ASj5vkn+'/main',251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured_main')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'جديد الأفلام',q3QVhZaDEuo8t2ASj5vkn+'/main',251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'new_movies')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'جديد الحلقات',q3QVhZaDEuo8t2ASj5vkn+'/main',251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'new_episodes')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'المضاف حديثاً',q3QVhZaDEuo8t2ASj5vkn+'/latest',251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'lastest')
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('class="MenuHeader"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	KUTgdRBshwIZcbuv0LVC4 = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
	bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',KUTgdRBshwIZcbuv0LVC4,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title in bLPGQ21sY8ie0fZ:
		title = zJRbA1YW2Eor(title)
		if title not in IVD2kBKhW8FeQLvxUm and title!=eHdDoxhJCEPMZFVa2fg:
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,256)
	return nR2B1Wye7luXb5
def VrWsaTmY2qZ(url,type):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-SUBMENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if 'class="SliderInSection' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الأكثر مشاهدة',url,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'most')
	if 'class="MainSlides' in nR2B1Wye7luXb5: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'المميزة',url,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	if 'class="LinksList' in nR2B1Wye7luXb5:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="LinksList(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			if len(RRztfCIs16MGxEHLJ25vDNAa7hpWT)>1 and type=='new_episodes': cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[1]
			items = cBawilJXvK1m.findall('href="(.*?)"(.*?)</a>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title in items:
				uVpKOk8ZM0LvQ6UI = cBawilJXvK1m.findall('</i>(.*?)<span>(.*?)<',title,cBawilJXvK1m.DOTALL)
				try: B0ZiepTkgjAq8lWxCKyX1 = uVpKOk8ZM0LvQ6UI[0][0].replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				except: B0ZiepTkgjAq8lWxCKyX1 = eHdDoxhJCEPMZFVa2fg
				try: CCbge5YqUNRrZXMz1K7u0h6mId = uVpKOk8ZM0LvQ6UI[0][1].replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
				except: CCbge5YqUNRrZXMz1K7u0h6mId = eHdDoxhJCEPMZFVa2fg
				uVpKOk8ZM0LvQ6UI = B0ZiepTkgjAq8lWxCKyX1+avcfIls8w7gk69hYUErHxzQTXtm24j+CCbge5YqUNRrZXMz1K7u0h6mId
				if '<strong>' in title:
					qg3DwCuZVcyLpnzEjtvFaHKkMs = cBawilJXvK1m.findall('</i>(.*?)<',title,cBawilJXvK1m.DOTALL)
					if qg3DwCuZVcyLpnzEjtvFaHKkMs: uVpKOk8ZM0LvQ6UI = qg3DwCuZVcyLpnzEjtvFaHKkMs[0]
				if not uVpKOk8ZM0LvQ6UI:
					qg3DwCuZVcyLpnzEjtvFaHKkMs = cBawilJXvK1m.findall('alt="(.*?)"',title,cBawilJXvK1m.DOTALL)
					if qg3DwCuZVcyLpnzEjtvFaHKkMs: uVpKOk8ZM0LvQ6UI = qg3DwCuZVcyLpnzEjtvFaHKkMs[0]
				if uVpKOk8ZM0LvQ6UI:
					if 'key=' in apOKrFbP9IYHDyUVm7: type = apOKrFbP9IYHDyUVm7.split('key=')[1]
					else: type = 'newest'
					uVpKOk8ZM0LvQ6UI = uVpKOk8ZM0LvQ6UI.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,apOKrFbP9IYHDyUVm7,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	return
def zRK9ruIt0ZFV4bgi(url,type):
	fb9C73uPyN,data,items = 'GET',eHdDoxhJCEPMZFVa2fg,[]
	if type=='filters':
		if '?' in url:
			Rp6j2ZoUKzOitrQDca5JIgbS4TEw,LbAmEhrdt7eRV2Y = 'POST',{}
			E1Viom5L3684CTOFJ,RaJf24z7sOkrApTlSCPi3 = url.split('?')
			a0VHgjbCY1KfuI6o = RaJf24z7sOkrApTlSCPi3.split('&')
			for g6DoPQHrhS in a0VHgjbCY1KfuI6o:
				key,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = g6DoPQHrhS.split('=')
				LbAmEhrdt7eRV2Y[key] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
			if a0VHgjbCY1KfuI6o: fb9C73uPyN,url,data = Rp6j2ZoUKzOitrQDca5JIgbS4TEw,E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,fb9C73uPyN,url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if type=='filters': RRztfCIs16MGxEHLJ25vDNAa7hpWT = [nR2B1Wye7luXb5]
	elif 'featured' in type: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="MainSlides(.*?)class="LinksList',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	elif type=='new_movies': RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	elif type=='new_episodes': RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	elif type=='most': RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="SliderInSection(.*?)class="LinksList',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	else: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="Blocks-UL"(.*?)class="AboElSeed"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if 'featured' in type:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		eWof5aHlLJXkKID28phNGQqZrR = cBawilJXvK1m.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if eWof5aHlLJXkKID28phNGQqZrR:
			ppQOjlq2gaPkW,FBITEXGDfe2mcCxnQs6ktMdy9HJh,zlr63dK4kj,JN1MdQFh5iArSHPsEquaxO0CG6U = zip(*eWof5aHlLJXkKID28phNGQqZrR)
			items = zip(ppQOjlq2gaPkW,JN1MdQFh5iArSHPsEquaxO0CG6U,FBITEXGDfe2mcCxnQs6ktMdy9HJh)
	else:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	adU3exogvimBLnCQOwz = []
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		if 'WWE' in title: continue
		title = zJRbA1YW2Eor(title)
		if 'الحلقة' in title:
			vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
			if vQ2LDF3UyXZbhu97Y:
				title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
				if title not in adU3exogvimBLnCQOwz:
					adU3exogvimBLnCQOwz.append(title)
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,253,PeLqCN5Ek8bB)
			else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,252,PeLqCN5Ek8bB)
		elif '/selary/' in apOKrFbP9IYHDyUVm7 or 'مسلسل' in title:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,253,PeLqCN5Ek8bB)
		else:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,252,PeLqCN5Ek8bB)
	if type in ['newest','best','most']:
		items = cBawilJXvK1m.findall('page-numbers" href="(.*?)">(.*?)<',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			apOKrFbP9IYHDyUVm7 = q3QVhZaDEuo8t2ASj5vkn+apOKrFbP9IYHDyUVm7
			apOKrFbP9IYHDyUVm7 = zJRbA1YW2Eor(apOKrFbP9IYHDyUVm7)
			title = zJRbA1YW2Eor(title)
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,type)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5[10000:]
	items = cBawilJXvK1m.findall('data-src="(.*?)".*?alt="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not items: return
	PeLqCN5Ek8bB,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="ContainerEpisodesList"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?<em>(.*?)</em>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,vQ2LDF3UyXZbhu97Y in items:
			title = name+' - الحلقة رقم '+vQ2LDF3UyXZbhu97Y
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,252,PeLqCN5Ek8bB)
	else: qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+'ملف التشغيل',url,252,PeLqCN5Ek8bB)
	return
def LtEAs86WP97waZ(title,apOKrFbP9IYHDyUVm7):
	uVpKOk8ZM0LvQ6UI = cBawilJXvK1m.findall('[a-zA-Z-]+',title,cBawilJXvK1m.DOTALL)
	if uVpKOk8ZM0LvQ6UI: title = uVpKOk8ZM0LvQ6UI[0]
	else: title = title+avcfIls8w7gk69hYUErHxzQTXtm24j+b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
	title = title.replace('عرب سيد',eHdDoxhJCEPMZFVa2fg).replace('مباشر',eHdDoxhJCEPMZFVa2fg).replace('مشاهدة',eHdDoxhJCEPMZFVa2fg)
	title = title.replace('ٍ',eHdDoxhJCEPMZFVa2fg)
	title = title.replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	return title
def bbmQeYGSTIv(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	E1Viom5L3684CTOFJ = aP8bLqZJsQlH3ivWKc.url
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,'url')
	headers['Referer'] = GfhcsvCWIon+'/'
	T0oYA6DCGmBtc95fPapFLVOhM,wJpuIhq6xtRGQSEe5HA,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,[]
	I5bBg0yFXYWdemJ1rRE4QGj = cBawilJXvK1m.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if I5bBg0yFXYWdemJ1rRE4QGj: T0oYA6DCGmBtc95fPapFLVOhM,kcWMPsL8rTBgnQEoRpmd9yOjXC,wJpuIhq6xtRGQSEe5HA,FyWTVmEXrYwtpUBujRMxZb = I5bBg0yFXYWdemJ1rRE4QGj[0]
	else:
		I5bBg0yFXYWdemJ1rRE4QGj = cBawilJXvK1m.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if I5bBg0yFXYWdemJ1rRE4QGj:
			apOKrFbP9IYHDyUVm7,kcWMPsL8rTBgnQEoRpmd9yOjXC = I5bBg0yFXYWdemJ1rRE4QGj[0]
			if 'watch' in kcWMPsL8rTBgnQEoRpmd9yOjXC: T0oYA6DCGmBtc95fPapFLVOhM = apOKrFbP9IYHDyUVm7
			else: wJpuIhq6xtRGQSEe5HA = apOKrFbP9IYHDyUVm7
	if T0oYA6DCGmBtc95fPapFLVOhM:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',T0oYA6DCGmBtc95fPapFLVOhM,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-PLAY-2nd')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="WatcherArea(.*?</ul>)',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			IUQajudylJeN6TDVB1bnXqc = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			IUQajudylJeN6TDVB1bnXqc = IUQajudylJeN6TDVB1bnXqc.replace('</ul>','<h3>')
			IUQajudylJeN6TDVB1bnXqc = IUQajudylJeN6TDVB1bnXqc.replace('<h3>','<h3><h3>')
			ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall('<h3>.*?(\d+)(.*?)<h3>',IUQajudylJeN6TDVB1bnXqc,cBawilJXvK1m.DOTALL)
			if not ekNMoIJzswUSDVQf564: ekNMoIJzswUSDVQf564 = [(eHdDoxhJCEPMZFVa2fg,IUQajudylJeN6TDVB1bnXqc)]
			for s0s2bIZtWx8w3,cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
				if s0s2bIZtWx8w3: s0s2bIZtWx8w3 = '____'+s0s2bIZtWx8w3
				items = cBawilJXvK1m.findall('data-link="(.*?)".*?<span>(.*?)</span>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				for apOKrFbP9IYHDyUVm7,name in items:
					if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
					apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+name+'__watch'+s0s2bIZtWx8w3
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not JCZVK86QTYwX4mfgOrod: JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if JCZVK86QTYwX4mfgOrod:
			apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3 = JCZVK86QTYwX4mfgOrod[0]
			name = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,'name')
			if '%' in s0s2bIZtWx8w3: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+name+'__embed__'
			else: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+name+'__embed____'+s0s2bIZtWx8w3
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if wJpuIhq6xtRGQSEe5HA:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',wJpuIhq6xtRGQSEe5HA,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-PLAY-3rd')
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="DownloadArea(.*?)<script src=',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			IUQajudylJeN6TDVB1bnXqc = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
			ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall('class="DownloadServers(.*?)</ul>',IUQajudylJeN6TDVB1bnXqc,cBawilJXvK1m.DOTALL)
			for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
				items = cBawilJXvK1m.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				for apOKrFbP9IYHDyUVm7,title,s0s2bIZtWx8w3 in items:
					if not apOKrFbP9IYHDyUVm7: continue
					if 'reviewstation' in apOKrFbP9IYHDyUVm7: continue
					apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7)
					apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__download____'+s0s2bIZtWx8w3
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	J4F5BlZRtmsNrupG7njzb3ydYL8vo = str(ppQOjlq2gaPkW)
	AiUEhB3wfpcvbQzDO = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in J4F5BlZRtmsNrupG7njzb3ydYL8vo for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in AiUEhB3wfpcvbQzDO):
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search: search = mJ1lHWKUPcZGezML7X2u9S()
	if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/find/?find='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
def bbkDE5p9zlX6aV(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==eHdDoxhJCEPMZFVa2fg: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	else: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = filter.split('___')
	if type=='CATEGORIES':
		if F23emprt1knX9iCxLZ58zl[0]+'==' not in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = F23emprt1knX9iCxLZ58zl[0]
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(F23emprt1knX9iCxLZ58zl[0:-1])):
			if F23emprt1knX9iCxLZ58zl[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+'==' in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = F23emprt1knX9iCxLZ58zl[dhcGSyo8Kn1mHZwvEAkzJ7NUq+1]
		aTFm6bOUj7 = goUS2aiGbZX1OQ+'&&'+U3d2hkuwDIj56+'==0'
		e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&&'+U3d2hkuwDIj56+'==0'
		r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7.strip('&&')+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM.strip('&&')
		jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'modified_filters')
		E1Viom5L3684CTOFJ = url+'//getposts??'+jj8Ha32XYoVSZhNUsWyCPDmq4f
	elif type=='FILTERS':
		aSF3HMlugcs9G7Yz = QRKwbZae0G3m(goUS2aiGbZX1OQ,'modified_values')
		aSF3HMlugcs9G7Yz = zrHeZWCqQMOymk1d7anKpu0vEx8(aSF3HMlugcs9G7Yz)
		if JVw3Ug6xQykdj2oM50!=eHdDoxhJCEPMZFVa2fg: JVw3Ug6xQykdj2oM50 = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'modified_filters')
		if JVw3Ug6xQykdj2oM50==eHdDoxhJCEPMZFVa2fg: E1Viom5L3684CTOFJ = url
		else: E1Viom5L3684CTOFJ = url+'//getposts??'+JVw3Ug6xQykdj2oM50
		FFZmdCYeVfKwBkMn4qyvcX = YYGcZjDLnzRN9QE(E1Viom5L3684CTOFJ)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أظهار قائمة الفيديو التي تم اختيارها ',FFZmdCYeVfKwBkMn4qyvcX,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'filters')
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' [[   '+aSF3HMlugcs9G7Yz+'   ]]',FFZmdCYeVfKwBkMn4qyvcX,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'filters')
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'POST',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ARABSEED-FILTERS_MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	xyqhLBzpeQPHZKmOEFog4v = cBawilJXvK1m.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	XtaWmhvSdnc0kJuNG9 = cBawilJXvK1m.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = xyqhLBzpeQPHZKmOEFog4v+XtaWmhvSdnc0kJuNG9
	dict = {}
	for name,BYy2jD5CQfh3rdxTAFzJ84Vk6E,cOUiow273ytu1GC5N0FJh in IVnCEBUYx5s3oleJkmdr2zWa0Ni:
		items = cBawilJXvK1m.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('data-rate="(.*?)".*?<em>(.*?)</em>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			items = []
			for gW0v8nMxdq2,q5qDOCzEe0Lv4ZyJbWnaPcpVsB in bLPGQ21sY8ie0fZ: items.append([gW0v8nMxdq2,eHdDoxhJCEPMZFVa2fg,q5qDOCzEe0Lv4ZyJbWnaPcpVsB])
			BYy2jD5CQfh3rdxTAFzJ84Vk6E = 'rate'
			name = 'التقييم'
		else: BYy2jD5CQfh3rdxTAFzJ84Vk6E = items[0][1]
		if '==' not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = url
		if type=='CATEGORIES':
			if U3d2hkuwDIj56!=BYy2jD5CQfh3rdxTAFzJ84Vk6E: continue
			elif len(items)<=1:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==F23emprt1knX9iCxLZ58zl[-1]: zRK9ruIt0ZFV4bgi(E1Viom5L3684CTOFJ)
				else: bbkDE5p9zlX6aV(E1Viom5L3684CTOFJ,'CATEGORIES___'+r3bWKiRBqwE54ayCf0utvhDlx)
				return
			else:
				FFZmdCYeVfKwBkMn4qyvcX = YYGcZjDLnzRN9QE(E1Viom5L3684CTOFJ)
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==F23emprt1knX9iCxLZ58zl[-1]: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع ',FFZmdCYeVfKwBkMn4qyvcX,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'filters')
				else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع ',E1Viom5L3684CTOFJ,254,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		elif type=='FILTERS':
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'==0'
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'==0'
			r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع :'+name,E1Viom5L3684CTOFJ,255,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E] = {}
		for gW0v8nMxdq2,ppxnlrkDsXUmKQWFt,q5qDOCzEe0Lv4ZyJbWnaPcpVsB in items:
			if gW0v8nMxdq2 in IVD2kBKhW8FeQLvxUm: continue
			if 'الكل' in gW0v8nMxdq2: continue
			gW0v8nMxdq2 = zJRbA1YW2Eor(gW0v8nMxdq2)
			C8Qb5HdOey9Maf60Y3xZKGmhlDc1,uVpKOk8ZM0LvQ6UI = gW0v8nMxdq2,gW0v8nMxdq2
			uVpKOk8ZM0LvQ6UI = name+': '+C8Qb5HdOey9Maf60Y3xZKGmhlDc1
			dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E][q5qDOCzEe0Lv4ZyJbWnaPcpVsB] = uVpKOk8ZM0LvQ6UI
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=='+C8Qb5HdOey9Maf60Y3xZKGmhlDc1
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
			nSjP8erv4yop = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			if type=='FILTERS':
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,url,255,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
			elif type=='CATEGORIES' and F23emprt1knX9iCxLZ58zl[-2]+'==' in goUS2aiGbZX1OQ:
				jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(e2mXDvCIA45Hp81FPKhaiWJGuM,'modified_filters')
				ajHR9ABQl2buvm = url+'//getposts??'+jj8Ha32XYoVSZhNUsWyCPDmq4f
				FFZmdCYeVfKwBkMn4qyvcX = YYGcZjDLnzRN9QE(ajHR9ABQl2buvm)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,FFZmdCYeVfKwBkMn4qyvcX,251,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'filters')
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+uVpKOk8ZM0LvQ6UI,url,254,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
	return
F23emprt1knX9iCxLZ58zl = ['category','country','release-year']
oji5q2RnKASB97GN = ['category','country','genre','release-year','language','quality','rate']
def YYGcZjDLnzRN9QE(url):
	YLF6vs0JIAMSc3rNfit7w1xB = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',YLF6vs0JIAMSc3rNfit7w1xB)
	url = url.replace('/category/اخرى',eHdDoxhJCEPMZFVa2fg)
	if YLF6vs0JIAMSc3rNfit7w1xB not in url: url = url+YLF6vs0JIAMSc3rNfit7w1xB
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def QRKwbZae0G3m(yTtrwivOXY68ECP7ZHQgNdJ1,mode):
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.strip('&&')
	f8TRa4pzuVmo7c9gZ1j6rtPYOXqe,Q2OrNnmvR5HfY = {},eHdDoxhJCEPMZFVa2fg
	if '==' in yTtrwivOXY68ECP7ZHQgNdJ1:
		items = yTtrwivOXY68ECP7ZHQgNdJ1.split('&&')
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			WW4LlMgICSbVYDfXKQdtzik,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split('==')
			f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[WW4LlMgICSbVYDfXKQdtzik] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	for key in oji5q2RnKASB97GN:
		if key in list(f8TRa4pzuVmo7c9gZ1j6rtPYOXqe.keys()): q5qDOCzEe0Lv4ZyJbWnaPcpVsB = f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[key]
		else: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = '0'
		if '%' not in q5qDOCzEe0Lv4ZyJbWnaPcpVsB: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = vFDQstemyYANa(q5qDOCzEe0Lv4ZyJbWnaPcpVsB)
		if mode=='modified_values' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+' + '+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='modified_filters' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&&'+key+'=='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='all': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&&'+key+'=='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip(' + ')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip('&&')
	return Q2OrNnmvR5HfY
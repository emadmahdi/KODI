# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from dIxmaLQn3F import *
dqKGMYgJxSF8Ub1kotlsP936Ww7B(f90fGrlSEObDsuiA3U(u"ࠩࡗࡉࡘ࡚ࠧ೪"),eNEhtuoi9gK8JaTpIXj(u"ࠪࡘࡊ࡙ࡔࠨ೫"))
sn9KybUtqNivPWZDdE4Ck2 = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡶࡶ࠵࠰ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠲ࡹ࡮ࡩ࡯࡭ࡥࡶࡴࡧࡤࡣࡣࡱࡨ࠳ࡩ࡯࡮࠱࠴࠴ࡒࡈ࠮ࡻ࡫ࡳࠫ೬")
sn9KybUtqNivPWZDdE4Ck2 = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡰࡦࡧࡧࡸࡪࡹࡴ࠯ࡨࡷࡴ࠳ࡵࡴࡦࡰࡨࡸ࠳࡭ࡲ࠰ࡨ࡬ࡰࡪࡹ࠯ࡵࡧࡶࡸ࠶࠶࠰࡬࠰ࡧࡦࠬ೭")
L7IPyDUvXQwA2e9fChNruZcYM50(sn9KybUtqNivPWZDdE4Ck2,{},YchIv6N09BaWPEj4tieAnluKZrRXT)
Nn360bq79W2kzUt = LyOR7f69iA(u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ใะู࠳ࡳࡰ࠴ࠩ೮")
Nn360bq79W2kzUt = TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡄ࠼࡟ࡠ࡙ࡋࡍࡑ࡞࡟ࡸࡪࡳࡰ࡝࡞ࡤࡥࠥࡨࡢ࡝࡞ࡩ࡭ࡱ࡫࡟࠵࠺࠶࠸ࡤ࡙ࡈࡗࡡี๎ฬืษࡠษ็ีุ๎ไࡠษ็ว฾฾ๅࡠุࠪ࠭ࡤ࠮รษษำีࡤอไฮๆ๋หั๐ࠩ࠯࡯ࡳ࠷ࠬ೯")
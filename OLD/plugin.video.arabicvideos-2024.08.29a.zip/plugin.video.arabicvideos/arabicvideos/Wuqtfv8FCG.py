# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'SHAHID4U'
r07r9xeEFASJXluImT = '_SH4_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
IVD2kBKhW8FeQLvxUm = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==110: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==111: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==112: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==113: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url,True)
	elif mode==114: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'FULL_FILTER___'+text)
	elif mode==115: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbkDE5p9zlX6aV(url,'DEFINED_FILTER___'+text)
	elif mode==116: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url,False)
	elif mode==119: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	headers = {'User-Agent':qq62QA8h3pGxzCwWVeXIF7glKf(True)}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',q3QVhZaDEuo8t2ASj5vkn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-MENU-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	rPxSTcgYVul1sqkwtD8HC62vZ4 = b31wAB8mhaz2rXHoJFlfvDugtsOj(aP8bLqZJsQlH3ivWKc.url,'url')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,119,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر محدد',rPxSTcgYVul1sqkwtD8HC62vZ4,115)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'فلتر كامل',rPxSTcgYVul1sqkwtD8HC62vZ4,114)
	qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'المميزة',rPxSTcgYVul1sqkwtD8HC62vZ4,111,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'featured')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('simple-filter(.*?)adv-filter',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for filter,PeLqCN5Ek8bB,title in items:
			url = rPxSTcgYVul1sqkwtD8HC62vZ4+filter
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,url,111,PeLqCN5Ek8bB,eHdDoxhJCEPMZFVa2fg,filter)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="dropdown"(.*?)<script>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		items = cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if title in IVD2kBKhW8FeQLvxUm: continue
			if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = rPxSTcgYVul1sqkwtD8HC62vZ4+apOKrFbP9IYHDyUVm7
			if 'netflix' in apOKrFbP9IYHDyUVm7: title = 'نيتفلكس'
			qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,111)
	return nR2B1Wye7luXb5
def zRK9ruIt0ZFV4bgi(url,ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=eHdDoxhJCEPMZFVa2fg,aP8bLqZJsQlH3ivWKc=eHdDoxhJCEPMZFVa2fg):
	headers = {'User-Agent':qq62QA8h3pGxzCwWVeXIF7glKf(True)}
	if not aP8bLqZJsQlH3ivWKc: aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-TITLES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT,items,adU3exogvimBLnCQOwz = [],[],[]
	if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR=='featured': RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('glide__slides(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	else: RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('shows-container(.*?)pagination',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	if not items: items = cBawilJXvK1m.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	L5aGZx9Y8zy6V2U = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for apOKrFbP9IYHDyUVm7,PeLqCN5Ek8bB,title in items:
		if 'WWE' in title: continue
		if 'javascript' in apOKrFbP9IYHDyUVm7: continue
		apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7).strip('/')
		title = zJRbA1YW2Eor(title)
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		vQ2LDF3UyXZbhu97Y = cBawilJXvK1m.findall('(.*?) الحلقة \d+',title,cBawilJXvK1m.DOTALL)
		if '/film/' in apOKrFbP9IYHDyUVm7 or 'فيلم' in apOKrFbP9IYHDyUVm7 or any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in title for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in L5aGZx9Y8zy6V2U):
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,112,PeLqCN5Ek8bB)
		elif vQ2LDF3UyXZbhu97Y and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + vQ2LDF3UyXZbhu97Y[0]
			if title not in adU3exogvimBLnCQOwz:
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,113,PeLqCN5Ek8bB)
				adU3exogvimBLnCQOwz.append(title)
		elif '/actor/' in apOKrFbP9IYHDyUVm7:
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,111,PeLqCN5Ek8bB)
		elif '/series/' in apOKrFbP9IYHDyUVm7 and '/list' not in url:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'/list'
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,111,PeLqCN5Ek8bB)
		elif '/list' in url and 'حلقة' in title:
			qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,112,PeLqCN5Ek8bB)
		else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,113,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('"pagination"(.*?)</ul>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR!='search': items = cBawilJXvK1m.findall('(updateQuery).*?>(.+?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		else: items = cBawilJXvK1m.findall('<li>.*?href="(.*?)">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for apOKrFbP9IYHDyUVm7,title in items:
			title = title.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)
			title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			if ff8WuQ0HaAmPEdo6SnMXr1sCeTzR!='search':
				if '?' in url: apOKrFbP9IYHDyUVm7 = url+'&page='+title
				else: apOKrFbP9IYHDyUVm7 = url+'?page='+title
			title = zJRbA1YW2Eor(title)
			if title: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'صفحة '+title,apOKrFbP9IYHDyUVm7,111,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ff8WuQ0HaAmPEdo6SnMXr1sCeTzR)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url,jNvPEasplBCSkVZ0uWH):
	headers = {'User-Agent':qq62QA8h3pGxzCwWVeXIF7glKf(True)}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-EPISODES-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('items d-flex(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if len(RRztfCIs16MGxEHLJ25vDNAa7hpWT)>1:
		if '/season/' in RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]: MMHTKqYVvSrLojUt,Tfo9biLauWAQBSXw3GmeqkV = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0],RRztfCIs16MGxEHLJ25vDNAa7hpWT[1]
		else: MMHTKqYVvSrLojUt,Tfo9biLauWAQBSXw3GmeqkV = RRztfCIs16MGxEHLJ25vDNAa7hpWT[1],RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	else: MMHTKqYVvSrLojUt,Tfo9biLauWAQBSXw3GmeqkV = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0],RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	for gMmB3iopS0ZXrOFewhcxt in range(2):
		if jNvPEasplBCSkVZ0uWH: mode,type,cOUiow273ytu1GC5N0FJh = 116,'folder',MMHTKqYVvSrLojUt
		else: mode,type,cOUiow273ytu1GC5N0FJh = 112,'video',Tfo9biLauWAQBSXw3GmeqkV
		items = cBawilJXvK1m.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if jNvPEasplBCSkVZ0uWH and len(items)<2:
			jNvPEasplBCSkVZ0uWH = False
			continue
		for apOKrFbP9IYHDyUVm7,C8Qb5HdOey9Maf60Y3xZKGmhlDc1,uVpKOk8ZM0LvQ6UI in items:
			title = C8Qb5HdOey9Maf60Y3xZKGmhlDc1+avcfIls8w7gk69hYUErHxzQTXtm24j+uVpKOk8ZM0LvQ6UI
			qfpnsHw19BiaSktcXWbGA(type,r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,mode)
		break
	if not items and '/episodes' in nR2B1Wye7luXb5:
		iPHnReTNGdqm1Dg = cBawilJXvK1m.findall('class="breadcrumb"(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if iPHnReTNGdqm1Dg:
			cOUiow273ytu1GC5N0FJh = iPHnReTNGdqm1Dg[0]
			JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			if len(JCZVK86QTYwX4mfgOrod)>2:
				apOKrFbP9IYHDyUVm7 = JCZVK86QTYwX4mfgOrod[2]+'list'
				zRK9ruIt0ZFV4bgi(apOKrFbP9IYHDyUVm7)
	return
def bbmQeYGSTIv(url):
	headers = {'User-Agent':qq62QA8h3pGxzCwWVeXIF7glKf(True)}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-PLAY-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('class="actions(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall('href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	XoyUDTIx2L0NFKs4fbSaPvQ9Bt = '/watch/' in cOUiow273ytu1GC5N0FJh
	download = '/download/' in cOUiow273ytu1GC5N0FJh
	if   XoyUDTIx2L0NFKs4fbSaPvQ9Bt and not download: yge7aHmjxlZ0A9UcdtRqEp2I,IHn78xN4VTkSbZarvgzFYL = JCZVK86QTYwX4mfgOrod[0],eHdDoxhJCEPMZFVa2fg
	elif not XoyUDTIx2L0NFKs4fbSaPvQ9Bt and download: yge7aHmjxlZ0A9UcdtRqEp2I,IHn78xN4VTkSbZarvgzFYL = eHdDoxhJCEPMZFVa2fg,JCZVK86QTYwX4mfgOrod[0]
	elif XoyUDTIx2L0NFKs4fbSaPvQ9Bt and download: yge7aHmjxlZ0A9UcdtRqEp2I,IHn78xN4VTkSbZarvgzFYL = JCZVK86QTYwX4mfgOrod[0],JCZVK86QTYwX4mfgOrod[1]
	else: yge7aHmjxlZ0A9UcdtRqEp2I,IHn78xN4VTkSbZarvgzFYL = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	ppQOjlq2gaPkW = []
	if XoyUDTIx2L0NFKs4fbSaPvQ9Bt:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',yge7aHmjxlZ0A9UcdtRqEp2I,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-PLAY-2nd')
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('let servers(.*?)player',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		if eFUZtGJawsxyA42SRXl8fkBrnjo:
			KUTgdRBshwIZcbuv0LVC4 = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
			bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('"name":"(.*?)".*?"url":"(.*?)"',KUTgdRBshwIZcbuv0LVC4,cBawilJXvK1m.DOTALL)
			for title,apOKrFbP9IYHDyUVm7 in bLPGQ21sY8ie0fZ:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace('\\/','/')
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__watch'
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if download:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',IHn78xN4VTkSbZarvgzFYL,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-PLAY-3rd')
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		eFUZtGJawsxyA42SRXl8fkBrnjo = cBawilJXvK1m.findall('"servers"(.*?)info-container',L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if eFUZtGJawsxyA42SRXl8fkBrnjo:
			KUTgdRBshwIZcbuv0LVC4 = eFUZtGJawsxyA42SRXl8fkBrnjo[0]
			bLPGQ21sY8ie0fZ = cBawilJXvK1m.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',KUTgdRBshwIZcbuv0LVC4,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,title,s0s2bIZtWx8w3 in bLPGQ21sY8ie0fZ:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+'?named='+title+'__download'+'____'+s0s2bIZtWx8w3
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	import SOnwRtkA74
	SOnwRtkA74.q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(ppQOjlq2gaPkW,EERWJf1adv67,'video',url)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if not search:
		search = mJ1lHWKUPcZGezML7X2u9S()
		if not search: return
	search = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn+'/search?s='+search
	zRK9ruIt0ZFV4bgi(url,'search')
	return
def FADrXnGJYOuZlzU4t(url):
	url = url.split('/smartemadfilter?')[0]
	headers = {'User-Agent':qq62QA8h3pGxzCwWVeXIF7glKf(True)}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,'GET',url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = []
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('adv-filter(.*?)shows-container',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
		IVnCEBUYx5s3oleJkmdr2zWa0Ni = cBawilJXvK1m.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		V12b0HtGrWMkPqABj5nvioJZQ,yZOpoR4Ph53fHFAJbzv,ekNMoIJzswUSDVQf564 = zip(*IVnCEBUYx5s3oleJkmdr2zWa0Ni)
		IVnCEBUYx5s3oleJkmdr2zWa0Ni = zip(yZOpoR4Ph53fHFAJbzv,V12b0HtGrWMkPqABj5nvioJZQ,ekNMoIJzswUSDVQf564)
	return IVnCEBUYx5s3oleJkmdr2zWa0Ni
def SeP2jVnzMQ37(cOUiow273ytu1GC5N0FJh):
	items = cBawilJXvK1m.findall('value="(.*?)".*?>\s*(.*?)\s*<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	return items
def f5BCGNS0nFwMbpsZLtv9VJz(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	gXxmlY6uF78d4pHVhSMKyUCae2f = url.split('/smartemadfilter?')[0]
	qGa7FvNptsk = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,'url')
	url = url.replace(gXxmlY6uF78d4pHVhSMKyUCae2f,qGa7FvNptsk)
	url = url.replace('/smartemadfilter?','/?')
	return url
o0rBAEigunZKbdl7YhQ4eLxX = ['quality','year','genre','category']
vmQWHaV17urZ = ['category','genre','year']
def bbkDE5p9zlX6aV(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==eHdDoxhJCEPMZFVa2fg: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	else: goUS2aiGbZX1OQ,JVw3Ug6xQykdj2oM50 = filter.split('___')
	if type=='DEFINED_FILTER':
		if vmQWHaV17urZ[0]+'=' not in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = vmQWHaV17urZ[0]
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(vmQWHaV17urZ[0:-1])):
			if vmQWHaV17urZ[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+'=' in goUS2aiGbZX1OQ: U3d2hkuwDIj56 = vmQWHaV17urZ[dhcGSyo8Kn1mHZwvEAkzJ7NUq+1]
		aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+U3d2hkuwDIj56+'=0'
		e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+U3d2hkuwDIj56+'=0'
		r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7.strip('&')+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM.strip('&')
		jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'modified_filters')
		E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
	elif type=='FULL_FILTER':
		aSF3HMlugcs9G7Yz = QRKwbZae0G3m(goUS2aiGbZX1OQ,'modified_values')
		aSF3HMlugcs9G7Yz = zrHeZWCqQMOymk1d7anKpu0vEx8(aSF3HMlugcs9G7Yz)
		if JVw3Ug6xQykdj2oM50!=eHdDoxhJCEPMZFVa2fg: JVw3Ug6xQykdj2oM50 = QRKwbZae0G3m(JVw3Ug6xQykdj2oM50,'modified_filters')
		if JVw3Ug6xQykdj2oM50==eHdDoxhJCEPMZFVa2fg: E1Viom5L3684CTOFJ = url
		else: E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+JVw3Ug6xQykdj2oM50
		ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'أظهار قائمة الفيديو التي تم اختيارها ',ajHR9ABQl2buvm,111)
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+' [[   '+aSF3HMlugcs9G7Yz+'   ]]',ajHR9ABQl2buvm,111)
		qfpnsHw19BiaSktcXWbGA('link','[COLOR FFC89008] ===== ===== ===== [/COLOR]',eHdDoxhJCEPMZFVa2fg,9999)
	IVnCEBUYx5s3oleJkmdr2zWa0Ni = FADrXnGJYOuZlzU4t(url)
	dict = {}
	for name,BYy2jD5CQfh3rdxTAFzJ84Vk6E,cOUiow273ytu1GC5N0FJh in IVnCEBUYx5s3oleJkmdr2zWa0Ni:
		name = name.replace('كل ',eHdDoxhJCEPMZFVa2fg)
		items = SeP2jVnzMQ37(cOUiow273ytu1GC5N0FJh)
		if '=' not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = url
		if type=='DEFINED_FILTER':
			if U3d2hkuwDIj56!=BYy2jD5CQfh3rdxTAFzJ84Vk6E: continue
			elif len(items)<2:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==vmQWHaV17urZ[-1]:
					ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
					zRK9ruIt0ZFV4bgi(ajHR9ABQl2buvm)
				else: bbkDE5p9zlX6aV(E1Viom5L3684CTOFJ,'DEFINED_FILTER___'+r3bWKiRBqwE54ayCf0utvhDlx)
				return
			else:
				if BYy2jD5CQfh3rdxTAFzJ84Vk6E==vmQWHaV17urZ[-1]:
					ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
					qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',ajHR9ABQl2buvm,111)
				else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع',E1Viom5L3684CTOFJ,115,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		elif type=='FULL_FILTER':
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'=0'
			r3bWKiRBqwE54ayCf0utvhDlx = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'الجميع :'+name,E1Viom5L3684CTOFJ,114,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,r3bWKiRBqwE54ayCf0utvhDlx)
		dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E] = {}
		for q5qDOCzEe0Lv4ZyJbWnaPcpVsB,gW0v8nMxdq2 in items:
			if q5qDOCzEe0Lv4ZyJbWnaPcpVsB=='196533': gW0v8nMxdq2 = 'أفلام نيتفلكس'
			elif q5qDOCzEe0Lv4ZyJbWnaPcpVsB=='196531': gW0v8nMxdq2 = 'مسلسلات نيتفلكس'
			if gW0v8nMxdq2 in IVD2kBKhW8FeQLvxUm: continue
			dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E][q5qDOCzEe0Lv4ZyJbWnaPcpVsB] = gW0v8nMxdq2
			aTFm6bOUj7 = goUS2aiGbZX1OQ+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+gW0v8nMxdq2
			e2mXDvCIA45Hp81FPKhaiWJGuM = JVw3Ug6xQykdj2oM50+'&'+BYy2jD5CQfh3rdxTAFzJ84Vk6E+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
			nSjP8erv4yop = aTFm6bOUj7+'___'+e2mXDvCIA45Hp81FPKhaiWJGuM
			title = gW0v8nMxdq2+' :'#+dict[BYy2jD5CQfh3rdxTAFzJ84Vk6E]['0']
			title = gW0v8nMxdq2+' :'+name
			if type=='FULL_FILTER': qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,114,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
			elif type=='DEFINED_FILTER' and vmQWHaV17urZ[-2]+'=' in goUS2aiGbZX1OQ:
				jj8Ha32XYoVSZhNUsWyCPDmq4f = QRKwbZae0G3m(e2mXDvCIA45Hp81FPKhaiWJGuM,'modified_filters')
				E1Viom5L3684CTOFJ = url+'/smartemadfilter?'+jj8Ha32XYoVSZhNUsWyCPDmq4f
				ajHR9ABQl2buvm = f5BCGNS0nFwMbpsZLtv9VJz(E1Viom5L3684CTOFJ)
				qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,ajHR9ABQl2buvm,111)
			else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,url,115,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,nSjP8erv4yop)
	return
def QRKwbZae0G3m(yTtrwivOXY68ECP7ZHQgNdJ1,mode):
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.replace('=&','=0&')
	yTtrwivOXY68ECP7ZHQgNdJ1 = yTtrwivOXY68ECP7ZHQgNdJ1.strip('&')
	f8TRa4pzuVmo7c9gZ1j6rtPYOXqe = {}
	if '=' in yTtrwivOXY68ECP7ZHQgNdJ1:
		items = yTtrwivOXY68ECP7ZHQgNdJ1.split('&')
		for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in items:
			WW4LlMgICSbVYDfXKQdtzik,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split('=')
			f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[WW4LlMgICSbVYDfXKQdtzik] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = eHdDoxhJCEPMZFVa2fg
	for key in o0rBAEigunZKbdl7YhQ4eLxX:
		if key in list(f8TRa4pzuVmo7c9gZ1j6rtPYOXqe.keys()): q5qDOCzEe0Lv4ZyJbWnaPcpVsB = f8TRa4pzuVmo7c9gZ1j6rtPYOXqe[key]
		else: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = '0'
		if '%' not in q5qDOCzEe0Lv4ZyJbWnaPcpVsB: q5qDOCzEe0Lv4ZyJbWnaPcpVsB = vFDQstemyYANa(q5qDOCzEe0Lv4ZyJbWnaPcpVsB)
		if mode=='modified_values' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+' + '+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='modified_filters' and q5qDOCzEe0Lv4ZyJbWnaPcpVsB!='0': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		elif mode=='all': Q2OrNnmvR5HfY = Q2OrNnmvR5HfY+'&'+key+'='+q5qDOCzEe0Lv4ZyJbWnaPcpVsB
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip(' + ')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.strip('&')
	Q2OrNnmvR5HfY = Q2OrNnmvR5HfY.replace('=0','=')
	return Q2OrNnmvR5HfY
# -*- coding: utf-8 -*-
from dIxmaLQn3F import *
EERWJf1adv67 = 'ALFATIMI'
r07r9xeEFASJXluImT = '_FTM_'
q3QVhZaDEuo8t2ASj5vkn = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EERWJf1adv67][0]
zk3857F2rmgPIUvc = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
OM7Vd8YHLPfbDGzXNx = ['3030','628']
def alfBT1q2Mxg7GZdpS8jJzmc9FuiyEX(mode,url,text):
	if   mode==60: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = pDomkPy18JGi7xQ302dYVqHLM9WTCj()
	elif mode==61: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = zRK9ruIt0ZFV4bgi(url,text)
	elif mode==62: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	elif mode==63: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = bbmQeYGSTIv(url)
	elif mode==64: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = asWoPMBjYVl5(text)
	elif mode==69: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = ZZG8yFCkvXnPTgR6Jc(text)
	else: JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = False
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def pDomkPy18JGi7xQ302dYVqHLM9WTCj():
	qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+'بحث في الموقع',eHdDoxhJCEPMZFVa2fg,69,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'_REMEMBERRESULTS_')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'ما يتم مشاهدته الان',q3QVhZaDEuo8t2ASj5vkn,64,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'recent_viewed_vids')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'الاكثر مشاهدة',q3QVhZaDEuo8t2ASj5vkn,64,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'most_viewed_vids')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'اضيفت مؤخرا',q3QVhZaDEuo8t2ASj5vkn,64,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'recently_added_vids')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'فيديو عشوائي',q3QVhZaDEuo8t2ASj5vkn,64,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'random_vids')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'افلام ومسلسلات',q3QVhZaDEuo8t2ASj5vkn,61,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'-1')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'البرامج الدينية',q3QVhZaDEuo8t2ASj5vkn,61,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'-2')
	qfpnsHw19BiaSktcXWbGA('folder',EERWJf1adv67+'_SCRIPT_'+r07r9xeEFASJXluImT+'English Videos',q3QVhZaDEuo8t2ASj5vkn,61,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'-3')
	return eHdDoxhJCEPMZFVa2fg
def zRK9ruIt0ZFV4bgi(url,U3d2hkuwDIj56):
	LPdCM5OxYz = eHdDoxhJCEPMZFVa2fg
	if U3d2hkuwDIj56 not in ['-1','-2','-3']: LPdCM5OxYz = '?cat='+U3d2hkuwDIj56
	E1Viom5L3684CTOFJ = q3QVhZaDEuo8t2ASj5vkn+'/menu_level.php'+LPdCM5OxYz
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,'ALFATIMI-TITLES-1st')
	items = cBawilJXvK1m.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	tLVC75irdGxeI1zlocZTMp0R,PrQyXW5TAoS = False,False
	for apOKrFbP9IYHDyUVm7,title,count in items:
		title = zJRbA1YW2Eor(title)
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
		LPdCM5OxYz = cBawilJXvK1m.findall('cat=(.*?)&',apOKrFbP9IYHDyUVm7,cBawilJXvK1m.DOTALL)[0]
		if U3d2hkuwDIj56==LPdCM5OxYz: tLVC75irdGxeI1zlocZTMp0R = True
		elif tLVC75irdGxeI1zlocZTMp0R 	or (U3d2hkuwDIj56=='-1' and LPdCM5OxYz in zk3857F2rmgPIUvc)  						or (U3d2hkuwDIj56=='-2' and LPdCM5OxYz not in OM7Vd8YHLPfbDGzXNx and LPdCM5OxYz not in zk3857F2rmgPIUvc)  						or (U3d2hkuwDIj56=='-3' and LPdCM5OxYz in OM7Vd8YHLPfbDGzXNx):
							if count=='1': qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,63)
							else: qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,61,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LPdCM5OxYz)
							PrQyXW5TAoS = True
	if not PrQyXW5TAoS: tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	return
def tcJeirkgjMal25ofbE8zF4nxmOBw(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(bbfreYhcgwZlKEGVx7zRU,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,True,'ALFATIMI-EPISODES-1st')
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall('pagination(.*?)id="footer',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	items = cBawilJXvK1m.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	apOKrFbP9IYHDyUVm7 = eHdDoxhJCEPMZFVa2fg
	for PeLqCN5Ek8bB,title,apOKrFbP9IYHDyUVm7 in items:
		title = title.replace('Add',eHdDoxhJCEPMZFVa2fg).replace('to Quicklist',eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,63,PeLqCN5Ek8bB)
	RRztfCIs16MGxEHLJ25vDNAa7hpWT=cBawilJXvK1m.findall('(.*?)div',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	cOUiow273ytu1GC5N0FJh=RRztfCIs16MGxEHLJ25vDNAa7hpWT[0]
	cOUiow273ytu1GC5N0FJh=cBawilJXvK1m.findall('pagination(.*?)</div>',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[0]
	items=cBawilJXvK1m.findall('href="(.*?)".*?>(.*?)<',cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
	E1Viom5L3684CTOFJ = url.split('?')[0]
	for apOKrFbP9IYHDyUVm7,TTSQZBHtnbfOeLuxm3IqE in items:
		apOKrFbP9IYHDyUVm7 = E1Viom5L3684CTOFJ + apOKrFbP9IYHDyUVm7
		title = zJRbA1YW2Eor(TTSQZBHtnbfOeLuxm3IqE)
		title = 'صفحة ' + title
		qfpnsHw19BiaSktcXWbGA('folder',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,62)
	return apOKrFbP9IYHDyUVm7
def bbmQeYGSTIv(url):
	if 'videos.php' in url: url = tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,True,'ALFATIMI-PLAY-1st')
	items = cBawilJXvK1m.findall('playlistfile:"(.*?)"',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	IZkpyKSFVarcHwG1g6emqQv70h(url,EERWJf1adv67,'video')
	return
def asWoPMBjYVl5(U3d2hkuwDIj56):
	j6KOlzWGugZqmx0sPS = { 'mode' : U3d2hkuwDIj56 }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = GHIgY9AomX(j6KOlzWGugZqmx0sPS)
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = cBawilJXvK1m.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	for apOKrFbP9IYHDyUVm7,title,PeLqCN5Ek8bB in items:
		title = title.strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
		if 'http' not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = 'http:'+apOKrFbP9IYHDyUVm7
		qfpnsHw19BiaSktcXWbGA('video',r07r9xeEFASJXluImT+title,apOKrFbP9IYHDyUVm7,63,PeLqCN5Ek8bB)
	return
def ZZG8yFCkvXnPTgR6Jc(search):
	search,WWLbVhETM9ZCwm85f,showDialogs = F1T64yBoQa5b(search)
	if search==eHdDoxhJCEPMZFVa2fg: search = mJ1lHWKUPcZGezML7X2u9S()
	if search==eHdDoxhJCEPMZFVa2fg: return
	diojk6J5vzuRNDKmw = search.replace(avcfIls8w7gk69hYUErHxzQTXtm24j,'+')
	url = q3QVhZaDEuo8t2ASj5vkn + '/search_result.php?query=' + diojk6J5vzuRNDKmw
	tcJeirkgjMal25ofbE8zF4nxmOBw(url)
	return
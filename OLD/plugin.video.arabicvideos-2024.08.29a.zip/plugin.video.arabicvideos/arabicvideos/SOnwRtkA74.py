# -*- coding: utf-8 -*-
import sys as jjO4Xf7GBW8Dx2HR0tdP
qKXE8o1tuP = jjO4Xf7GBW8Dx2HR0tdP.version_info [0] == 2
QLZwvdlEhu3SGrkK = 2048
t9OZ2W8FQxpHAeN0C6Dr = 7
def UhXyg2sJIzZHf4oPbjlNRmtVexADQ3 (ShLnNbFQ2U1f7AImu6goVHrGjB9):
	global LLFxoujESTryRnv
	uBqCvFsi0yghQeJLKG9l = ord (ShLnNbFQ2U1f7AImu6goVHrGjB9 [-1])
	FFkaol2XndzcJTQVYR8sZ5 = ShLnNbFQ2U1f7AImu6goVHrGjB9 [:-1]
	IqSWT3rZRDl9AF5BnovxmVY = uBqCvFsi0yghQeJLKG9l % len (FFkaol2XndzcJTQVYR8sZ5)
	mmQhPgC2tyDWTiVG8ZcJpej9 = FFkaol2XndzcJTQVYR8sZ5 [:IqSWT3rZRDl9AF5BnovxmVY] + FFkaol2XndzcJTQVYR8sZ5 [IqSWT3rZRDl9AF5BnovxmVY:]
	if qKXE8o1tuP:
		wGB9MU23toFsd = unicode () .join ([unichr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	else:
		wGB9MU23toFsd = str () .join ([chr (ord (LAuyNg4TfXDZqBUHYMbsIdiw) - QLZwvdlEhu3SGrkK - (PP6rgUJGXn9tRWALCiIYhBDjpm + uBqCvFsi0yghQeJLKG9l) % t9OZ2W8FQxpHAeN0C6Dr) for PP6rgUJGXn9tRWALCiIYhBDjpm, LAuyNg4TfXDZqBUHYMbsIdiw in enumerate (mmQhPgC2tyDWTiVG8ZcJpej9)])
	return eval (wGB9MU23toFsd)
HkiMU0QrdzW3l6gwnT,XugxFprC26zGM,S8i3sBYoHWdTURpAgN=UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3,UhXyg2sJIzZHf4oPbjlNRmtVexADQ3
KKOXx3uWLqpTSahNUHiBF87PcZoe,jUcmHhgVvW0EdYOIfXeaDF,wY1p9mP03S8drbcH64t5WQkv=S8i3sBYoHWdTURpAgN,XugxFprC26zGM,HkiMU0QrdzW3l6gwnT
I5bUBGpPXn0W6,QQM0uTLKsZWel6m1arpjVz4vwcSN,LTN6DPEmrwehtZMy=wY1p9mP03S8drbcH64t5WQkv,jUcmHhgVvW0EdYOIfXeaDF,KKOXx3uWLqpTSahNUHiBF87PcZoe
dEwyQDiz0nhjV6MovaH7tIWYel92,TMKXOwyLdzhDj1Q6PmoigsbV4,bP01xn84BiQN=LTN6DPEmrwehtZMy,QQM0uTLKsZWel6m1arpjVz4vwcSN,I5bUBGpPXn0W6
w2vjZmdJuY7c,EX25Y0l8ILvz7QcRC,GGn0oFgBITbethla4qXL9sfkdMZNPH=bP01xn84BiQN,TMKXOwyLdzhDj1Q6PmoigsbV4,dEwyQDiz0nhjV6MovaH7tIWYel92
ehfEsaiJBSvbcULtNPVgykA2,J7divaGOCgq2SLfXpDzZYN58wc,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz=GGn0oFgBITbethla4qXL9sfkdMZNPH,EX25Y0l8ILvz7QcRC,w2vjZmdJuY7c
ToYfyBpWumeN3ZELc5JIDtV9gdvU,ilBWK5nXxg1do4jENGC07Zq,KW5bYS20wTF1LyCs9=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz,J7divaGOCgq2SLfXpDzZYN58wc,ehfEsaiJBSvbcULtNPVgykA2
Cp6c5tZe8I0PxnAW,NxXMrsTC5FniYuRBOK8,CKUiyEe28zsZ=KW5bYS20wTF1LyCs9,ilBWK5nXxg1do4jENGC07Zq,ToYfyBpWumeN3ZELc5JIDtV9gdvU
eNEhtuoi9gK8JaTpIXj,t3coAp06zvHrTl49bUVgx,ietolwsjpIPK7Fr=CKUiyEe28zsZ,NxXMrsTC5FniYuRBOK8,Cp6c5tZe8I0PxnAW
RqLvTrID0yMVeClpYcnZ16i3X,LyOR7f69iA,KQ3sCe9Pzh=ietolwsjpIPK7Fr,t3coAp06zvHrTl49bUVgx,eNEhtuoi9gK8JaTpIXj
egY8Jti0smdLM3h1VQRSW,ZAz3qtNh46EwTkg0dRWKD2XF7Q,f90fGrlSEObDsuiA3U=KQ3sCe9Pzh,LyOR7f69iA,RqLvTrID0yMVeClpYcnZ16i3X
from dIxmaLQn3F import *
EERWJf1adv67 = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᦴ")
ZBpPHRbhg8C9kvOlE5nzwcKJt62M = []
headers = {t3coAp06zvHrTl49bUVgx(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᦵ"):eHdDoxhJCEPMZFVa2fg}
BBa0Gi3tIbXcvoWEgd9zuk74 = [EX25Y0l8ILvz7QcRC(u"ࠩࡄࡏ࡜ࡇࡍࠨᦶ"),ietolwsjpIPK7Fr(u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬᦷ"),bP01xn84BiQN(u"ࠫࡎࡌࡉࡍࡏࠪᦸ"),Cp6c5tZe8I0PxnAW(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨᦹ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨᦺ"),eNEhtuoi9gK8JaTpIXj(u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪᦻ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡋࡓࡘ࡛࠭ᦼ"),f90fGrlSEObDsuiA3U(u"ࠩࡐ࠷࡚࠭ᦽ")]
e6OJYPXgC0UlMjawGVH8FAz95ZBDhk = [S8i3sBYoHWdTURpAgN(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫᦾ"),S8i3sBYoHWdTURpAgN(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩᦿ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡇࡋࡘࡃࡐࠫᧀ")]
def q2OzDpW8QFNMmaGXlhbx3tKkEd4rA(wROf6m4Ix73jtsdnZ1vpCDuV,source,type,url):
	if not wROf6m4Ix73jtsdnZ1vpCDuV:
		vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡩ࡭ࡳࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࡳࠡࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ᧁ")+source+egY8Jti0smdLM3h1VQRSW(u"ࠧࠡ࡟ࠣࠤࠥࠦࡔࡺࡲࡨ࠾ࠥࡡࠠࠨᧂ")+type+egY8Jti0smdLM3h1VQRSW(u"ࠨࠢࡠࠫᧃ"))
		JqCpiT7gGSDe = EeZHTwQUW2BuvJyIh(pyifuNFdxe,KW5bYS20wTF1LyCs9(u"ࠩࡧ࡭ࡨࡺࠧᧄ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ᧅ"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪᧆ"))
		SNaoWCmLHFk = b8bLFaejUB.strftime(RqLvTrID0yMVeClpYcnZ16i3X(u"࡙ࠬࠫ࠯ࠧࡰ࠲ࠪࡪࠠࠦࡊ࠽ࠩࡒ࠭ᧇ"),b8bLFaejUB.gmtime(a8HLTkO2ns49yGNgiroS))
		g6DoPQHrhS = SNaoWCmLHFk,url
		key = source+h597x8jYiAIBDzcedPslw6pQy+MCrWtwnF2TViZOD7z0pXgqI4+h597x8jYiAIBDzcedPslw6pQy+str(YB5Segc7IQ)
		sh3cDaZzUkKQFEAl74OryuPtGqJ = eHdDoxhJCEPMZFVa2fg
		if key not in list(JqCpiT7gGSDe.keys()): JqCpiT7gGSDe[key] = [g6DoPQHrhS]
		else:
			if url not in str(JqCpiT7gGSDe[key]): JqCpiT7gGSDe[key].append(g6DoPQHrhS)
			else: sh3cDaZzUkKQFEAl74OryuPtGqJ = eNEhtuoi9gK8JaTpIXj(u"࠭࡜࡯๊ࠢิฬࠦวๅใํำ๏๎ࠠๆ๊ฯ์ิࠦแ๋ࠢๅหห๋ษࠡษ็ๅ๏ี๊้้สฮࠥอไห์่๊ࠣࠦสฺ็็ࠫᧈ")
		lgowIShzeXtTAD31dOaRKGy = CKUiyEe28zsZ(u"࠱ࢗ")
		for key in list(JqCpiT7gGSDe.keys()):
			JqCpiT7gGSDe[key] = list(set(JqCpiT7gGSDe[key]))
			lgowIShzeXtTAD31dOaRKGy += len(JqCpiT7gGSDe[key])
		dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᧉ"),w2vjZmdJuY7c(u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ็้ࠥ๐ฬะ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠩ᧊")+sh3cDaZzUkKQFEAl74OryuPtGqJ+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩ࡟ࡲࡡࡴࠠๅๆ฼่๊ࠦวๅสิ๊ฬ๋ฬࠡ์ๅ์๊ࠦศอ็฼ࠤ็อฦๆหࠣฬฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢํะิࠦไ่ษ้้ࠣ็วหࠢไ๎ิ๐่๊ࠡึ์ๆฺ๊ࠦำูࠤ฾๊๊ไࠢส่อืๆศ็ฯࠤศ์ࠠหำึ่ࠥํะ่ࠢส่็อฦๆหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ฻้ำ๊อ๋ࠠืหัࠥ฿ฯะ้สࠤ࠺ࠦแ๋ัํ์์อสࠨ᧋")+wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡠࡳࡢ࡮ࠨ᧌")+ilBWK5nXxg1do4jENGC07Zq(u"ࠫ฾ีฯࠡษ็ๅ๏ี๊้้สฮࠥ็๊ࠡษ็ๆฬฬๅสࠢส่ว์่๊ࠠࠣ࠾ࠥࠦࠧ᧍")+str(lgowIShzeXtTAD31dOaRKGy))
		if lgowIShzeXtTAD31dOaRKGy>=RqLvTrID0yMVeClpYcnZ16i3X(u"࠷࢘"):
			zf7iFX1auw0bQU = VinwUNFtrZTh0oPs2zm(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᧎"),KQ3sCe9Pzh(u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧ᧏"))
			if zf7iFX1auw0bQU==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠴࢙"):
				GPmHKrpXaBEzbI10f8Vcylw = eHdDoxhJCEPMZFVa2fg
				for key in list(JqCpiT7gGSDe.keys()):
					GPmHKrpXaBEzbI10f8Vcylw += kDUv7ouWrcgMe6OipQJm+key
					pbYMSGBAd7rPI2quJzgEnVcZ8D4WHy = sorted(JqCpiT7gGSDe[key],reverse=rDceXBpHkfVUYRJ3tIx95Z,key=lambda BQCUgxd3PfA1uhterw: BQCUgxd3PfA1uhterw[x1Oa8bBf36EwsLMirtFc])
					for SNaoWCmLHFk,url in pbYMSGBAd7rPI2quJzgEnVcZ8D4WHy:
						GPmHKrpXaBEzbI10f8Vcylw += kDUv7ouWrcgMe6OipQJm+SNaoWCmLHFk+h597x8jYiAIBDzcedPslw6pQy+zrHeZWCqQMOymk1d7anKpu0vEx8(url)
					GPmHKrpXaBEzbI10f8Vcylw += bP01xn84BiQN(u"ࠧ࡝ࡰ࡟ࡲࠬ᧐")
				import YmtfK6LolI
				gZdOM2jYEfV = YmtfK6LolI.CpsdhEGBHQZYJcS23wjrxzn(wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡘ࡬ࡨࡪࡵࡳࠨ᧑"),eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᧒"),eHdDoxhJCEPMZFVa2fg,GPmHKrpXaBEzbI10f8Vcylw)
				if gZdOM2jYEfV: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LyOR7f69iA(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᧓"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫฯ๋ࠠศๆศีุอไࠡส้ะฬำࠧ᧔"))
				else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ᧕"),ehfEsaiJBSvbcULtNPVgykA2(u"࠭แีๆอࠤ฾๋ไ๋หࠣห้หัิษ็ࠫ᧖"))
			if zf7iFX1auw0bQU!=-TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠵࢚"):
				JqCpiT7gGSDe = {}
				k5L96NenKBwpSYWv(pyifuNFdxe,Cp6c5tZe8I0PxnAW(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪ᧗"),dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧ᧘"))
		if JqCpiT7gGSDe: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ᧙"),f90fGrlSEObDsuiA3U(u"ࠪࡗࡎ࡚ࡅࡔࡡࡈࡖࡗࡕࡒࡔࠩ᧚"),JqCpiT7gGSDe,ICRfWub2vqlor0Q)
		return
	wROf6m4Ix73jtsdnZ1vpCDuV = list(set(wROf6m4Ix73jtsdnZ1vpCDuV))
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = TkUhDliFqrwZcgaYCj9KAJNLu(wROf6m4Ix73jtsdnZ1vpCDuV,source)
	ulUSB8M5gRQrhecqfkntWpKa3 = str(ppQOjlq2gaPkW).count(NxXMrsTC5FniYuRBOK8(u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ᧛"))
	S3aNKZ0jgCdXxVW = str(ppQOjlq2gaPkW).count(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ᧜"))
	YWPFwIvK0pj3Z2tkd1A = len(ppQOjlq2gaPkW)-ulUSB8M5gRQrhecqfkntWpKa3-S3aNKZ0jgCdXxVW
	fNZkOUrmQwx = I5bUBGpPXn0W6(u"࠭ๅีษ๊ำฮࡀࠧ᧝")+str(ulUSB8M5gRQrhecqfkntWpKa3)+Cp6c5tZe8I0PxnAW(u"ࠧࠡࠢࠣࠤฯำๅ๋ๆ࠽ࠫ᧞")+str(S3aNKZ0jgCdXxVW)+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࠢࠣࠤࠥษฮา๋࠽ࠫ᧟")+str(YWPFwIvK0pj3Z2tkd1A)
	if not ppQOjlq2gaPkW: zbiGC4DUKEx,CZBQor8PhWYnplUtkzvH6 = bP01xn84BiQN(u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭᧠"),eHdDoxhJCEPMZFVa2fg
	else:
		add = J7divaGOCgq2SLfXpDzZYN58wc(u"࠵࢛")
		if not any(q5qDOCzEe0Lv4ZyJbWnaPcpVsB in source for q5qDOCzEe0Lv4ZyJbWnaPcpVsB in BBa0Gi3tIbXcvoWEgd9zuk74):
			add = EX25Y0l8ILvz7QcRC(u"࠷࢜")
			ppQOjlq2gaPkW = [EX25Y0l8ILvz7QcRC(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡣࡆࡒࡌࡠࡎࡌࡒࡐ࡙ࠧ᧡")]+list(ppQOjlq2gaPkW)
			FBITEXGDfe2mcCxnQs6ktMdy9HJh = [SbyWQGMDnV+ietolwsjpIPK7Fr(u"ࠫๆำีࠡฮ่๎฾ࠦวๅีํีๆืวหࠩ᧢")+Nat0Dx9puRUWCsgz6JyFhY3]+list(FBITEXGDfe2mcCxnQs6ktMdy9HJh)
		while YchIv6N09BaWPEj4tieAnluKZrRXT:
			CZBQor8PhWYnplUtkzvH6,zbiGC4DUKEx = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
			if add and len(ppQOjlq2gaPkW)==S8i3sBYoHWdTURpAgN(u"࠳࢞"): iLcCSnPyKYWs3xkQ0p14 = LyOR7f69iA(u"࠱࢝")
			else: iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(fNZkOUrmQwx,FBITEXGDfe2mcCxnQs6ktMdy9HJh)
			if iLcCSnPyKYWs3xkQ0p14==-RqLvTrID0yMVeClpYcnZ16i3X(u"࠳࢟"): zbiGC4DUKEx = EX25Y0l8ILvz7QcRC(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ᧣")
			elif add and iLcCSnPyKYWs3xkQ0p14==ehfEsaiJBSvbcULtNPVgykA2(u"࠳ࢠ"):
				zbiGC4DUKEx = RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪ᧤")
				JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = uu2MfWD8YnUksacXdCJ01qA(FBITEXGDfe2mcCxnQs6ktMdy9HJh[add:],ppQOjlq2gaPkW[add:],source)
				if JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
					rkBEVKJvcAWp6b5TqIPZHnhMtsmR = []
					for qg3DwCuZVcyLpnzEjtvFaHKkMs,RWksc38o1dJzAmeaQj7uGxbvKlZhUL,QQzeH5q1iEcYxXGn7,cNsU4Xbq2fld0Z7KYv8V1xP,Elp0LQsGwZNrY in JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
						if Elp0LQsGwZNrY: rkBEVKJvcAWp6b5TqIPZHnhMtsmR.append((qg3DwCuZVcyLpnzEjtvFaHKkMs,RWksc38o1dJzAmeaQj7uGxbvKlZhUL,QQzeH5q1iEcYxXGn7,cNsU4Xbq2fld0Z7KYv8V1xP,Elp0LQsGwZNrY))
					if rkBEVKJvcAWp6b5TqIPZHnhMtsmR: FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,errors,RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod = zip(*rkBEVKJvcAWp6b5TqIPZHnhMtsmR)
					else:
						dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᧥"),t3coAp06zvHrTl49bUVgx(u"ࠨๆ็วุ็ࠠๅ็ࠣ๎ฯ๋ࠠฦ์ฯหิࠦำ๋ำไีฬะࠠอ์าอࠥ็๊้ࠡำหࠥอไโ์า๎ํࠦ࠮࠯ࠢะหํ๊ࠠฤ่ࠣฮอำหࠡ฻้ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎๋่ࠥศไ฼ࠤศิั๊ࠩ᧦"))
						zbiGC4DUKEx = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ᧧")
						break
					fNZkOUrmQwx = I5bUBGpPXn0W6(u"ࠪหู้๊าใิหฯࠦวๅฮํำฮࠦࠨࠡࠩ᧨")+str(len(ppQOjlq2gaPkW))+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࠥ࠯ࠧ᧩")
					add = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴ࢡ")
					continue
			else:
				JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = uu2MfWD8YnUksacXdCJ01qA([FBITEXGDfe2mcCxnQs6ktMdy9HJh[iLcCSnPyKYWs3xkQ0p14]],[ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]],source)
				if JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
					title,apOKrFbP9IYHDyUVm7,errors,RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod = JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1[x1Oa8bBf36EwsLMirtFc]
					if NxXMrsTC5FniYuRBOK8(u"ู๊ࠬาใิࠫ᧪") in title and CKUiyEe28zsZ(u"࠭࠲ๆฮ๊์้࠸ࠧ᧫") in title:
						vR9cOpMtk51j(bGQ2Ok7RNi,WMyqfm31ka2jICwiE(EERWJf1adv67)+ietolwsjpIPK7Fr(u"࡙ࠧࠡࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡸ࡫࡬ࡦࡥࡷࡩࡩࠦࡳࡦࡴࡹࡩࡷࠦࠠࠡࡕࡨࡶࡻ࡫ࡲ࠻ࠢ࡞ࠤࠬ᧬")+title+Cp6c5tZe8I0PxnAW(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ᧭")+apOKrFbP9IYHDyUVm7+eNEhtuoi9gK8JaTpIXj(u"ࠩࠣࡡࠬ᧮"))
						import YmtfK6LolI
						YmtfK6LolI.Tbzw54Kc8JBgtA()
						zbiGC4DUKEx = t3coAp06zvHrTl49bUVgx(u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ᧯")
					else:
						zbiGC4DUKEx,CZBQor8PhWYnplUtkzvH6,e8UJpoK72tOlWfr0wRs3BA9xn = aEQkdLrqF5IC2pOt(title,apOKrFbP9IYHDyUVm7,errors,RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod,source,type)
			if zbiGC4DUKEx in [LTN6DPEmrwehtZMy(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᧰"),J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ᧱"),eNEhtuoi9gK8JaTpIXj(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ᧲"),f90fGrlSEObDsuiA3U(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ᧳"),wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ᧴")] or len(ppQOjlq2gaPkW)==jUcmHhgVvW0EdYOIfXeaDF(u"࠶ࢢ")+add: break
			elif zbiGC4DUKEx in [NxXMrsTC5FniYuRBOK8(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ᧵"),EX25Y0l8ILvz7QcRC(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ᧶"),NxXMrsTC5FniYuRBOK8(u"ࠫࡹࡸࡩࡦࡦࠪ᧷")]: break
			elif zbiGC4DUKEx not in [NxXMrsTC5FniYuRBOK8(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠳ࡰࡧࡣࡲ࡫࡮ࡶࠩ᧸"),I5bUBGpPXn0W6(u"࠭ࡨࡵࡶࡳࡷࠬ᧹")]:
				if kDUv7ouWrcgMe6OipQJm in CZBQor8PhWYnplUtkzvH6: CZBQor8PhWYnplUtkzvH6 = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧ࡜ࡎࡈࡊ࡙ࡣࠠࠡࠩ᧺")+CZBQor8PhWYnplUtkzvH6.replace(kDUv7ouWrcgMe6OipQJm,HkiMU0QrdzW3l6gwnT(u"ࠨ࡞ࡱ࡟ࡑࡋࡆࡕ࡟ࠣࠤࠬ᧻"))
				dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ᧼"),EX25Y0l8ILvz7QcRC(u"ࠪหู้๊าใิࠤ้๋๋ࠠ฻่่ࠥาัษࠢึ๎ึ็ัࠡ฼ํี์࠭᧽")+kDUv7ouWrcgMe6OipQJm+CZBQor8PhWYnplUtkzvH6,profile=t3coAp06zvHrTl49bUVgx(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩ᧾"))
	if zbiGC4DUKEx==S8i3sBYoHWdTURpAgN(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ᧿") and len(FBITEXGDfe2mcCxnQs6ktMdy9HJh)>Cp6c5tZe8I0PxnAW(u"࠶ࢣ"): dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᨀ"),bP01xn84BiQN(u"ࠧิ์ิๅึࠦ็ัษࠣห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠥาัษࠢไ๎ิ๐่ࠡ฼ํี์࠭ᨁ")+kDUv7ouWrcgMe6OipQJm+CZBQor8PhWYnplUtkzvH6,profile=ietolwsjpIPK7Fr(u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮ࡡࡰࡩࡩ࡯ࡵ࡮ࡨࡲࡲࡹ࠭ᨂ"))
	elif zbiGC4DUKEx in [dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᨃ"),NxXMrsTC5FniYuRBOK8(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫᨄ")] and CZBQor8PhWYnplUtkzvH6!=eHdDoxhJCEPMZFVa2fg: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᨅ"),CZBQor8PhWYnplUtkzvH6,profile=GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥ࡭ࡦࡦ࡬ࡹࡲ࡬࡯࡯ࡶࠪᨆ"))
	return zbiGC4DUKEx
EEkpBwQcYeDF1l0gCVf,eiLBMxpW4clFUI1RDEbafZ3w8P9,a1FuRnTyGNcgjp,XdMecaI2PTCORGq75g0itblp,egrIanvP2qSOtUCbyBuH5W1QF,kn95ly07gtcC = [],[],[],[],[],[]
def uu2MfWD8YnUksacXdCJ01qA(YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV,source):
	global EEkpBwQcYeDF1l0gCVf,eiLBMxpW4clFUI1RDEbafZ3w8P9,a1FuRnTyGNcgjp,XdMecaI2PTCORGq75g0itblp,egrIanvP2qSOtUCbyBuH5W1QF,kn95ly07gtcC
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1,B8d5PqjYoIMrhT,new = [],[],[]
	Rpfbit9Qjk4zYoMu0q(rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z,rDceXBpHkfVUYRJ3tIx95Z)
	count = len(wROf6m4Ix73jtsdnZ1vpCDuV)
	for HIlROZrLU1bpzD0KPGqja7BVc in range(count):
		EEkpBwQcYeDF1l0gCVf.append(None)
		eiLBMxpW4clFUI1RDEbafZ3w8P9.append(None)
		a1FuRnTyGNcgjp.append(None)
		XdMecaI2PTCORGq75g0itblp.append(None)
		egrIanvP2qSOtUCbyBuH5W1QF.append(None)
		kn95ly07gtcC.append(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠰ࢤ"))
		title = YYs45omUWpDLndclV[HIlROZrLU1bpzD0KPGqja7BVc]
		apOKrFbP9IYHDyUVm7 = wROf6m4Ix73jtsdnZ1vpCDuV[HIlROZrLU1bpzD0KPGqja7BVc].strip(avcfIls8w7gk69hYUErHxzQTXtm24j).strip(egY8Jti0smdLM3h1VQRSW(u"࠭ࠦࠨᨇ")).strip(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡀࠩᨈ")).strip(t3coAp06zvHrTl49bUVgx(u"ࠨ࠱ࠪᨉ"))
		if count>NSudqlOzja: dqKGMYgJxSF8Ub1kotlsP936Ww7B(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩไัฺࠦำ๋ำไีࠥืโๆࠢࠣࠫᨊ")+str(HIlROZrLU1bpzD0KPGqja7BVc+KQ3sCe9Pzh(u"࠲ࢥ")),title)
		if source in e6OJYPXgC0UlMjawGVH8FAz95ZBDhk: nuVCO58S4cEjfyeHRIhsw3W(title,apOKrFbP9IYHDyUVm7,source,HIlROZrLU1bpzD0KPGqja7BVc)
		else:
			aa5lrVF97o2ckusvf4IibRJGnxj3N = apOKrFbP9IYHDyUVm7.split(CKUiyEe28zsZ(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᨋ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠳ࢦ"))[x1Oa8bBf36EwsLMirtFc]
			oOTWvyMrVxCQe53 = EeZHTwQUW2BuvJyIh(pyifuNFdxe,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡱ࡯ࡳࡵࠩᨌ"),RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡊࠧᨍ"),aa5lrVF97o2ckusvf4IibRJGnxj3N)
			if oOTWvyMrVxCQe53 and (oOTWvyMrVxCQe53[CKUiyEe28zsZ(u"࠳ࢧ")] or oOTWvyMrVxCQe53[f90fGrlSEObDsuiA3U(u"࠶ࢨ")]): EEkpBwQcYeDF1l0gCVf[HIlROZrLU1bpzD0KPGqja7BVc] = oOTWvyMrVxCQe53
			else:
				wNUcIMmJhd3KLo = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=nuVCO58S4cEjfyeHRIhsw3W,args=(title,apOKrFbP9IYHDyUVm7,source,HIlROZrLU1bpzD0KPGqja7BVc))
				wNUcIMmJhd3KLo.start()
				B8d5PqjYoIMrhT.append(wNUcIMmJhd3KLo)
				new.append(HIlROZrLU1bpzD0KPGqja7BVc)
				b8bLFaejUB.sleep(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠵࠴࠷࠶ࢩ"))
	timeout = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠼࠰ࢪ") if source==S8i3sBYoHWdTURpAgN(u"࠭ࡁࡌ࡙ࡄࡑࠬᨎ") else KW5bYS20wTF1LyCs9(u"࠳࠱ࢫ")
	B0ZiepTkgjAq8lWxCKyX1 = b8bLFaejUB.time()
	for wNUcIMmJhd3KLo in B8d5PqjYoIMrhT: wNUcIMmJhd3KLo.join(timeout)
	for HIlROZrLU1bpzD0KPGqja7BVc in range(count):
		title = YYs45omUWpDLndclV[HIlROZrLU1bpzD0KPGqja7BVc]
		apOKrFbP9IYHDyUVm7 = wROf6m4Ix73jtsdnZ1vpCDuV[HIlROZrLU1bpzD0KPGqja7BVc].strip(avcfIls8w7gk69hYUErHxzQTXtm24j).strip(ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࠧࠩᨏ")).strip(bP01xn84BiQN(u"ࠨࡁࠪᨐ")).strip(ietolwsjpIPK7Fr(u"ࠩ࠲ࠫᨑ"))
		lkou0eECPJ = YchIv6N09BaWPEj4tieAnluKZrRXT if kn95ly07gtcC[HIlROZrLU1bpzD0KPGqja7BVc]+NSudqlOzja>timeout else rDceXBpHkfVUYRJ3tIx95Z
		if EEkpBwQcYeDF1l0gCVf[HIlROZrLU1bpzD0KPGqja7BVc] and (EEkpBwQcYeDF1l0gCVf[HIlROZrLU1bpzD0KPGqja7BVc][TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠱ࢬ")] or EEkpBwQcYeDF1l0gCVf[HIlROZrLU1bpzD0KPGqja7BVc][CKUiyEe28zsZ(u"࠴ࢭ")]): MMgbiAsukdIntoeW2F,uVpKOk8ZM0LvQ6UI,bmsN7D3kPQ8Beh5RS0M4ng2FcY = EEkpBwQcYeDF1l0gCVf[HIlROZrLU1bpzD0KPGqja7BVc]
		elif lkou0eECPJ: MMgbiAsukdIntoeW2F,uVpKOk8ZM0LvQ6UI,bmsN7D3kPQ8Beh5RS0M4ng2FcY = XugxFprC26zGM(u"ࠪࡠࡳࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡕ࡫ࡰࡩࡩࠦࡏࡶࡶࠣࠬࠬᨒ")+str(timeout)+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࠥࡹࡥࡤࡱࡱࡨࡸ࠯ࠧᨓ"),[],[]
		else: MMgbiAsukdIntoeW2F,uVpKOk8ZM0LvQ6UI,bmsN7D3kPQ8Beh5RS0M4ng2FcY = eNEhtuoi9gK8JaTpIXj(u"ࠬࡢ࡮ࡇࡣ࡬ࡰࡪࡪ࠺ࠡࠢࡆࡳࡺࡲࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫᨔ"),[],[]
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1.append([title,apOKrFbP9IYHDyUVm7,MMgbiAsukdIntoeW2F,uVpKOk8ZM0LvQ6UI,bmsN7D3kPQ8Beh5RS0M4ng2FcY])
		if HIlROZrLU1bpzD0KPGqja7BVc in new:
			aa5lrVF97o2ckusvf4IibRJGnxj3N = apOKrFbP9IYHDyUVm7.split(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᨕ"),wY1p9mP03S8drbcH64t5WQkv(u"࠴ࢮ"))[x1Oa8bBf36EwsLMirtFc]
			CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࠩᨖ"),aa5lrVF97o2ckusvf4IibRJGnxj3N,[MMgbiAsukdIntoeW2F,uVpKOk8ZM0LvQ6UI,bmsN7D3kPQ8Beh5RS0M4ng2FcY],bbfreYhcgwZlKEGVx7zRU)
	Rpfbit9Qjk4zYoMu0q(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg)
	return JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1
def nuVCO58S4cEjfyeHRIhsw3W(GfhcsvCWIon,url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2):
	global EEkpBwQcYeDF1l0gCVf,kn95ly07gtcC
	kn95ly07gtcC[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴ࢯ")
	B0ZiepTkgjAq8lWxCKyX1 = b8bLFaejUB.time()
	vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+HkiMU0QrdzW3l6gwnT(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩᨗ")+GfhcsvCWIon+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ᨘࠥ࠭")+url+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࠤࡢ࠭ᨙ"))
	apOKrFbP9IYHDyUVm7,KKRvMmipdA3uG4JFwnPzxlby = url,eHdDoxhJCEPMZFVa2fg
	oqubg1xTHK9 = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨᨚ")
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = Z85ap4wMUdBiOQeJYEbL2h9gGVK(url,source)
	if CZBQor8PhWYnplUtkzvH6==ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᨛ"):
		EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᨜"),[],[]
		kn95ly07gtcC[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = b8bLFaejUB.time()-B0ZiepTkgjAq8lWxCKyX1
		return EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2]
	elif XugxFprC26zGM(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᨝") in CZBQor8PhWYnplUtkzvH6:
		KKRvMmipdA3uG4JFwnPzxlby = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠫ᨞")
		apOKrFbP9IYHDyUVm7 = m8hUPGa329VWyFexMio(ppQOjlq2gaPkW)[x1Oa8bBf36EwsLMirtFc]
		oqubg1xTHK9,KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = IVw4BfqGgT(KKRvMmipdA3uG4JFwnPzxlby,apOKrFbP9IYHDyUVm7,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2)
		if KKRvMmipdA3uG4JFwnPzxlby==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᨟"):
			kn95ly07gtcC[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = b8bLFaejUB.time()-B0ZiepTkgjAq8lWxCKyX1
			return KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	elif CZBQor8PhWYnplUtkzvH6: KKRvMmipdA3uG4JFwnPzxlby = LTN6DPEmrwehtZMy(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪᨠ")+CZBQor8PhWYnplUtkzvH6.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)[:TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠽࠶ࢰ")]
	if ppQOjlq2gaPkW:
		ppQOjlq2gaPkW = m8hUPGa329VWyFexMio(ppQOjlq2gaPkW)
		vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+bP01xn84BiQN(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧᨡ")+GfhcsvCWIon+ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩᨢ")+oqubg1xTHK9+eNEhtuoi9gK8JaTpIXj(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪᨣ")+url+f90fGrlSEObDsuiA3U(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧᨤ")+apOKrFbP9IYHDyUVm7+jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࡸࡀࠠ࡜ࠢࠪᨥ")+str(ppQOjlq2gaPkW)+Cp6c5tZe8I0PxnAW(u"ࠩࠣࡡࠬᨦ"))
	else: vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+ietolwsjpIPK7Fr(u"ࠪࠤࠥࠦࡒࡦࡵࡲࡰࡻ࡯࡮ࡨࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪᨧ")+GfhcsvCWIon+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࠥࡣࠠࠡࠢࡒࡶ࡮࡭ࡩ࡯ࡣ࡯࠾ࠥࡡࠠࠨᨨ")+url+wY1p9mP03S8drbcH64t5WQkv(u"ࠬࠦ࡝ࠡࠢࠣࡐ࡮ࡴ࡫࠻ࠢ࡞ࠤࠬᨩ")+apOKrFbP9IYHDyUVm7+LTN6DPEmrwehtZMy(u"࠭ࠠ࡞ࠢࠣࠤࡊࡸࡲࡰࡴࡶ࠾ࠥࡡࠠࠨᨪ")+KKRvMmipdA3uG4JFwnPzxlby+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࠡ࡟ࠪᨫ"))
	KKRvMmipdA3uG4JFwnPzxlby = zrHeZWCqQMOymk1d7anKpu0vEx8(KKRvMmipdA3uG4JFwnPzxlby)
	EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	kn95ly07gtcC[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = b8bLFaejUB.time()-B0ZiepTkgjAq8lWxCKyX1
	return KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def aEQkdLrqF5IC2pOt(title,apOKrFbP9IYHDyUVm7,CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,source,type=eHdDoxhJCEPMZFVa2fg):
	if CZBQor8PhWYnplUtkzvH6==XugxFprC26zGM(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᨬ"): return CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	elif ppQOjlq2gaPkW:
		while YchIv6N09BaWPEj4tieAnluKZrRXT:
			if len(ppQOjlq2gaPkW)==LyOR7f69iA(u"࠷ࢱ"): iLcCSnPyKYWs3xkQ0p14 = LyOR7f69iA(u"࠰ࢲ")
			else: iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨᨭ"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
			if iLcCSnPyKYWs3xkQ0p14==-RqLvTrID0yMVeClpYcnZ16i3X(u"࠲ࢳ"): zbiGC4DUKEx = Cp6c5tZe8I0PxnAW(u"ࠪࡸࡷ࡯ࡥࡥࠩᨮ")
			else:
				gxNRd9u84co2 = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
				vR9cOpMtk51j(eQb20ZUHIjXE3xqsCWLfkghRGBFaNY,WMyqfm31ka2jICwiE(EERWJf1adv67)+t3coAp06zvHrTl49bUVgx(u"ࠫࠥࠦࠠࡑ࡮ࡤࡽ࡮ࡴࡧࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࡀࠠ࡜ࠢࠪᨯ")+title+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࠦ࡝ࠡࠢࠣࡓࡷ࡯ࡧࡪࡰࡤࡰ࠿࡛ࠦࠡࠩᨰ")+apOKrFbP9IYHDyUVm7+NxXMrsTC5FniYuRBOK8(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧᨱ")+str(gxNRd9u84co2)+t3coAp06zvHrTl49bUVgx(u"ࠧࠡ࡟ࠪᨲ"))
				if LyOR7f69iA(u"ࠨ࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࠫᨳ") in gxNRd9u84co2 and ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠩᨴ") in gxNRd9u84co2:
					MMgbiAsukdIntoeW2F,qqVw1UMpJmejYh5ioKIbnFGH,e8UJpoK72tOlWfr0wRs3BA9xn = P8d1JkD5oOqVLxf7Wjm(gxNRd9u84co2)
					if e8UJpoK72tOlWfr0wRs3BA9xn: gxNRd9u84co2 = e8UJpoK72tOlWfr0wRs3BA9xn[x1Oa8bBf36EwsLMirtFc]
					else: gxNRd9u84co2 = eHdDoxhJCEPMZFVa2fg
				if not gxNRd9u84co2: zbiGC4DUKEx = f90fGrlSEObDsuiA3U(u"ࠪࡹࡳࡸࡥࡴࡱ࡯ࡺࡪࡪࠧᨵ")
				else: zbiGC4DUKEx = IZkpyKSFVarcHwG1g6emqQv70h(gxNRd9u84co2,source,type)
			if zbiGC4DUKEx in [EX25Y0l8ILvz7QcRC(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬᨶ"),KW5bYS20wTF1LyCs9(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭ᨷ"),HkiMU0QrdzW3l6gwnT(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࡠ࠴ࡱࡨࡤࡳࡥ࡯ࡷࠪᨸ")] or len(ppQOjlq2gaPkW)==LTN6DPEmrwehtZMy(u"࠳ࢴ"): break
			elif zbiGC4DUKEx in [f90fGrlSEObDsuiA3U(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧᨹ"),XugxFprC26zGM(u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩᨺ"),KW5bYS20wTF1LyCs9(u"ࠩࡷࡶ࡮࡫ࡤࠨᨻ")]: break
			else: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᨼ"),XugxFprC26zGM(u"ࠫฬ๊ๅๅใฺ่๊๊ࠣࠦ็็ࠤัืศࠡ็็ๅࠥเ๊า้ࠪᨽ"))
	else:
		zbiGC4DUKEx = jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩᨾ")
		if llr1C3SIFjViqLDtZP(apOKrFbP9IYHDyUVm7): zbiGC4DUKEx = IZkpyKSFVarcHwG1g6emqQv70h(apOKrFbP9IYHDyUVm7,source,type)
	return zbiGC4DUKEx,CZBQor8PhWYnplUtkzvH6,ppQOjlq2gaPkW
def ULdxvsN7JK(url,source):
	E1Viom5L3684CTOFJ,qYbiDSNfEgj6,GfhcsvCWIon,LLSGfXKAcDusNJtRYihbOzeojqdC,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,DfV0FjXSuriL6O1aM5hPZlQt8 = url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	if ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᨿ") in url:
		E1Viom5L3684CTOFJ,qYbiDSNfEgj6 = url.split(w2vjZmdJuY7c(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨᩀ"),eNEhtuoi9gK8JaTpIXj(u"࠴ࢵ"))
		qYbiDSNfEgj6 = qYbiDSNfEgj6+egY8Jti0smdLM3h1VQRSW(u"ࠨࡡࡢࠫᩁ")+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡢࡣࠬᩂ")+bP01xn84BiQN(u"ࠪࡣࡤ࠭ᩃ")+HkiMU0QrdzW3l6gwnT(u"ࠫࡤࡥࠧᩄ")+f90fGrlSEObDsuiA3U(u"ࠬࡥ࡟ࠨᩅ")
		Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,DfV0FjXSuriL6O1aM5hPZlQt8,wGp3f1bmBdPS5icYFqDNZxj2UEzoM, = qYbiDSNfEgj6.split(ilBWK5nXxg1do4jENGC07Zq(u"࠭࡟ࡠࠩᩆ"))[:TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺ࢶ")]
	if not s0s2bIZtWx8w3: s0s2bIZtWx8w3 = KW5bYS20wTF1LyCs9(u"ࠧ࠱ࠩᩇ")
	else: s0s2bIZtWx8w3 = s0s2bIZtWx8w3.replace(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡲࠪᩈ"),eHdDoxhJCEPMZFVa2fg).replace(avcfIls8w7gk69hYUErHxzQTXtm24j,eHdDoxhJCEPMZFVa2fg)
	E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.strip(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡂࠫᩉ")).strip(HkiMU0QrdzW3l6gwnT(u"ࠪ࠳ࠬᩊ")).strip(CKUiyEe28zsZ(u"ࠫࠫ࠭ᩋ"))
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬ࡮࡯ࡴࡶࠪᩌ"))
	if Pe9ETSvwUGBnkC1hO: LLSGfXKAcDusNJtRYihbOzeojqdC = Pe9ETSvwUGBnkC1hO
	else: LLSGfXKAcDusNJtRYihbOzeojqdC = GfhcsvCWIon
	LLSGfXKAcDusNJtRYihbOzeojqdC = b31wAB8mhaz2rXHoJFlfvDugtsOj(LLSGfXKAcDusNJtRYihbOzeojqdC,w2vjZmdJuY7c(u"࠭࡮ࡢ࡯ࡨࠫᩍ"))
	Pe9ETSvwUGBnkC1hO = Pe9ETSvwUGBnkC1hO.replace(f90fGrlSEObDsuiA3U(u"ࠧๆสสุึ࠭ᩎ"),eHdDoxhJCEPMZFVa2fg).replace(jUcmHhgVvW0EdYOIfXeaDF(u"ࠨีํีๆืࠧᩏ"),eHdDoxhJCEPMZFVa2fg).replace(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩส่ࠥ࠭ᩐ"),avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	qYbiDSNfEgj6 = qYbiDSNfEgj6.replace(LyOR7f69iA(u"้ࠪออิาࠩᩑ"),eHdDoxhJCEPMZFVa2fg).replace(KW5bYS20wTF1LyCs9(u"ุࠫ๐ัโำࠪᩒ"),eHdDoxhJCEPMZFVa2fg).replace(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬอไࠡࠩᩓ"),avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	LLSGfXKAcDusNJtRYihbOzeojqdC = LLSGfXKAcDusNJtRYihbOzeojqdC.replace(LTN6DPEmrwehtZMy(u"࠭ๅษษืีࠬᩔ"),eHdDoxhJCEPMZFVa2fg).replace(eNEhtuoi9gK8JaTpIXj(u"ࠧิ์ิๅึ࠭ᩕ"),eHdDoxhJCEPMZFVa2fg).replace(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨษ็ࠤࠬᩖ"),avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
	return E1Viom5L3684CTOFJ,qYbiDSNfEgj6,GfhcsvCWIon,LLSGfXKAcDusNJtRYihbOzeojqdC,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,DfV0FjXSuriL6O1aM5hPZlQt8
def kqvWahMKsBN4pHotTgD3zEe7(url,source):
	kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO,IITWl8rZUFOqDJdvxQMe1askm40i,dIOzovmchxnCsFGfARLaTJQDXEY,NNFQ4KLy5WqbvhJgBsxG9p,a6R5ogfCL2V90MjEXTJ,oqubg1xTHK9 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,None,None,None,None,None
	E1Viom5L3684CTOFJ,qYbiDSNfEgj6,GfhcsvCWIon,LLSGfXKAcDusNJtRYihbOzeojqdC,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,DfV0FjXSuriL6O1aM5hPZlQt8 = ULdxvsN7JK(url,source)
	if Cp6c5tZe8I0PxnAW(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᩗ") in url:
		if   type==CKUiyEe28zsZ(u"ࠪࡩࡲࡨࡥࡥࠩᩘ"): type = avcfIls8w7gk69hYUErHxzQTXtm24j+EX25Y0l8ILvz7QcRC(u"๊ࠫ็ึๅࠩᩙ")
		elif type==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡽࡡࡵࡥ࡫ࠫᩚ"): type = avcfIls8w7gk69hYUErHxzQTXtm24j+HkiMU0QrdzW3l6gwnT(u"࠭ࠥๆึส๋ิฯࠧᩛ")
		elif type==LTN6DPEmrwehtZMy(u"ࠧࡣࡱࡷ࡬ࠬᩜ"): type = avcfIls8w7gk69hYUErHxzQTXtm24j+KW5bYS20wTF1LyCs9(u"ࠨࠧࠨู้อ็ะหࠣ์ฯำๅ๋ๆࠪᩝ")
		elif type==bP01xn84BiQN(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᩞ"): type = avcfIls8w7gk69hYUErHxzQTXtm24j+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࠩࠪࠫสฮ็ํ่ࠬ᩟")
		elif type==eHdDoxhJCEPMZFVa2fg: type = avcfIls8w7gk69hYUErHxzQTXtm24j+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"᩠ࠫࠪࠫࠥࠦࠩ")
		if N63IHpMe8P!=eHdDoxhJCEPMZFVa2fg:
			if LTN6DPEmrwehtZMy(u"ࠬࡳࡰ࠵ࠩᩡ") not in N63IHpMe8P: N63IHpMe8P = eNEhtuoi9gK8JaTpIXj(u"࠭ࠥࠨᩢ")+N63IHpMe8P
			N63IHpMe8P = avcfIls8w7gk69hYUErHxzQTXtm24j+N63IHpMe8P
		if s0s2bIZtWx8w3!=eHdDoxhJCEPMZFVa2fg:
			s0s2bIZtWx8w3 = HkiMU0QrdzW3l6gwnT(u"ࠧࠦࠧࠨࠩࠪࠫࠥࠦࠧࠪᩣ")+s0s2bIZtWx8w3
			s0s2bIZtWx8w3 = avcfIls8w7gk69hYUErHxzQTXtm24j+s0s2bIZtWx8w3[-eNEhtuoi9gK8JaTpIXj(u"࠾ࢷ"):]
	if   KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡃࡎࡓࡆࡓࠧᩤ")		in source: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif w2vjZmdJuY7c(u"ࠩࡄࡏ࡜ࡇࡍࠨᩥ")		in source: IITWl8rZUFOqDJdvxQMe1askm40i	= wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡥࡰࡽࡡ࡮ࠩᩦ")
	elif dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ᩧ")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif t3coAp06zvHrTl49bUVgx(u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫᩨ")	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif CKUiyEe28zsZ(u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨᩩ")		in source: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧᩪ")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif f90fGrlSEObDsuiA3U(u"ࠨࡨࡤࡷࡪࡲࠧᩫ")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡷ࠻ࡲ࡫ࡥ࡭ࠩᩬ")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif f90fGrlSEObDsuiA3U(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪᩭ")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡲࡿࡥࡨࡻࡹ࡭ࡵ࠭ᩮ")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif EX25Y0l8ILvz7QcRC(u"ࠬ࡬ࡡ࡫ࡧࡵࠫᩯ")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭แอำࠪᩰ")			in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= NxXMrsTC5FniYuRBOK8(u"ࠧࡧࡣ࡭ࡩࡷ࠭ᩱ")
	elif ietolwsjpIPK7Fr(u"ࠨใ็ื฼๐ๆࠨᩲ")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡳࡥࡱ࡫ࡳࡵ࡫ࡱࡩࠬᩳ")
	elif EX25Y0l8ILvz7QcRC(u"ࠪ࡫ࡩࡸࡩࡷࡧࠪᩴ")		in E1Viom5L3684CTOFJ:   IITWl8rZUFOqDJdvxQMe1askm40i	= wY1p9mP03S8drbcH64t5WQkv(u"ࠫ࡬ࡵ࡯ࡨ࡮ࡨࠫ᩵")
	elif KQ3sCe9Pzh(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ᩶")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif KW5bYS20wTF1LyCs9(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭᩷")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ᩸")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡰࡨࡻࡨ࡯࡭ࡢࠩ᩹")		in Pe9ETSvwUGBnkC1hO:   IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif NxXMrsTC5FniYuRBOK8(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧ᩺")	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡦࡴࡱࡲࡢࠩ᩻")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif I5bUBGpPXn0W6(u"ࠫࡹࡼࡦࡶࡰࠪ᩼")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif NxXMrsTC5FniYuRBOK8(u"ࠬࡺࡶ࡬ࡵࡤࠫ᩽")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif bP01xn84BiQN(u"࠭ࡡ࡯ࡣࡹ࡭ࡩࢀࠧ᩾")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰ᩿ࠩ")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif t3coAp06zvHrTl49bUVgx(u"ࠨࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪ᪀")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif EX25Y0l8ILvz7QcRC(u"ࠩࡶ࡬ࡦ࡮ࡥࡥ࠶ࡸࠫ᪁")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif bP01xn84BiQN(u"ࠪࡧ࡮ࡳࡡ࠵ࡷࠪ᪂")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif KW5bYS20wTF1LyCs9(u"ࠫࡪ࡭ࡹ࡯ࡱࡺࠫ᪃")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif w2vjZmdJuY7c(u"ࠬ࡮ࡡ࡭ࡣࡦ࡭ࡲࡧࠧ᪄")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif CKUiyEe28zsZ(u"࠭ࡣࡪ࡯ࡤࡥࡧࡪ࡯ࠨ᪅")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif egY8Jti0smdLM3h1VQRSW(u"ࠧࡳࡧࡧࡱࡴࡪࡸࠨ᪆")	 	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= Cp6c5tZe8I0PxnAW(u"ࠨࡴࡨࡨࡲࡵࡤࡹࠩ᪇")
	elif eNEhtuoi9gK8JaTpIXj(u"ࠩࡼࡳࡺࡺࡵࠨ᪈")	 	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫ᪉")
	elif f90fGrlSEObDsuiA3U(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫ᪊")	 	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭᪋")
	elif w2vjZmdJuY7c(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ᪌")	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif LyOR7f69iA(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ᪍")	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= CKUiyEe28zsZ(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬ᪎")
	elif t3coAp06zvHrTl49bUVgx(u"ࠩࡨ࡫ࡾ࠴ࡢࡦࡵࡷࠫ᪏")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷ࠵ࠬ᪐")
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ᪑")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= S8i3sBYoHWdTURpAgN(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠹ࠧ᪒")
	elif LyOR7f69iA(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨ᪓")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩ᪔")
	elif eNEhtuoi9gK8JaTpIXj(u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ᪕")	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= I5bUBGpPXn0W6(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ᪖")
	elif Cp6c5tZe8I0PxnAW(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭᪗")	in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࡮ࡴࡦ࡭ࡣࡰࠫ᪘")
	elif NxXMrsTC5FniYuRBOK8(u"ࠬࡨࡵࡻࡼࡹࡶࡱ࠭᪙")		in GfhcsvCWIon: IITWl8rZUFOqDJdvxQMe1askm40i	= egY8Jti0smdLM3h1VQRSW(u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ᪚")
	elif dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡢࡴࡤࡦࡱࡵࡡࡥࡵࠪ᪛")	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= S8i3sBYoHWdTURpAgN(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫ᪜")
	elif eNEhtuoi9gK8JaTpIXj(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪ᪝")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫ᪞")
	elif eNEhtuoi9gK8JaTpIXj(u"ࠫࡨࡧࡴࡤࡪ࠱࡭ࡸ࠭᪟")	 	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= Cp6c5tZe8I0PxnAW(u"ࠬࡩࡡࡵࡥ࡫ࠫ᪠")
	elif ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡦࡪ࡮ࡨࡶ࡮ࡵࠧ᪡")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= egY8Jti0smdLM3h1VQRSW(u"ࠧࡧ࡫࡯ࡩࡷ࡯࡯ࠨ᪢")
	elif LTN6DPEmrwehtZMy(u"ࠨࡸ࡬ࡨࡧࡳࠧ᪣")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= eNEhtuoi9gK8JaTpIXj(u"ࠩࡹ࡭ࡩࡨ࡭ࠨ᪤")
	elif CKUiyEe28zsZ(u"ࠪࡺ࡮ࡪࡨࡥࠩ᪥")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡲࡿࡶࡪࡦࠪ᪦")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡳࡹࡷ࡫࡬ࡨࠬᪧ")		in GfhcsvCWIon: a6R5ogfCL2V90MjEXTJ	= LLSGfXKAcDusNJtRYihbOzeojqdC
	elif wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡶࡪࡦࡨࡳࡧ࡯࡮ࠨ᪨")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= LTN6DPEmrwehtZMy(u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ᪩")
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡩࡲࡺ࡮ࡪࠧ᪪")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࡪࡳࡻ࡯ࡤࠨ᪫")
	elif w2vjZmdJuY7c(u"ࠪࡰ࡮࡯ࡶࡪࡦࡨࡳࠬ᪬") 	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= XugxFprC26zGM(u"ࠫࡱ࡯ࡩࡷ࡫ࡧࡩࡴ࠭᪭")
	elif wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡳࡰ࠵ࡷࡳࡰࡴࡧࡤࠨ᪮")	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= LyOR7f69iA(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩ᪯")
	elif ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡱࡷࡥࡰ࡮ࡩࡶࡪࡦࡨࡳࠬ᪰")	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡲࡸࡦࡱ࡯ࡣࡷ࡫ࡧࡩࡴ࠭᪱")
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡵࡥࡵ࡯ࡤࡷ࡫ࡧࡩࡴ࠭᪲") 	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧ᪳")
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬ᪴")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= XugxFprC26zGM(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ᪵࠭")
	elif LyOR7f69iA(u"࠭ࡵࡱࡲ᪶ࠪ") 			in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡶࡲࡥࡳࡲ᪷࠭")
	elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡷࡳࡦ᪸ࠬ") 			in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡸࡴࡧࡵ࡭ࠨ᪹")
	elif ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡹࡶࡲ࡯ࡢࡦ᪺ࠪ") 		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫ᪻")
	elif wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡼࡣࡴࡶࡵࡩࡦࡳࠧ᪼") 	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ᪽")
	elif XugxFprC26zGM(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ᪾")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= CKUiyEe28zsZ(u"ࠨࡸ࡬ࡨࡧࡵࡢࠨᪿ")
	elif CKUiyEe28zsZ(u"ࠩࡹ࡭ࡩࡵࡺࡢᫀࠩ") 		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= NxXMrsTC5FniYuRBOK8(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪ᫁")
	elif J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨ᫂") 	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= XugxFprC26zGM(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰ᫃ࠩ")
	elif LyOR7f69iA(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧ᫄ࠪ")	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= egY8Jti0smdLM3h1VQRSW(u"ࠧࡸ࡫ࡱࡸࡻ࠴࡬ࡪࡸࡨࠫ᫅")
	elif XugxFprC26zGM(u"ࠨࡼ࡬ࡴࡵࡿࡳࡩࡣࡵࡩࠬ᫆")	in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= LyOR7f69iA(u"ࠩࡽ࡭ࡵࡶࡹࡴࡪࡤࡶࡪ࠭᫇")
	elif egY8Jti0smdLM3h1VQRSW(u"ࠪ࡬ࡩ࠳ࡣࡥࡰࠪ᫈")		in GfhcsvCWIon: dIOzovmchxnCsFGfARLaTJQDXEY	= HkiMU0QrdzW3l6gwnT(u"ࠫ࡭ࡪ࠭ࡤࡦࡱࠫ᫉")
	if   IITWl8rZUFOqDJdvxQMe1askm40i:	kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬิวึ᫊ࠩ"),IITWl8rZUFOqDJdvxQMe1askm40i
	elif a6R5ogfCL2V90MjEXTJ:		kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO = wY1p9mP03S8drbcH64t5WQkv(u"࠭ࠥๆฯาำࠬ᫋"),a6R5ogfCL2V90MjEXTJ
	elif dIOzovmchxnCsFGfARLaTJQDXEY:		kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬᫌ"),dIOzovmchxnCsFGfARLaTJQDXEY
	elif NNFQ4KLy5WqbvhJgBsxG9p:	kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO = HkiMU0QrdzW3l6gwnT(u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧᫍ"),NNFQ4KLy5WqbvhJgBsxG9p
	elif oqubg1xTHK9:	kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩᫎ"),LLSGfXKAcDusNJtRYihbOzeojqdC
	else:			kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫ᫏"),LLSGfXKAcDusNJtRYihbOzeojqdC
	return kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3
def Z85ap4wMUdBiOQeJYEbL2h9gGVK(url,source):
	E1Viom5L3684CTOFJ,a6R5ogfCL2V90MjEXTJ,GfhcsvCWIon,LLSGfXKAcDusNJtRYihbOzeojqdC,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,DfV0FjXSuriL6O1aM5hPZlQt8 = ULdxvsN7JK(url,source)
	if   w2vjZmdJuY7c(u"ࠫࡆࡑࡏࡂࡏࠪ᫐")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = Fea5Jby2kR(E1Viom5L3684CTOFJ,Pe9ETSvwUGBnkC1hO)
	elif dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡇࡋࡘࡃࡐࠫ᫑")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = CUTcRwrWs9(E1Viom5L3684CTOFJ,type,s0s2bIZtWx8w3)
	elif KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨ᫒")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = UR8FgEY7kJ(E1Viom5L3684CTOFJ)
	elif f90fGrlSEObDsuiA3U(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ᫓")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = e27zOM5Tmb(E1Viom5L3684CTOFJ)
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡻࡲࡹࡹࡻࠧ᫔")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = e27zOM5Tmb(E1Viom5L3684CTOFJ)
	elif egY8Jti0smdLM3h1VQRSW(u"ࠩࡼ࠶ࡺ࠴ࡢࡦࠩ᫕")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = e27zOM5Tmb(E1Viom5L3684CTOFJ)
	elif HkiMU0QrdzW3l6gwnT(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪ᫖")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = hYSQu6oesZ(E1Viom5L3684CTOFJ)
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭᫗")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = fHC5Ku3jMg(E1Viom5L3684CTOFJ)
	elif eNEhtuoi9gK8JaTpIXj(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧ᫘")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = wLhCnjZVsc(E1Viom5L3684CTOFJ)
	elif w2vjZmdJuY7c(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ᫙")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = GPkJLhHnO3(E1Viom5L3684CTOFJ)
	elif ietolwsjpIPK7Fr(u"ࠧࡔࡊࡒࡊࡍࡇࠧ᫚")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = Zm95OxkaWF(E1Viom5L3684CTOFJ)
	elif egY8Jti0smdLM3h1VQRSW(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ᫛")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = BUiuKe0MF7(E1Viom5L3684CTOFJ,DfV0FjXSuriL6O1aM5hPZlQt8)
	elif RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪ᫜")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = hKeTC741rb(E1Viom5L3684CTOFJ)
	elif S8i3sBYoHWdTURpAgN(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪ᫝")		in source: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = ulF3fqkQYR(E1Viom5L3684CTOFJ)
	elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭᫞")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = ySw97VLqvm(E1Viom5L3684CTOFJ)
	elif TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨ᫟")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = RRXJPG8pa2(E1Viom5L3684CTOFJ)
	elif RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭᫠")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = tXvBOKzIeChDNFwHlL6Vr0fbUiRA8(E1Viom5L3684CTOFJ)
	elif ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ᫡")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = Wuqtfv8FCG(E1Viom5L3684CTOFJ)
	elif TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪ᫢")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = Wuqtfv8FCG(E1Viom5L3684CTOFJ)
	elif Cp6c5tZe8I0PxnAW(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩ᫣")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = rNYwsf7vbW(E1Viom5L3684CTOFJ)
	elif bP01xn84BiQN(u"ࠪࡸࡻ࡬ࡵ࡯ࠩ᫤")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = y8geHuIGD9(E1Viom5L3684CTOFJ)
	elif egY8Jti0smdLM3h1VQRSW(u"ࠫࡹࡼ࡫ࡴࡣࠪ᫥")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = y8geHuIGD9(E1Viom5L3684CTOFJ)
	elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧ᫦")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = y8geHuIGD9(E1Viom5L3684CTOFJ)
	elif bP01xn84BiQN(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨ᫧")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = VkzL4nFWeO(E1Viom5L3684CTOFJ)
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩ᫨")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = jAQcYTetKX(E1Viom5L3684CTOFJ)
	elif t3coAp06zvHrTl49bUVgx(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪ᫩")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = ONGvmkJl9UdPCZQK1bIteFS8R(E1Viom5L3684CTOFJ)
	elif ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡹࡷ࠹ࡻࠧ᫪")			in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = YCszToelGr(E1Viom5L3684CTOFJ)
	elif egY8Jti0smdLM3h1VQRSW(u"ࠪࡪࡦࡰࡥࡳࠩ᫫")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = bwc3If0s54(E1Viom5L3684CTOFJ)
	elif EX25Y0l8ILvz7QcRC(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬ᫬")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = iiyOUr0L5P(E1Viom5L3684CTOFJ)
	elif Cp6c5tZe8I0PxnAW(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭᫭")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = iiyOUr0L5P(E1Viom5L3684CTOFJ)
	elif jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶࠪ᫮")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = HH3fO9vDLW(E1Viom5L3684CTOFJ)
	elif egY8Jti0smdLM3h1VQRSW(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪ᫯")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = HH3fO9vDLW(E1Viom5L3684CTOFJ)
	elif dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ᫰")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = QoJZN84LHx(E1Viom5L3684CTOFJ)
	elif RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩ᫱")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = l5ikFnmCqh(E1Viom5L3684CTOFJ)
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡦࡴࡱࡲࡢࠩ᫲")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = lKEUgnXfoA(E1Viom5L3684CTOFJ)
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ᫳")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = xp3idWHVor(E1Viom5L3684CTOFJ)
	elif ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ᫴")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = bbrLcgqASe(E1Viom5L3684CTOFJ)
	elif f90fGrlSEObDsuiA3U(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ᫵")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = TYaLP7hqv8(E1Viom5L3684CTOFJ)
	elif egY8Jti0smdLM3h1VQRSW(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ᫶")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	elif S8i3sBYoHWdTURpAgN(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ᫷")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = EELl8BIS4h(E1Viom5L3684CTOFJ)
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨ᫸")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = YFehn7k38D(E1Viom5L3684CTOFJ)
	elif EX25Y0l8ILvz7QcRC(u"ࠪࡹࡵࡨࡡ࡮ࠩ᫹") 		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	else: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = bP01xn84BiQN(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᫺"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	if CZBQor8PhWYnplUtkzvH6 and CZBQor8PhWYnplUtkzvH6!=dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᫻"): CZBQor8PhWYnplUtkzvH6 = LyOR7f69iA(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩ᫼")+CZBQor8PhWYnplUtkzvH6
	return CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def VW9HZqAbQTifBp0e7atNgcLoP(CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW):
	RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod = [],[]
	for title,apOKrFbP9IYHDyUVm7 in zip(FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW):
		if llr1C3SIFjViqLDtZP(apOKrFbP9IYHDyUVm7):
			RnjhvEwkQqYtb94WpBxX5P.append(title)
			JCZVK86QTYwX4mfgOrod.append(apOKrFbP9IYHDyUVm7)
	if not JCZVK86QTYwX4mfgOrod and not CZBQor8PhWYnplUtkzvH6: CZBQor8PhWYnplUtkzvH6 = XugxFprC26zGM(u"ࠧࡇࡣ࡬ࡰࡪࡪࠧ᫽")
	return CZBQor8PhWYnplUtkzvH6,RnjhvEwkQqYtb94WpBxX5P,JCZVK86QTYwX4mfgOrod
def IVw4BfqGgT(KKRvMmipdA3uG4JFwnPzxlby,url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2):
	global EEkpBwQcYeDF1l0gCVf,eiLBMxpW4clFUI1RDEbafZ3w8P9,a1FuRnTyGNcgjp,XdMecaI2PTCORGq75g0itblp,egrIanvP2qSOtUCbyBuH5W1QF
	grRNXh05S23dyjcIo = []
	VZQEimXRBP8LdaHT4pIvSxUGr = (LyOR7f69iA(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩ᫾"),[],[])
	eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2],a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2],XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2],egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = VZQEimXRBP8LdaHT4pIvSxUGr,VZQEimXRBP8LdaHT4pIvSxUGr,VZQEimXRBP8LdaHT4pIvSxUGr,VZQEimXRBP8LdaHT4pIvSxUGr
	y519VAXC4EQvgqNPpe = [drCKekmUwst6,YQrP62lufcTSvMjHsK4OzC,zuJXMtOoBR7qGpdbc5KTI6Se,XeyczgF4MA]
	for n78THilV0dMtpfA2q in y519VAXC4EQvgqNPpe:
		EMxBeCnNyL = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=n78THilV0dMtpfA2q,args=(url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2))
		EMxBeCnNyL.start()
		if eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᫿") or (not eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		if a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==w2vjZmdJuY7c(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᬀ") or (not a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		if XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==ilBWK5nXxg1do4jENGC07Zq(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᬁ") or (not XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		if egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==NxXMrsTC5FniYuRBOK8(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᬂ") or (not egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		b8bLFaejUB.sleep(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠶࠮࠸࠷ࢸ"))
		grRNXh05S23dyjcIo.append(EMxBeCnNyL)
	timeout,step = iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴࠲ࢺ"),J7divaGOCgq2SLfXpDzZYN58wc(u"࠲ࢹ")
	for VZQEimXRBP8LdaHT4pIvSxUGr in range(timeout//step):
		if eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᬃ") or (not eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		if a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==egY8Jti0smdLM3h1VQRSW(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᬄ") or (not a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		if XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==bP01xn84BiQN(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᬅ") or (not XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		if egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc]==jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᬆ") or (not egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][x1Oa8bBf36EwsLMirtFc] and egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2][FB0pIzAoK8wqgd3UiY5]): break
		b8bLFaejUB.sleep(step)
	for EMxBeCnNyL in grRNXh05S23dyjcIo: EMxBeCnNyL.join(S8i3sBYoHWdTURpAgN(u"࠳ࢻ"))
	sig6o0V1HfvKYSx7yBOdDbtmL = f90fGrlSEObDsuiA3U(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠩᬇ")
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2]
	ppQOjlq2gaPkW = m8hUPGa329VWyFexMio(ppQOjlq2gaPkW)
	EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	if CZBQor8PhWYnplUtkzvH6==bP01xn84BiQN(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᬈ") or ppQOjlq2gaPkW: return sig6o0V1HfvKYSx7yBOdDbtmL,CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	KKRvMmipdA3uG4JFwnPzxlby += QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠵࠾ࠥࠦࠧᬉ")+CZBQor8PhWYnplUtkzvH6.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)[:HkiMU0QrdzW3l6gwnT(u"࠻࠴ࢼ")]
	sig6o0V1HfvKYSx7yBOdDbtmL = NxXMrsTC5FniYuRBOK8(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠬᬊ")
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2]
	ppQOjlq2gaPkW = m8hUPGa329VWyFexMio(ppQOjlq2gaPkW)
	EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	if CZBQor8PhWYnplUtkzvH6==w2vjZmdJuY7c(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᬋ") or ppQOjlq2gaPkW: return sig6o0V1HfvKYSx7yBOdDbtmL,CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	KKRvMmipdA3uG4JFwnPzxlby += Cp6c5tZe8I0PxnAW(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠹࠺ࠡࠢࠪᬌ")+CZBQor8PhWYnplUtkzvH6.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)[:Cp6c5tZe8I0PxnAW(u"࠼࠵ࢽ")]
	sig6o0V1HfvKYSx7yBOdDbtmL = bP01xn84BiQN(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠴ࠨᬍ")
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2]
	ppQOjlq2gaPkW = m8hUPGa329VWyFexMio(ppQOjlq2gaPkW)
	EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	if CZBQor8PhWYnplUtkzvH6==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᬎ") or ppQOjlq2gaPkW: return sig6o0V1HfvKYSx7yBOdDbtmL,CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	KKRvMmipdA3uG4JFwnPzxlby += KQ3sCe9Pzh(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠶࠽ࠤࠥ࠭ᬏ")+CZBQor8PhWYnplUtkzvH6.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)[:NxXMrsTC5FniYuRBOK8(u"࠽࠶ࢾ")]
	sig6o0V1HfvKYSx7yBOdDbtmL = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠸ࠫᬐ")
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2]
	ppQOjlq2gaPkW = m8hUPGa329VWyFexMio(ppQOjlq2gaPkW)
	EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	if CZBQor8PhWYnplUtkzvH6==f90fGrlSEObDsuiA3U(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᬑ") or ppQOjlq2gaPkW: return sig6o0V1HfvKYSx7yBOdDbtmL,CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	KKRvMmipdA3uG4JFwnPzxlby += ehfEsaiJBSvbcULtNPVgykA2(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠺ࡀࠠࠡࠩᬒ")+CZBQor8PhWYnplUtkzvH6.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)[:I5bUBGpPXn0W6(u"࠾࠰ࢿ")]
	EEkpBwQcYeDF1l0gCVf[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	return sig6o0V1HfvKYSx7yBOdDbtmL,KKRvMmipdA3uG4JFwnPzxlby,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def drCKekmUwst6(url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2):
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡰࡤࡱࡪ࠭ᬓ"))
	ppQOjlq2gaPkW = []
	if Cp6c5tZe8I0PxnAW(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧᬔ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = xp3idWHVor(url)
	elif bP01xn84BiQN(u"ࠪ࡫ࡴࡵࡧ࡭ࡧࡸࡷࡪࡸࡣࡰࠩᬕ") in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = E3Qx8lesbjw7UXnVyYhLT1z5FmO6(url)
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡾࡵࡵࡵࡷࠪᬖ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = e27zOM5Tmb(url)
	elif bP01xn84BiQN(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬᬗ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = e27zOM5Tmb(url)
	elif QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡰࡩࡱࡷࡳࡸ࠴ࡡࡱࡲ࠱࡫ࠬᬘ")	in url   : CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = EMlqfRzI4WnLOFbD9PvmN7TuacgK(url)
	elif EX25Y0l8ILvz7QcRC(u"ࠧ࡮ࡱࡶ࡬ࡦ࡮ࡤࡢࠩᬙ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = P8d1JkD5oOqVLxf7Wjm(url)
	elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡨࡤࡷࡪࡲࡨࡥࠩᬚ")		in url   : CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = UR8FgEY7kJ(url)
	elif bP01xn84BiQN(u"ࠩࡤࡶࡦࡨ࡬ࡰࡣࡧࡷࠬᬛ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = vahHPgqTB9esS(url)
	elif QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡥࡷࡩࡨࡪࡸࡨࠫᬜ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = Wz0UY6VL3Dct1m4uxrq5CwAMZS(url)
	elif eNEhtuoi9gK8JaTpIXj(u"ࠫࡧࡻࡺࡻࡸࡵࡰࠬᬝ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = CJxyZec1NEGhtp50Pw(url)
	elif ehfEsaiJBSvbcULtNPVgykA2(u"ࠬ࡫࠵ࡵࡵࡤࡶࠬᬞ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = TT9mADZgiHJXr7bckMz6tjeYdCP(url)
	elif S8i3sBYoHWdTURpAgN(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬᬟ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = KZF3QBrkyJwI5g(url)
	elif NxXMrsTC5FniYuRBOK8(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪᬠ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = KZF3QBrkyJwI5g(url)
	elif ietolwsjpIPK7Fr(u"ࠨࡷࡳࡦࡦࡳࠧᬡ") 		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[url]
	elif ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫᬢ") 	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = h8hUwAB3iKLYHRpkWE59xZ1v(url)
	elif GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭ᬣ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = UdIgbLwQ6OPMBxjEXARyH40JCufvp(url)
	elif KQ3sCe9Pzh(u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨᬤ") 	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = rB5Iypubvh42OtawzxWMK8(url)
	elif ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡺ࡯ࡱ࠶ࡷࡳࡵ࠭ᬥ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = YqS0Uw1i46rzPtDMe(url)
	elif J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡵࡱࡤࠪᬦ") 			in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = FFeQa1DvosIbwSV3LtPNkUGC(url)
	elif LTN6DPEmrwehtZMy(u"ࠧࡶࡲࡳࠫᬧ") 			in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = FFeQa1DvosIbwSV3LtPNkUGC(url)
	elif w2vjZmdJuY7c(u"ࠨࡷࡴࡰࡴࡧࡤࠨᬨ") 		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = h67PMUgvqLSOBWXV3tprms25Cy1H(url)
	elif t3coAp06zvHrTl49bUVgx(u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫᬩ") 	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = hkiWPtMdzVONqnIlYAmpXcvrgLZR(url)
	elif RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡺ࡮ࡪࡢࡰࡤࠪᬪ")		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = EFKuhwgWURIm(url)
	elif ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡻ࡯ࡤࡰࡼࡤࠫᬫ") 		in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = q9qVyFAwfN4zg5HPQnWMGxCR(url)
	elif LTN6DPEmrwehtZMy(u"ࠬࡽࡡࡵࡥ࡫ࡺ࡮ࡪࡥࡰࠩᬬ") 	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = wHU1RT5ngXjKD(url)
	elif ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡷࡪࡰࡷࡺ࠳ࡲࡩࡷࡧࠪᬭ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = IlTvAhqyo271xiVeC0NPLKbS(url)
	elif iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫᬮ")	in GfhcsvCWIon: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = gXWKhz2n1xbIVBR5sTmQFkd8A6etY(url)
	else: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[],[]
	global eiLBMxpW4clFUI1RDEbafZ3w8P9
	if CZBQor8PhWYnplUtkzvH6 and CZBQor8PhWYnplUtkzvH6!=wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᬯ"): CZBQor8PhWYnplUtkzvH6 = Cp6c5tZe8I0PxnAW(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤࠬᬰ")
	eiLBMxpW4clFUI1RDEbafZ3w8P9[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	return
def YQrP62lufcTSvMjHsK4OzC(url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2):
	global a1FuRnTyGNcgjp
	if jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫᬱ") in url:
		a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࡓ࡬࡫ࡳࡴࡪࡪࠧᬲ"),[],[]
		return
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[],[]
	if llr1C3SIFjViqLDtZP(url): CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[url]
	if not ppQOjlq2gaPkW: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = ZV5jUvoQHlq(url)
	if not ppQOjlq2gaPkW: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = TuZk0aqBKVvCzdyMxhwJDtbS(url)
	if not ppQOjlq2gaPkW:
		if CZBQor8PhWYnplUtkzvH6==ietolwsjpIPK7Fr(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᬳ"): CZBQor8PhWYnplUtkzvH6 = eHdDoxhJCEPMZFVa2fg
		a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = ietolwsjpIPK7Fr(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀ᬴ࠠࠡࠩ")+CZBQor8PhWYnplUtkzvH6,[],[]
		return
	a1FuRnTyGNcgjp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	return
def zuJXMtOoBR7qGpdbc5KTI6Se(url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2):
	pw9fgsSRmnKId80YbU1PA = eHdDoxhJCEPMZFVa2fg
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = rDceXBpHkfVUYRJ3tIx95Z
	try:
		import resolveurl as X9XM7rsiAIvd
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = X9XM7rsiAIvd.resolve(url)
	except Exception as COqAGFScYMe1HpuImUQf63hXi5TNPv: pw9fgsSRmnKId80YbU1PA = str(COqAGFScYMe1HpuImUQf63hXi5TNPv)
	global XdMecaI2PTCORGq75g0itblp
	if not JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1:
		if pw9fgsSRmnKId80YbU1PA==eHdDoxhJCEPMZFVa2fg:
			pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
			if pw9fgsSRmnKId80YbU1PA!=ilBWK5nXxg1do4jENGC07Zq(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪᬵ"): jjO4Xf7GBW8Dx2HR0tdP.stderr.write(pw9fgsSRmnKId80YbU1PA)
		CZBQor8PhWYnplUtkzvH6 = pw9fgsSRmnKId80YbU1PA.splitlines()[-CKUiyEe28zsZ(u"࠱ࣀ")]
		XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫᬶ")+CZBQor8PhWYnplUtkzvH6,[],[]
		return
	XdMecaI2PTCORGq75g0itblp[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1]
	return
def XeyczgF4MA(url,source,Wb5BrDZcyQsjJf17PSCnX4EYN6wv2):
	pw9fgsSRmnKId80YbU1PA = eHdDoxhJCEPMZFVa2fg
	JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = rDceXBpHkfVUYRJ3tIx95Z
	try:
		import yt_dlp as ShucBCJj0I2PdxLFtTOMK6qef18NHQ
		RwZtdAT1fWDv = ShucBCJj0I2PdxLFtTOMK6qef18NHQ.YoutubeDL({ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫᬷ"): YchIv6N09BaWPEj4tieAnluKZrRXT})
		JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 = RwZtdAT1fWDv.extract_info(url,download=rDceXBpHkfVUYRJ3tIx95Z)
	except Exception as COqAGFScYMe1HpuImUQf63hXi5TNPv: pw9fgsSRmnKId80YbU1PA = str(COqAGFScYMe1HpuImUQf63hXi5TNPv)
	global egrIanvP2qSOtUCbyBuH5W1QF
	if not JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1 or egY8Jti0smdLM3h1VQRSW(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫᬸ") not in list(JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1.keys()):
		if pw9fgsSRmnKId80YbU1PA==eHdDoxhJCEPMZFVa2fg:
			pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
			if pw9fgsSRmnKId80YbU1PA!=EX25Y0l8ILvz7QcRC(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧᬹ"): jjO4Xf7GBW8Dx2HR0tdP.stderr.write(pw9fgsSRmnKId80YbU1PA)
		CZBQor8PhWYnplUtkzvH6 = pw9fgsSRmnKId80YbU1PA.splitlines()[-KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠲ࣁ")]
		egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = egY8Jti0smdLM3h1VQRSW(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨᬺ")+CZBQor8PhWYnplUtkzvH6,[],[]
	else:
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
		for apOKrFbP9IYHDyUVm7 in JMOHBZqFv8xAnUPDTyG7XbNSY3Qik1[KW5bYS20wTF1LyCs9(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧᬻ")]:
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(apOKrFbP9IYHDyUVm7[XugxFprC26zGM(u"ࠧࡧࡱࡵࡱࡦࡺࠧᬼ")])
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7[ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡷࡵࡰࠬᬽ")])
		egrIanvP2qSOtUCbyBuH5W1QF[Wb5BrDZcyQsjJf17PSCnX4EYN6wv2] = eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	return
def ZV5jUvoQHlq(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡊࡉ࡙࠭ᬾ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡆࡆࡌࡖࡊࡉࡔࡠࡗࡕࡐ࠲࠷ࡳࡵࠩᬿ"))
	headers = aP8bLqZJsQlH3ivWKc.headers
	if EX25Y0l8ILvz7QcRC(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᭀ") in list(headers.keys()):
		apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[Cp6c5tZe8I0PxnAW(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᭁ")]
		if llr1C3SIFjViqLDtZP(apOKrFbP9IYHDyUVm7): return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩᭂ"),[],[]
def m8hUPGa329VWyFexMio(yoPm1UMpR0VCchze6nZkTArEWlNv3s):
	if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧ࡭࡫ࡶࡸࠬᭃ") in str(type(yoPm1UMpR0VCchze6nZkTArEWlNv3s)):
		JCZVK86QTYwX4mfgOrod = []
		for apOKrFbP9IYHDyUVm7 in yoPm1UMpR0VCchze6nZkTArEWlNv3s:
			if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡵࡷࡶ᭄ࠬ") in str(type(apOKrFbP9IYHDyUVm7)): apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg).replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			JCZVK86QTYwX4mfgOrod.append(apOKrFbP9IYHDyUVm7)
	else: JCZVK86QTYwX4mfgOrod = yoPm1UMpR0VCchze6nZkTArEWlNv3s.replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg).replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
	return JCZVK86QTYwX4mfgOrod
def TkUhDliFqrwZcgaYCj9KAJNLu(e8UJpoK72tOlWfr0wRs3BA9xn,source):
	gXU5SKA1bjDEPi7JoWt89NhVry0 = c4cPSX2jOIm8KCQlfW5wM
	data = EeZHTwQUW2BuvJyIh(pyifuNFdxe,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࡯࡭ࡸࡺࠧᭅ"),CKUiyEe28zsZ(u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫᭆ"),e8UJpoK72tOlWfr0wRs3BA9xn)
	if data:
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = list(zip(*data))
		return FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,iPE7gXFLMcadA9RtDI = [],[],[]
	for apOKrFbP9IYHDyUVm7 in e8UJpoK72tOlWfr0wRs3BA9xn:
		if t3coAp06zvHrTl49bUVgx(u"ࠫ࠴࠵ࠧᭇ") not in apOKrFbP9IYHDyUVm7: continue
		kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3 = kqvWahMKsBN4pHotTgD3zEe7(apOKrFbP9IYHDyUVm7,source)
		s0s2bIZtWx8w3 = cBawilJXvK1m.findall(w2vjZmdJuY7c(u"ࠬࡢࡤࠬࠩᭈ"),s0s2bIZtWx8w3,cBawilJXvK1m.DOTALL)
		if s0s2bIZtWx8w3: s0s2bIZtWx8w3 = int(s0s2bIZtWx8w3[x1Oa8bBf36EwsLMirtFc])
		else: s0s2bIZtWx8w3 = HkiMU0QrdzW3l6gwnT(u"࠲ࣂ")
		GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࡮ࡢ࡯ࡨࠫᭉ"))
		iPE7gXFLMcadA9RtDI.append([kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,apOKrFbP9IYHDyUVm7,GfhcsvCWIon])
	if iPE7gXFLMcadA9RtDI:
		U9DQFgcVxGA87NkyWzeY = sorted(iPE7gXFLMcadA9RtDI,reverse=YchIv6N09BaWPEj4tieAnluKZrRXT,key=lambda key: (key[BSw5mizCOsKxWrRDvtJuFajY],key[x1Oa8bBf36EwsLMirtFc],key[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1],key[FB0pIzAoK8wqgd3UiY5],key[NSudqlOzja],key[J7divaGOCgq2SLfXpDzZYN58wc(u"࠸ࣃ")],key[LyOR7f69iA(u"࠺ࣄ")]))
		QT4iU37M8FpR26qhBXlVOSwrxzLv,p4JSF3VTBEm = [],[]
		for g6DoPQHrhS in U9DQFgcVxGA87NkyWzeY:
			kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,apOKrFbP9IYHDyUVm7,GfhcsvCWIon = g6DoPQHrhS
			if wY1p9mP03S8drbcH64t5WQkv(u"ࠧๆใู่ࠬᭊ") in type:
				p4JSF3VTBEm.append(g6DoPQHrhS)
				continue
			if g6DoPQHrhS not in QT4iU37M8FpR26qhBXlVOSwrxzLv: QT4iU37M8FpR26qhBXlVOSwrxzLv.append(g6DoPQHrhS)
		QT4iU37M8FpR26qhBXlVOSwrxzLv = p4JSF3VTBEm+QT4iU37M8FpR26qhBXlVOSwrxzLv
		for kGtWqeZEsTS0nMHXfV,Pe9ETSvwUGBnkC1hO,type,N63IHpMe8P,s0s2bIZtWx8w3,apOKrFbP9IYHDyUVm7,GfhcsvCWIon in QT4iU37M8FpR26qhBXlVOSwrxzLv:
			if s0s2bIZtWx8w3: s0s2bIZtWx8w3 = str(s0s2bIZtWx8w3)
			else: s0s2bIZtWx8w3 = eHdDoxhJCEPMZFVa2fg
			title = jUcmHhgVvW0EdYOIfXeaDF(u"ࠨีํีๆืࠧᭋ")+avcfIls8w7gk69hYUErHxzQTXtm24j+type+avcfIls8w7gk69hYUErHxzQTXtm24j+kGtWqeZEsTS0nMHXfV+avcfIls8w7gk69hYUErHxzQTXtm24j+s0s2bIZtWx8w3+avcfIls8w7gk69hYUErHxzQTXtm24j+N63IHpMe8P+avcfIls8w7gk69hYUErHxzQTXtm24j+Pe9ETSvwUGBnkC1hO
			if GfhcsvCWIon not in title: title = title+avcfIls8w7gk69hYUErHxzQTXtm24j+GfhcsvCWIon
			title = title.replace(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࠨࠫᭌ"),eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
			if apOKrFbP9IYHDyUVm7 not in ppQOjlq2gaPkW:
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		if ppQOjlq2gaPkW:
			data = list(zip(FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW))
			if data: CbR3IdmoLYPcOqfuGNyWit6Xg(pyifuNFdxe,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫ᭍"),e8UJpoK72tOlWfr0wRs3BA9xn,data,gXU5SKA1bjDEPi7JoWt89NhVry0)
	return FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def tXvBOKzIeChDNFwHlL6Vr0fbUiRA8(url):
	if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ᭎") in url:
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = YY02fhEdJNI5cCpw1nUMj(url)
		if ppQOjlq2gaPkW: return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
		return bP01xn84BiQN(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࠵ࡘ࠼ࠬ᭏"),[],[]
	return Cp6c5tZe8I0PxnAW(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᭐"),[eHdDoxhJCEPMZFVa2fg],[url]
def ySw97VLqvm(url):
	wROf6m4Ix73jtsdnZ1vpCDuV,YYs45omUWpDLndclV = [],[]
	if t3coAp06zvHrTl49bUVgx(u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪ᭑") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,ietolwsjpIPK7Fr(u"ࠨࡉࡈࡘࠬ᭒"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫ᭓"))
		if dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ᭔") in aP8bLqZJsQlH3ivWKc.headers:
			apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭᭕")]
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
			GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,XugxFprC26zGM(u"ࠬࡴࡡ࡮ࡧࠪ᭖"))
			YYs45omUWpDLndclV.append(GfhcsvCWIon)
	elif EX25Y0l8ILvz7QcRC(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬ᭗") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,XugxFprC26zGM(u"ࠧࡈࡇࡗࠫ᭘"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,f90fGrlSEObDsuiA3U(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪ᭙"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		TWPUiXfNzJDF32e90KuRQgMl = cBawilJXvK1m.findall(KQ3sCe9Pzh(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ᭚"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if TWPUiXfNzJDF32e90KuRQgMl:
			TWPUiXfNzJDF32e90KuRQgMl = TWPUiXfNzJDF32e90KuRQgMl[x1Oa8bBf36EwsLMirtFc]
			kijEAOvZclmKhY7NJwe8S = XPBZo1pUak(TWPUiXfNzJDF32e90KuRQgMl)
			eON9EFpwMaBf1iCYk0WG42V3KSLh = cBawilJXvK1m.findall(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠬࠨ᭛"),kijEAOvZclmKhY7NJwe8S,cBawilJXvK1m.DOTALL)
			if eON9EFpwMaBf1iCYk0WG42V3KSLh:
				eON9EFpwMaBf1iCYk0WG42V3KSLh = eON9EFpwMaBf1iCYk0WG42V3KSLh[x1Oa8bBf36EwsLMirtFc]
				eON9EFpwMaBf1iCYk0WG42V3KSLh = DIpuHqsKGS3ErJvk9taCRiX80(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡱ࡯ࡳࡵࠩ᭜"),eON9EFpwMaBf1iCYk0WG42V3KSLh)
				for dict in eON9EFpwMaBf1iCYk0WG42V3KSLh:
					apOKrFbP9IYHDyUVm7 = dict[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬ࡬ࡩ࡭ࡧࠪ᭝")]
					s0s2bIZtWx8w3 = dict[ehfEsaiJBSvbcULtNPVgykA2(u"࠭࡬ࡢࡤࡨࡰࠬ᭞")]
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
					GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧ࡯ࡣࡰࡩࠬ᭟"))
					YYs45omUWpDLndclV.append(s0s2bIZtWx8w3+avcfIls8w7gk69hYUErHxzQTXtm24j+GfhcsvCWIon)
		elif LTN6DPEmrwehtZMy(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ᭠") in aP8bLqZJsQlH3ivWKc.headers:
			apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[I5bUBGpPXn0W6(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ᭡")]
			wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
			GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡲࡦࡳࡥࠨ᭢"))
			YYs45omUWpDLndclV.append(GfhcsvCWIon)
		if I5bUBGpPXn0W6(u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫ᭣") in url:
			apOKrFbP9IYHDyUVm7 = url.split(w2vjZmdJuY7c(u"ࠬࡅࡵࡳ࡮ࡀࠫ᭤"))[NSudqlOzja]
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.split(egY8Jti0smdLM3h1VQRSW(u"࠭ࠦࠨ᭥"))[x1Oa8bBf36EwsLMirtFc]
			if apOKrFbP9IYHDyUVm7:
				wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
				YYs45omUWpDLndclV.append(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧ᭦"))
	else:
		wROf6m4Ix73jtsdnZ1vpCDuV.append(url)
		GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,LTN6DPEmrwehtZMy(u"ࠨࡰࡤࡱࡪ࠭᭧"))
		YYs45omUWpDLndclV.append(GfhcsvCWIon)
	if not wROf6m4Ix73jtsdnZ1vpCDuV: return w2vjZmdJuY7c(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭᭨"),[],[]
	elif len(wROf6m4Ix73jtsdnZ1vpCDuV)==f90fGrlSEObDsuiA3U(u"࠶ࣅ"): apOKrFbP9IYHDyUVm7 = wROf6m4Ix73jtsdnZ1vpCDuV[x1Oa8bBf36EwsLMirtFc]
	else:
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(ietolwsjpIPK7Fr(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨ᭩"),YYs45omUWpDLndclV)
		if iLcCSnPyKYWs3xkQ0p14==-GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠷ࣆ"): return RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᭪"),[],[]
		apOKrFbP9IYHDyUVm7 = wROf6m4Ix73jtsdnZ1vpCDuV[iLcCSnPyKYWs3xkQ0p14]
	return EX25Y0l8ILvz7QcRC(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᭫"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def E3Qx8lesbjw7UXnVyYhLT1z5FmO6(url):
	headers = {RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶ᭬ࠪ"):t3coAp06zvHrTl49bUVgx(u"ࠧࡌࡱࡧ࡭࠴࠭᭭")+str(YB5Segc7IQ)}
	for gMmB3iopS0ZXrOFewhcxt in range(ilBWK5nXxg1do4jENGC07Zq(u"࠵࠱ࣇ")):
		b8bLFaejUB.sleep(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠱࠰࠴࠴࠵ࣈ"))
		aP8bLqZJsQlH3ivWKc = aZOozWEtm3ifLwelvb(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡉࡈࡘࠬ᭮"),url,eHdDoxhJCEPMZFVa2fg,headers,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭᭯"))
		if ietolwsjpIPK7Fr(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ᭰") in list(aP8bLqZJsQlH3ivWKc.headers.keys()):
			apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[CKUiyEe28zsZ(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭᭱")]
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+KW5bYS20wTF1LyCs9(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ᭲")+headers[S8i3sBYoHWdTURpAgN(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᭳")]
			return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
		if aP8bLqZJsQlH3ivWKc.code!=HkiMU0QrdzW3l6gwnT(u"࠶࠵࠽ࣉ"): break
	return t3coAp06zvHrTl49bUVgx(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠭᭴"),[],[]
def EMlqfRzI4WnLOFbD9PvmN7TuacgK(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,eNEhtuoi9gK8JaTpIXj(u"ࠨࡉࡈࡘࠬ᭵"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨ᭶"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧ᭷"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
		return eHdDoxhJCEPMZFVa2fg,[s0s2bIZtWx8w3],[apOKrFbP9IYHDyUVm7]
	return ietolwsjpIPK7Fr(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉࠬ᭸"),[],[]
def UR8FgEY7kJ(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡍࡅࡕࠩ᭹"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡘࡋࡌࡉࡆ࠴࠱࠶ࡹࡴࠨ᭺"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	nR2B1Wye7luXb5 = br73AglSQ0i(nR2B1Wye7luXb5)
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(KQ3sCe9Pzh(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᭻"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]]
	return wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬ᭼"),[],[]
def ulF3fqkQYR(url):
	if len(url)>wY1p9mP03S8drbcH64t5WQkv(u"࠵࠴࠵࣊"):
		url = url.strip(egY8Jti0smdLM3h1VQRSW(u"ࠩ࠲ࠫ᭽"))+Cp6c5tZe8I0PxnAW(u"ࠪ࠳ࠬ᭾")
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡌࡋࡔࠨ᭿"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡄࡖࡔࡠࡁ࠮࠳ࡶࡸࠬᮀ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		if I5bUBGpPXn0W6(u"࠴࣋") and f90fGrlSEObDsuiA3U(u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡪ࠯ࡹ࠱ࡴࠬࡵ࠮ࡨ࠰ࡷ࠯ࠧᮁ") in nR2B1Wye7luXb5:
			RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࠣ࡮ࡲࡥࡩ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ᮂ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
				cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[ilBWK5nXxg1do4jENGC07Zq(u"࠵࣌")]
				RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨ࠾ࡶࡧࡷ࡯ࡰࡵࡀࡹࡥࡷ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡣࡳ࡫ࡳࡸࠬᮃ"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
					cOUiow273ytu1GC5N0FJh = z7CnJ4SVOIabe9tqjgPGhKfu1i6Uo2(RRztfCIs16MGxEHLJ25vDNAa7hpWT[XugxFprC26zGM(u"࠶࣍")])
		elif len(nR2B1Wye7luXb5)<KQ3sCe9Pzh(u"࠴࠱࠲࣎"): apOKrFbP9IYHDyUVm7 = nR2B1Wye7luXb5
		else: return dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡑࡇࡒࡐ࡜ࡄࠫᮄ"),[],[]
		return GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࠫᮅ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᮆ"),[eHdDoxhJCEPMZFVa2fg],[url]
def hKeTC741rb(url):
	if I5bUBGpPXn0W6(u"ࠬࡹࡥࡳࡸࡀࠫᮇ") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,EX25Y0l8ILvz7QcRC(u"࠭ࡇࡆࡖࠪᮈ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,I5bUBGpPXn0W6(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡑࡓࡓࡕࡄࡄ࠱࠶ࡹࡴࠨᮉ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᮊ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7: url = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
		else:
			apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(EX25Y0l8ILvz7QcRC(u"ࠤࡄࡰࡧࡧࡐ࡭ࡣࡼࡩࡷࡉ࡯࡯ࡶࡵࡳࡱࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧࠣᮋ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if apOKrFbP9IYHDyUVm7:
				url = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
				url = HHP76VFiKDS2xphlGsqN48j1.b64decode(url)
				if WHjh1POtMKlmgiy68RSqb: url = url.decode(m6PFtLblInpNZ8x)
			else: return GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡌࡎࡕࡗࡆࡆ࠭ᮌ"),[],[]
	return wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᮍ"),[eHdDoxhJCEPMZFVa2fg],[url]
def Zm95OxkaWF(url):
	if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࠵ࡤࡰࡹࡱ࠲ࡵ࡮ࡰࠨᮎ") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,eNEhtuoi9gK8JaTpIXj(u"࠭ࡇࡆࡖࠪᮏ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡆࡉࡃ࠰࠵ࡸࡺࠧᮐ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(HkiMU0QrdzW3l6gwnT(u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡸࡴࡤࡴࡵ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᮑ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		url = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	return I5bUBGpPXn0W6(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᮒ"),[eHdDoxhJCEPMZFVa2fg],[url]
def hYSQu6oesZ(url):
	if f90fGrlSEObDsuiA3U(u"ࠪࡷࡪࡸࡶࡦࡴ࠱ࡴ࡭ࡶࠧᮓ") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,t3coAp06zvHrTl49bUVgx(u"ࠫࡌࡋࡔࠨᮔ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆ࠺ࡕ࠮࠳ࡶࡸࠬᮕ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᮖ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
		if LyOR7f69iA(u"ࠧࡩࡶࡷࡴࠬᮗ") in apOKrFbP9IYHDyUVm7: return w2vjZmdJuY7c(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᮘ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
		return KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡈࡏࡍࡂ࠶ࡘࠫᮙ"),[],[]
	return LTN6DPEmrwehtZMy(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᮚ"),[eHdDoxhJCEPMZFVa2fg],[url]
def rNYwsf7vbW(url):
	E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(url)
	W9PzsMeLJTc83mS45G17n = {J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧᮛ"):bP01xn84BiQN(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ᮜ"),HkiMU0QrdzW3l6gwnT(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᮝ"):ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᮞ")}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,t3coAp06zvHrTl49bUVgx(u"ࠨࡒࡒࡗ࡙࠭ᮟ"),E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡐࡒ࡛࠲࠷ࡳࡵࠩᮠ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(t3coAp06zvHrTl49bUVgx(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᮡ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not apOKrFbP9IYHDyUVm7: return Cp6c5tZe8I0PxnAW(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡑࡓ࡜࠭ᮢ"),[],[]
	apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	return QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᮣ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def jAQcYTetKX(url):
	headers = {LTN6DPEmrwehtZMy(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᮤ"):egY8Jti0smdLM3h1VQRSW(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᮥ")}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡉࡈࡘࠬᮦ"),url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡐࡑࡉࡔࡗࡕ࠭࠲ࡵࡷࠫᮧ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(eNEhtuoi9gK8JaTpIXj(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᮨ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
	if not apOKrFbP9IYHDyUVm7: return LTN6DPEmrwehtZMy(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡓࡉࡑࡒࡊࡕࡘࡏࠨᮩ"),[],[]
	apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	return KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᮪"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def VkzL4nFWeO(url):
	E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(url)
	W9PzsMeLJTc83mS45G17n = {ietolwsjpIPK7Fr(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩ᮫ࠬ"):EX25Y0l8ILvz7QcRC(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᮬ")}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,S8i3sBYoHWdTURpAgN(u"ࠨࡒࡒࡗ࡙࠭ᮭ"),E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡎࡁࡍࡃࡆࡍࡒࡇ࠭࠲ࡵࡷࠫᮮ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࠫࠬࡂࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀ࡟ࠧ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢࠨ࡟ࠪࠫࠬᮯ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
	if not apOKrFbP9IYHDyUVm7: return KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡈࡂࡎࡄࡇࡎࡓࡁࠨ᮰"),[],[]
	apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	if KQ3sCe9Pzh(u"ࠬ࡮ࡴࡵࡲࠪ᮱") not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡨࡵࡶࡳ࠾ࠬ᮲")+apOKrFbP9IYHDyUVm7
	return CKUiyEe28zsZ(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᮳"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def GPkJLhHnO3(url):
	bmsN7D3kPQ8Beh5RS0M4ng2FcY,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV = url,[],[]
	if ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࠨ᮴") in url:
		E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(url)
		W9PzsMeLJTc83mS45G17n = {iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ᮵"):Cp6c5tZe8I0PxnAW(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥ࠽ࠣࡧ࡭ࡧࡲࡴࡧࡷࡁ࡚࡚ࡆ࠮࠺ࠪ᮶")}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡕࡕࡓࡕࠩ᮷"),E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡇࡂࡅࡑ࠰࠵ࡸࡺࠧ᮸"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		ge4hFRp51QsUPtGTnBuzka = cBawilJXvK1m.findall(eNEhtuoi9gK8JaTpIXj(u"࠭ࠧࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾࡝ࠥࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧ࠭࡝ࠨࠩࠪ᮹"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		if ge4hFRp51QsUPtGTnBuzka: bmsN7D3kPQ8Beh5RS0M4ng2FcY = ge4hFRp51QsUPtGTnBuzka[x1Oa8bBf36EwsLMirtFc]
	return eNEhtuoi9gK8JaTpIXj(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᮺ"),[eHdDoxhJCEPMZFVa2fg],[bmsN7D3kPQ8Beh5RS0M4ng2FcY]
def y8geHuIGD9(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,t3coAp06zvHrTl49bUVgx(u"ࠨࡉࡈࡘࠬᮻ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡚ࡖࡇࡗࡑ࠱࠶ࡹࡴࠨᮼ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	t35lCdQaSIhWZ8r4npj = cBawilJXvK1m.findall(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠥࡺࡦࡸࠠࡧࡵࡨࡶࡻࠦ࠽࠯ࠬࡂࠫ࠭࠴ࠪࡀࠫࠪࠦᮽ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
	if t35lCdQaSIhWZ8r4npj:
		t35lCdQaSIhWZ8r4npj = t35lCdQaSIhWZ8r4npj[x1Oa8bBf36EwsLMirtFc][S8i3sBYoHWdTURpAgN(u"࠳࣏"):]
		t35lCdQaSIhWZ8r4npj = HHP76VFiKDS2xphlGsqN48j1.b64decode(t35lCdQaSIhWZ8r4npj)
		if WHjh1POtMKlmgiy68RSqb: t35lCdQaSIhWZ8r4npj = t35lCdQaSIhWZ8r4npj.decode(m6PFtLblInpNZ8x)
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(w2vjZmdJuY7c(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᮾ"),t35lCdQaSIhWZ8r4npj,cBawilJXvK1m.DOTALL)
	else: apOKrFbP9IYHDyUVm7 = eHdDoxhJCEPMZFVa2fg
	if not apOKrFbP9IYHDyUVm7: return f90fGrlSEObDsuiA3U(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡕࡘࡉ࡙ࡓ࠭ᮿ"),[],[]
	apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	if jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡨࡵࡶࡳࠫᯀ") not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡩࡶࡷࡴ࠿࠭ᯁ")+apOKrFbP9IYHDyUVm7
	return KQ3sCe9Pzh(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᯂ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def ONGvmkJl9UdPCZQK1bIteFS8R(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,f90fGrlSEObDsuiA3U(u"ࠩࡊࡉ࡙࠭ᯃ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡇࡊ࡝࡛ࡏࡐ࠮࠳ࡶࡸࠬᯄ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(S8i3sBYoHWdTURpAgN(u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡵࡰ࠱࠶࠸ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᯅ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not apOKrFbP9IYHDyUVm7: return KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࡛ࡈࡋ࡞࡜ࡉࡑࠩᯆ"),[],[]
	apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	return ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᯇ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def xp3idWHVor(url):
	id = url.split(ehfEsaiJBSvbcULtNPVgykA2(u"ࠧ࠰ࠩᯈ"))[-QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠳࣐")]
	if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨᯉ") in url: url = url.replace(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩ࠲ࡩࡲࡨࡥࡥࠩᯊ"),eHdDoxhJCEPMZFVa2fg)
	url = url.replace(NxXMrsTC5FniYuRBOK8(u"ࠪ࠲ࡨࡵ࡭࠰ࠩᯋ"),t3coAp06zvHrTl49bUVgx(u"ࠫ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿࡥࡳ࠱ࡰࡩࡹࡧࡤࡢࡶࡤ࠳ࠬᯌ"))
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,Cp6c5tZe8I0PxnAW(u"ࠬࡍࡅࡕࠩᯍ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭࠲ࡵࡷࠫᯎ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	CZBQor8PhWYnplUtkzvH6 = LTN6DPEmrwehtZMy(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧᯏ")
	COqAGFScYMe1HpuImUQf63hXi5TNPv = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠨࠤࡨࡶࡷࡵࡲࠣ࠰࠭ࡃࠧࡳࡥࡴࡵࡤ࡫ࡪ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩᯐ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if COqAGFScYMe1HpuImUQf63hXi5TNPv: CZBQor8PhWYnplUtkzvH6 = COqAGFScYMe1HpuImUQf63hXi5TNPv[x1Oa8bBf36EwsLMirtFc]
	url = cBawilJXvK1m.findall(LyOR7f69iA(u"ࠩࡻ࠱ࡲࡶࡥࡨࡗࡕࡐࠧ࠲ࠢࡶࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᯑ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not url and CZBQor8PhWYnplUtkzvH6:
		return CZBQor8PhWYnplUtkzvH6,[],[]
	apOKrFbP9IYHDyUVm7 = url[x1Oa8bBf36EwsLMirtFc].replace(KW5bYS20wTF1LyCs9(u"ࠪࡠࡡ࠭ᯒ"),eHdDoxhJCEPMZFVa2fg)
	qqVw1UMpJmejYh5ioKIbnFGH,e8UJpoK72tOlWfr0wRs3BA9xn = YY02fhEdJNI5cCpw1nUMj(apOKrFbP9IYHDyUVm7)
	lPbeIkcm9Ows2U54NhGFL = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿ࡢࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡶࡧࡷ࡫ࡥ࡯ࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᯓ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if lPbeIkcm9Ows2U54NhGFL: nphMwAIt97jQEaBvcoD8VNPxYk2,ciPek8sCfZzMng,zFio5q0hbjk16SRZ3Jw = lPbeIkcm9Ows2U54NhGFL[x1Oa8bBf36EwsLMirtFc]
	else: nphMwAIt97jQEaBvcoD8VNPxYk2,ciPek8sCfZzMng,zFio5q0hbjk16SRZ3Jw = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	zFio5q0hbjk16SRZ3Jw = zFio5q0hbjk16SRZ3Jw.replace(CKUiyEe28zsZ(u"ࠬࡢ࠯ࠨᯔ"),S8i3sBYoHWdTURpAgN(u"࠭࠯ࠨᯕ"))
	ciPek8sCfZzMng = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(ciPek8sCfZzMng)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh = [SbyWQGMDnV+HkiMU0QrdzW3l6gwnT(u"ࠧࡐ࡙ࡑࡉࡗࡀࠠࠡࠩᯖ")+ciPek8sCfZzMng+Nat0Dx9puRUWCsgz6JyFhY3]+qqVw1UMpJmejYh5ioKIbnFGH
	ppQOjlq2gaPkW = [zFio5q0hbjk16SRZ3Jw]+e8UJpoK72tOlWfr0wRs3BA9xn
	iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(XugxFprC26zGM(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩᯗ")+str(len(ppQOjlq2gaPkW)-ehfEsaiJBSvbcULtNPVgykA2(u"࠴࣑"))+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"้้ࠩࠣ็ࠩࠨᯘ"),FBITEXGDfe2mcCxnQs6ktMdy9HJh)
	if iLcCSnPyKYWs3xkQ0p14==-HkiMU0QrdzW3l6gwnT(u"࠵࣒"): return egY8Jti0smdLM3h1VQRSW(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᯙ"),[],[]
	elif iLcCSnPyKYWs3xkQ0p14==I5bUBGpPXn0W6(u"࠵࣓"):
		beodhfn062VN8vwZzU5I9uLlySiQxF = jjO4Xf7GBW8Dx2HR0tdP.argv[x1Oa8bBf36EwsLMirtFc]+CKUiyEe28zsZ(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠶࠳࠶ࠫࡻࡲ࡭࠿ࠪᯚ")+zFio5q0hbjk16SRZ3Jw+NxXMrsTC5FniYuRBOK8(u"ࠬࠬࡴࡦࡺࡷࡸࡂ࠭ᯛ")+ciPek8sCfZzMng
		ccwRLKk3hs0E.executebuiltin(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥᯜ")+beodhfn062VN8vwZzU5I9uLlySiQxF+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠢࠪࠤᯝ"))
		return ietolwsjpIPK7Fr(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᯞ"),[],[]
	apOKrFbP9IYHDyUVm7 =  ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def lKEUgnXfoA(apOKrFbP9IYHDyUVm7):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,S8i3sBYoHWdTURpAgN(u"ࠩࡊࡉ࡙࠭ᯟ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LyOR7f69iA(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩᯠ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	if KQ3sCe9Pzh(u"ࠫ࠳ࡰࡳࡰࡰࠪᯡ") in apOKrFbP9IYHDyUVm7: url = cBawilJXvK1m.findall(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᯢ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	else: url = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᯣ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not url: return ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅࡓࡐࡘࡁࠨᯤ"),[],[]
	url = url[x1Oa8bBf36EwsLMirtFc]
	if NxXMrsTC5FniYuRBOK8(u"ࠨࡪࡷࡸࡵ࠭ᯥ") not in url: url = wY1p9mP03S8drbcH64t5WQkv(u"ࠩ࡫ࡸࡹࡶ࠺ࠨ᯦")+url
	return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[url]
def P8d1JkD5oOqVLxf7Wjm(url):
	headers = { eNEhtuoi9gK8JaTpIXj(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᯧ") : eHdDoxhJCEPMZFVa2fg }
	if KQ3sCe9Pzh(u"ࠫࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧᯨ") in url:
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠵ࡸࡺࠧᯩ"))
		items = cBawilJXvK1m.findall(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᯪ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if items: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[items[x1Oa8bBf36EwsLMirtFc]]
		else:
			sh3cDaZzUkKQFEAl74OryuPtGqJ = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡴࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᯫ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if sh3cDaZzUkKQFEAl74OryuPtGqJ:
				dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪᯬ"),sh3cDaZzUkKQFEAl74OryuPtGqJ[x1Oa8bBf36EwsLMirtFc])
				return GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪᯭ")+sh3cDaZzUkKQFEAl74OryuPtGqJ[x1Oa8bBf36EwsLMirtFc],[],[]
	else:
		TR3DAb6GkCsva1 = wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭ᯮ")
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠵ࡲࡩ࠭ᯯ"))
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(CKUiyEe28zsZ(u"ࠬࡌ࡯ࡳ࡯ࠣࡱࡪࡺࡨࡰࡦࡀࠦࡕࡕࡓࡕࠤࠣࡥࡨࡺࡩࡰࡰࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧᯰ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return NxXMrsTC5FniYuRBOK8(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪᯱ"),[],[]
		bmsN7D3kPQ8Beh5RS0M4ng2FcY = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc]
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc][NSudqlOzja]
		if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧ࠯ࡴࡤࡶ᯲ࠬ") in cOUiow273ytu1GC5N0FJh or TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨ࠰ࡽ࡭ࡵ᯳࠭") in cOUiow273ytu1GC5N0FJh: return LTN6DPEmrwehtZMy(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡐࡓࡘࡎࡁࡉࡆࡄࠤࡓࡵࡴࠡࡣࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠧ᯴"),[],[]
		items = cBawilJXvK1m.findall(LTN6DPEmrwehtZMy(u"ࠪࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᯵"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		j6KOlzWGugZqmx0sPS = {}
		for Pe9ETSvwUGBnkC1hO,q5qDOCzEe0Lv4ZyJbWnaPcpVsB in items:
			j6KOlzWGugZqmx0sPS[Pe9ETSvwUGBnkC1hO] = q5qDOCzEe0Lv4ZyJbWnaPcpVsB
		data = GHIgY9AomX(j6KOlzWGugZqmx0sPS)
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,bmsN7D3kPQ8Beh5RS0M4ng2FcY,data,headers,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭᯶"))
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪ᯷"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not RRztfCIs16MGxEHLJ25vDNAa7hpWT: return CKUiyEe28zsZ(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪ᯸"),[],[]
		download = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc]
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc][NSudqlOzja]
		items = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧ᯹"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		cR75npCiqU8TLfgMZO,FBITEXGDfe2mcCxnQs6ktMdy9HJh,II38vmlgDXhF,ppQOjlq2gaPkW,nwlGHtq74Ej5FoYQhRU = [],[],[],[],[]
		for apOKrFbP9IYHDyUVm7,title in items:
			if f90fGrlSEObDsuiA3U(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ᯺") in apOKrFbP9IYHDyUVm7:
				cR75npCiqU8TLfgMZO,II38vmlgDXhF = YY02fhEdJNI5cCpw1nUMj(apOKrFbP9IYHDyUVm7)
				ppQOjlq2gaPkW = ppQOjlq2gaPkW + II38vmlgDXhF
				if cR75npCiqU8TLfgMZO[x1Oa8bBf36EwsLMirtFc]==S8i3sBYoHWdTURpAgN(u"ࠩ࠰࠵ࠬ᯻"): FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ᯼")+ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡲ࠹ࡵ࠹ࠢࠪ᯽")+TR3DAb6GkCsva1)
				else:
					for title in cR75npCiqU8TLfgMZO:
						FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(w2vjZmdJuY7c(u"ࠬࠦำ๋ำไีࠥิวึࠢࠪ᯾")+KQ3sCe9Pzh(u"࠭࡭࠴ࡷ࠻ࠤࠬ᯿")+TR3DAb6GkCsva1+avcfIls8w7gk69hYUErHxzQTXtm24j+title)
			else:
				title = title.replace(LTN6DPEmrwehtZMy(u"ࠧ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠩᰀ"),eHdDoxhJCEPMZFVa2fg)
				title = title.strip(egY8Jti0smdLM3h1VQRSW(u"ࠨࠤࠪᰁ"))
				title = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨᰂ")+eNEhtuoi9gK8JaTpIXj(u"ࠪࠤࡲࡶ࠴ࠡࠩᰃ")+TR3DAb6GkCsva1+avcfIls8w7gk69hYUErHxzQTXtm24j+title
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		apOKrFbP9IYHDyUVm7 = LyOR7f69iA(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠭ᰄ") + download
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧᰅ"))
		items = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥᰆ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for id,tWi3JH8rRhxcgnYuMVUK,hash,IUfWHuARFLN4bqGO9ntcBaV in items:
			title = KQ3sCe9Pzh(u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫᰇ")+KW5bYS20wTF1LyCs9(u"ࠨࠢࡰࡴ࠹ࠦࠧᰈ")+TR3DAb6GkCsva1+avcfIls8w7gk69hYUErHxzQTXtm24j+IUfWHuARFLN4bqGO9ntcBaV.split(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡻࠫᰉ"))[NSudqlOzja]
			apOKrFbP9IYHDyUVm7 = wY1p9mP03S8drbcH64t5WQkv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡪ࡬ࡀࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠪ࡮ࡪ࠽ࠨᰊ")+id+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࠫࡳ࡯ࡥࡧࡀࠫᰋ")+tWi3JH8rRhxcgnYuMVUK+eNEhtuoi9gK8JaTpIXj(u"ࠬࠬࡨࡢࡵ࡫ࡁࠬᰌ")+hash
			nwlGHtq74Ej5FoYQhRU.append(IUfWHuARFLN4bqGO9ntcBaV)
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		nwlGHtq74Ej5FoYQhRU = set(nwlGHtq74Ej5FoYQhRU)
		URn8tae3WBw,MsQ6wcNCuqV72fgOB = [],[]
		for title in FBITEXGDfe2mcCxnQs6ktMdy9HJh:
			qP2i0GOngzrMYVDKIF6ab = cBawilJXvK1m.findall(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࠠࠩ࡞ࡧ࠮ࡽࢂ࡜ࡥࠬࠬࠪࠫࠨᰍ"),title+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࠧࠨࠪᰎ"),cBawilJXvK1m.DOTALL)
			for IUfWHuARFLN4bqGO9ntcBaV in nwlGHtq74Ej5FoYQhRU:
				if qP2i0GOngzrMYVDKIF6ab[x1Oa8bBf36EwsLMirtFc] in IUfWHuARFLN4bqGO9ntcBaV:
					title = title.replace(qP2i0GOngzrMYVDKIF6ab[x1Oa8bBf36EwsLMirtFc],IUfWHuARFLN4bqGO9ntcBaV.split(bP01xn84BiQN(u"ࠨࡺࠪᰏ"))[NSudqlOzja])
			URn8tae3WBw.append(title)
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(ppQOjlq2gaPkW)):
			items = cBawilJXvK1m.findall(LyOR7f69iA(u"ࠤࠩࠪ࠭࠴ࠪࡀࠫࠫࡠࡩ࠰ࠩࠧࠨࠥᰐ"),ietolwsjpIPK7Fr(u"ࠪࠪࠫ࠭ᰑ")+URn8tae3WBw[dhcGSyo8Kn1mHZwvEAkzJ7NUq]+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࠫࠬࠧᰒ"),cBawilJXvK1m.DOTALL)
			MsQ6wcNCuqV72fgOB.append( [URn8tae3WBw[dhcGSyo8Kn1mHZwvEAkzJ7NUq],ppQOjlq2gaPkW[dhcGSyo8Kn1mHZwvEAkzJ7NUq],items[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc],items[x1Oa8bBf36EwsLMirtFc][NSudqlOzja]] )
		MsQ6wcNCuqV72fgOB = sorted(MsQ6wcNCuqV72fgOB, key=lambda zJXiTW43hwos8qFOQfa9C0RkeB5MIm: zJXiTW43hwos8qFOQfa9C0RkeB5MIm[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1], reverse=YchIv6N09BaWPEj4tieAnluKZrRXT)
		MsQ6wcNCuqV72fgOB = sorted(MsQ6wcNCuqV72fgOB, key=lambda zJXiTW43hwos8qFOQfa9C0RkeB5MIm: zJXiTW43hwos8qFOQfa9C0RkeB5MIm[FB0pIzAoK8wqgd3UiY5], reverse=rDceXBpHkfVUYRJ3tIx95Z)
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(len(MsQ6wcNCuqV72fgOB)):
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(MsQ6wcNCuqV72fgOB[dhcGSyo8Kn1mHZwvEAkzJ7NUq][x1Oa8bBf36EwsLMirtFc])
			ppQOjlq2gaPkW.append(MsQ6wcNCuqV72fgOB[dhcGSyo8Kn1mHZwvEAkzJ7NUq][NSudqlOzja])
	if len(ppQOjlq2gaPkW)==ehfEsaiJBSvbcULtNPVgykA2(u"࠶ࣔ"): return egY8Jti0smdLM3h1VQRSW(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩᰓ"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def TT9mADZgiHJXr7bckMz6tjeYdCP(url):
	dezG4T3itVrAKvX9 = url.split(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭࠿ࠨᰔ"))
	E1Viom5L3684CTOFJ = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
	headers = { EX25Y0l8ILvz7QcRC(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᰕ") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࠻ࡔࡔࡃࡕ࠱࠶ࡹࡴࠨᰖ"))
	items = cBawilJXvK1m.findall(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡓࡰࡪࡧࡳࡦࠢࡺࡥ࡮ࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪᰗ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	url = items[x1Oa8bBf36EwsLMirtFc]
	return LTN6DPEmrwehtZMy(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᰘ"),[eHdDoxhJCEPMZFVa2fg],[url]
def CJxyZec1NEGhtp50Pw(url):
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	headers = { ehfEsaiJBSvbcULtNPVgykA2(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᰙ") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫᰚ"))
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(egY8Jti0smdLM3h1VQRSW(u"࠭ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡷࡵࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᰛ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if E1Viom5L3684CTOFJ: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]]
	else: return ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅ࡙࡟ࡠࡖࡓࡎࠪᰜ"),[],[]
def KZF3QBrkyJwI5g(url):
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	headers = { bP01xn84BiQN(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᰝ") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(c4cPSX2jOIm8KCQlfW5wM,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨᰞ"))
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(EX25Y0l8ILvz7QcRC(u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭ᰟ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if E1Viom5L3684CTOFJ: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]]
	else: return EX25Y0l8ILvz7QcRC(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗࠬᰠ"),[],[]
def bwc3If0s54(url):
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,errno = [],[],eHdDoxhJCEPMZFVa2fg
	if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࠩᰡ") in url:
		E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y = ZZOBwdspmUJWtNH9KPyj0TI5V68hv(url)
		W9PzsMeLJTc83mS45G17n = {iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬᰢ"):Cp6c5tZe8I0PxnAW(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧᰣ")}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡒࡒࡗ࡙࠭ᰤ"),E1Viom5L3684CTOFJ,LbAmEhrdt7eRV2Y,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬᰥ"))
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		if L3f4VRFXh0Sb1xwKPzoi.startswith(eNEhtuoi9gK8JaTpIXj(u"ࠪ࡬ࡹࡺࡰࠨᰦ")): E1Viom5L3684CTOFJ = L3f4VRFXh0Sb1xwKPzoi
		else:
			ajHR9ABQl2buvm = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬᰧ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			if ajHR9ABQl2buvm:
				E1Viom5L3684CTOFJ = ajHR9ABQl2buvm[x1Oa8bBf36EwsLMirtFc]
				ajHR9ABQl2buvm = cBawilJXvK1m.findall(eNEhtuoi9gK8JaTpIXj(u"ࠬࡹ࡯ࡶࡴࡦࡩࡂ࠮࠮ࠫࡁࠬ࡟ࠫࠪ࡝ࠨᰨ"),E1Viom5L3684CTOFJ,cBawilJXvK1m.DOTALL)
				if ajHR9ABQl2buvm:
					E1Viom5L3684CTOFJ = zrHeZWCqQMOymk1d7anKpu0vEx8(ajHR9ABQl2buvm[x1Oa8bBf36EwsLMirtFc])
					return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	elif RqLvTrID0yMVeClpYcnZ16i3X(u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࠧᰩ") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡈࡇࡗࠫᰪ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠲ࡵࡷࠫᰫ"))
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		if RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᰬ") in list(aP8bLqZJsQlH3ivWKc.headers.keys()): E1Viom5L3684CTOFJ = aP8bLqZJsQlH3ivWKc.headers[HkiMU0QrdzW3l6gwnT(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᰭ")]
		else: E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(bP01xn84BiQN(u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᰮ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)[x1Oa8bBf36EwsLMirtFc]
	if ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬ࠵ࡶ࠰ࠩᰯ") in E1Viom5L3684CTOFJ or GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭࠯ࡧ࠱ࠪᰰ") in E1Viom5L3684CTOFJ:
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.replace(S8i3sBYoHWdTURpAgN(u"ࠧ࠰ࡨ࠲ࠫᰱ"),NxXMrsTC5FniYuRBOK8(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࠧᰲ"))
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.replace(ilBWK5nXxg1do4jENGC07Zq(u"ࠩ࠲ࡺ࠴࠭ᰳ"),bP01xn84BiQN(u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩᰴ"))
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,LyOR7f69iA(u"ࠫࡕࡕࡓࡕࠩᰵ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠸ࡸࡤࠨᰶ"))
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		items = cBawilJXvK1m.findall(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅ᰷ࠩࠣࠩ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if items:
			for apOKrFbP9IYHDyUVm7,title in items:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(CKUiyEe28zsZ(u"ࠧ࡝࡞ࠪ᰸"),eHdDoxhJCEPMZFVa2fg)
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		else:
			items = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ᰹"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			if items:
				apOKrFbP9IYHDyUVm7 = items[x1Oa8bBf36EwsLMirtFc]
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(HkiMU0QrdzW3l6gwnT(u"ࠩ࡟ࡠࠬ᰺"),eHdDoxhJCEPMZFVa2fg)
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(eHdDoxhJCEPMZFVa2fg)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	else: return ietolwsjpIPK7Fr(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᰻"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	if len(ppQOjlq2gaPkW)==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠰ࣕ"): return ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ᰼"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def YCszToelGr(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡍࡅࡕࠩ᰽"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭᰾"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,errno = [],[],eHdDoxhJCEPMZFVa2fg
	if iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪ᰿") in url or KW5bYS20wTF1LyCs9(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩ᱀") in url:
		if wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬ᱁") in url:
			E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᱂"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]
		else: E1Viom5L3684CTOFJ = url
		if XugxFprC26zGM(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫ᱃") not in E1Viom5L3684CTOFJ: return dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᱄"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡇࡆࡖࠪ᱅"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠶ࡳࡪࠧ᱆"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࡬ࡶࠫ᱇"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc]
		items = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᱈"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		if items:
			for apOKrFbP9IYHDyUVm7,jZHGcWxXpdVO038fnt in items:
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(jZHGcWxXpdVO038fnt)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	elif LyOR7f69iA(u"ࠪࡱࡦ࡯࡮ࡠࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࠬ᱉") in url:
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(t3coAp06zvHrTl49bUVgx(u"ࠫࡺࡸ࡬࠾ࠪ࠱࠮ࡄ࠯ࠢࠨ᱊"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,bP01xn84BiQN(u"ࠬࡍࡅࡕࠩ᱋"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,f90fGrlSEObDsuiA3U(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠶ࡶࡩ࠭᱌"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		ajHR9ABQl2buvm = cBawilJXvK1m.findall(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩᱍ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		ajHR9ABQl2buvm = ajHR9ABQl2buvm[x1Oa8bBf36EwsLMirtFc]
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(eHdDoxhJCEPMZFVa2fg)
		ppQOjlq2gaPkW.append(ajHR9ABQl2buvm)
	elif eNEhtuoi9gK8JaTpIXj(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨᱎ") in url:
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(HkiMU0QrdzW3l6gwnT(u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᱏ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if E1Viom5L3684CTOFJ:
			E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]
			return iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᱐"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	if len(ppQOjlq2gaPkW)==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠱ࣖ"): return jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡘࡖ࠸࡚࠭᱑"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def fHC5Ku3jMg(url):
	if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡅࡧࡦࡶࡀࠫ᱒") in url:
		apOKrFbP9IYHDyUVm7 = url.split(KW5bYS20wTF1LyCs9(u"࠭࠿ࡨࡧࡷࡁࠬ᱓"),egY8Jti0smdLM3h1VQRSW(u"࠳ࣗ"))[NSudqlOzja]
		apOKrFbP9IYHDyUVm7 = HHP76VFiKDS2xphlGsqN48j1.b64decode(apOKrFbP9IYHDyUVm7)
		if WHjh1POtMKlmgiy68RSqb: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.decode(m6PFtLblInpNZ8x,w2vjZmdJuY7c(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ᱔"))
		return w2vjZmdJuY7c(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᱕"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	website = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[w2vjZmdJuY7c(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫ᱖")][x1Oa8bBf36EwsLMirtFc]
	headers = {RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ᱗"):website}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,w2vjZmdJuY7c(u"ࠫࡌࡋࡔࠨ᱘"),url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡄ࠰࠶ࡳࡪࠧ᱙"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,XugxFprC26zGM(u"࠭ࡵࡳ࡮ࠪᱚ"))
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᱛ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠣࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨᱜ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࠤࡩ࡭ࡱ࡫࠺ࠨࠪ࠱࠮ࡄ࠯ࠧࠣᱝ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]+t3coAp06zvHrTl49bUVgx(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᱞ")+website
		return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	if KW5bYS20wTF1LyCs9(u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠫᱟ") in nR2B1Wye7luXb5:
		SNgOuwmvaQ2f = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠬࡴࡡ࡮ࡧࡀࠦ࡝ࡺ࡯࡬ࡧࡱࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᱠ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if SNgOuwmvaQ2f:
			apOKrFbP9IYHDyUVm7 = SNgOuwmvaQ2f[x1Oa8bBf36EwsLMirtFc]
			apOKrFbP9IYHDyUVm7 = HHP76VFiKDS2xphlGsqN48j1.b64decode(apOKrFbP9IYHDyUVm7)
			if WHjh1POtMKlmgiy68RSqb: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.decode(m6PFtLblInpNZ8x,KQ3sCe9Pzh(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᱡ"))
			apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠧࡩࡶࡷࡴ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࠯ࠫᱢ"),apOKrFbP9IYHDyUVm7,cBawilJXvK1m.DOTALL)
			if apOKrFbP9IYHDyUVm7:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]+Cp6c5tZe8I0PxnAW(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᱣ")+website
				return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return XugxFprC26zGM(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᱤ"),[eHdDoxhJCEPMZFVa2fg],[url]
def BUiuKe0MF7(url,DfV0FjXSuriL6O1aM5hPZlQt8):
	YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV = [],[]
	if ehfEsaiJBSvbcULtNPVgykA2(u"ࠪ࠳࠶࠵ࠧᱥ") in url:
		apOKrFbP9IYHDyUVm7 = url.replace(w2vjZmdJuY7c(u"ࠫ࠴࠷࠯ࠨᱦ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠬ࠵࠴࠰ࠩᱧ"))
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡇࡆࡖࠪᱨ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠷ࡳࡵࠩᱩ"))
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(egY8Jti0smdLM3h1VQRSW(u"ࠨ࠾ࡹ࡭ࡩ࡫࡯ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡧࡩࡴࡄࠧᱪ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
			cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc]
			items = cBawilJXvK1m.findall(t3coAp06zvHrTl49bUVgx(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᱫ"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
			for apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3 in items:
				if apOKrFbP9IYHDyUVm7 not in wROf6m4Ix73jtsdnZ1vpCDuV:
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
					GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡲࡦࡳࡥࠨᱬ"))
					YYs45omUWpDLndclV.append(GfhcsvCWIon+KwJyZLDzC4FbHhXgTfI+s0s2bIZtWx8w3)
			return eHdDoxhJCEPMZFVa2fg,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV
	elif EX25Y0l8ILvz7QcRC(u"ࠫ࠴ࡪ࠯ࠨᱭ") in url:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,I5bUBGpPXn0W6(u"ࠬࡍࡅࡕࠩᱮ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠷ࡴࡤࠨᱯ"))
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(ietolwsjpIPK7Fr(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᱰ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc].replace(LyOR7f69iA(u"ࠨ࠱࠴࠳ࠬᱱ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩ࠲࠸࠴࠭ᱲ"))
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡋࡊ࡚ࠧᱳ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠶ࡶࡩ࠭ᱴ"))
			L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
			apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡩ࡬ࡢࡵࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᱵ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			if apOKrFbP9IYHDyUVm7: return LTN6DPEmrwehtZMy(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱶ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]]
	elif J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࠰ࡴࡲࡰࡪ࠵ࠧᱷ") in url:
		headers = {RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᱸ"):DfV0FjXSuriL6O1aM5hPZlQt8}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡊࡉ࡙࠭ᱹ"),url,eHdDoxhJCEPMZFVa2fg,headers,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,f90fGrlSEObDsuiA3U(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠶ࡷ࡬ࠬᱺ"))
		apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᱻ")]
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,CKUiyEe28zsZ(u"ࠬࡍࡅࡕࠩᱼ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠺ࡺࡨࠨᱽ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV = qTdWVHsCB8DvNFuRfaj6KLA(apOKrFbP9IYHDyUVm7,nR2B1Wye7luXb5)
		return CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV
	elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫ᱾") in url:
		E1Viom5L3684CTOFJ = url.replace(t3coAp06zvHrTl49bUVgx(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬ᱿"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩ࠲ࡷࡨࡸࡩࡱࡶ࠲ࠫᲀ"))
		W9PzsMeLJTc83mS45G17n = {f90fGrlSEObDsuiA3U(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᲁ"):DfV0FjXSuriL6O1aM5hPZlQt8}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,KW5bYS20wTF1LyCs9(u"ࠫࡌࡋࡔࠨᲂ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,S8i3sBYoHWdTURpAgN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠺ࡹ࡮ࠧᲃ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᲄ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,S8i3sBYoHWdTURpAgN(u"ࠧࡈࡇࡗࠫᲅ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠷ࡵࡪࠪᲆ"))
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
			if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᲇ") in list(aP8bLqZJsQlH3ivWKc.headers.keys()):
				apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᲈ")]
				aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,KW5bYS20wTF1LyCs9(u"ࠫࡌࡋࡔࠨᲉ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠼ࡹ࡮ࠧᲊ"))
				nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
				CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV = qTdWVHsCB8DvNFuRfaj6KLA(apOKrFbP9IYHDyUVm7,nR2B1Wye7luXb5)
				if wROf6m4Ix73jtsdnZ1vpCDuV: return CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV
			elif QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧ᲋") in apOKrFbP9IYHDyUVm7:
				apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ᲌"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨ࠱࡭ࡻࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁࠬ᲍"))
				return XugxFprC26zGM(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᲎"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	else: return dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᲏"),[eHdDoxhJCEPMZFVa2fg],[url]
	return bP01xn84BiQN(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨᲐ"),[],[]
def EELl8BIS4h(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,w2vjZmdJuY7c(u"ࠬࡍࡅࡕࠩᲑ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,egY8Jti0smdLM3h1VQRSW(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠶ࡹࡴࠨᲒ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	data = cBawilJXvK1m.findall(t3coAp06zvHrTl49bUVgx(u"ࠧࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᲓ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if data:
		sAZIk4FeEoQq5GtC3xTbRUMB,id,ED1Yx7AGRSBOviIst2j = data[x1Oa8bBf36EwsLMirtFc]
		data = GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨࡱࡳࡁࠬᲔ")+sAZIk4FeEoQq5GtC3xTbRUMB+LTN6DPEmrwehtZMy(u"ࠩࠩ࡭ࡩࡃࠧᲕ")+id+XugxFprC26zGM(u"ࠪࠪ࡫ࡴࡡ࡮ࡧࡀࠫᲖ")+ED1Yx7AGRSBOviIst2j
		headers = {KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪᲗ"):egY8Jti0smdLM3h1VQRSW(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫᲘ")}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,EX25Y0l8ILvz7QcRC(u"࠭ࡐࡐࡕࡗࠫᲙ"),url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠸࡮ࡥࠩᲚ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠨࠤࡵࡩ࡫࡫ࡲࡦࡴࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲛ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7: return LyOR7f69iA(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᲜ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]]
	return w2vjZmdJuY7c(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧᲝ"),[],[]
def TYaLP7hqv8(url):
	headers = {RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧᲞ"):wY1p9mP03S8drbcH64t5WQkv(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭Ჟ")}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡇࡆࡖࠪᲠ"),url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲࠷ࡳࡵࠩᲡ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(eNEhtuoi9gK8JaTpIXj(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ტ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc].replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg)
		return ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᲣ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧᲤ"),[],[]
def jTiokqLutZ(url):
	E1Viom5L3684CTOFJ = url.split(f90fGrlSEObDsuiA3U(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬᲥ"),ehfEsaiJBSvbcULtNPVgykA2(u"࠴ࣘ"))[x1Oa8bBf36EwsLMirtFc].strip(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡅࠧᲦ")).strip(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭࠯ࠨᲧ")).strip(LTN6DPEmrwehtZMy(u"ࠧࠧࠩᲨ"))
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,items,ajHR9ABQl2buvm = [],[],[],eHdDoxhJCEPMZFVa2fg
	headers = { wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᲩ"):QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠩᲪ") }
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪࡋࡊ࡚ࠧᲫ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠳ࡶࡸࠬᲬ"))
	if XugxFprC26zGM(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᲭ") in list(aP8bLqZJsQlH3ivWKc.headers.keys()): ajHR9ABQl2buvm = aP8bLqZJsQlH3ivWKc.headers[S8i3sBYoHWdTURpAgN(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᲮ")]
	if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡩࡶࡷࡴࠬᲯ") in ajHR9ABQl2buvm:
		if ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩᲰ") in url: ajHR9ABQl2buvm = ajHR9ABQl2buvm.replace(ehfEsaiJBSvbcULtNPVgykA2(u"ࠩ࠲ࡪ࠴࠭Ჱ"),t3coAp06zvHrTl49bUVgx(u"ࠪ࠳ࡻ࠵ࠧᲲ"))
		dd4eVADo8jbaHCgISOQw6pKFLR = E1Viom5L3684CTOFJ.split(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡄࡖࡈࡑࡕࡌࡈࡂ࠭Ჳ"))[NSudqlOzja]
		headers = { KW5bYS20wTF1LyCs9(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᲴ"):headers[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᲵ")] , jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧᲶ"):HkiMU0QrdzW3l6gwnT(u"ࠨࡒࡋࡔࡘࡏࡄ࠾ࠩᲷ")+dd4eVADo8jbaHCgISOQw6pKFLR }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,NxXMrsTC5FniYuRBOK8(u"ࠩࡊࡉ࡙࠭Ჸ"),ajHR9ABQl2buvm,eHdDoxhJCEPMZFVa2fg,headers,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭Ჹ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		if f90fGrlSEObDsuiA3U(u"ࠫ࠴࡬࠯ࠨᲺ") in ajHR9ABQl2buvm: items = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠬࡂࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᲻"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		elif EX25Y0l8ILvz7QcRC(u"࠭࠯ࡷ࠱ࠪ᲼") in ajHR9ABQl2buvm: items = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲽ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if items: return [],[eHdDoxhJCEPMZFVa2fg],[ items[x1Oa8bBf36EwsLMirtFc] ]
		elif I5bUBGpPXn0W6(u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧᲾ") in nR2B1Wye7luXb5:
			return wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬᲿ"),[],[]
	else: return EX25Y0l8ILvz7QcRC(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭᳀"),[],[]
def YFehn7k38D(apOKrFbP9IYHDyUVm7):
	dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭᳁"),apOKrFbP9IYHDyUVm7+bP01xn84BiQN(u"ࠬࠬࠦࠨ᳂"),cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
	CJAVOZo730iHxPXp,ddzpB2kja9m6quyflHA = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
	url = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧ᳃")+CJAVOZo730iHxPXp+egY8Jti0smdLM3h1VQRSW(u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ᳄")+ddzpB2kja9m6quyflHA
	headers = { w2vjZmdJuY7c(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᳅"):eHdDoxhJCEPMZFVa2fg , f90fGrlSEObDsuiA3U(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ᳆"):QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ᳇") }
	E1Viom5L3684CTOFJ = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪ᳈"))
	return ietolwsjpIPK7Fr(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᳉"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
def QoJZN84LHx(url):
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,ietolwsjpIPK7Fr(u"࠭ࡵࡳ࡮ࠪ᳊"))
	W9PzsMeLJTc83mS45G17n = {eNEhtuoi9gK8JaTpIXj(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ᳋"):GfhcsvCWIon,Cp6c5tZe8I0PxnAW(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪ᳌"):XugxFprC26zGM(u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ᳍")}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(OclpauhMYPIx502SgUe1X7EWd,ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡋࡊ࡚ࠧ᳎"),url,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡆࡍࡒࡇ࠭࠲ࡵࡷࠫ᳏"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭᳐"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	E1Viom5L3684CTOFJ = eHdDoxhJCEPMZFVa2fg
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc]
		items = cBawilJXvK1m.findall(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ᳑"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
		for title,apOKrFbP9IYHDyUVm7 in items:
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		if len(ppQOjlq2gaPkW)==RqLvTrID0yMVeClpYcnZ16i3X(u"࠵ࣙ"): E1Viom5L3684CTOFJ = ppQOjlq2gaPkW[x1Oa8bBf36EwsLMirtFc]
		elif len(ppQOjlq2gaPkW)>GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠶ࣚ"):
			iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ᳒"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
			if iLcCSnPyKYWs3xkQ0p14==-f90fGrlSEObDsuiA3U(u"࠷ࣛ"): return eHdDoxhJCEPMZFVa2fg,[],[]
			E1Viom5L3684CTOFJ = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	else:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᳓"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: E1Viom5L3684CTOFJ = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc]
	if not E1Viom5L3684CTOFJ: return KW5bYS20wTF1LyCs9(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡃࡊࡏࡄ᳔ࠫ"),[],[]
	return NxXMrsTC5FniYuRBOK8(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ᳕࠭"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
def l5ikFnmCqh(url):
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,LTN6DPEmrwehtZMy(u"ࠫࡺࡸ࡬ࠨ᳖"))
	W9PzsMeLJTc83mS45G17n = {iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡘࡥࡧࡧࡵࡩࡷ᳗࠭"):GfhcsvCWIon,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ᳘"):XugxFprC26zGM(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫᳙ࠧ")}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(OclpauhMYPIx502SgUe1X7EWd,NxXMrsTC5FniYuRBOK8(u"ࠨࡉࡈࡘࠬ᳚"),url,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ᳛"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽᳜ࠫ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	E1Viom5L3684CTOFJ = eHdDoxhJCEPMZFVa2fg
	if RRztfCIs16MGxEHLJ25vDNAa7hpWT:
		cOUiow273ytu1GC5N0FJh = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc]
		items = cBawilJXvK1m.findall(EX25Y0l8ILvz7QcRC(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ᳝ࠪ"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
		FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
		for title,apOKrFbP9IYHDyUVm7 in items:
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
		if len(ppQOjlq2gaPkW)==LyOR7f69iA(u"࠱ࣜ"): E1Viom5L3684CTOFJ = ppQOjlq2gaPkW[x1Oa8bBf36EwsLMirtFc]
		elif len(ppQOjlq2gaPkW)>CKUiyEe28zsZ(u"࠲ࣝ"):
			iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(Cp6c5tZe8I0PxnAW(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิส᳞ࠪ"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
			if iLcCSnPyKYWs3xkQ0p14==-S8i3sBYoHWdTURpAgN(u"࠳ࣞ"): return eHdDoxhJCEPMZFVa2fg,[],[]
			E1Viom5L3684CTOFJ = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]
	if not E1Viom5L3684CTOFJ:
		RRztfCIs16MGxEHLJ25vDNAa7hpWT = cBawilJXvK1m.findall(HkiMU0QrdzW3l6gwnT(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ᳟ࠫࠥࠫ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if RRztfCIs16MGxEHLJ25vDNAa7hpWT: E1Viom5L3684CTOFJ = RRztfCIs16MGxEHLJ25vDNAa7hpWT[x1Oa8bBf36EwsLMirtFc]
	if not E1Viom5L3684CTOFJ: return CKUiyEe28zsZ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡉࡈࡏࡍࡂࠩ᳠"),[],[]
	return HkiMU0QrdzW3l6gwnT(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᳡"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
def RRXJPG8pa2(apOKrFbP9IYHDyUVm7):
	dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡡࡅࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠦࠨ᳢"),apOKrFbP9IYHDyUVm7+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"᳣ࠪࠪࠫ࠭"),cBawilJXvK1m.DOTALL)
	url,CJAVOZo730iHxPXp,ddzpB2kja9m6quyflHA = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
	data = {KQ3sCe9Pzh(u"ࠫࡵࡵࡳࡵࡡ࡬ࡨ᳤ࠬ"):CJAVOZo730iHxPXp,eNEhtuoi9gK8JaTpIXj(u"ࠬࡹࡥࡳࡸࡨࡶ᳥ࠬ"):ddzpB2kja9m6quyflHA}
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡐࡐࡕࡗ᳦ࠫ"),url,data,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎࡅࡄࡑ࠲࠷ࡳࡵ᳧ࠩ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(CKUiyEe28zsZ(u"ࠨ࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ᳨࠭ࠧ࠭"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[x1Oa8bBf36EwsLMirtFc]
	return egY8Jti0smdLM3h1VQRSW(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᳩ"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
def HH3fO9vDLW(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡋࡊ࡚ࠧᳪ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡑࡏࡇࡉࡖ࠰࠵ࡸࡺࠧᳫ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(ietolwsjpIPK7Fr(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᳬ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
		if apOKrFbP9IYHDyUVm7: return KW5bYS20wTF1LyCs9(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ᳭ࠩ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return Cp6c5tZe8I0PxnAW(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬᳮ"),[],[]
def jjR5Cdrlzi(url):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡉࡈࡘࠬᳯ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡆࡐ࡚ࡖ࠭࠲ࡵࡷࠫᳰ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠪࡀࡎࡌࡒࡂࡏࡈࠤࡘࡘࡃ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᳱ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[x1Oa8bBf36EwsLMirtFc]
	return RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᳲ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def iiyOUr0L5P(url):
	gXxmlY6uF78d4pHVhSMKyUCae2f = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࡻࡲ࡭ࠩᳳ"))
	if J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭᳴") in url:
		headers = {wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᳵ"):gXxmlY6uF78d4pHVhSMKyUCae2f}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,w2vjZmdJuY7c(u"ࠨࡉࡈࡘࠬᳶ"),url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠱ࡴࡶࠪ᳷"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(LyOR7f69iA(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᳸"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if E1Viom5L3684CTOFJ:
			E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]
			if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࡭ࡺࡴࡱࠩ᳹") not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = LTN6DPEmrwehtZMy(u"ࠬ࡮ࡴࡵࡲ࠽ࠫᳺ")+E1Viom5L3684CTOFJ
			if w2vjZmdJuY7c(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧ᳻") in E1Viom5L3684CTOFJ:
				E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.replace(t3coAp06zvHrTl49bUVgx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩ᳼"),KW5bYS20wTF1LyCs9(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩ᳽"))
				aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,Cp6c5tZe8I0PxnAW(u"ࠩࡊࡉ࡙࠭᳾"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫ᳿"))
				L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
				items = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠫࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴀ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
				FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
				qGa7FvNptsk = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,XugxFprC26zGM(u"ࠬࡻࡲ࡭ࠩᴁ"))
				for apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3 in reversed(items):
					apOKrFbP9IYHDyUVm7 = qGa7FvNptsk+apOKrFbP9IYHDyUVm7+Cp6c5tZe8I0PxnAW(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᴂ")+qGa7FvNptsk
					FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(s0s2bIZtWx8w3)
					ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
				return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
			else: return NxXMrsTC5FniYuRBOK8(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᴃ"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	E1Viom5L3684CTOFJ = url+wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᴄ")+gXxmlY6uF78d4pHVhSMKyUCae2f
	if CKUiyEe28zsZ(u"ࠩ࡫ࡸࡹࡶࠧᴅ") not in E1Viom5L3684CTOFJ: E1Viom5L3684CTOFJ = ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪ࡬ࡹࡺࡰ࠻ࠩᴆ")+E1Viom5L3684CTOFJ
	return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
def zQoE3ZYJnBTX7Ddpch1Iq(apOKrFbP9IYHDyUVm7):
	gXxmlY6uF78d4pHVhSMKyUCae2f = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡺࡸ࡬ࠨᴇ"))
	if NxXMrsTC5FniYuRBOK8(u"ࠬࡶ࡯ࡴࡶ࡬ࡨࠬᴈ") in apOKrFbP9IYHDyUVm7:
		dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࡞ࡂࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬᴉ"),apOKrFbP9IYHDyUVm7+Cp6c5tZe8I0PxnAW(u"ࠧࠧࠨࠪᴊ"),cBawilJXvK1m.DOTALL)
		url,CJAVOZo730iHxPXp,ddzpB2kja9m6quyflHA = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
		data = {KW5bYS20wTF1LyCs9(u"ࠨ࡫ࡧࠫᴋ"):CJAVOZo730iHxPXp,KW5bYS20wTF1LyCs9(u"ࠩࡶࡩࡷࡼࡥࡳࠩᴌ"):ddzpB2kja9m6quyflHA}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,EX25Y0l8ILvz7QcRC(u"ࠪࡔࡔ࡙ࡔࠨᴍ"),url,data,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠳ࡶࡸࠬᴎ"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(w2vjZmdJuY7c(u"ࠬ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴏ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)[x1Oa8bBf36EwsLMirtFc]
		if KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡣࡪ࡯ࡤࡲࡴࡽࠧᴐ") in E1Viom5L3684CTOFJ:
			headers = {bP01xn84BiQN(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᴑ"):gXxmlY6uF78d4pHVhSMKyUCae2f,S8i3sBYoHWdTURpAgN(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᴒ"):eHdDoxhJCEPMZFVa2fg}
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡊࡉ࡙࠭ᴓ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠳ࡰࡧࠫᴔ"))
			L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
			items = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸ࡯ࡺࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴕ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
			FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
			qGa7FvNptsk = b31wAB8mhaz2rXHoJFlfvDugtsOj(E1Viom5L3684CTOFJ,NxXMrsTC5FniYuRBOK8(u"ࠬࡻࡲ࡭ࠩᴖ"))
			for apOKrFbP9IYHDyUVm7,s0s2bIZtWx8w3 in reversed(items):
				apOKrFbP9IYHDyUVm7 = qGa7FvNptsk+apOKrFbP9IYHDyUVm7+CKUiyEe28zsZ(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᴗ")+qGa7FvNptsk
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(s0s2bIZtWx8w3)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
			return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
		else: return LTN6DPEmrwehtZMy(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᴘ"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	else:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+egY8Jti0smdLM3h1VQRSW(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᴙ")+gXxmlY6uF78d4pHVhSMKyUCae2f
		return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
def bbrLcgqASe(apOKrFbP9IYHDyUVm7):
	if t3coAp06zvHrTl49bUVgx(u"ࠩࡳࡳࡸࡺࡩࡥࠩᴚ") in apOKrFbP9IYHDyUVm7:
		dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬᴛ"),apOKrFbP9IYHDyUVm7+f90fGrlSEObDsuiA3U(u"ࠫࠫࠬࠧᴜ"),cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		CJAVOZo730iHxPXp,ddzpB2kja9m6quyflHA = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
		XmWBjLi8A2qhzKCJ7p6r = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡻࡲ࡭ࠩᴝ"))
		url = XmWBjLi8A2qhzKCJ7p6r+CKUiyEe28zsZ(u"࠭࠯ࡢ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵࡃࡤࡧࡣࡵ࡫ࡲࡲࡂ࡭ࡥࡵࡵࡨࡶࡻ࡫ࡲࠧࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠫᴞ")+CJAVOZo730iHxPXp+bP01xn84BiQN(u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫᴟ")+ddzpB2kja9m6quyflHA
		headers = { NxXMrsTC5FniYuRBOK8(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᴠ"):eHdDoxhJCEPMZFVa2fg , wY1p9mP03S8drbcH64t5WQkv(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬᴡ"):ietolwsjpIPK7Fr(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫᴢ") }
		E1Viom5L3684CTOFJ = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡅࡐࡎࡕࡎ࡛࠯࠴ࡷࡹ࠭ᴣ"))
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).replace(y1fVB2E63aLnJgkWeCZHujY,eHdDoxhJCEPMZFVa2fg)
		return ietolwsjpIPK7Fr(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴤ"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	elif f90fGrlSEObDsuiA3U(u"࠭࠯ࡳࡧࡧ࡭ࡷ࡫ࡣࡵ࠱ࠪᴥ") in apOKrFbP9IYHDyUVm7:
		ww8qbZ4QgUcmjEYkiL73OCozha1 = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠳ࣟ")
		while EX25Y0l8ILvz7QcRC(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫᴦ") in apOKrFbP9IYHDyUVm7 and ww8qbZ4QgUcmjEYkiL73OCozha1<KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠹࣠"):
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡉࡈࡘࠬᴧ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡃࡎࡌࡓࡓࡠ࠭࠳ࡰࡧࠫᴨ"))
			if EX25Y0l8ILvz7QcRC(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᴩ") in list(aP8bLqZJsQlH3ivWKc.headers.keys()): apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᴪ")]
			ww8qbZ4QgUcmjEYkiL73OCozha1 += bP01xn84BiQN(u"࠶࣡")
		return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	else: return TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠩᴫ"),[],[]
def wLhCnjZVsc(url):
	GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,HkiMU0QrdzW3l6gwnT(u"࠭ࡵࡳ࡮ࠪᴬ"))
	headers = {ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᴭ"):GfhcsvCWIon,HkiMU0QrdzW3l6gwnT(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᴮ"):qq62QA8h3pGxzCwWVeXIF7glKf()}
	if bP01xn84BiQN(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪᴯ") in url:
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡗࡊࡋࡄ࠮࠴ࡱࡨࠬᴰ"))
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴱ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if apOKrFbP9IYHDyUVm7:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc].replace(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬ࡮ࡴࡵࡲࡶࠫᴲ"),LTN6DPEmrwehtZMy(u"࠭ࡨࡵࡶࡳࠫᴳ"))
			return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	else:
		ZyfwPOAGcg7DReX5njJzk = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,XugxFprC26zGM(u"ࠧࡈࡇࡗࠫᴴ"),url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠳ࡳࡦࠪᴵ"))
		nR2B1Wye7luXb5 = ZyfwPOAGcg7DReX5njJzk.content
		W9PzsMeLJTc83mS45G17n = headers.copy()
		if w2vjZmdJuY7c(u"ࠩࡢࡰࡳࡱ࡟ࠨᴶ") in str(ZyfwPOAGcg7DReX5njJzk.cookies):
			cookies = ZyfwPOAGcg7DReX5njJzk.cookies
			W9PzsMeLJTc83mS45G17n[KQ3sCe9Pzh(u"ࠪࡇࡴࡵ࡫ࡪࡧࠪᴷ")] = zrHeZWCqQMOymk1d7anKpu0vEx8(GHIgY9AomX(cookies))
		apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡱ࡯࡮࡬࠰࡫ࡶࡪ࡬ࠠ࠾ࠢࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧᴸ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not apOKrFbP9IYHDyUVm7: return ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴹ"),[eHdDoxhJCEPMZFVa2fg],[url]
		else:
			apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc])+LyOR7f69iA(u"࠭ࠦࡥ࠿࠴ࠫᴺ")
			NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡈࡇࡗࠫᴻ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡕࡈࡉࡉ࠳࠴ࡵࡪࠪᴼ"))
			nR2B1Wye7luXb5 = NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.content
			apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࡬ࡨࡂࠨࡢࡵࡰࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᴽ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if apOKrFbP9IYHDyUVm7:
				apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc])
				if Cp6c5tZe8I0PxnAW(u"ࠪࡱࡵ࠺ࠧᴾ") in apOKrFbP9IYHDyUVm7 and XugxFprC26zGM(u"ࠫ࠴ࡪ࠯ࠨᴿ") in apOKrFbP9IYHDyUVm7: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
				else: return ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᵀ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return w2vjZmdJuY7c(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡅࡇ࡙ࡅࡆࡆࠪᵁ"),[],[]
def Wuqtfv8FCG(apOKrFbP9IYHDyUVm7):
	if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠫᵂ") in apOKrFbP9IYHDyUVm7:
		headers = {jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫᵃ"):QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪᵄ")}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠪࡋࡊ࡚ࠧᵅ"),apOKrFbP9IYHDyUVm7,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡊࡄࡌࡎࡊ࠴ࡖ࠯࠴ࡷࡹ࠭ᵆ"))
		url = aP8bLqZJsQlH3ivWKc.content
		if url: return w2vjZmdJuY7c(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᵇ"),[eHdDoxhJCEPMZFVa2fg],[url]
	else:
		dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡰࡰࡵࡷ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࡹࡥࡳࡸࡨࡶ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠪࠧᵈ"),apOKrFbP9IYHDyUVm7,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		if not dezG4T3itVrAKvX9: dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠦࠪᵉ"),apOKrFbP9IYHDyUVm7,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		CJAVOZo730iHxPXp,ddzpB2kja9m6quyflHA = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
		GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(apOKrFbP9IYHDyUVm7,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡷࡵࡰࠬᵊ"))
		url = GfhcsvCWIon+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࠲ࡻࡵ࠳ࡣࡰࡰࡷࡩࡳࡺ࠯ࡵࡪࡨࡱࡪࡹ࠯ࡵࡪࡨࡱࡪ࠵ࡁ࡫ࡣࡻࡥࡹ࠵ࡓࡪࡰࡪࡰࡪ࠵ࡓࡦࡴࡹࡩࡷ࠴ࡰࡩࡲࠪᵋ")
		data = {QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪ࡭ࡩ࠭ᵌ"):CJAVOZo730iHxPXp,jUcmHhgVvW0EdYOIfXeaDF(u"ࠫ࡮࠭ᵍ"):ddzpB2kja9m6quyflHA}
		headers = {egY8Jti0smdLM3h1VQRSW(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨᵎ"):ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧᵏ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᵐ"):apOKrFbP9IYHDyUVm7}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡒࡒࡗ࡙࠭ᵑ"),url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡙ࡈࡂࡊࡌࡈ࠹࡛࠭࠳ࡰࡧࠫᵒ"))
		L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
		E1Viom5L3684CTOFJ = cBawilJXvK1m.findall(EX25Y0l8ILvz7QcRC(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᵓ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		if E1Viom5L3684CTOFJ:
			E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ[x1Oa8bBf36EwsLMirtFc]
			return LTN6DPEmrwehtZMy(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᵔ"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	return S8i3sBYoHWdTURpAgN(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᵕ"),[],[]
def puHE2DAJFiz(rzOc9GVUHpxDRFAL75dJPob4TlgsBn):
	kIjiW3UcJeGMQ1z7SnDh025sq = MoO74hKeqm8fFka.getSetting(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡡࡷ࠰ࡤ࡯ࡼࡧ࡭࠯ࡸࡨࡶ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠧᵖ"))
	headers = {ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧᵗ"):kIjiW3UcJeGMQ1z7SnDh025sq} if kIjiW3UcJeGMQ1z7SnDh025sq else eHdDoxhJCEPMZFVa2fg
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡉࡈࡘࠬᵘ"),rzOc9GVUHpxDRFAL75dJPob4TlgsBn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠷ࡳࡵࠩᵙ"))
	Jp4gyvhXLMkzW06SVbZK5 = aP8bLqZJsQlH3ivWKc.content
	t3j7MdkQwHi0KJoC = str(aP8bLqZJsQlH3ivWKc.headers)
	AAhGYdZ8XDzyp0m6kLIqreNnuvS = t3j7MdkQwHi0KJoC+Jp4gyvhXLMkzW06SVbZK5
	if S8i3sBYoHWdTURpAgN(u"ࠪ࠲ࡲࡶ࠴ࠨᵚ") in AAhGYdZ8XDzyp0m6kLIqreNnuvS: PrQyXW5TAoS = YchIv6N09BaWPEj4tieAnluKZrRXT
	else:
		KKl1pnNIryCH,L6GuZYmNyAEUBi1sQ,CE3tyVRNWKGfkIOwnmFv7q,Io3U5phKexRmkydAHZX0,PrQyXW5TAoS = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z
		captcha = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᵛ"),Jp4gyvhXLMkzW06SVbZK5,cBawilJXvK1m.DOTALL)
		if captcha: CE3tyVRNWKGfkIOwnmFv7q,Io3U5phKexRmkydAHZX0 = captcha[x1Oa8bBf36EwsLMirtFc]
		O5imCYrX91pNTqkWP230Gb7uD = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[KQ3sCe9Pzh(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬᵜ")][eNEhtuoi9gK8JaTpIXj(u"࠽࣢")]
		if Cp6c5tZe8I0PxnAW(u"࠰ࣣ"):
			data = {dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡵࡴࡧࡵࠫᵝ"):ZylBO1ktRGvdJ0,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨᵞ"):MCrWtwnF2TViZOD7z0pXgqI4,NxXMrsTC5FniYuRBOK8(u"ࠨࡷࡵࡰࠬᵟ"):rzOc9GVUHpxDRFAL75dJPob4TlgsBn,ehfEsaiJBSvbcULtNPVgykA2(u"ࠩ࡮ࡩࡾ࠭ᵠ"):Io3U5phKexRmkydAHZX0,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪ࡭ࡩ࠭ᵡ"):eHdDoxhJCEPMZFVa2fg,TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫ࡯ࡵࡢࠨᵢ"):w2vjZmdJuY7c(u"ࠬ࡭ࡥࡵࡷࡵࡰࡸ࠭ᵣ")}
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡐࡐࡕࡗࠫᵤ"),O5imCYrX91pNTqkWP230Gb7uD,data,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,f90fGrlSEObDsuiA3U(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠶ࡳࡪࠧᵥ"))
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		nR2B1Wye7luXb5 = eHdDoxhJCEPMZFVa2fg
		if nR2B1Wye7luXb5.startswith(jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡗࡕࡐࡘࡃࠧᵦ")):
			yoPm1UMpR0VCchze6nZkTArEWlNv3s = DIpuHqsKGS3ErJvk9taCRiX80(ilBWK5nXxg1do4jENGC07Zq(u"ࠩ࡯࡭ࡸࡺࠧᵧ"),nR2B1Wye7luXb5.split(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࡙ࠪࡗࡒࡓ࠾ࠩᵨ"),ilBWK5nXxg1do4jENGC07Zq(u"࠲ࣤ"))[NSudqlOzja])
			for mzfT1LoKkCy7g9wuSqV in yoPm1UMpR0VCchze6nZkTArEWlNv3s:
				url = mzfT1LoKkCy7g9wuSqV[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡺࡸ࡬ࠨᵩ")]
				fb9C73uPyN = mzfT1LoKkCy7g9wuSqV[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡳࡥࡵࡪࡲࡨࠬᵪ")]
				data = mzfT1LoKkCy7g9wuSqV[I5bUBGpPXn0W6(u"࠭ࡤࡢࡶࡤࠫᵫ")]
				headers = mzfT1LoKkCy7g9wuSqV[J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨᵬ")]
				aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,fb9C73uPyN,url,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨᵭ"))
				Jp4gyvhXLMkzW06SVbZK5 = aP8bLqZJsQlH3ivWKc.content
				if HkiMU0QrdzW3l6gwnT(u"ࠩ࠱ࡱࡵ࠺ࠧᵮ") in Jp4gyvhXLMkzW06SVbZK5:
					PrQyXW5TAoS = YchIv6N09BaWPEj4tieAnluKZrRXT
					break
				t3j7MdkQwHi0KJoC = str(aP8bLqZJsQlH3ivWKc.headers)
				AAhGYdZ8XDzyp0m6kLIqreNnuvS = t3j7MdkQwHi0KJoC+Jp4gyvhXLMkzW06SVbZK5
				KKl1pnNIryCH = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࠬࡦࡱࡷࡢ࡯࡙ࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮࡝ࡹ࠮࠭࠳࠰࠿ࠣࠪࡨࡽࡏ࠴ࠪࡀࠫࠥࠫᵯ"),AAhGYdZ8XDzyp0m6kLIqreNnuvS,cBawilJXvK1m.DOTALL)
				L6GuZYmNyAEUBi1sQ = cBawilJXvK1m.findall(S8i3sBYoHWdTURpAgN(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡵࡱ࡮ࡩࡳ࠴ࠪࡀࠤࠫ࠴࠸ࡇ࠮ࠫࡁࠬࠦࠬᵰ"),AAhGYdZ8XDzyp0m6kLIqreNnuvS,cBawilJXvK1m.DOTALL)
				if L6GuZYmNyAEUBi1sQ: L6GuZYmNyAEUBi1sQ = L6GuZYmNyAEUBi1sQ[x1Oa8bBf36EwsLMirtFc]
				if KKl1pnNIryCH or L6GuZYmNyAEUBi1sQ: break
		if not PrQyXW5TAoS:
			if not KKl1pnNIryCH:
				if captcha and not L6GuZYmNyAEUBi1sQ:
					if iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠳ࣥ"): L6GuZYmNyAEUBi1sQ = skwPQphCbmFYRMD0LWq(Io3U5phKexRmkydAHZX0,LyOR7f69iA(u"ࠬࡧࡲࠨᵱ"),rzOc9GVUHpxDRFAL75dJPob4TlgsBn)
					else:
						if not nR2B1Wye7luXb5.startswith(egY8Jti0smdLM3h1VQRSW(u"࠭ࡉࡅ࠿ࠪᵲ")):
							data = {ietolwsjpIPK7Fr(u"ࠧࡶࡵࡨࡶࠬᵳ"):ZylBO1ktRGvdJ0,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩᵴ"):MCrWtwnF2TViZOD7z0pXgqI4,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩࡸࡶࡱ࠭ᵵ"):rzOc9GVUHpxDRFAL75dJPob4TlgsBn,KQ3sCe9Pzh(u"ࠪ࡯ࡪࡿࠧᵶ"):Io3U5phKexRmkydAHZX0,bP01xn84BiQN(u"ࠫ࡮ࡪࠧᵷ"):eHdDoxhJCEPMZFVa2fg,HkiMU0QrdzW3l6gwnT(u"ࠬࡰ࡯ࡣࠩᵸ"):I5bUBGpPXn0W6(u"࠭ࡧࡦࡶ࡬ࡨࠬᵹ")}
							aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,ietolwsjpIPK7Fr(u"ࠧࡑࡑࡖࡘࠬᵺ"),O5imCYrX91pNTqkWP230Gb7uD,data,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠹ࡺࡨࠨᵻ"))
							nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
						else: nR2B1Wye7luXb5 = ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡌࡈࡂ࠷࠲࠴࠶࠽࠾࠿ࡀࡔࡊࡏࡈࡓ࡚࡚࠽࠵࠷ࠪᵼ")
						if nR2B1Wye7luXb5.startswith(ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡍࡉࡃࠧᵽ")):
							XQ3mT28AJSiMh7c9FZlp5djBLE = cBawilJXvK1m.findall(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡎࡊ࠽ࠩ࠰࠭ࡃ࠮ࡀ࠺࠻࠼ࡗࡍࡒࡋࡏࡖࡖࡀࠬ࠳࠰࠿ࠪࠦࠪᵾ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
							WqGp5TVJe1SK,MbacDJogKp5ElfIi = XQ3mT28AJSiMh7c9FZlp5djBLE[x1Oa8bBf36EwsLMirtFc]
							sh3cDaZzUkKQFEAl74OryuPtGqJ = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬํะ่ࠢส่฾๋ไ๋หࠣฮาะวอ๋ࠢๆฯࠦๅ็ࠢ࠴࠴ࠥหไ๊ࠢࠪᵿ")+MbacDJogKp5ElfIi+f90fGrlSEObDsuiA3U(u"࠭ࠠฬษ้๎ฮ࠭ᶀ")
							nNHfB2iT893EUZtSd = R62V7GXNPvf8()
							nNHfB2iT893EUZtSd.create(t3coAp06zvHrTl49bUVgx(u"ࠧๆฯส์้ฯࠠหฮส์ืࠦแฮืࠣว๋อࠠฤ่ึห๋่ࠦๅีอࠤอืๆศ็ฯࠤ่๎ๅษ์๋ฮึ࠭ᶁ"),sh3cDaZzUkKQFEAl74OryuPtGqJ)
							Ppsc1X7zb46N90TeSCRaD = b8bLFaejUB.time()
							ggz9kaWmr2S4pRnD3ZAFwK0E,MjnrwJB35EdqWeA4bID09fa = t3coAp06zvHrTl49bUVgx(u"࠳ࣦ"),t3coAp06zvHrTl49bUVgx(u"࠳ࣦ")
							while ggz9kaWmr2S4pRnD3ZAFwK0E<int(MbacDJogKp5ElfIi):
								evP9UQfyEcG5hBwVzl(nNHfB2iT893EUZtSd,int(ggz9kaWmr2S4pRnD3ZAFwK0E/int(MbacDJogKp5ElfIi)*iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠵࠵࠶ࣧ")),sh3cDaZzUkKQFEAl74OryuPtGqJ,eHdDoxhJCEPMZFVa2fg,MbacDJogKp5ElfIi+XugxFprC26zGM(u"ࠨࠢ࠲ࠤࠬᶂ")+str(int(ggz9kaWmr2S4pRnD3ZAFwK0E))+EX25Y0l8ILvz7QcRC(u"ࠩࠣࠤะอๆ๋หࠪᶃ"))
								if ggz9kaWmr2S4pRnD3ZAFwK0E>MjnrwJB35EdqWeA4bID09fa+CKUiyEe28zsZ(u"࠶࠶ࣨ"):
									data = {ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡹࡸ࡫ࡲࠨᶄ"):ZylBO1ktRGvdJ0,Cp6c5tZe8I0PxnAW(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬᶅ"):MCrWtwnF2TViZOD7z0pXgqI4,LyOR7f69iA(u"ࠬࡻࡲ࡭ࠩᶆ"):rzOc9GVUHpxDRFAL75dJPob4TlgsBn,KW5bYS20wTF1LyCs9(u"࠭࡫ࡦࡻࠪᶇ"):Io3U5phKexRmkydAHZX0,ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡪࡦࠪᶈ"):WqGp5TVJe1SK,wY1p9mP03S8drbcH64t5WQkv(u"ࠨ࡬ࡲࡦࠬᶉ"):bP01xn84BiQN(u"ࠩࡪࡩࡹࡺ࡯࡬ࡧࡱࠫᶊ")}
									aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,KW5bYS20wTF1LyCs9(u"ࠪࡔࡔ࡙ࡔࠨᶋ"),O5imCYrX91pNTqkWP230Gb7uD,data,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠶ࡶ࡫ࠫᶌ"))
									nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
									if nR2B1Wye7luXb5.startswith(wY1p9mP03S8drbcH64t5WQkv(u"࡚ࠬࡏࡌࡇࡑࡁࠬᶍ")):
										L6GuZYmNyAEUBi1sQ = nR2B1Wye7luXb5.split(ehfEsaiJBSvbcULtNPVgykA2(u"࠭ࡔࡐࡍࡈࡒࡂ࠭ᶎ"),Cp6c5tZe8I0PxnAW(u"࠷ࣩ"))[NSudqlOzja]
										break
									MjnrwJB35EdqWeA4bID09fa = ggz9kaWmr2S4pRnD3ZAFwK0E
								else: b8bLFaejUB.sleep(t3coAp06zvHrTl49bUVgx(u"࠱࣪"))
								ggz9kaWmr2S4pRnD3ZAFwK0E = b8bLFaejUB.time()-Ppsc1X7zb46N90TeSCRaD
							nNHfB2iT893EUZtSd.close()
				if L6GuZYmNyAEUBi1sQ:
					br1kyc3SMLGa0TN = aP8bLqZJsQlH3ivWKc.cookies
					CknO1y0jpJ9uoYsL6GQfRiv = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠧࡢ࡭ࡺࡥࡲࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠩ࠰࠭ࡃ࠮ࡁࠧᶏ"),AAhGYdZ8XDzyp0m6kLIqreNnuvS,cBawilJXvK1m.DOTALL)
					if EX25Y0l8ILvz7QcRC(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨᶐ") in list(br1kyc3SMLGa0TN.keys()): CknO1y0jpJ9uoYsL6GQfRiv = br1kyc3SMLGa0TN[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩᶑ")]
					elif CknO1y0jpJ9uoYsL6GQfRiv: CknO1y0jpJ9uoYsL6GQfRiv = CknO1y0jpJ9uoYsL6GQfRiv[x1Oa8bBf36EwsLMirtFc]
					captcha = cBawilJXvK1m.findall(LyOR7f69iA(u"ࠪࡴࡦ࡭ࡥ࠮ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠱࠮ࡄࡧࡣࡵ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡪࡶࡨ࡯ࡪࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᶒ"),Jp4gyvhXLMkzW06SVbZK5,cBawilJXvK1m.DOTALL)
					if captcha: CE3tyVRNWKGfkIOwnmFv7q,Io3U5phKexRmkydAHZX0 = captcha[x1Oa8bBf36EwsLMirtFc]
					if CknO1y0jpJ9uoYsL6GQfRiv and captcha:
						headers = {bP01xn84BiQN(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫᶓ"):KQ3sCe9Pzh(u"ࠬࡧ࡫ࡸࡣࡰࡣࡸ࡫ࡳࡴ࡫ࡲࡲࡂ࠭ᶔ")+CknO1y0jpJ9uoYsL6GQfRiv,CKUiyEe28zsZ(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᶕ"):rzOc9GVUHpxDRFAL75dJPob4TlgsBn,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ᶖ"):t3coAp06zvHrTl49bUVgx(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧᶗ")}
						data = LyOR7f69iA(u"ࠩࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦ࠿ࠪᶘ")+L6GuZYmNyAEUBi1sQ
						aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡔࡔ࡙ࡔࠨᶙ"),CE3tyVRNWKGfkIOwnmFv7q,data,headers,rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠷ࡶ࡫ࠫᶚ"))
						Jp4gyvhXLMkzW06SVbZK5 = aP8bLqZJsQlH3ivWKc.content
						try: cookies = aP8bLqZJsQlH3ivWKc.cookies
						except: cookies = {}
						KKl1pnNIryCH = cBawilJXvK1m.findall(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧ࠭ࠨࡢ࡭ࡺࡥࡲ࡜ࡥࡳ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱ࠲࠯ࡅࠩࠨ࠼ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦᶛ"),str(cookies),cBawilJXvK1m.DOTALL)
			if KKl1pnNIryCH:
				Pe9ETSvwUGBnkC1hO,KKl1pnNIryCH = KKl1pnNIryCH[x1Oa8bBf36EwsLMirtFc]
				kIjiW3UcJeGMQ1z7SnDh025sq = Pe9ETSvwUGBnkC1hO+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭࠽ࠨᶜ")+KKl1pnNIryCH
				MoO74hKeqm8fFka.setSetting(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨᶝ"),kIjiW3UcJeGMQ1z7SnDh025sq)
				dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᶞ"),NxXMrsTC5FniYuRBOK8(u"้ࠩะาะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฦ่ึห๋ࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหาื์ࠠ็ฬสสัࠦ็ัษࠣห้็อึࠢ็็๏๊ࠦิฬัำ๊ํวࠡๆสั็อࠠ࠯࠰ࠣ์้อࠠห๊ฯำࠥำวอห่ࠣส฿วะห๋ࠣีอࠠศๆไัฺࠦไฺัฬࠤศฺ็าࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไโฯุࠤุ๎แࠡ์อ็ึืࠠโ์ࠣัฬ๊ษࠡฬ฽๎ึࠦัษูࠣห้า็ศิࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหืโษฤࠤึอ่หำࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤๆ฻ไࠡี็็ࠥอไาษ๋ฮึࠦ࠮࠯ࠢฦ์ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦศา๊ๆื๏࠭ᶟ"))
				if I5bUBGpPXn0W6(u"ࠪ࠲ࡲࡶ࠴ࠨᶠ") not in Jp4gyvhXLMkzW06SVbZK5:
					headers = {bP01xn84BiQN(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫᶡ"):kIjiW3UcJeGMQ1z7SnDh025sq}
					aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,LyOR7f69iA(u"ࠬࡍࡅࡕࠩᶢ"),rzOc9GVUHpxDRFAL75dJPob4TlgsBn,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭ᶣ"))
					Jp4gyvhXLMkzW06SVbZK5 = aP8bLqZJsQlH3ivWKc.content
	if not PrQyXW5TAoS and not kIjiW3UcJeGMQ1z7SnDh025sq: dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪᶤ"),HkiMU0QrdzW3l6gwnT(u"ࠨใื่ฯูࠦๆๆํอࠥ็อึࠢฦ๊ฬࠦร็ีส๊ࠥ࠴࠮ࠡฯส์้ࠦลฺษาอࠥอไฺ็็๎ฮࠦๅาหࠣวำื้ࠡสสืฯิฯศ็๊ࠣๆูࠠศๆไ๎ิ๐่ࠡล๋ࠤๆ๐ฯ๋๊ࠣ฾๏ื็ࠡ็้ࠤ๋็ำࠡษ็้ํู่ࠨᶥ"))
	return Jp4gyvhXLMkzW06SVbZK5
def CUTcRwrWs9(url,type,s0s2bIZtWx8w3):
	wROf6m4Ix73jtsdnZ1vpCDuV,YYs45omUWpDLndclV = [],[]
	rzOc9GVUHpxDRFAL75dJPob4TlgsBn = url
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡊࡉ࡙࠭ᶦ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LTN6DPEmrwehtZMy(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠷ࡳࡵࠩᶧ"))
	L3f4VRFXh0Sb1xwKPzoi = aP8bLqZJsQlH3ivWKc.content
	KHScimU69tMCJLYr5PW3 = []
	if t3coAp06zvHrTl49bUVgx(u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬᶨ") in L3f4VRFXh0Sb1xwKPzoi or NxXMrsTC5FniYuRBOK8(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩᶩ") in L3f4VRFXh0Sb1xwKPzoi:
		ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵ࠴ࠪࡀ࠾࠲ࡥࡃ࠭ᶪ"),L3f4VRFXh0Sb1xwKPzoi,cBawilJXvK1m.DOTALL)
		if ekNMoIJzswUSDVQf564:
			for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
				JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall(LTN6DPEmrwehtZMy(u"ࠧࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫᶫ"),cOUiow273ytu1GC5N0FJh,cBawilJXvK1m.DOTALL)
				for apOKrFbP9IYHDyUVm7,title in JCZVK86QTYwX4mfgOrod:
					if apOKrFbP9IYHDyUVm7 in wROf6m4Ix73jtsdnZ1vpCDuV: continue
					if ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࠱ࡺࡥࡹࡩࡨ࠰ࠩᶬ") not in apOKrFbP9IYHDyUVm7 and S8i3sBYoHWdTURpAgN(u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠴࠭ᶭ") not in apOKrFbP9IYHDyUVm7: continue
					if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪหࠬᶮ") not in title:
						KHScimU69tMCJLYr5PW3.append((title,apOKrFbP9IYHDyUVm7))
						continue
					title = title.replace(KW5bYS20wTF1LyCs9(u"ࠫࡁ࠵ࡳࡱࡣࡱࡂࠬᶯ"),eHdDoxhJCEPMZFVa2fg).replace(I5bUBGpPXn0W6(u"ࠬࠦ࠭ࠡࠩᶰ"),eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j).replace(KwJyZLDzC4FbHhXgTfI,avcfIls8w7gk69hYUErHxzQTXtm24j)
					if t3coAp06zvHrTl49bUVgx(u"࠭ࡳࡱࡣࡱࠫᶱ") in title: continue
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
					YYs45omUWpDLndclV.append(title)
			for title,apOKrFbP9IYHDyUVm7 in KHScimU69tMCJLYr5PW3:
				if apOKrFbP9IYHDyUVm7 not in wROf6m4Ix73jtsdnZ1vpCDuV:
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
					YYs45omUWpDLndclV.append(title)
			iLcCSnPyKYWs3xkQ0p14 = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠱࣫")
			if len(wROf6m4Ix73jtsdnZ1vpCDuV)>wY1p9mP03S8drbcH64t5WQkv(u"࠳࣬"):
				iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(t3coAp06zvHrTl49bUVgx(u"ࠧษ฻ู๋ฬ๊ࠦฮฬสะࠥ࠼࠰ࠡอส๊๏ฯࠧᶲ"),YYs45omUWpDLndclV)
				if iLcCSnPyKYWs3xkQ0p14==-XugxFprC26zGM(u"࠴࣭"): return QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠥࡇࡋࡘࡃࡐࠫᶳ"),[],[]
			if wROf6m4Ix73jtsdnZ1vpCDuV and iLcCSnPyKYWs3xkQ0p14>=f90fGrlSEObDsuiA3U(u"࠴࣮"): rzOc9GVUHpxDRFAL75dJPob4TlgsBn = wROf6m4Ix73jtsdnZ1vpCDuV[iLcCSnPyKYWs3xkQ0p14]
	Jp4gyvhXLMkzW06SVbZK5 = puHE2DAJFiz(rzOc9GVUHpxDRFAL75dJPob4TlgsBn)
	ppQOjlq2gaPkW,FBITEXGDfe2mcCxnQs6ktMdy9HJh = [],[]
	if type==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫᶴ"):
		oNFBVYpm0t = cBawilJXvK1m.findall(w2vjZmdJuY7c(u"ࠪࡦࡹࡴ࠭࡭ࡱࡤࡨࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᶵ"),Jp4gyvhXLMkzW06SVbZK5,cBawilJXvK1m.DOTALL)
		if oNFBVYpm0t:
			apOKrFbP9IYHDyUVm7 = zrHeZWCqQMOymk1d7anKpu0vEx8(oNFBVYpm0t[x1Oa8bBf36EwsLMirtFc])
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(s0s2bIZtWx8w3)
	elif type==RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࡼࡧࡴࡤࡪࠪᶶ"):
		JCZVK86QTYwX4mfgOrod = cBawilJXvK1m.findall(LTN6DPEmrwehtZMy(u"ࠬࡂࡳࡰࡷࡵࡧࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᶷ"),Jp4gyvhXLMkzW06SVbZK5,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7,size in JCZVK86QTYwX4mfgOrod:
			if not apOKrFbP9IYHDyUVm7: continue
			if s0s2bIZtWx8w3 in size:
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(size)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
				break
		if not ppQOjlq2gaPkW:
			for apOKrFbP9IYHDyUVm7,size in JCZVK86QTYwX4mfgOrod:
				if not apOKrFbP9IYHDyUVm7: continue
				FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(size)
				ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if not ppQOjlq2gaPkW: return RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎ࡛ࡆࡓࠧᶸ"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def Fea5Jby2kR(url,Pe9ETSvwUGBnkC1hO):
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,XugxFprC26zGM(u"ࠧࡈࡇࡗࠫᶹ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠵ࡸࡺࠧᶺ"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	cookies = aP8bLqZJsQlH3ivWKc.cookies
	if EX25Y0l8ILvz7QcRC(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩᶻ") in list(cookies.keys()):
		kIjiW3UcJeGMQ1z7SnDh025sq = cookies[I5bUBGpPXn0W6(u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪᶼ")]
		kIjiW3UcJeGMQ1z7SnDh025sq = zrHeZWCqQMOymk1d7anKpu0vEx8(XXcKxHD7jfmMoyQ0dZRCV1sPzv2(kIjiW3UcJeGMQ1z7SnDh025sq))
		items = cBawilJXvK1m.findall(XugxFprC26zGM(u"ࠫࡷࡵࡵࡵࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᶽ"),kIjiW3UcJeGMQ1z7SnDh025sq,cBawilJXvK1m.DOTALL)
		E1Viom5L3684CTOFJ = items[x1Oa8bBf36EwsLMirtFc].replace(KQ3sCe9Pzh(u"ࠬࡢ࠯ࠨᶾ"),LyOR7f69iA(u"࠭࠯ࠨᶿ"))
		E1Viom5L3684CTOFJ = XXcKxHD7jfmMoyQ0dZRCV1sPzv2(E1Viom5L3684CTOFJ)
	else: E1Viom5L3684CTOFJ = url
	if EX25Y0l8ILvz7QcRC(u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ᷀") in E1Viom5L3684CTOFJ:
		id = E1Viom5L3684CTOFJ.split(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࠧ࠵ࡊࠬ᷁"))[-f90fGrlSEObDsuiA3U(u"࠶࣯")]
		E1Viom5L3684CTOFJ = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡥࡹࡩࡨ࠯࡫ࡶ࠳᷂ࠬ")+id
		return wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᷃"),[eHdDoxhJCEPMZFVa2fg],[E1Viom5L3684CTOFJ]
	else:
		website = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[XugxFprC26zGM(u"ࠫࡆࡑࡏࡂࡏࠪ᷄")][x1Oa8bBf36EwsLMirtFc]
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(bbfreYhcgwZlKEGVx7zRU,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࡍࡅࡕࠩ᷅"),website,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,YchIv6N09BaWPEj4tieAnluKZrRXT,eHdDoxhJCEPMZFVa2fg,EX25Y0l8ILvz7QcRC(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠴ࡱࡨࠬ᷆"))
		H5HD9LUJol = aP8bLqZJsQlH3ivWKc.url
		cwWPyA9hl5O3 = E1Viom5L3684CTOFJ.split(w2vjZmdJuY7c(u"ࠧ࠰ࠩ᷇"))[FB0pIzAoK8wqgd3UiY5]
		Z5lCjgHkypLMtw4SPxinWEK73d1Jz = H5HD9LUJol.split(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨ࠱ࠪ᷈"))[FB0pIzAoK8wqgd3UiY5]
		ajHR9ABQl2buvm = E1Viom5L3684CTOFJ.replace(cwWPyA9hl5O3,Z5lCjgHkypLMtw4SPxinWEK73d1Jz)
		headers = { HkiMU0QrdzW3l6gwnT(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭᷉"):eHdDoxhJCEPMZFVa2fg , eNEhtuoi9gK8JaTpIXj(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭᷊࠭"):iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ᷋") , jUcmHhgVvW0EdYOIfXeaDF(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭᷌"):ajHR9ABQl2buvm }
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡐࡐࡕࡗࠫ᷍"), ajHR9ABQl2buvm, eHdDoxhJCEPMZFVa2fg, headers, rDceXBpHkfVUYRJ3tIx95Z,eHdDoxhJCEPMZFVa2fg,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ᷎࠭"))
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		items = cBawilJXvK1m.findall(KQ3sCe9Pzh(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᷏"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		if not items:
			items = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ᷐ࠪ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
			if not items:
				items = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᷑"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL|cBawilJXvK1m.IGNORECASE)
		if items:
			apOKrFbP9IYHDyUVm7 = items[x1Oa8bBf36EwsLMirtFc].replace(Cp6c5tZe8I0PxnAW(u"ࠫࡡ࠵ࠧ᷒"),t3coAp06zvHrTl49bUVgx(u"ࠬ࠵ࠧᷓ"))
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.rstrip(I5bUBGpPXn0W6(u"࠭࠯ࠨᷔ"))
			if ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡩࡶࡷࡴࠬᷕ") not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = I5bUBGpPXn0W6(u"ࠨࡪࡷࡸࡵࡀࠧᷖ") + apOKrFbP9IYHDyUVm7
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(ilBWK5nXxg1do4jENGC07Zq(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࠪᷗ"),S8i3sBYoHWdTURpAgN(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬᷘ"))
			if Pe9ETSvwUGBnkC1hO==eHdDoxhJCEPMZFVa2fg: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
			else: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᷙ"),[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
		else: CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = XugxFprC26zGM(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍࡒࡅࡒ࠭ᷚ"),[],[]
		return CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def rB5Iypubvh42OtawzxWMK8(url):
	headers = { RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᷛ") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫᷜ"))
	items = cBawilJXvK1m.findall(HkiMU0QrdzW3l6gwnT(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᷝ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW,errno = [],[],eHdDoxhJCEPMZFVa2fg
	if items:
		for apOKrFbP9IYHDyUVm7,jZHGcWxXpdVO038fnt in items:
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(jZHGcWxXpdVO038fnt)
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if len(ppQOjlq2gaPkW)==Cp6c5tZe8I0PxnAW(u"࠶ࣰ"): return ehfEsaiJBSvbcULtNPVgykA2(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏࠨᷞ"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def h67PMUgvqLSOBWXV3tprms25Cy1H(url):
	headers = {f90fGrlSEObDsuiA3U(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᷟ"):eHdDoxhJCEPMZFVa2fg}
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡓࡏࡓࡆࡊ࠭࠲ࡵࡷࠫᷠ"))
	items = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠬࡹ࡯ࡶࡴࡦࡩࡸࡀࠠ࡝࡝ࠥࠬ࠳࠰࠿ࠪࠤࠪᷡ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		url = items[x1Oa8bBf36EwsLMirtFc]+RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᷢ")+url
		return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[url]
	else: return I5bUBGpPXn0W6(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡕࡑࡕࡁࡅࠩᷣ"),[],[]
def hkiWPtMdzVONqnIlYAmpXcvrgLZR(url):
	url = url.strip(S8i3sBYoHWdTURpAgN(u"ࠨ࠱ࠪᷤ"))
	if XugxFprC26zGM(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪᷥ") in url: id = url.split(bP01xn84BiQN(u"ࠪ࠳ࠬᷦ"))[BSw5mizCOsKxWrRDvtJuFajY]
	else: id = url.split(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࠴࠭ᷧ"))[-jUcmHhgVvW0EdYOIfXeaDF(u"࠱ࣱ")]
	url = TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩᷨ") + id
	headers = { t3coAp06zvHrTl49bUVgx(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᷩ") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡈ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩᷪ"))
	nR2B1Wye7luXb5 = nR2B1Wye7luXb5.replace(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨ࡞࡟ࠫᷫ"),eHdDoxhJCEPMZFVa2fg)
	items = cBawilJXvK1m.findall(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩᷬ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[ items[x1Oa8bBf36EwsLMirtFc] ]
	else: return KQ3sCe9Pzh(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡜ࡃࡔࡖࡕࡉࡆࡓࠧᷭ"),[],[]
def q9qVyFAwfN4zg5HPQnWMGxCR(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡋࡇࡓ࡟ࡇ࠭࠲ࡵࡷࠫᷮ"))
	items = cBawilJXvK1m.findall(ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠠࡳࡧࡶ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᷯ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	for apOKrFbP9IYHDyUVm7,jZHGcWxXpdVO038fnt,qP2i0GOngzrMYVDKIF6ab in items:
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(jZHGcWxXpdVO038fnt+avcfIls8w7gk69hYUErHxzQTXtm24j+qP2i0GOngzrMYVDKIF6ab)
		ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if len(ppQOjlq2gaPkW)==wY1p9mP03S8drbcH64t5WQkv(u"࠱ࣲ"): return Cp6c5tZe8I0PxnAW(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡘࡌࡈࡔࡠࡁࠨᷰ"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def wHU1RT5ngXjKD(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡆ࡚ࡃࡉࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫᷱ"))
	items = cBawilJXvK1m.findall(eNEhtuoi9gK8JaTpIXj(u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡺ࡮ࡪࡥࡰ࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬࡢࠩ࡝ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠪࡀ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࠽࠱ࡷࡨࡃࠨᷲ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	items = set(items)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	for id,tWi3JH8rRhxcgnYuMVUK,hash,jZHGcWxXpdVO038fnt,qP2i0GOngzrMYVDKIF6ab in items:
		url = t3coAp06zvHrTl49bUVgx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵ࠮ࡶࡵ࠲ࡨࡱࡅ࡯ࡱ࠿ࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡴࡸࡩࡨࠨ࡬ࡨࡂ࠭ᷳ")+id+wY1p9mP03S8drbcH64t5WQkv(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪᷴ")+tWi3JH8rRhxcgnYuMVUK+KQ3sCe9Pzh(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ᷵")+hash
		nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ᷶"))
		items = cBawilJXvK1m.findall(LyOR7f69iA(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ᷷ࠬࠦࠬ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		for apOKrFbP9IYHDyUVm7 in items:
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(jZHGcWxXpdVO038fnt+avcfIls8w7gk69hYUErHxzQTXtm24j+qP2i0GOngzrMYVDKIF6ab)
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
	if len(ppQOjlq2gaPkW)==bP01xn84BiQN(u"࠲ࣳ"): return J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ᷸࠭"),[],[]
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def FFeQa1DvosIbwSV3LtPNkUGC(url):
	apOKrFbP9IYHDyUVm7 = eHdDoxhJCEPMZFVa2fg
	if I5bUBGpPXn0W6(u"࠴ࣴ") or wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡍࡨࡽࡂ᷹࠭") not in url:
		E1Viom5L3684CTOFJ = url.replace(NxXMrsTC5FniYuRBOK8(u"ࠩࡸࡴࡧࡵ࡭࠯࡮࡬ࡺࡪ᷺࠭"),f90fGrlSEObDsuiA3U(u"ࠪࡹࡵࡶ࡯࡮࠰࡯࡭ࡻ࡫ࠧ᷻"))
		E1Viom5L3684CTOFJ = E1Viom5L3684CTOFJ.split(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫ࠴࠭᷼"))
		id = E1Viom5L3684CTOFJ[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]
		E1Viom5L3684CTOFJ = EX25Y0l8ILvz7QcRC(u"ࠬ࠵᷽ࠧ").join(E1Viom5L3684CTOFJ[ietolwsjpIPK7Fr(u"࠴ࣵ"):KW5bYS20wTF1LyCs9(u"࠹ࣶ")])
		j6KOlzWGugZqmx0sPS = {GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡩࡥࠩ᷾"):id,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧࡰࡲ᷿ࠪ"):egY8Jti0smdLM3h1VQRSW(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫḀ"),bP01xn84BiQN(u"ࠩࡰࡩࡹ࡮࡯ࡥࡡࡩࡶࡪ࡫ࠧḁ"):f90fGrlSEObDsuiA3U(u"ࠪࡊࡷ࡫ࡥࠬࡆࡲࡻࡳࡲ࡯ࡢࡦ࠮ࠩ࠸ࡋࠥ࠴ࡇࠪḂ")}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,HkiMU0QrdzW3l6gwnT(u"ࠫࡕࡕࡓࡕࠩḃ"),E1Viom5L3684CTOFJ,j6KOlzWGugZqmx0sPS,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡓࡆࡔࡓ࠭࠲ࡵࡷࠫḄ"))
		if NxXMrsTC5FniYuRBOK8(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨḅ") in list(aP8bLqZJsQlH3ivWKc.headers.keys()): apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[KW5bYS20wTF1LyCs9(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩḆ")]
		if not apOKrFbP9IYHDyUVm7 and aP8bLqZJsQlH3ivWKc.succeeded:
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
			apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨ࡫ࡧࡁࠧࡪࡩࡳࡧࡦࡸࡤࡲࡩ࡯࡭ࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬḇ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
	else:
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡊࡉ࡙࠭Ḉ"),url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠸࡮ࡥࠩḉ"))
		if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭Ḋ") in list(aP8bLqZJsQlH3ivWKc.headers.keys()): apOKrFbP9IYHDyUVm7 = aP8bLqZJsQlH3ivWKc.headers[ehfEsaiJBSvbcULtNPVgykA2(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧḋ")]
	if apOKrFbP9IYHDyUVm7: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	return QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡓࡆࡔࡓࠧḌ"),[],[]
def h8hUwAB3iKLYHRpkWE59xZ1v(url):
	headers = { w2vjZmdJuY7c(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫḍ") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,XugxFprC26zGM(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡑࡏࡉࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪḎ"))
	items = cBawilJXvK1m.findall(LTN6DPEmrwehtZMy(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࠪ࠱࠮ࡄ࠯ࠢࠨḏ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [],[]
	if items:
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(I5bUBGpPXn0W6(u"ࠪࡱࡵ࠺ࠧḐ"))
		ppQOjlq2gaPkW.append(items[x1Oa8bBf36EwsLMirtFc][NSudqlOzja])
		FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(Cp6c5tZe8I0PxnAW(u"ࠫࡲ࠹ࡵ࠹ࠩḑ"))
		ppQOjlq2gaPkW.append(items[x1Oa8bBf36EwsLMirtFc][x1Oa8bBf36EwsLMirtFc])
		return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
	else: return S8i3sBYoHWdTURpAgN(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡍࡋࡌ࡚ࡎࡊࡅࡐࠩḒ"),[],[]
CCDTylGVAF5ahzPjteRWpdnwI0N = rDceXBpHkfVUYRJ3tIx95Z
def e27zOM5Tmb(url):
	global CCDTylGVAF5ahzPjteRWpdnwI0N
	if CCDTylGVAF5ahzPjteRWpdnwI0N: return ietolwsjpIPK7Fr(u"࠭ࡅࡳࡴࡲࡶࠥࠦࠠࠡ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡟ࡏࡖࡖࡘࡆࡊࠦࡆࡢ࡫࡯ࡩࡩ࠭ḓ"),[],[]
	CCDTylGVAF5ahzPjteRWpdnwI0N = YchIv6N09BaWPEj4tieAnluKZrRXT
	id = url.split(eNEhtuoi9gK8JaTpIXj(u"ࠧ࠰ࠩḔ"))[-jUcmHhgVvW0EdYOIfXeaDF(u"࠷ࣷ")]
	id = id.split(XugxFprC26zGM(u"ࠨࠨࠪḕ"))[x1Oa8bBf36EwsLMirtFc]
	id = id.replace(wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫḖ"),eHdDoxhJCEPMZFVa2fg)
	E1Viom5L3684CTOFJ = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[KW5bYS20wTF1LyCs9(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫḗ")][x1Oa8bBf36EwsLMirtFc]+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧḘ")+id
	R8RfLGIiSYUtQ = t3coAp06zvHrTl49bUVgx(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࡯ࡶࡶࡸ࠲ࡧ࡫࠯ࠨḙ")+id
	xk9fB2YKJRyt0DcPXNHTSiLQ,FA9sKIS20rvDMn,ClMvFfmwunY,Vpnwvx26jWqH3ysMAiQ = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	headers = {iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪḚ"):eHdDoxhJCEPMZFVa2fg}
	if bP01xn84BiQN(u"࠰ࣸ"):
		for gMmB3iopS0ZXrOFewhcxt in range(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠶ࣹ")):
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,S8i3sBYoHWdTURpAgN(u"ࠧࡈࡇࡗࠫḛ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,LyOR7f69iA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩḜ"))
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
			if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩ࡬ࡸࡦ࡭ࠧḝ") in nR2B1Wye7luXb5: break
			b8bLFaejUB.sleep(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠴ࣺ"))
		zULDufV4d3mQ = cBawilJXvK1m.findall(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡓࡰࡦࡿࡥࡳࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧḞ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if zULDufV4d3mQ: zULDufV4d3mQ = zULDufV4d3mQ[x1Oa8bBf36EwsLMirtFc]
		else: zULDufV4d3mQ = nR2B1Wye7luXb5
	else:
		nR2B1Wye7luXb5 = eHdDoxhJCEPMZFVa2fg
		headers[jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪḟ")] = LyOR7f69iA(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨḠ")
		ajHR9ABQl2buvm = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[J7divaGOCgq2SLfXpDzZYN58wc(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧḡ")][x1Oa8bBf36EwsLMirtFc]+NxXMrsTC5FniYuRBOK8(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡰ࡭ࡣࡼࡩࡷ࠭Ḣ")
		RaJf24z7sOkrApTlSCPi3 = EX25Y0l8ILvz7QcRC(u"ࠨࡽࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨḣ")+id+jUcmHhgVvW0EdYOIfXeaDF(u"ࠩࠥ࠰ࠥࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠶࠴࠹ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡆࡔࡄࡓࡑࡌࡈࡤ࡚ࡅࡔࡖࡖ࡙ࡎ࡚ࡅࠣࡿࢀࢁࠬḤ")
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡔࡔ࡙ࡔࠨḥ"),ajHR9ABQl2buvm,RaJf24z7sOkrApTlSCPi3,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬḦ"))
		zULDufV4d3mQ = aP8bLqZJsQlH3ivWKc.content
	zULDufV4d3mQ = zULDufV4d3mQ.replace(LyOR7f69iA(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ḧ"),jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࠦࠨḨ"))
	LLhpkdOojJyaRWzrI = DIpuHqsKGS3ErJvk9taCRiX80(egY8Jti0smdLM3h1VQRSW(u"ࠧࡥ࡫ࡦࡸࠬḩ"),zULDufV4d3mQ)
	FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = [NxXMrsTC5FniYuRBOK8(u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬḪ")],[eHdDoxhJCEPMZFVa2fg]
	try:
		jPWZ2aGV6qBwxvO8mYdJurlUy = LLhpkdOojJyaRWzrI[eNEhtuoi9gK8JaTpIXj(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡶࠫḫ")][J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧḬ")][EX25Y0l8ILvz7QcRC(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲ࡙ࡸࡡࡤ࡭ࡶࠫḭ")]
		for pp2VEXJiPnzLK1gx in jPWZ2aGV6qBwxvO8mYdJurlUy:
			apOKrFbP9IYHDyUVm7 = pp2VEXJiPnzLK1gx[wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡨࡡࡴࡧࡘࡶࡱ࠭Ḯ")]
			try: title = pp2VEXJiPnzLK1gx[KW5bYS20wTF1LyCs9(u"࠭࡮ࡢ࡯ࡨࠫḯ")][KW5bYS20wTF1LyCs9(u"ࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫḰ")]
			except: title = pp2VEXJiPnzLK1gx[ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡰࡤࡱࡪ࠭ḱ")][eNEhtuoi9gK8JaTpIXj(u"ࠩࡵࡹࡳࡹࠧḲ")][x1Oa8bBf36EwsLMirtFc][t3coAp06zvHrTl49bUVgx(u"ࠪࡸࡪࡾࡴࡵࠩḳ")]
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
	except: pass
	if len(FBITEXGDfe2mcCxnQs6ktMdy9HJh)>w2vjZmdJuY7c(u"࠴ࣻ"):
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(t3coAp06zvHrTl49bUVgx(u"ࠫฬิสาࠢส่ฯืฬๆหࠣࠬࠬḴ")+str(len(FBITEXGDfe2mcCxnQs6ktMdy9HJh))+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࠦๅๅใࠬࠫḵ"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
		if iLcCSnPyKYWs3xkQ0p14==-egY8Jti0smdLM3h1VQRSW(u"࠵ࣼ"): return ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫḶ"),[],[]
		elif iLcCSnPyKYWs3xkQ0p14!=KQ3sCe9Pzh(u"࠵ࣽ"):
			apOKrFbP9IYHDyUVm7 = ppQOjlq2gaPkW[iLcCSnPyKYWs3xkQ0p14]+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࠧࠩḷ")
			tsy4p9hHvl5RK7SdzeU1EkmF3 = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭Ḹ"),apOKrFbP9IYHDyUVm7)
			if tsy4p9hHvl5RK7SdzeU1EkmF3: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(tsy4p9hHvl5RK7SdzeU1EkmF3[x1Oa8bBf36EwsLMirtFc],XugxFprC26zGM(u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪḹ"))
			else: apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫḺ")
			xk9fB2YKJRyt0DcPXNHTSiLQ = apOKrFbP9IYHDyUVm7.strip(XugxFprC26zGM(u"ࠫࠫ࠭ḻ"))
	u78ONxfoYs,aFuJY01gUwTkS8,MgyH4P2VLOfFdzRjDIU7Ys6,BhJ4zrbnPK7wTAk1xZ,aJRkoEKrCuei07MYZvxdXlB9 = [],[],[],[],[]
	try: FA9sKIS20rvDMn = LLhpkdOojJyaRWzrI[bP01xn84BiQN(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬḼ")][S8i3sBYoHWdTURpAgN(u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨḽ")]
	except: pass
	try: ClMvFfmwunY = LLhpkdOojJyaRWzrI[egY8Jti0smdLM3h1VQRSW(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧḾ")][bP01xn84BiQN(u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩḿ")]
	except: pass
	try: u78ONxfoYs = LLhpkdOojJyaRWzrI[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩṀ")][CKUiyEe28zsZ(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫṁ")]
	except: pass
	try: aFuJY01gUwTkS8 = LLhpkdOojJyaRWzrI[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫṂ")][LyOR7f69iA(u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧṃ")]
	except: pass
	D6f1uKLYAWIws95Se0cQRGim8zNP3H = u78ONxfoYs+aFuJY01gUwTkS8
	for dict in D6f1uKLYAWIws95Se0cQRGim8zNP3H:
		if ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡩࡵࡣࡪࠫṄ") in list(dict.keys()): dict[HkiMU0QrdzW3l6gwnT(u"ࠧࡪࡶࡤ࡫ࠬṅ")] = str(dict[iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨ࡫ࡷࡥ࡬࠭Ṇ")])
		if Cp6c5tZe8I0PxnAW(u"ࠩࡩࡴࡸ࠭ṇ") in list(dict.keys()): dict[egY8Jti0smdLM3h1VQRSW(u"ࠪࡪࡵࡹࠧṈ")] = str(dict[CKUiyEe28zsZ(u"ࠫ࡫ࡶࡳࠨṉ")])
		if eNEhtuoi9gK8JaTpIXj(u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧṊ") in list(dict.keys()): dict[jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡴࡺࡲࡨࠫṋ")] = dict[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩṌ")]
		if S8i3sBYoHWdTURpAgN(u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪṍ") in list(dict.keys()): dict[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭Ṏ")] = str(dict[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬṏ")])
		if LTN6DPEmrwehtZMy(u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫṐ") in list(dict.keys()): dict[CKUiyEe28zsZ(u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ṑ")] = str(dict[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭Ṓ")])
		if eNEhtuoi9gK8JaTpIXj(u"ࠧࡸ࡫ࡧࡸ࡭࠭ṓ") in list(dict.keys()): dict[t3coAp06zvHrTl49bUVgx(u"ࠨࡵ࡬ࡾࡪ࠭Ṕ")] = str(dict[w2vjZmdJuY7c(u"ࠩࡺ࡭ࡩࡺࡨࠨṕ")])+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡼࠬṖ")+str(dict[ehfEsaiJBSvbcULtNPVgykA2(u"ࠫ࡭࡫ࡩࡨࡪࡷࠫṗ")])
		if ehfEsaiJBSvbcULtNPVgykA2(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨṘ") in list(dict.keys()): dict[jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡩ࡯࡫ࡷࠫṙ")] = dict[ehfEsaiJBSvbcULtNPVgykA2(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪṚ")][I5bUBGpPXn0W6(u"ࠨࡵࡷࡥࡷࡺࠧṛ")]+egY8Jti0smdLM3h1VQRSW(u"ࠩ࠰ࠫṜ")+dict[Cp6c5tZe8I0PxnAW(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭ṝ")][KQ3sCe9Pzh(u"ࠫࡪࡴࡤࠨṞ")]
		if ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩṟ") in list(dict.keys()): dict[eNEhtuoi9gK8JaTpIXj(u"࠭ࡩ࡯ࡦࡨࡼࠬṠ")] = dict[w2vjZmdJuY7c(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫṡ")][XugxFprC26zGM(u"ࠨࡵࡷࡥࡷࡺࠧṢ")]+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࠰ࠫṣ")+dict[w2vjZmdJuY7c(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧṤ")][I5bUBGpPXn0W6(u"ࠫࡪࡴࡤࠨṥ")]
		if Cp6c5tZe8I0PxnAW(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭Ṧ") in list(dict.keys()): dict[NxXMrsTC5FniYuRBOK8(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧṧ")] = dict[t3coAp06zvHrTl49bUVgx(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨṨ")]
		if t3coAp06zvHrTl49bUVgx(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩṩ") in list(dict.keys()) and int(dict[EX25Y0l8ILvz7QcRC(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪṪ")])>XugxFprC26zGM(u"࠷࠱࠲࠴࠵࠶࠸࠹࠳ࣾ"): del dict[w2vjZmdJuY7c(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫṫ")]
		if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭Ṭ") in list(dict.keys()):
			OWUv2KfG8JatSgZQ9MTCPpqc4m = dict[ietolwsjpIPK7Fr(u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧṭ")].split(t3coAp06zvHrTl49bUVgx(u"࠭ࠦࠨṮ"))
			for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in OWUv2KfG8JatSgZQ9MTCPpqc4m:
				key,q5qDOCzEe0Lv4ZyJbWnaPcpVsB = AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠧ࠾ࠩṯ"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠱ࣿ"))
				dict[key] = zrHeZWCqQMOymk1d7anKpu0vEx8(q5qDOCzEe0Lv4ZyJbWnaPcpVsB)
		if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡷࡵࡰࠬṰ") in list(dict.keys()): dict[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡸࡶࡱ࠭ṱ")] = zrHeZWCqQMOymk1d7anKpu0vEx8(dict[LTN6DPEmrwehtZMy(u"ࠪࡹࡷࡲࠧṲ")])
		MgyH4P2VLOfFdzRjDIU7Ys6.append(dict)
	smp92YPTJqXydRf0KvQC3j1WAzl7F = eHdDoxhJCEPMZFVa2fg
	if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡸࡶ࠽ࡴ࡫ࡪࠫṳ") in zULDufV4d3mQ:
		if not nR2B1Wye7luXb5:
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡍࡅࡕࠩṴ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,w2vjZmdJuY7c(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠷ࡷࡪࠧṵ"))
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		y6y7vqaIENetGlxBKcnsdUiOoMu = cBawilJXvK1m.findall(HkiMU0QrdzW3l6gwnT(u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱࡟ࡻ࠯ࡅ࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟࠯࠰࠲ࡦࡦࡹࡥ࠯࡬ࡶ࠭ࠧ࠭Ṷ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if y6y7vqaIENetGlxBKcnsdUiOoMu:
			y6y7vqaIENetGlxBKcnsdUiOoMu = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[XugxFprC26zGM(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩṷ")][x1Oa8bBf36EwsLMirtFc]+y6y7vqaIENetGlxBKcnsdUiOoMu[x1Oa8bBf36EwsLMirtFc]
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,I5bUBGpPXn0W6(u"ࠩࡊࡉ࡙࠭Ṹ"),y6y7vqaIENetGlxBKcnsdUiOoMu,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠵ࡶ࡫ࠫṹ"))
			smp92YPTJqXydRf0KvQC3j1WAzl7F = aP8bLqZJsQlH3ivWKc.content
			import youtube_signature.cipher as qqIhk27pUrF5NYPlSsg86edQcn,youtube_signature.json_script_engine as EWjmDJYUB90fqKoXawdTFA5h
			OWUv2KfG8JatSgZQ9MTCPpqc4m = JJ63gSnFpMxT9HyioQlmBGDKPWA.OWUv2KfG8JatSgZQ9MTCPpqc4m.Cipher()
			OWUv2KfG8JatSgZQ9MTCPpqc4m._object_cache = {}
			KKBiHSdJONafQzo0FsVCnelhIwU = OWUv2KfG8JatSgZQ9MTCPpqc4m._load_javascript(smp92YPTJqXydRf0KvQC3j1WAzl7F)
			nrKvAtjlE24WusqDgL836GY = DIpuHqsKGS3ErJvk9taCRiX80(w2vjZmdJuY7c(u"ࠫࡸࡺࡲࠨṺ"),str(KKBiHSdJONafQzo0FsVCnelhIwU))
			B6TJGz0wHsFMyRo4uSfDXrnNe1d = JJ63gSnFpMxT9HyioQlmBGDKPWA.hqCfJmA96DbS0VLOTz4dHa7uyv8PK.JsonScriptEngine(nrKvAtjlE24WusqDgL836GY)
	for dict in MgyH4P2VLOfFdzRjDIU7Ys6:
		url = dict[w2vjZmdJuY7c(u"ࠬࡻࡲ࡭ࠩṻ")]
		if wY1p9mP03S8drbcH64t5WQkv(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠿ࠪṼ") in url or url.count(bP01xn84BiQN(u"ࠧࡴ࡫ࡪࡁࠬṽ"))>wY1p9mP03S8drbcH64t5WQkv(u"࠲ऀ"):
			BhJ4zrbnPK7wTAk1xZ.append(dict)
		elif smp92YPTJqXydRf0KvQC3j1WAzl7F and RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡵࠪṾ") in list(dict.keys()) and GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡶࡴࠬṿ") in list(dict.keys()):
			MkejYSRhDZwmn7GTcAfXNxU4 = B6TJGz0wHsFMyRo4uSfDXrnNe1d.execute(dict[ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡷࠬẀ")])
			if MkejYSRhDZwmn7GTcAfXNxU4!=dict[S8i3sBYoHWdTURpAgN(u"ࠫࡸ࠭ẁ")]:
				dict[bP01xn84BiQN(u"ࠬࡻࡲ࡭ࠩẂ")] = url+EX25Y0l8ILvz7QcRC(u"࠭ࠦࠨẃ")+dict[CKUiyEe28zsZ(u"ࠧࡴࡲࠪẄ")]+EX25Y0l8ILvz7QcRC(u"ࠨ࠿ࠪẅ")+MkejYSRhDZwmn7GTcAfXNxU4
				BhJ4zrbnPK7wTAk1xZ.append(dict)
	for dict in BhJ4zrbnPK7wTAk1xZ:
		N63IHpMe8P,PysrOdvp8N1b40GQVLBnf,srcZOqvy37xdFU,FyWTVmEXrYwtpUBujRMxZb,Npn6lA9PfvZgxeWk2t,PHrtMU1sgahiE = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪẆ"),ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫẇ"),KQ3sCe9Pzh(u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬẈ"),jUcmHhgVvW0EdYOIfXeaDF(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭ẉ"),eHdDoxhJCEPMZFVa2fg,ietolwsjpIPK7Fr(u"࠭࠰ࠨẊ")
		try:
			SSc8J5X3DypAs09MrqKBkUeHaC = dict[S8i3sBYoHWdTURpAgN(u"ࠧࡵࡻࡳࡩࠬẋ")]
			SSc8J5X3DypAs09MrqKBkUeHaC = SSc8J5X3DypAs09MrqKBkUeHaC.replace(Cp6c5tZe8I0PxnAW(u"ࠨ࠭ࠪẌ"),eHdDoxhJCEPMZFVa2fg)
			items = cBawilJXvK1m.findall(S8i3sBYoHWdTURpAgN(u"ࠩࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫẍ"),SSc8J5X3DypAs09MrqKBkUeHaC,cBawilJXvK1m.DOTALL)
			FyWTVmEXrYwtpUBujRMxZb,N63IHpMe8P,Npn6lA9PfvZgxeWk2t = items[x1Oa8bBf36EwsLMirtFc]
			EEYrqUSthNPL = Npn6lA9PfvZgxeWk2t.split(ilBWK5nXxg1do4jENGC07Zq(u"ࠪ࠰ࠬẎ"))
			PysrOdvp8N1b40GQVLBnf = eHdDoxhJCEPMZFVa2fg
			for AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ in EEYrqUSthNPL: PysrOdvp8N1b40GQVLBnf += AXbxkE53yI2mnSKMLhTsYOG9C6FNcQ.split(CKUiyEe28zsZ(u"ࠫ࠳࠭ẏ"))[x1Oa8bBf36EwsLMirtFc]+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࠲ࠧẐ")
			PysrOdvp8N1b40GQVLBnf = PysrOdvp8N1b40GQVLBnf.strip(egY8Jti0smdLM3h1VQRSW(u"࠭ࠬࠨẑ"))
			if jUcmHhgVvW0EdYOIfXeaDF(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨẒ") in list(dict.keys()): PHrtMU1sgahiE = str(float(dict[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩẓ")]*wY1p9mP03S8drbcH64t5WQkv(u"࠳࠳ँ"))//w2vjZmdJuY7c(u"࠴࠴࠷࠺ं")/wY1p9mP03S8drbcH64t5WQkv(u"࠳࠳ँ"))+ehfEsaiJBSvbcULtNPVgykA2(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩẔ")
			else: PHrtMU1sgahiE = eHdDoxhJCEPMZFVa2fg
			if FyWTVmEXrYwtpUBujRMxZb==CKUiyEe28zsZ(u"ࠪࡸࡪࡾࡴࡵࠩẕ"): continue
			elif CKUiyEe28zsZ(u"ࠫ࠱࠭ẖ") in SSc8J5X3DypAs09MrqKBkUeHaC:
				FyWTVmEXrYwtpUBujRMxZb = wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡇࠫࡗࠩẗ")
				srcZOqvy37xdFU = N63IHpMe8P+KwJyZLDzC4FbHhXgTfI+PHrtMU1sgahiE+dict[eNEhtuoi9gK8JaTpIXj(u"࠭ࡳࡪࡼࡨࠫẘ")].split(HkiMU0QrdzW3l6gwnT(u"ࠧࡹࠩẙ"))[NSudqlOzja]
			elif FyWTVmEXrYwtpUBujRMxZb==HkiMU0QrdzW3l6gwnT(u"ࠨࡸ࡬ࡨࡪࡵࠧẚ"):
				FyWTVmEXrYwtpUBujRMxZb = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࡙ࠩ࡭ࡩ࡫࡯ࠨẛ")
				srcZOqvy37xdFU = PHrtMU1sgahiE+dict[ietolwsjpIPK7Fr(u"ࠪࡷ࡮ࢀࡥࠨẜ")].split(bP01xn84BiQN(u"ࠫࡽ࠭ẝ"))[NSudqlOzja]+KwJyZLDzC4FbHhXgTfI+dict[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬ࡬ࡰࡴࠩẞ")]+S8i3sBYoHWdTURpAgN(u"࠭ࡦࡱࡵࠪẟ")+KwJyZLDzC4FbHhXgTfI+N63IHpMe8P
			elif FyWTVmEXrYwtpUBujRMxZb==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࡢࡷࡧ࡭ࡴ࠭Ạ"):
				FyWTVmEXrYwtpUBujRMxZb = wY1p9mP03S8drbcH64t5WQkv(u"ࠨࡃࡸࡨ࡮ࡵࠧạ")
				srcZOqvy37xdFU = PHrtMU1sgahiE+str(int(dict[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭Ả")])/J7divaGOCgq2SLfXpDzZYN58wc(u"࠵࠵࠶࠰ः"))+ietolwsjpIPK7Fr(u"ࠪ࡯࡭ࢀࠠࠡࠩả")+dict[ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬẤ")]+NxXMrsTC5FniYuRBOK8(u"ࠬࡩࡨࠨấ")+KwJyZLDzC4FbHhXgTfI+N63IHpMe8P
		except:
			pw9fgsSRmnKId80YbU1PA = Wf01HbdyEtp5N4BUKCcY7.format_exc()
			if pw9fgsSRmnKId80YbU1PA!=RqLvTrID0yMVeClpYcnZ16i3X(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩẦ"): jjO4Xf7GBW8Dx2HR0tdP.stderr.write(pw9fgsSRmnKId80YbU1PA)
		if wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡥࡷࡵࡁࠬầ") in dict[eNEhtuoi9gK8JaTpIXj(u"ࠨࡷࡵࡰࠬẨ")]: WWPgm9fvlH2oIOnrD1 = round(ehfEsaiJBSvbcULtNPVgykA2(u"࠶࠮࠶अ")+float(dict[egY8Jti0smdLM3h1VQRSW(u"ࠩࡸࡶࡱ࠭ẩ")].split(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪࡨࡺࡸ࠽ࠨẪ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠶ऄ"))[NSudqlOzja].split(EX25Y0l8ILvz7QcRC(u"ࠫࠫ࠭ẫ"),KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠶ऄ"))[x1Oa8bBf36EwsLMirtFc]))
		elif XugxFprC26zGM(u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨẬ") in list(dict.keys()): WWPgm9fvlH2oIOnrD1 = round(NxXMrsTC5FniYuRBOK8(u"࠰࠯࠷आ")+float(dict[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩậ")])/Cp6c5tZe8I0PxnAW(u"࠲࠲࠳࠴इ"))
		else: WWPgm9fvlH2oIOnrD1 = ilBWK5nXxg1do4jENGC07Zq(u"ࠧ࠱ࠩẮ")
		if eNEhtuoi9gK8JaTpIXj(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩắ") not in list(dict.keys()): PHrtMU1sgahiE = dict[XugxFprC26zGM(u"ࠩࡶ࡭ࡿ࡫ࠧẰ")].split(eNEhtuoi9gK8JaTpIXj(u"ࠪࡼࠬằ"))[NSudqlOzja]
		else: PHrtMU1sgahiE = dict[KQ3sCe9Pzh(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬẲ")]
		if f90fGrlSEObDsuiA3U(u"ࠬ࡯࡮ࡪࡶࠪẳ") not in list(dict.keys()): dict[NxXMrsTC5FniYuRBOK8(u"࠭ࡩ࡯࡫ࡷࠫẴ")] = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠧ࠱࠯࠳ࠫẵ")
		dict[EX25Y0l8ILvz7QcRC(u"ࠨࡶ࡬ࡸࡱ࡫ࠧẶ")] = FyWTVmEXrYwtpUBujRMxZb+I5bUBGpPXn0W6(u"ࠩ࠽ࠤࠥ࠭ặ")+srcZOqvy37xdFU+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࠤࠥ࠮ࠧẸ")+PysrOdvp8N1b40GQVLBnf+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫ࠱࠭ẹ")+dict[bP01xn84BiQN(u"ࠬ࡯ࡴࡢࡩࠪẺ")]+wY1p9mP03S8drbcH64t5WQkv(u"࠭ࠩࠨẻ")
		dict[KW5bYS20wTF1LyCs9(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨẼ")] = srcZOqvy37xdFU.split(KwJyZLDzC4FbHhXgTfI)[x1Oa8bBf36EwsLMirtFc].split(S8i3sBYoHWdTURpAgN(u"ࠨ࡭ࡥࡴࡸ࠭ẽ"))[x1Oa8bBf36EwsLMirtFc]
		dict[dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩࡷࡽࡵ࡫࠲ࠨẾ")] = FyWTVmEXrYwtpUBujRMxZb
		dict[S8i3sBYoHWdTURpAgN(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬế")] = N63IHpMe8P
		dict[dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠫࡨࡵࡤࡦࡥࡶࠫỀ")] = Npn6lA9PfvZgxeWk2t
		dict[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧề")] = WWPgm9fvlH2oIOnrD1
		dict[Cp6c5tZe8I0PxnAW(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧỂ")] = PHrtMU1sgahiE
		aJRkoEKrCuei07MYZvxdXlB9.append(dict)
	DObXK6WPct,tg2alOx5pA7WIdJLKE,u9cwApm4Us,K25EH7dNGhgBrsk0MQpP,XSHjIsrxUtCe0AznOBYJqbV6LZuN = [],[],[],[],[]
	jjSs5EfJBnKCLX2DvFtiZ81Rxzmlq,p6p85kbhFjOMqxAfTVzl,BqHpUiElOuvs2QS,shxBSRQ1UH2e,SSz48XEocGe = [],[],[],[],[]
	if FA9sKIS20rvDMn:
		dict = {}
		dict[eNEhtuoi9gK8JaTpIXj(u"ࠧࡵࡻࡳࡩ࠷࠭ể")] = KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡃ࠮࡚ࠬỄ")
		dict[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫễ")] = jUcmHhgVvW0EdYOIfXeaDF(u"ࠪࡱࡵࡪࠧỆ")
		dict[NxXMrsTC5FniYuRBOK8(u"ࠫࡹ࡯ࡴ࡭ࡧࠪệ")] = dict[CKUiyEe28zsZ(u"ࠬࡺࡹࡱࡧ࠵ࠫỈ")]+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭࠺ࠡࠢࠪỉ")+dict[KW5bYS20wTF1LyCs9(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩỊ")]+KwJyZLDzC4FbHhXgTfI+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨฮ๋ำฮࠦะไ์ฬࠫị")
		dict[bP01xn84BiQN(u"ࠩࡸࡶࡱ࠭Ọ")] = FA9sKIS20rvDMn
		dict[NxXMrsTC5FniYuRBOK8(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫọ")] = bP01xn84BiQN(u"ࠫ࠵࠭Ỏ")
		dict[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ỏ")] = ilBWK5nXxg1do4jENGC07Zq(u"࠭࠹࠹࠹࠹࠹࠹࠹࠲࠲࠲ࠪỐ")
		aJRkoEKrCuei07MYZvxdXlB9.append(dict)
	if ClMvFfmwunY:
		cR75npCiqU8TLfgMZO,II38vmlgDXhF = YY02fhEdJNI5cCpw1nUMj(ClMvFfmwunY)
		B42t5jAHsfEbho7W3PDNpIqJV = list(zip(cR75npCiqU8TLfgMZO,II38vmlgDXhF))
		for title,apOKrFbP9IYHDyUVm7 in B42t5jAHsfEbho7W3PDNpIqJV:
			dict = {}
			dict[NxXMrsTC5FniYuRBOK8(u"ࠧࡵࡻࡳࡩ࠷࠭ố")] = J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡃ࠮࡚ࠬỒ")
			dict[TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫồ")] = EX25Y0l8ILvz7QcRC(u"ࠪࡱ࠸ࡻ࠸ࠨỔ")
			dict[w2vjZmdJuY7c(u"ࠫࡺࡸ࡬ࠨổ")] = apOKrFbP9IYHDyUVm7
			if ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡱࡢࡱࡵࠪỖ") in title: dict[NxXMrsTC5FniYuRBOK8(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧỗ")] = title.split(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧ࡬ࡤࡳࡷࠬỘ"))[x1Oa8bBf36EwsLMirtFc].rsplit(KwJyZLDzC4FbHhXgTfI)[-t3coAp06zvHrTl49bUVgx(u"࠳ई")]
			else: dict[LyOR7f69iA(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩộ")] = KQ3sCe9Pzh(u"ࠩ࠴࠴ࠬỚ")
			if title.count(KwJyZLDzC4FbHhXgTfI)>HkiMU0QrdzW3l6gwnT(u"࠴उ"):
				s0s2bIZtWx8w3 = title.rsplit(KwJyZLDzC4FbHhXgTfI)[-GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠷ऊ")]
				if s0s2bIZtWx8w3.isdigit(): dict[CKUiyEe28zsZ(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫớ")] = s0s2bIZtWx8w3
				else: dict[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬỜ")] = t3coAp06zvHrTl49bUVgx(u"ࠬ࠶࠰࠱࠲ࠪờ")
			if title==XugxFprC26zGM(u"࠭࠭࠲ࠩỞ"): dict[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡵ࡫ࡷࡰࡪ࠭ở")] = dict[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡶࡼࡴࡪ࠸ࠧỠ")]+S8i3sBYoHWdTURpAgN(u"ࠩ࠽ࠤࠥ࠭ỡ")+dict[egY8Jti0smdLM3h1VQRSW(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬỢ")]+KwJyZLDzC4FbHhXgTfI+wY1p9mP03S8drbcH64t5WQkv(u"ࠫั๎ฯสࠢำ็๏ฯࠧợ")
			else: dict[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡺࡩࡵ࡮ࡨࠫỤ")] = dict[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡴࡺࡲࡨ࠶ࠬụ")]+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧ࠻ࠢࠣࠫỦ")+dict[LTN6DPEmrwehtZMy(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪủ")]+KwJyZLDzC4FbHhXgTfI+dict[LyOR7f69iA(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪỨ")]+NxXMrsTC5FniYuRBOK8(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪứ")+dict[I5bUBGpPXn0W6(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬỪ")]
			aJRkoEKrCuei07MYZvxdXlB9.append(dict)
	aJRkoEKrCuei07MYZvxdXlB9 = sorted(aJRkoEKrCuei07MYZvxdXlB9,reverse=YchIv6N09BaWPEj4tieAnluKZrRXT,key=lambda key: float(key[S8i3sBYoHWdTURpAgN(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ừ")]))
	if not aJRkoEKrCuei07MYZvxdXlB9:
		if not nR2B1Wye7luXb5:
			aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(ZAl2gePWifs3IXG,jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡇࡆࡖࠪỬ"),E1Viom5L3684CTOFJ,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠺ࡺࡨࠨử"))
			nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		z7zRKcweSZAk = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫỮ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		bYrLlO9uMs5tm0IGFhK2v = cBawilJXvK1m.findall(J7divaGOCgq2SLfXpDzZYN58wc(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫữ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		i25MesXmlJoQNOgLPbIqDrVvG9 = cBawilJXvK1m.findall(EX25Y0l8ILvz7QcRC(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩỰ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		NtYlMGwxjLczOC41yKSv = cBawilJXvK1m.findall(LTN6DPEmrwehtZMy(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ự"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		try: kYTnbXx86lUR3rCQBuPE9G = LLhpkdOojJyaRWzrI[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩỲ")][jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫỳ")][CKUiyEe28zsZ(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨỴ")][dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠨࡶ࡬ࡸࡱ࡫ࠧỵ")][bP01xn84BiQN(u"ࠩࡵࡹࡳࡹࠧỶ")][x1Oa8bBf36EwsLMirtFc][QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪࡸࡪࡾࡴࡵࠩỷ")]
		except: kYTnbXx86lUR3rCQBuPE9G = eHdDoxhJCEPMZFVa2fg
		try: ffltMmc18vHTK37qkn = LLhpkdOojJyaRWzrI[ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨỸ")][wY1p9mP03S8drbcH64t5WQkv(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪỹ")][dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧỺ")][w2vjZmdJuY7c(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨỻ")][x1Oa8bBf36EwsLMirtFc][TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨࡴࡸࡲࡸ࠭Ỽ")][x1Oa8bBf36EwsLMirtFc][XugxFprC26zGM(u"ࠩࡷࡩࡽࡺࡴࠨỽ")]
		except: ffltMmc18vHTK37qkn = eHdDoxhJCEPMZFVa2fg
		try: MTS5y2F0xHrCk1mpVv3Is9Qbt = LLhpkdOojJyaRWzrI[wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧỾ")][EX25Y0l8ILvz7QcRC(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫỿ")]
		except: MTS5y2F0xHrCk1mpVv3Is9Qbt = eHdDoxhJCEPMZFVa2fg
		if z7zRKcweSZAk or bYrLlO9uMs5tm0IGFhK2v or i25MesXmlJoQNOgLPbIqDrVvG9 or NtYlMGwxjLczOC41yKSv or kYTnbXx86lUR3rCQBuPE9G or ffltMmc18vHTK37qkn or MTS5y2F0xHrCk1mpVv3Is9Qbt:
			if   z7zRKcweSZAk: sh3cDaZzUkKQFEAl74OryuPtGqJ = z7zRKcweSZAk[x1Oa8bBf36EwsLMirtFc]
			elif bYrLlO9uMs5tm0IGFhK2v: sh3cDaZzUkKQFEAl74OryuPtGqJ = bYrLlO9uMs5tm0IGFhK2v[x1Oa8bBf36EwsLMirtFc]
			elif i25MesXmlJoQNOgLPbIqDrVvG9: sh3cDaZzUkKQFEAl74OryuPtGqJ = i25MesXmlJoQNOgLPbIqDrVvG9[x1Oa8bBf36EwsLMirtFc]
			elif NtYlMGwxjLczOC41yKSv: sh3cDaZzUkKQFEAl74OryuPtGqJ = NtYlMGwxjLczOC41yKSv[x1Oa8bBf36EwsLMirtFc]
			elif kYTnbXx86lUR3rCQBuPE9G: sh3cDaZzUkKQFEAl74OryuPtGqJ = kYTnbXx86lUR3rCQBuPE9G
			elif ffltMmc18vHTK37qkn: sh3cDaZzUkKQFEAl74OryuPtGqJ = ffltMmc18vHTK37qkn
			elif MTS5y2F0xHrCk1mpVv3Is9Qbt: sh3cDaZzUkKQFEAl74OryuPtGqJ = MTS5y2F0xHrCk1mpVv3Is9Qbt
			mn47Nfgz2AHM5TSxIchUXbBK = sh3cDaZzUkKQFEAl74OryuPtGqJ.replace(kDUv7ouWrcgMe6OipQJm,eHdDoxhJCEPMZFVa2fg).strip(avcfIls8w7gk69hYUErHxzQTXtm24j)
			tPfAEarulFTo = SbyWQGMDnV+S8i3sBYoHWdTURpAgN(u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮ่ࠦใัࠣ๎่๎ๆࠡ฼ํี๋ࠥไศศ่ࠤ้ฮูืࠢสู่๊สฯั่๎๋ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠪἀ")+Nat0Dx9puRUWCsgz6JyFhY3
			dXINKZJp6Tbu7wmS(eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KW5bYS20wTF1LyCs9(u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่๊ࠡส่๊ฮัๆฮࠪἁ"),tPfAEarulFTo+ietolwsjpIPK7Fr(u"ࠧ࡝ࡰ࡟ࡲࠬἂ")+mn47Nfgz2AHM5TSxIchUXbBK)
			return KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡇࡵࡶࡴࡸࠠࠡࠢࠣ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸ࡚ࠠࡑࡘࡘ࡚ࡈࡅࠡࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠪἃ")+mn47Nfgz2AHM5TSxIchUXbBK,[],[]
		else: return TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥࠩἄ"),[],[]
	tyjfCBloSO,gyPfKCmczs4Y9p7,ySpNPcAvZ7Ukq = [],[],[]
	for dict in aJRkoEKrCuei07MYZvxdXlB9:
		if dict[I5bUBGpPXn0W6(u"ࠪࡸࡾࡶࡥ࠳ࠩἅ")]==TMKXOwyLdzhDj1Q6PmoigsbV4(u"࡛ࠫ࡯ࡤࡦࡱࠪἆ"):
			DObXK6WPct.append(dict[f90fGrlSEObDsuiA3U(u"ࠬࡺࡩࡵ࡮ࡨࠫἇ")])
			jjSs5EfJBnKCLX2DvFtiZ81Rxzmlq.append(dict)
		elif dict[t3coAp06zvHrTl49bUVgx(u"࠭ࡴࡺࡲࡨ࠶ࠬἈ")]==ietolwsjpIPK7Fr(u"ࠧࡂࡷࡧ࡭ࡴ࠭Ἁ"):
			tg2alOx5pA7WIdJLKE.append(dict[ietolwsjpIPK7Fr(u"ࠨࡶ࡬ࡸࡱ࡫ࠧἊ")])
			p6p85kbhFjOMqxAfTVzl.append(dict)
		elif dict[HkiMU0QrdzW3l6gwnT(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫἋ")]==ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡱࡵࡪࠧἌ"):
			title = dict[Cp6c5tZe8I0PxnAW(u"ࠫࡹ࡯ࡴ࡭ࡧࠪἍ")].replace(Cp6c5tZe8I0PxnAW(u"ࠬࡇࠫࡗ࠼ࠣࠤࠬἎ"),eHdDoxhJCEPMZFVa2fg)
			if TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧἏ") not in list(dict.keys()): PHrtMU1sgahiE = eNEhtuoi9gK8JaTpIXj(u"ࠧ࠱ࠩἐ")
			else: PHrtMU1sgahiE = dict[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩἑ")]
			tyjfCBloSO.append([dict,{},title,PHrtMU1sgahiE])
		else:
			title = dict[TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡷ࡭ࡹࡲࡥࠨἒ")].replace(LTN6DPEmrwehtZMy(u"ࠪࡅ࠰࡜࠺ࠡࠢࠪἓ"),eHdDoxhJCEPMZFVa2fg)
			if wY1p9mP03S8drbcH64t5WQkv(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬἔ") not in list(dict.keys()): PHrtMU1sgahiE = ietolwsjpIPK7Fr(u"ࠬ࠶ࠧἕ")
			else: PHrtMU1sgahiE = dict[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ἖")]
			tyjfCBloSO.append([dict,{},title,PHrtMU1sgahiE])
			u9cwApm4Us.append(title)
			BqHpUiElOuvs2QS.append(dict)
		IY7lb49xow5c8JZpgQARGKEWmOTaN = YchIv6N09BaWPEj4tieAnluKZrRXT
		if ietolwsjpIPK7Fr(u"ࠧࡤࡱࡧࡩࡨࡹࠧ἗") in list(dict.keys()):
			if J7divaGOCgq2SLfXpDzZYN58wc(u"ࠨࡣࡹ࠴ࠬἘ") in dict[CKUiyEe28zsZ(u"ࠩࡦࡳࡩ࡫ࡣࡴࠩἙ")]: IY7lb49xow5c8JZpgQARGKEWmOTaN = rDceXBpHkfVUYRJ3tIx95Z
			elif YB5Segc7IQ<J7divaGOCgq2SLfXpDzZYN58wc(u"࠶࠾ऋ"):
				if CKUiyEe28zsZ(u"ࠪࡥࡻࡩࠧἚ") not in dict[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡨࡵࡤࡦࡥࡶࠫἛ")] and wY1p9mP03S8drbcH64t5WQkv(u"ࠬࡳࡰ࠵ࡣࠪἜ") not in dict[Cp6c5tZe8I0PxnAW(u"࠭ࡣࡰࡦࡨࡧࡸ࠭Ἕ")]: IY7lb49xow5c8JZpgQARGKEWmOTaN = rDceXBpHkfVUYRJ3tIx95Z
		if dict[LTN6DPEmrwehtZMy(u"ࠧࡵࡻࡳࡩ࠷࠭἞")]==ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠨࡘ࡬ࡨࡪࡵࠧ἟") and dict[dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࡬ࡲ࡮ࡺࠧἠ")]!=LTN6DPEmrwehtZMy(u"ࠪ࠴࠲࠶ࠧἡ") and IY7lb49xow5c8JZpgQARGKEWmOTaN==YchIv6N09BaWPEj4tieAnluKZrRXT:
			XSHjIsrxUtCe0AznOBYJqbV6LZuN.append(dict[GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡹ࡯ࡴ࡭ࡧࠪἢ")])
			SSz48XEocGe.append(dict)
		elif dict[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡺࡹࡱࡧ࠵ࠫἣ")]==eNEhtuoi9gK8JaTpIXj(u"࠭ࡁࡶࡦ࡬ࡳࠬἤ") and dict[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠧࡪࡰ࡬ࡸࠬἥ")]!=jUcmHhgVvW0EdYOIfXeaDF(u"ࠨ࠲࠰࠴ࠬἦ") and IY7lb49xow5c8JZpgQARGKEWmOTaN==YchIv6N09BaWPEj4tieAnluKZrRXT:
			K25EH7dNGhgBrsk0MQpP.append(dict[HkiMU0QrdzW3l6gwnT(u"ࠩࡷ࡭ࡹࡲࡥࠨἧ")])
			shxBSRQ1UH2e.append(dict)
	for y9fSnPzHJVWs in shxBSRQ1UH2e:
		NK59qyCnd2zxIvUre = y9fSnPzHJVWs[wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫἨ")]
		for GolWBO1dmuvqcHXQN in SSz48XEocGe:
			wo1blzfUg4KAV7p6E05WuG2LjNSJPn = GolWBO1dmuvqcHXQN[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬἩ")]
			PHrtMU1sgahiE = wo1blzfUg4KAV7p6E05WuG2LjNSJPn+NK59qyCnd2zxIvUre
			title = GolWBO1dmuvqcHXQN[HkiMU0QrdzW3l6gwnT(u"ࠬࡺࡩࡵ࡮ࡨࠫἪ")].replace(ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡖࡪࡦࡨࡳ࠿ࠦࠠࠨἫ"),t3coAp06zvHrTl49bUVgx(u"ࠧ࡮ࡲࡧࠤࠥ࠭Ἤ"))
			title = title.replace(GolWBO1dmuvqcHXQN[QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪἭ")]+KwJyZLDzC4FbHhXgTfI,eHdDoxhJCEPMZFVa2fg)
			title = title.replace(str((float(wo1blzfUg4KAV7p6E05WuG2LjNSJPn*XugxFprC26zGM(u"࠷࠰ऌ"))//w2vjZmdJuY7c(u"࠱࠱࠴࠷ऍ")/XugxFprC26zGM(u"࠷࠰ऌ")))+Cp6c5tZe8I0PxnAW(u"ࠩ࡮ࡦࡵࡹࠧἮ"),str((float(PHrtMU1sgahiE*XugxFprC26zGM(u"࠷࠰ऌ"))//w2vjZmdJuY7c(u"࠱࠱࠴࠷ऍ")/XugxFprC26zGM(u"࠷࠰ऌ")))+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪ࡯ࡧࡶࡳࠨἯ"))
			title = title+jUcmHhgVvW0EdYOIfXeaDF(u"ࠫ࠭࠭ἰ")+y9fSnPzHJVWs[EX25Y0l8ILvz7QcRC(u"ࠬࡺࡩࡵ࡮ࡨࠫἱ")].split(I5bUBGpPXn0W6(u"࠭ࠨࠨἲ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠲ऎ"))[NSudqlOzja]
			tyjfCBloSO.append([GolWBO1dmuvqcHXQN,y9fSnPzHJVWs,title,PHrtMU1sgahiE])
	tyjfCBloSO = sorted(tyjfCBloSO, reverse=YchIv6N09BaWPEj4tieAnluKZrRXT, key=lambda key: float(key[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1]))
	for GolWBO1dmuvqcHXQN,y9fSnPzHJVWs,title,PHrtMU1sgahiE in tyjfCBloSO:
		wN6RjPeb7n8AgiSBqKVyL = GolWBO1dmuvqcHXQN[bP01xn84BiQN(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩἳ")]
		if LTN6DPEmrwehtZMy(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪἴ") in list(y9fSnPzHJVWs.keys()):
			wN6RjPeb7n8AgiSBqKVyL = CKUiyEe28zsZ(u"ࠩࡰࡴࡩ࠭ἵ")
		if wN6RjPeb7n8AgiSBqKVyL not in ySpNPcAvZ7Ukq:
			ySpNPcAvZ7Ukq.append(wN6RjPeb7n8AgiSBqKVyL)
			gyPfKCmczs4Y9p7.append([GolWBO1dmuvqcHXQN,y9fSnPzHJVWs,title,PHrtMU1sgahiE])
	GV147dTqx8rotz5Y0sJBSnLE,hiMlWebnpQsr3NzuxctT,Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg = [],[],NxXMrsTC5FniYuRBOK8(u"࠲ए")
	ciPek8sCfZzMng,mOv8yaY5pV9EcGIkx3T7t2eQqzjh = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
	try: ciPek8sCfZzMng = LLhpkdOojJyaRWzrI[egY8Jti0smdLM3h1VQRSW(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩἶ")][eNEhtuoi9gK8JaTpIXj(u"ࠫࡦࡻࡴࡩࡱࡵࠫἷ")]
	except: ciPek8sCfZzMng = eHdDoxhJCEPMZFVa2fg
	try: jIhCgufLmxdBlsO4FNVr = LLhpkdOojJyaRWzrI[ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫἸ")][NxXMrsTC5FniYuRBOK8(u"࠭ࡣࡩࡣࡱࡲࡪࡲࡉࡥࠩἹ")]
	except: jIhCgufLmxdBlsO4FNVr = eHdDoxhJCEPMZFVa2fg
	if ciPek8sCfZzMng and jIhCgufLmxdBlsO4FNVr:
		Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg += iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠴ऐ")
		title = SbyWQGMDnV+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧࡐ࡙ࡑࡉࡗࡀࠠࠡࠩἺ")+ciPek8sCfZzMng+Nat0Dx9puRUWCsgz6JyFhY3
		apOKrFbP9IYHDyUVm7 = VtgEUvxaDeTMuPlwi3HAQchFpIOJ9[EX25Y0l8ILvz7QcRC(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩἻ")][x1Oa8bBf36EwsLMirtFc]+Cp6c5tZe8I0PxnAW(u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬἼ")+jIhCgufLmxdBlsO4FNVr
		GV147dTqx8rotz5Y0sJBSnLE.append(title)
		hiMlWebnpQsr3NzuxctT.append(apOKrFbP9IYHDyUVm7)
		try: mOv8yaY5pV9EcGIkx3T7t2eQqzjh = LLhpkdOojJyaRWzrI[ietolwsjpIPK7Fr(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩἽ")][NxXMrsTC5FniYuRBOK8(u"ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࠧἾ")][w2vjZmdJuY7c(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࡴࠩἿ")][-ilBWK5nXxg1do4jENGC07Zq(u"࠵ऑ")][dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭ࡵࡳ࡮ࠪὀ")]
		except: pass
	for GolWBO1dmuvqcHXQN,y9fSnPzHJVWs,title,PHrtMU1sgahiE in gyPfKCmczs4Y9p7:
		GV147dTqx8rotz5Y0sJBSnLE.append(title) ; hiMlWebnpQsr3NzuxctT.append(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨὁ"))
	if u9cwApm4Us: GV147dTqx8rotz5Y0sJBSnLE.append(w2vjZmdJuY7c(u"ࠨื๋ีฮ่ࠦึ๊อࠤ๊ำฯะหࠪὂ")) ; hiMlWebnpQsr3NzuxctT.append(S8i3sBYoHWdTURpAgN(u"ࠩࡰࡹࡽ࡫ࡤࠨὃ"))
	if tyjfCBloSO: GV147dTqx8rotz5Y0sJBSnLE.append(RqLvTrID0yMVeClpYcnZ16i3X(u"ูࠪํืษุ๊ࠡ์ฯࠦวๅ็อ์ๆืࠧὄ")) ; hiMlWebnpQsr3NzuxctT.append(Cp6c5tZe8I0PxnAW(u"ࠫࡦࡲ࡬ࠨὅ"))
	if XSHjIsrxUtCe0AznOBYJqbV6LZuN: GV147dTqx8rotz5Y0sJBSnLE.append(ilBWK5nXxg1do4jENGC07Zq(u"ࠬࡳࡰࡥࠢสาฯืࠠศๆุ์ึฯ้ࠠษ็ูํะࠧ὆")) ; hiMlWebnpQsr3NzuxctT.append(jUcmHhgVvW0EdYOIfXeaDF(u"࠭࡭ࡱࡦࠪ὇"))
	if DObXK6WPct: GV147dTqx8rotz5Y0sJBSnLE.append(wY1p9mP03S8drbcH64t5WQkv(u"ࠧึ๊ิอࠥฮฯู้่ࠣํะࠧὈ")) ; hiMlWebnpQsr3NzuxctT.append(LTN6DPEmrwehtZMy(u"ࠨࡸ࡬ࡨࡪࡵࠧὉ"))
	if tg2alOx5pA7WIdJLKE: GV147dTqx8rotz5Y0sJBSnLE.append(LTN6DPEmrwehtZMy(u"ุࠩ์ฯࠦศะ๊้ࠤฺ๎ัสࠩὊ")) ; hiMlWebnpQsr3NzuxctT.append(bP01xn84BiQN(u"ࠪࡥࡺࡪࡩࡰࠩὋ"))
	FJ0oqWOPrdjhf = rDceXBpHkfVUYRJ3tIx95Z
	while YchIv6N09BaWPEj4tieAnluKZrRXT:
		iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(R8RfLGIiSYUtQ, GV147dTqx8rotz5Y0sJBSnLE)
		if iLcCSnPyKYWs3xkQ0p14==-ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠶ऒ"): return TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩὌ"),[],[]
		elif iLcCSnPyKYWs3xkQ0p14==GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠶ओ") and ciPek8sCfZzMng:
			apOKrFbP9IYHDyUVm7 = hiMlWebnpQsr3NzuxctT[iLcCSnPyKYWs3xkQ0p14]
			beodhfn062VN8vwZzU5I9uLlySiQxF = jjO4Xf7GBW8Dx2HR0tdP.argv[x1Oa8bBf36EwsLMirtFc]+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡅࡴࡺࡲࡨࡁ࡫ࡵ࡬ࡥࡧࡵࠪࡲࡵࡤࡦ࠿࠴࠸࠶ࠬ࡮ࡢ࡯ࡨࡁࠬὍ")+vFDQstemyYANa(ciPek8sCfZzMng)+NxXMrsTC5FniYuRBOK8(u"࠭ࠦࡶࡴ࡯ࡁࠬ὎")+apOKrFbP9IYHDyUVm7
			if mOv8yaY5pV9EcGIkx3T7t2eQqzjh: beodhfn062VN8vwZzU5I9uLlySiQxF = beodhfn062VN8vwZzU5I9uLlySiQxF+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧࠧ࡫ࡰࡥ࡬࡫࠽ࠨ὏")+vFDQstemyYANa(mOv8yaY5pV9EcGIkx3T7t2eQqzjh)
			ccwRLKk3hs0E.executebuiltin(LTN6DPEmrwehtZMy(u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧὐ")+beodhfn062VN8vwZzU5I9uLlySiQxF+XugxFprC26zGM(u"ࠤࠬࠦὑ"))
			return ietolwsjpIPK7Fr(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨὒ"),[],[]
		iL3sKTVC7EZgM9kDajU1FYGBqWrdc = hiMlWebnpQsr3NzuxctT[iLcCSnPyKYWs3xkQ0p14]
		TDnQaWP4GySw1bk = GV147dTqx8rotz5Y0sJBSnLE[iLcCSnPyKYWs3xkQ0p14]
		if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡩࡧࡳࡩࠩὓ"):
			Vpnwvx26jWqH3ysMAiQ = FA9sKIS20rvDMn
			break
		elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc in [LTN6DPEmrwehtZMy(u"ࠬࡧࡵࡥ࡫ࡲࠫὔ"),f90fGrlSEObDsuiA3U(u"࠭ࡶࡪࡦࡨࡳࠬὕ"),CKUiyEe28zsZ(u"ࠧ࡮ࡷࡻࡩࡩ࠭ὖ")]:
			if iL3sKTVC7EZgM9kDajU1FYGBqWrdc==KW5bYS20wTF1LyCs9(u"ࠨ࡯ࡸࡼࡪࡪࠧὗ"): FBITEXGDfe2mcCxnQs6ktMdy9HJh,weKJ3osXrC58DxAkRjHBPSLnZ7u9 = u9cwApm4Us,BqHpUiElOuvs2QS
			elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==w2vjZmdJuY7c(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ὘"): FBITEXGDfe2mcCxnQs6ktMdy9HJh,weKJ3osXrC58DxAkRjHBPSLnZ7u9 = DObXK6WPct,jjSs5EfJBnKCLX2DvFtiZ81Rxzmlq
			elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪࡥࡺࡪࡩࡰࠩὙ"): FBITEXGDfe2mcCxnQs6ktMdy9HJh,weKJ3osXrC58DxAkRjHBPSLnZ7u9 = tg2alOx5pA7WIdJLKE,p6p85kbhFjOMqxAfTVzl
			iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(S8i3sBYoHWdTURpAgN(u"ࠫฬิสาࠢส่๊๊แࠡࠪࠪ὚")+str(len(FBITEXGDfe2mcCxnQs6ktMdy9HJh))+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠬࠦๅๅใࠬࠫὛ"), FBITEXGDfe2mcCxnQs6ktMdy9HJh)
			if iLcCSnPyKYWs3xkQ0p14!=-f90fGrlSEObDsuiA3U(u"࠱औ"):
				Vpnwvx26jWqH3ysMAiQ = weKJ3osXrC58DxAkRjHBPSLnZ7u9[iLcCSnPyKYWs3xkQ0p14][ietolwsjpIPK7Fr(u"࠭ࡵࡳ࡮ࠪ὜")]
				TDnQaWP4GySw1bk = FBITEXGDfe2mcCxnQs6ktMdy9HJh[iLcCSnPyKYWs3xkQ0p14]
				break
		elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==NxXMrsTC5FniYuRBOK8(u"ࠧ࡮ࡲࡧࠫὝ"):
			iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(t3coAp06zvHrTl49bUVgx(u"ࠨษัฮึࠦฬ้ัฬࠤฬ๊ี้ำฬࠤ࠭࠭὞")+str(len(XSHjIsrxUtCe0AznOBYJqbV6LZuN))+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"้้ࠩࠣ็ࠩࠨὟ"), XSHjIsrxUtCe0AznOBYJqbV6LZuN)
			if iLcCSnPyKYWs3xkQ0p14!=-ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠲क"):
				TDnQaWP4GySw1bk = XSHjIsrxUtCe0AznOBYJqbV6LZuN[iLcCSnPyKYWs3xkQ0p14]
				j47xkeHdchVpN1m5a6LKRlGow = SSz48XEocGe[iLcCSnPyKYWs3xkQ0p14]
				iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪหำะัࠡฮ๋ำฮࠦวๅื๋ฮࠥ࠮ࠧὠ")+str(len(K25EH7dNGhgBrsk0MQpP))+dEwyQDiz0nhjV6MovaH7tIWYel92(u"๋ࠫࠥไโࠫࠪὡ"), K25EH7dNGhgBrsk0MQpP)
				if iLcCSnPyKYWs3xkQ0p14!=-Cp6c5tZe8I0PxnAW(u"࠳ख"):
					TDnQaWP4GySw1bk += XugxFprC26zGM(u"ࠬࠦࠫࠡࠩὢ")+K25EH7dNGhgBrsk0MQpP[iLcCSnPyKYWs3xkQ0p14]
					MMo5IOy9KB = shxBSRQ1UH2e[iLcCSnPyKYWs3xkQ0p14]
					FJ0oqWOPrdjhf = YchIv6N09BaWPEj4tieAnluKZrRXT
					break
		elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡡ࡭࡮ࠪὣ"):
			uRFlymXJ67P,mrTHNQJBoMicY4WyPZfKxt2jqkLAu,BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4,cRQbCO5plfyTwxuUNKk3z = list(zip(*tyjfCBloSO))
			iLcCSnPyKYWs3xkQ0p14 = ZZhzstQTSCXRg(NxXMrsTC5FniYuRBOK8(u"ࠧศะอีࠥอไๆๆไࠤ࠭࠭ὤ")+str(len(BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4))+EX25Y0l8ILvz7QcRC(u"ࠨ่่ࠢๆ࠯ࠧὥ"), BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4)
			if iLcCSnPyKYWs3xkQ0p14!=-egY8Jti0smdLM3h1VQRSW(u"࠴ग"):
				TDnQaWP4GySw1bk = BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4[iLcCSnPyKYWs3xkQ0p14]
				j47xkeHdchVpN1m5a6LKRlGow = uRFlymXJ67P[iLcCSnPyKYWs3xkQ0p14]
				if RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡰࡴࡩ࠭ὦ") in BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4[iLcCSnPyKYWs3xkQ0p14] and j47xkeHdchVpN1m5a6LKRlGow[egY8Jti0smdLM3h1VQRSW(u"ࠪࡹࡷࡲࠧὧ")]!=FA9sKIS20rvDMn:
					MMo5IOy9KB = mrTHNQJBoMicY4WyPZfKxt2jqkLAu[iLcCSnPyKYWs3xkQ0p14]
					FJ0oqWOPrdjhf = YchIv6N09BaWPEj4tieAnluKZrRXT
				else: Vpnwvx26jWqH3ysMAiQ = j47xkeHdchVpN1m5a6LKRlGow[ietolwsjpIPK7Fr(u"ࠫࡺࡸ࡬ࠨὨ")]
				break
		elif iL3sKTVC7EZgM9kDajU1FYGBqWrdc==I5bUBGpPXn0W6(u"ࠬ࡮ࡩࡨࡪࡨࡷࡹ࠭Ὡ"):
			uRFlymXJ67P,mrTHNQJBoMicY4WyPZfKxt2jqkLAu,BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4,cRQbCO5plfyTwxuUNKk3z = list(zip(*gyPfKCmczs4Y9p7))
			j47xkeHdchVpN1m5a6LKRlGow = uRFlymXJ67P[iLcCSnPyKYWs3xkQ0p14-Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg]
			if HkiMU0QrdzW3l6gwnT(u"࠭࡭ࡱࡦࠪὪ") in BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4[iLcCSnPyKYWs3xkQ0p14-Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg] and j47xkeHdchVpN1m5a6LKRlGow[t3coAp06zvHrTl49bUVgx(u"ࠧࡶࡴ࡯ࠫὫ")]!=FA9sKIS20rvDMn:
				MMo5IOy9KB = mrTHNQJBoMicY4WyPZfKxt2jqkLAu[iLcCSnPyKYWs3xkQ0p14-Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg]
				FJ0oqWOPrdjhf = YchIv6N09BaWPEj4tieAnluKZrRXT
			else: Vpnwvx26jWqH3ysMAiQ = j47xkeHdchVpN1m5a6LKRlGow[w2vjZmdJuY7c(u"ࠨࡷࡵࡰࠬὬ")]
			TDnQaWP4GySw1bk = BS6KTsz8W3hI0fcmjoA7VnGUrwZ5u4[iLcCSnPyKYWs3xkQ0p14-Ed8RGxqiJwIrf1eAQVtnBWCovD3Uyg]
			break
	if not FJ0oqWOPrdjhf: QnZAclb0IKEfRt5CrdqkY = Vpnwvx26jWqH3ysMAiQ
	else: QnZAclb0IKEfRt5CrdqkY = LTN6DPEmrwehtZMy(u"࡙ࠩ࡭ࡩ࡫࡯࠻ࠢࠪὭ")+j47xkeHdchVpN1m5a6LKRlGow[KQ3sCe9Pzh(u"ࠪࡹࡷࡲࠧὮ")]+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࠥ࠱ࠠࡂࡷࡧ࡭ࡴࡀࠠࠨὯ")+MMo5IOy9KB[ietolwsjpIPK7Fr(u"ࠬࡻࡲ࡭ࠩὰ")]
	if FJ0oqWOPrdjhf:
		Lwpm2zuklXIDQxVebNJj = int(j47xkeHdchVpN1m5a6LKRlGow[CKUiyEe28zsZ(u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨά")])
		Q3ocezy6SNW2XP1vEIf = int(MMo5IOy9KB[NxXMrsTC5FniYuRBOK8(u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩὲ")])
		WWPgm9fvlH2oIOnrD1 = str(max(Lwpm2zuklXIDQxVebNJj,Q3ocezy6SNW2XP1vEIf))
		jw3qbopeTcS0XsgfvdQLr16uRWzOKF = j47xkeHdchVpN1m5a6LKRlGow[jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡷࡵࡰࠬέ")].replace(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࠩࠫὴ"),wY1p9mP03S8drbcH64t5WQkv(u"ࠪࠪࡦࡳࡰ࠼ࠩή"))
		bimrwonxp4LusNZJ0 = MMo5IOy9KB[CKUiyEe28zsZ(u"ࠫࡺࡸ࡬ࠨὶ")].replace(TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠬࠬࠧί"),ietolwsjpIPK7Fr(u"࠭ࠦࡢ࡯ࡳ࠿ࠬὸ"))
		mpd = jUcmHhgVvW0EdYOIfXeaDF(u"ࠧ࠽ࡁࡻࡱࡱࠦࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣ࠳࠱࠴ࠧࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠾ࠤࡘࡘࡋ࠳࠸ࠣࡁࡁࡠࡳ࠭ό")
		mpd += f90fGrlSEObDsuiA3U(u"ࠨ࠾ࡐࡔࡉࠦࡸ࡮࡮ࡱࡷ࠿ࡾࡳࡪ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡸ࠵࠱ࡳࡷ࡭࠯࠳࠲࠳࠵࠴࡞ࡍࡍࡕࡦ࡬ࡪࡳࡡ࠮࡫ࡱࡷࡹࡧ࡮ࡤࡧࠥࠤࡽࡳ࡬࡯ࡵࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡸࡩࡨࡦ࡯ࡤ࠾ࡲࡶࡤ࠻࠴࠳࠵࠶ࠨࠠࡹ࡯࡯ࡲࡸࡀࡸ࡭࡫ࡱ࡯ࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡻ࠸࠴࡯ࡳࡩ࠲࠵࠾࠿࠹࠰ࡺ࡯࡭ࡳࡱࠢࠡࡺࡶ࡭࠿ࡹࡣࡩࡧࡰࡥࡑࡵࡣࡢࡶ࡬ࡳࡳࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡴࡥ࡫ࡩࡲࡧ࠺࡮ࡲࡧ࠾࠷࠶࠱࠲ࠢ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡸࡦࡴࡤࡢࡴࡧࡷ࠳࡯ࡳࡰ࠰ࡲࡶ࡬࠵ࡩࡵࡶࡩ࠳ࡕࡻࡢ࡭࡫ࡦࡰࡾࡇࡶࡢ࡫࡯ࡥࡧࡲࡥࡔࡶࡤࡲࡩࡧࡲࡥࡵ࠲ࡑࡕࡋࡇ࠮ࡆࡄࡗࡍࡥࡳࡤࡪࡨࡱࡦࡥࡦࡪ࡮ࡨࡷ࠴ࡊࡁࡔࡊ࠰ࡑࡕࡊ࠮ࡹࡵࡧࠦࠥࡳࡩ࡯ࡄࡸࡪ࡫࡫ࡲࡕ࡫ࡰࡩࡂࠨࡐࡕ࠳࠱࠹ࡘࠨࠠ࡮ࡧࡧ࡭ࡦࡖࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡈࡺࡸࡡࡵ࡫ࡲࡲࡂࠨࡐࡕࠩὺ")+WWPgm9fvlH2oIOnrD1+KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠩࡖࠦࠥࡺࡹࡱࡧࡀࠦࡸࡺࡡࡵ࡫ࡦࠦࠥࡶࡲࡰࡨ࡬ࡰࡪࡹ࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡨࡦࡹࡨ࠻ࡲࡵࡳ࡫࡯࡬ࡦ࠼࡬ࡷࡴ࡬ࡦ࠮࡯ࡤ࡭ࡳࡀ࠲࠱࠳࠴ࠦࡃࡢ࡮ࠨύ")
		mpd += NxXMrsTC5FniYuRBOK8(u"ࠪࡀࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧὼ")
		mpd += QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠳ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡸ࡬ࡨࡪࡵ࠯ࠨώ")+j47xkeHdchVpN1m5a6LKRlGow[I5bUBGpPXn0W6(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ὾")]+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡖࡵࡹࡪࠨ࠾࡝ࡰࠪ὿")
		mpd += Cp6c5tZe8I0PxnAW(u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬᾀ")
		mpd += LyOR7f69iA(u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨᾁ")+j47xkeHdchVpN1m5a6LKRlGow[ietolwsjpIPK7Fr(u"ࠩ࡬ࡸࡦ࡭ࠧᾂ")]+eNEhtuoi9gK8JaTpIXj(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧᾃ")+j47xkeHdchVpN1m5a6LKRlGow[ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫࡨࡵࡤࡦࡥࡶࠫᾄ")]+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠬࠨࠠࡴࡶࡤࡶࡹ࡝ࡩࡵࡪࡖࡅࡕࡃࠢ࠲ࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢࠨᾅ")+str(j47xkeHdchVpN1m5a6LKRlGow[KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧᾆ")])+eNEhtuoi9gK8JaTpIXj(u"ࠧࠣࠢࡺ࡭ࡩࡺࡨ࠾ࠤࠪᾇ")+str(j47xkeHdchVpN1m5a6LKRlGow[ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡹ࡬ࡨࡹ࡮ࠧᾈ")])+KQ3sCe9Pzh(u"ࠩࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧ࠭ᾉ")+str(j47xkeHdchVpN1m5a6LKRlGow[J7divaGOCgq2SLfXpDzZYN58wc(u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪᾊ")])+LyOR7f69iA(u"ࠫࠧࠦࡦࡳࡣࡰࡩࡗࡧࡴࡦ࠿ࠥࠫᾋ")+j47xkeHdchVpN1m5a6LKRlGow[I5bUBGpPXn0W6(u"ࠬ࡬ࡰࡴࠩᾌ")]+Cp6c5tZe8I0PxnAW(u"࠭ࠢ࠿࡞ࡱࠫᾍ")
		mpd += XugxFprC26zGM(u"ࠧ࠽ࡄࡤࡷࡪ࡛ࡒࡍࡀࠪᾎ")+jw3qbopeTcS0XsgfvdQLr16uRWzOKF+QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨ࠾࠲ࡆࡦࡹࡥࡖࡔࡏࡂࡡࡴࠧᾏ")
		mpd += EX25Y0l8ILvz7QcRC(u"ࠩ࠿ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡂࠨࠧᾐ")+j47xkeHdchVpN1m5a6LKRlGow[ehfEsaiJBSvbcULtNPVgykA2(u"ࠪ࡭ࡳࡪࡥࡹࠩᾑ")]+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫࠧࡄ࡜࡯ࠩᾒ")
		mpd += CKUiyEe28zsZ(u"ࠬࡂࡉ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡣࡷ࡭ࡴࡴࠠࡳࡣࡱ࡫ࡪࡃࠢࠨᾓ")+j47xkeHdchVpN1m5a6LKRlGow[EX25Y0l8ILvz7QcRC(u"࠭ࡩ࡯࡫ࡷࠫᾔ")]+CKUiyEe28zsZ(u"ࠧࠣࠢ࠲ࡂࡡࡴࠧᾕ")
		mpd += KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨ࠾࠲ࡗࡪ࡭࡭ࡦࡰࡷࡆࡦࡹࡥ࠿࡞ࡱࠫᾖ")
		mpd += RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩ࠿࠳ࡗ࡫ࡰࡳࡧࡶࡩࡳࡺࡡࡵ࡫ࡲࡲࡃࡢ࡮ࠨᾗ")
		mpd += HkiMU0QrdzW3l6gwnT(u"ࠪࡀ࠴ࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࡃࡢ࡮ࠨᾘ")
		mpd += ehfEsaiJBSvbcULtNPVgykA2(u"ࠫࡁࡇࡤࡢࡲࡷࡥࡹ࡯࡯࡯ࡕࡨࡸࠥ࡯ࡤ࠾ࠤ࠴ࠦࠥࡳࡩ࡮ࡧࡗࡽࡵ࡫࠽ࠣࡣࡸࡨ࡮ࡵ࠯ࠨᾙ")+MMo5IOy9KB[HkiMU0QrdzW3l6gwnT(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧᾚ")]+S8i3sBYoHWdTURpAgN(u"࠭ࠢࠡࡵࡸࡦࡸ࡫ࡧ࡮ࡧࡱࡸࡆࡲࡩࡨࡰࡰࡩࡳࡺ࠽ࠣࡖࡵࡹࡪࠨ࠾࡝ࡰࠪᾛ")
		mpd += egY8Jti0smdLM3h1VQRSW(u"ࠧ࠽ࡔࡲࡰࡪࠦࡳࡤࡪࡨࡱࡪࡏࡤࡖࡴ࡬ࡁࠧࡻࡲ࡯࠼ࡰࡴࡪ࡭࠺ࡅࡃࡖࡌ࠿ࡸ࡯࡭ࡧ࠽࠶࠵࠷࠱ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡰࡥ࡮ࡴࠢ࠰ࡀ࡟ࡲࠬᾜ")
		mpd += RqLvTrID0yMVeClpYcnZ16i3X(u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨᾝ")+MMo5IOy9KB[CKUiyEe28zsZ(u"ࠩ࡬ࡸࡦ࡭ࠧᾞ")]+KW5bYS20wTF1LyCs9(u"ࠪࠦࠥࡩ࡯ࡥࡧࡦࡷࡂࠨࠧᾟ")+MMo5IOy9KB[CKUiyEe28zsZ(u"ࠫࡨࡵࡤࡦࡥࡶࠫᾠ")]+eNEhtuoi9gK8JaTpIXj(u"ࠬࠨࠠࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࡀࠦ࠶࠹࠰࠵࠹࠸ࠦࡃࡢ࡮ࠨᾡ")
		mpd += S8i3sBYoHWdTURpAgN(u"࠭࠼ࡂࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡉ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࠥࡹࡣࡩࡧࡰࡩࡎࡪࡕࡳ࡫ࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾࠷࠹࠰࠱࠵࠽࠷࠿ࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡩ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲ࠿࠸࠰࠲࠳ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠬᾢ")+MMo5IOy9KB[wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨᾣ")]+ehfEsaiJBSvbcULtNPVgykA2(u"ࠨࠤ࠲ࡂࡡࡴࠧᾤ")
		mpd += HkiMU0QrdzW3l6gwnT(u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬᾥ")+bimrwonxp4LusNZJ0+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩᾦ")
		mpd += TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩᾧ")+MMo5IOy9KB[bP01xn84BiQN(u"ࠬ࡯࡮ࡥࡧࡻࠫᾨ")]+HkiMU0QrdzW3l6gwnT(u"࠭ࠢ࠿࡞ࡱࠫᾩ")
		mpd += QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪᾪ")+MMo5IOy9KB[EX25Y0l8ILvz7QcRC(u"ࠨ࡫ࡱ࡭ࡹ࠭ᾫ")]+wY1p9mP03S8drbcH64t5WQkv(u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩᾬ")
		mpd += LyOR7f69iA(u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭ᾭ")
		mpd += f90fGrlSEObDsuiA3U(u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪᾮ")
		mpd += GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪᾯ")
		mpd += iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫᾰ")
		mpd += dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩᾱ")
		if WHjh1POtMKlmgiy68RSqb:
			import http.server as NNX5pi7gFYu
			import http.client as n3mkHYfNacU7tu6T4ZShGPyK
		else:
			import BaseHTTPServer as NNX5pi7gFYu
			import httplib as n3mkHYfNacU7tu6T4ZShGPyK
		class PSgN9zpo6WfynCcF1(NNX5pi7gFYu.HTTPServer):
			def __init__(gmChyf98s5,ip=ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫᾲ"),port=Cp6c5tZe8I0PxnAW(u"࠹࠺࠶࠵࠶घ"),mpd=iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠩ࠿ࡂࠬᾳ")):
				gmChyf98s5.ip = ip
				gmChyf98s5.port = port
				gmChyf98s5.mpd = mpd
				NNX5pi7gFYu.HTTPServer.__init__(gmChyf98s5,(gmChyf98s5.ip,gmChyf98s5.port),dMET8XklpFDH3670PUtG9qxova)
				gmChyf98s5.mpdurl = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫᾴ")+ip+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫ࠿࠭᾵")+str(port)+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫᾶ")
			def start(gmChyf98s5):
				gmChyf98s5.threads = NLZqC35dHIcYei6Tpr4wms(rDceXBpHkfVUYRJ3tIx95Z)
				gmChyf98s5.threads.zuhp2kCsanALdD(jUcmHhgVvW0EdYOIfXeaDF(u"࠶ङ"),gmChyf98s5.iAyx6osfVR0F)
			def iAyx6osfVR0F(gmChyf98s5):
				gmChyf98s5.keeprunning = YchIv6N09BaWPEj4tieAnluKZrRXT
				while gmChyf98s5.keeprunning:
					gmChyf98s5.handle_request()
			def stop(gmChyf98s5):
				gmChyf98s5.keeprunning = rDceXBpHkfVUYRJ3tIx95Z
				gmChyf98s5.aW5npg2chmizVTQvjyCXk()
			def QQdkGC8prAH7eZh2w3SJoODyIRn(gmChyf98s5):
				gmChyf98s5.stop()
				gmChyf98s5.d8ERXc2O9NADu.close()
				gmChyf98s5.server_close()
			def mmsDbMiK1LoVW65(gmChyf98s5,mpd):
				gmChyf98s5.mpd = mpd
			def aW5npg2chmizVTQvjyCXk(gmChyf98s5):
				Mh2SmYKyRLsevXCJpTajHZbi0Gf = n3mkHYfNacU7tu6T4ZShGPyK.HTTPConnection(gmChyf98s5.ip+XugxFprC26zGM(u"࠭࠺ࠨᾷ")+str(gmChyf98s5.port))
				Mh2SmYKyRLsevXCJpTajHZbi0Gf.request(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠢࡉࡇࡄࡈࠧᾸ"), egY8Jti0smdLM3h1VQRSW(u"ࠣ࠱ࠥᾹ"))
		class dMET8XklpFDH3670PUtG9qxova(NNX5pi7gFYu.BaseHTTPRequestHandler):
			def nEyCaUuBH9KL(gmChyf98s5):
				gmChyf98s5.send_response(jUcmHhgVvW0EdYOIfXeaDF(u"࠸࠰࠱च"))
				gmChyf98s5.send_header(bP01xn84BiQN(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨᾺ"),CKUiyEe28zsZ(u"ࠪࡸࡪࡾࡴࡵ࠱ࡳࡰࡦ࡯࡮ࠨΆ"))
				gmChyf98s5.end_headers()
				gmChyf98s5.wfile.write(gmChyf98s5.GfhcsvCWIon.mpd.encode(m6PFtLblInpNZ8x))
				b8bLFaejUB.sleep(t3coAp06zvHrTl49bUVgx(u"࠱छ"))
				if gmChyf98s5.path==eNEhtuoi9gK8JaTpIXj(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪᾼ"): gmChyf98s5.GfhcsvCWIon.QQdkGC8prAH7eZh2w3SJoODyIRn()
				if gmChyf98s5.path==HkiMU0QrdzW3l6gwnT(u"ࠬ࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ᾽"): gmChyf98s5.GfhcsvCWIon.QQdkGC8prAH7eZh2w3SJoODyIRn()
			def LCzbcdwO7KP8xg3l9Ehs0Z(gmChyf98s5):
				gmChyf98s5.send_response(egY8Jti0smdLM3h1VQRSW(u"࠳࠲࠳ज"))
				gmChyf98s5.end_headers()
		mULbdy5G0DZOTpaMvRrwWEAN2 = PSgN9zpo6WfynCcF1(J7divaGOCgq2SLfXpDzZYN58wc(u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩι"),iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠷࠸࠴࠺࠻झ"),mpd)
		Vpnwvx26jWqH3ysMAiQ = mULbdy5G0DZOTpaMvRrwWEAN2.mpdurl
		mULbdy5G0DZOTpaMvRrwWEAN2.start()
	else: mULbdy5G0DZOTpaMvRrwWEAN2 = eHdDoxhJCEPMZFVa2fg
	if not Vpnwvx26jWqH3ysMAiQ: return t3coAp06zvHrTl49bUVgx(u"ࠧࡆࡴࡵࡳࡷࠦࠠࠡࠢ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷ࡙ࠦࡐࡗࡗ࡙ࡇࡋࠠࡇࡣ࡬ࡰࡪࡪࠧ᾿"),[],[]
	return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[[Vpnwvx26jWqH3ysMAiQ,xk9fB2YKJRyt0DcPXNHTSiLQ,mULbdy5G0DZOTpaMvRrwWEAN2]]
def EFKuhwgWURIm(url):
	headers = { t3coAp06zvHrTl49bUVgx(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ῀") : eHdDoxhJCEPMZFVa2fg }
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,bP01xn84BiQN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡜ࡉࡅࡄࡒࡆ࠲࠷ࡳࡵࠩ῁"))
	items = cBawilJXvK1m.findall(wY1p9mP03S8drbcH64t5WQkv(u"ࠪࡪ࡮ࡲࡥ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠯ࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤࡿ࠭ࡡࢃࠧῂ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	items = set(items)
	items = sorted(items, reverse=YchIv6N09BaWPEj4tieAnluKZrRXT, key=lambda key: key[FB0pIzAoK8wqgd3UiY5])
	cR75npCiqU8TLfgMZO,FBITEXGDfe2mcCxnQs6ktMdy9HJh,II38vmlgDXhF,ppQOjlq2gaPkW = [],[],[],[]
	if not items: return CKUiyEe28zsZ(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡊࡆࡅࡓࡇ࠭ῃ"),[],[]
	for apOKrFbP9IYHDyUVm7,ppxnlrkDsXUmKQWFt,jZHGcWxXpdVO038fnt in items:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬῄ"),jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡨࡵࡶࡳ࠾ࠬ῅"))
		if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠧ࠯࡯࠶ࡹ࠽࠭ῆ") in apOKrFbP9IYHDyUVm7:
			cR75npCiqU8TLfgMZO,II38vmlgDXhF = YY02fhEdJNI5cCpw1nUMj(apOKrFbP9IYHDyUVm7)
			ppQOjlq2gaPkW = ppQOjlq2gaPkW + II38vmlgDXhF
			if cR75npCiqU8TLfgMZO[x1Oa8bBf36EwsLMirtFc]==bP01xn84BiQN(u"ࠨ࠯࠴ࠫῇ"): FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(KQ3sCe9Pzh(u"ࠩึ๎ึ็ัࠡะสูࠬῈ")+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠪࠤࠥࠦ࡭࠴ࡷ࠻ࠫΈ"))
			else:
				for title in cR75npCiqU8TLfgMZO:
					FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(ietolwsjpIPK7Fr(u"ุࠫ๐ัโำࠣาฬ฻ࠧῊ")+D8OnEGLjecaXw+title)
		else:
			title = Cp6c5tZe8I0PxnAW(u"ู๊ࠬาใิࠤำอีࠨΉ")+J7divaGOCgq2SLfXpDzZYN58wc(u"࠭ࠠࠡࠢࡰࡴ࠹ࠦࠠࠡࠩῌ")+jZHGcWxXpdVO038fnt
			ppQOjlq2gaPkW.append(apOKrFbP9IYHDyUVm7)
			FBITEXGDfe2mcCxnQs6ktMdy9HJh.append(title)
	return eHdDoxhJCEPMZFVa2fg,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
def qTdWVHsCB8DvNFuRfaj6KLA(url,nR2B1Wye7luXb5):
	YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV,FEgedfU4Wa,YdRivB5jFXMNpakxz4rUKQu7J8V0S,JCZVK86QTYwX4mfgOrod = [],[],[],[],[]
	if KW5bYS20wTF1LyCs9(u"ࠧࡴࡶࡵࠫ῍") not in str(type(nR2B1Wye7luXb5)): nR2B1Wye7luXb5 = nR2B1Wye7luXb5.decode(m6PFtLblInpNZ8x,NxXMrsTC5FniYuRBOK8(u"ࠨ࡫ࡪࡲࡴࡸࡥࠨ῎"))
	apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠩ࠿ࡺ࡮ࡪࡥࡰࠢࡳࡶࡪࡲ࡯ࡢࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ῏"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7 and not llr1C3SIFjViqLDtZP(apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]): apOKrFbP9IYHDyUVm7 = []
	if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩῐ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7 and not llr1C3SIFjViqLDtZP(apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]): apOKrFbP9IYHDyUVm7 = []
	if not apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = cBawilJXvK1m.findall(ietolwsjpIPK7Fr(u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪῑ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if apOKrFbP9IYHDyUVm7 and not llr1C3SIFjViqLDtZP(apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]): apOKrFbP9IYHDyUVm7 = []
	if apOKrFbP9IYHDyUVm7:
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7[x1Oa8bBf36EwsLMirtFc]
		title = apOKrFbP9IYHDyUVm7.rsplit(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬ࠴ࠧῒ"),ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠴ञ"))[NSudqlOzja]
		YYs45omUWpDLndclV.append(title)
		wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	else:
		ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall(LTN6DPEmrwehtZMy(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬΐ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not ekNMoIJzswUSDVQf564: ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠧࡷࡣࡵࠤࡸࡵࡵࡳࡥࡨࡷࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪ῔"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not ekNMoIJzswUSDVQf564: ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠨࡸࡤࡶࠥࡰࡷࠡ࠿ࠣࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮࠭῕"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if not ekNMoIJzswUSDVQf564: ekNMoIJzswUSDVQf564 = cBawilJXvK1m.findall(ilBWK5nXxg1do4jENGC07Zq(u"ࠩࡹࡥࡷࠦࡰ࡭ࡣࡼࡩࡷࠦ࠽ࠡ࠰࠭ࡃࡡ࠮ࠨ࡝ࡽ࠱࠮ࡄࡢࡽࠪ࡞ࠬࠫῖ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if ekNMoIJzswUSDVQf564:
			ekNMoIJzswUSDVQf564 = ekNMoIJzswUSDVQf564[x1Oa8bBf36EwsLMirtFc]
			ekNMoIJzswUSDVQf564 = cBawilJXvK1m.sub(ehfEsaiJBSvbcULtNPVgykA2(u"ࡵࠫ࠭ࡡ࡜ࡼ࡞࠯ࡡࡠࡢࡴ࡝ࡵ࡟ࡲࡡࡸ࡝ࠫࠫࠫࡠࡼ࠱࡛࡝ࡶ࡟ࡷࡢ࠰ࠩ࠻ࠩῗ"),f90fGrlSEObDsuiA3U(u"ࡶࠬࡢ࠱ࠣ࡞࠵ࠦ࠿࠭Ῐ"),ekNMoIJzswUSDVQf564)
			ekNMoIJzswUSDVQf564 = DIpuHqsKGS3ErJvk9taCRiX80(LTN6DPEmrwehtZMy(u"ࠬࡪࡩࡤࡶࠪῙ"),ekNMoIJzswUSDVQf564)
			if isinstance(ekNMoIJzswUSDVQf564,dict): ekNMoIJzswUSDVQf564 = [ekNMoIJzswUSDVQf564]
			for cOUiow273ytu1GC5N0FJh in ekNMoIJzswUSDVQf564:
				aA6KX7VTZEOoLN92rJRzxF105iC4,apOKrFbP9IYHDyUVm7 = eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg
				if isinstance(cOUiow273ytu1GC5N0FJh,dict):
					keys = list(cOUiow273ytu1GC5N0FJh.keys())
					if   ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡴࡺࡲࡨࠫῚ") in keys: aA6KX7VTZEOoLN92rJRzxF105iC4 = str(cOUiow273ytu1GC5N0FJh[KQ3sCe9Pzh(u"ࠧࡵࡻࡳࡩࠬΊ")])
					if   XugxFprC26zGM(u"ࠨࡨ࡬ࡰࡪ࠭῜") in keys: apOKrFbP9IYHDyUVm7 = cOUiow273ytu1GC5N0FJh[wY1p9mP03S8drbcH64t5WQkv(u"ࠩࡩ࡭ࡱ࡫ࠧ῝")]
					elif egY8Jti0smdLM3h1VQRSW(u"ࠪ࡬ࡱࡹࠧ῞") in keys: apOKrFbP9IYHDyUVm7 = cOUiow273ytu1GC5N0FJh[RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫ࡭ࡲࡳࠨ῟")]
					elif LTN6DPEmrwehtZMy(u"ࠬࡹࡲࡤࠩῠ") in keys: apOKrFbP9IYHDyUVm7 = cOUiow273ytu1GC5N0FJh[jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࡳࡳࡥࠪῡ")]
					if   w2vjZmdJuY7c(u"ࠧ࡭ࡣࡥࡩࡱ࠭ῢ") in keys: title = str(cOUiow273ytu1GC5N0FJh[TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠨ࡮ࡤࡦࡪࡲࠧΰ")])
					elif egY8Jti0smdLM3h1VQRSW(u"ࠩࡹ࡭ࡩ࡫࡯ࡠࡪࡨ࡭࡬࡮ࡴࠨῤ") in keys: title = str(cOUiow273ytu1GC5N0FJh[eNEhtuoi9gK8JaTpIXj(u"ࠪࡺ࡮ࡪࡥࡰࡡ࡫ࡩ࡮࡭ࡨࡵࠩῥ")])
					elif KQ3sCe9Pzh(u"ࠫ࠳࠭ῦ") in apOKrFbP9IYHDyUVm7: title = apOKrFbP9IYHDyUVm7.rsplit(egY8Jti0smdLM3h1VQRSW(u"ࠬ࠴ࠧῧ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠵ट"))[NSudqlOzja]
					else: title = apOKrFbP9IYHDyUVm7
				elif isinstance(cOUiow273ytu1GC5N0FJh,str):
					apOKrFbP9IYHDyUVm7 = cOUiow273ytu1GC5N0FJh
					title = apOKrFbP9IYHDyUVm7.rsplit(bP01xn84BiQN(u"࠭࠮ࠨῨ"),TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠶ठ"))[NSudqlOzja]
				if LyOR7f69iA(u"࠷ड"):
					YYs45omUWpDLndclV.append(title+KwJyZLDzC4FbHhXgTfI+aA6KX7VTZEOoLN92rJRzxF105iC4)
					wROf6m4Ix73jtsdnZ1vpCDuV.append(apOKrFbP9IYHDyUVm7)
	for apOKrFbP9IYHDyUVm7,title in zip(wROf6m4Ix73jtsdnZ1vpCDuV,YYs45omUWpDLndclV):
		apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7.replace(GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠧ࡝࡞࠲ࠫῩ"),QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠨ࠱ࠪῪ"))
		GfhcsvCWIon = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,KQ3sCe9Pzh(u"ࠩࡸࡶࡱ࠭Ύ"))
		PPOaXI9Tr1fAD7luhFGYpKJ5q = qq62QA8h3pGxzCwWVeXIF7glKf()
		if KW5bYS20wTF1LyCs9(u"ࠪ࡬ࡹࡺࡰࠨῬ") not in apOKrFbP9IYHDyUVm7: apOKrFbP9IYHDyUVm7 = GfhcsvCWIon+apOKrFbP9IYHDyUVm7
		if eNEhtuoi9gK8JaTpIXj(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ῭") in apOKrFbP9IYHDyUVm7:
			headers = {dEwyQDiz0nhjV6MovaH7tIWYel92(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ΅"):PPOaXI9Tr1fAD7luhFGYpKJ5q,iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ`"):GfhcsvCWIon}
			BSMaXmcV231uwHpgZz9jrKdPhlf5U,svg4Z25CUnRdEJ9P = YY02fhEdJNI5cCpw1nUMj(apOKrFbP9IYHDyUVm7,headers)
			YdRivB5jFXMNpakxz4rUKQu7J8V0S += svg4Z25CUnRdEJ9P
			FEgedfU4Wa += BSMaXmcV231uwHpgZz9jrKdPhlf5U
		else:
			apOKrFbP9IYHDyUVm7 = apOKrFbP9IYHDyUVm7+KW5bYS20wTF1LyCs9(u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭῰")+PPOaXI9Tr1fAD7luhFGYpKJ5q+t3coAp06zvHrTl49bUVgx(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ῱")+GfhcsvCWIon
			YdRivB5jFXMNpakxz4rUKQu7J8V0S.append(apOKrFbP9IYHDyUVm7)
			FEgedfU4Wa.append(title)
	CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV = eHdDoxhJCEPMZFVa2fg,[],[]
	if YdRivB5jFXMNpakxz4rUKQu7J8V0S: CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV = eHdDoxhJCEPMZFVa2fg,FEgedfU4Wa,YdRivB5jFXMNpakxz4rUKQu7J8V0S
	else:
		if GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩ࠿ࠫῲ") not in nR2B1Wye7luXb5 and len(nR2B1Wye7luXb5)<HkiMU0QrdzW3l6gwnT(u"࠱࠱࠲ढ") and nR2B1Wye7luXb5: CZBQor8PhWYnplUtkzvH6 = nR2B1Wye7luXb5
		else:
			msg = cBawilJXvK1m.findall(ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡀࡩ࡯ࡶࠡࡵࡷࡽࡱ࡫࠽ࠣ࠰࠭ࡃࠧࡄࠨࡇ࡫࡯ࡩ࠳࠰࠿ࠪ࠾ࠪῳ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if not msg: msg = cBawilJXvK1m.findall(ietolwsjpIPK7Fr(u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡹࡴࡤࡼࡩࡥࡧࡲࡣࡸࡺࡵࡣࡡࡷࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧῴ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if not msg: msg = cBawilJXvK1m.findall(iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠬࡂࡨ࠳ࡀࠫࡗࡴࡸࡲࡺ࠰࠭ࡃ࠮ࡂࠧ῵"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
			if msg: CZBQor8PhWYnplUtkzvH6 = msg[x1Oa8bBf36EwsLMirtFc]
	return CZBQor8PhWYnplUtkzvH6,YYs45omUWpDLndclV,wROf6m4Ix73jtsdnZ1vpCDuV
def npYeGdUTi6mHXovPz4S(qVRkXOP5i0Le7o,url):
	global cMj58K6gnvq1z4RPXioUt
	url = url.strip(LTN6DPEmrwehtZMy(u"࠭࠯ࠨῶ"))
	kijEAOvZclmKhY7NJwe8S,j6KOlzWGugZqmx0sPS = eHdDoxhJCEPMZFVa2fg,{}
	headers = {NxXMrsTC5FniYuRBOK8(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫῷ"):qq62QA8h3pGxzCwWVeXIF7glKf()}
	headers[w2vjZmdJuY7c(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩῸ")] = b31wAB8mhaz2rXHoJFlfvDugtsOj(url,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩࡸࡶࡱ࠭Ό"))
	headers[ietolwsjpIPK7Fr(u"ࠪࡅࡨࡩࡥࡱࡶ࠰ࡐࡦࡴࡧࡶࡣࡪࡩࠬῺ")] = LyOR7f69iA(u"ࠫࡪࡴ࠭ࡖࡕ࠯ࡩࡳࡁࡱ࠾࠲࠱࠽ࠬΏ")
	headers[HkiMU0QrdzW3l6gwnT(u"࡙ࠬࡥࡤ࠯ࡉࡩࡹࡩࡨ࠮ࡆࡨࡷࡹ࠭ῼ")] = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭ࡩࡧࡴࡤࡱࡪ࠭´")
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,CKUiyEe28zsZ(u"ࠧࡈࡇࡗࠫ῾"),url,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,jUcmHhgVvW0EdYOIfXeaDF(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠱ࡴࡶࠪ῿"))
	nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
	gYetqQsBzcT9oNm7Wi2 = aP8bLqZJsQlH3ivWKc.code
	if not isinstance(nR2B1Wye7luXb5,str): nR2B1Wye7luXb5 = nR2B1Wye7luXb5.decode(m6PFtLblInpNZ8x,HkiMU0QrdzW3l6gwnT(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫࠀ"))
	if QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡱ࠮ࡤ࠰ࡨ࠲࡫࠭ࡧ࠯ࠫࠁ") in nR2B1Wye7luXb5:
		TWPUiXfNzJDF32e90KuRQgMl = cBawilJXvK1m.findall(jUcmHhgVvW0EdYOIfXeaDF(u"࠭ࠨࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡡࡤࡳ࡟࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩࠂ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if TWPUiXfNzJDF32e90KuRQgMl:
			try: kijEAOvZclmKhY7NJwe8S = XPBZo1pUak(TWPUiXfNzJDF32e90KuRQgMl[x1Oa8bBf36EwsLMirtFc])
			except: kijEAOvZclmKhY7NJwe8S = eHdDoxhJCEPMZFVa2fg
	if KQ3sCe9Pzh(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪ࡫࠰ࡺ࠲࡮࠭ࡶ࠯ࡩ࠱ࡸࠩࠨࠃ") in nR2B1Wye7luXb5:
		TWPUiXfNzJDF32e90KuRQgMl = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳ࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨࠄ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
		if TWPUiXfNzJDF32e90KuRQgMl:
			try: kijEAOvZclmKhY7NJwe8S = z7CnJ4SVOIabe9tqjgPGhKfu1i6Uo2(TWPUiXfNzJDF32e90KuRQgMl[x1Oa8bBf36EwsLMirtFc])
			except: kijEAOvZclmKhY7NJwe8S = eHdDoxhJCEPMZFVa2fg
	L3f4VRFXh0Sb1xwKPzoi = nR2B1Wye7luXb5+kijEAOvZclmKhY7NJwe8S
	if EX25Y0l8ILvz7QcRC(u"ࠩࠥ࡭ࡩ࠸ࠢࠨࠅ") in L3f4VRFXh0Sb1xwKPzoi or HkiMU0QrdzW3l6gwnT(u"ࠪࠦ࡮ࡪࠢࠨࠆ") in L3f4VRFXh0Sb1xwKPzoi:
		rrOoQCDxVZJzywdGR8eu67PaL92A = url.split(LTN6DPEmrwehtZMy(u"ࠫ࠴࠭ࠇ"))[bIyhUC0ZcXQeWBARSTMnPLk85Dl7G1].replace(ilBWK5nXxg1do4jENGC07Zq(u"ࠬ࡫࡭ࡣࡧࡧ࠱ࠬࠈ"),eHdDoxhJCEPMZFVa2fg).replace(TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭࠮ࡩࡶࡰࡰࠬࠉ"),eHdDoxhJCEPMZFVa2fg)
		if egY8Jti0smdLM3h1VQRSW(u"ࠧࠣ࡫ࡧ࠶ࠧ࠭ࠊ") in L3f4VRFXh0Sb1xwKPzoi: j6KOlzWGugZqmx0sPS = {GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨ࡫ࡧ࠶ࠬࠋ"):rrOoQCDxVZJzywdGR8eu67PaL92A,I5bUBGpPXn0W6(u"ࠩࡲࡴࠬࠌ"):egY8Jti0smdLM3h1VQRSW(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࠷࠭ࠍ")}
		elif f90fGrlSEObDsuiA3U(u"ࠫࠧ࡯ࡤࠣࠩࠎ") in L3f4VRFXh0Sb1xwKPzoi: j6KOlzWGugZqmx0sPS = {f90fGrlSEObDsuiA3U(u"ࠬ࡯ࡤࠨࠏ"):rrOoQCDxVZJzywdGR8eu67PaL92A,LyOR7f69iA(u"࠭࡯ࡱࠩࠐ"):EX25Y0l8ILvz7QcRC(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪࠑ")}
		W9PzsMeLJTc83mS45G17n = headers.copy()
		W9PzsMeLJTc83mS45G17n[I5bUBGpPXn0W6(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࠒ")] = QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨࠓ")
		NNdthm8Tc71DVUrXyCkFJ2QKwlfBa = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,Cp6c5tZe8I0PxnAW(u"ࠪࡔࡔ࡙ࡔࠨࠔ"),url,j6KOlzWGugZqmx0sPS,W9PzsMeLJTc83mS45G17n,eHdDoxhJCEPMZFVa2fg,rDceXBpHkfVUYRJ3tIx95Z,eNEhtuoi9gK8JaTpIXj(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠵ࡲࡩ࠭ࠕ"))
		L3f4VRFXh0Sb1xwKPzoi = NNdthm8Tc71DVUrXyCkFJ2QKwlfBa.content
	IkiTNYZ531tc8yfKJAqQ,oP1fJRyKgmWv2dhisVCtecFbl5G,a03RWSd4pKwscEY = qTdWVHsCB8DvNFuRfaj6KLA(url,L3f4VRFXh0Sb1xwKPzoi)
	cMj58K6gnvq1z4RPXioUt[qVRkXOP5i0Le7o] = IkiTNYZ531tc8yfKJAqQ,oP1fJRyKgmWv2dhisVCtecFbl5G,a03RWSd4pKwscEY,gYetqQsBzcT9oNm7Wi2
	return
cMj58K6gnvq1z4RPXioUt,nL6SzOr9NBT = {},CKUiyEe28zsZ(u"࠱ण")
def TuZk0aqBKVvCzdyMxhwJDtbS(url):
	global cMj58K6gnvq1z4RPXioUt,nL6SzOr9NBT
	JCZVK86QTYwX4mfgOrod,threads = [],[]
	nL6SzOr9NBT += LyOR7f69iA(u"࠳࠳࠴त")
	EEwha7xqIPH8LKbCyVpfWr2J = nL6SzOr9NBT
	JCZVK86QTYwX4mfgOrod.append([LyOR7f69iA(u"࠴थ"),url])
	cMj58K6gnvq1z4RPXioUt[EEwha7xqIPH8LKbCyVpfWr2J+wY1p9mP03S8drbcH64t5WQkv(u"࠵द")] = [None,None,None,None]
	jQU9BMCDT7rOWngp3 = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=npYeGdUTi6mHXovPz4S,args=(EEwha7xqIPH8LKbCyVpfWr2J+S8i3sBYoHWdTURpAgN(u"࠶ध"),url))
	jQU9BMCDT7rOWngp3.start()
	jQU9BMCDT7rOWngp3.join(I5bUBGpPXn0W6(u"࠷࠰न"))
	if not cMj58K6gnvq1z4RPXioUt[EEwha7xqIPH8LKbCyVpfWr2J+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠱ऩ")][FB0pIzAoK8wqgd3UiY5]:
		E1Viom5L3684CTOFJ = url.replace(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ࠖ"),ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠭࠯ࠨࠗ"))
		dezG4T3itVrAKvX9 = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠧ࡟ࠪ࠱࠮ࡄࡀ࠯࠰࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬࠨࠬ࠘"),E1Viom5L3684CTOFJ+S8i3sBYoHWdTURpAgN(u"ࠨ࠱ࠪ࠙"),cBawilJXvK1m.DOTALL)
		start,KSRhEpNs6X7fZQlr42uOkHMwng,end = dezG4T3itVrAKvX9[x1Oa8bBf36EwsLMirtFc]
		end = end.strip(LTN6DPEmrwehtZMy(u"ࠩ࠲ࠫࠚ"))
		W8EiVCXBOc1dDf = len(KSRhEpNs6X7fZQlr42uOkHMwng)<J7divaGOCgq2SLfXpDzZYN58wc(u"࠵प") or KSRhEpNs6X7fZQlr42uOkHMwng in [ilBWK5nXxg1do4jENGC07Zq(u"ࠪࡪ࡮ࡲࡥࠨࠛ"),bP01xn84BiQN(u"ࠫࡻ࡯ࡤࡦࡱࠪࠜ"),GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠬࡼࡩࡥࡧࡲࡩࡲࡨࡥࡥࠩࠝ"),bP01xn84BiQN(u"࠭ࡡ࡫ࡣࡻࠫࠞ"),f90fGrlSEObDsuiA3U(u"ࠧࡪࡨࡵࡥࡲ࡫ࠧࠟ"),Cp6c5tZe8I0PxnAW(u"ࠨ࡯࡬ࡶࡷࡵࡲࠨࠠ")]
		if not W8EiVCXBOc1dDf: JCZVK86QTYwX4mfgOrod.append([TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠴फ"),start+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪࠡ")+KSRhEpNs6X7fZQlr42uOkHMwng+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠪ࠳ࠬࠢ")+end])
		if end: JCZVK86QTYwX4mfgOrod.append([EX25Y0l8ILvz7QcRC(u"࠶ब"),start+iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠫ࠴࠭ࠣ")+KSRhEpNs6X7fZQlr42uOkHMwng+XugxFprC26zGM(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ࠤ")+end])
		if eNEhtuoi9gK8JaTpIXj(u"࠭࠮ࡩࡶࡰࡰࠬࠥ") in KSRhEpNs6X7fZQlr42uOkHMwng:
			EGHo4g1AfZCyK = KSRhEpNs6X7fZQlr42uOkHMwng.replace(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧ࠯ࡪࡷࡱࡱ࠭ࠦ"),eHdDoxhJCEPMZFVa2fg)
			JCZVK86QTYwX4mfgOrod.append([J7divaGOCgq2SLfXpDzZYN58wc(u"࠸भ"),start+ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࠱ࠪࠧ")+EGHo4g1AfZCyK+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࠲ࠫࠨ")+end])
			JCZVK86QTYwX4mfgOrod.append([KKOXx3uWLqpTSahNUHiBF87PcZoe(u"࠺म"),start+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫࠩ")+EGHo4g1AfZCyK+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫ࠴࠭ࠪ")+end])
			if end: JCZVK86QTYwX4mfgOrod.append([iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠼य"),start+I5bUBGpPXn0W6(u"ࠬ࠵ࠧࠫ")+EGHo4g1AfZCyK+dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧࠬ")+end])
		elif jUcmHhgVvW0EdYOIfXeaDF(u"ࠧ࠯ࡪࡷࡱࡱ࠭࠭") in end:
			BJ2H6MhXCQaedvSx578EUoInTP0O = end.replace(NxXMrsTC5FniYuRBOK8(u"ࠨ࠰࡫ࡸࡲࡲࠧ࠮"),eHdDoxhJCEPMZFVa2fg)
			JCZVK86QTYwX4mfgOrod.append([XugxFprC26zGM(u"࠷र"),start+NxXMrsTC5FniYuRBOK8(u"ࠩ࠲ࠫ࠯")+KSRhEpNs6X7fZQlr42uOkHMwng+XugxFprC26zGM(u"ࠪ࠳ࠬ࠰")+BJ2H6MhXCQaedvSx578EUoInTP0O])
			if not W8EiVCXBOc1dDf: JCZVK86QTYwX4mfgOrod.append([TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠹ऱ"),start+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ࠱")+KSRhEpNs6X7fZQlr42uOkHMwng+LyOR7f69iA(u"ࠬ࠵ࠧ࠲")+BJ2H6MhXCQaedvSx578EUoInTP0O])
			JCZVK86QTYwX4mfgOrod.append([KW5bYS20wTF1LyCs9(u"࠻ल"),start+HkiMU0QrdzW3l6gwnT(u"࠭࠯ࠨ࠳")+KSRhEpNs6X7fZQlr42uOkHMwng+ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ࠴")+BJ2H6MhXCQaedvSx578EUoInTP0O])
		else:
			if not W8EiVCXBOc1dDf: JCZVK86QTYwX4mfgOrod.append([QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠴࠴ळ"),start+ilBWK5nXxg1do4jENGC07Zq(u"ࠨ࠱ࠪ࠵")+KSRhEpNs6X7fZQlr42uOkHMwng+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ࠶")])
			if not W8EiVCXBOc1dDf: JCZVK86QTYwX4mfgOrod.append([ehfEsaiJBSvbcULtNPVgykA2(u"࠵࠶ऴ"),start+ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ࠷")+KSRhEpNs6X7fZQlr42uOkHMwng+J7divaGOCgq2SLfXpDzZYN58wc(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ࠸")])
			if end: JCZVK86QTYwX4mfgOrod.append([CKUiyEe28zsZ(u"࠶࠸व"),start+dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠬ࠵ࠧ࠹")+KSRhEpNs6X7fZQlr42uOkHMwng+KQ3sCe9Pzh(u"࠭࠯ࠨ࠺")+end+ilBWK5nXxg1do4jENGC07Zq(u"ࠧ࠯ࡪࡷࡱࡱ࠭࠻")])
			if end: JCZVK86QTYwX4mfgOrod.append([KW5bYS20wTF1LyCs9(u"࠷࠳श"),start+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨ࠱ࠪ࠼")+KSRhEpNs6X7fZQlr42uOkHMwng+TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪ࠽")+end+KQ3sCe9Pzh(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ࠾")])
		if W8EiVCXBOc1dDf and end:
			end = end.replace(ietolwsjpIPK7Fr(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬ࠿"),jUcmHhgVvW0EdYOIfXeaDF(u"ࠬ࠵ࠧࡀ"))
			JCZVK86QTYwX4mfgOrod.append([GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠱࠵ष"),start+t3coAp06zvHrTl49bUVgx(u"࠭࠯ࠨࡁ")+end])
			JCZVK86QTYwX4mfgOrod.append([LyOR7f69iA(u"࠲࠷स"),start+jUcmHhgVvW0EdYOIfXeaDF(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨࡂ")+end])
			if egY8Jti0smdLM3h1VQRSW(u"ࠨ࠰࡫ࡸࡲࡲࠧࡃ") in end:
				BJ2H6MhXCQaedvSx578EUoInTP0O = end.replace(bP01xn84BiQN(u"ࠩ࠱࡬ࡹࡳ࡬ࠨࡄ"),eHdDoxhJCEPMZFVa2fg)
				JCZVK86QTYwX4mfgOrod.append([ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠳࠹ह"),start+CKUiyEe28zsZ(u"ࠪ࠳ࠬࡅ")+BJ2H6MhXCQaedvSx578EUoInTP0O])
				JCZVK86QTYwX4mfgOrod.append([XugxFprC26zGM(u"࠴࠻ऺ"),start+ilBWK5nXxg1do4jENGC07Zq(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬࡆ")+BJ2H6MhXCQaedvSx578EUoInTP0O])
			else:
				JCZVK86QTYwX4mfgOrod.append([NxXMrsTC5FniYuRBOK8(u"࠵࠽ऻ"),start+LTN6DPEmrwehtZMy(u"ࠬ࠵ࠧࡇ")+end+jUcmHhgVvW0EdYOIfXeaDF(u"࠭࠮ࡩࡶࡰࡰࠬࡈ")])
				JCZVK86QTYwX4mfgOrod.append([bP01xn84BiQN(u"࠶࠿़"),start+LTN6DPEmrwehtZMy(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨࡉ")+end+bP01xn84BiQN(u"ࠨ࠰࡫ࡸࡲࡲࠧࡊ")])
		un5INVWjHeFX10SBiaO = []
		for bAQX4RoUJYDEVqKMgLW56F7Zh9z,apOKrFbP9IYHDyUVm7 in JCZVK86QTYwX4mfgOrod[HkiMU0QrdzW3l6gwnT(u"࠷ऽ"):]:
			cMj58K6gnvq1z4RPXioUt[EEwha7xqIPH8LKbCyVpfWr2J+bAQX4RoUJYDEVqKMgLW56F7Zh9z] = [None,None,None,None]
			KEOorfUts65gXDvbHMV3N = fFkWcdnY8bEHhXMNpCjx6Ia7VAze.Thread(target=npYeGdUTi6mHXovPz4S,args=(EEwha7xqIPH8LKbCyVpfWr2J+bAQX4RoUJYDEVqKMgLW56F7Zh9z,apOKrFbP9IYHDyUVm7))
			KEOorfUts65gXDvbHMV3N.start()
			un5INVWjHeFX10SBiaO.append(KEOorfUts65gXDvbHMV3N)
			b8bLFaejUB.sleep(ietolwsjpIPK7Fr(u"࠰࠯࠹࠸ा"))
		for KEOorfUts65gXDvbHMV3N in un5INVWjHeFX10SBiaO: KEOorfUts65gXDvbHMV3N.join(ilBWK5nXxg1do4jENGC07Zq(u"࠲࠲ि"))
	CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = eHdDoxhJCEPMZFVa2fg,[],[]
	YAaiDoVhGzp = []
	for bAQX4RoUJYDEVqKMgLW56F7Zh9z,apOKrFbP9IYHDyUVm7 in JCZVK86QTYwX4mfgOrod:
		Sy4ivu9HcsQI,loy1KS7HJhjC36wfsTiqQM,kJlTvOus2KxX8jrfF4DeypaB5thmb,pwjBfe9q4I017v5s36HJU = cMj58K6gnvq1z4RPXioUt[EEwha7xqIPH8LKbCyVpfWr2J+bAQX4RoUJYDEVqKMgLW56F7Zh9z]
		if not ppQOjlq2gaPkW and kJlTvOus2KxX8jrfF4DeypaB5thmb: FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW = loy1KS7HJhjC36wfsTiqQM,kJlTvOus2KxX8jrfF4DeypaB5thmb
		if not CZBQor8PhWYnplUtkzvH6 and Sy4ivu9HcsQI: CZBQor8PhWYnplUtkzvH6 = Sy4ivu9HcsQI
		if pwjBfe9q4I017v5s36HJU: YAaiDoVhGzp.append(pwjBfe9q4I017v5s36HJU)
	YAaiDoVhGzp = list(set(YAaiDoVhGzp))
	if not CZBQor8PhWYnplUtkzvH6 and len(YAaiDoVhGzp)==KW5bYS20wTF1LyCs9(u"࠳ी"):
		gYetqQsBzcT9oNm7Wi2 = YAaiDoVhGzp[x1Oa8bBf36EwsLMirtFc]
		if gYetqQsBzcT9oNm7Wi2!=TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠵࠴࠵ु"):
			if gYetqQsBzcT9oNm7Wi2<LyOR7f69iA(u"࠴ू"): CZBQor8PhWYnplUtkzvH6 = wY1p9mP03S8drbcH64t5WQkv(u"࡙ࠩ࡭ࡩ࡫࡯ࠡࡲࡤ࡫ࡪ࠵ࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡱࡳࡹࠦࡡࡤࡥࡨࡷࡸ࡯ࡢ࡭ࡧࠪࡋ")
			else:
				CZBQor8PhWYnplUtkzvH6 = ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠪࡌ࡙࡚ࡐࠡࡇࡵࡶࡴࡸ࠺ࠡࠩࡌ")+str(gYetqQsBzcT9oNm7Wi2)
				if WHjh1POtMKlmgiy68RSqb: import http.client as n3mkHYfNacU7tu6T4ZShGPyK
				else: import httplib as n3mkHYfNacU7tu6T4ZShGPyK
				try: CZBQor8PhWYnplUtkzvH6 += RqLvTrID0yMVeClpYcnZ16i3X(u"ࠫࠥ࠮ࠠࠨࡍ")+n3mkHYfNacU7tu6T4ZShGPyK.responses[gYetqQsBzcT9oNm7Wi2]+RqLvTrID0yMVeClpYcnZ16i3X(u"ࠬࠦࠩࠨࡎ")
				except: pass
	b8bLFaejUB.sleep(ehfEsaiJBSvbcULtNPVgykA2(u"࠶ृ"))
	return CZBQor8PhWYnplUtkzvH6,FBITEXGDfe2mcCxnQs6ktMdy9HJh,ppQOjlq2gaPkW
class JiaKMLmlE3fW8HSk5wzG(VVZgPQ2kYLoKe6jic5AEzqupG.WindowDialog):
	def __init__(gmChyf98s5, *args, **XsN3vaEdwV1Qpm):
		SbzIUgWMH7o4eYEhvRGmukVJ = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx, HkiMU0QrdzW3l6gwnT(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩࡏ"), KW5bYS20wTF1LyCs9(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫࡐ"), S8i3sBYoHWdTURpAgN(u"ࠨࡦ࡬ࡥࡱࡵࡧࡣࡩ࠱ࡴࡳ࡭ࠧࡑ"))
		GAZdO2YDUgpeaCc0QTN = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx, RqLvTrID0yMVeClpYcnZ16i3X(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬࡒ"), LyOR7f69iA(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧࡓ"), jUcmHhgVvW0EdYOIfXeaDF(u"ࠫࡸ࡫࡬ࡦࡥࡷࡩࡩ࠴ࡰ࡯ࡩࠪࡔ"))
		wwxYalHGzA4bIhg81 = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx, HkiMU0QrdzW3l6gwnT(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨࡕ"), CKUiyEe28zsZ(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪࡖ"), RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡣࡷࡷࡸࡴࡴࡦࡰ࠰ࡳࡲ࡬࠭ࡗ"))
		ycGNVWDMBUvuJAxYI2Opd5Q1R = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx, ilBWK5nXxg1do4jENGC07Zq(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫࡘ"), LTN6DPEmrwehtZMy(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࡙࠭"), ehfEsaiJBSvbcULtNPVgykA2(u"ࠪࡦࡺࡺࡴࡰࡰࡱࡪ࠳ࡶ࡮ࡨ࡚ࠩ"))
		UgcoG1Ylz4STILwtyfPumiXv = RRydns1CErYlIhwSx7.path.join(lAf7eTIozDOK0arHsmWx, I5bUBGpPXn0W6(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹ࡛ࠧ"), QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ࡜"), Cp6c5tZe8I0PxnAW(u"࠭ࡢࡶࡶࡷࡳࡳࡨࡧ࠯ࡲࡱ࡫ࠬ࡝"))
		gmChyf98s5.cancelled = rDceXBpHkfVUYRJ3tIx95Z
		gmChyf98s5.chk = [x1Oa8bBf36EwsLMirtFc] * KQ3sCe9Pzh(u"࠿ॄ")
		gmChyf98s5.chkbutton = [x1Oa8bBf36EwsLMirtFc] * GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠹ॅ")
		gmChyf98s5.chkstate = [rDceXBpHkfVUYRJ3tIx95Z] * EX25Y0l8ILvz7QcRC(u"࠺ॆ")
		MyXiTERdWGsSDl18jYzB5rVbnP, JADC4HFe9Q1wVPhkigsZrMBOW, TbVDEd93XKC, VXyQYTAPZ6NeGMsJpfFdm8Kx = dEwyQDiz0nhjV6MovaH7tIWYel92(u"࠵࠹࠵ै"), CKUiyEe28zsZ(u"࠲े"), ehfEsaiJBSvbcULtNPVgykA2(u"࠻࠵࠶ॉ"), TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠼࠼࠰ॊ")
		skQCyZI2PT0XEgbNJVtS8w = MyXiTERdWGsSDl18jYzB5rVbnP+TbVDEd93XKC//LTN6DPEmrwehtZMy(u"࠸ो")
		BFsIO6GbjSdni9Hm1U5PcKVDRMqtkY, Xx8zsNHnqfhKeTvL7ki3m6AyPR, lnOoLQNbewvVdgyWxDGs9SrzjR, neZU8CH2sBzjVR = Cp6c5tZe8I0PxnAW(u"࠴࠷࠸्"), LyOR7f69iA(u"࠱࠳࠲ौ"), ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷࠳࠴ॎ"), ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"࠷࠳࠴ॎ")
		y8stM9oflN64aHdTI3 = BFsIO6GbjSdni9Hm1U5PcKVDRMqtkY+lnOoLQNbewvVdgyWxDGs9SrzjR//egY8Jti0smdLM3h1VQRSW(u"࠵ॏ")
		dgjWQJ7IrD1UmkCiAGROy09Zz, ZIWTY0fueR, ouk0mZDVO2fNGLB8, nF5VSCJ3vUD2K6TdYstGeW = t3coAp06zvHrTl49bUVgx(u"࠶࠶࠰॑"), jUcmHhgVvW0EdYOIfXeaDF(u"࠼࠵࠶॒"), bP01xn84BiQN(u"࠵࠺࠶ॐ"), KQ3sCe9Pzh(u"࠵࠱॓")
		DevTfuFrH1NWACgcnZs8ML6QU4 = skQCyZI2PT0XEgbNJVtS8w-ouk0mZDVO2fNGLB8-dgjWQJ7IrD1UmkCiAGROy09Zz//TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠳॔")
		S9pxfsUwqc8IP7K2 = skQCyZI2PT0XEgbNJVtS8w+dgjWQJ7IrD1UmkCiAGROy09Zz//KW5bYS20wTF1LyCs9(u"࠴ॕ")
		oJaf1rePFmxDCi9V, dSilhnHKyRpjXDosEO6LW, Y6YuP4wZ2RT7W3ovyQLaBVEj, H2KYekRfA4zBpTJS = KQ3sCe9Pzh(u"࠶࠹࠺ॖ"), XugxFprC26zGM(u"࠷࠵ॗ"), KQ3sCe9Pzh(u"࠻࠰࠱ख़"), TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺࠶क़")
		MjtXEP1vY386Nq7yz4Rp, QfRbAulLpvDZ6G, y4NrGTf3mWa5bAD, nAK2qCFTeOjPN1Bao = S8i3sBYoHWdTURpAgN(u"࠳࠶࠷ग़"), TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠺࠴ढ़"), QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠷࠳࠴ड़"), QQM0uTLKsZWel6m1arpjVz4vwcSN(u"࠶࠲ज़")
		a0ayr8NxTbQ1WX9eDutIwLc = f90fGrlSEObDsuiA3U(u"࠴࠳࠿फ़")
		MyXiTERdWGsSDl18jYzB5rVbnP, JADC4HFe9Q1wVPhkigsZrMBOW, TbVDEd93XKC, VXyQYTAPZ6NeGMsJpfFdm8Kx = int(MyXiTERdWGsSDl18jYzB5rVbnP*a0ayr8NxTbQ1WX9eDutIwLc), int(JADC4HFe9Q1wVPhkigsZrMBOW*a0ayr8NxTbQ1WX9eDutIwLc), int(TbVDEd93XKC*a0ayr8NxTbQ1WX9eDutIwLc), int(VXyQYTAPZ6NeGMsJpfFdm8Kx*a0ayr8NxTbQ1WX9eDutIwLc)
		BFsIO6GbjSdni9Hm1U5PcKVDRMqtkY, Xx8zsNHnqfhKeTvL7ki3m6AyPR, lnOoLQNbewvVdgyWxDGs9SrzjR, neZU8CH2sBzjVR = int(BFsIO6GbjSdni9Hm1U5PcKVDRMqtkY*a0ayr8NxTbQ1WX9eDutIwLc), int(Xx8zsNHnqfhKeTvL7ki3m6AyPR*a0ayr8NxTbQ1WX9eDutIwLc), int(lnOoLQNbewvVdgyWxDGs9SrzjR*a0ayr8NxTbQ1WX9eDutIwLc), int(neZU8CH2sBzjVR*a0ayr8NxTbQ1WX9eDutIwLc)
		DevTfuFrH1NWACgcnZs8ML6QU4, mrZ7hPtlBJXO2nufjCax, dZqocLu8M79TyvxjW, vf5CUJzatbBjc = int(DevTfuFrH1NWACgcnZs8ML6QU4*a0ayr8NxTbQ1WX9eDutIwLc), int(ZIWTY0fueR*a0ayr8NxTbQ1WX9eDutIwLc), int(ouk0mZDVO2fNGLB8*a0ayr8NxTbQ1WX9eDutIwLc), int(nF5VSCJ3vUD2K6TdYstGeW*a0ayr8NxTbQ1WX9eDutIwLc)
		S9pxfsUwqc8IP7K2, cF2MSeaJCpx7ms, uuHajZmcUfVToKzx8, DPkO3VMGIpfZ = int(S9pxfsUwqc8IP7K2*a0ayr8NxTbQ1WX9eDutIwLc), int(ZIWTY0fueR*a0ayr8NxTbQ1WX9eDutIwLc), int(ouk0mZDVO2fNGLB8*a0ayr8NxTbQ1WX9eDutIwLc), int(nF5VSCJ3vUD2K6TdYstGeW*a0ayr8NxTbQ1WX9eDutIwLc)
		oJaf1rePFmxDCi9V, dSilhnHKyRpjXDosEO6LW, Y6YuP4wZ2RT7W3ovyQLaBVEj, H2KYekRfA4zBpTJS = int(oJaf1rePFmxDCi9V*a0ayr8NxTbQ1WX9eDutIwLc), int(dSilhnHKyRpjXDosEO6LW*a0ayr8NxTbQ1WX9eDutIwLc), int(Y6YuP4wZ2RT7W3ovyQLaBVEj*a0ayr8NxTbQ1WX9eDutIwLc), int(H2KYekRfA4zBpTJS*a0ayr8NxTbQ1WX9eDutIwLc)
		MjtXEP1vY386Nq7yz4Rp, QfRbAulLpvDZ6G, y4NrGTf3mWa5bAD, nAK2qCFTeOjPN1Bao = int(MjtXEP1vY386Nq7yz4Rp*a0ayr8NxTbQ1WX9eDutIwLc), int(QfRbAulLpvDZ6G*a0ayr8NxTbQ1WX9eDutIwLc), int(y4NrGTf3mWa5bAD*a0ayr8NxTbQ1WX9eDutIwLc), int(nAK2qCFTeOjPN1Bao*a0ayr8NxTbQ1WX9eDutIwLc)
		TrMheJ3ERpzXw9W8By1vN = VVZgPQ2kYLoKe6jic5AEzqupG.ControlImage(MyXiTERdWGsSDl18jYzB5rVbnP, JADC4HFe9Q1wVPhkigsZrMBOW, TbVDEd93XKC, VXyQYTAPZ6NeGMsJpfFdm8Kx, SbzIUgWMH7o4eYEhvRGmukVJ)
		gmChyf98s5.addControl(TrMheJ3ERpzXw9W8By1vN)
		gmChyf98s5.iteration = XsN3vaEdwV1Qpm.get(dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠧࡪࡶࡨࡶࡦࡺࡩࡰࡰࠪ࡞"))
		bhn3BUp7PqaeR9SDFrL = OR97bMGecfgDCqux3YdAZ6y+NxXMrsTC5FniYuRBOK8(u"ࠨใะูࠥษๆศࠢศุ๊อๆ๊ࠡ็ืฯࠦั้ส๋ฮࠥࠦࠠࠡࠢࠣࠤࠥࠦࠧ࡟")+ehfEsaiJBSvbcULtNPVgykA2(u"ࠩส่๊ำว้ๆฬࠤึ่ๅࠡࠢࠪࡠ")+str(gmChyf98s5.iteration)+Nat0Dx9puRUWCsgz6JyFhY3
		gmChyf98s5.strActionInfo = VVZgPQ2kYLoKe6jic5AEzqupG.ControlLabel(oJaf1rePFmxDCi9V, dSilhnHKyRpjXDosEO6LW, Y6YuP4wZ2RT7W3ovyQLaBVEj, H2KYekRfA4zBpTJS, bhn3BUp7PqaeR9SDFrL, HkiMU0QrdzW3l6gwnT(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪࡡ"))
		gmChyf98s5.addControl(gmChyf98s5.strActionInfo)
		PeLqCN5Ek8bB = VVZgPQ2kYLoKe6jic5AEzqupG.ControlImage(BFsIO6GbjSdni9Hm1U5PcKVDRMqtkY, Xx8zsNHnqfhKeTvL7ki3m6AyPR, lnOoLQNbewvVdgyWxDGs9SrzjR, neZU8CH2sBzjVR, XsN3vaEdwV1Qpm.get(t3coAp06zvHrTl49bUVgx(u"ࠫࡨࡧࡰࡵࡥ࡫ࡥࠬࡢ")))
		gmChyf98s5.addControl(PeLqCN5Ek8bB)
		oIkcg9ZKGFaEw0XyrT7 = OR97bMGecfgDCqux3YdAZ6y+XsN3vaEdwV1Qpm.get(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠬࡳࡳࡨࠩࡣ"))+Nat0Dx9puRUWCsgz6JyFhY3
		gmChyf98s5.strActionInfo = VVZgPQ2kYLoKe6jic5AEzqupG.ControlLabel(MjtXEP1vY386Nq7yz4Rp, QfRbAulLpvDZ6G, y4NrGTf3mWa5bAD, nAK2qCFTeOjPN1Bao, oIkcg9ZKGFaEw0XyrT7, bP01xn84BiQN(u"࠭ࡦࡰࡰࡷ࠵࠸࠭ࡤ"))
		gmChyf98s5.addControl(gmChyf98s5.strActionInfo)
		text = OR97bMGecfgDCqux3YdAZ6y+bP01xn84BiQN(u"ࠧฯำ๋ะࠬࡥ")+Nat0Dx9puRUWCsgz6JyFhY3
		gmChyf98s5.cancelbutton = VVZgPQ2kYLoKe6jic5AEzqupG.ControlButton(DevTfuFrH1NWACgcnZs8ML6QU4, mrZ7hPtlBJXO2nufjCax, dZqocLu8M79TyvxjW, vf5CUJzatbBjc, text, focusTexture=UgcoG1Ylz4STILwtyfPumiXv, noFocusTexture=wwxYalHGzA4bIhg81, alignment=CKUiyEe28zsZ(u"࠷य़"))
		text = OR97bMGecfgDCqux3YdAZ6y+GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠨษึฮ๊ืวาࠩࡦ")+Nat0Dx9puRUWCsgz6JyFhY3
		gmChyf98s5.okbutton = VVZgPQ2kYLoKe6jic5AEzqupG.ControlButton(S9pxfsUwqc8IP7K2, cF2MSeaJCpx7ms, uuHajZmcUfVToKzx8, DPkO3VMGIpfZ, text, focusTexture=UgcoG1Ylz4STILwtyfPumiXv, noFocusTexture=wwxYalHGzA4bIhg81, alignment=RqLvTrID0yMVeClpYcnZ16i3X(u"࠸ॠ"))
		gmChyf98s5.addControl(gmChyf98s5.okbutton)
		gmChyf98s5.addControl(gmChyf98s5.cancelbutton)
		UNBEdKGrsn4O8pXMAT2LhPYbgmRuw, A4AGrTpEdf = neZU8CH2sBzjVR//w2vjZmdJuY7c(u"࠳ॡ"), lnOoLQNbewvVdgyWxDGs9SrzjR//w2vjZmdJuY7c(u"࠳ॡ")
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(RqLvTrID0yMVeClpYcnZ16i3X(u"࠺ॢ")):
			sMEoLWZ4IgaR = dhcGSyo8Kn1mHZwvEAkzJ7NUq // iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"࠵ॣ")
			HH9y3RixvlTJEKOLAZePXc = dhcGSyo8Kn1mHZwvEAkzJ7NUq % w2vjZmdJuY7c(u"࠶।")
			rcIyfv4ERWCVks70Ai1jZ3 = BFsIO6GbjSdni9Hm1U5PcKVDRMqtkY + (A4AGrTpEdf * HH9y3RixvlTJEKOLAZePXc)
			cYiSV3gzqaT0F4W = Xx8zsNHnqfhKeTvL7ki3m6AyPR + (UNBEdKGrsn4O8pXMAT2LhPYbgmRuw * sMEoLWZ4IgaR)
			gmChyf98s5.chk[dhcGSyo8Kn1mHZwvEAkzJ7NUq] = VVZgPQ2kYLoKe6jic5AEzqupG.ControlImage(rcIyfv4ERWCVks70Ai1jZ3, cYiSV3gzqaT0F4W, A4AGrTpEdf, UNBEdKGrsn4O8pXMAT2LhPYbgmRuw, GAZdO2YDUgpeaCc0QTN)
			gmChyf98s5.addControl(gmChyf98s5.chk[dhcGSyo8Kn1mHZwvEAkzJ7NUq])
			gmChyf98s5.chk[dhcGSyo8Kn1mHZwvEAkzJ7NUq].setVisible(rDceXBpHkfVUYRJ3tIx95Z)
			gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq] = VVZgPQ2kYLoKe6jic5AEzqupG.ControlButton(rcIyfv4ERWCVks70Ai1jZ3, cYiSV3gzqaT0F4W, A4AGrTpEdf, UNBEdKGrsn4O8pXMAT2LhPYbgmRuw, str(dhcGSyo8Kn1mHZwvEAkzJ7NUq + f90fGrlSEObDsuiA3U(u"࠵॥")), font=LyOR7f69iA(u"ࠩࡩࡳࡳࡺ࠱࠴ࠩࡧ"), focusTexture=wwxYalHGzA4bIhg81, noFocusTexture=ycGNVWDMBUvuJAxYI2Opd5Q1R)
			gmChyf98s5.addControl(gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq])
		for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(t3coAp06zvHrTl49bUVgx(u"࠾०")):
			ZSrfUy7nlW34mkAG0qOhKagcJ9C = (dhcGSyo8Kn1mHZwvEAkzJ7NUq // wY1p9mP03S8drbcH64t5WQkv(u"࠹१")) * wY1p9mP03S8drbcH64t5WQkv(u"࠹१")
			UpcBymMeZbx1haVfSsk7EFI6YL = ZSrfUy7nlW34mkAG0qOhKagcJ9C + (dhcGSyo8Kn1mHZwvEAkzJ7NUq + RqLvTrID0yMVeClpYcnZ16i3X(u"࠱२")) % ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"࠴३")
			RQNjBOpPn7g2H9E = ZSrfUy7nlW34mkAG0qOhKagcJ9C + (dhcGSyo8Kn1mHZwvEAkzJ7NUq - I5bUBGpPXn0W6(u"࠳४")) % t3coAp06zvHrTl49bUVgx(u"࠶५")
			pzEsqY1tACnPjv = (dhcGSyo8Kn1mHZwvEAkzJ7NUq - KQ3sCe9Pzh(u"࠸७")) % LTN6DPEmrwehtZMy(u"࠽६")
			ERQxtqn5fbT7 = (dhcGSyo8Kn1mHZwvEAkzJ7NUq + ilBWK5nXxg1do4jENGC07Zq(u"࠳९")) % bP01xn84BiQN(u"࠿८")
			gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq].controlRight(gmChyf98s5.chkbutton[UpcBymMeZbx1haVfSsk7EFI6YL])
			gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq].controlLeft(gmChyf98s5.chkbutton[RQNjBOpPn7g2H9E])
			if dhcGSyo8Kn1mHZwvEAkzJ7NUq <= S8i3sBYoHWdTURpAgN(u"࠳॰"):
				gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq].controlUp(gmChyf98s5.okbutton)
			else:
				gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq].controlUp(gmChyf98s5.chkbutton[pzEsqY1tACnPjv])
			if dhcGSyo8Kn1mHZwvEAkzJ7NUq >= S8i3sBYoHWdTURpAgN(u"࠸ॱ"):
				gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq].controlDown(gmChyf98s5.okbutton)
			else:
				gmChyf98s5.chkbutton[dhcGSyo8Kn1mHZwvEAkzJ7NUq].controlDown(gmChyf98s5.chkbutton[ERQxtqn5fbT7])
		gmChyf98s5.okbutton.controlLeft(gmChyf98s5.cancelbutton)
		gmChyf98s5.okbutton.controlRight(gmChyf98s5.cancelbutton)
		gmChyf98s5.cancelbutton.controlLeft(gmChyf98s5.okbutton)
		gmChyf98s5.cancelbutton.controlRight(gmChyf98s5.okbutton)
		gmChyf98s5.okbutton.controlDown(gmChyf98s5.chkbutton[FB0pIzAoK8wqgd3UiY5])
		gmChyf98s5.okbutton.controlUp(gmChyf98s5.chkbutton[w2vjZmdJuY7c(u"࠻ॲ")])
		gmChyf98s5.cancelbutton.controlDown(gmChyf98s5.chkbutton[x1Oa8bBf36EwsLMirtFc])
		gmChyf98s5.cancelbutton.controlUp(gmChyf98s5.chkbutton[LyOR7f69iA(u"࠺ॳ")])
		gmChyf98s5.setFocus(gmChyf98s5.okbutton)
	def get(gmChyf98s5):
		gmChyf98s5.doModal()
		gmChyf98s5.close()
		if not gmChyf98s5.cancelled:
			return [dhcGSyo8Kn1mHZwvEAkzJ7NUq for dhcGSyo8Kn1mHZwvEAkzJ7NUq in range(XugxFprC26zGM(u"࠾ॴ")) if gmChyf98s5.chkstate[dhcGSyo8Kn1mHZwvEAkzJ7NUq]]
	def onControl(gmChyf98s5, X4XCv52ZA0GheM6tqiknwU):
		if X4XCv52ZA0GheM6tqiknwU.getId() == gmChyf98s5.okbutton.getId() and any(gmChyf98s5.chkstate):
			gmChyf98s5.close()
		elif X4XCv52ZA0GheM6tqiknwU.getId() == gmChyf98s5.cancelbutton.getId():
			gmChyf98s5.cancelled = YchIv6N09BaWPEj4tieAnluKZrRXT
			gmChyf98s5.close()
		else:
			jZHGcWxXpdVO038fnt = X4XCv52ZA0GheM6tqiknwU.getLabel()
			if jZHGcWxXpdVO038fnt.isnumeric():
				index = int(jZHGcWxXpdVO038fnt) - jUcmHhgVvW0EdYOIfXeaDF(u"࠷ॵ")
				gmChyf98s5.chkstate[index] = not gmChyf98s5.chkstate[index]
				gmChyf98s5.chk[index].setVisible(gmChyf98s5.chkstate[index])
	def onAction(gmChyf98s5, RLepADMmoBQqVnlT5t):
		if RLepADMmoBQqVnlT5t == LTN6DPEmrwehtZMy(u"࠱࠱ॶ"):
			gmChyf98s5.cancelled = YchIv6N09BaWPEj4tieAnluKZrRXT
			gmChyf98s5.close()
def skwPQphCbmFYRMD0LWq(key,qStMGnRJL0exKZjiW6dC19p5,url):
	headers = {XugxFprC26zGM(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫࡨ"):url,GGn0oFgBITbethla4qXL9sfkdMZNPH(u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭ࡩ"):qStMGnRJL0exKZjiW6dC19p5}
	jlt5JRZM146xwAzhFDKP = f90fGrlSEObDsuiA3U(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠱ࡤࡴ࡮࠵ࡦࡢ࡮࡯ࡦࡦࡩ࡫ࡀ࡭ࡀࠫࡪ")+key
	aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,ilBWK5nXxg1do4jENGC07Zq(u"࠭ࡇࡆࡖࠪ࡫"),jlt5JRZM146xwAzhFDKP,eHdDoxhJCEPMZFVa2fg,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡊ࡚࡟ࡓࡇࡆࡅࡕ࡚ࡃࡉࡃ࠵ࡣ࡙ࡕࡋࡆࡐ࠰࠵ࡸࡺࠧ࡬"))
	L6GuZYmNyAEUBi1sQ,iteration = eHdDoxhJCEPMZFVa2fg,NxXMrsTC5FniYuRBOK8(u"࠱ॷ")
	while YchIv6N09BaWPEj4tieAnluKZrRXT:
		nR2B1Wye7luXb5 = aP8bLqZJsQlH3ivWKc.content
		j6KOlzWGugZqmx0sPS = cBawilJXvK1m.findall(NxXMrsTC5FniYuRBOK8(u"ࠨࠤࠫ࠳ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠯ࡢࡲ࡬࠶࠴ࡶࡡࡺ࡮ࡲࡥࡩࡡ࡞ࠣ࡟࠮࠭ࠬ࡭"), nR2B1Wye7luXb5)
		iteration += GGn0oFgBITbethla4qXL9sfkdMZNPH(u"࠳ॸ")
		message = cBawilJXvK1m.findall(Cp6c5tZe8I0PxnAW(u"ࠩ࠿ࡰࡦࡨࡥ࡭࡝ࡡࡂࡢ࠱ࡣ࡭ࡣࡶࡷࡂࠨࡦࡣࡥ࠰࡭ࡲࡧࡧࡦࡵࡨࡰࡪࡩࡴ࠮࡯ࡨࡷࡸࡧࡧࡦ࠯ࡷࡩࡽࡺࠢ࡜ࡠࡁࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡢࡤࡨࡰࡃ࠭࡮"), nR2B1Wye7luXb5)
		if not message: message = cBawilJXvK1m.findall(RqLvTrID0yMVeClpYcnZ16i3X(u"ࠪࡀࡩ࡯ࡶ࡜ࡠࡁࡡ࠰ࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡢࡤ࠯࡬ࡱࡦ࡭ࡥࡴࡧ࡯ࡩࡨࡺ࠭࡮ࡧࡶࡷࡦ࡭ࡥ࠮ࡧࡵࡶࡴࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭࡯"), nR2B1Wye7luXb5)
		if not message:
			L6GuZYmNyAEUBi1sQ = cBawilJXvK1m.findall(KKOXx3uWLqpTSahNUHiBF87PcZoe(u"ࠫࡷ࡫ࡡࡥࡱࡱࡰࡾࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࡰ"), nR2B1Wye7luXb5)[x1Oa8bBf36EwsLMirtFc]
			break
		else:
			message = message[x1Oa8bBf36EwsLMirtFc]
			j6KOlzWGugZqmx0sPS = j6KOlzWGugZqmx0sPS[x1Oa8bBf36EwsLMirtFc]
		YUzoH6ImdJl97rjqMFRPtZGp0v = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"ࡷ࠭࡮ࡢ࡯ࡨࡁࠧࡩࠢ࡝ࡵ࠮ࡺࡦࡲࡵࡦ࠿ࠥࠬࡠࡤࠢ࡞࠭ࠬࠫࡱ"), nR2B1Wye7luXb5)[x1Oa8bBf36EwsLMirtFc]
		CWHIMXmlx1oP9e2JjGBNvT7 = TMKXOwyLdzhDj1Q6PmoigsbV4(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭ࠦࡵࠪࡲ") % (j6KOlzWGugZqmx0sPS.replace(LyOR7f69iA(u"ࠧࠧࡣࡰࡴࡀ࠭ࡳ"), KW5bYS20wTF1LyCs9(u"ࠨࠨࠪࡴ")))
		message = cBawilJXvK1m.sub(ZAz3qtNh46EwTkg0dRWKD2XF7Q(u"ࠩ࠿࠳ࡄ࠮ࡤࡪࡸࡿࡷࡹࡸ࡯࡯ࡩࠬ࡟ࡣࡄ࡝ࠫࡀࠪࡵ"), eHdDoxhJCEPMZFVa2fg, message)
		iCrwDNuE6Ugf0 = JiaKMLmlE3fW8HSk5wzG(captcha=CWHIMXmlx1oP9e2JjGBNvT7, msg=message, iteration=iteration)
		E3GzsTph5J = iCrwDNuE6Ugf0.get()
		if not E3GzsTph5J: break
		data = {KQ3sCe9Pzh(u"ࠪࡧࠬࡶ"): YUzoH6ImdJl97rjqMFRPtZGp0v, NxXMrsTC5FniYuRBOK8(u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭ࡷ"): E3GzsTph5J}
		aP8bLqZJsQlH3ivWKc = aaxj45TqfRm38HepJy7C(c4cPSX2jOIm8KCQlfW5wM,egY8Jti0smdLM3h1VQRSW(u"ࠬࡖࡏࡔࡖࠪࡸ"),jlt5JRZM146xwAzhFDKP,data,headers,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,KQ3sCe9Pzh(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡊࡉ࡙ࡥࡒࡆࡅࡄࡔ࡙ࡉࡈࡂ࠴ࡢࡘࡔࡑࡅࡏ࠯࠵ࡲࡩ࠭ࡹ"))
	return L6GuZYmNyAEUBi1sQ
def vahHPgqTB9esS(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,wY1p9mP03S8drbcH64t5WQkv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡇࡂࡍࡑࡄࡈࡘ࠳࠱ࡴࡶࠪࡺ"))
	items = cBawilJXvK1m.findall(I5bUBGpPXn0W6(u"ࠨࡥࡲࡰࡴࡸ࠽ࠣࡴࡨࡨࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࡻ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[ items[x1Oa8bBf36EwsLMirtFc] ]
	else: return HkiMU0QrdzW3l6gwnT(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡘࡁࡃࡎࡒࡅࡉ࡙ࠧࡼ"),[],[]
def YqS0Uw1i46rzPtDMe(url):
	return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[url]
def gXWKhz2n1xbIVBR5sTmQFkd8A6etY(url):
	GfhcsvCWIon = url.split(S8i3sBYoHWdTURpAgN(u"ࠪ࠳ࠬࡽ"))
	gfFOp52kHwT = KW5bYS20wTF1LyCs9(u"ࠫ࠴࠭ࡾ").join(GfhcsvCWIon[KQ3sCe9Pzh(u"࠳ॹ"):XugxFprC26zGM(u"࠷ॺ")])
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,J7divaGOCgq2SLfXpDzZYN58wc(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡜ࡌࡔࡕ࡟ࡓࡉࡃࡕࡉ࠲࠷ࡳࡵࠩࡿ"))
	items = cBawilJXvK1m.findall(CKUiyEe28zsZ(u"࠭ࡤ࡭ࡤࡸࡸࡹࡵ࡮࡝ࠩ࡟࠭࠳࡮ࡲࡦࡨࠣࡁࠥࠨࠨ࠯ࠬࡂ࠭ࠧࠦ࡜ࠬࠢ࡟ࠬ࠭࠴ࠪࡀࠫࠣࡠࠪࠦࠨ࠯ࠬࡂ࠭ࠥࡢࠫࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࠧࠣࠬ࠳࠰࠿ࠪ࡞ࠬࠤࡡ࠱ࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢀ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		DDY4vSW3UQ,pxVBnJRzq0,BBvAXnziVTKwRfDUx2a,N5g3ZBO2yWI9t8rUmGd,ZGY15VL6CxB3Jrn0DakUN8,OqwriJzavymDe0njUE2TXKf = items[x1Oa8bBf36EwsLMirtFc]
		WW4LlMgICSbVYDfXKQdtzik = int(pxVBnJRzq0) % int(BBvAXnziVTKwRfDUx2a) + int(N5g3ZBO2yWI9t8rUmGd) % int(ZGY15VL6CxB3Jrn0DakUN8)
		url = gfFOp52kHwT + DDY4vSW3UQ + str(WW4LlMgICSbVYDfXKQdtzik) + OqwriJzavymDe0njUE2TXKf
		return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[url]
	else: return egY8Jti0smdLM3h1VQRSW(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢ࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠭ࢁ"),[],[]
def UdIgbLwQ6OPMBxjEXARyH40JCufvp(url):
	id = url.split(ehfEsaiJBSvbcULtNPVgykA2(u"ࠨ࠱ࠪࢂ"))[-w2vjZmdJuY7c(u"࠶ॻ")]
	headers = { QQM0uTLKsZWel6m1arpjVz4vwcSN(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࢃ") : f90fGrlSEObDsuiA3U(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩࢄ") }
	j6KOlzWGugZqmx0sPS = { TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠦ࡮ࡪࠢࢅ"):id , w2vjZmdJuY7c(u"ࠧࡵࡰࠣࢆ"):iEAhmrIUCwjleD8nX1yBqGoxvMkSTz(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠤࢇ") }
	mzfT1LoKkCy7g9wuSqV = aaxj45TqfRm38HepJy7C(srU0Sl1oOC29FB6gHTYX,HkiMU0QrdzW3l6gwnT(u"ࠧࡑࡑࡖࡘࠬ࢈"), url, j6KOlzWGugZqmx0sPS, headers, eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,CKUiyEe28zsZ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡖ࠴ࡖࡒࡏࡓࡆࡊ࠭࠲ࡵࡷࠫࢉ"))
	if TMKXOwyLdzhDj1Q6PmoigsbV4(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫࢊ") in list(mzfT1LoKkCy7g9wuSqV.headers.keys()): apOKrFbP9IYHDyUVm7 = mzfT1LoKkCy7g9wuSqV.headers[LyOR7f69iA(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࢋ")]
	else: apOKrFbP9IYHDyUVm7 = url
	if apOKrFbP9IYHDyUVm7: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[apOKrFbP9IYHDyUVm7]
	else: return eNEhtuoi9gK8JaTpIXj(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡑ࠶ࡘࡔࡑࡕࡁࡅࠩࢌ"),[],[]
def IlTvAhqyo271xiVeC0NPLKbS(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,t3coAp06zvHrTl49bUVgx(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡌࡒ࡙࡜ࡌࡊࡘࡈ࠱࠶ࡹࡴࠨࢍ"))
	items = cBawilJXvK1m.findall(wY1p9mP03S8drbcH64t5WQkv(u"࠭࡭ࡱ࠶࠽ࠤࡡࡡ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩࢎ"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[ items[x1Oa8bBf36EwsLMirtFc] ]
	else: return w2vjZmdJuY7c(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡚ࠢࡍࡓ࡚ࡖࡍࡋ࡙ࡉࠬ࢏"),[],[]
def Wz0UY6VL3Dct1m4uxrq5CwAMZS(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,Cp6c5tZe8I0PxnAW(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡃࡉࡋ࡙ࡉ࠲࠷ࡳࡵࠩ࢐"))
	items = cBawilJXvK1m.findall(ToYfyBpWumeN3ZELc5JIDtV9gdvU(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࢑"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items:
		url = url = dEwyQDiz0nhjV6MovaH7tIWYel92(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠳ࡵࡲࡨࠩ࢒") + items[x1Oa8bBf36EwsLMirtFc]
		return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[ url ]
	else: return HkiMU0QrdzW3l6gwnT(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡓࡅࡋࡍ࡛ࡋࠧ࢓"),[],[]
def dryskm6jXtQVDIxvCGSKcLO(url):
	nR2B1Wye7luXb5 = jczXhd47kwrWFoEg8lVSCR2eZfLIQT(srU0Sl1oOC29FB6gHTYX,url,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eHdDoxhJCEPMZFVa2fg,eNEhtuoi9gK8JaTpIXj(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡖࡘࡗࡋࡁࡎ࠯࠴ࡷࡹ࠭࢔"))
	items = cBawilJXvK1m.findall(f90fGrlSEObDsuiA3U(u"࠭ࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࢕"),nR2B1Wye7luXb5,cBawilJXvK1m.DOTALL)
	if items: return eHdDoxhJCEPMZFVa2fg,[eHdDoxhJCEPMZFVa2fg],[ items[x1Oa8bBf36EwsLMirtFc] ]
	else: return RqLvTrID0yMVeClpYcnZ16i3X(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡈࡗ࡙ࡘࡅࡂࡏࠪ࢖"),[],[]
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'ALFATIMI'
kL0nT7NpZdKVD3jM2OHB = '_FTM_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qbl8JdafGOc6I = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
fGycOdqoM6RSuK0szlB = ['3030','628']
def hH3sRBSFAr(mode,url,text):
	if   mode==60: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==61: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==62: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==63: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==64: SD0TxMRXiep4cjPBsnzI = P4VUMDrZ9o7zuNaBbCxd6Oji1tlvW3(text)
	elif mode==69: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,69,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'ما يتم مشاهدته الان',V4kF6EQiwo,64,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'recent_viewed_vids')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الاكثر مشاهدة',V4kF6EQiwo,64,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'most_viewed_vids')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'اضيفت مؤخرا',V4kF6EQiwo,64,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'recently_added_vids')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'فيديو عشوائي',V4kF6EQiwo,64,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'random_vids')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'افلام ومسلسلات',V4kF6EQiwo,61,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'-1')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'البرامج الدينية',V4kF6EQiwo,61,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'-2')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'English Videos',V4kF6EQiwo,61,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'-3')
	return CJlTSEpZsWb0QHg5w
def nvHUf8mW6E4GSw5VFRXN(url,y3LbIjrZvcATpNDM):
	BF0Ns1WhLkzuxj8rOGpdAPfYE9c = CJlTSEpZsWb0QHg5w
	if y3LbIjrZvcATpNDM not in ['-1','-2','-3']: BF0Ns1WhLkzuxj8rOGpdAPfYE9c = '?cat='+y3LbIjrZvcATpNDM
	BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+'/menu_level.php'+BF0Ns1WhLkzuxj8rOGpdAPfYE9c
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALFATIMI-TITLES-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	uOkSbCsqfDl7vBIM6cYa1th0NVzZ,jXqW0t7CZSn2dshG8E1HrlUu = False,False
	for ZgsbN5iSL48t2IhVFnmy,title,count in items:
		title = wAmsc95ya0LHz(title)
		title = title.strip(YvOQBzaTAscXR9ql)
		if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
		BF0Ns1WhLkzuxj8rOGpdAPfYE9c = Zy2l0g8QU5vqefaTrsw.findall('cat=(.*?)&',ZgsbN5iSL48t2IhVFnmy,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
		if y3LbIjrZvcATpNDM==BF0Ns1WhLkzuxj8rOGpdAPfYE9c: uOkSbCsqfDl7vBIM6cYa1th0NVzZ = True
		elif uOkSbCsqfDl7vBIM6cYa1th0NVzZ 	or (y3LbIjrZvcATpNDM=='-1' and BF0Ns1WhLkzuxj8rOGpdAPfYE9c in qbl8JdafGOc6I)  						or (y3LbIjrZvcATpNDM=='-2' and BF0Ns1WhLkzuxj8rOGpdAPfYE9c not in fGycOdqoM6RSuK0szlB and BF0Ns1WhLkzuxj8rOGpdAPfYE9c not in qbl8JdafGOc6I)  						or (y3LbIjrZvcATpNDM=='-3' and BF0Ns1WhLkzuxj8rOGpdAPfYE9c in fGycOdqoM6RSuK0szlB):
							if count=='1': khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,63)
							else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,61,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,BF0Ns1WhLkzuxj8rOGpdAPfYE9c)
							jXqW0t7CZSn2dshG8E1HrlUu = True
	if not jXqW0t7CZSn2dshG8E1HrlUu: j9zTQsrVRx2(url)
	return
def j9zTQsrVRx2(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,True,'ALFATIMI-EPISODES-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('pagination(.*?)id="footer',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ZgsbN5iSL48t2IhVFnmy = CJlTSEpZsWb0QHg5w
	for hzGKUP1XjAoeT79MJcDF,title,ZgsbN5iSL48t2IhVFnmy in items:
		title = title.replace('Add',CJlTSEpZsWb0QHg5w).replace('to Quicklist',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,63,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('(.*?)div',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys=s67485upzYNMS3PqDelkrdfo[0]
	D3D6TF50oUBtJlvijPMW8ys=Zy2l0g8QU5vqefaTrsw.findall('pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	items=Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	BBwfuWGxUIrdCoc4ka7 = url.split('?')[0]
	for ZgsbN5iSL48t2IhVFnmy,FqVRbwzuN5yhPJSsQE6n in items:
		ZgsbN5iSL48t2IhVFnmy = BBwfuWGxUIrdCoc4ka7 + ZgsbN5iSL48t2IhVFnmy
		title = wAmsc95ya0LHz(FqVRbwzuN5yhPJSsQE6n)
		title = 'صفحة ' + title
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,62)
	return ZgsbN5iSL48t2IhVFnmy
def rHwfOZb3oSgJKi(url):
	if 'videos.php' in url: url = j9zTQsrVRx2(url)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,True,'ALFATIMI-PLAY-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('playlistfile:"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	ZQtv0jY9W6L8UHgpnKm(url,T1QDsJlUtCGhn,'video')
	return
def P4VUMDrZ9o7zuNaBbCxd6Oji1tlvW3(y3LbIjrZvcATpNDM):
	wSfEHOilLYIK = { 'mode' : y3LbIjrZvcATpNDM }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = Hc6rjXpgb3CZuVKYk(wSfEHOilLYIK)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
		title = title.strip(YvOQBzaTAscXR9ql)
		if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,63,hzGKUP1XjAoeT79MJcDF)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo + '/search_result.php?query=' + QjfknOVHzZIUir
	j9zTQsrVRx2(url)
	return
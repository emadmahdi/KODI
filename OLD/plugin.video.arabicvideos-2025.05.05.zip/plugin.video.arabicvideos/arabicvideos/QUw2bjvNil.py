﻿# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
def hH3sRBSFAr(BEUVvSQtRimC,TBW2jhqNQY8i):
	if TBW2jhqNQY8i==CJlTSEpZsWb0QHg5w: return
	if BEUVvSQtRimC==1:
		zq8L6QblRWZmTvgPnXcF = rTF8V7fLD2SXJbAURpZjQ4wH.getCurrentWindowDialogId()
		Bw7JWegm1qSoh8iK5D492GtyA = rTF8V7fLD2SXJbAURpZjQ4wH.Window(zq8L6QblRWZmTvgPnXcF)
		TBW2jhqNQY8i = CqvfpVUrZNTzdiXKnx69Q2m7L8AuF(TBW2jhqNQY8i)
		Bw7JWegm1qSoh8iK5D492GtyA.getControl(311).setLabel(TBW2jhqNQY8i)
	if BEUVvSQtRimC==0:
		kcxAmftieK56PE9TqbDHdSrF8='X'
		if A7Z6OVh20eCEUx: voKMEtW17cbI3NxdSq2 = isinstance(TBW2jhqNQY8i,str)
		else: voKMEtW17cbI3NxdSq2 = isinstance(TBW2jhqNQY8i,unicode)
		if voKMEtW17cbI3NxdSq2==True: kcxAmftieK56PE9TqbDHdSrF8='U'
		jvDkzZHBGaY3r1uh62mARJKf=str(type(TBW2jhqNQY8i))+YvOQBzaTAscXR9ql+TBW2jhqNQY8i+YvOQBzaTAscXR9ql+kcxAmftieK56PE9TqbDHdSrF8+YvOQBzaTAscXR9ql
		for PMTRpXQvDIkiNszwYGnb32a in range(0,len(TBW2jhqNQY8i),1):
			jvDkzZHBGaY3r1uh62mARJKf += hex(ord(TBW2jhqNQY8i[PMTRpXQvDIkiNszwYGnb32a])).replace('0x',CJlTSEpZsWb0QHg5w)+YvOQBzaTAscXR9ql
		TBW2jhqNQY8i = CqvfpVUrZNTzdiXKnx69Q2m7L8AuF(TBW2jhqNQY8i)
		kcxAmftieK56PE9TqbDHdSrF8='X'
		if A7Z6OVh20eCEUx: voKMEtW17cbI3NxdSq2 = isinstance(TBW2jhqNQY8i, str)
		else: voKMEtW17cbI3NxdSq2 = isinstance(TBW2jhqNQY8i, unicode)
		if voKMEtW17cbI3NxdSq2==True: kcxAmftieK56PE9TqbDHdSrF8='U'
		eMsPjvoR3tri5DKgkYOqULmZ=str(type(TBW2jhqNQY8i))+YvOQBzaTAscXR9ql+TBW2jhqNQY8i+YvOQBzaTAscXR9ql+kcxAmftieK56PE9TqbDHdSrF8+YvOQBzaTAscXR9ql
		for PMTRpXQvDIkiNszwYGnb32a in range(0,len(TBW2jhqNQY8i),1):
			eMsPjvoR3tri5DKgkYOqULmZ += hex(ord(TBW2jhqNQY8i[PMTRpXQvDIkiNszwYGnb32a])).replace('0x',CJlTSEpZsWb0QHg5w)+YvOQBzaTAscXR9ql
	return
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'KATKOTTV'
kL0nT7NpZdKVD3jM2OHB = '_KTV_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = []
def hH3sRBSFAr(mode,url,text):
	if   mode==810: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==811: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==812: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==813: SD0TxMRXiep4cjPBsnzI = KrDZxq4duabWHcmkS0LyVRe7zTUXl(url)
	elif mode==819: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'KATKOTTV-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,819,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"primary-links"(.*?)"most-viewed"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,811)
	return
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'KATKOTTV-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"home-content"(.*?)"footer"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"thumb".*?data-src="(.*?)".*?href="(.*?)".*?title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		wDkMP6jlz7XeN5Sp = []
		for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة).\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if 'episodes' not in type and ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0][0]
				title = title.replace('اون لاين',CJlTSEpZsWb0QHg5w)
				if title not in wDkMP6jlz7XeN5Sp:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,813,hzGKUP1XjAoeT79MJcDF)
					wDkMP6jlz7XeN5Sp.append(title)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,812,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("'pagination'(.*?)footer",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,811,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	return
def KrDZxq4duabWHcmkS0LyVRe7zTUXl(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'KATKOTTV-SERIES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"category".*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy: nvHUf8mW6E4GSw5VFRXN(ZgsbN5iSL48t2IhVFnmy[0],'episodes')
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ = []
	BBwfuWGxUIrdCoc4ka7 = url+'?do=watch'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'KATKOTTV-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('" src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	else:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'KATKOTTV-PLAY-2nd')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		HGXYPrKegtmb2zE3aqTxiF = Zy2l0g8QU5vqefaTrsw.findall('post=(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if HGXYPrKegtmb2zE3aqTxiF:
			HGXYPrKegtmb2zE3aqTxiF = qqth6cAFkaRowLlUeMng.b64decode(HGXYPrKegtmb2zE3aqTxiF[0])
			if A7Z6OVh20eCEUx: HGXYPrKegtmb2zE3aqTxiF = HGXYPrKegtmb2zE3aqTxiF.decode(Im5KSGZYBpRvdMVsbuXg)
			HGXYPrKegtmb2zE3aqTxiF = oE7iT3HI5VDdmY4kPOjr('dict',HGXYPrKegtmb2zE3aqTxiF)
			Rp1g7OlotseGnf0NFmKk6rLxd = HGXYPrKegtmb2zE3aqTxiF['servers']
			RYHIKeQZLBpbNvmhkq2GV1C = list(Rp1g7OlotseGnf0NFmKk6rLxd.keys())
			Rp1g7OlotseGnf0NFmKk6rLxd = list(Rp1g7OlotseGnf0NFmKk6rLxd.values())
			xxMT4HEkmJgz = zip(RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd)
			for title,ZgsbN5iSL48t2IhVFnmy in xxMT4HEkmJgz:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'GLOBALSEARCH'
kL0nT7NpZdKVD3jM2OHB = '_GLS_'
def hH3sRBSFAr(BEUVvSQtRimC,pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T,GOF25jkXb1DnaB4vhL9):
	if   BEUVvSQtRimC==540: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif BEUVvSQtRimC==541: SD0TxMRXiep4cjPBsnzI = mgeNy4wQUOIWdAu3bGs82Z79(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==542: SD0TxMRXiep4cjPBsnzI = ytq8cZJF3m1V6B4a(FMxeyLvnzabpJhCXgS6T,pkNZlmhUSwtXgriJHjT59MV1QqK,GOF25jkXb1DnaB4vhL9)
	elif BEUVvSQtRimC==543: SD0TxMRXiep4cjPBsnzI = fTHvn3K1s8LxV76EM()
	elif BEUVvSQtRimC==548: SD0TxMRXiep4cjPBsnzI = ROwc1ob7nj0u(pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==549: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(FMxeyLvnzabpJhCXgS6T)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','بحث جديد لجميع المواقع',CJlTSEpZsWb0QHg5w,549)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link','كيف يعمل بحث جميع المواقع','',543)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'==== كلمات البحث المخزنة ===='+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	L8Q1Xdx6gial = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if L8Q1Xdx6gial:
		L8Q1Xdx6gial = L8Q1Xdx6gial['__SEQUENCED_COLUMNS__']
		for CmcJgXf24nBp5IeSdvt9xZAbjHEi in reversed(L8Q1Xdx6gial):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',CmcJgXf24nBp5IeSdvt9xZAbjHEi,CJlTSEpZsWb0QHg5w,549,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CmcJgXf24nBp5IeSdvt9xZAbjHEi)
	return
def HYGiJ9pfmMTnIb4L7tX(CmcJgXf24nBp5IeSdvt9xZAbjHEi):
	if not CmcJgXf24nBp5IeSdvt9xZAbjHEi:
		CmcJgXf24nBp5IeSdvt9xZAbjHEi = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not CmcJgXf24nBp5IeSdvt9xZAbjHEi: return
		CmcJgXf24nBp5IeSdvt9xZAbjHEi = CmcJgXf24nBp5IeSdvt9xZAbjHEi.lower()
	lrpUStmO67zg = CmcJgXf24nBp5IeSdvt9xZAbjHEi.replace(kL0nT7NpZdKVD3jM2OHB,CJlTSEpZsWb0QHg5w)
	kOvL14bgf2ShtoCpVPlAKiz9yuTxU3(lrpUStmO67zg,'_ALL',True)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link','بحث جماعي للمواقع - '+lrpUStmO67zg,'search_sites_all',542,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','بحث منفرد للمواقع - '+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,541,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','نتائج البحث مفصلة - '+lrpUStmO67zg,'opened_sites_all',542,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','نتائج البحث مقسمة - '+lrpUStmO67zg,'listed_sites_all',542,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	return
def kOvL14bgf2ShtoCpVPlAKiz9yuTxU3(RQETJZgfusx,NgmUk75LCT,IDtUKr46o9u1iWgYHR3QlF0jeCXm):
	if NgmUk75LCT=='_ALL': dIXT1xewkp0tUKVC4MP = '_GLS_'
	elif NgmUk75LCT=='_GOOGLE': dIXT1xewkp0tUKVC4MP = '_GOS_'
	TshPeCl3SHqxgbW5 = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_SPLITTED'+NgmUk75LCT,RQETJZgfusx)
	md0CiQXzISOJw4TBukAHU5hb = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_SPLITTED'+NgmUk75LCT,dIXT1xewkp0tUKVC4MP+RQETJZgfusx)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_SPLITTED'+NgmUk75LCT,RQETJZgfusx)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_SPLITTED'+NgmUk75LCT,dIXT1xewkp0tUKVC4MP+RQETJZgfusx)
	vNQSXrsT2KFAfJaCVE = TshPeCl3SHqxgbW5+md0CiQXzISOJw4TBukAHU5hb
	if vNQSXrsT2KFAfJaCVE and IDtUKr46o9u1iWgYHR3QlF0jeCXm: RQETJZgfusx = dIXT1xewkp0tUKVC4MP+RQETJZgfusx
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_SPLITTED'+NgmUk75LCT,RQETJZgfusx,vNQSXrsT2KFAfJaCVE,taSwGoeiz7mv)
	return
def eeSzyvE3rp2YHUsi(NgmUk75LCT):
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=1: return
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_SPLITTED'+NgmUk75LCT)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_DETAILED'+NgmUk75LCT)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_DIVIDED'+NgmUk75LCT)
	if NgmUk75LCT=='_GOOGLE': oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GOOGLESEARCH_RESULTS')
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def ytq8cZJF3m1V6B4a(B1UFhj70X5,wZGSJADTp1u7RrelOCnikHPy0xf,kkOJyjmSrYFIvopU=CJlTSEpZsWb0QHg5w,ntrPz2UMHvg=GzM4fSLbdKhkCTHX01ORYFq9W3P,YZMghwJpbViUm9kjrof82={}):
	kgdu1w3t0xQ2qhLP8R6fNWiZG,PUXf9ZM1lThS8m2HoLVeO3,xxp5EgcKl49b6nfO,mob478yIE9PeDzT6ritKU0,NbgXUDGYoZ3JrQFtn = [],{},{},{},{}
	if '_all' in wZGSJADTp1u7RrelOCnikHPy0xf: NgmUk75LCT,lRbNd90mLMt,dIXT1xewkp0tUKVC4MP = '_ALL','_all','_GLS_'
	elif '_google' in wZGSJADTp1u7RrelOCnikHPy0xf: NgmUk75LCT,lRbNd90mLMt,dIXT1xewkp0tUKVC4MP = '_GOOGLE','_google','_GOS_'
	if wZGSJADTp1u7RrelOCnikHPy0xf in ['listed_sites'+lRbNd90mLMt,'opened_sites'+lRbNd90mLMt,'closed_sites'+lRbNd90mLMt]:
		if wZGSJADTp1u7RrelOCnikHPy0xf=='listed_sites'+lRbNd90mLMt: kgdu1w3t0xQ2qhLP8R6fNWiZG = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_SPLITTED'+NgmUk75LCT,dIXT1xewkp0tUKVC4MP+B1UFhj70X5)
		elif wZGSJADTp1u7RrelOCnikHPy0xf=='opened_sites'+lRbNd90mLMt: kgdu1w3t0xQ2qhLP8R6fNWiZG = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_DETAILED'+NgmUk75LCT,B1UFhj70X5)
		elif wZGSJADTp1u7RrelOCnikHPy0xf=='closed_sites'+lRbNd90mLMt: kgdu1w3t0xQ2qhLP8R6fNWiZG = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_DIVIDED'+NgmUk75LCT,(kkOJyjmSrYFIvopU,B1UFhj70X5))
	if not kgdu1w3t0xQ2qhLP8R6fNWiZG:
		sdGflAoZBxPURVuF = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		gEqOeRhimXy7rDZ4IH0 = 'هل تريد الآن البحث في جميع المواقع عن \n "'+Ym6q5M4TocDaA013RjFQ+YvOQBzaTAscXR9ql+B1UFhj70X5+YvOQBzaTAscXR9ql+oOQaRxBXyJ5jVnZ+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if wZGSJADTp1u7RrelOCnikHPy0xf=='search_sites'+lRbNd90mLMt: LLyhViKbxMntl5JSk = gEqOeRhimXy7rDZ4IH0
		else: LLyhViKbxMntl5JSk = sdGflAoZBxPURVuF+gEqOeRhimXy7rDZ4IH0
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=1: return
		BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY)
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+'   Search For: [ '+B1UFhj70X5+' ]')
		tXoA9WdJ8DjV3vsC64LxubkH = 1
		for ad3z2451e09FrDHmvci in ntrPz2UMHvg:
			rGcAizy2a9ZvsRBYgHjh35FKIDeq = YZMghwJpbViUm9kjrof82[ad3z2451e09FrDHmvci] if YZMghwJpbViUm9kjrof82 else B1UFhj70X5
			try: jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
			except: continue
			PUXf9ZM1lThS8m2HoLVeO3[ad3z2451e09FrDHmvci] = []
			gKL8iaPh9sTzdx7ANOfVpbRrcHGkU = '_NODIALOGS_'
			if '-' in ad3z2451e09FrDHmvci: gKL8iaPh9sTzdx7ANOfVpbRrcHGkU = gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+'_REMEMBERRESULTS__'+ad3z2451e09FrDHmvci+'_'
			if tXoA9WdJ8DjV3vsC64LxubkH:
				L8Wkv5KCSoq.sleep(0.75)
				NbgXUDGYoZ3JrQFtn[ad3z2451e09FrDHmvci] = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=x3L5fIUkM6czApTHVJtoWN8b4i,args=(rGcAizy2a9ZvsRBYgHjh35FKIDeq+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,))
				NbgXUDGYoZ3JrQFtn[ad3z2451e09FrDHmvci].start()
			else: x3L5fIUkM6czApTHVJtoWN8b4i(rGcAizy2a9ZvsRBYgHjh35FKIDeq+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
			KhwN2zcb7iMkjS5E4WURxByPGon(HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci),CJlTSEpZsWb0QHg5w,L8Wkv5KCSoq=1000)
		if tXoA9WdJ8DjV3vsC64LxubkH:
			L8Wkv5KCSoq.sleep(2)
			for ad3z2451e09FrDHmvci in ntrPz2UMHvg: NbgXUDGYoZ3JrQFtn[ad3z2451e09FrDHmvci].join(10)
			L8Wkv5KCSoq.sleep(2)
		for ad3z2451e09FrDHmvci in ntrPz2UMHvg:
			try: jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
			except: continue
			for LLGOIVqdTpZAFRgvQ0ChPc in Ew2zQ8u7Ss.menuItemsLIST:
				nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = LLGOIVqdTpZAFRgvQ0ChPc
				if FTbIBSC3OLPvyaZjqK7 in idaKcvOmbRrkW1CtHhZfeAJQV4D:
					if 'IPTV-' in ad3z2451e09FrDHmvci and (239>=BEUVvSQtRimC>=230 or 289>=BEUVvSQtRimC>=280):
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['IPTV-LIVE']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['IPTV-MOVIES']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['IPTV-SERIES']: continue
						if 'صفحة' not in idaKcvOmbRrkW1CtHhZfeAJQV4D:
							if   nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='live': ad3z2451e09FrDHmvci = 'IPTV-LIVE'
							elif nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video': ad3z2451e09FrDHmvci = 'IPTV-MOVIES'
							elif nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder': ad3z2451e09FrDHmvci = 'IPTV-SERIES'
						else:
							if   'LIVE' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'IPTV-LIVE'
							elif 'MOVIES' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'IPTV-MOVIES'
							elif 'SERIES' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'IPTV-SERIES'
					elif 'M3U-' in ad3z2451e09FrDHmvci and 729>=BEUVvSQtRimC>=710:
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['M3U-LIVE']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['M3U-MOVIES']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['M3U-SERIES']: continue
						if 'صفحة' not in idaKcvOmbRrkW1CtHhZfeAJQV4D:
							if   nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='live': ad3z2451e09FrDHmvci = 'M3U-LIVE'
							elif nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video': ad3z2451e09FrDHmvci = 'M3U-MOVIES'
							elif nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder': ad3z2451e09FrDHmvci = 'M3U-SERIES'
						else:
							if   'LIVE' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'M3U-LIVE'
							elif 'MOVIES' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'M3U-MOVIES'
							elif 'SERIES' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'M3U-SERIES'
					elif 'YOUTUBE-' in ad3z2451e09FrDHmvci and 149>=BEUVvSQtRimC>=140:
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['YOUTUBE-CHANNELS']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['YOUTUBE-PLAYLISTS']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in idaKcvOmbRrkW1CtHhZfeAJQV4D or ':: ' in idaKcvOmbRrkW1CtHhZfeAJQV4D:
							continue
						else:
							if   BEUVvSQtRimC==144 and 'USER' in idaKcvOmbRrkW1CtHhZfeAJQV4D: ad3z2451e09FrDHmvci = 'YOUTUBE-CHANNELS'
							elif BEUVvSQtRimC==144 and 'CHNL' in idaKcvOmbRrkW1CtHhZfeAJQV4D: ad3z2451e09FrDHmvci = 'YOUTUBE-CHANNELS'
							elif BEUVvSQtRimC==144 and 'LIST' in idaKcvOmbRrkW1CtHhZfeAJQV4D: ad3z2451e09FrDHmvci = 'YOUTUBE-PLAYLISTS'
							elif BEUVvSQtRimC==143: ad3z2451e09FrDHmvci = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in ad3z2451e09FrDHmvci and 419>=BEUVvSQtRimC>=400:
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['DAILYMOTION-PLAYLISTS']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['DAILYMOTION-CHANNELS']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['DAILYMOTION-VIDEOS']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['DAILYMOTION-LIVES']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['DAILYMOTION-HASHTAGS']: continue
						if   BEUVvSQtRimC in [401,405]: ad3z2451e09FrDHmvci = 'DAILYMOTION-PLAYLISTS'
						elif BEUVvSQtRimC in [402,406]: ad3z2451e09FrDHmvci = 'DAILYMOTION-CHANNELS'
						elif BEUVvSQtRimC in [404]: ad3z2451e09FrDHmvci = 'DAILYMOTION-VIDEOS'
						elif BEUVvSQtRimC in [415]: ad3z2451e09FrDHmvci = 'DAILYMOTION-LIVES'
						elif BEUVvSQtRimC in [416]: ad3z2451e09FrDHmvci = 'DAILYMOTION-HASHTAGS'
					elif 'PANET-' in ad3z2451e09FrDHmvci and 39>=BEUVvSQtRimC>=30:
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['PANET-SERIES']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['PANET-MOVIES']: continue
						if   BEUVvSQtRimC in [32,39]: ad3z2451e09FrDHmvci = 'PANET-SERIES'
						elif BEUVvSQtRimC in [33,39]: ad3z2451e09FrDHmvci = 'PANET-MOVIES'
					elif 'IFILM-' in ad3z2451e09FrDHmvci and 29>=BEUVvSQtRimC>=20:
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['IFILM-ARABIC']: continue
						if LLGOIVqdTpZAFRgvQ0ChPc in PUXf9ZM1lThS8m2HoLVeO3['IFILM-ENGLISH']: continue
						if   '/ar.' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'IFILM-ARABIC'
						elif '/en.' in pkNZlmhUSwtXgriJHjT59MV1QqK: ad3z2451e09FrDHmvci = 'IFILM-ENGLISH'
					PUXf9ZM1lThS8m2HoLVeO3[ad3z2451e09FrDHmvci].append(LLGOIVqdTpZAFRgvQ0ChPc)
		for ad3z2451e09FrDHmvci in list(PUXf9ZM1lThS8m2HoLVeO3.keys()):
			xxp5EgcKl49b6nfO[ad3z2451e09FrDHmvci] = []
			mob478yIE9PeDzT6ritKU0[ad3z2451e09FrDHmvci] = []
			for nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in PUXf9ZM1lThS8m2HoLVeO3[ad3z2451e09FrDHmvci]:
				LLGOIVqdTpZAFRgvQ0ChPc = (nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
				if 'صفحة' in idaKcvOmbRrkW1CtHhZfeAJQV4D and nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder': mob478yIE9PeDzT6ritKU0[ad3z2451e09FrDHmvci].append(LLGOIVqdTpZAFRgvQ0ChPc)
				else: xxp5EgcKl49b6nfO[ad3z2451e09FrDHmvci].append(LLGOIVqdTpZAFRgvQ0ChPc)
		AARyWv018IdMpZTPJUrLtY5b,s4r8vZgD0yjm75HP3bKVFiktqC6uN = [],[]
		NqYfA9CbvJsZyL = list(xxp5EgcKl49b6nfO.keys())
		QBxaTRrmMjF9ptn = KQI8YgWzhmCV4T(NqYfA9CbvJsZyL)
		CCdnrIfkXLesuyj5bgxWlcq = []
		for ad3z2451e09FrDHmvci in QBxaTRrmMjF9ptn:
			if isinstance(ad3z2451e09FrDHmvci,tuple):
				CCdnrIfkXLesuyj5bgxWlcq = [ad3z2451e09FrDHmvci]
				continue
			if ad3z2451e09FrDHmvci not in ntrPz2UMHvg: continue
			if xxp5EgcKl49b6nfO[ad3z2451e09FrDHmvci]:
				HbZN0vKoiP6GeTlg = HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci)
				zw3kO2WMoP8GNtuv4a9bCBRQyle = [('link',Ym6q5M4TocDaA013RjFQ+'===== '+HbZN0vKoiP6GeTlg+' ====='+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)]
				if 0: ZgKJjRT4v7Onps = B1UFhj70X5+' - '+'بحث'+YvOQBzaTAscXR9ql+HbZN0vKoiP6GeTlg
				else: ZgKJjRT4v7Onps = 'بحث'+YvOQBzaTAscXR9ql+HbZN0vKoiP6GeTlg+' - '+B1UFhj70X5
				if len(xxp5EgcKl49b6nfO[ad3z2451e09FrDHmvci])<8: eedVvK4hEy5XRoQcr7 = []
				else:
					qPHOed13KwFYxQNa0yh = Dj62UpP5MrbTkJqhRa+ZgKJjRT4v7Onps+oOQaRxBXyJ5jVnZ
					eedVvK4hEy5XRoQcr7 = [('folder',dIXT1xewkp0tUKVC4MP+qPHOed13KwFYxQNa0yh,'closed_sites'+lRbNd90mLMt,542,CJlTSEpZsWb0QHg5w,ad3z2451e09FrDHmvci,B1UFhj70X5,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)]
				BoQPGitw1qF2ljeW9 = xxp5EgcKl49b6nfO[ad3z2451e09FrDHmvci]+mob478yIE9PeDzT6ritKU0[ad3z2451e09FrDHmvci]
				f6uU37GtPA82wZDiFl = CCdnrIfkXLesuyj5bgxWlcq+zw3kO2WMoP8GNtuv4a9bCBRQyle+BoQPGitw1qF2ljeW9[:7]+eedVvK4hEy5XRoQcr7
				AARyWv018IdMpZTPJUrLtY5b += f6uU37GtPA82wZDiFl
				TAj2sbzJ5dCof7iWMp3NwvZSuhr = [('folder',dIXT1xewkp0tUKVC4MP+ZgKJjRT4v7Onps,'closed_sites'+lRbNd90mLMt,542,CJlTSEpZsWb0QHg5w,ad3z2451e09FrDHmvci,B1UFhj70X5,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)]
				wWfzFZqjpe = CCdnrIfkXLesuyj5bgxWlcq+TAj2sbzJ5dCof7iWMp3NwvZSuhr
				s4r8vZgD0yjm75HP3bKVFiktqC6uN += wWfzFZqjpe
				JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_DIVIDED'+NgmUk75LCT,(ad3z2451e09FrDHmvci,B1UFhj70X5),BoQPGitw1qF2ljeW9,taSwGoeiz7mv)
				CCdnrIfkXLesuyj5bgxWlcq = []
		JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_DETAILED'+NgmUk75LCT,B1UFhj70X5,AARyWv018IdMpZTPJUrLtY5b,taSwGoeiz7mv)
		oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_SPLITTED'+NgmUk75LCT,B1UFhj70X5)
		JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_SPLITTED'+NgmUk75LCT,dIXT1xewkp0tUKVC4MP+B1UFhj70X5,s4r8vZgD0yjm75HP3bKVFiktqC6uN,taSwGoeiz7mv)
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم حتى تستطيع العودة إليها بدون عمل بحث جديد')
		kgdu1w3t0xQ2qhLP8R6fNWiZG = s4r8vZgD0yjm75HP3bKVFiktqC6uN if wZGSJADTp1u7RrelOCnikHPy0xf=='listed_sites'+lRbNd90mLMt and s4r8vZgD0yjm75HP3bKVFiktqC6uN else AARyWv018IdMpZTPJUrLtY5b
	if wZGSJADTp1u7RrelOCnikHPy0xf in ['listed_sites'+lRbNd90mLMt,'opened_sites'+lRbNd90mLMt,'closed_sites'+lRbNd90mLMt]:
		for nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in kgdu1w3t0xQ2qhLP8R6fNWiZG:
			if wZGSJADTp1u7RrelOCnikHPy0xf in ['listed_sites'+lRbNd90mLMt,'opened_sites'+lRbNd90mLMt] and 'صفحة' in idaKcvOmbRrkW1CtHhZfeAJQV4D and nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder': continue
			khqge7BVD9jPFy1S8T5Gn4QAlH(nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E)
	return
def mgeNy4wQUOIWdAu3bGs82Z79(search):
	QBxaTRrmMjF9ptn = KQI8YgWzhmCV4T(wt8VeLoQTG2A49pSNF5)
	for ad3z2451e09FrDHmvci in QBxaTRrmMjF9ptn:
		if '-' in ad3z2451e09FrDHmvci: continue
		if isinstance(ad3z2451e09FrDHmvci,tuple):
			Ew2zQ8u7Ss.menuItemsLIST.append(ad3z2451e09FrDHmvci)
			continue
		jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
		name = HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci)+' - '+search
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',FTbIBSC3OLPvyaZjqK7+name,ad3z2451e09FrDHmvci,548,'','',search)
	return
def ROwc1ob7nj0u(ad3z2451e09FrDHmvci,search):
	jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
	x3L5fIUkM6czApTHVJtoWN8b4i(search)
	return
def fTHvn3K1s8LxV76EM():
	PIUzVg8uwmHlMKO5Lk6oxAZ('','',TAExSfcoNi4eORZ8HPB,'هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def Glo3jHx29h6WNT(B1UFhj70X5=CJlTSEpZsWb0QHg5w):
	CmcJgXf24nBp5IeSdvt9xZAbjHEi,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(B1UFhj70X5)
	if not CmcJgXf24nBp5IeSdvt9xZAbjHEi:
		CmcJgXf24nBp5IeSdvt9xZAbjHEi = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not CmcJgXf24nBp5IeSdvt9xZAbjHEi: return
		CmcJgXf24nBp5IeSdvt9xZAbjHEi = CmcJgXf24nBp5IeSdvt9xZAbjHEi.lower()
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+'   Search For: [ '+CmcJgXf24nBp5IeSdvt9xZAbjHEi+' ]')
	QjfknOVHzZIUir = CmcJgXf24nBp5IeSdvt9xZAbjHEi+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU
	if 0: yoB0zYNiHpGAJV6T2nmdKehf,lrpUStmO67zg = CmcJgXf24nBp5IeSdvt9xZAbjHEi+' - ',CJlTSEpZsWb0QHg5w
	else: yoB0zYNiHpGAJV6T2nmdKehf,lrpUStmO67zg = CJlTSEpZsWb0QHg5w,' - '+CmcJgXf24nBp5IeSdvt9xZAbjHEi
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'مواقع سيرفرات خاصة - قليلة المشاكل'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,157)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_M3U_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث M3U'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,719,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_IPT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث IPTV'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,239,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_BKR_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع بكرا'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,379,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_ART_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع تونز عربية'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,739,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_KRB_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع قناة كربلاء'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,329,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FH2_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فاصل الثاني'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,599,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_KTV_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع كتكوت تيفي'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,819,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_EB1_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع ايجي بيست 1'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,779,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_EB2_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع ايجي بيست 2'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,789,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_IFL_'+yoB0zYNiHpGAJV6T2nmdKehf+'  بحث موقع قناة آي فيلم'+lrpUStmO67zg+gCc52XVMGfAnOe,CJlTSEpZsWb0QHg5w,29,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_AKO_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع أكوام القديم'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,79,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_AKW_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع أكوام الجديد'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,249,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_MRF_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع قناة المعارف'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,49,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SHM_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع شوف ماكس'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,59,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,157)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_LRZ_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع لاروزا'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,709,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FJS_'+yoB0zYNiHpGAJV6T2nmdKehf+' بحث موقع فجر شو'+lrpUStmO67zg+YvOQBzaTAscXR9ql,CJlTSEpZsWb0QHg5w,399,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TVF_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع تيفي فان'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,469,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_LDN_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع لودي نت'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,459,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_CMN_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما ناو'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,309,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SHN_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع شاهد نيوز'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,589,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir+'_NODIALOGS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_ARS_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع عرب سييد'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,259,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_CCB_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما كلوب'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,829,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SH4_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع شاهد فوريو'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,119,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir+'_NODIALOGS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SHT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع شوفها تيفي'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,649,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_WC1_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع وي سيما 1'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,569,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_WC2_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع وي سيما 2'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,1009,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'مواقع سيرفرات عامة - كثيرة المشاكل'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,157)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TKT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع تكات'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,949,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FST_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فوستا'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,609,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FBK_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فبركة'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,629,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_YQT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع ياقوت'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,669,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SHB_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع شبكتي'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,969,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_VRB_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فاربون'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,879,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_BRS_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع برستيج'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,659,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_KRM_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع كرمالك'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,929,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_ANZ_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع انمي زد'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,979,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FSK_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فارسكو'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,999,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_HLC_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع هلا سيما'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,89,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_MST_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع المصطبة'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,869,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SNT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع شوف نت'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,849,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_DR7_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع دراما صح'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,689,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_CFR_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما فري'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,839,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_CMF_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما فانز'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,99,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_CML_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما لايت'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,479,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_C4H_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما 400'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,699,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_ABD_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما عبدو'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,559,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_AKT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع اكوام تيوب'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,859,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_DCF_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع دراما كافيه'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,939,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FTV_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فوشار تيفي'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,919,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_CWB_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما وبس'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,989,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_AHK_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع أهواك تيفي'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,619,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_SRT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيريس تايم'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,899,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_FVD_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع فوشار فيديو'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,909,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_C4P_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع سيما فور بي'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,889,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_EB4_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع ايجي بيست 4'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,809,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'مواقع سيرفرات خاصة - قليلة المشاكل'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,157)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_YUT_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع يوتيوب'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,149,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_DLM_'+yoB0zYNiHpGAJV6T2nmdKehf+'بحث موقع دايلي موشن'+lrpUStmO67zg,CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,QjfknOVHzZIUir)
	return
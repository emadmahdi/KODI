# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'GOOGLESEARCH'
kL0nT7NpZdKVD3jM2OHB = '_GOS_'
def hH3sRBSFAr(BEUVvSQtRimC,pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T):
	if   BEUVvSQtRimC==1010: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif BEUVvSQtRimC==1011: SD0TxMRXiep4cjPBsnzI = JNaciTL48HdfsmEv(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==1012: SD0TxMRXiep4cjPBsnzI = Eje6MUCHgsGxcryA39DLkWtIhuz(pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==1013: SD0TxMRXiep4cjPBsnzI = fTHvn3K1s8LxV76EM()
	elif BEUVvSQtRimC==1014: SD0TxMRXiep4cjPBsnzI = udckD8r5RP(pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==1015: SD0TxMRXiep4cjPBsnzI = Ykf1uzemD8p(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==1016: SD0TxMRXiep4cjPBsnzI = ezQOWpZIxiVHfhckYu(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==1018: SD0TxMRXiep4cjPBsnzI = rA4dJL5Hmxzp89qtvSgfOEM(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==1019: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(FMxeyLvnzabpJhCXgS6T,False)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','بحث جوجل جديد',CJlTSEpZsWb0QHg5w,1019)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link','كيف يعمل بحث جوجل','',1013)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'==== كلمات البحث المخزنة ===='+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	L8Q1Xdx6gial = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if L8Q1Xdx6gial:
		L8Q1Xdx6gial = L8Q1Xdx6gial['__SEQUENCED_COLUMNS__']
		for CmcJgXf24nBp5IeSdvt9xZAbjHEi in reversed(L8Q1Xdx6gial):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',CmcJgXf24nBp5IeSdvt9xZAbjHEi,CJlTSEpZsWb0QHg5w,1019,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CmcJgXf24nBp5IeSdvt9xZAbjHEi)
	return
def rA4dJL5Hmxzp89qtvSgfOEM(search):
	HYGiJ9pfmMTnIb4L7tX(search,True)
	nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def HYGiJ9pfmMTnIb4L7tX(search,JZIa1wEWt8g9QYmRvzBGfX0jLiPc=False):
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	lrpUStmO67zg = search.replace(kL0nT7NpZdKVD3jM2OHB,CJlTSEpZsWb0QHg5w).lower()
	RfZKdSruM2xb7i6sQ03ckO4EG,RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = [],[],[]
	if not JZIa1wEWt8g9QYmRvzBGfX0jLiPc:
		RfZKdSruM2xb7i6sQ03ckO4EG = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GOOGLESEARCH_RESULTS',lrpUStmO67zg)
		if RfZKdSruM2xb7i6sQ03ckO4EG: RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = RfZKdSruM2xb7i6sQ03ckO4EG
	if JZIa1wEWt8g9QYmRvzBGfX0jLiPc or not RfZKdSruM2xb7i6sQ03ckO4EG:
		import KxIcVHk2jg
		KxIcVHk2jg.kOvL14bgf2ShtoCpVPlAKiz9yuTxU3(lrpUStmO67zg,'_GOOGLE',True)
		nLFxHT1YEWwlG06cX = nQG3rOlxULDw6bV(lrpUStmO67zg)
		for jglfWFcvo1mAdH9yeROS7XKNxu in nLFxHT1YEWwlG06cX:
			name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci = jglfWFcvo1mAdH9yeROS7XKNxu
			if ad3z2451e09FrDHmvci in rBou7qEXe4GUPnYMp6Af9yh: RNrfLxmFc3hnjbkYoJevdWpDZilwAa.append(jglfWFcvo1mAdH9yeROS7XKNxu)
			else: MUY45RWF9x8Odrz13kb7.append(jglfWFcvo1mAdH9yeROS7XKNxu)
		RNrfLxmFc3hnjbkYoJevdWpDZilwAa = sorted(RNrfLxmFc3hnjbkYoJevdWpDZilwAa,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[ZVNvqy4iF1a9X])
		MUY45RWF9x8Odrz13kb7 = sorted(MUY45RWF9x8Odrz13kb7,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[ZVNvqy4iF1a9X])
		JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'GOOGLESEARCH_RESULTS',lrpUStmO67zg,[RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7],taSwGoeiz7mv)
		oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_DETAILED_GOOGLE',lrpUStmO67zg)
		KxIcVHk2jg.kOvL14bgf2ShtoCpVPlAKiz9yuTxU3(lrpUStmO67zg,'_GOOGLE',False)
		oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+lrpUStmO67zg+"')")
		if RNrfLxmFc3hnjbkYoJevdWpDZilwAa: PIUzVg8uwmHlMKO5Lk6oxAZ('','',TAExSfcoNi4eORZ8HPB,'تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(RNrfLxmFc3hnjbkYoJevdWpDZilwAa))+'  مواقع')
		else: RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = qmKf3AUceanW2irMOELJQyTIRN170(lrpUStmO67zg,VJZIMkUN5siqB21Pf)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','بحث منفرد لمواقع جوجل',CJlTSEpZsWb0QHg5w,1011,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','نتائج البحث مفصلة - '+lrpUStmO67zg,'opened_sites_google',1012,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','نتائج البحث مقسمة - '+lrpUStmO67zg,'listed_sites_google',1012,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','مواقع جوجل ('+str(len(RNrfLxmFc3hnjbkYoJevdWpDZilwAa))+') - '+lrpUStmO67zg,'',1016,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,lrpUStmO67zg)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link','إعادة بحث جوجل - '+lrpUStmO67zg,'',1018,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,search)
	return
def ezQOWpZIxiVHfhckYu(lrpUStmO67zg):
	RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = qmKf3AUceanW2irMOELJQyTIRN170(lrpUStmO67zg)
	if not RNrfLxmFc3hnjbkYoJevdWpDZilwAa and not MUY45RWF9x8Odrz13kb7: return
	S3cEyiBdeo01G = {}
	for name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci in RNrfLxmFc3hnjbkYoJevdWpDZilwAa: S3cEyiBdeo01G[ad3z2451e09FrDHmvci] = name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci
	NqYfA9CbvJsZyL = list(S3cEyiBdeo01G.keys())
	import KxIcVHk2jg
	QBxaTRrmMjF9ptn = KxIcVHk2jg.KQI8YgWzhmCV4T(NqYfA9CbvJsZyL)
	for ad3z2451e09FrDHmvci in QBxaTRrmMjF9ptn:
		if isinstance(ad3z2451e09FrDHmvci,tuple):
			Ew2zQ8u7Ss.menuItemsLIST.append(ad3z2451e09FrDHmvci)
			continue
		name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci = S3cEyiBdeo01G[ad3z2451e09FrDHmvci]
		jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',FTbIBSC3OLPvyaZjqK7+name,ZgsbN5iSL48t2IhVFnmy,1014,Aq2Dt8VYCWaBQGZN7XIvOR,'',ad3z2451e09FrDHmvci)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+'مواقع بجوجل غير موجودة بالبرنامج'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,1015)
	MUY45RWF9x8Odrz13kb7 = sorted(MUY45RWF9x8Odrz13kb7,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[ZVNvqy4iF1a9X])
	for name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci in MUY45RWF9x8Odrz13kb7:
		khqge7BVD9jPFy1S8T5Gn4QAlH('link','_GOS_'+name,ZgsbN5iSL48t2IhVFnmy,1015,Aq2Dt8VYCWaBQGZN7XIvOR,'',ad3z2451e09FrDHmvci)
	return
def qmKf3AUceanW2irMOELJQyTIRN170(lrpUStmO67zg,pP73fkt4xQrHBA6=w2qb6lf5EM):
	RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = [],[]
	if pP73fkt4xQrHBA6:
		RfZKdSruM2xb7i6sQ03ckO4EG = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GOOGLESEARCH_RESULTS',lrpUStmO67zg)
		if RfZKdSruM2xb7i6sQ03ckO4EG: RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = RfZKdSruM2xb7i6sQ03ckO4EG
	if not RNrfLxmFc3hnjbkYoJevdWpDZilwAa and not MUY45RWF9x8Odrz13kb7: PIUzVg8uwmHlMKO5Lk6oxAZ('','',TAExSfcoNi4eORZ8HPB,'للأسف جوجل لم يجد مواقع فيها طلبك')
	return RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7
def Eje6MUCHgsGxcryA39DLkWtIhuz(lRbNd90mLMt,lrpUStmO67zg):
	RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = qmKf3AUceanW2irMOELJQyTIRN170(lrpUStmO67zg)
	if not RNrfLxmFc3hnjbkYoJevdWpDZilwAa and not MUY45RWF9x8Odrz13kb7: return
	MsXDAp6TObWS,yJxfuWpICv0SLsbqZHicYmRtGFNX = [],{}
	for name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci in RNrfLxmFc3hnjbkYoJevdWpDZilwAa:
		MsXDAp6TObWS.append(ad3z2451e09FrDHmvci)
		yJxfuWpICv0SLsbqZHicYmRtGFNX[ad3z2451e09FrDHmvci] = oGYu4rKi2akMpCdXlZyS3(text)
	import KxIcVHk2jg
	KxIcVHk2jg.ytq8cZJF3m1V6B4a(lrpUStmO67zg,lRbNd90mLMt,CJlTSEpZsWb0QHg5w,MsXDAp6TObWS,yJxfuWpICv0SLsbqZHicYmRtGFNX)
	return
def JNaciTL48HdfsmEv(lrpUStmO67zg):
	RNrfLxmFc3hnjbkYoJevdWpDZilwAa,MUY45RWF9x8Odrz13kb7 = qmKf3AUceanW2irMOELJQyTIRN170(lrpUStmO67zg)
	if not RNrfLxmFc3hnjbkYoJevdWpDZilwAa and not MUY45RWF9x8Odrz13kb7: return
	S3cEyiBdeo01G = {}
	for name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci in RNrfLxmFc3hnjbkYoJevdWpDZilwAa:
		S3cEyiBdeo01G[ad3z2451e09FrDHmvci] = name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci
	NqYfA9CbvJsZyL = list(S3cEyiBdeo01G.keys())
	import KxIcVHk2jg
	QBxaTRrmMjF9ptn = KxIcVHk2jg.KQI8YgWzhmCV4T(NqYfA9CbvJsZyL)
	for ad3z2451e09FrDHmvci in QBxaTRrmMjF9ptn:
		if isinstance(ad3z2451e09FrDHmvci,tuple):
			Ew2zQ8u7Ss.menuItemsLIST.append(ad3z2451e09FrDHmvci)
			continue
		name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci = S3cEyiBdeo01G[ad3z2451e09FrDHmvci]
		jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
		text = oGYu4rKi2akMpCdXlZyS3(text)
		name = name+' - '+lrpUStmO67zg
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',FTbIBSC3OLPvyaZjqK7+name,ad3z2451e09FrDHmvci,548,Aq2Dt8VYCWaBQGZN7XIvOR,'',text)
	return
def oGYu4rKi2akMpCdXlZyS3(title):
	ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة)',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
	II4x930lvTuVqekXBNCrMy = ABK45TEMpciLnmIlYOafQJZ8t[0][0] if ABK45TEMpciLnmIlYOafQJZ8t else title
	II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return II4x930lvTuVqekXBNCrMy
def nQG3rOlxULDw6bV(search):
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	BBwfuWGxUIrdCoc4ka7 = url+'&start=0&num=100&tbm=vid&udm=7'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'GOOGLESEARCH-SEARCH-1st')
	if not bqIufCQz2OWExjilm.succeeded: return []
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	YhQNszaGUreBlkOutEJK3AFI2D = tiFgl4DMvGEAUfjIYkHbr05.path.join(CD6FK0opq3A4cYJWN1RHeEUZvti,'googlesearch')
	if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(YhQNszaGUreBlkOutEJK3AFI2D):
		try: tiFgl4DMvGEAUfjIYkHbr05.makedirs(YhQNszaGUreBlkOutEJK3AFI2D)
		except: pass
	items = []
	p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if p3LfChWJd124eAYj78zw09SXonH:
		for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
			ZgsbN5iSL48t2IhVFnmy,title,text,t4zynV13ZoPe,name = D3D6TF50oUBtJlvijPMW8ys
			t4zynV13ZoPe = ''
			items.append([ZgsbN5iSL48t2IhVFnmy,title,text,name,t4zynV13ZoPe])
	else:
		BBwfuWGxUIrdCoc4ka7 = url+'&start=0&num=200'
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'GET::SCRAPERS',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'GOOGLESEARCH-SEARCH-2nd')
		if not bqIufCQz2OWExjilm.succeeded: return []
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not p3LfChWJd124eAYj78zw09SXonH: p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
			D3D6TF50oUBtJlvijPMW8ys = oE7iT3HI5VDdmY4kPOjr('list',D3D6TF50oUBtJlvijPMW8ys)
			if len(D3D6TF50oUBtJlvijPMW8ys)>17:
				ZgsbN5iSL48t2IhVFnmy = D3D6TF50oUBtJlvijPMW8ys[17]
				title,text,name,t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys[31][0:4]
				items.append([ZgsbN5iSL48t2IhVFnmy,title,text,name,t4zynV13ZoPe])
	pw7XUOCjaKAgS1r6sy8YTl4mkoL3,WWyLfSMh2cgPlV5N9FxpbGrKkR7O = [],[]
	for jglfWFcvo1mAdH9yeROS7XKNxu in items:
		ZgsbN5iSL48t2IhVFnmy,title,text,name,t4zynV13ZoPe = jglfWFcvo1mAdH9yeROS7XKNxu
		name = name.strip(' ')
		if not name: name = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
		name = vvcCMPFyJDZ48oH6lTzma0xr9edOUK(name)
		if 'http://' in t4zynV13ZoPe or 'https://' in t4zynV13ZoPe: Aq2Dt8VYCWaBQGZN7XIvOR = t4zynV13ZoPe
		elif 'data:image/' in t4zynV13ZoPe and ';base64,' in t4zynV13ZoPe:
			ubytdTEek3pmQYR = Zy2l0g8QU5vqefaTrsw.findall('data:image/(\w+);base64,',t4zynV13ZoPe)
			ubytdTEek3pmQYR = ubytdTEek3pmQYR[0]
			Aq2Dt8VYCWaBQGZN7XIvOR = tiFgl4DMvGEAUfjIYkHbr05.path.join(YhQNszaGUreBlkOutEJK3AFI2D,name+'.'+ubytdTEek3pmQYR)
			if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(Aq2Dt8VYCWaBQGZN7XIvOR):
				t4zynV13ZoPe = t4zynV13ZoPe.replace('\\u003d','=')
				t4zynV13ZoPe = t4zynV13ZoPe.replace('data:image/'+ubytdTEek3pmQYR+';base64,','')
				lVRzn8gWU2wtdsm1 = qqth6cAFkaRowLlUeMng.b64decode(t4zynV13ZoPe)
				open(Aq2Dt8VYCWaBQGZN7XIvOR,'wb').write(lVRzn8gWU2wtdsm1)
		else: Aq2Dt8VYCWaBQGZN7XIvOR = ''
		ad3z2451e09FrDHmvci = MVBGgbacwzlWth(name,ZgsbN5iSL48t2IhVFnmy)
		if ad3z2451e09FrDHmvci not in WWyLfSMh2cgPlV5N9FxpbGrKkR7O:
			WWyLfSMh2cgPlV5N9FxpbGrKkR7O.append(ad3z2451e09FrDHmvci)
			name = HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci)
			pw7XUOCjaKAgS1r6sy8YTl4mkoL3.append([name,ZgsbN5iSL48t2IhVFnmy,title,text,Aq2Dt8VYCWaBQGZN7XIvOR,ad3z2451e09FrDHmvci])
	return pw7XUOCjaKAgS1r6sy8YTl4mkoL3
def udckD8r5RP(ZgsbN5iSL48t2IhVFnmy,ad3z2451e09FrDHmvci):
	jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
	if FTbIBSC3OLPvyaZjqK7: jJRFufHp4y0KoasdBXqkEGl()
	else: Ykf1uzemD8p()
	return
def fTHvn3K1s8LxV76EM():
	PIUzVg8uwmHlMKO5Lk6oxAZ('','',TAExSfcoNi4eORZ8HPB,'هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def Ykf1uzemD8p(ad3z2451e09FrDHmvci=''):
	PIUzVg8uwmHlMKO5Lk6oxAZ('','',ad3z2451e09FrDHmvci,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def MVBGgbacwzlWth(name,ZgsbN5iSL48t2IhVFnmy):
	p41qMDrGthLNKFE = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	TV1Zu8bOAfle5vWSpht2nQ = name.lower()
	GzWuVjwZgDKa5PCcQTM4 = ''
	for key in list(p41qMDrGthLNKFE.keys()):
		if key.lower() in TV1Zu8bOAfle5vWSpht2nQ: GzWuVjwZgDKa5PCcQTM4 = p41qMDrGthLNKFE[key]
	if not GzWuVjwZgDKa5PCcQTM4:
		otCOTHujWKp7Dn6dvcafPqlx = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'url')
		for ad3z2451e09FrDHmvci in list(Ew2zQ8u7Ss.SITESURLS.keys()):
			UBanXr1KiQbhYvp0 = fUSgd7IjGYX496Hr25uFMl(Ew2zQ8u7Ss.SITESURLS[ad3z2451e09FrDHmvci][0],'url')
			if otCOTHujWKp7Dn6dvcafPqlx==UBanXr1KiQbhYvp0: GzWuVjwZgDKa5PCcQTM4 = ad3z2451e09FrDHmvci
	if not GzWuVjwZgDKa5PCcQTM4:
		TV1Zu8bOAfle5vWSpht2nQ = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
		for ad3z2451e09FrDHmvci in list(Ew2zQ8u7Ss.SITESURLS.keys()):
			i2clkCzTV6E = fUSgd7IjGYX496Hr25uFMl(Ew2zQ8u7Ss.SITESURLS[ad3z2451e09FrDHmvci][0],'name')
			if TV1Zu8bOAfle5vWSpht2nQ==i2clkCzTV6E: GzWuVjwZgDKa5PCcQTM4 = ad3z2451e09FrDHmvci
	if not GzWuVjwZgDKa5PCcQTM4: GzWuVjwZgDKa5PCcQTM4 = name
	GzWuVjwZgDKa5PCcQTM4 = GzWuVjwZgDKa5PCcQTM4.upper()
	return GzWuVjwZgDKa5PCcQTM4
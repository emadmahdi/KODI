# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'ARABICTOONS'
kL0nT7NpZdKVD3jM2OHB = '_ART_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
def hH3sRBSFAr(mode,url,text):
	if   mode==730: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==731: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==732: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==733: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==734: SD0TxMRXiep4cjPBsnzI = eetVagSMhfyXkIZNomnREU6DpYAKwv(url)
	elif mode==735: SD0TxMRXiep4cjPBsnzI = I0epLqw5DvY3is(url)
	elif mode==739: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,739,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'افلام',V4kF6EQiwo+'/movies.php',731)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مسلسلات',V4kF6EQiwo+'/cartoon.php',734)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مسلسلات مميزة',V4kF6EQiwo+'/top.php',735)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أحدث الأفلام المضافة',V4kF6EQiwo,731,'','','LATEST_MOVIES')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أحدث المسلسلات المضافة',V4kF6EQiwo,731,'','','LATEST_SERIES')
	return
def eetVagSMhfyXkIZNomnREU6DpYAKwv(url):
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الكل',url,731)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABICTOONS-SERIES_SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('label="navigation"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall("href='(.*?)'>(.*?)</a>",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = 'حرف '+title
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,731)
	return
def I0epLqw5DvY3is(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABICTOONS-SERIES_FEATURED-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="slider"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('title="(.*?)" href="(.*?)".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			hzGKUP1XjAoeT79MJcDF = V4kF6EQiwo+'/'+hzGKUP1XjAoeT79MJcDF
			title = title.strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,733,hzGKUP1XjAoeT79MJcDF)
	return
def nvHUf8mW6E4GSw5VFRXN(url,RjVAI6uzxFofm7qv):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABICTOONS-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("class='moviesBlocks(.*?)list-group",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if RjVAI6uzxFofm7qv=='LATEST_SERIES': D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[1]
	else: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('class="movie".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
		hzGKUP1XjAoeT79MJcDF = V4kF6EQiwo+'/'+hzGKUP1XjAoeT79MJcDF
		title = title.strip(YvOQBzaTAscXR9ql)
		if 'movies.php' in url or RjVAI6uzxFofm7qv=='LATEST_MOVIES':
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,732,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,733,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[-1]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = title.strip(YvOQBzaTAscXR9ql)
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,731)
	return
def j9zTQsrVRx2(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABICTOONS-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("class='moviesBlocks(.*?)script",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('class="movie".*?title="(.*?)".*?href="(.*?)".*?src="(.*?)".*?<b>(.*?)</b>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,SPszXI3WfaYplrM0B in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			hzGKUP1XjAoeT79MJcDF = V4kF6EQiwo+'/'+hzGKUP1XjAoeT79MJcDF
			title = title.strip(YvOQBzaTAscXR9ql)
			title = title+YvOQBzaTAscXR9ql+SPszXI3WfaYplrM0B.strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,732,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ = []
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABICTOONS-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('source src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if Rp1g7OlotseGnf0NFmKk6rLxd:
		ZgsbN5iSL48t2IhVFnmy = Rp1g7OlotseGnf0NFmKk6rLxd[0]
		if 'Referer=' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'|Referer=https://www.arabic-toons.com'
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named=__embed')
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'%20')
	MNXzjK3vV7D = [CJlTSEpZsWb0QHg5w,'m']
	eNiOIGc7DQnMt = ['مسلسلات','افلام']
	if showDialogs:
		CrqTamtPFuU = T4TK17YsEfZJ('اختر النوع المطلوب:', eNiOIGc7DQnMt)
		if CrqTamtPFuU==-1: return
	else: CrqTamtPFuU = 0
	type = MNXzjK3vV7D[CrqTamtPFuU]
	url = V4kF6EQiwo+'/livesearch.php?'+type+'&q='+search
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABICTOONS-SEARCH-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
		title = title.strip(YvOQBzaTAscXR9ql)
		if type=='m': khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,732)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,733)
	return
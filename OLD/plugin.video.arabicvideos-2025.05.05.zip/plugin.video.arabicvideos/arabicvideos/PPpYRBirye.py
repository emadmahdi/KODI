# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'MYCIMA'
headers = {'User-Agent':CJlTSEpZsWb0QHg5w}
kL0nT7NpZdKVD3jM2OHB = '_MCM_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['مصارعة حرة','wwe']
def hH3sRBSFAr(mode,url,text):
	if   mode==360: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==361: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==362: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==363: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url,text)
	elif mode==364: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'CATEGORIES___'+text)
	elif mode==365: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'FILTERS___'+text)
	elif mode==366: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==369: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text,url)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',V4kF6EQiwo,369,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر محدد',V4kF6EQiwo+'/AjaxCenter/RightBar',364)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر كامل',V4kF6EQiwo+'/AjaxCenter/RightBar',365)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'MYCIMA-MENU-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('class="menu-item.*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title==CJlTSEpZsWb0QHg5w: continue
			if any(value in title.lower() for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,366)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('hoverable activable(.*?)hoverable activable',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,366,hzGKUP1XjAoeT79MJcDF)
	return bGIVq1CQTjmosZg
def jSpWoLZQRIsrw7MnH5KEbu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'MYCIMA-SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if 'class="Slider--Grid"' in bGIVq1CQTjmosZg:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المميزة',url,361,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="list--Tabsui"(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,361)
	return
def nvHUf8mW6E4GSw5VFRXN(ppNtmefScAB6REx0ioOM21W,type=CJlTSEpZsWb0QHg5w):
	if '::' in ppNtmefScAB6REx0ioOM21W:
		ysw7G3tqjo,url = ppNtmefScAB6REx0ioOM21W.split('::')
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ysw7G3tqjo,'url')
		url = FFtJQalhPz+url
	else: url,ysw7G3tqjo = ppNtmefScAB6REx0ioOM21W,ppNtmefScAB6REx0ioOM21W
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'MYCIMA-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if type=='featured':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='filters':
		s67485upzYNMS3PqDelkrdfo = [bGIVq1CQTjmosZg.replace('\\/','/').replace('\\"','"')]
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
			if any(value in title.lower() for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			hzGKUP1XjAoeT79MJcDF = pd0Na8D5WZfHYkysVS(hzGKUP1XjAoeT79MJcDF)
			title = wAmsc95ya0LHz(title)
			title = pd0Na8D5WZfHYkysVS(title)
			title = title.replace('مشاهدة ',CJlTSEpZsWb0QHg5w)
			if '/series/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,363,hzGKUP1XjAoeT79MJcDF)
			elif 'حلقة' in title:
				ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) +حلقة +\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if ABK45TEMpciLnmIlYOafQJZ8t: title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
				if title not in wDkMP6jlz7XeN5Sp:
					wDkMP6jlz7XeN5Sp.append(title)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,363,hzGKUP1XjAoeT79MJcDF)
			else:
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,362,hzGKUP1XjAoeT79MJcDF)
		if type=='filters':
			xtUMKHZFhcPR38DYErsi6JyT = Zy2l0g8QU5vqefaTrsw.findall('"more_button_page":(.*?),',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if xtUMKHZFhcPR38DYErsi6JyT:
				count = xtUMKHZFhcPR38DYErsi6JyT[0]
				ZgsbN5iSL48t2IhVFnmy = url+'/offset/'+count
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة أخرى',ZgsbN5iSL48t2IhVFnmy,361,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
		elif type==CJlTSEpZsWb0QHg5w:
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if s67485upzYNMS3PqDelkrdfo:
				D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
				items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,title in items:
					title = 'صفحة '+wAmsc95ya0LHz(title)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,361)
	return
def j9zTQsrVRx2(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'MYCIMA-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bGIVq1CQTjmosZg = sWzgdLCjSVwaMuhFkNf1Uop(bGIVq1CQTjmosZg)
	name = Zy2l0g8QU5vqefaTrsw.findall('itemprop="item" href=".*?/series/(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if name: name = name[-1].replace('-',YvOQBzaTAscXR9ql).strip('/')
	if 'موسم' in name and type==CJlTSEpZsWb0QHg5w:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
	else: name = name
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="Seasons--Episodes"(.*?)</singlesection',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		if type==CJlTSEpZsWb0QHg5w:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,363,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'episodes')
		if len(Ew2zQ8u7Ss.menuItemsLIST)==0:
			zE8URkuN932 = Zy2l0g8QU5vqefaTrsw.findall('class="Episodes--Seasons--Episodes"(.*?)&&',D3D6TF50oUBtJlvijPMW8ys+'&&',Zy2l0g8QU5vqefaTrsw.DOTALL)
			if zE8URkuN932: D3D6TF50oUBtJlvijPMW8ys = zE8URkuN932[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<episodeTitle>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				title = name+' - '+title
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,362)
	if len(Ew2zQ8u7Ss.menuItemsLIST)==0:
		title = Zy2l0g8QU5vqefaTrsw.findall('<title>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',CJlTSEpZsWb0QHg5w).replace('مشاهدة ',CJlTSEpZsWb0QHg5w)
		else: title = 'ملف التشغيل'
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,url,362)
	return
def rHwfOZb3oSgJKi(url):
	MNXzjK3vV7D = []
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'MYCIMA-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE:
		aIW8LXhxq2Gkdv9YQCPHrwORFZJE = [aIW8LXhxq2Gkdv9YQCPHrwORFZJE[0][0],aIW8LXhxq2Gkdv9YQCPHrwORFZJE[0][1]]
		if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-url="(.*?)".*?strong>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if name=='سيرفر ماي سيما': name = 'mycima'
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__watch'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="List--Download(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx in items:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			egYIsS2qROfpVW83kx = Zy2l0g8QU5vqefaTrsw.findall('\d\d\d+',egYIsS2qROfpVW83kx,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if egYIsS2qROfpVW83kx: egYIsS2qROfpVW83kx = '____'+egYIsS2qROfpVW83kx[0]
			else: egYIsS2qROfpVW83kx = CJlTSEpZsWb0QHg5w
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named=mycima'+'__download'+egYIsS2qROfpVW83kx
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search,Wvthq9Um0fIprRaxd3TA7ji4JQclPN=CJlTSEpZsWb0QHg5w):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	MNXzjK3vV7D = ['/list','/','/list/series','/list/anime','/list/tv']
	eNiOIGc7DQnMt = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		CrqTamtPFuU = T4TK17YsEfZJ('اختر النوع المطلوب:', eNiOIGc7DQnMt)
		if CrqTamtPFuU==-1: return
	else: CrqTamtPFuU = 0
	if Wvthq9Um0fIprRaxd3TA7ji4JQclPN==CJlTSEpZsWb0QHg5w:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,False,CJlTSEpZsWb0QHg5w,'MYCIMA-SEARCH-1st')
		Wvthq9Um0fIprRaxd3TA7ji4JQclPN = bqIufCQz2OWExjilm.headers['Location']
		Wvthq9Um0fIprRaxd3TA7ji4JQclPN = Wvthq9Um0fIprRaxd3TA7ji4JQclPN.strip('/')
	BBwfuWGxUIrdCoc4ka7 = Wvthq9Um0fIprRaxd3TA7ji4JQclPN+'/search/'+search+MNXzjK3vV7D[CrqTamtPFuU]
	nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7)
	return
def wwkAylgOx852(ppNtmefScAB6REx0ioOM21W,filter):
	if '??' in ppNtmefScAB6REx0ioOM21W: url = ppNtmefScAB6REx0ioOM21W.split('//getposts??')[0]
	else: url = ppNtmefScAB6REx0ioOM21W
	filter = filter.replace('_FORGETRESULTS_',CJlTSEpZsWb0QHg5w)
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='CATEGORIES':
		if CyoSHprnasi3K0M[0]+'==' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = CyoSHprnasi3K0M[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(CyoSHprnasi3K0M[0:-1])):
			if CyoSHprnasi3K0M[PMTRpXQvDIkiNszwYGnb32a]+'==' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = CyoSHprnasi3K0M[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&&'+y3LbIjrZvcATpNDM+'==0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&&'+y3LbIjrZvcATpNDM+'==0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&&')+'___'+YYvW68idVrJQFa.strip('&&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		BBwfuWGxUIrdCoc4ka7 = url+'//getposts??'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='FILTERS':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm!=CJlTSEpZsWb0QHg5w: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		if bnCVRhKEGJ0DIYqUBsgdpm==CJlTSEpZsWb0QHg5w: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'//getposts??'+bnCVRhKEGJ0DIYqUBsgdpm
		Da7e1Ruo9G = fPKulGyw2E(BBwfuWGxUIrdCoc4ka7,ppNtmefScAB6REx0ioOM21W)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها ',Da7e1Ruo9G,361,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',Da7e1Ruo9G,361,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'MYCIMA-FILTERS_MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('\\"','"').replace('\\/','/')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<mycima--filter(.*?)</mycima--filter>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = Zy2l0g8QU5vqefaTrsw.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',D3D6TF50oUBtJlvijPMW8ys+'<filterbox',Zy2l0g8QU5vqefaTrsw.DOTALL)
	dict = {}
	for HLQNhXe7orPjl5Vm4,name,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		name = pd0Na8D5WZfHYkysVS(name)
		if 'interest' in HLQNhXe7orPjl5Vm4: continue
		items = Zy2l0g8QU5vqefaTrsw.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if '==' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='CATEGORIES':
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<=1:
				if HLQNhXe7orPjl5Vm4==CyoSHprnasi3K0M[-1]: nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'CATEGORIES___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				Da7e1Ruo9G = fPKulGyw2E(BBwfuWGxUIrdCoc4ka7,ppNtmefScAB6REx0ioOM21W)
				if HLQNhXe7orPjl5Vm4==CyoSHprnasi3K0M[-1]:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',Da7e1Ruo9G,361,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,364,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='FILTERS':
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&&'+HLQNhXe7orPjl5Vm4+'==0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&&'+HLQNhXe7orPjl5Vm4+'==0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name+': الجميع',BBwfuWGxUIrdCoc4ka7,365,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ+'_FORGETRESULTS_')
		dict[HLQNhXe7orPjl5Vm4] = {}
		for value,ll5WFBCJKhA64tIDT8qvX in items:
			name = pd0Na8D5WZfHYkysVS(name)
			ll5WFBCJKhA64tIDT8qvX = pd0Na8D5WZfHYkysVS(ll5WFBCJKhA64tIDT8qvX)
			if value=='r' or value=='nc-17': continue
			if any(value in ll5WFBCJKhA64tIDT8qvX.lower() for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			if 'http' in ll5WFBCJKhA64tIDT8qvX: continue
			if 'الكل' in ll5WFBCJKhA64tIDT8qvX: continue
			if 'n-a' in value: continue
			if ll5WFBCJKhA64tIDT8qvX==CJlTSEpZsWb0QHg5w: ll5WFBCJKhA64tIDT8qvX = value
			xhPQw3M2SrXTOm8B = ll5WFBCJKhA64tIDT8qvX
			K2miyG8hBnz7A3rbZ5DWJsVNapev9g = Zy2l0g8QU5vqefaTrsw.findall('<name>(.*?)</name>',ll5WFBCJKhA64tIDT8qvX,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if K2miyG8hBnz7A3rbZ5DWJsVNapev9g: xhPQw3M2SrXTOm8B = K2miyG8hBnz7A3rbZ5DWJsVNapev9g[0]
			II4x930lvTuVqekXBNCrMy = name+': '+xhPQw3M2SrXTOm8B
			dict[HLQNhXe7orPjl5Vm4][value] = II4x930lvTuVqekXBNCrMy
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&&'+HLQNhXe7orPjl5Vm4+'=='+xhPQw3M2SrXTOm8B
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&&'+HLQNhXe7orPjl5Vm4+'=='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			if type=='FILTERS':
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,url,365,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and CyoSHprnasi3K0M[-2]+'==' in LLnTmNF7UG4:
				mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'modified_filters')
				ysw7G3tqjo = url+'//getposts??'+mmMRqiu1zXvWZlK7hAgEQn
				Da7e1Ruo9G = fPKulGyw2E(ysw7G3tqjo,ppNtmefScAB6REx0ioOM21W)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,Da7e1Ruo9G,361,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,url,364,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
CyoSHprnasi3K0M = ['genre','release-year','nation']
JiKsdhqDNPuWzXxo3O2017TV = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def fPKulGyw2E(BBwfuWGxUIrdCoc4ka7,ysw7G3tqjo):
	if '/AjaxCenter/RightBar' in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace('//getposts??','::/AjaxCenter/Filtering/')
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace('==','/')
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace('&&','/')
	return BBwfuWGxUIrdCoc4ka7
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&&')
	Sucv4JD0rRPaBL8HFMjNt,fuTzgEqmbRX378cwQnJH9rhFCt = {},CJlTSEpZsWb0QHg5w
	if '==' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('==')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	for key in JiKsdhqDNPuWzXxo3O2017TV:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if '%' not in value: value = O4Ak3NXpyUHvE(value)
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&&'+key+'=='+value
		elif mode=='all': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&&'+key+'=='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&&')
	return fuTzgEqmbRX378cwQnJH9rhFCt
# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from LA3rP81q4u import *
T1QDsJlUtCGhn = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡊࡐࡌࡘࠬᆎ")
IIlg9XzFU81NabmDpSBH = O4F8UC5lMAS6ghETm1VoPDI(u"ࠨ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠨᆏ")
kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
oRZnA7lqNIdGiDhY = int(n3dz9vetbZKIVYm78)
m9wgSl1oUVRd = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(otNfFapeEnO(u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪᆐ"))
m9wgSl1oUVRd = m9wgSl1oUVRd.replace(HCgURFmf8NvkYs2wnX,CJlTSEpZsWb0QHg5w).replace(s6rxOhWUy0bXDdQMJleNmu,CJlTSEpZsWb0QHg5w)
if oRZnA7lqNIdGiDhY==XB4CjMkPFzhAHiI3q(u"࠷࠼࠰ᆶ"): nQOGR3ab9dh8LCx = yylSaxCLfkte(u"ࠪࠤࠥࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫᆑ")+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+cjVhOCwybeRo7UWg92(u"ࠫࠥࡣࠠࠡࠢࡎࡳࡩ࡯࠺ࠡ࡝ࠣࠫᆒ")+uZYhUVqxz4Itp7MRSD3JkXGlrL+s97s2k0LJgl(u"ࠬࠦ࡝ࠨᆓ")
else:
	hhTlRAve8k0YGSybDKgWXQq = sWzgdLCjSVwaMuhFkNf1Uop(zz4EDG1PtiyX3JVUlBeC).replace(Dj62UpP5MrbTkJqhRa,CJlTSEpZsWb0QHg5w).replace(Ym6q5M4TocDaA013RjFQ,CJlTSEpZsWb0QHg5w)
	hhTlRAve8k0YGSybDKgWXQq = hhTlRAve8k0YGSybDKgWXQq.replace(oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
	hhTlRAve8k0YGSybDKgWXQq = hhTlRAve8k0YGSybDKgWXQq.replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	nQOGR3ab9dh8LCx = HaTI5u1f3SCxmMAkw(u"࠭ࠠࠡࠢࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬᆔ")+m9wgSl1oUVRd+s97s2k0LJgl(u"ࠧࠡ࡟ࠣࠤࠥࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧᆕ")+n3dz9vetbZKIVYm78+KA26GucUHOwXL(u"ࠨࠢࡠࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨᆖ")+hhTlRAve8k0YGSybDKgWXQq+E6xdOMpqISHZCn(u"ࠩࠣࡡࠬᆗ")
JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,IIlg9XzFU81NabmDpSBH+rJ9cgWz4FU+u5ufzT4NjHKSr(T1QDsJlUtCGhn)+nQOGR3ab9dh8LCx)
if EcjO3giln2kQTdBY0XLAG(u"ࠪࡣࠬᆘ") in QQa9t5k6BLqflRNr: UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2 = QQa9t5k6BLqflRNr.split(rC5tnFDlQcRGA2(u"ࠫࡤ࠭ᆙ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)
else: UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2 = QQa9t5k6BLqflRNr,CJlTSEpZsWb0QHg5w
Ew2zQ8u7Ss.SuWYMCwV1oBNIG8cq7xR,uErMFcVGBXUvtJZ90zCTPxn2YW = VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w
if UZxHPtpYJg8u3h9rOnM in [NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࠷ࠧᆚ"),yylSaxCLfkte(u"࠭࠲ࠨᆛ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧ࠴ࠩᆜ"),rC5tnFDlQcRGA2(u"ࠨ࠶ࠪᆝ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠩ࠸ࠫᆞ"),yylSaxCLfkte(u"ࠪ࠵࠶࠭ᆟ"),Olh7n0zfV4(u"ࠫ࠶࠸ࠧᆠ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࠷࠳ࠨᆡ")] and (rC5tnFDlQcRGA2(u"࠭ࡁࡅࡆࠪᆢ") in xnlXAO3qzsuKr2 or zQGaM7ctZCN(u"ࠧࡓࡇࡐࡓ࡛ࡋࠧᆣ") in xnlXAO3qzsuKr2 or ZP1LyUCS3pIBu(u"ࠨࡗࡓࠫᆤ") in xnlXAO3qzsuKr2 or Olh7n0zfV4(u"ࠩࡇࡓ࡜ࡔࠧᆥ") in xnlXAO3qzsuKr2):
	from z2BQ0dUKrP import szprIF8Zyl30nRVMfEbJqiATQao1G
	szprIF8Zyl30nRVMfEbJqiATQao1G(QQa9t5k6BLqflRNr,UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(EcjO3giln2kQTdBY0XLAG(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧᆦ"),zz4EDG1PtiyX3JVUlBeC)
	Ew2zQ8u7Ss.SuWYMCwV1oBNIG8cq7xR = w2qb6lf5EM
elif not ohkAjGeH2Rf6Vw4vNM8rJE3tlnO5d and oRZnA7lqNIdGiDhY in [xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠸࠳࠶ᆷ"),O4F8UC5lMAS6ghETm1VoPDI(u"࠷࠲࠷ᆸ")]:
	DDQHXmOsdnJVtK = str(TiPIxOFX2bS5ZDG4A1KoeVUyW0dh[VVvcQpCU3OM09n(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆧ")])
	T1QDsJlUtCGhn = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡏࡐࡕࡘࠪᆨ") if oRZnA7lqNIdGiDhY==otNfFapeEnO(u"࠳࠵࠸ᆹ") else CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡍ࠴ࡗࠪᆩ")
	ol30VcxiXJbBI = T1QDsJlUtCGhn.lower()
	ww0cfi2ZxQvg7k3N1uLRhtFdH = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(otNfFapeEnO(u"ࠧࡢࡸ࠱ࠫᆪ")+ol30VcxiXJbBI+O4F8UC5lMAS6ghETm1VoPDI(u"ࠨ࠰ࡸࡷࡪࡸࡡࡨࡧࡱࡸࡤ࠭ᆫ")+DDQHXmOsdnJVtK)
	ffY51ieqb2WIwQRHExhZsAopFu = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡤࡺ࠳࠭ᆬ")+ol30VcxiXJbBI+GISOTJh20W(u"ࠪ࠲ࡷ࡫ࡦࡦࡴࡨࡶࡤ࠭ᆭ")+DDQHXmOsdnJVtK)
	if ww0cfi2ZxQvg7k3N1uLRhtFdH or ffY51ieqb2WIwQRHExhZsAopFu:
		otaunYGVIJ2jX8HsKm7ecR0bAh4 += yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࢁ࠭ᆮ")
		if ww0cfi2ZxQvg7k3N1uLRhtFdH: otaunYGVIJ2jX8HsKm7ecR0bAh4 += Olh7n0zfV4(u"ࠬࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᆯ")+ww0cfi2ZxQvg7k3N1uLRhtFdH
		if ffY51ieqb2WIwQRHExhZsAopFu: otaunYGVIJ2jX8HsKm7ecR0bAh4 += cbmeD4WNZfAowxT2JdUMtV(u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᆰ")+ffY51ieqb2WIwQRHExhZsAopFu
		otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡽࠨࠪᆱ"),HaTI5u1f3SCxmMAkw(u"ࠨࡾࠪᆲ"))
	kEdbuZMyrzwvTsaGKOxR79Fcjt62 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡤࡺ࠳࠭ᆳ")+ol30VcxiXJbBI+mi2ZJXCDzITuyev6gfn(u"ࠪ࠲ࡸ࡫ࡲࡷࡧࡵࡣࠬᆴ")+DDQHXmOsdnJVtK)
	if kEdbuZMyrzwvTsaGKOxR79Fcjt62:
		e9HVrxv5KIaNkL0yQCA = Zy2l0g8QU5vqefaTrsw.findall(TDpFsQXHze2q30uYtGPfEIm8(u"ࠫ࠿࠵࠯ࠩ࠰࠭ࡃ࠮࠵ࠧᆵ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,Zy2l0g8QU5vqefaTrsw.DOTALL)
		otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(e9HVrxv5KIaNkL0yQCA[ZVNvqy4iF1a9X],kEdbuZMyrzwvTsaGKOxR79Fcjt62)
	ZQtv0jY9W6L8UHgpnKm(otaunYGVIJ2jX8HsKm7ecR0bAh4,T1QDsJlUtCGhn,kcxAmftieK56PE9TqbDHdSrF8)
else:
	import kUCfvjAP1c
	try: kUCfvjAP1c.rcfBUlvIkDeGNKA3J(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh,oRZnA7lqNIdGiDhY,UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2,m9wgSl1oUVRd)
	except Exception as iy7BbWH2lmuDT1FrXaLJCq8: uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
AgesnIjOpZS46(Ew2zQ8u7Ss.SuWYMCwV1oBNIG8cq7xR,uErMFcVGBXUvtJZ90zCTPxn2YW)
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'SHIAVOICE'
kL0nT7NpZdKVD3jM2OHB = '_SHV_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
headers = {'User-Agent':None}
def hH3sRBSFAr(mode,url,text):
	if   mode==310: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==311: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	elif mode==312: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==313: SD0TxMRXiep4cjPBsnzI = rrsNbIBoRu14TME(url)
	elif mode==314: SD0TxMRXiep4cjPBsnzI = GWrYbnkfSBcuX8jZILoiaemMs(text)
	elif mode==319: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,319,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHIAVOICE-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="menulinks"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	items = Zy2l0g8QU5vqefaTrsw.findall('<h5>(.*?)</h5>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
	for ykAihXr9IU82HQqMx7tj5 in range(len(items)):
		title = items[ykAihXr9IU82HQqMx7tj5].strip(YvOQBzaTAscXR9ql)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,V4kF6EQiwo,314,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,str(ykAihXr9IU82HQqMx7tj5+1))
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مقاطع شهر',V4kF6EQiwo,314,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'0')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<B>(.*?)</B>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,311)
	return bGIVq1CQTjmosZg
def GWrYbnkfSBcuX8jZILoiaemMs(ykAihXr9IU82HQqMx7tj5):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHIAVOICE-LATEST-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if ykAihXr9IU82HQqMx7tj5=='0':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="tab-content"(.*?)</table>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = title.strip(YvOQBzaTAscXR9ql)
			name = name.strip(YvOQBzaTAscXR9ql)
			title = title+' ('+name+')'
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,312)
	elif ykAihXr9IU82HQqMx7tj5 in ['1','2','3']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(<h5>.*?)<div class="col-lg',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		xqdQv5roAGJeRTbNytkSKm6hl9 = int(ykAihXr9IU82HQqMx7tj5)-1
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[xqdQv5roAGJeRTbNytkSKm6hl9]
		if ykAihXr9IU82HQqMx7tj5=='1': items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		else: items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title,name in items:
			hzGKUP1XjAoeT79MJcDF = V4kF6EQiwo+'/'+hzGKUP1XjAoeT79MJcDF
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = title.strip(YvOQBzaTAscXR9ql)
			name = name.strip(YvOQBzaTAscXR9ql)
			title = title+' ('+name+')'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,311,hzGKUP1XjAoeT79MJcDF)
	elif ykAihXr9IU82HQqMx7tj5 in ['4','5','6']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(<h5>.*?)</table>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ykAihXr9IU82HQqMx7tj5 = int(ykAihXr9IU82HQqMx7tj5)-4
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ykAihXr9IU82HQqMx7tj5]
		items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,K2miyG8hBnz7A3rbZ5DWJsVNapev9g,title,TV1Zu8bOAfle5vWSpht2nQ in items:
			hzGKUP1XjAoeT79MJcDF = V4kF6EQiwo+'/'+hzGKUP1XjAoeT79MJcDF
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = title.strip(YvOQBzaTAscXR9ql)
			K2miyG8hBnz7A3rbZ5DWJsVNapev9g = K2miyG8hBnz7A3rbZ5DWJsVNapev9g.strip(YvOQBzaTAscXR9ql)
			TV1Zu8bOAfle5vWSpht2nQ = TV1Zu8bOAfle5vWSpht2nQ.strip(YvOQBzaTAscXR9ql)
			if K2miyG8hBnz7A3rbZ5DWJsVNapev9g: name = K2miyG8hBnz7A3rbZ5DWJsVNapev9g
			else: name = TV1Zu8bOAfle5vWSpht2nQ
			title = title+' ('+name+')'
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,312,hzGKUP1XjAoeT79MJcDF)
	return
def nvHUf8mW6E4GSw5VFRXN(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHIAVOICE-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('ibox-heading"(.*?)class="float-right',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if 'catsum-mobile' in D3D6TF50oUBtJlvijPMW8ys:
		items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title,count in items:
				hzGKUP1XjAoeT79MJcDF = V4kF6EQiwo+'/'+hzGKUP1XjAoeT79MJcDF
				ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
				count = count.replace(' الصوتية: ',':')
				title = title.strip(YvOQBzaTAscXR9ql)
				title = title+' ('+count+')'
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,311,hzGKUP1XjAoeT79MJcDF)
	else:
		items = Zy2l0g8QU5vqefaTrsw.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title,vSf657Y9uwozTEmlHxn4RUJWpF,XtbZnKed5mT2IYPy4MqvuOGURNwSc in items:
			if title==CJlTSEpZsWb0QHg5w or vSf657Y9uwozTEmlHxn4RUJWpF==CJlTSEpZsWb0QHg5w: continue
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = title+' ('+XtbZnKed5mT2IYPy4MqvuOGURNwSc+')'
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,312)
	if not items: j9zTQsrVRx2(bGIVq1CQTjmosZg)
	return
def j9zTQsrVRx2(bGIVq1CQTjmosZg):
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="ibox-content"(.*?)class="pagination',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title,name,count,XtbZnKed5mT2IYPy4MqvuOGURNwSc in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
		title = title.strip(YvOQBzaTAscXR9ql)
		name = name.strip(YvOQBzaTAscXR9ql)
		title = title+' ('+name+')'
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,312,CJlTSEpZsWb0QHg5w,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	return
def rrsNbIBoRu14TME(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHIAVOICE-SEARCH_ITEMS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="ibox-content p-1"(.*?)class="ibox-content"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo:
		nvHUf8mW6E4GSw5VFRXN(url)
		return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<strong>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
		title = title.strip(YvOQBzaTAscXR9ql)
		if '/play-' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,312)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,311)
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHIAVOICE-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('<audio.*?src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('<video.*?src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy[0]
	ZQtv0jY9W6L8UHgpnKm(ZgsbN5iSL48t2IhVFnmy,T1QDsJlUtCGhn,'video')
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	Py8XQvCAHEa3qpbBjg0sxNhRYU = ['&t=a','&t=c','&t=s']
	if showDialogs:
		kHWQP8oLASlUzM2s5GigtEhCyKB = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		CrqTamtPFuU = T4TK17YsEfZJ('موقع صوت الشيعة - أختر البحث', kHWQP8oLASlUzM2s5GigtEhCyKB)
		if CrqTamtPFuU == -1: return
	elif '_SHIAVOICE-PERSONS_' in EcrV3IasOo4Hq: CrqTamtPFuU = 0
	elif '_SHIAVOICE-ALBUMS_' in EcrV3IasOo4Hq: CrqTamtPFuU = 1
	elif '_SHIAVOICE-AUDIOS_' in EcrV3IasOo4Hq: CrqTamtPFuU = 2
	else: return
	type = Py8XQvCAHEa3qpbBjg0sxNhRYU[CrqTamtPFuU]
	url = V4kF6EQiwo+'/search.php?q='+search+type
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHIAVOICE-SEARCH-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="ibox-content"(.*?)class="ibox-content"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		if CrqTamtPFuU in [0,1]:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title,name in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				name = name.strip(YvOQBzaTAscXR9ql)
				title = title+' ('+name+')'
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,313,hzGKUP1XjAoeT79MJcDF)
		elif CrqTamtPFuU==2:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title,name in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				name = name.strip(YvOQBzaTAscXR9ql)
				title = title+' ('+name+')'
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,312)
	return
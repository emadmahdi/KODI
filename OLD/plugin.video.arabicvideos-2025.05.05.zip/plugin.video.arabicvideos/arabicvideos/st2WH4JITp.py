# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'MOVIZLAND'
headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
kL0nT7NpZdKVD3jM2OHB = '_MVZ_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
hRigZpdbjIYsDGr2 = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][1]
def hH3sRBSFAr(mode,url,text):
	if   mode==180: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==181: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==182: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==183: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==188: SD0TxMRXiep4cjPBsnzI = HSoWh10Q39ab7xk()
	elif mode==189: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def HSoWh10Q39ab7xk():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,message)
	return
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,189,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'بوكس اوفيس موفيز لاند',V4kF6EQiwo,181,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'box-office')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أحدث الافلام',V4kF6EQiwo,181,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'latest-movies')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'تليفزيون موفيز لاند',V4kF6EQiwo,181,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'tv')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الاكثر مشاهدة',V4kF6EQiwo,181,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'top-views')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أقوى الافلام الحالية',V4kF6EQiwo,181,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'top-movies')
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-MENU-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('<h2><a href="(.*?)".*?">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,181)
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': D3D6TF50oUBtJlvijPMW8ys = Zy2l0g8QU5vqefaTrsw.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	elif type=='box-office': D3D6TF50oUBtJlvijPMW8ys = Zy2l0g8QU5vqefaTrsw.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	elif type=='top-movies': D3D6TF50oUBtJlvijPMW8ys = Zy2l0g8QU5vqefaTrsw.findall('btn-2-overlay(.*?)<style>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	elif type=='top-views': D3D6TF50oUBtJlvijPMW8ys = Zy2l0g8QU5vqefaTrsw.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	elif type=='tv': D3D6TF50oUBtJlvijPMW8ys = Zy2l0g8QU5vqefaTrsw.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	else: D3D6TF50oUBtJlvijPMW8ys = bGIVq1CQTjmosZg
	if type in ['top-views','top-movies']:
		items = Zy2l0g8QU5vqefaTrsw.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: items = Zy2l0g8QU5vqefaTrsw.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	mmYWLBuEGhr5OQRvgyNApo8ldFVjP6 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for hzGKUP1XjAoeT79MJcDF,zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm,M0WAfXLaJseRbYZHPg4Kqh in items:
		if type in ['top-views','top-movies']:
			hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,otCOTHujWKp7Dn6dvcafPqlx,title = hzGKUP1XjAoeT79MJcDF,zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm,M0WAfXLaJseRbYZHPg4Kqh
		else: hzGKUP1XjAoeT79MJcDF,title,ZgsbN5iSL48t2IhVFnmy,otCOTHujWKp7Dn6dvcafPqlx = hzGKUP1XjAoeT79MJcDF,zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm,M0WAfXLaJseRbYZHPg4Kqh
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy)
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('?view=true',CJlTSEpZsWb0QHg5w)
		title = wAmsc95ya0LHz(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',CJlTSEpZsWb0QHg5w).replace('بجوده ',CJlTSEpZsWb0QHg5w)
		title = title.strip(YvOQBzaTAscXR9ql)
		if 'الحلقة' in title or 'الحلقه' in title:
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|الحلقه) \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0][0]
				if title not in wDkMP6jlz7XeN5Sp:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,183,hzGKUP1XjAoeT79MJcDF)
					wDkMP6jlz7XeN5Sp.append(title)
		elif any(value in title for value in mmYWLBuEGhr5OQRvgyNApo8ldFVjP6):
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy + '?servers=' + otCOTHujWKp7Dn6dvcafPqlx
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,182,hzGKUP1XjAoeT79MJcDF)
		else:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy + '?servers=' + otCOTHujWKp7Dn6dvcafPqlx
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,183,hzGKUP1XjAoeT79MJcDF)
	if type==CJlTSEpZsWb0QHg5w:
		items = Zy2l0g8QU5vqefaTrsw.findall('\n<li><a href="(.*?)".*?>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			title = title.replace('الصفحة ',CJlTSEpZsWb0QHg5w)
			if title!=CJlTSEpZsWb0QHg5w:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,181)
	return
def j9zTQsrVRx2(url):
	BBwfuWGxUIrdCoc4ka7 = url.split('?servers=')[0]
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-EPISODES-1st')
	D3D6TF50oUBtJlvijPMW8ys = Zy2l0g8QU5vqefaTrsw.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	title,Cm7xuRTdLQwZjv81V2AhKfqs04U,hzGKUP1XjAoeT79MJcDF = D3D6TF50oUBtJlvijPMW8ys[0]
	name = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="episodesNumbers"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy in items:
			ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy)
			title = Zy2l0g8QU5vqefaTrsw.findall('(الحلقة|الحلقه)-([0-9]+)',ZgsbN5iSL48t2IhVFnmy.split('/')[-2],Zy2l0g8QU5vqefaTrsw.DOTALL)
			if not title: title = Zy2l0g8QU5vqefaTrsw.findall('()-([0-9]+)',ZgsbN5iSL48t2IhVFnmy.split('/')[-2],Zy2l0g8QU5vqefaTrsw.DOTALL)
			if title: title = YvOQBzaTAscXR9ql + title[0][1]
			else: title = CJlTSEpZsWb0QHg5w
			title = name + ' - ' + 'الحلقة' + title
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,182,hzGKUP1XjAoeT79MJcDF)
	if not items:
		title = wAmsc95ya0LHz(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',CJlTSEpZsWb0QHg5w).replace('بجوده ',CJlTSEpZsWb0QHg5w)
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,url,182,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	vD98mqtSBzkYpG2F = url.split('?servers=')
	BBwfuWGxUIrdCoc4ka7 = vD98mqtSBzkYpG2F[0]
	del vD98mqtSBzkYpG2F[0]
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-PLAY-1st')
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('font-size: 25px;" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	if ZgsbN5iSL48t2IhVFnmy not in vD98mqtSBzkYpG2F: vD98mqtSBzkYpG2F.append(ZgsbN5iSL48t2IhVFnmy)
	MNXzjK3vV7D = []
	for ZgsbN5iSL48t2IhVFnmy in vD98mqtSBzkYpG2F:
		if '://moshahda.' in ZgsbN5iSL48t2IhVFnmy:
			z4nFcybDeX9VKN8BEZU6jGrv2pRLM = ZgsbN5iSL48t2IhVFnmy
			MNXzjK3vV7D.append(z4nFcybDeX9VKN8BEZU6jGrv2pRLM+'?named=Main')
	for ZgsbN5iSL48t2IhVFnmy in vD98mqtSBzkYpG2F:
		if '://vb.movizland.' in ZgsbN5iSL48t2IhVFnmy:
			bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-PLAY-2nd')
			bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.decode('windows-1256').encode(Im5KSGZYBpRvdMVsbuXg)
			bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if s67485upzYNMS3PqDelkrdfo:
				evkarIESVFp3ofA0cld8G,nKGBqEpeizbMmYHuIUWlrovCgLkA = [],[]
				if len(s67485upzYNMS3PqDelkrdfo)==1:
					title = CJlTSEpZsWb0QHg5w
					D3D6TF50oUBtJlvijPMW8ys = bGIVq1CQTjmosZg
				else:
					for D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
						zE8URkuN932 = Zy2l0g8QU5vqefaTrsw.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
						if zE8URkuN932: D3D6TF50oUBtJlvijPMW8ys = 'src="/uploads/13721411411.png"  \n  ' + zE8URkuN932[0][1]
						zE8URkuN932 = Zy2l0g8QU5vqefaTrsw.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
						if zE8URkuN932: D3D6TF50oUBtJlvijPMW8ys = 'src="/uploads/13721411411.png"  \n  ' + zE8URkuN932[0]
						zE8URkuN932 = Zy2l0g8QU5vqefaTrsw.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
						if zE8URkuN932: D3D6TF50oUBtJlvijPMW8ys = zE8URkuN932[0] + '  \n  src="/uploads/13721411411.png"'
						fQJ5ZCr7b8gXP6wSxo = Zy2l0g8QU5vqefaTrsw.findall('<(.*?)http://up.movizland.(online|com)/uploads/',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
						title = Zy2l0g8QU5vqefaTrsw.findall('> *([^<>]+) *<',fQJ5ZCr7b8gXP6wSxo[0][0],Zy2l0g8QU5vqefaTrsw.DOTALL)
						title = YvOQBzaTAscXR9ql.join(title)
						title = title.strip(YvOQBzaTAscXR9ql)
						title = title.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
						evkarIESVFp3ofA0cld8G.append(title)
					CrqTamtPFuU = T4TK17YsEfZJ('أختر الفيديو المطلوب:', evkarIESVFp3ofA0cld8G)
					if CrqTamtPFuU == -1 : return
					title = evkarIESVFp3ofA0cld8G[CrqTamtPFuU]
					D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[CrqTamtPFuU]
				ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('href="(http://moshahda\..*?/\w+.html)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				e9r2TID45QtO = ZgsbN5iSL48t2IhVFnmy[0]
				MNXzjK3vV7D.append(e9r2TID45QtO+'?named=Forum')
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('ـ',CJlTSEpZsWb0QHg5w)
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				Dlfi0cbKk8xYdhUuepVvN4JA = Zy2l0g8QU5vqefaTrsw.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for Ox2dhpuA8qNsWjTKXREDgUZ5i in Dlfi0cbKk8xYdhUuepVvN4JA:
					type = Zy2l0g8QU5vqefaTrsw.findall(' typetype="(.*?)" ',Ox2dhpuA8qNsWjTKXREDgUZ5i)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = CJlTSEpZsWb0QHg5w
					items = Zy2l0g8QU5vqefaTrsw.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',Ox2dhpuA8qNsWjTKXREDgUZ5i,Zy2l0g8QU5vqefaTrsw.DOTALL)
					for qPtxW6wrAKaoeEHuLl,ZgsbN5iSL48t2IhVFnmy in items:
						title = Zy2l0g8QU5vqefaTrsw.findall('(\w+[ \w]*)<',qPtxW6wrAKaoeEHuLl)
						title = title[-1]
						ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy + '?named=' + title + type
						MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7.replace(V4kF6EQiwo,hRigZpdbjIYsDGr2)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,ysw7G3tqjo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-PLAY-3rd')
	items = Zy2l0g8QU5vqefaTrsw.findall('" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		L7xnSu2DFrfY1GByXHbI = items[-1]
		MNXzjK3vV7D.append(L7xnSu2DFrfY1GByXHbI+'?named=Mobile')
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'MOVIZLAND-SEARCH-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('<option value="(.*?)">(.*?)</option>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	LsFvB5RcpdeIaf8qUbEtyMP3QN0 = [ CJlTSEpZsWb0QHg5w ]
	pFKTMoOGQPSJ3xdgmHuW4Njk7r82n = [ 'الكل وبدون فلتر' ]
	for y3LbIjrZvcATpNDM,title in items:
		LsFvB5RcpdeIaf8qUbEtyMP3QN0.append(y3LbIjrZvcATpNDM)
		pFKTMoOGQPSJ3xdgmHuW4Njk7r82n.append(title)
	if y3LbIjrZvcATpNDM:
		CrqTamtPFuU = T4TK17YsEfZJ('اختر الفلتر المناسب:', pFKTMoOGQPSJ3xdgmHuW4Njk7r82n)
		if CrqTamtPFuU == -1 : return
		y3LbIjrZvcATpNDM = LsFvB5RcpdeIaf8qUbEtyMP3QN0[CrqTamtPFuU]
	else: y3LbIjrZvcATpNDM = CJlTSEpZsWb0QHg5w
	url = V4kF6EQiwo + '/?s='+search+'&mcat='+y3LbIjrZvcATpNDM
	nvHUf8mW6E4GSw5VFRXN(url)
	return
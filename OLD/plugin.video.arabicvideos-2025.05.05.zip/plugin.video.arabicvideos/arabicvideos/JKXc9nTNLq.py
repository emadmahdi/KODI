# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'AHWAK'
kL0nT7NpZdKVD3jM2OHB = '_AHK_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['الصفحة الرئيسية','Sign in']
def hH3sRBSFAr(mode,url,text):
	if   mode==610: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==611: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==612: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==613: SD0TxMRXiep4cjPBsnzI = eB3ZX7kK5CTiIOoz(url,text)
	elif mode==614: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==619: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,619,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المميزة',V4kF6EQiwo,611,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المسلسلات المميزة',V4kF6EQiwo,611,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured_series')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('/category.php">(.*?)"navslide-divider"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("'dropdown-menu'(.*?)</ul>",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for zE8URkuN932 in s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace(zE8URkuN932,CJlTSEpZsWb0QHg5w)
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,614)
	return
def jSpWoLZQRIsrw7MnH5KEbu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"caret"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('"presentation"','</ul>')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = [(CJlTSEpZsWb0QHg5w,D3D6TF50oUBtJlvijPMW8ys)]
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' فرز أو فلتر أو ترتيب '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		for VVgEIqZuc3GRbY,D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if VVgEIqZuc3GRbY: VVgEIqZuc3GRbY = VVgEIqZuc3GRbY+': '
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = VVgEIqZuc3GRbY+title
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,611)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"pm-category-subcats"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc:
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if len(items)<30:
			khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,611)
	if not hh2VPjs7dkR581KzENYigmpZxLyb and not KXu2RYg3Bc: nvHUf8mW6E4GSw5VFRXN(url)
	return
def nvHUf8mW6E4GSw5VFRXN(url,RjVAI6uzxFofm7qv=CJlTSEpZsWb0QHg5w):
	if RjVAI6uzxFofm7qv=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-TITLES-1st')
	else:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-TITLES-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	D3D6TF50oUBtJlvijPMW8ys,items = CJlTSEpZsWb0QHg5w,[]
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	if RjVAI6uzxFofm7qv=='ajax-search':
		D3D6TF50oUBtJlvijPMW8ys = bGIVq1CQTjmosZg
		B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in B5vY7qZAFfeTcXnpCGP9SRr0kaHV: items.append((CJlTSEpZsWb0QHg5w,ZgsbN5iSL48t2IhVFnmy,title))
	elif RjVAI6uzxFofm7qv=='featured':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pm-video-watch-featured"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	elif RjVAI6uzxFofm7qv=='new_episodes':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"row pm-ul-browse-videos(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	elif RjVAI6uzxFofm7qv=='new_movies':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"row pm-ul-browse-videos(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if len(s67485upzYNMS3PqDelkrdfo)>1: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[1]
	elif RjVAI6uzxFofm7qv=='featured_series':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in B5vY7qZAFfeTcXnpCGP9SRr0kaHV: items.append((CJlTSEpZsWb0QHg5w,ZgsbN5iSL48t2IhVFnmy,title))
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(data-echo=".*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if D3D6TF50oUBtJlvijPMW8ys and not items: items = Zy2l0g8QU5vqefaTrsw.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not items: return
	wDkMP6jlz7XeN5Sp = []
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة).\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,612,hzGKUP1XjAoeT79MJcDF)
		elif RjVAI6uzxFofm7qv=='new_episodes':
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,612,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t:
			title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0][0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,613,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,613,hzGKUP1XjAoeT79MJcDF)
	if 1:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy=='#': continue
				ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,611)
	return
def eB3ZX7kK5CTiIOoz(url,FfC8TlgIzVh5aDePHELA3rwSo4uNRM):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-EPISODES-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	t4zynV13ZoPe = Zy2l0g8QU5vqefaTrsw.findall('preview_image_url: "(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if t4zynV13ZoPe: hzGKUP1XjAoeT79MJcDF = t4zynV13ZoPe[0]
	else: hzGKUP1XjAoeT79MJcDF = CJlTSEpZsWb0QHg5w
	items = []
	eE2nkorRIbZ1y = False
	if hh2VPjs7dkR581KzENYigmpZxLyb and not FfC8TlgIzVh5aDePHELA3rwSo4uNRM:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for FfC8TlgIzVh5aDePHELA3rwSo4uNRM,title in items:
			FfC8TlgIzVh5aDePHELA3rwSo4uNRM = FfC8TlgIzVh5aDePHELA3rwSo4uNRM.strip('#')
			if len(items)>1: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,613,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,FfC8TlgIzVh5aDePHELA3rwSo4uNRM)
			else: eE2nkorRIbZ1y = True
	else: eE2nkorRIbZ1y = True
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('id="'+FfC8TlgIzVh5aDePHELA3rwSo4uNRM+'"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc and eE2nkorRIbZ1y:
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('''title=["'](.*?)["'].*?href=['"](.*?)['"]''',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		items = []
		for title,ZgsbN5iSL48t2IhVFnmy in B5vY7qZAFfeTcXnpCGP9SRr0kaHV: items.append((ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF))
		if not items: items = Zy2l0g8QU5vqefaTrsw.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
			ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
			title = title.replace('</em><span>',YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,612,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ,DIA54R1lwcTz7OZPjX6a = [],[]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if 'post=' in bGIVq1CQTjmosZg:
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('id="player".*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		HGXYPrKegtmb2zE3aqTxiF = ZgsbN5iSL48t2IhVFnmy.split('post=')[1]
		HGXYPrKegtmb2zE3aqTxiF = qqth6cAFkaRowLlUeMng.b64decode(HGXYPrKegtmb2zE3aqTxiF)
		if A7Z6OVh20eCEUx: HGXYPrKegtmb2zE3aqTxiF = HGXYPrKegtmb2zE3aqTxiF.decode(Im5KSGZYBpRvdMVsbuXg)
		HGXYPrKegtmb2zE3aqTxiF = oE7iT3HI5VDdmY4kPOjr('dict',HGXYPrKegtmb2zE3aqTxiF)
		Rp1g7OlotseGnf0NFmKk6rLxd = HGXYPrKegtmb2zE3aqTxiF['servers']
		RYHIKeQZLBpbNvmhkq2GV1C = list(Rp1g7OlotseGnf0NFmKk6rLxd.keys())
		Rp1g7OlotseGnf0NFmKk6rLxd = list(Rp1g7OlotseGnf0NFmKk6rLxd.values())
		xxMT4HEkmJgz = zip(RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd)
		for title,ZgsbN5iSL48t2IhVFnmy in xxMT4HEkmJgz:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	else:
		BBwfuWGxUIrdCoc4ka7 = url.replace('watch.php','see.php')
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AHWAK-PLAY2-1st')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('<iframe src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
			if ZgsbN5iSL48t2IhVFnmy not in DIA54R1lwcTz7OZPjX6a:
				DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
				FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__embed'
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"WatchList"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy not in DIA54R1lwcTz7OZPjX6a:
					DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
					FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
					ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__watch'
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
		if 'pm-download' not in bGIVq1CQTjmosZg:
			BBwfuWGxUIrdCoc4ka7 = url.replace('watch.php','downloads.php')
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,False,'AHWAK-PLAY-2nd')
			bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('pm-download(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('download-url="(.*?)".*?<span>(.*?)</span>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy not in DIA54R1lwcTz7OZPjX6a:
					DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
					FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
					ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__download'
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/search.php?keywords='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
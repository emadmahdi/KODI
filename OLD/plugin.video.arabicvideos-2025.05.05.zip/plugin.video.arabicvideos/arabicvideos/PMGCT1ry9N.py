# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
T1QDsJlUtCGhn = 'AKOAM'
kL0nT7NpZdKVD3jM2OHB = '_AKO_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
VqQYjbA9PTWtfHcI016zlmLuF = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def hH3sRBSFAr(mode,url,text):
	if   mode==70: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==71: SD0TxMRXiep4cjPBsnzI = DT6xAoz34MIGpek7vXUhRJs1rOyYtl(url)
	elif mode==72: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==73: SD0TxMRXiep4cjPBsnzI = jd7P1Cs2yTcA0UxaFp(url)
	elif mode==74: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==79: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,79,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'سلسلة افلام',CJlTSEpZsWb0QHg5w,79,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'سلسلة افلام')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'سلاسل منوعة',CJlTSEpZsWb0QHg5w,79,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'سلسلة')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	qe1JPURnS9ODoCNEpbdh8i67Tur = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKOAM-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="partions"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,71)
	return bGIVq1CQTjmosZg
def DT6xAoz34MIGpek7vXUhRJs1rOyYtl(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKOAM-CATEGORIES-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('sect_parts(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,72)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'جميع الفروع',url,72)
	else: nvHUf8mW6E4GSw5VFRXN(url,CJlTSEpZsWb0QHg5w)
	return
def nvHUf8mW6E4GSw5VFRXN(url,type):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('section_title featured_title(.*?)subjects-crousel',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='search':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('akoam_result(.*?)<script',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='more':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('section_title more_title(.*?)footer_bottom_services',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('navigation(.*?)<script',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not items and s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		title = wAmsc95ya0LHz(title)
		if any(value in title for value in VqQYjbA9PTWtfHcI016zlmLuF): khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,73,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,73,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall("</li><li >.*?href='(.*?)'>(.*?)<",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,72,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	return
def l1lzAhFDEKB03RJq(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,True,'AKOAM-SECTIONS-2nd')
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('"href","(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[1]
	return BBwfuWGxUIrdCoc4ka7
def jd7P1Cs2yTcA0UxaFp(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,True,'AKOAM-SECTIONS-1st')
	Cus4cInlrjEUh8fFPtyXJBm6b31Z = Zy2l0g8QU5vqefaTrsw.findall('"(https*://akwam.net/\w+.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	qqKenakWsT9N6vg0GPVEhjyOfiDzX = Zy2l0g8QU5vqefaTrsw.findall('"(https*://underurl.com/\w+.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if Cus4cInlrjEUh8fFPtyXJBm6b31Z or qqKenakWsT9N6vg0GPVEhjyOfiDzX:
		if Cus4cInlrjEUh8fFPtyXJBm6b31Z: ysw7G3tqjo = Cus4cInlrjEUh8fFPtyXJBm6b31Z[0]
		elif qqKenakWsT9N6vg0GPVEhjyOfiDzX: ysw7G3tqjo = l1lzAhFDEKB03RJq(qqKenakWsT9N6vg0GPVEhjyOfiDzX[0])
		ysw7G3tqjo = sWzgdLCjSVwaMuhFkNf1Uop(ysw7G3tqjo)
		import fMhIVs8A5o
		if '/series/' in ysw7G3tqjo or '/shows/' in ysw7G3tqjo: fMhIVs8A5o.j9zTQsrVRx2(ysw7G3tqjo)
		else: fMhIVs8A5o.rHwfOZb3oSgJKi(ysw7G3tqjo)
		return
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	items = Zy2l0g8QU5vqefaTrsw.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = wAmsc95ya0LHz(title)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,73)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo:
		KhwN2zcb7iMkjS5E4WURxByPGon('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,hzGKUP1XjAoeT79MJcDF,D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	name = name.strip(YvOQBzaTAscXR9ql)
	if 'sub_epsiode_title' in D3D6TF50oUBtJlvijPMW8ys:
		items = Zy2l0g8QU5vqefaTrsw.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else:
		RSvlfhinpDGO2ECsANXIgM1jLY8 = Zy2l0g8QU5vqefaTrsw.findall('sub_file_title\'>(.*?) - <i>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		items = []
		for filename in RSvlfhinpDGO2ECsANXIgM1jLY8:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',CJlTSEpZsWb0QHg5w) ]
	count = 0
	Uz8mMbZifCyvkLnct,QdykbVHJeCZawWlIAps4 = [],[]
	size = len(items)
	for title,filename in items:
		B9dhnlXDQ3wt08O1PI = CJlTSEpZsWb0QHg5w
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: B9dhnlXDQ3wt08O1PI = filename.split('.')[-1]
		title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		Uz8mMbZifCyvkLnct.append(title)
		QdykbVHJeCZawWlIAps4.append(count)
		count += 1
	if size>0:
		if any(value in name for value in VqQYjbA9PTWtfHcI016zlmLuF):
			if size==1:
				CrqTamtPFuU = 0
			else:
				CrqTamtPFuU = T4TK17YsEfZJ('اختر الفيديو المناسب:', Uz8mMbZifCyvkLnct)
				if CrqTamtPFuU == -1: return
			rHwfOZb3oSgJKi(url+'?section='+str(1+QdykbVHJeCZawWlIAps4[size-CrqTamtPFuU-1]))
		else:
			for PMTRpXQvDIkiNszwYGnb32a in reversed(range(size)):
				title = name + ' - ' + Uz8mMbZifCyvkLnct[PMTRpXQvDIkiNszwYGnb32a]
				title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				ZgsbN5iSL48t2IhVFnmy = url + '?section='+str(size-PMTRpXQvDIkiNszwYGnb32a)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,74,hzGKUP1XjAoeT79MJcDF)
	else:
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+'الرابط ليس فيديو',CJlTSEpZsWb0QHg5w,9999,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	BBwfuWGxUIrdCoc4ka7,ABK45TEMpciLnmIlYOafQJZ8t = url.split('?section=')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,True,CJlTSEpZsWb0QHg5w,'AKOAM-PLAY_AKOAM-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	nn4Dg5YQqduzrA6ljh8aR91Xf = s67485upzYNMS3PqDelkrdfo[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	nn4Dg5YQqduzrA6ljh8aR91Xf = nn4Dg5YQqduzrA6ljh8aR91Xf + 'direct_link_box'
	p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('epsoide_box(.*?)direct_link_box',nn4Dg5YQqduzrA6ljh8aR91Xf,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ABK45TEMpciLnmIlYOafQJZ8t = len(p3LfChWJd124eAYj78zw09SXonH)-int(ABK45TEMpciLnmIlYOafQJZ8t)
	D3D6TF50oUBtJlvijPMW8ys = p3LfChWJd124eAYj78zw09SXonH[ABK45TEMpciLnmIlYOafQJZ8t]
	FhX9OGwaNyAEZ = []
	rrgEMBDLTdhYak3uG5K = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = Zy2l0g8QU5vqefaTrsw.findall("class='download_btn.*?href='(.*?)'",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy in items:
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named=________akoam')
	items = Zy2l0g8QU5vqefaTrsw.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for NW7SIaOxZ6Yt4FVHTe,ZgsbN5iSL48t2IhVFnmy in items:
		NW7SIaOxZ6Yt4FVHTe = NW7SIaOxZ6Yt4FVHTe.split('/')[-1]
		NW7SIaOxZ6Yt4FVHTe = NW7SIaOxZ6Yt4FVHTe.split('.')[0]
		if NW7SIaOxZ6Yt4FVHTe in rrgEMBDLTdhYak3uG5K:
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+rrgEMBDLTdhYak3uG5K[NW7SIaOxZ6Yt4FVHTe]+'________akoam')
		else: FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+NW7SIaOxZ6Yt4FVHTe+'________akoam')
	if not FhX9OGwaNyAEZ:
		message = Zy2l0g8QU5vqefaTrsw.findall('sub-no-file.*?\n(.*?)\n',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if message: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'رسالة من الموقع الاصلي',message[0])
	else:
		import kORBVznGat
		kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'%20')
	url = V4kF6EQiwo + '/search/'+QjfknOVHzZIUir
	SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'FASELHD2'
headers = {'User-Agent':CJlTSEpZsWb0QHg5w}
kL0nT7NpZdKVD3jM2OHB = '_FH2_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['wwe']
def hH3sRBSFAr(mode,url,text):
	if   mode==590: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==591: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==592: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==593: SD0TxMRXiep4cjPBsnzI = bFsHpJmxDSgKNdReElj(url,text)
	elif mode==599: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	dmiXC1cB7MZlb = V4kF6EQiwo
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',dmiXC1cB7MZlb,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD2-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',dmiXC1cB7MZlb,599,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المميزة',dmiXC1cB7MZlb,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured1')
	items = Zy2l0g8QU5vqefaTrsw.findall('<strong>(.*?)</strong>.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for title,ZgsbN5iSL48t2IhVFnmy in items:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details1')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-menu"(.*?)header-social',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		F6KPrYDQ9XmhI = Zy2l0g8QU5vqefaTrsw.findall('<li (.*?)</li>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for wtJK8x2e7QPUHqFvEnSp6N5yhO1CA in F6KPrYDQ9XmhI:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',wtJK8x2e7QPUHqFvEnSp6N5yhO1CA,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+ZgsbN5iSL48t2IhVFnmy
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details2')
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD2-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	Ix3CrBH47FSjTqk8vDeMbwhl = 0
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"archive-slider(.*?)<h4>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc: zE8URkuN932 = KXu2RYg3Bc[0]
	else: zE8URkuN932 = CJlTSEpZsWb0QHg5w
	if type=='featured1':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"slider-carousel"(.*?)</container>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		h7rNswEfSQKAI9YdVteJzl,RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd = zip(*items)
		items = zip(Rp1g7OlotseGnf0NFmKk6rLxd,h7rNswEfSQKAI9YdVteJzl,RYHIKeQZLBpbNvmhkq2GV1C)
	elif type=='featured2':
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',zE8URkuN932,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='filters':
		s67485upzYNMS3PqDelkrdfo = [bGIVq1CQTjmosZg.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in zE8URkuN932:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<h4>(.*?)</h4>(.*?)</container>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مميزة',url,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured2')
		title = s67485upzYNMS3PqDelkrdfo[0][0]
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details3')
		return
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<h4>(.*?)</h4>(.*?)</container>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		title,D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	wDkMP6jlz7XeN5Sp = []
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if any(value in title.lower() for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
		title = title.strip(YvOQBzaTAscXR9ql)
		title = wAmsc95ya0LHz(title)
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة).\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if '/movseries/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,591,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and type==CJlTSEpZsWb0QHg5w:
			title = '_MOD_'+ABK45TEMpciLnmIlYOafQJZ8t[0][0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,593,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,592,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,593,hzGKUP1XjAoeT79MJcDF)
	if type=='filters':
		xtUMKHZFhcPR38DYErsi6JyT = Zy2l0g8QU5vqefaTrsw.findall('"more_button_page":(.*?),',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if xtUMKHZFhcPR38DYErsi6JyT:
			count = xtUMKHZFhcPR38DYErsi6JyT[0]
			ZgsbN5iSL48t2IhVFnmy = url+'/offset/'+count
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة أخرى',ZgsbN5iSL48t2IhVFnmy,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
	elif 'details' in type:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = 'صفحة '+wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,591,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details4')
	return
def bFsHpJmxDSgKNdReElj(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD2-SEASONS_EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	K5ic8ROYfn1 = False
	if not type:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<seasons(.*?)</seasons>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if len(items)>1:
				dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
				K5ic8ROYfn1 = True
				for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
					title = wAmsc95ya0LHz(title)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,593,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,'episodes')
	if type=='episodes' or not K5ic8ROYfn1:
		t4zynV13ZoPe = Zy2l0g8QU5vqefaTrsw.findall('<bkز*?image:url\((.*?)\)"></bk>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if t4zynV13ZoPe: hzGKUP1XjAoeT79MJcDF = t4zynV13ZoPe[0]
		else: hzGKUP1XjAoeT79MJcDF = CJlTSEpZsWb0QHg5w
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<all-episodes(.*?)</all-episodes>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,592,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ,QrwmKPNDRbUsOLHIBG,mqk6U7HgpIBNdl9fxJ0KzTsj = [],[],[]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD2-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	kUZ2x0bjALaXpzdY4Ef7 = Zy2l0g8QU5vqefaTrsw.findall('العمر :.*?<strong">(.*?)</strong>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if kUZ2x0bjALaXpzdY4Ef7 and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,kUZ2x0bjALaXpzdY4Ef7): return
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('<iframe src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named=__embed')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<slice-title(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-url="(.*?)".*?</i>(.*?)</li>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			name = name.strip(YvOQBzaTAscXR9ql)
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__watch')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<downloads(.*?)</downloads>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</div>(.*?)</div>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__download')
	for VBvgS8MG7Qn in FhX9OGwaNyAEZ:
		ZgsbN5iSL48t2IhVFnmy,name = VBvgS8MG7Qn.split('?named')
		if ZgsbN5iSL48t2IhVFnmy not in QrwmKPNDRbUsOLHIBG:
			QrwmKPNDRbUsOLHIBG.append(ZgsbN5iSL48t2IhVFnmy)
			mqk6U7HgpIBNdl9fxJ0KzTsj.append(VBvgS8MG7Qn)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(mqk6U7HgpIBNdl9fxJ0KzTsj,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	dmiXC1cB7MZlb = V4kF6EQiwo
	url = dmiXC1cB7MZlb+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url,'details5')
	return
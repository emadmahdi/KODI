# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'SHAHID4U'
kL0nT7NpZdKVD3jM2OHB = '_SH4_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
headers = {'User-Agent':jQW9RpucaCLHX0sSBD6lrif58e47nt(True)}
qe1JPURnS9ODoCNEpbdh8i67Tur = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def hH3sRBSFAr(mode,url,text):
	if   mode==110: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==111: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==112: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==113: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url,True)
	elif mode==114: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'FULL_FILTER___'+text)
	elif mode==115: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'DEFINED_FILTER___'+text)
	elif mode==116: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url,False)
	elif mode==119: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(bqIufCQz2OWExjilm.url,'url')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,119,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر محدد',dmiXC1cB7MZlb,115)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر كامل',dmiXC1cB7MZlb,114)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المميزة',dmiXC1cB7MZlb,111,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('simple-filter(.*?)adv-filter',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for filter,hzGKUP1XjAoeT79MJcDF,title in items:
			url = dmiXC1cB7MZlb+filter
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,url,111,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,filter)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="dropdown"(.*?)<script>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+ZgsbN5iSL48t2IhVFnmy
			if 'netflix' in ZgsbN5iSL48t2IhVFnmy: title = 'نيتفلكس'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,111)
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url,Gy3m1diZPVuoMc2hWI6LpN=CJlTSEpZsWb0QHg5w,bqIufCQz2OWExjilm=CJlTSEpZsWb0QHg5w):
	if not bqIufCQz2OWExjilm: bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo,items,wDkMP6jlz7XeN5Sp = [],[],[]
	if Gy3m1diZPVuoMc2hWI6LpN=='featured': s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('glide__slides(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('shows-container(.*?)pagination',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if not items: items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if 'WWE' in title: continue
		if 'javascript' in ZgsbN5iSL48t2IhVFnmy: continue
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy).strip('/')
		title = wAmsc95ya0LHz(title)
		title = title.strip(YvOQBzaTAscXR9ql)
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if '/film/' in ZgsbN5iSL48t2IhVFnmy or 'فيلم' in ZgsbN5iSL48t2IhVFnmy or any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,112,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,113,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif '/actor/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,111,hzGKUP1XjAoeT79MJcDF)
		elif '/series/' in ZgsbN5iSL48t2IhVFnmy and '/list' not in url:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'/list'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,111,hzGKUP1XjAoeT79MJcDF)
		elif '/list' in url and 'حلقة' in title:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,112,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,113,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		if Gy3m1diZPVuoMc2hWI6LpN!='search': items = Zy2l0g8QU5vqefaTrsw.findall('(updateQuery).*?>(.+?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		else: items = Zy2l0g8QU5vqefaTrsw.findall('<li>.*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)
			title = title.strip(YvOQBzaTAscXR9ql)
			if Gy3m1diZPVuoMc2hWI6LpN!='search':
				if '?' in url: ZgsbN5iSL48t2IhVFnmy = url+'&page='+title
				else: ZgsbN5iSL48t2IhVFnmy = url+'?page='+title
			title = wAmsc95ya0LHz(title)
			if title: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,111,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Gy3m1diZPVuoMc2hWI6LpN)
	return
def j9zTQsrVRx2(url,yAMnNuaofHiURFEvrgY):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('items d-flex(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if len(s67485upzYNMS3PqDelkrdfo)>1:
		if '/season/' in s67485upzYNMS3PqDelkrdfo[0]: K5ic8ROYfn1,iypksRX5aYC = s67485upzYNMS3PqDelkrdfo[0],s67485upzYNMS3PqDelkrdfo[1]
		else: K5ic8ROYfn1,iypksRX5aYC = s67485upzYNMS3PqDelkrdfo[1],s67485upzYNMS3PqDelkrdfo[0]
	else: K5ic8ROYfn1,iypksRX5aYC = s67485upzYNMS3PqDelkrdfo[0],s67485upzYNMS3PqDelkrdfo[0]
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(2):
		if yAMnNuaofHiURFEvrgY: mode,type,D3D6TF50oUBtJlvijPMW8ys = 116,'folder',K5ic8ROYfn1
		else: mode,type,D3D6TF50oUBtJlvijPMW8ys = 112,'video',iypksRX5aYC
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if yAMnNuaofHiURFEvrgY and len(items)<2:
			yAMnNuaofHiURFEvrgY = False
			continue
		for ZgsbN5iSL48t2IhVFnmy,xhPQw3M2SrXTOm8B,II4x930lvTuVqekXBNCrMy in items:
			title = xhPQw3M2SrXTOm8B+YvOQBzaTAscXR9ql+II4x930lvTuVqekXBNCrMy
			khqge7BVD9jPFy1S8T5Gn4QAlH(type,kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,mode)
		break
	if not items and '/episodes' in bGIVq1CQTjmosZg:
		sZHU5RDWVxjfCw = Zy2l0g8QU5vqefaTrsw.findall('class="breadcrumb"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if sZHU5RDWVxjfCw:
			D3D6TF50oUBtJlvijPMW8ys = sZHU5RDWVxjfCw[0]
			Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if len(Rp1g7OlotseGnf0NFmKk6rLxd)>2:
				ZgsbN5iSL48t2IhVFnmy = Rp1g7OlotseGnf0NFmKk6rLxd[2]+'list'
				nvHUf8mW6E4GSw5VFRXN(ZgsbN5iSL48t2IhVFnmy)
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="actions(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	Z54mYpHBjiXNoG0ztgCkQS = '/watch/' in D3D6TF50oUBtJlvijPMW8ys
	download = '/download/' in D3D6TF50oUBtJlvijPMW8ys
	if   Z54mYpHBjiXNoG0ztgCkQS and not download: ah5I287fAEQ,zDTnLvw6oUaGWR0dFyux1 = Rp1g7OlotseGnf0NFmKk6rLxd[0],CJlTSEpZsWb0QHg5w
	elif not Z54mYpHBjiXNoG0ztgCkQS and download: ah5I287fAEQ,zDTnLvw6oUaGWR0dFyux1 = CJlTSEpZsWb0QHg5w,Rp1g7OlotseGnf0NFmKk6rLxd[0]
	elif Z54mYpHBjiXNoG0ztgCkQS and download: ah5I287fAEQ,zDTnLvw6oUaGWR0dFyux1 = Rp1g7OlotseGnf0NFmKk6rLxd[0],Rp1g7OlotseGnf0NFmKk6rLxd[1]
	else: ah5I287fAEQ,zDTnLvw6oUaGWR0dFyux1 = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	MNXzjK3vV7D = []
	if Z54mYpHBjiXNoG0ztgCkQS:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',ah5I287fAEQ,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-PLAY-2nd')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('let servers(.*?)player',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if KXu2RYg3Bc:
			zE8URkuN932 = KXu2RYg3Bc[0]
			B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('"name":"(.*?)".*?"url":"(.*?)"',zE8URkuN932,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for title,ZgsbN5iSL48t2IhVFnmy in B5vY7qZAFfeTcXnpCGP9SRr0kaHV:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('\\/','/')
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if download:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',zDTnLvw6oUaGWR0dFyux1,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-PLAY-3rd')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"servers"(.*?)info-container',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if KXu2RYg3Bc:
			zE8URkuN932 = KXu2RYg3Bc[0]
			B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',zE8URkuN932,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title,egYIsS2qROfpVW83kx in B5vY7qZAFfeTcXnpCGP9SRr0kaHV:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download'+'____'+egYIsS2qROfpVW83kx
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search:
		search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not search: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/search?s='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
def oRdVakZGH609MievEIKTyB(url):
	url = url.split('/smartemadfilter?')[0]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('adv-filter(.*?)shows-container',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		bXYD7OZPULlNcp6gtSEMWiau5FAdy = Zy2l0g8QU5vqefaTrsw.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		DBmwSrWc5hLaR3I4XHb86y2jtO1,CCImnA9gHWYJreXMB,p3LfChWJd124eAYj78zw09SXonH = zip(*bXYD7OZPULlNcp6gtSEMWiau5FAdy)
		bXYD7OZPULlNcp6gtSEMWiau5FAdy = zip(CCImnA9gHWYJreXMB,DBmwSrWc5hLaR3I4XHb86y2jtO1,p3LfChWJd124eAYj78zw09SXonH)
	return bXYD7OZPULlNcp6gtSEMWiau5FAdy
def rrxJkwNntpTHQiO6yvEZFocC(D3D6TF50oUBtJlvijPMW8ys):
	items = Zy2l0g8QU5vqefaTrsw.findall('value="(.*?)".*?>\s*(.*?)\s*<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	return items
def OPJyENVHqRaAcj2gZ(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	R9RzvLZDnPb = url.split('/smartemadfilter?')[0]
	cJXaNYSwQ0BP9bUgM = fUSgd7IjGYX496Hr25uFMl(url,'url')
	url = url.replace(R9RzvLZDnPb,cJXaNYSwQ0BP9bUgM)
	url = url.replace('/smartemadfilter?','/?')
	return url
HHRLnzapUIMAqJhB9o31E8 = ['quality','year','genre','category']
UxHo4glmcr = ['category','genre','year']
def wwkAylgOx852(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='DEFINED_FILTER':
		if UxHo4glmcr[0]+'=' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = UxHo4glmcr[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(UxHo4glmcr[0:-1])):
			if UxHo4glmcr[PMTRpXQvDIkiNszwYGnb32a]+'=' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = UxHo4glmcr[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+y3LbIjrZvcATpNDM+'=0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+y3LbIjrZvcATpNDM+'=0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&')+'___'+YYvW68idVrJQFa.strip('&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='FULL_FILTER':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm!=CJlTSEpZsWb0QHg5w: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		if bnCVRhKEGJ0DIYqUBsgdpm==CJlTSEpZsWb0QHg5w: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+bnCVRhKEGJ0DIYqUBsgdpm
		ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها ',ysw7G3tqjo,111)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',ysw7G3tqjo,111)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = oRdVakZGH609MievEIKTyB(url)
	dict = {}
	for name,HLQNhXe7orPjl5Vm4,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		name = name.replace('كل ',CJlTSEpZsWb0QHg5w)
		items = rrxJkwNntpTHQiO6yvEZFocC(D3D6TF50oUBtJlvijPMW8ys)
		if '=' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='DEFINED_FILTER':
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<2:
				if HLQNhXe7orPjl5Vm4==UxHo4glmcr[-1]:
					ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
					nvHUf8mW6E4GSw5VFRXN(ysw7G3tqjo)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'DEFINED_FILTER___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				if HLQNhXe7orPjl5Vm4==UxHo4glmcr[-1]:
					ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',ysw7G3tqjo,111)
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,115,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='FULL_FILTER':
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'=0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'=0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع :'+name,BBwfuWGxUIrdCoc4ka7,114,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		dict[HLQNhXe7orPjl5Vm4] = {}
		for value,ll5WFBCJKhA64tIDT8qvX in items:
			if value=='196533': ll5WFBCJKhA64tIDT8qvX = 'أفلام نيتفلكس'
			elif value=='196531': ll5WFBCJKhA64tIDT8qvX = 'مسلسلات نيتفلكس'
			if ll5WFBCJKhA64tIDT8qvX in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			dict[HLQNhXe7orPjl5Vm4][value] = ll5WFBCJKhA64tIDT8qvX
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'='+ll5WFBCJKhA64tIDT8qvX
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			title = ll5WFBCJKhA64tIDT8qvX+' :'#+dict[HLQNhXe7orPjl5Vm4]['0']
			title = ll5WFBCJKhA64tIDT8qvX+' :'+name
			if type=='FULL_FILTER': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,114,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
			elif type=='DEFINED_FILTER' and UxHo4glmcr[-2]+'=' in LLnTmNF7UG4:
				mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'modified_filters')
				BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+mmMRqiu1zXvWZlK7hAgEQn
				ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ysw7G3tqjo,111)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,115,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.replace('=&','=0&')
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&')
	Sucv4JD0rRPaBL8HFMjNt = {}
	if '=' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('=')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	fuTzgEqmbRX378cwQnJH9rhFCt = CJlTSEpZsWb0QHg5w
	for key in HHRLnzapUIMAqJhB9o31E8:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if '%' not in value: value = O4Ak3NXpyUHvE(value)
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
		elif mode=='all': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.replace('=0','=')
	return fuTzgEqmbRX378cwQnJH9rhFCt
# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from LA3rP81q4u import *
import base64 as qqth6cAFkaRowLlUeMng
T1QDsJlUtCGhn = E6xdOMpqISHZCn(u"ࠬࡒࡉࡃࡕࡗ࡛ࡔ࠭෰")
if A7Z6OVh20eCEUx:
	I6wir0ERy4koOXTzpLCmcl3udPbG = xtcZXNgkYM8wFOpCo70dl6HqRs.translatePath(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡻࡦࡲࡩࠧ෱"))
	p8QdZEXV573CWMLmY4bvO = xtcZXNgkYM8wFOpCo70dl6HqRs.translatePath(HaTI5u1f3SCxmMAkw(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨෲ"))
	nFM6jLciQ0zPA4Xb2hReVWSTqNv = xtcZXNgkYM8wFOpCo70dl6HqRs.translatePath(JACnOz297UuDK5HpPkc1LF(u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡱࡵࡧࡱࡣࡷ࡬ࠬෳ"))
	JTRCZri9Oka5mAUslqIhz0 = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,JACnOz297UuDK5HpPkc1LF(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ෴"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ෵"),cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡆࡪࡤࡰࡰࡶ࠷࠸࠴ࡤࡣࠩ෶"))
	uu6WUP2JdYkqXbiDhoyI = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,HaTI5u1f3SCxmMAkw(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ෷"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨ෸"),KA26GucUHOwXL(u"ࠧࡗ࡫ࡨࡻࡒࡵࡤࡦࡵ࠹࠲ࡩࡨࠧ෹"))
	m5tz1IW6Es3SMKRAc = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,E6xdOMpqISHZCn(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ෺"),zQGaM7ctZCN(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ෻"),JACnOz297UuDK5HpPkc1LF(u"ࠪࡘࡪࡾࡴࡶࡴࡨࡷ࠶࠹࠮ࡥࡤࠪ෼"))
	jWsfaIrEp2PiO0q9ygBvn4L = yylSaxCLfkte(u"ࡹࠬࡢࡵ࠱࠴ࡧ࠵ࠬ෽")
	from urllib.parse import quote as _JdrOnR5SHp
else:
	I6wir0ERy4koOXTzpLCmcl3udPbG = pKVikfGen4wMt80UTscxWjAoCZ5S.translatePath(KA26GucUHOwXL(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡺࡥࡱࡨ࠭෾"))
	p8QdZEXV573CWMLmY4bvO = pKVikfGen4wMt80UTscxWjAoCZ5S.translatePath(yylSaxCLfkte(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ෿"))
	nFM6jLciQ0zPA4Xb2hReVWSTqNv = pKVikfGen4wMt80UTscxWjAoCZ5S.translatePath(cjVhOCwybeRo7UWg92(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡰࡴ࡭ࡰࡢࡶ࡫ࠫ฀"))
	JTRCZri9Oka5mAUslqIhz0 = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,VVvcQpCU3OM09n(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪก"),yylSaxCLfkte(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫข"),cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡅࡩࡪ࡯࡯ࡵ࠵࠻࠳ࡪࡢࠨฃ"))
	uu6WUP2JdYkqXbiDhoyI = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ค"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧฅ"),Olh7n0zfV4(u"࠭ࡖࡪࡧࡺࡑࡴࡪࡥࡴ࠸࠱ࡨࡧ࠭ฆ"))
	m5tz1IW6Es3SMKRAc = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩง"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡆࡤࡸࡦࡨࡡࡴࡧࠪจ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡗࡩࡽࡺࡵࡳࡧࡶ࠵࠸࠴ࡤࡣࠩฉ"))
	jWsfaIrEp2PiO0q9ygBvn4L = s97s2k0LJgl(u"ࡸࠫࡡࡻ࠰࠳ࡦ࠴ࠫช").encode(Im5KSGZYBpRvdMVsbuXg)
	from urllib import quote as _JdrOnR5SHp
khYtrEzRsjxXW49NwMI = tiFgl4DMvGEAUfjIYkHbr05.path.join(nFM6jLciQ0zPA4Xb2hReVWSTqNv,EcjO3giln2kQTdBY0XLAG(u"ࠫࡰࡵࡤࡪ࠰࡯ࡳ࡬࠭ซ"))
PM4ReYxV1qtQ9 = tiFgl4DMvGEAUfjIYkHbr05.path.join(nFM6jLciQ0zPA4Xb2hReVWSTqNv,XB4CjMkPFzhAHiI3q(u"ࠬࡱ࡯ࡥ࡫࠱ࡳࡱࡪ࠮࡭ࡱࡪࠫฌ"))
ooPr6flc8dLHJy2gT = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡩࡱࡶࡹ࠵ࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨญ"))
llf964iOnja3wbS5 = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,yylSaxCLfkte(u"ࠧࡪࡲࡷࡺ࠷ࡪࡡࡵࡣࡢࡣࡤ࠴ࡤࡣࠩฎ"))
VLPYW7ylnbKeCSH = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,EcjO3giln2kQTdBY0XLAG(u"ࠨ࡯࠶ࡹࡩࡧࡴࡢࡡࡢࡣ࠳ࡪࡢࠨฏ"))
wiEebAT9Qs7dCztufUZNORv3 = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡩࡥࡻࡵࡵࡳ࡫ࡷࡩࡸ࠴ࡤࡢࡶࠪฐ"))
bRf59SPvF8VuKEs1MNnyJBhWxYDXgU = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,VVvcQpCU3OM09n(u"ࠪ࡭ࡵࡺࡶࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬฑ"))
oSVWcP6bX0mYFZi = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,HaTI5u1f3SCxmMAkw(u"ࠫࡲ࠹ࡵࡧ࡫࡯ࡩࡤࡥ࡟࠯ࡦࡤࡸࠬฒ"))
CD6FK0opq3A4cYJWN1RHeEUZvti = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,cbmeD4WNZfAowxT2JdUMtV(u"ࠬ࡯࡭ࡢࡩࡨࡷࠬณ"))
yyo93mPZgsESFchqW = tiFgl4DMvGEAUfjIYkHbr05.path.join(CD6FK0opq3A4cYJWN1RHeEUZvti,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡹࠧด"))
Fyf2HUjkrK1 = tiFgl4DMvGEAUfjIYkHbr05.path.join(CD6FK0opq3A4cYJWN1RHeEUZvti,s97s2k0LJgl(u"ࠧ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡹࠧต"))
AY8sKeZnH0TlO5IJFWquizE4Sda = tiFgl4DMvGEAUfjIYkHbr05.path.join(yyo93mPZgsESFchqW,cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡦ࡬ࡥࡱࡵࡧࡠ࠲࠳࠴࠵ࡥ࠮ࡱࡰࡪࠫถ"))
cizLW9VxEA2Nkqj7wtspB8HyT1X = BDgtaC2sJxV7Efq5.Addon().getAddonInfo(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡳࡥࡹ࡮ࠧท"))
H8aQPb6yKV7 = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,zQGaM7ctZCN(u"ࠪ࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬธ"))
IfkOnNurXscQ59BjgPCWJat3p = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡹ࡮ࡵ࡮ࡤ࠱ࡴࡳ࡭ࠧน"))
K6zfygOCsulWIVhAjL2mqdDHTFPJ = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࡬ࡡ࡯ࡣࡵࡸ࠳ࡶ࡮ࡨࠩบ"))
cD2Xug7aMLwNdAW5qJtkoTY4UmG = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,XB4CjMkPFzhAHiI3q(u"࠭ࡢࡢࡰࡱࡩࡷ࠴ࡰ࡯ࡩࠪป"))
hhMnWFSwUs2CuPQ5RDg = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,TDpFsQXHze2q30uYtGPfEIm8(u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧ࠱ࡴࡳ࡭ࠧผ"))
wRbVYJv3tqiscHeGZy0DWoAxXlN12 = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,otNfFapeEnO(u"ࠨࡲࡲࡷࡹ࡫ࡲ࠯ࡲࡱ࡫ࠬฝ"))
hsBygdxXNqLfvwaAZ1 = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,KA26GucUHOwXL(u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳ࠳ࡶ࡮ࡨࠩพ"))
EiTD82yI6CaKf = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸ࠳ࡶ࡮ࡨࠩฟ"))
w3uWGPObsEe1FNcZIgm72VRh6v = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡲ࡫࡮ࡶࡡࡵࡩࡩࡥ࠲࠱࠲ࡻ࠶࠺࠶࠮ࡱࡰࡪࠫภ"))
peNQPA4nfl320OYG7M = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡩࡨࡢࡰࡪࡩࡱࡵࡧ࠯ࡶࡻࡸࠬม"))
ORM3fVHnueUmCZhN57EF = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,XB4CjMkPFzhAHiI3q(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ย"))
mniV78zXC39fbN = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡶࡵࡨࡶࡩࡧࡴࡢࠩร"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬฤ"),R7xafKV3ekjDc)
uuUjvrQcey5 = tiFgl4DMvGEAUfjIYkHbr05.path.join(mniV78zXC39fbN,E6xdOMpqISHZCn(u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨล"))
JHZcO82T74nUWCuvym = tiFgl4DMvGEAUfjIYkHbr05.path.join(I6wir0ERy4koOXTzpLCmcl3udPbG,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡱࡪࡪࡩࡢࠩฦ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡋࡵ࡮ࡵࡵࠪว"),JACnOz297UuDK5HpPkc1LF(u"ࠬࡧࡲࡪࡣ࡯࠲ࡹࡺࡦࠨศ"))
ICZn7jmudQ6oMWByqhzwTis = set(Ew2zQ8u7Ss.BADWEBSITES)
WZ7itqR9KanXm2cYeGx3dMNTI4 = [jglfWFcvo1mAdH9yeROS7XKNxu for jglfWFcvo1mAdH9yeROS7XKNxu in WZ7itqR9KanXm2cYeGx3dMNTI4 if jglfWFcvo1mAdH9yeROS7XKNxu not in ICZn7jmudQ6oMWByqhzwTis]
GzM4fSLbdKhkCTHX01ORYFq9W3P = [jglfWFcvo1mAdH9yeROS7XKNxu for jglfWFcvo1mAdH9yeROS7XKNxu in GzM4fSLbdKhkCTHX01ORYFq9W3P if jglfWFcvo1mAdH9yeROS7XKNxu not in ICZn7jmudQ6oMWByqhzwTis]
rBou7qEXe4GUPnYMp6Af9yh = [jglfWFcvo1mAdH9yeROS7XKNxu for jglfWFcvo1mAdH9yeROS7XKNxu in rBou7qEXe4GUPnYMp6Af9yh if jglfWFcvo1mAdH9yeROS7XKNxu not in ICZn7jmudQ6oMWByqhzwTis]
wt8VeLoQTG2A49pSNF5 = [jglfWFcvo1mAdH9yeROS7XKNxu for jglfWFcvo1mAdH9yeROS7XKNxu in wt8VeLoQTG2A49pSNF5 if jglfWFcvo1mAdH9yeROS7XKNxu not in ICZn7jmudQ6oMWByqhzwTis]
bXd1yvHnFAG = [jglfWFcvo1mAdH9yeROS7XKNxu for jglfWFcvo1mAdH9yeROS7XKNxu in bXd1yvHnFAG if jglfWFcvo1mAdH9yeROS7XKNxu not in ICZn7jmudQ6oMWByqhzwTis]
class bVxDucoEdAsq7YfZLCRMe3m5nyW(bdXCmFHx35lTsQwi6):
	def __init__(rOXJKGtIFyuP4aZEkwQ3,*aargs,**kkwargs):
		rOXJKGtIFyuP4aZEkwQ3.choiceID = -P2Fgh6TCOWoaHjkqBcQnvRNXe
	def onClick(rOXJKGtIFyuP4aZEkwQ3,sBwW7dUkL3eAJMt):
		if sBwW7dUkL3eAJMt>=HaTI5u1f3SCxmMAkw(u"࠿࠰࠲࠲ᑬ"): rOXJKGtIFyuP4aZEkwQ3.choiceID = sBwW7dUkL3eAJMt-HaTI5u1f3SCxmMAkw(u"࠿࠰࠲࠲ᑬ")
		rOXJKGtIFyuP4aZEkwQ3.iYOKxb4qvpotC0EnmGwZS3()
	def vP57fmg8nMAoN4XLz(rOXJKGtIFyuP4aZEkwQ3,*aargs):
		rOXJKGtIFyuP4aZEkwQ3.button0,rOXJKGtIFyuP4aZEkwQ3.button1,rOXJKGtIFyuP4aZEkwQ3.button2 = aargs[ZVNvqy4iF1a9X],aargs[P2Fgh6TCOWoaHjkqBcQnvRNXe],aargs[VTadWjBloMwXO2CH9GDK6FR]
		rOXJKGtIFyuP4aZEkwQ3.header,rOXJKGtIFyuP4aZEkwQ3.text = aargs[D9yBM7wPFLz],aargs[P3cpaLN2sH]
		rOXJKGtIFyuP4aZEkwQ3.profile,rOXJKGtIFyuP4aZEkwQ3.direction = aargs[KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠵ᑭ")],aargs[I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠷ᑮ")]
		rOXJKGtIFyuP4aZEkwQ3.buttonstimeout,rOXJKGtIFyuP4aZEkwQ3.closetimeout = aargs[rC5tnFDlQcRGA2(u"࠺ᑰ")],aargs[KA26GucUHOwXL(u"࠺ᑯ")]
		if rOXJKGtIFyuP4aZEkwQ3.buttonstimeout>ZVNvqy4iF1a9X or rOXJKGtIFyuP4aZEkwQ3.closetimeout>rC5tnFDlQcRGA2(u"࠴ᑱ"): rOXJKGtIFyuP4aZEkwQ3.enable_progressbar = w2qb6lf5EM
		else: rOXJKGtIFyuP4aZEkwQ3.enable_progressbar = VJZIMkUN5siqB21Pf
		rOXJKGtIFyuP4aZEkwQ3.image_filename = AY8sKeZnH0TlO5IJFWquizE4Sda.replace(KA26GucUHOwXL(u"࠭࡟࠱࠲࠳࠴ࡤ࠭ษ"),yylSaxCLfkte(u"ࠧࡠࠩส")+str(L8Wkv5KCSoq.time())+mi2ZJXCDzITuyev6gfn(u"ࠨࡡࠪห"))
		rOXJKGtIFyuP4aZEkwQ3.image_filename = rOXJKGtIFyuP4aZEkwQ3.image_filename.replace(EcjO3giln2kQTdBY0XLAG(u"ࠩ࡟ࡠࠬฬ"),HaTI5u1f3SCxmMAkw(u"ࠪࡠࡡࡢ࡜ࠨอ")).replace(GISOTJh20W(u"ࠫ࠴࠵ࠧฮ"),EcjO3giln2kQTdBY0XLAG(u"ࠬ࠵࠯࠰࠱ࠪฯ"))
		rOXJKGtIFyuP4aZEkwQ3.image_height = sXRCiumten85HYp2xy7va1wQl(rOXJKGtIFyuP4aZEkwQ3.button0,rOXJKGtIFyuP4aZEkwQ3.button1,rOXJKGtIFyuP4aZEkwQ3.button2,rOXJKGtIFyuP4aZEkwQ3.header,rOXJKGtIFyuP4aZEkwQ3.text,rOXJKGtIFyuP4aZEkwQ3.profile,rOXJKGtIFyuP4aZEkwQ3.direction,rOXJKGtIFyuP4aZEkwQ3.enable_progressbar,rOXJKGtIFyuP4aZEkwQ3.image_filename)
		rOXJKGtIFyuP4aZEkwQ3.show()
		rOXJKGtIFyuP4aZEkwQ3.getControl(pz4WBwfyDdgk0m2aRr7SMv(u"࠾࠶࠵࠱ᑲ")).setImage(rOXJKGtIFyuP4aZEkwQ3.image_filename)
		rOXJKGtIFyuP4aZEkwQ3.getControl(pz4WBwfyDdgk0m2aRr7SMv(u"࠿࠰࠶࠲ᑳ")).setHeight(rOXJKGtIFyuP4aZEkwQ3.image_height)
		if not rOXJKGtIFyuP4aZEkwQ3.button1 and rOXJKGtIFyuP4aZEkwQ3.button0 and rOXJKGtIFyuP4aZEkwQ3.button2: rOXJKGtIFyuP4aZEkwQ3.getControl(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠺࠲࠴࠶ᑵ")).setPosition(-mi2ZJXCDzITuyev6gfn(u"࠴࠵࠴ᑶ"),E6xdOMpqISHZCn(u"࠰ᑴ"))
		return rOXJKGtIFyuP4aZEkwQ3.image_filename,rOXJKGtIFyuP4aZEkwQ3.image_height
	def I9WQZn1x0Hlhd(rOXJKGtIFyuP4aZEkwQ3):
		if rOXJKGtIFyuP4aZEkwQ3.buttonstimeout:
			rOXJKGtIFyuP4aZEkwQ3.th1 = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=rOXJKGtIFyuP4aZEkwQ3.MagHJzCcA6LQj7T)
			rOXJKGtIFyuP4aZEkwQ3.th1.start()
		else: rOXJKGtIFyuP4aZEkwQ3.ccTEyDs9HGBo1()
	def MagHJzCcA6LQj7T(rOXJKGtIFyuP4aZEkwQ3):
		rOXJKGtIFyuP4aZEkwQ3.getControl(rC5tnFDlQcRGA2(u"࠼࠴࠷࠶ᑷ")).setEnabled(w2qb6lf5EM)
		for LxNV5lenkhW6zoBJDMA7ZuqSg in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,rOXJKGtIFyuP4aZEkwQ3.buttonstimeout+P2Fgh6TCOWoaHjkqBcQnvRNXe):
			L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
			fIqb5WkhVZHrG1iY6 = int(HaTI5u1f3SCxmMAkw(u"࠵࠵࠶ᑸ")*LxNV5lenkhW6zoBJDMA7ZuqSg/rOXJKGtIFyuP4aZEkwQ3.buttonstimeout)
			rOXJKGtIFyuP4aZEkwQ3.uePpZnIE9hYmfltdr(fIqb5WkhVZHrG1iY6)
			if rOXJKGtIFyuP4aZEkwQ3.choiceID>Olh7n0zfV4(u"࠵ᑹ"): break
		rOXJKGtIFyuP4aZEkwQ3.ccTEyDs9HGBo1()
	def B4L8Tw1fcs0SACMEQIo5t(rOXJKGtIFyuP4aZEkwQ3):
		if rOXJKGtIFyuP4aZEkwQ3.closetimeout:
			rOXJKGtIFyuP4aZEkwQ3.th2 = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=rOXJKGtIFyuP4aZEkwQ3.XpKM1Ub3rnAygP8VDqO5edcvNQ2tzo)
			rOXJKGtIFyuP4aZEkwQ3.th2.start()
		else: rOXJKGtIFyuP4aZEkwQ3.ccTEyDs9HGBo1()
	def XpKM1Ub3rnAygP8VDqO5edcvNQ2tzo(rOXJKGtIFyuP4aZEkwQ3):
		rOXJKGtIFyuP4aZEkwQ3.getControl(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠿࠰࠳࠲ᑺ")).setEnabled(w2qb6lf5EM)
		L8Wkv5KCSoq.sleep(rOXJKGtIFyuP4aZEkwQ3.buttonstimeout)
		for LxNV5lenkhW6zoBJDMA7ZuqSg in range(rOXJKGtIFyuP4aZEkwQ3.closetimeout-P2Fgh6TCOWoaHjkqBcQnvRNXe,-P2Fgh6TCOWoaHjkqBcQnvRNXe,-P2Fgh6TCOWoaHjkqBcQnvRNXe):
			L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
			fIqb5WkhVZHrG1iY6 = int(O4F8UC5lMAS6ghETm1VoPDI(u"࠱࠱࠲ᑻ")*LxNV5lenkhW6zoBJDMA7ZuqSg/rOXJKGtIFyuP4aZEkwQ3.closetimeout)
			rOXJKGtIFyuP4aZEkwQ3.uePpZnIE9hYmfltdr(fIqb5WkhVZHrG1iY6)
			if rOXJKGtIFyuP4aZEkwQ3.choiceID>ZVNvqy4iF1a9X: break
		if rOXJKGtIFyuP4aZEkwQ3.closetimeout>ZVNvqy4iF1a9X: rOXJKGtIFyuP4aZEkwQ3.choiceID = VVvcQpCU3OM09n(u"࠲࠲ᑼ")
		rOXJKGtIFyuP4aZEkwQ3.iYOKxb4qvpotC0EnmGwZS3()
	def uePpZnIE9hYmfltdr(rOXJKGtIFyuP4aZEkwQ3,fIqb5WkhVZHrG1iY6):
		rOXJKGtIFyuP4aZEkwQ3.precent = fIqb5WkhVZHrG1iY6
		rOXJKGtIFyuP4aZEkwQ3.getControl(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠻࠳࠶࠵ᑽ")).setPercent(rOXJKGtIFyuP4aZEkwQ3.precent)
	def ccTEyDs9HGBo1(rOXJKGtIFyuP4aZEkwQ3):
		if rOXJKGtIFyuP4aZEkwQ3.button0: rOXJKGtIFyuP4aZEkwQ3.getControl(TDpFsQXHze2q30uYtGPfEIm8(u"࠼࠴࠶࠶ᑾ")).setEnabled(w2qb6lf5EM)
		if rOXJKGtIFyuP4aZEkwQ3.button1: rOXJKGtIFyuP4aZEkwQ3.getControl(EcjO3giln2kQTdBY0XLAG(u"࠽࠵࠷࠱ᑿ")).setEnabled(w2qb6lf5EM)
		if rOXJKGtIFyuP4aZEkwQ3.button2: rOXJKGtIFyuP4aZEkwQ3.getControl(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠾࠶࠱࠳ᒀ")).setEnabled(w2qb6lf5EM)
	def iYOKxb4qvpotC0EnmGwZS3(rOXJKGtIFyuP4aZEkwQ3):
		rOXJKGtIFyuP4aZEkwQ3.close()
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(rOXJKGtIFyuP4aZEkwQ3.image_filename)
		except: pass
class x74xDjR1rFbNiWh():
	def __init__(rOXJKGtIFyuP4aZEkwQ3,showDialogs=VJZIMkUN5siqB21Pf,logErrors=w2qb6lf5EM):
		rOXJKGtIFyuP4aZEkwQ3.showDialogs = showDialogs
		rOXJKGtIFyuP4aZEkwQ3.logErrors = logErrors
		rOXJKGtIFyuP4aZEkwQ3.finishedLIST,rOXJKGtIFyuP4aZEkwQ3.failedLIST = [],[]
		rOXJKGtIFyuP4aZEkwQ3.statusDICT,rOXJKGtIFyuP4aZEkwQ3.resultsDICT = {},{}
		rOXJKGtIFyuP4aZEkwQ3.processesLIST = []
		rOXJKGtIFyuP4aZEkwQ3.starttimeDICT,rOXJKGtIFyuP4aZEkwQ3.finishtimeDICT,rOXJKGtIFyuP4aZEkwQ3.elpasedtimeDICT = {},{},{}
	def TyXIMAtvq7bid6JOUuWGl4nQa(rOXJKGtIFyuP4aZEkwQ3,dq7AOIkC9r0,SWRyFq7kbgYN4JH9QmoDOEPsv8axU,*aargs):
		dq7AOIkC9r0 = str(dq7AOIkC9r0)
		rOXJKGtIFyuP4aZEkwQ3.statusDICT[dq7AOIkC9r0] = yylSaxCLfkte(u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧะ")
		if rOXJKGtIFyuP4aZEkwQ3.showDialogs: KhwN2zcb7iMkjS5E4WURxByPGon(CJlTSEpZsWb0QHg5w,dq7AOIkC9r0)
		Q46gK1iwY5dUEG3a = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=rOXJKGtIFyuP4aZEkwQ3.ACcDwrSifHKtqQ1geIoU2E8by9Yu,args=(dq7AOIkC9r0,SWRyFq7kbgYN4JH9QmoDOEPsv8axU,aargs))
		rOXJKGtIFyuP4aZEkwQ3.processesLIST.append(Q46gK1iwY5dUEG3a)
		return Q46gK1iwY5dUEG3a
	def cAw6YbSQ5P1zoDkBp(rOXJKGtIFyuP4aZEkwQ3,dq7AOIkC9r0,SWRyFq7kbgYN4JH9QmoDOEPsv8axU,*aargs):
		Q46gK1iwY5dUEG3a = rOXJKGtIFyuP4aZEkwQ3.TyXIMAtvq7bid6JOUuWGl4nQa(dq7AOIkC9r0,SWRyFq7kbgYN4JH9QmoDOEPsv8axU,*aargs)
		Q46gK1iwY5dUEG3a.start()
	def ACcDwrSifHKtqQ1geIoU2E8by9Yu(rOXJKGtIFyuP4aZEkwQ3,dq7AOIkC9r0,SWRyFq7kbgYN4JH9QmoDOEPsv8axU,aargs):
		dq7AOIkC9r0 = str(dq7AOIkC9r0)
		rOXJKGtIFyuP4aZEkwQ3.starttimeDICT[dq7AOIkC9r0] = L8Wkv5KCSoq.time()
		try:
			rOXJKGtIFyuP4aZEkwQ3.resultsDICT[dq7AOIkC9r0] = SWRyFq7kbgYN4JH9QmoDOEPsv8axU(*aargs)
			if mi2ZJXCDzITuyev6gfn(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࠨั") in str(SWRyFq7kbgYN4JH9QmoDOEPsv8axU) and not rOXJKGtIFyuP4aZEkwQ3.resultsDICT[dq7AOIkC9r0].succeeded: JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
			rOXJKGtIFyuP4aZEkwQ3.finishedLIST.append(dq7AOIkC9r0)
			rOXJKGtIFyuP4aZEkwQ3.statusDICT[dq7AOIkC9r0] = E6xdOMpqISHZCn(u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࠪา")
		except Exception as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
			if rOXJKGtIFyuP4aZEkwQ3.logErrors:
				uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
				if uErMFcVGBXUvtJZ90zCTPxn2YW!=od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬำ"): A8v6c2fL7egwWCF3YBqr4kXSRn.stderr.write(uErMFcVGBXUvtJZ90zCTPxn2YW)
			rOXJKGtIFyuP4aZEkwQ3.failedLIST.append(dq7AOIkC9r0)
			rOXJKGtIFyuP4aZEkwQ3.statusDICT[dq7AOIkC9r0] = EcjO3giln2kQTdBY0XLAG(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪิ")
		rOXJKGtIFyuP4aZEkwQ3.finishtimeDICT[dq7AOIkC9r0] = L8Wkv5KCSoq.time()
		rOXJKGtIFyuP4aZEkwQ3.elpasedtimeDICT[dq7AOIkC9r0] = rOXJKGtIFyuP4aZEkwQ3.finishtimeDICT[dq7AOIkC9r0] - rOXJKGtIFyuP4aZEkwQ3.starttimeDICT[dq7AOIkC9r0]
	def gqVFBJlS3Ls(rOXJKGtIFyuP4aZEkwQ3):
		for oatSMDlHRi0FkXBELpIAgwrPs1 in rOXJKGtIFyuP4aZEkwQ3.processesLIST:
			oatSMDlHRi0FkXBELpIAgwrPs1.start()
	def DhRWdGkFijfQ8ctsU325VNPL(rOXJKGtIFyuP4aZEkwQ3):
		while yylSaxCLfkte(u"ࠫࡷࡻ࡮࡯࡫ࡱ࡫ࠬี") in list(rOXJKGtIFyuP4aZEkwQ3.statusDICT.values()): L8Wkv5KCSoq.sleep(EcjO3giln2kQTdBY0XLAG(u"࠷ᒁ"))
def anBk07yC4SpglWexHzLfXJOFuV():
	if not ohkAjGeH2Rf6Vw4vNM8rJE3tlnO5d: return otNfFapeEnO(u"ࠬࡔࡏࡠࡗࡓࡈࡆ࡚ࡅࠨึ")
	ckGwqSb0hufPm = I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡆࡖࡎࡏࡣ࡚ࡖࡄࡂࡖࡈࠫื")
	YYwUmGVrh701PzEO9BKiW = [cbmeD4WNZfAowxT2JdUMtV(u"ࠧ࠹࠰࠸࠲࠵ุ࠭"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ࠴࠳࠶࠶࠴࠱࠱࠰࠴࠽ูࠬ"),s97s2k0LJgl(u"ࠩ࠵࠴࠷࠷࠮࠲࠳࠱࠶࠹ࡧฺࠧ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪ࠶࠵࠸࠱࠯࠳࠵࠲࠸࠶ࠧ฻"),EcjO3giln2kQTdBY0XLAG(u"ࠫ࠷࠶࠲࠳࠰࠳࠶࠳࠶࠲ࠨ฼"),EcjO3giln2kQTdBY0XLAG(u"ࠬ࠸࠰࠳࠴࠱࠵࠵࠴࠲࠳ࠩ฽"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭࠲࠱࠴࠶࠲࠵࠹࠮࠱࠸ࠪ฾"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧ࠳࠲࠵࠷࠳࠶࠵࠯࠳࠹ࠫ฿"),XB4CjMkPFzhAHiI3q(u"ࠨ࠴࠳࠶࠸࠴࠰࠷࠰࠳࠺ࠬเ"),E6xdOMpqISHZCn(u"ࠩ࠵࠴࠷࠹࠮࠲࠲࠱࠶࠽࠭แ"),EcjO3giln2kQTdBY0XLAG(u"ࠪ࠶࠵࠸࠴࠯࠲࠴࠲࠶࠺ࠧโ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠫ࠷࠶࠲࠵࠰࠳࠻࠳࠸࠰ࠨใ"),Olh7n0zfV4(u"ࠬ࠸࠰࠳࠷࠱࠴࠺࠴࠰࠶ࠩไ")]
	p7gFc0OdkJ = YYwUmGVrh701PzEO9BKiW[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
	peqKdAsw8CXLEt = Gb6AoxXFzh7L2SvVyZpWMuC5etNar(p7gFc0OdkJ)
	JzGhDCxO6cd = Gb6AoxXFzh7L2SvVyZpWMuC5etNar(Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a)
	if JzGhDCxO6cd>peqKdAsw8CXLEt:
		ckGwqSb0hufPm = O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡓࡊࡏࡓࡐࡊࡥࡕࡑࡆࡄࡘࡊ࠭ๅ")
	return ckGwqSb0hufPm
def hxg3VwrTRoJpdMHt7Aj92WcZy1(TpGRx3umFIEKey1i0XNz8CnJ):
	mQ7l3N5rDPuzHq4WXhKJRUIbgw,w0F5skN3cR7QW = CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf
	if TpGRx3umFIEKey1i0XNz8CnJ: mQ7l3N5rDPuzHq4WXhKJRUIbgw = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡴࡶࡵࠫๆ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭็"),yylSaxCLfkte(u"ࠩࡈ࡜࡙ࡘࡁࡑ࡛ࡗࡌࡔࡔࡃࡐࡆࡈ่ࠫ"))
	if not mQ7l3N5rDPuzHq4WXhKJRUIbgw:
		otaunYGVIJ2jX8HsKm7ecR0bAh4 = Ew2zQ8u7Ss.SITESURLS[E6xdOMpqISHZCn(u"ࠪࡔ࡞࡚ࡈࡐࡐ้ࠪ")][KA26GucUHOwXL(u"࠹ᒂ")]
		cl6ybZFW7O0 = {KA26GucUHOwXL(u"ࠫࡺࡹࡥࡳ๊ࠩ"):Ew2zQ8u7Ss.AV_CLIENT_IDS,XB4CjMkPFzhAHiI3q(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ๋࠭"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a}
		mQ7l3N5rDPuzHq4WXhKJRUIbgw = bQs8X1eOM6vauSBpIK5q0tJfDLwNn(XB4CjMkPFzhAHiI3q(u"࠭ࡐࡐࡕࡗࠫ์"),otaunYGVIJ2jX8HsKm7ecR0bAh4,cl6ybZFW7O0,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇ࡟ࡑ࡛ࡗࡌࡔࡔ࡟ࡄࡑࡇࡉ࠲࠷ࡳࡵࠩํ"))
		yfL6aW08mk9wbt75r2cUnVeqSC(Ew2zQ8u7Ss.api_python_actions[cjVhOCwybeRo7UWg92(u"࠺ᒃ")])
		if mQ7l3N5rDPuzHq4WXhKJRUIbgw: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠷࠭๎"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡈ࡜࡙ࡘࡁࡑ࡛ࡗࡌࡔࡔࡃࡐࡆࡈࠫ๏"),mQ7l3N5rDPuzHq4WXhKJRUIbgw,XlNnqz758Zeuo)
		w0F5skN3cR7QW = w2qb6lf5EM
	if mQ7l3N5rDPuzHq4WXhKJRUIbgw:
		global NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS = {},[],{},[]
		exec(mQ7l3N5rDPuzHq4WXhKJRUIbgw,globals(),locals())
		Ew2zQ8u7Ss.SITESURLS.update(NEW_SITESURLS)
		Ew2zQ8u7Ss.BADSCRAPERS = list(set(Ew2zQ8u7Ss.BADSCRAPERS+NEW_BADSCRAPERS))
		Ew2zQ8u7Ss.BADCOMMONIDS = list(set(Ew2zQ8u7Ss.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a in list(NEW_BADWEBSITES.keys()): Ew2zQ8u7Ss.BADWEBSITES += NEW_BADWEBSITES[Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a]
	return w0F5skN3cR7QW
def gghHSYtaECDqIxnLdjkO2KeM3():
	try: tiFgl4DMvGEAUfjIYkHbr05.makedirs(c2XOIv1RU6aSuAeiZ5Pgz9Gr)
	except: pass
	c5c9MivRmbxNBzWEeywITaonFtCD = anBk07yC4SpglWexHzLfXJOFuV()
	if c5c9MivRmbxNBzWEeywITaonFtCD==TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡗࡎࡓࡐࡍࡇࡢ࡙ࡕࡊࡁࡕࡇࠪ๐"): JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,pz4WBwfyDdgk0m2aRr7SMv(u"ࠫ࠳ࡢࡴࡂࡴࡤࡦ࡮ࡩࡖࡪࡦࡨࡳࡸࠦࡕࡱࡦࡤࡸࡪࠦࡔࡺࡲࡨ࠾ࠥࠦࡓࡊࡏࡓࡐࡊࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ๑")+zz4EDG1PtiyX3JVUlBeC+otNfFapeEnO(u"ࠬࠦ࡝ࠨ๒"))
	else: JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࠮࡝ࡶࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡈࡘࡐࡑࠦࡕࡑࡆࡄࡘࡊࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪ๓")+zz4EDG1PtiyX3JVUlBeC+ZP1LyUCS3pIBu(u"ࠧࠡ࡟ࠪ๔"))
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨฬ่ࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ็๊ࠡฮ๊หื้࡜࡯ว็ํࠥอไฦืาหึࠦัใ็࠽ࡠࡳࡢ࡮ࠨ๕")+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a)
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cbmeD4WNZfAowxT2JdUMtV(u"ࠩอ้ࠥะหษ์อࠤศ๎ࠠหฯา๎ะࠦวๅวุำฬืࠠศๆฯำ๏ีࠠๅสิ๊ฬ๋ฬࠡษ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦ࠮ࠡล๋ࠤฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣࡠࡳࡢ࡮ࠡีํๆํ๋ࠠศๆล๊ࠥอไษำ้ห๊าࠠษส฼ฺࠥอไโฯู๋ฬะࠠๅุ่หู๋ࠦๆๆࠣห้ฮั็ษ่ะࠥฮี้ำฬࠤฺำ๊ฮหࠣ์๊ะใศ็็อࠬ๖"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,mi2ZJXCDzITuyev6gfn(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ๗"),JACnOz297UuDK5HpPkc1LF(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ๘"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪ๙"),XB4CjMkPFzhAHiI3q(u"࠭ࡁࡍࡎࡢࡅࡉࡊࡏࡏࡕࡢ࡜ࡒࡒࠧ๚"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠶ࠬ๛"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,cjVhOCwybeRo7UWg92(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫ๜"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡖࡍ࡙ࡋࡓࡠࡐࡄࡑࡊ࡙ࠧ๝"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,XB4CjMkPFzhAHiI3q(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭๞"),rC5tnFDlQcRGA2(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩ๟"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ๠"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡓࡊࡖࡈࡗࡤ࡜ࡅࡓࡋࡉ࡝ࠬ๡"))
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(HaTI5u1f3SCxmMAkw(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡨࡲࡷࡹࡧࠧ๢"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(VVvcQpCU3OM09n(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡧࡸࡡ࡬ࡣࠪ๣"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬ๤"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(yylSaxCLfkte(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲࡫ࡧࡳࡦ࡮࡫ࡨ࠶࠭๥"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡦࡼ࠮ࡱࡴ࡬ࡺࡸ࠷ࠧ๦"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡧࡶ࠯ࡲࡨࡶ࡮ࡵࡤ࠯࡫ࡱࡪࡴࡹࠧ๧"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(s97s2k0LJgl(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ๨"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧ๩"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(JACnOz297UuDK5HpPkc1LF(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬ๪"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ๫"),CJlTSEpZsWb0QHg5w)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬ๬"),CJlTSEpZsWb0QHg5w)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,rC5tnFDlQcRGA2(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡓࡊࡖࡈࡗࠬ๭"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,EcjO3giln2kQTdBY0XLAG(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡊࡒࡗ࡚ࠬ๮"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬ๯"))
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,otNfFapeEnO(u"ࠧࡔࡅࡕࡅࡕࡋࡒࡔࡡࡖࡘࡆ࡚ࡕࡔࠩ๰"))
	Cdyun4OtYjmFGHTzaW6rKwf9bg3Jsq(VJZIMkUN5siqB21Pf)
	RRr3Anq81K9gQybv6E7loe(uhTI2t3wObYqsAi9DCoc)
	import tAoP1fdO67
	tAoP1fdO67.nn3q8dAwhfx(zQGaM7ctZCN(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ๱"),VJZIMkUN5siqB21Pf)
	tAoP1fdO67.nn3q8dAwhfx(zQGaM7ctZCN(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ๲"),VJZIMkUN5siqB21Pf)
	tAoP1fdO67.nn3q8dAwhfx(yylSaxCLfkte(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡨࡩࡱࡵ࡫ࡧࡥ࡫ࡵࡩࡨࡺࠧ๳"),VJZIMkUN5siqB21Pf)
	tAoP1fdO67.DkcrxeMRug629ZVS7FUdNlQ(w2qb6lf5EM)
	tAoP1fdO67.u6olD7tMWYEc0NLjyXr(VJZIMkUN5siqB21Pf)
	if c5c9MivRmbxNBzWEeywITaonFtCD==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡘࡏࡍࡑࡎࡈࡣ࡚ࡖࡄࡂࡖࡈࠫ๴"):
		M0f3PV6nRU(w2qb6lf5EM,[NN4DuIqLH9iGesZocawQTUWm0E])
	else:
		M0f3PV6nRU(VJZIMkUN5siqB21Pf,[])
		tAoP1fdO67.xVOWPbGFg1YI6sieKQERz()
		try:
			ccbiVgE73BumqxA2 = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,rC5tnFDlQcRGA2(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๵"),cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๶"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫ๷"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๸"))
			o4uGfn5NrKFd7P0b3gwOICTRveYyMi = BDgtaC2sJxV7Efq5.Addon(id=HaTI5u1f3SCxmMAkw(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱ࠭๹"))
			o4uGfn5NrKFd7P0b3gwOICTRveYyMi.setSetting(GISOTJh20W(u"ࠪࡥࡻ࠴ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩ๺"),JACnOz297UuDK5HpPkc1LF(u"ࠫࡋࡧ࡬ࡴࡧࠪ๻"))
		except: pass
		try:
			ccbiVgE73BumqxA2 = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,E6xdOMpqISHZCn(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ๼"),rC5tnFDlQcRGA2(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ๽"),zQGaM7ctZCN(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧ๾"),KA26GucUHOwXL(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧ๿"))
			o4uGfn5NrKFd7P0b3gwOICTRveYyMi = BDgtaC2sJxV7Efq5.Addon(id=E6xdOMpqISHZCn(u"ࠩࡶࡧࡷ࡯ࡰࡵ࠰ࡰࡳࡩࡻ࡬ࡦ࠰ࡼࡸ࠲ࡪ࡬ࡱࠩ຀"))
			o4uGfn5NrKFd7P0b3gwOICTRveYyMi.setSetting(s97s2k0LJgl(u"ࠪࡥࡻ࠴ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭ກ"),ZP1LyUCS3pIBu(u"ࠫ࠸࠭ຂ"))
		except: pass
		try:
			ccbiVgE73BumqxA2 = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ຃"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪຄ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧ຅"),s97s2k0LJgl(u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧຆ"))
			o4uGfn5NrKFd7P0b3gwOICTRveYyMi = BDgtaC2sJxV7Efq5.Addon(id=cjVhOCwybeRo7UWg92(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩງ"))
			o4uGfn5NrKFd7P0b3gwOICTRveYyMi.setSetting(XB4CjMkPFzhAHiI3q(u"ࠪࡥࡻ࠴ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨຈ"),KA26GucUHOwXL(u"ࠫ࠷࠭ຉ"))
		except: pass
	qPWgu3zkRbrv74yho = nfpZxRXATHiEOK465l9SvrsbmQ(mw5hKxvWDZSQ)
	qPWgu3zkRbrv74yho = nfpZxRXATHiEOK465l9SvrsbmQ(wiEebAT9Qs7dCztufUZNORv3)
	tAoP1fdO67.z8SKrmAwqGFZCosg6HxPW4nD(VJZIMkUN5siqB21Pf)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡧࡶ࠯ࡸࡨࡶࡸ࡯࡯࡯ࠩຊ"),Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a)
	nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def RozWqdt7ba(oRZnA7lqNIdGiDhY):
	w0F5skN3cR7QW = hxg3VwrTRoJpdMHt7Aj92WcZy1(w2qb6lf5EM)
	if w0F5skN3cR7QW:
		return
	Wo9ClqVB3rTvbQ562 = l0SfZzs3tbP9RInJMmvyDKG4VQH(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(EcjO3giln2kQTdBY0XLAG(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡹࡨࡰࡴࡷࠫ຋")))
	Wo9ClqVB3rTvbQ562 = ZVNvqy4iF1a9X if not Wo9ClqVB3rTvbQ562 else int(Wo9ClqVB3rTvbQ562)
	if not Wo9ClqVB3rTvbQ562 or not ZVNvqy4iF1a9X<=U6YgVKS9rAmwe1RTPlQnfiGs-Wo9ClqVB3rTvbQ562<=o1oDTrOyPliAC6QBcKXRathZGu9g4Y:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡳࡩࡱࡵࡸࠬຌ"),U2SFOzhqClfsiu36P1j0YGrcx7d(U6YgVKS9rAmwe1RTPlQnfiGs))
		RRr3Anq81K9gQybv6E7loe(uhTI2t3wObYqsAi9DCoc)
		return
	DrqjL7eXn3ViwC1BfuhE0YoAU8d = l0SfZzs3tbP9RInJMmvyDKG4VQH(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪຍ")))
	DrqjL7eXn3ViwC1BfuhE0YoAU8d = ZVNvqy4iF1a9X if not DrqjL7eXn3ViwC1BfuhE0YoAU8d else int(DrqjL7eXn3ViwC1BfuhE0YoAU8d)
	M6SgcOJ7TLBAa = l0SfZzs3tbP9RInJMmvyDKG4VQH(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(XB4CjMkPFzhAHiI3q(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫຎ")))
	M6SgcOJ7TLBAa = ZVNvqy4iF1a9X if not M6SgcOJ7TLBAa else int(M6SgcOJ7TLBAa)
	if not DrqjL7eXn3ViwC1BfuhE0YoAU8d or not M6SgcOJ7TLBAa or not ZVNvqy4iF1a9X<=U6YgVKS9rAmwe1RTPlQnfiGs-M6SgcOJ7TLBAa<=DrqjL7eXn3ViwC1BfuhE0YoAU8d:
		SjiUKuqM7nNBOe5W49(w2qb6lf5EM,DrqjL7eXn3ViwC1BfuhE0YoAU8d)
		return
	mGtMR34HAO = l0SfZzs3tbP9RInJMmvyDKG4VQH(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪຏ")))
	mGtMR34HAO = ZVNvqy4iF1a9X if not mGtMR34HAO else int(mGtMR34HAO)
	if not mGtMR34HAO or not ZVNvqy4iF1a9X<=U6YgVKS9rAmwe1RTPlQnfiGs-mGtMR34HAO<=DRmUs7l1O4xLeZYzGITXk:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(JACnOz297UuDK5HpPkc1LF(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡶࡪ࡭ࡵ࡭ࡣࡵࠫຐ"),U2SFOzhqClfsiu36P1j0YGrcx7d(U6YgVKS9rAmwe1RTPlQnfiGs))
		hxg3VwrTRoJpdMHt7Aj92WcZy1(VJZIMkUN5siqB21Pf)
		return
	if VJZIMkUN5siqB21Pf:
		mjK0BYSa1p = l0SfZzs3tbP9RInJMmvyDKG4VQH(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡱࡵ࡮ࡨࠩຑ")))
		mjK0BYSa1p = ZVNvqy4iF1a9X if not mjK0BYSa1p else int(mjK0BYSa1p)
		if not mjK0BYSa1p or not ZVNvqy4iF1a9X<=U6YgVKS9rAmwe1RTPlQnfiGs-mjK0BYSa1p<=ggZJf7YnlXHT3IjtMaWe6S:
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪຒ"),U2SFOzhqClfsiu36P1j0YGrcx7d(U6YgVKS9rAmwe1RTPlQnfiGs))
	return
def SjiUKuqM7nNBOe5W49(TpGRx3umFIEKey1i0XNz8CnJ,DrqjL7eXn3ViwC1BfuhE0YoAU8d):
	wbrVRJOtEAD0sHifuM5hcF = P2Fgh6TCOWoaHjkqBcQnvRNXe
	zekpCoxQlbNjXd = VJZIMkUN5siqB21Pf if Ew2zQ8u7Ss.krgh8yUEqa else w2qb6lf5EM
	if zekpCoxQlbNjXd:
		if not DrqjL7eXn3ViwC1BfuhE0YoAU8d: TpGRx3umFIEKey1i0XNz8CnJ = VJZIMkUN5siqB21Pf
		NUFLafsK3eo = RRltAnXSQPJ2Nki5FeMqs(TpGRx3umFIEKey1i0XNz8CnJ)
		if len(NUFLafsK3eo)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧ࠯࡞ࡷࡗ࡭ࡵࡷࡪࡰࡪࠤࡖࡻࡥࡴࡶ࡬ࡳࡳࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪຓ")+zz4EDG1PtiyX3JVUlBeC+E6xdOMpqISHZCn(u"ࠨࠢࡠࠫດ"))
			dq7AOIkC9r0,kznWKAPj2eN,h417jESXsCIZJenFNlf0ybo2dr5xAL,B5B97KCQSDNcVWJb8RjxvL,wRUixloKXmj7IPpY4AcO21Q6Hygu,j6h5EvtgIqUrYcKwl91p7RCJm4i = NUFLafsK3eo[ZVNvqy4iF1a9X]
			jkKGWHfxSeaVv9l,ootbcMklDverTHUZCB1wK6LdaF8 = B5B97KCQSDNcVWJb8RjxvL.split(GISOTJh20W(u"ࠩ࡟ࡲࡀࡁࠧຕ"))
			del NUFLafsK3eo[ZVNvqy4iF1a9X]
			BvpAJKWgnR = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(NUFLafsK3eo,P2Fgh6TCOWoaHjkqBcQnvRNXe)
			dq7AOIkC9r0,kznWKAPj2eN,h417jESXsCIZJenFNlf0ybo2dr5xAL,B5B97KCQSDNcVWJb8RjxvL,wRUixloKXmj7IPpY4AcO21Q6Hygu,j6h5EvtgIqUrYcKwl91p7RCJm4i = BvpAJKWgnR[ZVNvqy4iF1a9X]
			h417jESXsCIZJenFNlf0ybo2dr5xAL = TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩຖ")+Ym6q5M4TocDaA013RjFQ+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࠥࡀࠠࠨທ")+dq7AOIkC9r0+oOQaRxBXyJ5jVnZ+h417jESXsCIZJenFNlf0ybo2dr5xAL
			wRUixloKXmj7IPpY4AcO21Q6Hygu = E6xdOMpqISHZCn(u"ࠬหัิษ็ࠤึูวๅห่้๋ࠣศา็ฯࠫຘ")
			nQm1q2gsa0VEIPfoOv6ApH4CWDFU = zQGaM7ctZCN(u"࠭วๅฬหี฾อสࠨນ")
			button0,button1 = B5B97KCQSDNcVWJb8RjxvL,wRUixloKXmj7IPpY4AcO21Q6Hygu
			HQ64YpxE19vcqra = [button0,button1,nQm1q2gsa0VEIPfoOv6ApH4CWDFU]
			EE5FRJIMt084QzUbZjmkxyfovYdcHC = P2Fgh6TCOWoaHjkqBcQnvRNXe if Ew2zQ8u7Ss.wsrSnHQfOWm8 else od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠳࠳ᒄ")
			M9t6EHOwIr8cqy = -Olh7n0zfV4(u"࠼ᒅ")
			while M9t6EHOwIr8cqy<ZVNvqy4iF1a9X:
				H8MrkptCRcXAYwBaQZou51PeiDqSL0 = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(HQ64YpxE19vcqra,D9yBM7wPFLz)
				M9t6EHOwIr8cqy = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,H8MrkptCRcXAYwBaQZou51PeiDqSL0[ZVNvqy4iF1a9X],H8MrkptCRcXAYwBaQZou51PeiDqSL0[P2Fgh6TCOWoaHjkqBcQnvRNXe],H8MrkptCRcXAYwBaQZou51PeiDqSL0[VTadWjBloMwXO2CH9GDK6FR],jkKGWHfxSeaVv9l,h417jESXsCIZJenFNlf0ybo2dr5xAL,Olh7n0zfV4(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩບ"),EE5FRJIMt084QzUbZjmkxyfovYdcHC,VVvcQpCU3OM09n(u"࠺࠵ᒆ"))
				if M9t6EHOwIr8cqy==E6xdOMpqISHZCn(u"࠶࠶ᒇ"): break
				import tAoP1fdO67
				if M9t6EHOwIr8cqy>=ZVNvqy4iF1a9X and H8MrkptCRcXAYwBaQZou51PeiDqSL0[M9t6EHOwIr8cqy]==HQ64YpxE19vcqra[P2Fgh6TCOWoaHjkqBcQnvRNXe]:
					tAoP1fdO67.FeDaQc6MWl7()
					if M9t6EHOwIr8cqy>=ZVNvqy4iF1a9X: M9t6EHOwIr8cqy = -O4F8UC5lMAS6ghETm1VoPDI(u"࠿ᒈ")
				elif M9t6EHOwIr8cqy>=ZVNvqy4iF1a9X and H8MrkptCRcXAYwBaQZou51PeiDqSL0[M9t6EHOwIr8cqy]==HQ64YpxE19vcqra[VTadWjBloMwXO2CH9GDK6FR]:
					tAoP1fdO67.uucYwE73JTI4ABiUWDSqxnNedH(VJZIMkUN5siqB21Pf)
				if M9t6EHOwIr8cqy==-P2Fgh6TCOWoaHjkqBcQnvRNXe: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Ym6q5M4TocDaA013RjFQ+HaTI5u1f3SCxmMAkw(u"ࠨะิ์ัࠦฮุลࠪປ")+oOQaRxBXyJ5jVnZ+HaTI5u1f3SCxmMAkw(u"ࠩ࡟ࡲ๊ࠥไฯำ๋ะࠥอไึฯํัࠥษฮหำࠣ์ฬำฯࠡ็้ࠤฬ๊รอ๊หอࠥอไๆฬ๋ๅึฯࠧຜ"))
			wbrVRJOtEAD0sHifuM5hcF = P2Fgh6TCOWoaHjkqBcQnvRNXe
		else: wbrVRJOtEAD0sHifuM5hcF = ZVNvqy4iF1a9X
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(XB4CjMkPFzhAHiI3q(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬຝ"),U2SFOzhqClfsiu36P1j0YGrcx7d(U6YgVKS9rAmwe1RTPlQnfiGs))
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,E6xdOMpqISHZCn(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧພ"),yylSaxCLfkte(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪຟ"),wbrVRJOtEAD0sHifuM5hcF,XlNnqz758Zeuo)
	return
def ib1JV8gADQeGW57(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh,oRZnA7lqNIdGiDhY,UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2):
	if UZxHPtpYJg8u3h9rOnM in [EcjO3giln2kQTdBY0XLAG(u"࠭࠱ࠨຠ"),EcjO3giln2kQTdBY0XLAG(u"ࠧ࠳ࠩມ"),ZP1LyUCS3pIBu(u"ࠨ࠵ࠪຢ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࠷ࠫຣ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪ࠹ࠬ຤"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫ࠶࠷ࠧລ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࠷࠲ࠨ຦"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭࠱࠴ࠩວ")] and xnlXAO3qzsuKr2:
		import z2BQ0dUKrP
		z2BQ0dUKrP.szprIF8Zyl30nRVMfEbJqiATQao1G(QQa9t5k6BLqflRNr,UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2)
		nYgsitVoc3E(VJZIMkUN5siqB21Pf,zz4EDG1PtiyX3JVUlBeC)
	elif UZxHPtpYJg8u3h9rOnM==HaTI5u1f3SCxmMAkw(u"ࠧ࠷ࠩຨ"):
		import kUCfvjAP1c
		if xnlXAO3qzsuKr2==ZP1LyUCS3pIBu(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪຩ"): kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩํีั๏ࠠศๆส๊ฯ฾วาࠩສ"),GISOTJh20W(u"ࠪะฬื๊ࠡใะู๋ࠥไโࠢส่ฯำๅ๋ๆࠪຫ"),L8Wkv5KCSoq=h6sIkJOT5PB2vCxqo4LFag70wA(u"࠲࠱࠲࠳ᒉ"))
		elif xnlXAO3qzsuKr2==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡉࡋࡌࡆࡖࡈࠫຬ"): Fu7PUy1x6wh2(pkNZlmhUSwtXgriJHjT59MV1QqK,VJZIMkUN5siqB21Pf)
		SD0TxMRXiep4cjPBsnzI = kUCfvjAP1c.M4g7Ho2s8EhVxbyN1d0n(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,oRZnA7lqNIdGiDhY,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
		if xnlXAO3qzsuKr2==s97s2k0LJgl(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧອ"): JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	elif QQa9t5k6BLqflRNr==yylSaxCLfkte(u"࠭࠷ࠨຮ"):
		import KxIcVHk2jg
		KxIcVHk2jg.eeSzyvE3rp2YHUsi(ZP1LyUCS3pIBu(u"ࠧࡠࡃࡏࡐࠬຯ"))
		nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	elif QQa9t5k6BLqflRNr==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨ࠺ࠪະ"): pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨັ")+R7xafKV3ekjDc+zQGaM7ctZCN(u"ࠪࡃࡲࡵࡤࡦ࠿ࠪາ")+str(n3dz9vetbZKIVYm78)+cbmeD4WNZfAowxT2JdUMtV(u"ࠫࠫࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠬࠫຳ"))
	elif QQa9t5k6BLqflRNr==XB4CjMkPFzhAHiI3q(u"ࠬ࠿ࠧິ"):
		nYgsitVoc3E(w2qb6lf5EM)
	elif QQa9t5k6BLqflRNr==mi2ZJXCDzITuyev6gfn(u"࠭࠱࠱ࠩີ"):
		import KxIcVHk2jg
		KxIcVHk2jg.eeSzyvE3rp2YHUsi(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡠࡉࡒࡓࡌࡒࡅࠨຶ"))
		nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	elif QQa9t5k6BLqflRNr==KA26GucUHOwXL(u"ࠨ࠳࠷ࠫື"): nYgsitVoc3E(w2qb6lf5EM,JACnOz297UuDK5HpPkc1LF(u"ࠩࡐࡉࡓ࡛࡟ࡓࡇ࡙ࡉࡗ࡙ࡅࡅࡡࡗࡉࡒࡖຸࠧ"))
	elif QQa9t5k6BLqflRNr==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪ࠵࠺ູ࠭"): nYgsitVoc3E(w2qb6lf5EM,XB4CjMkPFzhAHiI3q(u"ࠫࡒࡋࡎࡖࡡࡄࡗࡈࡋࡎࡅࡇࡇࡣ࡙ࡋࡍࡑ຺ࠩ"))
	elif QQa9t5k6BLqflRNr==o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࠷࠶ࠨົ"): nYgsitVoc3E(w2qb6lf5EM,cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬຼ"))
	elif QQa9t5k6BLqflRNr==VVvcQpCU3OM09n(u"ࠧ࠲࠹ࠪຽ"): nYgsitVoc3E(w2qb6lf5EM,O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡏࡈࡒ࡚ࡥࡒࡂࡐࡇࡓࡒࡏ࡚ࡆࡆࡢࡘࡊࡓࡐࠨ຾"))
	elif QQa9t5k6BLqflRNr==cjVhOCwybeRo7UWg92(u"ࠩ࠴࠼ࠬ຿"):
		ksDvwLIca3bHm = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧເ"))
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡣ࡫ࡷࡶࡦࡺࡥࠨແ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࠳ࠧໂ")+ksDvwLIca3bHm)
	if QQa9t5k6BLqflRNr in [HaTI5u1f3SCxmMAkw(u"࠭࠹ࠨໃ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠲࠶ࠪໄ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࠳࠸ࠫ໅"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࠴࠺ࠬໆ"),Olh7n0zfV4(u"ࠪ࠵࠼࠭໇")]: JXBCMi3e9AW0PjShnfYxpRUbgGcv4(w2qb6lf5EM)
	return
def rcfBUlvIkDeGNKA3J(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh,oRZnA7lqNIdGiDhY,UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2,m9wgSl1oUVRd):
	if ohkAjGeH2Rf6Vw4vNM8rJE3tlnO5d: gghHSYtaECDqIxnLdjkO2KeM3()
	if QQa9t5k6BLqflRNr: ib1JV8gADQeGW57(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh,oRZnA7lqNIdGiDhY,UZxHPtpYJg8u3h9rOnM,xnlXAO3qzsuKr2)
	RozWqdt7ba(oRZnA7lqNIdGiDhY)
	cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui = w2qb6lf5EM,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf
	pOChbtIJDzKujx = nSDx0eZqomMks(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh,oRZnA7lqNIdGiDhY,m9wgSl1oUVRd,cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui)
	N6VvypcIiB2HXb,QgwJd8Sfs07zyqlmiKWRrCP9Dn,fSn7ArdbOmju,r9u8w2A3nbVvRpc1B,FqLrpUgxsS,jY6EJPO54qW1o92ugtBKcUwrn,jjnDkboXNHUhf,enRHwuOX2qxc4pQyTFAm5S6adtG = pOChbtIJDzKujx
	if N6VvypcIiB2HXb: return
	if QgwJd8Sfs07zyqlmiKWRrCP9Dn==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈ່ࠫ"): RRr3Anq81K9gQybv6E7loe(uhTI2t3wObYqsAi9DCoc)
	Qlu9Ih6YOVFw7X34(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡹࡴࡢࡴࡷ້ࠫ"))
	if ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(JACnOz297UuDK5HpPkc1LF(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩ໊ࠬ")) not in [CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡂࡗࡗࡓ໋ࠬ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡕࡗࡓࡕ࠭໌"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪໍ")]:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(cjVhOCwybeRo7UWg92(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ໎"),XB4CjMkPFzhAHiI3q(u"ࠫࡆ࡛ࡔࡐࠩ໏"))
	if not ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(JACnOz297UuDK5HpPkc1LF(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡦࡱࡷࠬ໐")): ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡧࡲࡸ࠭໑"),Ew2zQ8u7Ss.DNS_SERVERS[ZVNvqy4iF1a9X])
	SD0TxMRXiep4cjPBsnzI = M4g7Ho2s8EhVxbyN1d0n(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	if VVvcQpCU3OM09n(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ໒") in AyKma12GRYnziLV7EWIjUM: k1JMeFxNh68vZVuPndU7ap2bR = w2qb6lf5EM
	if kcxAmftieK56PE9TqbDHdSrF8==ZP1LyUCS3pIBu(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໓"):
		if r9u8w2A3nbVvRpc1B!=GISOTJh20W(u"ࠩ࠱࠲ࠬ໔") and FqLrpUgxsS: HDWalJw09McEVi7mYBgSP()
		if b4qsaVwC0mHOGPKp5>-P2Fgh6TCOWoaHjkqBcQnvRNXe:
			Bd8N12fjWFTgzK4ecEhIDxRo = [ZVNvqy4iF1a9X,yUMRP0QKIzY9BDnsV784TZmwkf(u"࠳࠸ᒋ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠴࠻ᒌ"),JACnOz297UuDK5HpPkc1LF(u"࠵࠾ᒍ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠳࠸ᒊ"),XB4CjMkPFzhAHiI3q(u"࠳࠵ᒐ"),TDpFsQXHze2q30uYtGPfEIm8(u"࠺࠶ᒎ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠻࠳ᒏ"),otNfFapeEnO(u"࠲࠳࠳ᒑ")]
			if (JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,zQGaM7ctZCN(u"ࠪ࡭ࡳࡺࠧ໕"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧ໖"),EcjO3giln2kQTdBY0XLAG(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪ໗")) or oRZnA7lqNIdGiDhY not in Bd8N12fjWFTgzK4ecEhIDxRo) and not Ew2zQ8u7Ss.wpBxtqcsDEafMFkToIXe:
				from p7gmr5fCJu import wZ7dtoKTGz102g
				Db3QUifAKVh1l9mj,zxWyYlkBm8q6GL = ppOqeuYQgUxftWB30FvMDC(wZ7dtoKTGz102g)
				N6VvypcIiB2HXb = h7h5jOlyrznxHePifwWbCvoaDQZA(fSn7ArdbOmju,Db3QUifAKVh1l9mj,cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui)
				if Db3QUifAKVh1l9mj and jY6EJPO54qW1o92ugtBKcUwrn:
					if zxWyYlkBm8q6GL: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ໘")+jjnDkboXNHUhf+E6xdOMpqISHZCn(u"ࠧࡠࠩ໙")+enRHwuOX2qxc4pQyTFAm5S6adtG,fSn7ArdbOmju,Db3QUifAKVh1l9mj,DRmUs7l1O4xLeZYzGITXk)
					else: oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,mi2ZJXCDzITuyev6gfn(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧ໚")+jjnDkboXNHUhf+GISOTJh20W(u"ࠩࡢࠫ໛")+enRHwuOX2qxc4pQyTFAm5S6adtG,fSn7ArdbOmju)
			else:
				ZqpKwnSTtsNmWYCfueOxd14.addDirectoryItem(b4qsaVwC0mHOGPKp5,XB4CjMkPFzhAHiI3q(u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴࠭ໜ")+R7xafKV3ekjDc+s97s2k0LJgl(u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡱ࡯࡮࡬ࠨࡰࡳࡩ࡫࠽࠶࠲࠳ࠫໝ"),rTF8V7fLD2SXJbAURpZjQ4wH.ListItem(cbmeD4WNZfAowxT2JdUMtV(u"๊ࠬฯ๋ๅู้้ࠣไส่๊ࠢࠥา็ศิๆࠫໞ")))
				ZqpKwnSTtsNmWYCfueOxd14.addDirectoryItem(b4qsaVwC0mHOGPKp5,E6xdOMpqISHZCn(u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩໟ")+R7xafKV3ekjDc+cbmeD4WNZfAowxT2JdUMtV(u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽࡭࡫ࡱ࡯ࠫࡳ࡯ࡥࡧࡀ࠹࠵࠶ࠧ໠"),rTF8V7fLD2SXJbAURpZjQ4wH.ListItem(XB4CjMkPFzhAHiI3q(u"ࠨลไฮาࠦไหไิวࠥอไหใสู๏๊ࠧ໡")))
			ZqpKwnSTtsNmWYCfueOxd14.endOfDirectory(b4qsaVwC0mHOGPKp5,cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui)
	return
def RRr3Anq81K9gQybv6E7loe(TKClDLHwg6MFkmspqJxXZroySAt):
	if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫ໢") in str(Ew2zQ8u7Ss.SEND_THESE_EVENTS): return
	iib2JTY7WG5B3uMKjCxVma9 = VJZIMkUN5siqB21Pf if TKClDLHwg6MFkmspqJxXZroySAt else w2qb6lf5EM
	if not iib2JTY7WG5B3uMKjCxVma9:
		T8TqpLwivJAOZgBDCKPdXHFYob6 = l0SfZzs3tbP9RInJMmvyDKG4VQH(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(E6xdOMpqISHZCn(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡰࡩࡸࡹࡡࡨࡧࡶࠫ໣")))
		T8TqpLwivJAOZgBDCKPdXHFYob6 = ZVNvqy4iF1a9X if not T8TqpLwivJAOZgBDCKPdXHFYob6 else int(T8TqpLwivJAOZgBDCKPdXHFYob6)
		if not T8TqpLwivJAOZgBDCKPdXHFYob6 or not ZVNvqy4iF1a9X<=U6YgVKS9rAmwe1RTPlQnfiGs-T8TqpLwivJAOZgBDCKPdXHFYob6<=TKClDLHwg6MFkmspqJxXZroySAt: iib2JTY7WG5B3uMKjCxVma9 = w2qb6lf5EM
	if not iib2JTY7WG5B3uMKjCxVma9:
		E15jByemhnGaScIP6fxOY3bupzw = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(cjVhOCwybeRo7UWg92(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ໤"))
		if E15jByemhnGaScIP6fxOY3bupzw in [CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡕࡌࡅࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ໥"),o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡎࡆ࡙ࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬ໦")]: iib2JTY7WG5B3uMKjCxVma9 = w2qb6lf5EM
	if not iib2JTY7WG5B3uMKjCxVma9:
		k5bP3WR8ODeqhYBcH40SKgwI7fMQN = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(rC5tnFDlQcRGA2(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠳ࠪ໧"))
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN = JEAtPbO4MULFdGCVWcHwp0SQ6(NN4DuIqLH9iGesZocawQTUWm0E)
		JJl5MQBcPOwEmWnr6T = ODLnpGUNsgx6(NN4DuIqLH9iGesZocawQTUWm0E,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,otNfFapeEnO(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡥࡩࡥࠢ࠾ࠫ໨"))
		JJl5MQBcPOwEmWnr6T = JJl5MQBcPOwEmWnr6T[GISOTJh20W(u"࠲ᒒ")][GISOTJh20W(u"࠲ᒒ")]
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
		DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(o2FdrDBimMuOw97q6QpNW8S(u"࠸ᒓ")*k5bP3WR8ODeqhYBcH40SKgwI7fMQN.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()
		DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(mi2ZJXCDzITuyev6gfn(u"࠵࠹ᒔ")*DajqVM3ptOGR6Cr2KyQoSYw.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()
		DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(pz4WBwfyDdgk0m2aRr7SMv(u"࠶࠿ᒕ")*DajqVM3ptOGR6Cr2KyQoSYw.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()
		DajqVM3ptOGR6Cr2KyQoSYw = str(int(DajqVM3ptOGR6Cr2KyQoSYw[E6xdOMpqISHZCn(u"࠳ᒗ"):XB4CjMkPFzhAHiI3q(u"࠲࠴ᒘ")],o2FdrDBimMuOw97q6QpNW8S(u"࠳࠹ᒙ")))[:s97s2k0LJgl(u"࠿ᒖ")]
		if DajqVM3ptOGR6Cr2KyQoSYw!=JJl5MQBcPOwEmWnr6T: iib2JTY7WG5B3uMKjCxVma9 = w2qb6lf5EM
	if iib2JTY7WG5B3uMKjCxVma9: CxIlGtFjUNru3Q(VJZIMkUN5siqB21Pf)
	return
def Ask1fYqbtjHaK7uoe5BiFhCSdLO2Pn(JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i,nqVYufmd4GFshQeHO9vp05,showDialogs):
	ad3z2451e09FrDHmvci = nqVYufmd4GFshQeHO9vp05.split(EcjO3giln2kQTdBY0XLAG(u"ࠩ࠰ࠫ໩"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X] if ZP1LyUCS3pIBu(u"ࠪ࠱ࠬ໪") in nqVYufmd4GFshQeHO9vp05 else nqVYufmd4GFshQeHO9vp05
	if not showDialogs or nqVYufmd4GFshQeHO9vp05 in zSOU8mieXluDYvIKF1HMfZoAgh0LR: return VJZIMkUN5siqB21Pf
	T5D9Uw47odNRKvZg6bLurViGeJq = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ໫"))
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(E6xdOMpqISHZCn(u"ࠬࡧࡶ࠯࡮ࡤࡲ࡬ࡻࡡࡨࡧ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪ࠭໬"),CJlTSEpZsWb0QHg5w)
	OUNRcXlzSEbJi52ZB7K3gMC9Vj0 = JsDZ0f79iTWLY412v5Ejl in [GISOTJh20W(u"࠽ᒝ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠵࠶࠶࠰࠲ᒛ"),Olh7n0zfV4(u"࠴࠵࠵࠶࠲ᒚ"),E6xdOMpqISHZCn(u"࠶࠶࠰࠶࠶ᒜ")]
	zgUhH4winX1yOvGcP = j6h5EvtgIqUrYcKwl91p7RCJm4i.lower()
	grVbnZAlpseQDMRhTwBfxOPaX85CN4 = JsDZ0f79iTWLY412v5Ejl in [ZVNvqy4iF1a9X,VVvcQpCU3OM09n(u"࠳࠳࠸ᒠ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠱࠱࠲࠹࠵ᒞ"),E6xdOMpqISHZCn(u"࠲࠳࠴ᒟ")]
	K489BrAIlFVmbZdLkQhSsWJeovq = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ໭") in zgUhH4winX1yOvGcP
	ccRj6yCIWOgUPtFa57 = mi2ZJXCDzITuyev6gfn(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ໮") in zgUhH4winX1yOvGcP
	Qaedhx7PmXYRISkHiVn09oMyJfEOF = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡸࡥࡤࡣࡳࡸࡨ࡮ࡡࠨ໯") in zgUhH4winX1yOvGcP
	XyU4Yxt8vzN0ASJTgZp = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠣࡷࡪࡩࡵࡳ࡫ࡷࡽࠥࡩࡨࡦࡥ࡮ࠫ໰") in zgUhH4winX1yOvGcP
	pE3d9qBL806NIPVZx1ge4ui = yylSaxCLfkte(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠ࡮࡫ࡶࡷ࡮ࡴࡧࠡ࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸࠥࡩࡨࡦࡥ࡮ࠫ໱") in zgUhH4winX1yOvGcP
	LCxQObnNkUAoGwXtuFiDJS5sT = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡻࡲࡹࡷࠦ࡮ࡦࡶࡺࡳࡷࡱࠠࡥࡧࡹ࡭ࡨ࡫ࡳࠨ໲") in zgUhH4winX1yOvGcP
	UKWyaeZQrGEDt4p6SnFPfNkdul5C = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(zQGaM7ctZCN(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪ໳"))
	Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩ໴"))
	vIQk7CgdRY = O4F8UC5lMAS6ghETm1VoPDI(u"ࠧโึ็ࠤๆ๐ࠠิฯหࠤฬ๊ีโฯฬࠤ๊์ࠠศๆศ๊ฯืๆหࠩ໵")
	TyGfBz2j8t1chD = XB4CjMkPFzhAHiI3q(u"ࠨࡇࡵࡶࡴࡸࠠࠨ໶")+str(JsDZ0f79iTWLY412v5Ejl)+rC5tnFDlQcRGA2(u"ࠩ࠽ࠤࠬ໷")+j6h5EvtgIqUrYcKwl91p7RCJm4i
	TyGfBz2j8t1chD = sWzgdLCjSVwaMuhFkNf1Uop(TyGfBz2j8t1chD)
	if any([grVbnZAlpseQDMRhTwBfxOPaX85CN4,K489BrAIlFVmbZdLkQhSsWJeovq,ccRj6yCIWOgUPtFa57,Qaedhx7PmXYRISkHiVn09oMyJfEOF,XyU4Yxt8vzN0ASJTgZp,pE3d9qBL806NIPVZx1ge4ui,LCxQObnNkUAoGwXtuFiDJS5sT]): vIQk7CgdRY += rC5tnFDlQcRGA2(u"ࠪࠤ࠳ࠦวๅ็๋ๆ฾ࠦแ๋้ࠣััฮࠠืัࠣ็ํี๊ࠡ็ุำึํࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠษษ็้ํู่࡝ࡰࠪ໸")
	if OUNRcXlzSEbJi52ZB7K3gMC9Vj0: vIQk7CgdRY += h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࠥ࠴ࠠๅัํ็ࠥิืฤࠢࡇࡒࡘ่ࠦๆ฻้ห์ࠦสฺาิࠤฯืฬๆหࠣหุ๋ࠠศๆ่์็฿ࠠฦๆ์ࠤึ่ๅ่࡞ࡱࠫ໹")
	TyGfBz2j8t1chD = rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+TyGfBz2j8t1chD+oOQaRxBXyJ5jVnZ
	if UKWyaeZQrGEDt4p6SnFPfNkdul5C==pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡇࡓࡌࠩ໺") or Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4==GISOTJh20W(u"࠭ࡁࡔࡍࠪ໻"):
		vIQk7CgdRY += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+TDpFsQXHze2q30uYtGPfEIm8(u"่ࠧๆࠣฮึ๐ฯࠡล้ࠤ๏ำว้ๆࠣห้ฮั็ษ่ะࠥหีๅษะࠤฬ๊ๅีๅ็อࠥ࠴࠮ࠡล่ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠฤ๊ࠣา฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥลࠡࠢࠩ໼")+oOQaRxBXyJ5jVnZ
	Wb3hHyodk2LBqwE5z = VJZIMkUN5siqB21Pf
	if UKWyaeZQrGEDt4p6SnFPfNkdul5C==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡃࡖࡏࠬ໽") or Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4==h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡄࡗࡐ࠭໾"):
		M9t6EHOwIr8cqy = IUHFoP2MS7n5QBvc3ZthfdN0e(XB4CjMkPFzhAHiI3q(u"ࠪࡧࡪࡴࡴࡦࡴࠪ໿"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫำื่อࠩༀ"),VVvcQpCU3OM09n(u"ࠬหัิษ็ࠤ้๊ๅษำ่ะࠬ༁"),KA26GucUHOwXL(u"࠭สึๆํัࠥอไๆึๆ่ฮ࠭༂"),ad3z2451e09FrDHmvci+VzZPgf1qW5L8auj2do9R4FpiXM7Ycy+HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci),vIQk7CgdRY+rJ9cgWz4FU+TyGfBz2j8t1chD)
		if M9t6EHOwIr8cqy==P2Fgh6TCOWoaHjkqBcQnvRNXe:
			from tAoP1fdO67 import FeDaQc6MWl7
			FeDaQc6MWl7()
		elif M9t6EHOwIr8cqy==VTadWjBloMwXO2CH9GDK6FR: Wb3hHyodk2LBqwE5z = w2qb6lf5EM
	else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ad3z2451e09FrDHmvci+VzZPgf1qW5L8auj2do9R4FpiXM7Ycy+HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci),vIQk7CgdRY,TyGfBz2j8t1chD)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(Olh7n0zfV4(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ༃"),T5D9Uw47odNRKvZg6bLurViGeJq)
	return Wb3hHyodk2LBqwE5z
def M0f3PV6nRU(UUYQlIeWtnfOS26CT4cGJLjr=VJZIMkUN5siqB21Pf,HHZKWJUS4h=[]):
	JSMvREj8i1u5zTy3aIeoOwGn = [mw5hKxvWDZSQ,wiEebAT9Qs7dCztufUZNORv3]+HHZKWJUS4h
	for N4jmWQledskOFctof in tiFgl4DMvGEAUfjIYkHbr05.listdir(c2XOIv1RU6aSuAeiZ5Pgz9Gr):
		if UUYQlIeWtnfOS26CT4cGJLjr and (N4jmWQledskOFctof.startswith(mi2ZJXCDzITuyev6gfn(u"ࠨ࡫ࡳࡸࡻ࠭༄")) or N4jmWQledskOFctof.startswith(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡰ࠷ࡺ࠭༅"))): continue
		if N4jmWQledskOFctof.startswith(VVvcQpCU3OM09n(u"ࠪࡪ࡮ࡲࡥࡠࠩ༆")): continue
		paoVihIqON8TE6CU0YQLg4ef9xMX = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,N4jmWQledskOFctof)
		if paoVihIqON8TE6CU0YQLg4ef9xMX in JSMvREj8i1u5zTy3aIeoOwGn: continue
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(paoVihIqON8TE6CU0YQLg4ef9xMX)
		except: pass
	if CD6FK0opq3A4cYJWN1RHeEUZvti not in JSMvREj8i1u5zTy3aIeoOwGn: xyP9q8HGgDkNbL4WFnd5lfVh(CD6FK0opq3A4cYJWN1RHeEUZvti,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
	L8Wkv5KCSoq.sleep(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠴ᒡ"))
	return
def G8xf170imLdgkjIUZrNDAq(wwe8bl92EmknVZ,por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP=w2qb6lf5EM,bhoLXAYz37qSr=w2qb6lf5EM):
	otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ༇")+wwe8bl92EmknVZ
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP,bhoLXAYz37qSr)
	if otaunYGVIJ2jX8HsKm7ecR0bAh4 in cDXLPHnAgY6NOk1GVStoiEx.content: cDXLPHnAgY6NOk1GVStoiEx.succeeded = VJZIMkUN5siqB21Pf
	if not cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	return cDXLPHnAgY6NOk1GVStoiEx
def v9T3ktNj7XguFo8H2(otaunYGVIJ2jX8HsKm7ecR0bAh4):
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡍࡅࡕࠩ༈"),otaunYGVIJ2jX8HsKm7ecR0bAh4,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ༉"),w2qb6lf5EM,VJZIMkUN5siqB21Pf)
	CV2mzHE647bkoQTWUAdgNOe = []
	if cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
		rTfFy9bpYtvsJc6OdihAXP = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࠡࠪ࠱࠮ࡄ࠯ࠠ࡝ࡦࡾ࠵࠱࠹ࡽ࡮ࡵࠪ༊"),z4YnlxGHF2AMtrw)
		if rTfFy9bpYtvsJc6OdihAXP: z4YnlxGHF2AMtrw = rJ9cgWz4FU.join(rTfFy9bpYtvsJc6OdihAXP)
		PaQmJB7cEuR5T3rsb9kvfIAlyqU = z4YnlxGHF2AMtrw.replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).strip(rJ9cgWz4FU).split(rJ9cgWz4FU)
		CV2mzHE647bkoQTWUAdgNOe = []
		for wwe8bl92EmknVZ in PaQmJB7cEuR5T3rsb9kvfIAlyqU:
			if wwe8bl92EmknVZ.count(O4F8UC5lMAS6ghETm1VoPDI(u"ࠨ࠰ࠪ་"))==D9yBM7wPFLz: CV2mzHE647bkoQTWUAdgNOe.append(wwe8bl92EmknVZ)
	return CV2mzHE647bkoQTWUAdgNOe
def awcv24YERQj(*aargs):
	bHRDJCZA1B2cVmLduf4UYwgth = yylSaxCLfkte(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠮ࡱࡴࡲࡼࡾࡹࡣࡳࡣࡳࡩ࠳ࡩ࡯࡮࠱ࡹ࠶࠴ࡅࡲࡦࡳࡸࡩࡸࡺ࠽ࡥ࡫ࡶࡴࡱࡧࡹࡱࡴࡲࡼ࡮࡫ࡳࠧࡲࡵࡳࡽࡿࡴࡺࡲࡨࡁ࡭ࡺࡴࡱࠨࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠶࠰࠱ࠨࡶࡷࡱࡃࡹࡦࡵࠩࡰ࡮ࡳࡩࡵ࠿࠴࠴ࠫࡩ࡯ࡶࡰࡷࡶࡾࡃࡎࡍ࠮ࡅࡉ࠱ࡊࡅ࠭ࡈࡕ࠰ࡌࡈࠬࡕࡔࠪ༌")
	KPCanX4YyRZvNVrOHo3 = Olh7n0zfV4(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡳࡴࡹࡴࡦࡴ࡮࡭ࡩ࠵࡯ࡱࡧࡱࡴࡷࡵࡸࡺ࡮࡬ࡷࡹ࠵࡭ࡢ࡫ࡱ࠳ࡍ࡚ࡔࡑࡕ࠱ࡸࡽࡺࠧ།")
	KFPZr5RYnB4VlkgwNSA2X = v9T3ktNj7XguFo8H2(KPCanX4YyRZvNVrOHo3)
	CV2mzHE647bkoQTWUAdgNOe = v9T3ktNj7XguFo8H2(bHRDJCZA1B2cVmLduf4UYwgth)
	PP4lc3Xd8L7bN6U = KFPZr5RYnB4VlkgwNSA2X+CV2mzHE647bkoQTWUAdgNOe
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࠥࠦࠠࡈࡱࡷࠤࡵࡸ࡯ࡹ࡫ࡨࡷࠥࡲࡩࡴࡶࠣࠤࠥ࠷ࡳࡵ࠭࠵ࡲࡩࡀࠠ࡜ࠢࠪ༎")+str(len(KFPZr5RYnB4VlkgwNSA2X))+VVvcQpCU3OM09n(u"ࠬ࠱ࠧ༏")+str(len(CV2mzHE647bkoQTWUAdgNOe))+JACnOz297UuDK5HpPkc1LF(u"࠭ࠠ࡞ࠩ༐"))
	wwe8bl92EmknVZ = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡢࡸ࠱ࡴࡷࡵࡸࡺ࠰࡯ࡥࡸࡺࠧ༑"))
	cDXLPHnAgY6NOk1GVStoiEx = Ing6ofPTzy1aJXv0()
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(Olh7n0zfV4(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ༒"),CJlTSEpZsWb0QHg5w)
	if wwe8bl92EmknVZ or PP4lc3Xd8L7bN6U:
		dq7AOIkC9r0,p3voWAbJhDmLaI2lgYGcVMEX = ZVNvqy4iF1a9X,yylSaxCLfkte(u"࠵࠵ᒢ")
		zxYGwI6pRo2lPDnqOu = len(PP4lc3Xd8L7bN6U)
		yMnC5QFIdj6LNwuOv = p3voWAbJhDmLaI2lgYGcVMEX
		if zxYGwI6pRo2lPDnqOu>yMnC5QFIdj6LNwuOv: Gz7p4QXwLqaDHBeOcu6tRY = yMnC5QFIdj6LNwuOv
		else: Gz7p4QXwLqaDHBeOcu6tRY = zxYGwI6pRo2lPDnqOu
		YbtAUJGX7smVlqH23 = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(PP4lc3Xd8L7bN6U,Gz7p4QXwLqaDHBeOcu6tRY)
		if wwe8bl92EmknVZ: YbtAUJGX7smVlqH23 = [wwe8bl92EmknVZ]+YbtAUJGX7smVlqH23
		Nk1aK7Tfey = x74xDjR1rFbNiWh(VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
		kc4BtgWCFLJ5yGRVZzuX1eni20 = L8Wkv5KCSoq.time()
		while L8Wkv5KCSoq.time()-kc4BtgWCFLJ5yGRVZzuX1eni20<=p3voWAbJhDmLaI2lgYGcVMEX and not Nk1aK7Tfey.finishedLIST:
			if dq7AOIkC9r0<Gz7p4QXwLqaDHBeOcu6tRY:
				wwe8bl92EmknVZ = YbtAUJGX7smVlqH23[dq7AOIkC9r0]
				Nk1aK7Tfey.cAw6YbSQ5P1zoDkBp(dq7AOIkC9r0,G8xf170imLdgkjIUZrNDAq,wwe8bl92EmknVZ,*aargs)
			L8Wkv5KCSoq.sleep(pz4WBwfyDdgk0m2aRr7SMv(u"࠵࠴࠷࠶ᒣ"))
			dq7AOIkC9r0 += P2Fgh6TCOWoaHjkqBcQnvRNXe
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+yylSaxCLfkte(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫࠿ࠦࠠࠡࡒࡵࡳࡽࡿ࠺ࠡ࡝ࠣࠫ༓")+wwe8bl92EmknVZ+Olh7n0zfV4(u"ࠪࠤࡢ࠭༔"))
		finishedLIST = Nk1aK7Tfey.finishedLIST
		if finishedLIST:
			resultsDICT = Nk1aK7Tfey.resultsDICT
			jxbuL3pBlwo2WmgNyihnc = finishedLIST[ZVNvqy4iF1a9X]
			cDXLPHnAgY6NOk1GVStoiEx = resultsDICT[jxbuL3pBlwo2WmgNyihnc]
			wwe8bl92EmknVZ = YbtAUJGX7smVlqH23[int(jxbuL3pBlwo2WmgNyihnc)]
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ༕"),wwe8bl92EmknVZ)
			if jxbuL3pBlwo2WmgNyihnc!=ZVNvqy4iF1a9X: JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+E6xdOMpqISHZCn(u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡳࡴ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ༖")+wwe8bl92EmknVZ+mi2ZJXCDzITuyev6gfn(u"࠭ࠠ࡞ࠩ༗"))
			else: JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡔࡣࡹࡩࡩࠦࡰࡳࡱࡻࡽ࠿࡛༘ࠦࠡࠩ")+wwe8bl92EmknVZ+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࠢࡠ༙ࠫ"))
	return cDXLPHnAgY6NOk1GVStoiEx
def MbNudD8nL9ISUvoAP03eWxwzY1hgX(GjlMx7yUkmOCbSiR,KPfw4teDZ5Icxl6CqNmk2BrMdGHn3,zzxmVB6TM1S=w2qb6lf5EM):
	TFO2yPandux7o56V8cDI = GjlMx7yUkmOCbSiR.create_connection
	def GD4CeZaxTOWg(rkQhLjm53yIodvGl0CXg,*aargs,**kkwargs):
		wYIMiDTnadBgA,ePtg1W7SBMXR8L = rkQhLjm53yIodvGl0CXg
		ip = G1ESvrbxXq(wYIMiDTnadBgA,KPfw4teDZ5Icxl6CqNmk2BrMdGHn3)
		if ip: wYIMiDTnadBgA = ip[ZVNvqy4iF1a9X]
		elif zzxmVB6TM1S:
			if KPfw4teDZ5Icxl6CqNmk2BrMdGHn3 in Ew2zQ8u7Ss.DNS_SERVERS: Ew2zQ8u7Ss.DNS_SERVERS.remove(KPfw4teDZ5Icxl6CqNmk2BrMdGHn3)
			if Ew2zQ8u7Ss.DNS_SERVERS:
				s3V7AT4cZSK = Ew2zQ8u7Ss.DNS_SERVERS[ZVNvqy4iF1a9X]
				ip = G1ESvrbxXq(wYIMiDTnadBgA,s3V7AT4cZSK)
				if ip: wYIMiDTnadBgA = ip[ZVNvqy4iF1a9X]
		if ip: Ew2zQ8u7Ss.dns_succeeded_urls.append(wYIMiDTnadBgA)
		rkQhLjm53yIodvGl0CXg = (wYIMiDTnadBgA,ePtg1W7SBMXR8L)
		return TFO2yPandux7o56V8cDI(rkQhLjm53yIodvGl0CXg,*aargs,**kkwargs)
	GjlMx7yUkmOCbSiR.create_connection = GD4CeZaxTOWg
	return TFO2yPandux7o56V8cDI
def u4hQMlGmCfTcdtrqU13Ly(otaunYGVIJ2jX8HsKm7ecR0bAh4):
	A7XGZdWSfHTY3wJL1o9,C7jr0UVAWoLZDgte9kbc4m3Gn = otaunYGVIJ2jX8HsKm7ecR0bAh4.split(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩ࠲ࠫ༚"))[VTadWjBloMwXO2CH9GDK6FR],o2FdrDBimMuOw97q6QpNW8S(u"࠾࠰ᒤ")
	if zQGaM7ctZCN(u"ࠪ࠾ࠬ༛") in A7XGZdWSfHTY3wJL1o9: A7XGZdWSfHTY3wJL1o9,C7jr0UVAWoLZDgte9kbc4m3Gn = A7XGZdWSfHTY3wJL1o9.split(otNfFapeEnO(u"ࠫ࠿࠭༜"))
	dxUc2irl9FGyQXJ1 = ZP1LyUCS3pIBu(u"ࠬ࠵ࠧ༝")+cbmeD4WNZfAowxT2JdUMtV(u"࠭࠯ࠨ༞").join(otaunYGVIJ2jX8HsKm7ecR0bAh4.split(cbmeD4WNZfAowxT2JdUMtV(u"ࠧ࠰ࠩ༟"))[TMfV6892ZoBdyxCH3tGrkwY0K(u"࠳ᒥ"):])
	RjVAI6uzxFofm7qv = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡉࡈࡘࠥ࠭༠")+dxUc2irl9FGyQXJ1+cjVhOCwybeRo7UWg92(u"ࠩࠣࡌ࡙࡚ࡐ࠰࠳࠱࠵ࡡࡸ࡜࡯ࠩ༡")
	RjVAI6uzxFofm7qv += CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡌࡴࡹࡴ࠻ࠢࠪ༢")+A7XGZdWSfHTY3wJL1o9+Olh7n0zfV4(u"ࠫࡡࡸ࡜࡯ࠩ༣")
	RjVAI6uzxFofm7qv += o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡢࡲ࡝ࡰࠪ༤")
	from socket import socket as lybrJX1W94gjOzT2qpH,AF_INET as uxCKlcTjdXhMVSiDmU,SOCK_STREAM as ruQg8e1PjwnOxfStyqI0ADLaZ2XCd
	try:
		QXmi70BHDRnWq1 = lybrJX1W94gjOzT2qpH(uxCKlcTjdXhMVSiDmU,ruQg8e1PjwnOxfStyqI0ADLaZ2XCd)
		QXmi70BHDRnWq1.connect((A7XGZdWSfHTY3wJL1o9,C7jr0UVAWoLZDgte9kbc4m3Gn))
		QXmi70BHDRnWq1.send(RjVAI6uzxFofm7qv.encode(Im5KSGZYBpRvdMVsbuXg))
		Guq3pxjRYK9yObMg865QNfzDws1Pi = QXmi70BHDRnWq1.recv(yylSaxCLfkte(u"࠶࠳࠽࠻ᒧ")*CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠲࠲࠵࠸ᒦ"))
		z4YnlxGHF2AMtrw = repr(Guq3pxjRYK9yObMg865QNfzDws1Pi)
	except: z4YnlxGHF2AMtrw = CJlTSEpZsWb0QHg5w
	return z4YnlxGHF2AMtrw
def fUSgd7IjGYX496Hr25uFMl(vTdZUJkpi6RuY9wlsPO2AxKo83ncWB,kcxAmftieK56PE9TqbDHdSrF8):
	if E6xdOMpqISHZCn(u"࠭࠮ࠨ༥") not in vTdZUJkpi6RuY9wlsPO2AxKo83ncWB: return vTdZUJkpi6RuY9wlsPO2AxKo83ncWB
	vTdZUJkpi6RuY9wlsPO2AxKo83ncWB = vTdZUJkpi6RuY9wlsPO2AxKo83ncWB+o2FdrDBimMuOw97q6QpNW8S(u"ࠧ࠰ࠩ༦")
	Fqc9DVJ53GnbEhsRfe7poLuPyC,jjE4scKW2ClVgNfyX9qhdYozI3 = vTdZUJkpi6RuY9wlsPO2AxKo83ncWB.split(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨ࠰ࠪ༧"),cjVhOCwybeRo7UWg92(u"࠴ᒨ"))
	rr13NHqe5BfOT,A6DJUpr7IlfT8QtNv1ugXxm = jjE4scKW2ClVgNfyX9qhdYozI3.split(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ࠲ࠫ༨"),TDpFsQXHze2q30uYtGPfEIm8(u"࠵ᒩ"))
	Q6SeM0GcJNdDv4hYsxPF7aVC8E = Fqc9DVJ53GnbEhsRfe7poLuPyC+yylSaxCLfkte(u"ࠪ࠲ࠬ༩")+rr13NHqe5BfOT
	if kcxAmftieK56PE9TqbDHdSrF8 in [HaTI5u1f3SCxmMAkw(u"ࠫ࡭ࡵࡳࡵࠩ༪"),KA26GucUHOwXL(u"ࠬࡴࡡ࡮ࡧࠪ༫")] and pz4WBwfyDdgk0m2aRr7SMv(u"࠭࠯ࠨ༬") in Q6SeM0GcJNdDv4hYsxPF7aVC8E: Q6SeM0GcJNdDv4hYsxPF7aVC8E = Q6SeM0GcJNdDv4hYsxPF7aVC8E.rsplit(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧ࠰ࠩ༭"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶ᒪ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	if kcxAmftieK56PE9TqbDHdSrF8==pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡰࡤࡱࡪ࠭༮") and zQGaM7ctZCN(u"ࠩ࠱ࠫ༯") in Q6SeM0GcJNdDv4hYsxPF7aVC8E:
		kbuKNPsDyLz6OvJgQGFiq2omj4hU7n = Q6SeM0GcJNdDv4hYsxPF7aVC8E.split(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪ࠲ࠬ༰"))
		G7N4Mz9HPU0CwasdkrRWgAu = len(kbuKNPsDyLz6OvJgQGFiq2omj4hU7n)
		if rC5tnFDlQcRGA2(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ༱") in Q6SeM0GcJNdDv4hYsxPF7aVC8E: kbuKNPsDyLz6OvJgQGFiq2omj4hU7n = O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ༲")
		elif G7N4Mz9HPU0CwasdkrRWgAu<=VTadWjBloMwXO2CH9GDK6FR: kbuKNPsDyLz6OvJgQGFiq2omj4hU7n = kbuKNPsDyLz6OvJgQGFiq2omj4hU7n[ZVNvqy4iF1a9X]
		elif G7N4Mz9HPU0CwasdkrRWgAu>=D9yBM7wPFLz: kbuKNPsDyLz6OvJgQGFiq2omj4hU7n = kbuKNPsDyLz6OvJgQGFiq2omj4hU7n[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		if len(kbuKNPsDyLz6OvJgQGFiq2omj4hU7n)>P2Fgh6TCOWoaHjkqBcQnvRNXe: Q6SeM0GcJNdDv4hYsxPF7aVC8E = kbuKNPsDyLz6OvJgQGFiq2omj4hU7n
	return Q6SeM0GcJNdDv4hYsxPF7aVC8E
def lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(VZAbHEDekzlFdUrvnMTG):
	EdUpJSrP2IbtmXx9WGLz0kaMon = repr(VZAbHEDekzlFdUrvnMTG.encode(Im5KSGZYBpRvdMVsbuXg)).replace(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࠧࠣ༳"),CJlTSEpZsWb0QHg5w)
	return EdUpJSrP2IbtmXx9WGLz0kaMon
def CqvfpVUrZNTzdiXKnx69Q2m7L8AuF(RFXEox3G0AyWCH):
	NNeJoSGfv7tF = CJlTSEpZsWb0QHg5w
	if BB7oCRfQNSYj5qDhTUevV: RFXEox3G0AyWCH = RFXEox3G0AyWCH.decode(Im5KSGZYBpRvdMVsbuXg)
	from unicodedata import decomposition as H5P16f7v0u
	for AtEsobIQdFVUzO in RFXEox3G0AyWCH:
		if   AtEsobIQdFVUzO==zz679V18GdcZwvrRexA0nNptY2Tab(u"ࡵࠨฤࠪ༴"): mEKFAS8NkeisG5whJvzUy3Lad = cbmeD4WNZfAowxT2JdUMtV(u"ࠨ࡞࡟ࡹ࠵࠼࠲࠳༵ࠩ")
		elif AtEsobIQdFVUzO==TDpFsQXHze2q30uYtGPfEIm8(u"ࡷࠪวࠬ༶"): mEKFAS8NkeisG5whJvzUy3Lad = JACnOz297UuDK5HpPkc1LF(u"ࠪࡠࡡࡻ࠰࠷࠴࠶༷ࠫ")
		elif AtEsobIQdFVUzO==rC5tnFDlQcRGA2(u"ࡹࠬสࠧ༸"): mEKFAS8NkeisG5whJvzUy3Lad = cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠹༹࠭")
		elif AtEsobIQdFVUzO==pz4WBwfyDdgk0m2aRr7SMv(u"ࡻࠧฦࠩ༺"): mEKFAS8NkeisG5whJvzUy3Lad = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠵ࠨ༻")
		elif AtEsobIQdFVUzO==pz4WBwfyDdgk0m2aRr7SMv(u"ࡶࠩษࠫ༼"): mEKFAS8NkeisG5whJvzUy3Lad = GISOTJh20W(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠸ࠪ༽")
		else:
			ptiI4clbeMU = H5P16f7v0u(AtEsobIQdFVUzO)
			if YvOQBzaTAscXR9ql in ptiI4clbeMU: mEKFAS8NkeisG5whJvzUy3Lad = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡠࡡࡻࠧ༾")+ptiI4clbeMU.split(YvOQBzaTAscXR9ql,P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			else:
				mEKFAS8NkeisG5whJvzUy3Lad = O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ࠵࠶࠰࠱ࠩ༿")+hex(ord(AtEsobIQdFVUzO)).replace(yylSaxCLfkte(u"ࠬ࠶ࡸࠨཀ"),CJlTSEpZsWb0QHg5w)
				mEKFAS8NkeisG5whJvzUy3Lad = pz4WBwfyDdgk0m2aRr7SMv(u"࠭࡜࡝ࡷࠪཁ")+mEKFAS8NkeisG5whJvzUy3Lad[-P3cpaLN2sH:]
		NNeJoSGfv7tF += mEKFAS8NkeisG5whJvzUy3Lad
	NNeJoSGfv7tF = NNeJoSGfv7tF.replace(KA26GucUHOwXL(u"ࠧ࡝࡞ࡸ࠴࠻ࡉࡃࠨག"),KA26GucUHOwXL(u"ࠨ࡞࡟ࡹ࠵࠼࠴࠺ࠩགྷ"))
	if BB7oCRfQNSYj5qDhTUevV: NNeJoSGfv7tF = NNeJoSGfv7tF.decode(zQGaM7ctZCN(u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪང")).encode(Im5KSGZYBpRvdMVsbuXg)
	else: NNeJoSGfv7tF = NNeJoSGfv7tF.encode(Im5KSGZYBpRvdMVsbuXg).decode(KA26GucUHOwXL(u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫཅ"))
	return NNeJoSGfv7tF
def tmMVl2yEWYoRg1LjHfPXGc7wqK0s(header=KA26GucUHOwXL(u"้ࠫ๎อสࠢส่๊็วห์ะࠫཆ"),twIOydEe6zhn1s=CJlTSEpZsWb0QHg5w,ZIWbuMK8O9dwV=VJZIMkUN5siqB21Pf,source=CJlTSEpZsWb0QHg5w):
	AyKma12GRYnziLV7EWIjUM = yHg4QIFOx06mfGocDN9REX7(header,twIOydEe6zhn1s,type=rTF8V7fLD2SXJbAURpZjQ4wH.INPUT_ALPHANUM)
	AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.strip(YvOQBzaTAscXR9ql).replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	if not AyKma12GRYnziLV7EWIjUM and not ZIWbuMK8O9dwV:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,mi2ZJXCDzITuyev6gfn(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡦࡥࡳࡩࡥ࡭ࡧࡧ࠾ࠥࠦࠠࠣࠩཇ")+AyKma12GRYnziLV7EWIjUM+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࠢࠨ཈"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yylSaxCLfkte(u"ࠧห็ࠣษ้เวยࠢส่สีฮศๆࠪཉ"))
		return CJlTSEpZsWb0QHg5w
	if AyKma12GRYnziLV7EWIjUM not in [CJlTSEpZsWb0QHg5w,YvOQBzaTAscXR9ql]:
		AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.strip(YvOQBzaTAscXR9ql)
		AyKma12GRYnziLV7EWIjUM = CqvfpVUrZNTzdiXKnx69Q2m7L8AuF(AyKma12GRYnziLV7EWIjUM)
	if source!=h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪཊ") and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(zQGaM7ctZCN(u"ࠩࡎࡉ࡞ࡈࡏࡂࡔࡇࠫཋ"),CJlTSEpZsWb0QHg5w,[AyKma12GRYnziLV7EWIjUM],VJZIMkUN5siqB21Pf):
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,VVvcQpCU3OM09n(u"ࠪ࠲ࡡࡺࡋࡦࡻࡥࡳࡦࡸࡤࠡࡧࡱࡸࡷࡿࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ཌ")+AyKma12GRYnziLV7EWIjUM+pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࠧ࠭ཌྷ"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Olh7n0zfV4(u"ࠬอๆหࠢๆฮอะࠠไๆ่อࠥษ่ࠡำๅ้๊ࠥ็ࠡ฻็ห็ฯࠠษลไ่ฬ๋ࠠๅๆๆฬฬืࠠโไฺࠤ࠳࠴้้ࠠำหࠥอไษำ้ห๊าࠠๅษࠣ๎ุ๋อࠡสสืฯิฯศ็๋่ࠣึวࠡๅ็้ฬะࠧཎ"))
		return CJlTSEpZsWb0QHg5w
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,EcjO3giln2kQTdBY0XLAG(u"࠭࠮࡝ࡶࡎࡩࡾࡨ࡯ࡢࡴࡧࠤࡪࡴࡴࡳࡻࠣࡥࡱࡲ࡯ࡸࡧࡧ࠾ࠥࠦࠠࠣࠩཏ")+AyKma12GRYnziLV7EWIjUM+s97s2k0LJgl(u"ࠧࠣࠩཐ"))
	return AyKma12GRYnziLV7EWIjUM
def bUD0vMHIQhKW(T1QDsJlUtCGhn,BBwfuWGxUIrdCoc4ka7,bsGedm1TLP7EgiUQDkCy={}):
	otaunYGVIJ2jX8HsKm7ecR0bAh4,DbWhLtyMFS,s2BDjNPyHOIbEmUw63RkGAJeVMp4K,sgfySRK1jcF2iohM7OUZHx4Je0r = BBwfuWGxUIrdCoc4ka7,{},{},CJlTSEpZsWb0QHg5w
	if E6xdOMpqISHZCn(u"ࠨࡾࠪད") in BBwfuWGxUIrdCoc4ka7: otaunYGVIJ2jX8HsKm7ecR0bAh4,DbWhLtyMFS = degRiWptawTqXvKNh(BBwfuWGxUIrdCoc4ka7,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡿࠫདྷ"))
	pu2iDICZX4K9gH = list(set(list(bsGedm1TLP7EgiUQDkCy.keys())+list(DbWhLtyMFS.keys())))
	for IVZCbl4keXui in pu2iDICZX4K9gH:
		if IVZCbl4keXui in list(DbWhLtyMFS.keys()): s2BDjNPyHOIbEmUw63RkGAJeVMp4K[IVZCbl4keXui] = DbWhLtyMFS[IVZCbl4keXui]
		else: s2BDjNPyHOIbEmUw63RkGAJeVMp4K[IVZCbl4keXui] = bsGedm1TLP7EgiUQDkCy[IVZCbl4keXui]
	if mi2ZJXCDzITuyev6gfn(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧན") not in pu2iDICZX4K9gH: s2BDjNPyHOIbEmUw63RkGAJeVMp4K[GISOTJh20W(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨཔ")] = jQW9RpucaCLHX0sSBD6lrif58e47nt()
	if cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ཕ") not in pu2iDICZX4K9gH: s2BDjNPyHOIbEmUw63RkGAJeVMp4K[O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧབ")] = fUSgd7IjGYX496Hr25uFMl(otaunYGVIJ2jX8HsKm7ecR0bAh4,s97s2k0LJgl(u"ࠧࡶࡴ࡯ࠫབྷ"))
	if E6xdOMpqISHZCn(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪམ") not in pu2iDICZX4K9gH: s2BDjNPyHOIbEmUw63RkGAJeVMp4K[yylSaxCLfkte(u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫཙ")] = KA26GucUHOwXL(u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠼ࠫཚ")
	for IVZCbl4keXui in list(s2BDjNPyHOIbEmUw63RkGAJeVMp4K.keys()): sgfySRK1jcF2iohM7OUZHx4Je0r += yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࠫ࠭ཛ")+IVZCbl4keXui+VVvcQpCU3OM09n(u"ࠬࡃࠧཛྷ")+s2BDjNPyHOIbEmUw63RkGAJeVMp4K[IVZCbl4keXui]
	if sgfySRK1jcF2iohM7OUZHx4Je0r: sgfySRK1jcF2iohM7OUZHx4Je0r = E6xdOMpqISHZCn(u"࠭ࡼࠨཝ")+sgfySRK1jcF2iohM7OUZHx4Je0r[P2Fgh6TCOWoaHjkqBcQnvRNXe:]
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(zz5iuewhAFONn8GQc0DtyKZ317pHo,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡈࡇࡗࠫཞ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,CJlTSEpZsWb0QHg5w,s2BDjNPyHOIbEmUw63RkGAJeVMp4K,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑ࠸࡛࠸࠮࠳ࡶࡸࠬཟ"),VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
	if xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡖࡘࡗࡋࡁࡎ࠯ࡌࡒࡋ࠭འ") not in z4YnlxGHF2AMtrw: return [VVvcQpCU3OM09n(u"ࠪ࠱࠶࠭ཡ")],[otaunYGVIJ2jX8HsKm7ecR0bAh4+sgfySRK1jcF2iohM7OUZHx4Je0r]
	if cbmeD4WNZfAowxT2JdUMtV(u"࡙ࠫ࡟ࡐࡆ࠿ࡄ࡙ࡉࡏࡏࠨར") in z4YnlxGHF2AMtrw: return [h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ࠳࠱ࠨལ")],[otaunYGVIJ2jX8HsKm7ecR0bAh4+sgfySRK1jcF2iohM7OUZHx4Je0r]
	if XB4CjMkPFzhAHiI3q(u"࠭ࡔ࡚ࡒࡈࡁ࡛ࡏࡄࡆࡑࠪཤ") in z4YnlxGHF2AMtrw: return [xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧ࠮࠳ࠪཥ")],[otaunYGVIJ2jX8HsKm7ecR0bAh4+sgfySRK1jcF2iohM7OUZHx4Je0r]
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,q96XVhAdWT1yr2cxHZ48f,udrCzRExmyiZbS18BDfO = [],[],[],[]
	xWMpqasJ9BD = Zy2l0g8QU5vqefaTrsw.findall(zQGaM7ctZCN(u"ࠨࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡸ࡜࡯࡟࠮ࠬ࠳࠰࠿ࠪ࡝࡟ࡶࡡࡴ࡝ࠬࠩས"),z4YnlxGHF2AMtrw+rJ9cgWz4FU,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not xWMpqasJ9BD: return [I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩ࠰࠵ࠬཧ")],[otaunYGVIJ2jX8HsKm7ecR0bAh4+sgfySRK1jcF2iohM7OUZHx4Je0r]
	for Oo8Hc9Xel1CFtv,vTdZUJkpi6RuY9wlsPO2AxKo83ncWB in xWMpqasJ9BD:
		dHJqy86aClLtceBW,ksDvwLIca3bHm,egYIsS2qROfpVW83kx = {},-mi2ZJXCDzITuyev6gfn(u"࠷ᒫ"),-mi2ZJXCDzITuyev6gfn(u"࠷ᒫ")
		LdWDNcvAkSjF5xMXhVUI8mfZK = CJlTSEpZsWb0QHg5w
		LL2H35jbrMlkIOR7C = Oo8Hc9Xel1CFtv.split(zQGaM7ctZCN(u"ࠪ࠰ࠬཨ"))
		for ZBstQ7jF04zNp8EmHoY5A in LL2H35jbrMlkIOR7C:
			if HaTI5u1f3SCxmMAkw(u"ࠫࡂ࠭ཀྵ") in ZBstQ7jF04zNp8EmHoY5A:
				IVZCbl4keXui,s7DAv92CkQXqVPOGS3Bxn = ZBstQ7jF04zNp8EmHoY5A.split(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡃࠧཪ"),pz4WBwfyDdgk0m2aRr7SMv(u"࠱ᒬ"))
				dHJqy86aClLtceBW[IVZCbl4keXui.lower()] = s7DAv92CkQXqVPOGS3Bxn
		if rC5tnFDlQcRGA2(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪཫ") in Oo8Hc9Xel1CFtv.lower():
			ksDvwLIca3bHm = int(dHJqy86aClLtceBW[s97s2k0LJgl(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫཬ")])//ZP1LyUCS3pIBu(u"࠲࠲࠵࠸ᒭ")
			LdWDNcvAkSjF5xMXhVUI8mfZK += str(ksDvwLIca3bHm)+mi2ZJXCDzITuyev6gfn(u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ཭")
		elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ཮") in Oo8Hc9Xel1CFtv.lower():
			ksDvwLIca3bHm = int(dHJqy86aClLtceBW[E6xdOMpqISHZCn(u"ࠪࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭࠭཯")])//rC5tnFDlQcRGA2(u"࠳࠳࠶࠹ᒮ")
			LdWDNcvAkSjF5xMXhVUI8mfZK += str(ksDvwLIca3bHm)+pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡰࡨࡰࡴࠢࠣࠫ཰")
		if otNfFapeEnO(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ཱࠩ") in Oo8Hc9Xel1CFtv.lower():
			egYIsS2qROfpVW83kx = int(dHJqy86aClLtceBW[HaTI5u1f3SCxmMAkw(u"࠭ࡲࡦࡵࡲࡰࡺࡺࡩࡰࡰིࠪ")].split(VVvcQpCU3OM09n(u"ࠧࡹཱིࠩ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe])
			LdWDNcvAkSjF5xMXhVUI8mfZK += str(egYIsS2qROfpVW83kx)+gCc52XVMGfAnOe
		LdWDNcvAkSjF5xMXhVUI8mfZK = LdWDNcvAkSjF5xMXhVUI8mfZK.strip(gCc52XVMGfAnOe)
		if not LdWDNcvAkSjF5xMXhVUI8mfZK: LdWDNcvAkSjF5xMXhVUI8mfZK = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ུࠩ")
		if not vTdZUJkpi6RuY9wlsPO2AxKo83ncWB.startswith(JACnOz297UuDK5HpPkc1LF(u"ࠩ࡫ࡸࡹࡶཱུࠧ")):
			if vTdZUJkpi6RuY9wlsPO2AxKo83ncWB.startswith(ZP1LyUCS3pIBu(u"ࠪ࠳࠴࠭ྲྀ")): vTdZUJkpi6RuY9wlsPO2AxKo83ncWB = otaunYGVIJ2jX8HsKm7ecR0bAh4.split(XB4CjMkPFzhAHiI3q(u"ࠫ࠿࠭ཷ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡀࠧླྀ")+vTdZUJkpi6RuY9wlsPO2AxKo83ncWB
			elif vTdZUJkpi6RuY9wlsPO2AxKo83ncWB.startswith(KA26GucUHOwXL(u"࠭࠯ࠨཹ")): vTdZUJkpi6RuY9wlsPO2AxKo83ncWB = fUSgd7IjGYX496Hr25uFMl(otaunYGVIJ2jX8HsKm7ecR0bAh4,cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡶࡴ࡯ེࠫ"))+vTdZUJkpi6RuY9wlsPO2AxKo83ncWB
			else: vTdZUJkpi6RuY9wlsPO2AxKo83ncWB = otaunYGVIJ2jX8HsKm7ecR0bAh4.rsplit(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨ࠱ཻࠪ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]+cjVhOCwybeRo7UWg92(u"ࠩ࠲ོࠫ")+vTdZUJkpi6RuY9wlsPO2AxKo83ncWB
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ཽࠬ") in list(dHJqy86aClLtceBW.keys()):
			otCOTHujWKp7Dn6dvcafPqlx = dHJqy86aClLtceBW[O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭ཾ")]
			otCOTHujWKp7Dn6dvcafPqlx = otCOTHujWKp7Dn6dvcafPqlx.replace(zQGaM7ctZCN(u"ࠬࠨࠧཿ"),CJlTSEpZsWb0QHg5w).replace(cbmeD4WNZfAowxT2JdUMtV(u"ࠨྀࠧࠣ"),CJlTSEpZsWb0QHg5w).split(o2FdrDBimMuOw97q6QpNW8S(u"ࠧࠤཱྀࠩ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
			pJkizt1GSHY62rhElDZjX = XETbMJIf1yetlQSinA2NW5YHvag6D(otCOTHujWKp7Dn6dvcafPqlx)
			if pJkizt1GSHY62rhElDZjX: II4x930lvTuVqekXBNCrMy = LdWDNcvAkSjF5xMXhVUI8mfZK+gCc52XVMGfAnOe+pJkizt1GSHY62rhElDZjX
			else: II4x930lvTuVqekXBNCrMy = LdWDNcvAkSjF5xMXhVUI8mfZK
			II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࠢࠣࡔࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥࠨྂ")
			II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy+gCc52XVMGfAnOe+fUSgd7IjGYX496Hr25uFMl(otCOTHujWKp7Dn6dvcafPqlx,s97s2k0LJgl(u"ࠩࡱࡥࡲ࡫ࠧྃ"))
			Uz8mMbZifCyvkLnct.append(II4x930lvTuVqekXBNCrMy)
			MNXzjK3vV7D.append(otCOTHujWKp7Dn6dvcafPqlx)
			q96XVhAdWT1yr2cxHZ48f.append(egYIsS2qROfpVW83kx)
			udrCzRExmyiZbS18BDfO.append(ksDvwLIca3bHm)
		vTdZUJkpi6RuY9wlsPO2AxKo83ncWB = vTdZUJkpi6RuY9wlsPO2AxKo83ncWB.split(JACnOz297UuDK5HpPkc1LF(u"྄ࠪࠧࠬ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		pJkizt1GSHY62rhElDZjX = XETbMJIf1yetlQSinA2NW5YHvag6D(vTdZUJkpi6RuY9wlsPO2AxKo83ncWB)
		if pJkizt1GSHY62rhElDZjX: LdWDNcvAkSjF5xMXhVUI8mfZK = LdWDNcvAkSjF5xMXhVUI8mfZK+gCc52XVMGfAnOe+pJkizt1GSHY62rhElDZjX
		LdWDNcvAkSjF5xMXhVUI8mfZK = LdWDNcvAkSjF5xMXhVUI8mfZK+gCc52XVMGfAnOe+fUSgd7IjGYX496Hr25uFMl(vTdZUJkpi6RuY9wlsPO2AxKo83ncWB,cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡳࡧ࡭ࡦࠩ྅"))
		Uz8mMbZifCyvkLnct.append(LdWDNcvAkSjF5xMXhVUI8mfZK)
		MNXzjK3vV7D.append(vTdZUJkpi6RuY9wlsPO2AxKo83ncWB)
		q96XVhAdWT1yr2cxHZ48f.append(egYIsS2qROfpVW83kx)
		udrCzRExmyiZbS18BDfO.append(ksDvwLIca3bHm)
	xxMT4HEkmJgz = list(zip(Uz8mMbZifCyvkLnct,MNXzjK3vV7D,q96XVhAdWT1yr2cxHZ48f,udrCzRExmyiZbS18BDfO))
	xxMT4HEkmJgz = sorted(xxMT4HEkmJgz, reverse=w2qb6lf5EM, key=lambda key: key[D9yBM7wPFLz])
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,q96XVhAdWT1yr2cxHZ48f,udrCzRExmyiZbS18BDfO = list(zip(*xxMT4HEkmJgz))
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = list(Uz8mMbZifCyvkLnct),list(MNXzjK3vV7D)
	nKGBqEpeizbMmYHuIUWlrovCgLkA = []
	for vTdZUJkpi6RuY9wlsPO2AxKo83ncWB in MNXzjK3vV7D: nKGBqEpeizbMmYHuIUWlrovCgLkA.append(vTdZUJkpi6RuY9wlsPO2AxKo83ncWB+sgfySRK1jcF2iohM7OUZHx4Je0r)
	bTxVLweoWPMu = list(zip(nKGBqEpeizbMmYHuIUWlrovCgLkA,[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡪࡵ࡮࡯ࡼࠫ྆")]*len(nKGBqEpeizbMmYHuIUWlrovCgLkA),udrCzRExmyiZbS18BDfO))
	guEnNcSqKeBsYLmzilb = FWK9ZMPpVauYrEH2v(T1QDsJlUtCGhn,bTxVLweoWPMu)
	if guEnNcSqKeBsYLmzilb:
		ZgsbN5iSL48t2IhVFnmy,Cm7xuRTdLQwZjv81V2AhKfqs04U,ksDvwLIca3bHm = guEnNcSqKeBsYLmzilb[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠳ᒯ")]
		index = nKGBqEpeizbMmYHuIUWlrovCgLkA.index(ZgsbN5iSL48t2IhVFnmy)
		title = Uz8mMbZifCyvkLnct[index]
		Uz8mMbZifCyvkLnct,nKGBqEpeizbMmYHuIUWlrovCgLkA = [title],[ZgsbN5iSL48t2IhVFnmy]
	return Uz8mMbZifCyvkLnct,nKGBqEpeizbMmYHuIUWlrovCgLkA
def G1ESvrbxXq(wYIMiDTnadBgA,KPfw4teDZ5Icxl6CqNmk2BrMdGHn3=CJlTSEpZsWb0QHg5w):
	if not KPfw4teDZ5Icxl6CqNmk2BrMdGHn3: KPfw4teDZ5Icxl6CqNmk2BrMdGHn3 = Ew2zQ8u7Ss.DNS_SERVERS[ZVNvqy4iF1a9X]
	if wYIMiDTnadBgA.replace(cjVhOCwybeRo7UWg92(u"࠭࠮ࠨ྇"),CJlTSEpZsWb0QHg5w).isdigit(): return [wYIMiDTnadBgA]
	from struct import pack as xxVbaUcuqn,unpack_from as ggIS9ormhKz67G
	from socket import socket as lybrJX1W94gjOzT2qpH,AF_INET as uxCKlcTjdXhMVSiDmU,SOCK_DGRAM as GGaDTfW7bQ6wFZNS2
	try:
		oKa1EenBHl8Ou0vJy4 = xxVbaUcuqn(cbmeD4WNZfAowxT2JdUMtV(u"ࠢ࠿ࡊࠥྈ"), cjVhOCwybeRo7UWg92(u"࠵࠷࠶࠴࠺ᒰ"))
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(cbmeD4WNZfAowxT2JdUMtV(u"ࠣࡀࡋࠦྉ"), XB4CjMkPFzhAHiI3q(u"࠷࠻࠶ᒱ"))
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(o2FdrDBimMuOw97q6QpNW8S(u"ࠤࡁࡌࠧྊ"), P2Fgh6TCOWoaHjkqBcQnvRNXe)
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(otNfFapeEnO(u"ࠥࡂࡍࠨྋ"), ZVNvqy4iF1a9X)
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(otNfFapeEnO(u"ࠦࡃࡎࠢྌ"), ZVNvqy4iF1a9X)
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡄࡈࠣྍ"), ZVNvqy4iF1a9X)
		if A7Z6OVh20eCEUx: Y6uAlbJfZwtdhmV5GXq8cUI0S = wYIMiDTnadBgA.split(VVvcQpCU3OM09n(u"࠭࠮ࠨྎ"))
		else: Y6uAlbJfZwtdhmV5GXq8cUI0S = wYIMiDTnadBgA.decode(Im5KSGZYBpRvdMVsbuXg).split(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧ࠯ࠩྏ"))
		for I3IjyoftS7VqQROz8YTZg in Y6uAlbJfZwtdhmV5GXq8cUI0S:
			iDqtORs9A8VflY2Kd1T0n6BC5a = I3IjyoftS7VqQROz8YTZg.encode(Im5KSGZYBpRvdMVsbuXg)
			oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(JACnOz297UuDK5HpPkc1LF(u"ࠣࡄࠥྐ"), len(I3IjyoftS7VqQROz8YTZg))
			for W57HdtsPVUcD804mfvKwMI6nNoau2C in I3IjyoftS7VqQROz8YTZg:
				oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(yylSaxCLfkte(u"ࠤࡦࠦྑ"), W57HdtsPVUcD804mfvKwMI6nNoau2C.encode(Im5KSGZYBpRvdMVsbuXg))
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠥࡆࠧྒ"), ZVNvqy4iF1a9X)
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠦࡃࡎࠢྒྷ"), P2Fgh6TCOWoaHjkqBcQnvRNXe)
		oKa1EenBHl8Ou0vJy4 += xxVbaUcuqn(cjVhOCwybeRo7UWg92(u"ࠧࡄࡈࠣྔ"), P2Fgh6TCOWoaHjkqBcQnvRNXe)
		C90zDgIkV6fumMNRr3ZYlesK2XW = lybrJX1W94gjOzT2qpH(uxCKlcTjdXhMVSiDmU,GGaDTfW7bQ6wFZNS2)
		C90zDgIkV6fumMNRr3ZYlesK2XW.sendto(bytes(oKa1EenBHl8Ou0vJy4),(KPfw4teDZ5Icxl6CqNmk2BrMdGHn3,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠻࠳ᒲ")))
		C90zDgIkV6fumMNRr3ZYlesK2XW.settimeout(cbmeD4WNZfAowxT2JdUMtV(u"࠶ᒳ"))
		qPWgu3zkRbrv74yho, vKmBNhGwAo4yzIcWZrLk93Ofa = C90zDgIkV6fumMNRr3ZYlesK2XW.recvfrom(mi2ZJXCDzITuyev6gfn(u"࠲࠲࠵࠸ᒴ"))
		C90zDgIkV6fumMNRr3ZYlesK2XW.close()
		HU8o4nWbe19BliPrYzEp62fFRMcT = ggIS9ormhKz67G(KA26GucUHOwXL(u"ࠨ࠾ࡉࡊࡋࡌࡍࡎࠢྕ"), qPWgu3zkRbrv74yho, ZVNvqy4iF1a9X)
		EEKLVT830OoNqYtW = HU8o4nWbe19BliPrYzEp62fFRMcT[D9yBM7wPFLz]
		COBkW8Gn4F0TIgY = len(wYIMiDTnadBgA)+otNfFapeEnO(u"࠳࠻ᒵ")
		B5B97KCQSDNcVWJb8RjxvL = []
		for _Oj03Nh7YuBqHeLAVX in range(EEKLVT830OoNqYtW):
			bb97P3TKnxhiGXyQM = COBkW8Gn4F0TIgY
			yJdvP7RNczhYqwZSo9kO2btmeTj4aK = P2Fgh6TCOWoaHjkqBcQnvRNXe
			v9xRJpVBQU1yLaSNtsYWKlGEOjPT = VJZIMkUN5siqB21Pf
			while w2qb6lf5EM:
				W57HdtsPVUcD804mfvKwMI6nNoau2C = ggIS9ormhKz67G(HaTI5u1f3SCxmMAkw(u"ࠢ࠿ࡄࠥྖ"), qPWgu3zkRbrv74yho, bb97P3TKnxhiGXyQM)[ZVNvqy4iF1a9X]
				if W57HdtsPVUcD804mfvKwMI6nNoau2C == ZVNvqy4iF1a9X:
					bb97P3TKnxhiGXyQM += P2Fgh6TCOWoaHjkqBcQnvRNXe
					break
				if W57HdtsPVUcD804mfvKwMI6nNoau2C >= TDpFsQXHze2q30uYtGPfEIm8(u"࠴࠽࠷ᒶ"):
					nHXkG6M2Bo40qda7VthUOAbSIgxFEP = ggIS9ormhKz67G(rC5tnFDlQcRGA2(u"ࠣࡀࡅࠦྗ"), qPWgu3zkRbrv74yho, bb97P3TKnxhiGXyQM + P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
					bb97P3TKnxhiGXyQM = ((W57HdtsPVUcD804mfvKwMI6nNoau2C << JACnOz297UuDK5HpPkc1LF(u"࠼ᒷ")) + nHXkG6M2Bo40qda7VthUOAbSIgxFEP - 0xc000) - P2Fgh6TCOWoaHjkqBcQnvRNXe
					v9xRJpVBQU1yLaSNtsYWKlGEOjPT = w2qb6lf5EM
				bb97P3TKnxhiGXyQM += P2Fgh6TCOWoaHjkqBcQnvRNXe
				if v9xRJpVBQU1yLaSNtsYWKlGEOjPT == VJZIMkUN5siqB21Pf: yJdvP7RNczhYqwZSo9kO2btmeTj4aK += P2Fgh6TCOWoaHjkqBcQnvRNXe
			if v9xRJpVBQU1yLaSNtsYWKlGEOjPT == w2qb6lf5EM: yJdvP7RNczhYqwZSo9kO2btmeTj4aK += P2Fgh6TCOWoaHjkqBcQnvRNXe
			COBkW8Gn4F0TIgY = COBkW8Gn4F0TIgY + yJdvP7RNczhYqwZSo9kO2btmeTj4aK
			yZX5HTKaVx6iCBgu2IqfGlW1tL = ggIS9ormhKz67G(GISOTJh20W(u"ࠤࡁࡌࡍࡏࡈࠣ྘"), qPWgu3zkRbrv74yho, COBkW8Gn4F0TIgY)
			COBkW8Gn4F0TIgY = COBkW8Gn4F0TIgY + s97s2k0LJgl(u"࠶࠶ᒸ")
			f3Z2Wthnx4zDPlNE0 = yZX5HTKaVx6iCBgu2IqfGlW1tL[ZVNvqy4iF1a9X]
			x9A12JZbtGkmdRHE3YsOU85e = yZX5HTKaVx6iCBgu2IqfGlW1tL[D9yBM7wPFLz]
			if f3Z2Wthnx4zDPlNE0 == P2Fgh6TCOWoaHjkqBcQnvRNXe:
				JKRaDUNEuX7FkAc5LQBt = ggIS9ormhKz67G(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠥࡂࠧྙ")+mi2ZJXCDzITuyev6gfn(u"ࠦࡇࠨྚ")*x9A12JZbtGkmdRHE3YsOU85e, qPWgu3zkRbrv74yho, COBkW8Gn4F0TIgY)
				ip = CJlTSEpZsWb0QHg5w
				for W57HdtsPVUcD804mfvKwMI6nNoau2C in JKRaDUNEuX7FkAc5LQBt: ip += str(W57HdtsPVUcD804mfvKwMI6nNoau2C) + od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬ࠴ࠧྛ")
				ip = ip[ZVNvqy4iF1a9X:-P2Fgh6TCOWoaHjkqBcQnvRNXe]
				B5B97KCQSDNcVWJb8RjxvL.append(ip)
			if f3Z2Wthnx4zDPlNE0 in [P2Fgh6TCOWoaHjkqBcQnvRNXe,VTadWjBloMwXO2CH9GDK6FR,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠶ᒻ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠸ᒼ"),cjVhOCwybeRo7UWg92(u"࠱࠶ᒺ"),mi2ZJXCDzITuyev6gfn(u"࠸࠸ᒹ")]: COBkW8Gn4F0TIgY = COBkW8Gn4F0TIgY + x9A12JZbtGkmdRHE3YsOU85e
	except: B5B97KCQSDNcVWJb8RjxvL = []
	if not B5B97KCQSDNcVWJb8RjxvL: JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+mi2ZJXCDzITuyev6gfn(u"࠭ࠠࠡࠢࡇࡒࡘࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡌࡴࡹࡴ࠻ࠢ࡞ࠤࠬྜ")+wYIMiDTnadBgA+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࠡ࡟ࠪྜྷ"))
	return B5B97KCQSDNcVWJb8RjxvL
def GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,otaunYGVIJ2jX8HsKm7ecR0bAh4,aIW8LXhxq2Gkdv9YQCPHrwORFZJE,showDialogs=w2qb6lf5EM):
	if Ew2zQ8u7Ss.avprivsnorestrict or not aIW8LXhxq2Gkdv9YQCPHrwORFZJE: return VJZIMkUN5siqB21Pf
	nEHeYNbqmzgKLMurFoIdivksJGDT6 = [O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡣࡧࡹࡱࡺࠧྞ"),Olh7n0zfV4(u"ࠩ࠴࠼࠰࠭ྟ"),zQGaM7ctZCN(u"ࠪࡼࡽ࠭ྠ"),XB4CjMkPFzhAHiI3q(u"ࠫࡵࡵࡲ࡯ࠩྡ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡹࡥࡹࠩྡྷ"),VVvcQpCU3OM09n(u"࠭࡮ࡴࡨࡺࠫྣ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧ࡮ࡣࡷࡹࡷ࡫ࠧྤ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨๅหหึ࠭ྥ"),cjVhOCwybeRo7UWg92(u"ࠩหห้เࠧྦ"),HaTI5u1f3SCxmMAkw(u"ࠪหอออ๋ࠩྦྷ"),Olh7n0zfV4(u"ࠫั์ำࠨྨ"),cbmeD4WNZfAowxT2JdUMtV(u"๋ࠬๅ็๊฼ࠫྩ")]
	if T1QDsJlUtCGhn!=od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡂࡐࡍࡕࡅࠬྪ"): nEHeYNbqmzgKLMurFoIdivksJGDT6 += [ZP1LyUCS3pIBu(u"ࠧࡳ࠼ࠪྫ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨ࠼ࡵࠫྫྷ"),cjVhOCwybeRo7UWg92(u"ࠩࡵ࠱ࠬྭ"),yylSaxCLfkte(u"ࠪ࠱ࡷ࠭ྮ"),XB4CjMkPFzhAHiI3q(u"ࠫ࠲ࡳࡡࠨྯ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡳࡡ࠮ࠩྰ")]
	for ccnb52oKNm9ts6xyXYJBL0E in aIW8LXhxq2Gkdv9YQCPHrwORFZJE:
		ccnb52oKNm9ts6xyXYJBL0E = ccnb52oKNm9ts6xyXYJBL0E.lower()
		if s97s2k0LJgl(u"࠭ࡧࡦࡶ࠱ࡴ࡭ࡶ࠿ࠨྱ") in ccnb52oKNm9ts6xyXYJBL0E: continue
		if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧ࡯ࡱࡷࠤࡷࡧࡴࡦࡦࠪྲ") in ccnb52oKNm9ts6xyXYJBL0E: continue
		if XB4CjMkPFzhAHiI3q(u"ࠨࡷࡱࡶࡦࡺࡥࡥࠩླ") in ccnb52oKNm9ts6xyXYJBL0E: continue
		if s97s2k0LJgl(u"ࠩะ่็ฯࠧྴ") in ccnb52oKNm9ts6xyXYJBL0E: continue
		if otNfFapeEnO(u"ࠪ฾๏ืࠠๆื้ๅࠬྵ") in ccnb52oKNm9ts6xyXYJBL0E: continue
		ccnb52oKNm9ts6xyXYJBL0E = ccnb52oKNm9ts6xyXYJBL0E.replace(Olh7n0zfV4(u"ࠫศ࠭ྶ"),E6xdOMpqISHZCn(u"ࠬอࠧྷ")).replace(TDpFsQXHze2q30uYtGPfEIm8(u"࠭ลࠨྸ"),E6xdOMpqISHZCn(u"ࠧศࠩྐྵ")).replace(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨฤࠪྺ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠩสࠫྻ")).replace(HaTI5u1f3SCxmMAkw(u"ࠪ๒ࠬྼ"),CJlTSEpZsWb0QHg5w).replace(yylSaxCLfkte(u"ࠫ๐࠭྽"),CJlTSEpZsWb0QHg5w)
		ccnb52oKNm9ts6xyXYJBL0E = ccnb52oKNm9ts6xyXYJBL0E.replace(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ๕ࠧ྾"),CJlTSEpZsWb0QHg5w).replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭๐ࠨ྿"),CJlTSEpZsWb0QHg5w).replace(o2FdrDBimMuOw97q6QpNW8S(u"ࠧ๎ࠩ࿀"),CJlTSEpZsWb0QHg5w).replace(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨ๓ࠪ࿁"),CJlTSEpZsWb0QHg5w)
		ccnb52oKNm9ts6xyXYJBL0E = ccnb52oKNm9ts6xyXYJBL0E.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩใࠫ࿂"),CJlTSEpZsWb0QHg5w).replace(zQGaM7ctZCN(u"ࠪ࠾ࠬ࿃"),CJlTSEpZsWb0QHg5w)
		if BB7oCRfQNSYj5qDhTUevV: ccnb52oKNm9ts6xyXYJBL0E = ccnb52oKNm9ts6xyXYJBL0E.decode(Im5KSGZYBpRvdMVsbuXg).encode(Im5KSGZYBpRvdMVsbuXg)
		sOfQXGJ29bwn6l3tVz8ZoUNmDckTS4 = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠫ࠭࠷࡛࠶࠯࠼ࡡ࠰ࢂ࠲࡜࠲࠰࠷ࡢ࠱ࠩࠨ࿄"),ccnb52oKNm9ts6xyXYJBL0E,Zy2l0g8QU5vqefaTrsw.DOTALL)
		LZ5F6qv0WCtQfb2 = VJZIMkUN5siqB21Pf
		for oYinH1JWQzh6 in sOfQXGJ29bwn6l3tVz8ZoUNmDckTS4:
			if len(oYinH1JWQzh6)==VTadWjBloMwXO2CH9GDK6FR:
				LZ5F6qv0WCtQfb2 = w2qb6lf5EM
				break
		if ccnb52oKNm9ts6xyXYJBL0E in [TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡸࠧ࿅")] or LZ5F6qv0WCtQfb2 or any(value in ccnb52oKNm9ts6xyXYJBL0E for value in nEHeYNbqmzgKLMurFoIdivksJGDT6):
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤ࿆ࠬ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࠡ࡟ࠪ࿇"))
			if showDialogs: KhwN2zcb7iMkjS5E4WURxByPGon(TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"ࠨษ็ๅ๏ี๊้ࠢ็่่ฮวาࠢไๆ฼่ࠦฤ่สࠤ๊์ูห้ࠪ࿈"))
			return w2qb6lf5EM
	return VJZIMkUN5siqB21Pf
def PIUzVg8uwmHlMKO5Lk6oxAZ(*aargs,**kkwargs):
	if aargs:
		direction = aargs[ZVNvqy4iF1a9X]
		UVk75zSWxjyoCXBTqILdisHprMG81l = aargs[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		if not direction: direction = JACnOz297UuDK5HpPkc1LF(u"ࠩࡦࡩࡳࡺࡥࡳࠩ࿉")
		if not UVk75zSWxjyoCXBTqILdisHprMG81l: UVk75zSWxjyoCXBTqILdisHprMG81l = cjVhOCwybeRo7UWg92(u"ࠪหุะๅาษิࠫ࿊")
		d6dAaSgBlW = aargs[VTadWjBloMwXO2CH9GDK6FR]
		AyKma12GRYnziLV7EWIjUM = rJ9cgWz4FU.join(aargs[JACnOz297UuDK5HpPkc1LF(u"࠶ᒽ"):])
	else: direction,UVk75zSWxjyoCXBTqILdisHprMG81l,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM = CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"ࠫࡔࡑࠧ࿋"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	IUHFoP2MS7n5QBvc3ZthfdN0e(direction,CJlTSEpZsWb0QHg5w,UVk75zSWxjyoCXBTqILdisHprMG81l,CJlTSEpZsWb0QHg5w,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,**kkwargs)
	return
def qjTH2m7LxzoDERekhrBMs(*aargs,**kkwargs):
	direction = aargs[ZVNvqy4iF1a9X]
	HhsPez5G3ZgM49mYqjri6 = aargs[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	pkRNYE5vUWHnu7FSOhaf3VQrXZy = aargs[VTadWjBloMwXO2CH9GDK6FR]
	if pkRNYE5vUWHnu7FSOhaf3VQrXZy or HhsPez5G3ZgM49mYqjri6: oOEzRZ8729Nlqbi = w2qb6lf5EM
	else: oOEzRZ8729Nlqbi = VJZIMkUN5siqB21Pf
	d6dAaSgBlW = aargs[D9yBM7wPFLz]
	AyKma12GRYnziLV7EWIjUM = aargs[P3cpaLN2sH]
	if not direction: direction = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ࿌")
	if not HhsPez5G3ZgM49mYqjri6: HhsPez5G3ZgM49mYqjri6 = mi2ZJXCDzITuyev6gfn(u"࠭ใๅษࠣࠤࡓࡵࠧ࿍")
	if not pkRNYE5vUWHnu7FSOhaf3VQrXZy: pkRNYE5vUWHnu7FSOhaf3VQrXZy = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧ็฻่ࠤࠥ࡟ࡥࡴࠩ࿎")
	if len(aargs)>=zQGaM7ctZCN(u"࠻ᒿ"): AyKma12GRYnziLV7EWIjUM += rJ9cgWz4FU+aargs[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠹ᒾ")]
	if len(aargs)>=pz4WBwfyDdgk0m2aRr7SMv(u"࠽ᓀ"): AyKma12GRYnziLV7EWIjUM += rJ9cgWz4FU+aargs[rC5tnFDlQcRGA2(u"࠶ᓁ")]
	M9t6EHOwIr8cqy = IUHFoP2MS7n5QBvc3ZthfdN0e(direction,HhsPez5G3ZgM49mYqjri6,CJlTSEpZsWb0QHg5w,pkRNYE5vUWHnu7FSOhaf3VQrXZy,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,**kkwargs)
	if M9t6EHOwIr8cqy==-I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠲ᓂ") and oOEzRZ8729Nlqbi: M9t6EHOwIr8cqy = -P2Fgh6TCOWoaHjkqBcQnvRNXe
	elif M9t6EHOwIr8cqy==-P2Fgh6TCOWoaHjkqBcQnvRNXe and not oOEzRZ8729Nlqbi: M9t6EHOwIr8cqy = VJZIMkUN5siqB21Pf
	elif M9t6EHOwIr8cqy==ZVNvqy4iF1a9X: M9t6EHOwIr8cqy = VJZIMkUN5siqB21Pf
	elif M9t6EHOwIr8cqy==VTadWjBloMwXO2CH9GDK6FR: M9t6EHOwIr8cqy = w2qb6lf5EM
	return M9t6EHOwIr8cqy
def T4TK17YsEfZJ(*aargs,**kkwargs):
	return rTF8V7fLD2SXJbAURpZjQ4wH.Dialog().select(*aargs,**kkwargs)
def KhwN2zcb7iMkjS5E4WURxByPGon(*aargs,**kkwargs):
	d6dAaSgBlW = aargs[ZVNvqy4iF1a9X]
	AyKma12GRYnziLV7EWIjUM = aargs[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	yyHs5ODcq31mzJR89rxIB60teL = kkwargs[XB4CjMkPFzhAHiI3q(u"ࠨࡶ࡬ࡱࡪ࠭࿏")] if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡷ࡭ࡲ࡫ࠧ࿐") in list(kkwargs.keys()) else XB4CjMkPFzhAHiI3q(u"࠳࠳࠴࠵ᓃ")
	iA1geCMwfad = aargs[VTadWjBloMwXO2CH9GDK6FR] if len(aargs)>VTadWjBloMwXO2CH9GDK6FR and TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡸ࡮ࡳࡥࠨ࿑") not in aargs[VTadWjBloMwXO2CH9GDK6FR] else CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡶࡪ࡭ࡵ࡭ࡣࡵࠫ࿒")
	Q46gK1iwY5dUEG3a = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=TV7QSwO93IYA2oi80uWENkFXr,args=(d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,iA1geCMwfad,yyHs5ODcq31mzJR89rxIB60teL))
	Q46gK1iwY5dUEG3a.start()
	return
def TV7QSwO93IYA2oi80uWENkFXr(d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,iA1geCMwfad,yyHs5ODcq31mzJR89rxIB60teL):
	kz7UuSPB94mxdRLiAYsTjnfIaqy2 = iA1geCMwfad.replace(ZP1LyUCS3pIBu(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࠬ࿓"),CJlTSEpZsWb0QHg5w)
	name = c3mPLX9b6oqze0UCJEartIuds(w2qb6lf5EM,kz7UuSPB94mxdRLiAYsTjnfIaqy2+zQGaM7ctZCN(u"࠭ࠠ࠮ࠢࠪ࿔")+d6dAaSgBlW+o2FdrDBimMuOw97q6QpNW8S(u"ࠧࠡ࠯ࠣࠫ࿕")+AyKma12GRYnziLV7EWIjUM)
	name = vvcCMPFyJDZ48oH6lTzma0xr9edOUK(name)
	image_filename = tiFgl4DMvGEAUfjIYkHbr05.path.join(Fyf2HUjkrK1,name+yylSaxCLfkte(u"ࠨ࠰ࡳࡲ࡬࠭࿖"))
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(image_filename):
		if iA1geCMwfad==E6xdOMpqISHZCn(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡴࡨ࡫ࡺࡲࡡࡳࠩ࿗"): image_height = Olh7n0zfV4(u"࠴࠵࠼ᓄ")
		elif iA1geCMwfad==s97s2k0LJgl(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡤࡹࡹࡵࠧ࿘"): image_height = yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶࠶࠶ᓅ")
	else: image_height = sXRCiumten85HYp2xy7va1wQl(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,iA1geCMwfad,otNfFapeEnO(u"ࠫࡱ࡫ࡦࡵࠩ࿙"),VJZIMkUN5siqB21Pf,image_filename)
	NNFUJPzhHKqZv0g1LVodXIwRec5i8 = bdXCmFHx35lTsQwi6(VVvcQpCU3OM09n(u"ࠬࡊࡩࡢ࡮ࡲ࡫ࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡌࡱࡦ࡭ࡥ࠯ࡺࡰࡰࠬ࿚"),cizLW9VxEA2Nkqj7wtspB8HyT1X,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧ࿛"),zQGaM7ctZCN(u"ࠧ࠸࠴࠳ࡴࠬ࿜"))
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.show()
	if iA1geCMwfad==yylSaxCLfkte(u"ࠨࡰࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴ࡟ࡢࡷࡷࡳࠬ࿝"):
		NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠿࠰࠵࠲ᓇ")).setHeight(yylSaxCLfkte(u"࠷࠷࠵ᓆ"))
		NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠻࠳࠸࠵ᓊ")).setPosition(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠵࠶ᓈ"),-HaTI5u1f3SCxmMAkw(u"࠹࠲ᓉ"))
		NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠼࠴࠺࠶ᓋ")).setPosition(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠵࠷࠶ᓌ"),-rC5tnFDlQcRGA2(u"࠻࠶ᓍ"))
		NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(zz679V18GdcZwvrRexA0nNptY2Tab(u"࠵࠲࠳ᓐ")).setPosition(JACnOz297UuDK5HpPkc1LF(u"࠿࠰ᓎ"),-o2FdrDBimMuOw97q6QpNW8S(u"࠳࠶ᓏ"))
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(o2FdrDBimMuOw97q6QpNW8S(u"࠶࠳࠵ᓑ")).setVisible(VJZIMkUN5siqB21Pf)
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(cbmeD4WNZfAowxT2JdUMtV(u"࠷࠴࠷ᓒ")).setVisible(VJZIMkUN5siqB21Pf)
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠽࠵࠻࠰ᓓ")).setImage(image_filename)
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠾࠶࠵࠱ᓔ")).setHeight(image_height)
	L8Wkv5KCSoq.sleep(yyHs5ODcq31mzJR89rxIB60teL//KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷࠰࠱࠲࠱࠴ᓕ"))
	return
def Jg3XRQ2Tsp1ryEAc4o9BiznbftaIFC(*aargs,**kkwargs):
	d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,profile,direction = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ࿞"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡰࡪ࡬ࡴࠨ࿟")
	if len(aargs)>=P2Fgh6TCOWoaHjkqBcQnvRNXe: d6dAaSgBlW = aargs[ZVNvqy4iF1a9X]
	if len(aargs)>=VTadWjBloMwXO2CH9GDK6FR: AyKma12GRYnziLV7EWIjUM = aargs[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	if len(aargs)>=D9yBM7wPFLz: profile = aargs[VTadWjBloMwXO2CH9GDK6FR]
	if len(aargs)>=P3cpaLN2sH: direction = aargs[D9yBM7wPFLz]
	return hQbEaPTN5tnZfArRuWDcY(direction,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,profile)
def EnPV0eZMSNT7ayA2LfFY(*aargs,**kkwargs):
	return rTF8V7fLD2SXJbAURpZjQ4wH.Dialog().contextmenu(*aargs,**kkwargs)
def pnbR791s62ld8e(*aargs,**kkwargs):
	return rTF8V7fLD2SXJbAURpZjQ4wH.Dialog().browseSingle(*aargs,**kkwargs)
def yHg4QIFOx06mfGocDN9REX7(*aargs,**kkwargs):
	return rTF8V7fLD2SXJbAURpZjQ4wH.Dialog().input(*aargs,**kkwargs)
def lkPKsYmp4UjR(*aargs,**kkwargs):
	return rTF8V7fLD2SXJbAURpZjQ4wH.DialogProgress(*aargs,**kkwargs)
def IUHFoP2MS7n5QBvc3ZthfdN0e(direction,button0=CJlTSEpZsWb0QHg5w,button1=CJlTSEpZsWb0QHg5w,button2=CJlTSEpZsWb0QHg5w,d6dAaSgBlW=CJlTSEpZsWb0QHg5w,AyKma12GRYnziLV7EWIjUM=CJlTSEpZsWb0QHg5w,profile=h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡨࡩࡨࡨࡲࡲࡹ࠭࿠"),dhHRNTA5rgwyos7L1OV3M9BQm8U0t=ZVNvqy4iF1a9X,PCJE8zuHprfyWMU7x0doKj6cmG=ZVNvqy4iF1a9X):
	if not direction: direction = cjVhOCwybeRo7UWg92(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ࿡")
	NNFUJPzhHKqZv0g1LVodXIwRec5i8 = bVxDucoEdAsq7YfZLCRMe3m5nyW(otNfFapeEnO(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨ࿢"),cizLW9VxEA2Nkqj7wtspB8HyT1X,Olh7n0zfV4(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ࿣"),EcjO3giln2kQTdBY0XLAG(u"ࠨ࠹࠵࠴ࡵ࠭࿤"))
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.vP57fmg8nMAoN4XLz(button0,button1,button2,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,profile,direction,dhHRNTA5rgwyos7L1OV3M9BQm8U0t,PCJE8zuHprfyWMU7x0doKj6cmG)
	if dhHRNTA5rgwyos7L1OV3M9BQm8U0t>ZVNvqy4iF1a9X: NNFUJPzhHKqZv0g1LVodXIwRec5i8.I9WQZn1x0Hlhd()
	if PCJE8zuHprfyWMU7x0doKj6cmG>ZVNvqy4iF1a9X: NNFUJPzhHKqZv0g1LVodXIwRec5i8.B4L8Tw1fcs0SACMEQIo5t()
	if dhHRNTA5rgwyos7L1OV3M9BQm8U0t==ZVNvqy4iF1a9X and PCJE8zuHprfyWMU7x0doKj6cmG==ZVNvqy4iF1a9X: NNFUJPzhHKqZv0g1LVodXIwRec5i8.ccTEyDs9HGBo1()
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.doModal()
	M9t6EHOwIr8cqy = NNFUJPzhHKqZv0g1LVodXIwRec5i8.choiceID
	return M9t6EHOwIr8cqy
def hQbEaPTN5tnZfArRuWDcY(direction,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,profile=od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ࿥")):
	if not direction: direction = VVvcQpCU3OM09n(u"ࠪࡰࡪ࡬ࡴࠨ࿦")
	NNFUJPzhHKqZv0g1LVodXIwRec5i8 = bdXCmFHx35lTsQwi6(cjVhOCwybeRo7UWg92(u"ࠫࡉ࡯ࡡ࡭ࡱࡪࡘࡪࡾࡴࡗ࡫ࡨࡻࡪࡸࡆࡶ࡮࡯ࡗࡨࡸࡥࡦࡰ࠱ࡼࡲࡲࠧ࿧"),cizLW9VxEA2Nkqj7wtspB8HyT1X,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭࿨"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭࠷࠳࠲ࡳࠫ࿩"))
	image_filename = AY8sKeZnH0TlO5IJFWquizE4Sda.replace(cjVhOCwybeRo7UWg92(u"ࠧࡠ࠲࠳࠴࠵ࡥࠧ࿪"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡡࠪ࿫")+str(L8Wkv5KCSoq.time())+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡢࠫ࿬"))
	image_filename = image_filename.replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡠࡡ࠭࿭"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡡࡢ࡜࡝ࠩ࿮")).replace(cbmeD4WNZfAowxT2JdUMtV(u"ࠬ࠵࠯ࠨ࿯"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭࠯࠰࠱࠲ࠫ࿰"))
	image_height = sXRCiumten85HYp2xy7va1wQl(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,d6dAaSgBlW,AyKma12GRYnziLV7EWIjUM,profile,direction,VJZIMkUN5siqB21Pf,image_filename)
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.show()
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(TDpFsQXHze2q30uYtGPfEIm8(u"࠹࠱࠷࠳ᓖ")).setHeight(image_height)
	NNFUJPzhHKqZv0g1LVodXIwRec5i8.getControl(mi2ZJXCDzITuyev6gfn(u"࠺࠲࠸࠴ᓗ")).setImage(image_filename)
	GUD0pzT9ZBSHYqIFR5vbus62gJ = NNFUJPzhHKqZv0g1LVodXIwRec5i8.doModal()
	try: tiFgl4DMvGEAUfjIYkHbr05.remove(image_filename)
	except: pass
	return GUD0pzT9ZBSHYqIFR5vbus62gJ
def jQW9RpucaCLHX0sSBD6lrif58e47nt(Jm17afY3KOP5WtkVqRn9iuj=w2qb6lf5EM):
	if Jm17afY3KOP5WtkVqRn9iuj:
		ww0cfi2ZxQvg7k3N1uLRhtFdH = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,VVvcQpCU3OM09n(u"ࠧࡴࡶࡵࠫ࿱"),yylSaxCLfkte(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࡣ࠶࠭࿲"),Olh7n0zfV4(u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘࠬ࿳"))
		if ww0cfi2ZxQvg7k3N1uLRhtFdH: return ww0cfi2ZxQvg7k3N1uLRhtFdH
	AyKma12GRYnziLV7EWIjUM = CJlTSEpZsWb0QHg5w
	if ZVNvqy4iF1a9X and cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
		InaYgGyu8qjsp1lOAbe4rKWVz = z4YnlxGHF2AMtrw.count(ZP1LyUCS3pIBu(u"ࠪࡑࡴࢀࡩ࡭࡮ࡤࠫ࿴"))
		if InaYgGyu8qjsp1lOAbe4rKWVz>o2FdrDBimMuOw97q6QpNW8S(u"࠺࠳ᓘ"):
			AyKma12GRYnziLV7EWIjUM = Zy2l0g8QU5vqefaTrsw.findall(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫ࡬࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡩࡴࡶ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭࿵"),z4YnlxGHF2AMtrw,Zy2l0g8QU5vqefaTrsw.DOTALL)
			AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM[ZVNvqy4iF1a9X]
	if not AyKma12GRYnziLV7EWIjUM:
		MRsbcA0FK65ZQpqjrtWkd9Tya = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,ZP1LyUCS3pIBu(u"ࠬࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ࿶"),HaTI5u1f3SCxmMAkw(u"࠭ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࡵ࠱ࡸࡽࡺࠧ࿷"))
		AyKma12GRYnziLV7EWIjUM = open(MRsbcA0FK65ZQpqjrtWkd9Tya,s97s2k0LJgl(u"ࠧࡳࡤࠪ࿸")).read()
		if A7Z6OVh20eCEUx: AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.decode(Im5KSGZYBpRvdMVsbuXg)
		AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)
	YvJSNT3ieGa0j54qVwMkd = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠨࠪࡐࡳࡿ࡯࡬࡭ࡣ࠱࠮ࡄ࠯࡜࡯ࠩ࿹"),AyKma12GRYnziLV7EWIjUM,Zy2l0g8QU5vqefaTrsw.DOTALL)
	RkQJXueHvyUAZLSV38Iatib1 = []
	for Oo8Hc9Xel1CFtv in YvJSNT3ieGa0j54qVwMkd:
		ptDcdLnmOMkjgHNR9hlBXTfV = Oo8Hc9Xel1CFtv.lower()
		if yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡤࡲࡩࡸ࡯ࡪࡦࠪ࿺") in ptDcdLnmOMkjgHNR9hlBXTfV: continue
		if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡹࡧࡻ࡮ࡵࡷࠪ࿻") in ptDcdLnmOMkjgHNR9hlBXTfV: continue
		if zQGaM7ctZCN(u"ࠫ࡮ࡶࡨࡰࡰࡨࠫ࿼") in ptDcdLnmOMkjgHNR9hlBXTfV: continue
		if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡩࡲࡰࡵࠪ࿽") in ptDcdLnmOMkjgHNR9hlBXTfV: continue
		RkQJXueHvyUAZLSV38Iatib1.append(Oo8Hc9Xel1CFtv)
	ww0cfi2ZxQvg7k3N1uLRhtFdH = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(RkQJXueHvyUAZLSV38Iatib1,P2Fgh6TCOWoaHjkqBcQnvRNXe)
	ww0cfi2ZxQvg7k3N1uLRhtFdH = ww0cfi2ZxQvg7k3N1uLRhtFdH[ZVNvqy4iF1a9X]
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,E6xdOMpqISHZCn(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫ࿾"),cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖࠪ࿿"),ww0cfi2ZxQvg7k3N1uLRhtFdH,DRmUs7l1O4xLeZYzGITXk)
	return ww0cfi2ZxQvg7k3N1uLRhtFdH
def nAtVz16YSq0Jf(uErMFcVGBXUvtJZ90zCTPxn2YW=CJlTSEpZsWb0QHg5w):
	if Ew2zQ8u7Ss.ALLOW_SHOWDIALOGS_FIX==VJZIMkUN5siqB21Pf: return
	if not uErMFcVGBXUvtJZ90zCTPxn2YW: uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
	if zQGaM7ctZCN(u"ࠨࡕࡼࡷࡹ࡫࡭ࡆࡺ࡬ࡸࠬက") in uErMFcVGBXUvtJZ90zCTPxn2YW or CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡢࡣࡤࡌࡏࡓࡅࡈࡣࡊ࡞ࡉࡕࡡࡢࡣࠬခ") in uErMFcVGBXUvtJZ90zCTPxn2YW: return
	if uErMFcVGBXUvtJZ90zCTPxn2YW!=otNfFapeEnO(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭ဂ"): A8v6c2fL7egwWCF3YBqr4kXSRn.stderr.write(uErMFcVGBXUvtJZ90zCTPxn2YW)
	xWMpqasJ9BD = uErMFcVGBXUvtJZ90zCTPxn2YW.splitlines()
	iy7BbWH2lmuDT1FrXaLJCq8 = xWMpqasJ9BD[-mi2ZJXCDzITuyev6gfn(u"࠴ᓙ")]
	PtKnsOdyoNVM4B = open(khYtrEzRsjxXW49NwMI,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡷࡨࠧဃ")).read()
	if A7Z6OVh20eCEUx: PtKnsOdyoNVM4B = PtKnsOdyoNVM4B.decode(Im5KSGZYBpRvdMVsbuXg)
	PtKnsOdyoNVM4B = PtKnsOdyoNVM4B[-rC5tnFDlQcRGA2(u"࠼࠵࠶࠰ᓚ"):]
	tSkGin1CgWMfv5d8aXsoHl = HaTI5u1f3SCxmMAkw(u"ࠬࡃࠧင")*O4F8UC5lMAS6ghETm1VoPDI(u"࠶࠶࠰ᓛ")
	if tSkGin1CgWMfv5d8aXsoHl in PtKnsOdyoNVM4B: PtKnsOdyoNVM4B = PtKnsOdyoNVM4B.rsplit(tSkGin1CgWMfv5d8aXsoHl,P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	if iy7BbWH2lmuDT1FrXaLJCq8 in PtKnsOdyoNVM4B: PtKnsOdyoNVM4B = PtKnsOdyoNVM4B.rsplit(iy7BbWH2lmuDT1FrXaLJCq8,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
	Jmv5rj3SbqETVd = Zy2l0g8QU5vqefaTrsw.findall(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࠨࡔࡱࡸࡶࡨ࡫ࡼࡎࡱࡧࡩ࠮ࡀࠠ࡝࡝ࠣࠬ࠳࠰࠿ࠪࠢ࡟ࡡࠬစ"),PtKnsOdyoNVM4B,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for e8ehcspxHd6KzW0CVYvQBq4OtSAg,nqVYufmd4GFshQeHO9vp05 in reversed(Jmv5rj3SbqETVd):
		if nqVYufmd4GFshQeHO9vp05: break
	else: nqVYufmd4GFshQeHO9vp05 = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡏࡑࡗࠤࡘࡖࡅࡄࡋࡉࡍࡊࡊࠧဆ")
	gdGX631yzBwMoYjUpqNt,Oo8Hc9Xel1CFtv,SWRyFq7kbgYN4JH9QmoDOEPsv8axU = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	iimvBpcfIYto7DP36wVdT2ErR1 = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡝ࡕࡘࡑࡣࠧဇ")+Ym6q5M4TocDaA013RjFQ+pz4WBwfyDdgk0m2aRr7SMv(u"ࠩส่ำ฽ร࠻ࠢࠣࠫဈ")+oOQaRxBXyJ5jVnZ+iy7BbWH2lmuDT1FrXaLJCq8
	BCMyfgK4GD2hiWlowzHLs5dj = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩဉ")+Ym6q5M4TocDaA013RjFQ+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫฬ๊ๅึัิ࠾ࠥࠦࠧည")+oOQaRxBXyJ5jVnZ+nqVYufmd4GFshQeHO9vp05
	for pj0yXcdPqb7hVHeI89TY2RW6r4m3 in reversed(xWMpqasJ9BD):
		if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡌࡩ࡭ࡧࠣࠦࠬဋ") in pj0yXcdPqb7hVHeI89TY2RW6r4m3 and O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬဌ") in pj0yXcdPqb7hVHeI89TY2RW6r4m3: break
	pj0yXcdPqb7hVHeI89TY2RW6r4m3 = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡇ࡫࡯ࡩࠥࠨࠨ࠯ࠬࡂ࠭ࠧࡢࠬࠡ࡮࡬ࡲࡪࠦࠨ࠯ࠬࡂ࠭ࡡ࠲ࠠࡪࡰࠣࠬ࠳࠰࠿ࠪࠦࠪဍ"),pj0yXcdPqb7hVHeI89TY2RW6r4m3,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if pj0yXcdPqb7hVHeI89TY2RW6r4m3:
		gdGX631yzBwMoYjUpqNt,Oo8Hc9Xel1CFtv,SWRyFq7kbgYN4JH9QmoDOEPsv8axU = pj0yXcdPqb7hVHeI89TY2RW6r4m3[ZVNvqy4iF1a9X]
		if mi2ZJXCDzITuyev6gfn(u"ࠨ࠱ࠪဎ") in gdGX631yzBwMoYjUpqNt: gdGX631yzBwMoYjUpqNt = gdGX631yzBwMoYjUpqNt.rsplit(yylSaxCLfkte(u"ࠩ࠲ࠫဏ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		else: gdGX631yzBwMoYjUpqNt = gdGX631yzBwMoYjUpqNt.rsplit(zQGaM7ctZCN(u"ࠪࡠࡡ࠭တ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		q4B3CSnoJHkO = JACnOz297UuDK5HpPkc1LF(u"ࠫࡠࡘࡔࡍ࡟ࠪထ")+Ym6q5M4TocDaA013RjFQ+s97s2k0LJgl(u"ࠬอไๆๆไ࠾ࠥࠦࠧဒ")+oOQaRxBXyJ5jVnZ+gdGX631yzBwMoYjUpqNt
		wjAMDO6VSq = JACnOz297UuDK5HpPkc1LF(u"࡛࠭ࡓࡖࡏࡡࠬဓ")+Ym6q5M4TocDaA013RjFQ+mi2ZJXCDzITuyev6gfn(u"ࠧศๆึ฻ึࡀࠠࠡࠩန")+oOQaRxBXyJ5jVnZ+Oo8Hc9Xel1CFtv
		KDmMHeSAucoW = cjVhOCwybeRo7UWg92(u"ࠨ࡝ࡕࡘࡑࡣࠧပ")+Ym6q5M4TocDaA013RjFQ+rC5tnFDlQcRGA2(u"ࠩส่๊้ว็࠼ࠣࠤࠬဖ")+oOQaRxBXyJ5jVnZ+SWRyFq7kbgYN4JH9QmoDOEPsv8axU
		CCrLdwQHu6tjyTi5ZKaM1Up = q4B3CSnoJHkO+rJ9cgWz4FU+wjAMDO6VSq+rJ9cgWz4FU+KDmMHeSAucoW+rJ9cgWz4FU+BCMyfgK4GD2hiWlowzHLs5dj+rJ9cgWz4FU+iimvBpcfIYto7DP36wVdT2ErR1
		fxcFIg3be2p6LDGJA8kHVE = wjAMDO6VSq+rJ9cgWz4FU+BCMyfgK4GD2hiWlowzHLs5dj+rJ9cgWz4FU+iimvBpcfIYto7DP36wVdT2ErR1+rJ9cgWz4FU+q4B3CSnoJHkO+rJ9cgWz4FU+KDmMHeSAucoW
		rcThStkM5Ia9Cs83BAGp1Oyg = wjAMDO6VSq+rJ9cgWz4FU+iimvBpcfIYto7DP36wVdT2ErR1+rJ9cgWz4FU+q4B3CSnoJHkO+rJ9cgWz4FU+KDmMHeSAucoW
	else:
		q4B3CSnoJHkO,wjAMDO6VSq,KDmMHeSAucoW = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		CCrLdwQHu6tjyTi5ZKaM1Up = BCMyfgK4GD2hiWlowzHLs5dj+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡠࡳࡢ࡮ࠨဗ")+iimvBpcfIYto7DP36wVdT2ErR1
		fxcFIg3be2p6LDGJA8kHVE = BCMyfgK4GD2hiWlowzHLs5dj+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡡࡴ࡜࡯ࠩဘ")+iimvBpcfIYto7DP36wVdT2ErR1
		rcThStkM5Ia9Cs83BAGp1Oyg = iimvBpcfIYto7DP36wVdT2ErR1
	OGtLzwJRmHaKj = EcjO3giln2kQTdBY0XLAG(u"ࠬำฯฬࠢั฻ศฺ๋ࠦำ้ࠣ็฻่ะࠩမ")+rJ9cgWz4FU
	f2Gc8gFzA3DEIV0e = N5lYSE3q9CkFvwz()
	iJxpWcoCw7gOIZ4XAT8 = []
	SD0TxMRXiep4cjPBsnzI = f2Gc8gFzA3DEIV0e[HaTI5u1f3SCxmMAkw(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫယ")]
	JzGhDCxO6cd = Gb6AoxXFzh7L2SvVyZpWMuC5etNar(Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a)
	if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬရ") in list(f2Gc8gFzA3DEIV0e.keys()):
		for LxrQ9fbltZaD8k7,F0KTgvtED5pla,Q7QO2cVT5z in SD0TxMRXiep4cjPBsnzI:
			iJxpWcoCw7gOIZ4XAT8 = max(iJxpWcoCw7gOIZ4XAT8,F0KTgvtED5pla)
		if JzGhDCxO6cd<iJxpWcoCw7gOIZ4XAT8:
			d6dAaSgBlW = cbmeD4WNZfAowxT2JdUMtV(u"ࠨไ่ࠤอะอะ์ฮࠤฬ๊ศา่ส้ัࠦโษๆࠣษึูวๅࠢส่ศิืศร่้๋ࠣศา็ฯࠫလ")
			M9t6EHOwIr8cqy = IUHFoP2MS7n5QBvc3ZthfdN0e(zQGaM7ctZCN(u"ࠩࡵ࡭࡬࡮ࡴࠨဝ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊าࠧသ"),ZP1LyUCS3pIBu(u"ࠫฯำฯ๋อࠪဟ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬิั้ฮࠪဠ"),OGtLzwJRmHaKj+d6dAaSgBlW,CCrLdwQHu6tjyTi5ZKaM1Up)
			if M9t6EHOwIr8cqy==P2Fgh6TCOWoaHjkqBcQnvRNXe:
				import tAoP1fdO67
				tAoP1fdO67.DkcrxeMRug629ZVS7FUdNlQ(w2qb6lf5EM)
				JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
			elif M9t6EHOwIr8cqy==VTadWjBloMwXO2CH9GDK6FR: JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	P1PavCzYN3KyIr9RVBoel8kmEOGfM0 = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,HaTI5u1f3SCxmMAkw(u"࠭࡬ࡪࡵࡷࠫအ"),GISOTJh20W(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪဢ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡃࡏࡐࡤ࡙ࡅࡏࡖࡢࡉࡗࡘࡏࡓࡕࠪဣ"))
	if not P1PavCzYN3KyIr9RVBoel8kmEOGfM0: P1PavCzYN3KyIr9RVBoel8kmEOGfM0 = []
	fxcFIg3be2p6LDGJA8kHVE = fxcFIg3be2p6LDGJA8kHVE.replace(rJ9cgWz4FU,ZP1LyUCS3pIBu(u"ࠩ࡟ࡠࡳ࠭ဤ")).replace(s97s2k0LJgl(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩဥ"),CJlTSEpZsWb0QHg5w).replace(Ym6q5M4TocDaA013RjFQ,CJlTSEpZsWb0QHg5w).replace(oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w)
	rcThStkM5Ia9Cs83BAGp1Oyg = rcThStkM5Ia9Cs83BAGp1Oyg.replace(rJ9cgWz4FU,s97s2k0LJgl(u"ࠫࡡࡢ࡮ࠨဦ")).replace(XB4CjMkPFzhAHiI3q(u"ࠬࡡࡒࡕࡎࡠࠫဧ"),CJlTSEpZsWb0QHg5w).replace(Ym6q5M4TocDaA013RjFQ,CJlTSEpZsWb0QHg5w).replace(oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w)
	IAEs9MqVwgQKyGm2LFZHdSoOc = Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭࠺࠻ࠩဨ")+rcThStkM5Ia9Cs83BAGp1Oyg
	if IAEs9MqVwgQKyGm2LFZHdSoOc in P1PavCzYN3KyIr9RVBoel8kmEOGfM0:
		d6dAaSgBlW = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧๅไาࠤ็๋สࠡษ้ฮูࠥวษไสࠤอหัิษ็ࠤ์ึวࠡษ็า฼ษࠠฦๆ์ࠤฬ๊ๅษำ่ะࠬဩ")
		PIUzVg8uwmHlMKO5Lk6oxAZ(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡴ࡬࡫࡭ࡺࠧဪ"),CJlTSEpZsWb0QHg5w,OGtLzwJRmHaKj+d6dAaSgBlW,CCrLdwQHu6tjyTi5ZKaM1Up)
		return
	hbF8WCQ0eS7TyOkE6zom23 = str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX).split(XB4CjMkPFzhAHiI3q(u"ࠩ࠱ࠫါ"))[ZVNvqy4iF1a9X]
	otaunYGVIJ2jX8HsKm7ecR0bAh4 = Ew2zQ8u7Ss.SITESURLS[E6xdOMpqISHZCn(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪာ")][xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠼ᓜ")]
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,Olh7n0zfV4(u"ࠫࡕࡕࡓࡕࠩိ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡉࡑ࡚ࡣࡊ࡞ࡉࡕࡡࡈࡖࡗࡕࡒࡔ࠯࠴ࡷࡹ࠭ီ"),VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
	TcV0SlgC8Z3ymxN4qp = Zy2l0g8QU5vqefaTrsw.findall(cjVhOCwybeRo7UWg92(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯࠿ࡀࠨ࠯ࠬࡂ࠭ࡠࡢࡲ࡝ࡰࡠ࠯ࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ု"),z4YnlxGHF2AMtrw,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for KPyIDuvmOxcRj1VS7Z,bigYQLZ47MGdcI8VKpW20w9rF,BB9SEbnPJAQReUu8ox06wGh,e6fVmTntEKb in TcV0SlgC8Z3ymxN4qp:
		KPyIDuvmOxcRj1VS7Z = KPyIDuvmOxcRj1VS7Z.split(mi2ZJXCDzITuyev6gfn(u"ࠧࠬࠩူ"))
		BB9SEbnPJAQReUu8ox06wGh = BB9SEbnPJAQReUu8ox06wGh.split(o2FdrDBimMuOw97q6QpNW8S(u"ࠨ࠭ࠪေ"))
		e6fVmTntEKb = e6fVmTntEKb.split(rC5tnFDlQcRGA2(u"ࠩ࠮ࠫဲ"))
		if Oo8Hc9Xel1CFtv in KPyIDuvmOxcRj1VS7Z and iy7BbWH2lmuDT1FrXaLJCq8==bigYQLZ47MGdcI8VKpW20w9rF and Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a in BB9SEbnPJAQReUu8ox06wGh and hbF8WCQ0eS7TyOkE6zom23 in e6fVmTntEKb:
			d6dAaSgBlW = HaTI5u1f3SCxmMAkw(u"๋ࠪีอࠠศๆั฻ศࠦๅฺำ๋ๅࠥ๎ำ๋฻ส่ัࠦศศๆศูิอัࠡษ็ๆฬีๅࠨဳ")
			Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(yylSaxCLfkte(u"ࠫࡷ࡯ࡧࡩࡶࠪဴ"),VVvcQpCU3OM09n(u"ࠬิั้ฮࠪဵ"),HaTI5u1f3SCxmMAkw(u"࠭ลาีส่ࠥหไ๊ࠢส่๊ฮัๆฮࠪံ"),OGtLzwJRmHaKj+d6dAaSgBlW,CCrLdwQHu6tjyTi5ZKaM1Up)
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe: PIUzVg8uwmHlMKO5Lk6oxAZ(zQGaM7ctZCN(u"ࠧࡤࡧࡱࡸࡪࡸ့ࠧ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,d6dAaSgBlW)
			return
	d6dAaSgBlW = yylSaxCLfkte(u"ࠨษ็ีัอมࠡวิืฬ๊่ࠠาสࠤฬ๊ฮุลࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨး")
	XpKwSsuCaOtJ0HLV8D = IUHFoP2MS7n5QBvc3ZthfdN0e(cjVhOCwybeRo7UWg92(u"ࠩࡵ࡭࡬࡮ࡴࠨ္"),cjVhOCwybeRo7UWg92(u"ࠪษึูวๅࠢศ่๎ࠦวๅ็หี๊า်ࠧ"),HaTI5u1f3SCxmMAkw(u"ࠫฯำฯ๋อࠣะืฬ๊ࠨျ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬะอะ์ฮࠤฬ๊ศา่ส้ั࠭ြ"),OGtLzwJRmHaKj+d6dAaSgBlW,CCrLdwQHu6tjyTi5ZKaM1Up)
	if XpKwSsuCaOtJ0HLV8D==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		hxg3VwrTRoJpdMHt7Aj92WcZy1(VJZIMkUN5siqB21Pf)
		KhwN2zcb7iMkjS5E4WURxByPGon(zQGaM7ctZCN(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣห้ะอะ์ฮࠤฬ๊ฬำศํࠫွ"),cbmeD4WNZfAowxT2JdUMtV(u"ࠧ๎ࡕࡸࡧࡨ࡫ࡳࡴࠩှ"),L8Wkv5KCSoq=o2FdrDBimMuOw97q6QpNW8S(u"࠷࠶࠲ᓝ"))
		JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	elif XpKwSsuCaOtJ0HLV8D==VTadWjBloMwXO2CH9GDK6FR:
		import tAoP1fdO67
		tAoP1fdO67.DkcrxeMRug629ZVS7FUdNlQ(w2qb6lf5EM)
		JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(otNfFapeEnO(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨဿ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,o2FdrDBimMuOw97q6QpNW8S(u"ࠩึ์ๆ๊ࠦห็ࠣษึูวๅࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤส๊้ࠡษ็้อืๅอࠢ็็๏ฺ๊ࠦำไࠤฬ๊ๅษำ่ะࠥษ๊็๋้ࠢฯ๏้ࠠๅํๅࠥ๎ไๆษำหࠥำีๅฬ๋ࠣีํࠠศๆุ่่๊ษࠡๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣหฺ๊วฮุ่่๊ࠢษ๊๊ࠡ์๊ࠥวࠡ์฼ีๆࠦใ๋ใࠣ฼์ืส๊ࠡ็้ฬึวฺ๊ࠡีฯ่ࠦๆฬ์ࠤ฽ํัห๊ࠢิ์ࠦวๅ็ื็้ฯࠠ࠯๊่ࠢࠥะั๋ัࠣวึูวๅࠢสุ่าไࠡมࠪ၀"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe: DVS31tWLTsGkuM68dqyrIPpgxBw = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭၁")
	else:
		PIUzVg8uwmHlMKO5Lk6oxAZ(VVvcQpCU3OM09n(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ၂"),CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Ym6q5M4TocDaA013RjFQ+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬะๅࠡว็฾ฬวࠠฦำึห้ࠦวๅะฺวࠬ၃")+oOQaRxBXyJ5jVnZ+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࡜࡯ๆฦ๊ࠥอไๆสิ้ัࠦไศࠢํ฽้๋ࠠศๆ฽๎อ่ࠦๅษࠣ๎ุะื๋฻ࠣษฺ๊วฮࠢส่ำ฽รࠡสา์๋ࠦำอๆࠣห้ษฮุษฤࠤฬ๊ะ๋่ࠢ็ฯ๎ศࠡใํ๋ࠥาๅ๋฻ࠣฮๆอี๋ๆ๋ࠣีอࠠศๆั฻ศ่ࠦ฻์ิ๋๋ࠥๆࠡษ็วำ฽วยࠩ၄"))
		return
	sBbvqgYCaSP50 = fxcFIg3be2p6LDGJA8kHVE
	import tAoP1fdO67
	cn0XyId7MkTCE1RifFhwQDN = tAoP1fdO67.nD9fpAQ50YatjGr(EcjO3giln2kQTdBY0XLAG(u"ࠧࡆࡴࡵࡳࡷࡹࠧ၅"),sBbvqgYCaSP50,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡙ࡈࡐ࡙ࡢࡉ࡝ࡏࡔࡠࡇࡕࡖࡔࡘࡓࠨ၆"),DVS31tWLTsGkuM68dqyrIPpgxBw)
	if cn0XyId7MkTCE1RifFhwQDN and DVS31tWLTsGkuM68dqyrIPpgxBw:
		P1PavCzYN3KyIr9RVBoel8kmEOGfM0.append(IAEs9MqVwgQKyGm2LFZHdSoOc)
		JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬ၇"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡅࡑࡒ࡟ࡔࡇࡑࡘࡤࡋࡒࡓࡑࡕࡗࠬ၈"),P1PavCzYN3KyIr9RVBoel8kmEOGfM0,XlNnqz758Zeuo)
	return
def hybGnOWlQ0F7xNTz1c5(qPWgu3zkRbrv74yho,filename=gZvlfk6xhACbXcD5j0KBLiVM1):
	L8Wkv5KCSoq.sleep(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠱࠰࠳࠶࠺ᓞ"))
	if A7Z6OVh20eCEUx: qPWgu3zkRbrv74yho = qPWgu3zkRbrv74yho.encode(Im5KSGZYBpRvdMVsbuXg)
	if not filename: N4jmWQledskOFctof = EcjO3giln2kQTdBY0XLAG(u"ࠫࡸࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦࡢࠫ၉")+str(L8Wkv5KCSoq.time())+GISOTJh20W(u"ࠬ࠴ࡤࡢࡶࠪ၊")
	else: N4jmWQledskOFctof = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡳ࠻࡞࡟࠴࠵࠶࠰ࡦ࡯ࡤࡨࡤ࠭။")+filename+ZP1LyUCS3pIBu(u"ࠧ࠯ࡦࡤࡸࠬ၌")
	open(N4jmWQledskOFctof,KA26GucUHOwXL(u"ࠨࡹࡥࠫ၍")).write(qPWgu3zkRbrv74yho)
	return
def RRltAnXSQPJ2Nki5FeMqs(TpGRx3umFIEKey1i0XNz8CnJ):
	if TpGRx3umFIEKey1i0XNz8CnJ:
		NUFLafsK3eo = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,HaTI5u1f3SCxmMAkw(u"ࠩ࡯࡭ࡸࡺࠧ၎"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ၏"),XB4CjMkPFzhAHiI3q(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧၐ"))
		if NUFLafsK3eo: return NUFLafsK3eo
	otaunYGVIJ2jX8HsKm7ecR0bAh4 = Ew2zQ8u7Ss.SITESURLS[Olh7n0zfV4(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬၑ")][EcjO3giln2kQTdBY0XLAG(u"࠷ᓟ")]
	kznWKAPj2eN = qqwenxatQlYJLD(VJZIMkUN5siqB21Pf) if not TpGRx3umFIEKey1i0XNz8CnJ else Ew2zQ8u7Ss.AV_CLIENT_IDS
	BLjoYe9GRiaWgluTk36p = Kmr20L5RiED9nOu1AGNa7WQUSle6()
	F087kSJl1WXD93VmP2gvUQtEKiAIL = BLjoYe9GRiaWgluTk36p.split(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࠬࠨၒ"))[VTadWjBloMwXO2CH9GDK6FR]
	eA6xXb1QGDif = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ၓ"))
	RNVQf1xjTKka = lchsgL4CQNIGP1XOzDF()
	cl6ybZFW7O0 = {CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡷࡶࡩࡷ࠭ၔ"):kznWKAPj2eN,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪၕ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,yylSaxCLfkte(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫၖ"):F087kSJl1WXD93VmP2gvUQtEKiAIL,Olh7n0zfV4(u"ࠫ࡮ࡪࡳࠨၗ"):U2SFOzhqClfsiu36P1j0YGrcx7d(RNVQf1xjTKka)}
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡖࡏࡔࡖࠪၘ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,cl6ybZFW7O0,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙࠭࠲ࡵࡷࠫၙ"))
	NUFLafsK3eo = []
	if cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
		NUFLafsK3eo = z4YnlxGHF2AMtrw.replace(VVvcQpCU3OM09n(u"ࠧ࡝࡞ࡵࠫၚ"),rJ9cgWz4FU).replace(E6xdOMpqISHZCn(u"ࠨ࡞࡟ࡲࠬၛ"),rJ9cgWz4FU).replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࡟ࡶࡡࡴࠧၜ"),rJ9cgWz4FU).replace(rScptJWVdgzQGR1E3LZ9byC,rJ9cgWz4FU)
		NUFLafsK3eo = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"ࠪࡗ࡙ࡇࡒࡕ࠼࠽ࡗ࡙ࡇࡒࡕ࠼࠽ࠬࡡࡪࠫࠪ࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮࠻࠼ࠫ࠲࠯ࡅࠩ࡝ࡰ࠽࠾࠭࠴ࠪࡀࠫ࡟ࡲࡊࡔࡄ࠻࠼ࡈࡒࡉ࠭ၝ"),NUFLafsK3eo,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if NUFLafsK3eo:
			NUFLafsK3eo = sorted(NUFLafsK3eo,reverse=VJZIMkUN5siqB21Pf,key=lambda key: int(key[ZVNvqy4iF1a9X]))
			dq7AOIkC9r0,kznWKAPj2eN,h417jESXsCIZJenFNlf0ybo2dr5xAL,B5B97KCQSDNcVWJb8RjxvL,wRUixloKXmj7IPpY4AcO21Q6Hygu,j6h5EvtgIqUrYcKwl91p7RCJm4i = NUFLafsK3eo[ZVNvqy4iF1a9X]
			PqJucMohK5B1SYkA8rsWw = j6h5EvtgIqUrYcKwl91p7RCJm4i if Ew2zQ8u7Ss.avprivslongperiod else h417jESXsCIZJenFNlf0ybo2dr5xAL
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(cjVhOCwybeRo7UWg92(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ၞ"),PqJucMohK5B1SYkA8rsWw)
			JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,cjVhOCwybeRo7UWg92(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠳ࠪၟ"),JACnOz297UuDK5HpPkc1LF(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩၠ"),NUFLafsK3eo,DRmUs7l1O4xLeZYzGITXk)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩၡ"),U2SFOzhqClfsiu36P1j0YGrcx7d(U6YgVKS9rAmwe1RTPlQnfiGs))
	return NUFLafsK3eo
def VESnzP5TLHsytv8irkf0maMg(LL2H35jbrMlkIOR7C,V4vyPzhxEBmaldr=ZVNvqy4iF1a9X,vCpQGynNmWorxjIdPzBE=ZVNvqy4iF1a9X):
	if V4vyPzhxEBmaldr and not vCpQGynNmWorxjIdPzBE: vCpQGynNmWorxjIdPzBE = len(LL2H35jbrMlkIOR7C)//V4vyPzhxEBmaldr
	yOkRiY4gxGq,LxNV5lenkhW6zoBJDMA7ZuqSg,VKyiu81IYHwQAmt = [],-P2Fgh6TCOWoaHjkqBcQnvRNXe,ZVNvqy4iF1a9X
	for ZBstQ7jF04zNp8EmHoY5A in LL2H35jbrMlkIOR7C:
		if VKyiu81IYHwQAmt%vCpQGynNmWorxjIdPzBE==ZVNvqy4iF1a9X:
			LxNV5lenkhW6zoBJDMA7ZuqSg += P2Fgh6TCOWoaHjkqBcQnvRNXe
			yOkRiY4gxGq.append([])
		yOkRiY4gxGq[LxNV5lenkhW6zoBJDMA7ZuqSg].append(ZBstQ7jF04zNp8EmHoY5A)
		VKyiu81IYHwQAmt += P2Fgh6TCOWoaHjkqBcQnvRNXe
	return yOkRiY4gxGq
def s2dShARPpeyZMqHzOr(N4jmWQledskOFctof,qPWgu3zkRbrv74yho):
	H34pwYZBaRzOuA = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,N4jmWQledskOFctof)
	if P2Fgh6TCOWoaHjkqBcQnvRNXe or VVvcQpCU3OM09n(u"ࠨࡋࡓࡘ࡛ࡥࠧၢ") not in N4jmWQledskOFctof or rC5tnFDlQcRGA2(u"ࠩࡐ࠷࡚ࡥࠧၣ") not in N4jmWQledskOFctof: AyKma12GRYnziLV7EWIjUM = str(qPWgu3zkRbrv74yho)
	else:
		yOkRiY4gxGq = VESnzP5TLHsytv8irkf0maMg(qPWgu3zkRbrv74yho,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠻ᓠ"))
		AyKma12GRYnziLV7EWIjUM = CJlTSEpZsWb0QHg5w
		for Aa5Qesm6E04YZSRnufDUL in yOkRiY4gxGq:
			AyKma12GRYnziLV7EWIjUM += str(Aa5Qesm6E04YZSRnufDUL)+ZP1LyUCS3pIBu(u"ࠪࡠࡳࡢ࡮࠾࠿ࡀࡁࡡࡴ࡜࡯ࠩၤ")
		AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.strip(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪၥ"))
	V7VldYATX4k91ogih2pWtfD03Z = BBxt0yrLpJSHvc57i.compress(AyKma12GRYnziLV7EWIjUM)
	open(H34pwYZBaRzOuA,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡽࡢࠨၦ")).write(V7VldYATX4k91ogih2pWtfD03Z)
	return
def sLCGaj9ZoPRb(XpIWfPGjl4u9Czb82hJqeM6ya,N4jmWQledskOFctof):
	if XpIWfPGjl4u9Czb82hJqeM6ya==cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡤࡪࡥࡷࠫၧ"): qPWgu3zkRbrv74yho = {}
	elif XpIWfPGjl4u9Czb82hJqeM6ya==o2FdrDBimMuOw97q6QpNW8S(u"ࠧ࡭࡫ࡶࡸࠬၨ"): qPWgu3zkRbrv74yho = []
	elif XpIWfPGjl4u9Czb82hJqeM6ya==yylSaxCLfkte(u"ࠨࡵࡷࡶࠬၩ"): qPWgu3zkRbrv74yho = CJlTSEpZsWb0QHg5w
	elif XpIWfPGjl4u9Czb82hJqeM6ya==cbmeD4WNZfAowxT2JdUMtV(u"ࠩ࡬ࡲࡹ࠭ၪ"): qPWgu3zkRbrv74yho = ZVNvqy4iF1a9X
	else: qPWgu3zkRbrv74yho = gZvlfk6xhACbXcD5j0KBLiVM1
	H34pwYZBaRzOuA = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,N4jmWQledskOFctof)
	V7VldYATX4k91ogih2pWtfD03Z = open(H34pwYZBaRzOuA,o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡶࡧ࠭ၫ")).read()
	AyKma12GRYnziLV7EWIjUM = BBxt0yrLpJSHvc57i.decompress(V7VldYATX4k91ogih2pWtfD03Z)
	if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡡࡴ࡜࡯࠿ࡀࡁࡂࡢ࡮࡝ࡰࠪၬ") not in AyKma12GRYnziLV7EWIjUM: qPWgu3zkRbrv74yho = eval(AyKma12GRYnziLV7EWIjUM)
	else:
		yOkRiY4gxGq = AyKma12GRYnziLV7EWIjUM.split(Olh7n0zfV4(u"ࠬࡢ࡮࡝ࡰࡀࡁࡂࡃ࡜࡯࡞ࡱࠫၭ"))
		del AyKma12GRYnziLV7EWIjUM
		qPWgu3zkRbrv74yho = []
		TkxIJywZfLHQsX5RG = x74xDjR1rFbNiWh()
		dq7AOIkC9r0 = ZVNvqy4iF1a9X
		for Aa5Qesm6E04YZSRnufDUL in yOkRiY4gxGq:
			TkxIJywZfLHQsX5RG.TyXIMAtvq7bid6JOUuWGl4nQa(str(dq7AOIkC9r0),eval,Aa5Qesm6E04YZSRnufDUL)
			dq7AOIkC9r0 += P2Fgh6TCOWoaHjkqBcQnvRNXe
		del yOkRiY4gxGq
		TkxIJywZfLHQsX5RG.gqVFBJlS3Ls()
		TkxIJywZfLHQsX5RG.DhRWdGkFijfQ8ctsU325VNPL()
		VI9CqeduXPrjZ21K4 = list(TkxIJywZfLHQsX5RG.resultsDICT.keys())
		VWlvCniYe2a5dOgrH1FB7NyLqtmA6 = sorted(VI9CqeduXPrjZ21K4,reverse=VJZIMkUN5siqB21Pf,key=lambda key: int(key))
		for dq7AOIkC9r0 in VWlvCniYe2a5dOgrH1FB7NyLqtmA6:
			qPWgu3zkRbrv74yho += TkxIJywZfLHQsX5RG.resultsDICT[dq7AOIkC9r0]
	return qPWgu3zkRbrv74yho
def kSqzx3pFZMI5ubOhcv(R7xafKV3ekjDc):
	RRPpkxsyNtIc3qz9JfALOdFUjYrM = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ၮ"),R7xafKV3ekjDc,XB4CjMkPFzhAHiI3q(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪၯ"))
	try: tFvTlXUOKgR4wDoYa = open(RRPpkxsyNtIc3qz9JfALOdFUjYrM,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡴࡥࠫၰ")).read()
	except:
		YARfZGQHe4VCNv = tiFgl4DMvGEAUfjIYkHbr05.path.join(I6wir0ERy4koOXTzpLCmcl3udPbG,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡤࡨࡩࡵ࡮ࡴࠩၱ"),R7xafKV3ekjDc,cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡥࡩࡪ࡯࡯࠰ࡻࡱࡱ࠭ၲ"))
		try: tFvTlXUOKgR4wDoYa = open(YARfZGQHe4VCNv,KA26GucUHOwXL(u"ࠫࡷࡨࠧၳ")).read()
		except: return CJlTSEpZsWb0QHg5w,[]
	if A7Z6OVh20eCEUx: tFvTlXUOKgR4wDoYa = tFvTlXUOKgR4wDoYa.decode(Im5KSGZYBpRvdMVsbuXg)
	w4onF3YLqkPxDftG = Zy2l0g8QU5vqefaTrsw.findall(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࡯ࡤ࠾࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࡡ࡜ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠧࡢࠧ࡞ࠩၴ"),tFvTlXUOKgR4wDoYa,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
	if not w4onF3YLqkPxDftG: return CJlTSEpZsWb0QHg5w,[]
	ENJHylPC9Tzh1,ndYuZ4l1m2XFL8NgHTDrO35RvVEpbQ = w4onF3YLqkPxDftG[ZVNvqy4iF1a9X],Gb6AoxXFzh7L2SvVyZpWMuC5etNar(w4onF3YLqkPxDftG[ZVNvqy4iF1a9X])
	return ENJHylPC9Tzh1,ndYuZ4l1m2XFL8NgHTDrO35RvVEpbQ
def N5lYSE3q9CkFvwz():
	HuVBkN8n349gQG75EXoT = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,ZP1LyUCS3pIBu(u"࠭ࡤࡪࡥࡷࠫၵ"),VVvcQpCU3OM09n(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬၶ"),Olh7n0zfV4(u"ࠨࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍࠩၷ"))
	if HuVBkN8n349gQG75EXoT: return HuVBkN8n349gQG75EXoT
	f2Gc8gFzA3DEIV0e,HuVBkN8n349gQG75EXoT = {},{}
	Jmv5rj3SbqETVd = [Ew2zQ8u7Ss.SITESURLS[pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡕࡉࡕࡕࡓࠨၸ")][ZVNvqy4iF1a9X]]
	if K9MoWfyg6w2EHIki4lLtFSzpxQTmRX>O4F8UC5lMAS6ghETm1VoPDI(u"࠵࠼࠴࠹࠺ᓡ"): Jmv5rj3SbqETVd.append(Ew2zQ8u7Ss.SITESURLS[Olh7n0zfV4(u"ࠪࡖࡊࡖࡏࡔࠩၹ")][P2Fgh6TCOWoaHjkqBcQnvRNXe])
	if A7Z6OVh20eCEUx: Jmv5rj3SbqETVd.append(Ew2zQ8u7Ss.SITESURLS[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡗࡋࡐࡐࡕࠪၺ")][VTadWjBloMwXO2CH9GDK6FR])
	for nfG4gRMblTZw9LPEhxkID7caYjA1SO in Jmv5rj3SbqETVd:
		cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,otNfFapeEnO(u"ࠬࡍࡅࡕࠩၻ"),nfG4gRMblTZw9LPEhxkID7caYjA1SO,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪၼ"))
		if cDXLPHnAgY6NOk1GVStoiEx.succeeded:
			z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
			nBUClQLykd9fj42se7 = nfG4gRMblTZw9LPEhxkID7caYjA1SO.rsplit(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧ࠰ࠩၽ"),VVvcQpCU3OM09n(u"࠶ᓢ"))[ZVNvqy4iF1a9X]
			JuO5tp8CYHvkm2fQNhixKBcS = Zy2l0g8QU5vqefaTrsw.findall(rC5tnFDlQcRGA2(u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩၾ"),z4YnlxGHF2AMtrw,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
			for R7xafKV3ekjDc,jymBTuN4WwcE5tknG6pYOv0fULq3bJ in JuO5tp8CYHvkm2fQNhixKBcS:
				M06SHofqEdLjAIhwR174kug = nBUClQLykd9fj42se7+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࠲ࠫၿ")+R7xafKV3ekjDc+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪ࠳ࠬႀ")+R7xafKV3ekjDc+Olh7n0zfV4(u"ࠫ࠲࠭ႁ")+jymBTuN4WwcE5tknG6pYOv0fULq3bJ+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࠴ࡺࡪࡲࠪႂ")
				if R7xafKV3ekjDc not in list(f2Gc8gFzA3DEIV0e.keys()):
					f2Gc8gFzA3DEIV0e[R7xafKV3ekjDc] = []
					HuVBkN8n349gQG75EXoT[R7xafKV3ekjDc] = []
				XGm7UMI3qQgkBWLSaFbzEpe9Zy = Gb6AoxXFzh7L2SvVyZpWMuC5etNar(jymBTuN4WwcE5tknG6pYOv0fULq3bJ)
				f2Gc8gFzA3DEIV0e[R7xafKV3ekjDc].append((jymBTuN4WwcE5tknG6pYOv0fULq3bJ,XGm7UMI3qQgkBWLSaFbzEpe9Zy,M06SHofqEdLjAIhwR174kug))
	for R7xafKV3ekjDc in list(f2Gc8gFzA3DEIV0e.keys()):
		HuVBkN8n349gQG75EXoT[R7xafKV3ekjDc] = sorted(f2Gc8gFzA3DEIV0e[R7xafKV3ekjDc],reverse=w2qb6lf5EM,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe])
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,cjVhOCwybeRo7UWg92(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࡡ࠴ࠫႃ"),zQGaM7ctZCN(u"ࠧࡂࡎࡏࡣࡆࡊࡄࡐࡐࡖࡣ࡝ࡓࡌࠨႄ"),HuVBkN8n349gQG75EXoT,DRmUs7l1O4xLeZYzGITXk)
	return HuVBkN8n349gQG75EXoT
def Gb6AoxXFzh7L2SvVyZpWMuC5etNar(jymBTuN4WwcE5tknG6pYOv0fULq3bJ):
	XGm7UMI3qQgkBWLSaFbzEpe9Zy = []
	BfpVtayZ532mMiHoF0 = jymBTuN4WwcE5tknG6pYOv0fULq3bJ.split(VVvcQpCU3OM09n(u"ࠨ࠰ࠪႅ"))
	for IGyeJrS3KWXzYhQTUkowj in BfpVtayZ532mMiHoF0:
		iDqtORs9A8VflY2Kd1T0n6BC5a = Zy2l0g8QU5vqefaTrsw.findall(VVvcQpCU3OM09n(u"ࠩ࡟ࡨ࠰ࢂ࡛࡝࠭࡟࠱ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠭ႆ"),IGyeJrS3KWXzYhQTUkowj,Zy2l0g8QU5vqefaTrsw.DOTALL)
		vLDEePRNhQJmwHGFu3Tkc4 = []
		for I3IjyoftS7VqQROz8YTZg in iDqtORs9A8VflY2Kd1T0n6BC5a:
			if I3IjyoftS7VqQROz8YTZg.isdigit(): I3IjyoftS7VqQROz8YTZg = int(I3IjyoftS7VqQROz8YTZg)
			vLDEePRNhQJmwHGFu3Tkc4.append(I3IjyoftS7VqQROz8YTZg)
		XGm7UMI3qQgkBWLSaFbzEpe9Zy.append(vLDEePRNhQJmwHGFu3Tkc4)
	return XGm7UMI3qQgkBWLSaFbzEpe9Zy
def B69TdyIDhfjFGt1(XGm7UMI3qQgkBWLSaFbzEpe9Zy):
	jymBTuN4WwcE5tknG6pYOv0fULq3bJ = CJlTSEpZsWb0QHg5w
	for IGyeJrS3KWXzYhQTUkowj in XGm7UMI3qQgkBWLSaFbzEpe9Zy:
		for I3IjyoftS7VqQROz8YTZg in IGyeJrS3KWXzYhQTUkowj: jymBTuN4WwcE5tknG6pYOv0fULq3bJ += str(I3IjyoftS7VqQROz8YTZg)
		jymBTuN4WwcE5tknG6pYOv0fULq3bJ += HaTI5u1f3SCxmMAkw(u"ࠪ࠲ࠬႇ")
	jymBTuN4WwcE5tknG6pYOv0fULq3bJ = jymBTuN4WwcE5tknG6pYOv0fULq3bJ.strip(E6xdOMpqISHZCn(u"ࠫ࠳࠭ႈ"))
	return jymBTuN4WwcE5tknG6pYOv0fULq3bJ
def fxpB0b5NLy6EdFzR3HGPTA(SFKVM29ObyREINTkpeYnl):
	a50MeDjfCnLNzihu = {}
	f2Gc8gFzA3DEIV0e = N5lYSE3q9CkFvwz()
	pz7VsmOZtBlgULS1br46 = NNbhkjvUe2WfgxTrOznLK1yBEmi(SFKVM29ObyREINTkpeYnl)
	for R7xafKV3ekjDc in SFKVM29ObyREINTkpeYnl:
		if R7xafKV3ekjDc not in list(f2Gc8gFzA3DEIV0e.keys()): continue
		HuVBkN8n349gQG75EXoT = f2Gc8gFzA3DEIV0e[R7xafKV3ekjDc]
		DSFpkLealC5dni,ywMG2KRhO1zC3ZeNb4rs,x1MmilJ8qBSa3Rr = HuVBkN8n349gQG75EXoT[ZVNvqy4iF1a9X]
		VQ5UjWuFyntkMKDJO0xL9cSHI1bs87,ym8QhkAEsUdvWLpNxCnOS = kSqzx3pFZMI5ubOhcv(R7xafKV3ekjDc)
		sAJkjqRNdCLDhSaEb1QiF,TTLvC9uqVUB0EHXab2FQ3P = pz7VsmOZtBlgULS1br46[R7xafKV3ekjDc]
		FncPoTrjqfVOLtNC0GKlueBA = ywMG2KRhO1zC3ZeNb4rs>ym8QhkAEsUdvWLpNxCnOS and sAJkjqRNdCLDhSaEb1QiF
		a1soztfTFIlNcHiyQE = w2qb6lf5EM
		if not sAJkjqRNdCLDhSaEb1QiF: viZM3cPoFDSLyf4Xa = ZP1LyUCS3pIBu(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭ႉ")
		elif not TTLvC9uqVUB0EHXab2FQ3P: viZM3cPoFDSLyf4Xa = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨႊ")
		elif FncPoTrjqfVOLtNC0GKlueBA: viZM3cPoFDSLyf4Xa = cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡰ࡮ࡧࠫႋ")
		else:
			viZM3cPoFDSLyf4Xa = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡩࡲࡳࡩ࠭ႌ")
			a1soztfTFIlNcHiyQE = VJZIMkUN5siqB21Pf
		a50MeDjfCnLNzihu[R7xafKV3ekjDc] = a1soztfTFIlNcHiyQE,VQ5UjWuFyntkMKDJO0xL9cSHI1bs87,ym8QhkAEsUdvWLpNxCnOS,DSFpkLealC5dni,ywMG2KRhO1zC3ZeNb4rs,viZM3cPoFDSLyf4Xa,x1MmilJ8qBSa3Rr
	return a50MeDjfCnLNzihu
def KK4WuMYyThQ8l0SID2JrfGsb6UNx(OejfAMyHhNxYbXoRq6CuS3tlgz,gadmvqueZiH,IKqzEG85PMbAusV=CJlTSEpZsWb0QHg5w,wjAMDO6VSq=CJlTSEpZsWb0QHg5w,KPyIDuvmOxcRj1VS7Z=CJlTSEpZsWb0QHg5w):
	if BB7oCRfQNSYj5qDhTUevV: OejfAMyHhNxYbXoRq6CuS3tlgz.update(gadmvqueZiH,IKqzEG85PMbAusV,wjAMDO6VSq,KPyIDuvmOxcRj1VS7Z)
	else: OejfAMyHhNxYbXoRq6CuS3tlgz.update(gadmvqueZiH,IKqzEG85PMbAusV+rJ9cgWz4FU+wjAMDO6VSq+rJ9cgWz4FU+KPyIDuvmOxcRj1VS7Z)
	return
def S1FGp8IvLshO4Dy6wUZmCY7rN2MXkK(LhHVms8XJpc):
	def HbXhx4I0oDFw2jTzYvO1Ru(KVnjhJR1kz5lXEYpqus83,knrd6ixTJv48KeRNstpFOUAGS,uurPe73JiIG=VVvcQpCU3OM09n(u"ࠤ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡧࡢࡤࡦࡨࡪ࡬࡮ࡩ࡫࡭࡯ࡱࡳࡵࡰࡲࡴࡶࡸࡺࡼࡷࡹࡻࡽࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛ࠤႍ")):
		return ((KVnjhJR1kz5lXEYpqus83 == ZVNvqy4iF1a9X) and uurPe73JiIG[ZVNvqy4iF1a9X]) or (HbXhx4I0oDFw2jTzYvO1Ru(KVnjhJR1kz5lXEYpqus83 // knrd6ixTJv48KeRNstpFOUAGS, knrd6ixTJv48KeRNstpFOUAGS, uurPe73JiIG).lstrip(uurPe73JiIG[ZVNvqy4iF1a9X]) + uurPe73JiIG[KVnjhJR1kz5lXEYpqus83 % knrd6ixTJv48KeRNstpFOUAGS])
	def QQtdhHb2ClTODL(LviNUydm2HwK, C1ZzP82RTx4IGKWb7sh, EPdwUCv2nkAZeS, iIvKUWE23HyP0L, vtr23ZGUi6QNApnBuoadO9CEh8c=gZvlfk6xhACbXcD5j0KBLiVM1, ooYEZgPdSCMs8V6epw5v1=gZvlfk6xhACbXcD5j0KBLiVM1, yzYNjHGi6hV8qgUKLmPbl=gZvlfk6xhACbXcD5j0KBLiVM1):
		while (EPdwUCv2nkAZeS):
			EPdwUCv2nkAZeS-=O4F8UC5lMAS6ghETm1VoPDI(u"࠷ᓣ")
			if (iIvKUWE23HyP0L[EPdwUCv2nkAZeS]): LviNUydm2HwK = Zy2l0g8QU5vqefaTrsw.sub(otNfFapeEnO(u"ࠥࡠࡡࡨࠢႎ") + HbXhx4I0oDFw2jTzYvO1Ru(EPdwUCv2nkAZeS, C1ZzP82RTx4IGKWb7sh) + NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠦࡡࡢࡢࠣႏ"),  iIvKUWE23HyP0L[EPdwUCv2nkAZeS], LviNUydm2HwK)
		return LviNUydm2HwK
	LhHVms8XJpc = LhHVms8XJpc.split(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࢃࠨࠨ႐"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	LhHVms8XJpc = LhHVms8XJpc.rsplit(pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡳࡱ࡮࡬ࡸࠬ႑"))[ZVNvqy4iF1a9X]+s97s2k0LJgl(u"ࠢࡴࡲ࡯࡭ࡹ࠮ࠧࡽࠩࠬ࠭ࠧ႒")
	WJOpDChFa9XitZ3NIH80nm6 = eval(cjVhOCwybeRo7UWg92(u"ࠨࡷࡱࡴࡦࡩ࡫ࠩࠩ႓")+LhHVms8XJpc,{otNfFapeEnO(u"ࠩࡥࡥࡸ࡫ࡎࠨ႔"):HbXhx4I0oDFw2jTzYvO1Ru,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡹࡳࡶࡡࡤ࡭ࠪ႕"):QQtdhHb2ClTODL})
	return WJOpDChFa9XitZ3NIH80nm6
def Ce6kWT1z3S(code):
	_fjYnkVcKdCvT=yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠦ࠵࠷࠲࠴࠶࠸࠺࠼࠾࠹ࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝࠯࠴ࠨ႖")
	def js9phTMrqtGiyO52(ooYEZgPdSCMs8V6epw5v1,vtr23ZGUi6QNApnBuoadO9CEh8c,UUyN51JqFmOEPuDQIVXoWYB):
		AKIaeRtpQCvSOLE27q8mw = list(_fjYnkVcKdCvT)
		uY4HzB1MCdlL = AKIaeRtpQCvSOLE27q8mw[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠰ᓤ"):vtr23ZGUi6QNApnBuoadO9CEh8c]
		PMTRpXQvDIkiNszwYGnb32a = AKIaeRtpQCvSOLE27q8mw[JACnOz297UuDK5HpPkc1LF(u"࠱ᓥ"):UUyN51JqFmOEPuDQIVXoWYB]
		ooYEZgPdSCMs8V6epw5v1 = list(ooYEZgPdSCMs8V6epw5v1)[::-HaTI5u1f3SCxmMAkw(u"࠳ᓦ")]
		DqUuWaBZV24 = o2FdrDBimMuOw97q6QpNW8S(u"࠳ᓧ")
		for EPdwUCv2nkAZeS,knrd6ixTJv48KeRNstpFOUAGS in enumerate(ooYEZgPdSCMs8V6epw5v1):
			if knrd6ixTJv48KeRNstpFOUAGS in uY4HzB1MCdlL: DqUuWaBZV24 = DqUuWaBZV24 + uY4HzB1MCdlL.index(knrd6ixTJv48KeRNstpFOUAGS)*vtr23ZGUi6QNApnBuoadO9CEh8c**EPdwUCv2nkAZeS
		iIvKUWE23HyP0L = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࠨ႗")
		while DqUuWaBZV24 > s97s2k0LJgl(u"࠴ᓨ"):
			iIvKUWE23HyP0L = PMTRpXQvDIkiNszwYGnb32a[DqUuWaBZV24%UUyN51JqFmOEPuDQIVXoWYB] + iIvKUWE23HyP0L
			DqUuWaBZV24 = (DqUuWaBZV24 - (DqUuWaBZV24%UUyN51JqFmOEPuDQIVXoWYB))//UUyN51JqFmOEPuDQIVXoWYB
		return int(iIvKUWE23HyP0L) or cjVhOCwybeRo7UWg92(u"࠵ᓩ")
	def mxbtAS9XyiKZQnYEfl71(uY4HzB1MCdlL,u,V4r0Xv5lTtABaed3MmCG6HcspxURQ,RRz9dcuLD4TwMQaYyiI,vtr23ZGUi6QNApnBuoadO9CEh8c,yzYNjHGi6hV8qgUKLmPbl):
		yzYNjHGi6hV8qgUKLmPbl = zQGaM7ctZCN(u"ࠨࠢ႘");
		PMTRpXQvDIkiNszwYGnb32a = HaTI5u1f3SCxmMAkw(u"࠶ᓪ")
		while PMTRpXQvDIkiNszwYGnb32a < len(uY4HzB1MCdlL):
			DqUuWaBZV24 = pz4WBwfyDdgk0m2aRr7SMv(u"࠰ᓫ")
			vEUp7Fz2hc3OZrlm = JACnOz297UuDK5HpPkc1LF(u"ࠢࠣ႙")
			while uY4HzB1MCdlL[PMTRpXQvDIkiNszwYGnb32a] is not V4r0Xv5lTtABaed3MmCG6HcspxURQ[vtr23ZGUi6QNApnBuoadO9CEh8c]:
				vEUp7Fz2hc3OZrlm = CJlTSEpZsWb0QHg5w.join([vEUp7Fz2hc3OZrlm,uY4HzB1MCdlL[PMTRpXQvDIkiNszwYGnb32a]])
				PMTRpXQvDIkiNszwYGnb32a = PMTRpXQvDIkiNszwYGnb32a + h6sIkJOT5PB2vCxqo4LFag70wA(u"࠲ᓬ")
			while DqUuWaBZV24 < len(V4r0Xv5lTtABaed3MmCG6HcspxURQ):
				vEUp7Fz2hc3OZrlm = vEUp7Fz2hc3OZrlm.replace(V4r0Xv5lTtABaed3MmCG6HcspxURQ[DqUuWaBZV24],str(DqUuWaBZV24))
				DqUuWaBZV24 = DqUuWaBZV24 + yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠳ᓭ")
			yzYNjHGi6hV8qgUKLmPbl = CJlTSEpZsWb0QHg5w.join([yzYNjHGi6hV8qgUKLmPbl,CJlTSEpZsWb0QHg5w.join(map(chr, [js9phTMrqtGiyO52(vEUp7Fz2hc3OZrlm,vtr23ZGUi6QNApnBuoadO9CEh8c,cbmeD4WNZfAowxT2JdUMtV(u"࠴࠴ᓮ")) - RRz9dcuLD4TwMQaYyiI]))])
			PMTRpXQvDIkiNszwYGnb32a = PMTRpXQvDIkiNszwYGnb32a + XB4CjMkPFzhAHiI3q(u"࠵ᓯ")
		return yzYNjHGi6hV8qgUKLmPbl
	code = code.replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ࡞ࡱࠫႚ"),CJlTSEpZsWb0QHg5w).replace(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩ࡟ࡶࠬႛ"),CJlTSEpZsWb0QHg5w)
	mUlywZzoxd6jChg4 = Zy2l0g8QU5vqefaTrsw.findall(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡠࢂࡢࠨࠣࠪ࡟ࡻ࠰࠯ࠢ࠭ࠪ࡟ࡨ࠰࠯ࠬࠣࠪ࡟ࡻ࠰࠯ࠢ࠭ࠪ࡟ࡨ࠰࠯ࠬࠩ࡞ࡧ࠯࠮࠲ࠨ࡝ࡦ࠮࠭ࡡ࠯࡜ࠪࠩႜ"),code,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if mUlywZzoxd6jChg4:
		mUlywZzoxd6jChg4 = list(mUlywZzoxd6jChg4[E6xdOMpqISHZCn(u"࠵ᓰ")])
		for vd6fL8NbeVr4syJ,code in enumerate(mUlywZzoxd6jChg4):
			if code.isdigit(): mUlywZzoxd6jChg4[vd6fL8NbeVr4syJ] = int(code)
			else: mUlywZzoxd6jChg4[vd6fL8NbeVr4syJ] = code.replace(mi2ZJXCDzITuyev6gfn(u"ࠫࡡࠨࠧႝ"),CJlTSEpZsWb0QHg5w)
		uoIDSbAy4R0WxlGiNMkwJB9ZH = mxbtAS9XyiKZQnYEfl71(*mUlywZzoxd6jChg4)
		return uoIDSbAy4R0WxlGiNMkwJB9ZH
	return CJlTSEpZsWb0QHg5w
def wjDlhYFdEG5(otaunYGVIJ2jX8HsKm7ecR0bAh4,WMkBG4aFKy1J6mpI9A=CJlTSEpZsWb0QHg5w):
	if WMkBG4aFKy1J6mpI9A==mi2ZJXCDzITuyev6gfn(u"ࠬࡲ࡯ࡸࡧࡵࠫ႞"): otaunYGVIJ2jX8HsKm7ecR0bAh4 = Zy2l0g8QU5vqefaTrsw.sub(ZP1LyUCS3pIBu(u"ࡸࠧࠦ࡝࠳࠱࠾ࡇ࡛࠭࡟ࡾ࠶ࢂ࠭႟"),lambda aa9BEsL21Srjc: aa9BEsL21Srjc.group(ZVNvqy4iF1a9X).lower(),otaunYGVIJ2jX8HsKm7ecR0bAh4)
	elif WMkBG4aFKy1J6mpI9A==s97s2k0LJgl(u"ࠧࡶࡲࡳࡩࡷ࠭Ⴀ"): otaunYGVIJ2jX8HsKm7ecR0bAh4 = Zy2l0g8QU5vqefaTrsw.sub(otNfFapeEnO(u"ࡳࠩࠨ࡟࠵࠳࠹ࡢ࠯ࡽࡡࢀ࠸ࡽࠨႡ"),lambda aa9BEsL21Srjc: aa9BEsL21Srjc.group(ZVNvqy4iF1a9X).upper(),otaunYGVIJ2jX8HsKm7ecR0bAh4)
	return otaunYGVIJ2jX8HsKm7ecR0bAh4
def NNbhkjvUe2WfgxTrOznLK1yBEmi(SFKVM29ObyREINTkpeYnl):
	veT8ibFAjHla5P,aBNLtkVZn5K3T = VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX = Izg3hVy4Nx1oOU6L29DFkmqnZ.connect(JTRCZri9Oka5mAUslqIhz0)
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.text_factory = str
	CUYvKkg403sS1yxGoTbWDhJAXN = PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.cursor()
	if len(SFKVM29ObyREINTkpeYnl)==P2Fgh6TCOWoaHjkqBcQnvRNXe: MWuG53wtk0TvQZPREg1nJVDc = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࠫࠦࠬႢ")+SFKVM29ObyREINTkpeYnl[ZVNvqy4iF1a9X]+pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࠦ࠮࠭Ⴃ")
	else: MWuG53wtk0TvQZPREg1nJVDc = str(tuple(SFKVM29ObyREINTkpeYnl))
	CUYvKkg403sS1yxGoTbWDhJAXN.execute(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡘࡋࡌࡆࡅࡗࠤࡦࡪࡤࡰࡰࡌࡈ࠱࡫࡮ࡢࡤ࡯ࡩࡩࠦࡆࡓࡑࡐࠤ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠࡊࡐࠣࠫႤ")+MWuG53wtk0TvQZPREg1nJVDc+O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࠦ࠻ࠨႥ"))
	FlhSkMf52TtUubsO = CUYvKkg403sS1yxGoTbWDhJAXN.fetchall()
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
	pz7VsmOZtBlgULS1br46 = {}
	for R7xafKV3ekjDc in SFKVM29ObyREINTkpeYnl: pz7VsmOZtBlgULS1br46[R7xafKV3ekjDc] = (VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	for R7xafKV3ekjDc,aBNLtkVZn5K3T in FlhSkMf52TtUubsO:
		veT8ibFAjHla5P = w2qb6lf5EM
		aBNLtkVZn5K3T = aBNLtkVZn5K3T==P2Fgh6TCOWoaHjkqBcQnvRNXe
		pz7VsmOZtBlgULS1br46[R7xafKV3ekjDc] = (veT8ibFAjHla5P,aBNLtkVZn5K3T)
	return pz7VsmOZtBlgULS1br46
def nfpZxRXATHiEOK465l9SvrsbmQ(gdGX631yzBwMoYjUpqNt):
	SD0TxMRXiep4cjPBsnzI = CJlTSEpZsWb0QHg5w
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(gdGX631yzBwMoYjUpqNt):
		AAFCv5YQlirBegzb8Lq = open(gdGX631yzBwMoYjUpqNt,EcjO3giln2kQTdBY0XLAG(u"࠭ࡲࡣࠩႦ")).read()
		if A7Z6OVh20eCEUx: AAFCv5YQlirBegzb8Lq = AAFCv5YQlirBegzb8Lq.decode(Im5KSGZYBpRvdMVsbuXg)
		FZXAqTw7bfyiJheLzr4tNYPls = oE7iT3HI5VDdmY4kPOjr(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡥ࡫ࡦࡸࠬႧ"),AAFCv5YQlirBegzb8Lq)
		if FZXAqTw7bfyiJheLzr4tNYPls:
			SD0TxMRXiep4cjPBsnzI = {}
			for IVZCbl4keXui in FZXAqTw7bfyiJheLzr4tNYPls.keys():
				SD0TxMRXiep4cjPBsnzI[IVZCbl4keXui] = []
				for e5YTXfZdE6UmBqt7oDFgOGsPw0b2 in FZXAqTw7bfyiJheLzr4tNYPls[IVZCbl4keXui]:
					kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
					kcxAmftieK56PE9TqbDHdSrF8 = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[ZVNvqy4iF1a9X]
					kuiZt5zMdvVJyC4LqwGDX = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[P2Fgh6TCOWoaHjkqBcQnvRNXe]
					kuiZt5zMdvVJyC4LqwGDX = qmi8sS9rIkdBzjfu43UpPeVJh0oCAn(kuiZt5zMdvVJyC4LqwGDX)
					otaunYGVIJ2jX8HsKm7ecR0bAh4 = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[VTadWjBloMwXO2CH9GDK6FR]
					n3dz9vetbZKIVYm78 = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[D9yBM7wPFLz]
					t4zynV13ZoPe = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[P3cpaLN2sH]
					GOF25jkXb1DnaB4vhL9 = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[EcjO3giln2kQTdBY0XLAG(u"࠻ᓱ")]
					if len(e5YTXfZdE6UmBqt7oDFgOGsPw0b2)>otNfFapeEnO(u"࠶ᓲ"): AyKma12GRYnziLV7EWIjUM = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[otNfFapeEnO(u"࠶ᓲ")]
					if len(e5YTXfZdE6UmBqt7oDFgOGsPw0b2)>h6sIkJOT5PB2vCxqo4LFag70wA(u"࠸ᓳ"): QQa9t5k6BLqflRNr = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[h6sIkJOT5PB2vCxqo4LFag70wA(u"࠸ᓳ")]
					if len(e5YTXfZdE6UmBqt7oDFgOGsPw0b2)>cbmeD4WNZfAowxT2JdUMtV(u"࠺ᓴ"): TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = e5YTXfZdE6UmBqt7oDFgOGsPw0b2[cbmeD4WNZfAowxT2JdUMtV(u"࠺ᓴ")]
					if gdGX631yzBwMoYjUpqNt==wiEebAT9Qs7dCztufUZNORv3: JHsxoRXCp8IBiqN0GFh3YzOjS = kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,CJlTSEpZsWb0QHg5w,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
					else: JHsxoRXCp8IBiqN0GFh3YzOjS = kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
					SD0TxMRXiep4cjPBsnzI[IVZCbl4keXui].append(JHsxoRXCp8IBiqN0GFh3YzOjS)
		fTpbwJEnLgeiay = str(SD0TxMRXiep4cjPBsnzI)
		if A7Z6OVh20eCEUx: fTpbwJEnLgeiay = fTpbwJEnLgeiay.encode(Im5KSGZYBpRvdMVsbuXg)
		open(gdGX631yzBwMoYjUpqNt,GISOTJh20W(u"ࠨࡹࡥࠫႨ")).write(fTpbwJEnLgeiay)
	return SD0TxMRXiep4cjPBsnzI
def ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci):
	TN8amyIXdQ = ad3z2451e09FrDHmvci.split(rC5tnFDlQcRGA2(u"ࠩ࠰ࠫႩ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
	jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	if   TN8amyIXdQ==rC5tnFDlQcRGA2(u"ࠪࡅࡍ࡝ࡁࡌࠩႪ")		:	from JKXc9nTNLq			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡆࡑࡏࡂࡏࠪႫ")		:	from PMGCT1ry9N			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓࠧႬ")	:	from KRtOEird86		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡁࡌ࡙ࡄࡑࠬႭ")		:	from fMhIVs8A5o			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yylSaxCLfkte(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪႮ")	:	from ccraUs1HBk		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡃࡏࡅࡗࡇࡂࠨႯ")	:	from AAvutxbwq9			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡄࡐࡋࡇࡔࡊࡏࡌࠫႰ")	:	from un9ZWjDp3F		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==XB4CjMkPFzhAHiI3q(u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭Ⴑ")	: 	from LozcH5xSi2		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭Ⴒ")	:	from PaLAEs3vhU		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭Ⴓ")	:	from w4cFd2lNLr		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cjVhOCwybeRo7UWg92(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨႴ")	:	from cBQLUZ4fs3		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬႵ"):	from lgWhXue6US	import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==ZP1LyUCS3pIBu(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪႶ")	:	from LCqVJ8tl0O		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==Olh7n0zfV4(u"ࠩࡄ࡝ࡑࡕࡌࠨႷ")		:	from ymjQYBHaUe			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡆࡔࡑࡒࡂࠩႸ")		:	from rJPGnWcRkF			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KA26GucUHOwXL(u"ࠫࡇࡘࡓࡕࡇࡍࠫႹ")	:	from xLo4rRMKA7			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==mi2ZJXCDzITuyev6gfn(u"ࠬࡉࡉࡎࡃ࠷࠴࠵࠭Ⴚ")	:	from UkgWsu2NXf		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡃࡊࡏࡄ࠸ࡕ࠭Ⴛ")	:	from E95EBVzPex			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==s97s2k0LJgl(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧႼ")	:	from JAZmdeQUG1			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==XB4CjMkPFzhAHiI3q(u"ࠨࡅࡌࡑࡆࡇࡂࡅࡑࠪႽ")	:	from nD5CrOKphe		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫႾ")	:	from ZZBuKcinpY		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cjVhOCwybeRo7UWg92(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩႿ"):	from RRbldB0kun	import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cjVhOCwybeRo7UWg92(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡕ࠭Ⴠ")	:	from xxDu24R6Zl		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==zQGaM7ctZCN(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧჁ")	:	from V0sUqye5m1		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡃࡊࡏࡄࡊࡗࡋࡅࠨჂ")	:	from iGF8JxXP3H		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡄࡋࡐࡅࡑࡏࡇࡉࡖࠪჃ")	:	from yCutDpP26Y		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==ZP1LyUCS3pIBu(u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩჄ")	:	from uq56mLpixQ		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==otNfFapeEnO(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫჅ")	:	from tKYSI6VxUi		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==HaTI5u1f3SCxmMAkw(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ჆"):	from UaYmNHehiZ	import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧჇ")	:	from V32U0Bs6Pc		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==ZP1LyUCS3pIBu(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭჈")	:	from Oqnu9wWgj4		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KA26GucUHOwXL(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࠧ჉")	:	from lb8y2mRT1O		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠲ࠩ჊")	:	from wKtk0pBnzE		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪ჋")	:	from SSicMeh0Kq		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==JACnOz297UuDK5HpPkc1LF(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠶ࠫ჌")	:	from BgOA7CehMY		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==Olh7n0zfV4(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬჍ")	:	from ssMROAFa4r		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==mi2ZJXCDzITuyev6gfn(u"ࠫࡊࡍ࡙ࡅࡇࡄࡈࠬ჎")	:	from Zc8dqj9vXN		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==E6xdOMpqISHZCn(u"ࠬࡋࡇ࡚ࡐࡒ࡛ࠬ჏")	:	from MVNu3jLwfF			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cjVhOCwybeRo7UWg92(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁࠨა")	:	from Adj6mLvDqc		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡆࡎࡌࡊ࡛ࡏࡄࡆࡑࠪბ")	:	from LHZmQ4nOh7		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩგ")	:	from C5giu860eU		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yylSaxCLfkte(u"ࠩࡉࡅࡏࡋࡒࡔࡊࡒ࡛ࠬდ")	:	from nYOv7ZqUTm		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫე")	:	from KB0hFNjHUz		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==mi2ZJXCDzITuyev6gfn(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ვ")	:	from EsAg37oUWu		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡌࡁࡔࡇࡏࡌࡉ࠸ࠧზ")	:	from jcyOMs9vF8		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡆࡐࡕࡗࡅࠬთ")		:	from I2p3Vsyoxn			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨი")	:	from jax5lmANT7		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KA26GucUHOwXL(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪკ")	:	from I8d2LJOfuH		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==zQGaM7ctZCN(u"ࠩࡉ࡙ࡘࡎࡁࡓࡘࡌࡈࡊࡕࠧლ"):	from pzYJTGmx5U	import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡋࡔࡕࡇࡍࡇࡖࡉࡆࡘࡃࡉࠩმ"):	from GKZzPyrb45	import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ნ")	:	from LLMe7oWdwj		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡏࡆࡊࡎࡐࠫო")		:	from jYGOKwRDuV			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡉࡑࡖ࡙ࠫპ")		:	from Da6LhPonbt			import kXTvVPcz07xwBfhnptsW1qaOC as jJRFufHp4y0KoasdBXqkEGl,j5jSfelZXC0UJNR8m3OVI17sq as x3L5fIUkM6czApTHVJtoWN8b4i,fFi12zTm45q8LO3bt7yXDKcagRACp as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KA26GucUHOwXL(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪჟ")	:	from O1e3yd5sri		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡍࡄࡘࡐࡕࡔࡕࡘࠪრ")	:	from mmK1S6acjg		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==E6xdOMpqISHZCn(u"ࠩࡎࡅ࡙ࡑࡏࡖࡖࡈࠫს")	:	from BBLdeRq0m6		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡏࡎࡘࡍࡂࡎࡎࠫტ")	:	from Hk5iJWYItf		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==XB4CjMkPFzhAHiI3q(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫუ")	:	from oJPQSp7stv			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ფ")	:	from TxJmS0bOEY		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡍ࠴ࡗࠪქ")		:	from vQnI182HJr			import kXTvVPcz07xwBfhnptsW1qaOC as jJRFufHp4y0KoasdBXqkEGl,j5jSfelZXC0UJNR8m3OVI17sq as x3L5fIUkM6czApTHVJtoWN8b4i,fFi12zTm45q8LO3bt7yXDKcagRACp as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪღ")	:	from TTtYMwLRpd		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==Olh7n0zfV4(u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨყ")	:	from up1VAmNE29			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡐ࡝ࡈࡏࡍࡂࠩშ")	:	from PPpYRBirye			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yylSaxCLfkte(u"ࠪࡔࡆࡔࡅࡕࠩჩ")		:	from OtDa8Ks7j6			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==zQGaM7ctZCN(u"ࠫࡖࡌࡉࡍࡏࠪც")		:	from jl0f3PNMDJ			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩძ"):	from OpgkXNqSf3		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡓࡉࡃࡅࡅࡐࡇࡔ࡚ࠩწ")	:	from jhG13yFHMx		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==XB4CjMkPFzhAHiI3q(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩჭ")	:	from w8pxZIi0LV		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==mi2ZJXCDzITuyev6gfn(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠵ࠫხ")	:	from wzxh4ZjFn8		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==E6xdOMpqISHZCn(u"ࠩࡖࡌࡆࡎࡉࡅࡐࡈ࡛ࡘ࠭ჯ"):	from Nue7J04rw9		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==XB4CjMkPFzhAHiI3q(u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠭ჰ")	:	from HvZyqG6mw3		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==s97s2k0LJgl(u"ࠫࡘࡎࡏࡇࡊࡄࠫჱ")	:	from Uw6QLFH1Vs			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==Olh7n0zfV4(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧჲ")	:	from Ea1UsVNk0u		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨჳ")	:	from qpxCfU8kW0		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡔࡊࡒࡓࡋࡖࡒࡐࠩჴ")	:	from LLfe8VFlaY		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡖࡌࡏࡆࡇࡔࠨჵ")	:	from ysVbrgY2T0			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==cjVhOCwybeRo7UWg92(u"ࠩࡗ࡚ࡋ࡛ࡎࠨჶ")		:	from IPtNXUHTKY			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==TDpFsQXHze2q30uYtGPfEIm8(u"࡚ࠪࡆࡘࡂࡐࡐࠪჷ")	:	from JNWU8HlCdk			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==JACnOz297UuDK5HpPkc1LF(u"࡛ࠫࡏࡄࡆࡑࡑࡗࡆࡋࡍࠨჸ"):	from Db2QqPEA9H		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭ჹ")	:	from ssyvixmErW		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧჺ")	:	from A3AJdilj7s		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࡚ࠧࡃࡔࡓ࡙࠭჻")		:	from pMyZescFv0			import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==otNfFapeEnO(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩჼ")	:	from pBMYifbqJA		import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	elif TN8amyIXdQ==pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ࡜ࡘࡇࡥࡃࡉࡃࡑࡒࡊࡒࡓࠨჽ"):	from HWkRbNjSlz	import kNjCwITmx4YAShdE62FJ as jJRFufHp4y0KoasdBXqkEGl,HYGiJ9pfmMTnIb4L7tX as x3L5fIUkM6czApTHVJtoWN8b4i,kL0nT7NpZdKVD3jM2OHB as FTbIBSC3OLPvyaZjqK7
	return jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7
def AznaIjR5kDMBf(fxnDkKpluQH,Dfi7FTuYWN49AaLEt3,showDialogs):
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,rC5tnFDlQcRGA2(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪ࠾ࠥࡡࠠࠨჾ")+fxnDkKpluQH+cjVhOCwybeRo7UWg92(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧჿ")+str(Dfi7FTuYWN49AaLEt3)+s97s2k0LJgl(u"ࠬࠦ࡝ࠨᄀ"))
	OejfAMyHhNxYbXoRq6CuS3tlgz = lkPKsYmp4UjR()
	OejfAMyHhNxYbXoRq6CuS3tlgz.create(TAExSfcoNi4eORZ8HPB,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"๊࠭อำํࠤฬ๊ย็ࠢไัฺࠦวๅ็็ๅࠥอไๆู็์อࠦสฮ็ํ่์่ࠦษ฻า๋ฬࠦำ้ใࠣฮอีรࠡ฻่่๏ฯࠠอๆหࠤฬ๊ๅๅใ้๋ࠣࠦวๅว้ฮึ์สࠨᄁ"))
	k0kxuL3BiKy2ePQfTcdM = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠴࠴࠷࠺ᓵ")*od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠴࠴࠷࠺ᓵ")
	Zj0n9wd37SDQXFkKeLyRI = XB4CjMkPFzhAHiI3q(u"࠵ᓶ")*k0kxuL3BiKy2ePQfTcdM
	import requests as WjPGK7puI3D2m0qXcHYEVUovrL1xkJ
	cDXLPHnAgY6NOk1GVStoiEx = WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.get(fxnDkKpluQH,stream=w2qb6lf5EM,headers=Dfi7FTuYWN49AaLEt3)
	VVfcRwtoxaFuB3Is = cDXLPHnAgY6NOk1GVStoiEx.headers
	cDXLPHnAgY6NOk1GVStoiEx.close()
	FFsQLVeqpYBaNOAojIbwy4 = bytes()
	if not VVfcRwtoxaFuB3Is:
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,pz4WBwfyDdgk0m2aRr7SMv(u"ࠧศๆหี๋อๅอࠢ็้ࠥ๐สๆๅ้ࠤ๊์ࠠหฯ่๎้ࠦวๅ็็ๅࠥอไๆู็์อ่ࠦศๆึฬอࠦโะࠢํ็ํ์ฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤ࠳ࠦฬาสࠣฮา๋๊ๅࠢส่๊๊แࠡ็ิอࠥษฮา๋ࠪᄂ"))
		OejfAMyHhNxYbXoRq6CuS3tlgz.close()
	else:
		if h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩᄃ") not in list(VVfcRwtoxaFuB3Is.keys()): WC7kstl2IgMbpNGh1uU86QjB = ZVNvqy4iF1a9X
		else: WC7kstl2IgMbpNGh1uU86QjB = int(VVfcRwtoxaFuB3Is[cjVhOCwybeRo7UWg92(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪᄄ")])
		ToYuiyRQ9tmZI0gzU3Cv7saP = str(int(zQGaM7ctZCN(u"࠷࠰࠱࠲ᓸ")*WC7kstl2IgMbpNGh1uU86QjB/k0kxuL3BiKy2ePQfTcdM)/yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶࠶࠰࠱࠰࠳ᓷ"))
		GcMwHQb6gBD9lKykj = int(WC7kstl2IgMbpNGh1uU86QjB/Zj0n9wd37SDQXFkKeLyRI)+P2Fgh6TCOWoaHjkqBcQnvRNXe
		if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡗࡧ࡮ࡨࡧࠪᄅ") in list(VVfcRwtoxaFuB3Is.keys()) and WC7kstl2IgMbpNGh1uU86QjB>k0kxuL3BiKy2ePQfTcdM:
			v3zrGsd6Moi7m2Bw = w2qb6lf5EM
			XAgbJRSYCHt6VNszhErGqc = []
			VILbKSMmFy1vEHruiBYfUC = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠱࠱ᓹ")
			XAgbJRSYCHt6VNszhErGqc.append(str(ZVNvqy4iF1a9X*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+mi2ZJXCDzITuyev6gfn(u"ࠫ࠲࠭ᄆ")+str(P2Fgh6TCOWoaHjkqBcQnvRNXe*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(P2Fgh6TCOWoaHjkqBcQnvRNXe*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+E6xdOMpqISHZCn(u"ࠬ࠳ࠧᄇ")+str(VTadWjBloMwXO2CH9GDK6FR*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(VTadWjBloMwXO2CH9GDK6FR*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+E6xdOMpqISHZCn(u"࠭࠭ࠨᄈ")+str(D9yBM7wPFLz*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(D9yBM7wPFLz*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࠮ࠩᄉ")+str(P3cpaLN2sH*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(P3cpaLN2sH*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨ࠯ࠪᄊ")+str(VVvcQpCU3OM09n(u"࠶ᓺ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(s97s2k0LJgl(u"࠷ᓻ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩ࠰ࠫᄋ")+str(zQGaM7ctZCN(u"࠹ᓼ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(mi2ZJXCDzITuyev6gfn(u"࠻ᓾ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+O4F8UC5lMAS6ghETm1VoPDI(u"ࠪ࠱ࠬᄌ")+str(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠻ᓽ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(o2FdrDBimMuOw97q6QpNW8S(u"࠷ᔀ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+EcjO3giln2kQTdBY0XLAG(u"ࠫ࠲࠭ᄍ")+str(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠾ᓿ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(o2FdrDBimMuOw97q6QpNW8S(u"࠺ᔂ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࠳ࠧᄎ")+str(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠺ᔁ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC-P2Fgh6TCOWoaHjkqBcQnvRNXe))
			XAgbJRSYCHt6VNszhErGqc.append(str(zQGaM7ctZCN(u"࠼ᔃ")*WC7kstl2IgMbpNGh1uU86QjB//VILbKSMmFy1vEHruiBYfUC)+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࠭ࠨᄏ"))
			Ngq3Ik0eoAZXd6ufTlhFOjHvcp7xS = float(GcMwHQb6gBD9lKykj)/VILbKSMmFy1vEHruiBYfUC
			QniujGXOm8sLBD = Ngq3Ik0eoAZXd6ufTlhFOjHvcp7xS/int(P2Fgh6TCOWoaHjkqBcQnvRNXe+Ngq3Ik0eoAZXd6ufTlhFOjHvcp7xS)
		else:
			v3zrGsd6Moi7m2Bw = VJZIMkUN5siqB21Pf
			VILbKSMmFy1vEHruiBYfUC = P2Fgh6TCOWoaHjkqBcQnvRNXe
			QniujGXOm8sLBD = P2Fgh6TCOWoaHjkqBcQnvRNXe
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,TDpFsQXHze2q30uYtGPfEIm8(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨࠥࡻࡳࡪࡰࡪࠤࡷࡧ࡮ࡨࡧࡶ࠾ࠥࡡࠠࠨᄐ")+str(v3zrGsd6Moi7m2Bw)+Olh7n0zfV4(u"ࠨࠢࡠࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᄑ")+str(WC7kstl2IgMbpNGh1uU86QjB)+ZP1LyUCS3pIBu(u"ࠩࠣࡡࠬᄒ"))
		LxNV5lenkhW6zoBJDMA7ZuqSg,UAM4rBejpLyg9KaVFcG8JmEx71TZsH = ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
		for VKyiu81IYHwQAmt in range(VILbKSMmFy1vEHruiBYfUC):
			bsGedm1TLP7EgiUQDkCy = Dfi7FTuYWN49AaLEt3.copy()
			if v3zrGsd6Moi7m2Bw: bsGedm1TLP7EgiUQDkCy[mi2ZJXCDzITuyev6gfn(u"ࠪࡖࡦࡴࡧࡦࠩᄓ")] = yylSaxCLfkte(u"ࠫࡧࡿࡴࡦࡵࡀࠫᄔ")+XAgbJRSYCHt6VNszhErGqc[VKyiu81IYHwQAmt]
			cDXLPHnAgY6NOk1GVStoiEx = WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.get(fxnDkKpluQH,stream=w2qb6lf5EM,headers=bsGedm1TLP7EgiUQDkCy,timeout=xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠷࠵࠶ᔄ"))
			for qBXeus8rlIF1Y3RT in cDXLPHnAgY6NOk1GVStoiEx.iter_content(chunk_size=Zj0n9wd37SDQXFkKeLyRI):
				if OejfAMyHhNxYbXoRq6CuS3tlgz.iscanceled():
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,VVvcQpCU3OM09n(u"ࠬ࠴࡜ࡵࡆࡲࡻࡳࡲ࡯ࡢࡦࠣࡇࡦࡴࡣࡦ࡮ࡨࡨࠬᄕ"))
					break
				LxNV5lenkhW6zoBJDMA7ZuqSg += QniujGXOm8sLBD
				FFsQLVeqpYBaNOAojIbwy4 += qBXeus8rlIF1Y3RT
				if not UAM4rBejpLyg9KaVFcG8JmEx71TZsH: UAM4rBejpLyg9KaVFcG8JmEx71TZsH = len(qBXeus8rlIF1Y3RT)
				if WC7kstl2IgMbpNGh1uU86QjB: KK4WuMYyThQ8l0SID2JrfGsb6UNx(OejfAMyHhNxYbXoRq6CuS3tlgz,ZP1LyUCS3pIBu(u"࠶࠶࠰ᔅ")*LxNV5lenkhW6zoBJDMA7ZuqSg//GcMwHQb6gBD9lKykj,KA26GucUHOwXL(u"࠭ฬๅสࠣห้๋ไโ࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧᄖ"),str(cbmeD4WNZfAowxT2JdUMtV(u"࠷࠰࠱࠰࠳ᔆ")*UAM4rBejpLyg9KaVFcG8JmEx71TZsH*LxNV5lenkhW6zoBJDMA7ZuqSg//Zj0n9wd37SDQXFkKeLyRI//cbmeD4WNZfAowxT2JdUMtV(u"࠷࠰࠱࠰࠳ᔆ"))+GISOTJh20W(u"ࠧࠡ࠱ࠣࠫᄗ")+ToYuiyRQ9tmZI0gzU3Cv7saP+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࠢࡐࡆࠬᄘ"))
				else: KK4WuMYyThQ8l0SID2JrfGsb6UNx(OejfAMyHhNxYbXoRq6CuS3tlgz,UAM4rBejpLyg9KaVFcG8JmEx71TZsH*LxNV5lenkhW6zoBJDMA7ZuqSg//Zj0n9wd37SDQXFkKeLyRI,yylSaxCLfkte(u"ࠩฯ่อࠦวๅ็็ๅ࠿࠳ࠧᄙ"),str(rC5tnFDlQcRGA2(u"࠱࠱࠲࠱࠴ᔇ")*UAM4rBejpLyg9KaVFcG8JmEx71TZsH*LxNV5lenkhW6zoBJDMA7ZuqSg//Zj0n9wd37SDQXFkKeLyRI//rC5tnFDlQcRGA2(u"࠱࠱࠲࠱࠴ᔇ"))+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࠤࡒࡈࠧᄚ"))
			cDXLPHnAgY6NOk1GVStoiEx.close()
		OejfAMyHhNxYbXoRq6CuS3tlgz.close()
		if len(FFsQLVeqpYBaNOAojIbwy4)<WC7kstl2IgMbpNGh1uU86QjB and WC7kstl2IgMbpNGh1uU86QjB>ZVNvqy4iF1a9X:
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,XB4CjMkPFzhAHiI3q(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡩࡥ࡮ࡲࡥࡥࠢࡲࡶࠥࡩࡡ࡯ࡥࡨࡰࡪࡪࠠࡢࡶ࠽ࠤࡠࠦࠧᄛ")+str(len(FFsQLVeqpYBaNOAojIbwy4)//k0kxuL3BiKy2ePQfTcdM)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡆࡳࡱࡰࠤࡹࡵࡴࡢ࡮ࠣࡳ࡫ࡀࠠ࡜ࠢࠪᄜ")+ToYuiyRQ9tmZI0gzU3Cv7saP+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࠠࡎࡄࠣࡡࠬᄝ"))
			M9t6EHOwIr8cqy = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,GISOTJh20W(u"ࠧฦๆ฽หฦ่ࠦฯำ๋ะࠬᄞ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨษึฮำีวๆࠢส่๊๊แࠡษ็๊ฬ่ีࠨᄟ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠩศ฽ฬีษࠡฮ็ฬࠥอไๆๆไࠫᄠ"),TAExSfcoNi4eORZ8HPB,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧᄡ")+str(len(FFsQLVeqpYBaNOAojIbwy4)//k0kxuL3BiKy2ePQfTcdM)+Olh7n0zfV4(u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪᄢ")+ToYuiyRQ9tmZI0gzU3Cv7saP+cbmeD4WNZfAowxT2JdUMtV(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧᄣ"))
			if M9t6EHOwIr8cqy==VTadWjBloMwXO2CH9GDK6FR: FFsQLVeqpYBaNOAojIbwy4 = AznaIjR5kDMBf(fxnDkKpluQH,Dfi7FTuYWN49AaLEt3,showDialogs)
			elif M9t6EHOwIr8cqy==P2Fgh6TCOWoaHjkqBcQnvRNXe: JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,Olh7n0zfV4(u"࠭࠮࡝ࡶࡑࡳࡹࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡢࡥࡦࡩࡵࡺࡥࡥࠢࡤࡲࡩࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡶࡵࡨࡨࠬᄤ"))
			else: return CJlTSEpZsWb0QHg5w
			if not FFsQLVeqpYBaNOAojIbwy4: return CJlTSEpZsWb0QHg5w
		else: JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,XB4CjMkPFzhAHiI3q(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᄥ")+ToYuiyRQ9tmZI0gzU3Cv7saP+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࠢࡐࡆࠥࡣࠧᄦ"))
	return FFsQLVeqpYBaNOAojIbwy4
def pXz39eEyMQUh2SmwvOlgH(T1QDsJlUtCGhn):
	return cDXLPHnAgY6NOk1GVStoiEx
def Kmr20L5RiED9nOu1AGNa7WQUSle6(ip=CJlTSEpZsWb0QHg5w):
	if Ew2zQ8u7Ss.GEOLOCATION_DATA: return Ew2zQ8u7Ss.GEOLOCATION_DATA
	fYWRVZjOmNioql3LU9stnBKba,F087kSJl1WXD93VmP2gvUQtEKiAIL,EwrTPBeKZxkJFbC5vUSOAWIG46,R7hv1zysck,aobpDWRk2vXqF3IsAcPdZf9uO,j9yAkZUi6LY = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	otaunYGVIJ2jX8HsKm7ecR0bAh4 = otNfFapeEnO(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ࠬᄧ")+ip+XB4CjMkPFzhAHiI3q(u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨᄨ")
	Dfi7FTuYWN49AaLEt3 = {EcjO3giln2kQTdBY0XLAG(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᄩ"):CJlTSEpZsWb0QHg5w}
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡍࡅࡕࠩᄪ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,CJlTSEpZsWb0QHg5w,Dfi7FTuYWN49AaLEt3,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩᄫ"))
	if not cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		otaunYGVIJ2jX8HsKm7ecR0bAh4 = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲ࠰ࡥࡵ࡯࠮ࡤࡱࡰ࠳࡯ࡹ࡯࡯࠱ࠪᄬ")+ip+VVvcQpCU3OM09n(u"ࠨࡁࡩ࡭ࡪࡲࡤࡴ࠿ࡴࡹࡪࡸࡹ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠬࡤ࡫ࡷࡽ࠱ࡵࡦࡧࡵࡨࡸࠬᄭ")
		cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,JACnOz297UuDK5HpPkc1LF(u"ࠩࡊࡉ࡙࠭ᄮ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,CJlTSEpZsWb0QHg5w,Dfi7FTuYWN49AaLEt3,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠵ࡲࡩ࠭ᄯ"))
	if cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		bGIVq1CQTjmosZg = cDXLPHnAgY6NOk1GVStoiEx.content
		ebi4ZVu3IypcQfa5DKJjLsmHRPw = KSHcVmz2W84iQvbRDBhGldpCL.loads(bGIVq1CQTjmosZg)
		UCSOjbBuaPz = list(ebi4ZVu3IypcQfa5DKJjLsmHRPw.keys())
		if HaTI5u1f3SCxmMAkw(u"ࠫ࡮ࡶࠧᄰ") in UCSOjbBuaPz: ip = ebi4ZVu3IypcQfa5DKJjLsmHRPw[pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࡯ࡰࠨᄱ")]
		if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩᄲ") in UCSOjbBuaPz: fYWRVZjOmNioql3LU9stnBKba = ebi4ZVu3IypcQfa5DKJjLsmHRPw[E6xdOMpqISHZCn(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪᄳ")]
		if cjVhOCwybeRo7UWg92(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩᄴ") in UCSOjbBuaPz: F087kSJl1WXD93VmP2gvUQtEKiAIL = ebi4ZVu3IypcQfa5DKJjLsmHRPw[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᄵ")]
		if KA26GucUHOwXL(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩᄶ") in UCSOjbBuaPz: EwrTPBeKZxkJFbC5vUSOAWIG46 = ebi4ZVu3IypcQfa5DKJjLsmHRPw[cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪᄷ")]
		if zQGaM7ctZCN(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬᄸ") in UCSOjbBuaPz: R7hv1zysck = ebi4ZVu3IypcQfa5DKJjLsmHRPw[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ᄹ")]
		if GISOTJh20W(u"ࠧࡤ࡫ࡷࡽࠬᄺ") in UCSOjbBuaPz: aobpDWRk2vXqF3IsAcPdZf9uO = ebi4ZVu3IypcQfa5DKJjLsmHRPw[JACnOz297UuDK5HpPkc1LF(u"ࠨࡥ࡬ࡸࡾ࠭ᄻ")]
		if E6xdOMpqISHZCn(u"ࠩࡴࡹࡪࡸࡹࠨᄼ") in UCSOjbBuaPz: ip = ebi4ZVu3IypcQfa5DKJjLsmHRPw[GISOTJh20W(u"ࠪࡵࡺ࡫ࡲࡺࠩᄽ")]
		if ZP1LyUCS3pIBu(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩᄾ") in UCSOjbBuaPz: EwrTPBeKZxkJFbC5vUSOAWIG46 = ebi4ZVu3IypcQfa5DKJjLsmHRPw[Olh7n0zfV4(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧࠪᄿ")]
		if o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪᅀ") in UCSOjbBuaPz: R7hv1zysck = ebi4ZVu3IypcQfa5DKJjLsmHRPw[zQGaM7ctZCN(u"ࠧࡳࡧࡪ࡭ࡴࡴࡎࡢ࡯ࡨࠫᅁ")]
		if rC5tnFDlQcRGA2(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪᅂ") in UCSOjbBuaPz:
			j9yAkZUi6LY = ebi4ZVu3IypcQfa5DKJjLsmHRPw[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫᅃ")][XB4CjMkPFzhAHiI3q(u"ࠪࡹࡹࡩࠧᅄ")]
			if j9yAkZUi6LY[ZVNvqy4iF1a9X] not in [cbmeD4WNZfAowxT2JdUMtV(u"ࠫ࠲࠭ᅅ"),Olh7n0zfV4(u"ࠬ࠱ࠧᅆ")]: j9yAkZUi6LY = zQGaM7ctZCN(u"࠭ࠫࠨᅇ")+j9yAkZUi6LY
		if KA26GucUHOwXL(u"ࠧࡰࡨࡩࡷࡪࡺࠧᅈ") in UCSOjbBuaPz:
			j9yAkZUi6LY = ebi4ZVu3IypcQfa5DKJjLsmHRPw[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡱࡩࡪࡸ࡫ࡴࠨᅉ")]
			if j9yAkZUi6LY>=VVvcQpCU3OM09n(u"࠱ᔈ"): j9yAkZUi6LY = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩ࠮ࠫᅊ")+L8Wkv5KCSoq.strftime(XB4CjMkPFzhAHiI3q(u"ࠥࠩࡍࡀࠥࡎࠤᅋ"),L8Wkv5KCSoq.gmtime(j9yAkZUi6LY))
			else: j9yAkZUi6LY = JACnOz297UuDK5HpPkc1LF(u"ࠫ࠲࠭ᅌ")+L8Wkv5KCSoq.strftime(Olh7n0zfV4(u"ࠧࠫࡈ࠻ࠧࡐࠦᅍ"),L8Wkv5KCSoq.gmtime(-j9yAkZUi6LY))
	Y4QC7LMg0wFHa5 = ip+ZP1LyUCS3pIBu(u"࠭ࠬࠨᅎ")+fYWRVZjOmNioql3LU9stnBKba+rC5tnFDlQcRGA2(u"ࠧ࠭ࠩᅏ")+F087kSJl1WXD93VmP2gvUQtEKiAIL+JACnOz297UuDK5HpPkc1LF(u"ࠨ࠮ࠪᅐ")+R7hv1zysck+zQGaM7ctZCN(u"ࠩ࠯ࠫᅑ")+aobpDWRk2vXqF3IsAcPdZf9uO+TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࠰ࠬᅒ")+j9yAkZUi6LY
	Y4QC7LMg0wFHa5 = Y4QC7LMg0wFHa5.encode(Im5KSGZYBpRvdMVsbuXg)
	if A7Z6OVh20eCEUx: Y4QC7LMg0wFHa5 = Y4QC7LMg0wFHa5.decode(s97s2k0LJgl(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬᅓ"))
	Ew2zQ8u7Ss.GEOLOCATION_DATA = pd0Na8D5WZfHYkysVS(Y4QC7LMg0wFHa5)
	return Ew2zQ8u7Ss.GEOLOCATION_DATA
def oQYikwjnrKAcF29bR3WJPvEThfe(z52bpJkqDK8vnc3x6rEXWYs0BFtfH):
	SSafgo8AVTOJDn1F4Pidh,showDialogs = CJlTSEpZsWb0QHg5w,w2qb6lf5EM
	if z52bpJkqDK8vnc3x6rEXWYs0BFtfH.count(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡥࠧᅔ"))>=VTadWjBloMwXO2CH9GDK6FR:
		z52bpJkqDK8vnc3x6rEXWYs0BFtfH,SSafgo8AVTOJDn1F4Pidh = z52bpJkqDK8vnc3x6rEXWYs0BFtfH.split(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭࡟ࠨᅕ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)
		SSafgo8AVTOJDn1F4Pidh = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡠࠩᅖ")+SSafgo8AVTOJDn1F4Pidh
		if TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭ᅗ") in SSafgo8AVTOJDn1F4Pidh: showDialogs = VJZIMkUN5siqB21Pf
		else: showDialogs = w2qb6lf5EM
	return z52bpJkqDK8vnc3x6rEXWYs0BFtfH,SSafgo8AVTOJDn1F4Pidh,showDialogs
def lchsgL4CQNIGP1XOzDF():
	eA6xXb1QGDif = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,yylSaxCLfkte(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨᅘ"))
	RNVQf1xjTKka = ZVNvqy4iF1a9X
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(eA6xXb1QGDif):
		for N4jmWQledskOFctof in tiFgl4DMvGEAUfjIYkHbr05.listdir(eA6xXb1QGDif):
			if JACnOz297UuDK5HpPkc1LF(u"ࠪ࠲ࡵࡿ࡯ࠨᅙ") in N4jmWQledskOFctof: continue
			if pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡤࡥࡰࡺࡥࡤࡧ࡭࡫࡟ࡠࠩᅚ") in N4jmWQledskOFctof: continue
			SJpuo5RyUOmY1sZXN2HGM = tiFgl4DMvGEAUfjIYkHbr05.path.join(eA6xXb1QGDif,N4jmWQledskOFctof)
			jLMUKcNImsv6TbYh4lyxX21,InaYgGyu8qjsp1lOAbe4rKWVz = hhA3ineut0C1(SJpuo5RyUOmY1sZXN2HGM)
			RNVQf1xjTKka += jLMUKcNImsv6TbYh4lyxX21
	return RNVQf1xjTKka
def CxIlGtFjUNru3Q(showDialogs):
	RYP9ZBSnAlwHE1y7umcpKb = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪᅛ"))
	OODYl8Sf1JjgWoTF = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,cjVhOCwybeRo7UWg92(u"࠭ࡳࡵࡴࠪᅜ"),E6xdOMpqISHZCn(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬᅝ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᅞ"))
	H03vyMjGLueotaWpiDQmqn9rc,yWTZXOr5DtbkmMqcAa8PwdxjU3BY = RYP9ZBSnAlwHE1y7umcpKb,OODYl8Sf1JjgWoTF
	TD8Gzp7UroCWkFb,HFPeq9Bn4tYlGkS5RWvcxgiJsKNd = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	if JACnOz297UuDK5HpPkc1LF(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫᅟ") not in str(Ew2zQ8u7Ss.SEND_THESE_EVENTS):
		otaunYGVIJ2jX8HsKm7ecR0bAh4 = Ew2zQ8u7Ss.SITESURLS[O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᅠ")][D9yBM7wPFLz]
		BLjoYe9GRiaWgluTk36p = Kmr20L5RiED9nOu1AGNa7WQUSle6()
		F087kSJl1WXD93VmP2gvUQtEKiAIL = BLjoYe9GRiaWgluTk36p.split(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ࠱࠭ᅡ"))[VTadWjBloMwXO2CH9GDK6FR]
		RNVQf1xjTKka = lchsgL4CQNIGP1XOzDF()
		cl6ybZFW7O0 = {o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡻࡳࡦࡴࠪᅢ"):Ew2zQ8u7Ss.AV_CLIENT_IDS,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧᅣ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᅤ"):F087kSJl1WXD93VmP2gvUQtEKiAIL,zQGaM7ctZCN(u"ࠨ࡫ࡧࡷࠬᅥ"):U2SFOzhqClfsiu36P1j0YGrcx7d(RNVQf1xjTKka)}
		cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡓࡓࡘ࡚ࠧᅦ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,cl6ybZFW7O0,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧᅧ"))
		if not cDXLPHnAgY6NOk1GVStoiEx.succeeded:
			if RYP9ZBSnAlwHE1y7umcpKb in [CJlTSEpZsWb0QHg5w,E6xdOMpqISHZCn(u"ࠫࡓࡋࡗࠨᅨ")]: H03vyMjGLueotaWpiDQmqn9rc = cjVhOCwybeRo7UWg92(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫᅩ")
			elif RYP9ZBSnAlwHE1y7umcpKb==mi2ZJXCDzITuyev6gfn(u"࠭ࡏࡍࡆࠪᅪ"): H03vyMjGLueotaWpiDQmqn9rc = s97s2k0LJgl(u"ࠧࡐࡎࡇࡣ࡙ࡕ࡟ࡆࡔࡕࡓࡗ࠭ᅫ")
		else:
			WWR73QsDLryCe8tiIAq1ZoxTmgXOk4 = cDXLPHnAgY6NOk1GVStoiEx.content
			WWR73QsDLryCe8tiIAq1ZoxTmgXOk4 = oE7iT3HI5VDdmY4kPOjr(Olh7n0zfV4(u"ࠨ࡮࡬ࡷࡹ࠭ᅬ"),WWR73QsDLryCe8tiIAq1ZoxTmgXOk4)
			WWR73QsDLryCe8tiIAq1ZoxTmgXOk4 = sorted(WWR73QsDLryCe8tiIAq1ZoxTmgXOk4,reverse=w2qb6lf5EM,key=lambda key: int(key[ZVNvqy4iF1a9X]))
			HFPeq9Bn4tYlGkS5RWvcxgiJsKNd,yWTZXOr5DtbkmMqcAa8PwdxjU3BY = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
			for lqzgM1rLchVwKaCx3Q,aWydti159CkZ3fS,sBbvqgYCaSP50 in WWR73QsDLryCe8tiIAq1ZoxTmgXOk4:
				if lqzgM1rLchVwKaCx3Q==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩ࠳ࠫᅭ"):
					HFPeq9Bn4tYlGkS5RWvcxgiJsKNd += sBbvqgYCaSP50+s97s2k0LJgl(u"ࠪ࠾࠿࠭ᅮ")
					continue
				if yWTZXOr5DtbkmMqcAa8PwdxjU3BY: yWTZXOr5DtbkmMqcAa8PwdxjU3BY += rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+GISOTJh20W(u"ࠫࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᅯ")+oOQaRxBXyJ5jVnZ+Olh7n0zfV4(u"ࠬࡢ࡮࡝ࡰࠪᅰ")
				qLyDNUlmdj6OXzKoai = sBbvqgYCaSP50.split(rJ9cgWz4FU)[ZVNvqy4iF1a9X]
				DxI7qsWPzOXa4HflAE = zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ัิษ็อࠥิวึห่่ࠣࠦแใูࠪᅱ") if aWydti159CkZ3fS else CJlTSEpZsWb0QHg5w
				yWTZXOr5DtbkmMqcAa8PwdxjU3BY += sBbvqgYCaSP50.replace(qLyDNUlmdj6OXzKoai,Ym6q5M4TocDaA013RjFQ+qLyDNUlmdj6OXzKoai+DxI7qsWPzOXa4HflAE+oOQaRxBXyJ5jVnZ)+rJ9cgWz4FU
			yWTZXOr5DtbkmMqcAa8PwdxjU3BY = rJ9cgWz4FU+yWTZXOr5DtbkmMqcAa8PwdxjU3BY+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࡝ࡰ࡟ࡲࠬᅲ")
			HFPeq9Bn4tYlGkS5RWvcxgiJsKNd = HFPeq9Bn4tYlGkS5RWvcxgiJsKNd.strip(yylSaxCLfkte(u"ࠨ࠼࠽ࠫᅳ"))
			TD8Gzp7UroCWkFb = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(Olh7n0zfV4(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬᅴ"))
			if yWTZXOr5DtbkmMqcAa8PwdxjU3BY==OODYl8Sf1JjgWoTF and RYP9ZBSnAlwHE1y7umcpKb in [zQGaM7ctZCN(u"ࠪࡓࡑࡊࠧᅵ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᅶ")]: H03vyMjGLueotaWpiDQmqn9rc = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡕࡌࡅࠩᅷ")
			else: H03vyMjGLueotaWpiDQmqn9rc = GISOTJh20W(u"࠭ࡎࡆ࡙ࠪᅸ")
			JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠵ࠬᅹ"),KA26GucUHOwXL(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᅺ"),yWTZXOr5DtbkmMqcAa8PwdxjU3BY,XlNnqz758Zeuo)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪᅻ"),U2SFOzhqClfsiu36P1j0YGrcx7d(U6YgVKS9rAmwe1RTPlQnfiGs))
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(E6xdOMpqISHZCn(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠶࠭ᅼ"),HFPeq9Bn4tYlGkS5RWvcxgiJsKNd)
			DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(JACnOz297UuDK5HpPkc1LF(u"࠷ᔉ")*HFPeq9Bn4tYlGkS5RWvcxgiJsKNd.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()
			DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(zQGaM7ctZCN(u"࠴࠸ᔊ")*DajqVM3ptOGR6Cr2KyQoSYw.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()
			DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠵࠾ᔋ")*DajqVM3ptOGR6Cr2KyQoSYw.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()
			PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN = JEAtPbO4MULFdGCVWcHwp0SQ6(NN4DuIqLH9iGesZocawQTUWm0E)
			ODLnpGUNsgx6(NN4DuIqLH9iGesZocawQTUWm0E,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡡ࡬ࡨࡂ࠭ᅽ")+str(int(DajqVM3ptOGR6Cr2KyQoSYw[EcjO3giln2kQTdBY0XLAG(u"࠹ᔍ"):cjVhOCwybeRo7UWg92(u"࠱࠳ᔎ")],TDpFsQXHze2q30uYtGPfEIm8(u"࠲࠸ᔏ")))[:GISOTJh20W(u"࠾ᔌ")]+KA26GucUHOwXL(u"ࠬࠦ࠻ࠨᅾ"))
			PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
		wbYZiJ5pjQFTLUBWV472 = w2qb6lf5EM if HFPeq9Bn4tYlGkS5RWvcxgiJsKNd!=TD8Gzp7UroCWkFb else VJZIMkUN5siqB21Pf
		if wbYZiJ5pjQFTLUBWV472:
			R3kmvGJNxDICS81Lrw = Ew2zQ8u7Ss.wsrSnHQfOWm8
			Ew2zQ8u7Ss.wpBxtqcsDEafMFkToIXe,Ew2zQ8u7Ss.wsrSnHQfOWm8,Ew2zQ8u7Ss.QFCWcArusifVavlYk29,Ew2zQ8u7Ss.krgh8yUEqa,Ew2zQ8u7Ss.avprivsnorestrict,Ew2zQ8u7Ss.avprivslongperiod = ed1Dvp6KAOcY2lFNzgm5t4ifE0h8([GISOTJh20W(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧᅿ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨᆀ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭ᆁ"),XB4CjMkPFzhAHiI3q(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪᆂ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘ࡯ࡱࡊࡖࡆࡘࡈ࡜ࠬᆃ"),EcjO3giln2kQTdBY0XLAG(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪᆄ")])
			YqG0j893LFmHRsBQu = Ew2zQ8u7Ss.wsrSnHQfOWm8
			if not R3kmvGJNxDICS81Lrw and YqG0j893LFmHRsBQu and zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙࡟ࡕࡕࠪᆅ") in Ew2zQ8u7Ss.SEND_THESE_EVENTS:
				Ew2zQ8u7Ss.SEND_THESE_EVENTS.remove(O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࡠࡖࡖࠫᆆ"))
				Ew2zQ8u7Ss.SEND_THESE_EVENTS.append(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩᆇ"))
			elif R3kmvGJNxDICS81Lrw and not YqG0j893LFmHRsBQu and TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪᆈ") in Ew2zQ8u7Ss.SEND_THESE_EVENTS:
				Ew2zQ8u7Ss.SEND_THESE_EVENTS.remove(E6xdOMpqISHZCn(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫᆉ"))
				Ew2zQ8u7Ss.SEND_THESE_EVENTS.append(rC5tnFDlQcRGA2(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗࡤ࡚ࡓࠨᆊ"))
			nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	if showDialogs:
		if H03vyMjGLueotaWpiDQmqn9rc in [zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪᆋ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫᆌ")]:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋ࠢ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ࠴࠮้ࠡำ๋ࠥอไๆึๆ่ฮࠦโะࠢํ็ํ์ࠠิสห๋ฬࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣวํࠦวๅำส์ฯืࠠศๆัหฺࠦศไࠢฦ์๋ࠥิไๆฬࠤๆ๐ࠠศๆฦื้อใࠡ฻้ำ่࠭ᆍ"))
		else:
			hQbEaPTN5tnZfArRuWDcY(cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭ᆎ"),yylSaxCLfkte(u"ࠨำึหห๊ࠠๆ่ࠣห้๋ศา็ฯࠤส๊้ࠡ็ึฮำีๅ๋ࠢส่อืๆศ็ฯࠫᆏ"),yWTZXOr5DtbkmMqcAa8PwdxjU3BY,yylSaxCLfkte(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪᆐ"))
			H03vyMjGLueotaWpiDQmqn9rc = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡓࡑࡊࠧᆑ")
	if H03vyMjGLueotaWpiDQmqn9rc!=RYP9ZBSnAlwHE1y7umcpKb:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(JACnOz297UuDK5HpPkc1LF(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩᆒ"),H03vyMjGLueotaWpiDQmqn9rc)
		nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def T83nMhxrkQRWmsoIeZJ7g(wYIMiDTnadBgA,ePtg1W7SBMXR8L):
	import socket as lybrJX1W94gjOzT2qpH
	C90zDgIkV6fumMNRr3ZYlesK2XW = lybrJX1W94gjOzT2qpH.socket(lybrJX1W94gjOzT2qpH.AF_INET,lybrJX1W94gjOzT2qpH.SOCK_STREAM)
	C90zDgIkV6fumMNRr3ZYlesK2XW.settimeout(D9yBM7wPFLz)
	try:
		kc4BtgWCFLJ5yGRVZzuX1eni20 = L8Wkv5KCSoq.time()
		C90zDgIkV6fumMNRr3ZYlesK2XW.connect((wYIMiDTnadBgA,ePtg1W7SBMXR8L))
		GdXS7k358z1f0unQtbOg = L8Wkv5KCSoq.time()
		Gm84MFs0UlA9Ze5BzLwith = round((GdXS7k358z1f0unQtbOg-kc4BtgWCFLJ5yGRVZzuX1eni20)*ZP1LyUCS3pIBu(u"࠳࠳࠴࠵ᔐ"))
	except: Gm84MFs0UlA9Ze5BzLwith = -P2Fgh6TCOWoaHjkqBcQnvRNXe
	C90zDgIkV6fumMNRr3ZYlesK2XW.close()
	return Gm84MFs0UlA9Ze5BzLwith
def Cdyun4OtYjmFGHTzaW6rKwf9bg3Jsq(showDialogs):
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,o2FdrDBimMuOw97q6QpNW8S(u"ู่ࠬโࠢํๆํ๋ࠠศๆหี๋อๅอࠢส่ว์ࠠษวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠠ࠯࠰๋้ࠣࠦสา์าࠤฯฺฺ๋ๆࠣ฽๊๊๊สࠢส่ฯ์ุ๋ใࠣห้ศๆࠡมࠤࠫᆓ"))
	else: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = w2qb6lf5EM
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		for N4jmWQledskOFctof in tiFgl4DMvGEAUfjIYkHbr05.listdir(c2XOIv1RU6aSuAeiZ5Pgz9Gr):
			if N4jmWQledskOFctof.endswith(cbmeD4WNZfAowxT2JdUMtV(u"࠭࠮ࡥࡤࠪᆔ")) and HaTI5u1f3SCxmMAkw(u"ࠧࡥࡣࡷࡥࠬᆕ") in N4jmWQledskOFctof:
				bzL2p4JPBl8FjcAZuieUTwNIk0 = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,N4jmWQledskOFctof)
				PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN = JEAtPbO4MULFdGCVWcHwp0SQ6(bzL2p4JPBl8FjcAZuieUTwNIk0)
				CUYvKkg403sS1yxGoTbWDhJAXN.execute(zQGaM7ctZCN(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡨࡲࡶࡪ࡯ࡧ࡯ࡡ࡮ࡩࡾࡹ࠽࡯ࡱ࠾ࠫᆖ"))
				CUYvKkg403sS1yxGoTbWDhJAXN.execute(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡓࡖࡆࡍࡍࡂࠢࡷࡩࡲࡶ࡟ࡴࡶࡲࡶࡪࡃࡍࡆࡏࡒࡖ࡞ࡁࠧᆗ"))
				CUYvKkg403sS1yxGoTbWDhJAXN.execute(GISOTJh20W(u"ࠪࡔࡗࡇࡇࡎࡃࠣ࡭ࡳࡺࡥࡨࡴ࡬ࡸࡾࡥࡣࡩࡧࡦ࡯ࡀ࠭ᆘ"))
				CUYvKkg403sS1yxGoTbWDhJAXN.execute(VVvcQpCU3OM09n(u"ࠫࡕࡘࡁࡈࡏࡄࠤࡴࡶࡴࡪ࡯࡬ࡾࡪࡁࠧᆙ"))
				CUYvKkg403sS1yxGoTbWDhJAXN.execute(s97s2k0LJgl(u"ࠬ࡜ࡁࡄࡗࡘࡑࡀ࠭ᆚ"))
				PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.commit()
				PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧᆛ"))
	return
def BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(Gd4NCj3eDmngrfQ2U7,PYO4bZ1dsHJuwVSU,showDialogs):
	if Gd4NCj3eDmngrfQ2U7!=RFb4YfvJSsWCy7Z0:
		if Gd4NCj3eDmngrfQ2U7==kbtm6wfFgoXpICs: Ew2zQ8u7Ss.ALLOW_DNS_FIX = w2qb6lf5EM
		elif Gd4NCj3eDmngrfQ2U7==uSo1OXy4h6xJvmAVfB3TEY: Ew2zQ8u7Ss.ALLOW_DNS_FIX = VJZIMkUN5siqB21Pf
		elif Gd4NCj3eDmngrfQ2U7==DnruJV9OfB70TSdt1zcCsWl3wFMI8E: Ew2zQ8u7Ss.ALLOW_DNS_FIX = w2qb6lf5EM
	if PYO4bZ1dsHJuwVSU!=RFb4YfvJSsWCy7Z0:
		if PYO4bZ1dsHJuwVSU==kbtm6wfFgoXpICs: Ew2zQ8u7Ss.ALLOW_PROXY_FIX = w2qb6lf5EM
		elif PYO4bZ1dsHJuwVSU==uSo1OXy4h6xJvmAVfB3TEY: Ew2zQ8u7Ss.ALLOW_PROXY_FIX = VJZIMkUN5siqB21Pf
		elif PYO4bZ1dsHJuwVSU==DnruJV9OfB70TSdt1zcCsWl3wFMI8E: Ew2zQ8u7Ss.ALLOW_PROXY_FIX = w2qb6lf5EM
	if showDialogs!=RFb4YfvJSsWCy7Z0:
		if showDialogs==kbtm6wfFgoXpICs: Ew2zQ8u7Ss.ALLOW_SHOWDIALOGS_FIX = w2qb6lf5EM
		elif showDialogs==uSo1OXy4h6xJvmAVfB3TEY: Ew2zQ8u7Ss.ALLOW_SHOWDIALOGS_FIX = VJZIMkUN5siqB21Pf
		elif showDialogs==DnruJV9OfB70TSdt1zcCsWl3wFMI8E: Ew2zQ8u7Ss.ALLOW_SHOWDIALOGS_FIX = w2qb6lf5EM
	return
def hyMjPsHUx1BCWT2v4k(website,VUajfbP8AXsxq9rv2hJYnLIgSNFy0,CBLQarT4XP=gZvlfk6xhACbXcD5j0KBLiVM1):
	DK2TngCBbZdmPoJl5uwS = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠴࠴ᔑ")
	fhloE1P2H70mFQOL8GvdbwjrCARtD3 = [HaTI5u1f3SCxmMAkw(u"࠵ᔒ"),HaTI5u1f3SCxmMAkw(u"࠵ᔒ"),HaTI5u1f3SCxmMAkw(u"࠵ᔒ"),XB4CjMkPFzhAHiI3q(u"࠶࠶ᔓ"),EcjO3giln2kQTdBY0XLAG(u"࠻ᔔ"),XB4CjMkPFzhAHiI3q(u"࠶࠶ᔓ"),HaTI5u1f3SCxmMAkw(u"࠵ᔒ"),HaTI5u1f3SCxmMAkw(u"࠵ᔒ"),HaTI5u1f3SCxmMAkw(u"࠵ᔒ"),EcjO3giln2kQTdBY0XLAG(u"࠻ᔔ")]
	Qb7BXESKVdGortMcp58N0IskiaDJe = []
	AbsXEkoIYSJy0P4 = [pz4WBwfyDdgk0m2aRr7SMv(u"࠰ᔕ")]*DK2TngCBbZdmPoJl5uwS
	u18XtU6MERCnj3Lyh2Nepl = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,VVvcQpCU3OM09n(u"ࠧࡥ࡫ࡦࡸࠬᆜ"),s97s2k0LJgl(u"ࠨࡕࡆࡖࡆࡖࡅࡓࡕࡢࡗ࡙ࡇࡔࡖࡕࠪᆝ"))
	for NZzVJ8h0cn1dauAvS in list(u18XtU6MERCnj3Lyh2Nepl.keys()):
		if website not in NZzVJ8h0cn1dauAvS: continue
		ad3z2451e09FrDHmvci,DO5nAEHi4SIoFuLr2GQwyKPt = NZzVJ8h0cn1dauAvS.split(E6xdOMpqISHZCn(u"ࠩࡢࡣࠬᆞ"))
		AbsXEkoIYSJy0P4[int(DO5nAEHi4SIoFuLr2GQwyKPt)] = u18XtU6MERCnj3Lyh2Nepl[NZzVJ8h0cn1dauAvS]
	for lljAD6u8pm13sXYRJgvPQKB5 in range(DK2TngCBbZdmPoJl5uwS):
		if lljAD6u8pm13sXYRJgvPQKB5 in Ew2zQ8u7Ss.BADSCRAPERS+VUajfbP8AXsxq9rv2hJYnLIgSNFy0: continue
		if lljAD6u8pm13sXYRJgvPQKB5==CBLQarT4XP: AbsXEkoIYSJy0P4[lljAD6u8pm13sXYRJgvPQKB5] = AbsXEkoIYSJy0P4[lljAD6u8pm13sXYRJgvPQKB5]+TDpFsQXHze2q30uYtGPfEIm8(u"࠲ᔖ")
		if AbsXEkoIYSJy0P4[lljAD6u8pm13sXYRJgvPQKB5]<rC5tnFDlQcRGA2(u"࠵ᔗ"): Qb7BXESKVdGortMcp58N0IskiaDJe += [lljAD6u8pm13sXYRJgvPQKB5]*fhloE1P2H70mFQOL8GvdbwjrCARtD3[lljAD6u8pm13sXYRJgvPQKB5]
	if not Qb7BXESKVdGortMcp58N0IskiaDJe:
		for lljAD6u8pm13sXYRJgvPQKB5 in range(DK2TngCBbZdmPoJl5uwS):
			AbsXEkoIYSJy0P4[lljAD6u8pm13sXYRJgvPQKB5] = otNfFapeEnO(u"࠳ᔘ")
			if lljAD6u8pm13sXYRJgvPQKB5 in Ew2zQ8u7Ss.BADSCRAPERS+VUajfbP8AXsxq9rv2hJYnLIgSNFy0: continue
			Qb7BXESKVdGortMcp58N0IskiaDJe += [lljAD6u8pm13sXYRJgvPQKB5]*fhloE1P2H70mFQOL8GvdbwjrCARtD3[lljAD6u8pm13sXYRJgvPQKB5]
	for lljAD6u8pm13sXYRJgvPQKB5 in Ew2zQ8u7Ss.BADSCRAPERS: AbsXEkoIYSJy0P4[lljAD6u8pm13sXYRJgvPQKB5] = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠽࠾࠿࠹ᔙ")
	plE3WomA8r9nwhgUPZTIaGs5f7MR = []
	for lljAD6u8pm13sXYRJgvPQKB5 in range(DK2TngCBbZdmPoJl5uwS): plE3WomA8r9nwhgUPZTIaGs5f7MR.append(website+KA26GucUHOwXL(u"ࠪࡣࡤ࠭ᆟ")+str(lljAD6u8pm13sXYRJgvPQKB5))
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,XB4CjMkPFzhAHiI3q(u"ࠫࡘࡉࡒࡂࡒࡈࡖࡘࡥࡓࡕࡃࡗ࡙ࡘ࠭ᆠ"),plE3WomA8r9nwhgUPZTIaGs5f7MR,AbsXEkoIYSJy0P4,zKrxu3m2blLZ1QkyCd*CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠺ᔚ"),w2qb6lf5EM)
	return Qb7BXESKVdGortMcp58N0IskiaDJe
def epDHqUwf9S4RAC6h3Yd8LsPVb(por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,JsDZ0f79iTWLY412v5Ejl=CJlTSEpZsWb0QHg5w,j6h5EvtgIqUrYcKwl91p7RCJm4i=CJlTSEpZsWb0QHg5w,VUajfbP8AXsxq9rv2hJYnLIgSNFy0=[]):
	website = nqVYufmd4GFshQeHO9vp05.split(cjVhOCwybeRo7UWg92(u"ࠬ࠳ࠧᆡ"))[ZVNvqy4iF1a9X]
	AAYdNKMXps6JDPFHgz7S = hyMjPsHUx1BCWT2v4k(website,VUajfbP8AXsxq9rv2hJYnLIgSNFy0)
	cKBL8AkYTtC = []
	if website==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᆢ"):
		if ZVNvqy4iF1a9X in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [ZVNvqy4iF1a9X]
		if P2Fgh6TCOWoaHjkqBcQnvRNXe in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P2Fgh6TCOWoaHjkqBcQnvRNXe]
		if VTadWjBloMwXO2CH9GDK6FR in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [VTadWjBloMwXO2CH9GDK6FR]
		if D9yBM7wPFLz in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [D9yBM7wPFLz]*TMfV6892ZoBdyxCH3tGrkwY0K(u"࠷࠰ᔛ")
		if P3cpaLN2sH in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P3cpaLN2sH]*GGsP9SDod4iUBm6kNMfLw
		if GGsP9SDod4iUBm6kNMfLw in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [GGsP9SDod4iUBm6kNMfLw]*yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠱࠱ᔜ")
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷ᔝ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷ᔝ")]
		if XB4CjMkPFzhAHiI3q(u"࠹ᔞ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [XB4CjMkPFzhAHiI3q(u"࠹ᔞ")]
	elif website==mi2ZJXCDzITuyev6gfn(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᆣ"):
		if D9yBM7wPFLz in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [D9yBM7wPFLz]*cjVhOCwybeRo7UWg92(u"࠴࠴ᔟ")
	elif website==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡅࡌࡑࡆࡒࡉࡈࡊࡗࠫᆤ"):
		if P3cpaLN2sH in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P3cpaLN2sH]*GGsP9SDod4iUBm6kNMfLw
		if GGsP9SDod4iUBm6kNMfLw in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [GGsP9SDod4iUBm6kNMfLw]*rC5tnFDlQcRGA2(u"࠵࠵ᔠ")
	elif website==Olh7n0zfV4(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪᆥ"):
		if h6sIkJOT5PB2vCxqo4LFag70wA(u"࠾ᔡ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [h6sIkJOT5PB2vCxqo4LFag70wA(u"࠾ᔡ")]*o2FdrDBimMuOw97q6QpNW8S(u"࠷࠰ᔢ")
	elif website==zz679V18GdcZwvrRexA0nNptY2Tab(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫᆦ"):
		if P2Fgh6TCOWoaHjkqBcQnvRNXe in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P2Fgh6TCOWoaHjkqBcQnvRNXe]
		if GGsP9SDod4iUBm6kNMfLw in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [GGsP9SDod4iUBm6kNMfLw]*HaTI5u1f3SCxmMAkw(u"࠱࠱ᔣ")
	elif website==pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡌࡕࡏࡈࡎࡈࡗࡊࡇࡒࡄࡊࠪᆧ"):
		if P3cpaLN2sH in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P3cpaLN2sH]*GGsP9SDod4iUBm6kNMfLw
	elif website==ZP1LyUCS3pIBu(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ᆨ"):
		if GGsP9SDod4iUBm6kNMfLw in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [GGsP9SDod4iUBm6kNMfLw]*pz4WBwfyDdgk0m2aRr7SMv(u"࠲࠲ᔤ")
		if yUMRP0QKIzY9BDnsV784TZmwkf(u"࠸ᔥ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [yUMRP0QKIzY9BDnsV784TZmwkf(u"࠸ᔥ")]
		if yylSaxCLfkte(u"࠺ᔦ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [yylSaxCLfkte(u"࠺ᔦ")]
		if VVvcQpCU3OM09n(u"࠼ᔧ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [VVvcQpCU3OM09n(u"࠼ᔧ")]
	elif website==JACnOz297UuDK5HpPkc1LF(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨᆩ"):
		if JACnOz297UuDK5HpPkc1LF(u"࠻ᔨ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [JACnOz297UuDK5HpPkc1LF(u"࠻ᔨ")]
		if E6xdOMpqISHZCn(u"࠽ᔩ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [E6xdOMpqISHZCn(u"࠽ᔩ")]
	elif website==pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩᆪ"):
		if P2Fgh6TCOWoaHjkqBcQnvRNXe in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P2Fgh6TCOWoaHjkqBcQnvRNXe]
		if P3cpaLN2sH in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [P3cpaLN2sH]*GGsP9SDod4iUBm6kNMfLw
		if GGsP9SDod4iUBm6kNMfLw in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [GGsP9SDod4iUBm6kNMfLw]*yUMRP0QKIzY9BDnsV784TZmwkf(u"࠱࠱ᔪ")
		if yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠷ᔫ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠷ᔫ")]
		if KA26GucUHOwXL(u"࠹ᔬ") in AAYdNKMXps6JDPFHgz7S: cKBL8AkYTtC += [KA26GucUHOwXL(u"࠹ᔬ")]
	if cKBL8AkYTtC: AAYdNKMXps6JDPFHgz7S = cKBL8AkYTtC
	if AAYdNKMXps6JDPFHgz7S:
		HSX3aeuwf5LNGEU7RWV = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(AAYdNKMXps6JDPFHgz7S,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
	else: HSX3aeuwf5LNGEU7RWV = -P2Fgh6TCOWoaHjkqBcQnvRNXe
	glcHUZI8YGupfz5T7oK3nxdRbrWt = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨีํีๆืࠠาไ่ࠤࠬᆫ")+str(HSX3aeuwf5LNGEU7RWV)
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+XB4CjMkPFzhAHiI3q(u"ࠩࠣࠤ࡚ࠥࡲࡺ࡫ࡱ࡫ࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ᆬ")+str(HSX3aeuwf5LNGEU7RWV)+otNfFapeEnO(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᆭ")+str(JsDZ0f79iTWLY412v5Ejl)+o2FdrDBimMuOw97q6QpNW8S(u"ࠫࠥࡣࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᆮ")+j6h5EvtgIqUrYcKwl91p7RCJm4i+yylSaxCLfkte(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᆯ")+nqVYufmd4GFshQeHO9vp05+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࠠ࡞࡙ࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᆰ")+BBwfuWGxUIrdCoc4ka7+GISOTJh20W(u"ࠧࠡ࡟ࠪᆱ"))
	update = w2qb6lf5EM
	if HSX3aeuwf5LNGEU7RWV==ZVNvqy4iF1a9X:
		scraperserver = cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠵ࠬᆲ")
		aRvnqWUHML5QS = o2FdrDBimMuOw97q6QpNW8S(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠱࠶࠲ࡧ࠶࠷࡬࠱࠮ࡥ࠸࠼ࡦ࠳࠴࠱࠴࠴࠱ࡦࡧ࠸࠵࠯ࡨ࠽࠷࠹ࡣࡢࡨ࠻࠹࠽࠹࠴ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫᆳ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+mi2ZJXCDzITuyev6gfn(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᆴ")+aRvnqWUHML5QS+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᆵ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		scraperserver = XB4CjMkPFzhAHiI3q(u"ࠬࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠳ࠩᆶ")
		aRvnqWUHML5QS = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡵࡰࡴ࠰࡮ࡩࡪࡶ࡟ࡩࡧࡤࡨࡪࡸࡳ࠾ࡖࡵࡹࡪ࠴ࡣࡰࡷࡱࡸࡷࡿ࠽ࡪ࡮࠽࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠽࠹࠸࠻࠳ࠨᆷ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+otNfFapeEnO(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᆸ")+aRvnqWUHML5QS+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᆹ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==VTadWjBloMwXO2CH9GDK6FR:
		scraperserver = o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡶࡧࡷࡧࡰࡦࡴࡤࡴ࡮࠭ᆺ")
		aRvnqWUHML5QS = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮࡬ࡧࡨࡴࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠲ࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࡀ࡭ࡱࡀ࠷࠷ࡤ࠷ࡪࡨ࠹࠴ࡧࡥࡧ࠵࠾ࡪ࠹ࡤ࠷࠸ࡥ࠶࠻ࡦ࠴࠸࠳࠸ࡨࡪ࠹࠲࠶ࡦࡄࡵࡸ࡯ࡹࡻ࠰ࡷࡪࡸࡶࡦࡴ࠱ࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯࠮ࡤࡱࡰ࠾࠽࠶࠰࠲ࠩᆻ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᆼ")+aRvnqWUHML5QS+mi2ZJXCDzITuyev6gfn(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᆽ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==D9yBM7wPFLz:
		scraperserver = E6xdOMpqISHZCn(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨᆾ")
		ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7.replace(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩᆿ"),s97s2k0LJgl(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩᇀ"))
		Da7e1Ruo9G = cbmeD4WNZfAowxT2JdUMtV(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡴ࡮࠴ࡳࡤࡴࡤࡴࡪࡻࡰ࠯ࡥࡲࡱ࠴ࡅࡡࡱ࡫ࡢ࡯ࡪࡿ࠽࠲ࡘࡑࡷࡒࡺࡌ࠲ࡱࡅࡖ࡝ࡱࡓࡏࡅࡥࡇࡒࡐ࠱ࡌ࡚࡜ࡎ࡯ࡰ࠰ࡥ࡬࡝ࡻࠫࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁࡋࡧ࡬ࡴࡧࠩࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦ࠿࡬ࡰࠫࡻࡲ࡭࠿ࠪᇁ")+O4Ak3NXpyUHvE(ysw7G3tqjo)
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(cjVhOCwybeRo7UWg92(u"ࠪࡋࡊ࡚ࠧᇂ"),Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==P3cpaLN2sH:
		scraperserver = JACnOz297UuDK5HpPkc1LF(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡸ࡯ࡣࡱࡷࠫᇃ")
		Da7e1Ruo9G = O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡪࡰࡪࡶࡴࡨ࡯ࡵ࠰ࡦࡳࡲ࠵࠿ࡵࡱ࡮ࡩࡳࡃࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠧࡲࡵࡳࡽࡿࡃࡰࡷࡱࡸࡷࡿ࠽ࡊࡎࠩࡹࡷࡲ࠽ࠨᇄ")+O4Ak3NXpyUHvE(BBwfuWGxUIrdCoc4ka7)
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡇࡆࡖࠪᇅ"),Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
		try:
			APzlpyC4ehQWRid9.content = oE7iT3HI5VDdmY4kPOjr(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡥ࡫ࡦࡸࠬᇆ"),APzlpyC4ehQWRid9.content)
			APzlpyC4ehQWRid9.content = APzlpyC4ehQWRid9.content[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡴࡨࡷࡺࡲࡴࠨᇇ")]
		except: pass
	elif HSX3aeuwf5LNGEU7RWV==GGsP9SDod4iUBm6kNMfLw:
		scraperserver = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺ࠱ࠨᇈ")
		aRvnqWUHML5QS = cjVhOCwybeRo7UWg92(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴࠧࡲࡵࡳࡽࡿ࡟ࡤࡱࡸࡲࡹࡸࡹ࠾ࡋࡏࠪࡧࡸ࡯ࡸࡵࡨࡶࡂࡌࡡ࡭ࡵࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨᇉ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇊ")+aRvnqWUHML5QS+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇋ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==ZP1LyUCS3pIBu(u"࠹ᔭ"):
		scraperserver = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠳ࠪᇌ")
		aRvnqWUHML5QS = JACnOz297UuDK5HpPkc1LF(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡥ࠵࠺࠸ࡧࡢ࠲ࡧ࠸࠴࠹࠺ࡤ࠳ࡥࡤ࠹ࡩ࠻ࡤ࠴ࡨ࠼ࡩ࠸ࡩ࠳࠹࠸ࡨࡧࡦ࠷࠱࠱࠺࠶࠼࠾ࡧ࠷࠴࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫᇍ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+KA26GucUHOwXL(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇎ")+aRvnqWUHML5QS+JACnOz297UuDK5HpPkc1LF(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇏ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠻ᔮ"):
		scraperserver = HaTI5u1f3SCxmMAkw(u"ࠪࡷࡨࡸࡡࡱࡧ࠱ࡨࡴ࠸ࠧᇐ")
		aRvnqWUHML5QS = zQGaM7ctZCN(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶ࡩ࠳ࡥ࠵ࡤࡩ࠶࠾࠵ࡥࡨ࠷ࡦ࡫࠼ࡡࡧ࠷࠶࠷ࡨ࠽࠰࠵࠲ࡥ࠷࠹࠽ࡣ࠺ࡧ࠼࠽ࡧ࡫࠴࠷࠸ࡤࡩ࠾ࡀࡣࡶࡵࡷࡳࡲࡎࡥࡢࡦࡨࡶࡸࡃࡔࡳࡷࡨࠪ࡬࡫࡯ࡄࡱࡧࡩࡂ࡯࡬ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࠮ࡥࡱ࠽࠼࠵࠾࠰ࠨᇑ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇒ")+aRvnqWUHML5QS+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇓ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==otNfFapeEnO(u"࠽ᔯ"):
		scraperserver = VVvcQpCU3OM09n(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠶ࠫᇔ")
		Da7e1Ruo9G = o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠲࡮ࡵ࠯ࡷ࠳࠲ࡃࡦࡶࡩࡠ࡭ࡨࡽࡂ࠹࠹࠺࠳ࡨ࠽ࡨ࠻࠭࠸ࡧࡨ࠷࠲࠺ࡥࡦ࠴࠰࠼࠹ࡩ࠰࠮ࡨࡧ࠻࠾࠸ࡢࡢࡦࡧ࠷ࡩ࠻ࠦࡤࡱࡸࡲࡹࡸࡹ࠾࡫࡯ࠪࡺࡸ࡬࠾ࠩᇕ")+O4Ak3NXpyUHvE(BBwfuWGxUIrdCoc4ka7)
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡊࡉ࡙࠭ᇖ"),Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	elif HSX3aeuwf5LNGEU7RWV==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠿ᔰ"):
		scraperserver = yylSaxCLfkte(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡦࡴࡴ࠳ࠩᇗ")
		aRvnqWUHML5QS = JACnOz297UuDK5HpPkc1LF(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠨࡳࡶࡴࡾࡹࡠࡥࡲࡹࡳࡺࡲࡺ࠿ࡄࡉࠫࡸࡥࡵࡷࡵࡲࡤࡶࡡࡨࡧࡢࡷࡴࡻࡲࡤࡧࡀࡸࡷࡻࡥࠧࡨࡲࡶࡼࡧࡲࡥࡡ࡫ࡩࡦࡪࡥࡳࡵࡀࡸࡷࡻࡥ࠻࠴ࡥ࠷࠹࠶ࡡ࠷࠺࠼࠴ࡦ࠻࠴࠱࠳ࡧࡦࡨ࠹࠷࠳ࡥ࠴࠵࠹࠻ࡤ࠺࠸࠵ࡩ࠽ࡆࡰࡳࡱࡻࡽ࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠱ࡧࡴࡳ࠺࠹࠲࠻࠴ࠬᇘ")
		Da7e1Ruo9G = BBwfuWGxUIrdCoc4ka7+Olh7n0zfV4(u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬᇙ")+aRvnqWUHML5QS+cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡼࡽࡐࡲ࡚ࡪࡸࡩࡧࡻࡖࡗࡑ࠭ᇚ")
		APzlpyC4ehQWRid9 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,Da7e1Ruo9G,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	else:
		scraperserver,Da7e1Ruo9G = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		APzlpyC4ehQWRid9 = Ing6ofPTzy1aJXv0()
		update = VJZIMkUN5siqB21Pf
	dJoXLYsRnEDH7y = (ZP1LyUCS3pIBu(u"ࠧࡷࡧࡵ࡭࡫ࡿ࠮ࡩࡶࡰࡰࡄࡸࡥࡥ࡫ࡵࡩࡨࡺ࠽ࠨᇛ") in BBwfuWGxUIrdCoc4ka7)
	if dJoXLYsRnEDH7y: APzlpyC4ehQWRid9.succeeded = VJZIMkUN5siqB21Pf
	if update and not APzlpyC4ehQWRid9.succeeded:
		hyMjPsHUx1BCWT2v4k(website,[],HSX3aeuwf5LNGEU7RWV)
		if len(list(set(AAYdNKMXps6JDPFHgz7S)))>P2Fgh6TCOWoaHjkqBcQnvRNXe:
			Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨๆ็วุ็ࠠิ์ิๅึࠦๅฺษ็ะฮࠦวๅฯฯฬࠥืโๆࠢࠪᇜ")+str(HSX3aeuwf5LNGEU7RWV)+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࠣๅู๊ࠠโ์ࠣ฽๊๊๊สࠢอะฬ๎าࠡษ็ััฮࠠ࠯࠰๋้ࠣࠦสา์าࠤ๊ำว้ๆฬࠤฯาว้ิࠣห้ำฬษ่ࠢีฮࠦรฯำ์ࠤออำหะาห๊ࠦำ๋ำไี๋ࠥฮหๆไࠤฤࠧࠧᇝ"))
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
				VUajfbP8AXsxq9rv2hJYnLIgSNFy0.append(HSX3aeuwf5LNGEU7RWV)
				APzlpyC4ehQWRid9 = epDHqUwf9S4RAC6h3Yd8LsPVb(por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i,VUajfbP8AXsxq9rv2hJYnLIgSNFy0)
				return APzlpyC4ehQWRid9
	APzlpyC4ehQWRid9.scrapernumber = str(HSX3aeuwf5LNGEU7RWV)
	scraperserver = scraperserver+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࠤ࠿ࠦࠧᇞ")+str(HSX3aeuwf5LNGEU7RWV)
	APzlpyC4ehQWRid9.scraperserver = scraperserver
	APzlpyC4ehQWRid9.scraperurl = Da7e1Ruo9G
	if APzlpyC4ehQWRid9.succeeded:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+JACnOz297UuDK5HpPkc1LF(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡔࡧࡵࡺࡪࡸ࠺ࠡ࡝ࠣࠫᇟ")+scraperserver+rC5tnFDlQcRGA2(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᇠ")+nqVYufmd4GFshQeHO9vp05+Olh7n0zfV4(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᇡ")+BBwfuWGxUIrdCoc4ka7+Olh7n0zfV4(u"ࠧࠡ࡟ࠪᇢ"))
		KhwN2zcb7iMkjS5E4WURxByPGon(ZP1LyUCS3pIBu(u"ࠨ่ฯัฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪᇣ"),glcHUZI8YGupfz5T7oK3nxdRbrWt,L8Wkv5KCSoq=xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠱࠱࠲࠳ᔱ"))
	else:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡨࡹࡱࡣࡶࡷࠥࡨ࡬ࡰࡥ࡮࡭ࡳ࡭ࠠࠡࠢࡖࡩࡷࡼࡥࡳ࠼ࠣ࡟ࠥ࠭ᇤ")+scraperserver+ZP1LyUCS3pIBu(u"ࠪࠤࡢࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᇥ")+str(APzlpyC4ehQWRid9.code)+mi2ZJXCDzITuyev6gfn(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ᇦ")+APzlpyC4ehQWRid9.reason+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᇧ")+nqVYufmd4GFshQeHO9vp05+cbmeD4WNZfAowxT2JdUMtV(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᇨ")+BBwfuWGxUIrdCoc4ka7+cbmeD4WNZfAowxT2JdUMtV(u"ࠧࠡ࡟ࠪᇩ"))
		KhwN2zcb7iMkjS5E4WURxByPGon(rC5tnFDlQcRGA2(u"ࠨใื่ฯูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠪᇪ"),glcHUZI8YGupfz5T7oK3nxdRbrWt,L8Wkv5KCSoq=VVvcQpCU3OM09n(u"࠲࠲࠳࠴ᔲ"))
	return APzlpyC4ehQWRid9
def FFkYHvnOyQUwLpuJIhrdx9EgP(JtQnzkyrlEG0aZ6mx4c,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,showDialogs,nqVYufmd4GFshQeHO9vp05):
	if not qPWgu3zkRbrv74yho or isinstance(qPWgu3zkRbrv74yho,dict): por2itPgjLlh5fAb3z47nFvUJE = rC5tnFDlQcRGA2(u"ࠩࡊࡉ࡙࠭ᇫ")
	else:
		por2itPgjLlh5fAb3z47nFvUJE = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡔࡔ࡙ࡔࠨᇬ")
		qPWgu3zkRbrv74yho = sWzgdLCjSVwaMuhFkNf1Uop(qPWgu3zkRbrv74yho)
		Mke8jDB62TRsY9LpP0QOHvF,qPWgu3zkRbrv74yho = degRiWptawTqXvKNh(qPWgu3zkRbrv74yho)
	cDXLPHnAgY6NOk1GVStoiEx = DNq5CJHPR3G7uX8pbngwF9T(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,w2qb6lf5EM,showDialogs,nqVYufmd4GFshQeHO9vp05)
	z4YnlxGHF2AMtrw = cDXLPHnAgY6NOk1GVStoiEx.content
	z4YnlxGHF2AMtrw = str(z4YnlxGHF2AMtrw)
	return z4YnlxGHF2AMtrw
def EuX7CkI8cK5b0YO1WVwQMy(otaunYGVIJ2jX8HsKm7ecR0bAh4):
	LLcgKaDr5z7oylH2iBe = otaunYGVIJ2jX8HsKm7ecR0bAh4.split(E6xdOMpqISHZCn(u"ࠫࢁࢂࠧᇭ"))
	BBwfuWGxUIrdCoc4ka7,iSNtwvQFHbA,norNEp9J308Y7MScPvRG1A2B,br0nG1O7vxmtPoqTJXsVKWyCkEY = LLcgKaDr5z7oylH2iBe[ZVNvqy4iF1a9X],gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1,w2qb6lf5EM
	for ZBstQ7jF04zNp8EmHoY5A in LLcgKaDr5z7oylH2iBe:
		if xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇮ") in ZBstQ7jF04zNp8EmHoY5A: iSNtwvQFHbA = ZBstQ7jF04zNp8EmHoY5A[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠳࠴ᔳ"):]
		elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡍࡺࡆࡑࡗ࡚ࡸ࡬࠾ࠩᇯ") in ZBstQ7jF04zNp8EmHoY5A: norNEp9J308Y7MScPvRG1A2B = ZBstQ7jF04zNp8EmHoY5A[zz679V18GdcZwvrRexA0nNptY2Tab(u"࠼ᔴ"):]
		elif od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇰ") in ZBstQ7jF04zNp8EmHoY5A: br0nG1O7vxmtPoqTJXsVKWyCkEY = VJZIMkUN5siqB21Pf
	return BBwfuWGxUIrdCoc4ka7,iSNtwvQFHbA,norNEp9J308Y7MScPvRG1A2B,br0nG1O7vxmtPoqTJXsVKWyCkEY
def zRtislG7CcO6UYZa(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,ooGayxYqbnASPsw4zZWl6CRMi9N,MMrAtIDxnhy3SeXC5QJsBRLzTU,O5M4IqvPVEzQCjaoyGBAt2,Dfi7FTuYWN49AaLEt3=CJlTSEpZsWb0QHg5w):
	wGsbjoK59B0JIt = fUSgd7IjGYX496Hr25uFMl(otaunYGVIJ2jX8HsKm7ecR0bAh4,cjVhOCwybeRo7UWg92(u"ࠨࡷࡵࡰࠬᇱ"))
	L15U9MHPl6qKxRTJDscbymh0o3etg = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡤࡺ࠳࡮࡯ࡴࡶ࠱ࠫᇲ")+ooGayxYqbnASPsw4zZWl6CRMi9N)
	if wGsbjoK59B0JIt==L15U9MHPl6qKxRTJDscbymh0o3etg: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(GISOTJh20W(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬᇳ")+ooGayxYqbnASPsw4zZWl6CRMi9N,CJlTSEpZsWb0QHg5w)
	if L15U9MHPl6qKxRTJDscbymh0o3etg: ysw7G3tqjo = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(wGsbjoK59B0JIt,L15U9MHPl6qKxRTJDscbymh0o3etg)
	else:
		ysw7G3tqjo = otaunYGVIJ2jX8HsKm7ecR0bAh4
		L15U9MHPl6qKxRTJDscbymh0o3etg = wGsbjoK59B0JIt
	nJsMjF0fH3 = DNq5CJHPR3G7uX8pbngwF9T(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,ysw7G3tqjo,CJlTSEpZsWb0QHg5w,Dfi7FTuYWN49AaLEt3,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨᇴ"))
	z4YnlxGHF2AMtrw = nJsMjF0fH3.content
	if A7Z6OVh20eCEUx:
		try: z4YnlxGHF2AMtrw = z4YnlxGHF2AMtrw.decode(Im5KSGZYBpRvdMVsbuXg,Olh7n0zfV4(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᇵ"))
		except: pass
	if not nJsMjF0fH3.succeeded or O5M4IqvPVEzQCjaoyGBAt2 not in z4YnlxGHF2AMtrw:
		MMrAtIDxnhy3SeXC5QJsBRLzTU = MMrAtIDxnhy3SeXC5QJsBRLzTU.replace(YvOQBzaTAscXR9ql,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࠫࠨᇶ"))
		BBwfuWGxUIrdCoc4ka7 = KA26GucUHOwXL(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡦࡸࡣࡩࡁࡴࡁࠬᇷ")+MMrAtIDxnhy3SeXC5QJsBRLzTU
		bsGedm1TLP7EgiUQDkCy = {zQGaM7ctZCN(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᇸ"):CJlTSEpZsWb0QHg5w}
		Ig8Y6D1bZtzURv = DNq5CJHPR3G7uX8pbngwF9T(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡒࡊ࡝࡟ࡉࡑࡖࡘࡓࡇࡍࡆ࠯࠵ࡲࡩ࠭ᇹ"))
		if Ig8Y6D1bZtzURv.succeeded:
			z4YnlxGHF2AMtrw = Ig8Y6D1bZtzURv.content
			if A7Z6OVh20eCEUx:
				try: z4YnlxGHF2AMtrw = z4YnlxGHF2AMtrw.decode(Im5KSGZYBpRvdMVsbuXg,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᇺ"))
				except: pass
			Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯࡝ࡹ࠭ࡠࡄ࠴ࠪࡀࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠬᇻ"),z4YnlxGHF2AMtrw,Zy2l0g8QU5vqefaTrsw.DOTALL)
			tt0LqMXUOJmn6i91fW = [L15U9MHPl6qKxRTJDscbymh0o3etg]
			NU7pvxdj3ig20nRBfr = [zQGaM7ctZCN(u"ࠬࡧࡰ࡬ࠩᇼ"),cjVhOCwybeRo7UWg92(u"࠭ࡧࡰࡱࡪࡰࡪ࠭ᇽ"),XB4CjMkPFzhAHiI3q(u"ࠧࡵࡹ࡬ࡸࡹ࡫ࡲࠨᇾ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩᇿ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡩࡥࡨ࡫ࡢࡰࡱ࡮ࠫሀ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡴ࡭ࡶࠧሁ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡦࡺ࡬ࡢࡳࠪሂ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡹࡩࡵࡧ࡬ࡲࡩ࡯ࡣࡦࡵࠪሃ"),Olh7n0zfV4(u"࠭ࡳࡶࡴ࠱ࡰࡾ࠭ሄ"),s97s2k0LJgl(u"ࠧࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩህ"),s97s2k0LJgl(u"ࠨ࡫ࡱࡪࡴࡸ࡭ࡦࡴࠪሆ"),yylSaxCLfkte(u"ࠩࡶ࡭ࡹ࡫࡬ࡪ࡭ࡨࠫሇ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪ࡭ࡳࡹࡴࡢࡩࡵࡥࡲ࠭ለ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡸࡴࡡࡱࡥ࡫ࡥࡹ࠭ሉ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬ࡮ࡴࡵࡲ࠰ࡩࡶࡻࡩࡷࠩሊ"),pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡦࡢࡵࡨࡰࡵࡲࡵࡴࠩላ")]
			for vTdZUJkpi6RuY9wlsPO2AxKo83ncWB in Rp1g7OlotseGnf0NFmKk6rLxd:
				if any(value in vTdZUJkpi6RuY9wlsPO2AxKo83ncWB for value in NU7pvxdj3ig20nRBfr): continue
				L15U9MHPl6qKxRTJDscbymh0o3etg = fUSgd7IjGYX496Hr25uFMl(vTdZUJkpi6RuY9wlsPO2AxKo83ncWB,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡶࡴ࡯ࠫሌ"))
				if L15U9MHPl6qKxRTJDscbymh0o3etg in tt0LqMXUOJmn6i91fW: continue
				if len(tt0LqMXUOJmn6i91fW)==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠽ᔵ"):
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+ZP1LyUCS3pIBu(u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡬ࡩ࡯ࡦࠣࡥࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨል")+ooGayxYqbnASPsw4zZWl6CRMi9N+s97s2k0LJgl(u"ࠩࠣࡡࠥࠦࡏ࡭ࡦ࠽ࠤࡠࠦࠧሎ")+wGsbjoK59B0JIt+ZP1LyUCS3pIBu(u"ࠪࠤࡢ࠭ሏ"))
					ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭ሐ")+ooGayxYqbnASPsw4zZWl6CRMi9N,CJlTSEpZsWb0QHg5w)
					break
				tt0LqMXUOJmn6i91fW.append(L15U9MHPl6qKxRTJDscbymh0o3etg)
				ysw7G3tqjo = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(wGsbjoK59B0JIt,L15U9MHPl6qKxRTJDscbymh0o3etg)
				nJsMjF0fH3 = DNq5CJHPR3G7uX8pbngwF9T(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,ysw7G3tqjo,CJlTSEpZsWb0QHg5w,Dfi7FTuYWN49AaLEt3,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩሑ"))
				z4YnlxGHF2AMtrw = nJsMjF0fH3.content
				if nJsMjF0fH3.succeeded and O5M4IqvPVEzQCjaoyGBAt2 in z4YnlxGHF2AMtrw:
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+VVvcQpCU3OM09n(u"࠭ࠠࠡࠢࡊࡳࡴ࡭࡬ࡦࠢࡩࡳࡺࡴࡤࠡࡣࠣࡲࡪࡽࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࠣࠤࡘ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭ሒ")+ooGayxYqbnASPsw4zZWl6CRMi9N+o2FdrDBimMuOw97q6QpNW8S(u"ࠧࠡ࡟ࠣࠤࠥࡔࡥࡸ࠼ࠣ࡟ࠥ࠭ሓ")+L15U9MHPl6qKxRTJDscbymh0o3etg+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࠢࡠࠤࠥࡕ࡬ࡥ࠼ࠣ࡟ࠥ࠭ሔ")+wGsbjoK59B0JIt+E6xdOMpqISHZCn(u"ࠩࠣࡡࠬሕ"))
					ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(ZP1LyUCS3pIBu(u"ࠪࡥࡻ࠴ࡨࡰࡵࡷ࠲ࠬሖ")+ooGayxYqbnASPsw4zZWl6CRMi9N,L15U9MHPl6qKxRTJDscbymh0o3etg)
					break
	return L15U9MHPl6qKxRTJDscbymh0o3etg,ysw7G3tqjo,nJsMjF0fH3
def HRYMpjUhOiul4zdP7G8c(AyKma12GRYnziLV7EWIjUM):
	FszTBEgutH = {
	 h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡦ࡮ࡷࡢ࡭ࠪሗ")				:zQGaM7ctZCN(u"๋่ࠬใ฻ࠣว์๎วไࠢอ๎ๆ๐ࠧመ")
	,GISOTJh20W(u"࠭ࡡ࡬ࡱࡤࡱࠬሙ")				:zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧๆ๊ๅ฽ࠥษใ้ษ่ࠤฬ๊โะ์่ࠫሚ")
	,rC5tnFDlQcRGA2(u"ࠨࡣ࡮ࡳࡦࡳࡣࡢ࡯ࠪማ")				:JACnOz297UuDK5HpPkc1LF(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦใศ็ࠪሜ")
	,cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡥࡰࡽࡡ࡮ࠩም")				:TDpFsQXHze2q30uYtGPfEIm8(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ะิ๐ฯࠨሞ")
	,JACnOz297UuDK5HpPkc1LF(u"ࠬࡧ࡫ࡸࡣࡰࡸࡺࡨࡥࠨሟ")			:CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ๅ้ไ฼ࠤฬ้่ศ็ࠣฮ๏๎ศࠨሠ")
	,GISOTJh20W(u"ࠧࡢ࡮ࡤࡶࡦࡨࠧሡ")				:KA26GucUHOwXL(u"ࠨ็๋ๆ฾ࠦใๅࠢส่฾ืศࠨሢ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡤࡰ࡫ࡧࡴࡪ࡯࡬ࠫሣ")				:CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"้ࠪํู่ࠡษ็้๋ฮัࠡษ็ๅฬ฽ๅ๋ࠩሤ")
	,pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡦࡲ࡫ࡢࡹࡷ࡬ࡦࡸࠧሥ")			:I7K1Tbk8YSXUhApzqwtLEQMV2(u"๋่ࠬใ฻ࠣๆ๋อษࠡษ็็ํััࠨሦ")
	,HaTI5u1f3SCxmMAkw(u"࠭ࡡ࡭࡯ࡤࡥࡷ࡫ࡦࠨሧ")				:Olh7n0zfV4(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣหู้๋ศำไࠫረ")
	,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡣ࡯ࡱࡸࡺࡢࡢࠩሩ")				:GISOTJh20W(u"่ࠩ์็฿ࠠศๆู่฼ฮษࠨሪ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡥࡳ࡯࡭ࡦࡼ࡬ࡨࠬራ")				:o2FdrDBimMuOw97q6QpNW8S(u"๊ࠫ๎โฺࠢส๊๊๐ࠠำัࠪሬ")
	,otNfFapeEnO(u"ࠬࡧࡲࡢࡤ࡬ࡧࡹࡵ࡯࡯ࡵࠪር")			:NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ๅ้ไ฼ࠤฯ๎ๆำࠢ฼ีอ๐ษࠨሮ")
	,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡢࡴࡤࡦࡸ࡫ࡥࡥࠩሯ")				:KA26GucUHOwXL(u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨሰ")
	,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫሱ")				:I7K1Tbk8YSXUhApzqwtLEQMV2(u"้ࠪํู่ࠡ฻ิฬ๊๊้่ࠥีࠫሲ")
	,E6xdOMpqISHZCn(u"ࠫࡦࡿ࡬ࡰ࡮ࠪሳ")				:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"๋่ࠬใ฻ࠣว๏๊่ๅࠩሴ")
	,o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡢࡰ࡭ࡵࡥࠬስ")				:GISOTJh20W(u"ࠧๆ๊ๅ฽ࠥฮใาษࠪሶ")
	,pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡤࡵࡷࡹ࡫ࡪࠨሷ")				:zz679V18GdcZwvrRexA0nNptY2Tab(u"่ࠩ์็฿ࠠษำึฮ๏าࠧሸ")
	,EcjO3giln2kQTdBY0XLAG(u"ࠪࡧ࡮ࡳࡡ࠵࠲࠳ࠫሹ")				:mi2ZJXCDzITuyev6gfn(u"๊ࠫ๎โฺࠢึ๎๊อࠠ࠵࠲࠳ࠫሺ")
	,mi2ZJXCDzITuyev6gfn(u"ࠬࡩࡩ࡮ࡣ࠷ࡴࠬሻ")				:TDpFsQXHze2q30uYtGPfEIm8(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไ์ึࠦศ๋ࠩሼ")
	,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧሽ")				:EcjO3giln2kQTdBY0XLAG(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ั๋๊ࠪሾ")
	,GISOTJh20W(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫሿ")				:TDpFsQXHze2q30uYtGPfEIm8(u"้ࠪํู่ࠡีํ้ฬูࠦษั๋ࠫቀ")
	,ZP1LyUCS3pIBu(u"ࠫࡨ࡯࡭ࡢࡥ࡯ࡹࡧ࠭ቁ")				:I7K1Tbk8YSXUhApzqwtLEQMV2(u"๋่ࠬใ฻ࠣื๏๋วࠡๅ็์อ࠭ቂ")
	,E6xdOMpqISHZCn(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࡸࡱࡵ࡯ࠬቃ")			:ZP1LyUCS3pIBu(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠡ฻่่ࠬቄ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡲࠪቅ")				:yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠪቆ")
	,zQGaM7ctZCN(u"ࠪࡧ࡮ࡳࡡࡧࡣࡱࡷࠬቇ")				:TDpFsQXHze2q30uYtGPfEIm8(u"๊ࠫ๎โฺࠢึ๎๊อࠠโษ้ึࠬቈ")
	,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡩࡩ࡮ࡣࡩࡶࡪ࡫ࠧ቉")				:E6xdOMpqISHZCn(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไี๏࠭ቊ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪቋ")			:VVvcQpCU3OM09n(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤ้อ๊หࠩቌ")
	,VVvcQpCU3OM09n(u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪቍ")				:O4F8UC5lMAS6ghETm1VoPDI(u"้ࠪํู่ࠡีํ้ฬࠦๆศ๊ࠪ቎")
	,s97s2k0LJgl(u"ࠫࡨ࡯࡭ࡢࡹࡥࡥࡸ࠭቏")				:JACnOz297UuDK5HpPkc1LF(u"๋่ࠬใ฻ࠣื๏๋ว๊ࠡหืࠬቐ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱࠫቑ")			:rC5tnFDlQcRGA2(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠩቒ")
	,cjVhOCwybeRo7UWg92(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠳ࡣࡩࡣࡱࡲࡪࡲࡳࠨቓ")	:zz679V18GdcZwvrRexA0nNptY2Tab(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠤู๊สฯั่๎๋࠭ቔ")
	,pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡪࡤࡷ࡭ࡺࡡࡨࡵࠪቕ")	:TMfV6892ZoBdyxCH3tGrkwY0K(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦ็ศึอห่࠭ቖ")
	,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰ࡰ࡮ࡼࡥࡴࠩ቗")	:O4F8UC5lMAS6ghETm1VoPDI(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠡ็หหูืࠧቘ")
	,XB4CjMkPFzhAHiI3q(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ቙"):mi2ZJXCDzITuyev6gfn(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่ࠣๆํอฦๆࠩቚ")
	,rC5tnFDlQcRGA2(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡵࡱࡳ࡭ࡨࡹࠧቛ")	:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊๋่ࠥศุํ฽ࠬቜ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡹ࡭ࡩ࡫࡯ࡴࠩቝ")	:h6sIkJOT5PB2vCxqo4LFag70wA(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠโ์า๎ํํวหࠩ቞")
	,zQGaM7ctZCN(u"࠭ࡤࡪࡵࡤࡦࡱ࡫ࡤࠨ቟")				:TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧๆฬ๋ๆๆ࠭በ")
	,pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡦࡵࡥࡲࡧࡣࡢࡨࡨࠫቡ")			:h6sIkJOT5PB2vCxqo4LFag70wA(u"่ࠩ์็฿ࠠะำส้ฬࠦใศใํ๋ࠬቢ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡨࡷࡧ࡭ࡢࡵ࠺ࠫባ")				:pz4WBwfyDdgk0m2aRr7SMv(u"๊ࠫ๎โฺࠢาีฬ๋วࠡืะࠫቤ")
	,XB4CjMkPFzhAHiI3q(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ብ")				:xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠧቦ")
	,o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩቧ")				:zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠢ࠴ࠫቨ")
	,cjVhOCwybeRo7UWg92(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠵ࠫቩ")				:NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠷࠭ቪ")
	,TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠸࠭ቫ")				:HaTI5u1f3SCxmMAkw(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠳ࠨቬ")
	,ZP1LyUCS3pIBu(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠴ࠨቭ")				:O4F8UC5lMAS6ghETm1VoPDI(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠶ࠪቮ")
	,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࡸ࡬ࡴࠬቯ")			:pz4WBwfyDdgk0m2aRr7SMv(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣࡺ࡮ࡶࠧተ")
	,pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡩ࡬ࡿࡤࡦࡣࡧࠫቱ")				:cbmeD4WNZfAowxT2JdUMtV(u"๊ࠫ๎โฺࠢศ๎ั๐ࠠะ์าࠫቲ")
	,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬ࡫ࡧࡺࡰࡲࡻࠬታ")				:KA26GucUHOwXL(u"࠭ๅ้ไ฼ࠤส๐ฬ๋้ࠢหํ࠭ቴ")
	,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡦ࡮ࡦ࡭ࡳ࡫࡭ࡢࠩት")				:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ็๋ๆ฾ࠦๅ้ี๋฽ฮࠦวๅีํ๊๊อࠧቶ")
	,VVvcQpCU3OM09n(u"ࠩࡨࡰ࡮࡬ࡶࡪࡦࡨࡳࠬቷ")			:mi2ZJXCDzITuyev6gfn(u"้ࠪํู่ࠡล็๎ๆࠦแ๋ัํ์ࠬቸ")
	,otNfFapeEnO(u"ࠫ࡫ࡧࡢࡳࡣ࡮ࡥࠬቹ")				:otNfFapeEnO(u"๋่ࠬใ฻ࠣๅอืใสࠩቺ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ቻ")				:JACnOz297UuDK5HpPkc1LF(u"ࠧโึ็ࠫቼ")
	,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡨࡤ࡮ࡪࡸࡳࡩࡱࡺࠫች")			:ZP1LyUCS3pIBu(u"่ࠩ์็฿ࠠโฮิࠤู๎ࠧቾ")
	,XB4CjMkPFzhAHiI3q(u"ࠪࡪࡦࡸࡥࡴ࡭ࡲࠫቿ")				:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"๊ࠫ๎โฺࠢไหึูใ้ࠩኀ")
	,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠷ࠧኁ")				:XB4CjMkPFzhAHiI3q(u"࠭ๅ้ไ฼ࠤๆอีๅࠢส่ศ๎ไࠨኂ")
	,zQGaM7ctZCN(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠳ࠩኃ")				:yylSaxCLfkte(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊หศ่ํࠫኄ")
	,EcjO3giln2kQTdBY0XLAG(u"ࠩࡩࡳࡱࡪࡥࡳࠩኅ")				:yylSaxCLfkte(u"้ࠪั๊ฯࠨኆ")
	,yylSaxCLfkte(u"ࠫ࡫ࡵࡳࡵࡣࠪኇ")				:TDpFsQXHze2q30uYtGPfEIm8(u"๋่ࠬใ฻ࠣๅํูสศࠩኈ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡦࡶࡰࡲࡲࡹࡼࠧ኉")				:VVvcQpCU3OM09n(u"ࠧๆ๊ๅ฽ࠥ็ๆ้่ࠣฮ๏็๊ࠨኊ")
	,JACnOz297UuDK5HpPkc1LF(u"ࠨࡨࡸࡷ࡭ࡧࡲࡵࡸࠪኋ")				:pz4WBwfyDdgk0m2aRr7SMv(u"่ࠩ์็฿ࠠโ๊ืหึࠦส๋ใํࠫኌ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡪࡺࡹࡨࡢࡴࡹ࡭ࡩ࡫࡯ࠨኍ")			:ZP1LyUCS3pIBu(u"๊ࠫ๎โฺࠢไ์ูอัࠡใํำ๏๎ࠧ኎")
	,JACnOz297UuDK5HpPkc1LF(u"ࠬ࡭࡯ࡰࡦࠪ኏")					:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ฬ๋ัࠪነ")
	,HaTI5u1f3SCxmMAkw(u"ࠧࡩࡣ࡯ࡥࡨ࡯࡭ࡢࠩኑ")				:Olh7n0zfV4(u"ࠨ็๋ๆ฾ࠦ็ๅษࠣื๏๋วࠨኒ")
	,zQGaM7ctZCN(u"ࠩ࡫ࡩࡱࡧ࡬ࠨና")				:s97s2k0LJgl(u"้ࠪํู่้ࠡ็ห้๊้ࠦฬํ์อ࠭ኔ")
	,KA26GucUHOwXL(u"ࠫ࡮࡬ࡩ࡭࡯ࠪን")				:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"๋่ࠬใ฻ࠣๆ๋อษࠡฤํࠤๆ๐ไๆࠩኖ")
	,zQGaM7ctZCN(u"࠭ࡩࡧ࡫࡯ࡱ࠲ࡧࡲࡢࡤ࡬ࡧࠬኗ")			:zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠤ฾ืศ๋ࠩኘ")
	,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡦࡰࡪࡰ࡮ࡹࡨࠨኙ")		:O4F8UC5lMAS6ghETm1VoPDI(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํ่๊ࠦว็ฮ็๎ื๐ࠧኚ")
	,otNfFapeEnO(u"ࠪ࡭ࡵࡺࡶࠨኛ")					:pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡎࡖࡔࡗࠩኜ")
	,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ࡯ࡰࡵࡸ࠰ࡰ࡮ࡼࡥࠨኝ")			:rC5tnFDlQcRGA2(u"࠭ࡉࡑࡖ࡙ࠤ็์่ศฬࠪኞ")
	,GISOTJh20W(u"ࠧࡪࡲࡷࡺ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬኟ")			:Olh7n0zfV4(u"ࠨࡋࡓࡘ࡛ࠦรโๆส้ࠬአ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࡬ࡴࡹࡼ࠭ࡴࡧࡵ࡭ࡪࡹࠧኡ")			:mi2ZJXCDzITuyev6gfn(u"ࠪࡍࡕ࡚ࡖࠡ็ึุ่๊วหࠩኢ")
	,JACnOz297UuDK5HpPkc1LF(u"ࠫࡰࡧࡲࡣࡣ࡯ࡥࡹࡼࠧኣ")			:O4F8UC5lMAS6ghETm1VoPDI(u"๋่ࠬใ฻ࠣๆ๋อษࠡๅิฬ้อมࠨኤ")
	,cjVhOCwybeRo7UWg92(u"࠭࡫ࡢࡶ࡮ࡳࡹࡺࡶࠨእ")				:mi2ZJXCDzITuyev6gfn(u"ࠧๆ๊ๅ฽้ࠥสไ๊อࠤฯ๐แ๋ࠩኦ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪኧ")				:pz4WBwfyDdgk0m2aRr7SMv(u"่ࠩ์็฿ࠠไฬๆ์ฯ࠭ከ")
	,GISOTJh20W(u"ࠪ࡯࡮ࡸ࡭ࡢ࡮࡮ࠫኩ")				:pz4WBwfyDdgk0m2aRr7SMv(u"๊ࠫ๎โฺࠢๆี๊อไไࠩኪ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡲࡡࡳࡱࡽࡥࠬካ")				:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ๅ้ไ฼ࠤ้อั้ิสࠫኬ")
	,Olh7n0zfV4(u"ࠧ࡭࡫ࡥࡶࡦࡸࡹࠨክ")				:yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ็็ๅࠬኮ")
	,KA26GucUHOwXL(u"ࠩ࡯࡭ࡻ࡫ࠧኯ")					:zQGaM7ctZCN(u"ࠪๆ๋อษࠨኰ")
	,otNfFapeEnO(u"ࠫࡱ࡯ࡶࡦࡶࡹࠫ኱")				:cjVhOCwybeRo7UWg92(u"๋ࠬไโࠩኲ")
	,TDpFsQXHze2q30uYtGPfEIm8(u"࠭࡬ࡰࡦࡼࡲࡪࡺࠧኳ")				:VVvcQpCU3OM09n(u"ࠧๆ๊ๅ฽๊่ࠥะ์๊ࠣฯ࠭ኴ")
	,rC5tnFDlQcRGA2(u"ࠨ࡯࠶ࡹࠬኵ")					:NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡐ࠷࡚࠭኶")
	,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡱ࠸ࡻ࠭࡭࡫ࡹࡩࠬ኷")				:s97s2k0LJgl(u"ࠫࡒ࠹ࡕࠡไ้์ฬะࠧኸ")
	,rC5tnFDlQcRGA2(u"ࠬࡳ࠳ࡶ࠯ࡰࡳࡻ࡯ࡥࡴࠩኹ")			:cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡍ࠴ࡗࠣวๆ๊วๆࠩኺ")
	,cbmeD4WNZfAowxT2JdUMtV(u"ࠧ࡮࠵ࡸ࠱ࡸ࡫ࡲࡪࡧࡶࠫኻ")			:zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡏ࠶๋࡙ࠥำๅี็หฯ࠭ኼ")
	,yylSaxCLfkte(u"ࠩࡰࡥࡸࡧࡶࡪࡦࡨࡳࠬኽ")			:KA26GucUHOwXL(u"้ࠪํู่ࠡ็สืฬࠦแ๋ัํ์ࠬኾ")
	,ZP1LyUCS3pIBu(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬ኿")				:TDpFsQXHze2q30uYtGPfEIm8(u"๋ࠬแใ๊าࠫዀ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭዁")				:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧๆ๊ๅ฽๋่ࠥโิࠣๅํื๊้ࠩዂ")
	,TDpFsQXHze2q30uYtGPfEIm8(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨዃ")				:TDpFsQXHze2q30uYtGPfEIm8(u"่ࠩ์็฿ࠠๆษํࠤุ๐ๅศࠩዄ")
	,Olh7n0zfV4(u"ࠪࡳࡱࡪࠧዅ")					:O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ็ี๊ๆࠩ዆")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡶࡡ࡯ࡧࡷࠫ዇")				:otNfFapeEnO(u"࠭ๅ้ไ฼ࠤออๆ๋ฬࠪወ")
	,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡱࡣࡱࡩࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ዉ")			:od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠥอแๅษ่ࠫዊ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡳࡥࡳ࡫ࡴ࠮ࡵࡨࡶ࡮࡫ࡳࠨዋ")			:E6xdOMpqISHZCn(u"้ࠪํู่ࠡสส๊๏ะࠠๆี็ื้อสࠨዌ")
	,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡶ࡬ࡩ࡭࡯ࠪው")				:NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"๋่ࠬใ฻ࠣ็๏๎ࠠโ์็้ࠬዎ")
	,o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡳࡦࡴ࡬ࡩࡸࡺࡩ࡮ࡧࠪዏ")			:otNfFapeEnO(u"ࠧๆ๊ๅ฽ู๊ࠥา์ึࠤฯอ๊ๆࠩዐ")
	,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡵ࡫ࡥࡧࡧ࡫ࡢࡶࡼࠫዑ")			:I7K1Tbk8YSXUhApzqwtLEQMV2(u"่ࠩ์็฿ࠠีสๆฮ๏࠭ዒ")
	,yylSaxCLfkte(u"ࠪࡷ࡭ࡧࡨࡪࡦ࠷ࡹࠬዓ")				:KA26GucUHOwXL(u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭ዔ")
	,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻ࠲ࠨዕ")			:zQGaM7ctZCN(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠡ࠴ࠪዖ")
	,o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫ዗")			:XB4CjMkPFzhAHiI3q(u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩዘ")
	,HaTI5u1f3SCxmMAkw(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬዙ")			:CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬዚ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧዛ")		:mi2ZJXCDzITuyev6gfn(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭ዜ")
	,yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩዝ")		:O4F8UC5lMAS6ghETm1VoPDI(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩዞ")
	,Olh7n0zfV4(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬዟ")	:rC5tnFDlQcRGA2(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩዠ")
	,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪዡ")				:KA26GucUHOwXL(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭ዢ")
	,VVvcQpCU3OM09n(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧዣ")				:ZP1LyUCS3pIBu(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭ዤ")
	,mi2ZJXCDzITuyev6gfn(u"ࠧࡴࡪࡲࡳ࡫ࡴࡥࡵࠩዥ")				:XB4CjMkPFzhAHiI3q(u"ࠨ็๋ๆ฾ࠦิ้ใ๊ࠣฯ࠭ዦ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫዧ")				:I7K1Tbk8YSXUhApzqwtLEQMV2(u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩየ")
	,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡹ࡯࡫ࡢࡣࡷࠫዩ")				:KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"๋่ࠬใ฻ࠣฮ่อสࠨዪ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡴࡷࡨࡸࡲࠬያ")				:I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧዬ")
	,s97s2k0LJgl(u"ࠨࡸࡤࡶࡧࡵ࡮ࠨይ")				:KA26GucUHOwXL(u"่ࠩ์็฿ࠠโษิฬํ์ࠧዮ")
	,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡺ࡮ࡪࡥࡰࠩዯ")				:pz4WBwfyDdgk0m2aRr7SMv(u"ࠫๆ๐ฯ๋๊ࠪደ")
	,E6xdOMpqISHZCn(u"ࠬࡼࡩࡥࡧࡲࡲࡸࡧࡥ࡮ࠩዱ")			:pz4WBwfyDdgk0m2aRr7SMv(u"࠭ๅ้ไ฼ࠤๆ๐ฯุ๋๊๊ࠣอฦๆࠩዲ")
	,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠱ࠨዳ")				:pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠲ࠩዴ")
	,EcjO3giln2kQTdBY0XLAG(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠴ࠪድ")				:s97s2k0LJgl(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠵ࠫዶ")
	,pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡾࡧࡱࡰࡶࠪዷ")				:KA26GucUHOwXL(u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩዸ")
	,GISOTJh20W(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧዹ")				:O4F8UC5lMAS6ghETm1VoPDI(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬዺ")
	,mi2ZJXCDzITuyev6gfn(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫዻ")		:EcjO3giln2kQTdBY0XLAG(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭ዼ")
	,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧዽ")	:yylSaxCLfkte(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨዾ")
	,yylSaxCLfkte(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭ዿ")		:EcjO3giln2kQTdBY0XLAG(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭ጀ")
	,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ጁ")			:JACnOz297UuDK5HpPkc1LF(u"ࠨ็๋ห็฿ࠠๆ่ࠣ๎ํะ๊้สࠪጂ")
	}
	aUnCR2TNPVms71Bprhow = AyKma12GRYnziLV7EWIjUM.lower()
	for key in list(FszTBEgutH.keys()):
		I9UVqNFJYLK0rej5gyBAOpMCht = key.lower()
		if aUnCR2TNPVms71Bprhow==I9UVqNFJYLK0rej5gyBAOpMCht:
			AyKma12GRYnziLV7EWIjUM = FszTBEgutH[key]
			break
	return AyKma12GRYnziLV7EWIjUM
def nYgsitVoc3E(E5EfKtv2xu,ggRBErTluPzAFU3VGL16Y0Shsp=CJlTSEpZsWb0QHg5w):
	Ew2zQ8u7Ss.SuWYMCwV1oBNIG8cq7xR = w2qb6lf5EM
	if not ggRBErTluPzAFU3VGL16Y0Shsp and E5EfKtv2xu: ggRBErTluPzAFU3VGL16Y0Shsp = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡕࡉࡖ࡛ࡅࡔࡖࡢࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪጃ")
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(GISOTJh20W(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧጄ"),ggRBErTluPzAFU3VGL16Y0Shsp)
	return
def O4Ak3NXpyUHvE(otaunYGVIJ2jX8HsKm7ecR0bAh4,BJj7iU9xumNnFTR3av=od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫ࠿࠵ࠧጅ")):
	return _JdrOnR5SHp(otaunYGVIJ2jX8HsKm7ecR0bAh4,BJj7iU9xumNnFTR3av)
def NNYFzc4E7AgWZ0(SPszXI3WfaYplrM0B):
	if SPszXI3WfaYplrM0B in [CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"ࠬ࠶ࠧጆ"),ZVNvqy4iF1a9X]: return CJlTSEpZsWb0QHg5w
	SPszXI3WfaYplrM0B = int(SPszXI3WfaYplrM0B)
	wPGIvQYum6 = SPszXI3WfaYplrM0B^ggZJf7YnlXHT3IjtMaWe6S
	PdyHBpvCV8LuOZEDFfcikGK2n3b5s = SPszXI3WfaYplrM0B^DRmUs7l1O4xLeZYzGITXk
	s4G9qOhkrVKobSpdgfEXI37W8cwn = SPszXI3WfaYplrM0B^o1oDTrOyPliAC6QBcKXRathZGu9g4Y
	GUD0pzT9ZBSHYqIFR5vbus62gJ = str(wPGIvQYum6)+str(PdyHBpvCV8LuOZEDFfcikGK2n3b5s)+str(s4G9qOhkrVKobSpdgfEXI37W8cwn)
	return GUD0pzT9ZBSHYqIFR5vbus62gJ
def gzToKrJkDEFlqBZxs73ScCn0bRA8(SPszXI3WfaYplrM0B):
	if SPszXI3WfaYplrM0B in [CJlTSEpZsWb0QHg5w,E6xdOMpqISHZCn(u"࠭࠰ࠨጇ"),ZVNvqy4iF1a9X]: return CJlTSEpZsWb0QHg5w
	SPszXI3WfaYplrM0B = str(SPszXI3WfaYplrM0B)
	GUD0pzT9ZBSHYqIFR5vbus62gJ = CJlTSEpZsWb0QHg5w
	if len(SPszXI3WfaYplrM0B)==pz4WBwfyDdgk0m2aRr7SMv(u"࠶࠻ᔶ"):
		wPGIvQYum6,PdyHBpvCV8LuOZEDFfcikGK2n3b5s,s4G9qOhkrVKobSpdgfEXI37W8cwn = SPszXI3WfaYplrM0B[ZVNvqy4iF1a9X:P3cpaLN2sH],SPszXI3WfaYplrM0B[P3cpaLN2sH:E6xdOMpqISHZCn(u"࠿ᔷ")],SPszXI3WfaYplrM0B[E6xdOMpqISHZCn(u"࠿ᔷ"):]
		wPGIvQYum6 = int(wPGIvQYum6)^o1oDTrOyPliAC6QBcKXRathZGu9g4Y
		PdyHBpvCV8LuOZEDFfcikGK2n3b5s = int(PdyHBpvCV8LuOZEDFfcikGK2n3b5s)^DRmUs7l1O4xLeZYzGITXk
		s4G9qOhkrVKobSpdgfEXI37W8cwn = int(s4G9qOhkrVKobSpdgfEXI37W8cwn)^ggZJf7YnlXHT3IjtMaWe6S
		if wPGIvQYum6==PdyHBpvCV8LuOZEDFfcikGK2n3b5s==s4G9qOhkrVKobSpdgfEXI37W8cwn: GUD0pzT9ZBSHYqIFR5vbus62gJ = str(wPGIvQYum6*yylSaxCLfkte(u"࠶࠱ᔸ"))
	return GUD0pzT9ZBSHYqIFR5vbus62gJ
def U2SFOzhqClfsiu36P1j0YGrcx7d(SPszXI3WfaYplrM0B,Lb36WxGYHCaqrdU09jOsFcvAe=rC5tnFDlQcRGA2(u"ࠧ࠷࠵࠻࠸࠶࠾࠲࠴ࠩገ")):
	if SPszXI3WfaYplrM0B==CJlTSEpZsWb0QHg5w: return CJlTSEpZsWb0QHg5w
	SPszXI3WfaYplrM0B = int(SPszXI3WfaYplrM0B)+int(Lb36WxGYHCaqrdU09jOsFcvAe)
	wPGIvQYum6 = SPszXI3WfaYplrM0B^ggZJf7YnlXHT3IjtMaWe6S
	PdyHBpvCV8LuOZEDFfcikGK2n3b5s = SPszXI3WfaYplrM0B^DRmUs7l1O4xLeZYzGITXk
	s4G9qOhkrVKobSpdgfEXI37W8cwn = SPszXI3WfaYplrM0B^o1oDTrOyPliAC6QBcKXRathZGu9g4Y
	GUD0pzT9ZBSHYqIFR5vbus62gJ = str(wPGIvQYum6)+str(PdyHBpvCV8LuOZEDFfcikGK2n3b5s)+str(s4G9qOhkrVKobSpdgfEXI37W8cwn)
	return GUD0pzT9ZBSHYqIFR5vbus62gJ
def l0SfZzs3tbP9RInJMmvyDKG4VQH(SPszXI3WfaYplrM0B,Lb36WxGYHCaqrdU09jOsFcvAe=cbmeD4WNZfAowxT2JdUMtV(u"ࠨ࠸࠶࠼࠹࠷࠸࠳࠵ࠪጉ")):
	if SPszXI3WfaYplrM0B==CJlTSEpZsWb0QHg5w: return CJlTSEpZsWb0QHg5w
	SPszXI3WfaYplrM0B = str(SPszXI3WfaYplrM0B)
	G7N4Mz9HPU0CwasdkrRWgAu = int(len(SPszXI3WfaYplrM0B)/D9yBM7wPFLz)
	wPGIvQYum6 = int(SPszXI3WfaYplrM0B[ZVNvqy4iF1a9X:G7N4Mz9HPU0CwasdkrRWgAu])^ggZJf7YnlXHT3IjtMaWe6S
	PdyHBpvCV8LuOZEDFfcikGK2n3b5s = int(SPszXI3WfaYplrM0B[G7N4Mz9HPU0CwasdkrRWgAu:VTadWjBloMwXO2CH9GDK6FR*G7N4Mz9HPU0CwasdkrRWgAu])^DRmUs7l1O4xLeZYzGITXk
	s4G9qOhkrVKobSpdgfEXI37W8cwn = int(SPszXI3WfaYplrM0B[VTadWjBloMwXO2CH9GDK6FR*G7N4Mz9HPU0CwasdkrRWgAu:D9yBM7wPFLz*G7N4Mz9HPU0CwasdkrRWgAu])^o1oDTrOyPliAC6QBcKXRathZGu9g4Y
	GUD0pzT9ZBSHYqIFR5vbus62gJ = CJlTSEpZsWb0QHg5w
	if wPGIvQYum6==PdyHBpvCV8LuOZEDFfcikGK2n3b5s==s4G9qOhkrVKobSpdgfEXI37W8cwn: GUD0pzT9ZBSHYqIFR5vbus62gJ = str(int(wPGIvQYum6)-int(Lb36WxGYHCaqrdU09jOsFcvAe))
	return GUD0pzT9ZBSHYqIFR5vbus62gJ
def kZUfwBd4cbK5T3sxlJN(EWcvU5FHBg084otmAYel):
	rAF9R2CzWX7 = Ew2zQ8u7Ss.SITESURLS[VVvcQpCU3OM09n(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩጊ")][KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠹ᔹ")]
	lQBarcs2M98AGZUpuyNEhCk = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ጋ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡸࡱࡩ࡯ࡵࠪጌ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡊࡥࡧࡣࡸࡰࡹ࠭ግ"),KA26GucUHOwXL(u"࠭࠷࠳࠲ࡳࠫጎ"),otNfFapeEnO(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩጏ"))
	MUp4saOWjR3IgxHNnhiF6rm5SfGX9l,ZvNMCn3hbz0BIq = hhA3ineut0C1(lQBarcs2M98AGZUpuyNEhCk)
	MUp4saOWjR3IgxHNnhiF6rm5SfGX9l = U2SFOzhqClfsiu36P1j0YGrcx7d(MUp4saOWjR3IgxHNnhiF6rm5SfGX9l,EcjO3giln2kQTdBY0XLAG(u"ࠨ࠳࠵࠵࠽࠹࠱࠹࠷࠶ࠫጐ"))
	dZRXhoNY9EUmxF = {TDpFsQXHze2q30uYtGPfEIm8(u"ࠩ࡬ࡨࡸ࠭጑"):od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡈࡎࡇࡌࡐࡉࠪጒ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡺࡹࡲࠨጓ"):Ew2zQ8u7Ss.AV_CLIENT_IDS,o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡼࡥࡳࠩጔ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,zQGaM7ctZCN(u"࠭ࡳࡤࡴࠪጕ"):EWcvU5FHBg084otmAYel,VVvcQpCU3OM09n(u"ࠧࡴ࡫ࡽࠫ጖"):MUp4saOWjR3IgxHNnhiF6rm5SfGX9l}
	UUykzXVivDr7EpoJB6fHqnNYc = {o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ጗"):rC5tnFDlQcRGA2(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨጘ")}
	seItrUlFO8X5vmuJPMRTfpibWcCk = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡔࡔ࡙ࡔࠨጙ"),rAF9R2CzWX7,dZRXhoNY9EUmxF,UUykzXVivDr7EpoJB6fHqnNYc,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,GISOTJh20W(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡈࡐ࡙ࡢࡔࡑࡇ࡙ࡠࡆࡌࡅࡑࡕࡇ࠮࠳ࡶࡸࠬጚ"))
	ae3duE80wIC6ykh = seItrUlFO8X5vmuJPMRTfpibWcCk.content
	try:
		if not ae3duE80wIC6ykh: trFQKh2NI4lVE8nJWY9jA
		KKkIrlDy9Ev6cnCz5bj = oE7iT3HI5VDdmY4kPOjr(Olh7n0zfV4(u"ࠬࡪࡩࡤࡶࠪጛ"),ae3duE80wIC6ykh)
		fWFVbJkB9HCpdtT14iGqUyY7AORN6h = KKkIrlDy9Ev6cnCz5bj[KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭࡭ࡴࡩࠪጜ")]
		DNFiERQXhVmptlM = KKkIrlDy9Ev6cnCz5bj[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡴࡧࡦࠫጝ")]
		QQMmCEKIDSnyuxqk3ObeNYU5G = KKkIrlDy9Ev6cnCz5bj[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡵࡷࡴࠬጞ")]
		DNFiERQXhVmptlM = int(l0SfZzs3tbP9RInJMmvyDKG4VQH(DNFiERQXhVmptlM,GISOTJh20W(u"ࠩ࠴࠶࠶࠾࠳࠲࠺࠸࠷ࠬጟ")))
		QQMmCEKIDSnyuxqk3ObeNYU5G = int(l0SfZzs3tbP9RInJMmvyDKG4VQH(QQMmCEKIDSnyuxqk3ObeNYU5G,JACnOz297UuDK5HpPkc1LF(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ጠ")))
		for MwO9CRA0W4Z76YauvTBFIJQDHdU5 in range(DNFiERQXhVmptlM,ZVNvqy4iF1a9X,-QQMmCEKIDSnyuxqk3ObeNYU5G):
			if not eval(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲࡮ࡹࡐ࡭ࡣࡼ࡭ࡳ࡭ࠨࠪࠩጡ"),{cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡾࡢ࡮ࡥࠪጢ"):pKVikfGen4wMt80UTscxWjAoCZ5S}): trFQKh2NI4lVE8nJWY9jA
			KhwN2zcb7iMkjS5E4WURxByPGon(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ศศไํࠤ้๊สอำหอࠥ๎วๅใะูࠬጣ"),str(MwO9CRA0W4Z76YauvTBFIJQDHdU5)+TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࠡࠢฮห๋๐ษࠨጤ"),L8Wkv5KCSoq=yylSaxCLfkte(u"࠳࠳࠴ᔺ")*QQMmCEKIDSnyuxqk3ObeNYU5G)
			pKVikfGen4wMt80UTscxWjAoCZ5S.sleep(zQGaM7ctZCN(u"࠴࠴࠵࠶ᔻ")*QQMmCEKIDSnyuxqk3ObeNYU5G)
		if eval(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯࡫ࡶࡔࡱࡧࡹࡪࡰࡪࠬ࠮࠭ጥ"),{KA26GucUHOwXL(u"ࠩࡻࡦࡲࡩࠧጦ"):pKVikfGen4wMt80UTscxWjAoCZ5S}):
			fWFVbJkB9HCpdtT14iGqUyY7AORN6h = fWFVbJkB9HCpdtT14iGqUyY7AORN6h.replace(rJ9cgWz4FU,EcjO3giln2kQTdBY0XLAG(u"ࠪࡠࡡࡴࠧጧ")).replace(rScptJWVdgzQGR1E3LZ9byC,o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡡࡢࡲࠨጨ"))
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬิั้ฮࠪጩ"),TAExSfcoNi4eORZ8HPB,fWFVbJkB9HCpdtT14iGqUyY7AORN6h)
		trFQKh2NI4lVE8nJWY9jA
	except: exec(pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡳࡵࡱࡳࠬ࠮࠭ጪ"),{Olh7n0zfV4(u"ࠧࡹࡤࡰࡧࠬጫ"):pKVikfGen4wMt80UTscxWjAoCZ5S})
	return
def kTi75UVbJ4IG2onre():
	exec(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࠩࠪࠑࠏࡺࡲࡺ࠼ࠐࠎࠎࡽࡩ࡯ࡦࡲࡻ࠶࠸࠳ࠡ࠿ࠣࡼࡧࡳࡣࡨࡷ࡬࠲࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠷ࠬࠑࠏࠏࡷࡩ࡫࡯ࡩ࡚ࠥࡲࡶࡧ࠽ࠑࠏࠏࠉࡹࡤࡰࡧ࠳ࡹ࡬ࡦࡧࡳࠬ࠶࠶࠰࠱ࠫࠐࠎࠎࠏࡴࡳࡻ࠽ࠤࡼ࡯࡮ࡥࡱࡺ࠵࠷࠹࠮ࡨࡧࡷࡊࡴࡩࡵࡴࠪ࠴࠴࠵࠸࠵ࠪࠏࠍࠍࠎ࡫ࡸࡤࡧࡳࡸ࠿ࠦࡢࡳࡧࡤ࡯ࠒࠐࠉࡻࡥࡵࡩࡦࡺࡥࡠࡧࡵࡳࡷࡸࠍࠋࡧࡻࡧࡪࡶࡴ࠻ࠢࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠏࠍࠫࠬ࠭ጬ"),{xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡻࡦࡲࡩࡧࡶ࡫ࠪጭ"):rTF8V7fLD2SXJbAURpZjQ4wH,o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡼࡧࡳࡣࠨጮ"):pKVikfGen4wMt80UTscxWjAoCZ5S})
	return
def hhA3ineut0C1(gdGX631yzBwMoYjUpqNt):
	jLMUKcNImsv6TbYh4lyxX21,InaYgGyu8qjsp1lOAbe4rKWVz = ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(gdGX631yzBwMoYjUpqNt):
		try: jLMUKcNImsv6TbYh4lyxX21 = tiFgl4DMvGEAUfjIYkHbr05.path.getsize(gdGX631yzBwMoYjUpqNt)
		except: pass
		if not jLMUKcNImsv6TbYh4lyxX21:
			try: jLMUKcNImsv6TbYh4lyxX21 = tiFgl4DMvGEAUfjIYkHbr05.stat(gdGX631yzBwMoYjUpqNt).st_size
			except: pass
		if not jLMUKcNImsv6TbYh4lyxX21:
			try:
				from pathlib import Path as OUEP3ryZR64wfacVNmzXLlS
				jLMUKcNImsv6TbYh4lyxX21 = OUEP3ryZR64wfacVNmzXLlS(gdGX631yzBwMoYjUpqNt).stat().st_size
			except: pass
		if jLMUKcNImsv6TbYh4lyxX21: InaYgGyu8qjsp1lOAbe4rKWVz = P2Fgh6TCOWoaHjkqBcQnvRNXe
	return jLMUKcNImsv6TbYh4lyxX21,InaYgGyu8qjsp1lOAbe4rKWVz
def Fu7PUy1x6wh2(u6ubhFi9fLC8SQVPpraxwgH7y3dz,showDialogs):
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,u6ubhFi9fLC8SQVPpraxwgH7y3dz+E6xdOMpqISHZCn(u"ࠫࡡࡴ࡜࡯ࠩጯ")+Dj62UpP5MrbTkJqhRa+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬํไࠡฬิ๎ิࠦๅิฯ๋ࠣีอࠠศๆ่่ๆࠦฟࠢࠩጰ")+oOQaRxBXyJ5jVnZ)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=h6sIkJOT5PB2vCxqo4LFag70wA(u"࠵ᔼ"): return VJZIMkUN5siqB21Pf
	succeeded = w2qb6lf5EM
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(u6ubhFi9fLC8SQVPpraxwgH7y3dz):
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(u6ubhFi9fLC8SQVPpraxwgH7y3dz.decode(Im5KSGZYBpRvdMVsbuXg))
		except:
			try: tiFgl4DMvGEAUfjIYkHbr05.remove(wSs8Y0HDJl4zoh9j)
			except Exception as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
				succeeded = VJZIMkUN5siqB21Pf
				if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn))
	if showDialogs:
		if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KA26GucUHOwXL(u"࠭แีๆอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆ࠭ጱ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨጲ"))
	return succeeded
def xyP9q8HGgDkNbL4WFnd5lfVh(JCkKANe5tqLdjnSb7,GGgb7enZsOIP8LXFMyu0NUWEdt,showDialogs):
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JCkKANe5tqLdjnSb7+pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࡞ࡱࡠࡳ࠭ጳ")+Dj62UpP5MrbTkJqhRa+KA26GucUHOwXL(u"๊่ࠩࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧጴ")+oOQaRxBXyJ5jVnZ)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=P2Fgh6TCOWoaHjkqBcQnvRNXe: return VJZIMkUN5siqB21Pf
	succeeded = w2qb6lf5EM
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(JCkKANe5tqLdjnSb7):
		for mv9lp6NGakCrdLsYP,y50BXKCecjEZuJWNwHV,BUNKAJQ3WLiVXbc in tiFgl4DMvGEAUfjIYkHbr05.walk(JCkKANe5tqLdjnSb7,topdown=VJZIMkUN5siqB21Pf):
			for gdGX631yzBwMoYjUpqNt in BUNKAJQ3WLiVXbc:
				H34pwYZBaRzOuA = tiFgl4DMvGEAUfjIYkHbr05.path.join(mv9lp6NGakCrdLsYP,gdGX631yzBwMoYjUpqNt)
				try: tiFgl4DMvGEAUfjIYkHbr05.remove(H34pwYZBaRzOuA)
				except Exception as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
					succeeded = VJZIMkUN5siqB21Pf
					if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn))
			if GGgb7enZsOIP8LXFMyu0NUWEdt:
				for dir in y50BXKCecjEZuJWNwHV:
					FvTzqfmBX45bVGgODprR = tiFgl4DMvGEAUfjIYkHbr05.path.join(mv9lp6NGakCrdLsYP,dir)
					try: tiFgl4DMvGEAUfjIYkHbr05.rmdir(FvTzqfmBX45bVGgODprR)
					except: pass
		if GGgb7enZsOIP8LXFMyu0NUWEdt:
			try: tiFgl4DMvGEAUfjIYkHbr05.rmdir(mv9lp6NGakCrdLsYP)
			except: pass
	if showDialogs:
		if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Olh7n0zfV4(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫጵ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,XB4CjMkPFzhAHiI3q(u"้๊ࠫริใࠣๅู๊สࠡ฻่่๏ฯࠠศๆ่ืา࠭ጶ"))
	return succeeded
def WYpLnF8SEJ64(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,nqVYufmd4GFshQeHO9vp05):
	BBwfuWGxUIrdCoc4ka7,iSNtwvQFHbA,norNEp9J308Y7MScPvRG1A2B,br0nG1O7vxmtPoqTJXsVKWyCkEY = EuX7CkI8cK5b0YO1WVwQMy(otaunYGVIJ2jX8HsKm7ecR0bAh4)
	ZBstQ7jF04zNp8EmHoY5A = por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3
	if JtQnzkyrlEG0aZ6mx4c<xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠵ᔽ"):
		oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,cjVhOCwybeRo7UWg92(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡕࡓࡎࡏࡍࡇ࠭ጷ"),ZBstQ7jF04zNp8EmHoY5A)
		JtQnzkyrlEG0aZ6mx4c = -JtQnzkyrlEG0aZ6mx4c
	if JtQnzkyrlEG0aZ6mx4c>cbmeD4WNZfAowxT2JdUMtV(u"࠶ᔾ"):
		z4YnlxGHF2AMtrw = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,KA26GucUHOwXL(u"࠭ࡳࡵࡴࠪጸ"),cjVhOCwybeRo7UWg92(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡗࡕࡐࡑࡏࡂࠨጹ"),ZBstQ7jF04zNp8EmHoY5A)
		if z4YnlxGHF2AMtrw:
			B6Ul0f5eTI8atPymFdXoiANcjK7g9(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡗࡕࡐࡑࡏࡂࠡࠢࡕࡉࡆࡊ࡟ࡄࡃࡆࡌࡊ࠭ጺ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,nqVYufmd4GFshQeHO9vp05,por2itPgjLlh5fAb3z47nFvUJE)
			return z4YnlxGHF2AMtrw
	z4YnlxGHF2AMtrw = bQs8X1eOM6vauSBpIK5q0tJfDLwNn(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,nqVYufmd4GFshQeHO9vp05)
	if z4YnlxGHF2AMtrw and JtQnzkyrlEG0aZ6mx4c: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢ࡙ࡗࡒࡌࡊࡄࠪጻ"),ZBstQ7jF04zNp8EmHoY5A,z4YnlxGHF2AMtrw,JtQnzkyrlEG0aZ6mx4c)
	return z4YnlxGHF2AMtrw
def FWK9ZMPpVauYrEH2v(T1QDsJlUtCGhn,XOxU2FnTMeYI,sRSwkE4FQD2=ZVNvqy4iF1a9X):
	aYyNJlQdwG5FX = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡢࡪࡶࡵࡥࡹ࡫ࠧጼ"))
	if aYyNJlQdwG5FX and zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫ࠲࠭ጽ") not in aYyNJlQdwG5FX: TT7WzUmOPGJIbheSrXvukiDj30c,lq5ASwHTrY76FEQ4ZKsJuGOC9dvm = int(aYyNJlQdwG5FX),w2qb6lf5EM
	elif sRSwkE4FQD2: TT7WzUmOPGJIbheSrXvukiDj30c,lq5ASwHTrY76FEQ4ZKsJuGOC9dvm = sRSwkE4FQD2,VJZIMkUN5siqB21Pf
	else: return []
	JRXn54gp3ABzO,WVzdRfFHp0NPjolQgh7A5qS6yI = [],CJlTSEpZsWb0QHg5w
	tPVDgEYod0cAMRH5pUv74nkL6uWI,NQjdrPi4JxWtqKgRD0,xqznTpB34ot0yjmPDvKbH,cAqv0MLal8sXQd6EWk = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
	XOxU2FnTMeYI = sorted(XOxU2FnTMeYI,reverse=w2qb6lf5EM,key=lambda key: (key[P2Fgh6TCOWoaHjkqBcQnvRNXe],key[VTadWjBloMwXO2CH9GDK6FR]))
	for stream,beoJENLAUaR2XcwIBvZVfjk0,ksDvwLIca3bHm in XOxU2FnTMeYI+[[CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZVNvqy4iF1a9X]]:
		if beoJENLAUaR2XcwIBvZVfjk0==WVzdRfFHp0NPjolQgh7A5qS6yI:
			if ksDvwLIca3bHm>TT7WzUmOPGJIbheSrXvukiDj30c: NQjdrPi4JxWtqKgRD0,cAqv0MLal8sXQd6EWk = stream,ksDvwLIca3bHm
			elif not tPVDgEYod0cAMRH5pUv74nkL6uWI: tPVDgEYod0cAMRH5pUv74nkL6uWI,xqznTpB34ot0yjmPDvKbH = stream,ksDvwLIca3bHm
		else:
			if NQjdrPi4JxWtqKgRD0 or tPVDgEYod0cAMRH5pUv74nkL6uWI:
				if tPVDgEYod0cAMRH5pUv74nkL6uWI: JRXn54gp3ABzO.append([tPVDgEYod0cAMRH5pUv74nkL6uWI,WVzdRfFHp0NPjolQgh7A5qS6yI,xqznTpB34ot0yjmPDvKbH])
				elif NQjdrPi4JxWtqKgRD0: JRXn54gp3ABzO.append([NQjdrPi4JxWtqKgRD0,WVzdRfFHp0NPjolQgh7A5qS6yI,cAqv0MLal8sXQd6EWk])
			if ksDvwLIca3bHm>TT7WzUmOPGJIbheSrXvukiDj30c:
				NQjdrPi4JxWtqKgRD0,cAqv0MLal8sXQd6EWk = stream,ksDvwLIca3bHm
				tPVDgEYod0cAMRH5pUv74nkL6uWI,xqznTpB34ot0yjmPDvKbH = CJlTSEpZsWb0QHg5w,ZVNvqy4iF1a9X
			else:
				NQjdrPi4JxWtqKgRD0,cAqv0MLal8sXQd6EWk = CJlTSEpZsWb0QHg5w,ZVNvqy4iF1a9X
				tPVDgEYod0cAMRH5pUv74nkL6uWI,xqznTpB34ot0yjmPDvKbH = stream,ksDvwLIca3bHm
		WVzdRfFHp0NPjolQgh7A5qS6yI = beoJENLAUaR2XcwIBvZVfjk0
	if lq5ASwHTrY76FEQ4ZKsJuGOC9dvm:
		X05xlEUFQ2edTgCcDHPki9h6omB8AZ,wFTdl0nDmLu9AV1RYp,Ds8P5JTdj7luQ3mLcqHB = zip(*JRXn54gp3ABzO)
		HuvflP02BQw = [HaTI5u1f3SCxmMAkw(u"ࠬࡳࡰ࠵ࠩጾ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭࡭ࡱࡦࠪጿ"),s97s2k0LJgl(u"ࠧࡵࡵࠪፀ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨ࡯࠶ࡹࠬፁ")]
		for beoJENLAUaR2XcwIBvZVfjk0 in HuvflP02BQw:
			if beoJENLAUaR2XcwIBvZVfjk0 in wFTdl0nDmLu9AV1RYp:
				index = wFTdl0nDmLu9AV1RYp.index(beoJENLAUaR2XcwIBvZVfjk0)
				JRXn54gp3ABzO = [[X05xlEUFQ2edTgCcDHPki9h6omB8AZ[index],wFTdl0nDmLu9AV1RYp[index],Ds8P5JTdj7luQ3mLcqHB[index]]]
				break
	return JRXn54gp3ABzO
def KQI8YgWzhmCV4T(NqYfA9CbvJsZyL):
	QBxaTRrmMjF9ptn,CCdnrIfkXLesuyj5bgxWlcq = [],gZvlfk6xhACbXcD5j0KBLiVM1
	for ad3z2451e09FrDHmvci in rBou7qEXe4GUPnYMp6Af9yh:
		if ad3z2451e09FrDHmvci==KA26GucUHOwXL(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪፂ"): CCdnrIfkXLesuyj5bgxWlcq = (yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡰ࡮ࡴ࡫ࠨፃ"),Dj62UpP5MrbTkJqhRa+mi2ZJXCDzITuyev6gfn(u"๊ࠫ๎วใ฻ࠣื๏ืแาษอࠤำอีสࠢ࠰ࠤ็๊๊ๅหࠣห้๋ิศๅ็ࠫፄ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠱࠶࠹ᔿ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)
		elif ad3z2451e09FrDHmvci==EcjO3giln2kQTdBY0XLAG(u"ࠬࡓࡉ࡙ࡇࡇࠫፅ"): CCdnrIfkXLesuyj5bgxWlcq = (E6xdOMpqISHZCn(u"࠭࡬ࡪࡰ࡮ࠫፆ"),Dj62UpP5MrbTkJqhRa+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧๆ๊สๆ฾ࠦำ๋ำไีฬะࠠฯษุอࠥ๎ูศ็ฬࠤ࠲ࠦใฬ์ิอࠥอไๆึส็้࠭ፇ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"࠲࠷࠺ᕀ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)
		elif ad3z2451e09FrDHmvci==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡒࡘࡆࡑࡏࡃࠨፈ"): CCdnrIfkXLesuyj5bgxWlcq = (zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩ࡯࡭ࡳࡱࠧፉ"),Dj62UpP5MrbTkJqhRa+yUMRP0QKIzY9BDnsV784TZmwkf(u"้ࠪํอโฺࠢึ๎ึ็ัศฬࠣ฽ฬ๋ษࠡ࠯ࠣ็ะ๐ัสࠢสฺ่๊วไๆࠪፊ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"࠳࠸࠻ᕁ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)
		if ad3z2451e09FrDHmvci not in NqYfA9CbvJsZyL: continue
		if CCdnrIfkXLesuyj5bgxWlcq:
			QBxaTRrmMjF9ptn.append(CCdnrIfkXLesuyj5bgxWlcq)
			CCdnrIfkXLesuyj5bgxWlcq = gZvlfk6xhACbXcD5j0KBLiVM1
		if ad3z2451e09FrDHmvci not in [otNfFapeEnO(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬፋ"),s97s2k0LJgl(u"ࠬࡓࡉ࡙ࡇࡇࠫፌ"),VVvcQpCU3OM09n(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ፍ")]: QBxaTRrmMjF9ptn.append(ad3z2451e09FrDHmvci)
	return QBxaTRrmMjF9ptn
def k7Y4iwed8cNbGHxfvK(T8bu9htUiPDwWlHaS426g,args=[]):
	UUykzXVivDr7EpoJB6fHqnNYc = {cjVhOCwybeRo7UWg92(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ፎ"):XB4CjMkPFzhAHiI3q(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫፏ")}
	uiLldJmwVbWXaAFOPC8,g2T7uYwO5bp,xxhL4jGYMa3kbQOtudlPJrpwmViRo = cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡹࡧࡧࡩ࠶࠶࠵࠷࠺࡬࡬ࡨࡣࡰࡼࡱࡺࡰ࡫ࠨፐ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࠸࠸ࡼࡣࡷ࠵ࡧࡪ࡬ࡰ࡫ࡰ࠹࠻ࡷࡽࢀࡤ࠳ࠩፑ"),int(L8Wkv5KCSoq.time())
	JucvlaLMXOI5BVf = uiLldJmwVbWXaAFOPC8+kaJFzbfodQNDR79cYjnw1yU5+str(xxhL4jGYMa3kbQOtudlPJrpwmViRo)+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+g2T7uYwO5bp
	DajqVM3ptOGR6Cr2KyQoSYw = jRBlVKHJ7fOx.md5(JucvlaLMXOI5BVf.encode(mi2ZJXCDzITuyev6gfn(u"ࠫࡺࡺࡦ࠹ࠩፒ"))).hexdigest()[:JACnOz297UuDK5HpPkc1LF(u"࠶࠶ᕂ")]
	dZRXhoNY9EUmxF = {I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡰࡳࡤࡱࡧࡩࠬፓ"):T8bu9htUiPDwWlHaS426g,pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡡࡳࡩࡶࠫፔ"):args,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡶࡵࡨࡶࠬፕ"):kaJFzbfodQNDR79cYjnw1yU5,o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩፖ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,E6xdOMpqISHZCn(u"ࠩ࡬ࡨࡸ࠭ፗ"):DajqVM3ptOGR6Cr2KyQoSYw}
	dZRXhoNY9EUmxF = KSHcVmz2W84iQvbRDBhGldpCL.dumps(dZRXhoNY9EUmxF)
	ShEVOkweJNn = Ew2zQ8u7Ss.SITESURLS[HaTI5u1f3SCxmMAkw(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪፘ")][cbmeD4WNZfAowxT2JdUMtV(u"࠵࠵ᕃ")]
	seItrUlFO8X5vmuJPMRTfpibWcCk = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡕࡕࡓࡕࠩፙ"),ShEVOkweJNn,dZRXhoNY9EUmxF,UUykzXVivDr7EpoJB6fHqnNYc,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡇࡆ࡙࡙ࡋ࡟ࡋࡕ࠰࠵ࡸࡺࠧፚ"))
	ae3duE80wIC6ykh = seItrUlFO8X5vmuJPMRTfpibWcCk.content
	return ae3duE80wIC6ykh
def UUwxvmgjdH2(iPoOA4EL8q,timeout,VmXaSkJsZ1HUfM7Ax6CvGr,MMnacmt8oYiI5zeG7,uQpWSenP8o4NGaxMTcm17VEJtY3A):
	Lz9tmBbO5uaInCZspSycjoDWYT = VJZIMkUN5siqB21Pf
	for YTrkBfgQc4upSjKHt in iPoOA4EL8q:
		YTrkBfgQc4upSjKHt.start()
		L8Wkv5KCSoq.sleep(VmXaSkJsZ1HUfM7Ax6CvGr)
		Lz9tmBbO5uaInCZspSycjoDWYT = uQpWSenP8o4NGaxMTcm17VEJtY3A()
		if Lz9tmBbO5uaInCZspSycjoDWYT: break
	else:
		LLcOnG4zgtBmWdkT1f0sKe = int(timeout-len(iPoOA4EL8q)*VmXaSkJsZ1HUfM7Ax6CvGr)
		if LLcOnG4zgtBmWdkT1f0sKe>ZVNvqy4iF1a9X:
			for Cm7xuRTdLQwZjv81V2AhKfqs04U in range(LLcOnG4zgtBmWdkT1f0sKe//MMnacmt8oYiI5zeG7):
				L8Wkv5KCSoq.sleep(MMnacmt8oYiI5zeG7)
				Lz9tmBbO5uaInCZspSycjoDWYT = uQpWSenP8o4NGaxMTcm17VEJtY3A()
				if Lz9tmBbO5uaInCZspSycjoDWYT: break
	for YTrkBfgQc4upSjKHt in iPoOA4EL8q:
		try: YTrkBfgQc4upSjKHt.join(VmXaSkJsZ1HUfM7Ax6CvGr)
		except: pass
	return Lz9tmBbO5uaInCZspSycjoDWYT
def BBGMAjz64tElUg(yqz94jVokMam0ZXJDchPKw=fhV49mDA6YK0):
	Zk0CxUQLfFYut75gXBesSlnJWh2 = rC5tnFDlQcRGA2(u"࠶࠶࠲࠵ᕄ")
	Ji8sp3FWKn4whl = ZVNvqy4iF1a9X
	if not Ji8sp3FWKn4whl:
		try:
			import shutil as hc96LKuEjAkB5eHaS0
			Ji8sp3FWKn4whl = hc96LKuEjAkB5eHaS0.disk_usage(yqz94jVokMam0ZXJDchPKw).free
		except: pass
	if not Ji8sp3FWKn4whl and hasattr(tiFgl4DMvGEAUfjIYkHbr05,yylSaxCLfkte(u"࠭ࡳࡵࡣࡷࡺ࡫ࡹࠧ፛")):
		try:
			FaYwL3vEmuinCW5rID2sTZ = tiFgl4DMvGEAUfjIYkHbr05.statvfs(yqz94jVokMam0ZXJDchPKw)
			Ji8sp3FWKn4whl = FaYwL3vEmuinCW5rID2sTZ.f_frsize * FaYwL3vEmuinCW5rID2sTZ.f_bavail
		except: pass
	if not Ji8sp3FWKn4whl and hasattr(tiFgl4DMvGEAUfjIYkHbr05,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡧࡵࡷࡥࡹࡼࡦࡴࠩ፜")):
		try:
			FaYwL3vEmuinCW5rID2sTZ = tiFgl4DMvGEAUfjIYkHbr05.fstatvfs(yqz94jVokMam0ZXJDchPKw)
			Ji8sp3FWKn4whl = FaYwL3vEmuinCW5rID2sTZ.f_frsize * FaYwL3vEmuinCW5rID2sTZ.f_bavail
		except: pass
	if not Ji8sp3FWKn4whl and A8v6c2fL7egwWCF3YBqr4kXSRn.platform == HaTI5u1f3SCxmMAkw(u"ࠨࡹ࡬ࡲ࠸࠸ࠧ፝"):
		try:
			import ctypes as uKpzDO08Wak4MFV
			qRW3yge6trZXb9IBFhG5jMofuvEHw = uKpzDO08Wak4MFV.c_ulonglong(ZVNvqy4iF1a9X)
			uKpzDO08Wak4MFV.windll.kernel32.GetDiskFreeSpaceExW(uKpzDO08Wak4MFV.c_wchar_p(yqz94jVokMam0ZXJDchPKw),None,None,uKpzDO08Wak4MFV.pointer(qRW3yge6trZXb9IBFhG5jMofuvEHw))
			Ji8sp3FWKn4whl = qRW3yge6trZXb9IBFhG5jMofuvEHw.value
		except: pass
	if not Ji8sp3FWKn4whl:
		try:
			ODN5q2cdTpoBfusvF = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶࡪ࡫ࡓࡱࡣࡦࡩࠬ፞"))
			PV3NhEdcr6Ke0USBYLIwOgfQzATFom = Zy2l0g8QU5vqefaTrsw.findall(yylSaxCLfkte(u"ࠪࡠࡩ࠱ࠨࡀ࠼࡟࠲ࡡࡪࠫࠪࡁࠪ፟"),ODN5q2cdTpoBfusvF,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if PV3NhEdcr6Ke0USBYLIwOgfQzATFom:
				PV3NhEdcr6Ke0USBYLIwOgfQzATFom = float(PV3NhEdcr6Ke0USBYLIwOgfQzATFom[otNfFapeEnO(u"࠶ᕅ")])
				if   KA26GucUHOwXL(u"࡙ࠫ࠭፠") in ODN5q2cdTpoBfusvF: Ji8sp3FWKn4whl = PV3NhEdcr6Ke0USBYLIwOgfQzATFom*Zk0CxUQLfFYut75gXBesSlnJWh2**P3cpaLN2sH
				elif yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡍࠧ፡") in ODN5q2cdTpoBfusvF: Ji8sp3FWKn4whl = PV3NhEdcr6Ke0USBYLIwOgfQzATFom*Zk0CxUQLfFYut75gXBesSlnJWh2**D9yBM7wPFLz
				elif cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡍࠨ።") in ODN5q2cdTpoBfusvF: Ji8sp3FWKn4whl = PV3NhEdcr6Ke0USBYLIwOgfQzATFom*Zk0CxUQLfFYut75gXBesSlnJWh2**VTadWjBloMwXO2CH9GDK6FR
				elif E6xdOMpqISHZCn(u"ࠧࡌࠩ፣") in ODN5q2cdTpoBfusvF: Ji8sp3FWKn4whl = PV3NhEdcr6Ke0USBYLIwOgfQzATFom*Zk0CxUQLfFYut75gXBesSlnJWh2
				else: Ji8sp3FWKn4whl = PV3NhEdcr6Ke0USBYLIwOgfQzATFom
		except: pass
	if not Ji8sp3FWKn4whl: Ji8sp3FWKn4whl = mi2ZJXCDzITuyev6gfn(u"࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿࠹ᕆ")
	return int(Ji8sp3FWKn4whl)
def G10GgN7HuBYaklXP6F4(TpGRx3umFIEKey1i0XNz8CnJ):
	if TpGRx3umFIEKey1i0XNz8CnJ:
		KTcOx6HBR9jJ8VS = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,yylSaxCLfkte(u"ࠨ࡮࡬ࡷࡹ࠭፤"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠸ࠧ፥"),Olh7n0zfV4(u"ࠪࡗࡎ࡚ࡅࡔࡡࡘࡗࡆࡍࡅࠨ፦"))
		if KTcOx6HBR9jJ8VS: return KTcOx6HBR9jJ8VS
	wSfEHOilLYIK = {JACnOz297UuDK5HpPkc1LF(u"ࠫࡦ࠭፧"):NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡧࠧ፨")}
	url = Ew2zQ8u7Ss.SITESURLS[XB4CjMkPFzhAHiI3q(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭፩")][P2Fgh6TCOWoaHjkqBcQnvRNXe]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,EcjO3giln2kQTdBY0XLAG(u"ࠧࡑࡑࡖࡘࠬ፪"),url,wSfEHOilLYIK,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,GISOTJh20W(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡋࡊ࡚࡟ࡔࡋࡗࡉࡘࡥࡕࡔࡃࡊࡉ࠲࠷ࡳࡵࠩ፫"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(s97s2k0LJgl(u"ࠩࡘࡲ࡮ࡺࡥࡥࠢࡖࡸࡦࡺࡥࡴࠩ፬"),EcjO3giln2kQTdBY0XLAG(u"࡙ࠪࡘࡇࠧ፭"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"࡚ࠫࡴࡩࡵࡧࡧࠤࡐ࡯࡮ࡨࡦࡲࡱࠬ፮"),O4F8UC5lMAS6ghETm1VoPDI(u"࡛ࠬࡋࠨ፯"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡕ࡯࡫ࡷࡩࡩࠦࡁࡳࡣࡥࠤࡊࡳࡩࡳࡣࡷࡩࡸ࠭፰"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡖࡃࡈࠫ፱"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡕࡤࡹࡩ࡯ࠠࡂࡴࡤࡦ࡮ࡧࠧ፲"),cjVhOCwybeRo7UWg92(u"ࠩࡎࡗࡆ࠭፳"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡒࡴࡸࡴࡩࠢࡐࡥࡨ࡫ࡤࡰࡰ࡬ࡥࠬ፴"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡓ࠴ࡍࡢࡥࡨࡨࡴࡴࡩࡢࠩ፵"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(mi2ZJXCDzITuyev6gfn(u"ࠬ࡝ࡥࡴࡶࡨࡶࡳࠦࡓࡢࡪࡤࡶࡦ࠭፶"),O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡗ࠯ࡕࡤ࡬ࡦࡸࡡࠨ፷"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡠࡡࡢࠫ፸"),gCc52XVMGfAnOe)
	try: FE4fIaSb9mtqXBvxZnwp = oE7iT3HI5VDdmY4kPOjr(JACnOz297UuDK5HpPkc1LF(u"ࠨ࡮࡬ࡷࡹ࠭፹"),bGIVq1CQTjmosZg)
	except:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,otNfFapeEnO(u"ࠩไุ้ࠦแ๋ࠢฯ่อࠦๅฮฬ๋๎ฬะࠠหไิ๎ึࠦวๅษึฮำีวๆࠩ፺"))
		return
	x3xnGo4CYzf9wTrP2WO,ZJvLbAjIBT8d6kr4VhH7N5PfzUt,ZuPwHM5X97aQo8AKi0tbezB = FE4fIaSb9mtqXBvxZnwp
	mlQLVIyOKqAuvCZ,sUiHLS38dbKXqcC9Z = [],[]
	for ad3z2451e09FrDHmvci,u7yIZvUxqEJFThR9PWzlAMc,N8adt2xSLvXEUfj6koMQOF in ZJvLbAjIBT8d6kr4VhH7N5PfzUt:
		if u7yIZvUxqEJFThR9PWzlAMc.isdigit(): u7yIZvUxqEJFThR9PWzlAMc = XB4CjMkPFzhAHiI3q(u"ࠪ࡬࡮࡭ࡨࡶࡵࡤ࡫ࡪ࠭፻") if int(u7yIZvUxqEJFThR9PWzlAMc)>otNfFapeEnO(u"࠶࠲ᕇ") else cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡱࡵࡷࡶࡵࡤ࡫ࡪ࠭፼")
		if ad3z2451e09FrDHmvci not in Ew2zQ8u7Ss.non_videos_actions:
			if   u7yIZvUxqEJFThR9PWzlAMc==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ࡮ࡩࡨࡪࡸࡷࡦ࡭ࡥࠨ፽"): mlQLVIyOKqAuvCZ.append(ad3z2451e09FrDHmvci)
			elif u7yIZvUxqEJFThR9PWzlAMc==KA26GucUHOwXL(u"࠭࡬ࡰࡹࡸࡷࡦ࡭ࡥࠨ፾"): sUiHLS38dbKXqcC9Z.append(ad3z2451e09FrDHmvci)
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,s97s2k0LJgl(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࡢ࠶ࠬ፿"),Olh7n0zfV4(u"ࠨࡕࡌࡘࡊ࡙࡟ࡖࡕࡄࡋࡊ࠭ᎀ"),[FE4fIaSb9mtqXBvxZnwp,mlQLVIyOKqAuvCZ,sUiHLS38dbKXqcC9Z],DRmUs7l1O4xLeZYzGITXk)
	return FE4fIaSb9mtqXBvxZnwp,mlQLVIyOKqAuvCZ,sUiHLS38dbKXqcC9Z
def DNq5CJHPR3G7uX8pbngwF9T(JtQnzkyrlEG0aZ6mx4c,por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP=CJlTSEpZsWb0QHg5w,bhoLXAYz37qSr=CJlTSEpZsWb0QHg5w):
	if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࠽࠾ࠬᎁ") in por2itPgjLlh5fAb3z47nFvUJE: por2itPgjLlh5fAb3z47nFvUJE,kcxAmftieK56PE9TqbDHdSrF8 = por2itPgjLlh5fAb3z47nFvUJE.split(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪ࠾࠿࠭ᎂ"))
	else: por2itPgjLlh5fAb3z47nFvUJE,kcxAmftieK56PE9TqbDHdSrF8 = por2itPgjLlh5fAb3z47nFvUJE,O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࠬᎃ")
	BBwfuWGxUIrdCoc4ka7,iSNtwvQFHbA,norNEp9J308Y7MScPvRG1A2B,br0nG1O7vxmtPoqTJXsVKWyCkEY = EuX7CkI8cK5b0YO1WVwQMy(otaunYGVIJ2jX8HsKm7ecR0bAh4)
	hQUrtWgASbesqXxLD78YzR0BO = Dfi7FTuYWN49AaLEt3.copy() if isinstance(Dfi7FTuYWN49AaLEt3,dict) else Dfi7FTuYWN49AaLEt3
	ZBstQ7jF04zNp8EmHoY5A = por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,qPWgu3zkRbrv74yho,hQUrtWgASbesqXxLD78YzR0BO,kHXci2ESlxLf
	if JtQnzkyrlEG0aZ6mx4c<ZVNvqy4iF1a9X:
		oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᎄ"),ZBstQ7jF04zNp8EmHoY5A)
		JtQnzkyrlEG0aZ6mx4c = -JtQnzkyrlEG0aZ6mx4c
	if JtQnzkyrlEG0aZ6mx4c>ZVNvqy4iF1a9X:
		cDXLPHnAgY6NOk1GVStoiEx = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨᎅ"),rC5tnFDlQcRGA2(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᎆ"),ZBstQ7jF04zNp8EmHoY5A)
		if cDXLPHnAgY6NOk1GVStoiEx.succeeded:
			B6Ul0f5eTI8atPymFdXoiANcjK7g9(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᎇ"),BBwfuWGxUIrdCoc4ka7,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,nqVYufmd4GFshQeHO9vp05,por2itPgjLlh5fAb3z47nFvUJE)
			return cDXLPHnAgY6NOk1GVStoiEx
	if kcxAmftieK56PE9TqbDHdSrF8==o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࠫᎈ"): cDXLPHnAgY6NOk1GVStoiEx = epDHqUwf9S4RAC6h3Yd8LsPVb(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05)
	else: cDXLPHnAgY6NOk1GVStoiEx = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP,bhoLXAYz37qSr)
	if cDXLPHnAgY6NOk1GVStoiEx.succeeded:
		if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡇࡎࡓࡁࡏࡑ࡚ࠫᎉ") in nqVYufmd4GFshQeHO9vp05: cDXLPHnAgY6NOk1GVStoiEx.content = EEa4ITHuLq82tv7Yx9ZzOQVD(cDXLPHnAgY6NOk1GVStoiEx.content)
		if cDXLPHnAgY6NOk1GVStoiEx.scrape: JtQnzkyrlEG0aZ6mx4c = ggZJf7YnlXHT3IjtMaWe6S
		if JtQnzkyrlEG0aZ6mx4c and cDXLPHnAgY6NOk1GVStoiEx.content: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧᎊ"),ZBstQ7jF04zNp8EmHoY5A,cDXLPHnAgY6NOk1GVStoiEx,JtQnzkyrlEG0aZ6mx4c)
	return cDXLPHnAgY6NOk1GVStoiEx
def LLcxjIKwGTE5Ra4gq2tU8mvrdN(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,data,headers,allow_redirects,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP,bhoLXAYz37qSr):
	if data==CJlTSEpZsWb0QHg5w: data = {}
	if headers==CJlTSEpZsWb0QHg5w: headers = {}
	UxFZj4yc65Yr2SDQavCALeoH7sk = w2qb6lf5EM if allow_redirects in [CJlTSEpZsWb0QHg5w,w2qb6lf5EM] else VJZIMkUN5siqB21Pf
	jRM2XgKnTPx = w2qb6lf5EM if showDialogs in [CJlTSEpZsWb0QHg5w,w2qb6lf5EM] else VJZIMkUN5siqB21Pf
	aPHyKJYpoAxQ = w2qb6lf5EM if hh02Dy49ZltkecdFgP in [CJlTSEpZsWb0QHg5w,w2qb6lf5EM] else VJZIMkUN5siqB21Pf
	ihHQsmlJjcNqPdST9 = w2qb6lf5EM if bhoLXAYz37qSr in [CJlTSEpZsWb0QHg5w,w2qb6lf5EM] else VJZIMkUN5siqB21Pf
	s502yd81FCuJmLVBlkPtxih9fZDA = data
	bsGedm1TLP7EgiUQDkCy = headers
	jRM2XgKnTPx = jRM2XgKnTPx if Ew2zQ8u7Ss.ALLOW_SHOWDIALOGS_FIX==gZvlfk6xhACbXcD5j0KBLiVM1 else Ew2zQ8u7Ss.ALLOW_SHOWDIALOGS_FIX
	aPHyKJYpoAxQ = aPHyKJYpoAxQ if Ew2zQ8u7Ss.ALLOW_DNS_FIX==gZvlfk6xhACbXcD5j0KBLiVM1 else Ew2zQ8u7Ss.ALLOW_DNS_FIX
	ihHQsmlJjcNqPdST9 = ihHQsmlJjcNqPdST9 if Ew2zQ8u7Ss.ALLOW_PROXY_FIX==gZvlfk6xhACbXcD5j0KBLiVM1 else Ew2zQ8u7Ss.ALLOW_PROXY_FIX
	if nqVYufmd4GFshQeHO9vp05==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡊࡐࡖࡘࡆࡒࡌࡠࡑࡏࡈࡤࡘࡅࡍࡇࡄࡗࡊ࠳࠱ࡴࡶࠪᎋ"): bsGedm1TLP7EgiUQDkCy = {}
	else:
		CVZYOa68wET2oUnFpHPgS0R = list(bsGedm1TLP7EgiUQDkCy.keys())
		if od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᎌ") not in CVZYOa68wET2oUnFpHPgS0R: bsGedm1TLP7EgiUQDkCy[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᎍ")] = Olh7n0zfV4(u"ࠨࡪࡷࡸࡵ࠭ᎎ")
		if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᎏ") not in CVZYOa68wET2oUnFpHPgS0R: bsGedm1TLP7EgiUQDkCy[ZP1LyUCS3pIBu(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᎐")] = jQW9RpucaCLHX0sSBD6lrif58e47nt(w2qb6lf5EM)
	return por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,aPHyKJYpoAxQ,ihHQsmlJjcNqPdST9
def pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP=CJlTSEpZsWb0QHg5w,bhoLXAYz37qSr=CJlTSEpZsWb0QHg5w):
	UUTkXYFqxNan3Ehvpy = LLcxjIKwGTE5Ra4gq2tU8mvrdN(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,showDialogs,nqVYufmd4GFshQeHO9vp05,hh02Dy49ZltkecdFgP,bhoLXAYz37qSr)
	por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,aPHyKJYpoAxQ,ihHQsmlJjcNqPdST9 = UUTkXYFqxNan3Ehvpy
	BBwfuWGxUIrdCoc4ka7,iSNtwvQFHbA,norNEp9J308Y7MScPvRG1A2B,br0nG1O7vxmtPoqTJXsVKWyCkEY = EuX7CkI8cK5b0YO1WVwQMy(otaunYGVIJ2jX8HsKm7ecR0bAh4)
	KPfw4teDZ5Icxl6CqNmk2BrMdGHn3 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡥࡰࡶࠫ᎑"))
	Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(s97s2k0LJgl(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ᎒"))
	UKWyaeZQrGEDt4p6SnFPfNkdul5C = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(EcjO3giln2kQTdBY0XLAG(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫ᎓"))
	AAYdNKMXps6JDPFHgz7S = [s97s2k0LJgl(u"ࠧࡴࡥࡵࡥࡵ࡫࡯ࡱࡵࠪ᎔"),yylSaxCLfkte(u"ࠨࡵࡦࡶࡦࡶࡥࡳࡣࡳ࡭ࠬ᎕"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡶࡧࡷࡧࡰࡪࡰࡪࡥࡳࡺࠧ᎖"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡷࡨࡸࡡࡱ࡫ࡱ࡫ࡷࡵࡢࡰࡶࠪ᎗"),yylSaxCLfkte(u"ࠫࡸࡩࡲࡢࡲࡨࡹࡵ࠭᎘"),VVvcQpCU3OM09n(u"ࠬࡹࡣࡳࡣࡳࡩ࠳ࡪ࡯ࠨ᎙")]
	epfODnzR9ES4UCd = w2qb6lf5EM if any(value in otaunYGVIJ2jX8HsKm7ecR0bAh4 for value in AAYdNKMXps6JDPFHgz7S) else VJZIMkUN5siqB21Pf
	if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࠦࡶࡴ࡯ࡁࠬ᎚") in BBwfuWGxUIrdCoc4ka7 and epfODnzR9ES4UCd: hBJqtDe20Mo6OwvUdj1 = BBwfuWGxUIrdCoc4ka7.rsplit(yylSaxCLfkte(u"ࠧࠧࡷࡵࡰࡂ࠭᎛"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	else: hBJqtDe20Mo6OwvUdj1 = CJlTSEpZsWb0QHg5w
	pp8LUTWmDA49ZEqX = Ew2zQ8u7Ss.SITESURLS[JACnOz297UuDK5HpPkc1LF(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ᎜")]
	VVQyKTjakFdlEpIfo7Ruch = BBwfuWGxUIrdCoc4ka7 in pp8LUTWmDA49ZEqX or hBJqtDe20Mo6OwvUdj1 in pp8LUTWmDA49ZEqX
	w6iu2NPaQX1krv7RqT3jg = Ew2zQ8u7Ss.SITESURLS[O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡕࡉࡕࡕࡓࠨ᎝")]
	LN361ldwCpBnKEj4RVuQ = BBwfuWGxUIrdCoc4ka7 in w6iu2NPaQX1krv7RqT3jg or hBJqtDe20Mo6OwvUdj1 in w6iu2NPaQX1krv7RqT3jg
	gbKyP1n3lSfRITXo = VVQyKTjakFdlEpIfo7Ruch or LN361ldwCpBnKEj4RVuQ
	g56Be1PtIoaJAnyf = VJZIMkUN5siqB21Pf
	Mzc7Uwrk10oeZ6EtuhqCT9pK = w2qb6lf5EM
	V7boQELk2Wljc6NYx8dy1Dwfm = iSNtwvQFHbA==None and norNEp9J308Y7MScPvRG1A2B==None and not epfODnzR9ES4UCd
	if V7boQELk2Wljc6NYx8dy1Dwfm and gbKyP1n3lSfRITXo:
		if VVQyKTjakFdlEpIfo7Ruch:
			EEHn8zmTCZOLce4o = pp8LUTWmDA49ZEqX.index(BBwfuWGxUIrdCoc4ka7)
			X6IdJyMuSr3nhtONs = Ew2zQ8u7Ss.SITESURLS[zQGaM7ctZCN(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨ᎞")][EEHn8zmTCZOLce4o]
			IvYulbnqaKs1Bre = Ew2zQ8u7Ss.SITESURLS[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠳ࠩ᎟")][EEHn8zmTCZOLce4o]
			ffE7wtdLAJrTkBua5X8RY = Ew2zQ8u7Ss.SITESURLS[VVvcQpCU3OM09n(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑ࠵ࠪᎠ")][EEHn8zmTCZOLce4o]
			eeqpSKuXbQxUMkC3RIdBr1tW2 = Ew2zQ8u7Ss.api_python_actions[EEHn8zmTCZOLce4o]
			if eeqpSKuXbQxUMkC3RIdBr1tW2==h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨᎡ"): aPHyKJYpoAxQ,ihHQsmlJjcNqPdST9,Mzc7Uwrk10oeZ6EtuhqCT9pK = VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf
			elif eeqpSKuXbQxUMkC3RIdBr1tW2==O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨᎢ"): g56Be1PtIoaJAnyf = w2qb6lf5EM
		elif LN361ldwCpBnKEj4RVuQ:
			EEHn8zmTCZOLce4o = w6iu2NPaQX1krv7RqT3jg.index(BBwfuWGxUIrdCoc4ka7)
			X6IdJyMuSr3nhtONs = Ew2zQ8u7Ss.SITESURLS[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓ࠵ࠬᎣ")][EEHn8zmTCZOLce4o]
			IvYulbnqaKs1Bre = Ew2zQ8u7Ss.SITESURLS[Olh7n0zfV4(u"ࠩࡕࡉࡕࡕࡓࡠࡄࡎࡔ࠷࠭Ꭴ")][EEHn8zmTCZOLce4o]
			ffE7wtdLAJrTkBua5X8RY = Ew2zQ8u7Ss.SITESURLS[zQGaM7ctZCN(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠹ࠧᎥ")][EEHn8zmTCZOLce4o]
			eeqpSKuXbQxUMkC3RIdBr1tW2 = Ew2zQ8u7Ss.api_repos_actions[EEHn8zmTCZOLce4o]
	if norNEp9J308Y7MScPvRG1A2B==CJlTSEpZsWb0QHg5w: norNEp9J308Y7MScPvRG1A2B = KPfw4teDZ5Icxl6CqNmk2BrMdGHn3
	elif norNEp9J308Y7MScPvRG1A2B==None and Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4 in [cjVhOCwybeRo7UWg92(u"ࠫࡆ࡛ࡔࡐࠩᎦ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᎧ")] and aPHyKJYpoAxQ: norNEp9J308Y7MScPvRG1A2B = KPfw4teDZ5Icxl6CqNmk2BrMdGHn3
	if VVQyKTjakFdlEpIfo7Ruch or LN361ldwCpBnKEj4RVuQ: p3voWAbJhDmLaI2lgYGcVMEX = pz4WBwfyDdgk0m2aRr7SMv(u"࠴࠳ᕈ")
	elif epfODnzR9ES4UCd: p3voWAbJhDmLaI2lgYGcVMEX = ZP1LyUCS3pIBu(u"࠹࠴ᕉ")
	elif nqVYufmd4GFshQeHO9vp05 in zSOU8mieXluDYvIKF1HMfZoAgh0LR: p3voWAbJhDmLaI2lgYGcVMEX = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠵࠵ᕊ")
	elif nqVYufmd4GFshQeHO9vp05==HaTI5u1f3SCxmMAkw(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇ࡙ࡉࡗ࡙ࡏࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨᎨ"): p3voWAbJhDmLaI2lgYGcVMEX = KA26GucUHOwXL(u"࠷࠶ᕋ")
	elif nqVYufmd4GFshQeHO9vp05==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡖࡕࡅࡓ࡙ࡌࡂࡖࡈ࠱࠶ࡹࡴࠨᎩ"): p3voWAbJhDmLaI2lgYGcVMEX = EcjO3giln2kQTdBY0XLAG(u"࠸࠰ᕌ")
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡗࡂࡏࠪᎪ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = TDpFsQXHze2q30uYtGPfEIm8(u"࠷࠱ᕍ")
	elif XB4CjMkPFzhAHiI3q(u"ࠩࡖࡌࡔࡌࡈࡂࠩᎫ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠸࠷ᕎ")
	elif yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪᎬ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = s97s2k0LJgl(u"࠴࠸ᕏ")
	elif yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡆࡎࡗࡂࡍࠪᎭ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = GISOTJh20W(u"࠵࠴ᕐ")
	elif yylSaxCLfkte(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨᎮ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶࠵ᕑ")
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬᎯ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = cjVhOCwybeRo7UWg92(u"࠸࠶ᕒ")
	elif rC5tnFDlQcRGA2(u"ࠧࡂࡍࡒࡅࡒ࠭Ꮀ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = Olh7n0zfV4(u"࠸࠵ᕓ")
	elif CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡃࡎ࡛ࡆࡓࠧᎱ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = yUMRP0QKIzY9BDnsV784TZmwkf(u"࠳࠱ᕔ")
	elif O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫᎲ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = VVvcQpCU3OM09n(u"࠳࠲ᕕ")
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠷ࠬᎳ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠸࠳ᕖ")
	elif E6xdOMpqISHZCn(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭Ꮄ") in nqVYufmd4GFshQeHO9vp05: p3voWAbJhDmLaI2lgYGcVMEX = Olh7n0zfV4(u"࠷࠴ᕗ")
	else: p3voWAbJhDmLaI2lgYGcVMEX = o2FdrDBimMuOw97q6QpNW8S(u"࠵࠺ᕘ")
	GXMWT5idUtFKelyH = (iSNtwvQFHbA!=None)
	z1bp0VrC3HF = (norNEp9J308Y7MScPvRG1A2B!=None and Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4!=CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࡙ࠬࡔࡐࡒࠪᎵ"))
	if GXMWT5idUtFKelyH and not epfODnzR9ES4UCd: KhwN2zcb7iMkjS5E4WURxByPGon(zQGaM7ctZCN(u"࠭สโ฻ํ่ࠥฮั้ๅึ๎ࠥืโๆࠩᎶ"),iSNtwvQFHbA)
	elif z1bp0VrC3HF: KhwN2zcb7iMkjS5E4WURxByPGon(O4F8UC5lMAS6ghETm1VoPDI(u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋ࠧᎷ"),norNEp9J308Y7MScPvRG1A2B)
	if GXMWT5idUtFKelyH:
		PaQmJB7cEuR5T3rsb9kvfIAlyqU = {o2FdrDBimMuOw97q6QpNW8S(u"ࠣࡪࡷࡸࡵࠨᎸ"):iSNtwvQFHbA,XB4CjMkPFzhAHiI3q(u"ࠤ࡫ࡸࡹࡶࡳࠣᎹ"):iSNtwvQFHbA}
		e1xMbXGpdzincoLurh8 = iSNtwvQFHbA
	else: PaQmJB7cEuR5T3rsb9kvfIAlyqU,e1xMbXGpdzincoLurh8 = {},CJlTSEpZsWb0QHg5w
	if z1bp0VrC3HF:
		import urllib3.util.connection as GjlMx7yUkmOCbSiR
		TFO2yPandux7o56V8cDI = MbNudD8nL9ISUvoAP03eWxwzY1hgX(GjlMx7yUkmOCbSiR,KPfw4teDZ5Icxl6CqNmk2BrMdGHn3,w2qb6lf5EM)
	r7K6zTQ21oyEskftlwIuaAWbXxjc,BCMyfgK4GD2hiWlowzHLs5dj,geDkEJs0oqiZ7Ar,Fb1PUxcaBfVdo3XeyJ,DGCTbv3JXn6zacyZpk1RYuQ,zB4rVvHEATPN8kwX1sjxZpY,verify = UxFZj4yc65Yr2SDQavCALeoH7sk,nqVYufmd4GFshQeHO9vp05,por2itPgjLlh5fAb3z47nFvUJE,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf,br0nG1O7vxmtPoqTJXsVKWyCkEY
	if g56Be1PtIoaJAnyf: DGCTbv3JXn6zacyZpk1RYuQ = w2qb6lf5EM
	if gbKyP1n3lSfRITXo or UxFZj4yc65Yr2SDQavCALeoH7sk: r7K6zTQ21oyEskftlwIuaAWbXxjc = VJZIMkUN5siqB21Pf
	JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i = -P2Fgh6TCOWoaHjkqBcQnvRNXe,TDpFsQXHze2q30uYtGPfEIm8(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪᎺ")
	gMaBHt5LmOeI = VJZIMkUN5siqB21Pf
	if not Ew2zQ8u7Ss.FORWARDS_HOSTNAMES: Ew2zQ8u7Ss.FORWARDS_HOSTNAMES = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡩ࡯ࡣࡵࠩᎻ"),s97s2k0LJgl(u"ࠬࡓࡉࡔࡅࡢࡘࡊࡓࡐࡠ࠴ࠪᎼ"),rC5tnFDlQcRGA2(u"࠭ࡆࡐࡔ࡚ࡅࡗࡊࡓࠨᎽ"))
	HHJL5Nu1CKrscB2mvX = []
	while BBwfuWGxUIrdCoc4ka7 not in HHJL5Nu1CKrscB2mvX and BBwfuWGxUIrdCoc4ka7 in list(Ew2zQ8u7Ss.FORWARDS_HOSTNAMES.keys()):
		HHJL5Nu1CKrscB2mvX.append(BBwfuWGxUIrdCoc4ka7)
		BBwfuWGxUIrdCoc4ka7 = Ew2zQ8u7Ss.FORWARDS_HOSTNAMES[BBwfuWGxUIrdCoc4ka7]
	wnySE1IrNAk5z9HUc6JGseW = s502yd81FCuJmLVBlkPtxih9fZDA
	if VVQyKTjakFdlEpIfo7Ruch:
		geDkEJs0oqiZ7Ar = otNfFapeEnO(u"ࠧࡑࡑࡖࡘࠬᎾ")
		bsGedm1TLP7EgiUQDkCy[ZP1LyUCS3pIBu(u"ࠨࡃ࡙࠱ࡊࡴࡣࡳࡻࡳࡸ࡮ࡵ࡮ࠨᎿ")] = E6xdOMpqISHZCn(u"࡙ࠩࡩࡷࡹࡩࡰࡰࠣ࠵࠳࠶ࠧᏀ")
		YMquDTrAkWgioXClmbdKtIL6OV90 = KSHcVmz2W84iQvbRDBhGldpCL.dumps(s502yd81FCuJmLVBlkPtxih9fZDA)
		wnySE1IrNAk5z9HUc6JGseW = RQqNCLO5ofzZ7(YMquDTrAkWgioXClmbdKtIL6OV90,yylSaxCLfkte(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼ᕙ"))
	import requests as WjPGK7puI3D2m0qXcHYEVUovrL1xkJ
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(yylSaxCLfkte(u"࠿ᕚ")):
		cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
		if LxNV5lenkhW6zoBJDMA7ZuqSg:
			BCMyfgK4GD2hiWlowzHLs5dj = TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠲ࡵࡷࠫᏁ")
			try: cDXLPHnAgY6NOk1GVStoiEx.close()
			except: pass
		if epfODnzR9ES4UCd or not GXMWT5idUtFKelyH: B6Ul0f5eTI8atPymFdXoiANcjK7g9(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡗࡋࡑࡖࡇࡖࡘࡘࡢࡴࡐࡒࡈࡒࡤ࡛ࡒࡍࠩᏂ"),BBwfuWGxUIrdCoc4ka7,wnySE1IrNAk5z9HUc6JGseW,bsGedm1TLP7EgiUQDkCy,BCMyfgK4GD2hiWlowzHLs5dj,geDkEJs0oqiZ7Ar)
		ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7
		try:
			cDXLPHnAgY6NOk1GVStoiEx = WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.request(geDkEJs0oqiZ7Ar,BBwfuWGxUIrdCoc4ka7,data=wnySE1IrNAk5z9HUc6JGseW,headers=bsGedm1TLP7EgiUQDkCy,verify=verify,allow_redirects=r7K6zTQ21oyEskftlwIuaAWbXxjc,timeout=p3voWAbJhDmLaI2lgYGcVMEX,proxies=PaQmJB7cEuR5T3rsb9kvfIAlyqU)
			if TMfV6892ZoBdyxCH3tGrkwY0K(u"࠳࠱࠲ᕛ")<=cDXLPHnAgY6NOk1GVStoiEx.status_code<=GISOTJh20W(u"࠴࠻࠼ᕜ"):
				if not Fb1PUxcaBfVdo3XeyJ:
					FJ23AXndahr9vZbQwpu5oycIEWH = list(cDXLPHnAgY6NOk1GVStoiEx.headers.keys())
					if cjVhOCwybeRo7UWg92(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᏃ") in FJ23AXndahr9vZbQwpu5oycIEWH: BBwfuWGxUIrdCoc4ka7 = cDXLPHnAgY6NOk1GVStoiEx.headers[ZP1LyUCS3pIBu(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨᏄ")]
					elif pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᏅ") in FJ23AXndahr9vZbQwpu5oycIEWH: BBwfuWGxUIrdCoc4ka7 = cDXLPHnAgY6NOk1GVStoiEx.headers[KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪᏆ")]
					else: Fb1PUxcaBfVdo3XeyJ = w2qb6lf5EM
					if not Fb1PUxcaBfVdo3XeyJ: BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.encode(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࡯ࡥࡹ࡯࡮࠲ࠩᏇ"),zQGaM7ctZCN(u"ࠪ࡭࡬ࡴ࡯ࡳࡧࠪᏈ")).decode(Im5KSGZYBpRvdMVsbuXg,cbmeD4WNZfAowxT2JdUMtV(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫᏉ"))
					if gbKyP1n3lSfRITXo and cDXLPHnAgY6NOk1GVStoiEx.status_code==o2FdrDBimMuOw97q6QpNW8S(u"࠵࠳࠻ᕝ"):
						r7K6zTQ21oyEskftlwIuaAWbXxjc = UxFZj4yc65Yr2SDQavCALeoH7sk
						geDkEJs0oqiZ7Ar = por2itPgjLlh5fAb3z47nFvUJE
						Fb1PUxcaBfVdo3XeyJ = w2qb6lf5EM
						GzuphrMafS
				if not Fb1PUxcaBfVdo3XeyJ or UxFZj4yc65Yr2SDQavCALeoH7sk:
					if O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ࡮ࡴࡵࡲࠪᏊ") not in BBwfuWGxUIrdCoc4ka7:
						Q6SeM0GcJNdDv4hYsxPF7aVC8E = fUSgd7IjGYX496Hr25uFMl(ysw7G3tqjo,yylSaxCLfkte(u"࠭ࡵࡳ࡮ࠪᏋ"))
						BBwfuWGxUIrdCoc4ka7 = Q6SeM0GcJNdDv4hYsxPF7aVC8E+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧ࠰ࠩᏌ")+BBwfuWGxUIrdCoc4ka7.lstrip(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨ࠱ࠪᏍ"))
				if BBwfuWGxUIrdCoc4ka7!=ysw7G3tqjo:
					Ew2zQ8u7Ss.FORWARDS_HOSTNAMES[ysw7G3tqjo] = BBwfuWGxUIrdCoc4ka7
					gMaBHt5LmOeI = w2qb6lf5EM
				if not Fb1PUxcaBfVdo3XeyJ and UxFZj4yc65Yr2SDQavCALeoH7sk:
					if XETbMJIf1yetlQSinA2NW5YHvag6D(BBwfuWGxUIrdCoc4ka7): GzuphrMafS
					else: continue
			elif XB4CjMkPFzhAHiI3q(u"࠹࠺࠶ᕟ")<=cDXLPHnAgY6NOk1GVStoiEx.status_code<=CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠸࠽࠾ᕞ"): DGCTbv3JXn6zacyZpk1RYuQ = w2qb6lf5EM
			ysw7G3tqjo = cDXLPHnAgY6NOk1GVStoiEx.url
			JsDZ0f79iTWLY412v5Ejl = cDXLPHnAgY6NOk1GVStoiEx.status_code
			j6h5EvtgIqUrYcKwl91p7RCJm4i = cDXLPHnAgY6NOk1GVStoiEx.reason
			cDXLPHnAgY6NOk1GVStoiEx.raise_for_status()
			cn0XyId7MkTCE1RifFhwQDN = w2qb6lf5EM
		except WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.exceptions.HTTPError as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
			pass
		except WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.exceptions.Timeout as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
			if BB7oCRfQNSYj5qDhTUevV: j6h5EvtgIqUrYcKwl91p7RCJm4i = str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn.message).split(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩ࠽ࠤࠬᏎ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			else: j6h5EvtgIqUrYcKwl91p7RCJm4i = str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn).split(XB4CjMkPFzhAHiI3q(u"ࠪ࠾ࠥ࠭Ꮟ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		except WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.exceptions.ConnectionError as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
			try: iy7BbWH2lmuDT1FrXaLJCq8 = O7Pjho8kUNMeqxyrEf1Hg2mQbDzn.message[ZVNvqy4iF1a9X]
			except: iy7BbWH2lmuDT1FrXaLJCq8 = str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn)
			llZhNYPXaUyjSwD7 = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"ࠦࡡࡡࡅࡳࡴࡱࡳࠥ࠮࡜ࡥ࠭ࠬࡠࡢࠦࠨ࠯ࠬࡂ࠭ࠬࠨᏐ"),iy7BbWH2lmuDT1FrXaLJCq8)
			if not llZhNYPXaUyjSwD7: llZhNYPXaUyjSwD7 = Zy2l0g8QU5vqefaTrsw.findall(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧ࠲ࠠࡦࡴࡵࡳࡷࡢࠨࠩ࡞ࡧ࠯࠮࠲ࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣᏑ"),iy7BbWH2lmuDT1FrXaLJCq8)
			if not llZhNYPXaUyjSwD7:
				LwmU4RiIh5kx = Zy2l0g8QU5vqefaTrsw.findall(yylSaxCLfkte(u"ࠨ࠺ࠡࠪ࠱࠮ࡄ࠯࠺࠯ࠬࡂࠬࡡࡪࠫࠪ࠼ࠥᏒ"),iy7BbWH2lmuDT1FrXaLJCq8)
				if LwmU4RiIh5kx: llZhNYPXaUyjSwD7 = [LwmU4RiIh5kx[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe],LwmU4RiIh5kx[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X]]
			if not llZhNYPXaUyjSwD7: llZhNYPXaUyjSwD7 = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"ࠢ࠻ࠪ࡟ࡨ࠰࠯࠺ࠡࠪ࠱࠮ࡄ࠯ࠧࠣᏓ"),iy7BbWH2lmuDT1FrXaLJCq8)
			if not llZhNYPXaUyjSwD7: llZhNYPXaUyjSwD7 = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠣࠢࠫࡠࡩ࠱ࠩ࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤᏔ"),iy7BbWH2lmuDT1FrXaLJCq8)
			try: JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i = llZhNYPXaUyjSwD7[ZVNvqy4iF1a9X]
			except: JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i = -VTadWjBloMwXO2CH9GDK6FR,iy7BbWH2lmuDT1FrXaLJCq8
		except WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.exceptions.RequestException as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
			if BB7oCRfQNSYj5qDhTUevV: j6h5EvtgIqUrYcKwl91p7RCJm4i = O7Pjho8kUNMeqxyrEf1Hg2mQbDzn.message
			else: j6h5EvtgIqUrYcKwl91p7RCJm4i = str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn)
		except:
			try: JsDZ0f79iTWLY412v5Ejl = cDXLPHnAgY6NOk1GVStoiEx.status_code
			except: pass
			try: j6h5EvtgIqUrYcKwl91p7RCJm4i = cDXLPHnAgY6NOk1GVStoiEx.reason
			except: pass
		j6h5EvtgIqUrYcKwl91p7RCJm4i = str(j6h5EvtgIqUrYcKwl91p7RCJm4i)
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,GISOTJh20W(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡡࡺࡒࡆࡕࡓࡓࡓ࡙ࡅࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫᏕ")+str(JsDZ0f79iTWLY412v5Ejl)+rC5tnFDlQcRGA2(u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬᏖ")+j6h5EvtgIqUrYcKwl91p7RCJm4i+O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭Ꮧ")+nqVYufmd4GFshQeHO9vp05+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᏘ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+ZP1LyUCS3pIBu(u"࠭ࠠ࡞ࠩᏙ"))
		if V7boQELk2Wljc6NYx8dy1Dwfm and gbKyP1n3lSfRITXo and not DGCTbv3JXn6zacyZpk1RYuQ and JsDZ0f79iTWLY412v5Ejl!=KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷࠶࠰ᕠ") and VVvcQpCU3OM09n(u"ࠧ࠲࠴࠺࠲࠵࠴࠰࠯࠳ࠪᏚ") not in BBwfuWGxUIrdCoc4ka7:
			if BBwfuWGxUIrdCoc4ka7 not in [X6IdJyMuSr3nhtONs,IvYulbnqaKs1Bre,ffE7wtdLAJrTkBua5X8RY]: BBwfuWGxUIrdCoc4ka7,DGCTbv3JXn6zacyZpk1RYuQ = X6IdJyMuSr3nhtONs,VJZIMkUN5siqB21Pf
			elif BBwfuWGxUIrdCoc4ka7==X6IdJyMuSr3nhtONs: BBwfuWGxUIrdCoc4ka7,DGCTbv3JXn6zacyZpk1RYuQ = IvYulbnqaKs1Bre,VJZIMkUN5siqB21Pf
			elif BBwfuWGxUIrdCoc4ka7==IvYulbnqaKs1Bre: BBwfuWGxUIrdCoc4ka7,DGCTbv3JXn6zacyZpk1RYuQ = ffE7wtdLAJrTkBua5X8RY,w2qb6lf5EM
			continue
		break
	JsDZ0f79iTWLY412v5Ejl = int(JsDZ0f79iTWLY412v5Ejl)
	if not cn0XyId7MkTCE1RifFhwQDN:
		Gm84MFs0UlA9Ze5BzLwith = T83nMhxrkQRWmsoIeZJ7g(cjVhOCwybeRo7UWg92(u"ࠨ࠳࠱࠵࠳࠷࠮࠲ࠩᏛ"),cbmeD4WNZfAowxT2JdUMtV(u"࠾࠰ᕡ"))
		if Gm84MFs0UlA9Ze5BzLwith==-P2Fgh6TCOWoaHjkqBcQnvRNXe:
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,otNfFapeEnO(u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠥࠦࠠࡅࡋࡖࡇࡔࡔࡎࡆࡅࡗࡉࡉࠦࠠࠡࡖ࡫ࡩࠥࡪࡥࡷ࡫ࡦࡩࠥ࡯ࡳࠡࡰࡲࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡶࡲࠤࡹ࡮ࡥࠡ࡫ࡱࡸࡪࡸ࡮ࡦࡶࠣࠥࠦ࠭Ꮬ"))
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,h6sIkJOT5PB2vCxqo4LFag70wA(u"่้ࠪษำโࠢฯ๋ฬุใࠡ฼ํี๋ࠥัษฺ๊ࠤออไฦ่อี๋ะࠠ࠯࠰ࠣวํฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ูสฯั่ࠤฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหูะษาหฯࠦฬ่ษี็ࠥเ๊าุࠢั๏ำษࠡ࡞ࡱࡠࡳࠦไฮๆࠣห้๋ิไๆฬࠤฯษใะࠢฦ๊ࠥา็ศิๆࠤ๊ืศู้ࠣฬ฼ื๊ใหูࠣา๐อสࠢหห้หๆหำ้ฮࠥ๎แ๋้ࠣห้หๆหำ้ฮࠥะูๆๆࠣฬฺ๎ัสࠢฯ๎ิฯࠧᏝ"))
			JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
			return cDXLPHnAgY6NOk1GVStoiEx
	if not cn0XyId7MkTCE1RifFhwQDN and HHJL5Nu1CKrscB2mvX:
		for url in HHJL5Nu1CKrscB2mvX:
			if url in list(Ew2zQ8u7Ss.FORWARDS_HOSTNAMES.keys()):
				del Ew2zQ8u7Ss.FORWARDS_HOSTNAMES[url]
				gMaBHt5LmOeI = w2qb6lf5EM
	if gMaBHt5LmOeI:
		JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖ࡟࠳ࠩᏞ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧᏟ"),Ew2zQ8u7Ss.FORWARDS_HOSTNAMES,ggZJf7YnlXHT3IjtMaWe6S)
		Ew2zQ8u7Ss.FORWARDS_HOSTNAMES = {}
	if norNEp9J308Y7MScPvRG1A2B!=None and Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4!=zQGaM7ctZCN(u"࠭ࡓࡕࡑࡓࠫᏠ"): GjlMx7yUkmOCbSiR.create_connection = TFO2yPandux7o56V8cDI
	if Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4==TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡂࡎ࡚ࡅ࡞࡙ࠧᏡ") and aPHyKJYpoAxQ: norNEp9J308Y7MScPvRG1A2B = None
	if not cn0XyId7MkTCE1RifFhwQDN and iSNtwvQFHbA==None and nqVYufmd4GFshQeHO9vp05 not in zSOU8mieXluDYvIKF1HMfZoAgh0LR:
		uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
		if uErMFcVGBXUvtJZ90zCTPxn2YW!=otNfFapeEnO(u"ࠨࡐࡲࡲࡪ࡚ࡹࡱࡧ࠽ࠤࡓࡵ࡮ࡦ࡞ࡱࠫᏢ"): A8v6c2fL7egwWCF3YBqr4kXSRn.stderr.write(uErMFcVGBXUvtJZ90zCTPxn2YW)
	Ig8Y6D1bZtzURv = Ing6ofPTzy1aJXv0()
	if epfODnzR9ES4UCd: ysw7G3tqjo = hBJqtDe20Mo6OwvUdj1
	if not ysw7G3tqjo: ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7
	Ig8Y6D1bZtzURv.url = ysw7G3tqjo
	Ig8Y6D1bZtzURv.scrape = epfODnzR9ES4UCd
	try: s2BDjNPyHOIbEmUw63RkGAJeVMp4K = cDXLPHnAgY6NOk1GVStoiEx.headers
	except: s2BDjNPyHOIbEmUw63RkGAJeVMp4K = {}
	try:
		LhWaJkpQxVYm = cDXLPHnAgY6NOk1GVStoiEx.content
		if VVQyKTjakFdlEpIfo7Ruch and LhWaJkpQxVYm:
			TO3ypZhD9Ru8JCvbQl5BiXMgWz = {iIvKUWE23HyP0L.lower(): hhGo9uOjZXkLFg0Uvw6pPAN5 for iIvKUWE23HyP0L, hhGo9uOjZXkLFg0Uvw6pPAN5 in cDXLPHnAgY6NOk1GVStoiEx.headers.items()}
			if TO3ypZhD9Ru8JCvbQl5BiXMgWz.get(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡤࡺ࠲࡫࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩᏣ"))==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨᏤ"):
				LhWaJkpQxVYm = tt4BxXNIpjgV6FkvHWu0aCToy(LhWaJkpQxVYm,ZP1LyUCS3pIBu(u"࠸࠲࠴࠺࠸࠾࠹࠵࠷ᕢ"))
				if LhWaJkpQxVYm==zQGaM7ctZCN(u"ࠫࡋࡇࡉࡍࡇࡇࡣࡉࡋࡃࡓ࡛ࡓࡘࡎࡔࡇࠨᏥ"):
					j6h5EvtgIqUrYcKwl91p7RCJm4i,JsDZ0f79iTWLY412v5Ejl = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡏ࡮ࡷࡣ࡯࡭ࡩࠦࡁࡑࡋࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳࠭Ꮶ"),-GGsP9SDod4iUBm6kNMfLw
					cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
					LhWaJkpQxVYm = j6h5EvtgIqUrYcKwl91p7RCJm4i
	except: LhWaJkpQxVYm = CJlTSEpZsWb0QHg5w
	if A7Z6OVh20eCEUx and isinstance(LhWaJkpQxVYm,bytes): LhWaJkpQxVYm = LhWaJkpQxVYm.decode(Im5KSGZYBpRvdMVsbuXg)
	if VVQyKTjakFdlEpIfo7Ruch and LhWaJkpQxVYm and O4F8UC5lMAS6ghETm1VoPDI(u"࠷࠸࠴ᕤ")<=JsDZ0f79iTWLY412v5Ejl<=cbmeD4WNZfAowxT2JdUMtV(u"࠶࠻࠼ᕣ"): j6h5EvtgIqUrYcKwl91p7RCJm4i = LhWaJkpQxVYm
	try: JVlsUET8kbGi = cDXLPHnAgY6NOk1GVStoiEx.cookies.get_dict()
	except: JVlsUET8kbGi = {}
	try: cDXLPHnAgY6NOk1GVStoiEx.close()
	except: pass
	Ig8Y6D1bZtzURv.code = JsDZ0f79iTWLY412v5Ejl
	Ig8Y6D1bZtzURv.reason = j6h5EvtgIqUrYcKwl91p7RCJm4i
	Ig8Y6D1bZtzURv.content = LhWaJkpQxVYm
	Ig8Y6D1bZtzURv.headers = s2BDjNPyHOIbEmUw63RkGAJeVMp4K
	Ig8Y6D1bZtzURv.cookies = JVlsUET8kbGi
	Ig8Y6D1bZtzURv.succeeded = cn0XyId7MkTCE1RifFhwQDN
	Ig8Y6D1bZtzURv.scrapernumber = CJlTSEpZsWb0QHg5w
	Ig8Y6D1bZtzURv.scraperserver = CJlTSEpZsWb0QHg5w
	Ig8Y6D1bZtzURv.scraperurl = CJlTSEpZsWb0QHg5w
	if BB7oCRfQNSYj5qDhTUevV or isinstance(Ig8Y6D1bZtzURv.content,str): puSW2JGqdYHmXOLosjkCgbeK = Ig8Y6D1bZtzURv.content.lower()
	else: puSW2JGqdYHmXOLosjkCgbeK = CJlTSEpZsWb0QHg5w
	wcNfPIsg7AK8CWGrXmepFnb0J = (ZP1LyUCS3pIBu(u"࠭ࡣ࡭ࡱࡸࡨ࡫ࡲࡡࡳࡧࠪᏧ") in puSW2JGqdYHmXOLosjkCgbeK or rC5tnFDlQcRGA2(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧᏨ") in puSW2JGqdYHmXOLosjkCgbeK) and puSW2JGqdYHmXOLosjkCgbeK.count(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤࠫᏩ"))>VTadWjBloMwXO2CH9GDK6FR and NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠴ࠫᏪ") not in nqVYufmd4GFshQeHO9vp05 and yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡴࡰ࡭ࡨࡲࠬᏫ") not in puSW2JGqdYHmXOLosjkCgbeK and not epfODnzR9ES4UCd
	dJoXLYsRnEDH7y = (GISOTJh20W(u"ࠫࡻ࡫ࡲࡪࡨࡼ࠲࡭ࡺ࡭࡭ࡁࡵࡩࡩ࡯ࡲࡦࡥࡷࡁࠬᏬ") in ysw7G3tqjo)
	if JsDZ0f79iTWLY412v5Ejl==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠵࠴࠵ᕥ") and (wcNfPIsg7AK8CWGrXmepFnb0J or dJoXLYsRnEDH7y):
		Ig8Y6D1bZtzURv.succeeded = VJZIMkUN5siqB21Pf
	if Ig8Y6D1bZtzURv.succeeded and V7boQELk2Wljc6NYx8dy1Dwfm and gbKyP1n3lSfRITXo:
		L7RjXk0D5eqaTrS6u9WhgAYFn = zQGaM7ctZCN(u"ࠬࡉࡁࡑࡖࡆࡌࡆ࠭Ꮽ")+s502yd81FCuJmLVBlkPtxih9fZDA[HaTI5u1f3SCxmMAkw(u"࠭ࡪࡰࡤࠪᏮ")].upper().replace(GISOTJh20W(u"ࠧࡈࡇࡗࠫᏯ"),CJlTSEpZsWb0QHg5w) if g56Be1PtIoaJAnyf else eeqpSKuXbQxUMkC3RIdBr1tW2
		yfL6aW08mk9wbt75r2cUnVeqSC(L7RjXk0D5eqaTrS6u9WhgAYFn)
	if not Ig8Y6D1bZtzURv.succeeded and V7boQELk2Wljc6NYx8dy1Dwfm:
		eFv360Ac74tNpfE5oijhw1DxOq = (NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᏰ") in puSW2JGqdYHmXOLosjkCgbeK and xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡵࡥࡾࠦࡩࡥ࠼ࠣࠫᏱ") in puSW2JGqdYHmXOLosjkCgbeK)
		Aw0oeybcN3UDW7rYCVlg9K5ZmPh4M = (VVvcQpCU3OM09n(u"ࠪ࠹ࠥࡹࡥࡤࠩᏲ") in puSW2JGqdYHmXOLosjkCgbeK and xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬᏳ") in puSW2JGqdYHmXOLosjkCgbeK)
		UDmfY1QkHi6EPtrjhBnu = (JsDZ0f79iTWLY412v5Ejl in [JACnOz297UuDK5HpPkc1LF(u"࠸࠵࠹ᕦ")] and h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ࡫ࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣ࠵࠵࠸࠰ࠨᏴ") in puSW2JGqdYHmXOLosjkCgbeK)
		fC2WQSK4wqjp = (I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭࡟ࡤࡨࡢࡧ࡭ࡲ࡟ࠨᏵ") in puSW2JGqdYHmXOLosjkCgbeK and mi2ZJXCDzITuyev6gfn(u"ࠧࡤࡪࡤࡰࡱ࡫࡮ࡨࡧ࠰ࠫ᏶") in puSW2JGqdYHmXOLosjkCgbeK)
		k8mJH047xD3p9bewurXWCdn = (KA26GucUHOwXL(u"ࠨ࡙ࡕࡓࡓࡍ࡟ࡗࡇࡕࡗࡎࡕࡎࡠࡐࡘࡑࡇࡋࡒࠨ᏷") in j6h5EvtgIqUrYcKwl91p7RCJm4i or JACnOz297UuDK5HpPkc1LF(u"ࠩࡺࡶࡴࡴࡧࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡱࡹࡲࡨࡥࡳࠩᏸ") in j6h5EvtgIqUrYcKwl91p7RCJm4i)
		if   wcNfPIsg7AK8CWGrXmepFnb0J: j6h5EvtgIqUrYcKwl91p7RCJm4i = rC5tnFDlQcRGA2(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡳࡧࡦࡥࡵࡺࡣࡩࡣࠪᏹ")
		elif eFv360Ac74tNpfE5oijhw1DxOq: j6h5EvtgIqUrYcKwl91p7RCJm4i = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᏺ")
		elif Aw0oeybcN3UDW7rYCVlg9K5ZmPh4M: j6h5EvtgIqUrYcKwl91p7RCJm4i = O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢ࠸ࠤࡸ࡫ࡣࡰࡰࡧࡷࠥࡨࡲࡰࡹࡶࡩࡷࠦࡣࡩࡧࡦ࡯ࠬᏻ")
		elif UDmfY1QkHi6EPtrjhBnu: j6h5EvtgIqUrYcKwl91p7RCJm4i = O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡢࡥࡦࡩࡸࡹࠠࡥࡧࡱ࡭ࡪࡪࠧᏼ")
		elif fC2WQSK4wqjp: j6h5EvtgIqUrYcKwl91p7RCJm4i = Olh7n0zfV4(u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠡࡵࡨࡧࡺࡸࡩࡵࡻࠣࡧ࡭࡫ࡣ࡬ࠩᏽ")
		elif dJoXLYsRnEDH7y: j6h5EvtgIqUrYcKwl91p7RCJm4i = Olh7n0zfV4(u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡳࡩࡴࡵ࡬ࡲ࡬ࠦࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠣࡧ࡭࡫ࡣ࡬ࠩ᏾")
		elif k8mJH047xD3p9bewurXWCdn: j6h5EvtgIqUrYcKwl91p7RCJm4i = pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡹࡰࡷࡵࠤࡳ࡫ࡴࡸࡱࡵ࡯ࠥࡪࡥࡷ࡫ࡦࡩࡸ࠭᏿")
		else: j6h5EvtgIqUrYcKwl91p7RCJm4i = str(j6h5EvtgIqUrYcKwl91p7RCJm4i)
		if nqVYufmd4GFshQeHO9vp05 in R347l8NdWwa5mnO9F2ZzCjYi: pass
		elif nqVYufmd4GFshQeHO9vp05 in zSOU8mieXluDYvIKF1HMfZoAgh0LR:
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࠤࠥࡊࡩࡳࡧࡦࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭᐀")+str(JsDZ0f79iTWLY412v5Ejl)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭ᐁ")+j6h5EvtgIqUrYcKwl91p7RCJm4i+cjVhOCwybeRo7UWg92(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᐂ")+nqVYufmd4GFshQeHO9vp05+zQGaM7ctZCN(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᐃ")+BBwfuWGxUIrdCoc4ka7+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࠡ࡟ࠪᐄ"))
		else: JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+HaTI5u1f3SCxmMAkw(u"ࠨࠢࠣࠤࡉ࡯ࡲࡦࡥࡷࠤࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬᐅ")+str(JsDZ0f79iTWLY412v5Ejl)+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫᐆ")+j6h5EvtgIqUrYcKwl91p7RCJm4i+E6xdOMpqISHZCn(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᐇ")+nqVYufmd4GFshQeHO9vp05+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᐈ")+BBwfuWGxUIrdCoc4ka7+mi2ZJXCDzITuyev6gfn(u"ࠬࠦ࡝ࠨᐉ"))
		hqOKNpfbIdsUSA1VT = hBJqtDe20Mo6OwvUdj1 if epfODnzR9ES4UCd else sWzgdLCjSVwaMuhFkNf1Uop(BBwfuWGxUIrdCoc4ka7)
		if BB7oCRfQNSYj5qDhTUevV and isinstance(hqOKNpfbIdsUSA1VT,unicode): hqOKNpfbIdsUSA1VT = hqOKNpfbIdsUSA1VT.encode(Im5KSGZYBpRvdMVsbuXg)
		if gbKyP1n3lSfRITXo: hqOKNpfbIdsUSA1VT = hqOKNpfbIdsUSA1VT.split(EcjO3giln2kQTdBY0XLAG(u"࠭࠯ࠨᐊ"))[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
		gkuyOpfleTtPz5A = str(j6h5EvtgIqUrYcKwl91p7RCJm4i)+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧ࡝ࡰࠫࠫᐋ")+hqOKNpfbIdsUSA1VT+zQGaM7ctZCN(u"ࠨࠫࠪᐌ")
		if any([wcNfPIsg7AK8CWGrXmepFnb0J,eFv360Ac74tNpfE5oijhw1DxOq,Aw0oeybcN3UDW7rYCVlg9K5ZmPh4M,UDmfY1QkHi6EPtrjhBnu,fC2WQSK4wqjp,dJoXLYsRnEDH7y,k8mJH047xD3p9bewurXWCdn]) and ihHQsmlJjcNqPdST9:
			if not k8mJH047xD3p9bewurXWCdn:
				Ig8Y6D1bZtzURv.code = -D9yBM7wPFLz
				JQWzTSVvkZmPoDuIX8e7BGF5wifg2p = h6sIkJOT5PB2vCxqo4LFag70wA(u"๊ࠩิ์ࠦวๅืไัฮࠦไศࠢํ้่์ࠠอๆห๋ฬࠦๅ็ࠢส่ส์สา่อࠤฬ๊ฮศืࠣฬ่ࠦ࠮࠯ࠢ็วู๋ࠦๅ์๊หࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ๏๋ๆฺࠢหีฬ๋ฬࠡษ็็ํ๋ศ๋๊อี๋ࠥๆࠡฮ็ฬࠥ๎แหฯࠣ์ฬูสฯัส้ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊ีโฯสฮࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิ๊ࠦิฬฺ๎฾ࠦร็ࠢํัฬ๎ไࠡษึฮำีวๆࠢศ๊ฯืๆหࠢฦาึ๏ࠠๅฬฯหํุ่ࠠาสࠤฬ๊ออสࠣ࠲࠳ࠦไไ่่ࠣฬ๊้ࠦฮาࠤ฻๋ว็ࠢฦ๊ࠥํะ่ࠢส่๊ำว้ๆฬࠤุ๎แࠡฬ้ะาࡢ࡮ࠨᐍ")+Ym6q5M4TocDaA013RjFQ+cjVhOCwybeRo7UWg92(u"ࠪࡉࡷࡸ࡯ࡳࠢࡆࡳࡩ࡫࠺ࠡࠢࠪᐎ")+str(Ig8Y6D1bZtzURv.code)+oOQaRxBXyJ5jVnZ+rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+EcjO3giln2kQTdBY0XLAG(u"ࠫ์๊ࠠหำํำ๋ࠥๆࠡสิ๊ฬ๋ฬࠡ฻่หิࠦร็ࠢํัฬ๎ไࠡฬฯหํุ่ࠠาสࠤฬ๊ออสࠣรࠦ࠭ᐏ")+oOQaRxBXyJ5jVnZ
			else:
				Ig8Y6D1bZtzURv.code = -P3cpaLN2sH
				JQWzTSVvkZmPoDuIX8e7BGF5wifg2p = otNfFapeEnO(u"๊ࠬฯ๋ๅู้้ࠣไสࠢไ๎ࠥอไฦ่อี๋ะࠠห็้฽ࠥ็สฮࠢห฽฻ࠦีโฯสฮࠥอไฦ่อี๋ะࠠศๆูีํื๊สࠢ࠱࠲ࠥํะ่ࠢสฺ่๊ใๅหࠣๆิࠦสไ๊้ࠤ๊์ࠠศๆิหํะัࠡ฻้ำ่ࠦร้่๊ࠢࠥฮั็ษ่ะࠥ฿ๆะๅࠣวํࠦๅ็ࠢฯ๋ฬฺุ่ࠠา็ࠥ࠴࠮๊ࠡ฻๎ๆะ็ࠡษ็ั๊อ๊สูࠢำࠥอไโ์ิ์ุอสࠡล๋ࠤ฻ีࠠศๆอะุูࠠฤฺ๊ࠣิࠦวๅสิห๊าࠠศๆ่ศี๐ษࠡ࠰࠱ࠤ้ำไࠡษ็ู้้ไสࠢํะอࠦล๋ไสๅࠥํะ่ࠢส่า๋ว๋หࠣห้ิวุศฬࡠࡳ࠭ᐐ")+Ym6q5M4TocDaA013RjFQ+cjVhOCwybeRo7UWg92(u"࠭ࡅࡳࡴࡲࡶࠥࡉ࡯ࡥࡧ࠽ࠤࠥ࠭ᐑ")+str(Ig8Y6D1bZtzURv.code)+oOQaRxBXyJ5jVnZ+rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+TDpFsQXHze2q30uYtGPfEIm8(u"่ࠧๆࠣฮึ๐ฯࠡ็้ࠤอืๆศ็ฯࠤ฾๋วะࠢฦ๊ࠥ๐อศ๊็ࠤฬูสฯัส้ࠥหๆหำ้ฮࠥษฮา๋่ࠣฯาว้ิ๋ࠣีํࠠศๆะ้ฬ๐ษࠡมࠤࠫᐒ")+oOQaRxBXyJ5jVnZ
			Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JQWzTSVvkZmPoDuIX8e7BGF5wifg2p)
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
				APzlpyC4ehQWRid9 = epDHqUwf9S4RAC6h3Yd8LsPVb(por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,wnySE1IrNAk5z9HUc6JGseW,bsGedm1TLP7EgiUQDkCy,UxFZj4yc65Yr2SDQavCALeoH7sk,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05,JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i)
				if APzlpyC4ehQWRid9.succeeded: return APzlpyC4ehQWRid9
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = w2qb6lf5EM
		if (Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4==cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡃࡖࡏࠬᐓ") or UKWyaeZQrGEDt4p6SnFPfNkdul5C==mi2ZJXCDzITuyev6gfn(u"ࠩࡄࡗࡐ࠭ᐔ")) and (aPHyKJYpoAxQ or ihHQsmlJjcNqPdST9):
			Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = Ask1fYqbtjHaK7uoe5BiFhCSdLO2Pn(JsDZ0f79iTWLY412v5Ejl,gkuyOpfleTtPz5A,nqVYufmd4GFshQeHO9vp05,jRM2XgKnTPx)
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa and Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4==Olh7n0zfV4(u"ࠪࡅࡘࡑࠧᐕ"): Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4 = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᐖ")
			else: Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4 = ZP1LyUCS3pIBu(u"ࠬࡘࡅࡋࡇࡆࡘࡊࡊࠧᐗ")
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa and UKWyaeZQrGEDt4p6SnFPfNkdul5C==ZP1LyUCS3pIBu(u"࠭ࡁࡔࡍࠪᐘ"): UKWyaeZQrGEDt4p6SnFPfNkdul5C = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩᐙ")
			else: UKWyaeZQrGEDt4p6SnFPfNkdul5C = pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᐚ")
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(E6xdOMpqISHZCn(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᐛ"),Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(yylSaxCLfkte(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡳࡶࡴࡾࡹࠨᐜ"),UKWyaeZQrGEDt4p6SnFPfNkdul5C)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
			if JsDZ0f79iTWLY412v5Ejl==cbmeD4WNZfAowxT2JdUMtV(u"࠽ᕧ") and yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫ࡭ࡺࡴࡱࡵࠪᐝ") in BBwfuWGxUIrdCoc4ka7 and Mzc7Uwrk10oeZ6EtuhqCT9pK:
				if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(Olh7n0zfV4(u"ࠬะแฺ์็ࠤๆำีࠡึ๊หิฯࠠศๆอุๆ๐ัࠡࡕࡖࡐࠬᐞ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᐟ"),L8Wkv5KCSoq=mi2ZJXCDzITuyev6gfn(u"࠸࠰࠱࠲ᕨ"))
				ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7+otNfFapeEnO(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᐠ")
				nJsMjF0fH3 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,ysw7G3tqjo,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,jRM2XgKnTPx,otNfFapeEnO(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠸࡮ࡥࠩᐡ"))
				if nJsMjF0fH3.succeeded:
					Ig8Y6D1bZtzURv = nJsMjF0fH3
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᐢ")+nqVYufmd4GFshQeHO9vp05+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᐣ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+cjVhOCwybeRo7UWg92(u"ࠫࠥࡣࠧᐤ"))
					if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬ์ฬศฯࠣฬฬูสฯัส้࡙ࠥࡓࡍࠩᐥ"),s97s2k0LJgl(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᐦ"),L8Wkv5KCSoq=ZP1LyUCS3pIBu(u"࠲࠱࠲࠳ᕩ"))
				else:
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡹࡸ࡯࡮ࡨࠢࡖࡗࡑࡀࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᐧ")+nqVYufmd4GFshQeHO9vp05+o2FdrDBimMuOw97q6QpNW8S(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᐨ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+EcjO3giln2kQTdBY0XLAG(u"ࠩࠣࡡࠬᐩ"))
					if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪๅู๊ࠠษษึฮำีวๆࠢࡖࡗࡑ࠭ᐪ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᐫ"),L8Wkv5KCSoq=TMfV6892ZoBdyxCH3tGrkwY0K(u"࠳࠲࠳࠴ᕪ"))
			if not Ig8Y6D1bZtzURv.succeeded and UKWyaeZQrGEDt4p6SnFPfNkdul5C in [yylSaxCLfkte(u"ࠬࡇࡕࡕࡑࠪᐬ"),o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᐭ")] and ihHQsmlJjcNqPdST9:
				if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(EcjO3giln2kQTdBY0XLAG(u"ࠧหใ฼๎้ࠦำ๋ำไีฬะࠠษำ๋็ุ๐ࠧᐮ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᐯ"),L8Wkv5KCSoq=XB4CjMkPFzhAHiI3q(u"࠴࠳࠴࠵ᕫ"))
				nJsMjF0fH3 = awcv24YERQj(por2itPgjLlh5fAb3z47nFvUJE,BBwfuWGxUIrdCoc4ka7,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,jRM2XgKnTPx,nqVYufmd4GFshQeHO9vp05)
				if nJsMjF0fH3.succeeded:
					Ig8Y6D1bZtzURv = nJsMjF0fH3
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࠣࠤࠥࡖࡲࡰࡺ࡬ࡩࡸࠦࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᐰ")+nqVYufmd4GFshQeHO9vp05+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᐱ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+cjVhOCwybeRo7UWg92(u"ࠫࠥࡣࠧᐲ"))
					if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬ์ฬศฯࠣื๏ืแาษอࠤอื่ไีํࠫᐳ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᐴ"),L8Wkv5KCSoq=TMfV6892ZoBdyxCH3tGrkwY0K(u"࠵࠴࠵࠶ᕬ"))
				else:
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+GISOTJh20W(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᐵ")+nqVYufmd4GFshQeHO9vp05+EcjO3giln2kQTdBY0XLAG(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᐶ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࠣࡡࠬᐷ"))
					if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪๅู๊ࠠิ์ิๅึอสࠡสิ์ู่๊ࠨᐸ"),HaTI5u1f3SCxmMAkw(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᐹ"),L8Wkv5KCSoq=h6sIkJOT5PB2vCxqo4LFag70wA(u"࠶࠵࠶࠰ᕭ"))
			if not Ig8Y6D1bZtzURv.succeeded and Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4 in [E6xdOMpqISHZCn(u"ࠬࡇࡕࡕࡑࠪᐺ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡁࡄࡅࡈࡔ࡙ࡋࡄࠨᐻ")] and aPHyKJYpoAxQ:
				if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(HaTI5u1f3SCxmMAkw(u"ࠧหใ฼๎้ࠦำ๋ำไีࠥࡊࡎࡔࠩᐼ"),VVvcQpCU3OM09n(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᐽ"),L8Wkv5KCSoq=yUMRP0QKIzY9BDnsV784TZmwkf(u"࠷࠶࠰࠱ᕮ"))
				ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡿࢀࡒࡿࡄࡏࡕࡘࡶࡱࡃࠧᐾ")
				nJsMjF0fH3 = pNaOYIAErvTnHXlwMhmcekij9P(por2itPgjLlh5fAb3z47nFvUJE,ysw7G3tqjo,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,kHXci2ESlxLf,jRM2XgKnTPx,zQGaM7ctZCN(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙࠭࠵ࡶ࡫ࠫᐿ"))
				if nJsMjF0fH3.succeeded:
					Ig8Y6D1bZtzURv = nJsMjF0fH3
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+JACnOz297UuDK5HpPkc1LF(u"ࠫࠥࠦࠠࡅࡐࡖࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡈࡓ࡙࠺ࠡ࡝ࠣࠫᑀ")+KPfw4teDZ5Icxl6CqNmk2BrMdGHn3+TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᑁ")+nqVYufmd4GFshQeHO9vp05+yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᑂ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࠡ࡟ࠪᑃ"))
					if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(TDpFsQXHze2q30uYtGPfEIm8(u"ࠨ่ฯหาࠦำ๋ำไีࠥࡊࡎࡔࠩᑄ"),rC5tnFDlQcRGA2(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᑅ"),L8Wkv5KCSoq=s97s2k0LJgl(u"࠸࠰࠱࠲ᕯ"))
				else:
					JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࠤࠥࠦࡄࡏࡕࠣࡪࡦ࡯࡬ࡦࡦ࠽ࠤࠥࠦࡄࡏࡕ࠽ࠤࡠࠦࠧᑆ")+KPfw4teDZ5Icxl6CqNmk2BrMdGHn3+Olh7n0zfV4(u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭ᑇ")+nqVYufmd4GFshQeHO9vp05+cjVhOCwybeRo7UWg92(u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᑈ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+JACnOz297UuDK5HpPkc1LF(u"࠭ࠠ࡞ࠩᑉ"))
					if jRM2XgKnTPx: KhwN2zcb7iMkjS5E4WURxByPGon(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧโึ็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧᑊ"),s97s2k0LJgl(u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪᑋ"),L8Wkv5KCSoq=xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠲࠱࠲࠳ᕰ"))
		if UKWyaeZQrGEDt4p6SnFPfNkdul5C==ZP1LyUCS3pIBu(u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫᑌ") or Aq0jwFrQ8lnK6MJmhaHYE1RPXg3V4==otNfFapeEnO(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᑍ"): jRM2XgKnTPx = VJZIMkUN5siqB21Pf
		if not Ig8Y6D1bZtzURv.succeeded:
			if jRM2XgKnTPx: Wb3hHyodk2LBqwE5z = Ask1fYqbtjHaK7uoe5BiFhCSdLO2Pn(JsDZ0f79iTWLY412v5Ejl,gkuyOpfleTtPz5A,nqVYufmd4GFshQeHO9vp05,jRM2XgKnTPx)
			if Ig8Y6D1bZtzURv.code!=KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠳࠲࠳ᕱ") and nqVYufmd4GFshQeHO9vp05 not in U3C7tspghAWc8qBHeIK and rC5tnFDlQcRGA2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࠨᑎ") not in nqVYufmd4GFshQeHO9vp05: JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	if ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨᑏ")) not in [Olh7n0zfV4(u"࠭ࡁࡖࡖࡒࠫᑐ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡔࡖࡒࡔࠬᑑ"),Olh7n0zfV4(u"ࠨࡃࡖࡏࠬᑒ")]: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬᑓ"),mi2ZJXCDzITuyev6gfn(u"ࠪࡅࡘࡑࠧᑔ"))
	if ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩᑕ")) not in [GISOTJh20W(u"ࠬࡇࡕࡕࡑࠪᑖ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡓࡕࡑࡓࠫᑗ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡂࡕࡎࠫᑘ")]: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(EcjO3giln2kQTdBY0XLAG(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᑙ"),E6xdOMpqISHZCn(u"ࠩࡄࡗࡐ࠭ᑚ"))
	return Ig8Y6D1bZtzURv
def UQbj5VpAvCo2FdXqZyRsP3(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo):
	z8Krljuof0WmBMwnAEYRXHbe4iZTJ, mceaCKZ2XRMpIo = list(kjGCm2DWF9wdlTb5), mceaCKZ2XRMpIo & 0xFFFFFFFF
	for PMTRpXQvDIkiNszwYGnb32a in range(len(z8Krljuof0WmBMwnAEYRXHbe4iZTJ)-P2Fgh6TCOWoaHjkqBcQnvRNXe, ZVNvqy4iF1a9X, -P2Fgh6TCOWoaHjkqBcQnvRNXe):
		mceaCKZ2XRMpIo = (mceaCKZ2XRMpIo * h6sIkJOT5PB2vCxqo4LFag70wA(u"࠴࠺࠻࠺࠵࠳࠷ᕳ") + VVvcQpCU3OM09n(u"࠳࠳࠵࠸࠿࠰࠵࠴࠵࠷ᕲ")) & 0xFFFFFFFF
		z8Krljuof0WmBMwnAEYRXHbe4iZTJ[PMTRpXQvDIkiNszwYGnb32a], z8Krljuof0WmBMwnAEYRXHbe4iZTJ[mceaCKZ2XRMpIo % (PMTRpXQvDIkiNszwYGnb32a + P2Fgh6TCOWoaHjkqBcQnvRNXe)] = z8Krljuof0WmBMwnAEYRXHbe4iZTJ[mceaCKZ2XRMpIo % (PMTRpXQvDIkiNszwYGnb32a + P2Fgh6TCOWoaHjkqBcQnvRNXe)], z8Krljuof0WmBMwnAEYRXHbe4iZTJ[PMTRpXQvDIkiNszwYGnb32a]
	return KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࠫᑛ").join(z8Krljuof0WmBMwnAEYRXHbe4iZTJ)
def K513Z962SFiwO0(kjGCm2DWF9wdlTb5, xGa2gBJRzchOVljHEv8YUwIrT, HSnFtUlDIvcV87RgTmrMKj):
	vSqtVanQM7grF3bRuyW2zk = otNfFapeEnO(u"ࠫࠬᑜ").join(chr(PMTRpXQvDIkiNszwYGnb32a) for PMTRpXQvDIkiNszwYGnb32a in range(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠶࠺࠼ᕴ")))
	if not A7Z6OVh20eCEUx: vSqtVanQM7grF3bRuyW2zk = vSqtVanQM7grF3bRuyW2zk.decode(otNfFapeEnO(u"ࠬࡲࡡࡵ࡫ࡱ࠵ࠬᑝ"))
	ddZYovV7hJP6UFf0mqrcB = UQbj5VpAvCo2FdXqZyRsP3(vSqtVanQM7grF3bRuyW2zk, xGa2gBJRzchOVljHEv8YUwIrT)
	jSI4tU0Z2K = UQbj5VpAvCo2FdXqZyRsP3(ddZYovV7hJP6UFf0mqrcB, xGa2gBJRzchOVljHEv8YUwIrT)
	BSvne5g1lEyxafJ8k = dict(zip(ddZYovV7hJP6UFf0mqrcB,jSI4tU0Z2K)) if not HSnFtUlDIvcV87RgTmrMKj else dict(zip(jSI4tU0Z2K,ddZYovV7hJP6UFf0mqrcB))
	kjGCm2DWF9wdlTb5 = o2FdrDBimMuOw97q6QpNW8S(u"࠭ࠧᑞ").join(BSvne5g1lEyxafJ8k.get(EPdwUCv2nkAZeS,EPdwUCv2nkAZeS) for EPdwUCv2nkAZeS in kjGCm2DWF9wdlTb5)
	return kjGCm2DWF9wdlTb5
def tXZw61Uh2IyO(kjGCm2DWF9wdlTb5, xGa2gBJRzchOVljHEv8YUwIrT):
	GzWuVjwZgDKa5PCcQTM4, bnYvk9O1Am8J6, CeHjmbrQTNWvxnq3y2fk5L9 = [], ZVNvqy4iF1a9X, ZVNvqy4iF1a9X
	J7i6zfAgHY31V0k = [HaTI5u1f3SCxmMAkw(u"࠶࠶ᕵ")-int(ooYEZgPdSCMs8V6epw5v1) for ooYEZgPdSCMs8V6epw5v1 in str(xGa2gBJRzchOVljHEv8YUwIrT)[::-P2Fgh6TCOWoaHjkqBcQnvRNXe]]
	pC2c6o07NWkYvn4TeyGUwM = int(mi2ZJXCDzITuyev6gfn(u"ࠧ࠺ࠩᑟ")*len(str(xGa2gBJRzchOVljHEv8YUwIrT)))//D9yBM7wPFLz-xGa2gBJRzchOVljHEv8YUwIrT
	xGa2gBJRzchOVljHEv8YUwIrT, pC2c6o07NWkYvn4TeyGUwM = xGa2gBJRzchOVljHEv8YUwIrT % NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠸࠵࠷ᕶ"), pC2c6o07NWkYvn4TeyGUwM % NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠸࠵࠷ᕶ")
	while bnYvk9O1Am8J6 < len(kjGCm2DWF9wdlTb5):
		zzujPeXITLwqQZlmVb = J7i6zfAgHY31V0k[CeHjmbrQTNWvxnq3y2fk5L9%len(J7i6zfAgHY31V0k)]
		D3D6TF50oUBtJlvijPMW8ys = kjGCm2DWF9wdlTb5[bnYvk9O1Am8J6 : bnYvk9O1Am8J6 + zzujPeXITLwqQZlmVb]
		GzWuVjwZgDKa5PCcQTM4 += [(ord(EPdwUCv2nkAZeS)^xGa2gBJRzchOVljHEv8YUwIrT)^pC2c6o07NWkYvn4TeyGUwM for EPdwUCv2nkAZeS in D3D6TF50oUBtJlvijPMW8ys][::-P2Fgh6TCOWoaHjkqBcQnvRNXe]
		bnYvk9O1Am8J6 += zzujPeXITLwqQZlmVb
		CeHjmbrQTNWvxnq3y2fk5L9 += P2Fgh6TCOWoaHjkqBcQnvRNXe
	j3GpV25Qlvn8zgEdb7WfTLZc = chr if A7Z6OVh20eCEUx else unichr
	kjGCm2DWF9wdlTb5 = E6xdOMpqISHZCn(u"ࠨࠩᑠ").join([j3GpV25Qlvn8zgEdb7WfTLZc(EPdwUCv2nkAZeS) for EPdwUCv2nkAZeS in GzWuVjwZgDKa5PCcQTM4])
	return kjGCm2DWF9wdlTb5
def RQqNCLO5ofzZ7(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo, mq0EkDHQ1nxuK5eBrZ=ZVNvqy4iF1a9X):
	if P2Fgh6TCOWoaHjkqBcQnvRNXe:
		if isinstance(kjGCm2DWF9wdlTb5, bytes): kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.decode(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡸࡸ࡫࠾ࠧᑡ"))
		H9C1o3E076pj = L8Wkv5KCSoq.time()+mq0EkDHQ1nxuK5eBrZ if mq0EkDHQ1nxuK5eBrZ>ZVNvqy4iF1a9X else L8Wkv5KCSoq.time()
		kjGCm2DWF9wdlTb5 = ZP1LyUCS3pIBu(u"ࡸࠦࢀࢃࡼࡽࡾࡾࢁࠧᑢ").format(int(H9C1o3E076pj), kjGCm2DWF9wdlTb5)
		kjGCm2DWF9wdlTb5 = tXZw61Uh2IyO(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo)
		kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.encode(ZP1LyUCS3pIBu(u"ࠫࡺࡺࡦ࠹ࠩᑣ"))
		kjGCm2DWF9wdlTb5 = BBxt0yrLpJSHvc57i.compress(kjGCm2DWF9wdlTb5)
		kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.decode(rC5tnFDlQcRGA2(u"ࠬࡲࡡࡵ࡫ࡱ࠵ࠬᑤ"))
		kjGCm2DWF9wdlTb5 = K513Z962SFiwO0(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo, o2FdrDBimMuOw97q6QpNW8S(u"ࡆࡢ࡮ࡶࡩᕷ"))
		kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.encode(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡵࡵࡨ࠻ࠫᑥ"))
	return kjGCm2DWF9wdlTb5
def tt4BxXNIpjgV6FkvHWu0aCToy(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo, mq0EkDHQ1nxuK5eBrZ=ZVNvqy4iF1a9X):
	if P2Fgh6TCOWoaHjkqBcQnvRNXe:
		if isinstance(kjGCm2DWF9wdlTb5, bytes): kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.decode(otNfFapeEnO(u"ࠧࡶࡶࡩ࠼ࠬᑦ"))
		kjGCm2DWF9wdlTb5 = K513Z962SFiwO0(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo, KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࡕࡴࡸࡩᕸ"))
		kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.encode(rC5tnFDlQcRGA2(u"ࠨ࡮ࡤࡸ࡮ࡴ࠱ࠨᑧ"))
		kjGCm2DWF9wdlTb5 = BBxt0yrLpJSHvc57i.decompress(kjGCm2DWF9wdlTb5)
		kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.decode(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡸࡸ࡫࠾ࠧᑨ"))
		kjGCm2DWF9wdlTb5 = tXZw61Uh2IyO(kjGCm2DWF9wdlTb5, mceaCKZ2XRMpIo)
		H9C1o3E076pj, kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.split(KA26GucUHOwXL(u"ࠪࢀࢁࢂࠧᑩ"), P2Fgh6TCOWoaHjkqBcQnvRNXe)
		Nzf3CPgKdDiHB = mq0EkDHQ1nxuK5eBrZ+int(H9C1o3E076pj)-L8Wkv5KCSoq.time() if mq0EkDHQ1nxuK5eBrZ>ZVNvqy4iF1a9X else int(H9C1o3E076pj)-L8Wkv5KCSoq.time()
		if Nzf3CPgKdDiHB<ZVNvqy4iF1a9X: return XB4CjMkPFzhAHiI3q(u"ࠫࡋࡇࡉࡍࡇࡇࡣࡉࡋࡃࡓ࡛ࡓࡘࡎࡔࡇࠨᑪ")
		kjGCm2DWF9wdlTb5 = kjGCm2DWF9wdlTb5.encode(JACnOz297UuDK5HpPkc1LF(u"ࠬࡻࡴࡧ࠺ࠪᑫ"))
	return kjGCm2DWF9wdlTb5
from QV4bLIu3Gg import *
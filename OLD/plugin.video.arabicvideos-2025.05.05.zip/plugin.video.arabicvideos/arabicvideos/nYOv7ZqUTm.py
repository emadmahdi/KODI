# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'FAJERSHOW'
kL0nT7NpZdKVD3jM2OHB = '_FJS_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['التصنيفات','انشاء حساب','طلبات الزوّار']
def hH3sRBSFAr(mode,url,text):
	if   mode==390: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==391: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==392: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==393: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==399: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,399,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FAJERSHOW-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = Zy2l0g8QU5vqefaTrsw.findall('<header>.*?<h2>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ykAihXr9IU82HQqMx7tj5 in range(len(items)):
		title = items[ykAihXr9IU82HQqMx7tj5]
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,V4kF6EQiwo,391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'latest'+str(ykAihXr9IU82HQqMx7tj5))
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مختارات عشوائية',V4kF6EQiwo,391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'randoms')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أعلى الأفلام تقييماً',V4kF6EQiwo,391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'top_imdb_movies')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أعلى المسلسلات تقييماً',V4kF6EQiwo,391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'top_imdb_series')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أفلام مميزة',V4kF6EQiwo+'/movies',391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured_movies')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مسلسلات مميزة',V4kF6EQiwo+'/tvshows',391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured_tvshows')
	D3D6TF50oUBtJlvijPMW8ys = CJlTSEpZsWb0QHg5w
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="menu"(.*?)id="contenedor"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys += s67485upzYNMS3PqDelkrdfo[0]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo+'/movies',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FAJERSHOW-MENU-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="releases"(.*?)aside',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys += s67485upzYNMS3PqDelkrdfo[0]
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	vhOcSIwNZ2TC8tEPR = True
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = wAmsc95ya0LHz(title)
		if title=='الأعلى مشاهدة':
			if vhOcSIwNZ2TC8tEPR:
				title = 'الافلام '+title
				vhOcSIwNZ2TC8tEPR = False
			else: title = 'المسلسلات '+title
		if title not in qe1JPURnS9ODoCNEpbdh8i67Tur:
			if title=='أفلام': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,V4kF6EQiwo+'/movies',391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'all_movies_tvshows')
			elif title=='مسلسلات': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,V4kF6EQiwo+'/tvshows',391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'all_movies_tvshows')
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,391)
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url,type):
	D3D6TF50oUBtJlvijPMW8ys,items = [],[]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FAJERSHOW-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if type in ['featured_movies','featured_tvshows']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="content"(.*?)id="archive-content"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	elif type=='all_movies_tvshows':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="archive-content"(.*?)class="pagination"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	elif type=='top_imdb_movies':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("class='top-imdb-list tleft(.*?)class='top-imdb-list tright",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='top_imdb_series':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("class='top-imdb-list tright(.*?)footer",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall("src='(.*?)'.*?href='(.*?)'>(.*?)<",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='search':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="search-page"(.*?)class="sidebar',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='sider':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="widget(.*?)class="widget',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		xxMT4HEkmJgz = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		MNXzjK3vV7D,FwatKBi3qv,Uz8mMbZifCyvkLnct = zip(*xxMT4HEkmJgz)
		items = zip(FwatKBi3qv,MNXzjK3vV7D,Uz8mMbZifCyvkLnct)
	elif type=='randoms':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="slider-movies-tvshows"(.*?)<header>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif 'latest' in type:
		ykAihXr9IU82HQqMx7tj5 = int(type[-1:])
		bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('<header>','<end><start>')
		bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace('</div></div></div>','</div></div></div><end>')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<start>(.*?)<end>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ykAihXr9IU82HQqMx7tj5]
		if ykAihXr9IU82HQqMx7tj5==6:
			xxMT4HEkmJgz = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)" alt="(.*?)".*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			FwatKBi3qv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = zip(*xxMT4HEkmJgz)
			items = zip(FwatKBi3qv,MNXzjK3vV7D,Uz8mMbZifCyvkLnct)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="content"(.*?)class="(pagination|sidebar)',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0][0]
			if '/collection/' in url:
				items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			elif '/quality/' in url:
				items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not items and D3D6TF50oUBtJlvijPMW8ys:
		items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		if 'src=' in title: continue
		if 'serie' in title:
			title = Zy2l0g8QU5vqefaTrsw.findall('^(.*?)<.*?serie">(.*?)<',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			title = title[0][1]
			if title in wDkMP6jlz7XeN5Sp: continue
			wDkMP6jlz7XeN5Sp.append(title)
			title = '_MOD_'+title
		II4x930lvTuVqekXBNCrMy = Zy2l0g8QU5vqefaTrsw.findall('^(.*?)<',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if II4x930lvTuVqekXBNCrMy: title = II4x930lvTuVqekXBNCrMy[0]
		title = wAmsc95ya0LHz(title)
		if '/tvshows/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,393,hzGKUP1XjAoeT79MJcDF)
		elif '/episodes/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,393,hzGKUP1XjAoeT79MJcDF)
		elif '/seasons/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,393,hzGKUP1XjAoeT79MJcDF)
		elif '/collection/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,391,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,392,hzGKUP1XjAoeT79MJcDF)
	if type not in ['featured_movies','featured_tvshows']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,391,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	return
def j9zTQsrVRx2(url):
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,'url')
	url = url.replace(FFtJQalhPz,V4kF6EQiwo)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FAJERSHOW-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('class="C rated".*?>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('''<ul class=["']episodios["']>(.*?)</ul></div></div></div>''',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('''src=["'](.*?)["'].*?href=["'](.*?)["']>(.*?)</a>''',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,392,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	url = url.replace('//show.alfajertv.com/','//fajer.show/')
	bGIVq1CQTjmosZg = WYpLnF8SEJ64(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FAJERSHOW-PLAY-1st')
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('class="C rated".*?>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	MNXzjK3vV7D = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="player-option-1"(.*?)class=["|\'](sheader|pag_episodes)["|\']',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0][0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-type="(.*?)" data-post="(.*?)" data-nume="(.*?)".*?class="vid_title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for type,HGXYPrKegtmb2zE3aqTxiF,hqgIciNTRe1,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/wp-admin/admin-ajax.php?action=doo_player_ajax&post='+HGXYPrKegtmb2zE3aqTxiF+'&nume='+hqgIciNTRe1+'&type='+type
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('''id=["']download["'] class(.*?)class=["']sbox["']''',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('''img src=["'](.*?)["'].*?href=["'](.*?)["'].*?["']quality["']>(.*?)<.*?<td>(.*?)<''',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx,qqU8ZQfsNRWFGhKkjm6d4rAPHvg in items:
			if '=' in hzGKUP1XjAoeT79MJcDF:
				f862mMDqdy = hzGKUP1XjAoeT79MJcDF.split('=')[1]
				title = fUSgd7IjGYX496Hr25uFMl(f862mMDqdy,'host')
			else: title = CJlTSEpZsWb0QHg5w
			title = qqU8ZQfsNRWFGhKkjm6d4rAPHvg+YvOQBzaTAscXR9ql+title
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download____'+egYIsS2qROfpVW83kx
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
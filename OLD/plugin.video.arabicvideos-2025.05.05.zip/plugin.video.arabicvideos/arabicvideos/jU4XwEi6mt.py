# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'LIVETV'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS['PYTHON'][0]
def hH3sRBSFAr(mode,url):
	if   mode==100: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==101: SD0TxMRXiep4cjPBsnzI = fJYhg7Z9iHuRPrUDQWFB('0',True)
	elif mode==102: SD0TxMRXiep4cjPBsnzI = fJYhg7Z9iHuRPrUDQWFB('1',True)
	elif mode==103: SD0TxMRXiep4cjPBsnzI = fJYhg7Z9iHuRPrUDQWFB('2',True)
	elif mode==104: SD0TxMRXiep4cjPBsnzI = fJYhg7Z9iHuRPrUDQWFB('3',True)
	elif mode==105: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==106: SD0TxMRXiep4cjPBsnzI = fJYhg7Z9iHuRPrUDQWFB('4',True)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_M3U_'+'قوائم فيديوهات M3U',CJlTSEpZsWb0QHg5w,762)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_IPT_'+'قوائم فيديوهات IPTV',CJlTSEpZsWb0QHg5w,761)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TV0_'+'قنوات من مواقعها الأصلية',CJlTSEpZsWb0QHg5w,101)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TV4_'+'قنوات مختارة من يوتيوب',CJlTSEpZsWb0QHg5w,106)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_YUT_'+'قنوات عربية من يوتيوب',CJlTSEpZsWb0QHg5w,147)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_YUT_'+'قنوات أجنبية من يوتيوب',CJlTSEpZsWb0QHg5w,148)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',CJlTSEpZsWb0QHg5w,28)
	khqge7BVD9jPFy1S8T5Gn4QAlH('live','_MRF_'+'قناة المعارف من موقعهم',CJlTSEpZsWb0QHg5w,41)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TV1_'+'قنوات تلفزيونية عامة',CJlTSEpZsWb0QHg5w,102)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TV2_'+'قنوات تلفزيونية خاصة',CJlTSEpZsWb0QHg5w,103)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder','_TV3_'+'قنوات تلفزيونية للفحص',CJlTSEpZsWb0QHg5w,104)
	return
def fJYhg7Z9iHuRPrUDQWFB(wtJK8x2e7QPUHqFvEnSp6N5yhO1CA,showDialogs=True):
	kL0nT7NpZdKVD3jM2OHB = '_TV'+wtJK8x2e7QPUHqFvEnSp6N5yhO1CA+'_'
	wSfEHOilLYIK = {'id':CJlTSEpZsWb0QHg5w,'user':Ew2zQ8u7Ss.AV_CLIENT_IDS,'function':'list','menu':wtJK8x2e7QPUHqFvEnSp6N5yhO1CA}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',V4kF6EQiwo,wSfEHOilLYIK,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIVETV-ITEMS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = Zy2l0g8QU5vqefaTrsw.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		for PMTRpXQvDIkiNszwYGnb32a in range(len(items)):
			name = items[PMTRpXQvDIkiNszwYGnb32a][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[PMTRpXQvDIkiNszwYGnb32a] = items[PMTRpXQvDIkiNszwYGnb32a][0],items[PMTRpXQvDIkiNszwYGnb32a][1],items[PMTRpXQvDIkiNszwYGnb32a][2],name,items[PMTRpXQvDIkiNszwYGnb32a][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for nqVYufmd4GFshQeHO9vp05,FFtJQalhPz,DrKqvRJgASd4kzVZWucE,name,hzGKUP1XjAoeT79MJcDF in items:
			if '#' in nqVYufmd4GFshQeHO9vp05: continue
			if nqVYufmd4GFshQeHO9vp05!='URL': name = name+Dj62UpP5MrbTkJqhRa+VzZPgf1qW5L8auj2do9R4FpiXM7Ycy+nqVYufmd4GFshQeHO9vp05+oOQaRxBXyJ5jVnZ
			url = nqVYufmd4GFshQeHO9vp05+';;'+FFtJQalhPz+';;'+DrKqvRJgASd4kzVZWucE+';;'+wtJK8x2e7QPUHqFvEnSp6N5yhO1CA
			khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+CJlTSEpZsWb0QHg5w+name,url,105,hzGKUP1XjAoeT79MJcDF)
	else:
		if showDialogs: khqge7BVD9jPFy1S8T5Gn4QAlH('link',kL0nT7NpZdKVD3jM2OHB+'هذه الخدمة مخصصة للمبرمج فقط',CJlTSEpZsWb0QHg5w,9999)
	return
def rHwfOZb3oSgJKi(id):
	nqVYufmd4GFshQeHO9vp05,FFtJQalhPz,DrKqvRJgASd4kzVZWucE,wtJK8x2e7QPUHqFvEnSp6N5yhO1CA = id.split(';;')
	url = CJlTSEpZsWb0QHg5w
	if nqVYufmd4GFshQeHO9vp05=='URL': url = DrKqvRJgASd4kzVZWucE
	elif nqVYufmd4GFshQeHO9vp05=='YOUTUBE':
		url = Ew2zQ8u7Ss.SITESURLS['YOUTUBE'][0]+'/watch?v='+DrKqvRJgASd4kzVZWucE
		import kORBVznGat
		kORBVznGat.wTf1Sd2gij64hzacOX([url],T1QDsJlUtCGhn,'live',url)
		return
	elif nqVYufmd4GFshQeHO9vp05=='GA':
		wSfEHOilLYIK = { 'id' : CJlTSEpZsWb0QHg5w, 'user' : Ew2zQ8u7Ss.AV_CLIENT_IDS , 'function' : 'playGA1' , 'menu' : CJlTSEpZsWb0QHg5w }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,wSfEHOilLYIK,CJlTSEpZsWb0QHg5w,False,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-1st')
		if not bqIufCQz2OWExjilm.succeeded:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		cookies = bqIufCQz2OWExjilm.cookies
		HpDR8BENQVqTCh14t5ZwJ9IlUzLXie = cookies['ASP.NET_SessionId']
		url = bqIufCQz2OWExjilm.headers['Location']
		wSfEHOilLYIK = { 'id' : DrKqvRJgASd4kzVZWucE , 'user' : Ew2zQ8u7Ss.AV_CLIENT_IDS , 'function' : 'playGA2' , 'menu' : CJlTSEpZsWb0QHg5w }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+HpDR8BENQVqTCh14t5ZwJ9IlUzLXie }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,wSfEHOilLYIK,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-2nd')
		if not bqIufCQz2OWExjilm.succeeded:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		url = Zy2l0g8QU5vqefaTrsw.findall('resp":"(http.*?m3u8)(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ZgsbN5iSL48t2IhVFnmy = url[0][0]
		UUTkXYFqxNan3Ehvpy = url[0][1]
		qo2x1ibgjTI7zQ0rB9h4YH3n = 'http://38.'+FFtJQalhPz+'777/'+DrKqvRJgASd4kzVZWucE+'_HD.m3u8'+UUTkXYFqxNan3Ehvpy
		EZ3ysmOTkYz2p8rGN = qo2x1ibgjTI7zQ0rB9h4YH3n.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		t3FCBc81QqniWDbPSMxG = qo2x1ibgjTI7zQ0rB9h4YH3n.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		Uz8mMbZifCyvkLnct = ['HD','SD1','SD2']
		MNXzjK3vV7D = [qo2x1ibgjTI7zQ0rB9h4YH3n,EZ3ysmOTkYz2p8rGN,t3FCBc81QqniWDbPSMxG]
		CrqTamtPFuU = 0
		if CrqTamtPFuU == -1: return
		else: url = MNXzjK3vV7D[CrqTamtPFuU]
	elif nqVYufmd4GFshQeHO9vp05=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		wSfEHOilLYIK = { 'id' : DrKqvRJgASd4kzVZWucE , 'user' : Ew2zQ8u7Ss.AV_CLIENT_IDS , 'function' : 'playNT' , 'menu' : wtJK8x2e7QPUHqFvEnSp6N5yhO1CA }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST', V4kF6EQiwo, wSfEHOilLYIK, headers, False,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-3rd')
		if not bqIufCQz2OWExjilm.succeeded:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		url = bqIufCQz2OWExjilm.headers['Location']
		url = url.replace('%20',YvOQBzaTAscXR9ql)
		url = url.replace('%3D','=')
		if 'Learn' in DrKqvRJgASd4kzVZWucE:
			url = url.replace('NTNNile',CJlTSEpZsWb0QHg5w)
			url = url.replace('learning1','Learning')
	elif nqVYufmd4GFshQeHO9vp05=='PL':
		wSfEHOilLYIK = { 'id' : DrKqvRJgASd4kzVZWucE , 'user' : Ew2zQ8u7Ss.AV_CLIENT_IDS , 'function' : 'playPL' , 'menu' : wtJK8x2e7QPUHqFvEnSp6N5yhO1CA }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST', V4kF6EQiwo, wSfEHOilLYIK, CJlTSEpZsWb0QHg5w,False,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-4th')
		if not bqIufCQz2OWExjilm.succeeded:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		url = bqIufCQz2OWExjilm.headers['Location']
		headers = {'Referer':bqIufCQz2OWExjilm.headers['Referer']}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'POST',url, CJlTSEpZsWb0QHg5w,headers , CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-5th')
		if not bqIufCQz2OWExjilm.succeeded:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		items = Zy2l0g8QU5vqefaTrsw.findall('source src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		url = items[0]
	elif nqVYufmd4GFshQeHO9vp05 in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if nqVYufmd4GFshQeHO9vp05=='TA': DrKqvRJgASd4kzVZWucE = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		wSfEHOilLYIK = { 'id' : DrKqvRJgASd4kzVZWucE , 'user' : Ew2zQ8u7Ss.AV_CLIENT_IDS , 'function' : 'play'+nqVYufmd4GFshQeHO9vp05 , 'menu' : wtJK8x2e7QPUHqFvEnSp6N5yhO1CA }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',V4kF6EQiwo,wSfEHOilLYIK,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-6th')
		if not bqIufCQz2OWExjilm.succeeded:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه الخدمة مخصصة للمبرمج فقط')
			return
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		url = bqIufCQz2OWExjilm.headers['Location']
		if nqVYufmd4GFshQeHO9vp05=='FM':
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'GET', url, CJlTSEpZsWb0QHg5w, CJlTSEpZsWb0QHg5w, False,CJlTSEpZsWb0QHg5w,'LIVETV-PLAY-7th')
			url = bqIufCQz2OWExjilm.headers['Location']
			url = url.replace('https','http')
	ZQtv0jY9W6L8UHgpnKm(url,T1QDsJlUtCGhn,'live')
	return
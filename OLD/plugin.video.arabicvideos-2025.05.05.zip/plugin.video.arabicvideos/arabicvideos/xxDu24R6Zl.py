# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'CIMACLUP'
kL0nT7NpZdKVD3jM2OHB = '_CMC_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['موقع نتفليكس']
def hH3sRBSFAr(mode,url,text):
	if   mode==490: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==491: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==492: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==493: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==494: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==499: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text,url)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMACLUP-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dmiXC1cB7MZlb = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	dmiXC1cB7MZlb = dmiXC1cB7MZlb[0].strip('/')
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(dmiXC1cB7MZlb,'url')
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"filter AjaxifyFilter"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc:
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-filter="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/wp-content/themes/old/filter/'+ZgsbN5iSL48t2IhVFnmy+'.php'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,491)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أفلام',dmiXC1cB7MZlb+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مسلسلات',dmiXC1cB7MZlb+'/category/مسلسلات/مسلسلات-اجنبى',494,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="navigation-menu"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if ZgsbN5iSL48t2IhVFnmy=='/': continue
		if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+ZgsbN5iSL48t2IhVFnmy
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,491)
	return bGIVq1CQTjmosZg
def jSpWoLZQRIsrw7MnH5KEbu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMACLUP-SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"filter"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,491)
	return
def nvHUf8mW6E4GSw5VFRXN(url,Gy3m1diZPVuoMc2hWI6LpN=CJlTSEpZsWb0QHg5w):
	items = []
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMACLUP-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	D3D6TF50oUBtJlvijPMW8ys = CJlTSEpZsWb0QHg5w
	if '.php' in url: D3D6TF50oUBtJlvijPMW8ys = bGIVq1CQTjmosZg
	elif '?s=' in url:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"blocks(.*?)"manifest"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"Blocks(.*?)"manifest"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if not D3D6TF50oUBtJlvijPMW8ys: return
	wDkMP6jlz7XeN5Sp = []
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		title = wAmsc95ya0LHz(title)
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) حلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not ABK45TEMpciLnmIlYOafQJZ8t: ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not ABK45TEMpciLnmIlYOafQJZ8t or any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,492,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and 'حلقة' in title:
			title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,493,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,493,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('<li><a href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			title = title.replace('الصفحة ',CJlTSEpZsWb0QHg5w)
			if title!=CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,491)
	return
def j9zTQsrVRx2(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMACLUP-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('"ButtonsBarCo".*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7:
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMACLUP-EPISODES-2nd')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('"img-responsive" src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hzGKUP1XjAoeT79MJcDF: hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0]
	else: hzGKUP1XjAoeT79MJcDF = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel('ListItem.Thumb')
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"filter"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"Blocks(.*?)class="pagination"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb and '/series/' not in url:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,493,hzGKUP1XjAoeT79MJcDF)
	elif KXu2RYg3Bc:
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,492,hzGKUP1XjAoeT79MJcDF)
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = wAmsc95ya0LHz(title)
				title = title.replace('الصفحة ',CJlTSEpZsWb0QHg5w)
				if title!=CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,491)
	return
def rHwfOZb3oSgJKi(url):
	BBwfuWGxUIrdCoc4ka7 = url.strip('/')+'/?view=1'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMACLUP-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	MNXzjK3vV7D = []
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	P0ZwheAmpSHo = Zy2l0g8QU5vqefaTrsw.findall("data: 'q=(.*?)&",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	P0ZwheAmpSHo = P0ZwheAmpSHo[0]
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"serversList"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-server="(.*?)">(.*?)</li>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for onqu8EkOK3csz,title in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/wp-content/themes/old/servers/server.php?q='+P0ZwheAmpSHo+'&i='+onqu8EkOK3csz+'?named='+title+'__watch'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"embedServer".*?SRC="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		title = 'مفضل'
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]+'?named=__embed__'+title
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"downloadsList"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('<td>(.*?)</td>.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,ZgsbN5iSL48t2IhVFnmy in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			if 'anavidz' in ZgsbN5iSL48t2IhVFnmy: II4x930lvTuVqekXBNCrMy = '__خاص'
			else: II4x930lvTuVqekXBNCrMy = CJlTSEpZsWb0QHg5w
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download'+II4x930lvTuVqekXBNCrMy
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search,dmiXC1cB7MZlb=CJlTSEpZsWb0QHg5w):
	if not dmiXC1cB7MZlb: dmiXC1cB7MZlb = V4kF6EQiwo
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search:
		search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not search: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = dmiXC1cB7MZlb+'/index.php?s='+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
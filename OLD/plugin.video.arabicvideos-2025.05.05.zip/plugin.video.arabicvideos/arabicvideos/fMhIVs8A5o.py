# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
T1QDsJlUtCGhn = 'AKWAM'
kL0nT7NpZdKVD3jM2OHB = '_AKW_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
aaLfQdgre2NIOw1ks5xPCo = CJlTSEpZsWb0QHg5w
qe1JPURnS9ODoCNEpbdh8i67Tur = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def hH3sRBSFAr(mode,url,text):
	if   mode==240: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==241: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==242: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==243: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==244: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'FILTERS___'+text)
	elif mode==245: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'CATEGORIES___'+text)
	elif mode==246: SD0TxMRXiep4cjPBsnzI = cmUB62GrfeTlwqMPSQ(url)
	elif mode==247: SD0TxMRXiep4cjPBsnzI = B69Gxeydir(url)
	elif mode==248: SD0TxMRXiep4cjPBsnzI = t4Mc0DxqSCpn75RNFkgKsZLvb8uhGB()
	elif mode==249: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def t4Mc0DxqSCpn75RNFkgKsZLvb8uhGB():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AKWAM-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	xxw28ctWOj9MDy4CYPbATLXaZu3nSG = Zy2l0g8QU5vqefaTrsw.findall('home-site-btn-container.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if xxw28ctWOj9MDy4CYPbATLXaZu3nSG: xxw28ctWOj9MDy4CYPbATLXaZu3nSG = xxw28ctWOj9MDy4CYPbATLXaZu3nSG[0]
	else: xxw28ctWOj9MDy4CYPbATLXaZu3nSG = V4kF6EQiwo
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',xxw28ctWOj9MDy4CYPbATLXaZu3nSG,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AKWAM-MENU-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,249,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر محدد',V4kF6EQiwo,246)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر كامل',V4kF6EQiwo,247)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المميزة',xxw28ctWOj9MDy4CYPbATLXaZu3nSG,241,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	recent = Zy2l0g8QU5vqefaTrsw.findall('recently-container.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ZgsbN5iSL48t2IhVFnmy = recent[0]
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'أضيف حديثا',ZgsbN5iSL48t2IhVFnmy,241)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,name,D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
		if name in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,241)
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			title = name+YvOQBzaTAscXR9ql+title
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,241)
	return
def cmUB62GrfeTlwqMPSQ(website=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKWAM-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="menu(.*?)<nav',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?text">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur:
				title = title+' مصنفة'
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,245)
		if website==CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	return bGIVq1CQTjmosZg
def B69Gxeydir(website=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKWAM-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="menu(.*?)<nav',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?text">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur:
				title = title+' مفلترة'
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,244)
		if website==CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('swiper-container(.*?)swiper-button-prev',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="widget"(.*?)main-footer',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not items:
			items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
			if '/series/' in ZgsbN5iSL48t2IhVFnmy or '/shows/' in ZgsbN5iSL48t2IhVFnmy:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,242,hzGKUP1XjAoeT79MJcDF)
			elif '/movies/' in ZgsbN5iSL48t2IhVFnmy:
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,243,hzGKUP1XjAoeT79MJcDF)
			elif '/games/' not in ZgsbN5iSL48t2IhVFnmy:
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,243,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			ZgsbN5iSL48t2IhVFnmy = wAmsc95ya0LHz(ZgsbN5iSL48t2IhVFnmy)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,241)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'%20')
	url = V4kF6EQiwo + '/search?q='+QjfknOVHzZIUir
	SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	return
def j9zTQsrVRx2(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in bGIVq1CQTjmosZg:
		hzGKUP1XjAoeT79MJcDF = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel('ListItem.Icon')
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+'رابط التشغيل',url,243,hzGKUP1XjAoeT79MJcDF)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('-episodes">(.*?)<div class="widget-4',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		iypksRX5aYC = Zy2l0g8QU5vqefaTrsw.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in iypksRX5aYC:
			title = title.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,242,hzGKUP1XjAoeT79MJcDF)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,243,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,True,'AKWAM-PLAY-1st')
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('badge-danger.*?>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	HQ64YpxE19vcqra = Zy2l0g8QU5vqefaTrsw.findall('li><a href="#(.*?)".*?>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	MNXzjK3vV7D,Uz8mMbZifCyvkLnct,p3LfChWJd124eAYj78zw09SXonH,RgLVShYeIGW = [],[],[],[]
	if HQ64YpxE19vcqra:
		B9dhnlXDQ3wt08O1PI = 'mp4'
		for UVk75zSWxjyoCXBTqILdisHprMG81l,egYIsS2qROfpVW83kx in HQ64YpxE19vcqra:
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('tab-content quality" id="'+UVk75zSWxjyoCXBTqILdisHprMG81l+'".*?</div>.\s*</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			p3LfChWJd124eAYj78zw09SXonH.append(D3D6TF50oUBtJlvijPMW8ys)
			RgLVShYeIGW.append(egYIsS2qROfpVW83kx)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="qualities(.*?)<h3.*?>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			D3D6TF50oUBtJlvijPMW8ys,filename = s67485upzYNMS3PqDelkrdfo[0]
			dd9y8i42IMC3volwujLQKTzfE = ['zip','rar','txt','pdf','htm','tar','iso','html']
			B9dhnlXDQ3wt08O1PI = filename.rsplit('.',1)[1].strip(YvOQBzaTAscXR9ql)
			if B9dhnlXDQ3wt08O1PI in dd9y8i42IMC3volwujLQKTzfE:
				PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'الملف ليس فيديو ولا صوت')
				return
		p3LfChWJd124eAYj78zw09SXonH.append(D3D6TF50oUBtJlvijPMW8ys)
		RgLVShYeIGW.append(CJlTSEpZsWb0QHg5w)
	for PMTRpXQvDIkiNszwYGnb32a in range(len(p3LfChWJd124eAYj78zw09SXonH)):
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?icon-(.*?)"',p3LfChWJd124eAYj78zw09SXonH[PMTRpXQvDIkiNszwYGnb32a],Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,aCWducL5NOhyHE0 in Rp1g7OlotseGnf0NFmKk6rLxd:
			if 'torrent' in aCWducL5NOhyHE0: continue
			elif 'download' in aCWducL5NOhyHE0: type = 'download'
			elif 'play' in aCWducL5NOhyHE0: type = 'watch'
			else: type = 'unknown'
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named=__'+type+'____'+RgLVShYeIGW[PMTRpXQvDIkiNszwYGnb32a]+'__akwam'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def wwkAylgOx852(url,filter):
	eLr1mRpNf0WX75CET62FjuIgaHq = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='CATEGORIES':
		if eLr1mRpNf0WX75CET62FjuIgaHq[0]+'=' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = eLr1mRpNf0WX75CET62FjuIgaHq[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(eLr1mRpNf0WX75CET62FjuIgaHq[0:-1])):
			if eLr1mRpNf0WX75CET62FjuIgaHq[PMTRpXQvDIkiNszwYGnb32a]+'=' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = eLr1mRpNf0WX75CET62FjuIgaHq[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+y3LbIjrZvcATpNDM+'=0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+y3LbIjrZvcATpNDM+'=0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&')+'___'+YYvW68idVrJQFa.strip('&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'all')
		BBwfuWGxUIrdCoc4ka7 = url+'?'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='FILTERS':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm!=CJlTSEpZsWb0QHg5w: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'all')
		if bnCVRhKEGJ0DIYqUBsgdpm==CJlTSEpZsWb0QHg5w: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'?'+bnCVRhKEGJ0DIYqUBsgdpm
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها',BBwfuWGxUIrdCoc4ka7,241,CJlTSEpZsWb0QHg5w,'1')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',BBwfuWGxUIrdCoc4ka7,241,CJlTSEpZsWb0QHg5w,'1')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,True,'AKWAM-FILTERS_MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<form id(.*?)</form>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = Zy2l0g8QU5vqefaTrsw.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	dict = {}
	for HLQNhXe7orPjl5Vm4,name,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		items = Zy2l0g8QU5vqefaTrsw.findall('<option(.*?)>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if '=' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='CATEGORIES':
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<=1:
				if HLQNhXe7orPjl5Vm4==eLr1mRpNf0WX75CET62FjuIgaHq[-1]: nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'CATEGORIES___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				if HLQNhXe7orPjl5Vm4==eLr1mRpNf0WX75CET62FjuIgaHq[-1]: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,241,CJlTSEpZsWb0QHg5w,'1')
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,245,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='FILTERS':
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'=0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'=0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع : '+name,BBwfuWGxUIrdCoc4ka7,244,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		dict[HLQNhXe7orPjl5Vm4] = {}
		for value,ll5WFBCJKhA64tIDT8qvX in items:
			if ll5WFBCJKhA64tIDT8qvX in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			if 'value' not in value: value = ll5WFBCJKhA64tIDT8qvX
			else: value = Zy2l0g8QU5vqefaTrsw.findall('"(.*?)"',value,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
			dict[HLQNhXe7orPjl5Vm4][value] = ll5WFBCJKhA64tIDT8qvX
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'='+ll5WFBCJKhA64tIDT8qvX
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			title = ll5WFBCJKhA64tIDT8qvX+' : '#+dict[HLQNhXe7orPjl5Vm4]['0']
			title = ll5WFBCJKhA64tIDT8qvX+' : '+name
			if type=='FILTERS': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,244,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
			elif type=='CATEGORIES' and eLr1mRpNf0WX75CET62FjuIgaHq[-2]+'=' in LLnTmNF7UG4:
				mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'all')
				ysw7G3tqjo = url+'?'+mmMRqiu1zXvWZlK7hAgEQn
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ysw7G3tqjo,241,CJlTSEpZsWb0QHg5w,'1')
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,245,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&')
	Sucv4JD0rRPaBL8HFMjNt = {}
	if '=' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('=')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	fuTzgEqmbRX378cwQnJH9rhFCt = CJlTSEpZsWb0QHg5w
	J6JSN2vjp5knhiVoFLXUAWBqGsT = ['section','category','rating','year','language','formats','quality']
	for key in J6JSN2vjp5knhiVoFLXUAWBqGsT:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
		elif mode=='all': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&')
	return fuTzgEqmbRX378cwQnJH9rhFCt
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'CIMAFANS'
headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
kL0nT7NpZdKVD3jM2OHB = '_CMF_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
def hH3sRBSFAr(mode,url,text):
	if   mode==90: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==91: SD0TxMRXiep4cjPBsnzI = fJYhg7Z9iHuRPrUDQWFB(url)
	elif mode==92: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==94: SD0TxMRXiep4cjPBsnzI = GWrYbnkfSBcuX8jZILoiaemMs()
	elif mode==95: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==99: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,99,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المضاف حديثا',CJlTSEpZsWb0QHg5w,94)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الأحدث',V4kF6EQiwo+'/?type=latest',91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الأعلى تقيماً',V4kF6EQiwo+'/?type=imdb',91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الأكثر مشاهدة',V4kF6EQiwo+'/?type=view',91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المثبت',V4kF6EQiwo+'/?type=pin',91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'جديد الأفلام',V4kF6EQiwo+'/?type=newMovies',91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'جديد الحلقات',V4kF6EQiwo+'/?type=newEpisodes',91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'CIMAFANS-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="mainmenu(.*?)nav',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('<li><a href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	qe1JPURnS9ODoCNEpbdh8i67Tur = ['افلام للكبار فقط']
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = title.strip(YvOQBzaTAscXR9ql)
		if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,91)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="f-cats"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('<li><a href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = title.strip(YvOQBzaTAscXR9ql)
		if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,91)
	return bGIVq1CQTjmosZg
def fJYhg7Z9iHuRPrUDQWFB(url):
	if '/search.php' in url:
		url,search = url.split('?t=')
		headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w , 'Content-Type' : 'application/x-www-form-urlencoded' }
		data = { 't' : search }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAFANS-ITEMS-1st')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	else:
		headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'CIMAFANS-ITEMS-2nd')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="movies-items(.*?)class="listfoot"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	else: D3D6TF50oUBtJlvijPMW8ys = CJlTSEpZsWb0QHg5w
	items = Zy2l0g8QU5vqefaTrsw.findall('background-image:url\((.*?)\).*?href="(.*?)".*?movie-title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		if 'الحلقة' in title and '/c/' not in url and '/cat/' not in url:
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة [0-9]+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_'+ABK45TEMpciLnmIlYOafQJZ8t[0]
				if title not in wDkMP6jlz7XeN5Sp:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,95,hzGKUP1XjAoeT79MJcDF)
					wDkMP6jlz7XeN5Sp.append(title)
		elif '/video/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,92,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,91,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('<a href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			title = title.replace('الصفحة ',CJlTSEpZsWb0QHg5w)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,91)
	return
def j9zTQsrVRx2(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'CIMAFANS-EPISODES-1st')
	hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('img src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0]
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="episodes-panel(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		name = Zy2l0g8QU5vqefaTrsw.findall('itemprop="title">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if name: name = name[1]
		else:
			name = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel('ListItem.Label')
			if oOQaRxBXyJ5jVnZ in name: name = name.split(oOQaRxBXyJ5jVnZ,1)[1]
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?name">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+name+' - '+title,ZgsbN5iSL48t2IhVFnmy,92,hzGKUP1XjAoeT79MJcDF)
	else:
		he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall('class="movietitle"><a href="(.*?)">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if he0wn71osQ8NCFJ9xzIqrDXBMRY: ZgsbN5iSL48t2IhVFnmy,title = he0wn71osQ8NCFJ9xzIqrDXBMRY[0]
		else: ZgsbN5iSL48t2IhVFnmy,title = url,name
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,92,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	MNXzjK3vV7D,aaMuOP4j5pcD = [],[]
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'CIMAFANS-PLAY-1st')
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('text-shadow: none;">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="links-panel(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?__download'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('nav-tabs"(.*?)video-panel-more',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('id="(.*?)".*?embed src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,ZgsbN5iSL48t2IhVFnmy in items:
			title = 'سيرفر '+id
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		items = Zy2l0g8QU5vqefaTrsw.findall('data-server-src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy in items:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
			ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy)
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def GWrYbnkfSBcuX8jZILoiaemMs():
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'CIMAFANS-LATEST-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="index-last-movie(.*?)id="index-slider-movie',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		if '/video/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,92,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,91,hzGKUP1XjAoeT79MJcDF)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo + '/search.php?t='+search
	fJYhg7Z9iHuRPrUDQWFB(url)
	return
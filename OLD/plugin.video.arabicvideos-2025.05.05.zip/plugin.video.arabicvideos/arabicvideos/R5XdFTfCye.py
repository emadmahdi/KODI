# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'SERIES4WATCH'
headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
kL0nT7NpZdKVD3jM2OHB = '_SFW_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
def hH3sRBSFAr(mode,url,text):
	if   mode==210: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==211: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	elif mode==212: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==213: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==214: SD0TxMRXiep4cjPBsnzI = WdIxqokEwVz7Kj6(url)
	elif mode==215: SD0TxMRXiep4cjPBsnzI = AZhEfUkjB1Vx6cdF9(url)
	elif mode==218: SD0TxMRXiep4cjPBsnzI = HSoWh10Q39ab7xk()
	elif mode==219: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def HSoWh10Q39ab7xk():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'الموقع تغير بالكامل',message)
	return
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,219,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	url = V4kF6EQiwo+'/getpostsPin?type=one&data=pin&limit=25'
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المميزة',url,211)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('FiltersButtons(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('data-get="(.*?)".*?</i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		url = V4kF6EQiwo+'/getposts?type=one&data='+ZgsbN5iSL48t2IhVFnmy
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,url,211)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('navigation-menu(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(http.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	qe1JPURnS9ODoCNEpbdh8i67Tur = ['مسلسلات انمي','الرئيسية']
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = title.strip(YvOQBzaTAscXR9ql)
		if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,211)
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: D3D6TF50oUBtJlvijPMW8ys = bGIVq1CQTjmosZg
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('MediaGrid"(.*?)class="pagination"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		else: return
	items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	mmYWLBuEGhr5OQRvgyNApo8ldFVjP6 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		if '/series/' in ZgsbN5iSL48t2IhVFnmy: continue
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy).strip('/')
		title = wAmsc95ya0LHz(title)
		title = title.strip(YvOQBzaTAscXR9ql)
		if '/film/' in ZgsbN5iSL48t2IhVFnmy or any(value in title for value in mmYWLBuEGhr5OQRvgyNApo8ldFVjP6):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,212,hzGKUP1XjAoeT79MJcDF)
		elif '/episode/' in ZgsbN5iSL48t2IhVFnmy and 'الحلقة' in title:
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
				if title not in wDkMP6jlz7XeN5Sp:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,213,hzGKUP1XjAoeT79MJcDF)
					wDkMP6jlz7XeN5Sp.append(title)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,213,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = wAmsc95ya0LHz(ZgsbN5iSL48t2IhVFnmy)
			title = wAmsc95ya0LHz(title)
			title = title.replace('الصفحة ',CJlTSEpZsWb0QHg5w)
			if title!=CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,211)
	return
def j9zTQsrVRx2(url):
	AQNWHvng86PlixtILT7Z0BmbM1,items,rrBu78NHhgxzta4ScCld = -1,[],[]
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-EPISODES-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('ti-list-numbered(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		p3LfChWJd124eAYj78zw09SXonH = CJlTSEpZsWb0QHg5w.join(s67485upzYNMS3PqDelkrdfo)
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',p3LfChWJd124eAYj78zw09SXonH,Zy2l0g8QU5vqefaTrsw.DOTALL)
	items.append(url)
	items = set(items)
	for ZgsbN5iSL48t2IhVFnmy in items:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.strip('/')
		title = '_MOD_' + ZgsbN5iSL48t2IhVFnmy.split('/')[-1].replace('-',YvOQBzaTAscXR9ql)
		Z9ZHlis43maAITJUwNQgS0on = Zy2l0g8QU5vqefaTrsw.findall('الحلقة-(\d+)',ZgsbN5iSL48t2IhVFnmy.split('/')[-1],Zy2l0g8QU5vqefaTrsw.DOTALL)
		if Z9ZHlis43maAITJUwNQgS0on: Z9ZHlis43maAITJUwNQgS0on = Z9ZHlis43maAITJUwNQgS0on[0]
		else: Z9ZHlis43maAITJUwNQgS0on = '0'
		rrBu78NHhgxzta4ScCld.append([ZgsbN5iSL48t2IhVFnmy,title,Z9ZHlis43maAITJUwNQgS0on])
	items = sorted(rrBu78NHhgxzta4ScCld, reverse=False, key=lambda key: int(key[2]))
	iM0XCULw6s1NgZK = str(items).count('/season/')
	AQNWHvng86PlixtILT7Z0BmbM1 = str(items).count('/episode/')
	if iM0XCULw6s1NgZK>1 and AQNWHvng86PlixtILT7Z0BmbM1>0 and '/season/' not in url:
		for ZgsbN5iSL48t2IhVFnmy,title,Z9ZHlis43maAITJUwNQgS0on in items:
			if '/season/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,213)
	else:
		for ZgsbN5iSL48t2IhVFnmy,title,Z9ZHlis43maAITJUwNQgS0on in items:
			if '/season/' not in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,212)
	return
def rHwfOZb3oSgJKi(url):
	MNXzjK3vV7D = []
	WyHwgmzU0GnP = url.split('/')
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in bGIVq1CQTjmosZg:
		BBwfuWGxUIrdCoc4ka7 = url.replace(WyHwgmzU0GnP[3],'watch')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-PLAY-2nd')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="servers-list(.*?)</div>',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if items:
				id = Zy2l0g8QU5vqefaTrsw.findall('post_id=(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if id:
					DrKqvRJgASd4kzVZWucE = id[0]
					for ZgsbN5iSL48t2IhVFnmy,title in items:
						ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/?postid='+DrKqvRJgASd4kzVZWucE+'&serverid='+ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
						MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			else:
				items = Zy2l0g8QU5vqefaTrsw.findall('data-embedd=".*?(http.*?)("|&quot;)',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,Cm7xuRTdLQwZjv81V2AhKfqs04U in items:
					MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if '/download/' in bGIVq1CQTjmosZg:
		BBwfuWGxUIrdCoc4ka7 = url.replace(WyHwgmzU0GnP[3],'download')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-PLAY-3rd')
		id = Zy2l0g8QU5vqefaTrsw.findall('postId:"(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if id:
			DrKqvRJgASd4kzVZWucE = id[0]
			bsGedm1TLP7EgiUQDkCy = { 'User-Agent':CJlTSEpZsWb0QHg5w , 'X-Requested-With':'XMLHttpRequest' }
			BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo + '/ajaxCenter?_action=getdownloadlinks&postId='+DrKqvRJgASd4kzVZWucE
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,'SERIES4WATCH-PLAY-4th')
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<h3.*?(\d+)(.*?)</div>',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if s67485upzYNMS3PqDelkrdfo:
				for kZ2Rg49pOSozh6x7jXdI,D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
					items = Zy2l0g8QU5vqefaTrsw.findall('<td>(.*?)<.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
					for name,ZgsbN5iSL48t2IhVFnmy in items:
						MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__download'+'____'+kZ2Rg49pOSozh6x7jXdI)
			else:
				s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<h6(.*?)</table>',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = [Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp]
				for D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
					name = CJlTSEpZsWb0QHg5w
					items = Zy2l0g8QU5vqefaTrsw.findall('href="(http.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
					for ZgsbN5iSL48t2IhVFnmy in items:
						FFtJQalhPz = '&&' + ZgsbN5iSL48t2IhVFnmy.split('/')[2].lower() + '&&'
						FFtJQalhPz = FFtJQalhPz.replace('.com&&',CJlTSEpZsWb0QHg5w).replace('.co&&',CJlTSEpZsWb0QHg5w)
						FFtJQalhPz = FFtJQalhPz.replace('.net&&',CJlTSEpZsWb0QHg5w).replace('.org&&',CJlTSEpZsWb0QHg5w)
						FFtJQalhPz = FFtJQalhPz.replace('.live&&',CJlTSEpZsWb0QHg5w).replace('.online&&',CJlTSEpZsWb0QHg5w)
						FFtJQalhPz = FFtJQalhPz.replace('&&hd.',CJlTSEpZsWb0QHg5w).replace('&&www.',CJlTSEpZsWb0QHg5w)
						FFtJQalhPz = FFtJQalhPz.replace('&&',CJlTSEpZsWb0QHg5w)
						ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy + '?named=' + name + FFtJQalhPz + '__download'
						MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo + '/search?s='+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
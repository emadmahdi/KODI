# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from kUCfvjAP1c import *
T1QDsJlUtCGhn = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫḪ")
xxybZE0NS9L = []
headers = {yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ḫ"):CJlTSEpZsWb0QHg5w}
def U1FhgfvH58aYrwe6(url,kDBuRZAIT93zVvdxOl,HROsvP0x3fl9m6iD8LJTCqgeUS):
	url = url.replace(s97s2k0LJgl(u"ࠪ࠳ࡲ࡯ࡲࡳࡱࡵ࠳ࠬḬ"),KA26GucUHOwXL(u"ࠫ࠴࡯ࡦࡳࡣࡰࡩ࠴࠭ḭ")).replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩḮ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭࠯ࡪࡨࡵࡥࡲ࡫࠯ࠨḯ"))
	url = url.replace(HaTI5u1f3SCxmMAkw(u"ࠧ࠰ࡹ࠱ࡱࡪ࡭ࡡ࡮ࡣࡻ࠲ࡲ࡫࠯ࠨḰ"),s97s2k0LJgl(u"ࠨ࠱ࡰࡩ࡬ࡧ࡭ࡢࡺ࠱ࡱࡪ࠵ࠧḱ"))
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,zQGaM7ctZCN(u"ࠩࡊࡉ࡙࠭Ḳ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎࡇࡊࡅࡒࡇࡘ࠮࠳ࡶࡸࠬḳ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	oTt1jwGblRQc7NZ = Zy2l0g8QU5vqefaTrsw.findall(ZP1LyUCS3pIBu(u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠫࡷࡵࡰࡶ࠾࠾ࠫࡷࡵࡰࡶ࠾ࠬ࠳࠰࠿ࠪࠨࡴࡹࡴࡺ࠻ࠨḴ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	headers = {otNfFapeEnO(u"ࠬ࡞࠭ࡊࡰࡨࡶࡹ࡯ࡡࠨḵ"):rC5tnFDlQcRGA2(u"࠭ࡴࡳࡷࡨࠫḶ"),TDpFsQXHze2q30uYtGPfEIm8(u"࡙ࠧ࠯ࡌࡲࡪࡸࡴࡪࡣ࠰ࡔࡦࡸࡴࡪࡣ࡯࠱ࡉࡧࡴࡢࠩḷ"):I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡵࡷࡶࡪࡧ࡭ࡴࠩḸ"),HaTI5u1f3SCxmMAkw(u"࡛ࠩ࠱ࡎࡴࡥࡳࡶ࡬ࡥ࠲ࡖࡡࡳࡶ࡬ࡥࡱ࠳ࡃࡰ࡯ࡳࡳࡳ࡫࡮ࡵࠩḹ"):cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡪ࡮ࡲࡥࡴ࠱ࡰ࡭ࡷࡸ࡯ࡳ࠱ࡹ࡭ࡩ࡫࡯ࠨḺ")}
	headers[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࡝࠳ࡉ࡯ࡧࡵࡸ࡮ࡧ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨḻ")] = oTt1jwGblRQc7NZ[ZVNvqy4iF1a9X]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,ZP1LyUCS3pIBu(u"ࠬࡍࡅࡕࠩḼ"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈ࡜࡙ࡘࡁࡄࡖࡢࡑࡊࡍࡁࡎࡃ࡛࠱࠷ࡴࡤࠨḽ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	lYPtZ8wLeQsHSuCOFjyV = KSHcVmz2W84iQvbRDBhGldpCL.loads(bGIVq1CQTjmosZg)
	X05xlEUFQ2edTgCcDHPki9h6omB8AZ = lYPtZ8wLeQsHSuCOFjyV[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡱࡴࡲࡴࡸ࠭Ḿ")][pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡵࡷࡶࡪࡧ࡭ࡴࠩḿ")][xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡧࡥࡹࡧࠧṀ")]
	FhX9OGwaNyAEZ = []
	for lljAD6u8pm13sXYRJgvPQKB5 in range(len(X05xlEUFQ2edTgCcDHPki9h6omB8AZ)):
		egYIsS2qROfpVW83kx = X05xlEUFQ2edTgCcDHPki9h6omB8AZ[lljAD6u8pm13sXYRJgvPQKB5][Olh7n0zfV4(u"ࠪࡰࡦࡨࡥ࡭ࠩṁ")]
		Rp1g7OlotseGnf0NFmKk6rLxd = X05xlEUFQ2edTgCcDHPki9h6omB8AZ[lljAD6u8pm13sXYRJgvPQKB5][I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡲ࡯ࡲࡳࡱࡵࡷࠬṂ")]
		for ZGTnDRoctbO372Y4 in range(len(Rp1g7OlotseGnf0NFmKk6rLxd)):
			title = Rp1g7OlotseGnf0NFmKk6rLxd[ZGTnDRoctbO372Y4][s97s2k0LJgl(u"ࠬࡪࡲࡪࡸࡨࡶࠬṃ")]
			ZgsbN5iSL48t2IhVFnmy = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡨࡵࡶࡳࡷ࠿࠭Ṅ")+Rp1g7OlotseGnf0NFmKk6rLxd[ZGTnDRoctbO372Y4][pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࡭࡫ࡱ࡯ࠬṅ")]+cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩṆ")+title+zQGaM7ctZCN(u"ࠩࡢࡣࠬṇ")+kDBuRZAIT93zVvdxOl+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡣࡤ࠭Ṉ")+egYIsS2qROfpVW83kx
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	return FhX9OGwaNyAEZ
def XZt4A3pGhsHSkK7jWaI(url,kDBuRZAIT93zVvdxOl,HROsvP0x3fl9m6iD8LJTCqgeUS):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡌࡋࡔࠨṉ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,cjVhOCwybeRo7UWg92(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡄࡐࡇࡇࡐࡍࡃ࡜ࡉࡗ࠳࠱ࡴࡶࠪṊ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if A7Z6OVh20eCEUx and isinstance(bGIVq1CQTjmosZg,bytes): bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.decode(Im5KSGZYBpRvdMVsbuXg,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ṋ"))
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(VVvcQpCU3OM09n(u"ࠧࠣࡣࡳࡰࡷ࠳࡭ࡦࡰࡸࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨṌ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
		items = Zy2l0g8QU5vqefaTrsw.findall(ZP1LyUCS3pIBu(u"ࠨ࠾ࡤࠤࡨࡲࡡࡴࡵࡀࠦࡦࡶ࡬ࡳ࠯࡯࡭ࡳࡱ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬṍ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		FhX9OGwaNyAEZ = []
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+ZP1LyUCS3pIBu(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪṎ")+title+VVvcQpCU3OM09n(u"ࠪࡣࡤ࠭ṏ")+kDBuRZAIT93zVvdxOl)
	return FhX9OGwaNyAEZ
def MGCt7LSINb9Oex3BuJ8(url,kDBuRZAIT93zVvdxOl,HROsvP0x3fl9m6iD8LJTCqgeUS):
	TpDOck7mtVlQ4ej = url.split(Olh7n0zfV4(u"ࠫ࠴࠭Ṑ"))[h6sIkJOT5PB2vCxqo4LFag70wA(u"࠸භ")]
	UBanXr1KiQbhYvp0 = qqth6cAFkaRowLlUeMng.b64decode(TpDOck7mtVlQ4ej)
	if A7Z6OVh20eCEUx: UBanXr1KiQbhYvp0 = UBanXr1KiQbhYvp0.decode(Im5KSGZYBpRvdMVsbuXg)
	Ia4CvrH0FmVXPLlzByRt9idwuKWpj = sWzgdLCjSVwaMuhFkNf1Uop(UBanXr1KiQbhYvp0)+cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ṑ")+HROsvP0x3fl9m6iD8LJTCqgeUS
	return [Ia4CvrH0FmVXPLlzByRt9idwuKWpj]
def vvTHyd3GVe(JeCNYRGHZzjVbLS95v4iw,source):
	DIA54R1lwcTz7OZPjX6a,uuYRW8lfmzgCKVZXAOMDkaNG5IPE = [],[]
	for A8CdXURF1Tkrp0t6LJ in JeCNYRGHZzjVbLS95v4iw:
		WlXkHQR2mp7wKBgGYh4 = Zy2l0g8QU5vqefaTrsw.findall(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭࡮ࡢ࡯ࡨࡨࡂ࠴ࠪࡀࡡࡢࠬ࠳࠰࠿ࠪࡡࡢࠫṒ"),A8CdXURF1Tkrp0t6LJ+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡠࡡࠪṓ"),Zy2l0g8QU5vqefaTrsw.DOTALL)
		BQ4XMcOAlP8KCyRpJWrLmIUhfYj = WlXkHQR2mp7wKBgGYh4[ZVNvqy4iF1a9X] if WlXkHQR2mp7wKBgGYh4 else CJlTSEpZsWb0QHg5w
		H3Hm481dSVokzW,M95MBGDtxT,mqk6U7HgpIBNdl9fxJ0KzTsj = A8CdXURF1Tkrp0t6LJ,CJlTSEpZsWb0QHg5w,[]
		if Olh7n0zfV4(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩṔ") in A8CdXURF1Tkrp0t6LJ: H3Hm481dSVokzW,M95MBGDtxT = A8CdXURF1Tkrp0t6LJ.split(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪṕ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)
		try:
			if O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡥࡱࡨࡡࡱ࡮ࡤࡽࡪࡸࠧṖ") in H3Hm481dSVokzW: mqk6U7HgpIBNdl9fxJ0KzTsj = XZt4A3pGhsHSkK7jWaI(H3Hm481dSVokzW,BQ4XMcOAlP8KCyRpJWrLmIUhfYj,M95MBGDtxT)
			elif yylSaxCLfkte(u"ࠫࡲ࡫ࡧࡢ࡯ࡤࡼࠬṗ") in H3Hm481dSVokzW: mqk6U7HgpIBNdl9fxJ0KzTsj = U1FhgfvH58aYrwe6(H3Hm481dSVokzW,BQ4XMcOAlP8KCyRpJWrLmIUhfYj,M95MBGDtxT)
			elif s97s2k0LJgl(u"ࠬ࠵࡬࠰ࡣࡋࡖ࠵ࡩࡈࡎ࠸ࡏࡽ࠾࠭Ṙ") in H3Hm481dSVokzW: mqk6U7HgpIBNdl9fxJ0KzTsj = MGCt7LSINb9Oex3BuJ8(H3Hm481dSVokzW,BQ4XMcOAlP8KCyRpJWrLmIUhfYj,M95MBGDtxT)
		except: pass
		if mqk6U7HgpIBNdl9fxJ0KzTsj:
			for otCOTHujWKp7Dn6dvcafPqlx in mqk6U7HgpIBNdl9fxJ0KzTsj:
				BB342QvkiWZzP7dTxINbsnrRX8q9,zOREmB0WVndrDcfXJlqH39UTNM4 = otCOTHujWKp7Dn6dvcafPqlx,CJlTSEpZsWb0QHg5w
				if Olh7n0zfV4(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧṙ") in otCOTHujWKp7Dn6dvcafPqlx: BB342QvkiWZzP7dTxINbsnrRX8q9,zOREmB0WVndrDcfXJlqH39UTNM4 = otCOTHujWKp7Dn6dvcafPqlx.split(pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨṚ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)
				if BB342QvkiWZzP7dTxINbsnrRX8q9 not in DIA54R1lwcTz7OZPjX6a:
					DIA54R1lwcTz7OZPjX6a.append(BB342QvkiWZzP7dTxINbsnrRX8q9)
					uuYRW8lfmzgCKVZXAOMDkaNG5IPE.append(otCOTHujWKp7Dn6dvcafPqlx)
		elif H3Hm481dSVokzW not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(H3Hm481dSVokzW)
			uuYRW8lfmzgCKVZXAOMDkaNG5IPE.append(A8CdXURF1Tkrp0t6LJ)
	return uuYRW8lfmzgCKVZXAOMDkaNG5IPE
def gML0FRnzDximsAw2ISCEdtZ(source,kcxAmftieK56PE9TqbDHdSrF8,url):
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤ࡫࡯࡮ࡥ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࡵࠣࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨṛ")+source+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࠣࡡࠥࠦࠠࠡࡖࡼࡴࡪࡀࠠ࡜ࠢࠪṜ")+kcxAmftieK56PE9TqbDHdSrF8+TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࠤࡢ࠭ṝ"))
	TT0poafKmYtg = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,GISOTJh20W(u"ࠫࡩ࡯ࡣࡵࠩṞ"),mi2ZJXCDzITuyev6gfn(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨṟ"),rC5tnFDlQcRGA2(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬṠ"))
	VVrQHyxnMeu3J1YTAfRsm = L8Wkv5KCSoq.strftime(E6xdOMpqISHZCn(u"࡛ࠧࠦ࠱ࠩࡲ࠴ࠥࡥࠢࠨࡌ࠿ࠫࡍࠨṡ"),L8Wkv5KCSoq.gmtime(U6YgVKS9rAmwe1RTPlQnfiGs))
	YjATkiozK34fNw1btrEeU8 = VVrQHyxnMeu3J1YTAfRsm,url
	key = source+NaE5l67ROx+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+NaE5l67ROx+str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX)
	LLyhViKbxMntl5JSk = CJlTSEpZsWb0QHg5w
	if key not in list(TT0poafKmYtg.keys()): TT0poafKmYtg[key] = [YjATkiozK34fNw1btrEeU8]
	else:
		if url not in str(TT0poafKmYtg[key]): TT0poafKmYtg[key].append(YjATkiozK34fNw1btrEeU8)
		else: LLyhViKbxMntl5JSk = EcjO3giln2kQTdBY0XLAG(u"ࠨ࡞ࡱࠤ์ึวࠡษ็ๅ๏ี๊้่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎๊ࠥๅࠡฬ฼้้࠭Ṣ")
	o5fjtv7pDH = ZVNvqy4iF1a9X
	for key in list(TT0poafKmYtg.keys()):
		TT0poafKmYtg[key] = list(set(TT0poafKmYtg[key]))
		o5fjtv7pDH += len(TT0poafKmYtg[key])
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,GISOTJh20W(u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦอั้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪṣ")+LLyhViKbxMntl5JSk+zQGaM7ctZCN(u"ࠪࡠࡳࡢ࡮ࠡๆ็฽้๋ࠠศๆหี๋อๅอࠢํๆํ๋ࠠษฮ่฽่ࠥวว็ฬࠤออไโ์า๎ํํวหࠢส่ฯ๐ࠠๅ็ࠣ๎ัีࠠๅ้สࠤ๊๊แศฬࠣๅ๏ี๊้๋ࠢืํ็๋ࠠ฻ิฺࠥ฿ไ๋ๅࠣห้ฮั็ษ่ะࠥษๆࠡฬิื้ࠦ็ั้ࠣห้่วว็ฬࠤส๊้ࠡษ็้อืๅอࠢ฼๊ิ๋วࠡ์ุฬาูࠦะั๊หࠥ࠻ࠠโ์า๎ํํวหࠩṤ")+o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡡࡴ࡜࡯ࠩṥ")+KA26GucUHOwXL(u"ࠬ฿ฯะࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢส่็อฦๆหࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠨṦ")+str(o5fjtv7pDH))
	if o5fjtv7pDH>=GGsP9SDod4iUBm6kNMfLw:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KA26GucUHOwXL(u"࠭วๅสิ๊ฬ๋ฬࠡฮ่฽่ࠥวว็ฬࠤๆ๐็ศࠢ࠸ࠤๆ๐ฯ๋๊๊หฯࠦไๆࠢํะิࠦวๅสิ๊ฬ๋ฬࠡๆ๊ห๋ࠥไโษอࠤๆ๐ฯ๋๊ࠣ࠲࠳ࠦำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡส่ืาࠦ็ั้ࠣห้่วว็ฬࠤࡡࡴ࡜࡯๊่ࠢࠥะั๋ัࠣษึูวๅ๊ࠢิ์ࠦวๅไสส๊ฯࠠใส็ࠤู๊อ่ษࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡๆๆ๎ࠥ๐โ้็ࠣห้๋ศา็ฯࠤอ็อึ๊ࠢิ์ࠦวๅใํำ๏๎็ศฬࠣรࠦࠧࠧṧ"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
			lv6X3tZSQcs4LOEuW2ofG70Db5 = CJlTSEpZsWb0QHg5w
			for key in list(TT0poafKmYtg.keys()):
				lv6X3tZSQcs4LOEuW2ofG70Db5 += rJ9cgWz4FU+key
				togV6bjrMCB5LEaqs0cImnSUDYFw = sorted(TT0poafKmYtg[key],reverse=VJZIMkUN5siqB21Pf,key=lambda mgN6JukZYTAfDS: mgN6JukZYTAfDS[ZVNvqy4iF1a9X])
				for VVrQHyxnMeu3J1YTAfRsm,url in togV6bjrMCB5LEaqs0cImnSUDYFw:
					lv6X3tZSQcs4LOEuW2ofG70Db5 += rJ9cgWz4FU+VVrQHyxnMeu3J1YTAfRsm+NaE5l67ROx+sWzgdLCjSVwaMuhFkNf1Uop(url)
				lv6X3tZSQcs4LOEuW2ofG70Db5 += KA26GucUHOwXL(u"ࠧ࡝ࡰ࡟ࡲࠬṨ")
			import tAoP1fdO67
			cn0XyId7MkTCE1RifFhwQDN = tAoP1fdO67.nD9fpAQ50YatjGr(rC5tnFDlQcRGA2(u"ࠨࡘ࡬ࡨࡪࡵࡳࠨṩ"),CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡌࡂ࡛ࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ṫ"),CJlTSEpZsWb0QHg5w,lv6X3tZSQcs4LOEuW2ofG70Db5)
			if cn0XyId7MkTCE1RifFhwQDN: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,otNfFapeEnO(u"ࠪฮ๊ࠦวๅวิืฬ๊ࠠษ่ฯหา࠭ṫ"))
			else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yylSaxCLfkte(u"ࠫๆฺไหࠢ฼้้๐ษࠡษ็ษึูวๅࠩṬ"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=-P2Fgh6TCOWoaHjkqBcQnvRNXe:
			TT0poafKmYtg = {}
			oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,E6xdOMpqISHZCn(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨṭ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬṮ"))
	if TT0poafKmYtg: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪṯ"),otNfFapeEnO(u"ࠨࡕࡌࡘࡊ࡙࡟ࡆࡔࡕࡓࡗ࡙ࠧṰ"),TT0poafKmYtg,XlNnqz758Zeuo)
	return
def wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,source,kcxAmftieK56PE9TqbDHdSrF8,url):
	if not FhX9OGwaNyAEZ:
		gML0FRnzDximsAw2ISCEdtZ(source,kcxAmftieK56PE9TqbDHdSrF8,url)
		return
	TT7WzUmOPGJIbheSrXvukiDj30c = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(s97s2k0LJgl(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ṱ"))
	E0u8lXO957QBkWtnL2Fyfa6vxmJrjp = cjVhOCwybeRo7UWg92(u"ࠪ࠱ࠬṲ") not in TT7WzUmOPGJIbheSrXvukiDj30c
	mqk6U7HgpIBNdl9fxJ0KzTsj = vvTHyd3GVe(FhX9OGwaNyAEZ[:],source)
	if mqk6U7HgpIBNdl9fxJ0KzTsj!=FhX9OGwaNyAEZ and not E0u8lXO957QBkWtnL2Fyfa6vxmJrjp:
		xPXY4LOQZJMT2jtvcG0IlCHm = []
		for A8CdXURF1Tkrp0t6LJ in FhX9OGwaNyAEZ:
			GXafYFdT3Mb5,HROsvP0x3fl9m6iD8LJTCqgeUS = A8CdXURF1Tkrp0t6LJ,CJlTSEpZsWb0QHg5w
			if ZP1LyUCS3pIBu(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬṳ") in A8CdXURF1Tkrp0t6LJ: GXafYFdT3Mb5,HROsvP0x3fl9m6iD8LJTCqgeUS = A8CdXURF1Tkrp0t6LJ.split(mi2ZJXCDzITuyev6gfn(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ṵ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)
			HROsvP0x3fl9m6iD8LJTCqgeUS = HROsvP0x3fl9m6iD8LJTCqgeUS.replace(s97s2k0LJgl(u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧṵ"),VVvcQpCU3OM09n(u"ࠧࠨṶ")).replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬṷ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࠪṸ")).replace(zQGaM7ctZCN(u"ࠪࡣࡤ࡫࡭ࡣࡧࡧࠫṹ"),KA26GucUHOwXL(u"ࠫࠬṺ"))
			xPXY4LOQZJMT2jtvcG0IlCHm.append(HROsvP0x3fl9m6iD8LJTCqgeUS)
		CrqTamtPFuU = T4TK17YsEfZJ(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬหุ่ษิࠤ็๎วว็ࠣห้า่ะหࠪṻ"),xPXY4LOQZJMT2jtvcG0IlCHm)
	FhX9OGwaNyAEZ = list(set(mqk6U7HgpIBNdl9fxJ0KzTsj))
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = TPqjAnFQ9dNoh7WpHtrzX56JVBuk(FhX9OGwaNyAEZ,source)
	if Ew2zQ8u7Ss.resolveonly:
		JCi4l3R2KmHo9zsnY8y = NDtHdSWmUvn2ZcVA(Uz8mMbZifCyvkLnct,MNXzjK3vV7D,source,VJZIMkUN5siqB21Pf)
		return
	vtlCmM9S1D407NTAUYb3ygQ8,nmREDwuel7S35JyF2BQ9KzbTv,I2bFxyp7VABu3oiPXfU9CORDZJ8Mh,JCi4l3R2KmHo9zsnY8y,oF6tfb91jMxULaIGKgYmyA8,jglfWFcvo1mAdH9yeROS7XKNxu = VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,[],CJlTSEpZsWb0QHg5w,[]
	K5W8kUxMoViJI6r9nywBbF7OlHqgh = VJZIMkUN5siqB21Pf if source in ttN9jO4XAVKs5b1i82CqGvxMHQBmYg else w2qb6lf5EM
	if K5W8kUxMoViJI6r9nywBbF7OlHqgh:
		nnolt2gkzSbFv5wCjUD7W8 = ZVNvqy4iF1a9X
		NrHamiKFWTu = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭࡬ࡪࡵࡷࠫṼ"),VVvcQpCU3OM09n(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡖ࡙ࡈࡉࡅࡆࡆࡈࡈࠬṽ"))
		Bke47Nz6RHTCFbYVyuOvf5X1r = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,KA26GucUHOwXL(u"ࠨ࡮࡬ࡷࡹ࠭Ṿ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣ࡚ࡔࡋࡏࡑ࡚ࡒࠬṿ"))
		kp179Z2Q8gP3056lhALsnT = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,ZP1LyUCS3pIBu(u"ࠪࡰ࡮ࡹࡴࠨẀ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭ẁ"))
		ykAihXr9IU82HQqMx7tj5 = ZVNvqy4iF1a9X
		for title,ZgsbN5iSL48t2IhVFnmy in list(zip(Uz8mMbZifCyvkLnct,MNXzjK3vV7D)):
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split(GISOTJh20W(u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭Ẃ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
			if ZgsbN5iSL48t2IhVFnmy in NrHamiKFWTu:
				nnolt2gkzSbFv5wCjUD7W8 += P2Fgh6TCOWoaHjkqBcQnvRNXe
				Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = ZHWTM8prgq7xyI9026PfEOJ+title+oOQaRxBXyJ5jVnZ
			elif ZgsbN5iSL48t2IhVFnmy in kp179Z2Q8gP3056lhALsnT:
				nnolt2gkzSbFv5wCjUD7W8 += P2Fgh6TCOWoaHjkqBcQnvRNXe
				Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = Dj62UpP5MrbTkJqhRa+title+oOQaRxBXyJ5jVnZ
			elif ZgsbN5iSL48t2IhVFnmy in Bke47Nz6RHTCFbYVyuOvf5X1r:
				nnolt2gkzSbFv5wCjUD7W8 += P2Fgh6TCOWoaHjkqBcQnvRNXe
				Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = title
			else:
				nnolt2gkzSbFv5wCjUD7W8 += P2Fgh6TCOWoaHjkqBcQnvRNXe
				Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = title
			ykAihXr9IU82HQqMx7tj5 += P2Fgh6TCOWoaHjkqBcQnvRNXe
		jglfWFcvo1mAdH9yeROS7XKNxu = [Ym6q5M4TocDaA013RjFQ+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭แฮืࠣะ๊๐ูࠡษ็ื๏ืแาษอࠫẃ")+oOQaRxBXyJ5jVnZ]
	else: oF6tfb91jMxULaIGKgYmyA8 = Ym6q5M4TocDaA013RjFQ+otNfFapeEnO(u"ࠧฤะอีࠥอไิ์ิๅึࠦวๅ็้หุฮࠧẄ")+oOQaRxBXyJ5jVnZ
	while w2qb6lf5EM:
		mVKHUFYcpBEvy4kSPx = w2qb6lf5EM
		if K5W8kUxMoViJI6r9nywBbF7OlHqgh:
			if E0u8lXO957QBkWtnL2Fyfa6vxmJrjp and len(Uz8mMbZifCyvkLnct)==P2Fgh6TCOWoaHjkqBcQnvRNXe: CrqTamtPFuU = P2Fgh6TCOWoaHjkqBcQnvRNXe
			else:
				ffHAV7XzjI1tYesJZyPNSd6TQ5vcb = str(Uz8mMbZifCyvkLnct).count(ZHWTM8prgq7xyI9026PfEOJ)
				Nj9ZUrDEBpYgaF3uWStRv01x = str(Uz8mMbZifCyvkLnct).count(Dj62UpP5MrbTkJqhRa)
				QJ3EuPUhMwRtdy5O06bijZxlASp7X = len(Uz8mMbZifCyvkLnct)-ffHAV7XzjI1tYesJZyPNSd6TQ5vcb-Nj9ZUrDEBpYgaF3uWStRv01x
				if BB7oCRfQNSYj5qDhTUevV: oF6tfb91jMxULaIGKgYmyA8 = Dj62UpP5MrbTkJqhRa+mi2ZJXCDzITuyev6gfn(u"ࠨࠢࠣࠤุ๐ฦส࠼ࠪẅ")+str(Nj9ZUrDEBpYgaF3uWStRv01x)+oOQaRxBXyJ5jVnZ+zQGaM7ctZCN(u"ࠩࠣࠤ๋ࠥฬ่๊็อ࠿࠭Ẇ")+str(QJ3EuPUhMwRtdy5O06bijZxlASp7X)+ZHWTM8prgq7xyI9026PfEOJ+VVvcQpCU3OM09n(u"ࠪะ๏ีษ࠻ࠩẇ")+str(ffHAV7XzjI1tYesJZyPNSd6TQ5vcb)+oOQaRxBXyJ5jVnZ
				else: oF6tfb91jMxULaIGKgYmyA8 = ZHWTM8prgq7xyI9026PfEOJ+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫั๐ฯส࠼ࠪẈ")+str(ffHAV7XzjI1tYesJZyPNSd6TQ5vcb)+oOQaRxBXyJ5jVnZ+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࠦࠠࠡ็ฯ๋ํ๊ษ࠻ࠩẉ")+str(QJ3EuPUhMwRtdy5O06bijZxlASp7X)+Dj62UpP5MrbTkJqhRa+JACnOz297UuDK5HpPkc1LF(u"࠭ࠠࠡࠢึ๎หฯ࠺ࠨẊ")+str(Nj9ZUrDEBpYgaF3uWStRv01x)+oOQaRxBXyJ5jVnZ
				CrqTamtPFuU = T4TK17YsEfZJ(oF6tfb91jMxULaIGKgYmyA8,jglfWFcvo1mAdH9yeROS7XKNxu+Uz8mMbZifCyvkLnct)
			if CrqTamtPFuU==ZVNvqy4iF1a9X:
				mVKHUFYcpBEvy4kSPx = VJZIMkUN5siqB21Pf
				start,end = ZVNvqy4iF1a9X,len(Uz8mMbZifCyvkLnct)-P2Fgh6TCOWoaHjkqBcQnvRNXe
				JCi4l3R2KmHo9zsnY8y = NDtHdSWmUvn2ZcVA(Uz8mMbZifCyvkLnct,MNXzjK3vV7D,source,w2qb6lf5EM)
				I2bFxyp7VABu3oiPXfU9CORDZJ8Mh = s97s2k0LJgl(u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࡡࡤࡰࡱ࠭ẋ") if JCi4l3R2KmHo9zsnY8y else cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩẌ")
			elif CrqTamtPFuU>ZVNvqy4iF1a9X: start,end = CrqTamtPFuU-P2Fgh6TCOWoaHjkqBcQnvRNXe,CrqTamtPFuU-P2Fgh6TCOWoaHjkqBcQnvRNXe
		else:
			if E0u8lXO957QBkWtnL2Fyfa6vxmJrjp and len(Uz8mMbZifCyvkLnct)==P2Fgh6TCOWoaHjkqBcQnvRNXe: CrqTamtPFuU = ZVNvqy4iF1a9X
			else: CrqTamtPFuU = T4TK17YsEfZJ(oF6tfb91jMxULaIGKgYmyA8,Uz8mMbZifCyvkLnct)
			start,end = CrqTamtPFuU,CrqTamtPFuU
		if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe:
			I2bFxyp7VABu3oiPXfU9CORDZJ8Mh = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫẍ")
			break
		if mVKHUFYcpBEvy4kSPx:
			I2bFxyp7VABu3oiPXfU9CORDZJ8Mh = VVvcQpCU3OM09n(u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࡤࡵ࡮ࡦࠩẎ")
			JCi4l3R2KmHo9zsnY8y = NDtHdSWmUvn2ZcVA([Uz8mMbZifCyvkLnct[start]],[MNXzjK3vV7D[start]],source,w2qb6lf5EM)
			title,ZgsbN5iSL48t2IhVFnmy,nmREDwuel7S35JyF2BQ9KzbTv,RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd,MqKrNmGt0SCihdw6XHlR95UAxEWn = JCi4l3R2KmHo9zsnY8y[ZVNvqy4iF1a9X]
			F5aB7XeozwKDVJOt3SUy8l9,Y0mGawWoBRvJ5fxutl7ekhgZ8U4I = Q5A9BT62tEfbGcUsduOP(title,ZgsbN5iSL48t2IhVFnmy,RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd,source,kcxAmftieK56PE9TqbDHdSrF8)
			if F5aB7XeozwKDVJOt3SUy8l9 in [pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩẏ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭Ẑ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧẑ")]:
				vtlCmM9S1D407NTAUYb3ygQ8 = w2qb6lf5EM
				break
			else:
				if not nmREDwuel7S35JyF2BQ9KzbTv: nmREDwuel7S35JyF2BQ9KzbTv = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡗ࡫ࡧࡩࡴࠦࡰ࡭ࡣࡼࠤ࡫ࡧࡩ࡭ࡧࡧࠫẒ")
				title = Dj62UpP5MrbTkJqhRa+title+oOQaRxBXyJ5jVnZ
				JCi4l3R2KmHo9zsnY8y[ZVNvqy4iF1a9X] = title,ZgsbN5iSL48t2IhVFnmy,nmREDwuel7S35JyF2BQ9KzbTv,RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd,MqKrNmGt0SCihdw6XHlR95UAxEWn
				ArUaIxjdRyXDECgwtBGhenP = ZgsbN5iSL48t2IhVFnmy.split(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩẓ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
				oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,rC5tnFDlQcRGA2(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡘ࡛ࡃࡄࡇࡈࡈࡊࡊࠧẔ"),ArUaIxjdRyXDECgwtBGhenP)
				JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,GISOTJh20W(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬẕ"),ArUaIxjdRyXDECgwtBGhenP,[nmREDwuel7S35JyF2BQ9KzbTv,title,ZgsbN5iSL48t2IhVFnmy],DRmUs7l1O4xLeZYzGITXk)
			if nmREDwuel7S35JyF2BQ9KzbTv==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩẖ"): break
			undycCUGvE3aiNzF24sHWbX0 = TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡡࡌࡆࡈࡗࡡࠥࠦࠧẗ")+nmREDwuel7S35JyF2BQ9KzbTv.replace(rJ9cgWz4FU,Olh7n0zfV4(u"࠭࡜࡯࡝ࡏࡉࡋ࡚࡝ࠡࠢࠪẘ")) if nmREDwuel7S35JyF2BQ9KzbTv.count(rJ9cgWz4FU)>Olh7n0zfV4(u"࠸ම") else rJ9cgWz4FU+nmREDwuel7S35JyF2BQ9KzbTv
			if yUMRP0QKIzY9BDnsV784TZmwkf(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨẙ") not in source: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,otNfFapeEnO(u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊ࡠࡳ࠭ẚ")+undycCUGvE3aiNzF24sHWbX0,profile=yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺࠧẛ"))
			if len(MNXzjK3vV7D)==P2Fgh6TCOWoaHjkqBcQnvRNXe and nmREDwuel7S35JyF2BQ9KzbTv: break
		for ykAihXr9IU82HQqMx7tj5 in range(start,end+P2Fgh6TCOWoaHjkqBcQnvRNXe):
			lACrje7vm1Ii9fgJT = ZVNvqy4iF1a9X if mVKHUFYcpBEvy4kSPx else ykAihXr9IU82HQqMx7tj5
			title,ZgsbN5iSL48t2IhVFnmy,nmREDwuel7S35JyF2BQ9KzbTv,RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd,MqKrNmGt0SCihdw6XHlR95UAxEWn = JCi4l3R2KmHo9zsnY8y[lACrje7vm1Ii9fgJT]
			Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5].replace(Dj62UpP5MrbTkJqhRa,CJlTSEpZsWb0QHg5w).replace(ZHWTM8prgq7xyI9026PfEOJ,CJlTSEpZsWb0QHg5w).replace(y9hsdr4BK7wI0kS,CJlTSEpZsWb0QHg5w).replace(oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w)
			if MqKrNmGt0SCihdw6XHlR95UAxEWn==mi2ZJXCDzITuyev6gfn(u"ࠪࡷࡺࡩࡣࡦࡵࡶࠫẜ"): Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = ZHWTM8prgq7xyI9026PfEOJ+Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5]+oOQaRxBXyJ5jVnZ
			elif MqKrNmGt0SCihdw6XHlR95UAxEWn==GISOTJh20W(u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬẝ"): Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = Dj62UpP5MrbTkJqhRa+Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5]+oOQaRxBXyJ5jVnZ
			else: Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5] = Uz8mMbZifCyvkLnct[ykAihXr9IU82HQqMx7tj5]
	if I2bFxyp7VABu3oiPXfU9CORDZJ8Mh==O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡴ࡯ࡵࡡࡵࡩࡸࡵ࡬ࡷࡣࡥࡰࡪ࠭ẞ"): PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ไๅลึๅ๊ࠥวࠡ์๋ะิࠦำ๋ำไีฬะࠠอ์าอࠥ็๊้ࠡำหࠥอไโ์า๎ํࠦ࠮࠯ࠢะหํ๊ࠠฤ่ࠣฮอำหࠡ฻้ࠤ์ึวࠡษ็ๅ๏ี๊้ࠢไ๎๋่ࠥศไ฼ࠤศิั๊ࠢไ๎ࠥํะศࠢส่อืๆศ็ฯࠫẟ"))
	if not vtlCmM9S1D407NTAUYb3ygQ8 or I2bFxyp7VABu3oiPXfU9CORDZJ8Mh in [yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡤࡣࡱࡧࡪࡲࡥࡥࠩẠ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡰࡲࡸࡤࡸࡥࡴࡱ࡯ࡺࡦࡨ࡬ࡦࠩạ")] or nmREDwuel7S35JyF2BQ9KzbTv:
		M1ZhJtx9FrvpBL5PQgudw7E = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩẢ"))
	return
def NDtHdSWmUvn2ZcVA(steS3aGdomU,FhX9OGwaNyAEZ,source,showDialogs):
	global Mk5xlBHF01Vr6,sf8h9NWETdlaQyrM0SwxeXICz,ppbVwZH5eBvodsMNqGU,yye0M5vwOLzKGTQpPx78bikHIr,vv8EJLFdUbn5mxM7V13AePfXG,SYZLFWxJva9PIVEOAR
	Mk5xlBHF01Vr6,sf8h9NWETdlaQyrM0SwxeXICz,ppbVwZH5eBvodsMNqGU,yye0M5vwOLzKGTQpPx78bikHIr = [],[],[],[]
	vv8EJLFdUbn5mxM7V13AePfXG,SYZLFWxJva9PIVEOAR = [],[]
	SD0TxMRXiep4cjPBsnzI,hoy1COxZzD8,new = [],[],[]
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY)
	count = len(FhX9OGwaNyAEZ)
	for lljAD6u8pm13sXYRJgvPQKB5 in range(count):
		Mk5xlBHF01Vr6.append(gZvlfk6xhACbXcD5j0KBLiVM1)
		sf8h9NWETdlaQyrM0SwxeXICz.append(gZvlfk6xhACbXcD5j0KBLiVM1)
		ppbVwZH5eBvodsMNqGU.append(gZvlfk6xhACbXcD5j0KBLiVM1)
		yye0M5vwOLzKGTQpPx78bikHIr.append(gZvlfk6xhACbXcD5j0KBLiVM1)
		vv8EJLFdUbn5mxM7V13AePfXG.append(gZvlfk6xhACbXcD5j0KBLiVM1)
		SYZLFWxJva9PIVEOAR.append(ZVNvqy4iF1a9X)
		title = steS3aGdomU[lljAD6u8pm13sXYRJgvPQKB5]
		ZgsbN5iSL48t2IhVFnmy = FhX9OGwaNyAEZ[lljAD6u8pm13sXYRJgvPQKB5].strip(YvOQBzaTAscXR9ql).strip(TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࠪࠬả")).strip(pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡄ࠭Ấ")).strip(pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࠵ࠧấ"))
		if count>P2Fgh6TCOWoaHjkqBcQnvRNXe and showDialogs: KhwN2zcb7iMkjS5E4WURxByPGon(KA26GucUHOwXL(u"࠭แฮืࠣื๏ืแาࠢิๆ๊ࠦࠠࠨẦ")+str(lljAD6u8pm13sXYRJgvPQKB5+Olh7n0zfV4(u"࠷ඹ")),title)
		YpHCeNvqQy7EarGhlKwnWmRM = [XB4CjMkPFzhAHiI3q(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨầ"),HaTI5u1f3SCxmMAkw(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭Ẩ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡄࡏ࡜ࡇࡍࠨẩ")]
		if source in YpHCeNvqQy7EarGhlKwnWmRM: vv8EJLFdUbn5mxM7V13AePfXG[lljAD6u8pm13sXYRJgvPQKB5] = FBTsWkd32lpSVnH6J4G8mLZiCN5r(title,ZgsbN5iSL48t2IhVFnmy,source,lljAD6u8pm13sXYRJgvPQKB5,w2qb6lf5EM)
		else:
			if P2Fgh6TCOWoaHjkqBcQnvRNXe:
				xgvnIVrzND9X7H = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=FBTsWkd32lpSVnH6J4G8mLZiCN5r,args=(title,ZgsbN5iSL48t2IhVFnmy,source,lljAD6u8pm13sXYRJgvPQKB5,count==EcjO3giln2kQTdBY0XLAG(u"࠱ය")))
				hoy1COxZzD8.append(xgvnIVrzND9X7H)
				new.append(lljAD6u8pm13sXYRJgvPQKB5)
	def vvM1lTZGpaIdb38cqyiO():
		F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH = VJZIMkUN5siqB21Pf
		for ZgsbN5iSL48t2IhVFnmy in vv8EJLFdUbn5mxM7V13AePfXG:
			if not ZgsbN5iSL48t2IhVFnmy: break
		else: F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH = w2qb6lf5EM
		BL9EG8ulJM5 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player().isPlaying() if Ew2zQ8u7Ss.resolveonly else w2qb6lf5EM
		return F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH or not BL9EG8ulJM5
	UUwxvmgjdH2(hoy1COxZzD8,wOhnQJgVWFLf0RPpZ1oY,Wx10KPISERil97ApBk,P2Fgh6TCOWoaHjkqBcQnvRNXe,vvM1lTZGpaIdb38cqyiO)
	for lljAD6u8pm13sXYRJgvPQKB5 in range(count):
		title = steS3aGdomU[lljAD6u8pm13sXYRJgvPQKB5]
		ZgsbN5iSL48t2IhVFnmy = FhX9OGwaNyAEZ[lljAD6u8pm13sXYRJgvPQKB5].strip(YvOQBzaTAscXR9ql).strip(JACnOz297UuDK5HpPkc1LF(u"ࠪࠪࠬẪ")).strip(rC5tnFDlQcRGA2(u"ࠫࡄ࠭ẫ")).strip(E6xdOMpqISHZCn(u"ࠬ࠵ࠧẬ"))
		ArUaIxjdRyXDECgwtBGhenP = ZgsbN5iSL48t2IhVFnmy.split(zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧậ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X] if lljAD6u8pm13sXYRJgvPQKB5 in new else VJZIMkUN5siqB21Pf
		stream = vv8EJLFdUbn5mxM7V13AePfXG[lljAD6u8pm13sXYRJgvPQKB5]
		if stream and not stream[ZVNvqy4iF1a9X] and stream[VTadWjBloMwXO2CH9GDK6FR]:
			MqKrNmGt0SCihdw6XHlR95UAxEWn = O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡴࡷࡦࡧࡪࡹࡳࠨẮ")
			undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx = stream
			if ArUaIxjdRyXDECgwtBGhenP: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭ắ"),ArUaIxjdRyXDECgwtBGhenP,[undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx],DRmUs7l1O4xLeZYzGITXk)
		elif stream and stream[ZVNvqy4iF1a9X] and not stream[P2Fgh6TCOWoaHjkqBcQnvRNXe] and not stream[VTadWjBloMwXO2CH9GDK6FR]:
			MqKrNmGt0SCihdw6XHlR95UAxEWn = E6xdOMpqISHZCn(u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࠪẰ")
			undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡨࡤ࡭ࡱ࡫ࡤ࡝ࡰࠪằ")+stream[ZVNvqy4iF1a9X],[],[]
			if ArUaIxjdRyXDECgwtBGhenP: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,EcjO3giln2kQTdBY0XLAG(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭Ẳ"),ArUaIxjdRyXDECgwtBGhenP,[undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx],DRmUs7l1O4xLeZYzGITXk)
		elif SYZLFWxJva9PIVEOAR[lljAD6u8pm13sXYRJgvPQKB5]+P2Fgh6TCOWoaHjkqBcQnvRNXe>JivAN3RT7g1PDmU8pS5fCxrl4KXk:
			MqKrNmGt0SCihdw6XHlR95UAxEWn = EcjO3giln2kQTdBY0XLAG(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭ẳ")
			undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx = VVvcQpCU3OM09n(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡹ࡯࡭ࡦࡦࠣࡳࡺࡺࠠࠩࠩẴ")+str(SYZLFWxJva9PIVEOAR[lljAD6u8pm13sXYRJgvPQKB5])+GISOTJh20W(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪẵ"),[],[]
			if ArUaIxjdRyXDECgwtBGhenP: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫẶ"),ArUaIxjdRyXDECgwtBGhenP,[undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx],DRmUs7l1O4xLeZYzGITXk)
		elif not stream:
			MqKrNmGt0SCihdw6XHlR95UAxEWn = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡦࡥࡳࡩࡥ࡭ࠩặ")
			undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx = XB4CjMkPFzhAHiI3q(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡘࡥࡴࡱ࡯ࡺ࡮ࡴࡧࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠪẸ"),[],[]
			if ArUaIxjdRyXDECgwtBGhenP: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡕࡏࡍࡑࡓ࡜ࡔࠧẹ"),ArUaIxjdRyXDECgwtBGhenP,[undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx],DRmUs7l1O4xLeZYzGITXk)
		else:
			MqKrNmGt0SCihdw6XHlR95UAxEWn = Olh7n0zfV4(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭Ẻ")
			undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx = E6xdOMpqISHZCn(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡵࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ẻ"),[],[]
			if ArUaIxjdRyXDECgwtBGhenP: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,s97s2k0LJgl(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡅࡡࡘࡒࡐࡔࡏࡘࡐࠪẼ"),ArUaIxjdRyXDECgwtBGhenP,[undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx],DRmUs7l1O4xLeZYzGITXk)
		SD0TxMRXiep4cjPBsnzI.append([title,ZgsbN5iSL48t2IhVFnmy,undycCUGvE3aiNzF24sHWbX0,II4x930lvTuVqekXBNCrMy,otCOTHujWKp7Dn6dvcafPqlx,MqKrNmGt0SCihdw6XHlR95UAxEWn])
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E)
	return SD0TxMRXiep4cjPBsnzI
def FBTsWkd32lpSVnH6J4G8mLZiCN5r(FFtJQalhPz,url,source,bqfWp3z1MOoYy87AKRxH6k,SSLa4KNzDmEeHd2g3sQjPOv0RMFl):
	global vv8EJLFdUbn5mxM7V13AePfXG,SYZLFWxJva9PIVEOAR
	SYZLFWxJva9PIVEOAR[bqfWp3z1MOoYy87AKRxH6k] = ZVNvqy4iF1a9X
	kc4BtgWCFLJ5yGRVZzuX1eni20 = L8Wkv5KCSoq.time()
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡶࡤࡶࡹ࡫ࡤࠡࠢࠣࡗࡪࡲࡥࡤࡶࡨࡨ࠿࡛ࠦࠡࠩẽ")+FFtJQalhPz+JACnOz297UuDK5HpPkc1LF(u"ࠩࠣࡡࠥࠦࠠࡐࡴ࡬࡫࡮ࡴࡡ࡭࠼ࠣ࡟ࠥ࠭Ế")+url+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࠤࡢ࠭ế"))
	ZgsbN5iSL48t2IhVFnmy,vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ = url,CJlTSEpZsWb0QHg5w
	MMtcEYpWqrhJDQUHXsF = cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡎࡔࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࠨỀ")
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = bQnqUZleYV1(url,source)
	if nmREDwuel7S35JyF2BQ9KzbTv==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪề"):
		vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = Olh7n0zfV4(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫỂ"),[],[]
		SYZLFWxJva9PIVEOAR[bqfWp3z1MOoYy87AKRxH6k] = L8Wkv5KCSoq.time()-kc4BtgWCFLJ5yGRVZzuX1eni20
		return vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k]
	elif CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪể") in nmREDwuel7S35JyF2BQ9KzbTv:
		vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ = rC5tnFDlQcRGA2(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࡑࡩࡪࡪࠠࡆࡺࡷࡩࡷࡴࡡ࡭ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥ࠮࠲࠮࠷ࠬࠫỄ")
		ZgsbN5iSL48t2IhVFnmy = nrv8ZGiAUe0HjMpO17LR2FJ4V(MNXzjK3vV7D)[ZVNvqy4iF1a9X]
		MMtcEYpWqrhJDQUHXsF,vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = N89NAK7O4C(vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,ZgsbN5iSL48t2IhVFnmy,source,bqfWp3z1MOoYy87AKRxH6k)
		if vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ==GISOTJh20W(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧễ"):
			vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
			SYZLFWxJva9PIVEOAR[bqfWp3z1MOoYy87AKRxH6k] = L8Wkv5KCSoq.time()-kc4BtgWCFLJ5yGRVZzuX1eni20
			return vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	elif nmREDwuel7S35JyF2BQ9KzbTv: vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ = yylSaxCLfkte(u"ࠪࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠷࠺ࠡࠢࠪỆ")+nmREDwuel7S35JyF2BQ9KzbTv.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)[:TMfV6892ZoBdyxCH3tGrkwY0K(u"࠹࠲ර")]
	if MNXzjK3vV7D:
		MNXzjK3vV7D = nrv8ZGiAUe0HjMpO17LR2FJ4V(MNXzjK3vV7D)
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࠥࠦࠠࡓࡧࡶࡳࡱࡼࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡧࡧࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧệ")+FFtJQalhPz+E6xdOMpqISHZCn(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩỈ")+MMtcEYpWqrhJDQUHXsF+yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪỉ")+url+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧỊ")+ZgsbN5iSL48t2IhVFnmy+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࠢࡠࠤ࡙ࠥࠦࠠࠡࠢ࡭ࡩ࡫࡯ࡴ࠼ࠣ࡟ࠥ࠭ị")+str(MNXzjK3vV7D)+JACnOz297UuDK5HpPkc1LF(u"ࠩࠣࡡࠬỌ"))
	else:
		zg6x4Tyip7AM = o2FdrDBimMuOw97q6QpNW8S(u"ࠪࠤࠥࠦࡅࡳࡴࡲࡶࡸࡀࠠ࡜ࠢࠪọ")+vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ+EcjO3giln2kQTdBY0XLAG(u"ࠫࠥࡣࠧỎ") if SSLa4KNzDmEeHd2g3sQjPOv0RMFl else CJlTSEpZsWb0QHg5w
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬỏ")+FFtJQalhPz+KA26GucUHOwXL(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪỐ")+url+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࠡ࡟ࠣࠤࠥࡒࡩ࡯࡭࠽ࠤࡠࠦࠧố")+ZgsbN5iSL48t2IhVFnmy+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࠢࡠࠫỒ")+zg6x4Tyip7AM)
	vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ = sWzgdLCjSVwaMuhFkNf1Uop(vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ)
	vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	SYZLFWxJva9PIVEOAR[bqfWp3z1MOoYy87AKRxH6k] = L8Wkv5KCSoq.time()-kc4BtgWCFLJ5yGRVZzuX1eni20
	return vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def Q5A9BT62tEfbGcUsduOP(title,ZgsbN5iSL48t2IhVFnmy,Uz8mMbZifCyvkLnct,MNXzjK3vV7D,source,kcxAmftieK56PE9TqbDHdSrF8=CJlTSEpZsWb0QHg5w):
	if MNXzjK3vV7D:
		if not Uz8mMbZifCyvkLnct[ZVNvqy4iF1a9X]: Uz8mMbZifCyvkLnct = MNXzjK3vV7D
		TT7WzUmOPGJIbheSrXvukiDj30c = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭ồ"))
		E0u8lXO957QBkWtnL2Fyfa6vxmJrjp = VVvcQpCU3OM09n(u"ࠪ࠱ࠬỔ") not in TT7WzUmOPGJIbheSrXvukiDj30c
		while w2qb6lf5EM:
			if E0u8lXO957QBkWtnL2Fyfa6vxmJrjp and len(MNXzjK3vV7D)==P2Fgh6TCOWoaHjkqBcQnvRNXe: CrqTamtPFuU = ZVNvqy4iF1a9X
			else: CrqTamtPFuU = T4TK17YsEfZJ(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠪổ"),Uz8mMbZifCyvkLnct)
			if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: GzWuVjwZgDKa5PCcQTM4 = pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧỖ")
			else:
				j7trxhWEgd8Hz = MNXzjK3vV7D[CrqTamtPFuU]
				JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+KA26GucUHOwXL(u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡹࡧࡲࡵࡧࡧࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬỗ")+title+cbmeD4WNZfAowxT2JdUMtV(u"ࠧࠡ࡟ࠣࠤࠥࡕࡲࡪࡩ࡬ࡲࡦࡲ࠺ࠡ࡝ࠣࠫỘ")+ZgsbN5iSL48t2IhVFnmy+JACnOz297UuDK5HpPkc1LF(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩộ")+str(j7trxhWEgd8Hz)+otNfFapeEnO(u"ࠩࠣࡡࠬỚ"))
				if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥ࠳࠭ớ") in j7trxhWEgd8Hz and otNfFapeEnO(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠫỜ") in j7trxhWEgd8Hz:
					undycCUGvE3aiNzF24sHWbX0,evkarIESVFp3ofA0cld8G,nKGBqEpeizbMmYHuIUWlrovCgLkA = AABHJZP2vkaQj8coq(j7trxhWEgd8Hz)
					if nKGBqEpeizbMmYHuIUWlrovCgLkA: j7trxhWEgd8Hz = nKGBqEpeizbMmYHuIUWlrovCgLkA[ZVNvqy4iF1a9X]
					else: j7trxhWEgd8Hz = CJlTSEpZsWb0QHg5w
				if not j7trxhWEgd8Hz: GzWuVjwZgDKa5PCcQTM4 = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩờ")
				else: GzWuVjwZgDKa5PCcQTM4 = ZQtv0jY9W6L8UHgpnKm(j7trxhWEgd8Hz,source,kcxAmftieK56PE9TqbDHdSrF8)
			if GzWuVjwZgDKa5PCcQTM4 in [cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧỞ"),HaTI5u1f3SCxmMAkw(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨở"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭Ỡ"),EcjO3giln2kQTdBY0XLAG(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫỡ")] or len(MNXzjK3vV7D)==O4F8UC5lMAS6ghETm1VoPDI(u"࠳඼"): break
			elif GzWuVjwZgDKa5PCcQTM4 in [zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪỢ"),E6xdOMpqISHZCn(u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬợ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡺࡲࡪࡧࡧࠫỤ")]: break
			else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬụ"))
	else:
		GzWuVjwZgDKa5PCcQTM4 = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡶࡰࡵࡩࡸࡵ࡬ࡷࡧࡧࠫỦ")
		if XETbMJIf1yetlQSinA2NW5YHvag6D(ZgsbN5iSL48t2IhVFnmy): GzWuVjwZgDKa5PCcQTM4 = ZQtv0jY9W6L8UHgpnKm(ZgsbN5iSL48t2IhVFnmy,source,kcxAmftieK56PE9TqbDHdSrF8)
	return GzWuVjwZgDKa5PCcQTM4,MNXzjK3vV7D
def XLVnhmgFlfE8QI3zrT2viR0d(url,source):
	BBwfuWGxUIrdCoc4ka7,zOREmB0WVndrDcfXJlqH39UTNM4,FFtJQalhPz,Or6FNQdAY0DtuT,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ffY51ieqb2WIwQRHExhZsAopFu = url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	if TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩủ") in url:
		BBwfuWGxUIrdCoc4ka7,zOREmB0WVndrDcfXJlqH39UTNM4 = url.split(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪỨ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)
		zOREmB0WVndrDcfXJlqH39UTNM4 = zOREmB0WVndrDcfXJlqH39UTNM4+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡣࡤ࠭ứ")+EcjO3giln2kQTdBY0XLAG(u"ࠫࡤࡥࠧỪ")+HaTI5u1f3SCxmMAkw(u"ࠬࡥ࡟ࠨừ")+cbmeD4WNZfAowxT2JdUMtV(u"࠭࡟ࡠࠩỬ")+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡠࡡࠪử")
		idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ffY51ieqb2WIwQRHExhZsAopFu,BCMyfgK4GD2hiWlowzHLs5dj = zOREmB0WVndrDcfXJlqH39UTNM4.split(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡡࡢࠫỮ"))[:HaTI5u1f3SCxmMAkw(u"࠹ල")]
	if not egYIsS2qROfpVW83kx: egYIsS2qROfpVW83kx = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࠳ࠫữ")
	else: egYIsS2qROfpVW83kx = egYIsS2qROfpVW83kx.replace(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡴࠬỰ"),CJlTSEpZsWb0QHg5w).replace(YvOQBzaTAscXR9ql,CJlTSEpZsWb0QHg5w)
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.strip(rC5tnFDlQcRGA2(u"ࠫࡄ࠭ự")).strip(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬ࠵ࠧỲ")).strip(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࠦࠨỳ"))
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(BBwfuWGxUIrdCoc4ka7,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡩࡱࡶࡸࠬỴ"))
	if idaKcvOmbRrkW1CtHhZfeAJQV4D: Or6FNQdAY0DtuT = idaKcvOmbRrkW1CtHhZfeAJQV4D
	else: Or6FNQdAY0DtuT = FFtJQalhPz
	Or6FNQdAY0DtuT = fUSgd7IjGYX496Hr25uFMl(Or6FNQdAY0DtuT,XB4CjMkPFzhAHiI3q(u"ࠨࡰࡤࡱࡪ࠭ỵ"))
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"่ࠩฬฬฺัࠨỶ"),CJlTSEpZsWb0QHg5w).replace(HaTI5u1f3SCxmMAkw(u"ࠪื๏ืแาࠩỷ"),CJlTSEpZsWb0QHg5w).replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫฬ๊ࠠࠨỸ"),YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	zOREmB0WVndrDcfXJlqH39UTNM4 = zOREmB0WVndrDcfXJlqH39UTNM4.replace(pz4WBwfyDdgk0m2aRr7SMv(u"๋ࠬศศึิࠫỹ"),CJlTSEpZsWb0QHg5w).replace(XB4CjMkPFzhAHiI3q(u"࠭ำ๋ำไีࠬỺ"),CJlTSEpZsWb0QHg5w).replace(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧศๆࠣࠫỻ"),YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	Or6FNQdAY0DtuT = Or6FNQdAY0DtuT.replace(rC5tnFDlQcRGA2(u"ࠨ็หหูืࠧỼ"),CJlTSEpZsWb0QHg5w).replace(cbmeD4WNZfAowxT2JdUMtV(u"ࠩึ๎ึ็ัࠨỽ"),CJlTSEpZsWb0QHg5w).replace(zQGaM7ctZCN(u"ࠪห้ࠦࠧỾ"),YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	return BBwfuWGxUIrdCoc4ka7,zOREmB0WVndrDcfXJlqH39UTNM4,FFtJQalhPz,Or6FNQdAY0DtuT,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ffY51ieqb2WIwQRHExhZsAopFu
def zNZnKyOkeRaS9tVJv7l3YFd(url,source):
	VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D,DxI7qsWPzOXa4HflAE,uufxcqSzYjrk,BDK2U05Zz8eAcWOR,HROsvP0x3fl9m6iD8LJTCqgeUS,MMtcEYpWqrhJDQUHXsF = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1
	BBwfuWGxUIrdCoc4ka7,zOREmB0WVndrDcfXJlqH39UTNM4,FFtJQalhPz,Or6FNQdAY0DtuT,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ffY51ieqb2WIwQRHExhZsAopFu = XLVnhmgFlfE8QI3zrT2viR0d(url,source)
	if Olh7n0zfV4(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬỿ") in url:
		if   kcxAmftieK56PE9TqbDHdSrF8==Olh7n0zfV4(u"ࠬ࡫࡭ࡣࡧࡧࠫἀ"): kcxAmftieK56PE9TqbDHdSrF8 = YvOQBzaTAscXR9ql+GISOTJh20W(u"࠭ๅโุ็ࠫἁ")
		elif kcxAmftieK56PE9TqbDHdSrF8==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡸࡣࡷࡧ࡭࠭ἂ"): kcxAmftieK56PE9TqbDHdSrF8 = YvOQBzaTAscXR9ql+HaTI5u1f3SCxmMAkw(u"ࠨุ่ࠧฬํฯสࠩἃ")
		elif kcxAmftieK56PE9TqbDHdSrF8==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡥࡳࡹ࡮ࠧἄ"): kcxAmftieK56PE9TqbDHdSrF8 = YvOQBzaTAscXR9ql+TMfV6892ZoBdyxCH3tGrkwY0K(u"๋ࠪࠩࠪิศ้าอࠥ๎สฮ็ํ่ࠬἅ")
		elif kcxAmftieK56PE9TqbDHdSrF8==ZP1LyUCS3pIBu(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ἆ"): kcxAmftieK56PE9TqbDHdSrF8 = YvOQBzaTAscXR9ql+GISOTJh20W(u"ࠬࠫࠥࠦฬะ้๏๊ࠧἇ")
		elif kcxAmftieK56PE9TqbDHdSrF8==CJlTSEpZsWb0QHg5w: kcxAmftieK56PE9TqbDHdSrF8 = YvOQBzaTAscXR9ql+s97s2k0LJgl(u"࠭ࠥࠦࠧࠨࠫἈ")
		if B9dhnlXDQ3wt08O1PI!=CJlTSEpZsWb0QHg5w:
			if otNfFapeEnO(u"ࠧ࡮ࡲ࠷ࠫἉ") not in B9dhnlXDQ3wt08O1PI: B9dhnlXDQ3wt08O1PI = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࠧࠪἊ")+B9dhnlXDQ3wt08O1PI
			B9dhnlXDQ3wt08O1PI = YvOQBzaTAscXR9ql+B9dhnlXDQ3wt08O1PI
		if egYIsS2qROfpVW83kx!=CJlTSEpZsWb0QHg5w:
			egYIsS2qROfpVW83kx = Olh7n0zfV4(u"ࠩࠨࠩࠪࠫࠥࠦࠧࠨࠩࠬἋ")+egYIsS2qROfpVW83kx
			egYIsS2qROfpVW83kx = YvOQBzaTAscXR9ql+egYIsS2qROfpVW83kx[-otNfFapeEnO(u"࠽඾"):]
	if   I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡅࡐࡕࡁࡎࠩἌ")		in source: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡆࡑࡗࡂࡏࠪἍ")		in source and pz4WBwfyDdgk0m2aRr7SMv(u"࡚ࠬࡕࡃࡇࠪἎ") not in source: DxI7qsWPzOXa4HflAE	= I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡡ࡬ࡹࡤࡱࠬἏ")
	elif yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧ࡬ࡣࡷ࡯ࡴࡻࡴࡦࠩἐ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif VVvcQpCU3OM09n(u"ࠨࡲ࡫ࡳࡹࡵࡳ࠯ࡣࡳࡴ࠳࡭ࠧἑ")	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫἒ")		in source: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif mi2ZJXCDzITuyev6gfn(u"ࠪࡥࡱࡧࡲࡢࡤࠪἓ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif o2FdrDBimMuOw97q6QpNW8S(u"ࠫ࡫ࡧࡳࡦ࡮ࠪἔ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡺ࠷࡮ࡧࡨࡰࠬἕ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif otNfFapeEnO(u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭἖")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif JACnOz297UuDK5HpPkc1LF(u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ἗")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif KA26GucUHOwXL(u"ࠨࡨࡤ࡮ࡪࡸࠧἘ")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif yylSaxCLfkte(u"ࠩไะึ࠭Ἑ")			in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= ZP1LyUCS3pIBu(u"ࠪࡪࡦࡰࡥࡳࠩἚ")
	elif XB4CjMkPFzhAHiI3q(u"ࠫๆ๊ำุ์้ࠫἛ")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= cjVhOCwybeRo7UWg92(u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨἜ")
	elif EcjO3giln2kQTdBY0XLAG(u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭Ἕ")		in BBwfuWGxUIrdCoc4ka7:   DxI7qsWPzOXa4HflAE	= TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ἞")
	elif zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ἟")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif rC5tnFDlQcRGA2(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩἠ")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫἡ")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡳ࡫ࡷࡤ࡫ࡰࡥࠬἢ")		in idaKcvOmbRrkW1CtHhZfeAJQV4D:   DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif VVvcQpCU3OM09n(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪἣ")	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡢࡰ࡭ࡵࡥࠬἤ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡵࡸࡩࡹࡳ࠭ἥ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif rC5tnFDlQcRGA2(u"ࠨࡶࡹ࡯ࡸࡧࠧἦ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif EcjO3giln2kQTdBY0XLAG(u"ࠩࡤࡲࡦࡼࡩࡥࡼࠪἧ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif cjVhOCwybeRo7UWg92(u"ࠪࡷ࡭ࡵ࡯ࡧࡲࡵࡳࠬἨ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭Ἡ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif HaTI5u1f3SCxmMAkw(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧἪ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif E6xdOMpqISHZCn(u"࠭ࡣࡪ࡯ࡤ࠸ࡺ࠭Ἣ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡦࡩࡼࡲࡴࡽࠧἬ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif GISOTJh20W(u"ࠨࡪࡤࡰࡦࡩࡩ࡮ࡣࠪἭ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif JACnOz297UuDK5HpPkc1LF(u"ࠩࡦ࡭ࡲࡧࡡࡣࡦࡲࠫἮ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡶࡪࡪ࡭ࡰࡦࡻࠫἯ")	 	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬἰ")
	elif I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡿ࡯ࡶࡶࡸࠫἱ")	 	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= otNfFapeEnO(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧἲ")
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡺ࠴ࡸ࠲ࡧ࡫ࠧἳ")	 	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= rC5tnFDlQcRGA2(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩἴ")
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨἵ")	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= Or6FNQdAY0DtuT
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡨ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴ࡤࠨἶ")	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= s97s2k0LJgl(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࡻ࡯ࡰࠨἷ")
	elif zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬ࡫ࡧࡺ࠰ࡥࡩࡸࡺࠧἸ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠱ࠨἹ")
	elif s97s2k0LJgl(u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨἺ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= yylSaxCLfkte(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠵ࠪἻ")
	elif TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫἼ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬἽ")
	elif TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪἾ")	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫἿ")
	elif VVvcQpCU3OM09n(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩὀ")	in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡪࡰࡩࡰࡦࡳࠧὁ")
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩὂ")		in FFtJQalhPz: DxI7qsWPzOXa4HflAE	= rC5tnFDlQcRGA2(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪὃ")
	elif yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭ὄ")	in FFtJQalhPz: uufxcqSzYjrk	= s97s2k0LJgl(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧὅ")
	elif cjVhOCwybeRo7UWg92(u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭὆")		in FFtJQalhPz: uufxcqSzYjrk	= h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ὇")
	elif o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩὈ")	 	in FFtJQalhPz: uufxcqSzYjrk	= JACnOz297UuDK5HpPkc1LF(u"ࠨࡥࡤࡸࡨ࡮ࠧὉ")
	elif ZP1LyUCS3pIBu(u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪὊ")		in FFtJQalhPz: uufxcqSzYjrk	= O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫὋ")
	elif I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡻ࡯ࡤࡣ࡯ࠪὌ")		in FFtJQalhPz: uufxcqSzYjrk	= zQGaM7ctZCN(u"ࠬࡼࡩࡥࡤࡰࠫὍ")
	elif yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡶࡪࡦ࡫ࡨࠬ὎")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif mi2ZJXCDzITuyev6gfn(u"ࠧ࡮ࡻࡹ࡭ࡩ࠭὏")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif KA26GucUHOwXL(u"ࠨ࡯ࡼࡺ࡮࡯ࡤࠨὐ")		in FFtJQalhPz: HROsvP0x3fl9m6iD8LJTCqgeUS	= Or6FNQdAY0DtuT
	elif yylSaxCLfkte(u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫὑ")		in FFtJQalhPz: uufxcqSzYjrk	= NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬὒ")
	elif rC5tnFDlQcRGA2(u"ࠫ࡬ࡵࡶࡪࡦࠪὓ")		in FFtJQalhPz: uufxcqSzYjrk	= I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ࡭࡯ࡷ࡫ࡧࠫὔ")
	elif zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨὕ") 	in FFtJQalhPz: uufxcqSzYjrk	= JACnOz297UuDK5HpPkc1LF(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩὖ")
	elif CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫὗ")	in FFtJQalhPz: uufxcqSzYjrk	= pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ὘")
	elif E6xdOMpqISHZCn(u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨὙ")	in FFtJQalhPz: uufxcqSzYjrk	= o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ὚")
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩὛ") 	in FFtJQalhPz: uufxcqSzYjrk	= E6xdOMpqISHZCn(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱࠪ὜")
	elif KA26GucUHOwXL(u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨὝ")		in FFtJQalhPz: uufxcqSzYjrk	= yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ὞")
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡸࡴࡵ࠭Ὗ") 			in FFtJQalhPz: uufxcqSzYjrk	= otNfFapeEnO(u"ࠪࡹࡵࡨ࡯࡮ࠩὠ")
	elif s97s2k0LJgl(u"ࠫࡺࡶࡢࠨὡ") 			in FFtJQalhPz: uufxcqSzYjrk	= pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡻࡰࡣࡱࡰࠫὢ")
	elif Olh7n0zfV4(u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭ὣ") 		in FFtJQalhPz: uufxcqSzYjrk	= zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧὤ")
	elif mi2ZJXCDzITuyev6gfn(u"ࠨࡸ࡮ࠫὥ") 			in FFtJQalhPz: uufxcqSzYjrk	= cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡹ࡯ࠬὦ")
	elif KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬὧ") 	in FFtJQalhPz: uufxcqSzYjrk	= O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡻࡩࡳࡵࡴࡨࡥࡲ࠭Ὠ")
	elif o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡼࡩࡥࡤࡲࡦࠬὩ")		in FFtJQalhPz: uufxcqSzYjrk	= GISOTJh20W(u"࠭ࡶࡪࡦࡥࡳࡧ࠭Ὢ")
	elif pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧὫ") 		in FFtJQalhPz: uufxcqSzYjrk	= pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨὬ")
	elif HaTI5u1f3SCxmMAkw(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭Ὥ") 	in FFtJQalhPz: uufxcqSzYjrk	= XB4CjMkPFzhAHiI3q(u"ࠪࡻࡦࡺࡣࡩࡸ࡬ࡨࡪࡵࠧὮ")
	elif s97s2k0LJgl(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨὯ")	in FFtJQalhPz: uufxcqSzYjrk	= E6xdOMpqISHZCn(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩὰ")
	elif VVvcQpCU3OM09n(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪά")	in FFtJQalhPz: uufxcqSzYjrk	= O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡻ࡫ࡳࡴࡾࡹࡨࡢࡴࡨࠫὲ")
	elif otNfFapeEnO(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨέ")		in FFtJQalhPz: uufxcqSzYjrk	= XB4CjMkPFzhAHiI3q(u"ࠩ࡫ࡨ࠲ࡩࡤ࡯ࠩὴ")
	if   DxI7qsWPzOXa4HflAE:	VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D = pz4WBwfyDdgk0m2aRr7SMv(u"ࠪาฬ฻ࠧή"),DxI7qsWPzOXa4HflAE
	elif HROsvP0x3fl9m6iD8LJTCqgeUS:		VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D = mi2ZJXCDzITuyev6gfn(u"๋ࠫࠪอะัࠪὶ"),HROsvP0x3fl9m6iD8LJTCqgeUS
	elif uufxcqSzYjrk:		VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D = yylSaxCLfkte(u"ฺࠬࠫࠥษ่ࠤ๊฿ั้ใࠪί"),uufxcqSzYjrk
	elif BDK2U05Zz8eAcWOR:	VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D = GISOTJh20W(u"࠭ࠥࠦࠧ฼ห๊ࠦฮศำฯ๎ࠬὸ"),BDK2U05Zz8eAcWOR
	elif MMtcEYpWqrhJDQUHXsF:	VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D = zQGaM7ctZCN(u"ࠧࠦࠧࠨࠩ฾อๅࠡะสีั๐ࠧό"),Or6FNQdAY0DtuT
	else:			VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࠧࠨูࠩࠪࠫศ็้ࠣัํ่ๅࠩὺ"),Or6FNQdAY0DtuT
	return VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx
def envYhcju3RgsVG5T6zStX(nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D):
	RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd = [],[]
	for title,ZgsbN5iSL48t2IhVFnmy in list(zip(Uz8mMbZifCyvkLnct,MNXzjK3vV7D)):
		if XETbMJIf1yetlQSinA2NW5YHvag6D(ZgsbN5iSL48t2IhVFnmy):
			RYHIKeQZLBpbNvmhkq2GV1C.append(title)
			Rp1g7OlotseGnf0NFmKk6rLxd.append(ZgsbN5iSL48t2IhVFnmy)
	if not Rp1g7OlotseGnf0NFmKk6rLxd and not nmREDwuel7S35JyF2BQ9KzbTv: nmREDwuel7S35JyF2BQ9KzbTv = VVvcQpCU3OM09n(u"ࠩࡉࡥ࡮ࡲࡥࡥࠩύ")
	return nmREDwuel7S35JyF2BQ9KzbTv,RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd
def bQnqUZleYV1(url,source):
	BBwfuWGxUIrdCoc4ka7,HROsvP0x3fl9m6iD8LJTCqgeUS,FFtJQalhPz,Or6FNQdAY0DtuT,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ffY51ieqb2WIwQRHExhZsAopFu = XLVnhmgFlfE8QI3zrT2viR0d(url,source)
	if   zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡽࡴࡻࡴࡶࠩὼ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧώ"),[CJlTSEpZsWb0QHg5w],[url]
	elif KA26GucUHOwXL(u"ࠬࡿ࠲ࡶ࠰ࡥࡩࠬ὾")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ὿"),[CJlTSEpZsWb0QHg5w],[url]
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡢ࡮ࡥࡥࡵࡲࡡࡺࡧࡵࠫᾀ")	in BBwfuWGxUIrdCoc4ka7  : nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = JgLtrn5bN6U9SvRjozVs(BBwfuWGxUIrdCoc4ka7)
	elif KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡃࡎࡓࡆࡓࠧᾁ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = PMGCT1ry9N(BBwfuWGxUIrdCoc4ka7,idaKcvOmbRrkW1CtHhZfeAJQV4D)
	elif od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡄࡏ࡜ࡇࡍࠨᾂ")		in source and NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡘ࡚ࡈࡅࠨᾃ") not in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = fMhIVs8A5o(BBwfuWGxUIrdCoc4ka7,kcxAmftieK56PE9TqbDHdSrF8,egYIsS2qROfpVW83kx)
	elif TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᾄ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = EsAg37oUWu(BBwfuWGxUIrdCoc4ka7)
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ᾅ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾆ"),[CJlTSEpZsWb0QHg5w],[url]
	elif KA26GucUHOwXL(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧᾇ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = JAZmdeQUG1(BBwfuWGxUIrdCoc4ka7)
	elif yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪᾈ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = ZZBuKcinpY(BBwfuWGxUIrdCoc4ka7)
	elif EcjO3giln2kQTdBY0XLAG(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫᾉ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = LCqVJ8tl0O(BBwfuWGxUIrdCoc4ka7)
	elif JACnOz297UuDK5HpPkc1LF(u"ࠪࡇࡎࡓࡁࡂࡄࡇࡓࠬᾊ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = nD5CrOKphe(BBwfuWGxUIrdCoc4ka7)
	elif I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡘࡎࡏࡇࡊࡄࠫᾋ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = Uw6QLFH1Vs(BBwfuWGxUIrdCoc4ka7,kcxAmftieK56PE9TqbDHdSrF8,HROsvP0x3fl9m6iD8LJTCqgeUS)
	elif mi2ZJXCDzITuyev6gfn(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧᾌ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = wKtk0pBnzE(BBwfuWGxUIrdCoc4ka7,ffY51ieqb2WIwQRHExhZsAopFu)
	elif zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭ᾍ")		in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = oJPQSp7stv(BBwfuWGxUIrdCoc4ka7)
	elif pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫᾎ")	in source: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = Nue7J04rw9(BBwfuWGxUIrdCoc4ka7)
	elif zQGaM7ctZCN(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪᾏ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = BBLdeRq0m6(BBwfuWGxUIrdCoc4ka7)
	elif rC5tnFDlQcRGA2(u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬᾐ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = KRtOEird86(BBwfuWGxUIrdCoc4ka7)
	elif rC5tnFDlQcRGA2(u"ࠪࡥࡱࡧࡲࡢࡤࠪᾑ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = ykiDdI7eHM39gLmKStGvnYBlR(BBwfuWGxUIrdCoc4ka7)
	elif ZP1LyUCS3pIBu(u"ࠫࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭ᾒ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = w8pxZIi0LV(BBwfuWGxUIrdCoc4ka7)
	elif ZP1LyUCS3pIBu(u"ࠬࡹࡨࡢࡪࡨࡨ࠹ࡻࠧᾓ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = w8pxZIi0LV(BBwfuWGxUIrdCoc4ka7)
	elif GISOTJh20W(u"࠭ࡥࡨࡻࡱࡳࡼ࠭ᾔ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = MVNu3jLwfF(BBwfuWGxUIrdCoc4ka7)
	elif rC5tnFDlQcRGA2(u"ࠧࡵࡸࡩࡹࡳ࠭ᾕ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = IPtNXUHTKY(BBwfuWGxUIrdCoc4ka7)
	elif GISOTJh20W(u"ࠨࡶࡹ࡯ࡸࡧࠧᾖ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = IPtNXUHTKY(BBwfuWGxUIrdCoc4ka7)
	elif VVvcQpCU3OM09n(u"ࠩࡷࡺ࠲࡬࠮ࡤࡱࡰࠫᾗ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = IPtNXUHTKY(BBwfuWGxUIrdCoc4ka7)
	elif VVvcQpCU3OM09n(u"ࠪ࡬ࡦࡲࡡࡤ࡫ࡰࡥࠬᾘ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = LLMe7oWdwj(BBwfuWGxUIrdCoc4ka7)
	elif yylSaxCLfkte(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ᾙ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = LLfe8VFlaY(BBwfuWGxUIrdCoc4ka7)
	elif zQGaM7ctZCN(u"ࠬࡳࡹࡦࡩࡼࡺ࡮ࡶࠧᾚ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = K2KUxCJYsp1(BBwfuWGxUIrdCoc4ka7)
	elif XB4CjMkPFzhAHiI3q(u"࠭ࡶࡴ࠶ࡸࠫᾛ")			in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = up1VAmNE29(BBwfuWGxUIrdCoc4ka7)
	elif otNfFapeEnO(u"ࠧࡧࡣ࡭ࡩࡷ࠭ᾜ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = nYOv7ZqUTm(BBwfuWGxUIrdCoc4ka7)
	elif TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩᾝ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = uq56mLpixQ(BBwfuWGxUIrdCoc4ka7)
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡱࡩࡼࡩࡩ࡮ࡣࠪᾞ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = uq56mLpixQ(BBwfuWGxUIrdCoc4ka7)
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡧ࡮ࡳࡡ࠮࡮࡬࡫࡭ࡺࠧᾟ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = yCutDpP26Y(BBwfuWGxUIrdCoc4ka7)
	elif NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡨ࡯࡭ࡢ࡮࡬࡫࡭ࡺࠧᾠ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = yCutDpP26Y(BBwfuWGxUIrdCoc4ka7)
	elif zQGaM7ctZCN(u"ࠬࡳࡹࡤ࡫ࡰࡥࠬᾡ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = PPpYRBirye(BBwfuWGxUIrdCoc4ka7)
	elif ZP1LyUCS3pIBu(u"࠭ࡷࡦࡥ࡬ࡱࡦ࠭ᾢ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = flb3YgHLxsUn0OSP6Dopd(BBwfuWGxUIrdCoc4ka7)
	elif xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡣࡱ࡮ࡶࡦ࠭ᾣ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = rJPGnWcRkF(BBwfuWGxUIrdCoc4ka7)
	elif EcjO3giln2kQTdBY0XLAG(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ᾤ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = UaYmNHehiZ(BBwfuWGxUIrdCoc4ka7)
	elif JACnOz297UuDK5HpPkc1LF(u"ࠩࡤࡶࡧࡲࡩࡰࡰࡽࠫᾥ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = vvY7POWtsG(BBwfuWGxUIrdCoc4ka7)
	elif E6xdOMpqISHZCn(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩᾦ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = ssMROAFa4r(BBwfuWGxUIrdCoc4ka7)
	elif otNfFapeEnO(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩᾧ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	elif O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹ࠭ᾨ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = BgOA7CehMY(BBwfuWGxUIrdCoc4ka7)
	elif HaTI5u1f3SCxmMAkw(u"࠭ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬ࠬᾩ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = R5XdFTfCye(BBwfuWGxUIrdCoc4ka7)
	elif o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡶࡲࡥࡥࡲ࠭ᾪ") 		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	else: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = ZP1LyUCS3pIBu(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᾫ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	if not nmREDwuel7S35JyF2BQ9KzbTv and not MNXzjK3vV7D: nmREDwuel7S35JyF2BQ9KzbTv = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡚ࡴ࡫࡯ࡱࡺࡲࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲ࠢࡉࡥ࡮ࡲࡵࡳࡧࠪᾬ")
	elif nmREDwuel7S35JyF2BQ9KzbTv not in [CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᾭ"),EcjO3giln2kQTdBY0XLAG(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᾮ")]: nmREDwuel7S35JyF2BQ9KzbTv = TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨᾯ")+nmREDwuel7S35JyF2BQ9KzbTv
	return nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def N89NAK7O4C(vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,url,source,bqfWp3z1MOoYy87AKRxH6k):
	global vv8EJLFdUbn5mxM7V13AePfXG,Mk5xlBHF01Vr6,sf8h9NWETdlaQyrM0SwxeXICz,ppbVwZH5eBvodsMNqGU,yye0M5vwOLzKGTQpPx78bikHIr
	cSxDtXmlrGpFuET6NsAJ92vhKZRH = []
	for MMtcEYpWqrhJDQUHXsF in [Mk5xlBHF01Vr6,sf8h9NWETdlaQyrM0SwxeXICz,ppbVwZH5eBvodsMNqGU,yye0M5vwOLzKGTQpPx78bikHIr]: MMtcEYpWqrhJDQUHXsF[bqfWp3z1MOoYy87AKRxH6k] = cjVhOCwybeRo7UWg92(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧᾰ"),[],[]
	bQ5NTWFmRyf0sO83H6SV9PvcMUkw,Gb5Plv6tKCYcXqLAOTIFw8RWHmNyd = [HejhiEQ7RzGZ,WWGtReJbXHp0gN1SQU46o,HY5V4S3stPrFyLIC,unNzkbLxYKl86G27EyAjhdR],[]
	if h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡧࡴࡧࡰࠬᾱ") in url: bQ5NTWFmRyf0sO83H6SV9PvcMUkw,Gb5Plv6tKCYcXqLAOTIFw8RWHmNyd = [HejhiEQ7RzGZ,WWGtReJbXHp0gN1SQU46o,unNzkbLxYKl86G27EyAjhdR],[ppbVwZH5eBvodsMNqGU]
	if O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡻࡲࡹࡹࡻࡢࡦࠩᾲ") in url: bQ5NTWFmRyf0sO83H6SV9PvcMUkw,Gb5Plv6tKCYcXqLAOTIFw8RWHmNyd = [HejhiEQ7RzGZ],[sf8h9NWETdlaQyrM0SwxeXICz,ppbVwZH5eBvodsMNqGU,yye0M5vwOLzKGTQpPx78bikHIr]
	for MMtcEYpWqrhJDQUHXsF in Gb5Plv6tKCYcXqLAOTIFw8RWHmNyd: MMtcEYpWqrhJDQUHXsF[bqfWp3z1MOoYy87AKRxH6k] = mi2ZJXCDzITuyev6gfn(u"ࠩࡖ࡯࡮ࡶࡰࡦࡦࠪᾳ"),[],[]
	for MMtcEYpWqrhJDQUHXsF in bQ5NTWFmRyf0sO83H6SV9PvcMUkw:
		tBTcL5fDdGeiZKOXvj9P1hCJqElxu = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=MMtcEYpWqrhJDQUHXsF,args=(url,source,bqfWp3z1MOoYy87AKRxH6k))
		cSxDtXmlrGpFuET6NsAJ92vhKZRH.append(tBTcL5fDdGeiZKOXvj9P1hCJqElxu)
	def hVcC865In4uSX07zPla23DQ():
		XuJUPx9HEqn5,ZVKXkWyOYeJzfT1QoMCjm0w,rhFMjSUm3AX2dCnv6ZEoOuNJY41,sxoGgQP9OHluTbY1dzVNp = VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf
		mp6YhJRjn1ebqN0TOuZQcFULfa,title,ZgsbN5iSL48t2IhVFnmy = Mk5xlBHF01Vr6[bqfWp3z1MOoYy87AKRxH6k]
		if (ZgsbN5iSL48t2IhVFnmy and not mp6YhJRjn1ebqN0TOuZQcFULfa) or (mp6YhJRjn1ebqN0TOuZQcFULfa and mp6YhJRjn1ebqN0TOuZQcFULfa!=zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠫᾴ")): XuJUPx9HEqn5 = w2qb6lf5EM
		mp6YhJRjn1ebqN0TOuZQcFULfa,title,ZgsbN5iSL48t2IhVFnmy = sf8h9NWETdlaQyrM0SwxeXICz[bqfWp3z1MOoYy87AKRxH6k]
		if (ZgsbN5iSL48t2IhVFnmy and not mp6YhJRjn1ebqN0TOuZQcFULfa) or (mp6YhJRjn1ebqN0TOuZQcFULfa and mp6YhJRjn1ebqN0TOuZQcFULfa!=pz4WBwfyDdgk0m2aRr7SMv(u"࡙ࠫ࡯࡭ࡦࡱࡸࡸࠬ᾵")): ZVKXkWyOYeJzfT1QoMCjm0w = w2qb6lf5EM
		mp6YhJRjn1ebqN0TOuZQcFULfa,title,ZgsbN5iSL48t2IhVFnmy = ppbVwZH5eBvodsMNqGU[bqfWp3z1MOoYy87AKRxH6k]
		if (ZgsbN5iSL48t2IhVFnmy and not mp6YhJRjn1ebqN0TOuZQcFULfa) or (mp6YhJRjn1ebqN0TOuZQcFULfa and mp6YhJRjn1ebqN0TOuZQcFULfa!=NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ᾶ")): rhFMjSUm3AX2dCnv6ZEoOuNJY41 = w2qb6lf5EM
		mp6YhJRjn1ebqN0TOuZQcFULfa,title,ZgsbN5iSL48t2IhVFnmy = yye0M5vwOLzKGTQpPx78bikHIr[bqfWp3z1MOoYy87AKRxH6k]
		if (ZgsbN5iSL48t2IhVFnmy and not mp6YhJRjn1ebqN0TOuZQcFULfa) or (mp6YhJRjn1ebqN0TOuZQcFULfa and mp6YhJRjn1ebqN0TOuZQcFULfa!=pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧᾷ")): sxoGgQP9OHluTbY1dzVNp = w2qb6lf5EM
		F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH = all([XuJUPx9HEqn5,ZVKXkWyOYeJzfT1QoMCjm0w,rhFMjSUm3AX2dCnv6ZEoOuNJY41,sxoGgQP9OHluTbY1dzVNp])
		BL9EG8ulJM5 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player().isPlaying() if Ew2zQ8u7Ss.resolveonly else w2qb6lf5EM
		return F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH or not BL9EG8ulJM5
	UUwxvmgjdH2(cSxDtXmlrGpFuET6NsAJ92vhKZRH,JivAN3RT7g1PDmU8pS5fCxrl4KXk,Wx10KPISERil97ApBk,P2Fgh6TCOWoaHjkqBcQnvRNXe,hVcC865In4uSX07zPla23DQ)
	succeeded = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠷࠭Ᾰ")
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = Mk5xlBHF01Vr6[bqfWp3z1MOoYy87AKRxH6k]
	MNXzjK3vV7D = nrv8ZGiAUe0HjMpO17LR2FJ4V(MNXzjK3vV7D)
	vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	if nmREDwuel7S35JyF2BQ9KzbTv==h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭Ᾱ") or MNXzjK3vV7D: return succeeded,nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ += cbmeD4WNZfAowxT2JdUMtV(u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠲࠻ࠢࠣࠫᾺ")+nmREDwuel7S35JyF2BQ9KzbTv.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)[:E6xdOMpqISHZCn(u"࠽࠶඿")]
	succeeded = rC5tnFDlQcRGA2(u"ࠪࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠴ࠩΆ")
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = sf8h9NWETdlaQyrM0SwxeXICz[bqfWp3z1MOoYy87AKRxH6k]
	MNXzjK3vV7D = nrv8ZGiAUe0HjMpO17LR2FJ4V(MNXzjK3vV7D)
	vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	if nmREDwuel7S35JyF2BQ9KzbTv==TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᾼ") or MNXzjK3vV7D: return succeeded,nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ += xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠶࠾ࠥࠦࠧ᾽")+nmREDwuel7S35JyF2BQ9KzbTv.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)[:yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠾࠰ව")]
	succeeded = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠸ࠬι")
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = ppbVwZH5eBvodsMNqGU[bqfWp3z1MOoYy87AKRxH6k]
	MNXzjK3vV7D = nrv8ZGiAUe0HjMpO17LR2FJ4V(MNXzjK3vV7D)
	vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	if nmREDwuel7S35JyF2BQ9KzbTv==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᾿") or MNXzjK3vV7D: return succeeded,nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ += zQGaM7ctZCN(u"ࠨ࡞ࡱࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࠺࠺ࠡࠢࠪ῀")+nmREDwuel7S35JyF2BQ9KzbTv.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)[:xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠸࠱ශ")]
	succeeded = EcjO3giln2kQTdBY0XLAG(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠵ࠨ῁")
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = yye0M5vwOLzKGTQpPx78bikHIr[bqfWp3z1MOoYy87AKRxH6k]
	MNXzjK3vV7D = nrv8ZGiAUe0HjMpO17LR2FJ4V(MNXzjK3vV7D)
	vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	if nmREDwuel7S35JyF2BQ9KzbTv==O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨῂ") or MNXzjK3vV7D: return succeeded,nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ += xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠷࠽ࠤࠥ࠭ῃ")+nmREDwuel7S35JyF2BQ9KzbTv.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)[:JACnOz297UuDK5HpPkc1LF(u"࠹࠲ෂ")]
	vv8EJLFdUbn5mxM7V13AePfXG[bqfWp3z1MOoYy87AKRxH6k] = vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	return succeeded,vv9wNDYG7LCb5sigkXmt6cOKAQ3uZ,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def HejhiEQ7RzGZ(url,source,bqfWp3z1MOoYy87AKRxH6k):
	BBwfuWGxUIrdCoc4ka7,HROsvP0x3fl9m6iD8LJTCqgeUS,FFtJQalhPz,Or6FNQdAY0DtuT,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ffY51ieqb2WIwQRHExhZsAopFu = XLVnhmgFlfE8QI3zrT2viR0d(url,source)
	MNXzjK3vV7D = []
	if cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪῄ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = UaYmNHehiZ(url)
	elif CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࠬ῅") in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = W3Ee7HPOspI409yAowNn(url)
	elif od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡺࡱࡸࡸࡺ࠭ῆ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = Vc5C4HmhgXPrM(url)
	elif zQGaM7ctZCN(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨῇ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = Vc5C4HmhgXPrM(url)
	elif cjVhOCwybeRo7UWg92(u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨῈ")	in url   : nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = W5WMO4jvzLAFGCR8TJs(url)
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬΈ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = AABHJZP2vkaQj8coq(url)
	elif O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ࡫ࡧࡳࡦ࡮࡫ࡨࠬῊ")		in url   : nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = EsAg37oUWu(url)
	elif od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨΉ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = XwFjnODH5QSq1y6ZeBvCExf(url)
	elif I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧῌ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = TKDvJi4HbdNXBOf(url)
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡣࡷࡽࡾࡻࡸ࡬ࠨ῍")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = UQBcPZrySm8Ihe(url)
	elif GISOTJh20W(u"ࠨࡧ࠸ࡸࡸࡧࡲࠨ῎")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = N6JY7AE3eaj(url)
	elif cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡩࡥࡨࡻ࡬ࡵࡻࡥࡳࡴࡱࡳࠨ῏")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = nA9VQiNPCF86gEHaUdk5zh4(url)
	elif I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪ࡭ࡳ࡬࡬ࡢ࡯࠱ࡧࡨ࠭ῐ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = nA9VQiNPCF86gEHaUdk5zh4(url)
	elif KA26GucUHOwXL(u"ࠫࡺࡶࡢࡢ࡯ࠪῑ") 		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
	elif rC5tnFDlQcRGA2(u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧῒ") 	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = xRLp0iUIMujOqf4avhwnJ6C53E(url)
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭࡭ࡱ࠶ࡸࡴࡱࡵࡡࡥࠩΐ")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = bZu5x2MLmV9WTAKpeGE7gICQBj6y(url)
	elif TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ῔") 	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = y4ERYXTtjHMilOvDW(url)
	elif otNfFapeEnO(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ῕")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = cgQRVawEnx1F63yBIG7W2ie09Np8h(url)
	elif s97s2k0LJgl(u"ࠩࡸࡴࡧ࠭ῖ") 			in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = FDhqiceKgBXkImwVP4MWEof(url)
	elif Olh7n0zfV4(u"ࠪࡹࡵࡶࠧῗ") 			in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = FDhqiceKgBXkImwVP4MWEof(url)
	elif cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡺࡷ࡬ࡰࡣࡧࠫῘ") 		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = nKbx6klaVepNCWqoM3Ii7rQg(url)
	elif TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡼ࡫ࠨῙ")	 		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = UUMB8eTf6v9CsjoHiYVKn71ZOx(BBwfuWGxUIrdCoc4ka7)
	elif ZP1LyUCS3pIBu(u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨῚ") 	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = pFIljnD4car6K85G(url)
	elif mi2ZJXCDzITuyev6gfn(u"ࠧࡷ࡫ࡧࡦࡴࡨࠧΊ")		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = FebNgOaxroT4hCW9tdU6BJnDw02zP(url)
	elif yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ῜") 		in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = xrhp9XcDujCPHOw(url)
	elif O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭῝") 	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = FFsQTkwmzhR(url)
	elif VVvcQpCU3OM09n(u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ῞")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = cxRDzIp0bsvM5mwP214U7OTXAkn9(url)
	elif otNfFapeEnO(u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ῟")	in FFtJQalhPz: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = ttfBqgSJKyj(url)
	else: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[],[]
	global Mk5xlBHF01Vr6
	if not nmREDwuel7S35JyF2BQ9KzbTv and not MNXzjK3vV7D: nmREDwuel7S35JyF2BQ9KzbTv = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶ࠥࡌࡡࡪ࡮ࡸࡶࡪ࠭ῠ")
	elif nmREDwuel7S35JyF2BQ9KzbTv not in [CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫῡ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪῢ")]: nmREDwuel7S35JyF2BQ9KzbTv = O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫΰ")+nmREDwuel7S35JyF2BQ9KzbTv
	Mk5xlBHF01Vr6[bqfWp3z1MOoYy87AKRxH6k] = nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	return
def WWGtReJbXHp0gN1SQU46o(url,source,bqfWp3z1MOoYy87AKRxH6k):
	global sf8h9NWETdlaQyrM0SwxeXICz
	if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪῤ") in url:
		sf8h9NWETdlaQyrM0SwxeXICz[bqfWp3z1MOoYy87AKRxH6k] = pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡙ࠥ࡫ࡪࡲࡳࡩࡩ࠭ῥ"),[],[]
		return
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[],[]
	if XETbMJIf1yetlQSinA2NW5YHvag6D(url):
		nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
	if not MNXzjK3vV7D:
		nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = DfOnlVIXHQKwpMWc9z(url)
	if not MNXzjK3vV7D:
		nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = bpfRrMUNl8Gk1VZKeIoJO(url)
	if not MNXzjK3vV7D:
		if nmREDwuel7S35JyF2BQ9KzbTv==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩῦ"): nmREDwuel7S35JyF2BQ9KzbTv = CJlTSEpZsWb0QHg5w
		nmREDwuel7S35JyF2BQ9KzbTv = VVvcQpCU3OM09n(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨῧ")+nmREDwuel7S35JyF2BQ9KzbTv if nmREDwuel7S35JyF2BQ9KzbTv else XB4CjMkPFzhAHiI3q(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࠦࡆࡢ࡫࡯ࡹࡷ࡫ࠧῨ")
	sf8h9NWETdlaQyrM0SwxeXICz[bqfWp3z1MOoYy87AKRxH6k] = nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	return
def HY5V4S3stPrFyLIC(url,source,bqfWp3z1MOoYy87AKRxH6k):
	uErMFcVGBXUvtJZ90zCTPxn2YW = CJlTSEpZsWb0QHg5w
	SD0TxMRXiep4cjPBsnzI = VJZIMkUN5siqB21Pf
	try:
		import resolveurl as dYgrWG06VNIMuU1LZhylFE7TJkcwst
		SD0TxMRXiep4cjPBsnzI = dYgrWG06VNIMuU1LZhylFE7TJkcwst.resolve(url)
	except Exception as mp6YhJRjn1ebqN0TOuZQcFULfa: uErMFcVGBXUvtJZ90zCTPxn2YW = str(mp6YhJRjn1ebqN0TOuZQcFULfa)
	global ppbVwZH5eBvodsMNqGU
	if not SD0TxMRXiep4cjPBsnzI:
		if uErMFcVGBXUvtJZ90zCTPxn2YW==CJlTSEpZsWb0QHg5w:
			uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
			if uErMFcVGBXUvtJZ90zCTPxn2YW!=ZP1LyUCS3pIBu(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪῩ"): A8v6c2fL7egwWCF3YBqr4kXSRn.stderr.write(uErMFcVGBXUvtJZ90zCTPxn2YW)
		nmREDwuel7S35JyF2BQ9KzbTv = uErMFcVGBXUvtJZ90zCTPxn2YW.splitlines()[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
		ppbVwZH5eBvodsMNqGU[bqfWp3z1MOoYy87AKRxH6k] = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫῪ")+nmREDwuel7S35JyF2BQ9KzbTv,[],[]
		return
	ppbVwZH5eBvodsMNqGU[bqfWp3z1MOoYy87AKRxH6k] = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[SD0TxMRXiep4cjPBsnzI]
	return
def unNzkbLxYKl86G27EyAjhdR(url,source,bqfWp3z1MOoYy87AKRxH6k):
	uErMFcVGBXUvtJZ90zCTPxn2YW = CJlTSEpZsWb0QHg5w
	SD0TxMRXiep4cjPBsnzI = VJZIMkUN5siqB21Pf
	try:
		import yt_dlp as SnbyoE3UvTs5FgKOr1Ct2ZujXRGe
		PQOhkDRvwW7FIYuE2 = SnbyoE3UvTs5FgKOr1Ct2ZujXRGe.YoutubeDL({yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫΎ"): w2qb6lf5EM})
		SD0TxMRXiep4cjPBsnzI = PQOhkDRvwW7FIYuE2.extract_info(url,download=VJZIMkUN5siqB21Pf)
	except Exception as mp6YhJRjn1ebqN0TOuZQcFULfa: uErMFcVGBXUvtJZ90zCTPxn2YW = str(mp6YhJRjn1ebqN0TOuZQcFULfa)
	global yye0M5vwOLzKGTQpPx78bikHIr
	if not SD0TxMRXiep4cjPBsnzI or mi2ZJXCDzITuyev6gfn(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫῬ") not in list(SD0TxMRXiep4cjPBsnzI.keys()):
		if uErMFcVGBXUvtJZ90zCTPxn2YW==CJlTSEpZsWb0QHg5w:
			uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
			if uErMFcVGBXUvtJZ90zCTPxn2YW!=O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ῭"): A8v6c2fL7egwWCF3YBqr4kXSRn.stderr.write(uErMFcVGBXUvtJZ90zCTPxn2YW)
		nmREDwuel7S35JyF2BQ9KzbTv = uErMFcVGBXUvtJZ90zCTPxn2YW.splitlines()[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
		yye0M5vwOLzKGTQpPx78bikHIr[bqfWp3z1MOoYy87AKRxH6k] = cjVhOCwybeRo7UWg92(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ΅")+nmREDwuel7S35JyF2BQ9KzbTv,[],[]
	else:
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
		for ZgsbN5iSL48t2IhVFnmy in SD0TxMRXiep4cjPBsnzI[pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧ`")]:
			Uz8mMbZifCyvkLnct.append(ZgsbN5iSL48t2IhVFnmy[zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡧࡱࡵࡱࡦࡺࠧ῰")])
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy[o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡷࡵࡰࠬ῱")])
		yye0M5vwOLzKGTQpPx78bikHIr[bqfWp3z1MOoYy87AKRxH6k] = CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	return
def DfOnlVIXHQKwpMWc9z(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡊࡉ࡙࠭ῲ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,KA26GucUHOwXL(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡒࡆࡆࡌࡖࡊࡉࡔࡠࡗࡕࡐ࠲࠷ࡳࡵࠩῳ"))
	headers = bqIufCQz2OWExjilm.headers
	if yylSaxCLfkte(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ῴ") in list(headers.keys()):
		ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[EcjO3giln2kQTdBY0XLAG(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ῵")]
		if XETbMJIf1yetlQSinA2NW5YHvag6D(ZgsbN5iSL48t2IhVFnmy): return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return VVvcQpCU3OM09n(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩῶ"),[],[]
def nrv8ZGiAUe0HjMpO17LR2FJ4V(vD98mqtSBzkYpG2F):
	if isinstance(vD98mqtSBzkYpG2F,list):
		Rp1g7OlotseGnf0NFmKk6rLxd = []
		for ZgsbN5iSL48t2IhVFnmy in vD98mqtSBzkYpG2F:
			if isinstance(ZgsbN5iSL48t2IhVFnmy,str): ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			Rp1g7OlotseGnf0NFmKk6rLxd.append(ZgsbN5iSL48t2IhVFnmy)
	else: Rp1g7OlotseGnf0NFmKk6rLxd = vD98mqtSBzkYpG2F.replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
	return Rp1g7OlotseGnf0NFmKk6rLxd
def TPqjAnFQ9dNoh7WpHtrzX56JVBuk(nKGBqEpeizbMmYHuIUWlrovCgLkA,source):
	data = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧ࡭࡫ࡶࡸࠬῷ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩῸ"),nKGBqEpeizbMmYHuIUWlrovCgLkA)
	if data:
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = zip(*data)
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = list(Uz8mMbZifCyvkLnct),list(MNXzjK3vV7D)
		return Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,UDIZkRigha1vL8WeqBmPwXQn = [],[],[]
	for ZgsbN5iSL48t2IhVFnmy in nKGBqEpeizbMmYHuIUWlrovCgLkA:
		if GISOTJh20W(u"ࠩ࠲࠳ࠬΌ") not in ZgsbN5iSL48t2IhVFnmy: continue
		VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx = zNZnKyOkeRaS9tVJv7l3YFd(ZgsbN5iSL48t2IhVFnmy,source)
		egYIsS2qROfpVW83kx = Zy2l0g8QU5vqefaTrsw.findall(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡠࡩ࠱ࠧῺ"),egYIsS2qROfpVW83kx,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if egYIsS2qROfpVW83kx: egYIsS2qROfpVW83kx = int(egYIsS2qROfpVW83kx[ZVNvqy4iF1a9X])
		else: egYIsS2qROfpVW83kx = ZVNvqy4iF1a9X
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,mi2ZJXCDzITuyev6gfn(u"ࠫࡳࡧ࡭ࡦࠩΏ"))
		UDIZkRigha1vL8WeqBmPwXQn.append([VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ZgsbN5iSL48t2IhVFnmy,FFtJQalhPz])
	if UDIZkRigha1vL8WeqBmPwXQn:
		tlQMPyp0DFBugKq = sorted(UDIZkRigha1vL8WeqBmPwXQn,reverse=w2qb6lf5EM,key=lambda key: (key[P3cpaLN2sH],key[ZVNvqy4iF1a9X],key[D9yBM7wPFLz],key[VTadWjBloMwXO2CH9GDK6FR],key[P2Fgh6TCOWoaHjkqBcQnvRNXe],key[pz4WBwfyDdgk0m2aRr7SMv(u"࠷ස")],key[h6sIkJOT5PB2vCxqo4LFag70wA(u"࠹හ")]))
		DIA54R1lwcTz7OZPjX6a,LrpKcvMZUH2O0hQ = [],[]
		for YjATkiozK34fNw1btrEeU8 in tlQMPyp0DFBugKq:
			VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ZgsbN5iSL48t2IhVFnmy,FFtJQalhPz = YjATkiozK34fNw1btrEeU8
			if xWQHt65qRu1rOXon9a0fvzSyGj32D(u"๋ࠬแืๆࠪῼ") in kcxAmftieK56PE9TqbDHdSrF8:
				LrpKcvMZUH2O0hQ.append(YjATkiozK34fNw1btrEeU8)
				continue
			if YjATkiozK34fNw1btrEeU8 not in DIA54R1lwcTz7OZPjX6a: DIA54R1lwcTz7OZPjX6a.append(YjATkiozK34fNw1btrEeU8)
		DIA54R1lwcTz7OZPjX6a = LrpKcvMZUH2O0hQ+DIA54R1lwcTz7OZPjX6a
		ykAihXr9IU82HQqMx7tj5 = ZVNvqy4iF1a9X
		for VyqGHJY3jcbR6tg,idaKcvOmbRrkW1CtHhZfeAJQV4D,kcxAmftieK56PE9TqbDHdSrF8,B9dhnlXDQ3wt08O1PI,egYIsS2qROfpVW83kx,ZgsbN5iSL48t2IhVFnmy,FFtJQalhPz in DIA54R1lwcTz7OZPjX6a:
			egYIsS2qROfpVW83kx = str(egYIsS2qROfpVW83kx) if egYIsS2qROfpVW83kx else CJlTSEpZsWb0QHg5w
			title = cjVhOCwybeRo7UWg92(u"࠭ำ๋ำไีࠬ´")+YvOQBzaTAscXR9ql+kcxAmftieK56PE9TqbDHdSrF8+YvOQBzaTAscXR9ql+VyqGHJY3jcbR6tg+YvOQBzaTAscXR9ql+egYIsS2qROfpVW83kx+YvOQBzaTAscXR9ql+B9dhnlXDQ3wt08O1PI+YvOQBzaTAscXR9ql+idaKcvOmbRrkW1CtHhZfeAJQV4D
			if FFtJQalhPz.lower() not in title.lower(): title = title+YvOQBzaTAscXR9ql+FFtJQalhPz
			title = title.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࠦࠩ῾"),CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
			ykAihXr9IU82HQqMx7tj5 += P2Fgh6TCOWoaHjkqBcQnvRNXe
			title = str(ykAihXr9IU82HQqMx7tj5)+cjVhOCwybeRo7UWg92(u"ࠨ࠰ࠣࠫ῿")+title
			if ZgsbN5iSL48t2IhVFnmy not in MNXzjK3vV7D:
				Uz8mMbZifCyvkLnct.append(title)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		if MNXzjK3vV7D:
			data = list(zip(Uz8mMbZifCyvkLnct,MNXzjK3vV7D))
			if data: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,XB4CjMkPFzhAHiI3q(u"ࠫࡘࡋࡒࡗࡇࡕࡗࠬࠀ"),nKGBqEpeizbMmYHuIUWlrovCgLkA,data,ggZJf7YnlXHT3IjtMaWe6S)
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = list(Uz8mMbZifCyvkLnct),list(MNXzjK3vV7D)
	return Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def JgLtrn5bN6U9SvRjozVs(url):
	nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = CJlTSEpZsWb0QHg5w,[],[]
	if pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࠵ࡤࡰࡹࡱࡰࡴࡧࡤ࠰ࠩࠁ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yylSaxCLfkte(u"࠭ࡇࡆࡖࠪࠂ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡑࡈࡁࡑࡎࡄ࡝ࡊࡘ࠭࠲ࡵࡷࠫࠃ"))
		ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.url
		if ZgsbN5iSL48t2IhVFnmy: nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	elif GISOTJh20W(u"ࠨࡵࡨࡶࡻࡃࠧࠄ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡊࡉ࡙࠭ࠅ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡍࡄࡄࡔࡑࡇ࡙ࡆࡔ࠰࠶ࡳࡪࠧࠆ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠇ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy: url = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		else:
			ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(GISOTJh20W(u"ࠧࡇ࡬ࡣࡣࡓࡰࡦࡿࡥࡳࡅࡲࡲࡹࡸ࡯࡭࡞ࠫࠫ࠭࠴ࠪࡀࠫࠪࠦࠈ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ZgsbN5iSL48t2IhVFnmy:
				url = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
				url = qqth6cAFkaRowLlUeMng.b64decode(url)
				if A7Z6OVh20eCEUx: url = url.decode(Im5KSGZYBpRvdMVsbuXg)
			else: return cjVhOCwybeRo7UWg92(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡏࡆࡆࡖࡌࡂ࡛ࡈࡖࠬࠉ"),[],[]
		nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = EcjO3giln2kQTdBY0XLAG(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࠊ"),[CJlTSEpZsWb0QHg5w],[url]
	return nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ
def w4cFd2lNLr(url,kcxAmftieK56PE9TqbDHdSrF8,HROsvP0x3fl9m6iD8LJTCqgeUS):
	if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡳࡹ࡭ࡩ࠭ࠋ") in url:
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = XZt4A3pGhsHSkK7jWaI(url,kcxAmftieK56PE9TqbDHdSrF8,HROsvP0x3fl9m6iD8LJTCqgeUS)
		if MNXzjK3vV7D: return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
		return ZP1LyUCS3pIBu(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡍࡔࡖࡅࡅࠬࠌ"),[],[]
	return KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࠍ"),[CJlTSEpZsWb0QHg5w],[url]
def ykiDdI7eHM39gLmKStGvnYBlR(url):
	if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࠎ") in url:
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = bUD0vMHIQhKW(T1QDsJlUtCGhn,url)
		if MNXzjK3vV7D: return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
		return s97s2k0LJgl(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࠵ࡘ࠼ࠬࠏ"),[],[]
	return TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠐ"),[CJlTSEpZsWb0QHg5w],[url]
def BBLdeRq0m6(url):
	FhX9OGwaNyAEZ,steS3aGdomU = [],[]
	if mi2ZJXCDzITuyev6gfn(u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪࠑ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡉࡈࡘࠬࠒ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫࠓ"))
		if o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬࠔ") in bqIufCQz2OWExjilm.headers:
			ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[HaTI5u1f3SCxmMAkw(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ࠕ")]
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
			FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,KA26GucUHOwXL(u"ࠬࡴࡡ࡮ࡧࠪࠖ"))
			steS3aGdomU.append(FFtJQalhPz)
	elif otNfFapeEnO(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬࠗ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,zQGaM7ctZCN(u"ࠧࡈࡇࡗࠫ࠘"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪ࠙"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		LhHVms8XJpc = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩࠚ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if LhHVms8XJpc:
			LhHVms8XJpc = LhHVms8XJpc[ZVNvqy4iF1a9X]
			WJOpDChFa9XitZ3NIH80nm6 = S1FGp8IvLshO4Dy6wUZmCY7rN2MXkK(LhHVms8XJpc)
			Jmv5rj3SbqETVd = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠬࠨࠛ"),WJOpDChFa9XitZ3NIH80nm6,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if Jmv5rj3SbqETVd:
				Jmv5rj3SbqETVd = Jmv5rj3SbqETVd[ZVNvqy4iF1a9X]
				Jmv5rj3SbqETVd = oE7iT3HI5VDdmY4kPOjr(VVvcQpCU3OM09n(u"ࠫࡱ࡯ࡳࡵࠩࠜ"),Jmv5rj3SbqETVd)
				for dict in Jmv5rj3SbqETVd:
					ZgsbN5iSL48t2IhVFnmy = dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࡬ࡩ࡭ࡧࠪࠝ")]
					egYIsS2qROfpVW83kx = dict[o2FdrDBimMuOw97q6QpNW8S(u"࠭࡬ࡢࡤࡨࡰࠬࠞ")]
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
					FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࡯ࡣࡰࡩࠬࠟ"))
					steS3aGdomU.append(egYIsS2qROfpVW83kx+YvOQBzaTAscXR9ql+FFtJQalhPz)
		elif cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪࠠ") in bqIufCQz2OWExjilm.headers:
			ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫࠡ")]
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
			FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,E6xdOMpqISHZCn(u"ࠪࡲࡦࡳࡥࠨࠢ"))
			steS3aGdomU.append(FFtJQalhPz)
		if Olh7n0zfV4(u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫࠣ") in url:
			ZgsbN5iSL48t2IhVFnmy = url.split(JACnOz297UuDK5HpPkc1LF(u"ࠬࡅࡵࡳ࡮ࡀࠫࠤ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split(Olh7n0zfV4(u"࠭ࠦࠨࠥ"))[ZVNvqy4iF1a9X]
			if ZgsbN5iSL48t2IhVFnmy:
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
				steS3aGdomU.append(VVvcQpCU3OM09n(u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧࠦ"))
	else:
		FhX9OGwaNyAEZ.append(url)
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,E6xdOMpqISHZCn(u"ࠨࡰࡤࡱࡪ࠭ࠧ"))
		steS3aGdomU.append(FFtJQalhPz)
	if not FhX9OGwaNyAEZ: return O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭ࠨ"),[],[]
	elif len(FhX9OGwaNyAEZ)==P2Fgh6TCOWoaHjkqBcQnvRNXe: ZgsbN5iSL48t2IhVFnmy = FhX9OGwaNyAEZ[ZVNvqy4iF1a9X]
	else:
		CrqTamtPFuU = T4TK17YsEfZJ(mi2ZJXCDzITuyev6gfn(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨࠩ"),steS3aGdomU)
		if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return zQGaM7ctZCN(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࠪ"),[],[]
		ZgsbN5iSL48t2IhVFnmy = FhX9OGwaNyAEZ[CrqTamtPFuU]
	return xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࠫ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def W3Ee7HPOspI409yAowNn(url):
	headers = {GISOTJh20W(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࠬ"):mi2ZJXCDzITuyev6gfn(u"ࠧࡌࡱࡧ࡭࠴࠭࠭")+str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX)}
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(EcjO3giln2kQTdBY0XLAG(u"࠹࠵ළ")):
		L8Wkv5KCSoq.sleep(Wx10KPISERil97ApBk)
		bqIufCQz2OWExjilm = pNaOYIAErvTnHXlwMhmcekij9P(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡉࡈࡘࠬ࠮"),url,CJlTSEpZsWb0QHg5w,headers,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭࠯"))
		if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ࠰") in list(bqIufCQz2OWExjilm.headers.keys()):
			ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭࠱")]
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+KA26GucUHOwXL(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫ࠲")+headers[JACnOz297UuDK5HpPkc1LF(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࠳")]
			return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
		if bqIufCQz2OWExjilm.code!=xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠹࠸࠹ෆ"): break
	return cjVhOCwybeRo7UWg92(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠭࠴"),[],[]
def W5WMO4jvzLAFGCR8TJs(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,Olh7n0zfV4(u"ࠨࡉࡈࡘࠬ࠵"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨ࠶"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧ࠷"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		return CJlTSEpZsWb0QHg5w,[egYIsS2qROfpVW83kx],[ZgsbN5iSL48t2IhVFnmy]
	return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉࠬ࠸"),[],[]
def A3AJdilj7s(url):
	if TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࠵ࡷࡦࡧࡳ࡭ࡸ࠵ࠧ࠹") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,GISOTJh20W(u"࠭ࡇࡆࡖࠪ࠺"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠵࠱࠶ࡹࡴࠨ࠻"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡵࡺࡧ࡬ࡪࡶࡼࡂࠬ࠼"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy: url = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		else: return h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄ࠶ࠬ࠽"),[],[]
	return KA26GucUHOwXL(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࠾"),[CJlTSEpZsWb0QHg5w],[url]
def EsAg37oUWu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡌࡋࡔࠨ࠿"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧࡀ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bGIVq1CQTjmosZg = EEa4ITHuLq82tv7Yx9ZzOQVD(bGIVq1CQTjmosZg)
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡁ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]]
	return Olh7n0zfV4(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡘࡋࡌࡉࡆ࠴ࠫࡂ"),[],[]
def oJPQSp7stv(url):
	if len(url)>Olh7n0zfV4(u"࠸࠰࠱෇"):
		url = url.strip(o2FdrDBimMuOw97q6QpNW8S(u"ࠨ࠱ࠪࡃ"))+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࠲ࠫࡄ")
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡋࡊ࡚ࠧࡅ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡃࡕࡓ࡟ࡇ࠭࠲ࡵࡷࠫࡆ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		if ZVNvqy4iF1a9X and rC5tnFDlQcRGA2(u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡩ࠮ࡸ࠰ࡳ࠲ࡴ࠭ࡧ࠯ࡶ࠮࠭ࡇ") in bGIVq1CQTjmosZg:
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"࠭ࠢ࡭ࡱࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬࡈ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if s67485upzYNMS3PqDelkrdfo:
				D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
				s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(ZP1LyUCS3pIBu(u"ࠧ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࡸࡤࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࠫࡉ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if s67485upzYNMS3PqDelkrdfo:
					D3D6TF50oUBtJlvijPMW8ys = Ce6kWT1z3S(s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X])
		elif len(bGIVq1CQTjmosZg)<s97s2k0LJgl(u"࠴࠱࠲෈"): ZgsbN5iSL48t2IhVFnmy = bGIVq1CQTjmosZg
		else: return yylSaxCLfkte(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡐࡆࡘࡏ࡛ࡃࠪࡊ"),[],[]
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࡋ"),[CJlTSEpZsWb0QHg5w],[url]
def Uw6QLFH1Vs(url,kcxAmftieK56PE9TqbDHdSrF8,HROsvP0x3fl9m6iD8LJTCqgeUS):
	if o2FdrDBimMuOw97q6QpNW8S(u"ࠪ࠳ࡩࡵࡷ࡯࠰ࡳ࡬ࡵ࠭ࡌ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡌࡋࡔࠨࡍ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡓࡋࡎࡁ࠮࠳ࡶࡸࠬࡎ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡶࡪࡦࡨࡳ࠲ࡽࡲࡢࡲࡳࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡏ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		url = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	return s97s2k0LJgl(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪࡐ"),[CJlTSEpZsWb0QHg5w],[url]
def JAZmdeQUG1(url):
	if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡵࡨࡶࡻ࡫ࡲ࠯ࡲ࡫ࡴࠬࡑ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yylSaxCLfkte(u"ࠩࡊࡉ࡙࠭ࡒ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄ࠸࡚࠳࠱ࡴࡶࠪࡓ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(zQGaM7ctZCN(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࡔ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࡮ࡴࡵࡲࠪࡕ") in ZgsbN5iSL48t2IhVFnmy: return VVvcQpCU3OM09n(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࡖ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
		return HaTI5u1f3SCxmMAkw(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡆࡍࡒࡇ࠴ࡖࠩࡗ"),[],[]
	return TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࡘ"),[CJlTSEpZsWb0QHg5w],[url]
def MVNu3jLwfF(url):
	BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = degRiWptawTqXvKNh(url)
	bsGedm1TLP7EgiUQDkCy = {o2FdrDBimMuOw97q6QpNW8S(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬࡙ࠬ"):s97s2k0LJgl(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷ࡚ࠫ"),rC5tnFDlQcRGA2(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧ࡛ࠪ"):JACnOz297UuDK5HpPkc1LF(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ࡜")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡐࡐࡕࡗࠫ࡝"),BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡎࡐ࡙࠰࠵ࡸࡺࠧ࡞"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࡟"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ZgsbN5iSL48t2IhVFnmy: return xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡏࡑ࡚ࠫࡠ"),[],[]
	ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	return TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࡡ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def LLfe8VFlaY(url):
	headers = {E6xdOMpqISHZCn(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧࡢ"):xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭ࡣ")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡇࡆࡖࠪࡤ"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡕࡏࡇࡒࡕࡓ࠲࠷ࡳࡵࠩࡥ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(ZP1LyUCS3pIBu(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࡦ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
	if not ZgsbN5iSL48t2IhVFnmy: return o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡏࡐࡈࡓࡖࡔ࠭ࡧ"),[],[]
	ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࡨ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def LLMe7oWdwj(url):
	BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = degRiWptawTqXvKNh(url)
	bsGedm1TLP7EgiUQDkCy = {XB4CjMkPFzhAHiI3q(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪࡩ"):EcjO3giln2kQTdBY0XLAG(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬࡪ")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡐࡐࡕࡗࠫ࡫"),BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡌࡆࡒࡁࡄࡋࡐࡅ࠲࠷ࡳࡵࠩ࡬"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࠩࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤࡸࡸࡣ࠾࡝ࠥࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧ࠭࡝ࠨࠩࠪ࡭"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
	if not ZgsbN5iSL48t2IhVFnmy: return VVvcQpCU3OM09n(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡍࡇࡌࡂࡅࡌࡑࡆ࠭࡮"),[],[]
	ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	if rC5tnFDlQcRGA2(u"ࠪ࡬ࡹࡺࡰࠨ࡯") not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = otNfFapeEnO(u"ࠫ࡭ࡺࡴࡱ࠼ࠪࡰ")+ZgsbN5iSL48t2IhVFnmy
	return KA26GucUHOwXL(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡱ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def nD5CrOKphe(url):
	otCOTHujWKp7Dn6dvcafPqlx,steS3aGdomU,FhX9OGwaNyAEZ = url,[],[]
	if GISOTJh20W(u"࠭࠯ࡢ࡬ࡤࡼ࠴࠭ࡲ") in url:
		BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = degRiWptawTqXvKNh(url)
		bsGedm1TLP7EgiUQDkCy = {E6xdOMpqISHZCn(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ࡳ"):XB4CjMkPFzhAHiI3q(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨࡴ")}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡓࡓࡘ࡚ࠧࡵ"),BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡅࡇࡊࡏ࠮࠳ࡶࡸࠬࡶ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		cKBL8AkYTtC = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"ࠫࠬ࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃ࡛ࠣࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࠫࡢ࠭ࠧࠨࡷ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if cKBL8AkYTtC: otCOTHujWKp7Dn6dvcafPqlx = cKBL8AkYTtC[ZVNvqy4iF1a9X]
	return yylSaxCLfkte(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨࡸ"),[CJlTSEpZsWb0QHg5w],[otCOTHujWKp7Dn6dvcafPqlx]
def IPtNXUHTKY(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡇࡆࡖࠪࡹ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡘ࡛ࡌࡕࡏ࠯࠴ࡷࡹ࠭ࡺ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	UGV1bzXoyk = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠣࡸࡤࡶࠥ࡬ࡳࡦࡴࡹࠤࡂ࠴ࠪࡀࠩࠫ࠲࠯ࡅࠩࠨࠤࡻ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
	if UGV1bzXoyk:
		UGV1bzXoyk = UGV1bzXoyk[ZVNvqy4iF1a9X][cjVhOCwybeRo7UWg92(u"࠳෉"):]
		UGV1bzXoyk = qqth6cAFkaRowLlUeMng.b64decode(UGV1bzXoyk)
		if A7Z6OVh20eCEUx: UGV1bzXoyk = UGV1bzXoyk.decode(Im5KSGZYBpRvdMVsbuXg)
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࡼ"),UGV1bzXoyk,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: ZgsbN5iSL48t2IhVFnmy = CJlTSEpZsWb0QHg5w
	if not ZgsbN5iSL48t2IhVFnmy: return XB4CjMkPFzhAHiI3q(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡚ࠥࡖࡇࡗࡑࠫࡽ"),[],[]
	ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	if o2FdrDBimMuOw97q6QpNW8S(u"ࠫ࡭ࡺࡴࡱࠩࡾ") not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬ࡮ࡴࡵࡲ࠽ࠫࡿ")+ZgsbN5iSL48t2IhVFnmy
	return I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩࢀ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def K2KUxCJYsp1(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,cjVhOCwybeRo7UWg92(u"ࠧࡈࡇࡗࠫࢁ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡅࡈ࡛࡙ࡍࡕ࠳࠱ࡴࡶࠪࢂ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠴࠶ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࢃ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ZgsbN5iSL48t2IhVFnmy: return cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡆࡉ࡜࡚ࡎࡖࠧࢄ"),[],[]
	ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	return NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧࢅ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def UaYmNHehiZ(url):
	id = url.split(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࠵ࠧࢆ"))[-h6sIkJOT5PB2vCxqo4LFag70wA(u"࠳්")]
	if cjVhOCwybeRo7UWg92(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠭ࢇ") in url: url = url.replace(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ࢈"),CJlTSEpZsWb0QHg5w)
	url = url.replace(HaTI5u1f3SCxmMAkw(u"ࠨ࠰ࡦࡳࡲ࠵ࠧࢉ"),KA26GucUHOwXL(u"ࠩ࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡪࡸ࠯࡮ࡧࡷࡥࡩࡧࡴࡢ࠱ࠪࢊ"))
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,rC5tnFDlQcRGA2(u"ࠪࡋࡊ࡚ࠧࢋ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠷ࡳࡵࠩࢌ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	nmREDwuel7S35JyF2BQ9KzbTv = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬࢍ")
	mp6YhJRjn1ebqN0TOuZQcFULfa = Zy2l0g8QU5vqefaTrsw.findall(HaTI5u1f3SCxmMAkw(u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧࢎ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if mp6YhJRjn1ebqN0TOuZQcFULfa: nmREDwuel7S35JyF2BQ9KzbTv = mp6YhJRjn1ebqN0TOuZQcFULfa[ZVNvqy4iF1a9X]
	url = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ࢏"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not url and nmREDwuel7S35JyF2BQ9KzbTv:
		return nmREDwuel7S35JyF2BQ9KzbTv,[],[]
	ZgsbN5iSL48t2IhVFnmy = url[ZVNvqy4iF1a9X].replace(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡞࡟ࠫ࢐"),CJlTSEpZsWb0QHg5w)
	evkarIESVFp3ofA0cld8G,nKGBqEpeizbMmYHuIUWlrovCgLkA = bUD0vMHIQhKW(T1QDsJlUtCGhn,ZgsbN5iSL48t2IhVFnmy)
	TT7WzUmOPGJIbheSrXvukiDj30c = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(zQGaM7ctZCN(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭࢑"))
	if TT7WzUmOPGJIbheSrXvukiDj30c and KA26GucUHOwXL(u"ࠪ࠱ࠬ࢒") not in TT7WzUmOPGJIbheSrXvukiDj30c: title,ZgsbN5iSL48t2IhVFnmy = evkarIESVFp3ofA0cld8G[ZVNvqy4iF1a9X],nKGBqEpeizbMmYHuIUWlrovCgLkA[ZVNvqy4iF1a9X]
	else:
		BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = Zy2l0g8QU5vqefaTrsw.findall(TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿ࡢࡻࠣ࡫ࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡶࡧࡷ࡫ࡥ࡯ࡰࡤࡱࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࢓"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF: dpM2uig8P5o1bAlFDYwSX0Wcyq,Y6POLrhF4lvKujB,va3Hzst1q8wWe = BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF[ZVNvqy4iF1a9X]
		else: dpM2uig8P5o1bAlFDYwSX0Wcyq,Y6POLrhF4lvKujB,va3Hzst1q8wWe = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		va3Hzst1q8wWe = va3Hzst1q8wWe.replace(zQGaM7ctZCN(u"ࠬࡢ࠯ࠨ࢔"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭࠯ࠨ࢕"))
		Y6POLrhF4lvKujB = pd0Na8D5WZfHYkysVS(Y6POLrhF4lvKujB)
		Uz8mMbZifCyvkLnct = [Dj62UpP5MrbTkJqhRa+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ࢖")+Y6POLrhF4lvKujB+oOQaRxBXyJ5jVnZ]+evkarIESVFp3ofA0cld8G
		MNXzjK3vV7D = [va3Hzst1q8wWe]+nKGBqEpeizbMmYHuIUWlrovCgLkA
		CrqTamtPFuU = T4TK17YsEfZJ(O4F8UC5lMAS6ghETm1VoPDI(u"ࠨษัฮึࠦวๅ็็ๅࠥอไๆ่สือࡀࠠࠩࠩࢗ")+str(len(MNXzjK3vV7D)-TMfV6892ZoBdyxCH3tGrkwY0K(u"࠴෋"))+I7K1Tbk8YSXUhApzqwtLEQMV2(u"้้ࠩࠣ็ࠩࠨ࢘"),Uz8mMbZifCyvkLnct)
		if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return HaTI5u1f3SCxmMAkw(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ࢙"),[],[]
		elif CrqTamtPFuU==ZVNvqy4iF1a9X:
			R5ljfoFUWL7VdInNtzZPB1 = A8v6c2fL7egwWCF3YBqr4kXSRn.argv[ZVNvqy4iF1a9X]+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡄࡺࡹࡱࡧࡀࡪࡴࡲࡤࡦࡴࠩࡱࡴࡪࡥ࠾࠶࠳࠶ࠫࡻࡲ࡭࠿࢚ࠪ")+va3Hzst1q8wWe+yylSaxCLfkte(u"ࠬࠬࡴࡦࡺࡷࡸࡂ࢛࠭")+Y6POLrhF4lvKujB
			pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ࢜")+R5ljfoFUWL7VdInNtzZPB1+VVvcQpCU3OM09n(u"ࠢࠪࠤ࢝"))
			return xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭࢞"),[],[]
		title,ZgsbN5iSL48t2IhVFnmy = Uz8mMbZifCyvkLnct[CrqTamtPFuU],MNXzjK3vV7D[CrqTamtPFuU]
	return CJlTSEpZsWb0QHg5w,[title],[ZgsbN5iSL48t2IhVFnmy]
def rJPGnWcRkF(ZgsbN5iSL48t2IhVFnmy):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,HaTI5u1f3SCxmMAkw(u"ࠩࡊࡉ࡙࠭࢟"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩࢠ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ࠳ࡰࡳࡰࡰࠪࢡ") in ZgsbN5iSL48t2IhVFnmy: url = Zy2l0g8QU5vqefaTrsw.findall(GISOTJh20W(u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬࢢ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: url = Zy2l0g8QU5vqefaTrsw.findall(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࢣ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not url: return cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅࡓࡐࡘࡁࠨࢤ"),[],[]
	url = url[ZVNvqy4iF1a9X]
	if ZP1LyUCS3pIBu(u"ࠨࡪࡷࡸࡵ࠭ࢥ") not in url: url = EcjO3giln2kQTdBY0XLAG(u"ࠩ࡫ࡸࡹࡶ࠺ࠨࢦ")+url
	return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
def AABHJZP2vkaQj8coq(url):
	headers = { JACnOz297UuDK5HpPkc1LF(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࢧ") : CJlTSEpZsWb0QHg5w }
	if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡴࡶ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࡡࡲࡶ࡮࡭ࠧࢨ") in url:
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠵ࡸࡺࠧࢩ"))
		items = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࢪ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[items[ZVNvqy4iF1a9X]]
		else:
			LLyhViKbxMntl5JSk = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡴࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬࢫ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if LLyhViKbxMntl5JSk:
				PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪࢬ"),LLyhViKbxMntl5JSk[ZVNvqy4iF1a9X])
				return cjVhOCwybeRo7UWg92(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪࢭ")+LLyhViKbxMntl5JSk[ZVNvqy4iF1a9X],[],[]
	else:
		TV1Zu8bOAfle5vWSpht2nQ = otNfFapeEnO(u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭ࢮ")
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠵ࡲࡩ࠭ࢯ"))
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"ࠬࡌ࡯ࡳ࡯ࠣࡱࡪࡺࡨࡰࡦࡀࠦࡕࡕࡓࡕࠤࠣࡥࡨࡺࡩࡰࡰࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧࢰ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: return O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪࢱ"),[],[]
		otCOTHujWKp7Dn6dvcafPqlx = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X]
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe]
		if s97s2k0LJgl(u"ࠧ࠯ࡴࡤࡶࠬࢲ") in D3D6TF50oUBtJlvijPMW8ys or HaTI5u1f3SCxmMAkw(u"ࠨ࠰ࡽ࡭ࡵ࠭ࢳ") in D3D6TF50oUBtJlvijPMW8ys: return zQGaM7ctZCN(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡐࡓࡘࡎࡁࡉࡆࡄࠤࡓࡵࡴࠡࡣࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠧࢴ"),[],[]
		items = Zy2l0g8QU5vqefaTrsw.findall(yylSaxCLfkte(u"ࠪࡲࡦࡳࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࢵ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		wSfEHOilLYIK = {}
		for idaKcvOmbRrkW1CtHhZfeAJQV4D,value in items:
			wSfEHOilLYIK[idaKcvOmbRrkW1CtHhZfeAJQV4D] = value
		data = Hc6rjXpgb3CZuVKYk(wSfEHOilLYIK)
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,otCOTHujWKp7Dn6dvcafPqlx,data,headers,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠶ࡶࡩ࠭ࢶ"))
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡗ࡫ࡧࡩࡴ࠴ࠪࡀࡩࡨࡸࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃࡸࡵࡵࡳࡥࡨࡷ࠿࠮࠮ࠫࡁࠬ࡭ࡲࡧࡧࡦ࠼ࠪࢷ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: return KA26GucUHOwXL(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡏࡒࡗࡍࡇࡈࡅࡃࠪࢸ"),[],[]
		download = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X]
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe]
		items = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠧࡧ࡫࡯ࡩ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠮ࠬ࡭ࡣࡥࡩࡱࡀࠢ࠯ࠬࡂࠦࢁ࠯ࠧࢹ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		UQVoHSPr1nuq4LWkyXMsd3tTvp8,Uz8mMbZifCyvkLnct,LL0smM98Y57PVH,MNXzjK3vV7D,cRfndxapZ7EMSroO5tL2 = [],[],[],[],[]
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧࢺ") in ZgsbN5iSL48t2IhVFnmy:
				UQVoHSPr1nuq4LWkyXMsd3tTvp8,LL0smM98Y57PVH = bUD0vMHIQhKW(T1QDsJlUtCGhn,ZgsbN5iSL48t2IhVFnmy)
				MNXzjK3vV7D = MNXzjK3vV7D + LL0smM98Y57PVH
				if UQVoHSPr1nuq4LWkyXMsd3tTvp8[ZVNvqy4iF1a9X]==pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ࠰࠵ࠬࢻ"): Uz8mMbZifCyvkLnct.append(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨࢼ")+yylSaxCLfkte(u"ࠫࡲ࠹ࡵ࠹ࠢࠪࢽ")+TV1Zu8bOAfle5vWSpht2nQ)
				else:
					for title in UQVoHSPr1nuq4LWkyXMsd3tTvp8:
						Uz8mMbZifCyvkLnct.append(yylSaxCLfkte(u"ࠬࠦำ๋ำไีࠥิวึࠢࠪࢾ")+cjVhOCwybeRo7UWg92(u"࠭࡭࠴ࡷ࠻ࠤࠬࢿ")+TV1Zu8bOAfle5vWSpht2nQ+YvOQBzaTAscXR9ql+title)
			else:
				title = title.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠩࣀ"),CJlTSEpZsWb0QHg5w)
				title = title.strip(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࠤࠪࣁ"))
				title = O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨࣂ")+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࠤࡲࡶ࠴ࠡࠩࣃ")+TV1Zu8bOAfle5vWSpht2nQ+YvOQBzaTAscXR9ql+title
				Uz8mMbZifCyvkLnct.append(title)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		ZgsbN5iSL48t2IhVFnmy = rC5tnFDlQcRGA2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴࡯࡯࡮࡬ࡲࡪ࠭ࣄ") + download
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒࡗࡍࡇࡈࡅࡃ࠰࠹ࡹ࡮ࠧࣅ"))
		items = Zy2l0g8QU5vqefaTrsw.findall(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡤࡰࡹࡱࡰࡴࡧࡤࡠࡸ࡬ࡨࡪࡵ࡜ࠩࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠮ࠥࣆ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,BEUVvSQtRimC,hash,kZ2Rg49pOSozh6x7jXdI in items:
			title = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࠡีํีๆืࠠหฯ่๎้ࠦฮศืࠣࠫࣇ")+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࠢࡰࡴ࠹ࠦࠧࣈ")+TV1Zu8bOAfle5vWSpht2nQ+YvOQBzaTAscXR9ql+kZ2Rg49pOSozh6x7jXdI.split(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡻࠫࣉ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			ZgsbN5iSL48t2IhVFnmy = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩ࠴ࡪ࡬ࡀࡱࡳࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࡥ࡯ࡳ࡫ࡪࠪ࡮ࡪ࠽ࠨ࣊")+id+cjVhOCwybeRo7UWg92(u"ࠫࠫࡳ࡯ࡥࡧࡀࠫ࣋")+BEUVvSQtRimC+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࠬࡨࡢࡵ࡫ࡁࠬ࣌")+hash
			cRfndxapZ7EMSroO5tL2.append(kZ2Rg49pOSozh6x7jXdI)
			Uz8mMbZifCyvkLnct.append(title)
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		cRfndxapZ7EMSroO5tL2 = set(cRfndxapZ7EMSroO5tL2)
		ROfjS2Ti0FZA1aUm9Y3yLX,uHo9gMPCQ0mK15aye7SAsiLYZjW = [],[]
		for title in Uz8mMbZifCyvkLnct:
			wwx7Hya1CoYNMP2 = Zy2l0g8QU5vqefaTrsw.findall(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࠠࠩ࡞ࡧ࠮ࡽࢂ࡜ࡥࠬࠬࠪࠫࠨ࣍"),title+zQGaM7ctZCN(u"ࠧࠧࠨࠪ࣎"),Zy2l0g8QU5vqefaTrsw.DOTALL)
			for kZ2Rg49pOSozh6x7jXdI in cRfndxapZ7EMSroO5tL2:
				if wwx7Hya1CoYNMP2[ZVNvqy4iF1a9X] in kZ2Rg49pOSozh6x7jXdI:
					title = title.replace(wwx7Hya1CoYNMP2[ZVNvqy4iF1a9X],kZ2Rg49pOSozh6x7jXdI.split(E6xdOMpqISHZCn(u"ࠨࡺ࣏ࠪ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe])
			ROfjS2Ti0FZA1aUm9Y3yLX.append(title)
		for PMTRpXQvDIkiNszwYGnb32a in range(len(MNXzjK3vV7D)):
			items = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠤࠩࠪ࠭࠴ࠪࡀࠫࠫࡠࡩ࠰ࠩࠧࠨ࣐ࠥ"),JACnOz297UuDK5HpPkc1LF(u"࣑ࠪࠪࠫ࠭")+ROfjS2Ti0FZA1aUm9Y3yLX[PMTRpXQvDIkiNszwYGnb32a]+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࣒ࠫࠫࠬࠧ"),Zy2l0g8QU5vqefaTrsw.DOTALL)
			uHo9gMPCQ0mK15aye7SAsiLYZjW.append( [ROfjS2Ti0FZA1aUm9Y3yLX[PMTRpXQvDIkiNszwYGnb32a],MNXzjK3vV7D[PMTRpXQvDIkiNszwYGnb32a],items[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X],items[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe]] )
		uHo9gMPCQ0mK15aye7SAsiLYZjW = sorted(uHo9gMPCQ0mK15aye7SAsiLYZjW, key=lambda CCdTQs87pLuoFG2ykKXAYU14zgv: CCdTQs87pLuoFG2ykKXAYU14zgv[D9yBM7wPFLz], reverse=w2qb6lf5EM)
		uHo9gMPCQ0mK15aye7SAsiLYZjW = sorted(uHo9gMPCQ0mK15aye7SAsiLYZjW, key=lambda CCdTQs87pLuoFG2ykKXAYU14zgv: CCdTQs87pLuoFG2ykKXAYU14zgv[VTadWjBloMwXO2CH9GDK6FR], reverse=VJZIMkUN5siqB21Pf)
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(uHo9gMPCQ0mK15aye7SAsiLYZjW)):
			Uz8mMbZifCyvkLnct.append(uHo9gMPCQ0mK15aye7SAsiLYZjW[PMTRpXQvDIkiNszwYGnb32a][ZVNvqy4iF1a9X])
			MNXzjK3vV7D.append(uHo9gMPCQ0mK15aye7SAsiLYZjW[PMTRpXQvDIkiNszwYGnb32a][P2Fgh6TCOWoaHjkqBcQnvRNXe])
	if len(MNXzjK3vV7D)==ZVNvqy4iF1a9X: return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂ࣓ࠩ"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def N6JY7AE3eaj(url):
	WyHwgmzU0GnP = url.split(o2FdrDBimMuOw97q6QpNW8S(u"࠭࠿ࠨࣔ"))
	BBwfuWGxUIrdCoc4ka7 = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
	headers = { KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࣕ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࠻ࡔࡔࡃࡕ࠱࠶ࡹࡴࠨࣖ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡓࡰࡪࡧࡳࡦࠢࡺࡥ࡮ࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪࣗ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	url = items[ZVNvqy4iF1a9X]
	return xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࣘ"),[CJlTSEpZsWb0QHg5w],[url]
def UQBcPZrySm8Ihe(url):
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	headers = { XB4CjMkPFzhAHiI3q(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࣙ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡇ࡚ࡒࡔ࡚ࡄࡒࡓࡐ࡙࠭࠲ࡵࡷࠫࣚ"))
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡲࡦࡦ࡬ࡶࡪࡩࡴࡠࡷࡵࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࣛ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]]
	else: return cjVhOCwybeRo7UWg92(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡅ࡙࡟ࡠࡖࡓࡎࠪࣜ"),[],[]
def nA9VQiNPCF86gEHaUdk5zh4(url):
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	headers = { E6xdOMpqISHZCn(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࣝ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,JACnOz297UuDK5HpPkc1LF(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ࠱࠶ࡹࡴࠨࣞ"))
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"ࠪ࡬ࡷ࡫ࡦࠣ࠮ࠥࠬ࡭ࡺࡴ࠯ࠬࡂ࠭ࠧ࠭ࣟ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]]
	else: return I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡅࡘࡐ࡙࡟ࡂࡐࡑࡎࡗࠬ࣠"),[],[]
def nYOv7ZqUTm(url):
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,errno = [],[],CJlTSEpZsWb0QHg5w
	if yylSaxCLfkte(u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࠩ࣡") in url:
		BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = degRiWptawTqXvKNh(url)
		bsGedm1TLP7EgiUQDkCy = {KA26GucUHOwXL(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ࣢"):od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࣣࠧ")}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡒࡒࡗ࡙࠭ࣤ"),BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮࠴ࡱࡨࠬࣥ"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		if Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp.startswith(zQGaM7ctZCN(u"ࠪ࡬ࡹࡺࡰࠨࣦ")): BBwfuWGxUIrdCoc4ka7 = Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp
		else:
			ysw7G3tqjo = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠫࠬ࠭ࡳࡳࡥࡀ࡟ࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡࠧࠣ࡟ࠪࠫࠬࣧ"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ysw7G3tqjo:
				BBwfuWGxUIrdCoc4ka7 = ysw7G3tqjo[ZVNvqy4iF1a9X]
				ysw7G3tqjo = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"ࠬࡹ࡯ࡶࡴࡦࡩࡂ࠮࠮ࠫࡁࠬ࡟ࠫࠪ࡝ࠨࣨ"),BBwfuWGxUIrdCoc4ka7,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if ysw7G3tqjo:
					BBwfuWGxUIrdCoc4ka7 = sWzgdLCjSVwaMuhFkNf1Uop(ysw7G3tqjo[ZVNvqy4iF1a9X])
					return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	elif xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࣩࠧ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yylSaxCLfkte(u"ࠧࡈࡇࡗࠫ࣪"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠲ࡵࡷࠫ࣫"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		if O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ࣬") in list(bqIufCQz2OWExjilm.headers.keys()): BBwfuWGxUIrdCoc4ka7 = bqIufCQz2OWExjilm.headers[pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲ࣭ࠬ")]
		else:
			BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠫ࡮ࡪ࠽ࠣ࡮࡬ࡲࡰࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࣮"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X] if BBwfuWGxUIrdCoc4ka7 else url
	if TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࠵ࡶ࠰࣯ࠩ") in BBwfuWGxUIrdCoc4ka7 or TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭࠯ࡧ࠱ࣰࠪ") in BBwfuWGxUIrdCoc4ka7:
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace(rC5tnFDlQcRGA2(u"ࠧ࠰ࡨ࠲ࣱࠫ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨ࠱ࡤࡴ࡮࠵ࡳࡰࡷࡵࡧࡪ࠵ࣲࠧ"))
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩ࠲ࡺ࠴࠭ࣳ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࠳ࡦࡶࡩ࠰ࡵࡲࡹࡷࡩࡥ࠰ࠩࣴ"))
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡕࡕࡓࡕࠩࣵ"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠸ࡸࡤࠨࣶ"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		items = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩࣷ"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧ࡝࡞ࠪࣸ"),CJlTSEpZsWb0QHg5w)
				Uz8mMbZifCyvkLnct.append(title)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		else:
			items = Zy2l0g8QU5vqefaTrsw.findall(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࣹࠩࠣࠩ"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if items:
				ZgsbN5iSL48t2IhVFnmy = items[ZVNvqy4iF1a9X]
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(s97s2k0LJgl(u"ࠩ࡟ࡠࣺࠬ"),CJlTSEpZsWb0QHg5w)
				Uz8mMbZifCyvkLnct.append(CJlTSEpZsWb0QHg5w)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	else: return zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ࣻ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	if len(MNXzjK3vV7D)==ZVNvqy4iF1a9X: return h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩࣼ"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def up1VAmNE29(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡍࡅࡕࠩࣽ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠴ࡷࡹ࠭ࣾ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,errno = [],[],CJlTSEpZsWb0QHg5w
	if yylSaxCLfkte(u"ࠧࡱ࡮ࡤࡽࡪࡸ࡟ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࠪࣿ") in url or s97s2k0LJgl(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩऀ") in url:
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡳࡰࡦࡿࡥࡳࡡࡨࡱࡧ࡫ࡤ࠯ࡲ࡫ࡴࠬँ") in url:
			BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨं"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]
		else: BBwfuWGxUIrdCoc4ka7 = url
		if XB4CjMkPFzhAHiI3q(u"ࠫࡲࡵࡶࡴ࠶ࡸࠫः") not in BBwfuWGxUIrdCoc4ka7: return pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨऄ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,cjVhOCwybeRo7UWg92(u"࠭ࡇࡆࡖࠪअ"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡑࡔ࡜ࡓ࠵ࡗ࠰࠶ࡳࡪࠧआ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠨ࡫ࡧࡁࠧࡶ࡬ࡢࡻࡨࡶࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࡬ࡶࠫइ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
		items = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪई"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for ZgsbN5iSL48t2IhVFnmy,m9wgSl1oUVRd in items:
				Uz8mMbZifCyvkLnct.append(m9wgSl1oUVRd)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	elif h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡱࡦ࡯࡮ࡠࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࠬउ") in url:
		BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡺࡸ࡬࠾ࠪ࠱࠮ࡄ࠯ࠢࠨऊ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,HaTI5u1f3SCxmMAkw(u"ࠬࡍࡅࡕࠩऋ"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠶ࡶࡩ࠭ऌ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ysw7G3tqjo = Zy2l0g8QU5vqefaTrsw.findall(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩऍ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ysw7G3tqjo = ysw7G3tqjo[ZVNvqy4iF1a9X]
		Uz8mMbZifCyvkLnct.append(CJlTSEpZsWb0QHg5w)
		MNXzjK3vV7D.append(ysw7G3tqjo)
	elif od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡰ࡮ࡴ࡫ࠨऎ") in url:
		BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(zQGaM7ctZCN(u"ࠩ࠿ࡧࡪࡴࡴࡦࡴࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬए"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if BBwfuWGxUIrdCoc4ka7:
			BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]
			return CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ऐ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	if len(MNXzjK3vV7D)==ZVNvqy4iF1a9X: return xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡘࡖ࠸࡚࠭ऑ"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def ZZBuKcinpY(url):
	if KA26GucUHOwXL(u"ࠬࡅࡧࡦࡶࡀࠫऒ") in url:
		ZgsbN5iSL48t2IhVFnmy = url.split(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭࠿ࡨࡧࡷࡁࠬओ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		ZgsbN5iSL48t2IhVFnmy = qqth6cAFkaRowLlUeMng.b64decode(ZgsbN5iSL48t2IhVFnmy)
		if A7Z6OVh20eCEUx: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.decode(Im5KSGZYBpRvdMVsbuXg,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧऔ"))
		return TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫक"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	website = Ew2zQ8u7Ss.SITESURLS[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫख")][ZVNvqy4iF1a9X]
	headers = {TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫग"):website}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡌࡋࡔࠨघ"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡉࡌࡖࡄ࠰࠶ࡳࡪࠧङ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡵࡳ࡮ࠪच"))
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠿࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫछ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠣࡵࡲࡹࡷࡩࡥࡴ࠼ࠣࡠࡠ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨज"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠤࡩ࡭ࡱ࡫࠺ࠨࠪ࠱࠮ࡄ࠯ࠧࠣझ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]+VVvcQpCU3OM09n(u"ࠪࢀࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ञ")+website
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	if yylSaxCLfkte(u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠫट") in bGIVq1CQTjmosZg:
		uGm21FM8TqpDw4ByXQUboCfsL5 = Zy2l0g8QU5vqefaTrsw.findall(rC5tnFDlQcRGA2(u"ࠬࡴࡡ࡮ࡧࡀࠦ࡝ࡺ࡯࡬ࡧࡱࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧठ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if uGm21FM8TqpDw4ByXQUboCfsL5:
			ZgsbN5iSL48t2IhVFnmy = uGm21FM8TqpDw4ByXQUboCfsL5[ZVNvqy4iF1a9X]
			ZgsbN5iSL48t2IhVFnmy = qqth6cAFkaRowLlUeMng.b64decode(ZgsbN5iSL48t2IhVFnmy)
			if A7Z6OVh20eCEUx: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.decode(Im5KSGZYBpRvdMVsbuXg,s97s2k0LJgl(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ड"))
			ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡩࡶࡷࡴ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࠯ࠫढ"),ZgsbN5iSL48t2IhVFnmy,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ZgsbN5iSL48t2IhVFnmy:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]+VVvcQpCU3OM09n(u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫण")+website
				return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬत"),[CJlTSEpZsWb0QHg5w],[url]
def wKtk0pBnzE(url,ffY51ieqb2WIwQRHExhZsAopFu):
	steS3aGdomU,FhX9OGwaNyAEZ = [],[]
	if od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ࠳࠶࠵ࠧथ") in url:
		ZgsbN5iSL48t2IhVFnmy = url.replace(JACnOz297UuDK5HpPkc1LF(u"ࠫ࠴࠷࠯ࠨद"),JACnOz297UuDK5HpPkc1LF(u"ࠬ࠵࠴࠰ࠩध"))
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡇࡆࡖࠪन"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠷ࡳࡵࠩऩ"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨ࠾ࡹ࡭ࡩ࡫࡯ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡷ࡫ࡧࡩࡴࡄࠧप"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
			items = Zy2l0g8QU5vqefaTrsw.findall(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨफ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx in items:
				if ZgsbN5iSL48t2IhVFnmy not in FhX9OGwaNyAEZ:
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
					FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,zQGaM7ctZCN(u"ࠪࡲࡦࡳࡥࠨब"))
					steS3aGdomU.append(FFtJQalhPz+gCc52XVMGfAnOe+egYIsS2qROfpVW83kx)
			return CJlTSEpZsWb0QHg5w,steS3aGdomU,FhX9OGwaNyAEZ
	elif E6xdOMpqISHZCn(u"ࠫ࠴ࡪ࠯ࠨभ") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡍࡅࡕࠩम"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠷ࡴࡤࠨय"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(GISOTJh20W(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨर"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X].replace(EcjO3giln2kQTdBY0XLAG(u"ࠨ࠱࠴࠳ࠬऱ"),KA26GucUHOwXL(u"ࠩ࠲࠸࠴࠭ल"))
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡋࡊ࡚ࠧळ"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠶ࡶࡩ࠭ऴ"))
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
			ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡩ࡬ࡢࡵࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬव"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ZgsbN5iSL48t2IhVFnmy: return TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩश"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]]
	elif GISOTJh20W(u"ࠧ࠰ࡴࡲࡰࡪ࠵ࠧष") in url:
		headers = {cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩस"):ffY51ieqb2WIwQRHExhZsAopFu}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,Olh7n0zfV4(u"ࠩࡊࡉ࡙࠭ह"),url,CJlTSEpZsWb0QHg5w,headers,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠶ࡷ࡬ࠬऺ"))
		ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[mi2ZJXCDzITuyev6gfn(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ऻ")]
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,mi2ZJXCDzITuyev6gfn(u"ࠬࡍࡅࡕ़ࠩ"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠺ࡺࡨࠨऽ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = P9IR4p02DGu3U1MgqiKkHn5(ZgsbN5iSL48t2IhVFnmy,bGIVq1CQTjmosZg)
		return nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ
	elif cbmeD4WNZfAowxT2JdUMtV(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫा") in url:
		BBwfuWGxUIrdCoc4ka7 = url.replace(zQGaM7ctZCN(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬि"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࠲ࡷࡨࡸࡩࡱࡶ࠲ࠫी"))
		bsGedm1TLP7EgiUQDkCy = {otNfFapeEnO(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫु"):ffY51ieqb2WIwQRHExhZsAopFu}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,VVvcQpCU3OM09n(u"ࠫࡌࡋࡔࠨू"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠺ࡹ࡮ࠧृ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧॄ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,VVvcQpCU3OM09n(u"ࠧࡈࡇࡗࠫॅ"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠶࠳࠷ࡵࡪࠪॆ"))
			bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
			if mi2ZJXCDzITuyev6gfn(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫे") in list(bqIufCQz2OWExjilm.headers.keys()):
				ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[zQGaM7ctZCN(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬै")]
				bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡌࡋࡔࠨॉ"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠼ࡹ࡮ࠧॊ"))
				bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
				nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = P9IR4p02DGu3U1MgqiKkHn5(ZgsbN5iSL48t2IhVFnmy,bGIVq1CQTjmosZg)
				if FhX9OGwaNyAEZ: return nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ
			elif XB4CjMkPFzhAHiI3q(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧो") in ZgsbN5iSL48t2IhVFnmy:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(HaTI5u1f3SCxmMAkw(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨौ"),JACnOz297UuDK5HpPkc1LF(u"ࠨ࠱࡭ࡻࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࡀ࡫ࡧࡁ्ࠬ"))
				return NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॎ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	else: return E6xdOMpqISHZCn(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ॏ"),[CJlTSEpZsWb0QHg5w],[url]
	return NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨॐ"),[],[]
def BgOA7CehMY(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡍࡅࡕࠩ॑"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠶ࡹࡴࠨ॒"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	data = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠧࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠰࠭ࡃࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ॓"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if data:
		VVQFv09XOr3JKzayR5dWUB,id,pnw4oGCWjxkAelHmJTEV8Oda6uR = data[ZVNvqy4iF1a9X]
		data = otNfFapeEnO(u"ࠨࡱࡳࡁࠬ॔")+VVQFv09XOr3JKzayR5dWUB+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࠩ࡭ࡩࡃࠧॕ")+id+GISOTJh20W(u"ࠪࠪ࡫ࡴࡡ࡮ࡧࡀࠫॖ")+pnw4oGCWjxkAelHmJTEV8Oda6uR
		headers = {O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪॗ"):yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫक़")}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,mi2ZJXCDzITuyev6gfn(u"࠭ࡐࡐࡕࡗࠫख़"),url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠷࠲࠸࡮ࡥࠩग़"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"ࠨࠤࡵࡩ࡫࡫ࡲࡦࡴࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫज़"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy: return O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬड़"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]]
	return HaTI5u1f3SCxmMAkw(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧढ़"),[],[]
def ssMROAFa4r(url):
	headers = {o2FdrDBimMuOw97q6QpNW8S(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧफ़"):TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭य़")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡇࡆࡖࠪॠ"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠸࠲࠷ࡳࡵࠩॡ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ॢ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X].replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w)
		return TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬॣ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ।"),[],[]
def lb8y2mRT1O(url):
	BBwfuWGxUIrdCoc4ka7 = url.split(zQGaM7ctZCN(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ॥"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X].strip(o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡅࠧ०")).strip(ZP1LyUCS3pIBu(u"࠭࠯ࠨ१")).strip(E6xdOMpqISHZCn(u"ࠧࠧࠩ२"))
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,items,ysw7G3tqjo = [],[],[],CJlTSEpZsWb0QHg5w
	headers = { CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ३"):cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠩ४") }
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,zQGaM7ctZCN(u"ࠪࡋࡊ࡚ࠧ५"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠮࠳ࡶࡸࠬ६"))
	if cjVhOCwybeRo7UWg92(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ७") in list(bqIufCQz2OWExjilm.headers.keys()): ysw7G3tqjo = bqIufCQz2OWExjilm.headers[zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ८")]
	if E6xdOMpqISHZCn(u"ࠧࡩࡶࡷࡴࠬ९") in ysw7G3tqjo:
		if TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩ॰") in url: ysw7G3tqjo = ysw7G3tqjo.replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩ࠲ࡪ࠴࠭ॱ"),s97s2k0LJgl(u"ࠪ࠳ࡻ࠵ࠧॲ"))
		qRkNX7jDMnGWcu = BBwfuWGxUIrdCoc4ka7.split(s97s2k0LJgl(u"ࠫࡄࡖࡈࡑࡕࡌࡈࡂ࠭ॳ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		headers = { xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩॴ"):headers[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪॵ")] , zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡄࡱࡲ࡯࡮࡫ࠧॶ"):HaTI5u1f3SCxmMAkw(u"ࠨࡒࡋࡔࡘࡏࡄ࠾ࠩॷ")+qRkNX7jDMnGWcu }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡊࡉ࡙࠭ॸ"),ysw7G3tqjo,CJlTSEpZsWb0QHg5w,headers,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭ॹ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫ࠴࡬࠯ࠨॺ") in ysw7G3tqjo: items = Zy2l0g8QU5vqefaTrsw.findall(mi2ZJXCDzITuyev6gfn(u"ࠬࡂࡨ࠳ࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫॻ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		elif o2FdrDBimMuOw97q6QpNW8S(u"࠭࠯ࡷ࠱ࠪॼ") in ysw7G3tqjo: items = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"ࠧࡪࡦࡀࠦࡻ࡯ࡤࡦࡱࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫॽ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items: return [],[CJlTSEpZsWb0QHg5w],[ items[ZVNvqy4iF1a9X] ]
		elif yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ࠾࡫࠵ࡃ࠺࠰࠵࠾࠲࡬࠶ࡄࠧॾ") in bGIVq1CQTjmosZg:
			return HaTI5u1f3SCxmMAkw(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢึ๎ึ็ัࠡษ็ๅ๏ี๊้ࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤํ๋ีะำ๊ࠤ๊์ࠠศๆศ๊ฯืๆหࠢส่ำอีสࠢห็ࠬॿ"),[],[]
	else: return KA26GucUHOwXL(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭ঀ"),[],[]
def R5XdFTfCye(ZgsbN5iSL48t2IhVFnmy):
	WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(VVvcQpCU3OM09n(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ঁ"),ZgsbN5iSL48t2IhVFnmy+cjVhOCwybeRo7UWg92(u"ࠬࠬࠦࠨং"),Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
	e2MSyTKUbONAa14zYLXZPCQv,qjiOvuHytNI8Z7brRwcU = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
	url = KA26GucUHOwXL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡵ࡭ࡪࡹ࠴ࡸࡣࡷࡧ࡭࠴࡮ࡦࡶ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡩࡨࡸࡸ࡫ࡲࡷࡧࡵࠪࡤࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠧঃ")+e2MSyTKUbONAa14zYLXZPCQv+ZP1LyUCS3pIBu(u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ঄")+qjiOvuHytNI8Z7brRwcU
	headers = { XB4CjMkPFzhAHiI3q(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬঅ"):CJlTSEpZsWb0QHg5w , HaTI5u1f3SCxmMAkw(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬআ"):ZP1LyUCS3pIBu(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫই") }
	BBwfuWGxUIrdCoc4ka7 = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠳࠱ࡴࡶࠪঈ"))
	return EcjO3giln2kQTdBY0XLAG(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨউ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
def PPpYRBirye(url):
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡵࡳ࡮ࠪঊ"))
	bsGedm1TLP7EgiUQDkCy = {o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨঋ"):FFtJQalhPz,XB4CjMkPFzhAHiI3q(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡇࡱࡧࡴࡪࡩ࡯ࡩࠪঌ"):KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡪࡾ࡮ࡶࠬࠡࡦࡨࡪࡱࡧࡴࡦࠩ঍")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(zz5iuewhAFONn8GQc0DtyKZ317pHo,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡋࡊ࡚ࠧ঎"),url,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎ࡛ࡆࡍࡒࡇ࠭࠲ࡵࡷࠫএ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡶ࡬ࡢࡻࡨࡶ࠳ࡷࡵࡢ࡮࡬ࡸࡾࡹࡥ࡭ࡧࡦࡸࡴࡸࠨ࠯ࠬࡂ࠭࡫ࡵࡲ࡮ࡣࡷࡷ࠿࠭ঐ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	BBwfuWGxUIrdCoc4ka7 = CJlTSEpZsWb0QHg5w
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
		items = Zy2l0g8QU5vqefaTrsw.findall(rC5tnFDlQcRGA2(u"࠭ࡦࡰࡴࡰࡥࡹࡀࠠ࡝ࠩࠫࡠࡩ࠴ࠪࡀࠫ࡟ࠫ࠱ࠦࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ঑"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
		for title,ZgsbN5iSL48t2IhVFnmy in items:
			Uz8mMbZifCyvkLnct.append(title)
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		if len(MNXzjK3vV7D)==P2Fgh6TCOWoaHjkqBcQnvRNXe: BBwfuWGxUIrdCoc4ka7 = MNXzjK3vV7D[ZVNvqy4iF1a9X]
		elif len(MNXzjK3vV7D)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
			CrqTamtPFuU = T4TK17YsEfZJ(pz4WBwfyDdgk0m2aRr7SMv(u"ࠧฤะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬࠬ঒"), Uz8mMbZifCyvkLnct)
			if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡇ࡛ࡍ࡙ࡥࡁࡍࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ও"),[],[]
			BBwfuWGxUIrdCoc4ka7 = MNXzjK3vV7D[CrqTamtPFuU]
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঔ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: BBwfuWGxUIrdCoc4ka7 = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
	if not BBwfuWGxUIrdCoc4ka7: return h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓ࡙ࡄࡋࡐࡅࠬক"),[],[]
	return NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧখ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
def flb3YgHLxsUn0OSP6Dopd(url):
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,XB4CjMkPFzhAHiI3q(u"ࠬࡻࡲ࡭ࠩগ"))
	bsGedm1TLP7EgiUQDkCy = {h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧঘ"):FFtJQalhPz,XB4CjMkPFzhAHiI3q(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩঙ"):yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨচ")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(zz5iuewhAFONn8GQc0DtyKZ317pHo,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡊࡉ࡙࠭ছ"),url,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡗࡆࡅࡌࡑࡆ࠳࠱ࡴࡶࠪজ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬঝ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	BBwfuWGxUIrdCoc4ka7 = CJlTSEpZsWb0QHg5w
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
		items = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫঞ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
		for title,ZgsbN5iSL48t2IhVFnmy in items:
			Uz8mMbZifCyvkLnct.append(title)
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		if len(MNXzjK3vV7D)==P2Fgh6TCOWoaHjkqBcQnvRNXe: BBwfuWGxUIrdCoc4ka7 = MNXzjK3vV7D[ZVNvqy4iF1a9X]
		elif len(MNXzjK3vV7D)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
			CrqTamtPFuU = T4TK17YsEfZJ(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫট"),Uz8mMbZifCyvkLnct)
			if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return ZP1LyUCS3pIBu(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬঠ"),[],[]
			BBwfuWGxUIrdCoc4ka7 = MNXzjK3vV7D[CrqTamtPFuU]
	if not BBwfuWGxUIrdCoc4ka7:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ড"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo: BBwfuWGxUIrdCoc4ka7 = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
	if not BBwfuWGxUIrdCoc4ka7: return yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄࠫঢ"),[],[]
	return yylSaxCLfkte(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ণ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
def KRtOEird86(ZgsbN5iSL48t2IhVFnmy):
	WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪত"),ZgsbN5iSL48t2IhVFnmy+JACnOz297UuDK5HpPkc1LF(u"ࠬࠬࠦࠨথ"),Zy2l0g8QU5vqefaTrsw.DOTALL)
	url,e2MSyTKUbONAa14zYLXZPCQv,qjiOvuHytNI8Z7brRwcU = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
	data = {HaTI5u1f3SCxmMAkw(u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧদ"):e2MSyTKUbONAa14zYLXZPCQv,pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡴࡧࡵࡺࡪࡸࠧধ"):qjiOvuHytNI8Z7brRwcU}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,XB4CjMkPFzhAHiI3q(u"ࠨࡒࡒࡗ࡙࠭ন"),url,data,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐࡇࡆࡓ࠭࠲ࡵࡷࠫ঩"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨপ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[ZVNvqy4iF1a9X]
	return o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧফ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
def Nue7J04rw9(url):
	ZgsbN5iSL48t2IhVFnmy = url
	if Olh7n0zfV4(u"ࠬࡅࡳࡦࡴࡹࡁࠬব") in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,HaTI5u1f3SCxmMAkw(u"࠭ࡇࡆࡖࠪভ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙࠭࠲ࡵࡷࠫম"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩয"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		else: return o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨর"),[],[]
	return E6xdOMpqISHZCn(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭঱"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def yCutDpP26Y(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡌࡋࡔࠨল"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱࠶ࡹࡴࠨ঳"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ঴"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		if ZgsbN5iSL48t2IhVFnmy: return O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ঵"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return rC5tnFDlQcRGA2(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭শ"),[],[]
def xxDu24R6Zl(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡊࡉ࡙࠭ষ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬস"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪহ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[ZVNvqy4iF1a9X]
	return I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ঺"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def uq56mLpixQ(url):
	R9RzvLZDnPb = fUSgd7IjGYX496Hr25uFMl(url,KA26GucUHOwXL(u"࠭ࡵࡳ࡮ࠪ঻"))
	if o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡪࡰࡧࡩࡽࡃ়ࠧ") in url:
		headers = {s97s2k0LJgl(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩঽ"):R9RzvLZDnPb}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡊࡉ࡙࠭া"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫি"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩী"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if BBwfuWGxUIrdCoc4ka7:
			BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]
			if cjVhOCwybeRo7UWg92(u"ࠬ࡮ࡴࡵࡲࠪু") not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = VVvcQpCU3OM09n(u"࠭ࡨࡵࡶࡳ࠾ࠬূ")+BBwfuWGxUIrdCoc4ka7
			if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨৃ") in BBwfuWGxUIrdCoc4ka7:
				bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,ZP1LyUCS3pIBu(u"ࠨࡉࡈࡘࠬৄ"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ৅"))
				Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
				items = Zy2l0g8QU5vqefaTrsw.findall(GISOTJh20W(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৆"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if not items:
					s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠫࠧ࡬ࡩ࡭ࡧࠥ࠾ࠥࡢ࡛ࠩ࠰࠭ࡃ࠮ࡢ࡝࡝࠰ࠪে"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if s67485upzYNMS3PqDelkrdfo:
						zE8URkuN932 = s67485upzYNMS3PqDelkrdfo[E6xdOMpqISHZCn(u"࠴෌")]
						items = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"ࠬࠨ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠣࠩৈ"),zE8URkuN932,Zy2l0g8QU5vqefaTrsw.DOTALL)
						if items:
							ssKVBGkDTgr0enlmjChuSoLzQMOva,h5h2zsDYFxieIUpOcf8A1vw = zip(*items)
							items = list(zip(h5h2zsDYFxieIUpOcf8A1vw,ssKVBGkDTgr0enlmjChuSoLzQMOva))
				Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
				cJXaNYSwQ0BP9bUgM = fUSgd7IjGYX496Hr25uFMl(BBwfuWGxUIrdCoc4ka7,zQGaM7ctZCN(u"࠭ࡵࡳ࡮ࠪ৉"))
				for ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx in reversed(items):
					ZgsbN5iSL48t2IhVFnmy = cJXaNYSwQ0BP9bUgM+ZgsbN5iSL48t2IhVFnmy+otNfFapeEnO(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ৊")+cJXaNYSwQ0BP9bUgM
					Uz8mMbZifCyvkLnct.append(egYIsS2qROfpVW83kx)
					MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
				return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
			else: return od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫো"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	BBwfuWGxUIrdCoc4ka7 = url+Olh7n0zfV4(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬৌ")+R9RzvLZDnPb
	if yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪ࡬ࡹࡺࡰࠨ্") not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫ࡭ࡺࡴࡱ࠼ࠪৎ")+BBwfuWGxUIrdCoc4ka7
	return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
def llAzqXOrDF(ZgsbN5iSL48t2IhVFnmy):
	R9RzvLZDnPb = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡻࡲ࡭ࠩ৏"))
	if yylSaxCLfkte(u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭৐") in ZgsbN5iSL48t2IhVFnmy:
		WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭৑"),ZgsbN5iSL48t2IhVFnmy+yylSaxCLfkte(u"ࠨࠨࠩࠫ৒"),Zy2l0g8QU5vqefaTrsw.DOTALL)
		url,e2MSyTKUbONAa14zYLXZPCQv,qjiOvuHytNI8Z7brRwcU = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
		data = {TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࡬ࡨࠬ৓"):e2MSyTKUbONAa14zYLXZPCQv,rC5tnFDlQcRGA2(u"ࠪࡷࡪࡸࡶࡦࡴࠪ৔"):qjiOvuHytNI8Z7brRwcU}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡕࡕࡓࡕࠩ৕"),url,data,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭৖"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫৗ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[ZVNvqy4iF1a9X]
		if cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ৘") in BBwfuWGxUIrdCoc4ka7:
			headers = {od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ৙"):R9RzvLZDnPb,O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭৚"):CJlTSEpZsWb0QHg5w}
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,JACnOz297UuDK5HpPkc1LF(u"ࠪࡋࡊ࡚ࠧ৛"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬড়"))
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
			items = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫঢ়"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
			cJXaNYSwQ0BP9bUgM = fUSgd7IjGYX496Hr25uFMl(BBwfuWGxUIrdCoc4ka7,XB4CjMkPFzhAHiI3q(u"࠭ࡵࡳ࡮ࠪ৞"))
			for ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx in reversed(items):
				ZgsbN5iSL48t2IhVFnmy = cJXaNYSwQ0BP9bUgM+ZgsbN5iSL48t2IhVFnmy+pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪয়")+cJXaNYSwQ0BP9bUgM
				Uz8mMbZifCyvkLnct.append(egYIsS2qROfpVW83kx)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
		else: return h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫৠ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	else:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+rC5tnFDlQcRGA2(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬৡ")+R9RzvLZDnPb
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
def vvY7POWtsG(ZgsbN5iSL48t2IhVFnmy):
	if O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡴࡴࡹࡴࡪࡦࠪৢ") in ZgsbN5iSL48t2IhVFnmy:
		WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ৣ"),ZgsbN5iSL48t2IhVFnmy+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࠬࠦࠨ৤"),Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		e2MSyTKUbONAa14zYLXZPCQv,qjiOvuHytNI8Z7brRwcU = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
		f862mMDqdy = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,HaTI5u1f3SCxmMAkw(u"࠭ࡵࡳ࡮ࠪ৥"))
		url = f862mMDqdy+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ০")+e2MSyTKUbONAa14zYLXZPCQv+Olh7n0zfV4(u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ১")+qjiOvuHytNI8Z7brRwcU
		headers = { zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭২"):CJlTSEpZsWb0QHg5w , HaTI5u1f3SCxmMAkw(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭৩"):yylSaxCLfkte(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ৪") }
		BBwfuWGxUIrdCoc4ka7 = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧ৫"))
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w)
		return KA26GucUHOwXL(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ৬"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	elif yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫ৭") in ZgsbN5iSL48t2IhVFnmy:
		CGktIKBqh4iY5TOwLJuRHMUNaXn = ZVNvqy4iF1a9X
		while s97s2k0LJgl(u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ৮") in ZgsbN5iSL48t2IhVFnmy and CGktIKBqh4iY5TOwLJuRHMUNaXn<ZP1LyUCS3pIBu(u"࠺෍"):
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,KA26GucUHOwXL(u"ࠩࡊࡉ࡙࠭৯"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬৰ"))
			if cjVhOCwybeRo7UWg92(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ৱ") in list(bqIufCQz2OWExjilm.headers.keys()): ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ৲")]
			CGktIKBqh4iY5TOwLJuRHMUNaXn += P2Fgh6TCOWoaHjkqBcQnvRNXe
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	else: return h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪ৳"),[],[]
def LCqVJ8tl0O(url):
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,otNfFapeEnO(u"ࠧࡶࡴ࡯ࠫ৴"))
	headers = {rC5tnFDlQcRGA2(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ৵"):FFtJQalhPz,yylSaxCLfkte(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭৶"):jQW9RpucaCLHX0sSBD6lrif58e47nt()}
	if yylSaxCLfkte(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ৷") in url:
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭৸"))
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ৹"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X].replace(s97s2k0LJgl(u"࠭ࡨࡵࡶࡳࡷࠬ৺"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡩࡶࡷࡴࠬ৻"))
			return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	else:
		NnbBrAtH0sV4FhPg3QzW89JxZL7U = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡉࡈࡘࠬৼ"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧࠫ৽"))
		bGIVq1CQTjmosZg = NnbBrAtH0sV4FhPg3QzW89JxZL7U.content
		bsGedm1TLP7EgiUQDkCy = headers.copy()
		if otNfFapeEnO(u"ࠪࡣࡱࡴ࡫ࡠࠩ৾") in str(NnbBrAtH0sV4FhPg3QzW89JxZL7U.cookies):
			cookies = NnbBrAtH0sV4FhPg3QzW89JxZL7U.cookies
			bsGedm1TLP7EgiUQDkCy[KA26GucUHOwXL(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ৿")] = sWzgdLCjSVwaMuhFkNf1Uop(Hc6rjXpgb3CZuVKYk(cookies))
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ਀"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not ZgsbN5iSL48t2IhVFnmy: return zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩਁ"),[CJlTSEpZsWb0QHg5w],[url]
		else:
			ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X])+s97s2k0LJgl(u"ࠧࠧࡦࡀ࠵ࠬਂ")
			Ig8Y6D1bZtzURv = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡉࡈࡘࠬਃ"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫ਄"))
			bGIVq1CQTjmosZg = Ig8Y6D1bZtzURv.content
			ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਅ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ZgsbN5iSL48t2IhVFnmy:
				ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X])
				if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡲࡶ࠴ࠨਆ") in ZgsbN5iSL48t2IhVFnmy and GISOTJh20W(u"ࠬ࠵ࡤ࠰ࠩਇ") in ZgsbN5iSL48t2IhVFnmy: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
				else: return KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩਈ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫਉ"),[],[]
def w8pxZIi0LV(ZgsbN5iSL48t2IhVFnmy):
	if E6xdOMpqISHZCn(u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬਊ") in ZgsbN5iSL48t2IhVFnmy:
		headers = {KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬ਋"):O4F8UC5lMAS6ghETm1VoPDI(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫ਌")}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡌࡋࡔࠨ਍"),ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧ਎"))
		url = bqIufCQz2OWExjilm.content
		if url: return HaTI5u1f3SCxmMAkw(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩਏ"),[CJlTSEpZsWb0QHg5w],[url]
	else:
		WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨਐ"),ZgsbN5iSL48t2IhVFnmy,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if not WyHwgmzU0GnP: WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫ਑"),ZgsbN5iSL48t2IhVFnmy,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		e2MSyTKUbONAa14zYLXZPCQv,qjiOvuHytNI8Z7brRwcU = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,VVvcQpCU3OM09n(u"ࠩࡸࡶࡱ࠭਒"))
		url = FFtJQalhPz+E6xdOMpqISHZCn(u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫਓ")
		data = {VVvcQpCU3OM09n(u"ࠫ࡮ࡪࠧਔ"):e2MSyTKUbONAa14zYLXZPCQv,JACnOz297UuDK5HpPkc1LF(u"ࠬ࡯ࠧਕ"):qjiOvuHytNI8Z7brRwcU}
		headers = {JACnOz297UuDK5HpPkc1LF(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩਖ"):KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨਗ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩਘ"):ZgsbN5iSL48t2IhVFnmy}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡓࡓࡘ࡚ࠧਙ"),url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬਚ"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਛ"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if BBwfuWGxUIrdCoc4ka7:
			BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X]
			return yylSaxCLfkte(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨਜ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	return E6xdOMpqISHZCn(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪਝ"),[],[]
def r1dow4CIZhlBTf(X6XZ5HbYeorC8s3nilWQ):
	EglLbxK8dH1RpDeu27zmqIify4TX = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(EcjO3giln2kQTdBY0XLAG(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨਞ"))
	headers = {TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨਟ"):EglLbxK8dH1RpDeu27zmqIify4TX} if EglLbxK8dH1RpDeu27zmqIify4TX else CJlTSEpZsWb0QHg5w
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,EcjO3giln2kQTdBY0XLAG(u"ࠩࡊࡉ࡙࠭ਠ"),X6XZ5HbYeorC8s3nilWQ,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪਡ"))
	Y9wypG3KfSgl8C2DzaPVWHm = bqIufCQz2OWExjilm.content
	MtgaDxuAJGkcIZ4Sph = str(bqIufCQz2OWExjilm.headers)
	FE2J41QiCSvDYPyAO8uWZ75k = MtgaDxuAJGkcIZ4Sph+Y9wypG3KfSgl8C2DzaPVWHm
	if cbmeD4WNZfAowxT2JdUMtV(u"ࠫ࠳ࡳࡰ࠵ࠩਢ") in FE2J41QiCSvDYPyAO8uWZ75k: jXqW0t7CZSn2dshG8E1HrlUu = w2qb6lf5EM
	else:
		fZDCO0XbaLSs7N8vTcQqmr6,eOVb64kRWwArpNmu5CLXtzfDF,HHPABWmLJFpRC,mHxu8WR0ec7BG9VIhTNyO3Fk,jXqW0t7CZSn2dshG8E1HrlUu = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf
		captcha = Zy2l0g8QU5vqefaTrsw.findall(cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡶࡡࡨࡧ࠰ࡶࡪࡪࡩࡳࡧࡦࡸ࠳࠰࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵ࡬ࡸࡪࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਣ"),Y9wypG3KfSgl8C2DzaPVWHm,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if captcha: HHPABWmLJFpRC,mHxu8WR0ec7BG9VIhTNyO3Fk = captcha[ZVNvqy4iF1a9X]
		tCIhoNqu0S = Ew2zQ8u7Ss.SITESURLS[cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ਤ")][KA26GucUHOwXL(u"࠽෎")]
		if ZVNvqy4iF1a9X:
			data = {NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡶࡵࡨࡶࠬਥ"):Ew2zQ8u7Ss.AV_CLIENT_IDS,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩਦ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡸࡶࡱ࠭ਧ"):X6XZ5HbYeorC8s3nilWQ,Olh7n0zfV4(u"ࠪ࡯ࡪࡿࠧਨ"):mHxu8WR0ec7BG9VIhTNyO3Fk,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࡮ࡪࠧ਩"):CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡰ࡯ࡣࠩਪ"):KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧਫ")}
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,otNfFapeEnO(u"ࠧࡑࡑࡖࡘࠬਬ"),tCIhoNqu0S,data,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠷ࡴࡤࠨਭ"))
			bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		bGIVq1CQTjmosZg = CJlTSEpZsWb0QHg5w
		if bGIVq1CQTjmosZg.startswith(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡘࡖࡑ࡙࠽ࠨਮ")):
			vD98mqtSBzkYpG2F = oE7iT3HI5VDdmY4kPOjr(VVvcQpCU3OM09n(u"ࠪࡰ࡮ࡹࡴࠨਯ"),bGIVq1CQTjmosZg.split(h6sIkJOT5PB2vCxqo4LFag70wA(u"࡚ࠫࡘࡌࡔ࠿ࠪਰ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe])
			for RjVAI6uzxFofm7qv in vD98mqtSBzkYpG2F:
				url = RjVAI6uzxFofm7qv[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡻࡲ࡭ࠩ਱")]
				ttTVKH3QhzZxYd = RjVAI6uzxFofm7qv[XB4CjMkPFzhAHiI3q(u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭ਲ")]
				data = RjVAI6uzxFofm7qv[yylSaxCLfkte(u"ࠧࡥࡣࡷࡥࠬਲ਼")]
				headers = RjVAI6uzxFofm7qv[KA26GucUHOwXL(u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩ਴")]
				bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,ttTVKH3QhzZxYd,url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩਵ"))
				Y9wypG3KfSgl8C2DzaPVWHm = bqIufCQz2OWExjilm.content
				if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪ࠲ࡲࡶ࠴ࠨਸ਼") in Y9wypG3KfSgl8C2DzaPVWHm:
					jXqW0t7CZSn2dshG8E1HrlUu = w2qb6lf5EM
					break
				MtgaDxuAJGkcIZ4Sph = str(bqIufCQz2OWExjilm.headers)
				FE2J41QiCSvDYPyAO8uWZ75k = MtgaDxuAJGkcIZ4Sph+Y9wypG3KfSgl8C2DzaPVWHm
				fZDCO0XbaLSs7N8vTcQqmr6 = Zy2l0g8QU5vqefaTrsw.findall(HaTI5u1f3SCxmMAkw(u"ࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࡞ࡺ࠯࠮࠴ࠪࡀࠤࠫࡩࡾࡐ࠮ࠫࡁࠬࠦࠬ਷"),FE2J41QiCSvDYPyAO8uWZ75k,Zy2l0g8QU5vqefaTrsw.DOTALL)
				eOVb64kRWwArpNmu5CLXtzfDF = Zy2l0g8QU5vqefaTrsw.findall(rC5tnFDlQcRGA2(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴ࠮ࠫࡁࠥࠬ࠵࠹ࡁ࠯ࠬࡂ࠭ࠧ࠭ਸ"),FE2J41QiCSvDYPyAO8uWZ75k,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if eOVb64kRWwArpNmu5CLXtzfDF: eOVb64kRWwArpNmu5CLXtzfDF = eOVb64kRWwArpNmu5CLXtzfDF[ZVNvqy4iF1a9X]
				if fZDCO0XbaLSs7N8vTcQqmr6 or eOVb64kRWwArpNmu5CLXtzfDF: break
		if not jXqW0t7CZSn2dshG8E1HrlUu:
			if not fZDCO0XbaLSs7N8vTcQqmr6:
				if captcha and not eOVb64kRWwArpNmu5CLXtzfDF:
					if P2Fgh6TCOWoaHjkqBcQnvRNXe: eOVb64kRWwArpNmu5CLXtzfDF = P49KnYr5bEVmfxB(mHxu8WR0ec7BG9VIhTNyO3Fk,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡡࡳࠩਹ"),X6XZ5HbYeorC8s3nilWQ)
					else:
						if not bGIVq1CQTjmosZg.startswith(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡊࡆࡀࠫ਺")):
							data = {JACnOz297UuDK5HpPkc1LF(u"ࠨࡷࡶࡩࡷ࠭਻"):Ew2zQ8u7Ss.AV_CLIENT_IDS,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡹࡩࡷࡹࡩࡰࡰ਼ࠪ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡹࡷࡲࠧ਽"):X6XZ5HbYeorC8s3nilWQ,yylSaxCLfkte(u"ࠫࡰ࡫ࡹࠨਾ"):mHxu8WR0ec7BG9VIhTNyO3Fk,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࡯ࡤࠨਿ"):CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡪࡰࡤࠪੀ"):cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡨࡧࡷ࡭ࡩ࠭ੁ")}
							bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡒࡒࡗ࡙࠭ੂ"),tCIhoNqu0S,data,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠺ࡴࡩࠩ੃"))
							bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
						else: bGIVq1CQTjmosZg = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡍࡉࡃ࠱࠳࠵࠷࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾࠶࠸ࠫ੄")
						if bGIVq1CQTjmosZg.startswith(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡎࡊ࠽ࠨ੅")):
							Tt6el7UsvY2mHqaD4EcQLkbWKxJ = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠬࡏࡄ࠾ࠪ࠱࠮ࡄ࠯࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠭࠴ࠪࡀࠫࠧࠫ੆"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
							hCfJ2Dz8HsV61Nb,p3voWAbJhDmLaI2lgYGcVMEX = Tt6el7UsvY2mHqaD4EcQLkbWKxJ[ZVNvqy4iF1a9X]
							LLyhViKbxMntl5JSk = otNfFapeEnO(u"࠭็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ์็ะࠠๆ่ࠣ࠵࠵ࠦลๅ๋ࠣࠫੇ")+p3voWAbJhDmLaI2lgYGcVMEX+JACnOz297UuDK5HpPkc1LF(u"ࠧࠡอส๊๏ฯࠧੈ")
							OejfAMyHhNxYbXoRq6CuS3tlgz = lkPKsYmp4UjR()
							OejfAMyHhNxYbXoRq6CuS3tlgz.create(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ็ะหํ๊ษࠡฬฯหํุࠠโฯุࠤศ์วࠡล้ืฬ์้ࠠๆึฮࠥฮั็ษ่ะ้่ࠥๆสํ์ฯืࠧ੉"),LLyhViKbxMntl5JSk)
							V9mORPHKysfhg6wxJ = L8Wkv5KCSoq.time()
							mKYGlw1CZzVWnpquTQsJx96yM3D4H,wQhPuV5WOcEKz3SN6oRGd0Fxynkl1I = ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
							while mKYGlw1CZzVWnpquTQsJx96yM3D4H<int(p3voWAbJhDmLaI2lgYGcVMEX):
								KK4WuMYyThQ8l0SID2JrfGsb6UNx(OejfAMyHhNxYbXoRq6CuS3tlgz,int(mKYGlw1CZzVWnpquTQsJx96yM3D4H/int(p3voWAbJhDmLaI2lgYGcVMEX)*KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠱࠱࠲ා")),LLyhViKbxMntl5JSk,CJlTSEpZsWb0QHg5w,p3voWAbJhDmLaI2lgYGcVMEX+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࠣ࠳ࠥ࠭੊")+str(int(mKYGlw1CZzVWnpquTQsJx96yM3D4H))+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࠤࠥัว็์ฬࠫੋ"))
								if mKYGlw1CZzVWnpquTQsJx96yM3D4H>wQhPuV5WOcEKz3SN6oRGd0Fxynkl1I+rC5tnFDlQcRGA2(u"࠲࠲ැ"):
									data = {JACnOz297UuDK5HpPkc1LF(u"ࠫࡺࡹࡥࡳࠩੌ"):Ew2zQ8u7Ss.AV_CLIENT_IDS,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ੍࠭"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,yylSaxCLfkte(u"࠭ࡵࡳ࡮ࠪ੎"):X6XZ5HbYeorC8s3nilWQ,EcjO3giln2kQTdBY0XLAG(u"ࠧ࡬ࡧࡼࠫ੏"):mHxu8WR0ec7BG9VIhTNyO3Fk,cjVhOCwybeRo7UWg92(u"ࠨ࡫ࡧࠫ੐"):hCfJ2Dz8HsV61Nb,XB4CjMkPFzhAHiI3q(u"ࠩ࡭ࡳࡧ࠭ੑ"):xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬ੒")}
									bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,EcjO3giln2kQTdBY0XLAG(u"ࠫࡕࡕࡓࡕࠩ੓"),tCIhoNqu0S,data,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬ੔"))
									bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
									if bGIVq1CQTjmosZg.startswith(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡔࡐࡍࡈࡒࡂ࠭੕")):
										eOVb64kRWwArpNmu5CLXtzfDF = bGIVq1CQTjmosZg.split(XB4CjMkPFzhAHiI3q(u"ࠧࡕࡑࡎࡉࡓࡃࠧ੖"),TDpFsQXHze2q30uYtGPfEIm8(u"࠳ෑ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
										break
									wQhPuV5WOcEKz3SN6oRGd0Fxynkl1I = mKYGlw1CZzVWnpquTQsJx96yM3D4H
								else: L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
								mKYGlw1CZzVWnpquTQsJx96yM3D4H = L8Wkv5KCSoq.time()-V9mORPHKysfhg6wxJ
							OejfAMyHhNxYbXoRq6CuS3tlgz.close()
				if eOVb64kRWwArpNmu5CLXtzfDF:
					aVRMpYeNTBEr0DCm7n4dKy1Fgb = bqIufCQz2OWExjilm.cookies
					HpDR8BENQVqTCh14t5ZwJ9IlUzLXie = Zy2l0g8QU5vqefaTrsw.findall(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠪ࠱࠮ࡄ࠯࠻ࠨ੗"),FE2J41QiCSvDYPyAO8uWZ75k,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩ੘") in list(aVRMpYeNTBEr0DCm7n4dKy1Fgb.keys()): HpDR8BENQVqTCh14t5ZwJ9IlUzLXie = aVRMpYeNTBEr0DCm7n4dKy1Fgb[ZP1LyUCS3pIBu(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࠪਖ਼")]
					elif HpDR8BENQVqTCh14t5ZwJ9IlUzLXie: HpDR8BENQVqTCh14t5ZwJ9IlUzLXie = HpDR8BENQVqTCh14t5ZwJ9IlUzLXie[ZVNvqy4iF1a9X]
					captcha = Zy2l0g8QU5vqefaTrsw.findall(TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਗ਼"),Y9wypG3KfSgl8C2DzaPVWHm,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if captcha: HHPABWmLJFpRC,mHxu8WR0ec7BG9VIhTNyO3Fk = captcha[ZVNvqy4iF1a9X]
					if HpDR8BENQVqTCh14t5ZwJ9IlUzLXie and captcha:
						headers = {h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬਜ਼"):XB4CjMkPFzhAHiI3q(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠧੜ")+HpDR8BENQVqTCh14t5ZwJ9IlUzLXie,cjVhOCwybeRo7UWg92(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ੝"):X6XZ5HbYeorC8s3nilWQ,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧਫ਼"):HaTI5u1f3SCxmMAkw(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨ੟")}
						data = JACnOz297UuDK5HpPkc1LF(u"ࠪ࡫࠲ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡴࡨࡷࡵࡵ࡮ࡴࡧࡀࠫ੠")+eOVb64kRWwArpNmu5CLXtzfDF
						bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡕࡕࡓࡕࠩ੡"),HHPABWmLJFpRC,data,headers,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠸ࡷ࡬ࠬ੢"))
						Y9wypG3KfSgl8C2DzaPVWHm = bqIufCQz2OWExjilm.content
						try: cookies = bqIufCQz2OWExjilm.cookies
						except: cookies = {}
						fZDCO0XbaLSs7N8vTcQqmr6 = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠳࠰࠿ࠪࠩ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ੣"),str(cookies),Zy2l0g8QU5vqefaTrsw.DOTALL)
			if fZDCO0XbaLSs7N8vTcQqmr6:
				idaKcvOmbRrkW1CtHhZfeAJQV4D,fZDCO0XbaLSs7N8vTcQqmr6 = fZDCO0XbaLSs7N8vTcQqmr6[ZVNvqy4iF1a9X]
				EglLbxK8dH1RpDeu27zmqIify4TX = idaKcvOmbRrkW1CtHhZfeAJQV4D+s97s2k0LJgl(u"ࠧ࠾ࠩ੤")+fZDCO0XbaLSs7N8vTcQqmr6
				ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(KA26GucUHOwXL(u"ࠨࡣࡹ࠲ࡦࡱࡷࡢ࡯࠱ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩ੥"),EglLbxK8dH1RpDeu27zmqIify4TX)
				PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"้ࠩะาะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฦ่ึห๋ࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหาื์ࠠ็ฬสสัࠦ็ัษࠣห้็อึࠢ็็๏๊ࠦิฬัำ๊ํวࠡๆสั็อࠠ࠯࠰ࠣ์้อࠠห๊ฯำࠥำวอห่ࠣส฿วะห๋ࠣีอࠠศๆไัฺࠦไฺัฬࠤศฺ็าࠢ࡟ࡲࡡࡴฺࠠๆ่หࠥษๆ้ࠡำหࠥอไโฯุࠤุ๎แࠡ์อ็ึืࠠโ์ࠣัฬ๊ษࠡฬ฽๎ึࠦัษูࠣห้า็ศิࠣฬฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥหืโษฤࠤึอ่หำࠣห้หๆหำ้ฮࠥ࠴࠮ࠡล๋ࠤๆ฻ไࠡี็็ࠥอไาษ๋ฮึࠦ࠮࠯ࠢฦ์ࠥอำหะาห๊ࠦࡖࡑࡐࠣวํࠦศา๊ๆื๏࠭੦"))
				if xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ࠲ࡲࡶ࠴ࠨ੧") not in Y9wypG3KfSgl8C2DzaPVWHm:
					headers = {E6xdOMpqISHZCn(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ੨"):EglLbxK8dH1RpDeu27zmqIify4TX}
					bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡍࡅࡕࠩ੩"),X6XZ5HbYeorC8s3nilWQ,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡅ࡝ࡕࡇࡓࡔࡡࡄࡏ࡜ࡇࡍࡠࡅࡄࡔ࡙ࡉࡈࡂ࠯࠺ࡸ࡭࠭੪"))
					Y9wypG3KfSgl8C2DzaPVWHm = bqIufCQz2OWExjilm.content
	if not jXqW0t7CZSn2dshG8E1HrlUu and not EglLbxK8dH1RpDeu27zmqIify4TX: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧโึ็ฮࠥ฿ๅๅ์ฬࠤๆำีࠡล้หࠥษๆิษ้ࠤ࠳࠴ࠠฮษ๋่ࠥหูศัฬࠤฬู๊ๆๆํอ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆ้ࠢๅุࠦวๅใํำ๏๎ࠠฤ๊ࠣๅ๏ี๊้ࠢ฽๎ึํࠠๆ่๊ࠣๆูࠠศๆ่์็฿ࠧ੫"))
	return Y9wypG3KfSgl8C2DzaPVWHm
def fMhIVs8A5o(url,kcxAmftieK56PE9TqbDHdSrF8,egYIsS2qROfpVW83kx):
	FhX9OGwaNyAEZ,steS3aGdomU = [],[]
	X6XZ5HbYeorC8s3nilWQ = url
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,VVvcQpCU3OM09n(u"ࠨࡉࡈࡘࠬ੬"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡘࡃࡐ࠱࠶ࡹࡴࠨ੭"))
	Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
	FYCjEDhZlMK2kbAatLGze7PX = []
	if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫ੮") in Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp or NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ੯") in Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp:
		p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall(Olh7n0zfV4(u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠳࠰࠿࠽࠱ࡤࡂࠬੰ"),Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if p3LfChWJd124eAYj78zw09SXonH:
			for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
				Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪੱ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,title in Rp1g7OlotseGnf0NFmKk6rLxd:
					if ZgsbN5iSL48t2IhVFnmy in FhX9OGwaNyAEZ: continue
					if O4F8UC5lMAS6ghETm1VoPDI(u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨੲ") not in ZgsbN5iSL48t2IhVFnmy and s97s2k0LJgl(u"ࠨ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧ࠳ࠬੳ") not in ZgsbN5iSL48t2IhVFnmy: continue
					if yylSaxCLfkte(u"ࠩสࠫੴ") not in title:
						FYCjEDhZlMK2kbAatLGze7PX.append((title,ZgsbN5iSL48t2IhVFnmy))
						continue
					title = title.replace(yylSaxCLfkte(u"ࠪࡀ࠴ࡹࡰࡢࡰࡁࠫੵ"),CJlTSEpZsWb0QHg5w).replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࠥ࠳ࠠࠨ੶"),CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
					if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡹࡰࡢࡰࠪ੷") in title: continue
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
					steS3aGdomU.append(title)
			for title,ZgsbN5iSL48t2IhVFnmy in FYCjEDhZlMK2kbAatLGze7PX:
				if ZgsbN5iSL48t2IhVFnmy not in FhX9OGwaNyAEZ:
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
					steS3aGdomU.append(title)
			CrqTamtPFuU = ZVNvqy4iF1a9X
			if len(FhX9OGwaNyAEZ)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				CrqTamtPFuU = T4TK17YsEfZJ(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ศฺุ๊หࠥ๐อหษฯࠤ࠻࠶ࠠฬษ้๎ฮ࠭੸"),steS3aGdomU)
				if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return KA26GucUHOwXL(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ੹"),[],[]
			if FhX9OGwaNyAEZ and CrqTamtPFuU>=ZVNvqy4iF1a9X: X6XZ5HbYeorC8s3nilWQ = FhX9OGwaNyAEZ[CrqTamtPFuU]
	Y9wypG3KfSgl8C2DzaPVWHm = r1dow4CIZhlBTf(X6XZ5HbYeorC8s3nilWQ)
	MNXzjK3vV7D,Uz8mMbZifCyvkLnct = [],[]
	if kcxAmftieK56PE9TqbDHdSrF8==otNfFapeEnO(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ੺"):
		ELcuI2Ztab6BplkxmnFRXV1 = Zy2l0g8QU5vqefaTrsw.findall(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡥࡸࡳ࠳࡬ࡰࡣࡧࡩࡷ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੻"),Y9wypG3KfSgl8C2DzaPVWHm,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ELcuI2Ztab6BplkxmnFRXV1:
			ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ELcuI2Ztab6BplkxmnFRXV1[ZVNvqy4iF1a9X])
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			Uz8mMbZifCyvkLnct.append(egYIsS2qROfpVW83kx)
	elif kcxAmftieK56PE9TqbDHdSrF8==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡻࡦࡺࡣࡩࠩ੼"):
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡁࡹ࡯ࡶࡴࡦࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴ࡫ࡽࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੽"),Y9wypG3KfSgl8C2DzaPVWHm,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,size in Rp1g7OlotseGnf0NFmKk6rLxd:
			if not ZgsbN5iSL48t2IhVFnmy: continue
			if egYIsS2qROfpVW83kx in size:
				Uz8mMbZifCyvkLnct.append(size)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
				break
		if not MNXzjK3vV7D:
			for ZgsbN5iSL48t2IhVFnmy,size in Rp1g7OlotseGnf0NFmKk6rLxd:
				if not ZgsbN5iSL48t2IhVFnmy: continue
				Uz8mMbZifCyvkLnct.append(size)
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if not MNXzjK3vV7D: return o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡍ࡚ࡅࡒ࠭੾"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def PMGCT1ry9N(url,idaKcvOmbRrkW1CtHhZfeAJQV4D):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡇࡆࡖࠪ੿"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠴ࡷࡹ࠭઀"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	cookies = bqIufCQz2OWExjilm.cookies
	if KA26GucUHOwXL(u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨઁ") in list(cookies.keys()):
		EglLbxK8dH1RpDeu27zmqIify4TX = cookies[HaTI5u1f3SCxmMAkw(u"ࠩࡪࡳࡱ࡯࡮࡬ࠩં")]
		EglLbxK8dH1RpDeu27zmqIify4TX = sWzgdLCjSVwaMuhFkNf1Uop(pd0Na8D5WZfHYkysVS(EglLbxK8dH1RpDeu27zmqIify4TX))
		items = Zy2l0g8QU5vqefaTrsw.findall(ZP1LyUCS3pIBu(u"ࠪࡶࡴࡻࡴࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫઃ"),EglLbxK8dH1RpDeu27zmqIify4TX,Zy2l0g8QU5vqefaTrsw.DOTALL)
		BBwfuWGxUIrdCoc4ka7 = items[ZVNvqy4iF1a9X].replace(yylSaxCLfkte(u"ࠫࡡ࠵ࠧ઄"),o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࠵ࠧઅ"))
		BBwfuWGxUIrdCoc4ka7 = pd0Na8D5WZfHYkysVS(BBwfuWGxUIrdCoc4ka7)
	else: BBwfuWGxUIrdCoc4ka7 = url
	if E6xdOMpqISHZCn(u"࠭ࡣࡢࡶࡦ࡬࠳࡯ࡳࠨઆ") in BBwfuWGxUIrdCoc4ka7:
		ddEhiVuvn5KYspgR8f3DQXAc = BBwfuWGxUIrdCoc4ka7.split(JACnOz297UuDK5HpPkc1LF(u"ࠧࠦ࠴ࡉࠫઇ"))[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
		BBwfuWGxUIrdCoc4ka7 = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡤࡸࡨ࡮࠮ࡪࡵ࠲ࠫઈ")+ddEhiVuvn5KYspgR8f3DQXAc
		return cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬઉ"),[CJlTSEpZsWb0QHg5w],[BBwfuWGxUIrdCoc4ka7]
	else:
		website = Ew2zQ8u7Ss.SITESURLS[VVvcQpCU3OM09n(u"ࠪࡅࡐࡕࡁࡎࠩઊ")][ZVNvqy4iF1a9X]
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,E6xdOMpqISHZCn(u"ࠫࡌࡋࡔࠨઋ"),website,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓ࠭࠳ࡰࡧࠫઌ"))
		ofNW1LBMCTYm7qkgbhjP3lrR4eIvx2 = bqIufCQz2OWExjilm.url
		uBsLmICOn1zgkZf9A = BBwfuWGxUIrdCoc4ka7.split(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭࠯ࠨઍ"))[VTadWjBloMwXO2CH9GDK6FR]
		ssAGea9EOhzqY32WiPDR8g = ofNW1LBMCTYm7qkgbhjP3lrR4eIvx2.split(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧ࠰ࠩ઎"))[VTadWjBloMwXO2CH9GDK6FR]
		ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7.replace(uBsLmICOn1zgkZf9A,ssAGea9EOhzqY32WiPDR8g)
		headers = { GISOTJh20W(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬએ"):CJlTSEpZsWb0QHg5w , od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬઐ"):HaTI5u1f3SCxmMAkw(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫઑ") , ZP1LyUCS3pIBu(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ઒"):ysw7G3tqjo }
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡖࡏࡔࡖࠪઓ"), ysw7G3tqjo, CJlTSEpZsWb0QHg5w, headers, VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠵ࡵࡨࠬઔ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		items = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧક"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if not items:
			items = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩખ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
			if not items:
				items = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"ࠩ࠿ࡩࡲࡨࡥࡥ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩગ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if items:
			ZgsbN5iSL48t2IhVFnmy = items[ZVNvqy4iF1a9X].replace(pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡠ࠴࠭ઘ"),Olh7n0zfV4(u"ࠫ࠴࠭ઙ"))
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.rstrip(cjVhOCwybeRo7UWg92(u"ࠬ࠵ࠧચ"))
			if JACnOz297UuDK5HpPkc1LF(u"࠭ࡨࡵࡶࡳࠫછ") not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡩࡶࡷࡴ࠿࠭જ") + ZgsbN5iSL48t2IhVFnmy
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(otNfFapeEnO(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠩઝ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫઞ"))
			if idaKcvOmbRrkW1CtHhZfeAJQV4D==CJlTSEpZsWb0QHg5w: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
			else: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ટ"),[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
		else: nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = otNfFapeEnO(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡁࡌࡑࡄࡑࠬઠ"),[],[]
		return nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def y4ERYXTtjHMilOvDW(url):
	headers = { otNfFapeEnO(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩડ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡕࡅࡕࡏࡄࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪઢ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨણ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D,errno = [],[],CJlTSEpZsWb0QHg5w
	if items:
		for ZgsbN5iSL48t2IhVFnmy,m9wgSl1oUVRd in items:
			Uz8mMbZifCyvkLnct.append(m9wgSl1oUVRd)
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if len(MNXzjK3vV7D)==ZVNvqy4iF1a9X: return EcjO3giln2kQTdBY0XLAG(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠧત"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def g8SwoNQROefYEGP1t3BKMix95D(url):
	DrKqvRJgASd4kzVZWucE = url.split(mi2ZJXCDzITuyev6gfn(u"ࠩ࠲ࠫથ"))[TDpFsQXHze2q30uYtGPfEIm8(u"࠶ි")]
	data = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠨ࡬ࡨࡂ࠭દ")+DrKqvRJgASd4kzVZWucE
	headers = {Olh7n0zfV4(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪધ"):otNfFapeEnO(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫન")}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡐࡐࡕࡗࠫ઩"),url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡗࡊࡌ࠮࠳ࡶࡸࠬપ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = Zy2l0g8QU5vqefaTrsw.findall(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡣࡧࡦࡱࡵࡣ࡬ࡡࡧࡩࡹ࡫ࡣࡵࡧࡧ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬફ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		url = items[ZVNvqy4iF1a9X]
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
	return rC5tnFDlQcRGA2(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡋࡘࡄࡍࠩબ"),[],[]
def UUMB8eTf6v9CsjoHiYVKn71ZOx(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,otNfFapeEnO(u"ࠪࡋࡊ࡚ࠧભ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡗࡍ࠰࠵ࡸࡺࠧમ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	try: bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.decode(cjVhOCwybeRo7UWg92(u"ࠬࡻࡴࡧ࠺ࠪય"),E6xdOMpqISHZCn(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ર"))
	except: pass
	items = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"ࠧࡥࡱࡦࡷࡤࡴ࡯ࡠࡲࡵࡩࡻ࡯ࡥࡸࡡࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ઱"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		url = items[ZVNvqy4iF1a9X]
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
	return XB4CjMkPFzhAHiI3q(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡚ࠣࡐ࠭લ"),[],[]
def nKbx6klaVepNCWqoM3Ii7rQg(url):
	headers = {KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ળ"):CJlTSEpZsWb0QHg5w}
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡒࡎࡒࡅࡉ࠳࠱ࡴࡶࠪ઴"))
	items = Zy2l0g8QU5vqefaTrsw.findall(zQGaM7ctZCN(u"ࠫࡸࡵࡵࡳࡥࡨࡷ࠿ࠦ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣࠩવ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		url = items[ZVNvqy4iF1a9X]+XB4CjMkPFzhAHiI3q(u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠨશ")+url
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
	return ZP1LyUCS3pIBu(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡗࡔࡐࡔࡇࡄࠨષ"),[],[]
def pFIljnD4car6K85G(url):
	url = url.strip(JACnOz297UuDK5HpPkc1LF(u"ࠧ࠰ࠩસ"))
	if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩહ") in url: ddEhiVuvn5KYspgR8f3DQXAc = url.split(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩ࠲ࠫ઺"))[P3cpaLN2sH]
	else: ddEhiVuvn5KYspgR8f3DQXAc = url.split(ZP1LyUCS3pIBu(u"ࠪ࠳ࠬ઻"))[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
	url = TDpFsQXHze2q30uYtGPfEIm8(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡣࡴࡶࡵࡩࡦࡳ࠮ࡵࡱ࠲ࡴࡱࡧࡹࡦࡴࡂࡪ࡮ࡪ࠽ࠨ઼") + ddEhiVuvn5KYspgR8f3DQXAc
	headers = { TMfV6892ZoBdyxCH3tGrkwY0K(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩઽ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡙ࡇࡘ࡚ࡒࡆࡃࡐ࠱࠶ࡹࡴࠨા"))
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧ࡝࡞ࠪિ"),CJlTSEpZsWb0QHg5w)
	items = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨી"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ items[ZVNvqy4iF1a9X] ]
	return cjVhOCwybeRo7UWg92(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡉࡓࡕࡔࡈࡅࡒ࠭ુ"),[],[]
def xrhp9XcDujCPHOw(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡊࡆࡒ࡞ࡆ࠳࠱ࡴࡶࠪૂ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡲࡡࡣࡧ࡯࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠱ࠦࡲࡦࡵ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫૃ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	for ZgsbN5iSL48t2IhVFnmy,m9wgSl1oUVRd,wwx7Hya1CoYNMP2 in items:
		Uz8mMbZifCyvkLnct.append(m9wgSl1oUVRd+YvOQBzaTAscXR9ql+wwx7Hya1CoYNMP2)
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if len(MNXzjK3vV7D)==ZVNvqy4iF1a9X: return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡗࡋࡇࡓ࡟ࡇࠧૄ"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def FFsQTkwmzhR(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠱ࡴࡶࠪૅ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡹ࡭ࡩ࡫࡯࡝ࠪࠪࠬ࠳࠰࠿ࠪࠩ࠯ࠫ࠭࠴ࠪࡀࠫࠪ࠰ࠬ࠮࠮ࠫࡁࠬࠫࡡ࠯࡜ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠯࠲࠯ࡅ࠼࠰ࡶࡧࡂࠧ૆"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	items = set(items)
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	for ddEhiVuvn5KYspgR8f3DQXAc,BEUVvSQtRimC,ZOkNBPwYy62,m9wgSl1oUVRd,wwx7Hya1CoYNMP2 in items:
		url = cjVhOCwybeRo7UWg92(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠴ࡵࡴ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬે")+ddEhiVuvn5KYspgR8f3DQXAc+pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࠩࡱࡴࡪࡥ࠾ࠩૈ")+BEUVvSQtRimC+ZP1LyUCS3pIBu(u"ࠪࠪ࡭ࡧࡳࡩ࠿ࠪૉ")+ZOkNBPwYy62
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,GISOTJh20W(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠷ࡴࡤࠨ૊"))
		items = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫો"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy in items:
			Uz8mMbZifCyvkLnct.append(m9wgSl1oUVRd+YvOQBzaTAscXR9ql+wwx7Hya1CoYNMP2)
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if len(MNXzjK3vV7D)==ZVNvqy4iF1a9X: return od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤ࡙ࠡࡄࡘࡈࡎࡖࡊࡆࡈࡓࠬૌ"),[],[]
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def FDhqiceKgBXkImwVP4MWEof(url):
	ZgsbN5iSL48t2IhVFnmy = CJlTSEpZsWb0QHg5w
	if P2Fgh6TCOWoaHjkqBcQnvRNXe or cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡌࡧࡼࡁ્ࠬ") not in url:
		BBwfuWGxUIrdCoc4ka7 = url.replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡷࡳࡦࡴࡳ࠮࡭࡫ࡹࡩࠬ૎"),E6xdOMpqISHZCn(u"ࠩࡸࡴࡵࡵ࡭࠯࡮࡬ࡺࡪ࠭૏"))
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.split(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࠳ࠬૐ"))
		ddEhiVuvn5KYspgR8f3DQXAc = BBwfuWGxUIrdCoc4ka7[D9yBM7wPFLz]
		BBwfuWGxUIrdCoc4ka7 = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫ࠴࠭૑").join(BBwfuWGxUIrdCoc4ka7[ZVNvqy4iF1a9X:P3cpaLN2sH])
		wSfEHOilLYIK = {E6xdOMpqISHZCn(u"ࠬ࡯ࡤࠨ૒"):ddEhiVuvn5KYspgR8f3DQXAc,pz4WBwfyDdgk0m2aRr7SMv(u"࠭࡯ࡱࠩ૓"):HaTI5u1f3SCxmMAkw(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠪ૔"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࡯ࡨࡸ࡭ࡵࡤࡠࡨࡵࡩࡪ࠭૕"):yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡉࡶࡪ࡫ࠫࡅࡱࡺࡲࡱࡵࡡࡥ࠭ࠨ࠷ࡊࠫ࠳ࡆࠩ૖")}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡔࡔ࡙ࡔࠨ૗"),BBwfuWGxUIrdCoc4ka7,wSfEHOilLYIK,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠱ࡴࡶࠪ૘"))
		if EcjO3giln2kQTdBY0XLAG(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ૙") in list(bqIufCQz2OWExjilm.headers.keys()): ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ૚")]
		if not ZgsbN5iSL48t2IhVFnmy and bqIufCQz2OWExjilm.succeeded:
			bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
			ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(cjVhOCwybeRo7UWg92(u"ࠧࡪࡦࡀࠦࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ૛"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
	else:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,zQGaM7ctZCN(u"ࠨࡉࡈࡘࠬ૜"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡐࡃࡑࡐ࠱࠷ࡴࡤࠨ૝"))
		if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬ૞") in list(bqIufCQz2OWExjilm.headers.keys()): ZgsbN5iSL48t2IhVFnmy = bqIufCQz2OWExjilm.headers[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭૟")]
	if ZgsbN5iSL48t2IhVFnmy: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	return E6xdOMpqISHZCn(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡖࡒࡅࡓࡒ࠭ૠ"),[],[]
def xRLp0iUIMujOqf4avhwnJ6C53E(url):
	headers = { KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪૡ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡐࡎࡏࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩૢ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡵࡲࡹࡷࡩࡥࡴ࠼࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧૣ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	if items:
		Uz8mMbZifCyvkLnct.append(Olh7n0zfV4(u"ࠩࡰࡴ࠹࠭૤"))
		MNXzjK3vV7D.append(items[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe])
		Uz8mMbZifCyvkLnct.append(O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡱ࠸ࡻ࠸ࠨ૥"))
		MNXzjK3vV7D.append(items[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X])
		return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
	else: return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡌࡊࡋ࡙ࡍࡉࡋࡏࠨ૦"),[],[]
def Vc5C4HmhgXPrM(url):
	ddEhiVuvn5KYspgR8f3DQXAc = url.split(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬ࠵ࠧ૧"))[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
	ddEhiVuvn5KYspgR8f3DQXAc = ddEhiVuvn5KYspgR8f3DQXAc.split(o2FdrDBimMuOw97q6QpNW8S(u"࠭ࠦࠨ૨"))[ZVNvqy4iF1a9X]
	ddEhiVuvn5KYspgR8f3DQXAc = ddEhiVuvn5KYspgR8f3DQXAc.replace(mi2ZJXCDzITuyev6gfn(u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ૩"),CJlTSEpZsWb0QHg5w)
	BBwfuWGxUIrdCoc4ka7 = Ew2zQ8u7Ss.SITESURLS[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ૪")][ZVNvqy4iF1a9X]+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ૫")+ddEhiVuvn5KYspgR8f3DQXAc
	YYsRFcnzOKbUHk6IBdwy2 = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࠭૬")+ddEhiVuvn5KYspgR8f3DQXAc
	eqVPIOhpxtFy,up7RfMNd1X = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	bGIVq1CQTjmosZg = CJlTSEpZsWb0QHg5w
	TvbSZDRi84I,DDuAgkFnXqlc3YZMQHp1r = CJlTSEpZsWb0QHg5w,{}
	s4ICZWhKngMSmDlJ9HPiXpojxG3,M90jQzoE6cHTqiFkGr5CS = CJlTSEpZsWb0QHg5w,{}
	headers = {zQGaM7ctZCN(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૭"):CJlTSEpZsWb0QHg5w}
	if ZVNvqy4iF1a9X:
		WNChIxPiSvRsObqcl5XaHLjYyfm = rC5tnFDlQcRGA2(u"࠵ී")
		for LxNV5lenkhW6zoBJDMA7ZuqSg in range(WNChIxPiSvRsObqcl5XaHLjYyfm):
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,yylSaxCLfkte(u"ࠬࡍࡅࡕࠩ૮"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠵ࡸࡺࠧ૯"))
			bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		lQNfmFHtUpCsDTv6RuLxcBaihKgV = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"ࠧࡷࡣࡵࠤࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡐ࡭ࡣࡼࡩࡷࡘࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫ૰"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		TvbSZDRi84I = lQNfmFHtUpCsDTv6RuLxcBaihKgV[ZVNvqy4iF1a9X] if lQNfmFHtUpCsDTv6RuLxcBaihKgV else bGIVq1CQTjmosZg
		DDuAgkFnXqlc3YZMQHp1r = oE7iT3HI5VDdmY4kPOjr(Olh7n0zfV4(u"ࠨࡦ࡬ࡧࡹ࠭૱"),TvbSZDRi84I)
	else:
		ysw7G3tqjo = Ew2zQ8u7Ss.SITESURLS[KA26GucUHOwXL(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ૲")][ZVNvqy4iF1a9X]+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪ࠳ࡾࡵࡵࡵࡷࡥࡩ࡮࠵ࡶ࠲࠱ࡳࡰࡦࡿࡥࡳࠩ૳")
		moAfNYgrkQsLwSVJG7KF1ua = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡦࡼ࠮ࡺࡱࡸࡸࡺࡨࡥ࠯ࡦࡤࡸࡦ࠭૴"))
		if moAfNYgrkQsLwSVJG7KF1ua.count(zQGaM7ctZCN(u"ࠬࡀ࠺࠻ࠩ૵"))==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠹ු"):
			VVw69yoifXgtG0ICb,key,xdL2YH1vrEDwVkZt,iFdphTKLJaOncyD4P3xSYGv2IRWE,eOVb64kRWwArpNmu5CLXtzfDF = moAfNYgrkQsLwSVJG7KF1ua.split(yylSaxCLfkte(u"࠭࠺࠻࠼ࠪ૶"))
			headers[I7K1Tbk8YSXUhApzqwtLEQMV2(u"࡙ࠧ࠯ࡊࡳࡴ࡭࠭ࡗ࡫ࡶ࡭ࡹࡵࡲ࠮ࡋࡧࠫ૷")] = VVw69yoifXgtG0ICb
		headers[o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ૸")] = ZP1LyUCS3pIBu(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬૹ")
		if P2Fgh6TCOWoaHjkqBcQnvRNXe:
			kjGCm2DWF9wdlTb5 = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡿࠧࡼࡩࡥࡧࡲࡍࡩࠨ࠺ࠡࠤࠪૺ")+ddEhiVuvn5KYspgR8f3DQXAc+GISOTJh20W(u"ࠫࠧ࠲ࠠࠣࡥࡲࡲࡹ࡫ࡸࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹࠨ࠺ࠡࡽࠥࡧࡱ࡯ࡥ࡯ࡶ࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠷࠯࠴࠳࠶࠹࠷࠲࠱࠳࠱࠵࠽࠴࠰࠱ࠤ࠯ࠤࠧࡩ࡬ࡪࡧࡱࡸࡓࡧ࡭ࡦࠤ࠽ࠤ࡚ࠧࡖࡉࡖࡐࡐ࠺ࠨࡽࡾࡿࠪૻ")
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,JACnOz297UuDK5HpPkc1LF(u"ࠬࡖࡏࡔࡖࠪૼ"),ysw7G3tqjo,kjGCm2DWF9wdlTb5,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠶ࡳࡪࠧ૽"))
			lQNfmFHtUpCsDTv6RuLxcBaihKgV = bqIufCQz2OWExjilm.content
			if mi2ZJXCDzITuyev6gfn(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧ૾") in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
				TvbSZDRi84I = lQNfmFHtUpCsDTv6RuLxcBaihKgV.replace(E6xdOMpqISHZCn(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩ૿"),HaTI5u1f3SCxmMAkw(u"ࠩࠩࠫ଀"))
				DDuAgkFnXqlc3YZMQHp1r = oE7iT3HI5VDdmY4kPOjr(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡨ࡮ࡩࡴࠨଁ"),TvbSZDRi84I)
		if P2Fgh6TCOWoaHjkqBcQnvRNXe:
			kjGCm2DWF9wdlTb5 = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࢀࠨࡶࡪࡦࡨࡳࡎࡪࠢ࠻ࠢࠥࠫଂ")+ddEhiVuvn5KYspgR8f3DQXAc+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࠨࠬࠡࠤࡦࡳࡳࡺࡥࡹࡶࠥ࠾ࠥࢁࠢࡤ࡮࡬ࡩࡳࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢ࠲࠻࠱࠸࠺࠴࠴ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡎࡕࡓࠣࡿࢀࢁࠬଃ")
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,zQGaM7ctZCN(u"࠭ࡐࡐࡕࡗࠫ଄"),ysw7G3tqjo,kjGCm2DWF9wdlTb5,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠸ࡸࡤࠨଅ"))
			lQNfmFHtUpCsDTv6RuLxcBaihKgV = bqIufCQz2OWExjilm.content
			if cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨଆ") in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
				s4ICZWhKngMSmDlJ9HPiXpojxG3 = lQNfmFHtUpCsDTv6RuLxcBaihKgV.replace(ZP1LyUCS3pIBu(u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪଇ"),JACnOz297UuDK5HpPkc1LF(u"ࠪࠪࠬଈ"))
				M90jQzoE6cHTqiFkGr5CS = oE7iT3HI5VDdmY4kPOjr(KA26GucUHOwXL(u"ࠫࡩ࡯ࡣࡵࠩଉ"),s4ICZWhKngMSmDlJ9HPiXpojxG3)
		if P2Fgh6TCOWoaHjkqBcQnvRNXe and Olh7n0zfV4(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬଊ") not in TvbSZDRi84I:
			TvbSZDRi84I,DDuAgkFnXqlc3YZMQHp1r,DDuAgkFnXqlc3YZMQHp1r = CJlTSEpZsWb0QHg5w,{},{}
			kjGCm2DWF9wdlTb5 = cjVhOCwybeRo7UWg92(u"࠭ࡻࠣࡸ࡬ࡨࡪࡵࡉࡥࠤ࠽ࠤࠧ࠭ଋ")+ddEhiVuvn5KYspgR8f3DQXAc+s97s2k0LJgl(u"ࠧࠣ࠮ࠣࠦࡨࡵ࡮ࡵࡧࡻࡸࠧࡀࠠࡼࠤࡦࡰ࡮࡫࡮ࡵࠤ࠽ࠤࢀࠨࡣ࡭࡫ࡨࡲࡹ࡜ࡥࡳࡵ࡬ࡳࡳࠨ࠺ࠡࠤ࠵࠲࠷࠶࠲࠵࠲࠺࠶࠻࠴࠰࠲࠰࠳࠴ࠧ࠲ࠠࠣࡥ࡯࡭ࡪࡴࡴࡏࡣࡰࡩࠧࡀࠠࠣࡏ࡚ࡉࡇࠨࡽࡾࡿࠪଌ")
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡒࡒࡗ࡙࠭଍"),ysw7G3tqjo,kjGCm2DWF9wdlTb5,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠴ࡵࡪࠪ଎"))
			lQNfmFHtUpCsDTv6RuLxcBaihKgV = bqIufCQz2OWExjilm.content
			if cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪଏ") in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
				TvbSZDRi84I = lQNfmFHtUpCsDTv6RuLxcBaihKgV.replace(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡡࡢࡵ࠱࠲࠵࠺ࠬଐ"),Olh7n0zfV4(u"ࠬࠬࠧ଑"))
				DDuAgkFnXqlc3YZMQHp1r = oE7iT3HI5VDdmY4kPOjr(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡤࡪࡥࡷࠫ଒"),TvbSZDRi84I)
		if P2Fgh6TCOWoaHjkqBcQnvRNXe and XB4CjMkPFzhAHiI3q(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧଓ") not in s4ICZWhKngMSmDlJ9HPiXpojxG3:
			s4ICZWhKngMSmDlJ9HPiXpojxG3,M90jQzoE6cHTqiFkGr5CS,M90jQzoE6cHTqiFkGr5CS = CJlTSEpZsWb0QHg5w,{},{}
			kjGCm2DWF9wdlTb5 = cjVhOCwybeRo7UWg92(u"ࠨࡽࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨଔ")+ddEhiVuvn5KYspgR8f3DQXAc+yylSaxCLfkte(u"ࠩࠥ࠰ࠥࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠶࠿࠮࠳࠻࠱࠷࠼ࠨࠬࠡࠤࡦࡰ࡮࡫࡮ࡵࡐࡤࡱࡪࠨ࠺ࠡࠤࡄࡒࡉࡘࡏࡊࡆࠥ࠰ࠥࠨࡡ࡯ࡦࡵࡳ࡮ࡪࡓࡥ࡭࡙ࡩࡷࡹࡩࡰࡰࠥ࠾ࠥࠨ࠳࠲ࠤࢀࢁࢂ࠭କ")
			headers[XB4CjMkPFzhAHiI3q(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧଖ")] = Olh7n0zfV4(u"ࠫࡨࡵ࡭࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡣࡱࡨࡷࡵࡩࡥ࠰ࡼࡳࡺࡺࡵࡣࡧ࠲࠵࠾࠴࠲࠺࠰࠶࠻ࠥ࠮ࡌࡪࡰࡸࡼࡀࠦࡕ࠼ࠢࡄࡲࡩࡸ࡯ࡪࡦࠣ࠵࠷ࡁࠠࡈࡄࠬࠤ࡬ࢀࡩࡱࠩଗ")
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡖࡏࡔࡖࠪଘ"),ysw7G3tqjo,kjGCm2DWF9wdlTb5,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,JACnOz297UuDK5HpPkc1LF(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠹ࡹ࡮ࠧଙ"))
			lQNfmFHtUpCsDTv6RuLxcBaihKgV = bqIufCQz2OWExjilm.content
			if ZP1LyUCS3pIBu(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧଚ") in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
				s4ICZWhKngMSmDlJ9HPiXpojxG3 = lQNfmFHtUpCsDTv6RuLxcBaihKgV.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ࡞࡟ࡹ࠵࠶࠲࠷ࠩଛ"),XB4CjMkPFzhAHiI3q(u"ࠩࠩࠫଜ"))
				M90jQzoE6cHTqiFkGr5CS = oE7iT3HI5VDdmY4kPOjr(otNfFapeEnO(u"ࠪࡨ࡮ࡩࡴࠨଝ"),s4ICZWhKngMSmDlJ9HPiXpojxG3)
	dwruTxthc07m4bp3LsRSgOn,yyeMu9iam5IS8QJs7BgwT6oXE,FEn6z98gortB,HIJeDO4CYXwoguaL8MA0tkVPBR = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,[],[]
	TgDPO7KFUbRSJEH2npwcWo1lqGB9,qcLzPF8pkuM,uhdYzXO0JnmFEyo5fsjWgKNRI,u1unQC8RcpxB2dqgweEWINlP5Yy = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,[],[]
	try: yyeMu9iam5IS8QJs7BgwT6oXE = DDuAgkFnXqlc3YZMQHp1r[cjVhOCwybeRo7UWg92(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫଞ")][GISOTJh20W(u"ࠬ࡮࡬ࡴࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭ଟ")]
	except: pass
	try: qcLzPF8pkuM = M90jQzoE6cHTqiFkGr5CS[Olh7n0zfV4(u"࠭ࡳࡵࡴࡨࡥࡲ࡯࡮ࡨࡆࡤࡸࡦ࠭ଠ")][E6xdOMpqISHZCn(u"ࠧࡩ࡮ࡶࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨଡ")]
	except: pass
	try: dwruTxthc07m4bp3LsRSgOn = DDuAgkFnXqlc3YZMQHp1r[h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡵࡷࡶࡪࡧ࡭ࡪࡰࡪࡈࡦࡺࡡࠨଢ")][HaTI5u1f3SCxmMAkw(u"ࠩࡧࡥࡸ࡮ࡍࡢࡰ࡬ࡪࡪࡹࡴࡖࡴ࡯ࠫଣ")]
	except: pass
	try: TgDPO7KFUbRSJEH2npwcWo1lqGB9 = M90jQzoE6cHTqiFkGr5CS[cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡷࡹࡸࡥࡢ࡯࡬ࡲ࡬ࡊࡡࡵࡣࠪତ")][otNfFapeEnO(u"ࠫࡩࡧࡳࡩࡏࡤࡲ࡮࡬ࡥࡴࡶࡘࡶࡱ࠭ଥ")]
	except: pass
	try: FEn6z98gortB = DDuAgkFnXqlc3YZMQHp1r[zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬଦ")][cjVhOCwybeRo7UWg92(u"࠭ࡦࡰࡴࡰࡥࡹࡹࠧଧ")]
	except: pass
	try: uhdYzXO0JnmFEyo5fsjWgKNRI = M90jQzoE6cHTqiFkGr5CS[pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧନ")][XB4CjMkPFzhAHiI3q(u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ଩")]
	except: pass
	try: HIJeDO4CYXwoguaL8MA0tkVPBR = DDuAgkFnXqlc3YZMQHp1r[GISOTJh20W(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩପ")][zQGaM7ctZCN(u"ࠪࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠬଫ")]
	except: pass
	try: u1unQC8RcpxB2dqgweEWINlP5Yy = M90jQzoE6cHTqiFkGr5CS[JACnOz297UuDK5HpPkc1LF(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫବ")][KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧଭ")]
	except: pass
	if not bGIVq1CQTjmosZg:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡇࡆࡖࠪମ"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠻ࡺࡨࠨଯ"))
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if not any([yyeMu9iam5IS8QJs7BgwT6oXE,qcLzPF8pkuM,dwruTxthc07m4bp3LsRSgOn,TgDPO7KFUbRSJEH2npwcWo1lqGB9,FEn6z98gortB,uhdYzXO0JnmFEyo5fsjWgKNRI,HIJeDO4CYXwoguaL8MA0tkVPBR,u1unQC8RcpxB2dqgweEWINlP5Yy]):
		sdGflAoZBxPURVuF = Zy2l0g8QU5vqefaTrsw.findall(O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫର"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		gEqOeRhimXy7rDZ4IH0 = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ଱"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		DDk4RTUJBYFjgx = Zy2l0g8QU5vqefaTrsw.findall(cjVhOCwybeRo7UWg92(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩଲ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		FhejcUfS9X0RHdbt4Zv1LKqkaMug = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଳ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		kkrv8pitOeIZVhJ2fT,uLGUEXer9WYJpT6P38wjCOshAbvqyf,NCJ5zjED36erSb8Qvh = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		try: kkrv8pitOeIZVhJ2fT = DDuAgkFnXqlc3YZMQHp1r[XB4CjMkPFzhAHiI3q(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩ଴")][E6xdOMpqISHZCn(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫଵ")][s97s2k0LJgl(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨଶ")][I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡶ࡬ࡸࡱ࡫ࠧଷ")][yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡵࡹࡳࡹࠧସ")][ZVNvqy4iF1a9X][EcjO3giln2kQTdBY0XLAG(u"ࠪࡸࡪࡾࡴࠨହ")]
		except:
			try: kkrv8pitOeIZVhJ2fT = M90jQzoE6cHTqiFkGr5CS[rC5tnFDlQcRGA2(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨ଺")][pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ଻")][GISOTJh20W(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸ଼ࠧ")][s97s2k0LJgl(u"ࠧࡵ࡫ࡷࡰࡪ࠭ଽ")][E6xdOMpqISHZCn(u"ࠨࡴࡸࡲࡸ࠭ା")][ZVNvqy4iF1a9X][KA26GucUHOwXL(u"ࠩࡷࡩࡽࡺࠧି")]
			except: pass
		try: uLGUEXer9WYJpT6P38wjCOshAbvqyf = DDuAgkFnXqlc3YZMQHp1r[GISOTJh20W(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧୀ")][KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡪࡸࡲࡰࡴࡖࡧࡷ࡫ࡥ࡯ࠩୁ")][JACnOz297UuDK5HpPkc1LF(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡊࡩࡢ࡮ࡲ࡫ࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭ୂ")][xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡤࡪࡣ࡯ࡳ࡬ࡓࡥࡴࡵࡤ࡫ࡪࡹࠧୃ")][ZVNvqy4iF1a9X][I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡳࡷࡱࡷࠬୄ")][ZVNvqy4iF1a9X][s97s2k0LJgl(u"ࠨࡶࡨࡼࡹ࠭୅")]
		except:
			try: uLGUEXer9WYJpT6P38wjCOshAbvqyf = M90jQzoE6cHTqiFkGr5CS[cjVhOCwybeRo7UWg92(u"ࠩࡳࡰࡦࡿࡡࡣ࡫࡯࡭ࡹࡿࡓࡵࡣࡷࡹࡸ࠭୆")][yylSaxCLfkte(u"ࠪࡩࡷࡸ࡯ࡳࡕࡦࡶࡪ࡫࡮ࠨେ")][ZP1LyUCS3pIBu(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡉ࡯ࡡ࡭ࡱࡪࡖࡪࡴࡤࡦࡴࡨࡶࠬୈ")][otNfFapeEnO(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡒ࡫ࡳࡴࡣࡪࡩࡸ࠭୉")][ZVNvqy4iF1a9X][od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡲࡶࡰࡶࠫ୊")][ZVNvqy4iF1a9X][NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡵࡧࡻࡸࠬୋ")]
			except: pass
		try: NCJ5zjED36erSb8Qvh = DDuAgkFnXqlc3YZMQHp1r[zQGaM7ctZCN(u"ࠨࡲ࡯ࡥࡾࡧࡢࡪ࡮࡬ࡸࡾ࡙ࡴࡢࡶࡸࡷࠬୌ")][KA26GucUHOwXL(u"ࠩࡵࡩࡦࡹ࡯࡯୍ࠩ")]
		except:
			try: NCJ5zjED36erSb8Qvh = M90jQzoE6cHTqiFkGr5CS[JACnOz297UuDK5HpPkc1LF(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧ୎")][ZP1LyUCS3pIBu(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫ୏")]
			except: pass
		ap8WywuCYTj7embPsUdF3DN0ozJ45H = CJlTSEpZsWb0QHg5w
		HcaqinAUGgmR5Do1flth9 = Dj62UpP5MrbTkJqhRa+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮࠦ࠮࠯ࠢฦ์ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣ࠲࠳ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢํัฯอฬࠡึํล๋ࠥอะัࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢ฽๎ึࠦโศัิࠤศ์๋ࠠึ฽่ࠥอไโ์า๎ํࠦวๅฤ้ࠫ୐")+oOQaRxBXyJ5jVnZ
		if sdGflAoZBxPURVuF or gEqOeRhimXy7rDZ4IH0 or DDk4RTUJBYFjgx or FhejcUfS9X0RHdbt4Zv1LKqkaMug or kkrv8pitOeIZVhJ2fT or uLGUEXer9WYJpT6P38wjCOshAbvqyf or NCJ5zjED36erSb8Qvh:
			if   sdGflAoZBxPURVuF: LLyhViKbxMntl5JSk = sdGflAoZBxPURVuF[ZVNvqy4iF1a9X]
			elif gEqOeRhimXy7rDZ4IH0: LLyhViKbxMntl5JSk = gEqOeRhimXy7rDZ4IH0[ZVNvqy4iF1a9X]
			elif DDk4RTUJBYFjgx: LLyhViKbxMntl5JSk = DDk4RTUJBYFjgx[ZVNvqy4iF1a9X]
			elif FhejcUfS9X0RHdbt4Zv1LKqkaMug: LLyhViKbxMntl5JSk = FhejcUfS9X0RHdbt4Zv1LKqkaMug[ZVNvqy4iF1a9X]
			elif kkrv8pitOeIZVhJ2fT: LLyhViKbxMntl5JSk = kkrv8pitOeIZVhJ2fT
			elif uLGUEXer9WYJpT6P38wjCOshAbvqyf: LLyhViKbxMntl5JSk = uLGUEXer9WYJpT6P38wjCOshAbvqyf
			elif NCJ5zjED36erSb8Qvh: LLyhViKbxMntl5JSk = NCJ5zjED36erSb8Qvh
			ap8WywuCYTj7embPsUdF3DN0ozJ45H = LLyhViKbxMntl5JSk.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			HcaqinAUGgmR5Do1flth9 += KA26GucUHOwXL(u"࠭࡜࡯࡞ࡱࠫ୑")+Ym6q5M4TocDaA013RjFQ+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧาีส่ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ୒")+oOQaRxBXyJ5jVnZ+rJ9cgWz4FU+ap8WywuCYTj7embPsUdF3DN0ozJ45H
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣ์ฬ๊ๅษำ่ะࠬ୓"),HcaqinAUGgmR5Do1flth9)
		if ap8WywuCYTj7embPsUdF3DN0ozJ45H: ap8WywuCYTj7embPsUdF3DN0ozJ45H = ZP1LyUCS3pIBu(u"ࠩ࠽ࠤࠬ୔")+ap8WywuCYTj7embPsUdF3DN0ozJ45H
		return KA26GucUHOwXL(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ୕")+ap8WywuCYTj7embPsUdF3DN0ozJ45H,[],[]
	fjunHJhodrm,zPay3UDRfFo8wkrpxLM4Bh,zbL6oNBjwl0c = [],[],[]
	H1ZOpNG7Xji5 = [yyeMu9iam5IS8QJs7BgwT6oXE,qcLzPF8pkuM]
	AuGwIHfoC8cDTreqRv = [dwruTxthc07m4bp3LsRSgOn,TgDPO7KFUbRSJEH2npwcWo1lqGB9]
	DIA54R1lwcTz7OZPjX6a,ByNJ7rtlhZqQWKAI15SMOmE02egzYU = [],[]
	for lJjZIhPaVQqAE5SMo in FEn6z98gortB+uhdYzXO0JnmFEyo5fsjWgKNRI:
		if lJjZIhPaVQqAE5SMo[rC5tnFDlQcRGA2(u"ࠫ࡮ࡺࡡࡨࠩୖ")] not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(lJjZIhPaVQqAE5SMo[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ࡯ࡴࡢࡩࠪୗ")])
			ByNJ7rtlhZqQWKAI15SMOmE02egzYU.append(lJjZIhPaVQqAE5SMo)
	DIA54R1lwcTz7OZPjX6a,LoG3flOSi6XJ87sZrxVDajK = [],[]
	for lJjZIhPaVQqAE5SMo in HIJeDO4CYXwoguaL8MA0tkVPBR+u1unQC8RcpxB2dqgweEWINlP5Yy:
		if lJjZIhPaVQqAE5SMo[rC5tnFDlQcRGA2(u"࠭ࡩࡵࡣࡪࠫ୘")] not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(lJjZIhPaVQqAE5SMo[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡪࡶࡤ࡫ࠬ୙")])
			LoG3flOSi6XJ87sZrxVDajK.append(lJjZIhPaVQqAE5SMo)
	for dict in ByNJ7rtlhZqQWKAI15SMOmE02egzYU+LoG3flOSi6XJ87sZrxVDajK:
		if EcjO3giln2kQTdBY0XLAG(u"ࠨ࡫ࡷࡥ࡬࠭୚") in list(dict.keys()): dict[yylSaxCLfkte(u"ࠩ࡬ࡸࡦ࡭ࠧ୛")] = str(dict[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ࡭ࡹࡧࡧࠨଡ଼")])
		if TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫ࡫ࡶࡳࠨଢ଼") in list(dict.keys()): dict[zQGaM7ctZCN(u"ࠬ࡬ࡰࡴࠩ୞")] = str(dict[mi2ZJXCDzITuyev6gfn(u"࠭ࡦࡱࡵࠪୟ")])
		if XB4CjMkPFzhAHiI3q(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩୠ") in list(dict.keys()): dict[otNfFapeEnO(u"ࠨࡶࡼࡴࡪ࠭ୡ")] = dict[yylSaxCLfkte(u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫୢ")]
		if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬୣ") in list(dict.keys()): dict[h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ୤")] = str(dict[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡧࡵࡥ࡫ࡲࡗࡦࡳࡰ࡭ࡧࡕࡥࡹ࡫ࠧ୥")])
		if JACnOz297UuDK5HpPkc1LF(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭୦") in list(dict.keys()): dict[o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ୧")] = str(dict[XB4CjMkPFzhAHiI3q(u"ࠨࡣࡸࡨ࡮ࡵࡃࡩࡣࡱࡲࡪࡲࡳࠨ୨")])
		if EcjO3giln2kQTdBY0XLAG(u"ࠩࡺ࡭ࡩࡺࡨࠨ୩") in list(dict.keys()): dict[JACnOz297UuDK5HpPkc1LF(u"ࠪࡷ࡮ࢀࡥࠨ୪")] = str(dict[O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡼ࡯ࡤࡵࡪࠪ୫")])+zQGaM7ctZCN(u"ࠬࡾࠧ୬")+str(dict[yylSaxCLfkte(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭୭")])
		if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ୮") in list(dict.keys()): dict[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡫ࡱ࡭ࡹ࠭୯")] = dict[yylSaxCLfkte(u"ࠩ࡬ࡲ࡮ࡺࡒࡢࡰࡪࡩࠬ୰")][HaTI5u1f3SCxmMAkw(u"ࠪࡷࡹࡧࡲࡵࠩୱ")]+otNfFapeEnO(u"ࠫ࠲࠭୲")+dict[GISOTJh20W(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨ୳")][cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡥ࡯ࡦࠪ୴")]
		if KA26GucUHOwXL(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫ୵") in list(dict.keys()): dict[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡫ࡱࡨࡪࡾࠧ୶")] = dict[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࡬ࡲࡩ࡫ࡸࡓࡣࡱ࡫ࡪ࠭୷")][cjVhOCwybeRo7UWg92(u"ࠪࡷࡹࡧࡲࡵࠩ୸")]+ZP1LyUCS3pIBu(u"ࠫ࠲࠭୹")+dict[s97s2k0LJgl(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩ୺")][yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡥ࡯ࡦࠪ୻")]
		if otNfFapeEnO(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨ୼") in list(dict.keys()): dict[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ୽")] = dict[TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡤࡺࡪࡸࡡࡨࡧࡅ࡭ࡹࡸࡡࡵࡧࠪ୾")]
		if s97s2k0LJgl(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ୿") in list(dict.keys()) and int(dict[pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ஀")])>cbmeD4WNZfAowxT2JdUMtV(u"࠷࠱࠲࠴࠵࠶࠸࠹࠳෕"): del dict[cjVhOCwybeRo7UWg92(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭஁")]
		if h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨஂ") in list(dict.keys()):
			jIeRlNqToXnPzUybp95mHGr = dict[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࡆ࡭ࡵ࡮ࡥࡳࠩஃ")].split(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࠨࠪ஄"))
			for jglfWFcvo1mAdH9yeROS7XKNxu in jIeRlNqToXnPzUybp95mHGr:
				key,value = jglfWFcvo1mAdH9yeROS7XKNxu.split(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡀࠫஅ"),s97s2k0LJgl(u"࠱ූ"))
				dict[key] = sWzgdLCjSVwaMuhFkNf1Uop(value)
		if yylSaxCLfkte(u"ࠪࡹࡷࡲࠧஆ") in list(dict.keys()): dict[Olh7n0zfV4(u"ࠫࡺࡸ࡬ࠨஇ")] = sWzgdLCjSVwaMuhFkNf1Uop(dict[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡻࡲ࡭ࠩஈ")])
		fjunHJhodrm.append(dict)
	EEhqPFWQjayH = CJlTSEpZsWb0QHg5w
	Mw5C10qkZePBslVhEj8K = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"࠭ࠢࠩ࠱ࡶ࠳ࡵࡲࡡࡺࡧࡵ࠳ࡡࡽࠪࡀ࠱ࡳࡰࡦࡿࡥࡳࡡ࡬ࡥࡸ࠴ࡶࡧ࡮ࡶࡩࡹ࠵ࡥ࡯ࡡ࠱࠲࠴ࡨࡡࡴࡧ࠱࡮ࡸ࠯ࠢࠨஉ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if Mw5C10qkZePBslVhEj8K:
		Mw5C10qkZePBslVhEj8K = Ew2zQ8u7Ss.SITESURLS[JACnOz297UuDK5HpPkc1LF(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨஊ")][ZVNvqy4iF1a9X]+Mw5C10qkZePBslVhEj8K[ZVNvqy4iF1a9X]
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,otNfFapeEnO(u"ࠨࡉࡈࡘࠬ஋"),Mw5C10qkZePBslVhEj8K,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠸ࡵࡪࠪ஌"))
		EEhqPFWQjayH = bqIufCQz2OWExjilm.content
	if EEhqPFWQjayH:
		if zQGaM7ctZCN(u"ࠪࡷࡵࡃࡳࡪࡩࠪ஍") in TvbSZDRi84I+s4ICZWhKngMSmDlJ9HPiXpojxG3:
			import youtube_signature.cipher as Qs7TUWPevL6qRHAa1w0Sz29O5,youtube_signature.json_script_engine as RepdN1zQEGiYtJ
			jIeRlNqToXnPzUybp95mHGr = iir2NWqhn7pbgSfUI3QLOx0ywCa9.jIeRlNqToXnPzUybp95mHGr.Cipher()
			jIeRlNqToXnPzUybp95mHGr._object_cache = {}
			J4LM8Bzq0HKd = jIeRlNqToXnPzUybp95mHGr._load_javascript(EEhqPFWQjayH)
			OXTp9JyoHg4xdwt83zNGC = oE7iT3HI5VDdmY4kPOjr(HaTI5u1f3SCxmMAkw(u"ࠫࡸࡺࡲࠨஎ"),str(J4LM8Bzq0HKd))
			uVF8SnWU1xzlhOifb6Zq = iir2NWqhn7pbgSfUI3QLOx0ywCa9.a5xPm1vBM6Yjzfo4LUdG9.JsonScriptEngine(OXTp9JyoHg4xdwt83zNGC)
		ewA42hba3lYcOEL7rxvXUDt5G = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࡷ࠭ࠧࠨࠪࡂࡼ࠮ࠐࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࡠ࠳࡭ࡥࡵ࡞ࠫࠦࡳࠨ࡜ࠪ࡞ࠬࠪࠫࡢࠨࡣ࠿ࡿࠎࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌࡦࡂ࡙ࡴࡳ࡫ࡱ࡫ࡡ࠴ࡦࡳࡱࡰࡇ࡭ࡧࡲࡄࡱࡧࡩࡡ࠮࠱࠲࠲࡟࠭ࢁࠐࠉࠊࠋࠌࠍ࠭ࡅࡐ࠽ࡵࡷࡶࡤ࡯ࡤࡹࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࠯࡟࠮࠭ࠫࠬ࡜ࠩࡤࡀࠦࡳࡴࠢ࡝࡝࡟࠯࠭ࡅࡐ࠾ࡵࡷࡶࡤ࡯ࡤࡹࠫ࡟ࡡࠏࠏࠉࠊࠋࠬࠎࠎࠏࠉࠊࠪࡂ࠾ࠏࠏࠉࠊࠋࠌ࠰ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࡠࠦࡠ࠯ࡡ࠮ࡡ࡝ࠫࠬࡃ࠱ࡩ࠽ࡢ࡞࠱ࠎࠎࠏࠉࠊࠋࠫࡃ࠿ࠐࠉࠊࠋࠌࠍࠎ࡭ࡥࡵ࡞ࠫࡦࡡ࠯ࡼࠋࠋࠌࠍࠎࠏࠉ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡣࠩࡣࠫ࡝࡝ࡥࡠࡢࡢࡼ࡝ࡾࡱࡹࡱࡲࠊࠊࠋࠌࠍࠎ࠯࡜ࠪࠨࠩࡠ࠭ࡩ࠽ࡽࠌࠌࠍࠎࠏ࡜ࡣࠪࡂࡔࡁࡼࡡࡳࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭ࠬࡁࠏࠏࠉࠊࠫࠫࡃࡕࡂ࡮ࡧࡷࡱࡧࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࡡࠧࡡ࠰࠯ࠨࡀ࠼࡟࡟࠭ࡅࡐ࠽࡫ࡧࡼࡃࡢࡤࠬࠫ࡟ࡡ࠮ࡅ࡜ࠩ࡝ࡤ࠱ࡿࡇ࡛࠭࡟࡟࠭ࠏࠏࠉࠊࠪࡂࠬࡻࡧࡲࠪ࠮࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡥࠤ࡞࠭࡟࠲ࡸ࡫ࡴ࡝ࠪࠫࡃ࠿ࠨ࡮ࠬࠤࡿ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡟ࠥ࡟࠮࠭ࡡ࠲ࠨࡀࡒࡀࡺࡦࡸࠩ࡝ࠫࠬࠫࠬ࠭ஏ"),EEhqPFWQjayH)
		if ewA42hba3lYcOEL7rxvXUDt5G:
			ewA42hba3lYcOEL7rxvXUDt5G = Zy2l0g8QU5vqefaTrsw.findall(ewA42hba3lYcOEL7rxvXUDt5G[ZVNvqy4iF1a9X][cbmeD4WNZfAowxT2JdUMtV(u"࠳෗")]+JACnOz297UuDK5HpPkc1LF(u"࠭࠽࡝࡝ࠫ࠲࠯ࡅࠩ࡝࡟ࠪஐ"),EEhqPFWQjayH,Zy2l0g8QU5vqefaTrsw.DOTALL)[ZVNvqy4iF1a9X]
			WnKa95pgYMB6GEQJCoiUSz = EEhqPFWQjayH.find(ewA42hba3lYcOEL7rxvXUDt5G+VVvcQpCU3OM09n(u"ࠧ࠾ࡨࡸࡲࡨࡺࡩࡰࡰࠫࠫ஑"))
			uIKWrswn6SyUGjHgDfiBVZo = EEhqPFWQjayH.find(HaTI5u1f3SCxmMAkw(u"ࠨࡿ࠾ࠫஒ"), WnKa95pgYMB6GEQJCoiUSz)
			tmD6fl5bzoiHaesdWv8pRcLqMKhTU = EEhqPFWQjayH[WnKa95pgYMB6GEQJCoiUSz:uIKWrswn6SyUGjHgDfiBVZo]+cbmeD4WNZfAowxT2JdUMtV(u"ࠩࢀࠫஓ")
			XJYm70kuDQwpT8O9eB5U6Ht3Kyl = Zy2l0g8QU5vqefaTrsw.findall(cjVhOCwybeRo7UWg92(u"ࠪࡺࡦࡸࠠ࠯ࠬࡂࡁ࠭࠴ࠪࡀࠫ࡟࠲ࠬஔ"),tmD6fl5bzoiHaesdWv8pRcLqMKhTU,Zy2l0g8QU5vqefaTrsw.DOTALL)[ZVNvqy4iF1a9X]
			nWjEKc4GwmqAakId3CXzvFYMZ = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠫ࡮࡬࡜ࠩࡶࡼࡴࡪࡵࡦࠡ࠰࠭ࡃࡂࡃ࠽ࠣࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧࠦࡡ࠯ࡲࡦࡶࡸࡶࡳࠦࠧக")+XJYm70kuDQwpT8O9eB5U6Ht3Kyl+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡁࠧ஖"),tmD6fl5bzoiHaesdWv8pRcLqMKhTU,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if nWjEKc4GwmqAakId3CXzvFYMZ: tmD6fl5bzoiHaesdWv8pRcLqMKhTU = tmD6fl5bzoiHaesdWv8pRcLqMKhTU.replace(nWjEKc4GwmqAakId3CXzvFYMZ[ZVNvqy4iF1a9X],CJlTSEpZsWb0QHg5w)
			pCdY0reuORzNLFs4hXikwMxqKQfA = {}
			for dict in fjunHJhodrm:
				url = dict[EcjO3giln2kQTdBY0XLAG(u"࠭ࡵࡳ࡮ࠪ஗")]
				if EcjO3giln2kQTdBY0XLAG(u"ࠧࠧࡰࡀࠫ஘") in url:
					iomM2ZNv9tGE5L = url.split(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࠨࡱࡁࠬங"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe].split(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࠩࠫச"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
					if iomM2ZNv9tGE5L not in list(pCdY0reuORzNLFs4hXikwMxqKQfA.keys()): pCdY0reuORzNLFs4hXikwMxqKQfA[iomM2ZNv9tGE5L] = k7Y4iwed8cNbGHxfvK(tmD6fl5bzoiHaesdWv8pRcLqMKhTU,[ewA42hba3lYcOEL7rxvXUDt5G,iomM2ZNv9tGE5L])
					dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡹࡷࡲࠧ஛")] = url.replace(mi2ZJXCDzITuyev6gfn(u"ࠫࠫࡴ࠽ࠨஜ")+iomM2ZNv9tGE5L+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࠬࠧ஝"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࠦ࡯࠿ࠪஞ")+pCdY0reuORzNLFs4hXikwMxqKQfA[iomM2ZNv9tGE5L]+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࠧࠩட"))
	for dict in fjunHJhodrm:
		url = dict[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡷࡵࡰࠬ஠")]
		if Olh7n0zfV4(u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭஡") in url or url.count(TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡷ࡮࡭࠽ࠨ஢"))>P2Fgh6TCOWoaHjkqBcQnvRNXe:
			zPay3UDRfFo8wkrpxLM4Bh.append(dict)
		elif EEhqPFWQjayH and EcjO3giln2kQTdBY0XLAG(u"ࠫࡸ࠭ண") in list(dict.keys()) and yylSaxCLfkte(u"ࠬࡹࡰࠨத") in list(dict.keys()):
			Ks3AkeO2S9iyCWfcJQDPXHtqboZ4R = uVF8SnWU1xzlhOifb6Zq.execute(dict[h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡳࠨ஥")])
			if Ks3AkeO2S9iyCWfcJQDPXHtqboZ4R!=dict[Olh7n0zfV4(u"ࠧࡴࠩ஦")]:
				dict[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡷࡵࡰࠬ஧")] = url+cbmeD4WNZfAowxT2JdUMtV(u"ࠩࠩࠫந")+dict[s97s2k0LJgl(u"ࠪࡷࡵ࠭ன")]+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡂ࠭ப")+Ks3AkeO2S9iyCWfcJQDPXHtqboZ4R
				zPay3UDRfFo8wkrpxLM4Bh.append(dict)
	for dict in zPay3UDRfFo8wkrpxLM4Bh:
		B9dhnlXDQ3wt08O1PI,PlW0iHCgYy3XIoLNaEmKkcJO8R5vn,M5fgyt7UpQDLSoVB3ZWax41OhCiGl,UDkNdJxF4il0QoeG89sBR,aBe3JYArL0zbZSpKH65jGP7,ksDvwLIca3bHm = KA26GucUHOwXL(u"ࠬࡻ࡮࡬ࡰࡲࡻࡳ࠭஫"),EcjO3giln2kQTdBY0XLAG(u"࠭ࡵ࡯࡭ࡱࡳࡼࡴࠧ஬"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡶࡰ࡮ࡲࡴࡽ࡮ࠨ஭"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩம"),CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩ࠳ࠫய")
		try:
			SgWl2CIxRns4k6vj = dict[GISOTJh20W(u"ࠪࡸࡾࡶࡥࠨர")]
			SgWl2CIxRns4k6vj = SgWl2CIxRns4k6vj.replace(VVvcQpCU3OM09n(u"ࠫ࠰࠭ற"),CJlTSEpZsWb0QHg5w)
			items = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࠾࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧல"),SgWl2CIxRns4k6vj,Zy2l0g8QU5vqefaTrsw.DOTALL)
			UDkNdJxF4il0QoeG89sBR,B9dhnlXDQ3wt08O1PI,aBe3JYArL0zbZSpKH65jGP7 = items[ZVNvqy4iF1a9X]
			ZnUy6ciaeTBD4w = aBe3JYArL0zbZSpKH65jGP7.split(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࠬࠨள"))
			PlW0iHCgYy3XIoLNaEmKkcJO8R5vn = CJlTSEpZsWb0QHg5w
			for jglfWFcvo1mAdH9yeROS7XKNxu in ZnUy6ciaeTBD4w: PlW0iHCgYy3XIoLNaEmKkcJO8R5vn += jglfWFcvo1mAdH9yeROS7XKNxu.split(Olh7n0zfV4(u"ࠧ࠯ࠩழ"))[ZVNvqy4iF1a9X]+rC5tnFDlQcRGA2(u"ࠨ࠮ࠪவ")
			PlW0iHCgYy3XIoLNaEmKkcJO8R5vn = PlW0iHCgYy3XIoLNaEmKkcJO8R5vn.strip(Olh7n0zfV4(u"ࠩ࠯ࠫஶ"))
			if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫஷ") in list(dict.keys()): ksDvwLIca3bHm = str(int(dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬஸ")])//yylSaxCLfkte(u"࠳࠳࠶࠹ෘ"))+otNfFapeEnO(u"ࠬࡱࡢࡱࡵࠣࠤࠬஹ")
			else: ksDvwLIca3bHm = CJlTSEpZsWb0QHg5w
			if UDkNdJxF4il0QoeG89sBR==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡴࡦࡺࡷࠫ஺"): continue
			elif od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠭ࠩ஻") in SgWl2CIxRns4k6vj:
				UDkNdJxF4il0QoeG89sBR = GISOTJh20W(u"ࠨࡃ࠮࡚ࠬ஼")
				M5fgyt7UpQDLSoVB3ZWax41OhCiGl = B9dhnlXDQ3wt08O1PI+gCc52XVMGfAnOe+ksDvwLIca3bHm+dict[XB4CjMkPFzhAHiI3q(u"ࠩࡶ࡭ࡿ࡫ࠧ஽")].split(pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡼࠬா"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			elif UDkNdJxF4il0QoeG89sBR==h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡻ࡯ࡤࡦࡱࠪி"):
				UDkNdJxF4il0QoeG89sBR = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࡜ࡩࡥࡧࡲࠫீ")
				M5fgyt7UpQDLSoVB3ZWax41OhCiGl = ksDvwLIca3bHm+dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡳࡪࡼࡨࠫு")].split(mi2ZJXCDzITuyev6gfn(u"ࠧࡹࠩூ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]+gCc52XVMGfAnOe+dict[pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡨࡳࡷࠬ௃")]+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡩࡴࡸ࠭௄")+gCc52XVMGfAnOe+B9dhnlXDQ3wt08O1PI
			elif UDkNdJxF4il0QoeG89sBR==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡥࡺࡪࡩࡰࠩ௅"):
				UDkNdJxF4il0QoeG89sBR = zQGaM7ctZCN(u"ࠫࡆࡻࡤࡪࡱࠪெ")
				M5fgyt7UpQDLSoVB3ZWax41OhCiGl = ksDvwLIca3bHm+str(int(dict[zQGaM7ctZCN(u"ࠬࡧࡵࡥ࡫ࡲࡣࡸࡧ࡭ࡱ࡮ࡨࡣࡷࡧࡴࡦࠩே")])/KA26GucUHOwXL(u"࠴࠴࠵࠶ෙ"))+pz4WBwfyDdgk0m2aRr7SMv(u"࠭࡫ࡩࡼࠣࠤࠬை")+dict[cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲࡳࠨ௉")]+O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡥ࡫ࠫொ")+gCc52XVMGfAnOe+B9dhnlXDQ3wt08O1PI
		except:
			uErMFcVGBXUvtJZ90zCTPxn2YW = Do276qcOfXz8l.format_exc()
			if uErMFcVGBXUvtJZ90zCTPxn2YW!=KA26GucUHOwXL(u"ࠩࡑࡳࡳ࡫ࡔࡺࡲࡨ࠾ࠥࡔ࡯࡯ࡧ࡟ࡲࠬோ"): A8v6c2fL7egwWCF3YBqr4kXSRn.stderr.write(uErMFcVGBXUvtJZ90zCTPxn2YW)
		if yylSaxCLfkte(u"ࠪࡨࡺࡸ࠽ࠨௌ") in dict[o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡺࡸ࡬ࠨ்")]: XtbZnKed5mT2IYPy4MqvuOGURNwSc = round(yylSaxCLfkte(u"࠵࠴࠵ෛ")+float(dict[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡻࡲ࡭ࠩ௎")].split(GISOTJh20W(u"࠭ࡤࡶࡴࡀࠫ௏"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠵ේ"))[P2Fgh6TCOWoaHjkqBcQnvRNXe].split(EcjO3giln2kQTdBY0XLAG(u"ࠧࠧࠩௐ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]))
		elif HaTI5u1f3SCxmMAkw(u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ௑") in list(dict.keys()): XtbZnKed5mT2IYPy4MqvuOGURNwSc = round(mi2ZJXCDzITuyev6gfn(u"࠶࠮࠶ො")+float(dict[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡤࡴࡵࡸ࡯ࡹࡆࡸࡶࡦࡺࡩࡰࡰࡐࡷࠬ௒")])/o2FdrDBimMuOw97q6QpNW8S(u"࠱࠱࠲࠳ෝ"))
		else: XtbZnKed5mT2IYPy4MqvuOGURNwSc = otNfFapeEnO(u"ࠪ࠴ࠬ௓")
		if xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ௔") not in list(dict.keys()): ksDvwLIca3bHm = dict[cjVhOCwybeRo7UWg92(u"ࠬࡹࡩࡻࡧࠪ௕")].split(E6xdOMpqISHZCn(u"࠭ࡸࠨ௖"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		else: ksDvwLIca3bHm = str(int(dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨௗ")])//zQGaM7ctZCN(u"࠲࠲࠵࠸ෞ"))
		if yylSaxCLfkte(u"ࠨ࡫ࡱ࡭ࡹ࠭௘") not in list(dict.keys()): dict[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࡬ࡲ࡮ࡺࠧ௙")] = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪ࠴࠲࠶ࠧ௚")
		dict[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ௛")] = UDkNdJxF4il0QoeG89sBR+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡀࠠࠡࠩ௜")+M5fgyt7UpQDLSoVB3ZWax41OhCiGl+o2FdrDBimMuOw97q6QpNW8S(u"࠭ࠠࠡࠪࠪ௝")+PlW0iHCgYy3XIoLNaEmKkcJO8R5vn+VVvcQpCU3OM09n(u"ࠧ࠭ࠩ௞")+dict[yylSaxCLfkte(u"ࠨ࡫ࡷࡥ࡬࠭௟")]+ZP1LyUCS3pIBu(u"ࠩࠬࠫ௠")
		dict[E6xdOMpqISHZCn(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ௡")] = M5fgyt7UpQDLSoVB3ZWax41OhCiGl.split(gCc52XVMGfAnOe)[ZVNvqy4iF1a9X].split(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡰࡨࡰࡴࠩ௢"))[ZVNvqy4iF1a9X]
		dict[zQGaM7ctZCN(u"ࠬࡺࡹࡱࡧ࠵ࠫ௣")] = UDkNdJxF4il0QoeG89sBR
		dict[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ௤")] = B9dhnlXDQ3wt08O1PI
		dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡤࡱࡧࡩࡨࡹࠧ௥")] = aBe3JYArL0zbZSpKH65jGP7
		dict[mi2ZJXCDzITuyev6gfn(u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ௦")] = XtbZnKed5mT2IYPy4MqvuOGURNwSc
		dict[ZP1LyUCS3pIBu(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ௧")] = ksDvwLIca3bHm
		zbL6oNBjwl0c.append(dict)
	hK4jNd6HY8u5rM0xsJ,mDe0FHaroGhZ,mJ96prgZ5voKXATG1WCHYzBnL,ekiVjwWmU35Q9sFPNgo7x2uOKb0,ylVQfWr8ESRszZhavPgiNe9jMt = [],[],[],[],[]
	LUJTqrdWmwIEP3XCMO2NQ8ngzvesyR,A6fLg34UHzbjxeVJrEXkKcnh,RiFBb6I5WcA9f0MqdmZ,KwZjsfFPQMnxh0VHDEOv7,iAC2jzaDcFbI8OP053 = [],[],[],[],[]
	for pszSqO1VEYjNtTDlyK8uZMov in AuGwIHfoC8cDTreqRv:
		if not pszSqO1VEYjNtTDlyK8uZMov: continue
		dict = {}
		dict[cjVhOCwybeRo7UWg92(u"ࠪࡸࡾࡶࡥ࠳ࠩ௨")] = HaTI5u1f3SCxmMAkw(u"ࠫࡆ࠱ࡖࠨ௩")
		dict[TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ௪")] = zQGaM7ctZCN(u"࠭࡭ࡱࡦࠪ௫")
		dict[HaTI5u1f3SCxmMAkw(u"ࠧࡵ࡫ࡷࡰࡪ࠭௬")] = dict[otNfFapeEnO(u"ࠨࡶࡼࡴࡪ࠸ࠧ௭")]+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ࠽ࠤࠥ࠭௮")+dict[cjVhOCwybeRo7UWg92(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ௯")]+gCc52XVMGfAnOe+cbmeD4WNZfAowxT2JdUMtV(u"ࠫั๎ฯสࠢำ็๏ฯࠧ௰")
		dict[O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡻࡲ࡭ࠩ௱")] = pszSqO1VEYjNtTDlyK8uZMov
		dict[zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧ௲")] = cjVhOCwybeRo7UWg92(u"ࠧ࠱ࠩ௳")
		dict[KA26GucUHOwXL(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ௴")] = pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ࠴࠵࠶࠸࠲࠳࠵࠶࠷ࠬ௵")
		zbL6oNBjwl0c.append(dict)
	for KKvumXZbhn87VOEPI6BwrMCQ in H1ZOpNG7Xji5:
		if not KKvumXZbhn87VOEPI6BwrMCQ: continue
		UQVoHSPr1nuq4LWkyXMsd3tTvp8,LL0smM98Y57PVH = bUD0vMHIQhKW(T1QDsJlUtCGhn,KKvumXZbhn87VOEPI6BwrMCQ)
		Yqtc07h2L9Rx5zjW1sIFTSd = list(zip(UQVoHSPr1nuq4LWkyXMsd3tTvp8,LL0smM98Y57PVH))
		for title,ZgsbN5iSL48t2IhVFnmy in Yqtc07h2L9Rx5zjW1sIFTSd:
			dict = {}
			dict[JACnOz297UuDK5HpPkc1LF(u"ࠪࡸࡾࡶࡥ࠳ࠩ௶")] = VVvcQpCU3OM09n(u"ࠫࡆ࠱ࡖࠨ௷")
			dict[XB4CjMkPFzhAHiI3q(u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ௸")] = zQGaM7ctZCN(u"࠭࡭࠴ࡷ࠻ࠫ௹")
			dict[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡶࡴ࡯ࠫ௺")] = ZgsbN5iSL48t2IhVFnmy
			if s97s2k0LJgl(u"ࠨ࡭ࡥࡴࡸ࠭௻") in title: dict[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ௼")] = title.split(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࡯ࡧࡶࡳࠨ௽"))[ZVNvqy4iF1a9X].rsplit(gCc52XVMGfAnOe)[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
			else: dict[Olh7n0zfV4(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ௾")] = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬ࠷࠰ࠨ௿")
			if title.count(gCc52XVMGfAnOe)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				egYIsS2qROfpVW83kx = title.rsplit(gCc52XVMGfAnOe)[-D9yBM7wPFLz]
				if egYIsS2qROfpVW83kx.isdigit(): dict[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧఀ")] = egYIsS2qROfpVW83kx
				else: dict[ZP1LyUCS3pIBu(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨఁ")] = pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࠲࠳࠴࠵࠭ం")
			if title==JACnOz297UuDK5HpPkc1LF(u"ࠩ࠰࠵ࠬః"): dict[cjVhOCwybeRo7UWg92(u"ࠪࡸ࡮ࡺ࡬ࡦࠩఄ")] = dict[TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡹࡿࡰࡦ࠴ࠪఅ")]+mi2ZJXCDzITuyev6gfn(u"ࠬࡀࠠࠡࠩఆ")+dict[o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨఇ")]+gCc52XVMGfAnOe+TDpFsQXHze2q30uYtGPfEIm8(u"ࠧอ๊าอࠥึใ๋หࠪఈ")
			else: dict[ZP1LyUCS3pIBu(u"ࠨࡶ࡬ࡸࡱ࡫ࠧఉ")] = dict[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡷࡽࡵ࡫࠲ࠨఊ")]+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪ࠾ࠥࠦࠧఋ")+dict[h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭ఌ")]+gCc52XVMGfAnOe+dict[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭఍")]+o2FdrDBimMuOw97q6QpNW8S(u"࠭࡫ࡣࡲࡶࠤࠥ࠭ఎ")+dict[E6xdOMpqISHZCn(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨఏ")]
			zbL6oNBjwl0c.append(dict)
	zbL6oNBjwl0c = sorted(zbL6oNBjwl0c,reverse=w2qb6lf5EM,key=lambda key: int(key[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩఐ")]))
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭఑")],[CJlTSEpZsWb0QHg5w]
	try: HHo1hysJVFgp8uNrm7QL = DDuAgkFnXqlc3YZMQHp1r[ZP1LyUCS3pIBu(u"ࠪࡧࡦࡶࡴࡪࡱࡱࡷࠬఒ")][TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡵࡲࡡࡺࡧࡵࡇࡦࡶࡴࡪࡱࡱࡷ࡙ࡸࡡࡤ࡭࡯࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨఓ")][rC5tnFDlQcRGA2(u"ࠬࡩࡡࡱࡶ࡬ࡳࡳ࡚ࡲࡢࡥ࡮ࡷࠬఔ")]
	except: HHo1hysJVFgp8uNrm7QL = []
	try: JdzfxiKItrjsgylv = DDuAgkFnXqlc3YZMQHp1r[h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡣࡢࡲࡷ࡭ࡴࡴࡳࠨక")][XB4CjMkPFzhAHiI3q(u"ࠧࡱ࡮ࡤࡽࡪࡸࡃࡢࡲࡷ࡭ࡴࡴࡳࡕࡴࡤࡧࡰࡲࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫఖ")][s97s2k0LJgl(u"ࠨࡥࡤࡴࡹ࡯࡯࡯ࡖࡵࡥࡨࡱࡳࠨగ")]
	except: JdzfxiKItrjsgylv = []
	for bbVJR0KXyI7nuBDYNhjHpw8a5CvMt in HHo1hysJVFgp8uNrm7QL+JdzfxiKItrjsgylv:
		try:
			ZgsbN5iSL48t2IhVFnmy = bbVJR0KXyI7nuBDYNhjHpw8a5CvMt[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡥࡥࡸ࡫ࡕࡳ࡮ࠪఘ")]
			try: title = bbVJR0KXyI7nuBDYNhjHpw8a5CvMt[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡲࡦࡳࡥࠨఙ")][KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨచ")]
			except: title = bbVJR0KXyI7nuBDYNhjHpw8a5CvMt[rC5tnFDlQcRGA2(u"ࠬࡴࡡ࡮ࡧࠪఛ")][XB4CjMkPFzhAHiI3q(u"࠭ࡲࡶࡰࡶࠫజ")][ZVNvqy4iF1a9X][VVvcQpCU3OM09n(u"ࠧࡵࡧࡻࡸࠬఝ")]
		except: continue
		if title not in Uz8mMbZifCyvkLnct:
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			Uz8mMbZifCyvkLnct.append(title)
	if len(Uz8mMbZifCyvkLnct)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
		CrqTamtPFuU = T4TK17YsEfZJ(VVvcQpCU3OM09n(u"ࠨษัฮึࠦวๅฬิะ๊ฯࠠࠩࠩఞ")+str(len(Uz8mMbZifCyvkLnct))+GISOTJh20W(u"้้ࠩࠣ็ࠩࠨట"),Uz8mMbZifCyvkLnct)
		if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨఠ"),[],[]
		elif CrqTamtPFuU!=ZVNvqy4iF1a9X:
			ZgsbN5iSL48t2IhVFnmy = MNXzjK3vV7D[CrqTamtPFuU]+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࠫ࠭డ")
			l2ScBqrQfENTW50wi34FRh = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"ࠬࠬࠨࡧ࡯ࡷࡁ࠳࠰࠿ࠪࠨࠪఢ"),ZgsbN5iSL48t2IhVFnmy)
			if l2ScBqrQfENTW50wi34FRh: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(l2ScBqrQfENTW50wi34FRh[ZVNvqy4iF1a9X],od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡦ࡮ࡶࡀࡺࡹࡺࠧణ"))
			else: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+yylSaxCLfkte(u"ࠧࡧ࡯ࡷࡁࡻࡺࡴࠨత")
			eqVPIOhpxtFy = ZgsbN5iSL48t2IhVFnmy.strip(JACnOz297UuDK5HpPkc1LF(u"ࠨࠨࠪథ"))
	XOxU2FnTMeYI = []
	for dict in zbL6oNBjwl0c:
		if dict[KA26GucUHOwXL(u"ࠩࡷࡽࡵ࡫࠲ࠨద")]==TDpFsQXHze2q30uYtGPfEIm8(u"࡚ࠪ࡮ࡪࡥࡰࠩధ"):
			hK4jNd6HY8u5rM0xsJ.append(dict[rC5tnFDlQcRGA2(u"ࠫࡹ࡯ࡴ࡭ࡧࠪన")])
			LUJTqrdWmwIEP3XCMO2NQ8ngzvesyR.append(dict)
		elif dict[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡺࡹࡱࡧ࠵ࠫ఩")]==cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡁࡶࡦ࡬ࡳࠬప"):
			mDe0FHaroGhZ.append(dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡵ࡫ࡷࡰࡪ࠭ఫ")])
			A6fLg34UHzbjxeVJrEXkKcnh.append(dict)
		elif dict[cjVhOCwybeRo7UWg92(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪబ")]==XB4CjMkPFzhAHiI3q(u"ࠩࡰࡴࡩ࠭భ"):
			title = dict[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡸ࡮ࡺ࡬ࡦࠩమ")].replace(XB4CjMkPFzhAHiI3q(u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫయ"),CJlTSEpZsWb0QHg5w)
			if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ర") not in list(dict.keys()): ksDvwLIca3bHm = s97s2k0LJgl(u"࠭࠰ࠨఱ")
			else: ksDvwLIca3bHm = dict[zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨల")]
			XOxU2FnTMeYI.append([dict,{},title,ksDvwLIca3bHm])
		else:
			title = dict[JACnOz297UuDK5HpPkc1LF(u"ࠨࡶ࡬ࡸࡱ࡫ࠧళ")].replace(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡄ࠯࡛ࡀࠠࠡࠩఴ"),CJlTSEpZsWb0QHg5w)
			if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫవ") not in list(dict.keys()): ksDvwLIca3bHm = VVvcQpCU3OM09n(u"ࠫ࠵࠭శ")
			else: ksDvwLIca3bHm = dict[zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ష")]
			XOxU2FnTMeYI.append([dict,{},title,ksDvwLIca3bHm])
			mJ96prgZ5voKXATG1WCHYzBnL.append(title)
			RiFBb6I5WcA9f0MqdmZ.append(dict)
		mXWerjsyuJi237 = w2qb6lf5EM
		if ZP1LyUCS3pIBu(u"࠭ࡣࡰࡦࡨࡧࡸ࠭స") in list(dict.keys()):
			if Olh7n0zfV4(u"ࠧࡢࡸ࠳ࠫహ") in dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡥࡲࡨࡪࡩࡳࠨ఺")]: mXWerjsyuJi237 = VJZIMkUN5siqB21Pf
			elif K9MoWfyg6w2EHIki4lLtFSzpxQTmRX<od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠳࠻ෟ") and ZP1LyUCS3pIBu(u"ࠩࡤࡺࡨ࠭఻") not in dict[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡧࡴࡪࡥࡤࡵ఼ࠪ")] and TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡲࡶ࠴ࡢࠩఽ") not in dict[s97s2k0LJgl(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬా")]: mXWerjsyuJi237 = VJZIMkUN5siqB21Pf
		if mXWerjsyuJi237 and dict[E6xdOMpqISHZCn(u"࠭ࡴࡺࡲࡨ࠶ࠬి")]==XB4CjMkPFzhAHiI3q(u"ࠧࡗ࡫ࡧࡩࡴ࠭ీ") and dict[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ࡫ࡱ࡭ࡹ࠭ు")]!=NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࠳࠱࠵࠭ూ"):
			ylVQfWr8ESRszZhavPgiNe9jMt.append(dict[KA26GucUHOwXL(u"ࠪࡸ࡮ࡺ࡬ࡦࠩృ")])
			iAC2jzaDcFbI8OP053.append(dict)
		elif mXWerjsyuJi237 and dict[O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡹࡿࡰࡦ࠴ࠪౄ")]==JACnOz297UuDK5HpPkc1LF(u"ࠬࡇࡵࡥ࡫ࡲࠫ౅") and dict[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡩ࡯࡫ࡷࠫె")]!=pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࠱࠯࠳ࠫే"):
			ekiVjwWmU35Q9sFPNgo7x2uOKb0.append(dict[HaTI5u1f3SCxmMAkw(u"ࠨࡶ࡬ࡸࡱ࡫ࠧై")])
			KwZjsfFPQMnxh0VHDEOv7.append(dict)
	for lOYbqfwHZRSKD13U9uP in KwZjsfFPQMnxh0VHDEOv7:
		XEuyjaf7DvJC = lOYbqfwHZRSKD13U9uP[cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ౉")]
		for qbkKwv0MA7PuWdh4syoEJ1SFt in iAC2jzaDcFbI8OP053:
			j3RkmYiDNa6LflJuqQ5Wxne = qbkKwv0MA7PuWdh4syoEJ1SFt[O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫొ")]
			ksDvwLIca3bHm = int(j3RkmYiDNa6LflJuqQ5Wxne)+int(XEuyjaf7DvJC)
			title = qbkKwv0MA7PuWdh4syoEJ1SFt[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡹ࡯ࡴ࡭ࡧࠪో")].replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࠦࠧౌ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࡭ࡱࡦࠣࠤ్ࠬ"))
			title = title.replace(qbkKwv0MA7PuWdh4syoEJ1SFt[EcjO3giln2kQTdBY0XLAG(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ౎")]+gCc52XVMGfAnOe,CJlTSEpZsWb0QHg5w)
			title = title.replace(j3RkmYiDNa6LflJuqQ5Wxne+ZP1LyUCS3pIBu(u"ࠨ࡭ࡥࡴࡸ࠭౏"),str(ksDvwLIca3bHm)+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩ࡮ࡦࡵࡹࠧ౐"))
			title = title+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࠬࠬ౑")+lOYbqfwHZRSKD13U9uP[E6xdOMpqISHZCn(u"ࠫࡹ࡯ࡴ࡭ࡧࠪ౒")].split(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࠮ࠧ౓"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			XOxU2FnTMeYI.append([qbkKwv0MA7PuWdh4syoEJ1SFt,lOYbqfwHZRSKD13U9uP,title,ksDvwLIca3bHm])
	bTxVLweoWPMu = []
	for stream in XOxU2FnTMeYI:
		qbkKwv0MA7PuWdh4syoEJ1SFt,lOYbqfwHZRSKD13U9uP,title,ksDvwLIca3bHm = stream
		beoJENLAUaR2XcwIBvZVfjk0 = title[:D9yBM7wPFLz]
		if mi2ZJXCDzITuyev6gfn(u"࠭ะไ์ฬࠫ౔") in title: beoJENLAUaR2XcwIBvZVfjk0 += ZP1LyUCS3pIBu(u"ౕࠧࠬࠩ")
		bTxVLweoWPMu.append([stream,beoJENLAUaR2XcwIBvZVfjk0,int(ksDvwLIca3bHm)])
	euPzIYQ8TVJNDK = VJZIMkUN5siqB21Pf
	B0N6n8dm32SgKTOLZzlba4E = FWK9ZMPpVauYrEH2v(T1QDsJlUtCGhn,bTxVLweoWPMu)
	if B0N6n8dm32SgKTOLZzlba4E:
		OXwJMTd9n3b,EdFqDARbVOkp9gaC,title,ksDvwLIca3bHm = B0N6n8dm32SgKTOLZzlba4E[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X]
		up7RfMNd1X = OXwJMTd9n3b[yylSaxCLfkte(u"ࠨࡷࡵࡰౖࠬ")]
		if E6xdOMpqISHZCn(u"ࠩࡰࡴࡩ࠭౗") in title and up7RfMNd1X!=pszSqO1VEYjNtTDlyK8uZMov: euPzIYQ8TVJNDK = w2qb6lf5EM
		a5TMoQixbRG9N = title
	else:
		JRXn54gp3ABzO = FWK9ZMPpVauYrEH2v(T1QDsJlUtCGhn,bTxVLweoWPMu,O4F8UC5lMAS6ghETm1VoPDI(u"࠴࠹࠵࠶෠"))
		JRXn54gp3ABzO,wFTdl0nDmLu9AV1RYp,Ds8P5JTdj7luQ3mLcqHB = zip(*JRXn54gp3ABzO)
		l0lSF3hYekxtf158yRp,eCmU1uPwnXSf4ocJjFRaVZY,frNSHT90aIyw3QKJUgVuq7j5ZkY4v = [],[],ZVNvqy4iF1a9X
		XOxU2FnTMeYI = sorted(XOxU2FnTMeYI, reverse=w2qb6lf5EM, key=lambda key: float(key[D9yBM7wPFLz]))
		Y6POLrhF4lvKujB,ng57B26W3wmucOAC,AFRrS8JIYWeht = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		try: Y6POLrhF4lvKujB = DDuAgkFnXqlc3YZMQHp1r[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡺ࡮ࡪࡥࡰࡆࡨࡸࡦ࡯࡬ࡴࠩౘ")][CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡦࡻࡴࡩࡱࡵࠫౙ")]
		except:
			try: Y6POLrhF4lvKujB = M90jQzoE6cHTqiFkGr5CS[zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡼࡩࡥࡧࡲࡈࡪࡺࡡࡪ࡮ࡶࠫౚ")][cjVhOCwybeRo7UWg92(u"࠭ࡡࡶࡶ࡫ࡳࡷ࠭౛")]
			except: pass
		try: ng57B26W3wmucOAC = DDuAgkFnXqlc3YZMQHp1r[otNfFapeEnO(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭౜")][cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡥ࡫ࡥࡳࡴࡥ࡭ࡋࡧࠫౝ")]
		except:
			try: ng57B26W3wmucOAC = M90jQzoE6cHTqiFkGr5CS[s97s2k0LJgl(u"ࠩࡹ࡭ࡩ࡫࡯ࡅࡧࡷࡥ࡮ࡲࡳࠨ౞")][cjVhOCwybeRo7UWg92(u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩ࠭౟")]
			except: pass
		if Y6POLrhF4lvKujB and ng57B26W3wmucOAC:
			frNSHT90aIyw3QKJUgVuq7j5ZkY4v += P2Fgh6TCOWoaHjkqBcQnvRNXe
			title = Dj62UpP5MrbTkJqhRa+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡔ࡝ࡎࡆࡔ࠽ࠤࠥ࠭ౠ")+Y6POLrhF4lvKujB+oOQaRxBXyJ5jVnZ
			ZgsbN5iSL48t2IhVFnmy = Ew2zQ8u7Ss.SITESURLS[s97s2k0LJgl(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ౡ")][ZVNvqy4iF1a9X]+E6xdOMpqISHZCn(u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࠩౢ")+ng57B26W3wmucOAC
			l0lSF3hYekxtf158yRp.append(title)
			eCmU1uPwnXSf4ocJjFRaVZY.append(ZgsbN5iSL48t2IhVFnmy)
			try: AFRrS8JIYWeht = DDuAgkFnXqlc3YZMQHp1r[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡷ࡫ࡧࡩࡴࡊࡥࡵࡣ࡬ࡰࡸ࠭ౣ")][VVvcQpCU3OM09n(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࠫ౤")][zQGaM7ctZCN(u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭౥")][-P2Fgh6TCOWoaHjkqBcQnvRNXe][cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡹࡷࡲࠧ౦")]
			except:
				try: AFRrS8JIYWeht = M90jQzoE6cHTqiFkGr5CS[O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪ౧")][yylSaxCLfkte(u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ౨")][cjVhOCwybeRo7UWg92(u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ౩")][-P2Fgh6TCOWoaHjkqBcQnvRNXe][KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡶࡴ࡯ࠫ౪")]
				except: pass
		for qbkKwv0MA7PuWdh4syoEJ1SFt,lOYbqfwHZRSKD13U9uP,title,ksDvwLIca3bHm in JRXn54gp3ABzO:
			l0lSF3hYekxtf158yRp.append(title) ; eCmU1uPwnXSf4ocJjFRaVZY.append(mi2ZJXCDzITuyev6gfn(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ౫"))
		if mJ96prgZ5voKXATG1WCHYzBnL: l0lSF3hYekxtf158yRp.append(yylSaxCLfkte(u"ุࠩ์ึฯ้ࠠื๋ฮ๋ࠥอะัฬࠫ౬")) ; eCmU1uPwnXSf4ocJjFRaVZY.append(yylSaxCLfkte(u"ࠪࡱࡺࡾࡥࡥࠩ౭"))
		if XOxU2FnTMeYI: l0lSF3hYekxtf158yRp.append(cjVhOCwybeRo7UWg92(u"ฺࠫ๎ัสู๋ࠢํะࠠศๆ่ฮํ็ัࠨ౮")) ; eCmU1uPwnXSf4ocJjFRaVZY.append(o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡧ࡬࡭ࠩ౯"))
		if ylVQfWr8ESRszZhavPgiNe9jMt: l0lSF3hYekxtf158yRp.append(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭วฯฬิࠤฬ๊ี้ำฬࠤํอไึ๊อࠫ౰")) ; eCmU1uPwnXSf4ocJjFRaVZY.append(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࡮ࡲࡧࠫ౱"))
		if hK4jNd6HY8u5rM0xsJ: l0lSF3hYekxtf158yRp.append(rC5tnFDlQcRGA2(u"ࠨื๋ีฮࠦศะ๊้ࠤฺ๎สࠨ౲")) ; eCmU1uPwnXSf4ocJjFRaVZY.append(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡹ࡭ࡩ࡫࡯ࠨ౳"))
		if mDe0FHaroGhZ: l0lSF3hYekxtf158yRp.append(EcjO3giln2kQTdBY0XLAG(u"ูࠪํะࠠษั๋๊ࠥ฻่าหࠪ౴")) ; eCmU1uPwnXSf4ocJjFRaVZY.append(E6xdOMpqISHZCn(u"ࠫࡦࡻࡤࡪࡱࠪ౵"))
		while w2qb6lf5EM:
			CrqTamtPFuU = T4TK17YsEfZJ(YYsRFcnzOKbUHk6IBdwy2,l0lSF3hYekxtf158yRp)
			if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe: return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ౶"),[],[]
			elif CrqTamtPFuU==ZVNvqy4iF1a9X and Y6POLrhF4lvKujB:
				ZgsbN5iSL48t2IhVFnmy = eCmU1uPwnXSf4ocJjFRaVZY[CrqTamtPFuU]
				R5ljfoFUWL7VdInNtzZPB1 = A8v6c2fL7egwWCF3YBqr4kXSRn.argv[ZVNvqy4iF1a9X]+I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭࠿ࡵࡻࡳࡩࡂ࡬࡯࡭ࡦࡨࡶࠫࡳ࡯ࡥࡧࡀ࠵࠹࠷ࠦ࡯ࡣࡰࡩࡂ࠭౷")+O4Ak3NXpyUHvE(Y6POLrhF4lvKujB)+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࠧࡷࡵࡰࡂ࠭౸")+ZgsbN5iSL48t2IhVFnmy
				if AFRrS8JIYWeht: R5ljfoFUWL7VdInNtzZPB1 = R5ljfoFUWL7VdInNtzZPB1+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࠨ࡬ࡱࡦ࡭ࡥ࠾ࠩ౹")+O4Ak3NXpyUHvE(AFRrS8JIYWeht)
				pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠤࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠨ౺")+R5ljfoFUWL7VdInNtzZPB1+O4F8UC5lMAS6ghETm1VoPDI(u"ࠥ࠭ࠧ౻"))
				return otNfFapeEnO(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ౼"),[],[]
			LfJRKzMepo0gZ = eCmU1uPwnXSf4ocJjFRaVZY[CrqTamtPFuU]
			a5TMoQixbRG9N = l0lSF3hYekxtf158yRp[CrqTamtPFuU]
			if LfJRKzMepo0gZ==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡪࡡࡴࡪࠪ౽"):
				up7RfMNd1X = pszSqO1VEYjNtTDlyK8uZMov
				break
			elif LfJRKzMepo0gZ in [cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡡࡶࡦ࡬ࡳࠬ౾"),s97s2k0LJgl(u"ࠧࡷ࡫ࡧࡩࡴ࠭౿"),ZP1LyUCS3pIBu(u"ࠨ࡯ࡸࡼࡪࡪࠧಀ")]:
				if LfJRKzMepo0gZ==TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡰࡹࡽ࡫ࡤࠨಁ"): Uz8mMbZifCyvkLnct,V8DdzNL3C6kY275puQqsAl = mJ96prgZ5voKXATG1WCHYzBnL,RiFBb6I5WcA9f0MqdmZ
				elif LfJRKzMepo0gZ==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡺ࡮ࡪࡥࡰࠩಂ"): Uz8mMbZifCyvkLnct,V8DdzNL3C6kY275puQqsAl = hK4jNd6HY8u5rM0xsJ,LUJTqrdWmwIEP3XCMO2NQ8ngzvesyR
				elif LfJRKzMepo0gZ==pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡦࡻࡤࡪࡱࠪಃ"): Uz8mMbZifCyvkLnct,V8DdzNL3C6kY275puQqsAl = mDe0FHaroGhZ,A6fLg34UHzbjxeVJrEXkKcnh
				CrqTamtPFuU = T4TK17YsEfZJ(pz4WBwfyDdgk0m2aRr7SMv(u"ࠬอฮหำࠣห้๋ไโࠢࠫࠫ಄")+str(len(Uz8mMbZifCyvkLnct))+KA26GucUHOwXL(u"࠭ࠠๆๆไ࠭ࠬಅ"),Uz8mMbZifCyvkLnct)
				if CrqTamtPFuU!=-P2Fgh6TCOWoaHjkqBcQnvRNXe:
					up7RfMNd1X = V8DdzNL3C6kY275puQqsAl[CrqTamtPFuU][zQGaM7ctZCN(u"ࠧࡶࡴ࡯ࠫಆ")]
					a5TMoQixbRG9N = Uz8mMbZifCyvkLnct[CrqTamtPFuU]
					break
			elif LfJRKzMepo0gZ==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨ࡯ࡳࡨࠬಇ"):
				CrqTamtPFuU = T4TK17YsEfZJ(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩสาฯืࠠอ๊าอࠥอไึ๊ิอࠥ࠮ࠧಈ")+str(len(ylVQfWr8ESRszZhavPgiNe9jMt))+JACnOz297UuDK5HpPkc1LF(u"ࠪࠤ๊๊แࠪࠩಉ"),ylVQfWr8ESRszZhavPgiNe9jMt)
				if CrqTamtPFuU!=-P2Fgh6TCOWoaHjkqBcQnvRNXe:
					a5TMoQixbRG9N = ylVQfWr8ESRszZhavPgiNe9jMt[CrqTamtPFuU]
					OXwJMTd9n3b = iAC2jzaDcFbI8OP053[CrqTamtPFuU]
					CrqTamtPFuU = T4TK17YsEfZJ(E6xdOMpqISHZCn(u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ฯࠦࠨࠨಊ")+str(len(ekiVjwWmU35Q9sFPNgo7x2uOKb0))+s97s2k0LJgl(u"ࠬࠦๅๅใࠬࠫಋ"),ekiVjwWmU35Q9sFPNgo7x2uOKb0)
					if CrqTamtPFuU!=-P2Fgh6TCOWoaHjkqBcQnvRNXe:
						a5TMoQixbRG9N += mi2ZJXCDzITuyev6gfn(u"࠭ࠠࠬࠢࠪಌ")+ekiVjwWmU35Q9sFPNgo7x2uOKb0[CrqTamtPFuU]
						EdFqDARbVOkp9gaC = KwZjsfFPQMnxh0VHDEOv7[CrqTamtPFuU]
						euPzIYQ8TVJNDK = w2qb6lf5EM
						break
			elif LfJRKzMepo0gZ==o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡢ࡮࡯ࠫ಍"):
				AFRkWisbQ7,qVDHrZQP3y9IMAk2jCmFYbpvBU,rGfxwMcFmvC7th3X15k0yb8qoUdsR,w6E3XxcJl509mjr1nbg48qdyeTCV = list(zip(*XOxU2FnTMeYI))
				CrqTamtPFuU = T4TK17YsEfZJ(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨษัฮึࠦวๅ็็ๅࠥ࠮ࠧಎ")+str(len(rGfxwMcFmvC7th3X15k0yb8qoUdsR))+h6sIkJOT5PB2vCxqo4LFag70wA(u"้้ࠩࠣ็ࠩࠨಏ"),rGfxwMcFmvC7th3X15k0yb8qoUdsR)
				if CrqTamtPFuU!=-P2Fgh6TCOWoaHjkqBcQnvRNXe:
					a5TMoQixbRG9N = rGfxwMcFmvC7th3X15k0yb8qoUdsR[CrqTamtPFuU]
					OXwJMTd9n3b = AFRkWisbQ7[CrqTamtPFuU]
					if XB4CjMkPFzhAHiI3q(u"ࠪࡱࡵࡪࠧಐ") in rGfxwMcFmvC7th3X15k0yb8qoUdsR[CrqTamtPFuU] and OXwJMTd9n3b[rC5tnFDlQcRGA2(u"ࠫࡺࡸ࡬ࠨ಑")]!=pszSqO1VEYjNtTDlyK8uZMov:
						EdFqDARbVOkp9gaC = qVDHrZQP3y9IMAk2jCmFYbpvBU[CrqTamtPFuU]
						euPzIYQ8TVJNDK = w2qb6lf5EM
					else: up7RfMNd1X = OXwJMTd9n3b[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡻࡲ࡭ࠩಒ")]
					break
			elif LfJRKzMepo0gZ==zQGaM7ctZCN(u"࠭ࡨࡪࡩ࡫ࡩࡸࡺࠧಓ"):
				AFRkWisbQ7,qVDHrZQP3y9IMAk2jCmFYbpvBU,rGfxwMcFmvC7th3X15k0yb8qoUdsR,w6E3XxcJl509mjr1nbg48qdyeTCV = list(zip(*JRXn54gp3ABzO))
				OXwJMTd9n3b = AFRkWisbQ7[CrqTamtPFuU-frNSHT90aIyw3QKJUgVuq7j5ZkY4v]
				if pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࡮ࡲࡧࠫಔ") in rGfxwMcFmvC7th3X15k0yb8qoUdsR[CrqTamtPFuU-frNSHT90aIyw3QKJUgVuq7j5ZkY4v] and OXwJMTd9n3b[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡷࡵࡰࠬಕ")]!=pszSqO1VEYjNtTDlyK8uZMov:
					EdFqDARbVOkp9gaC = qVDHrZQP3y9IMAk2jCmFYbpvBU[CrqTamtPFuU-frNSHT90aIyw3QKJUgVuq7j5ZkY4v]
					euPzIYQ8TVJNDK = w2qb6lf5EM
				else: up7RfMNd1X = OXwJMTd9n3b[yylSaxCLfkte(u"ࠩࡸࡶࡱ࠭ಖ")]
				a5TMoQixbRG9N = rGfxwMcFmvC7th3X15k0yb8qoUdsR[CrqTamtPFuU-frNSHT90aIyw3QKJUgVuq7j5ZkY4v]
				break
	if euPzIYQ8TVJNDK:
		OT3GztdQfScXHqBPj8lsRa = int(OXwJMTd9n3b[zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬಗ")])
		jqXNdsyFWp1oR6Y28LDEQlxriA = int(EdFqDARbVOkp9gaC[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ಘ")])
		XtbZnKed5mT2IYPy4MqvuOGURNwSc = str(max(OT3GztdQfScXHqBPj8lsRa,jqXNdsyFWp1oR6Y28LDEQlxriA))
		J7o8zpBly5fGNijbORhC = OXwJMTd9n3b[zQGaM7ctZCN(u"ࠬࡻࡲ࡭ࠩಙ")].replace(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࠦࠨಚ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࠧࡣࡰࡴࡀ࠭ಛ"))
		O17Or2sBoxHz0G64WA3Rqc = EdFqDARbVOkp9gaC[h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡷࡵࡰࠬಜ")].replace(EcjO3giln2kQTdBY0XLAG(u"ࠩࠩࠫಝ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࠪࡦࡳࡰ࠼ࠩಞ"))
		mpd = VVvcQpCU3OM09n(u"ࠫࡁࡓࡐࡅࠢࡰࡩࡩ࡯ࡡࡑࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࡊࡵࡳࡣࡷ࡭ࡴࡴ࠽ࠣࡒࡗࠫಟ")+XtbZnKed5mT2IYPy4MqvuOGURNwSc+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࡙ࠬࠢ࠿࡞ࡱࠫಠ")
		mpd += ZP1LyUCS3pIBu(u"࠭࠼ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪಡ")
		mpd += pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡻ࡯ࡤࡦࡱ࠲ࠫಢ")+OXwJMTd9n3b[pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪಣ")]+KA26GucUHOwXL(u"ࠩࠥࠤࡨࡵࡤࡦࡥࡶࡁࠧ࠭ತ")+OXwJMTd9n3b[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡧࡴࡪࡥࡤࡵࠪಥ")]+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࠧࡄ࡜࡯ࠩದ")
		mpd += KA26GucUHOwXL(u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪಧ")
		mpd += TDpFsQXHze2q30uYtGPfEIm8(u"࠭࠼ࡃࡣࡶࡩ࡚ࡘࡌ࠿ࠩನ")+J7o8zpBly5fGNijbORhC+ZP1LyUCS3pIBu(u"ࠧ࠽࠱ࡅࡥࡸ࡫ࡕࡓࡎࡁࡠࡳ࠭಩")
		mpd += I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨ࠾ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫ࠠࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࡁࠧ࠭ಪ")+OXwJMTd9n3b[EcjO3giln2kQTdBY0XLAG(u"ࠩ࡬ࡲࡩ࡫ࡸࠨಫ")]+KA26GucUHOwXL(u"ࠪࠦࡃࡢ࡮ࠨಬ")
		mpd += CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡁࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳࠦࡲࡢࡰࡪࡩࡂࠨࠧಭ")+OXwJMTd9n3b[KA26GucUHOwXL(u"ࠬ࡯࡮ࡪࡶࠪಮ")]+mi2ZJXCDzITuyev6gfn(u"࠭ࠢࠡ࠱ࡁࡠࡳ࠭ಯ")
		mpd += zQGaM7ctZCN(u"ࠧ࠽࠱ࡖࡩ࡬ࡳࡥ࡯ࡶࡅࡥࡸ࡫࠾࡝ࡰࠪರ")
		mpd += otNfFapeEnO(u"ࠨ࠾࠲ࡖࡪࡶࡲࡦࡵࡨࡲࡹࡧࡴࡪࡱࡱࡂࡡࡴࠧಱ")
		mpd += mi2ZJXCDzITuyev6gfn(u"ࠩ࠿࠳ࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࡂࡡࡴࠧಲ")
		mpd += HaTI5u1f3SCxmMAkw(u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡢࡷࡧ࡭ࡴ࠵ࠧಳ")+EdFqDARbVOkp9gaC[zQGaM7ctZCN(u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭಴")]+GISOTJh20W(u"ࠬࠨࠠࡤࡱࡧࡩࡨࡹ࠽ࠣࠩವ")+EdFqDARbVOkp9gaC[ZP1LyUCS3pIBu(u"࠭ࡣࡰࡦࡨࡧࡸ࠭ಶ")]+zQGaM7ctZCN(u"ࠧࠣࡀ࡟ࡲࠬಷ")
		mpd += cjVhOCwybeRo7UWg92(u"ࠨ࠾ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭ಸ")
		mpd += JACnOz297UuDK5HpPkc1LF(u"ࠩ࠿ࡆࡦࡹࡥࡖࡔࡏࡂࠬಹ")+O17Or2sBoxHz0G64WA3Rqc+o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡀ࠴ࡈࡡࡴࡧࡘࡖࡑࡄ࡜࡯ࠩ಺")
		mpd += yylSaxCLfkte(u"ࠫࡁ࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫࠽ࠣࠩ಻")+EdFqDARbVOkp9gaC[E6xdOMpqISHZCn(u"ࠬ࡯࡮ࡥࡧࡻ಼ࠫ")]+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࠢ࠿࡞ࡱࠫಽ")
		mpd += rC5tnFDlQcRGA2(u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪಾ")+EdFqDARbVOkp9gaC[GISOTJh20W(u"ࠨ࡫ࡱ࡭ࡹ࠭ಿ")]+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩೀ")
		mpd += cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭ು")
		mpd += HaTI5u1f3SCxmMAkw(u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪೂ")
		mpd += GISOTJh20W(u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪೃ")
		mpd += I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭࠼࠰ࡒࡨࡶ࡮ࡵࡤ࠿࡞ࡱࠫೄ")
		mpd += GISOTJh20W(u"ࠧ࠽࠱ࡐࡔࡉࡄ࡜࡯ࠩ೅")
		if A7Z6OVh20eCEUx:
			import http.server as RzOKqaHiVbUpkh5Peyvr26tXocG
			import http.client as DFGJctK0N8wg7a4HxqSzI2Ob
		else:
			import BaseHTTPServer as RzOKqaHiVbUpkh5Peyvr26tXocG
			import httplib as DFGJctK0N8wg7a4HxqSzI2Ob
		class QM3OKXhw95R7t6oLHGCpPfiIl2JYW(RzOKqaHiVbUpkh5Peyvr26tXocG.HTTPServer):
			def __init__(TW54k08qYHAVnOKXmhbf,ip=TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨ࡮ࡲࡧࡦࡲࡨࡰࡵࡷࠫೆ"),port=VVvcQpCU3OM09n(u"࠹࠺࠶࠵࠶෡"),mpd=rC5tnFDlQcRGA2(u"ࠩ࠿ࡂࠬೇ")):
				TW54k08qYHAVnOKXmhbf.ip = ip
				TW54k08qYHAVnOKXmhbf.port = port
				TW54k08qYHAVnOKXmhbf.mpd = mpd
				RzOKqaHiVbUpkh5Peyvr26tXocG.HTTPServer.__init__(TW54k08qYHAVnOKXmhbf,(TW54k08qYHAVnOKXmhbf.ip,TW54k08qYHAVnOKXmhbf.port),HIJGYMsjfFLePV3cyxCuNdh)
				TW54k08qYHAVnOKXmhbf.mpdurl = XB4CjMkPFzhAHiI3q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫೈ")+ip+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫ࠿࠭೉")+str(port)+Olh7n0zfV4(u"ࠬ࠵ࡹࡰࡷࡷࡹࡧ࡫࠮࡮ࡲࡧࠫೊ")
			def start(TW54k08qYHAVnOKXmhbf):
				TW54k08qYHAVnOKXmhbf.threads = x74xDjR1rFbNiWh(VJZIMkUN5siqB21Pf)
				TW54k08qYHAVnOKXmhbf.threads.cAw6YbSQ5P1zoDkBp(P2Fgh6TCOWoaHjkqBcQnvRNXe,TW54k08qYHAVnOKXmhbf.BexSI6skdN0)
			def BexSI6skdN0(TW54k08qYHAVnOKXmhbf):
				TW54k08qYHAVnOKXmhbf.keeprunning = w2qb6lf5EM
				while TW54k08qYHAVnOKXmhbf.keeprunning:
					TW54k08qYHAVnOKXmhbf.handle_request()
			def stop(TW54k08qYHAVnOKXmhbf):
				TW54k08qYHAVnOKXmhbf.keeprunning = VJZIMkUN5siqB21Pf
				TW54k08qYHAVnOKXmhbf.i40W5vGs1kgwOM9PLZ()
			def u5hJSpVFNHAiPYsKx(TW54k08qYHAVnOKXmhbf):
				TW54k08qYHAVnOKXmhbf.stop()
				TW54k08qYHAVnOKXmhbf.lybrJX1W94gjOzT2qpH.close()
				TW54k08qYHAVnOKXmhbf.server_close()
			def q1qwPWrhDfTectm2A(TW54k08qYHAVnOKXmhbf,mpd):
				TW54k08qYHAVnOKXmhbf.mpd = mpd
			def i40W5vGs1kgwOM9PLZ(TW54k08qYHAVnOKXmhbf):
				PBrsIxTjg1ec3VO0zJKl5oYLRpFUX = DFGJctK0N8wg7a4HxqSzI2Ob.HTTPConnection(TW54k08qYHAVnOKXmhbf.ip+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࠺ࠨೋ")+str(TW54k08qYHAVnOKXmhbf.port))
				PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.request(Olh7n0zfV4(u"ࠢࡉࡇࡄࡈࠧೌ"), otNfFapeEnO(u"ࠣ࠱್ࠥ"))
		class HIJGYMsjfFLePV3cyxCuNdh(RzOKqaHiVbUpkh5Peyvr26tXocG.BaseHTTPRequestHandler):
			def t6VK093dTzQyHm4ZIAv(TW54k08qYHAVnOKXmhbf):
				TW54k08qYHAVnOKXmhbf.send_response(cbmeD4WNZfAowxT2JdUMtV(u"࠷࠶࠰෢"))
				TW54k08qYHAVnOKXmhbf.send_header(GISOTJh20W(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ೎"),rC5tnFDlQcRGA2(u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ೏"))
				TW54k08qYHAVnOKXmhbf.end_headers()
				TW54k08qYHAVnOKXmhbf.wfile.write(TW54k08qYHAVnOKXmhbf.FFtJQalhPz.mpd.encode(Im5KSGZYBpRvdMVsbuXg))
				L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
				if TW54k08qYHAVnOKXmhbf.path==Olh7n0zfV4(u"ࠫ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ೐"): TW54k08qYHAVnOKXmhbf.FFtJQalhPz.u5hJSpVFNHAiPYsKx()
				if TW54k08qYHAVnOKXmhbf.path==cbmeD4WNZfAowxT2JdUMtV(u"ࠬ࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ೑"): TW54k08qYHAVnOKXmhbf.FFtJQalhPz.u5hJSpVFNHAiPYsKx()
			def NfhwkloB2DdG(TW54k08qYHAVnOKXmhbf):
				TW54k08qYHAVnOKXmhbf.send_response(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠸࠰࠱෣"))
				TW54k08qYHAVnOKXmhbf.end_headers()
		E3Er8OlNQST5ojnZt4MsFp19uXVC = QM3OKXhw95R7t6oLHGCpPfiIl2JYW(GISOTJh20W(u"࠭࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠩ೒"),GISOTJh20W(u"࠵࠶࠲࠸࠹෤"),mpd)
		up7RfMNd1X = E3Er8OlNQST5ojnZt4MsFp19uXVC.mpdurl
		E3Er8OlNQST5ojnZt4MsFp19uXVC.start()
	else: E3Er8OlNQST5ojnZt4MsFp19uXVC = CJlTSEpZsWb0QHg5w
	if A7Z6OVh20eCEUx: mdFyiKTarMUu0V,WWk31K7vaGFgdjQcpS = CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࡝ࡶࠪ೓")
	else: mdFyiKTarMUu0V,WWk31K7vaGFgdjQcpS = VVvcQpCU3OM09n(u"ࠨ࡞ࡷࠫ೔"),CJlTSEpZsWb0QHg5w
	DDJYRWz0HQqa = mdFyiKTarMUu0V+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡄࡹࡩ࡯࡯࠻ࠢ࡞ࠤࠬೕ")+EdFqDARbVOkp9gaC[pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡹࡷࡲࠧೖ")]+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࠥࡣ࡜࡯࡞ࡷࡠࡹ࠭೗")+WWk31K7vaGFgdjQcpS+Olh7n0zfV4(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ೘")+OXwJMTd9n3b[Olh7n0zfV4(u"࠭ࡵࡳ࡮ࠪ೙")]+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࠡ࡟ࠪ೚") if euPzIYQ8TVJNDK else mdFyiKTarMUu0V+ZP1LyUCS3pIBu(u"ࠨࡃ࠮࡚࠿࡛ࠦࠡࠩ೛")+up7RfMNd1X+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࠣࡡࠬ೜")
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡠࡹࡖ࡬ࡢࡻ࡬ࡲ࡬ࠦࡓࡵࡴࡨࡥࡲࡀࠠ࡜ࠢࠪೝ")+a5TMoQixbRG9N+o2FdrDBimMuOw97q6QpNW8S(u"ࠫࠥࡣࠠࠡࠢࠪೞ")+DDJYRWz0HQqa)
	if not up7RfMNd1X: return HaTI5u1f3SCxmMAkw(u"ࠬࡋࡲࡳࡱࡵࠤࠥࠦࠠ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ೟"),[],[]
	return CJlTSEpZsWb0QHg5w,[a5TMoQixbRG9N],[[up7RfMNd1X,eqVPIOhpxtFy,E3Er8OlNQST5ojnZt4MsFp19uXVC]]
def FebNgOaxroT4hCW9tdU6BJnDw02zP(url):
	headers = { EcjO3giln2kQTdBY0XLAG(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪೠ") : CJlTSEpZsWb0QHg5w }
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧೡ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(cjVhOCwybeRo7UWg92(u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬೢ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	items = set(items)
	items = sorted(items, reverse=w2qb6lf5EM, key=lambda key: key[VTadWjBloMwXO2CH9GDK6FR])
	UQVoHSPr1nuq4LWkyXMsd3tTvp8,Uz8mMbZifCyvkLnct,LL0smM98Y57PVH,MNXzjK3vV7D = [],[],[],[]
	if not items: return zQGaM7ctZCN(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡛ࡏࡄࡃࡑࡅࠫೣ"),[],[]
	for ZgsbN5iSL48t2IhVFnmy,Cm7xuRTdLQwZjv81V2AhKfqs04U,m9wgSl1oUVRd in items:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ೤"),mi2ZJXCDzITuyev6gfn(u"ࠫ࡭ࡺࡴࡱ࠼ࠪ೥"))
		if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࠴࡭࠴ࡷ࠻ࠫ೦") in ZgsbN5iSL48t2IhVFnmy:
			UQVoHSPr1nuq4LWkyXMsd3tTvp8,LL0smM98Y57PVH = bUD0vMHIQhKW(T1QDsJlUtCGhn,ZgsbN5iSL48t2IhVFnmy)
			MNXzjK3vV7D = MNXzjK3vV7D + LL0smM98Y57PVH
			if UQVoHSPr1nuq4LWkyXMsd3tTvp8[ZVNvqy4iF1a9X]==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭࠭࠲ࠩ೧"): Uz8mMbZifCyvkLnct.append(EcjO3giln2kQTdBY0XLAG(u"ࠧิ์ิๅึࠦฮศืࠪ೨")+mi2ZJXCDzITuyev6gfn(u"ࠨࠢࠣࠤࡲ࠹ࡵ࠹ࠩ೩"))
			else:
				for title in UQVoHSPr1nuq4LWkyXMsd3tTvp8:
					Uz8mMbZifCyvkLnct.append(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩึ๎ึ็ัࠡะสูࠬ೪")+VzZPgf1qW5L8auj2do9R4FpiXM7Ycy+title)
		else:
			title = rC5tnFDlQcRGA2(u"ࠪื๏ืแาࠢัหฺ࠭೫")+pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ೬")+m9wgSl1oUVRd
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			Uz8mMbZifCyvkLnct.append(title)
	return CJlTSEpZsWb0QHg5w,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
def P9IR4p02DGu3U1MgqiKkHn5(url,bGIVq1CQTjmosZg):
	steS3aGdomU,FhX9OGwaNyAEZ,HAJTp4ciaoZLsK7qjCewb,mqk6U7HgpIBNdl9fxJ0KzTsj,Rp1g7OlotseGnf0NFmKk6rLxd = [],[],[],[],[]
	if not isinstance(bGIVq1CQTjmosZg,str): bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.decode(Im5KSGZYBpRvdMVsbuXg,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ೭"))
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(XB4CjMkPFzhAHiI3q(u"࠭࠼ࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ೮"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy and not XETbMJIf1yetlQSinA2NW5YHvag6D(ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]): ZgsbN5iSL48t2IhVFnmy = []
	if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭೯"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy and not XETbMJIf1yetlQSinA2NW5YHvag6D(ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]): ZgsbN5iSL48t2IhVFnmy = []
	if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall(EcjO3giln2kQTdBY0XLAG(u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ೰"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy and not XETbMJIf1yetlQSinA2NW5YHvag6D(ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]): ZgsbN5iSL48t2IhVFnmy = []
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[ZVNvqy4iF1a9X]
		title = ZgsbN5iSL48t2IhVFnmy.rsplit(rC5tnFDlQcRGA2(u"ࠩ࠱ࠫೱ"),rC5tnFDlQcRGA2(u"࠲෥"))[P2Fgh6TCOWoaHjkqBcQnvRNXe]
		steS3aGdomU.append(title)
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	else:
		p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall(Olh7n0zfV4(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥ࠰ࠨ࡝࡝࠱࠮ࡄࡢ࡝ࠪࠩೲ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not p3LfChWJd124eAYj78zw09SXonH: p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡻࡧࡲࠡࡵࡲࡹࡷࡩࡥࡴࠢࡀࠤ࠭ࡢࡻ࠯ࠬࡂࡠࢂ࠯ࠧೳ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not p3LfChWJd124eAYj78zw09SXonH: p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall(JACnOz297UuDK5HpPkc1LF(u"ࠬࡼࡡࡳࠢ࡭ࡻࠥࡃࠠࠩ࡞ࡾ࠲࠯ࡅ࡜ࡾࠫࠪ೴"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not p3LfChWJd124eAYj78zw09SXonH: p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"࠭ࡶࡢࡴࠣࡴࡱࡧࡹࡦࡴࠣࡁࠥ࠴ࠪࡀ࡞ࠫࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮ࡢࠩࠨ೵"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if p3LfChWJd124eAYj78zw09SXonH:
			p3LfChWJd124eAYj78zw09SXonH = p3LfChWJd124eAYj78zw09SXonH[ZVNvqy4iF1a9X]
			p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.sub(ZP1LyUCS3pIBu(u"ࡲࠨࠪ࡞ࡠࢀࡢࠬ࡞࡝࡟ࡸࡡࡹ࡜࡯࡞ࡵࡡ࠯࠯ࠨ࡝ࡹ࠮࡟ࡡࡺ࡜ࡴ࡟࠭࠭࠿࠭೶"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࡳࠩ࡟࠵ࠧࡢ࠲ࠣ࠼ࠪ೷"),p3LfChWJd124eAYj78zw09SXonH)
			p3LfChWJd124eAYj78zw09SXonH = oE7iT3HI5VDdmY4kPOjr(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡧ࡭ࡨࡺࠧ೸"),p3LfChWJd124eAYj78zw09SXonH)
			if isinstance(p3LfChWJd124eAYj78zw09SXonH,dict): p3LfChWJd124eAYj78zw09SXonH = [p3LfChWJd124eAYj78zw09SXonH]
			for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
				uIMqy0igo5HSL,ZgsbN5iSL48t2IhVFnmy = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
				if isinstance(D3D6TF50oUBtJlvijPMW8ys,dict):
					keys = list(D3D6TF50oUBtJlvijPMW8ys.keys())
					if   otNfFapeEnO(u"ࠪࡸࡾࡶࡥࠨ೹") in keys: uIMqy0igo5HSL = str(D3D6TF50oUBtJlvijPMW8ys[JACnOz297UuDK5HpPkc1LF(u"ࠫࡹࡿࡰࡦࠩ೺")])
					if   KA26GucUHOwXL(u"ࠬ࡬ࡩ࡭ࡧࠪ೻") in keys: ZgsbN5iSL48t2IhVFnmy = D3D6TF50oUBtJlvijPMW8ys[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡦࡪ࡮ࡨࠫ೼")]
					elif otNfFapeEnO(u"ࠧࡩ࡮ࡶࠫ೽") in keys: ZgsbN5iSL48t2IhVFnmy = D3D6TF50oUBtJlvijPMW8ys[Olh7n0zfV4(u"ࠨࡪ࡯ࡷࠬ೾")]
					elif xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡶࡶࡨ࠭೿") in keys: ZgsbN5iSL48t2IhVFnmy = D3D6TF50oUBtJlvijPMW8ys[TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡷࡷࡩࠧഀ")]
					if   yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡱࡧࡢࡦ࡮ࠪഁ") in keys: title = str(D3D6TF50oUBtJlvijPMW8ys[HaTI5u1f3SCxmMAkw(u"ࠬࡲࡡࡣࡧ࡯ࠫം")])
					elif h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬഃ") in keys: title = str(D3D6TF50oUBtJlvijPMW8ys[XB4CjMkPFzhAHiI3q(u"ࠧࡷ࡫ࡧࡩࡴࡥࡨࡦ࡫ࡪ࡬ࡹ࠭ഄ")])
					elif EcjO3giln2kQTdBY0XLAG(u"ࠨ࠰ࠪഅ") in ZgsbN5iSL48t2IhVFnmy: title = ZgsbN5iSL48t2IhVFnmy.rsplit(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ࠱ࠫആ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
					else: title = ZgsbN5iSL48t2IhVFnmy
				elif isinstance(D3D6TF50oUBtJlvijPMW8ys,str):
					ZgsbN5iSL48t2IhVFnmy = D3D6TF50oUBtJlvijPMW8ys
					title = ZgsbN5iSL48t2IhVFnmy.rsplit(otNfFapeEnO(u"ࠪ࠲ࠬഇ"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
				if P2Fgh6TCOWoaHjkqBcQnvRNXe:
					steS3aGdomU.append(title+gCc52XVMGfAnOe+uIMqy0igo5HSL)
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	for ZgsbN5iSL48t2IhVFnmy,title in list(zip(FhX9OGwaNyAEZ,steS3aGdomU)):
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(zQGaM7ctZCN(u"ࠫࡡࡢ࠯ࠨഈ"),yylSaxCLfkte(u"ࠬ࠵ࠧഉ"))
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(url,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡵࡳ࡮ࠪഊ"))
		ww0cfi2ZxQvg7k3N1uLRhtFdH = jQW9RpucaCLHX0sSBD6lrif58e47nt()
		if VVvcQpCU3OM09n(u"ࠧࡩࡶࡷࡴࠬഋ") not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = FFtJQalhPz+ZgsbN5iSL48t2IhVFnmy
		if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧഌ") in ZgsbN5iSL48t2IhVFnmy:
			headers = {GISOTJh20W(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭഍"):ww0cfi2ZxQvg7k3N1uLRhtFdH,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫഎ"):FFtJQalhPz}
			gtSUq7b3Tu,uuYRW8lfmzgCKVZXAOMDkaNG5IPE = bUD0vMHIQhKW(T1QDsJlUtCGhn,ZgsbN5iSL48t2IhVFnmy,headers)
			mqk6U7HgpIBNdl9fxJ0KzTsj += uuYRW8lfmzgCKVZXAOMDkaNG5IPE
			HAJTp4ciaoZLsK7qjCewb += gtSUq7b3Tu
		else:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪഏ")+ww0cfi2ZxQvg7k3N1uLRhtFdH+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨഐ")+FFtJQalhPz
			mqk6U7HgpIBNdl9fxJ0KzTsj.append(ZgsbN5iSL48t2IhVFnmy)
			HAJTp4ciaoZLsK7qjCewb.append(title)
	nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = CJlTSEpZsWb0QHg5w,[],[]
	if mqk6U7HgpIBNdl9fxJ0KzTsj: nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ = CJlTSEpZsWb0QHg5w,HAJTp4ciaoZLsK7qjCewb,mqk6U7HgpIBNdl9fxJ0KzTsj
	else:
		if yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭࠼ࠨ഑") not in bGIVq1CQTjmosZg and len(bGIVq1CQTjmosZg)<zz679V18GdcZwvrRexA0nNptY2Tab(u"࠳࠳࠴෦") and bGIVq1CQTjmosZg: nmREDwuel7S35JyF2BQ9KzbTv = bGIVq1CQTjmosZg
		else:
			msg = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧ࠽ࡦ࡬ࡺࠥࡹࡴࡺ࡮ࡨࡁࠧ࠴ࠪࡀࠤࡁࠬࡋ࡯࡬ࡦ࠰࠭ࡃ࠮ࡂࠧഒ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if not msg: msg = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡶࡱࡡࡹ࡭ࡩ࡫࡯ࡠࡵࡷࡹࡧࡥࡴࡹࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫഓ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if not msg: msg = Zy2l0g8QU5vqefaTrsw.findall(cbmeD4WNZfAowxT2JdUMtV(u"ࠩ࠿࡬࠷ࡄࠨࡔࡱࡵࡶࡾ࠴ࠪࡀࠫ࠿ࠫഔ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if msg: nmREDwuel7S35JyF2BQ9KzbTv = msg[ZVNvqy4iF1a9X]
	return nmREDwuel7S35JyF2BQ9KzbTv,steS3aGdomU,FhX9OGwaNyAEZ
def EERdTtKk8A0Y4BbpePzo(ddszVaYWMC,url):
	global XwJ4hWsK5qH
	url = url.strip(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪ࠳ࠬക"))
	WJOpDChFa9XitZ3NIH80nm6,wSfEHOilLYIK = CJlTSEpZsWb0QHg5w,{}
	headers = {otNfFapeEnO(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨഖ"):jQW9RpucaCLHX0sSBD6lrif58e47nt()}
	headers[Olh7n0zfV4(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ഗ")] = fUSgd7IjGYX496Hr25uFMl(url,KA26GucUHOwXL(u"࠭ࡵࡳ࡮ࠪഘ"))
	headers[Olh7n0zfV4(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩങ")] = zQGaM7ctZCN(u"ࠨࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠺ࠩച")
	headers[rC5tnFDlQcRGA2(u"ࠩࡖࡩࡨ࠳ࡆࡦࡶࡦ࡬࠲ࡊࡥࡴࡶࠪഛ")] = otNfFapeEnO(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪജ")
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡌࡋࡔࠨഝ"),url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧഞ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	tOZC4fvKDPxwFmlTI6N9askGiX = bqIufCQz2OWExjilm.code
	if not isinstance(bGIVq1CQTjmosZg,str): bGIVq1CQTjmosZg = bGIVq1CQTjmosZg.decode(Im5KSGZYBpRvdMVsbuXg,rC5tnFDlQcRGA2(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ട"))
	if XB4CjMkPFzhAHiI3q(u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠭ഠ") in bGIVq1CQTjmosZg:
		LhHVms8XJpc = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠨࠪࡨࡺࡦࡲ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬ࡜ࡦࡵࡡ࠳࠰࠿ࠪ࠾࠲ࡷࡨࡸࡩࡱࡶࡁࠫഡ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if LhHVms8XJpc:
			try: WJOpDChFa9XitZ3NIH80nm6 = S1FGp8IvLshO4Dy6wUZmCY7rN2MXkK(LhHVms8XJpc[ZVNvqy4iF1a9X])
			except: WJOpDChFa9XitZ3NIH80nm6 = CJlTSEpZsWb0QHg5w
	if pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠬ࡭࠲ࡵ࠭ࡰ࠯ࡸ࠱࡫ࠬࡳࠫࠪഢ") in bGIVq1CQTjmosZg:
		LhHVms8XJpc = Zy2l0g8QU5vqefaTrsw.findall(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࠬࡪࡼࡡ࡭࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࡨ࠭ࡷ࠯ࡲ࠱ࡺࠬࡦ࠮ࡵ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪണ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if LhHVms8XJpc:
			try: WJOpDChFa9XitZ3NIH80nm6 = Ce6kWT1z3S(LhHVms8XJpc[ZVNvqy4iF1a9X])
			except: WJOpDChFa9XitZ3NIH80nm6 = CJlTSEpZsWb0QHg5w
	Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bGIVq1CQTjmosZg+WJOpDChFa9XitZ3NIH80nm6
	if pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࠧ࡯ࡤ࠳ࠤࠪത") in Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp or EcjO3giln2kQTdBY0XLAG(u"ࠬࠨࡩࡥࠤࠪഥ") in Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp:
		Jhu1pxvXFSanLBq7jg9RAICT = url.split(EcjO3giln2kQTdBY0XLAG(u"࠭࠯ࠨദ"))[D9yBM7wPFLz].replace(JACnOz297UuDK5HpPkc1LF(u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧധ"),CJlTSEpZsWb0QHg5w).replace(VVvcQpCU3OM09n(u"ࠨ࠰࡫ࡸࡲࡲࠧന"),CJlTSEpZsWb0QHg5w)
		if cjVhOCwybeRo7UWg92(u"ࠩࠥ࡭ࡩ࠸ࠢࠨഩ") in Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp: wSfEHOilLYIK = {pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࡭ࡩ࠸ࠧപ"):Jhu1pxvXFSanLBq7jg9RAICT,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡴࡶࠧഫ"):E6xdOMpqISHZCn(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠲ࠨബ")}
		elif otNfFapeEnO(u"࠭ࠢࡪࡦࠥࠫഭ") in Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp: wSfEHOilLYIK = {NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡪࡦࠪമ"):Jhu1pxvXFSanLBq7jg9RAICT,Olh7n0zfV4(u"ࠨࡱࡳࠫയ"):XB4CjMkPFzhAHiI3q(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬര")}
		bsGedm1TLP7EgiUQDkCy = headers.copy()
		bsGedm1TLP7EgiUQDkCy[otNfFapeEnO(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩറ")] = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪല")
		Ig8Y6D1bZtzURv = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡖࡏࡔࡖࠪള"),url,wSfEHOilLYIK,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡛ࡗࡍࡇࡒࡊࡐࡊ࠱࠷ࡴࡤࠨഴ"))
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = Ig8Y6D1bZtzURv.content
	vPVnWTFCgQd47xSlM5iHrwcpoAfD,CCdyov5pOw8Vclx17ABDnPUY,VzfNj8YMBQptkTqR1KsvAeolDHdW = P9IR4p02DGu3U1MgqiKkHn5(url,Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp)
	XwJ4hWsK5qH[ddszVaYWMC] = vPVnWTFCgQd47xSlM5iHrwcpoAfD,CCdyov5pOw8Vclx17ABDnPUY,VzfNj8YMBQptkTqR1KsvAeolDHdW,tOZC4fvKDPxwFmlTI6N9askGiX
	return
XwJ4hWsK5qH,iWAImTybfgFnuU2MLCxD = {},ZVNvqy4iF1a9X
def bpfRrMUNl8Gk1VZKeIoJO(url):
	global XwJ4hWsK5qH,iWAImTybfgFnuU2MLCxD
	iWAImTybfgFnuU2MLCxD += yylSaxCLfkte(u"࠴࠴࠵෧")
	fwJeZQU7SyThKW0ilz = iWAImTybfgFnuU2MLCxD
	Rp1g7OlotseGnf0NFmKk6rLxd = [(P2Fgh6TCOWoaHjkqBcQnvRNXe,url)]
	BBwfuWGxUIrdCoc4ka7 = url.replace(otNfFapeEnO(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨവ"),XB4CjMkPFzhAHiI3q(u"ࠨ࠱ࠪശ"))
	WyHwgmzU0GnP = Zy2l0g8QU5vqefaTrsw.findall(Olh7n0zfV4(u"ࠩࡡࠬ࠳࠰࠿࠻࠱࠲࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮ࠪࠧഷ"),BBwfuWGxUIrdCoc4ka7+XB4CjMkPFzhAHiI3q(u"ࠪ࠳ࠬസ"),Zy2l0g8QU5vqefaTrsw.DOTALL)
	try: start,U3UlZikCqOgPw4FED,end = WyHwgmzU0GnP[ZVNvqy4iF1a9X]
	except: return O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡖࡎࡗࡍࡤ࡞ࡓࡉࡃࡕࡍࡓࡍࠧഹ"),[],[]
	end = end.strip(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬ࠵ࠧഺ"))
	Yq28lD4BQI5Ccvr = len(U3UlZikCqOgPw4FED)<P3cpaLN2sH or U3UlZikCqOgPw4FED in [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡦࡪ࡮ࡨ഻ࠫ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡷ࡫ࡧࡩࡴ഼࠭"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡸ࡬ࡨࡪࡵࡥ࡮ࡤࡨࡨࠬഽ"),GISOTJh20W(u"ࠩࡤ࡮ࡦࡾࠧാ"),Olh7n0zfV4(u"ࠪ࡭࡫ࡸࡡ࡮ࡧࠪി"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡲ࡯ࡲࡳࡱࡵࠫീ")]
	if not Yq28lD4BQI5Ccvr: Rp1g7OlotseGnf0NFmKk6rLxd.append([VTadWjBloMwXO2CH9GDK6FR,start+mi2ZJXCDzITuyev6gfn(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ു")+U3UlZikCqOgPw4FED+mi2ZJXCDzITuyev6gfn(u"࠭࠯ࠨൂ")+end])
	if end: Rp1g7OlotseGnf0NFmKk6rLxd.append([D9yBM7wPFLz,start+rC5tnFDlQcRGA2(u"ࠧ࠰ࠩൃ")+U3UlZikCqOgPw4FED+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩൄ")+end])
	if rC5tnFDlQcRGA2(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ൅") in U3UlZikCqOgPw4FED:
		yCwMAYbLB91eZK0NsqukcxjUoamFG = U3UlZikCqOgPw4FED.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪ࠲࡭ࡺ࡭࡭ࠩെ"),CJlTSEpZsWb0QHg5w)
		Rp1g7OlotseGnf0NFmKk6rLxd.append([P3cpaLN2sH,start+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫ࠴࠭േ")+yCwMAYbLB91eZK0NsqukcxjUoamFG+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬ࠵ࠧൈ")+end])
		Rp1g7OlotseGnf0NFmKk6rLxd.append([KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠹෨"),start+GISOTJh20W(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧ൉")+yCwMAYbLB91eZK0NsqukcxjUoamFG+HaTI5u1f3SCxmMAkw(u"ࠧ࠰ࠩൊ")+end])
		if end: Rp1g7OlotseGnf0NFmKk6rLxd.append([EcjO3giln2kQTdBY0XLAG(u"࠻෩"),start+HaTI5u1f3SCxmMAkw(u"ࠨ࠱ࠪോ")+yCwMAYbLB91eZK0NsqukcxjUoamFG+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ࠲ࡩࡲࡨࡥࡥ࠯ࠪൌ")+end])
	elif O4F8UC5lMAS6ghETm1VoPDI(u"ࠪ࠲࡭ࡺ࡭࡭്ࠩ") in end:
		iim9HYDvBjrL18V = end.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫ࠳࡮ࡴ࡮࡮ࠪൎ"),CJlTSEpZsWb0QHg5w)
		Rp1g7OlotseGnf0NFmKk6rLxd.append([E6xdOMpqISHZCn(u"࠽෪"),start+cbmeD4WNZfAowxT2JdUMtV(u"ࠬ࠵ࠧ൏")+U3UlZikCqOgPw4FED+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࠯ࠨ൐")+iim9HYDvBjrL18V])
		if not Yq28lD4BQI5Ccvr: Rp1g7OlotseGnf0NFmKk6rLxd.append([E6xdOMpqISHZCn(u"࠸෫"),start+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ൑")+U3UlZikCqOgPw4FED+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ࠱ࠪ൒")+iim9HYDvBjrL18V])
		Rp1g7OlotseGnf0NFmKk6rLxd.append([zQGaM7ctZCN(u"࠺෬"),start+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩ࠲ࠫ൓")+U3UlZikCqOgPw4FED+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫൔ")+iim9HYDvBjrL18V])
	else:
		if not Yq28lD4BQI5Ccvr: Rp1g7OlotseGnf0NFmKk6rLxd.append([KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠳࠳෭"),start+otNfFapeEnO(u"ࠫ࠴࠭ൕ")+U3UlZikCqOgPw4FED+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࠴ࡨࡵ࡯࡯ࠫൖ")])
		if not Yq28lD4BQI5Ccvr: Rp1g7OlotseGnf0NFmKk6rLxd.append([E6xdOMpqISHZCn(u"࠴࠵෮"),start+h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧൗ")+U3UlZikCqOgPw4FED+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧ࠯ࡪࡷࡱࡱ࠭൘")])
		if end: Rp1g7OlotseGnf0NFmKk6rLxd.append([E6xdOMpqISHZCn(u"࠵࠷෯"),start+Olh7n0zfV4(u"ࠨ࠱ࠪ൙")+U3UlZikCqOgPw4FED+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࠲ࠫ൚")+end+cbmeD4WNZfAowxT2JdUMtV(u"ࠪ࠲࡭ࡺ࡭࡭ࠩ൛")])
		if end: Rp1g7OlotseGnf0NFmKk6rLxd.append([NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶࠹෰"),start+otNfFapeEnO(u"ࠫ࠴࠭൜")+U3UlZikCqOgPw4FED+XB4CjMkPFzhAHiI3q(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭൝")+end+GISOTJh20W(u"࠭࠮ࡩࡶࡰࡰࠬ൞")])
	if Yq28lD4BQI5Ccvr and end:
		end = end.replace(XB4CjMkPFzhAHiI3q(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨൟ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠨ࠱ࠪൠ"))
		Rp1g7OlotseGnf0NFmKk6rLxd.append([Olh7n0zfV4(u"࠷࠴෱"),start+zQGaM7ctZCN(u"ࠩ࠲ࠫൡ")+end])
		Rp1g7OlotseGnf0NFmKk6rLxd.append([EcjO3giln2kQTdBY0XLAG(u"࠱࠶ෲ"),start+otNfFapeEnO(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫൢ")+end])
		if HaTI5u1f3SCxmMAkw(u"ࠫ࠳࡮ࡴ࡮࡮ࠪൣ") in end:
			iim9HYDvBjrL18V = end.replace(JACnOz297UuDK5HpPkc1LF(u"ࠬ࠴ࡨࡵ࡯࡯ࠫ൤"),CJlTSEpZsWb0QHg5w)
			Rp1g7OlotseGnf0NFmKk6rLxd.append([I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠲࠸ෳ"),start+h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭࠯ࠨ൥")+iim9HYDvBjrL18V])
			Rp1g7OlotseGnf0NFmKk6rLxd.append([HaTI5u1f3SCxmMAkw(u"࠳࠺෴"),start+rC5tnFDlQcRGA2(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨ൦")+iim9HYDvBjrL18V])
		else:
			Rp1g7OlotseGnf0NFmKk6rLxd.append([KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠴࠼෵"),start+E6xdOMpqISHZCn(u"ࠨ࠱ࠪ൧")+end+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࠱࡬ࡹࡳ࡬ࠨ൨")])
			Rp1g7OlotseGnf0NFmKk6rLxd.append([o2FdrDBimMuOw97q6QpNW8S(u"࠵࠾෶"),start+otNfFapeEnO(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫ൩")+end+s97s2k0LJgl(u"ࠫ࠳࡮ࡴ࡮࡮ࠪ൪")])
	PAVCuNMlHjGqRTUsYxLodFKf = []
	for DrKqvRJgASd4kzVZWucE,otCOTHujWKp7Dn6dvcafPqlx in Rp1g7OlotseGnf0NFmKk6rLxd:
		XwJ4hWsK5qH[fwJeZQU7SyThKW0ilz+DrKqvRJgASd4kzVZWucE] = [gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1,gZvlfk6xhACbXcD5j0KBLiVM1]
		T5MfL38udmsxW7 = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=EERdTtKk8A0Y4BbpePzo,args=(fwJeZQU7SyThKW0ilz+DrKqvRJgASd4kzVZWucE,otCOTHujWKp7Dn6dvcafPqlx))
		PAVCuNMlHjGqRTUsYxLodFKf.append(T5MfL38udmsxW7)
	def vvM1lTZGpaIdb38cqyiO():
		F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH = VJZIMkUN5siqB21Pf
		for GzWuVjwZgDKa5PCcQTM4 in XwJ4hWsK5qH:
			if not GzWuVjwZgDKa5PCcQTM4: break
		else: F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH = w2qb6lf5EM
		BL9EG8ulJM5 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player().isPlaying() if Ew2zQ8u7Ss.resolveonly else w2qb6lf5EM
		return F1Ac2P0rR4NVTj9mObhLvBsXkaoIDH or not BL9EG8ulJM5
	UUwxvmgjdH2(PAVCuNMlHjGqRTUsYxLodFKf,AwpgdrK0t17WSR2BOifND,Wx10KPISERil97ApBk,P2Fgh6TCOWoaHjkqBcQnvRNXe,vvM1lTZGpaIdb38cqyiO)
	nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D = CJlTSEpZsWb0QHg5w,[],[]
	cHRaG042IpX8FhOKwE = []
	for DrKqvRJgASd4kzVZWucE,ZgsbN5iSL48t2IhVFnmy in Rp1g7OlotseGnf0NFmKk6rLxd:
		KEumynHOTt51Q0R29fsDox,IxKdkFAoXLhz,Ia4CvrH0FmVXPLlzByRt9idwuKWpj,qG2ilF48CpIhE0DMQcna = XwJ4hWsK5qH[fwJeZQU7SyThKW0ilz+DrKqvRJgASd4kzVZWucE]
		if not MNXzjK3vV7D and Ia4CvrH0FmVXPLlzByRt9idwuKWpj: Uz8mMbZifCyvkLnct,MNXzjK3vV7D = IxKdkFAoXLhz,Ia4CvrH0FmVXPLlzByRt9idwuKWpj
		if not nmREDwuel7S35JyF2BQ9KzbTv and KEumynHOTt51Q0R29fsDox: nmREDwuel7S35JyF2BQ9KzbTv = KEumynHOTt51Q0R29fsDox
		if qG2ilF48CpIhE0DMQcna: cHRaG042IpX8FhOKwE.append(qG2ilF48CpIhE0DMQcna)
	cHRaG042IpX8FhOKwE = list(set(cHRaG042IpX8FhOKwE))
	if not nmREDwuel7S35JyF2BQ9KzbTv and len(cHRaG042IpX8FhOKwE)==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		tOZC4fvKDPxwFmlTI6N9askGiX = cHRaG042IpX8FhOKwE[ZVNvqy4iF1a9X]
		if tOZC4fvKDPxwFmlTI6N9askGiX!=zz679V18GdcZwvrRexA0nNptY2Tab(u"࠷࠶࠰෷"):
			if tOZC4fvKDPxwFmlTI6N9askGiX<ZVNvqy4iF1a9X: nmREDwuel7S35JyF2BQ9KzbTv = O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ࡜ࡩࡥࡧࡲࠤࡵࡧࡧࡦ࠱ࡶࡩࡷࡼࡥࡳࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡤࡧࡨ࡫ࡳࡴ࡫ࡥࡰࡪ࠭൫")
			else:
				nmREDwuel7S35JyF2BQ9KzbTv = mi2ZJXCDzITuyev6gfn(u"࠭ࡈࡕࡖࡓࠤࡊࡸࡲࡰࡴ࠽ࠤࠬ൬")+str(tOZC4fvKDPxwFmlTI6N9askGiX)
				if A7Z6OVh20eCEUx: import http.client as DFGJctK0N8wg7a4HxqSzI2Ob
				else: import httplib as DFGJctK0N8wg7a4HxqSzI2Ob
				try: nmREDwuel7S35JyF2BQ9KzbTv += KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࠡࠪࠣࠫ൭")+DFGJctK0N8wg7a4HxqSzI2Ob.responses[tOZC4fvKDPxwFmlTI6N9askGiX]+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࠢࠬࠫ൮")
				except: pass
	L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
	return nmREDwuel7S35JyF2BQ9KzbTv,Uz8mMbZifCyvkLnct,MNXzjK3vV7D
class ODE3jFQ9T8aNKimGSPo6xBhLyUC5(rTF8V7fLD2SXJbAURpZjQ4wH.WindowDialog):
	def __init__(TW54k08qYHAVnOKXmhbf, *args, **SrtHZ8aVe6TjKok24bIiPuxyD):
		LLXzrdAhm18pyk0I6tHuiq9gD = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X, zQGaM7ctZCN(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬ൯"), pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧ൰"), cjVhOCwybeRo7UWg92(u"ࠫࡩ࡯ࡡ࡭ࡱࡪࡦ࡬࠴ࡰ࡯ࡩࠪ൱"))
		llYOBiT5gsu0Ut = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X, E6xdOMpqISHZCn(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ൲"), HaTI5u1f3SCxmMAkw(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪ൳"), mi2ZJXCDzITuyev6gfn(u"ࠧࡴࡧ࡯ࡩࡨࡺࡥࡥ࠰ࡳࡲ࡬࠭൴"))
		V3ygPi4XNHL = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X, GISOTJh20W(u"ࠨࡴࡨࡷࡴࡻࡲࡤࡧࡶࠫ൵"), TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠷࠭൶"), E6xdOMpqISHZCn(u"ࠪࡦࡺࡺࡴࡰࡰࡩࡳ࠳ࡶ࡮ࡨࠩ൷"))
		cMB4SZhPTiA5VLtyj2EK0IX = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X, rC5tnFDlQcRGA2(u"ࠫࡷ࡫ࡳࡰࡷࡵࡧࡪࡹࠧ൸"), VVvcQpCU3OM09n(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠳ࠩ൹"), pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡢࡶࡶࡷࡳࡳࡴࡦ࠯ࡲࡱ࡫ࠬൺ"))
		nHygu2BQahsUwZqizTGr5Pp41m08bE = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X, ZP1LyUCS3pIBu(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪൻ"), TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬർ"), yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡥࡹࡹࡺ࡯࡯ࡤࡪ࠲ࡵࡴࡧࠨൽ"))
		TW54k08qYHAVnOKXmhbf.cancelled = VJZIMkUN5siqB21Pf
		TW54k08qYHAVnOKXmhbf.chk = [ZVNvqy4iF1a9X] * TMfV6892ZoBdyxCH3tGrkwY0K(u"࠿෸")
		TW54k08qYHAVnOKXmhbf.chkbutton = [ZVNvqy4iF1a9X] * VVvcQpCU3OM09n(u"࠹෹")
		TW54k08qYHAVnOKXmhbf.chkstate = [VJZIMkUN5siqB21Pf] * XB4CjMkPFzhAHiI3q(u"࠺෺")
		W5GLbI1YknTjepV64tASi3g8, qAPwLv3X2DTrkBiISltWZ, hAkeNcr4DZ5wIYdmz, EE6icateITHYuM = h6sIkJOT5PB2vCxqo4LFag70wA(u"࠴࠸࠴෻"), ZVNvqy4iF1a9X, yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠺࠴࠵෼"), cbmeD4WNZfAowxT2JdUMtV(u"࠻࠻࠶෽")
		XJxilOmD4Z = W5GLbI1YknTjepV64tASi3g8+hAkeNcr4DZ5wIYdmz//VTadWjBloMwXO2CH9GDK6FR
		NdZ9DRQwmJUH, d1DMbQKiG2OFWaY8Un0, pw2kIViHsdZPRXD7GtvU, uQ0rUpFlLXoV8kYM = cjVhOCwybeRo7UWg92(u"࠹࠵࠶෿"), GISOTJh20W(u"࠶࠸࠰෾"), cbmeD4WNZfAowxT2JdUMtV(u"࠵࠱࠲฀"), cbmeD4WNZfAowxT2JdUMtV(u"࠵࠱࠲฀")
		F5RS7hX9BDucI4aCmwQlAU0ZiE = NdZ9DRQwmJUH+pw2kIViHsdZPRXD7GtvU//VTadWjBloMwXO2CH9GDK6FR
		rnzWCkym61ULoSP, FvDaHKcmrukNhjZCdt47GRJ, RpTnBWgzwXjMZ, KfeUBMWt1NJqTVwXFcm3Cg9u87Y0oy = zQGaM7ctZCN(u"࠳࠳࠴ข"), zQGaM7ctZCN(u"࠹࠹࠺ฃ"), CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠲࠷࠳ก"), TMfV6892ZoBdyxCH3tGrkwY0K(u"࠹࠵ค")
		MVBymIqRicvJF5PnKapYs2 = XJxilOmD4Z-RpTnBWgzwXjMZ-rnzWCkym61ULoSP//VTadWjBloMwXO2CH9GDK6FR
		pJ5U1q9c4w = XJxilOmD4Z+rnzWCkym61ULoSP//VTadWjBloMwXO2CH9GDK6FR
		wLWuY8QGmJD9Alr61gPMypoc3hTz, HdP6RqYvTGZ4EmiWzDf, VOLhYKjPC4TdbamXrwpDi, s5nSuWcXoTeih0yMbI2UvE41O = h6sIkJOT5PB2vCxqo4LFag70wA(u"࠸࠻࠵ฅ"), EcjO3giln2kQTdBY0XLAG(u"࠹࠰ฆ"), KA26GucUHOwXL(u"࠶࠲࠳จ"), yUMRP0QKIzY9BDnsV784TZmwkf(u"࠵࠱ง")
		mNc8A5ZCKsj7rJHX3TDPifUYgGuBFE, zhKQ7DWuINR, ffgIaiQGUS9uqVw0dx56, Sh5m0WT3cRXoxzaUJ = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠵࠸࠹ฉ"), yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠼࠶ฌ"), Olh7n0zfV4(u"࠹࠵࠶ซ"), zz679V18GdcZwvrRexA0nNptY2Tab(u"࠸࠴ช")
		fibKYIHB0xZC52op = JACnOz297UuDK5HpPkc1LF(u"࠶࠮࠺ญ")
		W5GLbI1YknTjepV64tASi3g8, qAPwLv3X2DTrkBiISltWZ, hAkeNcr4DZ5wIYdmz, EE6icateITHYuM = int(W5GLbI1YknTjepV64tASi3g8*fibKYIHB0xZC52op), int(qAPwLv3X2DTrkBiISltWZ*fibKYIHB0xZC52op), int(hAkeNcr4DZ5wIYdmz*fibKYIHB0xZC52op), int(EE6icateITHYuM*fibKYIHB0xZC52op)
		NdZ9DRQwmJUH, d1DMbQKiG2OFWaY8Un0, pw2kIViHsdZPRXD7GtvU, uQ0rUpFlLXoV8kYM = int(NdZ9DRQwmJUH*fibKYIHB0xZC52op), int(d1DMbQKiG2OFWaY8Un0*fibKYIHB0xZC52op), int(pw2kIViHsdZPRXD7GtvU*fibKYIHB0xZC52op), int(uQ0rUpFlLXoV8kYM*fibKYIHB0xZC52op)
		MVBymIqRicvJF5PnKapYs2, q0tefAu4X7KcTsDi, c4LUpjtXSRdWNghV2, iEHtzWToVcIDR4BGYvSh = int(MVBymIqRicvJF5PnKapYs2*fibKYIHB0xZC52op), int(FvDaHKcmrukNhjZCdt47GRJ*fibKYIHB0xZC52op), int(RpTnBWgzwXjMZ*fibKYIHB0xZC52op), int(KfeUBMWt1NJqTVwXFcm3Cg9u87Y0oy*fibKYIHB0xZC52op)
		pJ5U1q9c4w, MMLmrEpH9d5fcwA, rTAoFLm0Wn2jvDZctYq5GMugRU, ZSN86jpoCk04FsqzaVyRwX = int(pJ5U1q9c4w*fibKYIHB0xZC52op), int(FvDaHKcmrukNhjZCdt47GRJ*fibKYIHB0xZC52op), int(RpTnBWgzwXjMZ*fibKYIHB0xZC52op), int(KfeUBMWt1NJqTVwXFcm3Cg9u87Y0oy*fibKYIHB0xZC52op)
		wLWuY8QGmJD9Alr61gPMypoc3hTz, HdP6RqYvTGZ4EmiWzDf, VOLhYKjPC4TdbamXrwpDi, s5nSuWcXoTeih0yMbI2UvE41O = int(wLWuY8QGmJD9Alr61gPMypoc3hTz*fibKYIHB0xZC52op), int(HdP6RqYvTGZ4EmiWzDf*fibKYIHB0xZC52op), int(VOLhYKjPC4TdbamXrwpDi*fibKYIHB0xZC52op), int(s5nSuWcXoTeih0yMbI2UvE41O*fibKYIHB0xZC52op)
		mNc8A5ZCKsj7rJHX3TDPifUYgGuBFE, zhKQ7DWuINR, ffgIaiQGUS9uqVw0dx56, Sh5m0WT3cRXoxzaUJ = int(mNc8A5ZCKsj7rJHX3TDPifUYgGuBFE*fibKYIHB0xZC52op), int(zhKQ7DWuINR*fibKYIHB0xZC52op), int(ffgIaiQGUS9uqVw0dx56*fibKYIHB0xZC52op), int(Sh5m0WT3cRXoxzaUJ*fibKYIHB0xZC52op)
		Mk2R9vxf6cSluH1X = rTF8V7fLD2SXJbAURpZjQ4wH.ControlImage(W5GLbI1YknTjepV64tASi3g8, qAPwLv3X2DTrkBiISltWZ, hAkeNcr4DZ5wIYdmz, EE6icateITHYuM, LLXzrdAhm18pyk0I6tHuiq9gD)
		TW54k08qYHAVnOKXmhbf.addControl(Mk2R9vxf6cSluH1X)
		TW54k08qYHAVnOKXmhbf.iteration = SrtHZ8aVe6TjKok24bIiPuxyD.get(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ࡭ࡹ࡫ࡲࡢࡶ࡬ࡳࡳ࠭ൾ"))
		jpM69u1GF3LkWiZt4R = Ym6q5M4TocDaA013RjFQ+o2FdrDBimMuOw97q6QpNW8S(u"ࠫๆำีࠡล้หࠥหๆิษ้ࠤํ๊ำหࠢิ์อ๎สࠡࠢࠣࠤࠥࠦࠠࠡࠢࠪൿ")+TDpFsQXHze2q30uYtGPfEIm8(u"ࠬอไๆฯส์้ฯࠠาไ่ࠤࠥ࠭඀")+str(TW54k08qYHAVnOKXmhbf.iteration)+oOQaRxBXyJ5jVnZ
		TW54k08qYHAVnOKXmhbf.strActionInfo = rTF8V7fLD2SXJbAURpZjQ4wH.ControlLabel(wLWuY8QGmJD9Alr61gPMypoc3hTz, HdP6RqYvTGZ4EmiWzDf, VOLhYKjPC4TdbamXrwpDi, s5nSuWcXoTeih0yMbI2UvE41O, jpM69u1GF3LkWiZt4R, zQGaM7ctZCN(u"࠭ࡦࡰࡰࡷ࠵࠸࠭ඁ"))
		TW54k08qYHAVnOKXmhbf.addControl(TW54k08qYHAVnOKXmhbf.strActionInfo)
		hzGKUP1XjAoeT79MJcDF = rTF8V7fLD2SXJbAURpZjQ4wH.ControlImage(NdZ9DRQwmJUH, d1DMbQKiG2OFWaY8Un0, pw2kIViHsdZPRXD7GtvU, uQ0rUpFlLXoV8kYM, SrtHZ8aVe6TjKok24bIiPuxyD.get(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡤࡣࡳࡸࡨ࡮ࡡࠨං")))
		TW54k08qYHAVnOKXmhbf.addControl(hzGKUP1XjAoeT79MJcDF)
		Eoq7P8Jfk0 = Ym6q5M4TocDaA013RjFQ+SrtHZ8aVe6TjKok24bIiPuxyD.get(yylSaxCLfkte(u"ࠨ࡯ࡶ࡫ࠬඃ"))+oOQaRxBXyJ5jVnZ
		TW54k08qYHAVnOKXmhbf.strActionInfo = rTF8V7fLD2SXJbAURpZjQ4wH.ControlLabel(mNc8A5ZCKsj7rJHX3TDPifUYgGuBFE, zhKQ7DWuINR, ffgIaiQGUS9uqVw0dx56, Sh5m0WT3cRXoxzaUJ, Eoq7P8Jfk0, zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡩࡳࡳࡺ࠱࠴ࠩ඄"))
		TW54k08qYHAVnOKXmhbf.addControl(TW54k08qYHAVnOKXmhbf.strActionInfo)
		text = Ym6q5M4TocDaA013RjFQ+mi2ZJXCDzITuyev6gfn(u"ࠪาึ๎ฬࠨඅ")+oOQaRxBXyJ5jVnZ
		TW54k08qYHAVnOKXmhbf.cancelbutton = rTF8V7fLD2SXJbAURpZjQ4wH.ControlButton(MVBymIqRicvJF5PnKapYs2, q0tefAu4X7KcTsDi, c4LUpjtXSRdWNghV2, iEHtzWToVcIDR4BGYvSh, text, focusTexture=nHygu2BQahsUwZqizTGr5Pp41m08bE, noFocusTexture=V3ygPi4XNHL, alignment=otNfFapeEnO(u"࠲ฎ"))
		text = Ym6q5M4TocDaA013RjFQ+O4F8UC5lMAS6ghETm1VoPDI(u"ࠫฬูสๆำสีࠬආ")+oOQaRxBXyJ5jVnZ
		TW54k08qYHAVnOKXmhbf.okbutton = rTF8V7fLD2SXJbAURpZjQ4wH.ControlButton(pJ5U1q9c4w, MMLmrEpH9d5fcwA, rTAoFLm0Wn2jvDZctYq5GMugRU, ZSN86jpoCk04FsqzaVyRwX, text, focusTexture=nHygu2BQahsUwZqizTGr5Pp41m08bE, noFocusTexture=V3ygPi4XNHL, alignment=VVvcQpCU3OM09n(u"࠳ฏ"))
		TW54k08qYHAVnOKXmhbf.addControl(TW54k08qYHAVnOKXmhbf.okbutton)
		TW54k08qYHAVnOKXmhbf.addControl(TW54k08qYHAVnOKXmhbf.cancelbutton)
		mW5f7VHNYG0MQpkOqyzKoainEA9tR, Yx4el7MKcJwU3iAmL2j5psWOSy6gF = uQ0rUpFlLXoV8kYM//D9yBM7wPFLz, pw2kIViHsdZPRXD7GtvU//D9yBM7wPFLz
		for PMTRpXQvDIkiNszwYGnb32a in range(mi2ZJXCDzITuyev6gfn(u"࠻ฐ")):
			nquAs1mNjM3QUwICD7cx2f = PMTRpXQvDIkiNszwYGnb32a // D9yBM7wPFLz
			iR04CkdHDjWN = PMTRpXQvDIkiNszwYGnb32a % D9yBM7wPFLz
			UbSWguLAcV = NdZ9DRQwmJUH + (Yx4el7MKcJwU3iAmL2j5psWOSy6gF * iR04CkdHDjWN)
			uy2GMlSLA6K87hFNCIUWwqiHmZ = d1DMbQKiG2OFWaY8Un0 + (mW5f7VHNYG0MQpkOqyzKoainEA9tR * nquAs1mNjM3QUwICD7cx2f)
			TW54k08qYHAVnOKXmhbf.chk[PMTRpXQvDIkiNszwYGnb32a] = rTF8V7fLD2SXJbAURpZjQ4wH.ControlImage(UbSWguLAcV, uy2GMlSLA6K87hFNCIUWwqiHmZ, Yx4el7MKcJwU3iAmL2j5psWOSy6gF, mW5f7VHNYG0MQpkOqyzKoainEA9tR, llYOBiT5gsu0Ut)
			TW54k08qYHAVnOKXmhbf.addControl(TW54k08qYHAVnOKXmhbf.chk[PMTRpXQvDIkiNszwYGnb32a])
			TW54k08qYHAVnOKXmhbf.chk[PMTRpXQvDIkiNszwYGnb32a].setVisible(VJZIMkUN5siqB21Pf)
			TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a] = rTF8V7fLD2SXJbAURpZjQ4wH.ControlButton(UbSWguLAcV, uy2GMlSLA6K87hFNCIUWwqiHmZ, Yx4el7MKcJwU3iAmL2j5psWOSy6gF, mW5f7VHNYG0MQpkOqyzKoainEA9tR, str(PMTRpXQvDIkiNszwYGnb32a + P2Fgh6TCOWoaHjkqBcQnvRNXe), font=XB4CjMkPFzhAHiI3q(u"ࠬ࡬࡯࡯ࡶ࠴࠷ࠬඇ"), focusTexture=V3ygPi4XNHL, noFocusTexture=cMB4SZhPTiA5VLtyj2EK0IX)
			TW54k08qYHAVnOKXmhbf.addControl(TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a])
		for PMTRpXQvDIkiNszwYGnb32a in range(otNfFapeEnO(u"࠼ฑ")):
			WHPDaOsJA4gL1M0qTEwY = (PMTRpXQvDIkiNszwYGnb32a // D9yBM7wPFLz) * D9yBM7wPFLz
			AAf8Moeu2lapxB1nEJZt4GSiqDXh3s = WHPDaOsJA4gL1M0qTEwY + (PMTRpXQvDIkiNszwYGnb32a + P2Fgh6TCOWoaHjkqBcQnvRNXe) % D9yBM7wPFLz
			XUn0qmPhQgs7exkp91 = WHPDaOsJA4gL1M0qTEwY + (PMTRpXQvDIkiNszwYGnb32a - P2Fgh6TCOWoaHjkqBcQnvRNXe) % D9yBM7wPFLz
			Tgfxi879mJ = (PMTRpXQvDIkiNszwYGnb32a - D9yBM7wPFLz) % KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠽ฒ")
			z0KmhnPxM4gV3CA = (PMTRpXQvDIkiNszwYGnb32a + D9yBM7wPFLz) % CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠾ณ")
			TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a].controlRight(TW54k08qYHAVnOKXmhbf.chkbutton[AAf8Moeu2lapxB1nEJZt4GSiqDXh3s])
			TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a].controlLeft(TW54k08qYHAVnOKXmhbf.chkbutton[XUn0qmPhQgs7exkp91])
			if PMTRpXQvDIkiNszwYGnb32a <= VTadWjBloMwXO2CH9GDK6FR:
				TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a].controlUp(TW54k08qYHAVnOKXmhbf.okbutton)
			else:
				TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a].controlUp(TW54k08qYHAVnOKXmhbf.chkbutton[Tgfxi879mJ])
			if PMTRpXQvDIkiNszwYGnb32a >= yUMRP0QKIzY9BDnsV784TZmwkf(u"࠼ด"):
				TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a].controlDown(TW54k08qYHAVnOKXmhbf.okbutton)
			else:
				TW54k08qYHAVnOKXmhbf.chkbutton[PMTRpXQvDIkiNszwYGnb32a].controlDown(TW54k08qYHAVnOKXmhbf.chkbutton[z0KmhnPxM4gV3CA])
		TW54k08qYHAVnOKXmhbf.okbutton.controlLeft(TW54k08qYHAVnOKXmhbf.cancelbutton)
		TW54k08qYHAVnOKXmhbf.okbutton.controlRight(TW54k08qYHAVnOKXmhbf.cancelbutton)
		TW54k08qYHAVnOKXmhbf.cancelbutton.controlLeft(TW54k08qYHAVnOKXmhbf.okbutton)
		TW54k08qYHAVnOKXmhbf.cancelbutton.controlRight(TW54k08qYHAVnOKXmhbf.okbutton)
		TW54k08qYHAVnOKXmhbf.okbutton.controlDown(TW54k08qYHAVnOKXmhbf.chkbutton[VTadWjBloMwXO2CH9GDK6FR])
		TW54k08qYHAVnOKXmhbf.okbutton.controlUp(TW54k08qYHAVnOKXmhbf.chkbutton[HaTI5u1f3SCxmMAkw(u"࠸ต")])
		TW54k08qYHAVnOKXmhbf.cancelbutton.controlDown(TW54k08qYHAVnOKXmhbf.chkbutton[ZVNvqy4iF1a9X])
		TW54k08qYHAVnOKXmhbf.cancelbutton.controlUp(TW54k08qYHAVnOKXmhbf.chkbutton[rC5tnFDlQcRGA2(u"࠷ถ")])
		TW54k08qYHAVnOKXmhbf.setFocus(TW54k08qYHAVnOKXmhbf.okbutton)
	def get(TW54k08qYHAVnOKXmhbf):
		TW54k08qYHAVnOKXmhbf.doModal()
		TW54k08qYHAVnOKXmhbf.close()
		if not TW54k08qYHAVnOKXmhbf.cancelled:
			return [PMTRpXQvDIkiNszwYGnb32a for PMTRpXQvDIkiNszwYGnb32a in range(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠻ท")) if TW54k08qYHAVnOKXmhbf.chkstate[PMTRpXQvDIkiNszwYGnb32a]]
	def onControl(TW54k08qYHAVnOKXmhbf, GFlgLyXuJV2foT8U7vp5):
		if GFlgLyXuJV2foT8U7vp5.getId() == TW54k08qYHAVnOKXmhbf.okbutton.getId() and any(TW54k08qYHAVnOKXmhbf.chkstate):
			TW54k08qYHAVnOKXmhbf.close()
		elif GFlgLyXuJV2foT8U7vp5.getId() == TW54k08qYHAVnOKXmhbf.cancelbutton.getId():
			TW54k08qYHAVnOKXmhbf.cancelled = w2qb6lf5EM
			TW54k08qYHAVnOKXmhbf.close()
		else:
			m9wgSl1oUVRd = GFlgLyXuJV2foT8U7vp5.getLabel()
			if m9wgSl1oUVRd.isnumeric():
				index = int(m9wgSl1oUVRd) - P2Fgh6TCOWoaHjkqBcQnvRNXe
				TW54k08qYHAVnOKXmhbf.chkstate[index] = not TW54k08qYHAVnOKXmhbf.chkstate[index]
				TW54k08qYHAVnOKXmhbf.chk[index].setVisible(TW54k08qYHAVnOKXmhbf.chkstate[index])
	def onAction(TW54k08qYHAVnOKXmhbf, eeqpSKuXbQxUMkC3RIdBr1tW2):
		if eeqpSKuXbQxUMkC3RIdBr1tW2 == CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠴࠴ธ"):
			TW54k08qYHAVnOKXmhbf.cancelled = w2qb6lf5EM
			TW54k08qYHAVnOKXmhbf.close()
def P49KnYr5bEVmfxB(key,qqU8ZQfsNRWFGhKkjm6d4rAPHvg,url):
	headers = {otNfFapeEnO(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧඈ"):url,E6xdOMpqISHZCn(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩඉ"):qqU8ZQfsNRWFGhKkjm6d4rAPHvg}
	mgiG4h7jLUE5 = O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠴ࡧࡰࡪ࠱ࡩࡥࡱࡲࡢࡢࡥ࡮ࡃࡰࡃࠧඊ")+key
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡊࡉ࡙࠭උ"),mgiG4h7jLUE5,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡆࡖࡢࡖࡊࡉࡁࡑࡖࡆࡌࡆ࠸࡟ࡕࡑࡎࡉࡓ࠳࠱ࡴࡶࠪඌ"))
	eOVb64kRWwArpNmu5CLXtzfDF,iteration = CJlTSEpZsWb0QHg5w,ZVNvqy4iF1a9X
	while w2qb6lf5EM:
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		wSfEHOilLYIK = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠫࠧ࠮࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠲࠰ࡲࡤࡽࡱࡵࡡࡥ࡝ࡡࠦࡢ࠱ࠩࠨඍ"), bGIVq1CQTjmosZg)
		iteration += P2Fgh6TCOWoaHjkqBcQnvRNXe
		message = Zy2l0g8QU5vqefaTrsw.findall(pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡂ࡬ࡢࡤࡨࡰࡠࡤ࠾࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡩࡦࡨ࠳ࡩ࡮ࡣࡪࡩࡸ࡫࡬ࡦࡥࡷ࠱ࡲ࡫ࡳࡴࡣࡪࡩ࠲ࡺࡥࡹࡶࠥ࡟ࡣࡄ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯ࡥࡧ࡫࡬࠿ࠩඎ"), bGIVq1CQTjmosZg)
		if not message: message = Zy2l0g8QU5vqefaTrsw.findall(pz4WBwfyDdgk0m2aRr7SMv(u"࠭࠼ࡥ࡫ࡹ࡟ࡣࡄ࡝ࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡥࡧ࠲࡯࡭ࡢࡩࡨࡷࡪࡲࡥࡤࡶ࠰ࡱࡪࡹࡳࡢࡩࡨ࠱ࡪࡸࡲࡰࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩඏ"), bGIVq1CQTjmosZg)
		if not message:
			eOVb64kRWwArpNmu5CLXtzfDF = Zy2l0g8QU5vqefaTrsw.findall(cjVhOCwybeRo7UWg92(u"ࠧࡳࡧࡤࡨࡴࡴ࡬ࡺࡀࠫ࠲࠯ࡅࠩ࠽ࠩඐ"), bGIVq1CQTjmosZg)[ZVNvqy4iF1a9X]
			break
		else:
			message = message[ZVNvqy4iF1a9X]
			wSfEHOilLYIK = wSfEHOilLYIK[ZVNvqy4iF1a9X]
		YyanKDkEt59AW2gVSsjXf6NoQmOGl = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"ࡳࠩࡱࡥࡲ࡫࠽ࠣࡥࠥࡠࡸ࠱ࡶࡢ࡮ࡸࡩࡂࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠧඑ"), bGIVq1CQTjmosZg)[ZVNvqy4iF1a9X]
		rgAkqEzbfoQTxGVyZ = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰࠩࡸ࠭ඒ") % (wSfEHOilLYIK.replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࠪࡦࡳࡰ࠼ࠩඓ"), KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࠫ࠭ඔ")))
		message = Zy2l0g8QU5vqefaTrsw.sub(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡂ࠯ࡀࠪࡧ࡭ࡻࢂࡳࡵࡴࡲࡲ࡬࠯࡛࡟ࡀࡠ࠮ࡃ࠭ඕ"), CJlTSEpZsWb0QHg5w, message)
		F0CDdNbXunsKPIvqhAY = ODE3jFQ9T8aNKimGSPo6xBhLyUC5(captcha=rgAkqEzbfoQTxGVyZ, msg=message, iteration=iteration)
		HHRs2fDdbWGvk6Vj3zJlw = F0CDdNbXunsKPIvqhAY.get()
		if not HHRs2fDdbWGvk6Vj3zJlw: break
		data = {zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ࡣࠨඖ"): YyanKDkEt59AW2gVSsjXf6NoQmOGl, VVvcQpCU3OM09n(u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ඗"): HHRs2fDdbWGvk6Vj3zJlw}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡒࡒࡗ࡙࠭඘"),mgiG4h7jLUE5,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡅࡕࡡࡕࡉࡈࡇࡐࡕࡅࡋࡅ࠷ࡥࡔࡐࡍࡈࡒ࠲࠸࡮ࡥࠩ඙"))
	return eOVb64kRWwArpNmu5CLXtzfDF
def XwFjnODH5QSq1y6ZeBvCExf(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡃࡅࡐࡔࡇࡄࡔ࠯࠴ࡷࡹ࠭ක"))
	items = Zy2l0g8QU5vqefaTrsw.findall(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡨࡵ࡬ࡰࡴࡀࠦࡷ࡫ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩඛ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ items[ZVNvqy4iF1a9X] ]
	else: return CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡄࡆࡑࡕࡁࡅࡕࠪග"),[],[]
def cgQRVawEnx1F63yBIG7W2ie09Np8h(url):
	return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
def ttfBqgSJKyj(url):
	FFtJQalhPz = url.split(s97s2k0LJgl(u"࠭࠯ࠨඝ"))
	hgGSucEaTmiCWp1b9x = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠰ࠩඞ").join(FFtJQalhPz[ZVNvqy4iF1a9X:D9yBM7wPFLz])
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅ࠮࠳ࡶࡸࠬඟ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡧࡰࡧࡻࡴࡵࡱࡱࡠࠬࡢࠩ࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠢ࡟࠯ࠥࡢࠨࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩࠡ࡞࠮ࠤ࠭࠴ࠪࡀࠫࠣࡠࠪࠦࠨ࠯ࠬࡂ࠭ࡡ࠯ࠠ࡝࠭ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫච"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm,M0WAfXLaJseRbYZHPg4Kqh,QQrpsvmYB3qD7haTcoRG1OMEU0j,oGJLa5jrDBpCxITtd,DSwvgjdGc0tBMLeRVaCAYfINu9r3 = items[ZVNvqy4iF1a9X]
		bqCtj61hiYBzsUvGA = int(p2M53kf1DrH4Tm) % int(M0WAfXLaJseRbYZHPg4Kqh) + int(QQrpsvmYB3qD7haTcoRG1OMEU0j) % int(oGJLa5jrDBpCxITtd)
		url = hgGSucEaTmiCWp1b9x + zKUM1soNxBQCYLe87PD4uryqZT5H3b + str(bqCtj61hiYBzsUvGA) + DSwvgjdGc0tBMLeRVaCAYfINu9r3
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[url]
	else: return yylSaxCLfkte(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠩඡ"),[],[]
def bZu5x2MLmV9WTAKpeGE7gICQBj6y(url):
	id = url.split(KA26GucUHOwXL(u"ࠫ࠴࠭ජ"))[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
	headers = { KA26GucUHOwXL(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫඣ") : VVvcQpCU3OM09n(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬඤ") }
	wSfEHOilLYIK = { ZP1LyUCS3pIBu(u"ࠢࡪࡦࠥඥ"):id , KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠣࡱࡳࠦඦ"):E6xdOMpqISHZCn(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠧට") }
	RjVAI6uzxFofm7qv = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡔࡔ࡙ࡔࠨඨ"), url, wSfEHOilLYIK, headers, CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧඩ"))
	if VVvcQpCU3OM09n(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧඪ") in list(RjVAI6uzxFofm7qv.headers.keys()): ZgsbN5iSL48t2IhVFnmy = RjVAI6uzxFofm7qv.headers[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨණ")]
	else: ZgsbN5iSL48t2IhVFnmy = url
	if ZgsbN5iSL48t2IhVFnmy: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ZgsbN5iSL48t2IhVFnmy]
	else: return otNfFapeEnO(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡐࡔ࠹࡛ࡐࡍࡑࡄࡈࠬඬ"),[],[]
def cxRDzIp0bsvM5mwP214U7OTXAkn9(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡏࡎࡕࡘࡏࡍ࡛ࡋ࠭࠲ࡵࡷࠫත"))
	items = Zy2l0g8QU5vqefaTrsw.findall(GISOTJh20W(u"ࠩࡰࡴ࠹ࡀࠠ࡝࡝࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬථ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ items[ZVNvqy4iF1a9X] ]
	else: return yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠨද"),[],[]
def TKDvJi4HbdNXBOf(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡆࡌࡎ࡜ࡅ࠮࠳ࡶࡸࠬධ"))
	items = Zy2l0g8QU5vqefaTrsw.findall(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪන"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		url = url = cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡦ࡬࡮ࡼࡥ࠯ࡱࡵ࡫ࠬ඲") + items[ZVNvqy4iF1a9X]
		return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ url ]
	else: return KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡈࡎࡉࡗࡇࠪඳ"),[],[]
def mdUr4QoKOg(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊ࡙ࡔࡓࡇࡄࡑ࠲࠷ࡳࡵࠩප"))
	items = Zy2l0g8QU5vqefaTrsw.findall(KA26GucUHOwXL(u"ࠩࡹ࡭ࡩ࡫࡯ࠡࡲࡵࡩࡱࡵࡡࡥ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩඵ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items: return CJlTSEpZsWb0QHg5w,[CJlTSEpZsWb0QHg5w],[ items[ZVNvqy4iF1a9X] ]
	else: return VVvcQpCU3OM09n(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡓࡕࡔࡈࡅࡒ࠭බ"),[],[]
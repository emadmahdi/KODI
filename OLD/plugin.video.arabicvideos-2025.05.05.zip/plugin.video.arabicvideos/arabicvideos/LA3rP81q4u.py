# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
import xbmc as pKVikfGen4wMt80UTscxWjAoCZ5S,re as Zy2l0g8QU5vqefaTrsw,sys as A8v6c2fL7egwWCF3YBqr4kXSRn,xbmcaddon as BDgtaC2sJxV7Efq5,random as D5fy1ouOjwT9RXlH4IEhe3dMPmaxz,os as tiFgl4DMvGEAUfjIYkHbr05,xbmcvfs as xtcZXNgkYM8wFOpCo70dl6HqRs,time as L8Wkv5KCSoq,pickle as oMXjhciyrP,zlib as BBxt0yrLpJSHvc57i,xbmcgui as rTF8V7fLD2SXJbAURpZjQ4wH,xbmcplugin as ZqpKwnSTtsNmWYCfueOxd14,sqlite3 as Izg3hVy4Nx1oOU6L29DFkmqnZ,traceback as Do276qcOfXz8l,threading as CCARSBDXLj0NFfpu14,hashlib as jRBlVKHJ7fOx,json as KSHcVmz2W84iQvbRDBhGldpCL
from EcRxvVj7hw import *
import Ew2zQ8u7Ss
T1QDsJlUtCGhn = mi2ZJXCDzITuyev6gfn(u"ࠫࡑࡏࡂࡔࡑࡑࡉࠬ௰")
cizLW9VxEA2Nkqj7wtspB8HyT1X = BDgtaC2sJxV7Efq5.Addon().getAddonInfo(E6xdOMpqISHZCn(u"ࠬࡶࡡࡵࡪࠪ௱"))
jadA2Gzb9ri4onxk = tiFgl4DMvGEAUfjIYkHbr05.path.join(cizLW9VxEA2Nkqj7wtspB8HyT1X,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡰࡢࡥ࡮ࡥ࡬࡫ࡳࠨ௲"))
A8v6c2fL7egwWCF3YBqr4kXSRn.path.append(jadA2Gzb9ri4onxk)
uZYhUVqxz4Itp7MRSD3JkXGlrL = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(Olh7n0zfV4(u"ࠢࡔࡻࡶࡸࡪࡳ࠮ࡃࡷ࡬ࡰࡩ࡜ࡥࡳࡵ࡬ࡳࡳࠨ௳"))
K9MoWfyg6w2EHIki4lLtFSzpxQTmRX = Zy2l0g8QU5vqefaTrsw.findall(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࠪ࡟ࡨࡡࡪ࡜࠯࡞ࡧ࠭ࠬ௴"),uZYhUVqxz4Itp7MRSD3JkXGlrL,Zy2l0g8QU5vqefaTrsw.DOTALL)
K9MoWfyg6w2EHIki4lLtFSzpxQTmRX = float(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX[ZVNvqy4iF1a9X])
fapzkK9oANLM8Xc0 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player
bdXCmFHx35lTsQwi6 = rTF8V7fLD2SXJbAURpZjQ4wH.WindowXMLDialog
BB7oCRfQNSYj5qDhTUevV = K9MoWfyg6w2EHIki4lLtFSzpxQTmRX<GISOTJh20W(u"࠶࠿ම")
A7Z6OVh20eCEUx = K9MoWfyg6w2EHIki4lLtFSzpxQTmRX>zQGaM7ctZCN(u"࠷࠸࠯࠻࠼ඹ")
if A7Z6OVh20eCEUx:
	BO4WDv2Zl5q13u76 = pKVikfGen4wMt80UTscxWjAoCZ5S.LOGINFO
	HCgURFmf8NvkYs2wnX,s6rxOhWUy0bXDdQMJleNmu = GISOTJh20W(u"ࡷࠪࡠࡺ࠸࠰࠳ࡣࠪ௵"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࡸࠫࡡࡻ࠲࠱࠴ࡥࠫ௶")
	fhV49mDA6YK0 = xtcZXNgkYM8wFOpCo70dl6HqRs.translatePath(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ௷"))
	from urllib.parse import unquote as _cnU6omDqZ5K0k4Yb
else:
	BO4WDv2Zl5q13u76 = pKVikfGen4wMt80UTscxWjAoCZ5S.LOGNOTICE
	HCgURFmf8NvkYs2wnX,s6rxOhWUy0bXDdQMJleNmu = mi2ZJXCDzITuyev6gfn(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡦ࠭௸").encode(Im5KSGZYBpRvdMVsbuXg),yylSaxCLfkte(u"ࡻࠧ࡝ࡷ࠵࠴࠷ࡨࠧ௹").encode(Im5KSGZYBpRvdMVsbuXg)
	fhV49mDA6YK0 = pKVikfGen4wMt80UTscxWjAoCZ5S.translatePath(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡸࡪࡳࡰࠨ௺"))
	from urllib import unquote as _cnU6omDqZ5K0k4Yb
R7xafKV3ekjDc = A8v6c2fL7egwWCF3YBqr4kXSRn.argv[ZVNvqy4iF1a9X].split(XB4CjMkPFzhAHiI3q(u"ࠨ࠱ࠪ௻"))[VTadWjBloMwXO2CH9GDK6FR]
b4qsaVwC0mHOGPKp5 = int(A8v6c2fL7egwWCF3YBqr4kXSRn.argv[P2Fgh6TCOWoaHjkqBcQnvRNXe])
zz4EDG1PtiyX3JVUlBeC = A8v6c2fL7egwWCF3YBqr4kXSRn.argv[VTadWjBloMwXO2CH9GDK6FR]
HH3OIALbdWJS9Uh = R7xafKV3ekjDc.split(zQGaM7ctZCN(u"ࠩ࠱ࠫ௼"))[VTadWjBloMwXO2CH9GDK6FR]
Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(mi2ZJXCDzITuyev6gfn(u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡘࡨࡶࡸ࡯࡯࡯ࠪࠪ௽")+R7xafKV3ekjDc+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫ࠮࠭௾"))
c2XOIv1RU6aSuAeiZ5Pgz9Gr = tiFgl4DMvGEAUfjIYkHbr05.path.join(fhV49mDA6YK0,R7xafKV3ekjDc)
NN4DuIqLH9iGesZocawQTUWm0E = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡳࡡࡪࡰࡧࡥࡹࡧ࠮ࡥࡤࠪ௿"))
mw5hKxvWDZSQ = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,pz4WBwfyDdgk0m2aRr7SMv(u"࠭࡬ࡢࡵࡷࡺ࡮ࡪࡥࡰࡵ࠱ࡨࡦࡺࠧఀ"))
U6YgVKS9rAmwe1RTPlQnfiGs = int(L8Wkv5KCSoq.time())
ZoM1Newq29g7aGnDmE5VSOA6itk3 = BDgtaC2sJxV7Efq5.Addon(id=R7xafKV3ekjDc)
LxrQ9fbltZaD8k7 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(VVvcQpCU3OM09n(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫఁ"))
ohkAjGeH2Rf6Vw4vNM8rJE3tlnO5d = VJZIMkUN5siqB21Pf if LxrQ9fbltZaD8k7==Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a else w2qb6lf5EM
def degRiWptawTqXvKNh(otaunYGVIJ2jX8HsKm7ecR0bAh4,tSkGin1CgWMfv5d8aXsoHl=zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡁࠪం")):
	if od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡀࠫః") in otaunYGVIJ2jX8HsKm7ecR0bAh4:
		if tSkGin1CgWMfv5d8aXsoHl in otaunYGVIJ2jX8HsKm7ecR0bAh4: BBwfuWGxUIrdCoc4ka7,BwTXOyDtRrUGNv = otaunYGVIJ2jX8HsKm7ecR0bAh4.split(tSkGin1CgWMfv5d8aXsoHl,cjVhOCwybeRo7UWg92(u"࠱ය"))
		else: BBwfuWGxUIrdCoc4ka7,BwTXOyDtRrUGNv = CJlTSEpZsWb0QHg5w,otaunYGVIJ2jX8HsKm7ecR0bAh4
		BwTXOyDtRrUGNv = BwTXOyDtRrUGNv.split(JACnOz297UuDK5HpPkc1LF(u"ࠪࠪࠬఄ"))
		s502yd81FCuJmLVBlkPtxih9fZDA = {}
		for uFxm6h5Yf8ZTMAORzS in BwTXOyDtRrUGNv:
			IVZCbl4keXui,s7DAv92CkQXqVPOGS3Bxn = uFxm6h5Yf8ZTMAORzS.split(GISOTJh20W(u"ࠫࡂ࠭అ"),cbmeD4WNZfAowxT2JdUMtV(u"࠲ර"))
			s502yd81FCuJmLVBlkPtxih9fZDA[IVZCbl4keXui] = s7DAv92CkQXqVPOGS3Bxn
	else: BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = otaunYGVIJ2jX8HsKm7ecR0bAh4,{}
	return BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA
def qmi8sS9rIkdBzjfu43UpPeVJh0oCAn(kuiZt5zMdvVJyC4LqwGDX):
	L5hzUqf43Dp6irjuyvYCsKxEkgd,ad3z2451e09FrDHmvci,PifcKsYgTyuML8bJqU = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	kuiZt5zMdvVJyC4LqwGDX = kuiZt5zMdvVJyC4LqwGDX.replace(HCgURFmf8NvkYs2wnX,CJlTSEpZsWb0QHg5w).replace(s6rxOhWUy0bXDdQMJleNmu,CJlTSEpZsWb0QHg5w)
	he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬ࠮࠮ࠪ࡞࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋ࠶࠸ࡄ࠳ࡉࡠࡢ࠮࡜ࡸ࡞ࡺࡠࡼ࠯ࠠࠬ࡞࡞ࡠ࠴ࡉࡏࡍࡑࡕࡠࡢ࠮࠮ࠫࡁࠬࠨࠬఆ"),kuiZt5zMdvVJyC4LqwGDX,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if he0wn71osQ8NCFJ9xzIqrDXBMRY: L5hzUqf43Dp6irjuyvYCsKxEkgd,ad3z2451e09FrDHmvci,kuiZt5zMdvVJyC4LqwGDX = he0wn71osQ8NCFJ9xzIqrDXBMRY[ZVNvqy4iF1a9X]
	if L5hzUqf43Dp6irjuyvYCsKxEkgd not in [YvOQBzaTAscXR9ql,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࠬࠨఇ"),CJlTSEpZsWb0QHg5w]: PifcKsYgTyuML8bJqU = TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡠࡏࡒࡈࡤ࠭ఈ")
	if ad3z2451e09FrDHmvci: ad3z2451e09FrDHmvci = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡡࠪఉ")+ad3z2451e09FrDHmvci+E6xdOMpqISHZCn(u"ࠩࡢࠫఊ")
	kuiZt5zMdvVJyC4LqwGDX = ad3z2451e09FrDHmvci+PifcKsYgTyuML8bJqU+kuiZt5zMdvVJyC4LqwGDX
	return kuiZt5zMdvVJyC4LqwGDX
def sWzgdLCjSVwaMuhFkNf1Uop(otaunYGVIJ2jX8HsKm7ecR0bAh4):
	return _cnU6omDqZ5K0k4Yb(otaunYGVIJ2jX8HsKm7ecR0bAh4)
def Ggp2PFN048WD7rRkC6Uqit(gqO71otbRlBjGsVfrinmT):
	xxKQoPvibtJRM86cYT7wC5BdkX = {cjVhOCwybeRo7UWg92(u"ࠪࡸࡾࡶࡥࠨఋ"):CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡲࡵࡤࡦࠩఌ"):CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"ࠬࡻࡲ࡭ࠩ఍"):CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"࠭ࡴࡦࡺࡷࠫఎ"):CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠧࡱࡣࡪࡩࠬఏ"):CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"ࠨࡰࡤࡱࡪ࠭ఐ"):CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"ࠩ࡬ࡱࡦ࡭ࡥࠨ఑"):CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫఒ"):CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫ࡮ࡴࡦࡰࡦ࡬ࡧࡹ࠭ఓ"):CJlTSEpZsWb0QHg5w}
	if cjVhOCwybeRo7UWg92(u"ࠬࡅࠧఔ") in gqO71otbRlBjGsVfrinmT: gqO71otbRlBjGsVfrinmT = gqO71otbRlBjGsVfrinmT.split(O4F8UC5lMAS6ghETm1VoPDI(u"࠭࠿ࠨక"),P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	BBwfuWGxUIrdCoc4ka7,tfN7EUKOVsIBTrPC0anQJ9eg1q = degRiWptawTqXvKNh(gqO71otbRlBjGsVfrinmT)
	aargs = dict(list(xxKQoPvibtJRM86cYT7wC5BdkX.items())+list(tfN7EUKOVsIBTrPC0anQJ9eg1q.items()))
	IZFnPiRjz6 = aargs[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧ࡮ࡱࡧࡩࠬఖ")]
	eijQF3OCM1UhZlsRynr8A = sWzgdLCjSVwaMuhFkNf1Uop(aargs[mi2ZJXCDzITuyev6gfn(u"ࠨࡷࡵࡰࠬగ")])
	uExN2ItKhmHpv0SJTXF5c8LM = sWzgdLCjSVwaMuhFkNf1Uop(aargs[yylSaxCLfkte(u"ࠩࡷࡩࡽࡺࠧఘ")])
	onsBg7uQyD5qfSWrR3UjH0lkLCM4 = sWzgdLCjSVwaMuhFkNf1Uop(aargs[o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡴࡦ࡭ࡥࠨఙ")])
	IvRjzalHbcZLBhCPfqXAG = sWzgdLCjSVwaMuhFkNf1Uop(aargs[TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡹࡿࡰࡦࠩచ")])
	WU62iESYnP7 = sWzgdLCjSVwaMuhFkNf1Uop(aargs[E6xdOMpqISHZCn(u"ࠬࡴࡡ࡮ࡧࠪఛ")])
	YUhfx4yF86DI = sWzgdLCjSVwaMuhFkNf1Uop(aargs[otNfFapeEnO(u"࠭ࡩ࡮ࡣࡪࡩࠬజ")])
	t6oXbkTdmAK = aargs[h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨఝ")]
	eegb6SjDKLWAfnIHplYQ4 = sWzgdLCjSVwaMuhFkNf1Uop(aargs[cbmeD4WNZfAowxT2JdUMtV(u"ࠨ࡫ࡱࡪࡴࡪࡩࡤࡶࠪఞ")])
	if eegb6SjDKLWAfnIHplYQ4: eegb6SjDKLWAfnIHplYQ4 = eval(eegb6SjDKLWAfnIHplYQ4)
	else: eegb6SjDKLWAfnIHplYQ4 = {}
	if not IZFnPiRjz6: IvRjzalHbcZLBhCPfqXAG = yylSaxCLfkte(u"ࠩࡩࡳࡱࡪࡥࡳࠩట") ; IZFnPiRjz6 = Olh7n0zfV4(u"ࠪ࠶࠻࠶ࠧఠ")
	return IvRjzalHbcZLBhCPfqXAG,WU62iESYnP7,eijQF3OCM1UhZlsRynr8A,IZFnPiRjz6,YUhfx4yF86DI,onsBg7uQyD5qfSWrR3UjH0lkLCM4,uExN2ItKhmHpv0SJTXF5c8LM,t6oXbkTdmAK,eegb6SjDKLWAfnIHplYQ4
def u5ufzT4NjHKSr(T1QDsJlUtCGhn):
	bE05BTyHVFMfagGSukdW = A8v6c2fL7egwWCF3YBqr4kXSRn._getframe(P2Fgh6TCOWoaHjkqBcQnvRNXe).f_code.co_name
	if not T1QDsJlUtCGhn or not bE05BTyHVFMfagGSukdW or bE05BTyHVFMfagGSukdW==s97s2k0LJgl(u"ࠫࡁࡳ࡯ࡥࡷ࡯ࡩࡃ࠭డ"):
		return zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡡࠠࠨఢ")+HH3OIALbdWJS9Uh.upper()+cjVhOCwybeRo7UWg92(u"࠭࡟ࠨణ")+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡠࠩత")+str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX)+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࠢࡠࠫథ")
	return otNfFapeEnO(u"ࠩ࠱ࡠࡹ࠭ద")+bE05BTyHVFMfagGSukdW
def JwKDl495gRWA8jfsEbLhHQPnceFOqz(wQtRhFk5jfExWpXnOVi2gT,sBbvqgYCaSP50=CJlTSEpZsWb0QHg5w):
	if not sBbvqgYCaSP50: wQtRhFk5jfExWpXnOVi2gT,sBbvqgYCaSP50 = CJlTSEpZsWb0QHg5w,wQtRhFk5jfExWpXnOVi2gT
	sBbvqgYCaSP50 = sBbvqgYCaSP50.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡠࡽ࠶࠰ࠨధ"),CJlTSEpZsWb0QHg5w)
	if BB7oCRfQNSYj5qDhTUevV:
		try: sBbvqgYCaSP50 = sBbvqgYCaSP50.decode(Im5KSGZYBpRvdMVsbuXg,yylSaxCLfkte(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫన")).encode(Im5KSGZYBpRvdMVsbuXg,mi2ZJXCDzITuyev6gfn(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬ఩"))
		except: sBbvqgYCaSP50 = sBbvqgYCaSP50.encode(Im5KSGZYBpRvdMVsbuXg,O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ప"))
	SwxsBTflnipNFJ8CUY9mdert = BO4WDv2Zl5q13u76
	xWMpqasJ9BD = [CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w]
	if wQtRhFk5jfExWpXnOVi2gT: sBbvqgYCaSP50 = sBbvqgYCaSP50.replace(Ym6q5M4TocDaA013RjFQ,CJlTSEpZsWb0QHg5w).replace(Dj62UpP5MrbTkJqhRa,CJlTSEpZsWb0QHg5w).replace(oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w)
	else: wQtRhFk5jfExWpXnOVi2gT = PiDqTEkycIt9BYLs7uMnv5f
	hMIBwVCGcWq790fRy4HZm,tSkGin1CgWMfv5d8aXsoHl = Olh7n0zfV4(u"ࠧ࡝ࡶࠪఫ"),VzZPgf1qW5L8auj2do9R4FpiXM7Ycy
	frNSHT90aIyw3QKJUgVuq7j5ZkY4v = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠷࠶ල")*YvOQBzaTAscXR9ql if A7Z6OVh20eCEUx else cbmeD4WNZfAowxT2JdUMtV(u"࠵࠴඼")*YvOQBzaTAscXR9ql
	SiqJzXaEFc0lweOCPn = P3cpaLN2sH*hMIBwVCGcWq790fRy4HZm
	if sBbvqgYCaSP50.startswith(rC5tnFDlQcRGA2(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩబ")): sBbvqgYCaSP50 = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩ࠱ࡠࡹ࠭భ")+sBbvqgYCaSP50
	if LMcWw6B48Dj in wQtRhFk5jfExWpXnOVi2gT: SwxsBTflnipNFJ8CUY9mdert = pKVikfGen4wMt80UTscxWjAoCZ5S.LOGERROR
	if wQtRhFk5jfExWpXnOVi2gT in [PiDqTEkycIt9BYLs7uMnv5f,LMcWw6B48Dj]: xWMpqasJ9BD = [sBbvqgYCaSP50]
	elif wQtRhFk5jfExWpXnOVi2gT==owpdSWeCOTgNF6vQPyGEarZ: xWMpqasJ9BD = sBbvqgYCaSP50.split(tSkGin1CgWMfv5d8aXsoHl)
	elif wQtRhFk5jfExWpXnOVi2gT==MMxceZuwFzkCp9y0R:
		cKBL8AkYTtC = sBbvqgYCaSP50.split(tSkGin1CgWMfv5d8aXsoHl)
		xWMpqasJ9BD = [cKBL8AkYTtC[ZVNvqy4iF1a9X]]
		for lljAD6u8pm13sXYRJgvPQKB5 in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,len(cKBL8AkYTtC),VTadWjBloMwXO2CH9GDK6FR):
			try: CmSBwTWbyRMigJDpaf = cKBL8AkYTtC[lljAD6u8pm13sXYRJgvPQKB5]+tSkGin1CgWMfv5d8aXsoHl+cKBL8AkYTtC[lljAD6u8pm13sXYRJgvPQKB5+VVvcQpCU3OM09n(u"࠵඾")]
			except: CmSBwTWbyRMigJDpaf = cKBL8AkYTtC[lljAD6u8pm13sXYRJgvPQKB5]
			xWMpqasJ9BD.append(CmSBwTWbyRMigJDpaf)
	Po3Glfx1kvqcijAR = xWMpqasJ9BD[ZVNvqy4iF1a9X]
	for Oo8Hc9Xel1CFtv in xWMpqasJ9BD[P2Fgh6TCOWoaHjkqBcQnvRNXe:]:
		if wQtRhFk5jfExWpXnOVi2gT in [owpdSWeCOTgNF6vQPyGEarZ,MMxceZuwFzkCp9y0R]: SiqJzXaEFc0lweOCPn += hMIBwVCGcWq790fRy4HZm
		Po3Glfx1kvqcijAR += rScptJWVdgzQGR1E3LZ9byC+frNSHT90aIyw3QKJUgVuq7j5ZkY4v+SiqJzXaEFc0lweOCPn+Oo8Hc9Xel1CFtv
	if wQtRhFk5jfExWpXnOVi2gT in [LMcWw6B48Dj,owpdSWeCOTgNF6vQPyGEarZ]: Po3Glfx1kvqcijAR += rJ9cgWz4FU
	Po3Glfx1kvqcijAR += KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࠤࡤ࠭మ")
	if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࠪ࠭య") in Po3Glfx1kvqcijAR: Po3Glfx1kvqcijAR = sWzgdLCjSVwaMuhFkNf1Uop(Po3Glfx1kvqcijAR)
	pKVikfGen4wMt80UTscxWjAoCZ5S.log(Po3Glfx1kvqcijAR,level=SwxsBTflnipNFJ8CUY9mdert)
	return
def JEAtPbO4MULFdGCVWcHwp0SQ6(bzL2p4JPBl8FjcAZuieUTwNIk0):
	try: PBrsIxTjg1ec3VO0zJKl5oYLRpFUX = Izg3hVy4Nx1oOU6L29DFkmqnZ.connect(bzL2p4JPBl8FjcAZuieUTwNIk0,check_same_thread=VJZIMkUN5siqB21Pf)
	except:
		if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(c2XOIv1RU6aSuAeiZ5Pgz9Gr):
			tiFgl4DMvGEAUfjIYkHbr05.makedirs(c2XOIv1RU6aSuAeiZ5Pgz9Gr)
			PBrsIxTjg1ec3VO0zJKl5oYLRpFUX = Izg3hVy4Nx1oOU6L29DFkmqnZ.connect(bzL2p4JPBl8FjcAZuieUTwNIk0,check_same_thread=VJZIMkUN5siqB21Pf)
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.text_factory = str
	CUYvKkg403sS1yxGoTbWDhJAXN = PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.cursor()
	CUYvKkg403sS1yxGoTbWDhJAXN.execute(zQGaM7ctZCN(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡧࡵࡵࡱࡰࡥࡹ࡯ࡣࡠ࡫ࡱࡨࡪࡾ࠽࡯ࡱࠣ࠿ࠬర"))
	CUYvKkg403sS1yxGoTbWDhJAXN.execute(TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡩࡨࡰࡲࡶࡪࡥࡣࡩࡧࡦ࡯ࡤࡩ࡯࡯ࡵࡷࡶࡦ࡯࡮ࡵࡵࡀࡽࡪࡹࠠ࠼ࠩఱ"))
	CUYvKkg403sS1yxGoTbWDhJAXN.execute(VVvcQpCU3OM09n(u"ࠧࡑࡔࡄࡋࡒࡇࠠ࡫ࡱࡸࡶࡳࡧ࡬ࡠ࡯ࡲࡨࡪࡃࡏࡇࡈࠣ࠿ࠬల"))
	CUYvKkg403sS1yxGoTbWDhJAXN.execute(EcjO3giln2kQTdBY0XLAG(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡵࡼࡲࡨ࡮ࡲࡰࡰࡲࡹࡸࡃࡏࡇࡈࠣ࠿ࠬళ"))
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.commit()
	return PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN
def ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,qAdFOUJyw7ak5l,FFWOcgQZsp7fVuoEX9zSNvrK3k1L2J,uZe0Urpvb3d9=()):
	FlhSkMf52TtUubsO = gZvlfk6xhACbXcD5j0KBLiVM1
	timeout = JACnOz297UuDK5HpPkc1LF(u"࠶࠶඿")
	ZHRudGMgxIj6cm2LyPDbo1kN0r8 = L8Wkv5KCSoq.time()
	import kUCfvjAP1c
	while L8Wkv5KCSoq.time()-ZHRudGMgxIj6cm2LyPDbo1kN0r8<timeout:
		try:
			if qAdFOUJyw7ak5l: FlhSkMf52TtUubsO = CUYvKkg403sS1yxGoTbWDhJAXN.executemany(FFWOcgQZsp7fVuoEX9zSNvrK3k1L2J,uZe0Urpvb3d9).fetchall()
			else: FlhSkMf52TtUubsO = CUYvKkg403sS1yxGoTbWDhJAXN.execute(FFWOcgQZsp7fVuoEX9zSNvrK3k1L2J,uZe0Urpvb3d9).fetchall()
			break
		except Exception as ii8GhoFl1LA4ESeJnxyOjI6c:
			if yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡧࡥࡹࡧࡢࡢࡵࡨࠤ࡮ࡹࠠ࡭ࡱࡦ࡯ࡪࡪࠧఴ") not in str(ii8GhoFl1LA4ESeJnxyOjI6c): break
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࠲ࡡࡺࡄࡢࡶࡤࡦࡦࡹࡥࠡࡨ࡬ࡰࡪࠦࡩࡴࠢ࡯ࡳࡨࡱࡥࡥࠢࠣࠤࠬవ")+bzL2p4JPBl8FjcAZuieUTwNIk0+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡸࡪࡨࡲࠥ࡫ࡸࡦࡥࡸࡸ࡮ࡴࡧࠡࡶ࡫࡭ࡸࠦࡳࡵࡣࡷࡩࡲ࡫࡮ࡵࠢࠣࠤࠬశ")+FFWOcgQZsp7fVuoEX9zSNvrK3k1L2J)
		kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"๋ࠬไโࠢส่อ๐ว็ษอࠤ๊่แๅࠩష"),CJlTSEpZsWb0QHg5w,L8Wkv5KCSoq=TDpFsQXHze2q30uYtGPfEIm8(u"࠻࠰࠱ව"))
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.commit()
		L8Wkv5KCSoq.sleep(yylSaxCLfkte(u"࠰࠯࠴࠸ශ"))
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.commit()
	return FlhSkMf52TtUubsO
def JCLGIhgx1M9eEicOwf(bzL2p4JPBl8FjcAZuieUTwNIk0,XpIWfPGjl4u9Czb82hJqeM6ya,xxf8z7bBswhoepXg,NNtpzSEqhsu2J=gZvlfk6xhACbXcD5j0KBLiVM1):
	qPWgu3zkRbrv74yho = knjNZvrbGEaKB3oYCxHd8MW(XpIWfPGjl4u9Czb82hJqeM6ya)
	JtQnzkyrlEG0aZ6mx4c = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬస"))
	if xxf8z7bBswhoepXg not in [O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪహ"),mi2ZJXCDzITuyev6gfn(u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡒࡏࡍ࡙࡚ࡅࡅࡡࡄࡐࡑ࠭఺"),o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡊࡐࡔࡈࡁࡍࡕࡈࡅࡗࡉࡈࡠࡕࡓࡐࡎ࡚ࡔࡆࡆࡢࡋࡔࡕࡇࡍࡇࠪ఻")] and bzL2p4JPBl8FjcAZuieUTwNIk0==NN4DuIqLH9iGesZocawQTUWm0E and NNtpzSEqhsu2J!=I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡑࡊ࡙ࡓࡂࡉࡈࡗ఼ࠬ"):
		if JtQnzkyrlEG0aZ6mx4c==o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡘ࡚ࡏࡑࠩఽ"): return qPWgu3zkRbrv74yho
		QgwJd8Sfs07zyqlmiKWRrCP9Dn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩా"))
		if QgwJd8Sfs07zyqlmiKWRrCP9Dn==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ి"):
			oHCAyTbdWEFu(bzL2p4JPBl8FjcAZuieUTwNIk0,xxf8z7bBswhoepXg,NNtpzSEqhsu2J)
			return qPWgu3zkRbrv74yho
	X75pk6SwjhOKnx2Lt8GIcvTuNDgr = ZVNvqy4iF1a9X
	if JtQnzkyrlEG0aZ6mx4c==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨీ"): X75pk6SwjhOKnx2Lt8GIcvTuNDgr = EKMZnHy6FQ1GN7w8
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN = JEAtPbO4MULFdGCVWcHwp0SQ6(bzL2p4JPBl8FjcAZuieUTwNIk0)
	if X75pk6SwjhOKnx2Lt8GIcvTuNDgr: FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,yylSaxCLfkte(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨు")+xxf8z7bBswhoepXg+GISOTJh20W(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡩࡽࡶࡩࡳࡻࡁࠫూ")+str(U6YgVKS9rAmwe1RTPlQnfiGs+X75pk6SwjhOKnx2Lt8GIcvTuNDgr)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࠤࡀ࠭ృ"))
	FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,zQGaM7ctZCN(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫౄ")+xxf8z7bBswhoepXg+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡥࡹࡲ࡬ࡶࡾࡂࠧ౅")+str(U6YgVKS9rAmwe1RTPlQnfiGs)+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࠠ࠼ࠩె"))
	if NNtpzSEqhsu2J:
		FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,yylSaxCLfkte(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡥࡣࡷࡥࠥࡌࡒࡐࡏࠣࠦࠬే")+xxf8z7bBswhoepXg+HaTI5u1f3SCxmMAkw(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨై"),(str(NNtpzSEqhsu2J),))
		if FlhSkMf52TtUubsO:
			try:
				AyKma12GRYnziLV7EWIjUM = BBxt0yrLpJSHvc57i.decompress(FlhSkMf52TtUubsO[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X])
				qPWgu3zkRbrv74yho = oMXjhciyrP.loads(AyKma12GRYnziLV7EWIjUM)
			except: pass
	else:
		FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡖࡉࡑࡋࡃࡕࠢࡦࡳࡱࡻ࡭࡯࠮ࡧࡥࡹࡧࠠࡇࡔࡒࡑࠥࠨࠧ౉")+xxf8z7bBswhoepXg+O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࠦࠥࡁࠧొ"))
		if FlhSkMf52TtUubsO:
			qPWgu3zkRbrv74yho,l6yvPkLCJG3rpnh = {},[]
			for ttwBeGMrXaIPvyfnhUJmiCxok4,s502yd81FCuJmLVBlkPtxih9fZDA in FlhSkMf52TtUubsO:
				r0XwiCFev4oKqbZm5upBQk = BBxt0yrLpJSHvc57i.decompress(s502yd81FCuJmLVBlkPtxih9fZDA)
				s502yd81FCuJmLVBlkPtxih9fZDA = oMXjhciyrP.loads(r0XwiCFev4oKqbZm5upBQk)
				qPWgu3zkRbrv74yho[ttwBeGMrXaIPvyfnhUJmiCxok4] = s502yd81FCuJmLVBlkPtxih9fZDA
				l6yvPkLCJG3rpnh.append(ttwBeGMrXaIPvyfnhUJmiCxok4)
			if l6yvPkLCJG3rpnh:
				qPWgu3zkRbrv74yho[otNfFapeEnO(u"ࠫࡤࡥࡓࡆࡓࡘࡉࡓࡉࡅࡅࡡࡆࡓࡑ࡛ࡍࡏࡕࡢࡣࠬో")] = l6yvPkLCJG3rpnh
				if XpIWfPGjl4u9Czb82hJqeM6ya==O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡲࡩࡴࡶࠪౌ"): qPWgu3zkRbrv74yho = l6yvPkLCJG3rpnh
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
	return qPWgu3zkRbrv74yho
def JGFzPBowen2i0HI(bzL2p4JPBl8FjcAZuieUTwNIk0,xxf8z7bBswhoepXg,NNtpzSEqhsu2J,qPWgu3zkRbrv74yho,TmCtSod7vLkBlNKaDHghUMYjc,rYQBk6y47uewqhRvOFWLAiXMSI2b=VJZIMkUN5siqB21Pf):
	JtQnzkyrlEG0aZ6mx4c = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩ్ࠬ"))
	if JtQnzkyrlEG0aZ6mx4c==s97s2k0LJgl(u"ࠧࡍࡋࡐࡍ࡙ࡋࡄࠨ౎") and TmCtSod7vLkBlNKaDHghUMYjc>EKMZnHy6FQ1GN7w8: TmCtSod7vLkBlNKaDHghUMYjc = EKMZnHy6FQ1GN7w8
	if rYQBk6y47uewqhRvOFWLAiXMSI2b:
		kc4BtgWCFLJ5yGRVZzuX1eni20,GdXS7k358z1f0unQtbOg = [],[]
		for LxNV5lenkhW6zoBJDMA7ZuqSg in range(len(NNtpzSEqhsu2J)):
			AyKma12GRYnziLV7EWIjUM = oMXjhciyrP.dumps(qPWgu3zkRbrv74yho[LxNV5lenkhW6zoBJDMA7ZuqSg])
			qeWLQtnpNFX = BBxt0yrLpJSHvc57i.compress(AyKma12GRYnziLV7EWIjUM)
			kc4BtgWCFLJ5yGRVZzuX1eni20.append((NNtpzSEqhsu2J[LxNV5lenkhW6zoBJDMA7ZuqSg],))
			GdXS7k358z1f0unQtbOg.append((TmCtSod7vLkBlNKaDHghUMYjc+U6YgVKS9rAmwe1RTPlQnfiGs,str(NNtpzSEqhsu2J[LxNV5lenkhW6zoBJDMA7ZuqSg]),qeWLQtnpNFX))
	else:
		AyKma12GRYnziLV7EWIjUM = oMXjhciyrP.dumps(qPWgu3zkRbrv74yho)
		V7VldYATX4k91ogih2pWtfD03Z = BBxt0yrLpJSHvc57i.compress(AyKma12GRYnziLV7EWIjUM)
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN = JEAtPbO4MULFdGCVWcHwp0SQ6(bzL2p4JPBl8FjcAZuieUTwNIk0)
	FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,yylSaxCLfkte(u"ࠨࡅࡕࡉࡆ࡚ࡅࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡒࡔ࡚ࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠣࠩ౏")+xxf8z7bBswhoepXg+GISOTJh20W(u"ࠩࠥࠤ࠭࡫ࡸࡱ࡫ࡵࡽ࠱ࡩ࡯࡭ࡷࡰࡲ࠱ࡪࡡࡵࡣࠬࠤࡀ࠭౐"))
	if rYQBk6y47uewqhRvOFWLAiXMSI2b:
		FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,w2qb6lf5EM,mi2ZJXCDzITuyev6gfn(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠤࠪ౑")+xxf8z7bBswhoepXg+pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࠧࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫ౒"),kc4BtgWCFLJ5yGRVZzuX1eni20)
		FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,w2qb6lf5EM,o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡏࡎࡔࡇࡕࡘࠥࡏࡎࡕࡑࠣࠦࠬ౓")+xxf8z7bBswhoepXg+otNfFapeEnO(u"࠭ࠢࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࡂ࠰ࡄ࠲࠿ࠪࠢ࠾ࠫ౔"),GdXS7k358z1f0unQtbOg)
	else:
		if TmCtSod7vLkBlNKaDHghUMYjc:
			FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,EcjO3giln2kQTdBY0XLAG(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࠨౕࠧ")+xxf8z7bBswhoepXg+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯ࠢࡀࠤࡄࠦ࠻ࠨౖ"),(str(NNtpzSEqhsu2J),))
			FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,yylSaxCLfkte(u"ࠩࡌࡒࡘࡋࡒࡕࠢࡌࡒ࡙ࡕࠠࠣࠩ౗")+xxf8z7bBswhoepXg+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࠦࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮ࠦ࠻ࠨౘ"),(TmCtSod7vLkBlNKaDHghUMYjc+U6YgVKS9rAmwe1RTPlQnfiGs,str(NNtpzSEqhsu2J),V7VldYATX4k91ogih2pWtfD03Z))
		else:
			FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,ZP1LyUCS3pIBu(u"࡚ࠫࡖࡄࡂࡖࡈࠤࠧ࠭ౙ")+xxf8z7bBswhoepXg+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࠨࠠࡔࡇࡗࠤࡩࡧࡴࡢࠢࡀࠤࡄࠦࡗࡉࡇࡕࡉࠥࡩ࡯࡭ࡷࡰࡲࠥࡃࠠࡀࠢ࠾ࠫౚ"),(V7VldYATX4k91ogih2pWtfD03Z,str(NNtpzSEqhsu2J)))
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
	return
def oHCAyTbdWEFu(bzL2p4JPBl8FjcAZuieUTwNIk0,xxf8z7bBswhoepXg,NNtpzSEqhsu2J=gZvlfk6xhACbXcD5j0KBLiVM1):
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN = JEAtPbO4MULFdGCVWcHwp0SQ6(bzL2p4JPBl8FjcAZuieUTwNIk0)
	if NNtpzSEqhsu2J==gZvlfk6xhACbXcD5j0KBLiVM1: FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,XB4CjMkPFzhAHiI3q(u"࠭ࡄࡓࡑࡓࠤ࡙ࡇࡂࡍࡇࠣࡍࡋࠦࡅ࡙ࡋࡖࡘࡘࠦࠢࠨ౛")+xxf8z7bBswhoepXg+KA26GucUHOwXL(u"ࠧࠣࠢ࠾ࠫ౜"))
	else:
		B4T8DNxMitfkyWd5luLZ = (str(NNtpzSEqhsu2J),)
		if Olh7n0zfV4(u"ࠨࠧࠪౝ") in NNtpzSEqhsu2J: FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ౞")+xxf8z7bBswhoepXg+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡱ࡯࡫ࡦࠢࡂࠤࡀ࠭౟"),B4T8DNxMitfkyWd5luLZ)
		else: FlhSkMf52TtUubsO = ODLnpGUNsgx6(bzL2p4JPBl8FjcAZuieUTwNIk0,PBrsIxTjg1ec3VO0zJKl5oYLRpFUX,CUYvKkg403sS1yxGoTbWDhJAXN,VJZIMkUN5siqB21Pf,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࠥࠫౠ")+xxf8z7bBswhoepXg+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࠨࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࠦ࠽ࠡࡁࠣ࠿ࠬౡ"),B4T8DNxMitfkyWd5luLZ)
	PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
	return
class AUE7JimhM1uV(): pass
class Ing6ofPTzy1aJXv0(AUE7JimhM1uV):
	def __init__(rOXJKGtIFyuP4aZEkwQ3):
		rOXJKGtIFyuP4aZEkwQ3.url = CJlTSEpZsWb0QHg5w
		rOXJKGtIFyuP4aZEkwQ3.code = -yUMRP0QKIzY9BDnsV784TZmwkf(u"࠺࠻ෂ")
		rOXJKGtIFyuP4aZEkwQ3.reason = CJlTSEpZsWb0QHg5w
		rOXJKGtIFyuP4aZEkwQ3.content = CJlTSEpZsWb0QHg5w
		rOXJKGtIFyuP4aZEkwQ3.headers = {}
		rOXJKGtIFyuP4aZEkwQ3.cookies = {}
		rOXJKGtIFyuP4aZEkwQ3.succeeded = VJZIMkUN5siqB21Pf
def knjNZvrbGEaKB3oYCxHd8MW(kcxAmftieK56PE9TqbDHdSrF8):
	if kcxAmftieK56PE9TqbDHdSrF8==rC5tnFDlQcRGA2(u"࠭ࡤࡪࡥࡷࠫౢ"): qPWgu3zkRbrv74yho = {}
	elif kcxAmftieK56PE9TqbDHdSrF8==zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧ࡭࡫ࡶࡸࠬౣ"): qPWgu3zkRbrv74yho = []
	elif kcxAmftieK56PE9TqbDHdSrF8==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡶࡸࡴࡱ࡫ࠧ౤"): qPWgu3zkRbrv74yho = ()
	elif kcxAmftieK56PE9TqbDHdSrF8==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡶࡸࡷ࠭౥"): qPWgu3zkRbrv74yho = CJlTSEpZsWb0QHg5w
	elif kcxAmftieK56PE9TqbDHdSrF8==s97s2k0LJgl(u"ࠪ࡭ࡳࡺࠧ౦"): qPWgu3zkRbrv74yho = ZVNvqy4iF1a9X
	elif kcxAmftieK56PE9TqbDHdSrF8==TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭౧"): qPWgu3zkRbrv74yho = Ing6ofPTzy1aJXv0()
	elif not kcxAmftieK56PE9TqbDHdSrF8: qPWgu3zkRbrv74yho = gZvlfk6xhACbXcD5j0KBLiVM1
	else: qPWgu3zkRbrv74yho = gZvlfk6xhACbXcD5j0KBLiVM1
	return qPWgu3zkRbrv74yho
def ed1Dvp6KAOcY2lFNzgm5t4ifE0h8(I71YyJueLxqwMd):
	uWT6UO8N1vphI = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(cjVhOCwybeRo7UWg92(u"ࠬࡧࡶ࠯ࡲࡵ࡭ࡻࡹ࠱ࠨ౨"))
	Rsu58Dkb9KSnL = Ew2zQ8u7Ss.AV_CLIENT_IDS.splitlines()
	OOIAWl64fx = ZVNvqy4iF1a9X
	dd4LT95xC1Gwh6fF = len(I71YyJueLxqwMd)
	HFPeq9Bn4tYlGkS5RWvcxgiJsKNd = [VJZIMkUN5siqB21Pf]*dd4LT95xC1Gwh6fF
	for u0TeaCwAR73SpgzVkU6md in [U6YgVKS9rAmwe1RTPlQnfiGs,U6YgVKS9rAmwe1RTPlQnfiGs-o1oDTrOyPliAC6QBcKXRathZGu9g4Y]:
		rB0vzy1toCcJYZbOXNUs6pk8 = str(u0TeaCwAR73SpgzVkU6md*otNfFapeEnO(u"࠴࠴࠵࠶࠰࠱࠰࠳හ")/yylSaxCLfkte(u"࠶࠶࠶࠵࠶࠰ස"))[ZVNvqy4iF1a9X:h6sIkJOT5PB2vCxqo4LFag70wA(u"࠸ළ")]
		if rB0vzy1toCcJYZbOXNUs6pk8!=OOIAWl64fx:
			for lljAD6u8pm13sXYRJgvPQKB5 in range(dd4LT95xC1Gwh6fF):
				if not HFPeq9Bn4tYlGkS5RWvcxgiJsKNd[lljAD6u8pm13sXYRJgvPQKB5]:
					M96zE51XBmQxVsF2ujiy = VJZIMkUN5siqB21Pf
					for USpCglRqrsEhAyN8jV01OFo7d69 in Rsu58Dkb9KSnL:
						UFlOYV2HwEIW = XB4CjMkPFzhAHiI3q(u"࠭ࡘ࠲࠻ࠪ౩")+I71YyJueLxqwMd[lljAD6u8pm13sXYRJgvPQKB5]+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧ࠲࠺ࡀࠫ౪")+USpCglRqrsEhAyN8jV01OFo7d69[-GISOTJh20W(u"࠷࠺ෆ"):]+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+rB0vzy1toCcJYZbOXNUs6pk8
						UFlOYV2HwEIW = jRBlVKHJ7fOx.md5(UFlOYV2HwEIW.encode(Im5KSGZYBpRvdMVsbuXg)).hexdigest()[:yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠹࠲෇")]
						if UFlOYV2HwEIW in uWT6UO8N1vphI:
							M96zE51XBmQxVsF2ujiy = w2qb6lf5EM
							break
					HFPeq9Bn4tYlGkS5RWvcxgiJsKNd[lljAD6u8pm13sXYRJgvPQKB5] = M96zE51XBmQxVsF2ujiy
		OOIAWl64fx = rB0vzy1toCcJYZbOXNUs6pk8
	return HFPeq9Bn4tYlGkS5RWvcxgiJsKNd
class OUf6wJ2AILcTnDF1(fapzkK9oANLM8Xc0):
	def __init__(rOXJKGtIFyuP4aZEkwQ3): pass
	def eS9wcjItZ7YAK(rOXJKGtIFyuP4aZEkwQ3,EWcvU5FHBg084otmAYel):
		rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = yylSaxCLfkte(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ౫") if Ew2zQ8u7Ss.wpBxtqcsDEafMFkToIXe else CJlTSEpZsWb0QHg5w
		rOXJKGtIFyuP4aZEkwQ3.EWcvU5FHBg084otmAYel = EWcvU5FHBg084otmAYel
		if not Ew2zQ8u7Ss.wsrSnHQfOWm8:
			import kUCfvjAP1c
			kUCfvjAP1c.RRr3Anq81K9gQybv6E7loe(zz5iuewhAFONn8GQc0DtyKZ317pHo)
	def onPlayBackStopped(rOXJKGtIFyuP4aZEkwQ3): rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = mi2ZJXCDzITuyev6gfn(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ౬")
	def onPlayBackError(rOXJKGtIFyuP4aZEkwQ3): rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ౭")
	def onPlayBackEnded(rOXJKGtIFyuP4aZEkwQ3): rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ౮")
	def onPlayBackStarted(rOXJKGtIFyuP4aZEkwQ3):
		rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = EcjO3giln2kQTdBY0XLAG(u"ࠬࡹࡴࡢࡴࡷࡩࡩ࠭౯")
		M50hRontp3A1m4Lx = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=rOXJKGtIFyuP4aZEkwQ3.rL3Q2hgIsTNO)
		M50hRontp3A1m4Lx.start()
	def onAVStarted(rOXJKGtIFyuP4aZEkwQ3):
		if Ew2zQ8u7Ss.wsrSnHQfOWm8: rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = VVvcQpCU3OM09n(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ౰")
		else: rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ౱")
	def rL3Q2hgIsTNO(rOXJKGtIFyuP4aZEkwQ3):
		Qlu9Ih6YOVFw7X34(rC5tnFDlQcRGA2(u"ࠨࡵࡷࡳࡵ࠭౲"))
		sEDdV1HYhlpBOZAw3 = ZVNvqy4iF1a9X
		while not eval(KA26GucUHOwXL(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰࡬ࡷࡕࡲࡡࡺ࡫ࡱ࡫࠭࠯ࠧ౳"),{pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡼࡧࡳࡣࠨ౴"):pKVikfGen4wMt80UTscxWjAoCZ5S}) and rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡸࡺࡡࡳࡶࡨࡨࠬ౵"):
			pKVikfGen4wMt80UTscxWjAoCZ5S.sleep(E6xdOMpqISHZCn(u"࠱࠱࠲࠳෈"))
			sEDdV1HYhlpBOZAw3 += P2Fgh6TCOWoaHjkqBcQnvRNXe
			if sEDdV1HYhlpBOZAw3>xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠷࠲෉"): return
		if Ew2zQ8u7Ss.wpBxtqcsDEafMFkToIXe: rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = KA26GucUHOwXL(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭౶")
		elif Ew2zQ8u7Ss.wsrSnHQfOWm8: rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = yylSaxCLfkte(u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ౷")
		elif Ew2zQ8u7Ss.QFCWcArusifVavlYk29:
			import kUCfvjAP1c
			rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡵࡧࡶࡸ࡮ࡴࡧࠨ౸")
			uHG17EdPtkl2AQrU = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=kUCfvjAP1c.kZUfwBd4cbK5T3sxlJN,args=(rOXJKGtIFyuP4aZEkwQ3.EWcvU5FHBg084otmAYel,)).start()
			KdBasj41YAiUxtTfucCMQO = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=kUCfvjAP1c.kTi75UVbJ4IG2onre).start()
		else: rOXJKGtIFyuP4aZEkwQ3.RaPEyvwJUfzS96BhnmOCleY0tuxKNc = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠩ౹")
def yuVTG6Ck70qBSbnYOFvsfHxPr1wW():
	Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	fFStKMa3GBje1lNswuUAQDdr0qzXyx = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡖࡽࡸࡺࡥ࡮࠰ࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡒࡦࡳࡥࠨ౺"))
	try:
		WUFo1lNyAxgd = open(Olh7n0zfV4(u"ࠪ࠳ࡵࡸ࡯ࡤ࠱ࡦࡴࡺ࡯࡮ࡧࡱࠪ౻"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡷࡨࠧ౼")).read()
		if A7Z6OVh20eCEUx: WUFo1lNyAxgd = WUFo1lNyAxgd.decode(Im5KSGZYBpRvdMVsbuXg)
		hxZBsqyKpP = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"࡙ࠬࡥࡳ࡫ࡤࡰ࠳࠰࠿࠻ࠢࠫ࠲࠯ࡅࠩࠥࠩ౽"),WUFo1lNyAxgd,Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if hxZBsqyKpP: Nfn7B486egFOoldtMc5P1 = hxZBsqyKpP[ZVNvqy4iF1a9X]
	except: pass
	try:
		import subprocess as Ir7UnQluDMZvm6
		oatSMDlHRi0FkXBELpIAgwrPs1 = Ir7UnQluDMZvm6.Popen(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡳࡵࡣࡷࠤ࠲ࡩࠠࠣࠢࠨ࡜ࠥࠨࠠ࠰ࡵࡷࡳࡷࡧࡧࡦ࠱ࡨࡱࡺࡲࡡࡵࡧࡧ࠳࠵ࠦ࠻ࠡࡵࡷࡥࡹࠦ࠭ࡤࠢࠥࠤࠪ࡝ࠠࠣࠢ࠲ࡺࡦࡸ࠯࡭ࡱࡪࠫ౾"),shell=w2qb6lf5EM,stdin=Ir7UnQluDMZvm6.PIPE,stdout=Ir7UnQluDMZvm6.PIPE,stderr=Ir7UnQluDMZvm6.PIPE)
		pE4v1DhM36I7CO = oatSMDlHRi0FkXBELpIAgwrPs1.stdout.read()
		if pE4v1DhM36I7CO:
			if A7Z6OVh20eCEUx:
				pE4v1DhM36I7CO = pE4v1DhM36I7CO.decode(Im5KSGZYBpRvdMVsbuXg,TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧ౿"))
			RN5v1fO3uZVxQqhJXdUCtgKSE = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"ࠨࠢࠫࡠࡩࢁ࠱࠱ࡿࠬࠤࠬಀ"),pE4v1DhM36I7CO,Zy2l0g8QU5vqefaTrsw.IGNORECASE)
			if RN5v1fO3uZVxQqhJXdUCtgKSE: ZedEzDWyuTrPfg0p2A9l8w1s = min(RN5v1fO3uZVxQqhJXdUCtgKSE)
	except: pass
	return fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s
def qqwenxatQlYJLD(CHFsDhbMw7B3kel29gJYZOp=w2qb6lf5EM,G7N4Mz9HPU0CwasdkrRWgAu=yylSaxCLfkte(u"࠵࠵්")):
	dFeDOcB7GVQXHsYMUu9r = w2qb6lf5EM
	if CHFsDhbMw7B3kel29gJYZOp:
		LADl2C3MaYp = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࡯࡭ࡸࡺࠧಁ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ಂ"),Olh7n0zfV4(u"ࠫࡘࡏࡔࡆࡕࡢࡇࡍࡋࡃࡌࠩಃ"))
		if LADl2C3MaYp:
			EnTfOsZ26YjNvpH3,WkQBPFOw1HT,pNeCUAFcoOH,SYdpJq85kcXe74OInr9bwTE = LADl2C3MaYp
			dFeDOcB7GVQXHsYMUu9r = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,GISOTJh20W(u"ࠬࡲࡩࡴࡶࠪ಄"),GISOTJh20W(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩಅ"),KA26GucUHOwXL(u"ࠧࡔࡋࡗࡉࡘࡥࡖࡆࡔࡌࡊ࡞࠭ಆ"))
			if dFeDOcB7GVQXHsYMUu9r: fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s = dFeDOcB7GVQXHsYMUu9r
			else: fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s = yuVTG6Ck70qBSbnYOFvsfHxPr1wW()
			if (WkQBPFOw1HT,pNeCUAFcoOH,SYdpJq85kcXe74OInr9bwTE)==(fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s):
				KXteYFW3pA4VmdrRiuZ5nyEbCUx = rJ9cgWz4FU.join(EnTfOsZ26YjNvpH3)
				return KXteYFW3pA4VmdrRiuZ5nyEbCUx
	if dFeDOcB7GVQXHsYMUu9r: fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s = yuVTG6Ck70qBSbnYOFvsfHxPr1wW()
	global ZIArROJqYEWbeCUN,lWxK1fwkphHOF2u7tUijaA
	ZIArROJqYEWbeCUN,lWxK1fwkphHOF2u7tUijaA,YhysATdGIFc = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	G7N4Mz9HPU0CwasdkrRWgAu = G7N4Mz9HPU0CwasdkrRWgAu//VTadWjBloMwXO2CH9GDK6FR
	M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=MLYrVspkqCXn68Zm).start()
	M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=JsiCeLMfGo5KjIvQZmy1).start()
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠴࠴෋")):
		L8Wkv5KCSoq.sleep(s97s2k0LJgl(u"࠴࠳࠻෌"))
		if not YhysATdGIFc:
			try:
				gJ7NivUrITPeMtzm8hYRGj = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(EcjO3giln2kQTdBY0XLAG(u"ࠨࡐࡨࡸࡼࡵࡲ࡬࠰ࡐࡥࡨࡇࡤࡥࡴࡨࡷࡸ࠭ಇ"))
				if gJ7NivUrITPeMtzm8hYRGj.count(ZP1LyUCS3pIBu(u"ࠩ࠽ࠫಈ"))==GGsP9SDod4iUBm6kNMfLw and gJ7NivUrITPeMtzm8hYRGj.count(pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࠴ࠬಉ"))<yylSaxCLfkte(u"࠾෍"):
					gJ7NivUrITPeMtzm8hYRGj = gJ7NivUrITPeMtzm8hYRGj.lower().replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫ࠿࠭ಊ"),CJlTSEpZsWb0QHg5w)
					YhysATdGIFc = str(int(gJ7NivUrITPeMtzm8hYRGj,h6sIkJOT5PB2vCxqo4LFag70wA(u"࠷࠶෎")))
			except: pass
		if ZIArROJqYEWbeCUN and lWxK1fwkphHOF2u7tUijaA and YhysATdGIFc: break
	T4PRy6bHDZUrVwJN80dzM9qOf = [lWxK1fwkphHOF2u7tUijaA,ZIArROJqYEWbeCUN,YhysATdGIFc,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠬ࠶࠰࠲࠳࠵࠶࠸࠹࠴࠵࠷࠸࠺࠻࠽࠷ࠨಋ")]
	if Nfn7B486egFOoldtMc5P1 or ZedEzDWyuTrPfg0p2A9l8w1s:
		el5jFcRuLW = [(P3cpaLN2sH,Nfn7B486egFOoldtMc5P1),(GGsP9SDod4iUBm6kNMfLw,ZedEzDWyuTrPfg0p2A9l8w1s)]
		for IVZCbl4keXui,s7DAv92CkQXqVPOGS3Bxn in el5jFcRuLW:
			s7DAv92CkQXqVPOGS3Bxn = s7DAv92CkQXqVPOGS3Bxn.strip(O4F8UC5lMAS6ghETm1VoPDI(u"࠭࠰ࠨಌ"))
			if s7DAv92CkQXqVPOGS3Bxn:
				if A7Z6OVh20eCEUx: s7DAv92CkQXqVPOGS3Bxn = s7DAv92CkQXqVPOGS3Bxn.encode(Im5KSGZYBpRvdMVsbuXg)
				s7DAv92CkQXqVPOGS3Bxn = str(int(jRBlVKHJ7fOx.md5(s7DAv92CkQXqVPOGS3Bxn).hexdigest(),HaTI5u1f3SCxmMAkw(u"࠳࠷ා")))
				tlsSUfPaqJ9nugEw3x = [int(s7DAv92CkQXqVPOGS3Bxn[OdKHyxfZjwNLDXcpvolShW:OdKHyxfZjwNLDXcpvolShW+o2FdrDBimMuOw97q6QpNW8S(u"࠲࠷ැ")]) for OdKHyxfZjwNLDXcpvolShW in range(len(s7DAv92CkQXqVPOGS3Bxn)) if OdKHyxfZjwNLDXcpvolShW%o2FdrDBimMuOw97q6QpNW8S(u"࠲࠷ැ")==ZVNvqy4iF1a9X]
				T4PRy6bHDZUrVwJN80dzM9qOf[IVZCbl4keXui-P2Fgh6TCOWoaHjkqBcQnvRNXe] = str(sum(tlsSUfPaqJ9nugEw3x))
	Rsu58Dkb9KSnL,VEKMO02jLztkclSYi47xB5I1d = [],VJZIMkUN5siqB21Pf
	for VmldeOJSok2GQUnRBwb5ED,tlsSUfPaqJ9nugEw3x in enumerate(T4PRy6bHDZUrVwJN80dzM9qOf):
		if not tlsSUfPaqJ9nugEw3x: continue
		if VEKMO02jLztkclSYi47xB5I1d and tlsSUfPaqJ9nugEw3x==T4PRy6bHDZUrVwJN80dzM9qOf[-P2Fgh6TCOWoaHjkqBcQnvRNXe]: continue
		VEKMO02jLztkclSYi47xB5I1d = w2qb6lf5EM
		tlsSUfPaqJ9nugEw3x = rC5tnFDlQcRGA2(u"ࠧ࠱ࠩ಍")*G7N4Mz9HPU0CwasdkrRWgAu+tlsSUfPaqJ9nugEw3x
		tlsSUfPaqJ9nugEw3x = tlsSUfPaqJ9nugEw3x[-G7N4Mz9HPU0CwasdkrRWgAu:]
		SSCgtXvVDxOuJjPR56L1ZI3s,mCHGFygQ2WptswT = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		RD2Ym5dVna9pPK67Hy4FJ1GCSNi = str(int(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࠻ࠪಎ")*(G7N4Mz9HPU0CwasdkrRWgAu+P2Fgh6TCOWoaHjkqBcQnvRNXe))-int(tlsSUfPaqJ9nugEw3x))[-G7N4Mz9HPU0CwasdkrRWgAu:]
		for lljAD6u8pm13sXYRJgvPQKB5 in list(range(ZVNvqy4iF1a9X,G7N4Mz9HPU0CwasdkrRWgAu,P3cpaLN2sH)):
			SSCgtXvVDxOuJjPR56L1ZI3s += RD2Ym5dVna9pPK67Hy4FJ1GCSNi[lljAD6u8pm13sXYRJgvPQKB5:lljAD6u8pm13sXYRJgvPQKB5+P3cpaLN2sH]+O4F8UC5lMAS6ghETm1VoPDI(u"ࠩ࠰ࠫಏ")
			mCHGFygQ2WptswT += str(sum(map(int,tlsSUfPaqJ9nugEw3x[lljAD6u8pm13sXYRJgvPQKB5:lljAD6u8pm13sXYRJgvPQKB5+P3cpaLN2sH]))%TDpFsQXHze2q30uYtGPfEIm8(u"࠳࠳ෑ"))
		USpCglRqrsEhAyN8jV01OFo7d69 = str(VmldeOJSok2GQUnRBwb5ED)+SSCgtXvVDxOuJjPR56L1ZI3s+mCHGFygQ2WptswT
		Rsu58Dkb9KSnL.append(USpCglRqrsEhAyN8jV01OFo7d69)
	L4iYUdO0XRt81G5J,EnTfOsZ26YjNvpH3 = [],[]
	for user in Rsu58Dkb9KSnL:
		count = str(str(Rsu58Dkb9KSnL).count(user[cbmeD4WNZfAowxT2JdUMtV(u"࠴ි"):]))
		L4iYUdO0XRt81G5J.append(count+user)
	L4iYUdO0XRt81G5J = sorted(L4iYUdO0XRt81G5J,reverse=w2qb6lf5EM,key=lambda key: key[ZVNvqy4iF1a9X])
	for user in L4iYUdO0XRt81G5J: EnTfOsZ26YjNvpH3.append(user[P2Fgh6TCOWoaHjkqBcQnvRNXe:])
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ಐ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪ಑"),[fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s],DRmUs7l1O4xLeZYzGITXk)
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,yylSaxCLfkte(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨಒ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡓࡊࡖࡈࡗࡤࡉࡈࡆࡅࡎࠫಓ"),[EnTfOsZ26YjNvpH3,fFStKMa3GBje1lNswuUAQDdr0qzXyx,Nfn7B486egFOoldtMc5P1,ZedEzDWyuTrPfg0p2A9l8w1s],DRmUs7l1O4xLeZYzGITXk)
	for user in Ew2zQ8u7Ss.BADCOMMONIDS:
		if user in EnTfOsZ26YjNvpH3: EnTfOsZ26YjNvpH3.remove(user)
	KXteYFW3pA4VmdrRiuZ5nyEbCUx = rJ9cgWz4FU.join(EnTfOsZ26YjNvpH3)
	return KXteYFW3pA4VmdrRiuZ5nyEbCUx
def MLYrVspkqCXn68Zm():
	global ZIArROJqYEWbeCUN
	import getmac82 as smtAMafTZq2wl9W7JI
	try:
		d56YZaIqbHs3X0SpE2oB8 = smtAMafTZq2wl9W7JI.get_mac_address()
		if d56YZaIqbHs3X0SpE2oB8.count(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧ࠻ࠩಔ"))==GGsP9SDod4iUBm6kNMfLw and d56YZaIqbHs3X0SpE2oB8.count(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨ࠲ࠪಕ"))<cbmeD4WNZfAowxT2JdUMtV(u"࠽ී"):
			d56YZaIqbHs3X0SpE2oB8 = d56YZaIqbHs3X0SpE2oB8.lower().replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࠽ࠫಖ"),CJlTSEpZsWb0QHg5w)
			ZIArROJqYEWbeCUN = str(int(d56YZaIqbHs3X0SpE2oB8,otNfFapeEnO(u"࠶࠼ු")))
	except: pass
	return
def JsiCeLMfGo5KjIvQZmy1():
	global lWxK1fwkphHOF2u7tUijaA
	import getmac95 as GFW7ufJrMyH3IOU0m8bwcSKoZhnd5
	try:
		a8tLsuUNOe9wFroQmK0q = GFW7ufJrMyH3IOU0m8bwcSKoZhnd5.get_mac_address()
		if a8tLsuUNOe9wFroQmK0q.count(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪ࠾ࠬಗ"))==GGsP9SDod4iUBm6kNMfLw and a8tLsuUNOe9wFroQmK0q.count(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫ࠵࠭ಘ"))<zz679V18GdcZwvrRexA0nNptY2Tab(u"࠿෕"):
			a8tLsuUNOe9wFroQmK0q = a8tLsuUNOe9wFroQmK0q.lower().replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡀࠧಙ"),CJlTSEpZsWb0QHg5w)
			lWxK1fwkphHOF2u7tUijaA = str(int(a8tLsuUNOe9wFroQmK0q,pz4WBwfyDdgk0m2aRr7SMv(u"࠱࠷ූ")))
	except: pass
	return
def B6Ul0f5eTI8atPymFdXoiANcjK7g9(kcxAmftieK56PE9TqbDHdSrF8,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,nqVYufmd4GFshQeHO9vp05,por2itPgjLlh5fAb3z47nFvUJE):
	if A7Z6OVh20eCEUx and isinstance(qPWgu3zkRbrv74yho, bytes): qPWgu3zkRbrv74yho = qPWgu3zkRbrv74yho.decode(Im5KSGZYBpRvdMVsbuXg)
	for XPAw9c4EjYaDFU5r in qqtVjZsKERH2Jz1kQYnPB:
		if XPAw9c4EjYaDFU5r in otaunYGVIJ2jX8HsKm7ecR0bAh4: otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(XPAw9c4EjYaDFU5r,CJlTSEpZsWb0QHg5w)
		if XPAw9c4EjYaDFU5r in qPWgu3zkRbrv74yho: qPWgu3zkRbrv74yho = qPWgu3zkRbrv74yho.replace(XPAw9c4EjYaDFU5r,CJlTSEpZsWb0QHg5w)
		if XPAw9c4EjYaDFU5r in Dfi7FTuYWN49AaLEt3: Dfi7FTuYWN49AaLEt3 = Dfi7FTuYWN49AaLEt3.replace(XPAw9c4EjYaDFU5r,CJlTSEpZsWb0QHg5w)
	bsGedm1TLP7EgiUQDkCy = str(Dfi7FTuYWN49AaLEt3)[ZVNvqy4iF1a9X:E6xdOMpqISHZCn(u"࠳࠷࠳෗")].replace(rJ9cgWz4FU,Olh7n0zfV4(u"࠭࡜࡝ࡰࠪಚ")).replace(rScptJWVdgzQGR1E3LZ9byC,HaTI5u1f3SCxmMAkw(u"ࠧ࡝࡞ࡵࠫಛ")).replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql)
	if len(str(Dfi7FTuYWN49AaLEt3))>VVvcQpCU3OM09n(u"࠴࠸࠴ෘ"): bsGedm1TLP7EgiUQDkCy = bsGedm1TLP7EgiUQDkCy+pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࠢ࠱࠲࠳࠭ಜ")
	s502yd81FCuJmLVBlkPtxih9fZDA = str(qPWgu3zkRbrv74yho)[ZVNvqy4iF1a9X:TDpFsQXHze2q30uYtGPfEIm8(u"࠵࠹࠵ෙ")].replace(rJ9cgWz4FU,HaTI5u1f3SCxmMAkw(u"ࠩ࡟ࡠࡳ࠭ಝ")).replace(rScptJWVdgzQGR1E3LZ9byC,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡠࡡࡸࠧಞ")).replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql)
	if len(str(qPWgu3zkRbrv74yho))>KA26GucUHOwXL(u"࠶࠺࠶ේ"): s502yd81FCuJmLVBlkPtxih9fZDA = s502yd81FCuJmLVBlkPtxih9fZDA+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࠥ࠴࠮࠯ࠩಟ")
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࠧಠ")+kcxAmftieK56PE9TqbDHdSrF8+otNfFapeEnO(u"࠭ࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩಡ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+JACnOz297UuDK5HpPkc1LF(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩಢ")+nqVYufmd4GFshQeHO9vp05+rC5tnFDlQcRGA2(u"ࠨࠢࡠࠤࠥࠦࡍࡦࡶ࡫ࡳࡩࡀࠠ࡜ࠢࠪಣ")+por2itPgjLlh5fAb3z47nFvUJE+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࠣࡡࠥࠦࠠࡉࡧࡤࡨࡪࡸࡳ࠻ࠢ࡞ࠤࠬತ")+str(bsGedm1TLP7EgiUQDkCy)+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࠤࡢࠦࠠࠡࡆࡤࡸࡦࡀࠠ࡜ࠢࠪಥ")+s502yd81FCuJmLVBlkPtxih9fZDA+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࠥࡣࠧದ"))
	return
def bQs8X1eOM6vauSBpIK5q0tJfDLwNn(por2itPgjLlh5fAb3z47nFvUJE,otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho=CJlTSEpZsWb0QHg5w,Dfi7FTuYWN49AaLEt3=CJlTSEpZsWb0QHg5w,nqVYufmd4GFshQeHO9vp05=CJlTSEpZsWb0QHg5w):
	B6Ul0f5eTI8atPymFdXoiANcjK7g9(cjVhOCwybeRo7UWg92(u"࡛ࠬࡒࡍࡎࡌࡆࡡࡺ࡜ࡵࡑࡓࡉࡓࡥࡕࡓࡎࠪಧ"),otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,nqVYufmd4GFshQeHO9vp05,por2itPgjLlh5fAb3z47nFvUJE)
	if A7Z6OVh20eCEUx: import urllib.request as r1alPL5vQCt40HIG
	else: import urllib2 as r1alPL5vQCt40HIG
	if not Dfi7FTuYWN49AaLEt3: Dfi7FTuYWN49AaLEt3 = {h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪನ"):CJlTSEpZsWb0QHg5w}
	if not qPWgu3zkRbrv74yho: qPWgu3zkRbrv74yho = {}
	UfsBdAibG1326O5mDE4 = otaunYGVIJ2jX8HsKm7ecR0bAh4
	ZLrRvxsCcBEkyeNDwK = qPWgu3zkRbrv74yho
	VVQyKTjakFdlEpIfo7Ruch = UfsBdAibG1326O5mDE4 in Ew2zQ8u7Ss.SITESURLS[cjVhOCwybeRo7UWg92(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ಩")]
	if VVQyKTjakFdlEpIfo7Ruch:
		por2itPgjLlh5fAb3z47nFvUJE = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡒࡒࡗ࡙࠭ಪ")
		Dfi7FTuYWN49AaLEt3[cjVhOCwybeRo7UWg92(u"ࠩࡄ࡚࠲ࡋ࡮ࡤࡴࡼࡴࡹ࡯࡯࡯ࠩಫ")] = ZP1LyUCS3pIBu(u"࡚ࠪࡪࡸࡳࡪࡱࡱࠤ࠶࠴࠰ࠨಬ")
		gNo41TpFHJVr = KSHcVmz2W84iQvbRDBhGldpCL.dumps(qPWgu3zkRbrv74yho)
		import kUCfvjAP1c
		ZLrRvxsCcBEkyeNDwK = kUCfvjAP1c.RQqNCLO5ofzZ7(gNo41TpFHJVr,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠽࠷࠲࠸࠶࠼࠷࠺࠼ෛ"))
	elif por2itPgjLlh5fAb3z47nFvUJE==HaTI5u1f3SCxmMAkw(u"ࠫࡌࡋࡔࠨಭ"):
		UfsBdAibG1326O5mDE4 = otaunYGVIJ2jX8HsKm7ecR0bAh4+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡅࠧಮ")+Hc6rjXpgb3CZuVKYk(qPWgu3zkRbrv74yho)
		ZLrRvxsCcBEkyeNDwK = gZvlfk6xhACbXcD5j0KBLiVM1
	elif por2itPgjLlh5fAb3z47nFvUJE==zQGaM7ctZCN(u"࠭ࡐࡐࡕࡗࠫಯ") and pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࡫ࡵࡲࡲࠬರ") in str(Dfi7FTuYWN49AaLEt3):
		qPWgu3zkRbrv74yho = KSHcVmz2W84iQvbRDBhGldpCL.dumps(qPWgu3zkRbrv74yho)
		ZLrRvxsCcBEkyeNDwK = str(qPWgu3zkRbrv74yho).encode(Im5KSGZYBpRvdMVsbuXg)
	elif por2itPgjLlh5fAb3z47nFvUJE==GISOTJh20W(u"ࠨࡒࡒࡗ࡙࠭ಱ"):
		qPWgu3zkRbrv74yho = Hc6rjXpgb3CZuVKYk(qPWgu3zkRbrv74yho)
		ZLrRvxsCcBEkyeNDwK = qPWgu3zkRbrv74yho.encode(Im5KSGZYBpRvdMVsbuXg)
	try:
		yNiUF7p1L5EeOXh = r1alPL5vQCt40HIG.Request(UfsBdAibG1326O5mDE4,headers=Dfi7FTuYWN49AaLEt3,data=ZLrRvxsCcBEkyeNDwK)
		cDXLPHnAgY6NOk1GVStoiEx = r1alPL5vQCt40HIG.urlopen(yNiUF7p1L5EeOXh)
		LhWaJkpQxVYm = cDXLPHnAgY6NOk1GVStoiEx.read()
		JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i = rC5tnFDlQcRGA2(u"࠸࠰࠱ො"),HaTI5u1f3SCxmMAkw(u"ࠩࡒࡏࠬಲ")
	except:
		LhWaJkpQxVYm = CJlTSEpZsWb0QHg5w
		JsDZ0f79iTWLY412v5Ejl,j6h5EvtgIqUrYcKwl91p7RCJm4i = -P2Fgh6TCOWoaHjkqBcQnvRNXe,yylSaxCLfkte(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪಳ")
	try:
		if VVQyKTjakFdlEpIfo7Ruch and LhWaJkpQxVYm:
			TO3ypZhD9Ru8JCvbQl5BiXMgWz = {iIvKUWE23HyP0L.lower(): hhGo9uOjZXkLFg0Uvw6pPAN5 for iIvKUWE23HyP0L, hhGo9uOjZXkLFg0Uvw6pPAN5 in cDXLPHnAgY6NOk1GVStoiEx.headers.items()}
			if TO3ypZhD9Ru8JCvbQl5BiXMgWz.get(mi2ZJXCDzITuyev6gfn(u"ࠫࡦࡼ࠭ࡦࡰࡦࡶࡾࡶࡴࡪࡱࡱࠫ಴"))==I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ࡜ࡥࡳࡵ࡬ࡳࡳࠦ࠱࠯࠲ࠪವ"):
				LhWaJkpQxVYm = kUCfvjAP1c.tt4BxXNIpjgV6FkvHWu0aCToy(LhWaJkpQxVYm,cjVhOCwybeRo7UWg92(u"࠸࠲࠴࠺࠸࠾࠹࠵࠷ෝ"))
				if LhWaJkpQxVYm==KA26GucUHOwXL(u"࠭ࡆࡂࡋࡏࡉࡉࡥࡄࡆࡅࡕ࡝ࡕ࡚ࡉࡏࡉࠪಶ"):
					j6h5EvtgIqUrYcKwl91p7RCJm4i,JsDZ0f79iTWLY412v5Ejl = TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡊࡰࡹࡥࡱ࡯ࡤࠡࡃࡓࡍࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࠨಷ"),-GGsP9SDod4iUBm6kNMfLw
					LhWaJkpQxVYm = j6h5EvtgIqUrYcKwl91p7RCJm4i
	except: LhWaJkpQxVYm = CJlTSEpZsWb0QHg5w
	if A7Z6OVh20eCEUx and isinstance(LhWaJkpQxVYm,bytes): LhWaJkpQxVYm = LhWaJkpQxVYm.decode(Im5KSGZYBpRvdMVsbuXg)
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡘࡅࡔࡒࡒࡒࡘࡋࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪಸ")+str(JsDZ0f79iTWLY412v5Ejl)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡤࡷࡴࡴ࠺ࠡ࡝ࠣࠫಹ")+j6h5EvtgIqUrYcKwl91p7RCJm4i+Olh7n0zfV4(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ಺")+nqVYufmd4GFshQeHO9vp05+HaTI5u1f3SCxmMAkw(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ಻")+UfsBdAibG1326O5mDE4+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࠦ࡝ࠨ಼"))
	return LhWaJkpQxVYm
def I6sLSxrcnUTgZVNJwqmkKP4hbz1lOH(TiwVlmB1xYuy5UWthGIcbXz7Zof3D):
	tBV4MJKr7RsnuT8XahmqY = str(D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.randrange(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶ෞ"),mi2ZJXCDzITuyev6gfn(u"࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿ෟ")))
	L1MFAcDxPtTk4qbJu = {
		o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡵࡴࡧࡵࡣ࡮ࡪࠢಽ"):kaJFzbfodQNDR79cYjnw1yU5,
		pz4WBwfyDdgk0m2aRr7SMv(u"ࠢࡰࡵࡢࡺࡪࡸࡳࡪࡱࡱࠦಾ"):str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX),
		yylSaxCLfkte(u"ࠣࡣࡳࡴࡤࡼࡥࡳࡵ࡬ࡳࡳࠨಿ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,
		E6xdOMpqISHZCn(u"ࠤࡧࡩࡻ࡯ࡣࡦࡡࡩࡥࡲ࡯࡬ࡺࠤೀ"):Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,
		zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࠧು"): Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a,
		CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠦࡨࡧࡲࡳ࡫ࡨࡶࠧೂ"):Olh7n0zfV4(u"ࠧࡇࡒࡂࡄࡌࡇࡤ࡜ࡉࡅࡇࡒࡗࠧೃ"),
		o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡩࡱࠤೄ"): xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠢࠥࡴࡨࡱࡴࡺࡥࠣ೅"),
		yylSaxCLfkte(u"ࠣࠦࡶ࡯࡮ࡶ࡟ࡶࡵࡨࡶࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࡡࡶࡽࡳࡩࠢೆ"):VJZIMkUN5siqB21Pf
	}
	AUcMp3w1DOF4tRuejKXd9aLEzlnm = []
	for eeqpSKuXbQxUMkC3RIdBr1tW2 in TiwVlmB1xYuy5UWthGIcbXz7Zof3D:
		L7RjXk0D5eqaTrS6u9WhgAYFn = L1MFAcDxPtTk4qbJu.copy()
		L7RjXk0D5eqaTrS6u9WhgAYFn[s97s2k0LJgl(u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ೇ")] = eeqpSKuXbQxUMkC3RIdBr1tW2
		L7RjXk0D5eqaTrS6u9WhgAYFn[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡩࡻ࡫࡮ࡵࡡࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸ࠭ೈ")] = {HaTI5u1f3SCxmMAkw(u"ࠦࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣ೉"):eeqpSKuXbQxUMkC3RIdBr1tW2}
		L7RjXk0D5eqaTrS6u9WhgAYFn[yylSaxCLfkte(u"ࠬࡻࡳࡦࡴࡢࡴࡷࡵࡰࡦࡴࡷ࡭ࡪࡹࠧೊ")] = {XB4CjMkPFzhAHiI3q(u"ࠨࡕࡴࡧࡵࡣࡊࡼࡥ࡯ࡶࡢࡒࡦࡳࡥࠣೋ"):eeqpSKuXbQxUMkC3RIdBr1tW2}
		AUcMp3w1DOF4tRuejKXd9aLEzlnm.append(L7RjXk0D5eqaTrS6u9WhgAYFn)
	qPWgu3zkRbrv74yho = {
		EcjO3giln2kQTdBY0XLAG(u"ࠢࡢࡲ࡬ࡣࡰ࡫ࡹࠣೌ"):KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾್࠭"),
		E6xdOMpqISHZCn(u"ࠤ࡬ࡲࡸ࡫ࡲࡵࡡ࡬ࡨࠧ೎"):tBV4MJKr7RsnuT8XahmqY,
		yylSaxCLfkte(u"ࠥࡩࡻ࡫࡮ࡵࡵࠥ೏"): AUcMp3w1DOF4tRuejKXd9aLEzlnm
	}
	Dfi7FTuYWN49AaLEt3 = {E6xdOMpqISHZCn(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ೐"):CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ೑")}
	otaunYGVIJ2jX8HsKm7ecR0bAh4 = ZP1LyUCS3pIBu(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠶࠳ࡧ࡭ࡱ࡮࡬ࡸࡺࡪࡥ࠯ࡥࡲࡱ࠴࠸࠯ࡩࡶࡷࡴࡦࡶࡩࠨ೒")
	z4YnlxGHF2AMtrw = bQs8X1eOM6vauSBpIK5q0tJfDLwNn(mi2ZJXCDzITuyev6gfn(u"ࠧࡑࡑࡖࡘࠬ೓"),otaunYGVIJ2jX8HsKm7ecR0bAh4,qPWgu3zkRbrv74yho,Dfi7FTuYWN49AaLEt3,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧ೔"))
	return z4YnlxGHF2AMtrw
def oE7iT3HI5VDdmY4kPOjr(XpIWfPGjl4u9Czb82hJqeM6ya,AyKma12GRYnziLV7EWIjUM):
	AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.replace(ZP1LyUCS3pIBu(u"ࠩࡱࡹࡱࡲࠧೕ"),cjVhOCwybeRo7UWg92(u"ࠪࡒࡴࡴࡥࠨೖ"))
	AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.replace(E6xdOMpqISHZCn(u"ࠫࡹࡸࡵࡦࠩ೗"),KA26GucUHOwXL(u"࡚ࠬࡲࡶࡧࠪ೘"))
	AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.replace(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡦࡢ࡮ࡶࡩࠬ೙"),JACnOz297UuDK5HpPkc1LF(u"ࠧࡇࡣ࡯ࡷࡪ࠭೚"))
	AyKma12GRYnziLV7EWIjUM = AyKma12GRYnziLV7EWIjUM.replace(o2FdrDBimMuOw97q6QpNW8S(u"ࠨ࡞࠲ࠫ೛"),zQGaM7ctZCN(u"ࠩ࠲ࠫ೜"))
	try: r0XwiCFev4oKqbZm5upBQk = eval(AyKma12GRYnziLV7EWIjUM)
	except: r0XwiCFev4oKqbZm5upBQk = knjNZvrbGEaKB3oYCxHd8MW(XpIWfPGjl4u9Czb82hJqeM6ya)
	return r0XwiCFev4oKqbZm5upBQk
def HDWalJw09McEVi7mYBgSP():
	kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
	he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall(otNfFapeEnO(u"ࠪࡠࡩࡢࡤ࠻࡞ࡧࡠࡩࠦ࡜࡜࠱ࡆࡓࡑࡕࡒ࡝࡟ࠪೝ"),kuiZt5zMdvVJyC4LqwGDX,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if he0wn71osQ8NCFJ9xzIqrDXBMRY: kuiZt5zMdvVJyC4LqwGDX = kuiZt5zMdvVJyC4LqwGDX.split(he0wn71osQ8NCFJ9xzIqrDXBMRY[ZVNvqy4iF1a9X],P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	VVrQHyxnMeu3J1YTAfRsm = L8Wkv5KCSoq.strftime(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡤࠫ࡭࠯ࠧࡧࡣࠪࡎ࠺ࠦࡏࡢࠫೞ"),L8Wkv5KCSoq.localtime(U6YgVKS9rAmwe1RTPlQnfiGs))
	kuiZt5zMdvVJyC4LqwGDX = kuiZt5zMdvVJyC4LqwGDX+VVrQHyxnMeu3J1YTAfRsm
	LLGOIVqdTpZAFRgvQ0ChPc = kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(mw5hKxvWDZSQ):
		AAFCv5YQlirBegzb8Lq = open(mw5hKxvWDZSQ,cjVhOCwybeRo7UWg92(u"ࠬࡸࡢࠨ೟")).read()
		if A7Z6OVh20eCEUx: AAFCv5YQlirBegzb8Lq = AAFCv5YQlirBegzb8Lq.decode(Im5KSGZYBpRvdMVsbuXg)
		AAFCv5YQlirBegzb8Lq = oE7iT3HI5VDdmY4kPOjr(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡤࡪࡥࡷࠫೠ"),AAFCv5YQlirBegzb8Lq)
	else: AAFCv5YQlirBegzb8Lq = {}
	fTpbwJEnLgeiay = {}
	for BohpkIMqQKmRN in list(AAFCv5YQlirBegzb8Lq.keys()):
		if BohpkIMqQKmRN!=kcxAmftieK56PE9TqbDHdSrF8: fTpbwJEnLgeiay[BohpkIMqQKmRN] = AAFCv5YQlirBegzb8Lq[BohpkIMqQKmRN]
		else:
			if kuiZt5zMdvVJyC4LqwGDX and kuiZt5zMdvVJyC4LqwGDX!=TDpFsQXHze2q30uYtGPfEIm8(u"ࠧ࠯࠰ࠪೡ"):
				r98t2VSJ4q = AAFCv5YQlirBegzb8Lq[BohpkIMqQKmRN]
				if LLGOIVqdTpZAFRgvQ0ChPc in r98t2VSJ4q:
					lDgx8hPyYJvcX = r98t2VSJ4q.index(LLGOIVqdTpZAFRgvQ0ChPc)
					del r98t2VSJ4q[lDgx8hPyYJvcX]
				hA9Pip7QNB0mMR = [LLGOIVqdTpZAFRgvQ0ChPc]+r98t2VSJ4q
				hA9Pip7QNB0mMR = hA9Pip7QNB0mMR[:CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠸࠴෠")]
				fTpbwJEnLgeiay[BohpkIMqQKmRN] = hA9Pip7QNB0mMR
			else: fTpbwJEnLgeiay[BohpkIMqQKmRN] = AAFCv5YQlirBegzb8Lq[BohpkIMqQKmRN]
	if kcxAmftieK56PE9TqbDHdSrF8 not in list(fTpbwJEnLgeiay.keys()): fTpbwJEnLgeiay[kcxAmftieK56PE9TqbDHdSrF8] = [LLGOIVqdTpZAFRgvQ0ChPc]
	fTpbwJEnLgeiay = str(fTpbwJEnLgeiay)
	if A7Z6OVh20eCEUx: fTpbwJEnLgeiay = fTpbwJEnLgeiay.encode(Im5KSGZYBpRvdMVsbuXg)
	open(mw5hKxvWDZSQ,cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡹࡥࠫೢ")).write(fTpbwJEnLgeiay)
	return
def Hc6rjXpgb3CZuVKYk(qPWgu3zkRbrv74yho):
	if A7Z6OVh20eCEUx: import urllib.parse as NNtIZrLqyQ
	else: import urllib as NNtIZrLqyQ
	z137oDCwuY = NNtIZrLqyQ.urlencode(qPWgu3zkRbrv74yho)
	return z137oDCwuY
def ZQtv0jY9W6L8UHgpnKm(ysw7G3tqjo,pU731HfF4sAIayWOjRxzQu8LV=CJlTSEpZsWb0QHg5w,IvRjzalHbcZLBhCPfqXAG=CJlTSEpZsWb0QHg5w):
	LLrpSR3Picj6vDqzhFaW = pU731HfF4sAIayWOjRxzQu8LV not in [otNfFapeEnO(u"ࠩࡐ࠷࡚࠭ೣ"),s97s2k0LJgl(u"ࠪࡍࡕ࡚ࡖࠨ೤")]
	if not IvRjzalHbcZLBhCPfqXAG: IvRjzalHbcZLBhCPfqXAG = yylSaxCLfkte(u"ࠫࡻ࡯ࡤࡦࡱࠪ೥")
	F5aB7XeozwKDVJOt3SUy8l9,BOM6QXmwJe,E3Er8OlNQST5ojnZt4MsFp19uXVC = GISOTJh20W(u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪࠧ೦"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	if len(ysw7G3tqjo)==D9yBM7wPFLz:
		otaunYGVIJ2jX8HsKm7ecR0bAh4,IaO8BLRsvy,E3Er8OlNQST5ojnZt4MsFp19uXVC = ysw7G3tqjo
		if IaO8BLRsvy: BOM6QXmwJe = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࠠࠡࠢࡖࡹࡧࡺࡩࡵ࡮ࡨ࠾ࠥࡡࠠࠨ೧")+IaO8BLRsvy+E6xdOMpqISHZCn(u"ࠧࠡ࡟ࠪ೨")
	else: otaunYGVIJ2jX8HsKm7ecR0bAh4,IaO8BLRsvy,E3Er8OlNQST5ojnZt4MsFp19uXVC = ysw7G3tqjo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࠧ࠵࠴ࠬ೩"),YvOQBzaTAscXR9ql)
	pJkizt1GSHY62rhElDZjX = XETbMJIf1yetlQSinA2NW5YHvag6D(otaunYGVIJ2jX8HsKm7ecR0bAh4)
	if pU731HfF4sAIayWOjRxzQu8LV not in [rC5tnFDlQcRGA2(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ೪"),o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡍࡕ࡚ࡖࠨ೫")]:
		if pU731HfF4sAIayWOjRxzQu8LV!=otNfFapeEnO(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭೬"): otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.replace(YvOQBzaTAscXR9ql,s97s2k0LJgl(u"ࠬࠫ࠲࠱ࠩ೭"))
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࠠࠡࠢࡓࡶࡪࡶࡡࡳ࡫ࡱ࡫ࠥࡺ࡯ࠡࡲ࡯ࡥࡾ࠵ࡤࡰࡹࡱࡰࡴࡧࡤࠡࡸ࡬ࡨࡪࡵ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬ೮")+otaunYGVIJ2jX8HsKm7ecR0bAh4+cbmeD4WNZfAowxT2JdUMtV(u"ࠧࠡ࡟ࠪ೯")+BOM6QXmwJe)
		if pJkizt1GSHY62rhElDZjX==h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ೰") and pU731HfF4sAIayWOjRxzQu8LV not in [s97s2k0LJgl(u"ࠩࡌࡔ࡙࡜ࠧೱ"),E6xdOMpqISHZCn(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫೲ")]:
			import kUCfvjAP1c
			Uz8mMbZifCyvkLnct,MNXzjK3vV7D = kUCfvjAP1c.bUD0vMHIQhKW(pU731HfF4sAIayWOjRxzQu8LV,otaunYGVIJ2jX8HsKm7ecR0bAh4)
			InaYgGyu8qjsp1lOAbe4rKWVz = len(MNXzjK3vV7D)
			if InaYgGyu8qjsp1lOAbe4rKWVz>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				CrqTamtPFuU = kUCfvjAP1c.T4TK17YsEfZJ(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬೳ")+str(InaYgGyu8qjsp1lOAbe4rKWVz)+ZP1LyUCS3pIBu(u"ࠬࠦๅๅใࠬࠫ೴"), Uz8mMbZifCyvkLnct)
				if CrqTamtPFuU==-P2Fgh6TCOWoaHjkqBcQnvRNXe:
					kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(EcjO3giln2kQTdBY0XLAG(u"࠭ลๅ฼สลࠥ฿ๅๅ์ฬࠤฯฺฺ๋ๆࠣห้็๊ะ์๋ࠫ೵"),EcjO3giln2kQTdBY0XLAG(u"ࠧࡄࡣࡱࡧࡪࡲࠧ೶"))
					return F5aB7XeozwKDVJOt3SUy8l9
			else: CrqTamtPFuU = ZVNvqy4iF1a9X
			otaunYGVIJ2jX8HsKm7ecR0bAh4 = MNXzjK3vV7D[CrqTamtPFuU]
			if Uz8mMbZifCyvkLnct[ZVNvqy4iF1a9X]!=otNfFapeEnO(u"ࠨ࠯࠴ࠫ೷"):
				JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+VVvcQpCU3OM09n(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫࡬ࡦࡥࡷࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡪࡱࡱ࠾ࠥࡡࠠࠨ೸")+Uz8mMbZifCyvkLnct[CrqTamtPFuU]+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࠤࡢࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫ೹")+otaunYGVIJ2jX8HsKm7ecR0bAh4+o2FdrDBimMuOw97q6QpNW8S(u"ࠫࠥࡣࠧ೺"))
		if cbmeD4WNZfAowxT2JdUMtV(u"ࠬ࠵ࡩࡧ࡫࡯ࡱ࠴࠭೻") in otaunYGVIJ2jX8HsKm7ecR0bAh4: otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠫ࠭೼")
		elif rC5tnFDlQcRGA2(u"ࠧࡩࡶࡷࡴࠬ೽") in otaunYGVIJ2jX8HsKm7ecR0bAh4.lower() and TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨ࠱ࡧࡥࡸ࡮࠯ࠨ೾") not in otaunYGVIJ2jX8HsKm7ecR0bAh4 and TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧ೿") not in otaunYGVIJ2jX8HsKm7ecR0bAh4:
			otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4+HaTI5u1f3SCxmMAkw(u"ࠪࢀࠬഀ") if VVvcQpCU3OM09n(u"ࠫࢁ࠭ഁ") not in otaunYGVIJ2jX8HsKm7ecR0bAh4 else otaunYGVIJ2jX8HsKm7ecR0bAh4+zQGaM7ctZCN(u"ࠬࠬࠧം")
			if I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࠫഃ") not in otaunYGVIJ2jX8HsKm7ecR0bAh4 and JACnOz297UuDK5HpPkc1LF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࠩഄ") in otaunYGVIJ2jX8HsKm7ecR0bAh4.lower(): otaunYGVIJ2jX8HsKm7ecR0bAh4 += HaTI5u1f3SCxmMAkw(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠪࠬഅ")
			if zQGaM7ctZCN(u"ࠩࡸࡷࡪࡸ࠭ࡢࡩࡨࡲࡹࡃࠧആ") not in otaunYGVIJ2jX8HsKm7ecR0bAh4.lower() and pU731HfF4sAIayWOjRxzQu8LV not in [VVvcQpCU3OM09n(u"ࠪࡍࡕ࡚ࡖࠨഇ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡒ࠹ࡕࠨഈ")]: otaunYGVIJ2jX8HsKm7ecR0bAh4 += cjVhOCwybeRo7UWg92(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫഉ")
			if I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡲࡦࡨࡨࡶࡪࡸ࠽ࠨഊ") not in otaunYGVIJ2jX8HsKm7ecR0bAh4.lower(): otaunYGVIJ2jX8HsKm7ecR0bAh4 += yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࠬࠧഋ")
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+cbmeD4WNZfAowxT2JdUMtV(u"ࠨࠢࠣࠤࡌࡵࡴࠡࡨ࡬ࡲࡦࡲࠠࡶࡴ࡯ࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩഌ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+zQGaM7ctZCN(u"ࠩࠣࡡࠬ഍"))
	G50GsCJVZKfLvriEQb = rTF8V7fLD2SXJbAURpZjQ4wH.ListItem()
	IvRjzalHbcZLBhCPfqXAG,WU62iESYnP7,eijQF3OCM1UhZlsRynr8A,IZFnPiRjz6,YUhfx4yF86DI,onsBg7uQyD5qfSWrR3UjH0lkLCM4,uExN2ItKhmHpv0SJTXF5c8LM,t6oXbkTdmAK,eegb6SjDKLWAfnIHplYQ4 = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
	if pU731HfF4sAIayWOjRxzQu8LV not in [TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬഎ"),XB4CjMkPFzhAHiI3q(u"ࠫࡎࡖࡔࡗࠩഏ")]:
		if BB7oCRfQNSYj5qDhTUevV: o65tSBGwWj8TYAlaIv = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯ࡤࡨࡩࡵ࡮ࠨഐ")
		else: o65tSBGwWj8TYAlaIv = KA26GucUHOwXL(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࠫ഑")
		G50GsCJVZKfLvriEQb.setProperty(o65tSBGwWj8TYAlaIv, CJlTSEpZsWb0QHg5w)
		G50GsCJVZKfLvriEQb.setMimeType(XB4CjMkPFzhAHiI3q(u"ࠧ࡮࡫ࡰࡩ࠴ࡾ࠭ࡵࡻࡳࡩࠬഒ"))
		if K9MoWfyg6w2EHIki4lLtFSzpxQTmRX<s97s2k0LJgl(u"࠶࠵෡"): G50GsCJVZKfLvriEQb.setInfo(TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡸ࡬ࡨࡪࡵࠧഓ"),{yylSaxCLfkte(u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬഔ"):JACnOz297UuDK5HpPkc1LF(u"ࠪࡱࡴࡼࡩࡦࠩക")})
		else:
			ny5T4cQM92xlzFuI173AkBm = G50GsCJVZKfLvriEQb.getVideoInfoTag()
			ny5T4cQM92xlzFuI173AkBm.setMediaType(EcjO3giln2kQTdBY0XLAG(u"ࠫࡲࡵࡶࡪࡧࠪഖ"))
		G50GsCJVZKfLvriEQb.setArt({zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡺࡨࡶ࡯ࡥࠫഗ"):YUhfx4yF86DI,cjVhOCwybeRo7UWg92(u"࠭ࡰࡰࡵࡷࡩࡷ࠭ഘ"):YUhfx4yF86DI,Olh7n0zfV4(u"ࠧࡣࡣࡱࡲࡪࡸࠧങ"):YUhfx4yF86DI,EcjO3giln2kQTdBY0XLAG(u"ࠨࡨࡤࡲࡦࡸࡴࠨച"):YUhfx4yF86DI,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫഛ"):YUhfx4yF86DI,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ജ"):YUhfx4yF86DI,GISOTJh20W(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧഝ"):YUhfx4yF86DI,cjVhOCwybeRo7UWg92(u"ࠬ࡯ࡣࡰࡰࠪഞ"):YUhfx4yF86DI})
		if pJkizt1GSHY62rhElDZjX in [VVvcQpCU3OM09n(u"࠭࠮࡮ࡲࡧࠫട"),XB4CjMkPFzhAHiI3q(u"ࠧ࠯࡯࠶ࡹ࠽࠭ഠ")]: G50GsCJVZKfLvriEQb.setContentLookup(w2qb6lf5EM)
		else: G50GsCJVZKfLvriEQb.setContentLookup(VJZIMkUN5siqB21Pf)
		from tAoP1fdO67 import nn3q8dAwhfx
		if I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡴࡷࡱࡵ࠭ഡ") in otaunYGVIJ2jX8HsKm7ecR0bAh4:
			nn3q8dAwhfx(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬഢ"),VJZIMkUN5siqB21Pf)
		elif pJkizt1GSHY62rhElDZjX==ZP1LyUCS3pIBu(u"ࠪ࠲ࡲࡶࡤࠨണ") or rC5tnFDlQcRGA2(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫത") in otaunYGVIJ2jX8HsKm7ecR0bAh4:
			nn3q8dAwhfx(TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬഥ"),VJZIMkUN5siqB21Pf)
			G50GsCJVZKfLvriEQb.setProperty(o65tSBGwWj8TYAlaIv,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠭ദ"))
			G50GsCJVZKfLvriEQb.setProperty(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫࠮࡮ࡣࡱ࡭࡫࡫ࡳࡵࡡࡷࡽࡵ࡫ࠧധ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨ࡯ࡳࡨࠬന"))
		if IaO8BLRsvy:
			G50GsCJVZKfLvriEQb.setSubtitles([IaO8BLRsvy])
	if IvRjzalHbcZLBhCPfqXAG==E6xdOMpqISHZCn(u"ࠩࡹ࡭ࡩ࡫࡯ࠨഩ") and pU731HfF4sAIayWOjRxzQu8LV==yylSaxCLfkte(u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬപ"):
		F5aB7XeozwKDVJOt3SUy8l9 = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫഫ")
		pU731HfF4sAIayWOjRxzQu8LV = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡖࡌࡂ࡛ࡢࡈࡑࡥࡆࡊࡎࡈࡗࠬബ")
	elif IvRjzalHbcZLBhCPfqXAG==mi2ZJXCDzITuyev6gfn(u"࠭ࡶࡪࡦࡨࡳࠬഭ") and t6oXbkTdmAK.startswith(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࠷ࠩമ")):
		F5aB7XeozwKDVJOt3SUy8l9 = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭യ")
		pU731HfF4sAIayWOjRxzQu8LV = pU731HfF4sAIayWOjRxzQu8LV+o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡢࡈࡑ࠭ര")
	if F5aB7XeozwKDVJOt3SUy8l9!=od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨറ"): HDWalJw09McEVi7mYBgSP()
	X3oVsDYURKICHtuNvpMlGgbazL5.eS9wcjItZ7YAK(pU731HfF4sAIayWOjRxzQu8LV)
	if X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc: return od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡧࡲ࡯ࡤ࡭ࡨࡨࠬല")
	if IvRjzalHbcZLBhCPfqXAG==s97s2k0LJgl(u"ࠬࡼࡩࡥࡧࡲࠫള") and not t6oXbkTdmAK.startswith(EcjO3giln2kQTdBY0XLAG(u"࠭࠶ࠨഴ")):
		G50GsCJVZKfLvriEQb.setPath(otaunYGVIJ2jX8HsKm7ecR0bAh4)
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+Olh7n0zfV4(u"࡚ࠧࠡࠢࠣ࡮ࡪࡥࡰࠢࡳࡰࡦࡿࠠࡶࡵ࡬ࡲ࡬ࠦࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࠪࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧവ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࠢࡠࠫശ"))
		ZqpKwnSTtsNmWYCfueOxd14.setResolvedUrl(b4qsaVwC0mHOGPKp5,w2qb6lf5EM,G50GsCJVZKfLvriEQb)
	elif IvRjzalHbcZLBhCPfqXAG==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩ࡯࡭ࡻ࡫ࠧഷ"):
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+s97s2k0LJgl(u"ࠪࠤࠥࠦࡌࡪࡸࡨࠤࡵࡲࡡࡺࠢࡸࡷ࡮ࡴࡧࠡࡲ࡯ࡥࡾ࠮࡚ࠩࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭സ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࠥࡣࠧഹ"))
		X3oVsDYURKICHtuNvpMlGgbazL5.play(otaunYGVIJ2jX8HsKm7ecR0bAh4,G50GsCJVZKfLvriEQb)
	cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
	if F5aB7XeozwKDVJOt3SUy8l9==TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠪഺ"):
		from OXpy1BlZPe import eHZnogWEkjXcLl1dUs
		cn0XyId7MkTCE1RifFhwQDN = eHZnogWEkjXcLl1dUs(otaunYGVIJ2jX8HsKm7ecR0bAh4,pJkizt1GSHY62rhElDZjX,pU731HfF4sAIayWOjRxzQu8LV)
		if cn0XyId7MkTCE1RifFhwQDN: HDWalJw09McEVi7mYBgSP()
	else:
		p3voWAbJhDmLaI2lgYGcVMEX,F5aB7XeozwKDVJOt3SUy8l9,BBwkv2TnxQyrl,C7kdZq9Gx2vhUQ,KTJlC5hivY6ZQctbNu0mxwP = ZVNvqy4iF1a9X,XB4CjMkPFzhAHiI3q(u"࠭ࡴࡳ࡫ࡨࡨ഻ࠬ"),VJZIMkUN5siqB21Pf,pz4WBwfyDdgk0m2aRr7SMv(u"࠷࠰࠱࠲෣"),KA26GucUHOwXL(u"࠹࠻࠰࠱࠲෢")
		if LLrpSR3Picj6vDqzhFaW: import kUCfvjAP1c
		while p3voWAbJhDmLaI2lgYGcVMEX<KTJlC5hivY6ZQctbNu0mxwP:
			pKVikfGen4wMt80UTscxWjAoCZ5S.sleep(C7kdZq9Gx2vhUQ)
			p3voWAbJhDmLaI2lgYGcVMEX += C7kdZq9Gx2vhUQ
			if X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc==Olh7n0zfV4(u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࠨ഼") and not BBwkv2TnxQyrl:
				if LLrpSR3Picj6vDqzhFaW: kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(mi2ZJXCDzITuyev6gfn(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊อษาࠤฬ๊แ๋ัํ์ࠬഽ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡖࡹࡨࡩࡥࡴࡵࠪാ"),L8Wkv5KCSoq=Olh7n0zfV4(u"࠷࠶࠲෤"))
				JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡵࡷࡥࡷࡺࡥࡥࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧി")+otaunYGVIJ2jX8HsKm7ecR0bAh4+zQGaM7ctZCN(u"ࠫࠥࡣࠧീ")+BOM6QXmwJe)
				BBwkv2TnxQyrl = w2qb6lf5EM
			elif X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc in [s97s2k0LJgl(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭ു"),HaTI5u1f3SCxmMAkw(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧൂ")]:
				JwKDl495gRWA8jfsEbLhHQPnceFOqz(MMxceZuwFzkCp9y0R,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+s97s2k0LJgl(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻ࡬ࡲ࡬ࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫൃ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+EcjO3giln2kQTdBY0XLAG(u"ࠨࠢࡠࠫൄ")+BOM6QXmwJe)
				break
			elif X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc==o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ൅"):
				JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+GISOTJh20W(u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡰ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡘ࡬ࡨࡪࡵ࠺ࠡ࡝ࠣࠫെ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+KA26GucUHOwXL(u"ࠫࠥࡣࠧേ")+BOM6QXmwJe)
				if LLrpSR3Picj6vDqzhFaW: kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩൈ"),otNfFapeEnO(u"࠭ࡆࡢ࡫࡯ࡹࡷ࡫ࠧ൉"),L8Wkv5KCSoq=HaTI5u1f3SCxmMAkw(u"࠸࠷࠳෥"))
				break
			elif X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc==zQGaM7ctZCN(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨൊ"):
				JwKDl495gRWA8jfsEbLhHQPnceFOqz(LMcWw6B48Dj,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࠢࠣࠤࡉ࡫ࡶࡪࡥࡨࠤ࡮ࡹࠠࡣ࡮ࡲࡧࡰ࡫ࡤ࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭ോ")+otaunYGVIJ2jX8HsKm7ecR0bAh4+EcjO3giln2kQTdBY0XLAG(u"ࠩࠣࡡࠬൌ"))
				break
		else: F5aB7XeozwKDVJOt3SUy8l9 = rC5tnFDlQcRGA2(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷ്ࠫ")
	if F5aB7XeozwKDVJOt3SUy8l9 in [HaTI5u1f3SCxmMAkw(u"ࠫࡵࡲࡡࡺࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫൎ")] or X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc in [EcjO3giln2kQTdBY0XLAG(u"ࠬࡶ࡬ࡢࡻ࡬ࡲ࡬࠭൏"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ൐")] or cn0XyId7MkTCE1RifFhwQDN: yfL6aW08mk9wbt75r2cUnVeqSC(pU731HfF4sAIayWOjRxzQu8LV)
	else: exec(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡪ࡯ࡳࡳࡷࡺࠠࡹࡤࡰࡧࡀࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠬ൑"))
	BL9EG8ulJM5 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player().isPlaying()
	if not BL9EG8ulJM5 and F5aB7XeozwKDVJOt3SUy8l9 not in [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭൒")]:
		msg = cbmeD4WNZfAowxT2JdUMtV(u"ࠩࡗ࡭ࡲ࡫࡯ࡶࡶࠪ൓") if F5aB7XeozwKDVJOt3SUy8l9==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫൔ") else JACnOz297UuDK5HpPkc1LF(u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬൕ")
		if LLrpSR3Picj6vDqzhFaW: kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬ็ิๅฬࠣ฽๊๊๊สࠢอุ฿๐ไࠡษ็ๅ๏ี๊้ࠩൖ"),msg,L8Wkv5KCSoq=zz679V18GdcZwvrRexA0nNptY2Tab(u"࠹࠸࠴෦"))
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+HaTI5u1f3SCxmMAkw(u"࠭ࠠࠡࠢࠪൗ")+msg+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠻࡙ࠢࠣࡳࡱ࡮ࡰࡹࡱࠤࡵࡸ࡯ࡣ࡮ࡨࡱࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ൘")+otaunYGVIJ2jX8HsKm7ecR0bAh4+O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࠢࡠࠫ൙")+BOM6QXmwJe)
	return X3oVsDYURKICHtuNvpMlGgbazL5.RaPEyvwJUfzS96BhnmOCleY0tuxKNc
def XETbMJIf1yetlQSinA2NW5YHvag6D(otaunYGVIJ2jX8HsKm7ecR0bAh4):
	if KA26GucUHOwXL(u"ࠩࡂࠫ൚") in otaunYGVIJ2jX8HsKm7ecR0bAh4: otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.split(EcjO3giln2kQTdBY0XLAG(u"ࠪࡃࠬ൛"))[ZVNvqy4iF1a9X]
	if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࢁ࠭൜") in otaunYGVIJ2jX8HsKm7ecR0bAh4: otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.split(GISOTJh20W(u"ࠬࢂࠧ൝"))[ZVNvqy4iF1a9X]
	path = h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭࠯ࠨ൞").join(otaunYGVIJ2jX8HsKm7ecR0bAh4.split(KA26GucUHOwXL(u"ࠧ࠰ࠩൟ"))[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠶෧"):]) if s97s2k0LJgl(u"ࠨ࠼࠲࠳ࠬൠ") in otaunYGVIJ2jX8HsKm7ecR0bAh4 else otaunYGVIJ2jX8HsKm7ecR0bAh4
	pjYwrJk92aym7LK8qUAHeh6to1cbG = Zy2l0g8QU5vqefaTrsw.findall(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ࡟࠲࠭ࡡࡡ࠮ࡼ࠳࠱࠾ࡣࡻ࠳࠮࠷ࢁ࠮࠭ൡ"),path,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if pjYwrJk92aym7LK8qUAHeh6to1cbG:
		pjYwrJk92aym7LK8qUAHeh6to1cbG = pjYwrJk92aym7LK8qUAHeh6to1cbG[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
		rVeXsPYmKMBn3DNR8ZjQv9oplhxa7 = [mi2ZJXCDzITuyev6gfn(u"ࠪࡱ࠸ࡻ࠸ࠨൢ"),zQGaM7ctZCN(u"ࠫࡲࡶ࠴ࠨൣ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡳࡰࡥࠩ൤"),yylSaxCLfkte(u"࠭ࡷࡦࡤࡰࠫ൥"),VVvcQpCU3OM09n(u"ࠧࡢࡸ࡬ࠫ൦"),cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡣࡤࡧࠬ൧"),s97s2k0LJgl(u"ࠩࡰ࠷ࡺ࠭൨"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡱࡰࡼࠧ൩"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫ࡫ࡲࡶࠨ൪"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡳࡰ࠴ࠩ൫"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡴࡴࠩ൬")]
		if pjYwrJk92aym7LK8qUAHeh6to1cbG in rVeXsPYmKMBn3DNR8ZjQv9oplhxa7: return otNfFapeEnO(u"ࠧ࠯ࠩ൭")+pjYwrJk92aym7LK8qUAHeh6to1cbG
	return CJlTSEpZsWb0QHg5w
def yfL6aW08mk9wbt75r2cUnVeqSC(L7RjXk0D5eqaTrS6u9WhgAYFn):
	if not Ew2zQ8u7Ss.wsrSnHQfOWm8: L7RjXk0D5eqaTrS6u9WhgAYFn += EcjO3giln2kQTdBY0XLAG(u"ࠨࡡࡗࡗࠬ൮")
	Ew2zQ8u7Ss.SEND_THESE_EVENTS.append(L7RjXk0D5eqaTrS6u9WhgAYFn)
	return
def JXBCMi3e9AW0PjShnfYxpRUbgGcv4(CWkPFSgf6tYV5ircXjb=VJZIMkUN5siqB21Pf):
	M1ZhJtx9FrvpBL5PQgudw7E = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩ൯"))
	AgesnIjOpZS46(CWkPFSgf6tYV5ircXjb,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭൰"))
	A8v6c2fL7egwWCF3YBqr4kXSRn.exit()
def AgesnIjOpZS46(CWkPFSgf6tYV5ircXjb,uErMFcVGBXUvtJZ90zCTPxn2YW):
	if uErMFcVGBXUvtJZ90zCTPxn2YW:
		if zQGaM7ctZCN(u"ࠫࡤࡥ࡟ࡇࡑࡕࡇࡊࡥࡅ࡙ࡋࡗࡣࡤࡥࠧ൱") in uErMFcVGBXUvtJZ90zCTPxn2YW: JwKDl495gRWA8jfsEbLhHQPnceFOqz(CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"ࠬࡥ࡟ࡠࡈࡒࡖࡈࡋ࡟ࡆ࡚ࡌࡘࡤࡥ࡟ࠨ൲"))
		else:
			T5D9Uw47odNRKvZg6bLurViGeJq = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡡࡷ࠰࡯ࡥࡳ࡭ࡵࡢࡩࡨ࠲ࡹࡸࡡ࡯ࡵ࡯ࡥࡹ࡫ࠧ൳"))
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(HaTI5u1f3SCxmMAkw(u"ࠧࡢࡸ࠱ࡰࡦࡴࡧࡶࡣࡪࡩ࠳ࡺࡲࡢࡰࡶࡰࡦࡺࡥࠨ൴"),CJlTSEpZsWb0QHg5w)
			import kUCfvjAP1c
			kUCfvjAP1c.nAtVz16YSq0Jf(uErMFcVGBXUvtJZ90zCTPxn2YW)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(yylSaxCLfkte(u"ࠨࡣࡹ࠲ࡱࡧ࡮ࡨࡷࡤ࡫ࡪ࠴ࡴࡳࡣࡱࡷࡱࡧࡴࡦࠩ൵"),T5D9Uw47odNRKvZg6bLurViGeJq)
	Qlu9Ih6YOVFw7X34(EcjO3giln2kQTdBY0XLAG(u"ࠩࡶࡸࡴࡶࠧ൶"))
	QgwJd8Sfs07zyqlmiKWRrCP9Dn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧ൷"))
	if QgwJd8Sfs07zyqlmiKWRrCP9Dn==E6xdOMpqISHZCn(u"ࠫࡗࡋࡑࡖࡇࡖࡘࡤࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬ൸"): ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(XB4CjMkPFzhAHiI3q(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩ൹"),ZP1LyUCS3pIBu(u"࠭ࡒࡆࡈࡕࡉࡘࡎ࡟ࡄࡃࡆࡌࡊ࠭ൺ"))
	elif QgwJd8Sfs07zyqlmiKWRrCP9Dn==E6xdOMpqISHZCn(u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࡠࡅࡄࡇࡍࡋࠧൻ"): ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(cjVhOCwybeRo7UWg92(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬർ"),CJlTSEpZsWb0QHg5w)
	if ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(ZP1LyUCS3pIBu(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬൽ")) not in [cjVhOCwybeRo7UWg92(u"ࠪࡅ࡚࡚ࡏࠨൾ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡘ࡚ࡏࡑࠩൿ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡇࡓࡌࠩ඀")]: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡪ࡮ࡴࠩඁ"),s97s2k0LJgl(u"ࠧࡂࡕࡎࠫං"))
	if ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ඃ")) not in [yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡄ࡙࡙ࡕࠧ඄"),ZP1LyUCS3pIBu(u"ࠪࡗ࡙ࡕࡐࠨඅ"),EcjO3giln2kQTdBY0XLAG(u"ࠫࡆ࡙ࡋࠨආ")]: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡵࡸ࡯ࡹࡻࠪඇ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡁࡔࡍࠪඈ"))
	L7WjNGAsQrftauR = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(EcjO3giln2kQTdBY0XLAG(u"ࠧࡢࡸ࠱ࡱࡾࡹ࡫ࡪࡰ࠱ࡺ࡮࡫ࡷ࡮ࡱࡧࡩࠬඉ"))
	qhesyXgdkYi = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫඊ"))
	if zQGaM7ctZCN(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨඋ") in str(qhesyXgdkYi) and L7WjNGAsQrftauR in [XB4CjMkPFzhAHiI3q(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹ࠭ඌ"),ZP1LyUCS3pIBu(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪඍ")]:
		L8Wkv5KCSoq.sleep(yylSaxCLfkte(u"࠴࠳࠷࠰࠱෨"))
		pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(otNfFapeEnO(u"ࠬࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡕࡨࡸ࡛࡯ࡥࡸࡏࡲࡨࡪ࠮࠰ࠪࠩඎ"))
	if ZVNvqy4iF1a9X and b4qsaVwC0mHOGPKp5>-P2Fgh6TCOWoaHjkqBcQnvRNXe:
		ZqpKwnSTtsNmWYCfueOxd14.setResolvedUrl(b4qsaVwC0mHOGPKp5,VJZIMkUN5siqB21Pf,rTF8V7fLD2SXJbAURpZjQ4wH.ListItem())
		cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui = VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf
		ZqpKwnSTtsNmWYCfueOxd14.endOfDirectory(b4qsaVwC0mHOGPKp5,cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui)
	if Ew2zQ8u7Ss.SEND_THESE_EVENTS: I6sLSxrcnUTgZVNJwqmkKP4hbz1lOH(Ew2zQ8u7Ss.SEND_THESE_EVENTS)
	AgN4lvw09oPQS5uiqBI2TCWx7 = JCLpPcYQ1NSGX4Vz()
	if AgN4lvw09oPQS5uiqBI2TCWx7 and not Ew2zQ8u7Ss.resolveonly:
		Ew2zQ8u7Ss.resolveonly = w2qb6lf5EM
		BL9EG8ulJM5 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player().isPlaying()
		if not BL9EG8ulJM5: M1ZhJtx9FrvpBL5PQgudw7E = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺ࠮ࡄ࡮ࡨࡥࡷࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡵࡲࡡࡺ࡮࡬ࡷࡹ࡯ࡤࠣ࠼࠴ࢁࢂ࠭ඏ"))
		else:
			nn4f6gVzyS52ZxMAt9JsjFeGm = RqL2CVTJms1UfyxXoOuvBI()
			if nn4f6gVzyS52ZxMAt9JsjFeGm:
				import kUCfvjAP1c
				for lljAD6u8pm13sXYRJgvPQKB5 in range(ZVNvqy4iF1a9X,UpTN8c01LBJ,D9yBM7wPFLz):
					L8Wkv5KCSoq.sleep(D9yBM7wPFLz)
					BL9EG8ulJM5 = pKVikfGen4wMt80UTscxWjAoCZ5S.Player().isPlaying()
					if not BL9EG8ulJM5:
						kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(zQGaM7ctZCN(u"ࠧศๆไ๎ิ๐่ࠡษ็่ฬำโࠨඐ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠨว็฾ฬวࠠโฯุࠤฬ๊ำ๋ำไีฬะࠧඑ"),L8Wkv5KCSoq=TMfV6892ZoBdyxCH3tGrkwY0K(u"࠺࠶࠰෩"))
						break
				else:
					kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = Ggp2PFN048WD7rRkC6Uqit(nn4f6gVzyS52ZxMAt9JsjFeGm)
					if not any(value in kuiZt5zMdvVJyC4LqwGDX for value in kUCfvjAP1c.NOT_TO_TEST_ALL_SERVERS):
						kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(JACnOz297UuDK5HpPkc1LF(u"ࠩส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠪඒ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨඓ"),L8Wkv5KCSoq=ZP1LyUCS3pIBu(u"࠽࠵࠱෪"))
						L8Wkv5KCSoq.sleep(KA26GucUHOwXL(u"࠲෫"))
						if BB7oCRfQNSYj5qDhTUevV:
							otaunYGVIJ2jX8HsKm7ecR0bAh4 = otaunYGVIJ2jX8HsKm7ecR0bAh4.encode(Im5KSGZYBpRvdMVsbuXg)
						kUCfvjAP1c.BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY)
						SD0TxMRXiep4cjPBsnzI = kUCfvjAP1c.M4g7Ho2s8EhVxbyN1d0n(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
						kUCfvjAP1c.BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E)
						kUCfvjAP1c.KhwN2zcb7iMkjS5E4WURxByPGon(rC5tnFDlQcRGA2(u"ࠫฬ๊แ๋ัํ์ࠥอไๅษะๆࠬඔ"),yylSaxCLfkte(u"ࠬอๆห้์ࠤๆำีࠡษ็ื๏ืแาษอࠫඕ"),L8Wkv5KCSoq=E6xdOMpqISHZCn(u"࠸࠷࠳෬"))
						CWkPFSgf6tYV5ircXjb = VJZIMkUN5siqB21Pf
	TT7WzUmOPGJIbheSrXvukiDj30c = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪඖ"))
	if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧ࠮ࠩ඗") in TT7WzUmOPGJIbheSrXvukiDj30c:
		TT7WzUmOPGJIbheSrXvukiDj30c = TT7WzUmOPGJIbheSrXvukiDj30c.replace(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨ࠯ࠪ඘"),CJlTSEpZsWb0QHg5w)
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡨࡩࡵࡴࡤࡸࡪ࠭඙"),TT7WzUmOPGJIbheSrXvukiDj30c)
	if CWkPFSgf6tYV5ircXjb: pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧක"))
	return
def RqL2CVTJms1UfyxXoOuvBI():
	QLF9rgaUl3EhVXJqs0ZGeO8 = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(otNfFapeEnO(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡔࡱࡧࡹ࡭࡫ࡶࡸ࠳ࡍࡥࡵࡋࡷࡩࡲࡹࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡩࡥࠤ࠽࠵࠱ࠨࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠥ࠾ࡠࠨࡴࡪࡶ࡯ࡩࠧ࠲ࠢࡧ࡫࡯ࡩࠧ࠲ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࡡࢂ࠲ࠢࡪࡦࠥ࠾࠶ࢃࠧඛ"))
	SD0TxMRXiep4cjPBsnzI = KSHcVmz2W84iQvbRDBhGldpCL.loads(QLF9rgaUl3EhVXJqs0ZGeO8)[Olh7n0zfV4(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬග")]
	nn4f6gVzyS52ZxMAt9JsjFeGm = CJlTSEpZsWb0QHg5w
	try: items = SD0TxMRXiep4cjPBsnzI[HaTI5u1f3SCxmMAkw(u"࠭ࡩࡵࡧࡰࡷࠬඝ")]
	except: return CJlTSEpZsWb0QHg5w
	if items:
		for ykAihXr9IU82HQqMx7tj5,file in enumerate(items):
			path = file[cjVhOCwybeRo7UWg92(u"ࠧࡧ࡫࡯ࡩࠬඞ")]
			if R7xafKV3ekjDc not in path: continue
			path = path.split(R7xafKV3ekjDc)[P2Fgh6TCOWoaHjkqBcQnvRNXe][P2Fgh6TCOWoaHjkqBcQnvRNXe:]
			if path==zz4EDG1PtiyX3JVUlBeC: break
		count = SD0TxMRXiep4cjPBsnzI[E6xdOMpqISHZCn(u"ࠨ࡮࡬ࡱ࡮ࡺࡳࠨඟ")][h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡷࡳࡹࡧ࡬ࠨච")]
		if ykAihXr9IU82HQqMx7tj5+P2Fgh6TCOWoaHjkqBcQnvRNXe<count: nn4f6gVzyS52ZxMAt9JsjFeGm = items[ykAihXr9IU82HQqMx7tj5+P2Fgh6TCOWoaHjkqBcQnvRNXe][zQGaM7ctZCN(u"ࠪࡪ࡮ࡲࡥࠨඡ")]
	return nn4f6gVzyS52ZxMAt9JsjFeGm
def JCLpPcYQ1NSGX4Vz():
	M1ZhJtx9FrvpBL5PQgudw7E = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(yylSaxCLfkte(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡹ࡭ࡩ࡫࡯ࡱ࡮ࡤࡽࡪࡸ࠮ࡢࡷࡷࡳࡵࡲࡡࡺࡰࡨࡼࡹ࡯ࡴࡦ࡯ࠥࢁࢂ࠭ජ"))
	aBNLtkVZn5K3T = VJZIMkUN5siqB21Pf if yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡡ࡝ࠨඣ") in str(M1ZhJtx9FrvpBL5PQgudw7E) else w2qb6lf5EM
	return aBNLtkVZn5K3T
def Qlu9Ih6YOVFw7X34(TT8tFjgfcI9H1rKLYXasyGhRo):
	if Ew2zQ8u7Ss.busydialog_active:
		if TT8tFjgfcI9H1rKLYXasyGhRo==TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡳࡵࡱࡳࠫඤ"):
			NNFUJPzhHKqZv0g1LVodXIwRec5i8 = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡣࡷࡶࡽࡩ࡯ࡡ࡭ࡱࡪࡲࡴࡩࡡ࡯ࡥࡨࡰࠬඥ") if K9MoWfyg6w2EHIki4lLtFSzpxQTmRX>KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠳࠺࠲࠾࠿෭") else rC5tnFDlQcRGA2(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࠬඦ")
			pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࠩට")+NNFUJPzhHKqZv0g1LVodXIwRec5i8+TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࠭ࠬඨ"))
			Ew2zQ8u7Ss.busydialog_active = VJZIMkUN5siqB21Pf
	else:
		if TT8tFjgfcI9H1rKLYXasyGhRo==EcjO3giln2kQTdBY0XLAG(u"ࠫࡸࡺࡡࡳࡶࠪඩ"):
			NNFUJPzhHKqZv0g1LVodXIwRec5i8 = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࡰࡲࡧࡦࡴࡣࡦ࡮ࠪඪ") if K9MoWfyg6w2EHIki4lLtFSzpxQTmRX>GISOTJh20W(u"࠴࠻࠳࠿࠹෮") else yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡢࡶࡵࡼࡨ࡮ࡧ࡬ࡰࡩࠪණ")
			pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(Olh7n0zfV4(u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࠩඬ")+NNFUJPzhHKqZv0g1LVodXIwRec5i8+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࠫࠪත"))
			Ew2zQ8u7Ss.busydialog_active = w2qb6lf5EM
	return
def M1L4HSe3CfNJ(*args,**SrtHZ8aVe6TjKok24bIiPuxyD):
	daemon = SrtHZ8aVe6TjKok24bIiPuxyD.pop(JACnOz297UuDK5HpPkc1LF(u"ࠩࡧࡥࡪࡳ࡯࡯ࠩථ"),VJZIMkUN5siqB21Pf)
	Q46gK1iwY5dUEG3a = CCARSBDXLj0NFfpu14.Thread(*args,**SrtHZ8aVe6TjKok24bIiPuxyD)
	Q46gK1iwY5dUEG3a.daemon = daemon
	return Q46gK1iwY5dUEG3a
Rsu58Dkb9KSnL = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,EcjO3giln2kQTdBY0XLAG(u"ࠪࡰ࡮ࡹࡴࠨද"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧධ"),JACnOz297UuDK5HpPkc1LF(u"࡙ࠬࡉࡕࡇࡖࡣࡈࡎࡅࡄࡍࠪන"))
if Rsu58Dkb9KSnL:
	EnTfOsZ26YjNvpH3,WkQBPFOw1HT,pNeCUAFcoOH,SYdpJq85kcXe74OInr9bwTE = Rsu58Dkb9KSnL
	Ew2zQ8u7Ss.AV_CLIENT_IDS = rJ9cgWz4FU.join(EnTfOsZ26YjNvpH3)
if not Ew2zQ8u7Ss.AV_CLIENT_IDS: Ew2zQ8u7Ss.AV_CLIENT_IDS = qqwenxatQlYJLD()
X3oVsDYURKICHtuNvpMlGgbazL5 = OUf6wJ2AILcTnDF1()
Ew2zQ8u7Ss.wpBxtqcsDEafMFkToIXe,Ew2zQ8u7Ss.wsrSnHQfOWm8,Ew2zQ8u7Ss.QFCWcArusifVavlYk29,Ew2zQ8u7Ss.krgh8yUEqa,Ew2zQ8u7Ss.avprivsnorestrict,Ew2zQ8u7Ss.avprivslongperiod = ed1Dvp6KAOcY2lFNzgm5t4ifE0h8([KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧ඲"),o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨඳ"),cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭ප"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪඵ"),yylSaxCLfkte(u"ࠪࡆ࡙ࡋࡸࡑࡘ࠴࠽ࡘࡘࡖࡏࡗࡘ࡯ࡱࡊࡖࡆࡘࡈ࡜ࠬබ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡒ࡚࠰࠶ࡊ࡛࠴ࡱ࡚ࡔࡆࡈࡑࡗ࡚ࡔࡦࡖࡇ࡙ࡗࡘ࡛࠹ࡆ࡚ࠪභ")])
kaJFzbfodQNDR79cYjnw1yU5 = Ew2zQ8u7Ss.AV_CLIENT_IDS.splitlines()[ZVNvqy4iF1a9X][-Olh7n0zfV4(u"࠶࠹෯"):]
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
Hk0y5BFPUwlGDoiA7pu8 = 'EXCLUDES'
def I9UcFRy0AV51HZ3nTXW2eJmBMbigdP(idaKcvOmbRrkW1CtHhZfeAJQV4D,wbWJX8PB4v3OM):
	wbWJX8PB4v3OM = wbWJX8PB4v3OM.replace(Dj62UpP5MrbTkJqhRa,CJlTSEpZsWb0QHg5w).replace(' '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w)[P2Fgh6TCOWoaHjkqBcQnvRNXe:]
	F2Zh6YQLU7naWe = Zy2l0g8QU5vqefaTrsw.findall('[a-zA-Z]',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if 'بحث IPTV - ' in idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace('بحث IPTV - ',s6rxOhWUy0bXDdQMJleNmu+'بحث IPTV - '+s6rxOhWUy0bXDdQMJleNmu)
	elif ' IPTV' in idaKcvOmbRrkW1CtHhZfeAJQV4D and wbWJX8PB4v3OM=='IPT': idaKcvOmbRrkW1CtHhZfeAJQV4D = s6rxOhWUy0bXDdQMJleNmu+idaKcvOmbRrkW1CtHhZfeAJQV4D
	elif 'بحث M3U - ' in idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace('بحث M3U - ',s6rxOhWUy0bXDdQMJleNmu+'بحث M3U - '+s6rxOhWUy0bXDdQMJleNmu)
	elif ' M3U' in idaKcvOmbRrkW1CtHhZfeAJQV4D and wbWJX8PB4v3OM=='M3U': idaKcvOmbRrkW1CtHhZfeAJQV4D = s6rxOhWUy0bXDdQMJleNmu+idaKcvOmbRrkW1CtHhZfeAJQV4D
	elif 'بحث ' in idaKcvOmbRrkW1CtHhZfeAJQV4D and ' - ' in idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = s6rxOhWUy0bXDdQMJleNmu+idaKcvOmbRrkW1CtHhZfeAJQV4D
	elif not F2Zh6YQLU7naWe:
		zGceVQ18MmXfUASkbC0yvoLq5O = Zy2l0g8QU5vqefaTrsw.findall('^( *?)(.*?)( *?)$',idaKcvOmbRrkW1CtHhZfeAJQV4D)
		cYEW9A4xFl,AKhqFUDL3EjgYWvlxc,GH5WV8zeBobPnOZf1XIK6 = zGceVQ18MmXfUASkbC0yvoLq5O[ZVNvqy4iF1a9X]
		DscTzk0WtQBhXEMLvR = Zy2l0g8QU5vqefaTrsw.findall('^([!-~])',AKhqFUDL3EjgYWvlxc)
		if DscTzk0WtQBhXEMLvR: idaKcvOmbRrkW1CtHhZfeAJQV4D = cYEW9A4xFl+HCgURFmf8NvkYs2wnX+AKhqFUDL3EjgYWvlxc+GH5WV8zeBobPnOZf1XIK6
		else: idaKcvOmbRrkW1CtHhZfeAJQV4D = GH5WV8zeBobPnOZf1XIK6+s6rxOhWUy0bXDdQMJleNmu+AKhqFUDL3EjgYWvlxc+cYEW9A4xFl
	else:
		import bidi.algorithm as dz6mk9cAg0XbMFqJ28yZ
		if P2Fgh6TCOWoaHjkqBcQnvRNXe:
			pIqHE134kwe5QylU7COgrK = idaKcvOmbRrkW1CtHhZfeAJQV4D
			if BB7oCRfQNSYj5qDhTUevV: pIqHE134kwe5QylU7COgrK = pIqHE134kwe5QylU7COgrK.decode(Im5KSGZYBpRvdMVsbuXg,'ignore')
			wz9NZcDu0KVdT7A = dz6mk9cAg0XbMFqJ28yZ.get_display(pIqHE134kwe5QylU7COgrK,base_dir='L')
			MEQbr8wJUOiyjplZRX43HeKTaIz = pIqHE134kwe5QylU7COgrK.split(YvOQBzaTAscXR9ql)
			pU8eVZDkxlQoCLN = wz9NZcDu0KVdT7A.split(YvOQBzaTAscXR9ql)
			QAwaHgbEz4GZPoXCNDupY,kkOx2gjhqXJFvR48Ka71,gJntMZ96il2Y4kwueQ0r,SqJgFkIVl2YdNuG0f3 = [],[],CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
			Tyei1jcSPWlIwah = zip(MEQbr8wJUOiyjplZRX43HeKTaIz,pU8eVZDkxlQoCLN)
			for ZZSwoV3xWTz7dIMbFjGUCKclA5aP,mC1OTXaJLEoZe9h6FQIjV8Ygkp in Tyei1jcSPWlIwah:
				if ZZSwoV3xWTz7dIMbFjGUCKclA5aP==mC1OTXaJLEoZe9h6FQIjV8Ygkp==CJlTSEpZsWb0QHg5w and SqJgFkIVl2YdNuG0f3:
					gJntMZ96il2Y4kwueQ0r += YvOQBzaTAscXR9ql
					continue
				if ZZSwoV3xWTz7dIMbFjGUCKclA5aP==mC1OTXaJLEoZe9h6FQIjV8Ygkp:
					zsxHGU053Zlr4kNCdE = 'EN'
					if SqJgFkIVl2YdNuG0f3==zsxHGU053Zlr4kNCdE: gJntMZ96il2Y4kwueQ0r += YvOQBzaTAscXR9ql+ZZSwoV3xWTz7dIMbFjGUCKclA5aP
					elif ZZSwoV3xWTz7dIMbFjGUCKclA5aP:
						if gJntMZ96il2Y4kwueQ0r:
							kkOx2gjhqXJFvR48Ka71.append(gJntMZ96il2Y4kwueQ0r)
							QAwaHgbEz4GZPoXCNDupY.append(CJlTSEpZsWb0QHg5w)
						gJntMZ96il2Y4kwueQ0r = ZZSwoV3xWTz7dIMbFjGUCKclA5aP
				else:
					zsxHGU053Zlr4kNCdE = 'AR'
					if SqJgFkIVl2YdNuG0f3==zsxHGU053Zlr4kNCdE: gJntMZ96il2Y4kwueQ0r += YvOQBzaTAscXR9ql+ZZSwoV3xWTz7dIMbFjGUCKclA5aP
					elif ZZSwoV3xWTz7dIMbFjGUCKclA5aP:
						if gJntMZ96il2Y4kwueQ0r:
							QAwaHgbEz4GZPoXCNDupY.append(gJntMZ96il2Y4kwueQ0r)
							kkOx2gjhqXJFvR48Ka71.append(CJlTSEpZsWb0QHg5w)
						gJntMZ96il2Y4kwueQ0r = ZZSwoV3xWTz7dIMbFjGUCKclA5aP
				SqJgFkIVl2YdNuG0f3 = zsxHGU053Zlr4kNCdE
			if zsxHGU053Zlr4kNCdE=='EN':
				QAwaHgbEz4GZPoXCNDupY.append(gJntMZ96il2Y4kwueQ0r)
				kkOx2gjhqXJFvR48Ka71.append(CJlTSEpZsWb0QHg5w)
			else:
				kkOx2gjhqXJFvR48Ka71.append(gJntMZ96il2Y4kwueQ0r)
				QAwaHgbEz4GZPoXCNDupY.append(CJlTSEpZsWb0QHg5w)
			Anp8miuq1wWgN3QCoBVysrY2 = CJlTSEpZsWb0QHg5w
			Tyei1jcSPWlIwah = zip(QAwaHgbEz4GZPoXCNDupY,kkOx2gjhqXJFvR48Ka71)
			import bidi.mirror as FIVCw2daS9m1Eg3xBMQ5
			for dLoQiVGN8M0YukUnBw9l,K2vz86kxVZTH in Tyei1jcSPWlIwah:
				if dLoQiVGN8M0YukUnBw9l: Anp8miuq1wWgN3QCoBVysrY2 += YvOQBzaTAscXR9ql+dLoQiVGN8M0YukUnBw9l
				else:
					DscTzk0WtQBhXEMLvR = Zy2l0g8QU5vqefaTrsw.findall('([!-~]) *$',K2vz86kxVZTH)
					if DscTzk0WtQBhXEMLvR:
						DscTzk0WtQBhXEMLvR = DscTzk0WtQBhXEMLvR[ZVNvqy4iF1a9X]
						try:
							bKEGLogQUjdknVN = FIVCw2daS9m1Eg3xBMQ5.MIRRORED[DscTzk0WtQBhXEMLvR]
							zGceVQ18MmXfUASkbC0yvoLq5O = Zy2l0g8QU5vqefaTrsw.findall('^( *?)(.*?)( *?)$',K2vz86kxVZTH)
							if zGceVQ18MmXfUASkbC0yvoLq5O: cYEW9A4xFl,K2vz86kxVZTH,GH5WV8zeBobPnOZf1XIK6 = zGceVQ18MmXfUASkbC0yvoLq5O[ZVNvqy4iF1a9X]
							K2vz86kxVZTH = cYEW9A4xFl+bKEGLogQUjdknVN+K2vz86kxVZTH[:-P2Fgh6TCOWoaHjkqBcQnvRNXe]+GH5WV8zeBobPnOZf1XIK6
						except: pass
					Anp8miuq1wWgN3QCoBVysrY2 += YvOQBzaTAscXR9ql+K2vz86kxVZTH
			idaKcvOmbRrkW1CtHhZfeAJQV4D = Anp8miuq1wWgN3QCoBVysrY2[P2Fgh6TCOWoaHjkqBcQnvRNXe:]
			if BB7oCRfQNSYj5qDhTUevV: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.encode(Im5KSGZYBpRvdMVsbuXg)
		else:
			if BB7oCRfQNSYj5qDhTUevV: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.decode(Im5KSGZYBpRvdMVsbuXg)
			idaKcvOmbRrkW1CtHhZfeAJQV4D = dz6mk9cAg0XbMFqJ28yZ.get_display(idaKcvOmbRrkW1CtHhZfeAJQV4D)
			pIqHE134kwe5QylU7COgrK,wz9NZcDu0KVdT7A = idaKcvOmbRrkW1CtHhZfeAJQV4D,idaKcvOmbRrkW1CtHhZfeAJQV4D
			if 1:
				SqJgFkIVl2YdNuG0f3,QF9AMD3fe0d6tqjBJ41LwIaC2xK = CJlTSEpZsWb0QHg5w,[]
				MhFmeW6wtgHk = idaKcvOmbRrkW1CtHhZfeAJQV4D.split(YvOQBzaTAscXR9ql)
				for Vx2fXgAHebr68tDaId1QUMvzTc in MhFmeW6wtgHk:
					if not Vx2fXgAHebr68tDaId1QUMvzTc:
						if QF9AMD3fe0d6tqjBJ41LwIaC2xK: QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe] += YvOQBzaTAscXR9ql
						else: QF9AMD3fe0d6tqjBJ41LwIaC2xK.append(CJlTSEpZsWb0QHg5w)
						continue
					ZJcdm7tOp91nHV5EhsuQKG04iXN = Zy2l0g8QU5vqefaTrsw.findall('[!-~]',Vx2fXgAHebr68tDaId1QUMvzTc[ZVNvqy4iF1a9X])
					if ZJcdm7tOp91nHV5EhsuQKG04iXN==SqJgFkIVl2YdNuG0f3 and QF9AMD3fe0d6tqjBJ41LwIaC2xK: QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe] += YvOQBzaTAscXR9ql+Vx2fXgAHebr68tDaId1QUMvzTc
					else:
						if QF9AMD3fe0d6tqjBJ41LwIaC2xK:
							w0DdkYe4bWBA32QPjCs7m = Zy2l0g8QU5vqefaTrsw.findall('[^!-~]',QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe])
							if w0DdkYe4bWBA32QPjCs7m:
								QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe] = dz6mk9cAg0XbMFqJ28yZ.get_display(QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe])
								Q06nueLd3Vt7vJXH9 = Zy2l0g8QU5vqefaTrsw.findall('^ +',QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe])
								if Q06nueLd3Vt7vJXH9: QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe] = QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe].lstrip(YvOQBzaTAscXR9ql)+Q06nueLd3Vt7vJXH9[ZVNvqy4iF1a9X]
						QF9AMD3fe0d6tqjBJ41LwIaC2xK.append(Vx2fXgAHebr68tDaId1QUMvzTc)
					SqJgFkIVl2YdNuG0f3 = ZJcdm7tOp91nHV5EhsuQKG04iXN
				if QF9AMD3fe0d6tqjBJ41LwIaC2xK: QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe] = dz6mk9cAg0XbMFqJ28yZ.get_display(QF9AMD3fe0d6tqjBJ41LwIaC2xK[-P2Fgh6TCOWoaHjkqBcQnvRNXe])
				idaKcvOmbRrkW1CtHhZfeAJQV4D = YvOQBzaTAscXR9ql.join(QF9AMD3fe0d6tqjBJ41LwIaC2xK)
			if BB7oCRfQNSYj5qDhTUevV: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.encode(Im5KSGZYBpRvdMVsbuXg)
	return idaKcvOmbRrkW1CtHhZfeAJQV4D
def iQdPpwFnKG9IMWJmoO1U(izPAxfYFVy1m,Mw2LKPnouJT4s,BIoQkMtPRCNDJZlY9FuOH):
	nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,OdP1rwxvByjs5mF7VZeUCYgDG,vzt1qFLpWC,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = izPAxfYFVy1m
	BEUVvSQtRimC = int(BEUVvSQtRimC)
	UUXOlvtFjpd = Zy2l0g8QU5vqefaTrsw.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if UUXOlvtFjpd:
		UUXOlvtFjpd,YYrOMXAnUFKT1GNex5HwL,br8xYNRu4yqHQ = UUXOlvtFjpd[ZVNvqy4iF1a9X]
		idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(UUXOlvtFjpd,CJlTSEpZsWb0QHg5w)
	XH8JSWK3Amga = idaKcvOmbRrkW1CtHhZfeAJQV4D
	wbWJX8PB4v3OM = Zy2l0g8QU5vqefaTrsw.findall('^_(\w\w\w)_(.*?)$',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if wbWJX8PB4v3OM:
		wbWJX8PB4v3OM,idaKcvOmbRrkW1CtHhZfeAJQV4D = wbWJX8PB4v3OM[ZVNvqy4iF1a9X]
		I2ZROjfuB0kvqK3T7 = '_MOD_' in idaKcvOmbRrkW1CtHhZfeAJQV4D
		XDsN23oyrzZEGSihUa0W = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder'
		if I2ZROjfuB0kvqK3T7 and XDsN23oyrzZEGSihUa0W: QR34JVGupS1tv = ';'
		elif I2ZROjfuB0kvqK3T7 and not XDsN23oyrzZEGSihUa0W: QR34JVGupS1tv = jWsfaIrEp2PiO0q9ygBvn4L
		elif not I2ZROjfuB0kvqK3T7 and XDsN23oyrzZEGSihUa0W: QR34JVGupS1tv = ','
		elif not I2ZROjfuB0kvqK3T7 and not XDsN23oyrzZEGSihUa0W: QR34JVGupS1tv = YvOQBzaTAscXR9ql
		idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace('_MOD_',CJlTSEpZsWb0QHg5w)
		wbWJX8PB4v3OM = QR34JVGupS1tv+Dj62UpP5MrbTkJqhRa+wbWJX8PB4v3OM+' '+oOQaRxBXyJ5jVnZ
	else: wbWJX8PB4v3OM = CJlTSEpZsWb0QHg5w
	if UUXOlvtFjpd:
		if BB7oCRfQNSYj5qDhTUevV:
			UUXOlvtFjpd = Ym6q5M4TocDaA013RjFQ+YYrOMXAnUFKT1GNex5HwL+YvOQBzaTAscXR9ql+br8xYNRu4yqHQ+oOQaRxBXyJ5jVnZ
			if wbWJX8PB4v3OM: idaKcvOmbRrkW1CtHhZfeAJQV4D = UUXOlvtFjpd+YvOQBzaTAscXR9ql+s6rxOhWUy0bXDdQMJleNmu+wbWJX8PB4v3OM+idaKcvOmbRrkW1CtHhZfeAJQV4D
			else: idaKcvOmbRrkW1CtHhZfeAJQV4D = UUXOlvtFjpd+s6rxOhWUy0bXDdQMJleNmu+idaKcvOmbRrkW1CtHhZfeAJQV4D+YvOQBzaTAscXR9ql
		elif A7Z6OVh20eCEUx:
			if wbWJX8PB4v3OM:
				UUXOlvtFjpd = Ym6q5M4TocDaA013RjFQ+YYrOMXAnUFKT1GNex5HwL+YvOQBzaTAscXR9ql+br8xYNRu4yqHQ+oOQaRxBXyJ5jVnZ
				idaKcvOmbRrkW1CtHhZfeAJQV4D = UUXOlvtFjpd+YvOQBzaTAscXR9ql+wbWJX8PB4v3OM+idaKcvOmbRrkW1CtHhZfeAJQV4D
			else:
				UUXOlvtFjpd = Ym6q5M4TocDaA013RjFQ+br8xYNRu4yqHQ+YvOQBzaTAscXR9ql+YYrOMXAnUFKT1GNex5HwL+oOQaRxBXyJ5jVnZ
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D+YvOQBzaTAscXR9ql+s6rxOhWUy0bXDdQMJleNmu+UUXOlvtFjpd
	elif wbWJX8PB4v3OM:
		idaKcvOmbRrkW1CtHhZfeAJQV4D = I9UcFRy0AV51HZ3nTXW2eJmBMbigdP(idaKcvOmbRrkW1CtHhZfeAJQV4D,wbWJX8PB4v3OM)
		idaKcvOmbRrkW1CtHhZfeAJQV4D = wbWJX8PB4v3OM+idaKcvOmbRrkW1CtHhZfeAJQV4D
	izPAxfYFVy1m = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,XH8JSWK3Amga,pkNZlmhUSwtXgriJHjT59MV1QqK,str(BEUVvSQtRimC),ayeFgd1rBXvlfuKPYEihU82,OdP1rwxvByjs5mF7VZeUCYgDG,vzt1qFLpWC,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO
	IXN8x3Olit = {'type':CJlTSEpZsWb0QHg5w,'mode':CJlTSEpZsWb0QHg5w,'url':CJlTSEpZsWb0QHg5w,'text':CJlTSEpZsWb0QHg5w,'page':CJlTSEpZsWb0QHg5w,'name':CJlTSEpZsWb0QHg5w,'image':CJlTSEpZsWb0QHg5w,'context':CJlTSEpZsWb0QHg5w,'infodict':CJlTSEpZsWb0QHg5w}
	if A7Z6OVh20eCEUx: XH8JSWK3Amga = XH8JSWK3Amga.encode(Im5KSGZYBpRvdMVsbuXg,'ignore').decode(Im5KSGZYBpRvdMVsbuXg)
	IXN8x3Olit['name'] = O4Ak3NXpyUHvE(XH8JSWK3Amga)
	IXN8x3Olit['type'] = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ.strip(YvOQBzaTAscXR9ql)
	IXN8x3Olit['mode'] = str(BEUVvSQtRimC).strip(YvOQBzaTAscXR9ql)
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder' and OdP1rwxvByjs5mF7VZeUCYgDG: IXN8x3Olit['page'] = O4Ak3NXpyUHvE(OdP1rwxvByjs5mF7VZeUCYgDG.strip(YvOQBzaTAscXR9ql))
	if AC0yWDME4VSh8rkFXwpGeol6st: IXN8x3Olit['context'] = AC0yWDME4VSh8rkFXwpGeol6st.strip(YvOQBzaTAscXR9ql)
	if vzt1qFLpWC: IXN8x3Olit['text'] = O4Ak3NXpyUHvE(vzt1qFLpWC.strip(YvOQBzaTAscXR9ql))
	if ayeFgd1rBXvlfuKPYEihU82: IXN8x3Olit['image'] = O4Ak3NXpyUHvE(ayeFgd1rBXvlfuKPYEihU82.strip(YvOQBzaTAscXR9ql))
	if sQ3kPfLmHe6W5xUAiY0EKj18GrXnO:
		sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = str(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO)
		IXN8x3Olit['infodict'] = O4Ak3NXpyUHvE(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO.strip(YvOQBzaTAscXR9ql))
		sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = eval(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO)
	else: sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = {}
	if pkNZlmhUSwtXgriJHjT59MV1QqK: IXN8x3Olit['url'] = O4Ak3NXpyUHvE(pkNZlmhUSwtXgriJHjT59MV1QqK.strip(YvOQBzaTAscXR9ql))
	YRHCPUrfiAhj2QwNKaXelFWg = {'name':CJlTSEpZsWb0QHg5w,'context_menu':CJlTSEpZsWb0QHg5w,'plot':CJlTSEpZsWb0QHg5w,'stars':CJlTSEpZsWb0QHg5w,'image':CJlTSEpZsWb0QHg5w,'type':CJlTSEpZsWb0QHg5w,'isFolder':CJlTSEpZsWb0QHg5w,'newpath':CJlTSEpZsWb0QHg5w,'duration':CJlTSEpZsWb0QHg5w}
	JvSuHnyaFgo51Ylf07634hQjXwTIsA = []
	GzMJS98cAfLaN2EHxV = 'plugin://'+R7xafKV3ekjDc+'/?type='+IXN8x3Olit['type']+'&mode='+IXN8x3Olit['mode']
	if IXN8x3Olit['page']: GzMJS98cAfLaN2EHxV += '&page='+IXN8x3Olit['page']
	if IXN8x3Olit['name']: GzMJS98cAfLaN2EHxV += '&name='+IXN8x3Olit['name']
	if IXN8x3Olit['text']: GzMJS98cAfLaN2EHxV += '&text='+IXN8x3Olit['text']
	if IXN8x3Olit['infodict']: GzMJS98cAfLaN2EHxV += '&infodict='+IXN8x3Olit['infodict']
	if IXN8x3Olit['image']: GzMJS98cAfLaN2EHxV += '&image='+IXN8x3Olit['image']
	if IXN8x3Olit['url']: GzMJS98cAfLaN2EHxV += '&url='+IXN8x3Olit['url']
	if BEUVvSQtRimC not in [265,533]: YRHCPUrfiAhj2QwNKaXelFWg['favorites'] = w2qb6lf5EM
	else: YRHCPUrfiAhj2QwNKaXelFWg['favorites'] = VJZIMkUN5siqB21Pf
	if IXN8x3Olit['context']: GzMJS98cAfLaN2EHxV += '&context='+IXN8x3Olit['context']
	if BEUVvSQtRimC in [235,238] and nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='live' and 'EPG' in AC0yWDME4VSh8rkFXwpGeol6st:
		qZtD7faygAzk9ir40wmBl3XoLK = 'plugin://'+R7xafKV3ekjDc+'?mode=238&text=SHORT_EPG&url='+pkNZlmhUSwtXgriJHjT59MV1QqK
		vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'البرامج القادمة'+oOQaRxBXyJ5jVnZ
		dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
		JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if BEUVvSQtRimC==265:
		nOudwaDECF = Mw2LKPnouJT4s(vzt1qFLpWC,w2qb6lf5EM)
		if nOudwaDECF>ZVNvqy4iF1a9X:
			qZtD7faygAzk9ir40wmBl3XoLK = 'plugin://'+R7xafKV3ekjDc+'?mode=266&text='+vzt1qFLpWC
			vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'مسح قائمة آخر 50 '+HRYMpjUhOiul4zdP7G8c(vzt1qFLpWC)+oOQaRxBXyJ5jVnZ
			dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
			JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video' and BEUVvSQtRimC!=331:
		qZtD7faygAzk9ir40wmBl3XoLK = GzMJS98cAfLaN2EHxV+'&context=6_DOWNLOAD'
		vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'تحميل ملف الفيديو'+oOQaRxBXyJ5jVnZ
		dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
		JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if BEUVvSQtRimC==331:
		qZtD7faygAzk9ir40wmBl3XoLK = GzMJS98cAfLaN2EHxV+'&context=6_DELETE'
		vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'حذف ملف الفيديو'+oOQaRxBXyJ5jVnZ
		dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
		JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder' and BEUVvSQtRimC==540:
		QQM6hI8W2iHskmoltPeKjZ54bwq = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_SPLITTED_ALL')
		if QQM6hI8W2iHskmoltPeKjZ54bwq:
			qZtD7faygAzk9ir40wmBl3XoLK = 'plugin://'+R7xafKV3ekjDc+'?context=7'
			vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'مسح كلمات بحث المواقع'+oOQaRxBXyJ5jVnZ
			dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
			JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder' and BEUVvSQtRimC==1010:
		QQM6hI8W2iHskmoltPeKjZ54bwq = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if QQM6hI8W2iHskmoltPeKjZ54bwq:
			qZtD7faygAzk9ir40wmBl3XoLK = 'plugin://'+R7xafKV3ekjDc+'?context=10'
			vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'مسح كلمات بحث جوجل'+oOQaRxBXyJ5jVnZ
			dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
			JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	PdUAIZGsKMSnw7p2uYTJki = [9990,9999,VTadWjBloMwXO2CH9GDK6FR,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,536,537,538,540,710,719,761,762,1010,1022,1101,1103]
	if BEUVvSQtRimC not in PdUAIZGsKMSnw7p2uYTJki:
		qZtD7faygAzk9ir40wmBl3XoLK = 'plugin://'+R7xafKV3ekjDc+'?context=8&mode=260'
		vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'القائمة الرئيسية'+oOQaRxBXyJ5jVnZ
		dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
		JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	q5uUwoAYNzyTgHR = BEUVvSQtRimC-BEUVvSQtRimC%10
	if BEUVvSQtRimC%10:
		if q5uUwoAYNzyTgHR==280: q5uUwoAYNzyTgHR = 230
		if q5uUwoAYNzyTgHR==410: q5uUwoAYNzyTgHR = 400
		if q5uUwoAYNzyTgHR==520: q5uUwoAYNzyTgHR = 510
		if q5uUwoAYNzyTgHR not in fgbJtiE6ZhV5clxdOj1usX:
			qZtD7faygAzk9ir40wmBl3XoLK = 'plugin://'+R7xafKV3ekjDc+'?context=8&mode='+str(q5uUwoAYNzyTgHR)
			vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'قائمة الموقع'+oOQaRxBXyJ5jVnZ
			dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
			JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	qZtD7faygAzk9ir40wmBl3XoLK = GzMJS98cAfLaN2EHxV+'&context=9'
	vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'تحديث القائمة'+oOQaRxBXyJ5jVnZ
	dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
	JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ in ['video','live']:
		qZtD7faygAzk9ir40wmBl3XoLK = GzMJS98cAfLaN2EHxV+'&context=18'
		vLABmYtTFQqPJ1 = Ym6q5M4TocDaA013RjFQ+'إظهار قوائم الجودة'+oOQaRxBXyJ5jVnZ
		dXFbvGJLEsM = (vLABmYtTFQqPJ1,'RunPlugin('+qZtD7faygAzk9ir40wmBl3XoLK+')')
		JvSuHnyaFgo51Ylf07634hQjXwTIsA.append(dXFbvGJLEsM)
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ in ['link','video','live']: DsJaYtPVeIhRmSj5uiN1GTfAnw9g = VJZIMkUN5siqB21Pf
	elif nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='folder': DsJaYtPVeIhRmSj5uiN1GTfAnw9g = w2qb6lf5EM
	YRHCPUrfiAhj2QwNKaXelFWg['name'] = idaKcvOmbRrkW1CtHhZfeAJQV4D
	YRHCPUrfiAhj2QwNKaXelFWg['context_menu'] = JvSuHnyaFgo51Ylf07634hQjXwTIsA
	if 'plot' in list(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO.keys()): YRHCPUrfiAhj2QwNKaXelFWg['plot'] = sQ3kPfLmHe6W5xUAiY0EKj18GrXnO['plot']
	if 'stars' in list(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO.keys()): YRHCPUrfiAhj2QwNKaXelFWg['stars'] = sQ3kPfLmHe6W5xUAiY0EKj18GrXnO['stars']
	if ayeFgd1rBXvlfuKPYEihU82: YRHCPUrfiAhj2QwNKaXelFWg['image'] = ayeFgd1rBXvlfuKPYEihU82
	if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video' and OdP1rwxvByjs5mF7VZeUCYgDG:
		jQ3ILDlYFsmcqTKGpvy80aMkP7 = Zy2l0g8QU5vqefaTrsw.findall('[\d:]+',OdP1rwxvByjs5mF7VZeUCYgDG,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if jQ3ILDlYFsmcqTKGpvy80aMkP7:
			jQ3ILDlYFsmcqTKGpvy80aMkP7 = '0:0:0:0:0:'+jQ3ILDlYFsmcqTKGpvy80aMkP7[ZVNvqy4iF1a9X]
			z7PfyvHhJWqs8Fl,HNaDsrhnbAdWoQGRJ6YTSp08ugZPt,e0XGjtJSKQCicHBqRx,WjGRmOx9LvkpdXBF,d6sqnQWjwgI = jQ3ILDlYFsmcqTKGpvy80aMkP7.rsplit(':',P3cpaLN2sH)
			CIPb3oUF7T1BjLnNM2lWKtia6 = int(HNaDsrhnbAdWoQGRJ6YTSp08ugZPt)*24*co23tYRNHwpa+int(e0XGjtJSKQCicHBqRx)*co23tYRNHwpa+int(WjGRmOx9LvkpdXBF)*60+int(d6sqnQWjwgI)
			YRHCPUrfiAhj2QwNKaXelFWg['duration'] = CIPb3oUF7T1BjLnNM2lWKtia6
	YRHCPUrfiAhj2QwNKaXelFWg['type'] = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ
	YRHCPUrfiAhj2QwNKaXelFWg['isFolder'] = DsJaYtPVeIhRmSj5uiN1GTfAnw9g
	YRHCPUrfiAhj2QwNKaXelFWg['newpath'] = GzMJS98cAfLaN2EHxV
	YRHCPUrfiAhj2QwNKaXelFWg['menuItem'] = izPAxfYFVy1m
	YRHCPUrfiAhj2QwNKaXelFWg['mode'] = BEUVvSQtRimC
	return YRHCPUrfiAhj2QwNKaXelFWg
def ppOqeuYQgUxftWB30FvMDC(Mw2LKPnouJT4s):
	HgWtqkEBIyTxKo,K2miyG8hBnz7A3rbZ5DWJsVNapev9g = [],CJlTSEpZsWb0QHg5w
	from z2BQ0dUKrP import C2Ula90Z1dj3NhDMKR7YH8,wkEAKGHojXLfWJU3dvy7QCV4T
	BIoQkMtPRCNDJZlY9FuOH = C2Ula90Z1dj3NhDMKR7YH8()
	QgwJd8Sfs07zyqlmiKWRrCP9Dn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.status.refresh')
	if zz4EDG1PtiyX3JVUlBeC and (not QgwJd8Sfs07zyqlmiKWRrCP9Dn or QgwJd8Sfs07zyqlmiKWRrCP9Dn=='REFRESH_CACHE'): QgwJd8Sfs07zyqlmiKWRrCP9Dn = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'str','FOLDERS_SORT',zz4EDG1PtiyX3JVUlBeC)
	if QgwJd8Sfs07zyqlmiKWRrCP9Dn:
		if   '_PERM' in QgwJd8Sfs07zyqlmiKWRrCP9Dn: K2miyG8hBnz7A3rbZ5DWJsVNapev9g = 'دائمي'
		elif '_TEMP' in QgwJd8Sfs07zyqlmiKWRrCP9Dn: K2miyG8hBnz7A3rbZ5DWJsVNapev9g = 'مؤقت'
		if   '_REVERSED_' in QgwJd8Sfs07zyqlmiKWRrCP9Dn: TV1Zu8bOAfle5vWSpht2nQ = 'عكسي' ; Ew2zQ8u7Ss.menuItemsLIST[:] = reversed(Ew2zQ8u7Ss.menuItemsLIST)
		elif '_ASCENDED_' in QgwJd8Sfs07zyqlmiKWRrCP9Dn: TV1Zu8bOAfle5vWSpht2nQ = 'تصاعدي' ; Ew2zQ8u7Ss.menuItemsLIST[:] = sorted(Ew2zQ8u7Ss.menuItemsLIST,reverse=VJZIMkUN5siqB21Pf,key=lambda key:key[P2Fgh6TCOWoaHjkqBcQnvRNXe])
		elif '_DESCENDED_' in QgwJd8Sfs07zyqlmiKWRrCP9Dn: TV1Zu8bOAfle5vWSpht2nQ = 'تنازلي' ; Ew2zQ8u7Ss.menuItemsLIST[:] = sorted(Ew2zQ8u7Ss.menuItemsLIST,reverse=w2qb6lf5EM,key=lambda key:key[P2Fgh6TCOWoaHjkqBcQnvRNXe])
		elif '_RANDOMIZED_' in QgwJd8Sfs07zyqlmiKWRrCP9Dn: TV1Zu8bOAfle5vWSpht2nQ = 'عشوائي' ; D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.shuffle(Ew2zQ8u7Ss.menuItemsLIST)
	name = 'ترتيب '+TV1Zu8bOAfle5vWSpht2nQ+YvOQBzaTAscXR9ql+K2miyG8hBnz7A3rbZ5DWJsVNapev9g if K2miyG8hBnz7A3rbZ5DWJsVNapev9g else 'بدون ترتيب (أصلي)'
	name = Ym6q5M4TocDaA013RjFQ+name+oOQaRxBXyJ5jVnZ
	if QgwJd8Sfs07zyqlmiKWRrCP9Dn in d4kl1qU6GQT9tmfeNZMXvYJwDbr8: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.status.refresh',CJlTSEpZsWb0QHg5w)
	kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
	BEUVvSQtRimC = int(n3dz9vetbZKIVYm78)
	q5uUwoAYNzyTgHR = BEUVvSQtRimC-BEUVvSQtRimC%10
	if BEUVvSQtRimC%10 and q5uUwoAYNzyTgHR not in fgbJtiE6ZhV5clxdOj1usX and len(Ew2zQ8u7Ss.menuItemsLIST)>1:
		Ew2zQ8u7Ss.menuItemsLIST[:] = [('link',name,'',533,'','',zz4EDG1PtiyX3JVUlBeC,'','')]+Ew2zQ8u7Ss.menuItemsLIST
	for izPAxfYFVy1m in Ew2zQ8u7Ss.menuItemsLIST:
		YRHCPUrfiAhj2QwNKaXelFWg = iQdPpwFnKG9IMWJmoO1U(izPAxfYFVy1m,Mw2LKPnouJT4s,BIoQkMtPRCNDJZlY9FuOH)
		if YRHCPUrfiAhj2QwNKaXelFWg['favorites']:
			Sbo5yeLu3jxAp = wkEAKGHojXLfWJU3dvy7QCV4T(BIoQkMtPRCNDJZlY9FuOH,YRHCPUrfiAhj2QwNKaXelFWg['menuItem'],YRHCPUrfiAhj2QwNKaXelFWg['newpath'])
			YRHCPUrfiAhj2QwNKaXelFWg['context_menu'] = Sbo5yeLu3jxAp+YRHCPUrfiAhj2QwNKaXelFWg['context_menu']
		HgWtqkEBIyTxKo.append(YRHCPUrfiAhj2QwNKaXelFWg)
	zxWyYlkBm8q6GL = VJZIMkUN5siqB21Pf if '_TEMP' in QgwJd8Sfs07zyqlmiKWRrCP9Dn else w2qb6lf5EM
	return HgWtqkEBIyTxKo,zxWyYlkBm8q6GL
def QXmHF2aIleTuYq0tCfZb6DUPjNpg5(ww2nEWifbsVO4rMkHAgevcRP):
	QR34JVGupS1tv,x0ch5q6d7RpHVjSuZ1m4fbaUyrX, = [],CJlTSEpZsWb0QHg5w
	for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
		if not LowSfEj9cH: QR34JVGupS1tv.append(CJlTSEpZsWb0QHg5w)
		else: break
	ww2nEWifbsVO4rMkHAgevcRP = ww2nEWifbsVO4rMkHAgevcRP[len(QR34JVGupS1tv):]
	FMxeyLvnzabpJhCXgS6T = '\n\n\n\n'.join(ww2nEWifbsVO4rMkHAgevcRP)
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('===== ===== =====','000001')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(Dj62UpP5MrbTkJqhRa,'000002')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(Ym6q5M4TocDaA013RjFQ,'000003')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(oOQaRxBXyJ5jVnZ,'000004')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[RIGHT]','000005')
	bqfWp3z1MOoYy87AKRxH6k = 100000
	nFvX4ej8Hs2OfImtRzc = {}
	F8F3zgOBC5s0UvWXbQedwcEAofDum = Zy2l0g8QU5vqefaTrsw.findall('http.*?[\r\n ]',FMxeyLvnzabpJhCXgS6T,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for YfnRLBxzM2TSd8uOjbemZEo in F8F3zgOBC5s0UvWXbQedwcEAofDum:
		bqfWp3z1MOoYy87AKRxH6k += P2Fgh6TCOWoaHjkqBcQnvRNXe
		FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(YfnRLBxzM2TSd8uOjbemZEo,str(bqfWp3z1MOoYy87AKRxH6k))
		nFvX4ej8Hs2OfImtRzc[str(bqfWp3z1MOoYy87AKRxH6k)] = YfnRLBxzM2TSd8uOjbemZEo
	for X0Rq3ISdwTJsnWGM7Kmc4 in range(ZVNvqy4iF1a9X,len(FMxeyLvnzabpJhCXgS6T),4800):
		rrQlLRoNgStwmBiu1fb9TCdxe = FMxeyLvnzabpJhCXgS6T[X0Rq3ISdwTJsnWGM7Kmc4:X0Rq3ISdwTJsnWGM7Kmc4+4800]
		vYfNCsUkSVbI894lPxc = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.code')
		pkNZlmhUSwtXgriJHjT59MV1QqK = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+vYfNCsUkSVbI894lPxc
		G9olD6cNbsdS = {'Content-Type':'text/plain'}
		xDumKC4LTehPjr7UXfAVB5Zazv = rrQlLRoNgStwmBiu1fb9TCdxe.encode(Im5KSGZYBpRvdMVsbuXg)
		C0q5dOLGD8 = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'POST',pkNZlmhUSwtXgriJHjT59MV1QqK,xDumKC4LTehPjr7UXfAVB5Zazv,G9olD6cNbsdS,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if C0q5dOLGD8.succeeded:
			fLgxFao7GCIMqj8iw5ucXd4Ov = C0q5dOLGD8.content
			mt9DVeBRvoirZGysnFdMhN61 = oE7iT3HI5VDdmY4kPOjr('str',fLgxFao7GCIMqj8iw5ucXd4Ov)
			if mt9DVeBRvoirZGysnFdMhN61:
				mt9DVeBRvoirZGysnFdMhN61 = mt9DVeBRvoirZGysnFdMhN61['translation']
				mt9DVeBRvoirZGysnFdMhN61 = pd0Na8D5WZfHYkysVS(mt9DVeBRvoirZGysnFdMhN61)
				for ziNeUR6gHltVW in range(len(mt9DVeBRvoirZGysnFdMhN61)):
					x0ch5q6d7RpHVjSuZ1m4fbaUyrX += mt9DVeBRvoirZGysnFdMhN61[ziNeUR6gHltVW][ZVNvqy4iF1a9X]
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000001','===== ===== =====')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000002',Dj62UpP5MrbTkJqhRa)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000003',Ym6q5M4TocDaA013RjFQ)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000004',oOQaRxBXyJ5jVnZ)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000005','[RIGHT]')
	for bqfWp3z1MOoYy87AKRxH6k in list(nFvX4ej8Hs2OfImtRzc.keys()):
		YfnRLBxzM2TSd8uOjbemZEo = nFvX4ej8Hs2OfImtRzc[bqfWp3z1MOoYy87AKRxH6k]
		x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace(bqfWp3z1MOoYy87AKRxH6k,YfnRLBxzM2TSd8uOjbemZEo)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.split('\n\n\n\n')
	return QR34JVGupS1tv+x0ch5q6d7RpHVjSuZ1m4fbaUyrX
def qnCH0uVrGfl9a(ww2nEWifbsVO4rMkHAgevcRP):
	QR34JVGupS1tv,x0ch5q6d7RpHVjSuZ1m4fbaUyrX, = [],CJlTSEpZsWb0QHg5w
	for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
		if not LowSfEj9cH: QR34JVGupS1tv.append(CJlTSEpZsWb0QHg5w)
		else: break
	ww2nEWifbsVO4rMkHAgevcRP = ww2nEWifbsVO4rMkHAgevcRP[len(QR34JVGupS1tv):]
	FMxeyLvnzabpJhCXgS6T = '\\n\\n\\n\\n'.join(ww2nEWifbsVO4rMkHAgevcRP)
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('كلا','no')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('استمرار','continue')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('===== ===== =====','000001')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(Dj62UpP5MrbTkJqhRa,'000002')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(Ym6q5M4TocDaA013RjFQ,'000003')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(oOQaRxBXyJ5jVnZ,'000004')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[RIGHT]','000005')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[CENTER]','000006')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[RTL]','000007')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace("'","\\\\\\'")
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('"','\\\\\\"')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(rJ9cgWz4FU,'\\n')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(rScptJWVdgzQGR1E3LZ9byC,'\\\\r')
	for X0Rq3ISdwTJsnWGM7Kmc4 in range(ZVNvqy4iF1a9X,len(FMxeyLvnzabpJhCXgS6T),4800):
		rrQlLRoNgStwmBiu1fb9TCdxe = FMxeyLvnzabpJhCXgS6T[X0Rq3ISdwTJsnWGM7Kmc4:X0Rq3ISdwTJsnWGM7Kmc4+4800]
		pkNZlmhUSwtXgriJHjT59MV1QqK = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		G9olD6cNbsdS = {'Content-Type':'application/x-www-form-urlencoded'}
		vYfNCsUkSVbI894lPxc = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.code')
		xDumKC4LTehPjr7UXfAVB5Zazv = 'f.req='+O4Ak3NXpyUHvE('[[["MkEWBc","[[\\"'+rrQlLRoNgStwmBiu1fb9TCdxe+'\\",\\"ar\\",\\"'+vYfNCsUkSVbI894lPxc+'\\",1],[]]",null,"generic"]]]',CJlTSEpZsWb0QHg5w)
		xDumKC4LTehPjr7UXfAVB5Zazv = xDumKC4LTehPjr7UXfAVB5Zazv.replace('%5Cn','%5C%5Cn')
		C0q5dOLGD8 = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'POST',pkNZlmhUSwtXgriJHjT59MV1QqK,xDumKC4LTehPjr7UXfAVB5Zazv,G9olD6cNbsdS,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if C0q5dOLGD8.succeeded:
			fLgxFao7GCIMqj8iw5ucXd4Ov = C0q5dOLGD8.content
			fLgxFao7GCIMqj8iw5ucXd4Ov = fLgxFao7GCIMqj8iw5ucXd4Ov.split(rJ9cgWz4FU)[-P2Fgh6TCOWoaHjkqBcQnvRNXe]
			mt9DVeBRvoirZGysnFdMhN61 = oE7iT3HI5VDdmY4kPOjr('str',fLgxFao7GCIMqj8iw5ucXd4Ov)[ZVNvqy4iF1a9X][VTadWjBloMwXO2CH9GDK6FR]
			if mt9DVeBRvoirZGysnFdMhN61:
				mt9DVeBRvoirZGysnFdMhN61 = oE7iT3HI5VDdmY4kPOjr('str',mt9DVeBRvoirZGysnFdMhN61)[P2Fgh6TCOWoaHjkqBcQnvRNXe][ZVNvqy4iF1a9X][ZVNvqy4iF1a9X][GGsP9SDod4iUBm6kNMfLw]
				mt9DVeBRvoirZGysnFdMhN61 = pd0Na8D5WZfHYkysVS(mt9DVeBRvoirZGysnFdMhN61)
				for ziNeUR6gHltVW in range(len(mt9DVeBRvoirZGysnFdMhN61)):
					x0ch5q6d7RpHVjSuZ1m4fbaUyrX += mt9DVeBRvoirZGysnFdMhN61[ziNeUR6gHltVW][ZVNvqy4iF1a9X]
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('00000','0000').replace('0000','000')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0001','===== ===== =====')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0002',Dj62UpP5MrbTkJqhRa)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0003',Ym6q5M4TocDaA013RjFQ)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0004',oOQaRxBXyJ5jVnZ)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0005','[RIGHT]')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0006','[CENTER]')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0007','[RTL]')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.split('\n\n\n\n')
	return QR34JVGupS1tv+x0ch5q6d7RpHVjSuZ1m4fbaUyrX
def P3LVsCA6cSbw5driFN4vElB(ww2nEWifbsVO4rMkHAgevcRP):
	QR34JVGupS1tv,dJE7zucgHNtp = [],[]
	for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
		if not LowSfEj9cH: QR34JVGupS1tv.append(CJlTSEpZsWb0QHg5w)
		else: break
	ww2nEWifbsVO4rMkHAgevcRP = ww2nEWifbsVO4rMkHAgevcRP[len(QR34JVGupS1tv):]
	FMxeyLvnzabpJhCXgS6T = '\n\n\n\n'.join(ww2nEWifbsVO4rMkHAgevcRP)
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('كلا','no')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('استمرار','continue')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('أدناه','below')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(Dj62UpP5MrbTkJqhRa,'00001')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(Ym6q5M4TocDaA013RjFQ,'00002')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(oOQaRxBXyJ5jVnZ,'00003')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('=====','00004')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(',','00005')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[RTL]','00009')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[CENTER]','0000A')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(rScptJWVdgzQGR1E3LZ9byC,'0000B')
	ww2nEWifbsVO4rMkHAgevcRP = FMxeyLvnzabpJhCXgS6T.split(rJ9cgWz4FU)
	FMxeyLvnzabpJhCXgS6T,x0ch5q6d7RpHVjSuZ1m4fbaUyrX = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
		if len(FMxeyLvnzabpJhCXgS6T+LowSfEj9cH)<1800: FMxeyLvnzabpJhCXgS6T += rJ9cgWz4FU+LowSfEj9cH
		else:
			dJE7zucgHNtp.append(FMxeyLvnzabpJhCXgS6T)
			FMxeyLvnzabpJhCXgS6T = LowSfEj9cH
	dJE7zucgHNtp.append(FMxeyLvnzabpJhCXgS6T)
	for LowSfEj9cH in dJE7zucgHNtp:
		G9olD6cNbsdS = {'Content-Type':'application/json','User-Agent':CJlTSEpZsWb0QHg5w}
		pkNZlmhUSwtXgriJHjT59MV1QqK = 'https://api.reverso.net/translate/v1/translation'
		vYfNCsUkSVbI894lPxc = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.code')
		xDumKC4LTehPjr7UXfAVB5Zazv = {"format":"text","from":"ara","to":vYfNCsUkSVbI894lPxc,"input":LowSfEj9cH,"options":{"sentenceSplitter":w2qb6lf5EM,"origin":"translation.web","contextResults":VJZIMkUN5siqB21Pf,"languageDetection":VJZIMkUN5siqB21Pf}}
		xDumKC4LTehPjr7UXfAVB5Zazv = KSHcVmz2W84iQvbRDBhGldpCL.dumps(xDumKC4LTehPjr7UXfAVB5Zazv)
		C0q5dOLGD8 = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'POST',pkNZlmhUSwtXgriJHjT59MV1QqK,xDumKC4LTehPjr7UXfAVB5Zazv,G9olD6cNbsdS,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LIBRARY-REVERSO_TRANSLATE-1st')
		if C0q5dOLGD8.succeeded:
			fLgxFao7GCIMqj8iw5ucXd4Ov = C0q5dOLGD8.content
			fLgxFao7GCIMqj8iw5ucXd4Ov = oE7iT3HI5VDdmY4kPOjr('dict',fLgxFao7GCIMqj8iw5ucXd4Ov)
			x0ch5q6d7RpHVjSuZ1m4fbaUyrX += rJ9cgWz4FU+CJlTSEpZsWb0QHg5w.join(fLgxFao7GCIMqj8iw5ucXd4Ov['translation'])
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX[VTadWjBloMwXO2CH9GDK6FR:]
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000000','00000').replace('00000','0000').replace('0000','000')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0001',Dj62UpP5MrbTkJqhRa)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0002',Ym6q5M4TocDaA013RjFQ)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0003',oOQaRxBXyJ5jVnZ)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0004','=====')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0005',',')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('0009','[RTL]')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000A','[CENTER]')
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.replace('000B',rScptJWVdgzQGR1E3LZ9byC)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = x0ch5q6d7RpHVjSuZ1m4fbaUyrX.split('\n\n\n\n')
	return QR34JVGupS1tv+x0ch5q6d7RpHVjSuZ1m4fbaUyrX
def YkK6LcOFbDe(ww2nEWifbsVO4rMkHAgevcRP):
	Bg2aJMV1peCd83W = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.translate')
	if not Bg2aJMV1peCd83W or not ww2nEWifbsVO4rMkHAgevcRP: return ww2nEWifbsVO4rMkHAgevcRP
	bKpPgfhSrZ = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.provider')
	vYfNCsUkSVbI894lPxc = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.code')
	noWmU4GsvTkQ1 = vYfNCsUkSVbI894lPxc+'__'+str(ww2nEWifbsVO4rMkHAgevcRP)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.language.translate',CJlTSEpZsWb0QHg5w)
	x0ch5q6d7RpHVjSuZ1m4fbaUyrX = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','TRANSLATE_'+bKpPgfhSrZ,noWmU4GsvTkQ1)
	if not x0ch5q6d7RpHVjSuZ1m4fbaUyrX:
		if bKpPgfhSrZ=='GOOGLE': x0ch5q6d7RpHVjSuZ1m4fbaUyrX = qnCH0uVrGfl9a(ww2nEWifbsVO4rMkHAgevcRP)
		elif bKpPgfhSrZ=='REVERSO': x0ch5q6d7RpHVjSuZ1m4fbaUyrX = P3LVsCA6cSbw5driFN4vElB(ww2nEWifbsVO4rMkHAgevcRP)
		elif bKpPgfhSrZ=='GLOSBE': x0ch5q6d7RpHVjSuZ1m4fbaUyrX = QXmHF2aIleTuYq0tCfZb6DUPjNpg5(ww2nEWifbsVO4rMkHAgevcRP)
		if len(ww2nEWifbsVO4rMkHAgevcRP)==len(x0ch5q6d7RpHVjSuZ1m4fbaUyrX):
			JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'TRANSLATE_'+bKpPgfhSrZ,noWmU4GsvTkQ1,x0ch5q6d7RpHVjSuZ1m4fbaUyrX,taSwGoeiz7mv)
		else:
			x0ch5q6d7RpHVjSuZ1m4fbaUyrX = ww2nEWifbsVO4rMkHAgevcRP
			KhwN2zcb7iMkjS5E4WURxByPGon('الترجمة فشلت','Translation Failed')
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.language.translate','1')
	return x0ch5q6d7RpHVjSuZ1m4fbaUyrX
def h7h5jOlyrznxHePifwWbCvoaDQZA(izPAxfYFVy1m,HgWtqkEBIyTxKo,IKy3WamteYVQgqsR1bEhx,IPvuk4fVSX7wptOLjmhR5T,UtZ1rLqCFSGBjpfyosicz4l):
	nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = izPAxfYFVy1m
	mmDlzMEyab = []
	Bg2aJMV1peCd83W = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.translate')
	if Bg2aJMV1peCd83W:
		daPwgV4E1xsn93WUyDQbcp,ETg4dULIFpOwt036XsB8,cndJvQ2ji3KphPY1 = [],[],[]
		if not mmDlzMEyab:
			for YRHCPUrfiAhj2QwNKaXelFWg in HgWtqkEBIyTxKo:
				idaKcvOmbRrkW1CtHhZfeAJQV4D = YRHCPUrfiAhj2QwNKaXelFWg['name'].replace(s6rxOhWUy0bXDdQMJleNmu,CJlTSEpZsWb0QHg5w).replace(HCgURFmf8NvkYs2wnX,CJlTSEpZsWb0QHg5w)
				UUXOlvtFjpd = Zy2l0g8QU5vqefaTrsw.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if UUXOlvtFjpd:
					QR34JVGupS1tv,YYrOMXAnUFKT1GNex5HwL,br8xYNRu4yqHQ,LE2J3ijkv9DBZKr,idaKcvOmbRrkW1CtHhZfeAJQV4D = UUXOlvtFjpd[ZVNvqy4iF1a9X]
					UUXOlvtFjpd = QR34JVGupS1tv+YYrOMXAnUFKT1GNex5HwL+YvOQBzaTAscXR9ql+br8xYNRu4yqHQ+LE2J3ijkv9DBZKr+YvOQBzaTAscXR9ql
				else:
					UUXOlvtFjpd = Zy2l0g8QU5vqefaTrsw.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if UUXOlvtFjpd:
						idaKcvOmbRrkW1CtHhZfeAJQV4D,QR34JVGupS1tv,br8xYNRu4yqHQ,YYrOMXAnUFKT1GNex5HwL,LE2J3ijkv9DBZKr = UUXOlvtFjpd[ZVNvqy4iF1a9X]
						UUXOlvtFjpd = QR34JVGupS1tv+YYrOMXAnUFKT1GNex5HwL+YvOQBzaTAscXR9ql+br8xYNRu4yqHQ+LE2J3ijkv9DBZKr+YvOQBzaTAscXR9ql
					else: UUXOlvtFjpd = CJlTSEpZsWb0QHg5w
				wbWJX8PB4v3OM = Zy2l0g8QU5vqefaTrsw.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if wbWJX8PB4v3OM: wbWJX8PB4v3OM,idaKcvOmbRrkW1CtHhZfeAJQV4D = wbWJX8PB4v3OM[ZVNvqy4iF1a9X]
				else: wbWJX8PB4v3OM = CJlTSEpZsWb0QHg5w
				daPwgV4E1xsn93WUyDQbcp.append(UUXOlvtFjpd+wbWJX8PB4v3OM)
				ETg4dULIFpOwt036XsB8.append(idaKcvOmbRrkW1CtHhZfeAJQV4D)
			cndJvQ2ji3KphPY1 = YkK6LcOFbDe(ETg4dULIFpOwt036XsB8)
			if cndJvQ2ji3KphPY1:
				for X0Rq3ISdwTJsnWGM7Kmc4 in range(len(HgWtqkEBIyTxKo)):
					YRHCPUrfiAhj2QwNKaXelFWg = HgWtqkEBIyTxKo[X0Rq3ISdwTJsnWGM7Kmc4]
					YRHCPUrfiAhj2QwNKaXelFWg['name'] = daPwgV4E1xsn93WUyDQbcp[X0Rq3ISdwTJsnWGM7Kmc4]+cndJvQ2ji3KphPY1[X0Rq3ISdwTJsnWGM7Kmc4]
					mmDlzMEyab.append(YRHCPUrfiAhj2QwNKaXelFWg)
	if mmDlzMEyab: HgWtqkEBIyTxKo = mmDlzMEyab
	KPd9ZbtjszmDhY27wn3,CrDnYOKqdG95aVpkI6b7,JI0UCOa9g1pxMh = [],ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
	jipAkBeR6Q5VNtqobCrwE034GIgvm = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.status.menusimages')
	uv6RfenrDlm5XWdkYpFMbcUL4s0V = jipAkBeR6Q5VNtqobCrwE034GIgvm!='STOP'
	tihpr9RTwkWLYHxqFK = []
	if uv6RfenrDlm5XWdkYpFMbcUL4s0V:
		KPhSWMeDU8IoZy0Vf = tiFgl4DMvGEAUfjIYkHbr05.path.join(CD6FK0opq3A4cYJWN1RHeEUZvti,BEUVvSQtRimC)
		try: tihpr9RTwkWLYHxqFK = tiFgl4DMvGEAUfjIYkHbr05.listdir(KPhSWMeDU8IoZy0Vf)
		except:
			if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(KPhSWMeDU8IoZy0Vf):
				try: tiFgl4DMvGEAUfjIYkHbr05.makedirs(KPhSWMeDU8IoZy0Vf)
				except: pass
	XgGCE29IK3BkHqAbyOUfVs = vWT6Hon2lrGJ4DASkwfYF8('menu_item')
	Wr4KTUuPOjDfdAaRLGik86 = tihpr9RTwkWLYHxqFK
	if BB7oCRfQNSYj5qDhTUevV and A8v6c2fL7egwWCF3YBqr4kXSRn.platform=='win32':
		Wr4KTUuPOjDfdAaRLGik86 = []
		for nlOGWHiMrfz in tihpr9RTwkWLYHxqFK:
			nlOGWHiMrfz = nlOGWHiMrfz.decode('windows-1256').encode(Im5KSGZYBpRvdMVsbuXg)
			Wr4KTUuPOjDfdAaRLGik86.append(nlOGWHiMrfz)
	for YRHCPUrfiAhj2QwNKaXelFWg in HgWtqkEBIyTxKo:
		idaKcvOmbRrkW1CtHhZfeAJQV4D = YRHCPUrfiAhj2QwNKaXelFWg['name']
		if A7Z6OVh20eCEUx: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.encode(Im5KSGZYBpRvdMVsbuXg,'ignore').decode(Im5KSGZYBpRvdMVsbuXg)
		JvSuHnyaFgo51Ylf07634hQjXwTIsA = YRHCPUrfiAhj2QwNKaXelFWg['context_menu']
		A7qe5DES8O4b = YRHCPUrfiAhj2QwNKaXelFWg['plot']
		YYezyDqhBn6FiPN3dKU4M = YRHCPUrfiAhj2QwNKaXelFWg['stars']
		ayeFgd1rBXvlfuKPYEihU82 = YRHCPUrfiAhj2QwNKaXelFWg['image']
		nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = YRHCPUrfiAhj2QwNKaXelFWg['type']
		jQ3ILDlYFsmcqTKGpvy80aMkP7 = YRHCPUrfiAhj2QwNKaXelFWg['duration']
		DsJaYtPVeIhRmSj5uiN1GTfAnw9g = YRHCPUrfiAhj2QwNKaXelFWg['isFolder']
		GzMJS98cAfLaN2EHxV = YRHCPUrfiAhj2QwNKaXelFWg['newpath']
		bWcgk4XpuBKo8IaR = rTF8V7fLD2SXJbAURpZjQ4wH.ListItem(idaKcvOmbRrkW1CtHhZfeAJQV4D)
		bWcgk4XpuBKo8IaR.addContextMenuItems(JvSuHnyaFgo51Ylf07634hQjXwTIsA)
		NN5P0G7qkAmMc92g8VSvT1x = VJZIMkUN5siqB21Pf if uv6RfenrDlm5XWdkYpFMbcUL4s0V else w2qb6lf5EM
		if ayeFgd1rBXvlfuKPYEihU82:
			bWcgk4XpuBKo8IaR.setArt({'icon':ayeFgd1rBXvlfuKPYEihU82,'thumb':ayeFgd1rBXvlfuKPYEihU82,'fanart':ayeFgd1rBXvlfuKPYEihU82,'banner':ayeFgd1rBXvlfuKPYEihU82,'clearart':ayeFgd1rBXvlfuKPYEihU82,'poster':ayeFgd1rBXvlfuKPYEihU82,'clearlogo':ayeFgd1rBXvlfuKPYEihU82,'landscape':ayeFgd1rBXvlfuKPYEihU82})
			NN5P0G7qkAmMc92g8VSvT1x = VJZIMkUN5siqB21Pf
		elif not NN5P0G7qkAmMc92g8VSvT1x:
			NN5P0G7qkAmMc92g8VSvT1x = w2qb6lf5EM
			idaKcvOmbRrkW1CtHhZfeAJQV4D = c3mPLX9b6oqze0UCJEartIuds(VJZIMkUN5siqB21Pf,idaKcvOmbRrkW1CtHhZfeAJQV4D)
			idaKcvOmbRrkW1CtHhZfeAJQV4D = vvcCMPFyJDZ48oH6lTzma0xr9edOUK(idaKcvOmbRrkW1CtHhZfeAJQV4D)
			NhFjv9OQZLuytiSn0X7APlE = idaKcvOmbRrkW1CtHhZfeAJQV4D+'.png'
			pxawY4EuvBo = tiFgl4DMvGEAUfjIYkHbr05.path.join(KPhSWMeDU8IoZy0Vf,NhFjv9OQZLuytiSn0X7APlE)
			if NhFjv9OQZLuytiSn0X7APlE in Wr4KTUuPOjDfdAaRLGik86:
				bWcgk4XpuBKo8IaR.setArt({'icon':pxawY4EuvBo,'thumb':pxawY4EuvBo,'fanart':pxawY4EuvBo,'banner':pxawY4EuvBo,'clearart':pxawY4EuvBo,'poster':pxawY4EuvBo,'clearlogo':pxawY4EuvBo,'landscape':pxawY4EuvBo})
				NN5P0G7qkAmMc92g8VSvT1x = VJZIMkUN5siqB21Pf
			elif CrDnYOKqdG95aVpkI6b7<40 and JI0UCOa9g1pxMh<=D9yBM7wPFLz:
				try:
					kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK = t2NSsGbM7OaKRV1ocP(XgGCE29IK3BkHqAbyOUfVs,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,idaKcvOmbRrkW1CtHhZfeAJQV4D,'menu_item','center',VJZIMkUN5siqB21Pf,pxawY4EuvBo)
					bWcgk4XpuBKo8IaR.setArt({'icon':pxawY4EuvBo,'thumb':pxawY4EuvBo,'fanart':pxawY4EuvBo,'banner':pxawY4EuvBo,'clearart':pxawY4EuvBo,'poster':pxawY4EuvBo,'clearlogo':pxawY4EuvBo,'landscape':pxawY4EuvBo})
					CrDnYOKqdG95aVpkI6b7 += P2Fgh6TCOWoaHjkqBcQnvRNXe
					NN5P0G7qkAmMc92g8VSvT1x = VJZIMkUN5siqB21Pf
					Wr4KTUuPOjDfdAaRLGik86.append(NhFjv9OQZLuytiSn0X7APlE)
					if CrDnYOKqdG95aVpkI6b7==GGsP9SDod4iUBm6kNMfLw: KhwN2zcb7iMkjS5E4WURxByPGon('إضافة الكتابة لصور القائمة','انتظار',L8Wkv5KCSoq=500)
				except: JI0UCOa9g1pxMh += P2Fgh6TCOWoaHjkqBcQnvRNXe
		if NN5P0G7qkAmMc92g8VSvT1x:
			bWcgk4XpuBKo8IaR.setArt({'icon':w3uWGPObsEe1FNcZIgm72VRh6v,'thumb':w3uWGPObsEe1FNcZIgm72VRh6v,'fanart':w3uWGPObsEe1FNcZIgm72VRh6v,'banner':w3uWGPObsEe1FNcZIgm72VRh6v,'clearart':w3uWGPObsEe1FNcZIgm72VRh6v,'poster':w3uWGPObsEe1FNcZIgm72VRh6v,'clearlogo':w3uWGPObsEe1FNcZIgm72VRh6v,'landscape':w3uWGPObsEe1FNcZIgm72VRh6v})
		if K9MoWfyg6w2EHIki4lLtFSzpxQTmRX<20:
			if A7qe5DES8O4b: bWcgk4XpuBKo8IaR.setInfo('video',{'Plot':A7qe5DES8O4b,'PlotOutline':A7qe5DES8O4b})
			if YYezyDqhBn6FiPN3dKU4M: bWcgk4XpuBKo8IaR.setInfo('video',{'Rating':YYezyDqhBn6FiPN3dKU4M})
			if not ayeFgd1rBXvlfuKPYEihU82:
				bWcgk4XpuBKo8IaR.setInfo('video',{'Title':idaKcvOmbRrkW1CtHhZfeAJQV4D})
			if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video':
				bWcgk4XpuBKo8IaR.setInfo('video',{'mediatype':'tvshow'})
				if jQ3ILDlYFsmcqTKGpvy80aMkP7: bWcgk4XpuBKo8IaR.setInfo('video',{'duration':jQ3ILDlYFsmcqTKGpvy80aMkP7})
				bWcgk4XpuBKo8IaR.setProperty('IsPlayable','true')
		else:
			bZTd1QR0LMvkEm9j = bWcgk4XpuBKo8IaR.getVideoInfoTag()
			if YYezyDqhBn6FiPN3dKU4M: bZTd1QR0LMvkEm9j.setRating(float(YYezyDqhBn6FiPN3dKU4M))
			if not ayeFgd1rBXvlfuKPYEihU82:
				bZTd1QR0LMvkEm9j.setTitle(idaKcvOmbRrkW1CtHhZfeAJQV4D)
			if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video':
				bZTd1QR0LMvkEm9j.setMediaType('tvshow')
				if jQ3ILDlYFsmcqTKGpvy80aMkP7: bZTd1QR0LMvkEm9j.setDuration(jQ3ILDlYFsmcqTKGpvy80aMkP7)
				bWcgk4XpuBKo8IaR.setProperty('IsPlayable','true')
		KPd9ZbtjszmDhY27wn3.append((GzMJS98cAfLaN2EHxV,bWcgk4XpuBKo8IaR,DsJaYtPVeIhRmSj5uiN1GTfAnw9g))
	ZqpKwnSTtsNmWYCfueOxd14.setContent(b4qsaVwC0mHOGPKp5,'tvshows')
	KZ4QmkD2stHYhG9SjN6EFvJnqxTXRC = ZqpKwnSTtsNmWYCfueOxd14.addDirectoryItems(b4qsaVwC0mHOGPKp5,KPd9ZbtjszmDhY27wn3)
	ZqpKwnSTtsNmWYCfueOxd14.endOfDirectory(b4qsaVwC0mHOGPKp5,IKy3WamteYVQgqsR1bEhx,IPvuk4fVSX7wptOLjmhR5T,UtZ1rLqCFSGBjpfyosicz4l)
	return KZ4QmkD2stHYhG9SjN6EFvJnqxTXRC
def khqge7BVD9jPFy1S8T5Gn4QAlH(nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82=CJlTSEpZsWb0QHg5w,ZraEU3jpk2ns6q0ztPgvhioAX=CJlTSEpZsWb0QHg5w,FMxeyLvnzabpJhCXgS6T=CJlTSEpZsWb0QHg5w,AC0yWDME4VSh8rkFXwpGeol6st=CJlTSEpZsWb0QHg5w,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO={}):
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace('\t',CJlTSEpZsWb0QHg5w)
	pkNZlmhUSwtXgriJHjT59MV1QqK = pkNZlmhUSwtXgriJHjT59MV1QqK.replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace('\t',CJlTSEpZsWb0QHg5w)
	if '_SCRIPT_' in idaKcvOmbRrkW1CtHhZfeAJQV4D:
		Hk0y5BFPUwlGDoiA7pu8,idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.split('_SCRIPT_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
		if Hk0y5BFPUwlGDoiA7pu8 not in list(Ew2zQ8u7Ss.menuItemsDICT.keys()): Ew2zQ8u7Ss.menuItemsDICT[Hk0y5BFPUwlGDoiA7pu8] = []
		Ew2zQ8u7Ss.menuItemsDICT[Hk0y5BFPUwlGDoiA7pu8].append([nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO])
	Ew2zQ8u7Ss.menuItemsLIST.append([nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO])
	return
def wAmsc95ya0LHz(MM2ouIr1YX7TkEcg8OsPWD):
	if A7Z6OVh20eCEUx: from html import unescape as _ejW43oq78si0bnNKE
	else:
		from HTMLParser import HTMLParser as aqu4j2OFMZYLnId3HmJWrNfSxpDBw5
		_ejW43oq78si0bnNKE = aqu4j2OFMZYLnId3HmJWrNfSxpDBw5().unescape
	if '&' in MM2ouIr1YX7TkEcg8OsPWD and ';' in MM2ouIr1YX7TkEcg8OsPWD:
		if BB7oCRfQNSYj5qDhTUevV: MM2ouIr1YX7TkEcg8OsPWD = MM2ouIr1YX7TkEcg8OsPWD.decode(Im5KSGZYBpRvdMVsbuXg)
		MM2ouIr1YX7TkEcg8OsPWD = _ejW43oq78si0bnNKE(MM2ouIr1YX7TkEcg8OsPWD)
		if BB7oCRfQNSYj5qDhTUevV: MM2ouIr1YX7TkEcg8OsPWD = MM2ouIr1YX7TkEcg8OsPWD.encode(Im5KSGZYBpRvdMVsbuXg)
	return MM2ouIr1YX7TkEcg8OsPWD
def pd0Na8D5WZfHYkysVS(MM2ouIr1YX7TkEcg8OsPWD):
	if '\\u' in MM2ouIr1YX7TkEcg8OsPWD:
		if BB7oCRfQNSYj5qDhTUevV: MM2ouIr1YX7TkEcg8OsPWD = MM2ouIr1YX7TkEcg8OsPWD.decode('unicode_escape','ignore').encode(Im5KSGZYBpRvdMVsbuXg)
		elif A7Z6OVh20eCEUx: MM2ouIr1YX7TkEcg8OsPWD = MM2ouIr1YX7TkEcg8OsPWD.encode(Im5KSGZYBpRvdMVsbuXg).decode('unicode_escape','ignore')
	return MM2ouIr1YX7TkEcg8OsPWD
def sXRCiumten85HYp2xy7va1wQl(aNbDn7Cc0eogrThO9iUBIkvX,BICk8j4xVhzsWgF,AOEKYoxUaMJuGB6vLcVgnI,aarD9dRFN3L6gYTPS8,FMxeyLvnzabpJhCXgS6T,eQSDTK4aJOxHMgE,P4C5JryxQoz9LDZWBUV3aus7lOt2,bb1vhxP4KuWsmzcMnSCIXQ,vhnwFHMbyPIYW3o9r7kVD6A1ZQS4):
	tcpVFLE7TP1Dkye4w = tiFgl4DMvGEAUfjIYkHbr05.path.dirname(vhnwFHMbyPIYW3o9r7kVD6A1ZQS4)
	if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(tcpVFLE7TP1Dkye4w):
		try: tiFgl4DMvGEAUfjIYkHbr05.makedirs(tcpVFLE7TP1Dkye4w)
		except: pass
	ddex5DFQjqzNcaK = vWT6Hon2lrGJ4DASkwfYF8(eQSDTK4aJOxHMgE)
	kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK = t2NSsGbM7OaKRV1ocP(ddex5DFQjqzNcaK,aNbDn7Cc0eogrThO9iUBIkvX,BICk8j4xVhzsWgF,AOEKYoxUaMJuGB6vLcVgnI,aarD9dRFN3L6gYTPS8,FMxeyLvnzabpJhCXgS6T,eQSDTK4aJOxHMgE,P4C5JryxQoz9LDZWBUV3aus7lOt2,bb1vhxP4KuWsmzcMnSCIXQ,vhnwFHMbyPIYW3o9r7kVD6A1ZQS4)
	return kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK
def vWT6Hon2lrGJ4DASkwfYF8(eQSDTK4aJOxHMgE):
	JJnYNMUoQgEX = GGsP9SDod4iUBm6kNMfLw
	FHYnAyschMkEVtmqCvz4dSu2jpw = 20
	zlnMb9GXV2WjrgENtopdyBS7 = 20
	IutYxZcKvRMk0X52VBJCrTqbQ4eLOj = ZVNvqy4iF1a9X
	EBVupy1rIlXGnhDxoe92mtM = 'center'
	k0dGqCrmtEn8zOKF2JXbZ = ZVNvqy4iF1a9X
	S0tMN4DoEpay = 19
	gzkT0GLpAN9oCOVw25MqHEIW8 = 30
	WurR54lgJGKjIfMwhy0LOPTdXkox = 8
	uuzvVXogEiJRf = w2qb6lf5EM
	Gi9YuMfRgPKrkmTV7w = 375
	OXGl5sxmILjYbir3R9PCE6tUdg = 410
	Exuodsn9NX7Iz2MB4bUD6Ar = 50
	oo6uOlRUtzeQhIDYjbPCfHE = 280
	MPLNYoQCV4 = 28
	BNeMZX4tDkldxOhEzJfps2u = GGsP9SDod4iUBm6kNMfLw
	xkzbVduqwMHtJyaL17 = ZVNvqy4iF1a9X
	NtSDwgXceAZ6PoJKfOmslaHY3 = 31
	jL7wrHhZl8OCoWeYEn3gMIA = [36,32,28]
	from PIL import ImageDraw as uxCKlcTjdXhMVSiDmU,ImageFont as ruQg8e1PjwnOxfStyqI0ADLaZ2XCd,Image as H5P16f7v0u
	if 'notification' in eQSDTK4aJOxHMgE:
		if eQSDTK4aJOxHMgE=='notification_regular':
			j8r6pLnV3d = 117
			EBVupy1rIlXGnhDxoe92mtM = 'left'
			uuzvVXogEiJRf = VJZIMkUN5siqB21Pf
		elif eQSDTK4aJOxHMgE=='notification_auto':
			j8r6pLnV3d = 'UPPER'
			EBVupy1rIlXGnhDxoe92mtM = 'right'
			IutYxZcKvRMk0X52VBJCrTqbQ4eLOj = 10
		felixkHLTjavVKuo9XI = 720
		jL7wrHhZl8OCoWeYEn3gMIA = [33,33,33]
		zlnMb9GXV2WjrgENtopdyBS7 = 20
		FHYnAyschMkEVtmqCvz4dSu2jpw = ZVNvqy4iF1a9X
		gzkT0GLpAN9oCOVw25MqHEIW8 = 20
		S0tMN4DoEpay = 35
	elif eQSDTK4aJOxHMgE=='menu_item':
		jL7wrHhZl8OCoWeYEn3gMIA,felixkHLTjavVKuo9XI,j8r6pLnV3d = [28,28,28],200,250
		k0dGqCrmtEn8zOKF2JXbZ,gzkT0GLpAN9oCOVw25MqHEIW8,S0tMN4DoEpay, = ZVNvqy4iF1a9X,-12,-30
		FHYnAyschMkEVtmqCvz4dSu2jpw = ZVNvqy4iF1a9X
		HgCPAwtRnd = H5P16f7v0u.open(w3uWGPObsEe1FNcZIgm72VRh6v)
		a2RhMCENpVG57 = H5P16f7v0u.new('RGBA',(felixkHLTjavVKuo9XI,j8r6pLnV3d),(255,ZVNvqy4iF1a9X,ZVNvqy4iF1a9X,255))
	elif eQSDTK4aJOxHMgE=='confirm_smallfont': jL7wrHhZl8OCoWeYEn3gMIA,j8r6pLnV3d,felixkHLTjavVKuo9XI = [28,24,20],500,900
	elif eQSDTK4aJOxHMgE=='confirm_mediumfont': jL7wrHhZl8OCoWeYEn3gMIA,j8r6pLnV3d,felixkHLTjavVKuo9XI = [32,28,24],500,900
	elif eQSDTK4aJOxHMgE=='confirm_bigfont': jL7wrHhZl8OCoWeYEn3gMIA,j8r6pLnV3d,felixkHLTjavVKuo9XI = [36,32,28],500,900
	elif eQSDTK4aJOxHMgE=='textview_bigfont': j8r6pLnV3d,felixkHLTjavVKuo9XI = 740,1270
	elif eQSDTK4aJOxHMgE=='textview_bigfont_long': j8r6pLnV3d,felixkHLTjavVKuo9XI = 'UPPER',1270
	elif eQSDTK4aJOxHMgE=='textview_smallfont': jL7wrHhZl8OCoWeYEn3gMIA,j8r6pLnV3d,felixkHLTjavVKuo9XI = [28,23,18],740,1270
	elif eQSDTK4aJOxHMgE=='textview_smallfont_long': jL7wrHhZl8OCoWeYEn3gMIA,j8r6pLnV3d,felixkHLTjavVKuo9XI = [28,23,18],'UPPER',1270
	YNDX3jJ6FgrRLlnI,R65qDSeixuzb9jVGlwv2WhLy1sNcJ,gYz8PAmjra2X5KLbB = jL7wrHhZl8OCoWeYEn3gMIA
	mtdK7D1UZGTEosORLMrAC = ruQg8e1PjwnOxfStyqI0ADLaZ2XCd.truetype(JHZcO82T74nUWCuvym,size=YNDX3jJ6FgrRLlnI)
	cJLewjtAFp5soHvEkq41 = ruQg8e1PjwnOxfStyqI0ADLaZ2XCd.truetype(JHZcO82T74nUWCuvym,size=R65qDSeixuzb9jVGlwv2WhLy1sNcJ)
	Idn5AGzsgvhX6KTtmS = ruQg8e1PjwnOxfStyqI0ADLaZ2XCd.truetype(JHZcO82T74nUWCuvym,size=gYz8PAmjra2X5KLbB)
	xQKrJ8i7DZO36LEh = felixkHLTjavVKuo9XI-gzkT0GLpAN9oCOVw25MqHEIW8*VTadWjBloMwXO2CH9GDK6FR
	spJlSmzGjk5dogT = H5P16f7v0u.new('RGBA',(xQKrJ8i7DZO36LEh,100),(255,255,255,ZVNvqy4iF1a9X))
	U2URK65mPkuNMcd0oCpv = uxCKlcTjdXhMVSiDmU.Draw(spJlSmzGjk5dogT)
	g4kRfztnar3Fi9y5IM0pHVv,d5skZhGtvnJwcYXWKD2qiSu = U2URK65mPkuNMcd0oCpv.textsize('HHH BBB 888 000',font=mtdK7D1UZGTEosORLMrAC)
	Iuh3C6VPOkN27MxW1szvZ45D0i9,ggiDJXA8QCfjNS61dF = U2URK65mPkuNMcd0oCpv.textsize('HHH BBB 888 000',font=cJLewjtAFp5soHvEkq41)
	OxBjRwvrQhaye = {'delete_harakat':VJZIMkUN5siqB21Pf,'support_ligatures':w2qb6lf5EM,'ARABIC LIGATURE ALLAH':VJZIMkUN5siqB21Pf}
	from arabic_reshaper import ArabicReshaper as xxVbaUcuqn
	KK21BpvIbS6TzEaXCU8 = xxVbaUcuqn(configuration=OxBjRwvrQhaye)
	ddex5DFQjqzNcaK = {}
	qL2uzIMb3l10mRtix5VKPnCakYD = locals()
	for nnoEs7LuAtHfTMq4dKpvJXbRxkFY9 in qL2uzIMb3l10mRtix5VKPnCakYD: ddex5DFQjqzNcaK[nnoEs7LuAtHfTMq4dKpvJXbRxkFY9] = qL2uzIMb3l10mRtix5VKPnCakYD[nnoEs7LuAtHfTMq4dKpvJXbRxkFY9]
	return ddex5DFQjqzNcaK
def t2NSsGbM7OaKRV1ocP(ddex5DFQjqzNcaK,aNbDn7Cc0eogrThO9iUBIkvX,BICk8j4xVhzsWgF,AOEKYoxUaMJuGB6vLcVgnI,aarD9dRFN3L6gYTPS8,FMxeyLvnzabpJhCXgS6T,eQSDTK4aJOxHMgE,P4C5JryxQoz9LDZWBUV3aus7lOt2,bb1vhxP4KuWsmzcMnSCIXQ,vhnwFHMbyPIYW3o9r7kVD6A1ZQS4):
	for nnoEs7LuAtHfTMq4dKpvJXbRxkFY9 in ddex5DFQjqzNcaK: globals()[nnoEs7LuAtHfTMq4dKpvJXbRxkFY9] = ddex5DFQjqzNcaK[nnoEs7LuAtHfTMq4dKpvJXbRxkFY9]
	global MPLNYoQCV4,BNeMZX4tDkldxOhEzJfps2u
	if eQSDTK4aJOxHMgE!='menu_item':
		Bg2aJMV1peCd83W = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.translate')
		if Bg2aJMV1peCd83W:
			if aNbDn7Cc0eogrThO9iUBIkvX=='نعم  Yes': aNbDn7Cc0eogrThO9iUBIkvX = 'Yes'
			elif aNbDn7Cc0eogrThO9iUBIkvX=='كلا  No': aNbDn7Cc0eogrThO9iUBIkvX = 'No'
			if BICk8j4xVhzsWgF=='نعم  Yes': BICk8j4xVhzsWgF = 'Yes'
			elif BICk8j4xVhzsWgF=='كلا  No': BICk8j4xVhzsWgF = 'No'
			if AOEKYoxUaMJuGB6vLcVgnI=='نعم  Yes': AOEKYoxUaMJuGB6vLcVgnI = 'Yes'
			elif AOEKYoxUaMJuGB6vLcVgnI=='كلا  No': AOEKYoxUaMJuGB6vLcVgnI = 'No'
			qTXQ0E8GoMkdI1 = YkK6LcOFbDe([aNbDn7Cc0eogrThO9iUBIkvX,BICk8j4xVhzsWgF,AOEKYoxUaMJuGB6vLcVgnI,aarD9dRFN3L6gYTPS8,FMxeyLvnzabpJhCXgS6T])
			if qTXQ0E8GoMkdI1: aNbDn7Cc0eogrThO9iUBIkvX,BICk8j4xVhzsWgF,AOEKYoxUaMJuGB6vLcVgnI,aarD9dRFN3L6gYTPS8,FMxeyLvnzabpJhCXgS6T = qTXQ0E8GoMkdI1
	if BB7oCRfQNSYj5qDhTUevV:
		FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.decode(Im5KSGZYBpRvdMVsbuXg)
		aarD9dRFN3L6gYTPS8 = aarD9dRFN3L6gYTPS8.decode(Im5KSGZYBpRvdMVsbuXg)
		aNbDn7Cc0eogrThO9iUBIkvX = aNbDn7Cc0eogrThO9iUBIkvX.decode(Im5KSGZYBpRvdMVsbuXg)
		BICk8j4xVhzsWgF = BICk8j4xVhzsWgF.decode(Im5KSGZYBpRvdMVsbuXg)
		AOEKYoxUaMJuGB6vLcVgnI = AOEKYoxUaMJuGB6vLcVgnI.decode(Im5KSGZYBpRvdMVsbuXg)
	p3YAPubR4eLwTh0OXlsvU = aarD9dRFN3L6gYTPS8.count(rJ9cgWz4FU)+P2Fgh6TCOWoaHjkqBcQnvRNXe
	lOLdajByWYp5n = FHYnAyschMkEVtmqCvz4dSu2jpw+p3YAPubR4eLwTh0OXlsvU*(d5skZhGtvnJwcYXWKD2qiSu+IutYxZcKvRMk0X52VBJCrTqbQ4eLOj)-IutYxZcKvRMk0X52VBJCrTqbQ4eLOj
	if FMxeyLvnzabpJhCXgS6T:
		I1DP2jhUwNAHECWMl3Rzfvnb = ggiDJXA8QCfjNS61dF+WurR54lgJGKjIfMwhy0LOPTdXkox
		fp1gwGTLR9tqSz5E42amIYBNxJvd = KK21BpvIbS6TzEaXCU8.reshape(FMxeyLvnzabpJhCXgS6T)
		if uuzvVXogEiJRf:
			JKYSU1achtjrpmC = oZyWxlPOIzDQFE2pcCvUkH9a(U2URK65mPkuNMcd0oCpv,cJLewjtAFp5soHvEkq41,fp1gwGTLR9tqSz5E42amIYBNxJvd,R65qDSeixuzb9jVGlwv2WhLy1sNcJ,xQKrJ8i7DZO36LEh,I1DP2jhUwNAHECWMl3Rzfvnb)
			P8jahCdpv4xFIHc = IdBf0o3FO9eSrsa(JKYSU1achtjrpmC)
			iPvfl43oYB0XVkz5I96arKQ = P8jahCdpv4xFIHc.count(rJ9cgWz4FU)+P2Fgh6TCOWoaHjkqBcQnvRNXe
			JIAPsw43n7T9vUQCBh6LMxF1 = S0tMN4DoEpay+iPvfl43oYB0XVkz5I96arKQ*I1DP2jhUwNAHECWMl3Rzfvnb-WurR54lgJGKjIfMwhy0LOPTdXkox
		else:
			JIAPsw43n7T9vUQCBh6LMxF1 = S0tMN4DoEpay+ggiDJXA8QCfjNS61dF
			P8jahCdpv4xFIHc = fp1gwGTLR9tqSz5E42amIYBNxJvd.split(rJ9cgWz4FU)[ZVNvqy4iF1a9X]
			JKYSU1achtjrpmC = fp1gwGTLR9tqSz5E42amIYBNxJvd.split(rJ9cgWz4FU)[ZVNvqy4iF1a9X]
	else: JIAPsw43n7T9vUQCBh6LMxF1 = S0tMN4DoEpay
	dYmAXTt3q5ewyaIkDZWMbLUf04C9 = xkzbVduqwMHtJyaL17+NtSDwgXceAZ6PoJKfOmslaHY3
	if bb1vhxP4KuWsmzcMnSCIXQ:
		qQXdVlyzMUPfcxpjkC1wJtRSos4 = OXGl5sxmILjYbir3R9PCE6tUdg-Gi9YuMfRgPKrkmTV7w
		dYmAXTt3q5ewyaIkDZWMbLUf04C9 += qQXdVlyzMUPfcxpjkC1wJtRSos4
	else: qQXdVlyzMUPfcxpjkC1wJtRSos4 = ZVNvqy4iF1a9X
	if aNbDn7Cc0eogrThO9iUBIkvX or BICk8j4xVhzsWgF or AOEKYoxUaMJuGB6vLcVgnI: dYmAXTt3q5ewyaIkDZWMbLUf04C9 += Exuodsn9NX7Iz2MB4bUD6Ar
	kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK = j8r6pLnV3d if j8r6pLnV3d!='UPPER' else lOLdajByWYp5n+JIAPsw43n7T9vUQCBh6LMxF1+dYmAXTt3q5ewyaIkDZWMbLUf04C9
	spJlSmzGjk5dogT = H5P16f7v0u.new('RGBA',(felixkHLTjavVKuo9XI,kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK),(255,255,255,ZVNvqy4iF1a9X))
	kUbZhHmOsdVwWBxPCGt75f1FL = uxCKlcTjdXhMVSiDmU.Draw(spJlSmzGjk5dogT)
	KOlNsgUArc9MjFuhySEwvJZ1a = kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK-lOLdajByWYp5n-dYmAXTt3q5ewyaIkDZWMbLUf04C9-S0tMN4DoEpay
	if not BICk8j4xVhzsWgF and aNbDn7Cc0eogrThO9iUBIkvX and AOEKYoxUaMJuGB6vLcVgnI:
		MPLNYoQCV4 += 105
		BNeMZX4tDkldxOhEzJfps2u -= 110
	import bidi.algorithm as dz6mk9cAg0XbMFqJ28yZ
	if aarD9dRFN3L6gYTPS8:
		Tg5thck3VLF7x6Pj8On0o = FHYnAyschMkEVtmqCvz4dSu2jpw
		aarD9dRFN3L6gYTPS8 = dz6mk9cAg0XbMFqJ28yZ.get_display(KK21BpvIbS6TzEaXCU8.reshape(aarD9dRFN3L6gYTPS8))
		ww2nEWifbsVO4rMkHAgevcRP = aarD9dRFN3L6gYTPS8.splitlines()
		for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
			if LowSfEj9cH:
				QaihwOob8U5MYcl6xTmnesIJgN,SvLefAjZbGl943BdIicQhVw = kUbZhHmOsdVwWBxPCGt75f1FL.textsize(LowSfEj9cH,font=mtdK7D1UZGTEosORLMrAC)
				if EBVupy1rIlXGnhDxoe92mtM=='center': er4BnHPdLw6JcSh3Ftmp = JJnYNMUoQgEX+(felixkHLTjavVKuo9XI-QaihwOob8U5MYcl6xTmnesIJgN)/VTadWjBloMwXO2CH9GDK6FR
				elif EBVupy1rIlXGnhDxoe92mtM=='right': er4BnHPdLw6JcSh3Ftmp = JJnYNMUoQgEX+felixkHLTjavVKuo9XI-QaihwOob8U5MYcl6xTmnesIJgN-zlnMb9GXV2WjrgENtopdyBS7
				elif EBVupy1rIlXGnhDxoe92mtM=='left': er4BnHPdLw6JcSh3Ftmp = JJnYNMUoQgEX+zlnMb9GXV2WjrgENtopdyBS7
				kUbZhHmOsdVwWBxPCGt75f1FL.text((er4BnHPdLw6JcSh3Ftmp,Tg5thck3VLF7x6Pj8On0o),LowSfEj9cH,font=mtdK7D1UZGTEosORLMrAC,fill='yellow')
			Tg5thck3VLF7x6Pj8On0o += YNDX3jJ6FgrRLlnI+IutYxZcKvRMk0X52VBJCrTqbQ4eLOj
	if aNbDn7Cc0eogrThO9iUBIkvX or BICk8j4xVhzsWgF or AOEKYoxUaMJuGB6vLcVgnI:
		qvFsgnaM6umC = lOLdajByWYp5n+KOlNsgUArc9MjFuhySEwvJZ1a+S0tMN4DoEpay+qQXdVlyzMUPfcxpjkC1wJtRSos4+xkzbVduqwMHtJyaL17
		if aNbDn7Cc0eogrThO9iUBIkvX:
			aNbDn7Cc0eogrThO9iUBIkvX = dz6mk9cAg0XbMFqJ28yZ.get_display(KK21BpvIbS6TzEaXCU8.reshape(aNbDn7Cc0eogrThO9iUBIkvX))
			pZXxLUROF5KQP,KRtXNdI4zC0iDL = kUbZhHmOsdVwWBxPCGt75f1FL.textsize(aNbDn7Cc0eogrThO9iUBIkvX,font=Idn5AGzsgvhX6KTtmS)
			qtgNfHpOhS0T3ZbyedAaCBUoI96 = MPLNYoQCV4+ZVNvqy4iF1a9X*(BNeMZX4tDkldxOhEzJfps2u+oo6uOlRUtzeQhIDYjbPCfHE)+(oo6uOlRUtzeQhIDYjbPCfHE-pZXxLUROF5KQP)/VTadWjBloMwXO2CH9GDK6FR
			kUbZhHmOsdVwWBxPCGt75f1FL.text((qtgNfHpOhS0T3ZbyedAaCBUoI96,qvFsgnaM6umC),aNbDn7Cc0eogrThO9iUBIkvX,font=Idn5AGzsgvhX6KTtmS,fill='yellow')
		if BICk8j4xVhzsWgF:
			BICk8j4xVhzsWgF = dz6mk9cAg0XbMFqJ28yZ.get_display(KK21BpvIbS6TzEaXCU8.reshape(BICk8j4xVhzsWgF))
			D2y5E61MJPeikZONTouIzjnt,CrgajkMep2l1c = kUbZhHmOsdVwWBxPCGt75f1FL.textsize(BICk8j4xVhzsWgF,font=Idn5AGzsgvhX6KTtmS)
			gMRWKfP7xjbuBEeIzSv3ydFoLc = MPLNYoQCV4+P2Fgh6TCOWoaHjkqBcQnvRNXe*(BNeMZX4tDkldxOhEzJfps2u+oo6uOlRUtzeQhIDYjbPCfHE)+(oo6uOlRUtzeQhIDYjbPCfHE-D2y5E61MJPeikZONTouIzjnt)/VTadWjBloMwXO2CH9GDK6FR
			kUbZhHmOsdVwWBxPCGt75f1FL.text((gMRWKfP7xjbuBEeIzSv3ydFoLc,qvFsgnaM6umC),BICk8j4xVhzsWgF,font=Idn5AGzsgvhX6KTtmS,fill='yellow')
		if AOEKYoxUaMJuGB6vLcVgnI:
			AOEKYoxUaMJuGB6vLcVgnI = dz6mk9cAg0XbMFqJ28yZ.get_display(KK21BpvIbS6TzEaXCU8.reshape(AOEKYoxUaMJuGB6vLcVgnI))
			CshQLWin5bly2E1,tNDdzK9ZwYnoVH2jCqFcO3x1k = kUbZhHmOsdVwWBxPCGt75f1FL.textsize(AOEKYoxUaMJuGB6vLcVgnI,font=Idn5AGzsgvhX6KTtmS)
			iEpG9zhCfPmRBUTH80bvFW = MPLNYoQCV4+VTadWjBloMwXO2CH9GDK6FR*(BNeMZX4tDkldxOhEzJfps2u+oo6uOlRUtzeQhIDYjbPCfHE)+(oo6uOlRUtzeQhIDYjbPCfHE-CshQLWin5bly2E1)/VTadWjBloMwXO2CH9GDK6FR
			kUbZhHmOsdVwWBxPCGt75f1FL.text((iEpG9zhCfPmRBUTH80bvFW,qvFsgnaM6umC),AOEKYoxUaMJuGB6vLcVgnI,font=Idn5AGzsgvhX6KTtmS,fill='yellow')
	if FMxeyLvnzabpJhCXgS6T:
		qOi4FBEuSjJWNnIgs5PeMTQw,bk1n4dOsGYrM8xL6 = [],[]
		JKYSU1achtjrpmC = uoT81mNUnhi7MYwCRDfeQA(JKYSU1achtjrpmC)
		b6UewdjFQMZWVKI3PvAop8hus = JKYSU1achtjrpmC.split('_sss__newline_')
		for aMS3UvYnH2DotF in b6UewdjFQMZWVKI3PvAop8hus:
			MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC = P4C5JryxQoz9LDZWBUV3aus7lOt2
			if   '_sss__lineleft_' in aMS3UvYnH2DotF: MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC = 'left'
			elif '_sss__lineright_' in aMS3UvYnH2DotF: MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC = 'right'
			elif '_sss__linecenter_' in aMS3UvYnH2DotF: MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC = 'center'
			ao3UdSPVseh5xrH4BWkCJFI2Elcb = aMS3UvYnH2DotF
			llwSCg9uzVf1D = Zy2l0g8QU5vqefaTrsw.findall('_sss__.*?_',aMS3UvYnH2DotF,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for PlLvX0ginUyf in llwSCg9uzVf1D: ao3UdSPVseh5xrH4BWkCJFI2Elcb = ao3UdSPVseh5xrH4BWkCJFI2Elcb.replace(PlLvX0ginUyf,CJlTSEpZsWb0QHg5w)
			if ao3UdSPVseh5xrH4BWkCJFI2Elcb==CJlTSEpZsWb0QHg5w: QaihwOob8U5MYcl6xTmnesIJgN,SvLefAjZbGl943BdIicQhVw = ZVNvqy4iF1a9X,I1DP2jhUwNAHECWMl3Rzfvnb
			else: QaihwOob8U5MYcl6xTmnesIJgN,SvLefAjZbGl943BdIicQhVw = kUbZhHmOsdVwWBxPCGt75f1FL.textsize(ao3UdSPVseh5xrH4BWkCJFI2Elcb,font=cJLewjtAFp5soHvEkq41)
			if   MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC=='left': PqV9ZBWR6n4oiIJw = k0dGqCrmtEn8zOKF2JXbZ+gzkT0GLpAN9oCOVw25MqHEIW8
			elif MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC=='right': PqV9ZBWR6n4oiIJw = k0dGqCrmtEn8zOKF2JXbZ+gzkT0GLpAN9oCOVw25MqHEIW8+xQKrJ8i7DZO36LEh-QaihwOob8U5MYcl6xTmnesIJgN
			elif MnpX4Ai2GuTZ7kx1r96a5KlNeLJbC=='center': PqV9ZBWR6n4oiIJw = k0dGqCrmtEn8zOKF2JXbZ+gzkT0GLpAN9oCOVw25MqHEIW8+(xQKrJ8i7DZO36LEh-QaihwOob8U5MYcl6xTmnesIJgN)/VTadWjBloMwXO2CH9GDK6FR
			if PqV9ZBWR6n4oiIJw<gzkT0GLpAN9oCOVw25MqHEIW8: PqV9ZBWR6n4oiIJw = k0dGqCrmtEn8zOKF2JXbZ+gzkT0GLpAN9oCOVw25MqHEIW8
			qOi4FBEuSjJWNnIgs5PeMTQw.append(PqV9ZBWR6n4oiIJw)
			bk1n4dOsGYrM8xL6.append(QaihwOob8U5MYcl6xTmnesIJgN)
		PqV9ZBWR6n4oiIJw = qOi4FBEuSjJWNnIgs5PeMTQw[ZVNvqy4iF1a9X]
		XXePGakIOcKZQWfbBxu3hdERsUS = JKYSU1achtjrpmC.split('_sss_')
		rh3nL2TIqZOHXSdlkAGxs = (255,255,255,255)
		mw3C5qDIYzLPhd0nfoWF9R = rh3nL2TIqZOHXSdlkAGxs
		Mrt06eZIaqJxuwSG,rqGM4b2pnaD9wNXeiYfEmQx = ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
		EfnrXQsIGFMLJqiaHAxoCp6P = VJZIMkUN5siqB21Pf
		fX1Zt53MrQqxKhAbJ69nysYU2l = ZVNvqy4iF1a9X
		pJLXEo3At68C41w2mThrN = lOLdajByWYp5n+S0tMN4DoEpay/VTadWjBloMwXO2CH9GDK6FR
		if JIAPsw43n7T9vUQCBh6LMxF1<(KOlNsgUArc9MjFuhySEwvJZ1a+S0tMN4DoEpay):
			xatsX7mvZG8MNQCq6Ebk1VuzAIpf = (KOlNsgUArc9MjFuhySEwvJZ1a+S0tMN4DoEpay-JIAPsw43n7T9vUQCBh6LMxF1)/VTadWjBloMwXO2CH9GDK6FR
			pJLXEo3At68C41w2mThrN = lOLdajByWYp5n+S0tMN4DoEpay+xatsX7mvZG8MNQCq6Ebk1VuzAIpf-ggiDJXA8QCfjNS61dF/VTadWjBloMwXO2CH9GDK6FR
		for LowSfEj9cH in XXePGakIOcKZQWfbBxu3hdERsUS:
			if not LowSfEj9cH or (LowSfEj9cH and ord(LowSfEj9cH[ZVNvqy4iF1a9X])==65279): continue
			Phm2LrgFQolVp6HOdvbSt = LowSfEj9cH.split('_newline_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			F0TlpIwSO7gRsbVQrC = LowSfEj9cH.split('_newcolor',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			d7EMhZOtDzH = LowSfEj9cH.split('_endcolor_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			h9hgNYp10iOJqfbREwZkxt = LowSfEj9cH.split('_linertl_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			zziA04rRfTjHUBvCSb = LowSfEj9cH.split('_lineleft_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			WW7g9huYNxGQqmkCejraofZLDswFp6 = LowSfEj9cH.split('_lineright_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			ZCuew1iORtoGhFJQ8sU0cSgTVk = LowSfEj9cH.split('_linecenter_',P2Fgh6TCOWoaHjkqBcQnvRNXe)
			if len(Phm2LrgFQolVp6HOdvbSt)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				fX1Zt53MrQqxKhAbJ69nysYU2l += P2Fgh6TCOWoaHjkqBcQnvRNXe
				LowSfEj9cH = Phm2LrgFQolVp6HOdvbSt[P2Fgh6TCOWoaHjkqBcQnvRNXe]
				Mrt06eZIaqJxuwSG = ZVNvqy4iF1a9X
				PqV9ZBWR6n4oiIJw = qOi4FBEuSjJWNnIgs5PeMTQw[fX1Zt53MrQqxKhAbJ69nysYU2l]
				rqGM4b2pnaD9wNXeiYfEmQx += I1DP2jhUwNAHECWMl3Rzfvnb
				EfnrXQsIGFMLJqiaHAxoCp6P = VJZIMkUN5siqB21Pf
			elif len(F0TlpIwSO7gRsbVQrC)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				LowSfEj9cH = F0TlpIwSO7gRsbVQrC[P2Fgh6TCOWoaHjkqBcQnvRNXe]
				mw3C5qDIYzLPhd0nfoWF9R = LowSfEj9cH[ZVNvqy4iF1a9X:8]
				mw3C5qDIYzLPhd0nfoWF9R = '#'+mw3C5qDIYzLPhd0nfoWF9R[VTadWjBloMwXO2CH9GDK6FR:]
				LowSfEj9cH = LowSfEj9cH[9:]
			elif len(d7EMhZOtDzH)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				LowSfEj9cH = d7EMhZOtDzH[P2Fgh6TCOWoaHjkqBcQnvRNXe]
				mw3C5qDIYzLPhd0nfoWF9R = rh3nL2TIqZOHXSdlkAGxs
			elif len(h9hgNYp10iOJqfbREwZkxt)>P2Fgh6TCOWoaHjkqBcQnvRNXe:
				LowSfEj9cH = h9hgNYp10iOJqfbREwZkxt[P2Fgh6TCOWoaHjkqBcQnvRNXe]
				EfnrXQsIGFMLJqiaHAxoCp6P = w2qb6lf5EM
				Mrt06eZIaqJxuwSG = bk1n4dOsGYrM8xL6[fX1Zt53MrQqxKhAbJ69nysYU2l]
			elif len(zziA04rRfTjHUBvCSb)>1: LowSfEj9cH = zziA04rRfTjHUBvCSb[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			elif len(WW7g9huYNxGQqmkCejraofZLDswFp6)>1: LowSfEj9cH = WW7g9huYNxGQqmkCejraofZLDswFp6[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			elif len(ZCuew1iORtoGhFJQ8sU0cSgTVk)>1: LowSfEj9cH = ZCuew1iORtoGhFJQ8sU0cSgTVk[P2Fgh6TCOWoaHjkqBcQnvRNXe]
			if LowSfEj9cH:
				iBsfupg3Tr69U5G71AcnvLlXkW8oFe = pJLXEo3At68C41w2mThrN+rqGM4b2pnaD9wNXeiYfEmQx
				LowSfEj9cH = dz6mk9cAg0XbMFqJ28yZ.get_display(LowSfEj9cH)
				QaihwOob8U5MYcl6xTmnesIJgN,SvLefAjZbGl943BdIicQhVw = kUbZhHmOsdVwWBxPCGt75f1FL.textsize(LowSfEj9cH,font=cJLewjtAFp5soHvEkq41)
				if EfnrXQsIGFMLJqiaHAxoCp6P: Mrt06eZIaqJxuwSG -= QaihwOob8U5MYcl6xTmnesIJgN
				v2UO9r3w7JXfRb = PqV9ZBWR6n4oiIJw+Mrt06eZIaqJxuwSG
				kUbZhHmOsdVwWBxPCGt75f1FL.text((v2UO9r3w7JXfRb,iBsfupg3Tr69U5G71AcnvLlXkW8oFe),LowSfEj9cH,font=cJLewjtAFp5soHvEkq41,fill=mw3C5qDIYzLPhd0nfoWF9R)
				if eQSDTK4aJOxHMgE=='menu_item': kUbZhHmOsdVwWBxPCGt75f1FL.text((v2UO9r3w7JXfRb+P2Fgh6TCOWoaHjkqBcQnvRNXe,iBsfupg3Tr69U5G71AcnvLlXkW8oFe+P2Fgh6TCOWoaHjkqBcQnvRNXe),LowSfEj9cH,font=cJLewjtAFp5soHvEkq41,fill=mw3C5qDIYzLPhd0nfoWF9R)
				if not EfnrXQsIGFMLJqiaHAxoCp6P: Mrt06eZIaqJxuwSG += QaihwOob8U5MYcl6xTmnesIJgN
				if iBsfupg3Tr69U5G71AcnvLlXkW8oFe>KOlNsgUArc9MjFuhySEwvJZ1a+I1DP2jhUwNAHECWMl3Rzfvnb: break
	if eQSDTK4aJOxHMgE=='menu_item':
		RRC58ieE1ULcnobQ0WBqY3HKu = HgCPAwtRnd.copy()
		L8Wkv5KCSoq.sleep(0.05)
		RRC58ieE1ULcnobQ0WBqY3HKu.paste(a2RhMCENpVG57,(ZVNvqy4iF1a9X,ZVNvqy4iF1a9X),mask=spJlSmzGjk5dogT)
	else: RRC58ieE1ULcnobQ0WBqY3HKu = spJlSmzGjk5dogT
	if BB7oCRfQNSYj5qDhTUevV: vhnwFHMbyPIYW3o9r7kVD6A1ZQS4 = vhnwFHMbyPIYW3o9r7kVD6A1ZQS4.decode(Im5KSGZYBpRvdMVsbuXg)
	try: RRC58ieE1ULcnobQ0WBqY3HKu.save(vhnwFHMbyPIYW3o9r7kVD6A1ZQS4)
	except UnicodeError:
		if BB7oCRfQNSYj5qDhTUevV:
			vhnwFHMbyPIYW3o9r7kVD6A1ZQS4 = vhnwFHMbyPIYW3o9r7kVD6A1ZQS4.encode(Im5KSGZYBpRvdMVsbuXg)
			RRC58ieE1ULcnobQ0WBqY3HKu.save(vhnwFHMbyPIYW3o9r7kVD6A1ZQS4)
	return kFjDH0WgvEXq8hQpYJz2eNP3t7UTcK
def oZyWxlPOIzDQFE2pcCvUkH9a(U2URK65mPkuNMcd0oCpv,cJLewjtAFp5soHvEkq41,lbXBFaLnVhjwWSRD6,yfRBu5PCwspTXEvxkacr2iIh9,xQKrJ8i7DZO36LEh,oC7ug4l3XNe0sTnSGEQqLvyxOJrbRh):
	q3kmy2EZC1JD6xO,atrY35FhkAIzp06GK41xdlO,z8rnX0qLvoiT6sDVSwbyp95kO1 = CJlTSEpZsWb0QHg5w,ZVNvqy4iF1a9X,15000
	lbXBFaLnVhjwWSRD6 = lbXBFaLnVhjwWSRD6.replace('[COLOR ','[COLOR:::')
	O8qFXgImyQW = xQKrJ8i7DZO36LEh-yfRBu5PCwspTXEvxkacr2iIh9*VTadWjBloMwXO2CH9GDK6FR
	for jTANthfMm6y87i0Pb in lbXBFaLnVhjwWSRD6.splitlines():
		atrY35FhkAIzp06GK41xdlO += oC7ug4l3XNe0sTnSGEQqLvyxOJrbRh
		dkD5nPlwShzMNFXGxC26EmqLJb,bEC6SYvOKlwGR0LUdkM2j4qV = ZVNvqy4iF1a9X,CJlTSEpZsWb0QHg5w
		for Vx2fXgAHebr68tDaId1QUMvzTc in jTANthfMm6y87i0Pb.split(YvOQBzaTAscXR9ql):
			IC0gaNwZHeEMT54b3yh7Ati8 = IdBf0o3FO9eSrsa(YvOQBzaTAscXR9ql+Vx2fXgAHebr68tDaId1QUMvzTc)
			KzjMVUFukqdRB9pG,q9eE4jyd5a6bLogmu = U2URK65mPkuNMcd0oCpv.textsize(IC0gaNwZHeEMT54b3yh7Ati8,font=cJLewjtAFp5soHvEkq41)
			if dkD5nPlwShzMNFXGxC26EmqLJb+KzjMVUFukqdRB9pG<O8qFXgImyQW:
				if not bEC6SYvOKlwGR0LUdkM2j4qV: bEC6SYvOKlwGR0LUdkM2j4qV += Vx2fXgAHebr68tDaId1QUMvzTc
				else: bEC6SYvOKlwGR0LUdkM2j4qV += YvOQBzaTAscXR9ql+Vx2fXgAHebr68tDaId1QUMvzTc
				dkD5nPlwShzMNFXGxC26EmqLJb += KzjMVUFukqdRB9pG
			else:
				if KzjMVUFukqdRB9pG<O8qFXgImyQW:
					bEC6SYvOKlwGR0LUdkM2j4qV += '\n '+Vx2fXgAHebr68tDaId1QUMvzTc
					atrY35FhkAIzp06GK41xdlO += oC7ug4l3XNe0sTnSGEQqLvyxOJrbRh
					dkD5nPlwShzMNFXGxC26EmqLJb = KzjMVUFukqdRB9pG
				else:
					while KzjMVUFukqdRB9pG>O8qFXgImyQW:
						for X0Rq3ISdwTJsnWGM7Kmc4 in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,len(YvOQBzaTAscXR9ql+Vx2fXgAHebr68tDaId1QUMvzTc),P2Fgh6TCOWoaHjkqBcQnvRNXe):
							wwQYdXxFUPZo2gfkrOMT8Bi9nJNcvu = YvOQBzaTAscXR9ql+Vx2fXgAHebr68tDaId1QUMvzTc[:X0Rq3ISdwTJsnWGM7Kmc4]
							B8Qg6Kj5IpSVXOdHn4o2 = Vx2fXgAHebr68tDaId1QUMvzTc[X0Rq3ISdwTJsnWGM7Kmc4:]
							oUuz6MI8ikQESaRcBtm5fDve0PAXj = IdBf0o3FO9eSrsa(wwQYdXxFUPZo2gfkrOMT8Bi9nJNcvu)
							mCXqSrEbpANIZzPotj9Tn528iwlJ6F,yysOvwojZ46 = U2URK65mPkuNMcd0oCpv.textsize(oUuz6MI8ikQESaRcBtm5fDve0PAXj,font=cJLewjtAFp5soHvEkq41)
							if dkD5nPlwShzMNFXGxC26EmqLJb+mCXqSrEbpANIZzPotj9Tn528iwlJ6F>O8qFXgImyQW:
								m1z8LsDa5UyS30fkTF2Y = KzjMVUFukqdRB9pG-mCXqSrEbpANIZzPotj9Tn528iwlJ6F
								bEC6SYvOKlwGR0LUdkM2j4qV += wwQYdXxFUPZo2gfkrOMT8Bi9nJNcvu+rJ9cgWz4FU
								atrY35FhkAIzp06GK41xdlO += oC7ug4l3XNe0sTnSGEQqLvyxOJrbRh
								KzjMVUFukqdRB9pG = m1z8LsDa5UyS30fkTF2Y
								if m1z8LsDa5UyS30fkTF2Y>O8qFXgImyQW:
									dkD5nPlwShzMNFXGxC26EmqLJb = ZVNvqy4iF1a9X
									Vx2fXgAHebr68tDaId1QUMvzTc = B8Qg6Kj5IpSVXOdHn4o2
								else:
									dkD5nPlwShzMNFXGxC26EmqLJb = m1z8LsDa5UyS30fkTF2Y
									bEC6SYvOKlwGR0LUdkM2j4qV += B8Qg6Kj5IpSVXOdHn4o2
								break
				if atrY35FhkAIzp06GK41xdlO>z8rnX0qLvoiT6sDVSwbyp95kO1: break
		q3kmy2EZC1JD6xO += rJ9cgWz4FU+bEC6SYvOKlwGR0LUdkM2j4qV
		if atrY35FhkAIzp06GK41xdlO>z8rnX0qLvoiT6sDVSwbyp95kO1: break
	q3kmy2EZC1JD6xO = q3kmy2EZC1JD6xO[P2Fgh6TCOWoaHjkqBcQnvRNXe:]
	q3kmy2EZC1JD6xO = q3kmy2EZC1JD6xO.replace('[COLOR:::','[COLOR ')
	return q3kmy2EZC1JD6xO
def IdBf0o3FO9eSrsa(Vx2fXgAHebr68tDaId1QUMvzTc):
	if '[' in Vx2fXgAHebr68tDaId1QUMvzTc and ']' in Vx2fXgAHebr68tDaId1QUMvzTc:
		llwSCg9uzVf1D = [oOQaRxBXyJ5jVnZ,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		dtClWHkU9n15aEN8xgcTSQVIYsXr = Zy2l0g8QU5vqefaTrsw.findall('\[COLOR .*?\]',Vx2fXgAHebr68tDaId1QUMvzTc,Zy2l0g8QU5vqefaTrsw.DOTALL)
		P05yF2MuUznlDqgVxHceZvINjAoBX = Zy2l0g8QU5vqefaTrsw.findall('\[COLOR:::.*?\]',Vx2fXgAHebr68tDaId1QUMvzTc,Zy2l0g8QU5vqefaTrsw.DOTALL)
		Uq4FaxybpCwLYec1udzMHEirIVKZOg = llwSCg9uzVf1D+dtClWHkU9n15aEN8xgcTSQVIYsXr+P05yF2MuUznlDqgVxHceZvINjAoBX
		for PlLvX0ginUyf in Uq4FaxybpCwLYec1udzMHEirIVKZOg: Vx2fXgAHebr68tDaId1QUMvzTc = Vx2fXgAHebr68tDaId1QUMvzTc.replace(PlLvX0ginUyf,CJlTSEpZsWb0QHg5w)
	return Vx2fXgAHebr68tDaId1QUMvzTc
def uoT81mNUnhi7MYwCRDfeQA(FMxeyLvnzabpJhCXgS6T):
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(rJ9cgWz4FU,'_sss__newline_')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[RTL]','_sss__linertl_')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[LEFT]','_sss__lineleft_')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[RIGHT]','_sss__lineright_')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[CENTER]','_sss__linecenter_')
	FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace(oOQaRxBXyJ5jVnZ,'_sss__endcolor_')
	Tg3mYkdIFLPXW5ySe = Zy2l0g8QU5vqefaTrsw.findall('\[COLOR (.*?)\]',FMxeyLvnzabpJhCXgS6T,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for aTjRhtp0H6 in Tg3mYkdIFLPXW5ySe: FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.replace('[COLOR '+aTjRhtp0H6+']','_sss__newcolor'+aTjRhtp0H6+'_')
	return FMxeyLvnzabpJhCXgS6T
def c3mPLX9b6oqze0UCJEartIuds(qM86psOY91zCKXDf,idaKcvOmbRrkW1CtHhZfeAJQV4D=CJlTSEpZsWb0QHg5w):
	if not idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel('ListItem.Label')
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).strip(YvOQBzaTAscXR9ql)
	if qM86psOY91zCKXDf: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace('[COLOR ',CJlTSEpZsWb0QHg5w).replace(']',CJlTSEpZsWb0QHg5w)
	else: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(Ym6q5M4TocDaA013RjFQ,CJlTSEpZsWb0QHg5w).replace(Dj62UpP5MrbTkJqhRa,CJlTSEpZsWb0QHg5w).replace(ZHWTM8prgq7xyI9026PfEOJ,CJlTSEpZsWb0QHg5w).replace(RXSxl4a8gwkhnAtVdj9OeP,CJlTSEpZsWb0QHg5w)
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).replace(rScptJWVdgzQGR1E3LZ9byC,CJlTSEpZsWb0QHg5w).replace(oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w)
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(s6rxOhWUy0bXDdQMJleNmu,CJlTSEpZsWb0QHg5w).replace(HCgURFmf8NvkYs2wnX,CJlTSEpZsWb0QHg5w)
	mSgUBlqXThA3vn = Zy2l0g8QU5vqefaTrsw.findall('\d\d:\d\d ',idaKcvOmbRrkW1CtHhZfeAJQV4D,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if mSgUBlqXThA3vn: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.split(mSgUBlqXThA3vn[ZVNvqy4iF1a9X],P2Fgh6TCOWoaHjkqBcQnvRNXe)[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	if not idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = 'Main Menu'
	return idaKcvOmbRrkW1CtHhZfeAJQV4D
def vvcCMPFyJDZ48oH6lTzma0xr9edOUK(WEbjm0dNDHoz):
	mpi20w4fZ5H = CJlTSEpZsWb0QHg5w.join(X0Rq3ISdwTJsnWGM7Kmc4 for X0Rq3ISdwTJsnWGM7Kmc4 in WEbjm0dNDHoz if X0Rq3ISdwTJsnWGM7Kmc4 not in '\/":*?<>|'+jWsfaIrEp2PiO0q9ygBvn4L)
	return mpi20w4fZ5H
def EEa4ITHuLq82tv7Yx9ZzOQVD(ZraEU3jpk2ns6q0ztPgvhioAX):
	xDumKC4LTehPjr7UXfAVB5Zazv = Zy2l0g8QU5vqefaTrsw.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",ZraEU3jpk2ns6q0ztPgvhioAX,Zy2l0g8QU5vqefaTrsw.S)
	if xDumKC4LTehPjr7UXfAVB5Zazv:
		wLtg7rFzvCnkeQKH931jINcTlXPM,EEXmsq0pITdzeuLZAQo = xDumKC4LTehPjr7UXfAVB5Zazv[ZVNvqy4iF1a9X]
		wLtg7rFzvCnkeQKH931jINcTlXPM = Zy2l0g8QU5vqefaTrsw.findall("=[\r\n\s\t]+'(.*?)';", wLtg7rFzvCnkeQKH931jINcTlXPM, Zy2l0g8QU5vqefaTrsw.S)[ZVNvqy4iF1a9X]
		if wLtg7rFzvCnkeQKH931jINcTlXPM and EEXmsq0pITdzeuLZAQo:
			VYBUnvgxNh5S7syea6tQf84GZzoqKM = wLtg7rFzvCnkeQKH931jINcTlXPM.replace("'",CJlTSEpZsWb0QHg5w).replace("+",CJlTSEpZsWb0QHg5w).replace("\n",CJlTSEpZsWb0QHg5w).replace("\r",CJlTSEpZsWb0QHg5w)
			SnHXgJtmVCrd1wDbqUINzP0 = VYBUnvgxNh5S7syea6tQf84GZzoqKM.split('.')
			ZraEU3jpk2ns6q0ztPgvhioAX = CJlTSEpZsWb0QHg5w
			for R7VKv2j6Eetsl3Qd8 in SnHXgJtmVCrd1wDbqUINzP0:
				j20ioWmG1aCRJIXb = qqth6cAFkaRowLlUeMng.b64decode(R7VKv2j6Eetsl3Qd8+'==').decode(Im5KSGZYBpRvdMVsbuXg)
				WEOcY6myDxG2so7ZAgj3C8BN = Zy2l0g8QU5vqefaTrsw.findall('\d+', j20ioWmG1aCRJIXb, Zy2l0g8QU5vqefaTrsw.S)
				if WEOcY6myDxG2so7ZAgj3C8BN:
					XfJEK4a2ZOdzypC = int(WEOcY6myDxG2so7ZAgj3C8BN[ZVNvqy4iF1a9X])
					XfJEK4a2ZOdzypC += int(EEXmsq0pITdzeuLZAQo)
					ZraEU3jpk2ns6q0ztPgvhioAX = ZraEU3jpk2ns6q0ztPgvhioAX + chr(XfJEK4a2ZOdzypC)
			if A7Z6OVh20eCEUx: ZraEU3jpk2ns6q0ztPgvhioAX = ZraEU3jpk2ns6q0ztPgvhioAX.encode('iso-8859-1').decode(Im5KSGZYBpRvdMVsbuXg)
	return ZraEU3jpk2ns6q0ztPgvhioAX
def nSDx0eZqomMks(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh,oRZnA7lqNIdGiDhY,m9wgSl1oUVRd,cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui):
	E0Ou415QJc = int(oRZnA7lqNIdGiDhY%10)
	wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO = int(oRZnA7lqNIdGiDhY/10)
	fSn7ArdbOmju = kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,CJlTSEpZsWb0QHg5w,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
	gZ0wJBN9VMTikRerpyEY4XmGq = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.status.menuscache')
	if not gZ0wJBN9VMTikRerpyEY4XmGq: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.status.menuscache','AUTO')
	QgwJd8Sfs07zyqlmiKWRrCP9Dn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.status.refresh')
	r9u8w2A3nbVvRpc1B = qmi8sS9rIkdBzjfu43UpPeVJh0oCAn(m9wgSl1oUVRd)
	OakuY0NSWJl = [ZVNvqy4iF1a9X,15,17,19,26,34,50,53]
	ZcBhyNjCkgwPOFEMmHGx6b = wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO not in OakuY0NSWJl
	oi9XZ3cCQalLK8sIOPx = wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO in [23,28,71,72]
	zU5MPsC0ql6E = oRZnA7lqNIdGiDhY in [265,270]
	FqLrpUgxsS = (ZcBhyNjCkgwPOFEMmHGx6b or oi9XZ3cCQalLK8sIOPx) and not zU5MPsC0ql6E
	UzWF2vsti4Oaj = (QgwJd8Sfs07zyqlmiKWRrCP9Dn or not QQa9t5k6BLqflRNr) and QgwJd8Sfs07zyqlmiKWRrCP9Dn not in ['REFRESH_CACHE']+d4kl1qU6GQT9tmfeNZMXvYJwDbr8
	iPH9eK4185OJNagSqvh63rZp7B2s = 'type=' in QgwJd8Sfs07zyqlmiKWRrCP9Dn
	StVi6znbrA = oRZnA7lqNIdGiDhY in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	HYGiJ9pfmMTnIb4L7tX = E0Ou415QJc==9 or oRZnA7lqNIdGiDhY in [145,516,523,45]
	MJxHWY7CTiQdAqLNtm86V3RPBZD = not StVi6znbrA
	RRrMT7jgNXSwBidADluVpJ2ZWxkyU = not HYGiJ9pfmMTnIb4L7tX
	YYk2jTq8malFzSC9 = r9u8w2A3nbVvRpc1B in [CJlTSEpZsWb0QHg5w,'..']
	Dtm1JZlAOjqQ56nuXELN = YYk2jTq8malFzSC9 or MJxHWY7CTiQdAqLNtm86V3RPBZD
	Kkc8edsTRaQx = YYk2jTq8malFzSC9 or RRrMT7jgNXSwBidADluVpJ2ZWxkyU or iPH9eK4185OJNagSqvh63rZp7B2s
	YHLPKqcXkwZevpxQ = oRZnA7lqNIdGiDhY not in [260,261,265,270,330,536,537,538,540,1010,1101,1103]
	if gZ0wJBN9VMTikRerpyEY4XmGq=='STOP': cUPKza0kZ8JxXIydEnGSjHpgt = HYGiJ9pfmMTnIb4L7tX or StVi6znbrA
	else: cUPKza0kZ8JxXIydEnGSjHpgt = w2qb6lf5EM
	ft7BjUDFdebKQgZpMhAWuY = wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO in [74,75,108]
	QykldhnxAFTvUZ3uaXNrjC7e = oRZnA7lqNIdGiDhY in [280,720]
	O9mhCpnoLecP5VM34N2QlAW = not ft7BjUDFdebKQgZpMhAWuY and not QykldhnxAFTvUZ3uaXNrjC7e
	hkmU7dLqaVgwj0 = Dtm1JZlAOjqQ56nuXELN and Kkc8edsTRaQx and YHLPKqcXkwZevpxQ and cUPKza0kZ8JxXIydEnGSjHpgt and O9mhCpnoLecP5VM34N2QlAW
	f7f2iZXsNUnkJ9xVtYoL = YHLPKqcXkwZevpxQ and cUPKza0kZ8JxXIydEnGSjHpgt and O9mhCpnoLecP5VM34N2QlAW
	jY6EJPO54qW1o92ugtBKcUwrn = f7f2iZXsNUnkJ9xVtYoL
	jjnDkboXNHUhf = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.provider')
	enRHwuOX2qxc4pQyTFAm5S6adtG = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.code')
	N6VvypcIiB2HXb = VJZIMkUN5siqB21Pf
	if UzWF2vsti4Oaj and hkmU7dLqaVgwj0:
		Db3QUifAKVh1l9mj = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,'list','MENUS_CACHE_'+jjnDkboXNHUhf+'_'+enRHwuOX2qxc4pQyTFAm5S6adtG,fSn7ArdbOmju)
		if Db3QUifAKVh1l9mj:
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(CJlTSEpZsWb0QHg5w,'.\tMENUS_CACHE_'+jjnDkboXNHUhf+'_'+enRHwuOX2qxc4pQyTFAm5S6adtG+'   Loading menu from cache')
			if iPH9eK4185OJNagSqvh63rZp7B2s:
				mJSZVtxDOFb = []
				from p7gmr5fCJu import wZ7dtoKTGz102g
				from z2BQ0dUKrP import C2Ula90Z1dj3NhDMKR7YH8,wkEAKGHojXLfWJU3dvy7QCV4T
				fwasbv17MJUXRH = wZ7dtoKTGz102g
				CJMbgEUnL047di = C2Ula90Z1dj3NhDMKR7YH8()
				tuR0dAcwe1973pLEDTHnvWBbIVCQ = QgwJd8Sfs07zyqlmiKWRrCP9Dn
				pODPjX63gfx,qqjnPiU9gHuSx,ppNtmefScAB6REx0ioOM21W,ebVNuIfsYZxzOwPDdE1T8J,BzAWMpPxZJ7NlVajhqLOCwFI9,s6UzMufaWb0DAh,uDzkFrRpbQag3nOZeIUAiPcdCHJjh,BA8VcZLWDEmlFdTIX9HoC2,m8RWbFEIpzewuSGgVrydXC = Ggp2PFN048WD7rRkC6Uqit(tuR0dAcwe1973pLEDTHnvWBbIVCQ)
				KgEc2jeQkPuHbGZSzI5XhJlpvCRF = pODPjX63gfx,qqjnPiU9gHuSx,ppNtmefScAB6REx0ioOM21W,ebVNuIfsYZxzOwPDdE1T8J,BzAWMpPxZJ7NlVajhqLOCwFI9,s6UzMufaWb0DAh,uDzkFrRpbQag3nOZeIUAiPcdCHJjh,CJlTSEpZsWb0QHg5w,m8RWbFEIpzewuSGgVrydXC
				for Bd0QzaRXxCLWPefE2 in Db3QUifAKVh1l9mj:
					e7ef1KxjltV = Bd0QzaRXxCLWPefE2['menuItem']
					if e7ef1KxjltV==KgEc2jeQkPuHbGZSzI5XhJlpvCRF or Bd0QzaRXxCLWPefE2['mode'] in [265,270]:
						Bd0QzaRXxCLWPefE2 = iQdPpwFnKG9IMWJmoO1U(e7ef1KxjltV,fwasbv17MJUXRH,CJMbgEUnL047di)
						if Bd0QzaRXxCLWPefE2['favorites']:
							cZFNDlfiWq = wkEAKGHojXLfWJU3dvy7QCV4T(CJMbgEUnL047di,e7ef1KxjltV,Bd0QzaRXxCLWPefE2['newpath'])
							Bd0QzaRXxCLWPefE2['context_menu'] = cZFNDlfiWq+Bd0QzaRXxCLWPefE2['context_menu']
					mJSZVtxDOFb.append(Bd0QzaRXxCLWPefE2)
				ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.status.refresh',CJlTSEpZsWb0QHg5w)
				if kcxAmftieK56PE9TqbDHdSrF8=='folder': JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,'MENUS_CACHE_'+jjnDkboXNHUhf+'_'+enRHwuOX2qxc4pQyTFAm5S6adtG,fSn7ArdbOmju,mJSZVtxDOFb,DRmUs7l1O4xLeZYzGITXk)
			else: mJSZVtxDOFb = Db3QUifAKVh1l9mj
			if kcxAmftieK56PE9TqbDHdSrF8=='folder' and r9u8w2A3nbVvRpc1B!='..' and FqLrpUgxsS: HDWalJw09McEVi7mYBgSP()
			N6VvypcIiB2HXb = h7h5jOlyrznxHePifwWbCvoaDQZA(fSn7ArdbOmju,mJSZVtxDOFb,cn0XyId7MkTCE1RifFhwQDN,k1JMeFxNh68vZVuPndU7ap2bR,q7qaPLG596OS3RsfBui)
	elif kcxAmftieK56PE9TqbDHdSrF8=='folder' and QgwJd8Sfs07zyqlmiKWRrCP9Dn not in ['REFRESH_CACHE']+d4kl1qU6GQT9tmfeNZMXvYJwDbr8 and f7f2iZXsNUnkJ9xVtYoL:
		oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'MENUS_CACHE_'+jjnDkboXNHUhf+'_'+enRHwuOX2qxc4pQyTFAm5S6adtG,fSn7ArdbOmju)
	return N6VvypcIiB2HXb,QgwJd8Sfs07zyqlmiKWRrCP9Dn,fSn7ArdbOmju,r9u8w2A3nbVvRpc1B,FqLrpUgxsS,jY6EJPO54qW1o92ugtBKcUwrn,jjnDkboXNHUhf,enRHwuOX2qxc4pQyTFAm5S6adtG
def M4g7Ho2s8EhVxbyN1d0n(kcxAmftieK56PE9TqbDHdSrF8,kuiZt5zMdvVJyC4LqwGDX,otaunYGVIJ2jX8HsKm7ecR0bAh4,n3dz9vetbZKIVYm78,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh):
	oRZnA7lqNIdGiDhY = int(n3dz9vetbZKIVYm78)
	wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO = int(oRZnA7lqNIdGiDhY//10)
	if   wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==ZVNvqy4iF1a9X:  from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==P2Fgh6TCOWoaHjkqBcQnvRNXe:  from AAvutxbwq9 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==VTadWjBloMwXO2CH9GDK6FR:  from jYGOKwRDuV 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==D9yBM7wPFLz:  from OtDa8Ks7j6 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==P3cpaLN2sH:  from PaLAEs3vhU 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,GOF25jkXb1DnaB4vhL9)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==GGsP9SDod4iUBm6kNMfLw:  from Ea1UsVNk0u 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==6:  from un9ZWjDp3F 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==7:  from PMGCT1ry9N 			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==8:  from LLMe7oWdwj 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==9:  from V0sUqye5m1		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==10: from jU4XwEi6mt 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==11: from w8pxZIi0LV 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==12: from lb8y2mRT1O 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==13: from LozcH5xSi2		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==14: from pBMYifbqJA 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9,kuiZt5zMdvVJyC4LqwGDX,t4zynV13ZoPe)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==15: from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==16: from StVi6znbrA		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==17: from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==18: from st2WH4JITp		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==19: from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==20: from vvY7POWtsG		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==21: from R5XdFTfCye	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==22: from yqucJEwt9O		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==23: from Da6LhPonbt			import E2yVTSwA9QzkxUNsHKPBb81G; SD0TxMRXiep4cjPBsnzI = E2yVTSwA9QzkxUNsHKPBb81G(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==24: from fMhIVs8A5o 			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==25: from LCqVJ8tl0O 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==26: from p7gmr5fCJu 			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==27: from z2BQ0dUKrP		import E2yVTSwA9QzkxUNsHKPBb81G; SD0TxMRXiep4cjPBsnzI = E2yVTSwA9QzkxUNsHKPBb81G(oRZnA7lqNIdGiDhY,QQa9t5k6BLqflRNr)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==28: from Da6LhPonbt			import E2yVTSwA9QzkxUNsHKPBb81G; SD0TxMRXiep4cjPBsnzI = E2yVTSwA9QzkxUNsHKPBb81G(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==29: from HWkRbNjSlz	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==30: from uq56mLpixQ		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==31: from HvZyqG6mw3		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==32: from O1e3yd5sri		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==33: from OXpy1BlZPe		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==34: from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==35: from KRtOEird86		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==36: from PPpYRBirye			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==37: from rJPGnWcRkF			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==38: from up1VAmNE29 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==39: from nYOv7ZqUTm		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==40: from UaYmNHehiZ	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==41: from UaYmNHehiZ	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==42: from JAZmdeQUG1			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==43: from MVNu3jLwfF			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==44: from Zc8dqj9vXN		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==45: from TxJmS0bOEY		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==46: from IPtNXUHTKY			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==47: from yCutDpP26Y		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==48: from LLfe8VFlaY		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==49: from xxDu24R6Zl		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==50: from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==51: from Adj6mLvDqc 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==52: from Adj6mLvDqc 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==53: from p7gmr5fCJu 			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==54: from KxIcVHk2jg	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,GOF25jkXb1DnaB4vhL9)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==55: from nD5CrOKphe 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==56: from ssyvixmErW		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==57: from EsAg37oUWu		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==58: from Nue7J04rw9		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==59: from jcyOMs9vF8		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==60: from I2p3Vsyoxn			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==61: from JKXc9nTNLq			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==62: from C5giu860eU		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==63: from RRbldB0kun	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==64: from Uw6QLFH1Vs			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==65: from xLo4rRMKA7			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==66: from pMyZescFv0			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==67: from BBLdeRq0m6		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==68: from Oqnu9wWgj4		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==69: from UkgWsu2NXf		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==70: from oJPQSp7stv			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==71: from vQnI182HJr			import E2yVTSwA9QzkxUNsHKPBb81G; SD0TxMRXiep4cjPBsnzI = E2yVTSwA9QzkxUNsHKPBb81G(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==72: from vQnI182HJr			import E2yVTSwA9QzkxUNsHKPBb81G; SD0TxMRXiep4cjPBsnzI = E2yVTSwA9QzkxUNsHKPBb81G(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,kcxAmftieK56PE9TqbDHdSrF8,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==73: from lgWhXue6US	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==74: from SSmqvW7VfL		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==75: from SSmqvW7VfL		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==76: from StVi6znbrA		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==77: from wKtk0pBnzE 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==78: from SSicMeh0Kq 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==79: from BgOA7CehMY 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==80: from ssMROAFa4r 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==81: from mmK1S6acjg 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==82: from ZZBuKcinpY		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,GOF25jkXb1DnaB4vhL9,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==83: from iGF8JxXP3H		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==84: from qpxCfU8kW0		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==85: from ccraUs1HBk		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==86: from w4cFd2lNLr		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==87: from JNWU8HlCdk			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==88: from E95EBVzPex			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==89: from OpgkXNqSf3		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==90: from pzYJTGmx5U	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==91: from I8d2LJOfuH		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==92: from Hk5iJWYItf		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==93: from V32U0Bs6Pc		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==94: from ysVbrgY2T0			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==95: from jl0f3PNMDJ			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==96: from jhG13yFHMx		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==97: from cBQLUZ4fs3		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==98: from tKYSI6VxUi		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==99: from KB0hFNjHUz		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==100: from A3AJdilj7s		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==101: from GKZzPyrb45	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==102: from tAoP1fdO67 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==103: from Db2QqPEA9H	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==104: from TTtYMwLRpd		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==105: from ymjQYBHaUe			import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==106: from LHZmQ4nOh7		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==107: from jax5lmANT7		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==108: from SSmqvW7VfL		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==109: from wzxh4ZjFn8 	import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	elif wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==110: from p7gmr5fCJu 		import hH3sRBSFAr	; SD0TxMRXiep4cjPBsnzI = hH3sRBSFAr(oRZnA7lqNIdGiDhY,otaunYGVIJ2jX8HsKm7ecR0bAh4,AyKma12GRYnziLV7EWIjUM)
	else: SD0TxMRXiep4cjPBsnzI = None
	return SD0TxMRXiep4cjPBsnzI
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'ALARAB'
headers = {'User-Agent':CJlTSEpZsWb0QHg5w}
kL0nT7NpZdKVD3jM2OHB = '_KLA_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
def hH3sRBSFAr(mode,url,text):
	if   mode==10: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==11: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	elif mode==12: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==13: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==14: SD0TxMRXiep4cjPBsnzI = GWrYbnkfSBcuX8jZILoiaemMs()
	elif mode==15: SD0TxMRXiep4cjPBsnzI = LLeG4bQaNOwVCTyjnWmuxivXdhEpI()
	elif mode==16: SD0TxMRXiep4cjPBsnzI = nzDmZbH8vkxLo4Uq()
	elif mode==19: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,19,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'آخر الإضافات',CJlTSEpZsWb0QHg5w,14)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان',CJlTSEpZsWb0QHg5w,15)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'ALARAB-MENU-1st')
	s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('id="nav-slider"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	TuygaoCiIlkDLbUhRYj = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',TuygaoCiIlkDLbUhRYj,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
		title = title.strip(YvOQBzaTAscXR9ql)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="navbar"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	zE8URkuN932 = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',zE8URkuN932,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,11)
	return bGIVq1CQTjmosZg
def LLeG4bQaNOwVCTyjnWmuxivXdhEpI():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'جميع المسلسلات العربية',V4kF6EQiwo+'/view-8/مسلسلات-عربية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات السنة الأخيرة',CJlTSEpZsWb0QHg5w,16)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان الأخيرة 1',V4kF6EQiwo+'/view-8/مسلسلات-رمضان-2022',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان الأخيرة 2',V4kF6EQiwo+'/view-8/مسلسلات-رمضان-2023',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2023',V4kF6EQiwo+'/ramadan2023/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2022',V4kF6EQiwo+'/ramadan2022/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2021',V4kF6EQiwo+'/ramadan2021/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2020',V4kF6EQiwo+'/ramadan2020/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2019',V4kF6EQiwo+'/ramadan2019/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2018',V4kF6EQiwo+'/ramadan2018/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2017',V4kF6EQiwo+'/ramadan2017/مصرية',11)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات رمضان 2016',V4kF6EQiwo+'/ramadan2016/مصرية',11)
	return
def GWrYbnkfSBcuX8jZILoiaemMs():
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,True,'ALARAB-LATEST-1st')
	s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('heading-top(.*?)div class=',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]+s67485upzYNMS3PqDelkrdfo[1]
	items=Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		url = V4kF6EQiwo + ZgsbN5iSL48t2IhVFnmy
		if 'series' in url: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,11,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,url,12,hzGKUP1XjAoeT79MJcDF)
	return
def nvHUf8mW6E4GSw5VFRXN(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,headers,True,True,'ALARAB-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('video-category(.*?)right_content',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	jXqW0t7CZSn2dshG8E1HrlUu = False
	items = Zy2l0g8QU5vqefaTrsw.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp,rrBu78NHhgxzta4ScCld = [],[]
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if title==CJlTSEpZsWb0QHg5w: title = ZgsbN5iSL48t2IhVFnmy.split('/')[-1].replace('-',YvOQBzaTAscXR9ql)
		Z9ZHlis43maAITJUwNQgS0on = Zy2l0g8QU5vqefaTrsw.findall('(\d+)',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if Z9ZHlis43maAITJUwNQgS0on: Z9ZHlis43maAITJUwNQgS0on = int(Z9ZHlis43maAITJUwNQgS0on[0])
		else: Z9ZHlis43maAITJUwNQgS0on = 0
		rrBu78NHhgxzta4ScCld.append([hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title,Z9ZHlis43maAITJUwNQgS0on])
	rrBu78NHhgxzta4ScCld = sorted(rrBu78NHhgxzta4ScCld, reverse=True, key=lambda key: key[3])
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title,Z9ZHlis43maAITJUwNQgS0on in rrBu78NHhgxzta4ScCld:
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo + ZgsbN5iSL48t2IhVFnmy
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',CJlTSEpZsWb0QHg5w)
		title = title.replace('عالية على العرب',CJlTSEpZsWb0QHg5w)
		title = title.replace('مشاهدة مباشرة',CJlTSEpZsWb0QHg5w)
		title = title.replace('اون لاين',CJlTSEpZsWb0QHg5w)
		title = title.replace('اونلاين',CJlTSEpZsWb0QHg5w)
		title = title.replace('بجودة عالية',CJlTSEpZsWb0QHg5w)
		title = title.replace('جودة عالية',CJlTSEpZsWb0QHg5w)
		title = title.replace('بدون تحميل',CJlTSEpZsWb0QHg5w)
		title = title.replace('على العرب',CJlTSEpZsWb0QHg5w)
		title = title.replace('مباشرة',CJlTSEpZsWb0QHg5w)
		title = title.strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		title = '_MOD_'+title
		II4x930lvTuVqekXBNCrMy = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ABK45TEMpciLnmIlYOafQJZ8t: II4x930lvTuVqekXBNCrMy = ABK45TEMpciLnmIlYOafQJZ8t[0]
		if II4x930lvTuVqekXBNCrMy not in wDkMP6jlz7XeN5Sp:
			wDkMP6jlz7XeN5Sp.append(II4x930lvTuVqekXBNCrMy)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,ZgsbN5iSL48t2IhVFnmy,13,hzGKUP1XjAoeT79MJcDF)
				jXqW0t7CZSn2dshG8E1HrlUu = True
			elif 'series' in ZgsbN5iSL48t2IhVFnmy:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,11,hzGKUP1XjAoeT79MJcDF)
				jXqW0t7CZSn2dshG8E1HrlUu = True
			else:
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,12,hzGKUP1XjAoeT79MJcDF)
				jXqW0t7CZSn2dshG8E1HrlUu = True
	if jXqW0t7CZSn2dshG8E1HrlUu:
		items = Zy2l0g8QU5vqefaTrsw.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,GOF25jkXb1DnaB4vhL9 in items:
			url = V4kF6EQiwo + ZgsbN5iSL48t2IhVFnmy
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+GOF25jkXb1DnaB4vhL9,url,11)
	return
def j9zTQsrVRx2(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,True,'ALARAB-EPISODES-1st')
	DzhMXqK6x3mVg9y = Zy2l0g8QU5vqefaTrsw.findall('href="(/series.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+DzhMXqK6x3mVg9y[0]
	SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7)
	return
def rHwfOZb3oSgJKi(url):
	MNXzjK3vV7D = []
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,url,CJlTSEpZsWb0QHg5w,headers,True,'ALARAB-PLAY-1st')
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('class="resp-iframe" src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7:
		BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('^(http.*?)(http.*?)$',BBwfuWGxUIrdCoc4ka7,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if Rp1g7OlotseGnf0NFmKk6rLxd:
			vhOcSIwNZ2TC8tEPR = Rp1g7OlotseGnf0NFmKk6rLxd[0][0]
			AWoLvnkUr5,s4G9qOhkrVKobSpdgfEXI37W8cwn = Rp1g7OlotseGnf0NFmKk6rLxd[0][1].rsplit('/',1)
			ysw7G3tqjo = AWoLvnkUr5+'?named=__watch'
			MNXzjK3vV7D.append(ysw7G3tqjo)
			Da7e1Ruo9G = vhOcSIwNZ2TC8tEPR+s4G9qOhkrVKobSpdgfEXI37W8cwn
		else:
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,False,'ALARAB-PLAY-2nd')
			BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('"src": "(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if BBwfuWGxUIrdCoc4ka7:
				BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]+'?named=__watch__m3u8'
				MNXzjK3vV7D.append(BBwfuWGxUIrdCoc4ka7)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('searchBox(.*?)<style>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if BBwfuWGxUIrdCoc4ka7:
			BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]+'?named=__watch'
			MNXzjK3vV7D.append(BBwfuWGxUIrdCoc4ka7)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def nzDmZbH8vkxLo4Uq():
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,True,'ALARAB-RAMADAN-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="content_sec"(.*?)id="left_content"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	zt5jx4amOCZ2r = Zy2l0g8QU5vqefaTrsw.findall('/ramadan([0-9]+)/',str(items),Zy2l0g8QU5vqefaTrsw.DOTALL)
	zt5jx4amOCZ2r = zt5jx4amOCZ2r[0]
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		url = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
		title = title.strip(YvOQBzaTAscXR9ql)+YvOQBzaTAscXR9ql+zt5jx4amOCZ2r
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,11)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo + "/q/" + QjfknOVHzZIUir
	SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	return
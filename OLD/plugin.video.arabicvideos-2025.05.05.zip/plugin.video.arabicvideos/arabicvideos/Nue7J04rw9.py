# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'SHAHIDNEWS'
kL0nT7NpZdKVD3jM2OHB = '_SHN_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['قنوات فضائية','فارسكو','Show more']
def hH3sRBSFAr(mode,url,text):
	if   mode==580: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==581: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==582: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==583: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url,text)
	elif mode==584: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==589: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHIDNEWS-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,589,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('/category.php">(.*?)"navslide-divider"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("'dropdown-menu'(.*?)</ul>",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for zE8URkuN932 in s67485upzYNMS3PqDelkrdfo: D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace(zE8URkuN932,CJlTSEpZsWb0QHg5w)
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,584)
	return
def jSpWoLZQRIsrw7MnH5KEbu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHIDNEWS-SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"caret"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('"presentation"','</ul>')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = [(CJlTSEpZsWb0QHg5w,D3D6TF50oUBtJlvijPMW8ys)]
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' فرز أو فلتر أو ترتيب '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		for VVgEIqZuc3GRbY,D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if VVgEIqZuc3GRbY: VVgEIqZuc3GRbY = VVgEIqZuc3GRbY+': '
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = VVgEIqZuc3GRbY+title
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,581)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"pm-category-subcats"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc:
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if len(items)<30:
			khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,581)
	if not hh2VPjs7dkR581KzENYigmpZxLyb and not KXu2RYg3Bc: nvHUf8mW6E4GSw5VFRXN(url)
	return
def nvHUf8mW6E4GSw5VFRXN(url,RjVAI6uzxFofm7qv=CJlTSEpZsWb0QHg5w):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHIDNEWS-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(data-echo=".*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"BlocksList"(.*?)"titleSectionCon"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="pm-grid"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="pm-related"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if not items: items = Zy2l0g8QU5vqefaTrsw.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not items: items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy).strip('/')
		if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
		if 'http' not in hzGKUP1XjAoeT79MJcDF: hzGKUP1XjAoeT79MJcDF = dmiXC1cB7MZlb+'/'+hzGKUP1XjAoeT79MJcDF.strip('/')
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,582,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and 'الحلقة' in title:
			title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,583,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif '/movseries/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,581,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,583,hzGKUP1XjAoeT79MJcDF)
	if RjVAI6uzxFofm7qv not in ['featured_movies','featured_series']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy=='#': continue
				ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,581)
		FlN4Pz89LTmtVxD = Zy2l0g8QU5vqefaTrsw.findall('showmore" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if FlN4Pz89LTmtVxD:
			ZgsbN5iSL48t2IhVFnmy = FlN4Pz89LTmtVxD[0]
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مشاهدة المزيد',ZgsbN5iSL48t2IhVFnmy,581)
	return
def j9zTQsrVRx2(url,FfC8TlgIzVh5aDePHELA3rwSo4uNRM):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHIDNEWS-EPISODES-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('nav-seasons"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	items = []
	eE2nkorRIbZ1y = False
	if hh2VPjs7dkR581KzENYigmpZxLyb and not FfC8TlgIzVh5aDePHELA3rwSo4uNRM:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for FfC8TlgIzVh5aDePHELA3rwSo4uNRM,title in items:
			FfC8TlgIzVh5aDePHELA3rwSo4uNRM = FfC8TlgIzVh5aDePHELA3rwSo4uNRM.strip('#')
			if len(items)>1: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,583,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,FfC8TlgIzVh5aDePHELA3rwSo4uNRM)
			else: eE2nkorRIbZ1y = True
	else: eE2nkorRIbZ1y = True
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('id="'+FfC8TlgIzVh5aDePHELA3rwSo4uNRM+'"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc and eE2nkorRIbZ1y:
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,582)
		else:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,582)
	return
def rHwfOZb3oSgJKi(url):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	MNXzjK3vV7D = []
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHAHIDNEWS-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"Playerholder".*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
	if ZgsbN5iSL48t2IhVFnmy and 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
	jqHzgxVeQbSlE = ZgsbN5iSL48t2IhVFnmy.split('hash=')[1]
	WyHwgmzU0GnP = jqHzgxVeQbSlE.split('__')
	aPBMHCOI7bJjXFL5rwnq2,Rp1g7OlotseGnf0NFmKk6rLxd,title = CJlTSEpZsWb0QHg5w,[],CJlTSEpZsWb0QHg5w
	for GePbnu93wr4BKdMqm in WyHwgmzU0GnP:
		R2w9xEN67Sl = ((4-len(GePbnu93wr4BKdMqm)%4)%4)*'='
		try:
			GePbnu93wr4BKdMqm = qqth6cAFkaRowLlUeMng.b64decode(GePbnu93wr4BKdMqm+R2w9xEN67Sl)
			if A7Z6OVh20eCEUx: GePbnu93wr4BKdMqm = GePbnu93wr4BKdMqm.decode(Im5KSGZYBpRvdMVsbuXg,'ignore')
		except: pass
		aPBMHCOI7bJjXFL5rwnq2 += GePbnu93wr4BKdMqm
	aPBMHCOI7bJjXFL5rwnq2 = aPBMHCOI7bJjXFL5rwnq2.replace(' = ',' => ')
	mMxg3t6vek = aPBMHCOI7bJjXFL5rwnq2.splitlines()
	for ZgsbN5iSL48t2IhVFnmy in mMxg3t6vek:
		if '://' in ZgsbN5iSL48t2IhVFnmy: Rp1g7OlotseGnf0NFmKk6rLxd.append(ZgsbN5iSL48t2IhVFnmy)
	for ZgsbN5iSL48t2IhVFnmy in Rp1g7OlotseGnf0NFmKk6rLxd:
		if ' => ' in ZgsbN5iSL48t2IhVFnmy: title,ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split(' => ')
		elif 'http' in ZgsbN5iSL48t2IhVFnmy:
			title,ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('http')
			ZgsbN5iSL48t2IhVFnmy = 'http'+ZgsbN5iSL48t2IhVFnmy
		else: continue
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.strip(' ')
		if not title: title = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/search.php?keywords='+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'SHOOFMAX'
kL0nT7NpZdKVD3jM2OHB = '_SHM_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
hRigZpdbjIYsDGr2 = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][1]
SGcRTmovWh8NsAx9f0q2V = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][2]
def hH3sRBSFAr(mode,url,text):
	if   mode==50: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==51: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	elif mode==52: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==53: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==55: SD0TxMRXiep4cjPBsnzI = wX6hbloE8DKN()
	elif mode==56: SD0TxMRXiep4cjPBsnzI = kNt97bdZ8hmuBXg04FoJUa3S()
	elif mode==57: SD0TxMRXiep4cjPBsnzI = DVEvPnGWqpez(url,1)
	elif mode==58: SD0TxMRXiep4cjPBsnzI = DVEvPnGWqpez(url,2)
	elif mode==59: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,59,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المسلسلات',CJlTSEpZsWb0QHg5w,56)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الافلام',CJlTSEpZsWb0QHg5w,55)
	return CJlTSEpZsWb0QHg5w
def wX6hbloE8DKN():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أفلام مرتبة بسنة الإنتاج',V4kF6EQiwo+'/movie/1/yop',57)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أفلام مرتبة بالأفضل تقييم',V4kF6EQiwo+'/movie/1/review',57)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أفلام مرتبة بالأكثر مشاهدة',V4kF6EQiwo+'/movie/1/views',57)
	return
def kNt97bdZ8hmuBXg04FoJUa3S():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات مرتبة بسنة الإنتاج',V4kF6EQiwo+'/series/1/yop',57)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات مرتبة بالأفضل تقييم',V4kF6EQiwo+'/series/1/review',57)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسلات مرتبة بالأكثر مشاهدة',V4kF6EQiwo+'/series/1/views',57)
	return
def nvHUf8mW6E4GSw5VFRXN(url):
	if '?' in url:
		WyHwgmzU0GnP = url.split('?')
		url = WyHwgmzU0GnP[0]
		filter = '?' + O4Ak3NXpyUHvE(WyHwgmzU0GnP[1],'=&:/%')
	else: filter = CJlTSEpZsWb0QHg5w
	type,GOF25jkXb1DnaB4vhL9,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': WlXkHQR2mp7wKBgGYh4='فيلم'
		elif type=='series': WlXkHQR2mp7wKBgGYh4='مسلسل'
		url = V4kF6EQiwo + '/genre/filter/' + O4Ak3NXpyUHvE(WlXkHQR2mp7wKBgGYh4) + '/' + GOF25jkXb1DnaB4vhL9 + '/' + sort + filter
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHOOFMAX-TITLES-1st')
		items = Zy2l0g8QU5vqefaTrsw.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		j4tamyicXPDHKeTvWJ=0
		for id,title,K7Qk2LOnV1GyrzY5F,hzGKUP1XjAoeT79MJcDF in items:
			j4tamyicXPDHKeTvWJ += 1
			hzGKUP1XjAoeT79MJcDF = SGcRTmovWh8NsAx9f0q2V + '/v2/img/program/main/' + hzGKUP1XjAoeT79MJcDF + '-2.jpg'
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo + '/program/' + id
			if type=='movie': khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,53,hzGKUP1XjAoeT79MJcDF)
			if type=='series': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسل '+title,ZgsbN5iSL48t2IhVFnmy+'?ep='+K7Qk2LOnV1GyrzY5F+'='+title+'='+hzGKUP1XjAoeT79MJcDF,52,hzGKUP1XjAoeT79MJcDF)
	else:
		if type=='movie': WlXkHQR2mp7wKBgGYh4='movies'
		elif type=='series': WlXkHQR2mp7wKBgGYh4='series'
		url = hRigZpdbjIYsDGr2 + '/json/selected/' + sort + '-' + WlXkHQR2mp7wKBgGYh4 + '-WW.json'
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHOOFMAX-TITLES-2nd')
		items = Zy2l0g8QU5vqefaTrsw.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		j4tamyicXPDHKeTvWJ=0
		for id,K7Qk2LOnV1GyrzY5F,hzGKUP1XjAoeT79MJcDF,title in items:
			j4tamyicXPDHKeTvWJ += 1
			hzGKUP1XjAoeT79MJcDF = hRigZpdbjIYsDGr2 + '/img/program/' + hzGKUP1XjAoeT79MJcDF + '-2.jpg'
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo + '/program/' + id
			if type=='movie': khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,53,hzGKUP1XjAoeT79MJcDF)
			elif type=='series': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مسلسل '+title,ZgsbN5iSL48t2IhVFnmy+'?ep='+K7Qk2LOnV1GyrzY5F+'='+title+'='+hzGKUP1XjAoeT79MJcDF,52,hzGKUP1XjAoeT79MJcDF)
	title='صفحة '
	if j4tamyicXPDHKeTvWJ==16:
		for HS8Mws1vU4NkeLOJ in range(1,13) :
			if not GOF25jkXb1DnaB4vhL9==str(HS8Mws1vU4NkeLOJ):
				url = V4kF6EQiwo+'/genre/filter/'+type+'/'+str(HS8Mws1vU4NkeLOJ)+'/'+sort+filter
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title+str(HS8Mws1vU4NkeLOJ),url,51)
	return
def j9zTQsrVRx2(url):
	WyHwgmzU0GnP = url.split('=')
	K7Qk2LOnV1GyrzY5F = int(WyHwgmzU0GnP[1])
	name = sWzgdLCjSVwaMuhFkNf1Uop(WyHwgmzU0GnP[2])
	name = name.replace('_MOD_مسلسل ',CJlTSEpZsWb0QHg5w)
	hzGKUP1XjAoeT79MJcDF = WyHwgmzU0GnP[3]
	url = url.split('?')[0]
	if K7Qk2LOnV1GyrzY5F==0:
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHOOFMAX-EPISODES-1st')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<select(.*?)</select>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('option value="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		K7Qk2LOnV1GyrzY5F = int(items[-1])
	for ABK45TEMpciLnmIlYOafQJZ8t in range(K7Qk2LOnV1GyrzY5F,0,-1):
		ZgsbN5iSL48t2IhVFnmy = url + '?ep=' + str(ABK45TEMpciLnmIlYOafQJZ8t)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(ABK45TEMpciLnmIlYOafQJZ8t)
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,53,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHOOFMAX-PLAY-1st')
	P0XJMvahHbT9 = Zy2l0g8QU5vqefaTrsw.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if P0XJMvahHbT9:
		L8Wkv5KCSoq = P0XJMvahHbT9[1].replace('T',NaE5l67ROx)
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+rJ9cgWz4FU+L8Wkv5KCSoq)
		return
	mw4R3oI165fXtx,EdfOJQVXvW1 = [],[]
	uufM9nKyJphc1H0t4ZYWbwXT = Zy2l0g8QU5vqefaTrsw.findall('var origin_link = "(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	xu6CDnSVb9jLglBUHia7 = Zy2l0g8QU5vqefaTrsw.findall('var backup_origin_link = "(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('hls: (.*?)_link\+"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for FFtJQalhPz,ZgsbN5iSL48t2IhVFnmy in Rp1g7OlotseGnf0NFmKk6rLxd:
		if 'backup' in FFtJQalhPz:
			FFtJQalhPz = 'backup server'
			url = xu6CDnSVb9jLglBUHia7 + ZgsbN5iSL48t2IhVFnmy
		else:
			FFtJQalhPz = 'main server'
			url = uufM9nKyJphc1H0t4ZYWbwXT + ZgsbN5iSL48t2IhVFnmy
		if '.m3u8' in url:
			mw4R3oI165fXtx.append(url)
			EdfOJQVXvW1.append('m3u8  '+FFtJQalhPz)
	Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	Rp1g7OlotseGnf0NFmKk6rLxd += Zy2l0g8QU5vqefaTrsw.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for FFtJQalhPz,ZgsbN5iSL48t2IhVFnmy in Rp1g7OlotseGnf0NFmKk6rLxd:
		filename = ZgsbN5iSL48t2IhVFnmy.split('/')[-1]
		filename = filename.replace('fallback',CJlTSEpZsWb0QHg5w)
		filename = filename.replace('.mp4',CJlTSEpZsWb0QHg5w)
		filename = filename.replace('-',CJlTSEpZsWb0QHg5w)
		if 'backup' in FFtJQalhPz:
			FFtJQalhPz = 'backup server'
			url = xu6CDnSVb9jLglBUHia7 + ZgsbN5iSL48t2IhVFnmy
		else:
			FFtJQalhPz = 'main server'
			url = uufM9nKyJphc1H0t4ZYWbwXT + ZgsbN5iSL48t2IhVFnmy
		mw4R3oI165fXtx.append(url)
		EdfOJQVXvW1.append('mp4  '+FFtJQalhPz+gCc52XVMGfAnOe+filename)
	CrqTamtPFuU = T4TK17YsEfZJ('Select Video Quality:', EdfOJQVXvW1)
	if CrqTamtPFuU == -1 : return
	url = mw4R3oI165fXtx[CrqTamtPFuU]
	ZQtv0jY9W6L8UHgpnKm(url,T1QDsJlUtCGhn,'video')
	return
def DVEvPnGWqpez(url,type):
	if 'series' in url: BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo + '/genre/مسلسل'
	else: BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo + '/genre/فيلم'
	BBwfuWGxUIrdCoc4ka7 = O4Ak3NXpyUHvE(BBwfuWGxUIrdCoc4ka7)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'SHOOFMAX-FILTERS-1st')
	if type==1: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('subgenre(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type==2: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('country(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('option value="(.*?)">(.*?)</option',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if type==1:
		for nXVBLaGbw5ds8Tmc,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url+'?subgenre='+nXVBLaGbw5ds8Tmc,58)
	elif type==2:
		url,nXVBLaGbw5ds8Tmc = url.split('?')
		for F087kSJl1WXD93VmP2gvUQtEKiAIL,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url+'?country='+F087kSJl1WXD93VmP2gvUQtEKiAIL+'&'+nXVBLaGbw5ds8Tmc,51)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if not search: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'%20')
	url = V4kF6EQiwo+'/search?q='+QjfknOVHzZIUir
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,True,CJlTSEpZsWb0QHg5w,'SHOOFMAX-SEARCH-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('general-body(.*?)search-bottom-padding',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			url = V4kF6EQiwo + ZgsbN5iSL48t2IhVFnmy
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+O4Ak3NXpyUHvE(title)+'='+hzGKUP1XjAoeT79MJcDF
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,52,hzGKUP1XjAoeT79MJcDF)
				else:
					title = '_MOD_فيلم '+title
					khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,url,53,hzGKUP1XjAoeT79MJcDF)
	return
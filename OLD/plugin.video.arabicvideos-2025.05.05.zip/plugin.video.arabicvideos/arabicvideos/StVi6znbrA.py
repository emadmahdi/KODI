# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from kUCfvjAP1c import *
T1QDsJlUtCGhn = HaTI5u1f3SCxmMAkw(u"ࠨࡔࡄࡒࡉࡕࡍࡔࠩ᭙")
kL0nT7NpZdKVD3jM2OHB = rC5tnFDlQcRGA2(u"ࠩࡢࡐࡘ࡚࡟ࠨ᭚")
QcrHeGYFuatln7KBA6VJyhDIOz1qpf = P3cpaLN2sH
le6T9y2LYo1RpZS = cbmeD4WNZfAowxT2JdUMtV(u"࠶࠶᷅")
def hH3sRBSFAr(BEUVvSQtRimC,url,FMxeyLvnzabpJhCXgS6T,GOF25jkXb1DnaB4vhL9,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh):
	try: DDQHXmOsdnJVtK = str(TiPIxOFX2bS5ZDG4A1KoeVUyW0dh[E6xdOMpqISHZCn(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭛")])
	except: DDQHXmOsdnJVtK = CJlTSEpZsWb0QHg5w
	if   BEUVvSQtRimC==EcjO3giln2kQTdBY0XLAG(u"࠷࠶࠱᷆"): SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif BEUVvSQtRimC==GISOTJh20W(u"࠱࠷࠳᷇"): SD0TxMRXiep4cjPBsnzI = QwU8LcVxvR5tXjD(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==yUMRP0QKIzY9BDnsV784TZmwkf(u"࠲࠸࠵᷈"): SD0TxMRXiep4cjPBsnzI = aHmsWdwL8RoDvEQgu9702rKI(FMxeyLvnzabpJhCXgS6T,yUMRP0QKIzY9BDnsV784TZmwkf(u"࠲࠸࠵᷈"))
	elif BEUVvSQtRimC==ZP1LyUCS3pIBu(u"࠳࠹࠷᷉"): SD0TxMRXiep4cjPBsnzI = aHmsWdwL8RoDvEQgu9702rKI(FMxeyLvnzabpJhCXgS6T,ZP1LyUCS3pIBu(u"࠳࠹࠷᷉"))
	elif BEUVvSQtRimC==HaTI5u1f3SCxmMAkw(u"࠴࠺࠹᷊"): SD0TxMRXiep4cjPBsnzI = XZ5UPzfVJWTmYQxgpcOat29A(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==cbmeD4WNZfAowxT2JdUMtV(u"࠵࠻࠻᷋"): SD0TxMRXiep4cjPBsnzI = AIfymqjS8zuHJXoxh5bZ0MRcgT(url,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==zQGaM7ctZCN(u"࠶࠼࠶᷌"): SD0TxMRXiep4cjPBsnzI = byPFhZJpjcLqH09NIQ(url,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==otNfFapeEnO(u"࠷࠶࠸᷍"): SD0TxMRXiep4cjPBsnzI = WWoh4lQzqvSNaf(url,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==cjVhOCwybeRo7UWg92(u"࠱࠷࠺᷎"): SD0TxMRXiep4cjPBsnzI = hgaUQE8ztwrnOeFv4X5T6kx(url,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==zz679V18GdcZwvrRexA0nNptY2Tab(u"࠸࠸࠴᷏"): SD0TxMRXiep4cjPBsnzI = PkiGO8NbpchLjWBrm3lDvns6tHVC()
	elif BEUVvSQtRimC==Olh7n0zfV4(u"࠹࠹࠶᷐"): SD0TxMRXiep4cjPBsnzI = azi06WpYyDhHwQ5kqoXG()
	elif BEUVvSQtRimC==mi2ZJXCDzITuyev6gfn(u"࠺࠺࠸᷑"): SD0TxMRXiep4cjPBsnzI = qRmjzpa2TBI1PfSw4AbX(DDQHXmOsdnJVtK,FMxeyLvnzabpJhCXgS6T,GOF25jkXb1DnaB4vhL9)
	elif BEUVvSQtRimC==h6sIkJOT5PB2vCxqo4LFag70wA(u"࠻࠻࠺᷒"): SD0TxMRXiep4cjPBsnzI = acIxFuoBJR(DDQHXmOsdnJVtK,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠼࠼࠵ᷓ"): SD0TxMRXiep4cjPBsnzI = Wrnb9lUNjIThFxKuV5v6(DDQHXmOsdnJVtK,FMxeyLvnzabpJhCXgS6T)
	else: SD0TxMRXiep4cjPBsnzI = VJZIMkUN5siqB21Pf
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH(E6xdOMpqISHZCn(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᭜"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"่ࠬๆ้ษอࠤฯ๊แำ์๋๊ࠥ฿ิ้ษษ๎ฮ࠭᭝"),CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"࠷࠶࠲ᷔ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭࡟ࡍࡋ࡙ࡉ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᭞"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᭟"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬ᭠"),CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"࠱࠷࠴ᷕ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᭡"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(GISOTJh20W(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭢"),o2FdrDBimMuOw97q6QpNW8S(u"ࠫๆ๐ฯ๋๊๊หฯูࠦี๊สส๏ฯࠧ᭣"),CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠲࠸࠶ᷖ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᭤"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᭥"),GISOTJh20W(u"ࠧโ์า๎ํํวหࠢหัะูࠦี๊สส๏࠭᭦"),CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"࠳࠹࠸ᷗ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᭧"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᭨"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪๅ๏ี๊้้สฮࠥ฿ิ้ษษ๎ฮࠦๅ็ࠢๅื๊࠭᭩"),CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"࠺࠺࠸ᷘ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࡤࡘࡁࡏࡆࡒࡑࡤ࠭᭪"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡲࡩ࡯࡭ࠪ᭫"),Dj62UpP5MrbTkJqhRa+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤ᭬ࠬ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"࠽࠾࠿࠹ᷙ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(rC5tnFDlQcRGA2(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᭭"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨไ้์ฬะࠠࡎ࠵ࡘࠤ฾ฺ่ศศํอࠬ᭮"),CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"࠶࠼࠳ᷚ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡢࡑ࠸࡛࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᭯"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᭰"),HaTI5u1f3SCxmMAkw(u"ࠫๆ๐ฯ๋๊๊หฯࠦࡍ࠴ࡗࠣ฽ู๎วว์ฬࠫ᭱"),CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠷࠶࠴ᷛ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"ࠬࡥࡍ࠴ࡗࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᭲"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᭳"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧใี่ࠤ็์่ศฬࠣࡑ࠸ฺ࡛ࠠึ๋หห๐ࠧ᭴"),CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠱࠷࠴ᷜ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡡࡐ࠷࡚ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ᭵"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᭶"),s97s2k0LJgl(u"ࠪๆุ๋ࠠโ์า๎ํࠦࡍ࠴ࡗࠣ฽ู๎วว์ࠪ᭷"),CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"࠲࠸࠵ᷝ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡤࡓ࠳ࡖࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᭸"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(mi2ZJXCDzITuyev6gfn(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᭹"),pz4WBwfyDdgk0m2aRr7SMv(u"࠭แ๋ัํ์์อสࠡࡏ࠶࡙ࠥฮอฬࠢ฼ุํอฦ๋ࠩ᭺"),CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠳࠹࠸ᷞ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡠࡏ࠶࡙ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᭻"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᭼"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠩไ๎ิ๐่่ษอࠤࡒ࠹ࡕࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩ᭽"),CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠺࠺࠺ᷟ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,GISOTJh20W(u"ࠪࡣࡒ࠹ࡕࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭᭾"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡱ࡯࡮࡬ࠩ᭿"),Dj62UpP5MrbTkJqhRa+TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᮀ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠽࠾࠿࠹ᷠ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮁ"),GISOTJh20W(u"ࠧใ่๋หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬᮂ"),CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶࠼࠳ᷡ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᮃ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡩࡳࡱࡪࡥࡳࠩᮄ"),otNfFapeEnO(u"ࠪๅ๏ี๊้้สฮࠥࡏࡐࡕࡘࠣ฽ู๎วว์ฬࠫᮅ"),CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"࠷࠶࠴ᷢ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠫࡤࡏࡐࡕࡘࡢࡣ࡛ࡕࡄࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᮆ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᮇ"),JACnOz297UuDK5HpPkc1LF(u"࠭โิ็ࠣๆ๋๎วหࠢࡌࡔ࡙࡜ฺࠠึ๋หห๐ࠧᮈ"),CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"࠱࠷࠴ᷣ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"ࠧࡠࡋࡓࡘ࡛ࡥ࡟ࡍࡋ࡙ࡉࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᮉ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᮊ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠩๅื๊ࠦแ๋ัํ์ࠥࡏࡐࡕࡘࠣ฽ู๎วว์ࠪᮋ"),CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠲࠸࠵ᷤ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠪࡣࡎࡖࡔࡗࡡࡢ࡚ࡔࡊ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᮌ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᮍ"),rC5tnFDlQcRGA2(u"ࠬ็๊ะ์๋๋ฬะࠠࡊࡒࡗ࡚ࠥฮอฬࠢ฼ุํอฦ๋ࠩᮎ"),CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"࠳࠹࠸ᷥ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"࠭࡟ࡊࡒࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᮏ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᮐ"),ZP1LyUCS3pIBu(u"ࠨใํำ๏๎็ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊ส่๊่ࠢࠥำๆࠩᮑ"),CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"࠺࠺࠹ᷦ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡢࡍࡕ࡚ࡖࡠࡡࡕࡅࡓࡊࡏࡎࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᮒ"))
	return
def PkiGO8NbpchLjWBrm3lDvns6tHVC():
	khqge7BVD9jPFy1S8T5Gn4QAlH(JACnOz297UuDK5HpPkc1LF(u"ࠪࡪࡴࡲࡤࡦࡴࠪᮓ"),cjVhOCwybeRo7UWg92(u"ࠫࡤࡏࡐࡕࡡࠪᮔ")+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ็๊ะ์๋๋ฬะࠠอ็ํ฽ࠥࡏࡐࡕࡘࠪᮕ"),CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"࠻࠻࠺ᷧ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(Olh7n0zfV4(u"࠭࡬ࡪࡰ࡮ࠫᮖ"),Dj62UpP5MrbTkJqhRa+VVvcQpCU3OM09n(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᮗ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"࠾࠿࠹࠺ᷨ"))
	for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
		kL0nT7NpZdKVD3jM2OHB = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡡࡌࡔࠬᮘ")+str(DDQHXmOsdnJVtK)+EcjO3giln2kQTdBY0XLAG(u"ࠩࡢࠫᮙ")
		khqge7BVD9jPFy1S8T5Gn4QAlH(JACnOz297UuDK5HpPkc1LF(u"ࠪࡪࡴࡲࡤࡦࡴࠪᮚ"),kL0nT7NpZdKVD3jM2OHB+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࠥ็๊ะ์๋๋ฬะࠠๆฮ็ำࠥ࠭ᮛ")+gB7j2bpeiCF1v[DDQHXmOsdnJVtK],CJlTSEpZsWb0QHg5w,XB4CjMkPFzhAHiI3q(u"࠽࠶࠵ᷩ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{EcjO3giln2kQTdBY0XLAG(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᮜ"):DDQHXmOsdnJVtK})
	return
def azi06WpYyDhHwQ5kqoXG():
	khqge7BVD9jPFy1S8T5Gn4QAlH(XB4CjMkPFzhAHiI3q(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮝ"),EcjO3giln2kQTdBY0XLAG(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᮞ")+ZP1LyUCS3pIBu(u"ࠨใํำ๏๎็ศฬࠣะ๊๐ูࠡࡏ࠶࡙ࠬᮟ"),CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"࠷࠷࠷ᷪ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩ࡯࡭ࡳࡱࠧᮠ"),Dj62UpP5MrbTkJqhRa+EcjO3giln2kQTdBY0XLAG(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᮡ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"࠺࠻࠼࠽ᷫ"))
	for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
		kL0nT7NpZdKVD3jM2OHB = O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡤࡓࡕࠨᮢ")+str(DDQHXmOsdnJVtK)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡥࠧᮣ")
		khqge7BVD9jPFy1S8T5Gn4QAlH(KA26GucUHOwXL(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᮤ"),kL0nT7NpZdKVD3jM2OHB+VVvcQpCU3OM09n(u"ࠧࠡใํำ๏๎็ศฬ้ࠣั๊ฯࠡࠩᮥ")+gB7j2bpeiCF1v[DDQHXmOsdnJVtK],CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"࠹࠹࠹ᷬ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{KA26GucUHOwXL(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᮦ"):DDQHXmOsdnJVtK})
	return
def BGj03ZOqai9mukWUzVlJsRfH(ad3z2451e09FrDHmvci):
	global oRAXd91atgP6CZQUw7,l2crMbdwzayOW
	jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
	try:
		if EcjO3giln2kQTdBY0XLAG(u"ࠩࡌࡊࡎࡒࡍࠨᮧ") in ad3z2451e09FrDHmvci: jJRFufHp4y0KoasdBXqkEGl(ad3z2451e09FrDHmvci)
		else: jJRFufHp4y0KoasdBXqkEGl()
		nc5ZImQ2p697wiF4rJkfSsALBg = VJZIMkUN5siqB21Pf
	except:
		nAtVz16YSq0Jf()
		nc5ZImQ2p697wiF4rJkfSsALBg = w2qb6lf5EM
	ad3z2451e09FrDHmvci = HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci)
	if nc5ZImQ2p697wiF4rJkfSsALBg:
		KhwN2zcb7iMkjS5E4WURxByPGon(ad3z2451e09FrDHmvci,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪๅู๊ࠠๅๆฦืๆ࠭ᮨ"),L8Wkv5KCSoq=zQGaM7ctZCN(u"࠵࠴࠵࠶ᷭ"))
		oRAXd91atgP6CZQUw7 += P2Fgh6TCOWoaHjkqBcQnvRNXe
		l2crMbdwzayOW += JACnOz297UuDK5HpPkc1LF(u"ࠫࠥ࠴ࠠࠨᮩ")+ad3z2451e09FrDHmvci
	else: KhwN2zcb7iMkjS5E4WURxByPGon(ad3z2451e09FrDHmvci,CJlTSEpZsWb0QHg5w,L8Wkv5KCSoq=VVvcQpCU3OM09n(u"࠵࠵࠶࠰ᷮ"))
	return
hxd4FlkHos03zf86RPDXQjt = {}
def YWhMUAHvGnspLZ2gaKDd8mR3NJwxFb(lKfi3YtIyNWxwAs0=w2qb6lf5EM):
	global oRAXd91atgP6CZQUw7,l2crMbdwzayOW,hxd4FlkHos03zf86RPDXQjt
	if not lKfi3YtIyNWxwAs0:
		hxd4FlkHos03zf86RPDXQjt = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,yylSaxCLfkte(u"ࠬࡪࡩࡤࡶ᮪ࠪ"),otNfFapeEnO(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡕࡌࡘࡊ᮫࡙ࠧ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࡠࡃࡏࡐࠬᮬ"))
		if hxd4FlkHos03zf86RPDXQjt: return
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨᮭ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TDpFsQXHze2q30uYtGPfEIm8(u"ࠩะฮ๎ࠦสๆๆษࠤ์ึ็ࠡษ็ๆฬฬๅสࠢ࠱࠲ู๊ࠥโฯุࠤฬ๊ศา่ส้ัࠦฬๆ์฼ࠤ๊๎วใ฻ࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢไ๎ࠥอไษำ้ห๊าࠠฮฬ์ࠤ๏ูสฯำฯࠤ๊์็ศࠢไๆ฼ࠦวๅลๅืฬ๋ࠠศๆิส๏ู๊สࠢ࠱࠲ࠥัๅࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡสัึ๋ࠦ็ั้ࠣห้ษโิษ่ࠤาะ้ࠡๆสࠤฯำสศฮࠣว๋ࠦสๆๆษ๋ฬࠦๅาหࠣวำื้ࠡ࠰࠱ࠤ์ึ็ࠡษ็฽๊๊๊สࠢอัฯอฬࠡ฻สำฮࠦรใๆ้๋ࠣࠦ࠳ࠡัๅหห่ࠠ࡝ࡰ࡟ࡲࠬᮮ")+Dj62UpP5MrbTkJqhRa+h6sIkJOT5PB2vCxqo4LFag70wA(u"๋้ࠪࠦสา์าࠤศ์ࠠหฮ่฽่ࠥวว็ฬࠤฬ๊รใีส้ࠥอไร่ࠣรࠬᮯ")+oOQaRxBXyJ5jVnZ)
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=P2Fgh6TCOWoaHjkqBcQnvRNXe: return
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY,uSo1OXy4h6xJvmAVfB3TEY)
	em0iBcZqULYjv = Ew2zQ8u7Ss.menuItemsLIST
	oRAXd91atgP6CZQUw7,l2crMbdwzayOW,threads = ZVNvqy4iF1a9X,CJlTSEpZsWb0QHg5w,{}
	for ad3z2451e09FrDHmvci in WZ7itqR9KanXm2cYeGx3dMNTI4:
		L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
		threads[ad3z2451e09FrDHmvci] = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=BGj03ZOqai9mukWUzVlJsRfH,args=(ad3z2451e09FrDHmvci,))
		threads[ad3z2451e09FrDHmvci].start()
	else:
		for ad3z2451e09FrDHmvci in list(threads.keys()): threads[ad3z2451e09FrDHmvci].join()
	Ew2zQ8u7Ss.menuItemsLIST[:] = em0iBcZqULYjv
	hxd4FlkHos03zf86RPDXQjt = {}
	for ad3z2451e09FrDHmvci in list(threads.keys()):
		try: LeiI4gKJjqDftHTVs6XNlx20 = Ew2zQ8u7Ss.menuItemsDICT[ad3z2451e09FrDHmvci]
		except: continue
		ad3z2451e09FrDHmvci = KA26GucUHOwXL(u"ࠫࡤࡒࡓࡕࡡࠪ᮰")+HRYMpjUhOiul4zdP7G8c(ad3z2451e09FrDHmvci)
		for nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO in LeiI4gKJjqDftHTVs6XNlx20:
			if not idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = E6xdOMpqISHZCn(u"ࠬ࠴࠮࠯࠰ࠪ᮱")
			else:
				if idaKcvOmbRrkW1CtHhZfeAJQV4D.count(VVvcQpCU3OM09n(u"࠭࡟ࠨ᮲"))>P2Fgh6TCOWoaHjkqBcQnvRNXe: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.split(KA26GucUHOwXL(u"ࠧࡠࠩ᮳"),VTadWjBloMwXO2CH9GDK6FR)[VTadWjBloMwXO2CH9GDK6FR]
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(mi2ZJXCDzITuyev6gfn(u"ࠨࢢࠪ᮴"),CJlTSEpZsWb0QHg5w).replace(yylSaxCLfkte(u"ࠩࠣࡌࡉ࠭᮵"),CJlTSEpZsWb0QHg5w).replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡌࡉࠦࠧ᮶"),CJlTSEpZsWb0QHg5w)
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(o2FdrDBimMuOw97q6QpNW8S(u"ࠫๅ࠭᮷"),CJlTSEpZsWb0QHg5w).replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬฯࠧ᮸"),zQGaM7ctZCN(u"࠭็ࠨ᮹")).replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧลࠩᮺ"),rC5tnFDlQcRGA2(u"ࠨ๊ࠪᮻ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(KA26GucUHOwXL(u"ࠩฦࠫᮼ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪหࠬᮽ")).replace(HaTI5u1f3SCxmMAkw(u"ࠫส࠭ᮾ"),E6xdOMpqISHZCn(u"ࠬอࠧᮿ")).replace(E6xdOMpqISHZCn(u"࠭ยࠨᯀ"),zQGaM7ctZCN(u"ࠧศࠩᯁ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(XB4CjMkPFzhAHiI3q(u"ࠨๆฦࠫᯂ"),rC5tnFDlQcRGA2(u"ࠩ็หࠬᯃ")).replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"่ࠪส࠭ᯄ"),HaTI5u1f3SCxmMAkw(u"้ࠫอࠧᯅ")).replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"๊ࠬยࠨᯆ"),yylSaxCLfkte(u"࠭ไศࠩᯇ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(cjVhOCwybeRo7UWg92(u"ࠧ๏ࠩᯈ"),CJlTSEpZsWb0QHg5w).replace(cjVhOCwybeRo7UWg92(u"ࠨํࠪᯉ"),CJlTSEpZsWb0QHg5w).replace(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ๒ࠫᯊ"),CJlTSEpZsWb0QHg5w).replace(mi2ZJXCDzITuyev6gfn(u"ࠪ๐ࠬᯋ"),CJlTSEpZsWb0QHg5w)
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(E6xdOMpqISHZCn(u"ࠫ๕࠭ᯌ"),CJlTSEpZsWb0QHg5w).replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ๓ࠧᯍ"),CJlTSEpZsWb0QHg5w).replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭๒ࠨᯎ"),CJlTSEpZsWb0QHg5w).replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧ๒ࠩᯏ"),CJlTSEpZsWb0QHg5w)
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡾࠪᯐ"),CJlTSEpZsWb0QHg5w).replace(otNfFapeEnO(u"ࠩࢁࠫᯑ"),CJlTSEpZsWb0QHg5w)
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠪหํ์ࠠๅษํ๊ࠬᯒ"),CJlTSEpZsWb0QHg5w).replace(XB4CjMkPFzhAHiI3q(u"ุࠫ๐ๅศࠢ็ห๏ะࠧᯓ"),CJlTSEpZsWb0QHg5w)
				JVEvxwyzO6nf = [CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬอไฺษหࠫᯔ"),JACnOz297UuDK5HpPkc1LF(u"࠭ฮ๋ษ็ࠫᯕ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠧศๆห์๊࠭ᯖ"),s97s2k0LJgl(u"ࠨษ็ห๋࠭ᯗ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠩส฻ๆอไࠨᯘ"),s97s2k0LJgl(u"ࠪัฬ๊๊่ࠩᯙ"),cjVhOCwybeRo7UWg92(u"ࠫฬฺ๊ศิࠪᯚ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ฻วๅฯࠪᯛ"),VVvcQpCU3OM09n(u"࠭วๅัํ๊ࠬᯜ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧๆ๊ส่๏ีࠧᯝ"),XB4CjMkPFzhAHiI3q(u"ࠨษ็฽ฬ๊ๅࠨᯞ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩส฽๊อไࠨᯟ")]
				if not any(iOGS6EWr13ewPKpU4CD9d8Y2R in idaKcvOmbRrkW1CtHhZfeAJQV4D for iOGS6EWr13ewPKpU4CD9d8Y2R in JVEvxwyzO6nf): idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(GISOTJh20W(u"ࠪห้࠭ᯠ"),CJlTSEpZsWb0QHg5w)
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(s97s2k0LJgl(u"ࠫฬิั๋ࠩᯡ"),mi2ZJXCDzITuyev6gfn(u"ࠬอฮา๋ࠪᯢ")).replace(rC5tnFDlQcRGA2(u"࠭วอ่หํࠬᯣ"),Olh7n0zfV4(u"ࠧศฮ้ฬ๏࠭ᯤ")).replace(s97s2k0LJgl(u"ࠨ฻สส้๐็ࠨᯥ"),cjVhOCwybeRo7UWg92(u"ࠩ฼หห๊๊ࠨ᯦"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪหั์ศ๋้ࠪᯧ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫฬาๆษ์ࠪᯨ")).replace(GISOTJh20W(u"ࠬ฿ัษ์๊ࠫᯩ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ู࠭าสํࠫᯪ")).replace(XB4CjMkPFzhAHiI3q(u"ࠧา๊่หู๋๊่ࠩᯫ"),JACnOz297UuDK5HpPkc1LF(u"ࠨำ๋้ฬ์ำ๋ࠩᯬ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(cjVhOCwybeRo7UWg92(u"ࠩ฽ีอ๐็ࠨᯭ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪ฾ึฮ๊ࠨᯮ")).replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫํࠦๅิๆึ่ฬะࠧᯯ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"๋ࠬำๅี็หฯ࠭ᯰ")).replace(o2FdrDBimMuOw97q6QpNW8S(u"࠭ว฻ษ้ํࠬᯱ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠧศ฼ส๊๏᯲࠭"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨฬสี๏ิ๊ࠨ᯳"),cbmeD4WNZfAowxT2JdUMtV(u"ࠩอหึ๐ฮࠨ᯴")).replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠪา๏อไࠡ฻็้๏࠭᯵"),o2FdrDBimMuOw97q6QpNW8S(u"ࠫำ๐วๅࠩ᯶")).replace(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"๋่ࠬิ์ๅ๎์࠭᯷"),HaTI5u1f3SCxmMAkw(u"࠭ๅ้ีํๆ๎࠭᯸"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(GISOTJh20W(u"่่ࠧาํࠬ᯹"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨ้้ำ๏࠭᯺")).replace(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"๊๊ࠩิ๐็ࠨ᯻"),zQGaM7ctZCN(u"๋๋ࠪี๊ࠨ᯼")).replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫํัววไํ๋ࠬ᯽"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ๎หศศๅ๎ࠬ᯾"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭สๅ์ไึ๏๎ๆ๋้ࠪ᯿"),Olh7n0zfV4(u"ࠧหๆไึ๏๎ๆࠨᰀ")).replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨฬ็ๅื๐่็์๊ࠫᰁ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩอ่ๆุ๊้่ࠪᰂ")).replace(E6xdOMpqISHZCn(u"ࠪ์้ࠥัห๊้ࠫᰃ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫํ้ัห๊้ࠫᰄ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬอไฮษ็๎์࠭ᰅ"),yylSaxCLfkte(u"࠭อศๆํ๋ࠬᰆ")).replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧๆ๊ึ໐็๐ࠧᰇ"),HaTI5u1f3SCxmMAkw(u"ࠨ็๋ื๏่้ࠨᰈ")).replace(cbmeD4WNZfAowxT2JdUMtV(u"ࠩส่ฬ์ๅ๋ࠩᰉ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪห๋๋๊ࠨᰊ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(VVvcQpCU3OM09n(u"ࠫฬ๊ๅิๆึ่ฬะࠧᰋ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"๋ࠬำๅี็หฯ࠭ᰌ")).replace(GISOTJh20W(u"࠭วๅสิห๊าࠧᰍ"),yylSaxCLfkte(u"ࠧษำส้ั࠭ᰎ")).replace(Olh7n0zfV4(u"ࠨๅสีฯ๎ๆࠨᰏ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩๆีฯ๎ๆࠨᰐ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(XB4CjMkPFzhAHiI3q(u"ࠪัึ๎ศࠨᰑ"),GISOTJh20W(u"ࠫาืศࠨᰒ")).replace(rC5tnFDlQcRGA2(u"ࠬอไศ่สุ๏ีࠧᰓ"),EcjO3giln2kQTdBY0XLAG(u"࠭ว็ษื๎ิ࠭ᰔ")).replace(s97s2k0LJgl(u"ࠧศีํ์๏ํࠧᰕ"),XB4CjMkPFzhAHiI3q(u"ࠨษึ๎ํ๐ࠧᰖ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(zQGaM7ctZCN(u"ࠩ฼ีอ๏ࠧᰗ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ฽ึฮ๊ࠨᰘ")).replace(ZP1LyUCS3pIBu(u"ࠫฯืใ๊ࠩᰙ"),yylSaxCLfkte(u"ࠬะัไ์ࠪᰚ")).replace(cbmeD4WNZfAowxT2JdUMtV(u"࠭สาๅํ๋ࠬᰛ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧหำๆ๎ࠬᰜ")).replace(JACnOz297UuDK5HpPkc1LF(u"ࠨษ็้฻อแࠨᰝ"),otNfFapeEnO(u"ฺ่ࠩฬ็ࠧᰞ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪี๏อึ๋ࠩᰟ"),XB4CjMkPFzhAHiI3q(u"ࠫึ๐วืหࠪᰠ")).replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬื๊ศุ๊ࠫᰡ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ั๋ษูอࠬᰢ")).replace(zQGaM7ctZCN(u"ࠧศีํ์๏ํࠧᰣ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨษึ๎ํ๐ࠧᰤ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩๆ์๊๐ฯ๊ࠩᰥ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ็ํ๋๊ะ์ࠪᰦ")).replace(E6xdOMpqISHZCn(u"่ࠫ๎ๅ๋ัํ๋ࠬᰧ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"้่ࠬๆ์า๎ࠬᰨ")).replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ว็์่๎ࠬᰩ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠧศ่่๎ࠬᰪ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(E6xdOMpqISHZCn(u"ࠨษ้๎๊๐ิ็ࠩᰫ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩส๊๊๐ิ็ࠩᰬ")).replace(TDpFsQXHze2q30uYtGPfEIm8(u"ࠪห๋๋้ࠨᰭ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫฬ์ๅ๋ึ้ࠫᰮ")).replace(cjVhOCwybeRo7UWg92(u"ࠬอๆๆ์ࠪᰯ"),HaTI5u1f3SCxmMAkw(u"࠭ว็็ํุ๋࠭ᰰ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(KA26GucUHOwXL(u"ࠧศ่่๎ู์ิ็ࠩᰱ"),yylSaxCLfkte(u"ࠨษ้้๏ฺๆࠨᰲ")).replace(o2FdrDBimMuOw97q6QpNW8S(u"ࠩส่ฬ์ๅ๋ึ้ࠫᰳ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪห๋๋๊ี่ࠪᰴ")).replace(E6xdOMpqISHZCn(u"ࠫฬ็ไศ็ุ้๊ࠣำๅษอࠫᰵ"),JACnOz297UuDK5HpPkc1LF(u"ࠬอแๅษ่ࠤํ๋ำๅี็หฯ࠭ᰶ"))
				idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).strip(o2FdrDBimMuOw97q6QpNW8S(u"࠭࠭ࠨ᰷")).strip(YvOQBzaTAscXR9ql)
			if idaKcvOmbRrkW1CtHhZfeAJQV4D not in list(hxd4FlkHos03zf86RPDXQjt.keys()): hxd4FlkHos03zf86RPDXQjt[idaKcvOmbRrkW1CtHhZfeAJQV4D] = {}
			hxd4FlkHos03zf86RPDXQjt[idaKcvOmbRrkW1CtHhZfeAJQV4D][ad3z2451e09FrDHmvci] = [nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO]
	JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡖࡍ࡙ࡋࡓࠨ᰸"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡗࡎ࡚ࡅࡔࡡࡄࡐࡑ࠭᰹"),hxd4FlkHos03zf86RPDXQjt,XlNnqz758Zeuo)
	if oRAXd91atgP6CZQUw7>=le6T9y2LYo1RpZS: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,mi2ZJXCDzITuyev6gfn(u"ࠩ็ำ๏้ࠠๆึๆ่ฮࠦแ๋ࠢࠪ᰺")+str(oRAXd91atgP6CZQUw7)+GISOTJh20W(u"ࠪࠤ๊๎โฺ่๊๋่ࠢࠥศไ฼ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣ์์้ะศุ่่๊ࠢษࠡีหฬ์อฺࠠษาอ๋ࠥๆࠡษ็ษ๋ะั็์อࠤ฾์ฯไ๋ࠢห้๋่ศไ฼ࠤ์๐࠺ࠨ᰻")+l2crMbdwzayOW)
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫฯ๋ࠠอๆหࠤัฺ๋๊ࠢส่ศ่ำศ็ࠣห้๋ส้ใิอࠥ็๊ࠡษ็ฬึ์วๆฮࠪ᰼"))
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E,DnruJV9OfB70TSdt1zcCsWl3wFMI8E)
	JXBCMi3e9AW0PjShnfYxpRUbgGcv4()
	return
def nRQX5qeSYH0w(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	TpGRx3umFIEKey1i0XNz8CnJ = VJZIMkUN5siqB21Pf
	aPSGEUtMOfV7IlTdh6C4rpcsYBi = Ew2zQ8u7Ss.menuItemsLIST
	Ew2zQ8u7Ss.menuItemsLIST[:] = []
	if TpGRx3umFIEKey1i0XNz8CnJ and pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ᰽") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		SD0TxMRXiep4cjPBsnzI = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,O4F8UC5lMAS6ghETm1VoPDI(u"࠭࡬ࡪࡵࡷࠫ᰾"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡌࡔ࡙࡜ࠧ᰿"),mi2ZJXCDzITuyev6gfn(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࡠࠩ᱀")+DDQHXmOsdnJVtK)
	elif HaTI5u1f3SCxmMAkw(u"ࠩࡢࡐࡎ࡜ࡅࡠࠩ᱁") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU or KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡣ࡛ࡕࡄࡠࠩ᱂") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		import Da6LhPonbt
		LLyhViKbxMntl5JSk = mi2ZJXCDzITuyev6gfn(u"้๊ࠫริใ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์๋ࠣีอࠠศๆ่์็฿ࠠ࠯๋ࠢีุอไสࠢส่ำ฽รࠡๅส๊ࠥ็๊่ษࠣฮๆอี๋ๆࠣห้๋ิไๆฬࠤ࠳ࠦรัษࠣห้๋ิไๆฬࠤ้๐ำหࠢะะอࠦแอำหࠤสืำศๆ๋ࠣีํࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ัࠦๅ็ࠢๅหห๋ษࠡำึหห๊ࠠศๆหี๋อๅอࠩ᱃")
		if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡥࡌࡊࡘࡈࡣࠬ᱄") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
			try: Da6LhPonbt.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,mi2ZJXCDzITuyev6gfn(u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬ᱅"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᱆"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠨ็๋ๆ฾ࠦเࡊࡒࡗ๊࡚ࠥไโ์า๎ํํวหࠩ᱇"),LLyhViKbxMntl5JSk)
			try: Da6LhPonbt.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᱈"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+mi2ZJXCDzITuyev6gfn(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᱉"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๅ๏ี๊้้สฮࠬ᱊"),LLyhViKbxMntl5JSk)
			try: Da6LhPonbt.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࡜ࡏࡅࡡࡖࡉࡗࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ᱋"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᱌"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨᱍ"),LLyhViKbxMntl5JSk)
		if zQGaM7ctZCN(u"ࠨࡡ࡙ࡓࡉࡥࠧᱎ") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
			try: Da6LhPonbt.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᱏ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+GISOTJh20W(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ᱐"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"๊ࠫ๎โฺࠢใࡍࡕ࡚ࡖࠡๆ็ๆ๋๎วหࠩ᱑"),LLyhViKbxMntl5JSk)
			try: Da6LhPonbt.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,HaTI5u1f3SCxmMAkw(u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ᱒"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+E6xdOMpqISHZCn(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᱓"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧๆ๊ๅ฽ࠥๆࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ᱔"),LLyhViKbxMntl5JSk)
		SD0TxMRXiep4cjPBsnzI = Ew2zQ8u7Ss.menuItemsLIST
		if TpGRx3umFIEKey1i0XNz8CnJ: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ᱕"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࠪ᱖")+DDQHXmOsdnJVtK,SD0TxMRXiep4cjPBsnzI,XlNnqz758Zeuo)
	Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi
	return SD0TxMRXiep4cjPBsnzI
def Rklq1SyhxETOD5C(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	TpGRx3umFIEKey1i0XNz8CnJ = VJZIMkUN5siqB21Pf
	aPSGEUtMOfV7IlTdh6C4rpcsYBi = Ew2zQ8u7Ss.menuItemsLIST
	Ew2zQ8u7Ss.menuItemsLIST[:] = []
	if TpGRx3umFIEKey1i0XNz8CnJ and GISOTJh20W(u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ᱗") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		SD0TxMRXiep4cjPBsnzI = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡱ࡯ࡳࡵࠩ᱘"),s97s2k0LJgl(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫ᱙"),mi2ZJXCDzITuyev6gfn(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࡤ࠭ᱚ")+DDQHXmOsdnJVtK)
	elif Olh7n0zfV4(u"ࠧࡠࡎࡌ࡚ࡊࡥࠧᱛ") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU or JACnOz297UuDK5HpPkc1LF(u"ࠨࡡ࡙ࡓࡉࡥࠧᱜ") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		import vQnI182HJr
		LLyhViKbxMntl5JSk = zQGaM7ctZCN(u"ࠩ็่ศูแࠡๆา๎่ࠦๅีๅ็อࠥ็๊้ࠡำหࠥอไๆ๊ๅ฽ࠥ࠴้ࠠำึห้ฯࠠศๆั฻ศࠦใศ่ࠣๅ๏ํวࠡฬไหฺ๐ไࠡษ็ู้้ไสࠢ࠱ࠤศึวࠡษ็ู้้ไสࠢ็๎ุะࠠฮฮหࠤๆาัษࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๊์ࠠใษษ้ฮࠦัิษษ่ࠥอไษำ้ห๊าࠧᱝ")
		if mi2ZJXCDzITuyev6gfn(u"ࠪࡣࡑࡏࡖࡆࡡࠪᱞ") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
			try: vQnI182HJr.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,s97s2k0LJgl(u"࡛ࠫࡕࡄࡠࡗࡑࡏࡓࡕࡗࡏࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪᱟ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+KA26GucUHOwXL(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᱠ"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ๅ้ไ฼ࠤๅࡓ࠳ࡖࠢ็่ๆ๐ฯ๋๊๊หฯ࠭ᱡ"),LLyhViKbxMntl5JSk)
			try: vQnI182HJr.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,zQGaM7ctZCN(u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᱢ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+KA26GucUHOwXL(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱣ"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไโ์า๎ํํวหࠩᱤ"),LLyhViKbxMntl5JSk)
			try: vQnI182HJr.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,zQGaM7ctZCN(u"࡚ࠪࡔࡊ࡟ࡔࡇࡕࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᱥ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+ZP1LyUCS3pIBu(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱦ"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๅ๏ี๊้้สฮࠬᱧ"),LLyhViKbxMntl5JSk)
		if TDpFsQXHze2q30uYtGPfEIm8(u"࠭࡟ࡗࡑࡇࡣࠬᱨ") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
			try: vQnI182HJr.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,E6xdOMpqISHZCn(u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᱩ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᱪ"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"่ࠩ์็฿ࠠแࡏ࠶๊࡙ࠥไใ่๋หฯ࠭ᱫ"),LLyhViKbxMntl5JSk)
			try: vQnI182HJr.S8k6PsUIHu3L05T1fB(DDQHXmOsdnJVtK,E6xdOMpqISHZCn(u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᱬ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᱭ"),VJZIMkUN5siqB21Pf)
			except: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"๋่ࠬใ฻ࠣไࡒ࠹ࡕࠡๆ็ๆ๋๎วหࠩᱮ"),LLyhViKbxMntl5JSk)
		SD0TxMRXiep4cjPBsnzI = Ew2zQ8u7Ss.menuItemsLIST
		if TpGRx3umFIEKey1i0XNz8CnJ: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᱯ"),otNfFapeEnO(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࠧᱰ")+DDQHXmOsdnJVtK,SD0TxMRXiep4cjPBsnzI,XlNnqz758Zeuo)
	Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi
	return SD0TxMRXiep4cjPBsnzI
def qRmjzpa2TBI1PfSw4AbX(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,hnVLZboC3vXOgpr5w1TWYJeqMRE7):
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(RFb4YfvJSsWCy7Z0,RFb4YfvJSsWCy7Z0,uSo1OXy4h6xJvmAVfB3TEY)
	if hnVLZboC3vXOgpr5w1TWYJeqMRE7: YWhMUAHvGnspLZ2gaKDd8mR3NJwxFb(VJZIMkUN5siqB21Pf)
	elif EcjO3giln2kQTdBY0XLAG(u"ࠨࡡࡆࡖࡊࡇࡔࡆࡐࡈ࡛ࡤ࠭ᱱ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU and not hnVLZboC3vXOgpr5w1TWYJeqMRE7: YWhMUAHvGnspLZ2gaKDd8mR3NJwxFb(w2qb6lf5EM)
	Pv5DNzy6UQjF8stwG = gKL8iaPh9sTzdx7ANOfVpbRrcHGkU.replace(cjVhOCwybeRo7UWg92(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧᱲ"),CJlTSEpZsWb0QHg5w).replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᱳ"),CJlTSEpZsWb0QHg5w).replace(o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᱴ"),CJlTSEpZsWb0QHg5w)
	if not hnVLZboC3vXOgpr5w1TWYJeqMRE7:
		khqge7BVD9jPFy1S8T5Gn4QAlH(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡲࡩ࡯࡭ࠪᱵ"),cbmeD4WNZfAowxT2JdUMtV(u"࠭สฮัํฯ่ࠥวว็ฬࠤฬ๊รใีส้ࠬᱶ"),CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠼࠼࠳ᷯ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᱷ")+Pv5DNzy6UQjF8stwG,CJlTSEpZsWb0QHg5w,{h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᱸ"):DDQHXmOsdnJVtK})
		khqge7BVD9jPFy1S8T5Gn4QAlH(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩ࡯࡭ࡳࡱࠧᱹ"),Dj62UpP5MrbTkJqhRa+JACnOz297UuDK5HpPkc1LF(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᱺ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"࠿࠹࠺࠻ᷰ"))
		AY1CXeonHdIvaD4zlpL3ZGxu = [ZP1LyUCS3pIBu(u"ࠫศ็ไศ็ࠪᱻ"),s97s2k0LJgl(u"๋ࠬำๅี็หฯ࠭ᱼ"),zQGaM7ctZCN(u"࠭ๅิำะ๎ฬะࠧᱽ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧษำส้ั࠭᱾"),VVvcQpCU3OM09n(u"ࠨลฺๅฬ๊้ࠠๅิฮํ์ࠧ᱿"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩิ้฻อๆࠨᲀ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠪวาีห࠮ลัีࠬᲁ"),cbmeD4WNZfAowxT2JdUMtV(u"ุ๊ࠫวิๆࠪᲂ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"๋่ࠬิ์ๅํࠬᲃ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭รี้ิ࠱ศ้หาࠩᲄ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧศๆล๊ࠬᲅ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨุะ็ࠬᲆ"),mi2ZJXCDzITuyev6gfn(u"ࠩิ๎ฬ฼ษࠨᲇ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"๊ࠪ๏ะแๅๅึࠫᲈ"),E6xdOMpqISHZCn(u"๊๋ࠫหๅ์้ࠫᲉ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬฮหࠡฯํࠫᲊ"),KA26GucUHOwXL(u"࠭ฯ๋่ํอࠬ᲋"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧิ่๋หฯ࠭᲌"),JACnOz297UuDK5HpPkc1LF(u"ࠨลัี๎࠭᲍")]
		hnVLZboC3vXOgpr5w1TWYJeqMRE7 = ZVNvqy4iF1a9X
		for mZDuJpq0vKh in AY1CXeonHdIvaD4zlpL3ZGxu:
			hnVLZboC3vXOgpr5w1TWYJeqMRE7 += P2Fgh6TCOWoaHjkqBcQnvRNXe
			khqge7BVD9jPFy1S8T5Gn4QAlH(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡩࡳࡱࡪࡥࡳࠩ᲎"),kL0nT7NpZdKVD3jM2OHB+mZDuJpq0vKh,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷࠷࠵ᷱ"),CJlTSEpZsWb0QHg5w,str(hnVLZboC3vXOgpr5w1TWYJeqMRE7),Pv5DNzy6UQjF8stwG,CJlTSEpZsWb0QHg5w,{cjVhOCwybeRo7UWg92(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᲏"):DDQHXmOsdnJVtK})
	else:
		UdFmruH3p4Jeq2z6cOE7s = [GISOTJh20W(u"ࠫฬ็ไศ็ࠪᲐ"),otNfFapeEnO(u"ࠬࡳ࡯ࡷ࡫ࡨࠫᲑ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭แ๋ๆ่ࠫᲒ"),GISOTJh20W(u"ࠧโๆ่ࠫᲓ")]
		KrDZxq4duabWHcmkS0LyVRe7zTUXl = [VVvcQpCU3OM09n(u"ࠨ็ึุ่๊ࠧᲔ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡶࡩࡷ࡯ࡥࡴࠩᲕ")]
		BBXH7M9AjnVFLWGJw = [KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ุ้ࠪอัฮࠩᲖ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ู๊ࠫัฮ์สฮࠬᲗ")]
		KK6irxDh0CevyAbXG = [cbmeD4WNZfAowxT2JdUMtV(u"ࠬฮัศ็ฯࠫᲘ"),VVvcQpCU3OM09n(u"࠭ࡳࡩࡱࡺࠫᲙ"),mi2ZJXCDzITuyev6gfn(u"ࠧหๆไึ๏๎ๆࠨᲚ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨฬ็๎ๆุ๊้่ࠪᲛ")]
		Y9BfgUZDbFk4znsj1p3KcSd = [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩส๊๊๐ࠧᲜ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ็ึะ่็ࠩᲝ"),HaTI5u1f3SCxmMAkw(u"่ࠫอัห๊้ࠫᲞ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡱࡩࡥࡵࠪᲟ"),EcjO3giln2kQTdBY0XLAG(u"࠭ืโๆࠪᲠ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧศูไห้࠭Ს")]
		nzDmZbH8vkxLo4Uq = [KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨำฺ่ฬ์ࠧᲢ")]
		GWrYbnkfSBcuX8jZILoiaemMs = [s97s2k0LJgl(u"ࠩสัิัࠧᲣ"),GISOTJh20W(u"ࠪหำืࠧᲤ"),O4F8UC5lMAS6ghETm1VoPDI(u"๊ࠫ๎ฮาࠩᲥ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬาฯ๋ัࠪᲦ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭ๅืษไࠫᲧ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧฮัํฯࠬᲨ")]
		IIOnuH9zwgd5h = [NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨี็หุ๊ࠧᲩ"),yylSaxCLfkte(u"ࠩึุ่๊็ࠨᲪ")]
		pkhMjKPcUADvsSV = [zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪห฿อๆ๋ࠩᲫ"),zQGaM7ctZCN(u"๊ࠫ๎ำ๋ไ์ࠫᲬ"),mi2ZJXCDzITuyev6gfn(u"้ࠬไ๋สࠪᲭ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭อโๆࠪᲮ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧ࡮ࡷࡶ࡭ࡨ࠭Ჯ")]
		RGVYXlwxDzsioOCeMH6Spcf = [CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨษๆฯึ࠭Ჰ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠩสุ์ืࠧᲱ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"้๊ࠪ๐า่ࠩᲲ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫฬ฿ไ๊ࠩᲳ"),O4F8UC5lMAS6ghETm1VoPDI(u"๋ࠬฮหษิ๋ࠬᲴ"),o2FdrDBimMuOw97q6QpNW8S(u"࠭ๅฯฬสีฬะࠧᲵ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧศไ๋ํࠬᲶ")]
		QxWe0lhTcKpUFIyfob = [O4F8UC5lMAS6ghETm1VoPDI(u"ࠨษ็ห๋࠭Ჷ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠩะห้๐ࠧᲸ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"้ࠪะฮสࠨᲹ"),GISOTJh20W(u"ࠫึอฦอࠩᲺ")]
		JBr1DlbWUupf = [GISOTJh20W(u"ࠬ฼อไࠩ᲻"),cbmeD4WNZfAowxT2JdUMtV(u"࠭ใ้็ํำ๏࠭᲼")]
		MERtmeLD5T = [O4F8UC5lMAS6ghETm1VoPDI(u"ࠧา์สฺ์࠭Ჽ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠨๅ๋ี์࠭Ჾ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ู่ࠩฬืู่ࠩᲿ"),pz4WBwfyDdgk0m2aRr7SMv(u"ุࠪํะࠧ᳀"),Olh7n0zfV4(u"ࠫึ๐วืหࠪ᳁")]
		M4bKeCyJjoPDYBUt8W5xuv9 = [I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ์๊หใ็็ุ࠭᳂"),h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭࡮ࡦࡶࡩࡰ࡮ࡾࠧ᳃"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧ็์อๅ้๐ใิࠩ᳄")]
		ZDjqy6GCVFUOsvmaoW3SR9K2k = [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ็่ฯ้๐ๆࠨ᳅"),s97s2k0LJgl(u"ࠩสุำอีࠨ᳆"),o2FdrDBimMuOw97q6QpNW8S(u"๊ࠪั๎ๅࠨ᳇")]
		HrVCKhtwaksjEW = [pz4WBwfyDdgk0m2aRr7SMv(u"ࠫอัࠠฮ์ࠪ᳈"),cjVhOCwybeRo7UWg92(u"ࠬࡲࡩࡷࡧࠪ᳉"),ZP1LyUCS3pIBu(u"࠭โ็ษ๊ࠫ᳊"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧใ่๋หฯ࠭᳋")]
		pcWFn83TVo = [mi2ZJXCDzITuyev6gfn(u"ࠨัํ๊ࠬ᳌"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠩสำ฾๐็ࠨ᳍"),yylSaxCLfkte(u"ࠪึ๏อัศฬࠪ᳎"),KA26GucUHOwXL(u"้ࠫ฽ๅ๋ษอࠫ᳏"),cjVhOCwybeRo7UWg92(u"ࠬีูศรࠪ᳐"),s97s2k0LJgl(u"࠭โาษ้ࠫ᳑"),VVvcQpCU3OM09n(u"ࠧใืสสิ࠭᳒"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨำฮหฦ࠭᳓"),TMfV6892ZoBdyxCH3tGrkwY0K(u"่ࠩีั฿᳔๊่ࠩ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪหีอๆࠨ᳕"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫฬูไศ็᳖ࠪ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬะ่ศึํั᳗ࠬ"),JACnOz297UuDK5HpPkc1LF(u"࠭ฮุส᳘ࠪ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧฮ๊ี์๏᳙࠭"),otNfFapeEnO(u"ࠨ฻อฬฬะࠧ᳚"),cjVhOCwybeRo7UWg92(u"่ࠩ์ฬ๊๊ะࠩ᳛"),EcjO3giln2kQTdBY0XLAG(u"๊ࠪํอู๋᳜ࠩ"),cjVhOCwybeRo7UWg92(u"ࠫ฾่ววั᳝ࠪ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠬอๆศึํำ᳞ࠬ")]
		K9wyYgf34bHsdOqhZxNipk = [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭࠲࠱࠳࠳᳟ࠫ"),zQGaM7ctZCN(u"ࠧ࠳࠲࠴࠵ࠬ᳠"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨ࠴࠳࠵࠷࠭᳡"),otNfFapeEnO(u"ࠩ࠵࠴࠶࠹᳢ࠧ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࠶࠵࠷࠴ࠨ᳣"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫ࠷࠶࠱࠶᳤ࠩ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬ࠸࠰࠲࠸᳥ࠪ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭࠲࠱࠳࠺᳦ࠫ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧ࠳࠲࠴࠼᳧ࠬ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨ࠴࠳࠵࠾᳨࠭"),HaTI5u1f3SCxmMAkw(u"ࠩ࠵࠴࠷࠶ࠧᳩ"),s97s2k0LJgl(u"ࠪ࠶࠵࠸࠱ࠨᳪ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠫ࠷࠶࠲࠳ࠩᳫ"),Olh7n0zfV4(u"ࠬ࠸࠰࠳࠵ࠪᳬ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭࠲࠱࠴࠷᳭ࠫ"),rC5tnFDlQcRGA2(u"ࠧ࠳࠲࠵࠹ࠬᳮ"),otNfFapeEnO(u"ࠨ࠴࠳࠶࠻࠭ᳯ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩ࠵࠴࠷࠽ࠧᳰ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࠶࠵࠸࠸ࠨᳱ")]
		for idaKcvOmbRrkW1CtHhZfeAJQV4D in sorted(list(hxd4FlkHos03zf86RPDXQjt.keys())):
			TV1Zu8bOAfle5vWSpht2nQ = idaKcvOmbRrkW1CtHhZfeAJQV4D.lower()
			y3LbIjrZvcATpNDM = []
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in UdFmruH3p4Jeq2z6cOE7s): y3LbIjrZvcATpNDM.append(P2Fgh6TCOWoaHjkqBcQnvRNXe)
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in KrDZxq4duabWHcmkS0LyVRe7zTUXl): y3LbIjrZvcATpNDM.append(VTadWjBloMwXO2CH9GDK6FR)
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in BBXH7M9AjnVFLWGJw): y3LbIjrZvcATpNDM.append(D9yBM7wPFLz)
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in KK6irxDh0CevyAbXG): y3LbIjrZvcATpNDM.append(P3cpaLN2sH)
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in Y9BfgUZDbFk4znsj1p3KcSd): y3LbIjrZvcATpNDM.append(GGsP9SDod4iUBm6kNMfLw)
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in nzDmZbH8vkxLo4Uq): y3LbIjrZvcATpNDM.append(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠷ᷲ"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in GWrYbnkfSBcuX8jZILoiaemMs) and TV1Zu8bOAfle5vWSpht2nQ not in [cbmeD4WNZfAowxT2JdUMtV(u"ࠫฬิั๊ࠩᳲ")]: y3LbIjrZvcATpNDM.append(zz679V18GdcZwvrRexA0nNptY2Tab(u"࠹ᷳ"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in IIOnuH9zwgd5h): y3LbIjrZvcATpNDM.append(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠻ᷴ"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in pkhMjKPcUADvsSV): y3LbIjrZvcATpNDM.append(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠽᷵"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in RGVYXlwxDzsioOCeMH6Spcf): y3LbIjrZvcATpNDM.append(Olh7n0zfV4(u"࠶࠶᷶"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in QxWe0lhTcKpUFIyfob): y3LbIjrZvcATpNDM.append(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠷࠱᷷"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in JBr1DlbWUupf): y3LbIjrZvcATpNDM.append(otNfFapeEnO(u"࠱࠳᷸"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in MERtmeLD5T): y3LbIjrZvcATpNDM.append(yylSaxCLfkte(u"࠲࠵᷹"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in M4bKeCyJjoPDYBUt8W5xuv9): y3LbIjrZvcATpNDM.append(otNfFapeEnO(u"࠳࠷᷺"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in ZDjqy6GCVFUOsvmaoW3SR9K2k): y3LbIjrZvcATpNDM.append(ZP1LyUCS3pIBu(u"࠴࠹᷻"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in HrVCKhtwaksjEW): y3LbIjrZvcATpNDM.append(otNfFapeEnO(u"࠵࠻᷼"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in pcWFn83TVo): y3LbIjrZvcATpNDM.append(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠶࠽᷽"))
			if any(value in TV1Zu8bOAfle5vWSpht2nQ for value in K9wyYgf34bHsdOqhZxNipk): y3LbIjrZvcATpNDM.append(zQGaM7ctZCN(u"࠷࠸᷾"))
			if not y3LbIjrZvcATpNDM: y3LbIjrZvcATpNDM = [yUMRP0QKIzY9BDnsV784TZmwkf(u"࠱࠺᷿")]
			for BF0Ns1WhLkzuxj8rOGpdAPfYE9c in y3LbIjrZvcATpNDM:
				if str(BF0Ns1WhLkzuxj8rOGpdAPfYE9c)==hnVLZboC3vXOgpr5w1TWYJeqMRE7:
					khqge7BVD9jPFy1S8T5Gn4QAlH(GISOTJh20W(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᳳ"),kL0nT7NpZdKVD3jM2OHB+idaKcvOmbRrkW1CtHhZfeAJQV4D,idaKcvOmbRrkW1CtHhZfeAJQV4D,TDpFsQXHze2q30uYtGPfEIm8(u"࠲࠸࠹Ḁ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,Pv5DNzy6UQjF8stwG+VVvcQpCU3OM09n(u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᳴"))
	BDaObUfKHVYQ4gdjRxnPIWuGqZpFLJ(RFb4YfvJSsWCy7Z0,RFb4YfvJSsWCy7Z0,DnruJV9OfB70TSdt1zcCsWl3wFMI8E)
	return
def acIxFuoBJR(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	TpGRx3umFIEKey1i0XNz8CnJ = VJZIMkUN5siqB21Pf
	if TpGRx3umFIEKey1i0XNz8CnJ:
		khqge7BVD9jPFy1S8T5Gn4QAlH(yylSaxCLfkte(u"ࠧ࡭࡫ࡱ࡯ࠬᳵ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨฬะำ๏ัࠠใษษ้ฮࠦรใีส้ࠥࡏࡐࡕࡘࠪᳶ"),CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"࠹࠹࠸ḁ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡢࡇࡗࡋࡁࡕࡇࡑࡉ࡜ࡥࠧ᳷"),CJlTSEpZsWb0QHg5w,{yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡪࡴࡲࡤࡦࡴࠪ᳸"):DDQHXmOsdnJVtK})
		khqge7BVD9jPFy1S8T5Gn4QAlH(TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡱ࡯࡮࡬ࠩ᳹"),Dj62UpP5MrbTkJqhRa+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪᳺ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"࠼࠽࠾࠿Ḃ"))
	aPSGEUtMOfV7IlTdh6C4rpcsYBi = Ew2zQ8u7Ss.menuItemsLIST[:]
	import Da6LhPonbt
	if DDQHXmOsdnJVtK:
		if not Da6LhPonbt.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(DDQHXmOsdnJVtK,w2qb6lf5EM): return
		weB81EHyzA5QSpsdghiFIqa0U = nRQX5qeSYH0w(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
		hA9Pip7QNB0mMR = sorted(weB81EHyzA5QSpsdghiFIqa0U,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe].lower())
	else:
		if not Da6LhPonbt.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(CJlTSEpZsWb0QHg5w,w2qb6lf5EM): return
		if TpGRx3umFIEKey1i0XNz8CnJ and mi2ZJXCDzITuyev6gfn(u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ᳻") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
			hA9Pip7QNB0mMR = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,o2FdrDBimMuOw97q6QpNW8S(u"ࠧ࡭࡫ࡶࡸࠬ᳼"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡍࡕ࡚ࡖࠨ᳽"),yylSaxCLfkte(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡎࡖࡔࡗࡡࡄࡐࡑ࠭᳾"))
		else:
			tQNp14fW7wBIyJYSuFLKVEM6g3rHse,hA9Pip7QNB0mMR,weB81EHyzA5QSpsdghiFIqa0U = [],[],[]
			for NpviozmcaJMUT9QKfuI in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
				hA9Pip7QNB0mMR += nRQX5qeSYH0w(str(NpviozmcaJMUT9QKfuI),gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
			for type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in hA9Pip7QNB0mMR:
				if FMxeyLvnzabpJhCXgS6T not in tQNp14fW7wBIyJYSuFLKVEM6g3rHse:
					tQNp14fW7wBIyJYSuFLKVEM6g3rHse.append(FMxeyLvnzabpJhCXgS6T)
					eiEGsfQVL4H9WXNhFnxkjBu = type,idaKcvOmbRrkW1CtHhZfeAJQV4D,FMxeyLvnzabpJhCXgS6T,s97s2k0LJgl(u"࠵࠻࠻ḃ"),t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
					weB81EHyzA5QSpsdghiFIqa0U.append(eiEGsfQVL4H9WXNhFnxkjBu)
			hA9Pip7QNB0mMR = sorted(weB81EHyzA5QSpsdghiFIqa0U,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe].lower())
			if TpGRx3umFIEKey1i0XNz8CnJ: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,ZP1LyUCS3pIBu(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤࡏࡐࡕࡘࠪ᳿"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࡣࡆࡒࡌࠨᴀ"),hA9Pip7QNB0mMR,XlNnqz758Zeuo)
	Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi+hA9Pip7QNB0mMR
	nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def Wrnb9lUNjIThFxKuV5v6(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	TpGRx3umFIEKey1i0XNz8CnJ = VJZIMkUN5siqB21Pf
	if TpGRx3umFIEKey1i0XNz8CnJ:
		khqge7BVD9jPFy1S8T5Gn4QAlH(ZP1LyUCS3pIBu(u"ࠬࡲࡩ࡯࡭ࠪᴁ"),cbmeD4WNZfAowxT2JdUMtV(u"࠭สฮัํฯ่ࠥวว็ฬࠤศ่ำศ็ࠣࡑ࠸࡛ࠧᴂ"),CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"࠼࠼࠵Ḅ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᴃ"),CJlTSEpZsWb0QHg5w,{h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᴄ"):DDQHXmOsdnJVtK})
		khqge7BVD9jPFy1S8T5Gn4QAlH(E6xdOMpqISHZCn(u"ࠩ࡯࡭ࡳࡱࠧᴅ"),Dj62UpP5MrbTkJqhRa+cjVhOCwybeRo7UWg92(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࠨᴆ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"࠿࠹࠺࠻ḅ"))
	aPSGEUtMOfV7IlTdh6C4rpcsYBi = Ew2zQ8u7Ss.menuItemsLIST[:]
	import vQnI182HJr
	if DDQHXmOsdnJVtK:
		if not vQnI182HJr.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(DDQHXmOsdnJVtK,w2qb6lf5EM): return
		weB81EHyzA5QSpsdghiFIqa0U = Rklq1SyhxETOD5C(DDQHXmOsdnJVtK,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
		hA9Pip7QNB0mMR = sorted(weB81EHyzA5QSpsdghiFIqa0U,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe].lower())
	else:
		if not vQnI182HJr.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(CJlTSEpZsWb0QHg5w,w2qb6lf5EM): return
		if TpGRx3umFIEKey1i0XNz8CnJ and VVvcQpCU3OM09n(u"ࠫࡤࡉࡒࡆࡃࡗࡉࡓࡋࡗࡠࠩᴇ") not in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
			hA9Pip7QNB0mMR = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,yylSaxCLfkte(u"ࠬࡲࡩࡴࡶࠪᴈ"),JACnOz297UuDK5HpPkc1LF(u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࡠࡏ࠶࡙ࠬᴉ"),GISOTJh20W(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࡡࡐ࠷࡚ࡥࡁࡍࡎࠪᴊ"))
		else:
			tQNp14fW7wBIyJYSuFLKVEM6g3rHse,hA9Pip7QNB0mMR,weB81EHyzA5QSpsdghiFIqa0U = [],[],[]
			for NpviozmcaJMUT9QKfuI in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
				hA9Pip7QNB0mMR += Rklq1SyhxETOD5C(str(NpviozmcaJMUT9QKfuI),gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
			for type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in hA9Pip7QNB0mMR:
				if FMxeyLvnzabpJhCXgS6T not in tQNp14fW7wBIyJYSuFLKVEM6g3rHse:
					tQNp14fW7wBIyJYSuFLKVEM6g3rHse.append(FMxeyLvnzabpJhCXgS6T)
					eiEGsfQVL4H9WXNhFnxkjBu = type,idaKcvOmbRrkW1CtHhZfeAJQV4D,FMxeyLvnzabpJhCXgS6T,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠱࠷࠷Ḇ"),t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
					weB81EHyzA5QSpsdghiFIqa0U.append(eiEGsfQVL4H9WXNhFnxkjBu)
			hA9Pip7QNB0mMR = sorted(weB81EHyzA5QSpsdghiFIqa0U,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe].lower())
			if TpGRx3umFIEKey1i0XNz8CnJ: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࡢࡑ࠸࡛ࠧᴋ"),E6xdOMpqISHZCn(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡒ࠹ࡕࡠࡃࡏࡐࠬᴌ"),hA9Pip7QNB0mMR,XlNnqz758Zeuo)
	Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi+hA9Pip7QNB0mMR
	nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def AIfymqjS8zuHJXoxh5bZ0MRcgT(group,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	TpGRx3umFIEKey1i0XNz8CnJ = VJZIMkUN5siqB21Pf
	SD0TxMRXiep4cjPBsnzI = []
	uU27JPxlTs8ykRwOV = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡣࡎࡖࡔࡗࡡࠪᴍ") if Olh7n0zfV4(u"ࠫࡎࡖࡔࡗࠩᴎ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU else xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡥࡍ࠴ࡗࡢࠫᴏ")
	if TpGRx3umFIEKey1i0XNz8CnJ: SD0TxMRXiep4cjPBsnzI = JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,XB4CjMkPFzhAHiI3q(u"࠭࡬ࡪࡵࡷࠫᴐ"),zQGaM7ctZCN(u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠩᴑ")+uU27JPxlTs8ykRwOV[:-P2Fgh6TCOWoaHjkqBcQnvRNXe],group)
	if not SD0TxMRXiep4cjPBsnzI:
		for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
			if TpGRx3umFIEKey1i0XNz8CnJ: SD0TxMRXiep4cjPBsnzI += JCLGIhgx1M9eEicOwf(NN4DuIqLH9iGesZocawQTUWm0E,Olh7n0zfV4(u"ࠨ࡮࡬ࡷࡹ࠭ᴒ"),XB4CjMkPFzhAHiI3q(u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࠫᴓ")+uU27JPxlTs8ykRwOV[:-P2Fgh6TCOWoaHjkqBcQnvRNXe],zQGaM7ctZCN(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࠬᴔ")+uU27JPxlTs8ykRwOV+str(DDQHXmOsdnJVtK))
			elif uU27JPxlTs8ykRwOV==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡤࡏࡐࡕࡘࡢࠫᴕ"): SD0TxMRXiep4cjPBsnzI += nRQX5qeSYH0w(str(DDQHXmOsdnJVtK),otNfFapeEnO(u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪᴖ"))
			elif uU27JPxlTs8ykRwOV==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭࡟ࡎ࠵ࡘࡣࠬᴗ"): SD0TxMRXiep4cjPBsnzI += Rklq1SyhxETOD5C(str(DDQHXmOsdnJVtK),cjVhOCwybeRo7UWg92(u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࠬᴘ"))
		for type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in SD0TxMRXiep4cjPBsnzI:
			if FMxeyLvnzabpJhCXgS6T==group: M4g7Ho2s8EhVxbyN1d0n(type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
		items,B5vY7qZAFfeTcXnpCGP9SRr0kaHV = [],[]
		for type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in Ew2zQ8u7Ss.menuItemsLIST:
			pzGvr5luCwIcKExZVgmSHabi = type,idaKcvOmbRrkW1CtHhZfeAJQV4D[P3cpaLN2sH:],url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,CJlTSEpZsWb0QHg5w
			if pzGvr5luCwIcKExZVgmSHabi not in B5vY7qZAFfeTcXnpCGP9SRr0kaHV:
				B5vY7qZAFfeTcXnpCGP9SRr0kaHV.append(pzGvr5luCwIcKExZVgmSHabi)
				jglfWFcvo1mAdH9yeROS7XKNxu = type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh
				items.append(jglfWFcvo1mAdH9yeROS7XKNxu)
		SD0TxMRXiep4cjPBsnzI = sorted(items,reverse=VJZIMkUN5siqB21Pf,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe].lower()[JACnOz297UuDK5HpPkc1LF(u"࠶ḇ"):])
		if TpGRx3umFIEKey1i0XNz8CnJ: JGFzPBowen2i0HI(NN4DuIqLH9iGesZocawQTUWm0E,yylSaxCLfkte(u"ࠨࡕࡈࡇ࡙ࡏࡏࡏࡕࠪᴙ")+uU27JPxlTs8ykRwOV[:-P2Fgh6TCOWoaHjkqBcQnvRNXe],group,SD0TxMRXiep4cjPBsnzI,XlNnqz758Zeuo)
	if TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫᴚ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU and len(SD0TxMRXiep4cjPBsnzI)>QcrHeGYFuatln7KBA6VJyhDIOz1qpf:
		Ew2zQ8u7Ss.menuItemsLIST[:] = []
		khqge7BVD9jPFy1S8T5Gn4QAlH(Olh7n0zfV4(u"ࠪࡪࡴࡲࡤࡦࡴࠪᴛ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡠ࠭ᴜ")+Dj62UpP5MrbTkJqhRa+group+oOQaRxBXyJ5jVnZ+mi2ZJXCDzITuyev6gfn(u"ࠬࠦ࠺ศๆๅื๊ࡣࠧᴝ"),group,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠳࠹࠹Ḉ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,uU27JPxlTs8ykRwOV+yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴞ"))
		khqge7BVD9jPFy1S8T5Gn4QAlH(yylSaxCLfkte(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᴟ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠨว฼หิฯࠠศๆฺ่อࠦวๅ฻ื์ฬฬ๊ࠡ็้ࠤ๋็ำࠡษ็ๆุ๋ࠧᴠ"),group,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠴࠺࠺ḉ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,uU27JPxlTs8ykRwOV+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᴡ"))
		khqge7BVD9jPFy1S8T5Gn4QAlH(GISOTJh20W(u"ࠪࡰ࡮ࡴ࡫ࠨᴢ"),Dj62UpP5MrbTkJqhRa+VVvcQpCU3OM09n(u"ࠫࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩᴣ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,zQGaM7ctZCN(u"࠽࠾࠿࠹Ḋ"))
		SD0TxMRXiep4cjPBsnzI = Ew2zQ8u7Ss.menuItemsLIST+D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(SD0TxMRXiep4cjPBsnzI,QcrHeGYFuatln7KBA6VJyhDIOz1qpf)
	Ew2zQ8u7Ss.menuItemsLIST[:] = SD0TxMRXiep4cjPBsnzI
	nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def QwU8LcVxvR5tXjD(gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	khqge7BVD9jPFy1S8T5Gn4QAlH(VVvcQpCU3OM09n(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᴤ"),VVvcQpCU3OM09n(u"࠭ลฺษาอࠥ฽ไษࠢๅ๊ํอสࠡ฻ื์ฬฬ๊สࠩᴥ"),CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"࠶࠼࠱ḋ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧᴦ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(KA26GucUHOwXL(u"ࠨ࡮࡬ࡲࡰ࠭ᴧ"),Dj62UpP5MrbTkJqhRa+KA26GucUHOwXL(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᴨ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠿࠹࠺࠻Ḍ"))
	m8McTYW91khDAKvFg = Ew2zQ8u7Ss.menuItemsLIST[:]
	Ew2zQ8u7Ss.menuItemsLIST[:] = []
	import jU4XwEi6mt
	jU4XwEi6mt.fJYhg7Z9iHuRPrUDQWFB(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪ࠴ࠬᴩ"),VJZIMkUN5siqB21Pf)
	jU4XwEi6mt.fJYhg7Z9iHuRPrUDQWFB(rC5tnFDlQcRGA2(u"ࠫ࠶࠭ᴪ"),VJZIMkUN5siqB21Pf)
	jU4XwEi6mt.fJYhg7Z9iHuRPrUDQWFB(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬ࠸ࠧᴫ"),VJZIMkUN5siqB21Pf)
	if ZP1LyUCS3pIBu(u"࠭࡟ࡓࡃࡑࡈࡔࡓ࡟ࠨᴬ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		Ew2zQ8u7Ss.menuItemsLIST[:] = r5lxAUZ4TscS(Ew2zQ8u7Ss.menuItemsLIST)
		if len(Ew2zQ8u7Ss.menuItemsLIST)>QcrHeGYFuatln7KBA6VJyhDIOz1qpf: Ew2zQ8u7Ss.menuItemsLIST[:] = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(Ew2zQ8u7Ss.menuItemsLIST,QcrHeGYFuatln7KBA6VJyhDIOz1qpf)
	Ew2zQ8u7Ss.menuItemsLIST[:] = m8McTYW91khDAKvFg+Ew2zQ8u7Ss.menuItemsLIST
	return
def XZ5UPzfVJWTmYQxgpcOat29A(gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	gKL8iaPh9sTzdx7ANOfVpbRrcHGkU = gKL8iaPh9sTzdx7ANOfVpbRrcHGkU.replace(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᴭ"),CJlTSEpZsWb0QHg5w).replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᴮ"),CJlTSEpZsWb0QHg5w)
	headers = { NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᴯ") : CJlTSEpZsWb0QHg5w }
	url = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡨࡷࡹࡸࡡ࡯ࡦࡲࡱࡸ࠴ࡣࡰ࡯࠲ࡶࡦࡴࡤࡰ࡯࠰ࡥࡷࡧࡢࡪࡥ࠰ࡻࡴࡸࡤࡴࠩᴰ")
	data = {GISOTJh20W(u"ࠫࡶࡻࡡ࡯ࡶ࡬ࡸࡾ࠭ᴱ"):zQGaM7ctZCN(u"ࠬ࠻࠰ࠨᴲ")}
	data = Hc6rjXpgb3CZuVKYk(data)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(zz5iuewhAFONn8GQc0DtyKZ317pHo,JACnOz297UuDK5HpPkc1LF(u"࠭ࡇࡆࡖࠪᴳ"),url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠧࡓࡃࡑࡈࡔࡓࡓ࠮ࡔࡄࡒࡉࡕࡍࡠࡘࡌࡈࡊࡕࡓࡠࡈࡕࡓࡒࡥࡗࡐࡔࡇࡗ࠲࠷ࡳࡵࠩᴴ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall(HaTI5u1f3SCxmMAkw(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠤࠪᴵ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
	items = Zy2l0g8QU5vqefaTrsw.findall(s97s2k0LJgl(u"ࠩ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧᴶ"),D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	AZELHWKbU5BnyDMYP7e06V3wJ,gShlHGZ0KTRx3F6WQcv2n8 = list(zip(*items))
	boHVQiCm7xN9SzA1ltRfMnBU = []
	wwJYREiFe0GHkdahPjn = [YvOQBzaTAscXR9ql,cbmeD4WNZfAowxT2JdUMtV(u"ࠪࠦࠬᴷ"),E6xdOMpqISHZCn(u"ࠫࡥ࠭ᴸ"),HaTI5u1f3SCxmMAkw(u"ࠬ࠲ࠧᴹ"),mi2ZJXCDzITuyev6gfn(u"࠭࠮ࠨᴺ"),GISOTJh20W(u"ࠧ࠻ࠩᴻ"),cbmeD4WNZfAowxT2JdUMtV(u"ࠨ࠽ࠪᴼ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠤࠪࠦᴽ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪ࠱ࠬᴾ")]
	g6ukT7LWs2mfX9iI = gShlHGZ0KTRx3F6WQcv2n8+AZELHWKbU5BnyDMYP7e06V3wJ
	for nncUKMExpRjsIuhaV5gvAfLNC3 in g6ukT7LWs2mfX9iI:
		if nncUKMExpRjsIuhaV5gvAfLNC3 in gShlHGZ0KTRx3F6WQcv2n8: nep7Rc2kNoCYH = VTadWjBloMwXO2CH9GDK6FR
		if nncUKMExpRjsIuhaV5gvAfLNC3 in AZELHWKbU5BnyDMYP7e06V3wJ: nep7Rc2kNoCYH = P3cpaLN2sH
		IIwoWphBvX = [PMTRpXQvDIkiNszwYGnb32a in nncUKMExpRjsIuhaV5gvAfLNC3 for PMTRpXQvDIkiNszwYGnb32a in wwJYREiFe0GHkdahPjn]
		if any(IIwoWphBvX):
			lDgx8hPyYJvcX = IIwoWphBvX.index(w2qb6lf5EM)
			LA71boEHwxPZ6WiYSyvCleF8kdR0Q = wwJYREiFe0GHkdahPjn[lDgx8hPyYJvcX]
			cS1jzUQYv7lX8DgVitr6BNGLPM = CJlTSEpZsWb0QHg5w
			if nncUKMExpRjsIuhaV5gvAfLNC3.count(LA71boEHwxPZ6WiYSyvCleF8kdR0Q)>P2Fgh6TCOWoaHjkqBcQnvRNXe: kbEi9a7NOd80y4FerIlBAwg,uY6RBfvqwDZJL8KjadMch,cS1jzUQYv7lX8DgVitr6BNGLPM = nncUKMExpRjsIuhaV5gvAfLNC3.split(LA71boEHwxPZ6WiYSyvCleF8kdR0Q,VTadWjBloMwXO2CH9GDK6FR)
			else: kbEi9a7NOd80y4FerIlBAwg,uY6RBfvqwDZJL8KjadMch = nncUKMExpRjsIuhaV5gvAfLNC3.split(LA71boEHwxPZ6WiYSyvCleF8kdR0Q,P2Fgh6TCOWoaHjkqBcQnvRNXe)
			if len(kbEi9a7NOd80y4FerIlBAwg)>nep7Rc2kNoCYH: boHVQiCm7xN9SzA1ltRfMnBU.append(kbEi9a7NOd80y4FerIlBAwg.lower())
			if len(uY6RBfvqwDZJL8KjadMch)>nep7Rc2kNoCYH: boHVQiCm7xN9SzA1ltRfMnBU.append(uY6RBfvqwDZJL8KjadMch.lower())
			if len(cS1jzUQYv7lX8DgVitr6BNGLPM)>nep7Rc2kNoCYH: boHVQiCm7xN9SzA1ltRfMnBU.append(cS1jzUQYv7lX8DgVitr6BNGLPM.lower())
		elif len(nncUKMExpRjsIuhaV5gvAfLNC3)>nep7Rc2kNoCYH: boHVQiCm7xN9SzA1ltRfMnBU.append(nncUKMExpRjsIuhaV5gvAfLNC3.lower())
	for PMTRpXQvDIkiNszwYGnb32a in range(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠹ḍ")): D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.shuffle(boHVQiCm7xN9SzA1ltRfMnBU)
	if TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬᴿ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		zQClb9Bv7W6PYT1c8 = wt8VeLoQTG2A49pSNF5
	elif zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᵀ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		zQClb9Bv7W6PYT1c8 = [TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡉࡑࡖ࡙ࠫᵁ")]
		import Da6LhPonbt
		if not Da6LhPonbt.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(CJlTSEpZsWb0QHg5w,w2qb6lf5EM): return
	elif yylSaxCLfkte(u"ࠧࡠࡏ࠶࡙ࡤ࠭ᵂ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		zQClb9Bv7W6PYT1c8 = [GISOTJh20W(u"ࠨࡏ࠶࡙ࠬᵃ")]
		import vQnI182HJr
		if not vQnI182HJr.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(CJlTSEpZsWb0QHg5w,w2qb6lf5EM): return
	count,NbYZBpihSkzey0 = ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
	khqge7BVD9jPFy1S8T5Gn4QAlH(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡩࡳࡱࡪࡥࡳࠩᵄ"),ZP1LyUCS3pIBu(u"ࠪ࡟ࠥࠦ࡝ࠡ࠼ส่อำหࠡ฻้ࠫᵅ"),CJlTSEpZsWb0QHg5w,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠲࠸࠷Ḏ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵆ")+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
	khqge7BVD9jPFy1S8T5Gn4QAlH(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵇ"),JACnOz297UuDK5HpPkc1LF(u"࠭ลฺษาอࠥอไษฯฮࠤฬู๊ี๊สส๏࠭ᵈ"),CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"࠳࠹࠸ḏ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᵉ")+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
	khqge7BVD9jPFy1S8T5Gn4QAlH(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ࡮࡬ࡲࡰ࠭ᵊ"),Dj62UpP5MrbTkJqhRa+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᵋ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"࠼࠽࠾࠿Ḑ"))
	LDMo6FqngUzY = Ew2zQ8u7Ss.menuItemsLIST[:]
	Ew2zQ8u7Ss.menuItemsLIST[:] = []
	Xz95Pd8E2L74cawG = []
	for nncUKMExpRjsIuhaV5gvAfLNC3 in boHVQiCm7xN9SzA1ltRfMnBU:
		uY6RBfvqwDZJL8KjadMch = Zy2l0g8QU5vqefaTrsw.findall(rC5tnFDlQcRGA2(u"ࠪ࡟ࠥࡢࠬ࡝࠽࡟࠾ࡡ࠳࡜ࠬ࡞ࡀࡠࠧࡢࠧ࡝࡝࡟ࡡࡡ࠮࡜ࠪ࡞ࡾࡠࢂࡢࠡ࡝ࡂࠪᵌ")+cbmeD4WNZfAowxT2JdUMtV(u"ࠫࠨ࠭ᵍ")+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡢࠤ࡝ࠧ࡟ࡢࡡࠬ࡜ࠫ࡞ࡢࡠࡁࡢ࠾࡞ࠩᵎ"),nncUKMExpRjsIuhaV5gvAfLNC3,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if uY6RBfvqwDZJL8KjadMch: nncUKMExpRjsIuhaV5gvAfLNC3 = nncUKMExpRjsIuhaV5gvAfLNC3.split(uY6RBfvqwDZJL8KjadMch[ZVNvqy4iF1a9X],P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		ZeW3r05A7a6fgCsSpcdm = nncUKMExpRjsIuhaV5gvAfLNC3.replace(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭๑ࠨᵏ"),CJlTSEpZsWb0QHg5w).replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧ๏ࠩᵐ"),CJlTSEpZsWb0QHg5w).replace(JACnOz297UuDK5HpPkc1LF(u"ࠨํࠪᵑ"),CJlTSEpZsWb0QHg5w).replace(yylSaxCLfkte(u"ࠩ๒ࠫᵒ"),CJlTSEpZsWb0QHg5w).replace(XB4CjMkPFzhAHiI3q(u"ࠪ๐ࠬᵓ"),CJlTSEpZsWb0QHg5w)
		ZeW3r05A7a6fgCsSpcdm = ZeW3r05A7a6fgCsSpcdm.replace(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫ๕࠭ᵔ"),CJlTSEpZsWb0QHg5w).replace(mi2ZJXCDzITuyev6gfn(u"ࠬ๓ࠧᵕ"),CJlTSEpZsWb0QHg5w).replace(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭๒ࠨᵖ"),CJlTSEpZsWb0QHg5w).replace(O4F8UC5lMAS6ghETm1VoPDI(u"ࠧญࠩᵗ"),CJlTSEpZsWb0QHg5w).replace(zQGaM7ctZCN(u"ࠨโࠪᵘ"),CJlTSEpZsWb0QHg5w)
		if ZeW3r05A7a6fgCsSpcdm: Xz95Pd8E2L74cawG.append(ZeW3r05A7a6fgCsSpcdm)
	uVoDbAvl7CWUXY = []
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(ZVNvqy4iF1a9X,TMfV6892ZoBdyxCH3tGrkwY0K(u"࠶࠵ḑ")):
		search = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(Xz95Pd8E2L74cawG,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		if search in uVoDbAvl7CWUXY: continue
		uVoDbAvl7CWUXY.append(search)
		ad3z2451e09FrDHmvci = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(zQClb9Bv7W6PYT1c8,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+XB4CjMkPFzhAHiI3q(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥ࡜ࡩࡥࡧࡲࠤࡘ࡫ࡡࡳࡥ࡫ࠤࠥࠦࡳࡪࡶࡨ࠾ࠬᵙ")+str(ad3z2451e09FrDHmvci)+yylSaxCLfkte(u"ࠪࠤࠥࡹࡥࡢࡴࡦ࡬࠿࠭ᵚ")+search)
		jJRFufHp4y0KoasdBXqkEGl,x3L5fIUkM6czApTHVJtoWN8b4i,FTbIBSC3OLPvyaZjqK7 = ebr4GOKs6IT8wcNhjHZD(ad3z2451e09FrDHmvci)
		x3L5fIUkM6czApTHVJtoWN8b4i(search+cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡤࡔࡏࡅࡋࡄࡐࡔࡍࡓࡠࠩᵛ"))
		if len(Ew2zQ8u7Ss.menuItemsLIST)>ZVNvqy4iF1a9X: break
	search = search.replace(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡥࡍࡐࡆࡢࠫᵜ"),CJlTSEpZsWb0QHg5w)
	LDMo6FqngUzY[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe] = Olh7n0zfV4(u"࡛࠭ࠨᵝ")+Dj62UpP5MrbTkJqhRa+search+oOQaRxBXyJ5jVnZ+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࠡ࠼หัะูࠦ็࡟ࠪᵞ")
	Ew2zQ8u7Ss.menuItemsLIST[:] = r5lxAUZ4TscS(Ew2zQ8u7Ss.menuItemsLIST)
	if len(Ew2zQ8u7Ss.menuItemsLIST)>QcrHeGYFuatln7KBA6VJyhDIOz1qpf: Ew2zQ8u7Ss.menuItemsLIST[:] = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(Ew2zQ8u7Ss.menuItemsLIST,QcrHeGYFuatln7KBA6VJyhDIOz1qpf)
	Ew2zQ8u7Ss.menuItemsLIST[:] = LDMo6FqngUzY+Ew2zQ8u7Ss.menuItemsLIST
	return
def byPFhZJpjcLqH09NIQ(u2ETqyzR6wGoINm8KQbfWO1deZUr4,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU):
	u2ETqyzR6wGoINm8KQbfWO1deZUr4 = u2ETqyzR6wGoINm8KQbfWO1deZUr4.replace(cjVhOCwybeRo7UWg92(u"ࠨࡡࡐࡓࡉࡥࠧᵟ"),CJlTSEpZsWb0QHg5w)
	gKL8iaPh9sTzdx7ANOfVpbRrcHGkU = gKL8iaPh9sTzdx7ANOfVpbRrcHGkU.replace(VVvcQpCU3OM09n(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᵠ"),CJlTSEpZsWb0QHg5w).replace(mi2ZJXCDzITuyev6gfn(u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵡ"),CJlTSEpZsWb0QHg5w)
	YWhMUAHvGnspLZ2gaKDd8mR3NJwxFb(VJZIMkUN5siqB21Pf)
	if not hxd4FlkHos03zf86RPDXQjt: return
	if cjVhOCwybeRo7UWg92(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᵢ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᵣ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࡛࠭ࠨᵤ")+Dj62UpP5MrbTkJqhRa+u2ETqyzR6wGoINm8KQbfWO1deZUr4+oOQaRxBXyJ5jVnZ+TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࠡ࠼ส่็ูๅ࡞ࠩᵥ"),u2ETqyzR6wGoINm8KQbfWO1deZUr4,TMfV6892ZoBdyxCH3tGrkwY0K(u"࠶࠼࠶Ḓ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵦ")+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
		khqge7BVD9jPFy1S8T5Gn4QAlH(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡩࡳࡱࡪࡥࡳࠩᵧ"),rC5tnFDlQcRGA2(u"ࠪษ฾อฯสࠢส่฼๊ศࠡษ็฽ู๎วว์้๋ࠣࠦๆโีࠣห้่ำๆࠩᵨ"),u2ETqyzR6wGoINm8KQbfWO1deZUr4,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠷࠶࠷ḓ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵩ")+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
		khqge7BVD9jPFy1S8T5Gn4QAlH(JACnOz297UuDK5HpPkc1LF(u"ࠬࡲࡩ࡯࡭ࠪᵪ"),Dj62UpP5MrbTkJqhRa+O4F8UC5lMAS6ghETm1VoPDI(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫᵫ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"࠹࠺࠻࠼Ḕ"))
	for website in sorted(list(hxd4FlkHos03zf86RPDXQjt[u2ETqyzR6wGoINm8KQbfWO1deZUr4].keys())):
		type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = hxd4FlkHos03zf86RPDXQjt[u2ETqyzR6wGoINm8KQbfWO1deZUr4][website]
		if Olh7n0zfV4(u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩᵬ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU or len(hxd4FlkHos03zf86RPDXQjt[u2ETqyzR6wGoINm8KQbfWO1deZUr4])==P2Fgh6TCOWoaHjkqBcQnvRNXe:
			M4g7Ho2s8EhVxbyN1d0n(type,CJlTSEpZsWb0QHg5w,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w)
			Ew2zQ8u7Ss.menuItemsLIST[:] = r5lxAUZ4TscS(Ew2zQ8u7Ss.menuItemsLIST)
			aPSGEUtMOfV7IlTdh6C4rpcsYBi,hA9Pip7QNB0mMR = Ew2zQ8u7Ss.menuItemsLIST[:D9yBM7wPFLz],Ew2zQ8u7Ss.menuItemsLIST[D9yBM7wPFLz:]
			if xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪᵭ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
				for PMTRpXQvDIkiNszwYGnb32a in range(Olh7n0zfV4(u"࠺ḕ")): D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.shuffle(hA9Pip7QNB0mMR)
				Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi+hA9Pip7QNB0mMR[:QcrHeGYFuatln7KBA6VJyhDIOz1qpf]
			else: Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi+hA9Pip7QNB0mMR
		elif KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡢࡗࡎ࡚ࡅࡔࡡࠪᵮ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: khqge7BVD9jPFy1S8T5Gn4QAlH(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡪࡴࡲࡤࡦࡴࠪᵯ"),website,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	return
def aHmsWdwL8RoDvEQgu9702rKI(gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,BEUVvSQtRimC):
	gKL8iaPh9sTzdx7ANOfVpbRrcHGkU = gKL8iaPh9sTzdx7ANOfVpbRrcHGkU.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᵰ"),CJlTSEpZsWb0QHg5w).replace(VVvcQpCU3OM09n(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᵱ"),CJlTSEpZsWb0QHg5w)
	idaKcvOmbRrkW1CtHhZfeAJQV4D,hA9Pip7QNB0mMR = CJlTSEpZsWb0QHg5w,[]
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᵲ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧ࡜ࠩᵳ")+Dj62UpP5MrbTkJqhRa+idaKcvOmbRrkW1CtHhZfeAJQV4D+oOQaRxBXyJ5jVnZ+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪᵴ"),CJlTSEpZsWb0QHg5w,BEUVvSQtRimC,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᵵ")+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
	khqge7BVD9jPFy1S8T5Gn4QAlH(pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡪࡴࡲࡤࡦࡴࠪᵶ"),VVvcQpCU3OM09n(u"ࠫส฿วะหࠣ฻้ฮࠠใี่ࠤ฾ฺ่ศศํࠫᵷ"),CJlTSEpZsWb0QHg5w,BEUVvSQtRimC,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᵸ")+gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
	khqge7BVD9jPFy1S8T5Gn4QAlH(TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭࡬ࡪࡰ࡮ࠫᵹ"),Dj62UpP5MrbTkJqhRa+JACnOz297UuDK5HpPkc1LF(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬᵺ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"࠻࠼࠽࠾Ḗ"))
	aPSGEUtMOfV7IlTdh6C4rpcsYBi = Ew2zQ8u7Ss.menuItemsLIST[:]
	Ew2zQ8u7Ss.menuItemsLIST[:] = []
	SD0TxMRXiep4cjPBsnzI = []
	if otNfFapeEnO(u"ࠨࡡࡖࡍ࡙ࡋࡓࡠࠩᵻ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		YWhMUAHvGnspLZ2gaKDd8mR3NJwxFb(VJZIMkUN5siqB21Pf)
		if not hxd4FlkHos03zf86RPDXQjt: return
		Anx8fIMruRmoBiQ1NYs = list(hxd4FlkHos03zf86RPDXQjt.keys())
		u2ETqyzR6wGoINm8KQbfWO1deZUr4 = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(Anx8fIMruRmoBiQ1NYs,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		boHVQiCm7xN9SzA1ltRfMnBU = list(hxd4FlkHos03zf86RPDXQjt[u2ETqyzR6wGoINm8KQbfWO1deZUr4].keys())
		website = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(boHVQiCm7xN9SzA1ltRfMnBU,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = hxd4FlkHos03zf86RPDXQjt[u2ETqyzR6wGoINm8KQbfWO1deZUr4][website]
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࠣࠤࠥࡘࡡ࡯ࡦࡲࡱࠥࡉࡡࡵࡧࡪࡳࡷࡿࠠࠡࠢࡺࡩࡧࡹࡩࡵࡧ࠽ࠤࠬᵼ")+website+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࠤࠥࠦ࡮ࡢ࡯ࡨ࠾ࠥ࠭ᵽ")+idaKcvOmbRrkW1CtHhZfeAJQV4D+zQGaM7ctZCN(u"ࠫࠥࠦࠠࡶࡴ࡯࠾ࠥ࠭ᵾ")+url+JACnOz297UuDK5HpPkc1LF(u"ࠬࠦࠠࠡ࡯ࡲࡨࡪࡀࠠࠨᵿ")+str(wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO))
	elif cbmeD4WNZfAowxT2JdUMtV(u"࠭࡟ࡊࡒࡗ࡚ࡤ࠭ᶀ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		import Da6LhPonbt
		if not Da6LhPonbt.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(CJlTSEpZsWb0QHg5w,w2qb6lf5EM): return
		for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
			SD0TxMRXiep4cjPBsnzI += nRQX5qeSYH0w(str(DDQHXmOsdnJVtK),gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
		if not SD0TxMRXiep4cjPBsnzI: return
		type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(SD0TxMRXiep4cjPBsnzI,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+HaTI5u1f3SCxmMAkw(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧᶁ")+idaKcvOmbRrkW1CtHhZfeAJQV4D+yylSaxCLfkte(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪᶂ")+url+ZP1LyUCS3pIBu(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬᶃ")+str(wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO))
	elif zQGaM7ctZCN(u"ࠪࡣࡒ࠹ࡕࡠࠩᶄ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		import vQnI182HJr
		if not vQnI182HJr.Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(CJlTSEpZsWb0QHg5w,w2qb6lf5EM): return
		for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
			SD0TxMRXiep4cjPBsnzI += Rklq1SyhxETOD5C(str(DDQHXmOsdnJVtK),gKL8iaPh9sTzdx7ANOfVpbRrcHGkU)
		if not SD0TxMRXiep4cjPBsnzI: return
		type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(SD0TxMRXiep4cjPBsnzI,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫᶅ")+idaKcvOmbRrkW1CtHhZfeAJQV4D+cjVhOCwybeRo7UWg92(u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧᶆ")+url+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩᶇ")+str(wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO))
	RcfYirJBZqXdjWTSUNy8ak5 = idaKcvOmbRrkW1CtHhZfeAJQV4D
	TIO5i1EnL7PY2sq6DhQ3 = []
	for PMTRpXQvDIkiNszwYGnb32a in range(ZVNvqy4iF1a9X,mi2ZJXCDzITuyev6gfn(u"࠴࠴ḗ")):
		if PMTRpXQvDIkiNszwYGnb32a>ZVNvqy4iF1a9X: JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+HaTI5u1f3SCxmMAkw(u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧᶈ")+idaKcvOmbRrkW1CtHhZfeAJQV4D+XB4CjMkPFzhAHiI3q(u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪᶉ")+url+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬᶊ")+str(wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO))
		Ew2zQ8u7Ss.menuItemsLIST[:] = []
		if wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==TDpFsQXHze2q30uYtGPfEIm8(u"࠶࠸࠺Ḙ") and od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᶋ") in FMxeyLvnzabpJhCXgS6T: wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO = cjVhOCwybeRo7UWg92(u"࠷࠹࠳ḙ")
		if wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==HaTI5u1f3SCxmMAkw(u"࠽࠱࠵Ḛ") and yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡤࡥࡍ࠴ࡗࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᶌ") in FMxeyLvnzabpJhCXgS6T: wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠷࠲࠵ḛ")
		if wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==pz4WBwfyDdgk0m2aRr7SMv(u"࠲࠶࠷Ḝ"): wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO = cbmeD4WNZfAowxT2JdUMtV(u"࠴࠼࠵ḝ")
		Cm7xuRTdLQwZjv81V2AhKfqs04U = M4g7Ho2s8EhVxbyN1d0n(type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
		if yylSaxCLfkte(u"ࠬࡥࡉࡑࡖ࡙ࡣࠬᶍ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU and wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==VVvcQpCU3OM09n(u"࠴࠺࠼Ḟ"): del Ew2zQ8u7Ss.menuItemsLIST[:D9yBM7wPFLz]
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭࡟ࡎ࠵ࡘࡣࠬᶎ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU and wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==mi2ZJXCDzITuyev6gfn(u"࠵࠻࠾ḟ"): del Ew2zQ8u7Ss.menuItemsLIST[:D9yBM7wPFLz]
		hA9Pip7QNB0mMR[:] = r5lxAUZ4TscS(Ew2zQ8u7Ss.menuItemsLIST)
		if TIO5i1EnL7PY2sq6DhQ3 and lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࡵࠨฯ็ๆฮ࠭ᶏ")) in str(hA9Pip7QNB0mMR) or lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(s97s2k0LJgl(u"ࡶࠩะ่็ํࠧᶐ")) in str(hA9Pip7QNB0mMR):
			idaKcvOmbRrkW1CtHhZfeAJQV4D = RcfYirJBZqXdjWTSUNy8ak5
			hA9Pip7QNB0mMR[:] = TIO5i1EnL7PY2sq6DhQ3
			break
		RcfYirJBZqXdjWTSUNy8ak5 = idaKcvOmbRrkW1CtHhZfeAJQV4D
		TIO5i1EnL7PY2sq6DhQ3 = hA9Pip7QNB0mMR
		if str(hA9Pip7QNB0mMR).count(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡹ࡭ࡩ࡫࡯ࠨᶑ"))>ZVNvqy4iF1a9X: break
		if str(hA9Pip7QNB0mMR).count(TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡰ࡮ࡼࡥࠨᶒ"))>ZVNvqy4iF1a9X: break
		if wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==Olh7n0zfV4(u"࠷࠹࠳Ḡ"): break
		if wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==GISOTJh20W(u"࠽࠱࠴ḡ"): break
		if wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO==GISOTJh20W(u"࠲࠺࠳Ḣ"): break
		if XB4CjMkPFzhAHiI3q(u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭ᶓ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU and hA9Pip7QNB0mMR: type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,wyxXBk0qLD6Zb24rcQ3I1WRdEFi8nO,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(hA9Pip7QNB0mMR,P2Fgh6TCOWoaHjkqBcQnvRNXe)[ZVNvqy4iF1a9X]
	if not idaKcvOmbRrkW1CtHhZfeAJQV4D: idaKcvOmbRrkW1CtHhZfeAJQV4D = ZP1LyUCS3pIBu(u"ࠬ࠴࠮࠯࠰ࠪᶔ")
	elif idaKcvOmbRrkW1CtHhZfeAJQV4D.count(VVvcQpCU3OM09n(u"࠭࡟ࠨᶕ"))>P2Fgh6TCOWoaHjkqBcQnvRNXe: idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.split(E6xdOMpqISHZCn(u"ࠧࡠࠩᶖ"),VTadWjBloMwXO2CH9GDK6FR)[VTadWjBloMwXO2CH9GDK6FR]
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡗࡑࡏࡓࡕࡗࡏ࠼ࠣࠫᶗ"),CJlTSEpZsWb0QHg5w)
	idaKcvOmbRrkW1CtHhZfeAJQV4D = idaKcvOmbRrkW1CtHhZfeAJQV4D.replace(ZP1LyUCS3pIBu(u"ࠩࡢࡑࡔࡊ࡟ࠨᶘ"),CJlTSEpZsWb0QHg5w)
	aPSGEUtMOfV7IlTdh6C4rpcsYBi[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe] = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪ࡟ࠬᶙ")+Dj62UpP5MrbTkJqhRa+idaKcvOmbRrkW1CtHhZfeAJQV4D+oOQaRxBXyJ5jVnZ+pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࠥࡀวๅไึ้ࡢ࠭ᶚ")
	if O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧᶛ") in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU:
		for PMTRpXQvDIkiNszwYGnb32a in range(s97s2k0LJgl(u"࠺ḣ")): D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.shuffle(hA9Pip7QNB0mMR)
		Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi+hA9Pip7QNB0mMR[:QcrHeGYFuatln7KBA6VJyhDIOz1qpf]
	else: Ew2zQ8u7Ss.menuItemsLIST[:] = aPSGEUtMOfV7IlTdh6C4rpcsYBi+hA9Pip7QNB0mMR
	return
def WWoh4lQzqvSNaf(gOv5891U3AmTo2Chzp7MPfkcGYdH,nKtUlSCkQEXq82wFdJsO4zi):
	nKtUlSCkQEXq82wFdJsO4zi = nKtUlSCkQEXq82wFdJsO4zi.replace(ZP1LyUCS3pIBu(u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᶜ"),CJlTSEpZsWb0QHg5w).replace(otNfFapeEnO(u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᶝ"),CJlTSEpZsWb0QHg5w)
	lqFvWIRSCxtbroVgdUhu = nKtUlSCkQEXq82wFdJsO4zi
	if h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩᶞ") in nKtUlSCkQEXq82wFdJsO4zi:
		lqFvWIRSCxtbroVgdUhu = nKtUlSCkQEXq82wFdJsO4zi.split(yylSaxCLfkte(u"ࠩࡢࡣࡎࡖࡔࡗࡕࡨࡶ࡮࡫ࡳࡠࡡࠪᶟ"))[ZVNvqy4iF1a9X]
		type = zQGaM7ctZCN(u"ࠪ࠰ࡘࡋࡒࡊࡇࡖ࠾ࠥ࠭ᶠ")
	elif VVvcQpCU3OM09n(u"࡛ࠫࡕࡄࠨᶡ") in gOv5891U3AmTo2Chzp7MPfkcGYdH: type = pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࠲ࡖࡊࡆࡈࡓࡘࡀࠠࠨᶢ")
	elif JACnOz297UuDK5HpPkc1LF(u"࠭ࡌࡊࡘࡈࠫᶣ") in gOv5891U3AmTo2Chzp7MPfkcGYdH: type = cjVhOCwybeRo7UWg92(u"ࠧ࠭ࡎࡌ࡚ࡊࡀࠠࠨᶤ")
	khqge7BVD9jPFy1S8T5Gn4QAlH(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᶥ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࡞ࠫᶦ")+Dj62UpP5MrbTkJqhRa+type+lqFvWIRSCxtbroVgdUhu+oOQaRxBXyJ5jVnZ+VVvcQpCU3OM09n(u"ࠪࠤ࠿อไใี่ࡡࠬᶧ"),gOv5891U3AmTo2Chzp7MPfkcGYdH,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠳࠹࠻Ḥ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶨ")+nKtUlSCkQEXq82wFdJsO4zi)
	khqge7BVD9jPFy1S8T5Gn4QAlH(ZP1LyUCS3pIBu(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᶩ"),TDpFsQXHze2q30uYtGPfEIm8(u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬᶪ"),gOv5891U3AmTo2Chzp7MPfkcGYdH,GISOTJh20W(u"࠴࠺࠼ḥ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,JACnOz297UuDK5HpPkc1LF(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬᶫ")+nKtUlSCkQEXq82wFdJsO4zi)
	khqge7BVD9jPFy1S8T5Gn4QAlH(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࡮࡬ࡲࡰ࠭ᶬ"),Dj62UpP5MrbTkJqhRa+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦࠧᶭ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,Olh7n0zfV4(u"࠽࠾࠿࠹Ḧ"))
	import Da6LhPonbt
	for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
		if mi2ZJXCDzITuyev6gfn(u"ࠪࡣࡤࡏࡐࡕࡘࡖࡩࡷ࡯ࡥࡴࡡࡢࠫᶮ") in nKtUlSCkQEXq82wFdJsO4zi: Da6LhPonbt.S8k6PsUIHu3L05T1fB(str(DDQHXmOsdnJVtK),gOv5891U3AmTo2Chzp7MPfkcGYdH,nKtUlSCkQEXq82wFdJsO4zi,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf)
		else: Da6LhPonbt.fJYhg7Z9iHuRPrUDQWFB(str(DDQHXmOsdnJVtK),gOv5891U3AmTo2Chzp7MPfkcGYdH,nKtUlSCkQEXq82wFdJsO4zi,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf)
	Ew2zQ8u7Ss.menuItemsLIST[:] = r5lxAUZ4TscS(Ew2zQ8u7Ss.menuItemsLIST)
	if len(Ew2zQ8u7Ss.menuItemsLIST)>(QcrHeGYFuatln7KBA6VJyhDIOz1qpf+D9yBM7wPFLz): Ew2zQ8u7Ss.menuItemsLIST[:] = Ew2zQ8u7Ss.menuItemsLIST[:D9yBM7wPFLz]+D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(Ew2zQ8u7Ss.menuItemsLIST[D9yBM7wPFLz:],QcrHeGYFuatln7KBA6VJyhDIOz1qpf)
	return
def hgaUQE8ztwrnOeFv4X5T6kx(gOv5891U3AmTo2Chzp7MPfkcGYdH,nKtUlSCkQEXq82wFdJsO4zi):
	nKtUlSCkQEXq82wFdJsO4zi = nKtUlSCkQEXq82wFdJsO4zi.replace(zQGaM7ctZCN(u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᶯ"),CJlTSEpZsWb0QHg5w).replace(GISOTJh20W(u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩᶰ"),CJlTSEpZsWb0QHg5w)
	lqFvWIRSCxtbroVgdUhu = nKtUlSCkQEXq82wFdJsO4zi
	if XB4CjMkPFzhAHiI3q(u"࠭࡟ࡠࡏ࠶࡙ࡘ࡫ࡲࡪࡧࡶࡣࡤ࠭ᶱ") in nKtUlSCkQEXq82wFdJsO4zi:
		lqFvWIRSCxtbroVgdUhu = nKtUlSCkQEXq82wFdJsO4zi.split(VVvcQpCU3OM09n(u"ࠧࡠࡡࡐ࠷࡚࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧᶲ"))[ZVNvqy4iF1a9X]
		type = otNfFapeEnO(u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫᶳ")
	elif JACnOz297UuDK5HpPkc1LF(u"࡙ࠩࡓࡉ࠭ᶴ") in gOv5891U3AmTo2Chzp7MPfkcGYdH: type = TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭ᶵ")
	elif Olh7n0zfV4(u"ࠫࡑࡏࡖࡆࠩᶶ") in gOv5891U3AmTo2Chzp7MPfkcGYdH: type = cbmeD4WNZfAowxT2JdUMtV(u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭ᶷ")
	khqge7BVD9jPFy1S8T5Gn4QAlH(VVvcQpCU3OM09n(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᶸ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠧ࡜ࠩᶹ")+Dj62UpP5MrbTkJqhRa+type+lqFvWIRSCxtbroVgdUhu+oOQaRxBXyJ5jVnZ+XB4CjMkPFzhAHiI3q(u"ࠨࠢ࠽ห้่ำๆ࡟ࠪᶺ"),gOv5891U3AmTo2Chzp7MPfkcGYdH,zQGaM7ctZCN(u"࠶࠼࠸ḧ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᶻ")+nKtUlSCkQEXq82wFdJsO4zi)
	khqge7BVD9jPFy1S8T5Gn4QAlH(o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡪࡴࡲࡤࡦࡴࠪᶼ"),Olh7n0zfV4(u"ࠫส฿วะหࠣห้฽ไษࠢส่฾ฺ่ศศํࠤ๊์ࠠ็ใึࠤฬ๊โิ็ࠪᶽ"),gOv5891U3AmTo2Chzp7MPfkcGYdH,TDpFsQXHze2q30uYtGPfEIm8(u"࠷࠶࠹Ḩ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪᶾ")+nKtUlSCkQEXq82wFdJsO4zi)
	khqge7BVD9jPFy1S8T5Gn4QAlH(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭࡬ࡪࡰ࡮ࠫᶿ"),Dj62UpP5MrbTkJqhRa+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬ᷀")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠹࠺࠻࠼ḩ"))
	import vQnI182HJr
	for DDQHXmOsdnJVtK in range(P2Fgh6TCOWoaHjkqBcQnvRNXe,baPq30VI6TOmUnQJ+P2Fgh6TCOWoaHjkqBcQnvRNXe):
		if mi2ZJXCDzITuyev6gfn(u"ࠨࡡࡢࡑ࠸࡛ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ᷁") in nKtUlSCkQEXq82wFdJsO4zi: vQnI182HJr.S8k6PsUIHu3L05T1fB(str(DDQHXmOsdnJVtK),gOv5891U3AmTo2Chzp7MPfkcGYdH,nKtUlSCkQEXq82wFdJsO4zi,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf)
		else: vQnI182HJr.fJYhg7Z9iHuRPrUDQWFB(str(DDQHXmOsdnJVtK),gOv5891U3AmTo2Chzp7MPfkcGYdH,nKtUlSCkQEXq82wFdJsO4zi,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf)
	Ew2zQ8u7Ss.menuItemsLIST[:] = r5lxAUZ4TscS(Ew2zQ8u7Ss.menuItemsLIST)
	if len(Ew2zQ8u7Ss.menuItemsLIST)>(QcrHeGYFuatln7KBA6VJyhDIOz1qpf+D9yBM7wPFLz): Ew2zQ8u7Ss.menuItemsLIST[:] = Ew2zQ8u7Ss.menuItemsLIST[:D9yBM7wPFLz]+D5fy1ouOjwT9RXlH4IEhe3dMPmaxz.sample(Ew2zQ8u7Ss.menuItemsLIST[D9yBM7wPFLz:],QcrHeGYFuatln7KBA6VJyhDIOz1qpf)
	return
def r5lxAUZ4TscS(R0gZeisqfX):
	kFmsTYw8A6 = []
	for type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh in R0gZeisqfX:
		if KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ุࠩๅาฯ᷂ࠧ") in idaKcvOmbRrkW1CtHhZfeAJQV4D or zz679V18GdcZwvrRexA0nNptY2Tab(u"ูࠪๆำ็ࠨ᷃") in idaKcvOmbRrkW1CtHhZfeAJQV4D or s97s2k0LJgl(u"ࠫࡵࡧࡧࡦࠩ᷄") in idaKcvOmbRrkW1CtHhZfeAJQV4D.lower(): continue
		kFmsTYw8A6.append([type,idaKcvOmbRrkW1CtHhZfeAJQV4D,url,BEUVvSQtRimC,t4zynV13ZoPe,GOF25jkXb1DnaB4vhL9,FMxeyLvnzabpJhCXgS6T,QQa9t5k6BLqflRNr,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh])
	return kFmsTYw8A6
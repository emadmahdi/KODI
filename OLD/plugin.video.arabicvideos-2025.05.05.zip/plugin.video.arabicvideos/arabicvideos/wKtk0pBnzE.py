# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'EGYBEST1'
kL0nT7NpZdKVD3jM2OHB = '_EB1_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['مكتبتي','ايجي بست']
def hH3sRBSFAr(mode,url,GOF25jkXb1DnaB4vhL9,text):
	if   mode==770: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==771: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9)
	elif mode==772: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==773: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==774: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'FULL_FILTER___'+text)
	elif mode==775: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'DEFINED_FILTER___'+text)
	elif mode==776: SD0TxMRXiep4cjPBsnzI = bFsHpJmxDSgKNdReElj(url,GOF25jkXb1DnaB4vhL9)
	elif mode==779: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text,url)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,779,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST1-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('nav-list(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)</span>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			if any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,771)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-article(.*?)social-box',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('main-title.*?">(.*?)<.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,ZgsbN5iSL48t2IhVFnmy in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,771,CJlTSEpZsWb0QHg5w,'mainmenu')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-menu(.*?)</div></div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,771)
	return bGIVq1CQTjmosZg
def bFsHpJmxDSgKNdReElj(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST1-SEASONS_EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-article".*?">(.*?)<(.*?)article',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		K5ic8ROYfn1,iypksRX5aYC,items = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,[]
		for name,D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
			if 'حلقات' in name: iypksRX5aYC = D3D6TF50oUBtJlvijPMW8ys
			if 'مواسم' in name: K5ic8ROYfn1 = D3D6TF50oUBtJlvijPMW8ys
		if K5ic8ROYfn1 and not type:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',K5ic8ROYfn1,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if len(items)>1:
				for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,776,hzGKUP1XjAoeT79MJcDF,'season')
		if iypksRX5aYC and len(items)<2:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',iypksRX5aYC,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if items:
				for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
					khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,773,hzGKUP1XjAoeT79MJcDF)
			else:
				items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',iypksRX5aYC,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,title in items:
					khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,773)
	return
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST1-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items,g63IdQelXYianvKNxZr82kUGR,YUIwPVo4qucC7935ZW = [],False,False
	if not type:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-content(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</i>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,771,CJlTSEpZsWb0QHg5w,'submenu')
				g63IdQelXYianvKNxZr82kUGR = True
	if not type and 'p=' not in url:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('searchform(.*?)</form>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			if g63IdQelXYianvKNxZr82kUGR: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر محدد',url,775,CJlTSEpZsWb0QHg5w,'filter')
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر كامل',url,774,CJlTSEpZsWb0QHg5w,'filter')
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث',url,779)
			khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
			YUIwPVo4qucC7935ZW = True
	if not g63IdQelXYianvKNxZr82kUGR:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('blocks(.*?)article',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
				hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.strip(rJ9cgWz4FU)
				ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy)
				if '/serie/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,776,hzGKUP1XjAoeT79MJcDF,'season')
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,773,hzGKUP1XjAoeT79MJcDF)
			GOF25jkXb1DnaB4vhL9 = '1'
			if 'p=' in url: url,GOF25jkXb1DnaB4vhL9 = url.split('p=',1)
			PBrsIxTjg1ec3VO0zJKl5oYLRpFUX = '&' if '?' in url else '?'
			url = url+PBrsIxTjg1ec3VO0zJKl5oYLRpFUX
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(GOF25jkXb1DnaB4vhL9)+1)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الصفحة التالية',url,771)
			elif GOF25jkXb1DnaB4vhL9!='1':
				url = url+'p='+str(int(GOF25jkXb1DnaB4vhL9)-1)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الصفحة السابقة',url,771)
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST1-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('<label>التصنيف</label>.*?">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	steS3aGdomU,FhX9OGwaNyAEZ,RDwZryfhWXz735Gb6A1dqICExS = [],[],[]
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('download-section.*?action="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		if ZgsbN5iSL48t2IhVFnmy not in RDwZryfhWXz735Gb6A1dqICExS:
			RDwZryfhWXz735Gb6A1dqICExS.append(ZgsbN5iSL48t2IhVFnmy)
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named=__embed______'+O4Ak3NXpyUHvE(url))
	p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('WatchServers(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall("url='(.*?)'.*?>(.*?)<",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,FFtJQalhPz in Rp1g7OlotseGnf0NFmKk6rLxd:
			if ZgsbN5iSL48t2IhVFnmy not in RDwZryfhWXz735Gb6A1dqICExS:
				RDwZryfhWXz735Gb6A1dqICExS.append(ZgsbN5iSL48t2IhVFnmy)
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__both______'+O4Ak3NXpyUHvE(url))
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search,url=CJlTSEpZsWb0QHg5w):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if not search: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'%20')
	if not url: url = V4kF6EQiwo+'/search?query='+QjfknOVHzZIUir
	else: url = url+'?title='+QjfknOVHzZIUir+'&genre=&year=&lang='
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
def oRdVakZGH609MievEIKTyB(url):
	url = url.split('/smartemadfilter?')[0]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('form-row(.*?)</form>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		bXYD7OZPULlNcp6gtSEMWiau5FAdy = Zy2l0g8QU5vqefaTrsw.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		DBmwSrWc5hLaR3I4XHb86y2jtO1,CCImnA9gHWYJreXMB,p3LfChWJd124eAYj78zw09SXonH = zip(*bXYD7OZPULlNcp6gtSEMWiau5FAdy)
		bXYD7OZPULlNcp6gtSEMWiau5FAdy = zip(CCImnA9gHWYJreXMB,DBmwSrWc5hLaR3I4XHb86y2jtO1,p3LfChWJd124eAYj78zw09SXonH)
	return bXYD7OZPULlNcp6gtSEMWiau5FAdy
def rrxJkwNntpTHQiO6yvEZFocC(D3D6TF50oUBtJlvijPMW8ys):
	items = Zy2l0g8QU5vqefaTrsw.findall('value="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	return items
def OPJyENVHqRaAcj2gZ(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
HHRLnzapUIMAqJhB9o31E8 = ['year','lang','genre']
UxHo4glmcr = ['year','lang','genre']
def wwkAylgOx852(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='DEFINED_FILTER':
		if UxHo4glmcr[0]+'=' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = UxHo4glmcr[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(UxHo4glmcr[0:-1])):
			if UxHo4glmcr[PMTRpXQvDIkiNszwYGnb32a]+'=' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = UxHo4glmcr[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+y3LbIjrZvcATpNDM+'=0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+y3LbIjrZvcATpNDM+'=0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&')+'___'+YYvW68idVrJQFa.strip('&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'all')
		BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='FULL_FILTER':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'all')
		if not bnCVRhKEGJ0DIYqUBsgdpm: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+bnCVRhKEGJ0DIYqUBsgdpm
		ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها ',ysw7G3tqjo,771,CJlTSEpZsWb0QHg5w,'filter')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',ysw7G3tqjo,771,CJlTSEpZsWb0QHg5w,'filter')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = oRdVakZGH609MievEIKTyB(url)
	dict = {}
	for name,HLQNhXe7orPjl5Vm4,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		name = name.replace('كل ',CJlTSEpZsWb0QHg5w)
		items = rrxJkwNntpTHQiO6yvEZFocC(D3D6TF50oUBtJlvijPMW8ys)
		if '=' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='DEFINED_FILTER':
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<2:
				if HLQNhXe7orPjl5Vm4==UxHo4glmcr[-1]:
					ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
					nvHUf8mW6E4GSw5VFRXN(ysw7G3tqjo)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'DEFINED_FILTER___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				if HLQNhXe7orPjl5Vm4==UxHo4glmcr[-1]:
					ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع ',ysw7G3tqjo,771,CJlTSEpZsWb0QHg5w,'filter')
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع ',BBwfuWGxUIrdCoc4ka7,775,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='FULL_FILTER':
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'=0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'=0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع :'+name,BBwfuWGxUIrdCoc4ka7,774,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		dict[HLQNhXe7orPjl5Vm4] = {}
		for value,ll5WFBCJKhA64tIDT8qvX in items:
			if not value: continue
			if ll5WFBCJKhA64tIDT8qvX in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			dict[HLQNhXe7orPjl5Vm4][value] = ll5WFBCJKhA64tIDT8qvX
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'='+ll5WFBCJKhA64tIDT8qvX
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			title = ll5WFBCJKhA64tIDT8qvX+' :'#+dict[HLQNhXe7orPjl5Vm4]['0']
			title = ll5WFBCJKhA64tIDT8qvX+' :'+name
			if type=='FULL_FILTER': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,774,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
			elif type=='DEFINED_FILTER' and UxHo4glmcr[-2]+'=' in LLnTmNF7UG4:
				mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'modified_filters')
				BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+mmMRqiu1zXvWZlK7hAgEQn
				ysw7G3tqjo = OPJyENVHqRaAcj2gZ(BBwfuWGxUIrdCoc4ka7)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ysw7G3tqjo,771,CJlTSEpZsWb0QHg5w,'filter')
			elif type=='DEFINED_FILTER': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,775,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.replace('=&','=0&')
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&')
	Sucv4JD0rRPaBL8HFMjNt = {}
	if '=' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('=')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	fuTzgEqmbRX378cwQnJH9rhFCt = CJlTSEpZsWb0QHg5w
	for key in HHRLnzapUIMAqJhB9o31E8:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if '%' not in value: value = O4Ak3NXpyUHvE(value)
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
		elif mode=='all': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.replace('=0','=')
	return fuTzgEqmbRX378cwQnJH9rhFCt
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'EGYDEAD'
kL0nT7NpZdKVD3jM2OHB = '_EGD_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['مصارعة','احدث البرامج','احدث الالعاب','الرئيسية','احدث الاغانى']
def hH3sRBSFAr(mode,url,text):
	if   mode==440: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==441: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==442: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==443: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==449: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYDEAD-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(V4kF6EQiwo,'url')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,449,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الرئيسية',V4kF6EQiwo,441)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="title_menu_right"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		if ZgsbN5iSL48t2IhVFnmy=='#': continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,441)
	return
def nvHUf8mW6E4GSw5VFRXN(url,Z9ZHlis43maAITJUwNQgS0on=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYDEAD-TITLES-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="list-related"(.*?)class="pagination"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('<li>.*?href="(.*?)".*?<h1>(.*?)</h1>.*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
		if '/url/' in ZgsbN5iSL48t2IhVFnmy: continue
		elif '/season/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,443,hzGKUP1XjAoeT79MJcDF)
		elif '/episode/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,443,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,442,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,441)
	return
def j9zTQsrVRx2(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYDEAD-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"seasons-list"(.*?)</div>.</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"episodes-list"(.*?)</div>.</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,443,hzGKUP1XjAoeT79MJcDF)
	elif KXu2RYg3Bc:
		hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('"og:image" content="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0]
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,442,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	data = {'View':1}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYDEAD-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	MNXzjK3vV7D = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"watchAreaMaster"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-link="(.*?)".*?<p>(.*?)</p>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"donwload-servers-list"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"ser-name">(.*?)</span>.*?<em>(.*?)</em>.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,egYIsS2qROfpVW83kx,ZgsbN5iSL48t2IhVFnmy in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download'+'____'+egYIsS2qROfpVW83kx
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
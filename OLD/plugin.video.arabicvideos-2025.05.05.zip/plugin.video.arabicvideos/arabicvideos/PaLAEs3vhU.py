﻿# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'ALMAAREF'
headers = {'User-Agent':CJlTSEpZsWb0QHg5w}
kL0nT7NpZdKVD3jM2OHB = '_MRF_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def hH3sRBSFAr(mode,url,text,GOF25jkXb1DnaB4vhL9):
	if   mode==40: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==41: SD0TxMRXiep4cjPBsnzI = HrVCKhtwaksjEW()
	elif mode==42: SD0TxMRXiep4cjPBsnzI = KA6yD5mspPfq2w1R(text,GOF25jkXb1DnaB4vhL9)
	elif mode==43: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==44: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(text,GOF25jkXb1DnaB4vhL9)
	elif mode==49: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,49)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+'البث الحي لقناة المعارف',CJlTSEpZsWb0QHg5w,41)
	KA6yD5mspPfq2w1R(CJlTSEpZsWb0QHg5w,'1')
	return
def oLeM4kRvP7abOAXNy9lzY6T5nhWKFH(EcrV3IasOo4Hq,NbnV4aUlwXk):
	search,sort,DzhMXqK6x3mVg9y,y3LbIjrZvcATpNDM,UUCpomMvbF9QyldiTHW72E5 = CJlTSEpZsWb0QHg5w,[],[],[],[]
	Cm7xuRTdLQwZjv81V2AhKfqs04U,bkLGvg5s7ZBwiX4e6x3 = degRiWptawTqXvKNh(EcrV3IasOo4Hq)
	for ll5WFBCJKhA64tIDT8qvX in list(bkLGvg5s7ZBwiX4e6x3.keys()):
		value = bkLGvg5s7ZBwiX4e6x3[ll5WFBCJKhA64tIDT8qvX]
		if not value: continue
		if   ll5WFBCJKhA64tIDT8qvX=='sort': sort = [value]
		elif ll5WFBCJKhA64tIDT8qvX=='series': DzhMXqK6x3mVg9y = [value]
		elif ll5WFBCJKhA64tIDT8qvX=='search': search = value
		elif ll5WFBCJKhA64tIDT8qvX=='category': y3LbIjrZvcATpNDM = [value]
		elif ll5WFBCJKhA64tIDT8qvX=='specialist': UUCpomMvbF9QyldiTHW72E5 = [value]
	wSfEHOilLYIK = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":y3LbIjrZvcATpNDM,"specialist":UUCpomMvbF9QyldiTHW72E5,"series":DzhMXqK6x3mVg9y,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(NbnV4aUlwXk)}}
	wSfEHOilLYIK = KSHcVmz2W84iQvbRDBhGldpCL.dumps(wSfEHOilLYIK)
	ZgsbN5iSL48t2IhVFnmy = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',ZgsbN5iSL48t2IhVFnmy,wSfEHOilLYIK,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	data = oE7iT3HI5VDdmY4kPOjr('dict',bGIVq1CQTjmosZg)
	return data
def KA6yD5mspPfq2w1R(EcrV3IasOo4Hq,level):
	p3LfChWJd124eAYj78zw09SXonH = oLeM4kRvP7abOAXNy9lzY6T5nhWKFH(EcrV3IasOo4Hq,'1')
	D3D6TF50oUBtJlvijPMW8ys = p3LfChWJd124eAYj78zw09SXonH['facets']
	if level=='1':
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys['video_categories']
		items = Zy2l0g8QU5vqefaTrsw.findall('<div(.*?)/div>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',jglfWFcvo1mAdH9yeROS7XKNxu+'<',Zy2l0g8QU5vqefaTrsw.DOTALL)
			if not he0wn71osQ8NCFJ9xzIqrDXBMRY: he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall('data-value=\\"(.*?)\\">(.*?)<',jglfWFcvo1mAdH9yeROS7XKNxu+'<',Zy2l0g8QU5vqefaTrsw.DOTALL)
			y3LbIjrZvcATpNDM,title = he0wn71osQ8NCFJ9xzIqrDXBMRY[0]
			if BB7oCRfQNSYj5qDhTUevV: title = pd0Na8D5WZfHYkysVS(title)
			if not EcrV3IasOo4Hq: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,42,CJlTSEpZsWb0QHg5w,'2','?category='+y3LbIjrZvcATpNDM)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,42,CJlTSEpZsWb0QHg5w,'2',EcrV3IasOo4Hq+'&category='+y3LbIjrZvcATpNDM)
	if level=='2':
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys['specialist']
		items = Zy2l0g8QU5vqefaTrsw.findall('value="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for UUCpomMvbF9QyldiTHW72E5,title in items:
			if BB7oCRfQNSYj5qDhTUevV: title = pd0Na8D5WZfHYkysVS(title)
			if not UUCpomMvbF9QyldiTHW72E5: title = title = 'الجميع'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,42,CJlTSEpZsWb0QHg5w,'3',EcrV3IasOo4Hq+'&specialist='+UUCpomMvbF9QyldiTHW72E5)
	elif level=='3':
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys['series']
		items = Zy2l0g8QU5vqefaTrsw.findall('value="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for DzhMXqK6x3mVg9y,title in items:
			if BB7oCRfQNSYj5qDhTUevV: title = pd0Na8D5WZfHYkysVS(title)
			if not DzhMXqK6x3mVg9y: title = title = 'الجميع'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,42,CJlTSEpZsWb0QHg5w,'4',EcrV3IasOo4Hq+'&series='+DzhMXqK6x3mVg9y)
	elif level=='4':
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys['sort_video']
		items = Zy2l0g8QU5vqefaTrsw.findall('value="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for sort,title in items:
			if not sort: continue
			if BB7oCRfQNSYj5qDhTUevV: title = pd0Na8D5WZfHYkysVS(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,44,CJlTSEpZsWb0QHg5w,'1',EcrV3IasOo4Hq+'&sort='+sort)
	return
def nvHUf8mW6E4GSw5VFRXN(EcrV3IasOo4Hq,NbnV4aUlwXk):
	p3LfChWJd124eAYj78zw09SXonH = oLeM4kRvP7abOAXNy9lzY6T5nhWKFH(EcrV3IasOo4Hq,NbnV4aUlwXk)
	D3D6TF50oUBtJlvijPMW8ys = p3LfChWJd124eAYj78zw09SXonH['template']
	items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		if BB7oCRfQNSYj5qDhTUevV: title = pd0Na8D5WZfHYkysVS(title)
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,43,hzGKUP1XjAoeT79MJcDF)
	D3D6TF50oUBtJlvijPMW8ys = p3LfChWJd124eAYj78zw09SXonH['facets']['pagination']
	items = Zy2l0g8QU5vqefaTrsw.findall('data-page="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for GOF25jkXb1DnaB4vhL9,title in items:
		if NbnV4aUlwXk==GOF25jkXb1DnaB4vhL9: continue
		if BB7oCRfQNSYj5qDhTUevV: title = pd0Na8D5WZfHYkysVS(title)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,CJlTSEpZsWb0QHg5w,44,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,EcrV3IasOo4Hq)
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMAAREF-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('<video src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('youtube_url.*?(http.*?)&',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	FhX9OGwaNyAEZ = []
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0].replace('\/','/')
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HrVCKhtwaksjEW():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo+'/بث-مباشر',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMAAREF-LIVE-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	url = Zy2l0g8QU5vqefaTrsw.findall('"svpPlayer".*?(http.*?)&',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	url = url[0].replace('\\',CJlTSEpZsWb0QHg5w)
	ZQtv0jY9W6L8UHgpnKm(url,T1QDsJlUtCGhn,'live')
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	DpFaX93smJlOfCQGIxu = False
	if search==CJlTSEpZsWb0QHg5w:
		search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		DpFaX93smJlOfCQGIxu = True
	if search==CJlTSEpZsWb0QHg5w: return
	if not DpFaX93smJlOfCQGIxu: nvHUf8mW6E4GSw5VFRXN('?search='+search,'1')
	else: KA6yD5mspPfq2w1R('?search='+search,'1')
	return
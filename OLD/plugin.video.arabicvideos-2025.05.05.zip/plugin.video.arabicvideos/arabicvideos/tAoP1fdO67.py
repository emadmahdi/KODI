# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from kUCfvjAP1c import *
T1QDsJlUtCGhn = VVvcQpCU3OM09n(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠭น")
def hH3sRBSFAr(BEUVvSQtRimC,FMxeyLvnzabpJhCXgS6T=CJlTSEpZsWb0QHg5w):
	if   BEUVvSQtRimC==o2FdrDBimMuOw97q6QpNW8S(u"࠴ჱ"): Bvr7nVQbzg29W3pU8kKO5G1eE(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠶ჲ"): pass
	elif BEUVvSQtRimC==ZP1LyUCS3pIBu(u"࠸ჳ"): FeDaQc6MWl7(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==s97s2k0LJgl(u"࠳ჴ"): nEuCBY1qp6rNvPXGyF()
	elif BEUVvSQtRimC==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠵ჵ"): DDWykc36s9qCldbrRe(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠷ჶ"): QZapr9EA6yI3VNUH0G4MexF17bYhc()
	elif BEUVvSQtRimC==mi2ZJXCDzITuyev6gfn(u"࠹ჷ"): YPvl3tzWXfojDk()
	elif BEUVvSQtRimC==ZP1LyUCS3pIBu(u"࠻ჸ"): fxdNEv1heTwKZ6WrC()
	elif BEUVvSQtRimC==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠽ჹ"): QluZO17FXPoAIsU6aTrH()
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠷࠵࠱ჺ"): mm0wQKXGtP9MS7W()
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠱࠶࠳჻"): iisCDrREWA7()
	elif BEUVvSQtRimC==Olh7n0zfV4(u"࠲࠷࠵ჼ"): y6wFgHkKD8YLv25oX()
	elif BEUVvSQtRimC==TDpFsQXHze2q30uYtGPfEIm8(u"࠳࠸࠷ჽ"): EEXA94z2iDCTSPxBVqnpfed()
	elif BEUVvSQtRimC==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠴࠹࠹ჾ"): bRZ6YSFiMBzQL9()
	elif BEUVvSQtRimC==Olh7n0zfV4(u"࠵࠺࠻ჿ"): y8HsaKODVlSw4TeNpJ()
	elif BEUVvSQtRimC==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠶࠻࠶ᄀ"): zKyXalGV8J6L()
	elif BEUVvSQtRimC==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠷࠵࠸ᄁ"): ggyTRIkM2sQh9H0qjuwDEJate3x()
	elif BEUVvSQtRimC==o2FdrDBimMuOw97q6QpNW8S(u"࠱࠶࠺ᄂ"): yn3tg8rchHoj4i1Q9R2AN7ezGbZ()
	elif BEUVvSQtRimC==zz679V18GdcZwvrRexA0nNptY2Tab(u"࠲࠷࠼ᄃ"): MBbzLpFV7iKohH9SYk2QlE(w2qb6lf5EM)
	elif BEUVvSQtRimC==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠳࠺࠴ᄄ"): JD8h3ncMo9z4TrqU5fNbaVp1jOGW7()
	elif BEUVvSQtRimC==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠴࠻࠶ᄅ"): SEzRivcwpDKox7VC()
	elif BEUVvSQtRimC==KA26GucUHOwXL(u"࠵࠼࠸ᄆ"): jjTNmoGUqkaS36hcsDbgWHwyZQM4Jn([FMxeyLvnzabpJhCXgS6T],w2qb6lf5EM,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
	elif BEUVvSQtRimC==pz4WBwfyDdgk0m2aRr7SMv(u"࠶࠽࠳ᄇ"): nn3q8dAwhfx(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬบ"),w2qb6lf5EM)
	elif BEUVvSQtRimC==EcjO3giln2kQTdBY0XLAG(u"࠷࠷࠵ᄈ"): nn3q8dAwhfx(JACnOz297UuDK5HpPkc1LF(u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠩป"),w2qb6lf5EM)
	elif BEUVvSQtRimC==O4F8UC5lMAS6ghETm1VoPDI(u"࠱࠸࠷ᄉ"): jJOSxqwBc0GPoVaW7()
	elif BEUVvSQtRimC==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠲࠹࠹ᄊ"): uugQ85jOAaeDyFdsPk1YJWGcLI0()
	elif BEUVvSQtRimC==o2FdrDBimMuOw97q6QpNW8S(u"࠳࠺࠻ᄋ"): A5CUySeaPs(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫผ"))
	elif BEUVvSQtRimC==rC5tnFDlQcRGA2(u"࠴࠻࠾ᄌ"): A5CUySeaPs(Olh7n0zfV4(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠨฝ"))
	elif BEUVvSQtRimC==cjVhOCwybeRo7UWg92(u"࠵࠾࠶ᄍ"): T7THw29fQO()
	elif BEUVvSQtRimC==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠶࠿࠱ᄎ"): Z3ZLcI9DdAfywOvH8PgR()
	elif BEUVvSQtRimC==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠷࠹࠳ᄏ"): u4xCT9OASigmzWHJeP21()
	elif BEUVvSQtRimC==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠱࠺࠵ᄐ"): l6WRFE0gJStKwxCAZ7prza()
	elif BEUVvSQtRimC==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠲࠻࠷ᄑ"): rUkP54WoxAT2QD()
	elif BEUVvSQtRimC==E6xdOMpqISHZCn(u"࠳࠼࠹ᄒ"): F0LIQ451lcjkgUAus867qJrb()
	elif BEUVvSQtRimC==zz679V18GdcZwvrRexA0nNptY2Tab(u"࠴࠽࠻ᄓ"): fjVA1R8HOFxdQ()
	elif BEUVvSQtRimC==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠵࠾࠽ᄔ"): YsFHA4JPQg3pUhd8bTn7()
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠶࠿࠸ᄕ"): e9U6BpvfrNJ()
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠷࠹࠺ᄖ"): dmr8PhA7ZLWtvpk4c2SqN()
	elif BEUVvSQtRimC==XB4CjMkPFzhAHiI3q(u"࠳࠵࠲ᄗ"): OCuIKRAQ1X8rvBi9(FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==TDpFsQXHze2q30uYtGPfEIm8(u"࠴࠶࠴ᄘ"): xVOWPbGFg1YI6sieKQERz()
	elif BEUVvSQtRimC==otNfFapeEnO(u"࠵࠷࠶ᄙ"): p1Zc6GKEMW()
	elif BEUVvSQtRimC==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶࠸࠸ᄚ"): ApO7hXc9m1yzjZUnwWIHt()
	elif BEUVvSQtRimC==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠷࠹࠻ᄛ"): xgOa5wTKXsCFhn()
	elif BEUVvSQtRimC==zQGaM7ctZCN(u"࠸࠺࠶ᄜ"): uucYwE73JTI4ABiUWDSqxnNedH(VJZIMkUN5siqB21Pf)
	elif BEUVvSQtRimC==KA26GucUHOwXL(u"࠹࠴࠸ᄝ"): DkcrxeMRug629ZVS7FUdNlQ(w2qb6lf5EM)
	elif BEUVvSQtRimC==yylSaxCLfkte(u"࠳࠵࠺ᄞ"): pYKfqLMy4whsEebU8giAQ1W()
	elif BEUVvSQtRimC==rC5tnFDlQcRGA2(u"࠴࠶࠼ᄟ"): loBHfukKV4AGCtbFIvc7Y0eiLNJ(GISOTJh20W(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧพ"),w2qb6lf5EM,w2qb6lf5EM)
	elif BEUVvSQtRimC==O4F8UC5lMAS6ghETm1VoPDI(u"࠷࠳࠴ᄠ"): wDixZCH2O3aFjoWYEqpKNSBfUzdr()
	elif BEUVvSQtRimC==zz679V18GdcZwvrRexA0nNptY2Tab(u"࠸࠴࠶ᄡ"): nnTLsmFQ5J1uOUywpYH6I()
	elif BEUVvSQtRimC==cjVhOCwybeRo7UWg92(u"࠹࠵࠸ᄢ"): ylmBACGaNLwfVugZToFbiOY()
	elif BEUVvSQtRimC==TDpFsQXHze2q30uYtGPfEIm8(u"࠺࠶࠳ᄣ"): ahD2R6fnKoOkY1m(mw5hKxvWDZSQ)
	elif BEUVvSQtRimC==E6xdOMpqISHZCn(u"࠻࠰࠵ᄤ"): ahD2R6fnKoOkY1m(wiEebAT9Qs7dCztufUZNORv3)
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠵࠱࠷ᄥ"): mmO3EH1jAahkgBlsCnFcJ0eI7bv()
	elif BEUVvSQtRimC==EcjO3giln2kQTdBY0XLAG(u"࠶࠲࠹ᄦ"): Cdyun4OtYjmFGHTzaW6rKwf9bg3Jsq(w2qb6lf5EM)
	elif BEUVvSQtRimC==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠷࠳࠻ᄧ"): GbKdNI0A4wXrktQv6xY5UOeMH()
	elif BEUVvSQtRimC==rC5tnFDlQcRGA2(u"࠸࠴࠽ᄨ"): Ed3pvBwrR1OQ()
	elif BEUVvSQtRimC==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠵࠵࠸࠰ᄩ"): ZaYig0SsRL1X()
	elif BEUVvSQtRimC==otNfFapeEnO(u"࠶࠶࠲࠲ᄪ"): yw1ar6LEzA8KvJ0nl()
	elif BEUVvSQtRimC==cbmeD4WNZfAowxT2JdUMtV(u"࠷࠰࠳࠴ᄫ"): A5CUySeaPs(TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨฟ"))
	elif BEUVvSQtRimC==JACnOz297UuDK5HpPkc1LF(u"࠱࠱࠴࠶ᄬ"): w3iqsXYng5Zd6ovELxGMDQl()
	elif BEUVvSQtRimC==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠲࠲࠵࠸ᄭ"): u6olD7tMWYEc0NLjyXr(w2qb6lf5EM)
	return
def u6olD7tMWYEc0NLjyXr(showDialogs=VJZIMkUN5siqB21Pf):
	ZZcY93l5zPwxkVO4Im = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡧࡦࡲࡥ࠯࡭ࡨࡽࡧࡵࡡࡳࡦ࡯ࡥࡾࡵࡵࡵࡵࠥࢁࢂ࠭ภ"))
	ZZcY93l5zPwxkVO4Im = KSHcVmz2W84iQvbRDBhGldpCL.loads(ZZcY93l5zPwxkVO4Im)[cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡸࡥࡴࡷ࡯ࡸࠬม")][yylSaxCLfkte(u"࠭ࡶࡢ࡮ࡸࡩࠬย")]
	XpKwSsuCaOtJ0HLV8D,Mg1xdikKFfu5a9XPB8yv = VTadWjBloMwXO2CH9GDK6FR,ZZcY93l5zPwxkVO4Im[:]
	if showDialogs:
		MqKrNmGt0SCihdw6XHlR95UAxEWn = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠠศๆ฼ีอ๐ษࠡ็ไ฽้ฯ้ࠠฬ฼้้࠭ร") if GISOTJh20W(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨฤ") in ZZcY93l5zPwxkVO4Im else TDpFsQXHze2q30uYtGPfEIm8(u"ࠩ็์าฯࠠศๆ่ๅฬะ๊ฮࠢส่฾ืศ๋ห้ࠣฯ๎โโหࠪล")
		XpKwSsuCaOtJ0HLV8D = IUHFoP2MS7n5QBvc3ZthfdN0e(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡧࡪࡴࡴࡦࡴࠪฦ"),rC5tnFDlQcRGA2(u"ࠫำื่อࠩว"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬห๊ใษไࠫศ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭สี฼ํ่ࠬษ"),TAExSfcoNi4eORZ8HPB,Dj62UpP5MrbTkJqhRa+MqKrNmGt0SCihdw6XHlR95UAxEWn+oOQaRxBXyJ5jVnZ+rJ9cgWz4FU+rJ9cgWz4FU+O4F8UC5lMAS6ghETm1VoPDI(u"่ࠧา๊ࠤฬู๊่์ไอࠥะำๆฯࠣฬฬูสฯัส้๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦวๅ็๋ะํีษࠡใํࠤ่๎ฯ๋ࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢส๊ฯࠦสิฬฺ๎฾ࠦร็ࠢอ฽๊๊ࠠษฯฮࠤๆ๐ࠠๆ๊สๆ฾ࠦวๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣหฺ้๊สࠢส่฾ืศ๋หࠣ࠲࠳ࠦร้ࠢอืฯ฽ฺ๊ࠢฦ๊ࠥะใหสࠣีุอไสࠢ็่๊ฮัๆฮࠣฬฬ๊ไ฻หࠣห้฿ัษ์ฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦสี฼ํ่๊่ࠥฮหࠣห้๋แศฬํัࠥอไฺำห๎ฮࠦรๆࠢศ๎็อแ่ษࠣรࠦࠧࠧส"))
	if XpKwSsuCaOtJ0HLV8D==VTadWjBloMwXO2CH9GDK6FR and TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡃࡵࡥࡧ࡯ࡣࠡࡓ࡚ࡉࡗ࡚࡙ࠨห") not in ZZcY93l5zPwxkVO4Im: Mg1xdikKFfu5a9XPB8yv = [I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡔ࡛ࡊࡘࡔ࡚ࠩฬ")]+ZZcY93l5zPwxkVO4Im
	elif XpKwSsuCaOtJ0HLV8D==P2Fgh6TCOWoaHjkqBcQnvRNXe and yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡅࡷࡧࡢࡪࡥࠣࡕ࡜ࡋࡒࡕ࡛ࠪอ") in ZZcY93l5zPwxkVO4Im:
		Mg1xdikKFfu5a9XPB8yv = ZZcY93l5zPwxkVO4Im[:]
		Mg1xdikKFfu5a9XPB8yv.remove(TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡆࡸࡡࡣ࡫ࡦࠤࡖ࡝ࡅࡓࡖ࡜ࠫฮ"))
	if Mg1xdikKFfu5a9XPB8yv!=ZZcY93l5zPwxkVO4Im:
		Mg1xdikKFfu5a9XPB8yv = str(Mg1xdikKFfu5a9XPB8yv).replace(zQGaM7ctZCN(u"ࠧ࠭ࠢฯ"),VVvcQpCU3OM09n(u"࠭ࠢࠨะ"))
		SD0TxMRXiep4cjPBsnzI = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(s97s2k0LJgl(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡱࡵࡣࡢ࡮ࡨ࠲ࡰ࡫ࡹࡣࡱࡤࡶࡩࡲࡡࡺࡱࡸࡸࡸࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠩั")+Mg1xdikKFfu5a9XPB8yv+zQGaM7ctZCN(u"ࠨࡿࢀࠫา"))
		if showDialogs:
			if O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡷࡶࡺ࡫ࠧำ") in str(SD0TxMRXiep4cjPBsnzI): PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,O4F8UC5lMAS6ghETm1VoPDI(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧิ"))
			else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cjVhOCwybeRo7UWg92(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩี"))
	return
def w3iqsXYng5Zd6ovELxGMDQl():
	ksDvwLIca3bHm = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(cbmeD4WNZfAowxT2JdUMtV(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡤ࡬ࡸࡷࡧࡴࡦࠩึ"))
	message = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭วๅำๅ้ࠥอไๆฯาำࠥำวๅ์สࠤ์๎ࠠ࠻ࠢࠣࠤࠬื")+str(ksDvwLIca3bHm)+cbmeD4WNZfAowxT2JdUMtV(u"ࠧࠡ࡭ࡥࡴࡸุ࠭") if ksDvwLIca3bHm else TDpFsQXHze2q30uYtGPfEIm8(u"ࠨษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡ็อ์็็ษࠡฯส่๏อูࠧ")
	message = Dj62UpP5MrbTkJqhRa+message+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࡟ࡲ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅࠢฦ์ࠥะฺ๋์ิࠤึ่ๅࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠨฺ")+oOQaRxBXyJ5jVnZ
	LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡧࡪࡴࡴࡦࡴࠪ฻"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫำื่อࠩ฼"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬห๊ใษไࠫ฽"),Olh7n0zfV4(u"࠭สี฼ํ่ࠬ฾"),TAExSfcoNi4eORZ8HPB,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧศๆฯ์ิฯࠠศๆฦ์ฯ๎ๅศฬํ็๏ฯ่ࠠ์ࠣ฽๊๊๊สࠢํๆํ๋ࠠษ้สࠤฬ๊ศา่ส้ัࠦศศะอ๎ฬืࠠฤ฻็ํࠥา่ะห้ࠣฯ๎แาห่ࠣึ่ๅࠡษ็ะํีษࠡษ็ิ๏ࠦว็ฬࠣฮาีฯ่ࠢไ๎ࠥํะ่ࠢสู่อิสࠢ࠱࠲ࠥ๎็ัษ้ࠣ฾์ว่ࠢ฼๊ิ๋วࠡฬๅ์๊ࠦว็ฬࠣฬฯฺฺ๋ๆࠣๅ๏ี๊้ࠢไห๋ࠦวๅสิ๊ฬ๋ฬࠡๆ้ࠤ๏ูรๅๅࠣ฽๋ࠦวๅฮ๋ำฮࠦวๅฬํࠤฯื๊ะ้สࠤ้ษๆࠡษ็ฬึ์วๆฮࠣืํ็๋ࠠะอหึࠦวๅฮ๋ำฮࠦร้ฬ๋้ฬะ๊ไ์สࠤ࠳࠴ฺࠠๆ่หࠥอๆ่ࠢํะอࠦวฯฬํหึࠦัใ็ࠣะํีษࠡื฽๎ึࠦลัษࠣ็ฬ์สࠡษ็ษ๋ะั็ฬࠣ฽๋ีใࠡสฺ๎หฯࠠฤ๊ࠣๆ้๐ไส࡞ࡱࡠࡳ࠭฿")+message)
	if LfJRKzMepo0gZ in [-yylSaxCLfkte(u"࠳ᄮ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"࠳ᄯ")]: return
	if LfJRKzMepo0gZ==yUMRP0QKIzY9BDnsV784TZmwkf(u"࠵ᄰ"):
		ksDvwLIca3bHm = CJlTSEpZsWb0QHg5w
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,EcjO3giln2kQTdBY0XLAG(u"ࠨ่ฯัฯูࠦๆๆํอࠥห๊ใษไࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࠫเ"))
	else:
		items = [VVvcQpCU3OM09n(u"ࠩ࠵࠹࠵ࠦ࡫ࡣࡲࡶࠫแ"),JACnOz297UuDK5HpPkc1LF(u"ࠪ࠹࠵࠶ࠠ࡬ࡤࡳࡷࠬโ"),cjVhOCwybeRo7UWg92(u"ࠫ࠼࠻࠰ࠡ࡭ࡥࡴࡸ࠭ใ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠬ࠷࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨไ"),cjVhOCwybeRo7UWg92(u"࠭࠱࠳࠷࠳ࠤࡰࡨࡰࡴࠩๅ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠧ࠲࠷࠳࠴ࠥࡱࡢࡱࡵࠪๆ"),ZP1LyUCS3pIBu(u"ࠨ࠳࠺࠹࠵ࠦ࡫ࡣࡲࡶࠫ็"),HaTI5u1f3SCxmMAkw(u"ࠩ࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷ่ࠬ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠪ࠶࠺࠶࠰ࠡ࡭ࡥࡴࡸ้࠭"),JACnOz297UuDK5HpPkc1LF(u"ࠫ࠸࠶࠰࠱ࠢ࡮ࡦࡵࡹ๊ࠧ"),E6xdOMpqISHZCn(u"ࠬ࠹࠵࠱࠲ࠣ࡯ࡧࡶࡳࠨ๋"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭࠴࠱࠲࠳ࠤࡰࡨࡰࡴࠩ์"),JACnOz297UuDK5HpPkc1LF(u"ࠧ࠵࠷࠳࠴ࠥࡱࡢࡱࡵࠪํ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠨ࠷࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ๎"),Olh7n0zfV4(u"ࠩ࠹࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬ๏"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࠻࠵࠶࠰ࠡ࡭ࡥࡴࡸ࠭๐"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫ࠽࠶࠰࠱ࠢ࡮ࡦࡵࡹࠧ๑"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࠿࠰࠱࠲ࠣ࡯ࡧࡶࡳࠨ๒"),mi2ZJXCDzITuyev6gfn(u"࠭࠱࠱࠲࠳࠴ࠥࡱࡢࡱࡵࠪ๓"),ZP1LyUCS3pIBu(u"ࠧ࠲࠳࠳࠴࠵ࠦ࡫ࡣࡲࡶࠫ๔"),E6xdOMpqISHZCn(u"ࠨ࠳࠵࠴࠵࠶ࠠ࡬ࡤࡳࡷࠬ๕"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ࠼࠽࠾࠿࠹ࠡ࡭ࡥࡴࡸ࠭๖")]
		CrqTamtPFuU = T4TK17YsEfZJ(TDpFsQXHze2q30uYtGPfEIm8(u"ࠪหำะัࠡษ็ะํีษࠡษ็วํะ่ๆษอ๎่๐ษࠡษ็้๋อำษหࠪ๗"),items)
		if CrqTamtPFuU==-TDpFsQXHze2q30uYtGPfEIm8(u"࠶ᄱ"): return
		ksDvwLIca3bHm = str(items[CrqTamtPFuU][:-EcjO3giln2kQTdBY0XLAG(u"࠻ᄲ")])
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,O4F8UC5lMAS6ghETm1VoPDI(u"๋ࠫาอหࠢ฼้้๐ษࠡฬื฾๏๊้ࠠฬะำ๏ีࠠาไ่ࠤฬ๊ฬ้ัฬࠤฬ๊ร้ฬ๋้ฬะ๊ไ์ฬࡠࡳࡢ࡮ࠨ๘")+Dj62UpP5MrbTkJqhRa+ksDvwLIca3bHm+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࠦ࡫ࡣࡲࡶࠫ๙")+oOQaRxBXyJ5jVnZ)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡥ࡭ࡹࡸࡡࡵࡧࠪ๚"),ksDvwLIca3bHm)
	return
def yw1ar6LEzA8KvJ0nl(pP73fkt4xQrHBA6=VJZIMkUN5siqB21Pf):
	aBNLtkVZn5K3T = JCLpPcYQ1NSGX4Vz()
	MqKrNmGt0SCihdw6XHlR95UAxEWn = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧศๆอุ฿๐ไࠡษ็่ฬำโࠡ์฼้้࠭๛") if aBNLtkVZn5K3T else otNfFapeEnO(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใ่ࠢฮํ่แࠨ๜")
	LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(HaTI5u1f3SCxmMAkw(u"ࠩࡦࡩࡳࡺࡥࡳࠩ๝"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪาึ๎ฬࠨ๞"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫส๐โศใࠪ๟"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬะิ฻์็ࠫ๠"),TAExSfcoNi4eORZ8HPB,Dj62UpP5MrbTkJqhRa+MqKrNmGt0SCihdw6XHlR95UAxEWn+oOQaRxBXyJ5jVnZ+rJ9cgWz4FU+rC5tnFDlQcRGA2(u"࠭็ั้ࠣห้๎ุ๋ใฬࠤฯาูๅࠢๆ์ิ๐ࠠฤ๊อ์๊อส๋ๅํหࠥ๐โ้็ࠣฬฯฺฺ๋ๆࠣห้็๊ะ์๋ࠤฬ๊ไศฯๅࠤ࠳࠴ࠠฦ็สࠤอ฿ฯࠡษ้ฮ์อมࠡษ็ๅ๏ี๊้ࠢส่าอไ๋ࠢหว่๋ไ่ࠢ࠱࠲ࠥษ่ࠡส฼ำࠥอไ็ไิࠤ฾๊้ࠡิิࠤࠧะฬศ๊ีࠤส๊้ࠡษ็่ฬำโࠣࠢ࠱࠲ࠥ๎รุ๋สࠤ๊๋ใ็ࠢศ่฿อมࠡษ็ฮูเ๊ๅࠢส่้ออใࠢหห้์โาࠢ฼่๎ࠦาาࠢࠥษ๏่วโࠢส่ๆ๐ฯ๋๊ࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤฬ๊วิฬไหิฯࠠๆ่ࠣฮ฿๐๊าࠢอีฯ๐ศࠡ็ะฮํ๐วหࠢส่็๎วว็ࠣ࠲࠳่ࠦฯษุอࠥะัห์หࠤา๊โศฬࠣห้๋ำๅี็หฯࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡฬื฾๏๊่ࠠา๊ࠤฬู๊่์ไอࠥษๅࠡวํๆฬ็็ศࠢยࠥࠦ࠭๡"))
	if LfJRKzMepo0gZ==P2Fgh6TCOWoaHjkqBcQnvRNXe: M1ZhJtx9FrvpBL5PQgudw7E = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(rC5tnFDlQcRGA2(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡻ࡯ࡤࡦࡱࡳࡰࡦࡿࡥࡳ࠰ࡤࡹࡹࡵࡰ࡭ࡣࡼࡲࡪࡾࡴࡪࡶࡨࡱࠧ࠲ࠢࡷࡣ࡯ࡹࡪࠨ࠺࡜࡟ࢀࢁࠬ๢"))
	elif LfJRKzMepo0gZ==VTadWjBloMwXO2CH9GDK6FR: M1ZhJtx9FrvpBL5PQgudw7E = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࠬࠣࡸࡤࡰࡺ࡫ࠢ࠻࡝࠴ࡡࢂࢃࠧ๣"))
	if LfJRKzMepo0gZ in [P2Fgh6TCOWoaHjkqBcQnvRNXe,VTadWjBloMwXO2CH9GDK6FR]:
		if cjVhOCwybeRo7UWg92(u"ࠩࡷࡶࡺ࡫ࠧ๤") in str(M1ZhJtx9FrvpBL5PQgudw7E): PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪฮ๊ะࠠศๆ฼้้๐ษࠡส้ะฬำࠧ๥"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,mi2ZJXCDzITuyev6gfn(u"้๊ࠫริใࠣห้฿ๅๅ์ฬࠤๆฺไหࠩ๦"))
	return
def ZaYig0SsRL1X():
	url = Ew2zQ8u7Ss.SITESURLS[otNfFapeEnO(u"ࠬࡘࡅࡍࡇࡄࡗࡊ࡙ࠧ๧")][otNfFapeEnO(u"࠰ᄳ")]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,s97s2k0LJgl(u"࠭ࡇࡆࡖࠪ๨"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬ๩"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	BUNKAJQ3WLiVXbc = Zy2l0g8QU5vqefaTrsw.findall(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡪࡵࡩ࡫ࡃࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࠨࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠴ࠪࡀࠫ࠱ࡾ࡮ࡶࠢࠨ๪"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	BUNKAJQ3WLiVXbc = sorted(BUNKAJQ3WLiVXbc,reverse=w2qb6lf5EM)
	CrqTamtPFuU = T4TK17YsEfZJ(KA26GucUHOwXL(u"ࠩสาฯืࠠศๆศูิอัࠡษ็ิ๏ࠦสา์าࠤฯัศ๋ฬ๊ࠫ๫"),BUNKAJQ3WLiVXbc)
	if CrqTamtPFuU>=od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠱ᄴ"):
		YwbkiNC0PUn4SGH1uaxOjT2spIc = url.rsplit(zQGaM7ctZCN(u"ࠪ࠳ࠬ๬"),EcjO3giln2kQTdBY0XLAG(u"࠳ᄵ"))[mi2ZJXCDzITuyev6gfn(u"࠳ᄶ")]+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫ࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࠬ๭")+BUNKAJQ3WLiVXbc[CrqTamtPFuU]+otNfFapeEnO(u"ࠬ࠴ࡺࡪࡲࠪ๮")
		succeeded = LiTv20I56DgO(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ๯"),YwbkiNC0PUn4SGH1uaxOjT2spIc,w2qb6lf5EM)
		if succeeded:
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡢࡸ࠱ࡺࡪࡸࡳࡪࡱࡱࠫ๰"),CJlTSEpZsWb0QHg5w)
			Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"ࠨฬ่ࠤฯัศ๋ฬࠣษฺีวาࠢๅำ๏๋ࠠๅๆหี๋อๅอࠢ࠱࠲๊ࠥใ็ࠢหี๋อๅอࠢๆ์ิ๐๋ࠠไ๋้ࠥษ่ห๊่หฯ๐ใ๋ษࠣฬฯำฯ๋อࠣะ๊๐ูࠡษ็ฬึอๅอࠢหหุะฮะษ่ࠤวิัࠡวุำฬืࠠๆฬ๋ๅึࠦ࠮࠯๊่ࠢࠥะั๋ัࠣห้ศๆࠡวํๆฬ็ࠠศๆอัิ๐หࠡษ็วํะ่ๆษอ๎่๐ࠠๅ้ำหࠥอไษำ้ห๊าࠠภࠣࠤࠫ๱"))
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa: loBHfukKV4AGCtbFIvc7Y0eiLNJ(Olh7n0zfV4(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ๲"),w2qb6lf5EM,w2qb6lf5EM)
	return
def GbKdNI0A4wXrktQv6xY5UOeMH():
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,O4F8UC5lMAS6ghETm1VoPDI(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠢส่ำอีสࠢห์็ะࠠอๆหࠤฬ๊สฮัํฯฬะࠠ࠯࠰๋ࠣีอࠠศๆ่ืาࠦำ้ใࠣ๎ุฮศࠡฬะำ๏ัࠠโ๊ิ๎๊ࠥฬๆ์฼ࠤํ฾ววใࠣห้ฮั็ษ่ะࠥอไห์ࠣฮ฾ะๅะࠢ฼่๎ࠦๅา๊ิࠤํ่สࠡ็฼๎๋࠭๳"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩ๴"),CJlTSEpZsWb0QHg5w)
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡷ࡫ࡧࡶ࡮ࡤࡶࠬ๵"),CJlTSEpZsWb0QHg5w)
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(XB4CjMkPFzhAHiI3q(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡲ࡯࡯ࡩࠪ๶"),CJlTSEpZsWb0QHg5w)
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ๷"),CJlTSEpZsWb0QHg5w)
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(KA26GucUHOwXL(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪ๸"),CJlTSEpZsWb0QHg5w)
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩอ้๋ࠥำฮࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥอไฯษุอࠥฮ่ใฬࠣะ้ฮࠠศๆอัิ๐หศฬࠣ࠲࠳่ࠦิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢหฮาี๊ฬ๊ࠢิ์ࠦวๅว฼ำฬีวหࠢ࠱࠲ࠥ๎รุ๋สࠤฯำฯ๋อࠣ์฽อฦโࠢส่อืๆศ็ฯࠤฬ๊ส๋ࠢอ฽ฯ๋ฯࠡ฻็ํࠥอไ้ไอࠫ๹"))
		nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def mmO3EH1jAahkgBlsCnFcJ0eI7bv():
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕࡥ࠱ࠨ๺"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡖ࡛ࡅࡔࡖࡌࡓࡓ࡙ࠧ๻"))
	NUFLafsK3eo = RRltAnXSQPJ2Nki5FeMqs(VJZIMkUN5siqB21Pf)
	UUQPr6YwyiOtc = rJ9cgWz4FU
	C9fY2QT3DS0VZh5KJu = Ym6q5M4TocDaA013RjFQ+otNfFapeEnO(u"ࠬࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤ࠲࠳࠭࠮࠯ࠣ࠱࠲࠳࠭࠮ࠢ࠰࠱࠲࠳࠭ࠡࠩ๼")+oOQaRxBXyJ5jVnZ
	EEGapCkmgsiRD = rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+EcjO3giln2kQTdBY0XLAG(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࠪ๽")+oOQaRxBXyJ5jVnZ+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࡝ࡰ࡟ࡲࠬ๾")
	for id,kznWKAPj2eN,h417jESXsCIZJenFNlf0ybo2dr5xAL,B5B97KCQSDNcVWJb8RjxvL,wRUixloKXmj7IPpY4AcO21Q6Hygu,reason in reversed(NUFLafsK3eo):
		if id==VVvcQpCU3OM09n(u"ࠨ࠲ࠪ๿"):
			jkKGWHfxSeaVv9l,ootbcMklDverTHUZCB1wK6LdaF8 = B5B97KCQSDNcVWJb8RjxvL.split(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩ࡟ࡲࡀࡁࠧ຀"))
			continue
		if UUQPr6YwyiOtc!=rJ9cgWz4FU: UUQPr6YwyiOtc += EEGapCkmgsiRD
		sdGflAoZBxPURVuF = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩກ")+Ym6q5M4TocDaA013RjFQ+id+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࠥࡀࠠࠨຂ")+pz4WBwfyDdgk0m2aRr7SMv(u"ࠬอไิฦส่ࠥࡀࠠࠨ຃")+oOQaRxBXyJ5jVnZ+h417jESXsCIZJenFNlf0ybo2dr5xAL
		gEqOeRhimXy7rDZ4IH0 = GISOTJh20W(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧຄ")+Ym6q5M4TocDaA013RjFQ+JACnOz297UuDK5HpPkc1LF(u"ࠧศๆฯ์ฬฮࠠ࠻ࠢࠪ຅")+oOQaRxBXyJ5jVnZ+B5B97KCQSDNcVWJb8RjxvL
		DDk4RTUJBYFjgx = JACnOz297UuDK5HpPkc1LF(u"ࠨ࡝ࡕࡘࡑࡣࠧຆ")+Ym6q5M4TocDaA013RjFQ+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩส่ำ฽รࠡ࠼ࠣࠫງ")+oOQaRxBXyJ5jVnZ+wRUixloKXmj7IPpY4AcO21Q6Hygu
		FhejcUfS9X0RHdbt4Zv1LKqkaMug = VVvcQpCU3OM09n(u"ࠪࡠࡳࡡࡒࡕࡎࡠࠫຈ")+Ym6q5M4TocDaA013RjFQ+mi2ZJXCDzITuyev6gfn(u"ࠫฬ๊ำษสࠣ࠾ࠥ࠭ຉ")+oOQaRxBXyJ5jVnZ+reason
		UUQPr6YwyiOtc += sdGflAoZBxPURVuF+gEqOeRhimXy7rDZ4IH0+rJ9cgWz4FU+C9fY2QT3DS0VZh5KJu+rJ9cgWz4FU+DDk4RTUJBYFjgx+FhejcUfS9X0RHdbt4Zv1LKqkaMug+rJ9cgWz4FU
	hQbEaPTN5tnZfArRuWDcY(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡸࡩࡨࡪࡷࠫຊ"),ootbcMklDverTHUZCB1wK6LdaF8,UUQPr6YwyiOtc,KA26GucUHOwXL(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ຋"))
	return
def ahD2R6fnKoOkY1m(file):
	if file==wiEebAT9Qs7dCztufUZNORv3: K5MLrnwQVsvIay29 = otNfFapeEnO(u"ࠧใ๊สส๊ࠦวๅ็ไฺ้ฯࠧຌ")
	elif file==mw5hKxvWDZSQ: K5MLrnwQVsvIay29 = EcjO3giln2kQTdBY0XLAG(u"ࠨไ๋หห๋ࠠระิࠤฬ๊แ๋ัํ์์อสࠨຍ")
	LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(GISOTJh20W(u"ࠩࡦࡩࡳࡺࡥࡳࠩຎ"),pz4WBwfyDdgk0m2aRr7SMv(u"ุ้ࠪำࠧຏ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫส฻ไศฯࠪຐ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬิั้ฮࠪຑ"),TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"࠭็ๅࠢอี๏ีࠠฦื็หาࠦๅๅใࠣࠫຒ")+K5MLrnwQVsvIay29+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࠡล่ࠤฯื๊ะ่ࠢืาࠦวๅ็็ๅࠥลࠧຓ"))
	if LfJRKzMepo0gZ==O4F8UC5lMAS6ghETm1VoPDI(u"࠴ᄷ"):
		if tiFgl4DMvGEAUfjIYkHbr05.path.exists(file):
			try: tiFgl4DMvGEAUfjIYkHbr05.remove(file)
			except: pass
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,rC5tnFDlQcRGA2(u"ࠨฬ่ࠤู๊อࠡ็็ๅࠥ࠭ດ")+K5MLrnwQVsvIay29)
	elif LfJRKzMepo0gZ==O4F8UC5lMAS6ghETm1VoPDI(u"࠶ᄸ"):
		data = nfpZxRXATHiEOK465l9SvrsbmQ(file)
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"ࠩอ้ࠥหีๅษะࠤ๊๊แࠡࠩຕ")+K5MLrnwQVsvIay29)
	return
def nnTLsmFQ5J1uOUywpYH6I():
	if K9MoWfyg6w2EHIki4lLtFSzpxQTmRX<TDpFsQXHze2q30uYtGPfEIm8(u"࠷࠸ᄹ"):
		LLyhViKbxMntl5JSk = Olh7n0zfV4(u"่้ࠪษำโࠢฦ๊ฯࠦสิฬัำ๊ࠦลึัสี้่ࠥะ์ࠣๆิ๐ๅࠡำๅ้ࠥ࠭ຖ")+str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࠥ๎ไ่าสࠤฬ๊โ้ษษ้ࠥอไๆื๋ีฮࠦไศࠢอ฽ฺ๊๊่ࠠา็ࠥ࠴่ࠠา๊ࠤฬ๊ๅ๋ิฬࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣห้็๊ะ์๋๋ฬะࠠโ์ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠥ࠴ࠠๅวุ่ฬำࠠศๆุ่่๊ษࠡไ่ࠤอะอะ์ฮࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢศ่๎ࠦล๋ࠢศูิอัࠡำๅ้์ࠦรฺๆ์ࠤ๊์ࠠ࠲࠺࠱࠴ࠬທ")
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
		return
	qhesyXgdkYi = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(cbmeD4WNZfAowxT2JdUMtV(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨຘ"))
	a50MeDjfCnLNzihu = fxpB0b5NLy6EdFzR3HGPTA([yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬນ")])
	a1soztfTFIlNcHiyQE,EdoY4a1sPX,T0n6MfKbcA9vFrL,O8O6Gc1dj0EgNBnFxADvifKkebSLyp,LoiNjsvprheWQ5DAU6TYwl3SxGfk,CaDr5cndlMSjHY93Rh2tLK4omw,RbKpJAIvX7W = a50MeDjfCnLNzihu[ZP1LyUCS3pIBu(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ບ")]
	if a1soztfTFIlNcHiyQE or NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧປ") not in str(qhesyXgdkYi):
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yylSaxCLfkte(u"ࠩส่็๎วว็ࠣห้๋ี้ำฬࠤฯ฿ๅๅࠢไๆ฼ࠦๅฺࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮้ࠡำ๋ࠥอไใ๊สส๊ࠦสๆๅ้็๋ࠥๆࠡำว๎ฮࠦโ้ษษ้ࠥฮั็ษ่ะࠥ฿ๅศัࠣฬู้ไࠡื๋ีࠥฮฯๅษ้๋ࠣࠦวๅๅอหอฯࠧຜ"))
		cn0XyId7MkTCE1RifFhwQDN = ylmBACGaNLwfVugZToFbiOY()
		if not cn0XyId7MkTCE1RifFhwQDN: return
	z8SKrmAwqGFZCosg6HxPW4nD(w2qb6lf5EM)
	return
def z8SKrmAwqGFZCosg6HxPW4nD(showDialogs=w2qb6lf5EM):
	qhesyXgdkYi = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥࢁࢂ࠭ຝ"))
	if h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪພ") not in str(qhesyXgdkYi):
		if showDialogs:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,E6xdOMpqISHZCn(u"๊ࠬไฤีไࠤัํวำๅ่ࠣฬ๊ࠦิฬัำ๊ࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ࠲ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠห฻่่ࠥ็โุ่ࠢ฽ࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠱ࠤ์ึ็ࠡษ็ๆํอฦๆࠢอ้่์ใࠡ็้ࠤึส๊สࠢๅ์ฬฬๅࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศีๅ็ࠤฺ๎ัࠡสา่ฬࠦๅ็ࠢส่่ะวษหࠪຟ"))
		return
	ObToKD2HXyFMmkG = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,HaTI5u1f3SCxmMAkw(u"࠭ࡡࡥࡦࡲࡲࡸ࠭ຠ"),Olh7n0zfV4(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ມ"),GISOTJh20W(u"ࠨ࠹࠵࠴ࡵ࠭ຢ"),EcjO3giln2kQTdBY0XLAG(u"ࠩࡐࡽ࡛࡯ࡤࡦࡱࡑࡥࡻ࠴ࡸ࡮࡮ࠪຣ"))
	if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(ObToKD2HXyFMmkG): return
	AAFCv5YQlirBegzb8Lq = open(ObToKD2HXyFMmkG,E6xdOMpqISHZCn(u"ࠪࡶࡧ࠭຤")).read()
	if A7Z6OVh20eCEUx: AAFCv5YQlirBegzb8Lq = AAFCv5YQlirBegzb8Lq.decode(Im5KSGZYBpRvdMVsbuXg)
	WkiGHgOUrfbsFLoA4PznyK1tX5ZD7a = Zy2l0g8QU5vqefaTrsw.findall(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡁࡼࡩࡦࡹࡶࡂ࠭ࡢࡤࠬ࠮࡟ࡨ࠰࠲࡜ࡥ࠭ࠬ࠰࠭࠴ࠪࡀࠫ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫລ"),AAFCv5YQlirBegzb8Lq,Zy2l0g8QU5vqefaTrsw.DOTALL)
	QQeUtwR345uLsW69Hbni,Vk2uWcwU7o6tY9mAa = WkiGHgOUrfbsFLoA4PznyK1tX5ZD7a[ZVNvqy4iF1a9X]
	dn61R8gqKBwPGMkTCLh4jv3u = EcjO3giln2kQTdBY0XLAG(u"ࠬࡂࡶࡪࡧࡺࡷࡃ࠭຦")+QQeUtwR345uLsW69Hbni+ZP1LyUCS3pIBu(u"࠭ࠬࠨວ")+Vk2uWcwU7o6tY9mAa+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧ࠽࠱ࡹ࡭ࡪࡽࡳ࠿ࠩຨ")
	if showDialogs:
		ttmJlAQzOf = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡛࡯ࡥࡸ࡯ࡲࡨࡪ࠭ຩ"))
		if ttmJlAQzOf==otNfFapeEnO(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸࠬສ"): L7WjNGAsQrftauR = TDpFsQXHze2q30uYtGPfEIm8(u"ࠪๆํอฦๆࠢส่่ะวษหࠪຫ")
		elif ttmJlAQzOf==rC5tnFDlQcRGA2(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻࠪຬ"): L7WjNGAsQrftauR = zz679V18GdcZwvrRexA0nNptY2Tab(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪອ")
		else: L7WjNGAsQrftauR = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭โ้ษษ้ࠥษฮา๋ࠪຮ")
		LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡤࡧࡱࡸࡪࡸࠧຯ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠨไ๋หห๋ࠠฤะิํࠬະ"),HaTI5u1f3SCxmMAkw(u"ࠩๅ์ฬฬๅࠡษ็็ฯอศสࠩັ"),HaTI5u1f3SCxmMAkw(u"ࠪๆํอฦๆࠢสฺ่๎ัࠨາ"),s97s2k0LJgl(u"ࠫฬ์สࠡฯส่๏อࠠหีอาิ๋ࠠࠨຳ")+L7WjNGAsQrftauR,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬอๆหࠢส่ว์ࠠหีอาิ๋ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠮๊๊ࠡิฬࠦๅฺ่ส๋ࠥอๆไࠢอืฯ฽ฺ๊ࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥฮฯๅษ้๋ࠣࠦโ้ษษ้ࠥอไไฬสฬฮࠦ࠮๊ࠡฦ๎฻อࠠหีอ฻๏฿ࠠฦ์ๅหๆํวࠡใํࠤศ๐้ࠠไอࠤฯฺวยࠢ࡟ࡲࡡࡴࠠࠨິ")+Ym6q5M4TocDaA013RjFQ+Olh7n0zfV4(u"࠭ࠠฤะอีࠥอไร่๊ࠣํ฿ࠠศๆๅ์ฬฬๅࠡษ็ฮ๏ࠦสา์าࠤศูสฯัส้์อࠠภࠣࠪີ")+oOQaRxBXyJ5jVnZ)
		if LfJRKzMepo0gZ==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠱ᄺ"): WfCLZktXxE = pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡆࡏࡄࡈࠥࡒࡩࡴࡶࠪຶ")
		elif LfJRKzMepo0gZ==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠳ᄻ"): WfCLZktXxE = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡇࡐࡅࡉࠦࡇࡢ࡮࡯ࡩࡷࡿࠧື")
		else: WfCLZktXxE = CJlTSEpZsWb0QHg5w
	else:
		ttmJlAQzOf = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(Olh7n0zfV4(u"ࠩࡤࡺ࠳ࡳࡹࡴ࡭࡬ࡲ࠳ࡼࡩࡦࡹࡰࡳࡩ࡫ຸࠧ"))
		if   ttmJlAQzOf==CJlTSEpZsWb0QHg5w: LfJRKzMepo0gZ = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠲ᄼ")
		elif ttmJlAQzOf==KA26GucUHOwXL(u"ࠪࡉࡒࡇࡄࠡࡎ࡬ࡷࡹູ࠭"): LfJRKzMepo0gZ = cjVhOCwybeRo7UWg92(u"࠴ᄽ")
		elif ttmJlAQzOf==TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡊࡓࡁࡅࠢࡊࡥࡱࡲࡥࡳࡻ຺ࠪ"): LfJRKzMepo0gZ = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶ᄾ")
		WfCLZktXxE = ttmJlAQzOf
	if   LfJRKzMepo0gZ==KA26GucUHOwXL(u"࠵ᄿ"): o5oJEDdfANGMC1hVcTb = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬ࠻࠵࠭࠷࠷࠸࠱࠻࠵࠶ࠩົ")
	elif LfJRKzMepo0gZ==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷ᅀ"): o5oJEDdfANGMC1hVcTb = zQGaM7ctZCN(u"࠭࠵࠵࠶࠯࠹࠺࠻ࠬ࠶࠷ࠪຼ")
	elif LfJRKzMepo0gZ==cjVhOCwybeRo7UWg92(u"࠲ᅁ"): o5oJEDdfANGMC1hVcTb = zQGaM7ctZCN(u"ࠧ࠶࠷࠸࠰࠺࠻ࠬ࠶࠶࠷ࠫຽ")
	else: return
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡣࡹ࠲ࡲࡿࡳ࡬࡫ࡱ࠲ࡻ࡯ࡥࡸ࡯ࡲࡨࡪ࠭຾"),WfCLZktXxE)
	K10KWNCpAeZ6 = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩ࠿ࡺ࡮࡫ࡷࡴࡀࠪ຿")+o5oJEDdfANGMC1hVcTb+EcjO3giln2kQTdBY0XLAG(u"ࠪ࠰ࠬເ")+Vk2uWcwU7o6tY9mAa+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ແ")
	fTpbwJEnLgeiay = AAFCv5YQlirBegzb8Lq.replace(dn61R8gqKBwPGMkTCLh4jv3u,K10KWNCpAeZ6)
	if A7Z6OVh20eCEUx: fTpbwJEnLgeiay = fTpbwJEnLgeiay.encode(Im5KSGZYBpRvdMVsbuXg)
	open(ObToKD2HXyFMmkG,yylSaxCLfkte(u"ࠬࡽࡢࠨໂ")).write(fTpbwJEnLgeiay)
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,TDpFsQXHze2q30uYtGPfEIm8(u"࠭࠮࡝ࡶࡖ࡯࡮ࡴࠠࡅࡧࡩࡥࡺࡲࡴࠡࡘ࡬ࡩࡼࡹ࠺ࠡ࡝ࠣࠫໃ")+o5oJEDdfANGMC1hVcTb+HaTI5u1f3SCxmMAkw(u"ࠧࠡ࡟ࠪໄ"))
	if showDialogs: pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(zQGaM7ctZCN(u"ࠨࡔࡨࡰࡴࡧࡤࡔ࡭࡬ࡲ࠭࠯ࠧ໅"))
	return
def wDixZCH2O3aFjoWYEqpKNSBfUzdr():
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩหี๋อๅอࠢ฼้ฬีࠠโ์๊ࠤฺ๊ใๅหࠣ฽๋ีใࠡ࠰࠱࠲ࠥหๅศࠢฦ่ส฻ฯศำࠣๆิ๐ๅࠡ࠰࠱࠲ࠥษ่ࠡษ้ฮ๋ࠥๅ็๊฼ࠤ๊์ࠠศีอาิอๅࠡษ็ฬึ์วๆฮࠣ࠲࠳࠴ࠠฤ๊่ࠣิ๐ใࠡ็ื็้ฯࠠฤะิํࠥะฮึࠢฯ๋ฬุใࠡล้ฮࠥ๎ไศࠢอาฺࠦศใ์ฬࠤำ๊โࠡษ็่์ࠦ࡜࡯࡞ࡱࠤาอ่ๅࠢอัิ๐หࠡษ็ฬึ์วๆฮࠣวํࠦวหื็ࠤออไๆสิ้ัࠦไๆ฻ิๅฮࠦำษสࠣห้๋ิไๆฬࠤ฾์ฯไࠢ࠱࠲࠳ࠦ็ๅࠢอี๏ีࠠโฯุࠤฬ๊สฮัํฯฬะࠠศๆล๊ࠥลࠧໆ"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠲ᅂ"): fxdNEv1heTwKZ6WrC()
	return
def QluZO17FXPoAIsU6aTrH():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,o2FdrDBimMuOw97q6QpNW8S(u"๋ࠪีอࠠศๆ่์็฿ࠠๆ฼็ๆ๋ࠥๆࠡษ็ฺ้ีั๊ࠡ฽๎ึࠦๅฺำ๋ๅ๋ࠥส๋ࠢํีั฿ࠠๅๆ฼้้࠭໇"))
	return
def pYKfqLMy4whsEebU8giAQ1W():
	sdGflAoZBxPURVuF = Ym6q5M4TocDaA013RjFQ+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫฯ฿ฯศัุࠣ๏฿ษࠡฤ็ࠤ๊ำๅะࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥࡀࠠࠨ່")+oOQaRxBXyJ5jVnZ
	sdGflAoZBxPURVuF += Olh7n0zfV4(u"ࠬอไๆ๊ๅ฽ࠥษฯ็ษ๊ࠤๆ๐็ࠡวะูฬฬ๊สࠢ็฽ิีࠠศๆื๎฾ฯࠠโ์ࠣห้฿วๅ็ࠣฮ๊ࠦฬๆ฻๊ห๋ࠥๆࠡฮ่๎฾ࠦวๅ็ุหิืࠠศๆ่ฮํ็ัสࠢไ๎ࠥอไฦ่อี๋ะࠠศๆๅำ๏๋ษ๊ࠡส่ัี๊ะหࠣห้ำใ้็ํอࠥ๎วๅ฼ํีࠥำใ้็ํอࠥ๎ๅ็ࠢฯ้๏฿ࠠะ๊็ࠤฬู๊ศๆ่ࠤะ๋ࠠห็ࠣฮํำ๊ะ้สࠤํำำศสࠣหู้๋ะๆࠣัุฮࠠิๅส๊ࠥี่ๅࠢส่฾อไๆࠢ็ื๋ฯࠠ࠳࠲࠵࠵ࠥ๎็๋ࠢส่สำีศศํอࠥอไฤฯาฯࠥ๎วๅลื้้ࠦวๅฬํࠤฯฺ๋ࠠ็็๋ฬࠦแ๋ࠢสุ่์่ศฬࠣห้฿ิาหࠣห้๋วื์ฬ້ࠫ")
	sdGflAoZBxPURVuF += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰ࡵ࡫࡭ࡦࡩ࡯ࡶࡰࡷ໊ࠫ")+oOQaRxBXyJ5jVnZ
	gEqOeRhimXy7rDZ4IH0 = Ym6q5M4TocDaA013RjFQ+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧษำ้ห๊าࠠีำํ฻ࠥอไๆี็้ࠥࡀࠠࠨ໋")+oOQaRxBXyJ5jVnZ
	gEqOeRhimXy7rDZ4IH0 += XB4CjMkPFzhAHiI3q(u"ࠨ้๋ࠤ฾ฮวาหࠣ฽๋ࠦศา่ส้ั๊้ࠦใิࠤ๊฿ไ้็สฮࠥำำศสํอ้ࠥห๋ำฬࠤฯํๅࠡฮ่๎฾ࠦวๅ็ึ่๊๐ๆࠡ็ฮ่ࠥษ่ใษอࠤฬ๊ีๅษฬࠤํษ่ใษอࠤฬ๊ใิ๊ไࠤํอไฯี๋ๅࠥ๎ิไๆࠣห้่ๅา๋ࠢวํ่วหࠢส่็๋ั๊ࠡฦ๎฻อ๋๊ࠠไีࠥืฤ๋หࠣห้ํไศๆࠣๅ๏ࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅ๊ࠡฦ๎฻อࠠโ์๊ࠤฯ่่๋็้ࠣ๏๊วะ์ࠣ์์าั๋๋ࠢๅ๏ํࠠฤ์ูหࠥฮอฬ๋ࠢๆึอมสࠢส่็ืย็๋ࠢว๏฼วࠡใํ๋ࠥอำหะสีฮ่ࠦหใสศ้่ࠦโ์๊ࠤศ่่ศๆู้๋่ࠣษห่้ࠣษๅศ็ࠣ฽้๐้ࠠล่์ึࠦรฯำ์ࠤฯํๅࠡๅ็ࠤู๊ไๆࠢ࠱ࠤฬ๊ศา่ส้ัࠦๅไฬ๋ฬࠥฮไ฻หࠣะฬ็วࠡีๆีอะ้ࠠ์ึฮำีๅ่ࠡ฻ห๊่๋่ࠦา์ืࠦสฮฬࠣฬ๏ฬษ๊ࠡํ๊ิ๎าࠡๅสะ๏ะ้ࠠ็ัฺูࠦแใู่ࠣศา็ำหࠣห้๎๊็ั๋ึࠥ࠴ࠠศๆ่์็฿ࠠศๆิื๊๐ࠠๅๆหี๋อๅอ๊ࠢ์ࠬ໌")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸ࡮ࡴࡹ࠯ࡥࡦ࠳ࡲࡻࡳ࡭࡫ࡰࡶࡺࡲࡥࡳࠩໍ")+oOQaRxBXyJ5jVnZ
	LLyhViKbxMntl5JSk = yylSaxCLfkte(u"ࠪ࡟ࡗ࡚ࡌ࡞ࠩ໎")+sdGflAoZBxPURVuF+o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡡࡴ࡜࡯࡞ࡱ࡟ࡗ࡚ࡌ࡞ࠩ໏")+gEqOeRhimXy7rDZ4IH0
	hQbEaPTN5tnZfArRuWDcY(O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡸࡩࡨࡪࡷࠫ໐"),CJlTSEpZsWb0QHg5w,LLyhViKbxMntl5JSk)
	return
def uucYwE73JTI4ABiUWDSqxnNedH(TpGRx3umFIEKey1i0XNz8CnJ):
	RRr3Anq81K9gQybv6E7loe(uhTI2t3wObYqsAi9DCoc)
	NUFLafsK3eo = RRltAnXSQPJ2Nki5FeMqs(TpGRx3umFIEKey1i0XNz8CnJ)
	for L7RjXk0D5eqaTrS6u9WhgAYFn in [otNfFapeEnO(u"࠭ࡍࡆࡕࡖࡅࡌࡋࡓࠨ໑"),XB4CjMkPFzhAHiI3q(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ໒"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭໓"),yylSaxCLfkte(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࡤ࡚ࡓࠨ໔")]:
		if L7RjXk0D5eqaTrS6u9WhgAYFn in Ew2zQ8u7Ss.SEND_THESE_EVENTS: Ew2zQ8u7Ss.SEND_THESE_EVENTS.remove(L7RjXk0D5eqaTrS6u9WhgAYFn)
	yfL6aW08mk9wbt75r2cUnVeqSC(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭໕"))
	id,kznWKAPj2eN,h417jESXsCIZJenFNlf0ybo2dr5xAL,B5B97KCQSDNcVWJb8RjxvL,wRUixloKXmj7IPpY4AcO21Q6Hygu,reason = NUFLafsK3eo[ZVNvqy4iF1a9X]
	jkKGWHfxSeaVv9l,ootbcMklDverTHUZCB1wK6LdaF8 = B5B97KCQSDNcVWJb8RjxvL.split(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡡࡴ࠻࠼ࠩ໖"))
	gEqOeRhimXy7rDZ4IH0,DDk4RTUJBYFjgx,FhejcUfS9X0RHdbt4Zv1LKqkaMug = wRUixloKXmj7IPpY4AcO21Q6Hygu.split(zQGaM7ctZCN(u"ࠬࡢ࡮࠼࠽ࠪ໗"))
	EchvBMpPA1d69NjKiz0mltbCaw = w2qb6lf5EM
	while EchvBMpPA1d69NjKiz0mltbCaw:
		Xl2TL3jOce8NtIdPMfVZ6u7s0 = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"࠭ฮา๊ฯࠫ໘"),HaTI5u1f3SCxmMAkw(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭໙"),EcjO3giln2kQTdBY0XLAG(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩ໚"),cbmeD4WNZfAowxT2JdUMtV(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩ໛"),gEqOeRhimXy7rDZ4IH0)
		if Xl2TL3jOce8NtIdPMfVZ6u7s0==yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠴ᅃ"): cVlaztv5TX = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"ࠪ฽ํีษࠨໜ"),CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫໝ"),DDk4RTUJBYFjgx,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩໞ"))
		elif Xl2TL3jOce8NtIdPMfVZ6u7s0==O4F8UC5lMAS6ghETm1VoPDI(u"࠴ᅄ"): FeDaQc6MWl7()
		else: EchvBMpPA1d69NjKiz0mltbCaw = VJZIMkUN5siqB21Pf
	if TpGRx3umFIEKey1i0XNz8CnJ: nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def xgOa5wTKXsCFhn():
	T7THw29fQO()
	ttsha8epPUrTSxn64 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬໟ"))
	LLyhViKbxMntl5JSk = {}
	LLyhViKbxMntl5JSk[zQGaM7ctZCN(u"ࠧࡂࡗࡗࡓࠬ໠")] = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨษ็็ฬฺࠠศๆอ่็อฦ๋ࠢํ฽๊๊ࠧ໡")
	LLyhViKbxMntl5JSk[pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡖࡘࡔࡖࠧ໢")] = cbmeD4WNZfAowxT2JdUMtV(u"ࠪห้้วี่ࠢฮํ่แࠡฬ่ห๊อ้ࠠสส่่อๅๅࠩ໣")
	LLyhViKbxMntl5JSk[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡑࡏࡍࡊࡖࡈࡈࠬ໤")] = mi2ZJXCDzITuyev6gfn(u"้ࠬวีࠢฯำฬࠦโึ์ิࠤฬ๊ๅะ๋ࠣ࠲ࠥ࠭໥")+str(EKMZnHy6FQ1GN7w8/zQGaM7ctZCN(u"࠺࠵ᅅ"))+JACnOz297UuDK5HpPkc1LF(u"࠭ࠠะไํๆฮࠦแใูࠪ໦")
	QMZV7I2mbYW1vksJN5Seczn9Bl6p = LLyhViKbxMntl5JSk[ttsha8epPUrTSxn64]
	LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠧไษืࠤࠬ໧")+str(EKMZnHy6FQ1GN7w8/GISOTJh20W(u"࠻࠶ᅆ"))+cbmeD4WNZfAowxT2JdUMtV(u"ࠨࠢาๆ๏่ษࠨ໨"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨ໩"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪษ๏่วโࠢๆห๊๊ࠧ໪"),QMZV7I2mbYW1vksJN5Seczn9Bl6p,pz4WBwfyDdgk0m2aRr7SMv(u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦวๅๅสุࠥอไัๅํࠤฬ๊สๅไสส๏ࠦรๆࠢอี๏ีࠠฦ์ๅหๆࠦวๅๅสุࠥฮวๅๅส้้ࠦรๆࠢอี๏ีࠠไษืࠤ฾๋ั่ࠢๅู๏ืࠠอัสࠤฤࠧࠧ໫"))
	if LfJRKzMepo0gZ==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠶ᅇ"): VpdTixZvAHc1G5ls = GISOTJh20W(u"ࠬࡒࡉࡎࡋࡗࡉࡉ࠭໬")
	elif LfJRKzMepo0gZ==cbmeD4WNZfAowxT2JdUMtV(u"࠱ᅈ"): VpdTixZvAHc1G5ls = s97s2k0LJgl(u"࠭ࡁࡖࡖࡒࠫ໭")
	elif LfJRKzMepo0gZ==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠳ᅉ"): VpdTixZvAHc1G5ls = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡔࡖࡒࡔࠬ໮")
	else: VpdTixZvAHc1G5ls = CJlTSEpZsWb0QHg5w
	if VpdTixZvAHc1G5ls:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲࡭ࡺࡴࡱࡥࡤࡧ࡭࡫ࠧ໯"),VpdTixZvAHc1G5ls)
		nKczLSEWsb0RaMtAUNBeQy = LLyhViKbxMntl5JSk[VpdTixZvAHc1G5ls]
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,nKczLSEWsb0RaMtAUNBeQy)
	return
def ApO7hXc9m1yzjZUnwWIHt():
	LLyhViKbxMntl5JSk = {}
	LLyhViKbxMntl5JSk[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡄ࡙࡙ࡕࠧ໰")] = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪื๏ืแาࠢࡇࡒࡘࠦวๅฬ็ๆฬฬ๊ࠡ์฼้้ࡀࠠࠨ໱")
	LLyhViKbxMntl5JSk[O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡆ࡙ࡋࠨ໲")] = EcjO3giln2kQTdBY0XLAG(u"ู๊ࠬาใิࠤࡉࡔࡓࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํ࠺ࠡࠩ໳")
	LLyhViKbxMntl5JSk[TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡓࡕࡑࡓࠫ໴")] = rC5tnFDlQcRGA2(u"ࠧิ์ิๅึࠦࡄࡏࡕ้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ໵")
	vvEq0SlGFcPrs = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨ໶"))
	ttsha8epPUrTSxn64 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬ໷"))
	QMZV7I2mbYW1vksJN5Seczn9Bl6p = LLyhViKbxMntl5JSk[ttsha8epPUrTSxn64]+vvEq0SlGFcPrs
	LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"ࠪฮูเ๊ๅࠢ฼๊ิࠦวๅ็๋หๆ่ษࠨ໸"),otNfFapeEnO(u"ࠫฯฺฺ๋ๆࠣฮ้่วว์ࠪ໹"),rC5tnFDlQcRGA2(u"ࠬห๊ใษไࠤ่อๅๅࠩ໺"),QMZV7I2mbYW1vksJN5Seczn9Bl6p,cbmeD4WNZfAowxT2JdUMtV(u"࠭ำ๋ำไีࠥࡊࡎࡔ๊ࠢ์ࠥา็ศิࠣๅ๏ࠦวๅว้ฮึ์๊หࠢํๆํ๋ࠠษฬะ์๏๊ࠠฤี่หฦࠦวๅ็๋ห็฿้ࠠษ็ื๏ืแาษอࠤส๊้ࠡลิๆฬ๋้ࠠ฻้ำࠥฮูืࠢส่๋อำࠡ์ๅ์๊ࠦศฮฮหࠤํ๋ๆฺ๋ࠢั฻ืࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ࠴ࠠๅฬื฾๏๊ࠠิ์ิๅึࠦࡄࡏࡕࠣๆ๊ࠦศศะอ๎ฬืࠠศๆึ๎ึ็ัࠡษ็้๋อำษࠢฦ์่ࠥๅࠡสศ๎็อแ่ࠢหห้้วๆๆࠪ໻"))
	if LfJRKzMepo0gZ==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠲ᅊ"): VpdTixZvAHc1G5ls = KA26GucUHOwXL(u"ࠧࡂࡕࡎࠫ໼")
	elif LfJRKzMepo0gZ==yylSaxCLfkte(u"࠴ᅋ"): VpdTixZvAHc1G5ls = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡃࡘࡘࡔ࠭໽")
	elif LfJRKzMepo0gZ==EcjO3giln2kQTdBY0XLAG(u"࠶ᅌ"): VpdTixZvAHc1G5ls = VVvcQpCU3OM09n(u"ࠩࡖࡘࡔࡖࠧ໾")
	if LfJRKzMepo0gZ in [yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠶ᅎ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠶ᅍ")]:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡧࡪࡴࡴࡦࡴࠪ໿"),KA26GucUHOwXL(u"ุࠫ๐ัโำ࠽ࠤࠬༀ")+Ew2zQ8u7Ss.DNS_SERVERS[P2Fgh6TCOWoaHjkqBcQnvRNXe],pz4WBwfyDdgk0m2aRr7SMv(u"ู๊ࠬาใิ࠾ࠥ࠭༁")+Ew2zQ8u7Ss.DNS_SERVERS[ZVNvqy4iF1a9X],CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"࠭รฯฬสีู๊ࠥาใิࠤࡉࡔࡓࠡษ็้๋อำษࠢ็็ࠬ༂"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==mi2ZJXCDzITuyev6gfn(u"࠱ᅏ"): L15U9MHPl6qKxRTJDscbymh0o3etg = Ew2zQ8u7Ss.DNS_SERVERS[ZVNvqy4iF1a9X]
		else: L15U9MHPl6qKxRTJDscbymh0o3etg = Ew2zQ8u7Ss.DNS_SERVERS[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	elif LfJRKzMepo0gZ==TDpFsQXHze2q30uYtGPfEIm8(u"࠳ᅐ"): L15U9MHPl6qKxRTJDscbymh0o3etg = CJlTSEpZsWb0QHg5w
	else: VpdTixZvAHc1G5ls = CJlTSEpZsWb0QHg5w
	if VpdTixZvAHc1G5ls:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ༃"),VpdTixZvAHc1G5ls)
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡩࡴࡳࠨ༄"),L15U9MHPl6qKxRTJDscbymh0o3etg)
		nKczLSEWsb0RaMtAUNBeQy = LLyhViKbxMntl5JSk[VpdTixZvAHc1G5ls]+L15U9MHPl6qKxRTJDscbymh0o3etg
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,nKczLSEWsb0RaMtAUNBeQy)
	return
def p1Zc6GKEMW():
	ttsha8epPUrTSxn64 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(GISOTJh20W(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ༅"))
	LLyhViKbxMntl5JSk = {}
	LLyhViKbxMntl5JSk[E6xdOMpqISHZCn(u"ࠪࡅ࡚࡚ࡏࠨ༆")] = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫฬ๊ศา๊ๆื๏ࠦวๅฬ็ๆฬฬ๊ࠡฮส๋ืࠦไๅ฻่่ࠬ༇")
	LLyhViKbxMntl5JSk[TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡇࡓࡌࠩ༈")] = pz4WBwfyDdgk0m2aRr7SMv(u"࠭วๅสิ์ู่๊ࠡีํ฽๊๊ࠠษ฻าࠤฬ๊ำๆษะࠤ้ํࠧ༉")
	LLyhViKbxMntl5JSk[E6xdOMpqISHZCn(u"ࠧࡔࡖࡒࡔࠬ༊")] = Olh7n0zfV4(u"ࠨษ็ฬึ๎ใิ์้ࠣฯ๎โโࠢอ้ฬ๋ว๊ࠡหห้้วๆๆࠪ་")
	QMZV7I2mbYW1vksJN5Seczn9Bl6p = LLyhViKbxMntl5JSk[ttsha8epPUrTSxn64]
	LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"ࠩอุ฿๐ไࠡ฻้ำࠥอไๆ๊สๅ็ฯࠧ༌"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪฮูเ๊ๅࠢอ่็อฦ๋ࠩ།"),zQGaM7ctZCN(u"ࠫส๐โศใࠣ็ฬ๋ไࠨ༎"),QMZV7I2mbYW1vksJN5Seczn9Bl6p,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬอไษำ๋็ุ๐่๊ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠ฻่่ࠥ๎ำู๋ࠣฬ๏์ࠠอ้สึ่่ࠦศๆศ๊ฯืๆ๋ฬࠣ࠲ࠥํ่ࠡ์ึฮุ้๋ࠠๆหหฯ้้ࠠ์ๅ์๊ࠦศิฯห๋ฬࠦศะๆสࠤ๊์ใࠡอ่ࠤ๏ฮูฬ้สࠤ้้ࠠ࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢฦ้ࠥห๊ใษไࠤฬ๊ศา๊ๆื๏ࠦฟࠨ༏"))
	if LfJRKzMepo0gZ==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠲ᅑ"): VpdTixZvAHc1G5ls = h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡁࡔࡍࠪ༐")
	elif LfJRKzMepo0gZ==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠴ᅒ"): VpdTixZvAHc1G5ls = E6xdOMpqISHZCn(u"ࠧࡂࡗࡗࡓࠬ༑")
	elif LfJRKzMepo0gZ==ZP1LyUCS3pIBu(u"࠶ᅓ"): VpdTixZvAHc1G5ls = KA26GucUHOwXL(u"ࠨࡕࡗࡓࡕ࠭༒")
	else: VpdTixZvAHc1G5ls = CJlTSEpZsWb0QHg5w
	if VpdTixZvAHc1G5ls:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(JACnOz297UuDK5HpPkc1LF(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ༓"),VpdTixZvAHc1G5ls)
		nKczLSEWsb0RaMtAUNBeQy = LLyhViKbxMntl5JSk[VpdTixZvAHc1G5ls]
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,nKczLSEWsb0RaMtAUNBeQy)
	return
def Ed3pvBwrR1OQ():
	gZ0wJBN9VMTikRerpyEY4XmGq = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(yylSaxCLfkte(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ༔"))
	if gZ0wJBN9VMTikRerpyEY4XmGq==pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡘ࡚ࡏࡑࠩ༕"): header = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬะฮำ์้ࠤฬ๊โ้ษษ้๋ࠥส้ไไࠫ༖")
	else: header = TDpFsQXHze2q30uYtGPfEIm8(u"࠭สฯิํ๊ࠥอไใ๊สส๊ࠦๅโ฻็ࠫ༗")
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,s97s2k0LJgl(u"ࠧฦ์ๅหๆ༘࠭"),zQGaM7ctZCN(u"ࠨฬไ฽๏๊༙ࠧ"),header,GISOTJh20W(u"ࠩๅ์ฬฬๅࠡษ็ฬึ์วๆฮࠣ๎ฯ๋ࠠหฯา๎ะํวࠡล๋ฮํ๋วห์ๆ๎ฬࠦศฺัࠣ࠵࠻ࠦำศ฻ฬࠤ๊์ࠠฤ๊็ࠤศูสฯัส้ࠥ࠴࠮๊ࠡศ๎็อแࠡฬัึ๏์ࠠศๆๅ์ฬฬๅࠡ์วำ๏ࠦลๅ๋ࠣฮาี๊ฬ้สࠤๆ๐ࠠไๆ้ࠣึฯ๋ࠠฬ่ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦ࠮࠯๋๋ࠢีอ๋ࠠีหฬࠥฮืวࠢไ๎ࠥ็สฮࠢๅ์ฬฬๅࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴ่ࠠๆࠣฮึ๐ฯࠡฬไ฽๏๊ࠠฤ็ࠣษ๏่วโࠢอาื๐ๆࠡษ็ๆํอฦๆࠢยࠥࠦ࠭༚"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==-yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶ᅔ"): return
	elif Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡰࡸࡷࡨࡧࡣࡩࡧࠪ༛"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡆ࡛ࡔࡐࠩ༜"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,HaTI5u1f3SCxmMAkw(u"ࠬะๅࠡฬไ฽๏๊ࠠหะี๎๋ࠦวๅไ๋หห๋ࠧ༝"))
	else:
		ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭༞"),JACnOz297UuDK5HpPkc1LF(u"ࠧࡔࡖࡒࡔࠬ༟"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪ༠"))
	return
def Bvr7nVQbzg29W3pU8kKO5G1eE(FMxeyLvnzabpJhCXgS6T):
	if FMxeyLvnzabpJhCXgS6T!=CJlTSEpZsWb0QHg5w:
		FMxeyLvnzabpJhCXgS6T = CqvfpVUrZNTzdiXKnx69Q2m7L8AuF(FMxeyLvnzabpJhCXgS6T)
		FMxeyLvnzabpJhCXgS6T = FMxeyLvnzabpJhCXgS6T.decode(Im5KSGZYBpRvdMVsbuXg).encode(Im5KSGZYBpRvdMVsbuXg)
		zq8L6QblRWZmTvgPnXcF = I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠷࠰࠲࠲࠶ᅕ")
		Bw7JWegm1qSoh8iK5D492GtyA = rTF8V7fLD2SXJbAURpZjQ4wH.Window(zq8L6QblRWZmTvgPnXcF)
		Bw7JWegm1qSoh8iK5D492GtyA.getControl(XB4CjMkPFzhAHiI3q(u"࠳࠲࠳ᅖ")).setLabel(FMxeyLvnzabpJhCXgS6T)
	return
Z2AsBMp3RQShnCDiv4UkWN5EK0GHLg = [
			 E6xdOMpqISHZCn(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢ༡")
			,pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭༢")
			,HaTI5u1f3SCxmMAkw(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭༣")
			,otNfFapeEnO(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧ༤")
			,s97s2k0LJgl(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧ༥")
			,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩ༦")
			,KA26GucUHOwXL(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧ༧")+otNfFapeEnO(u"ࠩࠦࠫ༨")+cjVhOCwybeRo7UWg92(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩ༩")
			,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧ༪")
			,E6xdOMpqISHZCn(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨ༫")
			,E6xdOMpqISHZCn(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧ༬")
			,KA26GucUHOwXL(u"ࠧ࡟ࡠࡡࡢࡣ࠭༭")
			,VVvcQpCU3OM09n(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭༮")
			,yylSaxCLfkte(u"ࠩ࡯ࡥࡷ࡭ࡥࠡࡣࡸࡨ࡮ࡵࠠࡴࡻࡱࡧࠥ࡫ࡲࡳࡱࡵ࠾ࠬ༯")
			,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪ࡭ࡳ࡬࡯࠻ࠢࡐࡩࡩ࡯ࡡࡤࡱࡧࡩࡨࠦࡤࡦࡥࡲࡨࡪࡸ࠺ࠨ༰")
			]
def W6He8P9QgUuryTG(YjATkiozK34fNw1btrEeU8):
	if O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡑࡵࡡࡥ࡫ࡱ࡫ࠥࡹ࡫ࡪࡰࠣࡪ࡮ࡲࡥ࠻ࠩ༱") in YjATkiozK34fNw1btrEeU8 and zQGaM7ctZCN(u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠪ༲") in YjATkiozK34fNw1btrEeU8: return w2qb6lf5EM
	for FMxeyLvnzabpJhCXgS6T in Z2AsBMp3RQShnCDiv4UkWN5EK0GHLg:
		if FMxeyLvnzabpJhCXgS6T in YjATkiozK34fNw1btrEeU8: return w2qb6lf5EM
	return VJZIMkUN5siqB21Pf
def pNxPcE7BGklCJzZFmXRV(data):
	hkCQNLZv1KpbfJrz0DXR48VnY5tBF = zz679V18GdcZwvrRexA0nNptY2Tab(u"࠹ᅘ") if A7Z6OVh20eCEUx else TDpFsQXHze2q30uYtGPfEIm8(u"࠲࠷ᅗ")
	data = data.replace(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶࠴ᅙ")*YvOQBzaTAscXR9ql,hkCQNLZv1KpbfJrz0DXR48VnY5tBF*YvOQBzaTAscXR9ql)
	data = data.replace(otNfFapeEnO(u"࠭ࠠ࠽ࡩࡨࡲࡪࡸࡡ࡭ࡀ࠽ࠤࠬ༳"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧ࠻ࠢࠪ༴"))
	s502yd81FCuJmLVBlkPtxih9fZDA = CJlTSEpZsWb0QHg5w
	for YjATkiozK34fNw1btrEeU8 in data.splitlines():
		iYOKxb4qvpotC0EnmGwZS3 = Zy2l0g8QU5vqefaTrsw.findall(Olh7n0zfV4(u"ࠨࠢࠣࠤࠥࠦࡆࡪ࡮ࡨࠤࠧ࠮࠮ࠫࡁࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠮ࠪࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ༵ࠧ"),YjATkiozK34fNw1btrEeU8,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if iYOKxb4qvpotC0EnmGwZS3: YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(iYOKxb4qvpotC0EnmGwZS3[ZVNvqy4iF1a9X],CJlTSEpZsWb0QHg5w)
		s502yd81FCuJmLVBlkPtxih9fZDA += rJ9cgWz4FU+YjATkiozK34fNw1btrEeU8
	return s502yd81FCuJmLVBlkPtxih9fZDA
def OCuIKRAQ1X8rvBi9(llOgKR84ALMfZN7I):
	if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡒࡐࡉ࠭༶") in llOgKR84ALMfZN7I:
		rAJuMqhR2af3dZzX = PM4ReYxV1qtQ9
		header = E6xdOMpqISHZCn(u"ࠪๆึอมสࠢสุ่าไࠡษ็ๆิ๐ๅࠡม༷ࠪ")
	else:
		rAJuMqhR2af3dZzX = khYtrEzRsjxXW49NwMI
		header = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫ็ืวยหࠣหู้ฬๅࠢส่าอไ๋ࠢยࠫ༸")
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,header,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ูࠬฬๅࠢส่ศิืศรࠣ๎าะ่๋ࠢฦ๎฻อฺࠠๆ์ࠤุาไࠡษ็หุะฮะษ่ࠤ࠳่ࠦศๆสฯ๋๐ๆุࠡิ์ึ๐ษࠡๆ่฽ึ็ษࠡๅํๅࠥำฯฬฬࠣห้๋ิไๆฬࠤํ๋ว้๋ࠡࠤฬ๊ๅไษ้ࠤฬ๊ะ๋ࠢึฬอࠦอะ๊ฮࠤฬ๊ๅีๅ็อࠥ࠴ࠠไ๊า๎ࠥ๐อหใ฻ࠤอูฬๅ์้ࠤ࠳ࠦวๅล๋่ࠥํ่ࠡษ็ืั๊ࠠศๆะห้๐้ࠠใํู๋๋ࠥๅ๊่หฯࠦสษัฦࠤ๊์ะࠡสาห๏ฯࠠศๆอุ฿๐ไࠡษ็ัฬ๊๊ࠡๆหี๋อๅอࠢๆ์ิ๐้ࠠษ็ํࠥอไร่ࠣ࠲ࠥษๅศࠢสุ่าไࠡษ็ๆิ๐ๅࠡใ๊์ࠥอไิฮ็ࠤฬ๊ำศสๅࠤฬ๊ะ๋ࠢอ้ࠥาๅฺ้้๋ࠣࠦศา่ส้ัࠦใ้ัํࠤ็ฮไࠡฤัีࠥหืโษฤࠤ้ํࠠ࠯๊่ࠢࠥะั๋ัࠣห้อำห็ิหึࠦฟࠨ༹"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=yylSaxCLfkte(u"࠵ᅚ"): return
	ZnKTDBjcO6ALtF7yS5CMu9kPY,CGktIKBqh4iY5TOwLJuRHMUNaXn = [],XB4CjMkPFzhAHiI3q(u"࠵ᅛ")
	size,count = hhA3ineut0C1(rAJuMqhR2af3dZzX)
	file = open(rAJuMqhR2af3dZzX,KA26GucUHOwXL(u"࠭ࡲࡣࠩ༺"))
	if size>cbmeD4WNZfAowxT2JdUMtV(u"࠱࠱࠲࠵࠴࠵ᅝ"): file.seek(-E6xdOMpqISHZCn(u"࠷࠰࠱࠳࠳࠴ᅜ"),tiFgl4DMvGEAUfjIYkHbr05.SEEK_END)
	data = file.read()
	file.close()
	if A7Z6OVh20eCEUx: data = data.decode(Im5KSGZYBpRvdMVsbuXg)
	data = pNxPcE7BGklCJzZFmXRV(data)
	xWMpqasJ9BD = data.split(rJ9cgWz4FU)
	for YjATkiozK34fNw1btrEeU8 in reversed(xWMpqasJ9BD):
		RsyIfZNOcMDdaYw4h90gbiS1Kp = W6He8P9QgUuryTG(YjATkiozK34fNw1btrEeU8)
		if RsyIfZNOcMDdaYw4h90gbiS1Kp: continue
		YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(TDpFsQXHze2q30uYtGPfEIm8(u"ࠧ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠࡠࠩ༻"),Ym6q5M4TocDaA013RjFQ+JACnOz297UuDK5HpPkc1LF(u"ࠨࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ༼")+oOQaRxBXyJ5jVnZ)
		YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(JACnOz297UuDK5HpPkc1LF(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩ༽"),KA26GucUHOwXL(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆ࠱࠲࠳࠴ࡢ࠭༾")+s97s2k0LJgl(u"ࠫࡊࡘࡒࡐࡔ࠽ࠫ༿")+oOQaRxBXyJ5jVnZ)
		PDbioScAIaRZ6BG1hFXM = CJlTSEpZsWb0QHg5w
		doCuMzGbFrVTRSc1sH08 = Zy2l0g8QU5vqefaTrsw.findall(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡤࠨ࡝ࡦ࠮࠱࠭ࡢࡤࠬ࠯࡟ࡨ࠰ࠦ࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤ࡚ࠬࠫࠬࠬࠥ࠺࡝ࡦ࠮࠭ࠬཀ"),YjATkiozK34fNw1btrEeU8,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if doCuMzGbFrVTRSc1sH08:
			YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X],doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe]).replace(doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][VTadWjBloMwXO2CH9GDK6FR],CJlTSEpZsWb0QHg5w)
			PDbioScAIaRZ6BG1hFXM = doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe]
		else:
			doCuMzGbFrVTRSc1sH08 = Zy2l0g8QU5vqefaTrsw.findall(E6xdOMpqISHZCn(u"࠭࡞ࠩ࡞ࡧ࠯࠿ࡢࡤࠬ࠼࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮࠭࠭ࠦࡔ࠻࡞ࡧ࠯࠮࠭ཁ"),YjATkiozK34fNw1btrEeU8,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if doCuMzGbFrVTRSc1sH08:
				YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe],CJlTSEpZsWb0QHg5w)
				PDbioScAIaRZ6BG1hFXM = doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X]
		if PDbioScAIaRZ6BG1hFXM: YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(PDbioScAIaRZ6BG1hFXM,Dj62UpP5MrbTkJqhRa+PDbioScAIaRZ6BG1hFXM+oOQaRxBXyJ5jVnZ)
		ZnKTDBjcO6ALtF7yS5CMu9kPY.append(YjATkiozK34fNw1btrEeU8)
		if len(str(ZnKTDBjcO6ALtF7yS5CMu9kPY))>HaTI5u1f3SCxmMAkw(u"࠶࠲࠴࠴࠵ᅞ"): break
	ZnKTDBjcO6ALtF7yS5CMu9kPY = reversed(ZnKTDBjcO6ALtF7yS5CMu9kPY)
	d4brF8iCmk6ZE73jSzJNpMI = rJ9cgWz4FU.join(ZnKTDBjcO6ALtF7yS5CMu9kPY)
	hQbEaPTN5tnZfArRuWDcY(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧ࡭ࡧࡩࡸࠬག"),EcjO3giln2kQTdBY0XLAG(u"ࠨฤัีࠥษำุำࠣืั๊ࠠศๆฦา฼อม๊ࠡส่ฬูสฯัส้ࠬགྷ"),d4brF8iCmk6ZE73jSzJNpMI,VVvcQpCU3OM09n(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡸࡳࡡ࡭࡮ࡩࡳࡳࡺ࡟࡭ࡱࡱ࡫ࠬང"))
	return
def dmr8PhA7ZLWtvpk4c2SqN():
	RSvK8LmN1oxwgqJYT = open(peNQPA4nfl320OYG7M,cjVhOCwybeRo7UWg92(u"ࠪࡶࡧ࠭ཅ")).read()
	if A7Z6OVh20eCEUx: RSvK8LmN1oxwgqJYT = RSvK8LmN1oxwgqJYT.decode(Im5KSGZYBpRvdMVsbuXg)
	RSvK8LmN1oxwgqJYT = RSvK8LmN1oxwgqJYT.replace(ZP1LyUCS3pIBu(u"ࠫࡡࡺࠧཆ"),XB4CjMkPFzhAHiI3q(u"ࠬࠦࠠࠡࠢࠣࠤࠥࠦࠧཇ"))
	a50MeDjfCnLNzihu = Zy2l0g8QU5vqefaTrsw.findall(GISOTJh20W(u"࠭ࠨࡷ࡞ࡧ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧ཈"),RSvK8LmN1oxwgqJYT,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for YjATkiozK34fNw1btrEeU8 in a50MeDjfCnLNzihu:
		RSvK8LmN1oxwgqJYT = RSvK8LmN1oxwgqJYT.replace(YjATkiozK34fNw1btrEeU8,Ym6q5M4TocDaA013RjFQ+YjATkiozK34fNw1btrEeU8+oOQaRxBXyJ5jVnZ)
	Jg3XRQ2Tsp1ryEAc4o9BiznbftaIFC(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧศๆอ฾๏๐ัศฬࠣห้ษฮ๋ำฬࠤๆ๐ࠠศๆหีฬ๋ฬࠨཉ"),RSvK8LmN1oxwgqJYT)
	return
def e9U6BpvfrNJ():
	sdGflAoZBxPURVuF = EcjO3giln2kQTdBY0XLAG(u"ࠨส฼ฺࠥอไฤิิหึูࠦๅ๋ࠣห้ื๊ๆ๊อࠤ่๎ๆหำ๋่ࠥะ่โำࠣษ๊้ว็์ฬࠤฯ่ฯ๋็ࠣ์ฯษฮ๋ำࠣห้็๊ะ์๋ࠤํํะ่ࠢส่ศุัศำ๋ࠣ๏ࠦวๅลึ๋๊่ࠦศๆฦี็อๅࠡ็฼ࠤอ฿ึ๊ࠡๆห้ะวๅ์ࠪཊ")
	gEqOeRhimXy7rDZ4IH0 = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩ็ฮ็ี๊ๆࠢส่ๆ๐ฯ๋๊ࠣหุะฮะ็ࠣหู้็ๆࠢส่๏๋๊็๋่ࠢฯษฮ๋ำ๊ࠤฬูสฯั่ࠤฬ๊ำ่็ࠣห้๐ำศำࠣ࠲ࠥษๅศࠢ฼ำฮࠦวิ้่ࠤ๊ะสศๆํอࠥ็็ั้ࠣฮ็๎ๅࠡสอัึ๐ใࠡษ็ๅ๏ี๊้ࠢห์็ะࠠศๅหี๋ࠥๆ๊ࠡๅฮࠥอไิ้่ࠤฬ๊่ศฯาࠤ࠳ࠦรๆษࠣหู้็ๆࠢส่ศ฿ไ๊๋ࠢห้ษำโๆࠣๅ์๎๋ࠠฯิ็ࠥอไโ์า๎ํࠦลๅ๋ࠣห้ษๅศ็ࠣวํࠦลๅ๋ࠣห้๎ัศรࠣ์้้ๆࠡสๅๅืฯࠠไสํีฮ࠭ཋ")
	DDk4RTUJBYFjgx = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪว๊อࠠศๆฦี็อๅࠡใ๊๎ࠥะำหะา้๊ࠥไหไา๎๊่ࠦศๆอวำ๐ั๊ࠡ็็๋ࠦศๆไาหึูࠦะัࠣห้ั่ศ่ํࠤํอไะไสส็ࠦ࠮ࠡ็ฮ่ฬࠦัใ็ࠣ࠹࠹࠺ࠠห฻้๎ࠥ࠻ࠠะไสส็่ࠦࠡ࠶࠷ࠤะอๆ๋หࠣษ้๏ࠠศๆฦ้ฬ๋ࠠฤ๊ࠣษ้๏ࠠศๆ๋ีฬวࠠษฯึฬࠥอำหะาห๊้ࠠๅๆึ๋๊ࠦวๅ์่๎๋ࠦร้ࠢึ๋๊ࠦวๅ์ึหึ࠭ཌ")
	LLyhViKbxMntl5JSk = sdGflAoZBxPURVuF+mi2ZJXCDzITuyev6gfn(u"ࠫ࠿ࠦࠧཌྷ")+gEqOeRhimXy7rDZ4IH0+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࠦ࠮ࠡࠩཎ")+DDk4RTUJBYFjgx
	hQbEaPTN5tnZfArRuWDcY(TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ཏ"),TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk,rC5tnFDlQcRGA2(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪཐ"))
	return
def nD9fpAQ50YatjGr(type,LLyhViKbxMntl5JSk,showDialogs=w2qb6lf5EM,url=CJlTSEpZsWb0QHg5w,nqVYufmd4GFshQeHO9vp05=CJlTSEpZsWb0QHg5w,FMxeyLvnzabpJhCXgS6T=CJlTSEpZsWb0QHg5w,lv6X3tZSQcs4LOEuW2ofG70Db5=CJlTSEpZsWb0QHg5w):
	iPhpQn3OcAX04g5oEjql = w2qb6lf5EM
	if not Ew2zQ8u7Ss.wpBxtqcsDEafMFkToIXe:
		if showDialogs:
			Ax3cDp25Q0seGkmZtrJo1WYjMyVvHC = (od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨษ็ื฼ื࠺ࠨད") in LLyhViKbxMntl5JSk and HaTI5u1f3SCxmMAkw(u"ࠩส่๊้ว็࠼ࠪདྷ") in LLyhViKbxMntl5JSk and mi2ZJXCDzITuyev6gfn(u"ࠪห้๋ไโ࠼ࠪན") in LLyhViKbxMntl5JSk and otNfFapeEnO(u"ࠫฬ๊ฮุลࠪཔ") in LLyhViKbxMntl5JSk and O4F8UC5lMAS6ghETm1VoPDI(u"ࠬอไๆืาี࠿࠭ཕ") in LLyhViKbxMntl5JSk)
			if not Ax3cDp25Q0seGkmZtrJo1WYjMyVvHC: iPhpQn3OcAX04g5oEjql = qjTH2m7LxzoDERekhrBMs(Olh7n0zfV4(u"࠭ࡣࡦࡰࡷࡩࡷ࠭བ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"่ࠧๆࠣฮึูไ้ࠡำ๋ࠥอไาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠫབྷ"),LLyhViKbxMntl5JSk.replace(mi2ZJXCDzITuyev6gfn(u"ࠨ࡞࡟ࡲࠬམ"),rJ9cgWz4FU))
	elif showDialogs:
		LLyhViKbxMntl5JSk = yylSaxCLfkte(u"ࠩ࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡำึห้ฯ࡜࡝ࡰอ้๋ࠥำฮࠢส่ึูวๅห࡟ࡠࡳะๅࠡ็ึัࠥอไาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไสࠩཙ")
		Yx1yiHjnQ5bdNZJqvwc9ufGEK = qjTH2m7LxzoDERekhrBMs(pz4WBwfyDdgk0m2aRr7SMv(u"ࠪࡧࡪࡴࡴࡦࡴࠪཚ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫཛ")+E6xdOMpqISHZCn(u"ࠬࠦࠠ࠲࠱࠸ࠫཛྷ"),XB4CjMkPFzhAHiI3q(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫཝ"))
		ss5gtFUelYTVhWd42XbAnPy = qjTH2m7LxzoDERekhrBMs(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡤࡧࡱࡸࡪࡸࠧཞ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨཟ")+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࠣࠤ࠷࠵࠵ࠨའ"),s97s2k0LJgl(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨཡ"))
		t5UXp9jNSzh = qjTH2m7LxzoDERekhrBMs(TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫར"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬལ")+yylSaxCLfkte(u"࠭ࠠࠡ࠵࠲࠹ࠬཤ"),EcjO3giln2kQTdBY0XLAG(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬཥ"))
		wrk0BWHmGgdeOU67Fo = qjTH2m7LxzoDERekhrBMs(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨས"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"ࠩอ้๋ࠥำฮࠢิืฬ๊สไࠩཧ")+yylSaxCLfkte(u"ࠪࠤࠥ࠺࠯࠶ࠩཨ"),E6xdOMpqISHZCn(u"ࠫ์๊ࠠหำํำࠥหัิษ็ࠤึูวๅหࠣๅฬืฺสࠩཀྵ"))
		iPhpQn3OcAX04g5oEjql = qjTH2m7LxzoDERekhrBMs(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬཪ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"࠭สๆ่ࠢืาࠦัิษ็ฮ่࠭ཫ")+JACnOz297UuDK5HpPkc1LF(u"ࠧࠡࠢ࠸࠳࠺࠭ཬ"),s97s2k0LJgl(u"ࠨ้็ࠤฯื๊ะࠢศีุอไࠡำึห้ฯࠠโษิ฾ฮ࠭཭"))
	kznWKAPj2eN = qqwenxatQlYJLD(VJZIMkUN5siqB21Pf)
	U6m1oExLNuGKt2nzRYyq0 = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩࡄ࡚࠿ࠦࠧ཮")+kznWKAPj2eN+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪ࠱ࠬ཯")+type
	DVS31tWLTsGkuM68dqyrIPpgxBw = w2qb6lf5EM if zQGaM7ctZCN(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࠧ཰") in FMxeyLvnzabpJhCXgS6T else VJZIMkUN5siqB21Pf
	if not iPhpQn3OcAX04g5oEjql:
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,O4F8UC5lMAS6ghETm1VoPDI(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨཱ"))
		return VJZIMkUN5siqB21Pf
	aLf2nSIXhZegjGJKz7mqR6HQVP = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel(O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩིࠬ"))
	LLyhViKbxMntl5JSk += zQGaM7ctZCN(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ཱིࠥ࠭")+Ip3Xk2e9Dr8mYzWFvZhPHBnEg7a+pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࠢ࠽ࡠࡡࡴུࠧ")
	LLyhViKbxMntl5JSk += rC5tnFDlQcRGA2(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ཱུࠢࠪ")+kznWKAPj2eN+HaTI5u1f3SCxmMAkw(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩྲྀ")+uZYhUVqxz4Itp7MRSD3JkXGlrL+s97s2k0LJgl(u"ࠫࠥࡀ࡜࡝ࡰࠪཷ")
	LLyhViKbxMntl5JSk += TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪླྀ")+aLf2nSIXhZegjGJKz7mqR6HQVP
	BLjoYe9GRiaWgluTk36p = Kmr20L5RiED9nOu1AGNa7WQUSle6()
	BLjoYe9GRiaWgluTk36p = O4Ak3NXpyUHvE(BLjoYe9GRiaWgluTk36p)
	if BLjoYe9GRiaWgluTk36p: LLyhViKbxMntl5JSk += KA26GucUHOwXL(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨཹ")+BLjoYe9GRiaWgluTk36p
	if url: LLyhViKbxMntl5JSk += s97s2k0LJgl(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ེࠣࠫ")+url
	if nqVYufmd4GFshQeHO9vp05: LLyhViKbxMntl5JSk += XB4CjMkPFzhAHiI3q(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨཻ")+nqVYufmd4GFshQeHO9vp05
	LLyhViKbxMntl5JSk += HaTI5u1f3SCxmMAkw(u"ࠩࠣ࠾ࡡࡢ࡮ࠨོ")
	if showDialogs: KhwN2zcb7iMkjS5E4WURxByPGon(yylSaxCLfkte(u"ࠪะฬื๊ࠡษ็ษึูวๅཽࠩ"),VVvcQpCU3OM09n(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭ཾ"))
	if DVS31tWLTsGkuM68dqyrIPpgxBw:
		if o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬཿ") in FMxeyLvnzabpJhCXgS6T: VBDcLwYlIuzxX12my = PM4ReYxV1qtQ9
		else: VBDcLwYlIuzxX12my = khYtrEzRsjxXW49NwMI
		if not tiFgl4DMvGEAUfjIYkHbr05.path.exists(VBDcLwYlIuzxX12my):
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ฼ํี๋่ࠥอ๊าྀࠫ"))
			return VJZIMkUN5siqB21Pf
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧ࠯࡞ࡷࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡶࡩࡳࡪࠠࡵࡪࡨࠤࡱࡵࡧࡧ࡫࡯ࡩཱྀࠬ"))
		ZnKTDBjcO6ALtF7yS5CMu9kPY,CGktIKBqh4iY5TOwLJuRHMUNaXn = [],rC5tnFDlQcRGA2(u"࠲ᅟ")
		file = open(VBDcLwYlIuzxX12my,s97s2k0LJgl(u"ࠨࡴࡥࠫྂ"))
		size,count = hhA3ineut0C1(VBDcLwYlIuzxX12my)
		if size>yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠶࠴࠶࠶࠰࠱ᅠ"): file.seek(-yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠶࠴࠶࠶࠰࠱ᅠ"),tiFgl4DMvGEAUfjIYkHbr05.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(Im5KSGZYBpRvdMVsbuXg)
		data = pNxPcE7BGklCJzZFmXRV(data)
		xWMpqasJ9BD = data.splitlines()
		for YjATkiozK34fNw1btrEeU8 in reversed(xWMpqasJ9BD):
			RsyIfZNOcMDdaYw4h90gbiS1Kp = W6He8P9QgUuryTG(YjATkiozK34fNw1btrEeU8)
			if RsyIfZNOcMDdaYw4h90gbiS1Kp: continue
			doCuMzGbFrVTRSc1sH08 = Zy2l0g8QU5vqefaTrsw.findall(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩࡡࠬࡡࡪࠫ࠮ࠪ࡟ࡨ࠰࠳࡜ࡥ࠭ࠣࡠࡩ࠱࠺࡝ࡦ࠮࠾ࡡࡪࠫ࡝࠰࡟ࡨ࠰࠯ࠩࠩࠢࡗ࠾ࡡࡪࠫࠪࠩྃ"),YjATkiozK34fNw1btrEeU8,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if doCuMzGbFrVTRSc1sH08:
				YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][ZVNvqy4iF1a9X],doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe]).replace(doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][VTadWjBloMwXO2CH9GDK6FR],CJlTSEpZsWb0QHg5w)
			else:
				doCuMzGbFrVTRSc1sH08 = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡢ࠭ࡢࡤࠬ࠼࡟ࡨ࠰ࡀ࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠪࠣࡘ࠿ࡢࡤ྄ࠬࠫࠪ"),YjATkiozK34fNw1btrEeU8,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if doCuMzGbFrVTRSc1sH08: YjATkiozK34fNw1btrEeU8 = YjATkiozK34fNw1btrEeU8.replace(doCuMzGbFrVTRSc1sH08[ZVNvqy4iF1a9X][P2Fgh6TCOWoaHjkqBcQnvRNXe],CJlTSEpZsWb0QHg5w)
			ZnKTDBjcO6ALtF7yS5CMu9kPY.append(YjATkiozK34fNw1btrEeU8)
			if len(str(ZnKTDBjcO6ALtF7yS5CMu9kPY))>zQGaM7ctZCN(u"࠶࠺࠷࠰࠱࠲ᅡ"): break
		ZnKTDBjcO6ALtF7yS5CMu9kPY = reversed(ZnKTDBjcO6ALtF7yS5CMu9kPY)
		d4brF8iCmk6ZE73jSzJNpMI = mi2ZJXCDzITuyev6gfn(u"ࠫࡡࡸ࡜࡯ࠩ྅").join(ZnKTDBjcO6ALtF7yS5CMu9kPY)
	elif lv6X3tZSQcs4LOEuW2ofG70Db5: d4brF8iCmk6ZE73jSzJNpMI = lv6X3tZSQcs4LOEuW2ofG70Db5
	else: d4brF8iCmk6ZE73jSzJNpMI = CJlTSEpZsWb0QHg5w
	url = Ew2zQ8u7Ss.SITESURLS[KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ྆")][VTadWjBloMwXO2CH9GDK6FR]
	wSfEHOilLYIK = {cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡳࡶࡤ࡭ࡩࡨࡺࠧ྇"):U6m1oExLNuGKt2nzRYyq0,GISOTJh20W(u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨྈ"):LLyhViKbxMntl5JSk,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨ࡮ࡲ࡫࡫࡯࡬ࡦࠩྉ"):d4brF8iCmk6ZE73jSzJNpMI}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡓࡓࡘ࡚ࠧྊ"),url,wSfEHOilLYIK,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡙ࡅࡏࡆࡢࡉࡒࡇࡉࡍ࠯࠴ࡷࡹ࠭ྋ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if KA26GucUHOwXL(u"ࠫࠧࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠣ࠼ࠣ࠵࠱࠭ྌ") in bGIVq1CQTjmosZg: cn0XyId7MkTCE1RifFhwQDN = w2qb6lf5EM
	else: cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
	if showDialogs:
		if cn0XyId7MkTCE1RifFhwQDN:
			KhwN2zcb7iMkjS5E4WURxByPGon(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬะๅࠡษ็ษึูวๅࠢห๊ัออࠨྍ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭ࡓࡶࡥࡦࡩࡸࡹࠧྎ"))
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹ࠭ྏ"),otNfFapeEnO(u"ࠨฬ่ࠤสืำศๆࠣห้ืำศๆฬࠤอ์ฬศฯࠪྐ"))
		else:
			KhwN2zcb7iMkjS5E4WURxByPGon(XB4CjMkPFzhAHiI3q(u"ࠩ็่ศูแࠡใื่ࠥอไฦำึห้࠭ྑ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠪࡊࡦ࡯࡬ࡶࡴࡨࠫྒ"))
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,EcjO3giln2kQTdBY0XLAG(u"ࠫำ฽ร๊ࠡไุ้ࠦแ๋ࠢศีุอไࠡษ็ีุอไสࠩྒྷ"))
	return cn0XyId7MkTCE1RifFhwQDN
def iisCDrREWA7():
	sdGflAoZBxPURVuF = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡊ࡯ࠡࡻࡲࡹࠥࡽࡡ࡯ࡶࠣࡸࡴࠦࡴࡳࡣࡱࡷࡱࡧࡴࡦࠢࡰࡩࡳࡻࠠࡪࡶࡨࡱࡸࠦࡴࡰࠢࡤࠤࡱࡧ࡮ࡨࡷࡤ࡫ࡪࠦ࡯ࡵࡪࡨࡶࠥࡺࡨࡢࡰࠣࡅࡷࡧࡢࡪࡥࠣ࠲࠳ࠦࡏࡳࠢࡼࡳࡺࠦࡷࡢࡰࡷࠤࡹࡵࠠࡴࡪࡲࡻࠥࡇࡲࡢࡤ࡬ࡧࠥࡲࡥࡵࡶࡨࡶࡸࠦࡡ࡯ࡦࠣࡸࡪࡾࡴࠡࡁࠤࠫྔ")
	gEqOeRhimXy7rDZ4IH0 = zQGaM7ctZCN(u"࠭็ๅࠢอี๏ีࠠหำฯ้ฮࠦโ้ษษ้ࠥอไษำ้ห๊าࠠฦๆ์ࠤ้เษࠡลัี๎ฺ๋ࠦำࠣห้฿ัษ์ฬࠤ࠳࠴ࠠฤ็ࠣฮึ๐ฯࠡว฻๋ฬืࠠศๆฦัึ็้ࠠษ็็ฯอศสࠢส่฾ืศ๋หࠣรࠦ࠭ྕ")
	XpKwSsuCaOtJ0HLV8D = IUHFoP2MS7n5QBvc3ZthfdN0e(EcjO3giln2kQTdBY0XLAG(u"ࠧࡤࡧࡱࡸࡪࡸࠧྖ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨะิ์ัࠦࡅࡹ࡫ࡷࠫྗ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡗࡶࡦࡴࡳ࡭ࡣࡷࡩࠥะัอ็ฬࠫ྘"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪ฽ึฮ๊ࠡࡃࡵࡥࡧ࡯ࡣࠨྙ"),TAExSfcoNi4eORZ8HPB,sdGflAoZBxPURVuF+JACnOz297UuDK5HpPkc1LF(u"ࠫࡡࡴ࡜࡯ࠩྚ")+gEqOeRhimXy7rDZ4IH0)
	if XpKwSsuCaOtJ0HLV8D in [-yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠶ᅢ"),s97s2k0LJgl(u"࠶ᅣ")]: return
	elif XpKwSsuCaOtJ0HLV8D==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠱ᅤ"):
		import p7gmr5fCJu
		p7gmr5fCJu.hQ8GwszM3XqfBLV19g2x60PukmFJ()
		return
	s6hKGOFRDw37ILAjEY2lSrpXctC8dB = w2qb6lf5EM
	while s6hKGOFRDw37ILAjEY2lSrpXctC8dB:
		s6hKGOFRDw37ILAjEY2lSrpXctC8dB = VJZIMkUN5siqB21Pf
		message = yylSaxCLfkte(u"ࠬหะศࠢ฼๊ิ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ศำัโࠢส่฾ืศ๋หࠣๅฬึ็ษࠢศ่๎ࠦࠢฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠧࠦหๆࠢ฽๎ึࠦวๅะฺࠤส๊้ࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢ࠱࠲ࠥหะศࠢ็้ࠥะฬะࠢส่ำ฽ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡใ฽๎ึࠦวๅฮ็ำࠥหไ๊ࠢฦ๎ࠥาไะࠢฮห๋๐ࠠโ์๊ࠤฬ๊ฮุࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠣ࠲࠳ࠦหๆࠢห฽ิํวࠡ฼ํีࠥอไฯูࠣษ้๏ࠠࠣࡃࡵ࡭ࡦࡲࠢࠡ࡞ࡱࠤสึวࠡๆ๋ัฮࠦวๅ็ไหฯ๐อࠡษ็฽ึฮ๊สࠢ็หࠥะุ่ำ่่ࠣࠦ࠮࠯ࠢสิ์ฮࠠฦๆ์ࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤ࠳࠴ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้ํู่ࠡษ็ะ฿ืวโ์ࠣࡠࡳࡢ࡮้ࠡ็ࠤฯื๊ะࠢส่ว์ࠠโฬะࠤࠧหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠥࠤฤࠧࠧྛ")
		XpKwSsuCaOtJ0HLV8D = IUHFoP2MS7n5QBvc3ZthfdN0e(Olh7n0zfV4(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ྜ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪྜྷ"),EcjO3giln2kQTdBY0XLAG(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩྞ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡈࡲ࡬ࡲࡩࡴࡪࠣษ๋าไ๋ิํࠫྟ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ฽ิู๋้๋ࠠีࠥอไฤฯิๅࠥ๎วๅๅอหอฯࠠศๆ฼ีอ๐ษࠨྠ"),message,profile=xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩྡ"))
		if XpKwSsuCaOtJ0HLV8D==rC5tnFDlQcRGA2(u"࠳ᅥ"):
			message = VVvcQpCU3OM09n(u"ࠬࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢ࡯ࡩࡹࡺࡥࡳࡵࠣࡸ࡭࡫࡮ࠡࡱࡳࡩࡳࠦࠢࡌࡱࡧ࡭ࠥࡏ࡮ࡵࡧࡵࡪࡦࡩࡥࠡࡕࡨࡸࡹ࡯࡮ࡨࡵࠥࠤࡦࡴࡤࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠣࡸࡴࠦࠢࡂࡴ࡬ࡥࡱࠨࠠ࠯࠰ࠣࡍ࡫ࠦࡹࡰࡷࠣࡧࡦࡴ࡜ࠨࡶࠣࡪ࡮ࡴࡤࠡࠤࡄࡶ࡮ࡧ࡬ࠣࠢࡩࡳࡳࡺࠠࡵࡪࡨࡲࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡶ࡯࡮ࡴࠠࡵࡱࠣࡥࡳࡿࠠࡰࡶ࡫ࡩࡷࠦࡳ࡬࡫ࡱࠤࡹ࡮ࡡࡵࠢ࡫ࡥࡻ࡫ࠠ࡝ࠤࡄࡶ࡮ࡧ࡬࡝ࠤࠣࡪࡴࡴࡴࠡ࠰࠱ࠤࡆࡴࡤࠡࡶ࡫ࡩࡳࠦࡣࡩࡣࡱ࡫ࡪࠦࡴࡩࡧࠣࡪࡴࡴࡴࠡࡶࡲࠤࠧࡇࡲࡪࡣ࡯ࠦࠥࡢ࡮ࠡࡋࡩࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡩࡴࠢࡱࡳࡹࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢ࠱࠲࡚ࠥࡨࡦࡰࠣࡳࡵ࡫࡮ࠡࠤࡎࡳࡩ࡯ࠠࡊࡰࡷࡩࡷ࡬ࡡࡤࡧࠣࡗࡪࡺࡴࡪࡰࡪࡷࠧࠦࡡ࡯ࡦࠣࡧ࡭ࡧ࡮ࡨࡧࠣࡸ࡭࡫ࠠࡳࡧࡪ࡭ࡴࡴࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠤࡡࡴ࡜࡯ࠢࡇࡳࠥࡿ࡯ࡶࠢࡺࡥࡳࡺࠠ࡯ࡱࡺࠤࡹࡵࠠࡰࡲࡨࡲࠥࡺࡨࡦࠢࠥࡏࡴࡪࡩࠡࡋࡱࡸࡪࡸࡦࡢࡥࡨࠤࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸࠨࠠࡀࠣࠪྡྷ")
			XpKwSsuCaOtJ0HLV8D = IUHFoP2MS7n5QBvc3ZthfdN0e(h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ྣ"),Olh7n0zfV4(u"ࠧࡆࡺ࡬ࡸࠥิั้ฮࠪྤ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨ࡛ࡨࡷࠥ์ูๆࠩྥ"),VVvcQpCU3OM09n(u"ࠩࡄࡶࡦࡨࡩࡤࠢ฼ีอ๐ࠧྦ"),mi2ZJXCDzITuyev6gfn(u"ࠪࡑ࡮ࡹࡳࡪࡰࡪࠤࡆࡸࡡࡣ࡫ࡦࠤࡋࡵ࡮ࡵࠢࠩࠤ࡙࡫ࡸࡵࠩྦྷ"),message,profile=o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡨࡵ࡮ࡧ࡫ࡵࡱࡤࡳࡥࡥ࡫ࡸࡱ࡫ࡵ࡮ࡵࠩྨ"))
			if XpKwSsuCaOtJ0HLV8D==ZP1LyUCS3pIBu(u"࠴ᅦ"): s6hKGOFRDw37ILAjEY2lSrpXctC8dB = w2qb6lf5EM
		if XpKwSsuCaOtJ0HLV8D==EcjO3giln2kQTdBY0XLAG(u"࠴ᅧ"): YPvl3tzWXfojDk()
	return
def EEXA94z2iDCTSPxBVqnpfed():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠤํ๊ไหลๆำ่ࠥๅࠡสอุ฿๐ไࠡษ็ีฬฮืࠡษ็ิ๏ࠦไศࠢํ฽๊๊ࠠฬ็ࠣๆ๊ࠦศฦำึห้ࠦๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦวๅไสส๊ฯࠠศๆิส๏ู๊สࠢ็่อืๆศ็ฯࠫྩ"))
	return
def bRZ6YSFiMBzQL9():
	LLyhViKbxMntl5JSk = HaTI5u1f3SCxmMAkw(u"࠭็ัษࠣห้ฮั็ษ่ะ๋ࠥฮึืࠣๅ็฽ࠠๅๆ฽อࠥอไฺำห๎ฮ่ࠦๅๅ้ࠤ์ึวࠡๆสࠤ๏๋ๆฺ๋ࠢะํีࠠๆ๊สๆ฾ࠦแ๋้สࠤศ็ไศ็ࠣ์ู๊ไิๆสฮ๋ࠥสาฮ่อࠥษ่ࠡ็าฬ้าษࠡว็ํࠥอไๅ฼ฬࠤฬู๊าสํอࠥ๎วๅ๋่ࠣ฿อสࠡษัี๎่ࠦๅษࠣ๎ําฯࠡีหฬ๊ࠥไหๅิหึ࠭ྪ")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
	return
def y8HsaKODVlSw4TeNpJ():
	LLyhViKbxMntl5JSk = GISOTJh20W(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫྫ")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
	return
def zKyXalGV8J6L():
	LLyhViKbxMntl5JSk = GISOTJh20W(u"ࠨ้ํࠤุ๐ัโำสฮ๊ࠥวࠡ์ึฮ฼๐ูࠡษ็ฬึ์วๆฮࠣหุะฮะษ่๋ฬࠦศิสหࠤ่๎ๆ่ษ้ࠣา๋๊ส่๊ࠢࠥอไๆืาีࠥษ่ࠡสะหัฯࠠฦๆ์ࠤฬฺสาษๆࠤึูๅ๋ࠢฦ์ࠥาฯ๋ัฬࠤศ๎ࠠๅษࠣ๎฾ืแ่ษࠣห้ฮั็ษ่ะࠬྫྷ")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,rC5tnFDlQcRGA2(u"ࠩึ๎ึ็ัศฬࠣื๏ฬษࠡล๋ࠤ๊า็้ๆฬࠫྭ"),LLyhViKbxMntl5JSk)
	return
def ggyTRIkM2sQh9H0qjuwDEJate3x():
	LLyhViKbxMntl5JSk = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪหู้๊าใิหฯࠦวๅ฻ส้ฮࠦ็๋ࠢึ๎ึ็ัศฬࠣาฬืฬ๋หࠣ์฿๐ัࠡฬสฬ฾ฯࠠๅๆ่์็฿ࠠศๆฦู้๐้ࠠฮ่๎฾ࠦวๅ็๋ห็฿ࠠหีอาิ๋็ศ๋ࠢ฽ฬีษࠡฬๆ์๋ࠦๅอษ้๎ฮ่ࠦๆึส็้ํวࠡๅฮ๎ึฯࠠๅษ้ࠤฬ๊แ๋ัํ์์อสࠡใํ๋ฬࠦลๆษࠣฬ฼๐ฦสࠢฦ์๋ࠥๅ็๊฼อࠥษ่ࠡ็ะิํ็ษࠡล๋ࠤๆ๐็ศุ่่๊ࠢษࠡฯๅ์็ࠦวๅ็็็๏ฯ࡜࡯࡞ࡱࡠࡳอไิ์ิๅึอสࠡษ็าฬ฻ษ้ࠡํࠤุ๐ัโำสฮࠥะวษ฻ฬࠤ้๊ๅ้ไ฼ࠤฬ๊รึๆํࠤํ๋ำหะา้ฮࠦแ๋่ࠢ์ฬู่ࠡไ็๎้ฯࠠอัสࠤํ฿วะหࠣฮ่๎ๆࠡ็าๅํ฿ษࠡษ็วัืࠠฤ๊ࠣ๎๊๊ใ่ษࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ์้ํะศࠢไ๋๏ࠦฬ๋ัฬࠤู๋ศ๋ษࠣ์ุืฺ๊หࠣ์ฺ๊วไๆ๊ห่ࠥไ๋ๆฬࠤัีวࠨྮ")
	hQbEaPTN5tnZfArRuWDcY(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫྯ"),TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨྰ"))
	return
def yn3tg8rchHoj4i1Q9R2AN7ezGbZ():
	sdGflAoZBxPURVuF = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠭วษฬ฼ำࠥ฿ๆࠡ็็ๅฬะࠠศๆาๆฮࠦวๅ฻ส่๏ฯࠧྱ")
	gEqOeRhimXy7rDZ4IH0 = JACnOz297UuDK5HpPkc1LF(u"ࠧศสอ฽ิูࠦ็่่ࠢๆอสࠡล็ࠤࡲ࠹ࡵ࠹ࠩྲ")
	DDk4RTUJBYFjgx = rC5tnFDlQcRGA2(u"ࠨษหฮ฾ีฺ่้้ࠠࠣ็วหࠢส่ฯำๅ๋ๆࠣ์ฬ๊ฯศ๊้่ํีࠠࡥࡱࡺࡲࡱࡵࡡࡥࠩླ")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,sdGflAoZBxPURVuF,gEqOeRhimXy7rDZ4IH0,DDk4RTUJBYFjgx)
	return
def T7THw29fQO():
	gEqOeRhimXy7rDZ4IH0 = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩส่่อิ้๋ࠡࠤ๊ิา็่ࠢศ็ะࠠๅๆ่฽้๎ๅศฬࠣ๎ุะฮะ็๊ࠤฬ๊ศา่ส้ัࠦไฯิ้ࠤฺ็อศฬࠣห้หๆหำ้๎ฯ่ࠦา๊สฬ฼ࠦวๅใํำ๏๎็ศฬ่้ࠣ๎ี้ๆࠣษ้๐็ศࠢหืึ฿ษ๊ࠡหำํ์ࠠฦ่อี๋๐ส๊ࠡส่อืๆศ็ฯࠤ๏๋ำฮ้สࠤฯ๊โศศํหࠥฮูะࠢส๊ฯํวยࠢ฼้ึํว๊ࠡฦ๎฻อฺ่ࠠาࠤฯำฯ๋อࠣห้ฮั็ษ่ะࠥ࠴้้ࠠำหࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠิส฼อࠥษๆ้ษ฼ࠤ้฿ๅาࠢส่่อิࠡ࠼ࠪྴ")
	gEqOeRhimXy7rDZ4IH0 += cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡠࡳࡢ࡮ࠨྵ") + mi2ZJXCDzITuyev6gfn(u"ࠫ࠶࠴ࠠฬษหฮ๊ࠥไึใะหฯࠦวๅฬํࠤ๊฿ั้ใࠣว๋ํวࠡๆสࠤฯะฺ๋ำ๊ࠣ์อฦ๋ษࠣ์๊ีส่ࠢࠪྶ") + str(XlNnqz758Zeuo/O4F8UC5lMAS6ghETm1VoPDI(u"࠺࠵ᅨ")/O4F8UC5lMAS6ghETm1VoPDI(u"࠺࠵ᅨ")/JACnOz297UuDK5HpPkc1LF(u"࠷࠺ᅩ")/I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠹࠰ᅪ")) + yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࠦิ่ำࠪྷ")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU + ZP1LyUCS3pIBu(u"࠭࠲࠯ࠢฯำฬࠦื้์็ࠤฬ๊ๅะ๋่้ࠣ฻แฮษอࠤฬ๊ๅโำฺ๋ࠥษๆ่ษ่ࠣฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬྸ") + str(taSwGoeiz7mv/KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠶࠱ᅫ")/KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠶࠱ᅫ")/s97s2k0LJgl(u"࠳࠶ᅬ")) + TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࠡ์๋้ࠬྐྵ")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU + cjVhOCwybeRo7UWg92(u"ࠨ࠵࠱ࠤ฼๎๊ๅࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠ็ษาีฬࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬྺ") + str(ggZJf7YnlXHT3IjtMaWe6S/cjVhOCwybeRo7UWg92(u"࠸࠳ᅭ")/cjVhOCwybeRo7UWg92(u"࠸࠳ᅭ")/ZP1LyUCS3pIBu(u"࠵࠸ᅮ")) + pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࠣ๎ํ๋ࠧྻ")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU + CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪ࠸࠳ࠦๅห๊ึ฻ࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣๆิࠦสห฼ํีࠥ๎ๅะฬ๊ࠤࠬྼ") + str(DRmUs7l1O4xLeZYzGITXk/mi2ZJXCDzITuyev6gfn(u"࠺࠵ᅯ")/mi2ZJXCDzITuyev6gfn(u"࠺࠵ᅯ")) + od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ูࠫࠥวฺหࠪ྽")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU + cjVhOCwybeRo7UWg92(u"ࠬ࠻࠮ࠡไุ๎ึࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤฯะฺ๋ำࠣำฬฬๅศ๋้ࠢิะ็ࠡࠩ྾") + str(o1oDTrOyPliAC6QBcKXRathZGu9g4Y/zz679V18GdcZwvrRexA0nNptY2Tab(u"࠻࠶ᅰ")/zz679V18GdcZwvrRexA0nNptY2Tab(u"࠻࠶ᅰ")) + otNfFapeEnO(u"࠭ࠠิษ฼อࠬ྿")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU + GISOTJh20W(u"ࠧ࠷࠰ࠣะิอࠠใืํีࠥอไๆั์ࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢๆฯ๏ืว๊่ࠡำฯํࠠࠨ࿀") + str(zz5iuewhAFONn8GQc0DtyKZ317pHo/od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠼࠰ᅱ")) + XB4CjMkPFzhAHiI3q(u"ࠨࠢาๆ๏่ษࠨ࿁")
	gEqOeRhimXy7rDZ4IH0 += rJ9cgWz4FU + h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩ࠺࠲ࠥฮฯ้่ࠣ็ฬฺࠠๅๆุๅาอสࠡษ็ฮ๏ࠦสห฼ํีࠥฮำา฻ฬࠤํ๋ฯห้ࠣࠫ࿂") + str(uhTI2t3wObYqsAi9DCoc) + TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࠤิ่๊ใหࠪ࿃")
	gEqOeRhimXy7rDZ4IH0 += o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡡࡴ࡜࡯ࠩ࿄") + mi2ZJXCDzITuyev6gfn(u"๋ࠬหๅษ࠽ࠤฺ็อศฬࠣๆํอฦๆࠢส่ศ็ไศ็ࠣ์ฬ๊ๅิๆึ่ฬะ้ࠠษ็ั้่วหࠢ฼้ึํวࠡࠩ࿅") + str(DRmUs7l1O4xLeZYzGITXk/zQGaM7ctZCN(u"࠶࠱ᅲ")/zQGaM7ctZCN(u"࠶࠱ᅲ")) + KA26GucUHOwXL(u"࠭ࠠิษ฼อࠥ࠴ࠠฤ็สࠤ็๎วว็ࠣว๋๎วฺࠢส่ๆ๐ฯ๋๊๊หฯࠦแฺ็ิ๋ฬ࿆ࠦࠧ") + str(ggZJf7YnlXHT3IjtMaWe6S/zQGaM7ctZCN(u"࠶࠱ᅲ")/zQGaM7ctZCN(u"࠶࠱ᅲ")/TMfV6892ZoBdyxCH3tGrkwY0K(u"࠳࠶ᅳ")) + zQGaM7ctZCN(u"ࠧࠡลํห๊ࠦ࠮ࠡล่ห๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥ็ูๆำ๊หࠥ࠭࿇") + str(o1oDTrOyPliAC6QBcKXRathZGu9g4Y/zQGaM7ctZCN(u"࠶࠱ᅲ")/zQGaM7ctZCN(u"࠶࠱ᅲ")) + yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࠢึห฾ฯࠠโไฺࠤ࠳ࠦรๆษࠣๅา฻ࠠาไ่ࠤฬ๊ลึัสีࠥ็ูๆำ๊ࠤࠬ࿈") + str(zz5iuewhAFONn8GQc0DtyKZ317pHo/zQGaM7ctZCN(u"࠶࠱ᅲ")) + TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࠣำ็๐โสࠢ࠱ࠤศ๋วࠡใะูࠥอิหำส็ࠥๆࡉࡑࡖ࡙ࠤๆ฿ๅา้ࠣࠫ࿉") + str(uhTI2t3wObYqsAi9DCoc) + ZP1LyUCS3pIBu(u"ࠪࠤิ่๊ใหࠪ࿊")
	hQbEaPTN5tnZfArRuWDcY(o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡷ࡯ࡧࡩࡶࠪ࿋"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"๋ࠬว้๋ࠡࠤฬ๊ใศึࠣห้๋ำหะา้ࠥ็๊ࠡษ็ฬึ์วๆฮࠪ࿌"),gEqOeRhimXy7rDZ4IH0,h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ࿍"))
	return
def Z3ZLcI9DdAfywOvH8PgR():
	LLyhViKbxMntl5JSk = cjVhOCwybeRo7UWg92(u"ࠧศๆไหฺ๊ษࠡฬ฼๊๏ࠦๅอๆาࠤอ์แิࠢสื๊ํࠠศๆฦู้๐้ࠠษ็๊็฽ษࠡฬ฼๊๏ࠦร็ࠢส่ฬูๅࠡษ็วฺ๊๊ࠡฬ่ࠤฯ฿ฯ๋ๆ๊ࠤํ็วึๆฬࠤํ์โุหࠣฮ฾์้ࠡ็ฯ่ิ่ࠦห็ࠣฮ฾ี๊ๅࠢสื๊ํ้ࠠสา์ู๋ࠦๅษ่อࠥะู็์้้ࠣ็ࠠษ่ไืࠥอำๆ้ࠣห้ษีๅ์ࠪ࿎")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
	return
def u4xCT9OASigmzWHJeP21():
	LLyhViKbxMntl5JSk = TDpFsQXHze2q30uYtGPfEIm8(u"ࠨวำหࠥ๎วอ้อ็๋ࠥิไๆฬࠤๆ๐ࠠศๆืฬ่ฯ้ࠠฬ่ࠤา๊็ศࠢ࠱࠲࠳ࠦร้ࠢส๊่ࠦสู่ࠣว๋ࠦวๅ็๋ๆ฾ࠦวๅลุ่๏ࠦใศ่ࠣๅ๏ํࠠๆึๆ่ฮࠦๅลไอ๋ࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤๆหะ็ࠢฯีอࠦๅิฯࠣ็ฬฺࠠศๆหี๋อๅอࠢ็็๏๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦศุๆหࠤฬ๊ีโฯฬࠤฬ๊ีฮ์ะอࠥ๎สฯิํ๊์อࠠษั็ห๋ࠥๆࠡษ็ูๆำษࠡษ็ๆิ๐ๅสࠩ࿏")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
	return
def l6WRFE0gJStKwxCAZ7prza():
	LLyhViKbxMntl5JSk = HaTI5u1f3SCxmMAkw(u"ࠩส่฿ืึࠡ็้ࠤูํวะหࠣห้ะิโ์ิࠤ์๎ࠠื็ส๊ࠥ฻อส๋ࠢืึ๐ษࠡษ็้฾๊่ๆษอࠤฬ๊ๅหสสำ้ฯࠠษ์้ࠤฬ๊ศา่ส้ั่ࠦศๆ่์็฿ࠠศๆุ่ๆื้้ࠠำหࠥอไื็ส๊ࠥเ๊า่ࠢ฻้๎ศ๊ࠡ็หࠥำวอห่ࠣ์ูࠦ็ัࠣห้อสึษ็ࠤฬ๎ࠠศๆิฬ฼ࠦๅฺ่ࠢ์ฬู่ࠡษ็ๅ๏ี๊้้สฮࠥอไๆึไีฮ࠭࿐")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
	return
def rUkP54WoxAT2QD():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,s97s2k0LJgl(u"่่ࠪ๐๋ࠠ฻่่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊แ๋ัํ์์อสࠡ࡞ࡱࠤ๏าศࠡฬไ฽๏๊ࠠฦุสๅฮࠦวิ็๊หࠥࡢ࡮ࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨ࿑"))
	nn3q8dAwhfx(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨࠫ࿒"),w2qb6lf5EM)
	return
def F0LIQ451lcjkgUAus867qJrb():
	LLyhViKbxMntl5JSk  = zQGaM7ctZCN(u"๋ࠬฤฯำสࠤ็อๅหࠢห฽฻ࠦิาๅสฮࠥอไฦ่อี๋ะࠠศๆา์้๐ࠠษู๊฽ࠥ฿ววไฺࠣิࠦวๅสิห๊าࠠๆอ็ࠤ่๎ฯ๋ࠢ็ฮุ๋อࠡใๅ฻๊ࠥศฺุุ้ࠣะฮะ็ํࠤฬ๊ๅหืไัࠥฮวๅัั์้ࠦไๆ๊สๆ฾ࠦวๅใํำ๏๎ࠧ࿓")
	LLyhViKbxMntl5JSk += KA26GucUHOwXL(u"้่࠭ࠠอ๎ัฯࠠๅ้ำหࠥอไฺษษๆࠥ็ว็้ࠣฮ็ื๊ษษࠣะ๊๐ูࠡ็ึฮำีๅ๋ࠢหี๋อๅอࠢๆ์ิ๐ࠠๅษࠣ๎ุะื๋฻๋๊ࠥอไะะ๋่๊ࠥฬๆ์฼ࠤ๊๎วใ฻ࠣห้ฮั็ษ่ะࠥำส๊่ࠢ฽ࠥอำหะาห๊࠭࿔")
	LLyhViKbxMntl5JSk += rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+TDpFsQXHze2q30uYtGPfEIm8(u"ࠧแ࡚ࠢࠣࡕࡔࠠࠡล๋ࠤࠥࡖࡲࡰࡺࡼࠤࠥษ่ࠡࠢࡇࡒࡘࠦࠠฤ๊ࠣว๏ࠦอๅࠢหื๏฽ࠠระิࠫ࿕")+oOQaRxBXyJ5jVnZ+rJ9cgWz4FU
	LLyhViKbxMntl5JSk += KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ࡞ࡱ่ฬ์่ࠠาสࠤ้์๋ࠠฯ็ࠤฬ๊ๅีๅ็อࠥ๎ล็็สࠤๆ่ืࠡีํๆํ๋ࠠษวุ่ฬำࠠษ฻ูࠤฬ๊ๅ้ษๅ฽ࠥ๎ลฺษๅอ๋่ࠥศไ฼ࠤฬิั๊ࠢๆห๋ะࠠห฻ู่่ࠥวษไสࠤอี่็ุ่ࠢฬ้ไࠨ࿖")
	hQbEaPTN5tnZfArRuWDcY(GISOTJh20W(u"ࠩࡵ࡭࡬࡮ࡴࠨ࿗"),TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭࿘"))
	LLyhViKbxMntl5JSk = ZP1LyUCS3pIBu(u"ࠫฬ๊ๅ้ษๅ฽ࠥอไห์ࠣฮศััหࠢหห้฿ววไࠣ฽๋ีࠠษ฻ูࠤฬ๊ๆศี๋ࠣ๏ࡀࠧ࿙")
	LLyhViKbxMntl5JSk += rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+JACnOz297UuDK5HpPkc1LF(u"ࠬࡧ࡫ࡰࡣࡰࠤࠥ࡫ࡧࡺࡤࡨࡷࡹࠦࠠࡦࡩࡼࡦࡪࡹࡴࡷ࡫ࡳࠤࠥࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠡࠢࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠡࠢࡶ࡬ࡦ࡮ࡩࡥ࠶ࡸࠫ࿚")+oOQaRxBXyJ5jVnZ
	LLyhViKbxMntl5JSk += VVvcQpCU3OM09n(u"࠭࡜࡯࡞ࡱࠫ࿛")+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧศๆา์้ࠦวๅฬํࠤฯษหาฬࠣฬฬู๊ศศๅࠤ฾์ฯࠡส฼ฺࠥอไ็ษึࠤ์๐࠺ࠨ࿜")
	LLyhViKbxMntl5JSk += rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨ็ุีࠥࠦวๅๅ๋๎ฯࠦࠠฤ็ํี่อࠠࠡๅ้ำฬࠦࠠโำ้ืฬࠦࠠศๆํ์๋อๆࠡࠢหี๏฽ว็์สࠤฬ๊ลๆษิหฯࠦรๅ็ส๊๏อࠠา๊ึ๎ฬࠦวๅ์สฬฬ์ࠠศๆึ฽ํี๊สࠢิ์๊อๆ๋ษ๋ࠣํ๊ๆะษࠪ࿝")+oOQaRxBXyJ5jVnZ
	LLyhViKbxMntl5JSk += yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩ࡟ࡲࡡࡴࠧ࿞")+EcjO3giln2kQTdBY0XLAG(u"ࠪห้๋ศา็ฯࠤําฯูࠡิ๎็ฯࠠๅฬฯหํุࠠศๆ฼หห่้ࠠๆๆ๊์อࠠหฯอหัࠦฬ่ัࠣ็อ๐ั๊ࠡส่๊ฮัๆฮࠣ๎฽์ࠠศๆุ่่๊ษࠡื฽๎ึฯ้ࠠๆสࠤฯูสฮไࠣห้ะูษࠢไษีอࠠๅัํ็๋ࠥิไๆฬࠤออไะะ๋่๊ࠥศฺุࠣห้๋่ศไ฼ࠤํษ๊ืษ่่ࠣ๐๋ࠠฬูัࠥำฬๆࠢสฺ่๊ใๅหࠣࠫ࿟")
	LLyhViKbxMntl5JSk += Dj62UpP5MrbTkJqhRa+E6xdOMpqISHZCn(u"ࠫฬืำๅࠢิืฬ๊ษࠡ็วำอฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วไฬหࠤๆ๐็ศࠢสื๊ࠦศๅัๆࠤํษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥอไห์่ࠣฬࠦสิฬฺ๎฾ࠦฯฯ๊็๋ฬ࠭࿠")+oOQaRxBXyJ5jVnZ
	hQbEaPTN5tnZfArRuWDcY(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡸࡩࡨࡪࡷࠫ࿡"),TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk,cjVhOCwybeRo7UWg92(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ࿢"))
	return
def fjVA1R8HOFxdQ():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"ࠧฬๆสฯࠥ฽ัใࠢ็่ฯ๎วึๆ้ࠣ฾ࠦวๅ็หี๊าࠧ࿣"),KA26GucUHOwXL(u"ࠨลิื้ࠦัิษ็อࠥษ่ࠡ็ื็้ฯࠠๆ่ࠣๆฬฬๅสࠢิืฬฬไ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱวํࠦศศีอาิอๅࠡษ็ๅ๏ูศ้ๅࠣวิ์ว่࡞ࡱࠫ࿤")+Dj62UpP5MrbTkJqhRa+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥࡨ࡫ࡢࡰࡱ࡮࠲ࡨࡵ࡭࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻ࠫ࿥")+oOQaRxBXyJ5jVnZ+VVvcQpCU3OM09n(u"ࠪࡠࡳࡢ࡮ฤ๊ࠣฬฬืำศๆࠣห๏๋๊ๅࠢส่๎ࠦระ่ส๋ࠥࠦ࡜࡯ࠢࠪ࿦")+Dj62UpP5MrbTkJqhRa+ZP1LyUCS3pIBu(u"ࠫࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࡀࡨ࡯ࡤ࡭ࡱ࠴ࡣࡰ࡯ࠪ࿧")+oOQaRxBXyJ5jVnZ)
	return
def DDWykc36s9qCldbrRe(showDialogs=w2qb6lf5EM):
	if not showDialogs: showDialogs = w2qb6lf5EM
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡍࡅࡕࠩ࿨"),mi2ZJXCDzITuyev6gfn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡺࡤࡱࡵࡲࡥ࠯ࡥࡲࡱࠬ࿩"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡋࡘ࡙ࡖࡓࡠࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ࿪"))
	if not bqIufCQz2OWExjilm.succeeded:
		DDeArvFg1mW5wYbE62Uz0OkdQ8 = VJZIMkUN5siqB21Pf
		r9u8w2A3nbVvRpc1B = c3mPLX9b6oqze0UCJEartIuds(VJZIMkUN5siqB21Pf)
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+HaTI5u1f3SCxmMAkw(u"ࠨࠢࠣࠤࡍ࡚ࡔࡑࡕࠣࡊࡦ࡯࡬ࡦࡦࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࡠ࠭࿫")+r9u8w2A3nbVvRpc1B+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡠࠫ࿬"))
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Olh7n0zfV4(u"ࠪๅา฻ࠠศๆสฮฺอไࠡษ็ู้็ัࠡ࠰࠱࠲๋ࠥิไๆฬࠤ࠳࠴࠮ࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢࠫห้ืศุࠢสฺ่๊แา่ࠫࠣฬฺ๊ࠦ็็ࠤ฾์ฯไࠢ฼่๎ࠦใ้ัํࠤ࠳࠴࠮๊ࠡ฼๊ิ้ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥอไๆ๊สๆ฾ࠦวๅ็ืๅึฯࠧ࿭"))
	else:
		DDeArvFg1mW5wYbE62Uz0OkdQ8 = w2qb6lf5EM
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮࠯ࠢส่ฬะีศๆࠣห้๋ิโำࠣࠬฬ๊ัษูࠣห้๋ิโำࠬࠤ๏฿ๅๅࠢ฼๊ิ้้ࠠษ็ฬึ์วๆฮࠣๆฬีัࠡ฻็ํࠥอำหะาห๊ࠦวๅ็๋ห็฿ࠠศๆุ่ๆืษࠨ࿮"))
	if not DDeArvFg1mW5wYbE62Uz0OkdQ8 and showDialogs: y6wFgHkKD8YLv25oX()
	return DDeArvFg1mW5wYbE62Uz0OkdQ8
def y6wFgHkKD8YLv25oX():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,GISOTJh20W(u"ࠬฮูืࠢส่๊๎วใ฻ࠣฮาะวอࠢิฬ฼ࠦๅีใิࠤํ่ฯࠡ์ๆ์๋ࠦฬ่ษี็ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬ๊ัษูࠣห้๋ิโำࠣวํࠦ็็ษๆࠤฺ๊ใๅหࠣๅ๏ࠦิ่ษาอࠥอไหึไ๎ึࠦวๅะสูฮࠦศไ๊า๎ࠥ฿ๆะๅࠣ฽้๋วࠡษ้๋ࠥะๅࠡใะูࠥอไษำ้ห๊าฺࠠๆ์ࠤ่๎ฯ๋ࠢส่ส฻ฯศำสฮࠥࡢ࡮ࠡ࠳࠺࠲࠻ࠦࠠࠧࠢࠣ࠵࠽࠴࡛࠱࠯࠼ࡡࠥࠦࠦࠡࠢ࠴࠽࠳ࡡ࠰࠮࠵ࡠࠫ࿯"))
	LW1mu0fzcYyaZkEXqjoKAde()
	return
def FeDaQc6MWl7(FMxeyLvnzabpJhCXgS6T=CJlTSEpZsWb0QHg5w):
	DVS31tWLTsGkuM68dqyrIPpgxBw = w2qb6lf5EM
	if NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࠩ࿰") not in FMxeyLvnzabpJhCXgS6T:
		DVS31tWLTsGkuM68dqyrIPpgxBw = VJZIMkUN5siqB21Pf
		LfJRKzMepo0gZ = IUHFoP2MS7n5QBvc3ZthfdN0e(E6xdOMpqISHZCn(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿱"),Olh7n0zfV4(u"ࠨะิ์ั࠭࿲"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩศีุอไࠡ็ื็้ฯࠧ࿳"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪษึูวๅࠢิืฬ๊ษࠨ࿴"),TAExSfcoNi4eORZ8HPB,rC5tnFDlQcRGA2(u"ࠫ์๊ࠠหำํำࠥษๆࠡฬิื้ࠦัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠣ࠲࠳ࠦรๆࠢอี๏ีࠠฤ่ࠣฮึูไࠡ็ื็้ฯࠠๆ๊ฯ์ิฯࠠโ์ࠣห้ฮั็ษ่ะࠥลࠧ࿵"))
		if LfJRKzMepo0gZ in [-s97s2k0LJgl(u"࠳ᅴ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠳ᅵ")]: return
		elif LfJRKzMepo0gZ==s97s2k0LJgl(u"࠵ᅶ"):
			DVS31tWLTsGkuM68dqyrIPpgxBw = w2qb6lf5EM
			FMxeyLvnzabpJhCXgS6T = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨ࿶")
	if DVS31tWLTsGkuM68dqyrIPpgxBw:
		if cbmeD4WNZfAowxT2JdUMtV(u"࠭࡟ࡑࡔࡒࡆࡑࡋࡍࡠࡑࡏࡈࡤ࠭࿷") not in FMxeyLvnzabpJhCXgS6T:
			Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(zQGaM7ctZCN(u"ࠧࡤࡧࡱࡸࡪࡸࠧ࿸"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"ࠨู๊฽ࠥอไๆึๆ่ฮࠦแ๋ࠢสุ่าไࠨ࿹"),zQGaM7ctZCN(u"ࠩๅฬ้ࠦลาีส่ࠥอไิฮ็ࠤ฾๊๊ไࠢฦ๊ࠥะใาำࠣࠤ๋็ำࠡษ็ๅ฾๊ࠠศๆำ๎ࠥษูุษๆࠤฬ๊ๅีๅ็อࠥ࠴ࠠๅๅํࠤ๏ะๅࠡฬึะ๏๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥ็๊ࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠣ࠲ࠥ๎ศะ๊้ࠤ์ึวࠡษ็ฮุา๊ๅࠢึ์ๆࠦสาี็ࠤ๊๊แࠡๆสࠤๆอฦะห้๋ࠣํࠠๅว้๋๊ࠥวࠡ์ะฮํ๐ฺࠠๆ์ࠤฬ๊ๅีๅ็อࠥอไห์ࠣฮึ๐ฯࠡษ้ฮࠥอไฦส็ห฿ูࠦ็้สࠤ࠳ࠦ็ๅࠢๅ้ฯࠦศหๅิหึࠦวๅ็ื็้ฯࠠภࠩ࿺"))
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶ᅷ"):
				PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"ࠪฮ๊ࠦลๅ฼สลࠥอไฦำึห้࠭࿻"),rC5tnFDlQcRGA2(u"้๊ࠫริใࠣฬิ๎ๆࠡฬึะ๏๊ࠠศๆุ่่๊ษࠡใํࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦแศ่ࠣห้๋ศา็ฯࠤ้อ๋ࠠีอ฻๏฿ࠠๆ฻ิๅฮࠦวๅ็ื็้ฯ้ࠠๆสࠤา๊็ศࠢ็ห๋ࠦวๅ็หี๊าࠠๅษࠣ๎฾๊ๅࠡษ็฾๏ฮࠧ࿼"))
				return
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,HaTI5u1f3SCxmMAkw(u"ࠬ็๊ࠡษ็ุฬฺษࠡษ็ๆฬีๅสࠢะหํ๊ࠠฤ่ࠣฮ่ะศࠡำึห้ฯࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ๎วีำะࠤๆ๐็ศࠢสฺ่๊ใๅหࠣวํࠦวๅ็ฺ๋ํ฿้ࠠวำหࠥษัะฬࠣะํอศࠡ็้ࠤฬ๊ๅษำ่ะࠥ็ลั่ࠣว่ะศࠡ฻้์ฬ์ࠠษำํำ่ࠦรๅว็็ฯื่็์ࠣห้ห๊ๆ์็ࠤํะะไำࠣ์้อࠠห่ึํࠥษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษࠩ࿽"))
	LLyhViKbxMntl5JSk = tmMVl2yEWYoRg1LjHfPXGc7wqK0s(header=TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡗࡳ࡫ࡷࡩࠥࡧࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧ࿾"),source=T1QDsJlUtCGhn)
	if not LLyhViKbxMntl5JSk: return
	if DVS31tWLTsGkuM68dqyrIPpgxBw: type = pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠨ࿿")
	else: type = o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠩက")
	cn0XyId7MkTCE1RifFhwQDN = nD9fpAQ50YatjGr(type,LLyhViKbxMntl5JSk,w2qb6lf5EM,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠩࡈࡑࡆࡏࡌ࠮ࡈࡕࡓࡒ࠳ࡕࡔࡇࡕࡗࠬခ"),FMxeyLvnzabpJhCXgS6T)
	return
def nEuCBY1qp6rNvPXGyF():
	FMxeyLvnzabpJhCXgS6T = yUMRP0QKIzY9BDnsV784TZmwkf(u"๋ࠪีอࠠศๆหี๋อๅอࠢ็หࠥ๐่อั่ࠣ์ࠦร๋ࠢึ๎ึ็ัࠡ์ึฮ฻๐แࠡลํࠤ๊ำส้์สฮ࠳ࠦวๅสิ๊ฬ๋ฬࠡ์ึฮำีๅࠡำ๋หอ฽้ࠠฬู้๏์ࠠๅ็ะฮํ๐วห่ࠢีๆ๎ูสࠢ฼่๎ࠦำ๋ำไีฬะࠠฯษิะ๏ฯ࠮ࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠๆีว์ู้ࠦ็ࠢฦ๎๋ࠥอห๊ํหฯࠦสๆࠢอั๊๐ไ่ษࠣ฽้๏ࠠิ์ิๅึอส๊่ࠡ์ฬู่ࠡะสีั๐ษࠡࠤ่์ฬูู่ࠡิๅࠥัวๅอࠥ࠲ࠥาๅ๋฻ࠣห้ษำๆษฤࠤํอไๆษิ็ฬะ้ࠠษ็ูํื้ࠠษ็ฺ้๋่าษอࠤ์๐ࠠฯษุอࠥฮวึฯสฬ์อ࠮ࠡษ็ฬึ์วๆฮ่ࠣฬ๊ࠦ็ฬ๊็ࠥำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠥࡊࡍࡄࡃࠣษีอࠠไษ้ࠤ้ี๊ไࠢื็ํ๏ࠠฯษุอࠥฮวๅำ๋หอ฽้ࠠษ็ฮ฻อๅ๋่ࠣห้ิวาฮํอࠥ็วๅำฯหฦࠦวๅฬ๋หฺ๊ࠠๆ฻ࠣษิอัส๊ࠢิ์ࠦวๅีํีๆืวห๋ࠢห้๋่ศไ฼ࠤฬ๊ฮศำฯ๎ฮ࠴่ࠠาสࠤฬ๊ศา่ส้ัࠦ็้ࠢหฬุอืส่ࠢฮฺ็อࠡๆ่์ฬู่ࠡษ็์๏ฮࠧဂ")
	hQbEaPTN5tnZfArRuWDcY(pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡷ࡯ࡧࡩࡶࠪဃ"),VVvcQpCU3OM09n(u"ࠬำโ้ไࠣห้฽ศฺ๋ࠢห้์ิา๋ࠢๆฬ์่็ࠢส่ศ๊แ๋ห่้๋ࠣไไ์ฬࠤฬ๊ัใ็ํอࠬင"),FMxeyLvnzabpJhCXgS6T,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩစ"))
	FMxeyLvnzabpJhCXgS6T = Olh7n0zfV4(u"ࠧࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡪࡲࡷࡹࠦࡡ࡯ࡻࠣࡧࡴࡴࡴࡦࡰࡷࠤࡴࡴࠠࡢࡰࡼࠤࡸ࡫ࡲࡷࡧࡵ࠲ࠥࡏࡴࠡࡱࡱࡰࡾࠦࡵࡴࡧࡶࠤࡱ࡯࡮࡬ࡵࠣࡸࡴࠦࡥ࡮ࡤࡨࡨࡩ࡫ࡤࠡࡥࡲࡲࡹ࡫࡮ࡵࠢࡷ࡬ࡦࡺࠠࡸࡣࡶࠤࡺࡶ࡬ࡰࡣࡧࡩࡩࠦࡴࡰࠢࡳࡳࡵࡻ࡬ࡢࡴࠣࡳࡳࡲࡩ࡯ࡧࠣࡺ࡮ࡪࡥࡰࠢ࡫ࡳࡸࡺࡩ࡯ࡩࠣࡷ࡮ࡺࡥࡴ࠰ࠣࡅࡱࡲࠠࡵࡴࡤࡨࡪࡳࡡࡳ࡭ࡶ࠰ࠥࡼࡩࡥࡧࡲࡷ࠱ࠦࡴࡳࡣࡧࡩࠥࡴࡡ࡮ࡧࡶ࠰ࠥࡹࡥࡳࡸ࡬ࡧࡪࠦ࡭ࡢࡴ࡮ࡷ࠱ࠦࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࡧࡧࠤࡼࡵࡲ࡬࠮ࠣࡰࡴ࡭࡯ࡴࠢࡵࡩ࡫࡫ࡲࡦࡰࡦࡩࡩࠦࡨࡦࡴࡨ࡭ࡳࠦࡢࡦ࡮ࡲࡲ࡬ࠦࡴࡰࠢࡷ࡬ࡪ࡯ࡲࠡࡴࡨࡷࡵ࡫ࡣࡵ࡫ࡹࡩࠥࡵࡷ࡯ࡧࡵࡷࠥ࠵ࠠࡤࡱࡰࡴࡦࡴࡩࡦࡵ࠱ࠤ࡙࡮ࡥࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡶ࡯࡯ࡵ࡬ࡦࡱ࡫ࠠࡧࡱࡵࠤࡼ࡮ࡡࡵࠢࡲࡸ࡭࡫ࡲࠡࡲࡨࡳࡵࡲࡥࠡࡷࡳࡰࡴࡧࡤࠡࡶࡲࠤ࠸ࡸࡤࠡࡲࡤࡶࡹࡿࠠࡴ࡫ࡷࡩࡸ࠴ࠠࡘࡧࠣࡹࡷ࡭ࡥࠡࡣ࡯ࡰࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࡱࡺࡲࡪࡸࡳ࠭ࠢࡷࡳࠥࡸࡥࡤࡱࡪࡲ࡮ࢀࡥࠡࡶ࡫ࡥࡹࠦࡴࡩࡧࠣࡰ࡮ࡴ࡫ࡴࠢࡦࡳࡳࡺࡡࡪࡰࡨࡨࠥࡽࡩࡵࡪ࡬ࡲࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤࡦࡸࡥࠡ࡮ࡲࡧࡦࡺࡥࡥࠢࡶࡳࡲ࡫ࡷࡩࡧࡵࡩࠥ࡫࡬ࡴࡧࠣࡳࡳࠦࡴࡩࡧࠣࡻࡪࡨࠠࡰࡴࠣࡺ࡮ࡪࡥࡰࠢࡨࡱࡧ࡫ࡤࡥࡧࡧࠤࡦࡸࡥࠡࡨࡵࡳࡲࠦ࡯ࡵࡪࡨࡶࠥࡼࡡࡳ࡫ࡲࡹࡸࠦࡳࡪࡶࡨࡷ࠳ࠦࡉࡧࠢࡼࡳࡺࠦࡨࡢࡸࡨࠤࡦࡴࡹࠡ࡮ࡨ࡫ࡦࡲࠠࡪࡵࡶࡹࡪࡹࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡤࡱࡱࡸࡦࡩࡴࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦ࡭ࡦࡦ࡬ࡥࠥ࡬ࡩ࡭ࡧࠣࡳࡼࡴࡥࡳࡵࠣ࠳ࠥ࡮࡯ࡴࡶࡨࡶࡸ࠴ࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡶ࡭ࡲࡶ࡬ࡺࠢࡤࠤࡼ࡫ࡢࠡࡤࡵࡳࡼࡹࡥࡳ࠰ࠪဆ")
	hQbEaPTN5tnZfArRuWDcY(JACnOz297UuDK5HpPkc1LF(u"ࠨ࡮ࡨࡪࡹ࠭ဇ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩࡇ࡭࡬࡯ࡴࡢ࡮ࠣࡑ࡮ࡲ࡬ࡦࡰࡱ࡭ࡺࡳࠠࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࡅࡨࡺࠠࠩࡆࡐࡇࡆ࠯ࠧဈ"),FMxeyLvnzabpJhCXgS6T,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ဉ"))
	return
def SEzRivcwpDKox7VC():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩည"))
	l6WRFE0gJStKwxCAZ7prza()
	return
def uugQ85jOAaeDyFdsPk1YJWGcLI0():
	y78P1RxJl6IhFUHoYktCDcmTeOB0S = {}
	FE4fIaSb9mtqXBvxZnwp,mlQLVIyOKqAuvCZ,sUiHLS38dbKXqcC9Z = G10GgN7HuBYaklXP6F4(VJZIMkUN5siqB21Pf)
	sdGflAoZBxPURVuF,gEqOeRhimXy7rDZ4IH0,DDk4RTUJBYFjgx,FhejcUfS9X0RHdbt4Zv1LKqkaMug,Ke5r2RYgwGAZ,DHcl1rWQJ3Ro2yF57GTf9gjSsp,yBVGs7u3TDe9kd4AHKibU = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	sdGflAoZBxPURVuF = gCc52XVMGfAnOe.join(mlQLVIyOKqAuvCZ)
	gEqOeRhimXy7rDZ4IH0 = gCc52XVMGfAnOe.join(sUiHLS38dbKXqcC9Z)
	x3xnGo4CYzf9wTrP2WO,ZJvLbAjIBT8d6kr4VhH7N5PfzUt,ZuPwHM5X97aQo8AKi0tbezB = FE4fIaSb9mtqXBvxZnwp
	for ad3z2451e09FrDHmvci,u7yIZvUxqEJFThR9PWzlAMc,N8adt2xSLvXEUfj6koMQOF in ZJvLbAjIBT8d6kr4VhH7N5PfzUt:
		N8adt2xSLvXEUfj6koMQOF = pd0Na8D5WZfHYkysVS(N8adt2xSLvXEUfj6koMQOF)
		N8adt2xSLvXEUfj6koMQOF = N8adt2xSLvXEUfj6koMQOF.strip(YvOQBzaTAscXR9ql).strip(mi2ZJXCDzITuyev6gfn(u"ࠬࠦ࠮ࠨဋ"))
		TN8amyIXdQ = ad3z2451e09FrDHmvci.replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ဌ"),GISOTJh20W(u"ࠧࡂࡒࡌࠫဍ"))
		FhejcUfS9X0RHdbt4Zv1LKqkaMug += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+TN8amyIXdQ+TDpFsQXHze2q30uYtGPfEIm8(u"ࠨ࠼ࠣࠫဎ")+oOQaRxBXyJ5jVnZ+N8adt2xSLvXEUfj6koMQOF+rJ9cgWz4FU
		if u7yIZvUxqEJFThR9PWzlAMc.isdigit(): y78P1RxJl6IhFUHoYktCDcmTeOB0S[ad3z2451e09FrDHmvci] = int(u7yIZvUxqEJFThR9PWzlAMc)
	JNkaLVdSo9MP,za7CU9GfAR,FFDquhPpJUbTsX627VQrxew = list(zip(*ZJvLbAjIBT8d6kr4VhH7N5PfzUt))
	for ad3z2451e09FrDHmvci in sorted(bXd1yvHnFAG):
		if ad3z2451e09FrDHmvci not in JNkaLVdSo9MP:
			FhejcUfS9X0RHdbt4Zv1LKqkaMug += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+ad3z2451e09FrDHmvci+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩ࠽ࠤࠬဏ")+oOQaRxBXyJ5jVnZ+zQGaM7ctZCN(u"่ࠪฬ๊้ࠦฮาࠫတ")+rJ9cgWz4FU
			if ad3z2451e09FrDHmvci not in Ew2zQ8u7Ss.non_videos_actions: DDk4RTUJBYFjgx += gCc52XVMGfAnOe+ad3z2451e09FrDHmvci
	for N8adt2xSLvXEUfj6koMQOF,CGktIKBqh4iY5TOwLJuRHMUNaXn in x3xnGo4CYzf9wTrP2WO:
		N8adt2xSLvXEUfj6koMQOF = pd0Na8D5WZfHYkysVS(N8adt2xSLvXEUfj6koMQOF)
		Ke5r2RYgwGAZ += N8adt2xSLvXEUfj6koMQOF+zQGaM7ctZCN(u"ࠫ࠿ࠦࠧထ")+Dj62UpP5MrbTkJqhRa+str(CGktIKBqh4iY5TOwLJuRHMUNaXn)+oOQaRxBXyJ5jVnZ+VzZPgf1qW5L8auj2do9R4FpiXM7Ycy
	sdGflAoZBxPURVuF = sdGflAoZBxPURVuF.strip(YvOQBzaTAscXR9ql)
	gEqOeRhimXy7rDZ4IH0 = gEqOeRhimXy7rDZ4IH0.strip(YvOQBzaTAscXR9ql)
	DDk4RTUJBYFjgx = DDk4RTUJBYFjgx.strip(YvOQBzaTAscXR9ql)
	uLGUEXer9WYJpT6P38wjCOshAbvqyf = sdGflAoZBxPURVuF+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࠦࠠ࠯࠰ࠣࠤࠬဒ")+gEqOeRhimXy7rDZ4IH0
	kkrv8pitOeIZVhJ2fT  = ZP1LyUCS3pIBu(u"࠭ๅ้ษๅ฽ࠥา๊ะหุࠣ฿๊ࠠศๆหี๋อๅอ่๊ࠢ์อࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦࠨๆ่ࠣห้ษใฬำࠣษ้๏ࠠศๆฦๆ้࠯ࠧဓ")+rJ9cgWz4FU+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"้้ࠧำหู๋ࠥ็ษ๊ࠤสึวࠡๆา๎่ࠦๅีๅ็อࠥ็๊่็ࠣๅ์๐ࠠๆ่ࠣ฽๋ีใ๊ࠡ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะࠥ๎ไศ่๊ࠢࠥอไๆ๊ๅ฽ࠬန")+rJ9cgWz4FU
	kkrv8pitOeIZVhJ2fT += Dj62UpP5MrbTkJqhRa+uLGUEXer9WYJpT6P38wjCOshAbvqyf+oOQaRxBXyJ5jVnZ+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ࡞ࡱࡠࡳ࠭ပ")
	kkrv8pitOeIZVhJ2fT += o2FdrDBimMuOw97q6QpNW8S(u"่ࠩ์ฬู่ࠡๆ่ࠤ๏ฺฺๅ่๊ࠢ์อࠠศๆหี๋อๅอࠢไ๎ิ๐่่ษอࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษ่ࠡࠪีฯฮษࠡลหะิ๐ࠩࠨဖ")+rJ9cgWz4FU+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪ์์ึวࠡ็฼๊ฬํࠠศฯอ้ฬ๊้ࠠฮ๋ำ๋ࠥิไๆฬࠤ฾์ฯไࠢฦ์ࠥ็๊ࠡษ็้ํู่ࠡล๋ࠤๆ๐ࠠศๆหี๋อๅอࠩဗ")+rJ9cgWz4FU
	DDk4RTUJBYFjgx = gCc52XVMGfAnOe.join(sorted(DDk4RTUJBYFjgx.split(gCc52XVMGfAnOe)))
	kkrv8pitOeIZVhJ2fT += Dj62UpP5MrbTkJqhRa+DDk4RTUJBYFjgx+oOQaRxBXyJ5jVnZ
	A64AfqvgwInZxHOp30Fr5j,cHAIetExn5Z0bNkP3Kaj,ttTjyP4HXp,V7mQUljGbzHCZS = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶ᅸ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶ᅸ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶ᅸ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶ᅸ")
	all = y78P1RxJl6IhFUHoYktCDcmTeOB0S[yylSaxCLfkte(u"ࠫࡆࡒࡌࠨဘ")]
	if HaTI5u1f3SCxmMAkw(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬမ") in list(y78P1RxJl6IhFUHoYktCDcmTeOB0S.keys()): A64AfqvgwInZxHOp30Fr5j = y78P1RxJl6IhFUHoYktCDcmTeOB0S[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ယ")]
	if CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧࡊࡐࡖࡘࡆࡒࡌࠨရ") in list(y78P1RxJl6IhFUHoYktCDcmTeOB0S.keys()): cHAIetExn5Z0bNkP3Kaj = y78P1RxJl6IhFUHoYktCDcmTeOB0S[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨࡋࡑࡗ࡙ࡇࡌࡍࠩလ")]
	if h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡐࡉ࡙ࡘࡏࡑࡑࡏࡍࡘ࠭ဝ") in list(y78P1RxJl6IhFUHoYktCDcmTeOB0S.keys()): ttTjyP4HXp = y78P1RxJl6IhFUHoYktCDcmTeOB0S[TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧသ")]
	if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡗࡋࡐࡐࡕࠪဟ") in list(y78P1RxJl6IhFUHoYktCDcmTeOB0S.keys()): V7mQUljGbzHCZS = y78P1RxJl6IhFUHoYktCDcmTeOB0S[VVvcQpCU3OM09n(u"ࠬࡘࡅࡑࡑࡖࠫဠ")]
	Gx0ZgJlzLFyYTt = all-A64AfqvgwInZxHOp30Fr5j-cHAIetExn5Z0bNkP3Kaj-ttTjyP4HXp-V7mQUljGbzHCZS
	Cm7xuRTdLQwZjv81V2AhKfqs04U,mbFkRHMrcv2G0XD1BLx = ZuPwHM5X97aQo8AKi0tbezB[ZVNvqy4iF1a9X]
	Cm7xuRTdLQwZjv81V2AhKfqs04U,R97RhZFw5z6jdEytW8UkXcYvxPgbi = ZuPwHM5X97aQo8AKi0tbezB[P2Fgh6TCOWoaHjkqBcQnvRNXe]
	MpFd8Qix7v5TI = mbFkRHMrcv2G0XD1BLx-R97RhZFw5z6jdEytW8UkXcYvxPgbi
	yBVGs7u3TDe9kd4AHKibU += Ym6q5M4TocDaA013RjFQ+str(R97RhZFw5z6jdEytW8UkXcYvxPgbi)+oOQaRxBXyJ5jVnZ+I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭วๅ฻าำࠥอไฮไํๆ๏ࠦไๅลฯ๋ืฯࠠ࠻ࠢࠪအ")
	yBVGs7u3TDe9kd4AHKibU += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(MpFd8Qix7v5TI)+oOQaRxBXyJ5jVnZ+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧษษึฮำีวๆࠢࡳࡶࡴࡾࡹࠡล๋ࠤࡻࡶ࡮ࠡ࠼ࠣࠫဢ")
	yBVGs7u3TDe9kd4AHKibU += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(mbFkRHMrcv2G0XD1BLx)+oOQaRxBXyJ5jVnZ+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨษ็฽ิีࠠศๆๆ่๏ࠦไอ็ํ฽ࠥอไฤฮ๊ึฮࠦ࠺ࠡࠩဣ")
	yBVGs7u3TDe9kd4AHKibU += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(len(ZuPwHM5X97aQo8AKi0tbezB[TDpFsQXHze2q30uYtGPfEIm8(u"࠲ᅹ"):]))+oOQaRxBXyJ5jVnZ+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ฼ำิࠦวๅั๋่ࠥอไห์ࠣๅ๏ํวࠡลฯ๋ืฯࠠ࠻ࠢ࡟ࡲࡡࡴࠧဤ")
	for F087kSJl1WXD93VmP2gvUQtEKiAIL,kznWKAPj2eN in ZuPwHM5X97aQo8AKi0tbezB[mi2ZJXCDzITuyev6gfn(u"࠳ᅺ"):]:
		F087kSJl1WXD93VmP2gvUQtEKiAIL = pd0Na8D5WZfHYkysVS(F087kSJl1WXD93VmP2gvUQtEKiAIL)
		F087kSJl1WXD93VmP2gvUQtEKiAIL = F087kSJl1WXD93VmP2gvUQtEKiAIL.strip(YvOQBzaTAscXR9ql).strip(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࠤ࠳࠭ဥ"))
		yBVGs7u3TDe9kd4AHKibU += F087kSJl1WXD93VmP2gvUQtEKiAIL+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࠿ࠦࠧဦ")+Dj62UpP5MrbTkJqhRa+str(kznWKAPj2eN)+oOQaRxBXyJ5jVnZ+yylSaxCLfkte(u"ࠬࠦࠠࠡࠩဧ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += Ym6q5M4TocDaA013RjFQ+str(Gx0ZgJlzLFyYTt)+oOQaRxBXyJ5jVnZ+Olh7n0zfV4(u"࠭แ๋ัํ์์อสࠡษืฮ฿๊สࠡ࠼ࠣࠫဨ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(A64AfqvgwInZxHOp30Fr5j)+oOQaRxBXyJ5jVnZ+Olh7n0zfV4(u"ุࠧๆหหฯࠦำ๋ำไีࠥࡇࡐࡊࠢ࠽ࠤࠬဩ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(V7mQUljGbzHCZS)+oOQaRxBXyJ5jVnZ+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨู็ฬฬะࠠิ์ิๅึࠦวๅ็ึฮํีูࠡ࠼ࠣࠫဪ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(cHAIetExn5Z0bNkP3Kaj)+oOQaRxBXyJ5jVnZ+O4F8UC5lMAS6ghETm1VoPDI(u"ࠩอฯอ๐สࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ࠾ࠥ࠭ါ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(ttTjyP4HXp)+oOQaRxBXyJ5jVnZ+Olh7n0zfV4(u"ࠪฮะฮ๊หࠢฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ࠺ࠡࠩာ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+str(len(x3xnGo4CYzf9wTrP2WO))+oOQaRxBXyJ5jVnZ+cjVhOCwybeRo7UWg92(u"ࠫิ๎ไࠡึ฽่ฯࠦแ๋ัํ์์อสࠡ࠼ࠣࠫိ")
	DHcl1rWQJ3Ro2yF57GTf9gjSsp += pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡢ࡮࡝ࡰࠪီ")+Ke5r2RYgwGAZ
	hQbEaPTN5tnZfArRuWDcY(ZP1LyUCS3pIBu(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ု"),mi2ZJXCDzITuyev6gfn(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦิ฻ๆ๊หࠥํะศࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠡใํࠤฬู๊ศๆ่ࠤ่๊็ࠨူ"),DHcl1rWQJ3Ro2yF57GTf9gjSsp,HaTI5u1f3SCxmMAkw(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫေ"))
	hQbEaPTN5tnZfArRuWDcY(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡦࡩࡳࡺࡥࡳࠩဲ"),KA26GucUHOwXL(u"้ࠪํอโฺࠢสุฯเไหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮࠦแ๋ࠢส่฾อไๆࠢๆ่์࠭ဳ"),kkrv8pitOeIZVhJ2fT,mi2ZJXCDzITuyev6gfn(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧဴ"))
	hQbEaPTN5tnZfArRuWDcY(E6xdOMpqISHZCn(u"ࠬࡲࡥࡧࡶࠪဵ"),HaTI5u1f3SCxmMAkw(u"࠭รฺๆ์ࠤฬ๊ฯ้ๆࠣห้ะ๊ࠡษึฮำีๅหࠢส่อืๆศ็ฯࠤๆ๐ࠠ࠴ࠢฦ๎ฬ๋ࠠศๆ่ห฻๐ษࠨံ"),FhejcUfS9X0RHdbt4Zv1LKqkaMug,yylSaxCLfkte(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࡢࡰࡴࡴࡧࠨ့"))
	return
def YsFHA4JPQg3pUhd8bTn7():
	LLyhViKbxMntl5JSk = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨ้ำหࠥอไษำ้ห๊า๋ࠠ฻่่ࠥอแืๆࠣฬฬูสฯัส้ࠥาไะࠢๆ์ิ๐ࠠࠩࡍࡲࡨ࡮ࠦࡓ࡬࡫ࡱ࠭ࠥอไั์ࠣหุ๋็࡝ࡰࠪး")+Ym6q5M4TocDaA013RjFQ+KA26GucUHOwXL(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨ္")+oOQaRxBXyJ5jVnZ+o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡠࡳࡢ࡮࡝ࡰࠣ์๊๋ใ็ࠢอฯอ๐ส่ࠢหหุะฮะษ่ࠤู๊ส้ั฼ࠤ฾๋วะࠢࡈࡑࡆࡊࠠࡓࡧࡳࡳࡸ࡯ࡴࡰࡴࡼࠤศ๎ࠠหฯ่๎้ํࠠๆ่࡟ࡲ်ࠬ")+Ym6q5M4TocDaA013RjFQ+VVvcQpCU3OM09n(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳࠬျ")+oOQaRxBXyJ5jVnZ+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡢ࡮࡝ࡰ࡟ࡲࠥํะ่ࠢส่ึูวๅหࠣ์฿๐ั่ษࠣ็ะ๐ัࠡ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢส่อืๆศ็ฯࠤํอไๆิํำࠥษ๊ืษ้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤ๊฿ไ้็สฮࠥอไษำ้ห๊าࠧြ")
	hQbEaPTN5tnZfArRuWDcY(KA26GucUHOwXL(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ွ"),TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk,otNfFapeEnO(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪှ"))
	return
def xVOWPbGFg1YI6sieKQERz():
	LLyhViKbxMntl5JSk = cjVhOCwybeRo7UWg92(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ဿ")+rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+Ew2zQ8u7Ss.SITESURLS[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨ၀")][ZVNvqy4iF1a9X]+oOQaRxBXyJ5jVnZ+o2FdrDBimMuOw97q6QpNW8S(u"ࠪࠤࠥࠦࠠฤ๊ࠣࠤࠥࠦࠧ၁")+Dj62UpP5MrbTkJqhRa+Ew2zQ8u7Ss.SITESURLS[rC5tnFDlQcRGA2(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪ၂")][P2Fgh6TCOWoaHjkqBcQnvRNXe]+oOQaRxBXyJ5jVnZ
	LLyhViKbxMntl5JSk += Olh7n0zfV4(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬ၃")+Dj62UpP5MrbTkJqhRa+Ew2zQ8u7Ss.SITESURLS[KA26GucUHOwXL(u"࠭ࡋࡐࡆࡌࡣࡘࡕࡕࡓࡅࡈࡗࠬ၄")][ZVNvqy4iF1a9X]+oOQaRxBXyJ5jVnZ+otNfFapeEnO(u"ࠧࠡࠢࠣࠤศ๎ࠠࠡࠢࠣࠫ၅")+Dj62UpP5MrbTkJqhRa+Ew2zQ8u7Ss.SITESURLS[mi2ZJXCDzITuyev6gfn(u"ࠨࡍࡒࡈࡎࡥࡓࡐࡗࡕࡇࡊ࡙ࠧ၆")][P2Fgh6TCOWoaHjkqBcQnvRNXe]+oOQaRxBXyJ5jVnZ
	LLyhViKbxMntl5JSk += E6xdOMpqISHZCn(u"ࠩ࡟ࡲࡡࡴ࡜࡯ฮ่๎฾ࠦๅๅใสฮࠥ฿ๅศั้ࠣํา่ะหࠣๅ๏ࠦวๅ็๋ๆ฾ࠦระ่ส๋ࠬ၇")+rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+Ew2zQ8u7Ss.SITESURLS[GISOTJh20W(u"ࠪࡊࡎࡒࡅࡔࡡࡖࡓ࡚ࡘࡃࡆࡕࠪ၈")][ZVNvqy4iF1a9X]+oOQaRxBXyJ5jVnZ
	hQbEaPTN5tnZfArRuWDcY(XB4CjMkPFzhAHiI3q(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ၉"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬอไๆ๊สๆ฾ࠦวๅำึ้๏ฯࠠๅสิ๊ฬ๋ฬࠡ฻่หิࠦไๅใํำ๏๎็ศฬࠣห้฿ัษ์ฬࠫ၊"),LLyhViKbxMntl5JSk,ZP1LyUCS3pIBu(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ။"))
	return
def A5CUySeaPs(clotLmegpV):
	pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(GISOTJh20W(u"ࠧࡂࡦࡧࡳࡳ࠴ࡏࡱࡧࡱࡗࡪࡺࡴࡪࡰࡪࡷ࠭࠭၌")+clotLmegpV+s97s2k0LJgl(u"ࠨࠫࠪ၍"), w2qb6lf5EM)
	return
def YPvl3tzWXfojDk():
	Qlu9Ih6YOVFw7X34(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡶࡸࡴࡶࠧ၎"))
	pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(ZP1LyUCS3pIBu(u"ࠥࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠪࠤ၏"))
	return
def QZapr9EA6yI3VNUH0G4MexF17bYhc():
	pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(HaTI5u1f3SCxmMAkw(u"ࠫࡆࡪࡤࡰࡰ࠱ࡓࡵ࡫࡮ࡔࡧࡷࡸ࡮ࡴࡧࡴࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠫࠪၐ"), w2qb6lf5EM)
	return
def JD8h3ncMo9z4TrqU5fNbaVp1jOGW7():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zz679V18GdcZwvrRexA0nNptY2Tab(u"๊ࠬๅิฯ้ࠣาะ่๋ษอࠤ็อฦๆหࠣ࠲ࠥอะ่สࠣษ้๏ࠠศๆๅหห๋ษࠡษ็ฮ๏ࠦสา์าࠤู๊อ่ษࠣ์้อࠠหัั่ࠥหไ๋้สࠤํ๊ใ็ࠢหหุะฮะษ่ࠤࠧอไๆษ๋ืࠧࠦร้ࠢࠥห้ื๊ๆ๊อࠦࠥอึ฻ูࠣ฽้๏ࠠศๆีีࠥา็สࠢส่๏๋๊็ࠢฦ์ࠥอำหะา้ࠥࠨวๅๅํฬํืฯ๋ࠣࠢห฻เืࠡ฻็ํࠥำัโࠢࠥࡇࠧࠦร้ࠢ฼่๎ࠦวื฼ฺࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠬၑ"))
	return
def mm0wQKXGtP9MS7W():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩၒ"))
	return
def ylmBACGaNLwfVugZToFbiOY(d1DfmCcuZVgXnk=o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ၓ"),showDialogs=w2qb6lf5EM):
	qhesyXgdkYi = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫၔ"))
	data = KSHcVmz2W84iQvbRDBhGldpCL.loads(qhesyXgdkYi)
	bsZVJhESTRucCQ956BFXpG = data[mi2ZJXCDzITuyev6gfn(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩၕ")][E6xdOMpqISHZCn(u"ࠪࡺࡦࡲࡵࡦࠩၖ")]
	if BB7oCRfQNSYj5qDhTUevV: bsZVJhESTRucCQ956BFXpG = bsZVJhESTRucCQ956BFXpG.encode(Im5KSGZYBpRvdMVsbuXg)
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,otNfFapeEnO(u"ࠫ์๊ࠠหำํำࠥะฺ๋์ิࠤั๊ฯࠡࠩၗ")+bsZVJhESTRucCQ956BFXpG+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࠦวๅาํࠤู๊สฯั่ࠤฬ๊ย็ࠢไ๎้่ࠥะ์ࠣษ้๏ࠠศๆศูิอัࠡษ็วำ๐ัࠡๆฯ่ิࠦࠧၘ")+d1DfmCcuZVgXnk+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࠠภࠣࠪၙ"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=TMfV6892ZoBdyxCH3tGrkwY0K(u"࠳ᅻ"): return VJZIMkUN5siqB21Pf
	cn0XyId7MkTCE1RifFhwQDN,XF9stGBpWZLMRQVP,XoHuDNTndZPawj3 = HqoSQi1g7zRhuNWswcB(d1DfmCcuZVgXnk,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	if cn0XyId7MkTCE1RifFhwQDN:
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KA26GucUHOwXL(u"ࠧห็อࠤ฾๋ไ๋หࠣฮะฮ๊หࠢส่ั๊ฯࠡษ็ะิ๐ฯ๊๊ࠡ์ࠥาว่ิ่้ࠣอำหะาห๊ࠦ࠮ࠡี๋ๅࠥ๐สๆࠢส่ว์ࠠห฼ํ๎ึࠦลฺัสำฬะࠠไ๊า๎๊ࠥใ๋ࠢํืฯ฿ๅๅࠢส่ั๊ฯࠡษ็ะิ๐ฯࠡสา่ฬࠦๅ็ࠢส่็ี๊ๆࠩၚ"))
		GzWuVjwZgDKa5PCcQTM4 = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(cjVhOCwybeRo7UWg92(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬၛ")+d1DfmCcuZVgXnk+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࠥࢁࢂ࠭ၜ"))
		cn0XyId7MkTCE1RifFhwQDN = w2qb6lf5EM if zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡓࡐ࠭ၝ") in GzWuVjwZgDKa5PCcQTM4 else VJZIMkUN5siqB21Pf
		L8Wkv5KCSoq.sleep(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠴ᅼ"))
		pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(s97s2k0LJgl(u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫၞ"))
	elif showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,ZP1LyUCS3pIBu(u"๊ࠬไฤีไࠤๆฺไหࠢ฼้้๐ษࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊ࠠศๆฯ่ิࠦวๅ็ฺ่ํฮࠧၟ"))
	return cn0XyId7MkTCE1RifFhwQDN
def LW1mu0fzcYyaZkEXqjoKAde():
	url = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡪࡴࡵࡳࡷࡹ࠮࡬ࡱࡧ࡭࠳ࡺࡶ࠰ࡴࡨࡰࡪࡧࡳࡦࡵ࠲ࡻ࡮ࡴࡤࡰࡹࡶ࠳ࡼ࡯࡮࠷࠶࠲ࠫၠ")
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,zQGaM7ctZCN(u"ࠧࡈࡇࡗࠫၡ"),url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,EcjO3giln2kQTdBY0XLAG(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡗࡍࡕࡗࡠࡎࡄࡘࡊ࡙ࡔࡠࡍࡒࡈࡎࡥࡖࡆࡔࡖࡍࡔࡔ࠭࠲ࡵࡷࠫၢ"))
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ccYPCymQV1ISwuvrtT7 = Zy2l0g8QU5vqefaTrsw.findall(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤ࡮ࡳࡩ࡯࠭ࠩ࡞ࡧ࠯ࡡ࠴࡜ࡥ࠭࠰࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠯࠭ࠨၣ"),bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ccYPCymQV1ISwuvrtT7 = ccYPCymQV1ISwuvrtT7[ZVNvqy4iF1a9X].split(XB4CjMkPFzhAHiI3q(u"ࠪ࠱ࠬၤ"))[ZVNvqy4iF1a9X]
	ZKpD8S9zRX3EGL0W = str(K9MoWfyg6w2EHIki4lLtFSzpxQTmRX)
	FhejcUfS9X0RHdbt4Zv1LKqkaMug = NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡠࡘࡔࡍ࡟ศูิอัࠡๅ๋ำ๏ࠦวๅลั๎ึࠦวๅ็อ์ๆืࠠศๆล๊ࠥํ่ࠡ࠼ࠣࠤࠥ࠭ၥ")+Ym6q5M4TocDaA013RjFQ+ccYPCymQV1ISwuvrtT7+oOQaRxBXyJ5jVnZ
	FhejcUfS9X0RHdbt4Zv1LKqkaMug += O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡢ࡮࡝ࡰࠪၦ")+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࡛࠭ࡓࡖࡏࡡส฻ฯศำࠣ็ํี๊ࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ์๎ࠠ࠻ࠢࠣࠤࠬၧ")+Ym6q5M4TocDaA013RjFQ+ZKpD8S9zRX3EGL0W+oOQaRxBXyJ5jVnZ
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,FhejcUfS9X0RHdbt4Zv1LKqkaMug)
	return
def cxBlpMJj8G01LdHqrXfwZsKNa():
	WLpi4QVZdqBAJO1ny8MYmFc7Kt5xe,pOmiI03oQxVfPt,Yx83qjJ5UCvet = VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	ifXzRKsnPc,tyX65O2TQDxJhvz0i73SYP94eBEu,CCfZ34x8RPtDr9OqM7ahozNJX5 = VJZIMkUN5siqB21Pf,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	SFKVM29ObyREINTkpeYnl = [KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬၨ"),rC5tnFDlQcRGA2(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦࠪၩ"),zQGaM7ctZCN(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨၪ")]
	a50MeDjfCnLNzihu = fxpB0b5NLy6EdFzR3HGPTA(SFKVM29ObyREINTkpeYnl)
	for R7xafKV3ekjDc in SFKVM29ObyREINTkpeYnl:
		if R7xafKV3ekjDc not in list(a50MeDjfCnLNzihu.keys()): continue
		a1soztfTFIlNcHiyQE,VQ5UjWuFyntkMKDJO0xL9cSHI1bs87,ym8QhkAEsUdvWLpNxCnOS,DSFpkLealC5dni,ywMG2KRhO1zC3ZeNb4rs,qkG4rtz0bKE5vHXVfIRZ8joJw2yaW,x1MmilJ8qBSa3Rr = a50MeDjfCnLNzihu[R7xafKV3ekjDc]
		if R7xafKV3ekjDc==EcjO3giln2kQTdBY0XLAG(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨၫ"):
			ifXzRKsnPc = a1soztfTFIlNcHiyQE
			tyX65O2TQDxJhvz0i73SYP94eBEu = VQ5UjWuFyntkMKDJO0xL9cSHI1bs87+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࠥࠦࠠࠡࠪࠣࠫၬ")+HRYMpjUhOiul4zdP7G8c(qkG4rtz0bKE5vHXVfIRZ8joJw2yaW)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࠦࠩࠨၭ")
			CCfZ34x8RPtDr9OqM7ahozNJX5 = DSFpkLealC5dni
		elif R7xafKV3ekjDc==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤࠨၮ"):
			WLpi4QVZdqBAJO1ny8MYmFc7Kt5xe = WLpi4QVZdqBAJO1ny8MYmFc7Kt5xe or a1soztfTFIlNcHiyQE
			pOmiI03oQxVfPt += VVvcQpCU3OM09n(u"ࠧࠡࠢ࠯ࠤࠥ࠭ၯ")+VQ5UjWuFyntkMKDJO0xL9cSHI1bs87+cjVhOCwybeRo7UWg92(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨၰ")+HRYMpjUhOiul4zdP7G8c(qkG4rtz0bKE5vHXVfIRZ8joJw2yaW)+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࠣ࠭ࠬၱ")
			Yx83qjJ5UCvet += zQGaM7ctZCN(u"ࠪࠤࠥ࠲ࠠࠡࠩၲ")+DSFpkLealC5dni
		elif R7xafKV3ekjDc==cjVhOCwybeRo7UWg92(u"ࠫࡸࡱࡩ࡯࠰ࡰࡩࡹࡸ࡯ࡱࡱ࡯࡭ࡸࡋࡍࡂࡆࠪၳ"):
			h7I0kc4zT1tW5y8AsJUOMbfmeu = a1soztfTFIlNcHiyQE
			CTxEW0Ydp3Q4nR97uDIhFK1L5 = VQ5UjWuFyntkMKDJO0xL9cSHI1bs87+s97s2k0LJgl(u"ࠬࠦࠠࠡࠢࠫࠤࠬၴ")+HRYMpjUhOiul4zdP7G8c(qkG4rtz0bKE5vHXVfIRZ8joJw2yaW)+GISOTJh20W(u"࠭ࠠࠪࠩၵ")
			wjQN4mCpeZz7Pi = DSFpkLealC5dni
	pOmiI03oQxVfPt = pOmiI03oQxVfPt.strip(o2FdrDBimMuOw97q6QpNW8S(u"ࠧࠡࠢ࠯ࠤࠥ࠭ၶ"))
	Yx83qjJ5UCvet = Yx83qjJ5UCvet.strip(ZP1LyUCS3pIBu(u"ࠨࠢࠣ࠰ࠥࠦࠧၷ"))
	nUsbOI0kqGy  = rC5tnFDlQcRGA2(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆหี๋อๅอࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧၸ")+Ym6q5M4TocDaA013RjFQ+CCfZ34x8RPtDr9OqM7ahozNJX5+oOQaRxBXyJ5jVnZ
	nUsbOI0kqGy += rJ9cgWz4FU+HaTI5u1f3SCxmMAkw(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥศา่ส้ัูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬၹ")+Ym6q5M4TocDaA013RjFQ+tyX65O2TQDxJhvz0i73SYP94eBEu+oOQaRxBXyJ5jVnZ
	nUsbOI0kqGy += ZP1LyUCS3pIBu(u"ࠫࡡࡴ࡜࡯ࠩၺ")+zQGaM7ctZCN(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้๋ำห๊า฽ࠥ฿ๅศัࠣห้๋ส้ใิࠤฬ๊ย็๊ࠢ์ࠥࡀࠠࠡࠢࠪၻ")+Ym6q5M4TocDaA013RjFQ+Yx83qjJ5UCvet+oOQaRxBXyJ5jVnZ
	nUsbOI0kqGy += rJ9cgWz4FU+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆ่ืฯ๎ฯฺࠢ฼้ฬี่๊ࠠࠣ࠾ࠥࠦࠠࠨၼ")+Ym6q5M4TocDaA013RjFQ+pOmiI03oQxVfPt+oOQaRxBXyJ5jVnZ
	nUsbOI0kqGy += EcjO3giln2kQTdBY0XLAG(u"ࠧ࡝ࡰ࡟ࡲࠬၽ")+KA26GucUHOwXL(u"ࠨ࡝ࡕࡘࡑࡣวๅวุำฬืࠠศๆฦา๏ืࠠๅฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥอไๆฬ๋ๅึࠦวๅฤ้ࠤ์๎ࠠ࠻ࠢࠣࠤࠬၾ")+Ym6q5M4TocDaA013RjFQ+wjQN4mCpeZz7Pi+oOQaRxBXyJ5jVnZ
	nUsbOI0kqGy += rJ9cgWz4FU+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็ิ๏ࠦว็ฬࠣฮุะฮะ็๊ࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะ๊ࠢ์ࠥࡀࠠࠡࠢࠪၿ")+Ym6q5M4TocDaA013RjFQ+CTxEW0Ydp3Q4nR97uDIhFK1L5+oOQaRxBXyJ5jVnZ
	a1soztfTFIlNcHiyQE = ifXzRKsnPc or WLpi4QVZdqBAJO1ny8MYmFc7Kt5xe
	if a1soztfTFIlNcHiyQE:
		header = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪห้ืฬศรࠣฮาี๊ฬࠢศฺฬ็วหࠢๆ์ิ๐ࠠๅฯ็ࠤฬ๊ๅีษๆ่ࠬႀ")
		r0XwiCFev4oKqbZm5upBQk = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫฬ์สࠡสะหัฯࠠๅฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำࠥษ่ࠡฬะำ๏ัࠠๆีอ์ิ฿ฺࠠ็สำࠬႁ")
	else:
		header = EcjO3giln2kQTdBY0XLAG(u"ࠬำวๅ์สࠤ้อ๋๊ࠠฯำࠥะอะ์ฮหฯࠦไษำ้ห๊าฺࠠ็สำࠥษ่ࠡ็ึฮํีูࠡ฻่หิ࠭ႂ")
		r0XwiCFev4oKqbZm5upBQk = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭วๅำฯหฦࠦลษๆส฾ࠥอไๆสิ้ัูࠦ็ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬ๋หัํใࠨႃ")
	wmq6DlWebQ8 = pz4WBwfyDdgk0m2aRr7SMv(u"ࠧๅๅํࠤ๏฿ๅๅࠢ฼๊ิ้ࠠศๆอัิ๐หࠡษ็ฮ้่วว์ࠣ๎ัฮࠠฤ่ࠣ๎่๎ๆࠡๆา๎่ࠦแ๋ࠢๆ์ิ๐࡜࡯็ึฮํีูࠡ฻่หิࠦࡅࡎࡃࡇࠤࡗ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹࠨႄ")
	ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5 = nUsbOI0kqGy+E6xdOMpqISHZCn(u"ࠨ࡞ࡱࡠࡳ࠭ႅ")+r0XwiCFev4oKqbZm5upBQk+TDpFsQXHze2q30uYtGPfEIm8(u"ࠩ࡟ࡲࡡࡴࠧႆ")+wmq6DlWebQ8
	hQbEaPTN5tnZfArRuWDcY(EcjO3giln2kQTdBY0XLAG(u"ࠪࡶ࡮࡭ࡨࡵࠩႇ"),header,ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,o2FdrDBimMuOw97q6QpNW8S(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧႈ"))
	return a1soztfTFIlNcHiyQE
def LiTv20I56DgO(R7xafKV3ekjDc,x1MmilJ8qBSa3Rr,showDialogs):
	cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TMfV6892ZoBdyxCH3tGrkwY0K(u"ู่ࠬโࠢํฮ๊ࠦวๅฤ้ࠤั๊ศࠡษ็้้็ࠠศๆฺ่฿๎ืࠡๆ็ษ฻อแสࠢส่๊฽ไ้สฬࠤ้้๊ࠡ์อ้ࠥะหษ์อ๋ࠥ฿ไ๊ࠢๆ์ิ๐ࠠ࠯ࠢส่๊๊แࠡไาࠤ๏้่็ࠢๆฬ๏ื้ࠠไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦ࠮้ࠡ็ࠤฯื๊ะࠢอั๊๐ไࠡษ็้้็ࠠศๆล๊ࠥลࠡࠨႉ"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=P2Fgh6TCOWoaHjkqBcQnvRNXe: return VJZIMkUN5siqB21Pf
	MZzrwhJkUejWBfOE4uy = AznaIjR5kDMBf(x1MmilJ8qBSa3Rr,{},showDialogs)
	if MZzrwhJkUejWBfOE4uy:
		FvTzqfmBX45bVGgODprR = tiFgl4DMvGEAUfjIYkHbr05.path.join(ORM3fVHnueUmCZhN57EF,R7xafKV3ekjDc)
		xyP9q8HGgDkNbL4WFnd5lfVh(FvTzqfmBX45bVGgODprR,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
		import zipfile as QQYvJrc358uxEdpPa,io as Y6IlFkUwxDV1mCq7
		ssOKDQJhetpYrHCWbFNIzxZ = Y6IlFkUwxDV1mCq7.BytesIO(MZzrwhJkUejWBfOE4uy)
		try:
			R4FU8xzGaLpTIuNY3O = QQYvJrc358uxEdpPa.ZipFile(ssOKDQJhetpYrHCWbFNIzxZ)
			R4FU8xzGaLpTIuNY3O.extractall(ORM3fVHnueUmCZhN57EF)
			L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
			pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(s97s2k0LJgl(u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪႊ"))
			L8Wkv5KCSoq.sleep(P2Fgh6TCOWoaHjkqBcQnvRNXe)
			cn0XyId7MkTCE1RifFhwQDN = MadR5Fhf786e3wg(R7xafKV3ekjDc)
		except: cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
	if showDialogs:
		if cn0XyId7MkTCE1RifFhwQDN: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cjVhOCwybeRo7UWg92(u"ࠧห็ࠣฬ๋าวฮࠢอฯอ๐สࠡษ็ษ฻อแสࠢส่๊฽ไ้สฬࠫႋ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TDpFsQXHze2q30uYtGPfEIm8(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ࠭ႌ"))
	return cn0XyId7MkTCE1RifFhwQDN
def nn3q8dAwhfx(R7xafKV3ekjDc,showDialogs=w2qb6lf5EM):
	if showDialogs==CJlTSEpZsWb0QHg5w: showDialogs = w2qb6lf5EM
	pz7VsmOZtBlgULS1br46 = NNbhkjvUe2WfgxTrOznLK1yBEmi([R7xafKV3ekjDc])
	sAJkjqRNdCLDhSaEb1QiF,TTLvC9uqVUB0EHXab2FQ3P = pz7VsmOZtBlgULS1br46[R7xafKV3ekjDc]
	if TTLvC9uqVUB0EHXab2FQ3P:
		cn0XyId7MkTCE1RifFhwQDN = w2qb6lf5EM
		if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cjVhOCwybeRo7UWg92(u"ࠩไัฺࠦวๅวูหๆฯࠠ࡝ࡰႍࠣࠫ")+R7xafKV3ekjDc+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࠤࡡࡴ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭ႎ"))
	else:
		cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫႏ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,CJlTSEpZsWb0QHg5w+R7xafKV3ekjDc+rC5tnFDlQcRGA2(u"ࠬࠦ࡜࡯࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ์ฬ๊ศา่ส้ัࠦศฮษฯอ๊ࠥ็ศࠢ࠱ࠤ์๊ࠠหำํำࠥะหษ์อࠤํะแฺ์็ࠤ์ึ็ࠡษ็ษ฻อแสࠢส่ว์ࠠภࠩ႐"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==ZP1LyUCS3pIBu(u"࠵ᅽ"):
			pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(cjVhOCwybeRo7UWg92(u"࠭ࡉ࡯ࡵࡷࡥࡱࡲࡁࡥࡦࡲࡲ࠭࠭႑")+R7xafKV3ekjDc+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࠪࠩ႒"))
			L8Wkv5KCSoq.sleep(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠶ᅾ"))
			pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(KA26GucUHOwXL(u"ࠨࡕࡨࡲࡩࡉ࡬ࡪࡥ࡮ࠬ࠶࠷ࠩࠨ႓"))
			L8Wkv5KCSoq.sleep(GISOTJh20W(u"࠷ᅿ"))
			while pKVikfGen4wMt80UTscxWjAoCZ5S.getCondVisibility(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࡚ࠩ࡭ࡳࡪ࡯ࡸ࠰ࡌࡷࡆࡩࡴࡪࡸࡨࠬࡵࡸ࡯ࡨࡴࡨࡷࡸࡪࡩࡢ࡮ࡲ࡫࠮࠭႔")): L8Wkv5KCSoq.sleep(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠱ᆀ"))
			cn0XyId7MkTCE1RifFhwQDN = MadR5Fhf786e3wg(R7xafKV3ekjDc)
			if showDialogs and cn0XyId7MkTCE1RifFhwQDN: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,GISOTJh20W(u"ࠪฮ๊ࠦแฮืࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮ่่ࠦ์ࠣห้ศๆࠡฮส๋ืฯࠠๅๆสืฯิฯศ็ࠪ႕"))
			elif showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫๆฺไࠡใํࠤฯัศ๋ฬࠣวํࠦสโ฻ํ่ࠥษ่ࠡฬะำ๏ัࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠣ࠲ࠥ๎วๅฯ็ࠤ์๎ࠠหอห๎ฯํว๊ࠡอๅ฾๐ไ่ษ้๋ࠣࠦฮศำฯࠤฬ๊ศา่ส้ั࠭႖"))
	return cn0XyId7MkTCE1RifFhwQDN
def MBbzLpFV7iKohH9SYk2QlE(showDialogs):
	if not showDialogs: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = w2qb6lf5EM
	else: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ႗"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,HaTI5u1f3SCxmMAkw(u"࠭ศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢห฽๊๊๊สࠢอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡฬ็ๆฬฬ๊ศࠢๆ่ࠥ࠸࠴ࠡีส฽ฮ่ࠦๅๅ้ࠤ๊๋ใ็ࠢศะึอม่ษࠣห้ศๆࠡ࠰๋้ࠣࠦสา์าࠤฬ๊ย็ࠢฦ๊ࠥะืๅส้๋ࠣࠦใ้ัํࠤๆำี๊ࠡอัิ๐หࠡฮ่๎฾ࠦวๅวูหๆอสࠡมࠪ႘"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠲ᆁ"):
		pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡖࡲࡧࡥࡹ࡫ࡁࡥࡦࡲࡲࡗ࡫ࡰࡰࡵࠪ႙"))
		if showDialogs:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,EcjO3giln2kQTdBY0XLAG(u"ࠨฬ่ࠤสืำศๆࠣ฻้ฮࠠฦๆ์ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢส่ี๐ࠠโ์ࠣะ์อาไࠢ็็๏๊ࠦใ๊่ࠤอะอะ์ฮࠤัฺ๋๊ࠢศฺฬ็วหࠢๆ์ิ๐ࠠ࠯ࠢห้ฬࠦแ๋้สࠤฯำฯ๋อ๋ࠣีอࠠศๆหี๋อๅอ๋ࠢฮาี๊ฬ่ࠢืฯ๎ฯฺࠢ฼้ฬีࠠ࠯ࠢํีั๏ࠠฦ฻ฺหฦࠦใ้ัํࠤ࠺ࠦฯใษษๆࠥษ่ࠡลๆฯึࠦไไ์ࠣ๎๋ํ๊ࠡ฻่่๏ฯࠠศๆอัิ๐หࠨႚ"))
	return
def fxdNEv1heTwKZ6WrC():
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,KA26GucUHOwXL(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࡤ࠷ࠧႛ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫႜ"))
	LW1mu0fzcYyaZkEXqjoKAde()
	a1soztfTFIlNcHiyQE = cxBlpMJj8G01LdHqrXfwZsKNa()
	if a1soztfTFIlNcHiyQE:
		DkcrxeMRug629ZVS7FUdNlQ(w2qb6lf5EM)
		MBbzLpFV7iKohH9SYk2QlE(w2qb6lf5EM)
		nYgsitVoc3E(VJZIMkUN5siqB21Pf)
	return
def MadR5Fhf786e3wg(R7xafKV3ekjDc):
	SD0TxMRXiep4cjPBsnzI = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(HaTI5u1f3SCxmMAkw(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡅࡩࡪ࡯࡯ࡵ࠱ࡗࡪࡺࡁࡥࡦࡲࡲࡊࡴࡡࡣ࡮ࡨࡨࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡥࡩࡪ࡯࡯࡫ࡧࠦ࠿ࠨࠧႝ")+R7xafKV3ekjDc+GISOTJh20W(u"ࠬࠨࠬࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪ႞"))
	succeeded = w2qb6lf5EM if E6xdOMpqISHZCn(u"࠭ࡏࡌࠩ႟") in SD0TxMRXiep4cjPBsnzI else VJZIMkUN5siqB21Pf
	return succeeded
def vtDL4ASElbKdms1GJTNhn5(R7xafKV3ekjDc):
	SD0TxMRXiep4cjPBsnzI = pKVikfGen4wMt80UTscxWjAoCZ5S.executeJSONRPC(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠪႠ")+R7xafKV3ekjDc+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࠤ࠯ࠦࡪࡴࡡࡣ࡮ࡨࡨࠧࡀࡦࡢ࡮ࡶࡩࢂࢃࠧႡ"))
	succeeded = w2qb6lf5EM if pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡒࡏࠬႢ") in SD0TxMRXiep4cjPBsnzI else VJZIMkUN5siqB21Pf
	return succeeded
def HqoSQi1g7zRhuNWswcB(R7xafKV3ekjDc,showDialogs,iKO5fHpgV3utwY0yNmvc,a50MeDjfCnLNzihu=None):
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa,succeeded,XF9stGBpWZLMRQVP,VQ5UjWuFyntkMKDJO0xL9cSHI1bs87 = w2qb6lf5EM,VJZIMkUN5siqB21Pf,O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪႣ"),CJlTSEpZsWb0QHg5w
	if not a50MeDjfCnLNzihu: a50MeDjfCnLNzihu = fxpB0b5NLy6EdFzR3HGPTA([R7xafKV3ekjDc])
	if R7xafKV3ekjDc in list(a50MeDjfCnLNzihu.keys()):
		a1soztfTFIlNcHiyQE,VQ5UjWuFyntkMKDJO0xL9cSHI1bs87,ym8QhkAEsUdvWLpNxCnOS,DSFpkLealC5dni,ywMG2KRhO1zC3ZeNb4rs,qkG4rtz0bKE5vHXVfIRZ8joJw2yaW,x1MmilJ8qBSa3Rr = a50MeDjfCnLNzihu[R7xafKV3ekjDc]
		if qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫ࡬ࡵ࡯ࡥࠩႤ"):
			succeeded,XF9stGBpWZLMRQVP = w2qb6lf5EM,otNfFapeEnO(u"ࠬࡴ࡯ࡵࡪ࡬ࡲ࡬࠭Ⴅ")
			if iKO5fHpgV3utwY0yNmvc and showDialogs:
				Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,otNfFapeEnO(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭Ⴆ")+R7xafKV3ekjDc+otNfFapeEnO(u"ࠧ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡ็ิอࠥษฮา๋ࠪႧ"))
				if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
					succeeded = LiTv20I56DgO(R7xafKV3ekjDc,x1MmilJ8qBSa3Rr,VJZIMkUN5siqB21Pf)
					if succeeded:
						XF9stGBpWZLMRQVP = XB4CjMkPFzhAHiI3q(u"ࠨࡴࡨ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭Ⴈ")
						if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,s97s2k0LJgl(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋่ࠥอ๊าอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสศ฽ฬีษࠡฬฮฬ๏ะ็ศ࡞ࡱࡠࡳ࠭Ⴉ")+R7xafKV3ekjDc)
					else:
						XF9stGBpWZLMRQVP = XB4CjMkPFzhAHiI3q(u"ࠪࡪࡦ࡯࡬ࡦࡦࠪႪ")
						PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,E6xdOMpqISHZCn(u"้๊ࠫริใࠣ࠲࠳ࠦวๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ูสุ์฼ࠤส฿วะหࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫႫ")+R7xafKV3ekjDc)
		else:
			if showDialogs:
				if qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬࡪࡩࡴࡣࡥࡰࡪࡪࠧႬ"): LLyhViKbxMntl5JSk = yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ๅห๊ๅๅฮ࠭Ⴍ")
				elif qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡰ࡮ࡧࠫႮ"): LLyhViKbxMntl5JSk = rC5tnFDlQcRGA2(u"ࠨไา๎๊ฯࠧႯ")
				elif qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪႰ"): LLyhViKbxMntl5JSk = rC5tnFDlQcRGA2(u"ࠪ฾๏ืࠠๆอหฮฮ࠭Ⴑ")
				Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,s97s2k0LJgl(u"ࠫ์ึ็ࠡษ็ษ฻อแสࠢࠪႲ")+LLyhViKbxMntl5JSk+GISOTJh20W(u"ࠬࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษฺ๊วฮ๊ࠢิ์ࠦวๅ็ื็้ฯࠠภࠣ࡟ࡲࡡࡴࠧႳ")+R7xafKV3ekjDc)
			if not Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa: XF9stGBpWZLMRQVP = JACnOz297UuDK5HpPkc1LF(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨႴ")
			else:
				if qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==zQGaM7ctZCN(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩႵ"):
					succeeded = MadR5Fhf786e3wg(R7xafKV3ekjDc)
					if succeeded:
						XF9stGBpWZLMRQVP = cbmeD4WNZfAowxT2JdUMtV(u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩႶ")
						if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩฯ๎ิࠦฬะษࠣ࠲࠳ࠦวๅวูหๆฯࠠไษ้ฮ๋ࠥส้ไไอࠥ࠴࠮๊ࠡๅห๊ࠦวๅสิ๊ฬ๋ฬࠡสอุ฿๐ไ่ษ࡟ࡲࡡࡴࠧႷ")+R7xafKV3ekjDc)
					elif showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"่้ࠪษำโࠢ࠱࠲ࠥอไฦุสๅฮࠦๅห๊ๅๅฮࠦ࠮࠯๋่๊๊ࠢࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡฬื฾๏๊็ศ࡞ࡱࡠࡳ࠭Ⴘ")+R7xafKV3ekjDc)
				elif qkG4rtz0bKE5vHXVfIRZ8joJw2yaW in [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠫࡴࡲࡤࠨႹ"),KA26GucUHOwXL(u"ࠬࡳࡩࡴࡵ࡬ࡲ࡬࠭Ⴚ")]:
					succeeded = LiTv20I56DgO(R7xafKV3ekjDc,x1MmilJ8qBSa3Rr,VJZIMkUN5siqB21Pf)
					if succeeded:
						if qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==E6xdOMpqISHZCn(u"࠭࡯࡭ࡦࠪႻ"): XF9stGBpWZLMRQVP = XB4CjMkPFzhAHiI3q(u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨႼ")
						elif qkG4rtz0bKE5vHXVfIRZ8joJw2yaW==yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨ࡯࡬ࡷࡸ࡯࡮ࡨࠩႽ"): XF9stGBpWZLMRQVP = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠬႾ")
						VQ5UjWuFyntkMKDJO0xL9cSHI1bs87 = DSFpkLealC5dni
						if showDialogs:
							if XF9stGBpWZLMRQVP==rC5tnFDlQcRGA2(u"ࠪࡹࡵࡪࡡࡵࡧࡧࠫႿ"): PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫั๐ฯࠡฮาหࠥ࠴࠮ࠡษ็ษ฻อแสࠢๆห๋ะࠠใัํ้ฮࠦ࠮࠯๋ࠢห้ฮั็ษ่ะ่ࠥวๆࠢหฮาี๊ฬ้สࡠࡳࡢ࡮ࠨჀ")+R7xafKV3ekjDc)
							elif XF9stGBpWZLMRQVP==yylSaxCLfkte(u"ࠬ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨჁ"): PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧჂ")+R7xafKV3ekjDc)
					elif showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢส่อืๆศ็ฯࠤ้๋๋ࠠีอ฻๏฿ࠠหฯา๎ะࠦร้ࠢอฯอ๐ส้ࠡำ๋ࠥอไฦุสๅฮࡢ࡮࡝ࡰࠪჃ")+R7xafKV3ekjDc)
	elif showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,HaTI5u1f3SCxmMAkw(u"ࠨๆ็วุ็ࠠ࠯࠰๋ࠣีํࠠศๆศฺฬ็ษࠡ฼ํี๋่ࠥอ๊าอࠥ็๊ࠡ็ึฮํีูࠡ฻่หิࠦ࠮࠯๋่ࠢ์ึวࠡๆสࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦร็ࠢํๆํ๋ࠠษฬฮฬ๏ะ่ࠠา๊ࠤฬ๊ลืษไอࠥษ่ࠡฬะำ๏ั็ศ࡞ࡱࡠࡳ࠭Ⴤ")+R7xafKV3ekjDc)
	return succeeded,XF9stGBpWZLMRQVP,VQ5UjWuFyntkMKDJO0xL9cSHI1bs87
def loBHfukKV4AGCtbFIvc7Y0eiLNJ(R7xafKV3ekjDc,showDialogs,U6z13M7sDFNbjLtyQ9):
	GG0sJNhYLx6dPrSkFeobaCAuH2f = Izg3hVy4Nx1oOU6L29DFkmqnZ.connect(JTRCZri9Oka5mAUslqIhz0)
	GG0sJNhYLx6dPrSkFeobaCAuH2f.text_factory = str
	CUYvKkg403sS1yxGoTbWDhJAXN = GG0sJNhYLx6dPrSkFeobaCAuH2f.cursor()
	succeeded,utj0e6NiX92WDJcvaybfpEqk = w2qb6lf5EM,VJZIMkUN5siqB21Pf
	try:
		GexHg08dqaf7pC = TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫჅ")
		CUYvKkg403sS1yxGoTbWDhJAXN.execute(XB4CjMkPFzhAHiI3q(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡳࡷ࡯ࡧࡪࡰࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡂࠦࠢࠨ჆")+R7xafKV3ekjDc+VVvcQpCU3OM09n(u"ࠫࠧࠦ࠻ࠨჇ"))
		FlhSkMf52TtUubsO = CUYvKkg403sS1yxGoTbWDhJAXN.fetchall()
		if FlhSkMf52TtUubsO and GexHg08dqaf7pC not in str(FlhSkMf52TtUubsO): CUYvKkg403sS1yxGoTbWDhJAXN.execute(h6sIkJOT5PB2vCxqo4LFag70wA(u"࡛ࠬࡐࡅࡃࡗࡉࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࡕࡈࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡃࠠࠣࠩ჈")+GexHg08dqaf7pC+rC5tnFDlQcRGA2(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬ჉")+R7xafKV3ekjDc+KA26GucUHOwXL(u"ࠧࠣࠢ࠾ࠫ჊"))
		Ud0YQK1PNSfw8FV6voB3xpyeT = mi2ZJXCDzITuyev6gfn(u"ࠨࡤ࡯ࡥࡨࡱ࡬ࡪࡵࡷࠫ჋") if BB7oCRfQNSYj5qDhTUevV else KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࡸࡴࡩࡧࡴࡦࡡࡵࡹࡱ࡫ࡳࠨ჌")
		CUYvKkg403sS1yxGoTbWDhJAXN.execute(NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡗࡊࡒࡅࡄࡖࠣ࠮ࠥࡌࡒࡐࡏࠣࠫჍ")+Ud0YQK1PNSfw8FV6voB3xpyeT+VVvcQpCU3OM09n(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩ჎")+R7xafKV3ekjDc+yylSaxCLfkte(u"ࠬࠨࠠ࠼ࠩ჏"))
		FlhSkMf52TtUubsO = CUYvKkg403sS1yxGoTbWDhJAXN.fetchall()
		if FlhSkMf52TtUubsO:
			if showDialogs: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,O4F8UC5lMAS6ghETm1VoPDI(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪა")+R7xafKV3ekjDc+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧბ")+Dj62UpP5MrbTkJqhRa+o2FdrDBimMuOw97q6QpNW8S(u"ࠨ่ࠢฮํ่แ๊ࠡ็หࠥ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠหใ฼๎้ํࠠศๆล๊ࠥลࠡࠢࠢࠪგ")+oOQaRxBXyJ5jVnZ+HaTI5u1f3SCxmMAkw(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡวํๆฬ็็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧდ"))
			else: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = P2Fgh6TCOWoaHjkqBcQnvRNXe
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
				utj0e6NiX92WDJcvaybfpEqk = w2qb6lf5EM
				CUYvKkg403sS1yxGoTbWDhJAXN.execute(cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩე")+Ud0YQK1PNSfw8FV6voB3xpyeT+GISOTJh20W(u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡦࡪࡤࡰࡰࡌࡈࠥࡃࠠࠣࠩვ")+R7xafKV3ekjDc+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࠨࠠ࠼ࠩზ"))
		elif U6z13M7sDFNbjLtyQ9:
			if showDialogs: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭วๅฬะำ๏ัࠠศๆฦ์ฯ๎ๅศฬํ็๏ࠦไฦุสๅฮࠦ࡜࡯ࠢࠪთ")+R7xafKV3ekjDc+pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࠡ࡞ࡱࡠࡳࠦࠧი")+Dj62UpP5MrbTkJqhRa+yylSaxCLfkte(u"ࠨ่ࠢๅ฾๊้ࠠ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣษ๏่วโ้ࠣห้ศๆࠡมࠤࠥࠥ࠭კ")+oOQaRxBXyJ5jVnZ+EcjO3giln2kQTdBY0XLAG(u"ࠩࠣࡠࡳࡢ࡮ࠡฬึฮ฼๐ูࠡฬไ฽๏๊็ࠡสึ๋ํ๊ษࠡ฻้ำࠥอไฺ๊าอࠥหไ๊๊ࠢิ์ࠦวๅึสุฮࠦวๅ็๋ะํีษࠡใํࠤ็อฦๆหูࠣ๏อๆสࠢหี๋อๅอࠢ฼้ฬีࠧლ"))
			else: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = P2Fgh6TCOWoaHjkqBcQnvRNXe
			if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
				utj0e6NiX92WDJcvaybfpEqk = w2qb6lf5EM
				if BB7oCRfQNSYj5qDhTUevV: CUYvKkg403sS1yxGoTbWDhJAXN.execute(E6xdOMpqISHZCn(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩმ")+Ud0YQK1PNSfw8FV6voB3xpyeT+yylSaxCLfkte(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫნ")+R7xafKV3ekjDc+Olh7n0zfV4(u"ࠬࠨࠩࠡ࠽ࠪო"))
				else: CUYvKkg403sS1yxGoTbWDhJAXN.execute(Olh7n0zfV4(u"࠭ࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࠬპ")+Ud0YQK1PNSfw8FV6voB3xpyeT+rC5tnFDlQcRGA2(u"ࠧࠡࠪࡤࡨࡩࡵ࡮ࡊࡆ࠯ࡹࡵࡪࡡࡵࡧࡕࡹࡱ࡫ࠩࠡࡘࡄࡐ࡚ࡋࡓࠡࠪࠥࠫჟ")+R7xafKV3ekjDc+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࠤ࠯࠵࠮ࠦ࠻ࠨრ"))
	except: succeeded = VJZIMkUN5siqB21Pf
	GG0sJNhYLx6dPrSkFeobaCAuH2f.commit()
	GG0sJNhYLx6dPrSkFeobaCAuH2f.close()
	if utj0e6NiX92WDJcvaybfpEqk:
		L8Wkv5KCSoq.sleep(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠳ᆂ"))
		pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭ს"))
		L8Wkv5KCSoq.sleep(pz4WBwfyDdgk0m2aRr7SMv(u"࠴ᆃ"))
		if showDialogs:
			if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cjVhOCwybeRo7UWg92(u"๊ࠪัำสࠡ฻่่๏ฯࠠฦื็หาࠦสฮัํฯࠥอไฦุสๅฮࠦ࡜࡯࡞ࡱࠫტ")+R7xafKV3ekjDc)
			else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"ࠫๆฺไหࠢ฼้้๐ษࠡวุ่ฬำࠠหฯา๎ะࠦวๅวูหๆฯࠠ࡝ࡰ࡟ࡲࠬუ")+R7xafKV3ekjDc)
	return utj0e6NiX92WDJcvaybfpEqk
def jjTNmoGUqkaS36hcsDbgWHwyZQM4Jn(SFKVM29ObyREINTkpeYnl,showDialogs,iKO5fHpgV3utwY0yNmvc,U6z13M7sDFNbjLtyQ9):
	a50MeDjfCnLNzihu = fxpB0b5NLy6EdFzR3HGPTA(SFKVM29ObyREINTkpeYnl)
	YEpWZql3jXv = VJZIMkUN5siqB21Pf
	for R7xafKV3ekjDc in SFKVM29ObyREINTkpeYnl:
		succeeded,XF9stGBpWZLMRQVP,VQ5UjWuFyntkMKDJO0xL9cSHI1bs87 = HqoSQi1g7zRhuNWswcB(R7xafKV3ekjDc,showDialogs,iKO5fHpgV3utwY0yNmvc,a50MeDjfCnLNzihu)
		utj0e6NiX92WDJcvaybfpEqk = loBHfukKV4AGCtbFIvc7Y0eiLNJ(R7xafKV3ekjDc,showDialogs,U6z13M7sDFNbjLtyQ9)
		if utj0e6NiX92WDJcvaybfpEqk: YEpWZql3jXv = w2qb6lf5EM
	if YEpWZql3jXv:
		L8Wkv5KCSoq.sleep(pz4WBwfyDdgk0m2aRr7SMv(u"࠵ᆄ"))
		pKVikfGen4wMt80UTscxWjAoCZ5S.executebuiltin(XB4CjMkPFzhAHiI3q(u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩფ"))
		L8Wkv5KCSoq.sleep(cbmeD4WNZfAowxT2JdUMtV(u"࠶ᆅ"))
	if showDialogs:
		if len(SFKVM29ObyREINTkpeYnl)>yylSaxCLfkte(u"࠷ᆆ"): PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,yylSaxCLfkte(u"࠭สๆࠢห๊ัออࠡใะูࠥาๅ๋฻ࠣห้หึศใสฮࠬქ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"ࠧห็ࠣฬ๋าวฮࠢไัฺࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫღ")+SFKVM29ObyREINTkpeYnl[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠰ᆇ")])
	return
def DkcrxeMRug629ZVS7FUdNlQ(showDialogs):
	lhczgVuQRmebq47C = [I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ყ"),s97s2k0LJgl(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧࠫშ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧჩ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡾࡺ࠭ࡥ࡮ࡳࠫც")]
	twRPF1pJ945LBE2aImhvSqj6li = [KA26GucUHOwXL(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪ࠮ࡰࡶ࡫ࡩࡷࡹࠧძ"),VVvcQpCU3OM09n(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡩ࡬ࡸࡪ࡫ࠧწ"),cjVhOCwybeRo7UWg92(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪჭ"),VVvcQpCU3OM09n(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱࡫࡮ࡺࡨࡶࡤࠪხ"),otNfFapeEnO(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡦࡣࠪჯ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳ࡩ࡯ࡥࡧࡥࡩࡷ࡭ࠧჰ")]
	for R7xafKV3ekjDc in twRPF1pJ945LBE2aImhvSqj6li: vtDL4ASElbKdms1GJTNhn5(R7xafKV3ekjDc)
	jjTNmoGUqkaS36hcsDbgWHwyZQM4Jn(lhczgVuQRmebq47C,showDialogs,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	return
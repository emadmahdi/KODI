# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'DAILYMOTION'
kL0nT7NpZdKVD3jM2OHB = '_DLM_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
hRigZpdbjIYsDGr2 = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][1]
def hH3sRBSFAr(mode,url,text,type,GOF25jkXb1DnaB4vhL9):
	if	 mode==400: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==401: SD0TxMRXiep4cjPBsnzI = UISBH89nCpG6xTyj0(url,text)
	elif mode==402: SD0TxMRXiep4cjPBsnzI = Z2ZeGaUFbr7kKLzh0dlW(url,text)
	elif mode==403: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url,text)
	elif mode==404: SD0TxMRXiep4cjPBsnzI = MkqpNc2j86043AgmVQaSlrtxGOehy(text,GOF25jkXb1DnaB4vhL9)
	elif mode==405: SD0TxMRXiep4cjPBsnzI = jqFUeTp5SYno(text,GOF25jkXb1DnaB4vhL9)
	elif mode==406: SD0TxMRXiep4cjPBsnzI = oO6terwBCNqyiSTs3vU(text,GOF25jkXb1DnaB4vhL9)
	elif mode==407: SD0TxMRXiep4cjPBsnzI = wJvEhjCxQsVaD5PIN47(url,GOF25jkXb1DnaB4vhL9)
	elif mode==408: SD0TxMRXiep4cjPBsnzI = m8N9XTwDIlpA(url,GOF25jkXb1DnaB4vhL9)
	elif mode==409: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text,GOF25jkXb1DnaB4vhL9)
	elif mode==411: SD0TxMRXiep4cjPBsnzI = ffiLnpoqKjFCg(url,text)
	elif mode==414: SD0TxMRXiep4cjPBsnzI = qyBGnIVEhTg(text)
	elif mode==415: SD0TxMRXiep4cjPBsnzI = qLEleYaCnd(text,GOF25jkXb1DnaB4vhL9)
	elif mode==416: SD0TxMRXiep4cjPBsnzI = C6iqBGbs9K(text,GOF25jkXb1DnaB4vhL9)
	elif mode==417: SD0TxMRXiep4cjPBsnzI = uGJICrDjalMLZ0g(url,GOF25jkXb1DnaB4vhL9)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الرئيسية',CJlTSEpZsWb0QHg5w,414)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن فيديوهات',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'videos?sortBy=','_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن آخر الفيديوهات',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن الفيديوهات الأكثر مشاهدة',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن قوائم التشغيل',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'playlists','_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن مستخدم',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'channels','_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن بث حي',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'lives','_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن هاشتاك',CJlTSEpZsWb0QHg5w,409,CJlTSEpZsWb0QHg5w,'hashtags','_REMEMBERRESULTS_')
	return
def Z2ZeGaUFbr7kKLzh0dlW(url,xBhJODHjcnN):
	if '/dm_' in url:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,False,CJlTSEpZsWb0QHg5w,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = bqIufCQz2OWExjilm.headers
		if 'Location' in list(headers.keys()): url = V4kF6EQiwo+headers['Location']
	xBhJODHjcnN = Dj62UpP5MrbTkJqhRa+xBhJODHjcnN+oOQaRxBXyJ5jVnZ
	xBhJODHjcnN = V3KolYsADJU07t5FhPEanb61Z2(xBhJODHjcnN)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: بث حي',url,411,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'channel_lives_now')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: آخر الفيديوهات',url+'/videos',408)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: المميزة',url,411,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'channel_featured_videos')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: قوائم التشغيل',url+'/playlists',407)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: قنوات ذات صلة',url,411,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'channel_related_channel')
	return
def V3KolYsADJU07t5FhPEanb61Z2(title):
	title = title.rstrip('\\').strip(YvOQBzaTAscXR9ql).replace('\\\\','\\')
	title = pd0Na8D5WZfHYkysVS(title)
	return title
def rHwfOZb3oSgJKi(url,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF):
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX([url],T1QDsJlUtCGhn,'video',url)
	return
def MkqpNc2j86043AgmVQaSlrtxGOehy(search,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = CJlTSEpZsWb0QHg5w
	search = search.split('/videos')[0]
	RjVAI6uzxFofm7qv = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysearchwords',search)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	if sort==CJlTSEpZsWb0QHg5w: RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysortmethod',CJlTSEpZsWb0QHg5w)
	else: RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = V4kF6EQiwo+'/search/'+search+'/videos'
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv,search)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"videos"(.*?)"VideoConnection"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"node":.*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,title,Ra8hzcn1vfXmW,xBhJODHjcnN,XtbZnKed5mT2IYPy4MqvuOGURNwSc,hzGKUP1XjAoeT79MJcDF in items:
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+id
			title = V3KolYsADJU07t5FhPEanb61Z2(title)
			BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = Ra8hzcn1vfXmW+'::'+xBhJODHjcnN
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
		if '"hasNextPage":true' in bGIVq1CQTjmosZg:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,404,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,search)
	return
def jqFUeTp5SYno(search,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	RjVAI6uzxFofm7qv = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysearchwords',search)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	url = V4kF6EQiwo+'/search/'+search+'/playlists'
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv,search)
	items = Zy2l0g8QU5vqefaTrsw.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",.*?"total":(.*?),"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for id,name,e1LJSZy0IuTk5RoDnPK8tF9OfmlB,Ra8hzcn1vfXmW,xBhJODHjcnN,hzGKUP1XjAoeT79MJcDF,count in items:
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = V3KolYsADJU07t5FhPEanb61Z2(title)
		BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = Ra8hzcn1vfXmW+'::'+xBhJODHjcnN
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,401,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
	if '"hasNextPage":true' in bGIVq1CQTjmosZg:
		GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,405,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,search)
	return
def oO6terwBCNqyiSTs3vU(search,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	RjVAI6uzxFofm7qv = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysearchwords',search)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	url = V4kF6EQiwo+'/search/'+search+'/channels'
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv,search)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"channels"(.*?)"ChannelConnection"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"node".*?"name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbnailx240":"(.*?)",',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,name,hzGKUP1XjAoeT79MJcDF in items:
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+id
			title = 'USER:  '+name
			title = V3KolYsADJU07t5FhPEanb61Z2(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,402,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,name)
		if '"hasNextPage":true' in bGIVq1CQTjmosZg:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,406,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,search)
	return
def qyBGnIVEhTg(XOcDLTaFi5ns61k):
	RjVAI6uzxFofm7qv = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	lQNfmFHtUpCsDTv6RuLxcBaihKgV = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	if lQNfmFHtUpCsDTv6RuLxcBaihKgV:
		GFYUeboK8kzCEv7jIhJD = oE7iT3HI5VDdmY4kPOjr('dict',lQNfmFHtUpCsDTv6RuLxcBaihKgV)
		s7QxKilFEpz = GFYUeboK8kzCEv7jIhJD['data']['home']['neon']['sections']['edges']
		if not XOcDLTaFi5ns61k:
			JD0F1ilxOargGy4 = []
			for RKjnNTIv5AtCgdW in s7QxKilFEpz:
				IGyeJrS3KWXzYhQTUkowj = RKjnNTIv5AtCgdW['node']['title']
				if IGyeJrS3KWXzYhQTUkowj not in JD0F1ilxOargGy4: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+IGyeJrS3KWXzYhQTUkowj,CJlTSEpZsWb0QHg5w,414,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,IGyeJrS3KWXzYhQTUkowj)
				JD0F1ilxOargGy4.append(IGyeJrS3KWXzYhQTUkowj)
		else:
			for RKjnNTIv5AtCgdW in s7QxKilFEpz:
				IGyeJrS3KWXzYhQTUkowj = RKjnNTIv5AtCgdW['node']['title']
				if IGyeJrS3KWXzYhQTUkowj==XOcDLTaFi5ns61k:
					CYgcAi4RuQhtd0 = RKjnNTIv5AtCgdW['node']['components']['edges']
					for tEo173JDLBVAOhTUeNKr2nQbFxPd8Y in CYgcAi4RuQhtd0:
						XtbZnKed5mT2IYPy4MqvuOGURNwSc = str(tEo173JDLBVAOhTUeNKr2nQbFxPd8Y['node']['duration'])
						title = pd0Na8D5WZfHYkysVS(tEo173JDLBVAOhTUeNKr2nQbFxPd8Y['node']['title'])
						title = title.replace('\/','/')
						bfsyGWSTE5wD37lo9KzQtn04F2d = tEo173JDLBVAOhTUeNKr2nQbFxPd8Y['node']['xid']
						hzGKUP1XjAoeT79MJcDF = tEo173JDLBVAOhTUeNKr2nQbFxPd8Y['node']['thumbnailx480']
						hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
						ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+bfsyGWSTE5wD37lo9KzQtn04F2d
						khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	return
def qLEleYaCnd(search,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	RjVAI6uzxFofm7qv = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysearchwords',search)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	url = V4kF6EQiwo+'/search/'+search+'/lives'
	lQNfmFHtUpCsDTv6RuLxcBaihKgV = VSpfU3X6YBj(RjVAI6uzxFofm7qv,search)
	if lQNfmFHtUpCsDTv6RuLxcBaihKgV:
		GFYUeboK8kzCEv7jIhJD = oE7iT3HI5VDdmY4kPOjr('dict',lQNfmFHtUpCsDTv6RuLxcBaihKgV)
		try: s7QxKilFEpz = GFYUeboK8kzCEv7jIhJD['data']['search']['lives']['edges']
		except: s7QxKilFEpz = []
		for RKjnNTIv5AtCgdW in s7QxKilFEpz:
			name = RKjnNTIv5AtCgdW['node']['title']
			name = pd0Na8D5WZfHYkysVS(name)
			bfsyGWSTE5wD37lo9KzQtn04F2d = RKjnNTIv5AtCgdW['node']['xid']
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+bfsyGWSTE5wD37lo9KzQtn04F2d
			khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+'LIVE: '+name,ZgsbN5iSL48t2IhVFnmy,403)
		if '"hasNextPage":true' in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,415,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,search)
	return
def nUBRohrLCwDjAQEP4GFeTqcx(search,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	RjVAI6uzxFofm7qv = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysearchwords',search)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	url = V4kF6EQiwo+'/search/'+search+'/topics'
	lQNfmFHtUpCsDTv6RuLxcBaihKgV = VSpfU3X6YBj(RjVAI6uzxFofm7qv,search)
	if lQNfmFHtUpCsDTv6RuLxcBaihKgV:
		GFYUeboK8kzCEv7jIhJD = oE7iT3HI5VDdmY4kPOjr('dict',lQNfmFHtUpCsDTv6RuLxcBaihKgV)
		try: s7QxKilFEpz = GFYUeboK8kzCEv7jIhJD['data']['search']['topics']['edges']
		except: s7QxKilFEpz = []
		for RKjnNTIv5AtCgdW in s7QxKilFEpz:
			name = RKjnNTIv5AtCgdW['node']['name']
			bfsyGWSTE5wD37lo9KzQtn04F2d = RKjnNTIv5AtCgdW['node']['xid']
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/topic/'+bfsyGWSTE5wD37lo9KzQtn04F2d
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'TOPIC: '+name,ZgsbN5iSL48t2IhVFnmy,413)
		if '"hasNextPage":true' in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,412,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,search)
	return
def SCLAleUIT9h1EsfaFDJwgn0Kkd(url,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	bfsyGWSTE5wD37lo9KzQtn04F2d = url.split('/')[-1]
	RjVAI6uzxFofm7qv = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mytopicid',bfsyGWSTE5wD37lo9KzQtn04F2d)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	lQNfmFHtUpCsDTv6RuLxcBaihKgV = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	if lQNfmFHtUpCsDTv6RuLxcBaihKgV:
		GFYUeboK8kzCEv7jIhJD = oE7iT3HI5VDdmY4kPOjr('dict',lQNfmFHtUpCsDTv6RuLxcBaihKgV)
		s7QxKilFEpz = GFYUeboK8kzCEv7jIhJD['data']['topic']['videos']['edges']
		for RKjnNTIv5AtCgdW in s7QxKilFEpz:
			XtbZnKed5mT2IYPy4MqvuOGURNwSc = str(RKjnNTIv5AtCgdW['node']['duration'])
			title = pd0Na8D5WZfHYkysVS(RKjnNTIv5AtCgdW['node']['title'])
			title = title.replace('\/','/')
			bfsyGWSTE5wD37lo9KzQtn04F2d = RKjnNTIv5AtCgdW['node']['xid']
			hzGKUP1XjAoeT79MJcDF = RKjnNTIv5AtCgdW['node']['thumbnailx480']
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+bfsyGWSTE5wD37lo9KzQtn04F2d
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
		if '"hasNextPage":true' in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,413,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9)
	return
def UISBH89nCpG6xTyj0(url,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF):
	id = url.split('/')[-1]
	Ra8hzcn1vfXmW,xBhJODHjcnN = BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF.split('::',1)
	ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+Ra8hzcn1vfXmW
	xBhJODHjcnN = V3KolYsADJU07t5FhPEanb61Z2(xBhJODHjcnN)
	title = Dj62UpP5MrbTkJqhRa+'OWNER:  '+xBhJODHjcnN+oOQaRxBXyJ5jVnZ
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,402,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBhJODHjcnN)
	RjVAI6uzxFofm7qv = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('myplaylistid',id)
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"collection_videos"(.*?)"SectionEdge"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?thumbnailx240":"(.*?)",.*?"xid":"(.*?)",.*?"displayName":"(.*?)",',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,title,XtbZnKed5mT2IYPy4MqvuOGURNwSc,hzGKUP1XjAoeT79MJcDF,Ra8hzcn1vfXmW,xBhJODHjcnN in items:
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+id
			title = V3KolYsADJU07t5FhPEanb61Z2(title)
			BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = Ra8hzcn1vfXmW+'::'+xBhJODHjcnN
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
	return
def m8N9XTwDIlpA(url,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	DrKqvRJgASd4kzVZWucE = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	RjVAI6uzxFofm7qv = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mychannelid',DrKqvRJgASd4kzVZWucE)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysortmethod',sort)
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"node".*?"xid":"(.*?)",.*?"title":"(.*?)",.*?"duration":(.*?),".*?name":"(.*?)",.*?"displayName":"(.*?)",.*?"thumbURLx240":"(.*?)",',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,title,XtbZnKed5mT2IYPy4MqvuOGURNwSc,Ra8hzcn1vfXmW,xBhJODHjcnN,hzGKUP1XjAoeT79MJcDF in items:
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+id
			title = V3KolYsADJU07t5FhPEanb61Z2(title)
			BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = Ra8hzcn1vfXmW+'::'+xBhJODHjcnN
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
		if '"hasNextPage":true' in bGIVq1CQTjmosZg:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,408,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9)
	return
def wJvEhjCxQsVaD5PIN47(url,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	DrKqvRJgASd4kzVZWucE = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	RjVAI6uzxFofm7qv = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mychannelid',DrKqvRJgASd4kzVZWucE)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysortmethod',sort)
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"node".*?"xid":"(.*?)",.*?"name":"(.*?)",.*?"thumbURLx240":"(.*?)",.*?"total":(.*?),".*?xid":"(.*?)",.*?"name":"(.*?)",.*?"displayName":"(.*?)",',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,name,hzGKUP1XjAoeT79MJcDF,count,e1LJSZy0IuTk5RoDnPK8tF9OfmlB,Ra8hzcn1vfXmW,xBhJODHjcnN in items:
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = V3KolYsADJU07t5FhPEanb61Z2(title)
			BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = Ra8hzcn1vfXmW+'::'+xBhJODHjcnN
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,401,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
		if '"hasNextPage":true' in bGIVq1CQTjmosZg:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,407,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9)
	return
def ffiLnpoqKjFCg(url,tupNLK1evj76GiAVZPXQkoHSWqm):
	DrKqvRJgASd4kzVZWucE = url.split('/')[3]
	RjVAI6uzxFofm7qv = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mychannelid',DrKqvRJgASd4kzVZWucE)
	bGIVq1CQTjmosZg = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	DydoMOETet2jGf8vXlmasRC7xA = KSHcVmz2W84iQvbRDBhGldpCL.loads(bGIVq1CQTjmosZg)
	try: items = DydoMOETet2jGf8vXlmasRC7xA['data']['channel'][tupNLK1evj76GiAVZPXQkoHSWqm]['edges']
	except: items = []
	if not items: khqge7BVD9jPFy1S8T5Gn4QAlH('link',kL0nT7NpZdKVD3jM2OHB+'لا توجد نتائج',CJlTSEpZsWb0QHg5w,9999)
	else:
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			hzpx9mZqroQCP6v8GaHjk2 = jglfWFcvo1mAdH9yeROS7XKNxu['node']
			bfsyGWSTE5wD37lo9KzQtn04F2d = hzpx9mZqroQCP6v8GaHjk2['xid']
			keys = list(hzpx9mZqroQCP6v8GaHjk2.keys())
			vUfi0yEYDgHGKez4tax1 = hzpx9mZqroQCP6v8GaHjk2['__typename'].lower()
			if vUfi0yEYDgHGKez4tax1=='channel':
				name = hzpx9mZqroQCP6v8GaHjk2['name']
				y2GF5IwV3JS0 = hzpx9mZqroQCP6v8GaHjk2['displayName']
				title = 'USER:  '+y2GF5IwV3JS0
				hzGKUP1XjAoeT79MJcDF = hzpx9mZqroQCP6v8GaHjk2['coverURLx375']
			else:
				name = hzpx9mZqroQCP6v8GaHjk2['channel']['name']
				y2GF5IwV3JS0 = hzpx9mZqroQCP6v8GaHjk2['channel']['displayName']
				title = hzpx9mZqroQCP6v8GaHjk2['title']
				hzGKUP1XjAoeT79MJcDF = hzpx9mZqroQCP6v8GaHjk2['thumbnailx360']
				if vUfi0yEYDgHGKez4tax1=='live': title = 'LIVE:  '+title
			title = V3KolYsADJU07t5FhPEanb61Z2(title)
			BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = name+'::'+y2GF5IwV3JS0
			if BB7oCRfQNSYj5qDhTUevV:
				title = title.encode(Im5KSGZYBpRvdMVsbuXg)
				BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF = BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF.encode(Im5KSGZYBpRvdMVsbuXg)
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			if vUfi0yEYDgHGKez4tax1=='channel':
				ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+bfsyGWSTE5wD37lo9KzQtn04F2d
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,402,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
			else:
				if vUfi0yEYDgHGKez4tax1=='video': XtbZnKed5mT2IYPy4MqvuOGURNwSc = str(hzpx9mZqroQCP6v8GaHjk2['duration'])
				else: XtbZnKed5mT2IYPy4MqvuOGURNwSc = CJlTSEpZsWb0QHg5w
				ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+bfsyGWSTE5wD37lo9KzQtn04F2d
				khqge7BVD9jPFy1S8T5Gn4QAlH(vUfi0yEYDgHGKez4tax1,kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc,BXbhemSZ76UMyHcPQE4C5g1Rk9OwYF)
	return
def C6iqBGbs9K(search,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	RjVAI6uzxFofm7qv = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mysearchwords',search)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagelimit','40')
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	url = V4kF6EQiwo+'/search/'+search+'/hashtags'
	lQNfmFHtUpCsDTv6RuLxcBaihKgV = VSpfU3X6YBj(RjVAI6uzxFofm7qv,search)
	if lQNfmFHtUpCsDTv6RuLxcBaihKgV:
		GFYUeboK8kzCEv7jIhJD = oE7iT3HI5VDdmY4kPOjr('dict',lQNfmFHtUpCsDTv6RuLxcBaihKgV)
		try: s7QxKilFEpz = GFYUeboK8kzCEv7jIhJD['data']['search']['hashtags']['edges']
		except: s7QxKilFEpz = []
		for RKjnNTIv5AtCgdW in s7QxKilFEpz:
			name = RKjnNTIv5AtCgdW['node']['name']
			name = pd0Na8D5WZfHYkysVS(name)
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/hashtag/'+name[1:]
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'HSHTG: '+name,ZgsbN5iSL48t2IhVFnmy,417)
		if '"hasNextPage":true' in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,416,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9,search)
	return
def uGJICrDjalMLZ0g(url,GOF25jkXb1DnaB4vhL9=CJlTSEpZsWb0QHg5w):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	name = url.split('/')[-1]
	RjVAI6uzxFofm7qv = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('myhashtagname',name)
	RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.replace('mypagenumber',GOF25jkXb1DnaB4vhL9)
	lQNfmFHtUpCsDTv6RuLxcBaihKgV = VSpfU3X6YBj(RjVAI6uzxFofm7qv)
	if lQNfmFHtUpCsDTv6RuLxcBaihKgV:
		GFYUeboK8kzCEv7jIhJD = oE7iT3HI5VDdmY4kPOjr('dict',lQNfmFHtUpCsDTv6RuLxcBaihKgV)
		s7QxKilFEpz = GFYUeboK8kzCEv7jIhJD['data']['contentFeed']['edges']
		for RKjnNTIv5AtCgdW in s7QxKilFEpz:
			XtbZnKed5mT2IYPy4MqvuOGURNwSc = str(RKjnNTIv5AtCgdW['node']['post']['duration'])
			title = pd0Na8D5WZfHYkysVS(RKjnNTIv5AtCgdW['node']['post']['title'])
			title = title.replace('\/','/')
			bfsyGWSTE5wD37lo9KzQtn04F2d = RKjnNTIv5AtCgdW['node']['post']['xid']
			hzGKUP1XjAoeT79MJcDF = RKjnNTIv5AtCgdW['node']['post']['thumbnailx480']
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/video/'+bfsyGWSTE5wD37lo9KzQtn04F2d
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,403,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
		if '"hasNextPage":true' in lQNfmFHtUpCsDTv6RuLxcBaihKgV:
			GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)+1)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+GOF25jkXb1DnaB4vhL9,url,416,CJlTSEpZsWb0QHg5w,GOF25jkXb1DnaB4vhL9)
	return
def VSpfU3X6YBj(RjVAI6uzxFofm7qv,search=CJlTSEpZsWb0QHg5w):
	if A7Z6OVh20eCEUx: RjVAI6uzxFofm7qv = RjVAI6uzxFofm7qv.encode(Im5KSGZYBpRvdMVsbuXg)
	zEcJR3pH7i1WkZVT5e9 = fDo5UnjAkYuMiZtWL()
	headers = {"Authorization":zEcJR3pH7i1WkZVT5e9,"Origin":V4kF6EQiwo,'Content-Type':'text/plain; charset=utf-8'}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',hRigZpdbjIYsDGr2,RjVAI6uzxFofm7qv,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'DAILYMOTION-GET_PAGEDATA-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	return bGIVq1CQTjmosZg
def fDo5UnjAkYuMiZtWL():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'DAILYMOTION-GET_AUTHINTICATION-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	WMhQcOTp6BoKzbLDtF = Zy2l0g8QU5vqefaTrsw.findall('var r="(.*?)",o="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	IIvnpKBWabrAe6SO1qJUMylzuNw,HBgVjUXGay = WMhQcOTp6BoKzbLDtF[-1]
	RysE3kZWYSCA7hTLPp65H = 'https://graphql.api.dailymotion.com/oauth/token'
	V6fvq0glnJ9QLWyxSYid8urX4PBa2 = 'client_credentials'
	data = {'client_id':IIvnpKBWabrAe6SO1qJUMylzuNw,'client_secret':HBgVjUXGay,'grant_type':V6fvq0glnJ9QLWyxSYid8urX4PBa2}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',RysE3kZWYSCA7hTLPp65H,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	WMhQcOTp6BoKzbLDtF = Zy2l0g8QU5vqefaTrsw.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	yqNVtuiWwKra4,Jiyr78a12tHY0WxoUcz5 = WMhQcOTp6BoKzbLDtF[0]
	zEcJR3pH7i1WkZVT5e9 = Jiyr78a12tHY0WxoUcz5+" "+yqNVtuiWwKra4
	return zEcJR3pH7i1WkZVT5e9
def HYGiJ9pfmMTnIb4L7tX(search,UDkNdJxF4il0QoeG89sBR=CJlTSEpZsWb0QHg5w):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not UDkNdJxF4il0QoeG89sBR and showDialogs:
		DGI6U9Jucg74S = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		CrqTamtPFuU = T4TK17YsEfZJ('موقع ديلي موشن - اختر البحث',DGI6U9Jucg74S)
		if CrqTamtPFuU==-1: return
		elif CrqTamtPFuU==0: UDkNdJxF4il0QoeG89sBR = 'videos?sortBy='
		elif CrqTamtPFuU==1: UDkNdJxF4il0QoeG89sBR = 'videos?sortBy=RECENT'
		elif CrqTamtPFuU==2: UDkNdJxF4il0QoeG89sBR = 'videos?sortBy=VIEW_COUNT'
		elif CrqTamtPFuU==3: UDkNdJxF4il0QoeG89sBR = 'playlists'
		elif CrqTamtPFuU==4: UDkNdJxF4il0QoeG89sBR = 'channels'
		elif CrqTamtPFuU==5: UDkNdJxF4il0QoeG89sBR = 'lives'
		elif CrqTamtPFuU==6: UDkNdJxF4il0QoeG89sBR = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in EcrV3IasOo4Hq: UDkNdJxF4il0QoeG89sBR = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in EcrV3IasOo4Hq: UDkNdJxF4il0QoeG89sBR = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in EcrV3IasOo4Hq: UDkNdJxF4il0QoeG89sBR = 'channels'
	elif '_DAILYMOTION-LIVES_' in EcrV3IasOo4Hq: UDkNdJxF4il0QoeG89sBR = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in EcrV3IasOo4Hq: UDkNdJxF4il0QoeG89sBR = 'hashtags'
	elif not UDkNdJxF4il0QoeG89sBR: UDkNdJxF4il0QoeG89sBR = 'videos?sortBy='
	if not search:
		search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not search: return
	if 'videos' in UDkNdJxF4il0QoeG89sBR: MkqpNc2j86043AgmVQaSlrtxGOehy(search+'/'+UDkNdJxF4il0QoeG89sBR)
	elif 'playlists' in UDkNdJxF4il0QoeG89sBR: jqFUeTp5SYno(search)
	elif 'channels' in UDkNdJxF4il0QoeG89sBR: oO6terwBCNqyiSTs3vU(search)
	elif 'lives' in UDkNdJxF4il0QoeG89sBR: qLEleYaCnd(search)
	elif 'hashtags' in UDkNdJxF4il0QoeG89sBR: C6iqBGbs9K(search)
	return
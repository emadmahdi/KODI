# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
Hk0y5BFPUwlGDoiA7pu8 = 'FAVORITES'
def E2yVTSwA9QzkxUNsHKPBb81G(BEUVvSQtRimC,g8gECpUVG3oD4f7Qc):
	if   BEUVvSQtRimC==270: qTXQ0E8GoMkdI1 = kXTvVPcz07xwBfhnptsW1qaOC(g8gECpUVG3oD4f7Qc)
	else: qTXQ0E8GoMkdI1 = False
	return qTXQ0E8GoMkdI1
def szprIF8Zyl30nRVMfEbJqiATQao1G(AC0yWDME4VSh8rkFXwpGeol6st,g8gECpUVG3oD4f7Qc,YiWEmJ75QupjIT4twBAaqbZkvcO):
	if not AC0yWDME4VSh8rkFXwpGeol6st: return
	if   YiWEmJ75QupjIT4twBAaqbZkvcO=='UP1'	: hc21l9VI6xGQqtJZdPANBubUEW8pe(g8gECpUVG3oD4f7Qc,True,P2Fgh6TCOWoaHjkqBcQnvRNXe)
	elif YiWEmJ75QupjIT4twBAaqbZkvcO=='DOWN1'	: hc21l9VI6xGQqtJZdPANBubUEW8pe(g8gECpUVG3oD4f7Qc,False,P2Fgh6TCOWoaHjkqBcQnvRNXe)
	elif YiWEmJ75QupjIT4twBAaqbZkvcO=='UP4'	: hc21l9VI6xGQqtJZdPANBubUEW8pe(g8gECpUVG3oD4f7Qc,True,P3cpaLN2sH)
	elif YiWEmJ75QupjIT4twBAaqbZkvcO=='DOWN4'	: hc21l9VI6xGQqtJZdPANBubUEW8pe(g8gECpUVG3oD4f7Qc,False,P3cpaLN2sH)
	elif YiWEmJ75QupjIT4twBAaqbZkvcO=='ADD1'	: hhIgGZB5ibk6OQuK2P(g8gECpUVG3oD4f7Qc)
	elif YiWEmJ75QupjIT4twBAaqbZkvcO=='REMOVE1': DNmgsvU9AWuiq1QR(g8gECpUVG3oD4f7Qc)
	elif YiWEmJ75QupjIT4twBAaqbZkvcO=='DELETELIST': AUChHZvMjwBcpRdI437GbYo(g8gECpUVG3oD4f7Qc)
	return
def kXTvVPcz07xwBfhnptsW1qaOC(g8gECpUVG3oD4f7Qc):
	DBxaf0tiT3Oz9w2bm = C2Ula90Z1dj3NhDMKR7YH8()
	if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()):
		try:
			llBzgQYMT3ak1toDRVerxJ6qjC = DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]
			if ZVNvqy4iF1a9X and g8gECpUVG3oD4f7Qc in ['5','11','12','13']:
				for nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO in llBzgQYMT3ak1toDRVerxJ6qjC:
					if nnAfhejEKz2luw4UdLVW9OkgMcXIGZ=='video':
						khqge7BVD9jPFy1S8T5Gn4QAlH('video',Dj62UpP5MrbTkJqhRa+'تشغيل من الأعلى إلى الأسفل'+oOQaRxBXyJ5jVnZ,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st)
						khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
						break
			for nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO in llBzgQYMT3ak1toDRVerxJ6qjC:
				khqge7BVD9jPFy1S8T5Gn4QAlH(nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO)
		except:
			DBxaf0tiT3Oz9w2bm = nfpZxRXATHiEOK465l9SvrsbmQ(wiEebAT9Qs7dCztufUZNORv3)
			llBzgQYMT3ak1toDRVerxJ6qjC = DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]
			for nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO in llBzgQYMT3ak1toDRVerxJ6qjC:
				khqge7BVD9jPFy1S8T5Gn4QAlH(nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO)
	return
def hhIgGZB5ibk6OQuK2P(g8gECpUVG3oD4f7Qc):
	nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
	if g8gECpUVG3oD4f7Qc in ['5','11','12','13'] and nnAfhejEKz2luw4UdLVW9OkgMcXIGZ!='video':
		PIUzVg8uwmHlMKO5Lk6oxAZ('','',TAExSfcoNi4eORZ8HPB,'هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	izPAxfYFVy1m = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO
	DBxaf0tiT3Oz9w2bm = C2Ula90Z1dj3NhDMKR7YH8()
	uqg5WY7XViQbxD4MRyoAwUhZ2 = {}
	for fLH1AwiF9mjhK in list(DBxaf0tiT3Oz9w2bm.keys()):
		if fLH1AwiF9mjhK!=g8gECpUVG3oD4f7Qc: uqg5WY7XViQbxD4MRyoAwUhZ2[fLH1AwiF9mjhK] = DBxaf0tiT3Oz9w2bm[fLH1AwiF9mjhK]
		else:
			if idaKcvOmbRrkW1CtHhZfeAJQV4D and idaKcvOmbRrkW1CtHhZfeAJQV4D!='..':
				F2vS9wITxOAkeo0CPyflU = DBxaf0tiT3Oz9w2bm[fLH1AwiF9mjhK]
				if izPAxfYFVy1m in F2vS9wITxOAkeo0CPyflU:
					e54ehLtvBbZJiYqrw7fTcxQgWuCmI = F2vS9wITxOAkeo0CPyflU.index(izPAxfYFVy1m)
					del F2vS9wITxOAkeo0CPyflU[e54ehLtvBbZJiYqrw7fTcxQgWuCmI]
				HkXKBTe2uSxmw = F2vS9wITxOAkeo0CPyflU+[izPAxfYFVy1m]
				uqg5WY7XViQbxD4MRyoAwUhZ2[fLH1AwiF9mjhK] = HkXKBTe2uSxmw
			else: uqg5WY7XViQbxD4MRyoAwUhZ2[fLH1AwiF9mjhK] = DBxaf0tiT3Oz9w2bm[fLH1AwiF9mjhK]
	if g8gECpUVG3oD4f7Qc not in list(uqg5WY7XViQbxD4MRyoAwUhZ2.keys()): uqg5WY7XViQbxD4MRyoAwUhZ2[g8gECpUVG3oD4f7Qc] = [izPAxfYFVy1m]
	uN9QEvKVblh2YI8 = str(uqg5WY7XViQbxD4MRyoAwUhZ2)
	if A7Z6OVh20eCEUx: uN9QEvKVblh2YI8 = uN9QEvKVblh2YI8.encode(Im5KSGZYBpRvdMVsbuXg)
	open(wiEebAT9Qs7dCztufUZNORv3,'wb').write(uN9QEvKVblh2YI8)
	return
def DNmgsvU9AWuiq1QR(g8gECpUVG3oD4f7Qc):
	nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
	izPAxfYFVy1m = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO
	DBxaf0tiT3Oz9w2bm = C2Ula90Z1dj3NhDMKR7YH8()
	if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()) and izPAxfYFVy1m in DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]:
		DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc].remove(izPAxfYFVy1m)
		if len(DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc])==ZVNvqy4iF1a9X: del DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]
		uN9QEvKVblh2YI8 = str(DBxaf0tiT3Oz9w2bm)
		if A7Z6OVh20eCEUx: uN9QEvKVblh2YI8 = uN9QEvKVblh2YI8.encode(Im5KSGZYBpRvdMVsbuXg)
		open(wiEebAT9Qs7dCztufUZNORv3,'wb').write(uN9QEvKVblh2YI8)
	return
def hc21l9VI6xGQqtJZdPANBubUEW8pe(g8gECpUVG3oD4f7Qc,UUhqJByQiFLnGbC7tfVmDugIA1wjd,xNjWIDLEsfe):
	nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = Ggp2PFN048WD7rRkC6Uqit(zz4EDG1PtiyX3JVUlBeC)
	izPAxfYFVy1m = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO
	DBxaf0tiT3Oz9w2bm = C2Ula90Z1dj3NhDMKR7YH8()
	if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()):
		F2vS9wITxOAkeo0CPyflU = DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]
		if izPAxfYFVy1m not in F2vS9wITxOAkeo0CPyflU: return
		y4yjP6IWcJ9Mo2q0 = len(F2vS9wITxOAkeo0CPyflU)
		for X0Rq3ISdwTJsnWGM7Kmc4 in range(ZVNvqy4iF1a9X,xNjWIDLEsfe):
			zX4Uad0JuxRV8es7kEtb2IM9Bi3N = F2vS9wITxOAkeo0CPyflU.index(izPAxfYFVy1m)
			if UUhqJByQiFLnGbC7tfVmDugIA1wjd: MMlFALtnTZqi9g02dNbvx6XRJwuD = zX4Uad0JuxRV8es7kEtb2IM9Bi3N-P2Fgh6TCOWoaHjkqBcQnvRNXe
			else: MMlFALtnTZqi9g02dNbvx6XRJwuD = zX4Uad0JuxRV8es7kEtb2IM9Bi3N+P2Fgh6TCOWoaHjkqBcQnvRNXe
			if MMlFALtnTZqi9g02dNbvx6XRJwuD>=y4yjP6IWcJ9Mo2q0: MMlFALtnTZqi9g02dNbvx6XRJwuD = MMlFALtnTZqi9g02dNbvx6XRJwuD-y4yjP6IWcJ9Mo2q0
			if MMlFALtnTZqi9g02dNbvx6XRJwuD<ZVNvqy4iF1a9X: MMlFALtnTZqi9g02dNbvx6XRJwuD = MMlFALtnTZqi9g02dNbvx6XRJwuD+y4yjP6IWcJ9Mo2q0
			F2vS9wITxOAkeo0CPyflU.insert(MMlFALtnTZqi9g02dNbvx6XRJwuD, F2vS9wITxOAkeo0CPyflU.pop(zX4Uad0JuxRV8es7kEtb2IM9Bi3N))
		DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc] = F2vS9wITxOAkeo0CPyflU
		uN9QEvKVblh2YI8 = str(DBxaf0tiT3Oz9w2bm)
		if A7Z6OVh20eCEUx: uN9QEvKVblh2YI8 = uN9QEvKVblh2YI8.encode(Im5KSGZYBpRvdMVsbuXg)
		open(wiEebAT9Qs7dCztufUZNORv3,'wb').write(uN9QEvKVblh2YI8)
	return
def Bh6lIS8qU0xsR1wi34vJQzNF7m(g8gECpUVG3oD4f7Qc):
	if g8gECpUVG3oD4f7Qc in ['1','2','3','4']: ltNZM3L02OqVB,IcU23zFgH70r54aNvyAYhKbCLp1De = 'مفضلة',g8gECpUVG3oD4f7Qc
	elif g8gECpUVG3oD4f7Qc in ['5']: ltNZM3L02OqVB,IcU23zFgH70r54aNvyAYhKbCLp1De = 'تشغيل','1'
	elif g8gECpUVG3oD4f7Qc in ['11']: ltNZM3L02OqVB,IcU23zFgH70r54aNvyAYhKbCLp1De = 'تشغيل','2'
	else: ltNZM3L02OqVB,IcU23zFgH70r54aNvyAYhKbCLp1De = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	ce2VTq8Syut = ltNZM3L02OqVB+YvOQBzaTAscXR9ql+IcU23zFgH70r54aNvyAYhKbCLp1De
	return ce2VTq8Syut
def AUChHZvMjwBcpRdI437GbYo(g8gECpUVG3oD4f7Qc):
	ce2VTq8Syut = Bh6lIS8qU0xsR1wi34vJQzNF7m(g8gECpUVG3oD4f7Qc)
	AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هل تريد فعلا مسح جميع محتويات قائمة '+ce2VTq8Syut+' ؟!')
	if AAlgwLdnoxXz6G72yibjeEtu!=1: return
	DBxaf0tiT3Oz9w2bm = C2Ula90Z1dj3NhDMKR7YH8()
	if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()):
		del DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]
		uN9QEvKVblh2YI8 = str(DBxaf0tiT3Oz9w2bm)
		if A7Z6OVh20eCEUx: uN9QEvKVblh2YI8 = uN9QEvKVblh2YI8.encode(Im5KSGZYBpRvdMVsbuXg)
		open(wiEebAT9Qs7dCztufUZNORv3,'wb').write(uN9QEvKVblh2YI8)
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم مسح جميع محتويات قائمة '+ce2VTq8Syut)
	return
def C2Ula90Z1dj3NhDMKR7YH8():
	DBxaf0tiT3Oz9w2bm = {}
	if tiFgl4DMvGEAUfjIYkHbr05.path.exists(wiEebAT9Qs7dCztufUZNORv3):
		aaHBTmFt0uefUD = open(wiEebAT9Qs7dCztufUZNORv3,'rb').read()
		if A7Z6OVh20eCEUx: aaHBTmFt0uefUD = aaHBTmFt0uefUD.decode(Im5KSGZYBpRvdMVsbuXg)
		DBxaf0tiT3Oz9w2bm = oE7iT3HI5VDdmY4kPOjr('dict',aaHBTmFt0uefUD)
	return DBxaf0tiT3Oz9w2bm
def wkEAKGHojXLfWJU3dvy7QCV4T(DBxaf0tiT3Oz9w2bm,izPAxfYFVy1m,JE7rXF8jCRbcBZ2xaYVgQ964pP):
	nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,idaKcvOmbRrkW1CtHhZfeAJQV4D,pkNZlmhUSwtXgriJHjT59MV1QqK,BEUVvSQtRimC,ayeFgd1rBXvlfuKPYEihU82,ZraEU3jpk2ns6q0ztPgvhioAX,FMxeyLvnzabpJhCXgS6T,AC0yWDME4VSh8rkFXwpGeol6st,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO = izPAxfYFVy1m
	if not BEUVvSQtRimC: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,BEUVvSQtRimC = 'folder','260'
	wchp7RQPmv3F94usYSNVJTr,g8gECpUVG3oD4f7Qc = [],CJlTSEpZsWb0QHg5w
	if 'context=' in zz4EDG1PtiyX3JVUlBeC:
		mSgUBlqXThA3vn = Zy2l0g8QU5vqefaTrsw.findall('context=(\d+)',zz4EDG1PtiyX3JVUlBeC,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if mSgUBlqXThA3vn: g8gECpUVG3oD4f7Qc = str(mSgUBlqXThA3vn[ZVNvqy4iF1a9X])
	if BEUVvSQtRimC=='270':
		g8gECpUVG3oD4f7Qc = AC0yWDME4VSh8rkFXwpGeol6st
		if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()):
			ce2VTq8Syut = Bh6lIS8qU0xsR1wi34vJQzNF7m(g8gECpUVG3oD4f7Qc)
			wchp7RQPmv3F94usYSNVJTr.append(('مسح قائمة '+ce2VTq8Syut,'RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_DELETELIST'+')'))
	else:
		if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()):
			count = len(DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc])
			if count>P2Fgh6TCOWoaHjkqBcQnvRNXe: wchp7RQPmv3F94usYSNVJTr.append(('تحريك 1 للأعلى','RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_UP1)'))
			if count>P3cpaLN2sH: wchp7RQPmv3F94usYSNVJTr.append(('تحريك 4 للأعلى','RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_UP4)'))
			if count>P2Fgh6TCOWoaHjkqBcQnvRNXe: wchp7RQPmv3F94usYSNVJTr.append(('تحريك 1 للأسفل','RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_DOWN1)'))
			if count>P3cpaLN2sH: wchp7RQPmv3F94usYSNVJTr.append(('تحريك 4 للأسفل','RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_DOWN4)'))
		for g8gECpUVG3oD4f7Qc in ['1','2','3','4','5','11']:
			ce2VTq8Syut = Bh6lIS8qU0xsR1wi34vJQzNF7m(g8gECpUVG3oD4f7Qc)
			if g8gECpUVG3oD4f7Qc in list(DBxaf0tiT3Oz9w2bm.keys()) and izPAxfYFVy1m in DBxaf0tiT3Oz9w2bm[g8gECpUVG3oD4f7Qc]:
				wchp7RQPmv3F94usYSNVJTr.append(('مسح من '+ce2VTq8Syut,'RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_REMOVE1)'))
			else: wchp7RQPmv3F94usYSNVJTr.append(('إضافة ل'+ce2VTq8Syut,'RunPlugin('+JE7rXF8jCRbcBZ2xaYVgQ964pP+'&context='+g8gECpUVG3oD4f7Qc+'_ADD1)'))
	ScWDuIN96QnEB0qjbseLiAhFx = []
	for U126pl8IKwJ3kigtWP,RVXS4q6wG50tQmiHDfkzWEeL983l in wchp7RQPmv3F94usYSNVJTr:
		U126pl8IKwJ3kigtWP = Ym6q5M4TocDaA013RjFQ+U126pl8IKwJ3kigtWP+oOQaRxBXyJ5jVnZ
		ScWDuIN96QnEB0qjbseLiAhFx.append((U126pl8IKwJ3kigtWP,RVXS4q6wG50tQmiHDfkzWEeL983l,))
	return ScWDuIN96QnEB0qjbseLiAhFx
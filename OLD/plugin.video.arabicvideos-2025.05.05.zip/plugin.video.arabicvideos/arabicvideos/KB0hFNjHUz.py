# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'FARESKO'
kL0nT7NpZdKVD3jM2OHB = '_FSK_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['الرئيسية','يلا شوت']
def hH3sRBSFAr(mode,url,text):
	if   mode==990: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==991: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==992: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==993: SD0TxMRXiep4cjPBsnzI = KrDZxq4duabWHcmkS0LyVRe7zTUXl(url)
	elif mode==999: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FARESKO-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,999,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"primary-links"(.*?)</u',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,991)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"list-categories"(.*?)</u',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy.lstrip('/')
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,991)
	return
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FARESKO-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"home-content"(.*?)"footer"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('"overlay"','"duration"><')
		items = Zy2l0g8QU5vqefaTrsw.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		wDkMP6jlz7XeN5Sp = []
		for hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc,ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(' ')
			title = wAmsc95ya0LHz(title)
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة).\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if 'episodes' not in type and ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0][0]
				title = title.replace('اون لاين',CJlTSEpZsWb0QHg5w)
				if title not in wDkMP6jlz7XeN5Sp:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,993,hzGKUP1XjAoeT79MJcDF)
					wDkMP6jlz7XeN5Sp.append(title)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,992,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('''["']pagination["'](.*?)["']footer["']''',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		type = 'episodes_pages' if 'episodes' in type else 'pages'
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,991,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	else:
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('load-next-button" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة جديدة',ZgsbN5iSL48t2IhVFnmy[0],991,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	return
def KrDZxq4duabWHcmkS0LyVRe7zTUXl(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FARESKO-SERIES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="eplist"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		iypksRX5aYC = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in iypksRX5aYC:
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,992)
	else:
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"category".*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
			nvHUf8mW6E4GSw5VFRXN(ZgsbN5iSL48t2IhVFnmy,'episodes')
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ,DIA54R1lwcTz7OZPjX6a = [],[]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FARESKO-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if 'hash=' in bGIVq1CQTjmosZg:
		kR8G5ojeTnAsU = Zy2l0g8QU5vqefaTrsw.findall('hash=(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		kR8G5ojeTnAsU = list(set(kR8G5ojeTnAsU))
		for HGXYPrKegtmb2zE3aqTxiF in kR8G5ojeTnAsU:
			vLDEePRNhQJmwHGFu3Tkc4 = []
			WyHwgmzU0GnP = HGXYPrKegtmb2zE3aqTxiF.split('__')
			for GePbnu93wr4BKdMqm in WyHwgmzU0GnP:
				try:
					GePbnu93wr4BKdMqm = qqth6cAFkaRowLlUeMng.b64decode(GePbnu93wr4BKdMqm+'=')
					if A7Z6OVh20eCEUx: GePbnu93wr4BKdMqm = GePbnu93wr4BKdMqm.decode(Im5KSGZYBpRvdMVsbuXg)
					vLDEePRNhQJmwHGFu3Tkc4.append(GePbnu93wr4BKdMqm)
				except: pass
			Rp1g7OlotseGnf0NFmKk6rLxd = '>'.join(vLDEePRNhQJmwHGFu3Tkc4)
			Rp1g7OlotseGnf0NFmKk6rLxd = Rp1g7OlotseGnf0NFmKk6rLxd.splitlines()
			for ZgsbN5iSL48t2IhVFnmy in Rp1g7OlotseGnf0NFmKk6rLxd:
				if ' => ' in ZgsbN5iSL48t2IhVFnmy:
					title,ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split(' => ')
					FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch')
	elif 'post_id' in bGIVq1CQTjmosZg:
		e2MSyTKUbONAa14zYLXZPCQv = Zy2l0g8QU5vqefaTrsw.findall("post_id = '(.*?)'",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if e2MSyTKUbONAa14zYLXZPCQv:
			e2MSyTKUbONAa14zYLXZPCQv = e2MSyTKUbONAa14zYLXZPCQv[0]
			headers = {'X-Requested-With':'XMLHttpRequest'}
			A8CdXURF1Tkrp0t6LJ = V4kF6EQiwo+'/wp-admin/admin-ajax.php?action=video_info&post_id='+e2MSyTKUbONAa14zYLXZPCQv
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',A8CdXURF1Tkrp0t6LJ,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FARESKO-PLAY-2nd')
			DNm73EQF1BwZOl2AcT9gb = bqIufCQz2OWExjilm.content
			HHkwWMigXr8QOmtFpvPc10 = Zy2l0g8QU5vqefaTrsw.findall('"name":"(.*?)","src":"(.*?)"',DNm73EQF1BwZOl2AcT9gb,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if not HHkwWMigXr8QOmtFpvPc10:
				HHkwWMigXr8QOmtFpvPc10 = Zy2l0g8QU5vqefaTrsw.findall('"src":"(.*?)"',DNm73EQF1BwZOl2AcT9gb,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if HHkwWMigXr8QOmtFpvPc10:
					h7UTZibdmkM9urW6tY2xDgz3f = ['']*len(HHkwWMigXr8QOmtFpvPc10)
					HHkwWMigXr8QOmtFpvPc10 = list(zip(h7UTZibdmkM9urW6tY2xDgz3f,HHkwWMigXr8QOmtFpvPc10))
			for name,ZgsbN5iSL48t2IhVFnmy in HHkwWMigXr8QOmtFpvPc10:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('\\/','/')
				ZgsbN5iSL48t2IhVFnmy = O4Ak3NXpyUHvE(ZgsbN5iSL48t2IhVFnmy)
				if ZgsbN5iSL48t2IhVFnmy in DIA54R1lwcTz7OZPjX6a: continue
				else: DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__watch')
			otCOTHujWKp7Dn6dvcafPqlx = V4kF6EQiwo+'/wp-admin/admin-ajax.php?action=mwp_generate_video_download_link&post_id='+e2MSyTKUbONAa14zYLXZPCQv+'&video_id=null&video_url=null&video_source=custom'
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',otCOTHujWKp7Dn6dvcafPqlx,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FARESKO-PLAY-3rd')
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
			h5h2zsDYFxieIUpOcf8A1vw = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if h5h2zsDYFxieIUpOcf8A1vw:
				VMvRiS83k19YF4ZIWhwz,DclfbaFSQ3WUsjpGHyEZr = zip(*h5h2zsDYFxieIUpOcf8A1vw)
				h5h2zsDYFxieIUpOcf8A1vw = list(zip(DclfbaFSQ3WUsjpGHyEZr,VMvRiS83k19YF4ZIWhwz))
			for name,ZgsbN5iSL48t2IhVFnmy in h5h2zsDYFxieIUpOcf8A1vw:
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('\\/','/')
				ZgsbN5iSL48t2IhVFnmy = O4Ak3NXpyUHvE(ZgsbN5iSL48t2IhVFnmy)
				if ZgsbN5iSL48t2IhVFnmy in DIA54R1lwcTz7OZPjX6a: continue
				else: DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__download')
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
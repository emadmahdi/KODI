# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
headers = { 'User-Agent' : CJlTSEpZsWb0QHg5w }
T1QDsJlUtCGhn = 'AKOAMCAM'
kL0nT7NpZdKVD3jM2OHB = '_AKC_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['مصارعة']
def hH3sRBSFAr(mode,url,text):
	if   mode==350: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==351: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==352: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==353: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==354: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'FILTERS___'+text)
	elif mode==355: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'CATEGORIES___'+text)
	elif mode==356: SD0TxMRXiep4cjPBsnzI = cmUB62GrfeTlwqMPSQ(url)
	elif mode==357: SD0TxMRXiep4cjPBsnzI = B69Gxeydir(url)
	elif mode==359: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',kL0nT7NpZdKVD3jM2OHB+Ym6q5M4TocDaA013RjFQ+'هذا الموقع مغلق'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,8)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,359,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر محدد',V4kF6EQiwo,356)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر كامل',V4kF6EQiwo,357)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKOAMCAM-MENU-1st')
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('recently-container.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]
	else: BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'اضيف حديثا',BBwfuWGxUIrdCoc4ka7,351)
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('@id":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]
	else: BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المميزة',BBwfuWGxUIrdCoc4ka7,351,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-categories-list(.*?)main-categories-list',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?class="font.*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,351)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="categories-box(.*?)<footer',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = wAmsc95ya0LHz(ZgsbN5iSL48t2IhVFnmy)
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,351)
	return bGIVq1CQTjmosZg
def cmUB62GrfeTlwqMPSQ(website=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKOAMCAM-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="menu(.*?)<nav',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?text">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur:
				title = title+' مصنفة'
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,355)
		if website==CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	return bGIVq1CQTjmosZg
def B69Gxeydir(website=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,'AKOAMCAM-MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="menu(.*?)<nav',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?text">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title not in qe1JPURnS9ODoCNEpbdh8i67Tur:
				title = title+' مفلترة'
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,354)
		if website==CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	return bGIVq1CQTjmosZg
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(uhTI2t3wObYqsAi9DCoc,url,CJlTSEpZsWb0QHg5w,headers,True,'AKOAMCAM-TITLES-1st')
	if type=='featured': s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('swiper-container(.*?)swiper-button-prev',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="container"(.*?)main-footer',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('xlink:href="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		wDkMP6jlz7XeN5Sp = []
		for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			if 'الحلقة' in title or 'الحلقه' in title:
				ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|الحلقه) \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if ABK45TEMpciLnmIlYOafQJZ8t:
					title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0][0]
					if title not in wDkMP6jlz7XeN5Sp:
						khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,352,hzGKUP1XjAoeT79MJcDF)
						wDkMP6jlz7XeN5Sp.append(title)
			elif 'مسلسل' in title:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,352,hzGKUP1XjAoeT79MJcDF)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,353,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href=["\'](.*?)["\'].*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = wAmsc95ya0LHz(ZgsbN5iSL48t2IhVFnmy)
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,351)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo + '/?s='+QjfknOVHzZIUir
	SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	return
def j9zTQsrVRx2(url):
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,headers,True,'AKOAMCAM-EPISODES-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('text-white">الحلقات(.*?)<header',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		iypksRX5aYC = Zy2l0g8QU5vqefaTrsw.findall('href="(http.*?)".*?src="(.*?)".*?alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in iypksRX5aYC:
			if 'الحلقة' in title or 'الحلقه' in title: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,353,hzGKUP1XjAoeT79MJcDF)
	else:
		hzGKUP1XjAoeT79MJcDF = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel('ListItem.Icon')
		if bGIVq1CQTjmosZg.count('<title>')>1: title = Zy2l0g8QU5vqefaTrsw.findall('<title>(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)[1]
		else: title = 'رابط التشغيل'
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,url,353,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	MNXzjK3vV7D,Uz8mMbZifCyvkLnct = [],[]
	QzedPJIFoicwvakHf = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AKOAMCAM-PLAY-1st')
	bGIVq1CQTjmosZg = QzedPJIFoicwvakHf.content
	e2MSyTKUbONAa14zYLXZPCQv = Zy2l0g8QU5vqefaTrsw.findall('post_id=(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if e2MSyTKUbONAa14zYLXZPCQv:
		e2MSyTKUbONAa14zYLXZPCQv = e2MSyTKUbONAa14zYLXZPCQv[0]
		headers = {'User-Agent':CJlTSEpZsWb0QHg5w,'Content-Type':'application/x-www-form-urlencoded'}
		data = {'post_id':e2MSyTKUbONAa14zYLXZPCQv}
		BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Watch.php'
		d1dHblT6xyYeOvNGjcLVEa5B0wJ8Q2 = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'POST',BBwfuWGxUIrdCoc4ka7,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AKOAMCAM-PLAY-1st')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = d1dHblT6xyYeOvNGjcLVEa5B0wJ8Q2.content
		items = Zy2l0g8QU5vqefaTrsw.findall('data-server="(.*?)".*?class="text">(.*?)<',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for qjiOvuHytNI8Z7brRwcU,name in items:
			ZgsbN5iSL48t2IhVFnmy = 'https://w.akoam.cam/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Server.php'
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?postid='+e2MSyTKUbONAa14zYLXZPCQv+'&serverid='+qjiOvuHytNI8Z7brRwcU+'?named='+name+'__watch'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			Uz8mMbZifCyvkLnct.append(name)
		BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+'/wp-content/themes/aflam8kkk/Inc/Ajax/Single/Download.php'
		d1dHblT6xyYeOvNGjcLVEa5B0wJ8Q2 = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'POST',BBwfuWGxUIrdCoc4ka7,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'AKOAMCAM-PLAY-1st')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = d1dHblT6xyYeOvNGjcLVEa5B0wJ8Q2.content
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?class="text">(.*?)<',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.strip(YvOQBzaTAscXR9ql)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
			Uz8mMbZifCyvkLnct.append(title)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def wwkAylgOx852(url,filter):
	eLr1mRpNf0WX75CET62FjuIgaHq = ['cat','genre','release-year','quality','orderby']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='CATEGORIES':
		if eLr1mRpNf0WX75CET62FjuIgaHq[0]+'=' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = eLr1mRpNf0WX75CET62FjuIgaHq[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(eLr1mRpNf0WX75CET62FjuIgaHq[0:-1])):
			if eLr1mRpNf0WX75CET62FjuIgaHq[PMTRpXQvDIkiNszwYGnb32a]+'=' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = eLr1mRpNf0WX75CET62FjuIgaHq[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+y3LbIjrZvcATpNDM+'=0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+y3LbIjrZvcATpNDM+'=0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&')+'___'+YYvW68idVrJQFa.strip('&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'all')
		BBwfuWGxUIrdCoc4ka7 = url+'?'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='FILTERS':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm!=CJlTSEpZsWb0QHg5w: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'all')
		if bnCVRhKEGJ0DIYqUBsgdpm==CJlTSEpZsWb0QHg5w: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'?'+bnCVRhKEGJ0DIYqUBsgdpm
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها',BBwfuWGxUIrdCoc4ka7,351,CJlTSEpZsWb0QHg5w,'1')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',BBwfuWGxUIrdCoc4ka7,351,CJlTSEpZsWb0QHg5w,'1')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,headers,True,'AKOAMCAM-FILTERS_MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<form id(.*?)</form>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = Zy2l0g8QU5vqefaTrsw.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	dict = {}
	for HLQNhXe7orPjl5Vm4,name,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		items = Zy2l0g8QU5vqefaTrsw.findall('<option(.*?)>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if '=' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='CATEGORIES':
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<=1:
				if HLQNhXe7orPjl5Vm4==eLr1mRpNf0WX75CET62FjuIgaHq[-1]: nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'CATEGORIES___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				if HLQNhXe7orPjl5Vm4==eLr1mRpNf0WX75CET62FjuIgaHq[-1]: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,351,CJlTSEpZsWb0QHg5w,'1')
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,355,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='FILTERS':
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'=0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'=0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع : '+name,BBwfuWGxUIrdCoc4ka7,354,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		dict[HLQNhXe7orPjl5Vm4] = {}
		for value,ll5WFBCJKhA64tIDT8qvX in items:
			if ll5WFBCJKhA64tIDT8qvX in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			if 'value' not in value: value = ll5WFBCJKhA64tIDT8qvX
			else: value = Zy2l0g8QU5vqefaTrsw.findall('"(.*?)"',value,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
			dict[HLQNhXe7orPjl5Vm4][value] = ll5WFBCJKhA64tIDT8qvX
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'='+ll5WFBCJKhA64tIDT8qvX
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			title = ll5WFBCJKhA64tIDT8qvX+' : '#+dict[HLQNhXe7orPjl5Vm4]['0']
			title = ll5WFBCJKhA64tIDT8qvX+' : '+name
			if type=='FILTERS': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,354,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
			elif type=='CATEGORIES' and eLr1mRpNf0WX75CET62FjuIgaHq[-2]+'=' in LLnTmNF7UG4:
				mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'all')
				ysw7G3tqjo = url+'?'+mmMRqiu1zXvWZlK7hAgEQn
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ysw7G3tqjo,351,CJlTSEpZsWb0QHg5w,'1')
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,355,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&')
	Sucv4JD0rRPaBL8HFMjNt = {}
	if '=' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('=')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	fuTzgEqmbRX378cwQnJH9rhFCt = CJlTSEpZsWb0QHg5w
	J6JSN2vjp5knhiVoFLXUAWBqGsT = ['cat','genre','release-year','quality','orderby']
	for key in J6JSN2vjp5knhiVoFLXUAWBqGsT:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
		elif mode=='all': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&')
	return fuTzgEqmbRX378cwQnJH9rhFCt
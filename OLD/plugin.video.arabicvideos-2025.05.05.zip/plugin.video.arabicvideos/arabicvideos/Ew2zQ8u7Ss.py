# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from EcRxvVj7hw import *
SITESURLS = {
			 mi2ZJXCDzITuyev6gfn(u"ࠫࡆࡎࡗࡂࡍ઼ࠪ")		:[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡴ࠰ࡤ࡬ࡼࡧ࡫ࡵࡸ࠱ࡲࡪࡺࠧઽ")]
			,XB4CjMkPFzhAHiI3q(u"࠭ࡁࡌࡑࡄࡑࠬા")		:[GISOTJh20W(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣ࡮࠲ࡸࡼ࠯ࡰ࡮ࡧࠫિ")]
			,JACnOz297UuDK5HpPkc1LF(u"ࠨࡃࡎ࡛ࡆࡓࠧી")		:[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰ࠴ࡳࡷࠩુ")]
			,GISOTJh20W(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭ૂ")	:[GISOTJh20W(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࠯ࡣ࡮ࡻࡦࡳ࠮ࡵࡷࡥࡩࠬૃ")]
			,s97s2k0LJgl(u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧૄ")		:[HaTI5u1f3SCxmMAkw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡦ࡬ࠬૅ")]
			,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡂࡎࡐࡗ࡙ࡈࡁࠨ૆")		:[yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡡ࡭࡯ࡶࡸࡧࡧ࠮ࡵࡸࠪે")]
			,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫૈ")		:[mi2ZJXCDzITuyev6gfn(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡩ࡮ࡧࡽ࡭ࡩ࠴ࡳࡩࡱࡺࠫૉ")]
			,JACnOz297UuDK5HpPkc1LF(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩ૊")	:[o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡶࡦࡨࡩࡤ࠯ࡷࡳࡴࡴࡳ࠯ࡥࡲࡱࠬો")]
			,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨૌ")		:[EcjO3giln2kQTdBY0XLAG(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡵࡥࡧࡹࡥࡦࡦ࠱ࡲࡪࡺ્ࠧ")]
			,o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡃ࡜ࡐࡔࡒࠧ૎")		:[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪ࠴ࡡࡺ࡮ࡲࡰ࠳ࡴࡥࡵࠩ૏")]
			,VVvcQpCU3OM09n(u"ࠪࡆࡔࡑࡒࡂࠩૐ")		:[KA26GucUHOwXL(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࡮࡯ࡰࡨࡹࡳࡩ࠴ࡣࡰ࡯ࠪ૑")]
			,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡈࡒࡔࡖࡈࡎࠬ૒")		:[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡴࡶࡸࡪࡰ࠮ࡤࡱࡰࠫ૓")]
			,XB4CjMkPFzhAHiI3q(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ૔")		:[XB4CjMkPFzhAHiI3q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠴࠱࠲࠱ࡧࡴࡳࠧ૕")]
			,mi2ZJXCDzITuyev6gfn(u"ࠩࡆࡍࡒࡇ࠴ࡑࠩ૖")		:[o2FdrDBimMuOw97q6QpNW8S(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠶ࡳ࠲ࡨࡵ࡭ࠨ૗")]
			,pz4WBwfyDdgk0m2aRr7SMv(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫ૘")		:[HaTI5u1f3SCxmMAkw(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࠱ࡤ࡫ࡰࡥ࠹ࡻ࠮ࡤࡱࡰࠫ૙")]
			,s97s2k0LJgl(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨ૚")		:[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥ࡬ࡱࡦ࠹ࡢࡥࡱ࠱ࡧࡴࡳࠧ૛")]
			,XB4CjMkPFzhAHiI3q(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪ૜")		:[KA26GucUHOwXL(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡤ࡮ࡸࡦ࠳ࡽࡡࡵࡥ࡫ࠫ૝")]
			,Olh7n0zfV4(u"ࠪࡇࡎࡓࡁࡄࡎࡘࡆ࡜ࡕࡒࡌࠩ૞")	:[O4F8UC5lMAS6ghETm1VoPDI(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡶࡷ࠰ࡦ࡭ࡲࡧࡣ࡭ࡷࡥ࠲ࡸ࡮࡯ࡱࠩ૟")]
			,TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧૠ")		:[h6sIkJOT5PB2vCxqo4LFag70wA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨ࡯࡭ࡢࡨࡤࡲࡸ࠴ࡣࡰࠩૡ")]
			,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩૢ")		:[ZP1LyUCS3pIBu(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧࡦࡳࡧࡨ࠲ࡻ࡯ࡰࠨૣ")]
			,JACnOz297UuDK5HpPkc1LF(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ૤")	:[otNfFapeEnO(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲࡿ࠭ࡤ࡫ࡰࡥ࠳ࡴࡥࡵࠩ૥")]
			,KA26GucUHOwXL(u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ૦")		:[TDpFsQXHze2q30uYtGPfEIm8(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡲࡴࡽ࠮ࡤࡥࠪ૧")]
			,ZP1LyUCS3pIBu(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨ૨")		:[zQGaM7ctZCN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡦࠫ૩")]
			,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭૪")	:[EcjO3giln2kQTdBY0XLAG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠳ࡩ࡯࡮ࠩ૫"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡸࡡࡱࡪࡴࡰ࠳ࡧࡰࡪ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰࠫ૬")]
			,TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡉࡘࡁࡎࡃࡆࡅࡋࡋࠧ૭")	:[zQGaM7ctZCN(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷ࠳࠷࠱ࡨࡷࡧ࡭ࡢࡥࡤࡪࡪ࠳ࡴࡷ࠰ࡦࡳࡲ࠭૮")]
			,XB4CjMkPFzhAHiI3q(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ૯")		:[cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵࡥࡲࡧࡳ࠸࠰ࡱࡩࡹ࠭૰")]
			,o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪ૱")		:[yylSaxCLfkte(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠲࡫ࡻ࡮ࠨ૲")]
			,yylSaxCLfkte(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠶ࠬ૳")		:[otNfFapeEnO(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺࡤࡨࡷࡹ࠴ࡷࡦࡤࡦࡥࡲ࠭૴")]
			,Olh7n0zfV4(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠹ࠧ૵")		:[I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡥ࡭ࡩ࠭૶")]
			,HaTI5u1f3SCxmMAkw(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩ૷")		:[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠳ࡢࡦࡵࡷ࠲ࡳ࡫ࡴࠨ૸")]
			,HaTI5u1f3SCxmMAkw(u"ࠩࡈࡋ࡞ࡊࡅࡂࡆࠪૹ")		:[VVvcQpCU3OM09n(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡥࡧࡤࡨ࠳ࡲࡩࡷࡧࠪૺ")]
			,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡊࡒࡃࡊࡐࡈࡑࡆ࠭ૻ")		:[otNfFapeEnO(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡭ࡥ࡬ࡲࡪࡳࡡ࠯ࡥࡲࡱࠬૼ")]
			,mi2ZJXCDzITuyev6gfn(u"࠭ࡅࡍࡋࡉ࡚ࡎࡊࡅࡐࠩ૽")	:[Olh7n0zfV4(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡯ࡤ࠯ࡧ࡯࡭࡫࠴࡮ࡦࡹࡶࠫ૾")]
			,s97s2k0LJgl(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩ૿")		:[ZP1LyUCS3pIBu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡨࡲ࡬ࡣ࠱ࡧࡴࡳࠧ଀")]
			,XB4CjMkPFzhAHiI3q(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ଁ")	:[zQGaM7ctZCN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࡫ࡧࡵ࠲ࡸ࡮࡯ࡸࠩଂ")]
			,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡌࡁࡓࡇࡖࡏࡔ࠭ଃ")		:[E6xdOMpqISHZCn(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷ࡫ࡳ࠲࡫ࡧࡲࡦࡵ࡮ࡳ࠳ࡴࡥࡵࠩ଄")]
			,yylSaxCLfkte(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩଅ")		:[JACnOz297UuDK5HpPkc1LF(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷࡱࡧ࠮ࡧࡣࡶࡩࡱ࡮ࡤ࠯ࡥ࡯ࡳࡺࡪࠧଆ")]
			,o2FdrDBimMuOw97q6QpNW8S(u"ࠩࡉࡓࡘ࡚ࡁࠨଇ")		:[yylSaxCLfkte(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡪ࠯ࡨࡲࡷࡹࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧଈ")]
			,ZP1LyUCS3pIBu(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬଉ")		:[O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡧ࠯ࡣ࡯ࡱࡪࡹࡨ࡬ࡣ࡫࠲ࡳ࡫ࡴࠨଊ")]
			,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡆࡖࡕࡋࡅࡗ࡚ࡖࠨଋ")		:[JACnOz297UuDK5HpPkc1LF(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤ࠱ࡪࡺࡹࡨࡢࡴ࠰ࡸࡻ࠴ࡣࡰ࡯ࠪଌ")]
			,zQGaM7ctZCN(u"ࠨࡈࡘࡗࡍࡇࡒࡗࡋࡇࡉࡔ࠭଍")	:[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳࡬ࡵࡴࡪࡤࡶ࠳ࡼࡩࡥࡧࡲࠫ଎")]
			,E6xdOMpqISHZCn(u"ࠪࡌࡆࡒࡁࡄࡋࡐࡅࠬଏ")		:[JACnOz297UuDK5HpPkc1LF(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡮ࡡ࡭ࡣࡦ࡭ࡲࡧ࠮࡮ࡧࡧ࡭ࡦ࠭ଐ")]
			,VVvcQpCU3OM09n(u"ࠬࡏࡆࡊࡎࡐࠫ଑")		:[KA26GucUHOwXL(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ଒"),rC5tnFDlQcRGA2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳࡯ࡲࠨଓ"),otNfFapeEnO(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩࡥ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡩࡳࠩଔ"),Olh7n0zfV4(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦ࠸࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫକ"),E6xdOMpqISHZCn(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠽࠸࠴࠱࠺࠲࠱࠶࠹࠴࠱࠳࠴ࠪଖ")]
			,GISOTJh20W(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧଗ")	:[GISOTJh20W(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱࡭ࡶ࠭ଘ")]
			,s97s2k0LJgl(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨଙ")		:[HaTI5u1f3SCxmMAkw(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭࡬ࡸࡰࡵࡴ࠯ࡥࡤࡱࠬଚ")]
			,zQGaM7ctZCN(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩଛ")		:[ZP1LyUCS3pIBu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡺ࠴࡫ࡪࡴࡰࡥࡱࡱ࠮ࡤࡱࡰࠫଜ")]
			,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪଝ")		:[cbmeD4WNZfAowxT2JdUMtV(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲࡡࡳࡱࡽࡥ࠳࡯࡮࡬ࠩଞ")]
			,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭ଟ")		:[GISOTJh20W(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡧࡽࡳ࡫ࡴ࠯࡮࡬ࡲࡰ࠭ଠ")]
			,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡎࡃࡖࡅ࡛ࡏࡄࡆࡑࠪଡ")	:[O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡲ࠳ࡳࡡࡴࡣ࠱ࡲࡪࡽࡳࠨଢ")]
			,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡓࡅࡓࡋࡔࠨଣ")		:[EcjO3giln2kQTdBY0XLAG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡣࡱࡩࡹ࠴ࡣࡰ࠰࡬ࡰࠬତ")]
			,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࡗࡋࡌࡆࡃࡖࡉࡘ࠭ଥ")		:[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪ࠲࡯ࡴࡪࡩ࠰ࡧࡰࡥࡩࡥࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠴ࡵ࡬ࡥ࠱࡬ࡲࡩ࡫ࡸ࠯ࡪࡷࡱࡱ࠭ଦ")]
			,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡓࡆࡔࡌࡉࡘ࡚ࡉࡎࡇࠪଧ")	:[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡤࡤ࠲ࡸ࡫ࡲࡪࡧࡶࡸ࡮ࡳࡥ࠯ࡥࡤࡱࠬନ")]
			,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡕࡋࡅࡇࡇࡋࡂࡖ࡜ࠫ଩")	:[cjVhOCwybeRo7UWg92(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧ࡮ࡳࡡࡩࡦ࠱ࡺ࡮ࡶࠧପ")]
			,GISOTJh20W(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬଫ")		:[TDpFsQXHze2q30uYtGPfEIm8(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡢࡪ࠷ࡹ࠳ࡴࡥࡵࠩବ")]
			,HaTI5u1f3SCxmMAkw(u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛࠲ࠨଭ")	:[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࠰࡯࡭ࡻ࡫ࠧମ")]
			,TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫଯ")	:[yylSaxCLfkte(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࠲ࡸ࡮࠴ࡶ࠰ࡱࡩࡼࡹࠧର")]
			,EcjO3giln2kQTdBY0XLAG(u"ࠩࡖࡌࡔࡌࡈࡂࠩ଱")		:[VVvcQpCU3OM09n(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮࡯ࡧࡪࡤ࠲ࡹࡼࠧଲ")]
			,cjVhOCwybeRo7UWg92(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭ଳ")		:[E6xdOMpqISHZCn(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡩࡱࡲࡪࡲࡧࡸ࠯ࡥࡲࡱࠬ଴"),EcjO3giln2kQTdBY0XLAG(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡴࡪࡲࡳ࡫ࡳࡡࡹ࠰ࡦࡳࡲ࠭ଵ"),mi2ZJXCDzITuyev6gfn(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡳࡴ࡬࡭ࡢࡺ࠱ࡥࡿࡻࡲࡦࡧࡧ࡫ࡪ࠴࡮ࡦࡶࠪଶ")]
			,mi2ZJXCDzITuyev6gfn(u"ࠨࡕࡋࡓࡔࡌࡎࡆࡖࠪଷ")		:[ZP1LyUCS3pIBu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡸ࠴ࡳࡩࡱࡲࡪࡳ࡫ࡴ࠯ࡱࡱࡰ࡮ࡴࡥࠨସ")]
			,HaTI5u1f3SCxmMAkw(u"ࠪࡘࡎࡑࡁࡂࡖࠪହ")		:[zQGaM7ctZCN(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡺࡩ࡬ࡣࡤࡸ࠳ࡴࡥࡵࠩ଺")]
			,otNfFapeEnO(u"࡚ࠬࡖࡇࡗࡑࠫ଻")		:[HaTI5u1f3SCxmMAkw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺ࡫ࡻ࡮࠯࡯ࡨ଼ࠫ")]
			,E6xdOMpqISHZCn(u"ࠧࡗࡃࡕࡆࡔࡔࠧଽ")		:[XB4CjMkPFzhAHiI3q(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡰ࠲ࡻࡧࡲࡣࡱࡱ࠲ࡨࡧ࡭ࠨା")]
			,HaTI5u1f3SCxmMAkw(u"࡙ࠩࡍࡉࡋࡏࡏࡕࡄࡉࡒ࠭ି")	:[CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡲࡸࡧࡥ࡮࠰ࡱࡩࡹ࠭ୀ")]
			,HaTI5u1f3SCxmMAkw(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠵ࠬୁ")		:[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡥ࡬ࡱࡦ࠴ࡳࡩࡱࡺࠫୂ")]
			,KA26GucUHOwXL(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧୃ")		:[yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡧ࡮ࡳࡡ࠯ࡥ࡯࡭ࡨࡱࠧୄ")]
			,pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࡛ࡄࡕࡔ࡚ࠧ୅")		:[EcjO3giln2kQTdBY0XLAG(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽ࠳ࡿࡡࡲࡱࡷ࠲ࡹࡼࠧ୆")]
			,s97s2k0LJgl(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫେ")		:[mi2ZJXCDzITuyev6gfn(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳࠧୈ")]
			,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࡟ࡔࡃࡡࡆࡌࡆࡔࡎࡆࡎࡖࠫ୉")	:[yylSaxCLfkte(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮ࠩ୊")]
			,cjVhOCwybeRo7UWg92(u"ࠧࡊࡒࡗ࡚ࠬୋ")			:[CJlTSEpZsWb0QHg5w]
			,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡏ࠶࡙ࠬୌ")			:[CJlTSEpZsWb0QHg5w]
			,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡕࡉࡕࡕࡓࠨ୍")		:[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪ୎"),rC5tnFDlQcRGA2(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨ୏"),yylSaxCLfkte(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩ୐")]
			,TDpFsQXHze2q30uYtGPfEIm8(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑ࠳ࠪ୑")	:[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡲࡢࡹ࠲ࡶࡪ࡬ࡳ࠰ࡪࡨࡥࡩࡹ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠯ࡢࡦࡧࡳࡳࡹ࠮ࡹ࡯࡯ࠫ୒"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࡭ࡹ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯ࡳࡣࡺ࠳ࡷ࡫ࡦࡴ࠱࡫ࡩࡦࡪࡳ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡃࡇࡈࡔࡔࡓ࠲࠺࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠼࠳ࡾ࡭࡭ࠩ୓"),ZP1LyUCS3pIBu(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠲ࡏࡔࡊࡉ࠰ࡴࡤࡻ࠴ࡸࡥࡧࡵ࠲࡬ࡪࡧࡤࡴ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡄࡈࡉࡕࡎࡔ࠳࠼࠳ࡦࡪࡤࡰࡰࡶ࠵࠾࠴ࡸ࡮࡮ࠪ୔")]
			,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡖࡊࡖࡏࡔࡡࡅࡏࡕ࠸ࠧ୕")	:[rC5tnFDlQcRGA2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡴࡨࡴࡴ࠴ࡵ࡬࠰ࡷࡳ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩୖ"),E6xdOMpqISHZCn(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡵࡩࡵࡵ࠮ࡶ࡭࠱ࡸࡴ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧୗ"),E6xdOMpqISHZCn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡶࡪࡶ࡯࠯ࡷ࡮࠲ࡹࡵ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨ୘")]
			,XB4CjMkPFzhAHiI3q(u"ࠧࡓࡇࡓࡓࡘࡥࡂࡌࡒ࠶ࠫ୙")	:[XB4CjMkPFzhAHiI3q(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡇࡄࡅࡑࡑࡗ࠴ࡧࡤࡥࡱࡱࡷ࠳ࡾ࡭࡭ࠩ୚"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡁࡅࡆࡒࡒࡘ࠷࠸࠰ࡣࡧࡨࡴࡴࡳ࠲࠺࠱ࡼࡲࡲࠧ୛"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨଡ଼")]
			,XB4CjMkPFzhAHiI3q(u"ࠫࡐࡕࡄࡊࡡࡖࡓ࡚ࡘࡃࡆࡕࠪଢ଼")	:[HaTI5u1f3SCxmMAkw(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯ࠧ୞"),s97s2k0LJgl(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴ࡱ࡯ࡥ࡫ࠪୟ"),cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡭ࡲࡨ࡮࠭ୠ")]
			,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨࡈࡌࡐࡊ࡙࡟ࡔࡑࡘࡖࡈࡋࡓࠨୡ"):[GISOTJh20W(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡳ࡫ࡴ࡭࡫ࡩࡽ࠳ࡧࡰࡱࠩୢ")]
			,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠪࡏࡔࡊࡉࡆࡏࡄࡈࡤࡇࡐࡑࠩୣ")	:[TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪࠧ୤"),ZP1LyUCS3pIBu(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠶࠵࠷࠸࠯ࡨࡺࡷ࠳ࡹࡴࡰࡴࡨࠫ୥")]
			}
if P2Fgh6TCOWoaHjkqBcQnvRNXe:
	SITESURLS[NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭୦")]      = [GISOTJh20W(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ୧"),mi2ZJXCDzITuyev6gfn(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭୨"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ୩"),JACnOz297UuDK5HpPkc1LF(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ୪"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ୫"),o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ୬"),VVvcQpCU3OM09n(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ୭"),o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ୮"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ୯"),GISOTJh20W(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ୰"),yylSaxCLfkte(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭ୱ")]
	SITESURLS[I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐ࠲ࠩ୲")] = [xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ୳"),HaTI5u1f3SCxmMAkw(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭୴"),ZP1LyUCS3pIBu(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ୵"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ୶"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ୷"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ୸"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ୹"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠰ࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧ࠱ࡧࡴࡳ࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ୺"),Olh7n0zfV4(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩ୻"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ୼"),KA26GucUHOwXL(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭୽")]
	SITESURLS[JACnOz297UuDK5HpPkc1LF(u"ࠩࡓ࡝࡙ࡎࡏࡏࡡࡅࡏࡕ࠸ࠧ୾")] = [XB4CjMkPFzhAHiI3q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡱ࡯ࡳࡵࡲ࡯ࡥࡾ࠭୿"),cbmeD4WNZfAowxT2JdUMtV(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡻࡳࡢࡩࡨࡶࡪࡶ࡯ࡳࡶࠪ஀"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡳࡦࡰࡧࡩࡲࡧࡩ࡭ࠩ஁"),rC5tnFDlQcRGA2(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡨࡧࡷࡱࡪࡹࡳࡢࡩࡨࡷࠬஂ"),E6xdOMpqISHZCn(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸ࡮ࡹ࡬ࡢ࡯࡬ࡧࠬஃ"),Olh7n0zfV4(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ஄"),JACnOz297UuDK5HpPkc1LF(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺ࡫࡯ࡱࡺࡲࡪࡸࡲࡰࡴࡶࠫஅ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳ࡨࡧࡰࡵࡥ࡫ࡥࠬஆ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴ࡺࡥࡴࡶ࡬ࡲ࡬࠭இ"),KA26GucUHOwXL(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡧࡦࡶࡨࡼࡹࡸࡡࡱࡻࡷ࡬ࡴࡴࡣࡰࡦࡨࠫஈ"),mi2ZJXCDzITuyev6gfn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡦࡺࡨࡧࡺࡺࡥ࡫ࡵࠪஉ")]
	SITESURLS[cbmeD4WNZfAowxT2JdUMtV(u"ࠧࡑ࡛ࡗࡌࡔࡔ࡟ࡃࡍࡓ࠷ࠬஊ")] = [EcjO3giln2kQTdBY0XLAG(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧ஋"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫ஌"),XB4CjMkPFzhAHiI3q(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ஍"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭எ"),o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡮ࡱࡲࡳ࠳ࡩ࡯࡮࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭ஏ"),O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯࡯ࡲࡳࡴ࠴ࡣࡰ࡯࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩஐ"),JACnOz297UuDK5HpPkc1LF(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡰࡳࡴࡵ࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬ஑"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡱࡴࡵ࡯࠯ࡥࡲࡱ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ஒ"),VVvcQpCU3OM09n(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡲࡵ࡯ࡰ࠰ࡦࡳࡲ࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧஓ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡳ࡯ࡰࡱ࠱ࡧࡴࡳ࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬஔ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡭ࡰࡱࡲ࠲ࡨࡵ࡭࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫக")]
else:
	SITESURLS[EcjO3giln2kQTdBY0XLAG(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ஖")]      = [mi2ZJXCDzITuyev6gfn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩ஗"),Olh7n0zfV4(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭஘"),otNfFapeEnO(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬங"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨச"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ஛"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫஜ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ஝"),mi2ZJXCDzITuyev6gfn(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨஞ"),otNfFapeEnO(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩட"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧ஠"),VVvcQpCU3OM09n(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡩࡽ࡫ࡣࡶࡶࡨ࡮ࡸ࠭஡")]
	SITESURLS[od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡔ࡞࡚ࡈࡐࡐࡢࡆࡐࡖ࠱ࠨ஢")] = [CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡲࡩࡴࡶࡳࡰࡦࡿࠧண"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡵࡴࡣࡪࡩࡷ࡫ࡰࡰࡴࡷࠫத"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡴࡧࡱࡨࡪࡳࡡࡪ࡮ࠪ஥"),o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭஦"),XB4CjMkPFzhAHiI3q(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡯ࡳ࡭ࡣࡰ࡭ࡨ࠭஧"),Olh7n0zfV4(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡱࡶࡧࡶࡸ࡮ࡵ࡮ࡴࠩந"),cjVhOCwybeRo7UWg92(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡬ࡰࡲࡻࡳ࡫ࡲࡳࡱࡵࡷࠬன"),VVvcQpCU3OM09n(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠭ப"),s97s2k0LJgl(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡴࡦࡵࡷ࡭ࡳ࡭ࠧ஫"),Olh7n0zfV4(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷࡩࡽࡺࡲࡢࡲࡼࡸ࡭ࡵ࡮ࡤࡱࡧࡩࠬ஬"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡧࡻࡩࡨࡻࡴࡦ࡬ࡶࠫ஭")]
	SITESURLS[xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡒ࡜ࡘࡍࡕࡎࡠࡄࡎࡔ࠷࠭ம")] = [h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬய"),ZP1LyUCS3pIBu(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵࠩர"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨற"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫல"),O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫள"),yylSaxCLfkte(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧழ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪவ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫஶ"),EcjO3giln2kQTdBY0XLAG(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬஷ"),mi2ZJXCDzITuyev6gfn(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪஸ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡥࡹࡧࡦࡹࡹ࡫ࡪࡴࠩஹ")]
	SITESURLS[cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡐ࡚ࡖࡋࡓࡓࡥࡂࡌࡒ࠶ࠫ஺")] = [yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪ஻"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ஼"),GISOTJh20W(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭஽"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩா"),VVvcQpCU3OM09n(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩி"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷࠬீ"),GISOTJh20W(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨு"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡥࡤࡴࡹࡩࡨࡢࠩூ"),zQGaM7ctZCN(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪ௃"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨ௄"),yylSaxCLfkte(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡪࡾࡥࡤࡷࡷࡩ࡯ࡹࠧ௅")]
api_python_actions = [XB4CjMkPFzhAHiI3q(u"ࠫࡑࡏࡓࡕࡒࡏࡅ࡞࠭ெ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡘࡅࡑࡑࡕࡘࡘ࠭ே"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡅࡎࡃࡌࡐࡘ࠭ை"),rC5tnFDlQcRGA2(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩ௉"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࡋࡖࡐࡆࡓࡉࡄࡕࠪொ"),s97s2k0LJgl(u"ࠩࡔ࡙ࡊ࡙ࡔࡊࡑࡑࡗࠬோ"),yylSaxCLfkte(u"ࠪࡏࡓࡕࡗࡏࡇࡕࡖࡔࡘࡓࠨௌ"),E6xdOMpqISHZCn(u"ࠫࡈࡇࡐࡕࡅࡋࡅ்ࠬ"),cbmeD4WNZfAowxT2JdUMtV(u"࡚ࠬࡅࡔࡖࡌࡒࡌ࠭௎"),VVvcQpCU3OM09n(u"࠭ࡅ࡙ࡖࡕࡅࡕ࡟ࡔࡉࡑࡑࡇࡔࡊࡅࠨ௏"),EcjO3giln2kQTdBY0XLAG(u"ࠧࡆ࡚ࡈࡇ࡚࡚ࡅࡋࡕࠪௐ")]
api_repos_actions = [O4F8UC5lMAS6ghETm1VoPDI(u"ࠨࡃࡇࡈࡔࡔࡓࠨ௑"),cjVhOCwybeRo7UWg92(u"ࠩࡄࡈࡉࡕࡎࡔ࠳࠻ࠫ௒"),zQGaM7ctZCN(u"ࠪࡅࡉࡊࡏࡏࡕ࠴࠽ࠬ௓")]
non_videos_actions = [E6xdOMpqISHZCn(u"ࠫࡆࡒࡌࠨ௔"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬ௕"),Olh7n0zfV4(u"࠭ࡉࡏࡕࡗࡅࡑࡒࠧ௖"),rC5tnFDlQcRGA2(u"ࠧࡎࡇࡗࡖࡔࡖࡏࡍࡋࡖࠫௗ"),otNfFapeEnO(u"ࠨࡔࡈࡔࡔ࡙ࠧ௘"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗࠬ௙"),mi2ZJXCDzITuyev6gfn(u"ࠪࡇࡆࡖࡔࡄࡊࡄࡍࡉ࠭௚"),GISOTJh20W(u"ࠫࡈࡇࡐࡕࡅࡋࡅ࡙ࡕࡋࡆࡐࠪ௛"),E6xdOMpqISHZCn(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡍࡅࡕࡋࡇࠫ௜"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ࡓࡊࡖࡈࡗ࡚ࡘࡌࡔࠩ௝")]+api_python_actions+api_repos_actions
krgh8yUEqa = VJZIMkUN5siqB21Pf
QFCWcArusifVavlYk29 = w2qb6lf5EM
wpBxtqcsDEafMFkToIXe = VJZIMkUN5siqB21Pf
wsrSnHQfOWm8 = VJZIMkUN5siqB21Pf
avprivsnorestrict = VJZIMkUN5siqB21Pf
avprivslongperiod = VJZIMkUN5siqB21Pf
resolveonly = VJZIMkUN5siqB21Pf
SuWYMCwV1oBNIG8cq7xR = VJZIMkUN5siqB21Pf
ALLOW_DNS_FIX = gZvlfk6xhACbXcD5j0KBLiVM1
ALLOW_PROXY_FIX = gZvlfk6xhACbXcD5j0KBLiVM1
ALLOW_SHOWDIALOGS_FIX = gZvlfk6xhACbXcD5j0KBLiVM1
menuItemsLIST = []
SEND_THESE_EVENTS = []
FORWARDS_HOSTNAMES = {}
menuItemsDICT = {}
BADSCRAPERS = []
BADWEBSITES = [zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠧࡇࡗࡖࡌࡆࡘࡔࡗࠩ௞"),HaTI5u1f3SCxmMAkw(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫ௟"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪ௠"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬ௡"),EcjO3giln2kQTdBY0XLAG(u"ࠫࡑࡇࡒࡐ࡜ࡄࠫ௢"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧ௣"),otNfFapeEnO(u"࡙࠭ࡂࡓࡒࡘࠬ௤"),HaTI5u1f3SCxmMAkw(u"ࠧࡗࡃࡕࡆࡔࡔࠧ௥"),EcjO3giln2kQTdBY0XLAG(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪ௦"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡓࡅࡓࡋࡔࠨ௧")]
BADCOMMONIDS = [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ࠽࠾࠿࠹࠮࠻࠼࠽࠾࠳࠹࠺࠻࠼࠱࠾࠿࠹࠺࠯࠳࠴࠵࠶ࠧ௨"),ZP1LyUCS3pIBu(u"ࠫ࠾࠿࠸࠹࠯࠺࠻࠻࠼࠭࠶࠷࠷࠸࠲࠹࠳࠳࠴࠰࠶࠵࠾࠶ࠨ௩")]
GEOLOCATION_DATA = CJlTSEpZsWb0QHg5w
AV_CLIENT_IDS = CJlTSEpZsWb0QHg5w
DNS_SERVERS = [EcjO3giln2kQTdBY0XLAG(u"ࠬ࠷࠮࠲࠰࠴࠲࠶࠭௪"),ZP1LyUCS3pIBu(u"࠭࠸࠯࠺࠱࠼࠳࠾ࠧ௫"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࠲࠰࠳࠲࠵࠴࠱ࠨ௬"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨ࠺࠱࠼࠳࠺࠮࠵ࠩ௭"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ࠵࠴࠽࠴࠶࠸࠰࠵࠶࠷࠴࠲࠳࠴ࠪ௮"),mi2ZJXCDzITuyev6gfn(u"ࠪ࠶࠵࠾࠮࠷࠹࠱࠶࠷࠶࠮࠳࠴࠳ࠫ௯")]
busydialog_active = VJZIMkUN5siqB21Pf
dns_succeeded_urls = []
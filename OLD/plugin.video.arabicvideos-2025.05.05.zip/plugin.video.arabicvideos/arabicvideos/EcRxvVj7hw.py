# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
ZVNvqy4iF1a9X = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠳ৢ")
P2Fgh6TCOWoaHjkqBcQnvRNXe = h6sIkJOT5PB2vCxqo4LFag70wA(u"࠵ৣ")
VTadWjBloMwXO2CH9GDK6FR = P2Fgh6TCOWoaHjkqBcQnvRNXe+P2Fgh6TCOWoaHjkqBcQnvRNXe
D9yBM7wPFLz = VTadWjBloMwXO2CH9GDK6FR+P2Fgh6TCOWoaHjkqBcQnvRNXe
P3cpaLN2sH = D9yBM7wPFLz+P2Fgh6TCOWoaHjkqBcQnvRNXe
GGsP9SDod4iUBm6kNMfLw = P3cpaLN2sH+P2Fgh6TCOWoaHjkqBcQnvRNXe
CJlTSEpZsWb0QHg5w = zQGaM7ctZCN(u"ࠩࠪए")
YvOQBzaTAscXR9ql = Olh7n0zfV4(u"ࠪࠤࠬऐ")
gCc52XVMGfAnOe = YvOQBzaTAscXR9ql*VTadWjBloMwXO2CH9GDK6FR
VzZPgf1qW5L8auj2do9R4FpiXM7Ycy = YvOQBzaTAscXR9ql*D9yBM7wPFLz
NaE5l67ROx = YvOQBzaTAscXR9ql*P3cpaLN2sH
gZvlfk6xhACbXcD5j0KBLiVM1 = None
w2qb6lf5EM = HaTI5u1f3SCxmMAkw(u"ࡖࡵࡹࡪ਄")
VJZIMkUN5siqB21Pf = GISOTJh20W(u"ࡉࡥࡱࡹࡥਅ")
kbtm6wfFgoXpICs = TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠫࡹࡸࡵࡦࠩऑ")
uSo1OXy4h6xJvmAVfB3TEY = VVvcQpCU3OM09n(u"ࠬ࡬ࡡ࡭ࡵࡨࠫऒ")
RFb4YfvJSsWCy7Z0 = JACnOz297UuDK5HpPkc1LF(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ओ")
DnruJV9OfB70TSdt1zcCsWl3wFMI8E = KA26GucUHOwXL(u"ࠧࡥࡧࡩࡥࡺࡲࡴࠨऔ")
Dj62UpP5MrbTkJqhRa = ZP1LyUCS3pIBu(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡈ࠵࠳ࡈࡠࠫक")
Ym6q5M4TocDaA013RjFQ = o2FdrDBimMuOw97q6QpNW8S(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࠬख")
ZHWTM8prgq7xyI9026PfEOJ = EcjO3giln2kQTdBY0XLAG(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋ࠹࠳ࡆ࠶࠶࠷ࡢ࠭ग")
RXSxl4a8gwkhnAtVdj9OeP = XB4CjMkPFzhAHiI3q(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠱ࡇ࠷࠴ࡊࡋࡣࠧघ")
y9hsdr4BK7wI0kS = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊࡋࡌ࡝ࠨङ")
oOQaRxBXyJ5jVnZ = I7K1Tbk8YSXUhApzqwtLEQMV2(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨच")
Im5KSGZYBpRvdMVsbuXg = EcjO3giln2kQTdBY0XLAG(u"ࠧࡶࡶࡩ࠼ࠬछ")
PiDqTEkycIt9BYLs7uMnv5f = cjVhOCwybeRo7UWg92(u"ࠨࡐࡒࡘࡎࡉࡅࠨज")
MMxceZuwFzkCp9y0R = pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨझ")
LMcWw6B48Dj = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡉࡗࡘࡏࡓࠩञ")
owpdSWeCOTgNF6vQPyGEarZ = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩट")
rJ9cgWz4FU = JACnOz297UuDK5HpPkc1LF(u"ࠬࡢ࡮ࠨठ")
rScptJWVdgzQGR1E3LZ9byC = ZP1LyUCS3pIBu(u"࠭࡜ࡳࠩड")
TAExSfcoNi4eORZ8HPB = E6xdOMpqISHZCn(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪढ")
Wx10KPISERil97ApBk = rC5tnFDlQcRGA2(u"࠵࠴࠲࠶৤")
JivAN3RT7g1PDmU8pS5fCxrl4KXk = otNfFapeEnO(u"࠷࠵৥")
wOhnQJgVWFLf0RPpZ1oY = I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠳࠱০")
AwpgdrK0t17WSR2BOifND = EcjO3giln2kQTdBY0XLAG(u"࠲࠲১")
UpTN8c01LBJ = O4F8UC5lMAS6ghETm1VoPDI(u"࠳࠵࠴২")
zSOU8mieXluDYvIKF1HMfZoAgh0LR = [
						 KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡖࡉࡓࡊ࡟ࡂࡐࡄࡐ࡞࡚ࡉࡄࡕࡢࡉ࡛ࡋࡎࡕࡕ࠰࠵ࡸࡺࠧण")
						,O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡅࡗࡣࡒ࠹ࡕ࠹࠯࠴ࡷࡹ࠭त")
						,zQGaM7ctZCN(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡇࡎࡅࡑࡐࡣ࡚࡙ࡅࡓࡃࡊࡉࡓ࡚࠭࠲ࡵࡷࠫथ")
						,HaTI5u1f3SCxmMAkw(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡅࡕࡡࡓࡖࡔ࡞ࡉࡆࡕࡢࡐࡎ࡙ࡔ࠮࠳ࡶࡸࠬद")
						,XB4CjMkPFzhAHiI3q(u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧध")
						,pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩन")
						,HaTI5u1f3SCxmMAkw(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠲ࡵࡷࠫऩ")
						,cjVhOCwybeRo7UWg92(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡓࡔࡍࡌࡆࡡࡑࡉ࡜ࡥࡈࡐࡕࡗࡒࡆࡓࡅ࠮࠵ࡵࡨࠬप")
						,KA26GucUHOwXL(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡖࡊࡇࡄࡠࡃࡏࡐࡤࡇࡄࡅࡑࡑࡗࡤ࡞ࡍࡍ࠯࠴ࡷࡹ࠭फ")
						,TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡇࡐࡑࡊࡐࡊ࡛ࡓࡆࡔࡆࡓࡓ࡚ࡅࡏࡖ࠰࠵ࡸࡺࠧब")
						,TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡃ࡛ࡓࡅࡘ࡙࡟ࡂࡍ࡚ࡅࡒࡥࡃࡂࡒࡗࡇࡍࡇ࠭࠴ࡴࡧࠫभ")
						,pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬम")
						,ZP1LyUCS3pIBu(u"࠭ࡅࡍࡅࡌࡒࡊࡓࡁ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬय")
						,pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡜ࡘࡎࡁࡓࡋࡑࡋ࠲࠷ࡳࡵࠩर")
						,XB4CjMkPFzhAHiI3q(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝࡙ࡈࡂࡔࡌࡒࡌ࠳࠲࡯ࡦࠪऱ")
						]
U3C7tspghAWc8qBHeIK = zSOU8mieXluDYvIKF1HMfZoAgh0LR+[
				 pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫल")
				,otNfFapeEnO(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨळ")
				,E6xdOMpqISHZCn(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧऴ")
				,o2FdrDBimMuOw97q6QpNW8S(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨव")
				,cjVhOCwybeRo7UWg92(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩश")
				,zQGaM7ctZCN(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪष")
				,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪस")
				,yylSaxCLfkte(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫह")
				,GISOTJh20W(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬऺ")
				,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨऻ")
				,O4F8UC5lMAS6ghETm1VoPDI(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡉࡖࡗࡔࡘࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨ़")
				,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓ࠮ࡖࡈࡗ࡙ࡥࡁࡍࡎࡢ࡛ࡊࡈࡓࡊࡖࡈࡗ࠲࠷ࡳࡵࠩऽ")
				,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪा")
				,h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰࡙ࡘࡇࡇࡆࡡࡕࡉࡕࡕࡒࡕ࠯࠴ࡷࡹ࠭ि")
				,s97s2k0LJgl(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡔࡕࡇࡍࡇࡢࡘࡗࡇࡎࡔࡎࡄࡘࡊ࠳࠱ࡴࡶࠪी")
				,ZP1LyUCS3pIBu(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡖࡆࡔࡖࡓࡤ࡚ࡒࡂࡐࡖࡐࡆ࡚ࡅ࠮࠳ࡶࡸࠬु")
				]
R347l8NdWwa5mnO9F2ZzCjYi = [
						 mi2ZJXCDzITuyev6gfn(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ू")
						,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧृ")
						,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐ࡙ࡑ࡚ࡉࡠ࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧॄ")
						]
baPq30VI6TOmUnQJ = GGsP9SDod4iUBm6kNMfLw
gB7j2bpeiCF1v = [XB4CjMkPFzhAHiI3q(u"ࠧึใิࠫॅ"),s97s2k0LJgl(u"ࠨล๋่ࠬॆ"),yylSaxCLfkte(u"ࠩฮห๋๐ࠧे"),KA26GucUHOwXL(u"ࠪฯฬ๊หࠨै"),rC5tnFDlQcRGA2(u"ࠫึอศฺࠩॉ"),cjVhOCwybeRo7UWg92(u"ࠬิวๆีࠪॊ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ำศัึࠫो"),EcjO3giln2kQTdBY0XLAG(u"ࠧิษห฽ࠬौ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨอส्้๋࠭"),zQGaM7ctZCN(u"ࠩอหุ฿ࠧॎ"),s97s2k0LJgl(u"ࠪ฽ฬฺัࠨॏ")]
HHe0MfzptIms3JjZoubEYnkAC4FW = cbmeD4WNZfAowxT2JdUMtV(u"࠹࠴৩")
co23tYRNHwpa = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠺࠵৪")*HHe0MfzptIms3JjZoubEYnkAC4FW
zKrxu3m2blLZ1QkyCd = KA26GucUHOwXL(u"࠷࠺৫")*co23tYRNHwpa
f9LwgkGde0atTh = I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠹࠰৬")*zKrxu3m2blLZ1QkyCd
uhTI2t3wObYqsAi9DCoc = ZVNvqy4iF1a9X
zz5iuewhAFONn8GQc0DtyKZ317pHo = rC5tnFDlQcRGA2(u"࠳࠱৭")*HHe0MfzptIms3JjZoubEYnkAC4FW
o1oDTrOyPliAC6QBcKXRathZGu9g4Y = VTadWjBloMwXO2CH9GDK6FR*co23tYRNHwpa
DRmUs7l1O4xLeZYzGITXk = mi2ZJXCDzITuyev6gfn(u"࠲࠸৮")*co23tYRNHwpa
ggZJf7YnlXHT3IjtMaWe6S = D9yBM7wPFLz*zKrxu3m2blLZ1QkyCd
taSwGoeiz7mv = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠵࠳৯")*zKrxu3m2blLZ1QkyCd
XlNnqz758Zeuo = yUMRP0QKIzY9BDnsV784TZmwkf(u"࠴࠶ৰ")*f9LwgkGde0atTh
EKMZnHy6FQ1GN7w8 = co23tYRNHwpa
zsJlUtEqYGrVFfw49SLiogAcIxH6a7 = [TDpFsQXHze2q30uYtGPfEIm8(u"ࠫࡇࡕࡋࡓࡃࠪॐ"),E6xdOMpqISHZCn(u"ࠬࡖࡁࡏࡇࡗࠫ॑"),JACnOz297UuDK5HpPkc1LF(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖ॒ࠫ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ॓"),KA26GucUHOwXL(u"ࠨࡋࡉࡍࡑࡓࠧ॔"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡌࡊࡎࡒࡍ࠮ࡃࡕࡅࡇࡏࡃࠨॕ"),cjVhOCwybeRo7UWg92(u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡒࡌࡒࡉࡔࡊࠪॖ")]
zsJlUtEqYGrVFfw49SLiogAcIxH6a7 += [yylSaxCLfkte(u"ࠫ࡞࡚ࡂࡠࡅࡋࡅࡓࡔࡅࡍࡕࠪॗ"),ZP1LyUCS3pIBu(u"ࠬࡇࡋࡐࡃࡐࠫक़"),o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡁࡌ࡙ࡄࡑࠬख़"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧࡂࡎࡐࡅࡆࡘࡅࡇࠩग़"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪज़")]
S6N1p4El7tHw5Ou0vY3CcgAVK = [od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩड़"),mi2ZJXCDzITuyev6gfn(u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭ढ़"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࡙ࠫ࡜ࡆࡖࡐࠪफ़"),HaTI5u1f3SCxmMAkw(u"ࠬࡒࡏࡅ࡛ࡑࡉ࡙࠭य़"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧॠ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧࡔࡊࡄࡌࡎࡊࡎࡆ࡙ࡖࠫॡ"),ZP1LyUCS3pIBu(u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪॢ")]
S6N1p4El7tHw5Ou0vY3CcgAVK += [KA26GucUHOwXL(u"ࠩࡆࡍࡒࡇࡃࡍࡗࡅࠫॣ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ।"),otNfFapeEnO(u"ࠫࡘࡎࡏࡇࡊࡄࠫ॥"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠬ࡝ࡅࡄࡋࡐࡅ࠶࠭०"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠭ࡗࡆࡅࡌࡑࡆ࠸ࠧ१")]
PMZXRmiUl6GtWu3n4gdhpCbxqjJ = [zQGaM7ctZCN(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧ२"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠨࡃ࡜ࡐࡔࡒࠧ३"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࡉࡓࡘ࡚ࡁࠨ४"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࡊࡆࡈࡒࡂࡍࡄࠫ५"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠫ࡞ࡇࡑࡐࡖࠪ६"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ७"),o2FdrDBimMuOw97q6QpNW8S(u"࠭ࡖࡂࡔࡅࡓࡓ࠭८"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡃࡔࡖࡘࡊࡐࠧ९")]
PMZXRmiUl6GtWu3n4gdhpCbxqjJ += [o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡍࡌࡖࡒࡇࡌࡌࠩ॰"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࡄࡒࡎࡓࡅ࡛ࡋࡇࠫॱ"),cjVhOCwybeRo7UWg92(u"ࠪࡊࡆࡘࡅࡔࡍࡒࠫॲ"),cjVhOCwybeRo7UWg92(u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭ॳ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠬࡇࡌࡎࡕࡗࡆࡆ࠭ॴ"),GISOTJh20W(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨॵ"),VVvcQpCU3OM09n(u"ࠧࡅࡔࡄࡑࡆ࡙࠷ࠨॶ")]
PMZXRmiUl6GtWu3n4gdhpCbxqjJ += [JACnOz297UuDK5HpPkc1LF(u"ࠨࡅࡌࡑࡆࡌࡒࡆࡇࠪॷ"),E6xdOMpqISHZCn(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫॸ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠪࡉࡑࡏࡆࡗࡋࡇࡉࡔ࠭ॹ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬॺ"),rC5tnFDlQcRGA2(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨॻ"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧॼ"),otNfFapeEnO(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩॽ")]
PMZXRmiUl6GtWu3n4gdhpCbxqjJ += [ZP1LyUCS3pIBu(u"ࠨࡃࡎ࡛ࡆࡓࡔࡖࡄࡈࠫॾ"),XB4CjMkPFzhAHiI3q(u"ࠩࡐࡅࡘࡇࡖࡊࡆࡈࡓࠬॿ"),VVvcQpCU3OM09n(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭ঀ"),HaTI5u1f3SCxmMAkw(u"ࠫࡋ࡛ࡓࡉࡃࡕࡘ࡛࠭ঁ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡉࡉࡎࡃ࡚ࡆࡆ࡙ࠧং"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࡁࡉ࡙ࡄࡏࠬঃ"),s97s2k0LJgl(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠳ࠩ঄"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬঅ")]
PMZXRmiUl6GtWu3n4gdhpCbxqjJ += [ZP1LyUCS3pIBu(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫআ"),s97s2k0LJgl(u"ࠪࡗࡊࡘࡉࡆࡕࡗࡍࡒࡋࠧই"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩঈ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬউ"),rC5tnFDlQcRGA2(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨঊ"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖ࠴ࠪঋ"),mi2ZJXCDzITuyev6gfn(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠴ࠪঌ"),KA26GucUHOwXL(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠷ࠫ঍")]
ptazrIeX6LC80ysTPwGRng2kxEJ4Z = [cbmeD4WNZfAowxT2JdUMtV(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ঎"),rC5tnFDlQcRGA2(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉ࠲࡜ࡉࡅࡇࡒࡗࠬএ"),E6xdOMpqISHZCn(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡐࡍࡃ࡜ࡐࡎ࡙ࡔࡔࠩঐ"),xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡄࡊࡄࡒࡓࡋࡌࡔࠩ঑")]
ptazrIeX6LC80ysTPwGRng2kxEJ4Z += [o2FdrDBimMuOw97q6QpNW8S(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ঒"),JACnOz297UuDK5HpPkc1LF(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡖࡊࡆࡈࡓࡘ࠭ও"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪঔ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪক"),KA26GucUHOwXL(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡏࡍ࡛ࡋࡓࠨখ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡌࡆ࡙ࡈࡕࡃࡊࡗࠬগ")]
rBou7qEXe4GUPnYMp6Af9yh = [O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡐࡓࡋ࡙ࡅ࡙ࡋࠧঘ")]+zsJlUtEqYGrVFfw49SLiogAcIxH6a7+[pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡎࡋ࡛ࡉࡉ࠭ঙ")]+S6N1p4El7tHw5Ou0vY3CcgAVK+[TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡒࡘࡆࡑࡏࡃࠨচ")]+PMZXRmiUl6GtWu3n4gdhpCbxqjJ+[E6xdOMpqISHZCn(u"ࠩࡓࡖࡎ࡜ࡁࡕࡇࠪছ")]+ptazrIeX6LC80ysTPwGRng2kxEJ4Z
JM3nTBxh0RLCjrFHAtOXqP8UbwDmK = [Olh7n0zfV4(u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩজ")]
TTWgU1m2OydDbSQ7oI5qBh = [rC5tnFDlQcRGA2(u"ࠫࡕࡘࡉࡗࡃࡗࡉࠬঝ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠬࡓࡉ࡙ࡇࡇࠫঞ"),E6xdOMpqISHZCn(u"࠭ࡐࡖࡄࡏࡍࡈ࠭ট")]
CRj9s4Xd1Ti3whZx72LeScbKuva = [rC5tnFDlQcRGA2(u"ࠧࡎ࠵ࡘࠫঠ"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡋࡓࡘ࡛࠭ড"),GISOTJh20W(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧঢ"),otNfFapeEnO(u"ࠪࡍࡋࡏࡌࡎࠩণ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬত")]
feNFL9ocGk  = [s97s2k0LJgl(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪথ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧদ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧধ"),Olh7n0zfV4(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬন"),cjVhOCwybeRo7UWg92(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩ঩")]
feNFL9ocGk += [TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩপ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫফ")]
feNFL9ocGk += [JACnOz297UuDK5HpPkc1LF(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭ব"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪভ"),s97s2k0LJgl(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪম")]
feNFL9ocGk += [E6xdOMpqISHZCn(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫয"),yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧর"),s97s2k0LJgl(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨ঱")]
feNFL9ocGk += [I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ল"),rC5tnFDlQcRGA2(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩ঳"),VVvcQpCU3OM09n(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕࠪ঴")]
A6AyqISGDplHtobOxiY3vrN9E5aW = list(filter(lambda CCdTQs87pLuoFG2ykKXAYU14zgv: CCdTQs87pLuoFG2ykKXAYU14zgv not in feNFL9ocGk+JM3nTBxh0RLCjrFHAtOXqP8UbwDmK+TTWgU1m2OydDbSQ7oI5qBh+CRj9s4Xd1Ti3whZx72LeScbKuva,rBou7qEXe4GUPnYMp6Af9yh))
wt8VeLoQTG2A49pSNF5 = A6AyqISGDplHtobOxiY3vrN9E5aW+CRj9s4Xd1Ti3whZx72LeScbKuva
GzM4fSLbdKhkCTHX01ORYFq9W3P = A6AyqISGDplHtobOxiY3vrN9E5aW+feNFL9ocGk
WZ7itqR9KanXm2cYeGx3dMNTI4 = GzM4fSLbdKhkCTHX01ORYFq9W3P+JM3nTBxh0RLCjrFHAtOXqP8UbwDmK
bXd1yvHnFAG = wt8VeLoQTG2A49pSNF5+JM3nTBxh0RLCjrFHAtOXqP8UbwDmK
ttN9jO4XAVKs5b1i82CqGvxMHQBmYg = [yylSaxCLfkte(u"ࠧࡂࡍࡒࡅࡒ࠭঵"),o2FdrDBimMuOw97q6QpNW8S(u"ࠨࡃࡎ࡛ࡆࡓࠧশ"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡌࡊࡎࡒࡍࠨষ"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭স"),zQGaM7ctZCN(u"ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠭হ"),rC5tnFDlQcRGA2(u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ঺"),VVvcQpCU3OM09n(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ঻"),KA26GucUHOwXL(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨ়"),JACnOz297UuDK5HpPkc1LF(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭ঽ"),Olh7n0zfV4(u"ࠩࡐ࠷࡚࠭া"),zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠪࡍࡕ࡚ࡖࠨি"),EcjO3giln2kQTdBY0XLAG(u"ࠫࡇࡕࡋࡓࡃࠪী"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࡋࡌࡄࡋࡑࡉࡒࡇࠧু"),VVvcQpCU3OM09n(u"࠭ࡁࡓࡃࡅࡍࡈ࡚ࡏࡐࡐࡖࠫূ")]
NOT_TO_TEST_ALL_SERVERS = [GISOTJh20W(u"ࠧࡠࡃࡎࡓࡤ࠭ৃ"),ZP1LyUCS3pIBu(u"ࠨࡡࡄࡏ࡜ࡥࠧৄ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠩࡢࡍࡋࡒ࡟ࠨ৅"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡣࡐࡘࡂࡠࠩ৆"),KA26GucUHOwXL(u"ࠫࡤࡓࡒࡇࡡࠪে"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡥࡓࡉࡏࡢࠫৈ"),rC5tnFDlQcRGA2(u"࠭࡟ࡔࡊ࡙ࡣࠬ৉"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠧࡠ࡛ࡘࡘࡤ࠭৊"),mi2ZJXCDzITuyev6gfn(u"ࠨࡡࡇࡐࡒࡥࠧো"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࡢࡑ࡚࠭ৌ"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠪࡣࡎࡖ্ࠧ"),s97s2k0LJgl(u"ࠫࡤࡈࡋࡓࡡࠪৎ"),yylSaxCLfkte(u"ࠬࡥࡅࡍࡅࡢࠫ৏"),s97s2k0LJgl(u"࠭࡟ࡂࡔࡗࡣࠬ৐")]
d4kl1qU6GQT9tmfeNZMXvYJwDbr8 = [h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࡎࡇࡑ࡙ࡤࡘࡅࡗࡇࡕࡗࡊࡊ࡟ࡑࡇࡕࡑࠬ৑"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡏࡈࡒ࡚ࡥࡁࡔࡅࡈࡒࡉࡋࡄࡠࡒࡈࡖࡒ࠭৒"),EcjO3giln2kQTdBY0XLAG(u"ࠩࡐࡉࡓ࡛࡟ࡅࡇࡖࡇࡊࡔࡄࡆࡆࡢࡔࡊࡘࡍࠨ৓"),yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࡑࡊࡔࡕࡠࡔࡄࡒࡉࡕࡍࡊ࡜ࡈࡈࡤࡖࡅࡓࡏࠪ৔"),JACnOz297UuDK5HpPkc1LF(u"ࠫࡒࡋࡎࡖࡡࡕࡉ࡛ࡋࡒࡔࡇࡇࡣ࡙ࡋࡍࡑࠩ৕"),TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࡤ࡚ࡅࡎࡒࠪ৖"),yylSaxCLfkte(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊ࡟ࡕࡇࡐࡔࠬৗ"),NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠧࡎࡇࡑ࡙ࡤࡘࡁࡏࡆࡒࡑࡎࡠࡅࡅࡡࡗࡉࡒࡖࠧ৘")]
fgbJtiE6ZhV5clxdOj1usX = [ZVNvqy4iF1a9X,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠵࠺࠶ৱ"),EcjO3giln2kQTdBY0XLAG(u"࠶࠼࠰਀"),VVvcQpCU3OM09n(u"࠲࠹࠳ਃ"),XB4CjMkPFzhAHiI3q(u"࠵࠾࠶৸"),E6xdOMpqISHZCn(u"࠲࠷࠲৻"),o2FdrDBimMuOw97q6QpNW8S(u"࠶࠽࠶৿"),TDpFsQXHze2q30uYtGPfEIm8(u"࠸࠹࠰৹"),VVvcQpCU3OM09n(u"࠴࠶࠳ৼ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠹࠷࠰৲"),VVvcQpCU3OM09n(u"࠵࠱࠲ਂ"),GISOTJh20W(u"࠸࠶࠵৷"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠸࠷࠵৾"),ZP1LyUCS3pIBu(u"࠻࠴࠱৺"),KA26GucUHOwXL(u"࠽࠶࠱ਁ"),mi2ZJXCDzITuyev6gfn(u"࠳࠳࠵࠵৶"),s97s2k0LJgl(u"࠺࠻࠼࠴৵"),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠷࠰࠳࠲৳"),JACnOz297UuDK5HpPkc1LF(u"࠱࠱࠺࠳৴"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠳࠴࠴࠵৽")]
qqtVjZsKERH2Jz1kQYnPB = [zQGaM7ctZCN(u"ࠨ࠴࠸࠸ࡩࡪ࠳ࡢ࠶࠳࠽ࡩ࠾ࡢ࠷࠺࠴ࡨ࠹࡫࠱࠲࠹ࡨࡩ࠼࠾ࡣࡦࡤࡩ࠶࠾࠭৙"),I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠩ࠴࠹࠵ࡪ࠲࠳ࡨ࠴࠱ࡨ࠻࠸ࡢ࠯࠷࠴࠷࠷࠭ࡢࡣ࠻࠸࠲࡫࠹࠳࠵ࡦࡥ࡫࠾࠵࠹࠵࠷ࠫ৚"),otNfFapeEnO(u"ࠪ࠷࠾࠿࠱ࡦ࠻ࡦ࠹࠲࠽ࡥࡦ࠵࠰࠸ࡪ࡫࠲࠮࠺࠷ࡧ࠵࠳ࡦࡥ࠹࠼࠶ࡧࡧࡤࡥ࠵ࡧ࠹ࠬ৛"),otNfFapeEnO(u"ࠫ࠼࠼ࡢ࠵ࡨࡦ࠷࠹࡬ࡣࡥ࠳࠼ࡨ࠾ࡩ࠵࠶ࡣ࠴࠹࡫࠹࠶࠱࠶ࡦࡨ࠾࠷࠴ࡤࠩড়"),otNfFapeEnO(u"ࠬ࠷ࡖࡏࡵࡐࡸࡑ࠷࡯ࡃࡔ࡛࡯ࡘࡔࡃࡣࡅࡐࡎ࠶ࡑࡘ࡚ࡌ࡭࡮࠵ࡪࡪ࡛ࡹࠪঢ়"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࠭ࡡ࠵ࡨ࠺ࡪࡧ࠷࠴࠮࠴ࡧࡩ࡫࠳࠴࠱࠹࠴࠱࠽࠼࠴ࡣ࠯࠵࠶ࡪ࠹࠲࠷࠶ࡧ࠸ࡩࡪࡣࠨ৞"),Olh7n0zfV4(u"ࠧ࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࠬয়"),h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨࡥࡦ࠶࠻࠹ࡡࡣ࠳ࡨ࠹࠵࠺࠴ࡥ࠴ࡦࡥ࠺ࡪ࠵ࡥ࠵ࡩ࠽ࡪ࠹ࡣ࠴࠺࠹ࡩࡨࡧ࠱࠲࠲࠻࠷࠽࠿ࡡ࠸࠵ࠪৠ"),VVvcQpCU3OM09n(u"ࠩ࠴ࡧ࠸ࡪ࠳ࡢࡧ࠴࠼࠺ࡪࡦ࠵ࡤࡩ࠺ࡦ࡬࠵࠴࠵ࡦ࠻࠵࠺࠰ࡣ࠵࠷࠻ࡨ࠿ࡥ࠺࠻ࡥࡩ࠹࠼࠶ࡢࡧ࠼ࠫৡ")]
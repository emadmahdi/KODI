# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'LODYNET'
kL0nT7NpZdKVD3jM2OHB = '_LDN_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['الرئيسية','استفسارتكم و الطلبات']
def hH3sRBSFAr(mode,url,text):
	if   mode==450: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==451: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==452: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==453: SD0TxMRXiep4cjPBsnzI = jvfcNeDSnMh1z027lGd4rHm5gP(url)
	elif mode==454: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==459: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LODYNET-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(V4kF6EQiwo,'url')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,459,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'مثبتات لودي نت',dmiXC1cB7MZlb,451,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المضاف حديثا',dmiXC1cB7MZlb,451,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'latest')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"MainMenu"(.*?)"SiteSlider"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if ZgsbN5iSL48t2IhVFnmy=='#': continue
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,451)
	return
def nvHUf8mW6E4GSw5VFRXN(url,Gy3m1diZPVuoMc2hWI6LpN=CJlTSEpZsWb0QHg5w):
	items = []
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LODYNET-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if Gy3m1diZPVuoMc2hWI6LpN=='featured':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"SiteSlider"(.*?)"waves"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	elif Gy3m1diZPVuoMc2hWI6LpN=='latest':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"RecentPosts"(.*?)"pagination"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	elif '"ActorsList"' in bGIVq1CQTjmosZg:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"ActorsList"(.*?)"text/javascript"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif Gy3m1diZPVuoMc2hWI6LpN in ['0','1','2']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"Section"(.*?)</li></ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[int(Gy3m1diZPVuoMc2hWI6LpN)]
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"BlocksArea"(.*?)"text/javascript"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if not items: items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?data-src="(.*?)".*?<h2>(.*?)</h2>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','حلقة','الفيلم']
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if '"ActorsList"' in bGIVq1CQTjmosZg and 'src=' in hzGKUP1XjAoeT79MJcDF:
			hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)"',hzGKUP1XjAoeT79MJcDF,Zy2l0g8QU5vqefaTrsw.DOTALL)
			hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0]
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy).strip('/')
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) حلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not ABK45TEMpciLnmIlYOafQJZ8t: ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if set(title.split()) & set(En3VMwRsiIxPlShtqTdmLpoQ) and 'مسلسل' not in title:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,452,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and 'حلقة' in title:
			title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,453,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif '/category/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,451,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,453,hzGKUP1XjAoeT79MJcDF)
	if Gy3m1diZPVuoMc2hWI6LpN in [CJlTSEpZsWb0QHg5w,'latest']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,451)
	return
def jvfcNeDSnMh1z027lGd4rHm5gP(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LODYNET-SEASONS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"CategorySubLinks"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb and 'href=' in str(hh2VPjs7dkR581KzENYigmpZxLyb):
		title = Zy2l0g8QU5vqefaTrsw.findall('<title>(.*?)-',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		title = title[0].strip(YvOQBzaTAscXR9ql)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,454)
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,454)
	else: j9zTQsrVRx2(url)
	return
def j9zTQsrVRx2(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LODYNET-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"EpisodesList"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc:
		hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('"og:image" content="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0] if hzGKUP1XjAoeT79MJcDF else CJlTSEpZsWb0QHg5w
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,452,hzGKUP1XjAoeT79MJcDF)
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,454)
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ,DIA54R1lwcTz7OZPjX6a = [],[]
	BBwfuWGxUIrdCoc4ka7 = url.replace('/movies/','/watch_movies/')
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.replace('/episodes/','/watch_episodes/')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'LODYNET-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('<iframe src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		if ZgsbN5iSL48t2IhVFnmy not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
			FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__embed'
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"ServersList"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-embed="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if ZgsbN5iSL48t2IhVFnmy in DIA54R1lwcTz7OZPjX6a: continue
			DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"DownloadLinks"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			if ZgsbN5iSL48t2IhVFnmy in DIA54R1lwcTz7OZPjX6a: continue
			DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
			name = wAmsc95ya0LHz(name)
			egYIsS2qROfpVW83kx = Zy2l0g8QU5vqefaTrsw.findall('\d\d\d+',name,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if egYIsS2qROfpVW83kx:
				egYIsS2qROfpVW83kx = '____'+egYIsS2qROfpVW83kx[0]
				name = CJlTSEpZsWb0QHg5w
			else: egYIsS2qROfpVW83kx = CJlTSEpZsWb0QHg5w
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__download'+egYIsS2qROfpVW83kx
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/search/'+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
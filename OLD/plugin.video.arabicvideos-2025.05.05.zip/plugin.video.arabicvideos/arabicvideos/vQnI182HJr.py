# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
Hk0y5BFPUwlGDoiA7pu8 = 'M3U'
fFi12zTm45q8LO3bt7yXDKcagRACp = '_M3U_'
GG6WOtTMvsxwAb = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
vvgwu3AbyMSfLr = 4
def E2yVTSwA9QzkxUNsHKPBb81G(BEUVvSQtRimC,pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T,nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,ZraEU3jpk2ns6q0ztPgvhioAX,sQ3kPfLmHe6W5xUAiY0EKj18GrXnO):
	global fFi12zTm45q8LO3bt7yXDKcagRACp
	try:
		XDsN23oyrzZEGSihUa0W = str(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO['folder'])
		fFi12zTm45q8LO3bt7yXDKcagRACp = '_MU'+XDsN23oyrzZEGSihUa0W+'_'
	except: XDsN23oyrzZEGSihUa0W = CJlTSEpZsWb0QHg5w
	try: Dew1opNVWkiOsY = str(sQ3kPfLmHe6W5xUAiY0EKj18GrXnO['sequence'])
	except: Dew1opNVWkiOsY = CJlTSEpZsWb0QHg5w
	if   BEUVvSQtRimC==710: qTXQ0E8GoMkdI1 = OD492rvCRzZFh1jcf()
	elif BEUVvSQtRimC==711: qTXQ0E8GoMkdI1 = IvlxghompHDr(XDsN23oyrzZEGSihUa0W,Dew1opNVWkiOsY)
	elif BEUVvSQtRimC==712: qTXQ0E8GoMkdI1 = Jt0fg5nDy2rwXKUbmLZu(XDsN23oyrzZEGSihUa0W)
	elif BEUVvSQtRimC==713: qTXQ0E8GoMkdI1 = S8k6PsUIHu3L05T1fB(XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T,ZraEU3jpk2ns6q0ztPgvhioAX)
	elif BEUVvSQtRimC==714: qTXQ0E8GoMkdI1 = fJYhg7Z9iHuRPrUDQWFB(XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T,ZraEU3jpk2ns6q0ztPgvhioAX)
	elif BEUVvSQtRimC==715: qTXQ0E8GoMkdI1 = rHwfOZb3oSgJKi(XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,nnAfhejEKz2luw4UdLVW9OkgMcXIGZ)
	elif BEUVvSQtRimC==716: qTXQ0E8GoMkdI1 = HtVY5QwNBlPJegxuL8Wro6SbjI(XDsN23oyrzZEGSihUa0W,True)
	elif BEUVvSQtRimC==717: qTXQ0E8GoMkdI1 = M3Ts7SXDYcWRpG5ZwgP6vn(XDsN23oyrzZEGSihUa0W,True)
	elif BEUVvSQtRimC==718: qTXQ0E8GoMkdI1 = vBgGrKPu3Aoi6MwZhVTXyH1N(XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,FMxeyLvnzabpJhCXgS6T)
	elif BEUVvSQtRimC==719: qTXQ0E8GoMkdI1 = j5jSfelZXC0UJNR8m3OVI17sq(FMxeyLvnzabpJhCXgS6T,XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,ZraEU3jpk2ns6q0ztPgvhioAX)
	elif BEUVvSQtRimC==720: qTXQ0E8GoMkdI1 = kXTvVPcz07xwBfhnptsW1qaOC(XDsN23oyrzZEGSihUa0W,True)
	elif BEUVvSQtRimC==721: qTXQ0E8GoMkdI1 = jem4PF57gCRLbcVXHrtOSQG8WIi(XDsN23oyrzZEGSihUa0W)
	elif BEUVvSQtRimC==722: qTXQ0E8GoMkdI1 = BNduD0IE4hT2lYGcX7jemxQg6v(XDsN23oyrzZEGSihUa0W)
	elif BEUVvSQtRimC==723: qTXQ0E8GoMkdI1 = tPukapUrfy(XDsN23oyrzZEGSihUa0W)
	elif BEUVvSQtRimC==726: qTXQ0E8GoMkdI1 = V6tQNliUwzB9sYRpZP7HmcIJq(XDsN23oyrzZEGSihUa0W)
	elif BEUVvSQtRimC==729: qTXQ0E8GoMkdI1 = jg5ZqF2hQrLNP(FMxeyLvnzabpJhCXgS6T,XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,ZraEU3jpk2ns6q0ztPgvhioAX)
	else: qTXQ0E8GoMkdI1 = False
	return qTXQ0E8GoMkdI1
def OD492rvCRzZFh1jcf():
	for XDsN23oyrzZEGSihUa0W in range(1,baPq30VI6TOmUnQJ+1):
		fFi12zTm45q8LO3bt7yXDKcagRACp = '_MU'+str(XDsN23oyrzZEGSihUa0W)+'_'
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قائمة مجلد '+gB7j2bpeiCF1v[XDsN23oyrzZEGSihUa0W],CJlTSEpZsWb0QHg5w,720,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	return
def kXTvVPcz07xwBfhnptsW1qaOC(XDsN23oyrzZEGSihUa0W=CJlTSEpZsWb0QHg5w,s7yOo8cH9pXe=CJlTSEpZsWb0QHg5w):
	if XDsN23oyrzZEGSihUa0W:
		NsXK3LBicnmWRIM9vjqTeadHJEC = {'folder':XDsN23oyrzZEGSihUa0W}
		p3ZIxwvBOVT7j4 = CJlTSEpZsWb0QHg5w
	else:
		NsXK3LBicnmWRIM9vjqTeadHJEC = CJlTSEpZsWb0QHg5w
		p3ZIxwvBOVT7j4 = CJlTSEpZsWb0QHg5w
	aB2vqKckE3MQ14FmzyPltfV9b = Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe)
	if not aB2vqKckE3MQ14FmzyPltfV9b:
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+Ym6q5M4TocDaA013RjFQ+' إضافة وتغيير رابط'+p3ZIxwvBOVT7j4+YvOQBzaTAscXR9ql+gB7j2bpeiCF1v[1]+' '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,711,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W,'sequence':1})
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+Ym6q5M4TocDaA013RjFQ+' جلب ملفات'+p3ZIxwvBOVT7j4+' '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,712,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	else:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'بحث في الملفات'+p3ZIxwvBOVT7j4,CJlTSEpZsWb0QHg5w,729,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_',CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات مصنفة مرتبة'+p3ZIxwvBOVT7j4,'LIVE_GROUPED_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات مصنفة من القسم'+p3ZIxwvBOVT7j4,'LIVE_FROM_GROUP_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات مصنفة من الاسم'+p3ZIxwvBOVT7j4,'LIVE_FROM_NAME_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات مصنفة بلا ترتيب'+p3ZIxwvBOVT7j4,'LIVE_GROUPED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات بلا ترتيب'+p3ZIxwvBOVT7j4,'LIVE_ORIGINAL_GROUPED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات مجهولة مرتبة'+p3ZIxwvBOVT7j4,'LIVE_UNKNOWN_GROUPED_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'قنوات مجهولة بلا ترتيب'+p3ZIxwvBOVT7j4,'LIVE_UNKNOWN_GROUPED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'فيديوهات بلا ترتيب'+p3ZIxwvBOVT7j4,'VOD_ORIGINAL_GROUPED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'فيديوهات مصنفة القسم'+p3ZIxwvBOVT7j4,'VOD_FROM_GROUP_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'فيديوهات مصنفة من الاسم'+p3ZIxwvBOVT7j4,'VOD_FROM_NAME_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'فيديوهات مجهولة بلا ترتيب'+p3ZIxwvBOVT7j4,'VOD_UNKNOWN_GROUPED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'فيديوهات مجهولة مرتبة'+p3ZIxwvBOVT7j4,'VOD_UNKNOWN_GROUPED_SORTED',713,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	for bqfWp3z1MOoYy87AKRxH6k in range(1,vvgwu3AbyMSfLr+1):
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+'إضافة وتغيير رابط'+p3ZIxwvBOVT7j4+YvOQBzaTAscXR9ql+gB7j2bpeiCF1v[bqfWp3z1MOoYy87AKRxH6k],CJlTSEpZsWb0QHg5w,711,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W,'sequence':bqfWp3z1MOoYy87AKRxH6k})
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+'جلب ملفات'+p3ZIxwvBOVT7j4,CJlTSEpZsWb0QHg5w,712,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+'مسح ملفات'+p3ZIxwvBOVT7j4,CJlTSEpZsWb0QHg5w,717,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+'عدد فيديوهات'+p3ZIxwvBOVT7j4,CJlTSEpZsWb0QHg5w,721,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+'Referer تغيير'+p3ZIxwvBOVT7j4,CJlTSEpZsWb0QHg5w,726,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+'User-Agent تغيير'+p3ZIxwvBOVT7j4,CJlTSEpZsWb0QHg5w,723,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NsXK3LBicnmWRIM9vjqTeadHJEC)
	return
def HtVY5QwNBlPJegxuL8Wro6SbjI(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe=True):
	Vhg3efDCHGPNlT9S,xDi6lK2tI9fSkWqsyrUcz0AHZunemE = False,CJlTSEpZsWb0QHg5w
	NI4UnfBT3GoMbtp1RldZmHEO6WC0Q,FxrhG2E54YdWwoySRpIDvCm3qAcBaL = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	zT2pK63Bwovnqm90dOR8ijYE,iUdqu4EwMpYV150JPmA6hg2jxtN9bn,Fb4EjvrNwTW,OxWSnPBkYd,CkcsKOzYU9HjnVS6TG2wIiF1 = nguvlGpoHqA4(XDsN23oyrzZEGSihUa0W)
	if OxWSnPBkYd==CJlTSEpZsWb0QHg5w: return False,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	G9olD6cNbsdS = Ndelyjm71ubJakW83UHs4vi2Cr(XDsN23oyrzZEGSihUa0W)
	if zT2pK63Bwovnqm90dOR8ijYE:
		C0q5dOLGD8 = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'GET',zT2pK63Bwovnqm90dOR8ijYE,CJlTSEpZsWb0QHg5w,G9olD6cNbsdS,False,CJlTSEpZsWb0QHg5w,'M3U-CHECK_ACCOUNT-1st')
		fLgxFao7GCIMqj8iw5ucXd4Ov = C0q5dOLGD8.content
		if C0q5dOLGD8.succeeded:
			gg2MlOrvR9WmTn,jdvqG6VSay2FZ,I5CBVKolYGSFt9T6gsHn7,z7rQuZPxYdw5glN392vSyC4ijEoRHK,KqdiAYOCcjh6pbN5 = 0,0,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
			try:
				lJjZIhPaVQqAE5SMo = oE7iT3HI5VDdmY4kPOjr('dict',fLgxFao7GCIMqj8iw5ucXd4Ov)
				xDi6lK2tI9fSkWqsyrUcz0AHZunemE = lJjZIhPaVQqAE5SMo['user_info']['status']
				Vhg3efDCHGPNlT9S = True
				I5CBVKolYGSFt9T6gsHn7 = lJjZIhPaVQqAE5SMo['server_info']['time_now']
			except: pass
			if I5CBVKolYGSFt9T6gsHn7:
				try:
					MMrBGwijONm6o1J = L8Wkv5KCSoq.strptime(I5CBVKolYGSFt9T6gsHn7,'%Y.%m.%d %H:%M:%S')
					gg2MlOrvR9WmTn = int(L8Wkv5KCSoq.mktime(MMrBGwijONm6o1J))
					jdvqG6VSay2FZ = int(U6YgVKS9rAmwe1RTPlQnfiGs-gg2MlOrvR9WmTn)
					jdvqG6VSay2FZ = int((jdvqG6VSay2FZ+900)/1800)*1800
				except: pass
				try:
					MMrBGwijONm6o1J = L8Wkv5KCSoq.localtime(int(lJjZIhPaVQqAE5SMo['user_info']['created_at']))
					z7rQuZPxYdw5glN392vSyC4ijEoRHK = L8Wkv5KCSoq.strftime('%Y.%m.%d %H:%M:%S',MMrBGwijONm6o1J)
				except: pass
				try:
					MMrBGwijONm6o1J = L8Wkv5KCSoq.localtime(int(lJjZIhPaVQqAE5SMo['user_info']['exp_date']))
					KqdiAYOCcjh6pbN5 = L8Wkv5KCSoq.strftime('%Y.%m.%d %H:%M:%S',MMrBGwijONm6o1J)
				except: pass
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.timestamp_'+XDsN23oyrzZEGSihUa0W,str(U6YgVKS9rAmwe1RTPlQnfiGs))
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.timediff_'+XDsN23oyrzZEGSihUa0W,str(jdvqG6VSay2FZ))
			try:
				dTHUyxBipXfFuMltWOs1rRLG9g3 = '"server_info":'+fLgxFao7GCIMqj8iw5ucXd4Ov.split('"server_info":')[1]
				dTHUyxBipXfFuMltWOs1rRLG9g3 = dTHUyxBipXfFuMltWOs1rRLG9g3.replace(':',': ').replace(',',', ').replace('}}','}')
				OJxyez0FWaBKSm9Ili2 = Zy2l0g8QU5vqefaTrsw.findall('"url": "(.*?)", "port": "(.*?)"',dTHUyxBipXfFuMltWOs1rRLG9g3,Zy2l0g8QU5vqefaTrsw.DOTALL)
				NI4UnfBT3GoMbtp1RldZmHEO6WC0Q,FxrhG2E54YdWwoySRpIDvCm3qAcBaL = OJxyez0FWaBKSm9Ili2[0]
			except: Vhg3efDCHGPNlT9S = False
			if Vhg3efDCHGPNlT9S and s7yOo8cH9pXe:
				max = lJjZIhPaVQqAE5SMo['user_info']['max_connections']
				q1uEj2Yx9XPDa7TWVt6Rrvo = lJjZIhPaVQqAE5SMo['user_info']['active_cons']
				DmGNgv3Qx8oHJUAl1edu5tfn6 = lJjZIhPaVQqAE5SMo['user_info']['is_trial']
				l2D6cw4M7trQ1YARB = zT2pK63Bwovnqm90dOR8ijYE.split('?',1)
				LLyhViKbxMntl5JSk = 'URL:  '+Dj62UpP5MrbTkJqhRa+zT2pK63Bwovnqm90dOR8ijYE+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\n\nStatus:  '+Dj62UpP5MrbTkJqhRa+xDi6lK2tI9fSkWqsyrUcz0AHZunemE+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\nTrial:    '+Dj62UpP5MrbTkJqhRa+str(DmGNgv3Qx8oHJUAl1edu5tfn6=='1')+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\nCreated  At:  '+Dj62UpP5MrbTkJqhRa+z7rQuZPxYdw5glN392vSyC4ijEoRHK+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\nExpiry Date:  '+Dj62UpP5MrbTkJqhRa+KqdiAYOCcjh6pbN5+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\nConnections   ( Active / Maximum ) :  '+Dj62UpP5MrbTkJqhRa+q1uEj2Yx9XPDa7TWVt6Rrvo+' / '+max+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\nAllowed Outputs:   '+Dj62UpP5MrbTkJqhRa+" , ".join(lJjZIhPaVQqAE5SMo['user_info']['allowed_output_formats'])+oOQaRxBXyJ5jVnZ
				LLyhViKbxMntl5JSk += '\n\n'+dTHUyxBipXfFuMltWOs1rRLG9g3
				if xDi6lK2tI9fSkWqsyrUcz0AHZunemE=='Active': Jg3XRQ2Tsp1ryEAc4o9BiznbftaIFC('الاشتراك يعمل بدون مشاكل',LLyhViKbxMntl5JSk)
				else: Jg3XRQ2Tsp1ryEAc4o9BiznbftaIFC('يبدو أن هناك مشكلة في الاشتراك',LLyhViKbxMntl5JSk)
	if zT2pK63Bwovnqm90dOR8ijYE and Vhg3efDCHGPNlT9S and xDi6lK2tI9fSkWqsyrUcz0AHZunemE=='Active':
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+zT2pK63Bwovnqm90dOR8ijYE+' ]')
		IKy3WamteYVQgqsR1bEhx = True
	else:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,'Checking M3U URL   [ Does not work ]   [ '+zT2pK63Bwovnqm90dOR8ijYE+' ]')
		if s7yOo8cH9pXe: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		IKy3WamteYVQgqsR1bEhx = False
	return IKy3WamteYVQgqsR1bEhx,NI4UnfBT3GoMbtp1RldZmHEO6WC0Q,FxrhG2E54YdWwoySRpIDvCm3qAcBaL
def fJYhg7Z9iHuRPrUDQWFB(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy,vmP8iNstCT3WX,MhOeCQ2cFwNkg78Ki1DupIUG4H9,s7yOo8cH9pXe=True):
	if not MhOeCQ2cFwNkg78Ki1DupIUG4H9: MhOeCQ2cFwNkg78Ki1DupIUG4H9 = '1'
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe): return
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy)
	rrQkyZUWgOaJlKcC71Eue6VAI = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'list',QcLArCnTFUvdOwKXYGPy,vmP8iNstCT3WX)
	LE2J3ijkv9DBZKr = int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)*100
	QR34JVGupS1tv = LE2J3ijkv9DBZKr-100
	for AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY in rrQkyZUWgOaJlKcC71Eue6VAI[QR34JVGupS1tv:LE2J3ijkv9DBZKr]:
		UK4rRwoJyd2cMkpbeaQG9h = ('GROUPED' in QcLArCnTFUvdOwKXYGPy or QcLArCnTFUvdOwKXYGPy=='ALL')
		cc7oDqyNzf6C = ('GROUPED' not in QcLArCnTFUvdOwKXYGPy and QcLArCnTFUvdOwKXYGPy!='ALL')
		if UK4rRwoJyd2cMkpbeaQG9h or cc7oDqyNzf6C:
			if   'ARCHIVED'  in QcLArCnTFUvdOwKXYGPy: Ew2zQ8u7Ss.menuItemsLIST.append(['folder',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,718,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,'ARCHIVED',CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W}])
			elif 'EPG' 		 in QcLArCnTFUvdOwKXYGPy: Ew2zQ8u7Ss.menuItemsLIST.append(['folder',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,718,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,'FULL_EPG',CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W}])
			elif 'TIMESHIFT' in QcLArCnTFUvdOwKXYGPy: Ew2zQ8u7Ss.menuItemsLIST.append(['folder',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,718,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,'TIMESHIFT',CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W}])
			elif 'LIVE' 	 in QcLArCnTFUvdOwKXYGPy: Ew2zQ8u7Ss.menuItemsLIST.append(['live',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,715,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,AC0yWDME4VSh8rkFXwpGeol6st,{'folder':XDsN23oyrzZEGSihUa0W}])
			else: Ew2zQ8u7Ss.menuItemsLIST.append(['video',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,715,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W}])
	SQIMhV4vz1wfebA7tRoD = len(rrQkyZUWgOaJlKcC71Eue6VAI)
	aFE4IKnmld(XDsN23oyrzZEGSihUa0W,MhOeCQ2cFwNkg78Ki1DupIUG4H9,QcLArCnTFUvdOwKXYGPy,714,SQIMhV4vz1wfebA7tRoD,vmP8iNstCT3WX)
	return
def zcyAfrpWMeFlmh9vEBRgL1Pt8qa(Ka1MEvb0Ogt):
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Ka1MEvb0Ogt+'هذه القائمة إما فارغة أو غير موجودة',CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Ka1MEvb0Ogt+'أو الخدمة غير موجودة في اشتراكك',CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Ka1MEvb0Ogt+'أو رابط M3U الذي أنت أضفته غير صحيح',CJlTSEpZsWb0QHg5w,9999)
	return
def S8k6PsUIHu3L05T1fB(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy,vmP8iNstCT3WX,MhOeCQ2cFwNkg78Ki1DupIUG4H9,Ep9qvuOjIGCgSrT1WmFcx74D=CJlTSEpZsWb0QHg5w,s7yOo8cH9pXe=True):
	if not MhOeCQ2cFwNkg78Ki1DupIUG4H9: MhOeCQ2cFwNkg78Ki1DupIUG4H9 = '1'
	Ka1MEvb0Ogt = fFi12zTm45q8LO3bt7yXDKcagRACp
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe): return False
	if '__SERIES__' in vmP8iNstCT3WX: xFC4lokRcYXpUJrNG8e3,tGUg384rfky9KNoRnmlO = vmP8iNstCT3WX.split('__SERIES__')
	else: xFC4lokRcYXpUJrNG8e3,tGUg384rfky9KNoRnmlO = vmP8iNstCT3WX,CJlTSEpZsWb0QHg5w
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy)
	ZP0iHtScOIKGgLaE4bh7orfweYTj = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'list',QcLArCnTFUvdOwKXYGPy,'__GROUPS__')
	if not ZP0iHtScOIKGgLaE4bh7orfweYTj: return False
	AdcZ8h9Pr0MwUyjtHu4FigvWqnf1O = []
	for LJGSiYW26TnPHo,WC1Bc034gUjih7XZTpKvkEY in ZP0iHtScOIKGgLaE4bh7orfweYTj:
		if '===== ===== =====' in LJGSiYW26TnPHo:
			khqge7BVD9jPFy1S8T5Gn4QAlH('link',Ka1MEvb0Ogt+LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,9999)
			khqge7BVD9jPFy1S8T5Gn4QAlH('link',Ka1MEvb0Ogt+LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,9999)
			continue
		if Ep9qvuOjIGCgSrT1WmFcx74D:
			if '__SERIES__' in LJGSiYW26TnPHo: Ka1MEvb0Ogt = 'SERIES'
			elif '!!__UNKNOWN__!!' in LJGSiYW26TnPHo: Ka1MEvb0Ogt = 'UNKNOWN'
			elif 'LIVE' in QcLArCnTFUvdOwKXYGPy: Ka1MEvb0Ogt = 'LIVE'
			else: Ka1MEvb0Ogt = 'VIDEOS'
			Ka1MEvb0Ogt = ','+Dj62UpP5MrbTkJqhRa+Ka1MEvb0Ogt+': '+oOQaRxBXyJ5jVnZ
		if '__SERIES__' in LJGSiYW26TnPHo: vg8khFrNjD45bPLiKqyVYs2TZxOC,p5XONtjh3WolqLmSkerHMRcfdE9g = LJGSiYW26TnPHo.split('__SERIES__')
		else: vg8khFrNjD45bPLiKqyVYs2TZxOC,p5XONtjh3WolqLmSkerHMRcfdE9g = LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w
		if not vmP8iNstCT3WX:
			if vg8khFrNjD45bPLiKqyVYs2TZxOC in AdcZ8h9Pr0MwUyjtHu4FigvWqnf1O: continue
			AdcZ8h9Pr0MwUyjtHu4FigvWqnf1O.append(vg8khFrNjD45bPLiKqyVYs2TZxOC)
			if 'RANDOM' in Ep9qvuOjIGCgSrT1WmFcx74D: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',Ka1MEvb0Ogt+vg8khFrNjD45bPLiKqyVYs2TZxOC,QcLArCnTFUvdOwKXYGPy,168,CJlTSEpZsWb0QHg5w,'1',LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
			elif '__SERIES__' in LJGSiYW26TnPHo: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',Ka1MEvb0Ogt+vg8khFrNjD45bPLiKqyVYs2TZxOC,QcLArCnTFUvdOwKXYGPy,713,CJlTSEpZsWb0QHg5w,'1',LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',Ka1MEvb0Ogt+vg8khFrNjD45bPLiKqyVYs2TZxOC,QcLArCnTFUvdOwKXYGPy,714,CJlTSEpZsWb0QHg5w,'1',LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
		elif '__SERIES__' in LJGSiYW26TnPHo and vg8khFrNjD45bPLiKqyVYs2TZxOC==xFC4lokRcYXpUJrNG8e3:
			if p5XONtjh3WolqLmSkerHMRcfdE9g in AdcZ8h9Pr0MwUyjtHu4FigvWqnf1O: continue
			AdcZ8h9Pr0MwUyjtHu4FigvWqnf1O.append(p5XONtjh3WolqLmSkerHMRcfdE9g)
			if 'RANDOM' in Ep9qvuOjIGCgSrT1WmFcx74D: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',Ka1MEvb0Ogt+p5XONtjh3WolqLmSkerHMRcfdE9g,QcLArCnTFUvdOwKXYGPy,168,CJlTSEpZsWb0QHg5w,'1',LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',Ka1MEvb0Ogt+p5XONtjh3WolqLmSkerHMRcfdE9g,QcLArCnTFUvdOwKXYGPy,714,WC1Bc034gUjih7XZTpKvkEY,'1',LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	Ew2zQ8u7Ss.menuItemsLIST[:] = sorted(Ew2zQ8u7Ss.menuItemsLIST,reverse=False,key=lambda nnoEs7LuAtHfTMq4dKpvJXbRxkFY9: nnoEs7LuAtHfTMq4dKpvJXbRxkFY9[1].lower())
	if not Ep9qvuOjIGCgSrT1WmFcx74D:
		LE2J3ijkv9DBZKr = int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)*100
		QR34JVGupS1tv = LE2J3ijkv9DBZKr-100
		SQIMhV4vz1wfebA7tRoD = len(Ew2zQ8u7Ss.menuItemsLIST)
		Ew2zQ8u7Ss.menuItemsLIST[:] = Ew2zQ8u7Ss.menuItemsLIST[QR34JVGupS1tv:LE2J3ijkv9DBZKr]
		aFE4IKnmld(XDsN23oyrzZEGSihUa0W,MhOeCQ2cFwNkg78Ki1DupIUG4H9,QcLArCnTFUvdOwKXYGPy,713,SQIMhV4vz1wfebA7tRoD,vmP8iNstCT3WX)
	return True
def vBgGrKPu3Aoi6MwZhVTXyH1N(XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,qRv32XMcGwJatk6pb):
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,True): return
	G9olD6cNbsdS = Ndelyjm71ubJakW83UHs4vi2Cr(XDsN23oyrzZEGSihUa0W)
	gg2MlOrvR9WmTn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.timestamp_'+XDsN23oyrzZEGSihUa0W)
	if not gg2MlOrvR9WmTn or U6YgVKS9rAmwe1RTPlQnfiGs-int(gg2MlOrvR9WmTn)>24*co23tYRNHwpa:
		IKy3WamteYVQgqsR1bEhx,NI4UnfBT3GoMbtp1RldZmHEO6WC0Q,FxrhG2E54YdWwoySRpIDvCm3qAcBaL = HtVY5QwNBlPJegxuL8Wro6SbjI(XDsN23oyrzZEGSihUa0W,False)
		if not IKy3WamteYVQgqsR1bEhx: return
	jdvqG6VSay2FZ = int(ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.timediff_'+XDsN23oyrzZEGSihUa0W))
	Fb4EjvrNwTW = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.server_'+XDsN23oyrzZEGSihUa0W)
	OxWSnPBkYd = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.username_'+XDsN23oyrzZEGSihUa0W)
	CkcsKOzYU9HjnVS6TG2wIiF1 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.password_'+XDsN23oyrzZEGSihUa0W)
	ifCspBPW5yzr40 = pkNZlmhUSwtXgriJHjT59MV1QqK.split('/')
	DDxV5GWnJ16ZoEOY2yRLqj4FNXaQlv = ifCspBPW5yzr40[-1].replace('.ts',CJlTSEpZsWb0QHg5w).replace('.m3u8',CJlTSEpZsWb0QHg5w)
	if qRv32XMcGwJatk6pb=='SHORT_EPG': m4ezd8NVOX163wi5 = 'get_short_epg'
	else: m4ezd8NVOX163wi5 = 'get_simple_data_table'
	zT2pK63Bwovnqm90dOR8ijYE,iUdqu4EwMpYV150JPmA6hg2jxtN9bn,Fb4EjvrNwTW,OxWSnPBkYd,CkcsKOzYU9HjnVS6TG2wIiF1 = nguvlGpoHqA4(XDsN23oyrzZEGSihUa0W)
	if not OxWSnPBkYd: return
	t4tfZ1P6wdlNnqC28Mv3Wj = zT2pK63Bwovnqm90dOR8ijYE+'&action='+m4ezd8NVOX163wi5+'&stream_id='+DDxV5GWnJ16ZoEOY2yRLqj4FNXaQlv
	fLgxFao7GCIMqj8iw5ucXd4Ov = tL8Eg5DiX6zACQue(uhTI2t3wObYqsAi9DCoc,t4tfZ1P6wdlNnqC28Mv3Wj,CJlTSEpZsWb0QHg5w,G9olD6cNbsdS,CJlTSEpZsWb0QHg5w,'M3U-EPG_ITEMS-2nd')
	G8ApwJSlYTEoR3LIrWdnVec = oE7iT3HI5VDdmY4kPOjr('dict',fLgxFao7GCIMqj8iw5ucXd4Ov)
	GheLvyilbt5Fw = G8ApwJSlYTEoR3LIrWdnVec['epg_listings']
	loXUOR1IZdevPCzWwu = []
	if qRv32XMcGwJatk6pb in ['ARCHIVED','TIMESHIFT']:
		for lJjZIhPaVQqAE5SMo in GheLvyilbt5Fw:
			if lJjZIhPaVQqAE5SMo['has_archive']==1:
				loXUOR1IZdevPCzWwu.append(lJjZIhPaVQqAE5SMo)
				if qRv32XMcGwJatk6pb in ['TIMESHIFT']: break
		if not loXUOR1IZdevPCzWwu: return
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+Dj62UpP5MrbTkJqhRa+'الملفات الأولي بهذه القائمة قد لا تعمل'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		if qRv32XMcGwJatk6pb in ['TIMESHIFT']:
			d8d61EuLDtWUQ7jyY3AhN5Hvo = 2
			biIH4S26LFmUjBwTRkJ7 = d8d61EuLDtWUQ7jyY3AhN5Hvo*co23tYRNHwpa
			loXUOR1IZdevPCzWwu = []
			IAPH432OStQWK9hU1eCBwl6fER0LaD = int(int(lJjZIhPaVQqAE5SMo['start_timestamp'])/biIH4S26LFmUjBwTRkJ7)*biIH4S26LFmUjBwTRkJ7
			GGqjV8riMZ = U6YgVKS9rAmwe1RTPlQnfiGs+biIH4S26LFmUjBwTRkJ7
			BhODwEdtWf4jgyKH5om = int((GGqjV8riMZ-IAPH432OStQWK9hU1eCBwl6fER0LaD)/co23tYRNHwpa)
			for oFhapJsiDT4W in range(BhODwEdtWf4jgyKH5om):
				if oFhapJsiDT4W>=6:
					if oFhapJsiDT4W%d8d61EuLDtWUQ7jyY3AhN5Hvo!=0: continue
					jQ3ILDlYFsmcqTKGpvy80aMkP7 = biIH4S26LFmUjBwTRkJ7
				else: jQ3ILDlYFsmcqTKGpvy80aMkP7 = biIH4S26LFmUjBwTRkJ7//2
				SSbxUWyR4pCPfGeV6OmwrQ9gFKL = IAPH432OStQWK9hU1eCBwl6fER0LaD+oFhapJsiDT4W*co23tYRNHwpa
				lJjZIhPaVQqAE5SMo = {}
				lJjZIhPaVQqAE5SMo['title'] = CJlTSEpZsWb0QHg5w
				MMrBGwijONm6o1J = L8Wkv5KCSoq.localtime(SSbxUWyR4pCPfGeV6OmwrQ9gFKL-jdvqG6VSay2FZ-co23tYRNHwpa)
				lJjZIhPaVQqAE5SMo['start'] = L8Wkv5KCSoq.strftime('%Y.%m.%d %H:%M:%S',MMrBGwijONm6o1J)
				lJjZIhPaVQqAE5SMo['start_timestamp'] = str(SSbxUWyR4pCPfGeV6OmwrQ9gFKL)
				lJjZIhPaVQqAE5SMo['stop_timestamp'] = str(SSbxUWyR4pCPfGeV6OmwrQ9gFKL+jQ3ILDlYFsmcqTKGpvy80aMkP7)
				loXUOR1IZdevPCzWwu.append(lJjZIhPaVQqAE5SMo)
	elif qRv32XMcGwJatk6pb in ['SHORT_EPG','FULL_EPG']: loXUOR1IZdevPCzWwu = GheLvyilbt5Fw
	if qRv32XMcGwJatk6pb=='FULL_EPG' and len(loXUOR1IZdevPCzWwu)>0:
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+Dj62UpP5MrbTkJqhRa+'هذه قائمة برامج القنوات (جدول فقط)ـ'+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	Tsg8n4hucfEzo6w2QieXYyU9WqrAM = []
	WC1Bc034gUjih7XZTpKvkEY = pKVikfGen4wMt80UTscxWjAoCZ5S.getInfoLabel('ListItem.Icon')
	for lJjZIhPaVQqAE5SMo in loXUOR1IZdevPCzWwu:
		EDIvQuJecN0X89Klt = qqth6cAFkaRowLlUeMng.b64decode(lJjZIhPaVQqAE5SMo['title'])
		if A7Z6OVh20eCEUx: EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.decode(Im5KSGZYBpRvdMVsbuXg)
		SSbxUWyR4pCPfGeV6OmwrQ9gFKL = int(lJjZIhPaVQqAE5SMo['start_timestamp'])
		TpJLr9sFGagzOiImWdQ2KRqbE = int(lJjZIhPaVQqAE5SMo['stop_timestamp'])
		UCijqf2McmW = str(int((TpJLr9sFGagzOiImWdQ2KRqbE-SSbxUWyR4pCPfGeV6OmwrQ9gFKL+59)/60))
		b8gxTSv97kND = lJjZIhPaVQqAE5SMo['start'].replace(YvOQBzaTAscXR9ql,':')
		MMrBGwijONm6o1J = L8Wkv5KCSoq.localtime(SSbxUWyR4pCPfGeV6OmwrQ9gFKL-co23tYRNHwpa)
		r5EOT3spwbgL89aR0PMZkAHn = L8Wkv5KCSoq.strftime('%H:%M',MMrBGwijONm6o1J)
		Q0rB6d3FnLHJiCjsxk9Nvg2O4EUy7 = L8Wkv5KCSoq.strftime('%a',MMrBGwijONm6o1J)
		if qRv32XMcGwJatk6pb=='SHORT_EPG': EDIvQuJecN0X89Klt = Ym6q5M4TocDaA013RjFQ+r5EOT3spwbgL89aR0PMZkAHn+' ـ '+EDIvQuJecN0X89Klt+oOQaRxBXyJ5jVnZ
		elif qRv32XMcGwJatk6pb=='TIMESHIFT': EDIvQuJecN0X89Klt = Q0rB6d3FnLHJiCjsxk9Nvg2O4EUy7+YvOQBzaTAscXR9ql+r5EOT3spwbgL89aR0PMZkAHn+' ('+UCijqf2McmW+'min)'
		else: EDIvQuJecN0X89Klt = Q0rB6d3FnLHJiCjsxk9Nvg2O4EUy7+YvOQBzaTAscXR9ql+r5EOT3spwbgL89aR0PMZkAHn+' ('+UCijqf2McmW+'min)   '+EDIvQuJecN0X89Klt+' ـ'
		if qRv32XMcGwJatk6pb in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			tj7NWVphe83SzobGJ6B0EkDIfAgiQC = Fb4EjvrNwTW+'/timeshift/'+OxWSnPBkYd+'/'+CkcsKOzYU9HjnVS6TG2wIiF1+'/'+UCijqf2McmW+'/'+b8gxTSv97kND+'/'+DDxV5GWnJ16ZoEOY2yRLqj4FNXaQlv+'.m3u8'
			if qRv32XMcGwJatk6pb=='FULL_EPG': khqge7BVD9jPFy1S8T5Gn4QAlH('link',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,tj7NWVphe83SzobGJ6B0EkDIfAgiQC,9999,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,tj7NWVphe83SzobGJ6B0EkDIfAgiQC,715,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
		Tsg8n4hucfEzo6w2QieXYyU9WqrAM.append(EDIvQuJecN0X89Klt)
	if qRv32XMcGwJatk6pb=='SHORT_EPG' and Tsg8n4hucfEzo6w2QieXYyU9WqrAM: VuZfBhr3DSMNEX615R = EnPV0eZMSNT7ayA2LfFY(Tsg8n4hucfEzo6w2QieXYyU9WqrAM)
	return Tsg8n4hucfEzo6w2QieXYyU9WqrAM
def BNduD0IE4hT2lYGcX7jemxQg6v(XDsN23oyrzZEGSihUa0W):
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,True): return
	Fb4EjvrNwTW,nnby6IoXGO,D5nlTBfIwuRio3V72XdmH9P6EZ = CJlTSEpZsWb0QHg5w,0,0
	IKy3WamteYVQgqsR1bEhx,NI4UnfBT3GoMbtp1RldZmHEO6WC0Q,FxrhG2E54YdWwoySRpIDvCm3qAcBaL = HtVY5QwNBlPJegxuL8Wro6SbjI(XDsN23oyrzZEGSihUa0W,False)
	if IKy3WamteYVQgqsR1bEhx:
		XXaC8vwKiL7gtJfUxuHWyB4 = G1ESvrbxXq(NI4UnfBT3GoMbtp1RldZmHEO6WC0Q)
		nnby6IoXGO = T83nMhxrkQRWmsoIeZJ7g(XXaC8vwKiL7gtJfUxuHWyB4[0],int(FxrhG2E54YdWwoySRpIDvCm3qAcBaL))
		PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,'LIVE_GROUPED')
		WRxXVZAgCy1cvIzepqB = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'list','LIVE_GROUPED')
		rrQkyZUWgOaJlKcC71Eue6VAI = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'list','LIVE_GROUPED',WRxXVZAgCy1cvIzepqB[1])
		pkNZlmhUSwtXgriJHjT59MV1QqK = rrQkyZUWgOaJlKcC71Eue6VAI[0][2]
		ffF3JNDABSY0umwrpTeGL = Zy2l0g8QU5vqefaTrsw.findall('://(.*?)/',pkNZlmhUSwtXgriJHjT59MV1QqK,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ffF3JNDABSY0umwrpTeGL = ffF3JNDABSY0umwrpTeGL[0]
		if ':' in ffF3JNDABSY0umwrpTeGL: k0LxF9XyJ8psTZCMRwUArmoq,Z8ZhMlKb4it = ffF3JNDABSY0umwrpTeGL.split(':')
		else: k0LxF9XyJ8psTZCMRwUArmoq,Z8ZhMlKb4it = ffF3JNDABSY0umwrpTeGL,'80'
		d2uxo9AQaTwr7Uk = G1ESvrbxXq(k0LxF9XyJ8psTZCMRwUArmoq)
		D5nlTBfIwuRio3V72XdmH9P6EZ = T83nMhxrkQRWmsoIeZJ7g(d2uxo9AQaTwr7Uk[0],int(Z8ZhMlKb4it))
	if nnby6IoXGO and D5nlTBfIwuRio3V72XdmH9P6EZ:
		LLyhViKbxMntl5JSk = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		LLyhViKbxMntl5JSk += '\n\n'+'وقت ضائع في السيرفر الأصلي'+rJ9cgWz4FU+str(int(D5nlTBfIwuRio3V72XdmH9P6EZ*1000))+' ملي ثانية'
		LLyhViKbxMntl5JSk += '\n\n'+'وقت ضائع في السيرفر البديل'+rJ9cgWz4FU+str(int(nnby6IoXGO*1000))+' ملي ثانية'
		AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs('center','السيرفر الأصلي','السيرفر الأسرع',TAExSfcoNi4eORZ8HPB,LLyhViKbxMntl5JSk)
		if AAlgwLdnoxXz6G72yibjeEtu==1 and nnby6IoXGO<D5nlTBfIwuRio3V72XdmH9P6EZ: Fb4EjvrNwTW = NI4UnfBT3GoMbtp1RldZmHEO6WC0Q+':'+FxrhG2E54YdWwoySRpIDvCm3qAcBaL
	else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'البرنامج لم يجد السيرفر البديل')
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.server_'+XDsN23oyrzZEGSihUa0W,Fb4EjvrNwTW)
	return
def rHwfOZb3oSgJKi(XDsN23oyrzZEGSihUa0W,pkNZlmhUSwtXgriJHjT59MV1QqK,nnAfhejEKz2luw4UdLVW9OkgMcXIGZ):
	NnifRjgXDsW8m9S4qH = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W)
	wuGF6srviEng1LpCJtXT9 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.referer_'+XDsN23oyrzZEGSihUa0W)
	if NnifRjgXDsW8m9S4qH or wuGF6srviEng1LpCJtXT9:
		pkNZlmhUSwtXgriJHjT59MV1QqK += '|'
		if NnifRjgXDsW8m9S4qH: pkNZlmhUSwtXgriJHjT59MV1QqK += '&User-Agent='+NnifRjgXDsW8m9S4qH
		if wuGF6srviEng1LpCJtXT9: pkNZlmhUSwtXgriJHjT59MV1QqK += '&Referer='+wuGF6srviEng1LpCJtXT9
		pkNZlmhUSwtXgriJHjT59MV1QqK = pkNZlmhUSwtXgriJHjT59MV1QqK.replace('|&','|')
	ZQtv0jY9W6L8UHgpnKm(pkNZlmhUSwtXgriJHjT59MV1QqK,Hk0y5BFPUwlGDoiA7pu8,nnAfhejEKz2luw4UdLVW9OkgMcXIGZ)
	return
def tPukapUrfy(XDsN23oyrzZEGSihUa0W):
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	NnifRjgXDsW8m9S4qH = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W)
	gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs('center','استخدام الأصلي','تعديل القديم',NnifRjgXDsW8m9S4qH,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if gBaEJF2VuN7Sf64twMsPrO1p35z==1: NnifRjgXDsW8m9S4qH = tmMVl2yEWYoRg1LjHfPXGc7wqK0s('أكتب ـM3U User-Agent جديد',NnifRjgXDsW8m9S4qH,True)
	else: NnifRjgXDsW8m9S4qH = 'Unknown'
	if NnifRjgXDsW8m9S4qH==YvOQBzaTAscXR9ql:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NnifRjgXDsW8m9S4qH,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if gBaEJF2VuN7Sf64twMsPrO1p35z!=1:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم الإلغاء')
		return
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W,NnifRjgXDsW8m9S4qH)
	qw7beuI53SoE0jFmRrPtv4MNf(XDsN23oyrzZEGSihUa0W)
	return
def V6tQNliUwzB9sYRpZP7HmcIJq(XDsN23oyrzZEGSihUa0W):
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	wuGF6srviEng1LpCJtXT9 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.referer_'+XDsN23oyrzZEGSihUa0W)
	gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs('center','استخدام الأصلي','تعديل القديم',wuGF6srviEng1LpCJtXT9,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if gBaEJF2VuN7Sf64twMsPrO1p35z==1: wuGF6srviEng1LpCJtXT9 = tmMVl2yEWYoRg1LjHfPXGc7wqK0s('أكتب ـM3U Referer جديد',wuGF6srviEng1LpCJtXT9,True)
	else: wuGF6srviEng1LpCJtXT9 = CJlTSEpZsWb0QHg5w
	if wuGF6srviEng1LpCJtXT9==YvOQBzaTAscXR9ql:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,wuGF6srviEng1LpCJtXT9,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if gBaEJF2VuN7Sf64twMsPrO1p35z!=1:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم الإلغاء')
		return
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.referer_'+XDsN23oyrzZEGSihUa0W,wuGF6srviEng1LpCJtXT9)
	qw7beuI53SoE0jFmRrPtv4MNf(XDsN23oyrzZEGSihUa0W)
	return
def nguvlGpoHqA4(XDsN23oyrzZEGSihUa0W,qIPndfbhwtDNz20Ui4o7axM5L=CJlTSEpZsWb0QHg5w):
	if not chv6EiIgq0axK2AZJtrDNLdGy: chv6EiIgq0axK2AZJtrDNLdGy = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.url_'+XDsN23oyrzZEGSihUa0W)
	Fb4EjvrNwTW = fUSgd7IjGYX496Hr25uFMl(chv6EiIgq0axK2AZJtrDNLdGy,'url')
	OxWSnPBkYd = Zy2l0g8QU5vqefaTrsw.findall('username=(.*?)&',chv6EiIgq0axK2AZJtrDNLdGy+'&',Zy2l0g8QU5vqefaTrsw.DOTALL)
	CkcsKOzYU9HjnVS6TG2wIiF1 = Zy2l0g8QU5vqefaTrsw.findall('password=(.*?)&',chv6EiIgq0axK2AZJtrDNLdGy+'&',Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not OxWSnPBkYd or not CkcsKOzYU9HjnVS6TG2wIiF1:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	OxWSnPBkYd = OxWSnPBkYd[0]
	CkcsKOzYU9HjnVS6TG2wIiF1 = CkcsKOzYU9HjnVS6TG2wIiF1[0]
	zT2pK63Bwovnqm90dOR8ijYE = Fb4EjvrNwTW+'/player_api.php?username='+OxWSnPBkYd+'&password='+CkcsKOzYU9HjnVS6TG2wIiF1
	iUdqu4EwMpYV150JPmA6hg2jxtN9bn = Fb4EjvrNwTW+'/get.php?username='+OxWSnPBkYd+'&password='+CkcsKOzYU9HjnVS6TG2wIiF1+'&type=m3u_plus'
	return zT2pK63Bwovnqm90dOR8ijYE,iUdqu4EwMpYV150JPmA6hg2jxtN9bn,Fb4EjvrNwTW,OxWSnPBkYd,CkcsKOzYU9HjnVS6TG2wIiF1
def XZE5mrxHAyV0h4qW7Bvo8zCpJ(XDsN23oyrzZEGSihUa0W,QvxHXqabN3Vu0ftioAD5wE6K4dlhW=CJlTSEpZsWb0QHg5w):
	FY4zeathO0ClufW = QvxHXqabN3Vu0ftioAD5wE6K4dlhW.replace('/','_').replace(':','_').replace('.','_')
	FY4zeathO0ClufW = FY4zeathO0ClufW.replace('?','_').replace('=','_').replace('&','_')
	FY4zeathO0ClufW = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,FY4zeathO0ClufW).strip('.m3u')+'.m3u'
	return FY4zeathO0ClufW
def IvlxghompHDr(XDsN23oyrzZEGSihUa0W,Dew1opNVWkiOsY):
	ZvGVEz5p3Tw1Iut0rhRoPAKiYC = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.url_'+XDsN23oyrzZEGSihUa0W+'_'+Dew1opNVWkiOsY)
	PfMJkjqbechWQVsdD1GNFyn5Bmr8 = True
	if ZvGVEz5p3Tw1Iut0rhRoPAKiYC:
		gBaEJF2VuN7Sf64twMsPrO1p35z = IUHFoP2MS7n5QBvc3ZthfdN0e('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',Dj62UpP5MrbTkJqhRa+ZvGVEz5p3Tw1Iut0rhRoPAKiYC+oOQaRxBXyJ5jVnZ+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if gBaEJF2VuN7Sf64twMsPrO1p35z==-1: return
		elif gBaEJF2VuN7Sf64twMsPrO1p35z==0: ZvGVEz5p3Tw1Iut0rhRoPAKiYC = CJlTSEpZsWb0QHg5w
		elif gBaEJF2VuN7Sf64twMsPrO1p35z==2:
			gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if gBaEJF2VuN7Sf64twMsPrO1p35z in [-1,0]: return
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم مسح الرابط')
			PfMJkjqbechWQVsdD1GNFyn5Bmr8 = False
			gevIyJwApdbmY74WnzVM3PBfCD6kuO = CJlTSEpZsWb0QHg5w
	if PfMJkjqbechWQVsdD1GNFyn5Bmr8:
		gevIyJwApdbmY74WnzVM3PBfCD6kuO = tmMVl2yEWYoRg1LjHfPXGc7wqK0s('اكتب رابط M3U كاملا',ZvGVEz5p3Tw1Iut0rhRoPAKiYC)
		gevIyJwApdbmY74WnzVM3PBfCD6kuO = gevIyJwApdbmY74WnzVM3PBfCD6kuO.strip(YvOQBzaTAscXR9ql)
		if not gevIyJwApdbmY74WnzVM3PBfCD6kuO:
			gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if gBaEJF2VuN7Sf64twMsPrO1p35z in [-1,0]: return
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم مسح الرابط')
		else:
			LLyhViKbxMntl5JSk = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			gBaEJF2VuN7Sf64twMsPrO1p35z = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'الرابط الجديد هو:',Dj62UpP5MrbTkJqhRa+gevIyJwApdbmY74WnzVM3PBfCD6kuO+oOQaRxBXyJ5jVnZ+'\n\n'+LLyhViKbxMntl5JSk)
			if gBaEJF2VuN7Sf64twMsPrO1p35z!=1:
				PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم الإلغاء')
				return
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.url_'+XDsN23oyrzZEGSihUa0W+'_'+Dew1opNVWkiOsY,gevIyJwApdbmY74WnzVM3PBfCD6kuO)
	NnifRjgXDsW8m9S4qH = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W)
	if not NnifRjgXDsW8m9S4qH: ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W,'Unknown')
	qw7beuI53SoE0jFmRrPtv4MNf(XDsN23oyrzZEGSihUa0W)
	return
def ANqlLnKkS5Pm6sYXrH4zbRGBQT1C(ww2nEWifbsVO4rMkHAgevcRP,b1bayYVQsFZE40,IqGFD8YjV0HOPkZx,fcjphRrZaOnYKwW5C4gAXN9DltI,nOudwaDECF,ziNeUR6gHltVW,iUdqu4EwMpYV150JPmA6hg2jxtN9bn):
	rrQkyZUWgOaJlKcC71Eue6VAI,mpbSNAWuexRZdlvfc0HoIngEijh = [],[]
	FyOg5XPfVevbwI0ZhKaro = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
		if ziNeUR6gHltVW%473==0:
			KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,40+int(10*ziNeUR6gHltVW/nOudwaDECF),'قراءة الفيديوهات','الفيديو رقم:-',str(ziNeUR6gHltVW)+' / '+str(nOudwaDECF))
			if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
				fcjphRrZaOnYKwW5C4gAXN9DltI.close()
				return None,None,None
		pkNZlmhUSwtXgriJHjT59MV1QqK = Zy2l0g8QU5vqefaTrsw.findall('^(.*?)\n+((http|https|rtmp).*?)$',LowSfEj9cH,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if pkNZlmhUSwtXgriJHjT59MV1QqK:
			LowSfEj9cH,pkNZlmhUSwtXgriJHjT59MV1QqK,z7PfyvHhJWqs8Fl = pkNZlmhUSwtXgriJHjT59MV1QqK[0]
			pkNZlmhUSwtXgriJHjT59MV1QqK = pkNZlmhUSwtXgriJHjT59MV1QqK.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w)
			LowSfEj9cH = LowSfEj9cH.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w)
		else:
			mpbSNAWuexRZdlvfc0HoIngEijh.append({'line':LowSfEj9cH})
			continue
		drKWv2Dzuxnm4p,AC0yWDME4VSh8rkFXwpGeol6st,LJGSiYW26TnPHo,EDIvQuJecN0X89Klt,nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,SnVP63cIjgep95NXqF7KsZvMm = {},CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,False
		try:
			LowSfEj9cH,EDIvQuJecN0X89Klt = LowSfEj9cH.rsplit('",',1)
			LowSfEj9cH = LowSfEj9cH+'"'
		except:
			try: LowSfEj9cH,EDIvQuJecN0X89Klt = LowSfEj9cH.rsplit('1,',1)
			except: EDIvQuJecN0X89Klt = CJlTSEpZsWb0QHg5w
		drKWv2Dzuxnm4p['url'] = pkNZlmhUSwtXgriJHjT59MV1QqK
		NNlwDRQuXCH2POUWB = Zy2l0g8QU5vqefaTrsw.findall(' (.*?)="(.*?)"',LowSfEj9cH,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for nnoEs7LuAtHfTMq4dKpvJXbRxkFY9,iOGS6EWr13ewPKpU4CD9d8Y2R in NNlwDRQuXCH2POUWB:
			nnoEs7LuAtHfTMq4dKpvJXbRxkFY9 = nnoEs7LuAtHfTMq4dKpvJXbRxkFY9.replace('"',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			drKWv2Dzuxnm4p[nnoEs7LuAtHfTMq4dKpvJXbRxkFY9] = iOGS6EWr13ewPKpU4CD9d8Y2R.strip(YvOQBzaTAscXR9ql)
		atxfMF5eVQBj3PH0oRqJIibK4OwSnA = list(drKWv2Dzuxnm4p.keys())
		if not EDIvQuJecN0X89Klt:
			if 'name' in atxfMF5eVQBj3PH0oRqJIibK4OwSnA and drKWv2Dzuxnm4p['name']: EDIvQuJecN0X89Klt = drKWv2Dzuxnm4p['name']
		drKWv2Dzuxnm4p['title'] = EDIvQuJecN0X89Klt.strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		if 'logo' in atxfMF5eVQBj3PH0oRqJIibK4OwSnA:
			drKWv2Dzuxnm4p['img'] = drKWv2Dzuxnm4p['logo']
			del drKWv2Dzuxnm4p['logo']
		else: drKWv2Dzuxnm4p['img'] = CJlTSEpZsWb0QHg5w
		if 'group' in atxfMF5eVQBj3PH0oRqJIibK4OwSnA and drKWv2Dzuxnm4p['group']: LJGSiYW26TnPHo = drKWv2Dzuxnm4p['group']
		if any(value in pkNZlmhUSwtXgriJHjT59MV1QqK.lower() for value in FyOg5XPfVevbwI0ZhKaro):
			SnVP63cIjgep95NXqF7KsZvMm = True if 'm3u' not in pkNZlmhUSwtXgriJHjT59MV1QqK else False
		if SnVP63cIjgep95NXqF7KsZvMm or '__SERIES__' in LJGSiYW26TnPHo or '__MOVIES__' in LJGSiYW26TnPHo:
			nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = 'VOD'
			if '__SERIES__' in LJGSiYW26TnPHo: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ+'_SERIES'
			elif '__MOVIES__' in LJGSiYW26TnPHo: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ+'_MOVIES'
			else: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ+'_UNKNOWN'
			LJGSiYW26TnPHo = LJGSiYW26TnPHo.replace('__SERIES__',CJlTSEpZsWb0QHg5w).replace('__MOVIES__',CJlTSEpZsWb0QHg5w)
		else:
			nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = 'LIVE'
			if EDIvQuJecN0X89Klt in b1bayYVQsFZE40: AC0yWDME4VSh8rkFXwpGeol6st = AC0yWDME4VSh8rkFXwpGeol6st+'_EPG'
			if EDIvQuJecN0X89Klt in IqGFD8YjV0HOPkZx: AC0yWDME4VSh8rkFXwpGeol6st = AC0yWDME4VSh8rkFXwpGeol6st+'_ARCHIVED'
			if not LJGSiYW26TnPHo: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ+'_UNKNOWN'
			else: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ+AC0yWDME4VSh8rkFXwpGeol6st
		LJGSiYW26TnPHo = LJGSiYW26TnPHo.strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		if 'LIVE_UNKNOWN' in nnAfhejEKz2luw4UdLVW9OkgMcXIGZ: LJGSiYW26TnPHo = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in nnAfhejEKz2luw4UdLVW9OkgMcXIGZ: LJGSiYW26TnPHo = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in nnAfhejEKz2luw4UdLVW9OkgMcXIGZ:
			zlbKJ56OEnD1i8g3qT0YoRwUum = Zy2l0g8QU5vqefaTrsw.findall('(.*?) [Ss]\d+ +[Ee]\d+',drKWv2Dzuxnm4p['title'],Zy2l0g8QU5vqefaTrsw.DOTALL)
			if zlbKJ56OEnD1i8g3qT0YoRwUum: zlbKJ56OEnD1i8g3qT0YoRwUum = zlbKJ56OEnD1i8g3qT0YoRwUum[0]
			else: zlbKJ56OEnD1i8g3qT0YoRwUum = '!!__UNKNOWN_SERIES__!!'
			LJGSiYW26TnPHo = LJGSiYW26TnPHo+'__SERIES__'+zlbKJ56OEnD1i8g3qT0YoRwUum
		if 'id' in atxfMF5eVQBj3PH0oRqJIibK4OwSnA: del drKWv2Dzuxnm4p['id']
		if 'ID' in atxfMF5eVQBj3PH0oRqJIibK4OwSnA: del drKWv2Dzuxnm4p['ID']
		if 'name' in atxfMF5eVQBj3PH0oRqJIibK4OwSnA: del drKWv2Dzuxnm4p['name']
		EDIvQuJecN0X89Klt = drKWv2Dzuxnm4p['title']
		EDIvQuJecN0X89Klt = pd0Na8D5WZfHYkysVS(EDIvQuJecN0X89Klt)
		EDIvQuJecN0X89Klt = GoShBIaAyT(EDIvQuJecN0X89Klt)
		mGAUwEVCv5PobM,LJGSiYW26TnPHo = HSovFgetaXDq3M5fnjI1xC8967TuY0(LJGSiYW26TnPHo)
		N3BsVznDoKaPQZFImbJ,EDIvQuJecN0X89Klt = HSovFgetaXDq3M5fnjI1xC8967TuY0(EDIvQuJecN0X89Klt)
		drKWv2Dzuxnm4p['type'] = nnAfhejEKz2luw4UdLVW9OkgMcXIGZ
		drKWv2Dzuxnm4p['context'] = AC0yWDME4VSh8rkFXwpGeol6st
		drKWv2Dzuxnm4p['group'] = LJGSiYW26TnPHo.upper()
		drKWv2Dzuxnm4p['title'] = EDIvQuJecN0X89Klt.upper()
		drKWv2Dzuxnm4p['country'] = N3BsVznDoKaPQZFImbJ.upper()
		drKWv2Dzuxnm4p['language'] = mGAUwEVCv5PobM.upper()
		rrQkyZUWgOaJlKcC71Eue6VAI.append(drKWv2Dzuxnm4p)
		ziNeUR6gHltVW += 1
	return rrQkyZUWgOaJlKcC71Eue6VAI,ziNeUR6gHltVW,mpbSNAWuexRZdlvfc0HoIngEijh
def GoShBIaAyT(EDIvQuJecN0X89Klt):
	EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.replace('||','|').replace('___',':').replace('--','-')
	EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.replace('[[','[').replace(']]',']')
	EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.replace('((','(').replace('))',')')
	EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.replace('<<','<').replace('>>','>')
	EDIvQuJecN0X89Klt = EDIvQuJecN0X89Klt.strip(YvOQBzaTAscXR9ql)
	return EDIvQuJecN0X89Klt
def XWzdE9r67NlqkA0oDHMmFeI(Gq3SkiBZ5Mh7OrClnREdYemg,fcjphRrZaOnYKwW5C4gAXN9DltI,Dew1opNVWkiOsY):
	Ita2xUfiMSeuTP4sjQo6 = {}
	for FiZSRg2lbdOPtkaMKI8U4Vs in GG6WOtTMvsxwAb: Ita2xUfiMSeuTP4sjQo6[FiZSRg2lbdOPtkaMKI8U4Vs+'_'+Dew1opNVWkiOsY] = []
	nOudwaDECF = len(Gq3SkiBZ5Mh7OrClnREdYemg)
	Wn9YNC6SIsb3P7Lg8 = str(nOudwaDECF)
	ziNeUR6gHltVW = 0
	mpbSNAWuexRZdlvfc0HoIngEijh = []
	for drKWv2Dzuxnm4p in Gq3SkiBZ5Mh7OrClnREdYemg:
		if ziNeUR6gHltVW%873==0:
			KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,50+int(5*ziNeUR6gHltVW/nOudwaDECF),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(ziNeUR6gHltVW)+' / '+Wn9YNC6SIsb3P7Lg8)
			if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
				fcjphRrZaOnYKwW5C4gAXN9DltI.close()
				return None,None
		LJGSiYW26TnPHo,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY = drKWv2Dzuxnm4p['group'],drKWv2Dzuxnm4p['context'],drKWv2Dzuxnm4p['title'],drKWv2Dzuxnm4p['url'],drKWv2Dzuxnm4p['img']
		N3BsVznDoKaPQZFImbJ,mGAUwEVCv5PobM,FiZSRg2lbdOPtkaMKI8U4Vs = drKWv2Dzuxnm4p['country'],drKWv2Dzuxnm4p['language'],drKWv2Dzuxnm4p['type']
		ooDv7eYjgOMlf1y24nQBb6uskA = (LJGSiYW26TnPHo,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY)
		vjNRX3Fo08D6kiTPqwnJ2cdlmU = False
		if 'LIVE' in FiZSRg2lbdOPtkaMKI8U4Vs:
			if 'UNKNOWN' in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['LIVE_UNKNOWN_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			elif 'LIVE' in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['LIVE_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			else: vjNRX3Fo08D6kiTPqwnJ2cdlmU = True
			Ita2xUfiMSeuTP4sjQo6['LIVE_ORIGINAL_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
		elif 'VOD' in FiZSRg2lbdOPtkaMKI8U4Vs:
			if 'UNKNOWN' in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['VOD_UNKNOWN_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			elif 'MOVIES' in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['VOD_MOVIES_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			elif 'SERIES' in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['VOD_SERIES_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			else: vjNRX3Fo08D6kiTPqwnJ2cdlmU = True
			Ita2xUfiMSeuTP4sjQo6['VOD_ORIGINAL_GROUPED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
		else: vjNRX3Fo08D6kiTPqwnJ2cdlmU = True
		if vjNRX3Fo08D6kiTPqwnJ2cdlmU: mpbSNAWuexRZdlvfc0HoIngEijh.append(drKWv2Dzuxnm4p)
		ziNeUR6gHltVW += 1
	jjxhi1QIEkT = sorted(Gq3SkiBZ5Mh7OrClnREdYemg,reverse=False,key=lambda nnoEs7LuAtHfTMq4dKpvJXbRxkFY9: nnoEs7LuAtHfTMq4dKpvJXbRxkFY9['title'].lower())
	del Gq3SkiBZ5Mh7OrClnREdYemg
	Wn9YNC6SIsb3P7Lg8 = str(nOudwaDECF)
	ziNeUR6gHltVW = 0
	for drKWv2Dzuxnm4p in jjxhi1QIEkT:
		ziNeUR6gHltVW += 1
		if ziNeUR6gHltVW%873==0:
			KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,55+int(5*ziNeUR6gHltVW/nOudwaDECF),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(ziNeUR6gHltVW)+' / '+Wn9YNC6SIsb3P7Lg8)
			if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
				fcjphRrZaOnYKwW5C4gAXN9DltI.close()
				return None,None
		FiZSRg2lbdOPtkaMKI8U4Vs = drKWv2Dzuxnm4p['type']
		LJGSiYW26TnPHo,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY = drKWv2Dzuxnm4p['group'],drKWv2Dzuxnm4p['context'],drKWv2Dzuxnm4p['title'],drKWv2Dzuxnm4p['url'],drKWv2Dzuxnm4p['img']
		N3BsVznDoKaPQZFImbJ,mGAUwEVCv5PobM = drKWv2Dzuxnm4p['country'],drKWv2Dzuxnm4p['language']
		HHnRSdFb1iJ = (LJGSiYW26TnPHo,AC0yWDME4VSh8rkFXwpGeol6st+'_TIMESHIFT',EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY)
		ooDv7eYjgOMlf1y24nQBb6uskA = (LJGSiYW26TnPHo,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY)
		XK89odyO2u5zA1LpDSMnNfW = (N3BsVznDoKaPQZFImbJ,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY)
		DPJiFyQfh9UHtLlToMeO = (mGAUwEVCv5PobM,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY)
		if 'LIVE' in FiZSRg2lbdOPtkaMKI8U4Vs:
			if 'UNKNOWN' in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['LIVE_UNKNOWN_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			else: Ita2xUfiMSeuTP4sjQo6['LIVE_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			if 'EPG'		in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['LIVE_EPG_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			if 'ARCHIVED'	in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['LIVE_ARCHIVED_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			if 'ARCHIVED'	in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['LIVE_TIMESHIFT_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(HHnRSdFb1iJ)
			Ita2xUfiMSeuTP4sjQo6['LIVE_FROM_NAME_SORTED_'+Dew1opNVWkiOsY].append(XK89odyO2u5zA1LpDSMnNfW)
			Ita2xUfiMSeuTP4sjQo6['LIVE_FROM_GROUP_SORTED_'+Dew1opNVWkiOsY].append(DPJiFyQfh9UHtLlToMeO)
		elif 'VOD' in FiZSRg2lbdOPtkaMKI8U4Vs:
			if   'UNKNOWN'	in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['VOD_UNKNOWN_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			elif 'MOVIES'	in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['VOD_MOVIES_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			elif 'SERIES'	in FiZSRg2lbdOPtkaMKI8U4Vs: Ita2xUfiMSeuTP4sjQo6['VOD_SERIES_GROUPED_SORTED_'+Dew1opNVWkiOsY].append(ooDv7eYjgOMlf1y24nQBb6uskA)
			Ita2xUfiMSeuTP4sjQo6['VOD_FROM_NAME_SORTED_'+Dew1opNVWkiOsY].append(XK89odyO2u5zA1LpDSMnNfW)
			Ita2xUfiMSeuTP4sjQo6['VOD_FROM_GROUP_SORTED_'+Dew1opNVWkiOsY].append(DPJiFyQfh9UHtLlToMeO)
	return Ita2xUfiMSeuTP4sjQo6,mpbSNAWuexRZdlvfc0HoIngEijh
def HSovFgetaXDq3M5fnjI1xC8967TuY0(EDIvQuJecN0X89Klt):
	if len(EDIvQuJecN0X89Klt)<3: return EDIvQuJecN0X89Klt,EDIvQuJecN0X89Klt
	zsxHGU053Zlr4kNCdE,nndlWxXsTQ5aiMVe4SAb7 = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	oEX9hU1wp07AI3iFYC4Bk5MdQJxrG = EDIvQuJecN0X89Klt
	NN1iHZDRCzUOq = EDIvQuJecN0X89Klt[:1]
	GzUj2wlR3dtE9fL5FrV7vaxTC = EDIvQuJecN0X89Klt[1:]
	if   NN1iHZDRCzUOq=='(': nndlWxXsTQ5aiMVe4SAb7 = ')'
	elif NN1iHZDRCzUOq=='[': nndlWxXsTQ5aiMVe4SAb7 = ']'
	elif NN1iHZDRCzUOq=='<': nndlWxXsTQ5aiMVe4SAb7 = '>'
	elif NN1iHZDRCzUOq=='|': nndlWxXsTQ5aiMVe4SAb7 = '|'
	if nndlWxXsTQ5aiMVe4SAb7 and (nndlWxXsTQ5aiMVe4SAb7 in GzUj2wlR3dtE9fL5FrV7vaxTC):
		S5DAMebUd7,Z8uQd2qSw5nOfsYzUN = GzUj2wlR3dtE9fL5FrV7vaxTC.split(nndlWxXsTQ5aiMVe4SAb7,1)
		zsxHGU053Zlr4kNCdE = S5DAMebUd7
		oEX9hU1wp07AI3iFYC4Bk5MdQJxrG = NN1iHZDRCzUOq+S5DAMebUd7+nndlWxXsTQ5aiMVe4SAb7+YvOQBzaTAscXR9ql+Z8uQd2qSw5nOfsYzUN
	elif EDIvQuJecN0X89Klt.count('|')>=2:
		S5DAMebUd7,Z8uQd2qSw5nOfsYzUN = EDIvQuJecN0X89Klt.split('|',1)
		zsxHGU053Zlr4kNCdE = S5DAMebUd7
		oEX9hU1wp07AI3iFYC4Bk5MdQJxrG = S5DAMebUd7+' |'+Z8uQd2qSw5nOfsYzUN
	else:
		nndlWxXsTQ5aiMVe4SAb7 = Zy2l0g8QU5vqefaTrsw.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',EDIvQuJecN0X89Klt,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not nndlWxXsTQ5aiMVe4SAb7: nndlWxXsTQ5aiMVe4SAb7 = Zy2l0g8QU5vqefaTrsw.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',EDIvQuJecN0X89Klt,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not nndlWxXsTQ5aiMVe4SAb7: nndlWxXsTQ5aiMVe4SAb7 = Zy2l0g8QU5vqefaTrsw.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',EDIvQuJecN0X89Klt,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if nndlWxXsTQ5aiMVe4SAb7:
			S5DAMebUd7,Z8uQd2qSw5nOfsYzUN = EDIvQuJecN0X89Klt.split(nndlWxXsTQ5aiMVe4SAb7[0],1)
			zsxHGU053Zlr4kNCdE = S5DAMebUd7
			oEX9hU1wp07AI3iFYC4Bk5MdQJxrG = S5DAMebUd7+YvOQBzaTAscXR9ql+nndlWxXsTQ5aiMVe4SAb7[0]+YvOQBzaTAscXR9ql+Z8uQd2qSw5nOfsYzUN
	oEX9hU1wp07AI3iFYC4Bk5MdQJxrG = oEX9hU1wp07AI3iFYC4Bk5MdQJxrG.replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	zsxHGU053Zlr4kNCdE = zsxHGU053Zlr4kNCdE.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	if not zsxHGU053Zlr4kNCdE: zsxHGU053Zlr4kNCdE = '!!__UNKNOWN__!!'
	zsxHGU053Zlr4kNCdE = zsxHGU053Zlr4kNCdE.strip(YvOQBzaTAscXR9ql)
	oEX9hU1wp07AI3iFYC4Bk5MdQJxrG = oEX9hU1wp07AI3iFYC4Bk5MdQJxrG.strip(YvOQBzaTAscXR9ql)
	return zsxHGU053Zlr4kNCdE,oEX9hU1wp07AI3iFYC4Bk5MdQJxrG
def Ndelyjm71ubJakW83UHs4vi2Cr(XDsN23oyrzZEGSihUa0W):
	G9olD6cNbsdS = {}
	NnifRjgXDsW8m9S4qH = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W)
	if NnifRjgXDsW8m9S4qH: G9olD6cNbsdS['User-Agent'] = NnifRjgXDsW8m9S4qH
	wuGF6srviEng1LpCJtXT9 = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.referer_'+XDsN23oyrzZEGSihUa0W)
	if wuGF6srviEng1LpCJtXT9: G9olD6cNbsdS['Referer'] = wuGF6srviEng1LpCJtXT9
	return G9olD6cNbsdS
def uuYfDRegStjKQldXmBvN0(XDsN23oyrzZEGSihUa0W,Dew1opNVWkiOsY):
	global fcjphRrZaOnYKwW5C4gAXN9DltI,Ita2xUfiMSeuTP4sjQo6,iOvDaIlQRcYjGqf0MLC7xWz,eh3BJmSlUvWd7z28H1ou9jwIPa,in1QCUOD23xmTRylG4YVuoWPNbS8,WRxXVZAgCy1cvIzepqB,WRuCeZVaX1iflscGNSJ70M5j2PD,AK9iq3XYlvG,IsHoBhjrv6Vz04LF
	iUdqu4EwMpYV150JPmA6hg2jxtN9bn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.url_'+XDsN23oyrzZEGSihUa0W+'_'+Dew1opNVWkiOsY)
	NnifRjgXDsW8m9S4qH = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.useragent_'+XDsN23oyrzZEGSihUa0W)
	G9olD6cNbsdS = {'User-Agent':NnifRjgXDsW8m9S4qH}
	FY4zeathO0ClufW = oSVWcP6bX0mYFZi.replace('___','_'+XDsN23oyrzZEGSihUa0W+'_'+Dew1opNVWkiOsY)
	if 1:
		IKy3WamteYVQgqsR1bEhx,NI4UnfBT3GoMbtp1RldZmHEO6WC0Q,FxrhG2E54YdWwoySRpIDvCm3qAcBaL = True,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
		if not IKy3WamteYVQgqsR1bEhx:
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not iUdqu4EwMpYV150JPmA6hg2jxtN9bn: JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+'   No M3U URL found to download M3U files')
			else: JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(Hk0y5BFPUwlGDoiA7pu8)+'   Failed to download M3U files')
			return
		q3yVCYoDS4hK = AznaIjR5kDMBf(iUdqu4EwMpYV150JPmA6hg2jxtN9bn,G9olD6cNbsdS,True)
		if not q3yVCYoDS4hK: return
		open(FY4zeathO0ClufW,'wb').write(q3yVCYoDS4hK)
	else: q3yVCYoDS4hK = open(FY4zeathO0ClufW,'rb').read()
	if A7Z6OVh20eCEUx and q3yVCYoDS4hK: q3yVCYoDS4hK = q3yVCYoDS4hK.decode(Im5KSGZYBpRvdMVsbuXg)
	fcjphRrZaOnYKwW5C4gAXN9DltI = lkPKsYmp4UjR()
	fcjphRrZaOnYKwW5C4gAXN9DltI.create('جلب ملفات M3U جديدة',CJlTSEpZsWb0QHg5w)
	KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,15,'تنظيف الملف الرئيسي',CJlTSEpZsWb0QHg5w)
	q3yVCYoDS4hK = q3yVCYoDS4hK.replace('"tvg-','" tvg-')
	q3yVCYoDS4hK = q3yVCYoDS4hK.replace('َ',CJlTSEpZsWb0QHg5w).replace('ً',CJlTSEpZsWb0QHg5w).replace('ُ',CJlTSEpZsWb0QHg5w).replace('ٌ',CJlTSEpZsWb0QHg5w)
	q3yVCYoDS4hK = q3yVCYoDS4hK.replace('ّ',CJlTSEpZsWb0QHg5w).replace('ِ',CJlTSEpZsWb0QHg5w).replace('ٍ',CJlTSEpZsWb0QHg5w).replace('ْ',CJlTSEpZsWb0QHg5w)
	q3yVCYoDS4hK = q3yVCYoDS4hK.replace('group-title=','group=').replace('tvg-',CJlTSEpZsWb0QHg5w)
	IqGFD8YjV0HOPkZx,b1bayYVQsFZE40 = [],[]
	q3yVCYoDS4hK = q3yVCYoDS4hK.replace(rScptJWVdgzQGR1E3LZ9byC,rJ9cgWz4FU)
	ww2nEWifbsVO4rMkHAgevcRP = Zy2l0g8QU5vqefaTrsw.findall('NF:(.+?)'+'#'+'EXTI',q3yVCYoDS4hK+'\n+'+'#'+'EXTINF:',Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not ww2nEWifbsVO4rMkHAgevcRP:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(Hk0y5BFPUwlGDoiA7pu8)+'   Folder:'+XDsN23oyrzZEGSihUa0W+'  Sequence:'+Dew1opNVWkiOsY+'   No video links found in M3U file')
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+rJ9cgWz4FU+Ym6q5M4TocDaA013RjFQ+'مجلد رقم '+XDsN23oyrzZEGSihUa0W+'      رابط رقم '+Dew1opNVWkiOsY+oOQaRxBXyJ5jVnZ)
		fcjphRrZaOnYKwW5C4gAXN9DltI.close()
		return
	fAOTjq2utEZX6N = []
	for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
		ewaTFEgb3iZom = LowSfEj9cH.lower()
		if 'adult' in ewaTFEgb3iZom: continue
		if 'xxx' in ewaTFEgb3iZom: continue
		fAOTjq2utEZX6N.append(LowSfEj9cH)
	ww2nEWifbsVO4rMkHAgevcRP = fAOTjq2utEZX6N
	del fAOTjq2utEZX6N
	if 'iptv-org' in iUdqu4EwMpYV150JPmA6hg2jxtN9bn:
		fAOTjq2utEZX6N,YAqywGj1PJTCOI429Ffmep = [],[]
		for LowSfEj9cH in ww2nEWifbsVO4rMkHAgevcRP:
			WRxXVZAgCy1cvIzepqB = Zy2l0g8QU5vqefaTrsw.findall('group="(.*?)"',LowSfEj9cH,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if WRxXVZAgCy1cvIzepqB:
				WRxXVZAgCy1cvIzepqB = WRxXVZAgCy1cvIzepqB[0]
				oQA7XVPiGwbNq0hktDT = WRxXVZAgCy1cvIzepqB.split(';')
				if 'region' in iUdqu4EwMpYV150JPmA6hg2jxtN9bn: BJxvSRlZbsIw80Drh6i1Y3HoNt4 = '1_'
				elif 'category' in iUdqu4EwMpYV150JPmA6hg2jxtN9bn: BJxvSRlZbsIw80Drh6i1Y3HoNt4 = '2_'
				elif 'language' in iUdqu4EwMpYV150JPmA6hg2jxtN9bn: BJxvSRlZbsIw80Drh6i1Y3HoNt4 = '3_'
				elif 'country' in iUdqu4EwMpYV150JPmA6hg2jxtN9bn: BJxvSRlZbsIw80Drh6i1Y3HoNt4 = '4_'
				else: BJxvSRlZbsIw80Drh6i1Y3HoNt4 = '5_'
				hnzMJty6u4er3D2kEq = LowSfEj9cH.replace('group="'+WRxXVZAgCy1cvIzepqB+'"','group="'+BJxvSRlZbsIw80Drh6i1Y3HoNt4+'~'+Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ+'"')
				fAOTjq2utEZX6N.append(hnzMJty6u4er3D2kEq)
				for LJGSiYW26TnPHo in oQA7XVPiGwbNq0hktDT:
					hnzMJty6u4er3D2kEq = LowSfEj9cH.replace('group="'+WRxXVZAgCy1cvIzepqB+'"','group="'+BJxvSRlZbsIw80Drh6i1Y3HoNt4+LJGSiYW26TnPHo+'"')
					fAOTjq2utEZX6N.append(hnzMJty6u4er3D2kEq)
			else: fAOTjq2utEZX6N.append(LowSfEj9cH)
		ww2nEWifbsVO4rMkHAgevcRP = fAOTjq2utEZX6N
		del fAOTjq2utEZX6N,YAqywGj1PJTCOI429Ffmep
	nEP5OFqBbxo = 1024*1024
	jjViBGRK9n = 1+len(q3yVCYoDS4hK)//nEP5OFqBbxo//10
	del q3yVCYoDS4hK
	TtEwHUb2cDie = len(ww2nEWifbsVO4rMkHAgevcRP)
	YAqywGj1PJTCOI429Ffmep = VESnzP5TLHsytv8irkf0maMg(ww2nEWifbsVO4rMkHAgevcRP,jjViBGRK9n)
	del ww2nEWifbsVO4rMkHAgevcRP
	for X0Rq3ISdwTJsnWGM7Kmc4 in range(jjViBGRK9n):
		KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,35+int(5*X0Rq3ISdwTJsnWGM7Kmc4/jjViBGRK9n),'تقطيع الملف الرئيسي','الجزء رقم:-',str(X0Rq3ISdwTJsnWGM7Kmc4+1)+' / '+str(jjViBGRK9n))
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
			fcjphRrZaOnYKwW5C4gAXN9DltI.close()
			return
		VVY9dZfsj5Kk = str(YAqywGj1PJTCOI429Ffmep[X0Rq3ISdwTJsnWGM7Kmc4])
		if A7Z6OVh20eCEUx: VVY9dZfsj5Kk = VVY9dZfsj5Kk.encode(Im5KSGZYBpRvdMVsbuXg)
		open(FY4zeathO0ClufW+'.00'+str(X0Rq3ISdwTJsnWGM7Kmc4),'wb').write(VVY9dZfsj5Kk)
	del YAqywGj1PJTCOI429Ffmep,VVY9dZfsj5Kk
	sfTFVwdvK1CUMzRDPJNa7LmEXe89Yt,Gq3SkiBZ5Mh7OrClnREdYemg,ziNeUR6gHltVW = [],[],0
	for X0Rq3ISdwTJsnWGM7Kmc4 in range(jjViBGRK9n):
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
			fcjphRrZaOnYKwW5C4gAXN9DltI.close()
			return
		VVY9dZfsj5Kk = open(FY4zeathO0ClufW+'.00'+str(X0Rq3ISdwTJsnWGM7Kmc4),'rb').read()
		L8Wkv5KCSoq.sleep(1)
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(FY4zeathO0ClufW+'.00'+str(X0Rq3ISdwTJsnWGM7Kmc4))
		except: pass
		if A7Z6OVh20eCEUx: VVY9dZfsj5Kk = VVY9dZfsj5Kk.decode(Im5KSGZYBpRvdMVsbuXg)
		y9QBciskWgUa6rt28zNTF7S3o = oE7iT3HI5VDdmY4kPOjr('list',VVY9dZfsj5Kk)
		del VVY9dZfsj5Kk
		rrQkyZUWgOaJlKcC71Eue6VAI,ziNeUR6gHltVW,mpbSNAWuexRZdlvfc0HoIngEijh = ANqlLnKkS5Pm6sYXrH4zbRGBQT1C(y9QBciskWgUa6rt28zNTF7S3o,b1bayYVQsFZE40,IqGFD8YjV0HOPkZx,fcjphRrZaOnYKwW5C4gAXN9DltI,TtEwHUb2cDie,ziNeUR6gHltVW,iUdqu4EwMpYV150JPmA6hg2jxtN9bn)
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
			fcjphRrZaOnYKwW5C4gAXN9DltI.close()
			return
		if not rrQkyZUWgOaJlKcC71Eue6VAI:
			fcjphRrZaOnYKwW5C4gAXN9DltI.close()
			return
		Gq3SkiBZ5Mh7OrClnREdYemg += rrQkyZUWgOaJlKcC71Eue6VAI
		sfTFVwdvK1CUMzRDPJNa7LmEXe89Yt += mpbSNAWuexRZdlvfc0HoIngEijh
	del y9QBciskWgUa6rt28zNTF7S3o,rrQkyZUWgOaJlKcC71Eue6VAI
	Ita2xUfiMSeuTP4sjQo6,mpbSNAWuexRZdlvfc0HoIngEijh = XWzdE9r67NlqkA0oDHMmFeI(Gq3SkiBZ5Mh7OrClnREdYemg,fcjphRrZaOnYKwW5C4gAXN9DltI,Dew1opNVWkiOsY)
	if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
		fcjphRrZaOnYKwW5C4gAXN9DltI.close()
		return
	sfTFVwdvK1CUMzRDPJNa7LmEXe89Yt += mpbSNAWuexRZdlvfc0HoIngEijh
	del Gq3SkiBZ5Mh7OrClnREdYemg,mpbSNAWuexRZdlvfc0HoIngEijh
	eh3BJmSlUvWd7z28H1ou9jwIPa,in1QCUOD23xmTRylG4YVuoWPNbS8,WRxXVZAgCy1cvIzepqB,WRuCeZVaX1iflscGNSJ70M5j2PD,AK9iq3XYlvG = {},{},{},0,0
	UO2xPVsCi7YK1vH50EamAZSb = list(Ita2xUfiMSeuTP4sjQo6.keys())
	IsHoBhjrv6Vz04LF = len(UO2xPVsCi7YK1vH50EamAZSb)*3
	if 1:
		NbgXUDGYoZ3JrQFtn = {}
		for QcLArCnTFUvdOwKXYGPy in UO2xPVsCi7YK1vH50EamAZSb:
			NbgXUDGYoZ3JrQFtn[QcLArCnTFUvdOwKXYGPy] = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=U3lmdRVbPjgGCJzi6o0yawA,args=(QcLArCnTFUvdOwKXYGPy,))
			NbgXUDGYoZ3JrQFtn[QcLArCnTFUvdOwKXYGPy].start()
		for QcLArCnTFUvdOwKXYGPy in UO2xPVsCi7YK1vH50EamAZSb:
			NbgXUDGYoZ3JrQFtn[QcLArCnTFUvdOwKXYGPy].join()
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
			fcjphRrZaOnYKwW5C4gAXN9DltI.close()
			return
	else:
		for QcLArCnTFUvdOwKXYGPy in UO2xPVsCi7YK1vH50EamAZSb:
			U3lmdRVbPjgGCJzi6o0yawA(QcLArCnTFUvdOwKXYGPy)
			if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
				fcjphRrZaOnYKwW5C4gAXN9DltI.close()
				return
	FUJ1E2Ltqb(XDsN23oyrzZEGSihUa0W,Dew1opNVWkiOsY,False)
	UO2xPVsCi7YK1vH50EamAZSb = list(eh3BJmSlUvWd7z28H1ou9jwIPa.keys())
	iOvDaIlQRcYjGqf0MLC7xWz = 0
	if 1:
		NbgXUDGYoZ3JrQFtn = {}
		for QcLArCnTFUvdOwKXYGPy in UO2xPVsCi7YK1vH50EamAZSb:
			NbgXUDGYoZ3JrQFtn[QcLArCnTFUvdOwKXYGPy] = M1L4HSe3CfNJ(daemon=w2qb6lf5EM,target=EDWGzpuhQMj0ro,args=(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy))
			NbgXUDGYoZ3JrQFtn[QcLArCnTFUvdOwKXYGPy].start()
		for QcLArCnTFUvdOwKXYGPy in UO2xPVsCi7YK1vH50EamAZSb:
			NbgXUDGYoZ3JrQFtn[QcLArCnTFUvdOwKXYGPy].join()
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
			fcjphRrZaOnYKwW5C4gAXN9DltI.close()
			return
	else:
		for QcLArCnTFUvdOwKXYGPy in UO2xPVsCi7YK1vH50EamAZSb:
			EDWGzpuhQMj0ro(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy)
			if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
				fcjphRrZaOnYKwW5C4gAXN9DltI.close()
				return
	X0Rq3ISdwTJsnWGM7Kmc4 = 0
	pfmJNyEkSe4M0wDvPHOFqB5lTaKGt = len(sfTFVwdvK1CUMzRDPJNa7LmEXe89Yt)
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,'IGNORED')
	for I0Yn5jCgvH in sfTFVwdvK1CUMzRDPJNa7LmEXe89Yt:
		if X0Rq3ISdwTJsnWGM7Kmc4%27==0:
			KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,95+int(5*X0Rq3ISdwTJsnWGM7Kmc4//pfmJNyEkSe4M0wDvPHOFqB5lTaKGt),'تخزين المهملة','الفيديو رقم:-',str(X0Rq3ISdwTJsnWGM7Kmc4)+' / '+str(pfmJNyEkSe4M0wDvPHOFqB5lTaKGt))
			if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled():
				fcjphRrZaOnYKwW5C4gAXN9DltI.close()
				return
		JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,'IGNORED_'+Dew1opNVWkiOsY,str(I0Yn5jCgvH),CJlTSEpZsWb0QHg5w,XlNnqz758Zeuo)
		X0Rq3ISdwTJsnWGM7Kmc4 += 1
	JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,'IGNORED_'+Dew1opNVWkiOsY,'__COUNT__',str(pfmJNyEkSe4M0wDvPHOFqB5lTaKGt),XlNnqz758Zeuo)
	fcjphRrZaOnYKwW5C4gAXN9DltI.close()
	L8Wkv5KCSoq.sleep(1)
	qw7beuI53SoE0jFmRrPtv4MNf(XDsN23oyrzZEGSihUa0W)
	return
def U3lmdRVbPjgGCJzi6o0yawA(QcLArCnTFUvdOwKXYGPy):
	global fcjphRrZaOnYKwW5C4gAXN9DltI,Ita2xUfiMSeuTP4sjQo6,iOvDaIlQRcYjGqf0MLC7xWz,eh3BJmSlUvWd7z28H1ou9jwIPa,in1QCUOD23xmTRylG4YVuoWPNbS8,WRxXVZAgCy1cvIzepqB,WRuCeZVaX1iflscGNSJ70M5j2PD,AK9iq3XYlvG,IsHoBhjrv6Vz04LF
	eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy] = {}
	qh9coyJQY8eHSKCEugVsjPk,vIStZGla2gH0OrzkwbNcYC = {},[]
	LLXtYs4bljhFmPM = len(Ita2xUfiMSeuTP4sjQo6[QcLArCnTFUvdOwKXYGPy])
	eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy]['__COUNT__'] = LLXtYs4bljhFmPM
	if LLXtYs4bljhFmPM>0:
		VlvCX9LNrAmqiWBG4FuToQs56b2RK,afibvZP4skV0y6F,P0vYpWUtaleZwErCh7Nku5,uEkxTJihfzLSW4mRNnHXg0a,nkp6wbrhtu0K2EGaFgQs7 = zip(*Ita2xUfiMSeuTP4sjQo6[QcLArCnTFUvdOwKXYGPy])
		del afibvZP4skV0y6F,P0vYpWUtaleZwErCh7Nku5,uEkxTJihfzLSW4mRNnHXg0a
		oQA7XVPiGwbNq0hktDT = list(set(VlvCX9LNrAmqiWBG4FuToQs56b2RK))
		for LJGSiYW26TnPHo in oQA7XVPiGwbNq0hktDT:
			qh9coyJQY8eHSKCEugVsjPk[LJGSiYW26TnPHo] = CJlTSEpZsWb0QHg5w
			eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy][LJGSiYW26TnPHo] = []
		KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,60+int(15*AK9iq3XYlvG//IsHoBhjrv6Vz04LF),'تصنيع القوائم','الجزء رقم:-',str(AK9iq3XYlvG)+' / '+str(IsHoBhjrv6Vz04LF))
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled(): return
		AK9iq3XYlvG += 1
		buOv2oS6MQWqAJiHF1wzGmT8f0Ie = len(oQA7XVPiGwbNq0hktDT)
		del oQA7XVPiGwbNq0hktDT
		vIStZGla2gH0OrzkwbNcYC = list(set(zip(VlvCX9LNrAmqiWBG4FuToQs56b2RK,nkp6wbrhtu0K2EGaFgQs7)))
		del VlvCX9LNrAmqiWBG4FuToQs56b2RK,nkp6wbrhtu0K2EGaFgQs7
		for LJGSiYW26TnPHo,ayeFgd1rBXvlfuKPYEihU82 in vIStZGla2gH0OrzkwbNcYC:
			if not qh9coyJQY8eHSKCEugVsjPk[LJGSiYW26TnPHo] and ayeFgd1rBXvlfuKPYEihU82: qh9coyJQY8eHSKCEugVsjPk[LJGSiYW26TnPHo] = ayeFgd1rBXvlfuKPYEihU82
		KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,60+int(15*AK9iq3XYlvG//IsHoBhjrv6Vz04LF),'تصنيع القوائم','الجزء رقم:-',str(AK9iq3XYlvG)+' / '+str(IsHoBhjrv6Vz04LF))
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled(): return
		AK9iq3XYlvG += 1
		ZGtTJYLBeyj0vuPdf7DzWXq = list(qh9coyJQY8eHSKCEugVsjPk.keys())
		CCdbPNR2xE = list(qh9coyJQY8eHSKCEugVsjPk.values())
		del qh9coyJQY8eHSKCEugVsjPk
		vIStZGla2gH0OrzkwbNcYC = list(zip(ZGtTJYLBeyj0vuPdf7DzWXq,CCdbPNR2xE))
		del ZGtTJYLBeyj0vuPdf7DzWXq,CCdbPNR2xE
		vIStZGla2gH0OrzkwbNcYC = sorted(vIStZGla2gH0OrzkwbNcYC)
	else: AK9iq3XYlvG += 2
	eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy]['__GROUPS__'] = vIStZGla2gH0OrzkwbNcYC
	del vIStZGla2gH0OrzkwbNcYC
	for LJGSiYW26TnPHo,AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY in Ita2xUfiMSeuTP4sjQo6[QcLArCnTFUvdOwKXYGPy]:
		eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy][LJGSiYW26TnPHo].append((AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY))
	KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,60+int(15*AK9iq3XYlvG//IsHoBhjrv6Vz04LF),'تصنيع القوائم','الجزء رقم:-',str(AK9iq3XYlvG)+' / '+str(IsHoBhjrv6Vz04LF))
	if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled(): return
	AK9iq3XYlvG += 1
	del Ita2xUfiMSeuTP4sjQo6[QcLArCnTFUvdOwKXYGPy]
	WRxXVZAgCy1cvIzepqB[QcLArCnTFUvdOwKXYGPy] = list(eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy].keys())
	in1QCUOD23xmTRylG4YVuoWPNbS8[QcLArCnTFUvdOwKXYGPy] = len(WRxXVZAgCy1cvIzepqB[QcLArCnTFUvdOwKXYGPy])
	WRuCeZVaX1iflscGNSJ70M5j2PD += in1QCUOD23xmTRylG4YVuoWPNbS8[QcLArCnTFUvdOwKXYGPy]
	return
def EDWGzpuhQMj0ro(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy):
	global fcjphRrZaOnYKwW5C4gAXN9DltI,Ita2xUfiMSeuTP4sjQo6,iOvDaIlQRcYjGqf0MLC7xWz,eh3BJmSlUvWd7z28H1ou9jwIPa,in1QCUOD23xmTRylG4YVuoWPNbS8,WRxXVZAgCy1cvIzepqB,WRuCeZVaX1iflscGNSJ70M5j2PD,AK9iq3XYlvG,IsHoBhjrv6Vz04LF
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy)
	for ziNeUR6gHltVW in range(1+in1QCUOD23xmTRylG4YVuoWPNbS8[QcLArCnTFUvdOwKXYGPy]//273):
		YY3amX4Mg28ZNBqckK61upiP = []
		u5kMfyV9LFCmWlKQiY = WRxXVZAgCy1cvIzepqB[QcLArCnTFUvdOwKXYGPy][0:273]
		for LJGSiYW26TnPHo in u5kMfyV9LFCmWlKQiY:
			YY3amX4Mg28ZNBqckK61upiP.append(eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy][LJGSiYW26TnPHo])
		JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,QcLArCnTFUvdOwKXYGPy,u5kMfyV9LFCmWlKQiY,YY3amX4Mg28ZNBqckK61upiP,XlNnqz758Zeuo,True)
		iOvDaIlQRcYjGqf0MLC7xWz += len(u5kMfyV9LFCmWlKQiY)
		KK4WuMYyThQ8l0SID2JrfGsb6UNx(fcjphRrZaOnYKwW5C4gAXN9DltI,75+int(20*iOvDaIlQRcYjGqf0MLC7xWz//WRuCeZVaX1iflscGNSJ70M5j2PD),'تخزين القوائم','القائمة رقم:-',str(iOvDaIlQRcYjGqf0MLC7xWz)+' / '+str(WRuCeZVaX1iflscGNSJ70M5j2PD))
		if fcjphRrZaOnYKwW5C4gAXN9DltI.iscanceled(): return
		del WRxXVZAgCy1cvIzepqB[QcLArCnTFUvdOwKXYGPy][0:273]
	del eh3BJmSlUvWd7z28H1ou9jwIPa[QcLArCnTFUvdOwKXYGPy],WRxXVZAgCy1cvIzepqB[QcLArCnTFUvdOwKXYGPy],in1QCUOD23xmTRylG4YVuoWPNbS8[QcLArCnTFUvdOwKXYGPy]
	return
def MeQmIcZChNUKEj15J7w(XDsN23oyrzZEGSihUa0W,Dew1opNVWkiOsY,s7yOo8cH9pXe=True):
	MMgJ9a1kVR = 'عدد فيديوهات جميع الروابط'
	NJQRB364WkaEbr = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,'LIVE_ORIGINAL_GROUPED')
	Kcakhv250MeJ = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,'VOD_ORIGINAL_GROUPED')
	if Dew1opNVWkiOsY:
		MMgJ9a1kVR = 'عدد فيديوهات رابط '+gB7j2bpeiCF1v[int(Dew1opNVWkiOsY)]
		Dew1opNVWkiOsY = '_'+Dew1opNVWkiOsY
	pfmJNyEkSe4M0wDvPHOFqB5lTaKGt = JCLGIhgx1M9eEicOwf(NJQRB364WkaEbr,'int','IGNORED'+Dew1opNVWkiOsY,'__COUNT__')
	Px5GX6hSClqWbtK729gZ = JCLGIhgx1M9eEicOwf(NJQRB364WkaEbr,'int','LIVE_ORIGINAL_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	aamNOE21JArdtZf5nvDxkUBwX = JCLGIhgx1M9eEicOwf(Kcakhv250MeJ,'int','VOD_ORIGINAL_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	j4VrIm5Oi8WfLTAt7gUXpN = JCLGIhgx1M9eEicOwf(NJQRB364WkaEbr,'int','LIVE_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	gZ7ly6CeXjV = JCLGIhgx1M9eEicOwf(NJQRB364WkaEbr,'int','LIVE_UNKNOWN_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	ZQyiq6flvGx5u7XHVDCYoKac = JCLGIhgx1M9eEicOwf(NJQRB364WkaEbr,'int','VOD_MOVIES_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	tyN64OlVYTwnXmd75WDMh2 = JCLGIhgx1M9eEicOwf(Kcakhv250MeJ,'int','VOD_SERIES_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	wOyeZMBQq6DoJHKSaXnlA1mTgx0 = JCLGIhgx1M9eEicOwf(NJQRB364WkaEbr,'int','VOD_UNKNOWN_GROUPED'+Dew1opNVWkiOsY,'__COUNT__')
	WRxXVZAgCy1cvIzepqB = JCLGIhgx1M9eEicOwf(Kcakhv250MeJ,'list','VOD_SERIES_GROUPED'+Dew1opNVWkiOsY,'__GROUPS__')
	V0wXAn9KolvUkJirPEGycmp7ZO = []
	for LJGSiYW26TnPHo,WC1Bc034gUjih7XZTpKvkEY in WRxXVZAgCy1cvIzepqB:
		TiF9RjHUyz = LJGSiYW26TnPHo.split('__SERIES__')[1]
		V0wXAn9KolvUkJirPEGycmp7ZO.append(TiF9RjHUyz)
	eZnpuFW289DvI = len(V0wXAn9KolvUkJirPEGycmp7ZO)
	SQIMhV4vz1wfebA7tRoD = int(ZQyiq6flvGx5u7XHVDCYoKac)+int(tyN64OlVYTwnXmd75WDMh2)+int(wOyeZMBQq6DoJHKSaXnlA1mTgx0)+int(gZ7ly6CeXjV)+int(j4VrIm5Oi8WfLTAt7gUXpN)
	yy8zrDI0sQPSKnmYU1FgMq = CJlTSEpZsWb0QHg5w
	yy8zrDI0sQPSKnmYU1FgMq += 'قنوات: '+str(j4VrIm5Oi8WfLTAt7gUXpN)
	yy8zrDI0sQPSKnmYU1FgMq += '   .   أفلام: '+str(ZQyiq6flvGx5u7XHVDCYoKac)
	yy8zrDI0sQPSKnmYU1FgMq += '\nمسلسلات: '+str(eZnpuFW289DvI)
	yy8zrDI0sQPSKnmYU1FgMq += '   .   حلقات: '+str(tyN64OlVYTwnXmd75WDMh2)
	yy8zrDI0sQPSKnmYU1FgMq += '\nقنوات مجهولة: '+str(gZ7ly6CeXjV)
	yy8zrDI0sQPSKnmYU1FgMq += '   .   فيدوهات مجهولة: '+str(wOyeZMBQq6DoJHKSaXnlA1mTgx0)
	yy8zrDI0sQPSKnmYU1FgMq += '\nمجموع القنوات: '+str(Px5GX6hSClqWbtK729gZ)
	yy8zrDI0sQPSKnmYU1FgMq += '   .   مجموع الفيديوهات: '+str(aamNOE21JArdtZf5nvDxkUBwX)
	yy8zrDI0sQPSKnmYU1FgMq += '\n\nمجموع المضافة: '+str(SQIMhV4vz1wfebA7tRoD)
	yy8zrDI0sQPSKnmYU1FgMq += '   .   مجموع المهملة: '+str(pfmJNyEkSe4M0wDvPHOFqB5lTaKGt)
	if s7yOo8cH9pXe: PIUzVg8uwmHlMKO5Lk6oxAZ('center',CJlTSEpZsWb0QHg5w,MMgJ9a1kVR,yy8zrDI0sQPSKnmYU1FgMq)
	iKj2Gg4RMlBbhUcreXD5yf9AsY7n0P = yy8zrDI0sQPSKnmYU1FgMq.replace('\n\n',rJ9cgWz4FU)
	if not Dew1opNVWkiOsY: Dew1opNVWkiOsY = 'All'
	else: Dew1opNVWkiOsY = Dew1opNVWkiOsY[1]
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,'.\tCounts of M3U videos   Folder: '+XDsN23oyrzZEGSihUa0W+'   Sequence: '+Dew1opNVWkiOsY+rJ9cgWz4FU+iKj2Gg4RMlBbhUcreXD5yf9AsY7n0P)
	return yy8zrDI0sQPSKnmYU1FgMq
def FUJ1E2Ltqb(XDsN23oyrzZEGSihUa0W,Dew1opNVWkiOsY,s7yOo8cH9pXe=True):
	if s7yOo8cH9pXe:
		AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if AAlgwLdnoxXz6G72yibjeEtu!=1: return
		Xu6y4AblWUxH8SoQVp0wPzvNdKL = oSVWcP6bX0mYFZi.replace('___','_'+XDsN23oyrzZEGSihUa0W+'_'+Dew1opNVWkiOsY)
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(Xu6y4AblWUxH8SoQVp0wPzvNdKL)
		except: pass
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,CJlTSEpZsWb0QHg5w)
	if Dew1opNVWkiOsY:
		CCE4WfV6TPu7xMBK0ANlJ9S = []
		for p1usCRtzeflgrcQL0bZ53 in GG6WOtTMvsxwAb:
			CCE4WfV6TPu7xMBK0ANlJ9S.append(p1usCRtzeflgrcQL0bZ53+'_'+Dew1opNVWkiOsY)
		oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,'LINK_'+Dew1opNVWkiOsY)
	else:
		CCE4WfV6TPu7xMBK0ANlJ9S = GG6WOtTMvsxwAb
		oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,'DUMMY')
		oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,'GROUPS')
		oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,'ITEMS')
		oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,'SEARCH')
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'SECTIONS_M3U','SECTIONS_M3U_'+XDsN23oyrzZEGSihUa0W)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for QcLArCnTFUvdOwKXYGPy in CCE4WfV6TPu7xMBK0ANlJ9S:
		oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,QcLArCnTFUvdOwKXYGPy)
	Cdyun4OtYjmFGHTzaW6rKwf9bg3Jsq(False)
	qw7beuI53SoE0jFmRrPtv4MNf(XDsN23oyrzZEGSihUa0W)
	if s7yOo8cH9pXe: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم مسح جميع ملفات ـM3U')
	return
def Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W=CJlTSEpZsWb0QHg5w,s7yOo8cH9pXe=True):
	if XDsN23oyrzZEGSihUa0W:
		PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(str(XDsN23oyrzZEGSihUa0W),'DUMMY')
		z7PfyvHhJWqs8Fl = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'str','DUMMY','__DUMMY__')
		if z7PfyvHhJWqs8Fl: return True
	else:
		XDsN23oyrzZEGSihUa0W = '1'
		for p3ZIxwvBOVT7j4 in range(1,baPq30VI6TOmUnQJ+1):
			PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(str(p3ZIxwvBOVT7j4),'DUMMY')
			z7PfyvHhJWqs8Fl = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'str','DUMMY','__DUMMY__')
			if z7PfyvHhJWqs8Fl: return True
	if s7yOo8cH9pXe:
		VsEJQ85MI1fSlLruc3j6K9kWH = 'https://iptv-org.github.io/iptv/index.region.m3u'
		c6ciaHs5794xORwtGCevMfI = 'https://iptv-org.github.io/iptv/index.category.m3u'
		dbnBkg5prS7N2u3iI8zLYJCoc4 = 'https://iptv-org.github.io/iptv/index.language.m3u'
		UXVOdyRGm0PkirvYu6j = 'https://iptv-org.github.io/iptv/index.country.m3u'
		oVjCzG4TKhv = VsEJQ85MI1fSlLruc3j6K9kWH+rJ9cgWz4FU+c6ciaHs5794xORwtGCevMfI+rJ9cgWz4FU+dbnBkg5prS7N2u3iI8zLYJCoc4+rJ9cgWz4FU+UXVOdyRGm0PkirvYu6j
		AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'هذه القوائم تحتاج رابط فيديوهات نوعه M3U . وهو متوفر في الإنترنت مجانا . وأيضا تبيعه الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام روابط مجانية أو غير مجانية\n'+Dj62UpP5MrbTkJqhRa+'http://github.com/iptv-org/iptv'+oOQaRxBXyJ5jVnZ+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+Dj62UpP5MrbTkJqhRa+oVjCzG4TKhv+oOQaRxBXyJ5jVnZ,profile='confirm_smallfont')
		if AAlgwLdnoxXz6G72yibjeEtu==1:
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.url_'+str(XDsN23oyrzZEGSihUa0W)+'_1',VsEJQ85MI1fSlLruc3j6K9kWH)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.url_'+str(XDsN23oyrzZEGSihUa0W)+'_2',c6ciaHs5794xORwtGCevMfI)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.url_'+str(XDsN23oyrzZEGSihUa0W)+'_3',dbnBkg5prS7N2u3iI8zLYJCoc4)
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.m3u.url_'+str(XDsN23oyrzZEGSihUa0W)+'_4',UXVOdyRGm0PkirvYu6j)
			AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if AAlgwLdnoxXz6G72yibjeEtu==1:
				H1HLzuN3AtcXkgEOlJVjqxhCbITr = Jt0fg5nDy2rwXKUbmLZu(XDsN23oyrzZEGSihUa0W)
				return H1HLzuN3AtcXkgEOlJVjqxhCbITr
		else:
			MMgJ9a1kVR = 'إضافة وتغيير رابط '+gB7j2bpeiCF1v[1]+' (مجلد '+gB7j2bpeiCF1v[int(XDsN23oyrzZEGSihUa0W)]+')'
			AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,MMgJ9a1kVR,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if AAlgwLdnoxXz6G72yibjeEtu==1: IvlxghompHDr(XDsN23oyrzZEGSihUa0W,'1')
	return False
def j5jSfelZXC0UJNR8m3OVI17sq(VVgteBh0dDHOoLaUw,XDsN23oyrzZEGSihUa0W=CJlTSEpZsWb0QHg5w,QcLArCnTFUvdOwKXYGPy=CJlTSEpZsWb0QHg5w,MhOeCQ2cFwNkg78Ki1DupIUG4H9=CJlTSEpZsWb0QHg5w):
	if not MhOeCQ2cFwNkg78Ki1DupIUG4H9: MhOeCQ2cFwNkg78Ki1DupIUG4H9 = '1'
	CmcJgXf24nBp5IeSdvt9xZAbjHEi,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,s7yOo8cH9pXe = oQYikwjnrKAcF29bR3WJPvEThfe(VVgteBh0dDHOoLaUw)
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe): return
	if not CmcJgXf24nBp5IeSdvt9xZAbjHEi:
		CmcJgXf24nBp5IeSdvt9xZAbjHEi = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not CmcJgXf24nBp5IeSdvt9xZAbjHEi: return
	hqsV17ypoUtr3JQZGT = [CJlTSEpZsWb0QHg5w,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not QcLArCnTFUvdOwKXYGPy:
		if not s7yOo8cH9pXe:
			if   '_M3U-LIVE_' in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[1]
			elif '_M3U-MOVIES' in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[2]
			elif '_M3U-SERIES' in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[3]
			else: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[0]
		else:
			RV71xlXFJLh3drMqfaUZ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			LfJRKzMepo0gZ = T4TK17YsEfZJ('أختر البحث المناسب', RV71xlXFJLh3drMqfaUZ)
			if LfJRKzMepo0gZ==-1: return
			QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[LfJRKzMepo0gZ]
	CmcJgXf24nBp5IeSdvt9xZAbjHEi = CmcJgXf24nBp5IeSdvt9xZAbjHEi+'_NODIALOGS_'
	if XDsN23oyrzZEGSihUa0W: jg5ZqF2hQrLNP(CmcJgXf24nBp5IeSdvt9xZAbjHEi,XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy,MhOeCQ2cFwNkg78Ki1DupIUG4H9)
	else:
		for XDsN23oyrzZEGSihUa0W in range(1,baPq30VI6TOmUnQJ+1):
			jg5ZqF2hQrLNP(CmcJgXf24nBp5IeSdvt9xZAbjHEi,str(XDsN23oyrzZEGSihUa0W),QcLArCnTFUvdOwKXYGPy,MhOeCQ2cFwNkg78Ki1DupIUG4H9)
		Ew2zQ8u7Ss.menuItemsLIST[:] = sorted(Ew2zQ8u7Ss.menuItemsLIST,reverse=False,key=lambda nnoEs7LuAtHfTMq4dKpvJXbRxkFY9: nnoEs7LuAtHfTMq4dKpvJXbRxkFY9[1].lower())
	return
def jg5ZqF2hQrLNP(VVgteBh0dDHOoLaUw,XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy=CJlTSEpZsWb0QHg5w,MhOeCQ2cFwNkg78Ki1DupIUG4H9=CJlTSEpZsWb0QHg5w):
	if not MhOeCQ2cFwNkg78Ki1DupIUG4H9: MhOeCQ2cFwNkg78Ki1DupIUG4H9 = '1'
	CmcJgXf24nBp5IeSdvt9xZAbjHEi,gKL8iaPh9sTzdx7ANOfVpbRrcHGkU,s7yOo8cH9pXe = oQYikwjnrKAcF29bR3WJPvEThfe(VVgteBh0dDHOoLaUw)
	if not XDsN23oyrzZEGSihUa0W: return
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe): return
	if not CmcJgXf24nBp5IeSdvt9xZAbjHEi:
		CmcJgXf24nBp5IeSdvt9xZAbjHEi = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not CmcJgXf24nBp5IeSdvt9xZAbjHEi: return
	hqsV17ypoUtr3JQZGT = [CJlTSEpZsWb0QHg5w,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not QcLArCnTFUvdOwKXYGPy:
		if not s7yOo8cH9pXe:
			if   '_M3U-LIVE_' in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[1]
			elif '_M3U-MOVIES' in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[2]
			elif '_M3U-SERIES' in gKL8iaPh9sTzdx7ANOfVpbRrcHGkU: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[3]
			else: QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[0]
		else:
			RV71xlXFJLh3drMqfaUZ = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			LfJRKzMepo0gZ = T4TK17YsEfZJ('أختر البحث المناسب', RV71xlXFJLh3drMqfaUZ)
			if LfJRKzMepo0gZ==-1: return
			QcLArCnTFUvdOwKXYGPy = hqsV17ypoUtr3JQZGT[LfJRKzMepo0gZ]
	v5vYeEwFB20MbzQINZ64yhLsC = CmcJgXf24nBp5IeSdvt9xZAbjHEi.lower()
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,'SEARCH')
	qTXQ0E8GoMkdI1 = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'list','SEARCH',(QcLArCnTFUvdOwKXYGPy,v5vYeEwFB20MbzQINZ64yhLsC))
	if not qTXQ0E8GoMkdI1:
		tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi,qqSvL6cuxK12mGgWXIT47 = [],[]
		if not QcLArCnTFUvdOwKXYGPy: NdeXrEV7ofBiS9Q8bg12Fq5Yh3DWa = [1,2,3,4,5]
		else: NdeXrEV7ofBiS9Q8bg12Fq5Yh3DWa = [hqsV17ypoUtr3JQZGT.index(QcLArCnTFUvdOwKXYGPy)]
		for X0Rq3ISdwTJsnWGM7Kmc4 in NdeXrEV7ofBiS9Q8bg12Fq5Yh3DWa:
			if X0Rq3ISdwTJsnWGM7Kmc4!=3:
				rrQkyZUWgOaJlKcC71Eue6VAI = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'dict',hqsV17ypoUtr3JQZGT[X0Rq3ISdwTJsnWGM7Kmc4])
				del rrQkyZUWgOaJlKcC71Eue6VAI['__COUNT__']
				del rrQkyZUWgOaJlKcC71Eue6VAI['__GROUPS__']
				del rrQkyZUWgOaJlKcC71Eue6VAI['__SEQUENCED_COLUMNS__']
				WRxXVZAgCy1cvIzepqB = list(rrQkyZUWgOaJlKcC71Eue6VAI.keys())
				for LJGSiYW26TnPHo in WRxXVZAgCy1cvIzepqB:
					for AC0yWDME4VSh8rkFXwpGeol6st,EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY in rrQkyZUWgOaJlKcC71Eue6VAI[LJGSiYW26TnPHo]:
						if v5vYeEwFB20MbzQINZ64yhLsC in EDIvQuJecN0X89Klt.lower(): qqSvL6cuxK12mGgWXIT47.append((EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY))
					del rrQkyZUWgOaJlKcC71Eue6VAI[LJGSiYW26TnPHo]
				del rrQkyZUWgOaJlKcC71Eue6VAI
			else: WRxXVZAgCy1cvIzepqB = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'list',hqsV17ypoUtr3JQZGT[X0Rq3ISdwTJsnWGM7Kmc4],'__GROUPS__')
			for LJGSiYW26TnPHo in WRxXVZAgCy1cvIzepqB:
				try: LJGSiYW26TnPHo,WC1Bc034gUjih7XZTpKvkEY = LJGSiYW26TnPHo
				except: WC1Bc034gUjih7XZTpKvkEY = CJlTSEpZsWb0QHg5w
				if v5vYeEwFB20MbzQINZ64yhLsC in LJGSiYW26TnPHo.lower():
					if X0Rq3ISdwTJsnWGM7Kmc4!=3: KqpN2vJaV0Mym = LJGSiYW26TnPHo
					else:
						vg8khFrNjD45bPLiKqyVYs2TZxOC,p5XONtjh3WolqLmSkerHMRcfdE9g = LJGSiYW26TnPHo.split('__SERIES__')
						if v5vYeEwFB20MbzQINZ64yhLsC in vg8khFrNjD45bPLiKqyVYs2TZxOC.lower(): KqpN2vJaV0Mym = vg8khFrNjD45bPLiKqyVYs2TZxOC
						else: KqpN2vJaV0Mym = p5XONtjh3WolqLmSkerHMRcfdE9g
					tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi.append((LJGSiYW26TnPHo,KqpN2vJaV0Mym,hqsV17ypoUtr3JQZGT[X0Rq3ISdwTJsnWGM7Kmc4],WC1Bc034gUjih7XZTpKvkEY))
			del WRxXVZAgCy1cvIzepqB
		tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi = set(tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi)
		qqSvL6cuxK12mGgWXIT47 = set(qqSvL6cuxK12mGgWXIT47)
		tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi = sorted(tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi,reverse=False,key=lambda nnoEs7LuAtHfTMq4dKpvJXbRxkFY9: nnoEs7LuAtHfTMq4dKpvJXbRxkFY9[1])
		qqSvL6cuxK12mGgWXIT47 = sorted(qqSvL6cuxK12mGgWXIT47,reverse=False,key=lambda nnoEs7LuAtHfTMq4dKpvJXbRxkFY9: nnoEs7LuAtHfTMq4dKpvJXbRxkFY9[0])
		JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,'SEARCH',(QcLArCnTFUvdOwKXYGPy,v5vYeEwFB20MbzQINZ64yhLsC),(tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi,qqSvL6cuxK12mGgWXIT47),XlNnqz758Zeuo)
	else: tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi,qqSvL6cuxK12mGgWXIT47 = qTXQ0E8GoMkdI1
	WRxXVZAgCy1cvIzepqB = len(tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi)
	zM6BWTRrLw9 = len(qqSvL6cuxK12mGgWXIT47)
	ZraEU3jpk2ns6q0ztPgvhioAX = int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)
	fuH58AU2Z69TFjXdOwenGSrBK1o = max(0,(ZraEU3jpk2ns6q0ztPgvhioAX-1)*100)
	YNeLoW81rS0 = max(0,ZraEU3jpk2ns6q0ztPgvhioAX*100)
	KpM4HYvZ9Dw = max(0,fuH58AU2Z69TFjXdOwenGSrBK1o-WRxXVZAgCy1cvIzepqB)
	PC2zABqsnHiN = max(0,YNeLoW81rS0-WRxXVZAgCy1cvIzepqB)
	for LJGSiYW26TnPHo,KqpN2vJaV0Mym,gHnYqej6XRm79Ehb3,WC1Bc034gUjih7XZTpKvkEY in tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi[fuH58AU2Z69TFjXdOwenGSrBK1o:YNeLoW81rS0]:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+KqpN2vJaV0Mym,gHnYqej6XRm79Ehb3,714,WC1Bc034gUjih7XZTpKvkEY,'1',LJGSiYW26TnPHo,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	del tmS4hEf7JPxDWHBbp8LZVOkgv9QnIi
	for EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,WC1Bc034gUjih7XZTpKvkEY in qqSvL6cuxK12mGgWXIT47[KpM4HYvZ9Dw:PC2zABqsnHiN]:
		XXKZgQenvuHOx6r = XETbMJIf1yetlQSinA2NW5YHvag6D(pkNZlmhUSwtXgriJHjT59MV1QqK)
		nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = 'live'
		if '.mkv' in XXKZgQenvuHOx6r or 'VOD' in QcLArCnTFUvdOwKXYGPy: nnAfhejEKz2luw4UdLVW9OkgMcXIGZ = 'video'
		khqge7BVD9jPFy1S8T5Gn4QAlH(nnAfhejEKz2luw4UdLVW9OkgMcXIGZ,fFi12zTm45q8LO3bt7yXDKcagRACp+EDIvQuJecN0X89Klt,pkNZlmhUSwtXgriJHjT59MV1QqK,715,WC1Bc034gUjih7XZTpKvkEY,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	del qqSvL6cuxK12mGgWXIT47
	aFE4IKnmld(XDsN23oyrzZEGSihUa0W,MhOeCQ2cFwNkg78Ki1DupIUG4H9,QcLArCnTFUvdOwKXYGPy,719,WRxXVZAgCy1cvIzepqB+zM6BWTRrLw9,CmcJgXf24nBp5IeSdvt9xZAbjHEi+'_NODIALOGS_')
	return
def aFE4IKnmld(XDsN23oyrzZEGSihUa0W,MhOeCQ2cFwNkg78Ki1DupIUG4H9,QcLArCnTFUvdOwKXYGPy,BEUVvSQtRimC,SQIMhV4vz1wfebA7tRoD,FMxeyLvnzabpJhCXgS6T):
	if not MhOeCQ2cFwNkg78Ki1DupIUG4H9: MhOeCQ2cFwNkg78Ki1DupIUG4H9 = '1'
	if MhOeCQ2cFwNkg78Ki1DupIUG4H9!='1': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'صفحة '+str(1),QcLArCnTFUvdOwKXYGPy,BEUVvSQtRimC,CJlTSEpZsWb0QHg5w,str(1),FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	if not SQIMhV4vz1wfebA7tRoD: SQIMhV4vz1wfebA7tRoD = 0
	x35qPXG6fE2NLIv4tM9lye = int(SQIMhV4vz1wfebA7tRoD/100)+1
	for ZraEU3jpk2ns6q0ztPgvhioAX in range(2,x35qPXG6fE2NLIv4tM9lye):
		UK4rRwoJyd2cMkpbeaQG9h = (ZraEU3jpk2ns6q0ztPgvhioAX%10==0 or int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)-4<ZraEU3jpk2ns6q0ztPgvhioAX<int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)+4)
		cc7oDqyNzf6C = (UK4rRwoJyd2cMkpbeaQG9h and int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)-40<ZraEU3jpk2ns6q0ztPgvhioAX<int(MhOeCQ2cFwNkg78Ki1DupIUG4H9)+40)
		if str(ZraEU3jpk2ns6q0ztPgvhioAX)!=MhOeCQ2cFwNkg78Ki1DupIUG4H9 and (ZraEU3jpk2ns6q0ztPgvhioAX%100==0 or cc7oDqyNzf6C):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'صفحة '+str(ZraEU3jpk2ns6q0ztPgvhioAX),QcLArCnTFUvdOwKXYGPy,BEUVvSQtRimC,CJlTSEpZsWb0QHg5w,str(ZraEU3jpk2ns6q0ztPgvhioAX),FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	if str(x35qPXG6fE2NLIv4tM9lye)!=MhOeCQ2cFwNkg78Ki1DupIUG4H9: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',fFi12zTm45q8LO3bt7yXDKcagRACp+'أخر صفحة '+str(x35qPXG6fE2NLIv4tM9lye),QcLArCnTFUvdOwKXYGPy,BEUVvSQtRimC,CJlTSEpZsWb0QHg5w,str(x35qPXG6fE2NLIv4tM9lye),FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,{'folder':XDsN23oyrzZEGSihUa0W})
	return
def CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,QcLArCnTFUvdOwKXYGPy):
	PFJcO9mztW6Lq7Hl2M = VLPYW7ylnbKeCSH.replace('___','_'+XDsN23oyrzZEGSihUa0W)
	return PFJcO9mztW6Lq7Hl2M
def Jt0fg5nDy2rwXKUbmLZu(XDsN23oyrzZEGSihUa0W):
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,CJlTSEpZsWb0QHg5w)
	AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if AAlgwLdnoxXz6G72yibjeEtu!=1: return False
	M3Ts7SXDYcWRpG5ZwgP6vn(XDsN23oyrzZEGSihUa0W,False)
	WydkMYlV6csxa8v = [0]
	for bqfWp3z1MOoYy87AKRxH6k in range(1,vvgwu3AbyMSfLr+1):
		QvxHXqabN3Vu0ftioAD5wE6K4dlhW = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.url_'+XDsN23oyrzZEGSihUa0W+'_'+str(bqfWp3z1MOoYy87AKRxH6k))
		if QvxHXqabN3Vu0ftioAD5wE6K4dlhW: uuYfDRegStjKQldXmBvN0(XDsN23oyrzZEGSihUa0W,str(bqfWp3z1MOoYy87AKRxH6k))
		WydkMYlV6csxa8v.append(0)
	for QcLArCnTFUvdOwKXYGPy in GG6WOtTMvsxwAb:
		d8dt6qOslXfmR,CugmiRN1ckqAbHSF07MDxtV,CUQIE7xKqNO0eAGawjfVvXd2YiM6,xXfIWA04OzHk9tR5NM2BYg,qh9coyJQY8eHSKCEugVsjPk = 0,{},[],[],[]
		for bqfWp3z1MOoYy87AKRxH6k in range(1,vvgwu3AbyMSfLr+1):
			gHnYqej6XRm79Ehb3 = QcLArCnTFUvdOwKXYGPy+'_'+str(bqfWp3z1MOoYy87AKRxH6k)
			Ita2xUfiMSeuTP4sjQo6 = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'dict',gHnYqej6XRm79Ehb3)
			try:
				mhliPsMVvHFLQ = Ita2xUfiMSeuTP4sjQo6['__GROUPS__']
				oFhapJsiDT4W = Ita2xUfiMSeuTP4sjQo6['__COUNT__']
			except: mhliPsMVvHFLQ,oFhapJsiDT4W = [],'0'
			for ighVrzCEtsQObvnf in mhliPsMVvHFLQ:
				LJGSiYW26TnPHo,ayeFgd1rBXvlfuKPYEihU82 = ighVrzCEtsQObvnf
				rrQkyZUWgOaJlKcC71Eue6VAI = Ita2xUfiMSeuTP4sjQo6[LJGSiYW26TnPHo]
				if LJGSiYW26TnPHo not in xXfIWA04OzHk9tR5NM2BYg:
					xXfIWA04OzHk9tR5NM2BYg.append(LJGSiYW26TnPHo)
					qh9coyJQY8eHSKCEugVsjPk.append(ighVrzCEtsQObvnf)
					CugmiRN1ckqAbHSF07MDxtV[LJGSiYW26TnPHo] = []
				CugmiRN1ckqAbHSF07MDxtV[LJGSiYW26TnPHo] += rrQkyZUWgOaJlKcC71Eue6VAI
			oHCAyTbdWEFu(PFJcO9mztW6Lq7Hl2M,gHnYqej6XRm79Ehb3)
			JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,gHnYqej6XRm79Ehb3,'__COUNT__',oFhapJsiDT4W,XlNnqz758Zeuo)
			WydkMYlV6csxa8v[bqfWp3z1MOoYy87AKRxH6k] += int(oFhapJsiDT4W)
		for LJGSiYW26TnPHo in xXfIWA04OzHk9tR5NM2BYg:
			rrQkyZUWgOaJlKcC71Eue6VAI = list(set(CugmiRN1ckqAbHSF07MDxtV[LJGSiYW26TnPHo]))
			if 'SORTED' in QcLArCnTFUvdOwKXYGPy: rrQkyZUWgOaJlKcC71Eue6VAI = sorted(rrQkyZUWgOaJlKcC71Eue6VAI,reverse=False,key=lambda key: key[1].lower())
			d8dt6qOslXfmR += len(rrQkyZUWgOaJlKcC71Eue6VAI)
			CUQIE7xKqNO0eAGawjfVvXd2YiM6.append(rrQkyZUWgOaJlKcC71Eue6VAI)
		JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,QcLArCnTFUvdOwKXYGPy,'__COUNT__',str(d8dt6qOslXfmR),XlNnqz758Zeuo)
		JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,QcLArCnTFUvdOwKXYGPy,'__GROUPS__',qh9coyJQY8eHSKCEugVsjPk,XlNnqz758Zeuo)
		JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,QcLArCnTFUvdOwKXYGPy,xXfIWA04OzHk9tR5NM2BYg,CUQIE7xKqNO0eAGawjfVvXd2YiM6,XlNnqz758Zeuo,True)
	gguSFTWb1JNnMa0E = False
	for bqfWp3z1MOoYy87AKRxH6k in range(1,vvgwu3AbyMSfLr+1):
		if int(WydkMYlV6csxa8v[bqfWp3z1MOoYy87AKRxH6k])>0:
			QvxHXqabN3Vu0ftioAD5wE6K4dlhW = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.m3u.url_'+XDsN23oyrzZEGSihUa0W+'_'+str(bqfWp3z1MOoYy87AKRxH6k))
			JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,'LINK_'+str(bqfWp3z1MOoYy87AKRxH6k),'__LINK__',QvxHXqabN3Vu0ftioAD5wE6K4dlhW,XlNnqz758Zeuo)
			gguSFTWb1JNnMa0E = True
	JGFzPBowen2i0HI(PFJcO9mztW6Lq7Hl2M,'DUMMY','__DUMMY__','DUMMY',XlNnqz758Zeuo)
	if not gguSFTWb1JNnMa0E:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم جلب ملفات M3U جديدة')
	jem4PF57gCRLbcVXHrtOSQG8WIi(XDsN23oyrzZEGSihUa0W)
	Cdyun4OtYjmFGHTzaW6rKwf9bg3Jsq(False)
	nYgsitVoc3E(False)
	return True
def jem4PF57gCRLbcVXHrtOSQG8WIi(XDsN23oyrzZEGSihUa0W):
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,CJlTSEpZsWb0QHg5w)
	if not Sl1RDgZhv9zaPtCjpiYkMweVIQHNJx(XDsN23oyrzZEGSihUa0W,True): return
	for bqfWp3z1MOoYy87AKRxH6k in range(1,vvgwu3AbyMSfLr+1):
		QvxHXqabN3Vu0ftioAD5wE6K4dlhW = JCLGIhgx1M9eEicOwf(PFJcO9mztW6Lq7Hl2M,'str','LINK_'+str(bqfWp3z1MOoYy87AKRxH6k),'__LINK__')
		if QvxHXqabN3Vu0ftioAD5wE6K4dlhW: yy8zrDI0sQPSKnmYU1FgMq = MeQmIcZChNUKEj15J7w(XDsN23oyrzZEGSihUa0W,str(bqfWp3z1MOoYy87AKRxH6k))
	MeQmIcZChNUKEj15J7w(XDsN23oyrzZEGSihUa0W,CJlTSEpZsWb0QHg5w)
	return
def M3Ts7SXDYcWRpG5ZwgP6vn(XDsN23oyrzZEGSihUa0W,s7yOo8cH9pXe):
	if s7yOo8cH9pXe:
		AAlgwLdnoxXz6G72yibjeEtu = qjTH2m7LxzoDERekhrBMs('center',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if AAlgwLdnoxXz6G72yibjeEtu!=1: return
	PFJcO9mztW6Lq7Hl2M = CxHgD5s2Skm3JTlpujPqB4YytXaU(XDsN23oyrzZEGSihUa0W,CJlTSEpZsWb0QHg5w)
	try: tiFgl4DMvGEAUfjIYkHbr05.remove(PFJcO9mztW6Lq7Hl2M)
	except: pass
	for bqfWp3z1MOoYy87AKRxH6k in range(1,vvgwu3AbyMSfLr+1):
		WEbjm0dNDHoz = oSVWcP6bX0mYFZi.replace('___','_'+XDsN23oyrzZEGSihUa0W+'_'+str(bqfWp3z1MOoYy87AKRxH6k))
		ZTzVqbfeajYoc9Cp8RDldkBt30nvuA = tiFgl4DMvGEAUfjIYkHbr05.path.join(c2XOIv1RU6aSuAeiZ5Pgz9Gr,WEbjm0dNDHoz)
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(ZTzVqbfeajYoc9Cp8RDldkBt30nvuA)
		except: pass
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'SECTIONS_M3U','SECTIONS_M3U_'+XDsN23oyrzZEGSihUa0W)
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if s7yOo8cH9pXe:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'تم مسح جميع ملفات ـM3U')
		nYgsitVoc3E(False)
	return
def qw7beuI53SoE0jFmRrPtv4MNf(XDsN23oyrzZEGSihUa0W):
	bKpPgfhSrZ = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.provider')
	vYfNCsUkSVbI894lPxc = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.language.code')
	oHCAyTbdWEFu(NN4DuIqLH9iGesZocawQTUWm0E,'MENUS_CACHE_'+bKpPgfhSrZ+'_'+vYfNCsUkSVbI894lPxc,'%_MU'+XDsN23oyrzZEGSihUa0W+'_%')
	return
LLlV7F2rjRWD1CdQ = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'EGYBESTVIP'
kL0nT7NpZdKVD3jM2OHB = '_EGV_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
def hH3sRBSFAr(mode,url,GOF25jkXb1DnaB4vhL9,text):
	if   mode==220: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==221: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9)
	elif mode==222: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==223: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==224: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url)
	elif mode==229: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,229,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="i i-home"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,222)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="ba(.*?)<script',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,ZgsbN5iSL48t2IhVFnmy in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,221)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if 'html' not in ZgsbN5iSL48t2IhVFnmy: continue
			if not ZgsbN5iSL48t2IhVFnmy.endswith('/'): khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,221)
	return bGIVq1CQTjmosZg
def jSpWoLZQRIsrw7MnH5KEbu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="rs_scroll"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</i>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,224)
	return
def wwkAylgOx852(url):
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',url,221)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-FILTERS_MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="sub_nav(.*?)id="movies',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".+?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if ZgsbN5iSL48t2IhVFnmy=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,221)
	else: nvHUf8mW6E4GSw5VFRXN(url)
	return
def nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9='1'):
	if GOF25jkXb1DnaB4vhL9==CJlTSEpZsWb0QHg5w: GOF25jkXb1DnaB4vhL9 = '1'
	if '/search' in url or '?' in url: BBwfuWGxUIrdCoc4ka7 = url + '&'
	else: BBwfuWGxUIrdCoc4ka7 = url + '?'
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7 + 'page=' + GOF25jkXb1DnaB4vhL9
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('class="pda"(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[-1]
	elif '/series/' in url:
		s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('class="owl-carousel owl-carousel(.*?)div',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	else:
		s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('id="movies(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[-1]
	items = Zy2l0g8QU5vqefaTrsw.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		title = wAmsc95ya0LHz(title)
		if '/movie/' in ZgsbN5iSL48t2IhVFnmy or '/episode' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy.rstrip('/'),223,hzGKUP1XjAoeT79MJcDF)
		else:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,221,hzGKUP1XjAoeT79MJcDF)
	if len(items)>=16:
		KBZkF5Xdu90yV1 = ['/movies','/tv','/search','/trending']
		GOF25jkXb1DnaB4vhL9 = int(GOF25jkXb1DnaB4vhL9)
		if any(value in url for value in KBZkF5Xdu90yV1):
			for V4r0Xv5lTtABaed3MmCG6HcspxURQ in range(0,1000,100):
				if int(GOF25jkXb1DnaB4vhL9/100)*100==V4r0Xv5lTtABaed3MmCG6HcspxURQ:
					for PMTRpXQvDIkiNszwYGnb32a in range(V4r0Xv5lTtABaed3MmCG6HcspxURQ,V4r0Xv5lTtABaed3MmCG6HcspxURQ+100,10):
						if int(GOF25jkXb1DnaB4vhL9/10)*10==PMTRpXQvDIkiNszwYGnb32a:
							for DqUuWaBZV24 in range(PMTRpXQvDIkiNszwYGnb32a,PMTRpXQvDIkiNszwYGnb32a+10,1):
								if not GOF25jkXb1DnaB4vhL9==DqUuWaBZV24 and DqUuWaBZV24!=0:
									khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+str(DqUuWaBZV24),url,221,CJlTSEpZsWb0QHg5w,str(DqUuWaBZV24))
						elif PMTRpXQvDIkiNszwYGnb32a!=0: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+str(PMTRpXQvDIkiNszwYGnb32a),url,221,CJlTSEpZsWb0QHg5w,str(PMTRpXQvDIkiNszwYGnb32a))
						else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+str(1),url,221,CJlTSEpZsWb0QHg5w,str(1))
				elif V4r0Xv5lTtABaed3MmCG6HcspxURQ!=0: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+str(V4r0Xv5lTtABaed3MmCG6HcspxURQ),url,221,CJlTSEpZsWb0QHg5w,str(V4r0Xv5lTtABaed3MmCG6HcspxURQ))
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+str(1),url,221)
	return
def rHwfOZb3oSgJKi(url):
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-PLAY-1st')
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('<td>التصنيف</td>.*?">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO,pEUTSZnGqmgwhWf = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	MCHT8FbSm4wiPzjVlouxQ0v,LD74ZrM0IWU = bGIVq1CQTjmosZg,bGIVq1CQTjmosZg
	UxdgeDWXZALTouc3N64j = Zy2l0g8QU5vqefaTrsw.findall('show_dl api" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if UxdgeDWXZALTouc3N64j:
		for ZgsbN5iSL48t2IhVFnmy in UxdgeDWXZALTouc3N64j:
			if '/watch/' in ZgsbN5iSL48t2IhVFnmy: rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO = ZgsbN5iSL48t2IhVFnmy
			elif '/download/' in ZgsbN5iSL48t2IhVFnmy: pEUTSZnGqmgwhWf = ZgsbN5iSL48t2IhVFnmy
		if rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO!=CJlTSEpZsWb0QHg5w: MCHT8FbSm4wiPzjVlouxQ0v = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-PLAY-2nd')
		if pEUTSZnGqmgwhWf!=CJlTSEpZsWb0QHg5w: LD74ZrM0IWU = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,pEUTSZnGqmgwhWf,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-PLAY-3rd')
	kSNPrwjCWY1K5JGFyh06oeXn8uVU = Zy2l0g8QU5vqefaTrsw.findall('id="video".*?data-src="(.*?)"',MCHT8FbSm4wiPzjVlouxQ0v,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if kSNPrwjCWY1K5JGFyh06oeXn8uVU:
		BBwfuWGxUIrdCoc4ka7 = kSNPrwjCWY1K5JGFyh06oeXn8uVU[0]
		if BBwfuWGxUIrdCoc4ka7!=CJlTSEpZsWb0QHg5w and 'uploaded.egybest.download' in BBwfuWGxUIrdCoc4ka7 and '/?id=_' not in BBwfuWGxUIrdCoc4ka7:
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-PLAY-4th')
			cLlAbnCaE241R0fBSO = Zy2l0g8QU5vqefaTrsw.findall('source src="(.*?)" title="(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if cLlAbnCaE241R0fBSO:
				for ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx in cLlAbnCaE241R0fBSO:
					MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy+'?named=ed.egybest.do__watch__mp4__'+egYIsS2qROfpVW83kx)
			else:
				FFtJQalhPz = BBwfuWGxUIrdCoc4ka7.split('/')[2]
				MNXzjK3vV7D.append(BBwfuWGxUIrdCoc4ka7+'?named='+FFtJQalhPz+'__watch')
		elif BBwfuWGxUIrdCoc4ka7!=CJlTSEpZsWb0QHg5w:
			FFtJQalhPz = BBwfuWGxUIrdCoc4ka7.split('/')[2]
			MNXzjK3vV7D.append(BBwfuWGxUIrdCoc4ka7+'?named='+FFtJQalhPz+'__watch')
	P4PY3BnzVK = Zy2l0g8QU5vqefaTrsw.findall('<table class="dls_table(.*?)</table>',LD74ZrM0IWU,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if P4PY3BnzVK:
		P4PY3BnzVK = P4PY3BnzVK[0]
		hqRy14N3P0vfOwVj = Zy2l0g8QU5vqefaTrsw.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',P4PY3BnzVK,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if hqRy14N3P0vfOwVj:
			for egYIsS2qROfpVW83kx,ZgsbN5iSL48t2IhVFnmy in hqRy14N3P0vfOwVj:
				if 'myegyvip' not in ZgsbN5iSL48t2IhVFnmy: continue
				if ZgsbN5iSL48t2IhVFnmy.count('/')>=2:
					FFtJQalhPz = ZgsbN5iSL48t2IhVFnmy.split('/')[2]
					MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__download__mp4__'+egYIsS2qROfpVW83kx)
	hA9Pip7QNB0mMR = []
	for ZgsbN5iSL48t2IhVFnmy in MNXzjK3vV7D:
		hA9Pip7QNB0mMR.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(hA9Pip7QNB0mMR,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'+')
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBESTVIP-SEARCH-1st')
	eOVb64kRWwArpNmu5CLXtzfDF = Zy2l0g8QU5vqefaTrsw.findall('name="_token" value="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if eOVb64kRWwArpNmu5CLXtzfDF:
		url = V4kF6EQiwo+'/search?_token='+eOVb64kRWwArpNmu5CLXtzfDF[0]+'&q='+QjfknOVHzZIUir
		nvHUf8mW6E4GSw5VFRXN(url)
	return
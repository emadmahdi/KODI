# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'ARABSEED'
headers = {'User-Agent':jQW9RpucaCLHX0sSBD6lrif58e47nt()}
kL0nT7NpZdKVD3jM2OHB = '_ARS_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def hH3sRBSFAr(mode,url,text):
	if   mode==250: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==251: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==252: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==253: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==254: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'CATEGORIES___'+text)
	elif mode==255: SD0TxMRXiep4cjPBsnzI = wwkAylgOx852(url,'FILTERS___'+text)
	elif mode==256: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url,text)
	elif mode==259: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo+'/main',CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,259,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر محدد',V4kF6EQiwo+'/category/اخرى',254)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فلتر كامل',V4kF6EQiwo+'/category/اخرى',255)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المميزة',V4kF6EQiwo+'/main',251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured_main')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'جديد الأفلام',V4kF6EQiwo+'/main',251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'new_movies')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'جديد الحلقات',V4kF6EQiwo+'/main',251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'new_episodes')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المضاف حديثاً',V4kF6EQiwo+'/latest',251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'lastest')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('class="MenuHeader"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	zE8URkuN932 = KXu2RYg3Bc[0]
	B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',zE8URkuN932,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in B5vY7qZAFfeTcXnpCGP9SRr0kaHV:
		title = wAmsc95ya0LHz(title)
		if title not in qe1JPURnS9ODoCNEpbdh8i67Tur and title!=CJlTSEpZsWb0QHg5w:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,256)
	return bGIVq1CQTjmosZg
def jSpWoLZQRIsrw7MnH5KEbu(url,type):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-SUBMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if 'class="SliderInSection' in bGIVq1CQTjmosZg: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الأكثر مشاهدة',url,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'most')
	if 'class="MainSlides' in bGIVq1CQTjmosZg: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المميزة',url,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	if 'class="LinksList' in bGIVq1CQTjmosZg:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="LinksList(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			if len(s67485upzYNMS3PqDelkrdfo)>1 and type=='new_episodes': D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[1]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				II4x930lvTuVqekXBNCrMy = Zy2l0g8QU5vqefaTrsw.findall('</i>(.*?)<span>(.*?)<',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
				try: kc4BtgWCFLJ5yGRVZzuX1eni20 = II4x930lvTuVqekXBNCrMy[0][0].replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				except: kc4BtgWCFLJ5yGRVZzuX1eni20 = CJlTSEpZsWb0QHg5w
				try: GdXS7k358z1f0unQtbOg = II4x930lvTuVqekXBNCrMy[0][1].replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				except: GdXS7k358z1f0unQtbOg = CJlTSEpZsWb0QHg5w
				II4x930lvTuVqekXBNCrMy = kc4BtgWCFLJ5yGRVZzuX1eni20+YvOQBzaTAscXR9ql+GdXS7k358z1f0unQtbOg
				if '<strong>' in title:
					bb8tvfOl91VRHuEA6zNZ4GIU = Zy2l0g8QU5vqefaTrsw.findall('</i>(.*?)<',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if bb8tvfOl91VRHuEA6zNZ4GIU: II4x930lvTuVqekXBNCrMy = bb8tvfOl91VRHuEA6zNZ4GIU[0]
				if not II4x930lvTuVqekXBNCrMy:
					bb8tvfOl91VRHuEA6zNZ4GIU = Zy2l0g8QU5vqefaTrsw.findall('alt="(.*?)"',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if bb8tvfOl91VRHuEA6zNZ4GIU: II4x930lvTuVqekXBNCrMy = bb8tvfOl91VRHuEA6zNZ4GIU[0]
				if II4x930lvTuVqekXBNCrMy:
					if 'key=' in ZgsbN5iSL48t2IhVFnmy: type = ZgsbN5iSL48t2IhVFnmy.split('key=')[1]
					else: type = 'newest'
					II4x930lvTuVqekXBNCrMy = II4x930lvTuVqekXBNCrMy.strip(YvOQBzaTAscXR9ql)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,ZgsbN5iSL48t2IhVFnmy,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	return
def nvHUf8mW6E4GSw5VFRXN(url,type):
	ttTVKH3QhzZxYd,data,items = 'GET',CJlTSEpZsWb0QHg5w,[]
	if type=='filters':
		if '?' in url:
			geDkEJs0oqiZ7Ar,s502yd81FCuJmLVBlkPtxih9fZDA = 'POST',{}
			BBwfuWGxUIrdCoc4ka7,kjGCm2DWF9wdlTb5 = url.split('?')
			xWMpqasJ9BD = kjGCm2DWF9wdlTb5.split('&')
			for YjATkiozK34fNw1btrEeU8 in xWMpqasJ9BD:
				key,value = YjATkiozK34fNw1btrEeU8.split('=')
				s502yd81FCuJmLVBlkPtxih9fZDA[key] = value
			if xWMpqasJ9BD: ttTVKH3QhzZxYd,url,data = geDkEJs0oqiZ7Ar,BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,ttTVKH3QhzZxYd,url,data,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if type=='filters': s67485upzYNMS3PqDelkrdfo = [bGIVq1CQTjmosZg]
	elif 'featured' in type: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="MainSlides(.*?)class="LinksList',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='new_movies': s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='new_episodes': s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='most': s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="SliderInSection(.*?)class="LinksList',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="Blocks-UL"(.*?)class="AboElSeed"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if 'featured' in type:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		wi6ZqVAdgXUxSj0TPlWG7NsOmK48 = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if wi6ZqVAdgXUxSj0TPlWG7NsOmK48:
			MNXzjK3vV7D,Uz8mMbZifCyvkLnct,DWIPr3y5Awm9ebfs4xhGun,FwatKBi3qv = zip(*wi6ZqVAdgXUxSj0TPlWG7NsOmK48)
			items = zip(MNXzjK3vV7D,FwatKBi3qv,Uz8mMbZifCyvkLnct)
	else:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if 'WWE' in title: continue
		title = wAmsc95ya0LHz(title)
		if 'الحلقة' in title:
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
				if title not in wDkMP6jlz7XeN5Sp:
					wDkMP6jlz7XeN5Sp.append(title)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,253,hzGKUP1XjAoeT79MJcDF)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,252,hzGKUP1XjAoeT79MJcDF)
		elif '/selary/' in ZgsbN5iSL48t2IhVFnmy or 'مسلسل' in title:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,253,hzGKUP1XjAoeT79MJcDF)
		else:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,252,hzGKUP1XjAoeT79MJcDF)
	if type in ['newest','best','most']:
		items = Zy2l0g8QU5vqefaTrsw.findall('page-numbers" href="(.*?)">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			ZgsbN5iSL48t2IhVFnmy = wAmsc95ya0LHz(ZgsbN5iSL48t2IhVFnmy)
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,type)
	return
def j9zTQsrVRx2(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	bGIVq1CQTjmosZg = bGIVq1CQTjmosZg[10000:]
	items = Zy2l0g8QU5vqefaTrsw.findall('data-src="(.*?)".*?alt="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not items: return
	hzGKUP1XjAoeT79MJcDF,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(YvOQBzaTAscXR9ql)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(YvOQBzaTAscXR9ql)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="ContainerEpisodesList"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<em>(.*?)</em>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,ABK45TEMpciLnmIlYOafQJZ8t in items:
			title = name+' - الحلقة رقم '+ABK45TEMpciLnmIlYOafQJZ8t
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,252,hzGKUP1XjAoeT79MJcDF)
	else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+'ملف التشغيل',url,252,hzGKUP1XjAoeT79MJcDF)
	return
def w4SshPkrqiDnmbC9ARcJElIvY0F6t(title,ZgsbN5iSL48t2IhVFnmy):
	II4x930lvTuVqekXBNCrMy = Zy2l0g8QU5vqefaTrsw.findall('[a-zA-Z-]+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if II4x930lvTuVqekXBNCrMy: title = II4x930lvTuVqekXBNCrMy[0]
	else: title = title+YvOQBzaTAscXR9ql+fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
	title = title.replace('عرب سيد',CJlTSEpZsWb0QHg5w).replace('مباشر',CJlTSEpZsWb0QHg5w).replace('مشاهدة',CJlTSEpZsWb0QHg5w)
	title = title.replace('ٍ',CJlTSEpZsWb0QHg5w)
	title = title.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	return title
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	BBwfuWGxUIrdCoc4ka7 = bqIufCQz2OWExjilm.url
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(BBwfuWGxUIrdCoc4ka7,'url')
	headers['Referer'] = FFtJQalhPz+'/'
	headers['Content-Type'] = 'application/x-www-form-urlencoded'
	MNXzjK3vV7D,e4PJCWaFzUYspvgL = [],[]
	rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO,fTebzxUNulQ6JcjFOBKm5w,HiESMZ29Phsb4vKGCdeD = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	pEUTSZnGqmgwhWf,JL4wo8vIny5EtHKz3gT1OBMFRpu,GwRk65fIWmDQBs = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	vkOHeyF0oL3ub4D = Zy2l0g8QU5vqefaTrsw.findall('"WatchButtons"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if vkOHeyF0oL3ub4D:
		D3D6TF50oUBtJlvijPMW8ys = vkOHeyF0oL3ub4D[ZVNvqy4iF1a9X]
		if '<form' in D3D6TF50oUBtJlvijPMW8ys:
			e4PJCWaFzUYspvgL = Zy2l0g8QU5vqefaTrsw.findall('<form action="(.*?)".*?name="(.*?)".*?value="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if e4PJCWaFzUYspvgL:
				ttTVKH3QhzZxYd = 'POST'
				for eeqpSKuXbQxUMkC3RIdBr1tW2,name,value in e4PJCWaFzUYspvgL:
					if 'wpost' in name: rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO,fTebzxUNulQ6JcjFOBKm5w,HiESMZ29Phsb4vKGCdeD = eeqpSKuXbQxUMkC3RIdBr1tW2,name,value
					elif 'dpost' in name: pEUTSZnGqmgwhWf,JL4wo8vIny5EtHKz3gT1OBMFRpu,GwRk65fIWmDQBs = eeqpSKuXbQxUMkC3RIdBr1tW2,name,value
				Uo07D6FVvPXdtHlxYgWE = fTebzxUNulQ6JcjFOBKm5w+'='+HiESMZ29Phsb4vKGCdeD
				RPTKXl7mEzJC = JL4wo8vIny5EtHKz3gT1OBMFRpu+'='+GwRk65fIWmDQBs
		else:
			e4PJCWaFzUYspvgL = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if e4PJCWaFzUYspvgL:
				ttTVKH3QhzZxYd = 'GET'
				for ZgsbN5iSL48t2IhVFnmy in e4PJCWaFzUYspvgL:
					if 'wpost' in ZgsbN5iSL48t2IhVFnmy: rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO = ZgsbN5iSL48t2IhVFnmy
					elif 'dpost' in ZgsbN5iSL48t2IhVFnmy: pEUTSZnGqmgwhWf = ZgsbN5iSL48t2IhVFnmy
				Uo07D6FVvPXdtHlxYgWE = CJlTSEpZsWb0QHg5w
				RPTKXl7mEzJC = CJlTSEpZsWb0QHg5w
	if rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,ttTVKH3QhzZxYd,rG5Qp1XhiaNVtAbove6sw2fJ4uxMkO,Uo07D6FVvPXdtHlxYgWE,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-PLAY-2nd')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="WatcherArea(.*?</ul>)',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			nn4Dg5YQqduzrA6ljh8aR91Xf = s67485upzYNMS3PqDelkrdfo[0]
			nn4Dg5YQqduzrA6ljh8aR91Xf = nn4Dg5YQqduzrA6ljh8aR91Xf.replace('</ul>','<h3>')
			nn4Dg5YQqduzrA6ljh8aR91Xf = nn4Dg5YQqduzrA6ljh8aR91Xf.replace('<h3>','<h3><h3>')
			p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('<h3>.*?(\d+)(.*?)<h3>',nn4Dg5YQqduzrA6ljh8aR91Xf,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if not p3LfChWJd124eAYj78zw09SXonH: p3LfChWJd124eAYj78zw09SXonH = [(CJlTSEpZsWb0QHg5w,nn4Dg5YQqduzrA6ljh8aR91Xf)]
			for egYIsS2qROfpVW83kx,D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
				if egYIsS2qROfpVW83kx: egYIsS2qROfpVW83kx = '____'+egYIsS2qROfpVW83kx
				items = Zy2l0g8QU5vqefaTrsw.findall('data-link="(.*?)".*?<span>(.*?)</span>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,name in items:
					if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
					ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__watch'+egYIsS2qROfpVW83kx
					MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
		if Rp1g7OlotseGnf0NFmKk6rLxd:
			ZgsbN5iSL48t2IhVFnmy,egYIsS2qROfpVW83kx = Rp1g7OlotseGnf0NFmKk6rLxd[0]
			name = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
			if '%' in egYIsS2qROfpVW83kx: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__embed__'
			else: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__embed____'+egYIsS2qROfpVW83kx
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if pEUTSZnGqmgwhWf:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,ttTVKH3QhzZxYd,pEUTSZnGqmgwhWf,RPTKXl7mEzJC,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-PLAY-3rd')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="DownloadArea(.*?)<script src=',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			nn4Dg5YQqduzrA6ljh8aR91Xf = s67485upzYNMS3PqDelkrdfo[0]
			p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('class="DownloadServers(.*?)</ul>',nn4Dg5YQqduzrA6ljh8aR91Xf,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
				items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,title,egYIsS2qROfpVW83kx in items:
					if not ZgsbN5iSL48t2IhVFnmy: continue
					if 'reviewstation' in ZgsbN5iSL48t2IhVFnmy: continue
					ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy)
					ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download____'+egYIsS2qROfpVW83kx
					MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	L6J80bAkFHSsCY = str(MNXzjK3vV7D)
	dd9y8i42IMC3volwujLQKTzfE = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(value in L6J80bAkFHSsCY for value in dd9y8i42IMC3volwujLQKTzfE):
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if not search: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/find/?find='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
def wwkAylgOx852(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='CATEGORIES':
		if CyoSHprnasi3K0M[0]+'==' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = CyoSHprnasi3K0M[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(CyoSHprnasi3K0M[0:-1])):
			if CyoSHprnasi3K0M[PMTRpXQvDIkiNszwYGnb32a]+'==' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = CyoSHprnasi3K0M[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&&'+y3LbIjrZvcATpNDM+'==0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&&'+y3LbIjrZvcATpNDM+'==0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&&')+'___'+YYvW68idVrJQFa.strip('&&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		BBwfuWGxUIrdCoc4ka7 = url+'//getposts??'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='FILTERS':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm!=CJlTSEpZsWb0QHg5w: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		if bnCVRhKEGJ0DIYqUBsgdpm==CJlTSEpZsWb0QHg5w: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'//getposts??'+bnCVRhKEGJ0DIYqUBsgdpm
		Da7e1Ruo9G = fPKulGyw2E(BBwfuWGxUIrdCoc4ka7)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها ',Da7e1Ruo9G,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',Da7e1Ruo9G,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'POST',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ARABSEED-FILTERS_MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	YYCMHcJaGE = Zy2l0g8QU5vqefaTrsw.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	zwGi6BJx3lrP4cZW7bOIACte5vhN = Zy2l0g8QU5vqefaTrsw.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = YYCMHcJaGE+zwGi6BJx3lrP4cZW7bOIACte5vhN
	dict = {}
	for name,HLQNhXe7orPjl5Vm4,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		items = Zy2l0g8QU5vqefaTrsw.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			B5vY7qZAFfeTcXnpCGP9SRr0kaHV = Zy2l0g8QU5vqefaTrsw.findall('data-rate="(.*?)".*?<em>(.*?)</em>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			items = []
			for ll5WFBCJKhA64tIDT8qvX,value in B5vY7qZAFfeTcXnpCGP9SRr0kaHV: items.append([ll5WFBCJKhA64tIDT8qvX,CJlTSEpZsWb0QHg5w,value])
			HLQNhXe7orPjl5Vm4 = 'rate'
			name = 'التقييم'
		else: HLQNhXe7orPjl5Vm4 = items[0][1]
		if '==' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='CATEGORIES':
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<=1:
				if HLQNhXe7orPjl5Vm4==CyoSHprnasi3K0M[-1]: nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'CATEGORIES___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				Da7e1Ruo9G = fPKulGyw2E(BBwfuWGxUIrdCoc4ka7)
				if HLQNhXe7orPjl5Vm4==CyoSHprnasi3K0M[-1]: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع ',Da7e1Ruo9G,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع ',BBwfuWGxUIrdCoc4ka7,254,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='FILTERS':
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&&'+HLQNhXe7orPjl5Vm4+'==0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&&'+HLQNhXe7orPjl5Vm4+'==0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع :'+name,BBwfuWGxUIrdCoc4ka7,255,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		dict[HLQNhXe7orPjl5Vm4] = {}
		for ll5WFBCJKhA64tIDT8qvX,Cm7xuRTdLQwZjv81V2AhKfqs04U,value in items:
			if ll5WFBCJKhA64tIDT8qvX in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			if 'الكل' in ll5WFBCJKhA64tIDT8qvX: continue
			ll5WFBCJKhA64tIDT8qvX = wAmsc95ya0LHz(ll5WFBCJKhA64tIDT8qvX)
			xhPQw3M2SrXTOm8B,II4x930lvTuVqekXBNCrMy = ll5WFBCJKhA64tIDT8qvX,ll5WFBCJKhA64tIDT8qvX
			II4x930lvTuVqekXBNCrMy = name+': '+xhPQw3M2SrXTOm8B
			dict[HLQNhXe7orPjl5Vm4][value] = II4x930lvTuVqekXBNCrMy
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&&'+HLQNhXe7orPjl5Vm4+'=='+xhPQw3M2SrXTOm8B
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&&'+HLQNhXe7orPjl5Vm4+'=='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			if type=='FILTERS':
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,url,255,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
			elif type=='CATEGORIES' and CyoSHprnasi3K0M[-2]+'==' in LLnTmNF7UG4:
				mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'modified_filters')
				ysw7G3tqjo = url+'//getposts??'+mmMRqiu1zXvWZlK7hAgEQn
				Da7e1Ruo9G = fPKulGyw2E(ysw7G3tqjo)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,Da7e1Ruo9G,251,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+II4x930lvTuVqekXBNCrMy,url,254,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
CyoSHprnasi3K0M = ['category','country','release-year']
JiKsdhqDNPuWzXxo3O2017TV = ['category','country','genre','release-year','language','quality','rate']
def fPKulGyw2E(url):
	VwZ0e96Ipdy8L = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',VwZ0e96Ipdy8L)
	url = url.replace('/category/اخرى',CJlTSEpZsWb0QHg5w)
	if VwZ0e96Ipdy8L not in url: url = url+VwZ0e96Ipdy8L
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&&')
	Sucv4JD0rRPaBL8HFMjNt,fuTzgEqmbRX378cwQnJH9rhFCt = {},CJlTSEpZsWb0QHg5w
	if '==' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('==')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	for key in JiKsdhqDNPuWzXxo3O2017TV:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if '%' not in value: value = O4Ak3NXpyUHvE(value)
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&&'+key+'=='+value
		elif mode=='all': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&&'+key+'=='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&&')
	return fuTzgEqmbRX378cwQnJH9rhFCt
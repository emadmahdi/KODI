# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'FASELHD1'
headers = {'User-Agent':CJlTSEpZsWb0QHg5w}
kL0nT7NpZdKVD3jM2OHB = '_FH1_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['جوائز الأوسكار','المراجعات','wwe']
def hH3sRBSFAr(mode,url,text):
	if   mode==570: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==571: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==572: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==573: SD0TxMRXiep4cjPBsnzI = bFsHpJmxDSgKNdReElj(url,text)
	elif mode==576: SD0TxMRXiep4cjPBsnzI = peThWgCnwGKZD8Q1bjIvdmSRfL9A4H()
	elif mode==579: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',kL0nT7NpZdKVD3jM2OHB+'لماذا الموقع بطيء',CJlTSEpZsWb0QHg5w,576)
	dmiXC1cB7MZlb,url = V4kF6EQiwo,V4kF6EQiwo
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD1-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',dmiXC1cB7MZlb,579,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المميزة',dmiXC1cB7MZlb,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured1')
	items = Zy2l0g8QU5vqefaTrsw.findall('class="h3">(.*?)<.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for title,ZgsbN5iSL48t2IhVFnmy in items:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details1')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"menu-primary"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		F6KPrYDQ9XmhI = Zy2l0g8QU5vqefaTrsw.findall('<li (.*?)</li>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		BfpVtayZ532mMiHoF0 = [CJlTSEpZsWb0QHg5w,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		LxNV5lenkhW6zoBJDMA7ZuqSg = 0
		for wtJK8x2e7QPUHqFvEnSp6N5yhO1CA in F6KPrYDQ9XmhI:
			if LxNV5lenkhW6zoBJDMA7ZuqSg>0: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',wtJK8x2e7QPUHqFvEnSp6N5yhO1CA,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy=='#': continue
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+ZgsbN5iSL48t2IhVFnmy
				if title==CJlTSEpZsWb0QHg5w: continue
				if any(value in title.lower() for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
				title = BfpVtayZ532mMiHoF0[LxNV5lenkhW6zoBJDMA7ZuqSg]+title
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details2')
			LxNV5lenkhW6zoBJDMA7ZuqSg += 1
	return
def peThWgCnwGKZD8Q1bjIvdmSRfL9A4H():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD1-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('class="h4">(.*?)</div>(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not KXu2RYg3Bc: return
	if type=='filters':
		s67485upzYNMS3PqDelkrdfo = [bGIVq1CQTjmosZg.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"homeSlide"(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		h7rNswEfSQKAI9YdVteJzl,Rp1g7OlotseGnf0NFmKk6rLxd,RYHIKeQZLBpbNvmhkq2GV1C = zip(*items)
		items = zip(Rp1g7OlotseGnf0NFmKk6rLxd,h7rNswEfSQKAI9YdVteJzl,RYHIKeQZLBpbNvmhkq2GV1C)
	elif type=='featured2':
		title,D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	elif type=='details2' and len(KXu2RYg3Bc)>1:
		title = KXu2RYg3Bc[0][0]
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured2')
		title = KXu2RYg3Bc[1][0]
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details3')
		return
	else:
		title,D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[-1]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
		if any(value in title.lower() for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
		hzGKUP1XjAoeT79MJcDF = pd0Na8D5WZfHYkysVS(hzGKUP1XjAoeT79MJcDF)
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.split('?resize=')[0]
		title = wAmsc95ya0LHz(title)
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة).\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if '/collections/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,571,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and type==CJlTSEpZsWb0QHg5w:
			title = '_MOD_'+ABK45TEMpciLnmIlYOafQJZ8t[0][0]
			title = title.strip(' –')
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,573,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif 'episodes/' in ZgsbN5iSL48t2IhVFnmy or 'movies/' in ZgsbN5iSL48t2IhVFnmy or 'hindi/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,572,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,573,hzGKUP1XjAoeT79MJcDF)
	if type=='filters':
		xtUMKHZFhcPR38DYErsi6JyT = Zy2l0g8QU5vqefaTrsw.findall('"more_button_page":(.*?),',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if xtUMKHZFhcPR38DYErsi6JyT:
			count = xtUMKHZFhcPR38DYErsi6JyT[0]
			ZgsbN5iSL48t2IhVFnmy = url+'/offset/'+count
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة أخرى',ZgsbN5iSL48t2IhVFnmy,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'filters')
	elif 'details' in type:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("class='pagination(.*?)</div>",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall("href='(.*?)'.*?>(.*?)<",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = 'صفحة '+wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,571,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'details4')
	return
def bFsHpJmxDSgKNdReElj(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD1-SEASONS_EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	K5ic8ROYfn1 = False
	if not type:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"seasonList"(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if len(items)>1:
				dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
				K5ic8ROYfn1 = True
				for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,name,title in items:
					name = wAmsc95ya0LHz(name)
					if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+ZgsbN5iSL48t2IhVFnmy
					title = name+' - '+title
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,573,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,'episodes')
	if type=='episodes' or not K5ic8ROYfn1:
		t4zynV13ZoPe = Zy2l0g8QU5vqefaTrsw.findall('"posterImg".*?src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if t4zynV13ZoPe: hzGKUP1XjAoeT79MJcDF = t4zynV13ZoPe[0]
		else: hzGKUP1XjAoeT79MJcDF = CJlTSEpZsWb0QHg5w
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"epAll"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,572,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ,QrwmKPNDRbUsOLHIBG,mqk6U7HgpIBNdl9fxJ0KzTsj = [],[],[]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'FASELHD1-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	kUZ2x0bjALaXpzdY4Ef7 = Zy2l0g8QU5vqefaTrsw.findall('مستوى المشاهدة.*?">(.*?)</span>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if kUZ2x0bjALaXpzdY4Ef7:
		aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('"tag">(.*?)</a>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"videoRow"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('&img=')[0]
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named=__embed')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="streamHeader(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall("href = '(.*?)'.*?</i>(.*?)</a>",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('&img=')[0]
			name = name.strip(YvOQBzaTAscXR9ql)
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__watch')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="downloadLinks(.*?)blackwindow',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</span>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('&img=')[0]
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__download')
	for VBvgS8MG7Qn in FhX9OGwaNyAEZ:
		ZgsbN5iSL48t2IhVFnmy,name = VBvgS8MG7Qn.split('?named')
		if ZgsbN5iSL48t2IhVFnmy not in QrwmKPNDRbUsOLHIBG:
			QrwmKPNDRbUsOLHIBG.append(ZgsbN5iSL48t2IhVFnmy)
			mqk6U7HgpIBNdl9fxJ0KzTsj.append(VBvgS8MG7Qn)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(mqk6U7HgpIBNdl9fxJ0KzTsj,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7,'details5')
	return
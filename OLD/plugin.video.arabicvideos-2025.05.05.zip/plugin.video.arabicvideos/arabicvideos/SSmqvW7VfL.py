# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from kUCfvjAP1c import *
T1QDsJlUtCGhn = I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
kL0nT7NpZdKVD3jM2OHB = HaTI5u1f3SCxmMAkw(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
YZimk2XwlKsVvhdextABUcI9gq4bP = tiFgl4DMvGEAUfjIYkHbr05.path.join(ORM3fVHnueUmCZhN57EF,JACnOz297UuDK5HpPkc1LF(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
jMhAJq0zgBvXOsliyYrZ = tiFgl4DMvGEAUfjIYkHbr05.path.join(ORM3fVHnueUmCZhN57EF,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
Y9mySW1euc4JNnLAD5sO = tiFgl4DMvGEAUfjIYkHbr05.path.join(p8QdZEXV573CWMLmY4bvO,GISOTJh20W(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),ZP1LyUCS3pIBu(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
SmLFEuhkNcxzR95VgaidjDZJGqIW7P = pz4WBwfyDdgk0m2aRr7SMv(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
imh4EaRlXWQspGOTKkj = zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
Xk6DsmjcCx2V94SPnag0Olqy = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
ZbJpE8vTl2g0ekCMdDcXoB76Oi = rC5tnFDlQcRGA2(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
WxXGvdU10Vq6h4AJRk2zuaKlp7cNZO = ZP1LyUCS3pIBu(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
tfv2zEWqc8PiSdX3CThlJGRB0Kew4Y = cjVhOCwybeRo7UWg92(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
VeQOZU4cpWaM320PhbARouLz = CD6FK0opq3A4cYJWN1RHeEUZvti
OOjgARmdz8PHvCFtseS9lV3i = c2XOIv1RU6aSuAeiZ5Pgz9Gr
HZO7VXnFdogWRhz = uuUjvrQcey5
def hH3sRBSFAr(BEUVvSQtRimC):
	if   BEUVvSQtRimC==TDpFsQXHze2q30uYtGPfEIm8(u"࠹࠷࠴ࣉ"): SD0TxMRXiep4cjPBsnzI = lmkE194N7BdQ6GrTz5()
	elif BEUVvSQtRimC==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠺࠸࠶࣊"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(YZimk2XwlKsVvhdextABUcI9gq4bP,w2qb6lf5EM,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==rC5tnFDlQcRGA2(u"࠻࠹࠸࣋"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(jMhAJq0zgBvXOsliyYrZ,w2qb6lf5EM,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠼࠺࠳࣌"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(Y9mySW1euc4JNnLAD5sO,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==cjVhOCwybeRo7UWg92(u"࠽࠴࠵࣍"): SD0TxMRXiep4cjPBsnzI = RaMoBLcVkr(w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==GISOTJh20W(u"࠷࠵࠷࣎"): SD0TxMRXiep4cjPBsnzI = IPAfhFJbCXtp8diUq0oaeGk(w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠸࠶࠹࣏"): SD0TxMRXiep4cjPBsnzI = WK3sJl4T9bCqxgjz5VSwR(w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==pz4WBwfyDdgk0m2aRr7SMv(u"࠹࠸࠴࣐"): SD0TxMRXiep4cjPBsnzI = f7X4qNIC2Aa0RZuJSxbGFVs()
	elif BEUVvSQtRimC==VVvcQpCU3OM09n(u"࠺࠹࠶࣑"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(SmLFEuhkNcxzR95VgaidjDZJGqIW7P,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠻࠺࠸࣒"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(imh4EaRlXWQspGOTKkj,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠼࠻࠳࣓"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(Xk6DsmjcCx2V94SPnag0Olqy,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠽࠵࠵ࣔ"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(ZbJpE8vTl2g0ekCMdDcXoB76Oi,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==GISOTJh20W(u"࠷࠶࠷ࣕ"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(WxXGvdU10Vq6h4AJRk2zuaKlp7cNZO,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==E6xdOMpqISHZCn(u"࠸࠷࠹ࣖ"): SD0TxMRXiep4cjPBsnzI = xyP9q8HGgDkNbL4WFnd5lfVh(tfv2zEWqc8PiSdX3CThlJGRB0Kew4Y,VJZIMkUN5siqB21Pf,w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==JACnOz297UuDK5HpPkc1LF(u"࠹࠸࠻ࣗ"): SD0TxMRXiep4cjPBsnzI = VazIn0L2Y9Xwh3MsfSHGUP4(w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==yylSaxCLfkte(u"࠺࠹࠽ࣘ"): SD0TxMRXiep4cjPBsnzI = vxzS6t4QoLlKTZcVuB1sWHCp0Fe2P();lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==yylSaxCLfkte(u"࠵࠵࠾࠰ࣙ"): SD0TxMRXiep4cjPBsnzI = MzhJCPvZDi1lfnYpxQX7EqAgIO()
	elif BEUVvSQtRimC==NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠶࠶࠸࠲ࣚ"): SD0TxMRXiep4cjPBsnzI = uVslTgK8XWM6(w2qb6lf5EM);lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==TMfV6892ZoBdyxCH3tGrkwY0K(u"࠷࠰࠹࠴ࣛ"): SD0TxMRXiep4cjPBsnzI = Wptz3MeQUb4loNhvryVOgdLE9CJjwf();lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==o2FdrDBimMuOw97q6QpNW8S(u"࠱࠱࠺࠶ࣜ"): SD0TxMRXiep4cjPBsnzI = U2YNDLE5l31jmzTguC7bw6I4RHy();lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==rC5tnFDlQcRGA2(u"࠲࠲࠻࠸ࣝ"): SD0TxMRXiep4cjPBsnzI = LLIqNlBi0Rf();lC30Z9Hv8pSdaAsEjwgDfc14QO(SD0TxMRXiep4cjPBsnzI)
	elif BEUVvSQtRimC==I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠳࠳࠼࠺ࣞ"): SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif BEUVvSQtRimC==xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠴࠴࠽࠼ࣟ"): SD0TxMRXiep4cjPBsnzI = FFgQvYpfGoluzLnH6ZjdkTIPqcwXr()
	else: SD0TxMRXiep4cjPBsnzI = VJZIMkUN5siqB21Pf
	return SD0TxMRXiep4cjPBsnzI
def FFgQvYpfGoluzLnH6ZjdkTIPqcwXr():
	k0kxuL3BiKy2ePQfTcdM = TMfV6892ZoBdyxCH3tGrkwY0K(u"࠵࠵࠸࠴࣠")*TMfV6892ZoBdyxCH3tGrkwY0K(u"࠵࠵࠸࠴࣠")
	V4PdMsLrtHI6Ya1GBKoUE9uZFOT = BBGMAjz64tElUg()//k0kxuL3BiKy2ePQfTcdM
	UuyG4PaMEClO = V4PdMsLrtHI6Ya1GBKoUE9uZFOT<o2FdrDBimMuOw97q6QpNW8S(u"࠺࠶࣡")
	size = Dj62UpP5MrbTkJqhRa+JACnOz297UuDK5HpPkc1LF(u"ࠩ็ำ๏้ࠠๆีสัฮࠦแศำ฽อࠥࠦࠧࠌ")+str(V4PdMsLrtHI6Ya1GBKoUE9uZFOT)+cbmeD4WNZfAowxT2JdUMtV(u"ࠪࠤ๋๊ࠥอษหห๏ะࠧࠍ")+oOQaRxBXyJ5jVnZ
	if UuyG4PaMEClO:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡈࡎࡅࡄࡍࡢࡈࡎ࡙ࡋࡠࡕࡓࡅࡈࡋࠠࠡࠢࡖࡘࡔࡘࡁࡈࡇࠣࡍࡘࠦࡆࡖࡎࡏࠤࠥࠦࠧࠎ")+str(V4PdMsLrtHI6Ya1GBKoUE9uZFOT)+Olh7n0zfV4(u"ࠬࠦࡍࡃࠢࠤࠥࠬࠏ"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,pz4WBwfyDdgk0m2aRr7SMv(u"࠭ๅิษะอࠥอไหะี๎๋ࠦแ๋ࠢฯ๋ฬุใࠡลุฬาะࠠๆ็อ่หฯࠠ࠯࠰ࠣ์์ึวࠡ์ึฬอࠦๅีษๆ่้ࠥห๋ำฬࠤๆ๐ࠠหึ฽๎้ࠦวๅฮ๊หื่ࠦหึ฽๎้ࠦใ้ัํࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥอๆหࠢหัฬาษࠡว็ํࠥะๆู์ไࠤัํวำๅࠣ์ฯ์ื๋ใࠣ็ํี๊๊ࠡอ๊฽๐แ้ࠡำหࠥอไษำ้ห๊า࡜࡯࡞ࡱࠫࠐ")+size)
	else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,GISOTJh20W(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠโ์ࠣะ์อาไࠢฯ๎ิฯ࡜࡯࡞ࡱࠫࠑ")+size)
	return UuyG4PaMEClO
def lC30Z9Hv8pSdaAsEjwgDfc14QO(M96zE51XBmQxVsF2ujiy):
	if M96zE51XBmQxVsF2ujiy: nYgsitVoc3E(w2qb6lf5EM)
	return
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠨ࡮࡬ࡲࡰ࠭ࠒ"),pz4WBwfyDdgk0m2aRr7SMv(u"ࠩไัฺࠦๅิษะอࠥอไหะี๎๋࠭ࠓ"),CJlTSEpZsWb0QHg5w,O4F8UC5lMAS6ghETm1VoPDI(u"࠷࠰࠹࠸࣢"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(cbmeD4WNZfAowxT2JdUMtV(u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠫฯ์ุ๋ใࠣห้า็ศิࠪࠕ"),CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"࠷࠶࠲ࣣ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(rC5tnFDlQcRGA2(u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠖ"),zz679V18GdcZwvrRexA0nNptY2Tab(u"࠭สแ่฻๎ๆࠦใแ๊า๎ࠬࠗ"),CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠸࠶࠳ࣤ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠘"),O4F8UC5lMAS6ghETm1VoPDI(u"ࠨฬ้฼๏็ࠠศๆหี๋อๅอࠩ࠙"),CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"࠳࠳࠼࠵ࣥ"))
	return
def MzhJCPvZDi1lfnYpxQX7EqAgIO():
	zKd6gnjwiSJtMvY2OA7D,G9UoRjc7LF = rbUyqKHmW1wG8cfetnRjDV5(VeQOZU4cpWaM320PhbARouLz)
	crkO7AVy6vZ,q2q0meSDNL6X7oB3sK = rbUyqKHmW1wG8cfetnRjDV5(OOjgARmdz8PHvCFtseS9lV3i)
	eCYSbM31zDrhiujokIyTspxBK9n4A,pk4gqrxXyHCGOdN7Ez9IJW = hhA3ineut0C1(HZO7VXnFdogWRhz)
	p1SI98gdHqFhv,nUT5bOAsvJY = zKd6gnjwiSJtMvY2OA7D+crkO7AVy6vZ+eCYSbM31zDrhiujokIyTspxBK9n4A,G9UoRjc7LF+q2q0meSDNL6X7oB3sK+pk4gqrxXyHCGOdN7Ez9IJW
	nUsbOI0kqGy = VVvcQpCU3OM09n(u"ࠩࠣࠬࠬࠚ")+eXbZaszqlfLw24mKSVGdrtvEo7(zKd6gnjwiSJtMvY2OA7D)+E6xdOMpqISHZCn(u"ࠪࠤ࠲ࠦࠧࠛ")+str(G9UoRjc7LF)+O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠜ")
	r0XwiCFev4oKqbZm5upBQk = cbmeD4WNZfAowxT2JdUMtV(u"ࠬࠦࠨࠨࠝ")+eXbZaszqlfLw24mKSVGdrtvEo7(crkO7AVy6vZ)+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭ࠠ࠮ࠢࠪࠞ")+str(q2q0meSDNL6X7oB3sK)+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠟ")
	wmq6DlWebQ8 = od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨࠢࠫࠫࠠ")+eXbZaszqlfLw24mKSVGdrtvEo7(eCYSbM31zDrhiujokIyTspxBK9n4A)+zQGaM7ctZCN(u"ࠩࠣ࠱ࠥ࠭ࠡ")+str(pk4gqrxXyHCGOdN7Ez9IJW)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠢ")
	ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5 = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫࠥ࠮ࠧࠣ")+eXbZaszqlfLw24mKSVGdrtvEo7(p1SI98gdHqFhv)+E6xdOMpqISHZCn(u"ࠬࠦ࠭ࠡࠩࠤ")+str(nUT5bOAsvJY)+I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࠥ")
	khqge7BVD9jPFy1S8T5Gn4QAlH(yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠧ࡭࡫ࡱ࡯ࠬࠦ"),kL0nT7NpZdKVD3jM2OHB+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࠧ")+ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"࠴࠴࠽࠺ࣦ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩ࡯࡭ࡳࡱࠧࠨ"),Dj62UpP5MrbTkJqhRa+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࠩ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,JACnOz297UuDK5HpPkc1LF(u"࠽࠾࠿࠹ࣧ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(otNfFapeEnO(u"ࠫࡱ࡯࡮࡬ࠩࠪ"),kL0nT7NpZdKVD3jM2OHB+O4F8UC5lMAS6ghETm1VoPDI(u"๋ࠬำฮุࠢ์ึࠦวๅๅอหอฯࠧࠫ")+nUsbOI0kqGy,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠶࠶࠸࠲ࣨ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(o2FdrDBimMuOw97q6QpNW8S(u"࠭࡬ࡪࡰ࡮ࠫࠬ"),kL0nT7NpZdKVD3jM2OHB+KA26GucUHOwXL(u"ࠧๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠪ࠭")+r0XwiCFev4oKqbZm5upBQk,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠷࠰࠹࠴ࣩ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(pz4WBwfyDdgk0m2aRr7SMv(u"ࠨ࡮࡬ࡲࡰ࠭࠮"),kL0nT7NpZdKVD3jM2OHB+cbmeD4WNZfAowxT2JdUMtV(u"่ࠩืาࠦลฺัสำฬะࠠศๆหี๋อๅอࠩ࠯")+wmq6DlWebQ8,CJlTSEpZsWb0QHg5w,TMfV6892ZoBdyxCH3tGrkwY0K(u"࠱࠱࠺࠶࣪"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(cjVhOCwybeRo7UWg92(u"ࠪࡰ࡮ࡴ࡫ࠨ࠰"),kL0nT7NpZdKVD3jM2OHB+otNfFapeEnO(u"ࠫฯ฻แ๋ำࠣห้ฮั็ษ่ะࠬ࠱")+ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,CJlTSEpZsWb0QHg5w,zz679V18GdcZwvrRexA0nNptY2Tab(u"࠲࠲࠻࠸࣫"))
	return
def LLIqNlBi0Rf():
	M96zE51XBmQxVsF2ujiy = VJZIMkUN5siqB21Pf
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬํไࠡฬิ๎ิࠦแฺๆสࠤู๊อࠡฮ่๎฾ࠦลฺัสำฬะࠠศๆหี๋อๅอࠢ࠱࠲ࠥ๎ๅิฯࠣะ๊๐ูࠡ็็ๅฬะࠠศๆหี๋อๅอࠢส่็ี๊ๆหࠣ࠲࠳ࠦอห๋ࠣ๎฾๎ฯࠡษ็ฬึ์วๆฮࠣษ้๏ࠠฮษ็อࠥอไึใิࠤ࠳࠴๋ࠠ฻้๎ࠥำวๅหࠣ์฻฿๊สูࠢฬ฼ࠦวๅ็ุ๊฾ࠦ࠮࠯ࠢํ฽๋๐ࠠศๆะห้ฯࠠศๆอ๎ࠥ๎ึฺ้สࠤฬ๊ๅษำ่ะ๊ࠥไษำ้ห๊าࠠ࠯࠰๋ࠣีํࠠศๆ฼้้๐ษࠡฬอ้ࠥฮๅิฯ้ࠣั๊ฯࠡๅสุࠥอไษำ้ห๊า้ࠠ็ึั๋ࠥไโࠢศ฽ิอฯศฬࠣห้ฮั็ษ่ะࠥลࠡࠨ࠲"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
		aP0NR42zw8BJZEgSDdrI3vQH = U2YNDLE5l31jmzTguC7bw6I4RHy()
		rvZL8M2l75dC4eVFHTxOmtK = xyP9q8HGgDkNbL4WFnd5lfVh(c2XOIv1RU6aSuAeiZ5Pgz9Gr,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
		M96zE51XBmQxVsF2ujiy = aP0NR42zw8BJZEgSDdrI3vQH and rvZL8M2l75dC4eVFHTxOmtK
		if M96zE51XBmQxVsF2ujiy: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ฬ๋ัࠣ࠲࠳ࠦๆอฯอࠤ฾๋ไ๋หุ้ࠣำࠠศๆ่่ๆอสࠡษ็ๆิ๐ๅสࠢ็่อืๆศ็ฯࠤ࠳࠴้ࠠ฻สำࠥอไษำ้ห๊าࠠฦๆ์ࠤํ฼ู๋หࠣห้฻แาࠢ࠱࠲ࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠳"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"ࠧๅๆฦืๆࠦ࠮࠯ࠢไุ้ะฺࠠ็็๎ฮࠦสึใํีࠥอไษำ้ห๊า้ࠠว฼หิะ็ࠡว็ํࠥ๎ึฺ์ฬࠤ฻ฮืࠡษ็ฺ้์ูࠨ࠴"))
	return M96zE51XBmQxVsF2ujiy
def Wptz3MeQUb4loNhvryVOgdLE9CJjwf():
	import tAoP1fdO67
	tAoP1fdO67.T7THw29fQO()
	cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(zQGaM7ctZCN(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ࠵"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭࠶"),VVvcQpCU3OM09n(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศࠢ࠱࠲ࠥ฿ไๆษࠣว๋ࠦวๅ็ึัࠥ๐สๆࠢอ่็อฦ๋ษࠣ฽๋ีࠠศ่อ๋ฬวฺࠠ็ิࠤฬ๊ีโฯสฮࠥ࠴࠮๊ࠡฦ๎฻อࠠศๆ่ืาࠦไศࠢํฺึ่ࠦๆ็ๆ๊ࠥ๐อๅࠢห฽฻ࠦวๅ็ืห่๊ࠧ࠷"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		cn0XyId7MkTCE1RifFhwQDN = xyP9q8HGgDkNbL4WFnd5lfVh(c2XOIv1RU6aSuAeiZ5Pgz9Gr,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
		if cn0XyId7MkTCE1RifFhwQDN: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,pz4WBwfyDdgk0m2aRr7SMv(u"ࠫา๐ฯࠡ࠰࠱ࠤ๋าอหࠢ฼้้๐ษࠡ็ึั๋ࠥฬๅัࠣ็ฬฺࠠศๆหี๋อๅอࠩ࠸"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"๊ࠬไฤีไࠤ࠳࠴ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤู๊อࠡ็ฯ่ิࠦใศึࠣห้ฮั็ษ่ะࠬ࠹"))
	return cn0XyId7MkTCE1RifFhwQDN
def U2YNDLE5l31jmzTguC7bw6I4RHy():
	cn0XyId7MkTCE1RifFhwQDN = VJZIMkUN5siqB21Pf
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡣࡦࡰࡷࡩࡷ࠭࠺"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"ࠧิฦส่ࠬ࠻"),HaTI5u1f3SCxmMAkw(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ࠼"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		try:
			tiFgl4DMvGEAUfjIYkHbr05.remove(uuUjvrQcey5)
			cn0XyId7MkTCE1RifFhwQDN = w2qb6lf5EM
		except: pass
		if cn0XyId7MkTCE1RifFhwQDN: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ࠽"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ࠾"))
	return cn0XyId7MkTCE1RifFhwQDN
def MzhJCPvZDi1lfnYpxQX7EqAgIO():
	zKd6gnjwiSJtMvY2OA7D,G9UoRjc7LF = rbUyqKHmW1wG8cfetnRjDV5(VeQOZU4cpWaM320PhbARouLz)
	crkO7AVy6vZ,q2q0meSDNL6X7oB3sK = rbUyqKHmW1wG8cfetnRjDV5(OOjgARmdz8PHvCFtseS9lV3i)
	eCYSbM31zDrhiujokIyTspxBK9n4A,pk4gqrxXyHCGOdN7Ez9IJW = hhA3ineut0C1(HZO7VXnFdogWRhz)
	p1SI98gdHqFhv,nUT5bOAsvJY = zKd6gnjwiSJtMvY2OA7D+crkO7AVy6vZ+eCYSbM31zDrhiujokIyTspxBK9n4A,G9UoRjc7LF+q2q0meSDNL6X7oB3sK+pk4gqrxXyHCGOdN7Ez9IJW
	nUsbOI0kqGy = HaTI5u1f3SCxmMAkw(u"ࠫࠥ࠮ࠧ࠿")+eXbZaszqlfLw24mKSVGdrtvEo7(zKd6gnjwiSJtMvY2OA7D)+EcjO3giln2kQTdBY0XLAG(u"ࠬࠦ࠭ࠡࠩࡀ")+str(G9UoRjc7LF)+o2FdrDBimMuOw97q6QpNW8S(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࡁ")
	r0XwiCFev4oKqbZm5upBQk = ZP1LyUCS3pIBu(u"ࠧࠡࠪࠪࡂ")+eXbZaszqlfLw24mKSVGdrtvEo7(crkO7AVy6vZ)+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࠢ࠰ࠤࠬࡃ")+str(q2q0meSDNL6X7oB3sK)+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡄ")
	wmq6DlWebQ8 = mi2ZJXCDzITuyev6gfn(u"ࠪࠤ࠭࠭ࡅ")+eXbZaszqlfLw24mKSVGdrtvEo7(eCYSbM31zDrhiujokIyTspxBK9n4A)+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࠥ࠳ࠠࠨࡆ")+str(pk4gqrxXyHCGOdN7Ez9IJW)+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡇ")
	ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5 = cbmeD4WNZfAowxT2JdUMtV(u"࠭ࠠࠩࠩࡈ")+eXbZaszqlfLw24mKSVGdrtvEo7(p1SI98gdHqFhv)+TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࠡ࠯ࠣࠫࡉ")+str(nUT5bOAsvJY)+HaTI5u1f3SCxmMAkw(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࡊ")
	khqge7BVD9jPFy1S8T5Gn4QAlH(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩ࡯࡭ࡳࡱࠧࡋ"),kL0nT7NpZdKVD3jM2OHB+TDpFsQXHze2q30uYtGPfEIm8(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࡌ")+ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"࠳࠳࠼࠹࣬"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠫࡱ࡯࡮࡬ࠩࡍ"),Dj62UpP5MrbTkJqhRa+o2FdrDBimMuOw97q6QpNW8S(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࡎ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,ZP1LyUCS3pIBu(u"࠼࠽࠾࠿࣭"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(XB4CjMkPFzhAHiI3q(u"࠭࡬ࡪࡰ࡮ࠫࡏ"),kL0nT7NpZdKVD3jM2OHB+E6xdOMpqISHZCn(u"ࠧๆีะࠤฺ๎ัࠡษ็็ฯอศสࠩࡐ")+nUsbOI0kqGy,CJlTSEpZsWb0QHg5w,E6xdOMpqISHZCn(u"࠵࠵࠾࠱࣮"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(cbmeD4WNZfAowxT2JdUMtV(u"ࠨ࡮࡬ࡲࡰ࠭ࡑ"),kL0nT7NpZdKVD3jM2OHB+EcjO3giln2kQTdBY0XLAG(u"่ࠩืาࠦใศึࠣห้ฮั็ษ่ะࠬࡒ")+r0XwiCFev4oKqbZm5upBQk,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠶࠶࠸࠳࣯"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(KA26GucUHOwXL(u"ࠪࡰ࡮ࡴ࡫ࠨࡓ"),kL0nT7NpZdKVD3jM2OHB+zQGaM7ctZCN(u"ู๊ࠫอࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠫࡔ")+wmq6DlWebQ8,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"࠷࠰࠹࠵ࣰ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬࡲࡩ࡯࡭ࠪࡕ"),kL0nT7NpZdKVD3jM2OHB+cbmeD4WNZfAowxT2JdUMtV(u"࠭สึใํีࠥอไษำ้ห๊าࠧࡖ")+ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"࠱࠱࠺࠷ࣱ"))
	return
def lmkE194N7BdQ6GrTz5():
	zKd6gnjwiSJtMvY2OA7D,G9UoRjc7LF = rbUyqKHmW1wG8cfetnRjDV5(YZimk2XwlKsVvhdextABUcI9gq4bP)
	crkO7AVy6vZ,q2q0meSDNL6X7oB3sK = rbUyqKHmW1wG8cfetnRjDV5(jMhAJq0zgBvXOsliyYrZ)
	eCYSbM31zDrhiujokIyTspxBK9n4A,pk4gqrxXyHCGOdN7Ez9IJW = rbUyqKHmW1wG8cfetnRjDV5(Y9mySW1euc4JNnLAD5sO)
	p1SI98gdHqFhv,nUT5bOAsvJY = hhA3ineut0C1(m5tz1IW6Es3SMKRAc)
	p1SI98gdHqFhv -= NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠴࠸࠻࠺࠹ࣲ")
	nUT5bOAsvJY -= P2Fgh6TCOWoaHjkqBcQnvRNXe
	BUNKAJQ3WLiVXbc = str(tiFgl4DMvGEAUfjIYkHbr05.listdir(nFM6jLciQ0zPA4Xb2hReVWSTqNv))
	q5cAel6VuQC7Spa3bLhWD = BUNKAJQ3WLiVXbc.count(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧ࡬ࡱࡧ࡭ࡤࡹࡴࡢࡥ࡮ࡸࡷࡧࡣࡦࠩࡗ"))+BUNKAJQ3WLiVXbc.count(TDpFsQXHze2q30uYtGPfEIm8(u"ࠨ࡭ࡲࡨ࡮ࡥࡣࡳࡣࡶ࡬ࡱࡵࡧࠨࡘ"))
	nUsbOI0kqGy = E6xdOMpqISHZCn(u"࡙ࠩࠣࠬࠬ")+eXbZaszqlfLw24mKSVGdrtvEo7(zKd6gnjwiSJtMvY2OA7D)+cbmeD4WNZfAowxT2JdUMtV(u"ࠪࠤ࠲࡚ࠦࠧ")+str(G9UoRjc7LF)+mi2ZJXCDzITuyev6gfn(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࡛࠭ࠬ")
	r0XwiCFev4oKqbZm5upBQk = CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࠦࠨࠨ࡜")+eXbZaszqlfLw24mKSVGdrtvEo7(crkO7AVy6vZ)+pz4WBwfyDdgk0m2aRr7SMv(u"࠭ࠠ࠮ࠢࠪ࡝")+str(q2q0meSDNL6X7oB3sK)+o2FdrDBimMuOw97q6QpNW8S(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࡞")
	wmq6DlWebQ8 = zQGaM7ctZCN(u"ࠨࠢࠫࠫ࡟")+eXbZaszqlfLw24mKSVGdrtvEo7(eCYSbM31zDrhiujokIyTspxBK9n4A)+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠩࠣ࠱ࠥ࠭ࡠ")+str(pk4gqrxXyHCGOdN7Ez9IJW)+I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡡ")
	ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5 = KA26GucUHOwXL(u"ࠫࠥ࠮ࠧࡢ")+eXbZaszqlfLw24mKSVGdrtvEo7(p1SI98gdHqFhv)+o2FdrDBimMuOw97q6QpNW8S(u"ࠬ࠯ࠧࡣ")
	kD2LSC3yNusaXc9j1p = Olh7n0zfV4(u"࠭ࠠࠩࠩࡤ")+str(q5cAel6VuQC7Spa3bLhWD)+O4F8UC5lMAS6ghETm1VoPDI(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࡥ")
	y4yjP6IWcJ9Mo2q0 = zKd6gnjwiSJtMvY2OA7D+crkO7AVy6vZ+eCYSbM31zDrhiujokIyTspxBK9n4A+p1SI98gdHqFhv
	oFhapJsiDT4W = G9UoRjc7LF+q2q0meSDNL6X7oB3sK+pk4gqrxXyHCGOdN7Ez9IJW+nUT5bOAsvJY+q5cAel6VuQC7Spa3bLhWD
	FMxeyLvnzabpJhCXgS6T = zQGaM7ctZCN(u"ࠨࠢࠫࠫࡦ")+eXbZaszqlfLw24mKSVGdrtvEo7(y4yjP6IWcJ9Mo2q0)+EcjO3giln2kQTdBY0XLAG(u"ࠩࠣ࠱ࠥ࠭ࡧ")+str(oFhapJsiDT4W)+EcjO3giln2kQTdBY0XLAG(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࡨ")
	khqge7BVD9jPFy1S8T5Gn4QAlH(JACnOz297UuDK5HpPkc1LF(u"ࠫࡱ࡯࡮࡬ࠩࡩ"),kL0nT7NpZdKVD3jM2OHB+ZP1LyUCS3pIBu(u"๋ࠬำฮࠢส่ัฺ๋๊ࠩࡪ")+FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,o2FdrDBimMuOw97q6QpNW8S(u"࠹࠷࠹ࣳ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(TDpFsQXHze2q30uYtGPfEIm8(u"࠭࡬ࡪࡰ࡮ࠫ࡫"),Dj62UpP5MrbTkJqhRa+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠧࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭࡬")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"࠼࠽࠾࠿ࣴ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ࡮࡬ࡲࡰ࠭࡭"),kL0nT7NpZdKVD3jM2OHB+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆ่ศ็ะษࠨ࡮")+nUsbOI0kqGy,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠻࠹࠷ࣵ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠪࡰ࡮ࡴ࡫ࠨ࡯"),kL0nT7NpZdKVD3jM2OHB+EcjO3giln2kQTdBY0XLAG(u"ู๊ࠫอࠡษ็้้็วหࠢส่๊฼ฺู้ฬࠫࡰ")+r0XwiCFev4oKqbZm5upBQk,CJlTSEpZsWb0QHg5w,I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠼࠺࠲ࣶ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࡲࡩ࡯࡭ࠪࡱ"),kL0nT7NpZdKVD3jM2OHB+cbmeD4WNZfAowxT2JdUMtV(u"࠭ๅิฯࠣห้฻่าࠢส่็ี๊ๆหࠪࡲ")+wmq6DlWebQ8,CJlTSEpZsWb0QHg5w,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠽࠴࠴ࣷ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(ZP1LyUCS3pIBu(u"ࠧ࡭࡫ࡱ࡯ࠬࡳ"),kL0nT7NpZdKVD3jM2OHB+h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠨฬไี๏เࠠๆๆไࠤฺ๎ัࠡษ็ษ฻อแศฬࠪࡴ")+ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,CJlTSEpZsWb0QHg5w,KA26GucUHOwXL(u"࠷࠵࠶ࣸ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠩ࡯࡭ࡳࡱࠧࡵ"),kL0nT7NpZdKVD3jM2OHB+XB4CjMkPFzhAHiI3q(u"ุ้ࠪำࠠๆๆไหฯࠦวๅๅิหูࠦวๅ็วๆฯฯࠧࡶ")+kD2LSC3yNusaXc9j1p,CJlTSEpZsWb0QHg5w,otNfFapeEnO(u"࠸࠶࠹ࣹ"))
	return
def f7X4qNIC2Aa0RZuJSxbGFVs():
	gKcWk5CTFt8Ej = w2qb6lf5EM if VVvcQpCU3OM09n(u"ࠫ࠴࠭ࡷ") in p8QdZEXV573CWMLmY4bvO else VJZIMkUN5siqB21Pf
	if not gKcWk5CTFt8Ej:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cjVhOCwybeRo7UWg92(u"ࠬ฿ๅๅ์ฬࠤฯ์ุ๋ใࠣห้า็ศิ้ࠣฯ๎แาหࠣๅ็฽ࠠๅลฯ๋ืฯ๋๊้ࠠ็ุࠦ࠮࠯่ࠢฯ้ࠦรอ้ีอࠥษศๅ๋ࠢว๋ีั้์าࠤํ๊๊้่ๆืࠥ࠴࠮๊ࠡฯ๋ฬุใࠡๆํื๋ࠥๆ้ࠡำหࠥอไ็๊฼ࠫࡸ"))
		return
	QgwJd8Sfs07zyqlmiKWRrCP9Dn = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(cbmeD4WNZfAowxT2JdUMtV(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪࡹ"))
	if not QgwJd8Sfs07zyqlmiKWRrCP9Dn: vxzS6t4QoLlKTZcVuB1sWHCp0Fe2P()
	zKd6gnjwiSJtMvY2OA7D,G9UoRjc7LF = rbUyqKHmW1wG8cfetnRjDV5(SmLFEuhkNcxzR95VgaidjDZJGqIW7P)
	crkO7AVy6vZ,q2q0meSDNL6X7oB3sK = rbUyqKHmW1wG8cfetnRjDV5(imh4EaRlXWQspGOTKkj)
	eCYSbM31zDrhiujokIyTspxBK9n4A,pk4gqrxXyHCGOdN7Ez9IJW = rbUyqKHmW1wG8cfetnRjDV5(Xk6DsmjcCx2V94SPnag0Olqy)
	p1SI98gdHqFhv,nUT5bOAsvJY = rbUyqKHmW1wG8cfetnRjDV5(ZbJpE8vTl2g0ekCMdDcXoB76Oi)
	R5Re8tyJQuSla0,q5cAel6VuQC7Spa3bLhWD = rbUyqKHmW1wG8cfetnRjDV5(WxXGvdU10Vq6h4AJRk2zuaKlp7cNZO)
	ulV5GrSK3yxJM,QQKWRO5VGloHgeDj = rbUyqKHmW1wG8cfetnRjDV5(tfv2zEWqc8PiSdX3CThlJGRB0Kew4Y)
	nUsbOI0kqGy = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠧࠡࠪࠪࡺ")+eXbZaszqlfLw24mKSVGdrtvEo7(zKd6gnjwiSJtMvY2OA7D)+EcjO3giln2kQTdBY0XLAG(u"ࠨࠢ࠰ࠤࠬࡻ")+str(G9UoRjc7LF)+O4F8UC5lMAS6ghETm1VoPDI(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪࡼ")
	r0XwiCFev4oKqbZm5upBQk = yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࠤ࠭࠭ࡽ")+eXbZaszqlfLw24mKSVGdrtvEo7(crkO7AVy6vZ)+zQGaM7ctZCN(u"ࠫࠥ࠳ࠠࠨࡾ")+str(q2q0meSDNL6X7oB3sK)+GISOTJh20W(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭ࡿ")
	wmq6DlWebQ8 = rC5tnFDlQcRGA2(u"࠭ࠠࠩࠩࢀ")+eXbZaszqlfLw24mKSVGdrtvEo7(eCYSbM31zDrhiujokIyTspxBK9n4A)+rC5tnFDlQcRGA2(u"ࠧࠡ࠯ࠣࠫࢁ")+str(pk4gqrxXyHCGOdN7Ez9IJW)+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩࢂ")
	ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5 = ZP1LyUCS3pIBu(u"ࠩࠣࠬࠬࢃ")+eXbZaszqlfLw24mKSVGdrtvEo7(p1SI98gdHqFhv)+EcjO3giln2kQTdBY0XLAG(u"ࠪࠤ࠲ࠦࠧࢄ")+str(nUT5bOAsvJY)+Olh7n0zfV4(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࢅ")
	kD2LSC3yNusaXc9j1p = h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠬࠦࠨࠨࢆ")+eXbZaszqlfLw24mKSVGdrtvEo7(R5Re8tyJQuSla0)+VVvcQpCU3OM09n(u"࠭ࠠ࠮ࠢࠪࢇ")+str(q5cAel6VuQC7Spa3bLhWD)+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࢈")
	okUgf91AYt = cbmeD4WNZfAowxT2JdUMtV(u"ࠨࠢࠫࠫࢉ")+eXbZaszqlfLw24mKSVGdrtvEo7(ulV5GrSK3yxJM)+pz4WBwfyDdgk0m2aRr7SMv(u"ࠩࠣ࠱ࠥ࠭ࢊ")+str(QQKWRO5VGloHgeDj)+VVvcQpCU3OM09n(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࢋ")
	y4yjP6IWcJ9Mo2q0 = zKd6gnjwiSJtMvY2OA7D+crkO7AVy6vZ+eCYSbM31zDrhiujokIyTspxBK9n4A+p1SI98gdHqFhv+R5Re8tyJQuSla0+ulV5GrSK3yxJM
	oFhapJsiDT4W = G9UoRjc7LF+q2q0meSDNL6X7oB3sK+pk4gqrxXyHCGOdN7Ez9IJW+nUT5bOAsvJY+q5cAel6VuQC7Spa3bLhWD+QQKWRO5VGloHgeDj
	FMxeyLvnzabpJhCXgS6T = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࠥ࠮ࠧࢌ")+eXbZaszqlfLw24mKSVGdrtvEo7(y4yjP6IWcJ9Mo2q0)+KA26GucUHOwXL(u"ࠬࠦ࠭ࠡࠩࢍ")+str(oFhapJsiDT4W)+yylSaxCLfkte(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧࢎ")
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠧ࡭࡫ࡱ࡯ࠬ࢏"),kL0nT7NpZdKVD3jM2OHB+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠨว฼฻ฬวࠠาะุอ่ࠥัศรฬࠤํ้สศสฬࠫ࢐"),CJlTSEpZsWb0QHg5w,VVvcQpCU3OM09n(u"࠹࠸࠼ࣺ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠩ࡯࡭ࡳࡱࠧ࢑"),kL0nT7NpZdKVD3jM2OHB+XB4CjMkPFzhAHiI3q(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧ࢒")+FMxeyLvnzabpJhCXgS6T,CJlTSEpZsWb0QHg5w,rC5tnFDlQcRGA2(u"࠺࠹࠼ࣻ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(JACnOz297UuDK5HpPkc1LF(u"ࠫࡱ࡯࡮࡬ࠩ࢓"),Dj62UpP5MrbTkJqhRa+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫ࢔")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,HaTI5u1f3SCxmMAkw(u"࠽࠾࠿࠹ࣼ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(s97s2k0LJgl(u"࠭࡬ࡪࡰ࡮ࠫ࢕"),kL0nT7NpZdKVD3jM2OHB+GISOTJh20W(u"ࠧๆีะࠤ๊๊แศฬࠣࡹࡸࡧࡧࡦࡵࡷࡥࡹࡹࠧ࢖")+nUsbOI0kqGy,CJlTSEpZsWb0QHg5w,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠼࠻࠱ࣽ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨ࡮࡬ࡲࡰ࠭ࢗ"),kL0nT7NpZdKVD3jM2OHB+EcjO3giln2kQTdBY0XLAG(u"่ࠩืาࠦๅๅใสฮࠥࡪࡲࡰࡲࡥࡳࡽ࠭࢘")+r0XwiCFev4oKqbZm5upBQk,CJlTSEpZsWb0QHg5w,pz4WBwfyDdgk0m2aRr7SMv(u"࠽࠵࠳ࣾ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(yylSaxCLfkte(u"ࠪࡰ࡮ࡴ࡫ࠨ࢙"),kL0nT7NpZdKVD3jM2OHB+o2FdrDBimMuOw97q6QpNW8S(u"ู๊ࠫอࠡ็็ๅฬะࠠࡵࡱࡰࡦࡸࡺ࡯࡯ࡧࡶ࢚ࠫ")+wmq6DlWebQ8,CJlTSEpZsWb0QHg5w,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠷࠶࠵ࣿ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࡲࡩ࡯࡭࢛ࠪ"),kL0nT7NpZdKVD3jM2OHB+mi2ZJXCDzITuyev6gfn(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࡭ࡥࡳࠩ࢜")+ZHnxD46eqyXtbWs1ToKpkVhY8R9EM5,CJlTSEpZsWb0QHg5w,cbmeD4WNZfAowxT2JdUMtV(u"࠸࠷࠷ऀ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(GISOTJh20W(u"ࠧ࡭࡫ࡱ࡯ࠬ࢝"),kL0nT7NpZdKVD3jM2OHB+s97s2k0LJgl(u"ࠨ็ึั๋ࠥไโษอࠤࡱࡵࡧࠨ࢞")+kD2LSC3yNusaXc9j1p,CJlTSEpZsWb0QHg5w,TDpFsQXHze2q30uYtGPfEIm8(u"࠹࠸࠹ँ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(HaTI5u1f3SCxmMAkw(u"ࠩ࡯࡭ࡳࡱࠧ࢟"),kL0nT7NpZdKVD3jM2OHB+O4F8UC5lMAS6ghETm1VoPDI(u"ุ้ࠪำࠠๆๆไหฯࠦࡡ࡯ࡴࠪࢠ")+okUgf91AYt,CJlTSEpZsWb0QHg5w,h6sIkJOT5PB2vCxqo4LFag70wA(u"࠺࠹࠻ं"))
	return
def uVslTgK8XWM6(showDialogs):
	if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"๊ࠫาไะุࠢ์ึࠦใหษหอࠥอไใ๊สส๊ࠦ࠮࠯๊ࠢิฬࠦวๅ็ฯ่ิࠦแ๋้ࠣฬ฾฼ࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ็ัึ๋ฯࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳࠴ฺ่ࠠาࠤู๊อࠡษ็้ั๊ฯࠡีํๆํ๋ࠠศๆหี๋อๅอࠢหา้่ࠠๆฮ็ำࠥาฯ๋ัࠣ์๏ฮฯฤ่ࠢีฮࠦรฯำ์ࠤอ๋ไว้ࠣฬฬ๊ี้ำࠣ฽๋ีࠠโฬะࠤฬ๊โ้ษษ้ࠬࢡ"))
	AkxtBgzcH9mnoM,qTedJDzRGYwO6EbSo = [],ZVNvqy4iF1a9X
	for mv9lp6NGakCrdLsYP,U6thsi8ELAN,SUgOhZo14jAJNrKnGLYBpz2QH in tiFgl4DMvGEAUfjIYkHbr05.walk(CD6FK0opq3A4cYJWN1RHeEUZvti,topdown=VJZIMkUN5siqB21Pf):
		EYFkz02Jw7Daq1RWmABOUpGC46tVL = len(SUgOhZo14jAJNrKnGLYBpz2QH)
		if EYFkz02Jw7Daq1RWmABOUpGC46tVL>CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠹࠵࠶ः"): AkxtBgzcH9mnoM.append(U6thsi8ELAN)
		qTedJDzRGYwO6EbSo += EYFkz02Jw7Daq1RWmABOUpGC46tVL
	YszKq2LrXvutnP7Gy9c0eZl = qTedJDzRGYwO6EbSo>GISOTJh20W(u"࠺࠶࠰࠱ऄ")
	if showDialogs:
		count = Dj62UpP5MrbTkJqhRa+rC5tnFDlQcRGA2(u"๊ࠬฯ๋ๅࠣࠤࠬࢢ")+str(qTedJDzRGYwO6EbSo)+cjVhOCwybeRo7UWg92(u"࠭ࠠࠡื๋ีฮ࠭ࢣ")+oOQaRxBXyJ5jVnZ
		if not AkxtBgzcH9mnoM and not YszKq2LrXvutnP7Gy9c0eZl: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧๅษࠣ๎ําฯࠡ฻้ำ่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬࠦสฮฬสะࠥษๆࠡฬ่ืาࠦี้ำࠣห้้สศสฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡ็ึัࠥ฻่าࠢส่่ะวษหࠣห้ศๆࠡมࠤࠤࡡࡴ࡜࡯ࠩࢤ")+count)
		else: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨๆา๎่ࠦี้ำࠣ็ฯอศสࠢๆฯ๏ืษࠡ࠰࠱ࠤํํะศࠢๅำࠥ๐ำษสู้ࠣอใๅࠢไ๎ࠥะิ฻์็ࠤฬ๊ฬ่ษีࠤํะิ฻์็ࠤอืๆศ็ฯࠤ฾๋วะࠢ࠱࠲ࠥษๆหࠢหัฬาษࠡว็ํ๋ࠥำฮ๊ࠢิ์ࠦวๅื๋ีࠥ࠴࠮้ࠡ็ࠤฯื๊ะ่ࠢืาࠦี้ำࠣห้้สศสฬࠤฬ๊ย็ࠢยࠥࠥࡢ࡮࡝ࡰࠪࢥ")+count)
	else: Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = P2Fgh6TCOWoaHjkqBcQnvRNXe
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==P2Fgh6TCOWoaHjkqBcQnvRNXe:
		if YszKq2LrXvutnP7Gy9c0eZl: xyP9q8HGgDkNbL4WFnd5lfVh(mv9lp6NGakCrdLsYP,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
		elif AkxtBgzcH9mnoM:
			for U6thsi8ELAN in AkxtBgzcH9mnoM: xyP9q8HGgDkNbL4WFnd5lfVh(U6thsi8ELAN,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	return
def vxzS6t4QoLlKTZcVuB1sWHCp0Fe2P():
	M96zE51XBmQxVsF2ujiy = VJZIMkUN5siqB21Pf
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"ࠩ็็๏ฺ๊ࠦ็็ࠤฬ๊ส็ฺํๅࠥ฿ๆะๅࠣ࠲࠳ࠦศา่ส้ัูࠦๆษาࠤอำวอหࠣษ้๏ࠠฦ฻ฺหฦࠦัฯืฬࠤฬ๊โาษฤอࠥ๎วๅๅอหอฯࠠๅๆ่่ๆอส๊ࠡส่๊าไะษอࠤฬ๊ส๋ࠢึ์ๆ๊ࠦๆีะ๋ฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤ์๊ࠠหำํำࠥหูุษฤࠤ์ึ็ࠡษ็ีำ฻ษࠡษ็ฦ๋ࠦฟࠢࠩࢦ"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==-mi2ZJXCDzITuyev6gfn(u"࠷अ"): return
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa:
		import subprocess as Ir7UnQluDMZvm6
		try:
			Ir7UnQluDMZvm6.Popen(JACnOz297UuDK5HpPkc1LF(u"ࠪࡷࡺ࠭ࢧ"))
			M96zE51XBmQxVsF2ujiy = w2qb6lf5EM
		except: pass
		if M96zE51XBmQxVsF2ujiy:
			E5Zohl30DnIe8b = SmLFEuhkNcxzR95VgaidjDZJGqIW7P+YvOQBzaTAscXR9ql+imh4EaRlXWQspGOTKkj+YvOQBzaTAscXR9ql+Xk6DsmjcCx2V94SPnag0Olqy+YvOQBzaTAscXR9ql+ZbJpE8vTl2g0ekCMdDcXoB76Oi+YvOQBzaTAscXR9ql+WxXGvdU10Vq6h4AJRk2zuaKlp7cNZO+YvOQBzaTAscXR9ql+tfv2zEWqc8PiSdX3CThlJGRB0Kew4Y
			TxNJOY3lR85qfL = Ir7UnQluDMZvm6.Popen(KA26GucUHOwXL(u"ࠫࡸࡻࠠ࠮ࡥࠣࠦࡨ࡮࡭ࡰࡦࠣ࠱ࡗࠦ࠰࠸࠹࠺ࠤࠬࢨ")+E5Zohl30DnIe8b+O4F8UC5lMAS6ghETm1VoPDI(u"ࠬࠨࠧࢩ"),shell=w2qb6lf5EM,stdin=Ir7UnQluDMZvm6.PIPE,stdout=Ir7UnQluDMZvm6.PIPE,stderr=Ir7UnQluDMZvm6.PIPE)
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,XB4CjMkPFzhAHiI3q(u"࠭ๆอฯอࠤ฾๋ไ๋หࠣษ฾฽วยࠢส่ึิีสࠩࢪ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,XB4CjMkPFzhAHiI3q(u"ฺࠧ็็๎ฮࠦลฺูสลࠥืฮึหࠣห้่ัศรฬࠤํอไไฬสฬฮࠦสฮฬสะࠥฮั็ษ่ะࠥࠦࡲࡰࡱࡷࠤࠥษ่ࠡࠢࡶࡹࡵ࡫ࡲࡶࡵࡨࡶࠥࠦร้ࠢࠣࡷࡺ้ࠦࠠฮ๊หื้ࠠๅษࠣ๎ําฯࠡใํ๋ࠥํะศࠢส่อืๆศ็ฯࠤ࠳࠴ࠠฤ๊ࠣ็ํี๊ࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠศีอาิอๅ้ࠡำหࠥอไษำ้ห๊าࠧࢫ"))
	return M96zE51XBmQxVsF2ujiy
def eXbZaszqlfLw24mKSVGdrtvEo7(y4yjP6IWcJ9Mo2q0):
	for CCdTQs87pLuoFG2ykKXAYU14zgv in [TDpFsQXHze2q30uYtGPfEIm8(u"ࠨࡄࠪࢬ"),XB4CjMkPFzhAHiI3q(u"ࠩࡎࡆࠬࢭ"),ZP1LyUCS3pIBu(u"ࠪࡑࡇ࠭ࢮ"),cbmeD4WNZfAowxT2JdUMtV(u"ࠫࡌࡈࠧࢯ"),yUMRP0QKIzY9BDnsV784TZmwkf(u"࡚ࠬࡂࠨࢰ")]:
		if y4yjP6IWcJ9Mo2q0<NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠱࠱࠴࠷आ"): break
		else: y4yjP6IWcJ9Mo2q0 /= pz4WBwfyDdgk0m2aRr7SMv(u"࠲࠲࠵࠸࠳࠶इ")
	FMxeyLvnzabpJhCXgS6T = yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠨࠥ࠴࠰࠴ࡪࠥࠫࡳࠣࢱ")%(y4yjP6IWcJ9Mo2q0,CCdTQs87pLuoFG2ykKXAYU14zgv)
	return FMxeyLvnzabpJhCXgS6T
def rbUyqKHmW1wG8cfetnRjDV5(MWT38j9uRIfNHxhDdm7FAkv=cjVhOCwybeRo7UWg92(u"ࠧ࠯ࠩࢲ")):
	global vvAZumYSsJKcoTikP,QWX6a9JD0bqiNAzHBY3K
	vvAZumYSsJKcoTikP,QWX6a9JD0bqiNAzHBY3K = ZVNvqy4iF1a9X,ZVNvqy4iF1a9X
	def IIPHgZDiou(MWT38j9uRIfNHxhDdm7FAkv):
		global vvAZumYSsJKcoTikP,QWX6a9JD0bqiNAzHBY3K
		if tiFgl4DMvGEAUfjIYkHbr05.path.exists(MWT38j9uRIfNHxhDdm7FAkv):
			if ZVNvqy4iF1a9X and pz4WBwfyDdgk0m2aRr7SMv(u"ࠨࡵࡦࡥࡳࡪࡩࡳࠩࢳ") in dir(tiFgl4DMvGEAUfjIYkHbr05):
				for EEkBu71bOsLKdRgHPq in tiFgl4DMvGEAUfjIYkHbr05.scandir(MWT38j9uRIfNHxhDdm7FAkv):
					if EEkBu71bOsLKdRgHPq.is_dir(follow_symlinks=VJZIMkUN5siqB21Pf):
						IIPHgZDiou(EEkBu71bOsLKdRgHPq.path)
					elif EEkBu71bOsLKdRgHPq.is_file(follow_symlinks=VJZIMkUN5siqB21Pf):
						vvAZumYSsJKcoTikP += EEkBu71bOsLKdRgHPq.stat().st_size
						QWX6a9JD0bqiNAzHBY3K += P2Fgh6TCOWoaHjkqBcQnvRNXe
			else:
				for EEkBu71bOsLKdRgHPq in tiFgl4DMvGEAUfjIYkHbr05.listdir(MWT38j9uRIfNHxhDdm7FAkv):
					SJpuo5RyUOmY1sZXN2HGM = tiFgl4DMvGEAUfjIYkHbr05.path.abspath(tiFgl4DMvGEAUfjIYkHbr05.path.join(MWT38j9uRIfNHxhDdm7FAkv,EEkBu71bOsLKdRgHPq))
					if tiFgl4DMvGEAUfjIYkHbr05.path.isdir(SJpuo5RyUOmY1sZXN2HGM):
						IIPHgZDiou(SJpuo5RyUOmY1sZXN2HGM)
					elif tiFgl4DMvGEAUfjIYkHbr05.path.isfile(SJpuo5RyUOmY1sZXN2HGM):
						y4yjP6IWcJ9Mo2q0,oFhapJsiDT4W = hhA3ineut0C1(SJpuo5RyUOmY1sZXN2HGM)
						vvAZumYSsJKcoTikP += y4yjP6IWcJ9Mo2q0
						QWX6a9JD0bqiNAzHBY3K += oFhapJsiDT4W
		return
	try: IIPHgZDiou(MWT38j9uRIfNHxhDdm7FAkv)
	except: pass
	return vvAZumYSsJKcoTikP,QWX6a9JD0bqiNAzHBY3K
def IPAfhFJbCXtp8diUq0oaeGk(showDialogs):
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Dj62UpP5MrbTkJqhRa+O4F8UC5lMAS6ghETm1VoPDI(u"๊่ࠩࠥะั๋ัุ้ࠣำࠧࢴ")+rJ9cgWz4FU+TMfV6892ZoBdyxCH3tGrkwY0K(u"้ࠪั๊ฯࠡษ็้้็วหࠢส่๊สโหหࠣ࠲࠳่ࠦๆฮ็ำࠥอไๆๆไหฯࠦวๅ็ู฾ํ฽ษࠡ࠰࠱ࠤํ๋ฬๅัࠣห้฻่าࠢส่็ี๊ๆหࠣ࠲࠳่ࠦหใิ๎฿ࠦๅๅใูࠣํืࠠศๆศฺฬ็วหࠢ࠱࠲ࠥ๎ๅๅใสฮࠥอไไำสุࠬࢵ")+rJ9cgWz4FU+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫฤࠧࠡࠨࢶ")+oOQaRxBXyJ5jVnZ)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=P2Fgh6TCOWoaHjkqBcQnvRNXe: return
	eyXJEL9ItiZmb = xyP9q8HGgDkNbL4WFnd5lfVh(YZimk2XwlKsVvhdextABUcI9gq4bP,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
	WmeyIH4P7ilrJQK3p = xyP9q8HGgDkNbL4WFnd5lfVh(jMhAJq0zgBvXOsliyYrZ,w2qb6lf5EM,VJZIMkUN5siqB21Pf)
	NPdmcKJ6YlUgF8GfqDpjt2Ar = xyP9q8HGgDkNbL4WFnd5lfVh(Y9mySW1euc4JNnLAD5sO,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	ffqRW0kZ2YcSo = RaMoBLcVkr(VJZIMkUN5siqB21Pf)
	BaNQCDRd8yjJ9ZY = WK3sJl4T9bCqxgjz5VSwR(VJZIMkUN5siqB21Pf)
	succeeded = all([eyXJEL9ItiZmb,WmeyIH4P7ilrJQK3p,NPdmcKJ6YlUgF8GfqDpjt2Ar,ffqRW0kZ2YcSo,BaNQCDRd8yjJ9ZY])
	if showDialogs:
		if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,cbmeD4WNZfAowxT2JdUMtV(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ࢷ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Olh7n0zfV4(u"࠭ไๅลึๅࠥ็ิๅฬࠣ฽๊๊๊สࠢสู่๊อࠨࢸ"))
	return succeeded
def VazIn0L2Y9Xwh3MsfSHGUP4(showDialogs):
	if showDialogs:
		E5Zohl30DnIe8b = SmLFEuhkNcxzR95VgaidjDZJGqIW7P+rJ9cgWz4FU+imh4EaRlXWQspGOTKkj+rJ9cgWz4FU+Xk6DsmjcCx2V94SPnag0Olqy+rJ9cgWz4FU+ZbJpE8vTl2g0ekCMdDcXoB76Oi+rJ9cgWz4FU+WxXGvdU10Vq6h4AJRk2zuaKlp7cNZO+rJ9cgWz4FU+tfv2zEWqc8PiSdX3CThlJGRB0Kew4Y
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Dj62UpP5MrbTkJqhRa+ZP1LyUCS3pIBu(u"่ࠧๆࠣฮึ๐ฯࠡ็ึัࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠศๆอ๎ࠥ็๊้ࠡำ๋ࠥอไๆฮ็ำฬะ࡜࡯࡞ࡱࠫࢹ")+E5Zohl30DnIe8b+oOQaRxBXyJ5jVnZ)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=P2Fgh6TCOWoaHjkqBcQnvRNXe: return
	eyXJEL9ItiZmb = xyP9q8HGgDkNbL4WFnd5lfVh(SmLFEuhkNcxzR95VgaidjDZJGqIW7P,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	WmeyIH4P7ilrJQK3p = xyP9q8HGgDkNbL4WFnd5lfVh(imh4EaRlXWQspGOTKkj,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	NPdmcKJ6YlUgF8GfqDpjt2Ar = xyP9q8HGgDkNbL4WFnd5lfVh(Xk6DsmjcCx2V94SPnag0Olqy,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	ffqRW0kZ2YcSo = xyP9q8HGgDkNbL4WFnd5lfVh(ZbJpE8vTl2g0ekCMdDcXoB76Oi,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	BaNQCDRd8yjJ9ZY = xyP9q8HGgDkNbL4WFnd5lfVh(WxXGvdU10Vq6h4AJRk2zuaKlp7cNZO,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	xr0hG9CaOAi7 = xyP9q8HGgDkNbL4WFnd5lfVh(tfv2zEWqc8PiSdX3CThlJGRB0Kew4Y,VJZIMkUN5siqB21Pf,VJZIMkUN5siqB21Pf)
	succeeded = all([eyXJEL9ItiZmb,WmeyIH4P7ilrJQK3p,NPdmcKJ6YlUgF8GfqDpjt2Ar,ffqRW0kZ2YcSo,BaNQCDRd8yjJ9ZY,xr0hG9CaOAi7])
	if showDialogs:
		if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,JACnOz297UuDK5HpPkc1LF(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࢺ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,pz4WBwfyDdgk0m2aRr7SMv(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࢻ"))
	return succeeded
def RaMoBLcVkr(showDialogs):
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,Dj62UpP5MrbTkJqhRa+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"๋้ࠪࠦสา์าࠤู๊อࠡ็ะฮํ๐วห่่ࠢๆࠦี้ำࠣห้าไะࠢยࠥࠦ࠭ࢼ")+oOQaRxBXyJ5jVnZ)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=zz679V18GdcZwvrRexA0nNptY2Tab(u"࠳ई"): return zz679V18GdcZwvrRexA0nNptY2Tab(u"ࡉࡥࡱࡹࡥउ")
	try:
		succeeded = JACnOz297UuDK5HpPkc1LF(u"ࡘࡷࡻࡥऊ")
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX = Izg3hVy4Nx1oOU6L29DFkmqnZ.connect(m5tz1IW6Es3SMKRAc)
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.text_factory = str
		CUYvKkg403sS1yxGoTbWDhJAXN = PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.cursor()
		CUYvKkg403sS1yxGoTbWDhJAXN.execute(Olh7n0zfV4(u"ࠫࡉࡋࡌࡆࡖࡈࠤࡋࡘࡏࡎࠢࡳࡥࡹ࡮࠻ࠨࢽ"))
		CUYvKkg403sS1yxGoTbWDhJAXN.execute(ZP1LyUCS3pIBu(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡷ࡮ࢀࡥࡴ࠽ࠪࢾ"))
		CUYvKkg403sS1yxGoTbWDhJAXN.execute(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡹ࡫ࡸࡵࡷࡵࡩࡀ࠭ࢿ"))
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.commit()
		CUYvKkg403sS1yxGoTbWDhJAXN.execute(pz4WBwfyDdgk0m2aRr7SMv(u"ࠧࡗࡃࡆ࡙࡚ࡓ࠻ࠨࣀ"))
		PBrsIxTjg1ec3VO0zJKl5oYLRpFUX.close()
	except: succeeded = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࡋࡧ࡬ࡴࡧऋ")
	if showDialogs:
		if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KA26GucUHOwXL(u"ࠨฬ่ࠤฬ๊ๅิฯࠣฬ๋าวฮࠩࣁ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,O4F8UC5lMAS6ghETm1VoPDI(u"ࠩ็่ศูแࠡใื่ฯูࠦๆๆํอࠥอไๆีะࠫࣂ"))
	return succeeded
def WK3sJl4T9bCqxgjz5VSwR(showDialogs):
	if showDialogs:
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,h6sIkJOT5PB2vCxqo4LFag70wA(u"้้ࠪ็วหࠢส่่ืวี๊ࠢ๎๋ࠥไโษอࠤ๏฻ๆฺ้สࠤ่๎ฯ๋ࠢ฼๊ิ๋วࠡ์฽่็ࠦๆโี๊ࠤอ฻่าห้ࠣๆอฬฤหࠣ࠲࠳ࠦ็ั้ࠣห้๋ไโษอࠤ๏ำสศฮ๊ห๋ࠥศา็ฯ๎้่ࠥะ์ࠣัฯ๏๋ࠠ฻ิๅํ์ࠠๆ่๊ห้๊ࠥโࠢะำะะࠠศๆุ่่๊ษࠨࣃ")+rJ9cgWz4FU+rJ9cgWz4FU+Dj62UpP5MrbTkJqhRa+yylSaxCLfkte(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่่ࠢๆอสࠡษ็็ึอิࠡษ็้ษ่สสࠢยࠥࠦ࠭ࣄ")+oOQaRxBXyJ5jVnZ)
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=P2Fgh6TCOWoaHjkqBcQnvRNXe: return cbmeD4WNZfAowxT2JdUMtV(u"ࡌࡡ࡭ࡵࡨऌ")
	succeeded = E6xdOMpqISHZCn(u"ࡔࡳࡷࡨऍ")
	for file in tiFgl4DMvGEAUfjIYkHbr05.listdir(nFM6jLciQ0zPA4Xb2hReVWSTqNv):
		if EcjO3giln2kQTdBY0XLAG(u"ࠬࡱ࡯ࡥ࡫ࡢࡷࡹࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧࣅ") not in file and od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭࡫ࡰࡦ࡬ࡣࡨࡸࡡࡴࡪ࡯ࡳ࡬࠭ࣆ") not in file: continue
		H34pwYZBaRzOuA = tiFgl4DMvGEAUfjIYkHbr05.path.join(nFM6jLciQ0zPA4Xb2hReVWSTqNv,file)
		try: tiFgl4DMvGEAUfjIYkHbr05.remove(H34pwYZBaRzOuA)
		except Exception as O7Pjho8kUNMeqxyrEf1Hg2mQbDzn:
			succeeded = xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࡇࡣ࡯ࡷࡪऎ")
			if showDialogs: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,str(O7Pjho8kUNMeqxyrEf1Hg2mQbDzn))
	if showDialogs:
		if succeeded: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠧห็ࠣห้๋ำฮࠢห๊ัออࠨࣇ"))
		else: PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,ZP1LyUCS3pIBu(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฬ๊ๅิฯࠪࣈ"))
	return succeeded
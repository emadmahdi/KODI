# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'CIMANOW'
kL0nT7NpZdKVD3jM2OHB = '_CMN_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['قائمتي']
def hH3sRBSFAr(mode,url,text):
	if   mode==300: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==301: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==302: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url)
	elif mode==303: SD0TxMRXiep4cjPBsnzI = jvfcNeDSnMh1z027lGd4rHm5gP(url)
	elif mode==304: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==305: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==306: SD0TxMRXiep4cjPBsnzI = peThWgCnwGKZD8Q1bjIvdmSRfL9A4H()
	elif mode==309: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,309,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo+'/home',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<header(.*?)</header>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('<li><a href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = title.strip(YvOQBzaTAscXR9ql)
		if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,301)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	jSpWoLZQRIsrw7MnH5KEbu(V4kF6EQiwo+'/home',bGIVq1CQTjmosZg)
	return bGIVq1CQTjmosZg
def peThWgCnwGKZD8Q1bjIvdmSRfL9A4H():
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,'موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def jSpWoLZQRIsrw7MnH5KEbu(url,bGIVq1CQTjmosZg=CJlTSEpZsWb0QHg5w):
	if not bGIVq1CQTjmosZg:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-SUBMENU-1st')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ykAihXr9IU82HQqMx7tj5 = 0
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(<section>.*?</section>)',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		for D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
			ykAihXr9IU82HQqMx7tj5 += 1
			items = Zy2l0g8QU5vqefaTrsw.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for title,smI7z9Tq3UjwJPk68nQacYGuixNXK0,ZgsbN5iSL48t2IhVFnmy in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				if title==CJlTSEpZsWb0QHg5w: title = 'بووووو'
				if 'em><a' not in smI7z9Tq3UjwJPk68nQacYGuixNXK0:
					if D3D6TF50oUBtJlvijPMW8ys.count('/category/')>0:
						AY1CXeonHdIvaD4zlpL3ZGxu = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
						for ZgsbN5iSL48t2IhVFnmy in AY1CXeonHdIvaD4zlpL3ZGxu:
							title = ZgsbN5iSL48t2IhVFnmy.split('/')[-2]
							khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,301)
						continue
					else: ZgsbN5iSL48t2IhVFnmy = url+'?sequence='+str(ykAihXr9IU82HQqMx7tj5)
				if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,302)
	else: nvHUf8mW6E4GSw5VFRXN(url,bGIVq1CQTjmosZg)
	return
def nvHUf8mW6E4GSw5VFRXN(url,bGIVq1CQTjmosZg=CJlTSEpZsWb0QHg5w):
	if bGIVq1CQTjmosZg==CJlTSEpZsWb0QHg5w:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-TITLES-1st')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if '?sequence=' in url:
		url,ykAihXr9IU82HQqMx7tj5 = url.split('?sequence=')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(<section>.*?</section>)',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[int(ykAihXr9IU82HQqMx7tj5)-1]
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"posts"(.*?)</body>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	for ZgsbN5iSL48t2IhVFnmy,data,hzGKUP1XjAoeT79MJcDF in items:
		title = Zy2l0g8QU5vqefaTrsw.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if title: title = title[0][2].replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		if not title or title==CJlTSEpZsWb0QHg5w:
			title = Zy2l0g8QU5vqefaTrsw.findall('title">.*?</em>(.*?)<',data,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if title: title = title[0].replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			if not title or title==CJlTSEpZsWb0QHg5w:
				title = Zy2l0g8QU5vqefaTrsw.findall('title">(.*?)<',data,Zy2l0g8QU5vqefaTrsw.DOTALL)
				title = title[0].replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		title = wAmsc95ya0LHz(title)
		title = title.replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		if title not in wDkMP6jlz7XeN5Sp:
			wDkMP6jlz7XeN5Sp.append(title)
			zE8URkuN932 = ZgsbN5iSL48t2IhVFnmy+data+hzGKUP1XjAoeT79MJcDF
			if '/selary/' in zE8URkuN932 or 'مسلسل' in zE8URkuN932 or '"episode"' in zE8URkuN932:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,303,hzGKUP1XjAoeT79MJcDF)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,305,hzGKUP1XjAoeT79MJcDF)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('<li><a href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,302)
	return
def jvfcNeDSnMh1z027lGd4rHm5gP(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-SEASONS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	name = Zy2l0g8QU5vqefaTrsw.findall('<title>(.*?)</title>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if name:
		name = name[0].replace('| سيما ناو',CJlTSEpZsWb0QHg5w).replace('Cima Now',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		name = name.split('الحلقة')[0].strip(YvOQBzaTAscXR9ql)+' - '
	else: name = CJlTSEpZsWb0QHg5w
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<section(.*?)</section>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if len(items)>1:
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = name+title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,304)
		elif len(items)==1:
			ZgsbN5iSL48t2IhVFnmy,title = items[0]
			j9zTQsrVRx2(ZgsbN5iSL48t2IhVFnmy)
		else: j9zTQsrVRx2(url)
	return
def j9zTQsrVRx2(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if '/selary/' not in url:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"episodes"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			title = 'الحلقة '+title
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,305)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"details"(.*?)"related"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[ZVNvqy4iF1a9X]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,305,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	maIPzfejvUS4Jn7L3k6pdqE85su = Zy2l0g8QU5vqefaTrsw.findall('class="shine" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if maIPzfejvUS4Jn7L3k6pdqE85su:
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(maIPzfejvUS4Jn7L3k6pdqE85su[0],'url')
		headers = {'Referer':FFtJQalhPz}
	else: headers = CJlTSEpZsWb0QHg5w
	BBwfuWGxUIrdCoc4ka7 = url+'watching/'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMANOW-PLAY-5th')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	MNXzjK3vV7D = []
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"download"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</i>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
			egYIsS2qROfpVW83kx = Zy2l0g8QU5vqefaTrsw.findall('\d\d\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if egYIsS2qROfpVW83kx:
				egYIsS2qROfpVW83kx = '____'+egYIsS2qROfpVW83kx[0]
				title = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
			else: egYIsS2qROfpVW83kx = CJlTSEpZsWb0QHg5w
			otCOTHujWKp7Dn6dvcafPqlx = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download'+egYIsS2qROfpVW83kx
			MNXzjK3vV7D.append(otCOTHujWKp7Dn6dvcafPqlx)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"watch"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall('"embed".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy in Rp1g7OlotseGnf0NFmKk6rLxd:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
			title = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__embed'
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
		Rp1g7OlotseGnf0NFmKk6rLxd = [V4kF6EQiwo+'/wp-content/themes/Cima%20Now%20New/core.php']
		if Rp1g7OlotseGnf0NFmKk6rLxd:
			items = Zy2l0g8QU5vqefaTrsw.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for lDgx8hPyYJvcX,id,title in items:
				title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				ZgsbN5iSL48t2IhVFnmy = Rp1g7OlotseGnf0NFmKk6rLxd[0]+'?action=switch&index='+lDgx8hPyYJvcX+'&id='+id+'?named='+title+'__watch'
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo + '/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
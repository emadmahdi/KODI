# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'YOUTUBE'
kL0nT7NpZdKVD3jM2OHB = '_YUT_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
RXiOe1F4MjU0 = 0
def hH3sRBSFAr(mode,url,text,type,GOF25jkXb1DnaB4vhL9,name,t4zynV13ZoPe):
	if	 mode==140: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==141: SD0TxMRXiep4cjPBsnzI = lxce8rRhWnBtP7(url,name,t4zynV13ZoPe)
	elif mode==143: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url,type)
	elif mode==144: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9,text)
	elif mode==145: SD0TxMRXiep4cjPBsnzI = kAW9FDSYRi8O(url,GOF25jkXb1DnaB4vhL9)
	elif mode==147: SD0TxMRXiep4cjPBsnzI = ScF36ILbyjzE()
	elif mode==148: SD0TxMRXiep4cjPBsnzI = JTW3gUH5b2lNDhKCGE()
	elif mode==149: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	if 0:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'قائمة 1',V4kF6EQiwo+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'قائمة 2',V4kF6EQiwo+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'شخص',V4kF6EQiwo+'/user/TCNofficial',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'موقع',V4kF6EQiwo+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'حساب',V4kF6EQiwo+'/@TheSocialCTV',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'العاب',V4kF6EQiwo+'/gaming',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'افلام',V4kF6EQiwo+'/feed/storefront',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مختارات',V4kF6EQiwo+'/feed/guide_builder',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'قصيرة',V4kF6EQiwo+'/shorts',144,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'تصفح',V4kF6EQiwo+'/youtubei/v1/guide?key=',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'رئيسية',V4kF6EQiwo+CJlTSEpZsWb0QHg5w,144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'رائج',V4kF6EQiwo+'/feed/trending?bp=',144)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,149,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الرائجة',V4kF6EQiwo+'/feed/trending',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'التصفح',V4kF6EQiwo+'/youtubei/v1/guide?key=',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'القصيرة',V4kF6EQiwo+'/shorts',144,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مختارات يوتيوب',V4kF6EQiwo+'/feed/guide_builder',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مختارات البرنامج',CJlTSEpZsWb0QHg5w,290)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: قنوات عربية',CJlTSEpZsWb0QHg5w,147)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: قنوات أجنبية',CJlTSEpZsWb0QHg5w,148)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: افلام عربية',V4kF6EQiwo+'/results?search_query=فيلم',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: افلام اجنبية',V4kF6EQiwo+'/results?search_query=movie',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: مسرحيات عربية',V4kF6EQiwo+'/results?search_query=مسرحية',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: مسلسلات عربية',V4kF6EQiwo+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: مسلسلات اجنبية',V4kF6EQiwo+'/results?search_query=series&sp=EgIQAw==',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: مسلسلات كارتون',V4kF6EQiwo+'/results?search_query=كارتون&sp=EgIQAw==',144)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث: خطبة المرجعية',V4kF6EQiwo+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def lxce8rRhWnBtP7(url,name,t4zynV13ZoPe):
	name = qmi8sS9rIkdBzjfu43UpPeVJh0oCAn(name)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'CHNL:  '+name,url,144,t4zynV13ZoPe)
	return
def ScF36ILbyjzE():
	nvHUf8mW6E4GSw5VFRXN(V4kF6EQiwo+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JTW3gUH5b2lNDhKCGE():
	nvHUf8mW6E4GSw5VFRXN(V4kF6EQiwo+'/results?search_query=tv&sp=EgJAAQ==')
	return
def rHwfOZb3oSgJKi(url,type):
	url = url.split('&',1)[0]
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX([url],T1QDsJlUtCGhn,type,url)
	return
def FrqtV6IK7xUPlcDNyv08wmhg3eOJWb(em2kBinAhzfJd4KPVLG5b9NyIHlXca,url,lDgx8hPyYJvcX):
	level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = lDgx8hPyYJvcX.split('::')
	jvb1YrTkJ5V639KRtcDz4heg,vJq2gdQjeHw5GTEt = [],[]
	if '/youtubei/v1/browse' in url: jvb1YrTkJ5V639KRtcDz4heg.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: jvb1YrTkJ5V639KRtcDz4heg.append("yccc['onResponseReceivedCommands']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': jvb1YrTkJ5V639KRtcDz4heg.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yccc['entries']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yccc['items'][3]['guideSectionRenderer']['items']")
	eyXJEL9ItiZmb,bpq4iTzd2Uu7,f7q1B4jmJeypRKNwa5xcAVrLDW = HQkdT7C4Y68svmFgA9pNB(em2kBinAhzfJd4KPVLG5b9NyIHlXca,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
	if level=='1' and eyXJEL9ItiZmb:
		if len(bpq4iTzd2Uu7)>1 and 'search_query' not in url:
			for wi6ZqVAdgXUxSj0TPlWG7NsOmK48 in range(len(bpq4iTzd2Uu7)):
				RNz9u5fdmUvqKr2ZoDlxbVTLA8 = str(wi6ZqVAdgXUxSj0TPlWG7NsOmK48)
				jvb1YrTkJ5V639KRtcDz4heg = []
				jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['reloadContinuationItemsCommand']['continuationItems']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['command']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]")
				cn0XyId7MkTCE1RifFhwQDN,jglfWFcvo1mAdH9yeROS7XKNxu,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(bpq4iTzd2Uu7,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
				if cn0XyId7MkTCE1RifFhwQDN: vJq2gdQjeHw5GTEt.append([jglfWFcvo1mAdH9yeROS7XKNxu,url,'2::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::0::0'])
			jvb1YrTkJ5V639KRtcDz4heg.append("yccc['continuationEndpoint']")
			cn0XyId7MkTCE1RifFhwQDN,jglfWFcvo1mAdH9yeROS7XKNxu,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(em2kBinAhzfJd4KPVLG5b9NyIHlXca,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
			if cn0XyId7MkTCE1RifFhwQDN and vJq2gdQjeHw5GTEt and 'continuationCommand' in list(jglfWFcvo1mAdH9yeROS7XKNxu.keys()):
				ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/my_main_page_shorts_link'
				vJq2gdQjeHw5GTEt.append([jglfWFcvo1mAdH9yeROS7XKNxu,ZgsbN5iSL48t2IhVFnmy,'1::0::0::0'])
	return bpq4iTzd2Uu7,eyXJEL9ItiZmb,vJq2gdQjeHw5GTEt,f7q1B4jmJeypRKNwa5xcAVrLDW
def fy6YX0pQFbNqDeG8UdvVo(em2kBinAhzfJd4KPVLG5b9NyIHlXca,bpq4iTzd2Uu7,url,lDgx8hPyYJvcX):
	level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = lDgx8hPyYJvcX.split('::')
	jvb1YrTkJ5V639KRtcDz4heg,nYxsmAIwteJXhOW7VG = [],[]
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd[0]['itemSectionRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['reloadContinuationItemsCommand']['continuationItems']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: jvb1YrTkJ5V639KRtcDz4heg.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: jvb1YrTkJ5V639KRtcDz4heg.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yddd["+RNz9u5fdmUvqKr2ZoDlxbVTLA8+"]")
	WmeyIH4P7ilrJQK3p,nRWt2irkywaJCMzh,rOi2GxmnQFsk = HQkdT7C4Y68svmFgA9pNB(bpq4iTzd2Uu7,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
	if level=='2' and WmeyIH4P7ilrJQK3p:
		if len(nRWt2irkywaJCMzh)>1:
			for wi6ZqVAdgXUxSj0TPlWG7NsOmK48 in range(len(nRWt2irkywaJCMzh)):
				zNfZE7IU9YSc5ydGrgnl6aKMsLho = str(wi6ZqVAdgXUxSj0TPlWG7NsOmK48)
				jvb1YrTkJ5V639KRtcDz4heg = []
				jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['richSectionRenderer']['content']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]")
				jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['richItemRenderer']['content']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]")
				cn0XyId7MkTCE1RifFhwQDN,jglfWFcvo1mAdH9yeROS7XKNxu,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(nRWt2irkywaJCMzh,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
				if cn0XyId7MkTCE1RifFhwQDN: nYxsmAIwteJXhOW7VG.append([jglfWFcvo1mAdH9yeROS7XKNxu,url,'3::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::0'])
			jvb1YrTkJ5V639KRtcDz4heg.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			jvb1YrTkJ5V639KRtcDz4heg.append("yddd[1]")
			cn0XyId7MkTCE1RifFhwQDN,jglfWFcvo1mAdH9yeROS7XKNxu,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(bpq4iTzd2Uu7,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
			if cn0XyId7MkTCE1RifFhwQDN and nYxsmAIwteJXhOW7VG and 'continuationItemRenderer' in list(jglfWFcvo1mAdH9yeROS7XKNxu.keys()):
				nYxsmAIwteJXhOW7VG.append([jglfWFcvo1mAdH9yeROS7XKNxu,url,'3::0::0::0'])
	return nRWt2irkywaJCMzh,WmeyIH4P7ilrJQK3p,nYxsmAIwteJXhOW7VG,rOi2GxmnQFsk
def qSrchM8I7Gau9eY(em2kBinAhzfJd4KPVLG5b9NyIHlXca,nRWt2irkywaJCMzh,url,lDgx8hPyYJvcX):
	level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = lDgx8hPyYJvcX.split('::')
	jvb1YrTkJ5V639KRtcDz4heg,aaPveRfr8zKX = [],[]
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['reelShelfRenderer']['items']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee["+zNfZE7IU9YSc5ydGrgnl6aKMsLho+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yeee")
	NPdmcKJ6YlUgF8GfqDpjt2Ar,JFlCwSskdVLUYmfbpoRe9xz,pkoq7HJbsZdrAu0y3iWV6RPwU1 = HQkdT7C4Y68svmFgA9pNB(nRWt2irkywaJCMzh,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
	if level=='3' and NPdmcKJ6YlUgF8GfqDpjt2Ar:
		if len(JFlCwSskdVLUYmfbpoRe9xz)>0:
			for wi6ZqVAdgXUxSj0TPlWG7NsOmK48 in range(len(JFlCwSskdVLUYmfbpoRe9xz)):
				tv37nWx4g1YHeVOEP08ckLmi = str(wi6ZqVAdgXUxSj0TPlWG7NsOmK48)
				jvb1YrTkJ5V639KRtcDz4heg = []
				jvb1YrTkJ5V639KRtcDz4heg.append("yfff["+tv37nWx4g1YHeVOEP08ckLmi+"]['richItemRenderer']['content']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yfff["+tv37nWx4g1YHeVOEP08ckLmi+"]['gameCardRenderer']['game']")
				jvb1YrTkJ5V639KRtcDz4heg.append("yfff["+tv37nWx4g1YHeVOEP08ckLmi+"]['itemSectionRenderer']['contents'][0]")
				jvb1YrTkJ5V639KRtcDz4heg.append("yfff["+tv37nWx4g1YHeVOEP08ckLmi+"]")
				jvb1YrTkJ5V639KRtcDz4heg.append("yfff")
				cn0XyId7MkTCE1RifFhwQDN,jglfWFcvo1mAdH9yeROS7XKNxu,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(JFlCwSskdVLUYmfbpoRe9xz,CJlTSEpZsWb0QHg5w,jvb1YrTkJ5V639KRtcDz4heg)
				if cn0XyId7MkTCE1RifFhwQDN: aaPveRfr8zKX.append([jglfWFcvo1mAdH9yeROS7XKNxu,url,'4::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi])
	return JFlCwSskdVLUYmfbpoRe9xz,NPdmcKJ6YlUgF8GfqDpjt2Ar,aaPveRfr8zKX,pkoq7HJbsZdrAu0y3iWV6RPwU1
def HQkdT7C4Y68svmFgA9pNB(zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm,djaxES9L5Q4hlCeTzNoV):
	em2kBinAhzfJd4KPVLG5b9NyIHlXca,p2M53kf1DrH4Tm = zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm
	bpq4iTzd2Uu7,p2M53kf1DrH4Tm = zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm
	nRWt2irkywaJCMzh,p2M53kf1DrH4Tm = zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm
	JFlCwSskdVLUYmfbpoRe9xz,p2M53kf1DrH4Tm = zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm
	jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu = zKUM1soNxBQCYLe87PD4uryqZT5H3b,p2M53kf1DrH4Tm
	count = len(djaxES9L5Q4hlCeTzNoV)
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(count):
		try:
			xx4dChYmW8kLHF1p3 = eval(djaxES9L5Q4hlCeTzNoV[LxNV5lenkhW6zoBJDMA7ZuqSg])
			return True,xx4dChYmW8kLHF1p3,LxNV5lenkhW6zoBJDMA7ZuqSg+1
		except: pass
	return False,CJlTSEpZsWb0QHg5w,0
def nvHUf8mW6E4GSw5VFRXN(url,lDgx8hPyYJvcX=CJlTSEpZsWb0QHg5w,data=CJlTSEpZsWb0QHg5w):
	vJq2gdQjeHw5GTEt,nYxsmAIwteJXhOW7VG,aaPveRfr8zKX = [],[],[]
	if '::' not in lDgx8hPyYJvcX: lDgx8hPyYJvcX = '1::0::0::0'
	level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = lDgx8hPyYJvcX.split('::')
	if level=='4': level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = '1',RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi
	data = data.replace('_REMEMBERRESULTS_',CJlTSEpZsWb0QHg5w)
	bGIVq1CQTjmosZg,em2kBinAhzfJd4KPVLG5b9NyIHlXca,s502yd81FCuJmLVBlkPtxih9fZDA = lYpQwnhLBKi7rfPDS1o0(url,data)
	lDgx8hPyYJvcX = level+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
	if level in ['1','2','3']:
		bpq4iTzd2Uu7,eyXJEL9ItiZmb,vJq2gdQjeHw5GTEt,f7q1B4jmJeypRKNwa5xcAVrLDW = FrqtV6IK7xUPlcDNyv08wmhg3eOJWb(em2kBinAhzfJd4KPVLG5b9NyIHlXca,url,lDgx8hPyYJvcX)
		if not eyXJEL9ItiZmb: return
		G9UoRjc7LF = len(vJq2gdQjeHw5GTEt)
		if G9UoRjc7LF<2:
			if level=='1': level = '2'
			vJq2gdQjeHw5GTEt = []
	lDgx8hPyYJvcX = level+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
	if level in ['2','3']:
		nRWt2irkywaJCMzh,WmeyIH4P7ilrJQK3p,nYxsmAIwteJXhOW7VG,rOi2GxmnQFsk = fy6YX0pQFbNqDeG8UdvVo(em2kBinAhzfJd4KPVLG5b9NyIHlXca,bpq4iTzd2Uu7,url,lDgx8hPyYJvcX)
		if not WmeyIH4P7ilrJQK3p: return
		q2q0meSDNL6X7oB3sK = len(nYxsmAIwteJXhOW7VG)
		if q2q0meSDNL6X7oB3sK<2:
			if level=='2': level = '3'
			nYxsmAIwteJXhOW7VG = []
	lDgx8hPyYJvcX = level+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
	if level in ['3']:
		JFlCwSskdVLUYmfbpoRe9xz,NPdmcKJ6YlUgF8GfqDpjt2Ar,aaPveRfr8zKX,pkoq7HJbsZdrAu0y3iWV6RPwU1 = qSrchM8I7Gau9eY(em2kBinAhzfJd4KPVLG5b9NyIHlXca,nRWt2irkywaJCMzh,url,lDgx8hPyYJvcX)
		if not NPdmcKJ6YlUgF8GfqDpjt2Ar: return
		pk4gqrxXyHCGOdN7Ez9IJW = len(aaPveRfr8zKX)
	for jglfWFcvo1mAdH9yeROS7XKNxu,url,lDgx8hPyYJvcX in vJq2gdQjeHw5GTEt+nYxsmAIwteJXhOW7VG+aaPveRfr8zKX:
		M96zE51XBmQxVsF2ujiy = uYinbFs9LREDrhCQjfozd(jglfWFcvo1mAdH9yeROS7XKNxu,url,lDgx8hPyYJvcX)
	return
def uYinbFs9LREDrhCQjfozd(jglfWFcvo1mAdH9yeROS7XKNxu,url=CJlTSEpZsWb0QHg5w,lDgx8hPyYJvcX=CJlTSEpZsWb0QHg5w):
	if '::' in lDgx8hPyYJvcX: level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = lDgx8hPyYJvcX.split('::')
	else: level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = '1','0','0','0'
	cn0XyId7MkTCE1RifFhwQDN,title,ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,count,XtbZnKed5mT2IYPy4MqvuOGURNwSc,LE3WCqkr0wZv2tnUpT,RXj9SKFi3tmvY4W,kWub879evH1BsowPyxnGXcL5Y = TTSOZLh6as2bKlR(jglfWFcvo1mAdH9yeROS7XKNxu)
	wcNfPIsg7AK8CWGrXmepFnb0J = '/videos?' in ZgsbN5iSL48t2IhVFnmy or '/streams?' in ZgsbN5iSL48t2IhVFnmy or '/playlists?' in ZgsbN5iSL48t2IhVFnmy
	eFv360Ac74tNpfE5oijhw1DxOq = '/channels?' in ZgsbN5iSL48t2IhVFnmy or '/shorts?' in ZgsbN5iSL48t2IhVFnmy
	if wcNfPIsg7AK8CWGrXmepFnb0J or eFv360Ac74tNpfE5oijhw1DxOq: ZgsbN5iSL48t2IhVFnmy = url
	wcNfPIsg7AK8CWGrXmepFnb0J = 'watch?v=' not in ZgsbN5iSL48t2IhVFnmy and '/playlist?list=' not in ZgsbN5iSL48t2IhVFnmy
	eFv360Ac74tNpfE5oijhw1DxOq = '/gaming' not in ZgsbN5iSL48t2IhVFnmy  and '/feed/storefront' not in ZgsbN5iSL48t2IhVFnmy
	if lDgx8hPyYJvcX[0:5]=='3::0::' and wcNfPIsg7AK8CWGrXmepFnb0J and eFv360Ac74tNpfE5oijhw1DxOq: ZgsbN5iSL48t2IhVFnmy = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in ZgsbN5iSL48t2IhVFnmy:
		level,RNz9u5fdmUvqKr2ZoDlxbVTLA8,zNfZE7IU9YSc5ydGrgnl6aKMsLho,tv37nWx4g1YHeVOEP08ckLmi = '1','0','0','0'
		lDgx8hPyYJvcX = CJlTSEpZsWb0QHg5w
	s502yd81FCuJmLVBlkPtxih9fZDA = CJlTSEpZsWb0QHg5w
	if '/youtubei/v1/browse' in ZgsbN5iSL48t2IhVFnmy or '/youtubei/v1/search' in ZgsbN5iSL48t2IhVFnmy or '/my_main_page_shorts_link' in url:
		data = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.youtube.data')
		if data.count(':::')==4:
			VVw69yoifXgtG0ICb,key,xdL2YH1vrEDwVkZt,iFdphTKLJaOncyD4P3xSYGv2IRWE,eOVb64kRWwArpNmu5CLXtzfDF = data.split(':::')
			s502yd81FCuJmLVBlkPtxih9fZDA = VVw69yoifXgtG0ICb+':::'+key+':::'+xdL2YH1vrEDwVkZt+':::'+iFdphTKLJaOncyD4P3xSYGv2IRWE+':::'+kWub879evH1BsowPyxnGXcL5Y
			if '/my_main_page_shorts_link' in url and not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = url
			else: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?key='+key
	if not title:
		global RXiOe1F4MjU0
		RXiOe1F4MjU0 += 1
		title = 'فيديوهات '+str(RXiOe1F4MjU0)
		lDgx8hPyYJvcX = '3'+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
	if not cn0XyId7MkTCE1RifFhwQDN: return False
	elif 'searchPyvRenderer' in str(jglfWFcvo1mAdH9yeROS7XKNxu): return False
	elif '/about' in ZgsbN5iSL48t2IhVFnmy: return False
	elif '/community' in ZgsbN5iSL48t2IhVFnmy: return False
	elif 'continuationItemRenderer' in list(jglfWFcvo1mAdH9yeROS7XKNxu.keys()) or 'continuationCommand' in list(jglfWFcvo1mAdH9yeROS7XKNxu.keys()):
		if int(level)>1: level = str(int(level)-1)
		lDgx8hPyYJvcX = level+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+':: '+'صفحة أخرى',ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX,s502yd81FCuJmLVBlkPtxih9fZDA)
	elif '/search' in ZgsbN5iSL48t2IhVFnmy:
		title = ':: '+title
		lDgx8hPyYJvcX = '3'+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
		url = url.replace('/search',CJlTSEpZsWb0QHg5w)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,145,CJlTSEpZsWb0QHg5w,lDgx8hPyYJvcX,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not ZgsbN5iSL48t2IhVFnmy:
		lDgx8hPyYJvcX = '3'+'::'+RNz9u5fdmUvqKr2ZoDlxbVTLA8+'::'+zNfZE7IU9YSc5ydGrgnl6aKMsLho+'::'+tv37nWx4g1YHeVOEP08ckLmi
		title = ':: '+title
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX,s502yd81FCuJmLVBlkPtxih9fZDA)
	elif '/browse' in ZgsbN5iSL48t2IhVFnmy and url==V4kF6EQiwo:
		title = ':: '+title
		lDgx8hPyYJvcX = '2::0::0::0'
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX,s502yd81FCuJmLVBlkPtxih9fZDA)
	elif not ZgsbN5iSL48t2IhVFnmy and 'horizontalMovieListRenderer' in str(jglfWFcvo1mAdH9yeROS7XKNxu):
		title = ':: '+title
		lDgx8hPyYJvcX = '3::0::0::0'
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX)
	elif 'messageRenderer' in str(jglfWFcvo1mAdH9yeROS7XKNxu):
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,9999)
	elif LE3WCqkr0wZv2tnUpT:
		khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+LE3WCqkr0wZv2tnUpT+title,ZgsbN5iSL48t2IhVFnmy,143,hzGKUP1XjAoeT79MJcDF)
	elif '/playlist?list=' in ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('&playnext=1',CJlTSEpZsWb0QHg5w)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'LIST'+count+':  '+title,ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX)
	elif '/shorts/' in ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('&list=',1)[0]
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,143,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	elif '/watch?v=' in ZgsbN5iSL48t2IhVFnmy:
		if '&list=' in ZgsbN5iSL48t2IhVFnmy and count:
			kwGQr5AYTW = ZgsbN5iSL48t2IhVFnmy.split('&list=',1)[1]
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/playlist?list='+kwGQr5AYTW
			lDgx8hPyYJvcX = '1::0::0::0'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'LIST'+count+':  '+title,ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX)
		else:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('&list=',1)[0]
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,143,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	elif '/channel/' in ZgsbN5iSL48t2IhVFnmy or '/c/' in ZgsbN5iSL48t2IhVFnmy or ('/@' in ZgsbN5iSL48t2IhVFnmy and ZgsbN5iSL48t2IhVFnmy.count('/')==3):
		if BB7oCRfQNSYj5qDhTUevV:
			title = title.decode(Im5KSGZYBpRvdMVsbuXg).encode('raw_unicode_escape')
			title = pd0Na8D5WZfHYkysVS(title)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'CHNL'+count+':  '+title,ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX)
	elif '/user/' in ZgsbN5iSL48t2IhVFnmy:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'USER'+count+':  '+title,ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX)
	else:
		if not ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = url
		title = ':: '+title
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,144,hzGKUP1XjAoeT79MJcDF,lDgx8hPyYJvcX,s502yd81FCuJmLVBlkPtxih9fZDA)
	return True
def TTSOZLh6as2bKlR(jglfWFcvo1mAdH9yeROS7XKNxu):
	cn0XyId7MkTCE1RifFhwQDN,title,ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,count,XtbZnKed5mT2IYPy4MqvuOGURNwSc,LE3WCqkr0wZv2tnUpT,RXj9SKFi3tmvY4W,eOVb64kRWwArpNmu5CLXtzfDF = False,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	if not isinstance(jglfWFcvo1mAdH9yeROS7XKNxu,dict): return cn0XyId7MkTCE1RifFhwQDN,title,ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,count,XtbZnKed5mT2IYPy4MqvuOGURNwSc,LE3WCqkr0wZv2tnUpT,RXj9SKFi3tmvY4W,eOVb64kRWwArpNmu5CLXtzfDF
	for hh8iUXfjSe5cdF in list(jglfWFcvo1mAdH9yeROS7XKNxu.keys()):
		o7azcyS9bJu = jglfWFcvo1mAdH9yeROS7XKNxu[hh8iUXfjSe5cdF]
		if isinstance(o7azcyS9bJu,dict): break
	jvb1YrTkJ5V639KRtcDz4heg = []
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['header']['richListHeaderRenderer']['title']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['headline']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['unplayableText']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['formattedTitle']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['title']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['title']['runs'][0]['text']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['text']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['text']['runs'][0]['text']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['title']['content']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['title']")
	jvb1YrTkJ5V639KRtcDz4heg.append("item['title']")
	jvb1YrTkJ5V639KRtcDz4heg.append("item['reelWatchEndpoint']['videoId']")
	cn0XyId7MkTCE1RifFhwQDN,title,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu,jvb1YrTkJ5V639KRtcDz4heg)
	jvb1YrTkJ5V639KRtcDz4heg = []
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	jvb1YrTkJ5V639KRtcDz4heg.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	jvb1YrTkJ5V639KRtcDz4heg.append("item['commandMetadata']['webCommandMetadata']['url']")
	cn0XyId7MkTCE1RifFhwQDN,ZgsbN5iSL48t2IhVFnmy,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu,jvb1YrTkJ5V639KRtcDz4heg)
	jvb1YrTkJ5V639KRtcDz4heg = []
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnail']['thumbnails'][0]['url']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	jvb1YrTkJ5V639KRtcDz4heg.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	cn0XyId7MkTCE1RifFhwQDN,hzGKUP1XjAoeT79MJcDF,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu,jvb1YrTkJ5V639KRtcDz4heg)
	jvb1YrTkJ5V639KRtcDz4heg = []
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['videoCountShortText']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['videoCountText']['runs'][0]['text']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['videoCount']")
	cn0XyId7MkTCE1RifFhwQDN,count,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu,jvb1YrTkJ5V639KRtcDz4heg)
	jvb1YrTkJ5V639KRtcDz4heg = []
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['lengthText']['simpleText']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	cn0XyId7MkTCE1RifFhwQDN,XtbZnKed5mT2IYPy4MqvuOGURNwSc,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu,jvb1YrTkJ5V639KRtcDz4heg)
	jvb1YrTkJ5V639KRtcDz4heg = []
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	jvb1YrTkJ5V639KRtcDz4heg.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	cn0XyId7MkTCE1RifFhwQDN,eOVb64kRWwArpNmu5CLXtzfDF,Z9ZHlis43maAITJUwNQgS0on = HQkdT7C4Y68svmFgA9pNB(jglfWFcvo1mAdH9yeROS7XKNxu,o7azcyS9bJu,jvb1YrTkJ5V639KRtcDz4heg)
	if 'LIVE' in XtbZnKed5mT2IYPy4MqvuOGURNwSc: XtbZnKed5mT2IYPy4MqvuOGURNwSc,LE3WCqkr0wZv2tnUpT = CJlTSEpZsWb0QHg5w,'LIVE:  '
	if 'مباشر' in XtbZnKed5mT2IYPy4MqvuOGURNwSc: XtbZnKed5mT2IYPy4MqvuOGURNwSc,LE3WCqkr0wZv2tnUpT = CJlTSEpZsWb0QHg5w,'LIVE:  '
	if 'badges' in list(o7azcyS9bJu.keys()):
		uuf6ZsOavqhA8Gy = str(o7azcyS9bJu['badges'])
		if 'Free with Ads' in uuf6ZsOavqhA8Gy: RXj9SKFi3tmvY4W = '$:  '
		if 'LIVE' in uuf6ZsOavqhA8Gy: LE3WCqkr0wZv2tnUpT = 'LIVE:  '
		if 'Buy' in uuf6ZsOavqhA8Gy or 'Rent' in uuf6ZsOavqhA8Gy: RXj9SKFi3tmvY4W = '$$:  '
		if lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(u'مباشر') in uuf6ZsOavqhA8Gy: LE3WCqkr0wZv2tnUpT = 'LIVE:  '
		if lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(u'شراء') in uuf6ZsOavqhA8Gy: RXj9SKFi3tmvY4W = '$$:  '
		if lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(u'استئجار') in uuf6ZsOavqhA8Gy: RXj9SKFi3tmvY4W = '$$:  '
		if lXYsqrZehnzpFuJDBKV74Hy8kEbAOT(u'إعلانات') in uuf6ZsOavqhA8Gy: RXj9SKFi3tmvY4W = '$:  '
	ZgsbN5iSL48t2IhVFnmy = pd0Na8D5WZfHYkysVS(ZgsbN5iSL48t2IhVFnmy)
	if ZgsbN5iSL48t2IhVFnmy and 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
	hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.split('?')[0]
	if  hzGKUP1XjAoeT79MJcDF and 'http' not in hzGKUP1XjAoeT79MJcDF: hzGKUP1XjAoeT79MJcDF = 'https:'+hzGKUP1XjAoeT79MJcDF
	title = pd0Na8D5WZfHYkysVS(title)
	if RXj9SKFi3tmvY4W: title = RXj9SKFi3tmvY4W+title
	XtbZnKed5mT2IYPy4MqvuOGURNwSc = XtbZnKed5mT2IYPy4MqvuOGURNwSc.replace(',',CJlTSEpZsWb0QHg5w)
	count = count.replace(',',CJlTSEpZsWb0QHg5w)
	count = Zy2l0g8QU5vqefaTrsw.findall('\d+',count)
	if count: count = count[0]
	else: count = CJlTSEpZsWb0QHg5w
	return True,title,ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,count,XtbZnKed5mT2IYPy4MqvuOGURNwSc,LE3WCqkr0wZv2tnUpT,RXj9SKFi3tmvY4W,eOVb64kRWwArpNmu5CLXtzfDF
def lYpQwnhLBKi7rfPDS1o0(url,data=CJlTSEpZsWb0QHg5w,RjVAI6uzxFofm7qv=CJlTSEpZsWb0QHg5w):
	if RjVAI6uzxFofm7qv==CJlTSEpZsWb0QHg5w: RjVAI6uzxFofm7qv = 'ytInitialData'
	ww0cfi2ZxQvg7k3N1uLRhtFdH = jQW9RpucaCLHX0sSBD6lrif58e47nt()
	bsGedm1TLP7EgiUQDkCy = {'User-Agent':ww0cfi2ZxQvg7k3N1uLRhtFdH,'Cookie':'PREF=hl=ar'}
	global ZoM1Newq29g7aGnDmE5VSOA6itk3
	if not data: data = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting('av.youtube.data')
	if data.count(':::')==4: VVw69yoifXgtG0ICb,key,xdL2YH1vrEDwVkZt,iFdphTKLJaOncyD4P3xSYGv2IRWE,eOVb64kRWwArpNmu5CLXtzfDF = data.split(':::')
	else: VVw69yoifXgtG0ICb,key,xdL2YH1vrEDwVkZt,iFdphTKLJaOncyD4P3xSYGv2IRWE,eOVb64kRWwArpNmu5CLXtzfDF = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	s502yd81FCuJmLVBlkPtxih9fZDA = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":xdL2YH1vrEDwVkZt}}}
	if url==V4kF6EQiwo+'/shorts' or '/my_main_page_shorts_link' in url:
		url = V4kF6EQiwo+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		s502yd81FCuJmLVBlkPtxih9fZDA['sequenceParams'] = VVw69yoifXgtG0ICb
		s502yd81FCuJmLVBlkPtxih9fZDA = str(s502yd81FCuJmLVBlkPtxih9fZDA)
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',url,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = V4kF6EQiwo+'/youtubei/v1/guide?key='+key
		s502yd81FCuJmLVBlkPtxih9fZDA = str(s502yd81FCuJmLVBlkPtxih9fZDA)
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',url,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and VVw69yoifXgtG0ICb:
		s502yd81FCuJmLVBlkPtxih9fZDA['continuation'] = eOVb64kRWwArpNmu5CLXtzfDF
		s502yd81FCuJmLVBlkPtxih9fZDA['context']['client']['visitorData'] = VVw69yoifXgtG0ICb
		s502yd81FCuJmLVBlkPtxih9fZDA = str(s502yd81FCuJmLVBlkPtxih9fZDA)
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'POST',url,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and iFdphTKLJaOncyD4P3xSYGv2IRWE:
		bsGedm1TLP7EgiUQDkCy.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':xdL2YH1vrEDwVkZt})
		bsGedm1TLP7EgiUQDkCy.update({'Cookie':'VISITOR_INFO1_LIVE='+iFdphTKLJaOncyD4P3xSYGv2IRWE})
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'YOUTUBE-GET_PAGE_DATA-6th')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall('"innertubeApiKey".*?"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.I)
	if he0wn71osQ8NCFJ9xzIqrDXBMRY: key = he0wn71osQ8NCFJ9xzIqrDXBMRY[0]
	he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall('"cver".*?"value".*?"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.I)
	if he0wn71osQ8NCFJ9xzIqrDXBMRY: xdL2YH1vrEDwVkZt = he0wn71osQ8NCFJ9xzIqrDXBMRY[0]
	he0wn71osQ8NCFJ9xzIqrDXBMRY = Zy2l0g8QU5vqefaTrsw.findall('"visitorData".*?"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.I)
	if he0wn71osQ8NCFJ9xzIqrDXBMRY: VVw69yoifXgtG0ICb = he0wn71osQ8NCFJ9xzIqrDXBMRY[0]
	cookies = bqIufCQz2OWExjilm.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): iFdphTKLJaOncyD4P3xSYGv2IRWE = cookies['VISITOR_INFO1_LIVE']
	kjGCm2DWF9wdlTb5 = VVw69yoifXgtG0ICb+':::'+key+':::'+xdL2YH1vrEDwVkZt+':::'+iFdphTKLJaOncyD4P3xSYGv2IRWE+':::'+eOVb64kRWwArpNmu5CLXtzfDF
	if RjVAI6uzxFofm7qv=='ytInitialData' and 'ytInitialData' in bGIVq1CQTjmosZg:
		qyA6UwYpaTF = Zy2l0g8QU5vqefaTrsw.findall('window\["ytInitialData"\] = ({.*?});',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not qyA6UwYpaTF: qyA6UwYpaTF = Zy2l0g8QU5vqefaTrsw.findall('var ytInitialData = ({.*?});',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ZzOb5XcBp8IrvseYN = oE7iT3HI5VDdmY4kPOjr('str',qyA6UwYpaTF[0])
	elif RjVAI6uzxFofm7qv=='ytInitialGuideData' and 'ytInitialGuideData' in bGIVq1CQTjmosZg:
		qyA6UwYpaTF = Zy2l0g8QU5vqefaTrsw.findall('var ytInitialGuideData = ({.*?});',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		ZzOb5XcBp8IrvseYN = oE7iT3HI5VDdmY4kPOjr('str',qyA6UwYpaTF[0])
	elif '</script>' not in bGIVq1CQTjmosZg: ZzOb5XcBp8IrvseYN = oE7iT3HI5VDdmY4kPOjr('str',bGIVq1CQTjmosZg)
	else: ZzOb5XcBp8IrvseYN = CJlTSEpZsWb0QHg5w
	if 0:
		em2kBinAhzfJd4KPVLG5b9NyIHlXca = str(ZzOb5XcBp8IrvseYN)
		if A7Z6OVh20eCEUx: em2kBinAhzfJd4KPVLG5b9NyIHlXca = em2kBinAhzfJd4KPVLG5b9NyIHlXca.encode(Im5KSGZYBpRvdMVsbuXg)
		open('S:\\0000emad.dat','wb').write(em2kBinAhzfJd4KPVLG5b9NyIHlXca)
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting('av.youtube.data',kjGCm2DWF9wdlTb5)
	return bGIVq1CQTjmosZg,ZzOb5XcBp8IrvseYN,kjGCm2DWF9wdlTb5
def kAW9FDSYRi8O(url,lDgx8hPyYJvcX):
	search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if not search: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	BBwfuWGxUIrdCoc4ka7 = url+'/search?query='+search
	nvHUf8mW6E4GSw5VFRXN(BBwfuWGxUIrdCoc4ka7,lDgx8hPyYJvcX)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search:
		search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not search: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in EcrV3IasOo4Hq: PLxTcb7a3uD4jfH = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in EcrV3IasOo4Hq: PLxTcb7a3uD4jfH = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in EcrV3IasOo4Hq: PLxTcb7a3uD4jfH = '&sp=EgIQAg%253D%253D'
		else: PLxTcb7a3uD4jfH = CJlTSEpZsWb0QHg5w
		ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7+PLxTcb7a3uD4jfH
	else:
		uVn30ilCxmZ1y9gRhON7TfAa8vkw,TWXg48qF51MhGVLj2UH,II4x930lvTuVqekXBNCrMy = [],[],CJlTSEpZsWb0QHg5w
		deTsgFbOBSEDWw5u0MlkoGA = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		VVandtLyksx2wIfz = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		vvYhdD8bLyWulPJH = T4TK17YsEfZJ('اختر البحث المناسب',deTsgFbOBSEDWw5u0MlkoGA)
		if vvYhdD8bLyWulPJH == -1: return
		Sx8p4uBCcbRGrzPU = VVandtLyksx2wIfz[vvYhdD8bLyWulPJH]
		bGIVq1CQTjmosZg,EPdwUCv2nkAZeS,data = lYpQwnhLBKi7rfPDS1o0(BBwfuWGxUIrdCoc4ka7+Sx8p4uBCcbRGrzPU)
		if EPdwUCv2nkAZeS:
			try:
				ooYEZgPdSCMs8V6epw5v1 = EPdwUCv2nkAZeS['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for FKMCe17OHJkpRLG5rjDmfVXY6AS in range(len(ooYEZgPdSCMs8V6epw5v1)):
					group = ooYEZgPdSCMs8V6epw5v1[FKMCe17OHJkpRLG5rjDmfVXY6AS]['searchFilterGroupRenderer']['filters']
					for E5sdvgewHqyoVDuhNjCMIQO3Z6bS in range(len(group)):
						o7azcyS9bJu = group[E5sdvgewHqyoVDuhNjCMIQO3Z6bS]['searchFilterRenderer']
						if 'navigationEndpoint' in list(o7azcyS9bJu.keys()):
							ZgsbN5iSL48t2IhVFnmy = o7azcyS9bJu['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('\u0026','&')
							title = o7azcyS9bJu['tooltip']
							title = title.replace('البحث عن ',CJlTSEpZsWb0QHg5w)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								II4x930lvTuVqekXBNCrMy = title
								otCOTHujWKp7Dn6dvcafPqlx = ZgsbN5iSL48t2IhVFnmy
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',CJlTSEpZsWb0QHg5w)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								II4x930lvTuVqekXBNCrMy = title
								otCOTHujWKp7Dn6dvcafPqlx = ZgsbN5iSL48t2IhVFnmy
							if 'Sort by' in title: continue
							uVn30ilCxmZ1y9gRhON7TfAa8vkw.append(pd0Na8D5WZfHYkysVS(title))
							TWXg48qF51MhGVLj2UH.append(ZgsbN5iSL48t2IhVFnmy)
			except: pass
		if not II4x930lvTuVqekXBNCrMy: Z6BziesRPgXmWvckYrbE5S0HpOCq9K = CJlTSEpZsWb0QHg5w
		else:
			uVn30ilCxmZ1y9gRhON7TfAa8vkw = ['بدون فلتر',II4x930lvTuVqekXBNCrMy]+uVn30ilCxmZ1y9gRhON7TfAa8vkw
			TWXg48qF51MhGVLj2UH = [CJlTSEpZsWb0QHg5w,otCOTHujWKp7Dn6dvcafPqlx]+TWXg48qF51MhGVLj2UH
			KDi9hJPRBzpds4ML3Xk6xncSgtoIWu = T4TK17YsEfZJ('موقع يوتيوب - اختر الفلتر',uVn30ilCxmZ1y9gRhON7TfAa8vkw)
			if KDi9hJPRBzpds4ML3Xk6xncSgtoIWu == -1: return
			Z6BziesRPgXmWvckYrbE5S0HpOCq9K = TWXg48qF51MhGVLj2UH[KDi9hJPRBzpds4ML3Xk6xncSgtoIWu]
		if Z6BziesRPgXmWvckYrbE5S0HpOCq9K: ysw7G3tqjo = V4kF6EQiwo+Z6BziesRPgXmWvckYrbE5S0HpOCq9K
		elif Sx8p4uBCcbRGrzPU: ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7+Sx8p4uBCcbRGrzPU
		else: ysw7G3tqjo = BBwfuWGxUIrdCoc4ka7
	nvHUf8mW6E4GSw5VFRXN(ysw7G3tqjo)
	return
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'CIMAABDO'
kL0nT7NpZdKVD3jM2OHB = '_ABD_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['الرئيسية','افلام للكبار فقط +18']
def hH3sRBSFAr(mode,url,text):
	if   mode==550: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==551: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==552: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==553: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url)
	elif mode==559: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo+'/home',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(V4kF6EQiwo,'url')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,559,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'اخترنا لك',dmiXC1cB7MZlb+'/home',551,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'featured')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-content(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('data-name="(.*?)".*?</i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for Gy3m1diZPVuoMc2hWI6LpN,title in items:
		ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/ajax/getItem?item='+Gy3m1diZPVuoMc2hWI6LpN+'&Ajax=1'
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,551)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"nav-main"(.*?)</nav>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if ZgsbN5iSL48t2IhVFnmy=='#': continue
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' in title: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,551)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if ZgsbN5iSL48t2IhVFnmy=='#': continue
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		if 'مسلسل ' in title: continue
		if 'أحدث' not in title: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,551)
	return
def nvHUf8mW6E4GSw5VFRXN(url,Gy3m1diZPVuoMc2hWI6LpN=CJlTSEpZsWb0QHg5w):
	items = []
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = degRiWptawTqXvKNh(url)
		bsGedm1TLP7EgiUQDkCy = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-TITLES-1st')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		s67485upzYNMS3PqDelkrdfo = [bGIVq1CQTjmosZg]
	else:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-TITLES-2nd')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		if Gy3m1diZPVuoMc2hWI6LpN=='featured':
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"container"(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		elif '"section-post mb-10"' in bGIVq1CQTjmosZg:
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"section-post mb-10"(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		else:
			s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<article(.*?)"pagination"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not s67485upzYNMS3PqDelkrdfo: return
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if not items:
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)".*?data-original="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not items: items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy).strip('/')
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) الحلقة \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if 'سلاسل' not in url and any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,552,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and 'الحلقة' in title:
			title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,553,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif '/movies/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,551,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,553,hzGKUP1XjAoeT79MJcDF)
	if Gy3m1diZPVuoMc2hWI6LpN==CJlTSEpZsWb0QHg5w:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination"(.*?)<footer',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy=="": continue
				if title!=CJlTSEpZsWb0QHg5w: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,551)
	if '/ajax/getItem' in url or '/ajax/loadMore' in url:
		if '/ajax/getItem' in url:
			url = url.replace('/ajax/getItem','/ajax/loadMore')+'&offset=20'
		elif '/ajax/loadMore' in url:
			url,offset = url.split('&offset=')
			offset = int(offset)+20
			url = url+'&offset='+str(offset)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'هناك المزيد',url,551)
	return
def j9zTQsrVRx2(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"getSeasonsBySeries(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"list-episodes"(.*?)"container"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if hh2VPjs7dkR581KzENYigmpZxLyb and '/series/' not in url:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)".*?src="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,553,hzGKUP1XjAoeT79MJcDF)
	elif KXu2RYg3Bc:
		hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('"image" src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0]
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,552,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	ysw7G3tqjo = url.replace('/movies/','/watch_movies/')
	ysw7G3tqjo = ysw7G3tqjo.replace('/episodes/','/watch_episodes/')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',ysw7G3tqjo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(ysw7G3tqjo,'url')
	FhX9OGwaNyAEZ = []
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('''<iframe.*?src=["'](.*?)["']''',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'url')
		FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__embed')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"servers"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		e2MSyTKUbONAa14zYLXZPCQv = Zy2l0g8QU5vqefaTrsw.findall('postID = "(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		e2MSyTKUbONAa14zYLXZPCQv = e2MSyTKUbONAa14zYLXZPCQv[0]
		items = Zy2l0g8QU5vqefaTrsw.findall("getPlayer\('(.*?)'.*?</i>(.*?)</a>",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for FFtJQalhPz,title in items:
				title = title.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/ajax/getPlayer?server='+FFtJQalhPz+'&postID='+e2MSyTKUbONAa14zYLXZPCQv+'&Ajax=1'
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
		else:
			items = Zy2l0g8QU5vqefaTrsw.findall("getPlayerByName\('(.*?)','(.*?)'.*?\"server\">(.*?)</a>",D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if items:
				FFtJQalhPz,ODnBXVobrzCjTvlZ,title = items[0]
				ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/ajax/getPlayerByName?server='+FFtJQalhPz+'&multipleServers='+ODnBXVobrzCjTvlZ+'&postID='+e2MSyTKUbONAa14zYLXZPCQv+'&Ajax=1'
				BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA = degRiWptawTqXvKNh(ZgsbN5iSL48t2IhVFnmy)
				bsGedm1TLP7EgiUQDkCy = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
				bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',BBwfuWGxUIrdCoc4ka7,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-PLAY-2nd')
				bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
				cKBL8AkYTtC = Zy2l0g8QU5vqefaTrsw.findall('''<iframe src=["'](.*?)["']''',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL|Zy2l0g8QU5vqefaTrsw.IGNORECASE)
				otCOTHujWKp7Dn6dvcafPqlx = cKBL8AkYTtC[0] if cKBL8AkYTtC else CJlTSEpZsWb0QHg5w
				if '/iframe/' in otCOTHujWKp7Dn6dvcafPqlx:
					bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',otCOTHujWKp7Dn6dvcafPqlx,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-PLAY-3rd')
					bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
					oTt1jwGblRQc7NZ = Zy2l0g8QU5vqefaTrsw.findall('version&quot;:&quot;(.*?)&',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
					oTt1jwGblRQc7NZ = oTt1jwGblRQc7NZ[0]
					bsGedm1TLP7EgiUQDkCy = {}
					bsGedm1TLP7EgiUQDkCy['X-Inertia-Partial-Component'] = 'files/mirror/video'
					bsGedm1TLP7EgiUQDkCy['X-Inertia'] = 'true'
					bsGedm1TLP7EgiUQDkCy['X-Inertia-Partial-Data'] = 'streams'
					bsGedm1TLP7EgiUQDkCy['X-Inertia-Version'] = oTt1jwGblRQc7NZ
					bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',otCOTHujWKp7Dn6dvcafPqlx,CJlTSEpZsWb0QHg5w,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMAABDO-PLAY-4th')
					bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
					J0PiCTp7vsKfQOMhw6ZSuF8 = oE7iT3HI5VDdmY4kPOjr('dict',bGIVq1CQTjmosZg)
					groups = J0PiCTp7vsKfQOMhw6ZSuF8['props']['streams']['data']
					for group in groups:
						egYIsS2qROfpVW83kx = group['label'].replace(' (source)',CJlTSEpZsWb0QHg5w)
						p3XAjsMxVIFJOfzkYnZDoUTP = group['mirrors']
						for f73MSPaicsQRgmbnE5XI in p3XAjsMxVIFJOfzkYnZDoUTP:
							FFtJQalhPz = f73MSPaicsQRgmbnE5XI['driver']
							ZgsbN5iSL48t2IhVFnmy = 'http:'+f73MSPaicsQRgmbnE5XI['link']+'?named='+FFtJQalhPz+'__watch____'+egYIsS2qROfpVW83kx
							FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"downs"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,name in items:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+name+'__download'
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'-')
	url = V4kF6EQiwo+'/search/'+search+'.html'
	nvHUf8mW6E4GSw5VFRXN(url)
	return
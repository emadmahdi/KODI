# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'EGYBEST3'
kL0nT7NpZdKVD3jM2OHB = '_EB3_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['المصارعة الحرة','ايجي بست','التصميم الجديد','عروض المصارعة','مكتبتي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست','موقع نتفليكس']
def hH3sRBSFAr(mode,url,GOF25jkXb1DnaB4vhL9,text):
	if   mode==790: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==791: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9)
	elif mode==792: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==793: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==796: SD0TxMRXiep4cjPBsnzI = bFsHpJmxDSgKNdReElj(url,GOF25jkXb1DnaB4vhL9)
	elif mode==799: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST3-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('list-pages(.*?)fa-folder',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)</span>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			if any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,791)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-article(.*?)social-box',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('main-title.*?">(.*?)<.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for title,ZgsbN5iSL48t2IhVFnmy in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			if any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,791,CJlTSEpZsWb0QHg5w,'mainmenu')
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-menu(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(YvOQBzaTAscXR9ql)
			if any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur): continue
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,791)
	return bGIVq1CQTjmosZg
def bFsHpJmxDSgKNdReElj(url,type=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST3-SEASONS_EPISODES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-article".*?">(.*?)<(.*?)article',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		K5ic8ROYfn1,iypksRX5aYC,items = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,[]
		for name,D3D6TF50oUBtJlvijPMW8ys in s67485upzYNMS3PqDelkrdfo:
			if 'حلقات' in name: iypksRX5aYC = D3D6TF50oUBtJlvijPMW8ys
			if 'مواسم' in name: K5ic8ROYfn1 = D3D6TF50oUBtJlvijPMW8ys
		if K5ic8ROYfn1 and not type:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',K5ic8ROYfn1,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if len(items)>1:
				for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,796,hzGKUP1XjAoeT79MJcDF,'season')
		if iypksRX5aYC and len(items)<2:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?data-src="(.*?)".*?class="title">(.*?)<',iypksRX5aYC,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if items:
				for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
					khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,793,hzGKUP1XjAoeT79MJcDF)
			else:
				items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',iypksRX5aYC,Zy2l0g8QU5vqefaTrsw.DOTALL)
				for ZgsbN5iSL48t2IhVFnmy,title in items:
					khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,793)
	return
def nvHUf8mW6E4GSw5VFRXN(url,type=CJlTSEpZsWb0QHg5w):
	TT7WzUmOPGJIbheSrXvukiDj30c,start,UDkNdJxF4il0QoeG89sBR,select,g7Vn40TJSOBeAvyEF = 0,0,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	if 'pagination' in type:
		v8JbaLeix5TYwmQAgHq3BthZ2WF9y,data = degRiWptawTqXvKNh(url)
		TT7WzUmOPGJIbheSrXvukiDj30c = int(data['limit'])
		start = int(data['start'])
		UDkNdJxF4il0QoeG89sBR = data['type']
		select = data['select']
		s502yd81FCuJmLVBlkPtxih9fZDA = 'limit='+str(TT7WzUmOPGJIbheSrXvukiDj30c)+'&start='+str(start)+'&type='+UDkNdJxF4il0QoeG89sBR+'&select='+select
		bsGedm1TLP7EgiUQDkCy = {'Content-Type':'application/x-www-form-urlencoded'}
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',v8JbaLeix5TYwmQAgHq3BthZ2WF9y,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST3-TITLES-1st')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = 'blocks'+bGIVq1CQTjmosZg+'article'
	else:
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST3-TITLES-2nd')
		bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bGIVq1CQTjmosZg
		code = Zy2l0g8QU5vqefaTrsw.findall("<script>(var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?;var.*?=.*?);</script>",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if code:
			code = code[0].replace('var',CJlTSEpZsWb0QHg5w).replace(YvOQBzaTAscXR9ql,CJlTSEpZsWb0QHg5w).replace("'",CJlTSEpZsWb0QHg5w).replace(';','&')
			Cm7xuRTdLQwZjv81V2AhKfqs04U,data = degRiWptawTqXvKNh('?'+code)
			TT7WzUmOPGJIbheSrXvukiDj30c = int(data['limit'])
			start = int(data['start'])
			UDkNdJxF4il0QoeG89sBR = data['type']
			select = data['select']
			g7Vn40TJSOBeAvyEF = data['ajaxurl']
			s502yd81FCuJmLVBlkPtxih9fZDA = 'limit='+str(TT7WzUmOPGJIbheSrXvukiDj30c)+'&start='+str(start)+'&type='+UDkNdJxF4il0QoeG89sBR+'&select='+select
			v8JbaLeix5TYwmQAgHq3BthZ2WF9y = V4kF6EQiwo+g7Vn40TJSOBeAvyEF
			bsGedm1TLP7EgiUQDkCy = {'Content-Type':'application/x-www-form-urlencoded'}
			bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'POST',v8JbaLeix5TYwmQAgHq3BthZ2WF9y,s502yd81FCuJmLVBlkPtxih9fZDA,bsGedm1TLP7EgiUQDkCy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST3-TITLES-3rd')
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
			Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = 'blocks'+Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp+'article'
	items,g63IdQelXYianvKNxZr82kUGR,YUIwPVo4qucC7935ZW = [],False,False
	if not type:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-content(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</i>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = title.strip(YvOQBzaTAscXR9ql)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,791,CJlTSEpZsWb0QHg5w,'submenu')
				g63IdQelXYianvKNxZr82kUGR = True
	if not type:
		YUIwPVo4qucC7935ZW = DVEvPnGWqpez(bGIVq1CQTjmosZg)
	if not g63IdQelXYianvKNxZr82kUGR and not YUIwPVo4qucC7935ZW:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('blocks(.*?)article',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
				hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.strip(rJ9cgWz4FU)
				ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy)
				if '/selary/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,791,hzGKUP1XjAoeT79MJcDF)
				elif 'مسلسل' in ZgsbN5iSL48t2IhVFnmy and 'حلقة' not in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,796,hzGKUP1XjAoeT79MJcDF)
				elif 'موسم' in ZgsbN5iSL48t2IhVFnmy and 'حلقة' not in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,796,hzGKUP1XjAoeT79MJcDF)
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,793,hzGKUP1XjAoeT79MJcDF)
		dd4LT95xC1Gwh6fF = 12
		data = Zy2l0g8QU5vqefaTrsw.findall('class="(load-more.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if len(items)==dd4LT95xC1Gwh6fF and (data or 'pagination' in type):
			s502yd81FCuJmLVBlkPtxih9fZDA = 'limit='+str(dd4LT95xC1Gwh6fF)+'&start='+str(start+dd4LT95xC1Gwh6fF)+'&type='+UDkNdJxF4il0QoeG89sBR+'&select='+select
			BBwfuWGxUIrdCoc4ka7 = v8JbaLeix5TYwmQAgHq3BthZ2WF9y+'?next=page&'+s502yd81FCuJmLVBlkPtxih9fZDA
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'المزيد',BBwfuWGxUIrdCoc4ka7,791,CJlTSEpZsWb0QHg5w,'pagination_'+type)
	return
def DVEvPnGWqpez(bGIVq1CQTjmosZg):
	YUIwPVo4qucC7935ZW = False
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-article(.*?)article',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		p3LfChWJd124eAYj78zw09SXonH = Zy2l0g8QU5vqefaTrsw.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if p3LfChWJd124eAYj78zw09SXonH: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		for y3LbIjrZvcATpNDM,name,D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
			name = name.strip(YvOQBzaTAscXR9ql)
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,value in items:
				title = name+':  '+value
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,791,CJlTSEpZsWb0QHg5w,'filter')
				YUIwPVo4qucC7935ZW = True
	return YUIwPVo4qucC7935ZW
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(uhTI2t3wObYqsAi9DCoc,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'EGYBEST3-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	FhX9OGwaNyAEZ,RDwZryfhWXz735Gb6A1dqICExS = [],[]
	items = Zy2l0g8QU5vqefaTrsw.findall('server-item.*?data-code="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ttiOvGydzMpP6qNoR0Ygl in items:
		grmVG9Xpd40fqHe7DtPbZKkAC8S = qqth6cAFkaRowLlUeMng.b64decode(ttiOvGydzMpP6qNoR0Ygl)
		if A7Z6OVh20eCEUx: grmVG9Xpd40fqHe7DtPbZKkAC8S = grmVG9Xpd40fqHe7DtPbZKkAC8S.decode(Im5KSGZYBpRvdMVsbuXg)
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)"',grmVG9Xpd40fqHe7DtPbZKkAC8S,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
			if ZgsbN5iSL48t2IhVFnmy not in RDwZryfhWXz735Gb6A1dqICExS:
				RDwZryfhWXz735Gb6A1dqICExS.append(ZgsbN5iSL48t2IhVFnmy)
				FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__watch')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="downloads(.*?)</section>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('"tr flex-start".*?<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for egYIsS2qROfpVW83kx,ZgsbN5iSL48t2IhVFnmy in items:
			if ZgsbN5iSL48t2IhVFnmy not in RDwZryfhWXz735Gb6A1dqICExS:
				if '/?url=' in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.split('/?url=')[1]
				RDwZryfhWXz735Gb6A1dqICExS.append(ZgsbN5iSL48t2IhVFnmy)
				FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
				FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__download____'+egYIsS2qROfpVW83kx)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(text):
	return
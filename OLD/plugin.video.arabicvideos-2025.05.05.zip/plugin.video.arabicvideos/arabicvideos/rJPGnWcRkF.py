# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'BOKRA'
kL0nT7NpZdKVD3jM2OHB = '_BKR_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
headers = {'User-Agent':CJlTSEpZsWb0QHg5w}
qe1JPURnS9ODoCNEpbdh8i67Tur = ['افلام للكبار','بكرا TV']
def hH3sRBSFAr(mode,url,text):
	if   mode==370: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==371: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==372: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==374: SD0TxMRXiep4cjPBsnzI = AuSyOTIFl6fBr0tEzPUkQaMX3(url)
	elif mode==375: SD0TxMRXiep4cjPBsnzI = RGVYXlwxDzsioOCeMH6Spcf(url)
	elif mode==376: SD0TxMRXiep4cjPBsnzI = u35g7rFYXbs1K(0,url)
	elif mode==377: SD0TxMRXiep4cjPBsnzI = u35g7rFYXbs1K(1,url)
	elif mode==379: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-MENU-1st')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,379,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('right-side(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'المميزة',V4kF6EQiwo,375)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'الأحدث',V4kF6EQiwo,376)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+'قائمة الممثلين',V4kF6EQiwo,374)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="container"(.*?)top-menu',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items[7:]:
			title = title.strip(YvOQBzaTAscXR9ql)
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371)
		for ZgsbN5iSL48t2IhVFnmy,title in items[0:7]:
			title = title.strip(YvOQBzaTAscXR9ql)
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371)
	return
def AuSyOTIFl6fBr0tEzPUkQaMX3(website=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-ACTORSMENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="row cat Tags"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if 'http' in ZgsbN5iSL48t2IhVFnmy: continue
			else: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371)
	return
def RGVYXlwxDzsioOCeMH6Spcf(website=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-FEATURED-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"MainContent"(.*?)main-title2',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
				hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('://',':///').replace('//','/').replace(YvOQBzaTAscXR9ql,'%20')
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,372,hzGKUP1XjAoeT79MJcDF)
	return
def u35g7rFYXbs1K(id,website=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-WATCHINGNOW-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('main-title2(.*?)class="row',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[id]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
			if not any(value in title for value in qe1JPURnS9ODoCNEpbdh8i67Tur):
				hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('://',':///').replace('//','/').replace(YvOQBzaTAscXR9ql,'%20')
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,372,hzGKUP1XjAoeT79MJcDF)
	return
def nvHUf8mW6E4GSw5VFRXN(url,WlXkHQR2mp7wKBgGYh4=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if 'vidpage_' in url:
		ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('href="(/Album-.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if ZgsbN5iSL48t2IhVFnmy:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy[0]
			nvHUf8mW6E4GSw5VFRXN(ZgsbN5iSL48t2IhVFnmy)
			return
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class=" subcats"(.*?)class="col-md-3',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if WlXkHQR2mp7wKBgGYh4==CJlTSEpZsWb0QHg5w and s67485upzYNMS3PqDelkrdfo and s67485upzYNMS3PqDelkrdfo[0].count('href')>1:
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',url,371,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'titles')
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy
			title = title.strip(YvOQBzaTAscXR9ql)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371)
	else:
		wDkMP6jlz7XeN5Sp = []
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="col-md-3(.*?)col-xs-12',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="col-sm-8"(.*?)col-xs-12',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
				ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
				title = title.strip(YvOQBzaTAscXR9ql)
				hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('://',':///').replace('//','/').replace(YvOQBzaTAscXR9ql,'%20')
				if '/al_' in ZgsbN5iSL48t2IhVFnmy:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371,hzGKUP1XjAoeT79MJcDF)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) - +الحلقة +\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
					if ABK45TEMpciLnmIlYOafQJZ8t: title = '_MOD_مسلسل '+ABK45TEMpciLnmIlYOafQJZ8t[0]
					if title not in wDkMP6jlz7XeN5Sp:
						wDkMP6jlz7XeN5Sp.append(title)
						khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371,hzGKUP1XjAoeT79MJcDF)
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,372,hzGKUP1XjAoeT79MJcDF)
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('class="pagination(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('class="".*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy
				title = 'صفحة '+wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,371,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'titles')
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('label-success mrg-btm-5 ">(.*?)<',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE): return
	ysw7G3tqjo = CJlTSEpZsWb0QHg5w
	BBwfuWGxUIrdCoc4ka7 = Zy2l0g8QU5vqefaTrsw.findall('var url = "(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7[0]
	else: BBwfuWGxUIrdCoc4ka7 = url.replace('/vidpage_','/Play/')
	if 'http' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = V4kF6EQiwo+BBwfuWGxUIrdCoc4ka7
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.strip('-')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(zz5iuewhAFONn8GQc0DtyKZ317pHo,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'BOKRA-PLAY-2nd')
	Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
	ysw7G3tqjo = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ysw7G3tqjo:
		ysw7G3tqjo = ysw7G3tqjo[-1]
		if 'http' not in ysw7G3tqjo: ysw7G3tqjo = 'http:'+ysw7G3tqjo
		if '/PLAY/' not in BBwfuWGxUIrdCoc4ka7:
			if 'embed.min.js' in ysw7G3tqjo:
				RNCmVx5OPLMhArXcFJZB2 = Zy2l0g8QU5vqefaTrsw.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
				if RNCmVx5OPLMhArXcFJZB2:
					R3brV08ujsItnJ, CTzMPWAO6pBI5m9DvR4n3lFVuq = RNCmVx5OPLMhArXcFJZB2[0]
					ysw7G3tqjo = fUSgd7IjGYX496Hr25uFMl(ysw7G3tqjo,'url')+'/v2/'+R3brV08ujsItnJ+'/config/'+CTzMPWAO6pBI5m9DvR4n3lFVuq+'.json'
		import kORBVznGat
		kORBVznGat.wTf1Sd2gij64hzacOX([ysw7G3tqjo],T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/Search/'+search
	nvHUf8mW6E4GSw5VFRXN(url)
	return
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'IFILM'
kL0nT7NpZdKVD3jM2OHB = '_IFL_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
hRigZpdbjIYsDGr2 = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][1]
SGcRTmovWh8NsAx9f0q2V = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][2]
cOENU4pK5tsij = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][3]
def hH3sRBSFAr(mode,url,GOF25jkXb1DnaB4vhL9,text):
	if   mode==20: SD0TxMRXiep4cjPBsnzI = h0SDVqF2KPQIJl()
	elif mode==21: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ(url)
	elif mode==22: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9)
	elif mode==23: SD0TxMRXiep4cjPBsnzI = j9zTQsrVRx2(url,GOF25jkXb1DnaB4vhL9)
	elif mode==24: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url,text)
	elif mode==25: SD0TxMRXiep4cjPBsnzI = wwsF3KdfyziuXr8gZR0SD6hk(url)
	elif mode==27: SD0TxMRXiep4cjPBsnzI = HrVCKhtwaksjEW(url)
	elif mode==28: SD0TxMRXiep4cjPBsnzI = rbABT5PQzNus9KY1d()
	elif mode==29: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def h0SDVqF2KPQIJl():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'عربي',V4kF6EQiwo,21,CJlTSEpZsWb0QHg5w,'101')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'English',hRigZpdbjIYsDGr2,21,CJlTSEpZsWb0QHg5w,'101')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فارسى',SGcRTmovWh8NsAx9f0q2V,21,CJlTSEpZsWb0QHg5w,'101')
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فارسى 2',cOENU4pK5tsij,21,CJlTSEpZsWb0QHg5w,'101')
	return
def rbABT5PQzNus9KY1d():
	khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+'عربي',V4kF6EQiwo,27)
	khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+'English',hRigZpdbjIYsDGr2,27)
	khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+'فارسى',SGcRTmovWh8NsAx9f0q2V,27)
	khqge7BVD9jPFy1S8T5Gn4QAlH('live',kL0nT7NpZdKVD3jM2OHB+'فارسى 2',cOENU4pK5tsij,27)
	return
def kNjCwITmx4YAShdE62FJ(T9TPlHswJxmtzC4RpKGSvBqA2Uj):
	T1QDsJlUtCGhn = T9TPlHswJxmtzC4RpKGSvBqA2Uj
	if T9TPlHswJxmtzC4RpKGSvBqA2Uj=='IFILM-ARABIC': T9TPlHswJxmtzC4RpKGSvBqA2Uj = V4kF6EQiwo
	elif T9TPlHswJxmtzC4RpKGSvBqA2Uj=='IFILM-ENGLISH': T9TPlHswJxmtzC4RpKGSvBqA2Uj = hRigZpdbjIYsDGr2
	else: T1QDsJlUtCGhn = CJlTSEpZsWb0QHg5w
	qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(T9TPlHswJxmtzC4RpKGSvBqA2Uj)
	if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='ar' or T1QDsJlUtCGhn=='IFILM-ARABIC':
		jUnHpwrQf5X3q8aDG = 'بحث في الموقع'
		K2miyG8hBnz7A3rbZ5DWJsVNapev9g = 'مسلسلات - حالية'
		TV1Zu8bOAfle5vWSpht2nQ = 'مسلسلات - أحدث'
		i2clkCzTV6E = 'مسلسلات - أبجدي'
		BxEDZgLGF9M56fpvk7 = 'بث حي آي فيلم'
		kOFlIhuJ9CB60XoGMnVQ1qejN = 'أفلام'
		Hp970imoFRqyGUMEXwSgLbDjf = 'موسيقى'
		Ve0ifEsLa9B6v8tnuyYoqXhD4kZx = 'برامج'
	elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en' or T1QDsJlUtCGhn=='IFILM-ENGLISH':
		jUnHpwrQf5X3q8aDG = 'Search in site'
		K2miyG8hBnz7A3rbZ5DWJsVNapev9g = 'Series - Current'
		TV1Zu8bOAfle5vWSpht2nQ = 'Series - Latest'
		i2clkCzTV6E = 'Series - Alphabet'
		BxEDZgLGF9M56fpvk7 = 'Live iFilm channel'
		kOFlIhuJ9CB60XoGMnVQ1qejN = 'Movies'
		Hp970imoFRqyGUMEXwSgLbDjf = 'Music'
		Ve0ifEsLa9B6v8tnuyYoqXhD4kZx = 'Shows'
	elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg in ['fa','fa2']:
		jUnHpwrQf5X3q8aDG = 'جستجو در سایت'
		K2miyG8hBnz7A3rbZ5DWJsVNapev9g = 'سريال - جاری'
		TV1Zu8bOAfle5vWSpht2nQ = 'سريال - آخرین'
		i2clkCzTV6E = 'سريال - الفبا'
		BxEDZgLGF9M56fpvk7 = 'پخش زنده اي فيلم'
		kOFlIhuJ9CB60XoGMnVQ1qejN = 'فيلم'
		Hp970imoFRqyGUMEXwSgLbDjf = 'موسيقى'
		Ve0ifEsLa9B6v8tnuyYoqXhD4kZx = 'برنامه ها'
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+jUnHpwrQf5X3q8aDG,T9TPlHswJxmtzC4RpKGSvBqA2Uj,29,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('live',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+BxEDZgLGF9M56fpvk7,T9TPlHswJxmtzC4RpKGSvBqA2Uj,27)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	wtJK8x2e7QPUHqFvEnSp6N5yhO1CA = ['Series','Program','Music']
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/home',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-MENU-1st')
	s67485upzYNMS3PqDelkrdfo=Zy2l0g8QU5vqefaTrsw.findall('button-menu(.*?)/Contact',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if any(value in ZgsbN5iSL48t2IhVFnmy for value in wtJK8x2e7QPUHqFvEnSp6N5yhO1CA):
				url = T9TPlHswJxmtzC4RpKGSvBqA2Uj+ZgsbN5iSL48t2IhVFnmy
				if 'Series' in ZgsbN5iSL48t2IhVFnmy:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+K2miyG8hBnz7A3rbZ5DWJsVNapev9g,url,22,CJlTSEpZsWb0QHg5w,'100')
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+TV1Zu8bOAfle5vWSpht2nQ,url,22,CJlTSEpZsWb0QHg5w,'101')
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+i2clkCzTV6E,url,22,CJlTSEpZsWb0QHg5w,'201')
				elif 'Film' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+kOFlIhuJ9CB60XoGMnVQ1qejN,url,22,CJlTSEpZsWb0QHg5w,'100')
				elif 'Music' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+Hp970imoFRqyGUMEXwSgLbDjf,url,25,CJlTSEpZsWb0QHg5w,'101')
				elif 'Program' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+Ve0ifEsLa9B6v8tnuyYoqXhD4kZx,url,22,CJlTSEpZsWb0QHg5w,'101')
	return bGIVq1CQTjmosZg
def wwsF3KdfyziuXr8gZR0SD6hk(url):
	T9TPlHswJxmtzC4RpKGSvBqA2Uj = QF4S0VZsGLr(url)
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(ggZJf7YnlXHT3IjtMaWe6S,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-MUSIC_MENU-1st')
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('Music-tools-header(.*?)Music-body',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	title = Zy2l0g8QU5vqefaTrsw.findall('<p>(.*?)</p>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)[0]
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,22,CJlTSEpZsWb0QHg5w,'101')
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = T9TPlHswJxmtzC4RpKGSvBqA2Uj + ZgsbN5iSL48t2IhVFnmy
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,23,CJlTSEpZsWb0QHg5w,'101')
	return
def nvHUf8mW6E4GSw5VFRXN(url,GOF25jkXb1DnaB4vhL9):
	T9TPlHswJxmtzC4RpKGSvBqA2Uj = QF4S0VZsGLr(url)
	qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(url)
	type = url.split('/')[-1]
	doUfgB6sxmhJHZ1QejTOu = str(int(GOF25jkXb1DnaB4vhL9)//100)
	GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)%100)
	if type=='Series' and GOF25jkXb1DnaB4vhL9=='0':
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-TITLES-1st')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('serial-body(.*?)class="row',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			title = pd0Na8D5WZfHYkysVS(title)
			title = wAmsc95ya0LHz(title)
			ZgsbN5iSL48t2IhVFnmy = T9TPlHswJxmtzC4RpKGSvBqA2Uj + ZgsbN5iSL48t2IhVFnmy
			hzGKUP1XjAoeT79MJcDF = T9TPlHswJxmtzC4RpKGSvBqA2Uj + O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,23,hzGKUP1XjAoeT79MJcDF,doUfgB6sxmhJHZ1QejTOu+'01')
	j4tamyicXPDHKeTvWJ=0
	if type=='Series': y3LbIjrZvcATpNDM='3'
	if type=='Film': y3LbIjrZvcATpNDM='5'
	if type=='Program': y3LbIjrZvcATpNDM='7'
	if type in ['Series','Program','Film'] and GOF25jkXb1DnaB4vhL9!='0':
		BBwfuWGxUIrdCoc4ka7 = T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Home/PageingItem?category='+y3LbIjrZvcATpNDM+'&page='+GOF25jkXb1DnaB4vhL9+'&size=30&orderby='+doUfgB6sxmhJHZ1QejTOu
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-TITLES-2nd')
		items = Zy2l0g8QU5vqefaTrsw.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for id,title,hzGKUP1XjAoeT79MJcDF in items:
			title = pd0Na8D5WZfHYkysVS(title)
			title = title.replace('\\',CJlTSEpZsWb0QHg5w)
			title = title.replace('"',CJlTSEpZsWb0QHg5w)
			j4tamyicXPDHKeTvWJ += 1
			ZgsbN5iSL48t2IhVFnmy = T9TPlHswJxmtzC4RpKGSvBqA2Uj + '/' + type + '/Content/' + id
			hzGKUP1XjAoeT79MJcDF = T9TPlHswJxmtzC4RpKGSvBqA2Uj + O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
			if type=='Film': khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,24,hzGKUP1XjAoeT79MJcDF,doUfgB6sxmhJHZ1QejTOu+'01')
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,23,hzGKUP1XjAoeT79MJcDF,doUfgB6sxmhJHZ1QejTOu+'01')
	if type=='Music':
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Music/Index?page='+GOF25jkXb1DnaB4vhL9,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-TITLES-3rd')
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('pagination-demo(.*?)pagination-demo',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,hzGKUP1XjAoeT79MJcDF,title in items:
			j4tamyicXPDHKeTvWJ += 1
			hzGKUP1XjAoeT79MJcDF = T9TPlHswJxmtzC4RpKGSvBqA2Uj + hzGKUP1XjAoeT79MJcDF
			ZgsbN5iSL48t2IhVFnmy = T9TPlHswJxmtzC4RpKGSvBqA2Uj + ZgsbN5iSL48t2IhVFnmy
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,23,hzGKUP1XjAoeT79MJcDF,'101')
	if j4tamyicXPDHKeTvWJ>20:
		title='صفحة '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': title = 'Page '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': title = 'صفحه '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': title = 'صفحه '
		for HS8Mws1vU4NkeLOJ in range(1,11) :
			if not GOF25jkXb1DnaB4vhL9==str(HS8Mws1vU4NkeLOJ):
				e91SODCbGIP0uko2lVAqdZmzc = '0'+str(HS8Mws1vU4NkeLOJ)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title+str(HS8Mws1vU4NkeLOJ),url,22,CJlTSEpZsWb0QHg5w,doUfgB6sxmhJHZ1QejTOu+e91SODCbGIP0uko2lVAqdZmzc[-2:])
	return
def j9zTQsrVRx2(url,GOF25jkXb1DnaB4vhL9):
	if not GOF25jkXb1DnaB4vhL9: GOF25jkXb1DnaB4vhL9 = 0
	T9TPlHswJxmtzC4RpKGSvBqA2Uj = QF4S0VZsGLr(url)
	pU731HfF4sAIayWOjRxzQu8LV = QF4S0VZsGLr(url)
	qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(url)
	WyHwgmzU0GnP = url.split('/')
	id,type = WyHwgmzU0GnP[-1],WyHwgmzU0GnP[3]
	doUfgB6sxmhJHZ1QejTOu = str(int(GOF25jkXb1DnaB4vhL9)//100)
	GOF25jkXb1DnaB4vhL9 = str(int(GOF25jkXb1DnaB4vhL9)%100)
	j4tamyicXPDHKeTvWJ = 0
	if type=='Series':
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-EPISODES-1st')
		items = Zy2l0g8QU5vqefaTrsw.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		title = ' - الحلقة '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': title = ' - Episode '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': title = ' - قسمت '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': title = ' - قسمت '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': AnfpT5JCbhlqRiELVPZ0WUuo = CJlTSEpZsWb0QHg5w
		else: AnfpT5JCbhlqRiELVPZ0WUuo = qqU8ZQfsNRWFGhKkjm6d4rAPHvg
		DMf9SicWY2boxuvHjlZkL1QtX = Zy2l0g8QU5vqefaTrsw.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for name,count,hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy in items:
			for ABK45TEMpciLnmIlYOafQJZ8t in range(int(count),0,-1):
				iRChAlY614xNq = hzGKUP1XjAoeT79MJcDF + AnfpT5JCbhlqRiELVPZ0WUuo + id + '/' + str(ABK45TEMpciLnmIlYOafQJZ8t) + '.png'
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = name + title + str(ABK45TEMpciLnmIlYOafQJZ8t)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = wAmsc95ya0LHz(K2miyG8hBnz7A3rbZ5DWJsVNapev9g)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+K2miyG8hBnz7A3rbZ5DWJsVNapev9g,url,24,iRChAlY614xNq,CJlTSEpZsWb0QHg5w,str(ABK45TEMpciLnmIlYOafQJZ8t))
	elif type=='Program':
		BBwfuWGxUIrdCoc4ka7 = T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+GOF25jkXb1DnaB4vhL9+'&size=30&orderby=1'
		bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-EPISODES-2nd')
		items = Zy2l0g8QU5vqefaTrsw.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		title = ' - الحلقة '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': title = ' - Episode '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': title = ' - قسمت '
		if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': title = ' - قسمت '
		for ABK45TEMpciLnmIlYOafQJZ8t,hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,DaCwR3vdTcbQkXtYJENGu01sAiUWKZ,name in items:
			j4tamyicXPDHKeTvWJ += 1
			iRChAlY614xNq = pU731HfF4sAIayWOjRxzQu8LV + O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
			name = pd0Na8D5WZfHYkysVS(name)
			K2miyG8hBnz7A3rbZ5DWJsVNapev9g = name + title + str(ABK45TEMpciLnmIlYOafQJZ8t)
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+K2miyG8hBnz7A3rbZ5DWJsVNapev9g,BBwfuWGxUIrdCoc4ka7,24,iRChAlY614xNq,CJlTSEpZsWb0QHg5w,str(j4tamyicXPDHKeTvWJ))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			BBwfuWGxUIrdCoc4ka7 = T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Music/GetTracksBy?id='+str(id)+'&page='+GOF25jkXb1DnaB4vhL9+'&size=30&type=0'
			bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-EPISODES-3rd')
			items = Zy2l0g8QU5vqefaTrsw.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,name,title in items:
				j4tamyicXPDHKeTvWJ += 1
				iRChAlY614xNq = pU731HfF4sAIayWOjRxzQu8LV + O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = name + ' - ' + title
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = K2miyG8hBnz7A3rbZ5DWJsVNapev9g.strip(YvOQBzaTAscXR9ql)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = pd0Na8D5WZfHYkysVS(K2miyG8hBnz7A3rbZ5DWJsVNapev9g)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+K2miyG8hBnz7A3rbZ5DWJsVNapev9g,BBwfuWGxUIrdCoc4ka7,24,iRChAlY614xNq,CJlTSEpZsWb0QHg5w,str(j4tamyicXPDHKeTvWJ))
		elif 'Clips' in url:
			BBwfuWGxUIrdCoc4ka7 = T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Music/GetTracksBy?id=0&page='+GOF25jkXb1DnaB4vhL9+'&size=30&type=15'
			bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-EPISODES-4th')
			items = Zy2l0g8QU5vqefaTrsw.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for hzGKUP1XjAoeT79MJcDF,title,ZgsbN5iSL48t2IhVFnmy in items:
				j4tamyicXPDHKeTvWJ += 1
				iRChAlY614xNq = pU731HfF4sAIayWOjRxzQu8LV + O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = title.strip(YvOQBzaTAscXR9ql)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = pd0Na8D5WZfHYkysVS(K2miyG8hBnz7A3rbZ5DWJsVNapev9g)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+K2miyG8hBnz7A3rbZ5DWJsVNapev9g,BBwfuWGxUIrdCoc4ka7,24,iRChAlY614xNq,CJlTSEpZsWb0QHg5w,str(j4tamyicXPDHKeTvWJ))
		elif 'category' in url:
			if 'category=6' in url:
				BBwfuWGxUIrdCoc4ka7 = T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Music/GetTracksBy?id=0&page='+GOF25jkXb1DnaB4vhL9+'&size=30&type=6'
				bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				BBwfuWGxUIrdCoc4ka7 = T9TPlHswJxmtzC4RpKGSvBqA2Uj+'/Music/GetTracksBy?id=0&page='+GOF25jkXb1DnaB4vhL9+'&size=30&type=4'
				bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-EPISODES-6th')
			items = Zy2l0g8QU5vqefaTrsw.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,name,title in items:
				j4tamyicXPDHKeTvWJ += 1
				iRChAlY614xNq = pU731HfF4sAIayWOjRxzQu8LV + O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = name + ' - ' + title
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = K2miyG8hBnz7A3rbZ5DWJsVNapev9g.strip(YvOQBzaTAscXR9ql)
				K2miyG8hBnz7A3rbZ5DWJsVNapev9g = pd0Na8D5WZfHYkysVS(K2miyG8hBnz7A3rbZ5DWJsVNapev9g)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+K2miyG8hBnz7A3rbZ5DWJsVNapev9g,BBwfuWGxUIrdCoc4ka7,24,iRChAlY614xNq,CJlTSEpZsWb0QHg5w,str(j4tamyicXPDHKeTvWJ))
	if type=='Music' or type=='Program':
		if j4tamyicXPDHKeTvWJ>25:
			title='صفحة '
			if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': title = ' Page '
			if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': title = ' صفحه '
			if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': title = ' صفحه '
			for HS8Mws1vU4NkeLOJ in range(1,11):
				if not GOF25jkXb1DnaB4vhL9==str(HS8Mws1vU4NkeLOJ):
					e91SODCbGIP0uko2lVAqdZmzc = '0'+str(HS8Mws1vU4NkeLOJ)
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title+str(HS8Mws1vU4NkeLOJ),url,23,CJlTSEpZsWb0QHg5w,doUfgB6sxmhJHZ1QejTOu+e91SODCbGIP0uko2lVAqdZmzc[-2:])
	return
def rHwfOZb3oSgJKi(url,ABK45TEMpciLnmIlYOafQJZ8t):
	pU731HfF4sAIayWOjRxzQu8LV = QF4S0VZsGLr(url)
	Uz8mMbZifCyvkLnct,MNXzjK3vV7D = [],[]
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-PLAY-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(url)
		WyHwgmzU0GnP = url.split('/')
		id,type = WyHwgmzU0GnP[-1],WyHwgmzU0GnP[3]
		ZgsbN5iSL48t2IhVFnmy = items[0][0]+qqU8ZQfsNRWFGhKkjm6d4rAPHvg+id+'/,'+ABK45TEMpciLnmIlYOafQJZ8t+','+ABK45TEMpciLnmIlYOafQJZ8t+'_'+items[0][2]
		Uz8mMbZifCyvkLnct.append('m3u8')
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	items = Zy2l0g8QU5vqefaTrsw.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(url)
		WyHwgmzU0GnP = url.split('/')
		id,type = WyHwgmzU0GnP[-1],WyHwgmzU0GnP[3]
		ZgsbN5iSL48t2IhVFnmy = items[0][0]+qqU8ZQfsNRWFGhKkjm6d4rAPHvg+id+'/'+ABK45TEMpciLnmIlYOafQJZ8t+items[0][2]
		Uz8mMbZifCyvkLnct.append('mp4 url')
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	items = Zy2l0g8QU5vqefaTrsw.findall('source src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy in items:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('//','/')
		Uz8mMbZifCyvkLnct.append('mp4 src')
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	items = Zy2l0g8QU5vqefaTrsw.findall('VideoAddress":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		ZgsbN5iSL48t2IhVFnmy = items[int(ABK45TEMpciLnmIlYOafQJZ8t)-1]
		ZgsbN5iSL48t2IhVFnmy = pU731HfF4sAIayWOjRxzQu8LV+O4Ak3NXpyUHvE(ZgsbN5iSL48t2IhVFnmy)
		Uz8mMbZifCyvkLnct.append('mp4 address')
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	items = Zy2l0g8QU5vqefaTrsw.findall('VoiceAddress":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		ZgsbN5iSL48t2IhVFnmy = items[int(ABK45TEMpciLnmIlYOafQJZ8t)-1]
		ZgsbN5iSL48t2IhVFnmy = pU731HfF4sAIayWOjRxzQu8LV+O4Ak3NXpyUHvE(ZgsbN5iSL48t2IhVFnmy)
		Uz8mMbZifCyvkLnct.append('mp3 address')
		MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	if len(MNXzjK3vV7D)==1: ZgsbN5iSL48t2IhVFnmy = MNXzjK3vV7D[0]
	else:
		CrqTamtPFuU = T4TK17YsEfZJ('اختر الفيديو المناسب:', Uz8mMbZifCyvkLnct)
		if CrqTamtPFuU == -1 : return
		ZgsbN5iSL48t2IhVFnmy = MNXzjK3vV7D[CrqTamtPFuU]
	ZQtv0jY9W6L8UHgpnKm(ZgsbN5iSL48t2IhVFnmy,T1QDsJlUtCGhn,'video')
	return
def QF4S0VZsGLr(url):
	if V4kF6EQiwo in url: ad3z2451e09FrDHmvci = V4kF6EQiwo
	elif hRigZpdbjIYsDGr2 in url: ad3z2451e09FrDHmvci = hRigZpdbjIYsDGr2
	elif SGcRTmovWh8NsAx9f0q2V in url: ad3z2451e09FrDHmvci = SGcRTmovWh8NsAx9f0q2V
	elif cOENU4pK5tsij in url: ad3z2451e09FrDHmvci = cOENU4pK5tsij
	else: ad3z2451e09FrDHmvci = CJlTSEpZsWb0QHg5w
	return ad3z2451e09FrDHmvci
def YCIrNVn8sLXeudGHMTjFp2(url):
	if   V4kF6EQiwo in url: qqU8ZQfsNRWFGhKkjm6d4rAPHvg = 'ar'
	elif hRigZpdbjIYsDGr2 in url: qqU8ZQfsNRWFGhKkjm6d4rAPHvg = 'en'
	elif SGcRTmovWh8NsAx9f0q2V in url: qqU8ZQfsNRWFGhKkjm6d4rAPHvg = 'fa'
	elif cOENU4pK5tsij in url: qqU8ZQfsNRWFGhKkjm6d4rAPHvg = 'fa2'
	else: qqU8ZQfsNRWFGhKkjm6d4rAPHvg = CJlTSEpZsWb0QHg5w
	return qqU8ZQfsNRWFGhKkjm6d4rAPHvg
def HrVCKhtwaksjEW(url):
	qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(url)
	BBwfuWGxUIrdCoc4ka7 = url + '/Home/Live'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-LIVE-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = Zy2l0g8QU5vqefaTrsw.findall('source src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	ysw7G3tqjo = items[0]
	ZQtv0jY9W6L8UHgpnKm(ysw7G3tqjo,T1QDsJlUtCGhn,'live')
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if not search:
		search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
		if not search: return
	QjfknOVHzZIUir = search.replace(YvOQBzaTAscXR9ql,'+')
	if showDialogs:
		aaMuOP4j5pcD = [ V4kF6EQiwo , hRigZpdbjIYsDGr2 , SGcRTmovWh8NsAx9f0q2V , cOENU4pK5tsij ]
		eNiOIGc7DQnMt = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		CrqTamtPFuU = T4TK17YsEfZJ('اختر اللغة المناسبة:', eNiOIGc7DQnMt)
		if CrqTamtPFuU == -1 : return
		website = aaMuOP4j5pcD[CrqTamtPFuU]
	else:
		if '_IFILM-ARABIC_' in EcrV3IasOo4Hq: website = V4kF6EQiwo
		elif '_IFILM-ENGLISH_' in EcrV3IasOo4Hq: website = hRigZpdbjIYsDGr2
		else: website = CJlTSEpZsWb0QHg5w
	if not website: return
	qqU8ZQfsNRWFGhKkjm6d4rAPHvg = YCIrNVn8sLXeudGHMTjFp2(website)
	BBwfuWGxUIrdCoc4ka7 = website + "/Home/Search?searchstring=" + QjfknOVHzZIUir
	bGIVq1CQTjmosZg = FFkYHvnOyQUwLpuJIhrdx9EgP(DRmUs7l1O4xLeZYzGITXk,BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'IFILM-SEARCH-1st')
	items = Zy2l0g8QU5vqefaTrsw.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if items:
		for hzGKUP1XjAoeT79MJcDF,y3LbIjrZvcATpNDM,id,title in items:
			if y3LbIjrZvcATpNDM in ['3','7']:
				title = title.replace('\\',CJlTSEpZsWb0QHg5w)
				title = title.replace('"',CJlTSEpZsWb0QHg5w)
				if y3LbIjrZvcATpNDM=='3':
					type = 'Series'
					if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='ar': name = 'مسلسل : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': name = 'Series : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': name = 'سريال ها : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': name = 'سريال ها : '
				elif y3LbIjrZvcATpNDM=='5':
					type = 'Film'
					if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='ar': name = 'فيلم : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': name = 'Movie : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': name = 'فيلم : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': name = 'فلم ها : '
				elif y3LbIjrZvcATpNDM=='7':
					type = 'Program'
					if qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='ar': name = 'برنامج : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='en': name = 'Program : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa': name = 'برنامه ها : '
					elif qqU8ZQfsNRWFGhKkjm6d4rAPHvg=='fa2': name = 'برنامه ها : '
				title = name + title
				ZgsbN5iSL48t2IhVFnmy = website + '/' + type + '/Content/' + id
				hzGKUP1XjAoeT79MJcDF = O4Ak3NXpyUHvE(hzGKUP1XjAoeT79MJcDF)
				hzGKUP1XjAoeT79MJcDF = website+hzGKUP1XjAoeT79MJcDF
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,23,hzGKUP1XjAoeT79MJcDF,'101')
	return
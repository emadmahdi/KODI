# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
import bs4 as j9Ptk2a1mz0NqS
T1QDsJlUtCGhn = 'ELCINEMA'
kL0nT7NpZdKVD3jM2OHB = '_ELC_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
headers = {'Referer':V4kF6EQiwo}
qe1JPURnS9ODoCNEpbdh8i67Tur = []
def hH3sRBSFAr(mode,url,text):
	if   mode==510: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==511: SD0TxMRXiep4cjPBsnzI = ot9EDdYTZu5cUfp(url)
	elif mode==512: SD0TxMRXiep4cjPBsnzI = gc0NCfH2e7VuUjYw4OJimEQkB3Av(url)
	elif mode==513: SD0TxMRXiep4cjPBsnzI = ymXT6HgbcNOlBtunG(url)
	elif mode==514: SD0TxMRXiep4cjPBsnzI = hP2v5s3xnbe6kZQJ9qaTDdY(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: SD0TxMRXiep4cjPBsnzI = hP2v5s3xnbe6kZQJ9qaTDdY(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: SD0TxMRXiep4cjPBsnzI = lYu0XNoJ31mR4T26cskqvKxBM(text)
	elif mode==517: SD0TxMRXiep4cjPBsnzI = K6KRFw8EiCVtf1hNx(url)
	elif mode==518: SD0TxMRXiep4cjPBsnzI = UBVWp2SNXTbfthDj5OmQlKnyaz3F(url)
	elif mode==519: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	elif mode==520: SD0TxMRXiep4cjPBsnzI = jkuA2oXEQ7xUGp(url)
	elif mode==521: SD0TxMRXiep4cjPBsnzI = jQ40JHnaeMPlqhwZd7mC(url)
	elif mode==522: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==523: SD0TxMRXiep4cjPBsnzI = n8UhHC2Gc4lWksT1dqY0MypVfPx(text)
	elif mode==524: SD0TxMRXiep4cjPBsnzI = loY7C3uOWAE1QnydbPtaZg4M90h()
	elif mode==525: SD0TxMRXiep4cjPBsnzI = EGqfQ6mA7pCPIHOWb0ZMvxDSYL()
	elif mode==526: SD0TxMRXiep4cjPBsnzI = yeTsJhoNcqlYu0kdLU6gRKFVZjbX()
	elif mode==527: SD0TxMRXiep4cjPBsnzI = VMhf9rucOP5sHNEwnFAd()
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث بموسوعة السينما',CJlTSEpZsWb0QHg5w,519)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'موسوعة الأعمال',CJlTSEpZsWb0QHg5w,525)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'موسوعة الأشخاص',CJlTSEpZsWb0QHg5w,526)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'موسوعة المصنفات',CJlTSEpZsWb0QHg5w,527)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'موسوعة المنوعات',CJlTSEpZsWb0QHg5w,524)
	return
def loY7C3uOWAE1QnydbPtaZg4M90h():
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' فيديوهات - خاصة',V4kF6EQiwo+'/video',520)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فيديوهات - أحدث',V4kF6EQiwo+'/video/latest',521)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فيديوهات - أقدم',V4kF6EQiwo+'/video/oldest',521)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فيديوهات - أكثر مشاهدة',V4kF6EQiwo+'/video/views',521)
	return
def EGqfQ6mA7pCPIHOWb0ZMvxDSYL():
	wPH2lpyDXVN3WfKQ = V4kF6EQiwo+'/lineup?utf8=%E2%9C%93'
	OnGWDfTqAapx5w4EuYv = wPH2lpyDXVN3WfKQ+'&type=2&category=1&foreign=false&tag='
	UmI7OBf8jgXqtCVKvsNHJ4REa = wPH2lpyDXVN3WfKQ+'&type=2&category=3&foreign=false&tag='
	vaK5nxV9ewjIqu3TpDMkRfAiXU = wPH2lpyDXVN3WfKQ+'&type=2&category=1&foreign=true&tag='
	Esa0fX1Wj8gtR4mT = wPH2lpyDXVN3WfKQ+'&type=2&category=3&foreign=true&tag='
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات أفلام عربي',OnGWDfTqAapx5w4EuYv,511)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات مسلسلات عربي',UmI7OBf8jgXqtCVKvsNHJ4REa,511)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات أفلام اجنبي',vaK5nxV9ewjIqu3TpDMkRfAiXU,511)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات مسلسلات اجنبي',Esa0fX1Wj8gtR4mT,511)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس أعمال أبجدي',V4kF6EQiwo+'/index/work/alphabet',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس  بلد الإنتاج',V4kF6EQiwo+'/index/work/country',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس اللغة',V4kF6EQiwo+'/index/work/language',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس مصنفات العمل',V4kF6EQiwo+'/index/work/genre',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس سنة الإصدار',V4kF6EQiwo+'/index/work/release_year',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مواسم - فلتر محدد',V4kF6EQiwo+'/seasonals',515)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مواسم - فلتر كامل',V4kF6EQiwo+'/seasonals',514)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات - فلتر محدد',V4kF6EQiwo+'/lineup',515)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات - فلتر كامل',V4kF6EQiwo+'/lineup',514)
	return
def VMhf9rucOP5sHNEwnFAd():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',V4kF6EQiwo+'/lineup',CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	D3D6TF50oUBtJlvijPMW8ys = yzBNMPF13j.find('select',attrs={'name':'tag'})
	EcrV3IasOo4Hq = D3D6TF50oUBtJlvijPMW8ys.find_all('option')
	for ll5WFBCJKhA64tIDT8qvX in EcrV3IasOo4Hq:
		value = ll5WFBCJKhA64tIDT8qvX.get('value')
		if not value: continue
		title = ll5WFBCJKhA64tIDT8qvX.text
		if BB7oCRfQNSYj5qDhTUevV:
			title = title.encode(Im5KSGZYBpRvdMVsbuXg)
			value = value.encode(Im5KSGZYBpRvdMVsbuXg)
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+value
		title = title.replace('قائمة ',CJlTSEpZsWb0QHg5w)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,511)
	return
def yeTsJhoNcqlYu0kdLU6gRKFVZjbX():
	wPH2lpyDXVN3WfKQ = V4kF6EQiwo+'/lineup?utf8=%E2%9C%93'
	A8CdXURF1Tkrp0t6LJ = wPH2lpyDXVN3WfKQ+'&type=1&category=&foreign=&tag='
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات أشخاص',A8CdXURF1Tkrp0t6LJ,511)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس أشخاص أبجدي',V4kF6EQiwo+'/index/person/alphabet',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس موطن',V4kF6EQiwo+'/index/person/nationality',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس  تاريخ الميلاد',V4kF6EQiwo+'/index/person/birth_year',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'فهرس  تاريخ الوفاة',V4kF6EQiwo+'/index/person/death_year',517)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات - فلتر محدد',V4kF6EQiwo+'/lineup',515)
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مصنفات - فلتر كامل',V4kF6EQiwo+'/lineup',514)
	return
def ot9EDdYTZu5cUfp(url):
	if '/seasonals' in url: lDgx8hPyYJvcX = 0
	elif '/lineup' in url: lDgx8hPyYJvcX = 1
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-LISTS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	p3LfChWJd124eAYj78zw09SXonH = yzBNMPF13j.find_all(class_='jumbo-theater clearfix')
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		title = D3D6TF50oUBtJlvijPMW8ys.find_all('a')[lDgx8hPyYJvcX].text
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+D3D6TF50oUBtJlvijPMW8ys.find_all('a')[lDgx8hPyYJvcX].get('href')
		if BB7oCRfQNSYj5qDhTUevV:
			title = title.encode(Im5KSGZYBpRvdMVsbuXg)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
		if not p3LfChWJd124eAYj78zw09SXonH:
			gc0NCfH2e7VuUjYw4OJimEQkB3Av(ZgsbN5iSL48t2IhVFnmy)
			return
		else:
			title = title.replace('قائمة ',CJlTSEpZsWb0QHg5w)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,512)
	aFE4IKnmld(yzBNMPF13j,511)
	return
def aFE4IKnmld(yzBNMPF13j,mode):
	D3D6TF50oUBtJlvijPMW8ys = yzBNMPF13j.find(class_='pagination')
	if D3D6TF50oUBtJlvijPMW8ys:
		OO0Qk3lYgVDot2NBjfdP = D3D6TF50oUBtJlvijPMW8ys.find_all('a')
		T87wkWyZuAjG9xlVrU6egQMq = D3D6TF50oUBtJlvijPMW8ys.find_all('li')
		V0BKOzTF2sSCHablAdMurp75 = list(zip(OO0Qk3lYgVDot2NBjfdP,T87wkWyZuAjG9xlVrU6egQMq))
		LxNV5lenkhW6zoBJDMA7ZuqSg = -1
		dd4LT95xC1Gwh6fF = len(V0BKOzTF2sSCHablAdMurp75)
		for FqVRbwzuN5yhPJSsQE6n,iMWR3HEKdCsTIUOn8S0FlPVQ7 in V0BKOzTF2sSCHablAdMurp75:
			LxNV5lenkhW6zoBJDMA7ZuqSg += 1
			iMWR3HEKdCsTIUOn8S0FlPVQ7 = iMWR3HEKdCsTIUOn8S0FlPVQ7['class']
			if 'unavailable' in iMWR3HEKdCsTIUOn8S0FlPVQ7 or 'current' in iMWR3HEKdCsTIUOn8S0FlPVQ7: continue
			TV1Zu8bOAfle5vWSpht2nQ = FqVRbwzuN5yhPJSsQE6n.text
			otCOTHujWKp7Dn6dvcafPqlx = V4kF6EQiwo+FqVRbwzuN5yhPJSsQE6n.get('href')
			if BB7oCRfQNSYj5qDhTUevV:
				TV1Zu8bOAfle5vWSpht2nQ = TV1Zu8bOAfle5vWSpht2nQ.encode(Im5KSGZYBpRvdMVsbuXg)
				otCOTHujWKp7Dn6dvcafPqlx = otCOTHujWKp7Dn6dvcafPqlx.encode(Im5KSGZYBpRvdMVsbuXg)
			if   LxNV5lenkhW6zoBJDMA7ZuqSg==0: TV1Zu8bOAfle5vWSpht2nQ = 'أولى'
			elif LxNV5lenkhW6zoBJDMA7ZuqSg==1: TV1Zu8bOAfle5vWSpht2nQ = 'سابقة'
			elif LxNV5lenkhW6zoBJDMA7ZuqSg==dd4LT95xC1Gwh6fF-2: TV1Zu8bOAfle5vWSpht2nQ = 'لاحقة'
			elif LxNV5lenkhW6zoBJDMA7ZuqSg==dd4LT95xC1Gwh6fF-1: TV1Zu8bOAfle5vWSpht2nQ = 'أخيرة'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+TV1Zu8bOAfle5vWSpht2nQ,otCOTHujWKp7Dn6dvcafPqlx,mode)
	return
def gc0NCfH2e7VuUjYw4OJimEQkB3Av(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-TITLES1-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	p3LfChWJd124eAYj78zw09SXonH = yzBNMPF13j.find_all(class_='row')
	items,vhOcSIwNZ2TC8tEPR = [],True
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		if not D3D6TF50oUBtJlvijPMW8ys.find(class_='thumbnail-wrapper'): continue
		if vhOcSIwNZ2TC8tEPR: vhOcSIwNZ2TC8tEPR = False ; continue
		hBUjNdHip61tIqcPOVsDTkY = []
		D9laJcXPxgb = D3D6TF50oUBtJlvijPMW8ys.find_all(class_=['censorship red','censorship purple'])
		for vrBI9XJiL24opDK3hQ in D9laJcXPxgb:
			ccnb52oKNm9ts6xyXYJBL0E = vrBI9XJiL24opDK3hQ.find_all('li')[1].text
			if BB7oCRfQNSYj5qDhTUevV:
				ccnb52oKNm9ts6xyXYJBL0E = ccnb52oKNm9ts6xyXYJBL0E.encode(Im5KSGZYBpRvdMVsbuXg)
			hBUjNdHip61tIqcPOVsDTkY.append(ccnb52oKNm9ts6xyXYJBL0E)
		if not GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,CJlTSEpZsWb0QHg5w,hBUjNdHip61tIqcPOVsDTkY,False):
			t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('data-src')
			title = D3D6TF50oUBtJlvijPMW8ys.find('h3')
			name = title.find('a').text
			ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+title.find('a').get('href')
			ia9PCofuMkqvUtypFOxXjD7J = D3D6TF50oUBtJlvijPMW8ys.find(class_='no-margin')
			qB30x862LdzsOw = D3D6TF50oUBtJlvijPMW8ys.find(class_='legend')
			if ia9PCofuMkqvUtypFOxXjD7J: ia9PCofuMkqvUtypFOxXjD7J = ia9PCofuMkqvUtypFOxXjD7J.text
			if qB30x862LdzsOw: qB30x862LdzsOw = qB30x862LdzsOw.text
			if BB7oCRfQNSYj5qDhTUevV:
				t4zynV13ZoPe = t4zynV13ZoPe.encode(Im5KSGZYBpRvdMVsbuXg)
				name = name.encode(Im5KSGZYBpRvdMVsbuXg)
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
				if ia9PCofuMkqvUtypFOxXjD7J: ia9PCofuMkqvUtypFOxXjD7J = ia9PCofuMkqvUtypFOxXjD7J.encode(Im5KSGZYBpRvdMVsbuXg)
			TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = {}
			if qB30x862LdzsOw: TiPIxOFX2bS5ZDG4A1KoeVUyW0dh['stars'] = qB30x862LdzsOw
			if ia9PCofuMkqvUtypFOxXjD7J:
				ia9PCofuMkqvUtypFOxXjD7J = ia9PCofuMkqvUtypFOxXjD7J.replace(rJ9cgWz4FU,' .. ')
				TiPIxOFX2bS5ZDG4A1KoeVUyW0dh['plot'] = ia9PCofuMkqvUtypFOxXjD7J.replace('...اقرأ المزيد',CJlTSEpZsWb0QHg5w)
			if '/work/' in ZgsbN5iSL48t2IhVFnmy:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,516,t4zynV13ZoPe,CJlTSEpZsWb0QHg5w,name,CJlTSEpZsWb0QHg5w,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
			elif '/person/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,513,t4zynV13ZoPe,CJlTSEpZsWb0QHg5w,name,CJlTSEpZsWb0QHg5w,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	aFE4IKnmld(yzBNMPF13j,512)
	return
def ymXT6HgbcNOlBtunG(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-TITLES2-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	p3LfChWJd124eAYj78zw09SXonH = yzBNMPF13j.find_all('li')
	CCImnA9gHWYJreXMB,items = [],[]
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		if not D3D6TF50oUBtJlvijPMW8ys.find(class_='thumbnail-wrapper'): continue
		if not D3D6TF50oUBtJlvijPMW8ys.find(class_=['unstyled','unstyled text-center']): continue
		if D3D6TF50oUBtJlvijPMW8ys.find(class_='hide'): continue
		title = D3D6TF50oUBtJlvijPMW8ys.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in CCImnA9gHWYJreXMB: continue
		CCImnA9gHWYJreXMB.append(name)
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+title.find('a').get('href')
		if '/search/work/' in url: t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('src')
		elif '/search/person/' in url: t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('data-src')
		elif '/search/video/' in url: t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('data-src')
		else: t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('src')
		if BB7oCRfQNSYj5qDhTUevV:
			name = name.encode(Im5KSGZYBpRvdMVsbuXg)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
			t4zynV13ZoPe = t4zynV13ZoPe.encode(Im5KSGZYBpRvdMVsbuXg)
		name = name.strip(YvOQBzaTAscXR9ql)
		items.append((name,ZgsbN5iSL48t2IhVFnmy,t4zynV13ZoPe))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,ZgsbN5iSL48t2IhVFnmy,t4zynV13ZoPe in items:
		if '/search/video/' in url: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,522,t4zynV13ZoPe)
		elif '/search/person/' in url: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,513,t4zynV13ZoPe,CJlTSEpZsWb0QHg5w,name)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,516,t4zynV13ZoPe,CJlTSEpZsWb0QHg5w,name)
	return
def lYu0XNoJ31mR4T26cskqvKxBM(text):
	text = text.replace('الإعلان',CJlTSEpZsWb0QHg5w).replace('لفيلم',CJlTSEpZsWb0QHg5w).replace('الرسمي',CJlTSEpZsWb0QHg5w)
	text = text.replace('إعلان',CJlTSEpZsWb0QHg5w).replace('فيلم',CJlTSEpZsWb0QHg5w).replace('البرومو',CJlTSEpZsWb0QHg5w)
	text = text.replace('التشويقي',CJlTSEpZsWb0QHg5w).replace('لمسلسل',CJlTSEpZsWb0QHg5w).replace('مسلسل',CJlTSEpZsWb0QHg5w)
	text = text.replace(':',CJlTSEpZsWb0QHg5w).replace(')',CJlTSEpZsWb0QHg5w).replace('(',CJlTSEpZsWb0QHg5w).replace(',',CJlTSEpZsWb0QHg5w)
	text = text.replace('_',CJlTSEpZsWb0QHg5w).replace(';',CJlTSEpZsWb0QHg5w).replace('-',CJlTSEpZsWb0QHg5w).replace('.',CJlTSEpZsWb0QHg5w)
	text = text.replace('\'',CJlTSEpZsWb0QHg5w).replace('\"',CJlTSEpZsWb0QHg5w)
	text = text.replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
	text = text.strip(YvOQBzaTAscXR9ql)
	jjV3ys5GPKBlO4dpAIuinYFZogN = text.count(YvOQBzaTAscXR9ql)+1
	if jjV3ys5GPKBlO4dpAIuinYFZogN==1:
		n8UhHC2Gc4lWksT1dqY0MypVfPx(text)
		return
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',kL0nT7NpZdKVD3jM2OHB+Dj62UpP5MrbTkJqhRa+'==== كلمات للبحث ===='+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	dd9eaGTQzEybmRkh1I = text.split(YvOQBzaTAscXR9ql)
	x8qgltONCwZUiRBzMuA = pow(2,jjV3ys5GPKBlO4dpAIuinYFZogN)
	cveatiu5V6kNl72sxr1XOCLhDB4G = []
	def SgGUtBPmTQNH4(C1ZzP82RTx4IGKWb7sh,knrd6ixTJv48KeRNstpFOUAGS):
		if C1ZzP82RTx4IGKWb7sh=='1': return knrd6ixTJv48KeRNstpFOUAGS
		return CJlTSEpZsWb0QHg5w
	for LxNV5lenkhW6zoBJDMA7ZuqSg in range(x8qgltONCwZUiRBzMuA,0,-1):
		RowukSMXJVmcZqG8a6h3DLpCIUf = list(jjV3ys5GPKBlO4dpAIuinYFZogN*'0'+bin(LxNV5lenkhW6zoBJDMA7ZuqSg)[2:])[-jjV3ys5GPKBlO4dpAIuinYFZogN:]
		RowukSMXJVmcZqG8a6h3DLpCIUf = reversed(RowukSMXJVmcZqG8a6h3DLpCIUf)
		GzWuVjwZgDKa5PCcQTM4 = map(SgGUtBPmTQNH4,RowukSMXJVmcZqG8a6h3DLpCIUf,dd9eaGTQzEybmRkh1I)
		title = YvOQBzaTAscXR9ql.join(filter(None,GzWuVjwZgDKa5PCcQTM4))
		if BB7oCRfQNSYj5qDhTUevV: II4x930lvTuVqekXBNCrMy = title.decode(Im5KSGZYBpRvdMVsbuXg)
		else: II4x930lvTuVqekXBNCrMy = title
		if len(II4x930lvTuVqekXBNCrMy)>2 and title not in cveatiu5V6kNl72sxr1XOCLhDB4G:
			cveatiu5V6kNl72sxr1XOCLhDB4G.append(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,CJlTSEpZsWb0QHg5w,523,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,title)
	return
def n8UhHC2Gc4lWksT1dqY0MypVfPx(lrpUStmO67zg):
	if BB7oCRfQNSYj5qDhTUevV:
		lrpUStmO67zg = lrpUStmO67zg.decode(Im5KSGZYBpRvdMVsbuXg)
		import arabic_reshaper as AAk0CdOYlxLbh,bidi.algorithm as dz6mk9cAg0XbMFqJ28yZ
		lrpUStmO67zg = AAk0CdOYlxLbh.ArabicReshaper().reshape(lrpUStmO67zg)
		lrpUStmO67zg = dz6mk9cAg0XbMFqJ28yZ.get_display(lrpUStmO67zg)
	import KxIcVHk2jg
	lrpUStmO67zg = tmMVl2yEWYoRg1LjHfPXGc7wqK0s(twIOydEe6zhn1s=lrpUStmO67zg)
	KxIcVHk2jg.HYGiJ9pfmMTnIb4L7tX(lrpUStmO67zg)
	return
def K6KRFw8EiCVtf1hNx(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-INDEXES_LISTS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	D3D6TF50oUBtJlvijPMW8ys = yzBNMPF13j.find(class_='list-separator list-title')
	RYHIKeQZLBpbNvmhkq2GV1C = D3D6TF50oUBtJlvijPMW8ys.find_all('a')
	items = []
	for title in RYHIKeQZLBpbNvmhkq2GV1C:
		name = title.text
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+title.get('href')
		if BB7oCRfQNSYj5qDhTUevV:
			name = name.encode(Im5KSGZYBpRvdMVsbuXg)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
		if '#' not in ZgsbN5iSL48t2IhVFnmy: items.append((name,ZgsbN5iSL48t2IhVFnmy))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for jglfWFcvo1mAdH9yeROS7XKNxu in items:
		name,ZgsbN5iSL48t2IhVFnmy = jglfWFcvo1mAdH9yeROS7XKNxu
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,518)
	return
def UBVWp2SNXTbfthDj5OmQlKnyaz3F(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-INDEXES_TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	p3LfChWJd124eAYj78zw09SXonH = yzBNMPF13j.find(class_='expand').find_all('tr')
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		FLwb6XN4mjiZT2P3gRVE9vQ = D3D6TF50oUBtJlvijPMW8ys.find_all('a')
		if not FLwb6XN4mjiZT2P3gRVE9vQ: continue
		t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('data-src')
		name = FLwb6XN4mjiZT2P3gRVE9vQ[1].text
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+FLwb6XN4mjiZT2P3gRVE9vQ[1].get('href')
		qB30x862LdzsOw = D3D6TF50oUBtJlvijPMW8ys.find(class_='legend')
		if qB30x862LdzsOw: qB30x862LdzsOw = qB30x862LdzsOw.text
		if BB7oCRfQNSYj5qDhTUevV:
			name = name.encode(Im5KSGZYBpRvdMVsbuXg)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
			t4zynV13ZoPe = t4zynV13ZoPe.encode(Im5KSGZYBpRvdMVsbuXg)
		TiPIxOFX2bS5ZDG4A1KoeVUyW0dh = {}
		if qB30x862LdzsOw: TiPIxOFX2bS5ZDG4A1KoeVUyW0dh['stars'] = qB30x862LdzsOw
		if '/work/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,516,t4zynV13ZoPe,CJlTSEpZsWb0QHg5w,name,CJlTSEpZsWb0QHg5w,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
		elif '/person/' in ZgsbN5iSL48t2IhVFnmy: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+name,ZgsbN5iSL48t2IhVFnmy,513,t4zynV13ZoPe,CJlTSEpZsWb0QHg5w,name,CJlTSEpZsWb0QHg5w,TiPIxOFX2bS5ZDG4A1KoeVUyW0dh)
	aFE4IKnmld(yzBNMPF13j,518)
	return
def jkuA2oXEQ7xUGp(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-VIDEOS_LISTS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	RYHIKeQZLBpbNvmhkq2GV1C = yzBNMPF13j.find_all(class_='section-title inline')
	Rp1g7OlotseGnf0NFmKk6rLxd = yzBNMPF13j.find_all(class_='button green small right')
	items = zip(RYHIKeQZLBpbNvmhkq2GV1C,Rp1g7OlotseGnf0NFmKk6rLxd)
	for title,ZgsbN5iSL48t2IhVFnmy in items:
		title = title.text
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+ZgsbN5iSL48t2IhVFnmy.get('href')
		if BB7oCRfQNSYj5qDhTUevV:
			title = title.encode(Im5KSGZYBpRvdMVsbuXg)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
		title = title.replace(NaE5l67ROx,YvOQBzaTAscXR9ql).replace(VzZPgf1qW5L8auj2do9R4FpiXM7Ycy,YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,521)
	return
def jQ40JHnaeMPlqhwZd7mC(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-VIDEOS_TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	HFksQVaob2jUgT6mXE9 = yzBNMPF13j.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	p3LfChWJd124eAYj78zw09SXonH = HFksQVaob2jUgT6mXE9.find_all('li')
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		title = D3D6TF50oUBtJlvijPMW8ys.find(class_='title').text
		ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+D3D6TF50oUBtJlvijPMW8ys.find('a').get('href')
		t4zynV13ZoPe = D3D6TF50oUBtJlvijPMW8ys.find('img').get('data-src')
		XtbZnKed5mT2IYPy4MqvuOGURNwSc = D3D6TF50oUBtJlvijPMW8ys.find(class_='duration').text
		if BB7oCRfQNSYj5qDhTUevV:
			title = title.encode(Im5KSGZYBpRvdMVsbuXg)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
			t4zynV13ZoPe = t4zynV13ZoPe.encode(Im5KSGZYBpRvdMVsbuXg)
			XtbZnKed5mT2IYPy4MqvuOGURNwSc = XtbZnKed5mT2IYPy4MqvuOGURNwSc.encode(Im5KSGZYBpRvdMVsbuXg)
		XtbZnKed5mT2IYPy4MqvuOGURNwSc = XtbZnKed5mT2IYPy4MqvuOGURNwSc.replace(rJ9cgWz4FU,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,522,t4zynV13ZoPe,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	aFE4IKnmld(yzBNMPF13j,521)
	return
def rHwfOZb3oSgJKi(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	ZgsbN5iSL48t2IhVFnmy = yzBNMPF13j.find(class_='flex-video').find('iframe').get('src')
	if BB7oCRfQNSYj5qDhTUevV: ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.encode(Im5KSGZYBpRvdMVsbuXg)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX([ZgsbN5iSL48t2IhVFnmy],T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'%20')
	url = V4kF6EQiwo+'/search/?q='+search
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-SEARCH-1st')
	if not bqIufCQz2OWExjilm.succeeded:
		A8CdXURF1Tkrp0t6LJ = V4kF6EQiwo+'/search_entity/?q='+search+'&entity=work'
		otCOTHujWKp7Dn6dvcafPqlx = V4kF6EQiwo+'/search_entity/?q='+search+'&entity=person'
		UBanXr1KiQbhYvp0 = V4kF6EQiwo+'/search_entity/?q='+search+'&entity=video'
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن أعمال',A8CdXURF1Tkrp0t6LJ,513,CJlTSEpZsWb0QHg5w,search)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن أشخاص',otCOTHujWKp7Dn6dvcafPqlx,513,CJlTSEpZsWb0QHg5w,search)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث عن فيديوهات',UBanXr1KiQbhYvp0,513,CJlTSEpZsWb0QHg5w,search)
		return
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	yzBNMPF13j = j9Ptk2a1mz0NqS.BeautifulSoup(bGIVq1CQTjmosZg,'html.parser',multi_valued_attributes=None)
	p3LfChWJd124eAYj78zw09SXonH = yzBNMPF13j.find_all(class_='section-title left')
	for D3D6TF50oUBtJlvijPMW8ys in p3LfChWJd124eAYj78zw09SXonH:
		title = D3D6TF50oUBtJlvijPMW8ys.text
		if BB7oCRfQNSYj5qDhTUevV:
			title = title.encode(Im5KSGZYBpRvdMVsbuXg)
		title = title.split('(',1)[0].strip(YvOQBzaTAscXR9ql)
		if   'أعمال' in title: ZgsbN5iSL48t2IhVFnmy = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: ZgsbN5iSL48t2IhVFnmy = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: ZgsbN5iSL48t2IhVFnmy = url.replace('/search/','/search/video/')
		else: continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,513)
	return
def hP2v5s3xnbe6kZQJ9qaTDdY(url,text):
	global eLr1mRpNf0WX75CET62FjuIgaHq,J6JSN2vjp5knhiVoFLXUAWBqGsT
	if '/seasonals' in url:
		eLr1mRpNf0WX75CET62FjuIgaHq = ['seasonal','year','category']
		J6JSN2vjp5knhiVoFLXUAWBqGsT = ['seasonal','year','category']
	elif '/lineup' in url:
		eLr1mRpNf0WX75CET62FjuIgaHq = ['category','foreign','type']
		J6JSN2vjp5knhiVoFLXUAWBqGsT = ['category','foreign','type']
	wwkAylgOx852(url,text)
	return
def oRdVakZGH609MievEIKTyB(url):
	url = url.split('/smartemadfilter?')[0]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(ggZJf7YnlXHT3IjtMaWe6S,'GET',url,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('form action="/(.*?)</form>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = Zy2l0g8QU5vqefaTrsw.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	return bXYD7OZPULlNcp6gtSEMWiau5FAdy
def rrxJkwNntpTHQiO6yvEZFocC(D3D6TF50oUBtJlvijPMW8ys):
	items = Zy2l0g8QU5vqefaTrsw.findall('<option value="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	return items
def bMOpi5Uu0qHgotajDZ(url):
	R9RzvLZDnPb = url.split('/smartemadfilter?')[0]
	cJXaNYSwQ0BP9bUgM = fUSgd7IjGYX496Hr25uFMl(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def OLbrI5VF02Tj3sCJWHwG(YYvW68idVrJQFa,url):
	mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(YYvW68idVrJQFa,'all_filters')
	ysw7G3tqjo = url+'/smartemadfilter?'+mmMRqiu1zXvWZlK7hAgEQn
	ysw7G3tqjo = bMOpi5Uu0qHgotajDZ(ysw7G3tqjo)
	return ysw7G3tqjo
def wwkAylgOx852(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==CJlTSEpZsWb0QHg5w: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w
	else: LLnTmNF7UG4,bnCVRhKEGJ0DIYqUBsgdpm = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if eLr1mRpNf0WX75CET62FjuIgaHq[0]+'=' not in LLnTmNF7UG4: y3LbIjrZvcATpNDM = eLr1mRpNf0WX75CET62FjuIgaHq[0]
		for PMTRpXQvDIkiNszwYGnb32a in range(len(eLr1mRpNf0WX75CET62FjuIgaHq[0:-1])):
			if eLr1mRpNf0WX75CET62FjuIgaHq[PMTRpXQvDIkiNszwYGnb32a]+'=' in LLnTmNF7UG4: y3LbIjrZvcATpNDM = eLr1mRpNf0WX75CET62FjuIgaHq[PMTRpXQvDIkiNszwYGnb32a+1]
		R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+y3LbIjrZvcATpNDM+'=0'
		YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+y3LbIjrZvcATpNDM+'=0'
		PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB.strip('&')+'___'+YYvW68idVrJQFa.strip('&')
		mmMRqiu1zXvWZlK7hAgEQn = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+mmMRqiu1zXvWZlK7hAgEQn
	elif type=='ALL_ITEMS_FILTER':
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = dfWao504Fciv(LLnTmNF7UG4,'modified_values')
		zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2 = sWzgdLCjSVwaMuhFkNf1Uop(zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2)
		if bnCVRhKEGJ0DIYqUBsgdpm!=CJlTSEpZsWb0QHg5w: bnCVRhKEGJ0DIYqUBsgdpm = dfWao504Fciv(bnCVRhKEGJ0DIYqUBsgdpm,'modified_filters')
		if bnCVRhKEGJ0DIYqUBsgdpm==CJlTSEpZsWb0QHg5w: BBwfuWGxUIrdCoc4ka7 = url
		else: BBwfuWGxUIrdCoc4ka7 = url+'/smartemadfilter?'+bnCVRhKEGJ0DIYqUBsgdpm
		BBwfuWGxUIrdCoc4ka7 = bMOpi5Uu0qHgotajDZ(BBwfuWGxUIrdCoc4ka7)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'أظهار قائمة الفيديو التي تم اختيارها ',BBwfuWGxUIrdCoc4ka7,511)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+' [[   '+zFYbXkuqBJHMUl1ytAZdKLsnPOaQo2+'   ]]',BBwfuWGxUIrdCoc4ka7,511)
		khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	bXYD7OZPULlNcp6gtSEMWiau5FAdy = oRdVakZGH609MievEIKTyB(url)
	dict = {}
	for name,HLQNhXe7orPjl5Vm4,D3D6TF50oUBtJlvijPMW8ys in bXYD7OZPULlNcp6gtSEMWiau5FAdy:
		name = name.replace('--',CJlTSEpZsWb0QHg5w)
		items = rrxJkwNntpTHQiO6yvEZFocC(D3D6TF50oUBtJlvijPMW8ys)
		if '=' not in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7 = url
		if type=='SPECIFIED_FILTER':
			if HLQNhXe7orPjl5Vm4 not in eLr1mRpNf0WX75CET62FjuIgaHq: continue
			if y3LbIjrZvcATpNDM!=HLQNhXe7orPjl5Vm4: continue
			elif len(items)<2:
				if HLQNhXe7orPjl5Vm4==eLr1mRpNf0WX75CET62FjuIgaHq[-1]:
					url = bMOpi5Uu0qHgotajDZ(url)
					gc0NCfH2e7VuUjYw4OJimEQkB3Av(url)
				else: wwkAylgOx852(BBwfuWGxUIrdCoc4ka7,'SPECIFIED_FILTER___'+PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
				return
			else:
				BBwfuWGxUIrdCoc4ka7 = bMOpi5Uu0qHgotajDZ(BBwfuWGxUIrdCoc4ka7)
				if HLQNhXe7orPjl5Vm4==eLr1mRpNf0WX75CET62FjuIgaHq[-1]: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,511)
				else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع',BBwfuWGxUIrdCoc4ka7,515,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		elif type=='ALL_ITEMS_FILTER':
			if HLQNhXe7orPjl5Vm4 not in J6JSN2vjp5knhiVoFLXUAWBqGsT: continue
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'=0'
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'=0'
			PrT5vR6KdZ37HFuyxBSbEGItiLMJ = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'الجميع: '+name,BBwfuWGxUIrdCoc4ka7,514,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,PrT5vR6KdZ37HFuyxBSbEGItiLMJ)
		dict[HLQNhXe7orPjl5Vm4] = {}
		for value,ll5WFBCJKhA64tIDT8qvX in items:
			if ll5WFBCJKhA64tIDT8qvX in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			if 'مصنفات أخرى' in ll5WFBCJKhA64tIDT8qvX: continue
			if 'الكل' in ll5WFBCJKhA64tIDT8qvX: continue
			if 'اللغة' in ll5WFBCJKhA64tIDT8qvX: continue
			ll5WFBCJKhA64tIDT8qvX = ll5WFBCJKhA64tIDT8qvX.replace('قائمة ',CJlTSEpZsWb0QHg5w)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[HLQNhXe7orPjl5Vm4][value] = ll5WFBCJKhA64tIDT8qvX
			R1bsYLhg7y5GEu8pqN6JiXVI40vWFB = LLnTmNF7UG4+'&'+HLQNhXe7orPjl5Vm4+'='+ll5WFBCJKhA64tIDT8qvX
			YYvW68idVrJQFa = bnCVRhKEGJ0DIYqUBsgdpm+'&'+HLQNhXe7orPjl5Vm4+'='+value
			xBOKIM4ZCd = R1bsYLhg7y5GEu8pqN6JiXVI40vWFB+'___'+YYvW68idVrJQFa
			if name: title = ll5WFBCJKhA64tIDT8qvX+' :'+name
			else: title = ll5WFBCJKhA64tIDT8qvX
			if type=='ALL_ITEMS_FILTER': khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,514,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
			elif type=='SPECIFIED_FILTER' and eLr1mRpNf0WX75CET62FjuIgaHq[-2]+'=' in LLnTmNF7UG4:
				ysw7G3tqjo = OLbrI5VF02Tj3sCJWHwG(YYvW68idVrJQFa,url)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ysw7G3tqjo,511)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,515,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xBOKIM4ZCd)
	return
def dfWao504Fciv(YUIwPVo4qucC7935ZW,mode):
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.replace('=&','=0&')
	YUIwPVo4qucC7935ZW = YUIwPVo4qucC7935ZW.strip('&')
	Sucv4JD0rRPaBL8HFMjNt = {}
	if '=' in YUIwPVo4qucC7935ZW:
		items = YUIwPVo4qucC7935ZW.split('&')
		for jglfWFcvo1mAdH9yeROS7XKNxu in items:
			bqCtj61hiYBzsUvGA,value = jglfWFcvo1mAdH9yeROS7XKNxu.split('=')
			Sucv4JD0rRPaBL8HFMjNt[bqCtj61hiYBzsUvGA] = value
	fuTzgEqmbRX378cwQnJH9rhFCt = CJlTSEpZsWb0QHg5w
	for key in J6JSN2vjp5knhiVoFLXUAWBqGsT:
		if key in list(Sucv4JD0rRPaBL8HFMjNt.keys()): value = Sucv4JD0rRPaBL8HFMjNt[key]
		else: value = '0'
		if '%' not in value: value = O4Ak3NXpyUHvE(value)
		if mode=='modified_values' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+' + '+value
		elif mode=='modified_filters' and value!='0': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
		elif mode=='all_filters': fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt+'&'+key+'='+value
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip(' + ')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.strip('&')
	fuTzgEqmbRX378cwQnJH9rhFCt = fuTzgEqmbRX378cwQnJH9rhFCt.replace('=0','=')
	return fuTzgEqmbRX378cwQnJH9rhFCt
eLr1mRpNf0WX75CET62FjuIgaHq = []
J6JSN2vjp5knhiVoFLXUAWBqGsT = []
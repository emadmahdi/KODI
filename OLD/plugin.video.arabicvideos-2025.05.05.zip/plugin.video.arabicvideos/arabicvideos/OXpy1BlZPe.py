# -*- coding: utf-8 -*-
import sys as A8v6c2fL7egwWCF3YBqr4kXSRn
MyGHgvBTlUf3AokR6pIcmOhY7Ptx = A8v6c2fL7egwWCF3YBqr4kXSRn.version_info [0] == 2
kk9rBMUdGbPYDLXSFC21Z5Kcse = 2048
Uo1u0hIrjLnA = 7
def ESKo9M8yVf (EvdrxsR7GM):
	global DDE1eXOMBzxG3JLRUs7TbuHA
	c3c0i6WkGTOXm95I7zsEAo = ord (EvdrxsR7GM [-1])
	Rti9UXnYW0LBua = EvdrxsR7GM [:-1]
	uso2HEvIMxam = c3c0i6WkGTOXm95I7zsEAo % len (Rti9UXnYW0LBua)
	ErxajNJuA7oS48yH1VbY = Rti9UXnYW0LBua [:uso2HEvIMxam] + Rti9UXnYW0LBua [uso2HEvIMxam:]
	if MyGHgvBTlUf3AokR6pIcmOhY7Ptx:
		R05usn1EiM = unicode () .join ([unichr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	else:
		R05usn1EiM = str () .join ([chr (ord (lcjRJAvWX74xEeD5Pqbog) - kk9rBMUdGbPYDLXSFC21Z5Kcse - (iAUk9WD6QKo + c3c0i6WkGTOXm95I7zsEAo) % Uo1u0hIrjLnA) for iAUk9WD6QKo, lcjRJAvWX74xEeD5Pqbog in enumerate (ErxajNJuA7oS48yH1VbY)])
	return eval (R05usn1EiM)
TMfV6892ZoBdyxCH3tGrkwY0K,E6xdOMpqISHZCn,xWQHt65qRu1rOXon9a0fvzSyGj32D=ESKo9M8yVf,ESKo9M8yVf,ESKo9M8yVf
h6sIkJOT5PB2vCxqo4LFag70wA,JACnOz297UuDK5HpPkc1LF,VVvcQpCU3OM09n=xWQHt65qRu1rOXon9a0fvzSyGj32D,E6xdOMpqISHZCn,TMfV6892ZoBdyxCH3tGrkwY0K
HaTI5u1f3SCxmMAkw,o2FdrDBimMuOw97q6QpNW8S,otNfFapeEnO=VVvcQpCU3OM09n,JACnOz297UuDK5HpPkc1LF,h6sIkJOT5PB2vCxqo4LFag70wA
KA26GucUHOwXL,I7K1Tbk8YSXUhApzqwtLEQMV2,GISOTJh20W=otNfFapeEnO,o2FdrDBimMuOw97q6QpNW8S,HaTI5u1f3SCxmMAkw
yNC5SED4RwQmB0qrGPgVl6hzIpc3ie,cbmeD4WNZfAowxT2JdUMtV,od9imFLzxAh8ZQwbVcgjtKl4qUIa=GISOTJh20W,I7K1Tbk8YSXUhApzqwtLEQMV2,KA26GucUHOwXL
s97s2k0LJgl,rC5tnFDlQcRGA2,pz4WBwfyDdgk0m2aRr7SMv=od9imFLzxAh8ZQwbVcgjtKl4qUIa,cbmeD4WNZfAowxT2JdUMtV,yNC5SED4RwQmB0qrGPgVl6hzIpc3ie
CwhjA4tpzIRlsEDSNTfncaZirvVYKo,XB4CjMkPFzhAHiI3q,TDpFsQXHze2q30uYtGPfEIm8=pz4WBwfyDdgk0m2aRr7SMv,rC5tnFDlQcRGA2,s97s2k0LJgl
NeKZDzU6rTQ0xPiBEMFH3Cn89qf,ZP1LyUCS3pIBu,mi2ZJXCDzITuyev6gfn=TDpFsQXHze2q30uYtGPfEIm8,XB4CjMkPFzhAHiI3q,CwhjA4tpzIRlsEDSNTfncaZirvVYKo
KKF9hZLPTlWCav4bGOoygtYwx5snDQ,cjVhOCwybeRo7UWg92,yylSaxCLfkte=mi2ZJXCDzITuyev6gfn,ZP1LyUCS3pIBu,NeKZDzU6rTQ0xPiBEMFH3Cn89qf
O4F8UC5lMAS6ghETm1VoPDI,yUMRP0QKIzY9BDnsV784TZmwkf,zz679V18GdcZwvrRexA0nNptY2Tab=yylSaxCLfkte,cjVhOCwybeRo7UWg92,KKF9hZLPTlWCav4bGOoygtYwx5snDQ
zQGaM7ctZCN,EcjO3giln2kQTdBY0XLAG,Olh7n0zfV4=zz679V18GdcZwvrRexA0nNptY2Tab,yUMRP0QKIzY9BDnsV784TZmwkf,O4F8UC5lMAS6ghETm1VoPDI
from kUCfvjAP1c import *
T1QDsJlUtCGhn = yylSaxCLfkte(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ਆ")
def hH3sRBSFAr(BEUVvSQtRimC,pkNZlmhUSwtXgriJHjT59MV1QqK):
	if   BEUVvSQtRimC==yylSaxCLfkte(u"࠹࠳࠱ઔ"): SD0TxMRXiep4cjPBsnzI = HRuxApw9tdo7C1YWTNXyvZa3jnUM()
	elif BEUVvSQtRimC==yylSaxCLfkte(u"࠳࠴࠳ક"): SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(pkNZlmhUSwtXgriJHjT59MV1QqK)
	elif BEUVvSQtRimC==KA26GucUHOwXL(u"࠴࠵࠵ખ"): SD0TxMRXiep4cjPBsnzI = c3jIhs8tDi()
	elif BEUVvSQtRimC==o2FdrDBimMuOw97q6QpNW8S(u"࠵࠶࠷ગ"): SD0TxMRXiep4cjPBsnzI = BBxAd1jFilPcDn9S4()
	else: SD0TxMRXiep4cjPBsnzI = VJZIMkUN5siqB21Pf
	return SD0TxMRXiep4cjPBsnzI
def rHwfOZb3oSgJKi(pkNZlmhUSwtXgriJHjT59MV1QqK):
	ZQtv0jY9W6L8UHgpnKm(pkNZlmhUSwtXgriJHjT59MV1QqK,T1QDsJlUtCGhn,I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠬࡼࡩࡥࡧࡲࠫਇ"))
	return
def BBxAd1jFilPcDn9S4():
	LLyhViKbxMntl5JSk = JACnOz297UuDK5HpPkc1LF(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬਈ")
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yUMRP0QKIzY9BDnsV784TZmwkf(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ਉ"),LLyhViKbxMntl5JSk)
	return
def HRuxApw9tdo7C1YWTNXyvZa3jnUM():
	khqge7BVD9jPFy1S8T5Gn4QAlH(ZP1LyUCS3pIBu(u"ࠨ࡮࡬ࡲࡰ࠭ਊ"),Dj62UpP5MrbTkJqhRa+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧ਋")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,mi2ZJXCDzITuyev6gfn(u"࠶࠷࠸ઘ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(o2FdrDBimMuOw97q6QpNW8S(u"ࠪࡰ࡮ࡴ࡫ࠨ਌"),Dj62UpP5MrbTkJqhRa+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫ਍")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,JACnOz297UuDK5HpPkc1LF(u"࠷࠸࠸ઙ"))
	khqge7BVD9jPFy1S8T5Gn4QAlH(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡲࡩ࡯࡭ࠪ਎"),Dj62UpP5MrbTkJqhRa+XB4CjMkPFzhAHiI3q(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬਏ")+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠾࠿࠹࠺ચ"))
	AEqRNpjrKeY8JVoH0OkfwGUX = bgecRODnf2Luvqj()
	dPqLHy6JSrfN0lZE12n4mA = tiFgl4DMvGEAUfjIYkHbr05.stat(AEqRNpjrKeY8JVoH0OkfwGUX).st_mtime
	BUNKAJQ3WLiVXbc = []
	if A7Z6OVh20eCEUx: OacgIYXU4vBSuWMVw1ZQR7oK = tiFgl4DMvGEAUfjIYkHbr05.listdir(AEqRNpjrKeY8JVoH0OkfwGUX.encode(Im5KSGZYBpRvdMVsbuXg))
	else: OacgIYXU4vBSuWMVw1ZQR7oK = tiFgl4DMvGEAUfjIYkHbr05.listdir(AEqRNpjrKeY8JVoH0OkfwGUX.decode(Im5KSGZYBpRvdMVsbuXg))
	for WEbjm0dNDHoz in OacgIYXU4vBSuWMVw1ZQR7oK:
		if A7Z6OVh20eCEUx: WEbjm0dNDHoz = WEbjm0dNDHoz.decode(Im5KSGZYBpRvdMVsbuXg)
		if not WEbjm0dNDHoz.startswith(TDpFsQXHze2q30uYtGPfEIm8(u"ࠧࡧ࡫࡯ࡩࡤ࠭ਐ")): continue
		ZKnJkXsWTtA3 = tiFgl4DMvGEAUfjIYkHbr05.path.join(AEqRNpjrKeY8JVoH0OkfwGUX,WEbjm0dNDHoz)
		dPqLHy6JSrfN0lZE12n4mA = tiFgl4DMvGEAUfjIYkHbr05.path.getmtime(ZKnJkXsWTtA3)
		BUNKAJQ3WLiVXbc.append([WEbjm0dNDHoz,dPqLHy6JSrfN0lZE12n4mA])
	BUNKAJQ3WLiVXbc = sorted(BUNKAJQ3WLiVXbc,reverse=w2qb6lf5EM,key=lambda key: key[P2Fgh6TCOWoaHjkqBcQnvRNXe])
	for WEbjm0dNDHoz,dPqLHy6JSrfN0lZE12n4mA in BUNKAJQ3WLiVXbc:
		if BB7oCRfQNSYj5qDhTUevV:
			try: WEbjm0dNDHoz = WEbjm0dNDHoz.decode(Im5KSGZYBpRvdMVsbuXg)
			except: pass
			WEbjm0dNDHoz = WEbjm0dNDHoz.encode(Im5KSGZYBpRvdMVsbuXg)
		ZKnJkXsWTtA3 = tiFgl4DMvGEAUfjIYkHbr05.path.join(AEqRNpjrKeY8JVoH0OkfwGUX,WEbjm0dNDHoz)
		khqge7BVD9jPFy1S8T5Gn4QAlH(KA26GucUHOwXL(u"ࠨࡸ࡬ࡨࡪࡵࠧ਑"),WEbjm0dNDHoz,ZKnJkXsWTtA3,CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠹࠳࠲છ"))
	return
def bgecRODnf2Luvqj():
	AEqRNpjrKeY8JVoH0OkfwGUX = ZoM1Newq29g7aGnDmE5VSOA6itk3.getSetting(JACnOz297UuDK5HpPkc1LF(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬ਒"))
	if AEqRNpjrKeY8JVoH0OkfwGUX: return AEqRNpjrKeY8JVoH0OkfwGUX
	ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(VVvcQpCU3OM09n(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ਓ"),c2XOIv1RU6aSuAeiZ5Pgz9Gr)
	return c2XOIv1RU6aSuAeiZ5Pgz9Gr
def c3jIhs8tDi():
	AEqRNpjrKeY8JVoH0OkfwGUX = bgecRODnf2Luvqj()
	yXFGvQAdkarzCch = qjTH2m7LxzoDERekhrBMs(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫਔ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,cjVhOCwybeRo7UWg92(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩਕ"),Ym6q5M4TocDaA013RjFQ+AEqRNpjrKeY8JVoH0OkfwGUX+oOQaRxBXyJ5jVnZ+E6xdOMpqISHZCn(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧਖ"))
	if yXFGvQAdkarzCch==KA26GucUHOwXL(u"࠱જ"):
		DjBdfaxy9ZzgnAUvNs4pucRbel5 = pnbR791s62ld8e(yUMRP0QKIzY9BDnsV784TZmwkf(u"࠴ઝ"),s97s2k0LJgl(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫਗ"),E6xdOMpqISHZCn(u"ࠨ࡮ࡲࡧࡦࡲࠧਘ"),CJlTSEpZsWb0QHg5w,VJZIMkUN5siqB21Pf,w2qb6lf5EM,AEqRNpjrKeY8JVoH0OkfwGUX)
		Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(TDpFsQXHze2q30uYtGPfEIm8(u"ࠩࡦࡩࡳࡺࡥࡳࠩਙ"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧਚ"),Ym6q5M4TocDaA013RjFQ+AEqRNpjrKeY8JVoH0OkfwGUX+oOQaRxBXyJ5jVnZ+zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬਛ"))
		if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa==cjVhOCwybeRo7UWg92(u"࠳ઞ"):
			ZoM1Newq29g7aGnDmE5VSOA6itk3.setSetting(Olh7n0zfV4(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨਜ"),DjBdfaxy9ZzgnAUvNs4pucRbel5)
			PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,zQGaM7ctZCN(u"࠭สๆࠢอ฾๏๐ัࠡ็ๆห๋ࠦสฯิํ๊ࠥอไๆๆไหฯࠦวๅ็ะ้้ฯࠧਝ"))
	return
def eHZnogWEkjXcLl1dUs(pkNZlmhUSwtXgriJHjT59MV1QqK,pJkizt1GSHY62rhElDZjX=CJlTSEpZsWb0QHg5w,website=CJlTSEpZsWb0QHg5w):
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+s97s2k0LJgl(u"ࠧࠡࠢࠣࡔࡷ࡫ࡰࡢࡴ࡬ࡲ࡬ࠦࡴࡰࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧਞ")+pkNZlmhUSwtXgriJHjT59MV1QqK+GISOTJh20W(u"ࠨࠢࡠࠫਟ"))
	if not pJkizt1GSHY62rhElDZjX: pJkizt1GSHY62rhElDZjX = XETbMJIf1yetlQSinA2NW5YHvag6D(pkNZlmhUSwtXgriJHjT59MV1QqK)
	AEqRNpjrKeY8JVoH0OkfwGUX = bgecRODnf2Luvqj()
	r9u8w2A3nbVvRpc1B = c3mPLX9b6oqze0UCJEartIuds(VJZIMkUN5siqB21Pf)
	WEbjm0dNDHoz = r9u8w2A3nbVvRpc1B.replace(YvOQBzaTAscXR9ql,zQGaM7ctZCN(u"ࠩࡢࠫਠ"))
	WEbjm0dNDHoz = vvcCMPFyJDZ48oH6lTzma0xr9edOUK(WEbjm0dNDHoz)
	WEbjm0dNDHoz = KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠪࡪ࡮ࡲࡥࡠࠩਡ")+str(int(U6YgVKS9rAmwe1RTPlQnfiGs))[-NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠷ટ"):]+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"ࠫࡤ࠭ਢ")+WEbjm0dNDHoz+pJkizt1GSHY62rhElDZjX
	Uh7VZxqkotCvrAiMgSOQp = tiFgl4DMvGEAUfjIYkHbr05.path.join(AEqRNpjrKeY8JVoH0OkfwGUX,WEbjm0dNDHoz)
	G9olD6cNbsdS = {}
	G9olD6cNbsdS[HaTI5u1f3SCxmMAkw(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠧਣ")] = CJlTSEpZsWb0QHg5w
	G9olD6cNbsdS[KA26GucUHOwXL(u"࠭ࡁࡤࡥࡨࡴࡹ࠭ਤ")] = otNfFapeEnO(u"ࠧࠫ࠱࠭ࠫਥ")
	pkNZlmhUSwtXgriJHjT59MV1QqK = pkNZlmhUSwtXgriJHjT59MV1QqK.replace(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨࡸࡨࡶ࡮࡬ࡹࡱࡧࡨࡶࡂ࡬ࡡ࡭ࡵࡨࠫਦ"),CJlTSEpZsWb0QHg5w)
	if zQGaM7ctZCN(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠧਧ") in pkNZlmhUSwtXgriJHjT59MV1QqK:
		BBwfuWGxUIrdCoc4ka7,ww0cfi2ZxQvg7k3N1uLRhtFdH = pkNZlmhUSwtXgriJHjT59MV1QqK.rsplit(s97s2k0LJgl(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨਨ"),KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠵ઠ"))
		ww0cfi2ZxQvg7k3N1uLRhtFdH = ww0cfi2ZxQvg7k3N1uLRhtFdH.replace(zQGaM7ctZCN(u"ࠫࢁ࠭਩"),CJlTSEpZsWb0QHg5w).replace(yylSaxCLfkte(u"ࠬࠬࠧਪ"),CJlTSEpZsWb0QHg5w)
	else: BBwfuWGxUIrdCoc4ka7,ww0cfi2ZxQvg7k3N1uLRhtFdH = pkNZlmhUSwtXgriJHjT59MV1QqK,None
	if not ww0cfi2ZxQvg7k3N1uLRhtFdH: ww0cfi2ZxQvg7k3N1uLRhtFdH = jQW9RpucaCLHX0sSBD6lrif58e47nt()
	if ww0cfi2ZxQvg7k3N1uLRhtFdH: G9olD6cNbsdS[O4F8UC5lMAS6ghETm1VoPDI(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਫ")] = ww0cfi2ZxQvg7k3N1uLRhtFdH
	if zQGaM7ctZCN(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩਬ") in BBwfuWGxUIrdCoc4ka7: BBwfuWGxUIrdCoc4ka7,ffY51ieqb2WIwQRHExhZsAopFu = BBwfuWGxUIrdCoc4ka7.rsplit(xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿ࠪਭ"),O4F8UC5lMAS6ghETm1VoPDI(u"࠶ડ"))
	else: BBwfuWGxUIrdCoc4ka7,ffY51ieqb2WIwQRHExhZsAopFu = BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w
	BBwfuWGxUIrdCoc4ka7 = BBwfuWGxUIrdCoc4ka7.strip(KA26GucUHOwXL(u"ࠩࡿࠫਮ")).strip(od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࠪࠬਯ")).strip(JACnOz297UuDK5HpPkc1LF(u"ࠫࢁ࠭ਰ")).strip(VVvcQpCU3OM09n(u"ࠬࠬࠧ਱"))
	ffY51ieqb2WIwQRHExhZsAopFu = ffY51ieqb2WIwQRHExhZsAopFu.replace(KA26GucUHOwXL(u"࠭ࡼࠨਲ"),CJlTSEpZsWb0QHg5w).replace(VVvcQpCU3OM09n(u"ࠧࠧࠩਲ਼"),CJlTSEpZsWb0QHg5w)
	if ffY51ieqb2WIwQRHExhZsAopFu:	G9olD6cNbsdS[yylSaxCLfkte(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ਴")] = ffY51ieqb2WIwQRHExhZsAopFu
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+Olh7n0zfV4(u"ࠩࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪਵ")+BBwfuWGxUIrdCoc4ka7+yylSaxCLfkte(u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭ਸ਼")+str(G9olD6cNbsdS)+xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ਷")+Uh7VZxqkotCvrAiMgSOQp+TDpFsQXHze2q30uYtGPfEIm8(u"ࠬࠦ࡝ࠨਸ"))
	k0kxuL3BiKy2ePQfTcdM = E6xdOMpqISHZCn(u"࠷࠰࠳࠶ઢ")*E6xdOMpqISHZCn(u"࠷࠰࠳࠶ઢ")
	V4PdMsLrtHI6Ya1GBKoUE9uZFOT = BBGMAjz64tElUg()//k0kxuL3BiKy2ePQfTcdM
	if not V4PdMsLrtHI6Ya1GBKoUE9uZFOT:
		hQbEaPTN5tnZfArRuWDcY(CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"࠭ࡲࡪࡩ࡫ࡸࠬਹ"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠧๆีสัฮࠦวๅฬัึ๏์ࠠๆฮ๊์้ฯࠧ਺"),CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠨๆ็วุ็ࠠศๆหี๋อๅอࠢ฽๎ึࠦโศัิࠤศ์๋ࠠฯาำ๋ࠥโะษิࠤู๊วฮหࠣห้ะฮำ์้ࠤฬ๊แศำ฽อࠥ็๊ࠡฮ๊หื้้ࠠ฻็๎์ࠦแศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦไ็ࠢํ฽ฺ๊๊่ࠠา็ࠥหไ๊ࠢฦ๊ࠥ๐โ้็้ࠣอืๅอ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡสะ่ࠥํะ่ࠢสฺ่๊ใๅห่ࠣฬ์ࠠหฯ่๎้ࠦวๅใํำ๏๎็ศฬࠣๆิ๊ࠦิสหࠤฬ๋สๅษฤࠤัํวำๅࠣฬฬ๊ๅๅใสฮࠥ๎็ัษࠣๅ๏ํࠠฯู๋ีฮูࠦๅ๋ࠣ฽๊๊ࠠอ้สึ่ࠦศึ๊ิอࠥ฻อ๋ฯฬࠤํ๊็ัษࠣหู้ศษࠢๅห๊ࠦวๅ็หี๊าࠠๆฦๅฮฬࠦศๆ่฼ࠤฬ๊ศา่ส้ัࠦๅ็ࠢอั๊๐ไࠡษ็ๅ๏ี๊้้สฮࠬ਻"),TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸ਼ࠬ"))
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+HaTI5u1f3SCxmMAkw(u"ࠪࠤࠥࠦࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡧࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥࡺࡨࡦࠢࡧ࡭ࡸࡱࠠࡧࡴࡨࡩࠥࡹࡰࡢࡥࡨࠫ਽"))
		return VJZIMkUN5siqB21Pf
	if pJkizt1GSHY62rhElDZjX==otNfFapeEnO(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪਾ"):
		Uz8mMbZifCyvkLnct,MNXzjK3vV7D = bUD0vMHIQhKW(T1QDsJlUtCGhn,BBwfuWGxUIrdCoc4ka7,G9olD6cNbsdS)
		if len(Uz8mMbZifCyvkLnct)==h6sIkJOT5PB2vCxqo4LFag70wA(u"࠰ણ"):
			KhwN2zcb7iMkjS5E4WURxByPGon(cbmeD4WNZfAowxT2JdUMtV(u"ࠬ็ิๅࠢไ๎ࠥห๊อษาࠤ๊๊แࠡษ็ฮา๋๊ๅࠩਿ"),CJlTSEpZsWb0QHg5w)
			return VJZIMkUN5siqB21Pf
		elif len(Uz8mMbZifCyvkLnct)==Olh7n0zfV4(u"࠲ત"): CrqTamtPFuU = EcjO3giln2kQTdBY0XLAG(u"࠲થ")
		elif len(Uz8mMbZifCyvkLnct)>o2FdrDBimMuOw97q6QpNW8S(u"࠴દ"):
			CrqTamtPFuU = T4TK17YsEfZJ(s97s2k0LJgl(u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫੀ"), Uz8mMbZifCyvkLnct)
			if CrqTamtPFuU == -XB4CjMkPFzhAHiI3q(u"࠵ધ") :
				KhwN2zcb7iMkjS5E4WURxByPGon(s97s2k0LJgl(u"ࠧห็ࠣษ้เวยࠢส่ฯำๅ๋ๆࠪੁ"),CJlTSEpZsWb0QHg5w)
				return VJZIMkUN5siqB21Pf
		BBwfuWGxUIrdCoc4ka7 = MNXzjK3vV7D[CrqTamtPFuU]
	Jqn93zLatWr6sobuB8meH5gTZV0Ac = zz679V18GdcZwvrRexA0nNptY2Tab(u"࠵ન")
	import requests as WjPGK7puI3D2m0qXcHYEVUovrL1xkJ
	if pJkizt1GSHY62rhElDZjX==TDpFsQXHze2q30uYtGPfEIm8(u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧੂ"):
		Uh7VZxqkotCvrAiMgSOQp = Uh7VZxqkotCvrAiMgSOQp.rsplit(E6xdOMpqISHZCn(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨ੃"))[ZVNvqy4iF1a9X]+cbmeD4WNZfAowxT2JdUMtV(u"ࠪ࠲ࡲࡶ࠴ࠨ੄")
		C0q5dOLGD8 = DNq5CJHPR3G7uX8pbngwF9T(o1oDTrOyPliAC6QBcKXRathZGu9g4Y,mi2ZJXCDzITuyev6gfn(u"ࠫࡌࡋࡔࠨ੅"),BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,G9olD6cNbsdS,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊ࠭ࡅࡑ࡚ࡒࡑࡕࡁࡅࡡ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬ੆"))
		bkAc7RmjDwnZJ = C0q5dOLGD8.content
		Rp1g7OlotseGnf0NFmKk6rLxd = Zy2l0g8QU5vqefaTrsw.findall(o2FdrDBimMuOw97q6QpNW8S(u"࠭ࠣࡆ࡚ࡗࡍࡓࡌ࠺࠯ࠬࡂ࡟ࡡࡴ࡜ࡳ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧੇ"),bkAc7RmjDwnZJ+pz4WBwfyDdgk0m2aRr7SMv(u"ࠧ࡝ࡰ࡟ࡶࠬੈ"),Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not Rp1g7OlotseGnf0NFmKk6rLxd:
			JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+otNfFapeEnO(u"ࠨࠢࠣࠤ࡙࡮ࡥࠡ࡯࠶ࡹ࠽ࠦࡦࡪ࡮ࡨࠤࡩ࡯ࡤࠡࡰࡲࡸࠥ࡮ࡡࡷࡧࠣࡸ࡭࡫ࠠࡳࡧࡴࡹ࡮ࡸࡥࡥࠢ࡯࡭ࡳࡱࡳ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ੉")+BBwfuWGxUIrdCoc4ka7+cbmeD4WNZfAowxT2JdUMtV(u"ࠩࠣࡡࠬ੊"))
			return VJZIMkUN5siqB21Pf
		ZgsbN5iSL48t2IhVFnmy = Rp1g7OlotseGnf0NFmKk6rLxd[ZVNvqy4iF1a9X]
		if not ZgsbN5iSL48t2IhVFnmy.startswith(I7K1Tbk8YSXUhApzqwtLEQMV2(u"ࠪ࡬ࡹࡺࡰࠨੋ")):
			if ZgsbN5iSL48t2IhVFnmy.startswith(h6sIkJOT5PB2vCxqo4LFag70wA(u"ࠫ࠴࠵ࠧੌ")): ZgsbN5iSL48t2IhVFnmy = BBwfuWGxUIrdCoc4ka7.split(rC5tnFDlQcRGA2(u"ࠬࡀ੍ࠧ"),mi2ZJXCDzITuyev6gfn(u"࠷઩"))[ZVNvqy4iF1a9X]+TDpFsQXHze2q30uYtGPfEIm8(u"࠭࠺ࠨ੎")+ZgsbN5iSL48t2IhVFnmy
			elif ZgsbN5iSL48t2IhVFnmy.startswith(otNfFapeEnO(u"ࠧ࠰ࠩ੏")): ZgsbN5iSL48t2IhVFnmy = fUSgd7IjGYX496Hr25uFMl(BBwfuWGxUIrdCoc4ka7,zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠨࡷࡵࡰࠬ੐"))+ZgsbN5iSL48t2IhVFnmy
			else: ZgsbN5iSL48t2IhVFnmy = BBwfuWGxUIrdCoc4ka7.rsplit(O4F8UC5lMAS6ghETm1VoPDI(u"ࠩ࠲ࠫੑ"),EcjO3giln2kQTdBY0XLAG(u"࠱પ"))[ZVNvqy4iF1a9X]+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪ࠳ࠬ੒")+ZgsbN5iSL48t2IhVFnmy
		C0q5dOLGD8 = WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.request(zQGaM7ctZCN(u"ࠫࡌࡋࡔࠨ੓"),ZgsbN5iSL48t2IhVFnmy,headers=G9olD6cNbsdS,verify=VJZIMkUN5siqB21Pf)
		QQaHXlZP5u = C0q5dOLGD8.content
		rmuy109FwWhBjetfZopGQlU7 = len(QQaHXlZP5u)
		GcMwHQb6gBD9lKykj = len(Rp1g7OlotseGnf0NFmKk6rLxd)
		Jqn93zLatWr6sobuB8meH5gTZV0Ac = rmuy109FwWhBjetfZopGQlU7*GcMwHQb6gBD9lKykj
	else:
		rmuy109FwWhBjetfZopGQlU7 = VVvcQpCU3OM09n(u"࠲ફ")*k0kxuL3BiKy2ePQfTcdM
		C0q5dOLGD8 = WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.request(zz679V18GdcZwvrRexA0nNptY2Tab(u"ࠬࡍࡅࡕࠩ੔"),BBwfuWGxUIrdCoc4ka7,headers=G9olD6cNbsdS,verify=VJZIMkUN5siqB21Pf,stream=w2qb6lf5EM)
		if EcjO3giln2kQTdBY0XLAG(u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡍࡧࡱ࡫ࡹ࡮ࠧ੕") in C0q5dOLGD8.headers: Jqn93zLatWr6sobuB8meH5gTZV0Ac = int(C0q5dOLGD8.headers[XB4CjMkPFzhAHiI3q(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨ੖")])
		GcMwHQb6gBD9lKykj = int(Jqn93zLatWr6sobuB8meH5gTZV0Ac//rmuy109FwWhBjetfZopGQlU7)
	ToYuiyRQ9tmZI0gzU3Cv7saP = int(Jqn93zLatWr6sobuB8meH5gTZV0Ac//k0kxuL3BiKy2ePQfTcdM)+yUMRP0QKIzY9BDnsV784TZmwkf(u"࠳બ")
	if Jqn93zLatWr6sobuB8meH5gTZV0Ac<E6xdOMpqISHZCn(u"࠵࠵࠵࠶࠰ભ"):
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+GISOTJh20W(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡ࡫ࡶࠤࡹࡵ࡯ࠡࡵࡰࡥࡱࡲࠠࡰࡴࠣ࡭ࡹࠦࡩࡴࠢࡰ࠷ࡺ࠾ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ੗")+BBwfuWGxUIrdCoc4ka7+E6xdOMpqISHZCn(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭੘")+str(ToYuiyRQ9tmZI0gzU3Cv7saP)+mi2ZJXCDzITuyev6gfn(u"ࠪࠤࡒࡈࠠ࡞ࠢࠣࠤࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩਖ਼")+str(V4PdMsLrtHI6Ya1GBKoUE9uZFOT)+ZP1LyUCS3pIBu(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧਗ਼")+Uh7VZxqkotCvrAiMgSOQp+pz4WBwfyDdgk0m2aRr7SMv(u"ࠬࠦ࡝ࠨਜ਼"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,s97s2k0LJgl(u"࠭แีๆࠣๅ๏ࠦๅฺำไอࠥำฬๆ่่ࠢๆࠦวๅใํำ๏๎ࠠฤ๊ࠣห้๋ไโุࠢ฾๏ืࠠอัสࠤํ๊็ัษ่ࠣฬ๊ࠦๆๅ้ࠤ้๊ศา่ส้ัࠦสฮ็ํ่ࠥํะศࠢส่๊๊แࠨੜ"))
		return VJZIMkUN5siqB21Pf
	XyUiScOx1AjCrK8hItHaz = O4F8UC5lMAS6ghETm1VoPDI(u"࠸࠵࠶મ")
	wv1yXDA5CqgxhoJ62eV7Qiar89 = V4PdMsLrtHI6Ya1GBKoUE9uZFOT-ToYuiyRQ9tmZI0gzU3Cv7saP
	if wv1yXDA5CqgxhoJ62eV7Qiar89<XyUiScOx1AjCrK8hItHaz:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(owpdSWeCOTgNF6vQPyGEarZ,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+cjVhOCwybeRo7UWg92(u"ࠧࠡࠢࠣࡒࡴࡺࠠࡦࡰࡲࡹ࡬࡮ࠠࡥ࡫ࡶ࡯ࠥࡹࡰࡢࡥࡨࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡷ࡬ࡪࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭੝")+BBwfuWGxUIrdCoc4ka7+VVvcQpCU3OM09n(u"ࠨࠢࡠࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬਫ਼")+str(ToYuiyRQ9tmZI0gzU3Cv7saP)+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠩࠣࡑࡇࠦ࡝ࠡࠢࠣࡅࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨ੟")+str(V4PdMsLrtHI6Ya1GBKoUE9uZFOT)+XB4CjMkPFzhAHiI3q(u"ࠪࠤࡒࡈࠠ࠮ࠢࠪ੠")+str(XyUiScOx1AjCrK8hItHaz)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧ੡")+Uh7VZxqkotCvrAiMgSOQp+TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠬࠦ࡝ࠨ੢"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"࠭ไศࠢํ์ัีࠠๆีสัฮࠦใศใํอ๊ࠥไหฯ่๎้࠭੣"),GISOTJh20W(u"ࠧศๆ่่ๆࠦวๅ็ฺ่ํฮࠠหฯ่๎้ํࠠฮฮ่๋ࠥ࠭੤")+str(ToYuiyRQ9tmZI0gzU3Cv7saP)+otNfFapeEnO(u"ࠨ่ࠢ๎฿อศศ์อࠤํา็ศิๆࠤๆ๐็ࠡ็ึหาฯࠠโษิ฾ฮࠦࠧ੥")+str(V4PdMsLrtHI6Ya1GBKoUE9uZFOT)+cbmeD4WNZfAowxT2JdUMtV(u"้ࠩࠣ๏เวษษํฮࠥ๎ไๅ็ะหๆ฾ษࠡ฻็ํࠥ฿ๅๅࠢฯ๋ฬุใࠡสา์๋ࠦๅีษๆ่ࠥ๐ฬษࠢศฬ็อมࠡࠩ੦")+str(XyUiScOx1AjCrK8hItHaz)+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠪࠤ๊๐ฺศสส๎ฯࠦแศำ฽อࠥีวว็สࠤํํะศ่ࠢ฽๋อ็ࠡล้ࠤัํวำๅ่ࠣฬࠦส้ฮาࠤๆ๐็ࠡ็ึหาฯࠠไษไ๎ฮࠦไหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠤฬ๊ๅุๆ๋ฬࠬ੧"))
		return VJZIMkUN5siqB21Pf
	Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa = qjTH2m7LxzoDERekhrBMs(O4F8UC5lMAS6ghETm1VoPDI(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ੨"),CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,yylSaxCLfkte(u"ࠬํไࠡฬิ๎ิࠦสฮ็ํ่ࠥอไๆๆไࠤฤ࠭੩"),E6xdOMpqISHZCn(u"࠭วๅ็็ๅࠥอไๆู็์อࠦออ็๊ࠤฯ่ั๋สสࠤࠬ੪")+str(ToYuiyRQ9tmZI0gzU3Cv7saP)+Olh7n0zfV4(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣ์ัํวำๅࠣๅ๏ํࠠๆีสัฮࠦแศำ฽อࠥะโา์หหࠥ࠭੫")+str(V4PdMsLrtHI6Ya1GBKoUE9uZFOT)+rC5tnFDlQcRGA2(u"ࠨ่ࠢ๎฿อศศ์อࠤํํะศࠢส่๊๊แࠡไาࠤ๏ำสศฮࠣฬ฾฼ࠠศๆ๋ๆฯࠦไๅฬะ้๏๊ࠠๆ่ࠣห้หๆหำ้ฮࠥหไ๊ࠢฯ๋ฬุใࠡ࠰๋้ࠣࠦว็ฬ้ࠣฯษใะ๋ࠢฮึ๐ฯࠡษ็หุะๅาษิࠤอะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠢยࠫ੬"))
	if Cbr8x7J6ezSoZA0PRDIlif5wpdsKEa!=EcjO3giln2kQTdBY0XLAG(u"࠶ય"):
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,xWQHt65qRu1rOXon9a0fvzSyGj32D(u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧ੭"))
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+cjVhOCwybeRo7UWg92(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡴࡩࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡵࡦࠡࡶ࡫ࡩࠥࡼࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ੮")+BBwfuWGxUIrdCoc4ka7+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫ੯")+Uh7VZxqkotCvrAiMgSOQp+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࠦ࡝ࠨੰ"))
		return VJZIMkUN5siqB21Pf
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+Olh7n0zfV4(u"࠭ࠠࠡࠢࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡸࡺࡡࡳࡶࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠫੱ"))
	OejfAMyHhNxYbXoRq6CuS3tlgz = lkPKsYmp4UjR()
	OejfAMyHhNxYbXoRq6CuS3tlgz.create(Uh7VZxqkotCvrAiMgSOQp,TMfV6892ZoBdyxCH3tGrkwY0K(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨੲ"))
	Lz9tmBbO5uaInCZspSycjoDWYT = w2qb6lf5EM
	kc4BtgWCFLJ5yGRVZzuX1eni20 = L8Wkv5KCSoq.time()
	if not Ew2zQ8u7Ss.wsrSnHQfOWm8:
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠨสึฬอูࠦะ็ࠣห้ะศา฻ࠣฮ๊ࠦลๅ฼สลࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩੳ"))
		return VJZIMkUN5siqB21Pf
	if A7Z6OVh20eCEUx: Xu6y4AblWUxH8SoQVp0wPzvNdKL = open(Uh7VZxqkotCvrAiMgSOQp,ZP1LyUCS3pIBu(u"ࠩࡺࡦࠬੴ"))
	else: Xu6y4AblWUxH8SoQVp0wPzvNdKL = open(Uh7VZxqkotCvrAiMgSOQp.decode(Im5KSGZYBpRvdMVsbuXg),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠪࡻࡧ࠭ੵ"))
	if pJkizt1GSHY62rhElDZjX==XB4CjMkPFzhAHiI3q(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ੶"):
		for LxNV5lenkhW6zoBJDMA7ZuqSg in range(KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷ર"),GcMwHQb6gBD9lKykj+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"࠷ર")):
			ZgsbN5iSL48t2IhVFnmy = Rp1g7OlotseGnf0NFmKk6rLxd[LxNV5lenkhW6zoBJDMA7ZuqSg-h6sIkJOT5PB2vCxqo4LFag70wA(u"࠱઱")]
			if not ZgsbN5iSL48t2IhVFnmy.startswith(JACnOz297UuDK5HpPkc1LF(u"ࠬ࡮ࡴࡵࡲࠪ੷")):
				if ZgsbN5iSL48t2IhVFnmy.startswith(pz4WBwfyDdgk0m2aRr7SMv(u"࠭࠯࠰ࠩ੸")): ZgsbN5iSL48t2IhVFnmy = BBwfuWGxUIrdCoc4ka7.split(otNfFapeEnO(u"ࠧ࠻ࠩ੹"),o2FdrDBimMuOw97q6QpNW8S(u"࠲લ"))[ZVNvqy4iF1a9X]+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠨ࠼ࠪ੺")+ZgsbN5iSL48t2IhVFnmy
				elif ZgsbN5iSL48t2IhVFnmy.startswith(otNfFapeEnO(u"ࠩ࠲ࠫ੻")): ZgsbN5iSL48t2IhVFnmy = fUSgd7IjGYX496Hr25uFMl(BBwfuWGxUIrdCoc4ka7,mi2ZJXCDzITuyev6gfn(u"ࠪࡹࡷࡲࠧ੼"))+ZgsbN5iSL48t2IhVFnmy
				else: ZgsbN5iSL48t2IhVFnmy = BBwfuWGxUIrdCoc4ka7.rsplit(s97s2k0LJgl(u"ࠫ࠴࠭੽"),ZP1LyUCS3pIBu(u"࠳ળ"))[ZVNvqy4iF1a9X]+yUMRP0QKIzY9BDnsV784TZmwkf(u"ࠬ࠵ࠧ੾")+ZgsbN5iSL48t2IhVFnmy
			C0q5dOLGD8 = WjPGK7puI3D2m0qXcHYEVUovrL1xkJ.request(s97s2k0LJgl(u"࠭ࡇࡆࡖࠪ੿"),ZgsbN5iSL48t2IhVFnmy,headers=G9olD6cNbsdS,verify=VJZIMkUN5siqB21Pf)
			QQaHXlZP5u = C0q5dOLGD8.content
			C0q5dOLGD8.close()
			Xu6y4AblWUxH8SoQVp0wPzvNdKL.write(QQaHXlZP5u)
			oOEkV5DSq29xLN = L8Wkv5KCSoq.time()
			ii4G17pew5ZzLEnfraO = oOEkV5DSq29xLN-kc4BtgWCFLJ5yGRVZzuX1eni20
			ee98Tcw0YmGJC7qoZ6znr2BFKAhyd = ii4G17pew5ZzLEnfraO//LxNV5lenkhW6zoBJDMA7ZuqSg
			EuSMhfkR0IxOm = ee98Tcw0YmGJC7qoZ6znr2BFKAhyd*(GcMwHQb6gBD9lKykj+h6sIkJOT5PB2vCxqo4LFag70wA(u"࠴઴"))
			MrOP1CDtKR3Qv = EuSMhfkR0IxOm-ii4G17pew5ZzLEnfraO
			KK4WuMYyThQ8l0SID2JrfGsb6UNx(OejfAMyHhNxYbXoRq6CuS3tlgz,int(I7K1Tbk8YSXUhApzqwtLEQMV2(u"࠶࠶࠰શ")*LxNV5lenkhW6zoBJDMA7ZuqSg//(GcMwHQb6gBD9lKykj+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠵વ"))),Olh7n0zfV4(u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨ઀"),cbmeD4WNZfAowxT2JdUMtV(u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨઁ"),str(LxNV5lenkhW6zoBJDMA7ZuqSg*rmuy109FwWhBjetfZopGQlU7//k0kxuL3BiKy2ePQfTcdM)+yylSaxCLfkte(u"ࠩ࠲ࠫં")+str(ToYuiyRQ9tmZI0gzU3Cv7saP)+cbmeD4WNZfAowxT2JdUMtV(u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨઃ")+L8Wkv5KCSoq.strftime(HaTI5u1f3SCxmMAkw(u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ઄"),L8Wkv5KCSoq.gmtime(MrOP1CDtKR3Qv))+mi2ZJXCDzITuyev6gfn(u"ࠬࠦเࠨઅ"))
			if OejfAMyHhNxYbXoRq6CuS3tlgz.iscanceled():
				Lz9tmBbO5uaInCZspSycjoDWYT = VJZIMkUN5siqB21Pf
				break
	else:
		LxNV5lenkhW6zoBJDMA7ZuqSg = VVvcQpCU3OM09n(u"࠶ષ")
		for QQaHXlZP5u in C0q5dOLGD8.iter_content(chunk_size=rmuy109FwWhBjetfZopGQlU7):
			Xu6y4AblWUxH8SoQVp0wPzvNdKL.write(QQaHXlZP5u)
			LxNV5lenkhW6zoBJDMA7ZuqSg = LxNV5lenkhW6zoBJDMA7ZuqSg+otNfFapeEnO(u"࠱સ")
			oOEkV5DSq29xLN = L8Wkv5KCSoq.time()
			ii4G17pew5ZzLEnfraO = oOEkV5DSq29xLN-kc4BtgWCFLJ5yGRVZzuX1eni20
			ee98Tcw0YmGJC7qoZ6znr2BFKAhyd = ii4G17pew5ZzLEnfraO/LxNV5lenkhW6zoBJDMA7ZuqSg
			EuSMhfkR0IxOm = ee98Tcw0YmGJC7qoZ6znr2BFKAhyd*(GcMwHQb6gBD9lKykj+cjVhOCwybeRo7UWg92(u"࠲હ"))
			MrOP1CDtKR3Qv = EuSMhfkR0IxOm-ii4G17pew5ZzLEnfraO
			KK4WuMYyThQ8l0SID2JrfGsb6UNx(OejfAMyHhNxYbXoRq6CuS3tlgz,int(HaTI5u1f3SCxmMAkw(u"࠴࠴࠵઻")*LxNV5lenkhW6zoBJDMA7ZuqSg/(GcMwHQb6gBD9lKykj+GISOTJh20W(u"࠳઺"))),od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧઆ"),GISOTJh20W(u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧઇ"),str(LxNV5lenkhW6zoBJDMA7ZuqSg*rmuy109FwWhBjetfZopGQlU7//k0kxuL3BiKy2ePQfTcdM)+NeKZDzU6rTQ0xPiBEMFH3Cn89qf(u"ࠨ࠱ࠪઈ")+str(ToYuiyRQ9tmZI0gzU3Cv7saP)+rC5tnFDlQcRGA2(u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧઉ")+L8Wkv5KCSoq.strftime(HaTI5u1f3SCxmMAkw(u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧઊ"),L8Wkv5KCSoq.gmtime(MrOP1CDtKR3Qv))+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࠥๆࠧઋ"))
			if OejfAMyHhNxYbXoRq6CuS3tlgz.iscanceled():
				Lz9tmBbO5uaInCZspSycjoDWYT = VJZIMkUN5siqB21Pf
				break
		C0q5dOLGD8.close()
	Xu6y4AblWUxH8SoQVp0wPzvNdKL.close()
	OejfAMyHhNxYbXoRq6CuS3tlgz.close()
	if not Lz9tmBbO5uaInCZspSycjoDWYT:
		JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+CwhjA4tpzIRlsEDSNTfncaZirvVYKo(u"ࠬࠦࠠࠡࡗࡶࡩࡷࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠰࡫ࡱࡸࡪࡸࡲࡶࡲࡷࡩࡩࠦࡴࡩࡧࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡶࡲࡰࡥࡨࡷࡸࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩઌ")+BBwfuWGxUIrdCoc4ka7+yNC5SED4RwQmB0qrGPgVl6hzIpc3ie(u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡬ࡦ࠼ࠣ࡟ࠥ࠭ઍ")+Uh7VZxqkotCvrAiMgSOQp+od9imFLzxAh8ZQwbVcgjtKl4qUIa(u"ࠧࠡ࡟ࠪ઎"))
		PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,o2FdrDBimMuOw97q6QpNW8S(u"ࠨสะือࠦืๅสๆࠤฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩએ"))
		return w2qb6lf5EM
	JwKDl495gRWA8jfsEbLhHQPnceFOqz(PiDqTEkycIt9BYLs7uMnv5f,u5ufzT4NjHKSr(T1QDsJlUtCGhn)+o2FdrDBimMuOw97q6QpNW8S(u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤ࡫࡯࡬ࡦࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࡯ࡽࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨઐ")+BBwfuWGxUIrdCoc4ka7+yylSaxCLfkte(u"ࠪࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪઑ")+Uh7VZxqkotCvrAiMgSOQp+KKF9hZLPTlWCav4bGOoygtYwx5snDQ(u"ࠫࠥࡣࠧ઒"))
	PIUzVg8uwmHlMKO5Lk6oxAZ(CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,TAExSfcoNi4eORZ8HPB,TDpFsQXHze2q30uYtGPfEIm8(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะࠫઓ"))
	return w2qb6lf5EM
# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'CIMALIGHT'
kL0nT7NpZdKVD3jM2OHB = '_CML_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['قنوات فضائية']
def hH3sRBSFAr(mode,url,text):
	if   mode==470: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==471: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==472: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==473: SD0TxMRXiep4cjPBsnzI = eB3ZX7kK5CTiIOoz(url,text)
	elif mode==474: SD0TxMRXiep4cjPBsnzI = jSpWoLZQRIsrw7MnH5KEbu(url)
	elif mode==479: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,479,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"content"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?</i>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		title = title.replace(gCc52XVMGfAnOe,CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('cat=online-movies1','cat=online-movies')
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,474)
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('/category.php">(.*?)"navslide-divider"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall("'dropdown-menu'(.*?)</ul>",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,474)
	return
def jSpWoLZQRIsrw7MnH5KEbu(url):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	if 'topvideos.php' in url: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"caret"(.*?)id="pm-grid"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	else: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"caret"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if 'topvideos.php' in ZgsbN5iSL48t2IhVFnmy:
				if 'topvideos.php?c=english-movies' in ZgsbN5iSL48t2IhVFnmy: continue
				if 'topvideos.php?c=online-movies1' in ZgsbN5iSL48t2IhVFnmy: continue
				if 'topvideos.php?c=misc' in ZgsbN5iSL48t2IhVFnmy: continue
				if 'topvideos.php?c=tv-channel' in ZgsbN5iSL48t2IhVFnmy: continue
				if 'منذ البداية' in title and 'do=rating' not in ZgsbN5iSL48t2IhVFnmy: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,471)
	else: nvHUf8mW6E4GSw5VFRXN(url)
	return
def nvHUf8mW6E4GSw5VFRXN(url,RjVAI6uzxFofm7qv=CJlTSEpZsWb0QHg5w):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	items = []
	if RjVAI6uzxFofm7qv=='featured_movies':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"container-fluid"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		Rp1g7OlotseGnf0NFmKk6rLxd,RYHIKeQZLBpbNvmhkq2GV1C,Oj0IGE6BMR3lfp12PH8aStoUCyV9gQ = zip(*items)
		items = zip(Oj0IGE6BMR3lfp12PH8aStoUCyV9gQ,Rp1g7OlotseGnf0NFmKk6rLxd,RYHIKeQZLBpbNvmhkq2GV1C)
	elif RjVAI6uzxFofm7qv=='featured_series':
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('المسلسلات المميزة(.*?)<style>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		Rp1g7OlotseGnf0NFmKk6rLxd,RYHIKeQZLBpbNvmhkq2GV1C,Oj0IGE6BMR3lfp12PH8aStoUCyV9gQ = zip(*items)
		items = zip(Oj0IGE6BMR3lfp12PH8aStoUCyV9gQ,Rp1g7OlotseGnf0NFmKk6rLxd,RYHIKeQZLBpbNvmhkq2GV1C)
	else:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('(data-echo=".*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"BlocksList"(.*?)"titleSectionCon"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="pm-grid"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('id="pm-related"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('pm-ul-browse-videos(.*?)clearfix',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if not s67485upzYNMS3PqDelkrdfo: return
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
	if not items: items = Zy2l0g8QU5vqefaTrsw.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if not items: items = Zy2l0g8QU5vqefaTrsw.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
	wDkMP6jlz7XeN5Sp = []
	En3VMwRsiIxPlShtqTdmLpoQ = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for hzGKUP1XjAoeT79MJcDF,ZgsbN5iSL48t2IhVFnmy,title in items:
		ZgsbN5iSL48t2IhVFnmy = sWzgdLCjSVwaMuhFkNf1Uop(ZgsbN5iSL48t2IhVFnmy).strip('/')
		title = title.replace('ماي سيما',CJlTSEpZsWb0QHg5w).replace('مشاهدة',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql).replace(gCc52XVMGfAnOe,YvOQBzaTAscXR9ql)
		if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
		if 'http' not in hzGKUP1XjAoeT79MJcDF: hzGKUP1XjAoeT79MJcDF = dmiXC1cB7MZlb+'/'+hzGKUP1XjAoeT79MJcDF.strip('/')
		ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة) \d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if any(value in title for value in En3VMwRsiIxPlShtqTdmLpoQ):
			title = '_MOD_'+title
			khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,472,hzGKUP1XjAoeT79MJcDF)
		elif ABK45TEMpciLnmIlYOafQJZ8t and 'حلقة' in title:
			title = '_MOD_'+ABK45TEMpciLnmIlYOafQJZ8t[0][0]
			if title not in wDkMP6jlz7XeN5Sp:
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,473,hzGKUP1XjAoeT79MJcDF)
				wDkMP6jlz7XeN5Sp.append(title)
		elif '/movseries/' in ZgsbN5iSL48t2IhVFnmy:
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,471,hzGKUP1XjAoeT79MJcDF)
		else: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,473,hzGKUP1XjAoeT79MJcDF)
	if RjVAI6uzxFofm7qv not in ['featured_movies','featured_series']:
		s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"pagination(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if s67485upzYNMS3PqDelkrdfo:
			D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if ZgsbN5iSL48t2IhVFnmy=='#': continue
				ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				title = wAmsc95ya0LHz(title)
				khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,471)
		FlN4Pz89LTmtVxD = Zy2l0g8QU5vqefaTrsw.findall('showmore" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if FlN4Pz89LTmtVxD:
			ZgsbN5iSL48t2IhVFnmy = FlN4Pz89LTmtVxD[0]
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مشاهدة المزيد',ZgsbN5iSL48t2IhVFnmy,471)
	return
def eB3ZX7kK5CTiIOoz(url,FfC8TlgIzVh5aDePHELA3rwSo4uNRM):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-EPISODES-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"SeasonsBox"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	items = []
	if hh2VPjs7dkR581KzENYigmpZxLyb and not FfC8TlgIzVh5aDePHELA3rwSo4uNRM:
		hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('"series-header".*?src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0] if hzGKUP1XjAoeT79MJcDF else CJlTSEpZsWb0QHg5w
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if len(items)==1: FfC8TlgIzVh5aDePHELA3rwSo4uNRM = items[0][0]
		elif len(items)>1:
			for FfC8TlgIzVh5aDePHELA3rwSo4uNRM,title in items: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,473,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,FfC8TlgIzVh5aDePHELA3rwSo4uNRM)
	KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('id="'+FfC8TlgIzVh5aDePHELA3rwSo4uNRM+'"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if KXu2RYg3Bc and len(items)<2:
		hzGKUP1XjAoeT79MJcDF = Zy2l0g8QU5vqefaTrsw.findall('"series-header".*?src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF[0] if hzGKUP1XjAoeT79MJcDF else CJlTSEpZsWb0QHg5w
		D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if items:
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				title = title.replace('ماي سيما',CJlTSEpZsWb0QHg5w).replace('مسلسل',CJlTSEpZsWb0QHg5w).strip(YvOQBzaTAscXR9ql)
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,472,hzGKUP1XjAoeT79MJcDF)
		else:
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title,hzGKUP1XjAoeT79MJcDF in items:
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('/')
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,472,hzGKUP1XjAoeT79MJcDF)
	if 'id="pm-related"' in bGIVq1CQTjmosZg:
		if items: khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
		khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'مواضيع ذات صلة',url,471)
	return
def rHwfOZb3oSgJKi(url):
	MNXzjK3vV7D = []
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('<div itemprop="description">(.*?)href=',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		aIW8LXhxq2Gkdv9YQCPHrwORFZJE = Zy2l0g8QU5vqefaTrsw.findall('<p>(.*?)</p>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if aIW8LXhxq2Gkdv9YQCPHrwORFZJE and GGfoAPFD7ygWpKnu6eVHxNmMc920Qt(T1QDsJlUtCGhn,url,aIW8LXhxq2Gkdv9YQCPHrwORFZJE,True): return
	BBwfuWGxUIrdCoc4ka7 = url.replace('/watch.php','/play.php')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-PLAY-2nd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	dcei7QhWIFMZUan5 = []
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"embedURL" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		if ZgsbN5iSL48t2IhVFnmy and ZgsbN5iSL48t2IhVFnmy not in dcei7QhWIFMZUan5:
			dcei7QhWIFMZUan5.append(ZgsbN5iSL48t2IhVFnmy)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named=__embed'
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	items = Zy2l0g8QU5vqefaTrsw.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	for ZgsbN5iSL48t2IhVFnmy,title in items:
		if ZgsbN5iSL48t2IhVFnmy not in dcei7QhWIFMZUan5:
			dcei7QhWIFMZUan5.append(ZgsbN5iSL48t2IhVFnmy)
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__watch'
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
			MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	BBwfuWGxUIrdCoc4ka7 = url.replace('/watch.php','/downloads.php')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'CIMALIGHT-PLAY-3rd')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"downloadlist"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<strong>(.*?)</strong>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if ZgsbN5iSL48t2IhVFnmy not in dcei7QhWIFMZUan5:
				dcei7QhWIFMZUan5.append(ZgsbN5iSL48t2IhVFnmy)
				ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+title+'__download'
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = 'http:'+ZgsbN5iSL48t2IhVFnmy
				MNXzjK3vV7D.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(MNXzjK3vV7D,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(V4kF6EQiwo,'url')
	url = FFtJQalhPz+'/search.php?keywords='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
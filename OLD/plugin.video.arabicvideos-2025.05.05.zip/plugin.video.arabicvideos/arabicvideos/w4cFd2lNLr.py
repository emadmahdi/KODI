# -*- coding: utf-8 -*-
from kUCfvjAP1c import *
T1QDsJlUtCGhn = 'ALMSTBA'
kL0nT7NpZdKVD3jM2OHB = '_MST_'
V4kF6EQiwo = Ew2zQ8u7Ss.SITESURLS[T1QDsJlUtCGhn][0]
qe1JPURnS9ODoCNEpbdh8i67Tur = ['الرئيسية','يلا شوت']
def hH3sRBSFAr(mode,url,text):
	if   mode==860: SD0TxMRXiep4cjPBsnzI = kNjCwITmx4YAShdE62FJ()
	elif mode==861: SD0TxMRXiep4cjPBsnzI = nvHUf8mW6E4GSw5VFRXN(url,text)
	elif mode==862: SD0TxMRXiep4cjPBsnzI = rHwfOZb3oSgJKi(url)
	elif mode==863: SD0TxMRXiep4cjPBsnzI = eB3ZX7kK5CTiIOoz(url,text)
	elif mode==869: SD0TxMRXiep4cjPBsnzI = HYGiJ9pfmMTnIb4L7tX(text)
	else: SD0TxMRXiep4cjPBsnzI = False
	return SD0TxMRXiep4cjPBsnzI
def kNjCwITmx4YAShdE62FJ():
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',V4kF6EQiwo+'/indx1/',CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMSTBA-MENU-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'بحث في الموقع',CJlTSEpZsWb0QHg5w,869,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'_REMEMBERRESULTS_')
	khqge7BVD9jPFy1S8T5Gn4QAlH('link',Dj62UpP5MrbTkJqhRa+' ===== ===== ===== '+oOQaRxBXyJ5jVnZ,CJlTSEpZsWb0QHg5w,9999)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"primary-links"(.*?)</u',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?<span>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,861)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"list-categories"(.*?)<script',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = V4kF6EQiwo+'/'+ZgsbN5iSL48t2IhVFnmy.lstrip('/')
			if title in qe1JPURnS9ODoCNEpbdh8i67Tur: continue
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',T1QDsJlUtCGhn+'_SCRIPT_'+kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,861)
	return
def nvHUf8mW6E4GSw5VFRXN(url,UDkNdJxF4il0QoeG89sBR=CJlTSEpZsWb0QHg5w):
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMSTBA-TITLES-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('"home-content"(.*?)"footer"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		D3D6TF50oUBtJlvijPMW8ys = D3D6TF50oUBtJlvijPMW8ys.replace('"overlay"','"duration"><')
		items = Zy2l0g8QU5vqefaTrsw.findall('"thumb".*?data-src="(.*?)".*?"duration">(.*?)<.*?href="(.*?)">(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		wDkMP6jlz7XeN5Sp = []
		for hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc,ZgsbN5iSL48t2IhVFnmy,title in items:
			title = title.strip(' ')
			title = wAmsc95ya0LHz(title)
			ABK45TEMpciLnmIlYOafQJZ8t = Zy2l0g8QU5vqefaTrsw.findall('(.*?) (الحلقة|حلقة).\d+',title,Zy2l0g8QU5vqefaTrsw.DOTALL)
			if 'episodes' not in UDkNdJxF4il0QoeG89sBR and ABK45TEMpciLnmIlYOafQJZ8t:
				title = '_MOD_' + ABK45TEMpciLnmIlYOafQJZ8t[0][0]
				title = title.replace('اون لاين',CJlTSEpZsWb0QHg5w)
				if title not in wDkMP6jlz7XeN5Sp:
					khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,863,hzGKUP1XjAoeT79MJcDF)
					wDkMP6jlz7XeN5Sp.append(title)
			else: khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,862,hzGKUP1XjAoeT79MJcDF,XtbZnKed5mT2IYPy4MqvuOGURNwSc)
	s67485upzYNMS3PqDelkrdfo = Zy2l0g8QU5vqefaTrsw.findall('''["']pagination["'](.*?)["']footer["']''',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if s67485upzYNMS3PqDelkrdfo:
		UDkNdJxF4il0QoeG89sBR = 'episodes_pages' if 'episodes' in UDkNdJxF4il0QoeG89sBR else 'pages'
		D3D6TF50oUBtJlvijPMW8ys = s67485upzYNMS3PqDelkrdfo[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)">(.*?)</a>',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for ZgsbN5iSL48t2IhVFnmy,title in items:
			title = wAmsc95ya0LHz(title)
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة '+title,ZgsbN5iSL48t2IhVFnmy,861,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,UDkNdJxF4il0QoeG89sBR)
	else:
		QTJ5f1mz9FaKt = Zy2l0g8QU5vqefaTrsw.findall('class="pagination__next.*?href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if QTJ5f1mz9FaKt:
			ZgsbN5iSL48t2IhVFnmy = QTJ5f1mz9FaKt[0]
			khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+'صفحة لاحقة',ZgsbN5iSL48t2IhVFnmy,861,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,UDkNdJxF4il0QoeG89sBR)
	return
def eB3ZX7kK5CTiIOoz(url,FfC8TlgIzVh5aDePHELA3rwSo4uNRM):
	dmiXC1cB7MZlb = fUSgd7IjGYX496Hr25uFMl(url,'url')
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',url,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMSTBA-EPISODES_SEASONS-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	hh2VPjs7dkR581KzENYigmpZxLyb = Zy2l0g8QU5vqefaTrsw.findall('"episodes-container"(.*?)</ul>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	t4zynV13ZoPe = Zy2l0g8QU5vqefaTrsw.findall('"thumbnailUrl":"(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	hzGKUP1XjAoeT79MJcDF = t4zynV13ZoPe[0] if t4zynV13ZoPe else CJlTSEpZsWb0QHg5w
	hzGKUP1XjAoeT79MJcDF = hzGKUP1XjAoeT79MJcDF.replace('\/','/')
	hzGKUP1XjAoeT79MJcDF += '|Referer='+V4kF6EQiwo
	items = []
	eE2nkorRIbZ1y = False
	if hh2VPjs7dkR581KzENYigmpZxLyb and not FfC8TlgIzVh5aDePHELA3rwSo4uNRM:
		D3D6TF50oUBtJlvijPMW8ys = hh2VPjs7dkR581KzENYigmpZxLyb[0]
		items = Zy2l0g8QU5vqefaTrsw.findall('data-tab="(.*?)".*?>(.*?)<',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
		for FfC8TlgIzVh5aDePHELA3rwSo4uNRM,title in items:
			FfC8TlgIzVh5aDePHELA3rwSo4uNRM = FfC8TlgIzVh5aDePHELA3rwSo4uNRM.strip('#')
			if len(items)>1: khqge7BVD9jPFy1S8T5Gn4QAlH('folder',kL0nT7NpZdKVD3jM2OHB+title,url,863,hzGKUP1XjAoeT79MJcDF,CJlTSEpZsWb0QHg5w,FfC8TlgIzVh5aDePHELA3rwSo4uNRM)
			else: eE2nkorRIbZ1y = True
	else: eE2nkorRIbZ1y = True
	if eE2nkorRIbZ1y or not FfC8TlgIzVh5aDePHELA3rwSo4uNRM:
		if not FfC8TlgIzVh5aDePHELA3rwSo4uNRM: KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"tab-content.*?id="(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		else: KXu2RYg3Bc = Zy2l0g8QU5vqefaTrsw.findall('"tab-content.*?id="'+FfC8TlgIzVh5aDePHELA3rwSo4uNRM+'"(.*?)</div>',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
		if KXu2RYg3Bc:
			D3D6TF50oUBtJlvijPMW8ys = KXu2RYg3Bc[0]
			items = Zy2l0g8QU5vqefaTrsw.findall('href="(.*?)" title="(.*?)"',D3D6TF50oUBtJlvijPMW8ys,Zy2l0g8QU5vqefaTrsw.DOTALL)
			for ZgsbN5iSL48t2IhVFnmy,title in items:
				if 'http' not in ZgsbN5iSL48t2IhVFnmy: ZgsbN5iSL48t2IhVFnmy = dmiXC1cB7MZlb+'/'+ZgsbN5iSL48t2IhVFnmy.strip('./')
				title = title.replace('</em><span>',YvOQBzaTAscXR9ql)
				khqge7BVD9jPFy1S8T5Gn4QAlH('video',kL0nT7NpZdKVD3jM2OHB+title,ZgsbN5iSL48t2IhVFnmy,862,hzGKUP1XjAoeT79MJcDF)
	return
def rHwfOZb3oSgJKi(url):
	FhX9OGwaNyAEZ,DIA54R1lwcTz7OZPjX6a = [],[]
	BBwfuWGxUIrdCoc4ka7 = url.strip('/')+'/?do=watch'
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',BBwfuWGxUIrdCoc4ka7,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMSTBA-PLAY-1st')
	bGIVq1CQTjmosZg = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('iframe src="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
		bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',ZgsbN5iSL48t2IhVFnmy,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMSTBA-PLAY-2nd')
		Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
		otCOTHujWKp7Dn6dvcafPqlx = Zy2l0g8QU5vqefaTrsw.findall('iframe src="(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
		otCOTHujWKp7Dn6dvcafPqlx = otCOTHujWKp7Dn6dvcafPqlx[0] if otCOTHujWKp7Dn6dvcafPqlx else ZgsbN5iSL48t2IhVFnmy
		otCOTHujWKp7Dn6dvcafPqlx = wAmsc95ya0LHz(otCOTHujWKp7Dn6dvcafPqlx)
		if otCOTHujWKp7Dn6dvcafPqlx not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(otCOTHujWKp7Dn6dvcafPqlx)
			FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(otCOTHujWKp7Dn6dvcafPqlx,'name')
			otCOTHujWKp7Dn6dvcafPqlx = otCOTHujWKp7Dn6dvcafPqlx+'?named='+FFtJQalhPz+'__embed'
			FhX9OGwaNyAEZ.append(otCOTHujWKp7Dn6dvcafPqlx)
	headers = {'Referer':url}
	P0ZwheAmpSHo = Zy2l0g8QU5vqefaTrsw.findall('post_id:(\d+)',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	iGgXABh6Vj5ZSOucoRteHvydQz = V4kF6EQiwo+'/wp-admin/admin-ajax.php?action=video_info&post_id='+P0ZwheAmpSHo[0]
	bqIufCQz2OWExjilm = DNq5CJHPR3G7uX8pbngwF9T(DRmUs7l1O4xLeZYzGITXk,'GET',iGgXABh6Vj5ZSOucoRteHvydQz,CJlTSEpZsWb0QHg5w,headers,CJlTSEpZsWb0QHg5w,CJlTSEpZsWb0QHg5w,'ALMSTBA-PLAY-3rd')
	Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp = bqIufCQz2OWExjilm.content
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"src":"(.*?)"',Ti2vzPUAmqEjLhwMe7gy5X9f3nQCxp,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy.replace('\/','/')
		if ZgsbN5iSL48t2IhVFnmy not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
			FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__watch'
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	ZgsbN5iSL48t2IhVFnmy = Zy2l0g8QU5vqefaTrsw.findall('"Download" target="_blank" href="(.*?)"',bGIVq1CQTjmosZg,Zy2l0g8QU5vqefaTrsw.DOTALL)
	if ZgsbN5iSL48t2IhVFnmy:
		ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy[0]
		if ZgsbN5iSL48t2IhVFnmy not in DIA54R1lwcTz7OZPjX6a:
			DIA54R1lwcTz7OZPjX6a.append(ZgsbN5iSL48t2IhVFnmy)
			FFtJQalhPz = fUSgd7IjGYX496Hr25uFMl(ZgsbN5iSL48t2IhVFnmy,'name')
			ZgsbN5iSL48t2IhVFnmy = ZgsbN5iSL48t2IhVFnmy+'?named='+FFtJQalhPz+'__download'
			FhX9OGwaNyAEZ.append(ZgsbN5iSL48t2IhVFnmy)
	import kORBVznGat
	kORBVznGat.wTf1Sd2gij64hzacOX(FhX9OGwaNyAEZ,T1QDsJlUtCGhn,'video',url)
	return
def HYGiJ9pfmMTnIb4L7tX(search):
	search,EcrV3IasOo4Hq,showDialogs = oQYikwjnrKAcF29bR3WJPvEThfe(search)
	if search==CJlTSEpZsWb0QHg5w: search = tmMVl2yEWYoRg1LjHfPXGc7wqK0s()
	if search==CJlTSEpZsWb0QHg5w: return
	search = search.replace(YvOQBzaTAscXR9ql,'+')
	url = V4kF6EQiwo+'/?s='+search
	nvHUf8mW6E4GSw5VFRXN(url,'search')
	return
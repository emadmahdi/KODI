# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'FASELHD1'
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_FH1_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['جوائز الأوسكار','المراجعات','wwe']
def n1zxUlcAgR(mode,url,text):
	if   mode==570: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==571: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==572: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==573: bPFto2wZdNYrClgBIEv60DJAzu = RG2K4b1gqI9ViYQX(url,text)
	elif mode==576: bPFto2wZdNYrClgBIEv60DJAzu = Q7WcgGmChLNKOT1vUrM()
	elif mode==579: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'لماذا الموقع بطيء',nbOFVEDkpT4BIR7Qq82yPmHeJU,576)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,url = zKREXyTHfVSNL8ZFYs,zKREXyTHfVSNL8ZFYs
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD1-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,579,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured1')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('class="h3">(.*?)<.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details1')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"menu-primary"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		FDmSKut6Meh9yRqY4 = ScntgdOZCY74vNpXeW5jh8i.findall('<li (.*?)</li>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Mvq45Ece0DIhpuS8LAxinWotTj = [nbOFVEDkpT4BIR7Qq82yPmHeJU,'أفلام: ','مسلسلات: ','برامج: ','آسيوي: ','أنمي: ']
		HT4fGXqv8hEcKsJ = 0
		for XHr9mRzgEVcM26KOdYTBWf4Lxa in FDmSKut6Meh9yRqY4:
			if HT4fGXqv8hEcKsJ>0: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',XHr9mRzgEVcM26KOdYTBWf4Lxa,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='#': continue
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				if title==nbOFVEDkpT4BIR7Qq82yPmHeJU: continue
				if any(XPL0O2VkI3w1C8enMaqi in title.lower() for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
				title = Mvq45Ece0DIhpuS8LAxinWotTj[HT4fGXqv8hEcKsJ]+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details2')
			HT4fGXqv8hEcKsJ += 1
	return
def Q7WcgGmChLNKOT1vUrM():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','موقع فاصل الأول بطيء من المصدر .. بسبب قيام أصحاب الموقع بإضافة فحص وتحقق أمني ضد هجوم البرامج وهجوم القراصنة على صفحات الموقع .. والوقت الضائع يذهب في محاولة تجاوز هذا الفحص واثبات أن هذا البرنامج هو مجرد متصفح للمواقع ولا يقوم بالهجوم على المواقع')
	return
def IGDobAKtj4kPF5V(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD1-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('class="h4">(.*?)</div>(.*?)"container"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not b8Ior2kWzq1tc: return
	if type=='filters':
		eXpgPIbRv2ZMGwjm5 = [UTvsQb4HpCP3Aeo2wDZG7X5V.replace('\\/','/').replace('\\"','"')]
	elif type=='featured1':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"homeSlide"(.*?)"container"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(' src="(.*?)".*? href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		LYsTUSXwFZk2E53,rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF = zip(*items)
		items = zip(rU02bCJFWZDfVuhtMgBOyQi5P,LYsTUSXwFZk2E53,bdW70uQAIF)
	elif type=='featured2':
		title,G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*? data-src="(.*?)".*? alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='details2' and len(b8Ior2kWzq1tc)>1:
		title = b8Ior2kWzq1tc[0][0]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured2')
		title = b8Ior2kWzq1tc[1][0]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details3')
		return
	else:
		title,G4JHzTEp61 = b8Ior2kWzq1tc[-1]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*? data-src="(.*?)".*?"h1">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if any(XPL0O2VkI3w1C8enMaqi in title.lower() for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
		X79kphTKa1xLP = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(X79kphTKa1xLP)
		X79kphTKa1xLP = X79kphTKa1xLP.split('?resize=')[0]
		title = dCtxzeFX4GJVonm(title)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة).\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if '/collections/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,571,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp and type==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			title = '_MOD_'+BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
			title = title.strip(' –')
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,573,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		elif 'episodes/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or 'movies/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or 'hindi/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,572,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,573,X79kphTKa1xLP)
	if type=='filters':
		M2RDC4XTQxmqHJ8cWNbA = ScntgdOZCY74vNpXeW5jh8i.findall('"more_button_page":(.*?),',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if M2RDC4XTQxmqHJ8cWNbA:
			count = M2RDC4XTQxmqHJ8cWNbA[0]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+'/offset/'+count
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة أخرى',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
	elif 'details' in type:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall("class='pagination(.*?)</div>",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall("href='(.*?)'.*?>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = 'صفحة '+dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,571,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details4')
	return
def RG2K4b1gqI9ViYQX(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD1-SEASONS_EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	KXVHpZTa3BCSWlQYUut0PdDLc94Rzo = False
	if not type:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"seasonList"(.*?)"container"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href = \'(.*?)\'.*? data-src="(.*?)".*?alt="(.*?)".*?"title">(.*?)</div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if len(items)>1:
				R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
				KXVHpZTa3BCSWlQYUut0PdDLc94Rzo = True
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,name,title in items:
					name = dCtxzeFX4GJVonm(name)
					if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
					title = name+' - '+title
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,573,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,'episodes')
	if type=='episodes' or not KXVHpZTa3BCSWlQYUut0PdDLc94Rzo:
		nnu5vdh1IscOA8J = ScntgdOZCY74vNpXeW5jh8i.findall('"posterImg".*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if nnu5vdh1IscOA8J: X79kphTKa1xLP = nnu5vdh1IscOA8J[0]
		else: X79kphTKa1xLP = nbOFVEDkpT4BIR7Qq82yPmHeJU
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"epAll"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				title = dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,572,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	NWtqFg91ZSKinvIwAc,rMU1A3KVhge,MOi17hVvIujyezmL = [],[],[]
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD1-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXwj0EFQN4no89Gr5VhiYOsCvt = ScntgdOZCY74vNpXeW5jh8i.findall('مستوى المشاهدة.*?">(.*?)</span>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXwj0EFQN4no89Gr5VhiYOsCvt:
		DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('"tag">(.*?)</a>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"videoRow"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&img=')[0]
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=__embed')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="streamHeader(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall("href = '(.*?)'.*?</i>(.*?)</a>",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&img=')[0]
			name = name.strip(S3X6GcaiExOPtb)
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__watch')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="downloadLinks(.*?)blackwindow',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</span>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&img=')[0]
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__download')
	for clCgpAiNx2TMzBoKbrFHfkXjUDG0 in NWtqFg91ZSKinvIwAc:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name = clCgpAiNx2TMzBoKbrFHfkXjUDG0.split('?named')
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in rMU1A3KVhge:
			rMU1A3KVhge.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			MOi17hVvIujyezmL.append(clCgpAiNx2TMzBoKbrFHfkXjUDG0)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(MOi17hVvIujyezmL,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/?s='+search
	IGDobAKtj4kPF5V(plSscrVjkRviPwm,'details5')
	return
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'MOVIZLAND'
headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_MVZ_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
C07t1e38mH2LEMzny4vX9riOblaBF = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][1]
def n1zxUlcAgR(mode,url,text):
	if   mode==180: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==181: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==182: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==183: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==188: bPFto2wZdNYrClgBIEv60DJAzu = y8dfMtPUxD1lCROwL97YsuWEk34S()
	elif mode==189: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def y8dfMtPUxD1lCROwL97YsuWEk34S():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج',message)
	return
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,189,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بوكس اوفيس موفيز لاند',zKREXyTHfVSNL8ZFYs,181,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'box-office')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أحدث الافلام',zKREXyTHfVSNL8ZFYs,181,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'latest-movies')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'تليفزيون موفيز لاند',zKREXyTHfVSNL8ZFYs,181,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'tv')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الاكثر مشاهدة',zKREXyTHfVSNL8ZFYs,181,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'top-views')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أقوى الافلام الحالية',zKREXyTHfVSNL8ZFYs,181,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'top-movies')
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-MENU-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<h2><a href="(.*?)".*?">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,181)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-ITEMS-1st')
	if type=='latest-movies': G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall('class="titleSection">أحدث الأفلام</h1>(.*?)<h1',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	elif type=='box-office': G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall('class="titleSection">بوكس اوفيس موفيز لاند</h1>(.*?)<h1',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	elif type=='top-movies': G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall('btn-2-overlay(.*?)<style>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	elif type=='top-views': G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall('btn-1 btn-absoly(.*?)btn-2 btn-absoly',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	elif type=='tv': G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall('class="titleSection">تليفزيون موفيز لاند</h1>(.*?)class="paging"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	else: G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
	if type in ['top-views','top-movies']:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('style="background-image:url\(\'(.*?)\'.*?href="(.*?)".*?href="(.*?)".*?bottom-title.*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: items = ScntgdOZCY74vNpXeW5jh8i.findall('height="3[0-9]+" src="(.*?)".*?bottom-title.*?href=.*?>(.*?)<.*?href="(.*?)".*?href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	Zq6suEoHra8xBIJFSUAvWYb7 = ['فيلم','الحلقة','الحلقه','عرض','Raw','SmackDown','اعلان','اجزاء']
	for X79kphTKa1xLP,HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,yWM7n98Pir0vxBftd in items:
		if type in ['top-views','top-movies']:
			X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,f7Je8XzEqNpgHL9m4OURdAQ1,title = X79kphTKa1xLP,HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,yWM7n98Pir0vxBftd
		else: X79kphTKa1xLP,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,f7Je8XzEqNpgHL9m4OURdAQ1 = X79kphTKa1xLP,HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,yWM7n98Pir0vxBftd
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('?view=true',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = dCtxzeFX4GJVonm(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('بجوده ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.strip(S3X6GcaiExOPtb)
		if 'الحلقة' in title or 'الحلقه' in title:
			BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|الحلقه) \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if BBuqr7CwzEIi9UL54n0AVoHXPlp:
				title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
				if title not in tWsVFQj47pw0L56rZfg:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,183,X79kphTKa1xLP)
					tWsVFQj47pw0L56rZfg.append(title)
		elif any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in Zq6suEoHra8xBIJFSUAvWYb7):
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 + '?servers=' + f7Je8XzEqNpgHL9m4OURdAQ1
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,182,X79kphTKa1xLP)
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 + '?servers=' + f7Je8XzEqNpgHL9m4OURdAQ1
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,183,X79kphTKa1xLP)
	if type==nbOFVEDkpT4BIR7Qq82yPmHeJU:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('\n<li><a href="(.*?)".*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = dCtxzeFX4GJVonm(title)
			title = title.replace('الصفحة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,181)
	return
def PXyn8J3WjhRgA(url):
	plSscrVjkRviPwm = url.split('?servers=')[0]
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-EPISODES-1st')
	G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall('<title>(.*?)</title>.*?height="([0-9]+)" src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	title,uiazRbmZ63Je21WGqn,X79kphTKa1xLP = G4JHzTEp61[0]
	name = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|الحلقه) [0-9]+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if name: name = '_MOD_' + name[0][0]
	else: name = title
	items = []
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="episodesNumbers"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			title = ScntgdOZCY74vNpXeW5jh8i.findall('(الحلقة|الحلقه)-([0-9]+)',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-2],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not title: title = ScntgdOZCY74vNpXeW5jh8i.findall('()-([0-9]+)',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-2],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if title: title = S3X6GcaiExOPtb + title[0][1]
			else: title = nbOFVEDkpT4BIR7Qq82yPmHeJU
			title = name + ' - ' + 'الحلقة' + title
			title = dCtxzeFX4GJVonm(title)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,182,X79kphTKa1xLP)
	if not items:
		title = dCtxzeFX4GJVonm(title)
		if 'بجودة ' in title or 'بجوده ' in title:
			title = '_MOD_' + title.replace('بجودة ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('بجوده ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,182,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	oOkVKhLScA2xdJ05lCRPgN = url.split('?servers=')
	plSscrVjkRviPwm = oOkVKhLScA2xdJ05lCRPgN[0]
	del oOkVKhLScA2xdJ05lCRPgN[0]
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-PLAY-1st')
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('font-size: 25px;" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in oOkVKhLScA2xdJ05lCRPgN: oOkVKhLScA2xdJ05lCRPgN.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	lPpY5fw3tOBcEye91Caun2FQZ = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in oOkVKhLScA2xdJ05lCRPgN:
		if '://moshahda.' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			mne39j1U5uAXkYfW26MdqaPiy4t = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			lPpY5fw3tOBcEye91Caun2FQZ.append(mne39j1U5uAXkYfW26MdqaPiy4t+'?named=Main')
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in oOkVKhLScA2xdJ05lCRPgN:
		if '://vb.movizland.' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-PLAY-2nd')
			UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.decode('windows-1256').encode(zSafwK0sDXdMN5JReniIQmrZxp)
			UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('src="http://up.movizland.com/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('src="http://up.movizland.online/uploads/13721411411.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"')
			UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('</a></div><br /><div align="center">','src="/uploads/13721411411.png"')
			UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('class="tborder" align="center"','src="/uploads/13721411411.png"')
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				Z82diNu7RlDybXFqVrvo,gCJprIs2wUzfcNhtxv = [],[]
				if len(eXpgPIbRv2ZMGwjm5)==1:
					title = nbOFVEDkpT4BIR7Qq82yPmHeJU
					G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
				else:
					for G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
						eXBMHvPbDunL = ScntgdOZCY74vNpXeW5jh8i.findall('src="/uploads/13721411411.png".*?http://up.movizland.(online|com)/uploads/.*?\*\*\*\*\*\*\*+(.*?src="/uploads/13721411411.png")',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						if eXBMHvPbDunL: G4JHzTEp61 = 'src="/uploads/13721411411.png"  \n  ' + eXBMHvPbDunL[0][1]
						eXBMHvPbDunL = ScntgdOZCY74vNpXeW5jh8i.findall('src="/uploads/13721411411.png".*?<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />(.*?href="http://moshahda\..*?/\w+.html".*?src="/uploads/13721411411.png")',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						if eXBMHvPbDunL: G4JHzTEp61 = 'src="/uploads/13721411411.png"  \n  ' + eXBMHvPbDunL[0]
						eXBMHvPbDunL = ScntgdOZCY74vNpXeW5jh8i.findall('(src="/uploads/13721411411.png".*?href="http://moshahda\..*?/\w+.html".*?)<hr size="1" style="color:'+'#'+'333; background-color:'+'#'+'333" />.*?src="/uploads/13721411411.png"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						if eXBMHvPbDunL: G4JHzTEp61 = eXBMHvPbDunL[0] + '  \n  src="/uploads/13721411411.png"'
						Q2LAzZadUR5MKPcT = ScntgdOZCY74vNpXeW5jh8i.findall('<(.*?)http://up.movizland.(online|com)/uploads/',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						title = ScntgdOZCY74vNpXeW5jh8i.findall('> *([^<>]+) *<',Q2LAzZadUR5MKPcT[0][0],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						title = S3X6GcaiExOPtb.join(title)
						title = title.strip(S3X6GcaiExOPtb)
						title = title.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
						Z82diNu7RlDybXFqVrvo.append(title)
					bCiGxXzDkH = nnRXQH90qeOtABkJzGr('أختر الفيديو المطلوب:', Z82diNu7RlDybXFqVrvo)
					if bCiGxXzDkH == -1 : return
					title = Z82diNu7RlDybXFqVrvo[bCiGxXzDkH]
					G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[bCiGxXzDkH]
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http://moshahda\..*?/\w+.html)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				MKfBxCWnVdki7c = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
				lPpY5fw3tOBcEye91Caun2FQZ.append(MKfBxCWnVdki7c+'?named=Forum')
				G4JHzTEp61 = G4JHzTEp61.replace('ـ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				G4JHzTEp61 = G4JHzTEp61.replace('src="http://up.movizland.online/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				G4JHzTEp61 = G4JHzTEp61.replace('src="http://up.movizland.com/uploads/1517412175296.png"','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="both"  \n  ')
				G4JHzTEp61 = G4JHzTEp61.replace('سيرفرات التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				G4JHzTEp61 = G4JHzTEp61.replace('روابط التحميل','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="download"  \n  ')
				G4JHzTEp61 = G4JHzTEp61.replace('سيرفرات المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				G4JHzTEp61 = G4JHzTEp61.replace('روابط المشاهد','src="/uploads/13721411411.png"  \n  src="/uploads/13721411411.png"  \n  typetype="watch"  \n  ')
				UGK7nEhgLaOW2BtZVe1 = ScntgdOZCY74vNpXeW5jh8i.findall('(src="/uploads/13721411411.png".*?href="http://e5tsar.com/\d+".*?src="/uploads/13721411411.png")',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for MMzdmJ4hEwDRHCjQGr1ip72S in UGK7nEhgLaOW2BtZVe1:
					type = ScntgdOZCY74vNpXeW5jh8i.findall(' typetype="(.*?)" ',MMzdmJ4hEwDRHCjQGr1ip72S)
					if type:
						if type[0]!='both': type = '__'+type[0]
						else: type = nbOFVEDkpT4BIR7Qq82yPmHeJU
					items = ScntgdOZCY74vNpXeW5jh8i.findall('(?<!http://e5tsar.com/)(\w+[ \w]*</font>.*?|\w+[ \w]*<br />.*?)href="(http://e5tsar.com/.*?)"',MMzdmJ4hEwDRHCjQGr1ip72S,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					for IThDSnxM0sLAz5UFEOqjmuwPaf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
						title = ScntgdOZCY74vNpXeW5jh8i.findall('(\w+[ \w]*)<',IThDSnxM0sLAz5UFEOqjmuwPaf)
						title = title[-1]
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 + '?named=' + title + type
						lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm.replace(zKREXyTHfVSNL8ZFYs,C07t1e38mH2LEMzny4vX9riOblaBF)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-PLAY-3rd')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		xx4gSk05YlULpzcXNjPDb2i = items[-1]
		lPpY5fw3tOBcEye91Caun2FQZ.append(xx4gSk05YlULpzcXNjPDb2i+'?named=Mobile')
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVIZLAND-SEARCH-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<option value="(.*?)">(.*?)</option>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	K5BAv0lgMsab86R = [ nbOFVEDkpT4BIR7Qq82yPmHeJU ]
	oVlyqSBwU3tWGDLKE91u8AMQkCa = [ 'الكل وبدون فلتر' ]
	for jGdXt7eADorwlv8pahNV95H6Tn2qKx,title in items:
		K5BAv0lgMsab86R.append(jGdXt7eADorwlv8pahNV95H6Tn2qKx)
		oVlyqSBwU3tWGDLKE91u8AMQkCa.append(title)
	if jGdXt7eADorwlv8pahNV95H6Tn2qKx:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الفلتر المناسب:', oVlyqSBwU3tWGDLKE91u8AMQkCa)
		if bCiGxXzDkH == -1 : return
		jGdXt7eADorwlv8pahNV95H6Tn2qKx = K5BAv0lgMsab86R[bCiGxXzDkH]
	else: jGdXt7eADorwlv8pahNV95H6Tn2qKx = nbOFVEDkpT4BIR7Qq82yPmHeJU
	url = zKREXyTHfVSNL8ZFYs + '/?s='+search+'&mcat='+jGdXt7eADorwlv8pahNV95H6Tn2qKx
	IGDobAKtj4kPF5V(url)
	return
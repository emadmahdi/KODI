# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'LIVETV'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE['PYTHON'][0]
def n1zxUlcAgR(mode,url):
	if   mode==100: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==101: bPFto2wZdNYrClgBIEv60DJAzu = KwinXTzJv1N8yghA9UbI0HueGqa7R('0',True)
	elif mode==102: bPFto2wZdNYrClgBIEv60DJAzu = KwinXTzJv1N8yghA9UbI0HueGqa7R('1',True)
	elif mode==103: bPFto2wZdNYrClgBIEv60DJAzu = KwinXTzJv1N8yghA9UbI0HueGqa7R('2',True)
	elif mode==104: bPFto2wZdNYrClgBIEv60DJAzu = KwinXTzJv1N8yghA9UbI0HueGqa7R('3',True)
	elif mode==105: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==106: bPFto2wZdNYrClgBIEv60DJAzu = KwinXTzJv1N8yghA9UbI0HueGqa7R('4',True)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_M3U_'+'قوائم فيديوهات M3U',nbOFVEDkpT4BIR7Qq82yPmHeJU,762)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_IPT_'+'قوائم فيديوهات IPTV',nbOFVEDkpT4BIR7Qq82yPmHeJU,761)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TV0_'+'قنوات من مواقعها الأصلية',nbOFVEDkpT4BIR7Qq82yPmHeJU,101)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TV4_'+'قنوات مختارة من يوتيوب',nbOFVEDkpT4BIR7Qq82yPmHeJU,106)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_YUT_'+'قنوات عربية من يوتيوب',nbOFVEDkpT4BIR7Qq82yPmHeJU,147)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_YUT_'+'قنوات أجنبية من يوتيوب',nbOFVEDkpT4BIR7Qq82yPmHeJU,148)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_IFL_'+'  قناة آي فيلم من موقعهم  ',nbOFVEDkpT4BIR7Qq82yPmHeJU,28)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live','_MRF_'+'قناة المعارف من موقعهم',nbOFVEDkpT4BIR7Qq82yPmHeJU,41)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live','_PNT_'+'قناة هلا من موقع بانيت',nbOFVEDkpT4BIR7Qq82yPmHeJU,38)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TV1_'+'قنوات تلفزيونية عامة',nbOFVEDkpT4BIR7Qq82yPmHeJU,102)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TV2_'+'قنوات تلفزيونية خاصة',nbOFVEDkpT4BIR7Qq82yPmHeJU,103)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TV3_'+'قنوات تلفزيونية للفحص',nbOFVEDkpT4BIR7Qq82yPmHeJU,104)
	return
def KwinXTzJv1N8yghA9UbI0HueGqa7R(XHr9mRzgEVcM26KOdYTBWf4Lxa,showDialogs=True):
	TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_TV'+XHr9mRzgEVcM26KOdYTBWf4Lxa+'_'
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = {'id':nbOFVEDkpT4BIR7Qq82yPmHeJU,'user':iidHGYjPEW4zU,'function':'list','menu':XHr9mRzgEVcM26KOdYTBWf4Lxa}
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',zKREXyTHfVSNL8ZFYs,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-ITEMS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	items = ScntgdOZCY74vNpXeW5jh8i.findall('([^;\r\n]+?);;(.*?);;(.*?);;(.*?);;(.*?);;',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		for WoEZvMXa0K2suwgPl in range(len(items)):
			name = items[WoEZvMXa0K2suwgPl][3]
			start = name[0:2]
			start = start.replace('al','Al')
			start = start.replace('El','Al')
			start = start.replace('AL','Al')
			start = start.replace('EL','Al')
			name = start+name[2:]
			start = name[0:3]
			start = start.replace('Al-','Al')
			start = start.replace('Al ','Al')
			name = start+name[3:]
			items[WoEZvMXa0K2suwgPl] = items[WoEZvMXa0K2suwgPl][0],items[WoEZvMXa0K2suwgPl][1],items[WoEZvMXa0K2suwgPl][2],name,items[WoEZvMXa0K2suwgPl][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for eg6iV4ckQxvTrjWKyBulYR,RWZpkDLtY5Eyb46029MvAKmqBQd8o,vLrxHDuiN08ba5pRlmUtMAIyfZX,name,X79kphTKa1xLP in items:
			if '#' in eg6iV4ckQxvTrjWKyBulYR: continue
			if eg6iV4ckQxvTrjWKyBulYR!='URL': name = name+eMypvI8XqHjYU02anWD9gsSrkt+PCnucez1ITGQbklj7SoqNtw0O8+eg6iV4ckQxvTrjWKyBulYR+c7gxFyUCGm
			url = eg6iV4ckQxvTrjWKyBulYR+';;'+RWZpkDLtY5Eyb46029MvAKmqBQd8o+';;'+vLrxHDuiN08ba5pRlmUtMAIyfZX+';;'+XHr9mRzgEVcM26KOdYTBWf4Lxa
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+nbOFVEDkpT4BIR7Qq82yPmHeJU+name,url,105,X79kphTKa1xLP)
	else:
		if showDialogs: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'هذه الخدمة مخصصة للمبرمج فقط',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	return
def AOk1T6KwciHrWU2MYJzZnEN(id):
	eg6iV4ckQxvTrjWKyBulYR,RWZpkDLtY5Eyb46029MvAKmqBQd8o,vLrxHDuiN08ba5pRlmUtMAIyfZX,XHr9mRzgEVcM26KOdYTBWf4Lxa = id.split(';;')
	url = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if eg6iV4ckQxvTrjWKyBulYR=='URL': url = vLrxHDuiN08ba5pRlmUtMAIyfZX
	elif eg6iV4ckQxvTrjWKyBulYR=='YOUTUBE':
		url = sCSyOla9hrcE['YOUTUBE'][0]+'/watch?v='+vLrxHDuiN08ba5pRlmUtMAIyfZX
		import gdVOXAx7tm
		gdVOXAx7tm.ooRpOJtyIaY([url],QSJFrwB3dMiyH2mTPKD9a,'live',url)
		return
	elif eg6iV4ckQxvTrjWKyBulYR=='GA':
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = { 'id' : nbOFVEDkpT4BIR7Qq82yPmHeJU, 'user' : iidHGYjPEW4zU , 'function' : 'playGA1' , 'menu' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-1st')
		if not cnPhVmgFxA.succeeded:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		cookies = cnPhVmgFxA.cookies
		sVirjnBEY23dFh4oHleMXvz = cookies['ASP.NET_SessionId']
		url = cnPhVmgFxA.headers['Location']
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = { 'id' : vLrxHDuiN08ba5pRlmUtMAIyfZX , 'user' : iidHGYjPEW4zU , 'function' : 'playGA2' , 'menu' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
		headers = { 'Cookie' : 'ASP.NET_SessionId='+sVirjnBEY23dFh4oHleMXvz }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,iugaeRtZ5HFw7mJc9AdTbKlLV2,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-2nd')
		if not cnPhVmgFxA.succeeded:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		url = ScntgdOZCY74vNpXeW5jh8i.findall('resp":"(http.*?m3u8)(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url[0][0]
		wqHptDJiLhz = url[0][1]
		yJUXhxDajuFd0KSZEnNTWs = 'http://38.'+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'777/'+vLrxHDuiN08ba5pRlmUtMAIyfZX+'_HD.m3u8'+wqHptDJiLhz
		QQ7YMpCyVfa3sdv = yJUXhxDajuFd0KSZEnNTWs.replace('36:7','40:7').replace('_HD.m3u8','.m3u8')
		vAhfrYnocGsCkwB0 = yJUXhxDajuFd0KSZEnNTWs.replace('36:7','42:7').replace('_HD.m3u8','.m3u8')
		bbKoeBcirVfzwAqZdQUFDSX = ['HD','SD1','SD2']
		lPpY5fw3tOBcEye91Caun2FQZ = [yJUXhxDajuFd0KSZEnNTWs,QQ7YMpCyVfa3sdv,vAhfrYnocGsCkwB0]
		bCiGxXzDkH = 0
		if bCiGxXzDkH == -1: return
		else: url = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	elif eg6iV4ckQxvTrjWKyBulYR=='NT':
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = { 'id' : vLrxHDuiN08ba5pRlmUtMAIyfZX , 'user' : iidHGYjPEW4zU , 'function' : 'playNT' , 'menu' : XHr9mRzgEVcM26KOdYTBWf4Lxa }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST', zKREXyTHfVSNL8ZFYs, iugaeRtZ5HFw7mJc9AdTbKlLV2, headers, False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-3rd')
		if not cnPhVmgFxA.succeeded:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		url = cnPhVmgFxA.headers['Location']
		url = url.replace('%20',S3X6GcaiExOPtb)
		url = url.replace('%3D','=')
		if 'Learn' in vLrxHDuiN08ba5pRlmUtMAIyfZX:
			url = url.replace('NTNNile',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			url = url.replace('learning1','Learning')
	elif eg6iV4ckQxvTrjWKyBulYR=='PL':
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = { 'id' : vLrxHDuiN08ba5pRlmUtMAIyfZX , 'user' : iidHGYjPEW4zU , 'function' : 'playPL' , 'menu' : XHr9mRzgEVcM26KOdYTBWf4Lxa }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST', zKREXyTHfVSNL8ZFYs, iugaeRtZ5HFw7mJc9AdTbKlLV2, nbOFVEDkpT4BIR7Qq82yPmHeJU,False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-4th')
		if not cnPhVmgFxA.succeeded:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		url = cnPhVmgFxA.headers['Location']
		headers = {'Referer':cnPhVmgFxA.headers['Referer']}
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',url, nbOFVEDkpT4BIR7Qq82yPmHeJU,headers , nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-5th')
		if not cnPhVmgFxA.succeeded:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		items = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		url = items[0]
	elif eg6iV4ckQxvTrjWKyBulYR in ['TA','FM','YU','WS1','WS2','RL1','RL2']:
		if eg6iV4ckQxvTrjWKyBulYR=='TA': vLrxHDuiN08ba5pRlmUtMAIyfZX = id
		headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = { 'id' : vLrxHDuiN08ba5pRlmUtMAIyfZX , 'user' : iidHGYjPEW4zU , 'function' : 'play'+eg6iV4ckQxvTrjWKyBulYR , 'menu' : XHr9mRzgEVcM26KOdYTBWf4Lxa }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',zKREXyTHfVSNL8ZFYs,iugaeRtZ5HFw7mJc9AdTbKlLV2,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-6th')
		if not cnPhVmgFxA.succeeded:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذه الخدمة مخصصة للمبرمج فقط')
			return
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		url = cnPhVmgFxA.headers['Location']
		if eg6iV4ckQxvTrjWKyBulYR=='FM':
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET', url, nbOFVEDkpT4BIR7Qq82yPmHeJU, nbOFVEDkpT4BIR7Qq82yPmHeJU, False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVETV-PLAY-7th')
			url = cnPhVmgFxA.headers['Location']
			url = url.replace('https','http')
	brh5aWRxQzn6YL8UDNOyK9SFGo(url,QSJFrwB3dMiyH2mTPKD9a,'live')
	return
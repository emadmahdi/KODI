# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'ALARAB'
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_KLA_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
def n1zxUlcAgR(mode,url,text):
	if   mode==10: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==11: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==12: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==13: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==14: bPFto2wZdNYrClgBIEv60DJAzu = f0GcyVKge7()
	elif mode==15: bPFto2wZdNYrClgBIEv60DJAzu = sybcZ02uXBT()
	elif mode==16: bPFto2wZdNYrClgBIEv60DJAzu = ccXGVP8kzM7UNgQ6qDmijvsI02()
	elif mode==19: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,19,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'آخر الإضافات',nbOFVEDkpT4BIR7Qq82yPmHeJU,14)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان',nbOFVEDkpT4BIR7Qq82yPmHeJU,15)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ALARAB-MENU-1st')
	eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('id="nav-slider"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	mKr2OGpz3BEs8XuCQNaIxhybV = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',mKr2OGpz3BEs8XuCQNaIxhybV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = title.strip(S3X6GcaiExOPtb)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="navbar"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	eXBMHvPbDunL = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',eXBMHvPbDunL,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,11)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def sybcZ02uXBT():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'جميع المسلسلات العربية',zKREXyTHfVSNL8ZFYs+'/view-8/مسلسلات-عربية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات السنة الأخيرة',nbOFVEDkpT4BIR7Qq82yPmHeJU,16)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان الأخيرة 1',zKREXyTHfVSNL8ZFYs+'/view-8/مسلسلات-رمضان-2022',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان الأخيرة 2',zKREXyTHfVSNL8ZFYs+'/view-8/مسلسلات-رمضان-2023',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2023',zKREXyTHfVSNL8ZFYs+'/ramadan2023/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2022',zKREXyTHfVSNL8ZFYs+'/ramadan2022/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2021',zKREXyTHfVSNL8ZFYs+'/ramadan2021/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2020',zKREXyTHfVSNL8ZFYs+'/ramadan2020/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2019',zKREXyTHfVSNL8ZFYs+'/ramadan2019/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2018',zKREXyTHfVSNL8ZFYs+'/ramadan2018/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2017',zKREXyTHfVSNL8ZFYs+'/ramadan2017/مصرية',11)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات رمضان 2016',zKREXyTHfVSNL8ZFYs+'/ramadan2016/مصرية',11)
	return
def f0GcyVKge7():
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'ALARAB-LATEST-1st')
	eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('heading-top(.*?)div class=',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]+eXpgPIbRv2ZMGwjm5[1]
	items=ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?data-src="(.*?)" alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		url = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if 'series' in url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,11,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,12,X79kphTKa1xLP)
	return
def IGDobAKtj4kPF5V(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,True,'ALARAB-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('video-category(.*?)right_content',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5: return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	qv5R2JduMmjoEIcKQ3kt7WgX = False
	items = ScntgdOZCY74vNpXeW5jh8i.findall('video-box.*?href="(.*?)".*?src="(http.*?)" alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg,N3OCzkD7MEISKqTBJ = [],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if title==nbOFVEDkpT4BIR7Qq82yPmHeJU: title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-1].replace('-',S3X6GcaiExOPtb)
		AG0kLzo8e6wiV1DdSb = ScntgdOZCY74vNpXeW5jh8i.findall('(\d+)',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if AG0kLzo8e6wiV1DdSb: AG0kLzo8e6wiV1DdSb = int(AG0kLzo8e6wiV1DdSb[0])
		else: AG0kLzo8e6wiV1DdSb = 0
		N3OCzkD7MEISKqTBJ.append([X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb])
	N3OCzkD7MEISKqTBJ = sorted(N3OCzkD7MEISKqTBJ, reverse=True, key=lambda key: key[3])
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb in N3OCzkD7MEISKqTBJ:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = title.replace('مشاهدة مسلسل','مسلسل')
		title = title.replace('مشاهدة المسلسل','المسلسل')
		title = title.replace('مشاهدة فيلم','فيلم')
		title = title.replace('مشاهدة الفيلم','الفيلم')
		title = title.replace('مباشرة كواليتي',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('عالية على العرب',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('مشاهدة مباشرة',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('اون لاين',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('اونلاين',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('بجودة عالية',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('جودة عالية',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('بدون تحميل',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('على العرب',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.replace('مباشرة',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = title.strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		title = '_MOD_'+title
		HDE69mkhQg2NaFpuUy5JRb = title
		if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
			BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if BBuqr7CwzEIi9UL54n0AVoHXPlp: HDE69mkhQg2NaFpuUy5JRb = BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
		if HDE69mkhQg2NaFpuUy5JRb not in tWsVFQj47pw0L56rZfg:
			tWsVFQj47pw0L56rZfg.append(HDE69mkhQg2NaFpuUy5JRb)
			if '/q/' in url and ('الحلقة' in title or 'الحلقه' in title):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,13,X79kphTKa1xLP)
				qv5R2JduMmjoEIcKQ3kt7WgX = True
			elif 'series' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,11,X79kphTKa1xLP)
				qv5R2JduMmjoEIcKQ3kt7WgX = True
			else:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,12,X79kphTKa1xLP)
				qv5R2JduMmjoEIcKQ3kt7WgX = True
	if qv5R2JduMmjoEIcKQ3kt7WgX:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('tsc_3d_button red.*?href="(.*?)" title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ohpwd6UumaecE3IWV8lAv0 in items:
			url = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+ohpwd6UumaecE3IWV8lAv0,url,11)
	return
def PXyn8J3WjhRgA(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'ALARAB-EPISODES-1st')
	dKDogOhGNljecME = ScntgdOZCY74vNpXeW5jh8i.findall('href="(/series.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+dKDogOhGNljecME[0]
	bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(plSscrVjkRviPwm)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	lPpY5fw3tOBcEye91Caun2FQZ = []
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'ALARAB-PLAY-1st')
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('class="resp-iframe" src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm:
		plSscrVjkRviPwm = plSscrVjkRviPwm[0]
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('^(http.*?)(http.*?)$',plSscrVjkRviPwm,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if rU02bCJFWZDfVuhtMgBOyQi5P:
			xgSWk30lJyqA2rmUn8dNBaRTz = rU02bCJFWZDfVuhtMgBOyQi5P[0][0]
			ZirzIaJqcENbWvpG4o,LLcmCS143zXWDNrq = rU02bCJFWZDfVuhtMgBOyQi5P[0][1].rsplit('/',1)
			zb2QIaL7Y4h9g8lSck = ZirzIaJqcENbWvpG4o+'?named=__watch'
			lPpY5fw3tOBcEye91Caun2FQZ.append(zb2QIaL7Y4h9g8lSck)
			jYzLtvxkH7R3msNZwhgeT90noEu5q = xgSWk30lJyqA2rmUn8dNBaRTz+LLcmCS143zXWDNrq
		else:
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,False,'ALARAB-PLAY-2nd')
			plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('"src": "(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if plSscrVjkRviPwm:
				plSscrVjkRviPwm = plSscrVjkRviPwm[0]+'?named=__watch__m3u8'
				lPpY5fw3tOBcEye91Caun2FQZ.append(plSscrVjkRviPwm)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('searchBox(.*?)<style>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[0]+'?named=__watch'
			lPpY5fw3tOBcEye91Caun2FQZ.append(plSscrVjkRviPwm)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def ccXGVP8kzM7UNgQ6qDmijvsI02():
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'ALARAB-RAMADAN-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="content_sec"(.*?)id="left_content"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	H9AKU2MoNOwecz8JIXmE = ScntgdOZCY74vNpXeW5jh8i.findall('/ramadan([0-9]+)/',str(items),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	H9AKU2MoNOwecz8JIXmE = H9AKU2MoNOwecz8JIXmE[0]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		url = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = title.strip(S3X6GcaiExOPtb)+S3X6GcaiExOPtb+H9AKU2MoNOwecz8JIXmE
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,11)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs + "/q/" + T871qPZzS4LkoMBa3Db9Q
	bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	return
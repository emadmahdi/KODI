# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'DRAMAS7'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_DR7_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['الصفحة الرئيسية','Sign in','تسجيل']
def n1zxUlcAgR(mode,url,text):
	if   mode==680: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==681: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==682: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==683: bPFto2wZdNYrClgBIEv60DJAzu = XZPY6JeohB9ODmRrgIxvuA(url,text)
	elif mode==684: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==689: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DRAMAS7-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,689,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',zKREXyTHfVSNL8ZFYs,681,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('/category.php">(.*?)"navslide-divider"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall("'dropdown-menu'(.*?)</ul>",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for eXBMHvPbDunL in eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = G4JHzTEp61.replace(eXBMHvPbDunL,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if title in CZrI4vYju7a: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,684)
	return
def Cvflxc4FMs37bmY(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DRAMAS7-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"caret"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IHV3wWCjYv4:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		G4JHzTEp61 = G4JHzTEp61.replace('"presentation"','</ul>')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = [(nbOFVEDkpT4BIR7Qq82yPmHeJU,G4JHzTEp61)]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' فرز أو فلتر أو ترتيب '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		for WBVx7UzjEQPnhy0owDHtmdGgl,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if WBVx7UzjEQPnhy0owDHtmdGgl: WBVx7UzjEQPnhy0owDHtmdGgl = WBVx7UzjEQPnhy0owDHtmdGgl+': '
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = WBVx7UzjEQPnhy0owDHtmdGgl+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,681)
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"pm-category-subcats"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(items)<30:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,681)
	if not IHV3wWCjYv4 and not b8Ior2kWzq1tc: IGDobAKtj4kPF5V(url)
	return
def IGDobAKtj4kPF5V(url,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if s0tfc7T2hwBM=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DRAMAS7-TITLES-1st')
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DRAMAS7-TITLES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	G4JHzTEp61,items = nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	if s0tfc7T2hwBM=='ajax-search':
		G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG: items.append((nbOFVEDkpT4BIR7Qq82yPmHeJU,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title))
	elif s0tfc7T2hwBM=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="featured"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			if G4JHzTEp61:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('''href="(.*?)" title="(.*?)".*?:url\(\'(.*?)\'''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF,iOBlEWpyGH6U1rakhzYnuM = zip(*items)
				items = zip(iOBlEWpyGH6U1rakhzYnuM,rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF)
	elif s0tfc7T2hwBM=='new_episodes':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"row pm-ul-browse-videos(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	elif s0tfc7T2hwBM=='new_movies':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"row pm-ul-browse-videos(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(eXpgPIbRv2ZMGwjm5)>1: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[1]
	elif s0tfc7T2hwBM=='featured_series':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG: items.append((nbOFVEDkpT4BIR7Qq82yPmHeJU,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title))
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(data-echo=".*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if G4JHzTEp61 and not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: return
	tWsVFQj47pw0L56rZfg = []
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة).\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,682,X79kphTKa1xLP)
		elif s0tfc7T2hwBM=='new_episodes':
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,682,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,683,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,683,X79kphTKa1xLP)
	if 1:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='#': continue
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
				title = dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,681)
	return
def XZPY6JeohB9ODmRrgIxvuA(url,W58zOLpMh2ZTrcEemS70AUy):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DRAMAS7-EPISODES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	nnu5vdh1IscOA8J = ScntgdOZCY74vNpXeW5jh8i.findall('"series-header".*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if nnu5vdh1IscOA8J: X79kphTKa1xLP = nnu5vdh1IscOA8J[0]
	else: X79kphTKa1xLP = nbOFVEDkpT4BIR7Qq82yPmHeJU
	items = []
	ee9RfPxQdhHY1qbt0Om8ianC673W = False
	if IHV3wWCjYv4 and not W58zOLpMh2ZTrcEemS70AUy:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('''onclick="openCity\(event, '(.*?)'\)">(.*?)</button>''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for W58zOLpMh2ZTrcEemS70AUy,title in items:
			W58zOLpMh2ZTrcEemS70AUy = W58zOLpMh2ZTrcEemS70AUy.strip('#')
			if len(items)>1: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,683,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,W58zOLpMh2ZTrcEemS70AUy)
			else: ee9RfPxQdhHY1qbt0Om8ianC673W = True
	else: ee9RfPxQdhHY1qbt0Om8ianC673W = True
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('id="'+W58zOLpMh2ZTrcEemS70AUy+'"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc and ee9RfPxQdhHY1qbt0Om8ianC673W:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('title="(.*?)" href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		items = []
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in XhE8FpdTjG: items.append((grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP))
		if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
			title = title.replace('</em><span>',S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,682,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	NWtqFg91ZSKinvIwAc,vdYMP3fDSnxzeEgXmqpcua = [],[]
	plSscrVjkRviPwm = url.replace('watch.php','play.php')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DRAMAS7-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"WatchList"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('embed-url="(.*?)".*?<strong>(.*?)</strong>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
				vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__watch'
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
			vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__embed'
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"downloadlist"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('download-url="(.*?)".*?<strong>(.*?)</strong>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
				vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__download'
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/search.php?keywords='+search
	IGDobAKtj4kPF5V(url,'search')
	return
# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࢨ")
def n1zxUlcAgR(EYMmnJAyxV,wNyZhHdvUeC3M):
	if   EYMmnJAyxV==l4DS8mnEjHhFMZ5YOe(u"࠹࠳࠱ऽ"): bPFto2wZdNYrClgBIEv60DJAzu = D0fjRsUkTnYHtvW()
	elif EYMmnJAyxV==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠳࠴࠳ा"): bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(wNyZhHdvUeC3M)
	elif EYMmnJAyxV==fgv5U2eRVaQqSiuGD(u"࠴࠵࠵ि"): bPFto2wZdNYrClgBIEv60DJAzu = xu4gXYWHh6BtKc2iNQ()
	elif EYMmnJAyxV==fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠵࠶࠷ी"): bPFto2wZdNYrClgBIEv60DJAzu = TUoeEDjtdB91v()
	elif EYMmnJAyxV==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠶࠷࠹ु"): bPFto2wZdNYrClgBIEv60DJAzu = RRykuN43DpMCEftVXIHFx5K(wNyZhHdvUeC3M)
	else: bPFto2wZdNYrClgBIEv60DJAzu = SmbNGskjMx
	return bPFto2wZdNYrClgBIEv60DJAzu
def RRykuN43DpMCEftVXIHFx5K(Lyp3BXZ05G):
	try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(Lyp3BXZ05G.decode(zSafwK0sDXdMN5JReniIQmrZxp))
	except: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(Lyp3BXZ05G)
	return
def AOk1T6KwciHrWU2MYJzZnEN(wNyZhHdvUeC3M):
	brh5aWRxQzn6YL8UDNOyK9SFGo(wNyZhHdvUeC3M,QSJFrwB3dMiyH2mTPKD9a,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡼࡩࡥࡧࡲࠫࢩ"))
	return
def TUoeEDjtdB91v():
	CtO9cFuULSm62PWToMlzN1 = fgv5U2eRVaQqSiuGD(u"࠭รั้หࠤส๊้ࠡำสฬ฼ࠦวๅใํำ๏๎ࠠฤ๊ࠣห้฻่หࠢไ๎ࠥอไๆ๊ๅ฽ࠥอไๆู็์อࠦหๆࠢฦฺ฿฽ฺࠠๆ์ࠤืืࠠศๆๅหห๋ษࠡษ็๎๊๐ๆࠡอ่ࠤศิสศำࠣࠦฯำๅ๋ๆ้้ࠣ็วหࠢไ๎ิ๐่ࠣࠢฮ้ࠥอฮหษิࠤิ่ษࠡษ็ูํืษ๊ࠡสาฯอั่๋ࠡ฽๋ࠥไโࠢสฺ่๎ัส๋ࠢฬ฾ี็ศࠢึ์ๆ๊ࠦษัฦࠤฬ๊สฮ็ํ่ࠬࢪ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ุࠧำํๆฮࠦสฮ็ํ่ࠥอไๆๆไหฯ࠭ࢫ"),CtO9cFuULSm62PWToMlzN1)
	return
def D0fjRsUkTnYHtvW():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨ࡮࡬ࡲࡰ࠭ࢬ"),eMypvI8XqHjYU02anWD9gsSrkt+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ฺࠩี๏่ษࠡฬะ้๏๊ࠠๆๆไหฯࠦวๅใํำ๏๎ࠧࢭ")+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"࠷࠸࠹ू"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(t4txivgXSUWBOlCakQmNDjf(u"ࠪࡰ࡮ࡴ࡫ࠨࢮ"),eMypvI8XqHjYU02anWD9gsSrkt+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫฯเ๊๋ำ้่ࠣอๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠫࢯ")+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"࠸࠹࠲ृ"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡲࡩ࡯࡭ࠪࢰ"),eMypvI8XqHjYU02anWD9gsSrkt+flDSRbv57PnV3(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࠬࢱ")+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"࠿࠹࠺࠻ॄ"))
	PVqiOpuox0Dt6I = Q2ZH0kKWVEBysiJNRj4h9zu5og()
	B9Py72d1iTWR6FtvuajsMIOm3z4 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.stat(PVqiOpuox0Dt6I).st_mtime
	l6ifO2ZNCResYtwnP0rD5S8oxac3y = []
	if IZhXMprxvAHqBEFkg0: HHzl8MeTo0xKcnO5I29Q = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(PVqiOpuox0Dt6I.encode(zSafwK0sDXdMN5JReniIQmrZxp))
	else: HHzl8MeTo0xKcnO5I29Q = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(PVqiOpuox0Dt6I.decode(zSafwK0sDXdMN5JReniIQmrZxp))
	for OT2twr6bkIVevaGfSPM1 in HHzl8MeTo0xKcnO5I29Q:
		if IZhXMprxvAHqBEFkg0: OT2twr6bkIVevaGfSPM1 = OT2twr6bkIVevaGfSPM1.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		if not OT2twr6bkIVevaGfSPM1.startswith(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡧ࡫࡯ࡩࡤ࠭ࢲ")): continue
		tabCHGMFY8Sx4VIne5lKJvUA6BNj02 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(PVqiOpuox0Dt6I,OT2twr6bkIVevaGfSPM1)
		B9Py72d1iTWR6FtvuajsMIOm3z4 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.getmtime(tabCHGMFY8Sx4VIne5lKJvUA6BNj02)
		l6ifO2ZNCResYtwnP0rD5S8oxac3y.append([OT2twr6bkIVevaGfSPM1,B9Py72d1iTWR6FtvuajsMIOm3z4])
	l6ifO2ZNCResYtwnP0rD5S8oxac3y = sorted(l6ifO2ZNCResYtwnP0rD5S8oxac3y,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: key[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	for OT2twr6bkIVevaGfSPM1,B9Py72d1iTWR6FtvuajsMIOm3z4 in l6ifO2ZNCResYtwnP0rD5S8oxac3y:
		if n7neb9KTv10FcU:
			try: OT2twr6bkIVevaGfSPM1 = OT2twr6bkIVevaGfSPM1.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			except: pass
			OT2twr6bkIVevaGfSPM1 = OT2twr6bkIVevaGfSPM1.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		tabCHGMFY8Sx4VIne5lKJvUA6BNj02 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(PVqiOpuox0Dt6I,OT2twr6bkIVevaGfSPM1)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj(X1mRwt2YJKgCLu9a67(u"ࠨࡸ࡬ࡨࡪࡵࠧࢳ"),OT2twr6bkIVevaGfSPM1,tabCHGMFY8Sx4VIne5lKJvUA6BNj02,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠳࠴࠳ॅ"))
	return
def Q2ZH0kKWVEBysiJNRj4h9zu5og():
	PVqiOpuox0Dt6I = llnG7jiQBYKhAeovbT.getSetting(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡤࡺ࠳ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬࢴ"))
	if PVqiOpuox0Dt6I: return PVqiOpuox0Dt6I
	llnG7jiQBYKhAeovbT.setSetting(QlTuvPbSpnjygBVW(u"ࠪࡥࡻ࠴ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭ࢵ"),iy1kK0BAJVLazhHpnZEqrYt9dOfW)
	return iy1kK0BAJVLazhHpnZEqrYt9dOfW
def xu4gXYWHh6BtKc2iNQ():
	PVqiOpuox0Dt6I = Q2ZH0kKWVEBysiJNRj4h9zu5og()
	vHSrYX7yfKOnB1DqezlxMTVZA5 = ttiZs4bKHFvugJj5z(flDSRbv57PnV3(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫࢶ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"๋ࠬใศ่ࠣฮำุ๊็่่ࠢๆอสࠡษ็ฮา๋๊ๅࠩࢷ"),l5JG7XwbOfo8DznU+PVqiOpuox0Dt6I+c7gxFyUCGm+I3cxjYaHhsrM7T4UX26klN(u"࠭࡜࡯࡞ࡱ๋ีอ่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะอๆๆ๊หࠥอๆหࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦส฻์ํีࠥอไๆๅส๊ࠥลࠧࢸ"))
	if vHSrYX7yfKOnB1DqezlxMTVZA5==YayJj10OGl(u"࠲ॆ"):
		sQ0tipGowBEZ = bboV3ruP5MYqCOdeBK1XnRJUcxv8(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠵े"),YayJj10OGl(u"ࠧๆๅส๊ࠥะอๆ์็ࠤ๊๊แศฬࠣห้็๊ะ์๋ࠫࢹ"),l4DS8mnEjHhFMZ5YOe(u"ࠨ࡮ࡲࡧࡦࡲࠧࢺ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4,PVqiOpuox0Dt6I)
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡦࡩࡳࡺࡥࡳࠩࢻ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"้่ࠪอๆࠡฬัึ๏์ࠠๆๆไหฯࠦวๅฬะ้๏๊ࠧࢼ"),l5JG7XwbOfo8DznU+PVqiOpuox0Dt6I+c7gxFyUCGm+t4txivgXSUWBOlCakQmNDjf(u"ࠫࡡࡴ࡜࡯้ำหࠥํ่ࠡษ็้่อๆࠡษ็ะิ๐ฯࠡๆอาื๐ๆࠡ็็ๅฬะࠠศๆไ๎ิ๐่ࠡษ็ฮ๏ࠦสฮ็็๋ฬࠦว็ฬࠣฬฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯࠤ࠳ࠦ็ๅࠢอี๏ีࠠศีอาิอๅ่ࠢหำ้อࠠๆ่ࠣห้๋ใศ่ࠣห้่ฯ๋็ࠣรࠬࢽ"))
		if oyNUHM3uQq==DJ6ugPjW9bX8I(u"࠴ै"):
			llnG7jiQBYKhAeovbT.setSetting(ulAxHwvzR9eTb5n(u"ࠬࡧࡶ࠯ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨࢾ"),sQ0tipGowBEZ)
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,I3cxjYaHhsrM7T4UX26klN(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࢿ"),ulAxHwvzR9eTb5n(u"ࠧห็ࠣฮ฿๐๊า่ࠢ็ฬ์ࠠหะี๎๋ࠦวๅ็็ๅฬะࠠศๆ่ั๊๊ษࠨࣀ"))
	return
def SIvBzVkdQYCWnlsN3wiT41cZqjOhp(wNyZhHdvUeC3M,J8J0A4lx7y9GDEBq=nbOFVEDkpT4BIR7Qq82yPmHeJU,website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+l4DS8mnEjHhFMZ5YOe(u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨࣁ")+wNyZhHdvUeC3M+flDSRbv57PnV3(u"ࠩࠣࡡࠬࣂ"))
	if not J8J0A4lx7y9GDEBq: J8J0A4lx7y9GDEBq = JoEms64VZ1ldaf9NYBgcKCFL(wNyZhHdvUeC3M)
	PVqiOpuox0Dt6I = Q2ZH0kKWVEBysiJNRj4h9zu5og()
	RM8ZdQkKxUFIDTz573 = Op47XGBbfiolxenLkTdyPrW6Z(SmbNGskjMx)
	OT2twr6bkIVevaGfSPM1 = RM8ZdQkKxUFIDTz573.replace(S3X6GcaiExOPtb,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡣࠬࣃ"))
	OT2twr6bkIVevaGfSPM1 = JABPVj6TrWOU29Xvmo(OT2twr6bkIVevaGfSPM1)
	OT2twr6bkIVevaGfSPM1 = Fo1SgXMsHk(u"ࠫ࡫࡯࡬ࡦࡡࠪࣄ")+str(int(sqeRK2tVw8))[-YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠸ॉ"):]+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡥࠧࣅ")+OT2twr6bkIVevaGfSPM1+J8J0A4lx7y9GDEBq
	b7P3hRIvWU5ZOdkMiGyCljqt = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(PVqiOpuox0Dt6I,OT2twr6bkIVevaGfSPM1)
	YeRr5GFOCqn9ufVy = {}
	YeRr5GFOCqn9ufVy[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨࣆ")] = nbOFVEDkpT4BIR7Qq82yPmHeJU
	YeRr5GFOCqn9ufVy[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡂࡥࡦࡩࡵࡺࠧࣇ")] = l4DS8mnEjHhFMZ5YOe(u"ࠨࠬ࠲࠮ࠬࣈ")
	wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࡦࡢ࡮ࡶࡩࠬࣉ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if fsQukcZeJ8YbozTXKEvS7h306DCA(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨ࣊") in wNyZhHdvUeC3M:
		plSscrVjkRviPwm,VLs4zv8ycboXT0UG7rk2fAj = wNyZhHdvUeC3M.rsplit(X60YQOADpkHBb31LiR5qUEKfM(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩ࣋"),X1mRwt2YJKgCLu9a67(u"࠶ॊ"))
		VLs4zv8ycboXT0UG7rk2fAj = VLs4zv8ycboXT0UG7rk2fAj.replace(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࢂࠧ࣌"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(z3sIGH8jmLYg(u"࠭ࠦࠨ࣍"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	else: plSscrVjkRviPwm,VLs4zv8ycboXT0UG7rk2fAj = wNyZhHdvUeC3M,None
	if not VLs4zv8ycboXT0UG7rk2fAj: VLs4zv8ycboXT0UG7rk2fAj = MdwGcQOsmlV6vKI73THrUY4()
	if VLs4zv8ycboXT0UG7rk2fAj: YeRr5GFOCqn9ufVy[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࣎")] = VLs4zv8ycboXT0UG7rk2fAj
	if IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡔࡨࡪࡪࡸࡥࡳ࠿࣏ࠪ") in plSscrVjkRviPwm: plSscrVjkRviPwm,JygZr6tXVAOGqPoF = plSscrVjkRviPwm.rsplit(l4DS8mnEjHhFMZ5YOe(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࡀ࣐ࠫ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠷ो"))
	else: plSscrVjkRviPwm,JygZr6tXVAOGqPoF = plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU
	plSscrVjkRviPwm = plSscrVjkRviPwm.strip(bYyKEjIuGQzoq3AR1(u"ࠪࢀ࣑ࠬ")).strip(fgv5U2eRVaQqSiuGD(u"࣒ࠫࠫ࠭")).strip(X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࢂ࣓ࠧ")).strip(tM24jD1gO0(u"࠭ࠦࠨࣔ"))
	JygZr6tXVAOGqPoF = JygZr6tXVAOGqPoF.replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡽࠩࣕ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࠨࠪࣖ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if JygZr6tXVAOGqPoF:	YeRr5GFOCqn9ufVy[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࣗ")] = JygZr6tXVAOGqPoF
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+z3sIGH8jmLYg(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫࣘ")+plSscrVjkRviPwm+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࠥࡣࠠࠡࠢࡋࡩࡦࡪࡥࡳࡵ࠽ࠤࡠࠦࠧࣙ")+str(YeRr5GFOCqn9ufVy)+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬࣚ")+b7P3hRIvWU5ZOdkMiGyCljqt+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࠠ࡞ࠩࣛ"))
	L9iyPRtCwK4DUmJYBsE = ulAxHwvzR9eTb5n(u"࠱࠱࠴࠷ौ")*ulAxHwvzR9eTb5n(u"࠱࠱࠴࠷ौ")
	SXiohpy4OnYd3sgexZt9WlR8 = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠱्")
	try:
		GCc0fujSPJ9w7sqmt4xNgdW1loMVnp =	RarSo2nTfwU0WEGK.getInfoLabel(SSvu1CZjTW7FcloNqD(u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࠪࣜ"))
		GCc0fujSPJ9w7sqmt4xNgdW1loMVnp = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠨ࡞ࡧ࠯ࠬࣝ"),GCc0fujSPJ9w7sqmt4xNgdW1loMVnp)
		SXiohpy4OnYd3sgexZt9WlR8 = int(GCc0fujSPJ9w7sqmt4xNgdW1loMVnp[f4fTutDOEwUeIoPLRQ])
	except: pass
	if not SXiohpy4OnYd3sgexZt9WlR8:
		try:
			NBnmljVSeXg = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.statvfs(PVqiOpuox0Dt6I)
			SXiohpy4OnYd3sgexZt9WlR8 = NBnmljVSeXg.f_frsize*NBnmljVSeXg.f_bavail//L9iyPRtCwK4DUmJYBsE
		except: pass
	if not SXiohpy4OnYd3sgexZt9WlR8:
		try:
			NBnmljVSeXg = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.fstatvfs(PVqiOpuox0Dt6I)
			SXiohpy4OnYd3sgexZt9WlR8 = NBnmljVSeXg.f_frsize*NBnmljVSeXg.f_bavail//L9iyPRtCwK4DUmJYBsE
		except: pass
	if not SXiohpy4OnYd3sgexZt9WlR8:
		try:
			import shutil as R3TukeKbcP
			DfiBp9Te1CwXAb5zQsOh,aCM1brTwtqfhHcix7EkoUeyDmAdY9u,L0Up2dhAtouemkHyZ = R3TukeKbcP.disk_usage(PVqiOpuox0Dt6I)
			SXiohpy4OnYd3sgexZt9WlR8 = L0Up2dhAtouemkHyZ//L9iyPRtCwK4DUmJYBsE
		except: pass
	if not SXiohpy4OnYd3sgexZt9WlR8:
		r31rWd0qVCzeNapuFjwZg8scSIi5(X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡵ࡭࡬࡮ࡴࠨࣞ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ุ้ࠪออสࠢส่ฯิา๋่้ࠣัํ่ๅหࠪࣟ"),Fo1SgXMsHk(u"้๊ࠫริใࠣห้ฮั็ษ่ะࠥเ๊าࠢๅหิืࠠฤ่ࠣ๎าีฯࠡ็ๅำฬืࠠๆีสัฮࠦวๅฬัึ๏์ࠠศๆไหึเษࠡใํࠤัํวำๅࠣ์฾๊๊่ࠢไห๋ࠦสฮ็ํ่ࠥอไโ์า๎ํํวหࠢ็๊ࠥ๐ูๆๆࠣ฽๋ีใࠡว็ํࠥษๆࠡ์ๅ์๊ࠦๅษำ่ะ๏ࠦศา่ส้ัࠦใ้ัํࠤอำไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦไศ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯࠦโะࠢํือฮࠠศ็อ่ฬวࠠอ้สึ่ࠦศศๆ่่ๆอส๊๊ࠡิฬࠦแ๋้ࠣา฼๎ัสࠢ฼่๎ูࠦๆๆࠣะ์อาไࠢหูํืษࠡืะ๎าฯ้ࠠๆ๊ิฬࠦวๅีหฬ่ࠥวๆࠢส่๊ฮัๆฮ้ࠣษ่สศࠢห้๋฿ࠠศๆหี๋อๅอ่๊ࠢࠥะอๆ์็ࠤฬ๊แ๋ัํ์์อสࠨ࣠"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ࣡"))
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bYyKEjIuGQzoq3AR1(u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧ࣢"))
		return SmbNGskjMx
	if J8J0A4lx7y9GDEBq==l4DS8mnEjHhFMZ5YOe(u"ࠧ࠯࡯࠶ࡹ࠽ࣣ࠭"):
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = mmAWFnZUkQ3HowdxRtCN9(plSscrVjkRviPwm,YeRr5GFOCqn9ufVy)
		if len(bbKoeBcirVfzwAqZdQUFDSX)==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠲ॎ"):
			SSVCGE0bOfW1w9u52yvBxocNeP(bnI4kmPtrW7yFEhljXOCq9(u"ࠨใื่ࠥ็๊ࠡวํะฬีࠠๆๆไࠤฬ๊สฮ็ํ่ࠬࣤ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			return SmbNGskjMx
		elif len(bbKoeBcirVfzwAqZdQUFDSX)==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠴ॏ"): bCiGxXzDkH = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠴ॐ")
		elif len(bbKoeBcirVfzwAqZdQUFDSX)>yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠶॑"):
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr(ulAxHwvzR9eTb5n(u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮࠧࣥ"), bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH == -usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠷॒") :
				SSVCGE0bOfW1w9u52yvBxocNeP(Fo1SgXMsHk(u"ࠪฮ๊ࠦลๅ฼สลࠥอไหฯ่๎้ࣦ࠭"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				return SmbNGskjMx
		plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	in9MwQtvjXzG = X1mRwt2YJKgCLu9a67(u"࠰॓")
	import requests as SiB7OvlwTJKzdEorLDefAGHF
	if J8J0A4lx7y9GDEBq==I3cxjYaHhsrM7T4UX26klN(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪࣧ"):
		b7P3hRIvWU5ZOdkMiGyCljqt = b7P3hRIvWU5ZOdkMiGyCljqt.rsplit(l4DS8mnEjHhFMZ5YOe(u"ࠬ࠴࡭࠴ࡷ࠻ࠫࣨ"))[f4fTutDOEwUeIoPLRQ]+z3sIGH8jmLYg(u"࠭࠮࡮ࡲ࠷ࣩࠫ")
		BTxl2eLIqSzUk = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡈࡇࡗࠫ࣪"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆ࠰ࡈࡔ࡝ࡎࡍࡑࡄࡈࡤ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ࣫"))
		BhsFwQGtxXfqYgeVI5z839EHvybr = BTxl2eLIqSzUk.content
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࠦࡉ࡝࡚ࡉࡏࡈ࠽࠲࠯ࡅ࡛࡝ࡰ࡟ࡶࡢ࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠪ࣬"),BhsFwQGtxXfqYgeVI5z839EHvybr+IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡠࡳࡢࡲࠨ࣭"),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not rU02bCJFWZDfVuhtMgBOyQi5P:
			fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࠥࠦࠠࡕࡪࡨࠤࡲ࠹ࡵ࠹ࠢࡩ࡭ࡱ࡫ࠠࡥ࡫ࡧࠤࡳࡵࡴࠡࡪࡤࡺࡪࠦࡴࡩࡧࠣࡶࡪࡷࡵࡪࡴࡨࡨࠥࡲࡩ࡯࡭ࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠ࣮ࠦࠧ")+plSscrVjkRviPwm+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࠦ࡝ࠨ࣯"))
			return SmbNGskjMx
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = rU02bCJFWZDfVuhtMgBOyQi5P[f4fTutDOEwUeIoPLRQ]
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.startswith(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡨࡵࡶࡳࣰࠫ")):
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.startswith(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧ࠰࠱ࣱࠪ")): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = plSscrVjkRviPwm.split(SSvu1CZjTW7FcloNqD(u"ࠨ࠼ࣲࠪ"),tM24jD1gO0(u"࠲॔"))[f4fTutDOEwUeIoPLRQ]+X1mRwt2YJKgCLu9a67(u"ࠩ࠽ࠫࣳ")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			elif grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.startswith(ulAxHwvzR9eTb5n(u"ࠪ࠳ࠬࣴ")): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡺࡸ࡬ࠨࣵ"))+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = plSscrVjkRviPwm.rsplit(Fo1SgXMsHk(u"ࠬ࠵ࣶࠧ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠳ॕ"))[f4fTutDOEwUeIoPLRQ]+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭࠯ࠨࣷ")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		BTxl2eLIqSzUk = SiB7OvlwTJKzdEorLDefAGHF.request(QlTuvPbSpnjygBVW(u"ࠧࡈࡇࡗࠫࣸ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,headers=YeRr5GFOCqn9ufVy,verify=SmbNGskjMx)
		sVxSuvIj6tO3kR8JnP2ldp = BTxl2eLIqSzUk.content
		BX89rMkmW5adNzpvqeCfT4bF7g = len(sVxSuvIj6tO3kR8JnP2ldp)
		kkDsjSHALX = len(rU02bCJFWZDfVuhtMgBOyQi5P)
		in9MwQtvjXzG = BX89rMkmW5adNzpvqeCfT4bF7g*kkDsjSHALX
	else:
		BX89rMkmW5adNzpvqeCfT4bF7g = t4txivgXSUWBOlCakQmNDjf(u"࠴ॖ")*L9iyPRtCwK4DUmJYBsE
		BTxl2eLIqSzUk = SiB7OvlwTJKzdEorLDefAGHF.request(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡉࡈࡘࣹࠬ"),plSscrVjkRviPwm,headers=YeRr5GFOCqn9ufVy,verify=SmbNGskjMx,stream=Ag9l6cw3EBqP8HsQuGMizfOtr4)
		if QlTuvPbSpnjygBVW(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࣺࠪ") in BTxl2eLIqSzUk.headers: in9MwQtvjXzG = int(BTxl2eLIqSzUk.headers[flDSRbv57PnV3(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡑ࡫࡮ࡨࡶ࡫ࠫࣻ")])
		kkDsjSHALX = int(in9MwQtvjXzG//BX89rMkmW5adNzpvqeCfT4bF7g)
	hnr8Rsl7iIbeLjYwPJBGS = int(in9MwQtvjXzG//L9iyPRtCwK4DUmJYBsE)+QlTuvPbSpnjygBVW(u"࠵ॗ")
	if in9MwQtvjXzG<fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠷࠷࠰࠱࠲क़"):
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+DJ6ugPjW9bX8I(u"ࠫࠥࠦࠠࡗ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡵࡱࡲࠤࡸࡳࡡ࡭࡮ࠣࡳࡷࠦࡩࡵࠢ࡬ࡷࠥࡳ࠳ࡶ࠺ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭ࣼ")+plSscrVjkRviPwm+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩࣽ")+str(hnr8Rsl7iIbeLjYwPJBGS)+X1mRwt2YJKgCLu9a67(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬࣾ")+str(SXiohpy4OnYd3sgexZt9WlR8)+flDSRbv57PnV3(u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡈ࡬ࡰࡪࡀࠠ࡜ࠢࠪࣿ")+b7P3hRIvWU5ZOdkMiGyCljqt+bnI4kmPtrW7yFEhljXOCq9(u"ࠨࠢࡠࠫऀ"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬँ"),X1mRwt2YJKgCLu9a67(u"ࠪๅู๊ࠠโ์้ࠣ฾ืแสࠢะะ๊ࠦๅๅใࠣห้็๊ะ์๋ࠤศ๎ࠠศๆ่่ๆࠦี฻์ิࠤัีว๊ࠡ็๋ีอࠠๅษࠣ๎๊้ๆࠡๆ็ฬึ์วๆฮࠣฮา๋๊ๅ๊ࠢิฬࠦวๅ็็ๅࠬं"))
		return SmbNGskjMx
	sA34IqkKSaw = X60YQOADpkHBb31LiR5qUEKfM(u"࠺࠰࠱ख़")
	kKjL5vsuDplg0 = SXiohpy4OnYd3sgexZt9WlR8-hnr8Rsl7iIbeLjYwPJBGS
	if kKjL5vsuDplg0<sA34IqkKSaw:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࠥࠦࠠࡏࡱࡷࠤࡪࡴ࡯ࡶࡩ࡫ࠤࡩ࡯ࡳ࡬ࠢࡶࡴࡦࡩࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪः")+plSscrVjkRviPwm+SSvu1CZjTW7FcloNqD(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩऄ")+str(hnr8Rsl7iIbeLjYwPJBGS)+z3sIGH8jmLYg(u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡂࡸࡤ࡭ࡱࡧࡢ࡭ࡧࠣࡷ࡮ࢀࡥ࠻ࠢ࡞ࠤࠬअ")+str(SXiohpy4OnYd3sgexZt9WlR8)+Fo1SgXMsHk(u"ࠧࠡࡏࡅࠤ࠲ࠦࠧआ")+str(sA34IqkKSaw)+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫइ")+b7P3hRIvWU5ZOdkMiGyCljqt+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࠣࡡࠬई"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪउ"),Fo1SgXMsHk(u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪऊ")+str(hnr8Rsl7iIbeLjYwPJBGS)+UpQ56M0dO1N9xIvVegy(u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫऋ")+str(SXiohpy4OnYd3sgexZt9WlR8)+fgv5U2eRVaQqSiuGD(u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦลษไสลࠥ࠭ऌ")+str(sA34IqkKSaw)+qrjy8LuKVPNYdbSvzh(u"ࠧࠡ็ํ฾ฬฮว๋ฬࠣๅฬืฺสࠢาหห๋ว๊๊ࠡิฬࠦๅฺ่ส๋ࠥษๆࠡฮ๊หื้ࠠๅษࠣฮําฯࠡใํ๋๋ࠥำศฯฬࠤ่อแ๋ห่ࠣฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษࠩऍ"))
		return SmbNGskjMx
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(l4DS8mnEjHhFMZ5YOe(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨऎ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"๊่ࠩࠥะั๋ัࠣฮา๋๊ๅࠢส่๊๊แࠡมࠪए"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪห้๋ไโࠢส่๊฽ไ้สࠣัั๋็ࠡฬๅี๏ฮวࠡࠩऐ")+str(hnr8Rsl7iIbeLjYwPJBGS)+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"๋๊ࠫࠥ฻ษหห๏ะ้ࠠฮ๊หื้ࠠโ์๊ࠤู๊วฮหࠣๅฬืฺสࠢอๆึ๐ศศࠢࠪऑ")+str(SXiohpy4OnYd3sgexZt9WlR8)+t4txivgXSUWBOlCakQmNDjf(u"ࠬࠦๅ๋฼สฬฬ๐ส๊๊ࠡิฬࠦวๅ็็ๅ่ࠥฯࠡ์ะฮฬาࠠษ฻ูࠤฬ๊่ใฬ่้ࠣะอๆ์็ࠤ๊์ࠠศๆศ๊ฯืๆหࠢศ่๎ࠦฬ่ษี็ࠥ࠴่ࠠๆࠣห๋ะࠠๆฬฦ็ิ่ࠦหำํำࠥอไศีอ้ึอัࠡสอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦฟࠨऒ"))
	if oyNUHM3uQq!=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠱ग़"):
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"࠭สๆࠢศ่฿อมࠡ฻่่๏ฯࠠหฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋ࠫओ"))
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬ࡦࡦࠣࡸ࡭࡫ࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡲࡪࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩऔ")+plSscrVjkRviPwm+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨक")+b7P3hRIvWU5ZOdkMiGyCljqt+qrjy8LuKVPNYdbSvzh(u"ࠩࠣࡡࠬख"))
		return SmbNGskjMx
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࠤࠥࠦࡄࡰࡹࡱࡰࡴࡧࡤࠡࡵࡷࡥࡷࡺࡥࡥࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࡲࡹࠨग"))
	kXhEFvVqefGtabMy9z0YlpBi = LMSZwD0IRAziTh()
	kXhEFvVqefGtabMy9z0YlpBi.create(b7P3hRIvWU5ZOdkMiGyCljqt,bYyKEjIuGQzoq3AR1(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬघ"))
	I6XNwymg5Y = Ag9l6cw3EBqP8HsQuGMizfOtr4
	BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
	if not QQ3hd2tR8s.ggSlJwTytkUHBA2dz:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨङ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠭ศิสหࠤ฾ีๅࠡษ็ฮอืูࠡฬ่ࠤสฺ๊ศรࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧच"))
		return SmbNGskjMx
	if IZhXMprxvAHqBEFkg0: nTOU6Iu7oFf = open(b7P3hRIvWU5ZOdkMiGyCljqt,flDSRbv57PnV3(u"ࠧࡸࡤࠪछ"))
	else: nTOU6Iu7oFf = open(b7P3hRIvWU5ZOdkMiGyCljqt.decode(zSafwK0sDXdMN5JReniIQmrZxp),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡹࡥࠫज"))
	if J8J0A4lx7y9GDEBq==l4DS8mnEjHhFMZ5YOe(u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨझ"):
		for HT4fGXqv8hEcKsJ in range(DJ6ugPjW9bX8I(u"࠲ज़"),kkDsjSHALX+DJ6ugPjW9bX8I(u"࠲ज़")):
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = rU02bCJFWZDfVuhtMgBOyQi5P[HT4fGXqv8hEcKsJ-wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠳ड़")]
			if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.startswith(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪ࡬ࡹࡺࡰࠨञ")):
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.startswith(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࠴࠵ࠧट")): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = plSscrVjkRviPwm.split(Fo1SgXMsHk(u"ࠬࡀࠧठ"),X1mRwt2YJKgCLu9a67(u"࠴ढ़"))[f4fTutDOEwUeIoPLRQ]+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭࠺ࠨड")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				elif grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.startswith(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࠰ࠩढ")): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡷࡵࡰࠬण"))+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = plSscrVjkRviPwm.rsplit(SSvu1CZjTW7FcloNqD(u"ࠩ࠲ࠫत"),Fo1SgXMsHk(u"࠵फ़"))[f4fTutDOEwUeIoPLRQ]+ulAxHwvzR9eTb5n(u"ࠪ࠳ࠬथ")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			BTxl2eLIqSzUk = SiB7OvlwTJKzdEorLDefAGHF.request(flDSRbv57PnV3(u"ࠫࡌࡋࡔࠨद"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,headers=YeRr5GFOCqn9ufVy,verify=SmbNGskjMx)
			sVxSuvIj6tO3kR8JnP2ldp = BTxl2eLIqSzUk.content
			BTxl2eLIqSzUk.close()
			nTOU6Iu7oFf.write(sVxSuvIj6tO3kR8JnP2ldp)
			m5dGtOp8ZrANYvafElezRM9Tn7 = lQMuw1PvVpAk.time()
			xArVhtDn8pwkP7 = m5dGtOp8ZrANYvafElezRM9Tn7-BfM7ldYzjy5qVPoeJuN2QEpL9
			K5iR8vDuMfGPpUJ91TIXhzj = xArVhtDn8pwkP7//HT4fGXqv8hEcKsJ
			VshpQZCMBc1IyD5S0KwPj7v = K5iR8vDuMfGPpUJ91TIXhzj*(kkDsjSHALX+q4izXt0sjIQSZcHVAf3EmKRbx(u"࠶य़"))
			swofCcHX7KTie3PyVERO2huYIqSt = VshpQZCMBc1IyD5S0KwPj7v-xArVhtDn8pwkP7
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,int(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠱࠱࠲ॡ")*HT4fGXqv8hEcKsJ//(kkDsjSHALX+tM24jD1gO0(u"࠷ॠ"))),bYyKEjIuGQzoq3AR1(u"ࠬอไิูิࠤๆ๎โ้๋ࠡࠤ๊้ว็ࠢอาื๐ๆࠡ็็ๅࠥอไโ์า๎ํ࠭ध"),IINBvuxkCSJrO1Q0UyngdLi(u"࠭ฬๅส้้ࠣ็ࠠศๆไ๎ิ๐่࠻࠯ࠣห้าายࠢิๆ๊࠭न"),str(HT4fGXqv8hEcKsJ*BX89rMkmW5adNzpvqeCfT4bF7g//L9iyPRtCwK4DUmJYBsE)+fgv5U2eRVaQqSiuGD(u"ࠧ࠰ࠩऩ")+str(hnr8Rsl7iIbeLjYwPJBGS)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࠢࡐࡆ๊ࠥࠦࠠࠡๅฮ๋ࠥสษไํ࠾ࠥ࠭प")+lQMuw1PvVpAk.strftime(YayJj10OGl(u"ࠤࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦफ"),lQMuw1PvVpAk.gmtime(swofCcHX7KTie3PyVERO2huYIqSt))+QlTuvPbSpnjygBVW(u"ࠪࠤๅ࠭ब"))
			if kXhEFvVqefGtabMy9z0YlpBi.iscanceled():
				I6XNwymg5Y = SmbNGskjMx
				break
	else:
		HT4fGXqv8hEcKsJ = l4DS8mnEjHhFMZ5YOe(u"࠱ॢ")
		for sVxSuvIj6tO3kR8JnP2ldp in BTxl2eLIqSzUk.iter_content(chunk_size=BX89rMkmW5adNzpvqeCfT4bF7g):
			nTOU6Iu7oFf.write(sVxSuvIj6tO3kR8JnP2ldp)
			HT4fGXqv8hEcKsJ = HT4fGXqv8hEcKsJ+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠳ॣ")
			m5dGtOp8ZrANYvafElezRM9Tn7 = lQMuw1PvVpAk.time()
			xArVhtDn8pwkP7 = m5dGtOp8ZrANYvafElezRM9Tn7-BfM7ldYzjy5qVPoeJuN2QEpL9
			K5iR8vDuMfGPpUJ91TIXhzj = xArVhtDn8pwkP7/HT4fGXqv8hEcKsJ
			VshpQZCMBc1IyD5S0KwPj7v = K5iR8vDuMfGPpUJ91TIXhzj*(kkDsjSHALX+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠴।"))
			swofCcHX7KTie3PyVERO2huYIqSt = VshpQZCMBc1IyD5S0KwPj7v-xArVhtDn8pwkP7
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,int(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠶࠶࠰०")*HT4fGXqv8hEcKsJ/(kkDsjSHALX+bnI4kmPtrW7yFEhljXOCq9(u"࠵॥"))),UpQ56M0dO1N9xIvVegy(u"ࠫฬ๊ำุำࠣๅํ่่๊้่ࠠࠣอๆࠡฬัึ๏์ࠠๆๆไࠤฬ๊แ๋ัํ์ࠬभ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬาไษ่่ࠢๆࠦวๅใํำ๏๎࠺࠮ࠢส่ัุมࠡำๅ้ࠬम"),str(HT4fGXqv8hEcKsJ*BX89rMkmW5adNzpvqeCfT4bF7g//L9iyPRtCwK4DUmJYBsE)+qrjy8LuKVPNYdbSvzh(u"࠭࠯ࠨय")+str(hnr8Rsl7iIbeLjYwPJBGS)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࠡࡏࡅࠤ้ࠥࠦࠠไอࠤ๊ะศใ์࠽ࠤࠬर")+lQMuw1PvVpAk.strftime(t4txivgXSUWBOlCakQmNDjf(u"ࠣࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥऱ"),lQMuw1PvVpAk.gmtime(swofCcHX7KTie3PyVERO2huYIqSt))+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠣไࠬल"))
			if kXhEFvVqefGtabMy9z0YlpBi.iscanceled():
				I6XNwymg5Y = SmbNGskjMx
				break
		BTxl2eLIqSzUk.close()
	nTOU6Iu7oFf.close()
	kXhEFvVqefGtabMy9z0YlpBi.close()
	if not I6XNwymg5Y:
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+X1mRwt2YJKgCLu9a67(u"ࠪࠤࠥࠦࡕࡴࡧࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩ࠵ࡩ࡯ࡶࡨࡶࡷࡻࡰࡵࡧࡧࠤࡹ࡮ࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡴࡷࡵࡣࡦࡵࡶࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧळ")+plSscrVjkRviPwm+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫऴ")+b7P3hRIvWU5ZOdkMiGyCljqt+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࠦ࡝ࠨव"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩश"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧษฯึฬࠥ฽ไษๅࠣฮ๊ࠦลๅ฼สลࠥ฿ๅๅ์ฬࠤฯำๅ๋ๆ้้ࠣ็ࠠศๆไ๎ิ๐่ࠨष"))
		return Ag9l6cw3EBqP8HsQuGMizfOtr4
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+fgv5U2eRVaQqSiuGD(u"ࠨࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࡨࡨࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭࡮ࡼࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧस")+plSscrVjkRviPwm+Fo1SgXMsHk(u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩह")+b7P3hRIvWU5ZOdkMiGyCljqt+Fo1SgXMsHk(u"ࠪࠤࡢ࠭ऺ"))
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧऻ"),DJ6ugPjW9bX8I(u"ࠬะๅࠡฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥฮๆอษะ़ࠫ"))
	return Ag9l6cw3EBqP8HsQuGMizfOtr4
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'GLOBALSEARCH'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_GLS_'
def n1zxUlcAgR(EYMmnJAyxV,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,ohpwd6UumaecE3IWV8lAv0):
	if   EYMmnJAyxV==540: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif EYMmnJAyxV==541: bPFto2wZdNYrClgBIEv60DJAzu = bcdm6puk0ysJXFgCloh7EDfUv(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==542: bPFto2wZdNYrClgBIEv60DJAzu = IvrgPGo8Be(J1rvN7I8eLXuS54mZ6lnUjg,wNyZhHdvUeC3M,ohpwd6UumaecE3IWV8lAv0)
	elif EYMmnJAyxV==543: bPFto2wZdNYrClgBIEv60DJAzu = A9vlaj5oR0YXTJuFIyEBV()
	elif EYMmnJAyxV==548: bPFto2wZdNYrClgBIEv60DJAzu = xyurzMKCVJQ0(wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==549: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(J1rvN7I8eLXuS54mZ6lnUjg)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','بحث جديد لجميع المواقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,549)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','كيف يعمل بحث جميع المواقع','',543)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'==== كلمات البحث المخزنة ===='+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	WW1Gr4pauClz = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'dict','GLOBALSEARCH_SPLITTED_ALL')
	if WW1Gr4pauClz:
		WW1Gr4pauClz = WW1Gr4pauClz['__SEQUENCED_COLUMNS__']
		for B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ in reversed(WW1Gr4pauClz):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,nbOFVEDkpT4BIR7Qq82yPmHeJU,549,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ)
	return
def cvZoNw4F0fRjYaMuP5CVrE(B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ):
	if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ:
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = dR75Vq2gprfHmUcNhG()
		if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ: return
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ.lower()
	KYPwjRcdHJ0 = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ.replace(TbufdXZL9Ml72WmGcpQ5FAgBYKqa,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	kXdKqMmtEf2bcZPi(KYPwjRcdHJ0,'_ALL',True)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','بحث جماعي للمواقع - '+KYPwjRcdHJ0,'search_sites_all',542,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','بحث منفرد للمواقع - '+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,541,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','نتائج البحث مفصلة - '+KYPwjRcdHJ0,'opened_sites_all',542,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','نتائج البحث مقسمة - '+KYPwjRcdHJ0,'listed_sites_all',542,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	return
def kXdKqMmtEf2bcZPi(UvIxo4FlqbkDJA,lY3XQyzBNW,Mk8L5zB4cgWmAQ7fCeHN6Gr0oTY):
	if lY3XQyzBNW=='_ALL': Y7K6m8qtkCunWF2XfcIdVgv4 = '_GLS_'
	elif lY3XQyzBNW=='_GOOGLE': Y7K6m8qtkCunWF2XfcIdVgv4 = '_GOS_'
	RQDmFsW52AKNvPB = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,UvIxo4FlqbkDJA)
	RRaSIGPbEnZXWg7DtNrJOkcmMz = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,Y7K6m8qtkCunWF2XfcIdVgv4+UvIxo4FlqbkDJA)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,UvIxo4FlqbkDJA)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,Y7K6m8qtkCunWF2XfcIdVgv4+UvIxo4FlqbkDJA)
	YYEsQhJD8OW3a = RQDmFsW52AKNvPB+RRaSIGPbEnZXWg7DtNrJOkcmMz
	if YYEsQhJD8OW3a and Mk8L5zB4cgWmAQ7fCeHN6Gr0oTY: UvIxo4FlqbkDJA = Y7K6m8qtkCunWF2XfcIdVgv4+UvIxo4FlqbkDJA
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,UvIxo4FlqbkDJA,YYEsQhJD8OW3a,rXKp4uqLMW3v)
	return
def QLUli3kgWhOq(lY3XQyzBNW):
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هل تريد مسح جميع كلمات البحث المخزنة في البرنامج ؟!!')
	if oyNUHM3uQq!=1: return
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_SPLITTED'+lY3XQyzBNW)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_DETAILED'+lY3XQyzBNW)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_DIVIDED'+lY3XQyzBNW)
	if lY3XQyzBNW=='_GOOGLE': uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GOOGLESEARCH_RESULTS')
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم بنجاح مسح جميع كلمات البحث المخزنة في البرنامج')
	return
def IvrgPGo8Be(NckbIxftmrjUh0KYn,t4DP3mp7Jq62bhE,UFS70f3H5oyVAp96bJdhwsmB84W=nbOFVEDkpT4BIR7Qq82yPmHeJU,jjkGz0trAqQu1lMNDvy8IH7UCWdBeO=dx4FLKQzHp3Rih7fnoackqbN,hhUdBNHZYlwjIACRiukKaO3sg={}):
	qb1hrzIR5gBCofF37,VrJzjgscSt8XuykMqxGdlC9fBZw0,N3oFvhIKwkPdq,XP5pBa3fhgITSd0WtqNDuw1U7Y2,EERBxagV8muspkbzSvi = [],{},{},{},{}
	if '_all' in t4DP3mp7Jq62bhE: lY3XQyzBNW,EYsUAzvhI6FwSM9uiGm2c,Y7K6m8qtkCunWF2XfcIdVgv4 = '_ALL','_all','_GLS_'
	elif '_google' in t4DP3mp7Jq62bhE: lY3XQyzBNW,EYsUAzvhI6FwSM9uiGm2c,Y7K6m8qtkCunWF2XfcIdVgv4 = '_GOOGLE','_google','_GOS_'
	if t4DP3mp7Jq62bhE in ['listed_sites'+EYsUAzvhI6FwSM9uiGm2c,'opened_sites'+EYsUAzvhI6FwSM9uiGm2c,'closed_sites'+EYsUAzvhI6FwSM9uiGm2c]:
		if t4DP3mp7Jq62bhE=='listed_sites'+EYsUAzvhI6FwSM9uiGm2c: qb1hrzIR5gBCofF37 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,Y7K6m8qtkCunWF2XfcIdVgv4+NckbIxftmrjUh0KYn)
		elif t4DP3mp7Jq62bhE=='opened_sites'+EYsUAzvhI6FwSM9uiGm2c: qb1hrzIR5gBCofF37 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_DETAILED'+lY3XQyzBNW,NckbIxftmrjUh0KYn)
		elif t4DP3mp7Jq62bhE=='closed_sites'+EYsUAzvhI6FwSM9uiGm2c: qb1hrzIR5gBCofF37 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_DIVIDED'+lY3XQyzBNW,(UFS70f3H5oyVAp96bJdhwsmB84W,NckbIxftmrjUh0KYn))
	if not qb1hrzIR5gBCofF37:
		G8CImB4K9pN3OhHT = 'هذا البحث غير موجود في كاش البرنامج \n\n\n'
		dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = 'هل تريد الآن البحث في جميع المواقع عن \n "'+l5JG7XwbOfo8DznU+S3X6GcaiExOPtb+NckbIxftmrjUh0KYn+S3X6GcaiExOPtb+c7gxFyUCGm+'" \n علما أن هذا البحث قد يحتاج بعض الوقت'
		if t4DP3mp7Jq62bhE=='search_sites'+EYsUAzvhI6FwSM9uiGm2c: CtO9cFuULSm62PWToMlzN1 = dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs
		else: CtO9cFuULSm62PWToMlzN1 = G8CImB4K9pN3OhHT+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج',CtO9cFuULSm62PWToMlzN1)
		if oyNUHM3uQq!=1: return
		Zb4NIBy16VvWF(False,False,False)
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Search For: [ '+NckbIxftmrjUh0KYn+' ]')
		IFLG0YOr8SuztT14qc = 1
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in jjkGz0trAqQu1lMNDvy8IH7UCWdBeO:
			p8qs3Q1hIef2ZRiJBFGcDUKy = hhUdBNHZYlwjIACRiukKaO3sg[HMPtOcVoJiXCu8z0nesDWYkIl9ER] if hhUdBNHZYlwjIACRiukKaO3sg else NckbIxftmrjUh0KYn
			try: UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			except: continue
			VrJzjgscSt8XuykMqxGdlC9fBZw0[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = []
			Hg9iNXSxJobPBr = '_NODIALOGS_'
			if '-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER: Hg9iNXSxJobPBr = Hg9iNXSxJobPBr+'_REMEMBERRESULTS__'+HMPtOcVoJiXCu8z0nesDWYkIl9ER+'_'
			if IFLG0YOr8SuztT14qc:
				lQMuw1PvVpAk.sleep(0.75)
				EERBxagV8muspkbzSvi[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = eb6R0h1Fjl.Thread(target=Nwj2WURK7qbY6coiBdMDzuS,args=(p8qs3Q1hIef2ZRiJBFGcDUKy+Hg9iNXSxJobPBr,))
				EERBxagV8muspkbzSvi[HMPtOcVoJiXCu8z0nesDWYkIl9ER].start()
			else: Nwj2WURK7qbY6coiBdMDzuS(p8qs3Q1hIef2ZRiJBFGcDUKy+Hg9iNXSxJobPBr)
			SSVCGE0bOfW1w9u52yvBxocNeP(wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER),nbOFVEDkpT4BIR7Qq82yPmHeJU,lQMuw1PvVpAk=1000)
		if IFLG0YOr8SuztT14qc:
			lQMuw1PvVpAk.sleep(2)
			for HMPtOcVoJiXCu8z0nesDWYkIl9ER in jjkGz0trAqQu1lMNDvy8IH7UCWdBeO: EERBxagV8muspkbzSvi[HMPtOcVoJiXCu8z0nesDWYkIl9ER].join(10)
			lQMuw1PvVpAk.sleep(2)
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in jjkGz0trAqQu1lMNDvy8IH7UCWdBeO:
			try: UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			except: continue
			for rqQNcnS9WF6AeXbI15od2H in LvJuOzMqk6WlP971eoGpUQ8:
				iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = rqQNcnS9WF6AeXbI15od2H
				if fxUgL78lj13rQ4W6wZOE in xbfwC5hkXLvsJa8PReOS9AyU1z:
					if 'IPTV-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER and (239>=EYMmnJAyxV>=230 or 289>=EYMmnJAyxV>=280):
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['IPTV-LIVE']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['IPTV-MOVIES']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['IPTV-SERIES']: continue
						if 'صفحة' not in xbfwC5hkXLvsJa8PReOS9AyU1z:
							if   iiyAEbQ5f80=='live': HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IPTV-LIVE'
							elif iiyAEbQ5f80=='video': HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IPTV-MOVIES'
							elif iiyAEbQ5f80=='folder': HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IPTV-SERIES'
						else:
							if   'LIVE' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IPTV-LIVE'
							elif 'MOVIES' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IPTV-MOVIES'
							elif 'SERIES' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IPTV-SERIES'
					elif 'M3U-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER and 729>=EYMmnJAyxV>=710:
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['M3U-LIVE']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['M3U-MOVIES']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['M3U-SERIES']: continue
						if 'صفحة' not in xbfwC5hkXLvsJa8PReOS9AyU1z:
							if   iiyAEbQ5f80=='live': HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'M3U-LIVE'
							elif iiyAEbQ5f80=='video': HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'M3U-MOVIES'
							elif iiyAEbQ5f80=='folder': HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'M3U-SERIES'
						else:
							if   'LIVE' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'M3U-LIVE'
							elif 'MOVIES' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'M3U-MOVIES'
							elif 'SERIES' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'M3U-SERIES'
					elif 'YOUTUBE-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER and 149>=EYMmnJAyxV>=140:
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['YOUTUBE-CHANNELS']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['YOUTUBE-PLAYLISTS']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['YOUTUBE-VIDEOS']: continue
						if 'صفحة أخرى' in xbfwC5hkXLvsJa8PReOS9AyU1z or ':: ' in xbfwC5hkXLvsJa8PReOS9AyU1z:
							continue
						else:
							if   EYMmnJAyxV==144 and 'USER' in xbfwC5hkXLvsJa8PReOS9AyU1z: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'YOUTUBE-CHANNELS'
							elif EYMmnJAyxV==144 and 'CHNL' in xbfwC5hkXLvsJa8PReOS9AyU1z: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'YOUTUBE-CHANNELS'
							elif EYMmnJAyxV==144 and 'LIST' in xbfwC5hkXLvsJa8PReOS9AyU1z: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'YOUTUBE-PLAYLISTS'
							elif EYMmnJAyxV==143: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'YOUTUBE-VIDEOS'
							else: continue
					elif 'DAILYMOTION-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER and 419>=EYMmnJAyxV>=400:
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['DAILYMOTION-PLAYLISTS']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['DAILYMOTION-CHANNELS']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['DAILYMOTION-VIDEOS']: continue
						if   EYMmnJAyxV in [401,405]: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'DAILYMOTION-PLAYLISTS'
						elif EYMmnJAyxV in [402,406]: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'DAILYMOTION-CHANNELS'
						elif EYMmnJAyxV in [404]: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'DAILYMOTION-VIDEOS'
						elif EYMmnJAyxV in [415]: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'DAILYMOTION-LIVES'
					elif 'PANET-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER and 39>=EYMmnJAyxV>=30:
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['PANET-SERIES']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['PANET-MOVIES']: continue
						if   EYMmnJAyxV in [32,39]: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'PANET-SERIES'
						elif EYMmnJAyxV in [33,39]: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'PANET-MOVIES'
					elif 'IFILM-' in HMPtOcVoJiXCu8z0nesDWYkIl9ER and 29>=EYMmnJAyxV>=20:
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['IFILM-ARABIC']: continue
						if rqQNcnS9WF6AeXbI15od2H in VrJzjgscSt8XuykMqxGdlC9fBZw0['IFILM-ENGLISH']: continue
						if   '/ar.' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IFILM-ARABIC'
						elif '/en.' in wNyZhHdvUeC3M: HMPtOcVoJiXCu8z0nesDWYkIl9ER = 'IFILM-ENGLISH'
					VrJzjgscSt8XuykMqxGdlC9fBZw0[HMPtOcVoJiXCu8z0nesDWYkIl9ER].append(rqQNcnS9WF6AeXbI15od2H)
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in list(VrJzjgscSt8XuykMqxGdlC9fBZw0.keys()):
			N3oFvhIKwkPdq[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = []
			XP5pBa3fhgITSd0WtqNDuw1U7Y2[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = []
			for iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in VrJzjgscSt8XuykMqxGdlC9fBZw0[HMPtOcVoJiXCu8z0nesDWYkIl9ER]:
				rqQNcnS9WF6AeXbI15od2H = (iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
				if 'صفحة' in xbfwC5hkXLvsJa8PReOS9AyU1z and iiyAEbQ5f80=='folder': XP5pBa3fhgITSd0WtqNDuw1U7Y2[HMPtOcVoJiXCu8z0nesDWYkIl9ER].append(rqQNcnS9WF6AeXbI15od2H)
				else: N3oFvhIKwkPdq[HMPtOcVoJiXCu8z0nesDWYkIl9ER].append(rqQNcnS9WF6AeXbI15od2H)
		nnCJ0xa4WEwLbAfVc,DjeARlk126cXaLVQJHT9snvIty = [],[]
		UUAmxeZhpHJFELQ21t = list(N3oFvhIKwkPdq.keys())
		UOdI3NWsq7Z = krz9nKbhoxfVJc(UUAmxeZhpHJFELQ21t)
		boe0pS8jmCnNQvasP9UuB = []
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in UOdI3NWsq7Z:
			if 'tuple' in str(type(HMPtOcVoJiXCu8z0nesDWYkIl9ER)):
				boe0pS8jmCnNQvasP9UuB = [HMPtOcVoJiXCu8z0nesDWYkIl9ER]
				continue
			if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in jjkGz0trAqQu1lMNDvy8IH7UCWdBeO: continue
			if N3oFvhIKwkPdq[HMPtOcVoJiXCu8z0nesDWYkIl9ER]:
				txCiV4unbDgqmd3vY5sW7JLRMBOA = wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
				uumixkpCEZnhG = [('link',l5JG7XwbOfo8DznU+'===== '+txCiV4unbDgqmd3vY5sW7JLRMBOA+' ====='+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)]
				if 0: R7EpnFQ6s8 = NckbIxftmrjUh0KYn+' - '+'بحث'+S3X6GcaiExOPtb+txCiV4unbDgqmd3vY5sW7JLRMBOA
				else: R7EpnFQ6s8 = 'بحث'+S3X6GcaiExOPtb+txCiV4unbDgqmd3vY5sW7JLRMBOA+' - '+NckbIxftmrjUh0KYn
				if len(N3oFvhIKwkPdq[HMPtOcVoJiXCu8z0nesDWYkIl9ER])<8: B5uE49j6ZtiF7S = []
				else:
					lT0U2ESM3hAjzrKq6a1gePmyOBi = eMypvI8XqHjYU02anWD9gsSrkt+R7EpnFQ6s8+c7gxFyUCGm
					B5uE49j6ZtiF7S = [('folder',Y7K6m8qtkCunWF2XfcIdVgv4+lT0U2ESM3hAjzrKq6a1gePmyOBi,'closed_sites'+EYsUAzvhI6FwSM9uiGm2c,542,nbOFVEDkpT4BIR7Qq82yPmHeJU,HMPtOcVoJiXCu8z0nesDWYkIl9ER,NckbIxftmrjUh0KYn,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)]
				NNHwCrByft5iXL2OzATFIJuWUj9lv = N3oFvhIKwkPdq[HMPtOcVoJiXCu8z0nesDWYkIl9ER]+XP5pBa3fhgITSd0WtqNDuw1U7Y2[HMPtOcVoJiXCu8z0nesDWYkIl9ER]
				TubevAyrKnQhDHc1R7LmGFB64Mk = boe0pS8jmCnNQvasP9UuB+uumixkpCEZnhG+NNHwCrByft5iXL2OzATFIJuWUj9lv[:7]+B5uE49j6ZtiF7S
				nnCJ0xa4WEwLbAfVc += TubevAyrKnQhDHc1R7LmGFB64Mk
				OCi3kfdBb04s6oAlKzxFMh9Yep1Hg = [('folder',Y7K6m8qtkCunWF2XfcIdVgv4+R7EpnFQ6s8,'closed_sites'+EYsUAzvhI6FwSM9uiGm2c,542,nbOFVEDkpT4BIR7Qq82yPmHeJU,HMPtOcVoJiXCu8z0nesDWYkIl9ER,NckbIxftmrjUh0KYn,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)]
				uaG6JcISkfL5CE = boe0pS8jmCnNQvasP9UuB+OCi3kfdBb04s6oAlKzxFMh9Yep1Hg
				DjeARlk126cXaLVQJHT9snvIty += uaG6JcISkfL5CE
				z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'GLOBALSEARCH_DIVIDED'+lY3XQyzBNW,(HMPtOcVoJiXCu8z0nesDWYkIl9ER,NckbIxftmrjUh0KYn),NNHwCrByft5iXL2OzATFIJuWUj9lv,rXKp4uqLMW3v)
				boe0pS8jmCnNQvasP9UuB = []
		z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'GLOBALSEARCH_DETAILED'+lY3XQyzBNW,NckbIxftmrjUh0KYn,nnCJ0xa4WEwLbAfVc,rXKp4uqLMW3v)
		uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,NckbIxftmrjUh0KYn)
		z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'GLOBALSEARCH_SPLITTED'+lY3XQyzBNW,Y7K6m8qtkCunWF2XfcIdVgv4+NckbIxftmrjUh0KYn,DjeARlk126cXaLVQJHT9snvIty,rXKp4uqLMW3v)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','البحث الجماعي انتهى بنجاح \n\n تم تخزين النتائج في كاش البرنامج لمدة ثلاثين يوم لكي تستطيع العودة إليها بدون عمل بحث جديد')
		qb1hrzIR5gBCofF37 = DjeARlk126cXaLVQJHT9snvIty if t4DP3mp7Jq62bhE=='listed_sites'+EYsUAzvhI6FwSM9uiGm2c and DjeARlk126cXaLVQJHT9snvIty else nnCJ0xa4WEwLbAfVc
	if t4DP3mp7Jq62bhE in ['listed_sites'+EYsUAzvhI6FwSM9uiGm2c,'opened_sites'+EYsUAzvhI6FwSM9uiGm2c,'closed_sites'+EYsUAzvhI6FwSM9uiGm2c]:
		for iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in qb1hrzIR5gBCofF37:
			if t4DP3mp7Jq62bhE in ['listed_sites'+EYsUAzvhI6FwSM9uiGm2c,'opened_sites'+EYsUAzvhI6FwSM9uiGm2c] and 'صفحة' in xbfwC5hkXLvsJa8PReOS9AyU1z and iiyAEbQ5f80=='folder': continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
	Zb4NIBy16VvWF(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return
def bcdm6puk0ysJXFgCloh7EDfUv(search):
	UUAmxeZhpHJFELQ21t = TltfNJPeVwqk5Bhvcmyn7pG
	UOdI3NWsq7Z = krz9nKbhoxfVJc(UUAmxeZhpHJFELQ21t)
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER in UOdI3NWsq7Z:
		if 'tuple' in str(type(HMPtOcVoJiXCu8z0nesDWYkIl9ER)):
			LvJuOzMqk6WlP971eoGpUQ8.append(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			continue
		UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
		name = wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER)+' - '+search
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',fxUgL78lj13rQ4W6wZOE+name,HMPtOcVoJiXCu8z0nesDWYkIl9ER,548,'','',search)
	return
def xyurzMKCVJQ0(HMPtOcVoJiXCu8z0nesDWYkIl9ER,search):
	UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	Nwj2WURK7qbY6coiBdMDzuS(search)
	return
def A9vlaj5oR0YXTJuFIyEBV():
	aY7RFmnWc5uU9T3Q0Mxq4('','','رسالة من المبرمج','هذا البحث يستخدم محركات البحث الصغيرة الموجودة في كل موقع من مواقع البرنامج .. ونتائج هذا البحث تعتمد على دقة وفعالية وبرمجة كل موقع منها\n\nللأسف هذه المحركات الصغيرة لا تفهم جميع تفاصيل الفيديوهات ولا تفهم طريقة تفكير البشر ولا تستطيع إصلاح الأخطاء الإملائية .. ولهذا هي تحتاج دقة كبيرة جدا في اختيار وكتابة كلمات البحث المناسبة الصحيحة الدقيقة حتى تجد لك طلبك')
	return
def krz9nKbhoxfVJc(UUAmxeZhpHJFELQ21t):
	UOdI3NWsq7Z,boe0pS8jmCnNQvasP9UuB = [],None
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER in TltfNJPeVwqk5Bhvcmyn7pG:
		if   HMPtOcVoJiXCu8z0nesDWYkIl9ER=='PRIVATE': boe0pS8jmCnNQvasP9UuB = ('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات خاصة - قليلة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		elif HMPtOcVoJiXCu8z0nesDWYkIl9ER=='MIXED': boe0pS8jmCnNQvasP9UuB = ('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		elif HMPtOcVoJiXCu8z0nesDWYkIl9ER=='PUBLIC': boe0pS8jmCnNQvasP9UuB = ('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات عامة - كثيرة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in UUAmxeZhpHJFELQ21t: continue
		if boe0pS8jmCnNQvasP9UuB:
			UOdI3NWsq7Z.append(boe0pS8jmCnNQvasP9UuB)
			boe0pS8jmCnNQvasP9UuB = None
		if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in ['PRIVATE','MIXED','PUBLIC']: UOdI3NWsq7Z.append(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	return UOdI3NWsq7Z
def VdJzAaPm7sXyTIMbFp4(NckbIxftmrjUh0KYn=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,Hg9iNXSxJobPBr,showDialogs = hKjNwk3Bfpa48Om7JQz(NckbIxftmrjUh0KYn)
	if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ:
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = dR75Vq2gprfHmUcNhG()
		if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ: return
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ.lower()
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Search For: [ '+B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+' ]')
	T871qPZzS4LkoMBa3Db9Q = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+Hg9iNXSxJobPBr
	if 0: EgxmzfSoR4GA,KYPwjRcdHJ0 = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+' - ',nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: EgxmzfSoR4GA,KYPwjRcdHJ0 = nbOFVEDkpT4BIR7Qq82yPmHeJU,' - '+B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات خاصة - قليلة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_M3U_'+EgxmzfSoR4GA+'بحث M3U'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,719,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_IPT_'+EgxmzfSoR4GA+'بحث IPTV'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,239,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_BKR_'+EgxmzfSoR4GA+'بحث موقع بكرا'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,379,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_ART_'+EgxmzfSoR4GA+'بحث موقع تونز عربية'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,739,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_KRB_'+EgxmzfSoR4GA+'بحث موقع قناة كربلاء'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,329,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FH2_'+EgxmzfSoR4GA+'بحث موقع فاصل الثاني'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,599,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_KTV_'+EgxmzfSoR4GA+'بحث موقع كتكوت تيفي'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,819,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_EB1_'+EgxmzfSoR4GA+'بحث موقع ايجي بيست 1'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,779,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_EB2_'+EgxmzfSoR4GA+'بحث موقع ايجي بيست 2'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,789,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_IFL_'+EgxmzfSoR4GA+'  بحث موقع قناة آي فيلم'+KYPwjRcdHJ0+BhmzEC6OGD7FXZig9Tp5A,nbOFVEDkpT4BIR7Qq82yPmHeJU,29,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_AKO_'+EgxmzfSoR4GA+'بحث موقع أكوام القديم'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,79,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_AKW_'+EgxmzfSoR4GA+'بحث موقع أكوام الجديد'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,249,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_MRF_'+EgxmzfSoR4GA+'بحث موقع قناة المعارف'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,49,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SHM_'+EgxmzfSoR4GA+'بحث موقع شوف ماكس'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,59,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات خاصة وعامة - كثيرة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_LRZ_'+EgxmzfSoR4GA+'بحث موقع لاروزا'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,709,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FJS_'+EgxmzfSoR4GA+' بحث موقع فجر شو'+KYPwjRcdHJ0+S3X6GcaiExOPtb,nbOFVEDkpT4BIR7Qq82yPmHeJU,399,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TVF_'+EgxmzfSoR4GA+'بحث موقع تيفي فان'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,469,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_LDN_'+EgxmzfSoR4GA+'بحث موقع لودي نت'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,459,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_CMN_'+EgxmzfSoR4GA+'بحث موقع سيما ناو'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,309,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SHN_'+EgxmzfSoR4GA+'بحث موقع شاهد نيوز'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,589,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q+'_NODIALOGS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_ARS_'+EgxmzfSoR4GA+'بحث موقع عرب سييد'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,259,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_CCB_'+EgxmzfSoR4GA+'بحث موقع سيما كلوب'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,829,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SH4_'+EgxmzfSoR4GA+'بحث موقع شاهد فوريو'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,119,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q+'_NODIALOGS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SHT_'+EgxmzfSoR4GA+'بحث موقع شوفها تيفي'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,649,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_WC1_'+EgxmzfSoR4GA+'بحث موقع وي سيما 1'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,569,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_WC2_'+EgxmzfSoR4GA+'بحث موقع وي سيما 2'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,1009,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات عامة - كثيرة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_TKT_'+EgxmzfSoR4GA+'بحث موقع تكات'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,949,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FST_'+EgxmzfSoR4GA+'بحث موقع فوستا'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,609,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FBK_'+EgxmzfSoR4GA+'بحث موقع فبركة'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,629,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_YQT_'+EgxmzfSoR4GA+'بحث موقع ياقوت'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,669,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SHB_'+EgxmzfSoR4GA+'بحث موقع شبكتي'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,969,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_VRB_'+EgxmzfSoR4GA+'بحث موقع فاربون'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,879,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_BRS_'+EgxmzfSoR4GA+'بحث موقع برستيج'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,659,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_KRM_'+EgxmzfSoR4GA+'بحث موقع كرمالك'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,929,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_ANZ_'+EgxmzfSoR4GA+'بحث موقع انمي زد'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,979,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FSK_'+EgxmzfSoR4GA+'بحث موقع فاريسكو'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,999,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_HLC_'+EgxmzfSoR4GA+'بحث موقع هلا سيما'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,89,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_MST_'+EgxmzfSoR4GA+'بحث موقع المصطبة'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,869,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SNT_'+EgxmzfSoR4GA+'بحث موقع شوف نت'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,849,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_DR7_'+EgxmzfSoR4GA+'بحث موقع دراما صح'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,689,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_CFR_'+EgxmzfSoR4GA+'بحث موقع سيما فري'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,839,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_CMF_'+EgxmzfSoR4GA+'بحث موقع سيما فانز'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,99,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_CML_'+EgxmzfSoR4GA+'بحث موقع سيما لايت'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,479,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_C4H_'+EgxmzfSoR4GA+'بحث موقع سيما 400'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,699,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_ABD_'+EgxmzfSoR4GA+'بحث موقع سيما عبدو'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,559,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_AKT_'+EgxmzfSoR4GA+'بحث موقع اكوام تيوب'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,859,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_DCF_'+EgxmzfSoR4GA+'بحث موقع دراما كافيه'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,939,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FTV_'+EgxmzfSoR4GA+'بحث موقع فوشار تيفي'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,919,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_CWB_'+EgxmzfSoR4GA+'بحث موقع سيما وبس'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,989,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_AHK_'+EgxmzfSoR4GA+'بحث موقع أهواك تيفي'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,619,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_SRT_'+EgxmzfSoR4GA+'بحث موقع سيريس تايم'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,899,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_FVD_'+EgxmzfSoR4GA+'بحث موقع فوشار فيديو'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,909,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_C4P_'+EgxmzfSoR4GA+'بحث موقع سيما فور بي'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,889,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_EB4_'+EgxmzfSoR4GA+'بحث موقع ايجي بيست 4'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,809,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع سيرفرات خاصة - قليلة المشاكل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,157)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_YUT_'+EgxmzfSoR4GA+'بحث موقع يوتيوب'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,149,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_DLM_'+EgxmzfSoR4GA+'بحث موقع دايلي موشن'+KYPwjRcdHJ0,nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,T871qPZzS4LkoMBa3Db9Q)
	return
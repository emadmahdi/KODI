﻿# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'ALMAAREF'
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_MRF_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['التواصل الاجتماعي','صور التواصل الاجتماعي','أرشيف جميع البرامج']
def n1zxUlcAgR(mode,url,text,ohpwd6UumaecE3IWV8lAv0):
	if   mode==40: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==41: bPFto2wZdNYrClgBIEv60DJAzu = dsFVer3DMTj2iQANyPmvkYU7()
	elif mode==42: bPFto2wZdNYrClgBIEv60DJAzu = JscVe7KzyAonDSu(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==43: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==44: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==49: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,49)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'البث الحي لقناة المعارف',nbOFVEDkpT4BIR7Qq82yPmHeJU,41)
	JscVe7KzyAonDSu(nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	return
def oh8zTHsI70rt6lZWb2FBA5REvU(YE1hqa60dGTRDZ8NVBM,nnAcWfhGHbpjElkPNxOmzo8):
	search,sort,dKDogOhGNljecME,jGdXt7eADorwlv8pahNV95H6Tn2qKx,X2y9nR0DZwKO7pW = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[],[],[]
	uiazRbmZ63Je21WGqn,jHVevKzCYZNkMg = kJPjYVSCDE2(YE1hqa60dGTRDZ8NVBM)
	for PspiL81kMT4BwOIXo in list(jHVevKzCYZNkMg.keys()):
		XPL0O2VkI3w1C8enMaqi = jHVevKzCYZNkMg[PspiL81kMT4BwOIXo]
		if not XPL0O2VkI3w1C8enMaqi: continue
		if   PspiL81kMT4BwOIXo=='sort': sort = [XPL0O2VkI3w1C8enMaqi]
		elif PspiL81kMT4BwOIXo=='series': dKDogOhGNljecME = [XPL0O2VkI3w1C8enMaqi]
		elif PspiL81kMT4BwOIXo=='search': search = XPL0O2VkI3w1C8enMaqi
		elif PspiL81kMT4BwOIXo=='category': jGdXt7eADorwlv8pahNV95H6Tn2qKx = [XPL0O2VkI3w1C8enMaqi]
		elif PspiL81kMT4BwOIXo=='specialist': X2y9nR0DZwKO7pW = [XPL0O2VkI3w1C8enMaqi]
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = {"action":"facetwp_refresh","data":{"facets":{"search":search,"video_categories":jGdXt7eADorwlv8pahNV95H6Tn2qKx,"specialist":X2y9nR0DZwKO7pW,"series":dKDogOhGNljecME,"number":[],"sort_video":sort,"count":[],"pagination":[]},"frozen_facets":{},"template":"video_desktop_posts","extras":{"sort":"default"},"soft_refresh":0,"is_bfcache":1,"first_load":0,"paged":int(nnAcWfhGHbpjElkPNxOmzo8)}}
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = eH72MR1wtfuI80myOo4ajgG.dumps(iugaeRtZ5HFw7mJc9AdTbKlLV2)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'https://almaaref.ch/wp-json/facetwp/v1/refresh'
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ALMAAREF-REQUEST_DATA_PAGE-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	data = dr1zfnatJxRHSF48jh0eODm5bGu('dict',UTvsQb4HpCP3Aeo2wDZG7X5V)
	return data
def JscVe7KzyAonDSu(YE1hqa60dGTRDZ8NVBM,level):
	ISmqngYzv6jrepWUx0l = oh8zTHsI70rt6lZWb2FBA5REvU(YE1hqa60dGTRDZ8NVBM,'1')
	G4JHzTEp61 = ISmqngYzv6jrepWUx0l['facets']
	if level=='1':
		G4JHzTEp61 = G4JHzTEp61['video_categories']
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<div(.*?)/div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for xB2lOZNsPvFQDC4gMz in items:
			EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall('data-value=\\"(.*?)\\".*?display-value\\">(.*?)<',xB2lOZNsPvFQDC4gMz+'<',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not EwNgXqHTSJK6sR9LWrBU3Zh8v: EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall('data-value=\\"(.*?)\\">(.*?)<',xB2lOZNsPvFQDC4gMz+'<',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			jGdXt7eADorwlv8pahNV95H6Tn2qKx,title = EwNgXqHTSJK6sR9LWrBU3Zh8v[0]
			if n7neb9KTv10FcU: title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			if not YE1hqa60dGTRDZ8NVBM: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,42,nbOFVEDkpT4BIR7Qq82yPmHeJU,'2','?category='+jGdXt7eADorwlv8pahNV95H6Tn2qKx)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,42,nbOFVEDkpT4BIR7Qq82yPmHeJU,'2',YE1hqa60dGTRDZ8NVBM+'&category='+jGdXt7eADorwlv8pahNV95H6Tn2qKx)
	if level=='2':
		G4JHzTEp61 = G4JHzTEp61['specialist']
		items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X2y9nR0DZwKO7pW,title in items:
			if n7neb9KTv10FcU: title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			if not X2y9nR0DZwKO7pW: title = title = 'الجميع'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,42,nbOFVEDkpT4BIR7Qq82yPmHeJU,'3',YE1hqa60dGTRDZ8NVBM+'&specialist='+X2y9nR0DZwKO7pW)
	elif level=='3':
		G4JHzTEp61 = G4JHzTEp61['series']
		items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for dKDogOhGNljecME,title in items:
			if n7neb9KTv10FcU: title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			if not dKDogOhGNljecME: title = title = 'الجميع'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,42,nbOFVEDkpT4BIR7Qq82yPmHeJU,'4',YE1hqa60dGTRDZ8NVBM+'&series='+dKDogOhGNljecME)
	elif level=='4':
		G4JHzTEp61 = G4JHzTEp61['sort_video']
		items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for sort,title in items:
			if not sort: continue
			if n7neb9KTv10FcU: title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,44,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',YE1hqa60dGTRDZ8NVBM+'&sort='+sort)
	return
def IGDobAKtj4kPF5V(YE1hqa60dGTRDZ8NVBM,nnAcWfhGHbpjElkPNxOmzo8):
	ISmqngYzv6jrepWUx0l = oh8zTHsI70rt6lZWb2FBA5REvU(YE1hqa60dGTRDZ8NVBM,nnAcWfhGHbpjElkPNxOmzo8)
	G4JHzTEp61 = ISmqngYzv6jrepWUx0l['template']
	items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if n7neb9KTv10FcU: title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,43,X79kphTKa1xLP)
	G4JHzTEp61 = ISmqngYzv6jrepWUx0l['facets']['pagination']
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-page="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for ohpwd6UumaecE3IWV8lAv0,title in items:
		if nnAcWfhGHbpjElkPNxOmzo8==ohpwd6UumaecE3IWV8lAv0: continue
		if n7neb9KTv10FcU: title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,44,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,YE1hqa60dGTRDZ8NVBM)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ALMAAREF-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<video src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('youtube_url.*?(http.*?)&',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	NWtqFg91ZSKinvIwAc = []
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0].replace('\/','/')
		NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def dsFVer3DMTj2iQANyPmvkYU7():
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs+'/بث-مباشر',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ALMAAREF-LIVE-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	url = ScntgdOZCY74vNpXeW5jh8i.findall('"svpPlayer".*?(http.*?)&',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	url = url[0].replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	brh5aWRxQzn6YL8UDNOyK9SFGo(url,QSJFrwB3dMiyH2mTPKD9a,'live')
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	icE4lReLjt8 = False
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU:
		search = dR75Vq2gprfHmUcNhG()
		icE4lReLjt8 = True
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	if not icE4lReLjt8: IGDobAKtj4kPF5V('?search='+search,'1')
	else: JscVe7KzyAonDSu('?search='+search,'1')
	return
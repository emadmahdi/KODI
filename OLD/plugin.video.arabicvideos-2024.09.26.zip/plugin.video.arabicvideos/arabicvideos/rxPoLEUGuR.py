# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'LAROZA'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_LRZ_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['الصفحة الرئيسية','Sign in','الاقسام','عرض المزيد']
def n1zxUlcAgR(mode,url,text):
	if   mode==700: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==701: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==702: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==703: bPFto2wZdNYrClgBIEv60DJAzu = XZPY6JeohB9ODmRrgIxvuA(url,text)
	elif mode==704: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==709: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = zKREXyTHfVSNL8ZFYs
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LAROZA-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,709,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المسلسلات',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/moslslat.php',701)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pm-top-nav"(.*?)class="hidden',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = title.replace('<b>',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		if title in CZrI4vYju7a: continue
		if 'javascrip' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		if 'class=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,704)
	return
def Cvflxc4FMs37bmY(url):
	qv5R2JduMmjoEIcKQ3kt7WgX = False
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LAROZA-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('role="menu"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IHV3wWCjYv4:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		G4JHzTEp61 = G4JHzTEp61.replace('"presentation"','</ul>')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = [(nbOFVEDkpT4BIR7Qq82yPmHeJU,G4JHzTEp61)]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' فرز أو فلتر أو ترتيب '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		for WBVx7UzjEQPnhy0owDHtmdGgl,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if WBVx7UzjEQPnhy0owDHtmdGgl: WBVx7UzjEQPnhy0owDHtmdGgl = WBVx7UzjEQPnhy0owDHtmdGgl+': '
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = WBVx7UzjEQPnhy0owDHtmdGgl+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,701)
				qv5R2JduMmjoEIcKQ3kt7WgX = True
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"pm-category-subcats"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(items)<30:
			if qv5R2JduMmjoEIcKQ3kt7WgX: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,701)
				qv5R2JduMmjoEIcKQ3kt7WgX = True
	McZrvSBqofYKz6Jj5g4axuIR2VGA = ScntgdOZCY74vNpXeW5jh8i.findall('class="catfootr"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if 0 and McZrvSBqofYKz6Jj5g4axuIR2VGA:
		G4JHzTEp61 = McZrvSBqofYKz6Jj5g4axuIR2VGA[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if 1:
			if qv5R2JduMmjoEIcKQ3kt7WgX: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,701)
				qv5R2JduMmjoEIcKQ3kt7WgX = True
	if not qv5R2JduMmjoEIcKQ3kt7WgX: IGDobAKtj4kPF5V(url)
	return
def IGDobAKtj4kPF5V(url,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if s0tfc7T2hwBM=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		headers = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LAROZA-TITLES-1st')
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LAROZA-TITLES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	G4JHzTEp61,items = nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	if s0tfc7T2hwBM=='ajax-search':
		G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG: items.append((nbOFVEDkpT4BIR7Qq82yPmHeJU,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title))
	elif s0tfc7T2hwBM=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="content"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	elif s0tfc7T2hwBM=='new_episodes':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"row pm-ul-browse-videos(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	elif s0tfc7T2hwBM=='new_movies':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"row pm-ul-browse-videos(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(eXpgPIbRv2ZMGwjm5)>1: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[1]
	elif s0tfc7T2hwBM=='featured_series':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"ba mgb table full"(.*?)"clearfix"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)" title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG: items.append((nbOFVEDkpT4BIR7Qq82yPmHeJU,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title))
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('("thumbnail".*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if G4JHzTEp61 and not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('"thumbnail".*?<a href="(.*?)" title="(.*?)".*?src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: return
	tWsVFQj47pw0L56rZfg = []
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
		title = dCtxzeFX4GJVonm(title)
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة).\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,702,X79kphTKa1xLP)
		elif s0tfc7T2hwBM=='new_episodes':
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,702,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,703,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,703,X79kphTKa1xLP)
	if 1:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if '?' in url: url,ohpwd6UumaecE3IWV8lAv0 = url.split('?',1)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='#': continue
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				title = dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,701)
	return
def XZPY6JeohB9ODmRrgIxvuA(url,W58zOLpMh2ZTrcEemS70AUy):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LAROZA-EPISODES_SEASONS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	nnu5vdh1IscOA8J = ScntgdOZCY74vNpXeW5jh8i.findall('"series-header".*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if nnu5vdh1IscOA8J: X79kphTKa1xLP = nnu5vdh1IscOA8J[0]
	else: X79kphTKa1xLP = nbOFVEDkpT4BIR7Qq82yPmHeJU
	items = []
	ee9RfPxQdhHY1qbt0Om8ianC673W = False
	if IHV3wWCjYv4 and not W58zOLpMh2ZTrcEemS70AUy:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('''openCity\(event, '(.*?)'\).*?">(.*?)</button>''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('data-serie="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for W58zOLpMh2ZTrcEemS70AUy,title in items:
			W58zOLpMh2ZTrcEemS70AUy = W58zOLpMh2ZTrcEemS70AUy.strip('#')
			if len(items)>1: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,703,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,W58zOLpMh2ZTrcEemS70AUy)
			else: ee9RfPxQdhHY1qbt0Om8ianC673W = True
	else: ee9RfPxQdhHY1qbt0Om8ianC673W = True
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"SeasonsEpisodesMain(.*?)<script>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5 and ee9RfPxQdhHY1qbt0Om8ianC673W:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall("`season_slug` = '"+W58zOLpMh2ZTrcEemS70AUy+"'(.*?)</div>",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if b8Ior2kWzq1tc: G4JHzTEp61 = b8Ior2kWzq1tc[0]
		else:
			plSscrVjkRviPwm = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/fetch_episodes.php'
			data = 'seasonId='+lcxFAteLQ1Pwu45Er2(W58zOLpMh2ZTrcEemS70AUy)
			headers = {'Content-Type':'application/x-www-form-urlencoded'}
			cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LAROZA-EPISODES_SEASONS-2nd')
			G4JHzTEp61 = cnPhVmgFxA.content
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('''href=['"](.*?)['"]><em>(.*?)</span>''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not XhE8FpdTjG: XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"><em>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		items = []
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG: items.append((grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP))
		if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('./')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
			title = title.replace('</em><span>',S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,702,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	NWtqFg91ZSKinvIwAc,vdYMP3fDSnxzeEgXmqpcua = [],[]
	UTvsQb4HpCP3Aeo2wDZG7X5V = ''
	if 'post=' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('id="player".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
		PSua7U3vIj9lwFpThsMHdiq2GEcV1N = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('post=')[1]
		PSua7U3vIj9lwFpThsMHdiq2GEcV1N = Y7goyGlxwNaP1XcWU6e.b64decode(PSua7U3vIj9lwFpThsMHdiq2GEcV1N)
		if IZhXMprxvAHqBEFkg0: PSua7U3vIj9lwFpThsMHdiq2GEcV1N = PSua7U3vIj9lwFpThsMHdiq2GEcV1N.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		PSua7U3vIj9lwFpThsMHdiq2GEcV1N = dr1zfnatJxRHSF48jh0eODm5bGu('dict',PSua7U3vIj9lwFpThsMHdiq2GEcV1N)
		rU02bCJFWZDfVuhtMgBOyQi5P = PSua7U3vIj9lwFpThsMHdiq2GEcV1N['servers']
		bdW70uQAIF = list(rU02bCJFWZDfVuhtMgBOyQi5P.keys())
		rU02bCJFWZDfVuhtMgBOyQi5P = list(rU02bCJFWZDfVuhtMgBOyQi5P.values())
		pgIxQdT5lkmt = zip(bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P)
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in pgIxQdT5lkmt:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else:
		plSscrVjkRviPwm = url.replace('video.php','play.php')
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHABAKATY-PLAY2-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"embedded" src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
				vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				title = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__embed'
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pm-servers"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<script(.*?)</script',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
				if 'function(h,u,n,t,e,r)' in G4JHzTEp61:
					G4JHzTEp61 = VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(G4JHzTEp61)
					G4JHzTEp61 = ScntgdOZCY74vNpXeW5jh8i.findall("encodedHtml = '(.*?)'",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if G4JHzTEp61:
						G4JHzTEp61 = Y7goyGlxwNaP1XcWU6e.b64decode(G4JHzTEp61[0])
						if IZhXMprxvAHqBEFkg0: G4JHzTEp61 = G4JHzTEp61.decode(zSafwK0sDXdMN5JReniIQmrZxp)
						items = ScntgdOZCY74vNpXeW5jh8i.findall('data-name="(.*?)".*?data-embed="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
							if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
								vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
								grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
								NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if 'pm-download' not in UTvsQb4HpCP3Aeo2wDZG7X5V:
			plSscrVjkRviPwm = url.replace('video.php','download.php')
			cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,False,'SHABAKATY-PLAY-2nd')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pm-download(.*?)"content"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<script(.*?)</script',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
				if 'function(h,u,n,t,e,r)' in G4JHzTEp61:
					G4JHzTEp61 = VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(G4JHzTEp61)
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"(http.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
						if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
							vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
							title = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
							grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'
							NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/search.php?keywords='+search
	IGDobAKtj4kPF5V(url,'search')
	return
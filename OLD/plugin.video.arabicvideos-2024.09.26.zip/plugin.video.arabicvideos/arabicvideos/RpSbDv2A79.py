# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
from vYfmi4wEP5 import *
import base64 as Y7goyGlxwNaP1XcWU6e
QSJFrwB3dMiyH2mTPKD9a = fgv5U2eRVaQqSiuGD(u"ࠩࡏࡍࡇ࡙ࡔࡘࡑࠪ୷")
T1tKzfJGbiuP4mkgHl3QrSNVn8 = {}
LvJuOzMqk6WlP971eoGpUQ8 = []
hhYNnS925rx4buzZaeVQg0,brwqJc3TALapItWlyz,VH0sy13WPr = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
UhfXK25nxeE8t3i0bOcl = {}
XXl2tGoemr7Yd,V3jFwXDRB56tzixuImOUTNhpenPqH = [f4fTutDOEwUeIoPLRQ],[f4fTutDOEwUeIoPLRQ]
fnZbzLvOBJm9krHujVw1oc3lYPq5 = SmbNGskjMx
if IZhXMprxvAHqBEFkg0:
	x0K15dC9TEQLotSHYOBWU = NtJjXky6q1.translatePath(z3sIGH8jmLYg(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡸࡣ࡯ࡦࠫ୸"))
	VRTXg24fPYirJ3 = NtJjXky6q1.translatePath(fgv5U2eRVaQqSiuGD(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬ୹"))
	AARGaz3TqfNeKgrJ5mZcFEIQY9 = NtJjXky6q1.translatePath(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰࡮ࡲ࡫ࡵࡧࡴࡩࠩ୺"))
	zZ9tVvyojlWYupgSJxDImHdLsUFTNq = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,ulAxHwvzR9eTb5n(u"࠭ࡵࡴࡧࡵࡨࡦࡺࡡࠨ୻"),ulAxHwvzR9eTb5n(u"ࠧࡅࡣࡷࡥࡧࡧࡳࡦࠩ୼"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡃࡧࡨࡴࡴࡳ࠴࠵࠱ࡨࡧ࠭୽"))
	CMBE1pKmT34Zxno8V = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡸࡷࡪࡸࡤࡢࡶࡤࠫ୾"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡈࡦࡺࡡࡣࡣࡶࡩࠬ୿"),cb3rmvAn4wa6lBPz2phOoYqX(u"࡛ࠫ࡯ࡥࡸࡏࡲࡨࡪࡹ࠶࠯ࡦࡥࠫ஀"))
	jXnZQgFiVG0SqJ4eyasY2fIE = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ஁"),cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨஂ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡕࡧࡻࡸࡺࡸࡥࡴ࠳࠶࠲ࡩࡨࠧஃ"))
	aiRHWcOtjhszqmMC7DePT1y = l4DS8mnEjHhFMZ5YOe(u"ࡶࠩ࡟ࡹ࠵࠸ࡤ࠲ࠩ஄")
	from urllib.parse import quote as _YcNCDm7pPxskylg
else:
	x0K15dC9TEQLotSHYOBWU = RarSo2nTfwU0WEGK.translatePath(QlTuvPbSpnjygBVW(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡾࡢ࡮ࡥࠪஅ"))
	VRTXg24fPYirJ3 = RarSo2nTfwU0WEGK.translatePath(l4DS8mnEjHhFMZ5YOe(u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫஆ"))
	AARGaz3TqfNeKgrJ5mZcFEIQY9 = RarSo2nTfwU0WEGK.translatePath(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯࡭ࡱࡪࡴࡦࡺࡨࠨஇ"))
	zZ9tVvyojlWYupgSJxDImHdLsUFTNq = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,UpQ56M0dO1N9xIvVegy(u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧஈ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡄࡢࡶࡤࡦࡦࡹࡥࠨஉ"),ulAxHwvzR9eTb5n(u"ࠧࡂࡦࡧࡳࡳࡹ࠲࠸࠰ࡧࡦࠬஊ"))
	CMBE1pKmT34Zxno8V = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,DJ6ugPjW9bX8I(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ஋"),X1mRwt2YJKgCLu9a67(u"ࠩࡇࡥࡹࡧࡢࡢࡵࡨࠫ஌"),UpQ56M0dO1N9xIvVegy(u"࡚ࠪ࡮࡫ࡷࡎࡱࡧࡩࡸ࠼࠮ࡥࡤࠪ஍"))
	jXnZQgFiVG0SqJ4eyasY2fIE = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,UpQ56M0dO1N9xIvVegy(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭எ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡊࡡࡵࡣࡥࡥࡸ࡫ࠧஏ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡔࡦࡺࡷࡹࡷ࡫ࡳ࠲࠵࠱ࡨࡧ࠭ஐ"))
	aiRHWcOtjhszqmMC7DePT1y = DJ6ugPjW9bX8I(u"ࡵࠨ࡞ࡸ࠴࠷ࡪ࠱ࠨ஑").encode(zSafwK0sDXdMN5JReniIQmrZxp)
	from urllib import quote as _YcNCDm7pPxskylg
vOxIJSfwPEpCc = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(AARGaz3TqfNeKgrJ5mZcFEIQY9,ulAxHwvzR9eTb5n(u"ࠨ࡭ࡲࡨ࡮࠴࡬ࡰࡩࠪஒ"))
zAJlBVmpGHYQkd7LXDP = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(AARGaz3TqfNeKgrJ5mZcFEIQY9,QlTuvPbSpnjygBVW(u"ࠩ࡮ࡳࡩ࡯࠮ࡰ࡮ࡧ࠲ࡱࡵࡧࠨஓ"))
Eh67dFOcRbgCMl = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪ࡭ࡵࡺࡶ࠲ࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬஔ"))
IIUtvdg9HxyNPckQCD5KZfRuF6el1 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,QlTuvPbSpnjygBVW(u"ࠫ࡮ࡶࡴࡷ࠴ࡧࡥࡹࡧ࡟ࡠࡡ࠱ࡨࡧ࠭க"))
x3x6InJLgoyuNW2jOe5tzXKAhdYCmE = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡳ࠳ࡶࡦࡤࡸࡦࡥ࡟ࡠ࠰ࡧࡦࠬ஖"))
g8FzaRfU7Zx9HeSBNtJ = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,DJ6ugPjW9bX8I(u"࠭ࡦࡢࡸࡲࡹࡷ࡯ࡴࡦࡵ࠱ࡨࡦࡺࠧ஗"))
xxMHi17GvS2mdltQNozjIn8RgVBr = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡪࡲࡷࡺ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩ஘"))
mEbtRoNBzaGf1KAuLUW6n4Sh3C = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨ࡯࠶ࡹ࡫࡯࡬ࡦࡡࡢࡣ࠳ࡪࡡࡵࠩங"))
yi4Em23SQL9GNOBzXcshRV7wg6IUM0 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩ࡬ࡱࡦ࡭ࡥࡴࠩச"))
p4MKclUbAaVDi2mBv = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(yi4Em23SQL9GNOBzXcshRV7wg6IUM0,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡨ࡮ࡧ࡬ࡰࡩࡶࠫ஛"))
UWC1po65KvgulqE4rmTcMfHkwnxb = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(yi4Em23SQL9GNOBzXcshRV7wg6IUM0,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡶࠫஜ"))
uGlSeqMahrVHD6kdBAo4TCcy5nXxN = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(p4MKclUbAaVDi2mBv,X1mRwt2YJKgCLu9a67(u"ࠬࡪࡩࡢ࡮ࡲ࡫ࡤ࠶࠰࠱࠲ࡢ࠲ࡵࡴࡧࠨ஝"))
VK0O2udTgfH8Y3GyvhmqNQZDEx = IcJ2vm5AukNS1biO4Z.Addon().getAddonInfo(IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡰࡢࡶ࡫ࠫஞ"))
J625VDbMdSwfxNTFQG7 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,t4txivgXSUWBOlCakQmNDjf(u"ࠧࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩட"))
eLvCGIOrZWN62ByD = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡶ࡫ࡹࡲࡨ࠮ࡱࡰࡪࠫ஠"))
EEI3VXmAYg51qdcjthSWK = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭஡"))
pghAeRvKEFJ = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡦࡦࡴ࡮ࡦࡴ࠱ࡴࡳ࡭ࠧ஢"))
TTnlXGBVwqgFo1sAImuzDH0h = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,bYyKEjIuGQzoq3AR1(u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࠮ࡱࡰࡪࠫண"))
qyNOUd370ZB = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,z3sIGH8jmLYg(u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩத"))
CU29KsXOni0m5tjGBa = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,flDSRbv57PnV3(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰ࠰ࡳࡲ࡬࠭஥"))
OB5QUskXEZCvp8btfjlaL1M6YKRH9 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,UpQ56M0dO1N9xIvVegy(u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵ࠰ࡳࡲ࡬࠭஦"))
lxNkBjPrQhcILG2iqvAVfeWtd = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,YayJj10OGl(u"ࠨ࡯ࡨࡲࡺࡥࡲࡦࡦࡢ࠶࠵࠶ࡸ࠳࠷࠳࠲ࡵࡴࡧࠨ஧"))
B2B6NE1VSfA4y8irFwbeD = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡦ࡬ࡦࡴࡧࡦ࡮ࡲ࡫࠳ࡺࡸࡵࠩந"))
iPlfQr1JR08 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,YayJj10OGl(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪன"))
dSqtElDz6Z31pkRgKOaf5ch = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡺࡹࡥࡳࡦࡤࡸࡦ࠭ப"),tM24jD1gO0(u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩ஫"),ldJmEsIZY9A4pXStekwNoTV,X1mRwt2YJKgCLu9a67(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ஬"))
Go8OygdMhLX7k = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(x0K15dC9TEQLotSHYOBWU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧ࡮ࡧࡧ࡭ࡦ࠭஭"),qrjy8LuKVPNYdbSvzh(u"ࠨࡈࡲࡲࡹࡹࠧம"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡤࡶ࡮ࡧ࡬࠯ࡶࡷࡪࠬய"))
ll3QVqcTKFM8vygt9GAoJRDWe = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠹ፒ")
rto0iz1Gk2xAmICHDhqR6FPnMK = [yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ูࠪๆืࠧர"),YayJj10OGl(u"ࠫศ๎ไࠨற"),tM24jD1gO0(u"ࠬัว็์ࠪல"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭หศๆฮࠫள"),l4DS8mnEjHhFMZ5YOe(u"ࠧาษห฽ࠬழ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨะสุ้࠭வ"),I3cxjYaHhsrM7T4UX26klN(u"ࠩึหิูࠧஶ"),flDSRbv57PnV3(u"ࠪืฬฮูࠨஷ"),qrjy8LuKVPNYdbSvzh(u"ࠫะอๅ็ࠩஸ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠬะวิ฻ࠪஹ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ู࠭ศึิࠫ஺")]
h1D9iUur2YAR = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧ⸼ࠢ⼠ࠤⸯࠦ⸻ࠨ஻")
cYBv41PTnyJ8MUOS = [cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࡛ࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙ࠧ஼")]
sXzTGlAP1UFu = [DJ6ugPjW9bX8I(u"ࠩࡌࡊࡎࡒࡍࠨ஽"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩா"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫி")]
sXzTGlAP1UFu += [bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡇࡋࡘࡃࡐࠫீ"),cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨு"),X1mRwt2YJKgCLu9a67(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩூ"),tM24jD1gO0(u"ࠨࡃࡎࡓࡆࡓࠧ௃"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡈࡐࡈࡏࡎࡆࡏࡄࠫ௄")]
sXzTGlAP1UFu += [xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭௅"),qrjy8LuKVPNYdbSvzh(u"ࠫࡇࡕࡋࡓࡃࠪெ"),SSvu1CZjTW7FcloNqD(u"ࠬࡇࡒࡂࡄࡌࡇ࡙ࡕࡏࡏࡕࠪே"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠱ࠨை"),QlTuvPbSpnjygBVW(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠳ࠩ௉")]
iLHomVZCr16O3 = [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫொ"),Fo1SgXMsHk(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪோ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡐࡔࡊ࡙ࡏࡇࡗࠫௌ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ்࠭"),t4txivgXSUWBOlCakQmNDjf(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩ௎"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡋࡂࡖࡎࡓ࡙࡚ࡖࠨ௏"),SSvu1CZjTW7FcloNqD(u"ࠧࡔࡊࡒࡓࡋࡔࡅࡕࠩௐ")]
iLHomVZCr16O3 += [flDSRbv57PnV3(u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗࠪ௑"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡗ࡚ࡋ࡛ࡎࠨ௒"),tM24jD1gO0(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫ௓"),fgv5U2eRVaQqSiuGD(u"ࠫ࡜ࡋࡃࡊࡏࡄ࠶ࠬ௔"),qrjy8LuKVPNYdbSvzh(u"ࠬࡉࡉࡎࡃࡆࡐ࡚ࡈࠧ௕"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡌࡂࡔࡒ࡞ࡆ࠭௖")]
h6I2BxpiVwej75081Cqbsk = [YayJj10OGl(u"ࠧࡄࡋࡐࡅࡆࡈࡄࡐࠩௗ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪ௘"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬ௙"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡊࡔ࡙ࡔࡂࠩ௚"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡆࡎࡗࡂࡍࠪ௛"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭௜"),Fo1SgXMsHk(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠲ࠨ௝"),z3sIGH8jmLYg(u"ࠧࡄࡋࡐࡅࡋࡘࡅࡆࠩ௞"),flDSRbv57PnV3(u"ࠨࡘࡄࡖࡇࡕࡎࠨ௟"),fgv5U2eRVaQqSiuGD(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭௠")]
h6I2BxpiVwej75081Cqbsk += [q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡗࡍࡕࡆࡉࡃࠪ௡"),X1mRwt2YJKgCLu9a67(u"ࠫࡇࡘࡓࡕࡇࡍࠫ௢"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࡟ࡁࡒࡑࡗࠫ௣"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡄࡓࡃࡐࡅࡘ࠽ࠧ௤"),YayJj10OGl(u"ࠧࡄࡋࡐࡅ࠹࠶࠰ࠨ௥"),YayJj10OGl(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠶ࠪ௦"),SSvu1CZjTW7FcloNqD(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ௧"),QlTuvPbSpnjygBVW(u"ࠪࡅࡐ࡝ࡁࡎࡖࡘࡆࡊ࠭௨"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡆࡒࡍࡔࡖࡅࡅࠬ௩"),bYyKEjIuGQzoq3AR1(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬ௪"),QlTuvPbSpnjygBVW(u"࠭ࡆࡂࡔࡈࡗࡐࡕࠧ௫")]
h6I2BxpiVwej75081Cqbsk += [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡇࡗࡖࡌࡆࡘࡖࡊࡆࡈࡓࠬ௬"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡈࡘࡗࡍࡇࡒࡕࡘࠪ௭"),fgv5U2eRVaQqSiuGD(u"ࠩࡎࡍࡗࡓࡁࡍࡍࠪ௮"),Fo1SgXMsHk(u"ࠪࡈࡗࡇࡍࡂࡅࡄࡊࡊ࠭௯"),fgv5U2eRVaQqSiuGD(u"࡙ࠫࡏࡋࡂࡃࡗࠫ௰"),IINBvuxkCSJrO1Q0UyngdLi(u"࡙ࠬࡈࡂࡄࡄࡏࡆ࡚࡙ࠨ௱"),IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡁࡏࡋࡐࡉ࡟ࡏࡄࠨ௲"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡄࡋࡐࡅ࡜ࡈࡁࡔࠩ௳")]
h6I2BxpiVwej75081Cqbsk += [O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬ௴"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡉ࡙ࡓࡕࡎࡕࡘࠪ௵"),QlTuvPbSpnjygBVW(u"ࠪࡅ࡞ࡒࡏࡍࠩ௶"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧ௷"),SSvu1CZjTW7FcloNqD(u"ࠬࡓࡁࡔࡃ࡙ࡍࡉࡋࡏࠨ௸")]
y50l6ZCsEzLJ = [I3cxjYaHhsrM7T4UX26klN(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧ௹"),fgv5U2eRVaQqSiuGD(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡘࡌࡈࡊࡕࡓࠨ௺"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡓࡐࡆ࡟ࡌࡊࡕࡗࡗࠬ௻"),X1mRwt2YJKgCLu9a67(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡇࡍࡇࡎࡏࡇࡏࡗࠬ௼")]
y50l6ZCsEzLJ += [bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ௽"),X1mRwt2YJKgCLu9a67(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯࡙ࡍࡉࡋࡏࡔࠩ௾"),QlTuvPbSpnjygBVW(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰ࡔࡑࡇ࡙ࡍࡋࡖࡘࡘ࠭௿"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡈࡎࡁࡏࡐࡈࡐࡘ࠭ఀ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡒࡉࡗࡇࡖࠫఁ"),DJ6ugPjW9bX8I(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡈࡂࡕࡋࡘࡆࡍࡓࠨం")]
y50l6ZCsEzLJ += [cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡌࡔ࡙࡜ࠧః"),ulAxHwvzR9eTb5n(u"ࠪࡍࡕ࡚ࡖ࠮ࡎࡌ࡚ࡊ࠭ఄ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡎࡖࡔࡗ࠯ࡐࡓ࡛ࡏࡅࡔࠩఅ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡏࡐࡕࡘ࠰ࡗࡊࡘࡉࡆࡕࠪఆ")]
y50l6ZCsEzLJ += [cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡍ࠴ࡗࠪఇ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡎ࠵ࡘ࠱ࡑࡏࡖࡆࠩఈ"),fgv5U2eRVaQqSiuGD(u"ࠨࡏ࠶࡙࠲ࡓࡏࡗࡋࡈࡗࠬఉ"),z3sIGH8jmLYg(u"ࠩࡐ࠷࡚࠳ࡓࡆࡔࡌࡉࡘ࠭ఊ")]
flGNbLkwiOQ8526tnuydaeWgCH0R  = [YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡅࡐ࡝ࡁࡎࠩఋ"),DJ6ugPjW9bX8I(u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠭ఌ"),ulAxHwvzR9eTb5n(u"ࠬࡈࡏࡌࡔࡄࠫ఍"),bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡁࡌࡑࡄࡑࠬఎ"),z3sIGH8jmLYg(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃࠩఏ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡈࡄࡆࡗࡇࡋࡂࠩఐ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵ࠫ఑"),YayJj10OGl(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬఒ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡈࡏࡍࡂ࠶ࡓࠫఓ")]
flGNbLkwiOQ8526tnuydaeWgCH0R += [z3sIGH8jmLYg(u"ࠬࡉࡉࡎࡃࡉࡅࡓ࡙ࠧఔ"),fgv5U2eRVaQqSiuGD(u"࠭ࡃࡊࡏࡄࡐࡎࡍࡈࡕࠩక"),fgv5U2eRVaQqSiuGD(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨఖ"),SSvu1CZjTW7FcloNqD(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩగ"),YayJj10OGl(u"࡚ࠩࡉࡈࡏࡍࡂ࠴ࠪఘ"),fgv5U2eRVaQqSiuGD(u"ࠪࡗࡍࡇࡈࡊࡆࡑࡉ࡜࡙ࠧఙ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡋࡕࡓࡕࡃࠪచ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡇࡈࡘࡃࡎࠫఛ"),YayJj10OGl(u"࠭ࡓࡉࡑࡒࡊࡓࡋࡔࠨజ"),qrjy8LuKVPNYdbSvzh(u"ࠧࡔࡇࡕࡍࡊ࡙ࡔࡊࡏࡈࠫఝ")]
flGNbLkwiOQ8526tnuydaeWgCH0R += [qrjy8LuKVPNYdbSvzh(u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚ࠫఞ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚ࠬట"),SSvu1CZjTW7FcloNqD(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠵ࠬఠ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠷࠭డ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠺ࠧఢ"),fgv5U2eRVaQqSiuGD(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨణ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡂࡍ࡚ࡅࡒ࡚ࡕࡃࡇࠪత"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩథ")]
flGNbLkwiOQ8526tnuydaeWgCH0R += [UpQ56M0dO1N9xIvVegy(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪద"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬధ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠭న"),X1mRwt2YJKgCLu9a67(u"࡚ࠬࡖࡇࡗࡑࠫ఩"),IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨప"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡔࡊࡒࡊࡍࡇࠧఫ"),flDSRbv57PnV3(u"ࠨࡘࡄࡖࡇࡕࡎࠨబ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪభ")]
flGNbLkwiOQ8526tnuydaeWgCH0R += [QlTuvPbSpnjygBVW(u"ࠪࡆࡗ࡙ࡔࡆࡌࠪమ"),QlTuvPbSpnjygBVW(u"ࠫ࡞ࡇࡑࡐࡖࠪయ"),QlTuvPbSpnjygBVW(u"ࠬࡊࡒࡂࡏࡄࡗ࠼࠭ర"),IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡃࡊࡏࡄ࠸࠵࠶ࠧఱ"),z3sIGH8jmLYg(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬల"),QlTuvPbSpnjygBVW(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪళ"),I3cxjYaHhsrM7T4UX26klN(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫఴ"),SSvu1CZjTW7FcloNqD(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪవ")]
flGNbLkwiOQ8526tnuydaeWgCH0R += [z3sIGH8jmLYg(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩశ"),X1mRwt2YJKgCLu9a67(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧష"),bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡋࡊࡔࡐࡅࡑࡑࠧస"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪహ"),I3cxjYaHhsrM7T4UX26klN(u"ࠨࡖࡌࡏࡆࡇࡔࠨ఺"),qrjy8LuKVPNYdbSvzh(u"ࠩࡖࡌࡆࡈࡁࡌࡃࡗ࡝ࠬ఻"),l4DS8mnEjHhFMZ5YOe(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈ఼ࠬ"),I3cxjYaHhsrM7T4UX26klN(u"ࠫࡈࡏࡍࡂ࡙ࡅࡅࡘ࠭ఽ")]
VvRAZjszyKmM1NepLTFIOW  = [yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐ࠰࡚ࡎࡊࡅࡐࡕࠪా"),UpQ56M0dO1N9xIvVegy(u"࠭ࡄࡂࡋࡏ࡝ࡒࡕࡔࡊࡑࡑ࠱ࡕࡒࡁ࡚ࡎࡌࡗ࡙࡙ࠧి"),tM24jD1gO0(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲ࡉࡈࡂࡐࡑࡉࡑ࡙ࠧీ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳ࡌࡊࡘࡈࡗࠬు"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔ࠭ࡉࡃࡖࡌ࡙ࡇࡇࡔࠩూ")]
VvRAZjszyKmM1NepLTFIOW += [O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡍࡋࡏࡌࡎ࠯ࡄࡖࡆࡈࡉࡄࠩృ"),I3cxjYaHhsrM7T4UX26klN(u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡓࡍࡌࡊࡕࡋࠫౄ")]
VvRAZjszyKmM1NepLTFIOW += [tM24jD1gO0(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠳ࡖࡊࡆࡈࡓࡘ࠭౅"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡕࠪె"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡅࡋࡅࡓࡔࡅࡍࡕࠪే")]
VvRAZjszyKmM1NepLTFIOW += [CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡋࡓࡘ࡛࠳ࡌࡊࡘࡈࠫై"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡌࡔ࡙࡜࠭ࡎࡑ࡙ࡍࡊ࡙ࠧ౉"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡍࡕ࡚ࡖ࠮ࡕࡈࡖࡎࡋࡓࠨొ")]
VvRAZjszyKmM1NepLTFIOW += [flDSRbv57PnV3(u"ࠫࡒ࠹ࡕ࠮ࡎࡌ࡚ࡊ࠭ో"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡓ࠳ࡖ࠯ࡐࡓ࡛ࡏࡅࡔࠩౌ"),SSvu1CZjTW7FcloNqD(u"࠭ࡍ࠴ࡗ࠰ࡗࡊࡘࡉࡆࡕ్ࠪ")]
WK0RpSZO9VhPIiQ7kUb = [z3sIGH8jmLYg(u"ࠧࡎ࠵ࡘࠫ౎"),X1mRwt2YJKgCLu9a67(u"ࠨࡋࡓࡘ࡛࠭౏"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡇࡅࡎࡒ࡙ࡎࡑࡗࡍࡔࡔࠧ౐"),flDSRbv57PnV3(u"ࠪࡍࡋࡏࡌࡎࠩ౑"),DJ6ugPjW9bX8I(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ౒")]
dx4FLKQzHp3Rih7fnoackqbN = flGNbLkwiOQ8526tnuydaeWgCH0R+VvRAZjszyKmM1NepLTFIOW
bdUDyYZK6lieXvtP = flGNbLkwiOQ8526tnuydaeWgCH0R+WK0RpSZO9VhPIiQ7kUb
GuTMSOtQEwpbx = flGNbLkwiOQ8526tnuydaeWgCH0R+VvRAZjszyKmM1NepLTFIOW+cYBv41PTnyJ8MUOS
TltfNJPeVwqk5Bhvcmyn7pG = [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡖࡒࡊࡘࡄࡘࡊ࠭౓")]+sXzTGlAP1UFu+[X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡍࡊ࡚ࡈࡈࠬ౔")]+iLHomVZCr16O3+[SSvu1CZjTW7FcloNqD(u"ࠧࡑࡗࡅࡐࡎࡉౕࠧ")]+h6I2BxpiVwej75081Cqbsk+[X1mRwt2YJKgCLu9a67(u"ࠨࡒࡕࡍ࡛ࡇࡔࡆౖࠩ")]+y50l6ZCsEzLJ
kkbtlN2PnKsIXuH = [CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡄࡏࡔࡇࡍࠨ౗"),ulAxHwvzR9eTb5n(u"ࠪࡅࡐ࡝ࡁࡎࠩౘ"),bYyKEjIuGQzoq3AR1(u"ࠫࡎࡌࡉࡍࡏࠪౙ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖࠨౚ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨ౛"),qrjy8LuKVPNYdbSvzh(u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙ࠩ౜"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈࠫౝ"),QlTuvPbSpnjygBVW(u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ౞"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪࡈࡆࡏࡌ࡚ࡏࡒࡘࡎࡕࡎࠨ౟"),flDSRbv57PnV3(u"ࠫࡒ࠹ࡕࠨౠ"),qrjy8LuKVPNYdbSvzh(u"ࠬࡏࡐࡕࡘࠪౡ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡂࡐࡍࡕࡅࠬౢ"),z3sIGH8jmLYg(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩౣ"),I3cxjYaHhsrM7T4UX26klN(u"ࠨࡃࡕࡅࡇࡏࡃࡕࡑࡒࡒࡘ࠭౤")]
NOT_TO_TEST_ALL_SERVERS = [qrjy8LuKVPNYdbSvzh(u"ࠩࡢࡅࡐࡕ࡟ࠨ౥"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡣࡆࡑࡗࡠࠩ౦"),Fo1SgXMsHk(u"ࠫࡤࡏࡆࡍࡡࠪ౧"),X1mRwt2YJKgCLu9a67(u"ࠬࡥࡋࡓࡄࡢࠫ౨"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭࡟ࡎࡔࡉࡣࠬ౩"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡠࡕࡋࡑࡤ࠭౪"),flDSRbv57PnV3(u"ࠨࡡࡖࡌ࡛ࡥࠧ౫"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡢ࡝࡚࡚࡟ࠨ౬"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡣࡉࡒࡍࡠࠩ౭"),UpQ56M0dO1N9xIvVegy(u"ࠫࡤࡓࡕࠨ౮"),X1mRwt2YJKgCLu9a67(u"ࠬࡥࡉࡑࠩ౯"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭࡟ࡃࡍࡕࡣࠬ౰"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡠࡇࡏࡇࡤ࠭౱"),flDSRbv57PnV3(u"ࠨࡡࡄࡖ࡙ࡥࠧ౲")]
dl6eh2Jv5auoMj93gnwK1 = [
						bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡞ࡓࡉࡃࡕࡍࡓࡍ࠭࠲ࡵࡷࠫ౳")
						,ulAxHwvzR9eTb5n(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠴ࡱࡨࠬ౴")
						,X1mRwt2YJKgCLu9a67(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡗࡏࡘࡎࡥࡘࡔࡊࡄࡖࡎࡔࡇ࠮࠳ࡶࡸࠬ౵")
						]
nfm7agrTI9E = [
						DJ6ugPjW9bX8I(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡓࡆࡐࡇࡣࡆࡔࡁࡍ࡛ࡗࡍࡈ࡙࡟ࡆࡘࡈࡒ࡙࡙࠭࠲ࡵࡷࠫ౶")
						,ulAxHwvzR9eTb5n(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ౷")
						,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡄࡒࡉࡕࡍࡠࡗࡖࡉࡗࡇࡇࡆࡐࡗ࠱࠶ࡹࡴࠨ౸")
						,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ౹")
						,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡌࡔ࡙࡜࠭ࡄࡊࡈࡇࡐࡥࡁࡄࡅࡒ࡙ࡓ࡚࠭࠲ࡵࡷࠫ౺")
						,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠴ࡷࡹ࠭౻")
						,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠶ࡹࡴࠨ౼")
						,DJ6ugPjW9bX8I(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡎࡆ࡙ࡢࡌࡔ࡙ࡔࡏࡃࡐࡉ࠲࠹ࡲࡥࠩ౽")
						,bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡓࡇࡄࡈࡤࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠳࠱ࡴࡶࠪ౾")
						,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡔࡕࡇࡍࡇࡘࡗࡊࡘࡃࡐࡐࡗࡉࡓ࡚࠭࠲ࡵࡷࠫ౿")
						,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠸ࡸࡤࠨಀ")
						,fgv5U2eRVaQqSiuGD(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠻ࡴࡩࠩಁ")
						,l4DS8mnEjHhFMZ5YOe(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩಂ")
						,ulAxHwvzR9eTb5n(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ಃ")
						,l4DS8mnEjHhFMZ5YOe(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧ಄")
						]
W7gN5jFqiE = nfm7agrTI9E+[
				 tM24jD1gO0(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡑࡔࡒ࡜࡞ࡥࡔࡆࡕࡗ࠱࠶ࡹࡴࠨಅ")
				,DJ6ugPjW9bX8I(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡋࡘ࡙ࡖࡓࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬಆ")
				,flDSRbv57PnV3(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢ࡛ࡊࡈࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫಇ")
				,bYyKEjIuGQzoq3AR1(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜ࡎࡋࡓ࠮࠴ࡱࡨࠬಈ")
				,l4DS8mnEjHhFMZ5YOe(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐ࠯࠴ࡷࡹ࠭ಉ")
				,DJ6ugPjW9bX8I(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠶ࡳࡪࠧಊ")
				,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡌࡒࡕࡓ࡝࡟ࡃࡐࡏ࠰࠵ࡸࡺࠧಋ")
				,wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡍࡓࡖࡔ࡞࡙ࡄࡑࡐ࠱࠷ࡴࡤࠨಌ")
				,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠹ࡲࡥࠩ಍")
				,fgv5U2eRVaQqSiuGD(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡆࡌࡊࡉࡋࡠࡊࡗࡘࡕ࡙࡟ࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬಎ")
				,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱ࡍ࡚ࡔࡑࡕࡢࡘࡊ࡙ࡔ࠮࠳ࡶࡸࠬಏ")
				,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠴ࡷࡹ࠭ಐ")
				,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠶ࡳࡪࠧ಑")
				,z3sIGH8jmLYg(u"࡙ࠬࡅࡓࡘࡌࡇࡊ࡙࠭ࡖࡕࡄࡋࡊࡥࡒࡆࡒࡒࡖ࡙࠳࠱ࡴࡶࠪಒ")
				,qrjy8LuKVPNYdbSvzh(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡕࡔࡄࡒࡘࡒࡁࡕࡇ࠰࠵ࡸࡺࠧಓ")
				,DJ6ugPjW9bX8I(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡔࡈ࡚ࡊࡘࡓࡐࡡࡗࡖࡆࡔࡓࡍࡃࡗࡉ࠲࠷ࡳࡵࠩಔ")
				]
jUy8IAthCYOu5k = [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩಕ"),t4txivgXSUWBOlCakQmNDjf(u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪಖ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫಗ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬಘ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭ಙ"),IINBvuxkCSJrO1Q0UyngdLi(u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧಚ")]
sCSyOla9hrcE = {
			 fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡂࡊ࡚ࡅࡐ࠭ಛ")		:[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡷ࠳ࡧࡨࡸࡣ࡮ࡸࡻ࠴࡮ࡦࡶࠪಜ")]
			,YayJj10OGl(u"ࠩࡄࡏࡔࡇࡍࠨಝ")		:[SSvu1CZjTW7FcloNqD(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࠮ࡴࡸ࠲ࡳࡱࡪࠧಞ")]
			,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡆࡑࡗࡂࡏࠪಟ")		:[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡬࠰ࡶࡺࠬಠ")]
			,bYyKEjIuGQzoq3AR1(u"࠭ࡁࡌ࡙ࡄࡑ࡙࡛ࡂࡆࠩಡ")	:[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡫࠱ࡥࡰࡽࡡ࡮࠰ࡷࡹࡧ࡫ࠧಢ")]
			,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪಣ")		:[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡱࡳࡡࡢࡴࡨࡪ࠳ࡩࡨࠨತ")]
			,flDSRbv57PnV3(u"ࠪࡅࡑࡓࡓࡕࡄࡄࠫಥ")		:[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼ࡯ࡥ࠰ࡤࡰࡲࡹࡴࡣࡣ࠱ࡸࡻ࠭ದ")]
			,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡇࡎࡊࡏࡈ࡞ࡎࡊࠧಧ")		:[IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡰ࡬ࡱࡪࢀࡩࡥ࠰ࡶ࡬ࡴࡽࠧನ")]
			,l4DS8mnEjHhFMZ5YOe(u"ࠧࡂࡔࡄࡆࡎࡉࡔࡐࡑࡑࡗࠬ಩")	:[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡲࡢࡤ࡬ࡧ࠲ࡺ࡯ࡰࡰࡶ࠲ࡨࡵ࡭ࠨಪ")]
			,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇࠫಫ")		:[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡡࡣࡵࡨࡩࡩ࠴࡮ࡦࡶࠪಬ")]
			,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡆ࡟ࡌࡐࡎࠪಭ")		:[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦ࠰ࡤࡽࡱࡵ࡬࠯ࡰࡨࡸࠬಮ")]
			,DJ6ugPjW9bX8I(u"࠭ࡂࡐࡍࡕࡅࠬಯ")		:[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡪࡲࡳ࡫ࡼ࡯ࡥ࠰ࡦࡳࡲ࠭ರ")]
			,l4DS8mnEjHhFMZ5YOe(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨಱ")		:[t4txivgXSUWBOlCakQmNDjf(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡦࡷࡹࡴࡦ࡬࠱ࡧࡴࡳࠧಲ")]
			,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡇࡎࡓࡁ࠵࠲࠳ࠫಳ")		:[DJ6ugPjW9bX8I(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣ࠷࠴࠵࠴ࡣࡰ࡯ࠪ಴")]
			,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡉࡉࡎࡃ࠷ࡔࠬವ")		:[xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡦ࡭ࡲࡧ࠴ࡱ࠰ࡦࡳࡲ࠭ಶ")]
			,UpQ56M0dO1N9xIvVegy(u"ࠧࡄࡋࡐࡅ࠹࡛ࠧಷ")		:[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠴ࡧ࡮ࡳࡡ࠵ࡷ࠱ࡧࡴࡳࠧಸ")]
			,QlTuvPbSpnjygBVW(u"ࠩࡆࡍࡒࡇࡁࡃࡆࡒࠫಹ")		:[tM24jD1gO0(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢ࠵ࡥࡨࡴ࠴ࡣࡰ࡯ࠪ಺")]
			,UpQ56M0dO1N9xIvVegy(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭಻")		:[bYyKEjIuGQzoq3AR1(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡪ࡯ࡤࡧࡱࡻࡢ࠯ࡹࡤࡸࡨ࡮಼ࠧ")]
			,flDSRbv57PnV3(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࡘࡑࡕࡏࠬಽ")	:[t4txivgXSUWBOlCakQmNDjf(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶࡹࡺ࠳ࡩࡩ࡮ࡣࡦࡰࡺࡨ࠮ࡴࡪࡲࡴࠬಾ")]
			,qrjy8LuKVPNYdbSvzh(u"ࠨࡅࡌࡑࡆࡌࡁࡏࡕࠪಿ")		:[IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤ࡫ࡰࡥ࡫ࡧ࡮ࡴ࠰ࡦࡳࡲ࠭ೀ")]
			,UpQ56M0dO1N9xIvVegy(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬು")		:[ulAxHwvzR9eTb5n(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡩ࡮ࡣࡩࡶࡪ࡫࠮ࡷ࡫ࡳࠫೂ")]
			,flDSRbv57PnV3(u"ࠬࡉࡉࡎࡃࡏࡍࡌࡎࡔࠨೃ")	:[q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠴࠺࠲ࡲࡿ࠭ࡤ࡫ࡰࡥ࠳ࡴࡥࡵ࠱ࡰࡽࡨ࠷ࠧೄ")]
			,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨ೅")		:[IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࡮ࡰࡹ࠱ࡧࡨ࠭ೆ")]
			,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡆࡍࡒࡇࡗࡃࡃࡖࠫೇ")		:[t4txivgXSUWBOlCakQmNDjf(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨ࡯࡭ࡢࡹࡥࡥࡸ࠴࡭ࡺࡥ࡬ࡱࡦ࠴ࡣࡤࠩೈ")]
			,tM24jD1gO0(u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩ೉")	:[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬೊ"),fgv5U2eRVaQqSiuGD(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧೋ")]
			,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡅࡔࡄࡑࡆࡉࡁࡇࡇࠪೌ")	:[t4txivgXSUWBOlCakQmNDjf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺ࠶࠺࠴ࡤࡳࡣࡰࡥࡨࡧࡦࡦ࠯ࡷࡺ࠳ࡩ࡯࡮್ࠩ")]
			,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪ೎")		:[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡩ࠮ࡥࡴࡤࡱࡦࡹ࠷࠯ࡥࡲࡱࠬ೏")]
			,l4DS8mnEjHhFMZ5YOe(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭೐")		:[SSvu1CZjTW7FcloNqD(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠮ࡧࡷࡱࠫ೑")]
			,cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠲ࠨ೒")		:[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡺࡩࡧࡩࡡ࡮ࠩ೓")]
			,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪ೔")		:[QlTuvPbSpnjygBVW(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡭ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡨࡩࡥࠩೕ")]
			,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࠸ࠬೖ")		:[flDSRbv57PnV3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺ࠯ࡥࡩࡸࡺ࠮࡯ࡧࡷࠫ೗")]
			,bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡋࡇ࡚ࡆࡈࡅࡉ࠭೘")		:[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡨࡪࡧࡤ࠯࡮࡬ࡺࡪ࠭೙")]
			,ulAxHwvzR9eTb5n(u"ࠧࡆࡎࡆࡍࡓࡋࡍࡂࠩ೚")		:[bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡰࡨ࡯࡮ࡦ࡯ࡤ࠲ࡨࡵ࡭ࠨ೛")]
			,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡈࡐࡎࡌࡖࡊࡆࡈࡓࠬ೜")	:[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧ࠲ࡪࡲࡩࡧ࠰ࡱࡩࡼࡹࠧೝ")]
			,ulAxHwvzR9eTb5n(u"ࠫࡋࡇࡂࡓࡃࡎࡅࠬೞ")		:[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢࡤࡵ࡯ࡦ࠴ࡣࡰ࡯ࠪ೟")]
			,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩೠ")	:[I3cxjYaHhsrM7T4UX26klN(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨࡤ࡮ࡪࡸ࠮ࡴࡪࡲࡻࠬೡ")]
			,qrjy8LuKVPNYdbSvzh(u"ࠨࡈࡄࡖࡊ࡙ࡋࡐࠩೢ")		:[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡶ࠮ࡧࡣࡵࡩࡸࡱ࡯࠯ࡰࡨࡸࠬೣ")]
			,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠶ࠬ೤")		:[UpQ56M0dO1N9xIvVegy(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡳ࡭ࡣ࠱ࡪࡦࡹࡥ࡭ࡪࡧ࠲ࡨࡲ࡯ࡶࡦࠪ೥")]
			,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡌࡏࡔࡖࡄࠫ೦")		:[t4txivgXSUWBOlCakQmNDjf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹ࡭࠲࡫ࡵࡳࡵࡣ࠰ࡸࡻ࠴࡮ࡦࡶࠪ೧")]
			,l4DS8mnEjHhFMZ5YOe(u"ࠧࡇࡗࡑࡓࡓ࡚ࡖࠨ೨")		:[flDSRbv57PnV3(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡪ࠲ࡦࡲ࡭ࡦࡵ࡫࡯ࡦ࡮࠮࡯ࡧࡷࠫ೩")]
			,bYyKEjIuGQzoq3AR1(u"ࠩࡉ࡙ࡘࡎࡁࡓࡖ࡙ࠫ೪")		:[flDSRbv57PnV3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡧ࠴ࡦࡶࡵ࡫ࡥࡷ࠳ࡴࡷ࠰ࡦࡳࡲ࠭೫")]
			,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡋ࡛ࡓࡉࡃࡕ࡚ࡎࡊࡅࡐࠩ೬")	:[ulAxHwvzR9eTb5n(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡨࡸࡷ࡭ࡧࡲ࠯ࡸ࡬ࡨࡪࡵࠧ೭")]
			,ulAxHwvzR9eTb5n(u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ೮")		:[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡱࡪࡪࡩࡢࠩ೯")]
			,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡋࡉࡍࡑࡓࠧ೰")		:[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷ࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡪࡴࠪೱ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪࡴ࠮ࡪࡨ࡬ࡰࡲࡺࡶ࠯࡫ࡵࠫೲ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡡ࠯࡫ࡩ࡭ࡱࡳࡴࡷ࠰࡬ࡶࠬೳ"),fgv5U2eRVaQqSiuGD(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡢ࠴࠱࡭࡫࡯࡬࡮ࡶࡹ࠲࡮ࡸࠧ೴"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠹࠴࠰࠴࠽࠵࠴࠲࠵࠰࠴࠶࠷࠭೵")]
			,I3cxjYaHhsrM7T4UX26klN(u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ೶")	:[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡥࡷࡨࡡ࡭ࡣ࠰ࡸࡻ࠴ࡩࡲࠩ೷")]
			,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡎࡅ࡙ࡑࡏࡕࡖ࡙ࠫ೸")		:[X1mRwt2YJKgCLu9a67(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡬ࡵ࡯࠯࡭࡬ࡸࡰࡵࡴ࠯ࡶࡹࠫ೹")]
			,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡐࡏࡒࡎࡃࡏࡏࠬ೺")		:[ulAxHwvzR9eTb5n(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡶ࠰࡮࡭ࡷࡳࡡ࡭࡭࠱ࡧࡴࡳࠧ೻")]
			,fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡋࡐࡆࡌࡉࡒࡇࡄࡠࡃࡓࡔࠬ೼")	:[fgv5U2eRVaQqSiuGD(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡶ࡬ࡲࡾ࠴ࡣࡤ࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧࠫ೽"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ࠲࠱࠳࠻࠲࡫ࡽࡳ࠯ࡵࡷࡳࡷ࡫ࠧ೾")]
			,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡏࡅࡗࡕ࡚ࡂࠩ೿")		:[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡧࡲࡰࡼࡤ࠲࡮ࡴࡦࡰࠩഀ")]
			,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫࡑࡕࡄ࡚ࡐࡈࡘࠬഁ")		:[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡦࡼࡲࡪࡺ࠮࡭࡫ࡱ࡯ࠬം")]
			,Fo1SgXMsHk(u"࠭ࡍࡂࡕࡄ࡚ࡎࡊࡅࡐࠩഃ")	:[ulAxHwvzR9eTb5n(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡳࡡࡴࡣࡹ࡭ࡩ࡫࡯࠯ࡰࡨࡻࡸ࠭ഄ")]
			,qrjy8LuKVPNYdbSvzh(u"ࠨࡒࡄࡒࡊ࡚ࠧഅ")		:[tM24jD1gO0(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡰࡢࡰࡨࡸ࠳ࡩ࡯࠯࡫࡯ࠫആ")]
			,DJ6ugPjW9bX8I(u"ࠪࡖࡊࡒࡅࡂࡕࡈࡗࠬഇ")		:[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡴࡷࡵ࡫ࡪ࠴ࡳࡩ࠱࡮ࡳࡩ࡯࠯ࡦ࡯ࡤࡨࡤࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶ࠳ࡔࡒࡄ࠰࡫ࡱࡨࡪࡾ࠮ࡩࡶࡰࡰࠬഈ")]
			,z3sIGH8jmLYg(u"࡙ࠬࡅࡓࡋࡈࡗ࡙ࡏࡍࡆࠩഉ")	:[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡣ࠱ࡷࡪࡸࡩࡦࡵࡷ࡭ࡲ࡫࠮ࡤࡣࡰࠫഊ")]
			,bYyKEjIuGQzoq3AR1(u"ࠧࡔࡊࡄࡆࡆࡑࡁࡕ࡛ࠪഋ")	:[I3cxjYaHhsrM7T4UX26klN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࠲ࡘࡎࡁࡃࡃࡎࡅ࡙࡟࠮ࡷ࡫ࡳࠫഌ")]
			,qrjy8LuKVPNYdbSvzh(u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ഍")		:[X1mRwt2YJKgCLu9a67(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡥࡥ࠶ࡸ࠶࠳ࡩ࡯࡮ࠩഎ")]
			,YayJj10OGl(u"ࠫࡘࡎࡁࡉࡋࡇࡒࡊ࡝ࡓࠨഏ")	:[l4DS8mnEjHhFMZ5YOe(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥ࠯ࡵ࡫࠸ࡺ࠴࡮ࡦࡹࡶࠫഐ")]
			,QlTuvPbSpnjygBVW(u"࠭ࡓࡉࡑࡉࡌࡆ࠭഑")		:[flDSRbv57PnV3(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡹࡨࡰࡨ࡫ࡥ࠳ࡺࡶࠨഒ")]
			,t4txivgXSUWBOlCakQmNDjf(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪഓ")		:[qrjy8LuKVPNYdbSvzh(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩഔ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪക"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡱࡩࡱࡦࡾ࠮ࡢࡼࡸࡶࡪ࡫ࡤࡨࡧ࠱ࡲࡪࡺࠧഖ")]
			,flDSRbv57PnV3(u"࡙ࠬࡈࡐࡑࡉࡒࡊ࡚ࠧഗ")		:[bYyKEjIuGQzoq3AR1(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡵ࠱ࡥࡰࡽࡡ࡮࠰ࡷࡹࡧ࡫ࠧഘ")]
			,SSvu1CZjTW7FcloNqD(u"ࠧࡕࡋࡎࡅࡆ࡚ࠧങ")		:[t4txivgXSUWBOlCakQmNDjf(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡴࡪ࡭ࡤࡥࡹ࠴࡮ࡦࡶࠪച")]
			,fgv5U2eRVaQqSiuGD(u"ࠩࡗ࡚ࡋ࡛ࡎࠨഛ")		:[UpQ56M0dO1N9xIvVegy(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡨࡸࡲ࠳ࡳࡥࠨജ")]
			,SSvu1CZjTW7FcloNqD(u"࡛ࠫࡇࡒࡃࡑࡑࠫഝ")		:[DJ6ugPjW9bX8I(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭࠯ࡸࡤࡶࡧࡵ࡮࠯ࡥࡤࡱࠬഞ")]
			,DJ6ugPjW9bX8I(u"࠭ࡖࡊࡆࡈࡓࡓ࡙ࡁࡆࡏࠪട")	:[z3sIGH8jmLYg(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠮࡯ࡵࡤࡩࡲ࠴࡮ࡦࡶࠪഠ")]
			,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨ࡙ࡈࡇࡎࡓࡁ࠲ࠩഡ")		:[flDSRbv57PnV3(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡪࡩࡩ࡮ࡣ࠱ࡷ࡭ࡵࡷࠨഢ")]
			,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫണ")		:[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡤ࡫ࡰࡥ࠳ࡩ࡬ࡪࡥ࡮ࠫത")]
			,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬ࡟ࡁࡒࡑࡗࠫഥ")		:[fgv5U2eRVaQqSiuGD(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺ࠰ࡼࡥࡶࡵࡴ࠯ࡶࡹࠫദ")]
			,ulAxHwvzR9eTb5n(u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࠨധ")		:[I3cxjYaHhsrM7T4UX26klN(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰࠫന")]
			,flDSRbv57PnV3(u"ࠩࡕࡉࡕࡕࡓࠨഩ")		:[ulAxHwvzR9eTb5n(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴࡮ࡦࡶ࡯࡭࡫ࡿ࠮ࡢࡲࡳ࠳ࡐࡕࡄࡊࡔࡈࡔࡔ࠵ࡁࡅࡆࡒࡒࡘ࠵ࡡࡥࡦࡲࡲࡸ࠴ࡸ࡮࡮ࠪപ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮࡯ࡧࡷࡰ࡮࡬ࡹ࠯ࡣࡳࡴ࠴ࡑࡏࡅࡋࡕࡉࡕࡕ࠯ࡂࡆࡇࡓࡓ࡙࠱࠹࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠻࠲ࡽࡳ࡬ࠨഫ"),t4txivgXSUWBOlCakQmNDjf(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡰࡨࡸࡱ࡯ࡦࡺ࠰ࡤࡴࡵ࠵ࡋࡐࡆࡌࡖࡊࡖࡏ࠰ࡃࡇࡈࡔࡔࡓ࠲࠻࠲ࡥࡩࡪ࡯࡯ࡵ࠴࠽࠳ࡾ࡭࡭ࠩബ")]
			,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡒࡆࡒࡒࡗࡤࡈࡋࡑࠩഭ")	:[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡷ࡫ࡰࡰ࠰ࡸ࡯࠳ࡺ࡯࠰ࡃࡇࡈࡔࡔࡓ࠰ࡣࡧࡨࡴࡴࡳ࠯ࡺࡰࡰࠬമ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮ࡸࡥࡱࡱ࠱ࡹࡰ࠴ࡴࡰ࠱ࡄࡈࡉࡕࡎࡔ࠳࠻࠳ࡦࡪࡤࡰࡰࡶ࠵࠽࠴ࡸ࡮࡮ࠪയ"),t4txivgXSUWBOlCakQmNDjf(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡲࡦࡲࡲ࠲ࡺࡱ࠮ࡵࡱ࠲ࡅࡉࡊࡏࡏࡕ࠴࠽࠴ࡧࡤࡥࡱࡱࡷ࠶࠿࠮ࡹ࡯࡯ࠫര")]
			,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡗࡔ࡛ࡒࡄࡇࡖࠫറ")		:[flDSRbv57PnV3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵࡫ࡰࡦ࡬ࠫല"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡵࡸࡶ࡬࡫࠮ࡴࡪࠪള"),t4txivgXSUWBOlCakQmNDjf(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡱࡩࡹࡲࡩࡧࡻ࠱ࡥࡵࡶ࠯ࡌࡑࡇࡍࡗࡋࡐࡐࠩഴ")]
			}
if vkIa3ijEQVsJGdWOXwK7bnue9ADR:
	sCSyOla9hrcE[QlTuvPbSpnjygBVW(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧവ")] = [YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪശ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧഷ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭സ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡷࡧࡵࡧࡪࡲ࠮ࡢࡲࡳ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩഹ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡸࡨࡶࡨ࡫࡬࠯ࡣࡳࡴ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩഺ"),DJ6ugPjW9bX8I(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡹࡩࡷࡩࡥ࡭࠰ࡤࡴࡵ࠵ࡧࡦࡶࡴࡹࡪࡹࡴࡪࡱࡱࡷ഻ࠬ"),SSvu1CZjTW7FcloNqD(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡺࡪࡸࡣࡦ࡮࠱ࡥࡵࡶ࠯ࡨࡧࡷ࡯ࡳࡵࡷ࡯ࡧࡵࡶࡴࡸࡳࠨ഼"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡻ࡫ࡲࡤࡧ࡯࠲ࡦࡶࡰ࠰ࡥࡤࡴࡹࡩࡨࡢࠩഽ"),QlTuvPbSpnjygBVW(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡼࡥࡳࡥࡨࡰ࠳ࡧࡰࡱ࠱ࡷࡩࡸࡺࡩ࡯ࡩࠪാ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡶࡦࡴࡦࡩࡱ࠴ࡡࡱࡲ࠲࡫ࡪࡺࡥࡹࡶࡵࡥࡵࡿࡴࡩࡱࡱࡧࡴࡪࡥࠨി")]
	sCSyOla9hrcE[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡕ࡟ࡔࡉࡑࡑࡣࡇࡑࡐࠨീ")] = [tM24jD1gO0(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵࡬ࡪࡵࡷࡴࡱࡧࡹࠨു"),cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡶࡵࡤ࡫ࡪࡸࡥࡱࡱࡵࡸࠬൂ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡵࡨࡲࡩ࡫࡭ࡢ࡫࡯ࠫൃ"),X1mRwt2YJKgCLu9a67(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡭ࡲࡨ࡮࡫࡭ࡢࡦ࠱ࡹࡰ࠴ࡴࡰ࠱ࡪࡩࡹࡳࡥࡴࡵࡤ࡫ࡪࡹࠧൄ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡮ࡳࡩ࡯ࡥ࡮ࡣࡧ࠲ࡺࡱ࠮ࡵࡱ࠲࡫ࡪࡺࡩࡴ࡮ࡤࡱ࡮ࡩࠧ൅"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡦ࡯ࡤࡨ࠳ࡻ࡫࠯ࡶࡲ࠳࡬࡫ࡴࡲࡷࡨࡷࡹ࡯࡯࡯ࡵࠪെ"),flDSRbv57PnV3(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡵࡤࡪࡧࡰࡥࡩ࠴ࡵ࡬࠰ࡷࡳ࠴࡭ࡥࡵ࡭ࡱࡳࡼࡴࡥࡳࡴࡲࡶࡸ࠭േ"),QlTuvPbSpnjygBVW(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱ࡯ࡥ࡫ࡨࡱࡦࡪ࠮ࡶ࡭࠱ࡸࡴ࠵ࡣࡢࡲࡷࡧ࡭ࡧࠧൈ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࠯ࡷ࡮࠲ࡹࡵ࠯ࡵࡧࡶࡸ࡮ࡴࡧࠨ൉"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࠰ࡸ࡯࠳ࡺ࡯࠰ࡩࡨࡸࡪࡾࡴࡳࡣࡳࡽࡹ࡮࡯࡯ࡥࡲࡨࡪ࠭ൊ")]
else:
	sCSyOla9hrcE[UpQ56M0dO1N9xIvVegy(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨോ")] = [Fo1SgXMsHk(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡰ࡮ࡹࡴࡱ࡮ࡤࡽࠬൌ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡺࡹࡡࡨࡧࡵࡩࡵࡵࡲࡵ്ࠩ"),QlTuvPbSpnjygBVW(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴ࡹࡥ࡯ࡦࡨࡱࡦ࡯࡬ࠨൎ"),UpQ56M0dO1N9xIvVegy(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶࡰࡩࡸࡹࡡࡨࡧࡶࠫ൏"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡨࡧࡷ࡭ࡸࡲࡡ࡮࡫ࡦࠫ൐"),t4txivgXSUWBOlCakQmNDjf(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡩࡨࡸࡶࡻࡥࡴࡶ࡬ࡳࡳࡹࠧ൑"),UpQ56M0dO1N9xIvVegy(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹࡱ࡮ࡰࡹࡱࡩࡷࡸ࡯ࡳࡵࠪ൒"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲ࡧࡦࡶࡴࡤࡪࡤࠫ൓"),t4txivgXSUWBOlCakQmNDjf(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳ࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬൔ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡧࡻࡸࡷࡧࡰࡺࡶ࡫ࡳࡳࡩ࡯ࡥࡧࠪൕ")]
	sCSyOla9hrcE[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩൖ")] = [I3cxjYaHhsrM7T4UX26klN(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯࡭࡫ࡶࡸࡵࡲࡡࡺࠩൗ"),ulAxHwvzR9eTb5n(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡷࡶࡥ࡬࡫ࡲࡦࡲࡲࡶࡹ࠭൘"),z3sIGH8jmLYg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡶࡩࡳࡪࡥ࡮ࡣ࡬ࡰࠬ൙"),z3sIGH8jmLYg(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠶࠼࠴࠰࠯࠲࠱࠵࠿࠻࠰࠱࠲࠲࡫ࡪࡺ࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ൚"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠷࠽࠮࠱࠰࠳࠲࠶ࡀ࠵࠱࠲࠳࠳࡬࡫ࡴࡪࡵ࡯ࡥࡲ࡯ࡣࠨ൛"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠸࠷࠯࠲࠱࠴࠳࠷࠺࠶࠲࠳࠴࠴࡭ࡥࡵࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ൜"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠲࠸࠰࠳࠲࠵࠴࠱࠻࠷࠳࠴࠵࠵ࡧࡦࡶ࡮ࡲࡴࡽ࡮ࡦࡴࡵࡳࡷࡹࠧ൝"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠳࠹࠱࠴࠳࠶࠮࠲࠼࠸࠴࠵࠶࠯ࡤࡣࡳࡸࡨ࡮ࡡࠨ൞"),UpQ56M0dO1N9xIvVegy(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠴࠺࠲࠵࠴࠰࠯࠳࠽࠹࠵࠶࠰࠰ࡶࡨࡷࡹ࡯࡮ࡨࠩൟ"),DJ6ugPjW9bX8I(u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠵࠻࠳࠶࠮࠱࠰࠴࠾࠺࠶࠰࠱࠱ࡪࡩࡹ࡫ࡸࡵࡴࡤࡴࡾࡺࡨࡰࡰࡦࡳࡩ࡫ࠧൠ")]
VdLvezkAg9 = [flDSRbv57PnV3(u"ࠩࡏࡍࡘ࡚ࡐࡍࡃ࡜ࠫൡ"),bYyKEjIuGQzoq3AR1(u"ࠪࡖࡊࡖࡏࡓࡖࡖࠫൢ"),tM24jD1gO0(u"ࠫࡊࡓࡁࡊࡎࡖࠫൣ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧ൤"),SSvu1CZjTW7FcloNqD(u"࠭ࡉࡔࡎࡄࡑࡎࡉࡓࠨ൥"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ൦"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡍࡑࡓ࡜ࡔࡅࡓࡔࡒࡖࡘ࠭൧"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡆࡅࡕ࡚ࡃࡉࡃࠪ൨"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡘࡊ࡙ࡔࡊࡐࡊࠫ൩"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭൪")]
nNJReWPO2VqzBymsZjGDhdr8MFg1 = [DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡇࡄࡅࡑࡑࡗࠬ൫"),UpQ56M0dO1N9xIvVegy(u"࠭ࡁࡅࡆࡒࡒࡘ࠷࠸ࠨ൬"),t4txivgXSUWBOlCakQmNDjf(u"ࠧࡂࡆࡇࡓࡓ࡙࠱࠺ࠩ൭")]
class eDQpxkXECKPv726ary3oJN(rRoSZPg8iW5NdFXjp):
	def __init__(S8GDrz3gxJMeYBF2o4c,*aargs,**kkwargs):
		S8GDrz3gxJMeYBF2o4c.choiceID = -vkIa3ijEQVsJGdWOXwK7bnue9ADR
	def onClick(S8GDrz3gxJMeYBF2o4c,V9ERixGY3XnbcI1Mkm2ozWtNT):
		if V9ERixGY3XnbcI1Mkm2ozWtNT>=tM24jD1gO0(u"࠾࠶࠱࠱ፓ"): S8GDrz3gxJMeYBF2o4c.choiceID = V9ERixGY3XnbcI1Mkm2ozWtNT-tM24jD1gO0(u"࠾࠶࠱࠱ፓ")
		S8GDrz3gxJMeYBF2o4c.V8eWxOPEoKcR4sHCqi0dITMD()
	def SunQIhtaHzidgwLM(S8GDrz3gxJMeYBF2o4c,*aargs):
		S8GDrz3gxJMeYBF2o4c.button0,S8GDrz3gxJMeYBF2o4c.button1,S8GDrz3gxJMeYBF2o4c.button2 = aargs[f4fTutDOEwUeIoPLRQ],aargs[vkIa3ijEQVsJGdWOXwK7bnue9ADR],aargs[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		S8GDrz3gxJMeYBF2o4c.header,S8GDrz3gxJMeYBF2o4c.text = aargs[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb],aargs[WtDrnpJmwQ37Z2Ae68hu4BY5M1]
		S8GDrz3gxJMeYBF2o4c.profile,S8GDrz3gxJMeYBF2o4c.direction = aargs[l4DS8mnEjHhFMZ5YOe(u"࠻ፔ")],aargs[X1mRwt2YJKgCLu9a67(u"࠶ፕ")]
		S8GDrz3gxJMeYBF2o4c.buttonstimeout,S8GDrz3gxJMeYBF2o4c.closetimeout = aargs[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠹ፗ")],aargs[q4izXt0sjIQSZcHVAf3EmKRbx(u"࠹ፖ")]
		if S8GDrz3gxJMeYBF2o4c.buttonstimeout>f4fTutDOEwUeIoPLRQ or S8GDrz3gxJMeYBF2o4c.closetimeout>DJ6ugPjW9bX8I(u"࠳ፘ"): S8GDrz3gxJMeYBF2o4c.enable_progressbar = Ag9l6cw3EBqP8HsQuGMizfOtr4
		else: S8GDrz3gxJMeYBF2o4c.enable_progressbar = SmbNGskjMx
		S8GDrz3gxJMeYBF2o4c.image_filename = uGlSeqMahrVHD6kdBAo4TCcy5nXxN.replace(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨ൮"),tM24jD1gO0(u"ࠩࡢࠫ൯")+str(lQMuw1PvVpAk.time())+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡣࠬ൰"))
		S8GDrz3gxJMeYBF2o4c.image_filename = S8GDrz3gxJMeYBF2o4c.image_filename.replace(bYyKEjIuGQzoq3AR1(u"ࠫࡡࡢࠧ൱"),Fo1SgXMsHk(u"ࠬࡢ࡜࡝࡞ࠪ൲")).replace(l4DS8mnEjHhFMZ5YOe(u"࠭࠯࠰ࠩ൳"),fgv5U2eRVaQqSiuGD(u"ࠧ࠰࠱࠲࠳ࠬ൴"))
		S8GDrz3gxJMeYBF2o4c.image_height = u4IWfU1ashntg3T(S8GDrz3gxJMeYBF2o4c.button0,S8GDrz3gxJMeYBF2o4c.button1,S8GDrz3gxJMeYBF2o4c.button2,S8GDrz3gxJMeYBF2o4c.header,S8GDrz3gxJMeYBF2o4c.text,S8GDrz3gxJMeYBF2o4c.profile,S8GDrz3gxJMeYBF2o4c.direction,S8GDrz3gxJMeYBF2o4c.enable_progressbar,S8GDrz3gxJMeYBF2o4c.image_filename)
		S8GDrz3gxJMeYBF2o4c.show()
		S8GDrz3gxJMeYBF2o4c.getControl(ulAxHwvzR9eTb5n(u"࠽࠵࠻࠰ፙ")).setImage(S8GDrz3gxJMeYBF2o4c.image_filename)
		S8GDrz3gxJMeYBF2o4c.getControl(IINBvuxkCSJrO1Q0UyngdLi(u"࠾࠶࠵࠱ፚ")).setHeight(S8GDrz3gxJMeYBF2o4c.image_height)
		if not S8GDrz3gxJMeYBF2o4c.button1 and S8GDrz3gxJMeYBF2o4c.button0 and S8GDrz3gxJMeYBF2o4c.button2: S8GDrz3gxJMeYBF2o4c.getControl(bYyKEjIuGQzoq3AR1(u"࠹࠱࠳࠵፜")).setPosition(-QlTuvPbSpnjygBVW(u"࠳࠴࠳፝"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠶፛"))
		return S8GDrz3gxJMeYBF2o4c.image_filename,S8GDrz3gxJMeYBF2o4c.image_height
	def FnmT0NgaBiHGyKRpSqsP2Z7EuD(S8GDrz3gxJMeYBF2o4c):
		if S8GDrz3gxJMeYBF2o4c.buttonstimeout:
			S8GDrz3gxJMeYBF2o4c.th1 = eb6R0h1Fjl.Thread(target=S8GDrz3gxJMeYBF2o4c.OOfXVUH8cqlnoyG4ji,args=())
			S8GDrz3gxJMeYBF2o4c.th1.start()
		else: S8GDrz3gxJMeYBF2o4c.JVdDRQZfvkrzm0GPKFMbXxw2I3()
	def OOfXVUH8cqlnoyG4ji(S8GDrz3gxJMeYBF2o4c):
		S8GDrz3gxJMeYBF2o4c.getControl(I3cxjYaHhsrM7T4UX26klN(u"࠻࠳࠶࠵፞")).setEnabled(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		for HT4fGXqv8hEcKsJ in range(vkIa3ijEQVsJGdWOXwK7bnue9ADR,S8GDrz3gxJMeYBF2o4c.buttonstimeout+vkIa3ijEQVsJGdWOXwK7bnue9ADR):
			lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
			I3DaWuvcG9L0lQ6pkgXy = int(bYyKEjIuGQzoq3AR1(u"࠴࠴࠵፟")*HT4fGXqv8hEcKsJ/S8GDrz3gxJMeYBF2o4c.buttonstimeout)
			S8GDrz3gxJMeYBF2o4c.kYqK8nORyo3(I3DaWuvcG9L0lQ6pkgXy)
			if S8GDrz3gxJMeYBF2o4c.choiceID>cb3rmvAn4wa6lBPz2phOoYqX(u"࠴፠"): break
		S8GDrz3gxJMeYBF2o4c.JVdDRQZfvkrzm0GPKFMbXxw2I3()
	def RdCY3r5JBHa2SuGon9Liz(S8GDrz3gxJMeYBF2o4c):
		if S8GDrz3gxJMeYBF2o4c.closetimeout:
			S8GDrz3gxJMeYBF2o4c.th2 = eb6R0h1Fjl.Thread(target=S8GDrz3gxJMeYBF2o4c.EcYosbrFJhk3eZ1,args=())
			S8GDrz3gxJMeYBF2o4c.th2.start()
		else: S8GDrz3gxJMeYBF2o4c.JVdDRQZfvkrzm0GPKFMbXxw2I3()
	def EcYosbrFJhk3eZ1(S8GDrz3gxJMeYBF2o4c):
		S8GDrz3gxJMeYBF2o4c.getControl(flDSRbv57PnV3(u"࠾࠶࠲࠱፡")).setEnabled(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		lQMuw1PvVpAk.sleep(S8GDrz3gxJMeYBF2o4c.buttonstimeout)
		for HT4fGXqv8hEcKsJ in range(S8GDrz3gxJMeYBF2o4c.closetimeout-vkIa3ijEQVsJGdWOXwK7bnue9ADR,-vkIa3ijEQVsJGdWOXwK7bnue9ADR,-vkIa3ijEQVsJGdWOXwK7bnue9ADR):
			lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
			I3DaWuvcG9L0lQ6pkgXy = int(t4txivgXSUWBOlCakQmNDjf(u"࠷࠰࠱።")*HT4fGXqv8hEcKsJ/S8GDrz3gxJMeYBF2o4c.closetimeout)
			S8GDrz3gxJMeYBF2o4c.kYqK8nORyo3(I3DaWuvcG9L0lQ6pkgXy)
			if S8GDrz3gxJMeYBF2o4c.choiceID>f4fTutDOEwUeIoPLRQ: break
		if S8GDrz3gxJMeYBF2o4c.closetimeout>f4fTutDOEwUeIoPLRQ: S8GDrz3gxJMeYBF2o4c.choiceID = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠱࠱፣")
		S8GDrz3gxJMeYBF2o4c.V8eWxOPEoKcR4sHCqi0dITMD()
	def kYqK8nORyo3(S8GDrz3gxJMeYBF2o4c,I3DaWuvcG9L0lQ6pkgXy):
		S8GDrz3gxJMeYBF2o4c.precent = I3DaWuvcG9L0lQ6pkgXy
		S8GDrz3gxJMeYBF2o4c.getControl(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠺࠲࠵࠴፤")).setPercent(S8GDrz3gxJMeYBF2o4c.precent)
	def JVdDRQZfvkrzm0GPKFMbXxw2I3(S8GDrz3gxJMeYBF2o4c):
		if S8GDrz3gxJMeYBF2o4c.button0: S8GDrz3gxJMeYBF2o4c.getControl(SSvu1CZjTW7FcloNqD(u"࠻࠳࠵࠵፥")).setEnabled(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		if S8GDrz3gxJMeYBF2o4c.button1: S8GDrz3gxJMeYBF2o4c.getControl(YayJj10OGl(u"࠼࠴࠶࠷፦")).setEnabled(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		if S8GDrz3gxJMeYBF2o4c.button2: S8GDrz3gxJMeYBF2o4c.getControl(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠽࠵࠷࠲፧")).setEnabled(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	def V8eWxOPEoKcR4sHCqi0dITMD(S8GDrz3gxJMeYBF2o4c):
		S8GDrz3gxJMeYBF2o4c.close()
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(S8GDrz3gxJMeYBF2o4c.image_filename)
		except: pass
class ps6AtMmOZI5izVcr4hF0xn9TJE7RL():
	def __init__(S8GDrz3gxJMeYBF2o4c,showDialogs=SmbNGskjMx,logErrors=Ag9l6cw3EBqP8HsQuGMizfOtr4):
		S8GDrz3gxJMeYBF2o4c.showDialogs = showDialogs
		S8GDrz3gxJMeYBF2o4c.logErrors = logErrors
		S8GDrz3gxJMeYBF2o4c.finishedLIST,S8GDrz3gxJMeYBF2o4c.failedLIST = [],[]
		S8GDrz3gxJMeYBF2o4c.statusDICT,S8GDrz3gxJMeYBF2o4c.resultsDICT = {},{}
		S8GDrz3gxJMeYBF2o4c.processesLIST = []
		S8GDrz3gxJMeYBF2o4c.starttimeDICT,S8GDrz3gxJMeYBF2o4c.finishtimeDICT,S8GDrz3gxJMeYBF2o4c.elpasedtimeDICT = {},{},{}
	def n5LdtkmOoIx7(S8GDrz3gxJMeYBF2o4c,qeVZY0a5zp,CCbUwJckDm,*aargs):
		qeVZY0a5zp = str(qeVZY0a5zp)
		S8GDrz3gxJMeYBF2o4c.statusDICT[qeVZY0a5zp] = QlTuvPbSpnjygBVW(u"ࠨࡴࡸࡲࡳ࡯࡮ࡨࠩ൵")
		if S8GDrz3gxJMeYBF2o4c.showDialogs: SSVCGE0bOfW1w9u52yvBxocNeP(nbOFVEDkpT4BIR7Qq82yPmHeJU,qeVZY0a5zp)
		llcD1veu9YVbRqL = eb6R0h1Fjl.Thread(target=S8GDrz3gxJMeYBF2o4c.jyHXptPO9YibV,args=(qeVZY0a5zp,CCbUwJckDm,aargs))
		S8GDrz3gxJMeYBF2o4c.processesLIST.append(llcD1veu9YVbRqL)
		return llcD1veu9YVbRqL
	def IvgGEhRUjtAKwpTlbferO8aYHuBsd(S8GDrz3gxJMeYBF2o4c,qeVZY0a5zp,CCbUwJckDm,*aargs):
		llcD1veu9YVbRqL = S8GDrz3gxJMeYBF2o4c.n5LdtkmOoIx7(qeVZY0a5zp,CCbUwJckDm,*aargs)
		llcD1veu9YVbRqL.start()
	def jyHXptPO9YibV(S8GDrz3gxJMeYBF2o4c,qeVZY0a5zp,CCbUwJckDm,aargs):
		qeVZY0a5zp = str(qeVZY0a5zp)
		S8GDrz3gxJMeYBF2o4c.starttimeDICT[qeVZY0a5zp] = lQMuw1PvVpAk.time()
		try:
			S8GDrz3gxJMeYBF2o4c.resultsDICT[qeVZY0a5zp] = CCbUwJckDm(*aargs)
			if X1mRwt2YJKgCLu9a67(u"ࠩࡒࡔࡊࡔࡕࡓࡎࠪ൶") in str(CCbUwJckDm) and not S8GDrz3gxJMeYBF2o4c.resultsDICT[qeVZY0a5zp].succeeded: R5VzflU0D2LQaSoKOskBuYtrXFC()
			S8GDrz3gxJMeYBF2o4c.finishedLIST.append(qeVZY0a5zp)
			S8GDrz3gxJMeYBF2o4c.statusDICT[qeVZY0a5zp] = DJ6ugPjW9bX8I(u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ൷")
		except Exception as TsLJDVQSbg5P9hd4YW7acCvEKqlXu:
			if S8GDrz3gxJMeYBF2o4c.logErrors:
				vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
				if vf9s4ClmTE08AGndQV!=O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧ൸"): Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
			S8GDrz3gxJMeYBF2o4c.failedLIST.append(qeVZY0a5zp)
			S8GDrz3gxJMeYBF2o4c.statusDICT[qeVZY0a5zp] = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ൹")
		S8GDrz3gxJMeYBF2o4c.finishtimeDICT[qeVZY0a5zp] = lQMuw1PvVpAk.time()
		S8GDrz3gxJMeYBF2o4c.elpasedtimeDICT[qeVZY0a5zp] = S8GDrz3gxJMeYBF2o4c.finishtimeDICT[qeVZY0a5zp] - S8GDrz3gxJMeYBF2o4c.starttimeDICT[qeVZY0a5zp]
	def GNW2KAEq1XwT5leBL98nYjFrfu4D(S8GDrz3gxJMeYBF2o4c):
		for dEY5LI34ch7nOwNjMyz2m6AaxpeX in S8GDrz3gxJMeYBF2o4c.processesLIST:
			dEY5LI34ch7nOwNjMyz2m6AaxpeX.start()
	def IwHZJdoMKB67cWxXyFY(S8GDrz3gxJMeYBF2o4c):
		while X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡲࡶࡰࡱ࡭ࡳ࡭ࠧൺ") in list(S8GDrz3gxJMeYBF2o4c.statusDICT.values()): lQMuw1PvVpAk.sleep(t4txivgXSUWBOlCakQmNDjf(u"࠶፨"))
def NJzuk8iI3thj():
	if not QQpBeZUlAbNKHfkCDLcqWYzv5: return xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡏࡑࡢ࡙ࡕࡊࡁࡕࡇࠪൻ")
	try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.makedirs(iy1kK0BAJVLazhHpnZEqrYt9dOfW)
	except: pass
	owguXCV3dRpzOhWrK6259kaJ7msl4 = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡈࡘࡐࡑࡥࡕࡑࡆࡄࡘࡊ࠭ർ")
	DEQcX5Ap4UlBrM = [IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࠻࠲࠺࠴࠰ࠨൽ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪ࠶࠵࠸࠱࠯࠳࠳࠲࠶࠿ࠧൾ"),DJ6ugPjW9bX8I(u"ࠫ࠷࠶࠲࠲࠰࠴࠵࠳࠸࠴ࡢࠩൿ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬ࠸࠰࠳࠳࠱࠵࠷࠴࠳࠱ࠩ඀"),q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭࠲࠱࠴࠵࠲࠵࠸࠮࠱࠴ࠪඁ"),UpQ56M0dO1N9xIvVegy(u"ࠧ࠳࠲࠵࠶࠳࠷࠰࠯࠴࠵ࠫං"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࠴࠳࠶࠸࠴࠰࠴࠰࠳࠺ࠬඃ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠩ࠵࠴࠷࠹࠮࠱࠷࠱࠵࠻࠭඄"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࠶࠵࠸࠳࠯࠲࠹࠲࠵࠼ࠧඅ"),qrjy8LuKVPNYdbSvzh(u"ࠫ࠷࠶࠲࠴࠰࠴࠴࠳࠸࠸ࠨආ"),l4DS8mnEjHhFMZ5YOe(u"ࠬ࠸࠰࠳࠶࠱࠴࠶࠴࠱࠵ࠩඇ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭࠲࠱࠴࠷࠲࠵࠽࠮࠳࠲ࠪඈ")]
	Hu75c8vMQ6mhgUBAVTRp = DEQcX5Ap4UlBrM[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	guPfDyI3s2ROjxMCQKh94 = ZZBH70rGPWXq9fCThR(Hu75c8vMQ6mhgUBAVTRp)
	fPgeCVLvuXrK6cZmT5khq3Fp = ZZBH70rGPWXq9fCThR(JeVILUu027qW)
	if fPgeCVLvuXrK6cZmT5khq3Fp>guPfDyI3s2ROjxMCQKh94:
		owguXCV3dRpzOhWrK6259kaJ7msl4 = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧඉ")
	return owguXCV3dRpzOhWrK6259kaJ7msl4
def fJOdcZ4hqWDMUtTCnlo7():
	for GvteTA3NKqC7RLWk,i5YdbEoS2gcpDm,l6ifO2ZNCResYtwnP0rD5S8oxac3y in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.walk(yi4Em23SQL9GNOBzXcshRV7wg6IUM0,topdown=SmbNGskjMx):
		if len(l6ifO2ZNCResYtwnP0rD5S8oxac3y)>QlTuvPbSpnjygBVW(u"࠻࠰࠱፩"): bQaAGNXBYIgClLm15ui3JqU(GvteTA3NKqC7RLWk,SmbNGskjMx,SmbNGskjMx)
	return
def ylGTu5RkOxQEeCD(RRdkhxeG53A7ClaoBOzFr0c6I4bD):
	if YayJj10OGl(u"ࠨࡇ࡛ࡘࡗࡇࡐ࡚ࡖࡋࡓࡓࡉࡏࡅࡇࠪඊ") in str(mHhBGP1spJW4kfAvbj92qVZ): return
	global sCSyOla9hrcE,XXl2tGoemr7Yd
	Vkuf83riYLd5B0c = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD: Vkuf83riYLd5B0c = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,flDSRbv57PnV3(u"ࠩࡶࡸࡷ࠭උ"),z3sIGH8jmLYg(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ඌ"),X1mRwt2YJKgCLu9a67(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭ඍ"))
	if not Vkuf83riYLd5B0c:
		qxZiT6WJ7sX = sCSyOla9hrcE[tM24jD1gO0(u"ࠬࡖ࡙ࡕࡊࡒࡒࠬඎ")][Fo1SgXMsHk(u"࠹፪")]
		ME0GZsPhDVmOvYfw = {bYyKEjIuGQzoq3AR1(u"࠭ࡵࡴࡧࡵࠫඏ"):iidHGYjPEW4zU,QlTuvPbSpnjygBVW(u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨඐ"):JeVILUu027qW}
		cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡒࡒࡗ࡙࠭එ"),qxZiT6WJ7sX,ME0GZsPhDVmOvYfw,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡉ࡝࡚ࡒࡂࡡࡓ࡝࡙ࡎࡏࡏࡡࡆࡓࡉࡋ࠭࠲ࡵࡷࠫඒ"))
		if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
			Vkuf83riYLd5B0c = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
			z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,fgv5U2eRVaQqSiuGD(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ඓ"),l4DS8mnEjHhFMZ5YOe(u"ࠫࡊ࡞ࡔࡓࡃࡓ࡝࡙ࡎࡏࡏࡅࡒࡈࡊ࠭ඔ"),Vkuf83riYLd5B0c,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	if Vkuf83riYLd5B0c:
		global NEW_SITESURLS,V3jFwXDRB56tzixuImOUTNhpenPqH
		exec(Vkuf83riYLd5B0c,globals(),locals())
		sCSyOla9hrcE.update(NEW_SITESURLS)
		XXl2tGoemr7Yd = V3jFwXDRB56tzixuImOUTNhpenPqH
	return
def LxDfBKHwXrV6RZn2y1C3o4zU9hgIi():
	xdONfc1X7rV9ygFJ6a = NJzuk8iI3thj()
	if xdONfc1X7rV9ygFJ6a==DJ6ugPjW9bX8I(u"࡙ࠬࡉࡎࡒࡏࡉࡤ࡛ࡐࡅࡃࡗࡉࠬඕ"): fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭࠮࡝ࡶࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳࠡࡗࡳࡨࡦࡺࡥࠡࡖࡼࡴࡪࡀࠠࠡࡕࡌࡑࡕࡒࡅࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬඖ")+cvU8LCyfWkogjSeF9lHphBdEZnzsmr+flDSRbv57PnV3(u"ࠧࠡ࡟ࠪ඗"))
	else: fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࠰࡟ࡸࡆࡸࡡࡣ࡫ࡦ࡚࡮ࡪࡥࡰࡵ࡙ࠣࡵࡪࡡࡵࡧࠣࡘࡾࡶࡥ࠻ࠢࠣࡊ࡚ࡒࡌࠡࡗࡓࡈࡆ࡚ࡅࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ඘")+cvU8LCyfWkogjSeF9lHphBdEZnzsmr+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࠣࡡࠬ඙"))
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,qrjy8LuKVPNYdbSvzh(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ක"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫฯ๋ࠠหฯา๎ะࠦวๅสิ๊ฬ๋ฬࠡใํࠤัํวำๅ࡟ࡲส๊้ࠡษ็ษฺีวาࠢิๆ๊ࡀ࡜࡯࡞ࡱࠫඛ")+JeVILUu027qW)
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨග"),UpQ56M0dO1N9xIvVegy(u"࠭สๆࠢอฯอ๐สࠡล๋ࠤฯำฯ๋อࠣห้หีะษิࠤฬ๊ฬะ์าࠤ้ฮั็ษ่ะࠥอไโ์า๎ํํวหࠢส่฾ืศ๋หࠣ࠲ࠥษ่ࠡฬ่ࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠ࡝ࡰ࡟ࡲู๊ࠥใ๊่ࠤฬ๊ย็ࠢส่อืๆศ็ฯࠤอฮูืࠢส่ๆำ่ึษอࠤ้฼ๅศ่ࠣ฽๊๊ࠠศๆหี๋อๅอࠢหูํืษࠡืะ๎าฯ้ࠠ็อ็ฬ๋ไสࠩඝ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪඞ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࠫඟ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,flDSRbv57PnV3(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬච"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡅࡑࡒ࡟ࡂࡆࡇࡓࡓ࡙࡟࡙ࡏࡏࠫඡ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧජ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧඣ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩඤ"),z3sIGH8jmLYg(u"ࠧࡔࡋࡗࡉࡘࡥࡎࡂࡏࡈࡗࠬඥ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,UpQ56M0dO1N9xIvVegy(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐࠫඦ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡖࡍ࡙ࡋࡓࡠࡅࡋࡉࡈࡑࠧට"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭ඨ"),ulAxHwvzR9eTb5n(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪඩ"))
	llnG7jiQBYKhAeovbT.setSetting(fgv5U2eRVaQqSiuGD(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࡦࡰࡵࡷࡥࠬඪ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࡧࡣࡥࡶࡦࡱࡡࠨණ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡢࡸ࠱࡬ࡴࡹࡴ࠯ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷࠪඬ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(bYyKEjIuGQzoq3AR1(u"ࠨࡣࡹ࠲࡭ࡵࡳࡵ࠰ࡩࡥࡸ࡫࡬ࡩࡦ࠴ࠫත"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(QlTuvPbSpnjygBVW(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬථ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(ulAxHwvzR9eTb5n(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠷࠭ද"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(fgv5U2eRVaQqSiuGD(u"ࠫࡦࡼ࠮ࡱࡧࡵ࡭ࡴࡪ࠮ࡪࡰࡩࡳࡸ࠭ධ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(SSvu1CZjTW7FcloNqD(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪන"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭඲"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(I3cxjYaHhsrM7T4UX26klN(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴࡬ࡰࡰࡪࠫඳ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(tM24jD1gO0(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩප"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting(I3cxjYaHhsrM7T4UX26klN(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫඵ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡗࡊࡉࡔࡊࡑࡑࡗࡤ࡙ࡉࡕࡇࡖࠫබ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,flDSRbv57PnV3(u"ࠫࡘࡋࡃࡕࡋࡒࡒࡘࡥࡉࡑࡖ࡙ࠫභ"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,fgv5U2eRVaQqSiuGD(u"࡙ࠬࡅࡄࡖࡌࡓࡓ࡙࡟ࡎ࠵ࡘࠫම"))
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡓࡄࡔࡄࡔࡊࡘࡓࡠࡕࡗࡅ࡙࡛ࡓࠨඹ"))
	kYaRIGV5T7Zvfbq3WKpmQwJiBg(SmbNGskjMx)
	hTxAoj52vsb6Mze9rnmIk7lNJg(zDoPOYNsJg2id1HLnx5bpf)
	import SJqrPsfTgG
	SJqrPsfTgG.mmhRocLej7aHKt4QYIyJNp9Bk(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	if xdONfc1X7rV9ygFJ6a==Fo1SgXMsHk(u"ࠧࡔࡋࡐࡔࡑࡋ࡟ࡖࡒࡇࡅ࡙ࡋࠧය"):
		NrCbofjFaXYHOd0htmn(Ag9l6cw3EBqP8HsQuGMizfOtr4,[SOEM49TbV0zuQ])
	else:
		NrCbofjFaXYHOd0htmn(SmbNGskjMx,[])
		SJqrPsfTgG.KKFMTDoB7R2fm38nuJbLCq9x4AYp1()
		SJqrPsfTgG.tjoDTklcueMPnHqI9yg(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨර"),SmbNGskjMx)
		SJqrPsfTgG.tjoDTklcueMPnHqI9yg(bYyKEjIuGQzoq3AR1(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴࠬ඼"),SmbNGskjMx)
		try:
			RKDkluzam42bL = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,t4txivgXSUWBOlCakQmNDjf(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬල"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ඾"),bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩ඿"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬව"))
			hhLs8W6yFcp4udSlnUwjg9TRZPkMDx = IcJ2vm5AukNS1biO4Z.Addon(id=IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡳࡧࡶࡳࡱࡼࡥࡶࡴ࡯ࠫශ"))
			hhLs8W6yFcp4udSlnUwjg9TRZPkMDx.setSetting(I3cxjYaHhsrM7T4UX26klN(u"ࠨࡣࡹ࠲ࡦࡻࡴࡰࡡࡳ࡭ࡨࡱࠧෂ"),SSvu1CZjTW7FcloNqD(u"ࠩࡉࡥࡱࡹࡥࠨස"))
		except: pass
		try:
			RKDkluzam42bL = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬහ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨළ"),l4DS8mnEjHhFMZ5YOe(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬෆ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ෇"))
			hhLs8W6yFcp4udSlnUwjg9TRZPkMDx = IcJ2vm5AukNS1biO4Z.Addon(id=SSvu1CZjTW7FcloNqD(u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮࡮ࡱࡧࡹࡱ࡫࠮ࡺࡶ࠰ࡨࡱࡶࠧ෈"))
			hhLs8W6yFcp4udSlnUwjg9TRZPkMDx.setSetting(I3cxjYaHhsrM7T4UX26klN(u"ࠨࡣࡹ࠲ࡻ࡯ࡤࡦࡱࡢࡵࡺࡧ࡬ࡪࡶࡼࠫ෉"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩ࠶්ࠫ"))
		except: pass
		try:
			RKDkluzam42bL = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,QlTuvPbSpnjygBVW(u"ࠪࡹࡸ࡫ࡲࡥࡣࡷࡥࠬ෋"),UpQ56M0dO1N9xIvVegy(u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨ෌"),z3sIGH8jmLYg(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ෍"),QlTuvPbSpnjygBVW(u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬ෎"))
			hhLs8W6yFcp4udSlnUwjg9TRZPkMDx = IcJ2vm5AukNS1biO4Z.Addon(id=usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠧා"))
			hhLs8W6yFcp4udSlnUwjg9TRZPkMDx.setSetting(IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡣࡹ࠲ࡘ࡚ࡒࡆࡃࡐࡗࡊࡒࡅࡄࡖࡌࡓࡓ࠭ැ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࠵ࠫෑ"))
		except: pass
	qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = LjfICzo9TkNMZ1PSaFW5vl3b0(TTrFaqDzxJOsh90UHIZ5)
	qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = LjfICzo9TkNMZ1PSaFW5vl3b0(g8FzaRfU7Zx9HeSBNtJ)
	SJqrPsfTgG.qqRhft0sZrzCpS89ecTV(SmbNGskjMx)
	llnG7jiQBYKhAeovbT.setSetting(bYyKEjIuGQzoq3AR1(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧි"),JeVILUu027qW)
	ue186CEMORWhvq(SmbNGskjMx)
	return
def At4mLshzQXaIrJlK():
	aaCkpHVr6dv7K2IxhOBfglMQu3580L = jB7hQVAxCkgwsDE5bOa83u9KXt4(llnG7jiQBYKhAeovbT.getSetting(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡷ࡭ࡵࡲࡵࠩී")))
	aaCkpHVr6dv7K2IxhOBfglMQu3580L = f4fTutDOEwUeIoPLRQ if not aaCkpHVr6dv7K2IxhOBfglMQu3580L else int(aaCkpHVr6dv7K2IxhOBfglMQu3580L)
	if not aaCkpHVr6dv7K2IxhOBfglMQu3580L or not f4fTutDOEwUeIoPLRQ<=sqeRK2tVw8-aaCkpHVr6dv7K2IxhOBfglMQu3580L<=pOLDXnFW5V6cTw7ikm:
		llnG7jiQBYKhAeovbT.setSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡸ࡮࡯ࡳࡶࠪු"),u8i2rxCZwsDyW7KMFIbmqgnvS(sqeRK2tVw8))
		hTxAoj52vsb6Mze9rnmIk7lNJg(zDoPOYNsJg2id1HLnx5bpf)
		ttJByPY158w4mzpC6RUa2 = jB7hQVAxCkgwsDE5bOa83u9KXt4(llnG7jiQBYKhAeovbT.getSetting(Fo1SgXMsHk(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡸࡥࡨࡷ࡯ࡥࡷ࠭෕")))
		ttJByPY158w4mzpC6RUa2 = f4fTutDOEwUeIoPLRQ if not ttJByPY158w4mzpC6RUa2 else int(ttJByPY158w4mzpC6RUa2)
		if not ttJByPY158w4mzpC6RUa2 or not f4fTutDOEwUeIoPLRQ<=sqeRK2tVw8-ttJByPY158w4mzpC6RUa2<=RRYx6sACloVPr3td95Ej:
			llnG7jiQBYKhAeovbT.setSetting(QlTuvPbSpnjygBVW(u"ࠧࡢࡸ࠱ࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡲࡦࡩࡸࡰࡦࡸࠧූ"),u8i2rxCZwsDyW7KMFIbmqgnvS(sqeRK2tVw8))
			ylGTu5RkOxQEeCD(SmbNGskjMx)
		QRiC2KaDLt1SY596 = jB7hQVAxCkgwsDE5bOa83u9KXt4(llnG7jiQBYKhAeovbT.getSetting(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡭ࡱࡱ࡫ࠬ෗")))
		QRiC2KaDLt1SY596 = f4fTutDOEwUeIoPLRQ if not QRiC2KaDLt1SY596 else int(QRiC2KaDLt1SY596)
		if not QRiC2KaDLt1SY596 or not f4fTutDOEwUeIoPLRQ<=sqeRK2tVw8-QRiC2KaDLt1SY596<=mmfpkVtUDjaq86eAuFzE0oxP:
			llnG7jiQBYKhAeovbT.setSetting(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡮ࡲࡲ࡬࠭ෘ"),u8i2rxCZwsDyW7KMFIbmqgnvS(sqeRK2tVw8))
			llcD1veu9YVbRqL = eb6R0h1Fjl.Thread(target=fJOdcZ4hqWDMUtTCnlo7)
			llcD1veu9YVbRqL.start()
	bS4pWh8NtwM2zYA = jB7hQVAxCkgwsDE5bOa83u9KXt4(llnG7jiQBYKhAeovbT.getSetting(I3cxjYaHhsrM7T4UX26klN(u"ࠪࡥࡻ࠴ࡰࡦࡴ࡬ࡳࡩ࠴ࡩ࡯ࡨࡲࡷࠬෙ")))
	bS4pWh8NtwM2zYA = f4fTutDOEwUeIoPLRQ if not bS4pWh8NtwM2zYA else int(bS4pWh8NtwM2zYA)
	y6GMXsg2icuFz17P = jB7hQVAxCkgwsDE5bOa83u9KXt4(llnG7jiQBYKhAeovbT.getSetting(DJ6ugPjW9bX8I(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭ේ")))
	y6GMXsg2icuFz17P = f4fTutDOEwUeIoPLRQ if not y6GMXsg2icuFz17P else int(y6GMXsg2icuFz17P)
	if not bS4pWh8NtwM2zYA or not y6GMXsg2icuFz17P or not f4fTutDOEwUeIoPLRQ<=sqeRK2tVw8-y6GMXsg2icuFz17P<=bS4pWh8NtwM2zYA: MgBzE315wT9vIydJWk0U6Y()
	return
def MgBzE315wT9vIydJWk0U6Y():
	HFaEkG8zQVX = vkIa3ijEQVsJGdWOXwK7bnue9ADR
	DLlmWanPCXRrUqi = SmbNGskjMx if QQ3hd2tR8s.qq293Npd7C else Ag9l6cw3EBqP8HsQuGMizfOtr4
	if DLlmWanPCXRrUqi:
		SEKgsaLmWbq5B7dHX2uQPVTUCe = nNR2JPEM9mh(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		if len(SEKgsaLmWbq5B7dHX2uQPVTUCe)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࠴࡜ࡵࡕ࡫ࡳࡼ࡯࡮ࡨࠢࡔࡹࡪࡹࡴࡪࡱࡱࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨෛ")+cvU8LCyfWkogjSeF9lHphBdEZnzsmr+bYyKEjIuGQzoq3AR1(u"࠭ࠠ࡞ࠩො"))
			qeVZY0a5zp,vHsaM4eT5Nkx9Zt,d1wmW9AYrsK,qbF0StY2asIVE1yWxNn4KUQB9dD,ArJ8jElsYxFZNhfvOiw,szmD9nEACSWOyk15fPl0QZoTv = SEKgsaLmWbq5B7dHX2uQPVTUCe[f4fTutDOEwUeIoPLRQ]
			p5dzuoRK9kgcswW86JaM0OhN1CbQnP,TT6JEsYjXLtmQdnG = qbF0StY2asIVE1yWxNn4KUQB9dD.split(I3cxjYaHhsrM7T4UX26klN(u"ࠧ࡝ࡰ࠾࠿ࠬෝ"))
			del SEKgsaLmWbq5B7dHX2uQPVTUCe[f4fTutDOEwUeIoPLRQ]
			YKDPT2RQbcoACLWx85V1 = eH7yw1hTGUROK2B4dcP0iEr.sample(SEKgsaLmWbq5B7dHX2uQPVTUCe,vkIa3ijEQVsJGdWOXwK7bnue9ADR)
			qeVZY0a5zp,vHsaM4eT5Nkx9Zt,d1wmW9AYrsK,qbF0StY2asIVE1yWxNn4KUQB9dD,ArJ8jElsYxFZNhfvOiw,szmD9nEACSWOyk15fPl0QZoTv = YKDPT2RQbcoACLWx85V1[f4fTutDOEwUeIoPLRQ]
			d1wmW9AYrsK = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨ࡝ࡕࡘࡑࡣࠧෞ")+l5JG7XwbOfo8DznU+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࠣ࠾ࠥ࠭ෟ")+qeVZY0a5zp+c7gxFyUCGm+d1wmW9AYrsK
			ArJ8jElsYxFZNhfvOiw = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪษึูวๅࠢิืฬ๊ษࠡๆ็้อืๅอࠩ෠")
			h1D9iUur2YAR = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫฬ๊สษำ฼หฯ࠭෡")
			button0,button1 = qbF0StY2asIVE1yWxNn4KUQB9dD,ArJ8jElsYxFZNhfvOiw
			bbLYqW1AGOld = [button0,button1,h1D9iUur2YAR]
			ID5MZ6RikNdy7UJEvWSc1tXaxOV = vkIa3ijEQVsJGdWOXwK7bnue9ADR if QQ3hd2tR8s.ggSlJwTytkUHBA2dz else X1mRwt2YJKgCLu9a67(u"࠲࠲፫")
			K4O6aMFQSLIbWxtGpPy2gZDB5q = -Fo1SgXMsHk(u"࠻፬")
			while K4O6aMFQSLIbWxtGpPy2gZDB5q<f4fTutDOEwUeIoPLRQ:
				AJ9Qz5cwmEhbl = eH7yw1hTGUROK2B4dcP0iEr.sample(bbLYqW1AGOld,ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb)
				K4O6aMFQSLIbWxtGpPy2gZDB5q = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,AJ9Qz5cwmEhbl[f4fTutDOEwUeIoPLRQ],AJ9Qz5cwmEhbl[vkIa3ijEQVsJGdWOXwK7bnue9ADR],AJ9Qz5cwmEhbl[QQSugEIn2mTCpRsfcaJHhPdAWzylM],p5dzuoRK9kgcswW86JaM0OhN1CbQnP,d1wmW9AYrsK,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺࠧ෢"),ID5MZ6RikNdy7UJEvWSc1tXaxOV,tM24jD1gO0(u"࠹࠴፭"))
				if K4O6aMFQSLIbWxtGpPy2gZDB5q==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠵࠵፮"): break
				import SJqrPsfTgG
				if K4O6aMFQSLIbWxtGpPy2gZDB5q>=f4fTutDOEwUeIoPLRQ and AJ9Qz5cwmEhbl[K4O6aMFQSLIbWxtGpPy2gZDB5q]==bbLYqW1AGOld[vkIa3ijEQVsJGdWOXwK7bnue9ADR]:
					SJqrPsfTgG.IbOgDw5uNE16VosCFnShBl()
					if K4O6aMFQSLIbWxtGpPy2gZDB5q>=f4fTutDOEwUeIoPLRQ: K4O6aMFQSLIbWxtGpPy2gZDB5q = -X1mRwt2YJKgCLu9a67(u"࠾፯")
				elif K4O6aMFQSLIbWxtGpPy2gZDB5q>=f4fTutDOEwUeIoPLRQ and AJ9Qz5cwmEhbl[K4O6aMFQSLIbWxtGpPy2gZDB5q]==bbLYqW1AGOld[QQSugEIn2mTCpRsfcaJHhPdAWzylM]:
					SJqrPsfTgG.UbxR3AHIEPcdBS(SmbNGskjMx)
				if K4O6aMFQSLIbWxtGpPy2gZDB5q==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ෣"),l5JG7XwbOfo8DznU+fgv5U2eRVaQqSiuGD(u"ࠧฯำ๋ะࠥิืฤࠩ෤")+c7gxFyUCGm+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨ࡞ࡱࠤ้๊ฮา๊ฯࠤฬ๊ีฮ์ะࠤศิสา๋ࠢหาีࠠๆ่ࠣห้ษฬ้สฬࠤฬ๊ๅห๊ไีฮ࠭෥"))
			HFaEkG8zQVX = vkIa3ijEQVsJGdWOXwK7bnue9ADR
		else: HFaEkG8zQVX = f4fTutDOEwUeIoPLRQ
	llnG7jiQBYKhAeovbT.setSetting(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡳࡸࡩࡸࡺࡩࡰࡰࡶࠫ෦"),u8i2rxCZwsDyW7KMFIbmqgnvS(sqeRK2tVw8))
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭෧"),Fo1SgXMsHk(u"ࠫࡘࡏࡔࡆࡕࡢࡒࡆࡓࡅࡔࠩ෨"),HFaEkG8zQVX,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	return
def xMSOwCX3PWYvAyFKaR1sZTV8GoLg(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ,yotXRvP4md3Vrnhq9lBH1F,NNntz8hA93kG6WqEDb1OUoeFm2fg,EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC):
	LIwD5g4fVCk2StRHBQadpK = int(yotXRvP4md3Vrnhq9lBH1F%z3sIGH8jmLYg(u"࠷࠰፰"))
	tWCYOJ19zpPNAawmf = int(yotXRvP4md3Vrnhq9lBH1F/UpQ56M0dO1N9xIvVegy(u"࠱࠱፱"))
	EcVTS7m3sH52OAhoxyY = vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,nbOFVEDkpT4BIR7Qq82yPmHeJU,Nyb1swDcFkeGUdMEnh9itZ
	oofqxF5JY2Sig16skctEhOeB3AX = llnG7jiQBYKhAeovbT.getSetting(fgv5U2eRVaQqSiuGD(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬ෩"))
	if not oofqxF5JY2Sig16skctEhOeB3AX: llnG7jiQBYKhAeovbT.setSetting(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡰࡩࡳࡻࡳࡤࡣࡦ࡬ࡪ࠭෪"),l4DS8mnEjHhFMZ5YOe(u"ࠧࡂࡗࡗࡓࠬ෫"))
	FGnvJ1ZOyESbpuerf54w8U = llnG7jiQBYKhAeovbT.getSetting(YayJj10OGl(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ෬"))
	RM8ZdQkKxUFIDTz573 = d7Pcqxem9LyM6WEiIpv(NNntz8hA93kG6WqEDb1OUoeFm2fg)
	ubMHV0c4eN6waIqlOQkxyR = [f4fTutDOEwUeIoPLRQ,t4txivgXSUWBOlCakQmNDjf(u"࠳࠸፳"),qrjy8LuKVPNYdbSvzh(u"࠴࠻፴"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠵࠾፵"),I3cxjYaHhsrM7T4UX26klN(u"࠳࠸፲"),ulAxHwvzR9eTb5n(u"࠳࠵፸"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠺࠶፶"),fgv5U2eRVaQqSiuGD(u"࠻࠳፷")]
	ZEa0TRLziM87x41NeFVH3bBYUm = tWCYOJ19zpPNAawmf not in ubMHV0c4eN6waIqlOQkxyR
	D2zC70QjVGsie = tWCYOJ19zpPNAawmf in [DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠶࠸፼"),UpQ56M0dO1N9xIvVegy(u"࠳࠺፹"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠺࠵፻"),fgv5U2eRVaQqSiuGD(u"࠹࠵፺")]
	uFpAGTrDUI1qePl9JOXzdow0cCKY2 = yotXRvP4md3Vrnhq9lBH1F in [UpQ56M0dO1N9xIvVegy(u"࠸࠶࠶፾"),QlTuvPbSpnjygBVW(u"࠷࠽࠰፽")]
	KGMvJO5RsciTk0jof3zID2aW9Ln = (ZEa0TRLziM87x41NeFVH3bBYUm or D2zC70QjVGsie) and not uFpAGTrDUI1qePl9JOXzdow0cCKY2
	kVYtxerc6DahoLIpzU2b = (FGnvJ1ZOyESbpuerf54w8U or not p8pRVmk1Jg03PjfMonTFyvLCax) and FGnvJ1ZOyESbpuerf54w8U not in [IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ෭"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡑࡊࡔࡕࡠࡔࡈ࡚ࡊࡘࡓࡆࡆࠪ෮"),flDSRbv57PnV3(u"ࠫࡒࡋࡎࡖࡡࡕࡅࡓࡊࡏࡎࡋ࡝ࡉࡉ࠭෯"),UpQ56M0dO1N9xIvVegy(u"ࠬࡓࡅࡏࡗࡢࡅࡘࡉࡅࡏࡆࡈࡈࠬ෰"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡍࡆࡐࡘࡣࡉࡋࡓࡄࡇࡑࡈࡊࡊࠧ෱")]
	JEQUBP0AC9waj = bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡵࡻࡳࡩࡂ࠭ෲ") in FGnvJ1ZOyESbpuerf54w8U
	A2rd6UB4H7 = yotXRvP4md3Vrnhq9lBH1F in [fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠴࠺࠶ᎉ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠵࠻࠸ᎊ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠶࠼࠳ᎋ"),I3cxjYaHhsrM7T4UX26klN(u"࠷࠶࠵ᎅ"),bnI4kmPtrW7yFEhljXOCq9(u"࠱࠷࠷ᎆ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠲࠸࠹ᎇ"),tM24jD1gO0(u"࠳࠹࠻ᎈ"),fgv5U2eRVaQqSiuGD(u"࠶࠼࠸ᎄ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠹࠹࠵ᎁ"),bYyKEjIuGQzoq3AR1(u"࠷࠷࠴፿"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠸࠸࠶ᎀ"),QlTuvPbSpnjygBVW(u"࠺࠺࠹ᎂ"),fgv5U2eRVaQqSiuGD(u"࠻࠻࠻ᎃ")]
	cvZoNw4F0fRjYaMuP5CVrE = LIwD5g4fVCk2StRHBQadpK==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠿ᎌ") or yotXRvP4md3Vrnhq9lBH1F in [X60YQOADpkHBb31LiR5qUEKfM(u"࠲࠶࠸ᎎ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠸࠵࠻᎐"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠷࠵࠷ᎏ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠴࠶ᎍ")]
	RP6zf9FrHX2Q5a8AIBvdnwpo = not A2rd6UB4H7
	aaSJNvFjKO0T7Xn1q3eyR = not cvZoNw4F0fRjYaMuP5CVrE
	X0ugERoYwPZLeQ = RM8ZdQkKxUFIDTz573 in [nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠨ࠰࠱ࠫෳ")]
	Oa8KdJT1gXvYli2xAI = X0ugERoYwPZLeQ or RP6zf9FrHX2Q5a8AIBvdnwpo
	TvQ4V9PkogXNDUAebrHm = X0ugERoYwPZLeQ or aaSJNvFjKO0T7Xn1q3eyR or JEQUBP0AC9waj
	wwamfkh4iKjAU = yotXRvP4md3Vrnhq9lBH1F not in [O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠳࠸࠳᎕"),ulAxHwvzR9eTb5n(u"࠶࠻࠷᎑"),DJ6ugPjW9bX8I(u"࠴࠹࠹᎖"),DJ6ugPjW9bX8I(u"࠸࠷࠱᎓"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠸࠹࠰᎒"),bnI4kmPtrW7yFEhljXOCq9(u"࠵࠵࠲᎔"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠴࠴࠶࠶᎗")]
	if oofqxF5JY2Sig16skctEhOeB3AX==l4DS8mnEjHhFMZ5YOe(u"ࠩࡖࡘࡔࡖࠧ෴"): LYMuliz6J18hOAnD2KcCoRT = cvZoNw4F0fRjYaMuP5CVrE or A2rd6UB4H7
	else: LYMuliz6J18hOAnD2KcCoRT = Ag9l6cw3EBqP8HsQuGMizfOtr4
	X4go0ezZuGlrxUH36vJ = tWCYOJ19zpPNAawmf in [qrjy8LuKVPNYdbSvzh(u"࠽࠴᎚"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠼࠻᎙"),ulAxHwvzR9eTb5n(u"࠹࠹᎘"),tM24jD1gO0(u"࠱࠱࠳᎛")]
	qqw5SnYyLGjRbMoBTfk = yotXRvP4md3Vrnhq9lBH1F in [SSvu1CZjTW7FcloNqD(u"࠳࠺࠳᎜"),Fo1SgXMsHk(u"࠹࠵࠴᎝")]
	k3MPvV8pJHSW0 = not X4go0ezZuGlrxUH36vJ and not qqw5SnYyLGjRbMoBTfk
	iiWS8Tph9oE = Oa8KdJT1gXvYli2xAI and TvQ4V9PkogXNDUAebrHm and wwamfkh4iKjAU and LYMuliz6J18hOAnD2KcCoRT and k3MPvV8pJHSW0
	RX7nrTtjJO1QbSBi = wwamfkh4iKjAU and LYMuliz6J18hOAnD2KcCoRT and k3MPvV8pJHSW0
	OTHqbvx8cyo5iwjCLSVu0zn = RX7nrTtjJO1QbSBi
	ptGWavmbV7I9F5h0ROqzTNY8elLD = llnG7jiQBYKhAeovbT.getSetting(SSvu1CZjTW7FcloNqD(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡲࡵࡳࡻ࡯ࡤࡦࡴࠪ෵"))
	AxES4pojwcuLMs = llnG7jiQBYKhAeovbT.getSetting(UpQ56M0dO1N9xIvVegy(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡦࡳࡩ࡫ࠧ෶"))
	iSCy3XpY1N7OW5gemjv8xlIn9QMDd = SmbNGskjMx
	if kVYtxerc6DahoLIpzU2b and iiWS8Tph9oE:
		wt89goCIrDRZ = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡲࡩࡴࡶࠪ෷"),SSvu1CZjTW7FcloNqD(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬ෸")+ptGWavmbV7I9F5h0ROqzTNY8elLD+fgv5U2eRVaQqSiuGD(u"ࠧࡠࠩ෹")+AxES4pojwcuLMs,EcVTS7m3sH52OAhoxyY)
		if wt89goCIrDRZ:
			fGBlEmQTwiAJt7rCYIxyau3jRh(nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠨ࠰࡟ࡸࡒࡋࡎࡖࡕࡢࡇࡆࡉࡈࡆࡡࠪ෺")+ptGWavmbV7I9F5h0ROqzTNY8elLD+bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡢࠫ෻")+AxES4pojwcuLMs+UpQ56M0dO1N9xIvVegy(u"ࠪࠤࠥࠦࡌࡰࡣࡧ࡭ࡳ࡭ࠠ࡮ࡧࡱࡹࠥ࡬ࡲࡰ࡯ࠣࡧࡦࡩࡨࡦࠩ෼"))
			if JEQUBP0AC9waj:
				g5ickQo9J1OB = []
				from ZyG6Wbnpi0 import ge0AtaIO6npZ8qRHUhusX
				from Z2ZSU6yEYJ import X48cC9SbOl6v20AU7HgEF3i,SSFTAqtnY3Wf
				xxGuXHDsP8eMcUrELit = ge0AtaIO6npZ8qRHUhusX
				bZ3mNKjk6QgdiytLpv = X48cC9SbOl6v20AU7HgEF3i()
				nqFtWNakEySzCZ0QwRD = FGnvJ1ZOyESbpuerf54w8U
				ss29DqM3L7oUKHC4BQSJ1zRY,gSNjcdf0buCeZzrmTXAUE4DLk5,CHjGhAf3oe8w4XIQtL2cFDZb,Eb89Kg5yaXn,VsA2oDpzITuEjBNCPbMn9cL4,N3VwfPkF9LqAY8urev14MOn6,KKgh7wUYmvFjZf8tcPS4nr2Wsu6oRi,rrRisndy8CzBXMAJNmVoDhItELe,XZ8yReErqDFQwvTgoid2KHxMG5c9 = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(nqFtWNakEySzCZ0QwRD)
				YBneawTtF8pEACKgIk72vRZXJ = ss29DqM3L7oUKHC4BQSJ1zRY,gSNjcdf0buCeZzrmTXAUE4DLk5,CHjGhAf3oe8w4XIQtL2cFDZb,Eb89Kg5yaXn,VsA2oDpzITuEjBNCPbMn9cL4,N3VwfPkF9LqAY8urev14MOn6,KKgh7wUYmvFjZf8tcPS4nr2Wsu6oRi,nbOFVEDkpT4BIR7Qq82yPmHeJU,XZ8yReErqDFQwvTgoid2KHxMG5c9
				for KvZBGkjih0bFCOr in wt89goCIrDRZ:
					i9iGSLukmf4Xbd157 = KvZBGkjih0bFCOr[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡲ࡫࡮ࡶࡋࡷࡩࡲ࠭෽")]
					if i9iGSLukmf4Xbd157==YBneawTtF8pEACKgIk72vRZXJ or KvZBGkjih0bFCOr[YayJj10OGl(u"ࠬࡳ࡯ࡥࡧࠪ෾")] in [bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠶࠻࠻᎟"),Fo1SgXMsHk(u"࠵࠻࠵᎞")]:
						KvZBGkjih0bFCOr = ZZOsRMvLwU(i9iGSLukmf4Xbd157,xxGuXHDsP8eMcUrELit,bZ3mNKjk6QgdiytLpv)
						if KvZBGkjih0bFCOr[X1mRwt2YJKgCLu9a67(u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࠩ෿")]:
							AOmjCtHZ2PpvN = SSFTAqtnY3Wf(bZ3mNKjk6QgdiytLpv,i9iGSLukmf4Xbd157,KvZBGkjih0bFCOr[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧ࡯ࡧࡺࡴࡦࡺࡨࠨ฀")])
							KvZBGkjih0bFCOr[Fo1SgXMsHk(u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࡡࡰࡩࡳࡻࠧก")] = AOmjCtHZ2PpvN+KvZBGkjih0bFCOr[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡦࡳࡳࡺࡥࡹࡶࡢࡱࡪࡴࡵࠨข")]
					g5ickQo9J1OB.append(KvZBGkjih0bFCOr)
				llnG7jiQBYKhAeovbT.setSetting(l4DS8mnEjHhFMZ5YOe(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡲࡦࡨࡵࡩࡸ࡮ࠧฃ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫค"): z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡓࡅࡏࡗࡖࡣࡈࡇࡃࡉࡇࡢࠫฅ")+ptGWavmbV7I9F5h0ROqzTNY8elLD+Fo1SgXMsHk(u"࠭࡟ࠨฆ")+AxES4pojwcuLMs,EcVTS7m3sH52OAhoxyY,g5ickQo9J1OB,RRYx6sACloVPr3td95Ej)
			else: g5ickQo9J1OB = wt89goCIrDRZ
			if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡧࡱ࡯ࡨࡪࡸࠧง") and RM8ZdQkKxUFIDTz573!=xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨ࠰࠱ࠫจ") and KGMvJO5RsciTk0jof3zID2aW9Ln: UKzkraEisF0wRZ()
			iSCy3XpY1N7OW5gemjv8xlIn9QMDd = uS4rEdcNAC3wxVR0XJ7ypgaQKnMl52(EcVTS7m3sH52OAhoxyY,g5ickQo9J1OB,EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC)
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡩࡳࡱࡪࡥࡳࠩฉ") and FGnvJ1ZOyESbpuerf54w8U not in [ulAxHwvzR9eTb5n(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪช"),I3cxjYaHhsrM7T4UX26klN(u"ࠫࡒࡋࡎࡖࡡࡕࡉ࡛ࡋࡒࡔࡇࡇࠫซ"),QlTuvPbSpnjygBVW(u"ࠬࡓࡅࡏࡗࡢࡖࡆࡔࡄࡐࡏࡌ࡞ࡊࡊࠧฌ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡍࡆࡐࡘࡣࡆ࡙ࡃࡆࡐࡇࡉࡉ࠭ญ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡎࡇࡑ࡙ࡤࡊࡅࡔࡅࡈࡒࡉࡋࡄࠨฎ")] and RX7nrTtjJO1QbSBi:
		uoxvtFlSXEPnf(SOEM49TbV0zuQ,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡏࡈࡒ࡚࡙࡟ࡄࡃࡆࡌࡊࡥࠧฏ")+ptGWavmbV7I9F5h0ROqzTNY8elLD+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡢࠫฐ")+AxES4pojwcuLMs,EcVTS7m3sH52OAhoxyY)
	return iSCy3XpY1N7OW5gemjv8xlIn9QMDd,FGnvJ1ZOyESbpuerf54w8U,EcVTS7m3sH52OAhoxyY,RM8ZdQkKxUFIDTz573,KGMvJO5RsciTk0jof3zID2aW9Ln,OTHqbvx8cyo5iwjCLSVu0zn,ptGWavmbV7I9F5h0ROqzTNY8elLD,AxES4pojwcuLMs
def hYESW9tlguGCq(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ,yotXRvP4md3Vrnhq9lBH1F,jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko):
	if jopJxNuhKylA7 in [IINBvuxkCSJrO1Q0UyngdLi(u"ࠪ࠵ࠬฑ"),YayJj10OGl(u"ࠫ࠷࠭ฒ"),qrjy8LuKVPNYdbSvzh(u"ࠬ࠹ࠧณ"),SSvu1CZjTW7FcloNqD(u"࠭࠴ࠨด"),t4txivgXSUWBOlCakQmNDjf(u"ࠧ࠶ࠩต"),Fo1SgXMsHk(u"ࠨ࠳࠴ࠫถ"),I3cxjYaHhsrM7T4UX26klN(u"ࠩ࠴࠶ࠬท"),QlTuvPbSpnjygBVW(u"ࠪ࠵࠸࠭ธ")] and ZcBfxUiVw9yeSzv8sGh34EW2QMko:
		import Z2ZSU6yEYJ
		Z2ZSU6yEYJ.YOqPCEczglNJma4xWU3QebRXwA2(p8pRVmk1Jg03PjfMonTFyvLCax,jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko)
		ue186CEMORWhvq(SmbNGskjMx,cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	elif jopJxNuhKylA7==wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫ࠻࠭น"):
		import RpSbDv2A79
		if ZcBfxUiVw9yeSzv8sGh34EW2QMko==xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧบ"): RpSbDv2A79.SSVCGE0bOfW1w9u52yvBxocNeP(xxtgfCnWOFlo0jTbU3PQI4Dq(u"๊࠭าฮ์ࠤฬ๊ว็ฬ฻หึ࠭ป"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧอษิ๎ࠥ็อึ่่ࠢๆࠦวๅฬะ้๏๊ࠧผ"),lQMuw1PvVpAk=flDSRbv57PnV3(u"࠷࠶࠰࠱Ꭰ"))
		elif ZcBfxUiVw9yeSzv8sGh34EW2QMko==bYyKEjIuGQzoq3AR1(u"ࠨࡆࡈࡐࡊ࡚ࡅࠨฝ"): yotXRvP4md3Vrnhq9lBH1F = l4DS8mnEjHhFMZ5YOe(u"࠹࠳࠵Ꭱ")
		bPFto2wZdNYrClgBIEv60DJAzu = RpSbDv2A79.QHAgKDUZvqTES8VMh(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,yotXRvP4md3Vrnhq9lBH1F,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
		if ZcBfxUiVw9yeSzv8sGh34EW2QMko==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫพ"): R5VzflU0D2LQaSoKOskBuYtrXFC()
	elif p8pRVmk1Jg03PjfMonTFyvLCax==bYyKEjIuGQzoq3AR1(u"ࠪ࠻ࠬฟ"):
		import H2VSdwTvpr
		H2VSdwTvpr.QLUli3kgWhOq(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡤࡇࡌࡍࠩภ"))
		ue186CEMORWhvq(SmbNGskjMx)
	elif p8pRVmk1Jg03PjfMonTFyvLCax==Fo1SgXMsHk(u"ࠬ࠾ࠧม"): RarSo2nTfwU0WEGK.executebuiltin(X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࠬย")+ldJmEsIZY9A4pXStekwNoTV+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡀ࡯ࡲࡨࡪࡃࠧร")+str(xv42oTYCQusGHzjMc3n01Zq)+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࠨࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠩࠨฤ"))
	elif p8pRVmk1Jg03PjfMonTFyvLCax==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩ࠼ࠫล"):
		ue186CEMORWhvq(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif p8pRVmk1Jg03PjfMonTFyvLCax==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪ࠵࠵࠭ฦ"):
		import H2VSdwTvpr
		H2VSdwTvpr.QLUli3kgWhOq(I3cxjYaHhsrM7T4UX26klN(u"ࠫࡤࡍࡏࡐࡉࡏࡉࠬว"))
		ue186CEMORWhvq(SmbNGskjMx)
	elif p8pRVmk1Jg03PjfMonTFyvLCax==xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬ࠷࠴ࠨศ"): ue186CEMORWhvq(Ag9l6cw3EBqP8HsQuGMizfOtr4,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡍࡆࡐࡘࡣࡗࡋࡖࡆࡔࡖࡉࡉ࠭ษ"))
	elif p8pRVmk1Jg03PjfMonTFyvLCax==bYyKEjIuGQzoq3AR1(u"ࠧ࠲࠷ࠪส"): ue186CEMORWhvq(Ag9l6cw3EBqP8HsQuGMizfOtr4,YayJj10OGl(u"ࠨࡏࡈࡒ࡚ࡥࡒࡂࡐࡇࡓࡒࡏ࡚ࡆࡆࠪห"))
	elif p8pRVmk1Jg03PjfMonTFyvLCax==YayJj10OGl(u"ࠩ࠴࠺ࠬฬ"): ue186CEMORWhvq(Ag9l6cw3EBqP8HsQuGMizfOtr4,IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡑࡊࡔࡕࡠࡃࡖࡇࡊࡔࡄࡆࡆࠪอ"))
	elif p8pRVmk1Jg03PjfMonTFyvLCax==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫ࠶࠽ࠧฮ"): ue186CEMORWhvq(Ag9l6cw3EBqP8HsQuGMizfOtr4,qrjy8LuKVPNYdbSvzh(u"ࠬࡓࡅࡏࡗࡢࡈࡊ࡙ࡃࡆࡐࡇࡉࡉ࠭ฯ"))
	if p8pRVmk1Jg03PjfMonTFyvLCax in [l4DS8mnEjHhFMZ5YOe(u"࠭࠹ࠨะ"),z3sIGH8jmLYg(u"ࠧ࠲࠶ࠪั"),flDSRbv57PnV3(u"ࠨ࠳࠸ࠫา"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࠴࠺ࠬำ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪ࠵࠼࠭ิ")]: R5VzflU0D2LQaSoKOskBuYtrXFC()
	return
def AAMHj7rFgDiz6oeaBmy0vfQI4x(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ,yotXRvP4md3Vrnhq9lBH1F,jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko,NNntz8hA93kG6WqEDb1OUoeFm2fg):
	if QQpBeZUlAbNKHfkCDLcqWYzv5: LxDfBKHwXrV6RZn2y1C3o4zU9hgIi()
	if p8pRVmk1Jg03PjfMonTFyvLCax: hYESW9tlguGCq(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ,yotXRvP4md3Vrnhq9lBH1F,jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko)
	At4mLshzQXaIrJlK()
	ylGTu5RkOxQEeCD(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC = Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx,SmbNGskjMx
	NulH64AFUhB2nPM0kRyYJ = xMSOwCX3PWYvAyFKaR1sZTV8GoLg(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ,yotXRvP4md3Vrnhq9lBH1F,NNntz8hA93kG6WqEDb1OUoeFm2fg,EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC)
	iSCy3XpY1N7OW5gemjv8xlIn9QMDd,FGnvJ1ZOyESbpuerf54w8U,EcVTS7m3sH52OAhoxyY,RM8ZdQkKxUFIDTz573,KGMvJO5RsciTk0jof3zID2aW9Ln,OTHqbvx8cyo5iwjCLSVu0zn,ptGWavmbV7I9F5h0ROqzTNY8elLD,AxES4pojwcuLMs = NulH64AFUhB2nPM0kRyYJ
	if iSCy3XpY1N7OW5gemjv8xlIn9QMDd: return
	if FGnvJ1ZOyESbpuerf54w8U==DJ6ugPjW9bX8I(u"ࠫࡗࡋࡆࡓࡇࡖࡌࡤࡉࡁࡄࡊࡈࠫี"): hTxAoj52vsb6Mze9rnmIk7lNJg(zDoPOYNsJg2id1HLnx5bpf)
	UUlNOsvLb1(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡹࡴࡢࡴࡷࠫึ"))
	if llnG7jiQBYKhAeovbT.getSetting(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬื")) not in [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡂࡗࡗࡓุࠬ"),X1mRwt2YJKgCLu9a67(u"ࠨࡕࡗࡓࡕู࠭"),DJ6ugPjW9bX8I(u"ࠩࡏࡍࡒࡏࡔࡆࡆฺࠪ")]:
		llnG7jiQBYKhAeovbT.setSetting(ulAxHwvzR9eTb5n(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡨࡵࡶࡳࡧࡦࡩࡨࡦࠩ฻"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡆ࡛ࡔࡐࠩ฼"))
	if not llnG7jiQBYKhAeovbT.getSetting(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡧࡶ࠯ࡦࡱࡷࠬ฽")): llnG7jiQBYKhAeovbT.setSetting(z3sIGH8jmLYg(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭฾"),jUy8IAthCYOu5k[f4fTutDOEwUeIoPLRQ])
	bPFto2wZdNYrClgBIEv60DJAzu = QHAgKDUZvqTES8VMh(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
	if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ฿") in om2lqtcZ5y4j: YYSzLsNiAr2R8FcBbIuleHv471UMp = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==bYyKEjIuGQzoq3AR1(u"ࠨࡨࡲࡰࡩ࡫ࡲࠨเ"):
		if RM8ZdQkKxUFIDTz573!=SSvu1CZjTW7FcloNqD(u"ࠩ࠱࠲ࠬแ") and KGMvJO5RsciTk0jof3zID2aW9Ln: UKzkraEisF0wRZ()
		if KXth1AHMv64CskLiWESrzuey>-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			gjnd0tEm8PSlXsufA31iGvp2bxT = [f4fTutDOEwUeIoPLRQ,fgv5U2eRVaQqSiuGD(u"࠲࠷Ꭳ"),flDSRbv57PnV3(u"࠳࠺Ꭴ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠴࠽Ꭵ"),X1mRwt2YJKgCLu9a67(u"࠲࠷Ꭲ"),tM24jD1gO0(u"࠹࠴Ꭸ"),bnI4kmPtrW7yFEhljXOCq9(u"࠹࠵Ꭶ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠺࠹Ꭷ")]
			if (r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,SSvu1CZjTW7FcloNqD(u"ࠪ࡭ࡳࡺࠧโ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡒࡏࡓࡄࡡࡓࡉࡗࡓࠧใ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࡙ࠬࡉࡕࡇࡖࡣࡓࡇࡍࡆࡕࠪไ")) or yotXRvP4md3Vrnhq9lBH1F not in gjnd0tEm8PSlXsufA31iGvp2bxT) and not QQ3hd2tR8s.F8e4uNA5OfTIHvkg6lCJt2BZ:
				from ZyG6Wbnpi0 import ge0AtaIO6npZ8qRHUhusX
				wt89goCIrDRZ = ppaqdOoPjl9AsWD(ge0AtaIO6npZ8qRHUhusX)
				iSCy3XpY1N7OW5gemjv8xlIn9QMDd = uS4rEdcNAC3wxVR0XJ7ypgaQKnMl52(EcVTS7m3sH52OAhoxyY,wt89goCIrDRZ,EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC)
				if wt89goCIrDRZ and OTHqbvx8cyo5iwjCLSVu0zn:
					z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡍࡆࡐࡘࡗࡤࡉࡁࡄࡊࡈࡣࠬๅ")+ptGWavmbV7I9F5h0ROqzTNY8elLD+l4DS8mnEjHhFMZ5YOe(u"ࠧࡠࠩๆ")+AxES4pojwcuLMs,EcVTS7m3sH52OAhoxyY,wt89goCIrDRZ,RRYx6sACloVPr3td95Ej)
			else:
				WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.addDirectoryItem(KXth1AHMv64CskLiWESrzuey,QlTuvPbSpnjygBVW(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠫ็")+ldJmEsIZY9A4pXStekwNoTV+I3cxjYaHhsrM7T4UX26klN(u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿࡯࡭ࡳࡱࠦ࡮ࡱࡧࡩࡂ࠻࠰࠱่ࠩ"),LAkCFq8ezcf.ListItem(UpQ56M0dO1N9xIvVegy(u"่ࠪิ๐ใࠡ็ื็้ฯࠠๆ่ࠣะ์อาไ้ࠩ")))
				WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.addDirectoryItem(KXth1AHMv64CskLiWESrzuey,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵๊ࠧ")+ldJmEsIZY9A4pXStekwNoTV+UpQ56M0dO1N9xIvVegy(u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡲࡩ࡯࡭ࠩࡱࡴࡪࡥ࠾࠷࠳࠴๋ࠬ"),LAkCFq8ezcf.ListItem(IINBvuxkCSJrO1Q0UyngdLi(u"࠭รโฬะࠤ้ะโาลࠣห้ะแศืํ่ࠬ์")))
			WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.endOfDirectory(KXth1AHMv64CskLiWESrzuey,EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC)
	return
def hTxAoj52vsb6Mze9rnmIk7lNJg(Uxytso74zZjcrW0aSbe):
	if flDSRbv57PnV3(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩํ") in mHhBGP1spJW4kfAvbj92qVZ or paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࡢࡘࡘ࠭๎") in mHhBGP1spJW4kfAvbj92qVZ: return
	OtpPuWXsQ7REvaU36CiMd = SmbNGskjMx if Uxytso74zZjcrW0aSbe else Ag9l6cw3EBqP8HsQuGMizfOtr4
	if not OtpPuWXsQ7REvaU36CiMd:
		ojXhyB91iAMZ6zG = jB7hQVAxCkgwsDE5bOa83u9KXt4(llnG7jiQBYKhAeovbT.getSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪ๏")))
		ojXhyB91iAMZ6zG = f4fTutDOEwUeIoPLRQ if not ojXhyB91iAMZ6zG else int(ojXhyB91iAMZ6zG)
		if not ojXhyB91iAMZ6zG or not f4fTutDOEwUeIoPLRQ<=sqeRK2tVw8-ojXhyB91iAMZ6zG<=Uxytso74zZjcrW0aSbe: OtpPuWXsQ7REvaU36CiMd = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if not OtpPuWXsQ7REvaU36CiMd:
		RI8zp3O9t0M6xBLX = llnG7jiQBYKhAeovbT.getSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴࡭ࡦࡵࡶࡥ࡬࡫ࡳࠨ๐"))
		if RI8zp3O9t0M6xBLX in [nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪ๑"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫ๒")]: OtpPuWXsQ7REvaU36CiMd = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if not OtpPuWXsQ7REvaU36CiMd:
		kpO5U0B31byGJauY4SmdfR = llnG7jiQBYKhAeovbT.getSetting(QlTuvPbSpnjygBVW(u"࠭ࡡࡷ࠰ࡳࡶ࡮ࡼࡳ࠲ࠩ๓"))
		D5RkyXEmpB = llnG7jiQBYKhAeovbT.getSetting(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡢࡸ࠱ࡴࡷ࡯ࡶࡴ࠴ࠪ๔"))
		ImVTYeswlrzB6L1jN9 = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(z3sIGH8jmLYg(u"࠵Ꭹ")*kpO5U0B31byGJauY4SmdfR.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()
		ImVTYeswlrzB6L1jN9 = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(X1mRwt2YJKgCLu9a67(u"࠲࠶Ꭺ")*ImVTYeswlrzB6L1jN9.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()
		ImVTYeswlrzB6L1jN9 = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠳࠼Ꭻ")*ImVTYeswlrzB6L1jN9.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()
		if ImVTYeswlrzB6L1jN9!=D5RkyXEmpB: OtpPuWXsQ7REvaU36CiMd = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if OtpPuWXsQ7REvaU36CiMd: PPoDgmISRnpCy8hO6JYaTB(SmbNGskjMx)
	return
def QHAgKDUZvqTES8VMh(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ):
	yotXRvP4md3Vrnhq9lBH1F = int(xv42oTYCQusGHzjMc3n01Zq)
	tWCYOJ19zpPNAawmf = int(yotXRvP4md3Vrnhq9lBH1F//YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠴࠴Ꭼ"))
	if   tWCYOJ19zpPNAawmf==f4fTutDOEwUeIoPLRQ:  from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==vkIa3ijEQVsJGdWOXwK7bnue9ADR:  from ccvSIPmxgW 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==QQSugEIn2mTCpRsfcaJHhPdAWzylM:  from sAqTFayKmW 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb:  from q4jPZGfbsQ 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==WtDrnpJmwQ37Z2Ae68hu4BY5M1:  from hjYJ5cngVB 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,ohpwd6UumaecE3IWV8lAv0)
	elif tWCYOJ19zpPNAawmf==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠹Ꭽ"):  from CMxWve5LZA 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==QlTuvPbSpnjygBVW(u"࠻Ꭾ"):  from Ftp6bAeKPu 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠽Ꭿ"):  from Pl9syVGTF0 			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠸Ꮀ"):  from bVgMzdZK7e 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==flDSRbv57PnV3(u"࠺Ꮁ"):  from YHdQMbUxS9		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠳࠳Ꮂ"): from DqbknNGvlo 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX)
	elif tWCYOJ19zpPNAawmf==DJ6ugPjW9bX8I(u"࠴࠵Ꮃ"): from v1skFBGlrX 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==l4DS8mnEjHhFMZ5YOe(u"࠵࠷Ꮄ"): from haJBXMtW9Y 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==QlTuvPbSpnjygBVW(u"࠶࠹Ꮅ"): from l5QuNeS31A		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==qrjy8LuKVPNYdbSvzh(u"࠷࠴Ꮆ"): from VtJMTRCpWz 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0,hXFjqduwKEt2TDC,nnu5vdh1IscOA8J)
	elif tWCYOJ19zpPNAawmf==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠱࠶Ꮇ"): from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠲࠸Ꮈ"): from A2rd6UB4H7		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ)
	elif tWCYOJ19zpPNAawmf==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠳࠺Ꮉ"): from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠴࠼Ꮊ"): from dfWITBHxcs		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==UpQ56M0dO1N9xIvVegy(u"࠵࠾Ꮋ"): from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==X60YQOADpkHBb31LiR5qUEKfM(u"࠷࠶Ꮌ"): from czHXgtQlrJ		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠸࠱Ꮍ"): from vID5SVuoAQ	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==flDSRbv57PnV3(u"࠲࠳Ꮎ"): from ivnrQ2C53o		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==IINBvuxkCSJrO1Q0UyngdLi(u"࠳࠵Ꮏ"): from FFiPRp8szx			import z4CledbofIyhpZVjugFO; bPFto2wZdNYrClgBIEv60DJAzu = z4CledbofIyhpZVjugFO(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ)
	elif tWCYOJ19zpPNAawmf==z3sIGH8jmLYg(u"࠴࠷Ꮐ"): from Hn1ehdUPB2 			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bYyKEjIuGQzoq3AR1(u"࠵࠹Ꮑ"): from cczNkUM8e6 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠶࠻Ꮒ"): from ZyG6Wbnpi0 			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==l4DS8mnEjHhFMZ5YOe(u"࠷࠽Ꮓ"): from Z2ZSU6yEYJ		import z4CledbofIyhpZVjugFO; bPFto2wZdNYrClgBIEv60DJAzu = z4CledbofIyhpZVjugFO(yotXRvP4md3Vrnhq9lBH1F,p8pRVmk1Jg03PjfMonTFyvLCax)
	elif tWCYOJ19zpPNAawmf==YayJj10OGl(u"࠸࠸Ꮔ"): from FFiPRp8szx			import z4CledbofIyhpZVjugFO; bPFto2wZdNYrClgBIEv60DJAzu = z4CledbofIyhpZVjugFO(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ)
	elif tWCYOJ19zpPNAawmf==z3sIGH8jmLYg(u"࠲࠺Ꮕ"): from V3LyopAcbw	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==cb3rmvAn4wa6lBPz2phOoYqX(u"࠴࠲Ꮖ"): from nIEpzfZOeA		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==t4txivgXSUWBOlCakQmNDjf(u"࠵࠴Ꮗ"): from Gna4eLcofr		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠶࠶Ꮘ"): from yitX6wlQ4H		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==QlTuvPbSpnjygBVW(u"࠷࠸Ꮙ"): from VVg6xidT03		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX)
	elif tWCYOJ19zpPNAawmf==z3sIGH8jmLYg(u"࠸࠺Ꮚ"): from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠹࠵Ꮛ"): from NC5BwOzQK0		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠳࠷Ꮜ"): from mJhnvlc9Rr			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠴࠹Ꮝ"): from FO9Pcsk5Xz			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==X60YQOADpkHBb31LiR5qUEKfM(u"࠵࠻Ꮞ"): from kDOBzqPZK3 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==X60YQOADpkHBb31LiR5qUEKfM(u"࠶࠽Ꮟ"): from WVBqhxkTJo		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==t4txivgXSUWBOlCakQmNDjf(u"࠸࠵Ꮠ"): from d7aRis2qhk	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0)
	elif tWCYOJ19zpPNAawmf==YayJj10OGl(u"࠹࠷Ꮡ"): from d7aRis2qhk	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0)
	elif tWCYOJ19zpPNAawmf==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠺࠲Ꮢ"): from ddhk8UY93x			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==cb3rmvAn4wa6lBPz2phOoYqX(u"࠴࠴Ꮣ"): from K8bGaEqlm7			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠵࠶Ꮤ"): from wsFPH620Aj		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠶࠸Ꮥ"): from UpMWqXALaE		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠷࠺Ꮦ"): from JfVHmqYKhQ			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==flDSRbv57PnV3(u"࠸࠼Ꮧ"): from eCcV9bE5Xv		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠹࠾Ꮨ"): from vfJn9cWZFU		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==I3cxjYaHhsrM7T4UX26klN(u"࠺࠹Ꮩ"): from aXsbM5p7he		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==UpQ56M0dO1N9xIvVegy(u"࠵࠱Ꮪ"): from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==X60YQOADpkHBb31LiR5qUEKfM(u"࠶࠳Ꮫ"): from SiCDoLXH6M 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==ulAxHwvzR9eTb5n(u"࠷࠵Ꮬ"): from SiCDoLXH6M 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠸࠷Ꮭ"): from ZyG6Wbnpi0 			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bnI4kmPtrW7yFEhljXOCq9(u"࠹࠹Ꮮ"): from H2VSdwTvpr	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,ohpwd6UumaecE3IWV8lAv0)
	elif tWCYOJ19zpPNAawmf==bnI4kmPtrW7yFEhljXOCq9(u"࠺࠻Ꮯ"): from TTfGtcnHWg 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠻࠶Ꮰ"): from WFjdaCvr19		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==l4DS8mnEjHhFMZ5YOe(u"࠵࠸Ꮱ"): from STvH5VK2LM		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠶࠺Ꮲ"): from jex85kwigp		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==l4DS8mnEjHhFMZ5YOe(u"࠷࠼Ꮳ"): from zpPiFvoSsY		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠹࠴Ꮴ"): from uu03lAibVf			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==qrjy8LuKVPNYdbSvzh(u"࠺࠶Ꮵ"): from k1ktzYv3H8			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==z3sIGH8jmLYg(u"࠻࠸Ꮶ"): from ZQYi1DaW6c		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠼࠳Ꮷ"): from fLXsKkaCtv	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bnI4kmPtrW7yFEhljXOCq9(u"࠶࠵Ꮸ"): from S5S2A0HuKB			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠷࠷Ꮹ"): from xpvHg7OTXf			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==IINBvuxkCSJrO1Q0UyngdLi(u"࠸࠹Ꮺ"): from T5WmUMzDlV			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠹࠻Ꮻ"): from bjdzha45nm		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠺࠽Ꮼ"): from IxG4zq92Yi		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==IINBvuxkCSJrO1Q0UyngdLi(u"࠻࠿Ꮽ"): from RfNHdv4g16		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bnI4kmPtrW7yFEhljXOCq9(u"࠽࠰Ꮾ"): from rxPoLEUGuR			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠷࠲Ꮿ"): from EEdIMHGg4C			import z4CledbofIyhpZVjugFO; bPFto2wZdNYrClgBIEv60DJAzu = z4CledbofIyhpZVjugFO(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠸࠴Ᏸ"): from EEdIMHGg4C			import z4CledbofIyhpZVjugFO; bPFto2wZdNYrClgBIEv60DJAzu = z4CledbofIyhpZVjugFO(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠹࠶Ᏹ"): from UVzJMx3sLg	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠺࠸Ᏺ"): from ttafkd4Mij		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F)
	elif tWCYOJ19zpPNAawmf==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠻࠺Ᏻ"): from ttafkd4Mij		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F)
	elif tWCYOJ19zpPNAawmf==X60YQOADpkHBb31LiR5qUEKfM(u"࠼࠼Ᏼ"): from A2rd6UB4H7		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ)
	elif tWCYOJ19zpPNAawmf==I3cxjYaHhsrM7T4UX26klN(u"࠽࠷Ᏽ"): from O6kUi5MdYE 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==z3sIGH8jmLYg(u"࠷࠹᏶"): from dt8zS4wDlp 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠸࠻᏷"): from Njvc8kFO4M 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠺࠳ᏸ"): from IcsWHablxw 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==YayJj10OGl(u"࠻࠵ᏹ"): from EfAJioaxd9 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠼࠷ᏺ"): from hXfZLEF01s		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==qrjy8LuKVPNYdbSvzh(u"࠽࠹ᏻ"): from FgxXCuKmjD		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠾࠴ᏼ"): from yz4Xr08SJb		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==fgv5U2eRVaQqSiuGD(u"࠸࠶ᏽ"): from A9pml3Qkxv		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==l4DS8mnEjHhFMZ5YOe(u"࠹࠸᏾"): from HHs8Sbglyo		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==UpQ56M0dO1N9xIvVegy(u"࠺࠺᏿"): from NLytcHfudP			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==IINBvuxkCSJrO1Q0UyngdLi(u"࠻࠼᐀"): from gIShpZ2xam			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠼࠾ᐁ"): from xkUrXP4pzH		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠾࠶ᐂ"): from nXRDE6wr72	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==z3sIGH8jmLYg(u"࠿࠱ᐃ"): from zECDyiN8cF		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==I3cxjYaHhsrM7T4UX26klN(u"࠹࠳ᐄ"): from usfqYpW9IU		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==I3cxjYaHhsrM7T4UX26klN(u"࠺࠵ᐅ"): from HRDks6JM5E		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠻࠷ᐆ"): from ruASsnwQOE			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠼࠹ᐇ"): from EDIPjT1y0b			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠽࠻ᐈ"): from sLgUQ9jwV5		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==fgv5U2eRVaQqSiuGD(u"࠾࠽ᐉ"): from BPecgpzADO		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==Fo1SgXMsHk(u"࠿࠸ᐊ"): from XaJItuHFfp		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==IINBvuxkCSJrO1Q0UyngdLi(u"࠹࠺ᐋ"): from l5WCgAFxHq		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠲࠲࠳ᐌ"): from CXPRLeTGkJ		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==l4DS8mnEjHhFMZ5YOe(u"࠳࠳࠵ᐍ"): from xUG0JazuM7	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠴࠴࠷ᐎ"): from SJqrPsfTgG 		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠵࠵࠹ᐏ"): from bX2UYRVk06	import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠶࠶࠴ᐐ"): from pu8iReDhBs		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==YayJj10OGl(u"࠷࠰࠶ᐑ"): from FjfEaWPULS			import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==t4txivgXSUWBOlCakQmNDjf(u"࠱࠱࠸ᐒ"): from LLJYZsrlXm		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	elif tWCYOJ19zpPNAawmf==SSvu1CZjTW7FcloNqD(u"࠲࠲࠺ᐓ"): from U7zP2CIs3p		import n1zxUlcAgR	; bPFto2wZdNYrClgBIEv60DJAzu = n1zxUlcAgR(yotXRvP4md3Vrnhq9lBH1F,qxZiT6WJ7sX,om2lqtcZ5y4j)
	else: bPFto2wZdNYrClgBIEv60DJAzu = None
	return bPFto2wZdNYrClgBIEv60DJAzu
def ATgivCW6tZwuBHkmNKc(XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv,eg6iV4ckQxvTrjWKyBulYR,showDialogs):
	HMPtOcVoJiXCu8z0nesDWYkIl9ER = eg6iV4ckQxvTrjWKyBulYR.split(Fo1SgXMsHk(u"ࠨ࠯ࠪ๕"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ] if cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩ࠰ࠫ๖") in eg6iV4ckQxvTrjWKyBulYR else eg6iV4ckQxvTrjWKyBulYR
	if not showDialogs or eg6iV4ckQxvTrjWKyBulYR in nfm7agrTI9E: return SmbNGskjMx
	zWym0pg9wja74X5xRQdYUe6nkEvKSt = llnG7jiQBYKhAeovbT.getSetting(z3sIGH8jmLYg(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ๗"))
	llnG7jiQBYKhAeovbT.setSetting(ulAxHwvzR9eTb5n(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ๘"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	ZPUvmfita1o = XqLr3B9MPx in [SSvu1CZjTW7FcloNqD(u"࠼ᐗ"),tM24jD1gO0(u"࠴࠵࠵࠶࠱ᐕ"),cb3rmvAn4wa6lBPz2phOoYqX(u"࠳࠴࠴࠵࠸ᐔ"),X1mRwt2YJKgCLu9a67(u"࠵࠵࠶࠵࠵ᐖ")]
	TU7clH3dzIEBv0851kXuJVQgCLKP = szmD9nEACSWOyk15fPl0QZoTv.lower()
	fHYTLteivsD1c6P = XqLr3B9MPx in [f4fTutDOEwUeIoPLRQ,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠲࠲࠷ᐚ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠷࠰࠱࠸࠴ᐘ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠱࠲࠳ᐙ")]
	LFru60YPp4WgkZA7basqoQ = z3sIGH8jmLYg(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭๙") in TU7clH3dzIEBv0851kXuJVQgCLKP
	qxOio3nZ4VbNzuPtI2TefaMg0BQ = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡢ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭๚") in TU7clH3dzIEBv0851kXuJVQgCLKP
	ANb4e6v9wKs = UpQ56M0dO1N9xIvVegy(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧࠧ๛") in TU7clH3dzIEBv0851kXuJVQgCLKP
	N3a2E04ZGYLwTQgCiPWehxnJfMcOom = SSvu1CZjTW7FcloNqD(u"ࠨࡤ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡩ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠢࡶࡩࡨࡻࡲࡪࡶࡼࠤࡨ࡮ࡥࡤ࡭ࠪ๜") in TU7clH3dzIEBv0851kXuJVQgCLKP
	EVzcAfpnQ1twxiO7bBjNM4DuW9r = llnG7jiQBYKhAeovbT.getSetting(bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧ๝"))
	slg0MoqUyXDtVp5cIFfdiRvJ = llnG7jiQBYKhAeovbT.getSetting(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭๞"))
	xtpbd4PRCk1 = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫๆฺไࠡใํࠤุำศࠡษ็ูๆำษࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭๟")
	Pg42zEF7h6Tx0sbjtM8H = bYyKEjIuGQzoq3AR1(u"ࠬࡋࡲࡳࡱࡵࠤࠬ๠")+str(XqLr3B9MPx)+YayJj10OGl(u"࠭࠺ࠡࠩ๡")+szmD9nEACSWOyk15fPl0QZoTv
	Pg42zEF7h6Tx0sbjtM8H = SxN0jnqr3LI(Pg42zEF7h6Tx0sbjtM8H)
	if fHYTLteivsD1c6P or LFru60YPp4WgkZA7basqoQ or qxOio3nZ4VbNzuPtI2TefaMg0BQ or ANb4e6v9wKs or N3a2E04ZGYLwTQgCiPWehxnJfMcOom: xtpbd4PRCk1 += wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࠡ࠰ࠣห้๋่ใ฻ࠣๅ๏ํࠠฮฮหࠤ฻ีࠠไ๊า๎๋ࠥีะำ๊ࠤฬ๊ล็ฬิ๊ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࡡࡴࠧ๢")
	if ZPUvmfita1o: xtpbd4PRCk1 += X1mRwt2YJKgCLu9a67(u"ࠨࠢ࠱ࠤ้ี๊ไࠢั฻ศࠦࡄࡏࡕࠣ์๊฿ๆศ้ࠣฮ฾ึัࠡฬิะ๊ฯࠠศี่ࠤฬ๊ๅ้ไ฼ࠤส๊้ࠡำๅ้์ࡢ࡮ࠨ๣")
	Pg42zEF7h6Tx0sbjtM8H = wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+Pg42zEF7h6Tx0sbjtM8H+c7gxFyUCGm
	if EVzcAfpnQ1twxiO7bBjNM4DuW9r==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡄࡗࡐ࠭๤") or slg0MoqUyXDtVp5cIFfdiRvJ==UpQ56M0dO1N9xIvVegy(u"ࠪࡅࡘࡑࠧ๥"):
		xtpbd4PRCk1 += wwOnIucWJj+l5JG7XwbOfo8DznU+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫ์๊ࠠหำํำࠥษๆࠡ์ะหํ๊ࠠศๆหี๋อๅอࠢศู้ออࠡษ็ู้้ไสࠢ࠱࠲ࠥษๅࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤศ๎ࠠฯูฦࠤส๊้ࠡษ็้อืๅอࠢยࠥࠦ࠭๦")+c7gxFyUCGm
	rsYWjvmXn4SZzOkgCuwUldVhKc9DJB = SmbNGskjMx
	if EVzcAfpnQ1twxiO7bBjNM4DuW9r==l4DS8mnEjHhFMZ5YOe(u"ࠬࡇࡓࡌࠩ๧") or slg0MoqUyXDtVp5cIFfdiRvJ==X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡁࡔࡍࠪ๨"):
		K4O6aMFQSLIbWxtGpPy2gZDB5q = YuqCtbB0XfT6rGUwS5z79VDk3del2E(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡤࡧࡱࡸࡪࡸࠧ๩"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨะิ์ั࠭๪"),l4DS8mnEjHhFMZ5YOe(u"ࠩศีุอไࠡๆ็้อืๅอࠩ๫"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪฮฺ๊๊ฮࠢสฺ่๊ใๅหࠪ๬"),HMPtOcVoJiXCu8z0nesDWYkIl9ER+PCnucez1ITGQbklj7SoqNtw0O8+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER),xtpbd4PRCk1+wwOnIucWJj+Pg42zEF7h6Tx0sbjtM8H)
		if K4O6aMFQSLIbWxtGpPy2gZDB5q==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			from SJqrPsfTgG import IbOgDw5uNE16VosCFnShBl
			IbOgDw5uNE16VosCFnShBl()
		elif K4O6aMFQSLIbWxtGpPy2gZDB5q==QQSugEIn2mTCpRsfcaJHhPdAWzylM: rsYWjvmXn4SZzOkgCuwUldVhKc9DJB = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,HMPtOcVoJiXCu8z0nesDWYkIl9ER+PCnucez1ITGQbklj7SoqNtw0O8+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER),xtpbd4PRCk1,Pg42zEF7h6Tx0sbjtM8H)
	llnG7jiQBYKhAeovbT.setSetting(UpQ56M0dO1N9xIvVegy(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ๭"),zWym0pg9wja74X5xRQdYUe6nkEvKSt)
	return rsYWjvmXn4SZzOkgCuwUldVhKc9DJB
def NrCbofjFaXYHOd0htmn(xQNTKXvLZHsYirpyWR5CPb=SmbNGskjMx,eWbRXDycKUoq64j7MT=[]):
	CKHtGuVy3a01FATsD = [TTrFaqDzxJOsh90UHIZ5,g8FzaRfU7Zx9HeSBNtJ]+eWbRXDycKUoq64j7MT
	for Oy2mWPY6LEsN3S95f in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(iy1kK0BAJVLazhHpnZEqrYt9dOfW):
		if xQNTKXvLZHsYirpyWR5CPb and (Oy2mWPY6LEsN3S95f.startswith(IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࡯ࡰࡵࡸࠪ๮")) or Oy2mWPY6LEsN3S95f.startswith(QlTuvPbSpnjygBVW(u"࠭࡭࠴ࡷࠪ๯"))): continue
		if Oy2mWPY6LEsN3S95f.startswith(IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡧ࡫࡯ࡩࡤ࠭๰")): continue
		p6IsE1yuKZe30OgAt5hfqYFzU = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,Oy2mWPY6LEsN3S95f)
		if p6IsE1yuKZe30OgAt5hfqYFzU in CKHtGuVy3a01FATsD: continue
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(p6IsE1yuKZe30OgAt5hfqYFzU)
		except: pass
	if yi4Em23SQL9GNOBzXcshRV7wg6IUM0 not in CKHtGuVy3a01FATsD: bQaAGNXBYIgClLm15ui3JqU(yi4Em23SQL9GNOBzXcshRV7wg6IUM0,Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
	lQMuw1PvVpAk.sleep(QlTuvPbSpnjygBVW(u"࠳ᐛ"))
	return
def ZDNzeFMqkLrpd50mvHQAhX(TTGlSLMqrHIkpsOQPjyNCW0xU6,hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh=Ag9l6cw3EBqP8HsQuGMizfOtr4,PPpCE2Tu0edtVKg1U=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	qxZiT6WJ7sX = qxZiT6WJ7sX+X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨ๱")+TTGlSLMqrHIkpsOQPjyNCW0xU6
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh,PPpCE2Tu0edtVKg1U)
	if qxZiT6WJ7sX in cA6C7PMTuUklQdfoYqZgXj2FrJN.content: cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded = SmbNGskjMx
	if not cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		R5VzflU0D2LQaSoKOskBuYtrXFC()
	return cA6C7PMTuUklQdfoYqZgXj2FrJN
def dzvVGSPAxQ5CTonjMU6atOwb(qxZiT6WJ7sX):
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,qrjy8LuKVPNYdbSvzh(u"ࠩࡊࡉ࡙࠭๲"),qxZiT6WJ7sX,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡔࡠࡒࡕࡓ࡝ࡏࡅࡔࡡࡏࡍࡘ࡚࠭࠲ࡵࡷࠫ๳"),Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
	f63vOeZN1dGAXlqTE4tnoPCg = []
	if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
		C5I4jEZm8JedFvWY0aSroRTl1 = ScntgdOZCY74vNpXeW5jh8i.findall(DJ6ugPjW9bX8I(u"ࠫࠥ࠮࠮ࠫࡁࠬࠤࡡࡪࡻ࠲࠮࠶ࢁࡲࡹࠧ๴"),B69RXYW5vf8Jt7O)
		if C5I4jEZm8JedFvWY0aSroRTl1: B69RXYW5vf8Jt7O = wwOnIucWJj.join(C5I4jEZm8JedFvWY0aSroRTl1)
		xX4R8BQn19 = B69RXYW5vf8Jt7O.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(wwOnIucWJj).split(wwOnIucWJj)
		f63vOeZN1dGAXlqTE4tnoPCg = []
		for TTGlSLMqrHIkpsOQPjyNCW0xU6 in xX4R8BQn19:
			if TTGlSLMqrHIkpsOQPjyNCW0xU6.count(l4DS8mnEjHhFMZ5YOe(u"ࠬ࠴ࠧ๵"))==ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb: f63vOeZN1dGAXlqTE4tnoPCg.append(TTGlSLMqrHIkpsOQPjyNCW0xU6)
	return f63vOeZN1dGAXlqTE4tnoPCg
def gjuezhF7pckGb(*aargs):
	RBjIWdK2C4GwUTSO95c6 = xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡵࡸ࡯ࡹࡻࡶࡧࡷࡧࡰࡦ࠰ࡦࡳࡲ࠵ࡶ࠳࠱ࡂࡶࡪࡷࡵࡦࡵࡷࡁࡩ࡯ࡳࡱ࡮ࡤࡽࡵࡸ࡯ࡹ࡫ࡨࡷࠫࡶࡲࡰࡺࡼࡸࡾࡶࡥ࠾ࡪࡷࡸࡵࠬࡴࡪ࡯ࡨࡳࡺࡺ࠽࠲࠲࠳࠴࠵ࠬࡳࡴ࡮ࡀࡽࡪࡹࠦ࡭࡫ࡰ࡭ࡹࡃ࠱࠱ࠨࡦࡳࡺࡴࡴࡳࡻࡀࡒࡑ࠲ࡂࡆ࠮ࡇࡉ࠱ࡌࡒ࠭ࡉࡅ࠰࡙ࡘࠧ๶")
	MgFzHUqoxBnwiNakX3tGmv6 = Fo1SgXMsHk(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡰࡱࡶࡸࡪࡸ࡫ࡪࡦ࠲ࡳࡵ࡫࡮ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡱࡦ࡯࡮࠰ࡊࡗࡘࡕ࡙࠮ࡵࡺࡷࠫ๷")
	MLjfFZmN319o8POQXUep = dzvVGSPAxQ5CTonjMU6atOwb(MgFzHUqoxBnwiNakX3tGmv6)
	f63vOeZN1dGAXlqTE4tnoPCg = dzvVGSPAxQ5CTonjMU6atOwb(RBjIWdK2C4GwUTSO95c6)
	gomrbf2REaQ5kVjL = MLjfFZmN319o8POQXUep+f63vOeZN1dGAXlqTE4tnoPCg
	fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧ๸")+str(len(MLjfFZmN319o8POQXUep))+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩ࠮ࠫ๹")+str(len(f63vOeZN1dGAXlqTE4tnoPCg))+l4DS8mnEjHhFMZ5YOe(u"ࠪࠤࡢ࠭๺"))
	TTGlSLMqrHIkpsOQPjyNCW0xU6 = llnG7jiQBYKhAeovbT.getSetting(l4DS8mnEjHhFMZ5YOe(u"ࠫࡦࡼ࠮ࡱࡴࡲࡼࡾ࠴࡬ࡢࡵࡷࠫ๻"))
	cA6C7PMTuUklQdfoYqZgXj2FrJN = zJpU8hfZnevcG()
	llnG7jiQBYKhAeovbT.setSetting(I3cxjYaHhsrM7T4UX26klN(u"ࠬࡧࡶ࠯ࡲࡵࡳࡽࡿ࠮࡭ࡣࡶࡸࠬ๼"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if TTGlSLMqrHIkpsOQPjyNCW0xU6 or gomrbf2REaQ5kVjL:
		qeVZY0a5zp,rXKsDBmP18gdEl4LWbU6 = f4fTutDOEwUeIoPLRQ,z3sIGH8jmLYg(u"࠴࠴ᐜ")
		qpcQYfMldbrsZKOXiz = len(gomrbf2REaQ5kVjL)
		ZZXQEmj512B = rXKsDBmP18gdEl4LWbU6
		if qpcQYfMldbrsZKOXiz>ZZXQEmj512B: MqFsjGz7m9nLJQ0ti513r = ZZXQEmj512B
		else: MqFsjGz7m9nLJQ0ti513r = qpcQYfMldbrsZKOXiz
		h3BRGsU1yL = eH7yw1hTGUROK2B4dcP0iEr.sample(gomrbf2REaQ5kVjL,MqFsjGz7m9nLJQ0ti513r)
		if TTGlSLMqrHIkpsOQPjyNCW0xU6: h3BRGsU1yL = [TTGlSLMqrHIkpsOQPjyNCW0xU6]+h3BRGsU1yL
		wc1BZOYyvQH2f = ps6AtMmOZI5izVcr4hF0xn9TJE7RL(SmbNGskjMx,SmbNGskjMx)
		BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
		while lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9<=rXKsDBmP18gdEl4LWbU6 and not wc1BZOYyvQH2f.finishedLIST:
			if qeVZY0a5zp<MqFsjGz7m9nLJQ0ti513r:
				TTGlSLMqrHIkpsOQPjyNCW0xU6 = h3BRGsU1yL[qeVZY0a5zp]
				wc1BZOYyvQH2f.IvgGEhRUjtAKwpTlbferO8aYHuBsd(qeVZY0a5zp,ZDNzeFMqkLrpd50mvHQAhX,TTGlSLMqrHIkpsOQPjyNCW0xU6,*aargs)
			lQMuw1PvVpAk.sleep(X60YQOADpkHBb31LiR5qUEKfM(u"࠴࠳࠽࠵ᐝ"))
			qeVZY0a5zp += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+t4txivgXSUWBOlCakQmNDjf(u"࠭ࠠࠡࠢࡗࡶࡾ࡯࡮ࡨ࠼ࠣࠤࠥࡖࡲࡰࡺࡼ࠾ࠥࡡࠠࠨ๽")+TTGlSLMqrHIkpsOQPjyNCW0xU6+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࠡ࡟ࠪ๾"))
		finishedLIST = wc1BZOYyvQH2f.finishedLIST
		if finishedLIST:
			resultsDICT = wc1BZOYyvQH2f.resultsDICT
			D4cYXdG5JpwrUH = finishedLIST[f4fTutDOEwUeIoPLRQ]
			cA6C7PMTuUklQdfoYqZgXj2FrJN = resultsDICT[D4cYXdG5JpwrUH]
			TTGlSLMqrHIkpsOQPjyNCW0xU6 = h3BRGsU1yL[int(D4cYXdG5JpwrUH)]
			llnG7jiQBYKhAeovbT.setSetting(flDSRbv57PnV3(u"ࠨࡣࡹ࠲ࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ๿"),TTGlSLMqrHIkpsOQPjyNCW0xU6)
			if D4cYXdG5JpwrUH!=f4fTutDOEwUeIoPLRQ: fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+DJ6ugPjW9bX8I(u"ࠩࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ຀")+TTGlSLMqrHIkpsOQPjyNCW0xU6+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࠤࡢ࠭ກ"))
			else: fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࠣࠤࡘࡧࡶࡦࡦࠣࡴࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭ຂ")+TTGlSLMqrHIkpsOQPjyNCW0xU6+DJ6ugPjW9bX8I(u"ࠬࠦ࡝ࠨ຃"))
	return cA6C7PMTuUklQdfoYqZgXj2FrJN
def JVFoSZKQlsGb2LBviX6HRaw(dmOKENZcVPJo6QBRFfk4j8,KdNWSOYLiu1zF4xwXblqpv8RsAm0gT):
	wX2Bm64Rx7h0fvui9yo = dmOKENZcVPJo6QBRFfk4j8.create_connection
	def SQPHwB321Ij(hhPJAT1BtkqdzGObF2v6W,*aargs,**kkwargs):
		KABa1T6Js3RHdXZ,RDshBrbxpgiT6 = hhPJAT1BtkqdzGObF2v6W
		ip = PNFTZx6gr4ycq(KABa1T6Js3RHdXZ,KdNWSOYLiu1zF4xwXblqpv8RsAm0gT)
		if ip: KABa1T6Js3RHdXZ = ip[f4fTutDOEwUeIoPLRQ]
		else:
			if KdNWSOYLiu1zF4xwXblqpv8RsAm0gT in jUy8IAthCYOu5k: jUy8IAthCYOu5k.remove(KdNWSOYLiu1zF4xwXblqpv8RsAm0gT)
			if jUy8IAthCYOu5k:
				lkN3VBgaHsnM90GYzFXmf = jUy8IAthCYOu5k[f4fTutDOEwUeIoPLRQ]
				ip = PNFTZx6gr4ycq(KABa1T6Js3RHdXZ,lkN3VBgaHsnM90GYzFXmf)
				if ip: KABa1T6Js3RHdXZ = ip[f4fTutDOEwUeIoPLRQ]
		hhPJAT1BtkqdzGObF2v6W = (KABa1T6Js3RHdXZ,RDshBrbxpgiT6)
		return wX2Bm64Rx7h0fvui9yo(hhPJAT1BtkqdzGObF2v6W,*aargs,**kkwargs)
	dmOKENZcVPJo6QBRFfk4j8.create_connection = SQPHwB321Ij
	return wX2Bm64Rx7h0fvui9yo
def nnRGlsTrB7IPkxe8c9SO(qxZiT6WJ7sX):
	zAM3lRLDm8xZQrFhpgytIWwKVY0j,urs1wNY0nB8CPIRlLQ = qxZiT6WJ7sX.split(flDSRbv57PnV3(u"࠭࠯ࠨຄ"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM],fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠽࠶ᐞ")
	if UpQ56M0dO1N9xIvVegy(u"ࠧ࠻ࠩ຅") in zAM3lRLDm8xZQrFhpgytIWwKVY0j: zAM3lRLDm8xZQrFhpgytIWwKVY0j,urs1wNY0nB8CPIRlLQ = zAM3lRLDm8xZQrFhpgytIWwKVY0j.split(fgv5U2eRVaQqSiuGD(u"ࠨ࠼ࠪຆ"))
	CymIkfN0vYui3KEhV8RUeFxrWA = DJ6ugPjW9bX8I(u"ࠩ࠲ࠫງ")+X60YQOADpkHBb31LiR5qUEKfM(u"ࠪ࠳ࠬຈ").join(qxZiT6WJ7sX.split(t4txivgXSUWBOlCakQmNDjf(u"ࠫ࠴࠭ຉ"))[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠹ᐟ"):])
	s0tfc7T2hwBM = QlTuvPbSpnjygBVW(u"ࠬࡍࡅࡕࠢࠪຊ")+CymIkfN0vYui3KEhV8RUeFxrWA+t4txivgXSUWBOlCakQmNDjf(u"࠭ࠠࡉࡖࡗࡔ࠴࠷࠮࠲࡞ࡵࡠࡳ࠭຋")
	s0tfc7T2hwBM += bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡉࡱࡶࡸ࠿ࠦࠧຌ")+zAM3lRLDm8xZQrFhpgytIWwKVY0j+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨ࡞ࡵࡠࡳ࠭ຍ")
	s0tfc7T2hwBM += usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩ࡟ࡶࡡࡴࠧຎ")
	from socket import socket as Ri19pkguZIof,AF_INET as zz0F47pPVUEIJfXMW89TZt,SOCK_STREAM as gm84czK096aZsVJYw5PqrbFku32
	try:
		PD9FRf0qHG2gL = Ri19pkguZIof(zz0F47pPVUEIJfXMW89TZt,gm84czK096aZsVJYw5PqrbFku32)
		PD9FRf0qHG2gL.connect((zAM3lRLDm8xZQrFhpgytIWwKVY0j,urs1wNY0nB8CPIRlLQ))
		PD9FRf0qHG2gL.send(s0tfc7T2hwBM.encode(zSafwK0sDXdMN5JReniIQmrZxp))
		bbSVeCHuivKsW = PD9FRf0qHG2gL.recv(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠵࠲࠼࠺ᐡ")*SSvu1CZjTW7FcloNqD(u"࠱࠱࠴࠷ᐠ"))
		B69RXYW5vf8Jt7O = repr(bbSVeCHuivKsW)
	except: B69RXYW5vf8Jt7O = nbOFVEDkpT4BIR7Qq82yPmHeJU
	return B69RXYW5vf8Jt7O
def Qi32bRtN18qvyWmaO7YKow9cXs(FM9sSUchwEWNXLCb85iY1dD,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG):
	if bYyKEjIuGQzoq3AR1(u"ࠪ࠲ࠬຏ") not in FM9sSUchwEWNXLCb85iY1dD: return FM9sSUchwEWNXLCb85iY1dD
	FM9sSUchwEWNXLCb85iY1dD = FM9sSUchwEWNXLCb85iY1dD+QlTuvPbSpnjygBVW(u"ࠫ࠴࠭ຐ")
	EfQi6MbzPeNjTO34aDSH,IETRLAGwB0MyiesFf1thJrolgz = FM9sSUchwEWNXLCb85iY1dD.split(X60YQOADpkHBb31LiR5qUEKfM(u"ࠬ࠴ࠧຑ"),SSvu1CZjTW7FcloNqD(u"࠳ᐢ"))
	cESPabtyMqh0LmD4CV716O2Hzoj3k,QLUw6PDvTzAxVadJl = IETRLAGwB0MyiesFf1thJrolgz.split(QlTuvPbSpnjygBVW(u"࠭࠯ࠨຒ"),bnI4kmPtrW7yFEhljXOCq9(u"࠴ᐣ"))
	CnHvq10LoBk7mUReK2bZ3cjl8 = EfQi6MbzPeNjTO34aDSH+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࠯ࠩຓ")+cESPabtyMqh0LmD4CV716O2Hzoj3k
	if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG in [YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡪࡲࡷࡹ࠭ດ"),DJ6ugPjW9bX8I(u"ࠩࡱࡥࡲ࡫ࠧຕ")] and z3sIGH8jmLYg(u"ࠪ࠳ࠬຖ") in CnHvq10LoBk7mUReK2bZ3cjl8: CnHvq10LoBk7mUReK2bZ3cjl8 = CnHvq10LoBk7mUReK2bZ3cjl8.rsplit(qrjy8LuKVPNYdbSvzh(u"ࠫ࠴࠭ທ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠵ᐤ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==DJ6ugPjW9bX8I(u"ࠬࡴࡡ࡮ࡧࠪຘ") and bnI4kmPtrW7yFEhljXOCq9(u"࠭࠮ࠨນ") in CnHvq10LoBk7mUReK2bZ3cjl8:
		bBUl0LMugdK6ykWT8jt = CnHvq10LoBk7mUReK2bZ3cjl8.split(flDSRbv57PnV3(u"ࠧ࠯ࠩບ"))
		vfRKCxijUVd3zZSLHe4 = len(bBUl0LMugdK6ykWT8jt)
		if DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ປ") in CnHvq10LoBk7mUReK2bZ3cjl8: bBUl0LMugdK6ykWT8jt = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧຜ")
		elif vfRKCxijUVd3zZSLHe4<=QQSugEIn2mTCpRsfcaJHhPdAWzylM: bBUl0LMugdK6ykWT8jt = bBUl0LMugdK6ykWT8jt[f4fTutDOEwUeIoPLRQ]
		elif vfRKCxijUVd3zZSLHe4>=ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb: bBUl0LMugdK6ykWT8jt = bBUl0LMugdK6ykWT8jt[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		if len(bBUl0LMugdK6ykWT8jt)>vkIa3ijEQVsJGdWOXwK7bnue9ADR: CnHvq10LoBk7mUReK2bZ3cjl8 = bBUl0LMugdK6ykWT8jt
	return CnHvq10LoBk7mUReK2bZ3cjl8
def YUSRdPDwbvE02uZ17oyH4jszLkgV9(jmS4TUpYEiL0lVqHu75f3):
	TIzpmeGDYf = repr(jmS4TUpYEiL0lVqHu75f3.encode(zSafwK0sDXdMN5JReniIQmrZxp)).replace(qrjy8LuKVPNYdbSvzh(u"ࠥࠫࠧຝ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return TIzpmeGDYf
def ufPy6eA5zURb7lGLK10hc(hhW7kFlLNAUmXeS5x):
	K8lwkaFyhjpdcGtOMDPUVEHZ = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if n7neb9KTv10FcU: hhW7kFlLNAUmXeS5x = hhW7kFlLNAUmXeS5x.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	from unicodedata import decomposition as FlcoB76G0mU3b1x
	for ZAfjea6wWBE in hhW7kFlLNAUmXeS5x:
		if   ZAfjea6wWBE==UpQ56M0dO1N9xIvVegy(u"ࡹࠬศࠧພ"): tkD6BCMayr3YKVvnGsTdU4 = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡢ࡜ࡶ࠲࠹࠶࠷࠭ຟ")
		elif ZAfjea6wWBE==fgv5U2eRVaQqSiuGD(u"ࡻࠧฤࠩຠ"): tkD6BCMayr3YKVvnGsTdU4 = z3sIGH8jmLYg(u"ࠧ࡝࡞ࡸ࠴࠻࠸࠳ࠨມ")
		elif ZAfjea6wWBE==IINBvuxkCSJrO1Q0UyngdLi(u"ࡶࠩวࠫຢ"): tkD6BCMayr3YKVvnGsTdU4 = X1mRwt2YJKgCLu9a67(u"ࠩ࡟ࡠࡺ࠶࠶࠳࠶ࠪຣ")
		elif ZAfjea6wWBE==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࡸࠫส࠭຤"): tkD6BCMayr3YKVvnGsTdU4 = UpQ56M0dO1N9xIvVegy(u"ࠫࡡࡢࡵ࠱࠸࠵࠹ࠬລ")
		elif ZAfjea6wWBE==I3cxjYaHhsrM7T4UX26klN(u"ࡺ࠭ฦࠨ຦"): tkD6BCMayr3YKVvnGsTdU4 = t4txivgXSUWBOlCakQmNDjf(u"࠭࡜࡝ࡷ࠳࠺࠷࠼ࠧວ")
		else:
			bYtpuqjd69eRSDVWxscXo0Cmz = FlcoB76G0mU3b1x(ZAfjea6wWBE)
			if S3X6GcaiExOPtb in bYtpuqjd69eRSDVWxscXo0Cmz: tkD6BCMayr3YKVvnGsTdU4 = l4DS8mnEjHhFMZ5YOe(u"ࠧ࡝࡞ࡸࠫຨ")+bYtpuqjd69eRSDVWxscXo0Cmz.split(S3X6GcaiExOPtb,vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			else:
				tkD6BCMayr3YKVvnGsTdU4 = bnI4kmPtrW7yFEhljXOCq9(u"ࠨ࠲࠳࠴࠵࠭ຩ")+hex(ord(ZAfjea6wWBE)).replace(fgv5U2eRVaQqSiuGD(u"ࠩ࠳ࡼࠬສ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				tkD6BCMayr3YKVvnGsTdU4 = qrjy8LuKVPNYdbSvzh(u"ࠪࡠࡡࡻࠧຫ")+tkD6BCMayr3YKVvnGsTdU4[-WtDrnpJmwQ37Z2Ae68hu4BY5M1:]
		K8lwkaFyhjpdcGtOMDPUVEHZ += tkD6BCMayr3YKVvnGsTdU4
	K8lwkaFyhjpdcGtOMDPUVEHZ = K8lwkaFyhjpdcGtOMDPUVEHZ.replace(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࡡࡢࡵ࠱࠸ࡆࡇࠬຬ"),qrjy8LuKVPNYdbSvzh(u"ࠬࡢ࡜ࡶ࠲࠹࠸࠾࠭ອ"))
	if n7neb9KTv10FcU: K8lwkaFyhjpdcGtOMDPUVEHZ = K8lwkaFyhjpdcGtOMDPUVEHZ.decode(QlTuvPbSpnjygBVW(u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧຮ")).encode(zSafwK0sDXdMN5JReniIQmrZxp)
	else: K8lwkaFyhjpdcGtOMDPUVEHZ = K8lwkaFyhjpdcGtOMDPUVEHZ.encode(zSafwK0sDXdMN5JReniIQmrZxp).decode(SSvu1CZjTW7FcloNqD(u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨຯ"))
	return K8lwkaFyhjpdcGtOMDPUVEHZ
def dR75Vq2gprfHmUcNhG(header=flDSRbv57PnV3(u"ࠨๆ๋ัฮࠦวๅ็ไหฯ๐อࠨະ"),hWXyS52dYN8u=nbOFVEDkpT4BIR7Qq82yPmHeJU,N4C0JTsUQauqBF7ILrig5Gw=SmbNGskjMx,source=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	om2lqtcZ5y4j = XdJg5QtsHAmrFUh26c9Opf1BI(header,hWXyS52dYN8u,type=LAkCFq8ezcf.INPUT_ALPHANUM)
	om2lqtcZ5y4j = om2lqtcZ5y4j.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	if not om2lqtcZ5y4j and not N4C0JTsUQauqBF7ILrig5Gw:
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,X1mRwt2YJKgCLu9a67(u"ࠩ࠱ࡠࡹࡑࡥࡺࡤࡲࡥࡷࡪࠠࡦࡰࡷࡶࡾࠦࡣࡢࡰࡦࡩࡱ࡫ࡤ࠻ࠢࠣࠤࠧ࠭ັ")+om2lqtcZ5y4j+fgv5U2eRVaQqSiuGD(u"ࠪࠦࠬາ"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧຳ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬะๅࠡว็฾ฬวࠠศๆศำำอไࠨິ"))
		return nbOFVEDkpT4BIR7Qq82yPmHeJU
	if om2lqtcZ5y4j not in [nbOFVEDkpT4BIR7Qq82yPmHeJU,S3X6GcaiExOPtb]:
		om2lqtcZ5y4j = om2lqtcZ5y4j.strip(S3X6GcaiExOPtb)
		om2lqtcZ5y4j = ufPy6eA5zURb7lGLK10hc(om2lqtcZ5y4j)
	if source!=flDSRbv57PnV3(u"࠭ࡓࡆࡔ࡙ࡍࡈࡋࡓࠨີ") and hVa7QF14igDIG820eXfd(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡌࡇ࡜ࡆࡔࡇࡒࡅࠩຶ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,[om2lqtcZ5y4j],SmbNGskjMx):
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨ࠰࡟ࡸࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡥ࡯ࡶࡵࡽࠥࡨ࡬ࡰࡥ࡮ࡩࡩࡀࠠࠡࠢࠥࠫື")+om2lqtcZ5y4j+IINBvuxkCSJrO1Q0UyngdLi(u"ຸࠩࠥࠫ"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ัູ࠭"),SSvu1CZjTW7FcloNqD(u"ࠫฬ์สࠡๅอฬฯࠦใๅ็ฬࠤศ๎ࠠาไ่ࠤ้ํฺࠠๆสๆฮࠦศฤใ็ห๊ࠦไๅๅหหึࠦแใูࠣ࠲࠳่่ࠦาสࠤฬ๊ศา่ส้ัࠦไศࠢํื๊ำࠠษษึฮำีวๆ๊ࠢ็ีอࠠไๆ่หฯ຺࠭"))
		return nbOFVEDkpT4BIR7Qq82yPmHeJU
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬ࠴࡜ࡵࡍࡨࡽࡧࡵࡡࡳࡦࠣࡩࡳࡺࡲࡺࠢࡤࡰࡱࡵࡷࡦࡦ࠽ࠤࠥࠦࠢࠨົ")+om2lqtcZ5y4j+q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࠢࠨຼ"))
	return om2lqtcZ5y4j
def mmAWFnZUkQ3HowdxRtCN9(plSscrVjkRviPwm,GcYwHSWoQ0Nq8KFfJDdvujZryM={}):
	qxZiT6WJ7sX,tN7afmDoVeSJOy6,I6czP5lQ0kxNrXwfdmVZyB8ED,pf3XnhlNqBc = plSscrVjkRviPwm,{},{},nbOFVEDkpT4BIR7Qq82yPmHeJU
	if YayJj10OGl(u"ࠧࡽࠩຽ") in plSscrVjkRviPwm: qxZiT6WJ7sX,tN7afmDoVeSJOy6 = kJPjYVSCDE2(plSscrVjkRviPwm,tM24jD1gO0(u"ࠨࡾࠪ຾"))
	MQa4xN1Aq6JYCWSk = list(set(list(GcYwHSWoQ0Nq8KFfJDdvujZryM.keys())+list(tN7afmDoVeSJOy6.keys())))
	for SRoElDIz1e9Vu in MQa4xN1Aq6JYCWSk:
		if SRoElDIz1e9Vu in list(tN7afmDoVeSJOy6.keys()): I6czP5lQ0kxNrXwfdmVZyB8ED[SRoElDIz1e9Vu] = tN7afmDoVeSJOy6[SRoElDIz1e9Vu]
		else: I6czP5lQ0kxNrXwfdmVZyB8ED[SRoElDIz1e9Vu] = GcYwHSWoQ0Nq8KFfJDdvujZryM[SRoElDIz1e9Vu]
	if IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭຿") not in MQa4xN1Aq6JYCWSk: I6czP5lQ0kxNrXwfdmVZyB8ED[I3cxjYaHhsrM7T4UX26klN(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧເ")] = MdwGcQOsmlV6vKI73THrUY4()
	if z3sIGH8jmLYg(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬແ") not in MQa4xN1Aq6JYCWSk: I6czP5lQ0kxNrXwfdmVZyB8ED[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ໂ")] = Qi32bRtN18qvyWmaO7YKow9cXs(qxZiT6WJ7sX,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡵࡳ࡮ࠪໃ"))
	if X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩໄ") not in MQa4xN1Aq6JYCWSk: I6czP5lQ0kxNrXwfdmVZyB8ED[l4DS8mnEjHhFMZ5YOe(u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ໅")] = ulAxHwvzR9eTb5n(u"ࠩࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠻ࠪໆ")
	for SRoElDIz1e9Vu in list(I6czP5lQ0kxNrXwfdmVZyB8ED.keys()): pf3XnhlNqBc += usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࠪࠬ໇")+SRoElDIz1e9Vu+l4DS8mnEjHhFMZ5YOe(u"ࠫࡂ່࠭")+I6czP5lQ0kxNrXwfdmVZyB8ED[SRoElDIz1e9Vu]
	if pf3XnhlNqBc: pf3XnhlNqBc = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࢂ້ࠧ")+pf3XnhlNqBc[vkIa3ijEQVsJGdWOXwK7bnue9ADR:]
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡇࡆࡖ໊ࠪ"),qxZiT6WJ7sX,nbOFVEDkpT4BIR7Qq82yPmHeJU,I6czP5lQ0kxNrXwfdmVZyB8ED,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡇ࡛ࡘࡗࡇࡃࡕࡡࡐ࠷࡚࠾࠭࠲ࡵࡷ໋ࠫ"),SmbNGskjMx,SmbNGskjMx)
	B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
	if flDSRbv57PnV3(u"ࠨࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊࠬ໌") not in B69RXYW5vf8Jt7O: return [bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩ࠰࠵ࠬໍ")],[qxZiT6WJ7sX+pf3XnhlNqBc]
	if Fo1SgXMsHk(u"ࠪࡘ࡞ࡖࡅ࠾ࡃࡘࡈࡎࡕࠧ໎") in B69RXYW5vf8Jt7O: return [SSvu1CZjTW7FcloNqD(u"ࠫ࠲࠷ࠧ໏")],[qxZiT6WJ7sX+pf3XnhlNqBc]
	if YayJj10OGl(u"࡚࡙ࠬࡑࡇࡀ࡚ࡎࡊࡅࡐࠩ໐") in B69RXYW5vf8Jt7O: return [ulAxHwvzR9eTb5n(u"࠭࠭࠲ࠩ໑")],[qxZiT6WJ7sX+pf3XnhlNqBc]
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,ggT2N9PZhtlcy,nhNoWS1ycY8bqHtl = [],[],[],[]
	FV968pLETkDJwxhXlye2O5ScH = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠧࠤࡇ࡛ࡘ࠲࡞࠭ࡔࡖࡕࡉࡆࡓ࠭ࡊࡐࡉ࠾࠭࠴ࠪࡀࠫ࡞ࡠࡷࡢ࡮࡞࠭ࠫ࠲࠯ࡅࠩ࡜࡞ࡵࡠࡳࡣࠫࠨ໒"),B69RXYW5vf8Jt7O+wwOnIucWJj,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not FV968pLETkDJwxhXlye2O5ScH: return [cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࠯࠴ࠫ໓")],[qxZiT6WJ7sX+pf3XnhlNqBc]
	for nnOtpcqvi6mCdL5QGgbhwkX9A1Y,FM9sSUchwEWNXLCb85iY1dD in FV968pLETkDJwxhXlye2O5ScH:
		U0zxGmJgb4TKLfAu5qe89Q,twyo6bl7DKGL,uTKGhcXEIpmDf = {},-tM24jD1gO0(u"࠶ᐥ"),-tM24jD1gO0(u"࠶ᐥ")
		YK3SfeJ2xq6d8jEbo = nbOFVEDkpT4BIR7Qq82yPmHeJU
		biSsqlWmZCrBfKAn4NkxHL = nnOtpcqvi6mCdL5QGgbhwkX9A1Y.split(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩ࠯ࠫ໔"))
		for EEZcU5jVnCeFk in biSsqlWmZCrBfKAn4NkxHL:
			if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡁࠬ໕") in EEZcU5jVnCeFk:
				SRoElDIz1e9Vu,NiQr7d3XtqRVzaOsxjPJM = EEZcU5jVnCeFk.split(t4txivgXSUWBOlCakQmNDjf(u"ࠫࡂ࠭໖"),QlTuvPbSpnjygBVW(u"࠷ᐦ"))
				U0zxGmJgb4TKLfAu5qe89Q[SRoElDIz1e9Vu.lower()] = NiQr7d3XtqRVzaOsxjPJM
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪ࠳ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ໗") in nnOtpcqvi6mCdL5QGgbhwkX9A1Y.lower():
			twyo6bl7DKGL = int(U0zxGmJgb4TKLfAu5qe89Q[cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡡࡷࡧࡵࡥ࡬࡫࠭ࡣࡣࡱࡨࡼ࡯ࡤࡵࡪࠪ໘")])//usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠱࠱࠴࠷ᐧ")
			YK3SfeJ2xq6d8jEbo += str(twyo6bl7DKGL)+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ໙")
		elif X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ໚") in nnOtpcqvi6mCdL5QGgbhwkX9A1Y.lower():
			twyo6bl7DKGL = int(U0zxGmJgb4TKLfAu5qe89Q[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ໛")])//bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠲࠲࠵࠸ᐨ")
			YK3SfeJ2xq6d8jEbo += str(twyo6bl7DKGL)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪໜ")
		if paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨໝ") in nnOtpcqvi6mCdL5QGgbhwkX9A1Y.lower():
			uTKGhcXEIpmDf = int(U0zxGmJgb4TKLfAu5qe89Q[QlTuvPbSpnjygBVW(u"ࠬࡸࡥࡴࡱ࡯ࡹࡹ࡯࡯࡯ࠩໞ")].split(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡸࠨໟ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
			YK3SfeJ2xq6d8jEbo += str(uTKGhcXEIpmDf)+BhmzEC6OGD7FXZig9Tp5A
		YK3SfeJ2xq6d8jEbo = YK3SfeJ2xq6d8jEbo.strip(BhmzEC6OGD7FXZig9Tp5A)
		if not YK3SfeJ2xq6d8jEbo: YK3SfeJ2xq6d8jEbo = t4txivgXSUWBOlCakQmNDjf(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ໠")
		if not FM9sSUchwEWNXLCb85iY1dD.startswith(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡪࡷࡸࡵ࠭໡")):
			if FM9sSUchwEWNXLCb85iY1dD.startswith(Fo1SgXMsHk(u"ࠩ࠲࠳ࠬ໢")): FM9sSUchwEWNXLCb85iY1dD = qxZiT6WJ7sX.split(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪ࠾ࠬ໣"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࠿࠭໤")+FM9sSUchwEWNXLCb85iY1dD
			elif FM9sSUchwEWNXLCb85iY1dD.startswith(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬ࠵ࠧ໥")): FM9sSUchwEWNXLCb85iY1dD = Qi32bRtN18qvyWmaO7YKow9cXs(qxZiT6WJ7sX,q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡵࡳ࡮ࠪ໦"))+FM9sSUchwEWNXLCb85iY1dD
			else: FM9sSUchwEWNXLCb85iY1dD = qxZiT6WJ7sX.rsplit(bYyKEjIuGQzoq3AR1(u"ࠧ࠰ࠩ໧"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]+tM24jD1gO0(u"ࠨ࠱ࠪ໨")+FM9sSUchwEWNXLCb85iY1dD
		if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡳࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫࠭ࡶࡴ࡬ࠫ໩") in list(U0zxGmJgb4TKLfAu5qe89Q.keys()):
			f7Je8XzEqNpgHL9m4OURdAQ1 = U0zxGmJgb4TKLfAu5qe89Q[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ໪")]
			f7Je8XzEqNpgHL9m4OURdAQ1 = f7Je8XzEqNpgHL9m4OURdAQ1.replace(ulAxHwvzR9eTb5n(u"ࠫࠧ࠭໫"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠭ࠢ໬"),nbOFVEDkpT4BIR7Qq82yPmHeJU).split(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࠣࠨ໭"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
			J8J0A4lx7y9GDEBq = JoEms64VZ1ldaf9NYBgcKCFL(f7Je8XzEqNpgHL9m4OURdAQ1)
			if J8J0A4lx7y9GDEBq: HDE69mkhQg2NaFpuUy5JRb = YK3SfeJ2xq6d8jEbo+BhmzEC6OGD7FXZig9Tp5A+J8J0A4lx7y9GDEBq
			else: HDE69mkhQg2NaFpuUy5JRb = YK3SfeJ2xq6d8jEbo
			HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࠡࠢࡓࡶࡴ࡭ࡲࡦࡵࡶ࡭ࡻ࡫ࠧ໮")
			HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb+BhmzEC6OGD7FXZig9Tp5A+Qi32bRtN18qvyWmaO7YKow9cXs(f7Je8XzEqNpgHL9m4OURdAQ1,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡰࡤࡱࡪ࠭໯"))
			bbKoeBcirVfzwAqZdQUFDSX.append(HDE69mkhQg2NaFpuUy5JRb)
			lPpY5fw3tOBcEye91Caun2FQZ.append(f7Je8XzEqNpgHL9m4OURdAQ1)
			ggT2N9PZhtlcy.append(uTKGhcXEIpmDf)
			nhNoWS1ycY8bqHtl.append(twyo6bl7DKGL)
		FM9sSUchwEWNXLCb85iY1dD = FM9sSUchwEWNXLCb85iY1dD.split(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࠦࠫ໰"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
		J8J0A4lx7y9GDEBq = JoEms64VZ1ldaf9NYBgcKCFL(FM9sSUchwEWNXLCb85iY1dD)
		if J8J0A4lx7y9GDEBq: YK3SfeJ2xq6d8jEbo = YK3SfeJ2xq6d8jEbo+BhmzEC6OGD7FXZig9Tp5A+J8J0A4lx7y9GDEBq
		YK3SfeJ2xq6d8jEbo = YK3SfeJ2xq6d8jEbo+BhmzEC6OGD7FXZig9Tp5A+Qi32bRtN18qvyWmaO7YKow9cXs(FM9sSUchwEWNXLCb85iY1dD,IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡲࡦࡳࡥࠨ໱"))
		bbKoeBcirVfzwAqZdQUFDSX.append(YK3SfeJ2xq6d8jEbo)
		lPpY5fw3tOBcEye91Caun2FQZ.append(FM9sSUchwEWNXLCb85iY1dD)
		ggT2N9PZhtlcy.append(uTKGhcXEIpmDf)
		nhNoWS1ycY8bqHtl.append(twyo6bl7DKGL)
	pgIxQdT5lkmt = list(zip(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,ggT2N9PZhtlcy,nhNoWS1ycY8bqHtl))
	pgIxQdT5lkmt = sorted(pgIxQdT5lkmt, reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4, key=lambda key: key[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb])
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,ggT2N9PZhtlcy,nhNoWS1ycY8bqHtl = list(zip(*pgIxQdT5lkmt))
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = list(bbKoeBcirVfzwAqZdQUFDSX),list(lPpY5fw3tOBcEye91Caun2FQZ)
	gCJprIs2wUzfcNhtxv = []
	for FM9sSUchwEWNXLCb85iY1dD in lPpY5fw3tOBcEye91Caun2FQZ: gCJprIs2wUzfcNhtxv.append(FM9sSUchwEWNXLCb85iY1dD+pf3XnhlNqBc)
	return bbKoeBcirVfzwAqZdQUFDSX,gCJprIs2wUzfcNhtxv
def PNFTZx6gr4ycq(KABa1T6Js3RHdXZ,KdNWSOYLiu1zF4xwXblqpv8RsAm0gT=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not KdNWSOYLiu1zF4xwXblqpv8RsAm0gT: KdNWSOYLiu1zF4xwXblqpv8RsAm0gT = jUy8IAthCYOu5k[f4fTutDOEwUeIoPLRQ]
	if KABa1T6Js3RHdXZ.replace(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࠳࠭໲"),nbOFVEDkpT4BIR7Qq82yPmHeJU).isdigit(): return [KABa1T6Js3RHdXZ]
	from struct import pack as K0fWw5vsMcRtzAobV24UymLGHaXQO,unpack_from as BftQuHceioEjz5GPpyOnDZMW
	from socket import socket as Ri19pkguZIof,AF_INET as zz0F47pPVUEIJfXMW89TZt,SOCK_DGRAM as EMyrzIFSatfucKnqxWhC4
	try:
		O1OzsCZvgVtJ = K0fWw5vsMcRtzAobV24UymLGHaXQO(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡄࡈࠣ໳"), DJ6ugPjW9bX8I(u"࠳࠵࠴࠹࠿ᐩ"))
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(ulAxHwvzR9eTb5n(u"ࠨ࠾ࡉࠤ໴"), X60YQOADpkHBb31LiR5qUEKfM(u"࠵࠹࠻ᐪ"))
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(X1mRwt2YJKgCLu9a67(u"ࠢ࠿ࡊࠥ໵"), vkIa3ijEQVsJGdWOXwK7bnue9ADR)
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠣࡀࡋࠦ໶"), f4fTutDOEwUeIoPLRQ)
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(l4DS8mnEjHhFMZ5YOe(u"ࠤࡁࡌࠧ໷"), f4fTutDOEwUeIoPLRQ)
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(SSvu1CZjTW7FcloNqD(u"ࠥࡂࡍࠨ໸"), f4fTutDOEwUeIoPLRQ)
		if IZhXMprxvAHqBEFkg0: h5hylaWLfGOemI9RgXQn2V4S7 = KABa1T6Js3RHdXZ.split(bYyKEjIuGQzoq3AR1(u"ࠫ࠳࠭໹"))
		else: h5hylaWLfGOemI9RgXQn2V4S7 = KABa1T6Js3RHdXZ.decode(zSafwK0sDXdMN5JReniIQmrZxp).split(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬ࠴ࠧ໺"))
		for zLuKOUqpVFdsgx4AhXklwH3Jc in h5hylaWLfGOemI9RgXQn2V4S7:
			tthOzV7absYioHcFMRCUwSJGArl = zLuKOUqpVFdsgx4AhXklwH3Jc.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡂࠣ໻"), len(zLuKOUqpVFdsgx4AhXklwH3Jc))
			for wWizVbMhfgr95ZJHDXdtQY in zLuKOUqpVFdsgx4AhXklwH3Jc:
				O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(UpQ56M0dO1N9xIvVegy(u"ࠢࡤࠤ໼"), wWizVbMhfgr95ZJHDXdtQY.encode(zSafwK0sDXdMN5JReniIQmrZxp))
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(Fo1SgXMsHk(u"ࠣࡄࠥ໽"), f4fTutDOEwUeIoPLRQ)
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠤࡁࡌࠧ໾"), vkIa3ijEQVsJGdWOXwK7bnue9ADR)
		O1OzsCZvgVtJ += K0fWw5vsMcRtzAobV24UymLGHaXQO(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠥࡂࡍࠨ໿"), vkIa3ijEQVsJGdWOXwK7bnue9ADR)
		hjDxswy60VORq = Ri19pkguZIof(zz0F47pPVUEIJfXMW89TZt,EMyrzIFSatfucKnqxWhC4)
		hjDxswy60VORq.sendto(bytes(O1OzsCZvgVtJ), (KdNWSOYLiu1zF4xwXblqpv8RsAm0gT, bYyKEjIuGQzoq3AR1(u"࠹࠸ᐫ")))
		hjDxswy60VORq.settimeout(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠻ᐬ"))
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC, lZr6Njk2KQEBtmbGY4wqRUh = hjDxswy60VORq.recvfrom(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠷࠰࠳࠶ᐭ"))
		hjDxswy60VORq.close()
		rvGk5JylR37IxFjEQWtw2CMg = BftQuHceioEjz5GPpyOnDZMW(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠦࡃࡎࡈࡉࡊࡋࡌࠧༀ"), qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC, f4fTutDOEwUeIoPLRQ)
		M3ThKkHuzeCD4cwvXOpysfPLSaAlR = rvGk5JylR37IxFjEQWtw2CMg[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
		tzUFrBSp98JvVdxys3mRPHNOhq = len(KABa1T6Js3RHdXZ)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠱࠹ᐮ")
		qbF0StY2asIVE1yWxNn4KUQB9dD = []
		for _JjCcvo1lhg0K5wnMDBqbEAmNiH4Ur in range(M3ThKkHuzeCD4cwvXOpysfPLSaAlR):
			vrIxlTg7ueCAzyBb = tzUFrBSp98JvVdxys3mRPHNOhq
			YYM7Kl8OgxbaDRq = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			srpMux1S4wbPZ = SmbNGskjMx
			while Ag9l6cw3EBqP8HsQuGMizfOtr4:
				wWizVbMhfgr95ZJHDXdtQY = BftQuHceioEjz5GPpyOnDZMW(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡄࡂࠣ༁"), qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC, vrIxlTg7ueCAzyBb)[f4fTutDOEwUeIoPLRQ]
				if wWizVbMhfgr95ZJHDXdtQY == f4fTutDOEwUeIoPLRQ:
					vrIxlTg7ueCAzyBb += vkIa3ijEQVsJGdWOXwK7bnue9ADR
					break
				if wWizVbMhfgr95ZJHDXdtQY >= CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠲࠻࠵ᐯ"):
					CSKEHpgA6G = BftQuHceioEjz5GPpyOnDZMW(YayJj10OGl(u"ࠨ࠾ࡃࠤ༂"), qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC, vrIxlTg7ueCAzyBb + vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
					vrIxlTg7ueCAzyBb = ((wWizVbMhfgr95ZJHDXdtQY << q4izXt0sjIQSZcHVAf3EmKRbx(u"࠺ᐰ")) + CSKEHpgA6G - 0xc000) - vkIa3ijEQVsJGdWOXwK7bnue9ADR
					srpMux1S4wbPZ = Ag9l6cw3EBqP8HsQuGMizfOtr4
				vrIxlTg7ueCAzyBb += vkIa3ijEQVsJGdWOXwK7bnue9ADR
				if srpMux1S4wbPZ == SmbNGskjMx: YYM7Kl8OgxbaDRq += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			if srpMux1S4wbPZ == Ag9l6cw3EBqP8HsQuGMizfOtr4: YYM7Kl8OgxbaDRq += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			tzUFrBSp98JvVdxys3mRPHNOhq = tzUFrBSp98JvVdxys3mRPHNOhq + YYM7Kl8OgxbaDRq
			q4WyHcoCr260nlYZEFzG = BftQuHceioEjz5GPpyOnDZMW(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠢ࠿ࡊࡋࡍࡍࠨ༃"), qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC, tzUFrBSp98JvVdxys3mRPHNOhq)
			tzUFrBSp98JvVdxys3mRPHNOhq = tzUFrBSp98JvVdxys3mRPHNOhq + bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠴࠴ᐱ")
			ZZUk2n8NmPzOIeM0oD3 = q4WyHcoCr260nlYZEFzG[f4fTutDOEwUeIoPLRQ]
			v6O8KQnBh5 = q4WyHcoCr260nlYZEFzG[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
			if ZZUk2n8NmPzOIeM0oD3 == vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				PHM3vmsO4jcRBIwr25YALp = BftQuHceioEjz5GPpyOnDZMW(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠣࡀࠥ༄")+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠤࡅࠦ༅")*v6O8KQnBh5, qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC, tzUFrBSp98JvVdxys3mRPHNOhq)
				ip = nbOFVEDkpT4BIR7Qq82yPmHeJU
				for wWizVbMhfgr95ZJHDXdtQY in PHM3vmsO4jcRBIwr25YALp: ip += str(wWizVbMhfgr95ZJHDXdtQY) + bYyKEjIuGQzoq3AR1(u"ࠪ࠲ࠬ༆")
				ip = ip[f4fTutDOEwUeIoPLRQ:-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
				qbF0StY2asIVE1yWxNn4KUQB9dD.append(ip)
			if ZZUk2n8NmPzOIeM0oD3 in [vkIa3ijEQVsJGdWOXwK7bnue9ADR,QQSugEIn2mTCpRsfcaJHhPdAWzylM,I3cxjYaHhsrM7T4UX26klN(u"࠻ᐴ"),tM24jD1gO0(u"࠶ᐵ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠶࠻ᐳ"),t4txivgXSUWBOlCakQmNDjf(u"࠶࠽ᐲ")]: tzUFrBSp98JvVdxys3mRPHNOhq = tzUFrBSp98JvVdxys3mRPHNOhq + v6O8KQnBh5
	except: qbF0StY2asIVE1yWxNn4KUQB9dD = []
	if not qbF0StY2asIVE1yWxNn4KUQB9dD: fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡊࡲࡷࡹࡀࠠ࡜ࠢࠪ༇")+KABa1T6Js3RHdXZ+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࠦ࡝ࠨ༈"))
	return qbF0StY2asIVE1yWxNn4KUQB9dD
def hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,qxZiT6WJ7sX,DozYPsfmHBxWh,showDialogs=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	if DozYPsfmHBxWh:
		TZqkMGVsy5KuCtonxfz = [IINBvuxkCSJrO1Q0UyngdLi(u"࠭ใษษิࠫ༉"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧษษ็฾ࠬ༊"),z3sIGH8jmLYg(u"ࠨࡣࡧࡹࡱࡺࠧ་"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡻࡼࠬ༌"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡷࡪࡾࠧ།")]
		if QSJFrwB3dMiyH2mTPKD9a!=I3cxjYaHhsrM7T4UX26klN(u"ࠫࡇࡕࡋࡓࡃࠪ༎"):
			TZqkMGVsy5KuCtonxfz += [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡸ࠺ࠨ༏"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡲ࠮ࠩ༐"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧ࠮࡯ࡤࠫ༑")]
			TZqkMGVsy5KuCtonxfz += [YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ࠼ࡵࠫ༒"),z3sIGH8jmLYg(u"ࠩ࠰ࡶࠬ༓"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡱࡦ࠳ࠧ༔")]
		for kJGUEqeVaRPID in DozYPsfmHBxWh:
			if bnI4kmPtrW7yFEhljXOCq9(u"ࠫ࡬࡫ࡴ࠯ࡲ࡫ࡴࡄ࠭༕") in kJGUEqeVaRPID: continue
			if bnI4kmPtrW7yFEhljXOCq9(u"ࠬำไใหࠪ༖") in kJGUEqeVaRPID: continue
			kJGUEqeVaRPID = kJGUEqeVaRPID.lower()
			if n7neb9KTv10FcU: kJGUEqeVaRPID = kJGUEqeVaRPID.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode(zSafwK0sDXdMN5JReniIQmrZxp)
			kJGUEqeVaRPID = kJGUEqeVaRPID.replace(bnI4kmPtrW7yFEhljXOCq9(u"࠭࠺ࠨ༗"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			eTPXbIWCDx9Q = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࠩ࠳࡞࠹࠲࠿࡝ࠬࡾ࠵࡟࠵࠳࠳࡞༘࠭ࠬࠫ"),kJGUEqeVaRPID,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			wvh8K4sDCPFcjmASdqYzkQR03GBx = SmbNGskjMx
			for Q1ytZwjo7a in eTPXbIWCDx9Q:
				if len(Q1ytZwjo7a)==QQSugEIn2mTCpRsfcaJHhPdAWzylM:
					wvh8K4sDCPFcjmASdqYzkQR03GBx = Ag9l6cw3EBqP8HsQuGMizfOtr4
					break
			if bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡰࡲࡸࠥࡸࡡࡵࡧࡧ༙ࠫ") in kJGUEqeVaRPID: continue
			elif paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡸࡲࡷࡧࡴࡦࡦࠪ༚") in kJGUEqeVaRPID: continue
			elif CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪ฾๏ืࠠๆื้ๅࠬ༛") in kJGUEqeVaRPID: continue
			elif Bi6UGMYAPubKoXJge23fIw59vqR8d([YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡇ࡚ࡅࡹࡒ࡙࠵࠾࡙ࡒࡗࡐࡘ࡙ࡱ࡜ࡄࡗࡇ࡙ࡉ࡝࠭༜")])[f4fTutDOEwUeIoPLRQ]: continue
			elif kJGUEqeVaRPID in [X1mRwt2YJKgCLu9a67(u"ࠬࡸࠧ༝")] or wvh8K4sDCPFcjmASdqYzkQR03GBx or any(XPL0O2VkI3w1C8enMaqi in kJGUEqeVaRPID for XPL0O2VkI3w1C8enMaqi in TZqkMGVsy5KuCtonxfz):
				fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+fgv5U2eRVaQqSiuGD(u"࠭ࠠࠡࠢࡅࡰࡴࡩ࡫ࡦࡦࠣࡥࡩࡻ࡬ࡵࡵࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ༞")+qxZiT6WJ7sX+flDSRbv57PnV3(u"ࠧࠡ࡟ࠪ༟"))
				if showDialogs: SSVCGE0bOfW1w9u52yvBxocNeP(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ༠"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠩส่ๆ๐ฯ๋๊่้้ࠣศศำࠣๅ็฽้ࠠล้ห๋ࠥๆฺฬ๊ࠫ༡"))
				return Ag9l6cw3EBqP8HsQuGMizfOtr4
	return SmbNGskjMx
def aY7RFmnWc5uU9T3Q0Mxq4(*aargs,**kkwargs):
	if aargs:
		direction = aargs[f4fTutDOEwUeIoPLRQ]
		K3K08FEm6r7SetNJB1cW = aargs[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		if not direction: direction = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡧࡪࡴࡴࡦࡴࠪ༢")
		if not K3K08FEm6r7SetNJB1cW: K3K08FEm6r7SetNJB1cW = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫฬูสๆำสีࠬ༣")
		uFvPQ6sYzyaq03f5riTIpcO = aargs[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		om2lqtcZ5y4j = wwOnIucWJj.join(aargs[Fo1SgXMsHk(u"࠴ᐶ"):])
	else: direction,K3K08FEm6r7SetNJB1cW,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j = nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡕࡋࠨ༤"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	YuqCtbB0XfT6rGUwS5z79VDk3del2E(direction,nbOFVEDkpT4BIR7Qq82yPmHeJU,K3K08FEm6r7SetNJB1cW,nbOFVEDkpT4BIR7Qq82yPmHeJU,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,**kkwargs)
	return
def ttiZs4bKHFvugJj5z(*aargs,**kkwargs):
	direction = aargs[f4fTutDOEwUeIoPLRQ]
	HoySplx7r21E = aargs[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	bbmX0GtSLxgUCuFzQMdH = aargs[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
	if bbmX0GtSLxgUCuFzQMdH or HoySplx7r21E: rLQYegJSj9yz = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else: rLQYegJSj9yz = SmbNGskjMx
	uFvPQ6sYzyaq03f5riTIpcO = aargs[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
	om2lqtcZ5y4j = aargs[WtDrnpJmwQ37Z2Ae68hu4BY5M1]
	if not direction: direction = bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༥")
	if not HoySplx7r21E: HoySplx7r21E = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧไๆสࠤࠥࡔ࡯ࠨ༦")
	if not bbmX0GtSLxgUCuFzQMdH: bbmX0GtSLxgUCuFzQMdH = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ่฼้࡙ࠥࠦࡦࡵࠪ༧")
	if len(aargs)>=flDSRbv57PnV3(u"࠹ᐸ"): om2lqtcZ5y4j += wwOnIucWJj+aargs[ulAxHwvzR9eTb5n(u"࠷ᐷ")]
	if len(aargs)>=l4DS8mnEjHhFMZ5YOe(u"࠻ᐹ"): om2lqtcZ5y4j += wwOnIucWJj+aargs[xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠻ᐺ")]
	K4O6aMFQSLIbWxtGpPy2gZDB5q = YuqCtbB0XfT6rGUwS5z79VDk3del2E(direction,HoySplx7r21E,nbOFVEDkpT4BIR7Qq82yPmHeJU,bbmX0GtSLxgUCuFzQMdH,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,**kkwargs)
	if K4O6aMFQSLIbWxtGpPy2gZDB5q==-z3sIGH8jmLYg(u"࠷ᐻ") and rLQYegJSj9yz: K4O6aMFQSLIbWxtGpPy2gZDB5q = -vkIa3ijEQVsJGdWOXwK7bnue9ADR
	elif K4O6aMFQSLIbWxtGpPy2gZDB5q==-vkIa3ijEQVsJGdWOXwK7bnue9ADR and not rLQYegJSj9yz: K4O6aMFQSLIbWxtGpPy2gZDB5q = SmbNGskjMx
	elif K4O6aMFQSLIbWxtGpPy2gZDB5q==f4fTutDOEwUeIoPLRQ: K4O6aMFQSLIbWxtGpPy2gZDB5q = SmbNGskjMx
	elif K4O6aMFQSLIbWxtGpPy2gZDB5q==QQSugEIn2mTCpRsfcaJHhPdAWzylM: K4O6aMFQSLIbWxtGpPy2gZDB5q = Ag9l6cw3EBqP8HsQuGMizfOtr4
	return K4O6aMFQSLIbWxtGpPy2gZDB5q
def nnRXQH90qeOtABkJzGr(*aargs,**kkwargs):
	return LAkCFq8ezcf.Dialog().select(*aargs,**kkwargs)
def SSVCGE0bOfW1w9u52yvBxocNeP(*aargs,**kkwargs):
	uFvPQ6sYzyaq03f5riTIpcO = aargs[f4fTutDOEwUeIoPLRQ]
	om2lqtcZ5y4j = aargs[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	pWUkKRaDhT0l98wZ = kkwargs[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡷ࡭ࡲ࡫ࠧ༨")] if X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡸ࡮ࡳࡥࠨ༩") in list(kkwargs.keys()) else bnI4kmPtrW7yFEhljXOCq9(u"࠱࠱࠲࠳ᐼ")
	SbVf79sY3qZdivrHnw = aargs[QQSugEIn2mTCpRsfcaJHhPdAWzylM] if len(aargs)>QQSugEIn2mTCpRsfcaJHhPdAWzylM and q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡹ࡯࡭ࡦࠩ༪") not in aargs[QQSugEIn2mTCpRsfcaJHhPdAWzylM] else Fo1SgXMsHk(u"ࠬࡴ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡣࡷ࡫ࡧࡶ࡮ࡤࡶࠬ༫")
	llcD1veu9YVbRqL = eb6R0h1Fjl.Thread(target=TOFHqwLsbz2x6AKVIYSocJ0MGEg4,args=(uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,SbVf79sY3qZdivrHnw,pWUkKRaDhT0l98wZ))
	llcD1veu9YVbRqL.start()
	return
def TOFHqwLsbz2x6AKVIYSocJ0MGEg4(uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,SbVf79sY3qZdivrHnw,pWUkKRaDhT0l98wZ):
	iujYGt1OwpQqT4bF6l = SbVf79sY3qZdivrHnw.replace(t4txivgXSUWBOlCakQmNDjf(u"࠭࡮ࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲࡤ࠭༬"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	name = Op47XGBbfiolxenLkTdyPrW6Z(Ag9l6cw3EBqP8HsQuGMizfOtr4,iujYGt1OwpQqT4bF6l+tM24jD1gO0(u"ࠧࠡ࠯ࠣࠫ༭")+uFvPQ6sYzyaq03f5riTIpcO+z3sIGH8jmLYg(u"ࠨࠢ࠰ࠤࠬ༮")+om2lqtcZ5y4j)
	name = JABPVj6TrWOU29Xvmo(name)
	image_filename = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(UWC1po65KvgulqE4rmTcMfHkwnxb,name+UpQ56M0dO1N9xIvVegy(u"ࠩ࠱ࡴࡳ࡭ࠧ༯"))
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(image_filename):
		if SbVf79sY3qZdivrHnw==qrjy8LuKVPNYdbSvzh(u"ࠪࡲࡴࡺࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࡡࡵࡩ࡬ࡻ࡬ࡢࡴࠪ༰"): image_height = Fo1SgXMsHk(u"࠲࠳࠺ᐽ")
		elif SbVf79sY3qZdivrHnw==xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡳࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࡢࡥࡺࡺ࡯ࠨ༱"): image_height = fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠴࠴࠴ᐾ")
	else: image_height = u4IWfU1ashntg3T(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,SbVf79sY3qZdivrHnw,fgv5U2eRVaQqSiuGD(u"ࠬࡲࡥࡧࡶࠪ༲"),SmbNGskjMx,image_filename)
	kXSzZd2KeCsm4PEHig0YUhqJBwR = rRoSZPg8iW5NdFXjp(Fo1SgXMsHk(u"࠭ࡄࡪࡣ࡯ࡳ࡬ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࡍࡲࡧࡧࡦ࠰ࡻࡱࡱ࠭༳"),VK0O2udTgfH8Y3GyvhmqNQZDEx,I3cxjYaHhsrM7T4UX26klN(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨ༴"),SSvu1CZjTW7FcloNqD(u"ࠨ࠹࠵࠴ࡵ༵࠭"))
	kXSzZd2KeCsm4PEHig0YUhqJBwR.show()
	if SbVf79sY3qZdivrHnw==cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡱࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࡠࡣࡸࡸࡴ࠭༶"):
		kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠽࠵࠺࠰ᑀ")).setHeight(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠵࠵࠺ᐿ"))
		kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠹࠱࠶࠳ᑃ")).setPosition(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠺࠻ᑁ"),-X60YQOADpkHBb31LiR5qUEKfM(u"࠾࠰ᑂ"))
		kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(UpQ56M0dO1N9xIvVegy(u"࠺࠲࠸࠴ᑄ")).setPosition(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠳࠵࠴ᑅ"),-xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠹࠴ᑆ"))
		kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(bnI4kmPtrW7yFEhljXOCq9(u"࠺࠰࠱ᑉ")).setPosition(q4izXt0sjIQSZcHVAf3EmKRbx(u"࠽࠵ᑇ"),-paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠸࠻ᑈ"))
	kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(DJ6ugPjW9bX8I(u"࠴࠱࠳ᑊ")).setVisible(SmbNGskjMx)
	kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠵࠲࠵ᑋ")).setVisible(SmbNGskjMx)
	kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(Fo1SgXMsHk(u"࠻࠳࠹࠵ᑌ")).setImage(image_filename)
	kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠼࠴࠺࠶ᑍ")).setHeight(image_height)
	lQMuw1PvVpAk.sleep(pWUkKRaDhT0l98wZ//YayJj10OGl(u"࠵࠵࠶࠰࠯࠲ᑎ"))
	return
def zU4taVvj6x12(*aargs,**kkwargs):
	uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,profile,direction = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪ༷ࠫ"),tM24jD1gO0(u"ࠫࡱ࡫ࡦࡵࠩ༸")
	if len(aargs)>=vkIa3ijEQVsJGdWOXwK7bnue9ADR: uFvPQ6sYzyaq03f5riTIpcO = aargs[f4fTutDOEwUeIoPLRQ]
	if len(aargs)>=QQSugEIn2mTCpRsfcaJHhPdAWzylM: om2lqtcZ5y4j = aargs[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	if len(aargs)>=ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb: profile = aargs[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
	if len(aargs)>=WtDrnpJmwQ37Z2Ae68hu4BY5M1: direction = aargs[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
	return r31rWd0qVCzeNapuFjwZg8scSIi5(direction,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,profile)
def unWTBJIFERUQqx0NS5DOjgP(*aargs,**kkwargs):
	return LAkCFq8ezcf.Dialog().contextmenu(*aargs,**kkwargs)
def bboV3ruP5MYqCOdeBK1XnRJUcxv8(*aargs,**kkwargs):
	return LAkCFq8ezcf.Dialog().browseSingle(*aargs,**kkwargs)
def XdJg5QtsHAmrFUh26c9Opf1BI(*aargs,**kkwargs):
	return LAkCFq8ezcf.Dialog().input(*aargs,**kkwargs)
def LMSZwD0IRAziTh(*aargs,**kkwargs):
	return LAkCFq8ezcf.DialogProgress(*aargs,**kkwargs)
def YuqCtbB0XfT6rGUwS5z79VDk3del2E(direction,button0=nbOFVEDkpT4BIR7Qq82yPmHeJU,button1=nbOFVEDkpT4BIR7Qq82yPmHeJU,button2=nbOFVEDkpT4BIR7Qq82yPmHeJU,uFvPQ6sYzyaq03f5riTIpcO=nbOFVEDkpT4BIR7Qq82yPmHeJU,om2lqtcZ5y4j=nbOFVEDkpT4BIR7Qq82yPmHeJU,profile=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡢࡪࡩࡩࡳࡳࡺ༹ࠧ"),TIKbDjgOlHF6ASv4dyJi=f4fTutDOEwUeIoPLRQ,ZFhGLEtHcBzl4YUS=f4fTutDOEwUeIoPLRQ):
	if not direction: direction = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡣࡦࡰࡷࡩࡷ࠭༺")
	kXSzZd2KeCsm4PEHig0YUhqJBwR = eDQpxkXECKPv726ary3oJN(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡃࡰࡰࡩ࡭ࡷࡳࡔࡩࡴࡨࡩࡇࡻࡴࡵࡱࡱࡷ࠳ࡾ࡭࡭ࠩ༻"),VK0O2udTgfH8Y3GyvhmqNQZDEx,qrjy8LuKVPNYdbSvzh(u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ༼"),YayJj10OGl(u"ࠩ࠺࠶࠵ࡶࠧ༽"))
	kXSzZd2KeCsm4PEHig0YUhqJBwR.SunQIhtaHzidgwLM(button0,button1,button2,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,profile,direction,TIKbDjgOlHF6ASv4dyJi,ZFhGLEtHcBzl4YUS)
	if TIKbDjgOlHF6ASv4dyJi>f4fTutDOEwUeIoPLRQ: kXSzZd2KeCsm4PEHig0YUhqJBwR.FnmT0NgaBiHGyKRpSqsP2Z7EuD()
	if ZFhGLEtHcBzl4YUS>f4fTutDOEwUeIoPLRQ: kXSzZd2KeCsm4PEHig0YUhqJBwR.RdCY3r5JBHa2SuGon9Liz()
	if TIKbDjgOlHF6ASv4dyJi==f4fTutDOEwUeIoPLRQ and ZFhGLEtHcBzl4YUS==f4fTutDOEwUeIoPLRQ: kXSzZd2KeCsm4PEHig0YUhqJBwR.JVdDRQZfvkrzm0GPKFMbXxw2I3()
	kXSzZd2KeCsm4PEHig0YUhqJBwR.doModal()
	K4O6aMFQSLIbWxtGpPy2gZDB5q = kXSzZd2KeCsm4PEHig0YUhqJBwR.choiceID
	return K4O6aMFQSLIbWxtGpPy2gZDB5q
def r31rWd0qVCzeNapuFjwZg8scSIi5(direction,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,profile=flDSRbv57PnV3(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫ༾")):
	if not direction: direction = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡱ࡫ࡦࡵࠩ༿")
	kXSzZd2KeCsm4PEHig0YUhqJBwR = rRoSZPg8iW5NdFXjp(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡊࡩࡢ࡮ࡲ࡫࡙࡫ࡸࡵࡘ࡬ࡩࡼ࡫ࡲࡇࡷ࡯ࡰࡘࡩࡲࡦࡧࡱ࠲ࡽࡳ࡬ࠨཀ"),VK0O2udTgfH8Y3GyvhmqNQZDEx,qrjy8LuKVPNYdbSvzh(u"࠭ࡄࡦࡨࡤࡹࡱࡺࠧཁ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠸࠴࠳ࡴࠬག"))
	image_filename = uGlSeqMahrVHD6kdBAo4TCcy5nXxN.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡡ࠳࠴࠵࠶࡟ࠨགྷ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡢࠫང")+str(lQMuw1PvVpAk.time())+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡣࠬཅ"))
	image_filename = image_filename.replace(DJ6ugPjW9bX8I(u"ࠫࡡࡢࠧཆ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡢ࡜࡝࡞ࠪཇ")).replace(ulAxHwvzR9eTb5n(u"࠭࠯࠰ࠩ཈"),tM24jD1gO0(u"ࠧ࠰࠱࠲࠳ࠬཉ"))
	image_height = u4IWfU1ashntg3T(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,uFvPQ6sYzyaq03f5riTIpcO,om2lqtcZ5y4j,profile,direction,SmbNGskjMx,image_filename)
	kXSzZd2KeCsm4PEHig0YUhqJBwR.show()
	kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(ulAxHwvzR9eTb5n(u"࠾࠶࠵࠱ᑏ")).setHeight(image_height)
	kXSzZd2KeCsm4PEHig0YUhqJBwR.getControl(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠿࠰࠶࠲ᑐ")).setImage(image_filename)
	tinT1zh3lAZ = kXSzZd2KeCsm4PEHig0YUhqJBwR.doModal()
	try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(image_filename)
	except: pass
	return tinT1zh3lAZ
def MdwGcQOsmlV6vKI73THrUY4(ilrw4IjUxQDWJ31VmS6BPugRsK=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	if ilrw4IjUxQDWJ31VmS6BPugRsK:
		VLs4zv8ycboXT0UG7rk2fAj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡵࡷࡶࠬཊ"),DJ6ugPjW9bX8I(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬཋ"),tM24jD1gO0(u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭ཌ"))
		if VLs4zv8ycboXT0UG7rk2fAj: return VLs4zv8ycboXT0UG7rk2fAj
	om2lqtcZ5y4j = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if f4fTutDOEwUeIoPLRQ and cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
		nnrNqvWG5TuXtCRK = B69RXYW5vf8Jt7O.count(bYyKEjIuGQzoq3AR1(u"ࠫࡒࡵࡺࡪ࡮࡯ࡥࠬཌྷ"))
		if nnrNqvWG5TuXtCRK>ulAxHwvzR9eTb5n(u"࠸࠱ᑑ"):
			om2lqtcZ5y4j = ScntgdOZCY74vNpXeW5jh8i.findall(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࡭ࡥࡵ࠯ࡷ࡬ࡪ࠳࡬ࡪࡵࡷ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧཎ"),B69RXYW5vf8Jt7O,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			om2lqtcZ5y4j = om2lqtcZ5y4j[f4fTutDOEwUeIoPLRQ]
	if not om2lqtcZ5y4j:
		Ul87Qx0EzTgNJVa23nK1Pyj = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬཏ"),z3sIGH8jmLYg(u"ࠧࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡶ࠲ࡹࡾࡴࠨཐ"))
		om2lqtcZ5y4j = open(Ul87Qx0EzTgNJVa23nK1Pyj,bYyKEjIuGQzoq3AR1(u"ࠨࡴࡥࠫད")).read()
		if IZhXMprxvAHqBEFkg0: om2lqtcZ5y4j = om2lqtcZ5y4j.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		om2lqtcZ5y4j = om2lqtcZ5y4j.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	CCQNZiSVfdAv9ez5 = ScntgdOZCY74vNpXeW5jh8i.findall(X1mRwt2YJKgCLu9a67(u"ࠩࠫࡑࡴࢀࡩ࡭࡮ࡤ࠲࠯ࡅࠩ࡝ࡰࠪདྷ"),om2lqtcZ5y4j,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	ttlp4eLusAFPEG = []
	for nnOtpcqvi6mCdL5QGgbhwkX9A1Y in CCQNZiSVfdAv9ez5:
		aFZqCkS8liLYT2mtwvpdj = nnOtpcqvi6mCdL5QGgbhwkX9A1Y.lower()
		if I3cxjYaHhsrM7T4UX26klN(u"ࠪࡥࡳࡪࡲࡰ࡫ࡧࠫན") in aFZqCkS8liLYT2mtwvpdj: continue
		if fgv5U2eRVaQqSiuGD(u"ࠫࡺࡨࡵ࡯ࡶࡸࠫཔ") in aFZqCkS8liLYT2mtwvpdj: continue
		if xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬ࡯ࡰࡩࡱࡱࡩࠬཕ") in aFZqCkS8liLYT2mtwvpdj: continue
		if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࡣࡳࡱࡶࠫབ") in aFZqCkS8liLYT2mtwvpdj: continue
		ttlp4eLusAFPEG.append(nnOtpcqvi6mCdL5QGgbhwkX9A1Y)
	VLs4zv8ycboXT0UG7rk2fAj = eH7yw1hTGUROK2B4dcP0iEr.sample(ttlp4eLusAFPEG,vkIa3ijEQVsJGdWOXwK7bnue9ADR)
	VLs4zv8ycboXT0UG7rk2fAj = VLs4zv8ycboXT0UG7rk2fAj[f4fTutDOEwUeIoPLRQ]
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,qrjy8LuKVPNYdbSvzh(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪབྷ"),tM24jD1gO0(u"ࠨࡗࡖࡉࡗࡇࡇࡆࡐࡗࠫམ"),VLs4zv8ycboXT0UG7rk2fAj,RRYx6sACloVPr3td95Ej)
	return VLs4zv8ycboXT0UG7rk2fAj
def ldsAFanjmVkh93ybXC(vf9s4ClmTE08AGndQV=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not vf9s4ClmTE08AGndQV: vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
	if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡖࡽࡸࡺࡥ࡮ࡇࡻ࡭ࡹ࠭ཙ") in vf9s4ClmTE08AGndQV or bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ཚ") in vf9s4ClmTE08AGndQV: return
	if vf9s4ClmTE08AGndQV!=l4DS8mnEjHhFMZ5YOe(u"ࠫࡓࡵ࡮ࡦࡖࡼࡴࡪࡀࠠࡏࡱࡱࡩࡡࡴࠧཛ"): Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
	FV968pLETkDJwxhXlye2O5ScH = vf9s4ClmTE08AGndQV.splitlines()
	FfrbtQYZoXdWM3Lu6nKU5g0RP4 = FV968pLETkDJwxhXlye2O5ScH[-YayJj10OGl(u"࠲ᑒ")]
	YY7qI1R8T03pwiFf2euj = open(vOxIJSfwPEpCc,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡸࡢࠨཛྷ")).read()
	if IZhXMprxvAHqBEFkg0: YY7qI1R8T03pwiFf2euj = YY7qI1R8T03pwiFf2euj.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	YY7qI1R8T03pwiFf2euj = YY7qI1R8T03pwiFf2euj[-DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠺࠳࠴࠵ᑓ"):]
	XXzySLFH501xlfQG = DJ6ugPjW9bX8I(u"࠭࠽ࠨཝ")*l4DS8mnEjHhFMZ5YOe(u"࠴࠴࠵ᑔ")
	if XXzySLFH501xlfQG in YY7qI1R8T03pwiFf2euj: YY7qI1R8T03pwiFf2euj = YY7qI1R8T03pwiFf2euj.rsplit(XXzySLFH501xlfQG,vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	if FfrbtQYZoXdWM3Lu6nKU5g0RP4 in YY7qI1R8T03pwiFf2euj: YY7qI1R8T03pwiFf2euj = YY7qI1R8T03pwiFf2euj.rsplit(FfrbtQYZoXdWM3Lu6nKU5g0RP4,vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
	pLhwC75ZXF0WgyDE = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠧࠩࡕࡲࡹࡷࡩࡥࡽࡏࡲࡨࡪ࠯࠺ࠡ࡞࡞ࠤ࠭࠴ࠪࡀࠫࠣࡠࡢ࠭ཞ"),YY7qI1R8T03pwiFf2euj,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for GxWyPKI7blwcFeak,eg6iV4ckQxvTrjWKyBulYR in reversed(pLhwC75ZXF0WgyDE):
		if eg6iV4ckQxvTrjWKyBulYR: break
	else: eg6iV4ckQxvTrjWKyBulYR = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡐࡒࡘ࡙ࠥࡐࡆࡅࡌࡊࡎࡋࡄࠨཟ")
	jjdUcJoK8fm1pbrS,nnOtpcqvi6mCdL5QGgbhwkX9A1Y,CCbUwJckDm = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	BoY4CMtbkXjugIRJ90 = UpQ56M0dO1N9xIvVegy(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨའ")+l5JG7XwbOfo8DznU+Fo1SgXMsHk(u"ࠪห้ิืฤ࠼ࠣࠤࠬཡ")+c7gxFyUCGm+FfrbtQYZoXdWM3Lu6nKU5g0RP4
	q1S5R0VxsyPwtMkemY7rGdO = DJ6ugPjW9bX8I(u"ࠫࡠࡘࡔࡍ࡟ࠪར")+l5JG7XwbOfo8DznU+YayJj10OGl(u"ࠬอไๆืาี࠿ࠦࠠࠨལ")+c7gxFyUCGm+eg6iV4ckQxvTrjWKyBulYR
	for tDhIRPBwMucn2A in reversed(FV968pLETkDJwxhXlye2O5ScH):
		if bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡆࡪ࡮ࡨࠤࠧ࠭ཤ") in tDhIRPBwMucn2A and cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠭ཥ") in tDhIRPBwMucn2A: break
	tDhIRPBwMucn2A = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠨࡈ࡬ࡰࡪࠦࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࠭ࠢ࡯࡭ࡳ࡫ࠠࠩ࠰࠭ࡃ࠮ࡢࠬࠡ࡫ࡱࠤ࠭࠴ࠪࡀࠫࠧࠫས"),tDhIRPBwMucn2A,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if tDhIRPBwMucn2A:
		jjdUcJoK8fm1pbrS,nnOtpcqvi6mCdL5QGgbhwkX9A1Y,CCbUwJckDm = tDhIRPBwMucn2A[f4fTutDOEwUeIoPLRQ]
		if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩ࠲ࠫཧ") in jjdUcJoK8fm1pbrS: jjdUcJoK8fm1pbrS = jjdUcJoK8fm1pbrS.rsplit(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪ࠳ࠬཨ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		else: jjdUcJoK8fm1pbrS = jjdUcJoK8fm1pbrS.rsplit(t4txivgXSUWBOlCakQmNDjf(u"ࠫࡡࡢࠧཀྵ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		poZrCbvq37zkds = I3cxjYaHhsrM7T4UX26klN(u"ࠬࡡࡒࡕࡎࡠࠫཪ")+l5JG7XwbOfo8DznU+flDSRbv57PnV3(u"࠭วๅ็็ๅ࠿ࠦࠠࠨཫ")+c7gxFyUCGm+jjdUcJoK8fm1pbrS
		O6EsTrcXeSz89WKhZkuol1IV = fgv5U2eRVaQqSiuGD(u"ࠧ࡜ࡔࡗࡐࡢ࠭ཬ")+l5JG7XwbOfo8DznU+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨษ็ื฼ื࠺ࠡࠢࠪ཭")+c7gxFyUCGm+nnOtpcqvi6mCdL5QGgbhwkX9A1Y
		qEMj9KeW2AoUw = ulAxHwvzR9eTb5n(u"ࠩ࡞ࡖ࡙ࡒ࡝ࠨ཮")+l5JG7XwbOfo8DznU+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪห้๋ใศ่࠽ࠤࠥ࠭཯")+c7gxFyUCGm+CCbUwJckDm
		UAJ4jtG08afvLBZ3DQhV = poZrCbvq37zkds+wwOnIucWJj+O6EsTrcXeSz89WKhZkuol1IV+wwOnIucWJj+qEMj9KeW2AoUw+wwOnIucWJj+q1S5R0VxsyPwtMkemY7rGdO+wwOnIucWJj+BoY4CMtbkXjugIRJ90
		ppCKveWtG6N = O6EsTrcXeSz89WKhZkuol1IV+wwOnIucWJj+q1S5R0VxsyPwtMkemY7rGdO+wwOnIucWJj+BoY4CMtbkXjugIRJ90+wwOnIucWJj+poZrCbvq37zkds+wwOnIucWJj+qEMj9KeW2AoUw
		v0762jaUGuNO9IMinpq1rtZJb3kgo = O6EsTrcXeSz89WKhZkuol1IV+wwOnIucWJj+BoY4CMtbkXjugIRJ90+wwOnIucWJj+poZrCbvq37zkds+wwOnIucWJj+qEMj9KeW2AoUw
	else:
		poZrCbvq37zkds,O6EsTrcXeSz89WKhZkuol1IV,qEMj9KeW2AoUw = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
		UAJ4jtG08afvLBZ3DQhV = q1S5R0VxsyPwtMkemY7rGdO+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡡࡴ࡜࡯ࠩ཰")+BoY4CMtbkXjugIRJ90
		ppCKveWtG6N = q1S5R0VxsyPwtMkemY7rGdO+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡢ࡮࡝ࡰཱࠪ")+BoY4CMtbkXjugIRJ90
		v0762jaUGuNO9IMinpq1rtZJb3kgo = BoY4CMtbkXjugIRJ90
	VqpoRfYgb8MQ2 = cb3rmvAn4wa6lBPz2phOoYqX(u"࠭อะอࠣา฼ษࠠ฻์ิࠤ๊่ี้ัིࠪ")+wwOnIucWJj
	qqKcFILbhsVY = xDsF5vGV0J39gAjM()
	tXdFbwBYj0GKuRxeqLs3ma4hzN = []
	bPFto2wZdNYrClgBIEv60DJAzu = qqKcFILbhsVY[X1mRwt2YJKgCLu9a67(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷཱིࠬ")]
	fPgeCVLvuXrK6cZmT5khq3Fp = ZZBH70rGPWXq9fCThR(JeVILUu027qW)
	if bYyKEjIuGQzoq3AR1(u"ࠨࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸུ࠭") in list(qqKcFILbhsVY.keys()):
		for nBVQ1KsvOAShDJ,jVFc0m9tsK8,CeTvcgZVAw2NM8f6H3yDW47xI in bPFto2wZdNYrClgBIEv60DJAzu:
			tXdFbwBYj0GKuRxeqLs3ma4hzN = max(tXdFbwBYj0GKuRxeqLs3ma4hzN,jVFc0m9tsK8)
		if fPgeCVLvuXrK6cZmT5khq3Fp<tXdFbwBYj0GKuRxeqLs3ma4hzN:
			uFvPQ6sYzyaq03f5riTIpcO = ulAxHwvzR9eTb5n(u"ࠩๅ้ࠥฮสฮัํฯࠥอไษำ้ห๊าࠠใส็ࠤสืำศๆࠣห้ษฮุษฤࠤ้๊ๅษำ่ะཱུࠬ")
			K4O6aMFQSLIbWxtGpPy2gZDB5q = YuqCtbB0XfT6rGUwS5z79VDk3del2E(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡶ࡮࡭ࡨࡵࠩྲྀ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨཷ"),tM24jD1gO0(u"ࠬะอะ์ฮࠫླྀ"),QlTuvPbSpnjygBVW(u"࠭ฮา๊ฯࠫཹ"),VqpoRfYgb8MQ2+uFvPQ6sYzyaq03f5riTIpcO,UAJ4jtG08afvLBZ3DQhV)
			if K4O6aMFQSLIbWxtGpPy2gZDB5q==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				import SJqrPsfTgG
				SJqrPsfTgG.mmhRocLej7aHKt4QYIyJNp9Bk(Ag9l6cw3EBqP8HsQuGMizfOtr4)
				R5VzflU0D2LQaSoKOskBuYtrXFC()
			elif K4O6aMFQSLIbWxtGpPy2gZDB5q==QQSugEIn2mTCpRsfcaJHhPdAWzylM: R5VzflU0D2LQaSoKOskBuYtrXFC()
	o3aHCXRSK71BW0ckzPOUtuTVsMbNh5 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,tM24jD1gO0(u"ࠧ࡭࡫ࡶࡸེࠬ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡏࡌࡗࡈࡥࡐࡆࡔࡐཻࠫ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡄࡐࡑࡥࡓࡆࡐࡗࡣࡊࡘࡒࡐࡔࡖོࠫ"))
	if not o3aHCXRSK71BW0ckzPOUtuTVsMbNh5: o3aHCXRSK71BW0ckzPOUtuTVsMbNh5 = []
	ppCKveWtG6N = ppCKveWtG6N.replace(wwOnIucWJj,DJ6ugPjW9bX8I(u"ࠪࡠࡡࡴཽࠧ")).replace(SSvu1CZjTW7FcloNqD(u"ࠫࡠࡘࡔࡍ࡟ࠪཾ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(l5JG7XwbOfo8DznU,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	v0762jaUGuNO9IMinpq1rtZJb3kgo = v0762jaUGuNO9IMinpq1rtZJb3kgo.replace(wwOnIucWJj,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡢ࡜࡯ࠩཿ")).replace(l4DS8mnEjHhFMZ5YOe(u"࡛࠭ࡓࡖࡏࡡྀࠬ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(l5JG7XwbOfo8DznU,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	yyIgUQjNJL = JeVILUu027qW+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࠻࠼ཱྀࠪ")+v0762jaUGuNO9IMinpq1rtZJb3kgo
	if yyIgUQjNJL in o3aHCXRSK71BW0ckzPOUtuTVsMbNh5:
		uFvPQ6sYzyaq03f5riTIpcO = tM24jD1gO0(u"ࠨๆๅำ่ࠥๅหࠢส๊ฯࠦำศสๅหࠥฮลาีส่ࠥํะศࠢส่ำ฽รࠡว็ํࠥอไๆสิ้ั࠭ྂ")
		aY7RFmnWc5uU9T3Q0Mxq4(tM24jD1gO0(u"ࠩࡵ࡭࡬࡮ࡴࠨྃ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,VqpoRfYgb8MQ2+uFvPQ6sYzyaq03f5riTIpcO,UAJ4jtG08afvLBZ3DQhV)
		return
	YcmXtPgKV69jrnspd = str(o8MCS3IzmRXdVDB7xg2eiW5baZUn).split(SSvu1CZjTW7FcloNqD(u"ࠪ࠲྄ࠬ"))[f4fTutDOEwUeIoPLRQ]
	qxZiT6WJ7sX = sCSyOla9hrcE[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫ྅")][DJ6ugPjW9bX8I(u"࠺ᑕ")]
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,X1mRwt2YJKgCLu9a67(u"ࠬࡖࡏࡔࡖࠪ྆"),qxZiT6WJ7sX,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡊࡒ࡛ࡤࡋࡘࡊࡖࡢࡉࡗࡘࡏࡓࡕ࠰࠵ࡸࡺࠧ྇"),SmbNGskjMx,SmbNGskjMx)
	B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
	WeL2PrsiBEAqpQVSFzY = ScntgdOZCY74vNpXeW5jh8i.findall(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡔࡖࡄࡖ࡙ࡀ࠺ࡔࡖࡄࡖ࡙ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡀ࠺ࠩ࠰࠭ࡃ࠮ࡡ࡜ࡳ࡞ࡱࡡ࠰ࡋࡎࡅ࠼࠽ࡉࡓࡊࠧྈ"),B69RXYW5vf8Jt7O,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for XRYkwAoD46paty,nIBmxtLeEM,cManrTouZmOCY,GMQx4sRCvTNzZ9S8gVUJ in WeL2PrsiBEAqpQVSFzY:
		XRYkwAoD46paty = XRYkwAoD46paty.split(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨ࠭ࠪྉ"))
		cManrTouZmOCY = cManrTouZmOCY.split(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩ࠮ࠫྊ"))
		GMQx4sRCvTNzZ9S8gVUJ = GMQx4sRCvTNzZ9S8gVUJ.split(bYyKEjIuGQzoq3AR1(u"ࠪ࠯ࠬྋ"))
		if nnOtpcqvi6mCdL5QGgbhwkX9A1Y in XRYkwAoD46paty and FfrbtQYZoXdWM3Lu6nKU5g0RP4==nIBmxtLeEM and JeVILUu027qW in cManrTouZmOCY and YcmXtPgKV69jrnspd in GMQx4sRCvTNzZ9S8gVUJ:
			uFvPQ6sYzyaq03f5riTIpcO = YayJj10OGl(u"ࠫ์ึวࠡษ็า฼ษࠠๆ฻ิ์ๆ่ࠦิ์฼ห้าࠠษษ็ษฺีวาࠢส่็อฯๆࠩྌ")
			oyNUHM3uQq = ttiZs4bKHFvugJj5z(fgv5U2eRVaQqSiuGD(u"ࠬࡸࡩࡨࡪࡷࠫྍ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ฮา๊ฯࠫྎ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠧฦำึห้ࠦลๅ๋ࠣห้๋ศา็ฯࠫྏ"),VqpoRfYgb8MQ2+uFvPQ6sYzyaq03f5riTIpcO,UAJ4jtG08afvLBZ3DQhV)
			if oyNUHM3uQq==vkIa3ijEQVsJGdWOXwK7bnue9ADR: aY7RFmnWc5uU9T3Q0Mxq4(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨྐ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,uFvPQ6sYzyaq03f5riTIpcO)
			return
	uFvPQ6sYzyaq03f5riTIpcO = UpQ56M0dO1N9xIvVegy(u"ࠩส่ึาวยࠢศีุอไ้ࠡำหࠥอไฯูฦࠤส๊้ࠡษ็้อืๅอࠩྑ")
	o4bm3GWNZOsKRQCt5zkneISYcuhH = YuqCtbB0XfT6rGUwS5z79VDk3del2E(qrjy8LuKVPNYdbSvzh(u"ࠪࡶ࡮࡭ࡨࡵࠩྒ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫสืำศๆࠣษ้๏ࠠศๆ่ฬึ๋ฬࠨྒྷ"),Fo1SgXMsHk(u"ࠬะอะ์ฮࠤัุฦ๋ࠩྔ"),UpQ56M0dO1N9xIvVegy(u"࠭สฮัํฯࠥอไษำ้ห๊าࠧྕ"),VqpoRfYgb8MQ2+uFvPQ6sYzyaq03f5riTIpcO,UAJ4jtG08afvLBZ3DQhV)
	if o4bm3GWNZOsKRQCt5zkneISYcuhH==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		ylGTu5RkOxQEeCD(SmbNGskjMx)
		SSVCGE0bOfW1w9u52yvBxocNeP(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤฬ๊สฮัํฯࠥอไอิษ๎ࠬྖ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠨ๏ࡖࡹࡨࡩࡥࡴࡵࠪྗ"),lQMuw1PvVpAk=cb3rmvAn4wa6lBPz2phOoYqX(u"࠼࠻࠰ᑖ"))
		R5VzflU0D2LQaSoKOskBuYtrXFC()
	elif o4bm3GWNZOsKRQCt5zkneISYcuhH==QQSugEIn2mTCpRsfcaJHhPdAWzylM:
		import SJqrPsfTgG
		SJqrPsfTgG.mmhRocLej7aHKt4QYIyJNp9Bk(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		R5VzflU0D2LQaSoKOskBuYtrXFC()
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡦࡩࡳࡺࡥࡳࠩ྘"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ྙ"),ulAxHwvzR9eTb5n(u"ุࠫ๎แࠡ์อ้ࠥหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์฼ีๆࠦวๅ็หี๊าࠠฤ์้ࠤํ๋ส๊๋ࠢ็๏็้ࠠๆ่หีอࠠฮื็ฮࠥํะ่ࠢสฺ่๊ใๅห่ࠣศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศ๊ࠡ็หࠥ๐ำหูํ฽ࠥอีๅษะࠤฺ๊ใๅหࠣ์์๎ࠠๅษࠣ๎฾ืแࠡๅํๅࠥ฾็าฬࠣ์้๋วัษࠣ฼์ืส๊่ࠡฮ๎ุ่ࠦำอࠤ์ึ็ࠡษ็ู้้ไสࠢ࠱ࠤ์๊ࠠหำํำࠥษัิษ็ࠤฬ๊ำอๆࠣรࠬྚ"))
	if oyNUHM3uQq==vkIa3ijEQVsJGdWOXwK7bnue9ADR: rsymoFnMJ3HE1z7l9T = YayJj10OGl(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࠨྛ")
	else:
		aY7RFmnWc5uU9T3Q0Mxq4(t4txivgXSUWBOlCakQmNDjf(u"࠭ࡣࡦࡰࡷࡩࡷ࠭ྜ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪྜྷ"),l5JG7XwbOfo8DznU+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨฬ่ࠤสฺ๊ศรࠣษึูวๅࠢส่ำ฽รࠨྞ")+c7gxFyUCGm+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩ࡟ࡲ้ษๆࠡษ็้อืๅอࠢ็หࠥ๐ูๅ็ࠣห้เ๊ษ๋่ࠢฬ๊ࠦิฬฺ๎฾ࠦลึๆสัࠥอไฯูฦࠤอี่็ࠢึะ้ࠦวๅลั฻ฬวࠠศๆำ๎๋ࠥให๊หࠤๆ๐็ࠡฮ่๎฾ࠦสโษุ๎้ࠦ็ัษࠣห้ิืฤ๋ࠢ฾๏ื็ࠡ็้ࠤฬ๊รฯูสลࠬྟ"))
		return
	D3PFE9RevWhwfUxYo51ta = ppCKveWtG6N
	import SJqrPsfTgG
	EJNf2kglaiQHnFGe531Iq = SJqrPsfTgG.Rs07nFAOYjCQN(IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡉࡷࡸ࡯ࡳࡵࠪྠ"),D3PFE9RevWhwfUxYo51ta,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡊࡓࡁࡊࡎ࠰ࡊࡗࡕࡍ࠮ࡕࡋࡓ࡜ࡥࡅ࡙ࡋࡗࡣࡊࡘࡒࡐࡔࡖࠫྡ"),rsymoFnMJ3HE1z7l9T)
	if EJNf2kglaiQHnFGe531Iq and rsymoFnMJ3HE1z7l9T:
		o3aHCXRSK71BW0ckzPOUtuTVsMbNh5.append(yyIgUQjNJL)
		z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨྡྷ"),ulAxHwvzR9eTb5n(u"࠭ࡁࡍࡎࡢࡗࡊࡔࡔࡠࡇࡕࡖࡔࡘࡓࠨྣ"),o3aHCXRSK71BW0ckzPOUtuTVsMbNh5,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	return
def H0dRxkCIZGvA2XWy(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,filename=None):
	if IZhXMprxvAHqBEFkg0: qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	if not filename: Oy2mWPY6LEsN3S95f = QlTuvPbSpnjygBVW(u"ࠧࡴ࠼࡟ࡠ࠵࠶࠰࠱ࡧࡰࡥࡩࡥࠧྤ")+str(lQMuw1PvVpAk.time())+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨ࠰ࡧࡥࡹ࠭ྥ")
	else: Oy2mWPY6LEsN3S95f = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡶ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤࡠࠩྦ")+filename+flDSRbv57PnV3(u"ࠪ࠲ࡩࡧࡴࠨྦྷ")
	open(Oy2mWPY6LEsN3S95f,X1mRwt2YJKgCLu9a67(u"ࠫࡼࡨࠧྨ")).write(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
	return
def nNR2JPEM9mh(RRdkhxeG53A7ClaoBOzFr0c6I4bD):
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD:
		SEKgsaLmWbq5B7dHX2uQPVTUCe = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡲࡩࡴࡶࠪྩ"),flDSRbv57PnV3(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩྪ"),t4txivgXSUWBOlCakQmNDjf(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪྫ"))
		if SEKgsaLmWbq5B7dHX2uQPVTUCe: return SEKgsaLmWbq5B7dHX2uQPVTUCe
	qxZiT6WJ7sX = sCSyOla9hrcE[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨྫྷ")][DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠻ᑗ")]
	vHsaM4eT5Nkx9Zt = DD98VLARlydeJU4uYk(SmbNGskjMx) if not RRdkhxeG53A7ClaoBOzFr0c6I4bD else iidHGYjPEW4zU
	v47vQB5lUtqRrzjo9HDC = Se0XLol6NIhZdG8HBruT4w()
	OORJ1AnN4w = v47vQB5lUtqRrzjo9HDC.split(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩ࠯ࠫྭ"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
	i4yHDe5TnKCoMGlXkr0UaI = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩྮ"))
	yiGWj1tvHcs6I0JzfaQuC7LTV2e5 = vvwCkoY1ReELHIyWaJf8n9j()
	ME0GZsPhDVmOvYfw = {QlTuvPbSpnjygBVW(u"ࠫࡺࡹࡥࡳࠩྯ"):vHsaM4eT5Nkx9Zt,DJ6ugPjW9bX8I(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ྰ"):JeVILUu027qW,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧྱ"):OORJ1AnN4w,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡪࡦࡶࠫྲ"):u8i2rxCZwsDyW7KMFIbmqgnvS(yiGWj1tvHcs6I0JzfaQuC7LTV2e5)}
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡒࡒࡗ࡙࠭ླ"),qxZiT6WJ7sX,ME0GZsPhDVmOvYfw,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡒࡗࡈࡗ࡙ࡏࡏࡏࡕ࠰࠵ࡸࡺࠧྴ"))
	SEKgsaLmWbq5B7dHX2uQPVTUCe = []
	if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
		SEKgsaLmWbq5B7dHX2uQPVTUCe = B69RXYW5vf8Jt7O.replace(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡠࡡࡸࠧྵ"),wwOnIucWJj).replace(IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡡࡢ࡮ࠨྶ"),wwOnIucWJj).replace(z3sIGH8jmLYg(u"ࠬࡢࡲ࡝ࡰࠪྷ"),wwOnIucWJj).replace(FKuOXLZA8PYBc7,wwOnIucWJj)
		SEKgsaLmWbq5B7dHX2uQPVTUCe = ScntgdOZCY74vNpXeW5jh8i.findall(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡓࡕࡃࡕࡘ࠿ࡀࡓࡕࡃࡕࡘ࠿ࡀࠨ࡝ࡦ࠮࠭࠿ࡀࠨ࠯ࠬࡂ࠭ࡡࡴ࠺࠻ࠪ࠱࠮ࡄ࠯࡜࡯࠼࠽ࠬ࠳࠰࠿ࠪ࡞ࡱ࠾࠿࠮࠮ࠫࡁࠬࡠࡳࡀ࠺ࠩ࠰࠭ࡃ࠮ࡢ࡮ࡆࡐࡇ࠾࠿ࡋࡎࡅࠩྸ"),SEKgsaLmWbq5B7dHX2uQPVTUCe,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if SEKgsaLmWbq5B7dHX2uQPVTUCe:
			SEKgsaLmWbq5B7dHX2uQPVTUCe = sorted(SEKgsaLmWbq5B7dHX2uQPVTUCe,reverse=SmbNGskjMx,key=lambda key: int(key[f4fTutDOEwUeIoPLRQ]))
			qeVZY0a5zp,vHsaM4eT5Nkx9Zt,d1wmW9AYrsK,qbF0StY2asIVE1yWxNn4KUQB9dD,ArJ8jElsYxFZNhfvOiw,szmD9nEACSWOyk15fPl0QZoTv = SEKgsaLmWbq5B7dHX2uQPVTUCe[f4fTutDOEwUeIoPLRQ]
			XszhWN0LMoBIaP = szmD9nEACSWOyk15fPl0QZoTv if Bi6UGMYAPubKoXJge23fIw59vqR8d([YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡎࡖ࠳࠹ࡍ࡞࠰࡭ࡖࡗࡉࡋࡔࡓࡖࡐࡩ࡙ࡊ࡜ࡓࡔࡗ࠼ࡉ࡝࠭ྐྵ")])[f4fTutDOEwUeIoPLRQ] else d1wmW9AYrsK
			llnG7jiQBYKhAeovbT.setSetting(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡣࡹ࠲ࡵ࡫ࡲࡪࡱࡧ࠲࡮ࡴࡦࡰࡵࠪྺ"),XszhWN0LMoBIaP)
			z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡐࡍࡘࡉ࡟ࡕࡇࡐࡔࠬྻ"),I3cxjYaHhsrM7T4UX26klN(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ྼ"),SEKgsaLmWbq5B7dHX2uQPVTUCe,RRYx6sACloVPr3td95Ej)
			llnG7jiQBYKhAeovbT.setSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡵࡺ࡫ࡳࡵ࡫ࡲࡲࡸ࠭྽"),u8i2rxCZwsDyW7KMFIbmqgnvS(sqeRK2tVw8))
	return SEKgsaLmWbq5B7dHX2uQPVTUCe
def LuHJknFyP3VhQNGfr1iwYg5v0X(biSsqlWmZCrBfKAn4NkxHL,a4PSOpvUIYFDuVeN3jt9olJ8iCqKGX=f4fTutDOEwUeIoPLRQ,pnCWtbXFmR3jQMvcV9Kdk=f4fTutDOEwUeIoPLRQ):
	if a4PSOpvUIYFDuVeN3jt9olJ8iCqKGX and not pnCWtbXFmR3jQMvcV9Kdk: pnCWtbXFmR3jQMvcV9Kdk = len(biSsqlWmZCrBfKAn4NkxHL)//a4PSOpvUIYFDuVeN3jt9olJ8iCqKGX
	N6XU4VI7zoJ9pwTq8BcYAG,HT4fGXqv8hEcKsJ,E8gJu2VxcoqW = [],-vkIa3ijEQVsJGdWOXwK7bnue9ADR,f4fTutDOEwUeIoPLRQ
	for EEZcU5jVnCeFk in biSsqlWmZCrBfKAn4NkxHL:
		if E8gJu2VxcoqW%pnCWtbXFmR3jQMvcV9Kdk==f4fTutDOEwUeIoPLRQ:
			HT4fGXqv8hEcKsJ += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			N6XU4VI7zoJ9pwTq8BcYAG.append([])
		N6XU4VI7zoJ9pwTq8BcYAG[HT4fGXqv8hEcKsJ].append(EEZcU5jVnCeFk)
		E8gJu2VxcoqW += vkIa3ijEQVsJGdWOXwK7bnue9ADR
	return N6XU4VI7zoJ9pwTq8BcYAG
def XXa0iIHgpcNARVuzxrF(Oy2mWPY6LEsN3S95f,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC):
	OKCM9wENivtI0buDaP34U7TsQH1 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,Oy2mWPY6LEsN3S95f)
	if vkIa3ijEQVsJGdWOXwK7bnue9ADR or yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡏࡐࡕࡘࡢࠫ྾") not in Oy2mWPY6LEsN3S95f or SSvu1CZjTW7FcloNqD(u"࠭ࡍ࠴ࡗࡢࠫ྿") not in Oy2mWPY6LEsN3S95f: om2lqtcZ5y4j = str(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
	else:
		N6XU4VI7zoJ9pwTq8BcYAG = LuHJknFyP3VhQNGfr1iwYg5v0X(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,bnI4kmPtrW7yFEhljXOCq9(u"࠸ᑘ"))
		om2lqtcZ5y4j = nbOFVEDkpT4BIR7Qq82yPmHeJU
		for YY1dtBGPakcgIxQn4if in N6XU4VI7zoJ9pwTq8BcYAG:
			om2lqtcZ5y4j += str(YY1dtBGPakcgIxQn4if)+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧ࡝ࡰ࡟ࡲࡂࡃ࠽࠾࡞ࡱࡠࡳ࠭࿀")
		om2lqtcZ5y4j = om2lqtcZ5y4j.strip(QlTuvPbSpnjygBVW(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ࿁"))
	sBiuGqU4RcwXgnbAE9D5 = kunYm8Op3RZMzK9qvUI7QCc4X.compress(om2lqtcZ5y4j)
	open(OKCM9wENivtI0buDaP34U7TsQH1,YayJj10OGl(u"ࠩࡺࡦࠬ࿂")).write(sBiuGqU4RcwXgnbAE9D5)
	return
def WGvN7YlOET4kmhsPbfXKCn9tyLF(cZXwI1vKHebdo4YLDqEfMVzrFW,Oy2mWPY6LEsN3S95f):
	if cZXwI1vKHebdo4YLDqEfMVzrFW==SSvu1CZjTW7FcloNqD(u"ࠪࡨ࡮ࡩࡴࠨ࿃"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = {}
	elif cZXwI1vKHebdo4YLDqEfMVzrFW==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡱ࡯ࡳࡵࠩ࿄"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = []
	elif cZXwI1vKHebdo4YLDqEfMVzrFW==flDSRbv57PnV3(u"ࠬࡹࡴࡳࠩ࿅"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = nbOFVEDkpT4BIR7Qq82yPmHeJU
	elif cZXwI1vKHebdo4YLDqEfMVzrFW==SSvu1CZjTW7FcloNqD(u"࠭ࡩ࡯ࡶ࿆ࠪ"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = f4fTutDOEwUeIoPLRQ
	else: qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = None
	OKCM9wENivtI0buDaP34U7TsQH1 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,Oy2mWPY6LEsN3S95f)
	sBiuGqU4RcwXgnbAE9D5 = open(OKCM9wENivtI0buDaP34U7TsQH1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡳࡤࠪ࿇")).read()
	om2lqtcZ5y4j = kunYm8Op3RZMzK9qvUI7QCc4X.decompress(sBiuGqU4RcwXgnbAE9D5)
	if tM24jD1gO0(u"ࠨ࡞ࡱࡠࡳࡃ࠽࠾࠿࡟ࡲࡡࡴࠧ࿈") not in om2lqtcZ5y4j: qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = eval(om2lqtcZ5y4j)
	else:
		N6XU4VI7zoJ9pwTq8BcYAG = om2lqtcZ5y4j.split(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩ࡟ࡲࡡࡴ࠽࠾࠿ࡀࡠࡳࡢ࡮ࠨ࿉"))
		del om2lqtcZ5y4j
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = []
		BTXEReSd9yHVNpag3k4fhZblUF2O = ps6AtMmOZI5izVcr4hF0xn9TJE7RL()
		qeVZY0a5zp = f4fTutDOEwUeIoPLRQ
		for YY1dtBGPakcgIxQn4if in N6XU4VI7zoJ9pwTq8BcYAG:
			BTXEReSd9yHVNpag3k4fhZblUF2O.n5LdtkmOoIx7(str(qeVZY0a5zp),eval,YY1dtBGPakcgIxQn4if)
			qeVZY0a5zp += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		del N6XU4VI7zoJ9pwTq8BcYAG
		BTXEReSd9yHVNpag3k4fhZblUF2O.GNW2KAEq1XwT5leBL98nYjFrfu4D()
		BTXEReSd9yHVNpag3k4fhZblUF2O.IwHZJdoMKB67cWxXyFY()
		AMR5XlfeSVy7dE6GLB0 = list(BTXEReSd9yHVNpag3k4fhZblUF2O.resultsDICT.keys())
		JycCvrakmeEtpg9Mj1f = sorted(AMR5XlfeSVy7dE6GLB0,reverse=SmbNGskjMx,key=lambda key: int(key))
		for qeVZY0a5zp in JycCvrakmeEtpg9Mj1f:
			qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC += BTXEReSd9yHVNpag3k4fhZblUF2O.resultsDICT[qeVZY0a5zp]
	return qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC
def d1IXYVFrneiWly(ldJmEsIZY9A4pXStekwNoTV):
	QQKZOJHXhlABq = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,ulAxHwvzR9eTb5n(u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ࿊"),ldJmEsIZY9A4pXStekwNoTV,fgv5U2eRVaQqSiuGD(u"ࠫࡦࡪࡤࡰࡰ࠱ࡼࡲࡲࠧ࿋"))
	try: HaU4JvoOetXc58E3 = open(QQKZOJHXhlABq,DJ6ugPjW9bX8I(u"ࠬࡸࡢࠨ࿌")).read()
	except:
		NNaLqvhgM5i8GSPzDA = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(x0K15dC9TEQLotSHYOBWU,DJ6ugPjW9bX8I(u"࠭ࡡࡥࡦࡲࡲࡸ࠭࿍"),ldJmEsIZY9A4pXStekwNoTV,X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡢࡦࡧࡳࡳ࠴ࡸ࡮࡮ࠪ࿎"))
		try: HaU4JvoOetXc58E3 = open(NNaLqvhgM5i8GSPzDA,DJ6ugPjW9bX8I(u"ࠨࡴࡥࠫ࿏")).read()
		except: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	if IZhXMprxvAHqBEFkg0: HaU4JvoOetXc58E3 = HaU4JvoOetXc58E3.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	nDW2R03IQ1lPKxwdLiS = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠩ࡬ࡨࡂ࠴ࠪࡀࡸࡨࡶࡸ࡯࡯࡯࠿࡞ࡠࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠤ࡟ࠫࡢ࠭࿐"),HaU4JvoOetXc58E3,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if not nDW2R03IQ1lPKxwdLiS: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	n0hS54zaxWXPjZHyG3iq,ql3pMChUxOrE1bsmLXnNKQ0Haw = nDW2R03IQ1lPKxwdLiS[f4fTutDOEwUeIoPLRQ],ZZBH70rGPWXq9fCThR(nDW2R03IQ1lPKxwdLiS[f4fTutDOEwUeIoPLRQ])
	return n0hS54zaxWXPjZHyG3iq,ql3pMChUxOrE1bsmLXnNKQ0Haw
def xDsF5vGV0J39gAjM():
	uusKkvRAfwzo = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡨ࡮ࡩࡴࠨ࿑"),bYyKEjIuGQzoq3AR1(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧ࿒"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡇࡌࡍࡡࡄࡈࡉࡕࡎࡔࡡ࡛ࡑࡑ࠭࿓"))
	if uusKkvRAfwzo: return uusKkvRAfwzo
	qqKcFILbhsVY,uusKkvRAfwzo = {},{}
	pLhwC75ZXF0WgyDE = [sCSyOla9hrcE[YayJj10OGl(u"࠭ࡒࡆࡒࡒࡗࠬ࿔")][f4fTutDOEwUeIoPLRQ]]
	if o8MCS3IzmRXdVDB7xg2eiW5baZUn>usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠲࠹࠱࠽࠾ᑙ"): pLhwC75ZXF0WgyDE.append(sCSyOla9hrcE[qrjy8LuKVPNYdbSvzh(u"ࠧࡓࡇࡓࡓࡘ࠭࿕")][vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	if IZhXMprxvAHqBEFkg0: pLhwC75ZXF0WgyDE.append(sCSyOla9hrcE[ulAxHwvzR9eTb5n(u"ࠨࡔࡈࡔࡔ࡙ࠧ࿖")][QQSugEIn2mTCpRsfcaJHhPdAWzylM])
	for DqSrHxEI59dNMKU3hzvgRluYQowjn in pLhwC75ZXF0WgyDE:
		cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡊࡉ࡙࠭࿗"),DqSrHxEI59dNMKU3hzvgRluYQowjn,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡗࡋࡁࡅࡡࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎ࠰࠵ࡸࡺࠧ࿘"))
		if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
			B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
			t27ATkWyKvV08iQLmdGUp = DqSrHxEI59dNMKU3hzvgRluYQowjn.rsplit(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫ࠴࠭࿙"),flDSRbv57PnV3(u"࠳ᑚ"))[f4fTutDOEwUeIoPLRQ]
			DNuzw7ICtirqHfO2GL1WpY6 = ScntgdOZCY74vNpXeW5jh8i.findall(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬ࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࿚"),B69RXYW5vf8Jt7O,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
			for ldJmEsIZY9A4pXStekwNoTV,jG1aHImP5Mnly9zUQF7Lrg43twk in DNuzw7ICtirqHfO2GL1WpY6:
				JHVu1vCQiZ5EBMnTKgkq9jXR = t27ATkWyKvV08iQLmdGUp+l4DS8mnEjHhFMZ5YOe(u"࠭࠯ࠨ࿛")+ldJmEsIZY9A4pXStekwNoTV+UpQ56M0dO1N9xIvVegy(u"ࠧ࠰ࠩ࿜")+ldJmEsIZY9A4pXStekwNoTV+QlTuvPbSpnjygBVW(u"ࠨ࠯ࠪ࿝")+jG1aHImP5Mnly9zUQF7Lrg43twk+X1mRwt2YJKgCLu9a67(u"ࠩ࠱ࡾ࡮ࡶࠧ࿞")
				if ldJmEsIZY9A4pXStekwNoTV not in list(qqKcFILbhsVY.keys()):
					qqKcFILbhsVY[ldJmEsIZY9A4pXStekwNoTV] = []
					uusKkvRAfwzo[ldJmEsIZY9A4pXStekwNoTV] = []
				AaHFtWeZXJI = ZZBH70rGPWXq9fCThR(jG1aHImP5Mnly9zUQF7Lrg43twk)
				qqKcFILbhsVY[ldJmEsIZY9A4pXStekwNoTV].append((jG1aHImP5Mnly9zUQF7Lrg43twk,AaHFtWeZXJI,JHVu1vCQiZ5EBMnTKgkq9jXR))
	for ldJmEsIZY9A4pXStekwNoTV in list(qqKcFILbhsVY.keys()):
		uusKkvRAfwzo[ldJmEsIZY9A4pXStekwNoTV] = sorted(qqKcFILbhsVY[ldJmEsIZY9A4pXStekwNoTV],reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: key[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,YayJj10OGl(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭࿟"),I3cxjYaHhsrM7T4UX26klN(u"ࠫࡆࡒࡌࡠࡃࡇࡈࡔࡔࡓࡠ࡚ࡐࡐࠬ࿠"),uusKkvRAfwzo,RRYx6sACloVPr3td95Ej)
	return uusKkvRAfwzo
def ZZBH70rGPWXq9fCThR(jG1aHImP5Mnly9zUQF7Lrg43twk):
	AaHFtWeZXJI = []
	Mvq45Ece0DIhpuS8LAxinWotTj = jG1aHImP5Mnly9zUQF7Lrg43twk.split(X1mRwt2YJKgCLu9a67(u"ࠬ࠴ࠧ࿡"))
	for y149aXxcSFj67tKvQTZ3WMrA in Mvq45Ece0DIhpuS8LAxinWotTj:
		tthOzV7absYioHcFMRCUwSJGArl = ScntgdOZCY74vNpXeW5jh8i.findall(SSvu1CZjTW7FcloNqD(u"࠭࡜ࡥ࠭ࡿ࡟ࡡ࠱࡜࠮ࡣ࠰ࡾࡆ࠳࡚࡞࠭ࠪ࿢"),y149aXxcSFj67tKvQTZ3WMrA,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		oIlKXyJUTg = []
		for zLuKOUqpVFdsgx4AhXklwH3Jc in tthOzV7absYioHcFMRCUwSJGArl:
			if zLuKOUqpVFdsgx4AhXklwH3Jc.isdigit(): zLuKOUqpVFdsgx4AhXklwH3Jc = int(zLuKOUqpVFdsgx4AhXklwH3Jc)
			oIlKXyJUTg.append(zLuKOUqpVFdsgx4AhXklwH3Jc)
		AaHFtWeZXJI.append(oIlKXyJUTg)
	return AaHFtWeZXJI
def F0EG6XvIMVO(AaHFtWeZXJI):
	jG1aHImP5Mnly9zUQF7Lrg43twk = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for y149aXxcSFj67tKvQTZ3WMrA in AaHFtWeZXJI:
		for zLuKOUqpVFdsgx4AhXklwH3Jc in y149aXxcSFj67tKvQTZ3WMrA: jG1aHImP5Mnly9zUQF7Lrg43twk += str(zLuKOUqpVFdsgx4AhXklwH3Jc)
		jG1aHImP5Mnly9zUQF7Lrg43twk += xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧ࠯ࠩ࿣")
	jG1aHImP5Mnly9zUQF7Lrg43twk = jG1aHImP5Mnly9zUQF7Lrg43twk.strip(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࠰ࠪ࿤"))
	return jG1aHImP5Mnly9zUQF7Lrg43twk
def wQ5nCz7RXvZJ(CCcLZqdnhFeisHmW):
	QCkFNzuGpZwqEmb = {}
	qqKcFILbhsVY = xDsF5vGV0J39gAjM()
	evkKrGczf3YO1mtqg5NWBhXiZEQoA = Y9Xn2ay8Z1wLx3verlh7iH4(CCcLZqdnhFeisHmW)
	for ldJmEsIZY9A4pXStekwNoTV in CCcLZqdnhFeisHmW:
		if ldJmEsIZY9A4pXStekwNoTV not in list(qqKcFILbhsVY.keys()): continue
		uusKkvRAfwzo = qqKcFILbhsVY[ldJmEsIZY9A4pXStekwNoTV]
		Df4LyUX3OcwgJ,iK8u9vLEpr,ZAUCeIRVlDYQn7 = uusKkvRAfwzo[f4fTutDOEwUeIoPLRQ]
		CmHdP8FiLUv1pR3k04honscZltb,Fcs4aKCzY7mL5QkV = d1IXYVFrneiWly(ldJmEsIZY9A4pXStekwNoTV)
		O29OxcJi3EQIGBNrlaXKg0M6,S4B8eUiF9y7PzcwAG0 = evkKrGczf3YO1mtqg5NWBhXiZEQoA[ldJmEsIZY9A4pXStekwNoTV]
		TT3vSaVpIkx = iK8u9vLEpr>Fcs4aKCzY7mL5QkV and O29OxcJi3EQIGBNrlaXKg0M6
		HD5qTR34VXh79ULoz = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if not O29OxcJi3EQIGBNrlaXKg0M6: jSeZWc8utPX0yYEhbCrUDlB = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡰ࡭ࡸࡹࡩ࡯ࡩࠪ࿥")
		elif not S4B8eUiF9y7PzcwAG0: jSeZWc8utPX0yYEhbCrUDlB = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬ࿦")
		elif TT3vSaVpIkx: jSeZWc8utPX0yYEhbCrUDlB = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡴࡲࡤࠨ࿧")
		else:
			jSeZWc8utPX0yYEhbCrUDlB = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬ࡭࡯ࡰࡦࠪ࿨")
			HD5qTR34VXh79ULoz = SmbNGskjMx
		QCkFNzuGpZwqEmb[ldJmEsIZY9A4pXStekwNoTV] = HD5qTR34VXh79ULoz,CmHdP8FiLUv1pR3k04honscZltb,Fcs4aKCzY7mL5QkV,Df4LyUX3OcwgJ,iK8u9vLEpr,jSeZWc8utPX0yYEhbCrUDlB,ZAUCeIRVlDYQn7
	return QCkFNzuGpZwqEmb
def a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,kdTN0xJGHpzDg5BPyFKcaZqOweUvr,oY3r2yaZx0iw4H=nbOFVEDkpT4BIR7Qq82yPmHeJU,O6EsTrcXeSz89WKhZkuol1IV=nbOFVEDkpT4BIR7Qq82yPmHeJU,XRYkwAoD46paty=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if n7neb9KTv10FcU: kXhEFvVqefGtabMy9z0YlpBi.update(kdTN0xJGHpzDg5BPyFKcaZqOweUvr,oY3r2yaZx0iw4H,O6EsTrcXeSz89WKhZkuol1IV,XRYkwAoD46paty)
	else: kXhEFvVqefGtabMy9z0YlpBi.update(kdTN0xJGHpzDg5BPyFKcaZqOweUvr,oY3r2yaZx0iw4H+wwOnIucWJj+O6EsTrcXeSz89WKhZkuol1IV+wwOnIucWJj+XRYkwAoD46paty)
	return
def oWMSrt64vnzZAJlBmf0Y7cDujLxVsb(LITxrWQFSP):
	def sZGazEIOPtKj2CpnHyFYqML(hxsSV7bXWGEu6OIfMm,LGrjQCh8dyHPJE1oNOp,WQ7m6keZ5JX=bnI4kmPtrW7yFEhljXOCq9(u"ࠨ࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࡘ࡚ࡕࡗ࡙࡛࡝࡟ࠨ࿩")):
		return ((hxsSV7bXWGEu6OIfMm == f4fTutDOEwUeIoPLRQ) and WQ7m6keZ5JX[f4fTutDOEwUeIoPLRQ]) or (sZGazEIOPtKj2CpnHyFYqML(hxsSV7bXWGEu6OIfMm // LGrjQCh8dyHPJE1oNOp, LGrjQCh8dyHPJE1oNOp, WQ7m6keZ5JX).lstrip(WQ7m6keZ5JX[f4fTutDOEwUeIoPLRQ]) + WQ7m6keZ5JX[hxsSV7bXWGEu6OIfMm % LGrjQCh8dyHPJE1oNOp])
	def FnAP8V697034(ZZQU7kgIpFyhNYzo2neqOJ, c6tmKg5E8hnRS4LUArqzZBYCINJT, qPR12SideET5Ljab, LL68RD2hgsKzjmavTctoq3Sdw, Leg3Kr6XvBVh=None, Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6=None, DBZhXlaxAfjOJF3c5Q24kvWuom=None):
		while (qPR12SideET5Ljab):
			qPR12SideET5Ljab-=X60YQOADpkHBb31LiR5qUEKfM(u"࠴ᑛ")
			if (LL68RD2hgsKzjmavTctoq3Sdw[qPR12SideET5Ljab]): ZZQU7kgIpFyhNYzo2neqOJ = ScntgdOZCY74vNpXeW5jh8i.sub(SSvu1CZjTW7FcloNqD(u"ࠢ࡝࡞ࡥࠦ࿪") + sZGazEIOPtKj2CpnHyFYqML(qPR12SideET5Ljab, c6tmKg5E8hnRS4LUArqzZBYCINJT) + t4txivgXSUWBOlCakQmNDjf(u"ࠣ࡞࡟ࡦࠧ࿫"),  LL68RD2hgsKzjmavTctoq3Sdw[qPR12SideET5Ljab], ZZQU7kgIpFyhNYzo2neqOJ)
		return ZZQU7kgIpFyhNYzo2neqOJ
	LITxrWQFSP = LITxrWQFSP.split(z3sIGH8jmLYg(u"ࠩࢀࠬࠬ࿬"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	LITxrWQFSP = LITxrWQFSP.rsplit(ulAxHwvzR9eTb5n(u"ࠪࡷࡵࡲࡩࡵࠩ࿭"))[f4fTutDOEwUeIoPLRQ]+I3cxjYaHhsrM7T4UX26klN(u"ࠦࡸࡶ࡬ࡪࡶࠫࠫࢁ࠭ࠩࠪࠤ࿮")
	zq8hVp3J6dsvUN94FwcEPfLkCtM = eval(Fo1SgXMsHk(u"ࠬࡻ࡮ࡱࡣࡦ࡯࠭࠭࿯")+LITxrWQFSP,{yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡢࡢࡵࡨࡒࠬ࿰"):sZGazEIOPtKj2CpnHyFYqML,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡶࡰࡳࡥࡨࡱࠧ࿱"):FnAP8V697034})
	return zq8hVp3J6dsvUN94FwcEPfLkCtM
def VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(code):
	_oUv39Az4JwVl71HBiZFs=flDSRbv57PnV3(u"ࠣ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠬ࠱ࠥ࿲")
	def tG6gF2nuSEWyTRDBk1XzoaJK7PA(Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6,Leg3Kr6XvBVh,kkze2HKMRdvjftbpl6NGaQ):
		RDYO017zSuXE23rvUxP = list(_oUv39Az4JwVl71HBiZFs)
		FBq5NUxjDaIMgTGcAVb2WOyS = RDYO017zSuXE23rvUxP[X60YQOADpkHBb31LiR5qUEKfM(u"࠴ᑜ"):Leg3Kr6XvBVh]
		WoEZvMXa0K2suwgPl = RDYO017zSuXE23rvUxP[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠵ᑝ"):kkze2HKMRdvjftbpl6NGaQ]
		Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6 = list(Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6)[::-DJ6ugPjW9bX8I(u"࠷ᑞ")]
		PrXa7MsyK0 = X60YQOADpkHBb31LiR5qUEKfM(u"࠰ᑟ")
		for qPR12SideET5Ljab,LGrjQCh8dyHPJE1oNOp in enumerate(Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6):
			if LGrjQCh8dyHPJE1oNOp in FBq5NUxjDaIMgTGcAVb2WOyS: PrXa7MsyK0 = PrXa7MsyK0 + FBq5NUxjDaIMgTGcAVb2WOyS.index(LGrjQCh8dyHPJE1oNOp)*Leg3Kr6XvBVh**qPR12SideET5Ljab
		LL68RD2hgsKzjmavTctoq3Sdw = X1mRwt2YJKgCLu9a67(u"ࠤࠥ࿳")
		while PrXa7MsyK0 > X1mRwt2YJKgCLu9a67(u"࠱ᑠ"):
			LL68RD2hgsKzjmavTctoq3Sdw = WoEZvMXa0K2suwgPl[PrXa7MsyK0%kkze2HKMRdvjftbpl6NGaQ] + LL68RD2hgsKzjmavTctoq3Sdw
			PrXa7MsyK0 = (PrXa7MsyK0 - (PrXa7MsyK0%kkze2HKMRdvjftbpl6NGaQ))//kkze2HKMRdvjftbpl6NGaQ
		return int(LL68RD2hgsKzjmavTctoq3Sdw) or xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠲ᑡ")
	def OKtVBUFej2zd97(FBq5NUxjDaIMgTGcAVb2WOyS,u,xxUSZfA7LmlMz6,H3H6jgOIFR0Vzkure972Bs,Leg3Kr6XvBVh,DBZhXlaxAfjOJF3c5Q24kvWuom):
		DBZhXlaxAfjOJF3c5Q24kvWuom = X1mRwt2YJKgCLu9a67(u"ࠥࠦ࿴");
		WoEZvMXa0K2suwgPl = Fo1SgXMsHk(u"࠳ᑢ")
		while WoEZvMXa0K2suwgPl < len(FBq5NUxjDaIMgTGcAVb2WOyS):
			PrXa7MsyK0 = Fo1SgXMsHk(u"࠴ᑣ")
			u5cjW2qyX6rJpmVoQlLvOx = IINBvuxkCSJrO1Q0UyngdLi(u"ࠦࠧ࿵")
			while FBq5NUxjDaIMgTGcAVb2WOyS[WoEZvMXa0K2suwgPl] is not xxUSZfA7LmlMz6[Leg3Kr6XvBVh]:
				u5cjW2qyX6rJpmVoQlLvOx = flDSRbv57PnV3(u"ࠬ࠭࿶").join([u5cjW2qyX6rJpmVoQlLvOx,FBq5NUxjDaIMgTGcAVb2WOyS[WoEZvMXa0K2suwgPl]])
				WoEZvMXa0K2suwgPl = WoEZvMXa0K2suwgPl + qrjy8LuKVPNYdbSvzh(u"࠶ᑤ")
			while PrXa7MsyK0 < len(xxUSZfA7LmlMz6):
				u5cjW2qyX6rJpmVoQlLvOx = u5cjW2qyX6rJpmVoQlLvOx.replace(xxUSZfA7LmlMz6[PrXa7MsyK0],str(PrXa7MsyK0))
				PrXa7MsyK0 = PrXa7MsyK0 + SSvu1CZjTW7FcloNqD(u"࠷ᑥ")
			DBZhXlaxAfjOJF3c5Q24kvWuom = X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࠧ࿷").join([DBZhXlaxAfjOJF3c5Q24kvWuom,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࠨ࿸").join(map(chr, [tG6gF2nuSEWyTRDBk1XzoaJK7PA(u5cjW2qyX6rJpmVoQlLvOx,Leg3Kr6XvBVh,cb3rmvAn4wa6lBPz2phOoYqX(u"࠱࠱ᑦ")) - H3H6jgOIFR0Vzkure972Bs]))])
			WoEZvMXa0K2suwgPl = WoEZvMXa0K2suwgPl + cb3rmvAn4wa6lBPz2phOoYqX(u"࠲ᑧ")
		return DBZhXlaxAfjOJF3c5Q24kvWuom
	code = code.replace(I3cxjYaHhsrM7T4UX26klN(u"ࠨ࡞ࡱࠫ࿹"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࠪ࿺")).replace(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡠࡷ࠭࿻"),UpQ56M0dO1N9xIvVegy(u"ࠫࠬ࿼"))
	ayTcxJ2tFn4jNowuI = ScntgdOZCY74vNpXeW5jh8i.findall(QlTuvPbSpnjygBVW(u"ࠬࡢࡽ࡝ࠪࠥࠬࡡࡽࠫࠪࠤ࠯ࠬࡡࡪࠫࠪ࠮ࠥࠬࡡࡽࠫࠪࠤ࠯ࠬࡡࡪࠫࠪ࠮ࠫࡠࡩ࠱ࠩ࠭ࠪ࡟ࡨ࠰࠯࡜ࠪ࡞ࠬࠫ࿽"),code,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if ayTcxJ2tFn4jNowuI:
		ayTcxJ2tFn4jNowuI = list(ayTcxJ2tFn4jNowuI[q4izXt0sjIQSZcHVAf3EmKRbx(u"࠲ᑨ")])
		for JfDYHtkqBMPz3Znl4,code in enumerate(ayTcxJ2tFn4jNowuI):
			if code.isdigit(): ayTcxJ2tFn4jNowuI[JfDYHtkqBMPz3Znl4] = int(code)
			else: ayTcxJ2tFn4jNowuI[JfDYHtkqBMPz3Znl4] = code.replace(q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭࡜ࠣࠩ࿾"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࠨ࿿"))
		AlrxcmqPCHVdN59tRgWUGF0IT = OKtVBUFej2zd97(*ayTcxJ2tFn4jNowuI)
		return AlrxcmqPCHVdN59tRgWUGF0IT
	return xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࠩက")
def fjRSh4O5u0BI(qxZiT6WJ7sX,kKOmyPCAFXNSw2MDYvhd=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if kKOmyPCAFXNSw2MDYvhd==ulAxHwvzR9eTb5n(u"ࠩ࡯ࡳࡼ࡫ࡲࠨခ"): qxZiT6WJ7sX = ScntgdOZCY74vNpXeW5jh8i.sub(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࡵࠫࠪࡡ࠰࠮࠻ࡄ࠱࡟ࡣࡻ࠳ࡿࠪဂ"),lambda GDQhBRUOaxfYNuZ: GDQhBRUOaxfYNuZ.group(f4fTutDOEwUeIoPLRQ).lower(),qxZiT6WJ7sX)
	elif kKOmyPCAFXNSw2MDYvhd==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡺࡶࡰࡦࡴࠪဃ"): qxZiT6WJ7sX = ScntgdOZCY74vNpXeW5jh8i.sub(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࡷ࠭ࠥ࡜࠲࠰࠽ࡦ࠳ࡺ࡞ࡽ࠵ࢁࠬင"),lambda GDQhBRUOaxfYNuZ: GDQhBRUOaxfYNuZ.group(f4fTutDOEwUeIoPLRQ).upper(),qxZiT6WJ7sX)
	return qxZiT6WJ7sX
def Y9Xn2ay8Z1wLx3verlh7iH4(CCcLZqdnhFeisHmW):
	boSy7iaAusXnEVOMj3BlKevgH1C0,eYvNqFMwxLgKb = SmbNGskjMx,SmbNGskjMx
	IgtL0mb7hnwEpYyuf6KUxXR = RhNFgjDTM1Zuakqx4K925EiLoAHUcz.connect(zZ9tVvyojlWYupgSJxDImHdLsUFTNq)
	IgtL0mb7hnwEpYyuf6KUxXR.text_factory = str
	yWESdJ2nUj31M8ONktxl4 = IgtL0mb7hnwEpYyuf6KUxXR.cursor()
	if len(CCcLZqdnhFeisHmW)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: AAyKQze6gmbYEdCSHOr = Fo1SgXMsHk(u"࠭ࠨࠣࠩစ")+CCcLZqdnhFeisHmW[f4fTutDOEwUeIoPLRQ]+flDSRbv57PnV3(u"ࠧࠣࠫࠪဆ")
	else: AAyKQze6gmbYEdCSHOr = str(tuple(CCcLZqdnhFeisHmW))
	yWESdJ2nUj31M8ONktxl4.execute(X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡣࡧࡨࡴࡴࡉࡅ࠮ࡨࡲࡦࡨ࡬ࡦࡦࠣࡊࡗࡕࡍࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠤ࡜ࡎࡅࡓࡇࠣࡥࡩࡪ࡯࡯ࡋࡇࠤࡎࡔࠠࠨဇ")+AAyKQze6gmbYEdCSHOr+DJ6ugPjW9bX8I(u"ࠩࠣ࠿ࠬဈ"))
	vDimntp752hHxBRQSX = yWESdJ2nUj31M8ONktxl4.fetchall()
	evkKrGczf3YO1mtqg5NWBhXiZEQoA = {}
	for ldJmEsIZY9A4pXStekwNoTV in CCcLZqdnhFeisHmW: evkKrGczf3YO1mtqg5NWBhXiZEQoA[ldJmEsIZY9A4pXStekwNoTV] = (SmbNGskjMx,SmbNGskjMx)
	for ldJmEsIZY9A4pXStekwNoTV,eYvNqFMwxLgKb in vDimntp752hHxBRQSX:
		boSy7iaAusXnEVOMj3BlKevgH1C0 = Ag9l6cw3EBqP8HsQuGMizfOtr4
		eYvNqFMwxLgKb = eYvNqFMwxLgKb==vkIa3ijEQVsJGdWOXwK7bnue9ADR
		evkKrGczf3YO1mtqg5NWBhXiZEQoA[ldJmEsIZY9A4pXStekwNoTV] = (boSy7iaAusXnEVOMj3BlKevgH1C0,eYvNqFMwxLgKb)
	IgtL0mb7hnwEpYyuf6KUxXR.close()
	return evkKrGczf3YO1mtqg5NWBhXiZEQoA
def LjfICzo9TkNMZ1PSaFW5vl3b0(jjdUcJoK8fm1pbrS):
	bPFto2wZdNYrClgBIEv60DJAzu = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(jjdUcJoK8fm1pbrS):
		LzODVY2ASrsdEQMbIm = open(jjdUcJoK8fm1pbrS,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡶࡧ࠭ဉ")).read()
		if IZhXMprxvAHqBEFkg0: LzODVY2ASrsdEQMbIm = LzODVY2ASrsdEQMbIm.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		JJCL7cAm8WkMRl = dr1zfnatJxRHSF48jh0eODm5bGu(IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡩ࡯ࡣࡵࠩည"),LzODVY2ASrsdEQMbIm)
		if JJCL7cAm8WkMRl:
			bPFto2wZdNYrClgBIEv60DJAzu = {}
			for SRoElDIz1e9Vu in JJCL7cAm8WkMRl.keys():
				bPFto2wZdNYrClgBIEv60DJAzu[SRoElDIz1e9Vu] = []
				for Xd6an5CeRhMPDvEkzSpslrT8gAmiK in JJCL7cAm8WkMRl[SRoElDIz1e9Vu]:
					vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
					vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[f4fTutDOEwUeIoPLRQ]
					hXFjqduwKEt2TDC = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
					hXFjqduwKEt2TDC = d7Pcqxem9LyM6WEiIpv(hXFjqduwKEt2TDC)
					qxZiT6WJ7sX = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
					xv42oTYCQusGHzjMc3n01Zq = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
					nnu5vdh1IscOA8J = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[WtDrnpJmwQ37Z2Ae68hu4BY5M1]
					ohpwd6UumaecE3IWV8lAv0 = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠸ᑩ")]
					if len(Xd6an5CeRhMPDvEkzSpslrT8gAmiK)>I3cxjYaHhsrM7T4UX26klN(u"࠺ᑪ"): om2lqtcZ5y4j = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[I3cxjYaHhsrM7T4UX26klN(u"࠺ᑪ")]
					if len(Xd6an5CeRhMPDvEkzSpslrT8gAmiK)>ulAxHwvzR9eTb5n(u"࠼ᑫ"): p8pRVmk1Jg03PjfMonTFyvLCax = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[ulAxHwvzR9eTb5n(u"࠼ᑫ")]
					if len(Xd6an5CeRhMPDvEkzSpslrT8gAmiK)>bYyKEjIuGQzoq3AR1(u"࠾ᑬ"): Nyb1swDcFkeGUdMEnh9itZ = Xd6an5CeRhMPDvEkzSpslrT8gAmiK[bYyKEjIuGQzoq3AR1(u"࠾ᑬ")]
					if jjdUcJoK8fm1pbrS==g8FzaRfU7Zx9HeSBNtJ: G6SBnmk7wTAKbZ5YdILvhM1 = vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,nbOFVEDkpT4BIR7Qq82yPmHeJU,Nyb1swDcFkeGUdMEnh9itZ
					else: G6SBnmk7wTAKbZ5YdILvhM1 = vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ
					bPFto2wZdNYrClgBIEv60DJAzu[SRoElDIz1e9Vu].append(G6SBnmk7wTAKbZ5YdILvhM1)
		wj9t5hBfkEVUd = str(bPFto2wZdNYrClgBIEv60DJAzu)
		if IZhXMprxvAHqBEFkg0: wj9t5hBfkEVUd = wj9t5hBfkEVUd.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open(jjdUcJoK8fm1pbrS,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡽࡢࠨဋ")).write(wj9t5hBfkEVUd)
	return bPFto2wZdNYrClgBIEv60DJAzu
def E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER):
	rGF7ZwyHnBSxcQepX5P = HMPtOcVoJiXCu8z0nesDWYkIl9ER.split(bnI4kmPtrW7yFEhljXOCq9(u"࠭࠭ࠨဌ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
	UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if   rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"ࠧࡂࡊ࡚ࡅࡐ࠭ဍ")		:	from k1ktzYv3H8			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==QlTuvPbSpnjygBVW(u"ࠨࡃࡎࡓࡆࡓࠧဎ")		:	from Pl9syVGTF0			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==UpQ56M0dO1N9xIvVegy(u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫဏ")	:	from NC5BwOzQK0		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡅࡐ࡝ࡁࡎࠩတ")		:	from Hn1ehdUPB2			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡆࡑࡗࡂࡏࡗ࡙ࡇࡋࠧထ")	:	from A9pml3Qkxv		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡇࡌࡂࡔࡄࡆࠬဒ")	:	from ccvSIPmxgW			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨဓ")	:	from Ftp6bAeKPu		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==t4txivgXSUWBOlCakQmNDjf(u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔࠪန")	: 	from l5QuNeS31A		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪပ")	:	from hjYJ5cngVB		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==SSvu1CZjTW7FcloNqD(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪဖ")	:	from HHs8Sbglyo		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡅࡓࡏࡍࡆ࡜ࡌࡈࠬဗ")	:	from BPecgpzADO		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡆࡘࡁࡃࡋࡆࡘࡔࡕࡎࡔࠩဘ"):	from UVzJMx3sLg	import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==ulAxHwvzR9eTb5n(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧမ")	:	from cczNkUM8e6		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==UpQ56M0dO1N9xIvVegy(u"࠭ࡁ࡚ࡎࡒࡐࠬယ")		:	from FjfEaWPULS			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡃࡑࡎࡖࡆ࠭ရ")		:	from FO9Pcsk5Xz			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==QlTuvPbSpnjygBVW(u"ࠨࡄࡕࡗ࡙ࡋࡊࠨလ")	:	from xpvHg7OTXf			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"ࠩࡆࡍࡒࡇ࠴࠱࠲ࠪဝ")	:	from RfNHdv4g16		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡇࡎࡓࡁ࠵ࡒࠪသ")	:	from gIShpZ2xam			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==UpQ56M0dO1N9xIvVegy(u"ࠫࡈࡏࡍࡂ࠶ࡘࠫဟ")	:	from ddhk8UY93x			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡉࡉࡎࡃࡄࡆࡉࡕࠧဠ")	:	from TTfGtcnHWg		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==tM24jD1gO0(u"࠭ࡃࡊࡏࡄࡇࡑ࡛ࡂࠨအ")	:	from hXfZLEF01s		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fgv5U2eRVaQqSiuGD(u"ࠧࡄࡋࡐࡅࡈࡒࡕࡃ࡙ࡒࡖࡐ࠭ဢ"):	from fLXsKkaCtv	import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡒࠪဣ")	:	from aXsbM5p7he		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==ulAxHwvzR9eTb5n(u"ࠩࡆࡍࡒࡇࡆࡂࡐࡖࠫဤ")	:	from YHdQMbUxS9		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==l4DS8mnEjHhFMZ5YOe(u"ࠪࡇࡎࡓࡁࡇࡔࡈࡉࠬဥ")	:	from FgxXCuKmjD		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==Fo1SgXMsHk(u"ࠫࡈࡏࡍࡂࡎࡌࡋࡍ࡚ࠧဦ")	:	from eCcV9bE5Xv		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==bYyKEjIuGQzoq3AR1(u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ဧ")	:	from nIEpzfZOeA		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡃࡊࡏࡄ࡛ࡇࡇࡓࠨဨ")	:	from XaJItuHFfp		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬဩ"):	from d7aRis2qhk	import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡆࡕࡅࡒࡇࡃࡂࡈࡈࠫဪ")	:	from HRDks6JM5E		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡇࡖࡆࡓࡁࡔ࠹ࠪါ")	:	from IxG4zq92Yi		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫာ")	:	from haJBXMtW9Y		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ိ")	:	from O6kUi5MdYE		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࠸ࠧီ")	:	from dt8zS4wDlp		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚࠳ࠨု")	:	from Njvc8kFO4M		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==t4txivgXSUWBOlCakQmNDjf(u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔ࠵ࠩူ")	:	from IcsWHablxw		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡇࡊ࡝ࡉࡋࡁࡅࠩေ")	:	from wsFPH620Aj		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"ࠩࡈࡋ࡞ࡔࡏࡘࠩဲ")	:	from K8bGaEqlm7			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡉࡑࡉࡉࡏࡇࡐࡅࠬဳ")	:	from SiCDoLXH6M		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==DJ6ugPjW9bX8I(u"ࠫࡊࡒࡉࡇࡘࡌࡈࡊࡕࠧဴ")	:	from LLJYZsrlXm		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"ࠬࡌࡁࡃࡔࡄࡏࡆ࠭ဵ")	:	from ZQYi1DaW6c		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩံ")	:	from WVBqhxkTJo		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡇࡃࡕࡉࡘࡑࡏࠨ့")	:	from l5WCgAFxHq		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==QlTuvPbSpnjygBVW(u"ࠨࡈࡄࡗࡊࡒࡈࡅ࠳ࠪး")	:	from STvH5VK2LM		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fgv5U2eRVaQqSiuGD(u"ࠩࡉࡅࡘࡋࡌࡉࡆ࠵္ࠫ")	:	from zpPiFvoSsY		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==tM24jD1gO0(u"ࠪࡊࡔ࡙ࡔࡂ်ࠩ")		:	from uu03lAibVf			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==YayJj10OGl(u"ࠫࡋ࡛ࡎࡐࡐࡗ࡚ࠬျ")	:	from U7zP2CIs3p		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==DJ6ugPjW9bX8I(u"ࠬࡌࡕࡔࡊࡄࡖ࡙࡜ࠧြ")	:	from zECDyiN8cF		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fgv5U2eRVaQqSiuGD(u"࠭ࡆࡖࡕࡋࡅࡗ࡜ࡉࡅࡇࡒࠫွ"):	from nXRDE6wr72	import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡈࡑࡒࡋࡑࡋࡓࡆࡃࡕࡇࡍ࠭ှ"):	from xUG0JazuM7	import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃࠪဿ")	:	from bVgMzdZK7e		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡌࡊࡎࡒࡍࠨ၀")		:	from sAqTFayKmW			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"ࠪࡍࡕ࡚ࡖࠨ၁")		:	from FFiPRp8szx			import hraw5mCZRvLQxX1iH as UGqCc4PebSEBwON07ZpuF,CCLlhnQdcKiA as Nwj2WURK7qbY6coiBdMDzuS,PPZDQo6RAG3a0Ot1Ydc5Fwz as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==YayJj10OGl(u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧ၂")	:	from yitX6wlQ4H		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"ࠬࡑࡁࡕࡍࡒࡘ࡙࡜ࠧ၃")	:	from EfAJioaxd9		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==ulAxHwvzR9eTb5n(u"࠭ࡋࡂࡖࡎࡓ࡚࡚ࡅࠨ၄")	:	from bjdzha45nm		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==z3sIGH8jmLYg(u"ࠧࡌࡋࡕࡑࡆࡒࡋࠨ၅")	:	from usfqYpW9IU		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==SSvu1CZjTW7FcloNqD(u"ࠨࡎࡄࡖࡔࡠࡁࠨ၆")	:	from rxPoLEUGuR			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡏࡓࡉ࡟ࡎࡆࡖࠪ၇")	:	from UpMWqXALaE		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==tM24jD1gO0(u"ࠪࡑ࠸࡛ࠧ၈")		:	from EEdIMHGg4C			import hraw5mCZRvLQxX1iH as UGqCc4PebSEBwON07ZpuF,CCLlhnQdcKiA as Nwj2WURK7qbY6coiBdMDzuS,PPZDQo6RAG3a0Ot1Ydc5Fwz as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡒࡇࡓࡂࡘࡌࡈࡊࡕࠧ၉")	:	from pu8iReDhBs		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡓࡏࡗࡕ࠷࡙ࠬ၊")	:	from kDOBzqPZK3			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭။")	:	from mJhnvlc9Rr			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡑࡃࡑࡉ࡙࠭၌")		:	from q4jPZGfbsQ			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==z3sIGH8jmLYg(u"ࠨࡓࡉࡍࡑࡓࠧ၍")		:	from EDIPjT1y0b			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡖࡉࡗࡏࡅࡔࡖࡌࡑࡊ࠭၎"):	from xkUrXP4pzH		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡗࡍࡇࡂࡂࡍࡄࡘ࡞࠭၏")	:	from sLgUQ9jwV5		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭ၐ")	:	from v1skFBGlrX		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࡙ࠬࡈࡂࡊࡌࡈࡓࡋࡗࡔࠩၑ"):	from jex85kwigp		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==qrjy8LuKVPNYdbSvzh(u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩၒ")	:	from Gna4eLcofr		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡔࡊࡒࡊࡍࡇࠧၓ")	:	from S5S2A0HuKB			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪၔ")	:	from CMxWve5LZA		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡖࡌࡔࡕࡆࡏࡇࡗࠫၕ")	:	from yz4Xr08SJb		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡗࡍࡕࡏࡇࡒࡕࡓࠬၖ")	:	from vfJn9cWZFU		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࡙ࠫࡏࡋࡂࡃࡗࠫၗ")	:	from ruASsnwQOE			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࡚ࠬࡖࡇࡗࡑࠫၘ")		:	from JfVHmqYKhQ			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==t4txivgXSUWBOlCakQmNDjf(u"࠭ࡔࡗࡈࡘࡒࠬၙ")		:	from JfVHmqYKhQ			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==QlTuvPbSpnjygBVW(u"ࠧࡗࡃࡕࡆࡔࡔࠧၚ")	:	from NLytcHfudP			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡘࡌࡈࡊࡕࡎࡔࡃࡈࡑࠬၛ"):	from bX2UYRVk06		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==q4izXt0sjIQSZcHVAf3EmKRbx(u"࡚ࠩࡉࡈࡏࡍࡂ࠳ࠪၜ")	:	from WFjdaCvr19		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==cb3rmvAn4wa6lBPz2phOoYqX(u"࡛ࠪࡊࡉࡉࡎࡃ࠵ࠫၝ")	:	from CXPRLeTGkJ		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==l4DS8mnEjHhFMZ5YOe(u"ࠫ࡞ࡇࡑࡐࡖࠪၞ")		:	from T5WmUMzDlV			import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==YayJj10OGl(u"ࠬ࡟ࡏࡖࡖࡘࡆࡊ࠭ၟ")	:	from VtJMTRCpWz		import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,cvZoNw4F0fRjYaMuP5CVrE as Nwj2WURK7qbY6coiBdMDzuS,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	elif rGF7ZwyHnBSxcQepX5P==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࡙࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬၠ"):	from V3LyopAcbw	import kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0 as UGqCc4PebSEBwON07ZpuF,TbufdXZL9Ml72WmGcpQ5FAgBYKqa as fxUgL78lj13rQ4W6wZOE
	return UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE
def OZq0bRFsaGe98NJxmW6tPiv(XibJtaWNpM84LHTURBZjFr0dgA,ehWfDEbAtMTZaS5x,showDialogs):
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧ࠻ࠢ࡞ࠤࠬၡ")+XibJtaWNpM84LHTURBZjFr0dgA+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫၢ")+str(ehWfDEbAtMTZaS5x)+bnI4kmPtrW7yFEhljXOCq9(u"ࠩࠣࡡࠬၣ"))
	kXhEFvVqefGtabMy9z0YlpBi = LMSZwD0IRAziTh()
	kXhEFvVqefGtabMy9z0YlpBi.create(tM24jD1gO0(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ၤ"),I3cxjYaHhsrM7T4UX26klN(u"ࠫ๏าั๋ࠢส่ว์ࠠโฯุࠤฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤํฮูะ้สࠤุ๎แࠡฬหำศูࠦๆๆํอࠥาไษࠢส่๊๊แࠡ็้ࠤฬ๊ล็ฬิ๊ฯ࠭ၥ"))
	L9iyPRtCwK4DUmJYBsE = DJ6ugPjW9bX8I(u"࠱࠱࠴࠷ᑭ")*DJ6ugPjW9bX8I(u"࠱࠱࠴࠷ᑭ")
	BHTQzdowKE6XJmkqG8Ft9CaZuv = ulAxHwvzR9eTb5n(u"࠲ᑮ")*L9iyPRtCwK4DUmJYBsE
	import requests as SiB7OvlwTJKzdEorLDefAGHF
	cA6C7PMTuUklQdfoYqZgXj2FrJN = SiB7OvlwTJKzdEorLDefAGHF.get(XibJtaWNpM84LHTURBZjFr0dgA,stream=Ag9l6cw3EBqP8HsQuGMizfOtr4,headers=ehWfDEbAtMTZaS5x)
	g6DL8mlYtd0CKUweR3Bi9x = cA6C7PMTuUklQdfoYqZgXj2FrJN.headers
	cA6C7PMTuUklQdfoYqZgXj2FrJN.close()
	hSnzq03pfjs2Mrco = bytes()
	if not g6DL8mlYtd0CKUweR3Bi9x:
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,I3cxjYaHhsrM7T4UX26klN(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨၦ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭วๅสิ๊ฬ๋ฬࠡๆ่ࠤ๏ะๅไ่้๋ࠣࠦสฮ็ํ่ࠥอไๆๆไࠤฬ๊ๅุๆ๋ฬࠥ๎วๅีหฬ่ࠥฯࠡ์ๆ์ู๋ࠦ็ัๆࠤฺ๊ใๅหࠣๅ๏ࠦวๅว้ฮึ์สࠡษ็าฬ฻ࠠษๅࠣ࠲ࠥาัษࠢอั๊๐ไࠡษ็้้็ࠠๆำฬࠤศิั๊ࠩၧ"))
		kXhEFvVqefGtabMy9z0YlpBi.close()
	else:
		if YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨၨ") not in list(g6DL8mlYtd0CKUweR3Bi9x.keys()): EIqKcrsB0y9lxg1mte = f4fTutDOEwUeIoPLRQ
		else: EIqKcrsB0y9lxg1mte = int(g6DL8mlYtd0CKUweR3Bi9x[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡏࡩࡳ࡭ࡴࡩࠩၩ")])
		hnr8Rsl7iIbeLjYwPJBGS = str(int(Fo1SgXMsHk(u"࠴࠴࠵࠶ᑰ")*EIqKcrsB0y9lxg1mte/L9iyPRtCwK4DUmJYBsE)/fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠳࠳࠴࠵࠴࠰ᑯ"))
		kkDsjSHALX = int(EIqKcrsB0y9lxg1mte/BHTQzdowKE6XJmkqG8Ft9CaZuv)+vkIa3ijEQVsJGdWOXwK7bnue9ADR
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡖࡦࡴࡧࡦࠩၪ") in list(g6DL8mlYtd0CKUweR3Bi9x.keys()) and EIqKcrsB0y9lxg1mte>L9iyPRtCwK4DUmJYBsE:
			uje9i4UWNHKI = Ag9l6cw3EBqP8HsQuGMizfOtr4
			h9L3lIV4rzN1vRsZYFxTt = []
			npGICJRHjQcVlK4FvmbPw6M0h = SSvu1CZjTW7FcloNqD(u"࠵࠵ᑱ")
			h9L3lIV4rzN1vRsZYFxTt.append(str(f4fTutDOEwUeIoPLRQ*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࠱ࠬၫ")+str(vkIa3ijEQVsJGdWOXwK7bnue9ADR*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(vkIa3ijEQVsJGdWOXwK7bnue9ADR*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫ࠲࠭ၬ")+str(QQSugEIn2mTCpRsfcaJHhPdAWzylM*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(QQSugEIn2mTCpRsfcaJHhPdAWzylM*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+QlTuvPbSpnjygBVW(u"ࠬ࠳ࠧၭ")+str(ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+X60YQOADpkHBb31LiR5qUEKfM(u"࠭࠭ࠨၮ")+str(WtDrnpJmwQ37Z2Ae68hu4BY5M1*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(WtDrnpJmwQ37Z2Ae68hu4BY5M1*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+z3sIGH8jmLYg(u"ࠧ࠮ࠩၯ")+str(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠺ᑲ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠻ᑳ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨ࠯ࠪၰ")+str(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠶ᑴ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(YayJj10OGl(u"࠸ᑶ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࠰ࠫၱ")+str(z3sIGH8jmLYg(u"࠸ᑵ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(YayJj10OGl(u"࠻ᑸ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+bYyKEjIuGQzoq3AR1(u"ࠪ࠱ࠬၲ")+str(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠻ᑷ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(l4DS8mnEjHhFMZ5YOe(u"࠾ᑺ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࠲࠭ၳ")+str(flDSRbv57PnV3(u"࠾ᑹ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h-vkIa3ijEQVsJGdWOXwK7bnue9ADR))
			h9L3lIV4rzN1vRsZYFxTt.append(str(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠹ᑻ")*EIqKcrsB0y9lxg1mte//npGICJRHjQcVlK4FvmbPw6M0h)+ulAxHwvzR9eTb5n(u"ࠬ࠳ࠧၴ"))
			mcn8ibqB0WrZVuE = float(kkDsjSHALX)/npGICJRHjQcVlK4FvmbPw6M0h
			fFOqPAinUBlT = mcn8ibqB0WrZVuE/int(vkIa3ijEQVsJGdWOXwK7bnue9ADR+mcn8ibqB0WrZVuE)
		else:
			uje9i4UWNHKI = SmbNGskjMx
			npGICJRHjQcVlK4FvmbPw6M0h = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			fFOqPAinUBlT = vkIa3ijEQVsJGdWOXwK7bnue9ADR
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,DJ6ugPjW9bX8I(u"࠭࠮࡝ࡶࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡺࡹࡩ࡯ࡩࠣࡶࡦࡴࡧࡦࡵ࠽ࠤࡠࠦࠧၵ")+str(uje9i4UWNHKI)+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࠡ࡟ࠣࠤࠥࡊ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡴ࡫ࡽࡩ࠿࡛ࠦࠡࠩၶ")+str(EIqKcrsB0y9lxg1mte)+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࠢࡠࠫၷ"))
		HT4fGXqv8hEcKsJ,bk71whGBrcMJdA9UFlx4W5Ryo = f4fTutDOEwUeIoPLRQ,f4fTutDOEwUeIoPLRQ
		for E8gJu2VxcoqW in range(npGICJRHjQcVlK4FvmbPw6M0h):
			GcYwHSWoQ0Nq8KFfJDdvujZryM = ehWfDEbAtMTZaS5x.copy()
			if uje9i4UWNHKI: GcYwHSWoQ0Nq8KFfJDdvujZryM[I3cxjYaHhsrM7T4UX26klN(u"ࠩࡕࡥࡳ࡭ࡥࠨၸ")] = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡦࡾࡺࡥࡴ࠿ࠪၹ")+h9L3lIV4rzN1vRsZYFxTt[E8gJu2VxcoqW]
			cA6C7PMTuUklQdfoYqZgXj2FrJN = SiB7OvlwTJKzdEorLDefAGHF.get(XibJtaWNpM84LHTURBZjFr0dgA,stream=Ag9l6cw3EBqP8HsQuGMizfOtr4,headers=GcYwHSWoQ0Nq8KFfJDdvujZryM,timeout=cb3rmvAn4wa6lBPz2phOoYqX(u"࠴࠲࠳ᑼ"))
			for rwSuJ5ncTs3EBjWyxq1HNADQ9 in cA6C7PMTuUklQdfoYqZgXj2FrJN.iter_content(chunk_size=BHTQzdowKE6XJmkqG8Ft9CaZuv):
				if kXhEFvVqefGtabMy9z0YlpBi.iscanceled():
					fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,tM24jD1gO0(u"ࠫ࠳ࡢࡴࡅࡱࡺࡲࡱࡵࡡࡥࠢࡆࡥࡳࡩࡥ࡭ࡧࡧࠫၺ"))
					break
				HT4fGXqv8hEcKsJ += fFOqPAinUBlT
				hSnzq03pfjs2Mrco += rwSuJ5ncTs3EBjWyxq1HNADQ9
				if not bk71whGBrcMJdA9UFlx4W5Ryo: bk71whGBrcMJdA9UFlx4W5Ryo = len(rwSuJ5ncTs3EBjWyxq1HNADQ9)
				if EIqKcrsB0y9lxg1mte: a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,tM24jD1gO0(u"࠳࠳࠴ᑽ")*HT4fGXqv8hEcKsJ//kkDsjSHALX,tM24jD1gO0(u"ࠬาไษࠢส่๊๊แ࠻࠯ࠣห้าายࠢิๆ๊࠭ၻ"),str(flDSRbv57PnV3(u"࠴࠴࠵࠴࠰ᑾ")*bk71whGBrcMJdA9UFlx4W5Ryo*HT4fGXqv8hEcKsJ//BHTQzdowKE6XJmkqG8Ft9CaZuv//flDSRbv57PnV3(u"࠴࠴࠵࠴࠰ᑾ"))+X1mRwt2YJKgCLu9a67(u"࠭ࠠ࠰ࠢࠪၼ")+hnr8Rsl7iIbeLjYwPJBGS+fgv5U2eRVaQqSiuGD(u"ࠧࠡࡏࡅࠫၽ"))
				else: a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,bk71whGBrcMJdA9UFlx4W5Ryo*HT4fGXqv8hEcKsJ//BHTQzdowKE6XJmkqG8Ft9CaZuv,I3cxjYaHhsrM7T4UX26klN(u"ࠨฮ็ฬࠥอไๆๆไ࠾࠲࠭ၾ"),str(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠵࠵࠶࠮࠱ᑿ")*bk71whGBrcMJdA9UFlx4W5Ryo*HT4fGXqv8hEcKsJ//BHTQzdowKE6XJmkqG8Ft9CaZuv//usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠵࠵࠶࠮࠱ᑿ"))+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࠣࡑࡇ࠭ၿ"))
			cA6C7PMTuUklQdfoYqZgXj2FrJN.close()
		kXhEFvVqefGtabMy9z0YlpBi.close()
		if len(hSnzq03pfjs2Mrco)<EIqKcrsB0y9lxg1mte and EIqKcrsB0y9lxg1mte>f4fTutDOEwUeIoPLRQ:
			fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,SSvu1CZjTW7FcloNqD(u"ࠪ࠲ࡡࡺࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡱࡵࠤࡨࡧ࡮ࡤࡧ࡯ࡩࡩࠦࡡࡵ࠼ࠣ࡟ࠥ࠭ႀ")+str(len(hSnzq03pfjs2Mrco)//L9iyPRtCwK4DUmJYBsE)+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࠥࡓࡂࠡ࡟ࠣࠤࠥࡌࡲࡰ࡯ࠣࡸࡴࡺࡡ࡭ࠢࡲࡪ࠿࡛ࠦࠡࠩႁ")+hnr8Rsl7iIbeLjYwPJBGS+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࠦࡍࡃࠢࡠࠫႂ"))
			K4O6aMFQSLIbWxtGpPy2gZDB5q = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ลๅ฼สลࠥ๎ฮา๊ฯࠫႃ"),z3sIGH8jmLYg(u"ࠧศีอาิอๅࠡษ็้้็ࠠศๆ้ห็฻ࠧႄ"),Fo1SgXMsHk(u"ࠨว฼หิฯࠠอๆหࠤฬ๊ๅๅใࠪႅ"),SSvu1CZjTW7FcloNqD(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬႆ"),ulAxHwvzR9eTb5n(u"ࠪๅู๊ࠠโ์ࠣะ้ฮࠠศๆ่่ๆࠦ࡜࡯ࠢ็่ศูแࠡฯาฯࠥิืฤࠢไ๎ࠥะอๆ์็ࠤฬ๊ๅๅใࠣࡠࡳࠦสๆࠢฯ่อࠦࠧႇ")+str(len(hSnzq03pfjs2Mrco)//L9iyPRtCwK4DUmJYBsE)+YayJj10OGl(u"๋๊ࠫࠥ฻ษหห๏ะࠠๆ่้ࠣัฺ๋่ࠢࠪႈ")+hnr8Rsl7iIbeLjYwPJBGS+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࠦๅ๋฼สฬฬ๐สࠡ࡞ࡱࠤัืศࠡฮ็ฬࠥอไๆๆไࠤ๊ืษࠡลัี๎ࠦ࡜࡯๊่ࠢࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ๅๅใࠣห้์วใืࠣรࠦࠧࠧႉ"))
			if K4O6aMFQSLIbWxtGpPy2gZDB5q==QQSugEIn2mTCpRsfcaJHhPdAWzylM: hSnzq03pfjs2Mrco = OZq0bRFsaGe98NJxmW6tPiv(XibJtaWNpM84LHTURBZjFr0dgA,ehWfDEbAtMTZaS5x,showDialogs)
			elif K4O6aMFQSLIbWxtGpPy2gZDB5q==vkIa3ijEQVsJGdWOXwK7bnue9ADR: fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭࠮࡝ࡶࡑࡳࡹࠦࡣࡰ࡯ࡳࡰࡪࡺࡥࡥࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡦࡪ࡮ࡨࠤ࡮ࡹࠠࡢࡥࡦࡩࡵࡺࡥࡥࠢࡤࡲࡩࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡶࡵࡨࡨࠬႊ"))
			else: return nbOFVEDkpT4BIR7Qq82yPmHeJU
			if not hSnzq03pfjs2Mrco: return nbOFVEDkpT4BIR7Qq82yPmHeJU
		else: fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧ࠯࡞ࡷࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡵࡤࡥࡨࡩࡩ࡫ࡤ࠯ࠢࠣࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫႋ")+hnr8Rsl7iIbeLjYwPJBGS+UpQ56M0dO1N9xIvVegy(u"ࠨࠢࡐࡆࠥࡣࠧႌ"))
	return hSnzq03pfjs2Mrco
def BKM6wyFpEmHgU9iGlbvdx3W(QSJFrwB3dMiyH2mTPKD9a):
	return cA6C7PMTuUklQdfoYqZgXj2FrJN
def Se0XLol6NIhZdG8HBruT4w(ip=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	global oFOIC90bwDxWKLBZYAhmk
	if oFOIC90bwDxWKLBZYAhmk: return oFOIC90bwDxWKLBZYAhmk
	NIqC3AywdGJDhMbeg8RzOv6uZaKor,OORJ1AnN4w,MMn6Bx7CZTGrRhV,bqCyikL7rHePKUJup9Zvwm40,WuBO5y3ACHohIEan7xJiLvqk6,ST6cmEpu5VY1KaXvAj = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	qxZiT6WJ7sX = UpQ56M0dO1N9xIvVegy(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡴࡼ࡮࡯࠯࡫ࡶ࠳ႍࠬ")+ip+flDSRbv57PnV3(u"ࠪࡃࡴࡻࡴࡱࡷࡷࡁ࡯ࡹ࡯࡯ࠨࡩ࡭ࡪࡲࡤࡴ࠿࡬ࡴ࠱ࡩ࡯࡯ࡶ࡬ࡲࡪࡴࡴ࠭ࡥࡲࡹࡳࡺࡲࡺ࠮ࡦࡳࡺࡴࡴࡳࡻࡢࡧࡴࡪࡥ࠭ࡴࡨ࡫࡮ࡵ࡮࠭ࡥ࡬ࡸࡾ࠲ࡴࡪ࡯ࡨࡾࡴࡴࡥࠨႎ")
	ehWfDEbAtMTZaS5x = {UpQ56M0dO1N9xIvVegy(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨႏ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bYyKEjIuGQzoq3AR1(u"ࠬࡍࡅࡕࠩ႐"),qxZiT6WJ7sX,nbOFVEDkpT4BIR7Qq82yPmHeJU,ehWfDEbAtMTZaS5x,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡒࡐࡔࡉࡁࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ႑"))
	if not cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		qxZiT6WJ7sX = fgv5U2eRVaQqSiuGD(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡲ࠰ࡥࡵ࡯࠮ࡤࡱࡰ࠳࡯ࡹ࡯࡯࠱ࠪ႒")+ip+Fo1SgXMsHk(u"ࠨࡁࡩ࡭ࡪࡲࡤࡴ࠿ࡴࡹࡪࡸࡹ࠭ࡥࡲࡲࡹ࡯࡮ࡦࡰࡷ࠰ࡨࡵࡵ࡯ࡶࡵࡽ࠱ࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧ࠯ࡶࡪ࡭ࡩࡰࡰࡑࡥࡲ࡫ࠬࡤ࡫ࡷࡽ࠱ࡵࡦࡧࡵࡨࡸࠬ႓")
		cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bYyKEjIuGQzoq3AR1(u"ࠩࡊࡉ࡙࠭႔"),qxZiT6WJ7sX,nbOFVEDkpT4BIR7Qq82yPmHeJU,ehWfDEbAtMTZaS5x,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡌࡋࡏࡍࡑࡆࡅ࡙ࡏࡏࡏ࠯࠵ࡲࡩ࠭႕"))
	if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		UTvsQb4HpCP3Aeo2wDZG7X5V = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
		HHWKlczXBiR5hxSw23yD = eH72MR1wtfuI80myOo4ajgG.loads(UTvsQb4HpCP3Aeo2wDZG7X5V)
		h7mNB2ItxGMRo = list(HHWKlczXBiR5hxSw23yD.keys())
		if X1mRwt2YJKgCLu9a67(u"ࠫ࡮ࡶࠧ႖") in h7mNB2ItxGMRo: ip = HHWKlczXBiR5hxSw23yD[QlTuvPbSpnjygBVW(u"ࠬ࡯ࡰࠨ႗")]
		if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡣࡰࡰࡷ࡭ࡳ࡫࡮ࡵࠩ႘") in h7mNB2ItxGMRo: NIqC3AywdGJDhMbeg8RzOv6uZaKor = HHWKlczXBiR5hxSw23yD[ulAxHwvzR9eTb5n(u"ࠧࡤࡱࡱࡸ࡮ࡴࡥ࡯ࡶࠪ႙")]
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩႚ") in h7mNB2ItxGMRo: OORJ1AnN4w = HHWKlczXBiR5hxSw23yD[Fo1SgXMsHk(u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪႛ")]
		if X1mRwt2YJKgCLu9a67(u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࡣࡨࡵࡤࡦࠩႜ") in h7mNB2ItxGMRo: MMn6Bx7CZTGrRhV = HHWKlczXBiR5hxSw23yD[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡤࡩ࡯ࡥࡧࠪႝ")]
		if DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡸࡥࡨ࡫ࡲࡲࠬ႞") in h7mNB2ItxGMRo: bqCyikL7rHePKUJup9Zvwm40 = HHWKlczXBiR5hxSw23yD[QlTuvPbSpnjygBVW(u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭႟")]
		if fgv5U2eRVaQqSiuGD(u"ࠧࡤ࡫ࡷࡽࠬႠ") in h7mNB2ItxGMRo: WuBO5y3ACHohIEan7xJiLvqk6 = HHWKlczXBiR5hxSw23yD[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡥ࡬ࡸࡾ࠭Ⴁ")]
		if SSvu1CZjTW7FcloNqD(u"ࠩࡴࡹࡪࡸࡹࠨႢ") in h7mNB2ItxGMRo: ip = HHWKlczXBiR5hxSw23yD[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡵࡺ࡫ࡲࡺࠩႣ")]
		if qrjy8LuKVPNYdbSvzh(u"ࠫࡨࡵࡵ࡯ࡶࡵࡽࡈࡵࡤࡦࠩႤ") in h7mNB2ItxGMRo: MMn6Bx7CZTGrRhV = HHWKlczXBiR5hxSw23yD[bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡩ࡯ࡶࡰࡷࡶࡾࡉ࡯ࡥࡧࠪႥ")]
		if YayJj10OGl(u"࠭ࡲࡦࡩ࡬ࡳࡳࡔࡡ࡮ࡧࠪႦ") in h7mNB2ItxGMRo: bqCyikL7rHePKUJup9Zvwm40 = HHWKlczXBiR5hxSw23yD[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡳࡧࡪ࡭ࡴࡴࡎࡢ࡯ࡨࠫႧ")]
		if paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡶ࡬ࡱࡪࢀ࡯࡯ࡧࠪႨ") in h7mNB2ItxGMRo:
			ST6cmEpu5VY1KaXvAj = HHWKlczXBiR5hxSw23yD[ulAxHwvzR9eTb5n(u"ࠩࡷ࡭ࡲ࡫ࡺࡰࡰࡨࠫႩ")][ulAxHwvzR9eTb5n(u"ࠪࡹࡹࡩࠧႪ")]
			if ST6cmEpu5VY1KaXvAj[f4fTutDOEwUeIoPLRQ] not in [xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫ࠲࠭Ⴋ"),bYyKEjIuGQzoq3AR1(u"ࠬ࠱ࠧႬ")]: ST6cmEpu5VY1KaXvAj = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࠫࠨႭ")+ST6cmEpu5VY1KaXvAj
		if xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡰࡨࡩࡷࡪࡺࠧႮ") in h7mNB2ItxGMRo:
			ST6cmEpu5VY1KaXvAj = HHWKlczXBiR5hxSw23yD[X1mRwt2YJKgCLu9a67(u"ࠨࡱࡩࡪࡸ࡫ࡴࠨႯ")]
			if ST6cmEpu5VY1KaXvAj>=paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠵ᒀ"): ST6cmEpu5VY1KaXvAj = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࠮ࠫႰ")+lQMuw1PvVpAk.strftime(X60YQOADpkHBb31LiR5qUEKfM(u"ࠥࠩࡍࡀࠥࡎࠤႱ"),lQMuw1PvVpAk.gmtime(ST6cmEpu5VY1KaXvAj))
			else: ST6cmEpu5VY1KaXvAj = Fo1SgXMsHk(u"ࠫ࠲࠭Ⴒ")+lQMuw1PvVpAk.strftime(SSvu1CZjTW7FcloNqD(u"ࠧࠫࡈ࠻ࠧࡐࠦႳ"),lQMuw1PvVpAk.gmtime(-ST6cmEpu5VY1KaXvAj))
	oFOIC90bwDxWKLBZYAhmk = ip+bnI4kmPtrW7yFEhljXOCq9(u"࠭ࠬࠨႴ")+NIqC3AywdGJDhMbeg8RzOv6uZaKor+X1mRwt2YJKgCLu9a67(u"ࠧ࠭ࠩႵ")+OORJ1AnN4w+ulAxHwvzR9eTb5n(u"ࠨ࠮ࠪႶ")+bqCyikL7rHePKUJup9Zvwm40+X60YQOADpkHBb31LiR5qUEKfM(u"ࠩ࠯ࠫႷ")+WuBO5y3ACHohIEan7xJiLvqk6+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࠰ࠬႸ")+ST6cmEpu5VY1KaXvAj
	if IZhXMprxvAHqBEFkg0: oFOIC90bwDxWKLBZYAhmk = oFOIC90bwDxWKLBZYAhmk.encode(zSafwK0sDXdMN5JReniIQmrZxp).decode(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬႹ"))
	oFOIC90bwDxWKLBZYAhmk = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(oFOIC90bwDxWKLBZYAhmk)
	return oFOIC90bwDxWKLBZYAhmk
def hKjNwk3Bfpa48Om7JQz(Vs8RXuWIyN5fTpihaz6):
	llo05WzCJX6AdsTiKpYFDM1ty,showDialogs = nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4
	if Vs8RXuWIyN5fTpihaz6.count(YayJj10OGl(u"ࠬࡥࠧႺ"))>=QQSugEIn2mTCpRsfcaJHhPdAWzylM:
		Vs8RXuWIyN5fTpihaz6,llo05WzCJX6AdsTiKpYFDM1ty = Vs8RXuWIyN5fTpihaz6.split(flDSRbv57PnV3(u"࠭࡟ࠨႻ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)
		llo05WzCJX6AdsTiKpYFDM1ty = z3sIGH8jmLYg(u"ࠧࡠࠩႼ")+llo05WzCJX6AdsTiKpYFDM1ty
		if SSvu1CZjTW7FcloNqD(u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭Ⴝ") in llo05WzCJX6AdsTiKpYFDM1ty: showDialogs = SmbNGskjMx
		else: showDialogs = Ag9l6cw3EBqP8HsQuGMizfOtr4
	return Vs8RXuWIyN5fTpihaz6,llo05WzCJX6AdsTiKpYFDM1ty,showDialogs
def vvwCkoY1ReELHIyWaJf8n9j():
	i4yHDe5TnKCoMGlXkr0UaI = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨႾ"))
	yiGWj1tvHcs6I0JzfaQuC7LTV2e5 = f4fTutDOEwUeIoPLRQ
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(i4yHDe5TnKCoMGlXkr0UaI):
		for Oy2mWPY6LEsN3S95f in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(i4yHDe5TnKCoMGlXkr0UaI):
			if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࠲ࡵࡿ࡯ࠨႿ") in Oy2mWPY6LEsN3S95f: continue
			if flDSRbv57PnV3(u"ࠫࡤࡥࡰࡺࡥࡤࡧ࡭࡫࡟ࡠࠩჀ") in Oy2mWPY6LEsN3S95f: continue
			nPljHyg6DT39LSAmC = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(i4yHDe5TnKCoMGlXkr0UaI,Oy2mWPY6LEsN3S95f)
			C30A7FMPzmarInS5K9bhfuE,nnrNqvWG5TuXtCRK = nHxt2Y5jIy4cWrZJ(nPljHyg6DT39LSAmC)
			yiGWj1tvHcs6I0JzfaQuC7LTV2e5 += C30A7FMPzmarInS5K9bhfuE
	return yiGWj1tvHcs6I0JzfaQuC7LTV2e5
def PPoDgmISRnpCy8hO6JYaTB(showDialogs):
	aeVB2H1U9qNX3JIm8Cc5swLhn = llnG7jiQBYKhAeovbT.getSetting(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪჁ"))
	yy3uATdMfBC0qUYbwv6gxSpicN8D4e = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡳࡵࡴࠪჂ"),X1mRwt2YJKgCLu9a67(u"ࠧࡎࡋࡖࡇࡤ࡚ࡅࡎࡒࠪჃ"),qrjy8LuKVPNYdbSvzh(u"ࠨࡏࡈࡗࡘࡇࡇࡆࡕࠪჄ"))
	HcR9wb2y8BsEXWJuxo1OIgSht,FqR8b4ajV0tCWkGI = aeVB2H1U9qNX3JIm8Cc5swLhn,yy3uATdMfBC0qUYbwv6gxSpicN8D4e
	hhwTZsBqDtJAEO,xTyeo4DVGXrWnNbcBP9YQ = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		qxZiT6WJ7sX = sCSyOla9hrcE[DJ6ugPjW9bX8I(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩჅ")][ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
		v47vQB5lUtqRrzjo9HDC = Se0XLol6NIhZdG8HBruT4w()
		OORJ1AnN4w = v47vQB5lUtqRrzjo9HDC.split(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪ࠰ࠬ჆"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		yiGWj1tvHcs6I0JzfaQuC7LTV2e5 = vvwCkoY1ReELHIyWaJf8n9j()
		ME0GZsPhDVmOvYfw = {ulAxHwvzR9eTb5n(u"ࠫࡺࡹࡥࡳࠩჇ"):iidHGYjPEW4zU,t4txivgXSUWBOlCakQmNDjf(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭჈"):JeVILUu027qW,t4txivgXSUWBOlCakQmNDjf(u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ჉"):OORJ1AnN4w,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡪࡦࡶࠫ჊"):u8i2rxCZwsDyW7KMFIbmqgnvS(yiGWj1tvHcs6I0JzfaQuC7LTV2e5)}
		cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,I3cxjYaHhsrM7T4UX26klN(u"ࠨࡒࡒࡗ࡙࠭჋"),qxZiT6WJ7sX,ME0GZsPhDVmOvYfw,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡋࡊ࡚࡟ࡎࡇࡖࡗࡆࡍࡅࡔ࠯࠴ࡷࡹ࠭჌"))
		if not cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
			if aeVB2H1U9qNX3JIm8Cc5swLhn in [nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡒࡊ࡝ࠧჍ")]: HcR9wb2y8BsEXWJuxo1OIgSht = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡓࡋࡗࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪ჎")
			elif aeVB2H1U9qNX3JIm8Cc5swLhn==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡕࡌࡅࠩ჏"): HcR9wb2y8BsEXWJuxo1OIgSht = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡏࡍࡆࡢࡘࡔࡥࡅࡓࡔࡒࡖࠬა")
		else:
			Nd3sv1yuMpLqGHc0wmWBE5fSVAFDe = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
			Nd3sv1yuMpLqGHc0wmWBE5fSVAFDe = dr1zfnatJxRHSF48jh0eODm5bGu(UpQ56M0dO1N9xIvVegy(u"ࠧ࡭࡫ࡶࡸࠬბ"),Nd3sv1yuMpLqGHc0wmWBE5fSVAFDe)
			Nd3sv1yuMpLqGHc0wmWBE5fSVAFDe = sorted(Nd3sv1yuMpLqGHc0wmWBE5fSVAFDe,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: int(key[f4fTutDOEwUeIoPLRQ]))
			xTyeo4DVGXrWnNbcBP9YQ,FqR8b4ajV0tCWkGI = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
			for OveUTg43Sw,deBqZkPGcfx3hJursIa2S05mAyiF,D3PFE9RevWhwfUxYo51ta in Nd3sv1yuMpLqGHc0wmWBE5fSVAFDe:
				if OveUTg43Sw==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ࠲ࠪგ"):
					xTyeo4DVGXrWnNbcBP9YQ += D3PFE9RevWhwfUxYo51ta+IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࠽࠾ࠬდ")
					continue
				if FqR8b4ajV0tCWkGI: FqR8b4ajV0tCWkGI += wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+DJ6ugPjW9bX8I(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩე")+c7gxFyUCGm+YayJj10OGl(u"ࠫࡡࡴ࡜࡯ࠩვ")
				Ta9sjDBMX1 = D3PFE9RevWhwfUxYo51ta.split(wwOnIucWJj)[f4fTutDOEwUeIoPLRQ]
				lc6PgsYTOqfkdMnvA1U = SSvu1CZjTW7FcloNqD(u"ࠬืำศๆฬࠤำอีสࠢ็็ࠥ็โุࠩზ") if deBqZkPGcfx3hJursIa2S05mAyiF else nbOFVEDkpT4BIR7Qq82yPmHeJU
				FqR8b4ajV0tCWkGI += D3PFE9RevWhwfUxYo51ta.replace(Ta9sjDBMX1,l5JG7XwbOfo8DznU+Ta9sjDBMX1+lc6PgsYTOqfkdMnvA1U+c7gxFyUCGm)+wwOnIucWJj
			FqR8b4ajV0tCWkGI = wwOnIucWJj+FqR8b4ajV0tCWkGI+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭࡜࡯࡞ࡱࠫთ")
			xTyeo4DVGXrWnNbcBP9YQ = xTyeo4DVGXrWnNbcBP9YQ.strip(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࠻࠼ࠪი"))
			hhwTZsBqDtJAEO = llnG7jiQBYKhAeovbT.getSetting(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡣࡹ࠲ࡵࡸࡩࡷࡵ࠴ࠫკ"))
			if FqR8b4ajV0tCWkGI==yy3uATdMfBC0qUYbwv6gxSpicN8D4e and aeVB2H1U9qNX3JIm8Cc5swLhn in [fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡒࡐࡉ࠭ლ"),z3sIGH8jmLYg(u"ࠪࡓࡑࡊ࡟ࡕࡑࡢࡉࡗࡘࡏࡓࠩმ")]: HcR9wb2y8BsEXWJuxo1OIgSht = YayJj10OGl(u"ࠫࡔࡒࡄࠨნ")
			else: HcR9wb2y8BsEXWJuxo1OIgSht = flDSRbv57PnV3(u"ࠬࡔࡅࡘࠩო")
			z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,QlTuvPbSpnjygBVW(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩპ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࠩჟ"),FqR8b4ajV0tCWkGI,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
			llnG7jiQBYKhAeovbT.setSetting(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡣࡹ࠲ࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩრ"),u8i2rxCZwsDyW7KMFIbmqgnvS(sqeRK2tVw8))
			llnG7jiQBYKhAeovbT.setSetting(qrjy8LuKVPNYdbSvzh(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬს"),xTyeo4DVGXrWnNbcBP9YQ)
			ImVTYeswlrzB6L1jN9 = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(fgv5U2eRVaQqSiuGD(u"࠻ᒁ")*xTyeo4DVGXrWnNbcBP9YQ.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()
			ImVTYeswlrzB6L1jN9 = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(DJ6ugPjW9bX8I(u"࠱࠵ᒂ")*ImVTYeswlrzB6L1jN9.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()
			ImVTYeswlrzB6L1jN9 = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(UpQ56M0dO1N9xIvVegy(u"࠲࠻ᒃ")*ImVTYeswlrzB6L1jN9.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()
			llnG7jiQBYKhAeovbT.setSetting(UpQ56M0dO1N9xIvVegy(u"ࠪࡥࡻ࠴ࡰࡳ࡫ࡹࡷ࠷࠭ტ"),ImVTYeswlrzB6L1jN9)
	if showDialogs:
		if HcR9wb2y8BsEXWJuxo1OIgSht in [SSvu1CZjTW7FcloNqD(u"ࠫࡔࡒࡄࡠࡖࡒࡣࡊࡘࡒࡐࡔࠪუ"),z3sIGH8jmLYg(u"ࠬࡔࡅࡘࡡࡗࡓࡤࡋࡒࡓࡑࡕࠫფ")]:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩქ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"่่ࠧส็๋ࠥิไๆฬࠤๆ๐ࠠอ้สึ่่่ࠦ์่ࠣ๏ูสࠡ็้ࠤฬ๊ศา่ส้ัࠦ࠮࠯๊ࠢิ์ࠦวๅ็ื็้ฯࠠใัࠣ๎่๎ๆࠡีหฬ์อࠠศๆศ๊ฯืๆหࠢส่ำอีࠡสๆࠤศ๎ࠠศๆิหํะัࠡษ็าฬ฻ࠠษๅࠣวํࠦๅีๅ็อࠥ็๊ࠡษ็วุ๊วไࠢ฼๊ิ้ࠧღ"))
		else:
			r31rWd0qVCzeNapuFjwZg8scSIi5(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡴ࡬࡫࡭ࡺࠧყ"),DJ6ugPjW9bX8I(u"ࠩิืฬฬไࠡ็้ࠤฬ๊ๅษำ่ะࠥหไ๊่ࠢืฯิฯๆ์ࠣห้ฮั็ษ่ะࠬშ"),FqR8b4ajV0tCWkGI,SSvu1CZjTW7FcloNqD(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹࡥ࡬ࡰࡰࡪࠫჩ"))
			HcR9wb2y8BsEXWJuxo1OIgSht = z3sIGH8jmLYg(u"ࠫࡔࡒࡄࠨც")
	if HcR9wb2y8BsEXWJuxo1OIgSht!=aeVB2H1U9qNX3JIm8Cc5swLhn:
		llnG7jiQBYKhAeovbT.setSetting(QlTuvPbSpnjygBVW(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡷࡸࡧࡧࡦࡵࠪძ"),HcR9wb2y8BsEXWJuxo1OIgSht)
		ue186CEMORWhvq(SmbNGskjMx)
	c7mhFPMqYXjUO = Ag9l6cw3EBqP8HsQuGMizfOtr4 if xTyeo4DVGXrWnNbcBP9YQ!=hhwTZsBqDtJAEO else SmbNGskjMx
	if c7mhFPMqYXjUO:
		QQ3hd2tR8s.F8e4uNA5OfTIHvkg6lCJt2BZ,QQ3hd2tR8s.ggSlJwTytkUHBA2dz,QQ3hd2tR8s.UXlu0f9Szq2MTcEeWrn,QQ3hd2tR8s.qq293Npd7C = Bi6UGMYAPubKoXJge23fIw59vqR8d([ulAxHwvzR9eTb5n(u"࠭ࡃࡕࡇ࠼ࡈࡘ࠷࠹ࡗࡗ࠳࡚ࡘ࡞ࠧწ"),ulAxHwvzR9eTb5n(u"ࠧࡘࡕࡘࡖࡋ࡚࠱࠺ࡓࡗࡉࡋࡠࡘࠨჭ"),tM24jD1gO0(u"ࠨࡄࡗࡉࡽࡖࡖ࠲࠻ࡘࡖ࡛ࡔࡕࡔࡗ࠸ࡌ࡝࠭ხ"),t4txivgXSUWBOlCakQmNDjf(u"ࠩࡒࡘ࠶࠿ࡊࡖ࠲ࡻࡆ࡙࡛࡬ࡅ࡚ࠪჯ")])
		ue186CEMORWhvq(SmbNGskjMx)
	return
def PPwLpT7XsB(KABa1T6Js3RHdXZ,RDshBrbxpgiT6):
	from socket import socket as Ri19pkguZIof,AF_INET as zz0F47pPVUEIJfXMW89TZt,SOCK_STREAM as gm84czK096aZsVJYw5PqrbFku32
	hjDxswy60VORq = Ri19pkguZIof(zz0F47pPVUEIJfXMW89TZt,gm84czK096aZsVJYw5PqrbFku32)
	hjDxswy60VORq.settimeout(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
	tQHRqT0iljUbMNeka,GZu2wNjMF8Pn431mBt = Ag9l6cw3EBqP8HsQuGMizfOtr4,f4fTutDOEwUeIoPLRQ
	BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
	try: hjDxswy60VORq.connect((KABa1T6Js3RHdXZ,RDshBrbxpgiT6))
	except: tQHRqT0iljUbMNeka = SmbNGskjMx
	m5dGtOp8ZrANYvafElezRM9Tn7 = lQMuw1PvVpAk.time()
	if tQHRqT0iljUbMNeka: GZu2wNjMF8Pn431mBt = m5dGtOp8ZrANYvafElezRM9Tn7-BfM7ldYzjy5qVPoeJuN2QEpL9
	return GZu2wNjMF8Pn431mBt
def kYaRIGV5T7Zvfbq3WKpmQwJiBg(showDialogs):
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ჰ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ุࠫ๎แࠡ์ๅ์๊ࠦวๅสิ๊ฬ๋ฬࠡษ็ฦ๋ࠦศฦื็หา่ࠦห่฻๎ๆࠦฬๆ์฼ࠤ็๎วฺัࠣห้ฮ๊ศ่สฮࠥ๎วๅๅสุࠥอไๆีอาิ๋ษࠡใํࠤฬ๊ศา่ส้ัࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮูเ๊ๅࠢ฼้้๐ษࠡษ็ฮ๋฾๊โࠢส่ว์ࠠภࠣࠪჱ"))
	else: oyNUHM3uQq = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if oyNUHM3uQq==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		for Oy2mWPY6LEsN3S95f in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(iy1kK0BAJVLazhHpnZEqrYt9dOfW):
			if Oy2mWPY6LEsN3S95f.endswith(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࠴ࡤࡣࠩჲ")) and fgv5U2eRVaQqSiuGD(u"࠭ࡤࡢࡶࡤࠫჳ") in Oy2mWPY6LEsN3S95f:
				rFHIDgtaQZAb4xn1WEqTvOcMo2 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,Oy2mWPY6LEsN3S95f)
				IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4 = UOneuCKtT2qLMcGXjDv38Qsgpad1fo(rFHIDgtaQZAb4xn1WEqTvOcMo2)
				yWESdJ2nUj31M8ONktxl4.execute(QlTuvPbSpnjygBVW(u"ࠧࡑࡔࡄࡋࡒࡇࠠࡧࡱࡵࡩ࡮࡭࡮ࡠ࡭ࡨࡽࡸࡃ࡮ࡰ࠽ࠪჴ"))
				yWESdJ2nUj31M8ONktxl4.execute(l4DS8mnEjHhFMZ5YOe(u"ࠨࡒࡕࡅࡌࡓࡁࠡࡶࡨࡱࡵࡥࡳࡵࡱࡵࡩࡂࡓࡅࡎࡑࡕ࡝ࡀ࠭ჵ"))
				yWESdJ2nUj31M8ONktxl4.execute(X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡓࡖࡆࡍࡍࡂࠢ࡬ࡲࡹ࡫ࡧࡳ࡫ࡷࡽࡤࡩࡨࡦࡥ࡮࠿ࠬჶ"))
				yWESdJ2nUj31M8ONktxl4.execute(SSvu1CZjTW7FcloNqD(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡳࡵࡺࡩ࡮࡫ࡽࡩࡀ࠭ჷ"))
				yWESdJ2nUj31M8ONktxl4.execute(flDSRbv57PnV3(u"࡛ࠫࡇࡃࡖࡗࡐ࠿ࠬჸ"))
				IgtL0mb7hnwEpYyuf6KUxXR.commit()
				IgtL0mb7hnwEpYyuf6KUxXR.close()
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨჹ"),Fo1SgXMsHk(u"࠭สๆฬࠣฬ๋าวฮࠢ฼้้๐ษࠡวุ่ฬำ้ࠠฬ้฼๏็ࠠอ็ํ฽่่ࠥศ฻าࠤฬ๊ศ๋ษ้หฯ่ࠦศๆๆหูࠦวๅ็ึฮำีๅสࠢไ๎ࠥอไษำ้ห๊าࠧჺ"))
	return
def Zb4NIBy16VvWF(eDYibzULwXvRc14QaZPt,PGJn1EqWZaUIp,showDialogs):
	if eDYibzULwXvRc14QaZPt!=None:
		global hhYNnS925rx4buzZaeVQg0
		hhYNnS925rx4buzZaeVQg0 = eDYibzULwXvRc14QaZPt
	if PGJn1EqWZaUIp!=None:
		global brwqJc3TALapItWlyz
		brwqJc3TALapItWlyz = PGJn1EqWZaUIp
	if showDialogs!=None:
		global VH0sy13WPr
		VH0sy13WPr = showDialogs
	return
def WcuQwBGVkHrlOIX2otjqnN8S(hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,data,headers,allow_redirects,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh,PPpCE2Tu0edtVKg1U):
	if showDialogs==nbOFVEDkpT4BIR7Qq82yPmHeJU: rphN9x37cLm5VKHjz401TuW6yfSeQ = Ag9l6cw3EBqP8HsQuGMizfOtr4 if VH0sy13WPr==nbOFVEDkpT4BIR7Qq82yPmHeJU else VH0sy13WPr
	else: rphN9x37cLm5VKHjz401TuW6yfSeQ = Ag9l6cw3EBqP8HsQuGMizfOtr4 if showDialogs else SmbNGskjMx
	if PPpCE2Tu0edtVKg1U==nbOFVEDkpT4BIR7Qq82yPmHeJU: Xg3b5p4NdQiBa7Vn = Ag9l6cw3EBqP8HsQuGMizfOtr4 if brwqJc3TALapItWlyz==nbOFVEDkpT4BIR7Qq82yPmHeJU else brwqJc3TALapItWlyz
	else: Xg3b5p4NdQiBa7Vn = Ag9l6cw3EBqP8HsQuGMizfOtr4 if PPpCE2Tu0edtVKg1U else SmbNGskjMx
	if e0jTUtumPFaNh==nbOFVEDkpT4BIR7Qq82yPmHeJU: en8KBhPvWxuOFfkqiNL5TCIgY = Ag9l6cw3EBqP8HsQuGMizfOtr4 if hhYNnS925rx4buzZaeVQg0==nbOFVEDkpT4BIR7Qq82yPmHeJU else hhYNnS925rx4buzZaeVQg0
	else: en8KBhPvWxuOFfkqiNL5TCIgY = Ag9l6cw3EBqP8HsQuGMizfOtr4 if e0jTUtumPFaNh else SmbNGskjMx
	if allow_redirects==nbOFVEDkpT4BIR7Qq82yPmHeJU: ePaz4qTOvkyQtUEncDw6iJGV0Fp = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else: ePaz4qTOvkyQtUEncDw6iJGV0Fp = Ag9l6cw3EBqP8HsQuGMizfOtr4 if allow_redirects else SmbNGskjMx
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {} if headers==nbOFVEDkpT4BIR7Qq82yPmHeJU else headers
	J27qXeRCpsgkEoT9Q0GYS6ct = {} if data==nbOFVEDkpT4BIR7Qq82yPmHeJU else data
	if eg6iV4ckQxvTrjWKyBulYR==QlTuvPbSpnjygBVW(u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡌࡒࡘ࡚ࡁࡍࡎࡢࡓࡑࡊ࡟ࡓࡇࡏࡉࡆ࡙ࡅ࠮࠳ࡶࡸࠬ჻"): GcYwHSWoQ0Nq8KFfJDdvujZryM = {}
	else:
		nxH18r5tZdXQL2PpYSNMCEUsw = list(GcYwHSWoQ0Nq8KFfJDdvujZryM.keys())
		if X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩჼ") not in nxH18r5tZdXQL2PpYSNMCEUsw: GcYwHSWoQ0Nq8KFfJDdvujZryM[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪჽ")] = SSvu1CZjTW7FcloNqD(u"ࠪ࡬ࡹࡺࡰࠨჾ")
		if Fo1SgXMsHk(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨჿ") not in nxH18r5tZdXQL2PpYSNMCEUsw: GcYwHSWoQ0Nq8KFfJDdvujZryM[UpQ56M0dO1N9xIvVegy(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᄀ")] = MdwGcQOsmlV6vKI73THrUY4(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,en8KBhPvWxuOFfkqiNL5TCIgY,Xg3b5p4NdQiBa7Vn
def MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh=nbOFVEDkpT4BIR7Qq82yPmHeJU,PPpCE2Tu0edtVKg1U=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	wqHptDJiLhz = WcuQwBGVkHrlOIX2otjqnN8S(hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh,PPpCE2Tu0edtVKg1U)
	hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,en8KBhPvWxuOFfkqiNL5TCIgY,Xg3b5p4NdQiBa7Vn = wqHptDJiLhz
	plSscrVjkRviPwm,PB2EFL4DkoAnup7SajZq9GdRr,Thl3xtBje9dpPf6YsUoAyOzbL7Kk,WCrF2sGJaTRcZbI5n = VVRhJ5xaEkKCW(qxZiT6WJ7sX)
	KdNWSOYLiu1zF4xwXblqpv8RsAm0gT = llnG7jiQBYKhAeovbT.getSetting(I3cxjYaHhsrM7T4UX26klN(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭ᄁ"))
	slg0MoqUyXDtVp5cIFfdiRvJ = llnG7jiQBYKhAeovbT.getSetting(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᄂ"))
	EVzcAfpnQ1twxiO7bBjNM4DuW9r = llnG7jiQBYKhAeovbT.getSetting(QlTuvPbSpnjygBVW(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᄃ"))
	Og3U6MDFpeKPfmtCw9qbRkaIZu8 = [X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡶࡧࡷࡧࡰࡦࡱࡳࡷࠬᄄ"),tM24jD1gO0(u"ࠪࡷࡨࡸࡡࡱࡧࡵࡥࡵ࡯ࠧᄅ"),UpQ56M0dO1N9xIvVegy(u"ࠫࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵࠩᄆ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸࠬᄇ"),X1mRwt2YJKgCLu9a67(u"࠭ࡳࡤࡴࡤࡴࡪࡻࡰࠨᄈ"),Fo1SgXMsHk(u"ࠧࡴࡥࡵࡥࡵ࡫࠮ࡥࡱࠪᄉ")]
	EVHg4WywAPo3ik8uCOD7dz96c0ZM = Ag9l6cw3EBqP8HsQuGMizfOtr4 if any(XPL0O2VkI3w1C8enMaqi in qxZiT6WJ7sX for XPL0O2VkI3w1C8enMaqi in Og3U6MDFpeKPfmtCw9qbRkaIZu8) else SmbNGskjMx
	if bYyKEjIuGQzoq3AR1(u"ࠨࠨࡸࡶࡱࡃࠧᄊ") in plSscrVjkRviPwm and EVHg4WywAPo3ik8uCOD7dz96c0ZM: HCwVNDvWpmkZ43A = plSscrVjkRviPwm.rsplit(bYyKEjIuGQzoq3AR1(u"ࠩࠩࡹࡷࡲ࠽ࠨᄋ"),X1mRwt2YJKgCLu9a67(u"࠳ᒄ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	else: HCwVNDvWpmkZ43A = nbOFVEDkpT4BIR7Qq82yPmHeJU
	EqvJyGBAjCX3OkT1t5wg9Sdx7zP = sCSyOla9hrcE[X1mRwt2YJKgCLu9a67(u"ࠪࡔ࡞࡚ࡈࡐࡐࠪᄌ")]
	o7dathXQUE = plSscrVjkRviPwm in EqvJyGBAjCX3OkT1t5wg9Sdx7zP or HCwVNDvWpmkZ43A in EqvJyGBAjCX3OkT1t5wg9Sdx7zP
	XpROLoKvTnum342 = sCSyOla9hrcE[bYyKEjIuGQzoq3AR1(u"ࠫࡗࡋࡐࡐࡕࠪᄍ")]
	BHgUQieVtFqMdCh5Ipo = plSscrVjkRviPwm in XpROLoKvTnum342 or HCwVNDvWpmkZ43A in XpROLoKvTnum342
	GV3ov2wm6WlMx = o7dathXQUE or BHgUQieVtFqMdCh5Ipo
	YN9MOIQG8sb3 = SmbNGskjMx
	TE1d3pveiGQS = Ag9l6cw3EBqP8HsQuGMizfOtr4
	w8LHOTIuyWhcYfRFXMx9QG65NaoBAK = PB2EFL4DkoAnup7SajZq9GdRr==None and Thl3xtBje9dpPf6YsUoAyOzbL7Kk==None and not EVHg4WywAPo3ik8uCOD7dz96c0ZM
	if w8LHOTIuyWhcYfRFXMx9QG65NaoBAK and GV3ov2wm6WlMx:
		if o7dathXQUE:
			Qb8F3nKdGzESLfyxkjlZPc2J = EqvJyGBAjCX3OkT1t5wg9Sdx7zP.index(plSscrVjkRviPwm)
			tHTiagpsAZRl = sCSyOla9hrcE[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡖ࡙ࡕࡊࡒࡒࡤࡈࡋࡑࠩᄎ")][Qb8F3nKdGzESLfyxkjlZPc2J]
			rOCQ5AYBtjXwExLVlfTo0 = VdLvezkAg9[Qb8F3nKdGzESLfyxkjlZPc2J]
			if rOCQ5AYBtjXwExLVlfTo0==z3sIGH8jmLYg(u"࠭ࡌࡊࡕࡗࡔࡑࡇ࡙ࠨᄏ"): en8KBhPvWxuOFfkqiNL5TCIgY,Xg3b5p4NdQiBa7Vn,TE1d3pveiGQS = SmbNGskjMx,SmbNGskjMx,SmbNGskjMx
			elif rOCQ5AYBtjXwExLVlfTo0==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡄࡃࡓࡘࡈࡎࡁࠨᄐ"): YN9MOIQG8sb3 = Ag9l6cw3EBqP8HsQuGMizfOtr4
		elif BHgUQieVtFqMdCh5Ipo:
			Qb8F3nKdGzESLfyxkjlZPc2J = XpROLoKvTnum342.index(plSscrVjkRviPwm)
			tHTiagpsAZRl = sCSyOla9hrcE[flDSRbv57PnV3(u"ࠨࡔࡈࡔࡔ࡙࡟ࡃࡍࡓࠫᄑ")][Qb8F3nKdGzESLfyxkjlZPc2J]
			rOCQ5AYBtjXwExLVlfTo0 = nNJReWPO2VqzBymsZjGDhdr8MFg1[Qb8F3nKdGzESLfyxkjlZPc2J]
	if Thl3xtBje9dpPf6YsUoAyOzbL7Kk==nbOFVEDkpT4BIR7Qq82yPmHeJU: Thl3xtBje9dpPf6YsUoAyOzbL7Kk = KdNWSOYLiu1zF4xwXblqpv8RsAm0gT
	elif Thl3xtBje9dpPf6YsUoAyOzbL7Kk==None and slg0MoqUyXDtVp5cIFfdiRvJ in [qrjy8LuKVPNYdbSvzh(u"ࠩࡄ࡙࡙ࡕࠧᄒ"),SSvu1CZjTW7FcloNqD(u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬᄓ")] and en8KBhPvWxuOFfkqiNL5TCIgY: Thl3xtBje9dpPf6YsUoAyOzbL7Kk = KdNWSOYLiu1zF4xwXblqpv8RsAm0gT
	if o7dathXQUE or BHgUQieVtFqMdCh5Ipo: rXKsDBmP18gdEl4LWbU6 = xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠴࠹ᒅ")
	elif EVHg4WywAPo3ik8uCOD7dz96c0ZM: rXKsDBmP18gdEl4LWbU6 = z3sIGH8jmLYg(u"࠺࠵ᒆ")
	elif eg6iV4ckQxvTrjWKyBulYR in nfm7agrTI9E: rXKsDBmP18gdEl4LWbU6 = flDSRbv57PnV3(u"࠶࠶ᒇ")
	elif eg6iV4ckQxvTrjWKyBulYR==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡘࡅࡗࡇࡕࡗࡔࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ᄔ"): rXKsDBmP18gdEl4LWbU6 = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠸࠰ᒈ")
	elif eg6iV4ckQxvTrjWKyBulYR==Fo1SgXMsHk(u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡐࡑࡊࡐࡊࡥࡔࡓࡃࡑࡗࡑࡇࡔࡆ࠯࠴ࡷࡹ࠭ᄕ"): rXKsDBmP18gdEl4LWbU6 = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠲࠱ᒉ")
	elif l4DS8mnEjHhFMZ5YOe(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏ࡜ࡇࡍࠨᄖ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = Fo1SgXMsHk(u"࠸࠲ᒊ")
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡔࡊࡒࡊࡍࡇࠧᄗ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = QlTuvPbSpnjygBVW(u"࠹࠸ᒋ")
	elif z3sIGH8jmLYg(u"ࠨࡅࡌࡑࡆ࠺ࡕࠨᄘ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = SSvu1CZjTW7FcloNqD(u"࠵࠹ᒌ")
	elif ulAxHwvzR9eTb5n(u"ࠩࡄࡌ࡜ࡇࡋࠨᄙ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠶࠵ᒍ")
	elif X1mRwt2YJKgCLu9a67(u"ࠪࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᄚ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = ulAxHwvzR9eTb5n(u"࠷࠶ᒎ")
	elif YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࡝ࡏࡓࡍࠪᄛ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = IINBvuxkCSJrO1Q0UyngdLi(u"࠹࠰ᒏ")
	elif flDSRbv57PnV3(u"ࠬࡇࡋࡐࡃࡐࠫᄜ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = I3cxjYaHhsrM7T4UX26klN(u"࠲࠶ᒐ")
	elif DJ6ugPjW9bX8I(u"࠭ࡁࡌ࡙ࡄࡑࠬᄝ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠴࠲ᒑ")
	elif YayJj10OGl(u"ࠧࡇࡃࡖࡉࡑࡎࡄ࠲ࠩᄞ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = bYyKEjIuGQzoq3AR1(u"࠴࠳ᒒ")
	elif SSvu1CZjTW7FcloNqD(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠵ࠪᄟ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠹࠴ᒓ")
	elif fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫᄠ") in eg6iV4ckQxvTrjWKyBulYR: rXKsDBmP18gdEl4LWbU6 = X60YQOADpkHBb31LiR5qUEKfM(u"࠸࠵ᒔ")
	else: rXKsDBmP18gdEl4LWbU6 = qrjy8LuKVPNYdbSvzh(u"࠶࠻ᒕ")
	oT5MDZCVIh7ciqF2sUuBt0AmH = (PB2EFL4DkoAnup7SajZq9GdRr!=None)
	bit4r1OK5x8yFlYkaSBQLVNqHp0gfT = (Thl3xtBje9dpPf6YsUoAyOzbL7Kk!=None and slg0MoqUyXDtVp5cIFfdiRvJ!=tM24jD1gO0(u"ࠪࡗ࡙ࡕࡐࠨᄡ"))
	if oT5MDZCVIh7ciqF2sUuBt0AmH and not EVHg4WywAPo3ik8uCOD7dz96c0ZM: SSVCGE0bOfW1w9u52yvBxocNeP(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫฯ็ู๋ๆࠣฬึ๎ใิ์ࠣี็๋ࠧᄢ"),PB2EFL4DkoAnup7SajZq9GdRr)
	elif bit4r1OK5x8yFlYkaSBQLVNqHp0gfT: SSVCGE0bOfW1w9u52yvBxocNeP(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬะแฺ์็ࠤࡉࡔࡓࠡำๅ้ࠬᄣ"),Thl3xtBje9dpPf6YsUoAyOzbL7Kk)
	if oT5MDZCVIh7ciqF2sUuBt0AmH:
		xX4R8BQn19 = {ulAxHwvzR9eTb5n(u"ࠨࡨࡵࡶࡳࠦᄤ"):PB2EFL4DkoAnup7SajZq9GdRr,flDSRbv57PnV3(u"ࠢࡩࡶࡷࡴࡸࠨᄥ"):PB2EFL4DkoAnup7SajZq9GdRr}
		eLln98aTzxJjRpdKMrQNI = PB2EFL4DkoAnup7SajZq9GdRr
	else: xX4R8BQn19,eLln98aTzxJjRpdKMrQNI = {},nbOFVEDkpT4BIR7Qq82yPmHeJU
	if bit4r1OK5x8yFlYkaSBQLVNqHp0gfT:
		import urllib3.util.connection as dmOKENZcVPJo6QBRFfk4j8
		wX2Bm64Rx7h0fvui9yo = JVFoSZKQlsGb2LBviX6HRaw(dmOKENZcVPJo6QBRFfk4j8,KdNWSOYLiu1zF4xwXblqpv8RsAm0gT)
	FbWqHMTo94UmcS,q1S5R0VxsyPwtMkemY7rGdO,Ps2BDkViKJGt,edYmagIlBU8,Ib96K8UFghZx2VONefJL4GEa,verify = ePaz4qTOvkyQtUEncDw6iJGV0Fp,eg6iV4ckQxvTrjWKyBulYR,hhyC3ID85J1uvxjFMi,SmbNGskjMx,SmbNGskjMx,WCrF2sGJaTRcZbI5n
	if YN9MOIQG8sb3: Ib96K8UFghZx2VONefJL4GEa = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if GV3ov2wm6WlMx or ePaz4qTOvkyQtUEncDw6iJGV0Fp: FbWqHMTo94UmcS = SmbNGskjMx
	if o7dathXQUE: Ps2BDkViKJGt = ulAxHwvzR9eTb5n(u"ࠨࡒࡒࡗ࡙࠭ᄦ")
	XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv = -vkIa3ijEQVsJGdWOXwK7bnue9ADR,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡘࡲࡰࡴ࡯ࡸࡰࠣࡉࡷࡸ࡯ࡳࠩᄧ")
	E8lYwgCNAIy0aDrHs = SmbNGskjMx
	global UhfXK25nxeE8t3i0bOcl
	if not UhfXK25nxeE8t3i0bOcl: UhfXK25nxeE8t3i0bOcl = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡨ࡮ࡩࡴࠨᄨ"),YayJj10OGl(u"ࠫࡒࡏࡓࡄࡡࡗࡉࡒࡖࠧᄩ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡌࡏࡓ࡙ࡄࡖࡉ࡙ࠧᄪ"))
	ZSLdWqoh9YfOP3b4eKlmir = []
	while plSscrVjkRviPwm not in ZSLdWqoh9YfOP3b4eKlmir and plSscrVjkRviPwm in list(UhfXK25nxeE8t3i0bOcl.keys()):
		ZSLdWqoh9YfOP3b4eKlmir.append(plSscrVjkRviPwm)
		plSscrVjkRviPwm = UhfXK25nxeE8t3i0bOcl[plSscrVjkRviPwm]
	import requests as SiB7OvlwTJKzdEorLDefAGHF
	for HT4fGXqv8hEcKsJ in range(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠿ᒖ")):
		hKxpjzRaL5u6gTX = Ag9l6cw3EBqP8HsQuGMizfOtr4
		EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
		try:
			if HT4fGXqv8hEcKsJ: q1S5R0VxsyPwtMkemY7rGdO = Fo1SgXMsHk(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠵ࡸࡺࠧᄫ")
			if EVHg4WywAPo3ik8uCOD7dz96c0ZM or not oT5MDZCVIh7ciqF2sUuBt0AmH: qvUe2bwfQ7sZKV(fgv5U2eRVaQqSiuGD(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡔ࡞ࡷࡓࡕࡋࡎࡠࡗࡕࡐࠬᄬ"),plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,q1S5R0VxsyPwtMkemY7rGdO,Ps2BDkViKJGt)
			try: cA6C7PMTuUklQdfoYqZgXj2FrJN.close()
			except: pass
			zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm
			cA6C7PMTuUklQdfoYqZgXj2FrJN = SiB7OvlwTJKzdEorLDefAGHF.request(Ps2BDkViKJGt,plSscrVjkRviPwm,data=J27qXeRCpsgkEoT9Q0GYS6ct,headers=GcYwHSWoQ0Nq8KFfJDdvujZryM,verify=verify,allow_redirects=FbWqHMTo94UmcS,timeout=rXKsDBmP18gdEl4LWbU6,proxies=xX4R8BQn19)
			if DJ6ugPjW9bX8I(u"࠳࠱࠲ᒗ")<=cA6C7PMTuUklQdfoYqZgXj2FrJN.status_code<=O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠴࠻࠼ᒘ"):
				if not edYmagIlBU8:
					C7I4XzhjSqa1e = list(cA6C7PMTuUklQdfoYqZgXj2FrJN.headers.keys())
					if qrjy8LuKVPNYdbSvzh(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᄭ") in C7I4XzhjSqa1e: plSscrVjkRviPwm = cA6C7PMTuUklQdfoYqZgXj2FrJN.headers[bYyKEjIuGQzoq3AR1(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᄮ")]
					elif xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡰࡴࡩࡡࡵ࡫ࡲࡲࠬᄯ") in C7I4XzhjSqa1e: plSscrVjkRviPwm = cA6C7PMTuUklQdfoYqZgXj2FrJN.headers[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᄰ")]
					else: edYmagIlBU8 = Ag9l6cw3EBqP8HsQuGMizfOtr4
					if not edYmagIlBU8: plSscrVjkRviPwm = plSscrVjkRviPwm.encode(l4DS8mnEjHhFMZ5YOe(u"ࠬࡲࡡࡵ࡫ࡱ࠱࠶࠭ᄱ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᄲ")).decode(zSafwK0sDXdMN5JReniIQmrZxp,X1mRwt2YJKgCLu9a67(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧᄳ"))
					if GV3ov2wm6WlMx and cA6C7PMTuUklQdfoYqZgXj2FrJN.status_code==l4DS8mnEjHhFMZ5YOe(u"࠵࠳࠻ᒙ"):
						FbWqHMTo94UmcS = ePaz4qTOvkyQtUEncDw6iJGV0Fp
						Ps2BDkViKJGt = hhyC3ID85J1uvxjFMi
						edYmagIlBU8 = Ag9l6cw3EBqP8HsQuGMizfOtr4
						TAMc1kCHiXn76qyFmlhKveUWSBL
				if not edYmagIlBU8 or ePaz4qTOvkyQtUEncDw6iJGV0Fp:
					if t4txivgXSUWBOlCakQmNDjf(u"ࠨࡪࡷࡸࡵ࠭ᄴ") not in plSscrVjkRviPwm:
						CnHvq10LoBk7mUReK2bZ3cjl8 = Qi32bRtN18qvyWmaO7YKow9cXs(zb2QIaL7Y4h9g8lSck,bYyKEjIuGQzoq3AR1(u"ࠩࡸࡶࡱ࠭ᄵ"))
						plSscrVjkRviPwm = CnHvq10LoBk7mUReK2bZ3cjl8+t4txivgXSUWBOlCakQmNDjf(u"ࠪ࠳ࠬᄶ")+plSscrVjkRviPwm.lstrip(YayJj10OGl(u"ࠫ࠴࠭ᄷ"))
				if plSscrVjkRviPwm!=zb2QIaL7Y4h9g8lSck:
					UhfXK25nxeE8t3i0bOcl[zb2QIaL7Y4h9g8lSck] = plSscrVjkRviPwm
					E8lYwgCNAIy0aDrHs = Ag9l6cw3EBqP8HsQuGMizfOtr4
				if not edYmagIlBU8 and ePaz4qTOvkyQtUEncDw6iJGV0Fp and not JoEms64VZ1ldaf9NYBgcKCFL(plSscrVjkRviPwm): TAMc1kCHiXn76qyFmlhKveUWSBL
			elif flDSRbv57PnV3(u"࠹࠺࠶ᒛ")<=cA6C7PMTuUklQdfoYqZgXj2FrJN.status_code<=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠸࠽࠾ᒚ"):
				cA6C7PMTuUklQdfoYqZgXj2FrJN.reason = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
				Ib96K8UFghZx2VONefJL4GEa = Ag9l6cw3EBqP8HsQuGMizfOtr4
			zb2QIaL7Y4h9g8lSck = cA6C7PMTuUklQdfoYqZgXj2FrJN.url
			XqLr3B9MPx = cA6C7PMTuUklQdfoYqZgXj2FrJN.status_code
			szmD9nEACSWOyk15fPl0QZoTv = cA6C7PMTuUklQdfoYqZgXj2FrJN.reason
			cA6C7PMTuUklQdfoYqZgXj2FrJN.raise_for_status()
			EJNf2kglaiQHnFGe531Iq = Ag9l6cw3EBqP8HsQuGMizfOtr4
		except SiB7OvlwTJKzdEorLDefAGHF.exceptions.HTTPError as TsLJDVQSbg5P9hd4YW7acCvEKqlXu:
			pass
		except SiB7OvlwTJKzdEorLDefAGHF.exceptions.Timeout as TsLJDVQSbg5P9hd4YW7acCvEKqlXu:
			if n7neb9KTv10FcU: szmD9nEACSWOyk15fPl0QZoTv = str(TsLJDVQSbg5P9hd4YW7acCvEKqlXu.message).split(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡀࠠࠨᄸ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			else: szmD9nEACSWOyk15fPl0QZoTv = str(TsLJDVQSbg5P9hd4YW7acCvEKqlXu).split(bnI4kmPtrW7yFEhljXOCq9(u"࠭࠺ࠡࠩᄹ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		except SiB7OvlwTJKzdEorLDefAGHF.exceptions.ConnectionError as TsLJDVQSbg5P9hd4YW7acCvEKqlXu:
			try: FfrbtQYZoXdWM3Lu6nKU5g0RP4 = TsLJDVQSbg5P9hd4YW7acCvEKqlXu.message[f4fTutDOEwUeIoPLRQ]
			except: FfrbtQYZoXdWM3Lu6nKU5g0RP4 = str(TsLJDVQSbg5P9hd4YW7acCvEKqlXu)
			SKQPI6Ee9aBODk = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤᄺ"),FfrbtQYZoXdWM3Lu6nKU5g0RP4)
			if not SKQPI6Ee9aBODk: SKQPI6Ee9aBODk = ScntgdOZCY74vNpXeW5jh8i.findall(YayJj10OGl(u"ࠣ࠮ࠣࡩࡷࡸ࡯ࡳ࡞ࠫࠬࡡࡪࠫࠪ࠮ࠣࠫ࠭࠴ࠪࡀࠫࠪࠦᄻ"),FfrbtQYZoXdWM3Lu6nKU5g0RP4)
			if not SKQPI6Ee9aBODk:
				gdFmPDByxejU = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠤ࠽ࠤ࠭࠴ࠪࡀࠫ࠽࠲࠯ࡅࠨ࡝ࡦ࠮࠭࠿ࠨᄼ"),FfrbtQYZoXdWM3Lu6nKU5g0RP4)
				if gdFmPDByxejU: SKQPI6Ee9aBODk = [gdFmPDByxejU[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR],gdFmPDByxejU[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ]]
			if not SKQPI6Ee9aBODk: SKQPI6Ee9aBODk = ScntgdOZCY74vNpXeW5jh8i.findall(X60YQOADpkHBb31LiR5qUEKfM(u"ࠥ࠾࠭ࡢࡤࠬࠫ࠽ࠤ࠭࠴ࠪࡀࠫࠪࠦᄽ"),FfrbtQYZoXdWM3Lu6nKU5g0RP4)
			if not SKQPI6Ee9aBODk: SKQPI6Ee9aBODk = ScntgdOZCY74vNpXeW5jh8i.findall(bnI4kmPtrW7yFEhljXOCq9(u"ࠦࠥ࠮࡜ࡥ࠭ࠬࡡࠥ࠮࠮ࠫࡁࠬࠫࠧᄾ"),FfrbtQYZoXdWM3Lu6nKU5g0RP4)
			try: XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv = SKQPI6Ee9aBODk[f4fTutDOEwUeIoPLRQ]
			except: XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv = -tM24jD1gO0(u"࠷ᒜ"),FfrbtQYZoXdWM3Lu6nKU5g0RP4
		except SiB7OvlwTJKzdEorLDefAGHF.exceptions.RequestException as TsLJDVQSbg5P9hd4YW7acCvEKqlXu:
			if n7neb9KTv10FcU: szmD9nEACSWOyk15fPl0QZoTv = TsLJDVQSbg5P9hd4YW7acCvEKqlXu.message
			else: szmD9nEACSWOyk15fPl0QZoTv = str(TsLJDVQSbg5P9hd4YW7acCvEKqlXu)
		except:
			hKxpjzRaL5u6gTX = SmbNGskjMx
			try: XqLr3B9MPx = cA6C7PMTuUklQdfoYqZgXj2FrJN.status_code
			except: pass
			try: szmD9nEACSWOyk15fPl0QZoTv = cA6C7PMTuUklQdfoYqZgXj2FrJN.reason
			except: pass
		szmD9nEACSWOyk15fPl0QZoTv = str(szmD9nEACSWOyk15fPl0QZoTv)
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓ࡝ࡶࡕࡉࡘࡖࡏࡏࡕࡈࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧᄿ")+str(XqLr3B9MPx)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨᅀ")+szmD9nEACSWOyk15fPl0QZoTv+t4txivgXSUWBOlCakQmNDjf(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᅁ")+eg6iV4ckQxvTrjWKyBulYR+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᅂ")+qxZiT6WJ7sX+IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࠣࡡࠬᅃ"))
		if w8LHOTIuyWhcYfRFXMx9QG65NaoBAK and GV3ov2wm6WlMx and hKxpjzRaL5u6gTX and not Ib96K8UFghZx2VONefJL4GEa and XqLr3B9MPx!=UpQ56M0dO1N9xIvVegy(u"࠸࠰࠱ᒝ"):
			plSscrVjkRviPwm = tHTiagpsAZRl
			Ib96K8UFghZx2VONefJL4GEa = Ag9l6cw3EBqP8HsQuGMizfOtr4
			continue
		if hKxpjzRaL5u6gTX: break
	if not EJNf2kglaiQHnFGe531Iq and ZSLdWqoh9YfOP3b4eKlmir:
		for url in ZSLdWqoh9YfOP3b4eKlmir: del UhfXK25nxeE8t3i0bOcl[url]
		E8lYwgCNAIy0aDrHs = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if E8lYwgCNAIy0aDrHs:
		z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡑࡎ࡙ࡃࡠࡖࡈࡑࡕ࠭ᅄ"),UpQ56M0dO1N9xIvVegy(u"ࠫࡋࡕࡒࡘࡃࡕࡈࡘ࠭ᅅ"),UhfXK25nxeE8t3i0bOcl,mmfpkVtUDjaq86eAuFzE0oxP)
		UhfXK25nxeE8t3i0bOcl = {}
	if Thl3xtBje9dpPf6YsUoAyOzbL7Kk!=None and slg0MoqUyXDtVp5cIFfdiRvJ!=t4txivgXSUWBOlCakQmNDjf(u"࡙ࠬࡔࡐࡒࠪᅆ"): dmOKENZcVPJo6QBRFfk4j8.create_connection = wX2Bm64Rx7h0fvui9yo
	if slg0MoqUyXDtVp5cIFfdiRvJ==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡁࡍ࡙ࡄ࡝ࡘ࠭ᅇ") and en8KBhPvWxuOFfkqiNL5TCIgY: Thl3xtBje9dpPf6YsUoAyOzbL7Kk = None
	if not EJNf2kglaiQHnFGe531Iq and PB2EFL4DkoAnup7SajZq9GdRr==None and eg6iV4ckQxvTrjWKyBulYR not in nfm7agrTI9E:
		vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
		if vf9s4ClmTE08AGndQV!=IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡏࡱࡱࡩ࡙ࡿࡰࡦ࠼ࠣࡒࡴࡴࡥ࡝ࡰࠪᅈ"): Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
	KXFGbQxMAgBRYh = zJpU8hfZnevcG()
	if EVHg4WywAPo3ik8uCOD7dz96c0ZM: zb2QIaL7Y4h9g8lSck = HCwVNDvWpmkZ43A
	if not zb2QIaL7Y4h9g8lSck: zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm
	KXFGbQxMAgBRYh.url = zb2QIaL7Y4h9g8lSck
	KXFGbQxMAgBRYh.scrape = EVHg4WywAPo3ik8uCOD7dz96c0ZM
	try: R6ntKwh5Sb1Jm9 = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
	except: R6ntKwh5Sb1Jm9 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: I6czP5lQ0kxNrXwfdmVZyB8ED = cA6C7PMTuUklQdfoYqZgXj2FrJN.headers
	except: I6czP5lQ0kxNrXwfdmVZyB8ED = {}
	try: HhgQUqsVtvep2 = cA6C7PMTuUklQdfoYqZgXj2FrJN.cookies.get_dict()
	except: HhgQUqsVtvep2 = {}
	try: cA6C7PMTuUklQdfoYqZgXj2FrJN.close()
	except: pass
	if IZhXMprxvAHqBEFkg0:
		try: R6ntKwh5Sb1Jm9 = R6ntKwh5Sb1Jm9.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		except: pass
	XqLr3B9MPx = int(XqLr3B9MPx)
	KXFGbQxMAgBRYh.code = XqLr3B9MPx
	KXFGbQxMAgBRYh.reason = szmD9nEACSWOyk15fPl0QZoTv
	KXFGbQxMAgBRYh.content = R6ntKwh5Sb1Jm9
	KXFGbQxMAgBRYh.headers = I6czP5lQ0kxNrXwfdmVZyB8ED
	KXFGbQxMAgBRYh.cookies = HhgQUqsVtvep2
	KXFGbQxMAgBRYh.succeeded = EJNf2kglaiQHnFGe531Iq
	KXFGbQxMAgBRYh.scrapernumber = nbOFVEDkpT4BIR7Qq82yPmHeJU
	KXFGbQxMAgBRYh.scraperserver = nbOFVEDkpT4BIR7Qq82yPmHeJU
	KXFGbQxMAgBRYh.scraperurl = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if n7neb9KTv10FcU or isinstance(KXFGbQxMAgBRYh.content,str): pcvzq4teEmo0yHu2CaiWFI9YDj = KXFGbQxMAgBRYh.content.lower()
	else: pcvzq4teEmo0yHu2CaiWFI9YDj = nbOFVEDkpT4BIR7Qq82yPmHeJU
	wjSstJ9KD8IhAgrzcyiuP = (DJ6ugPjW9bX8I(u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬᅉ") in pcvzq4teEmo0yHu2CaiWFI9YDj or YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡪࡳࡴ࡭࡬ࡦࠩᅊ") in pcvzq4teEmo0yHu2CaiWFI9YDj) and pcvzq4teEmo0yHu2CaiWFI9YDj.count(QlTuvPbSpnjygBVW(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠭ᅋ"))>wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠲ᒞ") and fgv5U2eRVaQqSiuGD(u"ࠫࡋࡇࡓࡆࡎࡋࡈ࠶࠭ᅌ") not in eg6iV4ckQxvTrjWKyBulYR and flDSRbv57PnV3(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴࠧᅍ") not in pcvzq4teEmo0yHu2CaiWFI9YDj and not EVHg4WywAPo3ik8uCOD7dz96c0ZM
	if XqLr3B9MPx==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠳࠲࠳ᒟ") and wjSstJ9KD8IhAgrzcyiuP: KXFGbQxMAgBRYh.succeeded = SmbNGskjMx
	if KXFGbQxMAgBRYh.succeeded and w8LHOTIuyWhcYfRFXMx9QG65NaoBAK and GV3ov2wm6WlMx:
		XXCxGBP0T1gVfmzvshUOZj4qN = Fo1SgXMsHk(u"࠭ࡃࡂࡒࡗࡇࡍࡇࠧᅎ")+J27qXeRCpsgkEoT9Q0GYS6ct[X1mRwt2YJKgCLu9a67(u"ࠧ࡫ࡱࡥࠫᅏ")].upper().replace(tM24jD1gO0(u"ࠨࡉࡈࡘࠬᅐ"),nbOFVEDkpT4BIR7Qq82yPmHeJU) if YN9MOIQG8sb3 else rOCQ5AYBtjXwExLVlfTo0
		Wyuk0g8ERiBU(XXCxGBP0T1gVfmzvshUOZj4qN)
	if not KXFGbQxMAgBRYh.succeeded and w8LHOTIuyWhcYfRFXMx9QG65NaoBAK:
		pL90NVf3ZXjUW7PlydQgI8Oz = (I3cxjYaHhsrM7T4UX26klN(u"ࠩࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪ࠭ᅑ") in pcvzq4teEmo0yHu2CaiWFI9YDj and tM24jD1gO0(u"ࠪࡶࡦࡿࠠࡪࡦ࠽ࠤࠬᅒ") in pcvzq4teEmo0yHu2CaiWFI9YDj)
		IRydSNiaH0653GU = (QlTuvPbSpnjygBVW(u"ࠫ࠺ࠦࡳࡦࡥࠪᅓ") in pcvzq4teEmo0yHu2CaiWFI9YDj and QlTuvPbSpnjygBVW(u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭ᅔ") in pcvzq4teEmo0yHu2CaiWFI9YDj)
		t3giwaVDy2rhxjLvQPn5E = (XqLr3B9MPx in [SSvu1CZjTW7FcloNqD(u"࠶࠳࠷ᒠ")] and bYyKEjIuGQzoq3AR1(u"࠭ࡥࡳࡴࡲࡶࠥࡩ࡯ࡥࡧ࠽ࠤ࠶࠶࠲࠱ࠩᅕ") in pcvzq4teEmo0yHu2CaiWFI9YDj)
		srTYNyzHUWq6FCpQSj = (fgv5U2eRVaQqSiuGD(u"ࠧࡠࡥࡩࡣࡨ࡮࡬ࡠࠩᅖ") in pcvzq4teEmo0yHu2CaiWFI9YDj and O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱ࠬᅗ") in pcvzq4teEmo0yHu2CaiWFI9YDj)
		if   wjSstJ9KD8IhAgrzcyiuP: szmD9nEACSWOyk15fPl0QZoTv = I3cxjYaHhsrM7T4UX26klN(u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡲࡦࡥࡤࡴࡹࡩࡨࡢࠩᅘ")
		elif pL90NVf3ZXjUW7PlydQgI8Oz: szmD9nEACSWOyk15fPl0QZoTv = X1mRwt2YJKgCLu9a67(u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡤ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫᅙ")
		elif IRydSNiaH0653GU: szmD9nEACSWOyk15fPl0QZoTv = z3sIGH8jmLYg(u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫᅚ")
		elif t3giwaVDy2rhxjLvQPn5E: szmD9nEACSWOyk15fPl0QZoTv = l4DS8mnEjHhFMZ5YOe(u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡦࡰࡴࡻࡤࡧ࡮ࡤࡶࡪࠦࡡࡤࡥࡨࡷࡸࠦࡤࡦࡰ࡬ࡩࡩ࠭ᅛ")
		elif srTYNyzHUWq6FCpQSj: szmD9nEACSWOyk15fPl0QZoTv = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡧࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠠࡴࡧࡦࡹࡷ࡯ࡴࡺࠢࡦ࡬ࡪࡩ࡫ࠨᅜ")
		else: szmD9nEACSWOyk15fPl0QZoTv = str(szmD9nEACSWOyk15fPl0QZoTv)
		if eg6iV4ckQxvTrjWKyBulYR in dl6eh2Jv5auoMj93gnwK1: pass
		elif eg6iV4ckQxvTrjWKyBulYR in nfm7agrTI9E:
			fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࠡࠢࡇ࡭ࡷ࡫ࡣࡵࠢࡦࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪᅝ")+str(XqLr3B9MPx)+IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪᅞ")+szmD9nEACSWOyk15fPl0QZoTv+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᅟ")+eg6iV4ckQxvTrjWKyBulYR+X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᅠ")+plSscrVjkRviPwm+DJ6ugPjW9bX8I(u"ࠫࠥࡣࠧᅡ"))
		else: fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࠦࠠࠡࡆ࡬ࡶࡪࡩࡴࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᅢ")+str(XqLr3B9MPx)+q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨᅣ")+szmD9nEACSWOyk15fPl0QZoTv+tM24jD1gO0(u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᅤ")+eg6iV4ckQxvTrjWKyBulYR+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᅥ")+plSscrVjkRviPwm+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࠣࡡࠬᅦ"))
		NrxJjXU4ECt9Iue6ZqR8QFhHBw = HCwVNDvWpmkZ43A if EVHg4WywAPo3ik8uCOD7dz96c0ZM else SxN0jnqr3LI(plSscrVjkRviPwm)
		if n7neb9KTv10FcU and isinstance(NrxJjXU4ECt9Iue6ZqR8QFhHBw,unicode): NrxJjXU4ECt9Iue6ZqR8QFhHBw = NrxJjXU4ECt9Iue6ZqR8QFhHBw.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		if GV3ov2wm6WlMx: NrxJjXU4ECt9Iue6ZqR8QFhHBw = NrxJjXU4ECt9Iue6ZqR8QFhHBw.split(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪ࠳ࠬᅧ"))[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		wb35OyQtordxYE7Fe = str(szmD9nEACSWOyk15fPl0QZoTv)+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡡࡴࠨࠡࠩᅨ")+NrxJjXU4ECt9Iue6ZqR8QFhHBw+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࠦࠩࠨᅩ")
		if XqLr3B9MPx in [-vkIa3ijEQVsJGdWOXwK7bnue9ADR,-QQSugEIn2mTCpRsfcaJHhPdAWzylM] or wjSstJ9KD8IhAgrzcyiuP or pL90NVf3ZXjUW7PlydQgI8Oz or IRydSNiaH0653GU or t3giwaVDy2rhxjLvQPn5E or srTYNyzHUWq6FCpQSj:
			KXFGbQxMAgBRYh.code = -ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			KXFGbQxMAgBRYh.reason = szmD9nEACSWOyk15fPl0QZoTv
			if Xg3b5p4NdQiBa7Vn:
				BiPjyGwzW9MJfvdFhT1gx26aNDel = mbxMtagQ5Nkl7wGTYDIZWK36yE(hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv)
				if BiPjyGwzW9MJfvdFhT1gx26aNDel.succeeded: return BiPjyGwzW9MJfvdFhT1gx26aNDel
		oyNUHM3uQq = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if (slg0MoqUyXDtVp5cIFfdiRvJ==bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡁࡔࡍࠪᅪ") or EVzcAfpnQ1twxiO7bBjNM4DuW9r==cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡂࡕࡎࠫᅫ")) and (en8KBhPvWxuOFfkqiNL5TCIgY or Xg3b5p4NdQiBa7Vn):
			oyNUHM3uQq = ATgivCW6tZwuBHkmNKc(XqLr3B9MPx,wb35OyQtordxYE7Fe,eg6iV4ckQxvTrjWKyBulYR,rphN9x37cLm5VKHjz401TuW6yfSeQ)
			if oyNUHM3uQq and slg0MoqUyXDtVp5cIFfdiRvJ==fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡃࡖࡏࠬᅬ"): slg0MoqUyXDtVp5cIFfdiRvJ = bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫᅭ")
			else: slg0MoqUyXDtVp5cIFfdiRvJ = ulAxHwvzR9eTb5n(u"ࠪࡖࡊࡐࡅࡄࡖࡈࡈࠬᅮ")
			if oyNUHM3uQq and EVzcAfpnQ1twxiO7bBjNM4DuW9r==ulAxHwvzR9eTb5n(u"ࠫࡆ࡙ࡋࠨᅯ"): EVzcAfpnQ1twxiO7bBjNM4DuW9r = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧᅰ")
			else: EVzcAfpnQ1twxiO7bBjNM4DuW9r = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨᅱ")
			llnG7jiQBYKhAeovbT.setSetting(IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᅲ"),slg0MoqUyXDtVp5cIFfdiRvJ)
			llnG7jiQBYKhAeovbT.setSetting(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭ᅳ"),EVzcAfpnQ1twxiO7bBjNM4DuW9r)
		if oyNUHM3uQq:
			if XqLr3B9MPx==I3cxjYaHhsrM7T4UX26klN(u"࠻ᒡ") and CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩ࡫ࡸࡹࡶࡳࠨᅴ") in plSscrVjkRviPwm and TE1d3pveiGQS:
				if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(ulAxHwvzR9eTb5n(u"ࠪฮๆ฿๊ๅࠢไัฺࠦิ่ษาอࠥอไหึไ๎ึࠦࡓࡔࡎࠪᅵ"),X1mRwt2YJKgCLu9a67(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᅶ"),lQMuw1PvVpAk=CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠶࠵࠶࠰ᒢ"))
				zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᅷ")
				XoP5dRbLCpM7mIjw9E0YcKn8 = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,zb2QIaL7Y4h9g8lSck,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,rphN9x37cLm5VKHjz401TuW6yfSeQ,fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕ࠰࠶ࡳࡪࠧᅸ"))
				if XoP5dRbLCpM7mIjw9E0YcKn8.succeeded:
					KXFGbQxMAgBRYh = XoP5dRbLCpM7mIjw9E0YcKn8
					fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡵࡴ࡫ࡱ࡫࡙ࠥࡓࡍ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᅹ")+eg6iV4ckQxvTrjWKyBulYR+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᅺ")+qxZiT6WJ7sX+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࠣࡡࠬᅻ"))
					if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(tM24jD1gO0(u"๊ࠪัออࠡสสืฯิฯศ็ࠣࡗࡘࡒࠧᅼ"),flDSRbv57PnV3(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᅽ"),lQMuw1PvVpAk=bnI4kmPtrW7yFEhljXOCq9(u"࠷࠶࠰࠱ᒣ"))
				else:
					fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+tM24jD1gO0(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡔࡕࡏ࠾ࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᅾ")+eg6iV4ckQxvTrjWKyBulYR+SSvu1CZjTW7FcloNqD(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᅿ")+qxZiT6WJ7sX+X1mRwt2YJKgCLu9a67(u"ࠧࠡ࡟ࠪᆀ"))
					if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨใื่ࠥฮวิฬัำฬ๋ࠠࡔࡕࡏࠫᆁ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᆂ"),lQMuw1PvVpAk=qrjy8LuKVPNYdbSvzh(u"࠸࠰࠱࠲ᒤ"))
			if not KXFGbQxMAgBRYh.succeeded and EVzcAfpnQ1twxiO7bBjNM4DuW9r in [SSvu1CZjTW7FcloNqD(u"ࠪࡅ࡚࡚ࡏࠨᆃ"),bYyKEjIuGQzoq3AR1(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᆄ")] and Xg3b5p4NdQiBa7Vn:
				if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬะแฺ์็ࠤุ๐ัโำสฮࠥฮั้ๅึ๎ࠬᆅ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆆ"),lQMuw1PvVpAk=q4izXt0sjIQSZcHVAf3EmKRbx(u"࠲࠱࠲࠳ᒥ"))
				XoP5dRbLCpM7mIjw9E0YcKn8 = gjuezhF7pckGb(hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR)
				if XoP5dRbLCpM7mIjw9E0YcKn8.succeeded:
					KXFGbQxMAgBRYh = XoP5dRbLCpM7mIjw9E0YcKn8
					fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bYyKEjIuGQzoq3AR1(u"ࠧࠡࠢࠣࡔࡷࡵࡸࡪࡧࡶࠤࡸࡻࡣࡤࡧࡨࡨࡪࡪ࠺ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧᆇ")+eg6iV4ckQxvTrjWKyBulYR+DJ6ugPjW9bX8I(u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᆈ")+qxZiT6WJ7sX+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࠣࡡࠬᆉ"))
					if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(t4txivgXSUWBOlCakQmNDjf(u"๊ࠪัออࠡีํีๆืวหࠢหีํ้ำ๋ࠩᆊ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"้ࠫหีๅษะࠤฺ๊ใๅหࠣห้หๆหำ้๎ฯ࠭ᆋ"),lQMuw1PvVpAk=IINBvuxkCSJrO1Q0UyngdLi(u"࠳࠲࠳࠴ᒦ"))
				else:
					fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+YayJj10OGl(u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡩࡥ࡮ࡲࡥࡥ࠼ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩᆌ")+eg6iV4ckQxvTrjWKyBulYR+xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᆍ")+qxZiT6WJ7sX+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࠡ࡟ࠪᆎ"))
					if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(bYyKEjIuGQzoq3AR1(u"ࠨใืู่๊ࠥาใิหฯࠦศา๊ๆื๏࠭ᆏ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫᆐ"),lQMuw1PvVpAk=X60YQOADpkHBb31LiR5qUEKfM(u"࠴࠳࠴࠵ᒧ"))
			if not KXFGbQxMAgBRYh.succeeded and slg0MoqUyXDtVp5cIFfdiRvJ in [CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡅ࡚࡚ࡏࠨᆑ"),t4txivgXSUWBOlCakQmNDjf(u"ࠫࡆࡉࡃࡆࡒࡗࡉࡉ࠭ᆒ")] and en8KBhPvWxuOFfkqiNL5TCIgY:
				if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(t4txivgXSUWBOlCakQmNDjf(u"ࠬะแฺ์็ࠤุ๐ัโำࠣࡈࡓ࡙ࠧᆓ"),flDSRbv57PnV3(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆔ"),lQMuw1PvVpAk=tM24jD1gO0(u"࠵࠴࠵࠶ᒨ"))
				zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm+IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬᆕ")
				XoP5dRbLCpM7mIjw9E0YcKn8 = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,zb2QIaL7Y4h9g8lSck,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,rphN9x37cLm5VKHjz401TuW6yfSeQ,IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠲࠺ࡴࡩࠩᆖ"))
				if XoP5dRbLCpM7mIjw9E0YcKn8.succeeded:
					KXFGbQxMAgBRYh = XoP5dRbLCpM7mIjw9E0YcKn8
					fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠣࠤࠥࡊࡎࡔࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡆࡑࡗ࠿࡛ࠦࠡࠩᆗ")+KdNWSOYLiu1zF4xwXblqpv8RsAm0gT+l4DS8mnEjHhFMZ5YOe(u"ࠪࠤࡢࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬᆘ")+eg6iV4ckQxvTrjWKyBulYR+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪᆙ")+qxZiT6WJ7sX+UpQ56M0dO1N9xIvVegy(u"ࠬࠦ࡝ࠨᆚ"))
					if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ๆอษะࠤุ๐ัโำࠣࡈࡓ࡙ࠧᆛ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩᆜ"),lQMuw1PvVpAk=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠶࠵࠶࠰ᒩ"))
				else:
					fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+Fo1SgXMsHk(u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬᆝ")+KdNWSOYLiu1zF4xwXblqpv8RsAm0gT+z3sIGH8jmLYg(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆞ")+eg6iV4ckQxvTrjWKyBulYR+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᆟ")+qxZiT6WJ7sX+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࠥࡣࠧᆠ"))
					if rphN9x37cLm5VKHjz401TuW6yfSeQ: SSVCGE0bOfW1w9u52yvBxocNeP(SSvu1CZjTW7FcloNqD(u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬᆡ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨᆢ"),lQMuw1PvVpAk=l4DS8mnEjHhFMZ5YOe(u"࠷࠶࠰࠱ᒪ"))
		if EVzcAfpnQ1twxiO7bBjNM4DuW9r==QlTuvPbSpnjygBVW(u"ࠧࡓࡇࡍࡉࡈ࡚ࡅࡅࠩᆣ") or slg0MoqUyXDtVp5cIFfdiRvJ==fgv5U2eRVaQqSiuGD(u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪᆤ"): rphN9x37cLm5VKHjz401TuW6yfSeQ = SmbNGskjMx
		if not KXFGbQxMAgBRYh.succeeded:
			if rphN9x37cLm5VKHjz401TuW6yfSeQ: rsYWjvmXn4SZzOkgCuwUldVhKc9DJB = ATgivCW6tZwuBHkmNKc(XqLr3B9MPx,wb35OyQtordxYE7Fe,eg6iV4ckQxvTrjWKyBulYR,rphN9x37cLm5VKHjz401TuW6yfSeQ)
			if XqLr3B9MPx!=QlTuvPbSpnjygBVW(u"࠸࠰࠱ᒫ") and eg6iV4ckQxvTrjWKyBulYR not in W7gN5jFqiE and flDSRbv57PnV3(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࠭ᆥ") not in eg6iV4ckQxvTrjWKyBulYR: R5VzflU0D2LQaSoKOskBuYtrXFC()
	if llnG7jiQBYKhAeovbT.getSetting(SSvu1CZjTW7FcloNqD(u"ࠪࡥࡻ࠴ࡳࡵࡣࡷࡹࡸ࠴ࡵࡴࡧࡧࡲࡸ࠭ᆦ")) not in [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡆ࡛ࡔࡐࠩᆧ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࡙ࠬࡔࡐࡒࠪᆨ"),flDSRbv57PnV3(u"࠭ࡁࡔࡍࠪᆩ")]: llnG7jiQBYKhAeovbT.setSetting(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪᆪ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡃࡖࡏࠬᆫ"))
	if llnG7jiQBYKhAeovbT.getSetting(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡲࡵࡳࡽࡿࠧᆬ")) not in [SSvu1CZjTW7FcloNqD(u"ࠪࡅ࡚࡚ࡏࠨᆭ"),fgv5U2eRVaQqSiuGD(u"ࠫࡘ࡚ࡏࡑࠩᆮ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡇࡓࡌࠩᆯ")]: llnG7jiQBYKhAeovbT.setSetting(ulAxHwvzR9eTb5n(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡸࡷࡪࡶࡲࡰࡺࡼࠫᆰ"),qrjy8LuKVPNYdbSvzh(u"ࠧࡂࡕࡎࠫᆱ"))
	return KXFGbQxMAgBRYh
def ZyCRXGxuMlqeNIjHV9(website,WYRtS45QopB67VDG,SgHk3zFaVPUluqoRsYXO7IB=None):
	wwoFQ2zkSTEbVchyiKZU6 = z3sIGH8jmLYg(u"࠱࠱ᒬ")
	l3yc6rWTfZqKtpd = [X60YQOADpkHBb31LiR5qUEKfM(u"࠲ᒭ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠲ᒭ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠲ᒭ"),t4txivgXSUWBOlCakQmNDjf(u"࠳࠳ᒮ"),fgv5U2eRVaQqSiuGD(u"࠸ᒯ"),t4txivgXSUWBOlCakQmNDjf(u"࠳࠳ᒮ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠲ᒭ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠲ᒭ"),X60YQOADpkHBb31LiR5qUEKfM(u"࠲ᒭ"),fgv5U2eRVaQqSiuGD(u"࠸ᒯ")]
	IjVB29vn3rFyX = XXl2tGoemr7Yd
	nh09FlJIcPdy3WpAKLS45a8i7Dg = []
	qqYCmxSDpWGcorE16uZ7 = [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠴ᒰ")]*wwoFQ2zkSTEbVchyiKZU6
	RjtAEsMI69oCXa = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡦ࡬ࡧࡹ࠭ᆲ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡖࡇࡗࡇࡐࡆࡔࡖࡣࡘ࡚ࡁࡕࡗࡖࠫᆳ"))
	for W7tEs8iD3uNarS6CQJeRMg9P0Yn in list(RjtAEsMI69oCXa.keys()):
		if website not in W7tEs8iD3uNarS6CQJeRMg9P0Yn: continue
		HMPtOcVoJiXCu8z0nesDWYkIl9ER,h3rZuybAVzjLfUWK6SB = W7tEs8iD3uNarS6CQJeRMg9P0Yn.split(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡣࡤ࠭ᆴ"))
		qqYCmxSDpWGcorE16uZ7[int(h3rZuybAVzjLfUWK6SB)] = RjtAEsMI69oCXa[W7tEs8iD3uNarS6CQJeRMg9P0Yn]
	for ablZij8g2sVkIB4m1pTKz3qEtx in range(wwoFQ2zkSTEbVchyiKZU6):
		if ablZij8g2sVkIB4m1pTKz3qEtx in IjVB29vn3rFyX+WYRtS45QopB67VDG: continue
		if ablZij8g2sVkIB4m1pTKz3qEtx==SgHk3zFaVPUluqoRsYXO7IB: qqYCmxSDpWGcorE16uZ7[ablZij8g2sVkIB4m1pTKz3qEtx] = qqYCmxSDpWGcorE16uZ7[ablZij8g2sVkIB4m1pTKz3qEtx]+SSvu1CZjTW7FcloNqD(u"࠶ᒱ")
		if qqYCmxSDpWGcorE16uZ7[ablZij8g2sVkIB4m1pTKz3qEtx]<usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠹ᒲ"): nh09FlJIcPdy3WpAKLS45a8i7Dg += [ablZij8g2sVkIB4m1pTKz3qEtx]*l3yc6rWTfZqKtpd[ablZij8g2sVkIB4m1pTKz3qEtx]
	if not nh09FlJIcPdy3WpAKLS45a8i7Dg:
		for ablZij8g2sVkIB4m1pTKz3qEtx in range(wwoFQ2zkSTEbVchyiKZU6):
			qqYCmxSDpWGcorE16uZ7[ablZij8g2sVkIB4m1pTKz3qEtx] = bnI4kmPtrW7yFEhljXOCq9(u"࠰ᒳ")
			if ablZij8g2sVkIB4m1pTKz3qEtx in IjVB29vn3rFyX+WYRtS45QopB67VDG: continue
			nh09FlJIcPdy3WpAKLS45a8i7Dg += [ablZij8g2sVkIB4m1pTKz3qEtx]*l3yc6rWTfZqKtpd[ablZij8g2sVkIB4m1pTKz3qEtx]
	for ablZij8g2sVkIB4m1pTKz3qEtx in IjVB29vn3rFyX: qqYCmxSDpWGcorE16uZ7[ablZij8g2sVkIB4m1pTKz3qEtx] = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠺࠻࠼࠽ᒴ")
	LIcB8xRFtA5D2 = []
	for ablZij8g2sVkIB4m1pTKz3qEtx in range(wwoFQ2zkSTEbVchyiKZU6): LIcB8xRFtA5D2.append(website+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࡤࡥࠧᆵ")+str(ablZij8g2sVkIB4m1pTKz3qEtx))
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࡙ࠬࡃࡓࡃࡓࡉࡗ࡙࡟ࡔࡖࡄࡘ࡚࡙ࠧᆶ"),LIcB8xRFtA5D2,qqYCmxSDpWGcorE16uZ7,Vs0Rwzrn3cKO5PhLio6Q2e*usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠷ᒵ"),Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return nh09FlJIcPdy3WpAKLS45a8i7Dg
def mbxMtagQ5Nkl7wGTYDIZWK36yE(hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv,WYRtS45QopB67VDG=[]):
	SSVCGE0bOfW1w9u52yvBxocNeP(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ศะลอࠤ฾๋ไ๋หࠣฮัอ่ำࠢส่าาศࠨᆷ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,lQMuw1PvVpAk=yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠺࠹࠵ᒶ"))
	fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࡦࡾࡶࡡࡴࡵࠣࡦࡱࡵࡣ࡬࡫ࡱ࡫ࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩᆸ")+str(XqLr3B9MPx)+IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࠢࡠࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᆹ")+szmD9nEACSWOyk15fPl0QZoTv+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫᆺ")+eg6iV4ckQxvTrjWKyBulYR+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࠤࡢࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᆻ")+plSscrVjkRviPwm+l4DS8mnEjHhFMZ5YOe(u"ࠫࠥࡣࠧᆼ"))
	website = eg6iV4ckQxvTrjWKyBulYR.split(IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࠳ࠧᆽ"))[f4fTutDOEwUeIoPLRQ]
	Og3U6MDFpeKPfmtCw9qbRkaIZu8 = ZyCRXGxuMlqeNIjHV9(website,WYRtS45QopB67VDG)
	DWeKu2Gsi84PbUEfhMwVNjloqg = []
	if website==SSvu1CZjTW7FcloNqD(u"࠭ࡆࡂࡕࡈࡐࡍࡊ࠱ࠨᆾ"):
		if f4fTutDOEwUeIoPLRQ in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [f4fTutDOEwUeIoPLRQ]
		if vkIa3ijEQVsJGdWOXwK7bnue9ADR in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		if QQSugEIn2mTCpRsfcaJHhPdAWzylM in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		if ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]*paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠵࠵ᒷ")
		if WtDrnpJmwQ37Z2Ae68hu4BY5M1 in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [WtDrnpJmwQ37Z2Ae68hu4BY5M1]*wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠺ᒸ")
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"࠵ᒺ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [q4izXt0sjIQSZcHVAf3EmKRbx(u"࠵ᒺ")]*l4DS8mnEjHhFMZ5YOe(u"࠷࠰ᒹ")
		if bYyKEjIuGQzoq3AR1(u"࠷ᒻ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [bYyKEjIuGQzoq3AR1(u"࠷ᒻ")]
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"࠹ᒼ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [q4izXt0sjIQSZcHVAf3EmKRbx(u"࠹ᒼ")]
	elif website==YayJj10OGl(u"ࠧࡔࡊࡄࡌࡎࡊ࠴ࡖࠩᆿ"):
		if ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]*yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠴࠴ᒽ")
	elif website==cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡅࡌࡑࡆ࡝ࡂࡂࡕࠪᇀ"):
		if vkIa3ijEQVsJGdWOXwK7bnue9ADR in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		if WtDrnpJmwQ37Z2Ae68hu4BY5M1 in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [WtDrnpJmwQ37Z2Ae68hu4BY5M1]*YayJj10OGl(u"࠹ᒾ")
		if z3sIGH8jmLYg(u"࠻ᓀ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [z3sIGH8jmLYg(u"࠻ᓀ")]*O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠶࠶ᒿ")
		if usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠶ᓁ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠶ᓁ")]
		if fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠸ᓂ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠸ᓂ")]
	elif website==YayJj10OGl(u"ࠩࡆࡍࡒࡇࡌࡊࡉࡋࡘࠬᇁ"):
		if WtDrnpJmwQ37Z2Ae68hu4BY5M1 in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [WtDrnpJmwQ37Z2Ae68hu4BY5M1]*YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠷ᓃ")
		if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠹ᓅ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠹ᓅ")]*cb3rmvAn4wa6lBPz2phOoYqX(u"࠴࠴ᓄ")
	elif website==SSvu1CZjTW7FcloNqD(u"࡛ࠪࡊࡉࡉࡎࡃ࠴ࠫᇂ"):
		if YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠾ᓆ") in Og3U6MDFpeKPfmtCw9qbRkaIZu8: DWeKu2Gsi84PbUEfhMwVNjloqg += [YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠾ᓆ")]*flDSRbv57PnV3(u"࠻ᓇ")
	if DWeKu2Gsi84PbUEfhMwVNjloqg: Og3U6MDFpeKPfmtCw9qbRkaIZu8 = DWeKu2Gsi84PbUEfhMwVNjloqg
	if Og3U6MDFpeKPfmtCw9qbRkaIZu8:
		MAq4TcsHXYEOd = eH7yw1hTGUROK2B4dcP0iEr.sample(Og3U6MDFpeKPfmtCw9qbRkaIZu8,vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
	else: MAq4TcsHXYEOd = -vkIa3ijEQVsJGdWOXwK7bnue9ADR
	update = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if MAq4TcsHXYEOd==f4fTutDOEwUeIoPLRQ:
		scraperserver = ulAxHwvzR9eTb5n(u"ࠫࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠱ࠨᇃ")
		J5gRvAifj87xsz = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡣࡳࡣࡳࡩࡴࡶࡳ࠯࡭ࡨࡩࡵࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡕࡴࡸࡩ࠳ࡩ࡯ࡶࡰࡷࡶࡾࡃࡩ࡭࠼࠴࠹࠵ࡪ࠲࠳ࡨ࠴࠱ࡨ࠻࠸ࡢ࠯࠷࠴࠷࠷࠭ࡢࡣ࠻࠸࠲࡫࠹࠳࠵ࡦࡥ࡫࠾࠵࠹࠵࠷ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠴ࡩࡰ࠼࠸࠷࠺࠹ࠧᇄ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+SSvu1CZjTW7FcloNqD(u"࠭ࡼࡽࡏࡼࡔࡷࡵࡸࡺࡗࡵࡰࡂ࠭ᇅ")+J5gRvAifj87xsz+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡽࡾࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧᇆ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		scraperserver = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡵࡦࡶࡦࡶࡥࡰࡲࡶ࠶ࠬᇇ")
		J5gRvAifj87xsz = Fo1SgXMsHk(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡧࡷࡧࡰࡦࡱࡳࡷ࠳ࡱࡥࡦࡲࡢ࡬ࡪࡧࡤࡦࡴࡶࡁ࡙ࡸࡵࡦ࠰ࡦࡳࡺࡴࡴࡳࡻࡀ࡭ࡱࡀ࠳࠺࠻࠴ࡩ࠾ࡩ࠵࠮࠹ࡨࡩ࠸࠳࠴ࡦࡧ࠵࠱࠽࠺ࡣ࠱࠯ࡩࡨ࠼࠿࠲ࡣࡣࡧࡨ࠸ࡪ࠵ࡁࡲࡵࡳࡽࡿ࠮ࡴࡥࡵࡥࡵ࡫࡯ࡱࡵ࠱࡭ࡴࡀ࠵࠴࠷࠶ࠫᇈ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࢀࢁࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪᇉ")+J5gRvAifj87xsz+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࢁࢂࡎࡰࡘࡨࡶ࡮࡬ࡹࡔࡕࡏࠫᇊ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==QQSugEIn2mTCpRsfcaJHhPdAWzylM:
		scraperserver = YayJj10OGl(u"ࠬࡹࡣࡳࡣࡳࡩࡷࡧࡰࡪࠩᇋ")
		J5gRvAifj87xsz = xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫࠱࡯ࡪ࡫ࡰࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠮ࡤࡱࡸࡲࡹࡸࡹࡠࡥࡲࡨࡪࡃࡩ࡭࠼࠺࠺ࡧ࠺ࡦࡤ࠵࠷ࡪࡨࡪ࠱࠺ࡦ࠼ࡧ࠺࠻ࡡ࠲࠷ࡩ࠷࠻࠶࠴ࡤࡦ࠼࠵࠹ࡩࡀࡱࡴࡲࡼࡾ࠳ࡳࡦࡴࡹࡩࡷ࠴ࡳࡤࡴࡤࡴࡪࡸࡡࡱ࡫࠱ࡧࡴࡳ࠺࠹࠲࠳࠵ࠬᇌ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᇍ")+J5gRvAifj87xsz+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇎ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb:
		scraperserver = I3cxjYaHhsrM7T4UX26klN(u"ࠩࡶࡧࡷࡧࡰࡦࡷࡳࠫᇏ")
		zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm.replace(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬᇐ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠬᇑ"))
		jYzLtvxkH7R3msNZwhgeT90noEu5q = ulAxHwvzR9eTb5n(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡧࡷࡧࡰࡦࡷࡳ࠲ࡨࡵ࡭࠰ࡁࡤࡴ࡮ࡥ࡫ࡦࡻࡀ࠵࡛ࡔࡳࡎࡶࡏ࠵ࡴࡈࡒ࡙࡭ࡖࡒࡈࡨࡃࡎࡌ࠴ࡏ࡝࡟ࡊ࡫࡬࠳ࡨ࡯ࡠࡷࠧ࡭ࡨࡩࡵࡥࡨࡦࡣࡧࡩࡷࡹ࠽ࡇࡣ࡯ࡷࡪࠬࡣࡰࡷࡱࡸࡷࡿ࡟ࡤࡱࡧࡩࡂ࡯࡬ࠧࡷࡵࡰࡂ࠭ᇒ")+lcxFAteLQ1Pwu45Er2(zb2QIaL7Y4h9g8lSck)
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡇࡆࡖࠪᇓ"),jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==WtDrnpJmwQ37Z2Ae68hu4BY5M1:
		scraperserver = I3cxjYaHhsrM7T4UX26klN(u"ࠧࡴࡥࡵࡥࡵ࡯࡮ࡨࡴࡲࡦࡴࡺࠧᇔ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = z3sIGH8jmLYg(u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡲࡰࡤࡲࡸ࠳ࡩ࡯࡮࠱ࡂࡸࡴࡱࡥ࡯࠿ࡤ࠸࡫࠽ࡦࡣ࠳࠷࠱࠷ࡪࡥࡧ࠯࠷࠴࠼࠷࠭࠹࠸࠷ࡦ࠲࠸࠲ࡦ࠵࠵࠺࠹ࡪ࠴ࡥࡦࡦࠪࡵࡸ࡯ࡹࡻࡆࡳࡺࡴࡴࡳࡻࡀࡍࡑࠬࡵࡳ࡮ࡀࠫᇕ")+lcxFAteLQ1Pwu45Er2(plSscrVjkRviPwm)
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡊࡉ࡙࠭ᇖ"),jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
		try:
			BiPjyGwzW9MJfvdFhT1gx26aNDel.content = dr1zfnatJxRHSF48jh0eODm5bGu(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡨ࡮ࡩࡴࠨᇗ"),BiPjyGwzW9MJfvdFhT1gx26aNDel.content)
			BiPjyGwzW9MJfvdFhT1gx26aNDel.content = BiPjyGwzW9MJfvdFhT1gx26aNDel.content[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᇘ")]
		except: pass
	elif MAq4TcsHXYEOd==X60YQOADpkHBb31LiR5qUEKfM(u"࠵ᓈ"):
		scraperserver = l4DS8mnEjHhFMZ5YOe(u"ࠬࡹࡣࡳࡣࡳ࡭ࡳ࡭ࡡ࡯ࡶ࠴ࠫᇙ")
		J5gRvAifj87xsz = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷࠪࡵࡸ࡯ࡹࡻࡢࡧࡴࡻ࡮ࡵࡴࡼࡁࡎࡒࠦࡣࡴࡲࡻࡸ࡫ࡲ࠾ࡈࡤࡰࡸ࡫ࠦࡧࡱࡵࡻࡦࡸࡤࡠࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫࠺࠳ࡤ࠶࠸࠵ࡧ࠶࠹࠻࠳ࡥ࠺࠺࠰࠲ࡦࡥࡧ࠸࠽࠲ࡤ࠳࠴࠸࠺ࡪ࠹࠷࠴ࡨ࠼ࡅࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲ࡬ࡲ࡬ࡧ࡮ࡵ࠰ࡦࡳࡲࡀ࠸࠱࠺࠳ࠫᇚ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧᇛ")+J5gRvAifj87xsz+UpQ56M0dO1N9xIvVegy(u"ࠨࡾࡿࡒࡴ࡜ࡥࡳ࡫ࡩࡽࡘ࡙ࡌࠨᇜ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==DJ6ugPjW9bX8I(u"࠷ᓉ"):
		scraperserver = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡶࡧࡷࡧࡰࡦ࠰ࡧࡳ࠶࠭ᇝ")
		J5gRvAifj87xsz = bYyKEjIuGQzoq3AR1(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡨ࠸࠶࠴ࡣࡥ࠵ࡪ࠻࠰࠵࠶ࡧ࠶ࡨࡧ࠵ࡥ࠷ࡧ࠷࡫࠿ࡥ࠴ࡥ࠶࠼࠻࡫ࡣࡢ࠳࠴࠴࠽࠹࠸࠺ࡣ࠺࠷࠿ࡩࡵࡴࡶࡲࡱࡍ࡫ࡡࡥࡧࡵࡷࡂ࡚ࡲࡶࡧࠩ࡫ࡪࡵࡃࡰࡦࡨࡁ࡮ࡲࡀࡱࡴࡲࡼࡾ࠴ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠼࠻࠴࠽࠶ࠧᇞ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+t4txivgXSUWBOlCakQmNDjf(u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫᇟ")+J5gRvAifj87xsz+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࢂࡼࡏࡱ࡙ࡩࡷ࡯ࡦࡺࡕࡖࡐࠬᇠ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠹ᓊ"):
		scraperserver = UpQ56M0dO1N9xIvVegy(u"࠭ࡳࡤࡴࡤࡴࡪ࠴ࡤࡰ࠴ࠪᇡ")
		J5gRvAifj87xsz = z3sIGH8jmLYg(u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲ࡥ࠶ࡨ࠸ࡧࡥ࠲࠺࠸ࡨ࡫࠺ࡢࡧ࠸ࡤࡪ࠺࠹࠳ࡤ࠹࠳࠸࠵ࡨ࠳࠵࠹ࡦ࠽ࡪ࠿࠹ࡣࡧ࠷࠺࠻ࡧࡥ࠺࠼ࡦࡹࡸࡺ࡯࡮ࡊࡨࡥࡩ࡫ࡲࡴ࠿ࡗࡶࡺ࡫ࠦࡨࡧࡲࡇࡴࡪࡥ࠾࡫࡯ࡄࡵࡸ࡯ࡹࡻ࠱ࡷࡨࡸࡡࡱࡧ࠱ࡨࡴࡀ࠸࠱࠺࠳ࠫᇢ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇣ")+J5gRvAifj87xsz+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇤ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==X1mRwt2YJKgCLu9a67(u"࠻ᓋ"):
		scraperserver = Fo1SgXMsHk(u"ࠪࡷࡨࡸࡡࡱࡧࡲࡴࡸ࠹ࠧᇥ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = flDSRbv57PnV3(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡲࡰࡺࡼ࠲ࡸࡩࡲࡢࡲࡨࡳࡵࡹ࠮ࡪࡱ࠲ࡺ࠶࠵࠿ࡢࡲ࡬ࡣࡰ࡫ࡹ࠾࠵࠼࠽࠶࡫࠹ࡤ࠷࠰࠻ࡪ࡫࠳࠮࠶ࡨࡩ࠷࠳࠸࠵ࡥ࠳࠱࡫ࡪ࠷࠺࠴ࡥࡥࡩࡪ࠳ࡥ࠷ࠩࡧࡴࡻ࡮ࡵࡴࡼࡁ࡮ࡲࠦࡶࡴ࡯ࡁࠬᇦ")+lcxFAteLQ1Pwu45Er2(plSscrVjkRviPwm)
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡍࡅࡕࠩᇧ"),jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	elif MAq4TcsHXYEOd==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠽ᓌ"):
		scraperserver = fgv5U2eRVaQqSiuGD(u"࠭ࡳࡤࡴࡤࡴ࡮ࡴࡧࡢࡰࡷ࠶ࠬᇨ")
		J5gRvAifj87xsz = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡥࡵࡥࡵ࡯࡮ࡨࡣࡱࡸࠫࡶࡲࡰࡺࡼࡣࡨࡵࡵ࡯ࡶࡵࡽࡂࡇࡅࠧࡴࡨࡸࡺࡸ࡮ࡠࡲࡤ࡫ࡪࡥࡳࡰࡷࡵࡧࡪࡃࡴࡳࡷࡨࠪ࡫ࡵࡲࡸࡣࡵࡨࡤ࡮ࡥࡢࡦࡨࡶࡸࡃࡴࡳࡷࡨ࠾࠷ࡨ࠳࠵࠲ࡤ࠺࠽࠿࠰ࡢ࠷࠷࠴࠶ࡪࡢࡤ࠵࠺࠶ࡨ࠷࠱࠵࠷ࡧ࠽࠻࠸ࡥ࠹ࡂࡳࡶࡴࡾࡹ࠯ࡵࡦࡶࡦࡶࡩ࡯ࡩࡤࡲࡹ࠴ࡣࡰ࡯࠽࠼࠵࠾࠰ࠨᇩ")
		jYzLtvxkH7R3msNZwhgeT90noEu5q = plSscrVjkRviPwm+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨᇪ")+J5gRvAifj87xsz+Fo1SgXMsHk(u"ࠩࡿࢀࡓࡵࡖࡦࡴ࡬ࡪࡾ࡙ࡓࡍࠩᇫ")
		BiPjyGwzW9MJfvdFhT1gx26aNDel = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,jYzLtvxkH7R3msNZwhgeT90noEu5q,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,SmbNGskjMx,SmbNGskjMx)
	else:
		scraperserver,jYzLtvxkH7R3msNZwhgeT90noEu5q = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
		BiPjyGwzW9MJfvdFhT1gx26aNDel = zJpU8hfZnevcG()
		update = SmbNGskjMx
	if update and not BiPjyGwzW9MJfvdFhT1gx26aNDel.succeeded:
		ZyCRXGxuMlqeNIjHV9(website,[],MAq4TcsHXYEOd)
		if len(list(set(Og3U6MDFpeKPfmtCw9qbRkaIZu8)))>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᇬ"),bYyKEjIuGQzoq3AR1(u"้๊ࠫริใࠣื๏ืแา่ࠢ฽ฬ๊ฬสࠢส่าาศࠡำๅ้ࠥ࠭ᇭ")+str(MAq4TcsHXYEOd)+qrjy8LuKVPNYdbSvzh(u"ࠬࠦแีๆࠣๅ๏ูࠦๆๆํอࠥะฬศ๊ีࠤฬ๊ออสࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠๆฯส์้ฯࠠหฮส์ืࠦวๅฯฯฬ๋ࠥัสࠢฦาึ๏ࠠษษึฮำีวๆࠢึ๎ึ็ัࠡ็ัฮ้็ࠠภࠣࠪᇮ"))
			if oyNUHM3uQq==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				WYRtS45QopB67VDG.append(MAq4TcsHXYEOd)
				BiPjyGwzW9MJfvdFhT1gx26aNDel = mbxMtagQ5Nkl7wGTYDIZWK36yE(hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,ePaz4qTOvkyQtUEncDw6iJGV0Fp,rphN9x37cLm5VKHjz401TuW6yfSeQ,eg6iV4ckQxvTrjWKyBulYR,XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv,WYRtS45QopB67VDG)
				return BiPjyGwzW9MJfvdFhT1gx26aNDel
	BiPjyGwzW9MJfvdFhT1gx26aNDel.scrapernumber = str(MAq4TcsHXYEOd)
	BiPjyGwzW9MJfvdFhT1gx26aNDel.scraperserver = scraperserver
	BiPjyGwzW9MJfvdFhT1gx26aNDel.scraperurl = jYzLtvxkH7R3msNZwhgeT90noEu5q
	nHKCi7l98avd54QEMtpSVjPsWhwX = ulAxHwvzR9eTb5n(u"࠭ำ๋ำไีࠥืโๆࠢࠪᇯ")+BiPjyGwzW9MJfvdFhT1gx26aNDel.scrapernumber
	if BiPjyGwzW9MJfvdFhT1gx26aNDel.succeeded:
		fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡧࡧࡩࡩࠦࡢࡺࡲࡤࡷࡸࠦࡢ࡭ࡱࡦ࡯࡮ࡴࡧࠡࠢࠣࡗࡪࡸࡶࡦࡴ࠽ࠤࡠࠦࠧᇰ")+scraperserver+DJ6ugPjW9bX8I(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᇱ")+eg6iV4ckQxvTrjWKyBulYR+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᇲ")+plSscrVjkRviPwm+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࠤࡢ࠭ᇳ"))
		SSVCGE0bOfW1w9u52yvBxocNeP(tM24jD1gO0(u"๋ࠫาอหࠢ฼้้๐ษࠡฬฯหํุࠠศๆะะอ࠭ᇴ"),nHKCi7l98avd54QEMtpSVjPsWhwX,lQMuw1PvVpAk=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠼࠻࠰ᓍ"))
	else:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡤࡼࡴࡦࡹࡳࠡࡤ࡯ࡳࡨࡱࡩ࡯ࡩࠣࠤ࡙ࠥࡥࡳࡸࡨࡶ࠿࡛ࠦࠡࠩᇵ")+scraperserver+ulAxHwvzR9eTb5n(u"࠭ࠠ࡞ࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭ᇶ")+str(BiPjyGwzW9MJfvdFhT1gx26aNDel.code)+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡢࡵࡲࡲ࠿࡛ࠦࠡࠩᇷ")+BiPjyGwzW9MJfvdFhT1gx26aNDel.reason+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪᇸ")+eg6iV4ckQxvTrjWKyBulYR+I3cxjYaHhsrM7T4UX26klN(u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᇹ")+plSscrVjkRviPwm+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࠤࡢ࠭ᇺ"))
		SSVCGE0bOfW1w9u52yvBxocNeP(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫๆฺไหࠢ฼้้๐ษࠡฬฯหํุࠠศๆะะอ࠭ᇻ"),nHKCi7l98avd54QEMtpSVjPsWhwX,lQMuw1PvVpAk=DJ6ugPjW9bX8I(u"࠽࠵࠱ᓎ"))
	return BiPjyGwzW9MJfvdFhT1gx26aNDel
def t57SmWGkHCXd4yq(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh=nbOFVEDkpT4BIR7Qq82yPmHeJU,PPpCE2Tu0edtVKg1U=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	plSscrVjkRviPwm,PB2EFL4DkoAnup7SajZq9GdRr,Thl3xtBje9dpPf6YsUoAyOzbL7Kk,WCrF2sGJaTRcZbI5n = VVRhJ5xaEkKCW(qxZiT6WJ7sX)
	try: HJr749RUIKauXfTCDNsbMt = ehWfDEbAtMTZaS5x.copy()
	except: HJr749RUIKauXfTCDNsbMt = ehWfDEbAtMTZaS5x
	EEZcU5jVnCeFk = hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,HJr749RUIKauXfTCDNsbMt,nl60jpTqCtDBoJfsuU7biMOc3wGNhV
	if mK4en38aY2UXly0rzZsoI6vMFQ5b<qrjy8LuKVPNYdbSvzh(u"࠰ᓏ"):
		uoxvtFlSXEPnf(SOEM49TbV0zuQ,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨᇼ"),EEZcU5jVnCeFk)
		mK4en38aY2UXly0rzZsoI6vMFQ5b = -mK4en38aY2UXly0rzZsoI6vMFQ5b
	if mK4en38aY2UXly0rzZsoI6vMFQ5b>q4izXt0sjIQSZcHVAf3EmKRbx(u"࠱ᓐ"):
		cA6C7PMTuUklQdfoYqZgXj2FrJN = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡲࡦࡵࡳࡳࡳࡹࡥࠨᇽ"),Fo1SgXMsHk(u"ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠪᇾ"),EEZcU5jVnCeFk)
		if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
			qvUe2bwfQ7sZKV(bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡔࡈࡕ࡚ࡋࡓࡕࡕࠣࠤࡗࡋࡁࡅࡡࡆࡅࡈࡎࡅࠨᇿ"),plSscrVjkRviPwm,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,eg6iV4ckQxvTrjWKyBulYR,hhyC3ID85J1uvxjFMi)
			return cA6C7PMTuUklQdfoYqZgXj2FrJN
	cA6C7PMTuUklQdfoYqZgXj2FrJN = MOpDGnv1WA3hTxeE2R(hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,nl60jpTqCtDBoJfsuU7biMOc3wGNhV,showDialogs,eg6iV4ckQxvTrjWKyBulYR,e0jTUtumPFaNh,PPpCE2Tu0edtVKg1U)
	if cA6C7PMTuUklQdfoYqZgXj2FrJN.succeeded:
		if X1mRwt2YJKgCLu9a67(u"ࠩࡆࡍࡒࡇࡎࡐ࡙ࠪሀ") in eg6iV4ckQxvTrjWKyBulYR: cA6C7PMTuUklQdfoYqZgXj2FrJN.content = NtZWe3LpRgnl29Vw(cA6C7PMTuUklQdfoYqZgXj2FrJN.content)
		if cA6C7PMTuUklQdfoYqZgXj2FrJN.scrape: mK4en38aY2UXly0rzZsoI6vMFQ5b = mmfpkVtUDjaq86eAuFzE0oxP
		if mK4en38aY2UXly0rzZsoI6vMFQ5b and cA6C7PMTuUklQdfoYqZgXj2FrJN.content: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,t4txivgXSUWBOlCakQmNDjf(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘ࠭ሁ"),EEZcU5jVnCeFk,cA6C7PMTuUklQdfoYqZgXj2FrJN,mK4en38aY2UXly0rzZsoI6vMFQ5b)
	return cA6C7PMTuUklQdfoYqZgXj2FrJN
def YmL4rcEjZIBU0wdC8Fv6qWPk(mK4en38aY2UXly0rzZsoI6vMFQ5b,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,showDialogs,eg6iV4ckQxvTrjWKyBulYR):
	if not qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC or isinstance(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,dict): hhyC3ID85J1uvxjFMi = I3cxjYaHhsrM7T4UX26klN(u"ࠫࡌࡋࡔࠨሂ")
	else:
		hhyC3ID85J1uvxjFMi = IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡖࡏࡔࡖࠪሃ")
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = SxN0jnqr3LI(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
		vqadojtCklmgyRneEwO,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = kJPjYVSCDE2(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
	cA6C7PMTuUklQdfoYqZgXj2FrJN = t57SmWGkHCXd4yq(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,Ag9l6cw3EBqP8HsQuGMizfOtr4,showDialogs,eg6iV4ckQxvTrjWKyBulYR)
	B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.content
	B69RXYW5vf8Jt7O = str(B69RXYW5vf8Jt7O)
	return B69RXYW5vf8Jt7O
def VVRhJ5xaEkKCW(qxZiT6WJ7sX):
	ppDRIuqohQlHZjskgCyv = qxZiT6WJ7sX.split(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡼࡽࠩሄ"))
	plSscrVjkRviPwm,PB2EFL4DkoAnup7SajZq9GdRr,Thl3xtBje9dpPf6YsUoAyOzbL7Kk,WCrF2sGJaTRcZbI5n = ppDRIuqohQlHZjskgCyv[f4fTutDOEwUeIoPLRQ],None,None,Ag9l6cw3EBqP8HsQuGMizfOtr4
	for EEZcU5jVnCeFk in ppDRIuqohQlHZjskgCyv:
		if z3sIGH8jmLYg(u"ࠧࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬህ") in EEZcU5jVnCeFk: PB2EFL4DkoAnup7SajZq9GdRr = EEZcU5jVnCeFk[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠳࠴ᓑ"):]
		elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫሆ") in EEZcU5jVnCeFk: Thl3xtBje9dpPf6YsUoAyOzbL7Kk = EEZcU5jVnCeFk[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠼ᓒ"):]
		elif usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡑࡳ࡛࡫ࡲࡪࡨࡼࡗࡘࡒࠧሇ") in EEZcU5jVnCeFk: WCrF2sGJaTRcZbI5n = SmbNGskjMx
	return plSscrVjkRviPwm,PB2EFL4DkoAnup7SajZq9GdRr,Thl3xtBje9dpPf6YsUoAyOzbL7Kk,WCrF2sGJaTRcZbI5n
def MdN2tCAu3WI4j7vy0(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,PlDVWLBYX5wQm,N0W1XcxqlO8Gewj7,pAtJykw4GCXKb31,ehWfDEbAtMTZaS5x=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	yVGJ4pRkKljcdswXU7E9vfOLDH8T = Qi32bRtN18qvyWmaO7YKow9cXs(qxZiT6WJ7sX,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡹࡷࡲࠧለ"))
	lFgE3cfXyG9Kws = llnG7jiQBYKhAeovbT.getSetting(flDSRbv57PnV3(u"ࠫࡦࡼ࠮ࡩࡱࡶࡸ࠳࠭ሉ")+PlDVWLBYX5wQm)
	if yVGJ4pRkKljcdswXU7E9vfOLDH8T==lFgE3cfXyG9Kws: llnG7jiQBYKhAeovbT.setSetting(DJ6ugPjW9bX8I(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧሊ")+PlDVWLBYX5wQm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if lFgE3cfXyG9Kws: zb2QIaL7Y4h9g8lSck = qxZiT6WJ7sX.replace(yVGJ4pRkKljcdswXU7E9vfOLDH8T,lFgE3cfXyG9Kws)
	else:
		zb2QIaL7Y4h9g8lSck = qxZiT6WJ7sX
		lFgE3cfXyG9Kws = yVGJ4pRkKljcdswXU7E9vfOLDH8T
	XoP5dRbLCpM7mIjw9E0YcKn8 = t57SmWGkHCXd4yq(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,ehWfDEbAtMTZaS5x,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡑࡒࡋࡑࡋ࡟ࡏࡇ࡚ࡣࡍࡕࡓࡕࡐࡄࡑࡊ࠳࠱ࡴࡶࠪላ"))
	B69RXYW5vf8Jt7O = XoP5dRbLCpM7mIjw9E0YcKn8.content
	if IZhXMprxvAHqBEFkg0:
		try: B69RXYW5vf8Jt7O = B69RXYW5vf8Jt7O.decode(zSafwK0sDXdMN5JReniIQmrZxp,bYyKEjIuGQzoq3AR1(u"ࠧࡪࡩࡱࡳࡷ࡫ࠧሌ"))
		except: pass
	if not XoP5dRbLCpM7mIjw9E0YcKn8.succeeded or pAtJykw4GCXKb31 not in B69RXYW5vf8Jt7O:
		N0W1XcxqlO8Gewj7 = N0W1XcxqlO8Gewj7.replace(S3X6GcaiExOPtb,SSvu1CZjTW7FcloNqD(u"ࠨ࠭ࠪል"))
		plSscrVjkRviPwm = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡶࡃࠧሎ")+N0W1XcxqlO8Gewj7
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧሏ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
		KXFGbQxMAgBRYh = t57SmWGkHCXd4yq(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡍࡏࡐࡉࡏࡉࡤࡔࡅࡘࡡࡋࡓࡘ࡚ࡎࡂࡏࡈ࠱࠷ࡴࡤࠨሐ"))
		if KXFGbQxMAgBRYh.succeeded:
			B69RXYW5vf8Jt7O = KXFGbQxMAgBRYh.content
			if IZhXMprxvAHqBEFkg0:
				try: B69RXYW5vf8Jt7O = B69RXYW5vf8Jt7O.decode(zSafwK0sDXdMN5JReniIQmrZxp,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬሑ"))
				except: pass
			rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱࡟ࡻ࠯ࡢ࠿࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧሒ"),B69RXYW5vf8Jt7O,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			SdRCF2qDcs49jLaYAB86xk3Vpf7J = [lFgE3cfXyG9Kws]
			RMNFHhbXTOS0owp1z3Ejl = [UpQ56M0dO1N9xIvVegy(u"ࠧࡢࡲ࡮ࠫሓ"),bYyKEjIuGQzoq3AR1(u"ࠨࡩࡲࡳ࡬ࡲࡥࠨሔ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡷࡻ࡮ࡺࡴࡦࡴࠪሕ"),DJ6ugPjW9bX8I(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫሖ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭ሗ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡶࡨࡱࠩመ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡡࡵ࡮ࡤࡵࠬሙ"),ulAxHwvzR9eTb5n(u"ࠧࡴ࡫ࡷࡩ࡮ࡴࡤࡪࡥࡨࡷࠬሚ"),QlTuvPbSpnjygBVW(u"ࠨࡵࡸࡶ࠳ࡲࡹࠨማ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡥࡰࡴ࡭ࡳࡱࡱࡷࠫሜ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪ࡭ࡳ࡬࡯ࡳ࡯ࡨࡶࠬም"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡸ࡯ࡴࡦ࡮࡬࡯ࡪ࠭ሞ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬ࡯࡮ࡴࡶࡤ࡫ࡷࡧ࡭ࠨሟ"),ulAxHwvzR9eTb5n(u"࠭ࡳ࡯ࡣࡳࡧ࡭ࡧࡴࠨሠ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡩࡶࡷࡴ࠲࡫ࡱࡶ࡫ࡹࠫሡ"),UpQ56M0dO1N9xIvVegy(u"ࠨࡨࡤࡷࡪࡲࡰ࡭ࡷࡶࠫሢ")]
			for FM9sSUchwEWNXLCb85iY1dD in rU02bCJFWZDfVuhtMgBOyQi5P:
				if any(XPL0O2VkI3w1C8enMaqi in FM9sSUchwEWNXLCb85iY1dD for XPL0O2VkI3w1C8enMaqi in RMNFHhbXTOS0owp1z3Ejl): continue
				lFgE3cfXyG9Kws = Qi32bRtN18qvyWmaO7YKow9cXs(FM9sSUchwEWNXLCb85iY1dD,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡸࡶࡱ࠭ሣ"))
				if lFgE3cfXyG9Kws in SdRCF2qDcs49jLaYAB86xk3Vpf7J: continue
				if len(SdRCF2qDcs49jLaYAB86xk3Vpf7J)==SSvu1CZjTW7FcloNqD(u"࠽ᓓ"):
					fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bnI4kmPtrW7yFEhljXOCq9(u"ࠪࠤࠥࠦࡇࡰࡱࡪࡰࡪࠦࡤࡪࡦࠣࡲࡴࡺࠠࡧ࡫ࡱࡨࠥࡧࠠ࡯ࡧࡺࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦࠠࠡࡕ࡬ࡸࡪࡀࠠ࡜ࠢࠪሤ")+PlDVWLBYX5wQm+IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࠥࡣࠠࠡࡑ࡯ࡨ࠿࡛ࠦࠡࠩሥ")+yVGJ4pRkKljcdswXU7E9vfOLDH8T+X1mRwt2YJKgCLu9a67(u"ࠬࠦ࡝ࠨሦ"))
					llnG7jiQBYKhAeovbT.setSetting(SSvu1CZjTW7FcloNqD(u"࠭ࡡࡷ࠰࡫ࡳࡸࡺ࠮ࠨሧ")+PlDVWLBYX5wQm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
					break
				SdRCF2qDcs49jLaYAB86xk3Vpf7J.append(lFgE3cfXyG9Kws)
				zb2QIaL7Y4h9g8lSck = qxZiT6WJ7sX.replace(yVGJ4pRkKljcdswXU7E9vfOLDH8T,lFgE3cfXyG9Kws)
				XoP5dRbLCpM7mIjw9E0YcKn8 = t57SmWGkHCXd4yq(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,ehWfDEbAtMTZaS5x,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡉࡒࡓࡌࡒࡅࡠࡐࡈ࡛ࡤࡎࡏࡔࡖࡑࡅࡒࡋ࠭࠴ࡴࡧࠫረ"))
				B69RXYW5vf8Jt7O = XoP5dRbLCpM7mIjw9E0YcKn8.content
				if XoP5dRbLCpM7mIjw9E0YcKn8.succeeded and pAtJykw4GCXKb31 in B69RXYW5vf8Jt7O:
					fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࠢࠣࠤࡌࡵ࡯ࡨ࡮ࡨࠤ࡫ࡵࡵ࡯ࡦࠣࡥࠥࡴࡥࡸࠢ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠤࠥࠦࡓࡪࡶࡨ࠾ࠥࡡࠠࠨሩ")+PlDVWLBYX5wQm+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࠣࡡࠥࠦࠠࡏࡧࡺ࠾ࠥࡡࠠࠨሪ")+lFgE3cfXyG9Kws+SSvu1CZjTW7FcloNqD(u"ࠪࠤࡢࠦࠠࡐ࡮ࡧ࠾ࠥࡡࠠࠨራ")+yVGJ4pRkKljcdswXU7E9vfOLDH8T+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࠥࡣࠧሬ"))
					llnG7jiQBYKhAeovbT.setSetting(UpQ56M0dO1N9xIvVegy(u"ࠬࡧࡶ࠯ࡪࡲࡷࡹ࠴ࠧር")+PlDVWLBYX5wQm,lFgE3cfXyG9Kws)
					break
	return lFgE3cfXyG9Kws,zb2QIaL7Y4h9g8lSck,XoP5dRbLCpM7mIjw9E0YcKn8
def wKYA6dfHyq3VgrZNbG5psjBRz0kXa(om2lqtcZ5y4j):
	RHaDN2tXyfhLu9Fs = {
	 YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡡࡩࡹࡤ࡯ࠬሮ")				:bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧๆ๊ๅ฽ࠥษ็้ษๆࠤฯ๐แ๋ࠩሯ")
	,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡣ࡮ࡳࡦࡳࠧሰ")				:z3sIGH8jmLYg(u"่ࠩ์็฿ࠠฤๅ๋ห๊ࠦวๅไา๎๊࠭ሱ")
	,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡥࡰࡵࡡ࡮ࡥࡤࡱࠬሲ")				:YayJj10OGl(u"๊ࠫ๎โฺࠢฦ็ํอๅࠡๅส้ࠬሳ")
	,bYyKEjIuGQzoq3AR1(u"ࠬࡧ࡫ࡸࡣࡰࠫሴ")				:X1mRwt2YJKgCLu9a67(u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪስ")
	,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡢ࡭ࡺࡥࡲࡺࡵࡣࡧࠪሶ")			:QlTuvPbSpnjygBVW(u"ࠨ็๋ๆ฾ࠦวไ๊ส้ࠥะ๊้สࠪሷ")
	,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡤࡰࡦࡸࡡࡣࠩሸ")				:IINBvuxkCSJrO1Q0UyngdLi(u"้ࠪํู่ࠡๅ็ࠤฬู๊าสࠪሹ")
	,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡦࡲࡦࡢࡶ࡬ࡱ࡮࠭ሺ")				:z3sIGH8jmLYg(u"๋่ࠬใ฻ࠣห้๋ๆษำࠣห้็วุ็ํࠫሻ")
	,bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡡ࡭࡭ࡤࡻࡹ࡮ࡡࡳࠩሼ")			:IINBvuxkCSJrO1Q0UyngdLi(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣห้้่ฬำࠪሽ")
	,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡣ࡯ࡱࡦࡧࡲࡦࡨࠪሾ")				:YayJj10OGl(u"่ࠩ์็฿ࠠใ่สอࠥอไๆ฻สีๆ࠭ሿ")
	,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡥࡱࡳࡳࡵࡤࡤࠫቀ")				:wCUIOeyRdxF3PtJ6TKYog8Xb(u"๊ࠫ๎โฺࠢส่๊฻ืษหࠪቁ")
	,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡧ࡮ࡪ࡯ࡨࡾ࡮ࡪࠧቂ")				:q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ๅ้ไ฼ࠤฬ์ๅ๋ࠢีำࠬቃ")
	,t4txivgXSUWBOlCakQmNDjf(u"ࠧࡢࡴࡤࡦ࡮ࡩࡴࡰࡱࡱࡷࠬቄ")			:X1mRwt2YJKgCLu9a67(u"ࠨ็๋ๆ฾ࠦส้่ีࠤ฾ืศ๋หࠪቅ")
	,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡤࡶࡦࡨࡳࡦࡧࡧࠫቆ")				:xxtgfCnWOFlo0jTbU3PQI4Dq(u"้ࠪํู่ࠡ฻ิฬู๊๋ࠥัࠪቇ")
	,DJ6ugPjW9bX8I(u"ࠫࡦࡸࡢ࡭࡫ࡲࡲࡿ࠭ቈ")				:ulAxHwvzR9eTb5n(u"๋่ࠬใ฻ࠣ฽ึฮࠠๅ์๋๊ื࠭቉")
	,DJ6ugPjW9bX8I(u"࠭ࡡࡺ࡮ࡲࡰࠬቊ")				:fgv5U2eRVaQqSiuGD(u"ࠧๆ๊ๅ฽ࠥษ๊ๅ๊็ࠫቋ")
	,l4DS8mnEjHhFMZ5YOe(u"ࠨࡤࡲ࡯ࡷࡧࠧቌ")				:SSvu1CZjTW7FcloNqD(u"่ࠩ์็฿ࠠษๅิหࠬቍ")
	,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡦࡷࡹࡴࡦ࡬ࠪ቎")				:CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"๊ࠫ๎โฺࠢหีุะ๊อࠩ቏")
	,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡩࡩ࡮ࡣ࠷࠴࠵࠭ቐ")				:DJ6ugPjW9bX8I(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢ࠷࠴࠵࠭ቑ")
	,UpQ56M0dO1N9xIvVegy(u"ࠧࡤ࡫ࡰࡥ࠹ࡶࠧቒ")				:paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆ๎ัࠡสํࠫቓ")
	,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡦ࡭ࡲࡧ࠴ࡶࠩቔ")				:DJ6ugPjW9bX8I(u"้ࠪํู่ࠡีํ้ฬࠦแ้ำํ์ࠬቕ")
	,t4txivgXSUWBOlCakQmNDjf(u"ࠫࡨ࡯࡭ࡢࡣࡥࡨࡴ࠭ቖ")				:usVCatpJzZGQ4gFiWX6803UALlkBOc(u"๋่ࠬใ฻ࠣื๏๋วࠡ฻หำํ࠭቗")
	,QlTuvPbSpnjygBVW(u"࠭ࡣࡪ࡯ࡤࡧࡱࡻࡢࠨቘ")				:YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ็้๎ศࠨ቙")
	,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡥ࡬ࡱࡦࡩ࡬ࡶࡤࡺࡳࡷࡱࠧቚ")			:paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"่ࠩ์็฿ࠠิ์่ห้ࠥไ้สࠣ฽๊๊ࠧቛ")
	,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡧ࡮ࡳࡡࡤ࡮ࡸࡴࠬቜ")				:QlTuvPbSpnjygBVW(u"๊ࠫ๎โฺࠢึ๎๊อࠠไๆ๋ฬࠬቝ")
	,X1mRwt2YJKgCLu9a67(u"ࠬࡩࡩ࡮ࡣࡩࡥࡳࡹࠧ቞")				:l4DS8mnEjHhFMZ5YOe(u"࠭ๅ้ไ฼ࠤุ๐ๅศࠢไหุ๋ࠧ቟")
	,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡤ࡫ࡰࡥ࡫ࡸࡥࡦࠩበ")				:z3sIGH8jmLYg(u"ࠨ็๋ๆ฾ࠦำ๋็สࠤๆื๊ࠨቡ")
	,QlTuvPbSpnjygBVW(u"ࠩࡦ࡭ࡲࡧ࡬ࡪࡩ࡫ࡸࠬቢ")			:cb3rmvAn4wa6lBPz2phOoYqX(u"้ࠪํู่ࠡีํ้ฬࠦไศ์อࠫባ")
	,UpQ56M0dO1N9xIvVegy(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬቤ")				:I3cxjYaHhsrM7T4UX26klN(u"๋่ࠬใ฻ࠣื๏๋ว่ࠡส์ࠬብ")
	,QlTuvPbSpnjygBVW(u"࠭ࡣࡪ࡯ࡤࡻࡧࡧࡳࠨቦ")				:usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧๆ๊ๅ฽ู๊ࠥๆษࠣ์อูࠧቧ")
	,X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ቨ")			:fsQukcZeJ8YbozTXKEvS7h306DCA(u"่ࠩ์็฿ࠠะษํ่๏ࠦๅ้ึ้ࠫቩ")
	,flDSRbv57PnV3(u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠮ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪቪ")	:tM24jD1gO0(u"๊ࠫ๎โฺࠢาห๏๊๊ࠡ็ุ๋๋ࠦๅิฬัำ๊๐ๆࠨቫ")
	,tM24jD1gO0(u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠰࡬ࡦࡹࡨࡵࡣࡪࡷࠬቬ")	:QlTuvPbSpnjygBVW(u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆ้ࠡสุฯอใࠨቭ")
	,Fo1SgXMsHk(u"ࠧࡥࡣ࡬ࡰࡾࡳ࡯ࡵ࡫ࡲࡲ࠲ࡲࡩࡷࡧࡶࠫቮ")	:bYyKEjIuGQzoq3AR1(u"ࠨ็๋ๆ฾ࠦฯศ์็๎๋่ࠥี่้ࠣออิาࠩቯ")
	,qrjy8LuKVPNYdbSvzh(u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪተ"):bnI4kmPtrW7yFEhljXOCq9(u"้ࠪํู่ࠡัส๎้๐ࠠๆ๊ื๊่่ࠥศศ่ࠫቱ")
	,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠯ࡷࡳࡵ࡯ࡣࡴࠩቲ")	:q4izXt0sjIQSZcHVAf3EmKRbx(u"๋่ࠬใ฻ࠣำฬ๐ไ๋่ࠢ์ู์ࠠๆ๊สฺ๏฿ࠧታ")
	,ulAxHwvzR9eTb5n(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ࠱ࡻ࡯ࡤࡦࡱࡶࠫቴ")	:fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧๆ๊ๅ฽ࠥีว๋ๆํࠤ๊๎ิ็ࠢไ๎ิ๐่่ษอࠫት")
	,ulAxHwvzR9eTb5n(u"ࠨࡦ࡬ࡷࡦࡨ࡬ࡦࡦࠪቶ")				:O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"่ࠩฮํ่แࠨቷ")
	,UpQ56M0dO1N9xIvVegy(u"ࠪࡨࡷࡧ࡭ࡢࡥࡤࡪࡪ࠭ቸ")			:usVCatpJzZGQ4gFiWX6803UALlkBOc(u"๊ࠫ๎โฺࠢาีฬ๋วࠡๅสๅ๏ํࠧቹ")
	,l4DS8mnEjHhFMZ5YOe(u"ࠬࡪࡲࡢ࡯ࡤࡷ࠼࠭ቺ")				:cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ๅ้ไ฼ࠤิืวๆษูࠣา࠭ቻ")
	,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨቼ")				:bYyKEjIuGQzoq3AR1(u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩች")
	,QlTuvPbSpnjygBVW(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠴ࠫቾ")				:xxtgfCnWOFlo0jTbU3PQI4Dq(u"้ࠪํู่ࠡษํะ๏ࠦศ๋ีอࠤ࠶࠭ቿ")
	,ulAxHwvzR9eTb5n(u"ࠫࡪ࡭ࡹࡣࡧࡶࡸ࠷࠭ኀ")				:qrjy8LuKVPNYdbSvzh(u"๋่ࠬใ฻ࠣห๏า๊ࠡสํืฯࠦ࠲ࠨኁ")
	,xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡥࡨࡻࡥࡩࡸࡺ࠳ࠨኂ")				:qrjy8LuKVPNYdbSvzh(u"ࠧๆ๊ๅ฽ࠥอ๊อ์ࠣฬ๏ูสࠡ࠵ࠪኃ")
	,t4txivgXSUWBOlCakQmNDjf(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠶ࠪኄ")				:X60YQOADpkHBb31LiR5qUEKfM(u"่ࠩ์็฿ࠠศ์ฯ๎ࠥฮ๊ิฬࠣ࠸ࠬኅ")
	,ulAxHwvzR9eTb5n(u"ࠪࡩ࡬ࡿࡢࡦࡵࡷࡺ࡮ࡶࠧኆ")			:YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"๊ࠫ๎โฺࠢส๎ั๐ࠠษ์ึฮࠥࡼࡩࡱࠩኇ")
	,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࡫ࡧࡺࡦࡨࡥࡩ࠭ኈ")				:bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ๅ้ไ฼ࠤส๐ฬ๋ࠢา๎ิ࠭኉")
	,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡦࡩࡼࡲࡴࡽࠧኊ")				:X60YQOADpkHBb31LiR5qUEKfM(u"ࠨ็๋ๆ฾ࠦล๋ฮํࠤ๋อ่ࠨኋ")
	,YayJj10OGl(u"ࠩࡨࡰࡨ࡯࡮ࡦ࡯ࡤࠫኌ")				:q4izXt0sjIQSZcHVAf3EmKRbx(u"้ࠪํู่ࠡ็๋ืํ฿ษࠡษ็ื๏์ๅศࠩኍ")
	,flDSRbv57PnV3(u"ࠫࡪࡲࡩࡧࡸ࡬ࡨࡪࡵࠧ኎")			:xxtgfCnWOFlo0jTbU3PQI4Dq(u"๋่ࠬใ฻ࠣว้๐แࠡใํำ๏๎ࠧ኏")
	,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࡦࡢࡤࡵࡥࡰࡧࠧነ")				:flDSRbv57PnV3(u"ࠧๆ๊ๅ฽ࠥ็ศาๅฬࠫኑ")
	,X1mRwt2YJKgCLu9a67(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨኒ")				:l4DS8mnEjHhFMZ5YOe(u"ࠩไุ้࠭ና")
	,X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡪࡦࡰࡥࡳࡵ࡫ࡳࡼ࠭ኔ")			:O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩን")
	,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬ࡬ࡡࡳࡧࡶ࡯ࡴ࠭ኖ")				:I3cxjYaHhsrM7T4UX26klN(u"࠭ๅ้ไ฼ࠤๆอั๋ีๆ์ࠬኗ")
	,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤ࠲ࠩኘ")				:paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨ็๋ๆ฾ࠦแศื็ࠤฬ๊ร้ๆࠪኙ")
	,QlTuvPbSpnjygBVW(u"ࠩࡩࡥࡸ࡫࡬ࡩࡦ࠵ࠫኚ")				:X1mRwt2YJKgCLu9a67(u"้ࠪํู่ࠡใสู้ࠦวๅอส๊๏࠭ኛ")
	,tM24jD1gO0(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫኜ")				:bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"๋ࠬฬๅัࠪኝ")
	,xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡦࡰࡵࡷࡥࠬኞ")				:tM24jD1gO0(u"ࠧๆ๊ๅ฽ࠥ็่ิฬสࠫኟ")
	,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡨࡸࡲࡴࡴࡴࡷࠩአ")				:UpQ56M0dO1N9xIvVegy(u"่ࠩ์็฿ࠠโ่๋๊ࠥะ๊โ์ࠪኡ")
	,bYyKEjIuGQzoq3AR1(u"ࠪࡪࡺࡹࡨࡢࡴࡷࡺࠬኢ")				:cb3rmvAn4wa6lBPz2phOoYqX(u"๊ࠫ๎โฺࠢไ์ูอัࠡฬํๅ๏࠭ኣ")
	,Fo1SgXMsHk(u"ࠬ࡬ࡵࡴࡪࡤࡶࡻ࡯ࡤࡦࡱࠪኤ")			:I3cxjYaHhsrM7T4UX26klN(u"࠭ๅ้ไ฼ࠤๆ๎ิศำࠣๅ๏ี๊้ࠩእ")
	,tM24jD1gO0(u"ࠧࡨࡱࡲࡨࠬኦ")					:CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨฮํำࠬኧ")
	,YayJj10OGl(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫከ")				:I3cxjYaHhsrM7T4UX26klN(u"้ࠪํู่้ࠡ็หู๊ࠥๆษࠪኩ")
	,tM24jD1gO0(u"ࠫ࡭࡫࡬ࡢ࡮ࠪኪ")				:yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"๋่ࠬใ฻๋้ࠣอไࠡ์๋ฮ๏๎ศࠨካ")
	,DJ6ugPjW9bX8I(u"࠭ࡩࡧ࡫࡯ࡱࠬኬ")				:X60YQOADpkHBb31LiR5qUEKfM(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣฦ๏ࠦแ๋ๆ่ࠫክ")
	,ulAxHwvzR9eTb5n(u"ࠨ࡫ࡩ࡭ࡱࡳ࠭ࡢࡴࡤࡦ࡮ࡩࠧኮ")			:wCUIOeyRdxF3PtJ6TKYog8Xb(u"่ࠩ์็฿ࠠใ่สอࠥศ๊ࠡใํู่๊ࠦาสํࠫኯ")
	,qrjy8LuKVPNYdbSvzh(u"ࠪ࡭࡫࡯࡬࡮࠯ࡨࡲ࡬ࡲࡩࡴࡪࠪኰ")		:usVCatpJzZGQ4gFiWX6803UALlkBOc(u"๊ࠫ๎โฺࠢๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡษ้ะ้๐า๋ࠩ኱")
	,z3sIGH8jmLYg(u"ࠬ࡯ࡰࡵࡸࠪኲ")					:xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡉࡑࡖ࡙ࠫኳ")
	,l4DS8mnEjHhFMZ5YOe(u"ࠧࡪࡲࡷࡺ࠲ࡲࡩࡷࡧࠪኴ")			:qrjy8LuKVPNYdbSvzh(u"ࠨࡋࡓࡘ࡛ࠦโ็๊สฮࠬኵ")
	,bYyKEjIuGQzoq3AR1(u"ࠩ࡬ࡴࡹࡼ࠭࡮ࡱࡹ࡭ࡪࡹࠧ኶")			:usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡍࡕ࡚ࡖࠡลไ่ฬ๋ࠧ኷")
	,flDSRbv57PnV3(u"ࠫ࡮ࡶࡴࡷ࠯ࡶࡩࡷ࡯ࡥࡴࠩኸ")			:DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡏࡐࡕࡘุ้๊ࠣำๅษอࠫኹ")
	,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭࡫ࡢࡴࡥࡥࡱࡧࡴࡷࠩኺ")			:SSvu1CZjTW7FcloNqD(u"ࠧๆ๊ๅ฽่ࠥๆศหࠣ็ึฮไศรࠪኻ")
	,YayJj10OGl(u"ࠨ࡭ࡤࡸࡰࡵࡴࡵࡸࠪኼ")				:SSvu1CZjTW7FcloNqD(u"่ࠩ์็฿ࠠไฬๆ์ฯࠦส๋ใํࠫኽ")
	,qrjy8LuKVPNYdbSvzh(u"ࠪ࡯ࡦࡺ࡫ࡰࡷࡷࡩࠬኾ")				:DJ6ugPjW9bX8I(u"๊ࠫ๎โฺࠢๆฮ่๎สࠨ኿")
	,bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡱࡩࡳ࡯ࡤࡰࡰ࠭ዀ")				:bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ๅ้ไ฼ࠤ่ืๅศๆๆࠫ዁")
	,Fo1SgXMsHk(u"ࠧ࡭ࡣࡵࡳࡿࡧࠧዂ")				:yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨ็๋ๆ฾ࠦไศำ๋ึฬ࠭ዃ")
	,ulAxHwvzR9eTb5n(u"ࠩ࡯࡭ࡧࡸࡡࡳࡻࠪዄ")				:wCUIOeyRdxF3PtJ6TKYog8Xb(u"้้ࠪ็ࠧዅ")
	,X1mRwt2YJKgCLu9a67(u"ࠫࡱ࡯ࡶࡦࠩ዆")					:Fo1SgXMsHk(u"่ࠬๆศหࠪ዇")
	,bnI4kmPtrW7yFEhljXOCq9(u"࠭࡬ࡪࡸࡨࡸࡻ࠭ወ")				:YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧๆๆไࠫዉ")
	,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࡮ࡲࡨࡾࡴࡥࡵࠩዊ")				:ulAxHwvzR9eTb5n(u"่ࠩ์็฿ࠠๅ๊า๎ࠥ์สࠨዋ")
	,Fo1SgXMsHk(u"ࠪࡱ࠸ࡻࠧዌ")					:QlTuvPbSpnjygBVW(u"ࠫࡒ࠹ࡕࠨው")
	,flDSRbv57PnV3(u"ࠬࡳ࠳ࡶ࠯࡯࡭ࡻ࡫ࠧዎ")				:YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡍ࠴ࡗࠣๆ๋๎วหࠩዏ")
	,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧ࡮࠵ࡸ࠱ࡲࡵࡶࡪࡧࡶࠫዐ")			:fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡏ࠶࡙ࠥษแๅษ่ࠫዑ")
	,bYyKEjIuGQzoq3AR1(u"ࠩࡰ࠷ࡺ࠳ࡳࡦࡴ࡬ࡩࡸ࠭ዒ")			:CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡑ࠸࡛ࠠๆี็ื้อสࠨዓ")
	,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡲࡧࡳࡢࡸ࡬ࡨࡪࡵࠧዔ")			:flDSRbv57PnV3(u"๋่ࠬใ฻้ࠣฬูวࠡใํำ๏๎ࠧዕ")
	,fgv5U2eRVaQqSiuGD(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧዖ")				:yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧๆใๅ์ิ࠭዗")
	,z3sIGH8jmLYg(u"ࠨ࡯ࡲࡺࡸ࠺ࡵࠨዘ")				:X1mRwt2YJKgCLu9a67(u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫዙ")
	,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡱࡾࡩࡩ࡮ࡣࠪዚ")				:DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"๊ࠫ๎โฺ่ࠢห๏ࠦำ๋็สࠫዛ")
	,qrjy8LuKVPNYdbSvzh(u"ࠬࡵ࡬ࡥࠩዜ")					:SSvu1CZjTW7FcloNqD(u"࠭โะ์่ࠫዝ")
	,UpQ56M0dO1N9xIvVegy(u"ࠧࡱࡣࡱࡩࡹ࠭ዞ")				:UpQ56M0dO1N9xIvVegy(u"ࠨ็๋ๆ฾ࠦศศ่ํฮࠬዟ")
	,bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡳࡥࡳ࡫ࡴ࠮࡯ࡲࡺ࡮࡫ࡳࠨዠ")			:cb3rmvAn4wa6lBPz2phOoYqX(u"้ࠪํู่ࠡสส๊๏ะࠠศใ็ห๊࠭ዡ")
	,l4DS8mnEjHhFMZ5YOe(u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡷࡪࡸࡩࡦࡵࠪዢ")			:Fo1SgXMsHk(u"๋่ࠬใ฻ࠣฬฬ์๊ห่ࠢืู้ไศฬࠪዣ")
	,ulAxHwvzR9eTb5n(u"࠭ࡱࡧ࡫࡯ࡱࠬዤ")				:YayJj10OGl(u"ࠧๆ๊ๅ฽้๊้ࠥࠢไ๎้๋ࠧዥ")
	,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡵࡨࡶ࡮࡫ࡳࡵ࡫ࡰࡩࠬዦ")			:UpQ56M0dO1N9xIvVegy(u"่ࠩ์็฿ࠠิ์ิ๎ุࠦสศ์่ࠫዧ")
	,X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡷ࡭ࡧࡢࡢ࡭ࡤࡸࡾ࠭የ")			:X60YQOADpkHBb31LiR5qUEKfM(u"๊ࠫ๎โฺࠢืฬ่ะ๊ࠨዩ")
	,flDSRbv57PnV3(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧዪ")				:DJ6ugPjW9bX8I(u"࠭ๅ้ไ฼ࠤูอ็ะࠢไ์ึ๐่ࠨያ")
	,l4DS8mnEjHhFMZ5YOe(u"ࠧࡴࡪࡤ࡬࡮ࡪ࡮ࡦࡹࡶࠫዬ")			:usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨ็๋ๆ฾ࠦิศ้าࠤ๋๐่ำࠩይ")
	,fgv5U2eRVaQqSiuGD(u"ࠩࡶ࡬࡮ࡧࡶࡰ࡫ࡦࡩࠬዮ")			:cb3rmvAn4wa6lBPz2phOoYqX(u"้ࠪํู่ࠡื๋ฮࠥอไี์฼อࠬዯ")
	,bYyKEjIuGQzoq3AR1(u"ࠫࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠭ࡢ࡮ࡥࡹࡲࡹࠧደ")		:paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"๋่ࠬใ฻ูࠣํะࠠศๆื๎฾ฯࠠศๆห์๊࠭ዱ")
	,X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡳࡩ࡫ࡤࡺࡴ࡯ࡣࡦ࠯ࡤࡹࡩ࡯࡯ࡴࠩዲ")		:fgv5U2eRVaQqSiuGD(u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสุࠢ์ฯ๐วหࠩዳ")
	,X1mRwt2YJKgCLu9a67(u"ࠨࡵ࡫࡭ࡦࡼ࡯ࡪࡥࡨ࠱ࡵ࡫ࡲࡴࡱࡱࡷࠬዴ")	:IINBvuxkCSJrO1Q0UyngdLi(u"่ࠩ์็฿ࠠึ๊อࠤฬ๊ิ๋฻ฬࠤ็อัวࠩድ")
	,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡷ࡭ࡵࡦࡩࡣࠪዶ")				:tM24jD1gO0(u"๊ࠫ๎โฺࠢื์ๆํวࠡฬํๅ๏࠭ዷ")
	,X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡹࡨࡰࡱࡩࡱࡦࡾࠧዸ")				:X1mRwt2YJKgCLu9a67(u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭ዹ")
	,SSvu1CZjTW7FcloNqD(u"ࠧࡴࡪࡲࡳ࡫ࡴࡥࡵࠩዺ")				:YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ็๋ๆ฾ࠦิ้ใ๊ࠣฯ࠭ዻ")
	,bYyKEjIuGQzoq3AR1(u"ࠩࡶ࡬ࡴࡵࡦࡱࡴࡲࠫዼ")				:qrjy8LuKVPNYdbSvzh(u"้ࠪํู่ࠡึ๋ๅࠥฮั้ࠩዽ")
	,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡹ࡯࡫ࡢࡣࡷࠫዾ")				:bnI4kmPtrW7yFEhljXOCq9(u"๋่ࠬใ฻ࠣฮ่อสࠨዿ")
	,SSvu1CZjTW7FcloNqD(u"࠭ࡴࡷࡨࡸࡲࠬጀ")				:l4DS8mnEjHhFMZ5YOe(u"ࠧๆ๊ๅ฽ࠥะ๊โ์ࠣๅฬ์ࠧጁ")
	,SSvu1CZjTW7FcloNqD(u"ࠨࡸࡤࡶࡧࡵ࡮ࠨጂ")				:tM24jD1gO0(u"่ࠩ์็฿ࠠโษิฬํ์ࠧጃ")
	,flDSRbv57PnV3(u"ࠪࡺ࡮ࡪࡥࡰࠩጄ")				:DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫๆ๐ฯ๋๊ࠪጅ")
	,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡼࡩࡥࡧࡲࡲࡸࡧࡥ࡮ࠩጆ")			:qrjy8LuKVPNYdbSvzh(u"࠭ๅ้ไ฼ࠤๆ๐ฯุ๋๊๊ࠣอฦๆࠩጇ")
	,bYyKEjIuGQzoq3AR1(u"ࠧࡸࡧࡦ࡭ࡲࡧ࠱ࠨገ")				:UpQ56M0dO1N9xIvVegy(u"ࠨ็๋ๆ฾่๋ࠦࠢึ๎๊อࠠ࠲ࠩጉ")
	,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡺࡩࡨ࡯࡭ࡢ࠴ࠪጊ")				:SSvu1CZjTW7FcloNqD(u"้ࠪํู่๊ࠡํࠤุ๐ๅศࠢ࠵ࠫጋ")
	,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡾࡧࡱࡰࡶࠪጌ")				:O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"๋่ࠬใ฻ࠣ๎ฬ่่หࠩግ")
	,DJ6ugPjW9bX8I(u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧጎ")				:SSvu1CZjTW7FcloNqD(u"ࠧๆ๊ๅ฽ࠥ๐่ห์๋ฬࠬጏ")
	,X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫጐ")		:Fo1SgXMsHk(u"่ࠩ์็฿๋๊ࠠอ๎ํฮࠠใ่๋หฯ࠭጑")
	,QlTuvPbSpnjygBVW(u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠱ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧጒ")	:bYyKEjIuGQzoq3AR1(u"๊ࠫ๎โฺࠢํ์ฯ๐่ษࠢๅ์ฬฬๅࠨጓ")
	,DJ6ugPjW9bX8I(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡶࡪࡦࡨࡳࡸ࠭ጔ")		:DJ6ugPjW9bX8I(u"࠭ๅ้ไ฼ࠤ๏๎ส๋๊หࠤๆ๐ฯ๋๊๊หฯ࠭ጕ")
	,QlTuvPbSpnjygBVW(u"ࠧࡺࡶࡥࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭጖")			:fgv5U2eRVaQqSiuGD(u"ࠨ็๋ห็฿ࠠๆ่ࠣ๎ํะ๊้สࠪ጗")
	}
	s9dxhATVZPfq35gt6jD = om2lqtcZ5y4j.lower()
	for key in list(RHaDN2tXyfhLu9Fs.keys()):
		ZCNnBQP1Isl8Hj6dpiThAOq = key.lower()
		if s9dxhATVZPfq35gt6jD==ZCNnBQP1Isl8Hj6dpiThAOq:
			om2lqtcZ5y4j = RHaDN2tXyfhLu9Fs[key]
			break
	return om2lqtcZ5y4j
def R5VzflU0D2LQaSoKOskBuYtrXFC():
	V5VsTuKOPYNQvkcX2 = RarSo2nTfwU0WEGK.executeJSONRPC(X1mRwt2YJKgCLu9a67(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡒ࡯ࡥࡾࡲࡩࡴࡶ࠱ࡇࡱ࡫ࡡࡳࠤ࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࡫ࡧࠦ࠿࠷ࡽࡾࠩጘ"))
	raise ValueError(fgv5U2eRVaQqSiuGD(u"ࠪࡣࡤࡥࡆࡐࡔࡆࡉࡤࡋࡘࡊࡖࡢࡣࡤ࠭ጙ"))
def ue186CEMORWhvq(ppsBfvqYORTK0r,p6yEcRV0WN9ox2asuzwl4ZkP8O=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	global fnZbzLvOBJm9krHujVw1oc3lYPq5
	fnZbzLvOBJm9krHujVw1oc3lYPq5 = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if not p6yEcRV0WN9ox2asuzwl4ZkP8O and ppsBfvqYORTK0r: p6yEcRV0WN9ox2asuzwl4ZkP8O = UpQ56M0dO1N9xIvVegy(u"ࠫࡗࡋࡑࡖࡇࡖࡘࡤࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬጚ")
	llnG7jiQBYKhAeovbT.setSetting(SSvu1CZjTW7FcloNqD(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩጛ"),p6yEcRV0WN9ox2asuzwl4ZkP8O)
	return
def lcxFAteLQ1Pwu45Er2(qxZiT6WJ7sX,cQX8HTJsaDbKfAGSdZmVjwNnzUEM=t4txivgXSUWBOlCakQmNDjf(u"࠭࠺࠰ࠩጜ")):
	return _YcNCDm7pPxskylg(qxZiT6WJ7sX,cQX8HTJsaDbKfAGSdZmVjwNnzUEM)
def zLOZgIrP5umTvoeVi7RNw491Ul0hd(pp3rWyabAnjeZ6XG):
	if pp3rWyabAnjeZ6XG in [nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧ࠱ࠩጝ"),f4fTutDOEwUeIoPLRQ]: return nbOFVEDkpT4BIR7Qq82yPmHeJU
	pp3rWyabAnjeZ6XG = int(pp3rWyabAnjeZ6XG)
	nvPVUS5EQo9IXLWDtlckM = pp3rWyabAnjeZ6XG^mmfpkVtUDjaq86eAuFzE0oxP
	gzd4nuwNqBmciA8Y3C0h = pp3rWyabAnjeZ6XG^RRYx6sACloVPr3td95Ej
	LLcmCS143zXWDNrq = pp3rWyabAnjeZ6XG^pOLDXnFW5V6cTw7ikm
	tinT1zh3lAZ = str(nvPVUS5EQo9IXLWDtlckM)+str(gzd4nuwNqBmciA8Y3C0h)+str(LLcmCS143zXWDNrq)
	return tinT1zh3lAZ
def cgakKAyeD5ij3ZJBmYhzx6Lr(pp3rWyabAnjeZ6XG):
	if pp3rWyabAnjeZ6XG in [nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠨ࠲ࠪጞ"),f4fTutDOEwUeIoPLRQ]: return nbOFVEDkpT4BIR7Qq82yPmHeJU
	pp3rWyabAnjeZ6XG = str(pp3rWyabAnjeZ6XG)
	tinT1zh3lAZ = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if len(pp3rWyabAnjeZ6XG)==z3sIGH8jmLYg(u"࠶࠻ᓔ"):
		nvPVUS5EQo9IXLWDtlckM,gzd4nuwNqBmciA8Y3C0h,LLcmCS143zXWDNrq = pp3rWyabAnjeZ6XG[f4fTutDOEwUeIoPLRQ:WtDrnpJmwQ37Z2Ae68hu4BY5M1],pp3rWyabAnjeZ6XG[WtDrnpJmwQ37Z2Ae68hu4BY5M1:l4DS8mnEjHhFMZ5YOe(u"࠿ᓕ")],pp3rWyabAnjeZ6XG[l4DS8mnEjHhFMZ5YOe(u"࠿ᓕ"):]
		nvPVUS5EQo9IXLWDtlckM = int(nvPVUS5EQo9IXLWDtlckM)^pOLDXnFW5V6cTw7ikm
		gzd4nuwNqBmciA8Y3C0h = int(gzd4nuwNqBmciA8Y3C0h)^RRYx6sACloVPr3td95Ej
		LLcmCS143zXWDNrq = int(LLcmCS143zXWDNrq)^mmfpkVtUDjaq86eAuFzE0oxP
		if nvPVUS5EQo9IXLWDtlckM==gzd4nuwNqBmciA8Y3C0h==LLcmCS143zXWDNrq: tinT1zh3lAZ = str(nvPVUS5EQo9IXLWDtlckM*yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠶࠱ᓖ"))
	return tinT1zh3lAZ
def u8i2rxCZwsDyW7KMFIbmqgnvS(pp3rWyabAnjeZ6XG,UVEjl5031tWLvSauXcs4rwAZmB=DJ6ugPjW9bX8I(u"ࠩ࠹࠷࠽࠺࠱࠹࠴࠶ࠫጟ")):
	if pp3rWyabAnjeZ6XG==nbOFVEDkpT4BIR7Qq82yPmHeJU: return nbOFVEDkpT4BIR7Qq82yPmHeJU
	pp3rWyabAnjeZ6XG = int(pp3rWyabAnjeZ6XG)+int(UVEjl5031tWLvSauXcs4rwAZmB)
	nvPVUS5EQo9IXLWDtlckM = pp3rWyabAnjeZ6XG^mmfpkVtUDjaq86eAuFzE0oxP
	gzd4nuwNqBmciA8Y3C0h = pp3rWyabAnjeZ6XG^RRYx6sACloVPr3td95Ej
	LLcmCS143zXWDNrq = pp3rWyabAnjeZ6XG^pOLDXnFW5V6cTw7ikm
	tinT1zh3lAZ = str(nvPVUS5EQo9IXLWDtlckM)+str(gzd4nuwNqBmciA8Y3C0h)+str(LLcmCS143zXWDNrq)
	return tinT1zh3lAZ
def jB7hQVAxCkgwsDE5bOa83u9KXt4(pp3rWyabAnjeZ6XG,UVEjl5031tWLvSauXcs4rwAZmB=qrjy8LuKVPNYdbSvzh(u"ࠪ࠺࠸࠾࠴࠲࠺࠵࠷ࠬጠ")):
	if pp3rWyabAnjeZ6XG==nbOFVEDkpT4BIR7Qq82yPmHeJU: return nbOFVEDkpT4BIR7Qq82yPmHeJU
	pp3rWyabAnjeZ6XG = str(pp3rWyabAnjeZ6XG)
	vfRKCxijUVd3zZSLHe4 = int(len(pp3rWyabAnjeZ6XG)/ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb)
	nvPVUS5EQo9IXLWDtlckM = int(pp3rWyabAnjeZ6XG[f4fTutDOEwUeIoPLRQ:vfRKCxijUVd3zZSLHe4])^mmfpkVtUDjaq86eAuFzE0oxP
	gzd4nuwNqBmciA8Y3C0h = int(pp3rWyabAnjeZ6XG[vfRKCxijUVd3zZSLHe4:QQSugEIn2mTCpRsfcaJHhPdAWzylM*vfRKCxijUVd3zZSLHe4])^RRYx6sACloVPr3td95Ej
	LLcmCS143zXWDNrq = int(pp3rWyabAnjeZ6XG[QQSugEIn2mTCpRsfcaJHhPdAWzylM*vfRKCxijUVd3zZSLHe4:ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb*vfRKCxijUVd3zZSLHe4])^pOLDXnFW5V6cTw7ikm
	tinT1zh3lAZ = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if nvPVUS5EQo9IXLWDtlckM==gzd4nuwNqBmciA8Y3C0h==LLcmCS143zXWDNrq: tinT1zh3lAZ = str(int(nvPVUS5EQo9IXLWDtlckM)-int(UVEjl5031tWLvSauXcs4rwAZmB))
	return tinT1zh3lAZ
def FsdxpPBgGZzfntTLWDhlKyM(qChDrcGZSTBdVEHNko8QM67xUA):
	iaefslb5KYVBNt4XH2qcEhmj6doJW = sCSyOla9hrcE[UpQ56M0dO1N9xIvVegy(u"ࠫࡕ࡟ࡔࡉࡑࡑࠫጡ")][DJ6ugPjW9bX8I(u"࠹ᓗ")]
	vIHhiCRzpqlyD34jPs2 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨጢ"),l4DS8mnEjHhFMZ5YOe(u"࠭ࡳ࡬࡫ࡱࡷࠬጣ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡅࡧࡩࡥࡺࡲࡴࠨጤ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨ࠹࠵࠴ࡵ࠭ጥ"),fgv5U2eRVaQqSiuGD(u"ࠩࡇ࡭ࡦࡲ࡯ࡨࡅࡲࡲ࡫࡯ࡲ࡮ࡖ࡫ࡶࡪ࡫ࡂࡶࡶࡷࡳࡳࡹ࠮ࡹ࡯࡯ࠫጦ"))
	dUykuchvf6qznPm,r7qhNKygnf = nHxt2Y5jIy4cWrZJ(vIHhiCRzpqlyD34jPs2)
	dUykuchvf6qznPm = u8i2rxCZwsDyW7KMFIbmqgnvS(dUykuchvf6qznPm,UpQ56M0dO1N9xIvVegy(u"ࠪ࠵࠷࠷࠸࠴࠳࠻࠹࠸࠭ጧ"))
	yKI7QukaD6slAd0CZXmVh4UBjbM = {QlTuvPbSpnjygBVW(u"ࠫ࡮ࡪࡳࠨጨ"):X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡊࡉࡂࡎࡒࡋࠬጩ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡵࡴࡴࠪጪ"):iidHGYjPEW4zU,t4txivgXSUWBOlCakQmNDjf(u"ࠧࡷࡧࡵࠫጫ"):JeVILUu027qW,tM24jD1gO0(u"ࠨࡵࡦࡶࠬጬ"):qChDrcGZSTBdVEHNko8QM67xUA,SSvu1CZjTW7FcloNqD(u"ࠩࡶ࡭ࡿ࠭ጭ"):dUykuchvf6qznPm}
	eVZ1IwYuzBiCs08lpMm46DH5Ntq = {Fo1SgXMsHk(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩጮ"):DJ6ugPjW9bX8I(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪጯ")}
	dzoatgfA31yLK5Y9iDwvXxBUFRT = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡖࡏࡔࡖࠪጰ"),iaefslb5KYVBNt4XH2qcEhmj6doJW,yKI7QukaD6slAd0CZXmVh4UBjbM,eVZ1IwYuzBiCs08lpMm46DH5Ntq,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡊࡒ࡛ࡤࡖࡌࡂ࡛ࡢࡈࡎࡇࡌࡐࡉ࠰࠵ࡸࡺࠧጱ"))
	bhFoAq8vn5Y6Ww4 = dzoatgfA31yLK5Y9iDwvXxBUFRT.content
	try:
		if not bhFoAq8vn5Y6Ww4: eeCbt3WNyIr1
		lx51Jv6iUmNbq0ukwLFaBHY = dr1zfnatJxRHSF48jh0eODm5bGu(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡥ࡫ࡦࡸࠬጲ"),bhFoAq8vn5Y6Ww4)
		zGcSra96i4wCfAtPDmyU7LlTRMk5B = lx51Jv6iUmNbq0ukwLFaBHY[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨ࡯ࡶ࡫ࠬጳ")]
		LLk8e1dcIqFNAZR6z9gpnW7Di = lx51Jv6iUmNbq0ukwLFaBHY[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡶࡩࡨ࠭ጴ")]
		KUM85Im4WV6PNlgASH = lx51Jv6iUmNbq0ukwLFaBHY[l4DS8mnEjHhFMZ5YOe(u"ࠪࡷࡹࡶࠧጵ")]
		LLk8e1dcIqFNAZR6z9gpnW7Di = int(jB7hQVAxCkgwsDE5bOa83u9KXt4(LLk8e1dcIqFNAZR6z9gpnW7Di,ulAxHwvzR9eTb5n(u"ࠫ࠶࠸࠱࠹࠵࠴࠼࠺࠹ࠧጶ")))
		KUM85Im4WV6PNlgASH = int(jB7hQVAxCkgwsDE5bOa83u9KXt4(KUM85Im4WV6PNlgASH,bnI4kmPtrW7yFEhljXOCq9(u"ࠬ࠷࠲࠲࠺࠶࠵࠽࠻࠳ࠨጷ")))
		for vLCzXEp6Kr8VbjxwIiJ in range(LLk8e1dcIqFNAZR6z9gpnW7Di,f4fTutDOEwUeIoPLRQ,-KUM85Im4WV6PNlgASH):
			if not eval(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫጸ"),{flDSRbv57PnV3(u"ࠧࡹࡤࡰࡧࠬጹ"):RarSo2nTfwU0WEGK}): eeCbt3WNyIr1
			SSVCGE0bOfW1w9u52yvBxocNeP(DJ6ugPjW9bX8I(u"ࠨสสๆ๏ࠦไๅฬฯีอฯ้ࠠษ็ๅา฻ࠧጺ"),str(vLCzXEp6Kr8VbjxwIiJ)+t4txivgXSUWBOlCakQmNDjf(u"ࠩࠣࠤะอๆ๋หࠪጻ"),lQMuw1PvVpAk=I3cxjYaHhsrM7T4UX26klN(u"࠵࠳࠴ᓘ")*KUM85Im4WV6PNlgASH)
			RarSo2nTfwU0WEGK.sleep(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠴࠴࠵࠶ᓙ")*KUM85Im4WV6PNlgASH)
		if eval(l4DS8mnEjHhFMZ5YOe(u"ࠪࡼࡧࡳࡣ࠯ࡒ࡯ࡥࡾ࡫ࡲࠩࠫ࠱࡭ࡸࡖ࡬ࡢࡻ࡬ࡲ࡬࠮ࠩࠨጼ"),{CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡽࡨ࡭ࡤࠩጽ"):RarSo2nTfwU0WEGK}):
			zGcSra96i4wCfAtPDmyU7LlTRMk5B = zGcSra96i4wCfAtPDmyU7LlTRMk5B.replace(wwOnIucWJj,tM24jD1gO0(u"ࠬࡢ࡜࡯ࠩጾ")).replace(FKuOXLZA8PYBc7,bYyKEjIuGQzoq3AR1(u"࠭࡜࡝ࡴࠪጿ"))
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠧฯำ๋ะࠬፀ"),t4txivgXSUWBOlCakQmNDjf(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫፁ"),zGcSra96i4wCfAtPDmyU7LlTRMk5B)
		eeCbt3WNyIr1
	except: exec(X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡻࡦࡲࡩ࠮ࡑ࡮ࡤࡽࡪࡸࠨࠪ࠰ࡶࡸࡴࡶࠨࠪࠩፂ"),{wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡼࡧࡳࡣࠨፃ"):RarSo2nTfwU0WEGK})
	return
def nVmGZTU79NByx():
	exec(X1mRwt2YJKgCLu9a67(u"ࠫࠬ࠭ࠍࠋࡶࡵࡽ࠿ࠓࠊࠊࡹ࡬ࡲࡩࡵࡷ࠲࠴࠶ࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡘ࡫ࡱࡨࡴࡽࠨ࠲࠲࠳࠶࠺࠯ࠍࠋࠋࡺ࡬࡮ࡲࡥࠡࡖࡵࡹࡪࡀࠍࠋࠋࠌࡼࡧࡳࡣ࠯ࡵ࡯ࡩࡪࡶࠨ࠲࠲࠳࠴࠮ࠓࠊࠊࠋࡷࡶࡾࡀࠠࡸ࡫ࡱࡨࡴࡽ࠱࠳࠵࠱࡫ࡪࡺࡆࡰࡥࡸࡷ࠭࠷࠰࠱࠴࠸࠭ࠒࠐࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡥࡶࡪࡧ࡫ࠎࠌࠌࡾࡨࡸࡥࡢࡶࡨࡣࡪࡸ࡯ࡳࡴࠐࠎࡪࡾࡣࡦࡲࡷ࠾ࠥࡾࡢ࡮ࡥ࠱ࡔࡱࡧࡹࡦࡴࠫ࠭࠳ࡹࡴࡰࡲࠫ࠭ࠒࠐࠧࠨࠩፄ"),{YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡾࡢ࡮ࡥࡪࡹ࡮࠭ፅ"):LAkCFq8ezcf,q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡸࡣ࡯ࡦࠫፆ"):RarSo2nTfwU0WEGK})
	return
def nHxt2Y5jIy4cWrZJ(jjdUcJoK8fm1pbrS):
	C30A7FMPzmarInS5K9bhfuE,nnrNqvWG5TuXtCRK = f4fTutDOEwUeIoPLRQ,f4fTutDOEwUeIoPLRQ
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(jjdUcJoK8fm1pbrS):
		try: C30A7FMPzmarInS5K9bhfuE = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.getsize(jjdUcJoK8fm1pbrS)
		except: pass
		if not C30A7FMPzmarInS5K9bhfuE:
			try: C30A7FMPzmarInS5K9bhfuE = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.stat(jjdUcJoK8fm1pbrS).st_size
			except: pass
		if not C30A7FMPzmarInS5K9bhfuE:
			try:
				from pathlib import Path as oZ8wV5H1D4vr9guib0KM7YjNznmB
				C30A7FMPzmarInS5K9bhfuE = oZ8wV5H1D4vr9guib0KM7YjNznmB(jjdUcJoK8fm1pbrS).stat().st_size
			except: pass
		if C30A7FMPzmarInS5K9bhfuE: nnrNqvWG5TuXtCRK = vkIa3ijEQVsJGdWOXwK7bnue9ADR
	return C30A7FMPzmarInS5K9bhfuE,nnrNqvWG5TuXtCRK
def bQaAGNXBYIgClLm15ui3JqU(FFyzCM05Oo9whmsKJ4au,UPpTaR7gwBXmt48hSsQr,showDialogs):
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪፇ"),FFyzCM05Oo9whmsKJ4au+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ࡞ࡱࡠࡳ࠭ፈ")+eMypvI8XqHjYU02anWD9gsSrkt+bYyKEjIuGQzoq3AR1(u"๊่ࠩࠥะั๋ัุ้ࠣำ่ࠠาสࠤฬ๊ๅอๆาࠤฤࠧࠧፉ")+c7gxFyUCGm)
		if oyNUHM3uQq!=vkIa3ijEQVsJGdWOXwK7bnue9ADR: return
	FfrbtQYZoXdWM3Lu6nKU5g0RP4 = SmbNGskjMx
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(FFyzCM05Oo9whmsKJ4au):
		for GvteTA3NKqC7RLWk,i5YdbEoS2gcpDm,l6ifO2ZNCResYtwnP0rD5S8oxac3y in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.walk(FFyzCM05Oo9whmsKJ4au,topdown=SmbNGskjMx):
			for jjdUcJoK8fm1pbrS in l6ifO2ZNCResYtwnP0rD5S8oxac3y:
				OKCM9wENivtI0buDaP34U7TsQH1 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(GvteTA3NKqC7RLWk,jjdUcJoK8fm1pbrS)
				try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(OKCM9wENivtI0buDaP34U7TsQH1)
				except Exception as TsLJDVQSbg5P9hd4YW7acCvEKqlXu:
					if showDialogs and not FfrbtQYZoXdWM3Lu6nKU5g0RP4: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ፊ"),str(TsLJDVQSbg5P9hd4YW7acCvEKqlXu))
					FfrbtQYZoXdWM3Lu6nKU5g0RP4 = Ag9l6cw3EBqP8HsQuGMizfOtr4
			if UPpTaR7gwBXmt48hSsQr:
				for dir in i5YdbEoS2gcpDm:
					RivoIjWfLJPkSa = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(GvteTA3NKqC7RLWk,dir)
					try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.rmdir(RivoIjWfLJPkSa)
					except: pass
		if UPpTaR7gwBXmt48hSsQr:
			try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.rmdir(GvteTA3NKqC7RLWk)
			except: pass
	if showDialogs and not FfrbtQYZoXdWM3Lu6nKU5g0RP4:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧፋ"),QlTuvPbSpnjygBVW(u"ࠬะๅࠡษ็ุ้ำࠠษ่ฯหา࠭ፌ"))
		ue186CEMORWhvq(SmbNGskjMx)
	return
def gg4NKLvmRJ1VdAOTwCl3Uj(mK4en38aY2UXly0rzZsoI6vMFQ5b,hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,eg6iV4ckQxvTrjWKyBulYR):
	plSscrVjkRviPwm,PB2EFL4DkoAnup7SajZq9GdRr,Thl3xtBje9dpPf6YsUoAyOzbL7Kk,WCrF2sGJaTRcZbI5n = VVRhJ5xaEkKCW(qxZiT6WJ7sX)
	EEZcU5jVnCeFk = hhyC3ID85J1uvxjFMi,plSscrVjkRviPwm,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x
	if mK4en38aY2UXly0rzZsoI6vMFQ5b<usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠴ᓚ"):
		uoxvtFlSXEPnf(SOEM49TbV0zuQ,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡖࡔࡏࡐࡎࡈࠧፍ"),EEZcU5jVnCeFk)
		mK4en38aY2UXly0rzZsoI6vMFQ5b = -mK4en38aY2UXly0rzZsoI6vMFQ5b
	if mK4en38aY2UXly0rzZsoI6vMFQ5b>UpQ56M0dO1N9xIvVegy(u"࠵ᓛ"):
		B69RXYW5vf8Jt7O = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡴࡶࡵࠫፎ"),I3cxjYaHhsrM7T4UX26klN(u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࡡࡘࡖࡑࡒࡉࡃࠩፏ"),EEZcU5jVnCeFk)
		if B69RXYW5vf8Jt7O:
			qvUe2bwfQ7sZKV(SSvu1CZjTW7FcloNqD(u"ࠩࡘࡖࡑࡒࡉࡃࠢࠣࡖࡊࡇࡄࡠࡅࡄࡇࡍࡋࠧፐ"),qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,eg6iV4ckQxvTrjWKyBulYR,hhyC3ID85J1uvxjFMi)
			return B69RXYW5vf8Jt7O
	B69RXYW5vf8Jt7O = CyiwT9JuQ2zYSqep618I3FR7G(hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,eg6iV4ckQxvTrjWKyBulYR)
	if B69RXYW5vf8Jt7O and mK4en38aY2UXly0rzZsoI6vMFQ5b: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣ࡚ࡘࡌࡍࡋࡅࠫፑ"),EEZcU5jVnCeFk,B69RXYW5vf8Jt7O,mK4en38aY2UXly0rzZsoI6vMFQ5b)
	return B69RXYW5vf8Jt7O
from hsnod063KQ import *
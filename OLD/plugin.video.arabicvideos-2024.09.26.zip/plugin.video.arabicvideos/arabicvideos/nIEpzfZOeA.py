# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'CIMANOW'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_CMN_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['قائمتي']
def n1zxUlcAgR(mode,url,text):
	if   mode==300: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==301: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==302: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==303: bPFto2wZdNYrClgBIEv60DJAzu = m3I0Japv1Zn58kT4ExWGdYAjPNgt2(url)
	elif mode==304: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==305: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==306: bPFto2wZdNYrClgBIEv60DJAzu = Q7WcgGmChLNKOT1vUrM()
	elif mode==309: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'لماذا الموقع بطيء',nbOFVEDkpT4BIR7Qq82yPmHeJU,306)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,309,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs+'/home',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMANOW-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<header>(.*?)</header>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<li><a href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = title.strip(S3X6GcaiExOPtb)
		if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,301)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Cvflxc4FMs37bmY(zKREXyTHfVSNL8ZFYs+'/home',UTvsQb4HpCP3Aeo2wDZG7X5V)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Q7WcgGmChLNKOT1vUrM():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','موقع سيما ناو بطيء من المصدر .. بسبب قيام أصحاب الموقع بتشفير محتويات جميع صفحات الموقع .. والوقت الضائع يذهب في معالجة تشفير الصفحات المشفرة قبل عرض محتوياتها في قوائم هذا البرنامج')
	return
def Cvflxc4FMs37bmY(url,UTvsQb4HpCP3Aeo2wDZG7X5V=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not UTvsQb4HpCP3Aeo2wDZG7X5V:
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMANOW-SUBMENU-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	wDIU0SN9GBtzZPoihYnv2xjqQC = 0
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(<section>.*?</section>)',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		for G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			wDIU0SN9GBtzZPoihYnv2xjqQC += 1
			items = ScntgdOZCY74vNpXeW5jh8i.findall('<section>.<span>(.*?)<(.*?)href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for title,IAFZ7NyqObsC8VeL32d9aHDvki,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
				title = title.strip(S3X6GcaiExOPtb)
				if title==nbOFVEDkpT4BIR7Qq82yPmHeJU: title = 'بووووو'
				if 'em><a' not in IAFZ7NyqObsC8VeL32d9aHDvki:
					if G4JHzTEp61.count('/category/')>0:
						VR3buw1nY8cUTpWge = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in VR3buw1nY8cUTpWge:
							title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-2]
							Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,301)
						continue
					else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+'?sequence='+str(wDIU0SN9GBtzZPoihYnv2xjqQC)
				if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,302)
	else: IGDobAKtj4kPF5V(url,UTvsQb4HpCP3Aeo2wDZG7X5V)
	return
def IGDobAKtj4kPF5V(url,UTvsQb4HpCP3Aeo2wDZG7X5V=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if UTvsQb4HpCP3Aeo2wDZG7X5V==nbOFVEDkpT4BIR7Qq82yPmHeJU:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMANOW-TITLES-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if '?sequence=' in url:
		url,wDIU0SN9GBtzZPoihYnv2xjqQC = url.split('?sequence=')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(<section>.*?</section>)',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[int(wDIU0SN9GBtzZPoihYnv2xjqQC)-1]
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"posts"(.*?)</body>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<a.*?href="(.*?)"(.*?)data-src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,data,X79kphTKa1xLP in items:
		title = ScntgdOZCY74vNpXeW5jh8i.findall('<em>(.*?)</em>(.*?)</li>.*?</em>(.*?)<em>',data,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if title: title = title[0][2].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		if not title or title==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			title = ScntgdOZCY74vNpXeW5jh8i.findall('title">.*?</em>(.*?)<',data,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if title: title = title[0].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			if not title or title==nbOFVEDkpT4BIR7Qq82yPmHeJU:
				title = ScntgdOZCY74vNpXeW5jh8i.findall('title">(.*?)<',data,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				title = title[0].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		title = dCtxzeFX4GJVonm(title)
		title = title.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		if title not in tWsVFQj47pw0L56rZfg:
			tWsVFQj47pw0L56rZfg.append(title)
			eXBMHvPbDunL = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+data+X79kphTKa1xLP
			if '/selary/' in eXBMHvPbDunL or 'مسلسل' in eXBMHvPbDunL or '"episode"' in eXBMHvPbDunL:
				if 'برامج' in data: title = 'برنامج '+title
				elif 'مسلسل' in data or 'موسم' in data: title = 'مسلسل '+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,303,X79kphTKa1xLP)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,305,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<li><a href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,302)
	return
def m3I0Japv1Zn58kT4ExWGdYAjPNgt2(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMANOW-SEASONS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	name = ScntgdOZCY74vNpXeW5jh8i.findall('<title>(.*?)</title>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	name = name[0].replace('| سيما ناو',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('Cima Now',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	name = name.split('الحلقة')[0].strip(S3X6GcaiExOPtb)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<section(.*?)</section>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(items)>1:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = name+' - '+title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,304)
		else: PXyn8J3WjhRgA(url)
	return
def PXyn8J3WjhRgA(url):
	if '/selary/' not in url: url = url.strip('/')+'/watching'
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMANOW-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if '/selary/' not in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"episodes"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			title = 'الحلقة '+title
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,305)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"details"(.*?)"related"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src=.*?src="(.*?)".*?alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,305,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	plSscrVjkRviPwm = url+'watching/'
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMANOW-PLAY-5th')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	lPpY5fw3tOBcEye91Caun2FQZ = []
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"download"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			uTKGhcXEIpmDf = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if uTKGhcXEIpmDf:
				uTKGhcXEIpmDf = '____'+uTKGhcXEIpmDf[0]
				title = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
			else: uTKGhcXEIpmDf = nbOFVEDkpT4BIR7Qq82yPmHeJU
			f7Je8XzEqNpgHL9m4OURdAQ1 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'+uTKGhcXEIpmDf
			lPpY5fw3tOBcEye91Caun2FQZ.append(f7Je8XzEqNpgHL9m4OURdAQ1)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"watch"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('"embed".*?src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P:
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			title = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__embed'
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		rU02bCJFWZDfVuhtMgBOyQi5P = [zKREXyTHfVSNL8ZFYs+'/wp-content/themes/Cima%20Now%20New/core.php']
		if rU02bCJFWZDfVuhtMgBOyQi5P:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('data-index="(.*?)".*?data-id="(.*?)".*?>(.*?)</li>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for wX9P3dR07B5HynVa8,id,title in items:
				title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = rU02bCJFWZDfVuhtMgBOyQi5P[0]+'?action=switch&index='+wX9P3dR07B5HynVa8+'&id='+id+'?named='+title+'__watch'
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs + '/?s='+search
	IGDobAKtj4kPF5V(url)
	return
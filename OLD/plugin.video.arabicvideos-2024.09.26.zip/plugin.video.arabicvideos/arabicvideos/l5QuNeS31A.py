# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'ALKAWTHAR'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_KWT_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
def n1zxUlcAgR(mode,url,ohpwd6UumaecE3IWV8lAv0,text):
	if   mode==130: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==131: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==132: bPFto2wZdNYrClgBIEv60DJAzu = Q5Q4NriupnKU(url)
	elif mode==133: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==134: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==135: bPFto2wZdNYrClgBIEv60DJAzu = dsFVer3DMTj2iQANyPmvkYU7()
	elif mode==139: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text,url)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,139,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-MENU-1st')
	eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('dropdown-menu(.*?)dropdown-toggle',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[1]
	items=ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if '/conductor' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		title = title.strip(S3X6GcaiExOPtb)
		url = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if '/category/' in url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,132)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,131)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المسلسلات',zKREXyTHfVSNL8ZFYs+'/category/543',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الأفلام',zKREXyTHfVSNL8ZFYs+'/category/628',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'برامج الصغار والشباب',zKREXyTHfVSNL8ZFYs+'/category/517',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'ابرز البرامج',zKREXyTHfVSNL8ZFYs+'/category/1763',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المحاضرات',zKREXyTHfVSNL8ZFYs+'/category/943',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'عاشوراء',zKREXyTHfVSNL8ZFYs+'/category/1353',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'البرامج الاجتماعية',zKREXyTHfVSNL8ZFYs+'/category/501',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'البرامج الدينية',zKREXyTHfVSNL8ZFYs+'/category/509',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'البرامج الوثائقية',zKREXyTHfVSNL8ZFYs+'/category/553',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'البرامج السياسية',zKREXyTHfVSNL8ZFYs+'/category/545',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'كتب',zKREXyTHfVSNL8ZFYs+'/category/291',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'تعلم الفارسية',zKREXyTHfVSNL8ZFYs+'/category/88',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أرشيف البرامج',zKREXyTHfVSNL8ZFYs+'/category/1279',132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	return
def IGDobAKtj4kPF5V(url):
	Vp9ol2W4DqYK7CMQbAciPxzd8jJn5 = ['/religious','/social','/political','/films','/series']
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-TITLES-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('titlebar(.*?)titlebar',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if any(XPL0O2VkI3w1C8enMaqi in url for XPL0O2VkI3w1C8enMaqi in Vp9ol2W4DqYK7CMQbAciPxzd8jJn5):
		items = ScntgdOZCY74vNpXeW5jh8i.findall("src='(.*?)'.*?href='(.*?)'.*?>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,133,X79kphTKa1xLP,'1')
	elif '/docs' in url:
		items = ScntgdOZCY74vNpXeW5jh8i.findall("src='(.*?)'.*?<h2>(.*?)</h2>.*?href='(.*?)'",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X79kphTKa1xLP,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			title = title.strip(S3X6GcaiExOPtb)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,133,X79kphTKa1xLP,'1')
	return
def Q5Q4NriupnKU(url):
	jGdXt7eADorwlv8pahNV95H6Tn2qKx = url.split('/')[-1]
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-CATEGORIES-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('parentcat(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5:
		PXyn8J3WjhRgA(url,'1')
		return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall("href='(.*?)'.*?>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = title.strip(S3X6GcaiExOPtb)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,132,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
	return
def PXyn8J3WjhRgA(url,ohpwd6UumaecE3IWV8lAv0):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-EPISODES-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('totalpagecount=[\'"](.*?)[\'"]',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items:
		url = ScntgdOZCY74vNpXeW5jh8i.findall('class="news-detail-body".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		url = url[0]
		title = '_MOD_' + 'ملف التشغيل'
		if url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,134)
		else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','لا يوجد حاليا ملفات فيديو في هذا الفرع')
		return
	OsDiwWYvKXhjFcf05RzZSkCNypn3B = int(items[0])
	name = ScntgdOZCY74vNpXeW5jh8i.findall('main-title.*?</a> >(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if name: name = name[0].strip(S3X6GcaiExOPtb)
	else: name = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Label')
	if '/category/' in url or 'search?q=' in url:
		jGdXt7eADorwlv8pahNV95H6Tn2qKx = url.split('/')[-1]
		if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs + '/category/' + jGdXt7eADorwlv8pahNV95H6Tn2qKx + '/' + ohpwd6UumaecE3IWV8lAv0
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-EPISODES-2nd')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('currentpagenumber(.*?)pagination',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?full(.*?)>.*?href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X79kphTKa1xLP,type,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if 'video' not in type: continue
			if 'مسلسل' in title and 'حلقة' not in title: continue
			title = title.replace('\r\n',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			title = title.strip(S3X6GcaiExOPtb)
			if 'مسلسل' in name and 'حلقة' in title and 'مسلسل' not in title:
				title = '_MOD_' + name + ' - ' + title
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx=='628': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,133,X79kphTKa1xLP,'1')
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,134,X79kphTKa1xLP)
	elif '/episode/' in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('playlist(.*?)col-md-12',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall("video-track-text.*?loadVideo\('(.*?)','(.*?)'.*?>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,134,X79kphTKa1xLP)
		elif '/category/628' in UTvsQb4HpCP3Aeo2wDZG7X5V:
				title = '_MOD_' + 'ملف التشغيل'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,134)
		else:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('id="Categories.*?href=\'(.*?)\'',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			jGdXt7eADorwlv8pahNV95H6Tn2qKx = items[0].split('/')[-1]
			url = zKREXyTHfVSNL8ZFYs + '/category/' + jGdXt7eADorwlv8pahNV95H6Tn2qKx
			Q5Q4NriupnKU(url)
			return
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		pmCWvsK7JxeMN = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in pmCWvsK7JxeMN:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('&amp;','&')
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,133)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	if '/news/' in url or '/episode/' in url:
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-PLAY-1st')
		items = ScntgdOZCY74vNpXeW5jh8i.findall("mobilevideopath.*?value='(.*?)'",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items: url = items[0]
	brh5aWRxQzn6YL8UDNOyK9SFGo(url,QSJFrwB3dMiyH2mTPKD9a,'video')
	return
def dsFVer3DMTj2iQANyPmvkYU7():
	url = zKREXyTHfVSNL8ZFYs+'/live'
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-LIVE-1st')
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('live-container.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = plSscrVjkRviPwm[0]
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Referer':zKREXyTHfVSNL8ZFYs}
	KXFGbQxMAgBRYh = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALKAWTHAR-LIVE-2nd')
	fv4KNqjIBQT0UcHmlYSnrwOAWGV = KXFGbQxMAgBRYh.content
	ffiueHIMq6oQxRpyO1ShacVGL4Pg = ScntgdOZCY74vNpXeW5jh8i.findall('csrf-token" content="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	ffiueHIMq6oQxRpyO1ShacVGL4Pg = ffiueHIMq6oQxRpyO1ShacVGL4Pg[0]
	gZMpFHKByVDdzP2mrokniYJ0 = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,'url')
	zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall("playUrl = '(.*?)'",fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	zb2QIaL7Y4h9g8lSck = gZMpFHKByVDdzP2mrokniYJ0+zb2QIaL7Y4h9g8lSck[0]
	I6czP5lQ0kxNrXwfdmVZyB8ED = {'X-CSRF-TOKEN':ffiueHIMq6oQxRpyO1ShacVGL4Pg}
	XoP5dRbLCpM7mIjw9E0YcKn8 = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,I6czP5lQ0kxNrXwfdmVZyB8ED,False,True,'ALKAWTHAR-LIVE-3rd')
	PvGT0e4Ybf = XoP5dRbLCpM7mIjw9E0YcKn8.content
	jYzLtvxkH7R3msNZwhgeT90noEu5q = ScntgdOZCY74vNpXeW5jh8i.findall('"(.*?)"',PvGT0e4Ybf,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	jYzLtvxkH7R3msNZwhgeT90noEu5q = jYzLtvxkH7R3msNZwhgeT90noEu5q[0].replace('\/','/')
	brh5aWRxQzn6YL8UDNOyK9SFGo(jYzLtvxkH7R3msNZwhgeT90noEu5q,QSJFrwB3dMiyH2mTPKD9a,'live')
	return
def cvZoNw4F0fRjYaMuP5CVrE(search,url=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if url==nbOFVEDkpT4BIR7Qq82yPmHeJU:
		if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
		if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
		search = lcxFAteLQ1Pwu45Er2(search)
		url = zKREXyTHfVSNL8ZFYs+'/search?q='+search
		PXyn8J3WjhRgA(url,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		return
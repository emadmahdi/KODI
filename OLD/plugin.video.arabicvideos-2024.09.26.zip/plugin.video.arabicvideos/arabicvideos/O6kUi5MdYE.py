# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'EGYBEST1'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_EB1_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['مكتبتي','ايجي بست']
def n1zxUlcAgR(mode,url,ohpwd6UumaecE3IWV8lAv0,text):
	if   mode==770: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==771: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==772: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==773: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==774: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'FULL_FILTER___'+text)
	elif mode==775: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'DEFINED_FILTER___'+text)
	elif mode==776: bPFto2wZdNYrClgBIEv60DJAzu = RG2K4b1gqI9ViYQX(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==779: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text,url)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,779,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST1-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('nav-list(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<span>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,771)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-article(.*?)social-box',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('main-title.*?">(.*?)<.*?href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			title = title.strip(S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,771,nbOFVEDkpT4BIR7Qq82yPmHeJU,'mainmenu')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-menu(.*?)</div></div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,771)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def RG2K4b1gqI9ViYQX(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST1-SEASONS_EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-article".*?">(.*?)<(.*?)article',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,HOsekxhQY6NrK1tcGu8BvVo7CLyUIP,items = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
		for name,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			if 'حلقات' in name: HOsekxhQY6NrK1tcGu8BvVo7CLyUIP = G4JHzTEp61
			if 'مواسم' in name: KXVHpZTa3BCSWlQYUut0PdDLc94Rzo = G4JHzTEp61
		if KXVHpZTa3BCSWlQYUut0PdDLc94Rzo and not type:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if len(items)>1:
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,776,X79kphTKa1xLP,'season')
		if HOsekxhQY6NrK1tcGu8BvVo7CLyUIP and len(items)<2:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',HOsekxhQY6NrK1tcGu8BvVo7CLyUIP,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if items:
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,773,X79kphTKa1xLP)
			else:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',HOsekxhQY6NrK1tcGu8BvVo7CLyUIP,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,773)
	return
def IGDobAKtj4kPF5V(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST1-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	items,ii2tNgwPc0CZ6Lyh4A3fT,c2oNVv4ptmTlhgL9s = [],False,False
	if not type:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-content(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,771,nbOFVEDkpT4BIR7Qq82yPmHeJU,'submenu')
				ii2tNgwPc0CZ6Lyh4A3fT = True
	if not type and 'p=' not in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('searchform(.*?)</form>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			if ii2tNgwPc0CZ6Lyh4A3fT: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',url,775,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',url,774,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث',url,779)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			c2oNVv4ptmTlhgL9s = True
	if not ii2tNgwPc0CZ6Lyh4A3fT:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('blocks(.*?)article',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
				X79kphTKa1xLP = X79kphTKa1xLP.strip(wwOnIucWJj)
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				if '/serie/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,776,X79kphTKa1xLP,'season')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,773,X79kphTKa1xLP)
			ohpwd6UumaecE3IWV8lAv0 = '1'
			if 'p=' in url: url,ohpwd6UumaecE3IWV8lAv0 = url.split('p=',1)
			IgtL0mb7hnwEpYyuf6KUxXR = '&' if '?' in url else '?'
			url = url+IgtL0mb7hnwEpYyuf6KUxXR
			url = url.replace('?&','?')
			if len(items)==40:
				url = url+'p='+str(int(ohpwd6UumaecE3IWV8lAv0)+1)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الصفحة التالية',url,771)
			elif ohpwd6UumaecE3IWV8lAv0!='1':
				url = url+'p='+str(int(ohpwd6UumaecE3IWV8lAv0)-1)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الصفحة السابقة',url,771)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST1-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('<label>التصنيف</label>.*?">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc,jtl0KQXhgEzFPJx1V = [],[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('download-section.*?action="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in jtl0KQXhgEzFPJx1V:
			jtl0KQXhgEzFPJx1V.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=__embed______'+lcxFAteLQ1Pwu45Er2(url))
	ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('WatchServers(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall("url='(.*?)'.*?>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o in rU02bCJFWZDfVuhtMgBOyQi5P:
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in jtl0KQXhgEzFPJx1V:
				jtl0KQXhgEzFPJx1V.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__both______'+lcxFAteLQ1Pwu45Er2(url))
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search,url=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search: search = dR75Vq2gprfHmUcNhG()
	if not search: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'%20')
	if not url: url = zKREXyTHfVSNL8ZFYs+'/search?query='+T871qPZzS4LkoMBa3Db9Q
	else: url = url+'?title='+T871qPZzS4LkoMBa3Db9Q+'&genre=&year=&lang='
	IGDobAKtj4kPF5V(url,'search')
	return
def XCdegEMjq1uDz3whim(url):
	url = url.split('/smartemadfilter?')[0]
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST1-GET_FILTERS_BLOCKS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	m8kVhKyAp7NCibFJ3sYO4EwMS = []
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('form-row(.*?)</form>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('select name="(.*?)".*?value>(.*?)<(.*?)</select',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		b2o6IZgK0h9TkNjqXdpAHB,QlL1JM5odKm9ZrEWwfesuP4jq,ISmqngYzv6jrepWUx0l = zip(*m8kVhKyAp7NCibFJ3sYO4EwMS)
		m8kVhKyAp7NCibFJ3sYO4EwMS = zip(QlL1JM5odKm9ZrEWwfesuP4jq,b2o6IZgK0h9TkNjqXdpAHB,ISmqngYzv6jrepWUx0l)
	return m8kVhKyAp7NCibFJ3sYO4EwMS
def Ubu4qfBDldYcI06(G4JHzTEp61):
	items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return items
def fcTiZpgPJwr(url):
	url = url.replace('/smartemadfilter?','?title=&')
	return url
xxLBlqUiovf95hGV = ['year','lang','genre']
MNx58jZdRO = ['year','lang','genre']
def bpRLN7ZqT5BiXKfMdI(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='DEFINED_FILTER':
		if MNx58jZdRO[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MNx58jZdRO[0]
		for WoEZvMXa0K2suwgPl in range(len(MNx58jZdRO[0:-1])):
			if MNx58jZdRO[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MNx58jZdRO[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'all')
		plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	elif type=='FULL_FILTER':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'all')
		if not RAf62IHC9L0OUl1oETijSgyxX5F: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'/smartemadfilter?'+RAf62IHC9L0OUl1oETijSgyxX5F
		zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',zb2QIaL7Y4h9g8lSck,771,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',zb2QIaL7Y4h9g8lSck,771,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	m8kVhKyAp7NCibFJ3sYO4EwMS = XCdegEMjq1uDz3whim(url)
	dict = {}
	for name,TT4Yd6yIaJGxZtoR8mh2O7,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		name = name.replace('كل ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		items = Ubu4qfBDldYcI06(G4JHzTEp61)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='DEFINED_FILTER':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<2:
				if TT4Yd6yIaJGxZtoR8mh2O7==MNx58jZdRO[-1]:
					zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
					IGDobAKtj4kPF5V(zb2QIaL7Y4h9g8lSck)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'DEFINED_FILTER___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				if TT4Yd6yIaJGxZtoR8mh2O7==MNx58jZdRO[-1]:
					zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',zb2QIaL7Y4h9g8lSck,771,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',plSscrVjkRviPwm,775,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='FULL_FILTER':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع :'+name,plSscrVjkRviPwm,774,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			if not XPL0O2VkI3w1C8enMaqi: continue
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			title = PspiL81kMT4BwOIXo+' :'#+dict[TT4Yd6yIaJGxZtoR8mh2O7]['0']
			title = PspiL81kMT4BwOIXo+' :'+name
			if type=='FULL_FILTER': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,774,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='DEFINED_FILTER' and MNx58jZdRO[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
				plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
				zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,771,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
			elif type=='DEFINED_FILTER': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,775,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.replace('=&','=0&')
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for key in xxLBlqUiovf95hGV:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('=0','=')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
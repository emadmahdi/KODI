# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'CIMACLUP'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_CMC_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['موقع نتفليكس']
def n1zxUlcAgR(mode,url,text):
	if   mode==490: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==491: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==492: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==493: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==494: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==499: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text,url)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMACLUP-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO[0].strip('/')
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,'url')
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"filter AjaxifyFilter"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-filter="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title in CZrI4vYju7a: continue
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/wp-content/themes/old/filter/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'.php'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,491)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أفلام',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/category/مسلسلات/مسلسلات-اجنبى',494,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="navigation-menu"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='/': continue
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if title in CZrI4vYju7a: continue
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,491)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Cvflxc4FMs37bmY(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMACLUP-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"filter"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IHV3wWCjYv4:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title in CZrI4vYju7a: continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,491)
	return
def IGDobAKtj4kPF5V(url,it8kJjp6GIWLOEBfm3zl0H7Qr4ygq=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	items = []
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMACLUP-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	G4JHzTEp61 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if '.php' in url: G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
	elif '?s=' in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"blocks(.*?)"manifest"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"Blocks(.*?)"manifest"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if not G4JHzTEp61: return
	tWsVFQj47pw0L56rZfg = []
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		title = dCtxzeFX4GJVonm(title)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) حلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not BBuqr7CwzEIi9UL54n0AVoHXPlp: BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not BBuqr7CwzEIi9UL54n0AVoHXPlp or any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,492,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp and 'حلقة' in title:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,493,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,493,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<li><a href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = dCtxzeFX4GJVonm(title)
			title = title.replace('الصفحة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,491)
	return
def PXyn8J3WjhRgA(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMACLUP-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('"ButtonsBarCo".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm:
		plSscrVjkRviPwm = plSscrVjkRviPwm[0]
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMACLUP-EPISODES-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	X79kphTKa1xLP = ScntgdOZCY74vNpXeW5jh8i.findall('"img-responsive" src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP[0]
	else: X79kphTKa1xLP = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Thumb')
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"filter"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"Blocks(.*?)class="pagination"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IHV3wWCjYv4 and '/series/' not in url:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,493,X79kphTKa1xLP)
	elif b8Ior2kWzq1tc:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,492,X79kphTKa1xLP)
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = dCtxzeFX4GJVonm(title)
				title = title.replace('الصفحة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,491)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	plSscrVjkRviPwm = url.strip('/')+'/?view=1'
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMACLUP-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	lPpY5fw3tOBcEye91Caun2FQZ = []
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	sahdZz9p8k0QGf156eSFEgPVb = ScntgdOZCY74vNpXeW5jh8i.findall("data: 'q=(.*?)&",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	sahdZz9p8k0QGf156eSFEgPVb = sahdZz9p8k0QGf156eSFEgPVb[0]
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"serversList"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-server="(.*?)">(.*?)</li>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for w49tWZ6hDF7vU,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/wp-content/themes/old/servers/server.php?q='+sahdZz9p8k0QGf156eSFEgPVb+'&i='+w49tWZ6hDF7vU+'?named='+title+'__watch'
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"embedServer".*?SRC="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		title = 'مفضل'
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]+'?named=__embed__'+title
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"downloadsList"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<td>(.*?)</td>.*?href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			title = title.strip(S3X6GcaiExOPtb)
			if 'anavidz' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: HDE69mkhQg2NaFpuUy5JRb = '__خاص'
			else: HDE69mkhQg2NaFpuUy5JRb = nbOFVEDkpT4BIR7Qq82yPmHeJU
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'+HDE69mkhQg2NaFpuUy5JRb
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search,R0mG4duvNLUHqgT8X7yZ6zBxk3CiO=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not R0mG4duvNLUHqgT8X7yZ6zBxk3CiO: R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = zKREXyTHfVSNL8ZFYs
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/index.php?s='+search
	IGDobAKtj4kPF5V(url)
	return
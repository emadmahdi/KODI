# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
VGjzYJZykfEWxlQLeap = 'EXCLUDES'
def GwFQmo3Yb8sdz(xbfwC5hkXLvsJa8PReOS9AyU1z,eH9C6OmRIMh3Sc4yN):
	eH9C6OmRIMh3Sc4yN = eH9C6OmRIMh3Sc4yN.replace(eMypvI8XqHjYU02anWD9gsSrkt,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(' '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU)[1:]
	J2Fi8gj0tvUfoOLb = ScntgdOZCY74vNpXeW5jh8i.findall('[a-zA-Z]',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if 'بحث IPTV - ' in xbfwC5hkXLvsJa8PReOS9AyU1z: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('بحث IPTV - ',dVMZJNUoPLOSp47lkeh6T0W31Gj+'بحث IPTV - '+dVMZJNUoPLOSp47lkeh6T0W31Gj)
	elif ' IPTV' in xbfwC5hkXLvsJa8PReOS9AyU1z and eH9C6OmRIMh3Sc4yN=='IPT': xbfwC5hkXLvsJa8PReOS9AyU1z = dVMZJNUoPLOSp47lkeh6T0W31Gj+xbfwC5hkXLvsJa8PReOS9AyU1z
	elif 'بحث M3U - ' in xbfwC5hkXLvsJa8PReOS9AyU1z: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('بحث M3U - ',dVMZJNUoPLOSp47lkeh6T0W31Gj+'بحث M3U - '+dVMZJNUoPLOSp47lkeh6T0W31Gj)
	elif ' M3U' in xbfwC5hkXLvsJa8PReOS9AyU1z and eH9C6OmRIMh3Sc4yN=='M3U': xbfwC5hkXLvsJa8PReOS9AyU1z = dVMZJNUoPLOSp47lkeh6T0W31Gj+xbfwC5hkXLvsJa8PReOS9AyU1z
	elif 'بحث ' in xbfwC5hkXLvsJa8PReOS9AyU1z and ' - ' in xbfwC5hkXLvsJa8PReOS9AyU1z: xbfwC5hkXLvsJa8PReOS9AyU1z = dVMZJNUoPLOSp47lkeh6T0W31Gj+xbfwC5hkXLvsJa8PReOS9AyU1z
	elif not J2Fi8gj0tvUfoOLb:
		BoeZCIb5xp8VfOLv = ScntgdOZCY74vNpXeW5jh8i.findall('^( *?)(.*?)( *?)$',xbfwC5hkXLvsJa8PReOS9AyU1z)
		GLNoXmvJ6Ap83c0tbs,SoWYxpiaKmecwr,ccvfQ1bsMPW6GRdYUDk4HpJgjn3 = BoeZCIb5xp8VfOLv[0]
		Cnoz17mR3d = ScntgdOZCY74vNpXeW5jh8i.findall('^([!-~])',SoWYxpiaKmecwr)
		if Cnoz17mR3d: xbfwC5hkXLvsJa8PReOS9AyU1z = GLNoXmvJ6Ap83c0tbs+AQJdiEVCZaDfh4+SoWYxpiaKmecwr+ccvfQ1bsMPW6GRdYUDk4HpJgjn3
		else: xbfwC5hkXLvsJa8PReOS9AyU1z = ccvfQ1bsMPW6GRdYUDk4HpJgjn3+dVMZJNUoPLOSp47lkeh6T0W31Gj+SoWYxpiaKmecwr+GLNoXmvJ6Ap83c0tbs
	else:
		import bidi.algorithm as InTA8P54xi0Ocg
		if 1:
			SL1JDCfc8gpUO5q0M7hsHu = xbfwC5hkXLvsJa8PReOS9AyU1z
			rgD5qesfV7xSa1RPKcy = InTA8P54xi0Ocg.get_display(xbfwC5hkXLvsJa8PReOS9AyU1z,base_dir='L')
			if n7neb9KTv10FcU: SL1JDCfc8gpUO5q0M7hsHu = SL1JDCfc8gpUO5q0M7hsHu.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			if n7neb9KTv10FcU: rgD5qesfV7xSa1RPKcy = rgD5qesfV7xSa1RPKcy.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			T5zESaQH6PBtdlLZsmAouwUfk = SL1JDCfc8gpUO5q0M7hsHu.split(S3X6GcaiExOPtb)
			Lr6AnhqDkIuxKiEUF4jRe0vfY5W = rgD5qesfV7xSa1RPKcy.split(S3X6GcaiExOPtb)
			Xpe9IJs6tCVd1fzBWgio0M78Hx,EiptCMcJoy37n0k9,JKmYRNCVla,LLleQvNd9SbIJ = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
			GmFbu6KwzRjL = zip(T5zESaQH6PBtdlLZsmAouwUfk,Lr6AnhqDkIuxKiEUF4jRe0vfY5W)
			for xxvC15bY0zHKDtcFXSG,O8IBYXDlhUG9cudgq1z7AfiEe in GmFbu6KwzRjL:
				if xxvC15bY0zHKDtcFXSG==O8IBYXDlhUG9cudgq1z7AfiEe==nbOFVEDkpT4BIR7Qq82yPmHeJU and LLleQvNd9SbIJ:
					JKmYRNCVla += S3X6GcaiExOPtb
					continue
				if xxvC15bY0zHKDtcFXSG==O8IBYXDlhUG9cudgq1z7AfiEe:
					oGhrR2kuUM5PIEgbyxHLaAqVecOZ = 'EN'
					if LLleQvNd9SbIJ==oGhrR2kuUM5PIEgbyxHLaAqVecOZ: JKmYRNCVla += S3X6GcaiExOPtb+xxvC15bY0zHKDtcFXSG
					elif xxvC15bY0zHKDtcFXSG:
						if JKmYRNCVla:
							EiptCMcJoy37n0k9.append(JKmYRNCVla)
							Xpe9IJs6tCVd1fzBWgio0M78Hx.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
						JKmYRNCVla = xxvC15bY0zHKDtcFXSG
				else:
					oGhrR2kuUM5PIEgbyxHLaAqVecOZ = 'AR'
					if LLleQvNd9SbIJ==oGhrR2kuUM5PIEgbyxHLaAqVecOZ: JKmYRNCVla += S3X6GcaiExOPtb+xxvC15bY0zHKDtcFXSG
					elif xxvC15bY0zHKDtcFXSG:
						if JKmYRNCVla:
							Xpe9IJs6tCVd1fzBWgio0M78Hx.append(JKmYRNCVla)
							EiptCMcJoy37n0k9.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
						JKmYRNCVla = xxvC15bY0zHKDtcFXSG
				LLleQvNd9SbIJ = oGhrR2kuUM5PIEgbyxHLaAqVecOZ
			if oGhrR2kuUM5PIEgbyxHLaAqVecOZ=='EN':
				Xpe9IJs6tCVd1fzBWgio0M78Hx.append(JKmYRNCVla)
				EiptCMcJoy37n0k9.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
			else:
				EiptCMcJoy37n0k9.append(JKmYRNCVla)
				Xpe9IJs6tCVd1fzBWgio0M78Hx.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
			cZqDa8dLoEe3b1gruO0F = nbOFVEDkpT4BIR7Qq82yPmHeJU
			GmFbu6KwzRjL = zip(Xpe9IJs6tCVd1fzBWgio0M78Hx,EiptCMcJoy37n0k9)
			import bidi.mirror as I63TFmlV1decR
			for CqVOdTxfJbjQrWngGZ6uFEm5D2aU,g6zw534l8DC1SxyRdTpGkXfF in GmFbu6KwzRjL:
				if CqVOdTxfJbjQrWngGZ6uFEm5D2aU: cZqDa8dLoEe3b1gruO0F += S3X6GcaiExOPtb+CqVOdTxfJbjQrWngGZ6uFEm5D2aU
				else:
					Cnoz17mR3d = ScntgdOZCY74vNpXeW5jh8i.findall('([!-~]) *$',g6zw534l8DC1SxyRdTpGkXfF)
					if Cnoz17mR3d:
						Cnoz17mR3d = Cnoz17mR3d[0]
						try:
							FigGou8hqynKep4ZvQ = I63TFmlV1decR.MIRRORED[Cnoz17mR3d]
							BoeZCIb5xp8VfOLv = ScntgdOZCY74vNpXeW5jh8i.findall('^( *?)(.*?)( *?)$',g6zw534l8DC1SxyRdTpGkXfF)
							if BoeZCIb5xp8VfOLv: GLNoXmvJ6Ap83c0tbs,g6zw534l8DC1SxyRdTpGkXfF,ccvfQ1bsMPW6GRdYUDk4HpJgjn3 = BoeZCIb5xp8VfOLv[0]
							g6zw534l8DC1SxyRdTpGkXfF = GLNoXmvJ6Ap83c0tbs+FigGou8hqynKep4ZvQ+g6zw534l8DC1SxyRdTpGkXfF[:-1]+ccvfQ1bsMPW6GRdYUDk4HpJgjn3
						except: pass
					cZqDa8dLoEe3b1gruO0F += S3X6GcaiExOPtb+g6zw534l8DC1SxyRdTpGkXfF
			xbfwC5hkXLvsJa8PReOS9AyU1z = cZqDa8dLoEe3b1gruO0F[1:]
			if n7neb9KTv10FcU: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		else:
			if n7neb9KTv10FcU: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			xbfwC5hkXLvsJa8PReOS9AyU1z = InTA8P54xi0Ocg.get_display(xbfwC5hkXLvsJa8PReOS9AyU1z)
			SL1JDCfc8gpUO5q0M7hsHu,rgD5qesfV7xSa1RPKcy = xbfwC5hkXLvsJa8PReOS9AyU1z,xbfwC5hkXLvsJa8PReOS9AyU1z
			if 1:
				LLleQvNd9SbIJ,vOGbzjQxCEY9BdLe0sF4q = nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
				JXlQCvTbSY = xbfwC5hkXLvsJa8PReOS9AyU1z.split(S3X6GcaiExOPtb)
				for oDBFOQHy8j1wpNI5ha2Er3g4U in JXlQCvTbSY:
					if not oDBFOQHy8j1wpNI5ha2Er3g4U:
						if vOGbzjQxCEY9BdLe0sF4q: vOGbzjQxCEY9BdLe0sF4q[-1] += S3X6GcaiExOPtb
						else: vOGbzjQxCEY9BdLe0sF4q.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
						continue
					O3GYEBD97d = ScntgdOZCY74vNpXeW5jh8i.findall('[!-~]',oDBFOQHy8j1wpNI5ha2Er3g4U[0])
					if O3GYEBD97d==LLleQvNd9SbIJ and vOGbzjQxCEY9BdLe0sF4q: vOGbzjQxCEY9BdLe0sF4q[-1] += S3X6GcaiExOPtb+oDBFOQHy8j1wpNI5ha2Er3g4U
					else:
						if vOGbzjQxCEY9BdLe0sF4q:
							YwNK1c40vokfaEFsRBQePDdUM29G = ScntgdOZCY74vNpXeW5jh8i.findall('[^!-~]',vOGbzjQxCEY9BdLe0sF4q[-1])
							if YwNK1c40vokfaEFsRBQePDdUM29G:
								vOGbzjQxCEY9BdLe0sF4q[-1] = InTA8P54xi0Ocg.get_display(vOGbzjQxCEY9BdLe0sF4q[-1])
								GemoUfjIL3CD4wK = ScntgdOZCY74vNpXeW5jh8i.findall('^ +',vOGbzjQxCEY9BdLe0sF4q[-1])
								if GemoUfjIL3CD4wK: vOGbzjQxCEY9BdLe0sF4q[-1] = vOGbzjQxCEY9BdLe0sF4q[-1].lstrip(S3X6GcaiExOPtb)+GemoUfjIL3CD4wK[0]
						vOGbzjQxCEY9BdLe0sF4q.append(oDBFOQHy8j1wpNI5ha2Er3g4U)
					LLleQvNd9SbIJ = O3GYEBD97d
				if vOGbzjQxCEY9BdLe0sF4q: vOGbzjQxCEY9BdLe0sF4q[-1] = InTA8P54xi0Ocg.get_display(vOGbzjQxCEY9BdLe0sF4q[-1])
				xbfwC5hkXLvsJa8PReOS9AyU1z = S3X6GcaiExOPtb.join(vOGbzjQxCEY9BdLe0sF4q)
			if n7neb9KTv10FcU: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	return xbfwC5hkXLvsJa8PReOS9AyU1z
def ZZOsRMvLwU(lLORW1akG2FBgoyfd0C39pnVcj,QLsEB5naGr63IX7tlAodPUu8F,yxSszj1J0cN2qh):
	iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,MFqDA0tvZcB7mJXR2H,aaG1kKWeDHCE2SAqIQt6J7Fjb,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = lLORW1akG2FBgoyfd0C39pnVcj
	EYMmnJAyxV = int(EYMmnJAyxV)
	WPwXK7yZuADcoetr = ScntgdOZCY74vNpXeW5jh8i.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if WPwXK7yZuADcoetr:
		WPwXK7yZuADcoetr,mvZ4fFWIpGKkRcoN3CzrebJHAUV,H06Jxy1fWpulVraFzUOo9eSkmc = WPwXK7yZuADcoetr[0]
		xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace(WPwXK7yZuADcoetr,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	EHMRG8hab7 = xbfwC5hkXLvsJa8PReOS9AyU1z
	eH9C6OmRIMh3Sc4yN = ScntgdOZCY74vNpXeW5jh8i.findall('^_(\w\w\w)_(.*?)$',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eH9C6OmRIMh3Sc4yN:
		eH9C6OmRIMh3Sc4yN,xbfwC5hkXLvsJa8PReOS9AyU1z = eH9C6OmRIMh3Sc4yN[0]
		VXcgGtwFL73SPYxR698Md1 = '_MOD_' in xbfwC5hkXLvsJa8PReOS9AyU1z
		gYJAT1vW0Uqm76G = iiyAEbQ5f80=='folder'
		if VXcgGtwFL73SPYxR698Md1 and gYJAT1vW0Uqm76G: ggA7LcUQRr = ';'
		elif VXcgGtwFL73SPYxR698Md1 and not gYJAT1vW0Uqm76G: ggA7LcUQRr = aiRHWcOtjhszqmMC7DePT1y
		elif not VXcgGtwFL73SPYxR698Md1 and gYJAT1vW0Uqm76G: ggA7LcUQRr = ','
		elif not VXcgGtwFL73SPYxR698Md1 and not gYJAT1vW0Uqm76G: ggA7LcUQRr = S3X6GcaiExOPtb
		xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('_MOD_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		eH9C6OmRIMh3Sc4yN = ggA7LcUQRr+eMypvI8XqHjYU02anWD9gsSrkt+eH9C6OmRIMh3Sc4yN+' '+c7gxFyUCGm
	else: eH9C6OmRIMh3Sc4yN = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if WPwXK7yZuADcoetr:
		if n7neb9KTv10FcU:
			WPwXK7yZuADcoetr = l5JG7XwbOfo8DznU+mvZ4fFWIpGKkRcoN3CzrebJHAUV+S3X6GcaiExOPtb+H06Jxy1fWpulVraFzUOo9eSkmc+c7gxFyUCGm
			if eH9C6OmRIMh3Sc4yN: xbfwC5hkXLvsJa8PReOS9AyU1z = WPwXK7yZuADcoetr+S3X6GcaiExOPtb+dVMZJNUoPLOSp47lkeh6T0W31Gj+eH9C6OmRIMh3Sc4yN+xbfwC5hkXLvsJa8PReOS9AyU1z
			else: xbfwC5hkXLvsJa8PReOS9AyU1z = WPwXK7yZuADcoetr+dVMZJNUoPLOSp47lkeh6T0W31Gj+xbfwC5hkXLvsJa8PReOS9AyU1z+S3X6GcaiExOPtb
		elif IZhXMprxvAHqBEFkg0:
			if eH9C6OmRIMh3Sc4yN:
				WPwXK7yZuADcoetr = l5JG7XwbOfo8DznU+mvZ4fFWIpGKkRcoN3CzrebJHAUV+S3X6GcaiExOPtb+H06Jxy1fWpulVraFzUOo9eSkmc+c7gxFyUCGm
				xbfwC5hkXLvsJa8PReOS9AyU1z = WPwXK7yZuADcoetr+S3X6GcaiExOPtb+eH9C6OmRIMh3Sc4yN+xbfwC5hkXLvsJa8PReOS9AyU1z
			else:
				WPwXK7yZuADcoetr = l5JG7XwbOfo8DznU+H06Jxy1fWpulVraFzUOo9eSkmc+S3X6GcaiExOPtb+mvZ4fFWIpGKkRcoN3CzrebJHAUV+c7gxFyUCGm
				xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z+S3X6GcaiExOPtb+dVMZJNUoPLOSp47lkeh6T0W31Gj+WPwXK7yZuADcoetr
	elif eH9C6OmRIMh3Sc4yN:
		xbfwC5hkXLvsJa8PReOS9AyU1z = GwFQmo3Yb8sdz(xbfwC5hkXLvsJa8PReOS9AyU1z,eH9C6OmRIMh3Sc4yN)
		xbfwC5hkXLvsJa8PReOS9AyU1z = eH9C6OmRIMh3Sc4yN+xbfwC5hkXLvsJa8PReOS9AyU1z
	lLORW1akG2FBgoyfd0C39pnVcj = iiyAEbQ5f80,EHMRG8hab7,wNyZhHdvUeC3M,str(EYMmnJAyxV),gwLmtlCDM6uq0EnWoNUx,MFqDA0tvZcB7mJXR2H,aaG1kKWeDHCE2SAqIQt6J7Fjb,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL
	sHwRPXu5aVUDxv = {'type':nbOFVEDkpT4BIR7Qq82yPmHeJU,'mode':nbOFVEDkpT4BIR7Qq82yPmHeJU,'url':nbOFVEDkpT4BIR7Qq82yPmHeJU,'text':nbOFVEDkpT4BIR7Qq82yPmHeJU,'page':nbOFVEDkpT4BIR7Qq82yPmHeJU,'name':nbOFVEDkpT4BIR7Qq82yPmHeJU,'image':nbOFVEDkpT4BIR7Qq82yPmHeJU,'context':nbOFVEDkpT4BIR7Qq82yPmHeJU,'infodict':nbOFVEDkpT4BIR7Qq82yPmHeJU}
	sHwRPXu5aVUDxv['name'] = lcxFAteLQ1Pwu45Er2(EHMRG8hab7)
	sHwRPXu5aVUDxv['type'] = iiyAEbQ5f80.strip(S3X6GcaiExOPtb)
	sHwRPXu5aVUDxv['mode'] = str(EYMmnJAyxV).strip(S3X6GcaiExOPtb)
	if iiyAEbQ5f80=='folder' and MFqDA0tvZcB7mJXR2H: sHwRPXu5aVUDxv['page'] = lcxFAteLQ1Pwu45Er2(MFqDA0tvZcB7mJXR2H.strip(S3X6GcaiExOPtb))
	if R0gbu46Cw9ZKhB5jsT8HAcGv: sHwRPXu5aVUDxv['context'] = R0gbu46Cw9ZKhB5jsT8HAcGv.strip(S3X6GcaiExOPtb)
	if aaG1kKWeDHCE2SAqIQt6J7Fjb: sHwRPXu5aVUDxv['text'] = lcxFAteLQ1Pwu45Er2(aaG1kKWeDHCE2SAqIQt6J7Fjb.strip(S3X6GcaiExOPtb))
	if gwLmtlCDM6uq0EnWoNUx: sHwRPXu5aVUDxv['image'] = lcxFAteLQ1Pwu45Er2(gwLmtlCDM6uq0EnWoNUx.strip(S3X6GcaiExOPtb))
	if RmjbIZdCFEMzkDNHaAqe7hoSBO5lL:
		RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = str(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL)
		sHwRPXu5aVUDxv['infodict'] = lcxFAteLQ1Pwu45Er2(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL.strip(S3X6GcaiExOPtb))
		RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = eval(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL)
	else: RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = {}
	if wNyZhHdvUeC3M: sHwRPXu5aVUDxv['url'] = lcxFAteLQ1Pwu45Er2(wNyZhHdvUeC3M.strip(S3X6GcaiExOPtb))
	t8g3ZChrwIvKnsGdYJQik = {'name':nbOFVEDkpT4BIR7Qq82yPmHeJU,'context_menu':nbOFVEDkpT4BIR7Qq82yPmHeJU,'plot':nbOFVEDkpT4BIR7Qq82yPmHeJU,'stars':nbOFVEDkpT4BIR7Qq82yPmHeJU,'image':nbOFVEDkpT4BIR7Qq82yPmHeJU,'type':nbOFVEDkpT4BIR7Qq82yPmHeJU,'isFolder':nbOFVEDkpT4BIR7Qq82yPmHeJU,'newpath':nbOFVEDkpT4BIR7Qq82yPmHeJU,'duration':nbOFVEDkpT4BIR7Qq82yPmHeJU}
	iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK = []
	ZndpPsrt1cxK57gyI2uCQXDJa0 = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'/?type='+sHwRPXu5aVUDxv['type']+'&mode='+sHwRPXu5aVUDxv['mode']
	if sHwRPXu5aVUDxv['page']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&page='+sHwRPXu5aVUDxv['page']
	if sHwRPXu5aVUDxv['name']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&name='+sHwRPXu5aVUDxv['name']
	if sHwRPXu5aVUDxv['text']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&text='+sHwRPXu5aVUDxv['text']
	if sHwRPXu5aVUDxv['infodict']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&infodict='+sHwRPXu5aVUDxv['infodict']
	if sHwRPXu5aVUDxv['image']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&image='+sHwRPXu5aVUDxv['image']
	if sHwRPXu5aVUDxv['url']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&url='+sHwRPXu5aVUDxv['url']
	if EYMmnJAyxV!=265: t8g3ZChrwIvKnsGdYJQik['favorites'] = True
	else: t8g3ZChrwIvKnsGdYJQik['favorites'] = False
	if sHwRPXu5aVUDxv['context']: ZndpPsrt1cxK57gyI2uCQXDJa0 += '&context='+sHwRPXu5aVUDxv['context']
	if EYMmnJAyxV in [235,238] and iiyAEbQ5f80=='live' and 'EPG' in R0gbu46Cw9ZKhB5jsT8HAcGv:
		WpRdIjGnJs4ml = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'?mode=238&text=SHORT_EPG&url='+wNyZhHdvUeC3M
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'البرامج القادمة'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if EYMmnJAyxV==265:
		lloWqNHwL5SjQcCI8ePFyB = QLsEB5naGr63IX7tlAodPUu8F(aaG1kKWeDHCE2SAqIQt6J7Fjb,True)
		if lloWqNHwL5SjQcCI8ePFyB>0:
			WpRdIjGnJs4ml = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'?mode=266&text='+aaG1kKWeDHCE2SAqIQt6J7Fjb
			At6UhC1Y9uW = l5JG7XwbOfo8DznU+'مسح قائمة آخر 50 '+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(aaG1kKWeDHCE2SAqIQt6J7Fjb)+c7gxFyUCGm
			nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
			iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if iiyAEbQ5f80=='video' and EYMmnJAyxV!=331:
		WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=6_DOWNLOAD'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'تحميل ملف الفيديو'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if EYMmnJAyxV==331:
		WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=6_DELETE'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'حذف ملف الفيديو'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if iiyAEbQ5f80=='folder' and EYMmnJAyxV==540:
		uOs1m74ITzBCnvFWJHlY = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_SPLITTED_ALL')
		if uOs1m74ITzBCnvFWJHlY:
			WpRdIjGnJs4ml = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'?context=7'
			At6UhC1Y9uW = l5JG7XwbOfo8DznU+'مسح كلمات بحث المواقع'+c7gxFyUCGm
			nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
			iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if iiyAEbQ5f80=='folder' and EYMmnJAyxV==1010:
		uOs1m74ITzBCnvFWJHlY = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if uOs1m74ITzBCnvFWJHlY:
			WpRdIjGnJs4ml = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'?context=10'
			At6UhC1Y9uW = l5JG7XwbOfo8DznU+'مسح كلمات بحث جوجل'+c7gxFyUCGm
			nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
			iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	quWSBcOHgA = [9990,9999,2,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010]
	if EYMmnJAyxV not in quWSBcOHgA:
		WpRdIjGnJs4ml = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'?context=8&mode=260'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'القائمة الرئيسية'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	mnrzxc3WM4VhgSXLs = [0,150,160,170,190,260,280,330,340,410,500,520,530,540,760,1010,9990]
	DYXn8cIqRtaGuvkHQgwWj16dsNV = EYMmnJAyxV-EYMmnJAyxV%10
	if EYMmnJAyxV%10:
		if DYXn8cIqRtaGuvkHQgwWj16dsNV==280: DYXn8cIqRtaGuvkHQgwWj16dsNV = 230
		if DYXn8cIqRtaGuvkHQgwWj16dsNV==410: DYXn8cIqRtaGuvkHQgwWj16dsNV = 400
		if DYXn8cIqRtaGuvkHQgwWj16dsNV==520: DYXn8cIqRtaGuvkHQgwWj16dsNV = 510
		if DYXn8cIqRtaGuvkHQgwWj16dsNV not in mnrzxc3WM4VhgSXLs:
			WpRdIjGnJs4ml = 'plugin://'+ldJmEsIZY9A4pXStekwNoTV+'?context=8&mode='+str(DYXn8cIqRtaGuvkHQgwWj16dsNV)
			At6UhC1Y9uW = l5JG7XwbOfo8DznU+'قائمة الموقع'+c7gxFyUCGm
			nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
			iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=9'
	At6UhC1Y9uW = l5JG7XwbOfo8DznU+'تحديث القائمة'+c7gxFyUCGm
	nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
	iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if EYMmnJAyxV%10 and DYXn8cIqRtaGuvkHQgwWj16dsNV not in mnrzxc3WM4VhgSXLs:
		WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=14'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'ترتيب عكسي'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
		WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=15'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'ترتيب عشوائي'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
		WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=16'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'ترتيب تصاعدي'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
		WpRdIjGnJs4ml = ZndpPsrt1cxK57gyI2uCQXDJa0+'&context=17'
		At6UhC1Y9uW = l5JG7XwbOfo8DznU+'ترتيب تنازلي'+c7gxFyUCGm
		nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9 = (At6UhC1Y9uW,'RunPlugin('+WpRdIjGnJs4ml+')')
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK.append(nEOx0hmPzVdKcyU5ZRCJqo3Ipfivg9)
	if iiyAEbQ5f80 in ['link','video','live']: Vn2jsPLCDrJTZ3pl8EW = False
	elif iiyAEbQ5f80=='folder': Vn2jsPLCDrJTZ3pl8EW = True
	t8g3ZChrwIvKnsGdYJQik['name'] = xbfwC5hkXLvsJa8PReOS9AyU1z
	t8g3ZChrwIvKnsGdYJQik['context_menu'] = iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK
	if 'plot' in list(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL.keys()): t8g3ZChrwIvKnsGdYJQik['plot'] = RmjbIZdCFEMzkDNHaAqe7hoSBO5lL['plot']
	if 'stars' in list(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL.keys()): t8g3ZChrwIvKnsGdYJQik['stars'] = RmjbIZdCFEMzkDNHaAqe7hoSBO5lL['stars']
	if gwLmtlCDM6uq0EnWoNUx: t8g3ZChrwIvKnsGdYJQik['image'] = gwLmtlCDM6uq0EnWoNUx
	if iiyAEbQ5f80=='video' and MFqDA0tvZcB7mJXR2H:
		vQgYUMCXexcZrWbHjBlL1FkqP = ScntgdOZCY74vNpXeW5jh8i.findall('[\d:]+',MFqDA0tvZcB7mJXR2H,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if vQgYUMCXexcZrWbHjBlL1FkqP:
			vQgYUMCXexcZrWbHjBlL1FkqP = '0:0:0:0:0:'+vQgYUMCXexcZrWbHjBlL1FkqP[0]
			RQg7AUDOp6MJtWwdba3VFYZ1XHokE,ttmCkFKBlZahvT,wRHCzGn3oyW,WzKmtTnl5NAi4MdqPYsef,nD4yaRspG9i7CNX36ZxPYt = vQgYUMCXexcZrWbHjBlL1FkqP.rsplit(':',4)
			dFySIEt94NM7cJ = int(ttmCkFKBlZahvT)*24*wfVkBtgLUIM3N6Ozy2i5pxlT+int(wRHCzGn3oyW)*wfVkBtgLUIM3N6Ozy2i5pxlT+int(WzKmtTnl5NAi4MdqPYsef)*60+int(nD4yaRspG9i7CNX36ZxPYt)
			t8g3ZChrwIvKnsGdYJQik['duration'] = dFySIEt94NM7cJ
	t8g3ZChrwIvKnsGdYJQik['type'] = iiyAEbQ5f80
	t8g3ZChrwIvKnsGdYJQik['isFolder'] = Vn2jsPLCDrJTZ3pl8EW
	t8g3ZChrwIvKnsGdYJQik['newpath'] = ZndpPsrt1cxK57gyI2uCQXDJa0
	t8g3ZChrwIvKnsGdYJQik['menuItem'] = lLORW1akG2FBgoyfd0C39pnVcj
	t8g3ZChrwIvKnsGdYJQik['mode'] = EYMmnJAyxV
	return t8g3ZChrwIvKnsGdYJQik
def ppaqdOoPjl9AsWD(QLsEB5naGr63IX7tlAodPUu8F):
	MQCbGUiJFAzjPy9B4mg1xn = []
	from Z2ZSU6yEYJ import X48cC9SbOl6v20AU7HgEF3i,SSFTAqtnY3Wf
	yxSszj1J0cN2qh = X48cC9SbOl6v20AU7HgEF3i()
	FGnvJ1ZOyESbpuerf54w8U = llnG7jiQBYKhAeovbT.getSetting('av.status.refresh')
	if   FGnvJ1ZOyESbpuerf54w8U=='MENU_REVERSED': LvJuOzMqk6WlP971eoGpUQ8[:] = reversed(LvJuOzMqk6WlP971eoGpUQ8)
	elif FGnvJ1ZOyESbpuerf54w8U=='MENU_RANDOMIZED': eH7yw1hTGUROK2B4dcP0iEr.shuffle(LvJuOzMqk6WlP971eoGpUQ8)
	elif FGnvJ1ZOyESbpuerf54w8U=='MENU_ASCENDED': LvJuOzMqk6WlP971eoGpUQ8[:] = sorted(LvJuOzMqk6WlP971eoGpUQ8,reverse=SmbNGskjMx,key=lambda key:key[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	elif FGnvJ1ZOyESbpuerf54w8U=='MENU_DESCENDED': LvJuOzMqk6WlP971eoGpUQ8[:] = sorted(LvJuOzMqk6WlP971eoGpUQ8,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key:key[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	if FGnvJ1ZOyESbpuerf54w8U.startswith('MENU_') and FGnvJ1ZOyESbpuerf54w8U.endswith('ED'): llnG7jiQBYKhAeovbT.setSetting('av.status.refresh',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	for lLORW1akG2FBgoyfd0C39pnVcj in LvJuOzMqk6WlP971eoGpUQ8:
		t8g3ZChrwIvKnsGdYJQik = ZZOsRMvLwU(lLORW1akG2FBgoyfd0C39pnVcj,QLsEB5naGr63IX7tlAodPUu8F,yxSszj1J0cN2qh)
		if t8g3ZChrwIvKnsGdYJQik['favorites']:
			lGDYysUKQEfc6gINCaxSn140 = SSFTAqtnY3Wf(yxSszj1J0cN2qh,t8g3ZChrwIvKnsGdYJQik['menuItem'],t8g3ZChrwIvKnsGdYJQik['newpath'])
			t8g3ZChrwIvKnsGdYJQik['context_menu'] = lGDYysUKQEfc6gINCaxSn140+t8g3ZChrwIvKnsGdYJQik['context_menu']
		MQCbGUiJFAzjPy9B4mg1xn.append(t8g3ZChrwIvKnsGdYJQik)
	return MQCbGUiJFAzjPy9B4mg1xn
def iuJ2mVxAc8wXrvUTR5I6(rrfWsKPq4nzR0V7jFoNBHQe):
	ggA7LcUQRr,JMaWzmDgyTt81VnR4Zj, = [],nbOFVEDkpT4BIR7Qq82yPmHeJU
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		if not k38Vi6PpwFNB7Aus1KErSLJaOdDvM: ggA7LcUQRr.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else: break
	rrfWsKPq4nzR0V7jFoNBHQe = rrfWsKPq4nzR0V7jFoNBHQe[len(ggA7LcUQRr):]
	J1rvN7I8eLXuS54mZ6lnUjg = '\n\n\n\n'.join(rrfWsKPq4nzR0V7jFoNBHQe)
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('===== ===== =====','000001')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(eMypvI8XqHjYU02anWD9gsSrkt,'000002')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(l5JG7XwbOfo8DznU,'000003')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(c7gxFyUCGm,'000004')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[RIGHT]','000005')
	UUfw8Ld24pDl5xbHRhe = 100000
	Pf2J7Ysjaibr = {}
	PulQ9IVywCsfgaMJmtS1n3ejoB = ScntgdOZCY74vNpXeW5jh8i.findall('http.*?[\r\n ]',J1rvN7I8eLXuS54mZ6lnUjg,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for flN3nOkjXJwiRTmq1YIV6dzA in PulQ9IVywCsfgaMJmtS1n3ejoB:
		UUfw8Ld24pDl5xbHRhe += 1
		J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(flN3nOkjXJwiRTmq1YIV6dzA,str(UUfw8Ld24pDl5xbHRhe))
		Pf2J7Ysjaibr[str(UUfw8Ld24pDl5xbHRhe)] = flN3nOkjXJwiRTmq1YIV6dzA
	for uvOaDl7f60HCwBiVKzes24 in range(0,len(J1rvN7I8eLXuS54mZ6lnUjg),4800):
		CCaf2Lz6jK7Nn = J1rvN7I8eLXuS54mZ6lnUjg[uvOaDl7f60HCwBiVKzes24:uvOaDl7f60HCwBiVKzes24+4800]
		aUpbQVqwl0 = llnG7jiQBYKhAeovbT.getSetting('av.language.code')
		wNyZhHdvUeC3M = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+aUpbQVqwl0
		YeRr5GFOCqn9ufVy = {'Content-Type':'text/plain'}
		gJv8eI2iVF90uCLSoyNGDHfmc = CCaf2Lz6jK7Nn.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		BTxl2eLIqSzUk = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',wNyZhHdvUeC3M,gJv8eI2iVF90uCLSoyNGDHfmc,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if BTxl2eLIqSzUk.succeeded:
			oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
			pg1XFzwKOSoT39WAbD5fJYsRNhv2 = dr1zfnatJxRHSF48jh0eODm5bGu('str',oHQzKutsWeALwSEXc8a)
			if pg1XFzwKOSoT39WAbD5fJYsRNhv2:
				pg1XFzwKOSoT39WAbD5fJYsRNhv2 = pg1XFzwKOSoT39WAbD5fJYsRNhv2['translation']
				pg1XFzwKOSoT39WAbD5fJYsRNhv2 = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(pg1XFzwKOSoT39WAbD5fJYsRNhv2)
				for f3phHmTd9wsvxGjD7SbJkIiRFB in range(len(pg1XFzwKOSoT39WAbD5fJYsRNhv2)):
					JMaWzmDgyTt81VnR4Zj += pg1XFzwKOSoT39WAbD5fJYsRNhv2[f3phHmTd9wsvxGjD7SbJkIiRFB][0]
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000001','===== ===== =====')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000002',eMypvI8XqHjYU02anWD9gsSrkt)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000003',l5JG7XwbOfo8DznU)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000004',c7gxFyUCGm)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000005','[RIGHT]')
	for UUfw8Ld24pDl5xbHRhe in list(Pf2J7Ysjaibr.keys()):
		flN3nOkjXJwiRTmq1YIV6dzA = Pf2J7Ysjaibr[UUfw8Ld24pDl5xbHRhe]
		JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace(UUfw8Ld24pDl5xbHRhe,flN3nOkjXJwiRTmq1YIV6dzA)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.split('\n\n\n\n')
	return ggA7LcUQRr+JMaWzmDgyTt81VnR4Zj
def TNkf0qbtoEv(rrfWsKPq4nzR0V7jFoNBHQe):
	ggA7LcUQRr,JMaWzmDgyTt81VnR4Zj, = [],nbOFVEDkpT4BIR7Qq82yPmHeJU
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		if not k38Vi6PpwFNB7Aus1KErSLJaOdDvM: ggA7LcUQRr.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else: break
	rrfWsKPq4nzR0V7jFoNBHQe = rrfWsKPq4nzR0V7jFoNBHQe[len(ggA7LcUQRr):]
	J1rvN7I8eLXuS54mZ6lnUjg = '\\n\\n\\n\\n'.join(rrfWsKPq4nzR0V7jFoNBHQe)
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('كلا','no')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('استمرار','continue')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('===== ===== =====','000001')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(eMypvI8XqHjYU02anWD9gsSrkt,'000002')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(l5JG7XwbOfo8DznU,'000003')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(c7gxFyUCGm,'000004')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[RIGHT]','000005')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[CENTER]','000006')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[RTL]','000007')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace("'","\\\\\\'")
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('"','\\\\\\"')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(wwOnIucWJj,'\\n')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(FKuOXLZA8PYBc7,'\\\\r')
	for uvOaDl7f60HCwBiVKzes24 in range(0,len(J1rvN7I8eLXuS54mZ6lnUjg),4800):
		CCaf2Lz6jK7Nn = J1rvN7I8eLXuS54mZ6lnUjg[uvOaDl7f60HCwBiVKzes24:uvOaDl7f60HCwBiVKzes24+4800]
		wNyZhHdvUeC3M = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		YeRr5GFOCqn9ufVy = {'Content-Type':'application/x-www-form-urlencoded'}
		aUpbQVqwl0 = llnG7jiQBYKhAeovbT.getSetting('av.language.code')
		gJv8eI2iVF90uCLSoyNGDHfmc = 'f.req='+lcxFAteLQ1Pwu45Er2('[[["MkEWBc","[[\\"'+CCaf2Lz6jK7Nn+'\\",\\"ar\\",\\"'+aUpbQVqwl0+'\\",1],[]]",null,"generic"]]]',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		gJv8eI2iVF90uCLSoyNGDHfmc = gJv8eI2iVF90uCLSoyNGDHfmc.replace('%5Cn','%5C%5Cn')
		BTxl2eLIqSzUk = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',wNyZhHdvUeC3M,gJv8eI2iVF90uCLSoyNGDHfmc,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if BTxl2eLIqSzUk.succeeded:
			oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
			oHQzKutsWeALwSEXc8a = oHQzKutsWeALwSEXc8a.split(wwOnIucWJj)[-1]
			pg1XFzwKOSoT39WAbD5fJYsRNhv2 = dr1zfnatJxRHSF48jh0eODm5bGu('str',oHQzKutsWeALwSEXc8a)[0][2]
			if pg1XFzwKOSoT39WAbD5fJYsRNhv2:
				pg1XFzwKOSoT39WAbD5fJYsRNhv2 = dr1zfnatJxRHSF48jh0eODm5bGu('str',pg1XFzwKOSoT39WAbD5fJYsRNhv2)[1][0][0][5]
				pg1XFzwKOSoT39WAbD5fJYsRNhv2 = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(pg1XFzwKOSoT39WAbD5fJYsRNhv2)
				for f3phHmTd9wsvxGjD7SbJkIiRFB in range(len(pg1XFzwKOSoT39WAbD5fJYsRNhv2)):
					JMaWzmDgyTt81VnR4Zj += pg1XFzwKOSoT39WAbD5fJYsRNhv2[f3phHmTd9wsvxGjD7SbJkIiRFB][0]
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('00000','0000').replace('0000','000')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0001','===== ===== =====')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0002',eMypvI8XqHjYU02anWD9gsSrkt)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0003',l5JG7XwbOfo8DznU)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0004',c7gxFyUCGm)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0005','[RIGHT]')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0006','[CENTER]')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0007','[RTL]')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.split('\n\n\n\n')
	return ggA7LcUQRr+JMaWzmDgyTt81VnR4Zj
def LEJPpXjqQAhYO(rrfWsKPq4nzR0V7jFoNBHQe):
	ggA7LcUQRr,KKO6olAJVzXeF8gSRj1vcBixpELIfP = [],[]
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		if not k38Vi6PpwFNB7Aus1KErSLJaOdDvM: ggA7LcUQRr.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else: break
	rrfWsKPq4nzR0V7jFoNBHQe = rrfWsKPq4nzR0V7jFoNBHQe[len(ggA7LcUQRr):]
	J1rvN7I8eLXuS54mZ6lnUjg = '\n\n\n\n'.join(rrfWsKPq4nzR0V7jFoNBHQe)
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('كلا','no')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('استمرار','continue')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('أدناه','below')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(eMypvI8XqHjYU02anWD9gsSrkt,'00001')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(l5JG7XwbOfo8DznU,'00002')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(c7gxFyUCGm,'00003')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('=====','00004')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(',','00005')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[RTL]','00009')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[CENTER]','0000A')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(FKuOXLZA8PYBc7,'0000B')
	rrfWsKPq4nzR0V7jFoNBHQe = J1rvN7I8eLXuS54mZ6lnUjg.split(wwOnIucWJj)
	J1rvN7I8eLXuS54mZ6lnUjg,JMaWzmDgyTt81VnR4Zj = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		if len(J1rvN7I8eLXuS54mZ6lnUjg+k38Vi6PpwFNB7Aus1KErSLJaOdDvM)<1800: J1rvN7I8eLXuS54mZ6lnUjg += wwOnIucWJj+k38Vi6PpwFNB7Aus1KErSLJaOdDvM
		else:
			KKO6olAJVzXeF8gSRj1vcBixpELIfP.append(J1rvN7I8eLXuS54mZ6lnUjg)
			J1rvN7I8eLXuS54mZ6lnUjg = k38Vi6PpwFNB7Aus1KErSLJaOdDvM
	KKO6olAJVzXeF8gSRj1vcBixpELIfP.append(J1rvN7I8eLXuS54mZ6lnUjg)
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in KKO6olAJVzXeF8gSRj1vcBixpELIfP:
		YeRr5GFOCqn9ufVy = {'Content-Type':'application/json','User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
		wNyZhHdvUeC3M = 'https://api.reverso.net/translate/v1/translation'
		aUpbQVqwl0 = llnG7jiQBYKhAeovbT.getSetting('av.language.code')
		gJv8eI2iVF90uCLSoyNGDHfmc = {"format":"text","from":"ara","to":aUpbQVqwl0,"input":k38Vi6PpwFNB7Aus1KErSLJaOdDvM,"options":{"sentenceSplitter":True,"origin":"translation.web","contextResults":False,"languageDetection":False}}
		gJv8eI2iVF90uCLSoyNGDHfmc = eH72MR1wtfuI80myOo4ajgG.dumps(gJv8eI2iVF90uCLSoyNGDHfmc)
		BTxl2eLIqSzUk = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',wNyZhHdvUeC3M,gJv8eI2iVF90uCLSoyNGDHfmc,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIBRARY-REVERSO_TRANSLATE-1st')
		if BTxl2eLIqSzUk.succeeded:
			oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
			oHQzKutsWeALwSEXc8a = dr1zfnatJxRHSF48jh0eODm5bGu('dict',oHQzKutsWeALwSEXc8a)
			JMaWzmDgyTt81VnR4Zj += wwOnIucWJj+nbOFVEDkpT4BIR7Qq82yPmHeJU.join(oHQzKutsWeALwSEXc8a['translation'])
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj[2:]
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000000','00000').replace('00000','0000').replace('0000','000')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0001',eMypvI8XqHjYU02anWD9gsSrkt)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0002',l5JG7XwbOfo8DznU)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0003',c7gxFyUCGm)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0004','=====')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0005',',')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('0009','[RTL]')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000A','[CENTER]')
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.replace('000B',FKuOXLZA8PYBc7)
	JMaWzmDgyTt81VnR4Zj = JMaWzmDgyTt81VnR4Zj.split('\n\n\n\n')
	return ggA7LcUQRr+JMaWzmDgyTt81VnR4Zj
def wRVgSQralMTW4pxzu8JPLB(rrfWsKPq4nzR0V7jFoNBHQe):
	KK6zJZqk7j0CuNbBa = llnG7jiQBYKhAeovbT.getSetting('av.language.translate')
	if not KK6zJZqk7j0CuNbBa or not rrfWsKPq4nzR0V7jFoNBHQe: return rrfWsKPq4nzR0V7jFoNBHQe
	H0HP8jx7JYMbp5BSLGKi9f = llnG7jiQBYKhAeovbT.getSetting('av.language.provider')
	aUpbQVqwl0 = llnG7jiQBYKhAeovbT.getSetting('av.language.code')
	WrvJlbqEZ3gXpIRjMTYw1y6k02 = aUpbQVqwl0+'__'+str(rrfWsKPq4nzR0V7jFoNBHQe)
	llnG7jiQBYKhAeovbT.setSetting('av.language.translate',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	JMaWzmDgyTt81VnR4Zj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','TRANSLATE_'+H0HP8jx7JYMbp5BSLGKi9f,WrvJlbqEZ3gXpIRjMTYw1y6k02)
	if not JMaWzmDgyTt81VnR4Zj:
		if H0HP8jx7JYMbp5BSLGKi9f=='GOOGLE': JMaWzmDgyTt81VnR4Zj = TNkf0qbtoEv(rrfWsKPq4nzR0V7jFoNBHQe)
		elif H0HP8jx7JYMbp5BSLGKi9f=='REVERSO': JMaWzmDgyTt81VnR4Zj = LEJPpXjqQAhYO(rrfWsKPq4nzR0V7jFoNBHQe)
		elif H0HP8jx7JYMbp5BSLGKi9f=='GLOSBE': JMaWzmDgyTt81VnR4Zj = iuJ2mVxAc8wXrvUTR5I6(rrfWsKPq4nzR0V7jFoNBHQe)
		if len(rrfWsKPq4nzR0V7jFoNBHQe)==len(JMaWzmDgyTt81VnR4Zj):
			z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'TRANSLATE_'+H0HP8jx7JYMbp5BSLGKi9f,WrvJlbqEZ3gXpIRjMTYw1y6k02,JMaWzmDgyTt81VnR4Zj,rXKp4uqLMW3v)
		else:
			JMaWzmDgyTt81VnR4Zj = rrfWsKPq4nzR0V7jFoNBHQe
			SSVCGE0bOfW1w9u52yvBxocNeP('الترجمة فشلت','Translation Failed')
	llnG7jiQBYKhAeovbT.setSetting('av.language.translate','1')
	return JMaWzmDgyTt81VnR4Zj
def uS4rEdcNAC3wxVR0XJ7ypgaQKnMl52(lLORW1akG2FBgoyfd0C39pnVcj,MQCbGUiJFAzjPy9B4mg1xn,aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,AAYh17xDBi0fNtOyZWvGaJQbEpo,rrdTk6GjcJ4):
	iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = lLORW1akG2FBgoyfd0C39pnVcj
	RRGdYKEubvV8 = []
	KK6zJZqk7j0CuNbBa = llnG7jiQBYKhAeovbT.getSetting('av.language.translate')
	if KK6zJZqk7j0CuNbBa:
		iiP0V39CkGFR51,RRHDjcUTVqxEGB,kkCeqWU1Xprac = [],[],[]
		if not RRGdYKEubvV8:
			for t8g3ZChrwIvKnsGdYJQik in MQCbGUiJFAzjPy9B4mg1xn:
				xbfwC5hkXLvsJa8PReOS9AyU1z = t8g3ZChrwIvKnsGdYJQik['name'].replace(dVMZJNUoPLOSp47lkeh6T0W31Gj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(AQJdiEVCZaDfh4,nbOFVEDkpT4BIR7Qq82yPmHeJU)
				WPwXK7yZuADcoetr = ScntgdOZCY74vNpXeW5jh8i.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if WPwXK7yZuADcoetr:
					ggA7LcUQRr,mvZ4fFWIpGKkRcoN3CzrebJHAUV,H06Jxy1fWpulVraFzUOo9eSkmc,gIqD4ESsoTy5AV73uY,xbfwC5hkXLvsJa8PReOS9AyU1z = WPwXK7yZuADcoetr[0]
					WPwXK7yZuADcoetr = ggA7LcUQRr+mvZ4fFWIpGKkRcoN3CzrebJHAUV+S3X6GcaiExOPtb+H06Jxy1fWpulVraFzUOo9eSkmc+gIqD4ESsoTy5AV73uY+S3X6GcaiExOPtb
				else:
					WPwXK7yZuADcoetr = ScntgdOZCY74vNpXeW5jh8i.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if WPwXK7yZuADcoetr:
						xbfwC5hkXLvsJa8PReOS9AyU1z,ggA7LcUQRr,H06Jxy1fWpulVraFzUOo9eSkmc,mvZ4fFWIpGKkRcoN3CzrebJHAUV,gIqD4ESsoTy5AV73uY = WPwXK7yZuADcoetr[0]
						WPwXK7yZuADcoetr = ggA7LcUQRr+mvZ4fFWIpGKkRcoN3CzrebJHAUV+S3X6GcaiExOPtb+H06Jxy1fWpulVraFzUOo9eSkmc+gIqD4ESsoTy5AV73uY+S3X6GcaiExOPtb
					else: WPwXK7yZuADcoetr = nbOFVEDkpT4BIR7Qq82yPmHeJU
				eH9C6OmRIMh3Sc4yN = ScntgdOZCY74vNpXeW5jh8i.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if eH9C6OmRIMh3Sc4yN: eH9C6OmRIMh3Sc4yN,xbfwC5hkXLvsJa8PReOS9AyU1z = eH9C6OmRIMh3Sc4yN[0]
				else: eH9C6OmRIMh3Sc4yN = nbOFVEDkpT4BIR7Qq82yPmHeJU
				iiP0V39CkGFR51.append(WPwXK7yZuADcoetr+eH9C6OmRIMh3Sc4yN)
				RRHDjcUTVqxEGB.append(xbfwC5hkXLvsJa8PReOS9AyU1z)
			kkCeqWU1Xprac = wRVgSQralMTW4pxzu8JPLB(RRHDjcUTVqxEGB)
			if kkCeqWU1Xprac:
				for uvOaDl7f60HCwBiVKzes24 in range(len(MQCbGUiJFAzjPy9B4mg1xn)):
					t8g3ZChrwIvKnsGdYJQik = MQCbGUiJFAzjPy9B4mg1xn[uvOaDl7f60HCwBiVKzes24]
					t8g3ZChrwIvKnsGdYJQik['name'] = iiP0V39CkGFR51[uvOaDl7f60HCwBiVKzes24]+kkCeqWU1Xprac[uvOaDl7f60HCwBiVKzes24]
					RRGdYKEubvV8.append(t8g3ZChrwIvKnsGdYJQik)
	if RRGdYKEubvV8: MQCbGUiJFAzjPy9B4mg1xn = RRGdYKEubvV8
	y91eVbDWLUijPKmEoczRMpn7twau3,liwMy1NgsAvnTSDrzF8Z95BW,KYHr4NjWFnvaoXA0tiQpg = [],0,0
	YbNBKckugsAqZTw3WDGEfv = llnG7jiQBYKhAeovbT.getSetting('av.status.menusimages')
	ocjYBTAxIE5r = YbNBKckugsAqZTw3WDGEfv!='STOP'
	if ocjYBTAxIE5r:
		rOBMXPL8nzTVfK93eAH = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(yi4Em23SQL9GNOBzXcshRV7wg6IUM0,EYMmnJAyxV)
		try: mDNU6QBw4hSa2zKpJv = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(rOBMXPL8nzTVfK93eAH)
		except:
			if not Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(rOBMXPL8nzTVfK93eAH):
				try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.makedirs(rOBMXPL8nzTVfK93eAH)
				except: pass
			mDNU6QBw4hSa2zKpJv = []
	gv2dUlIXOq0mYrRF7WCBQ = HEF7gSbdWKzL6Vpslr2PC3MZUuv('menu_item')
	for t8g3ZChrwIvKnsGdYJQik in MQCbGUiJFAzjPy9B4mg1xn:
		xbfwC5hkXLvsJa8PReOS9AyU1z = t8g3ZChrwIvKnsGdYJQik['name']
		iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK = t8g3ZChrwIvKnsGdYJQik['context_menu']
		ck7QVX0UFMW8 = t8g3ZChrwIvKnsGdYJQik['plot']
		gYZARp9LTtcu = t8g3ZChrwIvKnsGdYJQik['stars']
		gwLmtlCDM6uq0EnWoNUx = t8g3ZChrwIvKnsGdYJQik['image']
		iiyAEbQ5f80 = t8g3ZChrwIvKnsGdYJQik['type']
		vQgYUMCXexcZrWbHjBlL1FkqP = t8g3ZChrwIvKnsGdYJQik['duration']
		Vn2jsPLCDrJTZ3pl8EW = t8g3ZChrwIvKnsGdYJQik['isFolder']
		ZndpPsrt1cxK57gyI2uCQXDJa0 = t8g3ZChrwIvKnsGdYJQik['newpath']
		y7kf3ERUv2IF = LAkCFq8ezcf.ListItem(xbfwC5hkXLvsJa8PReOS9AyU1z)
		y7kf3ERUv2IF.addContextMenuItems(iizgwtoXDc1EyB6AOlTaU4P8LG7ZVK)
		HpyIB5AW3srLPM09Ot8 = False if ocjYBTAxIE5r else True
		if gwLmtlCDM6uq0EnWoNUx:
			y7kf3ERUv2IF.setArt({'icon':gwLmtlCDM6uq0EnWoNUx,'thumb':gwLmtlCDM6uq0EnWoNUx,'fanart':gwLmtlCDM6uq0EnWoNUx,'banner':gwLmtlCDM6uq0EnWoNUx,'clearart':gwLmtlCDM6uq0EnWoNUx,'poster':gwLmtlCDM6uq0EnWoNUx,'clearlogo':gwLmtlCDM6uq0EnWoNUx,'landscape':gwLmtlCDM6uq0EnWoNUx})
			HpyIB5AW3srLPM09Ot8 = False
		elif not HpyIB5AW3srLPM09Ot8:
			HpyIB5AW3srLPM09Ot8 = True
			xbfwC5hkXLvsJa8PReOS9AyU1z = Op47XGBbfiolxenLkTdyPrW6Z(SmbNGskjMx,xbfwC5hkXLvsJa8PReOS9AyU1z)
			xbfwC5hkXLvsJa8PReOS9AyU1z = JABPVj6TrWOU29Xvmo(xbfwC5hkXLvsJa8PReOS9AyU1z)
			wOMnVistqP8vkA = xbfwC5hkXLvsJa8PReOS9AyU1z+'.png'
			ZlybjzdOa6oYfsEU = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(rOBMXPL8nzTVfK93eAH,wOMnVistqP8vkA)
			if wOMnVistqP8vkA in mDNU6QBw4hSa2zKpJv:
				y7kf3ERUv2IF.setArt({'icon':ZlybjzdOa6oYfsEU,'thumb':ZlybjzdOa6oYfsEU,'fanart':ZlybjzdOa6oYfsEU,'banner':ZlybjzdOa6oYfsEU,'clearart':ZlybjzdOa6oYfsEU,'poster':ZlybjzdOa6oYfsEU,'clearlogo':ZlybjzdOa6oYfsEU,'landscape':ZlybjzdOa6oYfsEU})
				HpyIB5AW3srLPM09Ot8 = False
			elif liwMy1NgsAvnTSDrzF8Z95BW<40 and KYHr4NjWFnvaoXA0tiQpg<=3:
				try:
					lwfEQPTMdoSRYXFvZprI3Hk = FFmheU2OnzHiJjbqvyVCBDR(gv2dUlIXOq0mYrRF7WCBQ,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,xbfwC5hkXLvsJa8PReOS9AyU1z,'menu_item','center',False,ZlybjzdOa6oYfsEU)
					y7kf3ERUv2IF.setArt({'icon':ZlybjzdOa6oYfsEU,'thumb':ZlybjzdOa6oYfsEU,'fanart':ZlybjzdOa6oYfsEU,'banner':ZlybjzdOa6oYfsEU,'clearart':ZlybjzdOa6oYfsEU,'poster':ZlybjzdOa6oYfsEU,'clearlogo':ZlybjzdOa6oYfsEU,'landscape':ZlybjzdOa6oYfsEU})
					liwMy1NgsAvnTSDrzF8Z95BW += 1
					HpyIB5AW3srLPM09Ot8 = False
					mDNU6QBw4hSa2zKpJv.append(wOMnVistqP8vkA)
					if liwMy1NgsAvnTSDrzF8Z95BW==5: SSVCGE0bOfW1w9u52yvBxocNeP('إضافة الكتابة لصور القائمة','انتظار',lQMuw1PvVpAk=500)
				except: KYHr4NjWFnvaoXA0tiQpg += 1
		if HpyIB5AW3srLPM09Ot8:
			y7kf3ERUv2IF.setArt({'icon':lxNkBjPrQhcILG2iqvAVfeWtd,'thumb':lxNkBjPrQhcILG2iqvAVfeWtd,'fanart':lxNkBjPrQhcILG2iqvAVfeWtd,'banner':lxNkBjPrQhcILG2iqvAVfeWtd,'clearart':lxNkBjPrQhcILG2iqvAVfeWtd,'poster':lxNkBjPrQhcILG2iqvAVfeWtd,'clearlogo':lxNkBjPrQhcILG2iqvAVfeWtd,'landscape':lxNkBjPrQhcILG2iqvAVfeWtd})
		if o8MCS3IzmRXdVDB7xg2eiW5baZUn<20:
			if ck7QVX0UFMW8: y7kf3ERUv2IF.setInfo('video',{'Plot':ck7QVX0UFMW8,'PlotOutline':ck7QVX0UFMW8})
			if gYZARp9LTtcu: y7kf3ERUv2IF.setInfo('video',{'Rating':gYZARp9LTtcu})
			if not gwLmtlCDM6uq0EnWoNUx:
				y7kf3ERUv2IF.setInfo('video',{'Title':xbfwC5hkXLvsJa8PReOS9AyU1z})
			if iiyAEbQ5f80=='video':
				y7kf3ERUv2IF.setInfo('video',{'mediatype':'tvshow'})
				if vQgYUMCXexcZrWbHjBlL1FkqP: y7kf3ERUv2IF.setInfo('video',{'duration':vQgYUMCXexcZrWbHjBlL1FkqP})
				y7kf3ERUv2IF.setProperty('IsPlayable','true')
		else:
			iOEjTePZ3oVyh = y7kf3ERUv2IF.getVideoInfoTag()
			if gYZARp9LTtcu: iOEjTePZ3oVyh.setRating(float(gYZARp9LTtcu))
			if not gwLmtlCDM6uq0EnWoNUx:
				iOEjTePZ3oVyh.setTitle(xbfwC5hkXLvsJa8PReOS9AyU1z)
			if iiyAEbQ5f80=='video':
				iOEjTePZ3oVyh.setMediaType('tvshow')
				if vQgYUMCXexcZrWbHjBlL1FkqP: iOEjTePZ3oVyh.setDuration(vQgYUMCXexcZrWbHjBlL1FkqP)
				y7kf3ERUv2IF.setProperty('IsPlayable','true')
		y91eVbDWLUijPKmEoczRMpn7twau3.append((ZndpPsrt1cxK57gyI2uCQXDJa0,y7kf3ERUv2IF,Vn2jsPLCDrJTZ3pl8EW))
	WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.setContent(KXth1AHMv64CskLiWESrzuey,'tvshows')
	aBoSyf7zjlwWL8cpr0 = WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.addDirectoryItems(KXth1AHMv64CskLiWESrzuey,y91eVbDWLUijPKmEoczRMpn7twau3)
	WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.endOfDirectory(KXth1AHMv64CskLiWESrzuey,aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,AAYh17xDBi0fNtOyZWvGaJQbEpo,rrdTk6GjcJ4)
	return aBoSyf7zjlwWL8cpr0
def Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx=nbOFVEDkpT4BIR7Qq82yPmHeJU,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c=nbOFVEDkpT4BIR7Qq82yPmHeJU,J1rvN7I8eLXuS54mZ6lnUjg=nbOFVEDkpT4BIR7Qq82yPmHeJU,R0gbu46Cw9ZKhB5jsT8HAcGv=nbOFVEDkpT4BIR7Qq82yPmHeJU,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL={}):
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('\t',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('\t',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if '_SCRIPT_' in xbfwC5hkXLvsJa8PReOS9AyU1z: VGjzYJZykfEWxlQLeap,xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.split('_SCRIPT_',1)
	else: VGjzYJZykfEWxlQLeap,xbfwC5hkXLvsJa8PReOS9AyU1z = nbOFVEDkpT4BIR7Qq82yPmHeJU,xbfwC5hkXLvsJa8PReOS9AyU1z
	if VGjzYJZykfEWxlQLeap:
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = xbfwC5hkXLvsJa8PReOS9AyU1z
		if not zOnsD74YAjWJmrSgNdkLeqFMt5VQR: zOnsD74YAjWJmrSgNdkLeqFMt5VQR = '....'
		elif zOnsD74YAjWJmrSgNdkLeqFMt5VQR.count('_')>1: zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.split('_',2)[2]
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace(' ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('ـ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ة','ه').replace('ؤ','و')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('أ','ا').replace('إ','ا').replace('آ','ا')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('لأ','لا').replace('لإ','لا').replace('لآ','لا')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('َ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ً',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ُ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٌ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('ِ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٍ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ْ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ّ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('|',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('~',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('اون لاين',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('سيما لايت',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		hhdbn5xTog2cC6fJHuUswaGZXjr = ['العاب','خيال','البوم','الان','اطفال','حاليه','الغاز','صالح','الدين','مواليد','العالم','اعمال']
		if not any(ggMUCPqpYinc in zOnsD74YAjWJmrSgNdkLeqFMt5VQR for ggMUCPqpYinc in hhdbn5xTog2cC6fJHuUswaGZXjr): zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('ال',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('اخري','اخرى').replace('اجنبى','اجنبي').replace('عائليه','عائلي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('اجنبيه','اجنبي').replace('عربيه','عربي').replace('رومانسيه','رومانسي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('غربيه','غربي').replace('و مسلسلات','مسلسلات').replace('اغانى','اغاني')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('تاريخي','تاريخ').replace('خيال علمي','خيال').replace('موسيقيه','موسيقى')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('هندى','هندي').replace('هنديه','هندي').replace('وثائقيه','وثائقي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('تليفزيونيه','تلفزيون').replace('تلفزيونيه','تلفزيون').replace('و كرتون','وكرتون')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('الحاليه','حاليه').replace('موسیقي','موسيقى').replace('الانمي','انمي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('المسلسلات','مسلسلات').replace('البرامج','برامج').replace('كارتون','كرتون')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('حروب','حرب').replace('الاناشيد','اناشيد').replace('اسيويه','اسيوي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('عربى','عربي').replace('تركى','تركي').replace('تركيه','تركي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('رياضي','رياضة').replace('رياضه','رياضة').replace('اسيويه','اسيوي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('كوميدى','كوميدي').replace('كوميديه','كوميدي').replace('انيمي','انمي')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('انيميشن','انميشن').replace('انمى','انميشن').replace('انمي','انميشن')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace('انميشنشن','انميشن').replace('الانميشن','انميشن').replace('افلام مسلسلات','افلام ومسلسلات')
		zOnsD74YAjWJmrSgNdkLeqFMt5VQR = zOnsD74YAjWJmrSgNdkLeqFMt5VQR.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).strip(S3X6GcaiExOPtb)
		VGjzYJZykfEWxlQLeap = '_LST_'+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(VGjzYJZykfEWxlQLeap)
		if zOnsD74YAjWJmrSgNdkLeqFMt5VQR not in list(T1tKzfJGbiuP4mkgHl3QrSNVn8.keys()): T1tKzfJGbiuP4mkgHl3QrSNVn8[zOnsD74YAjWJmrSgNdkLeqFMt5VQR] = {}
		T1tKzfJGbiuP4mkgHl3QrSNVn8[zOnsD74YAjWJmrSgNdkLeqFMt5VQR][VGjzYJZykfEWxlQLeap] = [iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL]
	LvJuOzMqk6WlP971eoGpUQ8.append([iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL])
	return
def dCtxzeFX4GJVonm(PPeXbALlv0GzTHsW7iR4Sq):
	if IZhXMprxvAHqBEFkg0: from html import unescape as _PdKH2Vyvm5SiaRwz
	else:
		from HTMLParser import HTMLParser as onzU1r5tvDNhgmxKRCGTEXZb6pw
		_PdKH2Vyvm5SiaRwz = onzU1r5tvDNhgmxKRCGTEXZb6pw().unescape
	if '&' in PPeXbALlv0GzTHsW7iR4Sq and ';' in PPeXbALlv0GzTHsW7iR4Sq:
		if n7neb9KTv10FcU: PPeXbALlv0GzTHsW7iR4Sq = PPeXbALlv0GzTHsW7iR4Sq.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		PPeXbALlv0GzTHsW7iR4Sq = _PdKH2Vyvm5SiaRwz(PPeXbALlv0GzTHsW7iR4Sq)
		if n7neb9KTv10FcU: PPeXbALlv0GzTHsW7iR4Sq = PPeXbALlv0GzTHsW7iR4Sq.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	return PPeXbALlv0GzTHsW7iR4Sq
def eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(PPeXbALlv0GzTHsW7iR4Sq):
	if '\\u' in PPeXbALlv0GzTHsW7iR4Sq:
		if n7neb9KTv10FcU: PPeXbALlv0GzTHsW7iR4Sq = PPeXbALlv0GzTHsW7iR4Sq.decode('unicode_escape','ignore').encode(zSafwK0sDXdMN5JReniIQmrZxp)
		elif IZhXMprxvAHqBEFkg0: PPeXbALlv0GzTHsW7iR4Sq = PPeXbALlv0GzTHsW7iR4Sq.encode(zSafwK0sDXdMN5JReniIQmrZxp).decode('unicode_escape','ignore')
	return PPeXbALlv0GzTHsW7iR4Sq
def u4IWfU1ashntg3T(uQkgSRoVv56TyXGlpF7n,tsom9FTB5eb01I3l7YgdLrXu,P3S6ar9ov0BJK2qnyCUWV1zMTkZp,rnAFoG4cNTist,J1rvN7I8eLXuS54mZ6lnUjg,zLHqUtmR7a0drFn,aW9KRMStji5emgEC2rD6I7Y,Uy8MAzoxZI7mHuaqBTCc,EYOlQ563hw94qkg7KbGexvJs):
	jj98atdLTPvn4lxMWQ3C = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.dirname(EYOlQ563hw94qkg7KbGexvJs)
	if not Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(jj98atdLTPvn4lxMWQ3C):
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.makedirs(jj98atdLTPvn4lxMWQ3C)
		except: pass
	JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4 = HEF7gSbdWKzL6Vpslr2PC3MZUuv(zLHqUtmR7a0drFn)
	lwfEQPTMdoSRYXFvZprI3Hk = FFmheU2OnzHiJjbqvyVCBDR(JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4,uQkgSRoVv56TyXGlpF7n,tsom9FTB5eb01I3l7YgdLrXu,P3S6ar9ov0BJK2qnyCUWV1zMTkZp,rnAFoG4cNTist,J1rvN7I8eLXuS54mZ6lnUjg,zLHqUtmR7a0drFn,aW9KRMStji5emgEC2rD6I7Y,Uy8MAzoxZI7mHuaqBTCc,EYOlQ563hw94qkg7KbGexvJs)
	return lwfEQPTMdoSRYXFvZprI3Hk
def HEF7gSbdWKzL6Vpslr2PC3MZUuv(zLHqUtmR7a0drFn):
	iZnAYoxfMqDw76Egs = 5
	Nb5SuX8K01J9cGpnqZIO2sly = 20
	ICnxWa5k7oe4OzV = 20
	uzFaVOhJqLEdUCx3ZYDHIekg97 = 0
	Hv3oKN5DkQSc2Zw = 'center'
	hGuJNCmAqXZEURPLD8H = 0
	GGLIiFBY7lwZQXc8xJPjpWShg = 19
	RRmMa8FgO5vtCz2DQA = 30
	DLbWKoMfeR1EwunvBm9Xrd7Z6 = 8
	Xq61lIMbew = True
	ugwnqKrmbODZXdMQVaoIpjAk = 375
	aBOEurzj8S2lNXZ = 410
	GGDTnfpsB5ZR0Plhu1QUgm = 50
	VGubTPz7ftODR = 280
	xtVzSHwamuWL3 = 28
	CLDaTH189BwUOfnGxl = 5
	hZXMsPNdbyAjK2QWm3 = 0
	L96bWVClAaXOuEn = 31
	b2LfAarFoueGvmlxdiKWH3PSUIs = [36,32,28]
	from PIL import ImageDraw as zz0F47pPVUEIJfXMW89TZt,ImageFont as gm84czK096aZsVJYw5PqrbFku32,Image as FlcoB76G0mU3b1x
	if 'notification' in zLHqUtmR7a0drFn:
		if zLHqUtmR7a0drFn=='notification_regular':
			Zkaz6odF9PKYBHef2Mc7R0V1grLN = 117
			Hv3oKN5DkQSc2Zw = 'left'
			Xq61lIMbew = False
		elif zLHqUtmR7a0drFn=='notification_auto':
			Zkaz6odF9PKYBHef2Mc7R0V1grLN = 'UPPER'
			Hv3oKN5DkQSc2Zw = 'right'
			uzFaVOhJqLEdUCx3ZYDHIekg97 = 10
		oECvPBwJq5zruGHjRSdYKLkXOah7Wg = 720
		b2LfAarFoueGvmlxdiKWH3PSUIs = [33,33,33]
		ICnxWa5k7oe4OzV = 20
		Nb5SuX8K01J9cGpnqZIO2sly = 0
		RRmMa8FgO5vtCz2DQA = 20
		GGLIiFBY7lwZQXc8xJPjpWShg = 35
	elif zLHqUtmR7a0drFn=='menu_item':
		b2LfAarFoueGvmlxdiKWH3PSUIs,oECvPBwJq5zruGHjRSdYKLkXOah7Wg,Zkaz6odF9PKYBHef2Mc7R0V1grLN = [28,28,28],200,250
		hGuJNCmAqXZEURPLD8H,RRmMa8FgO5vtCz2DQA,GGLIiFBY7lwZQXc8xJPjpWShg, = 0,-12,-30
		Nb5SuX8K01J9cGpnqZIO2sly = 0
		qoJQI8VkW6ijXnyN5zuLbMA0B = FlcoB76G0mU3b1x.open(lxNkBjPrQhcILG2iqvAVfeWtd)
		YUN5bQGPguWd8 = FlcoB76G0mU3b1x.new('RGBA',(oECvPBwJq5zruGHjRSdYKLkXOah7Wg,Zkaz6odF9PKYBHef2Mc7R0V1grLN),(255,0,0,255))
	elif zLHqUtmR7a0drFn=='confirm_smallfont': b2LfAarFoueGvmlxdiKWH3PSUIs,Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = [28,24,20],500,900
	elif zLHqUtmR7a0drFn=='confirm_mediumfont': b2LfAarFoueGvmlxdiKWH3PSUIs,Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = [32,28,24],500,900
	elif zLHqUtmR7a0drFn=='confirm_bigfont': b2LfAarFoueGvmlxdiKWH3PSUIs,Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = [36,32,28],500,900
	elif zLHqUtmR7a0drFn=='textview_bigfont': Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = 740,1270
	elif zLHqUtmR7a0drFn=='textview_bigfont_long': Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = 'UPPER',1270
	elif zLHqUtmR7a0drFn=='textview_smallfont': b2LfAarFoueGvmlxdiKWH3PSUIs,Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = [28,23,18],740,1270
	elif zLHqUtmR7a0drFn=='textview_smallfont_long': b2LfAarFoueGvmlxdiKWH3PSUIs,Zkaz6odF9PKYBHef2Mc7R0V1grLN,oECvPBwJq5zruGHjRSdYKLkXOah7Wg = [28,23,18],'UPPER',1270
	BBwy71KkJDAIgdNlWbsGa,jvhH3nJocSkRq8,DYEGBNFP6VqH8b = b2LfAarFoueGvmlxdiKWH3PSUIs
	Gj9cOqMhTLuBUKs = gm84czK096aZsVJYw5PqrbFku32.truetype(Go8OygdMhLX7k,size=BBwy71KkJDAIgdNlWbsGa)
	L3kMW17Ax24mS6 = gm84czK096aZsVJYw5PqrbFku32.truetype(Go8OygdMhLX7k,size=jvhH3nJocSkRq8)
	jz6FJxWLwA38qd9MY2ED = gm84czK096aZsVJYw5PqrbFku32.truetype(Go8OygdMhLX7k,size=DYEGBNFP6VqH8b)
	KZfojhbCrHe = oECvPBwJq5zruGHjRSdYKLkXOah7Wg-RRmMa8FgO5vtCz2DQA*2
	v1C9OFYdRrHXM6Wl57GhkKp0Ibqt = FlcoB76G0mU3b1x.new('RGBA',(KZfojhbCrHe,100),(255,255,255,0))
	HBZfWE78hjKkx = zz0F47pPVUEIJfXMW89TZt.Draw(v1C9OFYdRrHXM6Wl57GhkKp0Ibqt)
	unAOp91JwRHPWafrVz7X5My,C4aMtS2gK87 = HBZfWE78hjKkx.textsize('HHH BBB 888 000',font=Gj9cOqMhTLuBUKs)
	zLBohjgMV194,wXh7yC5x68nV3Zpiltg = HBZfWE78hjKkx.textsize('HHH BBB 888 000',font=L3kMW17Ax24mS6)
	OImfniNpBG0eWdP3z = {'delete_harakat':False,'support_ligatures':True,'ARABIC LIGATURE ALLAH':False}
	from arabic_reshaper import ArabicReshaper as K0fWw5vsMcRtzAobV24UymLGHaXQO
	WWXmTNkUBwyS1GupCaJ7lvOgAKd = K0fWw5vsMcRtzAobV24UymLGHaXQO(configuration=OImfniNpBG0eWdP3z)
	JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4 = {}
	Zbxw1fqgOnjiS = locals()
	for dvhs8lngSEQTyr4a7YwjkFVcWope in Zbxw1fqgOnjiS: JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4[dvhs8lngSEQTyr4a7YwjkFVcWope] = Zbxw1fqgOnjiS[dvhs8lngSEQTyr4a7YwjkFVcWope]
	return JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4
def FFmheU2OnzHiJjbqvyVCBDR(JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4,uQkgSRoVv56TyXGlpF7n,tsom9FTB5eb01I3l7YgdLrXu,P3S6ar9ov0BJK2qnyCUWV1zMTkZp,rnAFoG4cNTist,J1rvN7I8eLXuS54mZ6lnUjg,zLHqUtmR7a0drFn,aW9KRMStji5emgEC2rD6I7Y,Uy8MAzoxZI7mHuaqBTCc,EYOlQ563hw94qkg7KbGexvJs):
	for dvhs8lngSEQTyr4a7YwjkFVcWope in JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4: globals()[dvhs8lngSEQTyr4a7YwjkFVcWope] = JI7ZmGTwgctuqR0Kp6MD1eAkfCWXY4[dvhs8lngSEQTyr4a7YwjkFVcWope]
	global xtVzSHwamuWL3,CLDaTH189BwUOfnGxl
	if zLHqUtmR7a0drFn!='menu_item':
		KK6zJZqk7j0CuNbBa = llnG7jiQBYKhAeovbT.getSetting('av.language.translate')
		if KK6zJZqk7j0CuNbBa:
			if uQkgSRoVv56TyXGlpF7n=='نعم  Yes': uQkgSRoVv56TyXGlpF7n = 'Yes'
			elif uQkgSRoVv56TyXGlpF7n=='كلا  No': uQkgSRoVv56TyXGlpF7n = 'No'
			if tsom9FTB5eb01I3l7YgdLrXu=='نعم  Yes': tsom9FTB5eb01I3l7YgdLrXu = 'Yes'
			elif tsom9FTB5eb01I3l7YgdLrXu=='كلا  No': tsom9FTB5eb01I3l7YgdLrXu = 'No'
			if P3S6ar9ov0BJK2qnyCUWV1zMTkZp=='نعم  Yes': P3S6ar9ov0BJK2qnyCUWV1zMTkZp = 'Yes'
			elif P3S6ar9ov0BJK2qnyCUWV1zMTkZp=='كلا  No': P3S6ar9ov0BJK2qnyCUWV1zMTkZp = 'No'
			UmwA0cdOSg2s7vnKR8zYp4ohWqH = wRVgSQralMTW4pxzu8JPLB([uQkgSRoVv56TyXGlpF7n,tsom9FTB5eb01I3l7YgdLrXu,P3S6ar9ov0BJK2qnyCUWV1zMTkZp,rnAFoG4cNTist,J1rvN7I8eLXuS54mZ6lnUjg])
			if UmwA0cdOSg2s7vnKR8zYp4ohWqH: uQkgSRoVv56TyXGlpF7n,tsom9FTB5eb01I3l7YgdLrXu,P3S6ar9ov0BJK2qnyCUWV1zMTkZp,rnAFoG4cNTist,J1rvN7I8eLXuS54mZ6lnUjg = UmwA0cdOSg2s7vnKR8zYp4ohWqH
	if n7neb9KTv10FcU:
		J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		rnAFoG4cNTist = rnAFoG4cNTist.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		uQkgSRoVv56TyXGlpF7n = uQkgSRoVv56TyXGlpF7n.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		tsom9FTB5eb01I3l7YgdLrXu = tsom9FTB5eb01I3l7YgdLrXu.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		P3S6ar9ov0BJK2qnyCUWV1zMTkZp = P3S6ar9ov0BJK2qnyCUWV1zMTkZp.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	wCBphxKtcg = rnAFoG4cNTist.count(wwOnIucWJj)+1
	Gyzg09menHCt = Nb5SuX8K01J9cGpnqZIO2sly+wCBphxKtcg*(C4aMtS2gK87+uzFaVOhJqLEdUCx3ZYDHIekg97)-uzFaVOhJqLEdUCx3ZYDHIekg97
	if J1rvN7I8eLXuS54mZ6lnUjg:
		CCwb6pDv2Gma80c5 = wXh7yC5x68nV3Zpiltg+DLbWKoMfeR1EwunvBm9Xrd7Z6
		WpXflONCYua9 = WWXmTNkUBwyS1GupCaJ7lvOgAKd.reshape(J1rvN7I8eLXuS54mZ6lnUjg)
		if Xq61lIMbew:
			hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7 = jwhnZ3lCupEsYT9O(HBZfWE78hjKkx,L3kMW17Ax24mS6,WpXflONCYua9,jvhH3nJocSkRq8,KZfojhbCrHe,CCwb6pDv2Gma80c5)
			nU0hcBztdGl = xd1knbJO9oMP2zfEWXL(hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7)
			UHadYv0mV7Nex3MqpjS1BFW5cTD = nU0hcBztdGl.count(wwOnIucWJj)+1
			mcgNQHFItr7wGAuZyiq5XDvPOb3 = GGLIiFBY7lwZQXc8xJPjpWShg+UHadYv0mV7Nex3MqpjS1BFW5cTD*CCwb6pDv2Gma80c5-DLbWKoMfeR1EwunvBm9Xrd7Z6
		else:
			mcgNQHFItr7wGAuZyiq5XDvPOb3 = GGLIiFBY7lwZQXc8xJPjpWShg+wXh7yC5x68nV3Zpiltg
			nU0hcBztdGl = WpXflONCYua9.split(wwOnIucWJj)[0]
			hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7 = WpXflONCYua9.split(wwOnIucWJj)[0]
	else: mcgNQHFItr7wGAuZyiq5XDvPOb3 = GGLIiFBY7lwZQXc8xJPjpWShg
	kjI3A9wHtayLE8VF4N5CxB = hZXMsPNdbyAjK2QWm3+L96bWVClAaXOuEn
	if Uy8MAzoxZI7mHuaqBTCc:
		DqN0IHQmTUvCErBe4oyfiScVY = aBOEurzj8S2lNXZ-ugwnqKrmbODZXdMQVaoIpjAk
		kjI3A9wHtayLE8VF4N5CxB += DqN0IHQmTUvCErBe4oyfiScVY
	else: DqN0IHQmTUvCErBe4oyfiScVY = 0
	if uQkgSRoVv56TyXGlpF7n or tsom9FTB5eb01I3l7YgdLrXu or P3S6ar9ov0BJK2qnyCUWV1zMTkZp: kjI3A9wHtayLE8VF4N5CxB += GGDTnfpsB5ZR0Plhu1QUgm
	lwfEQPTMdoSRYXFvZprI3Hk = Zkaz6odF9PKYBHef2Mc7R0V1grLN if Zkaz6odF9PKYBHef2Mc7R0V1grLN!='UPPER' else Gyzg09menHCt+mcgNQHFItr7wGAuZyiq5XDvPOb3+kjI3A9wHtayLE8VF4N5CxB
	v1C9OFYdRrHXM6Wl57GhkKp0Ibqt = FlcoB76G0mU3b1x.new('RGBA',(oECvPBwJq5zruGHjRSdYKLkXOah7Wg,lwfEQPTMdoSRYXFvZprI3Hk),(255,255,255,0))
	eqBhdyWvzVT5R4bi6tgf2c = zz0F47pPVUEIJfXMW89TZt.Draw(v1C9OFYdRrHXM6Wl57GhkKp0Ibqt)
	pgJnzi6WF8jwQ = lwfEQPTMdoSRYXFvZprI3Hk-Gyzg09menHCt-kjI3A9wHtayLE8VF4N5CxB-GGLIiFBY7lwZQXc8xJPjpWShg
	if not tsom9FTB5eb01I3l7YgdLrXu and uQkgSRoVv56TyXGlpF7n and P3S6ar9ov0BJK2qnyCUWV1zMTkZp:
		xtVzSHwamuWL3 += 105
		CLDaTH189BwUOfnGxl -= 110
	import bidi.algorithm as InTA8P54xi0Ocg
	if rnAFoG4cNTist:
		uOQkjHPnNJ8M96 = Nb5SuX8K01J9cGpnqZIO2sly
		rnAFoG4cNTist = InTA8P54xi0Ocg.get_display(WWXmTNkUBwyS1GupCaJ7lvOgAKd.reshape(rnAFoG4cNTist))
		rrfWsKPq4nzR0V7jFoNBHQe = rnAFoG4cNTist.splitlines()
		for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
			if k38Vi6PpwFNB7Aus1KErSLJaOdDvM:
				CD9c3LnVERBXd1Jv,zqsuwkTM0OGiDecP7IN9UCVKEf = eqBhdyWvzVT5R4bi6tgf2c.textsize(k38Vi6PpwFNB7Aus1KErSLJaOdDvM,font=Gj9cOqMhTLuBUKs)
				if Hv3oKN5DkQSc2Zw=='center': AqyjTIhFaHu0OmDzgGbkXsvSEoQ1 = iZnAYoxfMqDw76Egs+(oECvPBwJq5zruGHjRSdYKLkXOah7Wg-CD9c3LnVERBXd1Jv)/2
				elif Hv3oKN5DkQSc2Zw=='right': AqyjTIhFaHu0OmDzgGbkXsvSEoQ1 = iZnAYoxfMqDw76Egs+oECvPBwJq5zruGHjRSdYKLkXOah7Wg-CD9c3LnVERBXd1Jv-ICnxWa5k7oe4OzV
				elif Hv3oKN5DkQSc2Zw=='left': AqyjTIhFaHu0OmDzgGbkXsvSEoQ1 = iZnAYoxfMqDw76Egs+ICnxWa5k7oe4OzV
				eqBhdyWvzVT5R4bi6tgf2c.text((AqyjTIhFaHu0OmDzgGbkXsvSEoQ1,uOQkjHPnNJ8M96),k38Vi6PpwFNB7Aus1KErSLJaOdDvM,font=Gj9cOqMhTLuBUKs,fill='yellow')
			uOQkjHPnNJ8M96 += BBwy71KkJDAIgdNlWbsGa+uzFaVOhJqLEdUCx3ZYDHIekg97
	if uQkgSRoVv56TyXGlpF7n or tsom9FTB5eb01I3l7YgdLrXu or P3S6ar9ov0BJK2qnyCUWV1zMTkZp:
		cYETqmQlX8xHrC4v13uWFLb = Gyzg09menHCt+pgJnzi6WF8jwQ+GGLIiFBY7lwZQXc8xJPjpWShg+DqN0IHQmTUvCErBe4oyfiScVY+hZXMsPNdbyAjK2QWm3
		if uQkgSRoVv56TyXGlpF7n:
			uQkgSRoVv56TyXGlpF7n = InTA8P54xi0Ocg.get_display(WWXmTNkUBwyS1GupCaJ7lvOgAKd.reshape(uQkgSRoVv56TyXGlpF7n))
			xgp04cnNsTaPBvbm32hRlFiECU,nfpUIB7G8mS9d = eqBhdyWvzVT5R4bi6tgf2c.textsize(uQkgSRoVv56TyXGlpF7n,font=jz6FJxWLwA38qd9MY2ED)
			w5zRbHthNpDGOC8B01m6i4qx2 = xtVzSHwamuWL3+0*(CLDaTH189BwUOfnGxl+VGubTPz7ftODR)+(VGubTPz7ftODR-xgp04cnNsTaPBvbm32hRlFiECU)/2
			eqBhdyWvzVT5R4bi6tgf2c.text((w5zRbHthNpDGOC8B01m6i4qx2,cYETqmQlX8xHrC4v13uWFLb),uQkgSRoVv56TyXGlpF7n,font=jz6FJxWLwA38qd9MY2ED,fill='yellow')
		if tsom9FTB5eb01I3l7YgdLrXu:
			tsom9FTB5eb01I3l7YgdLrXu = InTA8P54xi0Ocg.get_display(WWXmTNkUBwyS1GupCaJ7lvOgAKd.reshape(tsom9FTB5eb01I3l7YgdLrXu))
			FNmKb0OdPeZ4ulcgWpCo1xnq6Y,UhKydSIloZbxC9p6 = eqBhdyWvzVT5R4bi6tgf2c.textsize(tsom9FTB5eb01I3l7YgdLrXu,font=jz6FJxWLwA38qd9MY2ED)
			p3z4IuE57emq2LKoSQFg = xtVzSHwamuWL3+1*(CLDaTH189BwUOfnGxl+VGubTPz7ftODR)+(VGubTPz7ftODR-FNmKb0OdPeZ4ulcgWpCo1xnq6Y)/2
			eqBhdyWvzVT5R4bi6tgf2c.text((p3z4IuE57emq2LKoSQFg,cYETqmQlX8xHrC4v13uWFLb),tsom9FTB5eb01I3l7YgdLrXu,font=jz6FJxWLwA38qd9MY2ED,fill='yellow')
		if P3S6ar9ov0BJK2qnyCUWV1zMTkZp:
			P3S6ar9ov0BJK2qnyCUWV1zMTkZp = InTA8P54xi0Ocg.get_display(WWXmTNkUBwyS1GupCaJ7lvOgAKd.reshape(P3S6ar9ov0BJK2qnyCUWV1zMTkZp))
			PIShQ4cMizV5X,kOswHxzQroecl = eqBhdyWvzVT5R4bi6tgf2c.textsize(P3S6ar9ov0BJK2qnyCUWV1zMTkZp,font=jz6FJxWLwA38qd9MY2ED)
			tfFdjRXiEBCUA1oJ3NIcw7 = xtVzSHwamuWL3+2*(CLDaTH189BwUOfnGxl+VGubTPz7ftODR)+(VGubTPz7ftODR-PIShQ4cMizV5X)/2
			eqBhdyWvzVT5R4bi6tgf2c.text((tfFdjRXiEBCUA1oJ3NIcw7,cYETqmQlX8xHrC4v13uWFLb),P3S6ar9ov0BJK2qnyCUWV1zMTkZp,font=jz6FJxWLwA38qd9MY2ED,fill='yellow')
	if J1rvN7I8eLXuS54mZ6lnUjg:
		uBg9LNUy7S6OpZGl8e5c2owVhmb,CCzMFUVkZp53qx8I9re = [],[]
		hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7 = raceHmKSYjUuDTNt(hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7)
		NRztb3X1G8KoQ5LEiecZJYTwj2O7 = hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7.split('_sss__newline_')
		for PZb1RaVTvAzfr24O9UJ8xY in NRztb3X1G8KoQ5LEiecZJYTwj2O7:
			pZLI2jYqiTAosFtGmV7aOd5De = aW9KRMStji5emgEC2rD6I7Y
			if   '_sss__lineleft_' in PZb1RaVTvAzfr24O9UJ8xY: pZLI2jYqiTAosFtGmV7aOd5De = 'left'
			elif '_sss__lineright_' in PZb1RaVTvAzfr24O9UJ8xY: pZLI2jYqiTAosFtGmV7aOd5De = 'right'
			elif '_sss__linecenter_' in PZb1RaVTvAzfr24O9UJ8xY: pZLI2jYqiTAosFtGmV7aOd5De = 'center'
			y4ynS6XcosLM793fB = PZb1RaVTvAzfr24O9UJ8xY
			l8FdMuLiOJtjo = ScntgdOZCY74vNpXeW5jh8i.findall('_sss__.*?_',PZb1RaVTvAzfr24O9UJ8xY,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for fsgtyANFBwmk89Te4MI in l8FdMuLiOJtjo: y4ynS6XcosLM793fB = y4ynS6XcosLM793fB.replace(fsgtyANFBwmk89Te4MI,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if y4ynS6XcosLM793fB==nbOFVEDkpT4BIR7Qq82yPmHeJU: CD9c3LnVERBXd1Jv,zqsuwkTM0OGiDecP7IN9UCVKEf = 0,CCwb6pDv2Gma80c5
			else: CD9c3LnVERBXd1Jv,zqsuwkTM0OGiDecP7IN9UCVKEf = eqBhdyWvzVT5R4bi6tgf2c.textsize(y4ynS6XcosLM793fB,font=L3kMW17Ax24mS6)
			if   pZLI2jYqiTAosFtGmV7aOd5De=='left': shMxWoCYrtjqDL1FUKI8dJzA = hGuJNCmAqXZEURPLD8H+RRmMa8FgO5vtCz2DQA
			elif pZLI2jYqiTAosFtGmV7aOd5De=='right': shMxWoCYrtjqDL1FUKI8dJzA = hGuJNCmAqXZEURPLD8H+RRmMa8FgO5vtCz2DQA+KZfojhbCrHe-CD9c3LnVERBXd1Jv
			elif pZLI2jYqiTAosFtGmV7aOd5De=='center': shMxWoCYrtjqDL1FUKI8dJzA = hGuJNCmAqXZEURPLD8H+RRmMa8FgO5vtCz2DQA+(KZfojhbCrHe-CD9c3LnVERBXd1Jv)/2
			if shMxWoCYrtjqDL1FUKI8dJzA<RRmMa8FgO5vtCz2DQA: shMxWoCYrtjqDL1FUKI8dJzA = hGuJNCmAqXZEURPLD8H+RRmMa8FgO5vtCz2DQA
			uBg9LNUy7S6OpZGl8e5c2owVhmb.append(shMxWoCYrtjqDL1FUKI8dJzA)
			CCzMFUVkZp53qx8I9re.append(CD9c3LnVERBXd1Jv)
		shMxWoCYrtjqDL1FUKI8dJzA = uBg9LNUy7S6OpZGl8e5c2owVhmb[0]
		h734hHdpIFZEWKXlvx5zcQDVw = hQ5Bj8yLxvo9Sw0MUVEFnsKfGTeA7.split('_sss_')
		OnGd4sHiCKtA7BTvlW9ohw8jJR63 = (255,255,255,255)
		A0n83dPDJ5iOGkjNC = OnGd4sHiCKtA7BTvlW9ohw8jJR63
		HAPYbzjZ1n2QFqa,JJQ2ARGuzYsTrUv9aWjVMNBwnDg8 = 0,0
		kGQTLaXwEJ3dj57M1UocNr6s42x = False
		jT16rnkoOzRc = 0
		ddzpGuEHOPCsIrFe = Gyzg09menHCt+GGLIiFBY7lwZQXc8xJPjpWShg/2
		if mcgNQHFItr7wGAuZyiq5XDvPOb3<(pgJnzi6WF8jwQ+GGLIiFBY7lwZQXc8xJPjpWShg):
			AwExOI0m7jphUtL1Mu = (pgJnzi6WF8jwQ+GGLIiFBY7lwZQXc8xJPjpWShg-mcgNQHFItr7wGAuZyiq5XDvPOb3)/2
			ddzpGuEHOPCsIrFe = Gyzg09menHCt+GGLIiFBY7lwZQXc8xJPjpWShg+AwExOI0m7jphUtL1Mu-wXh7yC5x68nV3Zpiltg/2
		for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in h734hHdpIFZEWKXlvx5zcQDVw:
			if not k38Vi6PpwFNB7Aus1KErSLJaOdDvM or (k38Vi6PpwFNB7Aus1KErSLJaOdDvM and ord(k38Vi6PpwFNB7Aus1KErSLJaOdDvM[0])==65279): continue
			gON7zQiUX4vaVxM6lsFwSyIp10Cec = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_newline_',1)
			sUQjavIJuwV8F9yqSM7c25rfBnPGz = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_newcolor',1)
			JJNExAMDy3uqKGj8XHPrsd9Yp = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_endcolor_',1)
			MhirWHvEqb = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_linertl_',1)
			v3qmThlHiCK2z = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_lineleft_',1)
			UuIJaPhmZvw = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_lineright_',1)
			kktERPvQCm = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.split('_linecenter_',1)
			if len(gON7zQiUX4vaVxM6lsFwSyIp10Cec)>1:
				jT16rnkoOzRc += 1
				k38Vi6PpwFNB7Aus1KErSLJaOdDvM = gON7zQiUX4vaVxM6lsFwSyIp10Cec[1]
				HAPYbzjZ1n2QFqa = 0
				shMxWoCYrtjqDL1FUKI8dJzA = uBg9LNUy7S6OpZGl8e5c2owVhmb[jT16rnkoOzRc]
				JJQ2ARGuzYsTrUv9aWjVMNBwnDg8 += CCwb6pDv2Gma80c5
				kGQTLaXwEJ3dj57M1UocNr6s42x = False
			elif len(sUQjavIJuwV8F9yqSM7c25rfBnPGz)>1:
				k38Vi6PpwFNB7Aus1KErSLJaOdDvM = sUQjavIJuwV8F9yqSM7c25rfBnPGz[1]
				A0n83dPDJ5iOGkjNC = k38Vi6PpwFNB7Aus1KErSLJaOdDvM[0:8]
				A0n83dPDJ5iOGkjNC = '#'+A0n83dPDJ5iOGkjNC[2:]
				k38Vi6PpwFNB7Aus1KErSLJaOdDvM = k38Vi6PpwFNB7Aus1KErSLJaOdDvM[9:]
			elif len(JJNExAMDy3uqKGj8XHPrsd9Yp)>1:
				k38Vi6PpwFNB7Aus1KErSLJaOdDvM = JJNExAMDy3uqKGj8XHPrsd9Yp[1]
				A0n83dPDJ5iOGkjNC = OnGd4sHiCKtA7BTvlW9ohw8jJR63
			elif len(MhirWHvEqb)>1:
				k38Vi6PpwFNB7Aus1KErSLJaOdDvM = MhirWHvEqb[1]
				kGQTLaXwEJ3dj57M1UocNr6s42x = True
				HAPYbzjZ1n2QFqa = CCzMFUVkZp53qx8I9re[jT16rnkoOzRc]
			elif len(v3qmThlHiCK2z)>1: k38Vi6PpwFNB7Aus1KErSLJaOdDvM = v3qmThlHiCK2z[1]
			elif len(UuIJaPhmZvw)>1: k38Vi6PpwFNB7Aus1KErSLJaOdDvM = UuIJaPhmZvw[1]
			elif len(kktERPvQCm)>1: k38Vi6PpwFNB7Aus1KErSLJaOdDvM = kktERPvQCm[1]
			if k38Vi6PpwFNB7Aus1KErSLJaOdDvM:
				reHh49Obs8V = ddzpGuEHOPCsIrFe+JJQ2ARGuzYsTrUv9aWjVMNBwnDg8
				k38Vi6PpwFNB7Aus1KErSLJaOdDvM = InTA8P54xi0Ocg.get_display(k38Vi6PpwFNB7Aus1KErSLJaOdDvM)
				CD9c3LnVERBXd1Jv,zqsuwkTM0OGiDecP7IN9UCVKEf = eqBhdyWvzVT5R4bi6tgf2c.textsize(k38Vi6PpwFNB7Aus1KErSLJaOdDvM,font=L3kMW17Ax24mS6)
				if kGQTLaXwEJ3dj57M1UocNr6s42x: HAPYbzjZ1n2QFqa -= CD9c3LnVERBXd1Jv
				xUHw0GAjnBl1FTd6ZMr7LhmpD3Q9by = shMxWoCYrtjqDL1FUKI8dJzA+HAPYbzjZ1n2QFqa
				eqBhdyWvzVT5R4bi6tgf2c.text((xUHw0GAjnBl1FTd6ZMr7LhmpD3Q9by,reHh49Obs8V),k38Vi6PpwFNB7Aus1KErSLJaOdDvM,font=L3kMW17Ax24mS6,fill=A0n83dPDJ5iOGkjNC)
				if zLHqUtmR7a0drFn=='menu_item': eqBhdyWvzVT5R4bi6tgf2c.text((xUHw0GAjnBl1FTd6ZMr7LhmpD3Q9by+1,reHh49Obs8V+1),k38Vi6PpwFNB7Aus1KErSLJaOdDvM,font=L3kMW17Ax24mS6,fill=A0n83dPDJ5iOGkjNC)
				if not kGQTLaXwEJ3dj57M1UocNr6s42x: HAPYbzjZ1n2QFqa += CD9c3LnVERBXd1Jv
				if reHh49Obs8V>pgJnzi6WF8jwQ+CCwb6pDv2Gma80c5: break
	if zLHqUtmR7a0drFn=='menu_item':
		hBTYUu3R4lztFQNSEk = qoJQI8VkW6ijXnyN5zuLbMA0B.copy()
		lQMuw1PvVpAk.sleep(0.05)
		hBTYUu3R4lztFQNSEk.paste(YUN5bQGPguWd8,(0,0),mask=v1C9OFYdRrHXM6Wl57GhkKp0Ibqt)
	else: hBTYUu3R4lztFQNSEk = v1C9OFYdRrHXM6Wl57GhkKp0Ibqt
	if n7neb9KTv10FcU: EYOlQ563hw94qkg7KbGexvJs = EYOlQ563hw94qkg7KbGexvJs.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	try: hBTYUu3R4lztFQNSEk.save(EYOlQ563hw94qkg7KbGexvJs)
	except UnicodeError:
		if n7neb9KTv10FcU:
			EYOlQ563hw94qkg7KbGexvJs = EYOlQ563hw94qkg7KbGexvJs.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			hBTYUu3R4lztFQNSEk.save(EYOlQ563hw94qkg7KbGexvJs)
	return lwfEQPTMdoSRYXFvZprI3Hk
def jwhnZ3lCupEsYT9O(HBZfWE78hjKkx,L3kMW17Ax24mS6,IPoAYRqyOpzLmS27n5uD8wdkQ6xb,so3MtlJPCHYkwAT2Q0E4fvdSye,KZfojhbCrHe,Ryx3YV7dKbsZcLXm):
	RV0LDq4s7J9kvyxjfghwaGZO,esFhPJNEvmTC6tlR,mQCip12UZWdhFuqeytsS = nbOFVEDkpT4BIR7Qq82yPmHeJU,0,15000
	IPoAYRqyOpzLmS27n5uD8wdkQ6xb = IPoAYRqyOpzLmS27n5uD8wdkQ6xb.replace('[COLOR ','[COLOR:::')
	Q78BkAxmFVIrZNdG2s = KZfojhbCrHe-so3MtlJPCHYkwAT2Q0E4fvdSye*2
	for FJtDHkzdBRxIA5aioful2gUr6yK in IPoAYRqyOpzLmS27n5uD8wdkQ6xb.splitlines():
		esFhPJNEvmTC6tlR += Ryx3YV7dKbsZcLXm
		jC4winlrt3HM0p7SY51QVA9,rb3kVAz1hTKIqxCMm9n20 = 0,nbOFVEDkpT4BIR7Qq82yPmHeJU
		for oDBFOQHy8j1wpNI5ha2Er3g4U in FJtDHkzdBRxIA5aioful2gUr6yK.split(S3X6GcaiExOPtb):
			aTJt1OzH0DiFXoMlYgcIp = xd1knbJO9oMP2zfEWXL(S3X6GcaiExOPtb+oDBFOQHy8j1wpNI5ha2Er3g4U)
			LLkFUuNACODM4igzT7Z1j5y,eIBxTwHFbAmoRnjD8U = HBZfWE78hjKkx.textsize(aTJt1OzH0DiFXoMlYgcIp,font=L3kMW17Ax24mS6)
			if jC4winlrt3HM0p7SY51QVA9+LLkFUuNACODM4igzT7Z1j5y<Q78BkAxmFVIrZNdG2s:
				if not rb3kVAz1hTKIqxCMm9n20: rb3kVAz1hTKIqxCMm9n20 += oDBFOQHy8j1wpNI5ha2Er3g4U
				else: rb3kVAz1hTKIqxCMm9n20 += S3X6GcaiExOPtb+oDBFOQHy8j1wpNI5ha2Er3g4U
				jC4winlrt3HM0p7SY51QVA9 += LLkFUuNACODM4igzT7Z1j5y
			else:
				if LLkFUuNACODM4igzT7Z1j5y<Q78BkAxmFVIrZNdG2s:
					rb3kVAz1hTKIqxCMm9n20 += '\n '+oDBFOQHy8j1wpNI5ha2Er3g4U
					esFhPJNEvmTC6tlR += Ryx3YV7dKbsZcLXm
					jC4winlrt3HM0p7SY51QVA9 = LLkFUuNACODM4igzT7Z1j5y
				else:
					while LLkFUuNACODM4igzT7Z1j5y>Q78BkAxmFVIrZNdG2s:
						for uvOaDl7f60HCwBiVKzes24 in range(1,len(S3X6GcaiExOPtb+oDBFOQHy8j1wpNI5ha2Er3g4U),1):
							ZZ9L0MWAsfj4DapiSJEBvxe = S3X6GcaiExOPtb+oDBFOQHy8j1wpNI5ha2Er3g4U[:uvOaDl7f60HCwBiVKzes24]
							tmyMci9BJCaKqLQjsWIT8z3DeOX = oDBFOQHy8j1wpNI5ha2Er3g4U[uvOaDl7f60HCwBiVKzes24:]
							nn5sagMAFkGXRNfe1JUpqmH9tP = xd1knbJO9oMP2zfEWXL(ZZ9L0MWAsfj4DapiSJEBvxe)
							jOfuM02oTSXF3JNwYUaV91ghQsP8my,VoMvm57ezIdiKbfq = HBZfWE78hjKkx.textsize(nn5sagMAFkGXRNfe1JUpqmH9tP,font=L3kMW17Ax24mS6)
							if jC4winlrt3HM0p7SY51QVA9+jOfuM02oTSXF3JNwYUaV91ghQsP8my>Q78BkAxmFVIrZNdG2s:
								DJ0p8NPEQlsSCA3HgYdaIU = LLkFUuNACODM4igzT7Z1j5y-jOfuM02oTSXF3JNwYUaV91ghQsP8my
								rb3kVAz1hTKIqxCMm9n20 += ZZ9L0MWAsfj4DapiSJEBvxe+wwOnIucWJj
								esFhPJNEvmTC6tlR += Ryx3YV7dKbsZcLXm
								LLkFUuNACODM4igzT7Z1j5y = DJ0p8NPEQlsSCA3HgYdaIU
								if DJ0p8NPEQlsSCA3HgYdaIU>Q78BkAxmFVIrZNdG2s:
									jC4winlrt3HM0p7SY51QVA9 = 0
									oDBFOQHy8j1wpNI5ha2Er3g4U = tmyMci9BJCaKqLQjsWIT8z3DeOX
								else:
									jC4winlrt3HM0p7SY51QVA9 = DJ0p8NPEQlsSCA3HgYdaIU
									rb3kVAz1hTKIqxCMm9n20 += tmyMci9BJCaKqLQjsWIT8z3DeOX
								break
				if esFhPJNEvmTC6tlR>mQCip12UZWdhFuqeytsS: break
		RV0LDq4s7J9kvyxjfghwaGZO += wwOnIucWJj+rb3kVAz1hTKIqxCMm9n20
		if esFhPJNEvmTC6tlR>mQCip12UZWdhFuqeytsS: break
	RV0LDq4s7J9kvyxjfghwaGZO = RV0LDq4s7J9kvyxjfghwaGZO[1:]
	RV0LDq4s7J9kvyxjfghwaGZO = RV0LDq4s7J9kvyxjfghwaGZO.replace('[COLOR:::','[COLOR ')
	return RV0LDq4s7J9kvyxjfghwaGZO
def xd1knbJO9oMP2zfEWXL(oDBFOQHy8j1wpNI5ha2Er3g4U):
	if '[' in oDBFOQHy8j1wpNI5ha2Er3g4U and ']' in oDBFOQHy8j1wpNI5ha2Er3g4U:
		l8FdMuLiOJtjo = [c7gxFyUCGm,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		jPYV5XsIWbA = ScntgdOZCY74vNpXeW5jh8i.findall('\[COLOR .*?\]',oDBFOQHy8j1wpNI5ha2Er3g4U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Tphg056BslvIHFAnqJD9iMVwz = ScntgdOZCY74vNpXeW5jh8i.findall('\[COLOR:::.*?\]',oDBFOQHy8j1wpNI5ha2Er3g4U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		bSthIkF4MBmJ = l8FdMuLiOJtjo+jPYV5XsIWbA+Tphg056BslvIHFAnqJD9iMVwz
		for fsgtyANFBwmk89Te4MI in bSthIkF4MBmJ: oDBFOQHy8j1wpNI5ha2Er3g4U = oDBFOQHy8j1wpNI5ha2Er3g4U.replace(fsgtyANFBwmk89Te4MI,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return oDBFOQHy8j1wpNI5ha2Er3g4U
def raceHmKSYjUuDTNt(J1rvN7I8eLXuS54mZ6lnUjg):
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(wwOnIucWJj,'_sss__newline_')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[RTL]','_sss__linertl_')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[LEFT]','_sss__lineleft_')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[RIGHT]','_sss__lineright_')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[CENTER]','_sss__linecenter_')
	J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace(c7gxFyUCGm,'_sss__endcolor_')
	J8JbMSXNfRaiOZeTj43td = ScntgdOZCY74vNpXeW5jh8i.findall('\[COLOR (.*?)\]',J1rvN7I8eLXuS54mZ6lnUjg,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for qsUOARbjz3rlayLxk2e8B in J8JbMSXNfRaiOZeTj43td: J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.replace('[COLOR '+qsUOARbjz3rlayLxk2e8B+']','_sss__newcolor'+qsUOARbjz3rlayLxk2e8B+'_')
	return J1rvN7I8eLXuS54mZ6lnUjg
def Op47XGBbfiolxenLkTdyPrW6Z(sgQPhTZqmbDR9U8vXpHojSkWLFrizG,xbfwC5hkXLvsJa8PReOS9AyU1z=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not xbfwC5hkXLvsJa8PReOS9AyU1z: xbfwC5hkXLvsJa8PReOS9AyU1z = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Label')
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace(R4PgzXibOn3f1SxmldrWw8acs2p,S3X6GcaiExOPtb).replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).strip(S3X6GcaiExOPtb)
	if sgQPhTZqmbDR9U8vXpHojSkWLFrizG: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('[COLOR ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(']',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	else: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace(l5JG7XwbOfo8DznU,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(eMypvI8XqHjYU02anWD9gsSrkt,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(Tm7XlOI1kSsg5L9Znd3RJVorD,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(fvZik7JRpGy2nlTxAaHzjhueK8,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	QjFV2DniPbzUEh9SrdxwMNoK = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d:\d\d ',xbfwC5hkXLvsJa8PReOS9AyU1z,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if QjFV2DniPbzUEh9SrdxwMNoK: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.split(QjFV2DniPbzUEh9SrdxwMNoK[0],1)[1]
	if not xbfwC5hkXLvsJa8PReOS9AyU1z: xbfwC5hkXLvsJa8PReOS9AyU1z = 'Main Menu'
	return xbfwC5hkXLvsJa8PReOS9AyU1z
def JABPVj6TrWOU29Xvmo(OT2twr6bkIVevaGfSPM1):
	zzGYfX0ndZBo4TsNbw27ImAMRjqar = nbOFVEDkpT4BIR7Qq82yPmHeJU.join(uvOaDl7f60HCwBiVKzes24 for uvOaDl7f60HCwBiVKzes24 in OT2twr6bkIVevaGfSPM1 if uvOaDl7f60HCwBiVKzes24 not in '\/":*?<>|'+aiRHWcOtjhszqmMC7DePT1y)
	return zzGYfX0ndZBo4TsNbw27ImAMRjqar
def NtZWe3LpRgnl29Vw(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c):
	gJv8eI2iVF90uCLSoyNGDHfmc = ScntgdOZCY74vNpXeW5jh8i.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,ScntgdOZCY74vNpXeW5jh8i.S)
	if gJv8eI2iVF90uCLSoyNGDHfmc:
		dfJmvYLH3tGOylK6VRa8BQNsxWcP,OaozYR4MKchZs6efSb = gJv8eI2iVF90uCLSoyNGDHfmc[0]
		dfJmvYLH3tGOylK6VRa8BQNsxWcP = ScntgdOZCY74vNpXeW5jh8i.findall("=[\r\n\s\t]+'(.*?)';", dfJmvYLH3tGOylK6VRa8BQNsxWcP, ScntgdOZCY74vNpXeW5jh8i.S)[0]
		if dfJmvYLH3tGOylK6VRa8BQNsxWcP and OaozYR4MKchZs6efSb:
			wwzO6qdHLVrfA82QyRkv9 = dfJmvYLH3tGOylK6VRa8BQNsxWcP.replace("'",nbOFVEDkpT4BIR7Qq82yPmHeJU).replace("+",nbOFVEDkpT4BIR7Qq82yPmHeJU).replace("\n",nbOFVEDkpT4BIR7Qq82yPmHeJU).replace("\r",nbOFVEDkpT4BIR7Qq82yPmHeJU)
			EfYwth2C5KSyz1j4XMicFqkPmVv = wwzO6qdHLVrfA82QyRkv9.split('.')
			jwQ1lvmx6hFoet7N5OViJITA4GdZ0c = nbOFVEDkpT4BIR7Qq82yPmHeJU
			for yycM74dNnhlmfwp in EfYwth2C5KSyz1j4XMicFqkPmVv:
				uoGFWl0gmDhMCef5x = Y7goyGlxwNaP1XcWU6e.b64decode(yycM74dNnhlmfwp+'==').decode(zSafwK0sDXdMN5JReniIQmrZxp)
				ggM1YtvKmcr0dHf4SVAjNxb3eoD = ScntgdOZCY74vNpXeW5jh8i.findall('\d+', uoGFWl0gmDhMCef5x, ScntgdOZCY74vNpXeW5jh8i.S)
				if ggM1YtvKmcr0dHf4SVAjNxb3eoD:
					powvfOjIQRYehkz = int(ggM1YtvKmcr0dHf4SVAjNxb3eoD[0])
					powvfOjIQRYehkz += int(OaozYR4MKchZs6efSb)
					jwQ1lvmx6hFoet7N5OViJITA4GdZ0c = jwQ1lvmx6hFoet7N5OViJITA4GdZ0c + chr(powvfOjIQRYehkz)
			if IZhXMprxvAHqBEFkg0: jwQ1lvmx6hFoet7N5OViJITA4GdZ0c = jwQ1lvmx6hFoet7N5OViJITA4GdZ0c.encode('iso-8859-1').decode(zSafwK0sDXdMN5JReniIQmrZxp)
	return jwQ1lvmx6hFoet7N5OViJITA4GdZ0c
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'YOUTUBE'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_YUT_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
def n1zxUlcAgR(mode,url,text,type,ohpwd6UumaecE3IWV8lAv0):
	if	 mode==140: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==143: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url,type)
	elif mode==144: bPFto2wZdNYrClgBIEv60DJAzu = KwinXTzJv1N8yghA9UbI0HueGqa7R(url,text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==145: bPFto2wZdNYrClgBIEv60DJAzu = wRSTtYUveNo(url)
	elif mode==146: bPFto2wZdNYrClgBIEv60DJAzu = u1oz8WdIg3pBxvG7sw(url)
	elif mode==147: bPFto2wZdNYrClgBIEv60DJAzu = zzfe089Mt5kqul2C()
	elif mode==148: bPFto2wZdNYrClgBIEv60DJAzu = JfljCxUqmu()
	elif mode==149: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,149,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+'_YTC_'+'مواقع اختارها المبرمج',nbOFVEDkpT4BIR7Qq82yPmHeJU,290)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مواقع اختارها يوتيوب',zKREXyTHfVSNL8ZFYs+'/feed/guide_builder',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الصفحة الرئيسية',zKREXyTHfVSNL8ZFYs,144,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المحتوى الرائج',zKREXyTHfVSNL8ZFYs+'/feed/trending',146)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: قنوات عربية',nbOFVEDkpT4BIR7Qq82yPmHeJU,147)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: قنوات أجنبية',nbOFVEDkpT4BIR7Qq82yPmHeJU,148)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: افلام عربية',zKREXyTHfVSNL8ZFYs+'/results?search_query=فيلم',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: افلام اجنبية',zKREXyTHfVSNL8ZFYs+'/results?search_query=movie',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسرحيات عربية',zKREXyTHfVSNL8ZFYs+'/results?search_query=مسرحية',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسلسلات عربية',zKREXyTHfVSNL8ZFYs+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسلسلات اجنبية',zKREXyTHfVSNL8ZFYs+'/results?search_query=series&sp=EgIQAw==',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسلسلات كارتون',zKREXyTHfVSNL8ZFYs+'/results?search_query=كارتون&sp=EgIQAw==',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: خطبة المرجعية',zKREXyTHfVSNL8ZFYs+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def zzfe089Mt5kqul2C():
	KwinXTzJv1N8yghA9UbI0HueGqa7R(zKREXyTHfVSNL8ZFYs+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JfljCxUqmu():
	KwinXTzJv1N8yghA9UbI0HueGqa7R(zKREXyTHfVSNL8ZFYs+'/results?search_query=tv&sp=EgJAAQ==')
	return
def AOk1T6KwciHrWU2MYJzZnEN(url,type):
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY([url],QSJFrwB3dMiyH2mTPKD9a,type,url)
	return
def u1oz8WdIg3pBxvG7sw(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V,yWESdJ2nUj31M8ONktxl4,data = kkNFuBV2aTgK(url)
	x7zfJk13cZqV = yWESdJ2nUj31M8ONktxl4['contents']['twoColumnBrowseResultsRenderer']['tabs']
	for HT4fGXqv8hEcKsJ in range(len(x7zfJk13cZqV)):
		xB2lOZNsPvFQDC4gMz = x7zfJk13cZqV[HT4fGXqv8hEcKsJ]
		eygV2sIhK6ZMdk1z4EGltH(xB2lOZNsPvFQDC4gMz,url,str(HT4fGXqv8hEcKsJ))
	mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[0]['tabRenderer']['content']['sectionListRenderer']['contents']
	u5cjW2qyX6rJpmVoQlLvOx = 0
	for HT4fGXqv8hEcKsJ in range(len(mNP1Efby0FIURSXC4l7ODwuiA3ojZ)):
		xB2lOZNsPvFQDC4gMz = mNP1Efby0FIURSXC4l7ODwuiA3ojZ[HT4fGXqv8hEcKsJ]['itemSectionRenderer']['contents'][0]
		if list(xB2lOZNsPvFQDC4gMz['shelfRenderer']['content'].keys())[0]=='horizontalListRenderer': continue
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty = Xi1MKn8wOuV5RA6jc2pf7gbdY9z(xB2lOZNsPvFQDC4gMz)
		if not title:
			u5cjW2qyX6rJpmVoQlLvOx += 1
			title = 'فيديوهات رائجة '+str(u5cjW2qyX6rJpmVoQlLvOx)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,144,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(HT4fGXqv8hEcKsJ))
	key = ScntgdOZCY74vNpXeW5jh8i.findall('"innertubeApiKey":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = 'https://www.youtube.com/youtubei/v1/guide?key='+key[0]
	UTvsQb4HpCP3Aeo2wDZG7X5V,yWESdJ2nUj31M8ONktxl4,J27qXeRCpsgkEoT9Q0GYS6ct = kkNFuBV2aTgK(plSscrVjkRviPwm)
	for E8gJu2VxcoqW in range(3,4):
		x7zfJk13cZqV = yWESdJ2nUj31M8ONktxl4['items'][E8gJu2VxcoqW]['guideSectionRenderer']['items']
		for HT4fGXqv8hEcKsJ in range(len(x7zfJk13cZqV)):
			xB2lOZNsPvFQDC4gMz = x7zfJk13cZqV[HT4fGXqv8hEcKsJ]
			if 'YouTube Premium' in str(xB2lOZNsPvFQDC4gMz): continue
			eygV2sIhK6ZMdk1z4EGltH(xB2lOZNsPvFQDC4gMz)
	return
def KwinXTzJv1N8yghA9UbI0HueGqa7R(url,data=nbOFVEDkpT4BIR7Qq82yPmHeJU,index=0):
	global llnG7jiQBYKhAeovbT
	if not data: data = llnG7jiQBYKhAeovbT.getSetting('av.youtube.data')
	if index: index = int(index)
	else: index = 0
	data = data.replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	UTvsQb4HpCP3Aeo2wDZG7X5V,yWESdJ2nUj31M8ONktxl4,J27qXeRCpsgkEoT9Q0GYS6ct = kkNFuBV2aTgK(url,data)
	V9vYM03qRyjcN5XIFDd2x4uUZgAlT,gsiDSnEjaJo5LeyBZKhX6 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	G7GhXQ9sRNCw6OnpymLMFcI1ZkU = ScntgdOZCY74vNpXeW5jh8i.findall('"ownerName".*?":"(.*?)".*?"url":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not G7GhXQ9sRNCw6OnpymLMFcI1ZkU: G7GhXQ9sRNCw6OnpymLMFcI1ZkU = ScntgdOZCY74vNpXeW5jh8i.findall('"videoOwner".*?"text":"(.*?)".*?"url":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not G7GhXQ9sRNCw6OnpymLMFcI1ZkU: G7GhXQ9sRNCw6OnpymLMFcI1ZkU = ScntgdOZCY74vNpXeW5jh8i.findall('"channelMetadataRenderer":\{"title":"(.*?)".*?"ownerUrls":\["(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if G7GhXQ9sRNCw6OnpymLMFcI1ZkU:
		V9vYM03qRyjcN5XIFDd2x4uUZgAlT = eMypvI8XqHjYU02anWD9gsSrkt+G7GhXQ9sRNCw6OnpymLMFcI1ZkU[0][0]+c7gxFyUCGm
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G7GhXQ9sRNCw6OnpymLMFcI1ZkU[0][1]
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if 'list=' in url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+V9vYM03qRyjcN5XIFDd2x4uUZgAlT,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144)
	vofnkpAa2IQ79we6Kmjt = ['/search','/videos','/channels','/playlists','/featured','ss=','ctoken=','key=','bp=','shelf_id=']
	llt3PJ0yReVZoS9u7iGzYskBvCNTEa = not any(XPL0O2VkI3w1C8enMaqi in url for XPL0O2VkI3w1C8enMaqi in vofnkpAa2IQ79we6Kmjt)
	if llt3PJ0yReVZoS9u7iGzYskBvCNTEa and V9vYM03qRyjcN5XIFDd2x4uUZgAlT:
		TKgxmZYczq9oPUWni4ak0NM6 = 'البحث'
		HDE69mkhQg2NaFpuUy5JRb = 'قوائم التشغيل'
		CgPhBrkIZpi = 'الفيديوهات'
		LuKM3QHIBwYDmfpRU0xn = 'القنوات'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+V9vYM03qRyjcN5XIFDd2x4uUZgAlT,url,9999)
		if '"title":"بحث"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+TKgxmZYczq9oPUWni4ak0NM6,url,145,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
		if '"title":"قوائم التشغيل"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,url+'/playlists',144)
		if '"title":"الفيديوهات"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+CgPhBrkIZpi,url+'/videos',144)
		if '"title":"القنوات"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+LuKM3QHIBwYDmfpRU0xn,url+'/channels',144)
		if '"title":"Search"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+TKgxmZYczq9oPUWni4ak0NM6,url,145,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
		if '"title":"Playlists"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,url+'/playlists',144)
		if '"title":"Videos"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+CgPhBrkIZpi,url+'/videos',144)
		if '"title":"Channels"' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+LuKM3QHIBwYDmfpRU0xn,url+'/channels',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	if 'search_query' in url:
		x7zfJk13cZqV = yWESdJ2nUj31M8ONktxl4['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']
		ZUErF2MALHw3fbdjORio7cN = 0
		for WoEZvMXa0K2suwgPl in range(len(x7zfJk13cZqV)):
			if 'itemSectionRenderer' in list(x7zfJk13cZqV[WoEZvMXa0K2suwgPl].keys()):
				mGh8noq2gbRIBrF9ZQx0jMYCJLvza = x7zfJk13cZqV[WoEZvMXa0K2suwgPl]['itemSectionRenderer']
				p9JzYBnAtPxg1WHFQ = len(str(mGh8noq2gbRIBrF9ZQx0jMYCJLvza))
				if p9JzYBnAtPxg1WHFQ>ZUErF2MALHw3fbdjORio7cN:
					ZUErF2MALHw3fbdjORio7cN = p9JzYBnAtPxg1WHFQ
					gsiDSnEjaJo5LeyBZKhX6 = mGh8noq2gbRIBrF9ZQx0jMYCJLvza
		if ZUErF2MALHw3fbdjORio7cN==0: return
	elif '&list=' in url or '/search?key=' in url or '/browse?key=' in url or 'ctoken=' in url or '/search' in url or url==zKREXyTHfVSNL8ZFYs:
		SbBfnz637O5kX = []
		SbBfnz637O5kX.append("cc['onResponseReceivedCommands'][0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']")
		SbBfnz637O5kX.append("cc['onResponseReceivedActions'][0]['appendContinuationItemsAction']['continuationItems']")
		SbBfnz637O5kX.append("cc[1]['response']['continuationContents']['sectionListContinuation']")
		SbBfnz637O5kX.append("cc[1]['response']['continuationContents']['gridContinuation']['items']")
		SbBfnz637O5kX.append("cc[1]['response']['continuationContents']['playlistVideoListContinuation']")
		SbBfnz637O5kX.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][-1]['expandableTabRenderer']['content']['sectionListRenderer']")
		SbBfnz637O5kX.append("cc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']")
		SbBfnz637O5kX.append("cc['contents']['twoColumnWatchNextResults']['playlist']['playlist']")
		MME5t97rOBFNRx,gsiDSnEjaJo5LeyBZKhX6 = uMDeVOTQLpZfsUqm(yWESdJ2nUj31M8ONktxl4,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
	if not gsiDSnEjaJo5LeyBZKhX6:
		try:
			x7zfJk13cZqV = yWESdJ2nUj31M8ONktxl4['contents']['twoColumnBrowseResultsRenderer']['tabs']
			wjSstJ9KD8IhAgrzcyiuP = '/videos' in url or '/playlists' in url or '/channels' in url
			H0VPbhrWoYnAX = '"title":"الفيديوهات"' in UTvsQb4HpCP3Aeo2wDZG7X5V or '"title":"قوائم التشغيل"' in UTvsQb4HpCP3Aeo2wDZG7X5V or '"title":"القنوات"' in UTvsQb4HpCP3Aeo2wDZG7X5V
			QQ9u4HCv8gmxV = '"title":"Videos"' in UTvsQb4HpCP3Aeo2wDZG7X5V or '"title":"Playlists"' in UTvsQb4HpCP3Aeo2wDZG7X5V or '"title":"Channels"' in UTvsQb4HpCP3Aeo2wDZG7X5V
			if wjSstJ9KD8IhAgrzcyiuP and (H0VPbhrWoYnAX or QQ9u4HCv8gmxV):
				for HT4fGXqv8hEcKsJ in range(len(x7zfJk13cZqV)):
					if 'tabRenderer' not in list(x7zfJk13cZqV[HT4fGXqv8hEcKsJ].keys()): continue
					mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[HT4fGXqv8hEcKsJ]['tabRenderer']
					try: oQmDSpdY0qHIxt1n3yJT2whE = mNP1Efby0FIURSXC4l7ODwuiA3ojZ['content']['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems'][HT4fGXqv8hEcKsJ]
					except: oQmDSpdY0qHIxt1n3yJT2whE = mNP1Efby0FIURSXC4l7ODwuiA3ojZ
					try: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = oQmDSpdY0qHIxt1n3yJT2whE['endpoint']['commandMetadata']['webCommandMetadata']['url']
					except: continue
					if   '/videos'		in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6	and '/videos'		in url: mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[HT4fGXqv8hEcKsJ] ; break
					elif '/playlists'	in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6	and '/playlists'	in url: mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[HT4fGXqv8hEcKsJ] ; break
					elif '/channels'	in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6	and '/channels'		in url: mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[HT4fGXqv8hEcKsJ] ; break
					else: mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[0]
			elif 'bp=' in url: mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[index]
			else: mNP1Efby0FIURSXC4l7ODwuiA3ojZ = x7zfJk13cZqV[0]
			gsiDSnEjaJo5LeyBZKhX6 = mNP1Efby0FIURSXC4l7ODwuiA3ojZ['tabRenderer']['content']
		except: pass
	if not gsiDSnEjaJo5LeyBZKhX6: return
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['shelfRenderer']['cards']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][int(index)]['richSectionRenderer']['content']")
	if 'view=' not in url: SbBfnz637O5kX.append("ff['sectionListRenderer']['subMenu']['channelSubMenuRenderer']['contentTypeSubMenuItems']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']['contents']")
	SbBfnz637O5kX.append("ff['sectionListRenderer']")
	SbBfnz637O5kX.append("ff['richGridRenderer']['contents']")
	SbBfnz637O5kX.append("ff['contents']")
	SbBfnz637O5kX.append("ff")
	jmS4TUpYEiL0lVqHu75f3 = YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'كل قوائم التشغيل')
	TIzpmeGDYf = YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'كل الفيديوهات')
	IoGVAMpf4E0SdUNXD2T7K5cm6z = YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'كل القنوات')
	umSy5WK1Uco3TMV = [jmS4TUpYEiL0lVqHu75f3,TIzpmeGDYf,IoGVAMpf4E0SdUNXD2T7K5cm6z,'All playlists','All videos','All channels']
	lWqhPpAwb03QJznL,oQmDSpdY0qHIxt1n3yJT2whE = uMDeVOTQLpZfsUqm(gsiDSnEjaJo5LeyBZKhX6,index,SbBfnz637O5kX)
	if 'list' in str(type(oQmDSpdY0qHIxt1n3yJT2whE)) and any(XPL0O2VkI3w1C8enMaqi in str(oQmDSpdY0qHIxt1n3yJT2whE[0]) for XPL0O2VkI3w1C8enMaqi in umSy5WK1Uco3TMV): del oQmDSpdY0qHIxt1n3yJT2whE[0]
	for hHRBjdtPMwWJ5caVZ in range(len(oQmDSpdY0qHIxt1n3yJT2whE)):
		SbBfnz637O5kX = []
		SbBfnz637O5kX.append("gg[index2]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
		SbBfnz637O5kX.append("gg[index2]['itemSectionRenderer']['header']")
		SbBfnz637O5kX.append("gg[index2]['horizontalCardListRenderer']['header']")
		SbBfnz637O5kX.append("gg[index2]['itemSectionRenderer']['contents'][0]")
		SbBfnz637O5kX.append("gg[index2]['richSectionRenderer']['content']")
		SbBfnz637O5kX.append("gg[index2]['richItemRenderer']['content']")
		SbBfnz637O5kX.append("gg[index2]['gameCardRenderer']['game']")
		SbBfnz637O5kX.append("gg[index2]")
		MME5t97rOBFNRx,xB2lOZNsPvFQDC4gMz = uMDeVOTQLpZfsUqm(oQmDSpdY0qHIxt1n3yJT2whE,hHRBjdtPMwWJ5caVZ,SbBfnz637O5kX)
		eygV2sIhK6ZMdk1z4EGltH(xB2lOZNsPvFQDC4gMz,url,str(hHRBjdtPMwWJ5caVZ))
		if MME5t97rOBFNRx=='4':
			try:
				FRoYV7yMCivWQTmZ9wOfJB3Dj2gA = xB2lOZNsPvFQDC4gMz['shelfRenderer']['content']['horizontalMovieListRenderer']['items']
				for Cr2oVlJOMFRyekdZTWX4fL in range(len(FRoYV7yMCivWQTmZ9wOfJB3Dj2gA)):
					LilorgIj7wn8BuUvtcTf = FRoYV7yMCivWQTmZ9wOfJB3Dj2gA[Cr2oVlJOMFRyekdZTWX4fL]
					eygV2sIhK6ZMdk1z4EGltH(LilorgIj7wn8BuUvtcTf)
			except: pass
	ii2tNgwPc0CZ6Lyh4A3fT = False
	if 'view=' not in url and lWqhPpAwb03QJznL=='8': ii2tNgwPc0CZ6Lyh4A3fT = True
	if ':::' in J27qXeRCpsgkEoT9Q0GYS6ct: mRJf2ElN8AYHIXCskSUruxgjFc,key,gWd2iwc5MPZyXvOj1pTtN,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,ffiueHIMq6oQxRpyO1ShacVGL4Pg,eDv42iKLNCb5uoA07wHfW = J27qXeRCpsgkEoT9Q0GYS6ct.split(':::')
	else: mRJf2ElN8AYHIXCskSUruxgjFc,key,gWd2iwc5MPZyXvOj1pTtN,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,ffiueHIMq6oQxRpyO1ShacVGL4Pg,eDv42iKLNCb5uoA07wHfW = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	plSscrVjkRviPwm,M2RDC4XTQxmqHJ8cWNbA = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if LvJuOzMqk6WlP971eoGpUQ8:
		RJn2yvc3w1POZ8d = str(LvJuOzMqk6WlP971eoGpUQ8[-1][1])
		if   TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'CHNL' in RJn2yvc3w1POZ8d: M2RDC4XTQxmqHJ8cWNbA = 'CHANNELS'
		elif TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'USER' in RJn2yvc3w1POZ8d: M2RDC4XTQxmqHJ8cWNbA = 'CHANNELS'
		elif TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'LIST' in RJn2yvc3w1POZ8d: M2RDC4XTQxmqHJ8cWNbA = 'PLAYLISTS'
	if '"continuations"' in UTvsQb4HpCP3Aeo2wDZG7X5V and '&list=' not in url and not ii2tNgwPc0CZ6Lyh4A3fT and 'shelf_id' not in url:
		plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/browse_ajax?ctoken='+gWd2iwc5MPZyXvOj1pTtN
	elif '"token"' in UTvsQb4HpCP3Aeo2wDZG7X5V and 'bp=' not in url and 'search_query' in url or 'search?key=' in url:
		plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/youtubei/v1/search?key='+key
	elif '"token"' in UTvsQb4HpCP3Aeo2wDZG7X5V and 'bp=' not in url:
		plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/youtubei/v1/browse?key='+key
	if plSscrVjkRviPwm: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة أخرى',plSscrVjkRviPwm,144,M2RDC4XTQxmqHJ8cWNbA,nbOFVEDkpT4BIR7Qq82yPmHeJU,J27qXeRCpsgkEoT9Q0GYS6ct)
	return
def uMDeVOTQLpZfsUqm(HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,YlkdsaZ8W3juChR0E56GQobcT):
	yWESdJ2nUj31M8ONktxl4 = HYxdW1nBCSGI
	gsiDSnEjaJo5LeyBZKhX6,index = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	oQmDSpdY0qHIxt1n3yJT2whE,hHRBjdtPMwWJ5caVZ = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	xB2lOZNsPvFQDC4gMz,A8eRO4d06vxVDqLEGH7 = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	count = len(YlkdsaZ8W3juChR0E56GQobcT)
	for HT4fGXqv8hEcKsJ in range(count):
		try:
			bbKnskEMiJed9cOCDh1f = eval(YlkdsaZ8W3juChR0E56GQobcT[HT4fGXqv8hEcKsJ])
			return str(HT4fGXqv8hEcKsJ+1),bbKnskEMiJed9cOCDh1f
		except: pass
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
def Xi1MKn8wOuV5RA6jc2pf7gbdY9z(xB2lOZNsPvFQDC4gMz):
	try: WbRD4Px5tfheHCOwUm1EaFc8szvL = list(xB2lOZNsPvFQDC4gMz.keys())[0]
	except: return False,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty = False,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	A8eRO4d06vxVDqLEGH7 = xB2lOZNsPvFQDC4gMz[WbRD4Px5tfheHCOwUm1EaFc8szvL]
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("render['unplayableText']['simpleText']")
	SbBfnz637O5kX.append("render['formattedTitle']['simpleText']")
	SbBfnz637O5kX.append("render['title']['simpleText']")
	SbBfnz637O5kX.append("render['title']['runs'][0]['text']")
	SbBfnz637O5kX.append("render['text']['simpleText']")
	SbBfnz637O5kX.append("render['text']['runs'][0]['text']")
	SbBfnz637O5kX.append("render['title']")
	SbBfnz637O5kX.append("item['title']")
	MME5t97rOBFNRx,title = uMDeVOTQLpZfsUqm(xB2lOZNsPvFQDC4gMz,A8eRO4d06vxVDqLEGH7,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("render['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("render['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("render['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	MME5t97rOBFNRx,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = uMDeVOTQLpZfsUqm(xB2lOZNsPvFQDC4gMz,A8eRO4d06vxVDqLEGH7,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("render['thumbnail']['thumbnails'][0]['url']")
	SbBfnz637O5kX.append("render['thumbnails'][0]['thumbnails'][0]['url']")
	MME5t97rOBFNRx,X79kphTKa1xLP = uMDeVOTQLpZfsUqm(xB2lOZNsPvFQDC4gMz,A8eRO4d06vxVDqLEGH7,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("render['videoCount']")
	SbBfnz637O5kX.append("render['videoCountText']['runs'][0]['text']")
	SbBfnz637O5kX.append("render['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	MME5t97rOBFNRx,count = uMDeVOTQLpZfsUqm(xB2lOZNsPvFQDC4gMz,A8eRO4d06vxVDqLEGH7,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("render['lengthText']['simpleText']")
	SbBfnz637O5kX.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	SbBfnz637O5kX.append("render['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	MME5t97rOBFNRx,H07WdckxAoZF1fn4LNMOTP65eEtr = uMDeVOTQLpZfsUqm(xB2lOZNsPvFQDC4gMz,A8eRO4d06vxVDqLEGH7,SbBfnz637O5kX)
	if 'LIVE' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf = nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE:  '
	if 'مباشر' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf = nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE:  '
	if 'badges' in list(A8eRO4d06vxVDqLEGH7.keys()):
		yyizNFhWGqgbrufA5UtLDZCa = str(A8eRO4d06vxVDqLEGH7['badges'])
		if 'Free with Ads' in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$:'
		if 'LIVE NOW' in yyizNFhWGqgbrufA5UtLDZCa: YhPe4rVdaFqX1MDRKf = 'LIVE:  '
		if 'Buy' in yyizNFhWGqgbrufA5UtLDZCa or 'Rent' in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$$:'
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'مباشر') in yyizNFhWGqgbrufA5UtLDZCa: YhPe4rVdaFqX1MDRKf = 'LIVE:  '
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'شراء') in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$$:'
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'استئجار') in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$$:'
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'إعلانات') in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$:'
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	X79kphTKa1xLP = X79kphTKa1xLP.split('?')[0]
	if  X79kphTKa1xLP and 'http' not in X79kphTKa1xLP: X79kphTKa1xLP = 'https:'+X79kphTKa1xLP
	title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
	if CoGin4IdJQKeq7k2jLrxMty: title = CoGin4IdJQKeq7k2jLrxMty+BhmzEC6OGD7FXZig9Tp5A+title
	H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.replace(',',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	count = count.replace(',',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	count = ScntgdOZCY74vNpXeW5jh8i.findall('\d+',count)
	if count: count = count[0]
	else: count = nbOFVEDkpT4BIR7Qq82yPmHeJU
	return True,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty
def eygV2sIhK6ZMdk1z4EGltH(xB2lOZNsPvFQDC4gMz,url=nbOFVEDkpT4BIR7Qq82yPmHeJU,index=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty = Xi1MKn8wOuV5RA6jc2pf7gbdY9z(xB2lOZNsPvFQDC4gMz)
	if not aBStCuH2RG4fOZJp19XAbKkI5xe7Nv: return
	elif 'continuationItemRenderer' in str(xB2lOZNsPvFQDC4gMz): return
	elif 'searchPyvRenderer' in str(xB2lOZNsPvFQDC4gMz): return
	elif not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'search_query' in url: return
	elif title and not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and ('search_query' in url or 'horizontalMovieListRenderer' in str(xB2lOZNsPvFQDC4gMz) or url==zKREXyTHfVSNL8ZFYs):
		title = '=== '+title+' ==='
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	elif title and 'messageRenderer' in str(xB2lOZNsPvFQDC4gMz):
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	elif '/feed/trending' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,index)
	elif not title: return
	elif YhPe4rVdaFqX1MDRKf: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+YhPe4rVdaFqX1MDRKf+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,143,X79kphTKa1xLP)
	elif 'watch?v=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/shorts/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		if '&list=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'index=' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			L72HwzvcCsoeGm5i4T08r13QPdfu9K = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&list=',1)[1]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/playlist?list='+L72HwzvcCsoeGm5i4T08r13QPdfu9K
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'LIST'+count+':  '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP)
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&list=',1)[0]
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,143,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr)
	else:
		type = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
		elif not any(XPL0O2VkI3w1C8enMaqi in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 for XPL0O2VkI3w1C8enMaqi in ['/videos','/playlists','/channels','/featured','ss=','bp=']):
			if '/channel/'	in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/c/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: type = 'CHNL'+count+':  '
			if '/user/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: type = 'USER'+count+':  '
			index,pWfkGjRBP6cz = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+type+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,index)
	return
def kkNFuBV2aTgK(url,data=nbOFVEDkpT4BIR7Qq82yPmHeJU,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	global llnG7jiQBYKhAeovbT
	if not data: data = llnG7jiQBYKhAeovbT.getSetting('av.youtube.data')
	if s0tfc7T2hwBM==nbOFVEDkpT4BIR7Qq82yPmHeJU: s0tfc7T2hwBM = 'ytInitialData'
	VLs4zv8ycboXT0UG7rk2fAj = MdwGcQOsmlV6vKI73THrUY4()
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'User-Agent':VLs4zv8ycboXT0UG7rk2fAj,'Cookie':'PREF=hl=ar'}
	if ':::' in data: mRJf2ElN8AYHIXCskSUruxgjFc,key,gWd2iwc5MPZyXvOj1pTtN,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,ffiueHIMq6oQxRpyO1ShacVGL4Pg,eDv42iKLNCb5uoA07wHfW = data.split(':::')
	else: mRJf2ElN8AYHIXCskSUruxgjFc,key,gWd2iwc5MPZyXvOj1pTtN,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,ffiueHIMq6oQxRpyO1ShacVGL4Pg,eDv42iKLNCb5uoA07wHfW = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 'guide?key=' in url:
		J27qXeRCpsgkEoT9Q0GYS6ct = {}
		J27qXeRCpsgkEoT9Q0GYS6ct['context'] = {"client":{"hl":"ar","clientName":"WEB","clientVersion":Rc4dwqYitn9msyAEuokSKf5HrUTGDv}}
		J27qXeRCpsgkEoT9Q0GYS6ct = str(J27qXeRCpsgkEoT9Q0GYS6ct)
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',url,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif 'key=' in url and mRJf2ElN8AYHIXCskSUruxgjFc:
		J27qXeRCpsgkEoT9Q0GYS6ct = {'continuation':ffiueHIMq6oQxRpyO1ShacVGL4Pg}
		J27qXeRCpsgkEoT9Q0GYS6ct['context'] = {"client":{"visitorData":mRJf2ElN8AYHIXCskSUruxgjFc,"clientName":"WEB","clientVersion":Rc4dwqYitn9msyAEuokSKf5HrUTGDv}}
		J27qXeRCpsgkEoT9Q0GYS6ct = str(J27qXeRCpsgkEoT9Q0GYS6ct)
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',url,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,True,'YOUTUBE-GET_PAGE_DATA-2nd')
	elif 'ctoken=' in url and eDv42iKLNCb5uoA07wHfW:
		GcYwHSWoQ0Nq8KFfJDdvujZryM.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':Rc4dwqYitn9msyAEuokSKf5HrUTGDv})
		GcYwHSWoQ0Nq8KFfJDdvujZryM.update({'Cookie':'VISITOR_INFO1_LIVE='+eDv42iKLNCb5uoA07wHfW})
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'YOUTUBE-GET_PAGE_DATA-3rd')
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'YOUTUBE-GET_PAGE_DATA-4th')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall('"innertubeApiKey".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if DWeKu2Gsi84PbUEfhMwVNjloqg: key = DWeKu2Gsi84PbUEfhMwVNjloqg[0]
	DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall('"cver".*?"value".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if DWeKu2Gsi84PbUEfhMwVNjloqg: Rc4dwqYitn9msyAEuokSKf5HrUTGDv = DWeKu2Gsi84PbUEfhMwVNjloqg[0]
	DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall('"token".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if DWeKu2Gsi84PbUEfhMwVNjloqg: ffiueHIMq6oQxRpyO1ShacVGL4Pg = DWeKu2Gsi84PbUEfhMwVNjloqg[0]
	DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall('"visitorData".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if DWeKu2Gsi84PbUEfhMwVNjloqg: mRJf2ElN8AYHIXCskSUruxgjFc = DWeKu2Gsi84PbUEfhMwVNjloqg[0]
	DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall('"continuation".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if DWeKu2Gsi84PbUEfhMwVNjloqg: gWd2iwc5MPZyXvOj1pTtN = DWeKu2Gsi84PbUEfhMwVNjloqg[0]
	cookies = cnPhVmgFxA.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): eDv42iKLNCb5uoA07wHfW = cookies['VISITOR_INFO1_LIVE']
	data = mRJf2ElN8AYHIXCskSUruxgjFc+':::'+key+':::'+gWd2iwc5MPZyXvOj1pTtN+':::'+Rc4dwqYitn9msyAEuokSKf5HrUTGDv+':::'+ffiueHIMq6oQxRpyO1ShacVGL4Pg+':::'+eDv42iKLNCb5uoA07wHfW
	if s0tfc7T2hwBM=='ytInitialData' and 'ytInitialData' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		lSU9XknmAEaZbTWwFBOd = ScntgdOZCY74vNpXeW5jh8i.findall('window\["ytInitialData"\] = ({.*?});',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not lSU9XknmAEaZbTWwFBOd: lSU9XknmAEaZbTWwFBOd = ScntgdOZCY74vNpXeW5jh8i.findall('var ytInitialData = ({.*?});',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		NNxwchK4sgA3aMJilkvqoSL8 = dr1zfnatJxRHSF48jh0eODm5bGu('str',lSU9XknmAEaZbTWwFBOd[0])
	elif s0tfc7T2hwBM=='ytInitialGuideData' and 'ytInitialGuideData' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		lSU9XknmAEaZbTWwFBOd = ScntgdOZCY74vNpXeW5jh8i.findall('var ytInitialGuideData = ({.*?});',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		NNxwchK4sgA3aMJilkvqoSL8 = dr1zfnatJxRHSF48jh0eODm5bGu('str',lSU9XknmAEaZbTWwFBOd[0])
	elif '</script>' not in UTvsQb4HpCP3Aeo2wDZG7X5V: NNxwchK4sgA3aMJilkvqoSL8 = dr1zfnatJxRHSF48jh0eODm5bGu('str',UTvsQb4HpCP3Aeo2wDZG7X5V)
	else: NNxwchK4sgA3aMJilkvqoSL8 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	llnG7jiQBYKhAeovbT.setSetting('av.youtube.data',data)
	return UTvsQb4HpCP3Aeo2wDZG7X5V,NNxwchK4sgA3aMJilkvqoSL8,data
def wRSTtYUveNo(url):
	search = dR75Vq2gprfHmUcNhG()
	if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	plSscrVjkRviPwm = url+'/search?query='+search
	KwinXTzJv1N8yghA9UbI0HueGqa7R(plSscrVjkRviPwm)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in YE1hqa60dGTRDZ8NVBM: DXl4MTxz2qmPKjcIdtF1QhJ3f = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in YE1hqa60dGTRDZ8NVBM: DXl4MTxz2qmPKjcIdtF1QhJ3f = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in YE1hqa60dGTRDZ8NVBM: DXl4MTxz2qmPKjcIdtF1QhJ3f = '&sp=EgIQAg%253D%253D'
		zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm+DXl4MTxz2qmPKjcIdtF1QhJ3f
	else:
		K0V6AHEvXReQN7gWt,wznIbY9hAdH3JZ5xUcK78fTP,HDE69mkhQg2NaFpuUy5JRb = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
		BBnuEtgQbG6F8PXDsyf = ['بدون ترتيب','ترتيب حسب مدى الصلة','ترتيب حسب تاريخ التحميل','ترتيب حسب عدد المشاهدات','ترتيب حسب التقييم']
		Ho4YD0TMti9 = [nbOFVEDkpT4BIR7Qq82yPmHeJU,'&sp=CAA%253D','&sp=CAI%253D','&sp=CAM%253D','&sp=CAE%253D']
		s1sB4jyXQcmTU6JG7VA5gZFEx = nnRXQH90qeOtABkJzGr('موقع يوتيوب - اختر الترتيب',BBnuEtgQbG6F8PXDsyf)
		if s1sB4jyXQcmTU6JG7VA5gZFEx == -1: return
		HHCEQhew4TXiqAUg3NtIS = Ho4YD0TMti9[s1sB4jyXQcmTU6JG7VA5gZFEx]
		UTvsQb4HpCP3Aeo2wDZG7X5V,qPR12SideET5Ljab,data = kkNFuBV2aTgK(plSscrVjkRviPwm+HHCEQhew4TXiqAUg3NtIS)
		if qPR12SideET5Ljab:
			Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6 = qPR12SideET5Ljab['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
			for SSCcG1ewzQU in range(len(Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6)):
				group = Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6[SSCcG1ewzQU]['searchFilterGroupRenderer']['filters']
				for YA6iT3jH91EDPxFtg in range(len(group)):
					A8eRO4d06vxVDqLEGH7 = group[YA6iT3jH91EDPxFtg]['searchFilterRenderer']
					if 'navigationEndpoint' in list(A8eRO4d06vxVDqLEGH7.keys()):
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = A8eRO4d06vxVDqLEGH7['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('\u0026','&')
						title = A8eRO4d06vxVDqLEGH7['tooltip']
						title = title.replace('البحث عن ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						if 'إزالة الفلتر' in title: continue
						if 'قائمة تشغيل' in title:
							title = 'جيد للمسلسلات '+title
							HDE69mkhQg2NaFpuUy5JRb = title
							f7Je8XzEqNpgHL9m4OURdAQ1 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
						if 'ترتيب حسب' in title: continue
						title = title.replace('Search for ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						if 'Remove' in title: continue
						if 'Playlist' in title:
							title = 'جيد للمسلسلات '+title
							HDE69mkhQg2NaFpuUy5JRb = title
							f7Je8XzEqNpgHL9m4OURdAQ1 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
						if 'Sort by' in title: continue
						K0V6AHEvXReQN7gWt.append(eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title))
						wznIbY9hAdH3JZ5xUcK78fTP.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if not HDE69mkhQg2NaFpuUy5JRb: v26IUydjlKYgR7w = nbOFVEDkpT4BIR7Qq82yPmHeJU
		else:
			K0V6AHEvXReQN7gWt = ['بدون فلتر',HDE69mkhQg2NaFpuUy5JRb]+K0V6AHEvXReQN7gWt
			wznIbY9hAdH3JZ5xUcK78fTP = [nbOFVEDkpT4BIR7Qq82yPmHeJU,f7Je8XzEqNpgHL9m4OURdAQ1]+wznIbY9hAdH3JZ5xUcK78fTP
			wh762VyY9WNxQkno3qjXI41deZE = nnRXQH90qeOtABkJzGr('موقع يوتيوب - اختر الفلتر',K0V6AHEvXReQN7gWt)
			if wh762VyY9WNxQkno3qjXI41deZE == -1: return
			v26IUydjlKYgR7w = wznIbY9hAdH3JZ5xUcK78fTP[wh762VyY9WNxQkno3qjXI41deZE]
		if v26IUydjlKYgR7w: zb2QIaL7Y4h9g8lSck = zKREXyTHfVSNL8ZFYs+v26IUydjlKYgR7w
		elif HHCEQhew4TXiqAUg3NtIS: zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm+HHCEQhew4TXiqAUg3NtIS
		else: zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm
	KwinXTzJv1N8yghA9UbI0HueGqa7R(zb2QIaL7Y4h9g8lSck)
	return
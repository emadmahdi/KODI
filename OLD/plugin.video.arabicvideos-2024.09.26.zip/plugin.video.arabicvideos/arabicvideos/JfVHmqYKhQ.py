# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'TVFUN'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_TVF_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['بث مباشر']
def n1zxUlcAgR(mode,url,text):
	if   mode==460: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==461: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==462: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==463: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==469: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TVFUN-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,469,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"menu-btn"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<span>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in CZrI4vYju7a: continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,461)
	return
def IGDobAKtj4kPF5V(url,it8kJjp6GIWLOEBfm3zl0H7Qr4ygq=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	items = []
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TVFUN-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="head-title"(.*?)id="footer"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		tWsVFQj47pw0L56rZfg = []
		m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			title = '_MOD_'+title.replace('<br>',S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).strip(S3X6GcaiExOPtb)
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,462,X79kphTKa1xLP)
			elif BBuqr7CwzEIi9UL54n0AVoHXPlp and 'الحلقة' in title:
				title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
				if title not in tWsVFQj47pw0L56rZfg:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,463,X79kphTKa1xLP)
					tWsVFQj47pw0L56rZfg.append(title)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,463,X79kphTKa1xLP)
	if it8kJjp6GIWLOEBfm3zl0H7Qr4ygq!='latest':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('<a href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip(S3X6GcaiExOPtb)
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=="": continue
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,461)
	return
def PXyn8J3WjhRgA(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TVFUN-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="head-title"(.*?)id="footer"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
				title = '_MOD_'+title.replace('<br>',S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).strip(S3X6GcaiExOPtb)
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,462,X79kphTKa1xLP)
		else:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('class="episode.*?href="(.*?)" title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,462)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip(S3X6GcaiExOPtb)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=="": continue
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,463)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	lPpY5fw3tOBcEye91Caun2FQZ = []
	plSscrVjkRviPwm = url.replace('/video/','/watch/')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TVFUN-PLAY-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('VideoServers"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for OwDu7J6kbX9Qhlxid0SqLPZUW43,name in rU02bCJFWZDfVuhtMgBOyQi5P:
			OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43[2:]
			if n7neb9KTv10FcU: OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			OwDu7J6kbX9Qhlxid0SqLPZUW43 = Y7goyGlxwNaP1XcWU6e.b64decode(OwDu7J6kbX9Qhlxid0SqLPZUW43)
			if IZhXMprxvAHqBEFkg0: OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',OwDu7J6kbX9Qhlxid0SqLPZUW43,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				if '//' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in lPpY5fw3tOBcEye91Caun2FQZ:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__watch'
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	if S3X6GcaiExOPtb in search:
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = zKREXyTHfVSNL8ZFYs+'/q/'+search+'/'
	IGDobAKtj4kPF5V(url)
	return
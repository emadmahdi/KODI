# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = tM24jD1gO0(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕࠪো")
def n1zxUlcAgR(EYMmnJAyxV,J1rvN7I8eLXuS54mZ6lnUjg=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if   EYMmnJAyxV==SSvu1CZjTW7FcloNqD(u"࠵೑"): SSxnFXwuQNT(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==cb3rmvAn4wa6lBPz2phOoYqX(u"࠷೒"): pass
	elif EYMmnJAyxV==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠲೓"): IbOgDw5uNE16VosCFnShBl(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==X60YQOADpkHBb31LiR5qUEKfM(u"࠴೔"): Ppr0d5ewGFXL9Z()
	elif EYMmnJAyxV==t4txivgXSUWBOlCakQmNDjf(u"࠶ೕ"): p7yhd4XJcbTZnRSKgC1(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠸ೖ"): gkB3aNoiAj0E5nqem1pdHw8()
	elif EYMmnJAyxV==DJ6ugPjW9bX8I(u"࠺೗"): MMRo1cWwGLKV0aJp()
	elif EYMmnJAyxV==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠼೘"): UAIF0rTwoYbJO9jMVqfhs27mtRCep()
	elif EYMmnJAyxV==UpQ56M0dO1N9xIvVegy(u"࠾೙"): Nbk3dJQsOeK5Y2ExRjWMo()
	elif EYMmnJAyxV==flDSRbv57PnV3(u"࠹೚"): CQpWYzAoaNZE9Tq7mDFtnw()
	elif EYMmnJAyxV==fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠲࠷࠳೛"): qq9b4oeBMTfUlEk2wNyzt()
	elif EYMmnJAyxV==IINBvuxkCSJrO1Q0UyngdLi(u"࠳࠸࠵೜"): Loigwze48U1V2AcspRGfJb7E()
	elif EYMmnJAyxV==z3sIGH8jmLYg(u"࠴࠹࠷ೝ"): ee6Bl0wZGrv()
	elif EYMmnJAyxV==QlTuvPbSpnjygBVW(u"࠵࠺࠹ೞ"): StWOzhfK24yb8dgCRUuo9qsc()
	elif EYMmnJAyxV==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠶࠻࠴೟"): SBeVKC0dk3nx49oHhbaAMR2jEwg6W()
	elif EYMmnJAyxV==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠷࠵࠶ೠ"): MMF6AXf0OHIKZVc3iWCLrRBp8TSldy()
	elif EYMmnJAyxV==bnI4kmPtrW7yFEhljXOCq9(u"࠱࠶࠸ೡ"): XXozK8CcxhYS3DlNguHVbPLQ()
	elif EYMmnJAyxV==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠲࠷࠺ೢ"): yURQG0os7Cz()
	elif EYMmnJAyxV==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠳࠸࠼ೣ"): RRYSPftNdOaMA291xjyK0XcoTJnpg()
	elif EYMmnJAyxV==SSvu1CZjTW7FcloNqD(u"࠴࠹࠾೤"): QK5Pg07pibDxqZS1IY2GyVk3Re(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠵࠼࠶೥"): isrhUHyRexIE2()
	elif EYMmnJAyxV==X60YQOADpkHBb31LiR5qUEKfM(u"࠶࠽࠱೦"): Fh13bDf9RwJ78eHnLYs5BKiTONz()
	elif EYMmnJAyxV==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠷࠷࠳೧"): r9aD2vZsWo3bMe([J1rvN7I8eLXuS54mZ6lnUjg],Ag9l6cw3EBqP8HsQuGMizfOtr4,Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
	elif EYMmnJAyxV==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠱࠸࠵೨"): tjoDTklcueMPnHqI9yg(SSvu1CZjTW7FcloNqD(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩৌ"),Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠲࠹࠷೩"): tjoDTklcueMPnHqI9yg(l4DS8mnEjHhFMZ5YOe(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ্࠭"),Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==qrjy8LuKVPNYdbSvzh(u"࠳࠺࠹೪"): ZDtGBKnj4k2pshl()
	elif EYMmnJAyxV==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠴࠻࠻೫"): RoJNZAHlUE4mi3ygrs8LweTaIj2dbC()
	elif EYMmnJAyxV==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠵࠼࠽೬"): euOGUICqTJP0(X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨৎ"))
	elif EYMmnJAyxV==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠶࠽࠸೭"): euOGUICqTJP0(X1mRwt2YJKgCLu9a67(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬ৏"))
	elif EYMmnJAyxV==fgv5U2eRVaQqSiuGD(u"࠷࠷࠺೮"): euOGUICqTJP0(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠭৐"))
	elif EYMmnJAyxV==cb3rmvAn4wa6lBPz2phOoYqX(u"࠱࠺࠲೯"): VfhJAnDWzB6u2ysbR()
	elif EYMmnJAyxV==bnI4kmPtrW7yFEhljXOCq9(u"࠲࠻࠴೰"): JHpfXDNhv7ZVQg12EIRayx5u()
	elif EYMmnJAyxV==cb3rmvAn4wa6lBPz2phOoYqX(u"࠳࠼࠶ೱ"): pCs27GybvnheKlct()
	elif EYMmnJAyxV==UpQ56M0dO1N9xIvVegy(u"࠴࠽࠸ೲ"): tQjFJdYIRHUGa1()
	elif EYMmnJAyxV==l4DS8mnEjHhFMZ5YOe(u"࠵࠾࠺ೳ"): dKNJ5y9ORx6scLXMTzWu0a3w8()
	elif EYMmnJAyxV==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠶࠿࠵೴"): Rjf3hV67FDG0St()
	elif EYMmnJAyxV==flDSRbv57PnV3(u"࠷࠹࠷೵"): EHgGjsScrXDMZ2ebCNhJld()
	elif EYMmnJAyxV==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠱࠺࠹೶"): jozp3PBF9JGcUXNrgRKds()
	elif EYMmnJAyxV==SSvu1CZjTW7FcloNqD(u"࠲࠻࠻೷"): R6elFSraws0yOvHCuBXNoGEzk1()
	elif EYMmnJAyxV==bYyKEjIuGQzoq3AR1(u"࠳࠼࠽೸"): K8rm4kDsxOeFwZVhHlI2gT()
	elif EYMmnJAyxV==DJ6ugPjW9bX8I(u"࠶࠸࠵೹"): Z8rqlOhW7vg3BFp60jmsI(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==X1mRwt2YJKgCLu9a67(u"࠷࠹࠷೺"): KKFMTDoB7R2fm38nuJbLCq9x4AYp1()
	elif EYMmnJAyxV==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠸࠺࠲೻"): VlbCd7LswvXFxaHGZYT53()
	elif EYMmnJAyxV==t4txivgXSUWBOlCakQmNDjf(u"࠹࠴࠴೼"): BEsthiXuaUe941c()
	elif EYMmnJAyxV==bnI4kmPtrW7yFEhljXOCq9(u"࠳࠵࠶೽"): S3pFKw0RlMXYBiIVhG7Z(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==DJ6ugPjW9bX8I(u"࠴࠶࠸೾"): OM2C9seoTaYPIbcByt8xVrq()
	elif EYMmnJAyxV==I3cxjYaHhsrM7T4UX26klN(u"࠵࠷࠺೿"): UbxR3AHIEPcdBS(SmbNGskjMx)
	elif EYMmnJAyxV==I3cxjYaHhsrM7T4UX26klN(u"࠶࠸࠼ഀ"): mmhRocLej7aHKt4QYIyJNp9Bk(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==t4txivgXSUWBOlCakQmNDjf(u"࠷࠹࠾ഁ"): wHMVpK0IPYiFURvrhxLJ19NOus()
	elif EYMmnJAyxV==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠸࠺࠹ം"): DDLHBPM3dqltVvkc2sYNWFXE07eAI(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬ৑"),Ag9l6cw3EBqP8HsQuGMizfOtr4,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠻࠰࠱ഃ"): P3yilC4fLoJ2Tw()
	elif EYMmnJAyxV==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠵࠱࠳ഄ"): qjkhtZBR6UefrlE4Pm0D()
	elif EYMmnJAyxV==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠶࠲࠵അ"): s8j7mtrbOgdlq9eNT2vSnRBcVpP6()
	elif EYMmnJAyxV==YayJj10OGl(u"࠷࠳࠷ആ"): n4spMr2z1Sf7JwDT5x6ePqbgZG(TTrFaqDzxJOsh90UHIZ5)
	elif EYMmnJAyxV==tM24jD1gO0(u"࠸࠴࠹ഇ"): n4spMr2z1Sf7JwDT5x6ePqbgZG(g8FzaRfU7Zx9HeSBNtJ)
	elif EYMmnJAyxV==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠹࠵࠻ഈ"): FCbPGwmIZrD1jAHUsuzKlt9oS()
	elif EYMmnJAyxV==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠺࠶࠶ഉ"): kYaRIGV5T7Zvfbq3WKpmQwJiBg(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠻࠰࠸ഊ"): FSruUQxdLDBTgboGe()
	elif EYMmnJAyxV==QlTuvPbSpnjygBVW(u"࠵࠱࠺ഋ"): snNeITzcWKPv9JH1()
	elif EYMmnJAyxV==YayJj10OGl(u"࠶࠲࠼ഌ"): bLSuE4KXWYVJAH9snldmr3x()
	elif EYMmnJAyxV==QlTuvPbSpnjygBVW(u"࠳࠳࠶࠵഍"): brQi6JBc3kM7N9SD()
	elif EYMmnJAyxV==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠴࠴࠷࠷എ"): LKafwQVMYnk9cmrhg8()
	return
def LKafwQVMYnk9cmrhg8(LrPCvHKemFQ07tdEafAWkhoDGUJuV1=SmbNGskjMx):
	eYvNqFMwxLgKb = Xy1xTM6b4LChGw5dzS3ZgkIU()
	aP4cVXjKzT = UpQ56M0dO1N9xIvVegy(u"ࠨษ็ฮูเ๊ๅࠢส่้ออใࠢํ฽๊๊ࠧ৒") if eYvNqFMwxLgKb else qrjy8LuKVPNYdbSvzh(u"ࠩส่ฯฺฺ๋ๆࠣห้๊วฮไ้ࠣฯ๎โโࠩ৓")
	CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡧࡪࡴࡴࡦࡴࠪ৔"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫำื่อࠩ৕"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬห๊ใษไࠫ৖"),tM24jD1gO0(u"࠭สี฼ํ่ࠬৗ"),SSvu1CZjTW7FcloNqD(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৘"),eMypvI8XqHjYU02anWD9gsSrkt+aP4cVXjKzT+c7gxFyUCGm+wwOnIucWJj+qrjy8LuKVPNYdbSvzh(u"ࠨ้ำ๋ࠥอไฺ้ํๅฮࠦสอ฻็ࠤ่๎ฯ๋ࠢฦ์ฯ๎ๅศฬํ็๏อ๋ࠠไ๋้ࠥฮสี฼ํ่ࠥอไโ์า๎ํࠦวๅๆสั็ࠦ࠮࠯ࠢศ้ฬࠦศฺัࠣห๋ะ็ศรࠣห้็๊ะ์๋ࠤฬ๊อศๆํࠤอษใๆๆ๊ࠤ࠳࠴ࠠฤ๊ࠣฬ฾ีࠠศๆ้ๆึูࠦๅ๋ࠣึึࠦࠢหฮส์ืࠦลๅ๋ࠣห้๊วฮไࠥࠤ࠳࠴้ࠠลํฺฬࠦๅๆๅ้ࠤสฺ๊ศรࠣห้ะิ฻์็ࠤฬ๊ไศฯๅࠤออไ็ไิࠤ฾๊้ࠡิิࠤࠧห๊ใษไࠤฬ๊แ๋ัํ์ࠧࠦ࠮࠯๋ࠢว๏฼วࠡ็่็๋ࠦวๅษึฮๆอฯส่๊ࠢࠥะฺ๋์ิࠤฯืส๋ส้ࠣาะ่๋ษอࠤฬ๊โ้ษษ้ࠥ࠴࠮๊ࠡัหฺฯࠠหำอ๎อࠦอๅไสฮࠥอไๆี็ื้อสࠡ࠰࠱ࠤ์๊ࠠหำํำࠥอไร่ࠣฮูเ๊ๅ๊ࠢิ์ࠦวๅ๊฻๎ๆฯࠠฤ็ࠣษ๏่วโ้สࠤฤࠧࠡࠨ৙"))
	if CH74LFlzUW3gkcxe2P==vkIa3ijEQVsJGdWOXwK7bnue9ADR: V5VsTuKOPYNQvkcX2 = RarSo2nTfwU0WEGK.executeJSONRPC(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣࡕࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡗࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࡖࡢ࡮ࡸࡩࠧ࠲ࠢࡪࡦࠥ࠾࠶࠲ࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨࡶࡪࡦࡨࡳࡵࡲࡡࡺࡧࡵ࠲ࡦࡻࡴࡰࡲ࡯ࡥࡾࡴࡥࡹࡶ࡬ࡸࡪࡳࠢ࠭ࠤࡹࡥࡱࡻࡥࠣ࠼࡞ࡡࢂࢃࠧ৚"))
	elif CH74LFlzUW3gkcxe2P==QQSugEIn2mTCpRsfcaJHhPdAWzylM: V5VsTuKOPYNQvkcX2 = RarSo2nTfwU0WEGK.executeJSONRPC(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡷ࡫ࡧࡩࡴࡶ࡬ࡢࡻࡨࡶ࠳ࡧࡵࡵࡱࡳࡰࡦࡿ࡮ࡦࡺࡷ࡭ࡹ࡫࡭ࠣ࠮ࠥࡺࡦࡲࡵࡦࠤ࠽࡟࠶ࡣࡽࡾࠩ৛"))
	if CH74LFlzUW3gkcxe2P in [vkIa3ijEQVsJGdWOXwK7bnue9ADR,QQSugEIn2mTCpRsfcaJHhPdAWzylM]:
		if ulAxHwvzR9eTb5n(u"ࠫࡹࡸࡵࡦࠩড়") in str(V5VsTuKOPYNQvkcX2): aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨঢ়"),cb3rmvAn4wa6lBPz2phOoYqX(u"࠭สๆฬࠣห้฿ๅๅ์ฬࠤอ์ฬศฯࠪ৞"))
		else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪয়"),bYyKEjIuGQzoq3AR1(u"ࠨๆ็วุ็ࠠศๆ฼้้๐ษࠡใื่ฯ࠭ৠ"))
	return
def brQi6JBc3kM7N9SD():
	url = sCSyOla9hrcE[YayJj10OGl(u"ࠩࡕࡉࡑࡋࡁࡔࡇࡖࠫৡ")][QlTuvPbSpnjygBVW(u"࠴ഏ")]
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡋࡊ࡚ࠧৢ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡉࡏࡕࡗࡅࡑࡒ࡟ࡐࡎࡇࡣࡗࡋࡌࡆࡃࡖࡉ࠲࠷ࡳࡵࠩৣ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	l6ifO2ZNCResYtwnP0rD5S8oxac3y = ScntgdOZCY74vNpXeW5jh8i.findall(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠱࠮ࡄ࠯ࠢࠨ৤"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	l6ifO2ZNCResYtwnP0rD5S8oxac3y = sorted(l6ifO2ZNCResYtwnP0rD5S8oxac3y,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4)
	bCiGxXzDkH = nnRXQH90qeOtABkJzGr(ulAxHwvzR9eTb5n(u"࠭รฯฬิࠤฬ๊ลึัสีࠥอไๆ่สือ࠭৥"),l6ifO2ZNCResYtwnP0rD5S8oxac3y)
	if bCiGxXzDkH>=bnI4kmPtrW7yFEhljXOCq9(u"࠵ഐ"):
		zWRXcK3eA29NDrF = url.rsplit(flDSRbv57PnV3(u"ࠧ࠰ࠩ০"),X1mRwt2YJKgCLu9a67(u"࠷഑"))[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠰ഒ")]+DJ6ugPjW9bX8I(u"ࠨ࠱ࠪ১")+l6ifO2ZNCResYtwnP0rD5S8oxac3y[bCiGxXzDkH]
		succeeded = q9WvrGEy1i4LXaMKRz0cmO8(QlTuvPbSpnjygBVW(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧ২"),zWRXcK3eA29NDrF,bYyKEjIuGQzoq3AR1(u"࡙ࡸࡵࡦ൤"))
		if succeeded:
			llnG7jiQBYKhAeovbT.setSetting(QlTuvPbSpnjygBVW(u"ࠪࡥࡻ࠴ࡶࡦࡴࡶ࡭ࡴࡴࠧ৩"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ৪"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠬะๅࠡฬฮฬ๏ะࠠฦืาหึࠦโะ์่ࠤ้๊ศา่ส้ัࠦ࠮࠯ࠢ็็๋ࠦศา่ส้ัࠦใ้ัํࠤ๏่่ๆࠢฦ์ฯ๎ๅศฬํ็๏อࠠษฬะำ๏ัࠠอ็ํ฽ࠥอไษำส้ัࠦศศีอาิอๅࠡฤัีࠥหีะษิࠤ๊ะ่โำࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠศๆล๊ࠥห๊ใษไࠤฬ๊สฮัํฯࠥอไฤ๊อ์๊อส๋ๅํࠤ้ํะศࠢส่อืๆศ็ฯࠤฤࠧࠡࠨ৫"))
			if oyNUHM3uQq: DDLHBPM3dqltVvkc2sYNWFXE07eAI(YayJj10OGl(u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡧࡲࡢࡤ࡬ࡧࡻ࡯ࡤࡦࡱࡶࠫ৬"),Ag9l6cw3EBqP8HsQuGMizfOtr4,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return
def FSruUQxdLDBTgboGe():
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৭"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠศๆัหฺฯࠠษ๊ๅฮࠥาไษࠢส่ฯำฯ๋อสฮࠥ࠴࠮้ࠡำหࠥอไๆีะࠤุ๎แࠡ์ึฬอࠦสฮัํฯࠥ็่า์่ࠣัฺ๋๊๋ࠢ฼ฬฬแࠡษ็ฬึ์วๆฮࠣห้ะ๊ࠡฬ฼ฮ๊ีฺࠠๆ์ࠤ๊ื่า๋ࠢๆฯࠦๅฺ์้ࠫ৮"))
	if oyNUHM3uQq:
		llnG7jiQBYKhAeovbT.setSetting(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡤࡺ࠳ࡲࡡࡴࡶࡦ࡬ࡪࡩ࡫࠯ࡵ࡫ࡳࡷࡺࠧ৯"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
		llnG7jiQBYKhAeovbT.setSetting(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡥࡻ࠴࡬ࡢࡵࡷࡧ࡭࡫ࡣ࡬࠰ࡵࡩ࡬ࡻ࡬ࡢࡴࠪৰ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
		llnG7jiQBYKhAeovbT.setSetting(l4DS8mnEjHhFMZ5YOe(u"ࠫࡦࡼ࠮࡭ࡣࡶࡸࡨ࡮ࡥࡤ࡭࠱ࡰࡴࡴࡧࠨৱ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
		llnG7jiQBYKhAeovbT.setSetting(UpQ56M0dO1N9xIvVegy(u"ࠬࡧࡶ࠯࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭৲"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
		llnG7jiQBYKhAeovbT.setSetting(UpQ56M0dO1N9xIvVegy(u"࠭ࡡࡷ࠰࡯ࡥࡸࡺࡣࡩࡧࡦ࡯࠳ࡷࡵࡦࡵࡷ࡭ࡴࡴࡳࠨ৳"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ৴"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨฬ่ࠤู๊อࠡว฼ำฬีวหࠢส่อืๆศ็ฯࠤฬ๊ฮศืฬࠤอ๎โหࠢฯ่อࠦวๅฬะำ๏ัวหࠢ࠱࠲ࠥ๎ำ้ใࠣ๎็๎ๅࠡษ็ฬึ์วๆฮࠣห้ศๆࠡสอัิ๐ห้ࠡำ๋ࠥอไฦ฻าหิอสࠡ࠰࠱ࠤํษ๊ืษࠣฮาี๊ฬ๋ࠢ฼ฬฬแࠡษ็ฬึ์วๆฮࠣห้ะ๊ࠡฬ฼ฮ๊ีฺࠠๆ์ࠤฬ๊่ใฬࠪ৵"))
		ue186CEMORWhvq(SmbNGskjMx)
	return
def bLSuE4KXWYVJAH9snldmr3x():
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ৶"),YayJj10OGl(u"๋้ࠪࠦสา์าࠤๆ฿ไศ่ࠢืาࠦฬๆ์฼ࠤส฿ฯศัสฮࠥอไษำ้ห๊าࠠ࠯࠰ࠣ์ู๊อࠡฮ่๎฾ࠦๅๅใสฮࠥอไษำ้ห๊าࠠศๆๅำ๏๋ษࠡ࠰࠱ࠤ้้๊ࠡ์฼์ิࠦวๅสิ๊ฬ๋ฬࠡว็ํࠥำวๅหࠣห้฻แาࠢ࠱࠲ࠥ๐ู็์ࠣฮัี๊ะࠢส่อืๆศ็ฯࠤํะีโ์ิ๋ࠥ๎่ื฻๊ࠤอำวๅหࠣห้๋ี็฻ࠣห้ะู๊๊ࠡ฽์อࠠศๆ่ฬึ๋ฬࠡมࠤࠥࠬ৷"))
	if oyNUHM3uQq:
		S3pFKw0RlMXYBiIVhG7Z(SmbNGskjMx)
		bQaAGNXBYIgClLm15ui3JqU(iy1kK0BAJVLazhHpnZEqrYt9dOfW,Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ৸"),DJ6ugPjW9bX8I(u"ࠬะๅࠡ็ึัࠥาๅ๋฻ࠣห้๋ไโษอࠤฬ๊โะ์่อ๊ࠥไษำ้ห๊าࠠ࠯࠰ࠣ์฾อฯࠡษ็ฬึ์วๆฮࠣษ้๏ุ้ࠠ฼๎ฮࠦวๅืไีࠥ࠴࠮ู๊ࠡ฽๏ฯࠠศๆู่๋฿ࠧ৹"))
	return
def FCbPGwmIZrD1jAHUsuzKlt9oS():
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,Fo1SgXMsHk(u"࠭ࡍࡊࡕࡆࡣ࡙ࡋࡍࡑࠩ৺"),tM24jD1gO0(u"ࠧࡒࡗࡈࡗ࡙ࡏࡏࡏࡕࠪ৻"))
	SEKgsaLmWbq5B7dHX2uQPVTUCe = nNR2JPEM9mh(SmbNGskjMx)
	pRvhfldKGVLPxSTzoC0X7FyQgca = wwOnIucWJj
	syilcoq3QRwSf = l5JG7XwbOfo8DznU+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࠢ࠰࠱࠲࠳࠭ࠡ࠯࠰࠱࠲࠳ࠠ࠮࠯࠰࠱࠲ࠦ࠭࠮࠯࠰࠱ࠥ࠳࠭࠮࠯࠰ࠤࠬৼ")+c7gxFyUCGm
	j0gVa3Lk7YoWJynGKb = wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+UpQ56M0dO1N9xIvVegy(u"ࠩࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥ࠭৽")+c7gxFyUCGm+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡠࡳࡢ࡮ࠨ৾")
	for id,vHsaM4eT5Nkx9Zt,d1wmW9AYrsK,qbF0StY2asIVE1yWxNn4KUQB9dD,ArJ8jElsYxFZNhfvOiw,reason in reversed(SEKgsaLmWbq5B7dHX2uQPVTUCe):
		if id==IINBvuxkCSJrO1Q0UyngdLi(u"ࠫ࠵࠭৿"):
			p5dzuoRK9kgcswW86JaM0OhN1CbQnP,TT6JEsYjXLtmQdnG = qbF0StY2asIVE1yWxNn4KUQB9dD.split(QlTuvPbSpnjygBVW(u"ࠬࡢ࡮࠼࠽ࠪ਀"))
			continue
		if pRvhfldKGVLPxSTzoC0X7FyQgca!=wwOnIucWJj: pRvhfldKGVLPxSTzoC0X7FyQgca += j0gVa3Lk7YoWJynGKb
		G8CImB4K9pN3OhHT = l4DS8mnEjHhFMZ5YOe(u"࡛࠭ࡓࡖࡏࡡࠬਁ")+l5JG7XwbOfo8DznU+id+Fo1SgXMsHk(u"ࠧࠡ࠼ࠣࠫਂ")+QlTuvPbSpnjygBVW(u"ࠨษ็ืษอไࠡ࠼ࠣࠫਃ")+c7gxFyUCGm+d1wmW9AYrsK
		dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = X1mRwt2YJKgCLu9a67(u"ࠩ࡟ࡲࡠࡘࡔࡍ࡟ࠪ਄")+l5JG7XwbOfo8DznU+tM24jD1gO0(u"ࠪห้า่ศสࠣ࠾ࠥ࠭ਅ")+c7gxFyUCGm+qbF0StY2asIVE1yWxNn4KUQB9dD
		Rv3xcXSYnZIK7bFNiUHweEQL0z1j = DJ6ugPjW9bX8I(u"ࠫࡠࡘࡔࡍ࡟ࠪਆ")+l5JG7XwbOfo8DznU+IINBvuxkCSJrO1Q0UyngdLi(u"ࠬอไฯูฦࠤ࠿ࠦࠧਇ")+c7gxFyUCGm+ArJ8jElsYxFZNhfvOiw
		amIcByjdlx5ktPVoh2WvQOXsLzi = bnI4kmPtrW7yFEhljXOCq9(u"࠭࡜࡯࡝ࡕࡘࡑࡣࠧਈ")+l5JG7XwbOfo8DznU+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧศๆึฬอࠦ࠺ࠡࠩਉ")+c7gxFyUCGm+reason
		pRvhfldKGVLPxSTzoC0X7FyQgca += G8CImB4K9pN3OhHT+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs+wwOnIucWJj+syilcoq3QRwSf+wwOnIucWJj+Rv3xcXSYnZIK7bFNiUHweEQL0z1j+amIcByjdlx5ktPVoh2WvQOXsLzi+wwOnIucWJj
	r31rWd0qVCzeNapuFjwZg8scSIi5(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡴ࡬࡫࡭ࡺࠧਊ"),TT6JEsYjXLtmQdnG,pRvhfldKGVLPxSTzoC0X7FyQgca,bYyKEjIuGQzoq3AR1(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࡤࡲ࡯࡯ࡩࠪ਋"))
	return
def n4spMr2z1Sf7JwDT5x6ePqbgZG(file):
	if file==g8FzaRfU7Zx9HeSBNtJ: eqZzctdnD0AUQkJBWMuFV = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪๆํอฦๆࠢส่๊็ึๅหࠪ਌")
	elif file==TTrFaqDzxJOsh90UHIZ5: eqZzctdnD0AUQkJBWMuFV = YayJj10OGl(u"ࠫ็๎วว็ࠣฦำืࠠศๆไ๎ิ๐่่ษอࠫ਍")
	CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(ulAxHwvzR9eTb5n(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ਎"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ๅิฯࠪਏ"),QlTuvPbSpnjygBVW(u"ࠧฦื็หา࠭ਐ"),I3cxjYaHhsrM7T4UX26klN(u"ࠨะิ์ั࠭਑"),UpQ56M0dO1N9xIvVegy(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ਒"),cb3rmvAn4wa6lBPz2phOoYqX(u"๋้ࠪࠦสา์าࠤส฻ไศฯ้้ࠣ็ࠠࠨਓ")+eqZzctdnD0AUQkJBWMuFV+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࠥษๅࠡฬิ๎ิࠦๅิฯࠣห้๋ไโࠢยࠫਔ"))
	if CH74LFlzUW3gkcxe2P==X1mRwt2YJKgCLu9a67(u"࠱ഓ"):
		if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(file):
			try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(file)
			except: pass
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨਕ"),bnI4kmPtrW7yFEhljXOCq9(u"࠭สๆ่ࠢืาࠦๅๅใࠣࠫਖ")+eqZzctdnD0AUQkJBWMuFV)
	elif CH74LFlzUW3gkcxe2P==tM24jD1gO0(u"࠳ഔ"):
		data = LjfICzo9TkNMZ1PSaFW5vl3b0(file)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪਗ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨฬ่ࠤส฻ไศฯ้้ࠣ็ࠠࠨਘ")+eqZzctdnD0AUQkJBWMuFV)
	return
def qjkhtZBR6UefrlE4Pm0D():
	if o8MCS3IzmRXdVDB7xg2eiW5baZUn<xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠴࠼ക"):
		CtO9cFuULSm62PWToMlzN1 = qrjy8LuKVPNYdbSvzh(u"ࠩ็่ศูแࠡล้ฮࠥะำหะา้ࠥหีะษิࠤ่๎ฯ๋ࠢๅำ๏๋ࠠาไ่ࠤࠬਙ")+str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)+l4DS8mnEjHhFMZ5YOe(u"ࠪࠤํ๊็ัษࠣห้่่ศศ่ࠤฬ๊ๅึ๊ิอ๊ࠥวࠡฬ฼ู้้ࠦ็ัๆࠤ࠳ࠦ็ั้ࠣห้๋๊ำหࠣฮ๊้ๆไ่๊ࠢࠥืฤ๋หࠣๆํอฦๆࠢส่ๆ๐ฯ๋๊๊หฯࠦแ๋ࠢหี๋อๅอࠢ฼้ฬีࠠษึๆ่ࠥ฻่าࠢหำ้อࠠๆ่ࠣห้้สศสฬࠤ࠳ࠦไฦื็หาࠦวๅ็ื็้ฯࠠใ็ࠣฬฯำฯ๋อࠣฬึ์วๆฮࠣ็ํี๊ࠡว็ํࠥห๊ࠡวุำฬืࠠาไ่๋ࠥษูๅ๋้๋ࠣࠦ࠱࠹࠰࠳ࠫਚ")
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧਛ"),CtO9cFuULSm62PWToMlzN1)
		return
	TRlmx0KhjvQorVk9DYGzwIp = RarSo2nTfwU0WEGK.executeJSONRPC(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࢁࠢ࡫ࡵࡲࡲࡷࡶࡣࠣ࠼ࠥ࠶࠳࠶ࠢ࠭ࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤ࡯ࡳࡴࡱࡡ࡯ࡦࡩࡩࡪࡲ࠮ࡴ࡭࡬ࡲࠧࢃࡽࠨਜ"))
	QCkFNzuGpZwqEmb = wQ5nCz7RXvZJ([xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬਝ")])
	HD5qTR34VXh79ULoz,l8TYai19OMFcqGrkVCBnLzPRSEh,PzN0rOVZpDGgoJxhas9f8qeE,U6smkyZndTrDF,IIZTEMylp2zJOc1AmntWL7,M6uvDPKAVpqf2wx,F71zbCVW604jiNHnpS = QCkFNzuGpZwqEmb[IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ਞ")]
	if HD5qTR34VXh79ULoz or UpQ56M0dO1N9xIvVegy(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧਟ") not in str(TRlmx0KhjvQorVk9DYGzwIp):
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬਠ"),bYyKEjIuGQzoq3AR1(u"ࠪห้่่ศศ่ࠤฬ๊ๅึ๊ิอࠥะูๆๆࠣๅ็฽ࠠๆ฻ࠣะ้ีࠠๆฬิ์อ๎ไิࠢ฼้ฬีࠠ࠯๊ࠢิ์ࠦวๅไ๋หห๋ࠠห็ๆ๊่ࠦๅ็ࠢิศ๏ฯࠠใ๊สส๊ࠦศา่ส้ัูࠦๆษาࠤอฺใๅุࠢ์ึࠦศะๆสࠤ๊์ࠠศๆๆฮฬฮษࠨਡ"))
		EJNf2kglaiQHnFGe531Iq = s8j7mtrbOgdlq9eNT2vSnRBcVpP6()
		if not EJNf2kglaiQHnFGe531Iq: return
	qqRhft0sZrzCpS89ecTV(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return
def qqRhft0sZrzCpS89ecTV(showDialogs=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	TRlmx0KhjvQorVk9DYGzwIp = RarSo2nTfwU0WEGK.executeJSONRPC(QlTuvPbSpnjygBVW(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧਢ"))
	if Fo1SgXMsHk(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫਣ") not in str(TRlmx0KhjvQorVk9DYGzwIp):
		if showDialogs:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩਤ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧๅๆฦืๆࠦฬ่ษี็๊ࠥวࠡ์ึฮำีๅࠡฮ็ำ๋ࠥสา๊ห์ฺู้ࠠ็สำࠥ࠴ࠠศๆๅ์ฬฬๅࠡษ็ฺ้๎ัสࠢอ฽๊๊ࠠโไฺࠤ๊฿ࠠอๆาࠤ๊ะั้สุู๋่ࠦๆษาࠤ࠳ࠦ็ั้ࠣห้่่ศศ่ࠤฯ๋ใ็ๅ้๋ࠣࠦัล์ฬࠤ็๎วว็ࠣฬึ์วๆฮࠣ฽๊อฯࠡสื็้ࠦี้ำࠣฬิ๊วࠡ็้ࠤฬ๊ใหษหอࠬਥ"))
		return
	kkOBpHDj9PI7Gu1zFoYyQCe = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,t4txivgXSUWBOlCakQmNDjf(u"ࠨࡣࡧࡨࡴࡴࡳࠨਦ"),qrjy8LuKVPNYdbSvzh(u"ࠩࡶ࡯࡮ࡴ࠮࡮ࡧࡷࡶࡴࡶ࡯࡭࡫ࡶࡉࡒࡇࡄࠨਧ"),SSvu1CZjTW7FcloNqD(u"ࠪ࠻࠷࠶ࡰࠨਨ"),t4txivgXSUWBOlCakQmNDjf(u"ࠫࡒࡿࡖࡪࡦࡨࡳࡓࡧࡶ࠯ࡺࡰࡰࠬ਩"))
	if not Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(kkOBpHDj9PI7Gu1zFoYyQCe): return
	LzODVY2ASrsdEQMbIm = open(kkOBpHDj9PI7Gu1zFoYyQCe,YayJj10OGl(u"ࠬࡸࡢࠨਪ")).read()
	if IZhXMprxvAHqBEFkg0: LzODVY2ASrsdEQMbIm = LzODVY2ASrsdEQMbIm.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	AEbwc1qkDtWj8 = ScntgdOZCY74vNpXeW5jh8i.findall(z3sIGH8jmLYg(u"࠭࠼ࡷ࡫ࡨࡻࡸࡄࠨ࡝ࡦ࠮࠰ࡡࡪࠫ࠭࡞ࡧ࠯࠮࠲ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡧࡺࡷࡃ࠭ਫ"),LzODVY2ASrsdEQMbIm,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	C5cQ1OtDMvAuXylrg3JUiPq6f,v4Bu6cbCY2kS = AEbwc1qkDtWj8[f4fTutDOEwUeIoPLRQ]
	yD4laHTjUB6xpE = SSvu1CZjTW7FcloNqD(u"ࠧ࠽ࡸ࡬ࡩࡼࡹ࠾ࠨਬ")+C5cQ1OtDMvAuXylrg3JUiPq6f+fgv5U2eRVaQqSiuGD(u"ࠨ࠮ࠪਭ")+v4Bu6cbCY2kS+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࠿࠳ࡻ࡯ࡥࡸࡵࡁࠫਮ")
	if showDialogs:
		Ip235bNBrYlMHhzgsO8U0GQvk46 = RarSo2nTfwU0WEGK.getInfoLabel(tM24jD1gO0(u"ࠪࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡖࡪࡧࡺࡱࡴࡪࡥࠨਯ"))
		if Ip235bNBrYlMHhzgsO8U0GQvk46==DJ6ugPjW9bX8I(u"ࠫࡊࡓࡁࡅࠢࡏ࡭ࡸࡺࠧਰ"): jMCutfr8dzEVI2eHkG9cnWxDy5Ao = z3sIGH8jmLYg(u"่่ࠬศศ่ࠤฬ๊ใหษหอࠬ਱")
		elif Ip235bNBrYlMHhzgsO8U0GQvk46==fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬਲ"): jMCutfr8dzEVI2eHkG9cnWxDy5Ao = UpQ56M0dO1N9xIvVegy(u"ࠧใ๊สส๊ࠦวๅื๋ีࠬਲ਼")
		else: jMCutfr8dzEVI2eHkG9cnWxDy5Ao = ulAxHwvzR9eTb5n(u"ࠨไ๋หห๋ࠠฤะิํࠬ਴")
		CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡦࡩࡳࡺࡥࡳࠩਵ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪๆํอฦๆࠢฦาึ๏ࠧਸ਼"),ulAxHwvzR9eTb5n(u"ࠫ็๎วว็ࠣห้้สศสฬࠫ਷"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"่่ࠬศศ่ࠤฬ๊ี้ำࠪਸ"),X1mRwt2YJKgCLu9a67(u"࠭ว็ฬࠣัฬ๊๊ศࠢอืฯิฯๆࠢࠪਹ")+jMCutfr8dzEVI2eHkG9cnWxDy5Ao,l4DS8mnEjHhFMZ5YOe(u"ࠧศ่อࠤฬ๊ย็ࠢอืฯิฯๆࠢส่ส฻ฯศำࠣห้ษฮ๋ำ่ࠣั๊ฯࠡ็อีํฮ่ๅีࠣ฽๊อฯࠡ࠰ࠣ์์ึวࠡ็฼๊ฬํࠠศ่ๆࠤฯูสุ์฼ࠤฬูสฯัส้ࠥอไใ๊สส๊ࠦวๅ็ุ์ึฯࠠษั็ห๋ࠥๆࠡไ๋หห๋ࠠศๆๆฮฬฮษࠡ࠰ࠣ์ศ๐ึศࠢอืฯ฽ฺ๊ࠢศ๎็อแ่ษࠣๅ๏ࠦร๋๋ࠢๆฯࠦสีษฤࠤࡡࡴ࡜࡯ࠢࠪ਺")+l5JG7XwbOfo8DznU+X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࠢฦาฯืࠠศๆล๊ࠥ์ฺ่ࠢส่็๎วว็ࠣห้ะ๊ࠡฬิ๎ิࠦริฬัำฬ๋็ศࠢยࠥࠬ਻")+c7gxFyUCGm)
		if CH74LFlzUW3gkcxe2P==X60YQOADpkHBb31LiR5qUEKfM(u"࠵ഖ"): S0SxUO3eoBzCcRLH4GkmnjgI7 = qrjy8LuKVPNYdbSvzh(u"ࠩࡈࡑࡆࡊࠠࡍ࡫ࡶࡸ਼ࠬ")
		elif CH74LFlzUW3gkcxe2P==fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠷ഗ"): S0SxUO3eoBzCcRLH4GkmnjgI7 = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡉࡒࡇࡄࠡࡉࡤࡰࡱ࡫ࡲࡺࠩ਽")
		else: S0SxUO3eoBzCcRLH4GkmnjgI7 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	else:
		Ip235bNBrYlMHhzgsO8U0GQvk46 = llnG7jiQBYKhAeovbT.getSetting(flDSRbv57PnV3(u"ࠫࡦࡼ࠮࡮ࡻࡶ࡯࡮ࡴ࠮ࡷ࡫ࡨࡻࡲࡵࡤࡦࠩਾ"))
		if   Ip235bNBrYlMHhzgsO8U0GQvk46==nbOFVEDkpT4BIR7Qq82yPmHeJU: CH74LFlzUW3gkcxe2P = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠶ഘ")
		elif Ip235bNBrYlMHhzgsO8U0GQvk46==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡋࡍࡂࡆࠣࡐ࡮ࡹࡴࠨਿ"): CH74LFlzUW3gkcxe2P = fgv5U2eRVaQqSiuGD(u"࠱ങ")
		elif Ip235bNBrYlMHhzgsO8U0GQvk46==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡅࡎࡃࡇࠤࡌࡧ࡬࡭ࡧࡵࡽࠬੀ"): CH74LFlzUW3gkcxe2P = wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠳ച")
		S0SxUO3eoBzCcRLH4GkmnjgI7 = Ip235bNBrYlMHhzgsO8U0GQvk46
	if   CH74LFlzUW3gkcxe2P==z3sIGH8jmLYg(u"࠲ഛ"): laxURkiFN5f0DbyvJBLr7j = X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࠶࠷࠯࠹࠹࠺ࠬ࠶࠷࠸ࠫੁ")
	elif CH74LFlzUW3gkcxe2P==fgv5U2eRVaQqSiuGD(u"࠴ജ"): laxURkiFN5f0DbyvJBLr7j = l4DS8mnEjHhFMZ5YOe(u"ࠨ࠷࠷࠸࠱࠻࠵࠶࠮࠸࠹ࠬੂ")
	elif CH74LFlzUW3gkcxe2P==q4izXt0sjIQSZcHVAf3EmKRbx(u"࠶ഝ"): laxURkiFN5f0DbyvJBLr7j = z3sIGH8jmLYg(u"ࠩ࠸࠹࠺࠲࠵࠶࠮࠸࠸࠹࠭੃")
	else: return
	llnG7jiQBYKhAeovbT.setSetting(qrjy8LuKVPNYdbSvzh(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨ੄"),S0SxUO3eoBzCcRLH4GkmnjgI7)
	r2FkmAgopYfXJ5Mil9KwyvtWuPdGsh = QlTuvPbSpnjygBVW(u"ࠫࡁࡼࡩࡦࡹࡶࡂࠬ੅")+laxURkiFN5f0DbyvJBLr7j+Fo1SgXMsHk(u"ࠬ࠲ࠧ੆")+v4Bu6cbCY2kS+tM24jD1gO0(u"࠭࠼࠰ࡸ࡬ࡩࡼࡹ࠾ࠨੇ")
	wj9t5hBfkEVUd = LzODVY2ASrsdEQMbIm.replace(yD4laHTjUB6xpE,r2FkmAgopYfXJ5Mil9KwyvtWuPdGsh)
	if IZhXMprxvAHqBEFkg0: wj9t5hBfkEVUd = wj9t5hBfkEVUd.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	open(kkOBpHDj9PI7Gu1zFoYyQCe,YayJj10OGl(u"ࠧࡸࡤࠪੈ")).write(wj9t5hBfkEVUd)
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࠰࡟ࡸࡘࡱࡩ࡯ࠢࡇࡩ࡫ࡧࡵ࡭ࡶ࡚ࠣ࡮࡫ࡷࡴ࠼ࠣ࡟ࠥ࠭੉")+laxURkiFN5f0DbyvJBLr7j+z3sIGH8jmLYg(u"ࠩࠣࡡࠬ੊"))
	if showDialogs: RarSo2nTfwU0WEGK.executebuiltin(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡖࡪࡲ࡯ࡢࡦࡖ࡯࡮ࡴࠨࠪࠩੋ"))
	return
def P3yilC4fLoJ2Tw():
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧੌ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬฮั็ษ่ะࠥ฿ๅศัࠣๅ๏ํࠠๆึๆ่ฮูࠦ็ัๆࠤ࠳࠴࠮ࠡว่หࠥษไฦืาหึࠦโะ์่ࠤ࠳࠴࠮ࠡล๋ࠤฬ์สࠡ็่๊ํ฿ࠠๆ่ࠣหุะฮะษ่ࠤฬ๊ศา่ส้ัࠦ࠮࠯࠰ࠣวํࠦไะ์ๆࠤฺ๊ใๅหࠣวำื้ࠡฬัูࠥา็ศิๆࠤศ์ส๊ࠡ็หࠥะฮึࠢหๆ๏ฯࠠฯๆๅࠤฬ๊ไ่ࠢ࡟ࡲࡡࡴࠠฮษ๋่ࠥะอะ์ฮࠤฬ๊ศา่ส้ัࠦร้ࠢสฮฺ๊ࠠษษ็้อืๅอࠢ็้฾ืแสࠢึฬอࠦวๅ็ื็้ฯฺ่ࠠา็ࠥ࠴࠮࠯๊่ࠢࠥะั๋ัࠣๅา฻ࠠศๆอัิ๐หศฬࠣห้ศๆࠡม੍ࠪ"))
	if oyNUHM3uQq==SSvu1CZjTW7FcloNqD(u"࠶ഞ"): UAIF0rTwoYbJO9jMVqfhs27mtRCep()
	return
def Nbk3dJQsOeK5Y2ExRjWMo():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ੎"),QlTuvPbSpnjygBVW(u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤ๊เไใ่๊ࠢࠥอไๆืาีࠥ๎ฺ๋ำ้ࠣ฾ื่โ่ࠢฮ๏๊ࠦาฮ฼ࠤู้๊ๆๆࠪ੏"))
	return
def wHMVpK0IPYiFURvrhxLJ19NOus():
	G8CImB4K9pN3OhHT = l5JG7XwbOfo8DznU+z3sIGH8jmLYg(u"ࠨฬ฼ำฬีࠠี์฼อࠥศไࠡ็ะ้ิࠦไิ่ฬࠤ࠷࠶࠲࠲ࠢ࠽ࠤࠬ੐")+c7gxFyUCGm
	G8CImB4K9pN3OhHT += DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩส่๊๎โฺࠢฦำ๋อ็ࠡใํ๋ࠥหอึษษ๎ฮࠦไฺัาࠤฬ๊ิ๋฻ฬࠤๆ๐ࠠศๆ฼ห้๋ࠠห็ࠣะ๊฿็ศ่๊ࠢࠥาๅ๋฻ࠣห้๋ีศัิࠤฬ๊ๅห๊ไีฮࠦแ๋ࠢส่ส์สา่อࠤฬ๊โะ์่อࠥ๎วๅฮา๎ิฯࠠศๆะ็ํ๋๊ส๋ࠢห้เ๊าࠢะ็ํ๋๊ส๋้๋ࠢࠦฬๆ์฼ࠤิ๎ไࠡษ็฽ฬ๊ๅࠡอ่ࠤฯ๋ࠠห๊ะ๎ิํว๊ࠡะืฬฮࠠศๆ่฽ิ๊ࠠฮีหࠤุ้ว็ࠢา์้ࠦวๅ฻ส่๊ࠦไิ่ฬࠤ࠷࠶࠲࠲๋๋ࠢ๏ࠦวๅวะูฬฬ๊สࠢส่ศำฯฬ๋ࠢห้ษิๆๆࠣห้ะ๊ࠡฬ่ࠤ฾๋ไ่ษࠣๅ๏ࠦวๅี้์ฬะࠠศๆ฼ุึฯࠠศๆ่ห฻๐ษࠨੑ")
	G8CImB4K9pN3OhHT += wwOnIucWJj+l5JG7XwbOfo8DznU+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡹ࡯࡮ࡺ࠰ࡦࡧ࠴ࡹࡨࡪࡣࡦࡳࡺࡴࡴࠨ੒")+c7gxFyUCGm
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = l5JG7XwbOfo8DznU+Fo1SgXMsHk(u"ࠫอืๆศ็ฯࠤูืุ๊ࠢสู่๊ไๆࠢ࠽ࠤࠬ੓")+c7gxFyUCGm
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += Fo1SgXMsHk(u"ࠬํ่ࠡ฻หหึฯฺ่ࠠࠣฬึ์วๆฮࠣ๎ํ็ัࠡ็฼่ํ๋วหࠢะืฬฮ๊สࠢๆฯ๏ืษࠡฬ๊้ࠥาๅ๋฻ࠣห้๋ำๅ็ํ๊๋ࠥหๅࠢฦ์็อสࠡษ็ู้อษ๊ࠡฦ์็อสࠡษ็็ุ๎แ๊ࠡส่ำู่โุ๋่๊ࠢࠠศๆๅ้ึ่ࠦฤ๊ๅหฯࠦวๅไ่ีࠥ๎รุ๋สࠤ๏๎แาࠢิศ๏ฯࠠศๆ๊่ฬ๊ࠠโ์ࠣะ๊๐ูࠡั๋่ࠥอไฺษ็้ࠥ๎รุ๋สࠤๆ๐็ࠡฬๅ์๏๋ࠠๆ์็หิ๐้้ࠠฯี๏่ࠦโ์๊ࠤศ๐ึศࠢหัะ่ࠦใำสลฮࠦวๅไิฦ๋่ࠦฤ์ูหࠥ็๊่ࠢสืฯิวาหࠣ์ฯ็วลๆࠣ์ๆ๐็ࠡลๅ์ฬ๊ࠠๆ่ึ์อฯࠠๅๆฦ้ฬฺ๋ࠠๆํࠤํษๅ้ำࠣวำื้ࠡฬ๊้้ࠥไࠡ็ึ่๊ࠦ࠮ࠡษ็ฬึ์วๆฮ้่ࠣะ่ษࠢห่฿ฯࠠอษไหูࠥใาสอࠤํ๐ำหะา้ࠥ์ุศ็ࠣ์๏์ฯ้ิࠣฮาะࠠษ์ษอࠥ๎๊็ั๋ึ้ࠥวอ์อࠤํ๋ฮึืࠣๅ็฽ࠠๅลฯ๋ืฯࠠศๆ๋๎๋ี่ำࠢ࠱ࠤฬ๊ๅ้ไ฼ࠤฬ๊ัิ็ํࠤ้๊ศา่ส้ัࠦ็้ࠩ੔")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj+l5JG7XwbOfo8DznU+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡵ࡫ࡱࡽ࠳ࡩࡣ࠰࡯ࡸࡷࡱ࡯࡭ࡳࡷ࡯ࡩࡷ࠭੕")+c7gxFyUCGm
	CtO9cFuULSm62PWToMlzN1 = bYyKEjIuGQzoq3AR1(u"ࠧ࡜ࡔࡗࡐࡢ࠭੖")+G8CImB4K9pN3OhHT+ulAxHwvzR9eTb5n(u"ࠨ࡞ࡱࡠࡳࡢ࡮࡜ࡔࡗࡐࡢ࠭੗")+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs
	r31rWd0qVCzeNapuFjwZg8scSIi5(qrjy8LuKVPNYdbSvzh(u"ࠩࡵ࡭࡬࡮ࡴࠨ੘"),nbOFVEDkpT4BIR7Qq82yPmHeJU,CtO9cFuULSm62PWToMlzN1)
	return
def UbxR3AHIEPcdBS(RRdkhxeG53A7ClaoBOzFr0c6I4bD):
	hTxAoj52vsb6Mze9rnmIk7lNJg(zDoPOYNsJg2id1HLnx5bpf)
	SEKgsaLmWbq5B7dHX2uQPVTUCe = nNR2JPEM9mh(RRdkhxeG53A7ClaoBOzFr0c6I4bD)
	Wyuk0g8ERiBU(ulAxHwvzR9eTb5n(u"ࠪࡈࡔࡔࡁࡕࡋࡒࡒࡘ࠭ਖ਼"))
	id,vHsaM4eT5Nkx9Zt,d1wmW9AYrsK,qbF0StY2asIVE1yWxNn4KUQB9dD,ArJ8jElsYxFZNhfvOiw,reason = SEKgsaLmWbq5B7dHX2uQPVTUCe[f4fTutDOEwUeIoPLRQ]
	p5dzuoRK9kgcswW86JaM0OhN1CbQnP,TT6JEsYjXLtmQdnG = qbF0StY2asIVE1yWxNn4KUQB9dD.split(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡡࡴ࠻࠼ࠩਗ਼"))
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs,Rv3xcXSYnZIK7bFNiUHweEQL0z1j,amIcByjdlx5ktPVoh2WvQOXsLzi = ArJ8jElsYxFZNhfvOiw.split(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡢ࡮࠼࠽ࠪਜ਼"))
	CFBjSK1Erhv8Pidstnk = Ag9l6cw3EBqP8HsQuGMizfOtr4
	while CFBjSK1Erhv8Pidstnk:
		Q5VR1x8yvFLmGe2ADJtnghwOqlNS4P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"࠭ฮา๊ฯࠫੜ"),bYyKEjIuGQzoq3AR1(u"ࠧฦำึห้ࠦัิษ็อ๊ࠥไๆสิ้ั࠭੝"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨไสส๊ฯࠠศๆอฬึ฿วหࠩਫ਼"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩ็ษ๏่วโࠢส่ส฿ไศ่สฮࠥࡀࠠࠡฬหี฾ࠦร้ࠢสุ้ำࠠศๆหี๋อๅอࠩ੟"),dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs)
		if Q5VR1x8yvFLmGe2ADJtnghwOqlNS4P==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠸ട"): usUYa62yR073IwibtrLopPSc8WDVC = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠪ฽ํีษࠨ੠"),nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"๊ࠫฮฯฤࠢส่ฯฮัฺࠢ฽๎ึࠦโศส็ࠤ้๊ๆใษืࠫ੡"),Rv3xcXSYnZIK7bFNiUHweEQL0z1j,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲࡥࡳ࡮ࡣ࡯ࡰ࡫ࡵ࡮ࡵࠩ੢"))
		elif Q5VR1x8yvFLmGe2ADJtnghwOqlNS4P==bnI4kmPtrW7yFEhljXOCq9(u"࠱ഠ"): IbOgDw5uNE16VosCFnShBl()
		else: CFBjSK1Erhv8Pidstnk = SmbNGskjMx
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD: ue186CEMORWhvq(SmbNGskjMx)
	return
def S3pFKw0RlMXYBiIVhG7Z(showDialogs):
	oyNUHM3uQq = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if showDialogs: oyNUHM3uQq = ttiZs4bKHFvugJj5z(flDSRbv57PnV3(u"࠭ࡣࡦࡰࡷࡩࡷ࠭੣"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧิฦส่ࠬ੤"),l4DS8mnEjHhFMZ5YOe(u"ࠨ้็ࠤศ์สࠡ็อว่ี้ࠠฬิ๎ิࠦๅิฯࠣ์ฯ฻แ๋ำࠣะ๊๐ูࠡว฼ำฬีวหࠢหี๋อๅอࠢ฼้ฬีࠠๅๆไ๎ิ๐่่ษอࠤฬู๊าสํอࠥ࠴ࠠฮ์ฮࠤฯ฿่ะࠢฯ้๏฿ࠠศๆศ฽ิอฯศฬࠣษ้๏ุ้ࠠ฼๎ฮࠦสฬสํฮࠥอไษำ้ห๊าࠠภࠩ੥"))
	if oyNUHM3uQq:
		EJNf2kglaiQHnFGe531Iq = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(dSqtElDz6Z31pkRgKOaf5ch):
			try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(dSqtElDz6Z31pkRgKOaf5ch)
			except: EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
		if showDialogs:
			if EJNf2kglaiQHnFGe531Iq: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠩอ้ࠥฮๆอษะࠤู๊อ๊ࠡอูๆ๐ัࠡ็็ๅࠥหูะษาหฯࠦศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩ੦"))
			else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"่้ࠪษำโࠢไุ้ะฺࠠ็็๎ฮࠦๅิฯ้้ࠣ็ࠠศๆศ฽ิอฯศฬࠪ੧"))
	return
def OM2C9seoTaYPIbcByt8xVrq():
	VfhJAnDWzB6u2ysbR()
	YbkVtUXfMdW3KJcjnCOzI6ml7L9Dq = llnG7jiQBYKhAeovbT.getSetting(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡩࡶࡷࡴࡨࡧࡣࡩࡧࠪ੨"))
	CtO9cFuULSm62PWToMlzN1 = {}
	CtO9cFuULSm62PWToMlzN1[bYyKEjIuGQzoq3AR1(u"ࠬࡇࡕࡕࡑࠪ੩")] = wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭วๅๅสุࠥอไหๆๅหห๐๋ࠠ฻่่ࠬ੪")
	CtO9cFuULSm62PWToMlzN1[YayJj10OGl(u"ࠧࡔࡖࡒࡔࠬ੫")] = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨษ็็ฬฺࠠๆฬ๋ๆๆࠦสๆษ่หࠥ๎ศศๆๆห๊๊ࠧ੬")
	CtO9cFuULSm62PWToMlzN1[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡏࡍࡒࡏࡔࡆࡆࠪ੭")] = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪ็ฬฺࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡ࠰ࠣࠫ੮")+str(gn5pkSvs06TGQdC2YVir38DWf9IM/X1mRwt2YJKgCLu9a67(u"࠷࠲ഡ"))+IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࠥีโ๋ไฬࠤๆ่ืࠨ੯")
	mZSj20RNkgCWrAVl94Y8 = CtO9cFuULSm62PWToMlzN1[YbkVtUXfMdW3KJcjnCOzI6ml7L9Dq]
	CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"้ࠬวีࠢࠪੰ")+str(gn5pkSvs06TGQdC2YVir38DWf9IM/t4txivgXSUWBOlCakQmNDjf(u"࠸࠳ഢ"))+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࠠะไํๆฮ࠭ੱ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧหึ฽๎้ࠦสๅไสส๏࠭ੲ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠨวํๆฬ็ࠠไษ่่ࠬੳ"),mZSj20RNkgCWrAVl94Y8,fsQukcZeJ8YbozTXKEvS7h306DCA(u"๊่ࠩࠥะั๋ัࠣหุะฮะษ่ࠤฬ๊ใศึࠣห้ึใ๋ࠢส่ฯ๊โศศํࠤศ๋ࠠหำํำࠥห๊ใษไࠤฬ๊ใศึࠣฬฬ๊ใศ็็ࠤศ๋ࠠหำํำ้ࠥวีࠢ฼้ึํࠠใืํีࠥาฯศࠢยࠥࠬੴ"))
	if CH74LFlzUW3gkcxe2P==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠳ണ"): iE2mAqBHtznLZcDXR = X1mRwt2YJKgCLu9a67(u"ࠪࡐࡎࡓࡉࡕࡇࡇࠫੵ")
	elif CH74LFlzUW3gkcxe2P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠵ത"): iE2mAqBHtznLZcDXR = l4DS8mnEjHhFMZ5YOe(u"ࠫࡆ࡛ࡔࡐࠩ੶")
	elif CH74LFlzUW3gkcxe2P==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠷ഥ"): iE2mAqBHtznLZcDXR = wCUIOeyRdxF3PtJ6TKYog8Xb(u"࡙ࠬࡔࡐࡒࠪ੷")
	else: iE2mAqBHtznLZcDXR = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if iE2mAqBHtznLZcDXR:
		llnG7jiQBYKhAeovbT.setSetting(ulAxHwvzR9eTb5n(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰࡫ࡸࡹࡶࡣࡢࡥ࡫ࡩࠬ੸"),iE2mAqBHtznLZcDXR)
		twbefi9HcYlgU0kTS3A6F1 = CtO9cFuULSm62PWToMlzN1[iE2mAqBHtznLZcDXR]
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,twbefi9HcYlgU0kTS3A6F1)
	return
def BEsthiXuaUe941c():
	CtO9cFuULSm62PWToMlzN1 = {}
	CtO9cFuULSm62PWToMlzN1[fgv5U2eRVaQqSiuGD(u"ࠧࡂࡗࡗࡓࠬ੹")] = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨีํีๆืࠠࡅࡐࡖࠤฬ๊สๅไสส๏ฺ๊ࠦ็็࠾ࠥ࠭੺")
	CtO9cFuULSm62PWToMlzN1[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡄࡗࡐ࠭੻")] = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪื๏ืแาࠢࡇࡒࡘࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋࠿ࠦࠧ੼")
	CtO9cFuULSm62PWToMlzN1[IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡘ࡚ࡏࡑࠩ੽")] = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ู๊ࠬาใิࠤࡉࡔࡓࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨ੾")
	JJCNgjQez0iVfRn6px = llnG7jiQBYKhAeovbT.getSetting(q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭੿"))
	YbkVtUXfMdW3KJcjnCOzI6ml7L9Dq = llnG7jiQBYKhAeovbT.getSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡤ࡯ࡵࠪ઀"))
	mZSj20RNkgCWrAVl94Y8 = CtO9cFuULSm62PWToMlzN1[YbkVtUXfMdW3KJcjnCOzI6ml7L9Dq]+JJCNgjQez0iVfRn6px
	CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨฬื฾๏ฺ๊่ࠠาࠤฬ๊ๅ้ษไๆฮ࠭ઁ"),SSvu1CZjTW7FcloNqD(u"ࠩอุ฿๐ไࠡฬ็ๆฬฬ๊ࠨં"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪษ๏่วโࠢๆห๊๊ࠧઃ"),mZSj20RNkgCWrAVl94Y8,qrjy8LuKVPNYdbSvzh(u"ุࠫ๐ัโำࠣࡈࡓ่๊࡙ࠠࠣะ์อาࠡใํࠤฬ๊ล็ฬิ๊๏ะ๋ࠠไ๋้ࠥฮสฮ๊ํ่ࠥษำๆษฤࠤฬ๊ๅ้ษๅ฽ࠥ๎วๅีํีๆืวหࠢศ่๎ࠦราไส้ࠥ๎ู็ัࠣฬ฾฼ࠠศๆ้หุ๊ࠦใ๊่ࠤอำฬษ๋้๋ࠢ฿้ࠠฯูีࠥฮูืࠢส่๊๎วใ฻ࠣ࠲๊ࠥสี฼ํู่๊ࠥาใิࠤࡉࡔࡓࠡไ่ࠤออฮห์สีࠥอไิ์ิๅึࠦวๅ็้หุฮࠠฤ๊ࠣๆ๊ࠦศฦ์ๅหๆํࠠษษ็็ฬ๋ไࠨ઄"))
	if CH74LFlzUW3gkcxe2P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠶ദ"): iE2mAqBHtznLZcDXR = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡇࡓࡌࠩઅ")
	elif CH74LFlzUW3gkcxe2P==bnI4kmPtrW7yFEhljXOCq9(u"࠱ധ"): iE2mAqBHtznLZcDXR = UpQ56M0dO1N9xIvVegy(u"࠭ࡁࡖࡖࡒࠫઆ")
	elif CH74LFlzUW3gkcxe2P==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠳ന"): iE2mAqBHtznLZcDXR = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡔࡖࡒࡔࠬઇ")
	if CH74LFlzUW3gkcxe2P in [tM24jD1gO0(u"࠳പ"),UpQ56M0dO1N9xIvVegy(u"࠳ഩ")]:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(ulAxHwvzR9eTb5n(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨઈ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩึ๎ึ็ั࠻ࠢࠪઉ")+jUy8IAthCYOu5k[vkIa3ijEQVsJGdWOXwK7bnue9ADR],qrjy8LuKVPNYdbSvzh(u"ࠪื๏ืแา࠼ࠣࠫઊ")+jUy8IAthCYOu5k[f4fTutDOEwUeIoPLRQ],nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠫศิสศำࠣื๏ืแาࠢࡇࡒࡘࠦวๅ็้หุฮࠠๅๅࠪઋ"))
		if oyNUHM3uQq==z3sIGH8jmLYg(u"࠵ഫ"): lFgE3cfXyG9Kws = jUy8IAthCYOu5k[f4fTutDOEwUeIoPLRQ]
		else: lFgE3cfXyG9Kws = jUy8IAthCYOu5k[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	elif CH74LFlzUW3gkcxe2P==cb3rmvAn4wa6lBPz2phOoYqX(u"࠷ബ"): lFgE3cfXyG9Kws = nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: iE2mAqBHtznLZcDXR = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if iE2mAqBHtznLZcDXR:
		llnG7jiQBYKhAeovbT.setSetting(l4DS8mnEjHhFMZ5YOe(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨઌ"),iE2mAqBHtznLZcDXR)
		llnG7jiQBYKhAeovbT.setSetting(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡡࡷ࠰ࡧࡲࡸ࠭ઍ"),lFgE3cfXyG9Kws)
		twbefi9HcYlgU0kTS3A6F1 = CtO9cFuULSm62PWToMlzN1[iE2mAqBHtznLZcDXR]+lFgE3cfXyG9Kws
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,twbefi9HcYlgU0kTS3A6F1)
	return
def VlbCd7LswvXFxaHGZYT53():
	YbkVtUXfMdW3KJcjnCOzI6ml7L9Dq = llnG7jiQBYKhAeovbT.getSetting(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬ઎"))
	CtO9cFuULSm62PWToMlzN1 = {}
	CtO9cFuULSm62PWToMlzN1[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡃࡘࡘࡔ࠭એ")] = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩส่อื่ไีํࠤฬ๊สๅไสส๏ࠦฬศ้ีࠤู้๊ๆๆࠪઐ")
	CtO9cFuULSm62PWToMlzN1[DJ6ugPjW9bX8I(u"ࠪࡅࡘࡑࠧઑ")] = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫฬ๊ศา๊ๆื๏ࠦำ๋฻่่ࠥฮูะࠢสุ่๋วฮࠢ็๋ࠬ઒")
	CtO9cFuULSm62PWToMlzN1[bYyKEjIuGQzoq3AR1(u"࡙ࠬࡔࡐࡒࠪઓ")] = bnI4kmPtrW7yFEhljXOCq9(u"࠭วๅสิ์ู่๊ࠡ็อ์็็ࠠห็ส้ฬ่ࠦษษ็็ฬ๋ไࠨઔ")
	mZSj20RNkgCWrAVl94Y8 = CtO9cFuULSm62PWToMlzN1[YbkVtUXfMdW3KJcjnCOzI6ml7L9Dq]
	CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(nbOFVEDkpT4BIR7Qq82yPmHeJU,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧหึ฽๎ู้ࠦ็ัࠣห้๋่ศใๅอࠬક"),bnI4kmPtrW7yFEhljXOCq9(u"ࠨฬื฾๏๊ࠠหๆๅหห๐ࠧખ"),ulAxHwvzR9eTb5n(u"ࠩศ๎็อแࠡๅส้้࠭ગ"),mZSj20RNkgCWrAVl94Y8,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪห้ฮั้ๅึ๎ࠥํ่ࠡฮ๊หืࠦแ๋ࠢส่ส์สา่ํฮࠥ๐ูๆๆࠣ์ุ๐ืࠡสํ๊ࠥา็ศิๆࠤํอไฦ่อี๋๐สࠡ࠰๋ࠣํ๊ࠦิฬ็้ࠥ฽ไษษอ็ࠥ๎๊ใ๊่ࠤอูอษ้สࠤอีไศ่๊่ࠢࠦหๆࠢํฬ฾ั็ศࠢ็็ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬื฾๏๊ࠠฤ็ࠣษ๏่วโࠢส่อื่ไีํࠤฤ࠭ઘ"))
	if CH74LFlzUW3gkcxe2P==SSvu1CZjTW7FcloNqD(u"࠶ഭ"): iE2mAqBHtznLZcDXR = l4DS8mnEjHhFMZ5YOe(u"ࠫࡆ࡙ࡋࠨઙ")
	elif CH74LFlzUW3gkcxe2P==cb3rmvAn4wa6lBPz2phOoYqX(u"࠱മ"): iE2mAqBHtznLZcDXR = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡇࡕࡕࡑࠪચ")
	elif CH74LFlzUW3gkcxe2P==fgv5U2eRVaQqSiuGD(u"࠳യ"): iE2mAqBHtznLZcDXR = q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡓࡕࡑࡓࠫછ")
	else: iE2mAqBHtznLZcDXR = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if iE2mAqBHtznLZcDXR:
		llnG7jiQBYKhAeovbT.setSetting(X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡹࡸ࡫ࡰࡳࡱࡻࡽࠬજ"),iE2mAqBHtznLZcDXR)
		twbefi9HcYlgU0kTS3A6F1 = CtO9cFuULSm62PWToMlzN1[iE2mAqBHtznLZcDXR]
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,twbefi9HcYlgU0kTS3A6F1)
	return
def snNeITzcWKPv9JH1():
	oofqxF5JY2Sig16skctEhOeB3AX = llnG7jiQBYKhAeovbT.getSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨઝ"))
	if oofqxF5JY2Sig16skctEhOeB3AX==SSvu1CZjTW7FcloNqD(u"ࠩࡖࡘࡔࡖࠧઞ"): header = X1mRwt2YJKgCLu9a67(u"ࠪฮำุ๊็ࠢส่็๎วว็้ࠣฯ๎โโࠩટ")
	else: header = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫฯิา๋่ࠣห้่่ศศ่ࠤ๊็ูๅࠩઠ")
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠬห๊ใษไࠫડ"),UpQ56M0dO1N9xIvVegy(u"࠭สโ฻ํ่ࠬઢ"),header,I3cxjYaHhsrM7T4UX26klN(u"ࠧใ๊สส๊ࠦวๅสิ๊ฬ๋ฬࠡ์อ้ࠥะอะ์ฮ๋ฬࠦร้ฬ๋้ฬะ๊ไ์สࠤอ฿ฯࠡ࠳࠹ࠤุอูส่๊ࠢࠥษ่ๅࠢฦืฯิฯศ็ࠣ࠲࠳่ࠦฦ์ๅหๆࠦสฯิํ๊ࠥอไใ๊สส๊๊ࠦลัํࠤส๊้ࠡฬะำ๏ั็ศࠢไ๎้ࠥไࠡ็ิอࠥ๐สๆࠢสืฯิฯศ็ࠣห้่่ศศ่ࠤ࠳࠴้้ࠠำหࠥ๐ำษสࠣฬ฼ฬࠠโ์ࠣๅฯำࠠใ๊สส๊ࠦวๅสิ๊ฬ๋ฬ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦสโ฻ํ่ࠥษๅࠡวํๆฬ็ࠠหะี๎๋ࠦวๅไ๋หห๋ࠠภࠣࠤࠫણ"))
	if oyNUHM3uQq==-Fo1SgXMsHk(u"࠳ര"): return
	elif oyNUHM3uQq:
		llnG7jiQBYKhAeovbT.setSetting(UpQ56M0dO1N9xIvVegy(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡲ࡫࡮ࡶࡵࡦࡥࡨ࡮ࡥࠨત"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡄ࡙࡙ࡕࠧથ"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭દ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫฯ๋ࠠหใ฼๎้ࠦสฯิํ๊ࠥอไใ๊สส๊࠭ધ"))
	else:
		llnG7jiQBYKhAeovbT.setSetting(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯࡯ࡨࡲࡺࡹࡣࡢࡥ࡫ࡩࠬન"),Fo1SgXMsHk(u"࠭ࡓࡕࡑࡓࠫ઩"))
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪપ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠨฬ่ࠤส๐โศใࠣฮำุ๊็ࠢส่็๎วว็ࠪફ"))
	return
def SSxnFXwuQNT(J1rvN7I8eLXuS54mZ6lnUjg):
	if J1rvN7I8eLXuS54mZ6lnUjg!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
		J1rvN7I8eLXuS54mZ6lnUjg = ufPy6eA5zURb7lGLK10hc(J1rvN7I8eLXuS54mZ6lnUjg)
		J1rvN7I8eLXuS54mZ6lnUjg = J1rvN7I8eLXuS54mZ6lnUjg.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode(zSafwK0sDXdMN5JReniIQmrZxp)
		TTUapq4hf7PzyFjG93YC8EMlXvL = X1mRwt2YJKgCLu9a67(u"࠴࠴࠶࠶࠳റ")
		T4Zo8zCmjqNpxO5bcLwdvSn = LAkCFq8ezcf.Window(TTUapq4hf7PzyFjG93YC8EMlXvL)
		T4Zo8zCmjqNpxO5bcLwdvSn.getControl(SSvu1CZjTW7FcloNqD(u"࠷࠶࠷ല")).setLabel(J1rvN7I8eLXuS54mZ6lnUjg)
	return
L3LjMymkTwio5YFhgadfnBqeOxCAs = [
			 DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠤࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥࡧࡶࡴࡲࡤࡧࡪࡹ࠰ࠡ࡫ࡶࠤࡳࡵࡴࠡࡥࡸࡶࡷ࡫࡮ࡵ࡮ࡼࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪࠢબ")
			,X1mRwt2YJKgCLu9a67(u"ࠪࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡐࡥࡱ࡯ࡣࡪࡱࡸࡷࠥࡹࡣࡳ࡫ࡳࡸࡸ࠭ભ")
			,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡕ࡜ࡒࠡࡋࡓࡘ࡛ࠦࡓࡪ࡯ࡳࡰࡪࠦࡃ࡭࡫ࡨࡲࡹ࠭મ")
			,qrjy8LuKVPNYdbSvzh(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡖࡪࡦࡨࡳࠥࡏ࡮ࡧࡱࠣࡏࡪࡿࠧય")
			,I3cxjYaHhsrM7T4UX26klN(u"࠭ࡴࡩ࡫ࡶࠤ࡭ࡧࡳࡩࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤ࡮ࡹࠠࡣࡴࡲ࡯ࡪࡴࠧર")
			,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡶࡵࡨࡷࠥࡶ࡬ࡢ࡫ࡱࠤࡍ࡚ࡔࡑࠢࡩࡳࡷࠦࡡࡥࡦ࠰ࡳࡳࠦࡤࡰࡹࡱࡰࡴࡧࡤࡴࠩ઱")
			,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡹࡸࡧࡧࡦ࠰࡫ࡸࡲࡲࠧલ")+t4txivgXSUWBOlCakQmNDjf(u"ࠩࠦࠫળ")+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡷࡸࡲ࠭ࡸࡣࡵࡲ࡮ࡴࡧࡴࠩ઴")
			,qrjy8LuKVPNYdbSvzh(u"ࠫࡎࡴࡳࡦࡥࡸࡶࡪࡘࡥࡲࡷࡨࡷࡹ࡝ࡡࡳࡰ࡬ࡲ࡬࠲ࠧવ")
			,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡋࡲࡳࡱࡵࠤ࡬࡫ࡴࡵ࡫ࡱ࡫ࠥࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠵࠿࡮ࡱࡧࡩࡪࡃ࠰ࠧࡶࡨࡼࡹࡺ࠽ࠨશ")
			,X1mRwt2YJKgCLu9a67(u"࠭ࡷࡢࡴࡱ࡭ࡳ࡭ࡳ࠯ࡹࡤࡶࡳ࠮ࠧષ")
			,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࡟ࡠࡡࡢࡣ࠭સ")
			,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡎࡲࡥࡩ࡯࡮ࡨࠢࡶ࡯࡮ࡴࠠࡧ࡫࡯ࡩ࠿࠭હ")
			]
def K0qws26HnMQlgOJe7roSTGEkZWDdb(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U):
	if xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡏࡳࡦࡪࡩ࡯ࡩࠣࡷࡰ࡯࡮ࠡࡨ࡬ࡰࡪࡀࠧ઺") in EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U and Fo1SgXMsHk(u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳࠨ઻") in EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U: return Ag9l6cw3EBqP8HsQuGMizfOtr4
	for J1rvN7I8eLXuS54mZ6lnUjg in L3LjMymkTwio5YFhgadfnBqeOxCAs:
		if J1rvN7I8eLXuS54mZ6lnUjg in EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U: return Ag9l6cw3EBqP8HsQuGMizfOtr4
	return SmbNGskjMx
def NSzWo684A1c(data):
	FUiVZn950zdoIuDAeNaGlSXxpC = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠽ഴ") if IZhXMprxvAHqBEFkg0 else fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠶࠻ള")
	data = data.replace(YayJj10OGl(u"࠳࠱വ")*S3X6GcaiExOPtb,FUiVZn950zdoIuDAeNaGlSXxpC*S3X6GcaiExOPtb)
	data = data.replace(YayJj10OGl(u"ࠫࠥࡂࡧࡦࡰࡨࡶࡦࡲ࠾࠻઼ࠢࠪ"),tM24jD1gO0(u"ࠬࡀࠠࠨઽ"))
	J27qXeRCpsgkEoT9Q0GYS6ct = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in data.splitlines():
		V8eWxOPEoKcR4sHCqi0dITMD = ScntgdOZCY74vNpXeW5jh8i.findall(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࠠࠡࠢࠣࠤࡋ࡯࡬ࡦࠢࠥࠬ࠳࠰࠿ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷ࠳࠯ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬા"),EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if V8eWxOPEoKcR4sHCqi0dITMD: EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(V8eWxOPEoKcR4sHCqi0dITMD[f4fTutDOEwUeIoPLRQ],nbOFVEDkpT4BIR7Qq82yPmHeJU)
		J27qXeRCpsgkEoT9Q0GYS6ct += wwOnIucWJj+EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U
	return J27qXeRCpsgkEoT9Q0GYS6ct
def Z8rqlOhW7vg3BFp60jmsI(u0JAhNfmEQ2x3t6XyCVU7KGr9cOb):
	if SSvu1CZjTW7FcloNqD(u"ࠧࡐࡎࡇࠫિ") in u0JAhNfmEQ2x3t6XyCVU7KGr9cOb:
		qGE580uYjRgUaIemyTKVZXWQr3f = zAJlBVmpGHYQkd7LXDP
		header = UpQ56M0dO1N9xIvVegy(u"ࠨไิหฦฯࠠศๆึะ้ࠦวๅไา๎๊ࠦฟࠨી")
	else:
		qGE580uYjRgUaIemyTKVZXWQr3f = vOxIJSfwPEpCc
		header = Fo1SgXMsHk(u"ࠩๅีฬวษࠡษ็ืั๊ࠠศๆะห้๐ࠠภࠩુ")
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,header,z3sIGH8jmLYg(u"ࠪืั๊ࠠศๆฦา฼อมࠡ์ะฮํ๐ࠠฤ์ูหࠥ฿ไ๊ࠢึะ้ࠦวๅษึฮำีวๆࠢ࠱ࠤํอไศอ้๎๋ࠦึา๊ิ๎ฮࠦไๆ฻ิๅฮࠦใ๋ใࠣัิัสࠡษ็ู้้ไส๋้ࠢฬࠦ็้ࠢส่๊้ว็ࠢส่ี๐ࠠิสหࠤาี่ฬࠢสฺ่๊ใๅหࠣ࠲้่ࠥะ์ࠣ๎าะแูࠢหืั๊๊็ࠢ࠱ࠤฬ๊ร้ๆ๋ࠣํࠦวๅีฯ่ࠥอไฮษ็๎ࠥ๎แ๋้้ࠣ฾๊่ๆษอࠤฯฮฯฤ่๊ࠢีࠦศะษํอࠥอไหึ฽๎้ࠦวๅฯส่๏ࠦไษำ้ห๊าࠠไ๊า๎ࠥ๎วๅ๋ࠣห้ศๆࠡ࠰ࠣว๊อࠠศๆึะ้ࠦวๅไา๎๊ࠦแ่๊ࠣหู้ฬๅࠢสุ่อศใࠢส่ี๐ࠠห็ࠣะ๊฿็ࠡ็้ࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢๅฬ้ࠦยฯำࠣษ฼็วยࠢ็๋ࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษ็หุะๅาษิࠤฤ࠭ૂ"))
	if oyNUHM3uQq!=ulAxHwvzR9eTb5n(u"࠲ശ"): return
	fx30OQD4Xq9h,HDYwF4bPdEQBy2lRhkisKfV9xaXr = [],bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠲ഷ")
	size,count = nHxt2Y5jIy4cWrZJ(qGE580uYjRgUaIemyTKVZXWQr3f)
	file = open(qGE580uYjRgUaIemyTKVZXWQr3f,I3cxjYaHhsrM7T4UX26klN(u"ࠫࡷࡨࠧૃ"))
	if size>DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠵࠵࠶࠲࠱࠲ഹ"): file.seek(-I3cxjYaHhsrM7T4UX26klN(u"࠴࠴࠵࠷࠰࠱സ"),Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.SEEK_END)
	data = file.read()
	file.close()
	if IZhXMprxvAHqBEFkg0: data = data.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	data = NSzWo684A1c(data)
	FV968pLETkDJwxhXlye2O5ScH = data.split(wwOnIucWJj)
	for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in reversed(FV968pLETkDJwxhXlye2O5ScH):
		UZnyPfh4RVFYlCH60X5 = K0qws26HnMQlgOJe7roSTGEkZWDdb(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
		if UZnyPfh4RVFYlCH60X5: continue
		EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(DJ6ugPjW9bX8I(u"ࠬࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡥࠧૄ"),l5JG7XwbOfo8DznU+qrjy8LuKVPNYdbSvzh(u"࠭ࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩૅ")+c7gxFyUCGm)
		EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡆࡔࡕࡓࡗࡀࠧ૆"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋ࠶࠰࠱࠲ࡠࠫે")+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡈࡖࡗࡕࡒ࠻ࠩૈ")+c7gxFyUCGm)
		DDt1YJEsXMu2wi = nbOFVEDkpT4BIR7Qq82yPmHeJU
		guwFjVmNtzrqeda63AfbG = ScntgdOZCY74vNpXeW5jh8i.findall(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪૉ"),EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if guwFjVmNtzrqeda63AfbG:
			EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ],guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]).replace(guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][QQSugEIn2mTCpRsfcaJHhPdAWzylM],nbOFVEDkpT4BIR7Qq82yPmHeJU)
			DDt1YJEsXMu2wi = guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		else:
			guwFjVmNtzrqeda63AfbG = ScntgdOZCY74vNpXeW5jh8i.findall(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫ૊"),EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if guwFjVmNtzrqeda63AfbG:
				EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR],nbOFVEDkpT4BIR7Qq82yPmHeJU)
				DDt1YJEsXMu2wi = guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ]
		if DDt1YJEsXMu2wi: EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(DDt1YJEsXMu2wi,eMypvI8XqHjYU02anWD9gsSrkt+DDt1YJEsXMu2wi+c7gxFyUCGm)
		fx30OQD4Xq9h.append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
		if len(str(fx30OQD4Xq9h))>bnI4kmPtrW7yFEhljXOCq9(u"࠺࠶࠱࠱࠲ഺ"): break
	fx30OQD4Xq9h = reversed(fx30OQD4Xq9h)
	TTAvE0f9mRyuqdnFtPL6VDJ = wwOnIucWJj.join(fx30OQD4Xq9h)
	r31rWd0qVCzeNapuFjwZg8scSIi5(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡲࡥࡧࡶࠪો"),UpQ56M0dO1N9xIvVegy(u"࠭ยฯำࠣวุ฽ัࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็ࠪૌ"),TTAvE0f9mRyuqdnFtPL6VDJ,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡶࡱࡦࡲ࡬ࡧࡱࡱࡸࡤࡲ࡯࡯ࡩ્ࠪ"))
	return
def K8rm4kDsxOeFwZVhHlI2gT():
	QPkzD4AYoLMi7suX3 = open(B2B6NE1VSfA4y8irFwbeD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡴࡥࠫ૎")).read()
	if IZhXMprxvAHqBEFkg0: QPkzD4AYoLMi7suX3 = QPkzD4AYoLMi7suX3.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	QPkzD4AYoLMi7suX3 = QPkzD4AYoLMi7suX3.replace(bYyKEjIuGQzoq3AR1(u"ࠩ࡟ࡸࠬ૏"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࠤࠥࠦࠠࠡࠢࠣࠤࠬૐ"))
	QCkFNzuGpZwqEmb = ScntgdOZCY74vNpXeW5jh8i.findall(l4DS8mnEjHhFMZ5YOe(u"ࠫ࠭ࡼ࡜ࡥ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬ૑"),QPkzD4AYoLMi7suX3,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in QCkFNzuGpZwqEmb:
		QPkzD4AYoLMi7suX3 = QPkzD4AYoLMi7suX3.replace(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U,l5JG7XwbOfo8DznU+EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U+c7gxFyUCGm)
	zU4taVvj6x12(t4txivgXSUWBOlCakQmNDjf(u"ࠬอไห฼ํ๎ึอสࠡษ็วำ๐ัสࠢไ๎ࠥอไษำส้ั࠭૒"),QPkzD4AYoLMi7suX3)
	return
def R6elFSraws0yOvHCuBXNoGEzk1():
	G8CImB4K9pN3OhHT = l4DS8mnEjHhFMZ5YOe(u"࠭ศฺุࠣห้ษาาษิࠤ฾๊้ࠡษ็ี๏๋่หࠢๆ์๋ะั้ๆࠣฮํ็ัࠡว่็ฬ์๊สࠢอๆิ๐ๅ๊ࠡอวำ๐ัࠡษ็ๅ๏ี๊้๋๋ࠢีํࠠศๆฦึึอั้ࠡํࠤฬ๊ริ้่ࠤํอไฤำๅห๊ࠦๅฺࠢห฽฻่ࠦไษ็ฮฬ๊๊ࠨ૓")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = t4txivgXSUWBOlCakQmNDjf(u"ࠧๅฬๅำ๏๋ࠠศๆไ๎ิ๐่ࠡษึฮำีๅࠡษ็ื์๋ࠠศๆํ้๏์้ࠠๆอวำ๐ั่ࠢสืฯิฯๆࠢสุ่ํๅࠡษ็๎ุอัࠡ࠰ࠣว๊อฺࠠัฬࠤฬู็ๆ่ࠢฮฯอไ๋หࠣๅ์ึ็ࠡฬๅ์๊ࠦศหฯิ๎่ࠦวๅใํำ๏๎ࠠษ๊ๅฮࠥอใษำ้๋่ࠣࠦใฬࠣหู้็ๆࠢส่ํออะࠢ࠱ࠤศ๋วࠡษ็ื์๋ࠠศๆฦ฽้๏้ࠠษ็วุ็ไࠡใ๊์ࠥ๐อาๅࠣห้็๊ะ์๋ࠤส๊้ࠡษ็ว๊อๅࠡล๋ࠤส๊้ࠡษ็์ึอม๊ࠡ็็๋ࠦศใใีอ้ࠥศ๋ำฬࠫ૔")
	Rv3xcXSYnZIK7bFNiUHweEQL0z1j = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨล่หࠥอไฤำๅห๊ࠦแ่์ࠣฮุะฮะ็่้ࠣะโะ์่ࠤํอไหลั๎ึ่ࠦๅๅ้ࠤอ๋โะษิࠤ฾ีฯࠡษ็ฯํอๆ๋๋ࠢห้ีโศศๅࠤ࠳ࠦๅฬๆสࠤึ่ๅࠡ࠷࠷࠸ࠥะู็์ࠣ࠹ࠥีโศศๅࠤํࠦ࠴࠵ࠢฮห๋๐ษࠡว็ํࠥอไฤ็ส้ࠥษ่ࠡว็ํࠥอไ้ำสลࠥฮอิสࠣหุะฮะษ่็๊ࠥไิ้่ࠤฬ๊๊ๆ์้ࠤศ๎ࠠิ้่ࠤฬ๊๊ิษิࠫ૕")
	CtO9cFuULSm62PWToMlzN1 = G8CImB4K9pN3OhHT+bnI4kmPtrW7yFEhljXOCq9(u"ࠩ࠽ࠤࠬ૖")+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs+z3sIGH8jmLYg(u"ࠪࠤ࠳ࠦࠧ૗")+Rv3xcXSYnZIK7bFNiUHweEQL0z1j
	r31rWd0qVCzeNapuFjwZg8scSIi5(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ૘"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ૙"),CtO9cFuULSm62PWToMlzN1,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࠩ૚"))
	return
def Rs07nFAOYjCQN(type,CtO9cFuULSm62PWToMlzN1,showDialogs=Ag9l6cw3EBqP8HsQuGMizfOtr4,url=nbOFVEDkpT4BIR7Qq82yPmHeJU,eg6iV4ckQxvTrjWKyBulYR=nbOFVEDkpT4BIR7Qq82yPmHeJU,J1rvN7I8eLXuS54mZ6lnUjg=nbOFVEDkpT4BIR7Qq82yPmHeJU,ldXSONaGmEQyckuhw=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	bYFZjwTuvStPop3Hy9UWan = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if not QQ3hd2tR8s.F8e4uNA5OfTIHvkg6lCJt2BZ:
		if showDialogs:
			KKj9F0tXMmW3Yg6BUaRz = (z3sIGH8jmLYg(u"ࠧศๆึ฻ึࡀࠧ૛") in CtO9cFuULSm62PWToMlzN1 and qrjy8LuKVPNYdbSvzh(u"ࠨษ็้่อๆ࠻ࠩ૜") in CtO9cFuULSm62PWToMlzN1 and QlTuvPbSpnjygBVW(u"ࠩส่๊๊แ࠻ࠩ૝") in CtO9cFuULSm62PWToMlzN1 and l4DS8mnEjHhFMZ5YOe(u"ࠪห้ิืฤࠩ૞") in CtO9cFuULSm62PWToMlzN1 and bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫฬ๊ๅึัิ࠾ࠬ૟") in CtO9cFuULSm62PWToMlzN1)
			if not KKj9F0tXMmW3Yg6BUaRz: bYFZjwTuvStPop3Hy9UWan = ttiZs4bKHFvugJj5z(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬૠ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"࠭็ๅࠢอีุ๊่ࠠา๊ࠤฬ๊ัิษ็อࠥหไ๊ࠢส่๊ฮัๆฮࠪૡ"),CtO9cFuULSm62PWToMlzN1.replace(X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࡝࡞ࡱࠫૢ"),wwOnIucWJj))
	elif showDialogs:
		CtO9cFuULSm62PWToMlzN1 = IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠาีส่ฮࡢ࡜࡯ฬ่ࠤู๊อࠡษ็ีุอไส࡞࡟ࡲฯ๋ࠠๆีะࠤฬ๊ัิษ็อࡡࡢ࡮ห็ุ้ࠣำࠠศๆิืฬ๊ษࠨૣ")
		toafI0hbendQj28LzUiN1sAHq3BS = ttiZs4bKHFvugJj5z(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡦࡩࡳࡺࡥࡳࠩ૤"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"ࠪฮ๊ࠦๅิฯࠣีุอไหๅࠪ૥")+bnI4kmPtrW7yFEhljXOCq9(u"ࠫࠥࠦ࠱࠰࠷ࠪ૦"),X1mRwt2YJKgCLu9a67(u"ࠬํไࠡฬิ๎ิࠦลาีส่ࠥืำศๆฬࠤๆอั฻หࠪ૧"))
		e351PgMrW2VnJ4KoOt0LN = ttiZs4bKHFvugJj5z(IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡣࡦࡰࡷࡩࡷ࠭૨"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧห็ุ้ࠣำࠠาีส่ฯ้ࠧ૩")+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࠢࠣ࠶࠴࠻ࠧ૪"),bnI4kmPtrW7yFEhljXOCq9(u"๊่ࠩࠥะั๋ัࠣษึูวๅࠢิืฬ๊ษࠡใสี฿ฯࠧ૫"))
		vo8F5hiPHn2a9GLUEDx = ttiZs4bKHFvugJj5z(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡧࡪࡴࡴࡦࡴࠪ૬"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫฯ๋ࠠๆีะࠤึูวๅฬๆࠫ૭")+SSvu1CZjTW7FcloNqD(u"ࠬࠦࠠ࠴࠱࠸ࠫ૮"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭็ๅࠢอี๏ีࠠฦำึห้ࠦัิษ็อࠥ็วา฼ฬࠫ૯"))
		zVIh63Of1gY2rskMjmJKG = ttiZs4bKHFvugJj5z(ulAxHwvzR9eTb5n(u"ࠧࡤࡧࡱࡸࡪࡸࠧ૰"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠨฬ่ࠤู๊อࠡำึห้ะใࠨ૱")+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࠣࠤ࠹࠵࠵ࠨ૲"),SSvu1CZjTW7FcloNqD(u"๋้ࠪࠦสา์าࠤสืำศๆࠣีุอไสࠢไหึเษࠨ૳"))
		bYFZjwTuvStPop3Hy9UWan = ttiZs4bKHFvugJj5z(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ૴"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"ࠬะๅࠡ็ึัࠥืำศๆอ็ࠬ૵")+flDSRbv57PnV3(u"࠭ࠠࠡ࠷࠲࠹ࠬ૶"),ulAxHwvzR9eTb5n(u"่ࠧๆࠣฮึ๐ฯࠡวิืฬ๊ࠠาีส่ฮࠦแศำ฽อࠬ૷"))
	vHsaM4eT5Nkx9Zt = DD98VLARlydeJU4uYk(SmbNGskjMx)
	mLtV7UBvaszXFKENic685u = YayJj10OGl(u"ࠨࡃ࡙࠾ࠥ࠭૸")+vHsaM4eT5Nkx9Zt+tM24jD1gO0(u"ࠩ࠰ࠫૹ")+type
	rsymoFnMJ3HE1z7l9T = Ag9l6cw3EBqP8HsQuGMizfOtr4 if DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ૺ") in J1rvN7I8eLXuS54mZ6lnUjg else SmbNGskjMx
	if not bYFZjwTuvStPop3Hy9UWan:
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧૻ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬะๅࠡว็฾ฬวࠠศๆศีุอไࠡส้หฦูࠦๅ๋ࠣ฻้ฮใࠨૼ"))
		return SmbNGskjMx
	DKQRwieocp = RarSo2nTfwU0WEGK.getInfoLabel(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬ૽"))
	CtO9cFuULSm62PWToMlzN1 += I3cxjYaHhsrM7T4UX26klN(u"ࠧࠡ࡞࡟ࡲࡡࡢ࡮࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽ࠡ࡞࡟ࡲࡆࡪࡤࡰࡰ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥ࠭૾")+JeVILUu027qW+t4txivgXSUWBOlCakQmNDjf(u"ࠨࠢ࠽ࡠࡡࡴࠧ૿")
	CtO9cFuULSm62PWToMlzN1 += paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡈࡱࡦ࡯࡬ࠡࡕࡨࡲࡩ࡫ࡲ࠻ࠢࠪ଀")+vHsaM4eT5Nkx9Zt+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࠤ࠿ࡢ࡜࡯ࡍࡲࡨ࡮ࠦࡖࡦࡴࡶ࡭ࡴࡴ࠺ࠡࠩଁ")+NZXC8zME6TFkOi0bpKVHLwfJydD4Ue+DJ6ugPjW9bX8I(u"ࠫࠥࡀ࡜࡝ࡰࠪଂ")
	CtO9cFuULSm62PWToMlzN1 += I3cxjYaHhsrM7T4UX26klN(u"ࠬࡑ࡯ࡥ࡫ࠣࡒࡦࡳࡥ࠻ࠢࠪଃ")+DKQRwieocp
	v47vQB5lUtqRrzjo9HDC = Se0XLol6NIhZdG8HBruT4w()
	v47vQB5lUtqRrzjo9HDC = lcxFAteLQ1Pwu45Er2(v47vQB5lUtqRrzjo9HDC)
	if v47vQB5lUtqRrzjo9HDC: CtO9cFuULSm62PWToMlzN1 += qrjy8LuKVPNYdbSvzh(u"࠭ࠠ࠻࡞࡟ࡲࡑࡵࡣࡢࡶ࡬ࡳࡳࡀࠠࠨ଄")+v47vQB5lUtqRrzjo9HDC
	if url: CtO9cFuULSm62PWToMlzN1 += UpQ56M0dO1N9xIvVegy(u"ࠧࠡ࠼࡟ࡠࡳ࡛ࡒࡍ࠼ࠣࠫଅ")+url
	if eg6iV4ckQxvTrjWKyBulYR: CtO9cFuULSm62PWToMlzN1 += O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࠢ࠽ࡠࡡࡴࡓࡰࡷࡵࡧࡪࡀࠠࠨଆ")+eg6iV4ckQxvTrjWKyBulYR
	CtO9cFuULSm62PWToMlzN1 += wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࠣ࠾ࡡࡢ࡮ࠨଇ")
	if showDialogs: SSVCGE0bOfW1w9u52yvBxocNeP(IINBvuxkCSJrO1Q0UyngdLi(u"ࠪะฬื๊ࠡษ็ษึูวๅࠩଈ"),tM24jD1gO0(u"ࠫฬ๊ัอษฤࠤฬ๊ว็ฬ฻หึ࠭ଉ"))
	if ldXSONaGmEQyckuhw:
		TTAvE0f9mRyuqdnFtPL6VDJ = ldXSONaGmEQyckuhw
		if IZhXMprxvAHqBEFkg0: TTAvE0f9mRyuqdnFtPL6VDJ = TTAvE0f9mRyuqdnFtPL6VDJ.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		TTAvE0f9mRyuqdnFtPL6VDJ = Y7goyGlxwNaP1XcWU6e.b64encode(TTAvE0f9mRyuqdnFtPL6VDJ)
	elif rsymoFnMJ3HE1z7l9T:
		if QlTuvPbSpnjygBVW(u"ࠬࡥࡐࡓࡑࡅࡐࡊࡓ࡟ࡐࡎࡇࡣࠬଊ") in J1rvN7I8eLXuS54mZ6lnUjg: VVOWSaH7K0mfTZ3eUB1rEu = zAJlBVmpGHYQkd7LXDP
		else: VVOWSaH7K0mfTZ3eUB1rEu = vOxIJSfwPEpCc
		if not Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(VVOWSaH7K0mfTZ3eUB1rEu):
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩଋ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧิฮ็ࠤฬ๊รฯูสลࠥ๎วๅษึฮำีวๆࠢ฽๎ึࠦๅ้ฮ๋ำࠬଌ"))
			return SmbNGskjMx
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨ࠰࡟ࡸࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡷࡪࡴࡤࠡࡶ࡫ࡩࠥࡲ࡯ࡨࡨ࡬ࡰࡪ࠭଍"))
		fx30OQD4Xq9h,HDYwF4bPdEQBy2lRhkisKfV9xaXr = [],xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠶഻")
		file = open(VVOWSaH7K0mfTZ3eUB1rEu,YayJj10OGl(u"ࠩࡵࡦࠬ଎"))
		size,count = nHxt2Y5jIy4cWrZJ(VVOWSaH7K0mfTZ3eUB1rEu)
		if size>tM24jD1gO0(u"࠳࠱࠳࠳࠴࠵഼"): file.seek(-tM24jD1gO0(u"࠳࠱࠳࠳࠴࠵഼"),Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.SEEK_END)
		data = file.read()
		file.close()
		data = data.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		data = NSzWo684A1c(data)
		FV968pLETkDJwxhXlye2O5ScH = data.splitlines()
		for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in reversed(FV968pLETkDJwxhXlye2O5ScH):
			UZnyPfh4RVFYlCH60X5 = K0qws26HnMQlgOJe7roSTGEkZWDdb(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
			if UZnyPfh4RVFYlCH60X5: continue
			guwFjVmNtzrqeda63AfbG = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠪࡢ࠭ࡢࡤࠬ࠯ࠫࡠࡩ࠱࠭࡝ࡦ࠮ࠤࡡࡪࠫ࠻࡞ࡧ࠯࠿ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠪࠪࠣࡘ࠿ࡢࡤࠬࠫࠪଏ"),EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if guwFjVmNtzrqeda63AfbG:
				EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ],guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]).replace(guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][QQSugEIn2mTCpRsfcaJHhPdAWzylM],nbOFVEDkpT4BIR7Qq82yPmHeJU)
			else:
				guwFjVmNtzrqeda63AfbG = ScntgdOZCY74vNpXeW5jh8i.findall(YayJj10OGl(u"ࠫࡣ࠮࡜ࡥ࠭࠽ࡠࡩ࠱࠺࡝ࡦ࠮ࡠ࠳ࡢࡤࠬࠫࠫࠤ࡙ࡀ࡜ࡥ࠭ࠬࠫଐ"),EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if guwFjVmNtzrqeda63AfbG: EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.replace(guwFjVmNtzrqeda63AfbG[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR],nbOFVEDkpT4BIR7Qq82yPmHeJU)
			fx30OQD4Xq9h.append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
			if len(str(fx30OQD4Xq9h))>z3sIGH8jmLYg(u"࠳࠷࠴࠴࠵࠶ഽ"): break
		fx30OQD4Xq9h = reversed(fx30OQD4Xq9h)
		TTAvE0f9mRyuqdnFtPL6VDJ = z3sIGH8jmLYg(u"ࠬࡢࡲ࡝ࡰࠪ଑").join(fx30OQD4Xq9h)
		TTAvE0f9mRyuqdnFtPL6VDJ = TTAvE0f9mRyuqdnFtPL6VDJ.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		TTAvE0f9mRyuqdnFtPL6VDJ = Y7goyGlxwNaP1XcWU6e.b64encode(TTAvE0f9mRyuqdnFtPL6VDJ)
	else: TTAvE0f9mRyuqdnFtPL6VDJ = nbOFVEDkpT4BIR7Qq82yPmHeJU
	url = sCSyOla9hrcE[X1mRwt2YJKgCLu9a67(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭଒")][QQSugEIn2mTCpRsfcaJHhPdAWzylM]
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = {cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡴࡷࡥ࡮ࡪࡩࡴࠨଓ"):mLtV7UBvaszXFKENic685u,UpQ56M0dO1N9xIvVegy(u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩଔ"):CtO9cFuULSm62PWToMlzN1,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩ࡯ࡳ࡬࡬ࡩ࡭ࡧࠪକ"):TTAvE0f9mRyuqdnFtPL6VDJ}
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,t4txivgXSUWBOlCakQmNDjf(u"ࠪࡔࡔ࡙ࡔࠨଖ"),url,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎ࠰࠵ࡸࡺࠧଗ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࠨࡳࡶࡥࡦࡩࡪࡪࡥࡥࠤ࠽ࠤ࠶࠲ࠧଘ") in UTvsQb4HpCP3Aeo2wDZG7X5V: EJNf2kglaiQHnFGe531Iq = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else: EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
	if showDialogs:
		if EJNf2kglaiQHnFGe531Iq:
			SSVCGE0bOfW1w9u52yvBxocNeP(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭สๆࠢส่สืำศๆࠣฬ๋าวฮࠩଙ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡔࡷࡦࡧࡪࡹࡳࠨଚ"))
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠨࡏࡨࡷࡸࡧࡧࡦࠢࡶࡩࡳࡺࠧଛ"),Fo1SgXMsHk(u"ࠩอ้ࠥหัิษ็ࠤฬ๊ัิษ็อࠥฮๆอษะࠫଜ"))
		else:
			SSVCGE0bOfW1w9u52yvBxocNeP(Fo1SgXMsHk(u"่้ࠪษำโࠢไุ้ࠦวๅวิืฬ๊ࠧଝ"),bYyKEjIuGQzoq3AR1(u"ࠫࡋࡧࡩ࡭ࡷࡵࡩࠬଞ"))
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨଟ"),Fo1SgXMsHk(u"࠭ฮุลࠣ์ๆฺไࠡใํࠤสืำศๆࠣห้ืำศๆฬࠫଠ"))
	return EJNf2kglaiQHnFGe531Iq
def Loigwze48U1V2AcspRGfJb7E():
	G8CImB4K9pN3OhHT = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠲࠰ࠣࠤࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࡼ࡯ࡴࡩࠢࡄࡶࡦࡨࡩࡤࠢࡷࡩࡽࡺࡴࠡࡶ࡫ࡩࡳࠦࡧࡰࠢࡷࡳࠥࠨࡋࡰࡦ࡬ࠤࡎࡴࡴࡦࡴࡩࡥࡨ࡫ࠠࡔࡧࡷࡸ࡮ࡴࡧࡴࠤࠣࡥࡳࡪࠠࡤࡪࡤࡲ࡬࡫ࠠࡵࡪࡨࠤ࡫ࡵ࡮ࡵࠢࡷࡳࠥࠨࡁࡳ࡫ࡤࡰࠧ࠭ଡ")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨ࠳࠱ࠤࠥࠦลัษ่ࠣิ๐ใࠡ็ื็้ฯࠠโ์ࠣห้ษอาใࠣห้฿ัษ์ฬࠤๆอะ่สࠣษ้๏ࠠฦ฻าหิอส๊ࠡสะ์ฯࠠไ๊า๎ࠥัๅࠡ฼ํีࠥอไฯูࠣห้๋ำหะา้ࠥหไ๊ࠢࠥࡅࡷ࡯ࡡ࡭ࠤࠪଢ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠩࡄࡶࡦࡨࡩࡤࠢࡓࡶࡴࡨ࡬ࡦ࡯ࠪଣ"),G8CImB4K9pN3OhHT+t4txivgXSUWBOlCakQmNDjf(u"ࠪࡠࡳࡢ࡮ࠨତ")+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs)
	G8CImB4K9pN3OhHT = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫ࠷࠴ࠠࠡࠢࡌࡪࠥࡿ࡯ࡶࠢࡦࡥࡳࡢࠧࡵࠢࡩ࡭ࡳࡪࠠࠣࡃࡵ࡭ࡦࡲࠢࠡࡨࡲࡲࡹࠦࡴࡩࡧࡱࠤࡨ࡮ࡡ࡯ࡩࡨࠤࡹ࡮ࡥࠡࡵ࡮࡭ࡳࠦࡡ࡯ࡦࠣࡸ࡭࡫࡮ࠡࡥ࡫ࡥࡳ࡭ࡥࠡࡶ࡫ࡩࠥ࡬࡯࡯ࡶࠪଥ")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = UpQ56M0dO1N9xIvVegy(u"ࠬ࠸࠮ࠡࠢࠣษีอࠠๅ็ࠣฮัีࠠศๆั฻ࠥࠨࡁࡳ࡫ࡤࡰࠧࠦแใ็ࠣฬฯเ๊๋ำࠣห้าไะࠢฮ้่ࠥๅࠡสอ฾๏ืࠠศๆั฻ࠥอไๆีอาิ๋ࠠฦๆ์ࠤࠧࡇࡲࡪࡣ࡯ࠦࠬଦ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡆࡰࡰࡷࠤࡕࡸ࡯ࡣ࡮ࡨࡱࠬଧ"),G8CImB4K9pN3OhHT+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࡝ࡰ࡟ࡲࠬନ")+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs)
	G8CImB4K9pN3OhHT = t4txivgXSUWBOlCakQmNDjf(u"ࠨ࠵࠱ࠤࠥࠦࡉࡧࠢࡼࡳࡺࠦࡤࡰࡰ࡟ࠫࡹࠦࡨࡢࡸࡨࠤࡆࡸࡡࡣ࡫ࡦࠤࡐ࡫ࡹࡣࡱࡤࡶࡩࠦࡴࡩࡧࡱࠤ࡬ࡵࠠࡵࡱࠣࠦࡐࡵࡤࡪࠢࡌࡲࡹ࡫ࡲࡧࡣࡦࡩ࡙ࠥࡥࡵࡶ࡬ࡲ࡬ࡹࠢࠡࡣࡱࡨࠥࡩࡨࡢࡰࡪࡩࠥࡺࡨࡦࠢࡵࡩ࡬࡯࡯࡯ࡣ࡯ࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭଩")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = YayJj10OGl(u"ࠩ࠶࠲ࠥࠦࠠฦาสࠤ้๋๋ࠠๅ้ࠤ้ี๊ไࠢ็์าฯࠠๆใสฮ๏ำฺࠠำห๎ฮࠦแศา๊ฬࠥหไ๊ࠢศ฽ิอฯศฬࠣ์ฬา็สࠢๆ์ิ๐ࠠฬ็ࠣ฾๏ืࠠฦ฻าหิอสࠡษ็้๋฽โสࠢส่ัเัศใํอࠬପ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠪࡊࡴࡴࡴࠡࡒࡵࡳࡧࡲࡥ࡮ࠩଫ"),G8CImB4K9pN3OhHT+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡡࡴ࡜࡯ࠩବ")+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs)
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬଭ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"࠭ࡆࡰࡰࡷࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠭ମ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡅࡱࠣࡽࡴࡻࠠࡸࡣࡱࡸࠥࡺ࡯ࠡࡩࡲࠤࡹࡵࠠࠣࡍࡲࡨ࡮ࠦࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦࠢࡖࡩࡹࡺࡩ࡯ࡩࡶࠦࠥࡴ࡯ࡸࠢࡂࠫଯ")+Fo1SgXMsHk(u"ࠨ࡞ࡱࡠࡳ࠭ର")+l4DS8mnEjHhFMZ5YOe(u"๊่ࠩࠥะั๋ัࠣห้ึ็ศสࠣษ้๏ࠠๅ๊ะอࠥหูะษาหฯ่ࠦศฮ๊อ้่ࠥะ์ࠣว้ศๆภࠩ଱"))
	if oyNUHM3uQq==bnI4kmPtrW7yFEhljXOCq9(u"࠳ാ"): MMRo1cWwGLKV0aJp()
	return
def StWOzhfK24yb8dgCRUuo9qsc():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ଲ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫ฿อไษษࠣหู้ศษ๊ࠢ์๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡษ็้฿ึ๊ࠡๆ็ฬึ์วๆฮࠣ์้๊สฤๅาࠤ็๋ࠠษฬื฾๏๊ࠠศๆิหอ฽ࠠศๆำ๎๊ࠥวࠡ์฼้้ࠦหๆࠢๅ้ࠥฮลาีส่๋ࠥิไๆฬࠤส๊้ࠡษ็้อืๅอ่๊ࠢࠥอไใษษ้ฮࠦวๅำษ๎ุ๐ษࠡๆ็ฬึ์วๆฮࠪଳ"))
	return
def SBeVKC0dk3nx49oHhbaAMR2jEwg6W():
	CtO9cFuULSm62PWToMlzN1 = UpQ56M0dO1N9xIvVegy(u"ࠬํะศࠢส่อืๆศ็ฯࠤ๊ิีึࠢไๆ฼ࠦไๅ฼ฬࠤฬู๊าสํอࠥ๎ไไ่๋ࠣีอࠠๅษࠣ๎๊์ู๊ࠡฯ์ิࠦๅ้ษๅ฽ࠥ็๊่ษࠣวๆ๊วๆุ๋้๊ࠢำๅษอࠤ๊ะัอ็ฬࠤศ๎ࠠๆัห่ัฯࠠฦๆ์ࠤฬ๊ไ฻หࠣห้฿ัษ์ฬࠤํอไ๊ࠢ็฾ฬะࠠศะิํࠥ๎ไศࠢํ์ัีࠠิสหࠤ้๊สไำสีࠬ଴")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩଵ"),CtO9cFuULSm62PWToMlzN1)
	return
def MMF6AXf0OHIKZVc3iWCLrRBp8TSldy():
	CtO9cFuULSm62PWToMlzN1 = bnI4kmPtrW7yFEhljXOCq9(u"ࠧศๆิ์ฬฮืࠡษ็ฬ฼๐ฦสࠢ็หࠥ฿ไศไฬࠤ้ํวࠡสส่อืๆศ็ฯࠤํเวๅสสࠤฬ๊ำษส๋ࠣํࠦๅ็ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠢส่๊เะ๋ࠢ็่อืๆศ็ฯࠫଶ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫଷ"),CtO9cFuULSm62PWToMlzN1)
	return
def XXozK8CcxhYS3DlNguHVbPLQ():
	CtO9cFuULSm62PWToMlzN1 = cb3rmvAn4wa6lBPz2phOoYqX(u"๊ࠩ๎ู๊ࠥาใิหฯࠦไศࠢํืฯ฽ฺ๊ࠢส่อืๆศ็ฯࠤฬูสฯัส้์อࠠษีหฬ้่ࠥ็้สࠤ๊ำๅ๋ห้๋ࠣࠦวๅ็ุำึࠦร้ࠢหัฬาษࠡว็ํࠥอิหำส็ࠥืำๆ์ࠣวํࠦฬะ์าอࠥษ่ࠡๆสࠤ๏฿ัโ้สࠤฬ๊ศา่ส้ั࠭ସ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ହ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ุࠫ๐ัโำสฮู๊ࠥวหࠣวํࠦๅอ้๋่ฮ࠭଺"),CtO9cFuULSm62PWToMlzN1)
	return
def yURQG0os7Cz():
	CtO9cFuULSm62PWToMlzN1 = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬอไิ์ิๅึอสࠡษ็฽ฬ๋ษ้ࠡํࠤุ๐ัโำสฮࠥิวาฮํอࠥ๎ฺ๋ำࠣฮฬฮูสࠢ็่๊๎โฺࠢส่ศ฻ไ๋๋ࠢะ๊๐ูࠡษ็้ํอโฺࠢอืฯิฯๆ้สࠤํ฿วะหࠣฮ่๎ๆࠡ็ฯห๋๐ษุ๊่ࠡฬ้ไ่ษࠣ็ะ๐ัสࠢ็ห๋ࠦวๅใํำ๏๎็ศฬࠣๅ๏ํวࠡว่หࠥฮื๋ศฬࠤศ๎ࠠๆ็้์฾ฯࠠฤ๊้ࠣาึ่โหࠣวํࠦแ๋้สࠤฺ๊ใๅหࠣั็๎โࠡษ็้้้๊ส࡞ࡱࡠࡳࡢ࡮ศๆึ๎ึ็ัศฬࠣห้ิวึห๋ࠣ๏ࠦำ๋ำไีฬะࠠหษห฽ฮࠦไๅ็๋ๆ฾ࠦวๅลุ่๏่ࠦๆีอาิ๋ษࠡใํࠤ๊๎วใ฻ࠣๆ้๐ไสࠢฯำฬฺ่ࠦษาอࠥะใ้่้ࠣิ็ฺ่หࠣห้ษฬาࠢฦ์ࠥ๐ๅๅๅ๊หࠥอไๆ๊ๅ฽ࠥอไฤื็๎ࠥ๎ไ่าสࠤๆํ๊ࠡฮํำฮࠦๆิสํหࠥ๎ำา์฼อࠥ๎ๅีษๆ่์อࠠใๆํ่ฮࠦฬะษࠪ଻")
	r31rWd0qVCzeNapuFjwZg8scSIi5(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡣࡦࡰࡷࡩࡷ଼࠭"),fgv5U2eRVaQqSiuGD(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪଽ"),CtO9cFuULSm62PWToMlzN1,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫା"))
	return
def RRYSPftNdOaMA291xjyK0XcoTJnpg():
	G8CImB4K9pN3OhHT = SSvu1CZjTW7FcloNqD(u"ࠩสฬฯ฿ฯࠡ฻้ࠤ๊๊แศฬࠣห้ีโสࠢส่฾อไ๋หࠪି")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪหอะูะࠢ฼๊๋ࠥไโษอࠤศ๊ࠠ࡮࠵ࡸ࠼ࠬୀ")
	Rv3xcXSYnZIK7bFNiUHweEQL0z1j = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫฬฮสฺัࠣ฽๋ࠦๅๅใสฮࠥอไหฯ่๎้่ࠦศๆาหํ์ไ้ัࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠬୁ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨୂ"),G8CImB4K9pN3OhHT,dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs,Rv3xcXSYnZIK7bFNiUHweEQL0z1j)
	return
def VfhJAnDWzB6u2ysbR():
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭วๅๅสุࠥํ่ࠡ็ัึ๋ࠦๅลไอࠤ้๊ๅฺๆ๋้ฬะ๋ࠠีอาิ๋็ࠡษ็ฬึ์วๆฮ่ࠣำุๆࠡืไัฬะࠠศๆศ๊ฯืๆ๋ฬࠣ์ึ๎วษูࠣห้็๊ะ์๋๋ฬะࠠๅๆู๋ํ๊ࠠฦๆํ๋ฬࠦศิำ฼อࠥ๎ศะ๊้ࠤส์สา่ํฮࠥ๎วๅสิ๊ฬ๋ฬࠡ์่ืาํวࠡฬ็ๆฬฬ๊ศࠢห฽ิࠦว็ฬ๊หฦูࠦๆำ๊หࠥ๎รุ๋สࠤ฾์ฯࠡฬะำ๏ัࠠศๆหี๋อๅอࠢ࠱ࠤํํะศࠢส่อืๆศ็ฯࠤ๏ูสฯั่ࠤุฮูสࠢฦ๊ํอูࠡๆ฼้ึࠦวๅๅสุࠥࡀࠧୃ")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += YayJj10OGl(u"ࠧ࡝ࡰ࡟ࡲࠬୄ") + wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨ࠳࠱ࠤะอศหࠢ็ฺ่็อศฬࠣห้ะ๊ࠡ็฼ีํ็ࠠฤ่๊ห๊ࠥวࠡฬอ฾๏ืࠠ็้สส๏อ้ࠠ็าฮ์ࠦࠧ୅") + str(p2CSGfkREb6TuDtas9yFPrU1e3NWL7/O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠹࠴ി")/O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠹࠴ി")/fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠶࠹ീ")/DJ6ugPjW9bX8I(u"࠸࠶ു")) + X60YQOADpkHBb31LiR5qUEKfM(u"ุࠩࠣ์ืࠧ୆")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj + UpQ56M0dO1N9xIvVegy(u"ࠪ࠶࠳ࠦฬะษࠣ฻ํ๐ไࠡษ็้ิ๏ࠠๅๆุๅาอสࠡษ็้ๆื่ืࠢฦ๊์อࠠๅษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩେ") + str(rXKp4uqLMW3v/IINBvuxkCSJrO1Q0UyngdLi(u"࠼࠰ൂ")/IINBvuxkCSJrO1Q0UyngdLi(u"࠼࠰ൂ")/YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠲࠵ൃ")) + QlTuvPbSpnjygBVW(u"ࠫࠥ๐่ๆࠩୈ")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj + flDSRbv57PnV3(u"ࠬ࠹࠮ู๋ࠡ๎้ࠦวๅ็าํ๊ࠥไึใะหฯࠦวๅฬํࠤ๋อฯาษࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩ୉") + str(mmfpkVtUDjaq86eAuFzE0oxP/wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠷࠲ൄ")/wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠷࠲ൄ")/bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠴࠷൅")) + ulAxHwvzR9eTb5n(u"๋๊่࠭ࠠࠫ୊")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj + yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧ࠵࠰้ࠣฯ๎ำุࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠใัࠣฮฯเ๊า๋้ࠢิะ็ࠡࠩୋ") + str(RRYx6sACloVPr3td95Ej/Fo1SgXMsHk(u"࠹࠴െ")/Fo1SgXMsHk(u"࠹࠴െ")) + t4txivgXSUWBOlCakQmNDjf(u"ࠨࠢึห฾ฯࠧୌ")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj + X1mRwt2YJKgCLu9a67(u"ࠩ࠸࠲่ࠥี๋ำࠣห้๋ฯ๊ࠢ็ฺ่็อศฬࠣห้ะ๊ࠡฬอ฾๏ืࠠะษษ้ฬ่ࠦๆัอ୍๋ࠥ࠭") + str(pOLDXnFW5V6cTw7ikm/DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠺࠵േ")/DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠺࠵േ")) + fgv5U2eRVaQqSiuGD(u"ࠪࠤุอูสࠩ୎")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj + tM24jD1gO0(u"ࠫ࠻࠴ࠠอัสࠤ็฻๊าࠢส่๊ี้ࠡๆ็ูๆำวหࠢส่ฯ๐ࠠหฬ฽๎ึࠦใฬ์ิหࠥ๎ๅะฬ๊ࠤࠬ୏") + str(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl/Fo1SgXMsHk(u"࠻࠶ൈ")) + xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࠦฯใ์ๅอࠬ୐")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += wwOnIucWJj + bnI4kmPtrW7yFEhljXOCq9(u"࠭࠷࠯ࠢหำํ์ࠠไษืࠤ้๊ีโฯสฮࠥอไห์ࠣฮฯเ๊าࠢหืึ฿ษ๊่ࠡำฯํࠠࠨ୑") + str(zDoPOYNsJg2id1HLnx5bpf) + X1mRwt2YJKgCLu9a67(u"ࠧࠡัๅ๎็ฯࠧ୒")
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += z3sIGH8jmLYg(u"ࠨ࡞ࡱࡠࡳ࠭୓") + yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"่ࠩฯ้อ࠺ࠡืไัฬะࠠใ๊สส๊ࠦวๅลไ่ฬ๋้ࠠษ็ุ้๊ำๅษอࠤํอไฮๆๅหฯูࠦๆำ๊หࠥ࠭୔") + str(RRYx6sACloVPr3td95Ej/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")) + Fo1SgXMsHk(u"ࠪࠤุอูสࠢ࠱ࠤศ๋วࠡไ๋หห๋ࠠฤ่๋ห฾ࠦวๅใํำ๏๎็ศฬࠣๅ฾๋ั่ษࠣࠫ୕") + str(mmfpkVtUDjaq86eAuFzE0oxP/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")/usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠲࠵ൊ")) + qrjy8LuKVPNYdbSvzh(u"ࠫࠥษ๊ศ็ࠣ࠲ࠥษๅศ่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢไ฽๊ื็ศࠢࠪୖ") + str(pOLDXnFW5V6cTw7ikm/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")) + QlTuvPbSpnjygBVW(u"ࠬࠦำศ฻ฬࠤๆ่ืࠡ࠰ࠣว๊อࠠโฯุࠤึ่ๅࠡษ็ษฺีวาࠢไ฽๊ื็ࠡࠩୗ") + str(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl/bnI4kmPtrW7yFEhljXOCq9(u"࠼࠰൉")) + qrjy8LuKVPNYdbSvzh(u"࠭ࠠะไํๆฮࠦ࠮ࠡล่หࠥ็อึࠢสุฯืวไࠢใࡍࡕ࡚ࡖࠡใ฼้ึํࠠࠨ୘") + str(zDoPOYNsJg2id1HLnx5bpf) + l4DS8mnEjHhFMZ5YOe(u"ࠧࠡัๅ๎็ฯࠧ୙")
	r31rWd0qVCzeNapuFjwZg8scSIi5(QlTuvPbSpnjygBVW(u"ࠨࡴ࡬࡫࡭ࡺࠧ୚"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"่ࠩหࠥํ่ࠡษ็็ฬฺࠠศๆ่ืฯิฯๆࠢไ๎ࠥอไษำ้ห๊าࠧ୛"),dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs,SSvu1CZjTW7FcloNqD(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭ଡ଼"))
	return
def JHpfXDNhv7ZVQg12EIRayx5u():
	CtO9cFuULSm62PWToMlzN1 = DJ6ugPjW9bX8I(u"ࠫฬ๊แศื็อࠥะู็์้ࠣั๊ฯࠡส้ๅุࠦวิ็๊ࠤฬ๊รึๆํࠤํอไ็ไฺอࠥะู็์ࠣว๋ࠦวๅษึ้ࠥอไฤื็๎ࠥะๅࠡฬ฼ำ๏๊็๊ࠡไหฺ๊ษ๊้ࠡๆ฼ฯࠠห฻้ํ๋ࠥฬๅัࠣ์ฯ๋ࠠห฻า๎้ࠦวิ็๊ࠤํฮฯ้่ࠣ฽้อๅสࠢอ฽๋๐ࠠๆๆไࠤอ์แิࠢสื๊ํࠠศๆฦู้๐ࠧଢ଼")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ୞"),CtO9cFuULSm62PWToMlzN1)
	return
def pCs27GybvnheKlct():
	CtO9cFuULSm62PWToMlzN1 = qrjy8LuKVPNYdbSvzh(u"࠭ลัษࠣ์ฬา็หๅู้้ࠣไสࠢไ๎ࠥอไีสๆอࠥ๎สๆࠢะ่์อࠠ࠯࠰࠱ࠤศ๎ࠠศ่ๆࠤฯ฾ๆࠡล้ࠤฬ๊ๅ้ไ฼ࠤฬ๊รึๆํࠤ่อๆࠡใํ๋๋ࠥิไๆฬࠤ๊สโห้ࠣ์ฯ๋ࠠฮๆ๊หࠥ࠴࠮࠯ࠢไษี์ࠠอำหࠤู๊อࠡๅสุࠥอไษำ้ห๊าࠠๅๅํࠤ๏่่ๆࠢส่อืๆศ็ฯࠤอ฽ไษࠢสฺ่็อสࠢสฺ่ำ๊ฮหࠣ์ฯิา๋่๊หࠥฮฯๅษ้๋ࠣࠦวๅืไัฮࠦวๅไา๎๊ฯࠧୟ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪୠ"),CtO9cFuULSm62PWToMlzN1)
	return
def tQjFJdYIRHUGa1():
	CtO9cFuULSm62PWToMlzN1 = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨษ็฾ึ฼ࠠๆุ่ࠣ์อฯสࠢส่ฯฺแ๋ำ๋ࠣํࠦึๆษ้ࠤฺำษ๊ࠡึี๏ฯࠠศๆ่฽้๎ๅศฬࠣห้๋สษษา่ฮࠦศ๋่ࠣห้ฮั็ษ่ะࠥ๎วๅ็๋ๆ฾ࠦวๅ็ืๅึ่่ࠦาสࠤฬ๊ึๆษ้ࠤ฿๐ัࠡ็ฺ่ํฮ้ࠠๆสࠤาอฬสࠢ็๋ࠥ฿ๆะࠢส่ฬะีศๆࠣหํࠦวๅำห฻ู๋ࠥࠡ็๋ห็฿ࠠศๆไ๎ิ๐่่ษอࠤฬ๊ๅีใิอࠬୡ")
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬୢ"),CtO9cFuULSm62PWToMlzN1)
	return
def dKNJ5y9ORx6scLXMTzWu0a3w8():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ୣ"),QlTuvPbSpnjygBVW(u"้้๊ࠫࠡ์฼้้ࠦ็ัษࠣห้์ฺ่่๊ࠢࠥอไโ์า๎ํํวหࠢ࡟ࡲࠥ๐ฬษࠢอๅ฾๐ไࠡวูหๆฯࠠศี่๋ฬࠦ࡜࡯ࠢ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ୤"))
	tjoDTklcueMPnHqI9yg(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ୥"),Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return
def Rjf3hV67FDG0St():
	CtO9cFuULSm62PWToMlzN1  = xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ๅละิห่ࠥวๆฬࠣฬ฾฼ࠠีำๆหฯࠦวๅว้ฮึ์สࠡษ็ำํ๊๊ࠡสฺ๋฾ูࠦศศๅࠤ฻ีࠠศๆหีฬ๋ฬࠡ็ฮ่้่ࠥะ์่ࠣฯูๅฮࠢไๆ฼ࠦไษ฻ูࠤู๊สฯั่๎ࠥอไๆฬุๅาࠦศศๆาาํ๊ࠠๅ็๋ห็฿ࠠศๆไ๎ิ๐่ࠨ୦")
	CtO9cFuULSm62PWToMlzN1 += tM24jD1gO0(u"๊้ࠧࠡฮ๏าษࠡๆ๊ิฬࠦวๅ฻สส็ࠦแศ่๊ࠤฯ่ั๋สสࠤัฺ๋๊่ࠢืฯิฯๆ์ࠣฬึ์วๆฮࠣ็ํี๊ࠡๆสࠤ๏ูสุ์฼์๋ࠦวๅัั์้ࠦไอ็ํ฽๋่ࠥศไ฼ࠤฬ๊ศา่ส้ัࠦอห๋้ࠣ฾ࠦวิฬัำฬ๋ࠧ୧")
	CtO9cFuULSm62PWToMlzN1 += wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨโࠣࠤ࡛ࡖࡎࠡࠢฦ์ࠥࠦࡐࡳࡱࡻࡽࠥࠦร้ࠢࠣࡈࡓ࡙ࠠࠡล๋ࠤศ๐ࠠฮๆࠣฬุ๐ืࠡฤัีࠬ୨")+c7gxFyUCGm+wwOnIucWJj
	CtO9cFuULSm62PWToMlzN1 += paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩ࡟ࡲ้อๆ้ࠡำห๊ࠥๆࠡ์ะ่ࠥอไๆึๆ่ฮ่ࠦฦ่่หࠥ็โุࠢึ๎็๎ๅࠡสศู้ออࠡส฼ฺࠥอไๆ๊สๆ฾่ࠦฦ฻สๆฮࠦๅ้ษๅ฽ࠥอฮา๋ࠣ็ฬ์สࠡฬ฼้้ࠦำศสๅหࠥฮฯู้่้ࠣอใๅࠩ୩")
	r31rWd0qVCzeNapuFjwZg8scSIi5(tM24jD1gO0(u"ࠪࡶ࡮࡭ࡨࡵࠩ୪"),DJ6ugPjW9bX8I(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ୫"),CtO9cFuULSm62PWToMlzN1,t4txivgXSUWBOlCakQmNDjf(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨ୬"))
	CtO9cFuULSm62PWToMlzN1 = l4DS8mnEjHhFMZ5YOe(u"࠭วๅ็๋ห็฿ࠠศๆอ๎ࠥะรฬำอࠤออไฺษษๆࠥ฿ๆะࠢห฽฻ࠦวๅ่สืࠥํ๊࠻ࠩ୭")
	CtO9cFuULSm62PWToMlzN1 += wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡢ࡭ࡲࡥࡲࠦࠠࡦࡩࡼࡦࡪࡹࡴࠡࠢࡨ࡫ࡾࡨࡥࡴࡶࡹ࡭ࡵࠦࠠ࡮ࡱࡹ࡭ࡿࡲࡡ࡯ࡦࠣࠤࡸ࡫ࡲࡪࡧࡶ࠸ࡼࡧࡴࡤࡪࠣࠤࡸ࡮ࡡࡩ࡫ࡧ࠸ࡺ࠭୮")+c7gxFyUCGm
	CtO9cFuULSm62PWToMlzN1 += qrjy8LuKVPNYdbSvzh(u"ࠨ࡞ࡱࡠࡳ࠭୯")+UpQ56M0dO1N9xIvVegy(u"ࠩส่ิ๎ไࠡษ็ฮ๏ࠦสฤอิฮࠥฮวๅ฻สส็ูࠦ็ัࠣฬ฾฼ࠠศๆ้หุࠦ็๋࠼ࠪ୰")
	CtO9cFuULSm62PWToMlzN1 += wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+cb3rmvAn4wa6lBPz2phOoYqX(u"ฺ้ࠪืࠠࠡษ็็ํ๐สࠡࠢฦ้๏ืใศࠢࠣ็๋ีวࠡࠢไีู๋วࠡࠢส่๏๎ๆศ่ࠣࠤอืุ๊ษ้๎ฬࠦวๅว่หึอสࠡล็้ฬ์๊ศࠢิ์ุ๐วࠡษ็๎ฬฮว็ࠢสุ่฿่ะ์ฬࠤึ๎ๅศ่ํหࠥํ่ๅ่าหࠬୱ")+c7gxFyUCGm
	CtO9cFuULSm62PWToMlzN1 += q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡡࡴ࡜࡯ࠩ୲")+YayJj10OGl(u"ࠬอไๆสิ้ั่ࠦอัࠣ฻ึ๐โสࠢ็ฮัอ่ำࠢส่฾อฦใ๋่่ࠢ์็ศࠢอัฯอฬࠡฮ๊ำ้ࠥศ๋ำࠣ์ฬ๊ๅษำ่ะࠥ๐ุ็ࠢสฺ่๊ใๅหูࠣ฿๐ัส๋่ࠢฬࠦสิฬะๆࠥอไห฻หࠤๆหะศࠢ็ำ๏้ࠠๆึๆ่ฮࠦศศๆาาํ๊ࠠๅส฼ฺࠥอไๆ๊สๆ฾่ࠦฤ์ูห๊ࠥใ๋ࠢํฮ฻ำࠠฮฮ่ࠤฬ๊ๅีๅ็อࠥ࠭୳")
	CtO9cFuULSm62PWToMlzN1 += eMypvI8XqHjYU02anWD9gsSrkt+t4txivgXSUWBOlCakQmNDjf(u"࠭วาี็ࠤึูวๅห้ࠣษีศสࠢศ่๎ࠦวๅ็หี๊า้ࠠษๆฮอࠦแ๋้สࠤฬูๅࠡส็ำ่่ࠦฤี่หฦࠦวๅ็๋ห็฿ࠠศๆอ๎๊ࠥวࠡฬึฮ฼๐ูࠡัั์้ํวࠨ୴")+c7gxFyUCGm
	r31rWd0qVCzeNapuFjwZg8scSIi5(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭୵"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ୶"),CtO9cFuULSm62PWToMlzN1,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬ୷"))
	return
def EHgGjsScrXDMZ2ebCNhJld():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪฯ้อหูࠡิๆ๊ࠥไห๊สู้ࠦๅฺࠢส่๊ฮัๆฮࠪ୸"),DJ6ugPjW9bX8I(u"ࠫศืำๅࠢิืฬ๊ษࠡล๋ࠤฺ๊ใๅห้๋ࠣࠦโศศ่อࠥิฯๆษอࠤ์ึวࠡษ็ฬึ์วๆฮ࡟ࡲࡡࡴร้ࠢหหุะฮะษ่ࠤฬ๊แ๋ีห์่ࠦระ่ส๋ࡡࡴࠧ୹")+eMypvI8XqHjYU02anWD9gsSrkt+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡡࡤࡧࡥࡳࡴࡱ࠮ࡤࡱࡰ࠳ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࠵࠴࠶࠾ࠧ୺")+c7gxFyUCGm+SSvu1CZjTW7FcloNqD(u"࠭࡜࡯࡞ࡱวํࠦศศำึห้ࠦว๋็ํ่ࠥอไ๊ࠢฦำ๋อ็ࠡࠢ࡟ࡲࠥ࠭୻")+eMypvI8XqHjYU02anWD9gsSrkt+l4DS8mnEjHhFMZ5YOe(u"ࠧࡢࡴࡤࡦ࡮ࡩࡶࡪࡦࡨࡳࡸ࠸࠰࠲࠺ࡃ࡫ࡲࡧࡩ࡭࠰ࡦࡳࡲ࠭୼")+c7gxFyUCGm)
	return
def CQpWYzAoaNZE9Tq7mDFtnw():
	VfhJAnDWzB6u2ysbR()
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ୽"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"๊่ࠩࠥะั๋ัุ้ࠣำࠠอ็ํ฽ࠥอไไษืࠤฤ࠭୾"),UpQ56M0dO1N9xIvVegy(u"ࠪห้้วีࠢํืึ฿ฺࠠ็็ࠤฬ๊ศา่ส้ั่ࠦๆีะ๋ࠥ๐ู๋ัࠣืาฮࠠศๆุๅาอสࠡ็้ࠤฬ๊ล็ฬิ๊ฯูࠦ็ัࠣห้ำวอหࠣษ้๐็ศ๋ࠢห้๋ำฮࠢํฮ๊ࠦสๅไสส๏อฺ่ࠠาࠤฬ์ส่ษฤࠤ฾๋ัࠡษ็ูๆำวห๋ࠢห้๋ำฮࠢ็หࠥ๐ึา๋้๊้ࠢๆࠡ์ะ่ࠥฮูืࠢสฺ่๊วไๆࠪ୿"))
	if oyNUHM3uQq==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠲ോ"):
		NrCbofjFaXYHOd0htmn(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫฯ๋ࠠๆีะࠤ่อิࠡษ็ฬึ์วๆฮࠣฬฬ๊ใศ็็ࠫ஀"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬหะศࠢๆห๋ะฺ่ࠠา็๋ࠥิไๆฬࠤๆ๐ࠠศฯาࠤฬ๊ๅ้ษๅ฽ࠥ็ฬาสࠣห้๋่ใ฻ࠣห้ศๆࠡ࠰࠱࠲ࠥ๎รัษࠣห้๋ิไๆฬࠤู๊สๆำฬࠤๆหะ็ࠢสีุ๊ࠠศๆุ่่๊ษࠡว็ํࠥอไๆสิ้ั࠭஁"))
	return oyNUHM3uQq
def p7yhd4XJcbTZnRSKgC1(showDialogs=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	if not showDialogs: showDialogs = Ag9l6cw3EBqP8HsQuGMizfOtr4
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,SSvu1CZjTW7FcloNqD(u"࠭ࡇࡆࡖࠪஂ"),l4DS8mnEjHhFMZ5YOe(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡻࡥࡲࡶ࡬ࡦ࠰ࡦࡳࡲ࠭ஃ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡌ࡙࡚ࡐࡔࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ஄"))
	if not cnPhVmgFxA.succeeded:
		qqVEFYoBu7ULiAkC89way3pzstD = SmbNGskjMx
		RM8ZdQkKxUFIDTz573 = Op47XGBbfiolxenLkTdyPrW6Z(SmbNGskjMx)
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+DJ6ugPjW9bX8I(u"ࠩࠣࠤࠥࡎࡔࡕࡒࡖࠤࡋࡧࡩ࡭ࡧࡧࠤࠥࠦࡌࡢࡤࡨࡰ࠿ࡡࠧஅ")+RM8ZdQkKxUFIDTz573+l4DS8mnEjHhFMZ5YOe(u"ࠪࡡࠬஆ"))
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧஇ"),X1mRwt2YJKgCLu9a67(u"ࠬ็อึࠢส่ฬะีศๆࠣห้๋ิโำࠣ࠲࠳࠴ࠠๆึๆ่ฮࠦ࠮࠯࠰ࠣห้อสึษ็ࠤฬ๊ๅีใิࠤ࠭อไาสฺࠤฬ๊ๅีใิ๊࠭ࠥวࠡ์฼ู้้ࠦ็ัๆࠤ฾๊้ࠡๅ๋ำ๏ࠦ࠮࠯࠰ࠣ์฾์ฯไࠢๆ์ิ๐ࠠ฻์ิࠤ็อฯาࠢ฼่๎ࠦวิฬัำฬ๋ࠠศๆ่์ฬู่ࠡษ็ู้็ัสࠩஈ"))
	else:
		qqVEFYoBu7ULiAkC89way3pzstD = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩஉ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧอ์าࠤัีวࠡ࠰࠱࠲ࠥอไศฬุห้ࠦวๅ็ืๅึࠦࠨศๆิฬ฼ࠦวๅ็ืๅึ࠯๋ࠠ฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦโศัิࠤ฾๊้ࠡษึฮำีวๆࠢส่๊๎วใ฻ࠣห้๋ิโำฬࠫஊ"))
	if not qqVEFYoBu7ULiAkC89way3pzstD and showDialogs: ee6Bl0wZGrv()
	return qqVEFYoBu7ULiAkC89way3pzstD
def ee6Bl0wZGrv():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ஋"),qrjy8LuKVPNYdbSvzh(u"ࠩห฽฻ࠦวๅ็๋ห็฿ࠠหฯอหัࠦัษูู้ࠣ็ั๊ࠡๅำࠥ๐ใ้่ࠣะ์อาไࠢ฽๎ึࠦโศัิࠤ฾๊้ࠡษ็ีอ฽ࠠศๆุ่ๆืࠠฤ๊๋๋ࠣอใࠡ็ื็้ฯࠠโ์ุࠣ์อฯสࠢส่ฯฺแ๋ำࠣห้ิวึหࠣฬ่๎ฯ๋ࠢ฼๊ิฺ้ࠠๆ่หࠥอๆ่ࠢอ้ࠥ็อึࠢส่อืๆศ็ฯࠤ฾๊้ࠡๅ๋ำ๏ࠦวๅวุำฬืวหࠢ࡟ࡲࠥ࠷࠷࠯࠸ࠣࠤࠫࠦࠠ࠲࠺࠱࡟࠵࠳࠹࡞ࠢࠣࠪࠥࠦ࠱࠺࠰࡞࠴࠲࠹࡝ࠨ஌"))
	ZONuL1gdCb9JlK48yPavn3r()
	return
def IbOgDw5uNE16VosCFnShBl(J1rvN7I8eLXuS54mZ6lnUjg=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	rsymoFnMJ3HE1z7l9T = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if t4txivgXSUWBOlCakQmNDjf(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭஍") not in J1rvN7I8eLXuS54mZ6lnUjg:
		rsymoFnMJ3HE1z7l9T = SmbNGskjMx
		CH74LFlzUW3gkcxe2P = YuqCtbB0XfT6rGUwS5z79VDk3del2E(IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡨ࡫࡮ࡵࡧࡵࠫஎ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬิั้ฮࠪஏ"),X1mRwt2YJKgCLu9a67(u"࠭ลาีส่๋ࠥิไๆฬࠫஐ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧฦำึห้ࠦัิษ็อࠬ஑"),fgv5U2eRVaQqSiuGD(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫஒ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"๊่ࠩࠥะั๋ัࠣว๋ࠦสาี็ࠤึูวๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬࠡ࠰࠱ࠤศ๋ࠠหำํำࠥษๆࠡฬิื้ࠦๅีๅ็อ๋่ࠥอ๊าอࠥ็๊ࠡษ็ฬึ์วๆฮࠣรࠬஓ"))
		if CH74LFlzUW3gkcxe2P in [-bnI4kmPtrW7yFEhljXOCq9(u"࠳ൌ"),QlTuvPbSpnjygBVW(u"࠳്")]: return
		elif CH74LFlzUW3gkcxe2P==bnI4kmPtrW7yFEhljXOCq9(u"࠵ൎ"):
			rsymoFnMJ3HE1z7l9T = Ag9l6cw3EBqP8HsQuGMizfOtr4
			J1rvN7I8eLXuS54mZ6lnUjg = t4txivgXSUWBOlCakQmNDjf(u"ࠪࡣࡕࡘࡏࡃࡎࡈࡑࡤ࠭ஔ")
	if rsymoFnMJ3HE1z7l9T:
		if DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࡤࡖࡒࡐࡄࡏࡉࡒࡥࡏࡍࡆࡢࠫக") not in J1rvN7I8eLXuS54mZ6lnUjg:
			oyNUHM3uQq = ttiZs4bKHFvugJj5z(YayJj10OGl(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ஖"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"่࠭ื฻ࠣห้๋ิไๆฬࠤๆ๐ࠠศๆึะ้࠭஗"),l4DS8mnEjHhFMZ5YOe(u"ࠧใส็ࠤสืำศๆࠣหู้ฬๅࠢ฼่๏้ࠠฤ่ࠣฮ่ืั้ࠡࠢๅุࠦวๅใ฼่ࠥอไั์ࠣว฾฽วไࠢสฺ่๊ใๅหࠣ࠲๊ࠥใ๋ࠢํฮ๊ࠦสิฮํ่ࠥํะ่ࠢสฺ่๊ใๅหࠣๅ๏ࠦำอๆࠣห้ษฮุษฤࠤํอไศีอาิอๅࠡ࠰ࠣ์อี่็๊ࠢิฬࠦวๅฬึะ๏๊ࠠิ๊ไࠤฯืำๅ่่ࠢๆࠦไศࠢไหหีษࠡ็้๋๊ࠥล็้่ࠣฬ๊ࠦฮฬ๋๎ࠥ฿ไ๊ࠢสฺ่๊ใๅหࠣห้ะ๊ࠡฬิ๎ิࠦว็ฬࠣห้หศๅษ฽ࠤ฾์็ศࠢ࠱ࠤ์๊ࠠใ็อࠤอะใาษิࠤฬ๊ๅีๅ็อࠥลࠧ஘"))
			if oyNUHM3uQq!=UpQ56M0dO1N9xIvVegy(u"࠶൏"):
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠨฬ่ࠤสฺ๊ศรࠣห้หัิษ็ࠫங"),bYyKEjIuGQzoq3AR1(u"ࠩ็่ศูแࠡสา์๋ࠦสิฮํ่ࠥอไๆึๆ่ฮࠦแ๋ࠢึะ้ࠦวๅลั฻ฬว้ࠠษ็หุะฮะษ่ࠤๆอๆࠡษ็้อืๅอࠢ็หࠥ๐ำหูํ฽ู๋ࠥาใฬࠤฬ๊ๅีๅ็อࠥ๎ไศࠢะ่์อࠠๅษ้ࠤฬ๊ๅษำ่ะ๊ࠥวࠡ์฼่๊ࠦวๅ฼ํฬࠬச"))
				return
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭஛"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫๆ๐ࠠศๆืหูฯࠠศๆๅหิ๋ษࠡฯส์้ࠦร็ࠢอ็ฯฮࠠาีส่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤํอิาฯࠣๅ๏ํวࠡษ็ู้้ไสࠢฦ์ࠥอไๆู๊์฾่ࠦฦาสࠤศืฯหࠢฯ์ฬฮࠠๆ่ࠣห้๋ศา็ฯࠤๆหะ็ࠢฦ็ฯฮฺ่๋ࠠห๋ࠦศา์า็ࠥษไฦๆๆฮึ๎ๆ๋ࠢส่ส๐ๅ๋ๆࠣ์ฯึใา๋่ࠢฬࠦส็ี์ࠤศ์ࠠศๆ่ฬึ๋ฬࠡๆสࠤ๏฿ไๆࠢส่฿๐ศࠨஜ"))
	search = dR75Vq2gprfHmUcNhG(header=z3sIGH8jmLYg(u"ࠬ࡝ࡲࡪࡶࡨࠤࡦࠦ࡭ࡦࡵࡶࡥ࡬࡫ࡥࠡࠢࠣห่ะศࠡำึห้ฯࠧ஝"),source=QSJFrwB3dMiyH2mTPKD9a)
	if not search: return
	CtO9cFuULSm62PWToMlzN1 = search
	if rsymoFnMJ3HE1z7l9T: type = z3sIGH8jmLYg(u"࠭ࡐࡳࡱࡥࡰࡪࡳࠧஞ")
	else: type = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡎࡧࡶࡷࡦ࡭ࡥࠨட")
	EJNf2kglaiQHnFGe531Iq = Rs07nFAOYjCQN(type,CtO9cFuULSm62PWToMlzN1,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"ࠨࡇࡐࡅࡎࡒ࠭ࡇࡔࡒࡑ࠲࡛ࡓࡆࡔࡖࠫ஠"),J1rvN7I8eLXuS54mZ6lnUjg)
	return
def Ppr0d5ewGFXL9Z():
	J1rvN7I8eLXuS54mZ6lnUjg = bnI4kmPtrW7yFEhljXOCq9(u"๊ࠩิฬࠦวๅสิ๊ฬ๋ฬࠡๆสࠤ๏๎ฬะࠢ็๋ࠥษ๊ࠡีํีๆื๋ࠠีอฺ๏็ࠠฤ์้ࠣาะ่๋ษอ࠲ࠥอไษำ้ห๊า๋ࠠีอาิ๋ࠠา๊สฬ฼่ࠦหุ่๎๋ࠦไๆฯอ์๏อสࠡ็ิๅํ฿ษࠡ฻็ํู๊ࠥาใิหฯࠦฮศำฯ๎ฮ࠴ࠠศๆหี๋อๅอࠢ฽๎ึࠦๅิฦ๋่ࠥ฿ๆࠡลํࠤ๊ำส้์สฮࠥะๅࠡฬะ้๏๊็ศࠢ฼่๎ࠦำ๋ำไีฬะ้ࠠ็๋ห็฿ࠠฯษิะ๏ฯࠠࠣ็๋ห็฿ุࠠำไࠤะอไฬࠤ࠱ࠤัฺ๋๊ࠢส่ศูๅศรࠣ์ฬ๊ๅศำๆหฯ่ࠦศๆุ์ึ่ࠦศๆู่๊๎ัศฬ๋ࠣ๏ࠦฮศืฬࠤออีฮษห๋ฬ࠴ࠠศๆหี๋อๅอࠢ็หࠥ๐ๆห้ๆࠤา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠤࡉࡓࡃࡂࠢศิฬࠦใศ่่ࠣิ๐ใࠡึๆ์๎ࠦฮศืฬࠤออไา๊สฬ฼่ࠦศๆอฺฬ๋๊็ࠢส่ำอัอ์ฬࠤๆอไาฮสลࠥอไห๊สู้ࠦๅฺࠢศำฬืษ้ࠡำ๋ࠥอไิ์ิๅึอส๊ࠡส่๊๎วใ฻ࠣห้ิวาฮํอ࠳ࠦ็ัษࠣห้ฮั็ษ่ะࠥํ่ࠡสหืฬ฽ษࠡ็อูๆำࠠๅ็๋ห็฿ࠠศๆ๋๎อ࠭஡")
	r31rWd0qVCzeNapuFjwZg8scSIi5(Fo1SgXMsHk(u"ࠪࡶ࡮࡭ࡨࡵࠩ஢"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫา่่ใࠢส่฼ฮู๊ࠡสฺ่๋ั๊ࠡๅห๋๎ๆࠡษ็ว้็๊สࠢ็่๊๊ใ๋หࠣห้ืโๆ์ฬࠫண"),J1rvN7I8eLXuS54mZ6lnUjg,tM24jD1gO0(u"ࠬࡺࡥࡹࡶࡹ࡭ࡪࡽ࡟ࡣ࡫ࡪࡪࡴࡴࡴࠨத"))
	J1rvN7I8eLXuS54mZ6lnUjg = l4DS8mnEjHhFMZ5YOe(u"࠭ࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡩࡱࡶࡸࠥࡧ࡮ࡺࠢࡦࡳࡳࡺࡥ࡯ࡶࠣࡳࡳࠦࡡ࡯ࡻࠣࡷࡪࡸࡶࡦࡴ࠱ࠤࡎࡺࠠࡰࡰ࡯ࡽࠥࡻࡳࡦࡵࠣࡰ࡮ࡴ࡫ࡴࠢࡷࡳࠥ࡫࡭ࡣࡧࡧࡨࡪࡪࠠࡤࡱࡱࡸࡪࡴࡴࠡࡶ࡫ࡥࡹࠦࡷࡢࡵࠣࡹࡵࡲ࡯ࡢࡦࡨࡨࠥࡺ࡯ࠡࡲࡲࡴࡺࡲࡡࡳࠢࡲࡲࡱ࡯࡮ࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡪࡲࡷࡹ࡯࡮ࡨࠢࡶ࡭ࡹ࡫ࡳ࠯ࠢࡄࡰࡱࠦࡴࡳࡣࡧࡩࡲࡧࡲ࡬ࡵ࠯ࠤࡻ࡯ࡤࡦࡱࡶ࠰ࠥࡺࡲࡢࡦࡨࠤࡳࡧ࡭ࡦࡵ࠯ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࠥࡳࡡࡳ࡭ࡶ࠰ࠥࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࡦࡦࠣࡻࡴࡸ࡫࠭ࠢ࡯ࡳ࡬ࡵࡳࠡࡴࡨࡪࡪࡸࡥ࡯ࡥࡨࡨࠥ࡮ࡥࡳࡧ࡬ࡲࠥࡨࡥ࡭ࡱࡱ࡫ࠥࡺ࡯ࠡࡶ࡫ࡩ࡮ࡸࠠࡳࡧࡶࡴࡪࡩࡴࡪࡸࡨࠤࡴࡽ࡮ࡦࡴࡶࠤ࠴ࠦࡣࡰ࡯ࡳࡥࡳ࡯ࡥࡴ࠰ࠣࡘ࡭࡫ࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠡ࡫ࡶࠤࡳࡵࡴࠡࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡥࡰࡪࠦࡦࡰࡴࠣࡻ࡭ࡧࡴࠡࡱࡷ࡬ࡪࡸࠠࡱࡧࡲࡴࡱ࡫ࠠࡶࡲ࡯ࡳࡦࡪࠠࡵࡱࠣ࠷ࡷࡪࠠࡱࡣࡵࡸࡾࠦࡳࡪࡶࡨࡷ࠳ࠦࡗࡦࠢࡸࡶ࡬࡫ࠠࡢ࡮࡯ࠤࡨࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࡰࡹࡱࡩࡷࡹࠬࠡࡶࡲࠤࡷ࡫ࡣࡰࡩࡱ࡭ࡿ࡫ࠠࡵࡪࡤࡸࠥࡺࡨࡦࠢ࡯࡭ࡳࡱࡳࠡࡥࡲࡲࡹࡧࡩ࡯ࡧࡧࠤࡼ࡯ࡴࡩ࡫ࡱࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣࡥࡷ࡫ࠠ࡭ࡱࡦࡥࡹ࡫ࡤࠡࡵࡲࡱࡪࡽࡨࡦࡴࡨࠤࡪࡲࡳࡦࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦ࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡࡧࡰࡦࡪࡪࡤࡦࡦࠣࡥࡷ࡫ࠠࡧࡴࡲࡱࠥࡵࡴࡩࡧࡵࠤࡻࡧࡲࡪࡱࡸࡷࠥࡹࡩࡵࡧࡶ࠲ࠥࡏࡦࠡࡻࡲࡹࠥ࡮ࡡࡷࡧࠣࡥࡳࡿࠠ࡭ࡧࡪࡥࡱࠦࡩࡴࡵࡸࡩࡸࠦࡰ࡭ࡧࡤࡷࡪࠦࡣࡰࡰࡷࡥࡨࡺࠠࡢࡲࡳࡶࡴࡶࡲࡪࡣࡷࡩࠥࡳࡥࡥ࡫ࡤࠤ࡫࡯࡬ࡦࠢࡲࡻࡳ࡫ࡲࡴࠢ࠲ࠤ࡭ࡵࡳࡵࡧࡵࡷ࠳ࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡵ࡬ࡱࡵࡲࡹࠡࡣࠣࡻࡪࡨࠠࡣࡴࡲࡻࡸ࡫ࡲ࠯ࠩ஥")
	r31rWd0qVCzeNapuFjwZg8scSIi5(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧ࡭ࡧࡩࡸࠬ஦"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡆ࡬࡫࡮ࡺࡡ࡭ࠢࡐ࡭ࡱࡲࡥ࡯ࡰ࡬ࡹࡲࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࡄࡧࡹࠦࠨࡅࡏࡆࡅ࠮࠭஧"),J1rvN7I8eLXuS54mZ6lnUjg,X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡷࡩࡽࡺࡶࡪࡧࡺࡣࡧ࡯ࡧࡧࡱࡱࡸࠬந"))
	return
def Fh13bDf9RwJ78eHnLYs5BKiTONz():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ன"),fgv5U2eRVaQqSiuGD(u"ࠫฬ๊ศา่ส้ัࠦไศࠢํๅา฻ࠠี้สำฮࠦวๅฬืๅ๏ืฺ่ࠠาࠤฬ๊วหืส่ࠥฮวๅ็๋ห็฿ࠠศๆุ่ๆืษ๊ࠡ็๋ีอࠠโ์ࠣัฬ๊้ࠠฮ๋ำฺࠥ็ศัฬࠤ฿๐ัࠡืะ๎าฯࠠฤ๊้๋ࠣะ็๋หࠣห้฻ไศฯํอࠥษ่ࠡ็ี๎ๆฯࠠโษ้ࠤ์ึวࠡๆ้ࠤ๏๎โโࠢส่ึฮืࠡษ็ู้็ั๊ࠡ็๊ࠥ๐่ใใࠣ฽๊๊ࠠศๆหี๋อๅอࠩப"))
	tQjFJdYIRHUGa1()
	return
def RoJNZAHlUE4mi3ygrs8LweTaIj2dbC():
	G8CImB4K9pN3OhHT,dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs,Rv3xcXSYnZIK7bFNiUHweEQL0z1j,amIcByjdlx5ktPVoh2WvQOXsLzi,zNk6ExiBAPCd,ZZ4oUQLSbzpjskD8fi,euozKVlDb584FkI = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	iugaeRtZ5HFw7mJc9AdTbKlLV2,zPJWEVNxflr,C4CW0SOrUyj,UUtGxTQPayKoSRZXjdW3 = {fgv5U2eRVaQqSiuGD(u"ࠬࡧࠧ஫"):qrjy8LuKVPNYdbSvzh(u"࠭ࡡࠨ஬")},{},[],{}
	url = sCSyOla9hrcE[fgv5U2eRVaQqSiuGD(u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ஭")][vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,QlTuvPbSpnjygBVW(u"ࠨࡒࡒࡗ࡙࠭ம"),url,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡚࡙ࡁࡈࡇࡢࡖࡊࡖࡏࡓࡖ࠰࠵ࡸࡺࠧய"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(SSvu1CZjTW7FcloNqD(u"࡙ࠪࡳ࡯ࡴࡦࡦࠣࡗࡹࡧࡴࡦࡵࠪர"),SSvu1CZjTW7FcloNqD(u"࡚࡙ࠫࡁࠨற"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(qrjy8LuKVPNYdbSvzh(u"࡛ࠬ࡮ࡪࡶࡨࡨࠥࡑࡩ࡯ࡩࡧࡳࡲ࠭ல"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡕࡌࠩள"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡖࡰ࡬ࡸࡪࡪࠠࡂࡴࡤࡦࠥࡋ࡭ࡪࡴࡤࡸࡪࡹࠧழ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡗࡄࡉࠬவ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡖࡥࡺࡪࡩࠡࡃࡵࡥࡧ࡯ࡡࠨஶ"),l4DS8mnEjHhFMZ5YOe(u"ࠪࡏࡘࡇࠧஷ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡓࡵࡲࡵࡪࠣࡑࡦࡩࡥࡥࡱࡱ࡭ࡦ࠭ஸ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡔ࠮ࡎࡣࡦࡩࡩࡵ࡮ࡪࡣࠪஹ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(X1mRwt2YJKgCLu9a67(u"࠭ࡗࡦࡵࡷࡩࡷࡴࠠࡔࡣ࡫ࡥࡷࡧࠧ஺"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡘ࠰ࡖࡥ࡭ࡧࡲࡢࠩ஻"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(DJ6ugPjW9bX8I(u"ࠨࡡࡢࡣࠬ஼"),BhmzEC6OGD7FXZig9Tp5A)
	try: sPtJj3hm84NCqXy2Y97fzvipT = dr1zfnatJxRHSF48jh0eODm5bGu(t4txivgXSUWBOlCakQmNDjf(u"ࠩ࡯࡭ࡸࡺࠧ஽"),UTvsQb4HpCP3Aeo2wDZG7X5V)
	except:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ா"),Fo1SgXMsHk(u"ࠫๆฺไࠡใํࠤั๊ศࠡ็ะฮํ๐วหࠢอๆึ๐ัࠡษ็หุะฮะษ่ࠫி"))
		return
	Pq9BR2SWKDfzl7V5JgFanyuYAwo,Zvoub325xB47H,xMC73mfFOWaSP49Rvg = sPtJj3hm84NCqXy2Y97fzvipT
	UUtGxTQPayKoSRZXjdW3 = {}
	Qs28USmnvqY5uD = [usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡉࡁࡑࡖࡆࡌࡆࡏࡄࠨீ"),X1mRwt2YJKgCLu9a67(u"࠭ࡃࡂࡒࡗࡇࡍࡇࡔࡐࡍࡈࡒࠬு")]
	J4QWBXf7O1kPpi5y9VqUZc = [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡂࡎࡏࠫூ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ௃"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡌࡒࡘ࡚ࡁࡍࡎࠪ௄"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡑࡊ࡚ࡒࡐࡒࡒࡐࡎ࡙ࠧ௅"),Fo1SgXMsHk(u"ࠫࡗࡋࡐࡐࡕࠪெ")]+Qs28USmnvqY5uD+VdLvezkAg9+nNJReWPO2VqzBymsZjGDhdr8MFg1
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER,HZdW8C1zapUqxePrEugJMjn,pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr in Zvoub325xB47H:
		pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr)
		pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr = pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr.strip(S3X6GcaiExOPtb).strip(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࠦ࠮ࠨே"))
		amIcByjdlx5ktPVoh2WvQOXsLzi += wwOnIucWJj+l5JG7XwbOfo8DznU+HMPtOcVoJiXCu8z0nesDWYkIl9ER+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭࠺ࠡࠩை")+c7gxFyUCGm+pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr+wwOnIucWJj
		if HZdW8C1zapUqxePrEugJMjn.isdigit():
			UUtGxTQPayKoSRZXjdW3[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = int(HZdW8C1zapUqxePrEugJMjn)
			if int(HZdW8C1zapUqxePrEugJMjn)>X1mRwt2YJKgCLu9a67(u"࠷࠰࠱൐"): HZdW8C1zapUqxePrEugJMjn = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡩ࡫ࡪ࡬ࡺࡹࡡࡨࡧࠪ௉")
			else: HZdW8C1zapUqxePrEugJMjn = ulAxHwvzR9eTb5n(u"ࠨ࡮ࡲࡻࡺࡹࡡࡨࡧࠪொ")
		if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in J4QWBXf7O1kPpi5y9VqUZc:
			if   HZdW8C1zapUqxePrEugJMjn==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࡫࡭࡬࡮ࡵࡴࡣࡪࡩࠬோ"): G8CImB4K9pN3OhHT += BhmzEC6OGD7FXZig9Tp5A+HMPtOcVoJiXCu8z0nesDWYkIl9ER
			elif HZdW8C1zapUqxePrEugJMjn==qrjy8LuKVPNYdbSvzh(u"ࠪࡰࡴࡽࡵࡴࡣࡪࡩࠬௌ"): dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs += BhmzEC6OGD7FXZig9Tp5A+HMPtOcVoJiXCu8z0nesDWYkIl9ER
	b015xEWXZG4eyUvtq9T6OuF8,o1oTyG3n75jiaYerutPZ0dhqs,cWBUy3v9egEd5RN0Lp = list(zip(*Zvoub325xB47H))
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER in sorted(bdUDyYZK6lieXvtP):
		if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in b015xEWXZG4eyUvtq9T6OuF8:
			amIcByjdlx5ktPVoh2WvQOXsLzi += wwOnIucWJj+l5JG7XwbOfo8DznU+HMPtOcVoJiXCu8z0nesDWYkIl9ER+I3cxjYaHhsrM7T4UX26klN(u"ࠫ࠿்ࠦࠧ")+c7gxFyUCGm+Fo1SgXMsHk(u"๊ࠬวࠡ์๋ะิ࠭௎")+cb3rmvAn4wa6lBPz2phOoYqX(u"࠭࡜࡯࡞ࡱࠫ௏")
			if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in J4QWBXf7O1kPpi5y9VqUZc: Rv3xcXSYnZIK7bFNiUHweEQL0z1j += BhmzEC6OGD7FXZig9Tp5A+HMPtOcVoJiXCu8z0nesDWYkIl9ER
	for pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr,HDYwF4bPdEQBy2lRhkisKfV9xaXr in Pq9BR2SWKDfzl7V5JgFanyuYAwo:
		pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr)
		zNk6ExiBAPCd += pY3oL0d8UQBjTMa2XgxkmIbHfCDRWr+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧ࠻ࠢࠪௐ")+eMypvI8XqHjYU02anWD9gsSrkt+str(HDYwF4bPdEQBy2lRhkisKfV9xaXr)+c7gxFyUCGm+UpQ56M0dO1N9xIvVegy(u"ࠨࠢࠣࠤࠬ௑")
	G8CImB4K9pN3OhHT = G8CImB4K9pN3OhHT.strip(S3X6GcaiExOPtb)
	dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs.strip(S3X6GcaiExOPtb)
	Rv3xcXSYnZIK7bFNiUHweEQL0z1j = Rv3xcXSYnZIK7bFNiUHweEQL0z1j.strip(S3X6GcaiExOPtb)
	toZ4n765X8zFp9BO3Ky2keG1N = G8CImB4K9pN3OhHT+BhmzEC6OGD7FXZig9Tp5A+dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs
	LySqdUiNpk8cxrA  = q4izXt0sjIQSZcHVAf3EmKRbx(u"่ࠩ์ฬู่่ࠡฯัࠥอไษำ้ห๊าࠠษฬื฾๏๊ࠠโ์า๎ํํวหࠢไ๎ࠥ࠹ࠠฤ์ส้ࠥอไๆษู๎ฮ࠭௒")+wwOnIucWJj+tM24jD1gO0(u"ࠪ์์ึวࠡ็฼๊ฬํࠠฦาสࠤ้ี๊ไุ่่๊ࠢษࠡใ๊๎๊๊ࠥิฬ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠨ௓")+wwOnIucWJj
	LySqdUiNpk8cxrA += eMypvI8XqHjYU02anWD9gsSrkt+toZ4n765X8zFp9BO3Ky2keG1N+c7gxFyUCGm+bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡡࡴ࡜࡯ࠩ௔")
	LySqdUiNpk8cxrA += Fo1SgXMsHk(u"๋่ࠬศไ฼ࠤ้๋๋ࠠึ฽่ࠥอไษำ้ห๊าࠠๆ่๊หࠥ็๊ะ์๋๋ฬะࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠫ௕")+wwOnIucWJj+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"่่࠭าสࠤ๊฿ๆศ้ࠣหาะๅศๆࠣ็อ๐ั๊ࠡฯ์ิࠦๅีๅ็อࠥ็๊ࠡษ็ฬึ์วๆฮࠪ௖")+wwOnIucWJj
	LySqdUiNpk8cxrA += eMypvI8XqHjYU02anWD9gsSrkt+Rv3xcXSYnZIK7bFNiUHweEQL0z1j+c7gxFyUCGm
	TctOY3LVXMCk9i4P1ZdxKA,QMjl1NiDF5Ia8JdHRh7B0,Fz17WJ6j0gU38kx9cl5a2OL4f,usEAZWIGTjwP = bYyKEjIuGQzoq3AR1(u"࠰൑"),bYyKEjIuGQzoq3AR1(u"࠰൑"),bYyKEjIuGQzoq3AR1(u"࠰൑"),bYyKEjIuGQzoq3AR1(u"࠰൑")
	all = UUtGxTQPayKoSRZXjdW3[fgv5U2eRVaQqSiuGD(u"ࠧࡂࡎࡏࠫௗ")]
	if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡒ࡜ࡘࡍࡕࡎࠨ௘") in list(UUtGxTQPayKoSRZXjdW3.keys()): TctOY3LVXMCk9i4P1ZdxKA = UUtGxTQPayKoSRZXjdW3[bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡓ࡝࡙ࡎࡏࡏࠩ௙")]
	if qrjy8LuKVPNYdbSvzh(u"ࠪࡍࡓ࡙ࡔࡂࡎࡏࠫ௚") in list(UUtGxTQPayKoSRZXjdW3.keys()): QMjl1NiDF5Ia8JdHRh7B0 = UUtGxTQPayKoSRZXjdW3[X1mRwt2YJKgCLu9a67(u"ࠫࡎࡔࡓࡕࡃࡏࡐࠬ௛")]
	if bYyKEjIuGQzoq3AR1(u"ࠬࡓࡅࡕࡔࡒࡔࡔࡒࡉࡔࠩ௜") in list(UUtGxTQPayKoSRZXjdW3.keys()): Fz17WJ6j0gU38kx9cl5a2OL4f = UUtGxTQPayKoSRZXjdW3[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡍࡆࡖࡕࡓࡕࡕࡌࡊࡕࠪ௝")]
	if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡓࡇࡓࡓࡘ࠭௞") in list(UUtGxTQPayKoSRZXjdW3.keys()): usEAZWIGTjwP = UUtGxTQPayKoSRZXjdW3[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡔࡈࡔࡔ࡙ࠧ௟")]
	SCuKt2HGZ7MU = all-TctOY3LVXMCk9i4P1ZdxKA-QMjl1NiDF5Ia8JdHRh7B0-Fz17WJ6j0gU38kx9cl5a2OL4f-usEAZWIGTjwP
	uiazRbmZ63Je21WGqn,h8QMNtnZ3KEJsF0umUDo = xMC73mfFOWaSP49Rvg[f4fTutDOEwUeIoPLRQ]
	uiazRbmZ63Je21WGqn,SP7HN5oftQRxs2kMzVqAei = xMC73mfFOWaSP49Rvg[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	SmRHoW0gieGA2QCIEwhVKP = h8QMNtnZ3KEJsF0umUDo-SP7HN5oftQRxs2kMzVqAei
	euozKVlDb584FkI += l5JG7XwbOfo8DznU+str(SP7HN5oftQRxs2kMzVqAei)+c7gxFyUCGm+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩส่฾ีฯࠡษ็ั็๐โ๋ࠢ็่ศา็ำหࠣ࠾ࠥ࠭௠")
	euozKVlDb584FkI += wwOnIucWJj+l5JG7XwbOfo8DznU+str(SmRHoW0gieGA2QCIEwhVKP)+c7gxFyUCGm+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪฬฬูสฯัส้ࠥࡶࡲࡰࡺࡼࠤศ๎ࠠࡷࡲࡱࠤ࠿ࠦࠧ௡")
	euozKVlDb584FkI += wwOnIucWJj+l5JG7XwbOfo8DznU+str(h8QMNtnZ3KEJsF0umUDo)+c7gxFyUCGm+X60YQOADpkHBb31LiR5qUEKfM(u"ࠫฬู๊ะัࠣห้้ไ๋ࠢ็ะ๊๐ูࠡษ็วัําสࠢ࠽ࠤࠬ௢")
	euozKVlDb584FkI += wwOnIucWJj+l5JG7XwbOfo8DznU+str(len(xMC73mfFOWaSP49Rvg[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠳൒"):]))+c7gxFyUCGm+fgv5U2eRVaQqSiuGD(u"ࠬ฿ฯะࠢส่ิ๎ไࠡษ็ฮ๏ࠦแ๋้สࠤศา็ำหࠣ࠾ࠥࡢ࡮࡝ࡰࠪ௣")
	for OORJ1AnN4w,vHsaM4eT5Nkx9Zt in xMC73mfFOWaSP49Rvg[wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠴൓"):]:
		OORJ1AnN4w = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(OORJ1AnN4w)
		OORJ1AnN4w = OORJ1AnN4w.strip(S3X6GcaiExOPtb).strip(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࠠ࠯ࠩ௤"))
		euozKVlDb584FkI += OORJ1AnN4w+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠻ࠢࠪ௥")+eMypvI8XqHjYU02anWD9gsSrkt+str(vHsaM4eT5Nkx9Zt)+c7gxFyUCGm+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࠢࠣࠤࠬ௦")
	ZZ4oUQLSbzpjskD8fi += l5JG7XwbOfo8DznU+str(SCuKt2HGZ7MU)+c7gxFyUCGm+z3sIGH8jmLYg(u"ࠩไ๎ิ๐่่ษอࠤฬฺส฻ๆอࠤ࠿ࠦࠧ௧")
	ZZ4oUQLSbzpjskD8fi += wwOnIucWJj+l5JG7XwbOfo8DznU+str(TctOY3LVXMCk9i4P1ZdxKA)+c7gxFyUCGm+fgv5U2eRVaQqSiuGD(u"ࠪ฻้ฮวหࠢึ๎ึ็ัࠡสส๎ะ๎ๆࠡ࠼ࠣࠫ௨")
	ZZ4oUQLSbzpjskD8fi += wwOnIucWJj+l5JG7XwbOfo8DznU+str(usEAZWIGTjwP)+c7gxFyUCGm+X60YQOADpkHBb31LiR5qUEKfM(u"ࠫ฼๊ศศฬࠣื๏ืแาࠢสู่๊ส้ั฼ࠤ࠿ࠦࠧ௩")
	ZZ4oUQLSbzpjskD8fi += wwOnIucWJj+l5JG7XwbOfo8DznU+str(QMjl1NiDF5Ia8JdHRh7B0)+c7gxFyUCGm+YayJj10OGl(u"ࠬะหษ์อࠤฯ฽ศ๋ไࠣ็ํี๊ࠡ฻่หิࠦ࠺ࠡࠩ௪")
	ZZ4oUQLSbzpjskD8fi += wwOnIucWJj+l5JG7XwbOfo8DznU+str(Fz17WJ6j0gU38kx9cl5a2OL4f)+c7gxFyUCGm+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭สฬสํฮࠥาไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢ࠽ࠤࠬ௫")
	ZZ4oUQLSbzpjskD8fi += wwOnIucWJj+l5JG7XwbOfo8DznU+str(len(Pq9BR2SWKDfzl7V5JgFanyuYAwo))+c7gxFyUCGm+tM24jD1gO0(u"ࠧะ๊็ࠤูเไหࠢไ๎ิ๐่่ษอࠤ࠿ࠦࠧ௬")
	ZZ4oUQLSbzpjskD8fi += UpQ56M0dO1N9xIvVegy(u"ࠨ࡞ࡱࡠࡳ࠭௭")+zNk6ExiBAPCd
	r31rWd0qVCzeNapuFjwZg8scSIi5(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡦࡩࡳࡺࡥࡳࠩ௮"),SSvu1CZjTW7FcloNqD(u"ࠪ฽ิีࠠศๆฦะ์ุษࠡษ็ฮ๏ࠦวิฬัำ๊ะ่ࠠาสࠤฬ๊ศา่ส้ัࠦแ๋ࠢ࠶ࠤศ๐วๆࠢส่๊อึ๋หࠣๅ๏ࠦวๅ฻ส่๊ࠦใๅ้ࠪ௯"),euozKVlDb584FkI,bYyKEjIuGQzoq3AR1(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧ௰"))
	r31rWd0qVCzeNapuFjwZg8scSIi5(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ௱"),SSvu1CZjTW7FcloNqD(u"ู࠭ะัࠣห้็๊ะ์๋๋ฬะࠠศๆอ๎ฺฺࠥๅ้สࠤ์ึวࠡษ็ฬึ์วๆฮࠣๅ๏ࠦ࠳ࠡลํห๊ࠦวๅ็สฺ๏ฯࠠโ์ࠣห้฿วๅ็ࠣ็้ํࠧ௲"),ZZ4oUQLSbzpjskD8fi,UpQ56M0dO1N9xIvVegy(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪ௳"))
	r31rWd0qVCzeNapuFjwZg8scSIi5(bYyKEjIuGQzoq3AR1(u"ࠨࡥࡨࡲࡹ࡫ࡲࠨ௴"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"่ࠩ์ฬู่ࠡษืฮ฿๊สࠡใํࠤ࠸ࠦร๋ษ่ࠤฬ๊ๅศุํอࠥ็๊ࠡษ็฽ฬ๊ๅࠡๅ็๋ࠬ௵"),LySqdUiNpk8cxrA,fgv5U2eRVaQqSiuGD(u"ࠪࡸࡪࡾࡴࡷ࡫ࡨࡻࡤࡨࡩࡨࡨࡲࡲࡹ࠭௶"))
	r31rWd0qVCzeNapuFjwZg8scSIi5(I3cxjYaHhsrM7T4UX26klN(u"ࠫࡱ࡫ࡦࡵࠩ௷"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬษูๅ๋ࠣห้ี่ๅࠢส่ฯ๐ࠠโ์ࠣ࠷ࠥษ๊ศ็ࠣห้๋วื์ฬࠤฬูสฯั่ฮࠥอไษำ้ห๊าࠧ௸"),amIcByjdlx5ktPVoh2WvQOXsLzi,Fo1SgXMsHk(u"࠭ࡴࡦࡺࡷࡺ࡮࡫ࡷࡠࡤ࡬࡫࡫ࡵ࡮ࡵࡡ࡯ࡳࡳ࡭ࠧ௹"))
	return
def jozp3PBF9JGcUXNrgRKds():
	CtO9cFuULSm62PWToMlzN1 = t4txivgXSUWBOlCakQmNDjf(u"่ࠧาสࠤฬ๊ศา่ส้ัฺ๊ࠦ็็ࠤฬ็ึๅࠢหหุะฮะษ่ࠤั๊ฯࠡๅ๋ำ๏ࠦࠨࡌࡱࡧ࡭࡙ࠥ࡫ࡪࡰࠬࠤฬ๊ะ๋ࠢสื๊ํ࡜࡯ࠩ௺")+l5JG7XwbOfo8DznU+bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ௻")+c7gxFyUCGm+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩ࡟ࡲࡡࡴ࡜࡯๋้๊้ࠢๆࠡฬฮฬ๏ะ็ࠡสสืฯิฯศ็ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡࡇࡐࡅࡉࠦࡒࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻࠣวํࠦสฮ็ํ่์ࠦๅ็࡞ࡱࠫ௼")+l5JG7XwbOfo8DznU+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡯ࡴࡪࡩࡳࡧࡳࡳ࠳ࡻ࡫࠯ࡶࡲࠫ௽")+c7gxFyUCGm+qrjy8LuKVPNYdbSvzh(u"ࠫࡡࡴ࡜࡯࡞ࡱࠤ์ึ็ࠡษ็ีุอไส๋ࠢ฾๏ื็ศࠢๆฯ๏ืࠠๆ๊ฯ์ิฯࠠโ์ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠣ์ฬ๊ๅำ์าࠤศ๐ึศ่ࠢ์ั๎ฯࠡใํࠤ็อฦๆหࠣวั๎ศสࠢส่อืๆศ็ฯࠫ௾")
	r31rWd0qVCzeNapuFjwZg8scSIi5(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬ௿"),fgv5U2eRVaQqSiuGD(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩఀ"),CtO9cFuULSm62PWToMlzN1,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡵࡧࡻࡸࡻ࡯ࡥࡸࡡࡥ࡭࡬࡬࡯࡯ࡶࠪఁ"))
	return
def KKFMTDoB7R2fm38nuJbLCq9x4AYp1():
	CtO9cFuULSm62PWToMlzN1 = X60YQOADpkHBb31LiR5qUEKfM(u"ࠨษ็ีฬฮื๋่ࠣวิ์ว่ࠢไ๎์๋วࠡฬฺฬ๏่ࠠไ๊า๎ࠥ฿ๅศัࠣ์์๎ฺࠠสสีฮูࠦ็ࠢอฯอ๐สࠡๅส้้ࠦว้ฬ๋้ฬะ๊ไ์่ࠣอืๆศ็ฯࠤ่๎ฯ๋๋้ࠢ฾ํࠠศุสๅฮูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊ส๋้ࠢ฾ํࠠศุสๅฮࠦฬๅั้ࠣฯื่ษ๊็ืࠥ฿ๅศัࠣ์๊฿็ࠡษูหๆฯࠠๆีอ์ิ฿ฺࠠ็สำࠥ๎แ๋้ࠣว๏฼วࠡฮ่๎฾ࠦวฺัสำฯࠦใ้ัํࠤฬ๊ๅุๆ๋ฬฮࠦไฺ็็ࠤอืๆศ็ฯࠤ฾๋วะ๋ࠢ็้ํวࠡฬอ้ࠥอ่ห๊่หฯ๐ใ๋ษࠣ์้อࠠหฯอหัࠦร๋้ࠢ์฾ࠦๅ็ࠢส่ำฮัสࠢไ๎้่ࠥะ์ࠣวํࠦวๅะหีฮࠦแ๋ࠢอฯอ๐สࠡลูหๆอสࠡๅ๋ำ๏࠭ం")+wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+sCSyOla9hrcE[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡎࡓࡉࡏࡅࡎࡃࡇࡣࡆࡖࡐࠨః")][f4fTutDOEwUeIoPLRQ]+c7gxFyUCGm+SSvu1CZjTW7FcloNqD(u"ࠪࠤࠥࠦࠠࠡࠢฦ์ࠥࠦࠠࠡࠢࠣࠫఄ")+eMypvI8XqHjYU02anWD9gsSrkt+sCSyOla9hrcE[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡐࡕࡄࡊࡇࡐࡅࡉࡥࡁࡑࡒࠪఅ")][vkIa3ijEQVsJGdWOXwK7bnue9ADR]+c7gxFyUCGm
	CtO9cFuULSm62PWToMlzN1 += UpQ56M0dO1N9xIvVegy(u"ࠬࡢ࡮࡝ࡰ࡟ࡲฬ๊ัศสฺࠤศีๆศ้๋ࠣํࠦวๅี๋ีุࠦวๅาํࠤ๏ำสศฮ๊ࠤ๊ี๊า่่ࠢๆอสࠡๅ๋ำ๏ࠦไหอห๎ฯࠦศา่ส้ัูࠦๆษาࠤออไุำํๆฮࠦวๅฬๅ่๏ี๊สࠢส่็ี๊ๆห࡟ࡲࠬఆ")+eMypvI8XqHjYU02anWD9gsSrkt+sCSyOla9hrcE[z3sIGH8jmLYg(u"࠭ࡓࡐࡗࡕࡇࡊ࡙ࠧఇ")][vkIa3ijEQVsJGdWOXwK7bnue9ADR]+c7gxFyUCGm
	CtO9cFuULSm62PWToMlzN1 += l4DS8mnEjHhFMZ5YOe(u"ࠧ࡝ࡰ࡟ࡲࡡࡴฬๆ์฼ࠤ๊๊แศฬࠣ฽๊อฯࠡ็๋ะํีษࠡใํࠤฬ๊ๅ้ไ฼ࠤศีๆศ้ࠪఈ")+wwOnIucWJj+eMypvI8XqHjYU02anWD9gsSrkt+sCSyOla9hrcE[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡕࡒ࡙ࡗࡉࡅࡔࠩఉ")][QQSugEIn2mTCpRsfcaJHhPdAWzylM]+c7gxFyUCGm
	r31rWd0qVCzeNapuFjwZg8scSIi5(t4txivgXSUWBOlCakQmNDjf(u"ࠩࡦࡩࡳࡺࡥࡳࠩఊ"),fgv5U2eRVaQqSiuGD(u"ࠪห้๋่ศไ฼ࠤฬ๊ัิ็ํอ๊ࠥศา่ส้ัูࠦๆษาࠤ้๊แ๋ัํ์์อสࠡษ็฽ึฮ๊สࠩఋ"),CtO9cFuULSm62PWToMlzN1,X1mRwt2YJKgCLu9a67(u"ࠫࡹ࡫ࡸࡵࡸ࡬ࡩࡼࡥࡢࡪࡩࡩࡳࡳࡺࠧఌ"))
	return
def euOGUICqTJP0(d8XzAO0pmRIQqoNDYWUJ5T3PHhLy):
	RarSo2nTfwU0WEGK.executebuiltin(Fo1SgXMsHk(u"ࠬࡇࡤࡥࡱࡱ࠲ࡔࡶࡥ࡯ࡕࡨࡸࡹ࡯࡮ࡨࡵࠫࠫ఍")+d8XzAO0pmRIQqoNDYWUJ5T3PHhLy+xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࠩࠨఎ"), Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return
def MMRo1cWwGLKV0aJp():
	UUlNOsvLb1(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡴࡶࡲࡴࠬఏ"))
	RarSo2nTfwU0WEGK.executebuiltin(z3sIGH8jmLYg(u"ࠣࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡌࡲࡹ࡫ࡲࡧࡣࡦࡩࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠯ࠢఐ"))
	return
def gkB3aNoiAj0E5nqem1pdHw8():
	RarSo2nTfwU0WEGK.executebuiltin(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡄࡨࡩࡵ࡮࠯ࡑࡳࡩࡳ࡙ࡥࡵࡶ࡬ࡲ࡬ࡹࠨࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠩࠨ఑"), Ag9l6cw3EBqP8HsQuGMizfOtr4)
	return
def isrhUHyRexIE2():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ఒ"),IINBvuxkCSJrO1Q0UyngdLi(u"้๋ࠫำฮ่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢ࠱ࠤฬึ็ษࠢศ่๎ࠦวๅไสส๊ฯࠠศๆอ๎ࠥะั๋ัุ้ࠣำ็ศ๋่ࠢฬࠦสะะ็ࠤส๊๊่ษࠣ์้้ๆࠡสสืฯิฯศ็ࠣࠦฬ๊ๅศ๊ึࠦࠥษ่ࠡࠤส่ึ๐ๅ้ฬࠥࠤฬ฼ฺุࠢ฼่๎ࠦวๅิิࠤัํษࠡษ็๎๊๐ๆࠡล๋ࠤฬูสฯั่ࠤࠧอไไ์ห์ึี๊ࠢࠡสฺ฿฽ฺࠠๆ์ࠤาืแࠡࠤࡆࠦࠥษ่ࠡ฻็ํࠥอึ฻ูࠣ฽้๏ࠠำำࠣࠦฬ๊โศศ่อࠧࠦวๅาํࠤๆ๐ࠠอ้ฬࠤฬ๊๊ๆ์้ࠫఓ"))
	return
def qq9b4oeBMTfUlEk2wNyzt():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨఔ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ไๅฬ฼ห๊๊ࠠๆ฻ࠣห้๋แืๆฬࠤ࠳ࠦวั้หࠤส๊้ࠡษ็ีฬฮืࠡษ็ิ๏ࠦสา์าࠤส฼วโฬ๊ࠤศ๎ࠠๆีะ๋๋ࠥๆࠡࠢๅหห๋ษࠡษ็้ๆ฼ไส๋่่ࠢ์ࠠๅษࠣฮ๋่ัࠡ฻็๎์่ࠦๅษࠣฮูเไ่ࠢ࠱ࠤํฮวิฬัำฬ๋ࠠࠣษ็้ฬ๎ำࠣࠢฦ์ࠥࠨวๅำํ้ํะࠢࠡษู฾฼ูࠦๅ๋ࠣหุ้ัࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้ࠠล่หࠥฮวิฬัำฬ๋ࠠࠣษ็็๏ฮ่าัࠥࠤๆอึ฻ูࠣ฽้๏ࠠฮำไࠤࠧࡉࠢࠡล๋ࠤ฾๊้ࠡิิࠤࠧอไใษษ้ฮࠨࠠศๆำ๎ࠥ็๊ࠡฮ๊อࠥอไ๋็ํ๊ࠥ࠴้่ࠠไืࠥอไไๆส้ࠥ๎วๅูิ๎็ฯฺ่ࠠาࠤฬ๊สฺษู่่๋ࠥࠡ็ะฮํ๐วหࠢๅ์ฬฬๅࠡษ็้ๆ฼ไสࠩక"))
	return
def s8j7mtrbOgdlq9eNT2vSnRBcVpP6(OgFepqCN6aTyPElVi2GK5f1Q8XwJR=l4DS8mnEjHhFMZ5YOe(u"ࠧࡴ࡭࡬ࡲ࠳ࡳࡥࡵࡴࡲࡴࡴࡲࡩࡴࡇࡐࡅࡉ࠭ఖ"),showDialogs=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	TRlmx0KhjvQorVk9DYGzwIp = RarSo2nTfwU0WEGK.executeJSONRPC(I3cxjYaHhsrM7T4UX26klN(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡲ࡯ࡰ࡭ࡤࡲࡩ࡬ࡥࡦ࡮࠱ࡷࡰ࡯࡮ࠣࡿࢀࠫగ"))
	data = eH72MR1wtfuI80myOo4ajgG.loads(TRlmx0KhjvQorVk9DYGzwIp)
	k9kERYAxQyw0KFXeuTUgIL4sP58hp = data[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡵࡩࡸࡻ࡬ࡵࠩఘ")][SSvu1CZjTW7FcloNqD(u"ࠪࡺࡦࡲࡵࡦࠩఙ")]
	if n7neb9KTv10FcU: k9kERYAxQyw0KFXeuTUgIL4sP58hp = k9kERYAxQyw0KFXeuTUgIL4sP58hp.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧచ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬํไࠡฬิ๎ิࠦส฻์ํีࠥาไะࠢࠪఛ")+k9kERYAxQyw0KFXeuTUgIL4sP58hp+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࠠศๆำ๎๋ࠥำหะา้ࠥอไร่ࠣๅ๏ࠦใ้ัํࠤส๊้ࠡษ็ษฺีวาࠢส่ศิ๊าࠢ็ะ้ีࠠࠨజ")+OgFepqCN6aTyPElVi2GK5f1Q8XwJR+IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࠡมࠤࠫఝ"))
		if oyNUHM3uQq!=flDSRbv57PnV3(u"࠴ൔ"): return SmbNGskjMx
	EJNf2kglaiQHnFGe531Iq,r4rKYigFLvlUImcBERaq,MMpderqvVm1F2xsAE = bb7p5GtMnXDJ(OgFepqCN6aTyPElVi2GK5f1Q8XwJR,SmbNGskjMx,SmbNGskjMx)
	if EJNf2kglaiQHnFGe531Iq:
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫఞ"),l4DS8mnEjHhFMZ5YOe(u"ࠩอ้ฯูࠦๆๆํอࠥะหษ์อࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣ์์๎ࠠอษ๊ึ๊ࠥไศีอาิอๅࠡ࠰ࠣืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢอ฾๏๐ัࠡว฼ำฬีวหࠢๆ์ิ๐ࠠๅๅํࠤ๏ูสฺ็็ࠤฬ๊ฬๅัࠣห้าฯ๋ัࠣฬิ๊วࠡ็้ࠤฬ๊โะ์่ࠫట"))
		yi6wOauQ3Sb1JUBt4 = RarSo2nTfwU0WEGK.executeJSONRPC(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡘ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣ࡫ࡧࠦ࠿࠷ࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢ࡭ࡱࡲ࡯ࡦࡴࡤࡧࡧࡨࡰ࠳ࡹ࡫ࡪࡰࠥ࠰ࠧࡼࡡ࡭ࡷࡨࠦ࠿ࠨࠧఠ")+OgFepqCN6aTyPElVi2GK5f1Q8XwJR+DJ6ugPjW9bX8I(u"ࠫࠧࢃࡽࠨడ"))
		EJNf2kglaiQHnFGe531Iq = Ag9l6cw3EBqP8HsQuGMizfOtr4 if IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡕࡋࠨఢ") in yi6wOauQ3Sb1JUBt4 else SmbNGskjMx
		lQMuw1PvVpAk.sleep(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠵ൕ"))
		RarSo2nTfwU0WEGK.executebuiltin(IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭ణ"))
	elif showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪత"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣ์ฯ็ู๋ๆࠣห้าไะࠢส่๊฽ไ้สࠪథ"))
	return EJNf2kglaiQHnFGe531Iq
def ZONuL1gdCb9JlK48yPavn3r():
	url = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰ࡭ࡷࡸ࡯ࡳࡵ࠱࡯ࡴࡪࡩ࠯ࡶࡹ࠳ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠵ࡷࡪࡰࡧࡳࡼࡹ࠯ࡸ࡫ࡱ࠺࠹࠵ࠧద")
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,YayJj10OGl(u"ࠪࡋࡊ࡚ࠧధ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡓࡉࡑ࡚ࡣࡑࡇࡔࡆࡕࡗࡣࡐࡕࡄࡊࡡ࡙ࡉࡗ࡙ࡉࡐࡐ࠰࠵ࡸࡺࠧన"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	XZGCDFNd4aTj0puPV5 = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡺࡩࡵ࡮ࡨࡁࠧࡱ࡯ࡥ࡫࠰ࠬࡡࡪࠫ࡝࠰࡟ࡨ࠰࠳࡛ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠫ࠰ࠫ఩"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	XZGCDFNd4aTj0puPV5 = XZGCDFNd4aTj0puPV5[f4fTutDOEwUeIoPLRQ].split(QlTuvPbSpnjygBVW(u"࠭࠭ࠨప"))[f4fTutDOEwUeIoPLRQ]
	hRAu92Us3ip5r = str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)
	amIcByjdlx5ktPVoh2WvQOXsLzi = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧ࡜ࡔࡗࡐࡢหีะษิࠤ่๎ฯ๋ࠢส่ศิ๊าࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩఫ")+l5JG7XwbOfo8DznU+XZGCDFNd4aTj0puPV5+c7gxFyUCGm
	amIcByjdlx5ktPVoh2WvQOXsLzi += usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨ࡞ࡱࡠࡳ࠭బ")+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩ࡞ࡖ࡙ࡒ࡝ฦืาหึࠦใ้ัํࠤฬ๊ะ๋ࠢส๊ฯࠦสิฬัำ๊ํ่๊ࠠࠣ࠾ࠥࠦࠠࠨభ")+l5JG7XwbOfo8DznU+hRAu92Us3ip5r+c7gxFyUCGm
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭మ"),amIcByjdlx5ktPVoh2WvQOXsLzi)
	return
def NzC490ABq1oxfQeXmHRGsgk():
	mmYAt80CiauzF9nqbycUpV,ccjeoT2YrRBqHZnydxE0Lzg,bt8JMmgsi4hxDRB6PqYja = SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	NcsACxze6RYSaMukWy8TvnHq5Kt0E,aaGKonmQDliEMJjzA9tpSe,bfmRZWnkCY4TzJHGjxO62cu9 = SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	CCcLZqdnhFeisHmW = [cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡥࡷࡧࡢࡪࡥࡹ࡭ࡩ࡫࡯ࡴࠩయ"),l4DS8mnEjHhFMZ5YOe(u"ࠬࡸࡥࡱࡱࡶ࡭ࡹࡵࡲࡺ࠰ࡨࡱࡦࡪࠧర"),QlTuvPbSpnjygBVW(u"࠭ࡳ࡬࡫ࡱ࠲ࡲ࡫ࡴࡳࡱࡳࡳࡱ࡯ࡳࡆࡏࡄࡈࠬఱ")]
	QCkFNzuGpZwqEmb = wQ5nCz7RXvZJ(CCcLZqdnhFeisHmW)
	for ldJmEsIZY9A4pXStekwNoTV in CCcLZqdnhFeisHmW:
		if ldJmEsIZY9A4pXStekwNoTV not in list(QCkFNzuGpZwqEmb.keys()): continue
		HD5qTR34VXh79ULoz,CmHdP8FiLUv1pR3k04honscZltb,Fcs4aKCzY7mL5QkV,Df4LyUX3OcwgJ,iK8u9vLEpr,V7mF5nZDjS1K6brlJc,ZAUCeIRVlDYQn7 = QCkFNzuGpZwqEmb[ldJmEsIZY9A4pXStekwNoTV]
		if ldJmEsIZY9A4pXStekwNoTV==qrjy8LuKVPNYdbSvzh(u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠬల"):
			NcsACxze6RYSaMukWy8TvnHq5Kt0E = HD5qTR34VXh79ULoz
			aaGKonmQDliEMJjzA9tpSe = CmHdP8FiLUv1pR3k04honscZltb+tM24jD1gO0(u"ࠨࠢࠣࠤࠥ࠮ࠠࠨళ")+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(V7mF5nZDjS1K6brlJc)+I3cxjYaHhsrM7T4UX26klN(u"ࠩࠣ࠭ࠬఴ")
			bfmRZWnkCY4TzJHGjxO62cu9 = Df4LyUX3OcwgJ
		elif ldJmEsIZY9A4pXStekwNoTV==SSvu1CZjTW7FcloNqD(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬవ"):
			mmYAt80CiauzF9nqbycUpV = mmYAt80CiauzF9nqbycUpV or HD5qTR34VXh79ULoz
			ccjeoT2YrRBqHZnydxE0Lzg += DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࠥࠦࠬࠡࠢࠪశ")+CmHdP8FiLUv1pR3k04honscZltb+bnI4kmPtrW7yFEhljXOCq9(u"ࠬࠦࠠࠡࠢࠫࠤࠬష")+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(V7mF5nZDjS1K6brlJc)+UpQ56M0dO1N9xIvVegy(u"࠭ࠠࠪࠩస")
			bt8JMmgsi4hxDRB6PqYja += fgv5U2eRVaQqSiuGD(u"ࠧࠡࠢ࠯ࠤࠥ࠭హ")+Df4LyUX3OcwgJ
		elif ldJmEsIZY9A4pXStekwNoTV==flDSRbv57PnV3(u"ࠨࡵ࡮࡭ࡳ࠴࡭ࡦࡶࡵࡳࡵࡵ࡬ࡪࡵࡈࡑࡆࡊࠧ఺"):
			mOKz89rG0kV2g7qPTpX = HD5qTR34VXh79ULoz
			TbzZPidSmxRO03BQvtw5j = CmHdP8FiLUv1pR3k04honscZltb+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࠣࠤࠥࠦࠨࠡࠩ఻")+wKYA6dfHyq3VgrZNbG5psjBRz0kXa(V7mF5nZDjS1K6brlJc)+X1mRwt2YJKgCLu9a67(u"ࠪࠤ࠮఼࠭")
			kim972rInZ4JU = Df4LyUX3OcwgJ
	ccjeoT2YrRBqHZnydxE0Lzg = ccjeoT2YrRBqHZnydxE0Lzg.strip(Fo1SgXMsHk(u"ࠫࠥࠦࠬࠡࠢࠪఽ"))
	bt8JMmgsi4hxDRB6PqYja = bt8JMmgsi4hxDRB6PqYja.strip(X1mRwt2YJKgCLu9a67(u"ࠬࠦࠠ࠭ࠢࠣࠫా"))
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz  = SSvu1CZjTW7FcloNqD(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไฤะํี๊ࠥศา่ส้ัูࠦๆษาࠤฬ๊ๅห๊ไีࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠣࠫి")+l5JG7XwbOfo8DznU+bfmRZWnkCY4TzJHGjxO62cu9+c7gxFyUCGm
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz += wwOnIucWJj+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࡜ࡔࡗࡐࡢอไฦืาหึࠦวๅาํࠤฬ์สࠡฬึฮำีๅ่ࠢ็ฬึ์วๆฮࠣ฽๊อฯ้๋ࠡࠤ࠿ࠦࠠࠡࠩీ")+l5JG7XwbOfo8DznU+aaGKonmQDliEMJjzA9tpSe+c7gxFyUCGm
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz += IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࡞ࡱࡠࡳ࠭ు")+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࡞ࡖ࡙ࡒ࡝ศๆศูิอัࠡษ็วำ๐ัࠡๆ่ืฯ๎ฯฺࠢ฼้ฬีࠠศๆ่ฮํ็ัࠡษ็ฦ๋ࠦ็้ࠢ࠽ࠤࠥࠦࠧూ")+l5JG7XwbOfo8DznU+bt8JMmgsi4hxDRB6PqYja+c7gxFyUCGm
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz += wwOnIucWJj+SSvu1CZjTW7FcloNqD(u"ࠪ࡟ࡗ࡚ࡌ࡞ษ็ษฺีวาࠢส่ี๐ࠠศ่อࠤฯูสฯั่๋๊ࠥๅิฬ๋ำ฾ูࠦๆษาࠤ์๎ࠠ࠻ࠢࠣࠤࠬృ")+l5JG7XwbOfo8DznU+ccjeoT2YrRBqHZnydxE0Lzg+c7gxFyUCGm
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz += DJ6ugPjW9bX8I(u"ࠫࡡࡴ࡜࡯ࠩౄ")+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡡࡒࡕࡎࡠห้หีะษิࠤฬ๊รฯ์ิࠤ้าไะ่ࠢฮึ๎ศ้ๆึࠤ฾๋วะࠢส่๊ะ่โำࠣห้ศๆ้๋ࠡࠤ࠿ࠦࠠࠡࠩ౅")+l5JG7XwbOfo8DznU+kim972rInZ4JU+c7gxFyUCGm
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz += wwOnIucWJj+q4izXt0sjIQSZcHVAf3EmKRbx(u"࡛࠭ࡓࡖࡏࡡฬ๊ลึัสีࠥอไั์ࠣห๋ะࠠหีอาิ๋็ࠡๆฯ่ิࠦๅหำ๋ฬํ๊ำࠡ฻่หิࠦ็้ࠢ࠽ࠤࠥࠦࠧె")+l5JG7XwbOfo8DznU+TbzZPidSmxRO03BQvtw5j+c7gxFyUCGm
	HD5qTR34VXh79ULoz = NcsACxze6RYSaMukWy8TvnHq5Kt0E or mmYAt80CiauzF9nqbycUpV
	if HD5qTR34VXh79ULoz:
		header = UpQ56M0dO1N9xIvVegy(u"ࠧศๆิะฬวࠠหฯา๎ะࠦลืษไหฯࠦใ้ัํࠤ้ำไࠡษ็ู้อใๅࠩే")
		eT40LGftIOPZKAcsU26Mx = UpQ56M0dO1N9xIvVegy(u"ࠨษ้ฮࠥฮอศฮฬࠤ้ะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠢฦ์ࠥะอะ์ฮࠤู๊ส้ั฼ࠤ฾๋วะࠩై")
	else:
		header = SSvu1CZjTW7FcloNqD(u"ࠩะห้๐วࠡๆสࠤ๏๎ฬะࠢอัิ๐หศฬ่ࠣอืๆศ็ฯࠤ฾๋วะࠢฦ์๋ࠥำห๊า฽ࠥ฿ๅศัࠪ౉")
		eT40LGftIOPZKAcsU26Mx = tM24jD1gO0(u"ࠪห้ืฬศรࠣษอ๊ว฻ࠢส่๊ฮัๆฮࠣ฽๋ࠦวๅ็ื็้ฯࠠศๆอ๎ࠥะ่ศฮ๊็ࠬొ")
	jFupHXv5iTlkQsPwrB24n6YoRAJC = DJ6ugPjW9bX8I(u"้้๊ࠫࠡ์฼ู้้ࠦ็ัๆࠤฬ๊สฮัํฯࠥอไหๆๅหห๐๋ࠠฮหࠤศ์๋ࠠๅ๋๊๊ࠥฯ๋ๅࠣๅ๏ࠦใ้ัํࡠࡳ๋ำห๊า฽ࠥ฿ๅศัࠣࡉࡒࡇࡄࠡࡔࡨࡴࡴࡹࡩࡵࡱࡵࡽࠬో")
	zKlZmFX0JRjE = UMjkHfeCxLXdyRFhJqINv6ouWSErlz+l4DS8mnEjHhFMZ5YOe(u"ࠬࡢ࡮࡝ࡰࠪౌ")+eT40LGftIOPZKAcsU26Mx+qrjy8LuKVPNYdbSvzh(u"࠭࡜࡯࡞ࡱ్ࠫ")+jFupHXv5iTlkQsPwrB24n6YoRAJC
	r31rWd0qVCzeNapuFjwZg8scSIi5(UpQ56M0dO1N9xIvVegy(u"ࠧࡳ࡫ࡪ࡬ࡹ࠭౎"),header,zKlZmFX0JRjE,X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡶࡨࡼࡹࡼࡩࡦࡹࡢࡦ࡮࡭ࡦࡰࡰࡷࠫ౏"))
	return HD5qTR34VXh79ULoz
def q9WvrGEy1i4LXaMKRz0cmO8(ldJmEsIZY9A4pXStekwNoTV,ZAUCeIRVlDYQn7,showDialogs):
	EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ౐"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪืํ็๋ࠠฬ่ࠤฬ๊ย็ࠢฯ่อࠦวๅ็็ๅࠥอไๆุ฽์฼ࠦไๅวูหๆฯࠠศๆ่฻้๎ศสࠢ็็๏๊ࠦห็ࠣฮะฮ๊ห้ࠣ฽้๏ࠠไ๊า๎ࠥ࠴ࠠศๆ่่ๆࠦโะࠢํ็ํ์ࠠไสํีࠥ๎โะࠢํัฯอฬࠡส฼ฺࠥอไ้ไอࠤ࠳ࠦ็ๅࠢอี๏ีࠠหฯ่๎้ࠦวๅ็็ๅࠥอไร่ࠣรࠦ࠭౑"))
		if oyNUHM3uQq!=qrjy8LuKVPNYdbSvzh(u"࠶ൖ"): return SmbNGskjMx
	ZgdPkGVeWw8X3jKRIvQ = OZq0bRFsaGe98NJxmW6tPiv(ZAUCeIRVlDYQn7,{},showDialogs)
	if ZgdPkGVeWw8X3jKRIvQ:
		RivoIjWfLJPkSa = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iPlfQr1JR08,ldJmEsIZY9A4pXStekwNoTV)
		bQaAGNXBYIgClLm15ui3JqU(RivoIjWfLJPkSa,Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
		import zipfile as j21jumUbyngwVOlSJPa8fi5rZC,io as ZvYFDMjnrS4piWk9I7bGEK1Q
		p5Q4hd6AvOWkn32G = ZvYFDMjnrS4piWk9I7bGEK1Q.BytesIO(ZgdPkGVeWw8X3jKRIvQ)
		try:
			jXdk64lZaQT5UtsENFHw9IzP8hWrp = j21jumUbyngwVOlSJPa8fi5rZC.ZipFile(p5Q4hd6AvOWkn32G)
			jXdk64lZaQT5UtsENFHw9IzP8hWrp.extractall(iPlfQr1JR08)
			lQMuw1PvVpAk.sleep(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠷ൗ"))
			RarSo2nTfwU0WEGK.executebuiltin(Fo1SgXMsHk(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ౒"))
			lQMuw1PvVpAk.sleep(IINBvuxkCSJrO1Q0UyngdLi(u"࠱൘"))
			EJNf2kglaiQHnFGe531Iq = VmRyDdOWiPLZkJN029n7Q8r(ldJmEsIZY9A4pXStekwNoTV)
		except: EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
	if showDialogs:
		if EJNf2kglaiQHnFGe531Iq: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ౓"),DJ6ugPjW9bX8I(u"࠭สๆࠢห๊ัออࠡฬฮฬ๏ะࠠศๆศฺฬ็ษࠡษ็้฼๊่ษหࠪ౔"))
		else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮౕࠪ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨๆ็วุ็ࠠโึ็ฮࠥ฿ๅๅ์ฬࠤฯัศ๋ฬࠣห้หึศใฬࠤฬ๊ๅุๆ๋ฬฮౖ࠭"))
	return EJNf2kglaiQHnFGe531Iq
def tjoDTklcueMPnHqI9yg(ldJmEsIZY9A4pXStekwNoTV,showDialogs=Ag9l6cw3EBqP8HsQuGMizfOtr4):
	if showDialogs==nbOFVEDkpT4BIR7Qq82yPmHeJU: showDialogs = Ag9l6cw3EBqP8HsQuGMizfOtr4
	evkKrGczf3YO1mtqg5NWBhXiZEQoA = Y9Xn2ay8Z1wLx3verlh7iH4([ldJmEsIZY9A4pXStekwNoTV])
	O29OxcJi3EQIGBNrlaXKg0M6,S4B8eUiF9y7PzcwAG0 = evkKrGczf3YO1mtqg5NWBhXiZEQoA[ldJmEsIZY9A4pXStekwNoTV]
	if S4B8eUiF9y7PzcwAG0:
		EJNf2kglaiQHnFGe531Iq = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ౗"),tM24jD1gO0(u"ࠪๅา฻ࠠศๆศฺฬ็ษࠡ࡞ࡱࠤࠬౘ")+ldJmEsIZY9A4pXStekwNoTV+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࠥࡢ࡮้ࠡำ๋ࠥษไฦุสๅฮูࠦ็ัๆࠤ๊๎ฬ้ัฬࠤํ๋แฺๆฬࠤําว่ิฬࠤ้๊วิฬัำฬ๋ࠧౙ"))
	else:
		EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡩࡥ࡯ࡶࡨࡶࠬౚ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ౛"),nbOFVEDkpT4BIR7Qq82yPmHeJU+ldJmEsIZY9A4pXStekwNoTV+X1mRwt2YJKgCLu9a67(u"ࠧࠡ࡞ࡱࠤ์ึ็ࠡล็ษ฻อแสࠢ฼๊ิ้ࠠ฻์ิࠤ๊็ูๅหࠣวํฺ๋ࠦำ้ࠣํา่ะหࠣ࠲ࠥ๐ฬษࠢอฯอ๐ส่ษࠣ์ฯ็ู๋ๆ๊ห๊ࠥใ๋ࠢํ฽๊๊ࠠศๆหี๋อๅอࠢ฼๊ิ้ࠠษื๋ีฮࠦีฮ์ะอࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬฮฬ๏ะ้ࠠฬไ฽๏๊่ࠠา๊ࠤฬ๊ลืษไอࠥอไร่ࠣรࠬ౜"))
		if oyNUHM3uQq==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠲൙"):
			RarSo2nTfwU0WEGK.executebuiltin(IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡋࡱࡷࡹࡧ࡬࡭ࡃࡧࡨࡴࡴࠨࠨౝ")+ldJmEsIZY9A4pXStekwNoTV+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࠬࠫ౞"))
			lQMuw1PvVpAk.sleep(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠳൚"))
			RarSo2nTfwU0WEGK.executebuiltin(QlTuvPbSpnjygBVW(u"ࠪࡗࡪࡴࡤࡄ࡮࡬ࡧࡰ࠮࠱࠲ࠫࠪ౟"))
			lQMuw1PvVpAk.sleep(ulAxHwvzR9eTb5n(u"࠴൛"))
			while RarSo2nTfwU0WEGK.getCondVisibility(SSvu1CZjTW7FcloNqD(u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡁࡤࡶ࡬ࡺࡪ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡥ࡫ࡤࡰࡴ࡭ࠩࠨౠ")): lQMuw1PvVpAk.sleep(YayJj10OGl(u"࠵൜"))
			EJNf2kglaiQHnFGe531Iq = VmRyDdOWiPLZkJN029n7Q8r(ldJmEsIZY9A4pXStekwNoTV)
			if showDialogs and EJNf2kglaiQHnFGe531Iq: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨౡ"),flDSRbv57PnV3(u"࠭สๆࠢไัฺࠦร้ࠢอฯอ๐สࠡล๋ࠤฯ็ู๋ๆࠣวํࠦสฮัํฯࠥอไฦุสๅฮࠦวๅ็ฺ่ํฮษ๊๊ࠡ๎ࠥอไร่ࠣะฬําสࠢ็่ฬูสฯัส้ࠬౢ"))
			elif showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪౣ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨใื่ࠥ็๊ࠡฬฮฬ๏ะࠠฤ๊ࠣฮๆ฿๊ๅࠢฦ์ࠥะอะ์ฮࠤฬ๊ลืษไอࠥอไๆู็์อฯࠠ࠯๋ࠢห้ำไ้๋ࠡࠤฯัศ๋ฬ๊หࠥ๎สโ฻ํ่์อࠠๆ่ࠣาฬืฬࠡษ็ฬึ์วๆฮࠪ౤"))
	return EJNf2kglaiQHnFGe531Iq
def QK5Pg07pibDxqZS1IY2GyVk3Re(showDialogs):
	if not showDialogs: oyNUHM3uQq = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else: oyNUHM3uQq = ttiZs4bKHFvugJj5z(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡦࡩࡳࡺࡥࡳࠩ౥"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭౦"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫอืๆศ็ฯࠤ่๎ฯ๋ࠢํๆํ๋ࠠษ฻่่๏ฯࠠหฯา๎ะࠦฬๆ์฼ࠤฬ๊ลืษไหฯࠦสๅไสส๏อࠠไๆࠣ࠶࠹ࠦำศ฻ฬࠤํ๊ใ็่้่ࠢ์ࠠฦฮิหฦํวࠡษ็ฦ๋ࠦ࠮้ࠡ็ࠤฯื๊ะࠢอัิ๐หࠡฮ่๎฾ࠦลืษไหฯࠦใ้ัํࠤฬ๊ย็ࠢยࠫ౧"))
	if oyNUHM3uQq==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠶൝"):
		RarSo2nTfwU0WEGK.executebuiltin(DJ6ugPjW9bX8I(u"࡛ࠬࡰࡥࡣࡷࡩࡆࡪࡤࡰࡰࡕࡩࡵࡵࡳࠨ౨"))
		if showDialogs:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ౩"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠧห็ࠣษึูวๅฺ่ࠢอࠦลๅ๋ࠣฬึ์วๆฮࠣ็ํี๊ࠡษ็ิ๏ࠦแ๋ࠢฯ๋ฬุใࠡๆๆ๎ࠥ๐โ้็ࠣฬฯำฯ๋อࠣะ๊๐ูࠡวูหๆอสࠡๅ๋ำ๏ࠦ࠮ࠡส่หࠥ็๊่ษࠣฮาี๊ฬ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡอัิ๐หࠡ็ึฮํีูࠡ฻่หิࠦ࠮ࠡ์ิะ๎ࠦลฺูสล้่ࠥะ์ࠣ࠹ࠥีโศศๅࠤศ๎ࠠฤๅฮี๊ࠥใ๋ࠢํ๊์๐ฺࠠ็็๎ฮࠦวๅฬะำ๏ัࠧ౪"))
	return
def UAIF0rTwoYbJO9jMVqfhs27mtRCep():
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡏࡌࡗࡈࡥࡔࡆࡏࡓࠫ౫"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡄࡐࡑࡥࡁࡅࡆࡒࡒࡘࡥࡘࡎࡎࠪ౬"))
	ZONuL1gdCb9JlK48yPavn3r()
	HD5qTR34VXh79ULoz = NzC490ABq1oxfQeXmHRGsgk()
	if HD5qTR34VXh79ULoz:
		mmhRocLej7aHKt4QYIyJNp9Bk(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		QK5Pg07pibDxqZS1IY2GyVk3Re(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		ue186CEMORWhvq(SmbNGskjMx)
	return
def VmRyDdOWiPLZkJN029n7Q8r(ldJmEsIZY9A4pXStekwNoTV):
	bPFto2wZdNYrClgBIEv60DJAzu = RarSo2nTfwU0WEGK.executeJSONRPC(fgv5U2eRVaQqSiuGD(u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡄࡨࡩࡵ࡮ࡴ࠰ࡖࡩࡹࡇࡤࡥࡱࡱࡉࡳࡧࡢ࡭ࡧࡧࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡤࡨࡩࡵ࡮ࡪࡦࠥ࠾ࠧ࠭౭")+ldJmEsIZY9A4pXStekwNoTV+fgv5U2eRVaQqSiuGD(u"ࠫࠧ࠲ࠢࡦࡰࡤࡦࡱ࡫ࡤࠣ࠼ࡷࡶࡺ࡫ࡽࡾࠩ౮"))
	succeeded = Ag9l6cw3EBqP8HsQuGMizfOtr4 if xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡕࡋࠨ౯") in bPFto2wZdNYrClgBIEv60DJAzu else SmbNGskjMx
	return succeeded
def XXWuibYBkaFP1rA(ldJmEsIZY9A4pXStekwNoTV):
	bPFto2wZdNYrClgBIEv60DJAzu = RarSo2nTfwU0WEGK.executeJSONRPC(flDSRbv57PnV3(u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣࠩ౰")+ldJmEsIZY9A4pXStekwNoTV+bYyKEjIuGQzoq3AR1(u"ࠧࠣ࠮ࠥࡩࡳࡧࡢ࡭ࡧࡧࠦ࠿࡬ࡡ࡭ࡵࡨࢁࢂ࠭౱"))
	succeeded = Ag9l6cw3EBqP8HsQuGMizfOtr4 if q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡑࡎࠫ౲") in bPFto2wZdNYrClgBIEv60DJAzu else SmbNGskjMx
	return succeeded
def bb7p5GtMnXDJ(ldJmEsIZY9A4pXStekwNoTV,showDialogs,XS3QTrpkc8qgUVzMHvKwfNoYjdt5,QCkFNzuGpZwqEmb=None):
	oyNUHM3uQq,succeeded,r4rKYigFLvlUImcBERaq,CmHdP8FiLUv1pR3k04honscZltb = Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ౳"),nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not QCkFNzuGpZwqEmb: QCkFNzuGpZwqEmb = wQ5nCz7RXvZJ([ldJmEsIZY9A4pXStekwNoTV])
	if ldJmEsIZY9A4pXStekwNoTV in list(QCkFNzuGpZwqEmb.keys()):
		HD5qTR34VXh79ULoz,CmHdP8FiLUv1pR3k04honscZltb,Fcs4aKCzY7mL5QkV,Df4LyUX3OcwgJ,iK8u9vLEpr,V7mF5nZDjS1K6brlJc,ZAUCeIRVlDYQn7 = QCkFNzuGpZwqEmb[ldJmEsIZY9A4pXStekwNoTV]
		if V7mF5nZDjS1K6brlJc==tM24jD1gO0(u"ࠪ࡫ࡴࡵࡤࠨ౴"):
			succeeded,r4rKYigFLvlUImcBERaq = Ag9l6cw3EBqP8HsQuGMizfOtr4,X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡳࡵࡴࡩ࡫ࡱ࡫ࠬ౵")
			if XS3QTrpkc8qgUVzMHvKwfNoYjdt5 and showDialogs:
				oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ౶"),QlTuvPbSpnjygBVW(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣ็ํี๊ࠡ์ึฮำีๅࠡลัีࠥหีะษิࠤ๊ะ่โำࠣๅ๏ࠦๅ้ษๅ฽๋ࠥำห๊า฽ࠥ฿ๅศั่ࠣ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭౷")+ldJmEsIZY9A4pXStekwNoTV+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࡝ࡰ࡟ࡲ์๊ࠠหำํำࠥหูศัฬࠤฯัศ๋ฬ๋ࠣีํࠠศๆศฺฬ็ษࠡ็ิอࠥษฮา๋ࠪ౸"))
				if oyNUHM3uQq:
					succeeded = q9WvrGEy1i4LXaMKRz0cmO8(ldJmEsIZY9A4pXStekwNoTV,ZAUCeIRVlDYQn7,SmbNGskjMx)
					if succeeded:
						r4rKYigFLvlUImcBERaq = ulAxHwvzR9eTb5n(u"ࠨࡴࡨ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠭౹")
						if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ౺"),fgv5U2eRVaQqSiuGD(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦๅ้ฮ๋ำฮࠦ࠮࠯๋ࠢๆฬ๋ࠠศๆหี๋อๅอࠢหษ฾อฯสࠢอฯอ๐ส่ษ࡟ࡲࡡࡴࠧ౻")+ldJmEsIZY9A4pXStekwNoTV)
					else:
						r4rKYigFLvlUImcBERaq = DJ6ugPjW9bX8I(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ౼")
						aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ౽"),cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ไๅลึๅࠥ࠴࠮ࠡษ็ฬึ์วๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦลฺษาอࠥะหษ์อࠤ์ึ็ࠡษ็ษ฻อแส࡞ࡱࡠࡳ࠭౾")+ldJmEsIZY9A4pXStekwNoTV)
		else:
			if showDialogs:
				if V7mF5nZDjS1K6brlJc==tM24jD1gO0(u"ࠧࡥ࡫ࡶࡥࡧࡲࡥࡥࠩ౿"): CtO9cFuULSm62PWToMlzN1 = X60YQOADpkHBb31LiR5qUEKfM(u"ࠨ็อ์็็ษࠨಀ")
				elif V7mF5nZDjS1K6brlJc==ulAxHwvzR9eTb5n(u"ࠩࡲࡰࡩ࠭ಁ"): CtO9cFuULSm62PWToMlzN1 = UpQ56M0dO1N9xIvVegy(u"ࠪๆิ๐ๅสࠩಂ")
				elif V7mF5nZDjS1K6brlJc==ulAxHwvzR9eTb5n(u"ࠫࡲ࡯ࡳࡴ࡫ࡱ࡫ࠬಃ"): CtO9cFuULSm62PWToMlzN1 = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬเ๊า่ࠢฯอะษࠨ಄")
				oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩಅ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"่ࠧา๊ࠤฬ๊ลืษไอࠥ࠭ಆ")+CtO9cFuULSm62PWToMlzN1+YayJj10OGl(u"ࠨࠢ࠱࠲ࠥํไࠡฬิ๎ิࠦลึๆสัࠥํะ่ࠢสฺ่๊ใๅหࠣรࠦࡢ࡮࡝ࡰࠪಇ")+ldJmEsIZY9A4pXStekwNoTV)
			if not oyNUHM3uQq: r4rKYigFLvlUImcBERaq = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࠫಈ")
			else:
				if V7mF5nZDjS1K6brlJc==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡨ࡮ࡹࡡࡣ࡮ࡨࡨࠬಉ"):
					succeeded = VmRyDdOWiPLZkJN029n7Q8r(ldJmEsIZY9A4pXStekwNoTV)
					if succeeded:
						r4rKYigFLvlUImcBERaq = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬಊ")
						if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨಋ"),z3sIGH8jmLYg(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ่อๆห่ࠢฮํ่แสࠢ࠱࠲ࠥ๎โศ็ࠣห้ฮั็ษ่ะࠥฮสี฼ํ่์อ࡜࡯࡞ࡱࠫಌ")+ldJmEsIZY9A4pXStekwNoTV)
					elif showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ಍"),bnI4kmPtrW7yFEhljXOCq9(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้หึศใฬࠤ๊ะ่ใใฬࠤ࠳࠴้ࠠๆ่ࠤ๏ูสุ์฼ࠤฬ๊ศา่ส้ัࠦสี฼ํ่์อ࡜࡯࡞ࡱࠫಎ")+ldJmEsIZY9A4pXStekwNoTV)
				elif V7mF5nZDjS1K6brlJc in [DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡲࡰࡩ࠭ಏ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡱ࡮ࡹࡳࡪࡰࡪࠫಐ")]:
					succeeded = q9WvrGEy1i4LXaMKRz0cmO8(ldJmEsIZY9A4pXStekwNoTV,ZAUCeIRVlDYQn7,SmbNGskjMx)
					if succeeded:
						if V7mF5nZDjS1K6brlJc==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡴࡲࡤࠨ಑"): r4rKYigFLvlUImcBERaq = ulAxHwvzR9eTb5n(u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭ಒ")
						elif V7mF5nZDjS1K6brlJc==flDSRbv57PnV3(u"࠭࡭ࡪࡵࡶ࡭ࡳ࡭ࠧಓ"): r4rKYigFLvlUImcBERaq = Fo1SgXMsHk(u"ࠧࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠪಔ")
						CmHdP8FiLUv1pR3k04honscZltb = Df4LyUX3OcwgJ
						if showDialogs:
							if r4rKYigFLvlUImcBERaq==l4DS8mnEjHhFMZ5YOe(u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩಕ"): aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬಖ"),DJ6ugPjW9bX8I(u"ࠪะ๏ีࠠอัสࠤ࠳࠴ࠠศๆศฺฬ็ษࠡๅส๊ฯࠦโะ์่อࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอัิ๐ห่ษ࡟ࡲࡡࡴࠧಗ")+ldJmEsIZY9A4pXStekwNoTV)
							elif r4rKYigFLvlUImcBERaq==flDSRbv57PnV3(u"ࠫ࡮ࡴࡳࡵࡣ࡯ࡰࡪࡪࠧಘ"): aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨಙ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ฬ๋ัࠣะิอࠠ࠯࠰ࠣห้หึศใฬࠤ้๋ࠠหๅ้ࠤ๊๎ฬ้ัฬࠤๆ๐ࠠไ๊า๎ࠥ࠴࠮๊ࠡส่อืๆศ็ฯࠤ็อๅࠡสอฯอ๐ส่ษ࡟ࡲࡡࡴࠧಚ")+ldJmEsIZY9A4pXStekwNoTV)
					elif showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪಛ"),Fo1SgXMsHk(u"ࠨๆ็วุ็ࠠ࠯࠰ࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ึฮ฼๐ูࠡฬะำ๏ัࠠฤ๊ࠣฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯ࡜࡯࡞ࡱࠫಜ")+ldJmEsIZY9A4pXStekwNoTV)
	elif showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬಝ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"่้ࠪษำโࠢ࠱࠲ࠥํะ่ࠢส่ส฼วโหࠣ฾๏ืࠠๆ๊ฯ์ิฯࠠโ์ุ้ࠣะ่ะ฻ࠣ฽๊อฯࠡ࠰࠱ࠤํ๊็ัษ่ࠣฬ๊ࠦิฬฺ๎฾ࠦวๅสิ๊ฬ๋ฬࠡล้ࠤ๏่่ๆࠢหฮะฮ๊ห๊ࠢิ์ࠦวๅวูหๆฯࠠฤ๊ࠣฮาี๊ฬ้สࡠࡳࡢ࡮ࠨಞ")+ldJmEsIZY9A4pXStekwNoTV)
	return succeeded,r4rKYigFLvlUImcBERaq,CmHdP8FiLUv1pR3k04honscZltb
def DDLHBPM3dqltVvkc2sYNWFXE07eAI(ldJmEsIZY9A4pXStekwNoTV,showDialogs,TbtfdnQu1W4NOJ,NmrqKDVFHyea4oYMjQ1wc3BJ=None,yWESdJ2nUj31M8ONktxl4=None):
	rrsIv1wTN7 = Ag9l6cw3EBqP8HsQuGMizfOtr4 if NmrqKDVFHyea4oYMjQ1wc3BJ else SmbNGskjMx
	if not rrsIv1wTN7:
		NmrqKDVFHyea4oYMjQ1wc3BJ = RhNFgjDTM1Zuakqx4K925EiLoAHUcz.connect(zZ9tVvyojlWYupgSJxDImHdLsUFTNq)
		NmrqKDVFHyea4oYMjQ1wc3BJ.text_factory = str
		yWESdJ2nUj31M8ONktxl4 = NmrqKDVFHyea4oYMjQ1wc3BJ.cursor()
	succeeded,QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d = Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx
	try:
		PKgaceuLwyM = flDSRbv57PnV3(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠭ಟ")
		yWESdJ2nUj31M8ONktxl4.execute(QlTuvPbSpnjygBVW(u"࡙ࠬࡅࡍࡇࡆࡘࠥࡵࡲࡪࡩ࡬ࡲࠥࡌࡒࡐࡏࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩࠦࡗࡉࡇࡕࡉࠥࡧࡤࡥࡱࡱࡍࡉࠦ࠽ࠡࠤࠪಠ")+ldJmEsIZY9A4pXStekwNoTV+IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࠢࠡ࠽ࠪಡ"))
		vDimntp752hHxBRQSX = yWESdJ2nUj31M8ONktxl4.fetchall()
		if vDimntp752hHxBRQSX and PKgaceuLwyM not in str(vDimntp752hHxBRQSX): yWESdJ2nUj31M8ONktxl4.execute(l4DS8mnEjHhFMZ5YOe(u"ࠧࡖࡒࡇࡅ࡙ࡋࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠣࡗࡊ࡚ࠠࡰࡴ࡬࡫࡮ࡴࠠ࠾ࠢࠥࠫಢ")+PKgaceuLwyM+bnI4kmPtrW7yFEhljXOCq9(u"ࠨࠤ࡛ࠣࡍࡋࡒࡆࠢࡤࡨࡩࡵ࡮ࡊࡆࠣࡁࠥࠨࠧಣ")+ldJmEsIZY9A4pXStekwNoTV+tM24jD1gO0(u"ࠩࠥࠤࡀ࠭ತ"))
		Jld52fXH1tO = DJ6ugPjW9bX8I(u"ࠪࡦࡱࡧࡣ࡬࡮࡬ࡷࡹ࠭ಥ") if n7neb9KTv10FcU else X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡺࡶࡤࡢࡶࡨࡣࡷࡻ࡬ࡦࡵࠪದ")
		yWESdJ2nUj31M8ONktxl4.execute(tM24jD1gO0(u"࡙ࠬࡅࡍࡇࡆࡘࠥ࠰ࠠࡇࡔࡒࡑࠥ࠭ಧ")+Jld52fXH1tO+z3sIGH8jmLYg(u"࠭ࠠࡘࡊࡈࡖࡊࠦࡡࡥࡦࡲࡲࡎࡊࠠ࠾ࠢࠥࠫನ")+ldJmEsIZY9A4pXStekwNoTV+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࠣࠢ࠾ࠫ಩"))
		vDimntp752hHxBRQSX = yWESdJ2nUj31M8ONktxl4.fetchall()
		if vDimntp752hHxBRQSX:
			if showDialogs: oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫಪ"),flDSRbv57PnV3(u"ࠩส่ฯำฯ๋อࠣห้ษ่ห๊่หฯ๐ใ๋ࠢ็ษ฻อแสࠢ࡟ࡲࠥ࠭ಫ")+ldJmEsIZY9A4pXStekwNoTV+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࠤࡡࡴ࡜࡯ࠢࠪಬ")+eMypvI8XqHjYU02anWD9gsSrkt+Fo1SgXMsHk(u"๋ࠫࠥส้ไไࠤํ๊วࠡ์฼้้ࠦ࠮࠯๊่ࠢࠥะั๋ัࠣฮๆ฿๊ๅ้ࠣห้ศๆࠡมࠤࠥࠥ࠭ಭ")+c7gxFyUCGm+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࠦ࡜࡯࡞ࡱࠤฯูสุ์฼ࠤส๐โศใ๊ࠤอู็้ๆฬࠤ฾์ฯࠡษ็฽ํีษࠡว็ํࠥํะ่ࠢสู่อิสࠢส่๊๎ฬ้ัฬࠤๆ๐ࠠใษษ้ฮࠦฮะ็สฮࠥฮั็ษ่ะࠥ฿ๅศัࠪಮ"))
			else: oyNUHM3uQq = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			if oyNUHM3uQq==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d = Ag9l6cw3EBqP8HsQuGMizfOtr4
				yWESdJ2nUj31M8ONktxl4.execute(l4DS8mnEjHhFMZ5YOe(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠬಯ")+Jld52fXH1tO+DJ6ugPjW9bX8I(u"࡙ࠧࠡࡋࡉࡗࡋࠠࡢࡦࡧࡳࡳࡏࡄࠡ࠿ࠣࠦࠬರ")+ldJmEsIZY9A4pXStekwNoTV+IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࠤࠣ࠿ࠬಱ"))
		elif TbtfdnQu1W4NOJ:
			if showDialogs: oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬಲ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪห้ะอะ์ฮࠤฬ๊ร้ฬ๋้ฬะ๊ไ์่ࠣส฼วโหࠣࡠࡳࠦࠧಳ")+ldJmEsIZY9A4pXStekwNoTV+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࠥࡢ࡮࡝ࡰࠣࠫ಴")+eMypvI8XqHjYU02anWD9gsSrkt+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࠦๅโ฻็ࠤํ๐ูๆๆࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ์ๅหๆํࠠศๆล๊ࠥลࠡࠢࠢࠪವ")+c7gxFyUCGm+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࠠ࡝ࡰ࡟ࡲࠥะำหูํ฽ࠥะแฺ์็๋ࠥฮำ่๊็อࠥ฿ๆะࠢส่฾๎ฯสࠢศ่๎ࠦ็ั้ࠣหฺ้วีหࠣห้๋่อ๊าอࠥ็๊ࠡไสส๊ฯࠠฯั่หฯࠦศา่ส้ัูࠦๆษาࠫಶ"))
			else: oyNUHM3uQq = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			if oyNUHM3uQq==vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d = Ag9l6cw3EBqP8HsQuGMizfOtr4
				if n7neb9KTv10FcU: yWESdJ2nUj31M8ONktxl4.execute(fgv5U2eRVaQqSiuGD(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥ࠭ಷ")+Jld52fXH1tO+I3cxjYaHhsrM7T4UX26klN(u"ࠨࠢࠫࡥࡩࡪ࡯࡯ࡋࡇ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨಸ")+ldJmEsIZY9A4pXStekwNoTV+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠥ࠭ࠥࡁࠧಹ"))
				else: yWESdJ2nUj31M8ONktxl4.execute(tM24jD1gO0(u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩ಺")+Jld52fXH1tO+tM24jD1gO0(u"ࠫࠥ࠮ࡡࡥࡦࡲࡲࡎࡊࠬࡶࡲࡧࡥࡹ࡫ࡒࡶ࡮ࡨ࠭ࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮ࠢࠨ಻")+ldJmEsIZY9A4pXStekwNoTV+z3sIGH8jmLYg(u"ࠬࠨࠬ࠲ࠫࠣ࠿಼ࠬ"))
	except: succeeded = SmbNGskjMx
	if showDialogs and QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d:
		if succeeded: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩಽ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧ็ฮะฮࠥ฿ๅๅ์ฬࠤส฻ไศฯࠣฮาี๊ฬࠢส่ส฼วโหࠣࡠࡳࡢ࡮ࠨಾ")+ldJmEsIZY9A4pXStekwNoTV)
		else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫಿ"),DJ6ugPjW9bX8I(u"ࠩไุ้ะฺࠠ็็๎ฮࠦลึๆสัࠥะอะ์ฮࠤฬ๊ลืษไอࠥࡢ࡮࡝ࡰࠪೀ")+ldJmEsIZY9A4pXStekwNoTV)
	if not rrsIv1wTN7:
		NmrqKDVFHyea4oYMjQ1wc3BJ.commit()
		NmrqKDVFHyea4oYMjQ1wc3BJ.close()
		if QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d:
			lQMuw1PvVpAk.sleep(z3sIGH8jmLYg(u"࠷൞"))
			RarSo2nTfwU0WEGK.executebuiltin(t4txivgXSUWBOlCakQmNDjf(u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧು"))
			lQMuw1PvVpAk.sleep(YayJj10OGl(u"࠱ൟ"))
	return QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d
def r9aD2vZsWo3bMe(CCcLZqdnhFeisHmW,showDialogs,XS3QTrpkc8qgUVzMHvKwfNoYjdt5,TbtfdnQu1W4NOJ):
	NmrqKDVFHyea4oYMjQ1wc3BJ = RhNFgjDTM1Zuakqx4K925EiLoAHUcz.connect(zZ9tVvyojlWYupgSJxDImHdLsUFTNq)
	NmrqKDVFHyea4oYMjQ1wc3BJ.text_factory = str
	yWESdJ2nUj31M8ONktxl4 = NmrqKDVFHyea4oYMjQ1wc3BJ.cursor()
	QCkFNzuGpZwqEmb = wQ5nCz7RXvZJ(CCcLZqdnhFeisHmW)
	B2VwufMsHyxTRLon3jpv = SmbNGskjMx
	for ldJmEsIZY9A4pXStekwNoTV in CCcLZqdnhFeisHmW:
		succeeded,r4rKYigFLvlUImcBERaq,CmHdP8FiLUv1pR3k04honscZltb = bb7p5GtMnXDJ(ldJmEsIZY9A4pXStekwNoTV,showDialogs,XS3QTrpkc8qgUVzMHvKwfNoYjdt5,QCkFNzuGpZwqEmb)
		QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d = DDLHBPM3dqltVvkc2sYNWFXE07eAI(ldJmEsIZY9A4pXStekwNoTV,showDialogs,TbtfdnQu1W4NOJ,NmrqKDVFHyea4oYMjQ1wc3BJ,yWESdJ2nUj31M8ONktxl4)
		if QmOoXKHGDU1j4xFiR7nM0AfhSg6c5d: B2VwufMsHyxTRLon3jpv = Ag9l6cw3EBqP8HsQuGMizfOtr4
	NmrqKDVFHyea4oYMjQ1wc3BJ.commit()
	NmrqKDVFHyea4oYMjQ1wc3BJ.close()
	if B2VwufMsHyxTRLon3jpv:
		lQMuw1PvVpAk.sleep(flDSRbv57PnV3(u"࠲ൠ"))
		RarSo2nTfwU0WEGK.executebuiltin(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨೂ"))
		lQMuw1PvVpAk.sleep(QlTuvPbSpnjygBVW(u"࠳ൡ"))
	if showDialogs:
		if len(CCcLZqdnhFeisHmW)>fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠴ൢ"): aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨೃ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭สๆࠢห๊ัออࠡใะูࠥาๅ๋฻ࠣห้หึศใสฮࠬೄ"))
		else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,I3cxjYaHhsrM7T4UX26klN(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ೅"),X1mRwt2YJKgCLu9a67(u"ࠨฬ่ࠤอ์ฬศฯࠣๅา฻ࠠศๆศฺฬ็ษ࡝ࡰ࡟ࡲࠬೆ")+CCcLZqdnhFeisHmW[flDSRbv57PnV3(u"࠴ൣ")])
	return
def mmhRocLej7aHKt4QYIyJNp9Bk(showDialogs):
	L1KgueY4Pf28 = [l4DS8mnEjHhFMZ5YOe(u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠧೇ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨࠬೈ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡲࡵࡤࡶ࡮ࡨ࠲ࡷ࡫ࡳࡰ࡮ࡹࡩࡺࡸ࡬ࠨ೉"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿࡴ࠮ࡦ࡯ࡴࠬೊ")]
	R8RAdwuqjJQU75COkzxB3pL = [IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡲࡦࡲࡲࡷ࡮ࡺ࡯ࡳࡻ࠱ࡩࡲࡧࡤ࠯ࡱࡷ࡬ࡪࡸࡳࠨೋ"),UpQ56M0dO1N9xIvVegy(u"ࠧࡳࡧࡳࡳࡸ࡯ࡴࡰࡴࡼ࠲ࡪࡳࡡࡥ࠰ࡪ࡭ࡹ࡫ࡥࠨೌ"),z3sIGH8jmLYg(u"ࠨࡴࡨࡴࡴࡹࡩࡵࡱࡵࡽ࠳࡫࡭ࡢࡦ࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ್ࠫ"),fgv5U2eRVaQqSiuGD(u"ࠩࡵࡩࡵࡵࡳࡪࡶࡲࡶࡾ࠴ࡥ࡮ࡣࡧ࠲࡬࡯ࡴࡩࡷࡥࠫ೎"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡶࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿ࠮ࡦ࡯ࡤࡨ࠳࡭ࡩࡵࡧࡤࠫ೏"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡷ࡫ࡰࡰࡵ࡬ࡸࡴࡸࡹ࠯ࡧࡰࡥࡩ࠴ࡣࡰࡦࡨࡦࡪࡸࡧࠨ೐")]
	for ldJmEsIZY9A4pXStekwNoTV in R8RAdwuqjJQU75COkzxB3pL: XXWuibYBkaFP1rA(ldJmEsIZY9A4pXStekwNoTV)
	r9aD2vZsWo3bMe(L1KgueY4Pf28,showDialogs,SmbNGskjMx,SmbNGskjMx)
	return
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'ARABSEED'
headers = {'User-Agent':MdwGcQOsmlV6vKI73THrUY4()}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_ARS_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['الرئيسية','المضاف حديثاً','مصارعه','اعلن معنا – For ads','موبايلات','برامج كمبيوتر','العاب كمبيوتر','اسلاميات','اخرى','اقسام اخري','اشتراكات']
def n1zxUlcAgR(mode,url,text):
	if   mode==250: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==251: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==252: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==253: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==254: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'CATEGORIES___'+text)
	elif mode==255: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'FILTERS___'+text)
	elif mode==256: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url,text)
	elif mode==259: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs+'/main',nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,259,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',zKREXyTHfVSNL8ZFYs+'/category/اخرى',254)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',zKREXyTHfVSNL8ZFYs+'/category/اخرى',255)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',zKREXyTHfVSNL8ZFYs+'/main',251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured_main')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'جديد الأفلام',zKREXyTHfVSNL8ZFYs+'/main',251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'new_movies')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'جديد الحلقات',zKREXyTHfVSNL8ZFYs+'/main',251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'new_episodes')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المضاف حديثاً',zKREXyTHfVSNL8ZFYs+'/latest',251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'lastest')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('class="MenuHeader"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	eXBMHvPbDunL = b8Ior2kWzq1tc[0]
	XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',eXBMHvPbDunL,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG:
		title = dCtxzeFX4GJVonm(title)
		if title not in CZrI4vYju7a and title!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,256)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Cvflxc4FMs37bmY(url,type):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if 'class="SliderInSection' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الأكثر مشاهدة',url,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'most')
	if 'class="MainSlides' in UTvsQb4HpCP3Aeo2wDZG7X5V: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',url,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
	if 'class="LinksList' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="LinksList(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			if len(eXpgPIbRv2ZMGwjm5)>1 and type=='new_episodes': G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[1]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				HDE69mkhQg2NaFpuUy5JRb = ScntgdOZCY74vNpXeW5jh8i.findall('</i>(.*?)<span>(.*?)<',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				try: BfM7ldYzjy5qVPoeJuN2QEpL9 = HDE69mkhQg2NaFpuUy5JRb[0][0].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				except: BfM7ldYzjy5qVPoeJuN2QEpL9 = nbOFVEDkpT4BIR7Qq82yPmHeJU
				try: DC7SYfy8Av6BQ9jZTql1cEoI03dFr = HDE69mkhQg2NaFpuUy5JRb[0][1].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				except: DC7SYfy8Av6BQ9jZTql1cEoI03dFr = nbOFVEDkpT4BIR7Qq82yPmHeJU
				HDE69mkhQg2NaFpuUy5JRb = BfM7ldYzjy5qVPoeJuN2QEpL9+S3X6GcaiExOPtb+DC7SYfy8Av6BQ9jZTql1cEoI03dFr
				if '<strong>' in title:
					CgPhBrkIZpi = ScntgdOZCY74vNpXeW5jh8i.findall('</i>(.*?)<',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if CgPhBrkIZpi: HDE69mkhQg2NaFpuUy5JRb = CgPhBrkIZpi[0]
				if not HDE69mkhQg2NaFpuUy5JRb:
					CgPhBrkIZpi = ScntgdOZCY74vNpXeW5jh8i.findall('alt="(.*?)"',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if CgPhBrkIZpi: HDE69mkhQg2NaFpuUy5JRb = CgPhBrkIZpi[0]
				if HDE69mkhQg2NaFpuUy5JRb:
					if 'key=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: type = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('key=')[1]
					else: type = 'newest'
					HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.strip(S3X6GcaiExOPtb)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,type)
	return
def IGDobAKtj4kPF5V(url,type):
	nvEb1Jx3qZo8Vk7Dgih2,data,items = 'GET',nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	if type=='filters':
		if '?' in url:
			Ps2BDkViKJGt,J27qXeRCpsgkEoT9Q0GYS6ct = 'POST',{}
			plSscrVjkRviPwm,zBk0VHdLqXOQ = url.split('?')
			FV968pLETkDJwxhXlye2O5ScH = zBk0VHdLqXOQ.split('&')
			for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in FV968pLETkDJwxhXlye2O5ScH:
				key,XPL0O2VkI3w1C8enMaqi = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U.split('=')
				J27qXeRCpsgkEoT9Q0GYS6ct[key] = XPL0O2VkI3w1C8enMaqi
			if FV968pLETkDJwxhXlye2O5ScH: nvEb1Jx3qZo8Vk7Dgih2,url,data = Ps2BDkViKJGt,plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,nvEb1Jx3qZo8Vk7Dgih2,url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if type=='filters': eXpgPIbRv2ZMGwjm5 = [UTvsQb4HpCP3Aeo2wDZG7X5V]
	elif 'featured' in type: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="MainSlides(.*?)class="LinksList',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='new_movies': eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('جديد الافلام.*?class="SliderInSection"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='new_episodes': eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('جديد الحلقات.*?class="SliderInSection"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='most': eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="SliderInSection(.*?)class="LinksList',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="Blocks-UL"(.*?)class="AboElSeed"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if 'featured' in type:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		WVosY6eP9At75ldUGJ1jKiT = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)" title="(.*?)".*?data-lazy.*? (src|data-image)="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if WVosY6eP9At75ldUGJ1jKiT:
			lPpY5fw3tOBcEye91Caun2FQZ,bbKoeBcirVfzwAqZdQUFDSX,hy1pOXkjI3KgHEruDFf2Zm,kZIdwFKsfN4qSOulRC3gcxz = zip(*WVosY6eP9At75ldUGJ1jKiT)
			items = zip(lPpY5fw3tOBcEye91Caun2FQZ,kZIdwFKsfN4qSOulRC3gcxz,bbKoeBcirVfzwAqZdQUFDSX)
	else:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('LoadingArea.*? href="(.*?)".*? data-\w{3,5}="(.*?)".*? alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if 'WWE' in title: continue
		title = dCtxzeFX4GJVonm(title)
		if 'الحلقة' in title:
			BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if BBuqr7CwzEIi9UL54n0AVoHXPlp:
				title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
				if title not in tWsVFQj47pw0L56rZfg:
					tWsVFQj47pw0L56rZfg.append(title)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,253,X79kphTKa1xLP)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,252,X79kphTKa1xLP)
		elif '/selary/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or 'مسلسل' in title:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,253,X79kphTKa1xLP)
		else:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,252,X79kphTKa1xLP)
	if type in ['newest','best','most']:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('page-numbers" href="(.*?)">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dCtxzeFX4GJVonm(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			title = dCtxzeFX4GJVonm(title)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,type)
	return
def PXyn8J3WjhRgA(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V[10000:]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-src="(.*?)".*?alt="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: return
	X79kphTKa1xLP,name = items[0]
	if 'الحلقة' in name: name = name.split('الحلقة')[0].strip(S3X6GcaiExOPtb)
	elif 'حلقة' in name: name = name.split('حلقة')[0].strip(S3X6GcaiExOPtb)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="ContainerEpisodesList"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<em>(.*?)</em>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,BBuqr7CwzEIi9UL54n0AVoHXPlp in items:
			title = name+' - الحلقة رقم '+BBuqr7CwzEIi9UL54n0AVoHXPlp
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,252,X79kphTKa1xLP)
	else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'ملف التشغيل',url,252,X79kphTKa1xLP)
	return
def W28MdufbyFODZTz(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	HDE69mkhQg2NaFpuUy5JRb = ScntgdOZCY74vNpXeW5jh8i.findall('[a-zA-Z-]+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if HDE69mkhQg2NaFpuUy5JRb: title = HDE69mkhQg2NaFpuUy5JRb[0]
	else: title = title+S3X6GcaiExOPtb+Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
	title = title.replace('عرب سيد',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('مباشر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('مشاهدة',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	title = title.replace('ٍ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	title = title.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	return title
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	plSscrVjkRviPwm = cnPhVmgFxA.url
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,'url')
	headers['Referer'] = RWZpkDLtY5Eyb46029MvAKmqBQd8o+'/'
	ibWVaumvdO0SF3,BZJE74zAYlvgmbIOdpw6tHkfc,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	wv7sgkDQndO8PS2 = ScntgdOZCY74vNpXeW5jh8i.findall('class="WatchButtons".*?href="(.*?)" class="(watch.*?)".*?href="(.*?)" class="(download.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if wv7sgkDQndO8PS2: ibWVaumvdO0SF3,gg8S4FihUQy0V26,BZJE74zAYlvgmbIOdpw6tHkfc,nFE7RXAdxPUaktfcCDwZGsQhMzybmY = wv7sgkDQndO8PS2[0]
	else:
		wv7sgkDQndO8PS2 = ScntgdOZCY74vNpXeW5jh8i.findall('class="WatchButtons".*?href="(.*?)" class="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if wv7sgkDQndO8PS2:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,gg8S4FihUQy0V26 = wv7sgkDQndO8PS2[0]
			if 'watch' in gg8S4FihUQy0V26: ibWVaumvdO0SF3 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			else: BZJE74zAYlvgmbIOdpw6tHkfc = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	if ibWVaumvdO0SF3:
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',ibWVaumvdO0SF3,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-PLAY-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="WatcherArea(.*?</ul>)',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			blRyHafBGwW = eXpgPIbRv2ZMGwjm5[0]
			blRyHafBGwW = blRyHafBGwW.replace('</ul>','<h3>')
			blRyHafBGwW = blRyHafBGwW.replace('<h3>','<h3><h3>')
			ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('<h3>.*?(\d+)(.*?)<h3>',blRyHafBGwW,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = [(nbOFVEDkpT4BIR7Qq82yPmHeJU,blRyHafBGwW)]
			for uTKGhcXEIpmDf,G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
				if uTKGhcXEIpmDf: uTKGhcXEIpmDf = '____'+uTKGhcXEIpmDf
				items = ScntgdOZCY74vNpXeW5jh8i.findall('data-link="(.*?)".*?<span>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
					if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__watch'+uTKGhcXEIpmDf
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('class="containerIframe".*? src="(.*?)".*? height="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not rU02bCJFWZDfVuhtMgBOyQi5P: rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('class="containerIframe".*? SRC="(.*?)".*? HEIGHT="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if rU02bCJFWZDfVuhtMgBOyQi5P:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf = rU02bCJFWZDfVuhtMgBOyQi5P[0]
			name = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
			if '%' in uTKGhcXEIpmDf: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__embed__'
			else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__embed____'+uTKGhcXEIpmDf
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if BZJE74zAYlvgmbIOdpw6tHkfc:
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',BZJE74zAYlvgmbIOdpw6tHkfc,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-PLAY-3rd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="DownloadArea(.*?)<script src=',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			blRyHafBGwW = eXpgPIbRv2ZMGwjm5[0]
			ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('class="DownloadServers(.*?)</ul>',blRyHafBGwW,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<span>(.*?)</span>.*?<p>(.*?)</p>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,uTKGhcXEIpmDf in items:
					if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
					if 'reviewstation' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download____'+uTKGhcXEIpmDf
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	CnyV3ckvP7SiYD24H8Ktsp1 = str(lPpY5fw3tOBcEye91Caun2FQZ)
	DLbKeGuPcnpS = ['.zip?','.rar?','.txt?','.pdf?','.tar?','.iso?','.zip.','.rar.','.txt.','.pdf.','.tar.','.iso.']
	if any(XPL0O2VkI3w1C8enMaqi in CnyV3ckvP7SiYD24H8Ktsp1 for XPL0O2VkI3w1C8enMaqi in DLbKeGuPcnpS):
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','جرب رابط مختلف لأن هذا الرابط ليس من نوع الروابط التي فيها ملفات فيديو .. لأن هذا الموقع فيه خدمات أخرى غير ملفات الفيديو')
		return
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search: search = dR75Vq2gprfHmUcNhG()
	if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/find/?find='+search
	IGDobAKtj4kPF5V(url,'search')
	return
def bpRLN7ZqT5BiXKfMdI(url,filter):
	if '??' in url: url = url.split('//getposts??')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='CATEGORIES':
		if Udh6nNR7sXA[0]+'==' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = Udh6nNR7sXA[0]
		for WoEZvMXa0K2suwgPl in range(len(Udh6nNR7sXA[0:-1])):
			if Udh6nNR7sXA[WoEZvMXa0K2suwgPl]+'==' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = Udh6nNR7sXA[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'==0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'==0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&&')+'___'+bhz0GBTNQdYxvnt.strip('&&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'//getposts??'+soAjtN3yd04Jzr
	elif type=='FILTERS':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'//getposts??'+RAf62IHC9L0OUl1oETijSgyxX5F
		jYzLtvxkH7R3msNZwhgeT90noEu5q = uuJH6gRYp415Vbscw9xOhelA8(plSscrVjkRviPwm)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',jYzLtvxkH7R3msNZwhgeT90noEu5q,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',jYzLtvxkH7R3msNZwhgeT90noEu5q,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'POST',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARABSEED-FILTERS_MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="TaxPageFilter"(.*?)class="TermBTNs"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	OIJlCBpLXPKin = ScntgdOZCY74vNpXeW5jh8i.findall('class="TaxPageFilterItem".*?<em>(.*?)</em>.*?data-tax="(.*?)"(.*?)</ul>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	emj4wxgTuCzcAd = ScntgdOZCY74vNpXeW5jh8i.findall('class="RatingFilter".*?<h4>(.*?)</h4>.*?(<ul>)(.*?)</ul>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	m8kVhKyAp7NCibFJ3sYO4EwMS = OIJlCBpLXPKin+emj4wxgTuCzcAd
	dict = {}
	for name,TT4Yd6yIaJGxZtoR8mh2O7,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-name="(.*?)".*?data-tax="(.*?)".*?data-term="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if name=='اخرى': name = 'الاقسام'
		if not items:
			XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('data-rate="(.*?)".*?<em>(.*?)</em>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			items = []
			for PspiL81kMT4BwOIXo,XPL0O2VkI3w1C8enMaqi in XhE8FpdTjG: items.append([PspiL81kMT4BwOIXo,nbOFVEDkpT4BIR7Qq82yPmHeJU,XPL0O2VkI3w1C8enMaqi])
			TT4Yd6yIaJGxZtoR8mh2O7 = 'rate'
			name = 'التقييم'
		else: TT4Yd6yIaJGxZtoR8mh2O7 = items[0][1]
		if '==' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='CATEGORIES':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<=1:
				if TT4Yd6yIaJGxZtoR8mh2O7==Udh6nNR7sXA[-1]: IGDobAKtj4kPF5V(plSscrVjkRviPwm)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'CATEGORIES___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				jYzLtvxkH7R3msNZwhgeT90noEu5q = uuJH6gRYp415Vbscw9xOhelA8(plSscrVjkRviPwm)
				if TT4Yd6yIaJGxZtoR8mh2O7==Udh6nNR7sXA[-1]: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',jYzLtvxkH7R3msNZwhgeT90noEu5q,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',plSscrVjkRviPwm,254,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='FILTERS':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'==0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'==0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع :'+name,plSscrVjkRviPwm,255,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for PspiL81kMT4BwOIXo,uiazRbmZ63Je21WGqn,XPL0O2VkI3w1C8enMaqi in items:
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			if 'الكل' in PspiL81kMT4BwOIXo: continue
			PspiL81kMT4BwOIXo = dCtxzeFX4GJVonm(PspiL81kMT4BwOIXo)
			TKgxmZYczq9oPUWni4ak0NM6,HDE69mkhQg2NaFpuUy5JRb = PspiL81kMT4BwOIXo,PspiL81kMT4BwOIXo
			HDE69mkhQg2NaFpuUy5JRb = name+': '+TKgxmZYczq9oPUWni4ak0NM6
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = HDE69mkhQg2NaFpuUy5JRb
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'=='+TKgxmZYczq9oPUWni4ak0NM6
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'=='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			if type=='FILTERS':
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,url,255,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='CATEGORIES' and Udh6nNR7sXA[-2]+'==' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
				zb2QIaL7Y4h9g8lSck = url+'//getposts??'+soAjtN3yd04Jzr
				jYzLtvxkH7R3msNZwhgeT90noEu5q = uuJH6gRYp415Vbscw9xOhelA8(zb2QIaL7Y4h9g8lSck)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,jYzLtvxkH7R3msNZwhgeT90noEu5q,251,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,url,254,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
Udh6nNR7sXA = ['category','country','release-year']
PAV4cdOXGlj7WFbBnptZJ = ['category','country','genre','release-year','language','quality','rate']
def uuJH6gRYp415Vbscw9xOhelA8(url):
	SmK5wyINUaWHV4poRtTiE = '/wp-content/themes/Elshaikh2021/Ajaxat/Home/FilteringHome.php'
	url = url.replace('//getposts',SmK5wyINUaWHV4poRtTiE)
	url = url.replace('/category/اخرى',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if SmK5wyINUaWHV4poRtTiE not in url: url = url+SmK5wyINUaWHV4poRtTiE
	url = url.replace('release-year','year')
	url = url.replace('??','?')
	url = url.replace('&&','&')
	url = url.replace('==','=')
	return url
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&&')
	brRAuE46JNZfie,OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = {},nbOFVEDkpT4BIR7Qq82yPmHeJU
	if '==' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('==')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	for key in PAV4cdOXGlj7WFbBnptZJ:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&&'+key+'=='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&&'+key+'=='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&&')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
QSJFrwB3dMiyH2mTPKD9a = 'AKOAM'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_AKO_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
XrpmDukA7JNIefBZwGCglHOSQ9P2y = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def n1zxUlcAgR(mode,url,text):
	if   mode==70: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==71: bPFto2wZdNYrClgBIEv60DJAzu = Q5Q4NriupnKU(url)
	elif mode==72: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==73: bPFto2wZdNYrClgBIEv60DJAzu = rWRhpCAfTvQ38wblL9ONi4sZuKHz(url)
	elif mode==74: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==79: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,79,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'سلسلة افلام',nbOFVEDkpT4BIR7Qq82yPmHeJU,79,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'سلسلة افلام')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'سلاسل منوعة',nbOFVEDkpT4BIR7Qq82yPmHeJU,79,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'سلسلة')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	CZrI4vYju7a = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKOAM-MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="partions"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title not in CZrI4vYju7a:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,71)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Q5Q4NriupnKU(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKOAM-CATEGORIES-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('sect_parts(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,72)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'جميع الفروع',url,72)
	else: IGDobAKtj4kPF5V(url,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return
def IGDobAKtj4kPF5V(url,type):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('section_title featured_title(.*?)subjects-crousel',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='search':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('akoam_result(.*?)<script',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='more':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('section_title more_title(.*?)footer_bottom_services',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('navigation(.*?)<script',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items and eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		title = dCtxzeFX4GJVonm(title)
		if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in XrpmDukA7JNIefBZwGCglHOSQ9P2y): Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,73,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,73,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall("</li><li >.*?href='(.*?)'>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,72,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,type)
	return
def h3gvEfA9VGzHaZD8bTNksliY2oeqIu(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKOAM-SECTIONS-2nd')
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('"href","(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = plSscrVjkRviPwm[1]
	return plSscrVjkRviPwm
def rWRhpCAfTvQ38wblL9ONi4sZuKHz(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKOAM-SECTIONS-1st')
	foXF8e9giD = ScntgdOZCY74vNpXeW5jh8i.findall('"(https*://akwam.net/\w+.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	QgPip74XoBW93u = ScntgdOZCY74vNpXeW5jh8i.findall('"(https*://underurl.com/\w+.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if foXF8e9giD or QgPip74XoBW93u:
		if foXF8e9giD: zb2QIaL7Y4h9g8lSck = foXF8e9giD[0]
		elif QgPip74XoBW93u: zb2QIaL7Y4h9g8lSck = h3gvEfA9VGzHaZD8bTNksliY2oeqIu(QgPip74XoBW93u[0])
		zb2QIaL7Y4h9g8lSck = SxN0jnqr3LI(zb2QIaL7Y4h9g8lSck)
		import Hn1ehdUPB2
		if '/series/' in zb2QIaL7Y4h9g8lSck or '/shows/' in zb2QIaL7Y4h9g8lSck: Hn1ehdUPB2.PXyn8J3WjhRgA(zb2QIaL7Y4h9g8lSck)
		else: Hn1ehdUPB2.AOk1T6KwciHrWU2MYJzZnEN(zb2QIaL7Y4h9g8lSck)
		return
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = dCtxzeFX4GJVonm(title)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,73)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5:
		SSVCGE0bOfW1w9u52yvBxocNeP('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,X79kphTKa1xLP,G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	name = name.strip(S3X6GcaiExOPtb)
	if 'sub_epsiode_title' in G4JHzTEp61:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		lV6L40jpTyBPs9RHFYS8eoExDuwQa = ScntgdOZCY74vNpXeW5jh8i.findall('sub_file_title\'>(.*?) - <i>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		items = []
		for filename in lV6L40jpTyBPs9RHFYS8eoExDuwQa:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',nbOFVEDkpT4BIR7Qq82yPmHeJU) ]
	count = 0
	bbKoeBcirVfzwAqZdQUFDSX,WWQSVCetT6cM = [],[]
	size = len(items)
	for title,filename in items:
		D63UZqx2XBgrtbje = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: D63UZqx2XBgrtbje = filename.split('.')[-1]
		title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		bbKoeBcirVfzwAqZdQUFDSX.append(title)
		WWQSVCetT6cM.append(count)
		count += 1
	if size>0:
		if any(XPL0O2VkI3w1C8enMaqi in name for XPL0O2VkI3w1C8enMaqi in XrpmDukA7JNIefBZwGCglHOSQ9P2y):
			if size==1:
				bCiGxXzDkH = 0
			else:
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الفيديو المناسب:', bbKoeBcirVfzwAqZdQUFDSX)
				if bCiGxXzDkH == -1: return
			AOk1T6KwciHrWU2MYJzZnEN(url+'?section='+str(1+WWQSVCetT6cM[size-bCiGxXzDkH-1]))
		else:
			for WoEZvMXa0K2suwgPl in reversed(range(size)):
				title = name + ' - ' + bbKoeBcirVfzwAqZdQUFDSX[WoEZvMXa0K2suwgPl]
				title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url + '?section='+str(size-WoEZvMXa0K2suwgPl)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,74,X79kphTKa1xLP)
	else:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الرابط ليس فيديو',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	plSscrVjkRviPwm,BBuqr7CwzEIi9UL54n0AVoHXPlp = url.split('?section=')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKOAM-PLAY_AKOAM-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	blRyHafBGwW = eXpgPIbRv2ZMGwjm5[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	blRyHafBGwW = blRyHafBGwW + 'direct_link_box'
	ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('epsoide_box(.*?)direct_link_box',blRyHafBGwW,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	BBuqr7CwzEIi9UL54n0AVoHXPlp = len(ISmqngYzv6jrepWUx0l)-int(BBuqr7CwzEIi9UL54n0AVoHXPlp)
	G4JHzTEp61 = ISmqngYzv6jrepWUx0l[BBuqr7CwzEIi9UL54n0AVoHXPlp]
	NWtqFg91ZSKinvIwAc = []
	EKMW9xjHLJnYg = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = ScntgdOZCY74vNpXeW5jh8i.findall("class='download_btn.*?href='(.*?)'",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=________akoam')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for rdumMQfvCyJtlew6i1kEsZ4DoWn,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		rdumMQfvCyJtlew6i1kEsZ4DoWn = rdumMQfvCyJtlew6i1kEsZ4DoWn.split('/')[-1]
		rdumMQfvCyJtlew6i1kEsZ4DoWn = rdumMQfvCyJtlew6i1kEsZ4DoWn.split('.')[0]
		if rdumMQfvCyJtlew6i1kEsZ4DoWn in EKMW9xjHLJnYg:
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+EKMW9xjHLJnYg[rdumMQfvCyJtlew6i1kEsZ4DoWn]+'________akoam')
		else: NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+rdumMQfvCyJtlew6i1kEsZ4DoWn+'________akoam')
	if not NWtqFg91ZSKinvIwAc:
		message = ScntgdOZCY74vNpXeW5jh8i.findall('sub-no-file.*?\n(.*?)\n',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if message: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من الموقع الاصلي',message[0])
	else:
		import gdVOXAx7tm
		gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'%20')
	url = zKREXyTHfVSNL8ZFYs + '/search/'+T871qPZzS4LkoMBa3Db9Q
	bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,'search')
	return
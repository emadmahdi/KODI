# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'DAILYMOTION'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_DLM_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
C07t1e38mH2LEMzny4vX9riOblaBF = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][1]
def n1zxUlcAgR(mode,url,text,type,ohpwd6UumaecE3IWV8lAv0):
	if	 mode==400: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==401: bPFto2wZdNYrClgBIEv60DJAzu = DqLOSxl8dU57viRfAQI0ksbZJp6Wr(url,text)
	elif mode==402: bPFto2wZdNYrClgBIEv60DJAzu = GJlbUVLomsCYR2X1OFrA0i9g74ED(url,text)
	elif mode==403: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url,text)
	elif mode==404: bPFto2wZdNYrClgBIEv60DJAzu = Epr5BwC3u8ltKAcQnzRISd97L2k(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==405: bPFto2wZdNYrClgBIEv60DJAzu = M6VsaDJK9h48HkBN0gwtT1dbuX(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==406: bPFto2wZdNYrClgBIEv60DJAzu = hhyXq2ot0AxWKe6Y(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==407: bPFto2wZdNYrClgBIEv60DJAzu = vcz5iqLYCEK7bgpretf2O(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==408: bPFto2wZdNYrClgBIEv60DJAzu = cL5jwN4AvIP2bG3(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==409: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==411: bPFto2wZdNYrClgBIEv60DJAzu = snm6EQPzui54Dw(url,text)
	elif mode==414: bPFto2wZdNYrClgBIEv60DJAzu = qJS9BdrAOajN(text)
	elif mode==415: bPFto2wZdNYrClgBIEv60DJAzu = Wq9dTKiVHGmB(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==416: bPFto2wZdNYrClgBIEv60DJAzu = oBE51eI2pTUnxl(text,ohpwd6UumaecE3IWV8lAv0)
	elif mode==417: bPFto2wZdNYrClgBIEv60DJAzu = T3CZuj9awoQMp(url,ohpwd6UumaecE3IWV8lAv0)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الرئيسية',nbOFVEDkpT4BIR7Qq82yPmHeJU,414)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن فيديوهات',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'videos?sortBy=','_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن آخر الفيديوهات',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'videos?sortBy=RECENT','_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن الفيديوهات الأكثر مشاهدة',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'videos?sortBy=VIEW_COUNT','_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن قوائم التشغيل',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'playlists','_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن مستخدم',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'channels','_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن بث حي',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'lives','_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن هاشتاك',nbOFVEDkpT4BIR7Qq82yPmHeJU,409,nbOFVEDkpT4BIR7Qq82yPmHeJU,'hashtags','_REMEMBERRESULTS_')
	return
def GJlbUVLomsCYR2X1OFrA0i9g74ED(url,V9vYM03qRyjcN5XIFDd2x4uUZgAlT):
	if '/dm_' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DAILYMOTION-CHANNELS_SUBMENU-1st',False,False)
		headers = cnPhVmgFxA.headers
		if 'Location' in list(headers.keys()): url = zKREXyTHfVSNL8ZFYs+headers['Location']
	V9vYM03qRyjcN5XIFDd2x4uUZgAlT = eMypvI8XqHjYU02anWD9gsSrkt+V9vYM03qRyjcN5XIFDd2x4uUZgAlT+c7gxFyUCGm
	V9vYM03qRyjcN5XIFDd2x4uUZgAlT = PRreVJ17DvKGaxSO(V9vYM03qRyjcN5XIFDd2x4uUZgAlT)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: بث حي',url,411,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'channel_lives_now')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: آخر الفيديوهات',url+'/videos',408)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: الأكثر مشاهدة',url+'/videos?sort=visited',408)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: المميزة',url,411,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'channel_featured_videos')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: قوائم التشغيل',url+'/playlists',407)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: قوائم التشغيل أبجدية',url+'/playlists?sort=alphaaz',407)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: قنوات ذات صلة',url,411,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'channel_related_channel')
	return
def PRreVJ17DvKGaxSO(title):
	title = title.rstrip('\\').strip(S3X6GcaiExOPtb).replace('\\\\','\\')
	title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
	return title
def AOk1T6KwciHrWU2MYJzZnEN(url,G7GhXQ9sRNCw6OnpymLMFcI1ZkU):
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY([url],QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def Epr5BwC3u8ltKAcQnzRISd97L2k(search,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	if 'sortBy=' in search: sort = search.split('sortBy=')[1].split('&')[0]
	else: sort = nbOFVEDkpT4BIR7Qq82yPmHeJU
	search = search.split('/videos')[0]
	s0tfc7T2hwBM = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeVideos":true,"page":mypagenumber,"limit":mypagelimitmysortmethod},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysearchwords',search)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	if sort==nbOFVEDkpT4BIR7Qq82yPmHeJU: s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysortmethod',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	else: s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysortmethod',',"sortByVideos":"'+sort+'"')
	url = zKREXyTHfVSNL8ZFYs+'/search/'+search+'/videos'
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"videos"(.*?)"VideoConnection"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"node".*?"xid":"(.*?)","title":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,title,qHBkjxS9tFdGDQY2lep,V9vYM03qRyjcN5XIFDd2x4uUZgAlT,H07WdckxAoZF1fn4LNMOTP65eEtr,X79kphTKa1xLP in items:
			if '"' in id: id = id.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in title: title = title.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in qHBkjxS9tFdGDQY2lep: qHBkjxS9tFdGDQY2lep = qHBkjxS9tFdGDQY2lep.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in V9vYM03qRyjcN5XIFDd2x4uUZgAlT: V9vYM03qRyjcN5XIFDd2x4uUZgAlT = V9vYM03qRyjcN5XIFDd2x4uUZgAlT.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+id
			title = PRreVJ17DvKGaxSO(title)
			G7GhXQ9sRNCw6OnpymLMFcI1ZkU = qHBkjxS9tFdGDQY2lep+'::'+V9vYM03qRyjcN5XIFDd2x4uUZgAlT
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
		if '"hasNextPage":true' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,404,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,search)
	return
def M6VsaDJK9h48HkBN0gwtT1dbuX(search,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	s0tfc7T2hwBM = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":true,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysearchwords',search)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	url = zKREXyTHfVSNL8ZFYs+'/search/'+search+'/playlists'
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)".*?"total":(.*?),',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for id,name,ff2vohtNyzYG93wBuMcOKIZFsV07Xq,qHBkjxS9tFdGDQY2lep,V9vYM03qRyjcN5XIFDd2x4uUZgAlT,X79kphTKa1xLP,count in items:
		if '"' in ff2vohtNyzYG93wBuMcOKIZFsV07Xq: ff2vohtNyzYG93wBuMcOKIZFsV07Xq = ff2vohtNyzYG93wBuMcOKIZFsV07Xq.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"' in qHBkjxS9tFdGDQY2lep: qHBkjxS9tFdGDQY2lep = qHBkjxS9tFdGDQY2lep.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"' in V9vYM03qRyjcN5XIFDd2x4uUZgAlT: V9vYM03qRyjcN5XIFDd2x4uUZgAlT = V9vYM03qRyjcN5XIFDd2x4uUZgAlT.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"' in id: id = id.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"' in name: name = name.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"' in X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"' in count: count = count.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/playlist/'+id
		title = 'LIST'+count+':  '+name
		title = PRreVJ17DvKGaxSO(title)
		G7GhXQ9sRNCw6OnpymLMFcI1ZkU = qHBkjxS9tFdGDQY2lep+'::'+V9vYM03qRyjcN5XIFDd2x4uUZgAlT
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,401,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
	if '"hasNextPage":true' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,405,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,search)
	return
def hhyXq2ot0AxWKe6Y(search,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	s0tfc7T2hwBM = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":true,"shouldIncludePlaylists":false,"shouldIncludeVideos":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    views {      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment VIDEO_WATCH_LATER_FRAGMENT on Video {  id  isInWatchLater  __typename}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    videos {      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(query: $query, first: $limit, page: $page, sort: $sortByVideos, durationMin: $durationMinVideos, durationMax: $durationMaxVideos, createdAfter: $createdAfterVideos) @include(if: $shouldIncludeVideos) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_WATCH_LATER_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysearchwords',search)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	url = zKREXyTHfVSNL8ZFYs+'/search/'+search+'/channels'
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"channels"(.*?)"ChannelConnection"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"node".*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbnailx240":"(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,name,X79kphTKa1xLP in items:
			if '"' in id: id = id.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in name: name = name.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+id
			title = 'USER:  '+name
			title = PRreVJ17DvKGaxSO(title)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,402,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,name)
		if '"hasNextPage":true' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,406,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,search)
	return
def qJS9BdrAOajN(j20IXLTbfyl3zs1cWgwO):
	s0tfc7T2hwBM = '''{"operationName":"HOME_QUERY","variables":{"space":"nextplore"},"query":"fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  thumbnail: coverURL(size: \\"x532\\")  coverURL: coverURL(size: \\"x532\\")  isFollowed  whitelistStatus {    id    isWhitelisted    __typename  }  __typename}query HOME_QUERY($space: String!) {  home: views {    id    neon {      id      sections(space: $space) {        edges {          node {            id            name            title            description            groupingType            type            relatedComponent {              __typename              ... on Collection {                id                xid                __typename              }              ... on Channel {                id                xid                name                displayName                logoURL(size: \\"x60\\")                __typename              }              ... on Topic {                id                __typename                ...TOPIC_BASE_FRAG              }            }            components {              edges {                node {                  __typename                  ... on Video {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    description                    duration                    __typename                  }                  ... on Live {                    id                    xid                    title                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx360: thumbnailURL(size: \\"x360\\")                    thumbnailx480: thumbnailURL(size: \\"x480\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    aspectRatio                    createdAt                    channel {                      id                      xid                      name                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      accountType                      __typename                    }                    startAt                    __typename                  }                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	yWdTJKAabtf84L1B2OsHN0oDur = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	if yWdTJKAabtf84L1B2OsHN0oDur:
		tWn0b5i4xwerjdD8PRBazQY = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
		sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = tWn0b5i4xwerjdD8PRBazQY['data']['home']['neon']['sections']['edges']
		if not j20IXLTbfyl3zs1cWgwO:
			hEqtm46fSug83xpslZOrkDKMRavN7C = []
			for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
				y149aXxcSFj67tKvQTZ3WMrA = xIRQd5OfGgyuZbjlDLoai6Y7['node']['title']
				if y149aXxcSFj67tKvQTZ3WMrA not in hEqtm46fSug83xpslZOrkDKMRavN7C: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+y149aXxcSFj67tKvQTZ3WMrA,nbOFVEDkpT4BIR7Qq82yPmHeJU,414,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,y149aXxcSFj67tKvQTZ3WMrA)
				hEqtm46fSug83xpslZOrkDKMRavN7C.append(y149aXxcSFj67tKvQTZ3WMrA)
		else:
			for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
				y149aXxcSFj67tKvQTZ3WMrA = xIRQd5OfGgyuZbjlDLoai6Y7['node']['title']
				if y149aXxcSFj67tKvQTZ3WMrA==j20IXLTbfyl3zs1cWgwO:
					FDbs4VejhLRYc3d = xIRQd5OfGgyuZbjlDLoai6Y7['node']['components']['edges']
					for ddcVk9ZG2rSE1ufy7obzh in FDbs4VejhLRYc3d:
						H07WdckxAoZF1fn4LNMOTP65eEtr = str(ddcVk9ZG2rSE1ufy7obzh['node']['duration'])
						title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(ddcVk9ZG2rSE1ufy7obzh['node']['title'])
						title = title.replace('\/','/')
						WwepmvqljKGZ5P9iB84U3Cdt = ddcVk9ZG2rSE1ufy7obzh['node']['xid']
						X79kphTKa1xLP = ddcVk9ZG2rSE1ufy7obzh['node']['thumbnailx480']
						X79kphTKa1xLP = X79kphTKa1xLP.replace('\/','/')
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+WwepmvqljKGZ5P9iB84U3Cdt
						Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr)
	return
def Wq9dTKiVHGmB(search,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	s0tfc7T2hwBM = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":false,"shouldIncludeVideos":false,"shouldIncludeLives":true,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }  ... on Live {    id    viewerEngagement {      id      favorited      __typename    }    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          xid          title          thumbnail: thumbnailURL(size: \\"x240\\")          thumbnailx60: thumbnailURL(size: \\"x60\\")          thumbnailx120: thumbnailURL(size: \\"x120\\")          thumbnailx240: thumbnailURL(size: \\"x240\\")          thumbnailx720: thumbnailURL(size: \\"x720\\")          audienceCount          aspectRatio          isOnAir          channel {            id            xid            name            displayName            accountType            __typename          }          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysearchwords',search)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	url = zKREXyTHfVSNL8ZFYs+'/search/'+search+'/lives'
	yWdTJKAabtf84L1B2OsHN0oDur = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search)
	if yWdTJKAabtf84L1B2OsHN0oDur:
		tWn0b5i4xwerjdD8PRBazQY = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
		try: sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = tWn0b5i4xwerjdD8PRBazQY['data']['search']['lives']['edges']
		except: sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = []
		for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
			name = xIRQd5OfGgyuZbjlDLoai6Y7['node']['title']
			name = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(name)
			WwepmvqljKGZ5P9iB84U3Cdt = xIRQd5OfGgyuZbjlDLoai6Y7['node']['xid']
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+WwepmvqljKGZ5P9iB84U3Cdt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'LIVE: '+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403)
		if '"hasNextPage":true' in yWdTJKAabtf84L1B2OsHN0oDur:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,415,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,search)
	return
def JVYSlEi9fb1eMGNZj7QR8kqIg(search,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	s0tfc7T2hwBM = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeTopics":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  stats {    id    views {      id      total      __typename    }    __typename  }  channel {    id    xid    name    displayName    accountType    __typename  }  duration  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  aspectRatio  __typename}fragment VIDEO_FAVORITES_FRAGMENT on Media {  __typename  ... on Video {    id    isInWatchLater    __typename  }  ... on Live {    id    isInWatchLater    __typename  }}fragment CHANNEL_BASE_FRAG on Channel {  accountType  id  xid  name  displayName  isFollowed  thumbnailx60: logoURL(size: \\"x60\\")  thumbnailx120: logoURL(size: \\"x120\\")  thumbnailx240: logoURL(size: \\"x240\\")  thumbnailx720: logoURL(size: \\"x720\\")  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  channel {    id    xid    name    displayName    accountType    __typename  }  description  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}fragment TOPIC_BASE_FRAG on Topic {  id  xid  name  videos(sort: \\"recent\\", first: 5) {    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        id        ...VIDEO_BASE_FRAGMENT        ...VIDEO_FAVORITES_FRAGMENT        __typename      }      __typename    }    __typename  }  stats {    id    videos {      id      total      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeTopics: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          ...VIDEO_FAVORITES_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    topics(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeTopics) {      metadata {        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      totalCount      edges {        node {          id          ...TOPIC_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysearchwords',search)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	url = zKREXyTHfVSNL8ZFYs+'/search/'+search+'/topics'
	yWdTJKAabtf84L1B2OsHN0oDur = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search)
	if yWdTJKAabtf84L1B2OsHN0oDur:
		tWn0b5i4xwerjdD8PRBazQY = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
		try: sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = tWn0b5i4xwerjdD8PRBazQY['data']['search']['topics']['edges']
		except: sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = []
		for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
			name = xIRQd5OfGgyuZbjlDLoai6Y7['node']['name']
			WwepmvqljKGZ5P9iB84U3Cdt = xIRQd5OfGgyuZbjlDLoai6Y7['node']['xid']
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/topic/'+WwepmvqljKGZ5P9iB84U3Cdt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'TOPIC: '+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,413)
		if '"hasNextPage":true' in yWdTJKAabtf84L1B2OsHN0oDur:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,412,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,search)
	return
def eTF10LWG73zO(url,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	WwepmvqljKGZ5P9iB84U3Cdt = url.split('/')[-1]
	s0tfc7T2hwBM = '''{"operationName":"DISCOVERY_TOPIC_MAIN_QUERY","variables":{"page":mypagenumber,"xid":"mytopicid"},"query":"fragment TOPIC_VIDEO_FRAGMENT on Video {  id  xid  title  duration  isLiked  isInWatchLater  isCreatedForKids  createdAt  isExplicit  videoHeight: height  videoWidth: width  category  channel {    id    xid    name    displayName    logoURLx25: logoURL(size: \\"x25\\")    logoURL(size: \\"x60\\")    accountType    __typename  }  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  aspectRatio  isPublished  __typename}query DISCOVERY_TOPIC_MAIN_QUERY($xid: String!, $page: Int = 1) {  topic(xid: $xid) {    id    xid    name    videos(sort: \\"recent\\", first: 30, page: $page) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...TOPIC_VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mytopicid',WwepmvqljKGZ5P9iB84U3Cdt)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	yWdTJKAabtf84L1B2OsHN0oDur = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	if yWdTJKAabtf84L1B2OsHN0oDur:
		tWn0b5i4xwerjdD8PRBazQY = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
		sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = tWn0b5i4xwerjdD8PRBazQY['data']['topic']['videos']['edges']
		for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
			H07WdckxAoZF1fn4LNMOTP65eEtr = str(xIRQd5OfGgyuZbjlDLoai6Y7['node']['duration'])
			title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(xIRQd5OfGgyuZbjlDLoai6Y7['node']['title'])
			title = title.replace('\/','/')
			WwepmvqljKGZ5P9iB84U3Cdt = xIRQd5OfGgyuZbjlDLoai6Y7['node']['xid']
			X79kphTKa1xLP = xIRQd5OfGgyuZbjlDLoai6Y7['node']['thumbnailx480']
			X79kphTKa1xLP = X79kphTKa1xLP.replace('\/','/')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+WwepmvqljKGZ5P9iB84U3Cdt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr)
		if '"hasNextPage":true' in yWdTJKAabtf84L1B2OsHN0oDur:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,413,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0)
	return
def DqLOSxl8dU57viRfAQI0ksbZJp6Wr(url,G7GhXQ9sRNCw6OnpymLMFcI1ZkU):
	id = url.split('/')[-1]
	qHBkjxS9tFdGDQY2lep,V9vYM03qRyjcN5XIFDd2x4uUZgAlT = G7GhXQ9sRNCw6OnpymLMFcI1ZkU.split('::',1)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+qHBkjxS9tFdGDQY2lep
	V9vYM03qRyjcN5XIFDd2x4uUZgAlT = PRreVJ17DvKGaxSO(V9vYM03qRyjcN5XIFDd2x4uUZgAlT)
	title = eMypvI8XqHjYU02anWD9gsSrkt+'OWNER:  '+V9vYM03qRyjcN5XIFDd2x4uUZgAlT+c7gxFyUCGm
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,402,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,V9vYM03qRyjcN5XIFDd2x4uUZgAlT)
	s0tfc7T2hwBM = '''{"operationName":"DISCOVERY_QUEUE_QUERY","variables":{"collectionXid":"myplaylistid","videoXid":"x7s7qbn"},"query":"query DISCOVERY_QUEUE_QUERY($videoXid: String!, $collectionXid: String, $device: String, $videoCountPerSection: Int) {  views {    id    neon {      id      sections(device: $device, space: \\"watching\\", followingChannelXids: [], followingTopicXids: [], watchedVideoXids: [], context: {mediaXid: $videoXid, collectionXid: $collectionXid}, first: 20) {        edges {          node {            id            name            groupingType            relatedComponent {              ... on Channel {                __typename                id                xid                name                displayName                logoURL(size: \\"x60\\")                logoURLx25: logoURL(size: \\"x25\\")              }              ... on Topic {                __typename                id                xid                name                names {                  edges {                    node {                      id                      name                      language {                        id                        codeAlpha2                        __typename                      }                      __typename                    }                    __typename                  }                  __typename                }              }              ... on Collection {                __typename                id                xid                name              }              __typename            }            components(first: $videoCountPerSection) {              metadata {                algorithm {                  name                  version                  uuid                  __typename                }                __typename              }              edges {                node {                  ... on Video {                    __typename                    id                    xid                    title                    duration                    thumbnailx60: thumbnailURL(size: \\"x60\\")                    thumbnailx120: thumbnailURL(size: \\"x120\\")                    thumbnailx240: thumbnailURL(size: \\"x240\\")                    thumbnailx720: thumbnailURL(size: \\"x720\\")                    channel {                      id                      xid                      accountType                      displayName                      logoURLx25: logoURL(size: \\"x25\\")                      logoURL(size: \\"x60\\")                      __typename                    }                  }                  ... on Channel {                    __typename                    id                    xid                    name                    displayName                    accountType                    logoURL(size: \\"x60\\")                  }                  __typename                }                __typename              }              __typename            }            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('myplaylistid',id)
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"collection_videos"(.*?)"SectionEdge"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"thumbnailx240":"(.*?)".*?"xid":"(.*?)".*?"displayName":"(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,title,H07WdckxAoZF1fn4LNMOTP65eEtr,X79kphTKa1xLP,qHBkjxS9tFdGDQY2lep,V9vYM03qRyjcN5XIFDd2x4uUZgAlT in items:
			if '"' in id: id = id.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in title: title = title.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in qHBkjxS9tFdGDQY2lep: qHBkjxS9tFdGDQY2lep = qHBkjxS9tFdGDQY2lep.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in V9vYM03qRyjcN5XIFDd2x4uUZgAlT: V9vYM03qRyjcN5XIFDd2x4uUZgAlT = V9vYM03qRyjcN5XIFDd2x4uUZgAlT.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+id
			title = PRreVJ17DvKGaxSO(title)
			G7GhXQ9sRNCw6OnpymLMFcI1ZkU = qHBkjxS9tFdGDQY2lep+'::'+V9vYM03qRyjcN5XIFDd2x4uUZgAlT
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
	return
def cL5jwN4AvIP2bG3(url,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	vLrxHDuiN08ba5pRlmUtMAIyfZX = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	s0tfc7T2hwBM = '''{"operationName":"CHANNEL_VIDEOS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbURLx240: thumbnailURL(size: \\"x240\\")  thumbURLx360: thumbnailURL(size: \\"x360\\")  thumbURLx480: thumbnailURL(size: \\"x480\\")  thumbURLx720: thumbnailURL(size: \\"x720\\")  __typename}query CHANNEL_VIDEOS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_videos_all_videos: videos(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mychannelid',vLrxHDuiN08ba5pRlmUtMAIyfZX)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysortmethod',sort)
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"channel_videos_all_videos"(.*?)"VideoConnection"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"node".*?"xid":"(.*?)".*?"title":"(.*?)".*?"duration":(.*?),.*?"name":"(.*?)".*?"displayName":"(.*?)".*?"thumbURLx240":"(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,title,H07WdckxAoZF1fn4LNMOTP65eEtr,qHBkjxS9tFdGDQY2lep,V9vYM03qRyjcN5XIFDd2x4uUZgAlT,X79kphTKa1xLP in items:
			if '"' in id: id = id.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in title: title = title.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in qHBkjxS9tFdGDQY2lep: qHBkjxS9tFdGDQY2lep = qHBkjxS9tFdGDQY2lep.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in V9vYM03qRyjcN5XIFDd2x4uUZgAlT: V9vYM03qRyjcN5XIFDd2x4uUZgAlT = V9vYM03qRyjcN5XIFDd2x4uUZgAlT.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+id
			title = PRreVJ17DvKGaxSO(title)
			G7GhXQ9sRNCw6OnpymLMFcI1ZkU = qHBkjxS9tFdGDQY2lep+'::'+V9vYM03qRyjcN5XIFDd2x4uUZgAlT
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
		if '"hasNextPage":true' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,408,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0)
	return
def vcz5iqLYCEK7bgpretf2O(url,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	vLrxHDuiN08ba5pRlmUtMAIyfZX = url.split('/')[-2]
	if 'sort=' in url: sort = url.split('sort=')[1].split('&')[0]
	else: sort = 'recent'
	s0tfc7T2hwBM = '''{"operationName":"CHANNEL_COLLECTIONS_QUERY","variables":{"channel_xid":"mychannelid","sort":"mysortmethod","page":mypagenumber},"query":"fragment CHANNEL_BASE_FRAGMENT on Channel {  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  isFollowed  accountType  __typename}fragment CHANNEL_IMAGES_FRAGMENT on Channel {  id  coverURLx375: coverURL(size: \\"x375\\")  __typename}fragment CHANNEL_UPDATED_FRAGMENT on Channel {  id  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}fragment CHANNEL_COMPLETE_FRAGMENT on Channel {  id  ...CHANNEL_BASE_FRAGMENT  ...CHANNEL_IMAGES_FRAGMENT  ...CHANNEL_UPDATED_FRAGMENT  description  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  externalLinks {    facebookURL    twitterURL    websiteURL    instagramURL    __typename  }  __typename}fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    views {      total      __typename    }    followers {      total      __typename    }    videos {      total      __typename    }    __typename  }  __typename}query CHANNEL_COLLECTIONS_QUERY($channel_xid: String!, $sort: String, $page: Int!) {  channel(xid: $channel_xid) {    id    ...CHANNEL_COMPLETE_FRAGMENT    channel_playlist_collections: collections(sort: $sort, page: $page, first: mypagelimit) {      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          xid          updatedAt          name          description          thumbURLx240: thumbnailURL(size: \\"x240\\")          thumbURLx360: thumbnailURL(size: \\"x360\\")          thumbURLx480: thumbnailURL(size: \\"x480\\")          stats {            videos {              total              __typename            }            __typename          }          channel {            id            ...CHANNEL_FRAGMENT            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mychannelid',vLrxHDuiN08ba5pRlmUtMAIyfZX)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysortmethod',sort)
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"channel_playlist_collections"(.*?)"CollectionConnection"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"node".*?"xid":"(.*?)".*?"name":"(.*?)".*?"thumbURLx240":"(.*?)".*?"total":(.*?),.*?"xid":"(.*?)".*?"name":"(.*?)".*?"displayName":"(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,name,X79kphTKa1xLP,count,ff2vohtNyzYG93wBuMcOKIZFsV07Xq,qHBkjxS9tFdGDQY2lep,V9vYM03qRyjcN5XIFDd2x4uUZgAlT in items:
			if '"' in id: id = id.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in name: name = name.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in count: count = count.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in ff2vohtNyzYG93wBuMcOKIZFsV07Xq: ff2vohtNyzYG93wBuMcOKIZFsV07Xq = ff2vohtNyzYG93wBuMcOKIZFsV07Xq.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in qHBkjxS9tFdGDQY2lep: qHBkjxS9tFdGDQY2lep = qHBkjxS9tFdGDQY2lep.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '"' in V9vYM03qRyjcN5XIFDd2x4uUZgAlT: V9vYM03qRyjcN5XIFDd2x4uUZgAlT = V9vYM03qRyjcN5XIFDd2x4uUZgAlT.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/playlist/'+id
			title = 'LIST'+count+':  '+name
			title = PRreVJ17DvKGaxSO(title)
			G7GhXQ9sRNCw6OnpymLMFcI1ZkU = qHBkjxS9tFdGDQY2lep+'::'+V9vYM03qRyjcN5XIFDd2x4uUZgAlT
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,401,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
		if '"hasNextPage":true' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,407,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0)
	return
def snm6EQPzui54Dw(url,VOM7XeYjvFa):
	vLrxHDuiN08ba5pRlmUtMAIyfZX = url.split('/')[3]
	s0tfc7T2hwBM = '''{"operationName":"CHANNEL_QUERY_DESKTOP","variables":{"channel_name":"mychannelid","relatedChannels":100},"query":"fragment CHANNEL_FRAGMENT on Channel {  accountType  id  xid  name  displayName  isArtist  logoURL(size: \\"x60\\")  coverURLx375: coverURL(size: \\"x375\\")  isFollowed  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  __typename}fragment LIVE_FRAGMENT on Live {  id  xid  title  startAt  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  __typename}fragment VIDEO_FRAGMENT on Video {  id  xid  title  viewCount  duration  createdAt  isInWatchLater  channel {    id    ...CHANNEL_FRAGMENT    __typename  }  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  __typename}fragment CHANNEL_MAIN_FRAGMENT on Channel {  id  xid  name  displayName  description  accountType  isArtist  logoURL(size: \\"x60\\")  coverURL1024x: coverURL(size: \\"1024x\\")  coverURL1920x: coverURL(size: \\"1920x\\")  isFollowed  tagline  country {    id    codeAlpha2    __typename  }  stats {    id    views {      id      total      __typename    }    followers {      id      total      __typename    }    videos {      id      total      __typename    }    __typename  }  externalLinks {    id    facebookURL    twitterURL    websiteURL    instagramURL    pinterestURL    __typename  }  channel_lives_now: lives(first: 4, isOnAir: true) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_lives_scheduled: lives(first: 4, startIn: 7200) {    edges {      node {        id        ...LIVE_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_featured_videos: videos(first: 4, isFeatured: true) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_all_videos: videos(first: 4) {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_most_viewed: videos(first: 4, sort: \\"visited\\") {    edges {      node {        id        ...VIDEO_FRAGMENT        __typename      }      __typename    }    __typename  }  channel_collections: collections(first: 4) {    edges {      node {        id        xid        name        description        stats {          id          videos {            id            total            __typename          }          __typename        }        thumbnailx240: thumbnailURL(size: \\"x240\\")        thumbnailx360: thumbnailURL(size: \\"x360\\")        thumbnailx480: thumbnailURL(size: \\"x480\\")        channel {          id          ...CHANNEL_FRAGMENT          __typename        }        __typename      }      __typename    }    __typename  }  channel_related_channel: networkChannels(    hasPublicVideos: true    first: $relatedChannels  ) {    edges {      node {        id        ...CHANNEL_FRAGMENT        __typename      }      __typename    }    __typename  }  __typename}query CHANNEL_QUERY_DESKTOP($channel_name: String!, $relatedChannels: Int) {  channel(name: $channel_name) {    id    ...CHANNEL_MAIN_FRAGMENT    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mychannelid',vLrxHDuiN08ba5pRlmUtMAIyfZX)
	UTvsQb4HpCP3Aeo2wDZG7X5V = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	uFC7Dj5RUtE2rl1hgckHSBJdiI = eH72MR1wtfuI80myOo4ajgG.loads(UTvsQb4HpCP3Aeo2wDZG7X5V)
	try: items = uFC7Dj5RUtE2rl1hgckHSBJdiI['data']['channel'][VOM7XeYjvFa]['edges']
	except: items = []
	if not items: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'لا توجد نتائج',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	else:
		for xB2lOZNsPvFQDC4gMz in items:
			PhJ4w3ZRzsb8FLneOfQSW2kN7u = xB2lOZNsPvFQDC4gMz['node']
			WwepmvqljKGZ5P9iB84U3Cdt = PhJ4w3ZRzsb8FLneOfQSW2kN7u['xid']
			keys = list(PhJ4w3ZRzsb8FLneOfQSW2kN7u.keys())
			jqFxQd0W7L = PhJ4w3ZRzsb8FLneOfQSW2kN7u['__typename'].lower()
			if jqFxQd0W7L=='channel':
				name = PhJ4w3ZRzsb8FLneOfQSW2kN7u['name']
				K2uJ4gEF9j8IPGa0rHeSNb = PhJ4w3ZRzsb8FLneOfQSW2kN7u['displayName']
				title = 'USER:  '+K2uJ4gEF9j8IPGa0rHeSNb
				X79kphTKa1xLP = PhJ4w3ZRzsb8FLneOfQSW2kN7u['coverURLx375']
			else:
				name = PhJ4w3ZRzsb8FLneOfQSW2kN7u['channel']['name']
				K2uJ4gEF9j8IPGa0rHeSNb = PhJ4w3ZRzsb8FLneOfQSW2kN7u['channel']['displayName']
				title = PhJ4w3ZRzsb8FLneOfQSW2kN7u['title']
				X79kphTKa1xLP = PhJ4w3ZRzsb8FLneOfQSW2kN7u['thumbnailx360']
				if jqFxQd0W7L=='live': title = 'LIVE:  '+title
			title = PRreVJ17DvKGaxSO(title)
			G7GhXQ9sRNCw6OnpymLMFcI1ZkU = name+'::'+K2uJ4gEF9j8IPGa0rHeSNb
			if n7neb9KTv10FcU:
				title = title.encode(zSafwK0sDXdMN5JReniIQmrZxp)
				G7GhXQ9sRNCw6OnpymLMFcI1ZkU = G7GhXQ9sRNCw6OnpymLMFcI1ZkU.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			if jqFxQd0W7L=='channel':
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+WwepmvqljKGZ5P9iB84U3Cdt
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,402,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
			else:
				if jqFxQd0W7L=='video': H07WdckxAoZF1fn4LNMOTP65eEtr = str(PhJ4w3ZRzsb8FLneOfQSW2kN7u['duration'])
				else: H07WdckxAoZF1fn4LNMOTP65eEtr = nbOFVEDkpT4BIR7Qq82yPmHeJU
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+WwepmvqljKGZ5P9iB84U3Cdt
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj(jqFxQd0W7L,TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr,G7GhXQ9sRNCw6OnpymLMFcI1ZkU)
	return
def oBE51eI2pTUnxl(search,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	s0tfc7T2hwBM = '''{"operationName":"SEARCH_QUERY","variables":{"query":"mysearchwords","shouldIncludeChannels":false,"shouldIncludePlaylists":false,"shouldIncludeHashtags":true,"shouldIncludeVideos":false,"shouldIncludeLives":false,"page":mypagenumber,"limit":mypagelimit},"query":"fragment VIDEO_BASE_FRAGMENT on Video {  id  xid  title  createdAt  duration  aspectRatio  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  accountType  isFollowed  avatar(height: SQUARE_120) {    id    url    __typename  }  followerEngagement {    id    followDate    __typename  }  metrics {    id    engagement {      id      followers {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment PLAYLIST_BASE_FRAG on Collection {  id  xid  name  description  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  metrics {    id    engagement {      id      videos(filter: {visibility: {eq: PUBLIC}}) {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment HASHTAG_BASE_FRAG on Hashtag {  id  xid  name  metrics {    id    engagement {      id      videos {        edges {          node {            id            total            __typename          }          __typename        }        __typename      }      __typename    }    __typename  }  __typename}fragment LIVE_BASE_FRAGMENT on Live {  id  xid  title  audienceCount  aspectRatio  isOnAir  thumbnail(height: PORTRAIT_240) {    id    url    __typename  }  creator {    id    xid    name    displayName    accountType    avatar(height: SQUARE_60) {      id      url      __typename    }    __typename  }  __typename}query SEARCH_QUERY($query: String!, $shouldIncludeVideos: Boolean!, $shouldIncludeChannels: Boolean!, $shouldIncludePlaylists: Boolean!, $shouldIncludeHashtags: Boolean!, $shouldIncludeLives: Boolean!, $page: Int, $limit: Int, $sortByVideos: SearchVideoSort, $durationMinVideos: Int, $durationMaxVideos: Int, $createdAfterVideos: DateTime) {  search {    id    videos(      query: $query      first: $limit      page: $page      sort: $sortByVideos      durationMin: $durationMinVideos      durationMax: $durationMaxVideos      createdAfter: $createdAfterVideos    ) @include(if: $shouldIncludeVideos) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...VIDEO_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    lives(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeLives) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...LIVE_BASE_FRAGMENT          __typename        }        __typename      }      __typename    }    channels(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeChannels) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...CHANNEL_BASE_FRAG          __typename        }        __typename      }      __typename    }    playlists: collections(query: $query, first: $limit, page: $page) @include(if: $shouldIncludePlaylists) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...PLAYLIST_BASE_FRAG          __typename        }        __typename      }      __typename    }    hashtags(query: $query, first: $limit, page: $page) @include(if: $shouldIncludeHashtags) {      metadata {        id        algorithm {          uuid          __typename        }        __typename      }      pageInfo {        hasNextPage        nextPage        __typename      }      edges {        node {          id          ...HASHTAG_BASE_FRAG          __typename        }        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mysearchwords',search)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagelimit','40')
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	url = zKREXyTHfVSNL8ZFYs+'/search/'+search+'/hashtags'
	yWdTJKAabtf84L1B2OsHN0oDur = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search)
	if yWdTJKAabtf84L1B2OsHN0oDur:
		tWn0b5i4xwerjdD8PRBazQY = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
		try: sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = tWn0b5i4xwerjdD8PRBazQY['data']['search']['hashtags']['edges']
		except: sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = []
		for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
			name = xIRQd5OfGgyuZbjlDLoai6Y7['node']['name']
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/hashtag/'+name[1:]
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'HSHTG: '+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,417)
		if '"hasNextPage":true' in yWdTJKAabtf84L1B2OsHN0oDur:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,416,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,search)
	return
def T3CZuj9awoQMp(url,ohpwd6UumaecE3IWV8lAv0=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	name = url.split('/')[-1]
	s0tfc7T2hwBM = '''{"operationName":"HASHTAG_VIDEOS_QUERY","variables":{"hashtag_name":"#myhashtagname","page":mypagenumber},"query":"fragment FRAG_VIDEO_BASE on Video {  id  xid  title  description  thumbnail: thumbnailURL(size: \\"x240\\")  thumbnailx60: thumbnailURL(size: \\"x60\\")  thumbnailx120: thumbnailURL(size: \\"x120\\")  thumbnailx240: thumbnailURL(size: \\"x240\\")  thumbnailx360: thumbnailURL(size: \\"x360\\")  thumbnailx480: thumbnailURL(size: \\"x480\\")  thumbnailx720: thumbnailURL(size: \\"x720\\")  bestAvailableQuality  duration  createdAt  viewerEngagement {    id    liked    favorited    __typename  }  isExplicit  canDisplayAds  aspectRatio  stats {    id    views {      id      total      __typename    }    __typename  }  language {    id    codeAlpha2    __typename  }  videoHeight: height  videoWidth: width  __typename}fragment CHANNEL_BASE_FRAG on Channel {  id  xid  name  displayName  description  logoURL(size: \\"x25\\")  logoURLx60: logoURL(size: \\"x60\\")  coverURL(size: \\"x200\\")  coverURLx1024: coverURL(size: \\"1024x\\")  isFollowed  isArtist  accountType  __typename}fragment VIDEO_FRAG on Video {  id  ...FRAG_VIDEO_BASE  channel {    id    ...CHANNEL_BASE_FRAG    __typename  }  __typename}query HASHTAG_VIDEOS_QUERY($hashtag_name: String!, $page: Int!) {  contentFeed(    name: HASHTAG    filter: {name: {eq: $hashtag_name}, post: {eq: VIDEO}}    sort: {create: DESC}    page: $page    first: 30  ) {    totalCount    pageInfo {      hasNextPage      nextPage      __typename    }    edges {      node {        post {          ...VIDEO_FRAG          __typename        }        featured        __typename      }      __typename    }    __typename  }}"}'''
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('myhashtagname',name)
	s0tfc7T2hwBM = s0tfc7T2hwBM.replace('mypagenumber',ohpwd6UumaecE3IWV8lAv0)
	yWdTJKAabtf84L1B2OsHN0oDur = p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM)
	if yWdTJKAabtf84L1B2OsHN0oDur:
		tWn0b5i4xwerjdD8PRBazQY = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
		sj3KxTr5fGPpwdRbAo1EaBD0C2qQM = tWn0b5i4xwerjdD8PRBazQY['data']['contentFeed']['edges']
		for xIRQd5OfGgyuZbjlDLoai6Y7 in sj3KxTr5fGPpwdRbAo1EaBD0C2qQM:
			H07WdckxAoZF1fn4LNMOTP65eEtr = str(xIRQd5OfGgyuZbjlDLoai6Y7['node']['post']['duration'])
			title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(xIRQd5OfGgyuZbjlDLoai6Y7['node']['post']['title'])
			title = title.replace('\/','/')
			WwepmvqljKGZ5P9iB84U3Cdt = xIRQd5OfGgyuZbjlDLoai6Y7['node']['post']['xid']
			X79kphTKa1xLP = xIRQd5OfGgyuZbjlDLoai6Y7['node']['post']['thumbnailx480']
			X79kphTKa1xLP = X79kphTKa1xLP.replace('\/','/')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video/'+WwepmvqljKGZ5P9iB84U3Cdt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,403,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr)
		if '"hasNextPage":true' in yWdTJKAabtf84L1B2OsHN0oDur:
			ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)+1)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+ohpwd6UumaecE3IWV8lAv0,url,416,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0)
	return
def p5t2v4gyGYH1WDULAbjSQ(s0tfc7T2hwBM,search=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	s0tfc7T2hwBM = s0tfc7T2hwBM.encode('utf-8')
	epnsk7biWOlcqfaL3mxTRMFAC = Iv2BjtqSucM0()
	headers = {"Authorization":epnsk7biWOlcqfaL3mxTRMFAC,"Origin":zKREXyTHfVSNL8ZFYs,'Content-Type':'text/plain; charset=utf-8'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',C07t1e38mH2LEMzny4vX9riOblaBF,s0tfc7T2hwBM,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DAILYMOTION-GET_PAGEDATA-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Iv2BjtqSucM0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DAILYMOTION-GET_AUTHINTICATION-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Aym6UiQ1I0GJctvoXxjhMVYz = ScntgdOZCY74vNpXeW5jh8i.findall('var r="(.*?)",o="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	XQFqwd4GBzKLo0nVj,KwBEPW1m5QAl = Aym6UiQ1I0GJctvoXxjhMVYz[-1]
	QLG9IKbpCt = 'https://graphql.api.dailymotion.com/oauth/token'
	ZLTAqcHg4nEMh9edbUFxR37 = 'client_credentials'
	data = {'client_id':XQFqwd4GBzKLo0nVj,'client_secret':KwBEPW1m5QAl,'grant_type':ZLTAqcHg4nEMh9edbUFxR37}
	headers = {'Content-Type':'application/x-www-form-urlencoded'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',QLG9IKbpCt,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'DAILYMOTION-GET_AUTHINTICATION-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Aym6UiQ1I0GJctvoXxjhMVYz = ScntgdOZCY74vNpXeW5jh8i.findall('"access_token": *"(.*?)".*?"token_type": *"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	hhmp28LByfuS7R4D0btP,qc1B9YviUnHobmkGrp2WJC5TzuVsa = Aym6UiQ1I0GJctvoXxjhMVYz[0]
	epnsk7biWOlcqfaL3mxTRMFAC = qc1B9YviUnHobmkGrp2WJC5TzuVsa+" "+hhmp28LByfuS7R4D0btP
	return epnsk7biWOlcqfaL3mxTRMFAC
def cvZoNw4F0fRjYaMuP5CVrE(search,nFE7RXAdxPUaktfcCDwZGsQhMzybmY=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not nFE7RXAdxPUaktfcCDwZGsQhMzybmY and showDialogs:
		BumehUF8wN76Y4oc1pqyXKEkabW = ['بحث عن فيديوهات','بحث عن آخر الفيديوهات','بحث عن الفيديوهات الاكثر مشاهدة','(جيد للمسلسلات) بحث عن قوائم تشغيل','بحث عن مستخدم','بحث عن بث حي','بحث عن هاشتاك']
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('موقع ديلي موشن - اختر البحث',BumehUF8wN76Y4oc1pqyXKEkabW)
		if bCiGxXzDkH==-1: return
		elif bCiGxXzDkH==0: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'videos?sortBy='
		elif bCiGxXzDkH==1: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'videos?sortBy=RECENT'
		elif bCiGxXzDkH==2: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'videos?sortBy=VIEW_COUNT'
		elif bCiGxXzDkH==3: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'playlists'
		elif bCiGxXzDkH==4: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'channels'
		elif bCiGxXzDkH==5: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'lives'
		elif bCiGxXzDkH==6: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'hashtags'
	elif '_DAILYMOTION-VIDEOS_' in YE1hqa60dGTRDZ8NVBM: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'videos?sortBy='
	elif '_DAILYMOTION-PLAYLISTS_' in YE1hqa60dGTRDZ8NVBM: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'playlists'
	elif '_DAILYMOTION-CHANNELS_' in YE1hqa60dGTRDZ8NVBM: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'channels'
	elif '_DAILYMOTION-LIVES_' in YE1hqa60dGTRDZ8NVBM: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'lives'
	elif '_DAILYMOTION-HASHTAGS_' in YE1hqa60dGTRDZ8NVBM: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'hashtags'
	else: nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'videos?sortBy='
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	if 'videos' in nFE7RXAdxPUaktfcCDwZGsQhMzybmY: Epr5BwC3u8ltKAcQnzRISd97L2k(search+'/'+nFE7RXAdxPUaktfcCDwZGsQhMzybmY)
	elif 'playlists' in nFE7RXAdxPUaktfcCDwZGsQhMzybmY: M6VsaDJK9h48HkBN0gwtT1dbuX(search)
	elif 'channels' in nFE7RXAdxPUaktfcCDwZGsQhMzybmY: hhyXq2ot0AxWKe6Y(search)
	elif 'lives' in nFE7RXAdxPUaktfcCDwZGsQhMzybmY: Wq9dTKiVHGmB(search)
	elif 'hashtags' in nFE7RXAdxPUaktfcCDwZGsQhMzybmY: oBE51eI2pTUnxl(search)
	return
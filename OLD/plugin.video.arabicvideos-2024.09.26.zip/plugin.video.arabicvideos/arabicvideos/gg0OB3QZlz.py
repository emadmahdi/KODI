﻿# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
def n1zxUlcAgR(EYMmnJAyxV,TsDyRu5M9qgtENl):
	if TsDyRu5M9qgtENl==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	if EYMmnJAyxV==1:
		TTUapq4hf7PzyFjG93YC8EMlXvL = LAkCFq8ezcf.getCurrentWindowDialogId()
		T4Zo8zCmjqNpxO5bcLwdvSn = LAkCFq8ezcf.Window(TTUapq4hf7PzyFjG93YC8EMlXvL)
		TsDyRu5M9qgtENl = ufPy6eA5zURb7lGLK10hc(TsDyRu5M9qgtENl)
		T4Zo8zCmjqNpxO5bcLwdvSn.getControl(311).setLabel(TsDyRu5M9qgtENl)
	if EYMmnJAyxV==0:
		vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG='X'
		if IZhXMprxvAHqBEFkg0: J9Ki8WMxL5zZNT1 = isinstance(TsDyRu5M9qgtENl,str)
		else: J9Ki8WMxL5zZNT1 = isinstance(TsDyRu5M9qgtENl,unicode)
		if J9Ki8WMxL5zZNT1==True: vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG='U'
		SDwcGes1piyg0u=str(type(TsDyRu5M9qgtENl))+S3X6GcaiExOPtb+TsDyRu5M9qgtENl+S3X6GcaiExOPtb+vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG+S3X6GcaiExOPtb
		for WoEZvMXa0K2suwgPl in range(0,len(TsDyRu5M9qgtENl),1):
			SDwcGes1piyg0u += hex(ord(TsDyRu5M9qgtENl[WoEZvMXa0K2suwgPl])).replace('0x',nbOFVEDkpT4BIR7Qq82yPmHeJU)+S3X6GcaiExOPtb
		TsDyRu5M9qgtENl = ufPy6eA5zURb7lGLK10hc(TsDyRu5M9qgtENl)
		vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG='X'
		if IZhXMprxvAHqBEFkg0: J9Ki8WMxL5zZNT1 = isinstance(TsDyRu5M9qgtENl, str)
		else: J9Ki8WMxL5zZNT1 = isinstance(TsDyRu5M9qgtENl, unicode)
		if J9Ki8WMxL5zZNT1==True: vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG='U'
		odCbPAS3kWpuUl5H0IDLq=str(type(TsDyRu5M9qgtENl))+S3X6GcaiExOPtb+TsDyRu5M9qgtENl+S3X6GcaiExOPtb+vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG+S3X6GcaiExOPtb
		for WoEZvMXa0K2suwgPl in range(0,len(TsDyRu5M9qgtENl),1):
			odCbPAS3kWpuUl5H0IDLq += hex(ord(TsDyRu5M9qgtENl[WoEZvMXa0K2suwgPl])).replace('0x',nbOFVEDkpT4BIR7Qq82yPmHeJU)+S3X6GcaiExOPtb
	return
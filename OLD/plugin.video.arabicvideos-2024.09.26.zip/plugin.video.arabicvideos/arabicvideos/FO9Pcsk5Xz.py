# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'BOKRA'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_BKR_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
CZrI4vYju7a = ['افلام للكبار','بكرا TV']
def n1zxUlcAgR(mode,url,text):
	if   mode==370: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==371: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==372: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==374: bPFto2wZdNYrClgBIEv60DJAzu = L2XnMkJpPT7ZBU5146YS3mtARqVEcx(url)
	elif mode==375: bPFto2wZdNYrClgBIEv60DJAzu = iCSuwFLehpB02(url)
	elif mode==376: bPFto2wZdNYrClgBIEv60DJAzu = qY5UPZxmp3iQ0t4M8WR(0,url)
	elif mode==377: bPFto2wZdNYrClgBIEv60DJAzu = qY5UPZxmp3iQ0t4M8WR(1,url)
	elif mode==379: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-MENU-1st')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,379,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قنوات تلفزيونية',zKREXyTHfVSNL8ZFYs+'/al_1103560_1',371)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('right-side(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',zKREXyTHfVSNL8ZFYs,375)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الأحدث',zKREXyTHfVSNL8ZFYs,376)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قائمة الممثلين',zKREXyTHfVSNL8ZFYs,374)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="container"(.*?)top-menu',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items[7:]:
			title = title.strip(S3X6GcaiExOPtb)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items[0:7]:
			title = title.strip(S3X6GcaiExOPtb)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371)
	return
def L2XnMkJpPT7ZBU5146YS3mtARqVEcx(website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-ACTORSMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="row cat Tags"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)" title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if 'http' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
			else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371)
	return
def iCSuwFLehpB02(website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-FEATURED-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"MainContent"(.*?)main-title2',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(/vidpage_.*?)".*? src="(.*?)".*?<h3>(.*?)</h3>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
				X79kphTKa1xLP = X79kphTKa1xLP.replace('://',':///').replace('//','/').replace(S3X6GcaiExOPtb,'%20')
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,372,X79kphTKa1xLP)
	return
def qY5UPZxmp3iQ0t4M8WR(id,website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-WATCHINGNOW-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-title2(.*?)class="row',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[id]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*? src="(.*?)".*?<h4>(.*?)</h4>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
				X79kphTKa1xLP = X79kphTKa1xLP.replace('://',':///').replace('//','/').replace(S3X6GcaiExOPtb,'%20')
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,372,X79kphTKa1xLP)
	return
def IGDobAKtj4kPF5V(url,gg8S4FihUQy0V26=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if 'vidpage_' in url:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('href="(/Album-.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
			IGDobAKtj4kPF5V(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			return
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class=" subcats"(.*?)class="col-md-3',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if gg8S4FihUQy0V26==nbOFVEDkpT4BIR7Qq82yPmHeJU and eXpgPIbRv2ZMGwjm5 and eXpgPIbRv2ZMGwjm5[0].count('href')>1:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',url,371,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'titles')
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)" title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			title = title.strip(S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371)
	else:
		tWsVFQj47pw0L56rZfg = []
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="col-md-3(.*?)col-xs-12',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="col-sm-8"(.*?)col-xs-12',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?<h4>(.*?)</h4>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				title = title.strip(S3X6GcaiExOPtb)
				X79kphTKa1xLP = X79kphTKa1xLP.replace('://',':///').replace('//','/').replace(S3X6GcaiExOPtb,'%20')
				if '/al_' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371,X79kphTKa1xLP)
				elif 'الحلقة' in title and ('/Cat-' in url or '/Search/' in url):
					BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) - +الحلقة +\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if BBuqr7CwzEIi9UL54n0AVoHXPlp: title = '_MOD_مسلسل '+BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
					if title not in tWsVFQj47pw0L56rZfg:
						tWsVFQj47pw0L56rZfg.append(title)
						Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371,X79kphTKa1xLP)
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,372,X79kphTKa1xLP)
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('class="".*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				title = 'صفحة '+dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,371,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'titles')
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('label-success mrg-btm-5 ">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	zb2QIaL7Y4h9g8lSck = nbOFVEDkpT4BIR7Qq82yPmHeJU
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('var url = "(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm: plSscrVjkRviPwm = plSscrVjkRviPwm[0]
	else: plSscrVjkRviPwm = url.replace('/vidpage_','/Play/')
	if 'http' not in plSscrVjkRviPwm: plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+plSscrVjkRviPwm
	plSscrVjkRviPwm = plSscrVjkRviPwm.strip('-')
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'BOKRA-PLAY-2nd')
	fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
	zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if zb2QIaL7Y4h9g8lSck:
		zb2QIaL7Y4h9g8lSck = zb2QIaL7Y4h9g8lSck[-1]
		if 'http' not in zb2QIaL7Y4h9g8lSck: zb2QIaL7Y4h9g8lSck = 'http:'+zb2QIaL7Y4h9g8lSck
		if '/PLAY/' not in plSscrVjkRviPwm:
			if 'embed.min.js' in zb2QIaL7Y4h9g8lSck:
				zkRUYXG7cxw0l8pHMgv64f = ScntgdOZCY74vNpXeW5jh8i.findall('data-publisher-id="(.*?)" data-video-id="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if zkRUYXG7cxw0l8pHMgv64f:
					u0nRAFcvE5N74Cdm8q, VtwYzaD8sSKC4pjlZxmq5WQu39FLbg = zkRUYXG7cxw0l8pHMgv64f[0]
					zb2QIaL7Y4h9g8lSck = Qi32bRtN18qvyWmaO7YKow9cXs(zb2QIaL7Y4h9g8lSck,'url')+'/v2/'+u0nRAFcvE5N74Cdm8q+'/config/'+VtwYzaD8sSKC4pjlZxmq5WQu39FLbg+'.json'
		import gdVOXAx7tm
		gdVOXAx7tm.ooRpOJtyIaY([zb2QIaL7Y4h9g8lSck],QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/Search/'+search
	IGDobAKtj4kPF5V(url)
	return
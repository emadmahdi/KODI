# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
QSJFrwB3dMiyH2mTPKD9a = 'AKWAM'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_AKW_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
vlHUmnKOrQg = nbOFVEDkpT4BIR7Qq82yPmHeJU
CZrI4vYju7a = ['ألعاب','المصارعة الحرة','القران الكريم','الكتب و الابحاث','الصور و الخلفيات','المسلسلات الاذاعية']
def n1zxUlcAgR(mode,url,text):
	if   mode==240: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==241: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==242: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==243: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==244: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'FILTERS___'+text)
	elif mode==245: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'CATEGORIES___'+text)
	elif mode==246: bPFto2wZdNYrClgBIEv60DJAzu = Yb7PWFCqOfmo6LyhJ2(url)
	elif mode==247: bPFto2wZdNYrClgBIEv60DJAzu = DNBiefuXLyCYl2M1QsjGO06Ecv(url)
	elif mode==248: bPFto2wZdNYrClgBIEv60DJAzu = yRNmrPsZxHB()
	elif mode==249: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def yRNmrPsZxHB():
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذا الموقع "أكوام الجديد" في بعض الأحيان فيه نوع من الحجب ضد البرامج . وهذا يسبب مشكلة في تشغيل الفيديوهات . هذه المشكلة سببها من الموقع الأصلي وهي تظهر وتختفي بصورة عشوائية')
	return
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKWAM-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	ypFNiI9DS3M5gt = ScntgdOZCY74vNpXeW5jh8i.findall('home-site-btn-container.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if ypFNiI9DS3M5gt: ypFNiI9DS3M5gt = ypFNiI9DS3M5gt[0]
	else: ypFNiI9DS3M5gt = zKREXyTHfVSNL8ZFYs
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',ypFNiI9DS3M5gt,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKWAM-MENU-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,249,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',zKREXyTHfVSNL8ZFYs,246)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',zKREXyTHfVSNL8ZFYs,247)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',ypFNiI9DS3M5gt,241,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
	recent = ScntgdOZCY74vNpXeW5jh8i.findall('recently-container.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = recent[0]
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أضيف حديثا',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,241)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('mb-4 d-flex align-items-center.*?href="(.*?)".*?class="header-link text-white">(.*?)<.*?class="menu"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
		if name in CZrI4vYju7a: continue
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,241)
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title in CZrI4vYju7a: continue
			title = name+S3X6GcaiExOPtb+title
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,241)
	return
def Yb7PWFCqOfmo6LyhJ2(website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKWAM-MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="menu(.*?)<nav',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?text">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title not in CZrI4vYju7a:
				title = title+' مصنفة'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,245)
		if website==nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def DNBiefuXLyCYl2M1QsjGO06Ecv(website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'AKWAM-MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="menu(.*?)<nav',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?text">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title not in CZrI4vYju7a:
				title = title+' مفلترة'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,244)
		if website==nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKWAM-TITLES-1st')
	if type=='featured': eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('swiper-container(.*?)swiper-button-prev',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="widget"(.*?)main-footer',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not items:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?href="(.*?)".*?text-white">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/shows/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,242,X79kphTKa1xLP)
			elif '/movies/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,243,X79kphTKa1xLP)
			elif '/games/' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,243,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title=='&lsaquo;': title = 'سابقة'
			if title=='&rsaquo;': title = 'لاحقة'
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dCtxzeFX4GJVonm(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,241)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'%20')
	url = zKREXyTHfVSNL8ZFYs + '/search?q='+T871qPZzS4LkoMBa3Db9Q
	bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	return
def PXyn8J3WjhRgA(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKWAM-EPISODES-1st')
	if '-episodes">' not in UTvsQb4HpCP3Aeo2wDZG7X5V:
		X79kphTKa1xLP = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Icon')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'رابط التشغيل',url,243,X79kphTKa1xLP)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('-episodes">(.*?)<div class="widget-4',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		HOsekxhQY6NrK1tcGu8BvVo7CLyUIP = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)".*?>(.*?)<.*?src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in HOsekxhQY6NrK1tcGu8BvVo7CLyUIP:
			title = title.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
			if 'الحلقات' in title or 'مواسم اخرى' in title: continue
			if '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,242,X79kphTKa1xLP)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,243,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKWAM-PLAY-1st')
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('badge-danger.*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	bbLYqW1AGOld = ScntgdOZCY74vNpXeW5jh8i.findall('li><a href="#(.*?)".*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	lPpY5fw3tOBcEye91Caun2FQZ,bbKoeBcirVfzwAqZdQUFDSX,ISmqngYzv6jrepWUx0l,dBHC2nTqybSNsrkXzZ = [],[],[],[]
	if bbLYqW1AGOld:
		D63UZqx2XBgrtbje = 'mp4'
		for K3K08FEm6r7SetNJB1cW,uTKGhcXEIpmDf in bbLYqW1AGOld:
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('tab-content quality" id="'+K3K08FEm6r7SetNJB1cW+'".*?</div>.\s*</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			ISmqngYzv6jrepWUx0l.append(G4JHzTEp61)
			dBHC2nTqybSNsrkXzZ.append(uTKGhcXEIpmDf)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="qualities(.*?)<h3.*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','لا يوجد ملف فيديو في هذا الرابط')
			return
		else:
			G4JHzTEp61,filename = eXpgPIbRv2ZMGwjm5[0]
			DLbKeGuPcnpS = ['zip','rar','txt','pdf','htm','tar','iso','html']
			D63UZqx2XBgrtbje = filename.rsplit('.',1)[1].strip(S3X6GcaiExOPtb)
			if D63UZqx2XBgrtbje in DLbKeGuPcnpS:
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','الملف ليس فيديو ولا صوت')
				return
		ISmqngYzv6jrepWUx0l.append(G4JHzTEp61)
		dBHC2nTqybSNsrkXzZ.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
	for WoEZvMXa0K2suwgPl in range(len(ISmqngYzv6jrepWUx0l)):
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?icon-(.*?)"',ISmqngYzv6jrepWUx0l[WoEZvMXa0K2suwgPl],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,XXlQ2NJMcUfPF7GArYTZn8xStjL63a in rU02bCJFWZDfVuhtMgBOyQi5P:
			if 'torrent' in XXlQ2NJMcUfPF7GArYTZn8xStjL63a: continue
			elif 'download' in XXlQ2NJMcUfPF7GArYTZn8xStjL63a: type = 'download'
			elif 'play' in XXlQ2NJMcUfPF7GArYTZn8xStjL63a: type = 'watch'
			else: type = 'unknown'
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=__'+type+'____'+dBHC2nTqybSNsrkXzZ[WoEZvMXa0K2suwgPl]+'__akwam'
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def bpRLN7ZqT5BiXKfMdI(url,filter):
	MMTo52yRJw30g6qZpPQsG = ['section','category','year','rating']
	if '?' in url: url = url.split('?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='CATEGORIES':
		if MMTo52yRJw30g6qZpPQsG[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[0]
		for WoEZvMXa0K2suwgPl in range(len(MMTo52yRJw30g6qZpPQsG[0:-1])):
			if MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'all')
		plSscrVjkRviPwm = url+'?'+soAjtN3yd04Jzr
	elif type=='FILTERS':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'all')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'?'+RAf62IHC9L0OUl1oETijSgyxX5F
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها',plSscrVjkRviPwm,241,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',plSscrVjkRviPwm,241,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,'AKWAM-FILTERS_MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<form id(.*?)</form>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('<select.*?name="(.*?)".*?">(.*?)<(.*?)</select>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	dict = {}
	for TT4Yd6yIaJGxZtoR8mh2O7,name,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<option(.*?)>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='CATEGORIES':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<=1:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: IGDobAKtj4kPF5V(plSscrVjkRviPwm)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'CATEGORIES___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,241,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,245,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='FILTERS':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع : '+name,plSscrVjkRviPwm,244,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			if 'value' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = PspiL81kMT4BwOIXo
			else: XPL0O2VkI3w1C8enMaqi = ScntgdOZCY74vNpXeW5jh8i.findall('"(.*?)"',XPL0O2VkI3w1C8enMaqi,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			title = PspiL81kMT4BwOIXo+' : '#+dict[TT4Yd6yIaJGxZtoR8mh2O7]['0']
			title = PspiL81kMT4BwOIXo+' : '+name
			if type=='FILTERS': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,244,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='CATEGORIES' and MMTo52yRJw30g6qZpPQsG[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'all')
				zb2QIaL7Y4h9g8lSck = url+'?'+soAjtN3yd04Jzr
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,241,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1')
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,245,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	TkPVaeQ9EG = ['section','category','rating','year','language','formats','quality']
	for key in TkPVaeQ9EG:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
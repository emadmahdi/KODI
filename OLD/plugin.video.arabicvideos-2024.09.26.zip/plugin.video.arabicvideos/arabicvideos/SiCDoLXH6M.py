# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
import bs4 as M5MY6w4Z7X123cFuVeLoJP0g
QSJFrwB3dMiyH2mTPKD9a = 'ELCINEMA'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_ELC_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
headers = {'Referer':zKREXyTHfVSNL8ZFYs}
CZrI4vYju7a = []
def n1zxUlcAgR(mode,url,text):
	if   mode==510: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==511: bPFto2wZdNYrClgBIEv60DJAzu = ww45zxvp0ONqSk(url)
	elif mode==512: bPFto2wZdNYrClgBIEv60DJAzu = MQ4KaqchUTkFfbJBztZr0(url)
	elif mode==513: bPFto2wZdNYrClgBIEv60DJAzu = IIsUwLBaAWDn3ov79RkJ0VrG(url)
	elif mode==514: bPFto2wZdNYrClgBIEv60DJAzu = oKIkBGx9lpZR2HFV8TXm7gQYM5NUv0(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==515: bPFto2wZdNYrClgBIEv60DJAzu = oKIkBGx9lpZR2HFV8TXm7gQYM5NUv0(url,'SPECIFIED_FILTER___'+text)
	elif mode==516: bPFto2wZdNYrClgBIEv60DJAzu = iytbc1eR2BgNFP4lYa(text)
	elif mode==517: bPFto2wZdNYrClgBIEv60DJAzu = piDtKH9TE18b0xr25uRBZ3X6koPC4(url)
	elif mode==518: bPFto2wZdNYrClgBIEv60DJAzu = wReOChsbZy1BrvAV4LKm(url)
	elif mode==519: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	elif mode==520: bPFto2wZdNYrClgBIEv60DJAzu = hN3XER7zkDbrpG(url)
	elif mode==521: bPFto2wZdNYrClgBIEv60DJAzu = VVSJFqWieBMmtgOU40olRKTA1HQ8Y(url)
	elif mode==522: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==523: bPFto2wZdNYrClgBIEv60DJAzu = KAGCZ7Dyp18(text)
	elif mode==524: bPFto2wZdNYrClgBIEv60DJAzu = y31BRKLCp0IodkV4()
	elif mode==525: bPFto2wZdNYrClgBIEv60DJAzu = mmHciTVFZYEKl6k1GoS2vag()
	elif mode==526: bPFto2wZdNYrClgBIEv60DJAzu = gu6ZDWrhvjpnNdxb9mJtHGoz80wf()
	elif mode==527: bPFto2wZdNYrClgBIEv60DJAzu = jVzvDM6euoams21ItxQCliOdLbR7()
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث بموسوعة السينما',nbOFVEDkpT4BIR7Qq82yPmHeJU,519)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'موسوعة الأعمال',nbOFVEDkpT4BIR7Qq82yPmHeJU,525)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'موسوعة الأشخاص',nbOFVEDkpT4BIR7Qq82yPmHeJU,526)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'موسوعة المصنفات',nbOFVEDkpT4BIR7Qq82yPmHeJU,527)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'موسوعة المنوعات',nbOFVEDkpT4BIR7Qq82yPmHeJU,524)
	return
def y31BRKLCp0IodkV4():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' فيديوهات - خاصة',zKREXyTHfVSNL8ZFYs+'/video',520)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فيديوهات - أحدث',zKREXyTHfVSNL8ZFYs+'/video/latest',521)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فيديوهات - أقدم',zKREXyTHfVSNL8ZFYs+'/video/oldest',521)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فيديوهات - أكثر مشاهدة',zKREXyTHfVSNL8ZFYs+'/video/views',521)
	return
def mmHciTVFZYEKl6k1GoS2vag():
	UqEMmszLn2k = zKREXyTHfVSNL8ZFYs+'/lineup?utf8=%E2%9C%93'
	jbCspFnL14TNtvXoh = UqEMmszLn2k+'&type=2&category=1&foreign=false&tag='
	cIKDTSRpamb6LrOXx = UqEMmszLn2k+'&type=2&category=3&foreign=false&tag='
	xxQuAdnXtMjVTzBK = UqEMmszLn2k+'&type=2&category=1&foreign=true&tag='
	w0wMn1KSdApqQoFjXT9VJl8ftms4W = UqEMmszLn2k+'&type=2&category=3&foreign=true&tag='
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات أفلام عربي',jbCspFnL14TNtvXoh,511)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات مسلسلات عربي',cIKDTSRpamb6LrOXx,511)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات أفلام اجنبي',xxQuAdnXtMjVTzBK,511)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات مسلسلات اجنبي',w0wMn1KSdApqQoFjXT9VJl8ftms4W,511)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس أعمال أبجدي',zKREXyTHfVSNL8ZFYs+'/index/work/alphabet',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس  بلد الإنتاج',zKREXyTHfVSNL8ZFYs+'/index/work/country',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس اللغة',zKREXyTHfVSNL8ZFYs+'/index/work/language',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس مصنفات العمل',zKREXyTHfVSNL8ZFYs+'/index/work/genre',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس سنة الإصدار',zKREXyTHfVSNL8ZFYs+'/index/work/release_year',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مواسم - فلتر محدد',zKREXyTHfVSNL8ZFYs+'/seasonals',515)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مواسم - فلتر كامل',zKREXyTHfVSNL8ZFYs+'/seasonals',514)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات - فلتر محدد',zKREXyTHfVSNL8ZFYs+'/lineup',515)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات - فلتر كامل',zKREXyTHfVSNL8ZFYs+'/lineup',514)
	return
def jVzvDM6euoams21ItxQCliOdLbR7():
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs+'/lineup',nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	G4JHzTEp61 = da8vW1GJpZU54xVBF7iwSCls.find('select',attrs={'name':'tag'})
	YE1hqa60dGTRDZ8NVBM = G4JHzTEp61.find_all('option')
	for PspiL81kMT4BwOIXo in YE1hqa60dGTRDZ8NVBM:
		XPL0O2VkI3w1C8enMaqi = PspiL81kMT4BwOIXo.get('value')
		if not XPL0O2VkI3w1C8enMaqi: continue
		title = PspiL81kMT4BwOIXo.text
		if n7neb9KTv10FcU:
			title = title.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			XPL0O2VkI3w1C8enMaqi = XPL0O2VkI3w1C8enMaqi.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/lineup?utf8=%E2%9C%93&type=&category=&foreign=&tag='+XPL0O2VkI3w1C8enMaqi
		title = title.replace('قائمة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,511)
	return
def gu6ZDWrhvjpnNdxb9mJtHGoz80wf():
	UqEMmszLn2k = zKREXyTHfVSNL8ZFYs+'/lineup?utf8=%E2%9C%93'
	vveSA4LImDMVoX9u = UqEMmszLn2k+'&type=1&category=&foreign=&tag='
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات أشخاص',vveSA4LImDMVoX9u,511)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس أشخاص أبجدي',zKREXyTHfVSNL8ZFYs+'/index/person/alphabet',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس موطن',zKREXyTHfVSNL8ZFYs+'/index/person/nationality',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس  تاريخ الميلاد',zKREXyTHfVSNL8ZFYs+'/index/person/birth_year',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فهرس  تاريخ الوفاة',zKREXyTHfVSNL8ZFYs+'/index/person/death_year',517)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات - فلتر محدد',zKREXyTHfVSNL8ZFYs+'/lineup',515)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مصنفات - فلتر كامل',zKREXyTHfVSNL8ZFYs+'/lineup',514)
	return
def ww45zxvp0ONqSk(url):
	if '/seasonals' in url: wX9P3dR07B5HynVa8 = 0
	elif '/lineup' in url: wX9P3dR07B5HynVa8 = 1
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-LISTS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	ISmqngYzv6jrepWUx0l = da8vW1GJpZU54xVBF7iwSCls.find_all(class_='jumbo-theater clearfix')
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		title = G4JHzTEp61.find_all('a')[wX9P3dR07B5HynVa8].text
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+G4JHzTEp61.find_all('a')[wX9P3dR07B5HynVa8].get('href')
		if n7neb9KTv10FcU:
			title = title.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		if not ISmqngYzv6jrepWUx0l:
			MQ4KaqchUTkFfbJBztZr0(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			return
		else:
			title = title.replace('قائمة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,512)
	E5n326fs9o8Z0ibU(da8vW1GJpZU54xVBF7iwSCls,511)
	return
def E5n326fs9o8Z0ibU(da8vW1GJpZU54xVBF7iwSCls,mode):
	G4JHzTEp61 = da8vW1GJpZU54xVBF7iwSCls.find(class_='pagination')
	if G4JHzTEp61:
		pmCWvsK7JxeMN = G4JHzTEp61.find_all('a')
		hgZAxd3LlbmcFrPGzS5UnjvCy9 = G4JHzTEp61.find_all('li')
		yv35FfutWCOgiqaU1SGnMP9TL7BZ = list(zip(pmCWvsK7JxeMN,hgZAxd3LlbmcFrPGzS5UnjvCy9))
		HT4fGXqv8hEcKsJ = -1
		p9JzYBnAtPxg1WHFQ = len(yv35FfutWCOgiqaU1SGnMP9TL7BZ)
		for yY1QxvbIU3p4jSnaVtmuPW,mVx7ekhuBRpglrvjtodI15Haq in yv35FfutWCOgiqaU1SGnMP9TL7BZ:
			HT4fGXqv8hEcKsJ += 1
			mVx7ekhuBRpglrvjtodI15Haq = mVx7ekhuBRpglrvjtodI15Haq['class']
			if 'unavailable' in mVx7ekhuBRpglrvjtodI15Haq or 'current' in mVx7ekhuBRpglrvjtodI15Haq: continue
			Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = yY1QxvbIU3p4jSnaVtmuPW.text
			f7Je8XzEqNpgHL9m4OURdAQ1 = zKREXyTHfVSNL8ZFYs+yY1QxvbIU3p4jSnaVtmuPW.get('href')
			if n7neb9KTv10FcU:
				Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y.encode(zSafwK0sDXdMN5JReniIQmrZxp)
				f7Je8XzEqNpgHL9m4OURdAQ1 = f7Je8XzEqNpgHL9m4OURdAQ1.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			if   HT4fGXqv8hEcKsJ==0: Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'أولى'
			elif HT4fGXqv8hEcKsJ==1: Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'سابقة'
			elif HT4fGXqv8hEcKsJ==p9JzYBnAtPxg1WHFQ-2: Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'لاحقة'
			elif HT4fGXqv8hEcKsJ==p9JzYBnAtPxg1WHFQ-1: Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'أخيرة'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y,f7Je8XzEqNpgHL9m4OURdAQ1,mode)
	return
def MQ4KaqchUTkFfbJBztZr0(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-TITLES1-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	ISmqngYzv6jrepWUx0l = da8vW1GJpZU54xVBF7iwSCls.find_all(class_='row')
	items,xgSWk30lJyqA2rmUn8dNBaRTz = [],True
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		if not G4JHzTEp61.find(class_='thumbnail-wrapper'): continue
		if xgSWk30lJyqA2rmUn8dNBaRTz: xgSWk30lJyqA2rmUn8dNBaRTz = False ; continue
		nn7AUPciDkr9z5vG = []
		TSXHIu6pKGgtklNPfbJ2h5rF = G4JHzTEp61.find_all(class_=['censorship red','censorship purple'])
		for OGEulSi3kMmca in TSXHIu6pKGgtklNPfbJ2h5rF:
			kJGUEqeVaRPID = OGEulSi3kMmca.find_all('li')[1].text
			if n7neb9KTv10FcU:
				kJGUEqeVaRPID = kJGUEqeVaRPID.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			nn7AUPciDkr9z5vG.append(kJGUEqeVaRPID)
		if not hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,nbOFVEDkpT4BIR7Qq82yPmHeJU,nn7AUPciDkr9z5vG,False):
			nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('data-src')
			title = G4JHzTEp61.find('h3')
			name = title.find('a').text
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+title.find('a').get('href')
			ejOhLDb2l4CptYTBWfoMG1vrna7 = G4JHzTEp61.find(class_='no-margin')
			t4tSbzDA93Qlqx1K = G4JHzTEp61.find(class_='legend')
			if ejOhLDb2l4CptYTBWfoMG1vrna7: ejOhLDb2l4CptYTBWfoMG1vrna7 = ejOhLDb2l4CptYTBWfoMG1vrna7.text
			if t4tSbzDA93Qlqx1K: t4tSbzDA93Qlqx1K = t4tSbzDA93Qlqx1K.text
			if n7neb9KTv10FcU:
				nnu5vdh1IscOA8J = nnu5vdh1IscOA8J.encode(zSafwK0sDXdMN5JReniIQmrZxp)
				name = name.encode(zSafwK0sDXdMN5JReniIQmrZxp)
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
				if ejOhLDb2l4CptYTBWfoMG1vrna7: ejOhLDb2l4CptYTBWfoMG1vrna7 = ejOhLDb2l4CptYTBWfoMG1vrna7.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			Nyb1swDcFkeGUdMEnh9itZ = {}
			if t4tSbzDA93Qlqx1K: Nyb1swDcFkeGUdMEnh9itZ['stars'] = t4tSbzDA93Qlqx1K
			if ejOhLDb2l4CptYTBWfoMG1vrna7:
				ejOhLDb2l4CptYTBWfoMG1vrna7 = ejOhLDb2l4CptYTBWfoMG1vrna7.replace(wwOnIucWJj,' .. ')
				Nyb1swDcFkeGUdMEnh9itZ['plot'] = ejOhLDb2l4CptYTBWfoMG1vrna7.replace('...اقرأ المزيد',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '/work/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,516,nnu5vdh1IscOA8J,nbOFVEDkpT4BIR7Qq82yPmHeJU,name,nbOFVEDkpT4BIR7Qq82yPmHeJU,Nyb1swDcFkeGUdMEnh9itZ)
			elif '/person/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,513,nnu5vdh1IscOA8J,nbOFVEDkpT4BIR7Qq82yPmHeJU,name,nbOFVEDkpT4BIR7Qq82yPmHeJU,Nyb1swDcFkeGUdMEnh9itZ)
	E5n326fs9o8Z0ibU(da8vW1GJpZU54xVBF7iwSCls,512)
	return
def IIsUwLBaAWDn3ov79RkJ0VrG(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-TITLES2-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	ISmqngYzv6jrepWUx0l = da8vW1GJpZU54xVBF7iwSCls.find_all('li')
	QlL1JM5odKm9ZrEWwfesuP4jq,items = [],[]
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		if not G4JHzTEp61.find(class_='thumbnail-wrapper'): continue
		if not G4JHzTEp61.find(class_=['unstyled','unstyled text-center']): continue
		if G4JHzTEp61.find(class_='hide'): continue
		title = G4JHzTEp61.find(class_=['unstyled','unstyled text-center'])
		name = title.find('a').text
		if name in QlL1JM5odKm9ZrEWwfesuP4jq: continue
		QlL1JM5odKm9ZrEWwfesuP4jq.append(name)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+title.find('a').get('href')
		if '/search/work/' in url: nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('src')
		elif '/search/person/' in url: nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('data-src')
		elif '/search/video/' in url: nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('data-src')
		else: nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('src')
		if n7neb9KTv10FcU:
			name = name.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			nnu5vdh1IscOA8J = nnu5vdh1IscOA8J.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		name = name.strip(S3X6GcaiExOPtb)
		items.append((name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nnu5vdh1IscOA8J))
	if '/search/person/' in url: items = sorted(items,reverse=False,key=lambda key: key[0])
	for name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nnu5vdh1IscOA8J in items:
		if '/search/video/' in url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,522,nnu5vdh1IscOA8J)
		elif '/search/person/' in url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,513,nnu5vdh1IscOA8J,nbOFVEDkpT4BIR7Qq82yPmHeJU,name)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,516,nnu5vdh1IscOA8J,nbOFVEDkpT4BIR7Qq82yPmHeJU,name)
	return
def iytbc1eR2BgNFP4lYa(text):
	text = text.replace('الإعلان',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('لفيلم',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('الرسمي',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	text = text.replace('إعلان',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('فيلم',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('البرومو',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	text = text.replace('التشويقي',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('لمسلسل',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('مسلسل',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	text = text.replace(':',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(')',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('(',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(',',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	text = text.replace('_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(';',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('-',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	text = text.replace('\'',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('\"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	text = text.replace(R4PgzXibOn3f1SxmldrWw8acs2p,S3X6GcaiExOPtb).replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	text = text.strip(S3X6GcaiExOPtb)
	v2SoWGqZgiPNjfEzH637 = text.count(S3X6GcaiExOPtb)+1
	if v2SoWGqZgiPNjfEzH637==1:
		KAGCZ7Dyp18(text)
		return
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+eMypvI8XqHjYU02anWD9gsSrkt+'==== كلمات للبحث ===='+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	S3SmBcxVh6LHey = text.split(S3X6GcaiExOPtb)
	NX4ndO9aUhJAkDES8tHBjPRrYflCI = pow(2,v2SoWGqZgiPNjfEzH637)
	CCyvpw7Uush2gbGeFr3 = []
	def rldKUxuOL5hmYwR(c6tmKg5E8hnRS4LUArqzZBYCINJT,LGrjQCh8dyHPJE1oNOp):
		if c6tmKg5E8hnRS4LUArqzZBYCINJT=='1': return LGrjQCh8dyHPJE1oNOp
		return nbOFVEDkpT4BIR7Qq82yPmHeJU
	for HT4fGXqv8hEcKsJ in range(NX4ndO9aUhJAkDES8tHBjPRrYflCI,0,-1):
		NWbj08aRTwHyS439AGz2onDxLhpO = list(v2SoWGqZgiPNjfEzH637*'0'+bin(HT4fGXqv8hEcKsJ)[2:])[-v2SoWGqZgiPNjfEzH637:]
		NWbj08aRTwHyS439AGz2onDxLhpO = reversed(NWbj08aRTwHyS439AGz2onDxLhpO)
		yi6wOauQ3Sb1JUBt4 = map(rldKUxuOL5hmYwR,NWbj08aRTwHyS439AGz2onDxLhpO,S3SmBcxVh6LHey)
		title = S3X6GcaiExOPtb.join(filter(None,yi6wOauQ3Sb1JUBt4))
		if n7neb9KTv10FcU: HDE69mkhQg2NaFpuUy5JRb = title.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		else: HDE69mkhQg2NaFpuUy5JRb = title
		if len(HDE69mkhQg2NaFpuUy5JRb)>2 and title not in CCyvpw7Uush2gbGeFr3:
			CCyvpw7Uush2gbGeFr3.append(title)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,523,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,title)
	return
def KAGCZ7Dyp18(KYPwjRcdHJ0):
	if n7neb9KTv10FcU:
		KYPwjRcdHJ0 = KYPwjRcdHJ0.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		import arabic_reshaper as oEJzklt47TWYFDyuV2Pwb,bidi.algorithm as InTA8P54xi0Ocg
		KYPwjRcdHJ0 = oEJzklt47TWYFDyuV2Pwb.ArabicReshaper().reshape(KYPwjRcdHJ0)
		KYPwjRcdHJ0 = InTA8P54xi0Ocg.get_display(KYPwjRcdHJ0)
	import H2VSdwTvpr
	KYPwjRcdHJ0 = dR75Vq2gprfHmUcNhG(hWXyS52dYN8u=KYPwjRcdHJ0)
	H2VSdwTvpr.cvZoNw4F0fRjYaMuP5CVrE(KYPwjRcdHJ0)
	return
def piDtKH9TE18b0xr25uRBZ3X6koPC4(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-INDEXES_LISTS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	G4JHzTEp61 = da8vW1GJpZU54xVBF7iwSCls.find(class_='list-separator list-title')
	bdW70uQAIF = G4JHzTEp61.find_all('a')
	items = []
	for title in bdW70uQAIF:
		name = title.text
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+title.get('href')
		if n7neb9KTv10FcU:
			name = name.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		if '#' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: items.append((name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6))
	items = sorted(items,reverse=False,key=lambda key: key[0])
	for xB2lOZNsPvFQDC4gMz in items:
		name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = xB2lOZNsPvFQDC4gMz
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,518)
	return
def wReOChsbZy1BrvAV4LKm(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-INDEXES_TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	ISmqngYzv6jrepWUx0l = da8vW1GJpZU54xVBF7iwSCls.find(class_='expand').find_all('tr')
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		WSjou2CXZkbNTy = G4JHzTEp61.find_all('a')
		if not WSjou2CXZkbNTy: continue
		nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('data-src')
		name = WSjou2CXZkbNTy[1].text
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+WSjou2CXZkbNTy[1].get('href')
		t4tSbzDA93Qlqx1K = G4JHzTEp61.find(class_='legend')
		if t4tSbzDA93Qlqx1K: t4tSbzDA93Qlqx1K = t4tSbzDA93Qlqx1K.text
		if n7neb9KTv10FcU:
			name = name.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			nnu5vdh1IscOA8J = nnu5vdh1IscOA8J.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		Nyb1swDcFkeGUdMEnh9itZ = {}
		if t4tSbzDA93Qlqx1K: Nyb1swDcFkeGUdMEnh9itZ['stars'] = t4tSbzDA93Qlqx1K
		if '/work/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,516,nnu5vdh1IscOA8J,nbOFVEDkpT4BIR7Qq82yPmHeJU,name,nbOFVEDkpT4BIR7Qq82yPmHeJU,Nyb1swDcFkeGUdMEnh9itZ)
		elif '/person/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,513,nnu5vdh1IscOA8J,nbOFVEDkpT4BIR7Qq82yPmHeJU,name,nbOFVEDkpT4BIR7Qq82yPmHeJU,Nyb1swDcFkeGUdMEnh9itZ)
	E5n326fs9o8Z0ibU(da8vW1GJpZU54xVBF7iwSCls,518)
	return
def hN3XER7zkDbrpG(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-VIDEOS_LISTS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	bdW70uQAIF = da8vW1GJpZU54xVBF7iwSCls.find_all(class_='section-title inline')
	rU02bCJFWZDfVuhtMgBOyQi5P = da8vW1GJpZU54xVBF7iwSCls.find_all(class_='button green small right')
	items = zip(bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P)
	for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		title = title.text
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.get('href')
		if n7neb9KTv10FcU:
			title = title.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		title = title.replace(R4PgzXibOn3f1SxmldrWw8acs2p,S3X6GcaiExOPtb).replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,521)
	return
def VVSJFqWieBMmtgOU40olRKTA1HQ8Y(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-VIDEOS_TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	UMJ6saG7uOmZ = da8vW1GJpZU54xVBF7iwSCls.find(class_='large-block-grid-4 medium-block-grid-4 small-block-grid-2')
	ISmqngYzv6jrepWUx0l = UMJ6saG7uOmZ.find_all('li')
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		title = G4JHzTEp61.find(class_='title').text
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+G4JHzTEp61.find('a').get('href')
		nnu5vdh1IscOA8J = G4JHzTEp61.find('img').get('data-src')
		H07WdckxAoZF1fn4LNMOTP65eEtr = G4JHzTEp61.find(class_='duration').text
		if n7neb9KTv10FcU:
			title = title.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			nnu5vdh1IscOA8J = nnu5vdh1IscOA8J.encode(zSafwK0sDXdMN5JReniIQmrZxp)
			H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,522,nnu5vdh1IscOA8J,H07WdckxAoZF1fn4LNMOTP65eEtr)
	E5n326fs9o8Z0ibU(da8vW1GJpZU54xVBF7iwSCls,521)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = da8vW1GJpZU54xVBF7iwSCls.find(class_='flex-video').find('iframe').get('src')
	if n7neb9KTv10FcU: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY([grwO1UeqkvQBf4tmz0jTx3lEKZWbF6],QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'%20')
	url = zKREXyTHfVSNL8ZFYs+'/search/?q='+search
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-SEARCH-1st')
	if not cnPhVmgFxA.succeeded:
		vveSA4LImDMVoX9u = zKREXyTHfVSNL8ZFYs+'/search_entity/?q='+search+'&entity=work'
		f7Je8XzEqNpgHL9m4OURdAQ1 = zKREXyTHfVSNL8ZFYs+'/search_entity/?q='+search+'&entity=person'
		SYPvo97s4dl2UuJ3WpXFehDganIzkN = zKREXyTHfVSNL8ZFYs+'/search_entity/?q='+search+'&entity=video'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن أعمال',vveSA4LImDMVoX9u,513,nbOFVEDkpT4BIR7Qq82yPmHeJU,search)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن أشخاص',f7Je8XzEqNpgHL9m4OURdAQ1,513,nbOFVEDkpT4BIR7Qq82yPmHeJU,search)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث عن فيديوهات',SYPvo97s4dl2UuJ3WpXFehDganIzkN,513,nbOFVEDkpT4BIR7Qq82yPmHeJU,search)
		return
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	da8vW1GJpZU54xVBF7iwSCls = M5MY6w4Z7X123cFuVeLoJP0g.BeautifulSoup(UTvsQb4HpCP3Aeo2wDZG7X5V,'html.parser',multi_valued_attributes=None)
	ISmqngYzv6jrepWUx0l = da8vW1GJpZU54xVBF7iwSCls.find_all(class_='section-title left')
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		title = G4JHzTEp61.text
		if n7neb9KTv10FcU:
			title = title.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		title = title.split('(',1)[0].strip(S3X6GcaiExOPtb)
		if   'أعمال' in title: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.replace('/search/','/search/work/')
		elif 'أشخاص' in title: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.replace('/search/','/search/person/')
		elif 'فيديوهات' in title: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.replace('/search/','/search/video/')
		else: continue
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,513)
	return
def oKIkBGx9lpZR2HFV8TXm7gQYM5NUv0(url,text):
	global MMTo52yRJw30g6qZpPQsG,TkPVaeQ9EG
	if '/seasonals' in url:
		MMTo52yRJw30g6qZpPQsG = ['seasonal','year','category']
		TkPVaeQ9EG = ['seasonal','year','category']
	elif '/lineup' in url:
		MMTo52yRJw30g6qZpPQsG = ['category','foreign','type']
		TkPVaeQ9EG = ['category','foreign','type']
	bpRLN7ZqT5BiXKfMdI(url,text)
	return
def XCdegEMjq1uDz3whim(url):
	url = url.split('/smartemadfilter?')[0]
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ELCINEMA-GET_FILTERS_BLOCKS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('form action="/(.*?)</form>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('<select name="(.*?)" id="(.*?)".*?>(.*?)</div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return m8kVhKyAp7NCibFJ3sYO4EwMS
def Ubu4qfBDldYcI06(G4JHzTEp61):
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<option value="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return items
def wwdcMz3HCWqi(url):
	jqDXgyUVZ2 = url.split('/smartemadfilter?')[0]
	ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	url = url.replace('/smartemadfilter?','/?utf8=%E2%9C%93&')
	return url
def dcpQSUukIqfltMFB2z6KCDnh1w9GY4(bhz0GBTNQdYxvnt,url):
	soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'all_filters')
	zb2QIaL7Y4h9g8lSck = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	zb2QIaL7Y4h9g8lSck = wwdcMz3HCWqi(zb2QIaL7Y4h9g8lSck)
	return zb2QIaL7Y4h9g8lSck
def bpRLN7ZqT5BiXKfMdI(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if MMTo52yRJw30g6qZpPQsG[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[0]
		for WoEZvMXa0K2suwgPl in range(len(MMTo52yRJw30g6qZpPQsG[0:-1])):
			if MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	elif type=='ALL_ITEMS_FILTER':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'/smartemadfilter?'+RAf62IHC9L0OUl1oETijSgyxX5F
		plSscrVjkRviPwm = wwdcMz3HCWqi(plSscrVjkRviPwm)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',plSscrVjkRviPwm,511)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',plSscrVjkRviPwm,511)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	m8kVhKyAp7NCibFJ3sYO4EwMS = XCdegEMjq1uDz3whim(url)
	dict = {}
	for name,TT4Yd6yIaJGxZtoR8mh2O7,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		name = name.replace('--',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		items = Ubu4qfBDldYcI06(G4JHzTEp61)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='SPECIFIED_FILTER':
			if TT4Yd6yIaJGxZtoR8mh2O7 not in MMTo52yRJw30g6qZpPQsG: continue
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<2:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]:
					url = wwdcMz3HCWqi(url)
					MQ4KaqchUTkFfbJBztZr0(url)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'SPECIFIED_FILTER___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				plSscrVjkRviPwm = wwdcMz3HCWqi(plSscrVjkRviPwm)
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,511)
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,515,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='ALL_ITEMS_FILTER':
			if TT4Yd6yIaJGxZtoR8mh2O7 not in TkPVaeQ9EG: continue
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع: '+name,plSscrVjkRviPwm,514,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			if 'مصنفات أخرى' in PspiL81kMT4BwOIXo: continue
			if 'الكل' in PspiL81kMT4BwOIXo: continue
			if 'اللغة' in PspiL81kMT4BwOIXo: continue
			PspiL81kMT4BwOIXo = PspiL81kMT4BwOIXo.replace('قائمة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if   name=='type': name = 'النوع'
			elif name=='category': name = 'العمل'
			elif name=='foreign': name = 'اللغة'
			elif name=='year': name = 'السنة'
			elif name=='seasonal': name = 'الموسم'
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			if name: title = PspiL81kMT4BwOIXo+' :'+name
			else: title = PspiL81kMT4BwOIXo
			if type=='ALL_ITEMS_FILTER': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,514,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='SPECIFIED_FILTER' and MMTo52yRJw30g6qZpPQsG[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				zb2QIaL7Y4h9g8lSck = dcpQSUukIqfltMFB2z6KCDnh1w9GY4(bhz0GBTNQdYxvnt,url)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,511)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,515,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.replace('=&','=0&')
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for key in TkPVaeQ9EG:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all_filters': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('=0','=')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
MMTo52yRJw30g6qZpPQsG = []
TkPVaeQ9EG = []
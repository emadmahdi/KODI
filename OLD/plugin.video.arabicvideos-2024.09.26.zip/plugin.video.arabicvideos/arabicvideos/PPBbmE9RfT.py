# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'RESOLVERS'
PSEgAh86NWmCQGdMKike = []
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
def ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,source,type,url):
	if not NWtqFg91ZSKinvIwAc:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Failed finding video files    Site: [ '+source+' ]    Type: [ '+type+' ]')
		VjSi2B0UsT9NtLJwgcMvahGz = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'dict','MISC_PERM','SITES_ERRORS')
		KxjH7PYqN8LgUEQGJ2Su = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M',lQMuw1PvVpAk.gmtime(sqeRK2tVw8))
		EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = KxjH7PYqN8LgUEQGJ2Su,url
		key = source+R4PgzXibOn3f1SxmldrWw8acs2p+JeVILUu027qW+R4PgzXibOn3f1SxmldrWw8acs2p+str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)
		CtO9cFuULSm62PWToMlzN1 = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if key not in list(VjSi2B0UsT9NtLJwgcMvahGz.keys()): VjSi2B0UsT9NtLJwgcMvahGz[key] = [EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U]
		else:
			if url not in str(VjSi2B0UsT9NtLJwgcMvahGz[key]): VjSi2B0UsT9NtLJwgcMvahGz[key].append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
			else: CtO9cFuULSm62PWToMlzN1 = '\n هذا الفيديو موجود في قائمة الفيديوهات التي لم تعمل'
		DfiBp9Te1CwXAb5zQsOh = f4fTutDOEwUeIoPLRQ
		for key in list(VjSi2B0UsT9NtLJwgcMvahGz.keys()):
			VjSi2B0UsT9NtLJwgcMvahGz[key] = list(set(VjSi2B0UsT9NtLJwgcMvahGz[key]))
			DfiBp9Te1CwXAb5zQsOh += len(VjSi2B0UsT9NtLJwgcMvahGz[key])
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','للأسف البرنامج لم يجد ملفات الفيديو'+CtO9cFuULSm62PWToMlzN1+'\n\n للعلم البرنامج يقوم بجمع قائمة بالفيديوهات التي لم يجد لها ملفات فيديو وسوف يعرض عليك البرنامج أن ترسل هذه القائمة إلى المبرمج عندما يصبح عددها 5 فيديوهات'+'\n\n'+'عدد الفيديوهات في القائمة الآن هو :  '+str(DfiBp9Te1CwXAb5zQsOh))
		if DfiBp9Te1CwXAb5zQsOh>=5:
			oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','البرنامج جمع قائمة فيها 5 فيديوهات لم يجد البرنامج لها ملفات فيديو .. سوف يقوم البرنامج الآن بمسح هذه القائمة \n\n هل تريد إرسال هذه القائمة قبل مسحها إلى المبرمج لكي يقوم المبرمج بفحص هذه الفيديوهات ؟!!')
			if oyNUHM3uQq==1:
				ldXSONaGmEQyckuhw = nbOFVEDkpT4BIR7Qq82yPmHeJU
				for key in list(VjSi2B0UsT9NtLJwgcMvahGz.keys()):
					ldXSONaGmEQyckuhw += wwOnIucWJj+key
					lcmuZp6W1DHq92 = sorted(VjSi2B0UsT9NtLJwgcMvahGz[key],reverse=SmbNGskjMx,key=lambda Pt5va0fRAFND1eQy2Wid: Pt5va0fRAFND1eQy2Wid[f4fTutDOEwUeIoPLRQ])
					for KxjH7PYqN8LgUEQGJ2Su,url in lcmuZp6W1DHq92:
						ldXSONaGmEQyckuhw += wwOnIucWJj+KxjH7PYqN8LgUEQGJ2Su+R4PgzXibOn3f1SxmldrWw8acs2p+SxN0jnqr3LI(url)
					ldXSONaGmEQyckuhw += '\n\n'
				import SJqrPsfTgG
				EJNf2kglaiQHnFGe531Iq = SJqrPsfTgG.Rs07nFAOYjCQN('Videos',nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-PLAY_RESOLVERS',nbOFVEDkpT4BIR7Qq82yPmHeJU,ldXSONaGmEQyckuhw)
				if EJNf2kglaiQHnFGe531Iq: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإرسال بنجاح')
				else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','فشلت عملية الإرسال')
			if oyNUHM3uQq!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				VjSi2B0UsT9NtLJwgcMvahGz = {}
				uoxvtFlSXEPnf(SOEM49TbV0zuQ,'MISC_PERM','SITES_ERRORS')
		if VjSi2B0UsT9NtLJwgcMvahGz: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'MISC_PERM','SITES_ERRORS',VjSi2B0UsT9NtLJwgcMvahGz,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
		return
	NWtqFg91ZSKinvIwAc = list(set(NWtqFg91ZSKinvIwAc))
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = IWXqZsVg1r5K3CvDb8kyUGcBfM(NWtqFg91ZSKinvIwAc,source)
	jarCW7DIfHmGPnioXb = str(lPpY5fw3tOBcEye91Caun2FQZ).count('__watch')
	UFgt54WuoMkclD8fV = str(lPpY5fw3tOBcEye91Caun2FQZ).count('__download')
	kzHjOFGKYMPQviCILw = len(lPpY5fw3tOBcEye91Caun2FQZ)-jarCW7DIfHmGPnioXb-UFgt54WuoMkclD8fV
	VEk5w62oP1nNy8sKjhxeaRU9 = 'مشاهدة:'+str(jarCW7DIfHmGPnioXb)+'    تحميل:'+str(UFgt54WuoMkclD8fV)+'    أخرى:'+str(kzHjOFGKYMPQviCILw)
	if not lPpY5fw3tOBcEye91Caun2FQZ: yi6wOauQ3Sb1JUBt4,uusxjPSpV5c = 'unresolved',nbOFVEDkpT4BIR7Qq82yPmHeJU
	else:
		add = f4fTutDOEwUeIoPLRQ
		if not any(XPL0O2VkI3w1C8enMaqi in source for XPL0O2VkI3w1C8enMaqi in kkbtlN2PnKsIXuH):
			add = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			lPpY5fw3tOBcEye91Caun2FQZ = ['RESOLVE_ALL_LINKS']+list(lPpY5fw3tOBcEye91Caun2FQZ)
			bbKoeBcirVfzwAqZdQUFDSX = [eMypvI8XqHjYU02anWD9gsSrkt+'فحص جميع السيرفرات'+c7gxFyUCGm]+list(bbKoeBcirVfzwAqZdQUFDSX)
		while Ag9l6cw3EBqP8HsQuGMizfOtr4:
			uusxjPSpV5c,yi6wOauQ3Sb1JUBt4 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
			if QQ3hd2tR8s.resolveonly: add,bCiGxXzDkH = vkIa3ijEQVsJGdWOXwK7bnue9ADR,f4fTutDOEwUeIoPLRQ
			elif add and len(lPpY5fw3tOBcEye91Caun2FQZ)==QQSugEIn2mTCpRsfcaJHhPdAWzylM:
				bCiGxXzDkH = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			else: bCiGxXzDkH = nnRXQH90qeOtABkJzGr(VEk5w62oP1nNy8sKjhxeaRU9,bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: yi6wOauQ3Sb1JUBt4 = 'canceled_1st_menu'
			elif add and bCiGxXzDkH==f4fTutDOEwUeIoPLRQ:
				yi6wOauQ3Sb1JUBt4 = 'canceled_2nd_menu'
				bPFto2wZdNYrClgBIEv60DJAzu = OrBPj5VNKUkz4hnIfCwxFD1aXGoZ(bbKoeBcirVfzwAqZdQUFDSX[add:],lPpY5fw3tOBcEye91Caun2FQZ[add:],source)
				if QQ3hd2tR8s.resolveonly: return
				if bPFto2wZdNYrClgBIEv60DJAzu:
					oSm4zHfbKd7PskcE0VQp2ATIX = []
					for CgPhBrkIZpi,SYPvo97s4dl2UuJ3WpXFehDganIzkN,kACE1zlNDqasm2GwKjgMcPJ8,tL3AvDMSBVOYs8qUkKJwx,wtZxuErOoh in bPFto2wZdNYrClgBIEv60DJAzu:
						if wtZxuErOoh: oSm4zHfbKd7PskcE0VQp2ATIX.append((CgPhBrkIZpi,SYPvo97s4dl2UuJ3WpXFehDganIzkN,kACE1zlNDqasm2GwKjgMcPJ8,tL3AvDMSBVOYs8qUkKJwx,wtZxuErOoh))
					if oSm4zHfbKd7PskcE0VQp2ATIX: bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errors,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = zip(*oSm4zHfbKd7PskcE0VQp2ATIX)
					else:
						aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','للأسف لم يتم إيجاد سيرفرات جيدة في هذا الفيديو .. حاول أن تبحث عن هذا الفيديو في مواقع أخرى')
						yi6wOauQ3Sb1JUBt4 = 'failed'
						break
					VEk5w62oP1nNy8sKjhxeaRU9 = 'السيرفرات الجيدة ( '+str(len(lPpY5fw3tOBcEye91Caun2FQZ))+' )'
					add = f4fTutDOEwUeIoPLRQ
					continue
			else:
				bPFto2wZdNYrClgBIEv60DJAzu = OrBPj5VNKUkz4hnIfCwxFD1aXGoZ([bbKoeBcirVfzwAqZdQUFDSX[bCiGxXzDkH]],[lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]],source)
				if bPFto2wZdNYrClgBIEv60DJAzu:
					title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,errors,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = bPFto2wZdNYrClgBIEv60DJAzu[f4fTutDOEwUeIoPLRQ]
					if 'سيرفر' in title and '2مجهول2' in title:
						fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Unknown selected server   Server: [ '+title+' ]   Original: [ '+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+' ]')
						import SJqrPsfTgG
						SJqrPsfTgG.XXozK8CcxhYS3DlNguHVbPLQ()
						yi6wOauQ3Sb1JUBt4 = 'unresolved'
					else:
						yi6wOauQ3Sb1JUBt4,uusxjPSpV5c,gCJprIs2wUzfcNhtxv = GdRbXfmZaPgM6ikSlc4eWLETVoNy8(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,errors,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P,source,type)
			if yi6wOauQ3Sb1JUBt4 in ['EXIT_ALL_RESOLVERS','canceled_1st_menu']:
				V5VsTuKOPYNQvkcX2 = RarSo2nTfwU0WEGK.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Playlist.Clear","params":{"playlistid":1}}')
			if yi6wOauQ3Sb1JUBt4 in ['EXIT_ALL_RESOLVERS','download','playing','testing','canceled_1st_menu'] or len(lPpY5fw3tOBcEye91Caun2FQZ)==1+add: break
			elif yi6wOauQ3Sb1JUBt4 in ['failed','timeout','tried']: break
			elif yi6wOauQ3Sb1JUBt4 not in ['canceled_2nd_menu','https']:
				if wwOnIucWJj in uusxjPSpV5c: uusxjPSpV5c = '[LEFT]  '+uusxjPSpV5c.replace(wwOnIucWJj,'\n[LEFT]  ')
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','السيرفر لم يعمل جرب سيرفر غيره'+wwOnIucWJj+uusxjPSpV5c,profile='confirm_mediumfont')
	if yi6wOauQ3Sb1JUBt4=='unresolved' and len(bbKoeBcirVfzwAqZdQUFDSX)>0: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','سيرفر هذا الفيديو لم يعمل جرب فيديو غيره'+wwOnIucWJj+uusxjPSpV5c,profile='confirm_mediumfont')
	elif yi6wOauQ3Sb1JUBt4 in ['failed','timeout'] and uusxjPSpV5c!=nbOFVEDkpT4BIR7Qq82yPmHeJU: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج',uusxjPSpV5c,profile='confirm_mediumfont')
	return yi6wOauQ3Sb1JUBt4
nPI56Ug8wj9My0fDscBETLHzAoXN,hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz,qs8JfMYReZAC = [],[],[],[],[],[]
def OrBPj5VNKUkz4hnIfCwxFD1aXGoZ(ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc,source):
	global nPI56Ug8wj9My0fDscBETLHzAoXN,hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz,qs8JfMYReZAC
	bPFto2wZdNYrClgBIEv60DJAzu,SSeYZRtvzpFrLmUgIf3T,new = [],[],[]
	Zb4NIBy16VvWF(SmbNGskjMx,SmbNGskjMx,SmbNGskjMx)
	count = len(NWtqFg91ZSKinvIwAc)
	for ablZij8g2sVkIB4m1pTKz3qEtx in range(count):
		nPI56Ug8wj9My0fDscBETLHzAoXN.append(None)
		hhvF5yW4kQ1dxCLm83BfATlZ.append(None)
		WywD1Y9fE4dOtLFZxgGJ6.append(None)
		SSaiGHeLq7KwAI4UTQJ.append(None)
		UmRopiJqVk9ljYde2Agz.append(None)
		qs8JfMYReZAC.append(f4fTutDOEwUeIoPLRQ)
		title = ifOk5xt1uHRJrTGFB7zZaeKIs6bqU[ablZij8g2sVkIB4m1pTKz3qEtx]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[ablZij8g2sVkIB4m1pTKz3qEtx].strip(S3X6GcaiExOPtb).strip('&').strip('?').strip('/')
		if count>vkIa3ijEQVsJGdWOXwK7bnue9ADR and QQ3hd2tR8s.showDialogs: SSVCGE0bOfW1w9u52yvBxocNeP('فحص سيرفر رقم  '+str(ablZij8g2sVkIB4m1pTKz3qEtx+1),title)
		PfJB8eMn4qwuRSHQAyd27TUlF = ['YOUTUBE','DAILYMOTION','AKWAM']
		if source in PfJB8eMn4qwuRSHQAyd27TUlF: wXCn0qZ1zB7egRv(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,ablZij8g2sVkIB4m1pTKz3qEtx)
		else:
			QSNHrmDRv6puBK9cxdsjJOVeMoXyia = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('?named=',vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
			m07BKTFoY8Iib = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','RESOLVED',QSNHrmDRv6puBK9cxdsjJOVeMoXyia)
			if m07BKTFoY8Iib and (m07BKTFoY8Iib[f4fTutDOEwUeIoPLRQ] or m07BKTFoY8Iib[QQSugEIn2mTCpRsfcaJHhPdAWzylM]): nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx] = m07BKTFoY8Iib
			else:
				fcWPXxCE0mY9vk1 = eb6R0h1Fjl.Thread(target=wXCn0qZ1zB7egRv,args=(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,ablZij8g2sVkIB4m1pTKz3qEtx))
				fcWPXxCE0mY9vk1.start()
				SSeYZRtvzpFrLmUgIf3T.append(fcWPXxCE0mY9vk1)
				new.append(ablZij8g2sVkIB4m1pTKz3qEtx)
				lQMuw1PvVpAk.sleep(0.75)
	timeout = 60 if source=='AKWAM' else 30
	BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
	for fcWPXxCE0mY9vk1 in SSeYZRtvzpFrLmUgIf3T: fcWPXxCE0mY9vk1.join(timeout)
	for ablZij8g2sVkIB4m1pTKz3qEtx in range(count):
		title = ifOk5xt1uHRJrTGFB7zZaeKIs6bqU[ablZij8g2sVkIB4m1pTKz3qEtx]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[ablZij8g2sVkIB4m1pTKz3qEtx].strip(S3X6GcaiExOPtb).strip('&').strip('?').strip('/')
		dhV16pObPmLnw3l8QEj0X7rSqG = Ag9l6cw3EBqP8HsQuGMizfOtr4 if qs8JfMYReZAC[ablZij8g2sVkIB4m1pTKz3qEtx]+vkIa3ijEQVsJGdWOXwK7bnue9ADR>timeout else SmbNGskjMx
		if nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx] and (nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx][f4fTutDOEwUeIoPLRQ] or nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx][QQSugEIn2mTCpRsfcaJHhPdAWzylM]): oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1 = nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx]
		elif dhV16pObPmLnw3l8QEj0X7rSqG: oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1 = '\nFailed:  Timed Out ('+str(timeout)+' seconds)',[],[]
		else: oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1 = '\nFailed:  Could not find the video file',[],[]
		bPFto2wZdNYrClgBIEv60DJAzu.append([title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1])
		if ablZij8g2sVkIB4m1pTKz3qEtx in new:
			QSNHrmDRv6puBK9cxdsjJOVeMoXyia = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('?named=',1)[f4fTutDOEwUeIoPLRQ]
			z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'RESOLVED',QSNHrmDRv6puBK9cxdsjJOVeMoXyia,[oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1],RRYx6sACloVPr3td95Ej)
	Zb4NIBy16VvWF(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return bPFto2wZdNYrClgBIEv60DJAzu
def wXCn0qZ1zB7egRv(RWZpkDLtY5Eyb46029MvAKmqBQd8o,url,source,UUfw8Ld24pDl5xbHRhe):
	global nPI56Ug8wj9My0fDscBETLHzAoXN,qs8JfMYReZAC
	qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = f4fTutDOEwUeIoPLRQ
	BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
	fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Resolving started   Selected: [ '+RWZpkDLtY5Eyb46029MvAKmqBQd8o+' ]   Original: [ '+url+' ]')
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,zGcM56Ki1lfB8TZPtVHeXb = url,nbOFVEDkpT4BIR7Qq82yPmHeJU
	Tks3rDNUeEqh6 = 'INTERNAL_RESOLVER'
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = iXgJUrjoMmF8hzs(url,source)
	if uusxjPSpV5c=='EXIT_ALL_RESOLVERS':
		nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = 'EXIT_ALL_RESOLVERS',[],[]
		qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9
		return nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe]
	elif 'NEED_EXTERNAL_RESOLVERS' in uusxjPSpV5c:
		zGcM56Ki1lfB8TZPtVHeXb = '\nResolver 1:  Need External Resolver'
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)[f4fTutDOEwUeIoPLRQ]
		Tks3rDNUeEqh6,zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = i0RIJo5SetVpOGdAyUbQ4v9NxnB3(zGcM56Ki1lfB8TZPtVHeXb,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,UUfw8Ld24pDl5xbHRhe)
		if zGcM56Ki1lfB8TZPtVHeXb=='EXIT_ALL_RESOLVERS':
			qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9
			return zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	elif uusxjPSpV5c: zGcM56Ki1lfB8TZPtVHeXb = 'Resolver 1:  '+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:80]
	if lPpY5fw3tOBcEye91Caun2FQZ:
		lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
		fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Resolving succeeded   Selected: [ '+RWZpkDLtY5Eyb46029MvAKmqBQd8o+' ]   Resolver: [ '+Tks3rDNUeEqh6+' ]   Original: [ '+url+' ]   Link: [ '+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+' ]   Videos: [ '+str(lPpY5fw3tOBcEye91Caun2FQZ)+' ]')
	else: fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Resolving failed   Selected: [ '+RWZpkDLtY5Eyb46029MvAKmqBQd8o+' ]   Original: [ '+url+' ]   Link: [ '+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+' ]   Errors: [ '+zGcM56Ki1lfB8TZPtVHeXb+' ]')
	zGcM56Ki1lfB8TZPtVHeXb = SxN0jnqr3LI(zGcM56Ki1lfB8TZPtVHeXb)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9
	return zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def GdRbXfmZaPgM6ikSlc4eWLETVoNy8(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,source,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if uusxjPSpV5c=='EXIT_ALL_RESOLVERS': return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	elif lPpY5fw3tOBcEye91Caun2FQZ:
		while Ag9l6cw3EBqP8HsQuGMizfOtr4:
			if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: bCiGxXzDkH = f4fTutDOEwUeIoPLRQ
			else: bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الملف المناسب:', bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: yi6wOauQ3Sb1JUBt4 = 'tried'
			else:
				kk4bAafDCZm7XQJis0PBqp1Weul = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
				fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Playing started   Selected: [ '+title+' ]   Original: [ '+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+' ]   Video: [ '+str(kk4bAafDCZm7XQJis0PBqp1Weul)+' ]')
				if 'moshahda.' in kk4bAafDCZm7XQJis0PBqp1Weul and 'download_orig' in kk4bAafDCZm7XQJis0PBqp1Weul:
					oOFlVdqEv9haMXwpHiPZUyArG3ux,Z82diNu7RlDybXFqVrvo,gCJprIs2wUzfcNhtxv = uoA1SsdxjlhEkX5eivf(kk4bAafDCZm7XQJis0PBqp1Weul)
					if gCJprIs2wUzfcNhtxv: kk4bAafDCZm7XQJis0PBqp1Weul = gCJprIs2wUzfcNhtxv[f4fTutDOEwUeIoPLRQ]
					else: kk4bAafDCZm7XQJis0PBqp1Weul = nbOFVEDkpT4BIR7Qq82yPmHeJU
				if not kk4bAafDCZm7XQJis0PBqp1Weul: yi6wOauQ3Sb1JUBt4 = 'unresolved'
				else: yi6wOauQ3Sb1JUBt4 = brh5aWRxQzn6YL8UDNOyK9SFGo(kk4bAafDCZm7XQJis0PBqp1Weul,source,type)
			if yi6wOauQ3Sb1JUBt4 in ['playing','testing','canceled_2nd_menu'] or len(lPpY5fw3tOBcEye91Caun2FQZ)==1: break
			elif yi6wOauQ3Sb1JUBt4 in ['failed','timeout','tried']: break
			else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','الملف لم يعمل جرب ملف غيره')
	else:
		yi6wOauQ3Sb1JUBt4 = 'unresolved'
		if JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6): yi6wOauQ3Sb1JUBt4 = brh5aWRxQzn6YL8UDNOyK9SFGo(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,type)
	return yi6wOauQ3Sb1JUBt4,uusxjPSpV5c,lPpY5fw3tOBcEye91Caun2FQZ
def GZXAWoIHDCisP(url,source):
	plSscrVjkRviPwm,Ft1mMA8RKoibjZe,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF = url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if '?named=' in url:
		plSscrVjkRviPwm,Ft1mMA8RKoibjZe = url.split('?named=',vkIa3ijEQVsJGdWOXwK7bnue9ADR)
		Ft1mMA8RKoibjZe = Ft1mMA8RKoibjZe+'__'+'__'+'__'+'__'+'__'
		xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF,q1S5R0VxsyPwtMkemY7rGdO, = Ft1mMA8RKoibjZe.split('__')[:6]
	if not uTKGhcXEIpmDf: uTKGhcXEIpmDf = '0'
	else: uTKGhcXEIpmDf = uTKGhcXEIpmDf.replace('p',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(S3X6GcaiExOPtb,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	plSscrVjkRviPwm = plSscrVjkRviPwm.strip('?').strip('/').strip('&')
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,'host')
	if xbfwC5hkXLvsJa8PReOS9AyU1z: BBCKhDfJqt = xbfwC5hkXLvsJa8PReOS9AyU1z
	else: BBCKhDfJqt = RWZpkDLtY5Eyb46029MvAKmqBQd8o
	BBCKhDfJqt = Qi32bRtN18qvyWmaO7YKow9cXs(BBCKhDfJqt,'name')
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('مباشر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('سيرفر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ال ',S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	Ft1mMA8RKoibjZe = Ft1mMA8RKoibjZe.replace('مباشر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('سيرفر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ال ',S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	BBCKhDfJqt = BBCKhDfJqt.replace('مباشر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('سيرفر',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ال ',S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	return plSscrVjkRviPwm,Ft1mMA8RKoibjZe,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF
def cRM9YqAt1Blibr3PCQoxvdah(url,source):
	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,lc6PgsYTOqfkdMnvA1U,wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn,DbpBKurLYhF4OCtUdRc6anEgA03Tx,ImzBe5xREiC6jgfY8yd,Tks3rDNUeEqh6 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,None,None,None,None,None
	plSscrVjkRviPwm,Ft1mMA8RKoibjZe,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF = GZXAWoIHDCisP(url,source)
	if '?named=' in url:
		if   type=='embed': type = S3X6GcaiExOPtb+'مفضل'
		elif type=='watch': type = S3X6GcaiExOPtb+'%مشاهدة'
		elif type=='both': type = S3X6GcaiExOPtb+'%%مشاهدة وتحميل'
		elif type=='download': type = S3X6GcaiExOPtb+'%%%تحميل'
		elif type==nbOFVEDkpT4BIR7Qq82yPmHeJU: type = S3X6GcaiExOPtb+'%%%%'
		if D63UZqx2XBgrtbje!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
			if 'mp4' not in D63UZqx2XBgrtbje: D63UZqx2XBgrtbje = '%'+D63UZqx2XBgrtbje
			D63UZqx2XBgrtbje = S3X6GcaiExOPtb+D63UZqx2XBgrtbje
		if uTKGhcXEIpmDf!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
			uTKGhcXEIpmDf = '%%%%%%%%%'+uTKGhcXEIpmDf
			uTKGhcXEIpmDf = S3X6GcaiExOPtb+uTKGhcXEIpmDf[-9:]
	if   'AKOAM'		in source: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'AKWAM'		in source: lc6PgsYTOqfkdMnvA1U	= 'akwam'
	elif 'katkoute'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'photos.app.g'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'arabseed'		in source: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'alarab'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'fasel'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 't7meel'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'movs4u'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'myegyvip'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'fajer'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'فجر'			in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= 'fajer'
	elif 'فلسطين'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= 'palestine'
	elif 'gdrive'		in plSscrVjkRviPwm:   lc6PgsYTOqfkdMnvA1U	= 'google'
	elif 'mycima'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'wecima'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'cimanow'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'newcima'		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'dailymotion'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'bokra'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'tvfun'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'tvksa'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'anavidz'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'shoofpro'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'shahid4u'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'shahed4u'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'cima4u'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'egynow'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'halacima'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'cimaabdo'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'redmodx'	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'redmodx'
	elif 'youtu'	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'youtube'
	elif 'y2u.be'	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'youtube'
	elif 'egy-best.net'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif 'd.egybest.d'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'egybestvip'
	elif 'egy.best'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'egybest1'
	elif 'egybest'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'egybest3'
	elif 'moshahda'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'moshahda'
	elif 'facultybooks'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'facultybooks'
	elif 'inflam.cc'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'inflam'
	elif 'buzzvrl'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= 'buzzvrl'
	elif 'arabloads'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'arabloads'
	elif 'archive'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'archive'
	elif 'catch.is'	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'catch'
	elif 'filerio'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'filerio'
	elif 'vidbm'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'vidbm'
	elif 'vidhd'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'myvid'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'myviid'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif 'videobin'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'videobin'
	elif 'govid'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'govid'
	elif 'liivideo' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'liivideo'
	elif 'mp4upload'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'mp4upload'
	elif 'publicvideo'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'publicvideo'
	elif 'rapidvideo' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'rapidvideo'
	elif 'top4top'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'top4top'
	elif 'upp' 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'upbom'
	elif 'upb' 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'upbom'
	elif 'uqload' 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'uqload'
	elif 'vcstream' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'vcstream'
	elif 'vidbob'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'vidbob'
	elif 'vidoza' 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'vidoza'
	elif 'watchvideo' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'watchvideo'
	elif 'wintv.live'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'wintv.live'
	elif 'zippyshare'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'zippyshare'
	elif 'hd-cdn'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= 'hd-cdn'
	if   lc6PgsYTOqfkdMnvA1U:	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = 'خاص',lc6PgsYTOqfkdMnvA1U
	elif ImzBe5xREiC6jgfY8yd:		OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = '%محدد',ImzBe5xREiC6jgfY8yd
	elif wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn:		OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = '%%عام معروف',wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn
	elif DbpBKurLYhF4OCtUdRc6anEgA03Tx:	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = '%%%عام خارجي',DbpBKurLYhF4OCtUdRc6anEgA03Tx
	elif Tks3rDNUeEqh6:	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = '%%%%عام خارجي',BBCKhDfJqt
	else:			OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = '%%%%%عام مجهول',BBCKhDfJqt
	return OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf
def iXgJUrjoMmF8hzs(url,source):
	plSscrVjkRviPwm,ImzBe5xREiC6jgfY8yd,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF = GZXAWoIHDCisP(url,source)
	if   'AKOAM'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Pl9syVGTF0(plSscrVjkRviPwm,xbfwC5hkXLvsJa8PReOS9AyU1z)
	elif 'AKWAM'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Hn1ehdUPB2(plSscrVjkRviPwm,type,uTKGhcXEIpmDf)
	elif 'FASELHD1'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = STvH5VK2LM(plSscrVjkRviPwm)
	elif 'YOUTUBE'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(plSscrVjkRviPwm)
	elif 'youtu'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(plSscrVjkRviPwm)
	elif 'y2u.be'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(plSscrVjkRviPwm)
	elif 'CIMA4U'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = ddhk8UY93x(plSscrVjkRviPwm)
	elif 'CIMACLUB'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hXfZLEF01s(plSscrVjkRviPwm)
	elif 'ARABSEED'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = cczNkUM8e6(plSscrVjkRviPwm)
	elif 'CIMAABDO'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = TTfGtcnHWg(plSscrVjkRviPwm)
	elif 'SHOFHA'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = S5S2A0HuKB(plSscrVjkRviPwm)
	elif 'EGYBEST1'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = O6kUi5MdYE(plSscrVjkRviPwm,JygZr6tXVAOGqPoF)
	elif 'ALMSTBA'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = HHs8Sbglyo(plSscrVjkRviPwm)
	elif 'LAROZA'		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = rxPoLEUGuR(plSscrVjkRviPwm)
	elif 'katkoute'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = bjdzha45nm(plSscrVjkRviPwm)
	elif 'akoam.cam'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = NC5BwOzQK0(plSscrVjkRviPwm)
	elif 'alarab'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Fs5NWnViClMK8(plSscrVjkRviPwm)
	elif 'shahid4u'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = v1skFBGlrX(plSscrVjkRviPwm)
	elif 'shahed4u'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = v1skFBGlrX(plSscrVjkRviPwm)
	elif 'egynow'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = K8bGaEqlm7(plSscrVjkRviPwm)
	elif 'tvfun'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = JfVHmqYKhQ(plSscrVjkRviPwm)
	elif 'tvksa'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = JfVHmqYKhQ(plSscrVjkRviPwm)
	elif 'tv-f.com'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = JfVHmqYKhQ(plSscrVjkRviPwm)
	elif 'halacima'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = bVgMzdZK7e(plSscrVjkRviPwm)
	elif 'shoofpro'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = vfJn9cWZFU(plSscrVjkRviPwm)
	elif 'myegyvip'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = xxPROgUl28WZ(plSscrVjkRviPwm)
	elif 'vs4u'			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = kDOBzqPZK3(plSscrVjkRviPwm)
	elif 'fajer'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WVBqhxkTJo(plSscrVjkRviPwm)
	elif 'cimanow'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nIEpzfZOeA(plSscrVjkRviPwm)
	elif 'newcima'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nIEpzfZOeA(plSscrVjkRviPwm)
	elif 'cima-light'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = eCcV9bE5Xv(plSscrVjkRviPwm)
	elif 'cimalight'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = eCcV9bE5Xv(plSscrVjkRviPwm)
	elif 'mycima'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = mJhnvlc9Rr(plSscrVjkRviPwm)
	elif 'wecima'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = zzhfIeX30wJVOH4qdQutYWD27(plSscrVjkRviPwm)
	elif 'bokra'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = FO9Pcsk5Xz(plSscrVjkRviPwm)
	elif 'dailymotion'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = d7aRis2qhk(plSscrVjkRviPwm)
	elif 'arblionz'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = czHXgtQlrJ(plSscrVjkRviPwm)
	elif 'egy-best.net'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = IcsWHablxw(plSscrVjkRviPwm)
	elif 'd.egybest.d'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	elif 'egybest'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Njvc8kFO4M(plSscrVjkRviPwm)
	elif 'series4watch'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = vID5SVuoAQ(plSscrVjkRviPwm)
	elif 'upbam' 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	if uusxjPSpV5c and uusxjPSpV5c!='EXIT_ALL_RESOLVERS': uusxjPSpV5c = 'Failed:  '+uusxjPSpV5c
	return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Krd8B5Qe2R7Li4qHnJOb1wSEUGVDT(uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ):
	bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = [],[]
	for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in zip(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ):
		if JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
			bdW70uQAIF.append(title)
			rU02bCJFWZDfVuhtMgBOyQi5P.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if not rU02bCJFWZDfVuhtMgBOyQi5P and not uusxjPSpV5c: uusxjPSpV5c = 'Failed'
	return uusxjPSpV5c,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P
def i0RIJo5SetVpOGdAyUbQ4v9NxnB3(zGcM56Ki1lfB8TZPtVHeXb,url,source,UUfw8Ld24pDl5xbHRhe):
	global nPI56Ug8wj9My0fDscBETLHzAoXN,hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz
	mvBYgfPuOD6xM27TpNnk3da14AeZb = []
	yUSCo6OPuT31Y8t = ('Timeout',[],[])
	hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe],WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe],SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe],UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe] = yUSCo6OPuT31Y8t,yUSCo6OPuT31Y8t,yUSCo6OPuT31Y8t,yUSCo6OPuT31Y8t
	ssMgjb7iFQ8HqDOEZ = [Y8YkuLrp9Gq,kunVGaU9Wt1iFsEv0qjLlomw,K6nUQo2kAX43JiLfZcph1Ga8q,z8EstRl3DLSmTwG4UW972O]
	if 'frdl' in url: ssMgjb7iFQ8HqDOEZ = [Y8YkuLrp9Gq,kunVGaU9Wt1iFsEv0qjLlomw,z8EstRl3DLSmTwG4UW972O]
	for Wgs5zmUlfnGTwjFNAPK in ssMgjb7iFQ8HqDOEZ:
		nOYqDV1m3xQ2HB9zdJL4 = eb6R0h1Fjl.Thread(target=Wgs5zmUlfnGTwjFNAPK,args=(url,source,UUfw8Ld24pDl5xbHRhe))
		mvBYgfPuOD6xM27TpNnk3da14AeZb.append(nOYqDV1m3xQ2HB9zdJL4)
		nOYqDV1m3xQ2HB9zdJL4.start()
		lQMuw1PvVpAk.sleep(1)
	timeout,step = 30,QQSugEIn2mTCpRsfcaJHhPdAWzylM
	for yUSCo6OPuT31Y8t in range(timeout//step):
		if hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]=='EXIT_ALL_RESOLVERS' or (not hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]): break
		if WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]=='EXIT_ALL_RESOLVERS' or (not WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]): break
		if SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]=='EXIT_ALL_RESOLVERS' or (not SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]): break
		if UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]=='EXIT_ALL_RESOLVERS' or (not UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]): break
		lQMuw1PvVpAk.sleep(step)
	for nOYqDV1m3xQ2HB9zdJL4 in mvBYgfPuOD6xM27TpNnk3da14AeZb: nOYqDV1m3xQ2HB9zdJL4.join(1)
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = 'EXTERNAL_RESOLVER_2'
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c=='EXIT_ALL_RESOLVERS' or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += '\nResolver 2:  '+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:80]
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = 'EXTERNAL_RESOLVER_3'
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c=='EXIT_ALL_RESOLVERS' or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += '\nResolver 3:  '+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:80]
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = 'EXTERNAL_RESOLVER_4'
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c=='EXIT_ALL_RESOLVERS' or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += '\nResolver 4:  '+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:80]
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = 'EXTERNAL_RESOLVER_5'
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c=='EXIT_ALL_RESOLVERS' or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += '\nResolver 5:  '+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:80]
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Y8YkuLrp9Gq(url,source,UUfw8Ld24pDl5xbHRhe):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'name')
	lPpY5fw3tOBcEye91Caun2FQZ = []
	if 'dailymotion'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = d7aRis2qhk(url)
	elif 'googleuserco' in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WbGIRfZTSKJLQ13cjXUqMFwrYyV68H(url)
	elif 'youtu'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(url)
	elif 'y2u.be'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(url)
	elif 'photos.app.g'	in url   : uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = OAKUxNEVDSguzfQ(url)
	elif 'moshahda'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = uoA1SsdxjlhEkX5eivf(url)
	elif 'faselhd'		in url   : uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = STvH5VK2LM(url)
	elif 'arabloads'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = znSbGIkNEJ7ZoVlFc36KWfr4(url)
	elif 'archive'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = YTbE8gRUZxMFfvL2CG(url)
	elif 'buzzvrl'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = W2VX5ICc6PhxfLMldDroGANH8g(url)
	elif 'e5tsar'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Tar1Wd7S2PUQpA0lmGCObunJLzsI(url)
	elif 'facultybooks'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = OFqBIv3fPQwKy2MCa90xhi(url)
	elif 'inflam.cc'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = OFqBIv3fPQwKy2MCa90xhi(url)
	elif 'upbam' 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	elif 'liivideo' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hySV345z0gvKfHxpjEPksT2(url)
	elif 'mp4upload'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = eh8ypgHQNvCFilYd9SsIDU1qV(url)
	elif 'rapidvideo' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = X8XUbv2VaP6f1S(url)
	elif 'top4top'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = H2cJulsEhx35e(url)
	elif 'upb' 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = RREam6IVLoCudeXDU1Aw(url)
	elif 'upp' 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = RREam6IVLoCudeXDU1Aw(url)
	elif 'uqload' 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Q8GvDRzUA3NXig0oJyEHStduYxqLP(url)
	elif 'vcstream' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = o6gsJ7VMy0FTQePUiGCwK5L9t4c2EH(url)
	elif 'vidbob'		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = PA3MXtUNpdknBTScuH16emlQW(url)
	elif 'vidoza' 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = XsE0MzVUwhTZ62Py(url)
	elif 'watchvideo' 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = ZjK0JomnMz2VhQ4Ce31(url)
	elif 'wintv.live'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hwL6eBCfEiJr0gm7FlI(url)
	elif 'zippyshare'	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = sRJ3YdvjMGkNV5ECngye(url)
	else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	global hhvF5yW4kQ1dxCLm83BfATlZ
	if uusxjPSpV5c and uusxjPSpV5c!='EXIT_ALL_RESOLVERS': uusxjPSpV5c = 'Failed:  '
	hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe] = uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return
def kunVGaU9Wt1iFsEv0qjLlomw(url,source,UUfw8Ld24pDl5xbHRhe):
	global WywD1Y9fE4dOtLFZxgGJ6
	if 'youtube' in url:
		WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe] = 'Failed:  Skipped',[],[]
		return
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	if JoEms64VZ1ldaf9NYBgcKCFL(url): uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	if not lPpY5fw3tOBcEye91Caun2FQZ: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = TlobMXNLteYc6vzU0gd7I(url)
	if not lPpY5fw3tOBcEye91Caun2FQZ: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WY71asuKNIFy3hJbotx2TCMXU(url)
	if not lPpY5fw3tOBcEye91Caun2FQZ:
		if uusxjPSpV5c=='EXIT_ALL_RESOLVERS': uusxjPSpV5c = nbOFVEDkpT4BIR7Qq82yPmHeJU
		WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe] = 'Failed:  '+uusxjPSpV5c,[],[]
		return
	WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe] = uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return
def K6nUQo2kAX43JiLfZcph1Ga8q(url,source,UUfw8Ld24pDl5xbHRhe):
	vf9s4ClmTE08AGndQV = nbOFVEDkpT4BIR7Qq82yPmHeJU
	bPFto2wZdNYrClgBIEv60DJAzu = SmbNGskjMx
	try:
		import resolveurl as swijhlkSazHdyePGnoX2Iq
		bPFto2wZdNYrClgBIEv60DJAzu = swijhlkSazHdyePGnoX2Iq.resolve(url)
	except Exception as pioIsrM6uymWHJRbhOYv: vf9s4ClmTE08AGndQV = str(pioIsrM6uymWHJRbhOYv)
	global SSaiGHeLq7KwAI4UTQJ
	if not bPFto2wZdNYrClgBIEv60DJAzu:
		if vf9s4ClmTE08AGndQV==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
			if vf9s4ClmTE08AGndQV!='NoneType: None\n': Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
		uusxjPSpV5c = vf9s4ClmTE08AGndQV.splitlines()[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe] = 'Failed:  '+uusxjPSpV5c,[],[]
		return
	SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe] = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[bPFto2wZdNYrClgBIEv60DJAzu]
	return
def z8EstRl3DLSmTwG4UW972O(url,source,UUfw8Ld24pDl5xbHRhe):
	vf9s4ClmTE08AGndQV = nbOFVEDkpT4BIR7Qq82yPmHeJU
	bPFto2wZdNYrClgBIEv60DJAzu = SmbNGskjMx
	try:
		import yt_dlp as MJ2QKiXw8V
		adSM4bNnpjq8ButTE93 = MJ2QKiXw8V.YoutubeDL({'no_color': Ag9l6cw3EBqP8HsQuGMizfOtr4})
		bPFto2wZdNYrClgBIEv60DJAzu = adSM4bNnpjq8ButTE93.extract_info(url,download=SmbNGskjMx)
	except Exception as pioIsrM6uymWHJRbhOYv: vf9s4ClmTE08AGndQV = str(pioIsrM6uymWHJRbhOYv)
	global UmRopiJqVk9ljYde2Agz
	if not bPFto2wZdNYrClgBIEv60DJAzu or 'formats' not in list(bPFto2wZdNYrClgBIEv60DJAzu.keys()):
		if vf9s4ClmTE08AGndQV==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
			if vf9s4ClmTE08AGndQV!='NoneType: None\n': Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
		uusxjPSpV5c = vf9s4ClmTE08AGndQV.splitlines()[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe] = 'Failed:  '+uusxjPSpV5c,[],[]
	else:
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in bPFto2wZdNYrClgBIEv60DJAzu['formats']:
			bbKoeBcirVfzwAqZdQUFDSX.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6['format'])
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6['url'])
		UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe] = nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return
def TlobMXNLteYc6vzU0gd7I(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,'RESOLVERS-REDIRECT_URL-1st')
	headers = cnPhVmgFxA.headers
	if 'Location' in list(headers.keys()):
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
		if JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6): return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'Failed:  ',[],[]
def wqGRSp8bWyjKmgoM4iT(oOkVKhLScA2xdJ05lCRPgN):
	if 'list' in str(type(oOkVKhLScA2xdJ05lCRPgN)):
		rU02bCJFWZDfVuhtMgBOyQi5P = []
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in oOkVKhLScA2xdJ05lCRPgN:
			if 'str' in str(type(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			rU02bCJFWZDfVuhtMgBOyQi5P.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else: rU02bCJFWZDfVuhtMgBOyQi5P = oOkVKhLScA2xdJ05lCRPgN.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
	return rU02bCJFWZDfVuhtMgBOyQi5P
def IWXqZsVg1r5K3CvDb8kyUGcBfM(gCJprIs2wUzfcNhtxv,source):
	GNWtbMyP30avIc6Vu = mmfpkVtUDjaq86eAuFzE0oxP
	data = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SERVERS',gCJprIs2wUzfcNhtxv)
	if data:
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = list(zip(*data))
		return bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,cvwn012JOtHdFbX = [],[],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in gCJprIs2wUzfcNhtxv:
		if '//' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf = cRM9YqAt1Blibr3PCQoxvdah(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source)
		uTKGhcXEIpmDf = ScntgdOZCY74vNpXeW5jh8i.findall('\d+',uTKGhcXEIpmDf,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if uTKGhcXEIpmDf: uTKGhcXEIpmDf = int(uTKGhcXEIpmDf[f4fTutDOEwUeIoPLRQ])
		else: uTKGhcXEIpmDf = f4fTutDOEwUeIoPLRQ
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
		cvwn012JOtHdFbX.append([OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o])
	if cvwn012JOtHdFbX:
		MDSBHhtupP3RUl1mGxOnfqF4 = sorted(cvwn012JOtHdFbX,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: (key[WtDrnpJmwQ37Z2Ae68hu4BY5M1],key[f4fTutDOEwUeIoPLRQ],key[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb],key[QQSugEIn2mTCpRsfcaJHhPdAWzylM],key[vkIa3ijEQVsJGdWOXwK7bnue9ADR],key[5],key[6]))
		vdYMP3fDSnxzeEgXmqpcua,cSjkilgqAFYw7UmP = [],[]
		for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in MDSBHhtupP3RUl1mGxOnfqF4:
			OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U
			if 'مفضل' in type:
				cSjkilgqAFYw7UmP.append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
				continue
			if EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U not in vdYMP3fDSnxzeEgXmqpcua: vdYMP3fDSnxzeEgXmqpcua.append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
		vdYMP3fDSnxzeEgXmqpcua = cSjkilgqAFYw7UmP+vdYMP3fDSnxzeEgXmqpcua
		wDIU0SN9GBtzZPoihYnv2xjqQC = f4fTutDOEwUeIoPLRQ
		for OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,type,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o in vdYMP3fDSnxzeEgXmqpcua:
			uTKGhcXEIpmDf = str(uTKGhcXEIpmDf) if uTKGhcXEIpmDf else nbOFVEDkpT4BIR7Qq82yPmHeJU
			title = 'سيرفر'+S3X6GcaiExOPtb+type+S3X6GcaiExOPtb+OBmo4zTHf6knjh8Z+S3X6GcaiExOPtb+uTKGhcXEIpmDf+S3X6GcaiExOPtb+D63UZqx2XBgrtbje+S3X6GcaiExOPtb+xbfwC5hkXLvsJa8PReOS9AyU1z
			if RWZpkDLtY5Eyb46029MvAKmqBQd8o not in title: title = title+S3X6GcaiExOPtb+RWZpkDLtY5Eyb46029MvAKmqBQd8o
			title = title.replace('%',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
			wDIU0SN9GBtzZPoihYnv2xjqQC += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			title = str(wDIU0SN9GBtzZPoihYnv2xjqQC)+'. '+title
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in lPpY5fw3tOBcEye91Caun2FQZ:
				bbKoeBcirVfzwAqZdQUFDSX.append(title)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if lPpY5fw3tOBcEye91Caun2FQZ:
			data = list(zip(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ))
			if data: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SERVERS',gCJprIs2wUzfcNhtxv,data,GNWtbMyP30avIc6Vu)
	return bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Fs5NWnViClMK8(url):
	if '.m3u8' in url:
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = mmAWFnZUkQ3HowdxRtCN9(url)
		if lPpY5fw3tOBcEye91Caun2FQZ: return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
		return 'Error: Resolver Failed M3U8',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def bjdzha45nm(url):
	NWtqFg91ZSKinvIwAc,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU = [],[]
	if '/videos.mp4?vid=' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-KATKOUTE-1st')
		if 'Location' in cnPhVmgFxA.headers:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
			ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o)
	elif 'katkoute.com' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-KATKOUTE-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		LITxrWQFSP = ScntgdOZCY74vNpXeW5jh8i.findall('(eval\(function\(p,a,c,k,e,d\).*?\)\)).</script>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if LITxrWQFSP:
			LITxrWQFSP = LITxrWQFSP[f4fTutDOEwUeIoPLRQ]
			zq8hVp3J6dsvUN94FwcEPfLkCtM = oWMSrt64vnzZAJlBmf0Y7cDujLxVsb(LITxrWQFSP)
			pLhwC75ZXF0WgyDE = ScntgdOZCY74vNpXeW5jh8i.findall('sources:(\[.*?\]),',zq8hVp3J6dsvUN94FwcEPfLkCtM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if pLhwC75ZXF0WgyDE:
				pLhwC75ZXF0WgyDE = pLhwC75ZXF0WgyDE[f4fTutDOEwUeIoPLRQ]
				pLhwC75ZXF0WgyDE = dr1zfnatJxRHSF48jh0eODm5bGu('list',pLhwC75ZXF0WgyDE)
				for dict in pLhwC75ZXF0WgyDE:
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dict['file']
					uTKGhcXEIpmDf = dict['label']
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(uTKGhcXEIpmDf+S3X6GcaiExOPtb+RWZpkDLtY5Eyb46029MvAKmqBQd8o)
		elif 'Location' in cnPhVmgFxA.headers:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
			ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o)
		if '?url=https://photos.app.goo' in url:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.split('?url=')[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&')[f4fTutDOEwUeIoPLRQ]
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append('photos google')
	else:
		NWtqFg91ZSKinvIwAc.append(url)
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'name')
		ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o)
	if not NWtqFg91ZSKinvIwAc: return 'Error: Resolver Failed KATKOUTE',[],[]
	elif len(NWtqFg91ZSKinvIwAc)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[f4fTutDOEwUeIoPLRQ]
	else:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('أختر الملف المناسب',ifOk5xt1uHRJrTGFB7zZaeKIs6bqU)
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[bCiGxXzDkH]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def WbGIRfZTSKJLQ13cjXUqMFwrYyV68H(url):
	headers = {'User-Agent':'Kodi/'+str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)}
	for HT4fGXqv8hEcKsJ in range(50):
		lQMuw1PvVpAk.sleep(0.100)
		cnPhVmgFxA = MOpDGnv1WA3hTxeE2R('GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-GOOGLEUSERCONTENT-1st')
		if 'Location' in list(cnPhVmgFxA.headers.keys()):
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'|User-Agent='+headers['User-Agent']
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
		if cnPhVmgFxA.code!=429: break
	return 'Error: Resolver Failed GOOGLEUSERCONTENT',[],[]
def OAKUxNEVDSguzfQ(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-PHOTOSGOOGLE-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"(https://video-downloads.*?)",.*?,.*?,(.*?),',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[uTKGhcXEIpmDf],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'Error: Resolver Failed PHOTOSGOOGLE',[],[]
def CXPRLeTGkJ(url):
	if '/weepis/' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-WECIMA2-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<quality>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		else: return 'Error: Resolver Failed WECIMA2',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def HHs8Sbglyo(url):
	if 'serv=' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ALMSTBA-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall("AlbaPlayerControl\('(.*?)'",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
				url = Y7goyGlxwNaP1XcWU6e.b64decode(url)
				if IZhXMprxvAHqBEFkg0: url = url.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			else: return 'Error: Resolver Failed ALMSTBA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def STvH5VK2LM(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-FASELHD1-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	UTvsQb4HpCP3Aeo2wDZG7X5V = NtZWe3LpRgnl29Vw(UTvsQb4HpCP3Aeo2wDZG7X5V)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"file":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]]
	return 'Error: Resolver Failed FASELHD1',[],[]
def rxPoLEUGuR(url):
	if len(url)>200:
		url = url.strip('/')+'/'
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-LAROZA-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		if f4fTutDOEwUeIoPLRQ and 'function(h,u,n,t,e,r)' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"loader"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
				eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<script>var(.*?)</script',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if eXpgPIbRv2ZMGwjm5:
					G4JHzTEp61 = VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(eXpgPIbRv2ZMGwjm5[0])
		elif len(UTvsQb4HpCP3Aeo2wDZG7X5V)<400: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = UTvsQb4HpCP3Aeo2wDZG7X5V
		else: return 'Error: Resolver Failed LAROZA',[],[]
		return '',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def S5S2A0HuKB(url):
	if '/down.php' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-SHOFHA-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('video-wrapper.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def ddhk8UY93x(url):
	if 'server.php' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMA4U-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		if 'http' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
		return 'Error: Resolver Failed CIMA4U',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def K8bGaEqlm7(url):
	plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYNOW-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'Error: Resolver Failed EGYNOW',[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def vfJn9cWZFU(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-SHOOFPRO-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'Error: Resolver Failed SHOOFPRO',[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def bVgMzdZK7e(url):
	plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-HALACIMA-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('''<iframe src=["'](.*?)["']''',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'Error: Resolver Failed HALACIMA',[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def TTfGtcnHWg(url):
	f7Je8XzEqNpgHL9m4OURdAQ1,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = url,[],[]
	if '/ajax/' in url:
		plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMAABDO-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall('''<iframe.*?src=["'](.*?)["']''',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if DWeKu2Gsi84PbUEfhMwVNjloqg: f7Je8XzEqNpgHL9m4OURdAQ1 = DWeKu2Gsi84PbUEfhMwVNjloqg[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[f7Je8XzEqNpgHL9m4OURdAQ1]
def JfVHmqYKhQ(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-TVFUN-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	OwDu7J6kbX9Qhlxid0SqLPZUW43 = ScntgdOZCY74vNpXeW5jh8i.findall("var fserv =.*?'(.*?)'",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if OwDu7J6kbX9Qhlxid0SqLPZUW43:
		OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43[f4fTutDOEwUeIoPLRQ][2:]
		OwDu7J6kbX9Qhlxid0SqLPZUW43 = Y7goyGlxwNaP1XcWU6e.b64decode(OwDu7J6kbX9Qhlxid0SqLPZUW43)
		if IZhXMprxvAHqBEFkg0: OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',OwDu7J6kbX9Qhlxid0SqLPZUW43,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'Error: Resolver Failed TVFUN',[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def xxPROgUl28WZ(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MYEGYVIP-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('class="col-sm-12".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'Error: Resolver Failed MYEGYVIP',[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def d7aRis2qhk(url):
	id = url.split('/')[-1]
	if '/embed' in url: url = url.replace('/embed',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	url = url.replace('.com/','.com/player/metadata/')
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-DAILYMOTION-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	uusxjPSpV5c = 'Error: Resolver Failed DAILYMOTION'
	pioIsrM6uymWHJRbhOYv = ScntgdOZCY74vNpXeW5jh8i.findall('"error".*?"messagee":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if pioIsrM6uymWHJRbhOYv: uusxjPSpV5c = pioIsrM6uymWHJRbhOYv[f4fTutDOEwUeIoPLRQ]
	url = ScntgdOZCY74vNpXeW5jh8i.findall('x-mpegURL","url":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not url and uusxjPSpV5c:
		return uusxjPSpV5c,[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url[f4fTutDOEwUeIoPLRQ].replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	Z82diNu7RlDybXFqVrvo,gCJprIs2wUzfcNhtxv = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	G7GhXQ9sRNCw6OnpymLMFcI1ZkU = ScntgdOZCY74vNpXeW5jh8i.findall('"owner":\{"id":"(.*?)".*?"screenname":"(.*?)","url":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if G7GhXQ9sRNCw6OnpymLMFcI1ZkU: pp5MvZK9bFhDIJ6rYuizlgOA,cZfRJhSApvVbEH6k1jlqNnr5QdXC,UNogQA5qVyfilCkv4dP90pDLXm7M = G7GhXQ9sRNCw6OnpymLMFcI1ZkU[f4fTutDOEwUeIoPLRQ]
	else: pp5MvZK9bFhDIJ6rYuizlgOA,cZfRJhSApvVbEH6k1jlqNnr5QdXC,UNogQA5qVyfilCkv4dP90pDLXm7M = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	UNogQA5qVyfilCkv4dP90pDLXm7M = UNogQA5qVyfilCkv4dP90pDLXm7M.replace('\/','/')
	cZfRJhSApvVbEH6k1jlqNnr5QdXC = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(cZfRJhSApvVbEH6k1jlqNnr5QdXC)
	bbKoeBcirVfzwAqZdQUFDSX = [eMypvI8XqHjYU02anWD9gsSrkt+'OWNER:  '+cZfRJhSApvVbEH6k1jlqNnr5QdXC+c7gxFyUCGm]+Z82diNu7RlDybXFqVrvo
	lPpY5fw3tOBcEye91Caun2FQZ = [UNogQA5qVyfilCkv4dP90pDLXm7M]+gCJprIs2wUzfcNhtxv
	bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الملف المناسب: ('+str(len(lPpY5fw3tOBcEye91Caun2FQZ)-1)+' ملف)',bbKoeBcirVfzwAqZdQUFDSX)
	if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
	elif bCiGxXzDkH==f4fTutDOEwUeIoPLRQ:
		vBWiqzoKuAxkDFLdHZjm9JrUy4t0I = Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[f4fTutDOEwUeIoPLRQ]+'?type=folder&mode=402&url='+UNogQA5qVyfilCkv4dP90pDLXm7M+'&textt='+cZfRJhSApvVbEH6k1jlqNnr5QdXC
		RarSo2nTfwU0WEGK.executebuiltin("Container.Update("+vBWiqzoKuAxkDFLdHZjm9JrUy4t0I+")")
		return 'EXIT_ALL_RESOLVERS',[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 =  lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def FO9Pcsk5Xz(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BOKRA-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if '.json' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: url = ScntgdOZCY74vNpXeW5jh8i.findall('"src":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: url = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not url: return 'Error: Resolver Failed BOKRA',[],[]
	url = url[f4fTutDOEwUeIoPLRQ]
	if 'http' not in url: url = 'http:'+url
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def uoA1SsdxjlhEkX5eivf(url):
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	if 'op=download_orig' in url:
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOSHAHDA-1st')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('direct link.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[items[f4fTutDOEwUeIoPLRQ]]
		else:
			CtO9cFuULSm62PWToMlzN1 = ScntgdOZCY74vNpXeW5jh8i.findall('class="err">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if CtO9cFuULSm62PWToMlzN1:
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من الموقع الاصلي',CtO9cFuULSm62PWToMlzN1[f4fTutDOEwUeIoPLRQ])
				return 'Error: '+CtO9cFuULSm62PWToMlzN1[f4fTutDOEwUeIoPLRQ],[],[]
	else:
		Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'movizland'
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOSHAHDA-2nd')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('Form method="POST" action=\'(.*?)\'(.*?)div',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: return 'Error: Resolver Failed MOSHAHDA',[],[]
		f7Je8XzEqNpgHL9m4OURdAQ1 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ]
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		if '.rar' in G4JHzTEp61 or '.zip' in G4JHzTEp61: return 'Error: MOSHAHDA Not a video file',[],[]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('name="(.*?)".*?value="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = {}
		for xbfwC5hkXLvsJa8PReOS9AyU1z,XPL0O2VkI3w1C8enMaqi in items:
			iugaeRtZ5HFw7mJc9AdTbKlLV2[xbfwC5hkXLvsJa8PReOS9AyU1z] = XPL0O2VkI3w1C8enMaqi
		data = hS5pZyveLR0Ju4EksT2jQ9mrU(iugaeRtZ5HFw7mJc9AdTbKlLV2)
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,f7Je8XzEqNpgHL9m4OURdAQ1,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOSHAHDA-3rd')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('Download Video.*?get\(\'(.*?)\'.*?sources:(.*?)image:',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: return 'Error: Resolver Failed MOSHAHDA',[],[]
		download = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ]
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('file:"(.*?)"(,label:".*?"|)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,bbKoeBcirVfzwAqZdQUFDSX,dQS7hrjxHlAnZ14b,lPpY5fw3tOBcEye91Caun2FQZ,hljznvGk8csQf2ebuVUZy = [],[],[],[],[]
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if '.m3u8' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				lPpY5fw3tOBcEye91Caun2FQZ = lPpY5fw3tOBcEye91Caun2FQZ + dQS7hrjxHlAnZ14b
				if v4pVXJWMjUC6oaQ3DY7PqKTGOSZk[f4fTutDOEwUeIoPLRQ]=='-1': bbKoeBcirVfzwAqZdQUFDSX.append(' سيرفر خاص '+'m3u8 '+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y)
				else:
					for title in v4pVXJWMjUC6oaQ3DY7PqKTGOSZk:
						bbKoeBcirVfzwAqZdQUFDSX.append(' سيرفر خاص '+'m3u8 '+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y+S3X6GcaiExOPtb+title)
			else:
				title = title.replace(',label:"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				title = title.strip('"')
				title = ' سيرفر  خاص '+' mp4 '+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y+S3X6GcaiExOPtb+title
				bbKoeBcirVfzwAqZdQUFDSX.append(title)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http://moshahda.online' + download
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOSHAHDA-5th')
		items = ScntgdOZCY74vNpXeW5jh8i.findall("download_video\('(.*?)','(.*?)','(.*?)'.*?<td>(.*?),",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,EYMmnJAyxV,hash,loKjdNbfgBHGYITLaZiPJV in items:
			title = ' سيرفر تحميل خاص '+' mp4 '+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y+S3X6GcaiExOPtb+loKjdNbfgBHGYITLaZiPJV.split('x')[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http://moshahda.online/dl?op=download_orig&id='+id+'&mode='+EYMmnJAyxV+'&hash='+hash
			hljznvGk8csQf2ebuVUZy.append(loKjdNbfgBHGYITLaZiPJV)
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		hljznvGk8csQf2ebuVUZy = set(hljznvGk8csQf2ebuVUZy)
		bEZpumacn58,XX4ukCywIBmMH = [],[]
		for title in bbKoeBcirVfzwAqZdQUFDSX:
			wgS3zkYrvX5R4DQi = ScntgdOZCY74vNpXeW5jh8i.findall(" (\d*x|\d*)&&",title+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for loKjdNbfgBHGYITLaZiPJV in hljznvGk8csQf2ebuVUZy:
				if wgS3zkYrvX5R4DQi[f4fTutDOEwUeIoPLRQ] in loKjdNbfgBHGYITLaZiPJV:
					title = title.replace(wgS3zkYrvX5R4DQi[f4fTutDOEwUeIoPLRQ],loKjdNbfgBHGYITLaZiPJV.split('x')[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
			bEZpumacn58.append(title)
		for WoEZvMXa0K2suwgPl in range(len(lPpY5fw3tOBcEye91Caun2FQZ)):
			items = ScntgdOZCY74vNpXeW5jh8i.findall("&&(.*?)(\d*)&&",'&&'+bEZpumacn58[WoEZvMXa0K2suwgPl]+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			XX4ukCywIBmMH.append( [bEZpumacn58[WoEZvMXa0K2suwgPl],lPpY5fw3tOBcEye91Caun2FQZ[WoEZvMXa0K2suwgPl],items[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ],items[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]] )
		XX4ukCywIBmMH = sorted(XX4ukCywIBmMH, key=lambda BJou58vPwLqONbGtKTxsiASR1Cr: BJou58vPwLqONbGtKTxsiASR1Cr[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb], reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4)
		XX4ukCywIBmMH = sorted(XX4ukCywIBmMH, key=lambda BJou58vPwLqONbGtKTxsiASR1Cr: BJou58vPwLqONbGtKTxsiASR1Cr[QQSugEIn2mTCpRsfcaJHhPdAWzylM], reverse=SmbNGskjMx)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for WoEZvMXa0K2suwgPl in range(len(XX4ukCywIBmMH)):
			bbKoeBcirVfzwAqZdQUFDSX.append(XX4ukCywIBmMH[WoEZvMXa0K2suwgPl][f4fTutDOEwUeIoPLRQ])
			lPpY5fw3tOBcEye91Caun2FQZ.append(XX4ukCywIBmMH[WoEZvMXa0K2suwgPl][vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return 'Error: Resolver Failed MOSHAHDA',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Tar1Wd7S2PUQpA0lmGCObunJLzsI(url):
	LCjugSrWIBPDyFb4X1o9fAM = url.split('?')
	plSscrVjkRviPwm = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-E5TSAR-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('Please wait.*?href=\'(.*?)\'',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	url = items[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def W2VX5ICc6PhxfLMldDroGANH8g(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-FACULTYBOOKS-1st')
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('redirect_url.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]]
	else: return 'Error: Resolver Failed BUZZVRL',[],[]
def OFqBIv3fPQwKy2MCa90xhi(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-FACULTYBOOKS-1st')
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('href","(htt.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]]
	else: return 'Error: Resolver Failed FACULTYBOOKS',[],[]
def WVBqhxkTJo(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errno = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if '/wp-admin/' in url:
		plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-FAJERSHOW-2nd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		if fv4KNqjIBQT0UcHmlYSnrwOAWGV.startswith('http'): plSscrVjkRviPwm = fv4KNqjIBQT0UcHmlYSnrwOAWGV
		else:
			zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall('''src=['"](.*?)['"]''',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if zb2QIaL7Y4h9g8lSck:
				plSscrVjkRviPwm = zb2QIaL7Y4h9g8lSck[f4fTutDOEwUeIoPLRQ]
				zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall('source=(.*?)[&$]',plSscrVjkRviPwm,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if zb2QIaL7Y4h9g8lSck:
					plSscrVjkRviPwm = SxN0jnqr3LI(zb2QIaL7Y4h9g8lSck[f4fTutDOEwUeIoPLRQ])
					return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	elif '/links/' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-FAJERSHOW-1st')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		if 'Location' in list(cnPhVmgFxA.headers.keys()): plSscrVjkRviPwm = cnPhVmgFxA.headers['Location']
		else: plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('id="link".*?href="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
	if '/v/' in plSscrVjkRviPwm or '/f/' in plSscrVjkRviPwm:
		plSscrVjkRviPwm = plSscrVjkRviPwm.replace('/f/','/api/source/')
		plSscrVjkRviPwm = plSscrVjkRviPwm.replace('/v/','/api/source/')
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-FAJERSHOW-3rd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"file":"(.*?)","label":"(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				bbKoeBcirVfzwAqZdQUFDSX.append(title)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		else:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('"file":"(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[f4fTutDOEwUeIoPLRQ]
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				bbKoeBcirVfzwAqZdQUFDSX.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return 'Error: Resolver Failed FAJERSHOW',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def kDOBzqPZK3(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOVS4U-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errno = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 'player_embed.php' in url or '/embed/' in url:
		if 'player_embed.php' in url:
			plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
		else: plSscrVjkRviPwm = url
		if 'movs4u' not in plSscrVjkRviPwm: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOVS4U-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="player"(.*?)videojs',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<source src="(.*?)".*?label="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,NNntz8hA93kG6WqEDb1OUoeFm2fg in items:
				bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	elif 'main_player.php' in url:
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('url=(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MOVS4U-3rd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall('"file": "(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		zb2QIaL7Y4h9g8lSck = zb2QIaL7Y4h9g8lSck[f4fTutDOEwUeIoPLRQ]
		bbKoeBcirVfzwAqZdQUFDSX.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
		lPpY5fw3tOBcEye91Caun2FQZ.append(zb2QIaL7Y4h9g8lSck)
	elif 'download_link' in url:
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('<center><a href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
			return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return 'Error: Resolver Failed MOVS4U',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def hXfZLEF01s(url):
	if '?get=' in url:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.split('?get=',vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = Y7goyGlxwNaP1XcWU6e.b64decode(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if IZhXMprxvAHqBEFkg0: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.decode(zSafwK0sDXdMN5JReniIQmrZxp,'ignore')
		return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	website = sCSyOla9hrcE['CIMACLUB'][f4fTutDOEwUeIoPLRQ]
	headers = {'Referer':website}
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMACLUB-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('download=.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall("sources: \['(.*?)'",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall("file:'(.*?)'",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]+'|Referer='+website
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	if 'name="Xtoken"' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		wBetPUDiRjrOGgdLYWF0u49K1AQ = ScntgdOZCY74vNpXeW5jh8i.findall('name="Xtoken" content="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if wBetPUDiRjrOGgdLYWF0u49K1AQ:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = wBetPUDiRjrOGgdLYWF0u49K1AQ[f4fTutDOEwUeIoPLRQ]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = Y7goyGlxwNaP1XcWU6e.b64decode(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			if IZhXMprxvAHqBEFkg0: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.decode(zSafwK0sDXdMN5JReniIQmrZxp,'ignore')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('http.*?(http.*?),',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]+'|Referer='+website
				return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def O6kUi5MdYE(url,JygZr6tXVAOGqPoF):
	ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = [],[]
	if '/1/' in url:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.replace('/1/','/4/')
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-1st')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<video(.*?)</video>',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?size="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in NWtqFg91ZSKinvIwAc:
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o+BhmzEC6OGD7FXZig9Tp5A+uTKGhcXEIpmDf)
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
	elif '/d/' in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-2nd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe.*?src="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ].replace('/1/','/4/')
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-3rd')
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('class.*?href="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]]
	elif '/role/' in url:
		headers = {'Referer':JygZr6tXVAOGqPoF}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-4th')
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-5th')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = mknXS3i7th0LRWj2xaF4YgcpuzGE(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,UTvsQb4HpCP3Aeo2wDZG7X5V)
		return uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
	elif '/download/' in url:
		plSscrVjkRviPwm = url.replace('/download/','/script/')
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Referer':JygZr6tXVAOGqPoF}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-6th')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
			cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-7th')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			if 'Location' in list(cnPhVmgFxA.headers.keys()):
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
				cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST1-8th')
				UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
				uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = mknXS3i7th0LRWj2xaF4YgcpuzGE(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,UTvsQb4HpCP3Aeo2wDZG7X5V)
				if NWtqFg91ZSKinvIwAc: return uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
			elif '/embed.php?id=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('/embed.php?id=','/jwplayer.php?id=')
				return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def Njvc8kFO4M(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST3-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	data = ScntgdOZCY74vNpXeW5jh8i.findall('"action".*?value="(.*?)".*?value="(.*?)".*?value="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if data:
		sRdbohGut7qZyfOXJEDeQHcgKY,id,J0ztXV9EeMWdUoySsCZ2wnp6 = data[f4fTutDOEwUeIoPLRQ]
		data = 'op='+sRdbohGut7qZyfOXJEDeQHcgKY+'&id='+id+'&fname='+J0ztXV9EeMWdUoySsCZ2wnp6
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST3-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"referer" value="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def IcsWHablxw(url):
	headers = {'X-Requested-With':'XMLHttpRequest'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST4-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'Error: Resolver Failed EGYBEST1',[],[]
def haJBXMtW9Y(url):
	plSscrVjkRviPwm = url.split('?named=',vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ].strip('?').strip('/').strip('&')
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,items,zb2QIaL7Y4h9g8lSck = [],[],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	headers = { 'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-EGYBEST-1st')
	if 'Location' in list(cnPhVmgFxA.headers.keys()): zb2QIaL7Y4h9g8lSck = cnPhVmgFxA.headers['Location']
	if 'http' in zb2QIaL7Y4h9g8lSck:
		if '__watch' in url: zb2QIaL7Y4h9g8lSck = zb2QIaL7Y4h9g8lSck.replace('/f/','/v/')
		hNZCDv9ReVup = plSscrVjkRviPwm.split('?PHPSID=')[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		headers = { 'User-Agent':headers['User-Agent'] , 'Cookie':'PHPSID='+hNZCDv9ReVup }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST-PLAY-3rd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		if '/f/' in zb2QIaL7Y4h9g8lSck: items = ScntgdOZCY74vNpXeW5jh8i.findall('<h2>.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		elif '/v/' in zb2QIaL7Y4h9g8lSck: items = ScntgdOZCY74vNpXeW5jh8i.findall('id="video".*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items: return [],[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
		elif '<h1>404</h1>' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			return 'Error: سيرفر الفيديو فيه حجب ضد كودي ومصدره من الإنترنت الخاصة بك',[],[]
	else: return 'Error: Resolver Failed EGYBEST',[],[]
def vID5SVuoAQ(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('postid=(.*?)&serverid=(.*?)&&',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
	url = 'https://series4watch.net/ajaxCenter?_action=getserver&_post_id='+lShZiBC3zc7yrx+'&serverid='+g7EnObA021BoG9dwYky
	headers = { 'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU , 'X-Requested-With':'XMLHttpRequest' }
	plSscrVjkRviPwm = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-SERIES4WATCH-1st')
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def mJhnvlc9Rr(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Referer':RWZpkDLtY5Eyb46029MvAKmqBQd8o,'Accept-Encoding':'gzip, deflate'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MYCIMA-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('player.qualityselector(.*?)formats:',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('format: \'(\d.*?)\', src: "(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[f4fTutDOEwUeIoPLRQ]
		elif len(lPpY5fw3tOBcEye91Caun2FQZ)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr('أختر الملف المناسب', bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
			plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: plSscrVjkRviPwm = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
	if not plSscrVjkRviPwm: return 'Error: Resolver Failed MYCIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def zzhfIeX30wJVOH4qdQutYWD27(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Referer':RWZpkDLtY5Eyb46029MvAKmqBQd8o,'Accept-Encoding':'gzip, deflate'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-WECIMA-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('player.qualityselector(.*?)formats:',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('format: \'(\d.*?)\', src: "(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[f4fTutDOEwUeIoPLRQ]
		elif len(lPpY5fw3tOBcEye91Caun2FQZ)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr('أختر الملف المناسب', bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
			plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	if not plSscrVjkRviPwm:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: plSscrVjkRviPwm = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
	if not plSscrVjkRviPwm: return 'Error: Resolver Failed WECIMA',[],[]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def NC5BwOzQK0(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	url,lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
	data = {'post_id':lShZiBC3zc7yrx,'server':g7EnObA021BoG9dwYky}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',url,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-AKOAMCAM-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('iframe src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def eCcV9bE5Xv(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMALIGHT-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'Error: Resolver Failed CIMALIGHT',[],[]
def aXsbM5p7he(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMACLUP-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<IFRAME SRC="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
	return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def nIEpzfZOeA(url):
	jqDXgyUVZ2 = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	if 'index=' in url:
		headers = {'Referer':jqDXgyUVZ2}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMANOW-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
			if 'http' not in plSscrVjkRviPwm: plSscrVjkRviPwm = 'http:'+plSscrVjkRviPwm
			if 'cimanow' in plSscrVjkRviPwm:
				plSscrVjkRviPwm = plSscrVjkRviPwm.replace('https://','http://')
				cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMANOW-2nd')
				fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
				items = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)".*?size="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
				ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,'url')
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in reversed(items):
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ksHfTPuQMGB+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'|Referer='+ksHfTPuQMGB
					bbKoeBcirVfzwAqZdQUFDSX.append(uTKGhcXEIpmDf)
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
			else: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	plSscrVjkRviPwm = url+'|Referer='+jqDXgyUVZ2
	if 'http' not in plSscrVjkRviPwm: plSscrVjkRviPwm = 'http:'+plSscrVjkRviPwm
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def a3kMrZmR9JojtwAC7H6ePzs18Xuv(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	jqDXgyUVZ2 = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'url')
	if 'postid' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('(http.*?)\?postid=(.*?)&serverid=(.*?)&&',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		url,lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		data = {'id':lShZiBC3zc7yrx,'server':g7EnObA021BoG9dwYky}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',url,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMANOW-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('iframe src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
		if 'cimanow' in plSscrVjkRviPwm:
			headers = {'Referer':jqDXgyUVZ2,'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
			cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-CIMANOW-2nd')
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
			items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?size="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
			ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,'url')
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in reversed(items):
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ksHfTPuQMGB+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'|Referer='+ksHfTPuQMGB
				bbKoeBcirVfzwAqZdQUFDSX.append(uTKGhcXEIpmDf)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
		else: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	else:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'|Referer='+jqDXgyUVZ2
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def czHXgtQlrJ(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	if 'postid' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('postid=(.*?)&serverid=(.*?)&&',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		fi7k6GdJ5p30raYvIozqnZEmFVubjA = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'url')
		url = fi7k6GdJ5p30raYvIozqnZEmFVubjA+'/ajaxCenter?_action=getserver&_post_id='+lShZiBC3zc7yrx+'&serverid='+g7EnObA021BoG9dwYky
		headers = { 'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU , 'X-Requested-With':'XMLHttpRequest' }
		plSscrVjkRviPwm = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARBLIONZ-1st')
		plSscrVjkRviPwm = plSscrVjkRviPwm.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	elif '/redirect/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		HDYwF4bPdEQBy2lRhkisKfV9xaXr = f4fTutDOEwUeIoPLRQ
		while '/redirect/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and HDYwF4bPdEQBy2lRhkisKfV9xaXr<5:
			cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARBLIONZ-2nd')
			if 'Location' in list(cnPhVmgFxA.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
			HDYwF4bPdEQBy2lRhkisKfV9xaXr += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else: return 'Error: Resolver Failed ARBLIONZ',[],[]
def cczNkUM8e6(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	headers = {'Referer':RWZpkDLtY5Eyb46029MvAKmqBQd8o,'User-Agent':MdwGcQOsmlV6vKI73THrUY4()}
	if '/embed-' in url:
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARABSEED-2nd')
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ].replace('https','http')
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else:
		lHzwp04JAKfQ9v6 = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARABSEED-3rd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = lHzwp04JAKfQ9v6.content
		GcYwHSWoQ0Nq8KFfJDdvujZryM = headers.copy()
		if '_lnk_' in str(lHzwp04JAKfQ9v6.cookies):
			cookies = lHzwp04JAKfQ9v6.cookies
			GcYwHSWoQ0Nq8KFfJDdvujZryM['Cookie'] = SxN0jnqr3LI(hS5pZyveLR0Ju4EksT2jQ9mrU(cookies))
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('link.href = "(http.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ])+'&d=1'
			KXFGbQxMAgBRYh = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARABSEED-4th')
			UTvsQb4HpCP3Aeo2wDZG7X5V = KXFGbQxMAgBRYh.content
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('id="btn".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ])
				if 'mp4' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and '/d/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
				else: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'Error: Resolver Failed ARABSEED',[],[]
def v1skFBGlrX(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	if '_action=getserver' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		headers = {'X-Requested-With':'XMLHttpRequest'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-SHAHID4U-1st')
		url = cnPhVmgFxA.content
		if url: return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	else:
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('postid=(.*?)&serverid=(.*?)$',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if not LCjugSrWIBPDyFb4X1o9fAM: LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('_post_id=(.*?)&serverid=(.*?)$',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'url')
		url = RWZpkDLtY5Eyb46029MvAKmqBQd8o+'/wp-content/themes/theme/Ajaxat/Single/Server.php'
		data = {'id':lShZiBC3zc7yrx,'i':g7EnObA021BoG9dwYky}
		headers = {'X-Requested-With':'XMLHttpRequest','Referer':grwO1UeqkvQBf4tmz0jTx3lEKZWbF6}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-SHAHID4U-2nd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
			return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	return 'Error: Resolver Failed SHAHID4U',[],[]
def U1uEz7TJBG5DjY9I8FoNrXfax2k(jUu9KomxkPAGDftYcq5a6lySB7X28):
	aWiAjtGlKhXeH64Iy = llnG7jiQBYKhAeovbT.getSetting('av.akwam.verification')
	headers = {'Cookie':aWiAjtGlKhXeH64Iy} if aWiAjtGlKhXeH64Iy else nbOFVEDkpT4BIR7Qq82yPmHeJU
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',jUu9KomxkPAGDftYcq5a6lySB7X28,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-1st')
	XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
	zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0 = str(cnPhVmgFxA.headers)
	n3j1bdVU6vgqukC = zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0+XvREomOzBpM81LVstnFJheUScZ
	if '.mp4' in n3j1bdVU6vgqukC: qv5R2JduMmjoEIcKQ3kt7WgX = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else:
		e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa,ffiueHIMq6oQxRpyO1ShacVGL4Pg,xJEtoVD4TkyeuKOqvcQUi,kOB9buo8XJLfV,qv5R2JduMmjoEIcKQ3kt7WgX = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx
		captcha = ScntgdOZCY74vNpXeW5jh8i.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if captcha: xJEtoVD4TkyeuKOqvcQUi,kOB9buo8XJLfV = captcha[f4fTutDOEwUeIoPLRQ]
		YnULcJZeMbrEPRGNxl7dm0SQjF = sCSyOla9hrcE['PYTHON'][7]
		if f4fTutDOEwUeIoPLRQ:
			data = {'user':iidHGYjPEW4zU,'version':JeVILUu027qW,'url':jUu9KomxkPAGDftYcq5a6lySB7X28,'key':kOB9buo8XJLfV,'id':nbOFVEDkpT4BIR7Qq82yPmHeJU,'job':'geturls'}
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',YnULcJZeMbrEPRGNxl7dm0SQjF,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-2nd')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		UTvsQb4HpCP3Aeo2wDZG7X5V = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if UTvsQb4HpCP3Aeo2wDZG7X5V.startswith('URLS='):
			oOkVKhLScA2xdJ05lCRPgN = dr1zfnatJxRHSF48jh0eODm5bGu('list',UTvsQb4HpCP3Aeo2wDZG7X5V.split('URLS=',vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
			for s0tfc7T2hwBM in oOkVKhLScA2xdJ05lCRPgN:
				url = s0tfc7T2hwBM['url']
				nvEb1Jx3qZo8Vk7Dgih2 = s0tfc7T2hwBM['method']
				data = s0tfc7T2hwBM['data']
				headers = s0tfc7T2hwBM['headers']
				cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,nvEb1Jx3qZo8Vk7Dgih2,url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-3rd')
				XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
				if '.mp4' in XvREomOzBpM81LVstnFJheUScZ:
					qv5R2JduMmjoEIcKQ3kt7WgX = Ag9l6cw3EBqP8HsQuGMizfOtr4
					break
				zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0 = str(cnPhVmgFxA.headers)
				n3j1bdVU6vgqukC = zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0+XvREomOzBpM81LVstnFJheUScZ
				e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa = ScntgdOZCY74vNpXeW5jh8i.findall('(akwamVerification\w+).*?"(eyJ.*?)"',n3j1bdVU6vgqukC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				ffiueHIMq6oQxRpyO1ShacVGL4Pg = ScntgdOZCY74vNpXeW5jh8i.findall('recaptcha-token.*?"(03A.*?)"',n3j1bdVU6vgqukC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if ffiueHIMq6oQxRpyO1ShacVGL4Pg: ffiueHIMq6oQxRpyO1ShacVGL4Pg = ffiueHIMq6oQxRpyO1ShacVGL4Pg[f4fTutDOEwUeIoPLRQ]
				if e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa or ffiueHIMq6oQxRpyO1ShacVGL4Pg: break
		if not qv5R2JduMmjoEIcKQ3kt7WgX:
			if not e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa:
				if captcha and not ffiueHIMq6oQxRpyO1ShacVGL4Pg:
					if vkIa3ijEQVsJGdWOXwK7bnue9ADR: ffiueHIMq6oQxRpyO1ShacVGL4Pg = T8124TfgoWpSlNRKOnaIyxLU(kOB9buo8XJLfV,'ar',jUu9KomxkPAGDftYcq5a6lySB7X28)
					else:
						if not UTvsQb4HpCP3Aeo2wDZG7X5V.startswith('ID='):
							data = {'user':iidHGYjPEW4zU,'version':JeVILUu027qW,'url':jUu9KomxkPAGDftYcq5a6lySB7X28,'key':kOB9buo8XJLfV,'id':nbOFVEDkpT4BIR7Qq82yPmHeJU,'job':'getid'}
							cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',YnULcJZeMbrEPRGNxl7dm0SQjF,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-4th')
							UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
						else: UTvsQb4HpCP3Aeo2wDZG7X5V = 'ID=1234::::TIMEOUT=45'
						if UTvsQb4HpCP3Aeo2wDZG7X5V.startswith('ID='):
							A38XgxsjyJH = ScntgdOZCY74vNpXeW5jh8i.findall('ID=(.*?)::::TIMEOUT=(.*?)$',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
							gmTvECoxeLMAlZO90psD2JjdubN7k,rXKsDBmP18gdEl4LWbU6 = A38XgxsjyJH[f4fTutDOEwUeIoPLRQ]
							CtO9cFuULSm62PWToMlzN1 = 'هذه العملية تحتاج وقت من 10 إلى '+rXKsDBmP18gdEl4LWbU6+' ثانية'
							kXhEFvVqefGtabMy9z0YlpBi = LMSZwD0IRAziTh()
							kXhEFvVqefGtabMy9z0YlpBi.create('محاولة تجاوز فحص أنا أنسان ولست برنامج كومبيوتر',CtO9cFuULSm62PWToMlzN1)
							eUYWg6EZSGsQCFt5hRTfDJzmO7xoa4 = lQMuw1PvVpAk.time()
							bTFSPBw7dg1E3OxyG642A,nLHWEdVe47rPl5CQShx36 = f4fTutDOEwUeIoPLRQ,f4fTutDOEwUeIoPLRQ
							while bTFSPBw7dg1E3OxyG642A<int(rXKsDBmP18gdEl4LWbU6):
								a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,int(bTFSPBw7dg1E3OxyG642A/int(rXKsDBmP18gdEl4LWbU6)*100),CtO9cFuULSm62PWToMlzN1,nbOFVEDkpT4BIR7Qq82yPmHeJU,rXKsDBmP18gdEl4LWbU6+' / '+str(int(bTFSPBw7dg1E3OxyG642A))+'  ثانية')
								if bTFSPBw7dg1E3OxyG642A>nLHWEdVe47rPl5CQShx36+10:
									data = {'user':iidHGYjPEW4zU,'version':JeVILUu027qW,'url':jUu9KomxkPAGDftYcq5a6lySB7X28,'key':kOB9buo8XJLfV,'id':gmTvECoxeLMAlZO90psD2JjdubN7k,'job':'gettoken'}
									cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',YnULcJZeMbrEPRGNxl7dm0SQjF,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-5th')
									UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
									if UTvsQb4HpCP3Aeo2wDZG7X5V.startswith('TOKEN='):
										ffiueHIMq6oQxRpyO1ShacVGL4Pg = UTvsQb4HpCP3Aeo2wDZG7X5V.split('TOKEN=',1)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
										break
									nLHWEdVe47rPl5CQShx36 = bTFSPBw7dg1E3OxyG642A
								else: lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
								bTFSPBw7dg1E3OxyG642A = lQMuw1PvVpAk.time()-eUYWg6EZSGsQCFt5hRTfDJzmO7xoa4
							kXhEFvVqefGtabMy9z0YlpBi.close()
				if ffiueHIMq6oQxRpyO1ShacVGL4Pg:
					h2hNFjZ3WKc0skYRq5dfulI6bD87Jg = cnPhVmgFxA.cookies
					sVirjnBEY23dFh4oHleMXvz = ScntgdOZCY74vNpXeW5jh8i.findall('akwam_session=(.*?);',n3j1bdVU6vgqukC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if 'akwam_session' in list(h2hNFjZ3WKc0skYRq5dfulI6bD87Jg.keys()): sVirjnBEY23dFh4oHleMXvz = h2hNFjZ3WKc0skYRq5dfulI6bD87Jg['akwam_session']
					elif sVirjnBEY23dFh4oHleMXvz: sVirjnBEY23dFh4oHleMXvz = sVirjnBEY23dFh4oHleMXvz[f4fTutDOEwUeIoPLRQ]
					captcha = ScntgdOZCY74vNpXeW5jh8i.findall('page-redirect.*?action="(.*?)".*?data-sitekey="(.*?)"',XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if captcha: xJEtoVD4TkyeuKOqvcQUi,kOB9buo8XJLfV = captcha[f4fTutDOEwUeIoPLRQ]
					if sVirjnBEY23dFh4oHleMXvz and captcha:
						headers = {'Cookie':'akwam_session='+sVirjnBEY23dFh4oHleMXvz,'Referer':jUu9KomxkPAGDftYcq5a6lySB7X28,'Content-Type':'application/x-www-form-urlencoded'}
						data = 'g-recaptcha-response='+ffiueHIMq6oQxRpyO1ShacVGL4Pg
						cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'POST',xJEtoVD4TkyeuKOqvcQUi,data,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-6th')
						XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
						try: cookies = cnPhVmgFxA.cookies
						except: cookies = {}
						e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa = ScntgdOZCY74vNpXeW5jh8i.findall("'(akwamVerification.*?)': '(.*?)'",str(cookies),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa:
				xbfwC5hkXLvsJa8PReOS9AyU1z,e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa = e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa[f4fTutDOEwUeIoPLRQ]
				aWiAjtGlKhXeH64Iy = xbfwC5hkXLvsJa8PReOS9AyU1z+'='+e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa
				llnG7jiQBYKhAeovbT.setSetting('av.akwam.verification',aWiAjtGlKhXeH64Iy)
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','نجحت عملية فحص أنا إنسان .. وقام البرنامج بخزن نتائج هذا الفحص لكي يستخدمها لاحقا .. ولا توجد حاجة لإعادة هذا الفحص لعدة أشهر \n\n علما أن هذا الفحص سوف يتكرر في حالة تغير ربط الجهاز بالإنترنت .. أو إطفاء راوتر الإنترنت .. أو فصل سلك الراوتر .. أو استخدام VPN أو بروكسي')
				if '.mp4' not in XvREomOzBpM81LVstnFJheUScZ:
					headers = {'Cookie':aWiAjtGlKhXeH64Iy}
					cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',jUu9KomxkPAGDftYcq5a6lySB7X28,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-BYPASS_AKWAM_CAPTCHA-7th')
					XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
	if not qv5R2JduMmjoEIcKQ3kt7WgX and not aWiAjtGlKhXeH64Iy: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','فشلت عملية فحص أنا أنسان .. حاول إعادة العملية مرة أخرى باستخدام نفس الفيديو أو فيديو غيره من نفس الموقع')
	return XvREomOzBpM81LVstnFJheUScZ
def Hn1ehdUPB2(url,type,uTKGhcXEIpmDf):
	NWtqFg91ZSKinvIwAc,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU = [],[]
	jUu9KomxkPAGDftYcq5a6lySB7X28 = url
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-AKWAM-1st')
	fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
	dD1CqFmH3BrpnT = []
	if '/watch/' in fv4KNqjIBQT0UcHmlYSnrwOAWGV or '/download/' in fv4KNqjIBQT0UcHmlYSnrwOAWGV:
		ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('<a href="http.*?</a>',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if ISmqngYzv6jrepWUx0l:
			for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
				rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)".*?<span.*?">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in rU02bCJFWZDfVuhtMgBOyQi5P:
					if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in NWtqFg91ZSKinvIwAc: continue
					if '/watch/' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and '/download/' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
					if 'ا' not in title:
						dD1CqFmH3BrpnT.append((title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6))
						continue
					title = title.replace('</span>',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(' - ',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
					if 'span' in title: continue
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title)
			for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in dD1CqFmH3BrpnT:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in NWtqFg91ZSKinvIwAc:
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title)
			bCiGxXzDkH = f4fTutDOEwUeIoPLRQ
			if len(NWtqFg91ZSKinvIwAc)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr('بعضها يحتاج 60 ثانية',ifOk5xt1uHRJrTGFB7zZaeKIs6bqU)
				if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
			if NWtqFg91ZSKinvIwAc and bCiGxXzDkH>=f4fTutDOEwUeIoPLRQ: jUu9KomxkPAGDftYcq5a6lySB7X28 = NWtqFg91ZSKinvIwAc[bCiGxXzDkH]
	XvREomOzBpM81LVstnFJheUScZ = U1uEz7TJBG5DjY9I8FoNrXfax2k(jUu9KomxkPAGDftYcq5a6lySB7X28)
	lPpY5fw3tOBcEye91Caun2FQZ,bbKoeBcirVfzwAqZdQUFDSX = [],[]
	if type=='download':
		YQX7lmSVAfr6Bzt9NUIRian = ScntgdOZCY74vNpXeW5jh8i.findall('btn-loader.*?href="(.*?)"',XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if YQX7lmSVAfr6Bzt9NUIRian:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(YQX7lmSVAfr6Bzt9NUIRian[f4fTutDOEwUeIoPLRQ])
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			bbKoeBcirVfzwAqZdQUFDSX.append(uTKGhcXEIpmDf)
	elif type=='watch':
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('<source.*?src="(.*?)".*?size="(.*?)"',XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,size in rU02bCJFWZDfVuhtMgBOyQi5P:
			if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
			if uTKGhcXEIpmDf in size:
				bbKoeBcirVfzwAqZdQUFDSX.append(size)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				break
		if not lPpY5fw3tOBcEye91Caun2FQZ:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,size in rU02bCJFWZDfVuhtMgBOyQi5P:
				if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				bbKoeBcirVfzwAqZdQUFDSX.append(size)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if not lPpY5fw3tOBcEye91Caun2FQZ: return 'Error: Resolver Failed AKWAM',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Pl9syVGTF0(url,xbfwC5hkXLvsJa8PReOS9AyU1z):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-AKOAM-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	cookies = cnPhVmgFxA.cookies
	if 'golink' in list(cookies.keys()):
		aWiAjtGlKhXeH64Iy = cookies['golink']
		aWiAjtGlKhXeH64Iy = SxN0jnqr3LI(eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(aWiAjtGlKhXeH64Iy))
		items = ScntgdOZCY74vNpXeW5jh8i.findall('route":"(.*?)"',aWiAjtGlKhXeH64Iy,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		plSscrVjkRviPwm = items[f4fTutDOEwUeIoPLRQ].replace('\/','/')
		plSscrVjkRviPwm = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(plSscrVjkRviPwm)
	else: plSscrVjkRviPwm = url
	if 'catch.is' in plSscrVjkRviPwm:
		diZGcVFrYSI3Nej1TBKQDAaWL6k = plSscrVjkRviPwm.split('%2F')[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		plSscrVjkRviPwm = 'http://catch.is/'+diZGcVFrYSI3Nej1TBKQDAaWL6k
		return 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	else:
		website = sCSyOla9hrcE['AKOAM'][f4fTutDOEwUeIoPLRQ]
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',website,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-AKOAM-2nd')
		tBGYpZ3PNLmuU1fl2C7WV = cnPhVmgFxA.url
		xeu9ijch5ts = plSscrVjkRviPwm.split('/')[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		x4ZjgGLBqXlwz2oTA7MD0 = tBGYpZ3PNLmuU1fl2C7WV.split('/')[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm.replace(xeu9ijch5ts,x4ZjgGLBqXlwz2oTA7MD0)
		headers = { 'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU , 'X-Requested-With':'XMLHttpRequest' , 'Referer':zb2QIaL7Y4h9g8lSck }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST', zb2QIaL7Y4h9g8lSck, nbOFVEDkpT4BIR7Qq82yPmHeJU, headers, SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-AKOAM-3rd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		items = ScntgdOZCY74vNpXeW5jh8i.findall('direct_link":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if not items:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
			if not items:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('<embed.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[f4fTutDOEwUeIoPLRQ].replace('\/','/')
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rstrip('/')
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:' + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('http://','https://')
			if xbfwC5hkXLvsJa8PReOS9AyU1z==nbOFVEDkpT4BIR7Qq82yPmHeJU: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
			else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = 'NEED_EXTERNAL_RESOLVERS',[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
		else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = 'Error: Resolver Failed AKOAM',[],[]
		return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def X8XUbv2VaP6f1S(url):
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-RAPIDVIDEO-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<source src="(.*?)".*?label="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errno = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if items:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,NNntz8hA93kG6WqEDb1OUoeFm2fg in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return 'Error: Resolver Failed RAPIDVIDEO',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Q8GvDRzUA3NXig0oJyEHStduYxqLP(url):
	headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-UQLOAD-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('sources: \["(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		url = items[f4fTutDOEwUeIoPLRQ]+'|Referer='+url
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	else: return 'Error: Resolver Failed UQLOAD',[],[]
def o6gsJ7VMy0FTQePUiGCwK5L9t4c2EH(url):
	url = url.strip('/')
	if '/embed/' in url: diZGcVFrYSI3Nej1TBKQDAaWL6k = url.split('/')[WtDrnpJmwQ37Z2Ae68hu4BY5M1]
	else: diZGcVFrYSI3Nej1TBKQDAaWL6k = url.split('/')[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	url = 'https://vcstream.to/player?fid=' + diZGcVFrYSI3Nej1TBKQDAaWL6k
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-VCSTREAM-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('file":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return 'Error: Resolver Failed VCSTREAM',[],[]
def XsE0MzVUwhTZ62Py(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-VIDOZA-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('src: "(.*?)".*?label:"(.*?)", res:"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,NNntz8hA93kG6WqEDb1OUoeFm2fg,wgS3zkYrvX5R4DQi in items:
		bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg+S3X6GcaiExOPtb+wgS3zkYrvX5R4DQi)
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return 'Error: Resolver Failed VIDOZA',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def ZjK0JomnMz2VhQ4Ce31(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-WATCHVIDEO-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall("download_video\('(.*?)','(.*?)','(.*?)'\)\">(.*?)</a>.*?<td>(.*?),.*?</td>",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items = set(items)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	for diZGcVFrYSI3Nej1TBKQDAaWL6k,EYMmnJAyxV,iy45XExGd9AK7VYTcZprkhfQ,NNntz8hA93kG6WqEDb1OUoeFm2fg,wgS3zkYrvX5R4DQi in items:
		url = 'https://watchvideo.us/dl?op=download_orig&id='+diZGcVFrYSI3Nej1TBKQDAaWL6k+'&mode='+EYMmnJAyxV+'&hash='+iy45XExGd9AK7VYTcZprkhfQ
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-WATCHVIDEO-2nd')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('direct link.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg+S3X6GcaiExOPtb+wgS3zkYrvX5R4DQi)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return 'Error: Resolver Failed WATCHVIDEO',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def RREam6IVLoCudeXDU1Aw(url):
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if vkIa3ijEQVsJGdWOXwK7bnue9ADR or 'Key=' not in url:
		plSscrVjkRviPwm = url.replace('upbom.live','uppom.live')
		plSscrVjkRviPwm = plSscrVjkRviPwm.split('/')
		diZGcVFrYSI3Nej1TBKQDAaWL6k = plSscrVjkRviPwm[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
		plSscrVjkRviPwm = '/'.join(plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ:WtDrnpJmwQ37Z2Ae68hu4BY5M1])
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = {'id':diZGcVFrYSI3Nej1TBKQDAaWL6k,'op':'download2','method_free':'Free+Download+%3E%3E'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',plSscrVjkRviPwm,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-UPBOM-1st')
		if 'Location' in list(cnPhVmgFxA.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['Location']
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and cnPhVmgFxA.succeeded:
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('id="direct_link".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-UPBOM-2nd')
		if 'location' in list(cnPhVmgFxA.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers['location']
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return 'Error: Resolver Failed UPBOM',[],[]
def hySV345z0gvKfHxpjEPksT2(url):
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-LIIVIDEO-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('sources:.*?"(.*?)","(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	if items:
		bbKoeBcirVfzwAqZdQUFDSX.append('mp4')
		lPpY5fw3tOBcEye91Caun2FQZ.append(items[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR])
		bbKoeBcirVfzwAqZdQUFDSX.append('m3u8')
		lPpY5fw3tOBcEye91Caun2FQZ.append(items[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ])
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	else: return 'Error: Resolver Failed LIIVIDEO',[],[]
cT5ofBydziOjbvw38XPpW = SmbNGskjMx
def VtJMTRCpWz(url):
	global cT5ofBydziOjbvw38XPpW
	if cT5ofBydziOjbvw38XPpW: return 'Error    : Resolver YOUTUBE Failed',[],[]
	cT5ofBydziOjbvw38XPpW = Ag9l6cw3EBqP8HsQuGMizfOtr4
	diZGcVFrYSI3Nej1TBKQDAaWL6k = url.split('/')[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	diZGcVFrYSI3Nej1TBKQDAaWL6k = diZGcVFrYSI3Nej1TBKQDAaWL6k.split('&')[f4fTutDOEwUeIoPLRQ]
	diZGcVFrYSI3Nej1TBKQDAaWL6k = diZGcVFrYSI3Nej1TBKQDAaWL6k.replace('watch?v=',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	plSscrVjkRviPwm = sCSyOla9hrcE['YOUTUBE'][f4fTutDOEwUeIoPLRQ]+'/watch?v='+diZGcVFrYSI3Nej1TBKQDAaWL6k
	RNhYFJCkgb4iU5M = 'http://youtu.be/'+diZGcVFrYSI3Nej1TBKQDAaWL6k
	coMCRv31uZ07nOGFVmwQAN4,w4Kx6sQHfSlboc8mYM27de9D1yqI,ejwabnuGOANDg,YRzpqA4JkjoOt1KC0du = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
	if f4fTutDOEwUeIoPLRQ:
		for HT4fGXqv8hEcKsJ in range(5):
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-YOUTUBE-1st')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			if 'itag' in UTvsQb4HpCP3Aeo2wDZG7X5V: break
			lQMuw1PvVpAk.sleep(QQSugEIn2mTCpRsfcaJHhPdAWzylM)
		yWdTJKAabtf84L1B2OsHN0oDur = ScntgdOZCY74vNpXeW5jh8i.findall('var ytInitialPlayerResponse = (.*?);</script>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if yWdTJKAabtf84L1B2OsHN0oDur: yWdTJKAabtf84L1B2OsHN0oDur = yWdTJKAabtf84L1B2OsHN0oDur[f4fTutDOEwUeIoPLRQ]
		else: yWdTJKAabtf84L1B2OsHN0oDur = UTvsQb4HpCP3Aeo2wDZG7X5V
	else:
		UTvsQb4HpCP3Aeo2wDZG7X5V = nbOFVEDkpT4BIR7Qq82yPmHeJU
		headers['Content-Type'] = 'application/json'
		zb2QIaL7Y4h9g8lSck = sCSyOla9hrcE['YOUTUBE'][f4fTutDOEwUeIoPLRQ]+'/youtubei/v1/player'
		zBk0VHdLqXOQ = '{"videoId": "'+diZGcVFrYSI3Nej1TBKQDAaWL6k+'", "context": {"client": {"clientVersion": "1.9", "clientName": "ANDROID_TESTSUITE"}}}'
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'POST',zb2QIaL7Y4h9g8lSck,zBk0VHdLqXOQ,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-YOUTUBE-2nd')
		yWdTJKAabtf84L1B2OsHN0oDur = cnPhVmgFxA.content
	yWdTJKAabtf84L1B2OsHN0oDur = yWdTJKAabtf84L1B2OsHN0oDur.replace('\\u0026','&')
	bP2ptXl7DGnqQvOfUH = dr1zfnatJxRHSF48jh0eODm5bGu('dict',yWdTJKAabtf84L1B2OsHN0oDur)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = ['بدون ترجمة يوتيوب'],[nbOFVEDkpT4BIR7Qq82yPmHeJU]
	try:
		uGNKhxReT267qiBC93YJ = bP2ptXl7DGnqQvOfUH['captions']['playerCaptionsTracklistRenderer']['captionTracks']
		for tOXU49jmqIfdB3 in uGNKhxReT267qiBC93YJ:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = tOXU49jmqIfdB3['baseUrl']
			try: title = tOXU49jmqIfdB3['name']['simpleText']
			except: title = tOXU49jmqIfdB3['name']['runs'][f4fTutDOEwUeIoPLRQ]['textt']
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
	except: pass
	if len(bbKoeBcirVfzwAqZdQUFDSX)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الترجمة ('+str(len(bbKoeBcirVfzwAqZdQUFDSX))+' ملف)', bbKoeBcirVfzwAqZdQUFDSX)
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
		elif bCiGxXzDkH!=f4fTutDOEwUeIoPLRQ:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]+'&'
			rGvO9dNWVnAg48SjPUcuRI0pDX1 = ScntgdOZCY74vNpXeW5jh8i.findall('&(fmt=.*?)&',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			if rGvO9dNWVnAg48SjPUcuRI0pDX1: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(rGvO9dNWVnAg48SjPUcuRI0pDX1[f4fTutDOEwUeIoPLRQ],'fmt=vtt')
			else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'fmt=vtt'
			coMCRv31uZ07nOGFVmwQAN4 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('&')
	vSlFYOychfpiWxzwtI76bN0XMR,Wr5kib4gEvpQI0TM,Y2DRjXQ9Tv75cOKHlok,D1JuqIHoXUjx,Hi2WrtP1f4DlGk5gR = [],[],[],[],[]
	try: w4Kx6sQHfSlboc8mYM27de9D1yqI = bP2ptXl7DGnqQvOfUH['streamingData']['dashManifestUrl']
	except: pass
	try: ejwabnuGOANDg = bP2ptXl7DGnqQvOfUH['streamingData']['hlsManifestUrl']
	except: pass
	try: vSlFYOychfpiWxzwtI76bN0XMR = bP2ptXl7DGnqQvOfUH['streamingData']['formats']
	except: pass
	try: Wr5kib4gEvpQI0TM = bP2ptXl7DGnqQvOfUH['streamingData']['adaptiveFormats']
	except: pass
	JwKD1X4hRIA = vSlFYOychfpiWxzwtI76bN0XMR+Wr5kib4gEvpQI0TM
	for dict in JwKD1X4hRIA:
		if 'itag' in list(dict.keys()): dict['itag'] = str(dict['itag'])
		if 'fps' in list(dict.keys()): dict['fps'] = str(dict['fps'])
		if 'mimeType' in list(dict.keys()): dict['type'] = dict['mimeType']
		if 'audioSampleRate' in list(dict.keys()): dict['audio_sample_rate'] = str(dict['audioSampleRate'])
		if 'audioChannels' in list(dict.keys()): dict['audio_channels'] = str(dict['audioChannels'])
		if 'width' in list(dict.keys()): dict['size'] = str(dict['width'])+'x'+str(dict['height'])
		if 'initRange' in list(dict.keys()): dict['init'] = dict['initRange']['start']+'-'+dict['initRange']['end']
		if 'indexRange' in list(dict.keys()): dict['index'] = dict['indexRange']['start']+'-'+dict['indexRange']['end']
		if 'averageBitrate' in list(dict.keys()): dict['bitrate'] = dict['averageBitrate']
		if 'bitrate' in list(dict.keys()) and int(dict['bitrate'])>111222333: del dict['bitrate']
		if 'signatureCipher' in list(dict.keys()):
			l1xzoYDPwrWj6GypSN = dict['signatureCipher'].split('&')
			for xB2lOZNsPvFQDC4gMz in l1xzoYDPwrWj6GypSN:
				key,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=',1)
				dict[key] = SxN0jnqr3LI(XPL0O2VkI3w1C8enMaqi)
		if 'url' in list(dict.keys()): dict['url'] = SxN0jnqr3LI(dict['url'])
		Y2DRjXQ9Tv75cOKHlok.append(dict)
	HJV56UEGvXkOLi = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 'sp=sig' in yWdTJKAabtf84L1B2OsHN0oDur:
		if not UTvsQb4HpCP3Aeo2wDZG7X5V:
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-YOUTUBE-3rd')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		SHGyEqBUd9v = ScntgdOZCY74vNpXeW5jh8i.findall('src="(/s/player/\w*?/player_ias.vflset/en_../base.js)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if SHGyEqBUd9v:
			SHGyEqBUd9v = sCSyOla9hrcE['YOUTUBE'][f4fTutDOEwUeIoPLRQ]+SHGyEqBUd9v[f4fTutDOEwUeIoPLRQ]
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',SHGyEqBUd9v,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-YOUTUBE-4th')
			HJV56UEGvXkOLi = cnPhVmgFxA.content
			import youtube_signature.cipher as DXFbJCp5H7ljVc61uRsakNgdBeAmIY,youtube_signature.json_script_engine as rERluCFzk0O4QhZYxbBAMXUWVv5mjn
			l1xzoYDPwrWj6GypSN = tf9KV52MpNE8iR0r.l1xzoYDPwrWj6GypSN.Cipher()
			l1xzoYDPwrWj6GypSN._object_cache = {}
			Haj0tcYEplW = l1xzoYDPwrWj6GypSN._load_javascript(HJV56UEGvXkOLi)
			nb4f58qaKBsHWi3YuvPOEVceIGTJw = dr1zfnatJxRHSF48jh0eODm5bGu('str',str(Haj0tcYEplW))
			EIkby8RG9oz1vBgeV5WsMQZN = tf9KV52MpNE8iR0r.RRnqt5y1lbvshQoCIUiXYdmA.JsonScriptEngine(nb4f58qaKBsHWi3YuvPOEVceIGTJw)
	for dict in Y2DRjXQ9Tv75cOKHlok:
		url = dict['url']
		if 'signature=' in url or url.count('sig=')>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			D1JuqIHoXUjx.append(dict)
		elif HJV56UEGvXkOLi and 's' in list(dict.keys()) and 'sp' in list(dict.keys()):
			mK1ZrjkRv4ay75epWOtAb = EIkby8RG9oz1vBgeV5WsMQZN.execute(dict['s'])
			if mK1ZrjkRv4ay75epWOtAb!=dict['s']:
				dict['url'] = url+'&'+dict['sp']+'='+mK1ZrjkRv4ay75epWOtAb
				D1JuqIHoXUjx.append(dict)
	for dict in D1JuqIHoXUjx:
		D63UZqx2XBgrtbje,oo1TBHMr5XV2sbEuaiRw7ZD4P,i5H9MQgPEX1Kz4k,nFE7RXAdxPUaktfcCDwZGsQhMzybmY,piSNgoCl30QnADL4q62juFROaWUh,twyo6bl7DKGL = 'unknown','unknown','unknown','Unknown',nbOFVEDkpT4BIR7Qq82yPmHeJU,'0'
		try:
			vBwlihVfEa84TW3NmjLdAJxcn29ps = dict['type']
			vBwlihVfEa84TW3NmjLdAJxcn29ps = vBwlihVfEa84TW3NmjLdAJxcn29ps.replace('+',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			items = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?)/(.*?);.*?"(.*?)"',vBwlihVfEa84TW3NmjLdAJxcn29ps,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			nFE7RXAdxPUaktfcCDwZGsQhMzybmY,D63UZqx2XBgrtbje,piSNgoCl30QnADL4q62juFROaWUh = items[f4fTutDOEwUeIoPLRQ]
			PMKXyZsVSjbEpnmr1 = piSNgoCl30QnADL4q62juFROaWUh.split(',')
			oo1TBHMr5XV2sbEuaiRw7ZD4P = nbOFVEDkpT4BIR7Qq82yPmHeJU
			for xB2lOZNsPvFQDC4gMz in PMKXyZsVSjbEpnmr1: oo1TBHMr5XV2sbEuaiRw7ZD4P += xB2lOZNsPvFQDC4gMz.split('.')[f4fTutDOEwUeIoPLRQ]+','
			oo1TBHMr5XV2sbEuaiRw7ZD4P = oo1TBHMr5XV2sbEuaiRw7ZD4P.strip(',')
			if 'bitrate' in list(dict.keys()): twyo6bl7DKGL = str(float(dict['bitrate']*10)//1024/10)+'kbps  '
			else: twyo6bl7DKGL = nbOFVEDkpT4BIR7Qq82yPmHeJU
			if nFE7RXAdxPUaktfcCDwZGsQhMzybmY=='textt': continue
			elif ',' in vBwlihVfEa84TW3NmjLdAJxcn29ps:
				nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'A+V'
				i5H9MQgPEX1Kz4k = D63UZqx2XBgrtbje+BhmzEC6OGD7FXZig9Tp5A+twyo6bl7DKGL+dict['size'].split('x')[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			elif nFE7RXAdxPUaktfcCDwZGsQhMzybmY=='video':
				nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'Video'
				i5H9MQgPEX1Kz4k = twyo6bl7DKGL+dict['size'].split('x')[vkIa3ijEQVsJGdWOXwK7bnue9ADR]+BhmzEC6OGD7FXZig9Tp5A+dict['fps']+'fps'+BhmzEC6OGD7FXZig9Tp5A+D63UZqx2XBgrtbje
			elif nFE7RXAdxPUaktfcCDwZGsQhMzybmY=='audio':
				nFE7RXAdxPUaktfcCDwZGsQhMzybmY = 'Audio'
				i5H9MQgPEX1Kz4k = twyo6bl7DKGL+str(int(dict['audio_sample_rate'])/1000)+'khz  '+dict['audio_channels']+'ch'+BhmzEC6OGD7FXZig9Tp5A+D63UZqx2XBgrtbje
		except:
			vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
			if vf9s4ClmTE08AGndQV!='NoneType: None\n': Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
		if 'dur=' in dict['url']: H07WdckxAoZF1fn4LNMOTP65eEtr = round(0.5+float(dict['url'].split('dur=',1)[vkIa3ijEQVsJGdWOXwK7bnue9ADR].split('&',vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]))
		elif 'approxDurationMs' in list(dict.keys()): H07WdckxAoZF1fn4LNMOTP65eEtr = round(0.5+float(dict['approxDurationMs'])/1000)
		else: H07WdckxAoZF1fn4LNMOTP65eEtr = '0'
		if 'bitrate' not in list(dict.keys()): twyo6bl7DKGL = dict['size'].split('x')[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		else: twyo6bl7DKGL = dict['bitrate']
		if 'init' not in list(dict.keys()): dict['init'] = '0-0'
		dict['title'] = nFE7RXAdxPUaktfcCDwZGsQhMzybmY+':  '+i5H9MQgPEX1Kz4k+'  ('+oo1TBHMr5XV2sbEuaiRw7ZD4P+','+dict['itag']+')'
		dict['quality'] = i5H9MQgPEX1Kz4k.split(BhmzEC6OGD7FXZig9Tp5A)[f4fTutDOEwUeIoPLRQ].split('kbps')[f4fTutDOEwUeIoPLRQ]
		dict['type2'] = nFE7RXAdxPUaktfcCDwZGsQhMzybmY
		dict['filetype'] = D63UZqx2XBgrtbje
		dict['codecs'] = piSNgoCl30QnADL4q62juFROaWUh
		dict['duration'] = H07WdckxAoZF1fn4LNMOTP65eEtr
		dict['bitrate'] = twyo6bl7DKGL
		Hi2WrtP1f4DlGk5gR.append(dict)
	NihE6AX0xgq1aUoKcwk9PFId,dBColkMzqPciO,reNHJO2YV6DqcbpMu5XQnF,GHJglMPq8dicaB67DbXURvowe3T,NR8JCd3ogDfZjG17zHiFyI2450rPt = [],[],[],[],[]
	ahwJu69WiN,I72X4GAJm3QSaWqBrFU5j,ej8EUVpXQlCYra7tNz094IF6xfPbk,qq5efZJx26AEv8ph,bqEZg1G0uzIocX6r = [],[],[],[],[]
	if w4Kx6sQHfSlboc8mYM27de9D1yqI:
		dict = {}
		dict['type2'] = 'A+V'
		dict['filetype'] = 'mpd'
		dict['title'] = dict['type2']+':  '+dict['filetype']+BhmzEC6OGD7FXZig9Tp5A+'جودة ذكية'
		dict['url'] = w4Kx6sQHfSlboc8mYM27de9D1yqI
		dict['quality'] = '0'
		dict['bitrate'] = '9876543210'
		Hi2WrtP1f4DlGk5gR.append(dict)
	if ejwabnuGOANDg:
		v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b = mmAWFnZUkQ3HowdxRtCN9(ejwabnuGOANDg)
		GGoDmbtFq47ra6zMEj = list(zip(v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b))
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in GGoDmbtFq47ra6zMEj:
			dict = {}
			dict['type2'] = 'A+V'
			dict['filetype'] = 'm3u8'
			dict['url'] = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if 'kbps' in title: dict['bitrate'] = title.split('kbps')[f4fTutDOEwUeIoPLRQ].rsplit(BhmzEC6OGD7FXZig9Tp5A)[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			else: dict['bitrate'] = '10'
			if title.count(BhmzEC6OGD7FXZig9Tp5A)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				uTKGhcXEIpmDf = title.rsplit(BhmzEC6OGD7FXZig9Tp5A)[-ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
				if uTKGhcXEIpmDf.isdigit(): dict['quality'] = uTKGhcXEIpmDf
				else: dict['quality'] = '0000'
			if title=='-1': dict['title'] = dict['type2']+':  '+dict['filetype']+BhmzEC6OGD7FXZig9Tp5A+'جودة ذكية'
			else: dict['title'] = dict['type2']+':  '+dict['filetype']+BhmzEC6OGD7FXZig9Tp5A+dict['bitrate']+'kbps  '+dict['quality']
			Hi2WrtP1f4DlGk5gR.append(dict)
	Hi2WrtP1f4DlGk5gR = sorted(Hi2WrtP1f4DlGk5gR,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: float(key['bitrate']))
	if not Hi2WrtP1f4DlGk5gR:
		if not UTvsQb4HpCP3Aeo2wDZG7X5V:
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-YOUTUBE-5th')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		G8CImB4K9pN3OhHT = ScntgdOZCY74vNpXeW5jh8i.findall('class="messagee">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = ScntgdOZCY74vNpXeW5jh8i.findall('"playerErrorMessageRenderer":\{"subreason":\{"runs":\[\{"textt":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Rv3xcXSYnZIK7bFNiUHweEQL0z1j = ScntgdOZCY74vNpXeW5jh8i.findall('"playerErrorMessageRenderer":\{"reason":{"simpleText":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		amIcByjdlx5ktPVoh2WvQOXsLzi = ScntgdOZCY74vNpXeW5jh8i.findall('"playerErrorMessageRenderer":\{"subreason":{"simpleText":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		try: LySqdUiNpk8cxrA = bP2ptXl7DGnqQvOfUH['playabilityStatus']['errorScreen']['confirmDialogRenderer']['title']['runs'][f4fTutDOEwUeIoPLRQ]['textt']
		except: LySqdUiNpk8cxrA = nbOFVEDkpT4BIR7Qq82yPmHeJU
		try: toZ4n765X8zFp9BO3Ky2keG1N = bP2ptXl7DGnqQvOfUH['playabilityStatus']['errorScreen']['confirmDialogRenderer']['dialogMessages'][f4fTutDOEwUeIoPLRQ]['runs'][f4fTutDOEwUeIoPLRQ]['textt']
		except: toZ4n765X8zFp9BO3Ky2keG1N = nbOFVEDkpT4BIR7Qq82yPmHeJU
		try: RwxE8lmUTt4hLuv = bP2ptXl7DGnqQvOfUH['playabilityStatus']['reason']
		except: RwxE8lmUTt4hLuv = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if G8CImB4K9pN3OhHT or dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs or Rv3xcXSYnZIK7bFNiUHweEQL0z1j or amIcByjdlx5ktPVoh2WvQOXsLzi or LySqdUiNpk8cxrA or toZ4n765X8zFp9BO3Ky2keG1N or RwxE8lmUTt4hLuv:
			if   G8CImB4K9pN3OhHT: CtO9cFuULSm62PWToMlzN1 = G8CImB4K9pN3OhHT[f4fTutDOEwUeIoPLRQ]
			elif dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs: CtO9cFuULSm62PWToMlzN1 = dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs[f4fTutDOEwUeIoPLRQ]
			elif Rv3xcXSYnZIK7bFNiUHweEQL0z1j: CtO9cFuULSm62PWToMlzN1 = Rv3xcXSYnZIK7bFNiUHweEQL0z1j[f4fTutDOEwUeIoPLRQ]
			elif amIcByjdlx5ktPVoh2WvQOXsLzi: CtO9cFuULSm62PWToMlzN1 = amIcByjdlx5ktPVoh2WvQOXsLzi[f4fTutDOEwUeIoPLRQ]
			elif LySqdUiNpk8cxrA: CtO9cFuULSm62PWToMlzN1 = LySqdUiNpk8cxrA
			elif toZ4n765X8zFp9BO3Ky2keG1N: CtO9cFuULSm62PWToMlzN1 = toZ4n765X8zFp9BO3Ky2keG1N
			elif RwxE8lmUTt4hLuv: CtO9cFuULSm62PWToMlzN1 = RwxE8lmUTt4hLuv
			rFb35EZUWa2 = CtO9cFuULSm62PWToMlzN1.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			EHRKpjc8XJ4xfl9FkndgsryPe7Gi = eMypvI8XqHjYU02anWD9gsSrkt+'هذا الفيديو فيه مشكلة وقد يكون غير ملائم لبعض المستخدمين أو غير متوفر الآن'+c7gxFyUCGm
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من الموقع والمبرمج',EHRKpjc8XJ4xfl9FkndgsryPe7Gi+'\n\n'+rFb35EZUWa2)
			return 'Error    : Resolver YOUTUBE Failed: '+rFb35EZUWa2,[],[]
		else: return 'Error    : Resolver YOUTUBE Failed',[],[]
	us5ZmETVAqtnhxrlFJb,NdVt7BJXkGLMy14,beCdKlr8WVY5GMSo3aL = [],[],[]
	for dict in Hi2WrtP1f4DlGk5gR:
		if dict['type2']=='Video':
			NihE6AX0xgq1aUoKcwk9PFId.append(dict['title'])
			ahwJu69WiN.append(dict)
		elif dict['type2']=='Audio':
			dBColkMzqPciO.append(dict['title'])
			I72X4GAJm3QSaWqBrFU5j.append(dict)
		elif dict['filetype']=='mpd':
			title = dict['title'].replace('A+V:  ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if 'bitrate' not in list(dict.keys()): twyo6bl7DKGL = '0'
			else: twyo6bl7DKGL = dict['bitrate']
			us5ZmETVAqtnhxrlFJb.append([dict,{},title,twyo6bl7DKGL])
		else:
			title = dict['title'].replace('A+V:  ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if 'bitrate' not in list(dict.keys()): twyo6bl7DKGL = '0'
			else: twyo6bl7DKGL = dict['bitrate']
			us5ZmETVAqtnhxrlFJb.append([dict,{},title,twyo6bl7DKGL])
			reNHJO2YV6DqcbpMu5XQnF.append(title)
			ej8EUVpXQlCYra7tNz094IF6xfPbk.append(dict)
		BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if 'codecs' in list(dict.keys()):
			if 'av0' in dict['codecs']: BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r = SmbNGskjMx
			elif o8MCS3IzmRXdVDB7xg2eiW5baZUn<18:
				if 'avc' not in dict['codecs'] and 'mp4a' not in dict['codecs']: BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r = SmbNGskjMx
		if dict['type2']=='Video' and dict['init']!='0-0' and BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r==Ag9l6cw3EBqP8HsQuGMizfOtr4:
			NR8JCd3ogDfZjG17zHiFyI2450rPt.append(dict['title'])
			bqEZg1G0uzIocX6r.append(dict)
		elif dict['type2']=='Audio' and dict['init']!='0-0' and BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r==Ag9l6cw3EBqP8HsQuGMizfOtr4:
			GHJglMPq8dicaB67DbXURvowe3T.append(dict['title'])
			qq5efZJx26AEv8ph.append(dict)
	for kQVO4r3FPjWH6 in qq5efZJx26AEv8ph:
		GP9mJLwqZbf2Kugp = kQVO4r3FPjWH6['bitrate']
		for HswcgVSFO3hExZflmX5KN4jro9QMR in bqEZg1G0uzIocX6r:
			QAl9WCgY3nwHN = HswcgVSFO3hExZflmX5KN4jro9QMR['bitrate']
			twyo6bl7DKGL = QAl9WCgY3nwHN+GP9mJLwqZbf2Kugp
			title = HswcgVSFO3hExZflmX5KN4jro9QMR['title'].replace('Video:  ','mpd  ')
			title = title.replace(HswcgVSFO3hExZflmX5KN4jro9QMR['filetype']+BhmzEC6OGD7FXZig9Tp5A,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			title = title.replace(str((float(QAl9WCgY3nwHN*10)//1024/10))+'kbps',str((float(twyo6bl7DKGL*10)//1024/10))+'kbps')
			title = title+'('+kQVO4r3FPjWH6['title'].split('(',vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			us5ZmETVAqtnhxrlFJb.append([HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL])
	us5ZmETVAqtnhxrlFJb = sorted(us5ZmETVAqtnhxrlFJb, reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4, key=lambda key: float(key[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]))
	for HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL in us5ZmETVAqtnhxrlFJb:
		uTj3MXJU5l7roQkd = HswcgVSFO3hExZflmX5KN4jro9QMR['filetype']
		if 'filetype' in list(kQVO4r3FPjWH6.keys()):
			uTj3MXJU5l7roQkd = 'mpd'
		if uTj3MXJU5l7roQkd not in beCdKlr8WVY5GMSo3aL:
			beCdKlr8WVY5GMSo3aL.append(uTj3MXJU5l7roQkd)
			NdVt7BJXkGLMy14.append([HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL])
	vvGIkPQMdXxus0,JZMTEbhgmdpo5rGt2ijVSDnK7U9,lc43J2kIQDvNmAgOXHrCGzwEextM = [],[],f4fTutDOEwUeIoPLRQ
	cZfRJhSApvVbEH6k1jlqNnr5QdXC,NLg42WeBdYFf1rDUbKo = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: cZfRJhSApvVbEH6k1jlqNnr5QdXC = bP2ptXl7DGnqQvOfUH['videoDetails']['author']
	except: cZfRJhSApvVbEH6k1jlqNnr5QdXC = nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: Mx4okSWZqj13Cw = bP2ptXl7DGnqQvOfUH['videoDetails']['channelId']
	except: Mx4okSWZqj13Cw = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if cZfRJhSApvVbEH6k1jlqNnr5QdXC and Mx4okSWZqj13Cw:
		lc43J2kIQDvNmAgOXHrCGzwEextM += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		title = eMypvI8XqHjYU02anWD9gsSrkt+'OWNER:  '+cZfRJhSApvVbEH6k1jlqNnr5QdXC+c7gxFyUCGm
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = sCSyOla9hrcE['YOUTUBE'][f4fTutDOEwUeIoPLRQ]+'/channel/'+Mx4okSWZqj13Cw
		vvGIkPQMdXxus0.append(title)
		JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		try: NLg42WeBdYFf1rDUbKo = bP2ptXl7DGnqQvOfUH['videoDetails']['thumbnail']['thumbnails'][-vkIa3ijEQVsJGdWOXwK7bnue9ADR]['url']
		except: pass
	for HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL in NdVt7BJXkGLMy14:
		vvGIkPQMdXxus0.append(title) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append('highest')
	if reNHJO2YV6DqcbpMu5XQnF: vvGIkPQMdXxus0.append('صورة وصوت محددة') ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append('muxed')
	if us5ZmETVAqtnhxrlFJb: vvGIkPQMdXxus0.append('صورة وصوت المتوفر') ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append('all')
	if NR8JCd3ogDfZjG17zHiFyI2450rPt: vvGIkPQMdXxus0.append('mpd اختر الصورة والصوت') ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append('mpd')
	if NihE6AX0xgq1aUoKcwk9PFId: vvGIkPQMdXxus0.append('صورة بدون صوت') ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append('video')
	if dBColkMzqPciO: vvGIkPQMdXxus0.append('صوت بدون صورة') ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append('audio')
	bHAYFo9MGm6gIBOReSjNLr2 = SmbNGskjMx
	while Ag9l6cw3EBqP8HsQuGMizfOtr4:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr(RNhYFJCkgb4iU5M, vvGIkPQMdXxus0)
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return 'EXIT_ALL_RESOLVERS',[],[]
		elif bCiGxXzDkH==f4fTutDOEwUeIoPLRQ and cZfRJhSApvVbEH6k1jlqNnr5QdXC:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = JZMTEbhgmdpo5rGt2ijVSDnK7U9[bCiGxXzDkH]
			vBWiqzoKuAxkDFLdHZjm9JrUy4t0I = Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[f4fTutDOEwUeIoPLRQ]+'?type=folder&mode=141&name='+lcxFAteLQ1Pwu45Er2(cZfRJhSApvVbEH6k1jlqNnr5QdXC)+'&url='+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if NLg42WeBdYFf1rDUbKo: vBWiqzoKuAxkDFLdHZjm9JrUy4t0I = vBWiqzoKuAxkDFLdHZjm9JrUy4t0I+'&image='+lcxFAteLQ1Pwu45Er2(NLg42WeBdYFf1rDUbKo)
			RarSo2nTfwU0WEGK.executebuiltin("Container.Update("+vBWiqzoKuAxkDFLdHZjm9JrUy4t0I+")")
			return 'EXIT_ALL_RESOLVERS',[],[]
		CH74LFlzUW3gkcxe2P = JZMTEbhgmdpo5rGt2ijVSDnK7U9[bCiGxXzDkH]
		AsywcRXgd9IY5 = vvGIkPQMdXxus0[bCiGxXzDkH]
		if CH74LFlzUW3gkcxe2P=='dash':
			YRzpqA4JkjoOt1KC0du = w4Kx6sQHfSlboc8mYM27de9D1yqI
			break
		elif CH74LFlzUW3gkcxe2P in ['audio','video','muxed']:
			if CH74LFlzUW3gkcxe2P=='muxed': bbKoeBcirVfzwAqZdQUFDSX,v1VonNPWhEGSa = reNHJO2YV6DqcbpMu5XQnF,ej8EUVpXQlCYra7tNz094IF6xfPbk
			elif CH74LFlzUW3gkcxe2P=='video': bbKoeBcirVfzwAqZdQUFDSX,v1VonNPWhEGSa = NihE6AX0xgq1aUoKcwk9PFId,ahwJu69WiN
			elif CH74LFlzUW3gkcxe2P=='audio': bbKoeBcirVfzwAqZdQUFDSX,v1VonNPWhEGSa = dBColkMzqPciO,I72X4GAJm3QSaWqBrFU5j
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الملف ('+str(len(bbKoeBcirVfzwAqZdQUFDSX))+' ملف)', bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				YRzpqA4JkjoOt1KC0du = v1VonNPWhEGSa[bCiGxXzDkH]['url']
				AsywcRXgd9IY5 = bbKoeBcirVfzwAqZdQUFDSX[bCiGxXzDkH]
				break
		elif CH74LFlzUW3gkcxe2P=='mpd':
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر جودة الصورة ('+str(len(NR8JCd3ogDfZjG17zHiFyI2450rPt))+' ملف)', NR8JCd3ogDfZjG17zHiFyI2450rPt)
			if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				AsywcRXgd9IY5 = NR8JCd3ogDfZjG17zHiFyI2450rPt[bCiGxXzDkH]
				lJoMYGpUm3TDVBgAjfs9 = bqEZg1G0uzIocX6r[bCiGxXzDkH]
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر جودة الصوت ('+str(len(GHJglMPq8dicaB67DbXURvowe3T))+' ملف)', GHJglMPq8dicaB67DbXURvowe3T)
				if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
					AsywcRXgd9IY5 += ' + '+GHJglMPq8dicaB67DbXURvowe3T[bCiGxXzDkH]
					lkhEPsCwpcYUF5m8HRoD1y4i = qq5efZJx26AEv8ph[bCiGxXzDkH]
					bHAYFo9MGm6gIBOReSjNLr2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
					break
		elif CH74LFlzUW3gkcxe2P=='all':
			srxZ2kiQoDIcJ3NRlS8,A1dGqPWl4FH0CgErLmcwSefnUo,zZm40svxDJBWqgd,vvAVFulUMsr = list(zip(*us5ZmETVAqtnhxrlFJb))
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الملف ('+str(len(zZm40svxDJBWqgd))+' ملف)', zZm40svxDJBWqgd)
			if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				AsywcRXgd9IY5 = zZm40svxDJBWqgd[bCiGxXzDkH]
				lJoMYGpUm3TDVBgAjfs9 = srxZ2kiQoDIcJ3NRlS8[bCiGxXzDkH]
				if 'mpd' in zZm40svxDJBWqgd[bCiGxXzDkH] and lJoMYGpUm3TDVBgAjfs9['url']!=w4Kx6sQHfSlboc8mYM27de9D1yqI:
					lkhEPsCwpcYUF5m8HRoD1y4i = A1dGqPWl4FH0CgErLmcwSefnUo[bCiGxXzDkH]
					bHAYFo9MGm6gIBOReSjNLr2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
				else: YRzpqA4JkjoOt1KC0du = lJoMYGpUm3TDVBgAjfs9['url']
				break
		elif CH74LFlzUW3gkcxe2P=='highest':
			srxZ2kiQoDIcJ3NRlS8,A1dGqPWl4FH0CgErLmcwSefnUo,zZm40svxDJBWqgd,vvAVFulUMsr = list(zip(*NdVt7BJXkGLMy14))
			lJoMYGpUm3TDVBgAjfs9 = srxZ2kiQoDIcJ3NRlS8[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM]
			if 'mpd' in zZm40svxDJBWqgd[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM] and lJoMYGpUm3TDVBgAjfs9['url']!=w4Kx6sQHfSlboc8mYM27de9D1yqI:
				lkhEPsCwpcYUF5m8HRoD1y4i = A1dGqPWl4FH0CgErLmcwSefnUo[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM]
				bHAYFo9MGm6gIBOReSjNLr2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
			else: YRzpqA4JkjoOt1KC0du = lJoMYGpUm3TDVBgAjfs9['url']
			AsywcRXgd9IY5 = zZm40svxDJBWqgd[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM]
			break
	if not bHAYFo9MGm6gIBOReSjNLr2: xMmZ3ViwDcNgT = YRzpqA4JkjoOt1KC0du
	else: xMmZ3ViwDcNgT = 'Video: '+lJoMYGpUm3TDVBgAjfs9['url']+' + Audio: '+lkhEPsCwpcYUF5m8HRoD1y4i['url']
	if bHAYFo9MGm6gIBOReSjNLr2:
		ICGU9xVBohSWkLA4RzNdT = int(lJoMYGpUm3TDVBgAjfs9['duration'])
		csoGZaKLS21 = int(lkhEPsCwpcYUF5m8HRoD1y4i['duration'])
		H07WdckxAoZF1fn4LNMOTP65eEtr = str(max(ICGU9xVBohSWkLA4RzNdT,csoGZaKLS21))
		kfrcL5RDN8a10eHTUjhgXKs7ViFm6 = lJoMYGpUm3TDVBgAjfs9['url'].replace('&','&amp;')
		uEYBcGLQMZzwy4Ue53Co2V7 = lkhEPsCwpcYUF5m8HRoD1y4i['url'].replace('&','&amp;')
		mpd = '<?xml version="1.0" encoding="UTF-8"?>\n'
		mpd += '<MPD xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="urn:mpeg:dash:schema:mpd:2011" xmlns:xlink="http://www.w3.org/1999/xlink" xsi:schemaLocation="urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd" minBufferTime="PT1.5S" mediaPresentationDuration="PT'+H07WdckxAoZF1fn4LNMOTP65eEtr+'S" type="static" profiles="urn:mpeg:dash:profile:isoff-main:2011">\n'
		mpd += '<Period>\n'
		mpd += '<AdaptationSet id="0" mimeType="video/'+lJoMYGpUm3TDVBgAjfs9['filetype']+'" subsegmentAlignment="True">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+lJoMYGpUm3TDVBgAjfs9['itag']+'" codecs="'+lJoMYGpUm3TDVBgAjfs9['codecs']+'" startWithSAP="1" bandwidth="'+str(lJoMYGpUm3TDVBgAjfs9['bitrate'])+'" width="'+str(lJoMYGpUm3TDVBgAjfs9['width'])+'" height="'+str(lJoMYGpUm3TDVBgAjfs9['height'])+'" frameRate="'+lJoMYGpUm3TDVBgAjfs9['fps']+'">\n'
		mpd += '<BaseURL>'+kfrcL5RDN8a10eHTUjhgXKs7ViFm6+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+lJoMYGpUm3TDVBgAjfs9['index']+'">\n'
		mpd += '<Initialization range="'+lJoMYGpUm3TDVBgAjfs9['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '<AdaptationSet id="1" mimeType="audio/'+lkhEPsCwpcYUF5m8HRoD1y4i['filetype']+'" subsegmentAlignment="True">\n'
		mpd += '<Role schemeIdUri="urn:mpeg:DASH:role:2011" value="main"/>\n'
		mpd += '<Representation id="'+lkhEPsCwpcYUF5m8HRoD1y4i['itag']+'" codecs="'+lkhEPsCwpcYUF5m8HRoD1y4i['codecs']+'" bandwidth="130475">\n'
		mpd += '<AudioChannelConfiguration schemeIdUri="urn:mpeg:dash:23003:3:audio_channel_configuration:2011" value="'+lkhEPsCwpcYUF5m8HRoD1y4i['audio_channels']+'"/>\n'
		mpd += '<BaseURL>'+uEYBcGLQMZzwy4Ue53Co2V7+'</BaseURL>\n'
		mpd += '<SegmentBase indexRange="'+lkhEPsCwpcYUF5m8HRoD1y4i['index']+'">\n'
		mpd += '<Initialization range="'+lkhEPsCwpcYUF5m8HRoD1y4i['init']+'" />\n'
		mpd += '</SegmentBase>\n'
		mpd += '</Representation>\n'
		mpd += '</AdaptationSet>\n'
		mpd += '</Period>\n'
		mpd += '</MPD>\n'
		if IZhXMprxvAHqBEFkg0:
			import http.server as iIekgmXJPa89vfbAw073scOUGZhEu
			import http.client as dJujeXC2cbflp6Dm08o
		else:
			import BaseHTTPServer as iIekgmXJPa89vfbAw073scOUGZhEu
			import httplib as dJujeXC2cbflp6Dm08o
		class P0CY1xtRire8UWnXdqhocOTpbyw(iIekgmXJPa89vfbAw073scOUGZhEu.HTTPServer):
			def __init__(UQtCpi5bgMm8n4,ip='localhost',port=55055,mpd='<>'):
				UQtCpi5bgMm8n4.ip = ip
				UQtCpi5bgMm8n4.port = port
				UQtCpi5bgMm8n4.mpd = mpd
				iIekgmXJPa89vfbAw073scOUGZhEu.HTTPServer.__init__(UQtCpi5bgMm8n4,(UQtCpi5bgMm8n4.ip,UQtCpi5bgMm8n4.port),fbLsM80F6cnkEGm)
				UQtCpi5bgMm8n4.mpdurl = 'http://'+ip+':'+str(port)+'/youtube.mpd'
			def start(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.threads = ps6AtMmOZI5izVcr4hF0xn9TJE7RL(SmbNGskjMx)
				UQtCpi5bgMm8n4.threads.IvgGEhRUjtAKwpTlbferO8aYHuBsd(vkIa3ijEQVsJGdWOXwK7bnue9ADR,UQtCpi5bgMm8n4.RRpuUN9mbW6TzZVIexdlnFOahQ2Loc)
			def RRpuUN9mbW6TzZVIexdlnFOahQ2Loc(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.keeprunning = Ag9l6cw3EBqP8HsQuGMizfOtr4
				while UQtCpi5bgMm8n4.keeprunning:
					UQtCpi5bgMm8n4.handle_request()
			def stop(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.keeprunning = SmbNGskjMx
				UQtCpi5bgMm8n4.ukEd2Ve9LTgtSU4nmXYDx()
			def KirqQO8ZlJ2zbXexMkAaLfDuY(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.stop()
				UQtCpi5bgMm8n4.Ri19pkguZIof.close()
				UQtCpi5bgMm8n4.server_close()
			def TLl7RQ8nZeOYbIACPyukH2F(UQtCpi5bgMm8n4,mpd):
				UQtCpi5bgMm8n4.mpd = mpd
			def ukEd2Ve9LTgtSU4nmXYDx(UQtCpi5bgMm8n4):
				IgtL0mb7hnwEpYyuf6KUxXR = dJujeXC2cbflp6Dm08o.HTTPConnection(UQtCpi5bgMm8n4.ip+':'+str(UQtCpi5bgMm8n4.port))
				IgtL0mb7hnwEpYyuf6KUxXR.request("HEAD", "/")
		class fbLsM80F6cnkEGm(iIekgmXJPa89vfbAw073scOUGZhEu.BaseHTTPRequestHandler):
			def HeKcWV1Obj4Ayknf(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.send_response(200)
				UQtCpi5bgMm8n4.send_header('Content-type','textt/plain')
				UQtCpi5bgMm8n4.end_headers()
				UQtCpi5bgMm8n4.wfile.write(UQtCpi5bgMm8n4.RWZpkDLtY5Eyb46029MvAKmqBQd8o.mpd.encode(zSafwK0sDXdMN5JReniIQmrZxp))
				lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
				if UQtCpi5bgMm8n4.path=='/youtube.mpd': UQtCpi5bgMm8n4.RWZpkDLtY5Eyb46029MvAKmqBQd8o.KirqQO8ZlJ2zbXexMkAaLfDuY()
				if UQtCpi5bgMm8n4.path=='/shutdown': UQtCpi5bgMm8n4.RWZpkDLtY5Eyb46029MvAKmqBQd8o.KirqQO8ZlJ2zbXexMkAaLfDuY()
			def JYAMbOg7h86GIqmjauNDtEnsf(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.send_response(200)
				UQtCpi5bgMm8n4.end_headers()
		mQJfTk78wuhiRqt6DWHnId = P0CY1xtRire8UWnXdqhocOTpbyw('127.0.0.1',55055,mpd)
		YRzpqA4JkjoOt1KC0du = mQJfTk78wuhiRqt6DWHnId.mpdurl
		mQJfTk78wuhiRqt6DWHnId.start()
	else: mQJfTk78wuhiRqt6DWHnId = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not YRzpqA4JkjoOt1KC0du: return 'Error    : Resolver YOUTUBE Failed',[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[[YRzpqA4JkjoOt1KC0du,coMCRv31uZ07nOGFVmwQAN4,mQJfTk78wuhiRqt6DWHnId]]
def PA3MXtUNpdknBTScuH16emlQW(url):
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-VIDBOB-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('file:"(.*?)"(,label:"(.*?)"|)\}',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items = set(items)
	items = sorted(items, reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4, key=lambda key: key[QQSugEIn2mTCpRsfcaJHhPdAWzylM])
	v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,bbKoeBcirVfzwAqZdQUFDSX,dQS7hrjxHlAnZ14b,lPpY5fw3tOBcEye91Caun2FQZ = [],[],[],[]
	if not items: return 'Error: Resolver Failed VIDBOB',[],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uiazRbmZ63Je21WGqn,NNntz8hA93kG6WqEDb1OUoeFm2fg in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('https:','http:')
		if '.m3u8' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			lPpY5fw3tOBcEye91Caun2FQZ = lPpY5fw3tOBcEye91Caun2FQZ + dQS7hrjxHlAnZ14b
			if v4pVXJWMjUC6oaQ3DY7PqKTGOSZk[f4fTutDOEwUeIoPLRQ]=='-1': bbKoeBcirVfzwAqZdQUFDSX.append('سيرفر خاص'+'   m3u8')
			else:
				for title in v4pVXJWMjUC6oaQ3DY7PqKTGOSZk:
					bbKoeBcirVfzwAqZdQUFDSX.append('سيرفر خاص'+PCnucez1ITGQbklj7SoqNtw0O8+title)
		else:
			title = 'سيرفر خاص'+'   mp4   '+NNntz8hA93kG6WqEDb1OUoeFm2fg
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def mknXS3i7th0LRWj2xaF4YgcpuzGE(url,UTvsQb4HpCP3Aeo2wDZG7X5V):
	ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc,wsXrPQaN9hZR43zWp,MOi17hVvIujyezmL,rU02bCJFWZDfVuhtMgBOyQi5P = [],[],[],[],[]
	if 'str' not in str(type(UTvsQb4HpCP3Aeo2wDZG7X5V)): UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.decode(zSafwK0sDXdMN5JReniIQmrZxp,'ignore')
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<video preload.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and not JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = []
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and not JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = []
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('direct_link.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and not JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = []
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rsplit('.',1)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title)
		NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else:
		ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('sources: *(\[.*?\])',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('var sources = (\{.*?\})',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('var jw = (\{.*?\})',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('var player = .*?\((\{.*?\})\)',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if ISmqngYzv6jrepWUx0l:
			ISmqngYzv6jrepWUx0l = ISmqngYzv6jrepWUx0l[f4fTutDOEwUeIoPLRQ]
			ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.sub(r'([\{\,][\t\s\n\r]*)(\w+[\t\s]*):',r'\1"\2":',ISmqngYzv6jrepWUx0l)
			ISmqngYzv6jrepWUx0l = dr1zfnatJxRHSF48jh0eODm5bGu('dict',ISmqngYzv6jrepWUx0l)
			if isinstance(ISmqngYzv6jrepWUx0l,dict): ISmqngYzv6jrepWUx0l = [ISmqngYzv6jrepWUx0l]
			for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
				nP8J6rQBatEoIO9T01AMW,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
				if isinstance(G4JHzTEp61,dict):
					keys = list(G4JHzTEp61.keys())
					if   'type' in keys: nP8J6rQBatEoIO9T01AMW = str(G4JHzTEp61['type'])
					if   'file' in keys: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61['file']
					elif 'hls' in keys: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61['hls']
					elif 'src' in keys: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61['src']
					if   'label' in keys: title = str(G4JHzTEp61['label'])
					elif 'video_height' in keys: title = str(G4JHzTEp61['video_height'])
					elif '.' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rsplit('.',1)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
					else: title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				elif isinstance(G4JHzTEp61,str):
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61
					title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rsplit('.',1)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
				if vkIa3ijEQVsJGdWOXwK7bnue9ADR:
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title+BhmzEC6OGD7FXZig9Tp5A+nP8J6rQBatEoIO9T01AMW)
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in zip(NWtqFg91ZSKinvIwAc,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU):
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('\\/','/')
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
		VLs4zv8ycboXT0UG7rk2fAj = MdwGcQOsmlV6vKI73THrUY4()
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = RWZpkDLtY5Eyb46029MvAKmqBQd8o+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if '.m3u8' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			headers = {'User-Agent':VLs4zv8ycboXT0UG7rk2fAj,'Referer':RWZpkDLtY5Eyb46029MvAKmqBQd8o}
			QajOiNXESemx,Dl68PgMWth = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,headers)
			MOi17hVvIujyezmL += Dl68PgMWth
			wsXrPQaN9hZR43zWp += QajOiNXESemx
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'|User-Agent='+VLs4zv8ycboXT0UG7rk2fAj+'&Referer='+RWZpkDLtY5Eyb46029MvAKmqBQd8o
			MOi17hVvIujyezmL.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			wsXrPQaN9hZR43zWp.append(title)
	uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	if MOi17hVvIujyezmL: uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = nbOFVEDkpT4BIR7Qq82yPmHeJU,wsXrPQaN9hZR43zWp,MOi17hVvIujyezmL
	else:
		if '<' not in UTvsQb4HpCP3Aeo2wDZG7X5V and len(UTvsQb4HpCP3Aeo2wDZG7X5V)<100 and UTvsQb4HpCP3Aeo2wDZG7X5V: uusxjPSpV5c = UTvsQb4HpCP3Aeo2wDZG7X5V
		else:
			msg = ScntgdOZCY74vNpXeW5jh8i.findall('<div style=".*?">(File.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not msg: msg = ScntgdOZCY74vNpXeW5jh8i.findall('<div class="vp_video_stub_txt">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not msg: msg = ScntgdOZCY74vNpXeW5jh8i.findall('<h2>(Sorry.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if msg: uusxjPSpV5c = msg[f4fTutDOEwUeIoPLRQ]
	return uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
def WkwY2x9TIB3KStndH1Nr(iHPy3of2Mkvr9b,url):
	global TTSJVE8yXumW
	url = url.strip('/')
	zq8hVp3J6dsvUN94FwcEPfLkCtM,iugaeRtZ5HFw7mJc9AdTbKlLV2 = nbOFVEDkpT4BIR7Qq82yPmHeJU,{}
	headers = {'User-Agent':MdwGcQOsmlV6vKI73THrUY4()}
	headers['Referer'] = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	headers['Accept-Language'] = 'en-US,en;q=0.9'
	headers['Sec-Fetch-Dest'] = 'iframe'
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,'RESOLVERS-XSHARING-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	kHY0cteDy7dL9sU2n = cnPhVmgFxA.code
	if not isinstance(UTvsQb4HpCP3Aeo2wDZG7X5V,str): UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.decode(zSafwK0sDXdMN5JReniIQmrZxp,'ignore')
	if 'function(p,a,c,k,e,' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		LITxrWQFSP = ScntgdOZCY74vNpXeW5jh8i.findall('(eval\(function\(p,a,c,k,e,[dr].*?)</script>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if LITxrWQFSP:
			try: zq8hVp3J6dsvUN94FwcEPfLkCtM = oWMSrt64vnzZAJlBmf0Y7cDujLxVsb(LITxrWQFSP[f4fTutDOEwUeIoPLRQ])
			except: zq8hVp3J6dsvUN94FwcEPfLkCtM = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 'function(h,u,n,t,e,r)' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		LITxrWQFSP = ScntgdOZCY74vNpXeW5jh8i.findall('(eval\(function\(h,u,n,t,e,r.*?)</script>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if LITxrWQFSP:
			try: zq8hVp3J6dsvUN94FwcEPfLkCtM = VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(LITxrWQFSP[f4fTutDOEwUeIoPLRQ])
			except: zq8hVp3J6dsvUN94FwcEPfLkCtM = nbOFVEDkpT4BIR7Qq82yPmHeJU
	fv4KNqjIBQT0UcHmlYSnrwOAWGV = UTvsQb4HpCP3Aeo2wDZG7X5V+zq8hVp3J6dsvUN94FwcEPfLkCtM
	if '"id2"' in fv4KNqjIBQT0UcHmlYSnrwOAWGV or '"id"' in fv4KNqjIBQT0UcHmlYSnrwOAWGV:
		bYpyRcGxCOV4WBS3gmrZdjMDTzL5N = url.split('/')[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb].replace('embed-',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.html',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '"id2"' in fv4KNqjIBQT0UcHmlYSnrwOAWGV: iugaeRtZ5HFw7mJc9AdTbKlLV2 = {'id2':bYpyRcGxCOV4WBS3gmrZdjMDTzL5N,'op':'download2'}
		elif '"id"' in fv4KNqjIBQT0UcHmlYSnrwOAWGV: iugaeRtZ5HFw7mJc9AdTbKlLV2 = {'id':bYpyRcGxCOV4WBS3gmrZdjMDTzL5N,'op':'download2'}
		GcYwHSWoQ0Nq8KFfJDdvujZryM = headers.copy()
		GcYwHSWoQ0Nq8KFfJDdvujZryM['Content-Type'] = 'application/x-www-form-urlencoded'
		KXFGbQxMAgBRYh = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',url,iugaeRtZ5HFw7mJc9AdTbKlLV2,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,'RESOLVERS-XSHARING-2nd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = KXFGbQxMAgBRYh.content
	rbmD62LsFjJS0gT5paOHNKBXA,lLAOqVw6tvRUX,Ru7m6PLbwQhAtn = mknXS3i7th0LRWj2xaF4YgcpuzGE(url,fv4KNqjIBQT0UcHmlYSnrwOAWGV)
	TTSJVE8yXumW[iHPy3of2Mkvr9b] = rbmD62LsFjJS0gT5paOHNKBXA,lLAOqVw6tvRUX,Ru7m6PLbwQhAtn,kHY0cteDy7dL9sU2n
	return
TTSJVE8yXumW,T8crE1S6MmOh7C5pwJUu = {},f4fTutDOEwUeIoPLRQ
def WY71asuKNIFy3hJbotx2TCMXU(url):
	global TTSJVE8yXumW,T8crE1S6MmOh7C5pwJUu
	rU02bCJFWZDfVuhtMgBOyQi5P,threads = [],[]
	T8crE1S6MmOh7C5pwJUu += 100
	y4XA5wJqRVjDn2h8oTcOHlv = T8crE1S6MmOh7C5pwJUu
	rU02bCJFWZDfVuhtMgBOyQi5P.append([vkIa3ijEQVsJGdWOXwK7bnue9ADR,url])
	TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+vkIa3ijEQVsJGdWOXwK7bnue9ADR] = [None,None,None,None]
	OUptEZs9Aq4Y = eb6R0h1Fjl.Thread(target=WkwY2x9TIB3KStndH1Nr,args=(y4XA5wJqRVjDn2h8oTcOHlv+vkIa3ijEQVsJGdWOXwK7bnue9ADR,url))
	OUptEZs9Aq4Y.start()
	OUptEZs9Aq4Y.join(10)
	if not TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+1][QQSugEIn2mTCpRsfcaJHhPdAWzylM]:
		plSscrVjkRviPwm = url.replace('/embed-','/')
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall('^(.*?://.*?)/(.*?)/(.*?)$',plSscrVjkRviPwm+'/',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		start,OlW8q2s4Uv0dXphEGnuc,end = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		end = end.strip('/')
		EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D = len(OlW8q2s4Uv0dXphEGnuc)<WtDrnpJmwQ37Z2Ae68hu4BY5M1 or OlW8q2s4Uv0dXphEGnuc in ['file','video','videoembed','ajax','iframe','mirror']
		if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([QQSugEIn2mTCpRsfcaJHhPdAWzylM,start+'/embed-'+OlW8q2s4Uv0dXphEGnuc+'/'+end])
		if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb,start+'/'+OlW8q2s4Uv0dXphEGnuc+'/embed-'+end])
		if '.html' in OlW8q2s4Uv0dXphEGnuc:
			vBuLTz940FAONjwtJXQfKEmIo = OlW8q2s4Uv0dXphEGnuc.replace('.html',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			rU02bCJFWZDfVuhtMgBOyQi5P.append([WtDrnpJmwQ37Z2Ae68hu4BY5M1,start+'/'+vBuLTz940FAONjwtJXQfKEmIo+'/'+end])
			rU02bCJFWZDfVuhtMgBOyQi5P.append([5,start+'/embed-'+vBuLTz940FAONjwtJXQfKEmIo+'/'+end])
			if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([6,start+'/'+vBuLTz940FAONjwtJXQfKEmIo+'/embed-'+end])
		elif '.html' in end:
			Q0eURSFfNkpj6d8aGXLy9 = end.replace('.html',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			rU02bCJFWZDfVuhtMgBOyQi5P.append([7,start+'/'+OlW8q2s4Uv0dXphEGnuc+'/'+Q0eURSFfNkpj6d8aGXLy9])
			if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([8,start+'/embed-'+OlW8q2s4Uv0dXphEGnuc+'/'+Q0eURSFfNkpj6d8aGXLy9])
			rU02bCJFWZDfVuhtMgBOyQi5P.append([9,start+'/'+OlW8q2s4Uv0dXphEGnuc+'/embed-'+Q0eURSFfNkpj6d8aGXLy9])
		else:
			if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([10,start+'/'+OlW8q2s4Uv0dXphEGnuc+'.html'])
			if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([11,start+'/embed-'+OlW8q2s4Uv0dXphEGnuc+'.html'])
			if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([12,start+'/'+OlW8q2s4Uv0dXphEGnuc+'/'+end+'.html'])
			if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([13,start+'/'+OlW8q2s4Uv0dXphEGnuc+'/embed-'+end+'.html'])
		if EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D and end:
			end = end.replace('/embed-','/')
			rU02bCJFWZDfVuhtMgBOyQi5P.append([14,start+'/'+end])
			rU02bCJFWZDfVuhtMgBOyQi5P.append([15,start+'/embed-'+end])
			if '.html' in end:
				Q0eURSFfNkpj6d8aGXLy9 = end.replace('.html',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				rU02bCJFWZDfVuhtMgBOyQi5P.append([16,start+'/'+Q0eURSFfNkpj6d8aGXLy9])
				rU02bCJFWZDfVuhtMgBOyQi5P.append([17,start+'/embed-'+Q0eURSFfNkpj6d8aGXLy9])
			else:
				rU02bCJFWZDfVuhtMgBOyQi5P.append([18,start+'/'+end+'.html'])
				rU02bCJFWZDfVuhtMgBOyQi5P.append([19,start+'/embed-'+end+'.html'])
		zZNIMUtsJnb4jBd0D9xeL6E1 = []
		for vLrxHDuiN08ba5pRlmUtMAIyfZX,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P[vkIa3ijEQVsJGdWOXwK7bnue9ADR:]:
			TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+vLrxHDuiN08ba5pRlmUtMAIyfZX] = [None,None,None,None]
			dAOvH3jPyxaCz9RJMN0e4omn = eb6R0h1Fjl.Thread(target=WkwY2x9TIB3KStndH1Nr,args=(y4XA5wJqRVjDn2h8oTcOHlv+vLrxHDuiN08ba5pRlmUtMAIyfZX,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6))
			dAOvH3jPyxaCz9RJMN0e4omn.start()
			zZNIMUtsJnb4jBd0D9xeL6E1.append(dAOvH3jPyxaCz9RJMN0e4omn)
			lQMuw1PvVpAk.sleep(0.75)
		for dAOvH3jPyxaCz9RJMN0e4omn in zZNIMUtsJnb4jBd0D9xeL6E1: dAOvH3jPyxaCz9RJMN0e4omn.join(10)
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	dN1ZYJmcsVKHnQLIp9MC = []
	for vLrxHDuiN08ba5pRlmUtMAIyfZX,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P:
		dkAb0HvoiPDgtrx3zGW8y,LuKM3QHIBwYDmfpRU0xn,wx9qKZ7TVArpioQJm4lM2,KmCMIQNbevOR5j7w8slruxFP0Jh2Yq = TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+vLrxHDuiN08ba5pRlmUtMAIyfZX]
		if not lPpY5fw3tOBcEye91Caun2FQZ and wx9qKZ7TVArpioQJm4lM2: bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = LuKM3QHIBwYDmfpRU0xn,wx9qKZ7TVArpioQJm4lM2
		if not uusxjPSpV5c and dkAb0HvoiPDgtrx3zGW8y: uusxjPSpV5c = dkAb0HvoiPDgtrx3zGW8y
		if KmCMIQNbevOR5j7w8slruxFP0Jh2Yq: dN1ZYJmcsVKHnQLIp9MC.append(KmCMIQNbevOR5j7w8slruxFP0Jh2Yq)
	dN1ZYJmcsVKHnQLIp9MC = list(set(dN1ZYJmcsVKHnQLIp9MC))
	if not uusxjPSpV5c and len(dN1ZYJmcsVKHnQLIp9MC)==1:
		kHY0cteDy7dL9sU2n = dN1ZYJmcsVKHnQLIp9MC[f4fTutDOEwUeIoPLRQ]
		if kHY0cteDy7dL9sU2n!=200:
			if kHY0cteDy7dL9sU2n<f4fTutDOEwUeIoPLRQ: uusxjPSpV5c = 'Video page/server is not accessible'
			else:
				uusxjPSpV5c = 'HTTP Error: '+str(kHY0cteDy7dL9sU2n)
				if IZhXMprxvAHqBEFkg0: import http.client as dJujeXC2cbflp6Dm08o
				else: import httplib as dJujeXC2cbflp6Dm08o
				try: uusxjPSpV5c += ' ( '+dJujeXC2cbflp6Dm08o.responses[kHY0cteDy7dL9sU2n]+' )'
				except: pass
	lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
	return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
class VVkiAZNDbfMq0FdHhCOL4KYm67SsG(LAkCFq8ezcf.WindowDialog):
	def __init__(UQtCpi5bgMm8n4, *args, **Ax9XPbS0kZw):
		muyTl76YbrqANX5EMHKzOVIoj2ekdg = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, 'resources', 'recaptcha2', 'dialogbg.png')
		ssr1CYDEJd5Uvzj = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, 'resources', 'recaptcha2', 'selected.png')
		TfLMtbAGKIQoqxZri6Y = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, 'resources', 'recaptcha2', 'buttonfo.png')
		NNmnElrFY0avOtfVPdbC8 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, 'resources', 'recaptcha2', 'buttonnf.png')
		prfa84bZTWomA175zsHXDEveVQROGJ = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, 'resources', 'recaptcha2', 'buttonbg.png')
		UQtCpi5bgMm8n4.cancelled = SmbNGskjMx
		UQtCpi5bgMm8n4.chk = [f4fTutDOEwUeIoPLRQ] * 9
		UQtCpi5bgMm8n4.chkbutton = [f4fTutDOEwUeIoPLRQ] * 9
		UQtCpi5bgMm8n4.chkstate = [SmbNGskjMx] * 9
		jGY5V06LUPM8, qu8LAThYsJ0cwfQ4XgGyNzlZk17UD, v6YAteBTcgF03Eb8UHdD, wf7MzlvOPipHXGKVSsd = 250, f4fTutDOEwUeIoPLRQ, 700, 760
		BpW0u5DfC2Fi1YGkRabOVPJdt4 = jGY5V06LUPM8+v6YAteBTcgF03Eb8UHdD//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		YeCSlLuX7GO2d, oHNcbMGArdm1jkDJgz, Jh68pGi2P3Kr0XwZVl79nbYUuy, awcQx9A3mogIuRJNKSz2tFYEZe = 355, 120, 500, 500
		nVemxZHP4cBoXJKuRwrDI7MCisq = YeCSlLuX7GO2d+Jh68pGi2P3Kr0XwZVl79nbYUuy//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		TD0HN5Ztsa7hOC1GoMjIe8uvUyBJ, Va7hxpjtCY0523fR8un, CO2wYaGmTrJ8E3bgBdsyF1Z9M, XsmgkdiKFP = 100, 655, 150, 50
		xxgLUpGBN9FneHE = BpW0u5DfC2Fi1YGkRabOVPJdt4-CO2wYaGmTrJ8E3bgBdsyF1Z9M-TD0HN5Ztsa7hOC1GoMjIe8uvUyBJ//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		CGW1v3hgAXat8UlfZDp6qc = BpW0u5DfC2Fi1YGkRabOVPJdt4+TD0HN5Ztsa7hOC1GoMjIe8uvUyBJ//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		GUSanVfWzrJcvkD8l1t7, kMxyQdPFgcfB2l, DPFzS3B8mY6T1yd2U7ZX5VbxEI, U5mJarh6u4WCEg2SMikTcQGAyB3 = 355, 30, 500, 50
		Twi4b1BJDpPHC, JwHQOe5ifPVu0YXkrZTI2bd, qqxN5GwiQbp7yY9kocsZvXFCzK2M, xCS1E7gQHjacbOXq8wk3UM6B0s = 355, 70, 500, 50
		LkcvQfVD3Cg649mpsTPq5uetijXz = 0.9
		jGY5V06LUPM8, qu8LAThYsJ0cwfQ4XgGyNzlZk17UD, v6YAteBTcgF03Eb8UHdD, wf7MzlvOPipHXGKVSsd = int(jGY5V06LUPM8*LkcvQfVD3Cg649mpsTPq5uetijXz), int(qu8LAThYsJ0cwfQ4XgGyNzlZk17UD*LkcvQfVD3Cg649mpsTPq5uetijXz), int(v6YAteBTcgF03Eb8UHdD*LkcvQfVD3Cg649mpsTPq5uetijXz), int(wf7MzlvOPipHXGKVSsd*LkcvQfVD3Cg649mpsTPq5uetijXz)
		YeCSlLuX7GO2d, oHNcbMGArdm1jkDJgz, Jh68pGi2P3Kr0XwZVl79nbYUuy, awcQx9A3mogIuRJNKSz2tFYEZe = int(YeCSlLuX7GO2d*LkcvQfVD3Cg649mpsTPq5uetijXz), int(oHNcbMGArdm1jkDJgz*LkcvQfVD3Cg649mpsTPq5uetijXz), int(Jh68pGi2P3Kr0XwZVl79nbYUuy*LkcvQfVD3Cg649mpsTPq5uetijXz), int(awcQx9A3mogIuRJNKSz2tFYEZe*LkcvQfVD3Cg649mpsTPq5uetijXz)
		xxgLUpGBN9FneHE, oMg7KC5OyQSIHNfGnbEmdla2e, Bn8HzhpZOfdwYWS, upxFnvOysPVSoTfKtIWQMEbU = int(xxgLUpGBN9FneHE*LkcvQfVD3Cg649mpsTPq5uetijXz), int(Va7hxpjtCY0523fR8un*LkcvQfVD3Cg649mpsTPq5uetijXz), int(CO2wYaGmTrJ8E3bgBdsyF1Z9M*LkcvQfVD3Cg649mpsTPq5uetijXz), int(XsmgkdiKFP*LkcvQfVD3Cg649mpsTPq5uetijXz)
		CGW1v3hgAXat8UlfZDp6qc, fk4CR5mJdZ2Oy3eKxMEGDNYtAscb8, AoNr1RqcLX3MOZF, BH85UsautCm62T93OkXYnEcI = int(CGW1v3hgAXat8UlfZDp6qc*LkcvQfVD3Cg649mpsTPq5uetijXz), int(Va7hxpjtCY0523fR8un*LkcvQfVD3Cg649mpsTPq5uetijXz), int(CO2wYaGmTrJ8E3bgBdsyF1Z9M*LkcvQfVD3Cg649mpsTPq5uetijXz), int(XsmgkdiKFP*LkcvQfVD3Cg649mpsTPq5uetijXz)
		GUSanVfWzrJcvkD8l1t7, kMxyQdPFgcfB2l, DPFzS3B8mY6T1yd2U7ZX5VbxEI, U5mJarh6u4WCEg2SMikTcQGAyB3 = int(GUSanVfWzrJcvkD8l1t7*LkcvQfVD3Cg649mpsTPq5uetijXz), int(kMxyQdPFgcfB2l*LkcvQfVD3Cg649mpsTPq5uetijXz), int(DPFzS3B8mY6T1yd2U7ZX5VbxEI*LkcvQfVD3Cg649mpsTPq5uetijXz), int(U5mJarh6u4WCEg2SMikTcQGAyB3*LkcvQfVD3Cg649mpsTPq5uetijXz)
		Twi4b1BJDpPHC, JwHQOe5ifPVu0YXkrZTI2bd, qqxN5GwiQbp7yY9kocsZvXFCzK2M, xCS1E7gQHjacbOXq8wk3UM6B0s = int(Twi4b1BJDpPHC*LkcvQfVD3Cg649mpsTPq5uetijXz), int(JwHQOe5ifPVu0YXkrZTI2bd*LkcvQfVD3Cg649mpsTPq5uetijXz), int(qqxN5GwiQbp7yY9kocsZvXFCzK2M*LkcvQfVD3Cg649mpsTPq5uetijXz), int(xCS1E7gQHjacbOXq8wk3UM6B0s*LkcvQfVD3Cg649mpsTPq5uetijXz)
		xQYui3Cs7JGDv9UgWeEAZ4BSX6 = LAkCFq8ezcf.ControlImage(jGY5V06LUPM8, qu8LAThYsJ0cwfQ4XgGyNzlZk17UD, v6YAteBTcgF03Eb8UHdD, wf7MzlvOPipHXGKVSsd, muyTl76YbrqANX5EMHKzOVIoj2ekdg)
		UQtCpi5bgMm8n4.addControl(xQYui3Cs7JGDv9UgWeEAZ4BSX6)
		UQtCpi5bgMm8n4.iteration = Ax9XPbS0kZw.get('iteration')
		II0B1Fd2tXH34iKc = l5JG7XwbOfo8DznU+'فحص أنا إنسان ولست روبوت         '+'المحاولة رقم  '+str(UQtCpi5bgMm8n4.iteration)+c7gxFyUCGm
		UQtCpi5bgMm8n4.strActionInfo = LAkCFq8ezcf.ControlLabel(GUSanVfWzrJcvkD8l1t7, kMxyQdPFgcfB2l, DPFzS3B8mY6T1yd2U7ZX5VbxEI, U5mJarh6u4WCEg2SMikTcQGAyB3, II0B1Fd2tXH34iKc, 'font13')
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.strActionInfo)
		X79kphTKa1xLP = LAkCFq8ezcf.ControlImage(YeCSlLuX7GO2d, oHNcbMGArdm1jkDJgz, Jh68pGi2P3Kr0XwZVl79nbYUuy, awcQx9A3mogIuRJNKSz2tFYEZe, Ax9XPbS0kZw.get('captcha'))
		UQtCpi5bgMm8n4.addControl(X79kphTKa1xLP)
		KQh3XHCco9LfvBkyrEGdiIFw7g4s = l5JG7XwbOfo8DznU+Ax9XPbS0kZw.get('msg')+c7gxFyUCGm
		UQtCpi5bgMm8n4.strActionInfo = LAkCFq8ezcf.ControlLabel(Twi4b1BJDpPHC, JwHQOe5ifPVu0YXkrZTI2bd, qqxN5GwiQbp7yY9kocsZvXFCzK2M, xCS1E7gQHjacbOXq8wk3UM6B0s, KQh3XHCco9LfvBkyrEGdiIFw7g4s, 'font13')
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.strActionInfo)
		text = l5JG7XwbOfo8DznU+'خروج'+c7gxFyUCGm
		UQtCpi5bgMm8n4.cancelbutton = LAkCFq8ezcf.ControlButton(xxgLUpGBN9FneHE, oMg7KC5OyQSIHNfGnbEmdla2e, Bn8HzhpZOfdwYWS, upxFnvOysPVSoTfKtIWQMEbU, text, focusTexture=prfa84bZTWomA175zsHXDEveVQROGJ, noFocusTexture=TfLMtbAGKIQoqxZri6Y, alignment=2)
		text = l5JG7XwbOfo8DznU+'استمرار'+c7gxFyUCGm
		UQtCpi5bgMm8n4.okbutton = LAkCFq8ezcf.ControlButton(CGW1v3hgAXat8UlfZDp6qc, fk4CR5mJdZ2Oy3eKxMEGDNYtAscb8, AoNr1RqcLX3MOZF, BH85UsautCm62T93OkXYnEcI, text, focusTexture=prfa84bZTWomA175zsHXDEveVQROGJ, noFocusTexture=TfLMtbAGKIQoqxZri6Y, alignment=2)
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.okbutton)
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.cancelbutton)
		GIXzfeDy29mVd853nbEipB7qxsU, AAhcJmMygzDFKXwjQW = awcQx9A3mogIuRJNKSz2tFYEZe//ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb, Jh68pGi2P3Kr0XwZVl79nbYUuy//ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
		for WoEZvMXa0K2suwgPl in range(9):
			vp2GZnO3VDFkKheaRw0JSMgHbYxtjf = WoEZvMXa0K2suwgPl // ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			XwqdSNcBCW5 = WoEZvMXa0K2suwgPl % ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			QwU3ikN1zgdf90 = YeCSlLuX7GO2d + (AAhcJmMygzDFKXwjQW * XwqdSNcBCW5)
			T30bpnQ6gePvY81wlECdZGH2OhMcrk = oHNcbMGArdm1jkDJgz + (GIXzfeDy29mVd853nbEipB7qxsU * vp2GZnO3VDFkKheaRw0JSMgHbYxtjf)
			UQtCpi5bgMm8n4.chk[WoEZvMXa0K2suwgPl] = LAkCFq8ezcf.ControlImage(QwU3ikN1zgdf90, T30bpnQ6gePvY81wlECdZGH2OhMcrk, AAhcJmMygzDFKXwjQW, GIXzfeDy29mVd853nbEipB7qxsU, ssr1CYDEJd5Uvzj)
			UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.chk[WoEZvMXa0K2suwgPl])
			UQtCpi5bgMm8n4.chk[WoEZvMXa0K2suwgPl].setVisible(SmbNGskjMx)
			UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl] = LAkCFq8ezcf.ControlButton(QwU3ikN1zgdf90, T30bpnQ6gePvY81wlECdZGH2OhMcrk, AAhcJmMygzDFKXwjQW, GIXzfeDy29mVd853nbEipB7qxsU, str(WoEZvMXa0K2suwgPl + vkIa3ijEQVsJGdWOXwK7bnue9ADR), font='font13', focusTexture=TfLMtbAGKIQoqxZri6Y, noFocusTexture=NNmnElrFY0avOtfVPdbC8)
			UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl])
		for WoEZvMXa0K2suwgPl in range(9):
			lcsAIn68dqF = (WoEZvMXa0K2suwgPl // ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb) * ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			uwOvHNnrY7e5V4B680qxkEjF = lcsAIn68dqF + (WoEZvMXa0K2suwgPl + vkIa3ijEQVsJGdWOXwK7bnue9ADR) % ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			xXHc4AVgskuhlBirF6weSCLmWOpJUM = lcsAIn68dqF + (WoEZvMXa0K2suwgPl - vkIa3ijEQVsJGdWOXwK7bnue9ADR) % ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			CL3RPwVZ2r = (WoEZvMXa0K2suwgPl - ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb) % 9
			zcnQadLFWRMDfvl3X8mr9kGh65p1EP = (WoEZvMXa0K2suwgPl + ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb) % 9
			UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlRight(UQtCpi5bgMm8n4.chkbutton[uwOvHNnrY7e5V4B680qxkEjF])
			UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlLeft(UQtCpi5bgMm8n4.chkbutton[xXHc4AVgskuhlBirF6weSCLmWOpJUM])
			if WoEZvMXa0K2suwgPl <= QQSugEIn2mTCpRsfcaJHhPdAWzylM:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlUp(UQtCpi5bgMm8n4.okbutton)
			else:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlUp(UQtCpi5bgMm8n4.chkbutton[CL3RPwVZ2r])
			if WoEZvMXa0K2suwgPl >= 6:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlDown(UQtCpi5bgMm8n4.okbutton)
			else:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlDown(UQtCpi5bgMm8n4.chkbutton[zcnQadLFWRMDfvl3X8mr9kGh65p1EP])
		UQtCpi5bgMm8n4.okbutton.controlLeft(UQtCpi5bgMm8n4.cancelbutton)
		UQtCpi5bgMm8n4.okbutton.controlRight(UQtCpi5bgMm8n4.cancelbutton)
		UQtCpi5bgMm8n4.cancelbutton.controlLeft(UQtCpi5bgMm8n4.okbutton)
		UQtCpi5bgMm8n4.cancelbutton.controlRight(UQtCpi5bgMm8n4.okbutton)
		UQtCpi5bgMm8n4.okbutton.controlDown(UQtCpi5bgMm8n4.chkbutton[QQSugEIn2mTCpRsfcaJHhPdAWzylM])
		UQtCpi5bgMm8n4.okbutton.controlUp(UQtCpi5bgMm8n4.chkbutton[8])
		UQtCpi5bgMm8n4.cancelbutton.controlDown(UQtCpi5bgMm8n4.chkbutton[f4fTutDOEwUeIoPLRQ])
		UQtCpi5bgMm8n4.cancelbutton.controlUp(UQtCpi5bgMm8n4.chkbutton[6])
		UQtCpi5bgMm8n4.setFocus(UQtCpi5bgMm8n4.okbutton)
	def get(UQtCpi5bgMm8n4):
		UQtCpi5bgMm8n4.doModal()
		UQtCpi5bgMm8n4.close()
		if not UQtCpi5bgMm8n4.cancelled:
			return [WoEZvMXa0K2suwgPl for WoEZvMXa0K2suwgPl in range(9) if UQtCpi5bgMm8n4.chkstate[WoEZvMXa0K2suwgPl]]
	def onControl(UQtCpi5bgMm8n4, WcyelmdGqpEXkvM):
		if WcyelmdGqpEXkvM.getId() == UQtCpi5bgMm8n4.okbutton.getId() and any(UQtCpi5bgMm8n4.chkstate):
			UQtCpi5bgMm8n4.close()
		elif WcyelmdGqpEXkvM.getId() == UQtCpi5bgMm8n4.cancelbutton.getId():
			UQtCpi5bgMm8n4.cancelled = Ag9l6cw3EBqP8HsQuGMizfOtr4
			UQtCpi5bgMm8n4.close()
		else:
			NNntz8hA93kG6WqEDb1OUoeFm2fg = WcyelmdGqpEXkvM.getLabel()
			if NNntz8hA93kG6WqEDb1OUoeFm2fg.isnumeric():
				index = int(NNntz8hA93kG6WqEDb1OUoeFm2fg) - vkIa3ijEQVsJGdWOXwK7bnue9ADR
				UQtCpi5bgMm8n4.chkstate[index] = not UQtCpi5bgMm8n4.chkstate[index]
				UQtCpi5bgMm8n4.chk[index].setVisible(UQtCpi5bgMm8n4.chkstate[index])
	def onAction(UQtCpi5bgMm8n4, rOCQ5AYBtjXwExLVlfTo0):
		if rOCQ5AYBtjXwExLVlfTo0 == 10:
			UQtCpi5bgMm8n4.cancelled = Ag9l6cw3EBqP8HsQuGMizfOtr4
			UQtCpi5bgMm8n4.close()
def T8124TfgoWpSlNRKOnaIyxLU(key,v7vZOgAQb30LNJljTKuS8Czc16,url):
	headers = {'Referer':url,'Accept-Language':v7vZOgAQb30LNJljTKuS8Czc16}
	EjzbgYNRQiI = 'http://www.google.com/recaptcha/api/fallback?k='+key
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',EjzbgYNRQiI,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-GET_RECAPTCHA2_TOKEN-1st')
	ffiueHIMq6oQxRpyO1ShacVGL4Pg,iteration = nbOFVEDkpT4BIR7Qq82yPmHeJU,f4fTutDOEwUeIoPLRQ
	while Ag9l6cw3EBqP8HsQuGMizfOtr4:
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = ScntgdOZCY74vNpXeW5jh8i.findall('"(/recaptcha/api2/payload[^"]+)', UTvsQb4HpCP3Aeo2wDZG7X5V)
		iteration += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		message = ScntgdOZCY74vNpXeW5jh8i.findall('<label[^>]+class="fbc-imageselect-message-text"[^>]*>(.*?)</label>', UTvsQb4HpCP3Aeo2wDZG7X5V)
		if not message: message = ScntgdOZCY74vNpXeW5jh8i.findall('<div[^>]+class="fbc-imageselect-message-error">(.*?)</div>', UTvsQb4HpCP3Aeo2wDZG7X5V)
		if not message:
			ffiueHIMq6oQxRpyO1ShacVGL4Pg = ScntgdOZCY74vNpXeW5jh8i.findall('readonly>(.*?)<', UTvsQb4HpCP3Aeo2wDZG7X5V)[f4fTutDOEwUeIoPLRQ]
			break
		else:
			message = message[f4fTutDOEwUeIoPLRQ]
			iugaeRtZ5HFw7mJc9AdTbKlLV2 = iugaeRtZ5HFw7mJc9AdTbKlLV2[f4fTutDOEwUeIoPLRQ]
		FhZrOPAIwHL58fES = ScntgdOZCY74vNpXeW5jh8i.findall(r'name="c"\s+value="([^"]+)', UTvsQb4HpCP3Aeo2wDZG7X5V)[f4fTutDOEwUeIoPLRQ]
		PBDV6S3uCQ0xRn4Zva = 'https://www.google.com%s' % (iugaeRtZ5HFw7mJc9AdTbKlLV2.replace('&amp;', '&'))
		message = ScntgdOZCY74vNpXeW5jh8i.sub('</?(div|strong)[^>]*>', nbOFVEDkpT4BIR7Qq82yPmHeJU, message)
		ukoU35Q42Tg = VVkiAZNDbfMq0FdHhCOL4KYm67SsG(captcha=PBDV6S3uCQ0xRn4Zva, msg=message, iteration=iteration)
		YbXOP8JFs6eUBm2u40IZGvxQpDoLh = ukoU35Q42Tg.get()
		if not YbXOP8JFs6eUBm2u40IZGvxQpDoLh: break
		data = {'c': FhZrOPAIwHL58fES, 'response': YbXOP8JFs6eUBm2u40IZGvxQpDoLh}
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'POST',EjzbgYNRQiI,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-GET_RECAPTCHA2_TOKEN-2nd')
	return ffiueHIMq6oQxRpyO1ShacVGL4Pg
def znSbGIkNEJ7ZoVlFc36KWfr4(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARABLOADS-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('color="red">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return 'Error: Resolver Failed ARABLOADS',[],[]
def H2cJulsEhx35e(url):
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def sRJ3YdvjMGkNV5ECngye(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = url.split('/')
	ltIOBcugLsVrjU0KT7z6yw = '/'.join(RWZpkDLtY5Eyb46029MvAKmqBQd8o[f4fTutDOEwUeIoPLRQ:ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb])
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ZIPPYSHARE-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('dlbutton\'\).href = "(.*?)" \+ \((.*?) \% (.*?) \+ (.*?) \% (.*?)\) \+ "(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,yWM7n98Pir0vxBftd,EK6mrvAkB1u,xxIYoGMmwBWjXP9gzhuVnTtcpb2rei,VvPDfA8Nm3dXqHK = items[f4fTutDOEwUeIoPLRQ]
		rm5wboALRxF2tlGd = int(OOajAkVTFvBQESqLmURc) % int(yWM7n98Pir0vxBftd) + int(EK6mrvAkB1u) % int(xxIYoGMmwBWjXP9gzhuVnTtcpb2rei)
		url = ltIOBcugLsVrjU0KT7z6yw + HYxdW1nBCSGI + str(rm5wboALRxF2tlGd) + VvPDfA8Nm3dXqHK
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	else: return 'Error: Resolver Failed ZIPPYSHARE',[],[]
def eh8ypgHQNvCFilYd9SsIDU1qV(url):
	id = url.split('/')[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = { "id":id , "op":"download2" }
	s0tfc7T2hwBM = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST', url, iugaeRtZ5HFw7mJc9AdTbKlLV2, headers, nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-MP4UPLOAD-1st')
	if 'Location' in list(s0tfc7T2hwBM.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = s0tfc7T2hwBM.headers['Location']
	else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else: return 'Error: Resolver Failed MP4UPLOAD',[],[]
def hwL6eBCfEiJr0gm7FlI(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-WINTVLIVE-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('mp4: \[\'(.*?)\'',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return 'Error: Resolver Failed WINTVLIVE',[],[]
def YTbE8gRUZxMFfvL2CG(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ARCHIVE-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		url = url = 'https://archive.org' + items[f4fTutDOEwUeIoPLRQ]
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ url ]
	else: return 'Error: Resolver Failed ARCHIVE',[],[]
def qfKuU98jkFOdPwv(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RESOLVERS-ESTREAM-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('video preload.*?src=.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return 'Error: Resolver Failed ESTREAM',[],[]
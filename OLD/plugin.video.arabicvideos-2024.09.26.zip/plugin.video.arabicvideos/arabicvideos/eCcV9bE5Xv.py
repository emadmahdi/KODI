# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'CIMALIGHT'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_CML_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['قنوات فضائية']
def n1zxUlcAgR(mode,url,text):
	if   mode==470: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==471: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==472: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==473: bPFto2wZdNYrClgBIEv60DJAzu = XZPY6JeohB9ODmRrgIxvuA(url,text)
	elif mode==474: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==479: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = ScntgdOZCY74vNpXeW5jh8i.findall('"url": "(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO[0].strip('/')
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,'url')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,479,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"content"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = title.replace(BhmzEC6OGD7FXZig9Tp5A,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('cat=online-movies1','cat=online-movies')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,474)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('/category.php">(.*?)"navslide-divider"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall("'dropdown-menu'(.*?)</ul>",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if title in CZrI4vYju7a: continue
		if 'مسلسل ' in title: continue
		if 'برنامج ' in title: continue
		if 'للكبار' in title: continue
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,474)
	return
def Cvflxc4FMs37bmY(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if 'topvideos.php' in url: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"caret"(.*?)id="pm-grid"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"caret"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if 'topvideos.php' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				if 'topvideos.php?c=english-movies' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				if 'topvideos.php?c=online-movies1' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				if 'topvideos.php?c=misc' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				if 'topvideos.php?c=tv-channel' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				if 'منذ البداية' in title and 'do=rating' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,471)
	else: IGDobAKtj4kPF5V(url)
	return
def IGDobAKtj4kPF5V(url,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	items = []
	if s0tfc7T2hwBM=='featured_movies':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"container-fluid"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?"title">(.*?)</div>.*?image:url\(\'(.*?)\'\)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF,iOBlEWpyGH6U1rakhzYnuM = zip(*items)
		items = zip(iOBlEWpyGH6U1rakhzYnuM,rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF)
	elif s0tfc7T2hwBM=='featured_series':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('المسلسلات المميزة(.*?)<style>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?title="(.*?)".*?image:url\(\'(.*?)\'\)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF,iOBlEWpyGH6U1rakhzYnuM = zip(*items)
		items = zip(iOBlEWpyGH6U1rakhzYnuM,rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(data-echo=".*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"BlocksList"(.*?)"titleSectionCon"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="pm-grid"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="pm-related"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pm-ul-browse-videos(.*?)clearfix',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: return
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6).strip('/')
		title = title.replace('ماي سيما',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('مشاهدة',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
		if 'http' not in X79kphTKa1xLP: X79kphTKa1xLP = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+X79kphTKa1xLP.strip('/')
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة) \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			title = '_MOD_'+title
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,472,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp and 'حلقة' in title:
			title = '_MOD_'+BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,473,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		elif '/movseries/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,471,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,473,X79kphTKa1xLP)
	if s0tfc7T2hwBM not in ['featured_movies','featured_series']:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='#': continue
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
				title = dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,471)
		MMxJvY3pH2lFNGwBIrzEVdA = ScntgdOZCY74vNpXeW5jh8i.findall('showmore" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if MMxJvY3pH2lFNGwBIrzEVdA:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = MMxJvY3pH2lFNGwBIrzEVdA[0]
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مشاهدة المزيد',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,471)
	return
def XZPY6JeohB9ODmRrgIxvuA(url,W58zOLpMh2ZTrcEemS70AUy):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-EPISODES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"SeasonsBox"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items = []
	if IHV3wWCjYv4 and not W58zOLpMh2ZTrcEemS70AUy:
		X79kphTKa1xLP = ScntgdOZCY74vNpXeW5jh8i.findall('"series-header".*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		X79kphTKa1xLP = X79kphTKa1xLP[0] if X79kphTKa1xLP else nbOFVEDkpT4BIR7Qq82yPmHeJU
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('openCity\(event\, \'(.*?)\'\)".*?>(.*?)</button>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(items)==1: W58zOLpMh2ZTrcEemS70AUy = items[0][0]
		elif len(items)>1:
			for W58zOLpMh2ZTrcEemS70AUy,title in items: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,473,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,W58zOLpMh2ZTrcEemS70AUy)
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('id="'+W58zOLpMh2ZTrcEemS70AUy+'"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc and len(items)<2:
		X79kphTKa1xLP = ScntgdOZCY74vNpXeW5jh8i.findall('"series-header".*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		X79kphTKa1xLP = X79kphTKa1xLP[0] if X79kphTKa1xLP else nbOFVEDkpT4BIR7Qq82yPmHeJU
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.replace('ماي سيما',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('مسلسل',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,472,X79kphTKa1xLP)
		else:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,472,X79kphTKa1xLP)
	if 'id="pm-related"' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		if items: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مواضيع ذات صلة',url,471)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	lPpY5fw3tOBcEye91Caun2FQZ = []
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<div itemprop="description">(.*?)href=',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('<p>(.*?)</p>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh,True): return
	plSscrVjkRviPwm = url.replace('/watch.php','/play.php')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-PLAY-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	n2lzWXLFESVAjC = []
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"embedURL" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in n2lzWXLFESVAjC:
			n2lzWXLFESVAjC.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=__embed'
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	items = ScntgdOZCY74vNpXeW5jh8i.findall("<iframe src='(.*?)'.*?<strong>(.*?)</strong>",UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in n2lzWXLFESVAjC:
			n2lzWXLFESVAjC.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	plSscrVjkRviPwm = url.replace('/watch.php','/downloads.php')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMALIGHT-PLAY-3rd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"downloadlist"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<strong>(.*?)</strong>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in n2lzWXLFESVAjC:
				n2lzWXLFESVAjC.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(zKREXyTHfVSNL8ZFYs,'url')
	url = RWZpkDLtY5Eyb46029MvAKmqBQd8o+'/search.php?keywords='+search
	IGDobAKtj4kPF5V(url,'search')
	return
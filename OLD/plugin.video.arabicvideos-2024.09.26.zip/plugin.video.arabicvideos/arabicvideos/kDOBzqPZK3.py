# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'MOVS4U'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_M4U_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['انواع افلام','جودات افلام']
def n1zxUlcAgR(mode,url,text):
	if   mode==380: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==381: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==382: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==383: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==389: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,389,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',zKREXyTHfVSNL8ZFYs,381,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجانبية',zKREXyTHfVSNL8ZFYs,381,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'sider')
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVS4U-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<header>.*?<h2>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for wDIU0SN9GBtzZPoihYnv2xjqQC in range(len(items)):
		title = items[wDIU0SN9GBtzZPoihYnv2xjqQC]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zKREXyTHfVSNL8ZFYs,381,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'latest'+str(wDIU0SN9GBtzZPoihYnv2xjqQC))
	G4JHzTEp61 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="menu"(.*?)id="contenedor"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 += eXpgPIbRv2ZMGwjm5[0]
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="sidebar(.*?)aside',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 += eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	xgSWk30lJyqA2rmUn8dNBaRTz = True
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = dCtxzeFX4GJVonm(title)
		if title=='الأعلى مشاهدة':
			if xgSWk30lJyqA2rmUn8dNBaRTz:
				title = 'الافلام '+title
				xgSWk30lJyqA2rmUn8dNBaRTz = False
			else: title = 'المسلسلات '+title
		if title not in CZrI4vYju7a:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,381)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url,type):
	G4JHzTEp61,items = [],[]
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVS4U-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if type=='search':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="search-page"(.*?)class="sidebar',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='sider':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="widget(.*?)class="widget',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		LLsZ4kViXQHKoGlhae3OBJ5T = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?img src="(.*?)".*?<h3>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		lPpY5fw3tOBcEye91Caun2FQZ,kZIdwFKsfN4qSOulRC3gcxz,bbKoeBcirVfzwAqZdQUFDSX = zip(*LLsZ4kViXQHKoGlhae3OBJ5T)
		items = zip(kZIdwFKsfN4qSOulRC3gcxz,lPpY5fw3tOBcEye91Caun2FQZ,bbKoeBcirVfzwAqZdQUFDSX)
	elif type=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="slider-movies-tvshows"(.*?)<header>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif 'latest' in type:
		wDIU0SN9GBtzZPoihYnv2xjqQC = int(type[-1:])
		UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('<header>','<end><start>')
		UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('<div class="sidebar','<end><div class="sidebar')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<start>(.*?)<end>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[wDIU0SN9GBtzZPoihYnv2xjqQC]
		if wDIU0SN9GBtzZPoihYnv2xjqQC==2: items = ScntgdOZCY74vNpXeW5jh8i.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="content"(.*?)class="(pagination|sidebar)',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0][0]
			if '/collection/' in url:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('img src="(.*?)".*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			elif '/quality/' in url:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('img src="(.*?)".*?href="(.*?)".*?"title">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items and G4JHzTEp61:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('img src="(.*?)".*?href=.*?href="(.*?)">(.*?)</div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if 'serie' in title:
			title = ScntgdOZCY74vNpXeW5jh8i.findall('^(.*?)<.*?serie">(.*?)<',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			title = title[0][1]
			if title in tWsVFQj47pw0L56rZfg: continue
			tWsVFQj47pw0L56rZfg.append(title)
			title = '_MOD_'+title
		HDE69mkhQg2NaFpuUy5JRb = ScntgdOZCY74vNpXeW5jh8i.findall('^(.*?)<',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if HDE69mkhQg2NaFpuUy5JRb: title = HDE69mkhQg2NaFpuUy5JRb[0]
		title = dCtxzeFX4GJVonm(title)
		if '/tvshows/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,383,X79kphTKa1xLP)
		elif '/episodes/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,383,X79kphTKa1xLP)
		elif '/seasons/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,383,X79kphTKa1xLP)
		elif '/collection/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,381,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,382,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination".*?Page (.*?) of (.*?)<(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		hhzWAg5bs4NeU7 = eXpgPIbRv2ZMGwjm5[0][0]
		Pl0sN2eKAHuXkGzhpQOWyB7dUb9 = eXpgPIbRv2ZMGwjm5[0][1]
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0][2]
		items = ScntgdOZCY74vNpXeW5jh8i.findall("href='(.*?)'.*?>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title==nbOFVEDkpT4BIR7Qq82yPmHeJU or title==Pl0sN2eKAHuXkGzhpQOWyB7dUb9: continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,381,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,type)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('/page/'+title+'/','/page/'+Pl0sN2eKAHuXkGzhpQOWyB7dUb9+'/')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'اخر صفحة '+Pl0sN2eKAHuXkGzhpQOWyB7dUb9,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,381,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,type)
	return
def PXyn8J3WjhRgA(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVS4U-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('class="C rated".*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh,False):
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المسلسل للكبار والمبرمج منعه',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		return
	if '/episodes/' in url or '/tvshows/' in url:
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall('''class='item'><a href="(.*?)"''',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[1]
			PXyn8J3WjhRgA(plSscrVjkRviPwm)
			return
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('''class='episodios'(.*?)id="cast"''',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('''src='(.*?)'.*?class='numerando'>(.*?)<.*?href='(.*?)'>(.*?)<''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X79kphTKa1xLP,BBuqr7CwzEIi9UL54n0AVoHXPlp,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
			title = BBuqr7CwzEIi9UL54n0AVoHXPlp+' : '+name+' الحلقة'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,382)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MOVS4U-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('class="C rated".*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	lPpY5fw3tOBcEye91Caun2FQZ = []
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('''id='player-option-1'(.*?)class=("sheader"|'pag_episodes')''',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0][0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall("data-url='(.*?)'.*?class='server'>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="remodal"(.*?)class="remodal-close"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('class="___dl_gdrive.*?href="(.*?)".*?">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/?s='+search
	IGDobAKtj4kPF5V(url,'search')
	return
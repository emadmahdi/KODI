# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'CIMA4U'
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_C4U_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def n1zxUlcAgR(mode,url,text):
	if   mode==420: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==421: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==422: bPFto2wZdNYrClgBIEv60DJAzu = m3I0Japv1Zn58kT4ExWGdYAjPNgt2(url)
	elif mode==423: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==424: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==427: bPFto2wZdNYrClgBIEv60DJAzu = fqzv6n2LTcEIAX4iNrJ1e8a(url)
	elif mode==429: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO[0].strip('/')
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,'url')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,429,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,425)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,424)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الرئيسية',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,421)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('NavigationMenu(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="*(.*?)"*>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if title in CZrI4vYju7a: continue
		if '/actors' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = 'أفلام النجوم'
		elif '/netflix' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = 'أفلام ومسلسلات نيتفلكس'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,421)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قائمة تفصيلية',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,427)
	return
def fqzv6n2LTcEIAX4iNrJ1e8a(website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('FilteringTitle(.*?)PageTitle',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for jGdXt7eADorwlv8pahNV95H6Tn2qKx,id,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if title in CZrI4vYju7a: continue
		if 'netflix-movies' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = 'مسلسلات نيتفلكس'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,421,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,jGdXt7eADorwlv8pahNV95H6Tn2qKx+'|'+id)
	return
def IGDobAKtj4kPF5V(url,it8kJjp6GIWLOEBfm3zl0H7Qr4ygq=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if not it8kJjp6GIWLOEBfm3zl0H7Qr4ygq or '|' in it8kJjp6GIWLOEBfm3zl0H7Qr4ygq:
		if '|' not in it8kJjp6GIWLOEBfm3zl0H7Qr4ygq: WWAy6qfXe5rs24 = nbOFVEDkpT4BIR7Qq82yPmHeJU
		else: WWAy6qfXe5rs24 = '/archive/'+it8kJjp6GIWLOEBfm3zl0H7Qr4ygq
		XXzySLFH501xlfQG = False
		if 'PinSlider' in UTvsQb4HpCP3Aeo2wDZG7X5V:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',url,421,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
			XXzySLFH501xlfQG = True
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('PageTitle(.*?)PageContent',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			eXBMHvPbDunL = eXpgPIbRv2ZMGwjm5[0]
			XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('data-tab="(.*?)".*?<span>(.*?)<',eXBMHvPbDunL,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for p73KEanrLbu58URNmX,HDE69mkhQg2NaFpuUy5JRb in XhE8FpdTjG:
				f7Je8XzEqNpgHL9m4OURdAQ1 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/ajaxcenter/action/HomepageLoader/tab/'+p73KEanrLbu58URNmX+WWAy6qfXe5rs24+'/'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1,421)
				XXzySLFH501xlfQG = True
		if XXzySLFH501xlfQG: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	if it8kJjp6GIWLOEBfm3zl0H7Qr4ygq=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('PinSlider(.*?)MultiFilter',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('PinSlider(.*?)PageTitle',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		else: G4JHzTEp61 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
	elif '/filter/' in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('PageContent(.*?)class="*pagination"*',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	elif '/actors' in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('PageContent(.*?)class="*pagination"*',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('Cima4uBlocks(.*?)</li></ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		else: G4JHzTEp61 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if not title: continue
		if '?news=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		title = title.replace('مشاهدة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = dCtxzeFX4GJVonm(title)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) حلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if BBuqr7CwzEIi9UL54n0AVoHXPlp and 'حلقة' in title:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,422,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		elif '/actor/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,421,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,422,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pagination(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5 and it8kJjp6GIWLOEBfm3zl0H7Qr4ygq!='featured':
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = dCtxzeFX4GJVonm(title)
			title = title.replace('الصفحة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,421)
	MMxJvY3pH2lFNGwBIrzEVdA = ScntgdOZCY74vNpXeW5jh8i.findall('</li><a href="(.*?)".*?>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if MMxJvY3pH2lFNGwBIrzEVdA:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title = MMxJvY3pH2lFNGwBIrzEVdA[0]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,421)
	return
def m3I0Japv1Zn58kT4ExWGdYAjPNgt2(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-SEASONS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="WatchNow".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		url = eXpgPIbRv2ZMGwjm5[0]
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-SEASONS-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('SeasonsSections(.*?)</div></div></div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if '/tag/' in url or '/actor' in url:
		IGDobAKtj4kPF5V(url)
	elif eXpgPIbRv2ZMGwjm5:
		X79kphTKa1xLP = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Thumb')
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall("href='(.*?)'>(.*?)<",G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		vrxV5GwBysnDe6 = ['مسلسل','موسم','برنامج','حلقة']
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in vrxV5GwBysnDe6):
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,423,X79kphTKa1xLP)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,426,X79kphTKa1xLP)
	else: PXyn8J3WjhRgA(url)
	return
def PXyn8J3WjhRgA(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	X79kphTKa1xLP = ScntgdOZCY74vNpXeW5jh8i.findall('"background-image:url\((.*?)\)',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if X79kphTKa1xLP: X79kphTKa1xLP = X79kphTKa1xLP[0]
	else: X79kphTKa1xLP = nbOFVEDkpT4BIR7Qq82yPmHeJU
	McZrvSBqofYKz6Jj5g4axuIR2VGA = ScntgdOZCY74vNpXeW5jh8i.findall('EpisodesSection(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if McZrvSBqofYKz6Jj5g4axuIR2VGA:
		G4JHzTEp61 = McZrvSBqofYKz6Jj5g4axuIR2VGA[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,BBuqr7CwzEIi9UL54n0AVoHXPlp in items:
			title = title+S3X6GcaiExOPtb+BBuqr7CwzEIi9UL54n0AVoHXPlp
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,426,X79kphTKa1xLP)
	else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'رابط التشغيل',url,426,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	bWygm5Iehls = cnPhVmgFxA.url
	if n7neb9KTv10FcU: bWygm5Iehls = bWygm5Iehls.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(bWygm5Iehls,'url')
	lPpY5fw3tOBcEye91Caun2FQZ = []
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('WatchSection(.*?)</div></div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-link="(.*?)".*? />(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for g7EnObA021BoG9dwYky,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			if 'myvid' in title.lower(): title = 'خاص '+title
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/structure/server.php?id='+g7EnObA021BoG9dwYky+'?named='+title+'__watch'
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('DownloadServers(.*?)</div></div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*? />(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			if 'myvid' in title.lower(): HDE69mkhQg2NaFpuUy5JRb = '__خاص'
			else: HDE69mkhQg2NaFpuUy5JRb = nbOFVEDkpT4BIR7Qq82yPmHeJU
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'+HDE69mkhQg2NaFpuUy5JRb
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/Search?q='+search
	IGDobAKtj4kPF5V(url,'search')
	return
def XCdegEMjq1uDz3whim(url):
	if 'smartemadfilter' not in url: url = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('MultiFilter(.*?)PageTitle',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return m8kVhKyAp7NCibFJ3sYO4EwMS
def Ubu4qfBDldYcI06(G4JHzTEp61):
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-id="(.*?)".*?</div>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return items
def wwdcMz3HCWqi(url):
	jqDXgyUVZ2 = url.split('/smartemadfilter?')[0]
	ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	url = url.replace(jqDXgyUVZ2,ksHfTPuQMGB)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
MMTo52yRJw30g6qZpPQsG = ['category','types','release-year']
TkPVaeQ9EG = ['Quality','release-year','types','category']
def bpRLN7ZqT5BiXKfMdI(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global MMTo52yRJw30g6qZpPQsG
			MMTo52yRJw30g6qZpPQsG = MMTo52yRJw30g6qZpPQsG[1:]
		if MMTo52yRJw30g6qZpPQsG[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[0]
		for WoEZvMXa0K2suwgPl in range(len(MMTo52yRJw30g6qZpPQsG[0:-1])):
			if MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	elif type=='ALL_ITEMS_FILTER':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'/smartemadfilter?'+RAf62IHC9L0OUl1oETijSgyxX5F
		plSscrVjkRviPwm = wwdcMz3HCWqi(plSscrVjkRviPwm)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',plSscrVjkRviPwm,421,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',plSscrVjkRviPwm,421,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	m8kVhKyAp7NCibFJ3sYO4EwMS = XCdegEMjq1uDz3whim(url)
	dict = {}
	for name,G4JHzTEp61,TT4Yd6yIaJGxZtoR8mh2O7 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		if '/category/' in url and TT4Yd6yIaJGxZtoR8mh2O7=='category': continue
		name = name.replace('--',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		items = Ubu4qfBDldYcI06(G4JHzTEp61)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='SPECIFIED_FILTER':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<2:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]:
					url = wwdcMz3HCWqi(url)
					IGDobAKtj4kPF5V(url)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'SPECIFIED_FILTER___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				plSscrVjkRviPwm = wwdcMz3HCWqi(plSscrVjkRviPwm)
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,421,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,425,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='ALL_ITEMS_FILTER':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع :'+name,plSscrVjkRviPwm,424,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			if XPL0O2VkI3w1C8enMaqi=='196533': PspiL81kMT4BwOIXo = 'أفلام نيتفلكس'
			elif XPL0O2VkI3w1C8enMaqi=='196531': PspiL81kMT4BwOIXo = 'مسلسلات نيتفلكس'
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			title = PspiL81kMT4BwOIXo+' :'#+dict[TT4Yd6yIaJGxZtoR8mh2O7]['0']
			title = PspiL81kMT4BwOIXo+' :'+name
			if type=='ALL_ITEMS_FILTER': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,424,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='SPECIFIED_FILTER' and MMTo52yRJw30g6qZpPQsG[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
				zb2QIaL7Y4h9g8lSck = url+'/smartemadfilter?'+soAjtN3yd04Jzr
				zb2QIaL7Y4h9g8lSck = wwdcMz3HCWqi(zb2QIaL7Y4h9g8lSck)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,421,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,425,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.replace('=&','=0&')
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for key in TkPVaeQ9EG:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('=0','=')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
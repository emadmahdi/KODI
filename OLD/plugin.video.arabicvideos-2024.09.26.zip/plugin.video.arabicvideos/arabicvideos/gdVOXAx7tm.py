# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ᩿ࠪ")
PSEgAh86NWmCQGdMKike = []
headers = {fgv5U2eRVaQqSiuGD(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᪀"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
def w1wHf7zVlYj8xaPER9dne0F2p3(source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,url):
	fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥ࡬ࡩ࡯ࡦ࡬ࡲ࡬ࠦࡶࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࡶࠤࠥࠦࠠࡔ࡫ࡷࡩ࠿࡛ࠦࠡࠩ᪁")+source+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࠤࡢࠦࠠࠡࠢࡗࡽࡵ࡫࠺ࠡ࡝ࠣࠫ᪂")+vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࠥࡣࠧ᪃"))
	VjSi2B0UsT9NtLJwgcMvahGz = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,fgv5U2eRVaQqSiuGD(u"ࠬࡪࡩࡤࡶࠪ᪄"),bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ᪅"),X1mRwt2YJKgCLu9a67(u"ࠧࡔࡋࡗࡉࡘࡥࡅࡓࡔࡒࡖࡘ࠭᪆"))
	KxjH7PYqN8LgUEQGJ2Su = lQMuw1PvVpAk.strftime(t4txivgXSUWBOlCakQmNDjf(u"ࠨࠧ࡜࠲ࠪࡳ࠮ࠦࡦࠣࠩࡍࡀࠥࡎࠩ᪇"),lQMuw1PvVpAk.gmtime(sqeRK2tVw8))
	EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U = KxjH7PYqN8LgUEQGJ2Su,url
	key = source+R4PgzXibOn3f1SxmldrWw8acs2p+JeVILUu027qW+R4PgzXibOn3f1SxmldrWw8acs2p+str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)
	CtO9cFuULSm62PWToMlzN1 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if key not in list(VjSi2B0UsT9NtLJwgcMvahGz.keys()): VjSi2B0UsT9NtLJwgcMvahGz[key] = [EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U]
	else:
		if url not in str(VjSi2B0UsT9NtLJwgcMvahGz[key]): VjSi2B0UsT9NtLJwgcMvahGz[key].append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
		else: CtO9cFuULSm62PWToMlzN1 = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࡟ࡲࠥํะศࠢส่ๆ๐ฯ๋๊้ࠣํา่ะࠢไ๎่ࠥวว็ฬࠤฬ๊แ๋ัํ์์อสࠡษ็ฮ๏ࠦไๆࠢอ฽๊๊ࠧ᪈")
	DfiBp9Te1CwXAb5zQsOh = f4fTutDOEwUeIoPLRQ
	for key in list(VjSi2B0UsT9NtLJwgcMvahGz.keys()):
		VjSi2B0UsT9NtLJwgcMvahGz[key] = list(set(VjSi2B0UsT9NtLJwgcMvahGz[key]))
		DfiBp9Te1CwXAb5zQsOh += len(VjSi2B0UsT9NtLJwgcMvahGz[key])
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭᪉"),bnI4kmPtrW7yFEhljXOCq9(u"้๊ࠫริใࠣห้ฮั็ษ่ะ๊ࠥๅࠡ์ฯำ๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠬ᪊")+CtO9cFuULSm62PWToMlzN1+Fo1SgXMsHk(u"ࠬࡢ࡮࡝ࡰ่้ࠣ฿ไๆࠢส่อืๆศ็ฯࠤ๏่่ๆࠢหะ๊฿ࠠใษษ้ฮࠦศศๆไ๎ิ๐่่ษอࠤฬ๊ส๋ࠢ็้ࠥ๐ฬะࠢ็๋ฬࠦๅๅใสฮࠥ็๊ะ์๋ࠤํู่โࠢํ฽ึ฼ฺࠠๆํ็ࠥอไษำ้ห๊าࠠฤ่ࠣฮึูไ้ࠡำ๋ࠥอไใษษ้ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ฾์ฯๆษࠣ๎ฺฮอࠡ฻าำ์อࠠ࠶ࠢไ๎ิ๐่่ษอࠫ᪋")+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭࡜࡯࡞ࡱࠫ᪌")+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ฺࠧัาࠤฬ๊แ๋ัํ์์อสࠡใํࠤฬ๊โศศ่อࠥอไร่๋ࠣํࠦ࠺ࠡࠢࠪ᪍")+str(DfiBp9Te1CwXAb5zQsOh))
	if DfiBp9Te1CwXAb5zQsOh>=DJ6ugPjW9bX8I(u"࠷ड़"):
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪎"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩส่อืๆศ็ฯࠤัู๋ࠡไสส๊ฯࠠโ์๊หࠥ࠻ࠠโ์า๎ํํวหࠢ็้ࠥ๐ฬะࠢส่อืๆศ็ฯࠤ้ํวࠡ็็ๅฬะࠠโ์า๎ํࠦ࠮࠯ࠢึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤอ๋ำฮ๊ࠢิ์ࠦวๅไสส๊ฯࠠ࡝ࡰ࡟ࡲࠥํไࠡฬิ๎ิࠦลาีส่ࠥํะ่ࠢส่็อฦๆหࠣๆอ๊ࠠๆีะ๋ฬࠦลๅ๋ࠣห้๋ศา็ฯࠤ้้๊ࠡ์ๅ์๊ࠦวๅ็หี๊าࠠษใะูࠥํะ่ࠢส่ๆ๐ฯ๋๊๊หฯࠦฟࠢࠣࠪ᪏"))
		if oyNUHM3uQq==Fo1SgXMsHk(u"࠴ढ़"):
			ldXSONaGmEQyckuhw = nbOFVEDkpT4BIR7Qq82yPmHeJU
			for key in list(VjSi2B0UsT9NtLJwgcMvahGz.keys()):
				ldXSONaGmEQyckuhw += wwOnIucWJj+key
				lcmuZp6W1DHq92 = sorted(VjSi2B0UsT9NtLJwgcMvahGz[key],reverse=SmbNGskjMx,key=lambda Pt5va0fRAFND1eQy2Wid: Pt5va0fRAFND1eQy2Wid[f4fTutDOEwUeIoPLRQ])
				for KxjH7PYqN8LgUEQGJ2Su,url in lcmuZp6W1DHq92:
					ldXSONaGmEQyckuhw += wwOnIucWJj+KxjH7PYqN8LgUEQGJ2Su+R4PgzXibOn3f1SxmldrWw8acs2p+SxN0jnqr3LI(url)
				ldXSONaGmEQyckuhw += QlTuvPbSpnjygBVW(u"ࠪࡠࡳࡢ࡮ࠨ᪐")
			import SJqrPsfTgG
			EJNf2kglaiQHnFGe531Iq = SJqrPsfTgG.Rs07nFAOYjCQN(fgv5U2eRVaQqSiuGD(u"࡛ࠫ࡯ࡤࡦࡱࡶࠫ᪑"),nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡏࡅ࡞ࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᪒"),nbOFVEDkpT4BIR7Qq82yPmHeJU,ldXSONaGmEQyckuhw)
			if EJNf2kglaiQHnFGe531Iq: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ᪓"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧห็ࠣห้หัิษ็ࠤอ์ฬศฯࠪ᪔"))
			else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ᪕"),Fo1SgXMsHk(u"ࠩไุ้ะฺࠠ็็๎ฮࠦวๅวิืฬ๊ࠧ᪖"))
		if oyNUHM3uQq!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			VjSi2B0UsT9NtLJwgcMvahGz = {}
			uoxvtFlSXEPnf(SOEM49TbV0zuQ,bYyKEjIuGQzoq3AR1(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭᪗"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡘࡏࡔࡆࡕࡢࡉࡗࡘࡏࡓࡕࠪ᪘"))
	if VjSi2B0UsT9NtLJwgcMvahGz: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,UpQ56M0dO1N9xIvVegy(u"ࠬࡓࡉࡔࡅࡢࡔࡊࡘࡍࠨ᪙"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡓࡊࡖࡈࡗࡤࡋࡒࡓࡑࡕࡗࠬ᪚"),VjSi2B0UsT9NtLJwgcMvahGz,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	return
def ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,url):
	if not NWtqFg91ZSKinvIwAc:
		w1wHf7zVlYj8xaPER9dne0F2p3(source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,url)
		return
	NWtqFg91ZSKinvIwAc = list(set(NWtqFg91ZSKinvIwAc))
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = IWXqZsVg1r5K3CvDb8kyUGcBfM(NWtqFg91ZSKinvIwAc,source)
	if QQ3hd2tR8s.resolveonly:
		dTs6tnqwXz2HoUiGQ7ESV8O = OrBPj5VNKUkz4hnIfCwxFD1aXGoZ(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,source,SmbNGskjMx)
		return
	cKsqgTefanYEr8PkwGo90xAJMi6,uusxjPSpV5c,Sx02JNGA3dqDrzycFTVZbHpWPj,dTs6tnqwXz2HoUiGQ7ESV8O = SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	iwv5QCcjR0b = not any(XPL0O2VkI3w1C8enMaqi in source for XPL0O2VkI3w1C8enMaqi in kkbtlN2PnKsIXuH)
	if iwv5QCcjR0b:
		DwK4lEg72p30Sn5FJzeA = f4fTutDOEwUeIoPLRQ
		JGbnFdKQ2N7LgzHUmCr = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,z3sIGH8jmLYg(u"ࠧ࡭࡫ࡶࡸࠬ᪛"),SSvu1CZjTW7FcloNqD(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭᪜"))
		KOWAPEai6F15vwhzBYI = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࡯࡭ࡸࡺࠧ᪝"),bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤࡌࡁࡊࡎࡈࡈࠬ᪞"))
		wDIU0SN9GBtzZPoihYnv2xjqQC = f4fTutDOEwUeIoPLRQ
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in zip(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ):
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split(YayJj10OGl(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᪟"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in JGbnFdKQ2N7LgzHUmCr:
				DwK4lEg72p30Sn5FJzeA += vkIa3ijEQVsJGdWOXwK7bnue9ADR
				bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC] = Tm7XlOI1kSsg5L9Znd3RJVorD+title+c7gxFyUCGm
			elif grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in KOWAPEai6F15vwhzBYI:
				DwK4lEg72p30Sn5FJzeA += vkIa3ijEQVsJGdWOXwK7bnue9ADR
				bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC] = eMypvI8XqHjYU02anWD9gsSrkt+title+c7gxFyUCGm
			wDIU0SN9GBtzZPoihYnv2xjqQC += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		xB2lOZNsPvFQDC4gMz = [l5JG7XwbOfo8DznU+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬ็อึࠢฯ้๏฿ࠠศๆึ๎ึ็ัศฬࠪ᪠")+c7gxFyUCGm]
	else: VEk5w62oP1nNy8sKjhxeaRU9 = l5JG7XwbOfo8DznU+q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭รฯฬิࠤฬ๊ำ๋ำไีࠥอไๆ่สือ࠭᪡")+c7gxFyUCGm
	while Ag9l6cw3EBqP8HsQuGMizfOtr4:
		ZjD9cUtb8X1JsPmyqBSgKzWlA = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if iwv5QCcjR0b:
			if len(bbKoeBcirVfzwAqZdQUFDSX)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: bCiGxXzDkH = vkIa3ijEQVsJGdWOXwK7bnue9ADR
			else:
				IICzQoSV6aFJhfGpWtkv = str(bbKoeBcirVfzwAqZdQUFDSX).count(Tm7XlOI1kSsg5L9Znd3RJVorD)
				HW9QwFLz0Sa4UGJKeVE5DIcN = str(bbKoeBcirVfzwAqZdQUFDSX).count(eMypvI8XqHjYU02anWD9gsSrkt)
				ESpzQHrteGmYouk0w7xMJ = len(bbKoeBcirVfzwAqZdQUFDSX)-IICzQoSV6aFJhfGpWtkv-HW9QwFLz0Sa4UGJKeVE5DIcN
				if n7neb9KTv10FcU: VEk5w62oP1nNy8sKjhxeaRU9 = eMypvI8XqHjYU02anWD9gsSrkt+I3cxjYaHhsrM7T4UX26klN(u"ࠧࠡࠢࠣื๏ฬษ࠻ࠩ᪢")+str(HW9QwFLz0Sa4UGJKeVE5DIcN)+c7gxFyUCGm+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࠢࠣࠤ๊า็้ๆฬ࠾ࠬ᪣")+str(ESpzQHrteGmYouk0w7xMJ)+Tm7XlOI1kSsg5L9Znd3RJVorD+fgv5U2eRVaQqSiuGD(u"ࠩฯ๎ิฯ࠺ࠨ᪤")+str(IICzQoSV6aFJhfGpWtkv)+c7gxFyUCGm
				else: VEk5w62oP1nNy8sKjhxeaRU9 = Tm7XlOI1kSsg5L9Znd3RJVorD+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪะ๏ีษ࠻ࠩ᪥")+str(IICzQoSV6aFJhfGpWtkv)+c7gxFyUCGm+fgv5U2eRVaQqSiuGD(u"ࠫࠥࠦࠠๆฮ๊์้ฯ࠺ࠨ᪦")+str(ESpzQHrteGmYouk0w7xMJ)+eMypvI8XqHjYU02anWD9gsSrkt+fgv5U2eRVaQqSiuGD(u"ࠬࠦࠠࠡีํสฮࡀࠧᪧ")+str(HW9QwFLz0Sa4UGJKeVE5DIcN)+c7gxFyUCGm
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr(VEk5w62oP1nNy8sKjhxeaRU9,xB2lOZNsPvFQDC4gMz+bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==f4fTutDOEwUeIoPLRQ:
				ZjD9cUtb8X1JsPmyqBSgKzWlA = SmbNGskjMx
				start,end = f4fTutDOEwUeIoPLRQ,len(bbKoeBcirVfzwAqZdQUFDSX)-vkIa3ijEQVsJGdWOXwK7bnue9ADR
				dTs6tnqwXz2HoUiGQ7ESV8O = OrBPj5VNKUkz4hnIfCwxFD1aXGoZ(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,source,Ag9l6cw3EBqP8HsQuGMizfOtr4)
				Sx02JNGA3dqDrzycFTVZbHpWPj = cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࡠࡣ࡯ࡰࠬ᪨") if dTs6tnqwXz2HoUiGQ7ESV8O else wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧ࡯ࡱࡷࡣࡷ࡫ࡳࡰ࡮ࡹࡥࡧࡲࡥࠨ᪩")
			elif bCiGxXzDkH>f4fTutDOEwUeIoPLRQ: start,end = bCiGxXzDkH-vkIa3ijEQVsJGdWOXwK7bnue9ADR,bCiGxXzDkH-vkIa3ijEQVsJGdWOXwK7bnue9ADR
		else:
			if len(bbKoeBcirVfzwAqZdQUFDSX)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: bCiGxXzDkH = f4fTutDOEwUeIoPLRQ
			else: bCiGxXzDkH = nnRXQH90qeOtABkJzGr(VEk5w62oP1nNy8sKjhxeaRU9,bbKoeBcirVfzwAqZdQUFDSX)
			start,end = bCiGxXzDkH,bCiGxXzDkH
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			Sx02JNGA3dqDrzycFTVZbHpWPj = z3sIGH8jmLYg(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪ᪪")
			break
		if ZjD9cUtb8X1JsPmyqBSgKzWlA:
			Sx02JNGA3dqDrzycFTVZbHpWPj = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࡣࡴࡴࡥࠨ᪫")
			dTs6tnqwXz2HoUiGQ7ESV8O = OrBPj5VNKUkz4hnIfCwxFD1aXGoZ([bbKoeBcirVfzwAqZdQUFDSX[start]],[lPpY5fw3tOBcEye91Caun2FQZ[start]],source,Ag9l6cw3EBqP8HsQuGMizfOtr4)
			title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uusxjPSpV5c,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = dTs6tnqwXz2HoUiGQ7ESV8O[f4fTutDOEwUeIoPLRQ]
			gruajX8IpBzV97JnPKs5F4AlMUwR,yH5pcaAJgdvU = GdRbXfmZaPgM6ikSlc4eWLETVoNy8(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P,source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG)
			if gruajX8IpBzV97JnPKs5F4AlMUwR in [q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠨ᪬"),l4DS8mnEjHhFMZ5YOe(u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ᪭"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡺࡥࡴࡶ࡬ࡲ࡬࠭᪮")]:
				cKsqgTefanYEr8PkwGo90xAJMi6 = Ag9l6cw3EBqP8HsQuGMizfOtr4
				break
			else:
				uusxjPSpV5c = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡪࡦ࡯࡬ࡦࡦࠪ᪯")
				title = eMypvI8XqHjYU02anWD9gsSrkt+title+c7gxFyUCGm
				dTs6tnqwXz2HoUiGQ7ESV8O[f4fTutDOEwUeIoPLRQ] = title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uusxjPSpV5c,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P
				QSNHrmDRv6puBK9cxdsjJOVeMoXyia = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split(flDSRbv57PnV3(u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ᪰"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
				uoxvtFlSXEPnf(SOEM49TbV0zuQ,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗ࡚ࡉࡃࡆࡇࡇࡉࡉ࠭᪱"),QSNHrmDRv6puBK9cxdsjJOVeMoXyia)
				z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡇࡣࡋࡇࡉࡍࡇࡇࠫ᪲"),QSNHrmDRv6puBK9cxdsjJOVeMoXyia,[uusxjPSpV5c,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6],RRYx6sACloVPr3td95Ej)
			if uusxjPSpV5c==I3cxjYaHhsrM7T4UX26klN(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᪳"): break
			oOFlVdqEv9haMXwpHiPZUyArG3ux = QlTuvPbSpnjygBVW(u"ࠫࡠࡒࡅࡇࡖࡠࠤࠥ࠭᪴")+uusxjPSpV5c.replace(wwOnIucWJj,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡢ࡮࡜ࡎࡈࡊ࡙ࡣ᪵ࠠࠡࠩ")) if wwOnIucWJj in uusxjPSpV5c else uusxjPSpV5c
			if fsQukcZeJ8YbozTXKEvS7h306DCA(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ᪶ࠧ") not in source: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮ᪷ࠪ"),bYyKEjIuGQzoq3AR1(u"ࠨษ็ื๏ืแาࠢ็้ࠥ๐ูๆๆࠣะึฮࠠิ์ิๅึฺ๋ࠦำ๊᪸ࠫ")+wwOnIucWJj+oOFlVdqEv9haMXwpHiPZUyArG3ux,profile=usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯ࡢࡱࡪࡪࡩࡶ࡯ࡩࡳࡳࡺ᪹ࠧ"))
			if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR and uusxjPSpV5c: break
		for wDIU0SN9GBtzZPoihYnv2xjqQC in range(start,end+vkIa3ijEQVsJGdWOXwK7bnue9ADR):
			KZi5k4Dag1GNFObAJ9ML3XYqd0 = f4fTutDOEwUeIoPLRQ if ZjD9cUtb8X1JsPmyqBSgKzWlA else wDIU0SN9GBtzZPoihYnv2xjqQC
			title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uusxjPSpV5c,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = dTs6tnqwXz2HoUiGQ7ESV8O[KZi5k4Dag1GNFObAJ9ML3XYqd0]
			bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC] = bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC].replace(eMypvI8XqHjYU02anWD9gsSrkt,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(Tm7XlOI1kSsg5L9Znd3RJVorD,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if uusxjPSpV5c: bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC] = eMypvI8XqHjYU02anWD9gsSrkt+bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC]+c7gxFyUCGm
			else: bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC] = Tm7XlOI1kSsg5L9Znd3RJVorD+bbKoeBcirVfzwAqZdQUFDSX[wDIU0SN9GBtzZPoihYnv2xjqQC]+c7gxFyUCGm
	if Sx02JNGA3dqDrzycFTVZbHpWPj==YayJj10OGl(u"ࠪࡲࡴࡺ࡟ࡳࡧࡶࡳࡱࡼࡡࡣ࡮ࡨ᪺ࠫ"): aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,qrjy8LuKVPNYdbSvzh(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ᪻"),UpQ56M0dO1N9xIvVegy(u"๊ࠬไฤีไࠤ้อ๋๊ࠠฯำู๊ࠥาใิหฯࠦฬ๋ัฬࠤๆ๐่ࠠาสࠤฬ๊แ๋ัํ์ࠥ࠴࠮ࠡฯส์้ࠦร็ࠢอฬาัฺ่๋ࠠࠣีอࠠศๆไ๎ิ๐่ࠡใํࠤ๊๎วใ฻ࠣวำื้ࠡใํࠤ์ึวࠡษ็ฬึ์วๆฮࠪ᪼"))
	if not cKsqgTefanYEr8PkwGo90xAJMi6 or Sx02JNGA3dqDrzycFTVZbHpWPj in [QlTuvPbSpnjygBVW(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨ᪽"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧ࡯ࡱࡷࡣࡷ࡫ࡳࡰ࡮ࡹࡥࡧࡲࡥࠨ᪾")] or uusxjPSpV5c:
		V5VsTuKOPYNQvkcX2 = RarSo2nTfwU0WEGK.executeJSONRPC(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧ࡯ࡤࠣ࠼࠴࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠰ࡆࡰࡪࡧࡲࠣ࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡪࡦࠥ࠾࠶ࢃࡽࠨᪿ"))
	return
nPI56Ug8wj9My0fDscBETLHzAoXN,hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz,qs8JfMYReZAC = [],[],[],[],[],[]
def OrBPj5VNKUkz4hnIfCwxFD1aXGoZ(ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc,source,showDialogs):
	global nPI56Ug8wj9My0fDscBETLHzAoXN,hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz,qs8JfMYReZAC
	bPFto2wZdNYrClgBIEv60DJAzu,SSeYZRtvzpFrLmUgIf3T,new = [],[],[]
	Zb4NIBy16VvWF(SmbNGskjMx,SmbNGskjMx,SmbNGskjMx)
	count = len(NWtqFg91ZSKinvIwAc)
	for ablZij8g2sVkIB4m1pTKz3qEtx in range(count):
		nPI56Ug8wj9My0fDscBETLHzAoXN.append(None)
		hhvF5yW4kQ1dxCLm83BfATlZ.append(None)
		WywD1Y9fE4dOtLFZxgGJ6.append(None)
		SSaiGHeLq7KwAI4UTQJ.append(None)
		UmRopiJqVk9ljYde2Agz.append(None)
		qs8JfMYReZAC.append(f4fTutDOEwUeIoPLRQ)
		title = ifOk5xt1uHRJrTGFB7zZaeKIs6bqU[ablZij8g2sVkIB4m1pTKz3qEtx]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[ablZij8g2sVkIB4m1pTKz3qEtx].strip(S3X6GcaiExOPtb).strip(X60YQOADpkHBb31LiR5qUEKfM(u"ᫀࠩࠩࠫ")).strip(qrjy8LuKVPNYdbSvzh(u"ࠪࡃࠬ᫁")).strip(X60YQOADpkHBb31LiR5qUEKfM(u"ࠫ࠴࠭᫂"))
		if count>vkIa3ijEQVsJGdWOXwK7bnue9ADR and showDialogs: SSVCGE0bOfW1w9u52yvBxocNeP(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬ็อึࠢึ๎ึ็ัࠡำๅ้᫃ࠥࠦࠧ")+str(ablZij8g2sVkIB4m1pTKz3qEtx+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠵फ़")),title)
		PfJB8eMn4qwuRSHQAyd27TUlF = [z3sIGH8jmLYg(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ᫄ࠧ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠬ᫅"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡃࡎ࡛ࡆࡓࠧ᫆")]
		if source in PfJB8eMn4qwuRSHQAyd27TUlF: nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx] = wXCn0qZ1zB7egRv(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,ablZij8g2sVkIB4m1pTKz3qEtx)
		else:
			if wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠶य़"):
				fcWPXxCE0mY9vk1 = eb6R0h1Fjl.Thread(target=wXCn0qZ1zB7egRv,args=(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,ablZij8g2sVkIB4m1pTKz3qEtx))
				fcWPXxCE0mY9vk1.start()
				SSeYZRtvzpFrLmUgIf3T.append(fcWPXxCE0mY9vk1)
				new.append(ablZij8g2sVkIB4m1pTKz3qEtx)
				lQMuw1PvVpAk.sleep(bYyKEjIuGQzoq3AR1(u"࠷ॠ"))
	timeout = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠶࠱ॡ") if source==qrjy8LuKVPNYdbSvzh(u"ࠩࡄࡏ࡜ࡇࡍࠨ᫇") else YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠴࠲ॢ")
	BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
	for fcWPXxCE0mY9vk1 in SSeYZRtvzpFrLmUgIf3T: fcWPXxCE0mY9vk1.join(timeout)
	for ablZij8g2sVkIB4m1pTKz3qEtx in range(count):
		title = ifOk5xt1uHRJrTGFB7zZaeKIs6bqU[ablZij8g2sVkIB4m1pTKz3qEtx]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[ablZij8g2sVkIB4m1pTKz3qEtx].strip(S3X6GcaiExOPtb).strip(UpQ56M0dO1N9xIvVegy(u"ࠪࠪࠬ᫈")).strip(ulAxHwvzR9eTb5n(u"ࠫࡄ࠭᫉")).strip(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬ࠵᫊ࠧ"))
		dhV16pObPmLnw3l8QEj0X7rSqG = Ag9l6cw3EBqP8HsQuGMizfOtr4 if qs8JfMYReZAC[ablZij8g2sVkIB4m1pTKz3qEtx]+vkIa3ijEQVsJGdWOXwK7bnue9ADR>timeout else SmbNGskjMx
		if len(nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx])==ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb and (nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx][f4fTutDOEwUeIoPLRQ] or nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx][QQSugEIn2mTCpRsfcaJHhPdAWzylM]): oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1 = nPI56Ug8wj9My0fDscBETLHzAoXN[ablZij8g2sVkIB4m1pTKz3qEtx]
		elif dhV16pObPmLnw3l8QEj0X7rSqG: oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1 = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭࡜࡯ࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࡘ࡮ࡳࡥࡥࠢࡒࡹࡹࠦࠨࠨ᫋")+str(timeout)+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࠡࡵࡨࡧࡴࡴࡤࡴࠫࠪᫌ"),[],[]
		else: oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1 = X1mRwt2YJKgCLu9a67(u"ࠨ࡞ࡱࡊࡦ࡯࡬ࡦࡦ࠽ࠤࠥࡉ࡯ࡶ࡮ࡧࠤࡳࡵࡴࠡࡨ࡬ࡲࡩࠦࡴࡩࡧࠣࡺ࡮ࡪࡥࡰࠢࡩ࡭ࡱ࡫ࠧᫍ"),[],[]
		bPFto2wZdNYrClgBIEv60DJAzu.append([title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1])
		if ablZij8g2sVkIB4m1pTKz3qEtx in new:
			QSNHrmDRv6puBK9cxdsjJOVeMoXyia = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᫎ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]
			if not oOFlVdqEv9haMXwpHiPZUyArG3ux: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,z3sIGH8jmLYg(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡈࡤ࡙ࡕࡄࡅࡈࡉࡉࡋࡄࠨ᫏"),QSNHrmDRv6puBK9cxdsjJOVeMoXyia,[oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1],RRYx6sACloVPr3td95Ej)
			else: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡉࡥࡆࡂࡋࡏࡉࡉ࠭᫐"),QSNHrmDRv6puBK9cxdsjJOVeMoXyia,[oOFlVdqEv9haMXwpHiPZUyArG3ux,HDE69mkhQg2NaFpuUy5JRb,f7Je8XzEqNpgHL9m4OURdAQ1],RRYx6sACloVPr3td95Ej)
	Zb4NIBy16VvWF(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return bPFto2wZdNYrClgBIEv60DJAzu
def wXCn0qZ1zB7egRv(RWZpkDLtY5Eyb46029MvAKmqBQd8o,url,source,UUfw8Ld24pDl5xbHRhe):
	global nPI56Ug8wj9My0fDscBETLHzAoXN,qs8JfMYReZAC
	qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = f4fTutDOEwUeIoPLRQ
	BfM7ldYzjy5qVPoeJuN2QEpL9 = lQMuw1PvVpAk.time()
	fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࠦࠠࠡࡔࡨࡷࡴࡲࡶࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭᫑")+RWZpkDLtY5Eyb46029MvAKmqBQd8o+X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࠠ࡞ࠢࠣࠤࡔࡸࡩࡨ࡫ࡱࡥࡱࡀࠠ࡜ࠢࠪ᫒")+url+Fo1SgXMsHk(u"ࠧࠡ࡟ࠪ᫓"))
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,zGcM56Ki1lfB8TZPtVHeXb = url,nbOFVEDkpT4BIR7Qq82yPmHeJU
	Tks3rDNUeEqh6 = z3sIGH8jmLYg(u"ࠨࡋࡑࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ᫔")
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = iXgJUrjoMmF8hzs(url,source)
	if uusxjPSpV5c==Fo1SgXMsHk(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᫕"):
		nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = X1mRwt2YJKgCLu9a67(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ᫖"),[],[]
		qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9
		return nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe]
	elif xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᫗") in uusxjPSpV5c:
		zGcM56Ki1lfB8TZPtVHeXb = DJ6ugPjW9bX8I(u"ࠬࡢ࡮ࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥࠦࡎࡦࡧࡧࠤࡊࡾࡴࡦࡴࡱࡥࡱࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠨ᫘")
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)[f4fTutDOEwUeIoPLRQ]
		Tks3rDNUeEqh6,zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = i0RIJo5SetVpOGdAyUbQ4v9NxnB3(zGcM56Ki1lfB8TZPtVHeXb,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,UUfw8Ld24pDl5xbHRhe)
		if zGcM56Ki1lfB8TZPtVHeXb==YayJj10OGl(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᫙"):
			qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9
			return zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	elif uusxjPSpV5c: zGcM56Ki1lfB8TZPtVHeXb = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡓࡧࡶࡳࡱࡼࡥࡳࠢ࠴࠾ࠥࠦࠧ᫚")+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠺࠳ॣ")]
	if lPpY5fw3tOBcEye91Caun2FQZ:
		lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
		fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+YayJj10OGl(u"ࠨࠢࠣࠤࡗ࡫ࡳࡰ࡮ࡹ࡭ࡳ࡭ࠠࡴࡷࡦࡧࡪ࡫ࡤࡦࡦࠣࠤ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪ࠺ࠡ࡝ࠣࠫ᫛")+RWZpkDLtY5Eyb46029MvAKmqBQd8o+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࠣࡡࠥࠦࠠࡓࡧࡶࡳࡱࡼࡥࡳ࠼ࠣ࡟ࠥ࠭᫜")+Tks3rDNUeEqh6+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࠤࡢࠦࠠࠡࡑࡵ࡭࡬࡯࡮ࡢ࡮࠽ࠤࡠࠦࠧ᫝")+url+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫࠥࡣࠠࠡࠢࡏ࡭ࡳࡱ࠺ࠡ࡝ࠣࠫ᫞")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+X1mRwt2YJKgCLu9a67(u"ࠬࠦ࡝࡚ࠡࠢࠣ࡮ࡪࡥࡰࡵ࠽ࠤࡠࠦࠧ᫟")+str(lPpY5fw3tOBcEye91Caun2FQZ)+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࠠ࡞ࠩ᫠"))
	else: fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࠡࠢࠣࡖࡪࡹ࡯࡭ࡸ࡬ࡲ࡬ࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡕࡨࡰࡪࡩࡴࡦࡦ࠽ࠤࡠࠦࠧ᫡")+RWZpkDLtY5Eyb46029MvAKmqBQd8o+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ᫢")+url+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ᫣")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+bYyKEjIuGQzoq3AR1(u"ࠪࠤࡢࠦࠠࠡࡇࡵࡶࡴࡸࡳ࠻ࠢ࡞ࠤࠬ᫤")+zGcM56Ki1lfB8TZPtVHeXb+l4DS8mnEjHhFMZ5YOe(u"ࠫࠥࡣࠧ᫥"))
	zGcM56Ki1lfB8TZPtVHeXb = SxN0jnqr3LI(zGcM56Ki1lfB8TZPtVHeXb)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	qs8JfMYReZAC[UUfw8Ld24pDl5xbHRhe] = lQMuw1PvVpAk.time()-BfM7ldYzjy5qVPoeJuN2QEpL9
	return zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def GdRbXfmZaPgM6ikSlc4eWLETVoNy8(title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if lPpY5fw3tOBcEye91Caun2FQZ:
		while Ag9l6cw3EBqP8HsQuGMizfOtr4:
			if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: bCiGxXzDkH = f4fTutDOEwUeIoPLRQ
			else: bCiGxXzDkH = nnRXQH90qeOtABkJzGr(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬอฮหำࠣห้๋ไโࠢส่๊์วิส࠽ࠫ᫦"), bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: yi6wOauQ3Sb1JUBt4 = X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡣࡢࡰࡦࡩࡱ࡫ࡤࠨ᫧")
			else:
				kk4bAafDCZm7XQJis0PBqp1Weul = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
				fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+Fo1SgXMsHk(u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡔࡧ࡯ࡩࡨࡺࡥࡥ࠼ࠣ࡟ࠥ࠭᫨")+title+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࠢࡠࠤࠥࠦࡏࡳ࡫ࡪ࡭ࡳࡧ࡬࠻ࠢ࡞ࠤࠬ᫩")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࠣࡡࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ᫪")+str(kk4bAafDCZm7XQJis0PBqp1Weul)+DJ6ugPjW9bX8I(u"ࠪࠤࡢ࠭᫫"))
				if flDSRbv57PnV3(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠴ࠧ᫬") in kk4bAafDCZm7XQJis0PBqp1Weul and IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡰࡴ࡬࡫ࠬ᫭") in kk4bAafDCZm7XQJis0PBqp1Weul:
					oOFlVdqEv9haMXwpHiPZUyArG3ux,Z82diNu7RlDybXFqVrvo,gCJprIs2wUzfcNhtxv = uoA1SsdxjlhEkX5eivf(kk4bAafDCZm7XQJis0PBqp1Weul)
					if gCJprIs2wUzfcNhtxv: kk4bAafDCZm7XQJis0PBqp1Weul = gCJprIs2wUzfcNhtxv[f4fTutDOEwUeIoPLRQ]
					else: kk4bAafDCZm7XQJis0PBqp1Weul = nbOFVEDkpT4BIR7Qq82yPmHeJU
				if not kk4bAafDCZm7XQJis0PBqp1Weul: yi6wOauQ3Sb1JUBt4 = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ᫮")
				else: yi6wOauQ3Sb1JUBt4 = brh5aWRxQzn6YL8UDNOyK9SFGo(kk4bAafDCZm7XQJis0PBqp1Weul,source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG)
			if yi6wOauQ3Sb1JUBt4 in [yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ᫯"),Fo1SgXMsHk(u"ࠨࡶࡨࡷࡹ࡯࡮ࡨࠩ᫰"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠧ᫱"),flDSRbv57PnV3(u"ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࠬ᫲")] or len(lPpY5fw3tOBcEye91Caun2FQZ)==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠴।"): break
			elif yi6wOauQ3Sb1JUBt4 in [fgv5U2eRVaQqSiuGD(u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ᫳"),fgv5U2eRVaQqSiuGD(u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭᫴"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡴࡳ࡫ࡨࡨࠬ᫵")]: break
			else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᫶"),SSvu1CZjTW7FcloNqD(u"ࠨษ็้้็ࠠๅ็ࠣ๎฾๋ไࠡฮิฬ๋ࠥไโࠢ฽๎ึํࠧ᫷"))
	else:
		yi6wOauQ3Sb1JUBt4 = bYyKEjIuGQzoq3AR1(u"ࠩࡸࡲࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭᫸")
		if JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6): yi6wOauQ3Sb1JUBt4 = brh5aWRxQzn6YL8UDNOyK9SFGo(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG)
	return yi6wOauQ3Sb1JUBt4,lPpY5fw3tOBcEye91Caun2FQZ
def GZXAWoIHDCisP(url,source):
	plSscrVjkRviPwm,Ft1mMA8RKoibjZe,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF = url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if l4DS8mnEjHhFMZ5YOe(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ᫹") in url:
		plSscrVjkRviPwm,Ft1mMA8RKoibjZe = url.split(X1mRwt2YJKgCLu9a67(u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ᫺"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)
		Ft1mMA8RKoibjZe = Ft1mMA8RKoibjZe+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡥ࡟ࠨ᫻")+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭࡟ࡠࠩ᫼")+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡠࡡࠪ᫽")+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡡࡢࠫ᫾")+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡢࡣࠬ᫿")
		xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF,q1S5R0VxsyPwtMkemY7rGdO, = Ft1mMA8RKoibjZe.split(flDSRbv57PnV3(u"ࠪࡣࡤ࠭ᬀ"))[:yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠺॥")]
	if not uTKGhcXEIpmDf: uTKGhcXEIpmDf = ulAxHwvzR9eTb5n(u"ࠫ࠵࠭ᬁ")
	else: uTKGhcXEIpmDf = uTKGhcXEIpmDf.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡶࠧᬂ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(S3X6GcaiExOPtb,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	plSscrVjkRviPwm = plSscrVjkRviPwm.strip(fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭࠿ࠨᬃ")).strip(bYyKEjIuGQzoq3AR1(u"ࠧ࠰ࠩᬄ")).strip(l4DS8mnEjHhFMZ5YOe(u"ࠨࠨࠪᬅ"))
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,t4txivgXSUWBOlCakQmNDjf(u"ࠩ࡫ࡳࡸࡺࠧᬆ"))
	if xbfwC5hkXLvsJa8PReOS9AyU1z: BBCKhDfJqt = xbfwC5hkXLvsJa8PReOS9AyU1z
	else: BBCKhDfJqt = RWZpkDLtY5Eyb46029MvAKmqBQd8o
	BBCKhDfJqt = Qi32bRtN18qvyWmaO7YKow9cXs(BBCKhDfJqt,ulAxHwvzR9eTb5n(u"ࠪࡲࡦࡳࡥࠨᬇ"))
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"๊ࠫฮวีำࠪᬈ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ู๊ࠬาใิࠫᬉ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭วๅࠢࠪᬊ"),S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	Ft1mMA8RKoibjZe = Ft1mMA8RKoibjZe.replace(I3cxjYaHhsrM7T4UX26klN(u"ࠧๆสสุึ࠭ᬋ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨีํีๆืࠧᬌ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩส่ࠥ࠭ᬍ"),S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	BBCKhDfJqt = BBCKhDfJqt.replace(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"้ࠪออิาࠩᬎ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(YayJj10OGl(u"ุࠫ๐ัโำࠪᬏ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(z3sIGH8jmLYg(u"ࠬอไࠡࠩᬐ"),S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	return plSscrVjkRviPwm,Ft1mMA8RKoibjZe,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF
def cRM9YqAt1Blibr3PCQoxvdah(url,source):
	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,lc6PgsYTOqfkdMnvA1U,wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn,DbpBKurLYhF4OCtUdRc6anEgA03Tx,ImzBe5xREiC6jgfY8yd,Tks3rDNUeEqh6 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,None,None,None,None,None
	plSscrVjkRviPwm,Ft1mMA8RKoibjZe,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF = GZXAWoIHDCisP(url,source)
	if bnI4kmPtrW7yFEhljXOCq9(u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧᬑ") in url:
		if   vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==t4txivgXSUWBOlCakQmNDjf(u"ࠧࡦ࡯ࡥࡩࡩ࠭ᬒ"): vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG = S3X6GcaiExOPtb+QlTuvPbSpnjygBVW(u"ࠨ็ไฺ้࠭ᬓ")
		elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡺࡥࡹࡩࡨࠨᬔ"): vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG = S3X6GcaiExOPtb+flDSRbv57PnV3(u"ฺ๊ࠪࠩว่ัฬࠫᬕ")
		elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==l4DS8mnEjHhFMZ5YOe(u"ࠫࡧࡵࡴࡩࠩᬖ"): vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG = S3X6GcaiExOPtb+X1mRwt2YJKgCLu9a67(u"ࠬࠫࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧᬗ")
		elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==bYyKEjIuGQzoq3AR1(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨᬘ"): vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG = S3X6GcaiExOPtb+UpQ56M0dO1N9xIvVegy(u"ࠧࠦࠧࠨฮา๋๊ๅࠩᬙ")
		elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==nbOFVEDkpT4BIR7Qq82yPmHeJU: vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG = S3X6GcaiExOPtb+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࠧࠨࠩࠪ࠭ᬚ")
		if D63UZqx2XBgrtbje!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
			if DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡰࡴ࠹࠭ᬛ") not in D63UZqx2XBgrtbje: D63UZqx2XBgrtbje = l4DS8mnEjHhFMZ5YOe(u"ࠪࠩࠬᬜ")+D63UZqx2XBgrtbje
			D63UZqx2XBgrtbje = S3X6GcaiExOPtb+D63UZqx2XBgrtbje
		if uTKGhcXEIpmDf!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
			uTKGhcXEIpmDf = l4DS8mnEjHhFMZ5YOe(u"ࠫࠪࠫࠥࠦࠧࠨࠩࠪࠫࠧᬝ")+uTKGhcXEIpmDf
			uTKGhcXEIpmDf = S3X6GcaiExOPtb+uTKGhcXEIpmDf[-DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠾०"):]
	if   bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡇࡋࡐࡃࡐࠫᬞ")		in source: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif YayJj10OGl(u"࠭ࡁࡌ࡙ࡄࡑࠬᬟ")		in source: lc6PgsYTOqfkdMnvA1U	= xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡢ࡭ࡺࡥࡲ࠭ᬠ")
	elif z3sIGH8jmLYg(u"ࠨ࡭ࡤࡸࡰࡵࡵࡵࡧࠪᬡ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif ulAxHwvzR9eTb5n(u"ࠩࡳ࡬ࡴࡺ࡯ࡴ࠰ࡤࡴࡵ࠴ࡧࠨᬢ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif Fo1SgXMsHk(u"ࠪࡥࡷࡧࡢࡴࡧࡨࡨࠬᬣ")		in source: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif tM24jD1gO0(u"ࠫࡦࡲࡡࡳࡣࡥࠫᬤ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif z3sIGH8jmLYg(u"ࠬ࡬ࡡࡴࡧ࡯ࠫᬥ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡴ࠸࡯ࡨࡩࡱ࠭ᬦ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif tM24jD1gO0(u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧᬧ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif X60YQOADpkHBb31LiR5qUEKfM(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪᬨ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡩࡥ࡯࡫ࡲࠨᬩ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif tM24jD1gO0(u"ࠪๅัืࠧᬪ")			in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= bnI4kmPtrW7yFEhljXOCq9(u"ࠫ࡫ࡧࡪࡦࡴࠪᬫ")
	elif DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬ็ไิูํ๊ࠬᬬ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= YayJj10OGl(u"࠭ࡰࡢ࡮ࡨࡷࡹ࡯࡮ࡦࠩᬭ")
	elif q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡨࡦࡵ࡭ࡻ࡫ࠧᬮ")		in plSscrVjkRviPwm:   lc6PgsYTOqfkdMnvA1U	= bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡩࡲࡳ࡬ࡲࡥࠨᬯ")
	elif bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡰࡽࡨ࡯࡭ࡢࠩᬰ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif qrjy8LuKVPNYdbSvzh(u"ࠪࡻࡪࡩࡩ࡮ࡣࠪᬱ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬᬲ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif ulAxHwvzR9eTb5n(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ࠭ᬳ")		in xbfwC5hkXLvsJa8PReOS9AyU1z:   lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif I3cxjYaHhsrM7T4UX26klN(u"࠭ࡤࡢ࡫࡯ࡽࡲࡵࡴࡪࡱࡱ᬴ࠫ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡣࡱ࡮ࡶࡦ࠭ᬵ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif DJ6ugPjW9bX8I(u"ࠨࡶࡹࡪࡺࡴࠧᬶ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡷࡺࡰࡹࡡࠨᬷ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif t4txivgXSUWBOlCakQmNDjf(u"ࠪࡥࡳࡧࡶࡪࡦࡽࠫᬸ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif SSvu1CZjTW7FcloNqD(u"ࠫࡸ࡮࡯ࡰࡨࡳࡶࡴ࠭ᬹ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧᬺ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif QlTuvPbSpnjygBVW(u"࠭ࡳࡩࡣ࡫ࡩࡩ࠺ࡵࠨᬻ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif tM24jD1gO0(u"ࠧࡤ࡫ࡰࡥ࠹ࡻࠧᬼ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif QlTuvPbSpnjygBVW(u"ࠨࡧࡪࡽࡳࡵࡷࠨᬽ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩ࡫ࡥࡱࡧࡣࡪ࡯ࡤࠫᬾ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif fgv5U2eRVaQqSiuGD(u"ࠪࡧ࡮ࡳࡡࡢࡤࡧࡳࠬᬿ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif ulAxHwvzR9eTb5n(u"ࠫࡷ࡫ࡤ࡮ࡱࡧࡼࠬᭀ")	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡸࡥࡥ࡯ࡲࡨࡽ࠭ᭁ")
	elif DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡹࡰࡷࡷࡹࠬᭂ")	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨᭃ")
	elif O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ᭄")	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= QlTuvPbSpnjygBVW(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪᭅ")
	elif ulAxHwvzR9eTb5n(u"ࠪࡩ࡬ࡿ࠭ࡣࡧࡶࡸ࠳ࡴࡥࡵࠩᭆ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= BBCKhDfJqt
	elif X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࠩᭇ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࡫ࡧࡺࡤࡨࡷࡹࡼࡩࡱࠩᭈ")
	elif Fo1SgXMsHk(u"࠭ࡥࡨࡻ࠱ࡦࡪࡹࡴࠨᭉ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠲ࠩᭊ")
	elif flDSRbv57PnV3(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩᭋ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡨ࡫ࡾࡨࡥࡴࡶ࠶ࠫᭌ")
	elif IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡱࡴࡹࡨࡢࡪࡧࡥࠬ᭍")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= YayJj10OGl(u"ࠫࡲࡵࡳࡩࡣ࡫ࡨࡦ࠭᭎")
	elif yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ᭏")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡦࡢࡥࡸࡰࡹࡿࡢࡰࡱ࡮ࡷࠬ᭐")
	elif DJ6ugPjW9bX8I(u"ࠧࡪࡰࡩࡰࡦࡳ࠮ࡤࡥࠪ᭑")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨ࡫ࡱࡪࡱࡧ࡭ࠨ᭒")
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ᭓")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: lc6PgsYTOqfkdMnvA1U	= ulAxHwvzR9eTb5n(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫ᭔")
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ᭕")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= YayJj10OGl(u"ࠬࡧࡲࡢࡤ࡯ࡳࡦࡪࡳࠨ᭖")
	elif ulAxHwvzR9eTb5n(u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ᭗")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡢࡴࡦ࡬࡮ࡼࡥࠨ᭘")
	elif qrjy8LuKVPNYdbSvzh(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪ᭙")	 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡦࡥࡹࡩࡨࠨ᭚")
	elif wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ᭛")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ᭜")
	elif fgv5U2eRVaQqSiuGD(u"ࠬࡼࡩࡥࡤࡰࠫ᭝")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= X1mRwt2YJKgCLu9a67(u"࠭ࡶࡪࡦࡥࡱࠬ᭞")
	elif IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡷ࡫ࡧ࡬ࡩ࠭᭟")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif l4DS8mnEjHhFMZ5YOe(u"ࠨ࡯ࡼࡺ࡮ࡪࠧ᭠")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif tM24jD1gO0(u"ࠩࡰࡽࡻ࡯ࡩࡥࠩ᭡")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: ImzBe5xREiC6jgfY8yd	= BBCKhDfJqt
	elif I3cxjYaHhsrM7T4UX26klN(u"ࠪࡺ࡮ࡪࡥࡰࡤ࡬ࡲࠬ᭢")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= t4txivgXSUWBOlCakQmNDjf(u"ࠫࡻ࡯ࡤࡦࡱࡥ࡭ࡳ࠭᭣")
	elif QlTuvPbSpnjygBVW(u"ࠬ࡭࡯ࡷ࡫ࡧࠫ᭤")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= YayJj10OGl(u"࠭ࡧࡰࡸ࡬ࡨࠬ᭥")
	elif cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧ࡭࡫࡬ࡺ࡮ࡪࡥࡰࠩ᭦") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= SSvu1CZjTW7FcloNqD(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪ᭧")
	elif fgv5U2eRVaQqSiuGD(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬ᭨")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= bYyKEjIuGQzoq3AR1(u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭᭩")
	elif bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࠩ᭪")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= YayJj10OGl(u"ࠬࡶࡵࡣ࡮࡬ࡧࡻ࡯ࡤࡦࡱࠪ᭫")
	elif I3cxjYaHhsrM7T4UX26klN(u"࠭ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱ᭬ࠪ") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡳࡣࡳ࡭ࡩࡼࡩࡥࡧࡲࠫ᭭")
	elif yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡶࡲࡴ࠹ࡺ࡯ࡱࠩ᭮")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= YayJj10OGl(u"ࠩࡷࡳࡵ࠺ࡴࡰࡲࠪ᭯")
	elif bYyKEjIuGQzoq3AR1(u"ࠪࡹࡵࡶࠧ᭰") 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= fgv5U2eRVaQqSiuGD(u"ࠫࡺࡶࡢࡰ࡯ࠪ᭱")
	elif t4txivgXSUWBOlCakQmNDjf(u"ࠬࡻࡰࡣࠩ᭲") 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= flDSRbv57PnV3(u"࠭ࡵࡱࡤࡲࡱࠬ᭳")
	elif ulAxHwvzR9eTb5n(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧ᭴") 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= YayJj10OGl(u"ࠨࡷࡴࡰࡴࡧࡤࠨ᭵")
	elif z3sIGH8jmLYg(u"ࠩࡹࡧࡸࡺࡲࡦࡣࡰࠫ᭶") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡺࡨࡹࡴࡳࡧࡤࡱࠬ᭷")
	elif ulAxHwvzR9eTb5n(u"ࠫࡻ࡯ࡤࡣࡱࡥࠫ᭸")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡼࡩࡥࡤࡲࡦࠬ᭹")
	elif paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡶࡪࡦࡲࡾࡦ࠭᭺") 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡷ࡫ࡧࡳࡿࡧࠧ᭻")
	elif qrjy8LuKVPNYdbSvzh(u"ࠨࡹࡤࡸࡨ࡮ࡶࡪࡦࡨࡳࠬ᭼") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= UpQ56M0dO1N9xIvVegy(u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭᭽")
	elif YayJj10OGl(u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ᭾")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= z3sIGH8jmLYg(u"ࠫࡼ࡯࡮ࡵࡸ࠱ࡰ࡮ࡼࡥࠨ᭿")
	elif paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࢀࡩࡱࡲࡼࡷ࡭ࡧࡲࡦࠩᮀ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪᮁ")
	elif usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡩࡦ࠰ࡧࡩࡴࠧᮂ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn	= X1mRwt2YJKgCLu9a67(u"ࠨࡪࡧ࠱ࡨࡪ࡮ࠨᮃ")
	if   lc6PgsYTOqfkdMnvA1U:	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = Fo1SgXMsHk(u"ࠩัหฺ࠭ᮄ"),lc6PgsYTOqfkdMnvA1U
	elif ImzBe5xREiC6jgfY8yd:		OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = SSvu1CZjTW7FcloNqD(u"๊ࠪࠩำฯะࠩᮅ"),ImzBe5xREiC6jgfY8yd
	elif wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn:		OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = I3cxjYaHhsrM7T4UX26klN(u"ูࠫࠪࠫศ็้ࠣ฾ื่โࠩᮆ"),wG9uPF4LsrRZaAoc7k5iQMIE1WJxpn
	elif DbpBKurLYhF4OCtUdRc6anEgA03Tx:	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࠫࠥࠦ฻ส้ࠥิวาฮํࠫᮇ"),DbpBKurLYhF4OCtUdRc6anEgA03Tx
	elif Tks3rDNUeEqh6:	OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = ulAxHwvzR9eTb5n(u"࠭ࠥࠦࠧࠨ฽ฬ๋ࠠฯษิะ๏࠭ᮈ"),BBCKhDfJqt
	else:			OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z = ulAxHwvzR9eTb5n(u"ࠧࠦࠧࠨࠩࠪ฿วๆ่ࠢะ์๎ไࠨᮉ"),BBCKhDfJqt
	return OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf
def iXgJUrjoMmF8hzs(url,source):
	plSscrVjkRviPwm,ImzBe5xREiC6jgfY8yd,RWZpkDLtY5Eyb46029MvAKmqBQd8o,BBCKhDfJqt,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,JygZr6tXVAOGqPoF = GZXAWoIHDCisP(url,source)
	if   qrjy8LuKVPNYdbSvzh(u"ࠨࡃࡎࡓࡆࡓࠧᮊ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Pl9syVGTF0(plSscrVjkRviPwm,xbfwC5hkXLvsJa8PReOS9AyU1z)
	elif O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡄࡏ࡜ࡇࡍࠨᮋ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Hn1ehdUPB2(plSscrVjkRviPwm,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,uTKGhcXEIpmDf)
	elif qrjy8LuKVPNYdbSvzh(u"ࠪࡊࡆ࡙ࡅࡍࡊࡇ࠵ࠬᮌ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = STvH5VK2LM(plSscrVjkRviPwm)
	elif CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬᮍ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᮎ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	elif QlTuvPbSpnjygBVW(u"࠭ࡹࡰࡷࡷࡹࠬᮏ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᮐ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	elif l4DS8mnEjHhFMZ5YOe(u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨᮑ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᮒ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	elif SSvu1CZjTW7FcloNqD(u"ࠪࡇࡎࡓࡁ࠵ࡗࠪᮓ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = ddhk8UY93x(plSscrVjkRviPwm)
	elif O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡈࡏࡍࡂࡅࡏ࡙ࡇ࠭ᮔ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hXfZLEF01s(plSscrVjkRviPwm)
	elif YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊࠧᮕ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = cczNkUM8e6(plSscrVjkRviPwm)
	elif Fo1SgXMsHk(u"࠭ࡃࡊࡏࡄࡅࡇࡊࡏࠨᮖ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = TTfGtcnHWg(plSscrVjkRviPwm)
	elif YayJj10OGl(u"ࠧࡔࡊࡒࡊࡍࡇࠧᮗ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = S5S2A0HuKB(plSscrVjkRviPwm)
	elif usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠳ࠪᮘ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = O6kUi5MdYE(plSscrVjkRviPwm,JygZr6tXVAOGqPoF)
	elif I3cxjYaHhsrM7T4UX26klN(u"ࠩࡄࡐࡒ࡙ࡔࡃࡃࠪᮙ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = HHs8Sbglyo(plSscrVjkRviPwm)
	elif yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡐࡆࡘࡏ࡛ࡃࠪᮚ")		in source: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = rxPoLEUGuR(plSscrVjkRviPwm)
	elif l4DS8mnEjHhFMZ5YOe(u"ࠫࡰࡧࡴ࡬ࡱࡸࡸࡪ࠭ᮛ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = bjdzha45nm(plSscrVjkRviPwm)
	elif flDSRbv57PnV3(u"ࠬࡧ࡫ࡰࡣࡰ࠲ࡨࡧ࡭ࠨᮜ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = NC5BwOzQK0(plSscrVjkRviPwm)
	elif q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡡ࡭ࡣࡵࡥࡧ࠭ᮝ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Fs5NWnViClMK8(plSscrVjkRviPwm)
	elif fgv5U2eRVaQqSiuGD(u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩᮞ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = v1skFBGlrX(plSscrVjkRviPwm)
	elif IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡵ࡫ࡥ࡭࡫ࡤ࠵ࡷࠪᮟ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = v1skFBGlrX(plSscrVjkRviPwm)
	elif CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡨ࡫ࡾࡴ࡯ࡸࠩᮠ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = K8bGaEqlm7(plSscrVjkRviPwm)
	elif QlTuvPbSpnjygBVW(u"ࠪࡸࡻ࡬ࡵ࡯ࠩᮡ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = JfVHmqYKhQ(plSscrVjkRviPwm)
	elif l4DS8mnEjHhFMZ5YOe(u"ࠫࡹࡼ࡫ࡴࡣࠪᮢ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = JfVHmqYKhQ(plSscrVjkRviPwm)
	elif O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡺࡶ࠮ࡨ࠱ࡧࡴࡳࠧᮣ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = JfVHmqYKhQ(plSscrVjkRviPwm)
	elif cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡨࡢ࡮ࡤࡧ࡮ࡳࡡࠨᮤ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = bVgMzdZK7e(plSscrVjkRviPwm)
	elif CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡴࡪࡲࡳ࡫ࡶࡲࡰࠩᮥ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = vfJn9cWZFU(plSscrVjkRviPwm)
	elif fgv5U2eRVaQqSiuGD(u"ࠨ࡯ࡼࡩ࡬ࡿࡶࡪࡲࠪᮦ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = xxPROgUl28WZ(plSscrVjkRviPwm)
	elif xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡹࡷ࠹ࡻࠧᮧ")			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = kDOBzqPZK3(plSscrVjkRviPwm)
	elif flDSRbv57PnV3(u"ࠪࡪࡦࡰࡥࡳࠩᮨ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WVBqhxkTJo(plSscrVjkRviPwm)
	elif DJ6ugPjW9bX8I(u"ࠫࡨ࡯࡭ࡢࡰࡲࡻࠬᮩ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nIEpzfZOeA(plSscrVjkRviPwm)
	elif paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡴࡥࡸࡥ࡬ࡱࡦ᮪࠭")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nIEpzfZOeA(plSscrVjkRviPwm)
	elif SSvu1CZjTW7FcloNqD(u"࠭ࡣࡪ࡯ࡤ࠱ࡱ࡯ࡧࡩࡶ᮫ࠪ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = eCcV9bE5Xv(plSscrVjkRviPwm)
	elif YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡤ࡫ࡰࡥࡱ࡯ࡧࡩࡶࠪᮬ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = eCcV9bE5Xv(plSscrVjkRviPwm)
	elif YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨᮭ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = mJhnvlc9Rr(plSscrVjkRviPwm)
	elif xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡺࡩࡨ࡯࡭ࡢࠩᮮ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = zzhfIeX30wJVOH4qdQutYWD27(plSscrVjkRviPwm)
	elif bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡦࡴࡱࡲࡢࠩᮯ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = FO9Pcsk5Xz(plSscrVjkRviPwm)
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯ࠩ᮰")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = d7aRis2qhk(plSscrVjkRviPwm)
	elif flDSRbv57PnV3(u"ࠬࡧࡲࡣ࡮࡬ࡳࡳࢀࠧ᮱")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = czHXgtQlrJ(plSscrVjkRviPwm)
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡥࡨࡻ࠰ࡦࡪࡹࡴ࠯ࡰࡨࡸࠬ᮲")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = IcsWHablxw(plSscrVjkRviPwm)
	elif cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡥ࠰ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡨࠬ᮳")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	elif YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ᮴")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Njvc8kFO4M(plSscrVjkRviPwm)
	elif DJ6ugPjW9bX8I(u"ࠩࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨࠨ᮵")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = vID5SVuoAQ(plSscrVjkRviPwm)
	elif bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡹࡵࡨࡡ࡮ࠩ᮶") 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = I3cxjYaHhsrM7T4UX26klN(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ᮷"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	if uusxjPSpV5c and uusxjPSpV5c!=O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ᮸"): uusxjPSpV5c = ulAxHwvzR9eTb5n(u"࠭ࡆࡢ࡫࡯ࡩࡩࡀࠠࠡࠩ᮹")+uusxjPSpV5c
	return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Krd8B5Qe2R7Li4qHnJOb1wSEUGVDT(uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ):
	bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = [],[]
	for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in zip(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ):
		if JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
			bdW70uQAIF.append(title)
			rU02bCJFWZDfVuhtMgBOyQi5P.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if not rU02bCJFWZDfVuhtMgBOyQi5P and not uusxjPSpV5c: uusxjPSpV5c = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡇࡣ࡬ࡰࡪࡪࠧᮺ")
	return uusxjPSpV5c,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P
def i0RIJo5SetVpOGdAyUbQ4v9NxnB3(zGcM56Ki1lfB8TZPtVHeXb,url,source,UUfw8Ld24pDl5xbHRhe):
	global nPI56Ug8wj9My0fDscBETLHzAoXN,hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz
	mvBYgfPuOD6xM27TpNnk3da14AeZb = []
	for Tks3rDNUeEqh6 in [hhvF5yW4kQ1dxCLm83BfATlZ,WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz]: Tks3rDNUeEqh6[UUfw8Ld24pDl5xbHRhe] = (CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩᮻ"),[],[])
	ssMgjb7iFQ8HqDOEZ,B51hTLnQmSeGEbcU6XW2xJYNt = [Y8YkuLrp9Gq,kunVGaU9Wt1iFsEv0qjLlomw,K6nUQo2kAX43JiLfZcph1Ga8q,z8EstRl3DLSmTwG4UW972O],[]
	if ulAxHwvzR9eTb5n(u"ࠩࡩࡶࡩࡲࠧᮼ") in url: ssMgjb7iFQ8HqDOEZ,B51hTLnQmSeGEbcU6XW2xJYNt = [Y8YkuLrp9Gq,kunVGaU9Wt1iFsEv0qjLlomw,z8EstRl3DLSmTwG4UW972O],[SSaiGHeLq7KwAI4UTQJ]
	if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫᮽ") in url: ssMgjb7iFQ8HqDOEZ,B51hTLnQmSeGEbcU6XW2xJYNt = [Y8YkuLrp9Gq],[WywD1Y9fE4dOtLFZxgGJ6,SSaiGHeLq7KwAI4UTQJ,UmRopiJqVk9ljYde2Agz]
	for Tks3rDNUeEqh6 in B51hTLnQmSeGEbcU6XW2xJYNt: Tks3rDNUeEqh6[UUfw8Ld24pDl5xbHRhe] = (X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡘࡱࡩࡱࡲࡨࡨࠬᮾ"),[],[])
	for Tks3rDNUeEqh6 in ssMgjb7iFQ8HqDOEZ:
		nOYqDV1m3xQ2HB9zdJL4 = eb6R0h1Fjl.Thread(target=Tks3rDNUeEqh6,args=(url,source,UUfw8Ld24pDl5xbHRhe))
		mvBYgfPuOD6xM27TpNnk3da14AeZb.append(nOYqDV1m3xQ2HB9zdJL4)
		nOYqDV1m3xQ2HB9zdJL4.start()
		lQMuw1PvVpAk.sleep(fgv5U2eRVaQqSiuGD(u"࠷१"))
	UCudDlZV4o,nqFydsJAp8TYhtR9VwXjPKCUGOorE,ffmN4RPjAs9DE2e,Kq6b4unAVGOHP3 = SmbNGskjMx,SmbNGskjMx,SmbNGskjMx,SmbNGskjMx
	timeout,step = bnI4kmPtrW7yFEhljXOCq9(u"࠳࠱२"),QQSugEIn2mTCpRsfcaJHhPdAWzylM
	for yUSCo6OPuT31Y8t in range(timeout//step):
		if not UCudDlZV4o and hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]!=X60YQOADpkHBb31LiR5qUEKfM(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭ᮿ"): UCudDlZV4o = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if not nqFydsJAp8TYhtR9VwXjPKCUGOorE and WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]!=wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡔࡪ࡯ࡨࡳࡺࡺࠧᯀ"): nqFydsJAp8TYhtR9VwXjPKCUGOorE = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if not ffmN4RPjAs9DE2e and SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]!=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡕ࡫ࡰࡩࡴࡻࡴࠨᯁ"): ffmN4RPjAs9DE2e = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if not Kq6b4unAVGOHP3 and UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ]!=Fo1SgXMsHk(u"ࠨࡖ࡬ࡱࡪࡵࡵࡵࠩᯂ"): Kq6b4unAVGOHP3 = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if UCudDlZV4o and nqFydsJAp8TYhtR9VwXjPKCUGOorE and ffmN4RPjAs9DE2e and Kq6b4unAVGOHP3: break
		if not hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]: break
		if not WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]: break
		if not SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]: break
		if not UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe][f4fTutDOEwUeIoPLRQ] and UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe][QQSugEIn2mTCpRsfcaJHhPdAWzylM]: break
		lQMuw1PvVpAk.sleep(step)
	for nOYqDV1m3xQ2HB9zdJL4 in mvBYgfPuOD6xM27TpNnk3da14AeZb: nOYqDV1m3xQ2HB9zdJL4.join(bYyKEjIuGQzoq3AR1(u"࠲३"))
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࡥ࠲ࠨᯃ")
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c==cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡉ࡝ࡏࡔࡠࡃࡏࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᯄ") or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡡࡴࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠴࠽ࠤࠥ࠭ᯅ")+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠺࠳४")]
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = tM24jD1gO0(u"ࠬࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠶ࠫᯆ")
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c==l4DS8mnEjHhFMZ5YOe(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᯇ") or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠸ࡀࠠࠡࠩᯈ")+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠻࠴५")]
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠺ࠧᯉ")
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c==DJ6ugPjW9bX8I(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᯊ") or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠵࠼ࠣࠤࠬᯋ")+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:ulAxHwvzR9eTb5n(u"࠼࠵६")]
	wwIn2vNElz5Q7yjKMGAhVdF13OHpD = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠷ࠪᯌ")
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe]
	lPpY5fw3tOBcEye91Caun2FQZ = wqGRSp8bWyjKmgoM4iT(lPpY5fw3tOBcEye91Caun2FQZ)
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	if uusxjPSpV5c==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡋࡘࡊࡖࡢࡅࡑࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᯍ") or lPpY5fw3tOBcEye91Caun2FQZ: return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	zGcM56Ki1lfB8TZPtVHeXb += IINBvuxkCSJrO1Q0UyngdLi(u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠹࠿ࠦࠠࠨᯎ")+uusxjPSpV5c.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)[:YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠽࠶७")]
	nPI56Ug8wj9My0fDscBETLHzAoXN[UUfw8Ld24pDl5xbHRhe] = zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return wwIn2vNElz5Q7yjKMGAhVdF13OHpD,zGcM56Ki1lfB8TZPtVHeXb,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Y8YkuLrp9Gq(url,source,UUfw8Ld24pDl5xbHRhe):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,fgv5U2eRVaQqSiuGD(u"ࠧ࡯ࡣࡰࡩࠬᯏ"))
	lPpY5fw3tOBcEye91Caun2FQZ = []
	if l4DS8mnEjHhFMZ5YOe(u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ᯐ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = d7aRis2qhk(url)
	elif cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡪࡳࡴ࡭࡬ࡦࡷࡶࡩࡷࡩ࡯ࠨᯑ") in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WbGIRfZTSKJLQ13cjXUqMFwrYyV68H(url)
	elif O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡽࡴࡻࡴࡶࠩᯒ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(url)
	elif yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡾ࠸ࡵ࠯ࡤࡨࠫᯓ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = VtJMTRCpWz(url)
	elif t4txivgXSUWBOlCakQmNDjf(u"ࠬࡶࡨࡰࡶࡲࡷ࠳ࡧࡰࡱ࠰ࡪࠫᯔ")	in url   : uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = OAKUxNEVDSguzfQ(url)
	elif flDSRbv57PnV3(u"࠭࡭ࡰࡵ࡫ࡥ࡭ࡪࡡࠨᯕ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = uoA1SsdxjlhEkX5eivf(url)
	elif wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࡧࡣࡶࡩࡱ࡮ࡤࠨᯖ")		in url   : uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = STvH5VK2LM(url)
	elif yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡣࡵࡥࡧࡲ࡯ࡢࡦࡶࠫᯗ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = znSbGIkNEJ7ZoVlFc36KWfr4(url)
	elif QlTuvPbSpnjygBVW(u"ࠩࡤࡶࡨ࡮ࡩࡷࡧࠪᯘ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = YTbE8gRUZxMFfvL2CG(url)
	elif X1mRwt2YJKgCLu9a67(u"ࠪࡦࡺࢀࡺࡷࡴ࡯ࠫᯙ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = W2VX5ICc6PhxfLMldDroGANH8g(url)
	elif Fo1SgXMsHk(u"ࠫࡪ࠻ࡴࡴࡣࡵࠫᯚ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Tar1Wd7S2PUQpA0lmGCObunJLzsI(url)
	elif IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫᯛ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = OFqBIv3fPQwKy2MCa90xhi(url)
	elif I3cxjYaHhsrM7T4UX26klN(u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩᯜ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = OFqBIv3fPQwKy2MCa90xhi(url)
	elif YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡶࡲࡥࡥࡲ࠭ᯝ") 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	elif l4DS8mnEjHhFMZ5YOe(u"ࠨ࡮࡬࡭ࡻ࡯ࡤࡦࡱࠪᯞ") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hySV345z0gvKfHxpjEPksT2(url)
	elif I3cxjYaHhsrM7T4UX26klN(u"ࠩࡰࡴ࠹ࡻࡰ࡭ࡱࡤࡨࠬᯟ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = eh8ypgHQNvCFilYd9SsIDU1qV(url)
	elif UpQ56M0dO1N9xIvVegy(u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧᯠ") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = X8XUbv2VaP6f1S(url)
	elif qrjy8LuKVPNYdbSvzh(u"ࠫࡹࡵࡰ࠵ࡶࡲࡴࠬᯡ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = H2cJulsEhx35e(url)
	elif paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡻࡰࡣࠩᯢ") 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = RREam6IVLoCudeXDU1Aw(url)
	elif fgv5U2eRVaQqSiuGD(u"࠭ࡵࡱࡲࠪᯣ") 			in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = RREam6IVLoCudeXDU1Aw(url)
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡶࡳ࡯ࡳࡦࡪࠧᯤ") 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = Q8GvDRzUA3NXig0oJyEHStduYxqLP(url)
	elif flDSRbv57PnV3(u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪᯥ") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = o6gsJ7VMy0FTQePUiGCwK5L9t4c2EH(url)
	elif X1mRwt2YJKgCLu9a67(u"ࠩࡹ࡭ࡩࡨ࡯ࡣ᯦ࠩ")		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = PA3MXtUNpdknBTScuH16emlQW(url)
	elif QlTuvPbSpnjygBVW(u"ࠪࡺ࡮ࡪ࡯ࡻࡣࠪᯧ") 		in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = XsE0MzVUwhTZ62Py(url)
	elif bYyKEjIuGQzoq3AR1(u"ࠫࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯ࠨᯨ") 	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = ZjK0JomnMz2VhQ4Ce31(url)
	elif QlTuvPbSpnjygBVW(u"ࠬࡽࡩ࡯ࡶࡹ࠲ࡱ࡯ࡶࡦࠩᯩ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = hwL6eBCfEiJr0gm7FlI(url)
	elif SSvu1CZjTW7FcloNqD(u"࠭ࡺࡪࡲࡳࡽࡸ࡮ࡡࡳࡧࠪᯪ")	in RWZpkDLtY5Eyb46029MvAKmqBQd8o: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = sRJ3YdvjMGkNV5ECngye(url)
	else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	global hhvF5yW4kQ1dxCLm83BfATlZ
	if uusxjPSpV5c and uusxjPSpV5c!=qrjy8LuKVPNYdbSvzh(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᯫ"): uusxjPSpV5c = UpQ56M0dO1N9xIvVegy(u"ࠨࡈࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠫᯬ")
	hhvF5yW4kQ1dxCLm83BfATlZ[UUfw8Ld24pDl5xbHRhe] = uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return
def kunVGaU9Wt1iFsEv0qjLlomw(url,source,UUfw8Ld24pDl5xbHRhe):
	global WywD1Y9fE4dOtLFZxgGJ6
	if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪᯭ") in url:
		WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe] = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡊࡦ࡯࡬ࡦࡦ࠽ࠤ࡙ࠥ࡫ࡪࡲࡳࡩࡩ࠭ᯮ"),[],[]
		return
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	if JoEms64VZ1ldaf9NYBgcKCFL(url): uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	if not lPpY5fw3tOBcEye91Caun2FQZ: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = TlobMXNLteYc6vzU0gd7I(url)
	if not lPpY5fw3tOBcEye91Caun2FQZ: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = WY71asuKNIFy3hJbotx2TCMXU(url)
	if not lPpY5fw3tOBcEye91Caun2FQZ:
		if uusxjPSpV5c==X1mRwt2YJKgCLu9a67(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᯯ"): uusxjPSpV5c = nbOFVEDkpT4BIR7Qq82yPmHeJU
		WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe] = IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨᯰ")+uusxjPSpV5c,[],[]
		return
	WywD1Y9fE4dOtLFZxgGJ6[UUfw8Ld24pDl5xbHRhe] = uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return
def K6nUQo2kAX43JiLfZcph1Ga8q(url,source,UUfw8Ld24pDl5xbHRhe):
	vf9s4ClmTE08AGndQV = nbOFVEDkpT4BIR7Qq82yPmHeJU
	bPFto2wZdNYrClgBIEv60DJAzu = SmbNGskjMx
	try:
		import resolveurl as swijhlkSazHdyePGnoX2Iq
		bPFto2wZdNYrClgBIEv60DJAzu = swijhlkSazHdyePGnoX2Iq.resolve(url)
	except Exception as pioIsrM6uymWHJRbhOYv: vf9s4ClmTE08AGndQV = str(pioIsrM6uymWHJRbhOYv)
	global SSaiGHeLq7KwAI4UTQJ
	if not bPFto2wZdNYrClgBIEv60DJAzu:
		if vf9s4ClmTE08AGndQV==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
			if vf9s4ClmTE08AGndQV!=I3cxjYaHhsrM7T4UX26klN(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩᯱ"): Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
		uusxjPSpV5c = vf9s4ClmTE08AGndQV.splitlines()[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe] = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡇࡣ࡬ࡰࡪࡪ࠺᯲ࠡࠢࠪ")+uusxjPSpV5c,[],[]
		return
	SSaiGHeLq7KwAI4UTQJ[UUfw8Ld24pDl5xbHRhe] = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[bPFto2wZdNYrClgBIEv60DJAzu]
	return
def z8EstRl3DLSmTwG4UW972O(url,source,UUfw8Ld24pDl5xbHRhe):
	vf9s4ClmTE08AGndQV = nbOFVEDkpT4BIR7Qq82yPmHeJU
	bPFto2wZdNYrClgBIEv60DJAzu = SmbNGskjMx
	try:
		import yt_dlp as MJ2QKiXw8V
		adSM4bNnpjq8ButTE93 = MJ2QKiXw8V.YoutubeDL({YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡰࡲࡣࡨࡵ࡬ࡰࡴ᯳ࠪ"): Ag9l6cw3EBqP8HsQuGMizfOtr4})
		bPFto2wZdNYrClgBIEv60DJAzu = adSM4bNnpjq8ButTE93.extract_info(url,download=SmbNGskjMx)
	except Exception as pioIsrM6uymWHJRbhOYv: vf9s4ClmTE08AGndQV = str(pioIsrM6uymWHJRbhOYv)
	global UmRopiJqVk9ljYde2Agz
	if not bPFto2wZdNYrClgBIEv60DJAzu or X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡩࡳࡷࡳࡡࡵࡵࠪ᯴") not in list(bPFto2wZdNYrClgBIEv60DJAzu.keys()):
		if vf9s4ClmTE08AGndQV==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
			if vf9s4ClmTE08AGndQV!=IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡒࡴࡴࡥࡕࡻࡳࡩ࠿ࠦࡎࡰࡰࡨࡠࡳ࠭᯵"): Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
		uusxjPSpV5c = vf9s4ClmTE08AGndQV.splitlines()[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe] = Fo1SgXMsHk(u"ࠫࡋࡧࡩ࡭ࡧࡧ࠾ࠥࠦࠧ᯶")+uusxjPSpV5c,[],[]
	else:
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in bPFto2wZdNYrClgBIEv60DJAzu[bnI4kmPtrW7yFEhljXOCq9(u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭᯷")]:
			bbKoeBcirVfzwAqZdQUFDSX.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࡦࡰࡴࡰࡥࡹ࠭᯸")])
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[flDSRbv57PnV3(u"ࠧࡶࡴ࡯ࠫ᯹")])
		UmRopiJqVk9ljYde2Agz[UUfw8Ld24pDl5xbHRhe] = nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	return
def TlobMXNLteYc6vzU0gd7I(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡉࡈࡘࠬ᯺"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,tM24jD1gO0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡘࡅࡅࡋࡕࡉࡈ࡚࡟ࡖࡔࡏ࠱࠶ࡹࡴࠨ᯻"))
	headers = cnPhVmgFxA.headers
	if l4DS8mnEjHhFMZ5YOe(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ᯼") in list(headers.keys()):
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[bYyKEjIuGQzoq3AR1(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭᯽")]
		if JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6): return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ᯾"),[],[]
def wqGRSp8bWyjKmgoM4iT(oOkVKhLScA2xdJ05lCRPgN):
	if wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭࡬ࡪࡵࡷࠫ᯿") in str(type(oOkVKhLScA2xdJ05lCRPgN)):
		rU02bCJFWZDfVuhtMgBOyQi5P = []
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in oOkVKhLScA2xdJ05lCRPgN:
			if bYyKEjIuGQzoq3AR1(u"ࠧࡴࡶࡵࠫᰀ") in str(type(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			rU02bCJFWZDfVuhtMgBOyQi5P.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else: rU02bCJFWZDfVuhtMgBOyQi5P = oOkVKhLScA2xdJ05lCRPgN.replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
	return rU02bCJFWZDfVuhtMgBOyQi5P
def IWXqZsVg1r5K3CvDb8kyUGcBfM(gCJprIs2wUzfcNhtxv,source):
	data = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,YayJj10OGl(u"ࠨ࡮࡬ࡷࡹ࠭ᰁ"),DJ6ugPjW9bX8I(u"ࠩࡖࡉࡗ࡜ࡅࡓࡕࠪᰂ"),gCJprIs2wUzfcNhtxv)
	if data:
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = zip(*data)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = list(bbKoeBcirVfzwAqZdQUFDSX),list(lPpY5fw3tOBcEye91Caun2FQZ)
		return bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,cvwn012JOtHdFbX = [],[],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in gCJprIs2wUzfcNhtxv:
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪ࠳࠴࠭ᰃ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf = cRM9YqAt1Blibr3PCQoxvdah(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,source)
		uTKGhcXEIpmDf = ScntgdOZCY74vNpXeW5jh8i.findall(z3sIGH8jmLYg(u"ࠫࡡࡪࠫࠨᰄ"),uTKGhcXEIpmDf,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if uTKGhcXEIpmDf: uTKGhcXEIpmDf = int(uTKGhcXEIpmDf[f4fTutDOEwUeIoPLRQ])
		else: uTKGhcXEIpmDf = f4fTutDOEwUeIoPLRQ
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,tM24jD1gO0(u"ࠬࡴࡡ࡮ࡧࠪᰅ"))
		cvwn012JOtHdFbX.append([OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o])
	if cvwn012JOtHdFbX:
		MDSBHhtupP3RUl1mGxOnfqF4 = sorted(cvwn012JOtHdFbX,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: (key[WtDrnpJmwQ37Z2Ae68hu4BY5M1],key[f4fTutDOEwUeIoPLRQ],key[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb],key[QQSugEIn2mTCpRsfcaJHhPdAWzylM],key[vkIa3ijEQVsJGdWOXwK7bnue9ADR],key[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠻८")],key[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠶९")]))
		vdYMP3fDSnxzeEgXmqpcua,cSjkilgqAFYw7UmP = [],[]
		for EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U in MDSBHhtupP3RUl1mGxOnfqF4:
			OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o = EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U
			if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ๅโุ็ࠫᰆ") in vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG:
				cSjkilgqAFYw7UmP.append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
				continue
			if EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U not in vdYMP3fDSnxzeEgXmqpcua: vdYMP3fDSnxzeEgXmqpcua.append(EXZyrK9FRwoWQ3BY6j1vC5axtlVS8U)
		vdYMP3fDSnxzeEgXmqpcua = cSjkilgqAFYw7UmP+vdYMP3fDSnxzeEgXmqpcua
		wDIU0SN9GBtzZPoihYnv2xjqQC = f4fTutDOEwUeIoPLRQ
		for OBmo4zTHf6knjh8Z,xbfwC5hkXLvsJa8PReOS9AyU1z,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,D63UZqx2XBgrtbje,uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,RWZpkDLtY5Eyb46029MvAKmqBQd8o in vdYMP3fDSnxzeEgXmqpcua:
			uTKGhcXEIpmDf = str(uTKGhcXEIpmDf) if uTKGhcXEIpmDf else nbOFVEDkpT4BIR7Qq82yPmHeJU
			title = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧิ์ิๅึ࠭ᰇ")+S3X6GcaiExOPtb+vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG+S3X6GcaiExOPtb+OBmo4zTHf6knjh8Z+S3X6GcaiExOPtb+uTKGhcXEIpmDf+S3X6GcaiExOPtb+D63UZqx2XBgrtbje+S3X6GcaiExOPtb+xbfwC5hkXLvsJa8PReOS9AyU1z
			if RWZpkDLtY5Eyb46029MvAKmqBQd8o not in title: title = title+S3X6GcaiExOPtb+RWZpkDLtY5Eyb46029MvAKmqBQd8o
			title = title.replace(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࠧࠪᰈ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
			wDIU0SN9GBtzZPoihYnv2xjqQC += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			title = str(wDIU0SN9GBtzZPoihYnv2xjqQC)+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩ࠱ࠤࠬᰉ")+title
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in lPpY5fw3tOBcEye91Caun2FQZ:
				bbKoeBcirVfzwAqZdQUFDSX.append(title)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if lPpY5fw3tOBcEye91Caun2FQZ:
			data = zip(bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ)
			if data: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡗࡊࡘࡖࡆࡔࡖࠫᰊ"),gCJprIs2wUzfcNhtxv,data,mmfpkVtUDjaq86eAuFzE0oxP)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = list(bbKoeBcirVfzwAqZdQUFDSX),list(lPpY5fw3tOBcEye91Caun2FQZ)
	return bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Fs5NWnViClMK8(url):
	if flDSRbv57PnV3(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪᰋ") in url:
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = mmAWFnZUkQ3HowdxRtCN9(url)
		if lPpY5fw3tOBcEye91Caun2FQZ: return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
		return IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎ࠵ࡘ࠼ࠬᰌ"),[],[]
	return qrjy8LuKVPNYdbSvzh(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᰍ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def bjdzha45nm(url):
	NWtqFg91ZSKinvIwAc,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU = [],[]
	if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡯ࡳ࠸ࡄࡼࡩࡥ࠿ࠪᰎ") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,tM24jD1gO0(u"ࠨࡉࡈࡘࠬᰏ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡑࡁࡕࡍࡒ࡙࡙ࡋ࠭࠲ࡵࡷࠫᰐ"))
		if cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᰑ") in cnPhVmgFxA.headers:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᰒ")]
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,Fo1SgXMsHk(u"ࠬࡴࡡ࡮ࡧࠪᰓ"))
			ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o)
	elif flDSRbv57PnV3(u"࠭࡫ࡢࡶ࡮ࡳࡺࡺࡥ࠯ࡥࡲࡱࠬᰔ") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡈࡇࡗࠫᰕ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡐࡇࡔࡌࡑࡘࡘࡊ࠳࠲࡯ࡦࠪᰖ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		LITxrWQFSP = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭ࡶࠬࡢ࠮ࡦ࠰ࡰ࠲ࡥ࠭ࡦ࡟࠭࠳࠰࠿࡝ࠫ࡟࠭࠮࠴࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩᰗ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if LITxrWQFSP:
			LITxrWQFSP = LITxrWQFSP[f4fTutDOEwUeIoPLRQ]
			zq8hVp3J6dsvUN94FwcEPfLkCtM = oWMSrt64vnzZAJlBmf0Y7cDujLxVsb(LITxrWQFSP)
			pLhwC75ZXF0WgyDE = ScntgdOZCY74vNpXeW5jh8i.findall(SSvu1CZjTW7FcloNqD(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠬࠨᰘ"),zq8hVp3J6dsvUN94FwcEPfLkCtM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if pLhwC75ZXF0WgyDE:
				pLhwC75ZXF0WgyDE = pLhwC75ZXF0WgyDE[f4fTutDOEwUeIoPLRQ]
				pLhwC75ZXF0WgyDE = dr1zfnatJxRHSF48jh0eODm5bGu(t4txivgXSUWBOlCakQmNDjf(u"ࠫࡱ࡯ࡳࡵࠩᰙ"),pLhwC75ZXF0WgyDE)
				for dict in pLhwC75ZXF0WgyDE:
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࡬ࡩ࡭ࡧࠪᰚ")]
					uTKGhcXEIpmDf = dict[tM24jD1gO0(u"࠭࡬ࡢࡤࡨࡰࠬᰛ")]
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,DJ6ugPjW9bX8I(u"ࠧ࡯ࡣࡰࡩࠬᰜ"))
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(uTKGhcXEIpmDf+S3X6GcaiExOPtb+RWZpkDLtY5Eyb46029MvAKmqBQd8o)
		elif tM24jD1gO0(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᰝ") in cnPhVmgFxA.headers:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᰞ")]
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡲࡦࡳࡥࠨᰟ"))
			ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o)
		if X1mRwt2YJKgCLu9a67(u"ࠫࡄࡻࡲ࡭࠿࡫ࡸࡹࡶࡳ࠻࠱࠲ࡴ࡭ࡵࡴࡰࡵ࠱ࡥࡵࡶ࠮ࡨࡱࡲࠫᰠ") in url:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.split(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡅࡵࡳ࡮ࡀࠫᰡ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split(t4txivgXSUWBOlCakQmNDjf(u"࠭ࠦࠨᰢ"))[f4fTutDOEwUeIoPLRQ]
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(t4txivgXSUWBOlCakQmNDjf(u"ࠧࡱࡪࡲࡸࡴࡹࠠࡨࡱࡲ࡫ࡱ࡫ࠧᰣ"))
	else:
		NWtqFg91ZSKinvIwAc.append(url)
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,ulAxHwvzR9eTb5n(u"ࠨࡰࡤࡱࡪ࠭ᰤ"))
		ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o)
	if not NWtqFg91ZSKinvIwAc: return Fo1SgXMsHk(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡐࡇࡔࡌࡑࡘࡘࡊ࠭ᰥ"),[],[]
	elif len(NWtqFg91ZSKinvIwAc)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[f4fTutDOEwUeIoPLRQ]
	else:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪวำะัࠡษ็้้็ࠠศๆ่๊ฬูศࠨᰦ"),ifOk5xt1uHRJrTGFB7zZaeKIs6bqU)
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return X1mRwt2YJKgCLu9a67(u"ࠫࡊ࡞ࡉࡕࡡࡄࡐࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᰧ"),[],[]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = NWtqFg91ZSKinvIwAc[bCiGxXzDkH]
	return wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᰨ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def WbGIRfZTSKJLQ13cjXUqMFwrYyV68H(url):
	headers = {IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᰩ"):DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡌࡱࡧ࡭࠴࠭ᰪ")+str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)}
	for HT4fGXqv8hEcKsJ in range(t4txivgXSUWBOlCakQmNDjf(u"࠶࠲॰")):
		lQMuw1PvVpAk.sleep(IINBvuxkCSJrO1Q0UyngdLi(u"࠲࠱࠵࠵࠶ॱ"))
		cnPhVmgFxA = MOpDGnv1WA3hTxeE2R(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡉࡈࡘࠬᰫ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡍࡏࡐࡉࡏࡉ࡚࡙ࡅࡓࡅࡒࡒ࡙ࡋࡎࡕ࠯࠴ࡷࡹ࠭ᰬ"))
		if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᰭ") in list(cnPhVmgFxA.headers.keys()):
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[ulAxHwvzR9eTb5n(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᰮ")]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠫᰯ")+headers[bYyKEjIuGQzoq3AR1(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪᰰ")]
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
		if cnPhVmgFxA.code!=t4txivgXSUWBOlCakQmNDjf(u"࠷࠶࠾ॲ"): break
	return O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡊࡓࡔࡍࡌࡆࡗࡖࡉࡗࡉࡏࡏࡖࡈࡒ࡙࠭ᰱ"),[],[]
def OAKUxNEVDSguzfQ(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡉࡈࡘࠬᰲ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡖࡈࡐࡖࡒࡗࡌࡕࡏࡈࡎࡈ࠱࠶ࡹࡴࠨᰳ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡪࡦࡨࡳ࠲ࡪ࡯ࡸࡰ࡯ࡳࡦࡪࡳ࠯ࠬࡂ࠭ࠧ࠲࠮ࠫࡁ࠯࠲࠯ࡅࠬࠩ࠰࠭ࡃ࠮࠲ࠧᰴ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[uTKGhcXEIpmDf],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return X1mRwt2YJKgCLu9a67(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡐࡉࡑࡗࡓࡘࡍࡏࡐࡉࡏࡉࠬᰵ"),[],[]
def CXPRLeTGkJ(url):
	if YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࠵ࡷࡦࡧࡳ࡭ࡸ࠵ࠧᰶ") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,l4DS8mnEjHhFMZ5YOe(u"࠭ࡇࡆࡖ᰷ࠪ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡛ࡊࡉࡉࡎࡃ࠵࠱࠶ࡹࡴࠨ᰸"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡵࡺࡧ࡬ࡪࡶࡼࡂࠬ᰹"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		else: return qrjy8LuKVPNYdbSvzh(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤ࡜ࡋࡃࡊࡏࡄ࠶ࠬ᰺"),[],[]
	return X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᰻"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def HHs8Sbglyo(url):
	if qrjy8LuKVPNYdbSvzh(u"ࠫࡸ࡫ࡲࡷ࠿ࠪ᰼") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡍࡅࡕࠩ᰽"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡐࡒ࡙ࡔࡃࡃ࠰࠵ࡸࡺࠧ᰾"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(I3cxjYaHhsrM7T4UX26klN(u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᰿"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠣࡃ࡯ࡦࡦࡖ࡬ࡢࡻࡨࡶࡈࡵ࡮ࡵࡴࡲࡰࡡ࠮ࠧࠩ࠰࠭ࡃ࠮࠭ࠢ᱀"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
				url = Y7goyGlxwNaP1XcWU6e.b64decode(url)
				if IZhXMprxvAHqBEFkg0: url = url.decode(zSafwK0sDXdMN5JReniIQmrZxp)
			else: return cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡆࡒࡍࡔࡖࡅࡅࠬ᱁"),[],[]
	return O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᱂"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def STvH5VK2LM(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bYyKEjIuGQzoq3AR1(u"ࠫࡌࡋࡔࠨ᱃"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡗࡊࡒࡈࡅ࠳࠰࠵ࡸࡺࠧ᱄"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	UTvsQb4HpCP3Aeo2wDZG7X5V = NtZWe3LpRgnl29Vw(UTvsQb4HpCP3Aeo2wDZG7X5V)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ᱅"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]]
	return flDSRbv57PnV3(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡉࡅࡘࡋࡌࡉࡆ࠴ࠫ᱆"),[],[]
def rxPoLEUGuR(url):
	if len(url)>ulAxHwvzR9eTb5n(u"࠶࠵࠶ॳ"):
		url = url.strip(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ࠱ࠪ᱇"))+tM24jD1gO0(u"ࠩ࠲ࠫ᱈")
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡋࡊ࡚ࠧ᱉"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,qrjy8LuKVPNYdbSvzh(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡍࡃࡕࡓ࡟ࡇ࠭࠲ࡵࡷࠫ᱊"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		if f4fTutDOEwUeIoPLRQ and t4txivgXSUWBOlCakQmNDjf(u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠨࡩ࠮ࡸ࠰ࡳ࠲ࡴ࠭ࡧ࠯ࡶ࠮࠭᱋") in UTvsQb4HpCP3Aeo2wDZG7X5V:
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"࠭ࠢ࡭ࡱࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ᱌"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠵ॴ")]
				eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧ࠽ࡵࡦࡶ࡮ࡶࡴ࠿ࡸࡤࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡩࡲࡪࡲࡷࠫᱍ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if eXpgPIbRv2ZMGwjm5:
					G4JHzTEp61 = VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(eXpgPIbRv2ZMGwjm5[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠶ॵ")])
		elif len(UTvsQb4HpCP3Aeo2wDZG7X5V)<fgv5U2eRVaQqSiuGD(u"࠴࠱࠲ॶ"): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = UTvsQb4HpCP3Aeo2wDZG7X5V
		else: return q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡐࡆࡘࡏ࡛ࡃࠪᱎ"),[],[]
		return SSvu1CZjTW7FcloNqD(u"ࠩࠪᱏ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return z3sIGH8jmLYg(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭᱐"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def S5S2A0HuKB(url):
	if bnI4kmPtrW7yFEhljXOCq9(u"ࠫ࠴ࡪ࡯ࡸࡰ࠱ࡴ࡭ࡶࠧ᱑") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡍࡅࡕࠩ᱒"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡖࡌࡔࡌࡈࡂ࠯࠴ࡷࡹ࠭᱓"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡷࡳࡣࡳࡴࡪࡸ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᱔"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		url = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᱕"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def ddhk8UY93x(url):
	if X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡶࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭᱖") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,flDSRbv57PnV3(u"ࠪࡋࡊ࡚ࠧ᱗"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅ࠹࡛࠭࠲ࡵࡷࠫ᱘"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ᱙"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		if qrjy8LuKVPNYdbSvzh(u"࠭ࡨࡵࡶࡳࠫᱚ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᱛ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
		return YayJj10OGl(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁ࠵ࡗࠪᱜ"),[],[]
	return SSvu1CZjTW7FcloNqD(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᱝ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def K8bGaEqlm7(url):
	plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {ulAxHwvzR9eTb5n(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ᱞ"):O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬᱟ"),flDSRbv57PnV3(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᱠ"):Fo1SgXMsHk(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᱡ")}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡑࡑࡖࡘࠬᱢ"),plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡏࡑ࡚࠱࠶ࡹࡴࠨᱣ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(l4DS8mnEjHhFMZ5YOe(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᱤ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡐࡒ࡛ࠬᱥ"),[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᱦ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def vfJn9cWZFU(url):
	headers = {fgv5U2eRVaQqSiuGD(u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨᱧ"):t4txivgXSUWBOlCakQmNDjf(u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧᱨ")}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,DJ6ugPjW9bX8I(u"ࠧࡈࡇࡗࠫᱩ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡘࡎࡏࡐࡈࡓࡖࡔ࠳࠱ࡴࡶࠪᱪ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᱫ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return bYyKEjIuGQzoq3AR1(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨ࡙ࠥࡈࡐࡑࡉࡔࡗࡕࠧᱬ"),[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᱭ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def bVgMzdZK7e(url):
	plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {Fo1SgXMsHk(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᱮ"):usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽࠭ᱯ")}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡑࡑࡖࡘࠬᱰ"),plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡍࡇࡌࡂࡅࡌࡑࡆ࠳࠱ࡴࡶࠪᱱ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࠪࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿࡞ࠦࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨࠧ࡞ࠩࠪࠫᱲ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return UpQ56M0dO1N9xIvVegy(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡎࡁࡍࡃࡆࡍࡒࡇࠧᱳ"),[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	if I3cxjYaHhsrM7T4UX26klN(u"ࠫ࡭ࡺࡴࡱࠩᱴ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࡮ࡴࡵࡲ࠽ࠫᱵ")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	return IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱶ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def TTfGtcnHWg(url):
	f7Je8XzEqNpgHL9m4OURdAQ1,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = url,[],[]
	if IINBvuxkCSJrO1Q0UyngdLi(u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࠧᱷ") in url:
		plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᱸ"):cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤ࠼ࠢࡦ࡬ࡦࡸࡳࡦࡶࡀ࡙࡙ࡌ࠭࠹ࠩᱹ")}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,Fo1SgXMsHk(u"ࠪࡔࡔ࡙ࡔࠨᱺ"),plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡆࡈࡄࡐ࠯࠴ࡷࡹ࠭ᱻ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		DWeKu2Gsi84PbUEfhMwVNjloqg = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽࡜ࠤࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࠬࡣࠧࠨࠩᱼ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if DWeKu2Gsi84PbUEfhMwVNjloqg: f7Je8XzEqNpgHL9m4OURdAQ1 = DWeKu2Gsi84PbUEfhMwVNjloqg[f4fTutDOEwUeIoPLRQ]
	return YayJj10OGl(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᱽ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[f7Je8XzEqNpgHL9m4OURdAQ1]
def JfVHmqYKhQ(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡈࡇࡗࠫ᱾"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡙࡜ࡆࡖࡐ࠰࠵ࡸࡺࠧ᱿"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	OwDu7J6kbX9Qhlxid0SqLPZUW43 = ScntgdOZCY74vNpXeW5jh8i.findall(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠤࡹࡥࡷࠦࡦࡴࡧࡵࡺࠥࡃ࠮ࠫࡁࠪࠬ࠳࠰࠿ࠪࠩࠥᲀ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	if OwDu7J6kbX9Qhlxid0SqLPZUW43:
		OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43[f4fTutDOEwUeIoPLRQ][CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠳ॷ"):]
		OwDu7J6kbX9Qhlxid0SqLPZUW43 = Y7goyGlxwNaP1XcWU6e.b64decode(OwDu7J6kbX9Qhlxid0SqLPZUW43)
		if IZhXMprxvAHqBEFkg0: OwDu7J6kbX9Qhlxid0SqLPZUW43 = OwDu7J6kbX9Qhlxid0SqLPZUW43.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(YayJj10OGl(u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᲁ"),OwDu7J6kbX9Qhlxid0SqLPZUW43,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return fgv5U2eRVaQqSiuGD(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡔࡗࡈࡘࡒࠬᲂ"),[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	if bnI4kmPtrW7yFEhljXOCq9(u"ࠬ࡮ࡴࡵࡲࠪᲃ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡨࡵࡶࡳ࠾ࠬᲄ")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	return z3sIGH8jmLYg(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᲅ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def xxPROgUl28WZ(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡉࡈࡘࠬᲆ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓ࡙ࡆࡉ࡜࡚ࡎࡖ࠭࠲ࡵࡷࠫᲇ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠵࠷ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᲈ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍ࡚ࡇࡊ࡝࡛ࡏࡐࠨᲉ"),[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	return X1mRwt2YJKgCLu9a67(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᲊ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def d7aRis2qhk(url):
	id = url.split(bnI4kmPtrW7yFEhljXOCq9(u"࠭࠯ࠨ᲋"))[-IINBvuxkCSJrO1Q0UyngdLi(u"࠳ॸ")]
	if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࠰ࡧࡰࡦࡪࡪࠧ᲌") in url: url = url.replace(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨ࠱ࡨࡱࡧ࡫ࡤࠨ᲍"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	url = url.replace(tM24jD1gO0(u"ࠩ࠱ࡧࡴࡳ࠯ࠨ᲎"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪ࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡯ࡨࡸࡦࡪࡡࡵࡣ࠲ࠫ᲏"))
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡌࡋࡔࠨᲐ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠳࠱ࡴࡶࠪᲑ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	uusxjPSpV5c = wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠭Გ")
	pioIsrM6uymWHJRbhOYv = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠧࠣࡧࡵࡶࡴࡸࠢ࠯ࠬࡂࠦࡲ࡫ࡳࡴࡣࡪࡩࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᲓ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if pioIsrM6uymWHJRbhOYv: uusxjPSpV5c = pioIsrM6uymWHJRbhOYv[f4fTutDOEwUeIoPLRQ]
	url = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"ࠨࡺ࠰ࡱࡵ࡫ࡧࡖࡔࡏࠦ࠱ࠨࡵࡳ࡮ࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬᲔ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not url and uusxjPSpV5c:
		return uusxjPSpV5c,[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url[f4fTutDOEwUeIoPLRQ].replace(X1mRwt2YJKgCLu9a67(u"ࠩ࡟ࡠࠬᲕ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	Z82diNu7RlDybXFqVrvo,gCJprIs2wUzfcNhtxv = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	G7GhXQ9sRNCw6OnpymLMFcI1ZkU = ScntgdOZCY74vNpXeW5jh8i.findall(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࠦࡴࡽ࡮ࡦࡴࠥ࠾ࡡࢁࠢࡪࡦࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡵࡦࡶࡪ࡫࡮࡯ࡣࡰࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡷࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧᲖ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if G7GhXQ9sRNCw6OnpymLMFcI1ZkU: pp5MvZK9bFhDIJ6rYuizlgOA,cZfRJhSApvVbEH6k1jlqNnr5QdXC,UNogQA5qVyfilCkv4dP90pDLXm7M = G7GhXQ9sRNCw6OnpymLMFcI1ZkU[f4fTutDOEwUeIoPLRQ]
	else: pp5MvZK9bFhDIJ6rYuizlgOA,cZfRJhSApvVbEH6k1jlqNnr5QdXC,UNogQA5qVyfilCkv4dP90pDLXm7M = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	UNogQA5qVyfilCkv4dP90pDLXm7M = UNogQA5qVyfilCkv4dP90pDLXm7M.replace(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡡ࠵ࠧᲗ"),fgv5U2eRVaQqSiuGD(u"ࠬ࠵ࠧᲘ"))
	cZfRJhSApvVbEH6k1jlqNnr5QdXC = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(cZfRJhSApvVbEH6k1jlqNnr5QdXC)
	bbKoeBcirVfzwAqZdQUFDSX = [eMypvI8XqHjYU02anWD9gsSrkt+X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡏࡘࡐࡈࡖ࠿ࠦࠠࠨᲙ")+cZfRJhSApvVbEH6k1jlqNnr5QdXC+c7gxFyUCGm]+Z82diNu7RlDybXFqVrvo
	lPpY5fw3tOBcEye91Caun2FQZ = [UNogQA5qVyfilCkv4dP90pDLXm7M]+gCJprIs2wUzfcNhtxv
	bCiGxXzDkH = nnRXQH90qeOtABkJzGr(ulAxHwvzR9eTb5n(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨᲚ")+str(len(lPpY5fw3tOBcEye91Caun2FQZ)-fgv5U2eRVaQqSiuGD(u"࠴ॹ"))+ulAxHwvzR9eTb5n(u"ࠨ่่ࠢๆ࠯ࠧᲛ"),bbKoeBcirVfzwAqZdQUFDSX)
	if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return l4DS8mnEjHhFMZ5YOe(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᲜ"),[],[]
	elif bCiGxXzDkH==f4fTutDOEwUeIoPLRQ:
		vBWiqzoKuAxkDFLdHZjm9JrUy4t0I = Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[f4fTutDOEwUeIoPLRQ]+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠵࠲࠵ࠪࡺࡸ࡬࠾ࠩᲝ")+UNogQA5qVyfilCkv4dP90pDLXm7M+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࠫࡺࡥࡹࡶࡷࡁࠬᲞ")+cZfRJhSApvVbEH6k1jlqNnr5QdXC
		RarSo2nTfwU0WEGK.executebuiltin(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠤᲟ")+vBWiqzoKuAxkDFLdHZjm9JrUy4t0I+UpQ56M0dO1N9xIvVegy(u"ࠨࠩࠣᲠ"))
		return ulAxHwvzR9eTb5n(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᲡ"),[],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 =  lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def FO9Pcsk5Xz(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡉࡈࡘࠬᲢ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈࡏࡌࡔࡄ࠱࠶ࡹࡴࠨᲣ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if I3cxjYaHhsrM7T4UX26klN(u"ࠪ࠲࡯ࡹ࡯࡯ࠩᲤ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: url = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠫࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᲥ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: url = ScntgdOZCY74vNpXeW5jh8i.findall(X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᲦ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not url: return bYyKEjIuGQzoq3AR1(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡒࡏࡗࡇࠧᲧ"),[],[]
	url = url[f4fTutDOEwUeIoPLRQ]
	if SSvu1CZjTW7FcloNqD(u"ࠧࡩࡶࡷࡴࠬᲨ") not in url: url = tM24jD1gO0(u"ࠨࡪࡷࡸࡵࡀࠧᲩ")+url
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def uoA1SsdxjlhEkX5eivf(url):
	headers = { fgv5U2eRVaQqSiuGD(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ც") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	if SSvu1CZjTW7FcloNqD(u"ࠪࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬࠭Ძ") in url:
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠴ࡷࡹ࠭Წ"))
		items = ScntgdOZCY74vNpXeW5jh8i.findall(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡪࡩࡳࡧࡦࡸࠥࡲࡩ࡯࡭࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲭ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[items[f4fTutDOEwUeIoPLRQ]]
		else:
			CtO9cFuULSm62PWToMlzN1 = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡥࡳࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᲮ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if CtO9cFuULSm62PWToMlzN1:
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠩᲯ"),CtO9cFuULSm62PWToMlzN1[f4fTutDOEwUeIoPLRQ])
				return SSvu1CZjTW7FcloNqD(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࠩᲰ")+CtO9cFuULSm62PWToMlzN1[f4fTutDOEwUeIoPLRQ],[],[]
	else:
		Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = flDSRbv57PnV3(u"ࠩࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨࠬᲱ")
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠴ࡱࡨࠬᲲ"))
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(Fo1SgXMsHk(u"ࠫࡋࡵࡲ࡮ࠢࡰࡩࡹ࡮࡯ࡥ࠿ࠥࡔࡔ࡙ࡔࠣࠢࡤࡧࡹ࡯࡯࡯࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭Ჳ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: return SSvu1CZjTW7FcloNqD(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩᲴ"),[],[]
		f7Je8XzEqNpgHL9m4OURdAQ1 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ]
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭࠮ࡳࡣࡵࠫᲵ") in G4JHzTEp61 or DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧ࠯ࡼ࡬ࡴࠬᲶ") in G4JHzTEp61: return IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡏࡒࡗࡍࡇࡈࡅࡃࠣࡒࡴࡺࠠࡢࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪ࠭Ჷ"),[],[]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(YayJj10OGl(u"ࠩࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᲸ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = {}
		for xbfwC5hkXLvsJa8PReOS9AyU1z,XPL0O2VkI3w1C8enMaqi in items:
			iugaeRtZ5HFw7mJc9AdTbKlLV2[xbfwC5hkXLvsJa8PReOS9AyU1z] = XPL0O2VkI3w1C8enMaqi
		data = hS5pZyveLR0Ju4EksT2jQ9mrU(iugaeRtZ5HFw7mJc9AdTbKlLV2)
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,f7Je8XzEqNpgHL9m4OURdAQ1,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠵ࡵࡨࠬᲹ"))
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"ࠫࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡖࡪࡦࡨࡳ࠳࠰࠿ࡨࡧࡷࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࠯ࠬࡂࡷࡴࡻࡲࡤࡧࡶ࠾࠭࠴ࠪࡀࠫ࡬ࡱࡦ࡭ࡥ࠻ࠩᲺ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: return fgv5U2eRVaQqSiuGD(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡑࡖࡌࡆࡎࡄࡂࠩ᲻"),[],[]
		download = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ]
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨ࠮ࠫࡁࠥࢀ࠮࠭᲼"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,bbKoeBcirVfzwAqZdQUFDSX,dQS7hrjxHlAnZ14b,lPpY5fw3tOBcEye91Caun2FQZ,hljznvGk8csQf2ebuVUZy = [],[],[],[],[]
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠯࡯࠶ࡹ࠽࠭Ჽ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				lPpY5fw3tOBcEye91Caun2FQZ = lPpY5fw3tOBcEye91Caun2FQZ + dQS7hrjxHlAnZ14b
				if v4pVXJWMjUC6oaQ3DY7PqKTGOSZk[f4fTutDOEwUeIoPLRQ]==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨ࠯࠴ࠫᲾ"): bbKoeBcirVfzwAqZdQUFDSX.append(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࠣื๏ืแาࠢัหฺࠦࠧᲿ")+z3sIGH8jmLYg(u"ࠪࡱ࠸ࡻ࠸ࠡࠩ᳀")+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y)
				else:
					for title in v4pVXJWMjUC6oaQ3DY7PqKTGOSZk:
						bbKoeBcirVfzwAqZdQUFDSX.append(l4DS8mnEjHhFMZ5YOe(u"ู๊ࠫࠥาใิࠤำอีࠡࠩ᳁")+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡳ࠳ࡶ࠺ࠣࠫ᳂")+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y+S3X6GcaiExOPtb+title)
			else:
				title = title.replace(t4txivgXSUWBOlCakQmNDjf(u"࠭ࠬ࡭ࡣࡥࡩࡱࡀࠢࠨ᳃"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				title = title.strip(DJ6ugPjW9bX8I(u"ࠧࠣࠩ᳄"))
				title = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࠢึ๎ึ็ัࠡࠢัหฺࠦࠧ᳅")+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࠣࡱࡵ࠺ࠠࠨ᳆")+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y+S3X6GcaiExOPtb+title
				bbKoeBcirVfzwAqZdQUFDSX.append(title)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = bYyKEjIuGQzoq3AR1(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥ࠳ࡵ࡮࡭࡫ࡱࡩࠬ᳇") + download
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑࡖࡌࡆࡎࡄࡂ࠯࠸ࡸ࡭࠭᳈"))
		items = ScntgdOZCY74vNpXeW5jh8i.findall(X1mRwt2YJKgCLu9a67(u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭ࠤ᳉"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,EYMmnJAyxV,hash,loKjdNbfgBHGYITLaZiPJV in items:
			title = z3sIGH8jmLYg(u"࠭ࠠิ์ิๅึࠦสฮ็ํ่ࠥิวึࠢࠪ᳊")+Fo1SgXMsHk(u"ࠧࠡ࡯ࡳ࠸ࠥ࠭᳋")+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y+S3X6GcaiExOPtb+loKjdNbfgBHGYITLaZiPJV.split(flDSRbv57PnV3(u"ࠨࡺࠪ᳌"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = I3cxjYaHhsrM7T4UX26klN(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧ᳍")+id+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࠪࡲࡵࡤࡦ࠿ࠪ᳎")+EYMmnJAyxV+IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࠫ࡮ࡡࡴࡪࡀࠫ᳏")+hash
			hljznvGk8csQf2ebuVUZy.append(loKjdNbfgBHGYITLaZiPJV)
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		hljznvGk8csQf2ebuVUZy = set(hljznvGk8csQf2ebuVUZy)
		bEZpumacn58,XX4ukCywIBmMH = [],[]
		for title in bbKoeBcirVfzwAqZdQUFDSX:
			wgS3zkYrvX5R4DQi = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࠦࠨ࡝ࡦ࠭ࡼࢁࡢࡤࠫࠫࠩࠪࠧ᳐"),title+z3sIGH8jmLYg(u"࠭ࠦࠧࠩ᳑"),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for loKjdNbfgBHGYITLaZiPJV in hljznvGk8csQf2ebuVUZy:
				if wgS3zkYrvX5R4DQi[f4fTutDOEwUeIoPLRQ] in loKjdNbfgBHGYITLaZiPJV:
					title = title.replace(wgS3zkYrvX5R4DQi[f4fTutDOEwUeIoPLRQ],loKjdNbfgBHGYITLaZiPJV.split(l4DS8mnEjHhFMZ5YOe(u"ࠧࡹࠩ᳒"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
			bEZpumacn58.append(title)
		for WoEZvMXa0K2suwgPl in range(len(lPpY5fw3tOBcEye91Caun2FQZ)):
			items = ScntgdOZCY74vNpXeW5jh8i.findall(Fo1SgXMsHk(u"ࠣࠨࠩࠬ࠳࠰࠿ࠪࠪ࡟ࡨ࠯࠯ࠦࠧࠤ᳓"),SSvu1CZjTW7FcloNqD(u"᳔ࠩࠩࠪࠬ")+bEZpumacn58[WoEZvMXa0K2suwgPl]+YayJj10OGl(u"᳕ࠪࠪࠫ࠭"),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			XX4ukCywIBmMH.append( [bEZpumacn58[WoEZvMXa0K2suwgPl],lPpY5fw3tOBcEye91Caun2FQZ[WoEZvMXa0K2suwgPl],items[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ],items[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR]] )
		XX4ukCywIBmMH = sorted(XX4ukCywIBmMH, key=lambda BJou58vPwLqONbGtKTxsiASR1Cr: BJou58vPwLqONbGtKTxsiASR1Cr[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb], reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4)
		XX4ukCywIBmMH = sorted(XX4ukCywIBmMH, key=lambda BJou58vPwLqONbGtKTxsiASR1Cr: BJou58vPwLqONbGtKTxsiASR1Cr[QQSugEIn2mTCpRsfcaJHhPdAWzylM], reverse=SmbNGskjMx)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for WoEZvMXa0K2suwgPl in range(len(XX4ukCywIBmMH)):
			bbKoeBcirVfzwAqZdQUFDSX.append(XX4ukCywIBmMH[WoEZvMXa0K2suwgPl][f4fTutDOEwUeIoPLRQ])
			lPpY5fw3tOBcEye91Caun2FQZ.append(XX4ukCywIBmMH[WoEZvMXa0K2suwgPl][vkIa3ijEQVsJGdWOXwK7bnue9ADR])
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡍࡐࡕࡋࡅࡍࡊࡁࠨ᳖"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Tar1Wd7S2PUQpA0lmGCObunJLzsI(url):
	LCjugSrWIBPDyFb4X1o9fAM = url.split(bYyKEjIuGQzoq3AR1(u"ࠬࡅ᳗ࠧ"))
	plSscrVjkRviPwm = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
	headers = { fgv5U2eRVaQqSiuGD(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶ᳘ࠪ") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉ࠺࡚ࡓࡂࡔ࠰࠵ࡸࡺ᳙ࠧ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠨࡒ࡯ࡩࡦࡹࡥࠡࡹࡤ࡭ࡹ࠴ࠪࡀࡪࡵࡩ࡫ࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ᳚"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	url = items[f4fTutDOEwUeIoPLRQ]
	return X1mRwt2YJKgCLu9a67(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᳛"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def W2VX5ICc6PhxfLMldDroGANH8g(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	headers = { YayJj10OGl(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ᳜ࠧ") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶ᳝ࠪ"))
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ᳞ࠬࠦࠬ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]]
	else: return UpQ56M0dO1N9xIvVegy(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡄࡘ࡞࡟࡜ࡒࡍ᳟ࠩ"),[],[]
def OFqBIv3fPQwKy2MCa90xhi(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	headers = { paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᳠") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡃࡖࡎࡗ࡝ࡇࡕࡏࡌࡕ࠰࠵ࡸࡺࠧ᳡"))
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(X1mRwt2YJKgCLu9a67(u"ࠩ࡫ࡶࡪ࡬ࠢ࠭ࠤࠫ࡬ࡹࡺ࠮ࠫࡁ᳢ࠬࠦࠬ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if plSscrVjkRviPwm: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]]
	else: return Fo1SgXMsHk(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖ᳣ࠫ"),[],[]
def WVBqhxkTJo(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errno = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if flDSRbv57PnV3(u"ࠫ࠴ࡽࡰ࠮ࡣࡧࡱ࡮ࡴ࠯ࠨ᳤") in url:
		plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨ᳥ࠫ"):bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࡀࠦࡣࡩࡣࡵࡷࡪࡺ࠽ࡖࡖࡉ࠱࠽᳦࠭")}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡑࡑࡖࡘ᳧ࠬ"),plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭࠳ࡰࡧ᳨ࠫ"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		if fv4KNqjIBQT0UcHmlYSnrwOAWGV.startswith(bnI4kmPtrW7yFEhljXOCq9(u"ࠩ࡫ࡸࡹࡶࠧᳩ")): plSscrVjkRviPwm = fv4KNqjIBQT0UcHmlYSnrwOAWGV
		else:
			zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall(DJ6ugPjW9bX8I(u"ࠪࠫࠬࡹࡲࡤ࠿࡞ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠ࠭ࠢ࡞ࠩࠪࠫᳪ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if zb2QIaL7Y4h9g8lSck:
				plSscrVjkRviPwm = zb2QIaL7Y4h9g8lSck[f4fTutDOEwUeIoPLRQ]
				zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall(YayJj10OGl(u"ࠫࡸࡵࡵࡳࡥࡨࡁ࠭࠴ࠪࡀࠫ࡞ࠪࠩࡣࠧᳫ"),plSscrVjkRviPwm,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if zb2QIaL7Y4h9g8lSck:
					plSscrVjkRviPwm = SxN0jnqr3LI(zb2QIaL7Y4h9g8lSck[f4fTutDOEwUeIoPLRQ])
					return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	elif flDSRbv57PnV3(u"ࠬ࠵࡬ࡪࡰ࡮ࡷ࠴࠭ᳬ") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡇࡆࡖ᳭ࠪ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠳࠱ࡴࡶࠪᳮ"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		if q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᳯ") in list(cnPhVmgFxA.headers.keys()): plSscrVjkRviPwm = cnPhVmgFxA.headers[fgv5U2eRVaQqSiuGD(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᳰ")]
		else: plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪ࡭ࡩࡃࠢ࡭࡫ࡱ࡯ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᳱ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
	if xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫ࠴ࡼ࠯ࠨᳲ") in plSscrVjkRviPwm or YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࠵ࡦ࠰ࠩᳳ") in plSscrVjkRviPwm:
		plSscrVjkRviPwm = plSscrVjkRviPwm.replace(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭࠯ࡧ࠱ࠪ᳴"),qrjy8LuKVPNYdbSvzh(u"ࠧ࠰ࡣࡳ࡭࠴ࡹ࡯ࡶࡴࡦࡩ࠴࠭ᳵ"))
		plSscrVjkRviPwm = plSscrVjkRviPwm.replace(YayJj10OGl(u"ࠨ࠱ࡹ࠳ࠬᳶ"),qrjy8LuKVPNYdbSvzh(u"ࠩ࠲ࡥࡵ࡯࠯ࡴࡱࡸࡶࡨ࡫࠯ࠨ᳷"))
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,SSvu1CZjTW7FcloNqD(u"ࠪࡔࡔ࡙ࡔࠨ᳸"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠷ࡷࡪࠧ᳹"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		items = ScntgdOZCY74vNpXeW5jh8i.findall(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢ࡭ࡣࡥࡩࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᳺ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(flDSRbv57PnV3(u"࠭࡜࡝ࠩ᳻"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				bbKoeBcirVfzwAqZdQUFDSX.append(title)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		else:
			items = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠧࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᳼"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[f4fTutDOEwUeIoPLRQ]
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(I3cxjYaHhsrM7T4UX26klN(u"ࠨ࡞࡟ࠫ᳽"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				bbKoeBcirVfzwAqZdQUFDSX.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else: return l4DS8mnEjHhFMZ5YOe(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ᳾"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡌࡁࡋࡇࡕࡗࡍࡕࡗࠨ᳿"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def kDOBzqPZK3(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,Fo1SgXMsHk(u"ࠫࡌࡋࡔࠨᴀ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠳ࡶࡸࠬᴁ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errno = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if QlTuvPbSpnjygBVW(u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࠩᴂ") in url or O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࠨᴃ") in url:
		if QlTuvPbSpnjygBVW(u"ࠨࡲ࡯ࡥࡾ࡫ࡲࡠࡧࡰࡦࡪࡪ࠮ࡱࡪࡳࠫᴄ") in url:
			plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᴅ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
		else: plSscrVjkRviPwm = url
		if usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡱࡴࡼࡳ࠵ࡷࠪᴆ") not in plSscrVjkRviPwm: return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᴇ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bYyKEjIuGQzoq3AR1(u"ࠬࡍࡅࡕࠩᴈ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡐࡓ࡛࡙࠴ࡖ࠯࠵ࡲࡩ࠭ᴉ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡪࡦࡀࠦࡵࡲࡡࡺࡧࡵࠦ࠭࠴ࠪࡀࠫࡹ࡭ࡩ࡫࡯࡫ࡵࠪᴊ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࠾ࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡯ࡥࡧ࡫࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᴋ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,NNntz8hA93kG6WqEDb1OUoeFm2fg in items:
				bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	elif I3cxjYaHhsrM7T4UX26klN(u"ࠩࡰࡥ࡮ࡴ࡟ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫᴌ") in url:
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧᴍ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡌࡋࡔࠨᴎ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏࡒ࡚ࡘ࠺ࡕ࠮࠵ࡵࡨࠬᴏ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		zb2QIaL7Y4h9g8lSck = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᴐ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		zb2QIaL7Y4h9g8lSck = zb2QIaL7Y4h9g8lSck[f4fTutDOEwUeIoPLRQ]
		bbKoeBcirVfzwAqZdQUFDSX.append(nbOFVEDkpT4BIR7Qq82yPmHeJU)
		lPpY5fw3tOBcEye91Caun2FQZ.append(zb2QIaL7Y4h9g8lSck)
	elif usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧᴑ") in url:
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᴒ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
			return CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᴓ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡓࡏࡗࡕ࠷࡙ࠬᴔ"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def hXfZLEF01s(url):
	if tM24jD1gO0(u"ࠫࡄ࡭ࡥࡵ࠿ࠪᴕ") in url:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.split(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡅࡧࡦࡶࡀࠫᴖ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = Y7goyGlxwNaP1XcWU6e.b64decode(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if IZhXMprxvAHqBEFkg0: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.decode(zSafwK0sDXdMN5JReniIQmrZxp,flDSRbv57PnV3(u"࠭ࡩࡨࡰࡲࡶࡪ࠭ᴗ"))
		return QlTuvPbSpnjygBVW(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᴘ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	website = sCSyOla9hrcE[DJ6ugPjW9bX8I(u"ࠨࡅࡌࡑࡆࡉࡌࡖࡄࠪᴙ")][f4fTutDOEwUeIoPLRQ]
	headers = {QlTuvPbSpnjygBVW(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᴚ"):website}
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡋࡊ࡚ࠧᴛ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡈࡒࡕࡃ࠯࠵ࡲࡩ࠭ᴜ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡻࡲ࡭ࠩᴝ"))
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠾࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᴞ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠢࡴࡱࡸࡶࡨ࡫ࡳ࠻ࠢ࡟࡟ࠬ࠮࠮ࠫࡁࠬࠫࠧᴟ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠣࡨ࡬ࡰࡪࡀࠧࠩ࠰࠭ࡃ࠮࠭ࠢᴠ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬᴡ")+website
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	if DJ6ugPjW9bX8I(u"ࠪࡲࡦࡳࡥ࠾ࠤ࡛ࡸࡴࡱࡥ࡯ࠤࠪᴢ") in UTvsQb4HpCP3Aeo2wDZG7X5V:
		wBetPUDiRjrOGgdLYWF0u49K1AQ = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡜ࡹࡵ࡫ࡦࡰࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴣ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if wBetPUDiRjrOGgdLYWF0u49K1AQ:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = wBetPUDiRjrOGgdLYWF0u49K1AQ[f4fTutDOEwUeIoPLRQ]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = Y7goyGlxwNaP1XcWU6e.b64decode(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			if IZhXMprxvAHqBEFkg0: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.decode(zSafwK0sDXdMN5JReniIQmrZxp,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬᴤ"))
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"࠭ࡨࡵࡶࡳ࠲࠯ࡅࠨࡩࡶࡷࡴ࠳࠰࠿ࠪ࠮ࠪᴥ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]+z3sIGH8jmLYg(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᴦ")+website
				return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᴧ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def O6kUi5MdYE(url,JygZr6tXVAOGqPoF):
	ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = [],[]
	if QlTuvPbSpnjygBVW(u"ࠩ࠲࠵࠴࠭ᴨ") in url:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.replace(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࠳࠶࠵ࠧᴩ"),qrjy8LuKVPNYdbSvzh(u"ࠫ࠴࠺࠯ࠨᴪ"))
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,qrjy8LuKVPNYdbSvzh(u"ࠬࡍࡅࡕࠩᴫ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠴࠱࠶ࡹࡴࠨᴬ"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧ࠽ࡸ࡬ࡨࡪࡵࠨ࠯ࠬࡂ࠭ࡁ࠵ࡶࡪࡦࡨࡳࡃ࠭ᴭ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
			items = ScntgdOZCY74vNpXeW5jh8i.findall(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵ࡬ࡾࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᴮ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in NWtqFg91ZSKinvIwAc:
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X1mRwt2YJKgCLu9a67(u"ࠩࡱࡥࡲ࡫ࠧᴯ"))
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(RWZpkDLtY5Eyb46029MvAKmqBQd8o+BhmzEC6OGD7FXZig9Tp5A+uTKGhcXEIpmDf)
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
	elif bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪ࠳ࡩ࠵ࠧᴰ") in url:
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,UpQ56M0dO1N9xIvVegy(u"ࠫࡌࡋࡔࠨᴱ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠶ࡳࡪࠧᴲ"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᴳ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ].replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧ࠰࠳࠲ࠫᴴ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨ࠱࠷࠳ࠬᴵ"))
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,ulAxHwvzR9eTb5n(u"ࠩࡊࡉ࡙࠭ᴶ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠱࠮࠵ࡵࡨࠬᴷ"))
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠫࡨࡲࡡࡴࡵ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᴸ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return bYyKEjIuGQzoq3AR1(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᴹ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]]
	elif qrjy8LuKVPNYdbSvzh(u"࠭࠯ࡳࡱ࡯ࡩ࠴࠭ᴺ") in url:
		headers = {X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨᴻ"):JygZr6tXVAOGqPoF}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡉࡈࡘࠬᴼ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠷࠭࠵ࡶ࡫ࠫᴽ"))
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬᴾ")]
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡌࡋࡔࠨᴿ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠳࠰࠹ࡹ࡮ࠧᵀ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = mknXS3i7th0LRWj2xaF4YgcpuzGE(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,UTvsQb4HpCP3Aeo2wDZG7X5V)
		return uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
	elif xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪᵁ") in url:
		plSscrVjkRviPwm = url.replace(tM24jD1gO0(u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠲ࠫᵂ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨ࠱ࡶࡧࡷ࡯ࡰࡵ࠱ࠪᵃ"))
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {I3cxjYaHhsrM7T4UX26klN(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᵄ"):JygZr6tXVAOGqPoF}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡋࡊ࡚ࠧᵅ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠹ࡸ࡭࠭ᵆ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᵇ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
			cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡇࡆࡖࠪᵈ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡉࡌ࡟ࡂࡆࡕࡗ࠵࠲࠽ࡴࡩࠩᵉ"))
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪᵊ") in list(cnPhVmgFxA.headers.keys()):
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[z3sIGH8jmLYg(u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫᵋ")]
				cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡋࡊ࡚ࠧᵌ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡆࡉ࡜ࡆࡊ࡙ࡔ࠲࠯࠻ࡸ࡭࠭ᵍ"))
				UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
				uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = mknXS3i7th0LRWj2xaF4YgcpuzGE(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,UTvsQb4HpCP3Aeo2wDZG7X5V)
				if NWtqFg91ZSKinvIwAc: return uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
			elif ulAxHwvzR9eTb5n(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠭ᵎ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲࡂ࡭ࡩࡃࠧᵏ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠰࡬ࡺࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶ࠿ࡪࡦࡀࠫᵐ"))
				return wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᵑ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else: return qrjy8LuKVPNYdbSvzh(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᵒ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	return bYyKEjIuGQzoq3AR1(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡋࡇ࡚ࡄࡈࡗ࡙࠷ࠧᵓ"),[],[]
def Njvc8kFO4M(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡌࡋࡔࠨᵔ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠵࠰࠵ࡸࡺࠧᵕ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	data = ScntgdOZCY74vNpXeW5jh8i.findall(I3cxjYaHhsrM7T4UX26klN(u"࠭ࠢࡢࡥࡷ࡭ࡴࡴࠢ࠯ࠬࡂࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᵖ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if data:
		sRdbohGut7qZyfOXJEDeQHcgKY,id,J0ztXV9EeMWdUoySsCZ2wnp6 = data[f4fTutDOEwUeIoPLRQ]
		data = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡰࡲࡀࠫᵗ")+sRdbohGut7qZyfOXJEDeQHcgKY+DJ6ugPjW9bX8I(u"ࠨࠨ࡬ࡨࡂ࠭ᵘ")+id+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࠩࡪࡳࡧ࡭ࡦ࠿ࠪᵙ")+J0ztXV9EeMWdUoySsCZ2wnp6
		headers = {I3cxjYaHhsrM7T4UX26klN(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᵚ"):SSvu1CZjTW7FcloNqD(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪᵛ")}
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡖࡏࡔࡖࠪᵜ"),url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠶࠱࠷ࡴࡤࠨᵝ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࠣࡴࡨࡪࡪࡸࡥࡳࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᵞ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return tM24jD1gO0(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᵟ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]]
	return l4DS8mnEjHhFMZ5YOe(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ᵠ"),[],[]
def IcsWHablxw(url):
	headers = {O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ᵡ"):I3cxjYaHhsrM7T4UX26klN(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬᵢ")}
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,SSvu1CZjTW7FcloNqD(u"ࠬࡍࡅࡕࠩᵣ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡋ࡞ࡈࡅࡔࡖ࠷࠱࠶ࡹࡴࠨᵤ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᵥ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		return SSvu1CZjTW7FcloNqD(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᵦ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return tM24jD1gO0(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘ࠶࠭ᵧ"),[],[]
def haJBXMtW9Y(url):
	plSscrVjkRviPwm = url.split(bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫᵨ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ].strip(bYyKEjIuGQzoq3AR1(u"ࠫࡄ࠭ᵩ")).strip(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬ࠵ࠧᵪ")).strip(X1mRwt2YJKgCLu9a67(u"࠭ࠦࠨᵫ"))
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,items,zb2QIaL7Y4h9g8lSck = [],[],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	headers = { yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᵬ"):paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠨᵭ") }
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡊࡉ࡙࠭ᵮ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅࡈ࡛ࡅࡉࡘ࡚࠭࠲ࡵࡷࠫᵯ"))
	if flDSRbv57PnV3(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᵰ") in list(cnPhVmgFxA.headers.keys()): zb2QIaL7Y4h9g8lSck = cnPhVmgFxA.headers[QlTuvPbSpnjygBVW(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᵱ")]
	if fgv5U2eRVaQqSiuGD(u"࠭ࡨࡵࡶࡳࠫᵲ") in zb2QIaL7Y4h9g8lSck:
		if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨᵳ") in url: zb2QIaL7Y4h9g8lSck = zb2QIaL7Y4h9g8lSck.replace(fgv5U2eRVaQqSiuGD(u"ࠨ࠱ࡩ࠳ࠬᵴ"),QlTuvPbSpnjygBVW(u"ࠩ࠲ࡺ࠴࠭ᵵ"))
		hNZCDv9ReVup = plSscrVjkRviPwm.split(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡃࡕࡎࡐࡔࡋࡇࡁࠬᵶ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		headers = { X1mRwt2YJKgCLu9a67(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᵷ"):headers[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᵸ")] , I3cxjYaHhsrM7T4UX26klN(u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ᵹ"):ulAxHwvzR9eTb5n(u"ࠧࡑࡊࡓࡗࡎࡊ࠽ࠨᵺ")+hNZCDv9ReVup }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,X1mRwt2YJKgCLu9a67(u"ࠨࡉࡈࡘࠬᵻ"),zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬᵼ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪ࠳࡫࠵ࠧᵽ") in zb2QIaL7Y4h9g8lSck: items = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠫࡁ࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᵾ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		elif fgv5U2eRVaQqSiuGD(u"ࠬ࠵ࡶ࠰ࠩᵿ") in zb2QIaL7Y4h9g8lSck: items = ScntgdOZCY74vNpXeW5jh8i.findall(I3cxjYaHhsrM7T4UX26klN(u"࠭ࡩࡥ࠿ࠥࡺ࡮ࡪࡥࡰࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᶀ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items: return [],[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
		elif wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧ࠽ࡪ࠴ࡂ࠹࠶࠴࠽࠱࡫࠵ࡃ࠭ᶁ") in UTvsQb4HpCP3Aeo2wDZG7X5V:
			return I3cxjYaHhsrM7T4UX26klN(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡีํีๆืࠠศๆไ๎ิ๐่ࠡใํ๋ࠥำฬษูࠢำ้่ࠥะ์ࠣ์๊฻ฯา้้๋ࠣࠦวๅว้ฮึ์สࠡษ็าฬ฻ษࠡสๆࠫᶂ"),[],[]
	else: return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡊࡍ࡙ࡃࡇࡖࡘࠬᶃ"),[],[]
def vID5SVuoAQ(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡴࡴࡹࡴࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࠪࠬᶄ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+bYyKEjIuGQzoq3AR1(u"ࠫࠫࠬࠧᶅ"),ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
	url = t4txivgXSUWBOlCakQmNDjf(u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡦࡴ࡬ࡩࡸ࠺ࡷࡢࡶࡦ࡬࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭ᶆ")+lShZiBC3zc7yrx+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪᶇ")+g7EnObA021BoG9dwYky
	headers = { UpQ56M0dO1N9xIvVegy(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᶈ"):nbOFVEDkpT4BIR7Qq82yPmHeJU , wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫᶉ"):O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪᶊ") }
	plSscrVjkRviPwm = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࠷ࡳࡵࠩᶋ"))
	return tM24jD1gO0(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧᶌ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def mJhnvlc9Rr(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡻࡲ࡭ࠩᶍ"))
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {l4DS8mnEjHhFMZ5YOe(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᶎ"):RWZpkDLtY5Eyb46029MvAKmqBQd8o,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩᶏ"):flDSRbv57PnV3(u"ࠨࡩࡽ࡭ࡵ࠲ࠠࡥࡧࡩࡰࡦࡺࡥࠨᶐ")}
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡊࡉ࡙࠭ᶑ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍ࡚ࡅࡌࡑࡆ࠳࠱ࡴࡶࠪᶒ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡵࡲࡡࡺࡧࡵ࠲ࡶࡻࡡ࡭࡫ࡷࡽࡸ࡫࡬ࡦࡥࡷࡳࡷ࠮࠮ࠫࡁࠬࡪࡴࡸ࡭ࡢࡶࡶ࠾ࠬᶓ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠬ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦ࡜ࠨࠪ࡟ࡨ࠳࠰࠿ࠪ࡞ࠪ࠰ࠥࡹࡲࡤ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫᶔ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[f4fTutDOEwUeIoPLRQ]
		elif len(lPpY5fw3tOBcEye91Caun2FQZ)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr(bYyKEjIuGQzoq3AR1(u"࠭รฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีหࠫᶕ"), bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return QlTuvPbSpnjygBVW(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᶖ"),[],[]
			plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᶗ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: plSscrVjkRviPwm = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
	if not plSscrVjkRviPwm: return bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠤࡒ࡟ࡃࡊࡏࡄࠫᶘ"),[],[]
	return YayJj10OGl(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᶙ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def zzhfIeX30wJVOH4qdQutYWD27(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡺࡸ࡬ࠨᶚ"))
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᶛ"):RWZpkDLtY5Eyb46029MvAKmqBQd8o,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨᶜ"):xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧᶝ")}
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡉࡈࡘࠬᶞ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡝ࡅࡄࡋࡐࡅ࠲࠷ࡳࡵࠩᶟ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡴࡱࡧࡹࡦࡴ࠱ࡵࡺࡧ࡬ࡪࡶࡼࡷࡪࡲࡥࡤࡶࡲࡶ࠭࠴ࠪࡀࠫࡩࡳࡷࡳࡡࡵࡵ࠽ࠫᶠ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪᶡ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if len(lPpY5fw3tOBcEye91Caun2FQZ)==vkIa3ijEQVsJGdWOXwK7bnue9ADR: plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[f4fTutDOEwUeIoPLRQ]
		elif len(lPpY5fw3tOBcEye91Caun2FQZ)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪᶢ"), bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return bYyKEjIuGQzoq3AR1(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᶣ"),[],[]
			plSscrVjkRviPwm = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	if not plSscrVjkRviPwm:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᶤ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: plSscrVjkRviPwm = eXpgPIbRv2ZMGwjm5[f4fTutDOEwUeIoPLRQ]
	if not plSscrVjkRviPwm: return CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡊࡉࡉࡎࡃࠪᶥ"),[],[]
	return DJ6ugPjW9bX8I(u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬᶦ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def NC5BwOzQK0(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡢ࠿ࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩᶧ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+DJ6ugPjW9bX8I(u"ࠫࠫࠬࠧᶨ"),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	url,lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
	data = {fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩ࠭ᶩ"):lShZiBC3zc7yrx,Fo1SgXMsHk(u"࠭ࡳࡦࡴࡹࡩࡷ࠭ᶪ"):g7EnObA021BoG9dwYky}
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡑࡑࡖࡘࠬᶫ"),url,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏࡆࡅࡒ࠳࠱ࡴࡶࠪᶬ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(z3sIGH8jmLYg(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᶭ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
	return UpQ56M0dO1N9xIvVegy(u"ࠪࡒࡊࡋࡄࡠࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠭ᶮ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def eCcV9bE5Xv(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,UpQ56M0dO1N9xIvVegy(u"ࠫࡌࡋࡔࠨᶯ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡒࡉࡈࡊࡗ࠱࠶ࡹࡴࠨᶰ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"࠭࠼ࡪࡨࡵࡥࡲ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᶱ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return SSvu1CZjTW7FcloNqD(u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪᶲ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return fgv5U2eRVaQqSiuGD(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡇࡎࡓࡁࡍࡋࡊࡌ࡙࠭ᶳ"),[],[]
def aXsbM5p7he(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,tM24jD1gO0(u"ࠩࡊࡉ࡙࠭ᶴ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡇࡑ࡛ࡐ࠮࠳ࡶࡸࠬᶵ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡁࡏࡆࡓࡃࡐࡉ࡙ࠥࡒࡄ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᶶ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
	return fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨᶷ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def nIEpzfZOeA(url):
	jqDXgyUVZ2 = Qi32bRtN18qvyWmaO7YKow9cXs(url,xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡵࡳ࡮ࠪᶸ"))
	if qrjy8LuKVPNYdbSvzh(u"ࠧࡪࡰࡧࡩࡽࡃࠧᶹ") in url:
		headers = {IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᶺ"):jqDXgyUVZ2}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,qrjy8LuKVPNYdbSvzh(u"ࠩࡊࡉ࡙࠭ᶻ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡃࡊࡏࡄࡒࡔ࡝࠭࠲ࡵࡷࠫᶼ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(flDSRbv57PnV3(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᶽ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
			if paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬ࡮ࡴࡵࡲࠪᶾ") not in plSscrVjkRviPwm: plSscrVjkRviPwm = UpQ56M0dO1N9xIvVegy(u"࠭ࡨࡵࡶࡳ࠾ࠬᶿ")+plSscrVjkRviPwm
			if X1mRwt2YJKgCLu9a67(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨ᷀") in plSscrVjkRviPwm:
				plSscrVjkRviPwm = plSscrVjkRviPwm.replace(ulAxHwvzR9eTb5n(u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠪ᷁"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱᷂ࠪ"))
				cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡋࡊ࡚ࠧ᷃"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬ᷄"))
				fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
				items = ScntgdOZCY74vNpXeW5jh8i.findall(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᷅"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
				ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡵࡳ࡮ࠪ᷆"))
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in reversed(items):
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ksHfTPuQMGB+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+QlTuvPbSpnjygBVW(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪ᷇")+ksHfTPuQMGB
					bbKoeBcirVfzwAqZdQUFDSX.append(uTKGhcXEIpmDf)
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
			else: return qrjy8LuKVPNYdbSvzh(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ᷈"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	plSscrVjkRviPwm = url+t4txivgXSUWBOlCakQmNDjf(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬ᷉")+jqDXgyUVZ2
	if flDSRbv57PnV3(u"ࠪ࡬ࡹࡺࡰࠨ᷊") not in plSscrVjkRviPwm: plSscrVjkRviPwm = fgv5U2eRVaQqSiuGD(u"ࠫ࡭ࡺࡴࡱ࠼ࠪ᷋")+plSscrVjkRviPwm
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
def a3kMrZmR9JojtwAC7H6ePzs18Xuv(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	jqDXgyUVZ2 = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,tM24jD1gO0(u"ࠬࡻࡲ࡭ࠩ᷌"))
	if YayJj10OGl(u"࠭ࡰࡰࡵࡷ࡭ࡩ࠭᷍") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(DJ6ugPjW9bX8I(u"ࠧࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡟ࡃࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁ᷎ࠬࠪࠫ࠭"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࠨ᷏ࠩࠫ"),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		url,lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		data = {l4DS8mnEjHhFMZ5YOe(u"ࠩ࡬ࡨ᷐ࠬ"):lShZiBC3zc7yrx,bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡷࡪࡸࡶࡦࡴࠪ᷑"):g7EnObA021BoG9dwYky}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,ulAxHwvzR9eTb5n(u"ࠫࡕࡕࡓࡕࠩ᷒"),url,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡅࡌࡑࡆࡔࡏࡘ࠯࠴ࡷࡹ࠭ᷓ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᷔ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[f4fTutDOEwUeIoPLRQ]
		if SSvu1CZjTW7FcloNqD(u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨᷕ") in plSscrVjkRviPwm:
			headers = {YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᷖ"):jqDXgyUVZ2,bYyKEjIuGQzoq3AR1(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᷗ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
			cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡋࡊ࡚ࠧᷘ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡄࡋࡐࡅࡓࡕࡗ࠮࠴ࡱࡨࠬᷙ"))
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
			items = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡩࡻࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᷚ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
			ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,bYyKEjIuGQzoq3AR1(u"࠭ࡵࡳ࡮ࠪᷛ"))
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in reversed(items):
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ksHfTPuQMGB+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪᷜ")+ksHfTPuQMGB
				bbKoeBcirVfzwAqZdQUFDSX.append(uTKGhcXEIpmDf)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
		else: return xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫᷝ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	else:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁࠬᷞ")+jqDXgyUVZ2
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
def czHXgtQlrJ(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	if usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡴࡴࡹࡴࡪࡦࠪᷟ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭ᷠ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+fgv5U2eRVaQqSiuGD(u"ࠬࠬࠦࠨᷡ"),ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		fi7k6GdJ5p30raYvIozqnZEmFVubjA = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡵࡳ࡮ࠪᷢ"))
		url = fi7k6GdJ5p30raYvIozqnZEmFVubjA+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬᷣ")+lShZiBC3zc7yrx+X1mRwt2YJKgCLu9a67(u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬᷤ")+g7EnObA021BoG9dwYky
		headers = { z3sIGH8jmLYg(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᷥ"):nbOFVEDkpT4BIR7Qq82yPmHeJU , bnI4kmPtrW7yFEhljXOCq9(u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ᷦ"):Fo1SgXMsHk(u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬᷧ") }
		plSscrVjkRviPwm = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡆࡑࡏࡏࡏ࡜࠰࠵ࡸࡺࠧᷨ"))
		plSscrVjkRviPwm = plSscrVjkRviPwm.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		return q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩᷩ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	elif cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧ࠰ࡴࡨࡨ࡮ࡸࡥࡤࡶ࠲ࠫᷪ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		HDYwF4bPdEQBy2lRhkisKfV9xaXr = f4fTutDOEwUeIoPLRQ
		while QlTuvPbSpnjygBVW(u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬᷫ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and HDYwF4bPdEQBy2lRhkisKfV9xaXr<yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠹ॺ"):
			cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,qrjy8LuKVPNYdbSvzh(u"ࠩࡊࡉ࡙࠭ᷬ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,I3cxjYaHhsrM7T4UX26klN(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡓࡄࡏࡍࡔࡔ࡚࠮࠴ࡱࡨࠬᷭ"))
			if wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ᷮ") in list(cnPhVmgFxA.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧᷯ")]
			HDYwF4bPdEQBy2lRhkisKfV9xaXr += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else: return bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪᷰ"),[],[]
def cczNkUM8e6(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,DJ6ugPjW9bX8I(u"ࠧࡶࡴ࡯ࠫᷱ"))
	headers = {qrjy8LuKVPNYdbSvzh(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᷲ"):RWZpkDLtY5Eyb46029MvAKmqBQd8o,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᷳ"):MdwGcQOsmlV6vKI73THrUY4()}
	if flDSRbv57PnV3(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫᷴ") in url:
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭᷵"))
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(flDSRbv57PnV3(u"ࠬࡂࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᷶"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ].replace(l4DS8mnEjHhFMZ5YOe(u"࠭ࡨࡵࡶࡳࡷ᷷ࠬ"),QlTuvPbSpnjygBVW(u"ࠧࡩࡶࡷࡴ᷸ࠬ"))
			return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else:
		lHzwp04JAKfQ9v6 = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡉࡈࡘ᷹ࠬ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠴ࡴࡧ᷺ࠫ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = lHzwp04JAKfQ9v6.content
		GcYwHSWoQ0Nq8KFfJDdvujZryM = headers.copy()
		if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡣࡱࡴ࡫ࡠࠩ᷻") in str(lHzwp04JAKfQ9v6.cookies):
			cookies = lHzwp04JAKfQ9v6.cookies
			GcYwHSWoQ0Nq8KFfJDdvujZryM[l4DS8mnEjHhFMZ5YOe(u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ᷼")] = SxN0jnqr3LI(hS5pZyveLR0Ju4EksT2jQ9mrU(cookies))
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡲࡩ࡯࡭࠱࡬ࡷ࡫ࡦࠡ࠿ࠣࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ᷽"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ᷾"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ])+SSvu1CZjTW7FcloNqD(u"ࠧࠧࡦࡀ࠵᷿ࠬ")
			KXFGbQxMAgBRYh = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡉࡈࡘࠬḀ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡖࡉࡊࡊ࠭࠵ࡶ࡫ࠫḁ"))
			UTvsQb4HpCP3Aeo2wDZG7X5V = KXFGbQxMAgBRYh.content
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪ࡭ࡩࡃࠢࡣࡶࡱࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ḃ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ])
				if bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡲࡶ࠴ࠨḃ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬ࠵ࡤ࠰ࠩḄ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
				else: return SSvu1CZjTW7FcloNqD(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩḅ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return UpQ56M0dO1N9xIvVegy(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫḆ"),[],[]
def v1skFBGlrX(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	if DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࡡࡤࡧࡹ࡯࡯࡯࠿ࡪࡩࡹࡹࡥࡳࡸࡨࡶࠬḇ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		headers = {O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬḈ"):bnI4kmPtrW7yFEhljXOCq9(u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫḉ")}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡌࡋࡔࠨḊ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰࠵ࡸࡺࠧḋ"))
		url = cnPhVmgFxA.content
		if url: return cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩḌ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	else:
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(tM24jD1gO0(u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠤࠨḍ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if not LCjugSrWIBPDyFb4X1o9fAM: LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠨࡡࡳࡳࡸࡺ࡟ࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠧࠫḎ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		lShZiBC3zc7yrx,g7EnObA021BoG9dwYky = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡸࡶࡱ࠭ḏ"))
		url = RWZpkDLtY5Eyb46029MvAKmqBQd8o+X60YQOADpkHBb31LiR5qUEKfM(u"ࠪ࠳ࡼࡶ࠭ࡤࡱࡱࡸࡪࡴࡴ࠰ࡶ࡫ࡩࡲ࡫ࡳ࠰ࡶ࡫ࡩࡲ࡫࠯ࡂ࡬ࡤࡼࡦࡺ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫḐ")
		data = {bYyKEjIuGQzoq3AR1(u"ࠫ࡮ࡪࠧḑ"):lShZiBC3zc7yrx,ulAxHwvzR9eTb5n(u"ࠬ࡯ࠧḒ"):g7EnObA021BoG9dwYky}
		headers = {I3cxjYaHhsrM7T4UX26klN(u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩḓ"):Fo1SgXMsHk(u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨḔ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩḕ"):grwO1UeqkvQBf4tmz0jTx3lEKZWbF6}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡓࡓࡘ࡚ࠧḖ"),url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DJ6ugPjW9bX8I(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮࠴ࡱࡨࠬḗ"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		plSscrVjkRviPwm = ScntgdOZCY74vNpXeW5jh8i.findall(fgv5U2eRVaQqSiuGD(u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩḘ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if plSscrVjkRviPwm:
			plSscrVjkRviPwm = plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ]
			return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨḙ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	return yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡕࡋࡅࡍࡏࡄ࠵ࡗࠪḚ"),[],[]
def U1uEz7TJBG5DjY9I8FoNrXfax2k(jUu9KomxkPAGDftYcq5a6lySB7X28):
	aWiAjtGlKhXeH64Iy = llnG7jiQBYKhAeovbT.getSetting(flDSRbv57PnV3(u"ࠧࡢࡸ࠱ࡥࡰࡽࡡ࡮࠰ࡹࡩࡷ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠨḛ"))
	headers = {usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡅࡲࡳࡰ࡯ࡥࠨḜ"):aWiAjtGlKhXeH64Iy} if aWiAjtGlKhXeH64Iy else nbOFVEDkpT4BIR7Qq82yPmHeJU
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡊࡉ࡙࠭ḝ"),jUu9KomxkPAGDftYcq5a6lySB7X28,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,qrjy8LuKVPNYdbSvzh(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂ࡚ࡒࡄࡗࡘࡥࡁࡌ࡙ࡄࡑࡤࡉࡁࡑࡖࡆࡌࡆ࠳࠱ࡴࡶࠪḞ"))
	XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
	zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0 = str(cnPhVmgFxA.headers)
	n3j1bdVU6vgqukC = zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0+XvREomOzBpM81LVstnFJheUScZ
	if flDSRbv57PnV3(u"ࠫ࠳ࡳࡰ࠵ࠩḟ") in n3j1bdVU6vgqukC: qv5R2JduMmjoEIcKQ3kt7WgX = Ag9l6cw3EBqP8HsQuGMizfOtr4
	else:
		e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa,ffiueHIMq6oQxRpyO1ShacVGL4Pg,xJEtoVD4TkyeuKOqvcQUi,kOB9buo8XJLfV,qv5R2JduMmjoEIcKQ3kt7WgX = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx
		captcha = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡶࡡࡨࡧ࠰ࡶࡪࡪࡩࡳࡧࡦࡸ࠳࠰࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡵ࡬ࡸࡪࡱࡥࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪḠ"),XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if captcha: xJEtoVD4TkyeuKOqvcQUi,kOB9buo8XJLfV = captcha[f4fTutDOEwUeIoPLRQ]
		YnULcJZeMbrEPRGNxl7dm0SQjF = sCSyOla9hrcE[fgv5U2eRVaQqSiuGD(u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭ḡ")][fgv5U2eRVaQqSiuGD(u"࠼ॻ")]
		if f4fTutDOEwUeIoPLRQ:
			data = {usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧࡶࡵࡨࡶࠬḢ"):iidHGYjPEW4zU,YayJj10OGl(u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩḣ"):JeVILUu027qW,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡸࡶࡱ࠭Ḥ"):jUu9KomxkPAGDftYcq5a6lySB7X28,fgv5U2eRVaQqSiuGD(u"ࠪ࡯ࡪࡿࠧḥ"):kOB9buo8XJLfV,QlTuvPbSpnjygBVW(u"ࠫ࡮ࡪࠧḦ"):nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡰ࡯ࡣࠩḧ"):wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡧࡦࡶࡸࡶࡱࡹࠧḨ")}
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡑࡑࡖࡘࠬḩ"),YnULcJZeMbrEPRGNxl7dm0SQjF,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡇ࡟ࡐࡂࡕࡖࡣࡆࡑࡗࡂࡏࡢࡇࡆࡖࡔࡄࡊࡄ࠱࠷ࡴࡤࠨḪ"))
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		UTvsQb4HpCP3Aeo2wDZG7X5V = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if UTvsQb4HpCP3Aeo2wDZG7X5V.startswith(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡘࡖࡑ࡙࠽ࠨḫ")):
			oOkVKhLScA2xdJ05lCRPgN = dr1zfnatJxRHSF48jh0eODm5bGu(X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡰ࡮ࡹࡴࠨḬ"),UTvsQb4HpCP3Aeo2wDZG7X5V.split(fgv5U2eRVaQqSiuGD(u"࡚ࠫࡘࡌࡔ࠿ࠪḭ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
			for s0tfc7T2hwBM in oOkVKhLScA2xdJ05lCRPgN:
				url = s0tfc7T2hwBM[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡻࡲ࡭ࠩḮ")]
				nvEb1Jx3qZo8Vk7Dgih2 = s0tfc7T2hwBM[bnI4kmPtrW7yFEhljXOCq9(u"࠭࡭ࡦࡶ࡫ࡳࡩ࠭ḯ")]
				data = s0tfc7T2hwBM[DJ6ugPjW9bX8I(u"ࠧࡥࡣࡷࡥࠬḰ")]
				headers = s0tfc7T2hwBM[DJ6ugPjW9bX8I(u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩḱ")]
				cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,nvEb1Jx3qZo8Vk7Dgih2,url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠹ࡲࡥࠩḲ"))
				XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
				if Fo1SgXMsHk(u"ࠪ࠲ࡲࡶ࠴ࠨḳ") in XvREomOzBpM81LVstnFJheUScZ:
					qv5R2JduMmjoEIcKQ3kt7WgX = Ag9l6cw3EBqP8HsQuGMizfOtr4
					break
				zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0 = str(cnPhVmgFxA.headers)
				n3j1bdVU6vgqukC = zUq3wYIJxnTC6PiDm8H9SQcsN5Mb0+XvREomOzBpM81LVstnFJheUScZ
				e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"ࠫ࠭ࡧ࡫ࡸࡣࡰ࡚ࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯࡞ࡺ࠯࠮࠴ࠪࡀࠤࠫࡩࡾࡐ࠮ࠫࡁࠬࠦࠬḴ"),n3j1bdVU6vgqukC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				ffiueHIMq6oQxRpyO1ShacVGL4Pg = ScntgdOZCY74vNpXeW5jh8i.findall(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡶࡲ࡯ࡪࡴ࠮ࠫࡁࠥࠬ࠵࠹ࡁ࠯ࠬࡂ࠭ࠧ࠭ḵ"),n3j1bdVU6vgqukC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if ffiueHIMq6oQxRpyO1ShacVGL4Pg: ffiueHIMq6oQxRpyO1ShacVGL4Pg = ffiueHIMq6oQxRpyO1ShacVGL4Pg[f4fTutDOEwUeIoPLRQ]
				if e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa or ffiueHIMq6oQxRpyO1ShacVGL4Pg: break
		if not qv5R2JduMmjoEIcKQ3kt7WgX:
			if not e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa:
				if captcha and not ffiueHIMq6oQxRpyO1ShacVGL4Pg:
					if vkIa3ijEQVsJGdWOXwK7bnue9ADR: ffiueHIMq6oQxRpyO1ShacVGL4Pg = T8124TfgoWpSlNRKOnaIyxLU(kOB9buo8XJLfV,z3sIGH8jmLYg(u"࠭ࡡࡳࠩḶ"),jUu9KomxkPAGDftYcq5a6lySB7X28)
					else:
						if not UTvsQb4HpCP3Aeo2wDZG7X5V.startswith(fgv5U2eRVaQqSiuGD(u"ࠧࡊࡆࡀࠫḷ")):
							data = {QlTuvPbSpnjygBVW(u"ࠨࡷࡶࡩࡷ࠭Ḹ"):iidHGYjPEW4zU,SSvu1CZjTW7FcloNqD(u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪḹ"):JeVILUu027qW,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪࡹࡷࡲࠧḺ"):jUu9KomxkPAGDftYcq5a6lySB7X28,I3cxjYaHhsrM7T4UX26klN(u"ࠫࡰ࡫ࡹࠨḻ"):kOB9buo8XJLfV,fgv5U2eRVaQqSiuGD(u"ࠬ࡯ࡤࠨḼ"):nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"࠭ࡪࡰࡤࠪḽ"):DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡨࡧࡷ࡭ࡩ࠭Ḿ")}
							cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,I3cxjYaHhsrM7T4UX26klN(u"ࠨࡒࡒࡗ࡙࠭ḿ"),YnULcJZeMbrEPRGNxl7dm0SQjF,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡈ࡙ࡑࡃࡖࡗࡤࡇࡋࡘࡃࡐࡣࡈࡇࡐࡕࡅࡋࡅ࠲࠺ࡴࡩࠩṀ"))
							UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
						else: UTvsQb4HpCP3Aeo2wDZG7X5V = YayJj10OGl(u"ࠪࡍࡉࡃ࠱࠳࠵࠷࠾࠿ࡀ࠺ࡕࡋࡐࡉࡔ࡛ࡔ࠾࠶࠸ࠫṁ")
						if UTvsQb4HpCP3Aeo2wDZG7X5V.startswith(z3sIGH8jmLYg(u"ࠫࡎࡊ࠽ࠨṂ")):
							A38XgxsjyJH = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠬࡏࡄ࠾ࠪ࠱࠮ࡄ࠯࠺࠻࠼࠽ࡘࡎࡓࡅࡐࡗࡗࡁ࠭࠴ࠪࡀࠫࠧࠫṃ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
							gmTvECoxeLMAlZO90psD2JjdubN7k,rXKsDBmP18gdEl4LWbU6 = A38XgxsjyJH[f4fTutDOEwUeIoPLRQ]
							CtO9cFuULSm62PWToMlzN1 = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭็ั้ࠣห้฿ๅๅ์ฬࠤฯำสศฮࠣ์็ะࠠๆ่ࠣ࠵࠵ࠦลๅ๋ࠣࠫṄ")+rXKsDBmP18gdEl4LWbU6+z3sIGH8jmLYg(u"ࠧࠡอส๊๏ฯࠧṅ")
							kXhEFvVqefGtabMy9z0YlpBi = LMSZwD0IRAziTh()
							kXhEFvVqefGtabMy9z0YlpBi.create(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨ็ะหํ๊ษࠡฬฯหํุࠠโฯุࠤศ์วࠡล้ืฬ์้ࠠๆึฮࠥฮั็ษ่ะ้่ࠥๆสํ์ฯืࠧṆ"),CtO9cFuULSm62PWToMlzN1)
							eUYWg6EZSGsQCFt5hRTfDJzmO7xoa4 = lQMuw1PvVpAk.time()
							bTFSPBw7dg1E3OxyG642A,nLHWEdVe47rPl5CQShx36 = f4fTutDOEwUeIoPLRQ,f4fTutDOEwUeIoPLRQ
							while bTFSPBw7dg1E3OxyG642A<int(rXKsDBmP18gdEl4LWbU6):
								a46aOmKBsRw7W3MyCvurG5TqFt2fQI(kXhEFvVqefGtabMy9z0YlpBi,int(bTFSPBw7dg1E3OxyG642A/int(rXKsDBmP18gdEl4LWbU6)*t4txivgXSUWBOlCakQmNDjf(u"࠷࠰࠱ॼ")),CtO9cFuULSm62PWToMlzN1,nbOFVEDkpT4BIR7Qq82yPmHeJU,rXKsDBmP18gdEl4LWbU6+QlTuvPbSpnjygBVW(u"ࠩࠣ࠳ࠥ࠭ṇ")+str(int(bTFSPBw7dg1E3OxyG642A))+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࠤࠥัว็์ฬࠫṈ"))
								if bTFSPBw7dg1E3OxyG642A>nLHWEdVe47rPl5CQShx36+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠱࠱ॽ"):
									data = {yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡺࡹࡥࡳࠩṉ"):iidHGYjPEW4zU,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭Ṋ"):JeVILUu027qW,bYyKEjIuGQzoq3AR1(u"࠭ࡵࡳ࡮ࠪṋ"):jUu9KomxkPAGDftYcq5a6lySB7X28,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧ࡬ࡧࡼࠫṌ"):kOB9buo8XJLfV,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࡫ࡧࠫṍ"):gmTvECoxeLMAlZO90psD2JjdubN7k,Fo1SgXMsHk(u"ࠩ࡭ࡳࡧ࠭Ṏ"):fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪ࡫ࡪࡺࡴࡰ࡭ࡨࡲࠬṏ")}
									cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡕࡕࡓࡕࠩṐ"),YnULcJZeMbrEPRGNxl7dm0SQjF,data,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠷ࡷ࡬ࠬṑ"))
									UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
									if UTvsQb4HpCP3Aeo2wDZG7X5V.startswith(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡔࡐࡍࡈࡒࡂ࠭Ṓ")):
										ffiueHIMq6oQxRpyO1ShacVGL4Pg = UTvsQb4HpCP3Aeo2wDZG7X5V.split(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡕࡑࡎࡉࡓࡃࠧṓ"),Fo1SgXMsHk(u"࠲ॾ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
										break
									nLHWEdVe47rPl5CQShx36 = bTFSPBw7dg1E3OxyG642A
								else: lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
								bTFSPBw7dg1E3OxyG642A = lQMuw1PvVpAk.time()-eUYWg6EZSGsQCFt5hRTfDJzmO7xoa4
							kXhEFvVqefGtabMy9z0YlpBi.close()
				if ffiueHIMq6oQxRpyO1ShacVGL4Pg:
					h2hNFjZ3WKc0skYRq5dfulI6bD87Jg = cnPhVmgFxA.cookies
					sVirjnBEY23dFh4oHleMXvz = ScntgdOZCY74vNpXeW5jh8i.findall(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡣ࡮ࡻࡦࡳ࡟ࡴࡧࡶࡷ࡮ࡵ࡮࠾ࠪ࠱࠮ࡄ࠯࠻ࠨṔ"),n3j1bdVU6vgqukC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡤ࡯ࡼࡧ࡭ࡠࡵࡨࡷࡸ࡯࡯࡯ࠩṕ") in list(h2hNFjZ3WKc0skYRq5dfulI6bD87Jg.keys()): sVirjnBEY23dFh4oHleMXvz = h2hNFjZ3WKc0skYRq5dfulI6bD87Jg[IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡥࡰࡽࡡ࡮ࡡࡶࡩࡸࡹࡩࡰࡰࠪṖ")]
					elif sVirjnBEY23dFh4oHleMXvz: sVirjnBEY23dFh4oHleMXvz = sVirjnBEY23dFh4oHleMXvz[f4fTutDOEwUeIoPLRQ]
					captcha = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠫࡵࡧࡧࡦ࠯ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠲࠯ࡅࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡧࡥࡹࡧ࠭ࡴ࡫ࡷࡩࡰ࡫ࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩṗ"),XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if captcha: xJEtoVD4TkyeuKOqvcQUi,kOB9buo8XJLfV = captcha[f4fTutDOEwUeIoPLRQ]
					if sVirjnBEY23dFh4oHleMXvz and captcha:
						headers = {UpQ56M0dO1N9xIvVegy(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬṘ"):tM24jD1gO0(u"࠭ࡡ࡬ࡹࡤࡱࡤࡹࡥࡴࡵ࡬ࡳࡳࡃࠧṙ")+sVirjnBEY23dFh4oHleMXvz,DJ6ugPjW9bX8I(u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨṚ"):jUu9KomxkPAGDftYcq5a6lySB7X28,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧṛ"):O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨṜ")}
						data = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪ࡫࠲ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠮ࡴࡨࡷࡵࡵ࡮ࡴࡧࡀࠫṝ")+ffiueHIMq6oQxRpyO1ShacVGL4Pg
						cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡕࡕࡓࡕࠩṞ"),xJEtoVD4TkyeuKOqvcQUi,data,headers,SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡄ࡜ࡔࡆ࡙ࡓࡠࡃࡎ࡛ࡆࡓ࡟ࡄࡃࡓࡘࡈࡎࡁ࠮࠸ࡷ࡬ࠬṟ"))
						XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
						try: cookies = cnPhVmgFxA.cookies
						except: cookies = {}
						e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa = ScntgdOZCY74vNpXeW5jh8i.findall(z3sIGH8jmLYg(u"ࠨࠧࠩࡣ࡮ࡻࡦࡳࡖࡦࡴ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠳࠰࠿ࠪࠩ࠽ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧṠ"),str(cookies),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa:
				xbfwC5hkXLvsJa8PReOS9AyU1z,e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa = e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa[f4fTutDOEwUeIoPLRQ]
				aWiAjtGlKhXeH64Iy = xbfwC5hkXLvsJa8PReOS9AyU1z+l4DS8mnEjHhFMZ5YOe(u"ࠧ࠾ࠩṡ")+e4D8brlW0pY3Ui5yQd6Sfc2Iu1AGa
				llnG7jiQBYKhAeovbT.setSetting(l4DS8mnEjHhFMZ5YOe(u"ࠨࡣࡹ࠲ࡦࡱࡷࡢ࡯࠱ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩṢ"),aWiAjtGlKhXeH64Iy)
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bYyKEjIuGQzoq3AR1(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬṣ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"๊ࠪัำสࠡ฻่่๏ฯࠠโฯุࠤศ์วࠡว้ืฬ์ࠠ࠯࠰ࠣ์็อๅࠡษ็ฬึ์วๆฮࠣฬำุๆ่ࠡอหหา่ࠠาสࠤฬ๊แฮื่่ࠣ๐๋ࠠีอาิ๋็ศࠢ็หา่วࠡ࠰࠱ࠤํ๊วࠡฬ๋ะิࠦอศฮฬࠤ้หูศัฬࠤ์ึวࠡษ็ๅา฻ࠠๅ฻าอࠥษิ่ำࠣࡠࡳࡢ࡮ࠡ฻็้ฬࠦร็๊ࠢิฬࠦวๅใะูู่ࠥโࠢํฮ่ืัࠡใํࠤาอไสࠢอ฾๏ืࠠาสฺࠤฬ๊ฬ่ษีࠤออไฦ่อี๋ะࠠ࠯࠰ࠣวํࠦลุใสลࠥืว้ฬิࠤฬ๊ล็ฬิ๊ฯࠦ࠮࠯ࠢฦ์ࠥ็ีๅࠢึ่่ࠦวๅำส์ฯืࠠ࠯࠰ࠣวํࠦวิฬัำฬ๋ࠠࡗࡒࡑࠤศ๎ࠠษำ๋็ุ๐ࠧṤ"))
				if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫ࠳ࡳࡰ࠵ࠩṥ") not in XvREomOzBpM81LVstnFJheUScZ:
					headers = {QlTuvPbSpnjygBVW(u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬṦ"):aWiAjtGlKhXeH64Iy}
					cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡇࡆࡖࠪṧ"),jUu9KomxkPAGDftYcq5a6lySB7X28,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡆ࡞ࡖࡁࡔࡕࡢࡅࡐ࡝ࡁࡎࡡࡆࡅࡕ࡚ࡃࡉࡃ࠰࠻ࡹ࡮ࠧṨ"))
					XvREomOzBpM81LVstnFJheUScZ = cnPhVmgFxA.content
	if not qv5R2JduMmjoEIcKQ3kt7WgX and not aWiAjtGlKhXeH64Iy: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫṩ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩไุ้ะฺࠠ็็๎ฮࠦแฮืࠣว๋อࠠฤ่ึห๋ࠦ࠮࠯ࠢะหํ๊ࠠฦ฻สำฮࠦวๅ฻่่๏ฯࠠๆำฬࠤศิั๊ࠢหหุะฮะษ่ࠤ๋็ำࠡษ็ๅ๏ี๊้ࠢฦ์ࠥ็๊ะ์๋ࠤ฿๐ั่่๊ࠢࠥ์แิࠢส่๊๎โฺࠩṪ"))
	return XvREomOzBpM81LVstnFJheUScZ
def Hn1ehdUPB2(url,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,uTKGhcXEIpmDf):
	NWtqFg91ZSKinvIwAc,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU = [],[]
	jUu9KomxkPAGDftYcq5a6lySB7X28 = url
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,qrjy8LuKVPNYdbSvzh(u"ࠪࡋࡊ࡚ࠧṫ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡍ࡚ࡅࡒ࠳࠱ࡴࡶࠪṬ"))
	fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
	dD1CqFmH3BrpnT = []
	if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭ṭ") in fv4KNqjIBQT0UcHmlYSnrwOAWGV or cb3rmvAn4wa6lBPz2phOoYqX(u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪṮ") in fv4KNqjIBQT0UcHmlYSnrwOAWGV:
		ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall(DJ6ugPjW9bX8I(u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠮ࠫࡁ࠿࠳ࡦࡄࠧṯ"),fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if ISmqngYzv6jrepWUx0l:
			for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
				rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡲࡤࡲ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬṰ"),G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in rU02bCJFWZDfVuhtMgBOyQi5P:
					if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in NWtqFg91ZSKinvIwAc: continue
					if IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࠲ࡻࡦࡺࡣࡩ࠱ࠪṱ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧṲ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
					if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫฬ࠭ṳ") not in title:
						dD1CqFmH3BrpnT.append((title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6))
						continue
					title = title.replace(flDSRbv57PnV3(u"ࠬࡂ࠯ࡴࡲࡤࡲࡃ࠭Ṵ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(z3sIGH8jmLYg(u"࠭ࠠ࠮ࠢࠪṵ"),nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
					if IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡴࡲࡤࡲࠬṶ") in title: continue
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title)
			for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in dD1CqFmH3BrpnT:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in NWtqFg91ZSKinvIwAc:
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title)
			bCiGxXzDkH = f4fTutDOEwUeIoPLRQ
			if len(NWtqFg91ZSKinvIwAc)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr(IINBvuxkCSJrO1Q0UyngdLi(u"ࠨส฼ฺ์อ๋ࠠฯอหัࠦ࠶࠱ࠢฮห๋๐ษࠨṷ"),ifOk5xt1uHRJrTGFB7zZaeKIs6bqU)
				if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return DJ6ugPjW9bX8I(u"ࠩࡈ࡜ࡎ࡚࡟ࡂࡎࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧṸ"),[],[]
			if NWtqFg91ZSKinvIwAc and bCiGxXzDkH>=f4fTutDOEwUeIoPLRQ: jUu9KomxkPAGDftYcq5a6lySB7X28 = NWtqFg91ZSKinvIwAc[bCiGxXzDkH]
	XvREomOzBpM81LVstnFJheUScZ = U1uEz7TJBG5DjY9I8FoNrXfax2k(jUu9KomxkPAGDftYcq5a6lySB7X28)
	lPpY5fw3tOBcEye91Caun2FQZ,bbKoeBcirVfzwAqZdQUFDSX = [],[]
	if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬṹ"):
		YQX7lmSVAfr6Bzt9NUIRian = ScntgdOZCY74vNpXeW5jh8i.findall(X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡧࡺ࡮࠮࡮ࡲࡥࡩ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩṺ"),XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if YQX7lmSVAfr6Bzt9NUIRian:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(YQX7lmSVAfr6Bzt9NUIRian[f4fTutDOEwUeIoPLRQ])
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			bbKoeBcirVfzwAqZdQUFDSX.append(uTKGhcXEIpmDf)
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡽࡡࡵࡥ࡫ࠫṻ"):
		rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall(flDSRbv57PnV3(u"࠭࠼ࡴࡱࡸࡶࡨ࡫࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶ࡭ࡿ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṼ"),XvREomOzBpM81LVstnFJheUScZ,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,size in rU02bCJFWZDfVuhtMgBOyQi5P:
			if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
			if uTKGhcXEIpmDf in size:
				bbKoeBcirVfzwAqZdQUFDSX.append(size)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				break
		if not lPpY5fw3tOBcEye91Caun2FQZ:
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,size in rU02bCJFWZDfVuhtMgBOyQi5P:
				if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				bbKoeBcirVfzwAqZdQUFDSX.append(size)
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if not lPpY5fw3tOBcEye91Caun2FQZ: return bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡄࡏ࡜ࡇࡍࠨṽ"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Pl9syVGTF0(url,xbfwC5hkXLvsJa8PReOS9AyU1z):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡉࡈࡘࠬṾ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡋࡐࡃࡐ࠱࠶ࡹࡴࠨṿ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	cookies = cnPhVmgFxA.cookies
	if t4txivgXSUWBOlCakQmNDjf(u"ࠪ࡫ࡴࡲࡩ࡯࡭ࠪẀ") in list(cookies.keys()):
		aWiAjtGlKhXeH64Iy = cookies[l4DS8mnEjHhFMZ5YOe(u"ࠫ࡬ࡵ࡬ࡪࡰ࡮ࠫẁ")]
		aWiAjtGlKhXeH64Iy = SxN0jnqr3LI(eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(aWiAjtGlKhXeH64Iy))
		items = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡸ࡯ࡶࡶࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ẃ"),aWiAjtGlKhXeH64Iy,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		plSscrVjkRviPwm = items[f4fTutDOEwUeIoPLRQ].replace(X1mRwt2YJKgCLu9a67(u"࠭࡜࠰ࠩẃ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠧ࠰ࠩẄ"))
		plSscrVjkRviPwm = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(plSscrVjkRviPwm)
	else: plSscrVjkRviPwm = url
	if t4txivgXSUWBOlCakQmNDjf(u"ࠨࡥࡤࡸࡨ࡮࠮ࡪࡵࠪẅ") in plSscrVjkRviPwm:
		diZGcVFrYSI3Nej1TBKQDAaWL6k = plSscrVjkRviPwm.split(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࠨ࠶ࡋ࠭Ẇ"))[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		plSscrVjkRviPwm = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡦࡺࡣࡩ࠰࡬ࡷ࠴࠭ẇ")+diZGcVFrYSI3Nej1TBKQDAaWL6k
		return paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧẈ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[plSscrVjkRviPwm]
	else:
		website = sCSyOla9hrcE[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡇࡋࡐࡃࡐࠫẉ")][f4fTutDOEwUeIoPLRQ]
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,SSvu1CZjTW7FcloNqD(u"࠭ࡇࡆࡖࠪẊ"),website,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Ag9l6cw3EBqP8HsQuGMizfOtr4,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠵ࡲࡩ࠭ẋ"))
		tBGYpZ3PNLmuU1fl2C7WV = cnPhVmgFxA.url
		xeu9ijch5ts = plSscrVjkRviPwm.split(t4txivgXSUWBOlCakQmNDjf(u"ࠨ࠱ࠪẌ"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		x4ZjgGLBqXlwz2oTA7MD0 = tBGYpZ3PNLmuU1fl2C7WV.split(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩ࠲ࠫẍ"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
		zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm.replace(xeu9ijch5ts,x4ZjgGLBqXlwz2oTA7MD0)
		headers = { IINBvuxkCSJrO1Q0UyngdLi(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧẎ"):nbOFVEDkpT4BIR7Qq82yPmHeJU , q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧẏ"):cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭Ẑ") , z3sIGH8jmLYg(u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧẑ"):zb2QIaL7Y4h9g8lSck }
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡑࡑࡖࡘࠬẒ"), zb2QIaL7Y4h9g8lSck, nbOFVEDkpT4BIR7Qq82yPmHeJU, headers, SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠷ࡷࡪࠧẓ"))
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		items = ScntgdOZCY74vNpXeW5jh8i.findall(bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩẔ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if not items:
			items = ScntgdOZCY74vNpXeW5jh8i.findall(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫẕ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
			if not items:
				items = ScntgdOZCY74vNpXeW5jh8i.findall(fgv5U2eRVaQqSiuGD(u"ࠫࡁ࡫࡭ࡣࡧࡧ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫẖ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[f4fTutDOEwUeIoPLRQ].replace(X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡢ࠯ࠨẗ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭࠯ࠨẘ"))
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rstrip(qrjy8LuKVPNYdbSvzh(u"ࠧ࠰ࠩẙ"))
			if l4DS8mnEjHhFMZ5YOe(u"ࠨࡪࡷࡸࡵ࠭ẚ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩ࡫ࡸࡹࡶ࠺ࠨẛ") + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠫẜ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭ẝ"))
			if xbfwC5hkXLvsJa8PReOS9AyU1z==nbOFVEDkpT4BIR7Qq82yPmHeJU: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
			else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨẞ"),[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
		else: uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡃࡎࡓࡆࡓࠧẟ"),[],[]
		return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def X8XUbv2VaP6f1S(url):
	headers = { l4DS8mnEjHhFMZ5YOe(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫẠ") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡇࡐࡊࡆ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬạ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(I3cxjYaHhsrM7T4UX26klN(u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪẢ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ,errno = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if items:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,NNntz8hA93kG6WqEDb1OUoeFm2fg in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡘࡁࡑࡋࡇ࡚ࡎࡊࡅࡐࠩả"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def Q8GvDRzUA3NXig0oJyEHStduYxqLP(url):
	headers = {xxtgfCnWOFlo0jTbU3PQI4Dq(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨẤ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡗࡔࡐࡔࡇࡄ࠮࠳ࡶࡸࠬấ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺ࠡ࡞࡞ࠦ࠭࠴ࠪࡀࠫࠥࠫẦ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		url = items[f4fTutDOEwUeIoPLRQ]+Fo1SgXMsHk(u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿ࠪầ")+url
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	else: return CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡙ࠣࡖࡒࡏࡂࡆࠪẨ"),[],[]
def o6gsJ7VMy0FTQePUiGCwK5L9t4c2EH(url):
	url = url.strip(bYyKEjIuGQzoq3AR1(u"ࠩ࠲ࠫẩ"))
	if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫẪ") in url: diZGcVFrYSI3Nej1TBKQDAaWL6k = url.split(SSvu1CZjTW7FcloNqD(u"ࠫ࠴࠭ẫ"))[WtDrnpJmwQ37Z2Ae68hu4BY5M1]
	else: diZGcVFrYSI3Nej1TBKQDAaWL6k = url.split(qrjy8LuKVPNYdbSvzh(u"ࠬ࠵ࠧẬ"))[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	url = YayJj10OGl(u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡥࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡳ࠴ࡶ࡬ࡢࡻࡨࡶࡄ࡬ࡩࡥ࠿ࠪậ") + diZGcVFrYSI3Nej1TBKQDAaWL6k
	headers = { xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫẮ") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡉࡓࡕࡔࡈࡅࡒ࠳࠱ࡴࡶࠪắ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩ࡟ࡠࠬẰ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	items = ScntgdOZCY74vNpXeW5jh8i.findall(QlTuvPbSpnjygBVW(u"ࠪࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪằ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return X1mRwt2YJKgCLu9a67(u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡢ࡫࡯ࡩࡩࠦࡖࡄࡕࡗࡖࡊࡇࡍࠨẲ"),[],[]
def XsE0MzVUwhTZ62Py(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡔࡠࡁ࠮࠳ࡶࡸࠬẳ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡳࡳࡥ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠡࡴࡨࡷ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ẵ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,NNntz8hA93kG6WqEDb1OUoeFm2fg,wgS3zkYrvX5R4DQi in items:
		bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg+S3X6GcaiExOPtb+wgS3zkYrvX5R4DQi)
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡕ࡚ࡂࠩẵ"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def ZjK0JomnMz2VhQ4Ce31(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡜ࡇࡔࡄࡊ࡙ࡍࡉࡋࡏ࠮࠳ࡶࡸࠬẶ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(flDSRbv57PnV3(u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࡜ࠪ࡞ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀ࠾࠲ࡸࡩࡄࠢặ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items = set(items)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	for diZGcVFrYSI3Nej1TBKQDAaWL6k,EYMmnJAyxV,iy45XExGd9AK7VYTcZprkhfQ,NNntz8hA93kG6WqEDb1OUoeFm2fg,wgS3zkYrvX5R4DQi in items:
		url = Fo1SgXMsHk(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡧࡴࡤࡪࡹ࡭ࡩ࡫࡯࠯ࡷࡶ࠳ࡩࡲ࠿ࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠩ࡭ࡩࡃࠧẸ")+diZGcVFrYSI3Nej1TBKQDAaWL6k+bYyKEjIuGQzoq3AR1(u"ࠫࠫࡳ࡯ࡥࡧࡀࠫẹ")+EYMmnJAyxV+Fo1SgXMsHk(u"ࠬࠬࡨࡢࡵ࡫ࡁࠬẺ")+iy45XExGd9AK7VYTcZprkhfQ
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡅ࡙ࡉࡈࡗࡋࡇࡉࡔ࠳࠲࡯ࡦࠪẻ"))
		items = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"ࠧࡥ࡫ࡵࡩࡨࡺࠠ࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ẽ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			bbKoeBcirVfzwAqZdQUFDSX.append(NNntz8hA93kG6WqEDb1OUoeFm2fg+S3X6GcaiExOPtb+wgS3zkYrvX5R4DQi)
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==f4fTutDOEwUeIoPLRQ: return flDSRbv57PnV3(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠧẽ"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def RREam6IVLoCudeXDU1Aw(url):
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if vkIa3ijEQVsJGdWOXwK7bnue9ADR or l4DS8mnEjHhFMZ5YOe(u"ࠩࡎࡩࡾࡃࠧẾ") not in url:
		plSscrVjkRviPwm = url.replace(QlTuvPbSpnjygBVW(u"ࠪࡹࡵࡨ࡯࡮࠰࡯࡭ࡻ࡫ࠧế"),UpQ56M0dO1N9xIvVegy(u"ࠫࡺࡶࡰࡰ࡯࠱ࡰ࡮ࡼࡥࠨỀ"))
		plSscrVjkRviPwm = plSscrVjkRviPwm.split(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬ࠵ࠧề"))
		diZGcVFrYSI3Nej1TBKQDAaWL6k = plSscrVjkRviPwm[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
		plSscrVjkRviPwm = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭࠯ࠨỂ").join(plSscrVjkRviPwm[f4fTutDOEwUeIoPLRQ:WtDrnpJmwQ37Z2Ae68hu4BY5M1])
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = {IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡪࡦࠪể"):diZGcVFrYSI3Nej1TBKQDAaWL6k,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡱࡳࠫỄ"):l4DS8mnEjHhFMZ5YOe(u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠶ࠬễ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡱࡪࡺࡨࡰࡦࡢࡪࡷ࡫ࡥࠨỆ"):cb3rmvAn4wa6lBPz2phOoYqX(u"ࠫࡋࡸࡥࡦ࠭ࡇࡳࡼࡴ࡬ࡰࡣࡧ࠯ࠪ࠹ࡅࠦ࠵ࡈࠫệ")}
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡖࡏࡔࡖࠪỈ"),plSscrVjkRviPwm,iugaeRtZ5HFw7mJc9AdTbKlLV2,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡘࡔࡇࡕࡍ࠮࠳ࡶࡸࠬỉ"))
		if DJ6ugPjW9bX8I(u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩỊ") in list(cnPhVmgFxA.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[UpQ56M0dO1N9xIvVegy(u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪị")]
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and cnPhVmgFxA.succeeded:
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(X1mRwt2YJKgCLu9a67(u"ࠩ࡬ࡨࡂࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭Ọ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,I3cxjYaHhsrM7T4UX26klN(u"ࠪࡋࡊ࡚ࠧọ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡖࡒࡅࡓࡒ࠳࠲࡯ࡦࠪỎ"))
		if YayJj10OGl(u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧỏ") in list(cnPhVmgFxA.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cnPhVmgFxA.headers[Fo1SgXMsHk(u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨỐ")]
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	return UpQ56M0dO1N9xIvVegy(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥࠢࡘࡔࡇࡕࡍࠨố"),[],[]
def hySV345z0gvKfHxpjEPksT2(url):
	headers = { fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬỒ") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡒࡉࡊࡘࡌࡈࡊࡕ࠭࠲ࡵࡷࠫồ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣࠩỔ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	if items:
		bbKoeBcirVfzwAqZdQUFDSX.append(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡲࡶ࠴ࠨổ"))
		lPpY5fw3tOBcEye91Caun2FQZ.append(items[f4fTutDOEwUeIoPLRQ][vkIa3ijEQVsJGdWOXwK7bnue9ADR])
		bbKoeBcirVfzwAqZdQUFDSX.append(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡳ࠳ࡶ࠺ࠪỖ"))
		lPpY5fw3tOBcEye91Caun2FQZ.append(items[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ])
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
	else: return yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡎࡌࡍ࡛ࡏࡄࡆࡑࠪỗ"),[],[]
def VtJMTRCpWz(url):
	diZGcVFrYSI3Nej1TBKQDAaWL6k = url.split(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧ࠰ࠩỘ"))[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	diZGcVFrYSI3Nej1TBKQDAaWL6k = diZGcVFrYSI3Nej1TBKQDAaWL6k.split(ulAxHwvzR9eTb5n(u"ࠨࠨࠪộ"))[f4fTutDOEwUeIoPLRQ]
	diZGcVFrYSI3Nej1TBKQDAaWL6k = diZGcVFrYSI3Nej1TBKQDAaWL6k.replace(t4txivgXSUWBOlCakQmNDjf(u"ࠩࡺࡥࡹࡩࡨࡀࡸࡀࠫỚ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	plSscrVjkRviPwm = sCSyOla9hrcE[flDSRbv57PnV3(u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫớ")][f4fTutDOEwUeIoPLRQ]+X1mRwt2YJKgCLu9a67(u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧỜ")+diZGcVFrYSI3Nej1TBKQDAaWL6k
	RNhYFJCkgb4iU5M = YayJj10OGl(u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࡯ࡶࡶࡸ࠲ࡧ࡫࠯ࠨờ")+diZGcVFrYSI3Nej1TBKQDAaWL6k
	coMCRv31uZ07nOGFVmwQAN4,w4Kx6sQHfSlboc8mYM27de9D1yqI,ejwabnuGOANDg,YRzpqA4JkjoOt1KC0du = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	headers = {ulAxHwvzR9eTb5n(u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪỞ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
	if f4fTutDOEwUeIoPLRQ:
		for HT4fGXqv8hEcKsJ in range(DJ6ugPjW9bX8I(u"࠷ॿ")):
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,DJ6ugPjW9bX8I(u"ࠧࡈࡇࡗࠫở"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠷ࡳࡵࠩỠ"))
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			if l4DS8mnEjHhFMZ5YOe(u"ࠩ࡬ࡸࡦ࡭ࠧỡ") in UTvsQb4HpCP3Aeo2wDZG7X5V: break
			lQMuw1PvVpAk.sleep(QQSugEIn2mTCpRsfcaJHhPdAWzylM)
		yWdTJKAabtf84L1B2OsHN0oDur = ScntgdOZCY74vNpXeW5jh8i.findall(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡓࡰࡦࡿࡥࡳࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡁࠥ࠮࠮ࠫࡁࠬ࠿ࡁ࠵ࡳࡤࡴ࡬ࡴࡹࡄࠧỢ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if yWdTJKAabtf84L1B2OsHN0oDur: yWdTJKAabtf84L1B2OsHN0oDur = yWdTJKAabtf84L1B2OsHN0oDur[f4fTutDOEwUeIoPLRQ]
		else: yWdTJKAabtf84L1B2OsHN0oDur = UTvsQb4HpCP3Aeo2wDZG7X5V
	else:
		UTvsQb4HpCP3Aeo2wDZG7X5V = nbOFVEDkpT4BIR7Qq82yPmHeJU
		headers[SSvu1CZjTW7FcloNqD(u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪợ")] = YayJj10OGl(u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨỤ")
		zb2QIaL7Y4h9g8lSck = sCSyOla9hrcE[tM24jD1gO0(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧụ")][f4fTutDOEwUeIoPLRQ]+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡰ࡭ࡣࡼࡩࡷ࠭Ủ")
		zBk0VHdLqXOQ = ulAxHwvzR9eTb5n(u"ࠨࡽࠥࡺ࡮ࡪࡥࡰࡋࡧࠦ࠿ࠦࠢࠨủ")+diZGcVFrYSI3Nej1TBKQDAaWL6k+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࠥ࠰ࠥࠨࡣࡰࡰࡷࡩࡽࡺࠢ࠻ࠢࡾࠦࡨࡲࡩࡦࡰࡷࠦ࠿ࠦࡻࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ࠼ࠣࠦ࠷࠴࠲࠱࠴࠵࠴࠾࠷࠸ࠣ࠮ࠣࠦࡨࡲࡩࡦࡰࡷࡒࡦࡳࡥࠣ࠼ࠣࠦࡒ࡝ࡅࡃࠤࢀࢁࢂ࠭Ứ")
		cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡔࡔ࡙ࡔࠨứ"),zb2QIaL7Y4h9g8lSck,zBk0VHdLqXOQ,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡚࠭ࡑࡘࡘ࡚ࡈࡅ࠮࠴ࡱࡨࠬỪ"))
		yWdTJKAabtf84L1B2OsHN0oDur = cnPhVmgFxA.content
	yWdTJKAabtf84L1B2OsHN0oDur = yWdTJKAabtf84L1B2OsHN0oDur.replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡢ࡜ࡶ࠲࠳࠶࠻࠭ừ"),qrjy8LuKVPNYdbSvzh(u"࠭ࠦࠨỬ"))
	bP2ptXl7DGnqQvOfUH = dr1zfnatJxRHSF48jh0eODm5bGu(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡥ࡫ࡦࡸࠬử"),yWdTJKAabtf84L1B2OsHN0oDur)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [IINBvuxkCSJrO1Q0UyngdLi(u"ࠨสา์๋ࠦสาฮ่อࠥ๐่ห์๋ฬࠬỮ")],[nbOFVEDkpT4BIR7Qq82yPmHeJU]
	try:
		uGNKhxReT267qiBC93YJ = bP2ptXl7DGnqQvOfUH[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡦࡥࡵࡺࡩࡰࡰࡶࠫữ")][YayJj10OGl(u"ࠪࡴࡱࡧࡹࡦࡴࡆࡥࡵࡺࡩࡰࡰࡶࡘࡷࡧࡣ࡬࡮࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧỰ")][DJ6ugPjW9bX8I(u"ࠫࡨࡧࡰࡵ࡫ࡲࡲ࡙ࡸࡡࡤ࡭ࡶࠫự")]
		for tOXU49jmqIfdB3 in uGNKhxReT267qiBC93YJ:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = tOXU49jmqIfdB3[ulAxHwvzR9eTb5n(u"ࠬࡨࡡࡴࡧࡘࡶࡱ࠭Ỳ")]
			try: title = tOXU49jmqIfdB3[YayJj10OGl(u"࠭࡮ࡢ࡯ࡨࠫỳ")][l4DS8mnEjHhFMZ5YOe(u"ࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫỴ")]
			except: title = tOXU49jmqIfdB3[flDSRbv57PnV3(u"ࠨࡰࡤࡱࡪ࠭ỵ")][QlTuvPbSpnjygBVW(u"ࠩࡵࡹࡳࡹࠧỶ")][f4fTutDOEwUeIoPLRQ][YayJj10OGl(u"ࠪࡸࡪࡾࡴࡵࠩỷ")]
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
	except: pass
	if len(bbKoeBcirVfzwAqZdQUFDSX)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr(X1mRwt2YJKgCLu9a67(u"ࠫฬิสาࠢส่ฯืฬๆหࠣࠬࠬỸ")+str(len(bbKoeBcirVfzwAqZdQUFDSX))+SSvu1CZjTW7FcloNqD(u"ࠬࠦๅๅใࠬࠫỹ"), bbKoeBcirVfzwAqZdQUFDSX)
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return qrjy8LuKVPNYdbSvzh(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫỺ"),[],[]
		elif bCiGxXzDkH!=f4fTutDOEwUeIoPLRQ:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]+z3sIGH8jmLYg(u"ࠧࠧࠩỻ")
			rGvO9dNWVnAg48SjPUcuRI0pDX1 = ScntgdOZCY74vNpXeW5jh8i.findall(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࠨࠫࡪࡲࡺ࠽࠯ࠬࡂ࠭ࠫ࠭Ỽ"),grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			if rGvO9dNWVnAg48SjPUcuRI0pDX1: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(rGvO9dNWVnAg48SjPUcuRI0pDX1[f4fTutDOEwUeIoPLRQ],flDSRbv57PnV3(u"ࠩࡩࡱࡹࡃࡶࡵࡶࠪỽ"))
			else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+bYyKEjIuGQzoq3AR1(u"ࠪࡪࡲࡺ࠽ࡷࡶࡷࠫỾ")
			coMCRv31uZ07nOGFVmwQAN4 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip(ulAxHwvzR9eTb5n(u"ࠫࠫ࠭ỿ"))
	vSlFYOychfpiWxzwtI76bN0XMR,Wr5kib4gEvpQI0TM,Y2DRjXQ9Tv75cOKHlok,D1JuqIHoXUjx,Hi2WrtP1f4DlGk5gR = [],[],[],[],[]
	try: w4Kx6sQHfSlboc8mYM27de9D1yqI = bP2ptXl7DGnqQvOfUH[QlTuvPbSpnjygBVW(u"ࠬࡹࡴࡳࡧࡤࡱ࡮ࡴࡧࡅࡣࡷࡥࠬἀ")][z3sIGH8jmLYg(u"࠭ࡤࡢࡵ࡫ࡑࡦࡴࡩࡧࡧࡶࡸ࡚ࡸ࡬ࠨἁ")]
	except: pass
	try: ejwabnuGOANDg = bP2ptXl7DGnqQvOfUH[bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯ࡩࡇࡥࡹࡧࠧἂ")][Fo1SgXMsHk(u"ࠨࡪ࡯ࡷࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠩἃ")]
	except: pass
	try: vSlFYOychfpiWxzwtI76bN0XMR = bP2ptXl7DGnqQvOfUH[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡶࡸࡷ࡫ࡡ࡮࡫ࡱ࡫ࡉࡧࡴࡢࠩἄ")][CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫἅ")]
	except: pass
	try: Wr5kib4gEvpQI0TM = bP2ptXl7DGnqQvOfUH[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࡭ࡄࡢࡶࡤࠫἆ")][I3cxjYaHhsrM7T4UX26klN(u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫ࡆࡰࡴࡰࡥࡹࡹࠧἇ")]
	except: pass
	JwKD1X4hRIA = vSlFYOychfpiWxzwtI76bN0XMR+Wr5kib4gEvpQI0TM
	for dict in JwKD1X4hRIA:
		if IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡩࡵࡣࡪࠫἈ") in list(dict.keys()): dict[tM24jD1gO0(u"ࠧࡪࡶࡤ࡫ࠬἉ")] = str(dict[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨ࡫ࡷࡥ࡬࠭Ἂ")])
		if QlTuvPbSpnjygBVW(u"ࠩࡩࡴࡸ࠭Ἃ") in list(dict.keys()): dict[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡪࡵࡹࠧἌ")] = str(dict[z3sIGH8jmLYg(u"ࠫ࡫ࡶࡳࠨἍ")])
		if YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡳࡩ࡮ࡧࡗࡽࡵ࡫ࠧἎ") in list(dict.keys()): dict[X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡴࡺࡲࡨࠫἏ")] = dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩἐ")]
		if bYyKEjIuGQzoq3AR1(u"ࠨࡣࡸࡨ࡮ࡵࡓࡢ࡯ࡳࡰࡪࡘࡡࡵࡧࠪἑ") in list(dict.keys()): dict[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭ἒ")] = str(dict[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡥࡺࡪࡩࡰࡕࡤࡱࡵࡲࡥࡓࡣࡷࡩࠬἓ")])
		if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡦࡻࡤࡪࡱࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫἔ") in list(dict.keys()): dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡧࡵࡥ࡫ࡲࡣࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ἕ")] = str(dict[z3sIGH8jmLYg(u"࠭ࡡࡶࡦ࡬ࡳࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭἖")])
		if z3sIGH8jmLYg(u"ࠧࡸ࡫ࡧࡸ࡭࠭἗") in list(dict.keys()): dict[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡵ࡬ࡾࡪ࠭Ἐ")] = str(dict[QlTuvPbSpnjygBVW(u"ࠩࡺ࡭ࡩࡺࡨࠨἙ")])+X1mRwt2YJKgCLu9a67(u"ࠪࡼࠬἚ")+str(dict[tM24jD1gO0(u"ࠫ࡭࡫ࡩࡨࡪࡷࠫἛ")])
		if qrjy8LuKVPNYdbSvzh(u"ࠬ࡯࡮ࡪࡶࡕࡥࡳ࡭ࡥࠨἜ") in list(dict.keys()): dict[DJ6ugPjW9bX8I(u"࠭ࡩ࡯࡫ࡷࠫἝ")] = dict[YayJj10OGl(u"ࠧࡪࡰ࡬ࡸࡗࡧ࡮ࡨࡧࠪ἞")][paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡵࡷࡥࡷࡺࠧ἟")]+X60YQOADpkHBb31LiR5qUEKfM(u"ࠩ࠰ࠫἠ")+dict[I3cxjYaHhsrM7T4UX26klN(u"ࠪ࡭ࡳ࡯ࡴࡓࡣࡱ࡫ࡪ࠭ἡ")][z3sIGH8jmLYg(u"ࠫࡪࡴࡤࠨἢ")]
		if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬ࡯࡮ࡥࡧࡻࡖࡦࡴࡧࡦࠩἣ") in list(dict.keys()): dict[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡩ࡯ࡦࡨࡼࠬἤ")] = dict[fgv5U2eRVaQqSiuGD(u"ࠧࡪࡰࡧࡩࡽࡘࡡ࡯ࡩࡨࠫἥ")][YayJj10OGl(u"ࠨࡵࡷࡥࡷࡺࠧἦ")]+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩ࠰ࠫἧ")+dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠪ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࠧἨ")][YayJj10OGl(u"ࠫࡪࡴࡤࠨἩ")]
		if bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡧࡶࡦࡴࡤ࡫ࡪࡈࡩࡵࡴࡤࡸࡪ࠭Ἢ") in list(dict.keys()): dict[Fo1SgXMsHk(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧἫ")] = dict[fgv5U2eRVaQqSiuGD(u"ࠧࡢࡸࡨࡶࡦ࡭ࡥࡃ࡫ࡷࡶࡦࡺࡥࠨἬ")]
		if cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩἭ") in list(dict.keys()) and int(dict[z3sIGH8jmLYg(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪἮ")])>wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠴࠵࠶࠸࠲࠳࠵࠶࠷ঀ"): del dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫἯ")]
		if t4txivgXSUWBOlCakQmNDjf(u"ࠫࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࡃࡪࡲ࡫ࡩࡷ࠭ἰ") in list(dict.keys()):
			l1xzoYDPwrWj6GypSN = dict[flDSRbv57PnV3(u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧἱ")].split(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࠦࠨἲ"))
			for xB2lOZNsPvFQDC4gMz in l1xzoYDPwrWj6GypSN:
				key,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split(flDSRbv57PnV3(u"ࠧ࠾ࠩἳ"),QlTuvPbSpnjygBVW(u"࠵ঁ"))
				dict[key] = SxN0jnqr3LI(XPL0O2VkI3w1C8enMaqi)
		if bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡷࡵࡰࠬἴ") in list(dict.keys()): dict[paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡸࡶࡱ࠭ἵ")] = SxN0jnqr3LI(dict[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡹࡷࡲࠧἶ")])
		Y2DRjXQ9Tv75cOKHlok.append(dict)
	HJV56UEGvXkOLi = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡸࡶ࠽ࡴ࡫ࡪࠫἷ") in yWdTJKAabtf84L1B2OsHN0oDur:
		if not UTvsQb4HpCP3Aeo2wDZG7X5V:
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,qrjy8LuKVPNYdbSvzh(u"ࠬࡍࡅࡕࠩἸ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡜ࡓ࡚࡚ࡕࡃࡇ࠰࠷ࡷࡪࠧἹ"))
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		SHGyEqBUd9v = ScntgdOZCY74vNpXeW5jh8i.findall(IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡴࡴࡦࡁࠧ࠮࠯ࡴ࠱ࡳࡰࡦࡿࡥࡳ࠱࡟ࡻ࠯ࡅ࠯ࡱ࡮ࡤࡽࡪࡸ࡟ࡪࡣࡶ࠲ࡻ࡬࡬ࡴࡧࡷ࠳ࡪࡴ࡟࠯࠰࠲ࡦࡦࡹࡥ࠯࡬ࡶ࠭ࠧ࠭Ἲ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if SHGyEqBUd9v:
			SHGyEqBUd9v = sCSyOla9hrcE[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩἻ")][f4fTutDOEwUeIoPLRQ]+SHGyEqBUd9v[f4fTutDOEwUeIoPLRQ]
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡊࡉ࡙࠭Ἴ"),SHGyEqBUd9v,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳࡙ࡐࡗࡗ࡙ࡇࡋ࠭࠵ࡶ࡫ࠫἽ"))
			HJV56UEGvXkOLi = cnPhVmgFxA.content
			import youtube_signature.cipher as DXFbJCp5H7ljVc61uRsakNgdBeAmIY,youtube_signature.json_script_engine as rERluCFzk0O4QhZYxbBAMXUWVv5mjn
			l1xzoYDPwrWj6GypSN = tf9KV52MpNE8iR0r.l1xzoYDPwrWj6GypSN.Cipher()
			l1xzoYDPwrWj6GypSN._object_cache = {}
			Haj0tcYEplW = l1xzoYDPwrWj6GypSN._load_javascript(HJV56UEGvXkOLi)
			nb4f58qaKBsHWi3YuvPOEVceIGTJw = dr1zfnatJxRHSF48jh0eODm5bGu(fgv5U2eRVaQqSiuGD(u"ࠫࡸࡺࡲࠨἾ"),str(Haj0tcYEplW))
			EIkby8RG9oz1vBgeV5WsMQZN = tf9KV52MpNE8iR0r.RRnqt5y1lbvshQoCIUiXYdmA.JsonScriptEngine(nb4f58qaKBsHWi3YuvPOEVceIGTJw)
	for dict in Y2DRjXQ9Tv75cOKHlok:
		url = dict[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡻࡲ࡭ࠩἿ")]
		if ulAxHwvzR9eTb5n(u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦ࠿ࠪὀ") in url or url.count(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡴ࡫ࡪࡁࠬὁ"))>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
			D1JuqIHoXUjx.append(dict)
		elif HJV56UEGvXkOLi and tM24jD1gO0(u"ࠨࡵࠪὂ") in list(dict.keys()) and YayJj10OGl(u"ࠩࡶࡴࠬὃ") in list(dict.keys()):
			mK1ZrjkRv4ay75epWOtAb = EIkby8RG9oz1vBgeV5WsMQZN.execute(dict[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡷࠬὄ")])
			if mK1ZrjkRv4ay75epWOtAb!=dict[SSvu1CZjTW7FcloNqD(u"ࠫࡸ࠭ὅ")]:
				dict[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡻࡲ࡭ࠩ὆")] = url+I3cxjYaHhsrM7T4UX26klN(u"࠭ࠦࠨ὇")+dict[z3sIGH8jmLYg(u"ࠧࡴࡲࠪὈ")]+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨ࠿ࠪὉ")+mK1ZrjkRv4ay75epWOtAb
				D1JuqIHoXUjx.append(dict)
	for dict in D1JuqIHoXUjx:
		D63UZqx2XBgrtbje,oo1TBHMr5XV2sbEuaiRw7ZD4P,i5H9MQgPEX1Kz4k,nFE7RXAdxPUaktfcCDwZGsQhMzybmY,piSNgoCl30QnADL4q62juFROaWUh,twyo6bl7DKGL = bYyKEjIuGQzoq3AR1(u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪὊ"),bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫὋ"),I3cxjYaHhsrM7T4UX26klN(u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬὌ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭Ὅ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭࠰ࠨ὎")
		try:
			vBwlihVfEa84TW3NmjLdAJxcn29ps = dict[DJ6ugPjW9bX8I(u"ࠧࡵࡻࡳࡩࠬ὏")]
			vBwlihVfEa84TW3NmjLdAJxcn29ps = vBwlihVfEa84TW3NmjLdAJxcn29ps.replace(qrjy8LuKVPNYdbSvzh(u"ࠨ࠭ࠪὐ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			items = ScntgdOZCY74vNpXeW5jh8i.findall(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࠫ࠲࠯ࡅࠩ࠰ࠪ࠱࠮ࡄ࠯࠻࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫὑ"),vBwlihVfEa84TW3NmjLdAJxcn29ps,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			nFE7RXAdxPUaktfcCDwZGsQhMzybmY,D63UZqx2XBgrtbje,piSNgoCl30QnADL4q62juFROaWUh = items[f4fTutDOEwUeIoPLRQ]
			PMKXyZsVSjbEpnmr1 = piSNgoCl30QnADL4q62juFROaWUh.split(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪ࠰ࠬὒ"))
			oo1TBHMr5XV2sbEuaiRw7ZD4P = nbOFVEDkpT4BIR7Qq82yPmHeJU
			for xB2lOZNsPvFQDC4gMz in PMKXyZsVSjbEpnmr1: oo1TBHMr5XV2sbEuaiRw7ZD4P += xB2lOZNsPvFQDC4gMz.split(DJ6ugPjW9bX8I(u"ࠫ࠳࠭ὓ"))[f4fTutDOEwUeIoPLRQ]+l4DS8mnEjHhFMZ5YOe(u"ࠬ࠲ࠧὔ")
			oo1TBHMr5XV2sbEuaiRw7ZD4P = oo1TBHMr5XV2sbEuaiRw7ZD4P.strip(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࠬࠨὕ"))
			if t4txivgXSUWBOlCakQmNDjf(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨὖ") in list(dict.keys()): twyo6bl7DKGL = str(float(dict[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩὗ")]*t4txivgXSUWBOlCakQmNDjf(u"࠶࠶ং"))//t4txivgXSUWBOlCakQmNDjf(u"࠷࠰࠳࠶ঃ")/t4txivgXSUWBOlCakQmNDjf(u"࠶࠶ং"))+IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ὘")
			else: twyo6bl7DKGL = nbOFVEDkpT4BIR7Qq82yPmHeJU
			if nFE7RXAdxPUaktfcCDwZGsQhMzybmY==YayJj10OGl(u"ࠪࡸࡪࡾࡴࡵࠩὙ"): continue
			elif fgv5U2eRVaQqSiuGD(u"ࠫ࠱࠭὚") in vBwlihVfEa84TW3NmjLdAJxcn29ps:
				nFE7RXAdxPUaktfcCDwZGsQhMzybmY = YayJj10OGl(u"ࠬࡇࠫࡗࠩὛ")
				i5H9MQgPEX1Kz4k = D63UZqx2XBgrtbje+BhmzEC6OGD7FXZig9Tp5A+twyo6bl7DKGL+dict[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡳࡪࡼࡨࠫ὜")].split(Fo1SgXMsHk(u"ࠧࡹࠩὝ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			elif nFE7RXAdxPUaktfcCDwZGsQhMzybmY==t4txivgXSUWBOlCakQmNDjf(u"ࠨࡸ࡬ࡨࡪࡵࠧ὞"):
				nFE7RXAdxPUaktfcCDwZGsQhMzybmY = z3sIGH8jmLYg(u"࡙ࠩ࡭ࡩ࡫࡯ࠨὟ")
				i5H9MQgPEX1Kz4k = twyo6bl7DKGL+dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡷ࡮ࢀࡥࠨὠ")].split(bYyKEjIuGQzoq3AR1(u"ࠫࡽ࠭ὡ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]+BhmzEC6OGD7FXZig9Tp5A+dict[qrjy8LuKVPNYdbSvzh(u"ࠬ࡬ࡰࡴࠩὢ")]+flDSRbv57PnV3(u"࠭ࡦࡱࡵࠪὣ")+BhmzEC6OGD7FXZig9Tp5A+D63UZqx2XBgrtbje
			elif nFE7RXAdxPUaktfcCDwZGsQhMzybmY==flDSRbv57PnV3(u"ࠧࡢࡷࡧ࡭ࡴ࠭ὤ"):
				nFE7RXAdxPUaktfcCDwZGsQhMzybmY = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡃࡸࡨ࡮ࡵࠧὥ")
				i5H9MQgPEX1Kz4k = twyo6bl7DKGL+str(int(dict[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡤࡹࡩ࡯࡯ࡠࡵࡤࡱࡵࡲࡥࡠࡴࡤࡸࡪ࠭ὦ")])/IINBvuxkCSJrO1Q0UyngdLi(u"࠱࠱࠲࠳঄"))+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪ࡯࡭ࢀࠠࠡࠩὧ")+dict[tM24jD1gO0(u"ࠫࡦࡻࡤࡪࡱࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬὨ")]+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠬࡩࡨࠨὩ")+BhmzEC6OGD7FXZig9Tp5A+D63UZqx2XBgrtbje
		except:
			vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
			if vf9s4ClmTE08AGndQV!=qrjy8LuKVPNYdbSvzh(u"࠭ࡎࡰࡰࡨࡘࡾࡶࡥ࠻ࠢࡑࡳࡳ࡫࡜࡯ࠩὪ"): Jg3GROZ80HzMpAfL2DQ4mdYhuW.stderr.write(vf9s4ClmTE08AGndQV)
		if IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡥࡷࡵࡁࠬὫ") in dict[I3cxjYaHhsrM7T4UX26klN(u"ࠨࡷࡵࡰࠬὬ")]: H07WdckxAoZF1fn4LNMOTP65eEtr = round(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠲࠱࠹আ")+float(dict[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡸࡶࡱ࠭Ὥ")].split(bnI4kmPtrW7yFEhljXOCq9(u"ࠪࡨࡺࡸ࠽ࠨὮ"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠲অ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR].split(tM24jD1gO0(u"ࠫࠫ࠭Ὧ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[f4fTutDOEwUeIoPLRQ]))
		elif QlTuvPbSpnjygBVW(u"ࠬࡧࡰࡱࡴࡲࡼࡉࡻࡲࡢࡶ࡬ࡳࡳࡓࡳࠨὰ") in list(dict.keys()): H07WdckxAoZF1fn4LNMOTP65eEtr = round(YayJj10OGl(u"࠳࠲࠺ই")+float(dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡡࡱࡲࡵࡳࡽࡊࡵࡳࡣࡷ࡭ࡴࡴࡍࡴࠩά")])/QlTuvPbSpnjygBVW(u"࠵࠵࠶࠰ঈ"))
		else: H07WdckxAoZF1fn4LNMOTP65eEtr = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧ࠱ࠩὲ")
		if bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩέ") not in list(dict.keys()): twyo6bl7DKGL = dict[qrjy8LuKVPNYdbSvzh(u"ࠩࡶ࡭ࡿ࡫ࠧὴ")].split(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡼࠬή"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		else: twyo6bl7DKGL = dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬὶ")]
		if DJ6ugPjW9bX8I(u"ࠬ࡯࡮ࡪࡶࠪί") not in list(dict.keys()): dict[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡩ࡯࡫ࡷࠫὸ")] = ulAxHwvzR9eTb5n(u"ࠧ࠱࠯࠳ࠫό")
		dict[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡶ࡬ࡸࡱ࡫ࠧὺ")] = nFE7RXAdxPUaktfcCDwZGsQhMzybmY+ulAxHwvzR9eTb5n(u"ࠩ࠽ࠤࠥ࠭ύ")+i5H9MQgPEX1Kz4k+qrjy8LuKVPNYdbSvzh(u"ࠪࠤࠥ࠮ࠧὼ")+oo1TBHMr5XV2sbEuaiRw7ZD4P+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫ࠱࠭ώ")+dict[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬ࡯ࡴࡢࡩࠪ὾")]+bnI4kmPtrW7yFEhljXOCq9(u"࠭ࠩࠨ὿")
		dict[ulAxHwvzR9eTb5n(u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨᾀ")] = i5H9MQgPEX1Kz4k.split(BhmzEC6OGD7FXZig9Tp5A)[f4fTutDOEwUeIoPLRQ].split(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࡭ࡥࡴࡸ࠭ᾁ"))[f4fTutDOEwUeIoPLRQ]
		dict[flDSRbv57PnV3(u"ࠩࡷࡽࡵ࡫࠲ࠨᾂ")] = nFE7RXAdxPUaktfcCDwZGsQhMzybmY
		dict[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬᾃ")] = D63UZqx2XBgrtbje
		dict[bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡨࡵࡤࡦࡥࡶࠫᾄ")] = piSNgoCl30QnADL4q62juFROaWUh
		dict[DJ6ugPjW9bX8I(u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧᾅ")] = H07WdckxAoZF1fn4LNMOTP65eEtr
		dict[flDSRbv57PnV3(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧᾆ")] = twyo6bl7DKGL
		Hi2WrtP1f4DlGk5gR.append(dict)
	NihE6AX0xgq1aUoKcwk9PFId,dBColkMzqPciO,reNHJO2YV6DqcbpMu5XQnF,GHJglMPq8dicaB67DbXURvowe3T,NR8JCd3ogDfZjG17zHiFyI2450rPt = [],[],[],[],[]
	ahwJu69WiN,I72X4GAJm3QSaWqBrFU5j,ej8EUVpXQlCYra7tNz094IF6xfPbk,qq5efZJx26AEv8ph,bqEZg1G0uzIocX6r = [],[],[],[],[]
	if w4Kx6sQHfSlboc8mYM27de9D1yqI:
		dict = {}
		dict[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡵࡻࡳࡩ࠷࠭ᾇ")] = bnI4kmPtrW7yFEhljXOCq9(u"ࠨࡃ࠮࡚ࠬᾈ")
		dict[UpQ56M0dO1N9xIvVegy(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫᾉ")] = DJ6ugPjW9bX8I(u"ࠪࡱࡵࡪࠧᾊ")
		dict[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡹ࡯ࡴ࡭ࡧࠪᾋ")] = dict[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡺࡹࡱࡧ࠵ࠫᾌ")]+flDSRbv57PnV3(u"࠭࠺ࠡࠢࠪᾍ")+dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩᾎ")]+BhmzEC6OGD7FXZig9Tp5A+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨฮ๋ำฮࠦะไ์ฬࠫᾏ")
		dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡸࡶࡱ࠭ᾐ")] = w4Kx6sQHfSlboc8mYM27de9D1yqI
		dict[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫᾑ")] = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫ࠵࠭ᾒ")
		dict[ulAxHwvzR9eTb5n(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ᾓ")] = I3cxjYaHhsrM7T4UX26klN(u"࠭࠹࠹࠹࠹࠹࠹࠹࠲࠲࠲ࠪᾔ")
		Hi2WrtP1f4DlGk5gR.append(dict)
	if ejwabnuGOANDg:
		v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b = mmAWFnZUkQ3HowdxRtCN9(ejwabnuGOANDg)
		GGoDmbtFq47ra6zMEj = list(zip(v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b))
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in GGoDmbtFq47ra6zMEj:
			dict = {}
			dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡵࡻࡳࡩ࠷࠭ᾕ")] = Fo1SgXMsHk(u"ࠨࡃ࠮࡚ࠬᾖ")
			dict[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫᾗ")] = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡱ࠸ࡻ࠸ࠨᾘ")
			dict[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡺࡸ࡬ࠨᾙ")] = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࡱࡢࡱࡵࠪᾚ") in title: dict[Fo1SgXMsHk(u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧᾛ")] = title.split(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧ࡬ࡤࡳࡷࠬᾜ"))[f4fTutDOEwUeIoPLRQ].rsplit(BhmzEC6OGD7FXZig9Tp5A)[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			else: dict[z3sIGH8jmLYg(u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩᾝ")] = SSvu1CZjTW7FcloNqD(u"ࠩ࠴࠴ࠬᾞ")
			if title.count(BhmzEC6OGD7FXZig9Tp5A)>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				uTKGhcXEIpmDf = title.rsplit(BhmzEC6OGD7FXZig9Tp5A)[-ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]
				if uTKGhcXEIpmDf.isdigit(): dict[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫᾟ")] = uTKGhcXEIpmDf
				else: dict[UpQ56M0dO1N9xIvVegy(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬᾠ")] = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬ࠶࠰࠱࠲ࠪᾡ")
			if title==ulAxHwvzR9eTb5n(u"࠭࠭࠲ࠩᾢ"): dict[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡵ࡫ࡷࡰࡪ࠭ᾣ")] = dict[bYyKEjIuGQzoq3AR1(u"ࠨࡶࡼࡴࡪ࠸ࠧᾤ")]+X60YQOADpkHBb31LiR5qUEKfM(u"ࠩ࠽ࠤࠥ࠭ᾥ")+dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬᾦ")]+BhmzEC6OGD7FXZig9Tp5A+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫั๎ฯสࠢำ็๏ฯࠧᾧ")
			else: dict[bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡺࡩࡵ࡮ࡨࠫᾨ")] = dict[q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡴࡺࡲࡨ࠶ࠬᾩ")]+flDSRbv57PnV3(u"ࠧ࠻ࠢࠣࠫᾪ")+dict[l4DS8mnEjHhFMZ5YOe(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪᾫ")]+BhmzEC6OGD7FXZig9Tp5A+dict[qrjy8LuKVPNYdbSvzh(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪᾬ")]+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪ࡯ࡧࡶࡳࠡࠢࠪᾭ")+dict[X1mRwt2YJKgCLu9a67(u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬᾮ")]
			Hi2WrtP1f4DlGk5gR.append(dict)
	Hi2WrtP1f4DlGk5gR = sorted(Hi2WrtP1f4DlGk5gR,reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4,key=lambda key: float(key[ulAxHwvzR9eTb5n(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ᾯ")]))
	if not Hi2WrtP1f4DlGk5gR:
		if not UTvsQb4HpCP3Aeo2wDZG7X5V:
			cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,l4DS8mnEjHhFMZ5YOe(u"࠭ࡇࡆࡖࠪᾰ"),plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡝ࡔ࡛ࡔࡖࡄࡈ࠱࠺ࡺࡨࠨᾱ"))
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		G8CImB4K9pN3OhHT = ScntgdOZCY74vNpXeW5jh8i.findall(QlTuvPbSpnjygBVW(u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡷࡸࡧࡧࡦࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᾲ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡳࡶࡤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࡠࢀࠨࡲࡶࡰࡶࠦ࠿ࡢ࡛࡝ࡽࠥࡸࡪࡾࡴࡵࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᾳ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Rv3xcXSYnZIK7bFNiUHweEQL0z1j = ScntgdOZCY74vNpXeW5jh8i.findall(ulAxHwvzR9eTb5n(u"ࠪࠦࡵࡲࡡࡺࡧࡵࡉࡷࡸ࡯ࡳࡏࡨࡷࡸࡧࡧࡦࡔࡨࡲࡩ࡫ࡲࡦࡴࠥ࠾ࡡࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࡽࠥࡷ࡮ࡳࡰ࡭ࡧࡗࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩᾴ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		amIcByjdlx5ktPVoh2WvQOXsLzi = ScntgdOZCY74vNpXeW5jh8i.findall(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࠧࡶ࡬ࡢࡻࡨࡶࡊࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡵࡸࡦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࢁࠢࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭᾵"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		try: LySqdUiNpk8cxrA = bP2ptXl7DGnqQvOfUH[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡶ࡬ࡢࡻࡤࡦ࡮ࡲࡩࡵࡻࡖࡸࡦࡺࡵࡴࠩᾶ")][IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡥࡳࡴࡲࡶࡘࡩࡲࡦࡧࡱࠫᾷ")][YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭ࡅ࡫ࡤࡰࡴ࡭ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨᾸ")][UpQ56M0dO1N9xIvVegy(u"ࠨࡶ࡬ࡸࡱ࡫ࠧᾹ")][flDSRbv57PnV3(u"ࠩࡵࡹࡳࡹࠧᾺ")][f4fTutDOEwUeIoPLRQ][fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡸࡪࡾࡴࡵࠩΆ")]
		except: LySqdUiNpk8cxrA = nbOFVEDkpT4BIR7Qq82yPmHeJU
		try: toZ4n765X8zFp9BO3Ky2keG1N = bP2ptXl7DGnqQvOfUH[qrjy8LuKVPNYdbSvzh(u"ࠫࡵࡲࡡࡺࡣࡥ࡭ࡱ࡯ࡴࡺࡕࡷࡥࡹࡻࡳࠨᾼ")][flDSRbv57PnV3(u"ࠬ࡫ࡲࡳࡱࡵࡗࡨࡸࡥࡦࡰࠪ᾽")][fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡣࡰࡰࡩ࡭ࡷࡳࡄࡪࡣ࡯ࡳ࡬ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧι")][QlTuvPbSpnjygBVW(u"ࠧࡥ࡫ࡤࡰࡴ࡭ࡍࡦࡵࡶࡥ࡬࡫ࡳࠨ᾿")][f4fTutDOEwUeIoPLRQ][t4txivgXSUWBOlCakQmNDjf(u"ࠨࡴࡸࡲࡸ࠭῀")][f4fTutDOEwUeIoPLRQ][bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡷࡩࡽࡺࡴࠨ῁")]
		except: toZ4n765X8zFp9BO3Ky2keG1N = nbOFVEDkpT4BIR7Qq82yPmHeJU
		try: RwxE8lmUTt4hLuv = bP2ptXl7DGnqQvOfUH[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡴࡱࡧࡹࡢࡤ࡬ࡰ࡮ࡺࡹࡔࡶࡤࡸࡺࡹࠧῂ")][xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࡷ࡫ࡡࡴࡱࡱࠫῃ")]
		except: RwxE8lmUTt4hLuv = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if G8CImB4K9pN3OhHT or dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs or Rv3xcXSYnZIK7bFNiUHweEQL0z1j or amIcByjdlx5ktPVoh2WvQOXsLzi or LySqdUiNpk8cxrA or toZ4n765X8zFp9BO3Ky2keG1N or RwxE8lmUTt4hLuv:
			if   G8CImB4K9pN3OhHT: CtO9cFuULSm62PWToMlzN1 = G8CImB4K9pN3OhHT[f4fTutDOEwUeIoPLRQ]
			elif dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs: CtO9cFuULSm62PWToMlzN1 = dEWY8Quh7ypwNMU5x1JRFoZlXqiGSs[f4fTutDOEwUeIoPLRQ]
			elif Rv3xcXSYnZIK7bFNiUHweEQL0z1j: CtO9cFuULSm62PWToMlzN1 = Rv3xcXSYnZIK7bFNiUHweEQL0z1j[f4fTutDOEwUeIoPLRQ]
			elif amIcByjdlx5ktPVoh2WvQOXsLzi: CtO9cFuULSm62PWToMlzN1 = amIcByjdlx5ktPVoh2WvQOXsLzi[f4fTutDOEwUeIoPLRQ]
			elif LySqdUiNpk8cxrA: CtO9cFuULSm62PWToMlzN1 = LySqdUiNpk8cxrA
			elif toZ4n765X8zFp9BO3Ky2keG1N: CtO9cFuULSm62PWToMlzN1 = toZ4n765X8zFp9BO3Ky2keG1N
			elif RwxE8lmUTt4hLuv: CtO9cFuULSm62PWToMlzN1 = RwxE8lmUTt4hLuv
			rFb35EZUWa2 = CtO9cFuULSm62PWToMlzN1.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			EHRKpjc8XJ4xfl9FkndgsryPe7Gi = eMypvI8XqHjYU02anWD9gsSrkt+UpQ56M0dO1N9xIvVegy(u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣๅ๏ํࠠๆึๆ่ฮࠦ࠮࠯ࠢฦ์ࠥเ๊า่่ࠢฬฬๅࠡๆห฽฻ࠦวๅ็ึฮำีๅ๋่ࠣ࠲࠳ࠦร้ࠢ฽๎ึࠦๅห๊ไีࠥอไร่ࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢํัฯอฬࠡึํล๋ࠥอะัࠣ࠲࠳ࠦร้ࠢํ์ฯ๐่ษࠢ฽๎ึࠦโศัิࠤศ์๋ࠠึ฽่ࠥอไโ์า๎ํࠦวๅฤ้ࠫῄ")+c7gxFyUCGm
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,UpQ56M0dO1N9xIvVegy(u"࠭ัิษ็อ๋ࠥๆࠡษ็้ํู่๊ࠡส่๊ฮัๆฮࠪ῅"),EHRKpjc8XJ4xfl9FkndgsryPe7Gi+bnI4kmPtrW7yFEhljXOCq9(u"ࠧ࡝ࡰ࡟ࡲࠬῆ")+l5JG7XwbOfo8DznU+YayJj10OGl(u"ࠨำึห้ฯࠠๆ่ࠣ๎ํะ๊้สࠪῇ")+c7gxFyUCGm+wwOnIucWJj+rFb35EZUWa2)
			return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡈࡶࡷࡵࡲࠡࠢࠣࠤ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲ࡛ࠡࡒ࡙࡙࡛ࡂࡆࠢࡉࡥ࡮ࡲࡥࡥ࠼ࠣࠫῈ")+rFb35EZUWa2,[],[]
		else: return O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪΈ"),[],[]
	us5ZmETVAqtnhxrlFJb,NdVt7BJXkGLMy14,beCdKlr8WVY5GMSo3aL = [],[],[]
	for dict in Hi2WrtP1f4DlGk5gR:
		if dict[ulAxHwvzR9eTb5n(u"ࠫࡹࡿࡰࡦ࠴ࠪῊ")]==X60YQOADpkHBb31LiR5qUEKfM(u"ࠬ࡜ࡩࡥࡧࡲࠫΉ"):
			NihE6AX0xgq1aUoKcwk9PFId.append(dict[l4DS8mnEjHhFMZ5YOe(u"࠭ࡴࡪࡶ࡯ࡩࠬῌ")])
			ahwJu69WiN.append(dict)
		elif dict[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡵࡻࡳࡩ࠷࠭῍")]==flDSRbv57PnV3(u"ࠨࡃࡸࡨ࡮ࡵࠧ῎"):
			dBColkMzqPciO.append(dict[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡷ࡭ࡹࡲࡥࠨ῏")])
			I72X4GAJm3QSaWqBrFU5j.append(dict)
		elif dict[IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬῐ")]==t4txivgXSUWBOlCakQmNDjf(u"ࠫࡲࡶࡤࠨῑ"):
			title = dict[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡺࡩࡵ࡮ࡨࠫῒ")].replace(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡁࠬࡘ࠽ࠤࠥ࠭ΐ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if bYyKEjIuGQzoq3AR1(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ῔") not in list(dict.keys()): twyo6bl7DKGL = l4DS8mnEjHhFMZ5YOe(u"ࠨ࠲ࠪ῕")
			else: twyo6bl7DKGL = dict[Fo1SgXMsHk(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪῖ")]
			us5ZmETVAqtnhxrlFJb.append([dict,{},title,twyo6bl7DKGL])
		else:
			title = dict[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡸ࡮ࡺ࡬ࡦࠩῗ")].replace(DJ6ugPjW9bX8I(u"ࠫࡆ࠱ࡖ࠻ࠢࠣࠫῘ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if UpQ56M0dO1N9xIvVegy(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭Ῑ") not in list(dict.keys()): twyo6bl7DKGL = cb3rmvAn4wa6lBPz2phOoYqX(u"࠭࠰ࠨῚ")
			else: twyo6bl7DKGL = dict[bYyKEjIuGQzoq3AR1(u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨΊ")]
			us5ZmETVAqtnhxrlFJb.append([dict,{},title,twyo6bl7DKGL])
			reNHJO2YV6DqcbpMu5XQnF.append(title)
			ej8EUVpXQlCYra7tNz094IF6xfPbk.append(dict)
		BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r = Ag9l6cw3EBqP8HsQuGMizfOtr4
		if UpQ56M0dO1N9xIvVegy(u"ࠨࡥࡲࡨࡪࡩࡳࠨ῜") in list(dict.keys()):
			if UpQ56M0dO1N9xIvVegy(u"ࠩࡤࡺ࠵࠭῝") in dict[YayJj10OGl(u"ࠪࡧࡴࡪࡥࡤࡵࠪ῞")]: BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r = SmbNGskjMx
			elif o8MCS3IzmRXdVDB7xg2eiW5baZUn<qrjy8LuKVPNYdbSvzh(u"࠶࠾উ"):
				if X1mRwt2YJKgCLu9a67(u"ࠫࡦࡼࡣࠨ῟") not in dict[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡩ࡯ࡥࡧࡦࡷࠬῠ")] and UpQ56M0dO1N9xIvVegy(u"࠭࡭ࡱ࠶ࡤࠫῡ") not in dict[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧࡤࡱࡧࡩࡨࡹࠧῢ")]: BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r = SmbNGskjMx
		if dict[qrjy8LuKVPNYdbSvzh(u"ࠨࡶࡼࡴࡪ࠸ࠧΰ")]==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࡙ࠩ࡭ࡩ࡫࡯ࠨῤ") and dict[I3cxjYaHhsrM7T4UX26klN(u"ࠪ࡭ࡳ࡯ࡴࠨῥ")]!=qrjy8LuKVPNYdbSvzh(u"ࠫ࠵࠳࠰ࠨῦ") and BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r==Ag9l6cw3EBqP8HsQuGMizfOtr4:
			NR8JCd3ogDfZjG17zHiFyI2450rPt.append(dict[X1mRwt2YJKgCLu9a67(u"ࠬࡺࡩࡵ࡮ࡨࠫῧ")])
			bqEZg1G0uzIocX6r.append(dict)
		elif dict[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡴࡺࡲࡨ࠶ࠬῨ")]==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࡂࡷࡧ࡭ࡴ࠭Ῡ") and dict[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨ࡫ࡱ࡭ࡹ࠭Ὺ")]!=ulAxHwvzR9eTb5n(u"ࠩ࠳࠱࠵࠭Ύ") and BKCkLEAtwlNsmQzJ0MUXvZd8a3x7r==Ag9l6cw3EBqP8HsQuGMizfOtr4:
			GHJglMPq8dicaB67DbXURvowe3T.append(dict[X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡸ࡮ࡺ࡬ࡦࠩῬ")])
			qq5efZJx26AEv8ph.append(dict)
	for kQVO4r3FPjWH6 in qq5efZJx26AEv8ph:
		GP9mJLwqZbf2Kugp = kQVO4r3FPjWH6[SSvu1CZjTW7FcloNqD(u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ῭")]
		for HswcgVSFO3hExZflmX5KN4jro9QMR in bqEZg1G0uzIocX6r:
			QAl9WCgY3nwHN = HswcgVSFO3hExZflmX5KN4jro9QMR[t4txivgXSUWBOlCakQmNDjf(u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭΅")]
			twyo6bl7DKGL = QAl9WCgY3nwHN+GP9mJLwqZbf2Kugp
			title = HswcgVSFO3hExZflmX5KN4jro9QMR[xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠭ࡴࡪࡶ࡯ࡩࠬ`")].replace(X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡗ࡫ࡧࡩࡴࡀࠠࠡࠩ῰"),bYyKEjIuGQzoq3AR1(u"ࠨ࡯ࡳࡨࠥࠦࠧ῱"))
			title = title.replace(HswcgVSFO3hExZflmX5KN4jro9QMR[O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫῲ")]+BhmzEC6OGD7FXZig9Tp5A,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			title = title.replace(str((float(QAl9WCgY3nwHN*SSvu1CZjTW7FcloNqD(u"࠷࠰ঊ"))//I3cxjYaHhsrM7T4UX26klN(u"࠱࠱࠴࠷ঋ")/SSvu1CZjTW7FcloNqD(u"࠷࠰ঊ")))+qrjy8LuKVPNYdbSvzh(u"ࠪ࡯ࡧࡶࡳࠨῳ"),str((float(twyo6bl7DKGL*SSvu1CZjTW7FcloNqD(u"࠷࠰ঊ"))//I3cxjYaHhsrM7T4UX26klN(u"࠱࠱࠴࠷ঋ")/SSvu1CZjTW7FcloNqD(u"࠷࠰ঊ")))+SSvu1CZjTW7FcloNqD(u"ࠫࡰࡨࡰࡴࠩῴ"))
			title = title+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬ࠮ࠧ῵")+kQVO4r3FPjWH6[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡴࡪࡶ࡯ࡩࠬῶ")].split(bnI4kmPtrW7yFEhljXOCq9(u"ࠧࠩࠩῷ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
			us5ZmETVAqtnhxrlFJb.append([HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL])
	us5ZmETVAqtnhxrlFJb = sorted(us5ZmETVAqtnhxrlFJb, reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4, key=lambda key: float(key[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb]))
	for HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL in us5ZmETVAqtnhxrlFJb:
		uTj3MXJU5l7roQkd = HswcgVSFO3hExZflmX5KN4jro9QMR[bYyKEjIuGQzoq3AR1(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪῸ")]
		if usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫΌ") in list(kQVO4r3FPjWH6.keys()):
			uTj3MXJU5l7roQkd = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡱࡵࡪࠧῺ")
		if uTj3MXJU5l7roQkd not in beCdKlr8WVY5GMSo3aL:
			beCdKlr8WVY5GMSo3aL.append(uTj3MXJU5l7roQkd)
			NdVt7BJXkGLMy14.append([HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL])
	vvGIkPQMdXxus0,JZMTEbhgmdpo5rGt2ijVSDnK7U9,lc43J2kIQDvNmAgOXHrCGzwEextM = [],[],f4fTutDOEwUeIoPLRQ
	cZfRJhSApvVbEH6k1jlqNnr5QdXC,NLg42WeBdYFf1rDUbKo = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: cZfRJhSApvVbEH6k1jlqNnr5QdXC = bP2ptXl7DGnqQvOfUH[bYyKEjIuGQzoq3AR1(u"ࠫࡻ࡯ࡤࡦࡱࡇࡩࡹࡧࡩ࡭ࡵࠪΏ")][fgv5U2eRVaQqSiuGD(u"ࠬࡧࡵࡵࡪࡲࡶࠬῼ")]
	except: cZfRJhSApvVbEH6k1jlqNnr5QdXC = nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: Mx4okSWZqj13Cw = bP2ptXl7DGnqQvOfUH[q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬ´")][DJ6ugPjW9bX8I(u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࠪ῾")]
	except: Mx4okSWZqj13Cw = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if cZfRJhSApvVbEH6k1jlqNnr5QdXC and Mx4okSWZqj13Cw:
		lc43J2kIQDvNmAgOXHrCGzwEextM += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		title = eMypvI8XqHjYU02anWD9gsSrkt+IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡑ࡚ࡒࡊࡘ࠺ࠡࠢࠪ῿")+cZfRJhSApvVbEH6k1jlqNnr5QdXC+c7gxFyUCGm
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = sCSyOla9hrcE[z3sIGH8jmLYg(u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬࠀ")][f4fTutDOEwUeIoPLRQ]+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨࠁ")+Mx4okSWZqj13Cw
		vvGIkPQMdXxus0.append(title)
		JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		try: NLg42WeBdYFf1rDUbKo = bP2ptXl7DGnqQvOfUH[wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡶࡪࡦࡨࡳࡉ࡫ࡴࡢ࡫࡯ࡷࠬࠂ")][bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࠃ")][t4txivgXSUWBOlCakQmNDjf(u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࠄ")][-vkIa3ijEQVsJGdWOXwK7bnue9ADR][bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡸࡶࡱ࠭ࠅ")]
		except: pass
	for HswcgVSFO3hExZflmX5KN4jro9QMR,kQVO4r3FPjWH6,title,twyo6bl7DKGL in NdVt7BJXkGLMy14:
		vvGIkPQMdXxus0.append(title) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪ࡬࡮࡭ࡨࡦࡵࡷࠫࠆ"))
	if reNHJO2YV6DqcbpMu5XQnF: vvGIkPQMdXxus0.append(cb3rmvAn4wa6lBPz2phOoYqX(u"ฺࠫ๎ัสู๋ࠢํะࠠๆฯาำฮ࠭ࠇ")) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(Fo1SgXMsHk(u"ࠬࡳࡵࡹࡧࡧࠫࠈ"))
	if us5ZmETVAqtnhxrlFJb: vvGIkPQMdXxus0.append(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ี้ำฬࠤํ฻่หࠢส่๊ะ่โำࠪࠉ")) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(qrjy8LuKVPNYdbSvzh(u"ࠧࡢ࡮࡯ࠫࠊ"))
	if NR8JCd3ogDfZjG17zHiFyI2450rPt: vvGIkPQMdXxus0.append(bYyKEjIuGQzoq3AR1(u"ࠨ࡯ࡳࡨࠥอฮหำࠣห้฻่าหࠣ์ฬ๊ี้ฬࠪࠋ")) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(Fo1SgXMsHk(u"ࠩࡰࡴࡩ࠭ࠌ"))
	if NihE6AX0xgq1aUoKcwk9PFId: vvGIkPQMdXxus0.append(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ูࠪํืษࠡสา์๋ࠦี้ฬࠪࠍ")) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(SSvu1CZjTW7FcloNqD(u"ࠫࡻ࡯ࡤࡦࡱࠪࠎ"))
	if dBColkMzqPciO: vvGIkPQMdXxus0.append(ulAxHwvzR9eTb5n(u"ࠬ฻่หࠢหำํ์ࠠึ๊ิอࠬࠏ")) ; JZMTEbhgmdpo5rGt2ijVSDnK7U9.append(IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡡࡶࡦ࡬ࡳࠬࠐ"))
	bHAYFo9MGm6gIBOReSjNLr2 = SmbNGskjMx
	while Ag9l6cw3EBqP8HsQuGMizfOtr4:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr(RNhYFJCkgb4iU5M, vvGIkPQMdXxus0)
		if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR: return cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡆ࡚ࡌࡘࡤࡇࡌࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬࠑ"),[],[]
		elif bCiGxXzDkH==f4fTutDOEwUeIoPLRQ and cZfRJhSApvVbEH6k1jlqNnr5QdXC:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = JZMTEbhgmdpo5rGt2ijVSDnK7U9[bCiGxXzDkH]
			vBWiqzoKuAxkDFLdHZjm9JrUy4t0I = Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[f4fTutDOEwUeIoPLRQ]+tM24jD1gO0(u"ࠨࡁࡷࡽࡵ࡫࠽ࡧࡱ࡯ࡨࡪࡸࠦ࡮ࡱࡧࡩࡂ࠷࠴࠲ࠨࡱࡥࡲ࡫࠽ࠨࠒ")+lcxFAteLQ1Pwu45Er2(cZfRJhSApvVbEH6k1jlqNnr5QdXC)+QlTuvPbSpnjygBVW(u"ࠩࠩࡹࡷࡲ࠽ࠨࠓ")+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if NLg42WeBdYFf1rDUbKo: vBWiqzoKuAxkDFLdHZjm9JrUy4t0I = vBWiqzoKuAxkDFLdHZjm9JrUy4t0I+bnI4kmPtrW7yFEhljXOCq9(u"ࠪࠪ࡮ࡳࡡࡨࡧࡀࠫࠔ")+lcxFAteLQ1Pwu45Er2(NLg42WeBdYFf1rDUbKo)
			RarSo2nTfwU0WEGK.executebuiltin(flDSRbv57PnV3(u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣࠕ")+vBWiqzoKuAxkDFLdHZjm9JrUy4t0I+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࠯ࠢࠖ"))
			return q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡅ࡙ࡋࡗࡣࡆࡒࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫࠗ"),[],[]
		CH74LFlzUW3gkcxe2P = JZMTEbhgmdpo5rGt2ijVSDnK7U9[bCiGxXzDkH]
		AsywcRXgd9IY5 = vvGIkPQMdXxus0[bCiGxXzDkH]
		if CH74LFlzUW3gkcxe2P==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡥࡣࡶ࡬ࠬ࠘"):
			YRzpqA4JkjoOt1KC0du = w4Kx6sQHfSlboc8mYM27de9D1yqI
			break
		elif CH74LFlzUW3gkcxe2P in [yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡣࡸࡨ࡮ࡵࠧ࠙"),z3sIGH8jmLYg(u"ࠩࡹ࡭ࡩ࡫࡯ࠨࠚ"),SSvu1CZjTW7FcloNqD(u"ࠪࡱࡺࡾࡥࡥࠩࠛ")]:
			if CH74LFlzUW3gkcxe2P==YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡲࡻࡸࡦࡦࠪࠜ"): bbKoeBcirVfzwAqZdQUFDSX,v1VonNPWhEGSa = reNHJO2YV6DqcbpMu5XQnF,ej8EUVpXQlCYra7tNz094IF6xfPbk
			elif CH74LFlzUW3gkcxe2P==usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡼࡩࡥࡧࡲࠫࠝ"): bbKoeBcirVfzwAqZdQUFDSX,v1VonNPWhEGSa = NihE6AX0xgq1aUoKcwk9PFId,ahwJu69WiN
			elif CH74LFlzUW3gkcxe2P==I3cxjYaHhsrM7T4UX26klN(u"࠭ࡡࡶࡦ࡬ࡳࠬࠞ"): bbKoeBcirVfzwAqZdQUFDSX,v1VonNPWhEGSa = dBColkMzqPciO,I72X4GAJm3QSaWqBrFU5j
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧศะอีࠥอไๆๆไࠤ࠭࠭ࠟ")+str(len(bbKoeBcirVfzwAqZdQUFDSX))+fgv5U2eRVaQqSiuGD(u"ࠨ่่ࠢๆ࠯ࠧࠠ"), bbKoeBcirVfzwAqZdQUFDSX)
			if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				YRzpqA4JkjoOt1KC0du = v1VonNPWhEGSa[bCiGxXzDkH][qrjy8LuKVPNYdbSvzh(u"ࠩࡸࡶࡱ࠭ࠡ")]
				AsywcRXgd9IY5 = bbKoeBcirVfzwAqZdQUFDSX[bCiGxXzDkH]
				break
		elif CH74LFlzUW3gkcxe2P==IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡱࡵࡪࠧࠢ"):
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫฬิสาࠢฯ์ิฯࠠศๆุ์ึฯࠠࠩࠩࠣ")+str(len(NR8JCd3ogDfZjG17zHiFyI2450rPt))+X1mRwt2YJKgCLu9a67(u"ࠬࠦๅๅใࠬࠫࠤ"), NR8JCd3ogDfZjG17zHiFyI2450rPt)
			if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				AsywcRXgd9IY5 = NR8JCd3ogDfZjG17zHiFyI2450rPt[bCiGxXzDkH]
				lJoMYGpUm3TDVBgAjfs9 = bqEZg1G0uzIocX6r[bCiGxXzDkH]
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr(t4txivgXSUWBOlCakQmNDjf(u"࠭วฯฬิࠤั๎ฯสࠢสฺ่๎สࠡࠪࠪࠥ")+str(len(GHJglMPq8dicaB67DbXURvowe3T))+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࠡ็็ๅ࠮࠭ࠦ"), GHJglMPq8dicaB67DbXURvowe3T)
				if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
					AsywcRXgd9IY5 += usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࠢ࠮ࠤࠬࠧ")+GHJglMPq8dicaB67DbXURvowe3T[bCiGxXzDkH]
					lkhEPsCwpcYUF5m8HRoD1y4i = qq5efZJx26AEv8ph[bCiGxXzDkH]
					bHAYFo9MGm6gIBOReSjNLr2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
					break
		elif CH74LFlzUW3gkcxe2P==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡤࡰࡱ࠭ࠨ"):
			srxZ2kiQoDIcJ3NRlS8,A1dGqPWl4FH0CgErLmcwSefnUo,zZm40svxDJBWqgd,vvAVFulUMsr = list(zip(*us5ZmETVAqtnhxrlFJb))
			bCiGxXzDkH = nnRXQH90qeOtABkJzGr(flDSRbv57PnV3(u"ࠪหำะัࠡษ็้้็ࠠࠩࠩࠩ")+str(len(zZm40svxDJBWqgd))+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"๋ࠫࠥไโࠫࠪࠪ"), zZm40svxDJBWqgd)
			if bCiGxXzDkH!=-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				AsywcRXgd9IY5 = zZm40svxDJBWqgd[bCiGxXzDkH]
				lJoMYGpUm3TDVBgAjfs9 = srxZ2kiQoDIcJ3NRlS8[bCiGxXzDkH]
				if QlTuvPbSpnjygBVW(u"ࠬࡳࡰࡥࠩࠫ") in zZm40svxDJBWqgd[bCiGxXzDkH] and lJoMYGpUm3TDVBgAjfs9[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡵࡳ࡮ࠪࠬ")]!=w4Kx6sQHfSlboc8mYM27de9D1yqI:
					lkhEPsCwpcYUF5m8HRoD1y4i = A1dGqPWl4FH0CgErLmcwSefnUo[bCiGxXzDkH]
					bHAYFo9MGm6gIBOReSjNLr2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
				else: YRzpqA4JkjoOt1KC0du = lJoMYGpUm3TDVBgAjfs9[ulAxHwvzR9eTb5n(u"ࠧࡶࡴ࡯ࠫ࠭")]
				break
		elif CH74LFlzUW3gkcxe2P==Fo1SgXMsHk(u"ࠨࡪ࡬࡫࡭࡫ࡳࡵࠩ࠮"):
			srxZ2kiQoDIcJ3NRlS8,A1dGqPWl4FH0CgErLmcwSefnUo,zZm40svxDJBWqgd,vvAVFulUMsr = list(zip(*NdVt7BJXkGLMy14))
			lJoMYGpUm3TDVBgAjfs9 = srxZ2kiQoDIcJ3NRlS8[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM]
			if qrjy8LuKVPNYdbSvzh(u"ࠩࡰࡴࡩ࠭࠯") in zZm40svxDJBWqgd[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM] and lJoMYGpUm3TDVBgAjfs9[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡹࡷࡲࠧ࠰")]!=w4Kx6sQHfSlboc8mYM27de9D1yqI:
				lkhEPsCwpcYUF5m8HRoD1y4i = A1dGqPWl4FH0CgErLmcwSefnUo[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM]
				bHAYFo9MGm6gIBOReSjNLr2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
			else: YRzpqA4JkjoOt1KC0du = lJoMYGpUm3TDVBgAjfs9[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡺࡸ࡬ࠨ࠱")]
			AsywcRXgd9IY5 = zZm40svxDJBWqgd[bCiGxXzDkH-lc43J2kIQDvNmAgOXHrCGzwEextM]
			break
	if not bHAYFo9MGm6gIBOReSjNLr2: xMmZ3ViwDcNgT = YRzpqA4JkjoOt1KC0du
	else: xMmZ3ViwDcNgT = ulAxHwvzR9eTb5n(u"ࠬ࡜ࡩࡥࡧࡲ࠾ࠥ࠭࠲")+lJoMYGpUm3TDVBgAjfs9[QlTuvPbSpnjygBVW(u"࠭ࡵࡳ࡮ࠪ࠳")]+Fo1SgXMsHk(u"ࠧࠡ࠭ࠣࡅࡺࡪࡩࡰ࠼ࠣࠫ࠴")+lkhEPsCwpcYUF5m8HRoD1y4i[YayJj10OGl(u"ࠨࡷࡵࡰࠬ࠵")]
	if bHAYFo9MGm6gIBOReSjNLr2:
		ICGU9xVBohSWkLA4RzNdT = int(lJoMYGpUm3TDVBgAjfs9[bYyKEjIuGQzoq3AR1(u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ࠶")])
		csoGZaKLS21 = int(lkhEPsCwpcYUF5m8HRoD1y4i[SSvu1CZjTW7FcloNqD(u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ࠷")])
		H07WdckxAoZF1fn4LNMOTP65eEtr = str(max(ICGU9xVBohSWkLA4RzNdT,csoGZaKLS21))
		kfrcL5RDN8a10eHTUjhgXKs7ViFm6 = lJoMYGpUm3TDVBgAjfs9[DJ6ugPjW9bX8I(u"ࠫࡺࡸ࡬ࠨ࠸")].replace(bYyKEjIuGQzoq3AR1(u"ࠬࠬࠧ࠹"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࠦࡢ࡯ࡳ࠿ࠬ࠺"))
		uEYBcGLQMZzwy4Ue53Co2V7 = lkhEPsCwpcYUF5m8HRoD1y4i[l4DS8mnEjHhFMZ5YOe(u"ࠧࡶࡴ࡯ࠫ࠻")].replace(QlTuvPbSpnjygBVW(u"ࠨࠨࠪ࠼"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࠩࡥࡲࡶ࠻ࠨ࠽"))
		mpd = X1mRwt2YJKgCLu9a67(u"ࠪࡀࡄࡾ࡭࡭ࠢࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠶࠴࠰ࠣࠢࡨࡲࡨࡵࡤࡪࡰࡪࡁ࡛ࠧࡔࡇ࠯࠻ࠦࡄࡄ࡜࡯ࠩ࠾")
		mpd += bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡁࡓࡐࡅࠢࡻࡱࡱࡴࡳ࠻ࡺࡶ࡭ࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡻ࠸࠴࡯ࡳࡩ࠲࠶࠵࠶࠱࠰࡚ࡐࡐࡘࡩࡨࡦ࡯ࡤ࠱࡮ࡴࡳࡵࡣࡱࡧࡪࠨࠠࡹ࡯࡯ࡲࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡴࡥ࡫ࡩࡲࡧ࠺࡮ࡲࡧ࠾࠷࠶࠱࠲ࠤࠣࡼࡲࡲ࡮ࡴ࠼ࡻࡰ࡮ࡴ࡫࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠱࠺࠻࠼࠳ࡽࡲࡩ࡯࡭ࠥࠤࡽࡹࡩ࠻ࡵࡦ࡬ࡪࡳࡡࡍࡱࡦࡥࡹ࡯࡯࡯࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠥ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡴࡢࡰࡧࡥࡷࡪࡳ࠯࡫ࡶࡳ࠳ࡵࡲࡨ࠱࡬ࡸࡹ࡬࠯ࡑࡷࡥࡰ࡮ࡩ࡬ࡺࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࡗࡹࡧ࡮ࡥࡣࡵࡨࡸ࠵ࡍࡑࡇࡊ࠱ࡉࡇࡓࡉࡡࡶࡧ࡭࡫࡭ࡢࡡࡩ࡭ࡱ࡫ࡳ࠰ࡆࡄࡗࡍ࠳ࡍࡑࡆ࠱ࡼࡸࡪࠢࠡ࡯࡬ࡲࡇࡻࡦࡧࡧࡵࡘ࡮ࡳࡥ࠾ࠤࡓࡘ࠶࠴࠵ࡔࠤࠣࡱࡪࡪࡩࡢࡒࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࡄࡶࡴࡤࡸ࡮ࡵ࡮࠾ࠤࡓࡘࠬ࠿")+H07WdckxAoZF1fn4LNMOTP65eEtr+ulAxHwvzR9eTb5n(u"࡙ࠬࠢࠡࡶࡼࡴࡪࡃࠢࡴࡶࡤࡸ࡮ࡩࠢࠡࡲࡵࡳ࡫࡯࡬ࡦࡵࡀࠦࡺࡸ࡮࠻࡯ࡳࡩ࡬ࡀࡤࡢࡵ࡫࠾ࡵࡸ࡯ࡧ࡫࡯ࡩ࠿࡯ࡳࡰࡨࡩ࠱ࡲࡧࡩ࡯࠼࠵࠴࠶࠷ࠢ࠿࡞ࡱࠫࡀ")
		mpd += flDSRbv57PnV3(u"࠭࠼ࡑࡧࡵ࡭ࡴࡪ࠾࡝ࡰࠪࡁ")
		mpd += t4txivgXSUWBOlCakQmNDjf(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠶ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡻ࡯ࡤࡦࡱ࠲ࠫࡂ")+lJoMYGpUm3TDVBgAjfs9[cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪࡃ")]+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀ࡙ࠦࡸࡵࡦࠤࡁࡠࡳ࠭ࡄ")
		mpd += l4DS8mnEjHhFMZ5YOe(u"ࠪࡀࡗࡵ࡬ࡦࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡈࡆ࡙ࡈ࠻ࡴࡲࡰࡪࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࡳࡡࡪࡰࠥ࠳ࡃࡢ࡮ࠨࡅ")
		mpd += SSvu1CZjTW7FcloNqD(u"ࠫࡁࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠦࡩࡥ࠿ࠥࠫࡆ")+lJoMYGpUm3TDVBgAjfs9[QlTuvPbSpnjygBVW(u"ࠬ࡯ࡴࡢࡩࠪࡇ")]+DJ6ugPjW9bX8I(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪࡈ")+lJoMYGpUm3TDVBgAjfs9[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡤࡱࡧࡩࡨࡹࠧࡉ")]+DJ6ugPjW9bX8I(u"ࠨࠤࠣࡷࡹࡧࡲࡵ࡙࡬ࡸ࡭࡙ࡁࡑ࠿ࠥ࠵ࠧࠦࡢࡢࡰࡧࡻ࡮ࡪࡴࡩ࠿ࠥࠫࡊ")+str(lJoMYGpUm3TDVBgAjfs9[SSvu1CZjTW7FcloNqD(u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪࡋ")])+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪࠦࠥࡽࡩࡥࡶ࡫ࡁࠧ࠭ࡌ")+str(lJoMYGpUm3TDVBgAjfs9[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡼ࡯ࡤࡵࡪࠪࡍ")])+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࠨࠠࡩࡧ࡬࡫࡭ࡺ࠽ࠣࠩࡎ")+str(lJoMYGpUm3TDVBgAjfs9[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭ࡏ")])+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࠣࠢࡩࡶࡦࡳࡥࡓࡣࡷࡩࡂࠨࠧࡐ")+lJoMYGpUm3TDVBgAjfs9[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡨࡳࡷࠬࡑ")]+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࠥࡂࡡࡴࠧࡒ")
		mpd += q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡀࡇࡧࡳࡦࡗࡕࡐࡃ࠭ࡓ")+kfrcL5RDN8a10eHTUjhgXKs7ViFm6+X1mRwt2YJKgCLu9a67(u"ࠫࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾࡝ࡰࠪࡔ")
		mpd += usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡂࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࠤ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥ࠾ࠤࠪࡕ")+lJoMYGpUm3TDVBgAjfs9[X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡩ࡯ࡦࡨࡼࠬࡖ")]+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࠣࡀ࡟ࡲࠬࡗ")
		mpd += z3sIGH8jmLYg(u"ࠨ࠾ࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡦࡺࡩࡰࡰࠣࡶࡦࡴࡧࡦ࠿ࠥࠫࡘ")+lJoMYGpUm3TDVBgAjfs9[qrjy8LuKVPNYdbSvzh(u"ࠩ࡬ࡲ࡮ࡺ࡙ࠧ")]+SSvu1CZjTW7FcloNqD(u"ࠪࠦࠥ࠵࠾࡝ࡰ࡚ࠪ")
		mpd += l4DS8mnEjHhFMZ5YOe(u"ࠫࡁ࠵ࡓࡦࡩࡰࡩࡳࡺࡂࡢࡵࡨࡂࡡࡴ࡛ࠧ")
		mpd += fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡂ࠯ࡓࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮࠿࡞ࡱࠫ࡜")
		mpd += wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭࠼࠰ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴ࠿࡞ࡱࠫ࡝")
		mpd += QlTuvPbSpnjygBVW(u"ࠧ࠽ࡃࡧࡥࡵࡺࡡࡵ࡫ࡲࡲࡘ࡫ࡴࠡ࡫ࡧࡁࠧ࠷ࠢࠡ࡯࡬ࡱࡪ࡚ࡹࡱࡧࡀࠦࡦࡻࡤࡪࡱ࠲ࠫ࡞")+lkhEPsCwpcYUF5m8HRoD1y4i[yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ࡟")]+UpQ56M0dO1N9xIvVegy(u"ࠩࠥࠤࡸࡻࡢࡴࡧࡪࡱࡪࡴࡴࡂ࡮࡬࡫ࡳࡳࡥ࡯ࡶࡀ࡙ࠦࡸࡵࡦࠤࡁࡠࡳ࠭ࡠ")
		mpd += wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡀࡗࡵ࡬ࡦࠢࡶࡧ࡭࡫࡭ࡦࡋࡧ࡙ࡷ࡯࠽ࠣࡷࡵࡲ࠿ࡳࡰࡦࡩ࠽ࡈࡆ࡙ࡈ࠻ࡴࡲࡰࡪࡀ࠲࠱࠳࠴ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࡳࡡࡪࡰࠥ࠳ࡃࡢ࡮ࠨࡡ")
		mpd += bYyKEjIuGQzoq3AR1(u"ࠫࡁࡘࡥࡱࡴࡨࡷࡪࡴࡴࡢࡶ࡬ࡳࡳࠦࡩࡥ࠿ࠥࠫࡢ")+lkhEPsCwpcYUF5m8HRoD1y4i[fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬ࡯ࡴࡢࡩࠪࡣ")]+bYyKEjIuGQzoq3AR1(u"࠭ࠢࠡࡥࡲࡨࡪࡩࡳ࠾ࠤࠪࡤ")+lkhEPsCwpcYUF5m8HRoD1y4i[DJ6ugPjW9bX8I(u"ࠧࡤࡱࡧࡩࡨࡹࠧࡥ")]+qrjy8LuKVPNYdbSvzh(u"ࠨࠤࠣࡦࡦࡴࡤࡸ࡫ࡧࡸ࡭ࡃࠢ࠲࠵࠳࠸࠼࠻ࠢ࠿࡞ࡱࠫࡦ")
		mpd += tM24jD1gO0(u"ࠩ࠿ࡅࡺࡪࡩࡰࡅ࡫ࡥࡳࡴࡥ࡭ࡅࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࠡࡵࡦ࡬ࡪࡳࡥࡊࡦࡘࡶ࡮ࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺࠳࠵࠳࠴࠸ࡀ࠳࠻ࡣࡸࡨ࡮ࡵ࡟ࡤࡪࡤࡲࡳ࡫࡬ࡠࡥࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮࠻࠴࠳࠵࠶ࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠨࡧ")+lkhEPsCwpcYUF5m8HRoD1y4i[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡥࡺࡪࡩࡰࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫࡨ")]+YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࠧ࠵࠾࡝ࡰࠪࡩ")
		mpd += DJ6ugPjW9bX8I(u"ࠬࡂࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨࡪ")+uEYBcGLQMZzwy4Ue53Co2V7+QlTuvPbSpnjygBVW(u"࠭࠼࠰ࡄࡤࡷࡪ࡛ࡒࡍࡀ࡟ࡲࠬ࡫")
		mpd += DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧ࠽ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࠦࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࡀࠦࠬ࡬")+lkhEPsCwpcYUF5m8HRoD1y4i[YayJj10OGl(u"ࠨ࡫ࡱࡨࡪࡾࠧ࡭")]+bYyKEjIuGQzoq3AR1(u"ࠩࠥࡂࡡࡴࠧ࡮")
		mpd += DJ6ugPjW9bX8I(u"ࠪࡀࡎࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡡࡵ࡫ࡲࡲࠥࡸࡡ࡯ࡩࡨࡁࠧ࠭࡯")+lkhEPsCwpcYUF5m8HRoD1y4i[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫ࡮ࡴࡩࡵࠩࡰ")]+X1mRwt2YJKgCLu9a67(u"ࠬࠨࠠ࠰ࡀ࡟ࡲࠬࡱ")
		mpd += X1mRwt2YJKgCLu9a67(u"࠭࠼࠰ࡕࡨ࡫ࡲ࡫࡮ࡵࡄࡤࡷࡪࡄ࡜࡯ࠩࡲ")
		mpd += bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧ࠽࠱ࡕࡩࡵࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡁࡠࡳ࠭ࡳ")
		mpd += paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨ࠾࠲ࡅࡩࡧࡰࡵࡣࡷ࡭ࡴࡴࡓࡦࡶࡁࡠࡳ࠭ࡴ")
		mpd += IINBvuxkCSJrO1Q0UyngdLi(u"ࠩ࠿࠳ࡕ࡫ࡲࡪࡱࡧࡂࡡࡴࠧࡵ")
		mpd += l4DS8mnEjHhFMZ5YOe(u"ࠪࡀ࠴ࡓࡐࡅࡀ࡟ࡲࠬࡶ")
		if IZhXMprxvAHqBEFkg0:
			import http.server as iIekgmXJPa89vfbAw073scOUGZhEu
			import http.client as dJujeXC2cbflp6Dm08o
		else:
			import BaseHTTPServer as iIekgmXJPa89vfbAw073scOUGZhEu
			import httplib as dJujeXC2cbflp6Dm08o
		class P0CY1xtRire8UWnXdqhocOTpbyw(iIekgmXJPa89vfbAw073scOUGZhEu.HTTPServer):
			def __init__(UQtCpi5bgMm8n4,ip=YayJj10OGl(u"ࠫࡱࡵࡣࡢ࡮࡫ࡳࡸࡺࠧࡷ"),port=X1mRwt2YJKgCLu9a67(u"࠶࠷࠳࠹࠺ঌ"),mpd=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡂ࠾ࠨࡸ")):
				UQtCpi5bgMm8n4.ip = ip
				UQtCpi5bgMm8n4.port = port
				UQtCpi5bgMm8n4.mpd = mpd
				iIekgmXJPa89vfbAw073scOUGZhEu.HTTPServer.__init__(UQtCpi5bgMm8n4,(UQtCpi5bgMm8n4.ip,UQtCpi5bgMm8n4.port),fbLsM80F6cnkEGm)
				UQtCpi5bgMm8n4.mpdurl = IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࠧࡹ")+ip+t4txivgXSUWBOlCakQmNDjf(u"ࠧ࠻ࠩࡺ")+str(port)+DJ6ugPjW9bX8I(u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧࡻ")
			def start(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.threads = ps6AtMmOZI5izVcr4hF0xn9TJE7RL(SmbNGskjMx)
				UQtCpi5bgMm8n4.threads.IvgGEhRUjtAKwpTlbferO8aYHuBsd(vkIa3ijEQVsJGdWOXwK7bnue9ADR,UQtCpi5bgMm8n4.RRpuUN9mbW6TzZVIexdlnFOahQ2Loc)
			def RRpuUN9mbW6TzZVIexdlnFOahQ2Loc(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.keeprunning = Ag9l6cw3EBqP8HsQuGMizfOtr4
				while UQtCpi5bgMm8n4.keeprunning:
					UQtCpi5bgMm8n4.handle_request()
			def stop(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.keeprunning = SmbNGskjMx
				UQtCpi5bgMm8n4.ukEd2Ve9LTgtSU4nmXYDx()
			def KirqQO8ZlJ2zbXexMkAaLfDuY(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.stop()
				UQtCpi5bgMm8n4.Ri19pkguZIof.close()
				UQtCpi5bgMm8n4.server_close()
			def TLl7RQ8nZeOYbIACPyukH2F(UQtCpi5bgMm8n4,mpd):
				UQtCpi5bgMm8n4.mpd = mpd
			def ukEd2Ve9LTgtSU4nmXYDx(UQtCpi5bgMm8n4):
				IgtL0mb7hnwEpYyuf6KUxXR = dJujeXC2cbflp6Dm08o.HTTPConnection(UQtCpi5bgMm8n4.ip+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩ࠽ࠫࡼ")+str(UQtCpi5bgMm8n4.port))
				IgtL0mb7hnwEpYyuf6KUxXR.request(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠥࡌࡊࡇࡄࠣࡽ"), t4txivgXSUWBOlCakQmNDjf(u"ࠦ࠴ࠨࡾ"))
		class fbLsM80F6cnkEGm(iIekgmXJPa89vfbAw073scOUGZhEu.BaseHTTPRequestHandler):
			def HeKcWV1Obj4Ayknf(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.send_response(DJ6ugPjW9bX8I(u"࠴࠳࠴঍"))
				UQtCpi5bgMm8n4.send_header(QlTuvPbSpnjygBVW(u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫࡿ"),SSvu1CZjTW7FcloNqD(u"࠭ࡴࡦࡺࡷࡸ࠴ࡶ࡬ࡢ࡫ࡱࠫࢀ"))
				UQtCpi5bgMm8n4.end_headers()
				UQtCpi5bgMm8n4.wfile.write(UQtCpi5bgMm8n4.RWZpkDLtY5Eyb46029MvAKmqBQd8o.mpd.encode(zSafwK0sDXdMN5JReniIQmrZxp))
				lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
				if UQtCpi5bgMm8n4.path==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭ࢁ"): UQtCpi5bgMm8n4.RWZpkDLtY5Eyb46029MvAKmqBQd8o.KirqQO8ZlJ2zbXexMkAaLfDuY()
				if UQtCpi5bgMm8n4.path==bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨ࠱ࡶ࡬ࡺࡺࡤࡰࡹࡱࠫࢂ"): UQtCpi5bgMm8n4.RWZpkDLtY5Eyb46029MvAKmqBQd8o.KirqQO8ZlJ2zbXexMkAaLfDuY()
			def JYAMbOg7h86GIqmjauNDtEnsf(UQtCpi5bgMm8n4):
				UQtCpi5bgMm8n4.send_response(QlTuvPbSpnjygBVW(u"࠵࠴࠵঎"))
				UQtCpi5bgMm8n4.end_headers()
		mQJfTk78wuhiRqt6DWHnId = P0CY1xtRire8UWnXdqhocOTpbyw(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬࢃ"),QlTuvPbSpnjygBVW(u"࠹࠺࠶࠵࠶এ"),mpd)
		YRzpqA4JkjoOt1KC0du = mQJfTk78wuhiRqt6DWHnId.mpdurl
		mQJfTk78wuhiRqt6DWHnId.start()
	else: mQJfTk78wuhiRqt6DWHnId = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not YRzpqA4JkjoOt1KC0du: return l4DS8mnEjHhFMZ5YOe(u"ࠪࡉࡷࡸ࡯ࡳࠢࠣࠤࠥࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪࢄ"),[],[]
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[[YRzpqA4JkjoOt1KC0du,coMCRv31uZ07nOGFVmwQAN4,mQJfTk78wuhiRqt6DWHnId]]
def PA3MXtUNpdknBTScuH16emlQW(url):
	headers = { UpQ56M0dO1N9xIvVegy(u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࢅ") : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡘࡌࡈࡇࡕࡂ࠮࠳ࡶࡸࠬࢆ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡦࡪ࡮ࡨ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠭࠲࡬ࡢࡤࡨࡰ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧࢂࠩ࡝ࡿࠪࢇ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items = set(items)
	items = sorted(items, reverse=Ag9l6cw3EBqP8HsQuGMizfOtr4, key=lambda key: key[QQSugEIn2mTCpRsfcaJHhPdAWzylM])
	v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,bbKoeBcirVfzwAqZdQUFDSX,dQS7hrjxHlAnZ14b,lPpY5fw3tOBcEye91Caun2FQZ = [],[],[],[]
	if not items: return CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡉࡥ࡮ࡲࡥࡥ࡙ࠢࡍࡉࡈࡏࡃࠩ࢈"),[],[]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uiazRbmZ63Je21WGqn,NNntz8hA93kG6WqEDb1OUoeFm2fg in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡪࡷࡸࡵࡹ࠺ࠨࢉ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩ࡫ࡸࡹࡶ࠺ࠨࢊ"))
		if bnI4kmPtrW7yFEhljXOCq9(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩࢋ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			v4pVXJWMjUC6oaQ3DY7PqKTGOSZk,dQS7hrjxHlAnZ14b = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			lPpY5fw3tOBcEye91Caun2FQZ = lPpY5fw3tOBcEye91Caun2FQZ + dQS7hrjxHlAnZ14b
			if v4pVXJWMjUC6oaQ3DY7PqKTGOSZk[f4fTutDOEwUeIoPLRQ]==X60YQOADpkHBb31LiR5qUEKfM(u"ࠫ࠲࠷ࠧࢌ"): bbKoeBcirVfzwAqZdQUFDSX.append(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ู๊ࠬาใิࠤำอีࠨࢍ")+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧࢎ"))
			else:
				for title in v4pVXJWMjUC6oaQ3DY7PqKTGOSZk:
					bbKoeBcirVfzwAqZdQUFDSX.append(IINBvuxkCSJrO1Q0UyngdLi(u"ࠧิ์ิๅึࠦฮศืࠪ࢏")+PCnucez1ITGQbklj7SoqNtw0O8+title)
		else:
			title = IINBvuxkCSJrO1Q0UyngdLi(u"ࠨีํีๆืࠠฯษุࠫ࢐")+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠣࠤࠥࡳࡰ࠵ࠢࠣࠤࠬ࢑")+NNntz8hA93kG6WqEDb1OUoeFm2fg
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			bbKoeBcirVfzwAqZdQUFDSX.append(title)
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
def mknXS3i7th0LRWj2xaF4YgcpuzGE(url,UTvsQb4HpCP3Aeo2wDZG7X5V):
	ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc,wsXrPQaN9hZR43zWp,MOi17hVvIujyezmL,rU02bCJFWZDfVuhtMgBOyQi5P = [],[],[],[],[]
	if bYyKEjIuGQzoq3AR1(u"ࠪࡷࡹࡸࠧ࢒") not in str(type(UTvsQb4HpCP3Aeo2wDZG7X5V)): UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.decode(zSafwK0sDXdMN5JReniIQmrZxp,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫ࢓"))
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡂࡶࡪࡦࡨࡳࠥࡶࡲࡦ࡮ࡲࡥࡩ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࢔"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and not JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = []
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(z3sIGH8jmLYg(u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࢕"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and not JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = []
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall(SSvu1CZjTW7FcloNqD(u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࢖"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and not JoEms64VZ1ldaf9NYBgcKCFL(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = []
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[f4fTutDOEwUeIoPLRQ]
		title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rsplit(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨ࠰ࠪࢗ"),q4izXt0sjIQSZcHVAf3EmKRbx(u"࠶ঐ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
		ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title)
		NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else:
		ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall(flDSRbv57PnV3(u"ࠩࡶࡳࡺࡸࡣࡦࡵ࠽ࠤ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨ࢘"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡺࡦࡸࠠࡴࡱࡸࡶࡨ࡫ࡳࠡ࠿ࠣࠬࡡࢁ࠮ࠫࡁ࡟ࢁ࠮࢙࠭"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠫࡻࡧࡲࠡ࡬ࡺࠤࡂࠦࠨ࡝ࡽ࠱࠮ࡄࡢࡽ࢚ࠪࠩ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not ISmqngYzv6jrepWUx0l: ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall(qrjy8LuKVPNYdbSvzh(u"ࠬࡼࡡࡳࠢࡳࡰࡦࡿࡥࡳࠢࡀࠤ࠳࠰࠿࡝ࠪࠫࡠࢀ࠴ࠪࡀ࡞ࢀ࠭ࡡ࠯࢛ࠧ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if ISmqngYzv6jrepWUx0l:
			ISmqngYzv6jrepWUx0l = ISmqngYzv6jrepWUx0l[f4fTutDOEwUeIoPLRQ]
			ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.sub(ulAxHwvzR9eTb5n(u"ࡸࠧࠩ࡝࡟ࡿࡡ࠲࡝࡜࡞ࡷࡠࡸࡢ࡮࡝ࡴࡠ࠮࠮࠮࡜ࡸ࠭࡞ࡠࡹࡢࡳ࡞ࠬࠬ࠾ࠬ࢜"),t4txivgXSUWBOlCakQmNDjf(u"ࡲࠨ࡞࠴ࠦࡡ࠸ࠢ࠻ࠩ࢝"),ISmqngYzv6jrepWUx0l)
			ISmqngYzv6jrepWUx0l = dr1zfnatJxRHSF48jh0eODm5bGu(bYyKEjIuGQzoq3AR1(u"ࠨࡦ࡬ࡧࡹ࠭࢞"),ISmqngYzv6jrepWUx0l)
			if isinstance(ISmqngYzv6jrepWUx0l,dict): ISmqngYzv6jrepWUx0l = [ISmqngYzv6jrepWUx0l]
			for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
				nP8J6rQBatEoIO9T01AMW,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
				if isinstance(G4JHzTEp61,dict):
					keys = list(G4JHzTEp61.keys())
					if   cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡷࡽࡵ࡫ࠧ࢟") in keys: nP8J6rQBatEoIO9T01AMW = str(G4JHzTEp61[t4txivgXSUWBOlCakQmNDjf(u"ࠪࡸࡾࡶࡥࠨࢠ")])
					if   q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࡫࡯࡬ࡦࠩࢡ") in keys: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61[UpQ56M0dO1N9xIvVegy(u"ࠬ࡬ࡩ࡭ࡧࠪࢢ")]
					elif z3sIGH8jmLYg(u"࠭ࡨ࡭ࡵࠪࢣ") in keys: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡩ࡮ࡶࠫࢤ")]
					elif fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡵࡵࡧࠬࢥ") in keys: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61[l4DS8mnEjHhFMZ5YOe(u"ࠩࡶࡶࡨ࠭ࢦ")]
					if   I3cxjYaHhsrM7T4UX26klN(u"ࠪࡰࡦࡨࡥ࡭ࠩࢧ") in keys: title = str(G4JHzTEp61[tM24jD1gO0(u"ࠫࡱࡧࡢࡦ࡮ࠪࢨ")])
					elif DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡼࡩࡥࡧࡲࡣ࡭࡫ࡩࡨࡪࡷࠫࢩ") in keys: title = str(G4JHzTEp61[qrjy8LuKVPNYdbSvzh(u"࠭ࡶࡪࡦࡨࡳࡤ࡮ࡥࡪࡩ࡫ࡸࠬࢪ")])
					elif X60YQOADpkHBb31LiR5qUEKfM(u"ࠧ࠯ࠩࢫ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rsplit(UpQ56M0dO1N9xIvVegy(u"ࠨ࠰ࠪࢬ"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠷঑"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
					else: title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				elif isinstance(G4JHzTEp61,str):
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61
					title = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rsplit(flDSRbv57PnV3(u"ࠩ࠱ࠫࢭ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠱঒"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
				if vkIa3ijEQVsJGdWOXwK7bnue9ADR:
					ifOk5xt1uHRJrTGFB7zZaeKIs6bqU.append(title+BhmzEC6OGD7FXZig9Tp5A+nP8J6rQBatEoIO9T01AMW)
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in zip(NWtqFg91ZSKinvIwAc,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU):
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࡠࡡ࠵ࠧࢮ"),qrjy8LuKVPNYdbSvzh(u"ࠫ࠴࠭ࢯ"))
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(url,fgv5U2eRVaQqSiuGD(u"ࠬࡻࡲ࡭ࠩࢰ"))
		VLs4zv8ycboXT0UG7rk2fAj = MdwGcQOsmlV6vKI73THrUY4()
		if bYyKEjIuGQzoq3AR1(u"࠭ࡨࡵࡶࡳࠫࢱ") not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = RWZpkDLtY5Eyb46029MvAKmqBQd8o+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࠯࡯࠶ࡹ࠽࠭ࢲ") in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			headers = {I3cxjYaHhsrM7T4UX26klN(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࢳ"):VLs4zv8ycboXT0UG7rk2fAj,z3sIGH8jmLYg(u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪࢴ"):RWZpkDLtY5Eyb46029MvAKmqBQd8o}
			QajOiNXESemx,Dl68PgMWth = mmAWFnZUkQ3HowdxRtCN9(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,headers)
			MOi17hVvIujyezmL += Dl68PgMWth
			wsXrPQaN9hZR43zWp += QajOiNXESemx
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+IINBvuxkCSJrO1Q0UyngdLi(u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩࢵ")+VLs4zv8ycboXT0UG7rk2fAj+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧࢶ")+RWZpkDLtY5Eyb46029MvAKmqBQd8o
			MOi17hVvIujyezmL.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			wsXrPQaN9hZR43zWp.append(title)
	uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	if MOi17hVvIujyezmL: uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc = nbOFVEDkpT4BIR7Qq82yPmHeJU,wsXrPQaN9hZR43zWp,MOi17hVvIujyezmL
	else:
		if Fo1SgXMsHk(u"ࠬࡂࠧࢷ") not in UTvsQb4HpCP3Aeo2wDZG7X5V and len(UTvsQb4HpCP3Aeo2wDZG7X5V)<CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠲࠲࠳ও") and UTvsQb4HpCP3Aeo2wDZG7X5V: uusxjPSpV5c = UTvsQb4HpCP3Aeo2wDZG7X5V
		else:
			msg = ScntgdOZCY74vNpXeW5jh8i.findall(fgv5U2eRVaQqSiuGD(u"࠭࠼ࡥ࡫ࡹࠤࡸࡺࡹ࡭ࡧࡀࠦ࠳࠰࠿ࠣࡀࠫࡊ࡮ࡲࡥ࠯ࠬࡂ࠭ࡁ࠭ࢸ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not msg: msg = ScntgdOZCY74vNpXeW5jh8i.findall(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡼࡰࡠࡸ࡬ࡨࡪࡵ࡟ࡴࡶࡸࡦࡤࡺࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪࢹ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if not msg: msg = ScntgdOZCY74vNpXeW5jh8i.findall(DJ6ugPjW9bX8I(u"ࠨ࠾࡫࠶ࡃ࠮ࡓࡰࡴࡵࡽ࠳࠰࠿ࠪ࠾ࠪࢺ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if msg: uusxjPSpV5c = msg[f4fTutDOEwUeIoPLRQ]
	return uusxjPSpV5c,ifOk5xt1uHRJrTGFB7zZaeKIs6bqU,NWtqFg91ZSKinvIwAc
def WkwY2x9TIB3KStndH1Nr(iHPy3of2Mkvr9b,url):
	global TTSJVE8yXumW
	url = url.strip(l4DS8mnEjHhFMZ5YOe(u"ࠩ࠲ࠫࢻ"))
	zq8hVp3J6dsvUN94FwcEPfLkCtM,iugaeRtZ5HFw7mJc9AdTbKlLV2 = nbOFVEDkpT4BIR7Qq82yPmHeJU,{}
	headers = {SSvu1CZjTW7FcloNqD(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࢼ"):MdwGcQOsmlV6vKI73THrUY4()}
	headers[wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࢽ")] = Qi32bRtN18qvyWmaO7YKow9cXs(url,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡻࡲ࡭ࠩࢾ"))
	headers[DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡌࡢࡰࡪࡹࡦ࡭ࡥࠨࢿ")] = X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡦࡰ࠰࡙ࡘ࠲ࡥ࡯࠽ࡴࡁ࠵࠴࠹ࠨࣀ")
	headers[IINBvuxkCSJrO1Q0UyngdLi(u"ࠨࡕࡨࡧ࠲ࡌࡥࡵࡥ࡫࠱ࡉ࡫ࡳࡵࠩࣁ")] = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠩࣂ")
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡋࡊ࡚ࠧࣃ"),url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࡙࠭ࡕࡋࡅࡗࡏࡎࡈ࠯࠴ࡷࡹ࠭ࣄ"))
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	kHY0cteDy7dL9sU2n = cnPhVmgFxA.code
	if not isinstance(UTvsQb4HpCP3Aeo2wDZG7X5V,str): UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.decode(zSafwK0sDXdMN5JReniIQmrZxp,t4txivgXSUWBOlCakQmNDjf(u"ࠬ࡯ࡧ࡯ࡱࡵࡩࠬࣅ"))
	if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࠬࣆ") in UTvsQb4HpCP3Aeo2wDZG7X5V:
		LITxrWQFSP = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࠩࡧࡹࡥࡱࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲࡛ࡥࡴࡠ࠲࠯ࡅࠩ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪࣇ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if LITxrWQFSP:
			try: zq8hVp3J6dsvUN94FwcEPfLkCtM = oWMSrt64vnzZAJlBmf0Y7cDujLxVsb(LITxrWQFSP[f4fTutDOEwUeIoPLRQ])
			except: zq8hVp3J6dsvUN94FwcEPfLkCtM = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠫ࡬࠱ࡻࠬ࡯࠮ࡷ࠰ࡪ࠲ࡲࠪࠩࣈ") in UTvsQb4HpCP3Aeo2wDZG7X5V:
		LITxrWQFSP = ScntgdOZCY74vNpXeW5jh8i.findall(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠫࡩࡻࡧ࡬࡝ࠪࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭࡮ࠬࡶ࠮ࡱ࠰ࡹ࠲ࡥ࠭ࡴ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩࣉ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if LITxrWQFSP:
			try: zq8hVp3J6dsvUN94FwcEPfLkCtM = VFXa9PyHhp8jzJ3OIoSlnC2kUAY5(LITxrWQFSP[f4fTutDOEwUeIoPLRQ])
			except: zq8hVp3J6dsvUN94FwcEPfLkCtM = nbOFVEDkpT4BIR7Qq82yPmHeJU
	fv4KNqjIBQT0UcHmlYSnrwOAWGV = UTvsQb4HpCP3Aeo2wDZG7X5V+zq8hVp3J6dsvUN94FwcEPfLkCtM
	if DJ6ugPjW9bX8I(u"ࠪࠦ࡮ࡪ࠲ࠣࠩ࣊") in fv4KNqjIBQT0UcHmlYSnrwOAWGV or tM24jD1gO0(u"ࠫࠧ࡯ࡤࠣࠩ࣋") in fv4KNqjIBQT0UcHmlYSnrwOAWGV:
		bYpyRcGxCOV4WBS3gmrZdjMDTzL5N = url.split(fgv5U2eRVaQqSiuGD(u"ࠬ࠵ࠧ࣌"))[ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb].replace(fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭࣍"),nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(z3sIGH8jmLYg(u"ࠧ࠯ࡪࡷࡱࡱ࠭࣎"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if QlTuvPbSpnjygBVW(u"ࠨࠤ࡬ࡨ࠷ࠨ࣏ࠧ") in fv4KNqjIBQT0UcHmlYSnrwOAWGV: iugaeRtZ5HFw7mJc9AdTbKlLV2 = {DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࡬ࡨ࠷࣐࠭"):bYpyRcGxCOV4WBS3gmrZdjMDTzL5N,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡳࡵ࣑࠭"):QlTuvPbSpnjygBVW(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸࣒ࠧ")}
		elif yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࠨࡩࡥࠤ࣓ࠪ") in fv4KNqjIBQT0UcHmlYSnrwOAWGV: iugaeRtZ5HFw7mJc9AdTbKlLV2 = {fgv5U2eRVaQqSiuGD(u"࠭ࡩࡥࠩࣔ"):bYpyRcGxCOV4WBS3gmrZdjMDTzL5N,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡰࡲࠪࣕ"):fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠫࣖ")}
		GcYwHSWoQ0Nq8KFfJDdvujZryM = headers.copy()
		GcYwHSWoQ0Nq8KFfJDdvujZryM[YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࣗ")] = X1mRwt2YJKgCLu9a67(u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩࣘ")
		KXFGbQxMAgBRYh = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,l4DS8mnEjHhFMZ5YOe(u"ࠫࡕࡕࡓࡕࠩࣙ"),url,iugaeRtZ5HFw7mJc9AdTbKlLV2,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,SmbNGskjMx,UpQ56M0dO1N9xIvVegy(u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡚ࡖࡌࡆࡘࡉࡏࡉ࠰࠶ࡳࡪࠧࣚ"))
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = KXFGbQxMAgBRYh.content
	rbmD62LsFjJS0gT5paOHNKBXA,lLAOqVw6tvRUX,Ru7m6PLbwQhAtn = mknXS3i7th0LRWj2xaF4YgcpuzGE(url,fv4KNqjIBQT0UcHmlYSnrwOAWGV)
	TTSJVE8yXumW[iHPy3of2Mkvr9b] = rbmD62LsFjJS0gT5paOHNKBXA,lLAOqVw6tvRUX,Ru7m6PLbwQhAtn,kHY0cteDy7dL9sU2n
	return
TTSJVE8yXumW,T8crE1S6MmOh7C5pwJUu = {},f4fTutDOEwUeIoPLRQ
def WY71asuKNIFy3hJbotx2TCMXU(url):
	global TTSJVE8yXumW,T8crE1S6MmOh7C5pwJUu
	rU02bCJFWZDfVuhtMgBOyQi5P,threads = [],[]
	T8crE1S6MmOh7C5pwJUu += bYyKEjIuGQzoq3AR1(u"࠳࠳࠴ঔ")
	y4XA5wJqRVjDn2h8oTcOHlv = T8crE1S6MmOh7C5pwJUu
	rU02bCJFWZDfVuhtMgBOyQi5P.append([vkIa3ijEQVsJGdWOXwK7bnue9ADR,url])
	TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+vkIa3ijEQVsJGdWOXwK7bnue9ADR] = [None,None,None,None]
	OUptEZs9Aq4Y = eb6R0h1Fjl.Thread(target=WkwY2x9TIB3KStndH1Nr,args=(y4XA5wJqRVjDn2h8oTcOHlv+vkIa3ijEQVsJGdWOXwK7bnue9ADR,url))
	OUptEZs9Aq4Y.start()
	OUptEZs9Aq4Y.join(bnI4kmPtrW7yFEhljXOCq9(u"࠴࠴ক"))
	if not TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+X60YQOADpkHBb31LiR5qUEKfM(u"࠵খ")][QQSugEIn2mTCpRsfcaJHhPdAWzylM]:
		plSscrVjkRviPwm = url.replace(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࠧࣛ"),qrjy8LuKVPNYdbSvzh(u"ࠧ࠰ࠩࣜ"))
		LCjugSrWIBPDyFb4X1o9fAM = ScntgdOZCY74vNpXeW5jh8i.findall(Fo1SgXMsHk(u"ࠨࡠࠫ࠲࠯ࡅ࠺࠰࠱࠱࠮ࡄ࠯࠯ࠩ࠰࠭ࡃ࠮࠵ࠨ࠯ࠬࡂ࠭ࠩ࠭ࣝ"),plSscrVjkRviPwm+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࠲ࠫࣞ"),ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		start,OlW8q2s4Uv0dXphEGnuc,end = LCjugSrWIBPDyFb4X1o9fAM[f4fTutDOEwUeIoPLRQ]
		end = end.strip(YayJj10OGl(u"ࠪ࠳ࠬࣟ"))
		EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D = len(OlW8q2s4Uv0dXphEGnuc)<WtDrnpJmwQ37Z2Ae68hu4BY5M1 or OlW8q2s4Uv0dXphEGnuc in [X60YQOADpkHBb31LiR5qUEKfM(u"ࠫ࡫࡯࡬ࡦࠩ࣠"),z3sIGH8jmLYg(u"ࠬࡼࡩࡥࡧࡲࠫ࣡"),Fo1SgXMsHk(u"࠭ࡶࡪࡦࡨࡳࡪࡳࡢࡦࡦࠪ࣢"),YayJj10OGl(u"ࠧࡢ࡬ࡤࡼࣣࠬ"),X1mRwt2YJKgCLu9a67(u"ࠨ࡫ࡩࡶࡦࡳࡥࠨࣤ"),bYyKEjIuGQzoq3AR1(u"ࠩࡰ࡭ࡷࡸ࡯ࡳࠩࣥ")]
		if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([QQSugEIn2mTCpRsfcaJHhPdAWzylM,start+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࣦࠫ")+OlW8q2s4Uv0dXphEGnuc+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࠴࠭ࣧ")+end])
		if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb,start+z3sIGH8jmLYg(u"ࠬ࠵ࠧࣨ")+OlW8q2s4Uv0dXphEGnuc+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭࠯ࡦ࡯ࡥࡩࡩ࠳ࣩࠧ")+end])
		if usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧ࠯ࡪࡷࡱࡱ࠭࣪") in OlW8q2s4Uv0dXphEGnuc:
			vBuLTz940FAONjwtJXQfKEmIo = OlW8q2s4Uv0dXphEGnuc.replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨ࠰࡫ࡸࡲࡲࠧ࣫"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			rU02bCJFWZDfVuhtMgBOyQi5P.append([WtDrnpJmwQ37Z2Ae68hu4BY5M1,start+l4DS8mnEjHhFMZ5YOe(u"ࠩ࠲ࠫ࣬")+vBuLTz940FAONjwtJXQfKEmIo+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪ࠳࣭ࠬ")+end])
			rU02bCJFWZDfVuhtMgBOyQi5P.append([yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠺গ"),start+z3sIGH8jmLYg(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱࣮ࠬ")+vBuLTz940FAONjwtJXQfKEmIo+SSvu1CZjTW7FcloNqD(u"ࠬ࠵࣯ࠧ")+end])
			if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([UpQ56M0dO1N9xIvVegy(u"࠼ঘ"),start+DJ6ugPjW9bX8I(u"࠭࠯ࠨࣰ")+vBuLTz940FAONjwtJXQfKEmIo+l4DS8mnEjHhFMZ5YOe(u"ࠧ࠰ࡧࡰࡦࡪࡪ࠭ࠨࣱ")+end])
		elif IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࠰࡫ࡸࡲࡲࣲࠧ") in end:
			Q0eURSFfNkpj6d8aGXLy9 = end.replace(YayJj10OGl(u"ࠩ࠱࡬ࡹࡳ࡬ࠨࣳ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			rU02bCJFWZDfVuhtMgBOyQi5P.append([YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠷ঙ"),start+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࠳ࠬࣴ")+OlW8q2s4Uv0dXphEGnuc+tM24jD1gO0(u"ࠫ࠴࠭ࣵ")+Q0eURSFfNkpj6d8aGXLy9])
			if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠹চ"),start+IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲ࣶ࠭")+OlW8q2s4Uv0dXphEGnuc+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭࠯ࠨࣷ")+Q0eURSFfNkpj6d8aGXLy9])
			rU02bCJFWZDfVuhtMgBOyQi5P.append([SSvu1CZjTW7FcloNqD(u"࠻ছ"),start+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠧ࠰ࠩࣸ")+OlW8q2s4Uv0dXphEGnuc+DJ6ugPjW9bX8I(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࣹࠩ")+Q0eURSFfNkpj6d8aGXLy9])
		else:
			if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([UpQ56M0dO1N9xIvVegy(u"࠴࠴জ"),start+bnI4kmPtrW7yFEhljXOCq9(u"ࠩ࠲ࣺࠫ")+OlW8q2s4Uv0dXphEGnuc+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪ࠲࡭ࡺ࡭࡭ࠩࣻ")])
			if not EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D: rU02bCJFWZDfVuhtMgBOyQi5P.append([q4izXt0sjIQSZcHVAf3EmKRbx(u"࠵࠶ঝ"),start+QlTuvPbSpnjygBVW(u"ࠫ࠴࡫࡭ࡣࡧࡧ࠱ࠬࣼ")+OlW8q2s4Uv0dXphEGnuc+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬ࠴ࡨࡵ࡯࡯ࠫࣽ")])
			if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠶࠸ঞ"),start+UpQ56M0dO1N9xIvVegy(u"࠭࠯ࠨࣾ")+OlW8q2s4Uv0dXphEGnuc+l4DS8mnEjHhFMZ5YOe(u"ࠧ࠰ࠩࣿ")+end+IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࠰࡫ࡸࡲࡲࠧऀ")])
			if end: rU02bCJFWZDfVuhtMgBOyQi5P.append([flDSRbv57PnV3(u"࠷࠳ট"),start+DJ6ugPjW9bX8I(u"ࠩ࠲ࠫँ")+OlW8q2s4Uv0dXphEGnuc+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪ࠳ࡪࡳࡢࡦࡦ࠰ࠫं")+end+DJ6ugPjW9bX8I(u"ࠫ࠳࡮ࡴ࡮࡮ࠪः")])
		if EXwMuBqxVJcj4dZmTYvtN2aAhy1K8D and end:
			end = end.replace(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ऄ"),l4DS8mnEjHhFMZ5YOe(u"࠭࠯ࠨअ"))
			rU02bCJFWZDfVuhtMgBOyQi5P.append([t4txivgXSUWBOlCakQmNDjf(u"࠱࠵ঠ"),start+bYyKEjIuGQzoq3AR1(u"ࠧ࠰ࠩआ")+end])
			rU02bCJFWZDfVuhtMgBOyQi5P.append([I3cxjYaHhsrM7T4UX26klN(u"࠲࠷ড"),start+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩइ")+end])
			if tM24jD1gO0(u"ࠩ࠱࡬ࡹࡳ࡬ࠨई") in end:
				Q0eURSFfNkpj6d8aGXLy9 = end.replace(tM24jD1gO0(u"ࠪ࠲࡭ࡺ࡭࡭ࠩउ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
				rU02bCJFWZDfVuhtMgBOyQi5P.append([X1mRwt2YJKgCLu9a67(u"࠳࠹ঢ"),start+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫ࠴࠭ऊ")+Q0eURSFfNkpj6d8aGXLy9])
				rU02bCJFWZDfVuhtMgBOyQi5P.append([I3cxjYaHhsrM7T4UX26klN(u"࠴࠻ণ"),start+z3sIGH8jmLYg(u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠲࠭ऋ")+Q0eURSFfNkpj6d8aGXLy9])
			else:
				rU02bCJFWZDfVuhtMgBOyQi5P.append([X1mRwt2YJKgCLu9a67(u"࠵࠽ত"),start+YayJj10OGl(u"࠭࠯ࠨऌ")+end+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧ࠯ࡪࡷࡱࡱ࠭ऍ")])
				rU02bCJFWZDfVuhtMgBOyQi5P.append([flDSRbv57PnV3(u"࠶࠿থ"),start+I3cxjYaHhsrM7T4UX26klN(u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠮ࠩऎ")+end+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩ࠱࡬ࡹࡳ࡬ࠨए")])
		zZNIMUtsJnb4jBd0D9xeL6E1 = []
		for vLrxHDuiN08ba5pRlmUtMAIyfZX,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P[vkIa3ijEQVsJGdWOXwK7bnue9ADR:]:
			TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+vLrxHDuiN08ba5pRlmUtMAIyfZX] = [None,None,None,None]
			dAOvH3jPyxaCz9RJMN0e4omn = eb6R0h1Fjl.Thread(target=WkwY2x9TIB3KStndH1Nr,args=(y4XA5wJqRVjDn2h8oTcOHlv+vLrxHDuiN08ba5pRlmUtMAIyfZX,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6))
			dAOvH3jPyxaCz9RJMN0e4omn.start()
			zZNIMUtsJnb4jBd0D9xeL6E1.append(dAOvH3jPyxaCz9RJMN0e4omn)
			lQMuw1PvVpAk.sleep(t4txivgXSUWBOlCakQmNDjf(u"࠶࠮࠸࠷দ"))
		for dAOvH3jPyxaCz9RJMN0e4omn in zZNIMUtsJnb4jBd0D9xeL6E1: dAOvH3jPyxaCz9RJMN0e4omn.join(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠱࠱ধ"))
	uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = nbOFVEDkpT4BIR7Qq82yPmHeJU,[],[]
	dN1ZYJmcsVKHnQLIp9MC = []
	for vLrxHDuiN08ba5pRlmUtMAIyfZX,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P:
		dkAb0HvoiPDgtrx3zGW8y,LuKM3QHIBwYDmfpRU0xn,wx9qKZ7TVArpioQJm4lM2,KmCMIQNbevOR5j7w8slruxFP0Jh2Yq = TTSJVE8yXumW[y4XA5wJqRVjDn2h8oTcOHlv+vLrxHDuiN08ba5pRlmUtMAIyfZX]
		if not lPpY5fw3tOBcEye91Caun2FQZ and wx9qKZ7TVArpioQJm4lM2: bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = LuKM3QHIBwYDmfpRU0xn,wx9qKZ7TVArpioQJm4lM2
		if not uusxjPSpV5c and dkAb0HvoiPDgtrx3zGW8y: uusxjPSpV5c = dkAb0HvoiPDgtrx3zGW8y
		if KmCMIQNbevOR5j7w8slruxFP0Jh2Yq: dN1ZYJmcsVKHnQLIp9MC.append(KmCMIQNbevOR5j7w8slruxFP0Jh2Yq)
	dN1ZYJmcsVKHnQLIp9MC = list(set(dN1ZYJmcsVKHnQLIp9MC))
	if not uusxjPSpV5c and len(dN1ZYJmcsVKHnQLIp9MC)==IINBvuxkCSJrO1Q0UyngdLi(u"࠲ন"):
		kHY0cteDy7dL9sU2n = dN1ZYJmcsVKHnQLIp9MC[f4fTutDOEwUeIoPLRQ]
		if kHY0cteDy7dL9sU2n!=z3sIGH8jmLYg(u"࠴࠳࠴঩"):
			if kHY0cteDy7dL9sU2n<f4fTutDOEwUeIoPLRQ: uusxjPSpV5c = X60YQOADpkHBb31LiR5qUEKfM(u"࡚ࠪ࡮ࡪࡥࡰࠢࡳࡥ࡬࡫࠯ࡴࡧࡵࡺࡪࡸࠠࡪࡵࠣࡲࡴࡺࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡮ࡨࠫऐ")
			else:
				uusxjPSpV5c = flDSRbv57PnV3(u"ࠫࡍ࡚ࡔࡑࠢࡈࡶࡷࡵࡲ࠻ࠢࠪऑ")+str(kHY0cteDy7dL9sU2n)
				if IZhXMprxvAHqBEFkg0: import http.client as dJujeXC2cbflp6Dm08o
				else: import httplib as dJujeXC2cbflp6Dm08o
				try: uusxjPSpV5c += flDSRbv57PnV3(u"ࠬࠦࠨࠡࠩऒ")+dJujeXC2cbflp6Dm08o.responses[kHY0cteDy7dL9sU2n]+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࠠࠪࠩओ")
				except: pass
	lQMuw1PvVpAk.sleep(vkIa3ijEQVsJGdWOXwK7bnue9ADR)
	return uusxjPSpV5c,bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ
class VVkiAZNDbfMq0FdHhCOL4KYm67SsG(LAkCFq8ezcf.WindowDialog):
	def __init__(UQtCpi5bgMm8n4, *args, **Ax9XPbS0kZw):
		muyTl76YbrqANX5EMHKzOVIoj2ekdg = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪऔ"), UpQ56M0dO1N9xIvVegy(u"ࠨࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠶ࠬक"), wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩࡧ࡭ࡦࡲ࡯ࡨࡤࡪ࠲ࡵࡴࡧࠨख"))
		ssr1CYDEJd5Uvzj = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, t4txivgXSUWBOlCakQmNDjf(u"ࠪࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠭ग"), paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠲ࠨघ"), wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡹࡥ࡭ࡧࡦࡸࡪࡪ࠮ࡱࡰࡪࠫङ"))
		TfLMtbAGKIQoqxZri6Y = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩच"), DJ6ugPjW9bX8I(u"ࠧࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠵ࠫछ"), YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡤࡸࡸࡹࡵ࡮ࡧࡱ࠱ࡴࡳ࡭ࠧज"))
		NNmnElrFY0avOtfVPdbC8 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, tM24jD1gO0(u"ࠩࡵࡩࡸࡵࡵࡳࡥࡨࡷࠬझ"), O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠸ࠧञ"), qrjy8LuKVPNYdbSvzh(u"ࠫࡧࡻࡴࡵࡱࡱࡲ࡫࠴ࡰ࡯ࡩࠪट"))
		prfa84bZTWomA175zsHXDEveVQROGJ = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx, I3cxjYaHhsrM7T4UX26klN(u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨठ"), yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠴ࠪड"), DJ6ugPjW9bX8I(u"ࠧࡣࡷࡷࡸࡴࡴࡢࡨ࠰ࡳࡲ࡬࠭ढ"))
		UQtCpi5bgMm8n4.cancelled = SmbNGskjMx
		UQtCpi5bgMm8n4.chk = [f4fTutDOEwUeIoPLRQ] * flDSRbv57PnV3(u"࠼প")
		UQtCpi5bgMm8n4.chkbutton = [f4fTutDOEwUeIoPLRQ] * Fo1SgXMsHk(u"࠽ফ")
		UQtCpi5bgMm8n4.chkstate = [SmbNGskjMx] * QlTuvPbSpnjygBVW(u"࠾ব")
		jGY5V06LUPM8, qu8LAThYsJ0cwfQ4XgGyNzlZk17UD, v6YAteBTcgF03Eb8UHdD, wf7MzlvOPipHXGKVSsd = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠸࠵࠱ভ"), f4fTutDOEwUeIoPLRQ, O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠷࠱࠲ম"), DJ6ugPjW9bX8I(u"࠸࠸࠳য")
		BpW0u5DfC2Fi1YGkRabOVPJdt4 = jGY5V06LUPM8+v6YAteBTcgF03Eb8UHdD//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		YeCSlLuX7GO2d, oHNcbMGArdm1jkDJgz, Jh68pGi2P3Kr0XwZVl79nbYUuy, awcQx9A3mogIuRJNKSz2tFYEZe = ulAxHwvzR9eTb5n(u"࠶࠹࠺঱"), tM24jD1gO0(u"࠳࠵࠴র"), UpQ56M0dO1N9xIvVegy(u"࠹࠵࠶ল"), UpQ56M0dO1N9xIvVegy(u"࠹࠵࠶ল")
		nVemxZHP4cBoXJKuRwrDI7MCisq = YeCSlLuX7GO2d+Jh68pGi2P3Kr0XwZVl79nbYUuy//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		TD0HN5Ztsa7hOC1GoMjIe8uvUyBJ, Va7hxpjtCY0523fR8un, CO2wYaGmTrJ8E3bgBdsyF1Z9M, XsmgkdiKFP = X60YQOADpkHBb31LiR5qUEKfM(u"࠷࠰࠱঴"), xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠶࠶࠷঵"), DJ6ugPjW9bX8I(u"࠶࠻࠰঳"), bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠶࠲শ")
		xxgLUpGBN9FneHE = BpW0u5DfC2Fi1YGkRabOVPJdt4-CO2wYaGmTrJ8E3bgBdsyF1Z9M-TD0HN5Ztsa7hOC1GoMjIe8uvUyBJ//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		CGW1v3hgAXat8UlfZDp6qc = BpW0u5DfC2Fi1YGkRabOVPJdt4+TD0HN5Ztsa7hOC1GoMjIe8uvUyBJ//QQSugEIn2mTCpRsfcaJHhPdAWzylM
		GUSanVfWzrJcvkD8l1t7, kMxyQdPFgcfB2l, DPFzS3B8mY6T1yd2U7ZX5VbxEI, U5mJarh6u4WCEg2SMikTcQGAyB3 = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠵࠸࠹ষ"), yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠶࠴স"), qrjy8LuKVPNYdbSvzh(u"࠺࠶࠰঺"), DJ6ugPjW9bX8I(u"࠹࠵হ")
		Twi4b1BJDpPHC, JwHQOe5ifPVu0YXkrZTI2bd, qqxN5GwiQbp7yY9kocsZvXFCzK2M, xCS1E7gQHjacbOXq8wk3UM6B0s = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠹࠵࠶঻"), SSvu1CZjTW7FcloNqD(u"࠹࠳া"), Fo1SgXMsHk(u"࠶࠲࠳ঽ"), CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠵࠱়")
		LkcvQfVD3Cg649mpsTPq5uetijXz = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠳࠲࠾ি")
		jGY5V06LUPM8, qu8LAThYsJ0cwfQ4XgGyNzlZk17UD, v6YAteBTcgF03Eb8UHdD, wf7MzlvOPipHXGKVSsd = int(jGY5V06LUPM8*LkcvQfVD3Cg649mpsTPq5uetijXz), int(qu8LAThYsJ0cwfQ4XgGyNzlZk17UD*LkcvQfVD3Cg649mpsTPq5uetijXz), int(v6YAteBTcgF03Eb8UHdD*LkcvQfVD3Cg649mpsTPq5uetijXz), int(wf7MzlvOPipHXGKVSsd*LkcvQfVD3Cg649mpsTPq5uetijXz)
		YeCSlLuX7GO2d, oHNcbMGArdm1jkDJgz, Jh68pGi2P3Kr0XwZVl79nbYUuy, awcQx9A3mogIuRJNKSz2tFYEZe = int(YeCSlLuX7GO2d*LkcvQfVD3Cg649mpsTPq5uetijXz), int(oHNcbMGArdm1jkDJgz*LkcvQfVD3Cg649mpsTPq5uetijXz), int(Jh68pGi2P3Kr0XwZVl79nbYUuy*LkcvQfVD3Cg649mpsTPq5uetijXz), int(awcQx9A3mogIuRJNKSz2tFYEZe*LkcvQfVD3Cg649mpsTPq5uetijXz)
		xxgLUpGBN9FneHE, oMg7KC5OyQSIHNfGnbEmdla2e, Bn8HzhpZOfdwYWS, upxFnvOysPVSoTfKtIWQMEbU = int(xxgLUpGBN9FneHE*LkcvQfVD3Cg649mpsTPq5uetijXz), int(Va7hxpjtCY0523fR8un*LkcvQfVD3Cg649mpsTPq5uetijXz), int(CO2wYaGmTrJ8E3bgBdsyF1Z9M*LkcvQfVD3Cg649mpsTPq5uetijXz), int(XsmgkdiKFP*LkcvQfVD3Cg649mpsTPq5uetijXz)
		CGW1v3hgAXat8UlfZDp6qc, fk4CR5mJdZ2Oy3eKxMEGDNYtAscb8, AoNr1RqcLX3MOZF, BH85UsautCm62T93OkXYnEcI = int(CGW1v3hgAXat8UlfZDp6qc*LkcvQfVD3Cg649mpsTPq5uetijXz), int(Va7hxpjtCY0523fR8un*LkcvQfVD3Cg649mpsTPq5uetijXz), int(CO2wYaGmTrJ8E3bgBdsyF1Z9M*LkcvQfVD3Cg649mpsTPq5uetijXz), int(XsmgkdiKFP*LkcvQfVD3Cg649mpsTPq5uetijXz)
		GUSanVfWzrJcvkD8l1t7, kMxyQdPFgcfB2l, DPFzS3B8mY6T1yd2U7ZX5VbxEI, U5mJarh6u4WCEg2SMikTcQGAyB3 = int(GUSanVfWzrJcvkD8l1t7*LkcvQfVD3Cg649mpsTPq5uetijXz), int(kMxyQdPFgcfB2l*LkcvQfVD3Cg649mpsTPq5uetijXz), int(DPFzS3B8mY6T1yd2U7ZX5VbxEI*LkcvQfVD3Cg649mpsTPq5uetijXz), int(U5mJarh6u4WCEg2SMikTcQGAyB3*LkcvQfVD3Cg649mpsTPq5uetijXz)
		Twi4b1BJDpPHC, JwHQOe5ifPVu0YXkrZTI2bd, qqxN5GwiQbp7yY9kocsZvXFCzK2M, xCS1E7gQHjacbOXq8wk3UM6B0s = int(Twi4b1BJDpPHC*LkcvQfVD3Cg649mpsTPq5uetijXz), int(JwHQOe5ifPVu0YXkrZTI2bd*LkcvQfVD3Cg649mpsTPq5uetijXz), int(qqxN5GwiQbp7yY9kocsZvXFCzK2M*LkcvQfVD3Cg649mpsTPq5uetijXz), int(xCS1E7gQHjacbOXq8wk3UM6B0s*LkcvQfVD3Cg649mpsTPq5uetijXz)
		xQYui3Cs7JGDv9UgWeEAZ4BSX6 = LAkCFq8ezcf.ControlImage(jGY5V06LUPM8, qu8LAThYsJ0cwfQ4XgGyNzlZk17UD, v6YAteBTcgF03Eb8UHdD, wf7MzlvOPipHXGKVSsd, muyTl76YbrqANX5EMHKzOVIoj2ekdg)
		UQtCpi5bgMm8n4.addControl(xQYui3Cs7JGDv9UgWeEAZ4BSX6)
		UQtCpi5bgMm8n4.iteration = Ax9XPbS0kZw.get(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨ࡫ࡷࡩࡷࡧࡴࡪࡱࡱࠫण"))
		II0B1Fd2tXH34iKc = l5JG7XwbOfo8DznU+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩไัฺࠦร็ษࠣษู๋ว็ุ๋่ࠢะࠠา๊ห์ฯࠦࠠࠡࠢࠣࠤࠥࠦࠠࠨत")+l4DS8mnEjHhFMZ5YOe(u"ࠪห้๋อศ๊็อࠥืโๆࠢࠣࠫथ")+str(UQtCpi5bgMm8n4.iteration)+c7gxFyUCGm
		UQtCpi5bgMm8n4.strActionInfo = LAkCFq8ezcf.ControlLabel(GUSanVfWzrJcvkD8l1t7, kMxyQdPFgcfB2l, DPFzS3B8mY6T1yd2U7ZX5VbxEI, U5mJarh6u4WCEg2SMikTcQGAyB3, II0B1Fd2tXH34iKc, z3sIGH8jmLYg(u"ࠫ࡫ࡵ࡮ࡵ࠳࠶ࠫद"))
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.strActionInfo)
		X79kphTKa1xLP = LAkCFq8ezcf.ControlImage(YeCSlLuX7GO2d, oHNcbMGArdm1jkDJgz, Jh68pGi2P3Kr0XwZVl79nbYUuy, awcQx9A3mogIuRJNKSz2tFYEZe, Ax9XPbS0kZw.get(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡩࡡࡱࡶࡦ࡬ࡦ࠭ध")))
		UQtCpi5bgMm8n4.addControl(X79kphTKa1xLP)
		KQh3XHCco9LfvBkyrEGdiIFw7g4s = l5JG7XwbOfo8DznU+Ax9XPbS0kZw.get(flDSRbv57PnV3(u"࠭࡭ࡴࡩࠪन"))+c7gxFyUCGm
		UQtCpi5bgMm8n4.strActionInfo = LAkCFq8ezcf.ControlLabel(Twi4b1BJDpPHC, JwHQOe5ifPVu0YXkrZTI2bd, qqxN5GwiQbp7yY9kocsZvXFCzK2M, xCS1E7gQHjacbOXq8wk3UM6B0s, KQh3XHCco9LfvBkyrEGdiIFw7g4s, UpQ56M0dO1N9xIvVegy(u"ࠧࡧࡱࡱࡸ࠶࠹ࠧऩ"))
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.strActionInfo)
		text = l5JG7XwbOfo8DznU+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨะิ์ั࠭प")+c7gxFyUCGm
		UQtCpi5bgMm8n4.cancelbutton = LAkCFq8ezcf.ControlButton(xxgLUpGBN9FneHE, oMg7KC5OyQSIHNfGnbEmdla2e, Bn8HzhpZOfdwYWS, upxFnvOysPVSoTfKtIWQMEbU, text, focusTexture=prfa84bZTWomA175zsHXDEveVQROGJ, noFocusTexture=TfLMtbAGKIQoqxZri6Y, alignment=SSvu1CZjTW7FcloNqD(u"࠶ী"))
		text = l5JG7XwbOfo8DznU+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩสืฯ๋ัศำࠪफ")+c7gxFyUCGm
		UQtCpi5bgMm8n4.okbutton = LAkCFq8ezcf.ControlButton(CGW1v3hgAXat8UlfZDp6qc, fk4CR5mJdZ2Oy3eKxMEGDNYtAscb8, AoNr1RqcLX3MOZF, BH85UsautCm62T93OkXYnEcI, text, focusTexture=prfa84bZTWomA175zsHXDEveVQROGJ, noFocusTexture=TfLMtbAGKIQoqxZri6Y, alignment=bYyKEjIuGQzoq3AR1(u"࠷ু"))
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.okbutton)
		UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.cancelbutton)
		GIXzfeDy29mVd853nbEipB7qxsU, AAhcJmMygzDFKXwjQW = awcQx9A3mogIuRJNKSz2tFYEZe//ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb, Jh68pGi2P3Kr0XwZVl79nbYUuy//ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
		for WoEZvMXa0K2suwgPl in range(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠿ূ")):
			vp2GZnO3VDFkKheaRw0JSMgHbYxtjf = WoEZvMXa0K2suwgPl // ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			XwqdSNcBCW5 = WoEZvMXa0K2suwgPl % ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			QwU3ikN1zgdf90 = YeCSlLuX7GO2d + (AAhcJmMygzDFKXwjQW * XwqdSNcBCW5)
			T30bpnQ6gePvY81wlECdZGH2OhMcrk = oHNcbMGArdm1jkDJgz + (GIXzfeDy29mVd853nbEipB7qxsU * vp2GZnO3VDFkKheaRw0JSMgHbYxtjf)
			UQtCpi5bgMm8n4.chk[WoEZvMXa0K2suwgPl] = LAkCFq8ezcf.ControlImage(QwU3ikN1zgdf90, T30bpnQ6gePvY81wlECdZGH2OhMcrk, AAhcJmMygzDFKXwjQW, GIXzfeDy29mVd853nbEipB7qxsU, ssr1CYDEJd5Uvzj)
			UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.chk[WoEZvMXa0K2suwgPl])
			UQtCpi5bgMm8n4.chk[WoEZvMXa0K2suwgPl].setVisible(SmbNGskjMx)
			UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl] = LAkCFq8ezcf.ControlButton(QwU3ikN1zgdf90, T30bpnQ6gePvY81wlECdZGH2OhMcrk, AAhcJmMygzDFKXwjQW, GIXzfeDy29mVd853nbEipB7qxsU, str(WoEZvMXa0K2suwgPl + vkIa3ijEQVsJGdWOXwK7bnue9ADR), font=DJ6ugPjW9bX8I(u"ࠪࡪࡴࡴࡴ࠲࠵ࠪब"), focusTexture=TfLMtbAGKIQoqxZri6Y, noFocusTexture=NNmnElrFY0avOtfVPdbC8)
			UQtCpi5bgMm8n4.addControl(UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl])
		for WoEZvMXa0K2suwgPl in range(qrjy8LuKVPNYdbSvzh(u"࠹ৃ")):
			lcsAIn68dqF = (WoEZvMXa0K2suwgPl // ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb) * ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			uwOvHNnrY7e5V4B680qxkEjF = lcsAIn68dqF + (WoEZvMXa0K2suwgPl + vkIa3ijEQVsJGdWOXwK7bnue9ADR) % ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			xXHc4AVgskuhlBirF6weSCLmWOpJUM = lcsAIn68dqF + (WoEZvMXa0K2suwgPl - vkIa3ijEQVsJGdWOXwK7bnue9ADR) % ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb
			CL3RPwVZ2r = (WoEZvMXa0K2suwgPl - ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb) % usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠺ৄ")
			zcnQadLFWRMDfvl3X8mr9kGh65p1EP = (WoEZvMXa0K2suwgPl + ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb) % tM24jD1gO0(u"࠻৅")
			UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlRight(UQtCpi5bgMm8n4.chkbutton[uwOvHNnrY7e5V4B680qxkEjF])
			UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlLeft(UQtCpi5bgMm8n4.chkbutton[xXHc4AVgskuhlBirF6weSCLmWOpJUM])
			if WoEZvMXa0K2suwgPl <= QQSugEIn2mTCpRsfcaJHhPdAWzylM:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlUp(UQtCpi5bgMm8n4.okbutton)
			else:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlUp(UQtCpi5bgMm8n4.chkbutton[CL3RPwVZ2r])
			if WoEZvMXa0K2suwgPl >= fgv5U2eRVaQqSiuGD(u"࠹৆"):
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlDown(UQtCpi5bgMm8n4.okbutton)
			else:
				UQtCpi5bgMm8n4.chkbutton[WoEZvMXa0K2suwgPl].controlDown(UQtCpi5bgMm8n4.chkbutton[zcnQadLFWRMDfvl3X8mr9kGh65p1EP])
		UQtCpi5bgMm8n4.okbutton.controlLeft(UQtCpi5bgMm8n4.cancelbutton)
		UQtCpi5bgMm8n4.okbutton.controlRight(UQtCpi5bgMm8n4.cancelbutton)
		UQtCpi5bgMm8n4.cancelbutton.controlLeft(UQtCpi5bgMm8n4.okbutton)
		UQtCpi5bgMm8n4.cancelbutton.controlRight(UQtCpi5bgMm8n4.okbutton)
		UQtCpi5bgMm8n4.okbutton.controlDown(UQtCpi5bgMm8n4.chkbutton[QQSugEIn2mTCpRsfcaJHhPdAWzylM])
		UQtCpi5bgMm8n4.okbutton.controlUp(UQtCpi5bgMm8n4.chkbutton[tM24jD1gO0(u"࠼ে")])
		UQtCpi5bgMm8n4.cancelbutton.controlDown(UQtCpi5bgMm8n4.chkbutton[f4fTutDOEwUeIoPLRQ])
		UQtCpi5bgMm8n4.cancelbutton.controlUp(UQtCpi5bgMm8n4.chkbutton[t4txivgXSUWBOlCakQmNDjf(u"࠻ৈ")])
		UQtCpi5bgMm8n4.setFocus(UQtCpi5bgMm8n4.okbutton)
	def get(UQtCpi5bgMm8n4):
		UQtCpi5bgMm8n4.doModal()
		UQtCpi5bgMm8n4.close()
		if not UQtCpi5bgMm8n4.cancelled:
			return [WoEZvMXa0K2suwgPl for WoEZvMXa0K2suwgPl in range(fgv5U2eRVaQqSiuGD(u"࠿৉")) if UQtCpi5bgMm8n4.chkstate[WoEZvMXa0K2suwgPl]]
	def onControl(UQtCpi5bgMm8n4, WcyelmdGqpEXkvM):
		if WcyelmdGqpEXkvM.getId() == UQtCpi5bgMm8n4.okbutton.getId() and any(UQtCpi5bgMm8n4.chkstate):
			UQtCpi5bgMm8n4.close()
		elif WcyelmdGqpEXkvM.getId() == UQtCpi5bgMm8n4.cancelbutton.getId():
			UQtCpi5bgMm8n4.cancelled = Ag9l6cw3EBqP8HsQuGMizfOtr4
			UQtCpi5bgMm8n4.close()
		else:
			NNntz8hA93kG6WqEDb1OUoeFm2fg = WcyelmdGqpEXkvM.getLabel()
			if NNntz8hA93kG6WqEDb1OUoeFm2fg.isnumeric():
				index = int(NNntz8hA93kG6WqEDb1OUoeFm2fg) - vkIa3ijEQVsJGdWOXwK7bnue9ADR
				UQtCpi5bgMm8n4.chkstate[index] = not UQtCpi5bgMm8n4.chkstate[index]
				UQtCpi5bgMm8n4.chk[index].setVisible(UQtCpi5bgMm8n4.chkstate[index])
	def onAction(UQtCpi5bgMm8n4, rOCQ5AYBtjXwExLVlfTo0):
		if rOCQ5AYBtjXwExLVlfTo0 == X60YQOADpkHBb31LiR5qUEKfM(u"࠱࠱৊"):
			UQtCpi5bgMm8n4.cancelled = Ag9l6cw3EBqP8HsQuGMizfOtr4
			UQtCpi5bgMm8n4.close()
def T8124TfgoWpSlNRKOnaIyxLU(key,v7vZOgAQb30LNJljTKuS8Czc16,url):
	headers = {X1mRwt2YJKgCLu9a67(u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬभ"):url,YayJj10OGl(u"ࠬࡇࡣࡤࡧࡳࡸ࠲ࡒࡡ࡯ࡩࡸࡥ࡬࡫ࠧम"):v7vZOgAQb30LNJljTKuS8Czc16}
	EjzbgYNRQiI = ulAxHwvzR9eTb5n(u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠲ࡥࡵ࡯࠯ࡧࡣ࡯ࡰࡧࡧࡣ࡬ࡁ࡮ࡁࠬय")+key
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡈࡇࡗࠫर"),EjzbgYNRQiI,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡋࡔࡠࡔࡈࡇࡆࡖࡔࡄࡊࡄ࠶ࡤ࡚ࡏࡌࡇࡑ࠱࠶ࡹࡴࠨऱ"))
	ffiueHIMq6oQxRpyO1ShacVGL4Pg,iteration = nbOFVEDkpT4BIR7Qq82yPmHeJU,f4fTutDOEwUeIoPLRQ
	while Ag9l6cw3EBqP8HsQuGMizfOtr4:
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		iugaeRtZ5HFw7mJc9AdTbKlLV2 = ScntgdOZCY74vNpXeW5jh8i.findall(bYyKEjIuGQzoq3AR1(u"ࠩࠥࠬ࠴ࡸࡥࡤࡣࡳࡸࡨ࡮ࡡ࠰ࡣࡳ࡭࠷࠵ࡰࡢࡻ࡯ࡳࡦࡪ࡛࡟ࠤࡠ࠯࠮࠭ल"), UTvsQb4HpCP3Aeo2wDZG7X5V)
		iteration += vkIa3ijEQVsJGdWOXwK7bnue9ADR
		message = ScntgdOZCY74vNpXeW5jh8i.findall(X1mRwt2YJKgCLu9a67(u"ࠪࡀࡱࡧࡢࡦ࡮࡞ࡢࡃࡣࠫࡤ࡮ࡤࡷࡸࡃࠢࡧࡤࡦ࠱࡮ࡳࡡࡨࡧࡶࡩࡱ࡫ࡣࡵ࠯ࡰࡩࡸࡹࡡࡨࡧ࠰ࡸࡪࡾࡴࠣ࡝ࡡࡂࡢ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭ࡣࡥࡩࡱࡄࠧळ"), UTvsQb4HpCP3Aeo2wDZG7X5V)
		if not message: message = ScntgdOZCY74vNpXeW5jh8i.findall(UpQ56M0dO1N9xIvVegy(u"ࠫࡁࡪࡩࡷ࡝ࡡࡂࡢ࠱ࡣ࡭ࡣࡶࡷࡂࠨࡦࡣࡥ࠰࡭ࡲࡧࡧࡦࡵࡨࡰࡪࡩࡴ࠮࡯ࡨࡷࡸࡧࡧࡦ࠯ࡨࡶࡷࡵࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧऴ"), UTvsQb4HpCP3Aeo2wDZG7X5V)
		if not message:
			ffiueHIMq6oQxRpyO1ShacVGL4Pg = ScntgdOZCY74vNpXeW5jh8i.findall(z3sIGH8jmLYg(u"ࠬࡸࡥࡢࡦࡲࡲࡱࡿ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧव"), UTvsQb4HpCP3Aeo2wDZG7X5V)[f4fTutDOEwUeIoPLRQ]
			break
		else:
			message = message[f4fTutDOEwUeIoPLRQ]
			iugaeRtZ5HFw7mJc9AdTbKlLV2 = iugaeRtZ5HFw7mJc9AdTbKlLV2[f4fTutDOEwUeIoPLRQ]
		FhZrOPAIwHL58fES = ScntgdOZCY74vNpXeW5jh8i.findall(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࡸࠧ࡯ࡣࡰࡩࡂࠨࡣࠣ࡞ࡶ࠯ࡻࡧ࡬ࡶࡧࡀࠦ࠭ࡡ࡞ࠣ࡟࠮࠭ࠬश"), UTvsQb4HpCP3Aeo2wDZG7X5V)[f4fTutDOEwUeIoPLRQ]
		PBDV6S3uCQ0xRn4Zva = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮ࠧࡶࠫष") % (iugaeRtZ5HFw7mJc9AdTbKlLV2.replace(I3cxjYaHhsrM7T4UX26klN(u"ࠨࠨࡤࡱࡵࡁࠧस"), paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࠩࠫह")))
		message = ScntgdOZCY74vNpXeW5jh8i.sub(t4txivgXSUWBOlCakQmNDjf(u"ࠪࡀ࠴ࡅࠨࡥ࡫ࡹࢀࡸࡺࡲࡰࡰࡪ࠭ࡠࡤ࠾࡞ࠬࡁࠫऺ"), nbOFVEDkpT4BIR7Qq82yPmHeJU, message)
		ukoU35Q42Tg = VVkiAZNDbfMq0FdHhCOL4KYm67SsG(captcha=PBDV6S3uCQ0xRn4Zva, msg=message, iteration=iteration)
		YbXOP8JFs6eUBm2u40IZGvxQpDoLh = ukoU35Q42Tg.get()
		if not YbXOP8JFs6eUBm2u40IZGvxQpDoLh: break
		data = {q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡨ࠭ऻ"): FhZrOPAIwHL58fES, z3sIGH8jmLYg(u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫़ࠧ"): YbXOP8JFs6eUBm2u40IZGvxQpDoLh}
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,flDSRbv57PnV3(u"࠭ࡐࡐࡕࡗࠫऽ"),EjzbgYNRQiI,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡋࡊ࡚࡟ࡓࡇࡆࡅࡕ࡚ࡃࡉࡃ࠵ࡣ࡙ࡕࡋࡆࡐ࠰࠶ࡳࡪࠧा"))
	return ffiueHIMq6oQxRpyO1ShacVGL4Pg
def znSbGIkNEJ7ZoVlFc36KWfr4(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡁࡃࡎࡒࡅࡉ࡙࠭࠲ࡵࡷࠫि"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(bYyKEjIuGQzoq3AR1(u"ࠩࡦࡳࡱࡵࡲ࠾ࠤࡵࡩࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧी"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡡࡪ࡮ࡨࡨࠥࡇࡒࡂࡄࡏࡓࡆࡊࡓࠨु"),[],[]
def H2cJulsEhx35e(url):
	return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
def sRJ3YdvjMGkNV5ECngye(url):
	RWZpkDLtY5Eyb46029MvAKmqBQd8o = url.split(z3sIGH8jmLYg(u"ࠫ࠴࠭ू"))
	ltIOBcugLsVrjU0KT7z6yw = qrjy8LuKVPNYdbSvzh(u"ࠬ࠵ࠧृ").join(RWZpkDLtY5Eyb46029MvAKmqBQd8o[f4fTutDOEwUeIoPLRQ:ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb])
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YayJj10OGl(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡝ࡍࡕࡖ࡙ࡔࡊࡄࡖࡊ࠳࠱ࡴࡶࠪॄ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(bYyKEjIuGQzoq3AR1(u"ࠧࡥ࡮ࡥࡹࡹࡺ࡯࡯࡞ࠪࡠ࠮࠴ࡨࡳࡧࡩࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠠ࡝࠭ࠣࡠ࠭࠮࠮ࠫࡁࠬࠤࡡࠫࠠࠩ࠰࠭ࡃ࠮ࠦ࡜ࠬࠢࠫ࠲࠯ࡅࠩࠡ࡞ࠨࠤ࠭࠴ࠪࡀࠫ࡟࠭ࠥࡢࠫࠡࠤࠫ࠲࠯ࡅࠩࠣࠩॅ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,yWM7n98Pir0vxBftd,EK6mrvAkB1u,xxIYoGMmwBWjXP9gzhuVnTtcpb2rei,VvPDfA8Nm3dXqHK = items[f4fTutDOEwUeIoPLRQ]
		rm5wboALRxF2tlGd = int(OOajAkVTFvBQESqLmURc) % int(yWM7n98Pir0vxBftd) + int(EK6mrvAkB1u) % int(xxIYoGMmwBWjXP9gzhuVnTtcpb2rei)
		url = ltIOBcugLsVrjU0KT7z6yw + HYxdW1nBCSGI + str(rm5wboALRxF2tlGd) + VvPDfA8Nm3dXqHK
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[url]
	else: return usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣ࡞ࡎࡖࡐ࡚ࡕࡋࡅࡗࡋࠧॆ"),[],[]
def eh8ypgHQNvCFilYd9SsIDU1qV(url):
	id = url.split(UpQ56M0dO1N9xIvVegy(u"ࠩ࠲ࠫे"))[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	headers = { q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩै") : O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪॉ") }
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = { I3cxjYaHhsrM7T4UX26klN(u"ࠧ࡯ࡤࠣॊ"):id , IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࡯ࡱࠤो"):I3cxjYaHhsrM7T4UX26klN(u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥ࠴ࠥौ") }
	s0tfc7T2hwBM = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡒࡒࡗ्࡙࠭"), url, iugaeRtZ5HFw7mJc9AdTbKlLV2, headers, nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡐ࠵ࡗࡓࡐࡔࡇࡄ࠮࠳ࡶࡸࠬॎ"))
	if t4txivgXSUWBOlCakQmNDjf(u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬॏ") in list(s0tfc7T2hwBM.headers.keys()): grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = s0tfc7T2hwBM.headers[UpQ56M0dO1N9xIvVegy(u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭ॐ")]
	else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[grwO1UeqkvQBf4tmz0jTx3lEKZWbF6]
	else: return YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡎࡒ࠷࡙ࡕࡒࡏࡂࡆࠪ॑"),[],[]
def hwL6eBCfEiJr0gm7FlI(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡍࡓ࡚ࡖࡍࡋ࡙ࡉ࠲࠷ࡳࡵ॒ࠩ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(bYyKEjIuGQzoq3AR1(u"ࠧ࡮ࡲ࠷࠾ࠥࡢ࡛࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ॓"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return Fo1SgXMsHk(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦ࡛ࠣࡎࡔࡔࡗࡎࡌ࡚ࡊ࠭॔"),[],[]
def YTbE8gRUZxMFfvL2CG(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡄࡊࡌ࡚ࡊ࠳࠱ࡴࡶࠪॕ"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॖ"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		url = url = bYyKEjIuGQzoq3AR1(u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡤࡪ࡬ࡺࡪ࠴࡯ࡳࡩࠪॗ") + items[f4fTutDOEwUeIoPLRQ]
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ url ]
	else: return flDSRbv57PnV3(u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡇࡣ࡬ࡰࡪࡪࠠࡂࡔࡆࡌࡎ࡜ࡅࠨक़"),[],[]
def qfKuU98jkFOdPwv(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧख़"))
	items = ScntgdOZCY74vNpXeW5jh8i.findall(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧग़"),UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items: return nbOFVEDkpT4BIR7Qq82yPmHeJU,[nbOFVEDkpT4BIR7Qq82yPmHeJU],[ items[f4fTutDOEwUeIoPLRQ] ]
	else: return YayJj10OGl(u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡦ࡯࡬ࡦࡦࠣࡉࡘ࡚ࡒࡆࡃࡐࠫज़"),[],[]
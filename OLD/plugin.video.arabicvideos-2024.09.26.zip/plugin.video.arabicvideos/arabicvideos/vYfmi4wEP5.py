# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
import xbmc as RarSo2nTfwU0WEGK,re as ScntgdOZCY74vNpXeW5jh8i,sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW,xbmcaddon as IcJ2vm5AukNS1biO4Z,random as eH7yw1hTGUROK2B4dcP0iEr,os as Yl6SPqWjpxcv9I4fL8ozNtRJUZi1,xbmcvfs as NtJjXky6q1,time as lQMuw1PvVpAk,pickle as xD1O90o6ic,zlib as kunYm8Op3RZMzK9qvUI7QCc4X,xbmcgui as LAkCFq8ezcf,xbmcplugin as WWTzqMo4Osga9iKAnfwJIGRZuk1vNV,sqlite3 as RhNFgjDTM1Zuakqx4K925EiLoAHUcz,traceback as R63P9q5uQMWwtdo81jYg7NZ,threading as eb6R0h1Fjl,hashlib as n5VDNKfZM3l1CQEi29LgdxGJ8,json as eH72MR1wtfuI80myOo4ajgG
import QQ3hd2tR8s
QSJFrwB3dMiyH2mTPKD9a = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡌࡊࡄࡖࡓࡓࡋࠧ१")
nbOFVEDkpT4BIR7Qq82yPmHeJU = bYyKEjIuGQzoq3AR1(u"ࠧࠨ२")
S3X6GcaiExOPtb = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࠢࠪ३")
BhmzEC6OGD7FXZig9Tp5A = S3X6GcaiExOPtb*X1mRwt2YJKgCLu9a67(u"࠴ପ")
PCnucez1ITGQbklj7SoqNtw0O8 = S3X6GcaiExOPtb*cb3rmvAn4wa6lBPz2phOoYqX(u"࠶ଫ")
R4PgzXibOn3f1SxmldrWw8acs2p = S3X6GcaiExOPtb*z3sIGH8jmLYg(u"࠸ବ")
Ag9l6cw3EBqP8HsQuGMizfOtr4 = bYyKEjIuGQzoq3AR1(u"࡚ࡲࡶࡧ୴")
SmbNGskjMx = l4DS8mnEjHhFMZ5YOe(u"ࡆࡢ࡮ࡶࡩ୵")
f4fTutDOEwUeIoPLRQ = QlTuvPbSpnjygBVW(u"࠵ଭ")
vkIa3ijEQVsJGdWOXwK7bnue9ADR = t4txivgXSUWBOlCakQmNDjf(u"࠷ମ")
QQSugEIn2mTCpRsfcaJHhPdAWzylM = DJ6ugPjW9bX8I(u"࠲ଯ")
ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb = t4txivgXSUWBOlCakQmNDjf(u"࠴ର")
WtDrnpJmwQ37Z2Ae68hu4BY5M1 = ulAxHwvzR9eTb5n(u"࠶଱")
eMypvI8XqHjYU02anWD9gsSrkt = tM24jD1gO0(u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡂ࠶࠴ࡉࡡࠬ४")
l5JG7XwbOfo8DznU = CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࠭५")
Tm7XlOI1kSsg5L9Znd3RJVorD = t4txivgXSUWBOlCakQmNDjf(u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌ࠲ࡆࡅࡉ࠶ࡊࡣࠧ६")
fvZik7JRpGy2nlTxAaHzjhueK8 = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆ࠲ࡈ࠸࠵ࡋࡌ࡝ࠨ७")
c7gxFyUCGm = xxtgfCnWOFlo0jTbU3PQI4Dq(u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ८")
zSafwK0sDXdMN5JReniIQmrZxp = bYyKEjIuGQzoq3AR1(u"ࠧࡶࡶࡩ࠼ࠬ९")
IISwOZ2BxkPv3yM = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡐࡒࡘࡎࡉࡅࠨ॰")
Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨॱ")
P5PUfZzwS4OkiaLVMlXDbj = SSvu1CZjTW7FcloNqD(u"ࠪࡉࡗࡘࡏࡓࠩॲ")
xzmAtigc7C6LJF5X = QlTuvPbSpnjygBVW(u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩॳ")
wwOnIucWJj = flDSRbv57PnV3(u"ࠬࡢ࡮ࠨॴ")
FKuOXLZA8PYBc7 = l4DS8mnEjHhFMZ5YOe(u"࠭࡜ࡳࠩॵ")
VK0O2udTgfH8Y3GyvhmqNQZDEx = IcJ2vm5AukNS1biO4Z.Addon().getAddonInfo(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡱࡣࡷ࡬ࠬॶ"))
TYAqaNwJvDEs = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VK0O2udTgfH8Y3GyvhmqNQZDEx,YayJj10OGl(u"ࠨࡲࡤࡧࡰࡧࡧࡦࡵࠪॷ"))
Jg3GROZ80HzMpAfL2DQ4mdYhuW.path.append(TYAqaNwJvDEs)
NZXC8zME6TFkOi0bpKVHLwfJydD4Ue = RarSo2nTfwU0WEGK.getInfoLabel(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠤࡖࡽࡸࡺࡥ࡮࠰ࡅࡹ࡮ࡲࡤࡗࡧࡵࡷ࡮ࡵ࡮ࠣॸ"))
o8MCS3IzmRXdVDB7xg2eiW5baZUn = ScntgdOZCY74vNpXeW5jh8i.findall(X1mRwt2YJKgCLu9a67(u"ࠪࠬࡡࡪ࡜ࡥ࡞࠱ࡠࡩ࠯ࠧॹ"),NZXC8zME6TFkOi0bpKVHLwfJydD4Ue,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
o8MCS3IzmRXdVDB7xg2eiW5baZUn = float(o8MCS3IzmRXdVDB7xg2eiW5baZUn[f4fTutDOEwUeIoPLRQ])
ctOAkqFIl731xdnp2S = RarSo2nTfwU0WEGK.Player
rRoSZPg8iW5NdFXjp = LAkCFq8ezcf.WindowXMLDialog
n7neb9KTv10FcU = o8MCS3IzmRXdVDB7xg2eiW5baZUn<X1mRwt2YJKgCLu9a67(u"࠴࠽ଲ")
IZhXMprxvAHqBEFkg0 = o8MCS3IzmRXdVDB7xg2eiW5baZUn>yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠵࠽࠴࠹࠺ଳ")
if IZhXMprxvAHqBEFkg0:
	y5y9TmIJiKcrafpk2BoD8GtYh1P = RarSo2nTfwU0WEGK.LOGINFO
	AQJdiEVCZaDfh4,dVMZJNUoPLOSp47lkeh6T0W31Gj = ulAxHwvzR9eTb5n(u"ࡹࠬࡢࡵ࠳࠲࠵ࡥࠬॺ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࡺ࠭࡜ࡶ࠴࠳࠶ࡧ࠭ॻ")
	tZVYORmiAq6aSvolPrLJN9uMXGge = NtJjXky6q1.translatePath(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡷࡩࡲࡶࠧॼ"))
	from urllib.parse import unquote as _Z6hV4ykaxJNRU3TCb2Gse
else:
	y5y9TmIJiKcrafpk2BoD8GtYh1P = RarSo2nTfwU0WEGK.LOGNOTICE
	AQJdiEVCZaDfh4,dVMZJNUoPLOSp47lkeh6T0W31Gj = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࡵࠨ࡞ࡸ࠶࠵࠸ࡡࠨॽ").encode(zSafwK0sDXdMN5JReniIQmrZxp),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࡶࠩ࡟ࡹ࠷࠶࠲ࡣࠩॾ").encode(zSafwK0sDXdMN5JReniIQmrZxp)
	tZVYORmiAq6aSvolPrLJN9uMXGge = RarSo2nTfwU0WEGK.translatePath(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡺࡥ࡮ࡲࠪॿ"))
	from urllib import unquote as _Z6hV4ykaxJNRU3TCb2Gse
e5ZzObIAdiPC8u6McDmkofxTW9EVN = q4izXt0sjIQSZcHVAf3EmKRbx(u"࠻࠶଴")
wfVkBtgLUIM3N6Ozy2i5pxlT = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠼࠰ଵ")*e5ZzObIAdiPC8u6McDmkofxTW9EVN
Vs0Rwzrn3cKO5PhLio6Q2e = X1mRwt2YJKgCLu9a67(u"࠲࠵ଶ")*wfVkBtgLUIM3N6Ozy2i5pxlT
nQvjc6VRhSZuF3 = fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠴࠲ଷ")*Vs0Rwzrn3cKO5PhLio6Q2e
zDoPOYNsJg2id1HLnx5bpf = f4fTutDOEwUeIoPLRQ
JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl = IINBvuxkCSJrO1Q0UyngdLi(u"࠵࠳ସ")*e5ZzObIAdiPC8u6McDmkofxTW9EVN
pOLDXnFW5V6cTw7ikm = QQSugEIn2mTCpRsfcaJHhPdAWzylM*wfVkBtgLUIM3N6Ozy2i5pxlT
RRYx6sACloVPr3td95Ej = UpQ56M0dO1N9xIvVegy(u"࠴࠺ହ")*wfVkBtgLUIM3N6Ozy2i5pxlT
mmfpkVtUDjaq86eAuFzE0oxP = ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb*Vs0Rwzrn3cKO5PhLio6Q2e
rXKp4uqLMW3v = X60YQOADpkHBb31LiR5qUEKfM(u"࠷࠵଺")*Vs0Rwzrn3cKO5PhLio6Q2e
p2CSGfkREb6TuDtas9yFPrU1e3NWL7 = I3cxjYaHhsrM7T4UX26klN(u"࠶࠸଻")*nQvjc6VRhSZuF3
gn5pkSvs06TGQdC2YVir38DWf9IM = wfVkBtgLUIM3N6Ozy2i5pxlT
ldJmEsIZY9A4pXStekwNoTV = Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[f4fTutDOEwUeIoPLRQ].split(YayJj10OGl(u"ࠪ࠳ࠬঀ"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
KXth1AHMv64CskLiWESrzuey = int(Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[vkIa3ijEQVsJGdWOXwK7bnue9ADR])
cvU8LCyfWkogjSeF9lHphBdEZnzsmr = Jg3GROZ80HzMpAfL2DQ4mdYhuW.argv[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
GtdFnJyHhE98Wozaj = ldJmEsIZY9A4pXStekwNoTV.split(yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫ࠳࠭ঁ"))[QQSugEIn2mTCpRsfcaJHhPdAWzylM]
JeVILUu027qW = RarSo2nTfwU0WEGK.getInfoLabel(cb3rmvAn4wa6lBPz2phOoYqX(u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡇࡤࡥࡱࡱ࡚ࡪࡸࡳࡪࡱࡱࠬࠬং")+ldJmEsIZY9A4pXStekwNoTV+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࠩࠨঃ"))
iy1kK0BAJVLazhHpnZEqrYt9dOfW = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(tZVYORmiAq6aSvolPrLJN9uMXGge,ldJmEsIZY9A4pXStekwNoTV)
SOEM49TbV0zuQ = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧ࡮ࡣ࡬ࡲࡩࡧࡴࡢ࠰ࡧࡦࠬ঄"))
TTrFaqDzxJOsh90UHIZ5 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࡮ࡤࡷࡹࡼࡩࡥࡧࡲࡷ࠳ࡪࡡࡵࠩঅ"))
sqeRK2tVw8 = int(lQMuw1PvVpAk.time())
llnG7jiQBYKhAeovbT = IcJ2vm5AukNS1biO4Z.Addon(id=ldJmEsIZY9A4pXStekwNoTV)
nBVQ1KsvOAShDJ = llnG7jiQBYKhAeovbT.getSetting(bYyKEjIuGQzoq3AR1(u"ࠩࡤࡺ࠳ࡼࡥࡳࡵ࡬ࡳࡳ࠭আ"))
QQpBeZUlAbNKHfkCDLcqWYzv5 = SmbNGskjMx if nBVQ1KsvOAShDJ==JeVILUu027qW else Ag9l6cw3EBqP8HsQuGMizfOtr4
cUzOMK82o05RpPAfVNqSI6vik3Wxb = SmbNGskjMx
def kJPjYVSCDE2(qxZiT6WJ7sX,XXzySLFH501xlfQG=SSvu1CZjTW7FcloNqD(u"ࠪࡃࠬই")):
	if fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡂ࠭ঈ") in qxZiT6WJ7sX:
		if XXzySLFH501xlfQG in qxZiT6WJ7sX: plSscrVjkRviPwm,TKfRnBsbvJpDUm = qxZiT6WJ7sX.split(XXzySLFH501xlfQG,z3sIGH8jmLYg(u"࠷଼"))
		else: plSscrVjkRviPwm,TKfRnBsbvJpDUm = nbOFVEDkpT4BIR7Qq82yPmHeJU,qxZiT6WJ7sX
		TKfRnBsbvJpDUm = TKfRnBsbvJpDUm.split(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࠬࠧউ"))
		J27qXeRCpsgkEoT9Q0GYS6ct = {}
		for XY3PL2HlGu5ofUtDwna8SCdZrJ in TKfRnBsbvJpDUm:
			SRoElDIz1e9Vu,NiQr7d3XtqRVzaOsxjPJM = XY3PL2HlGu5ofUtDwna8SCdZrJ.split(l4DS8mnEjHhFMZ5YOe(u"࠭࠽ࠨঊ"),I3cxjYaHhsrM7T4UX26klN(u"࠱ଽ"))
			J27qXeRCpsgkEoT9Q0GYS6ct[SRoElDIz1e9Vu] = NiQr7d3XtqRVzaOsxjPJM
	else: plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = qxZiT6WJ7sX,{}
	return plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct
def d7Pcqxem9LyM6WEiIpv(hXFjqduwKEt2TDC):
	PgLjnGiMxZ,HMPtOcVoJiXCu8z0nesDWYkIl9ER,u2w1PEMdeqIl0O74Dm6cN9Q = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	hXFjqduwKEt2TDC = hXFjqduwKEt2TDC.replace(AQJdiEVCZaDfh4,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(dVMZJNUoPLOSp47lkeh6T0W31Gj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠧࠩ࠰ࠬࡠࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆ࠱࠺ࡆ࠵ࡋࡢ࡝ࠩ࡞ࡺࡠࡼࡢࡷࠪࠢ࠮ࡠࡠࡢ࠯ࡄࡑࡏࡓࡗࡢ࡝ࠩ࠰࠭ࡃ࠮ࠪࠧঋ"),hXFjqduwKEt2TDC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if EwNgXqHTSJK6sR9LWrBU3Zh8v: PgLjnGiMxZ,HMPtOcVoJiXCu8z0nesDWYkIl9ER,hXFjqduwKEt2TDC = EwNgXqHTSJK6sR9LWrBU3Zh8v[f4fTutDOEwUeIoPLRQ]
	if PgLjnGiMxZ not in [S3X6GcaiExOPtb,t4txivgXSUWBOlCakQmNDjf(u"ࠨ࠮ࠪঌ"),nbOFVEDkpT4BIR7Qq82yPmHeJU]: u2w1PEMdeqIl0O74Dm6cN9Q = UpQ56M0dO1N9xIvVegy(u"ࠩࡢࡑࡔࡊ࡟ࠨ঍")
	if HMPtOcVoJiXCu8z0nesDWYkIl9ER: HMPtOcVoJiXCu8z0nesDWYkIl9ER = tM24jD1gO0(u"ࠪࡣࠬ঎")+HMPtOcVoJiXCu8z0nesDWYkIl9ER+bYyKEjIuGQzoq3AR1(u"ࠫࡤ࠭এ")
	hXFjqduwKEt2TDC = HMPtOcVoJiXCu8z0nesDWYkIl9ER+u2w1PEMdeqIl0O74Dm6cN9Q+hXFjqduwKEt2TDC
	return hXFjqduwKEt2TDC
def SxN0jnqr3LI(qxZiT6WJ7sX):
	return _Z6hV4ykaxJNRU3TCb2Gse(qxZiT6WJ7sX)
def Xo39wTgh20UdCuxn7qOepyVsYmtPNE(llkwQKReAPIL):
	qnEsVSF5wQetlJUZfMzi = {t4txivgXSUWBOlCakQmNDjf(u"ࠬࡺࡹࡱࡧࠪঐ"):nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭࡭ࡰࡦࡨࠫ঑"):nbOFVEDkpT4BIR7Qq82yPmHeJU,paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡶࡴ࡯ࠫ঒"):nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠨࡶࡨࡼࡹ࠭ও"):nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡳࡥ࡬࡫ࠧঔ"):nbOFVEDkpT4BIR7Qq82yPmHeJU,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡲࡦࡳࡥࠨক"):nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫ࡮ࡳࡡࡨࡧࠪখ"):nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭গ"):nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"࠭ࡩ࡯ࡨࡲࡨ࡮ࡩࡴࠨঘ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
	if xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠧࡀࠩঙ") in llkwQKReAPIL: llkwQKReAPIL = llkwQKReAPIL.split(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࡁࠪচ"),vkIa3ijEQVsJGdWOXwK7bnue9ADR)[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	plSscrVjkRviPwm,GOBqHWMTDoejXR5VFYh6a1Z = kJPjYVSCDE2(llkwQKReAPIL)
	aargs = dict(list(qnEsVSF5wQetlJUZfMzi.items())+list(GOBqHWMTDoejXR5VFYh6a1Z.items()))
	tCwilLAkcIoqr9dWU8zKb1NZfE = aargs[usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠩࡰࡳࡩ࡫ࠧছ")]
	NejxKSt0T53Xf1m = SxN0jnqr3LI(aargs[xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡹࡷࡲࠧজ")])
	EAB9KIghQMmeU437l = SxN0jnqr3LI(aargs[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡹ࡫ࡸࡵࠩঝ")])
	O5CAS4KgWIlUhZE = SxN0jnqr3LI(aargs[bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡶࡡࡨࡧࠪঞ")])
	LmMthlkxdC = SxN0jnqr3LI(aargs[X60YQOADpkHBb31LiR5qUEKfM(u"࠭ࡴࡺࡲࡨࠫট")])
	Z6PkXm3cyrnoWlV4IFBwgev = SxN0jnqr3LI(aargs[YayJj10OGl(u"ࠧ࡯ࡣࡰࡩࠬঠ")])
	P4h6CupRBIlMDW59LEn8QHA = SxN0jnqr3LI(aargs[DJ6ugPjW9bX8I(u"ࠨ࡫ࡰࡥ࡬࡫ࠧড")])
	gnf3wLzsHCFWpQ = aargs[I3cxjYaHhsrM7T4UX26klN(u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪঢ")]
	zJ6NlUaZvdqxh59cYIsRwSCDV = SxN0jnqr3LI(aargs[SSvu1CZjTW7FcloNqD(u"ࠪ࡭ࡳ࡬࡯ࡥ࡫ࡦࡸࠬণ")])
	if zJ6NlUaZvdqxh59cYIsRwSCDV: zJ6NlUaZvdqxh59cYIsRwSCDV = eval(zJ6NlUaZvdqxh59cYIsRwSCDV)
	else: zJ6NlUaZvdqxh59cYIsRwSCDV = {}
	if not tCwilLAkcIoqr9dWU8zKb1NZfE: LmMthlkxdC = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫত") ; tCwilLAkcIoqr9dWU8zKb1NZfE = Fo1SgXMsHk(u"ࠬ࠸࠶࠱ࠩথ")
	return LmMthlkxdC,Z6PkXm3cyrnoWlV4IFBwgev,NejxKSt0T53Xf1m,tCwilLAkcIoqr9dWU8zKb1NZfE,P4h6CupRBIlMDW59LEn8QHA,O5CAS4KgWIlUhZE,EAB9KIghQMmeU437l,gnf3wLzsHCFWpQ,zJ6NlUaZvdqxh59cYIsRwSCDV
def Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a):
	k2C4wuTO95WSqbVLJNcvlz = Jg3GROZ80HzMpAfL2DQ4mdYhuW._getframe(vkIa3ijEQVsJGdWOXwK7bnue9ADR).f_code.co_name
	if not QSJFrwB3dMiyH2mTPKD9a or not k2C4wuTO95WSqbVLJNcvlz or k2C4wuTO95WSqbVLJNcvlz==X1mRwt2YJKgCLu9a67(u"࠭࠼࡮ࡱࡧࡹࡱ࡫࠾ࠨদ"):
		return Fo1SgXMsHk(u"ࠧ࡜ࠢࠪধ")+GtdFnJyHhE98Wozaj.upper()+bnI4kmPtrW7yFEhljXOCq9(u"ࠨ࠯ࠪন")+JeVILUu027qW+X1mRwt2YJKgCLu9a67(u"ࠩ࠰ࠫ঩")+str(o8MCS3IzmRXdVDB7xg2eiW5baZUn)+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࠤࡢ࠭প")
	return usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫ࠳ࡢࡴࠨফ")+k2C4wuTO95WSqbVLJNcvlz
def fGBlEmQTwiAJt7rCYIxyau3jRh(FKMVNCcZqjYvnwHDR2mbU85s4,D3PFE9RevWhwfUxYo51ta):
	if n7neb9KTv10FcU: D3PFE9RevWhwfUxYo51ta = D3PFE9RevWhwfUxYo51ta.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode(zSafwK0sDXdMN5JReniIQmrZxp)
	MXYjRh6SwCED7PvaQr0ldL = y5y9TmIJiKcrafpk2BoD8GtYh1P
	FV968pLETkDJwxhXlye2O5ScH = [nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU]
	if FKMVNCcZqjYvnwHDR2mbU85s4: D3PFE9RevWhwfUxYo51ta = D3PFE9RevWhwfUxYo51ta.replace(l5JG7XwbOfo8DznU,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(eMypvI8XqHjYU02anWD9gsSrkt,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	else: FKMVNCcZqjYvnwHDR2mbU85s4 = IISwOZ2BxkPv3yM
	RMmunYS1LzpDxerUBNwXIW9486O3a,XXzySLFH501xlfQG = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࡢࡴࠨব"),PCnucez1ITGQbklj7SoqNtw0O8
	lc43J2kIQDvNmAgOXHrCGzwEextM = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠶࠵ି")*S3X6GcaiExOPtb if IZhXMprxvAHqBEFkg0 else cb3rmvAn4wa6lBPz2phOoYqX(u"࠴࠳ା")*S3X6GcaiExOPtb
	jxz7enRYvKt8wTPycDXqFglV6br2o = WtDrnpJmwQ37Z2Ae68hu4BY5M1*RMmunYS1LzpDxerUBNwXIW9486O3a
	if D3PFE9RevWhwfUxYo51ta.startswith(DJ6ugPjW9bX8I(u"࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧভ")): D3PFE9RevWhwfUxYo51ta = I3cxjYaHhsrM7T4UX26klN(u"ࠧ࠯࡞ࡷࠫম")+D3PFE9RevWhwfUxYo51ta
	if P5PUfZzwS4OkiaLVMlXDbj in FKMVNCcZqjYvnwHDR2mbU85s4: MXYjRh6SwCED7PvaQr0ldL = RarSo2nTfwU0WEGK.LOGERROR
	if FKMVNCcZqjYvnwHDR2mbU85s4 in [IISwOZ2BxkPv3yM,P5PUfZzwS4OkiaLVMlXDbj]: FV968pLETkDJwxhXlye2O5ScH = [D3PFE9RevWhwfUxYo51ta]
	elif FKMVNCcZqjYvnwHDR2mbU85s4==xzmAtigc7C6LJF5X: FV968pLETkDJwxhXlye2O5ScH = D3PFE9RevWhwfUxYo51ta.split(XXzySLFH501xlfQG)
	elif FKMVNCcZqjYvnwHDR2mbU85s4==Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ:
		DWeKu2Gsi84PbUEfhMwVNjloqg = D3PFE9RevWhwfUxYo51ta.split(XXzySLFH501xlfQG)
		FV968pLETkDJwxhXlye2O5ScH = [DWeKu2Gsi84PbUEfhMwVNjloqg[f4fTutDOEwUeIoPLRQ]]
		for ablZij8g2sVkIB4m1pTKz3qEtx in range(vkIa3ijEQVsJGdWOXwK7bnue9ADR,len(DWeKu2Gsi84PbUEfhMwVNjloqg),QQSugEIn2mTCpRsfcaJHhPdAWzylM):
			try: kkz82bMfyOLhguBZ6i = DWeKu2Gsi84PbUEfhMwVNjloqg[ablZij8g2sVkIB4m1pTKz3qEtx]+XXzySLFH501xlfQG+DWeKu2Gsi84PbUEfhMwVNjloqg[ablZij8g2sVkIB4m1pTKz3qEtx+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠴ୀ")]
			except: kkz82bMfyOLhguBZ6i = DWeKu2Gsi84PbUEfhMwVNjloqg[ablZij8g2sVkIB4m1pTKz3qEtx]
			FV968pLETkDJwxhXlye2O5ScH.append(kkz82bMfyOLhguBZ6i)
	vRiYW2OwoDZLCPpMEHUlkTsy = FV968pLETkDJwxhXlye2O5ScH[f4fTutDOEwUeIoPLRQ]
	for nnOtpcqvi6mCdL5QGgbhwkX9A1Y in FV968pLETkDJwxhXlye2O5ScH[vkIa3ijEQVsJGdWOXwK7bnue9ADR:]:
		if FKMVNCcZqjYvnwHDR2mbU85s4 in [xzmAtigc7C6LJF5X,Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ]: jxz7enRYvKt8wTPycDXqFglV6br2o += RMmunYS1LzpDxerUBNwXIW9486O3a
		vRiYW2OwoDZLCPpMEHUlkTsy += FKuOXLZA8PYBc7+lc43J2kIQDvNmAgOXHrCGzwEextM+jxz7enRYvKt8wTPycDXqFglV6br2o+nnOtpcqvi6mCdL5QGgbhwkX9A1Y
	vRiYW2OwoDZLCPpMEHUlkTsy += qrjy8LuKVPNYdbSvzh(u"ࠨࠢࡢࠫয")
	if YayJj10OGl(u"ࠩࠨࠫর") in vRiYW2OwoDZLCPpMEHUlkTsy: vRiYW2OwoDZLCPpMEHUlkTsy = SxN0jnqr3LI(vRiYW2OwoDZLCPpMEHUlkTsy)
	RarSo2nTfwU0WEGK.log(vRiYW2OwoDZLCPpMEHUlkTsy,level=MXYjRh6SwCED7PvaQr0ldL)
	return
def UOneuCKtT2qLMcGXjDv38Qsgpad1fo(rFHIDgtaQZAb4xn1WEqTvOcMo2):
	IgtL0mb7hnwEpYyuf6KUxXR = RhNFgjDTM1Zuakqx4K925EiLoAHUcz.connect(rFHIDgtaQZAb4xn1WEqTvOcMo2,check_same_thread=ulAxHwvzR9eTb5n(u"ࡇࡣ࡯ࡷࡪ୶"))
	IgtL0mb7hnwEpYyuf6KUxXR.text_factory = str
	yWESdJ2nUj31M8ONktxl4 = IgtL0mb7hnwEpYyuf6KUxXR.cursor()
	r1mCsIl0vEhG7tBH4kxipqN(IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4)
	yWESdJ2nUj31M8ONktxl4.execute(bYyKEjIuGQzoq3AR1(u"ࠪࡔࡗࡇࡇࡎࡃࠣࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡨࡥࡩ࡯ࡦࡨࡼࡂࡴ࡯࠼ࠩ঱"))
	yWESdJ2nUj31M8ONktxl4.execute(tM24jD1gO0(u"ࠫࡕࡘࡁࡈࡏࡄࠤ࡮࡭࡮ࡰࡴࡨࡣࡨ࡮ࡥࡤ࡭ࡢࡧࡴࡴࡳࡵࡴࡤ࡭ࡳࡺࡳ࠾ࡻࡨࡷࡀ࠭ল"))
	yWESdJ2nUj31M8ONktxl4.execute(UpQ56M0dO1N9xIvVegy(u"ࠬࡖࡒࡂࡉࡐࡅࠥࡰ࡯ࡶࡴࡱࡥࡱࡥ࡭ࡰࡦࡨࡁࡔࡌࡆ࠼ࠩ঳"))
	yWESdJ2nUj31M8ONktxl4.execute(X1mRwt2YJKgCLu9a67(u"࠭ࡐࡓࡃࡊࡑࡆࠦࡳࡺࡰࡦ࡬ࡷࡵ࡮ࡰࡷࡶࡁࡔࡌࡆ࠼ࠩ঴"))
	return IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4
def r1mCsIl0vEhG7tBH4kxipqN(IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4):
	V5VsTuKOPYNQvkcX2,timeout = SmbNGskjMx,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠹ୁ")
	LPGRaENriMYjlZX = lQMuw1PvVpAk.time()
	while lQMuw1PvVpAk.time()-LPGRaENriMYjlZX<timeout and not V5VsTuKOPYNQvkcX2:
		try:
			yWESdJ2nUj31M8ONktxl4.execute(ulAxHwvzR9eTb5n(u"ࠧࡃࡇࡊࡍࡓࠦࡉࡎࡏࡈࡈࡎࡇࡔࡆࠢࡗࡖࡆࡔࡓࡂࡅࡗࡍࡔࡔࠠ࠼ࠩ঵"))
			V5VsTuKOPYNQvkcX2 = Ag9l6cw3EBqP8HsQuGMizfOtr4
			IgtL0mb7hnwEpYyuf6KUxXR.commit()
		except: lQMuw1PvVpAk.sleep(YayJj10OGl(u"࠵࠴࠵ୂ"))
	if not V5VsTuKOPYNQvkcX2:
		import RpSbDv2A79
		RpSbDv2A79.aY7RFmnWc5uU9T3Q0Mxq4(wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠨࠩশ"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࠪষ"),DJ6ugPjW9bX8I(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭স"),SSvu1CZjTW7FcloNqD(u"ࠫฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡล้ࠤ๏ูสฯั่ࠤฬ๊ๅๅใࠣห้ิวึࠢหๆฬ฿ฯสࠢห๎ฬ์วห้ࠣ࠲࠳่ࠦิสหࠤ์ึ็ࠡษ็ู้้ไสࠢๅำࠥ๐ใ้่ࠣห้ิั้ฮ้๋ࠣࠦวๅสิ๊ฬ๋ฬࠡสุ์ึฯࠠ฻์ิࠤฺำ๊ฮหࠣࡠࡳࡢ࡮ࠡๆะ่ࠥอไๆึๆ่ฮࠦฬาสࠣษ฼็วยࠢๆ์ิ๐้ࠠว฼หิฯࠠหึ฽๎้ํࠠ࠯࠰ࠣวํࠦฬาสࠣษ฼็วยࠢส่ัํวำ๋ࠢษ฾อฯสࠢอุ฿๐ไ่ࠩহ"))
		AALCX4pzvF8HeuYtoDs7()
	return V5VsTuKOPYNQvkcX2
def r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(rFHIDgtaQZAb4xn1WEqTvOcMo2,cZXwI1vKHebdo4YLDqEfMVzrFW,bbdG2W5SZzaU9,wjWKbLxcZhBynaYE=None):
	qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = mI6nfpFj9qdCi0osvSl(cZXwI1vKHebdo4YLDqEfMVzrFW)
	mK4en38aY2UXly0rzZsoI6vMFQ5b = llnG7jiQBYKhAeovbT.getSetting(flDSRbv57PnV3(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡪࡷࡸࡵࡩࡡࡤࡪࡨࠫ঺"))
	if bbdG2W5SZzaU9 not in [IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡍࡊࡕࡆࡣࡕࡋࡒࡎࠩ঻"),X1mRwt2YJKgCLu9a67(u"ࠧࡈࡎࡒࡆࡆࡒࡓࡆࡃࡕࡇࡍࡥࡓࡑࡎࡌࡘ࡙ࡋࡄࡠࡃࡏࡐ়ࠬ"),ulAxHwvzR9eTb5n(u"ࠨࡉࡏࡓࡇࡇࡌࡔࡇࡄࡖࡈࡎ࡟ࡔࡒࡏࡍ࡙࡚ࡅࡅࡡࡊࡓࡔࡍࡌࡆࠩঽ")] and rFHIDgtaQZAb4xn1WEqTvOcMo2==SOEM49TbV0zuQ and wjWKbLxcZhBynaYE!=fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡖࠫা"):
		if mK4en38aY2UXly0rzZsoI6vMFQ5b==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡗ࡙ࡕࡐࠨি"): return qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC
		FGnvJ1ZOyESbpuerf54w8U = llnG7jiQBYKhAeovbT.getSetting(fgv5U2eRVaQqSiuGD(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨী"))
		if FGnvJ1ZOyESbpuerf54w8U==YayJj10OGl(u"ࠬࡘࡅࡇࡔࡈࡗࡍࡥࡃࡂࡅࡋࡉࠬু"):
			uoxvtFlSXEPnf(rFHIDgtaQZAb4xn1WEqTvOcMo2,bbdG2W5SZzaU9,wjWKbLxcZhBynaYE)
			return qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC
	PPbWNg29UEeX = f4fTutDOEwUeIoPLRQ
	if mK4en38aY2UXly0rzZsoI6vMFQ5b==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠭ࡌࡊࡏࡌࡘࡊࡊࠧূ"): PPbWNg29UEeX = gn5pkSvs06TGQdC2YVir38DWf9IM
	IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4 = UOneuCKtT2qLMcGXjDv38Qsgpad1fo(rFHIDgtaQZAb4xn1WEqTvOcMo2)
	DKI5CWMsJmx19SFvqjedgB = yWESdJ2nUj31M8ONktxl4.execute(X1mRwt2YJKgCLu9a67(u"ࠧࡔࡇࡏࡉࡈ࡚ࠠ࡯ࡣࡰࡩࠥࡌࡒࡐࡏࠣࡷࡶࡲࡩࡵࡧࡢࡱࡦࡹࡴࡦࡴ࡛ࠣࡍࡋࡒࡆࠢࡷࡽࡵ࡫࠽ࠣࡶࡤࡦࡱ࡫ࠢࠡࡃࡑࡈࠥࡴࡡ࡮ࡧࡀࠦࠬৃ")+bbdG2W5SZzaU9+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨࠤࠣ࠿ࠬৄ")).fetchall()
	if DKI5CWMsJmx19SFvqjedgB:
		if PPbWNg29UEeX: yWESdJ2nUj31M8ONktxl4.execute(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ৅")+bbdG2W5SZzaU9+t4txivgXSUWBOlCakQmNDjf(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡂࠬ৆")+str(sqeRK2tVw8+PPbWNg29UEeX)+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࠥࡁࠧে"))
		yWESdJ2nUj31M8ONktxl4.execute(DJ6ugPjW9bX8I(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬৈ")+bbdG2W5SZzaU9+QlTuvPbSpnjygBVW(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡦࡺࡳ࡭ࡷࡿ࠼ࠨ৉")+str(sqeRK2tVw8)+Fo1SgXMsHk(u"ࠧࠡ࠽ࠪ৊"))
		IgtL0mb7hnwEpYyuf6KUxXR.commit()
		if wjWKbLxcZhBynaYE:
			aiU7g2uH6G = (str(wjWKbLxcZhBynaYE),)
			yWESdJ2nUj31M8ONktxl4.execute(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡕࡈࡐࡊࡉࡔࠡࡦࡤࡸࡦࠦࡆࡓࡑࡐࠤࠧ࠭ো")+bbdG2W5SZzaU9+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩৌ"),aiU7g2uH6G)
			vDimntp752hHxBRQSX = yWESdJ2nUj31M8ONktxl4.fetchall()
			if vDimntp752hHxBRQSX:
				try:
					om2lqtcZ5y4j = kunYm8Op3RZMzK9qvUI7QCc4X.decompress(vDimntp752hHxBRQSX[f4fTutDOEwUeIoPLRQ][f4fTutDOEwUeIoPLRQ])
					qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = xD1O90o6ic.loads(om2lqtcZ5y4j)
				except: pass
		else:
			yWESdJ2nUj31M8ONktxl4.execute(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡧࡴࡲࡵ࡮ࡰ࠯ࡨࡦࡺࡡࠡࡈࡕࡓࡒࠦࠢࠨ্")+bbdG2W5SZzaU9+ulAxHwvzR9eTb5n(u"ࠫࠧࠦ࠻ࠨৎ"))
			vDimntp752hHxBRQSX = yWESdJ2nUj31M8ONktxl4.fetchall()
			if vDimntp752hHxBRQSX:
				qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,zBnOCqAIFZ = {},[]
				for Oxec30A6Hhf2zvb,J27qXeRCpsgkEoT9Q0GYS6ct in vDimntp752hHxBRQSX:
					eT40LGftIOPZKAcsU26Mx = kunYm8Op3RZMzK9qvUI7QCc4X.decompress(J27qXeRCpsgkEoT9Q0GYS6ct)
					J27qXeRCpsgkEoT9Q0GYS6ct = xD1O90o6ic.loads(eT40LGftIOPZKAcsU26Mx)
					qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC[Oxec30A6Hhf2zvb] = J27qXeRCpsgkEoT9Q0GYS6ct
					zBnOCqAIFZ.append(Oxec30A6Hhf2zvb)
				if zBnOCqAIFZ:
					qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC[IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡥ࡟ࡔࡇࡔ࡙ࡊࡔࡃࡆࡆࡢࡇࡔࡒࡕࡎࡐࡖࡣࡤ࠭৏")] = zBnOCqAIFZ
					if cZXwI1vKHebdo4YLDqEfMVzrFW==DJ6ugPjW9bX8I(u"࠭࡬ࡪࡵࡷࠫ৐"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = zBnOCqAIFZ
	IgtL0mb7hnwEpYyuf6KUxXR.close()
	return qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC
def z0ht1Nk9DRHx7PAan(rFHIDgtaQZAb4xn1WEqTvOcMo2,bbdG2W5SZzaU9,wjWKbLxcZhBynaYE,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,GNWtbMyP30avIc6Vu,EGBz4fois8UQdI1Ckw=SmbNGskjMx):
	mK4en38aY2UXly0rzZsoI6vMFQ5b = llnG7jiQBYKhAeovbT.getSetting(IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱࡬ࡹࡺࡰࡤࡣࡦ࡬ࡪ࠭৑"))
	if mK4en38aY2UXly0rzZsoI6vMFQ5b==DJ6ugPjW9bX8I(u"ࠨࡎࡌࡑࡎ࡚ࡅࡅࠩ৒") and GNWtbMyP30avIc6Vu>gn5pkSvs06TGQdC2YVir38DWf9IM: GNWtbMyP30avIc6Vu = gn5pkSvs06TGQdC2YVir38DWf9IM
	if EGBz4fois8UQdI1Ckw:
		BfM7ldYzjy5qVPoeJuN2QEpL9,DC7SYfy8Av6BQ9jZTql1cEoI03dFr = [],[]
		for HT4fGXqv8hEcKsJ in range(len(wjWKbLxcZhBynaYE)):
			om2lqtcZ5y4j = xD1O90o6ic.dumps(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC[HT4fGXqv8hEcKsJ])
			a5qNuYMRZKD6pvJkL4bEl13PW8 = kunYm8Op3RZMzK9qvUI7QCc4X.compress(om2lqtcZ5y4j)
			BfM7ldYzjy5qVPoeJuN2QEpL9.append((wjWKbLxcZhBynaYE[HT4fGXqv8hEcKsJ],))
			DC7SYfy8Av6BQ9jZTql1cEoI03dFr.append((GNWtbMyP30avIc6Vu+sqeRK2tVw8,str(wjWKbLxcZhBynaYE[HT4fGXqv8hEcKsJ]),a5qNuYMRZKD6pvJkL4bEl13PW8))
	else:
		om2lqtcZ5y4j = xD1O90o6ic.dumps(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
		sBiuGqU4RcwXgnbAE9D5 = kunYm8Op3RZMzK9qvUI7QCc4X.compress(om2lqtcZ5y4j)
	IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4 = UOneuCKtT2qLMcGXjDv38Qsgpad1fo(rFHIDgtaQZAb4xn1WEqTvOcMo2)
	yWESdJ2nUj31M8ONktxl4.execute(I3cxjYaHhsrM7T4UX26klN(u"ࠩࡅࡉࡌࡏࡎࠡࡋࡐࡑࡊࡊࡉࡂࡖࡈࠤ࡙ࡘࡁࡏࡕࡄࡇ࡙ࡏࡏࡏࠢ࠾ࠫ৓"))
	yWESdJ2nUj31M8ONktxl4.execute(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡇࡗࡋࡁࡕࡇࠣࡘࡆࡈࡌࡆࠢࡌࡊࠥࡔࡏࡕࠢࡈ࡜ࡎ࡙ࡔࡔࠢࠥࠫ৔")+bbdG2W5SZzaU9+t4txivgXSUWBOlCakQmNDjf(u"ࠫࠧࠦࠨࡦࡺࡳ࡭ࡷࡿࠬࡤࡱ࡯ࡹࡲࡴࠬࡥࡣࡷࡥ࠮ࠦ࠻ࠨ৕"))
	if EGBz4fois8UQdI1Ckw:
		yWESdJ2nUj31M8ONktxl4.executemany(I3cxjYaHhsrM7T4UX26klN(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࠦࠬ৖")+bbdG2W5SZzaU9+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࡙࠭ࠢࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭ৗ"),BfM7ldYzjy5qVPoeJuN2QEpL9)
		yWESdJ2nUj31M8ONktxl4.executemany(bnI4kmPtrW7yFEhljXOCq9(u"ࠧࡊࡐࡖࡉࡗ࡚ࠠࡊࡐࡗࡓࠥࠨࠧ৘")+bbdG2W5SZzaU9+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࠤ࡚ࠣࡆࡒࡕࡆࡕࠣࠬࡄ࠲࠿࠭ࡁࠬࠤࡀ࠭৙"),DC7SYfy8Av6BQ9jZTql1cEoI03dFr)
	else:
		if GNWtbMyP30avIc6Vu:
			aiU7g2uH6G = (str(wjWKbLxcZhBynaYE),)
			yWESdJ2nUj31M8ONktxl4.execute(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡇࡉࡑࡋࡔࡆࠢࡉࡖࡔࡓࠠࠣࠩ৚")+bbdG2W5SZzaU9+flDSRbv57PnV3(u"ࠪࠦࠥ࡝ࡈࡆࡔࡈࠤࡨࡵ࡬ࡶ࡯ࡱࠤࡂࠦ࠿ࠡ࠽ࠪ৛"),aiU7g2uH6G)
			aiU7g2uH6G = (GNWtbMyP30avIc6Vu+sqeRK2tVw8,str(wjWKbLxcZhBynaYE),sBiuGqU4RcwXgnbAE9D5)
			yWESdJ2nUj31M8ONktxl4.execute(qrjy8LuKVPNYdbSvzh(u"ࠫࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢࠥࠫড়")+bbdG2W5SZzaU9+fgv5U2eRVaQqSiuGD(u"ࠬࠨࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠩࠡ࠽ࠪঢ়"),aiU7g2uH6G)
		else:
			aiU7g2uH6G = (sBiuGqU4RcwXgnbAE9D5,str(wjWKbLxcZhBynaYE))
			yWESdJ2nUj31M8ONktxl4.execute(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡕࡑࡆࡄࡘࡊࠦࠢࠨ৞")+bbdG2W5SZzaU9+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࠣࠢࡖࡉ࡙ࠦࡤࡢࡶࡤࠤࡂࠦ࠿࡙ࠡࡋࡉࡗࡋࠠࡤࡱ࡯ࡹࡲࡴࠠ࠾ࠢࡂࠤࡀ࠭য়"),aiU7g2uH6G)
	IgtL0mb7hnwEpYyuf6KUxXR.commit()
	IgtL0mb7hnwEpYyuf6KUxXR.close()
	return
def uoxvtFlSXEPnf(rFHIDgtaQZAb4xn1WEqTvOcMo2,bbdG2W5SZzaU9,wjWKbLxcZhBynaYE=None):
	IgtL0mb7hnwEpYyuf6KUxXR,yWESdJ2nUj31M8ONktxl4 = UOneuCKtT2qLMcGXjDv38Qsgpad1fo(rFHIDgtaQZAb4xn1WEqTvOcMo2)
	if wjWKbLxcZhBynaYE==None: yWESdJ2nUj31M8ONktxl4.execute(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡆࡕࡓࡕࠦࡔࡂࡄࡏࡉࠥࡏࡆࠡࡇ࡛ࡍࡘ࡚ࡓࠡࠤࠪৠ")+bbdG2W5SZzaU9+qrjy8LuKVPNYdbSvzh(u"ࠩࠥࠤࡀ࠭ৡ"))
	else:
		DKI5CWMsJmx19SFvqjedgB = yWESdJ2nUj31M8ONktxl4.execute(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠪࡗࡊࡒࡅࡄࡖࠣࡲࡦࡳࡥࠡࡈࡕࡓࡒࠦࡳࡲ࡮࡬ࡸࡪࡥ࡭ࡢࡵࡷࡩࡷࠦࡗࡉࡇࡕࡉࠥࡺࡹࡱࡧࡀࠦࡹࡧࡢ࡭ࡧࠥࠤࡆࡔࡄࠡࡰࡤࡱࡪࡃࠢࠨৢ")+bbdG2W5SZzaU9+t4txivgXSUWBOlCakQmNDjf(u"ࠫࠧࠦ࠻ࠨৣ")).fetchall()
		if DKI5CWMsJmx19SFvqjedgB:
			aiU7g2uH6G = (str(wjWKbLxcZhBynaYE),)
			if O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠬࠫࠧ৤") in wjWKbLxcZhBynaYE: yWESdJ2nUj31M8ONktxl4.execute(q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࠧ࠭৥")+bbdG2W5SZzaU9+UpQ56M0dO1N9xIvVegy(u"࡚ࠧࠣࠢࡌࡊࡘࡅࠡࡥࡲࡰࡺࡳ࡮ࠡ࡮࡬࡯ࡪࠦ࠿ࠡ࠽ࠪ০"),aiU7g2uH6G)
			else: yWESdJ2nUj31M8ONktxl4.execute(SSvu1CZjTW7FcloNqD(u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠢࠨ১")+bbdG2W5SZzaU9+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࠥࠤ࡜ࡎࡅࡓࡇࠣࡧࡴࡲࡵ࡮ࡰࠣࡁࠥࡅࠠ࠼ࠩ২"),aiU7g2uH6G)
	IgtL0mb7hnwEpYyuf6KUxXR.commit()
	IgtL0mb7hnwEpYyuf6KUxXR.close()
	return
class ONElhJ1FvoxSKf6u0B(): pass
class zJpU8hfZnevcG(ONElhJ1FvoxSKf6u0B):
	def __init__(S8GDrz3gxJMeYBF2o4c):
		S8GDrz3gxJMeYBF2o4c.url = nbOFVEDkpT4BIR7Qq82yPmHeJU
		S8GDrz3gxJMeYBF2o4c.code = -bYyKEjIuGQzoq3AR1(u"࠿࠹ୃ")
		S8GDrz3gxJMeYBF2o4c.reason = nbOFVEDkpT4BIR7Qq82yPmHeJU
		S8GDrz3gxJMeYBF2o4c.content = nbOFVEDkpT4BIR7Qq82yPmHeJU
		S8GDrz3gxJMeYBF2o4c.headers = {}
		S8GDrz3gxJMeYBF2o4c.cookies = {}
		S8GDrz3gxJMeYBF2o4c.succeeded = SmbNGskjMx
def mI6nfpFj9qdCi0osvSl(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG):
	if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==QlTuvPbSpnjygBVW(u"ࠪࡨ࡮ࡩࡴࠨ৩"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = {}
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࡱ࡯ࡳࡵࠩ৪"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = []
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==X1mRwt2YJKgCLu9a67(u"ࠬࡺࡵࡱ࡮ࡨࠫ৫"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = ()
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==UpQ56M0dO1N9xIvVegy(u"࠭ࡳࡵࡴࠪ৬"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = nbOFVEDkpT4BIR7Qq82yPmHeJU
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==bYyKEjIuGQzoq3AR1(u"ࠧࡪࡰࡷࠫ৭"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = f4fTutDOEwUeIoPLRQ
	elif vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG==I3cxjYaHhsrM7T4UX26klN(u"ࠨࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ৮"): qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = zJpU8hfZnevcG()
	elif not vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG: qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = None
	else: qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = None
	return qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC
def Bi6UGMYAPubKoXJge23fIw59vqR8d(AUMbZ21E3x):
	aaQYVdzmTc3FxeU2Kb0nlSG8XvR = llnG7jiQBYKhAeovbT.getSetting(bnI4kmPtrW7yFEhljXOCq9(u"ࠩࡤࡺ࠳ࡶࡲࡪࡸࡶ࠵ࠬ৯"))
	F2po8K6YWEensAmrJ = iidHGYjPEW4zU.splitlines()
	lCe6aAbJOKYPNEuL2hUSTjWfs = f4fTutDOEwUeIoPLRQ
	p9JzYBnAtPxg1WHFQ = len(AUMbZ21E3x)
	xTyeo4DVGXrWnNbcBP9YQ = [SmbNGskjMx]*p9JzYBnAtPxg1WHFQ
	for bSY0hc5krQKBdJFAvq in [sqeRK2tVw8,sqeRK2tVw8-pOLDXnFW5V6cTw7ikm]:
		NsKW0untcZC4eyU3fiv5ahg9 = str(bSY0hc5krQKBdJFAvq*tM24jD1gO0(u"࠲࠲࠳࠴࠵࠶࠮࠱୅")/YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠴࠴࠴࠳࠴࠵ୄ"))[f4fTutDOEwUeIoPLRQ:SSvu1CZjTW7FcloNqD(u"࠶୆")]
		if NsKW0untcZC4eyU3fiv5ahg9!=lCe6aAbJOKYPNEuL2hUSTjWfs:
			for ablZij8g2sVkIB4m1pTKz3qEtx in range(p9JzYBnAtPxg1WHFQ):
				if not xTyeo4DVGXrWnNbcBP9YQ[ablZij8g2sVkIB4m1pTKz3qEtx]:
					tQHRqT0iljUbMNeka = SmbNGskjMx
					for hhpqwacIRP in F2po8K6YWEensAmrJ:
						L7lVIjRgqtU5fA2EJOMnoY01T = l4DS8mnEjHhFMZ5YOe(u"ࠪ࡜࠶࠿ࠧৰ")+AUMbZ21E3x[ablZij8g2sVkIB4m1pTKz3qEtx]+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫ࠶࠾࠽ࠨৱ")+hhpqwacIRP[-xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠵࠸େ"):]+JeVILUu027qW+NsKW0untcZC4eyU3fiv5ahg9
						L7lVIjRgqtU5fA2EJOMnoY01T = n5VDNKfZM3l1CQEi29LgdxGJ8.md5(L7lVIjRgqtU5fA2EJOMnoY01T.encode(zSafwK0sDXdMN5JReniIQmrZxp)).hexdigest()[:yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠷࠷ୈ")]
						if L7lVIjRgqtU5fA2EJOMnoY01T in aaQYVdzmTc3FxeU2Kb0nlSG8XvR:
							tQHRqT0iljUbMNeka = Ag9l6cw3EBqP8HsQuGMizfOtr4
							break
					xTyeo4DVGXrWnNbcBP9YQ[ablZij8g2sVkIB4m1pTKz3qEtx] = tQHRqT0iljUbMNeka
		lCe6aAbJOKYPNEuL2hUSTjWfs = NsKW0untcZC4eyU3fiv5ahg9
	return xTyeo4DVGXrWnNbcBP9YQ
class SRlNvD1a03QzgVLxu9nWOPZe5mrwKt(ctOAkqFIl731xdnp2S):
	def __init__(S8GDrz3gxJMeYBF2o4c): pass
	def CuDBaZ3FVPW5wtXgTYqM4Avo(S8GDrz3gxJMeYBF2o4c,qChDrcGZSTBdVEHNko8QM67xUA):
		S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭৲") if QQ3hd2tR8s.F8e4uNA5OfTIHvkg6lCJt2BZ else nbOFVEDkpT4BIR7Qq82yPmHeJU
		S8GDrz3gxJMeYBF2o4c.qChDrcGZSTBdVEHNko8QM67xUA = qChDrcGZSTBdVEHNko8QM67xUA
		if not QQ3hd2tR8s.ggSlJwTytkUHBA2dz:
			import RpSbDv2A79
			RpSbDv2A79.hTxAoj52vsb6Mze9rnmIk7lNJg(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl)
	def onPlayBackStopped(S8GDrz3gxJMeYBF2o4c): S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = X1mRwt2YJKgCLu9a67(u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭৳")
	def onPlayBackError(S8GDrz3gxJMeYBF2o4c): S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = l4DS8mnEjHhFMZ5YOe(u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ৴")
	def onPlayBackEnded(S8GDrz3gxJMeYBF2o4c): S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = SSvu1CZjTW7FcloNqD(u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ৵")
	def onPlayBackStarted(S8GDrz3gxJMeYBF2o4c):
		S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡶࡸࡦࡸࡴࡦࡦࠪ৶")
		w6Sku4nvbLh1 = eb6R0h1Fjl.Thread(target=S8GDrz3gxJMeYBF2o4c.mJsDV41edglUKZ7cBhuvjCE6T9,args=())
		w6Sku4nvbLh1.start()
	def onAVStarted(S8GDrz3gxJMeYBF2o4c):
		if QQ3hd2tR8s.ggSlJwTytkUHBA2dz: S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ৷")
		else: S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = DJ6ugPjW9bX8I(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ৸")
	def mJsDV41edglUKZ7cBhuvjCE6T9(S8GDrz3gxJMeYBF2o4c):
		UUlNOsvLb1(QlTuvPbSpnjygBVW(u"ࠬࡹࡴࡰࡲࠪ৹"))
		WSUFnQTOGaR7cpX = f4fTutDOEwUeIoPLRQ
		while not eval(DJ6ugPjW9bX8I(u"࠭ࡸࡣ࡯ࡦ࠲ࡕࡲࡡࡺࡧࡵࠬ࠮࠴ࡩࡴࡒ࡯ࡥࡾ࡯࡮ࡨࠪࠬࠫ৺"),{fgv5U2eRVaQqSiuGD(u"ࠧࡹࡤࡰࡧࠬ৻"):RarSo2nTfwU0WEGK}) and S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡵࡷࡥࡷࡺࡥࡥࠩৼ"):
			RarSo2nTfwU0WEGK.sleep(I3cxjYaHhsrM7T4UX26klN(u"࠶࠶࠰࠱୉"))
			WSUFnQTOGaR7cpX += vkIa3ijEQVsJGdWOXwK7bnue9ADR
			if WSUFnQTOGaR7cpX>paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠼࠰୊"): return
		if QQ3hd2tR8s.F8e4uNA5OfTIHvkg6lCJt2BZ: S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = ulAxHwvzR9eTb5n(u"ࠩࡥࡰࡴࡩ࡫ࡦࡦࠪ৽")
		elif QQ3hd2tR8s.ggSlJwTytkUHBA2dz: S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡴࡱࡧࡹࡪࡰࡪࠫ৾")
		elif QQ3hd2tR8s.UXlu0f9Szq2MTcEeWrn:
			import RpSbDv2A79
			S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠬ৿")
			Ef8Kqg7eGcQhm3FBYO45p = eb6R0h1Fjl.Thread(target=RpSbDv2A79.FsdxpPBgGZzfntTLWDhlKyM,args=(S8GDrz3gxJMeYBF2o4c.qChDrcGZSTBdVEHNko8QM67xUA,))
			Ef8Kqg7eGcQhm3FBYO45p.start()
			zzhsVo3NUc19A4Y2W8aLti = eb6R0h1Fjl.Thread(target=RpSbDv2A79.nVmGZTU79NByx,args=())
			zzhsVo3NUc19A4Y2W8aLti.start()
		else: S8GDrz3gxJMeYBF2o4c.rwlt36bkKgoFa = z3sIGH8jmLYg(u"ࠬࡨ࡬ࡰࡥ࡮ࡩࡩ࠭਀")
def YKV0oFEMdTCHk9LIg1ptn():
	STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846 = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	HGb6B3gINl5q1 = RarSo2nTfwU0WEGK.getInfoLabel(bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡆࡳ࡫ࡨࡲࡩࡲࡹࡏࡣࡰࡩࠬਁ"))
	try:
		j4MwGxHgzWIA01rVKLQ6dZD5ucX = open(flDSRbv57PnV3(u"ࠧ࠰ࡲࡵࡳࡨ࠵ࡣࡱࡷ࡬ࡲ࡫ࡵࠧਂ"),DJ6ugPjW9bX8I(u"ࠨࡴࡥࠫਃ")).read()
		if IZhXMprxvAHqBEFkg0: j4MwGxHgzWIA01rVKLQ6dZD5ucX = j4MwGxHgzWIA01rVKLQ6dZD5ucX.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		zZjbdFLOVkc6IPUx = ScntgdOZCY74vNpXeW5jh8i.findall(t4txivgXSUWBOlCakQmNDjf(u"ࠩࡖࡩࡷ࡯ࡡ࡭࠰࠭ࡃ࠿ࠦࠨ࠯ࠬࡂ࠭ࠩ࠭਄"),j4MwGxHgzWIA01rVKLQ6dZD5ucX,ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if zZjbdFLOVkc6IPUx: STgYyKVvMdBWUQzrk81fGDRouPj97 = zZjbdFLOVkc6IPUx[f4fTutDOEwUeIoPLRQ]
	except: pass
	try:
		import subprocess as zXDcYJZd2M6rHoqgfu9m
		dEY5LI34ch7nOwNjMyz2m6AaxpeX = zXDcYJZd2M6rHoqgfu9m.Popen(ulAxHwvzR9eTb5n(u"ࠪࡷࡹࡧࡴࠡ࠯ࡦࠤ࡙ࠧࠦࠥࠢࠥࠤ࠴ࡹࡴࡰࡴࡤ࡫ࡪ࠵ࡥ࡮ࡷ࡯ࡥࡹ࡫ࡤ࠰࠲ࠣ࠿ࠥࡹࡴࡢࡶࠣ࠱ࡨ࡚ࠦࠢࠡࠧࠤࠧࠦ࠯ࡷࡣࡵ࠳ࡱࡵࡧࠨਅ"),shell=Ag9l6cw3EBqP8HsQuGMizfOtr4,stdin=zXDcYJZd2M6rHoqgfu9m.PIPE,stdout=zXDcYJZd2M6rHoqgfu9m.PIPE,stderr=zXDcYJZd2M6rHoqgfu9m.PIPE)
		NQgMRfsXOTnyoe4kYrzEW3CGtlHApD = dEY5LI34ch7nOwNjMyz2m6AaxpeX.stdout.read()
		if NQgMRfsXOTnyoe4kYrzEW3CGtlHApD:
			if IZhXMprxvAHqBEFkg0:
				NQgMRfsXOTnyoe4kYrzEW3CGtlHApD = NQgMRfsXOTnyoe4kYrzEW3CGtlHApD.decode(zSafwK0sDXdMN5JReniIQmrZxp,Fo1SgXMsHk(u"ࠫ࡮࡭࡮ࡰࡴࡨࠫਆ"))
			oCtbgBDYUOekV = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬࠦࠨ࡝ࡦࡾ࠵࠵ࢃࠩࠡࠩਇ"),NQgMRfsXOTnyoe4kYrzEW3CGtlHApD,ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
			if oCtbgBDYUOekV: B2ruEDWjYQ846 = min(oCtbgBDYUOekV)
	except: pass
	return HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846
def DD98VLARlydeJU4uYk(Ua7wgPcZqVhynWQTipm=Ag9l6cw3EBqP8HsQuGMizfOtr4,vfRKCxijUVd3zZSLHe4=t4txivgXSUWBOlCakQmNDjf(u"࠳࠳ୋ")):
	xgl1U5GpwjuY9OAJkIn = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if Ua7wgPcZqVhynWQTipm:
		uZwgJV2CpsWIqEOrXj3 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,bYyKEjIuGQzoq3AR1(u"࠭࡬ࡪࡵࡷࠫਈ"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਉ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨࡕࡌࡘࡊ࡙࡟ࡄࡊࡈࡇࡐ࠭ਊ"))
		if uZwgJV2CpsWIqEOrXj3:
			F2po8K6YWEensAmrJ,kpEhTOoIu91c,XYEVAdmi87rtq,PEQlcuJUe7Ca50 = uZwgJV2CpsWIqEOrXj3
			xgl1U5GpwjuY9OAJkIn = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,I3cxjYaHhsrM7T4UX26klN(u"ࠩ࡯࡭ࡸࡺࠧ਋"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠪࡑࡎ࡙ࡃࡠࡒࡈࡖࡒ࠭਌"),Fo1SgXMsHk(u"ࠫࡘࡏࡔࡆࡕࡢ࡚ࡊࡘࡉࡇ࡛ࠪ਍"))
			if xgl1U5GpwjuY9OAJkIn: HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846 = xgl1U5GpwjuY9OAJkIn
			else: HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846 = YKV0oFEMdTCHk9LIg1ptn()
			if (kpEhTOoIu91c,XYEVAdmi87rtq,PEQlcuJUe7Ca50)==(HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846): return wwOnIucWJj.join(F2po8K6YWEensAmrJ)
	if xgl1U5GpwjuY9OAJkIn: HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846 = YKV0oFEMdTCHk9LIg1ptn()
	global QXEFfWTokADhBO2,tJhfKnv1Iy0WsjiLCH62rQkcD8V
	QXEFfWTokADhBO2,tJhfKnv1Iy0WsjiLCH62rQkcD8V,z4zGftS3asc5AVvX8kmBUdMDwpREj = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	vfRKCxijUVd3zZSLHe4 = vfRKCxijUVd3zZSLHe4//QQSugEIn2mTCpRsfcaJHhPdAWzylM
	eb6R0h1Fjl.Thread(target=jjp0Q4wZJhRb).start()
	eb6R0h1Fjl.Thread(target=wioelf7JyS1gUPMvL5).start()
	for HT4fGXqv8hEcKsJ in range(QlTuvPbSpnjygBVW(u"࠲࠲ୌ")):
		lQMuw1PvVpAk.sleep(t4txivgXSUWBOlCakQmNDjf(u"࠲࠱࠹୍"))
		if not z4zGftS3asc5AVvX8kmBUdMDwpREj:
			try:
				cfiGrgOsF8wNYPoIaRW36jECyH = RarSo2nTfwU0WEGK.getInfoLabel(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡔࡥࡵࡹࡲࡶࡰ࠴ࡍࡢࡥࡄࡨࡩࡸࡥࡴࡵࠪ਎"))
				if cfiGrgOsF8wNYPoIaRW36jECyH.count(cb3rmvAn4wa6lBPz2phOoYqX(u"࠭࠺ࠨਏ"))==fgv5U2eRVaQqSiuGD(u"࠹୏") and cfiGrgOsF8wNYPoIaRW36jECyH.count(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧ࠱ࠩਐ"))<DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠼୎"):
					cfiGrgOsF8wNYPoIaRW36jECyH = cfiGrgOsF8wNYPoIaRW36jECyH.lower().replace(DJ6ugPjW9bX8I(u"ࠨ࠼ࠪ਑"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
					z4zGftS3asc5AVvX8kmBUdMDwpREj = str(int(cfiGrgOsF8wNYPoIaRW36jECyH,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠶࠼୐")))
			except: pass
		if QXEFfWTokADhBO2 and tJhfKnv1Iy0WsjiLCH62rQkcD8V and z4zGftS3asc5AVvX8kmBUdMDwpREj: break
	ScyO93wB2mpNPdAkFb = [QXEFfWTokADhBO2,tJhfKnv1Iy0WsjiLCH62rQkcD8V,z4zGftS3asc5AVvX8kmBUdMDwpREj,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩ࠳࠴࠶࠷࠲࠳࠵࠶࠸࠹࠻࠵࠷࠸࠺࠻ࠬ਒")]
	if STgYyKVvMdBWUQzrk81fGDRouPj97 or B2ruEDWjYQ846:
		bbW6oLOyku8zZ4E2cxsJ = [(WtDrnpJmwQ37Z2Ae68hu4BY5M1,STgYyKVvMdBWUQzrk81fGDRouPj97),(fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠻୑"),B2ruEDWjYQ846)]
		for SRoElDIz1e9Vu,NiQr7d3XtqRVzaOsxjPJM in bbW6oLOyku8zZ4E2cxsJ:
			NiQr7d3XtqRVzaOsxjPJM = NiQr7d3XtqRVzaOsxjPJM.strip(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࠴ࠬਓ"))
			if NiQr7d3XtqRVzaOsxjPJM:
				if IZhXMprxvAHqBEFkg0: NiQr7d3XtqRVzaOsxjPJM = NiQr7d3XtqRVzaOsxjPJM.encode(zSafwK0sDXdMN5JReniIQmrZxp)
				NiQr7d3XtqRVzaOsxjPJM = str(int(n5VDNKfZM3l1CQEi29LgdxGJ8.md5(NiQr7d3XtqRVzaOsxjPJM).hexdigest(),QlTuvPbSpnjygBVW(u"࠳࠷୒")))
				BK2D7N0Ooesav3ijf = [int(NiQr7d3XtqRVzaOsxjPJM[zASahvYliyTVbNQnmsRp02BX4F1Pjt:zASahvYliyTVbNQnmsRp02BX4F1Pjt+cb3rmvAn4wa6lBPz2phOoYqX(u"࠳࠸୔")]) for zASahvYliyTVbNQnmsRp02BX4F1Pjt in range(len(NiQr7d3XtqRVzaOsxjPJM)) if zASahvYliyTVbNQnmsRp02BX4F1Pjt%cb3rmvAn4wa6lBPz2phOoYqX(u"࠳࠸୔")==ulAxHwvzR9eTb5n(u"࠱୓")]
				ScyO93wB2mpNPdAkFb[SRoElDIz1e9Vu-vkIa3ijEQVsJGdWOXwK7bnue9ADR] = str(sum(BK2D7N0Ooesav3ijf))
	F2po8K6YWEensAmrJ,vuQKleLx46JRq1dw2ImjgZVtb = [],SmbNGskjMx
	for KKTucVbPHoCiRGLdgXr9ZQapA in range(len(ScyO93wB2mpNPdAkFb)):
		BK2D7N0Ooesav3ijf = ScyO93wB2mpNPdAkFb[KKTucVbPHoCiRGLdgXr9ZQapA]
		if not BK2D7N0Ooesav3ijf: continue
		if vuQKleLx46JRq1dw2ImjgZVtb and BK2D7N0Ooesav3ijf==ScyO93wB2mpNPdAkFb[-vkIa3ijEQVsJGdWOXwK7bnue9ADR]: continue
		vuQKleLx46JRq1dw2ImjgZVtb = Ag9l6cw3EBqP8HsQuGMizfOtr4
		BK2D7N0Ooesav3ijf = QlTuvPbSpnjygBVW(u"ࠫ࠵࠭ਔ")*vfRKCxijUVd3zZSLHe4+BK2D7N0Ooesav3ijf
		BK2D7N0Ooesav3ijf = BK2D7N0Ooesav3ijf[-vfRKCxijUVd3zZSLHe4:]
		NOxaHQYtMPhfCTlW5dJbegu2rwV,kkDvjuF2XrTPnU = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
		gR9juarJQ2KvXs = str(int(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬ࠿ࠧਕ")*(vfRKCxijUVd3zZSLHe4+vkIa3ijEQVsJGdWOXwK7bnue9ADR))-int(BK2D7N0Ooesav3ijf))[-vfRKCxijUVd3zZSLHe4:]
		for ablZij8g2sVkIB4m1pTKz3qEtx in list(range(f4fTutDOEwUeIoPLRQ,vfRKCxijUVd3zZSLHe4,WtDrnpJmwQ37Z2Ae68hu4BY5M1)):
			NOxaHQYtMPhfCTlW5dJbegu2rwV += gR9juarJQ2KvXs[ablZij8g2sVkIB4m1pTKz3qEtx:ablZij8g2sVkIB4m1pTKz3qEtx+WtDrnpJmwQ37Z2Ae68hu4BY5M1]+X1mRwt2YJKgCLu9a67(u"࠭࠭ࠨਖ")
			kkDvjuF2XrTPnU += str(sum(map(int,BK2D7N0Ooesav3ijf[ablZij8g2sVkIB4m1pTKz3qEtx:ablZij8g2sVkIB4m1pTKz3qEtx+WtDrnpJmwQ37Z2Ae68hu4BY5M1]))%bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠴࠴୕"))
		hhpqwacIRP = str(KKTucVbPHoCiRGLdgXr9ZQapA)+NOxaHQYtMPhfCTlW5dJbegu2rwV+kkDvjuF2XrTPnU
		F2po8K6YWEensAmrJ.append(hhpqwacIRP)
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,t4txivgXSUWBOlCakQmNDjf(u"ࠧࡎࡋࡖࡇࡤࡖࡅࡓࡏࠪਗ"),t4txivgXSUWBOlCakQmNDjf(u"ࠨࡕࡌࡘࡊ࡙࡟ࡗࡇࡕࡍࡋ࡟ࠧਘ"),[HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846],RRYx6sACloVPr3td95Ej)
	z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩࡐࡍࡘࡉ࡟ࡑࡇࡕࡑࠬਙ"),flDSRbv57PnV3(u"ࠪࡗࡎ࡚ࡅࡔࡡࡆࡌࡊࡉࡋࠨਚ"),[F2po8K6YWEensAmrJ,HGb6B3gINl5q1,STgYyKVvMdBWUQzrk81fGDRouPj97,B2ruEDWjYQ846],mmfpkVtUDjaq86eAuFzE0oxP)
	return wwOnIucWJj.join(F2po8K6YWEensAmrJ)
def qvUe2bwfQ7sZKV(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,eg6iV4ckQxvTrjWKyBulYR,hhyC3ID85J1uvxjFMi):
	GcYwHSWoQ0Nq8KFfJDdvujZryM = str(ehWfDEbAtMTZaS5x)[f4fTutDOEwUeIoPLRQ:t4txivgXSUWBOlCakQmNDjf(u"࠶࠺࠶ୖ")].replace(wwOnIucWJj,Fo1SgXMsHk(u"ࠫࡡࡢ࡮ࠨਛ")).replace(FKuOXLZA8PYBc7,fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡢ࡜ࡳࠩਜ")).replace(R4PgzXibOn3f1SxmldrWw8acs2p,S3X6GcaiExOPtb).replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb)
	if len(str(ehWfDEbAtMTZaS5x))>wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠷࠻࠰ୗ"): GcYwHSWoQ0Nq8KFfJDdvujZryM = GcYwHSWoQ0Nq8KFfJDdvujZryM+l4DS8mnEjHhFMZ5YOe(u"࠭ࠠ࠯࠰࠱ࠫਝ")
	J27qXeRCpsgkEoT9Q0GYS6ct = str(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)[f4fTutDOEwUeIoPLRQ:O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠸࠵࠱୘")].replace(wwOnIucWJj,cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧ࡝࡞ࡱࠫਞ")).replace(FKuOXLZA8PYBc7,IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࡞࡟ࡶࠬਟ")).replace(R4PgzXibOn3f1SxmldrWw8acs2p,S3X6GcaiExOPtb).replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb)
	if len(str(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC))>xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠲࠶࠲୙"): J27qXeRCpsgkEoT9Q0GYS6ct = J27qXeRCpsgkEoT9Q0GYS6ct+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࠣ࠲࠳࠴ࠧਠ")
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡓࡕࡋࡎࡖࡔࡏࡣࠬਡ")+vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠫࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧਢ")+qxZiT6WJ7sX+z3sIGH8jmLYg(u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧਣ")+eg6iV4ckQxvTrjWKyBulYR+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࠠ࡞ࠢࠣࠤࡒ࡫ࡴࡩࡱࡧ࠾ࠥࡡࠠࠨਤ")+hhyC3ID85J1uvxjFMi+tM24jD1gO0(u"ࠧࠡ࡟ࠣࠤࠥࡎࡥࡢࡦࡨࡶࡸࡀࠠ࡜ࠢࠪਥ")+str(GcYwHSWoQ0Nq8KFfJDdvujZryM)+z3sIGH8jmLYg(u"ࠨࠢࡠࠤࠥࠦࡄࡢࡶࡤ࠾ࠥࡡࠠࠨਦ")+J27qXeRCpsgkEoT9Q0GYS6ct+I3cxjYaHhsrM7T4UX26klN(u"ࠩࠣࡡࠬਧ"))
	return
def jjp0Q4wZJhRb():
	global QXEFfWTokADhBO2
	import getmac82 as ddCUm7F5hzPfxkXl8oGTpWca4L
	try:
		h5azTG7UjSOAwYLFHQbp = ddCUm7F5hzPfxkXl8oGTpWca4L.get_mac_address()
		if h5azTG7UjSOAwYLFHQbp.count(YayJj10OGl(u"ࠪ࠾ࠬਨ"))==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠷୛") and h5azTG7UjSOAwYLFHQbp.count(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫ࠵࠭਩"))<paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠺୚"):
			h5azTG7UjSOAwYLFHQbp = h5azTG7UjSOAwYLFHQbp.lower().replace(Fo1SgXMsHk(u"ࠬࡀࠧਪ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			QXEFfWTokADhBO2 = str(int(h5azTG7UjSOAwYLFHQbp,tM24jD1gO0(u"࠴࠺ଡ଼")))
	except: pass
	return
def wioelf7JyS1gUPMvL5():
	global tJhfKnv1Iy0WsjiLCH62rQkcD8V
	import getmac94 as HLzE8Q4OSrv3jyCthqu
	try:
		zznh4DwXj9mWUiH71CtgV = HLzE8Q4OSrv3jyCthqu.get_mac_address()
		if zznh4DwXj9mWUiH71CtgV.count(I3cxjYaHhsrM7T4UX26klN(u"࠭࠺ࠨਫ"))==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠺୞") and zznh4DwXj9mWUiH71CtgV.count(fgv5U2eRVaQqSiuGD(u"ࠧ࠱ࠩਬ"))<IINBvuxkCSJrO1Q0UyngdLi(u"࠽ଢ଼"):
			zznh4DwXj9mWUiH71CtgV = zznh4DwXj9mWUiH71CtgV.lower().replace(flDSRbv57PnV3(u"ࠨ࠼ࠪਭ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			tJhfKnv1Iy0WsjiLCH62rQkcD8V = str(int(zznh4DwXj9mWUiH71CtgV,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠷࠶ୟ")))
	except: pass
	return
def CyiwT9JuQ2zYSqep618I3FR7G(hhyC3ID85J1uvxjFMi,qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC=nbOFVEDkpT4BIR7Qq82yPmHeJU,ehWfDEbAtMTZaS5x=nbOFVEDkpT4BIR7Qq82yPmHeJU,eg6iV4ckQxvTrjWKyBulYR=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	qvUe2bwfQ7sZKV(SSvu1CZjTW7FcloNqD(u"ࠩࡘࡖࡑࡒࡉࡃ࡞ࡷࡠࡹࡕࡐࡆࡐࡢ࡙ࡗࡒࠧਮ"),qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,eg6iV4ckQxvTrjWKyBulYR,hhyC3ID85J1uvxjFMi)
	if IZhXMprxvAHqBEFkg0: import urllib.request as rQt8SCvXEuFRof52AYM
	else: import urllib2 as rQt8SCvXEuFRof52AYM
	if not ehWfDEbAtMTZaS5x: ehWfDEbAtMTZaS5x = {O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧਯ"):nbOFVEDkpT4BIR7Qq82yPmHeJU}
	if not qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC: qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = {}
	if hhyC3ID85J1uvxjFMi==fgv5U2eRVaQqSiuGD(u"ࠫࡌࡋࡔࠨਰ"):
		qxZiT6WJ7sX = qxZiT6WJ7sX+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠬࡅࠧ਱")+hS5pZyveLR0Ju4EksT2jQ9mrU(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = None
	elif hhyC3ID85J1uvxjFMi==yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ࡐࡐࡕࡗࠫਲ") and bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧ࡫ࡵࡲࡲࠬਲ਼") in str(ehWfDEbAtMTZaS5x):
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = eH72MR1wtfuI80myOo4ajgG.dumps(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = str(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC).encode(zSafwK0sDXdMN5JReniIQmrZxp)
	elif hhyC3ID85J1uvxjFMi==YayJj10OGl(u"ࠨࡒࡒࡗ࡙࠭਴"):
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = hS5pZyveLR0Ju4EksT2jQ9mrU(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
		qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	try:
		cF6Au1LDgzMVZd2NJYeXjqK50k = rQt8SCvXEuFRof52AYM.Request(qxZiT6WJ7sX,headers=ehWfDEbAtMTZaS5x,data=qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
		cA6C7PMTuUklQdfoYqZgXj2FrJN = rQt8SCvXEuFRof52AYM.urlopen(cF6Au1LDgzMVZd2NJYeXjqK50k)
		B69RXYW5vf8Jt7O = cA6C7PMTuUklQdfoYqZgXj2FrJN.read()
		XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv = wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠲࠱࠲ୠ"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡒࡏࠬਵ")
	except:
		B69RXYW5vf8Jt7O = nbOFVEDkpT4BIR7Qq82yPmHeJU
		XqLr3B9MPx,szmD9nEACSWOyk15fPl0QZoTv = -vkIa3ijEQVsJGdWOXwK7bnue9ADR,bYyKEjIuGQzoq3AR1(u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡊࡸࡲࡰࡴࠪਸ਼")
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤ࡛ࡒࡍࡎࡌࡆࡡࡺ࡜ࡵࡔࡈࡗࡕࡕࡎࡔࡇࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭਷")+str(XqLr3B9MPx)+QlTuvPbSpnjygBVW(u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧਸ")+szmD9nEACSWOyk15fPl0QZoTv+bYyKEjIuGQzoq3AR1(u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨਹ")+eg6iV4ckQxvTrjWKyBulYR+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭਺")+qxZiT6WJ7sX+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࠢࡠࠫ਻"))
	if B69RXYW5vf8Jt7O and IZhXMprxvAHqBEFkg0: B69RXYW5vf8Jt7O = B69RXYW5vf8Jt7O.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	return B69RXYW5vf8Jt7O
def ThGYJa4dyjI(ATHfcUgmdRt3ESah5Q4zr9V2X1M):
	Fzo2RlCgrxwv8VyiDeXt5ES4MaBf7G = {
		xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠤࡸࡷࡪࡸ࡟ࡪࡦ਼ࠥ"):FtpGjIPv2H,
		cb3rmvAn4wa6lBPz2phOoYqX(u"ࠥࡳࡸࡥࡶࡦࡴࡶ࡭ࡴࡴࠢ਽"):str(o8MCS3IzmRXdVDB7xg2eiW5baZUn),
		IINBvuxkCSJrO1Q0UyngdLi(u"ࠦࡦࡶࡰࡠࡸࡨࡶࡸ࡯࡯࡯ࠤਾ"):JeVILUu027qW,
		YayJj10OGl(u"ࠧࡪࡥࡷ࡫ࡦࡩࡤ࡬ࡡ࡮࡫࡯ࡽࠧਿ"):JeVILUu027qW,
		tM24jD1gO0(u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣੀ"): JeVILUu027qW,
		CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠢࡤࡣࡵࡶ࡮࡫ࡲࠣੁ"):fgv5U2eRVaQqSiuGD(u"ࠣࡃࡕࡅࡇࡏࡃࡠࡘࡌࡈࡊࡕࡓࠣੂ"),
		fgv5U2eRVaQqSiuGD(u"ࠤ࡬ࡴࠧ੃"): wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠥࠨࡷ࡫࡭ࡰࡶࡨࠦ੄"),
		bnI4kmPtrW7yFEhljXOCq9(u"ࠦࠩࡹ࡫ࡪࡲࡢࡹࡸ࡫ࡲࡠࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࡤࡹࡹ࡯ࡥࠥ੅"):SmbNGskjMx
	}
	sE9a3VeqwCBTIOinPcAgk7x = []
	for rOCQ5AYBtjXwExLVlfTo0 in ATHfcUgmdRt3ESah5Q4zr9V2X1M:
		XXCxGBP0T1gVfmzvshUOZj4qN = Fzo2RlCgrxwv8VyiDeXt5ES4MaBf7G.copy()
		XXCxGBP0T1gVfmzvshUOZj4qN[qrjy8LuKVPNYdbSvzh(u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ੆")] = rOCQ5AYBtjXwExLVlfTo0
		XXCxGBP0T1gVfmzvshUOZj4qN[CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩੇ")] = {qrjy8LuKVPNYdbSvzh(u"ࠢࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦੈ"):rOCQ5AYBtjXwExLVlfTo0}
		XXCxGBP0T1gVfmzvshUOZj4qN[tM24jD1gO0(u"ࠨࡷࡶࡩࡷࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ੉")] = {cb3rmvAn4wa6lBPz2phOoYqX(u"ࠤࡘࡷࡪࡸ࡟ࡆࡸࡨࡲࡹࡥࡎࡢ࡯ࡨࠦ੊"):rOCQ5AYBtjXwExLVlfTo0}
		sE9a3VeqwCBTIOinPcAgk7x.append(XXCxGBP0T1gVfmzvshUOZj4qN)
	xIZuFTyOfPBJC8w = str(eH7yw1hTGUROK2B4dcP0iEr.randrange(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠶ୡ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠻࠼࠽࠾࠿࠹࠺࠻࠼࠽࠾࠿ୢ")))
	qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC = {
		DJ6ugPjW9bX8I(u"ࠥࡥࡵ࡯࡟࡬ࡧࡼࠦੋ"):UpQ56M0dO1N9xIvVegy(u"ࠫ࠷࠻࠴ࡥࡦ࠶ࡥ࠹࠶࠹ࡥ࠺ࡥ࠺࠽࠷ࡤ࠵ࡧ࠴࠵࠼࡫ࡥ࠸࠺ࡦࡩࡧ࡬࠲࠺ࠩੌ"),
		YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧ࡯࡮ࡴࡧࡵࡸࡤ࡯ࡤ੍ࠣ"):xIZuFTyOfPBJC8w,
		fgv5U2eRVaQqSiuGD(u"ࠨࡥࡷࡧࡱࡸࡸࠨ੎"): sE9a3VeqwCBTIOinPcAgk7x
	}
	ehWfDEbAtMTZaS5x = {QlTuvPbSpnjygBVW(u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭੏"):O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ੐")}
	qxZiT6WJ7sX = QlTuvPbSpnjygBVW(u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠲࠯ࡣࡰࡴࡱ࡯ࡴࡶࡦࡨ࠲ࡨࡵ࡭࠰࠴࠲࡬ࡹࡺࡰࡢࡲ࡬ࠫੑ")
	B69RXYW5vf8Jt7O = CyiwT9JuQ2zYSqep618I3FR7G(SSvu1CZjTW7FcloNqD(u"ࠪࡔࡔ࡙ࡔࠨ੒"),qxZiT6WJ7sX,qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC,ehWfDEbAtMTZaS5x,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲࡙ࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࡘ࠳࠱ࡴࡶࠪ੓"))
	return B69RXYW5vf8Jt7O
def dr1zfnatJxRHSF48jh0eODm5bGu(cZXwI1vKHebdo4YLDqEfMVzrFW,om2lqtcZ5y4j):
	om2lqtcZ5y4j = om2lqtcZ5y4j.replace(usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡴࡵ࡭࡮ࠪ੔"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠭ࡎࡰࡰࡨࠫ੕"))
	om2lqtcZ5y4j = om2lqtcZ5y4j.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡵࡴࡸࡩࠬ੖"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠨࡖࡵࡹࡪ࠭੗"))
	om2lqtcZ5y4j = om2lqtcZ5y4j.replace(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡩࡥࡱࡹࡥࠨ੘"),t4txivgXSUWBOlCakQmNDjf(u"ࠪࡊࡦࡲࡳࡦࠩਖ਼"))
	om2lqtcZ5y4j = om2lqtcZ5y4j.replace(bnI4kmPtrW7yFEhljXOCq9(u"ࠫࡡ࠵ࠧਗ਼"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠬ࠵ࠧਜ਼"))
	try: eT40LGftIOPZKAcsU26Mx = eval(om2lqtcZ5y4j)
	except: eT40LGftIOPZKAcsU26Mx = mI6nfpFj9qdCi0osvSl(cZXwI1vKHebdo4YLDqEfMVzrFW)
	return eT40LGftIOPZKAcsU26Mx
def UKzkraEisF0wRZ():
	vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall(YayJj10OGl(u"࠭࡜ࡥ࡞ࡧ࠾ࡡࡪ࡜ࡥࠢ࡟࡟࠴ࡉࡏࡍࡑࡕࡠࡢ࠭ੜ"),hXFjqduwKEt2TDC,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if EwNgXqHTSJK6sR9LWrBU3Zh8v: hXFjqduwKEt2TDC = hXFjqduwKEt2TDC.split(EwNgXqHTSJK6sR9LWrBU3Zh8v[f4fTutDOEwUeIoPLRQ],fgv5U2eRVaQqSiuGD(u"࠴ୣ"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	KxjH7PYqN8LgUEQGJ2Su = lQMuw1PvVpAk.strftime(DJ6ugPjW9bX8I(u"ࠧࡠࠧࡰ࠲ࠪࡪ࡟ࠦࡊ࠽ࠩࡒࡥࠧ੝"),lQMuw1PvVpAk.localtime(sqeRK2tVw8))
	hXFjqduwKEt2TDC = hXFjqduwKEt2TDC+KxjH7PYqN8LgUEQGJ2Su
	rqQNcnS9WF6AeXbI15od2H = vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(TTrFaqDzxJOsh90UHIZ5):
		LzODVY2ASrsdEQMbIm = open(TTrFaqDzxJOsh90UHIZ5,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠨࡴࡥࠫਫ਼")).read()
		if IZhXMprxvAHqBEFkg0: LzODVY2ASrsdEQMbIm = LzODVY2ASrsdEQMbIm.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		LzODVY2ASrsdEQMbIm = dr1zfnatJxRHSF48jh0eODm5bGu(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡧ࡭ࡨࡺࠧ੟"),LzODVY2ASrsdEQMbIm)
	else: LzODVY2ASrsdEQMbIm = {}
	wj9t5hBfkEVUd = {}
	for zIFusZ20PnClrDSq4XBxMiJEegAQ in list(LzODVY2ASrsdEQMbIm.keys()):
		if zIFusZ20PnClrDSq4XBxMiJEegAQ!=vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG: wj9t5hBfkEVUd[zIFusZ20PnClrDSq4XBxMiJEegAQ] = LzODVY2ASrsdEQMbIm[zIFusZ20PnClrDSq4XBxMiJEegAQ]
		else:
			if hXFjqduwKEt2TDC and hXFjqduwKEt2TDC!=X1mRwt2YJKgCLu9a67(u"ࠪ࠲࠳࠭੠"):
				ccvNF2iALRVXGsTkS96muIxZjqgd = LzODVY2ASrsdEQMbIm[zIFusZ20PnClrDSq4XBxMiJEegAQ]
				if rqQNcnS9WF6AeXbI15od2H in ccvNF2iALRVXGsTkS96muIxZjqgd:
					wX9P3dR07B5HynVa8 = ccvNF2iALRVXGsTkS96muIxZjqgd.index(rqQNcnS9WF6AeXbI15od2H)
					del ccvNF2iALRVXGsTkS96muIxZjqgd[wX9P3dR07B5HynVa8]
				SeADMcUw2F3OYJdGiZIy6Lmk = [rqQNcnS9WF6AeXbI15od2H]+ccvNF2iALRVXGsTkS96muIxZjqgd
				SeADMcUw2F3OYJdGiZIy6Lmk = SeADMcUw2F3OYJdGiZIy6Lmk[:bnI4kmPtrW7yFEhljXOCq9(u"࠹࠵୤")]
				wj9t5hBfkEVUd[zIFusZ20PnClrDSq4XBxMiJEegAQ] = SeADMcUw2F3OYJdGiZIy6Lmk
			else: wj9t5hBfkEVUd[zIFusZ20PnClrDSq4XBxMiJEegAQ] = LzODVY2ASrsdEQMbIm[zIFusZ20PnClrDSq4XBxMiJEegAQ]
	if vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG not in list(wj9t5hBfkEVUd.keys()): wj9t5hBfkEVUd[vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG] = [rqQNcnS9WF6AeXbI15od2H]
	wj9t5hBfkEVUd = str(wj9t5hBfkEVUd)
	if IZhXMprxvAHqBEFkg0: wj9t5hBfkEVUd = wj9t5hBfkEVUd.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	open(TTrFaqDzxJOsh90UHIZ5,IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡼࡨࠧ੡")).write(wj9t5hBfkEVUd)
	return
def hS5pZyveLR0Ju4EksT2jQ9mrU(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC):
	if IZhXMprxvAHqBEFkg0: import urllib.parse as zQRHYmo30S
	else: import urllib as zQRHYmo30S
	aZkiq74YXlIgBxbd = zQRHYmo30S.urlencode(qqsgWeVHPN5SxXF9oZjvu1bmOYdyEC)
	return aZkiq74YXlIgBxbd
def brh5aWRxQzn6YL8UDNOyK9SFGo(zb2QIaL7Y4h9g8lSck,bHoRBqDl31pavfGw=nbOFVEDkpT4BIR7Qq82yPmHeJU,LmMthlkxdC=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	P2vOEyHYqmtxLJawN5o7Cr4Zcj = bHoRBqDl31pavfGw not in [QlTuvPbSpnjygBVW(u"ࠬࡓ࠳ࡖࠩ੢"),paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࡉࡑࡖ࡙ࠫ੣")]
	if not LmMthlkxdC: LmMthlkxdC = flDSRbv57PnV3(u"ࠧࡷ࡫ࡧࡩࡴ࠭੤")
	gruajX8IpBzV97JnPKs5F4AlMUwR,JpFyEd3Hf0DYBXcvT5urO,mQJfTk78wuhiRqt6DWHnId = t4txivgXSUWBOlCakQmNDjf(u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࠪ੥"),nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if len(zb2QIaL7Y4h9g8lSck)==ohisjm7IfXVDvQn1CJUlcZWdp8Bgeb:
		qxZiT6WJ7sX,zPVRGIK9ZihHujyq4T3OBYF,mQJfTk78wuhiRqt6DWHnId = zb2QIaL7Y4h9g8lSck
		if zPVRGIK9ZihHujyq4T3OBYF: JpFyEd3Hf0DYBXcvT5urO = qrjy8LuKVPNYdbSvzh(u"ࠩࠣࠤ࡙ࠥࡵࡣࡶ࡬ࡸࡱ࡫࠺ࠡ࡝ࠣࠫ੦")+zPVRGIK9ZihHujyq4T3OBYF+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪࠤࡢ࠭੧")
	else: qxZiT6WJ7sX,zPVRGIK9ZihHujyq4T3OBYF,mQJfTk78wuhiRqt6DWHnId = zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	qxZiT6WJ7sX = qxZiT6WJ7sX.replace(UpQ56M0dO1N9xIvVegy(u"ࠫࠪ࠸࠰ࠨ੨"),S3X6GcaiExOPtb)
	J8J0A4lx7y9GDEBq = JoEms64VZ1ldaf9NYBgcKCFL(qxZiT6WJ7sX)
	if bHoRBqDl31pavfGw not in [QlTuvPbSpnjygBVW(u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ੩"),ulAxHwvzR9eTb5n(u"࠭ࡉࡑࡖ࡙ࠫ੪")]:
		if bHoRBqDl31pavfGw!=X1mRwt2YJKgCLu9a67(u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ੫"): qxZiT6WJ7sX = qxZiT6WJ7sX.replace(S3X6GcaiExOPtb,fgv5U2eRVaQqSiuGD(u"ࠨࠧ࠵࠴ࠬ੬"))
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+I3cxjYaHhsrM7T4UX26klN(u"ࠩࠣࠤࠥࡖࡲࡦࡲࡤࡶ࡮ࡴࡧࠡࡶࡲࠤࡵࡲࡡࡺ࠱ࡧࡳࡼࡴ࡬ࡰࡣࡧࠤࡻ࡯ࡤࡦࡱࠣࠤࠥ࡜ࡩࡥࡧࡲ࠾ࠥࡡࠠࠨ੭")+qxZiT6WJ7sX+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࠤࡢ࠭੮")+JpFyEd3Hf0DYBXcvT5urO)
		if J8J0A4lx7y9GDEBq==bYyKEjIuGQzoq3AR1(u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ੯") and bHoRBqDl31pavfGw not in [z3sIGH8jmLYg(u"ࠬࡏࡐࡕࡘࠪੰ"),YayJj10OGl(u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࠧੱ")]:
			from RpSbDv2A79 import mmAWFnZUkQ3HowdxRtCN9,nnRXQH90qeOtABkJzGr,SSVCGE0bOfW1w9u52yvBxocNeP
			bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = mmAWFnZUkQ3HowdxRtCN9(qxZiT6WJ7sX)
			nnrNqvWG5TuXtCRK = len(lPpY5fw3tOBcEye91Caun2FQZ)
			if nnrNqvWG5TuXtCRK>vkIa3ijEQVsJGdWOXwK7bnue9ADR:
				bCiGxXzDkH = nnRXQH90qeOtABkJzGr(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿ࠦࠨࠨੲ")+str(nnrNqvWG5TuXtCRK)+bnI4kmPtrW7yFEhljXOCq9(u"ࠨ่่ࠢๆ࠯ࠧੳ"), bbKoeBcirVfzwAqZdQUFDSX)
				if bCiGxXzDkH==-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
					SSVCGE0bOfW1w9u52yvBxocNeP(IINBvuxkCSJrO1Q0UyngdLi(u"ࠩศ่฿อมࠡ฻่่๏ฯࠠหึ฽๎้ࠦวๅใํำ๏๎ࠧੴ"),qrjy8LuKVPNYdbSvzh(u"ࠪࡇࡦࡴࡣࡦ࡮ࠪੵ"))
					return gruajX8IpBzV97JnPKs5F4AlMUwR
			else: bCiGxXzDkH = f4fTutDOEwUeIoPLRQ
			qxZiT6WJ7sX = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
			if bbKoeBcirVfzwAqZdQUFDSX[f4fTutDOEwUeIoPLRQ]!=O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫ࠲࠷ࠧ੶"):
				fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bnI4kmPtrW7yFEhljXOCq9(u"ࠬࠦࠠࠡࡘ࡬ࡨࡪࡵࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࠣࠤࡘ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠺ࠡ࡝ࠣࠫ੷")+bbKoeBcirVfzwAqZdQUFDSX[bCiGxXzDkH]+t4txivgXSUWBOlCakQmNDjf(u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧ੸")+qxZiT6WJ7sX+bYyKEjIuGQzoq3AR1(u"ࠧࠡ࡟ࠪ੹"))
		if cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࠱࡬ࡪ࡮ࡲ࡭࠰ࠩ੺") in qxZiT6WJ7sX: qxZiT6WJ7sX = qxZiT6WJ7sX+z3sIGH8jmLYg(u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠧࠩ੻")
		elif X60YQOADpkHBb31LiR5qUEKfM(u"ࠪ࡬ࡹࡺࡰࠨ੼") in qxZiT6WJ7sX.lower() and fgv5U2eRVaQqSiuGD(u"ࠫ࠴ࡪࡡࡴࡪ࠲ࠫ੽") not in qxZiT6WJ7sX and usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴࡭ࡱࡦࠪ੾") not in qxZiT6WJ7sX:
			qxZiT6WJ7sX = qxZiT6WJ7sX+qrjy8LuKVPNYdbSvzh(u"࠭ࡼࠨ੿") if l4DS8mnEjHhFMZ5YOe(u"ࠧࡽࠩ઀") not in qxZiT6WJ7sX else qxZiT6WJ7sX+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࠨࠪઁ")
			if X1mRwt2YJKgCLu9a67(u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࠧં") not in qxZiT6WJ7sX and O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬઃ") in qxZiT6WJ7sX.lower(): qxZiT6WJ7sX += tM24jD1gO0(u"ࠫࡻ࡫ࡲࡪࡨࡼࡴࡪ࡫ࡲ࠾ࡨࡤࡰࡸ࡫ࠦࠨ઄")
			if bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡻࡳࡦࡴ࠰ࡥ࡬࡫࡮ࡵ࠿ࠪઅ") not in qxZiT6WJ7sX.lower() and bHoRBqDl31pavfGw not in [CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡉࡑࡖ࡙ࠫઆ"),qrjy8LuKVPNYdbSvzh(u"ࠧࡎ࠵ࡘࠫઇ")]: qxZiT6WJ7sX += UpQ56M0dO1N9xIvVegy(u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠬࠧઈ")
			if paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࡀࠫઉ") not in qxZiT6WJ7sX.lower(): qxZiT6WJ7sX += flDSRbv57PnV3(u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱࠨࠪઊ")
	fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+YayJj10OGl(u"ࠫࠥࠦࠠࡈࡱࡷࠤ࡫࡯࡮ࡢ࡮ࠣࡹࡷࡲ࡙ࠠࠡࠢ࡭ࡩ࡫࡯࠻ࠢ࡞ࠤࠬઋ")+qxZiT6WJ7sX+SSvu1CZjTW7FcloNqD(u"ࠬࠦ࡝ࠨઌ"))
	WeVBr0yK8RXLH74ZYiNsozbGAu53J = LAkCFq8ezcf.ListItem()
	LmMthlkxdC,Z6PkXm3cyrnoWlV4IFBwgev,NejxKSt0T53Xf1m,tCwilLAkcIoqr9dWU8zKb1NZfE,P4h6CupRBIlMDW59LEn8QHA,O5CAS4KgWIlUhZE,EAB9KIghQMmeU437l,gnf3wLzsHCFWpQ,zJ6NlUaZvdqxh59cYIsRwSCDV = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	if bHoRBqDl31pavfGw not in [l4DS8mnEjHhFMZ5YOe(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨઍ"),Fo1SgXMsHk(u"ࠧࡊࡒࡗ࡚ࠬ઎")]:
		if n7neb9KTv10FcU: Em04QIKbnuVWwJY1l = xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫએ")
		else: Em04QIKbnuVWwJY1l = flDSRbv57PnV3(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳࠧઐ")
		WeVBr0yK8RXLH74ZYiNsozbGAu53J.setProperty(Em04QIKbnuVWwJY1l, nbOFVEDkpT4BIR7Qq82yPmHeJU)
		WeVBr0yK8RXLH74ZYiNsozbGAu53J.setMimeType(YayJj10OGl(u"ࠪࡱ࡮ࡳࡥ࠰ࡺ࠰ࡸࡾࡶࡥࠨઑ"))
		if o8MCS3IzmRXdVDB7xg2eiW5baZUn<t4txivgXSUWBOlCakQmNDjf(u"࠷࠶୥"): WeVBr0yK8RXLH74ZYiNsozbGAu53J.setInfo(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡻ࡯ࡤࡦࡱࠪ઒"),{bnI4kmPtrW7yFEhljXOCq9(u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨઓ"):tM24jD1gO0(u"࠭࡭ࡰࡸ࡬ࡩࠬઔ")})
		else:
			E304nJOm8yQKuCfLW9os = WeVBr0yK8RXLH74ZYiNsozbGAu53J.getVideoInfoTag()
			E304nJOm8yQKuCfLW9os.setMediaType(YayJj10OGl(u"ࠧ࡮ࡱࡹ࡭ࡪ࠭ક"))
		WeVBr0yK8RXLH74ZYiNsozbGAu53J.setArt({fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨࡶ࡫ࡹࡲࡨࠧખ"):P4h6CupRBIlMDW59LEn8QHA,DJ6ugPjW9bX8I(u"ࠩࡳࡳࡸࡺࡥࡳࠩગ"):P4h6CupRBIlMDW59LEn8QHA,xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࡦࡦࡴ࡮ࡦࡴࠪઘ"):P4h6CupRBIlMDW59LEn8QHA,t4txivgXSUWBOlCakQmNDjf(u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫઙ"):P4h6CupRBIlMDW59LEn8QHA,X1mRwt2YJKgCLu9a67(u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧચ"):P4h6CupRBIlMDW59LEn8QHA,bYyKEjIuGQzoq3AR1(u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩછ"):P4h6CupRBIlMDW59LEn8QHA,bYyKEjIuGQzoq3AR1(u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪજ"):P4h6CupRBIlMDW59LEn8QHA,UpQ56M0dO1N9xIvVegy(u"ࠨ࡫ࡦࡳࡳ࠭ઝ"):P4h6CupRBIlMDW59LEn8QHA})
		if J8J0A4lx7y9GDEBq in [qrjy8LuKVPNYdbSvzh(u"ࠩ࠱ࡱࡵࡪࠧઞ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩટ")]: WeVBr0yK8RXLH74ZYiNsozbGAu53J.setContentLookup(Ag9l6cw3EBqP8HsQuGMizfOtr4)
		else: WeVBr0yK8RXLH74ZYiNsozbGAu53J.setContentLookup(SmbNGskjMx)
		from SJqrPsfTgG import tjoDTklcueMPnHqI9yg
		if yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࡷࡺ࡭ࡱࠩઠ") in qxZiT6WJ7sX:
			tjoDTklcueMPnHqI9yg(IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠨડ"),SmbNGskjMx)
		elif J8J0A4lx7y9GDEBq==YayJj10OGl(u"࠭࠮࡮ࡲࡧࠫઢ") or YayJj10OGl(u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧણ") in qxZiT6WJ7sX:
			tjoDTklcueMPnHqI9yg(X60YQOADpkHBb31LiR5qUEKfM(u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠨત"),SmbNGskjMx)
			WeVBr0yK8RXLH74ZYiNsozbGAu53J.setProperty(Em04QIKbnuVWwJY1l,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩથ"))
			WeVBr0yK8RXLH74ZYiNsozbGAu53J.setProperty(t4txivgXSUWBOlCakQmNDjf(u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪદ"),SSvu1CZjTW7FcloNqD(u"ࠫࡲࡶࡤࠨધ"))
		if zPVRGIK9ZihHujyq4T3OBYF:
			WeVBr0yK8RXLH74ZYiNsozbGAu53J.setSubtitles([zPVRGIK9ZihHujyq4T3OBYF])
	if LmMthlkxdC==t4txivgXSUWBOlCakQmNDjf(u"ࠬࡼࡩࡥࡧࡲࠫન") and bHoRBqDl31pavfGw==cb3rmvAn4wa6lBPz2phOoYqX(u"࠭ࡄࡐ࡙ࡑࡐࡔࡇࡄࠨ઩"):
		gruajX8IpBzV97JnPKs5F4AlMUwR = cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧપ")
		bHoRBqDl31pavfGw = X60YQOADpkHBb31LiR5qUEKfM(u"ࠨࡒࡏࡅ࡞ࡥࡄࡍࡡࡉࡍࡑࡋࡓࠨફ")
	elif LmMthlkxdC==Fo1SgXMsHk(u"ࠩࡹ࡭ࡩ࡫࡯ࠨબ") and gnf3wLzsHCFWpQ.startswith(bnI4kmPtrW7yFEhljXOCq9(u"ࠪ࠺ࠬભ")):
		gruajX8IpBzV97JnPKs5F4AlMUwR = bYyKEjIuGQzoq3AR1(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩમ")
		bHoRBqDl31pavfGw = bHoRBqDl31pavfGw+z3sIGH8jmLYg(u"ࠬࡥࡄࡍࠩય")
	if gruajX8IpBzV97JnPKs5F4AlMUwR!=DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠫર"): UKzkraEisF0wRZ()
	VJsP3BOmAfS4nzh8FplUdXwo5W27q6.CuDBaZ3FVPW5wtXgTYqM4Avo(bHoRBqDl31pavfGw)
	if VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa: return q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡣ࡮ࡲࡧࡰ࡫ࡤࠨ઱")
	if LmMthlkxdC==paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠨࡸ࡬ࡨࡪࡵࠧલ") and not gnf3wLzsHCFWpQ.startswith(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࠹ࠫળ")):
		WeVBr0yK8RXLH74ZYiNsozbGAu53J.setPath(qxZiT6WJ7sX)
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥࡶ࡬ࡢࡻࠣࡹࡸ࡯࡮ࡨࠢࡶࡩࡹࡘࡥࡴࡱ࡯ࡺࡪࡪࡕࡳ࡮ࠫ࠭ࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪ઴")+qxZiT6WJ7sX+bYyKEjIuGQzoq3AR1(u"ࠫࠥࡣࠧવ"))
		WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.setResolvedUrl(KXth1AHMv64CskLiWESrzuey,Ag9l6cw3EBqP8HsQuGMizfOtr4,WeVBr0yK8RXLH74ZYiNsozbGAu53J)
	elif LmMthlkxdC==QlTuvPbSpnjygBVW(u"ࠬࡲࡩࡷࡧࠪશ"):
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+bYyKEjIuGQzoq3AR1(u"࠭ࠠࠡࠢࡏ࡭ࡻ࡫ࠠࡱ࡮ࡤࡽࠥࡻࡳࡪࡰࡪࠤࡵࡲࡡࡺࠪࠬࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩષ")+qxZiT6WJ7sX+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࠡ࡟ࠪસ"))
		VJsP3BOmAfS4nzh8FplUdXwo5W27q6.play(qxZiT6WJ7sX,WeVBr0yK8RXLH74ZYiNsozbGAu53J)
	EJNf2kglaiQHnFGe531Iq = SmbNGskjMx
	if gruajX8IpBzV97JnPKs5F4AlMUwR==qrjy8LuKVPNYdbSvzh(u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭હ"):
		from VVg6xidT03 import SIvBzVkdQYCWnlsN3wiT41cZqjOhp
		EJNf2kglaiQHnFGe531Iq = SIvBzVkdQYCWnlsN3wiT41cZqjOhp(qxZiT6WJ7sX,J8J0A4lx7y9GDEBq,bHoRBqDl31pavfGw)
		if EJNf2kglaiQHnFGe531Iq: UKzkraEisF0wRZ()
	else:
		rXKsDBmP18gdEl4LWbU6,gruajX8IpBzV97JnPKs5F4AlMUwR,Ku8pAaVNItW,l91w4JtET5qfmdhCsK,ABRqXGkj9N76SfzOTtQd = f4fTutDOEwUeIoPLRQ,X1mRwt2YJKgCLu9a67(u"ࠩࡷࡶ࡮࡫ࡤࠨ઺"),SmbNGskjMx,DJ6ugPjW9bX8I(u"࠱࠱࠲࠳୧"),X60YQOADpkHBb31LiR5qUEKfM(u"࠺࠵࠱࠲࠳୦")
		if P2vOEyHYqmtxLJawN5o7Cr4Zcj: from RpSbDv2A79 import SSVCGE0bOfW1w9u52yvBxocNeP
		while rXKsDBmP18gdEl4LWbU6<ABRqXGkj9N76SfzOTtQd:
			RarSo2nTfwU0WEGK.sleep(l91w4JtET5qfmdhCsK)
			rXKsDBmP18gdEl4LWbU6 += l91w4JtET5qfmdhCsK
			if VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪࡷࡹࡧࡲࡵࡧࡧࠫ઻") and not Ku8pAaVNItW:
				if P2vOEyHYqmtxLJawN5o7Cr4Zcj: SSVCGE0bOfW1w9u52yvBxocNeP(fsQukcZeJ8YbozTXKEvS7h306DCA(u"๋ࠫาอหࠢ฼้้๐ษࠡวํะฬีࠠศๆไ๎ิ๐่ࠨ઼"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"࡙ࠬࡵࡤࡥࡨࡷࡸ࠭ઽ"),lQMuw1PvVpAk=UpQ56M0dO1N9xIvVegy(u"࠸࠷࠳୨"))
				fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+fsQukcZeJ8YbozTXKEvS7h306DCA(u"࠭ࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࠥ࡜ࡩࡥࡧࡲࠤࡸࡺࡡࡳࡶࡨࡨࠥࠦࠠࡗ࡫ࡧࡩࡴࡀࠠ࡜ࠢࠪા")+qxZiT6WJ7sX+fgv5U2eRVaQqSiuGD(u"ࠧࠡ࡟ࠪિ")+JpFyEd3Hf0DYBXcvT5urO)
				Ku8pAaVNItW = Ag9l6cw3EBqP8HsQuGMizfOtr4
			elif VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa in [l4DS8mnEjHhFMZ5YOe(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩી"),fgv5U2eRVaQqSiuGD(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪુ")]:
				fGBlEmQTwiAJt7rCYIxyau3jRh(Ks92S7bFeoUhWGqM6AIBaYDv1gjcJ,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+I3cxjYaHhsrM7T4UX26klN(u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺࡙ࠡࠢ࡭ࡩ࡫࡯ࠡࡲ࡯ࡥࡾ࡯࡮ࡨࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧૂ")+qxZiT6WJ7sX+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࠥࡣࠧૃ")+JpFyEd3Hf0DYBXcvT5urO)
				break
			elif VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa==bnI4kmPtrW7yFEhljXOCq9(u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬૄ"):
				fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+l4DS8mnEjHhFMZ5YOe(u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡺ࡮ࡪࡥࡰࠢࠣࠤ࡛࡯ࡤࡦࡱ࠽ࠤࡠࠦࠧૅ")+qxZiT6WJ7sX+t4txivgXSUWBOlCakQmNDjf(u"ࠧࠡ࡟ࠪ૆")+JpFyEd3Hf0DYBXcvT5urO)
				if P2vOEyHYqmtxLJawN5o7Cr4Zcj: SSVCGE0bOfW1w9u52yvBxocNeP(fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬે"),t4txivgXSUWBOlCakQmNDjf(u"ࠩࡉࡥ࡮ࡲࡵࡳࡧࠪૈ"),lQMuw1PvVpAk=DJ6ugPjW9bX8I(u"࠹࠸࠴୩"))
				break
			elif VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa==q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠪࡦࡱࡵࡣ࡬ࡧࡧࠫૉ"):
				fGBlEmQTwiAJt7rCYIxyau3jRh(P5PUfZzwS4OkiaLVMlXDbj,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫࠥࠦࠠࡅࡧࡹ࡭ࡨ࡫ࠠࡪࡵࠣࡦࡱࡵࡣ࡬ࡧࡧࠤࠥࠦࡖࡪࡦࡨࡳ࠿࡛ࠦࠡࠩ૊")+qxZiT6WJ7sX+Fo1SgXMsHk(u"ࠬࠦ࡝ࠨો"))
				break
		else: gruajX8IpBzV97JnPKs5F4AlMUwR = DJ6ugPjW9bX8I(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧૌ")
	if gruajX8IpBzV97JnPKs5F4AlMUwR in [YayJj10OGl(u"ࠧࡱ࡮ࡤࡽࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ્ࠧ")] or VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa in [fgv5U2eRVaQqSiuGD(u"ࠨࡲ࡯ࡥࡾ࡯࡮ࡨࠩ૎"),fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠩࡷࡩࡸࡺࡩ࡯ࡩࠪ૏")] or EJNf2kglaiQHnFGe531Iq: Wyuk0g8ERiBU(bHoRBqDl31pavfGw)
	else: exec(t4txivgXSUWBOlCakQmNDjf(u"ࠪ࡭ࡲࡶ࡯ࡳࡶࠣࡼࡧࡳࡣ࠼ࡺࡥࡱࡨ࠴ࡐ࡭ࡣࡼࡩࡷ࠮ࠩ࠯ࡵࡷࡳࡵ࠮ࠩࠨૐ"))
	JxkZu9DIrEXC2LfpobR8WMY = RarSo2nTfwU0WEGK.Player().isPlaying()
	if not JxkZu9DIrEXC2LfpobR8WMY and gruajX8IpBzV97JnPKs5F4AlMUwR not in [I3cxjYaHhsrM7T4UX26klN(u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࡯࡮ࡨࠩ૑")]:
		msg = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࡚ࠬࡩ࡮ࡧࡲࡹࡹ࠭૒") if gruajX8IpBzV97JnPKs5F4AlMUwR==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ૓") else IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠨ૔")
		if P2vOEyHYqmtxLJawN5o7Cr4Zcj: SSVCGE0bOfW1w9u52yvBxocNeP(bYyKEjIuGQzoq3AR1(u"ࠨใื่ฯูࠦๆๆํอࠥะิ฻์็ࠤฬ๊แ๋ัํ์ࠬ૕"),msg,lQMuw1PvVpAk=tM24jD1gO0(u"࠺࠹࠵୪"))
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+YayJj10OGl(u"ࠩࠣࠤࠥ࠭૖")+msg+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪ࠾ࠥࠦࡕ࡯࡭ࡱࡳࡼࡴࠠࡱࡴࡲࡦࡱ࡫࡭࡚ࠡࠢࠣ࡮ࡪࡥࡰ࠼ࠣ࡟ࠥ࠭૗")+qxZiT6WJ7sX+UpQ56M0dO1N9xIvVegy(u"ࠫࠥࡣࠧ૘")+JpFyEd3Hf0DYBXcvT5urO)
	return VJsP3BOmAfS4nzh8FplUdXwo5W27q6.rwlt36bkKgoFa
def JoEms64VZ1ldaf9NYBgcKCFL(qxZiT6WJ7sX):
	if IZhXMprxvAHqBEFkg0: from urllib.parse import urlparse as u4QJ32PtIkmc7YWVsRE
	else: from urlparse import urlparse as u4QJ32PtIkmc7YWVsRE
	path = u4QJ32PtIkmc7YWVsRE(qxZiT6WJ7sX).path
	b8z9WKkErgYtyas0CUcVvQN1hxHmXu = nbOFVEDkpT4BIR7Qq82yPmHeJU if SSvu1CZjTW7FcloNqD(u"ࠬ࠴ࠧ૙") not in path else path.rsplit(IINBvuxkCSJrO1Q0UyngdLi(u"࠭࠮ࠨ૚"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠵୫"))[vkIa3ijEQVsJGdWOXwK7bnue9ADR]
	if b8z9WKkErgYtyas0CUcVvQN1hxHmXu in [paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࡢࡸ࡬ࠫ૛"),q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠨࡶࡶࠫ૜"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࡤࡥࡨ࠭૝"),l4DS8mnEjHhFMZ5YOe(u"ࠪࡱࡵ࠺ࠧ૞"),tM24jD1gO0(u"ࠫࡲ࠹ࡵࠨ૟"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡳ࠳ࡶ࠺ࠪૠ"),CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭࡭ࡱࡦࠪૡ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠧ࡮࡭ࡹࠫૢ"),SSvu1CZjTW7FcloNqD(u"ࠨࡨ࡯ࡺࠬૣ"),ulAxHwvzR9eTb5n(u"ࠩࡰࡴ࠸࠭૤"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪࡻࡪࡨ࡭ࠨ૥")]: return UpQ56M0dO1N9xIvVegy(u"ࠫ࠳࠭૦")+b8z9WKkErgYtyas0CUcVvQN1hxHmXu
	return nbOFVEDkpT4BIR7Qq82yPmHeJU
def Wyuk0g8ERiBU(XXCxGBP0T1gVfmzvshUOZj4qN):
	if not QQ3hd2tR8s.ggSlJwTytkUHBA2dz: XXCxGBP0T1gVfmzvshUOZj4qN += fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠬࡥࡔࡔࠩ૧")
	mHhBGP1spJW4kfAvbj92qVZ.append(XXCxGBP0T1gVfmzvshUOZj4qN)
	return
def AALCX4pzvF8HeuYtoDs7(f8RoLj2sExhD7H3t5JY4=SmbNGskjMx):
	DI8EKCHQ4spn5iJLZO0f7Syzbdwhr(f8RoLj2sExhD7H3t5JY4,UpQ56M0dO1N9xIvVegy(u"࠭࡟ࡠࡡࡉࡓࡗࡉࡅࡠࡇ࡛ࡍ࡙ࡥ࡟ࡠࠩ૨"))
	Jg3GROZ80HzMpAfL2DQ4mdYhuW.exit()
def DI8EKCHQ4spn5iJLZO0f7Syzbdwhr(f8RoLj2sExhD7H3t5JY4,vf9s4ClmTE08AGndQV):
	if vf9s4ClmTE08AGndQV:
		if CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧࡠࡡࡢࡊࡔࡘࡃࡆࡡࡈ࡜ࡎ࡚࡟ࡠࡡࠪ૩") in vf9s4ClmTE08AGndQV: fGBlEmQTwiAJt7rCYIxyau3jRh(nbOFVEDkpT4BIR7Qq82yPmHeJU,X1mRwt2YJKgCLu9a67(u"ࠨࡡࡢࡣࡋࡕࡒࡄࡇࡢࡉ࡝ࡏࡔࡠࡡࡢࠫ૪"))
		else:
			zWym0pg9wja74X5xRQdYUe6nkEvKSt = llnG7jiQBYKhAeovbT.getSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠩࡤࡺ࠳ࡲࡡ࡯ࡩࡸࡥ࡬࡫࠮ࡵࡴࡤࡲࡸࡲࡡࡵࡧࠪ૫"))
			llnG7jiQBYKhAeovbT.setSetting(l4DS8mnEjHhFMZ5YOe(u"ࠪࡥࡻ࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥ࠯ࡶࡵࡥࡳࡹ࡬ࡢࡶࡨࠫ૬"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
			import RpSbDv2A79
			RpSbDv2A79.ldsAFanjmVkh93ybXC(vf9s4ClmTE08AGndQV)
			llnG7jiQBYKhAeovbT.setSetting(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠫࡦࡼ࠮࡭ࡣࡱ࡫ࡺࡧࡧࡦ࠰ࡷࡶࡦࡴࡳ࡭ࡣࡷࡩࠬ૭"),zWym0pg9wja74X5xRQdYUe6nkEvKSt)
	UUlNOsvLb1(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࡹࡴࡰࡲࠪ૮"))
	FGnvJ1ZOyESbpuerf54w8U = llnG7jiQBYKhAeovbT.getSetting(YayJj10OGl(u"࠭ࡡࡷ࠰ࡶࡸࡦࡺࡵࡴ࠰ࡵࡩ࡫ࡸࡥࡴࡪࠪ૯"))
	if FGnvJ1ZOyESbpuerf54w8U==z3sIGH8jmLYg(u"ࠧࡓࡇࡔ࡙ࡊ࡙ࡔࡠࡔࡈࡊࡗࡋࡓࡉࡡࡆࡅࡈࡎࡅࠨ૰"): llnG7jiQBYKhAeovbT.setSetting(X1mRwt2YJKgCLu9a67(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬ૱"),X60YQOADpkHBb31LiR5qUEKfM(u"ࠩࡕࡉࡋࡘࡅࡔࡊࡢࡇࡆࡉࡈࡆࠩ૲"))
	elif FGnvJ1ZOyESbpuerf54w8U==YayJj10OGl(u"ࠪࡖࡊࡌࡒࡆࡕࡋࡣࡈࡇࡃࡉࡇࠪ૳"): llnG7jiQBYKhAeovbT.setSetting(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨ૴"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if llnG7jiQBYKhAeovbT.getSetting(t4txivgXSUWBOlCakQmNDjf(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡷࡶࡩࡩࡴࡳࠨ૵")) not in [flDSRbv57PnV3(u"࠭ࡁࡖࡖࡒࠫ૶"),X1mRwt2YJKgCLu9a67(u"ࠧࡔࡖࡒࡔࠬ૷"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡃࡖࡏࠬ૸")]: llnG7jiQBYKhAeovbT.setSetting(IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡻࡳࡦࡦࡱࡷࠬૹ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪࡅࡘࡑࠧૺ"))
	if llnG7jiQBYKhAeovbT.getSetting(l4DS8mnEjHhFMZ5YOe(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡶࡵࡨࡴࡷࡵࡸࡺࠩૻ")) not in [CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡇࡕࡕࡑࠪૼ"),t4txivgXSUWBOlCakQmNDjf(u"࠭ࡓࡕࡑࡓࠫ૽"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠧࡂࡕࡎࠫ૾")]: llnG7jiQBYKhAeovbT.setSetting(YayJj10OGl(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡺࡹࡥࡱࡴࡲࡼࡾ࠭૿"),flDSRbv57PnV3(u"ࠩࡄࡗࡐ࠭଀"))
	jMCutfr8dzEVI2eHkG9cnWxDy5Ao = llnG7jiQBYKhAeovbT.getSetting(X60YQOADpkHBb31LiR5qUEKfM(u"ࠪࡥࡻ࠴࡭ࡺࡵ࡮࡭ࡳ࠴ࡶࡪࡧࡺࡱࡴࡪࡥࠨଁ"))
	TRlmx0KhjvQorVk9DYGzwIp = RarSo2nTfwU0WEGK.executeJSONRPC(X60YQOADpkHBb31LiR5qUEKfM(u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡹࡥࡵࡶ࡬ࡲ࡬ࠨ࠺ࠣ࡮ࡲࡳࡰࡧ࡮ࡥࡨࡨࡩࡱ࠴ࡳ࡬࡫ࡱࠦࢂࢃࠧଂ"))
	if cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡹ࡫ࡪࡰ࠱ࡱࡪࡺࡲࡰࡲࡲࡰ࡮ࡹࡅࡎࡃࡇࠫଃ") in str(TRlmx0KhjvQorVk9DYGzwIp) and jMCutfr8dzEVI2eHkG9cnWxDy5Ao in [DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠭ࡅࡎࡃࡇࠤࡑ࡯ࡳࡵࠩ଄"),ulAxHwvzR9eTb5n(u"ࠧࡆࡏࡄࡈࠥࡍࡡ࡭࡮ࡨࡶࡾ࠭ଅ")]:
		lQMuw1PvVpAk.sleep(xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠵࠴࠱࠱࠲୬"))
		RarSo2nTfwU0WEGK.executebuiltin(YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠨࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡘ࡫ࡴࡗ࡫ࡨࡻࡒࡵࡤࡦࠪ࠳࠭ࠬଆ"))
	if f4fTutDOEwUeIoPLRQ and KXth1AHMv64CskLiWESrzuey>-vkIa3ijEQVsJGdWOXwK7bnue9ADR:
		WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.setResolvedUrl(KXth1AHMv64CskLiWESrzuey,SmbNGskjMx,LAkCFq8ezcf.ListItem())
		EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC = SmbNGskjMx,SmbNGskjMx,SmbNGskjMx
		WWTzqMo4Osga9iKAnfwJIGRZuk1vNV.endOfDirectory(KXth1AHMv64CskLiWESrzuey,EJNf2kglaiQHnFGe531Iq,YYSzLsNiAr2R8FcBbIuleHv471UMp,YWlSmwPBg4AZiC)
	if mHhBGP1spJW4kfAvbj92qVZ:
		if qrjy8LuKVPNYdbSvzh(u"ࠩࡇࡓࡓࡇࡔࡊࡑࡑࡗࠬଇ") in str(mHhBGP1spJW4kfAvbj92qVZ) and t4txivgXSUWBOlCakQmNDjf(u"ࠪࡕ࡚ࡋࡓࡕࡋࡒࡒࡘ࠭ଈ") in str(mHhBGP1spJW4kfAvbj92qVZ) and bYyKEjIuGQzoq3AR1(u"ࠫࡒࡋࡓࡔࡃࡊࡉࡘ࠭ଉ") in str(mHhBGP1spJW4kfAvbj92qVZ):
			for XXCxGBP0T1gVfmzvshUOZj4qN in [z3sIGH8jmLYg(u"ࠬࡓࡅࡔࡕࡄࡋࡊ࡙ࠧଊ"),tM24jD1gO0(u"࠭ࡑࡖࡇࡖࡘࡎࡕࡎࡔࠩଋ"),I3cxjYaHhsrM7T4UX26klN(u"ࠧࡎࡇࡖࡗࡆࡍࡅࡔࡡࡗࡗࠬଌ"),fgv5U2eRVaQqSiuGD(u"ࠨࡓࡘࡉࡘ࡚ࡉࡐࡐࡖࡣ࡙࡙ࠧ଍")]:
				if XXCxGBP0T1gVfmzvshUOZj4qN in mHhBGP1spJW4kfAvbj92qVZ: mHhBGP1spJW4kfAvbj92qVZ.remove(XXCxGBP0T1gVfmzvshUOZj4qN)
		Ef8Kqg7eGcQhm3FBYO45p = eb6R0h1Fjl.Thread(target=ThGYJa4dyjI,args=(mHhBGP1spJW4kfAvbj92qVZ,))
		Ef8Kqg7eGcQhm3FBYO45p.start()
	G8g9VuAfRpvaLCwh = Xy1xTM6b4LChGw5dzS3ZgkIU()
	JxkZu9DIrEXC2LfpobR8WMY = RarSo2nTfwU0WEGK.Player().isPlaying()
	if G8g9VuAfRpvaLCwh and JxkZu9DIrEXC2LfpobR8WMY:
		xZAq402Jn5TLeMj1aS6mwdYt8 = FGASiLgK1ZceNVQ8zOwfmU7ha3vbyR()
		if xZAq402Jn5TLeMj1aS6mwdYt8:
			QQ3hd2tR8s.resolveonly = Ag9l6cw3EBqP8HsQuGMizfOtr4
			lQMuw1PvVpAk.sleep(Fo1SgXMsHk(u"࠼࠰୭"))
			JxkZu9DIrEXC2LfpobR8WMY = RarSo2nTfwU0WEGK.Player().isPlaying()
			if JxkZu9DIrEXC2LfpobR8WMY:
				vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(xZAq402Jn5TLeMj1aS6mwdYt8)
				import RpSbDv2A79
				if not any(XPL0O2VkI3w1C8enMaqi in hXFjqduwKEt2TDC for XPL0O2VkI3w1C8enMaqi in RpSbDv2A79.NOT_TO_TEST_ALL_SERVERS):
					RpSbDv2A79.SSVCGE0bOfW1w9u52yvBxocNeP(t4txivgXSUWBOlCakQmNDjf(u"ࠩส่ๆ๐ฯ๋๊ࠣห้๊วฮไࠪ଎"),bYyKEjIuGQzoq3AR1(u"ࠪๅา฻ࠠอ็ํ฽ࠥอไิ์ิๅึอสࠨଏ"),lQMuw1PvVpAk=UpQ56M0dO1N9xIvVegy(u"࠲࠱࠲࠳୮"))
					lQMuw1PvVpAk.sleep(X1mRwt2YJKgCLu9a67(u"࠳୯"))
					if n7neb9KTv10FcU:
						qxZiT6WJ7sX = qxZiT6WJ7sX.encode(zSafwK0sDXdMN5JReniIQmrZxp)
					bPFto2wZdNYrClgBIEv60DJAzu = RpSbDv2A79.QHAgKDUZvqTES8VMh(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
					RpSbDv2A79.SSVCGE0bOfW1w9u52yvBxocNeP(DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࠬଐ"),z3sIGH8jmLYg(u"ࠬอๆห้์ࠤๆำีࠡษ็ื๏ืแาษอࠫ଑"),lQMuw1PvVpAk=l4DS8mnEjHhFMZ5YOe(u"࠴࠳࠴࠵୰"))
	if f8RoLj2sExhD7H3t5JY4: RarSo2nTfwU0WEGK.executebuiltin(q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ଒"))
	return
def FGASiLgK1ZceNVQ8zOwfmU7ha3vbyR():
	cJyLwzhfRZj3DaWokN = RarSo2nTfwU0WEGK.executeJSONRPC(ulAxHwvzR9eTb5n(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡐ࡭ࡣࡼࡰ࡮ࡹࡴ࠯ࡉࡨࡸࡎࡺࡥ࡮ࡵࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡲ࡯ࡥࡾࡲࡩࡴࡶ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡶࡴࡶࡥࡳࡶ࡬ࡩࡸࠨ࠺࡜ࠤࡷ࡭ࡹࡲࡥࠣ࠮ࠥࡪ࡮ࡲࡥࠣ࠮ࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨ࡝ࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪଓ"))
	bPFto2wZdNYrClgBIEv60DJAzu = eH72MR1wtfuI80myOo4ajgG.loads(cJyLwzhfRZj3DaWokN)[X1mRwt2YJKgCLu9a67(u"ࠨࡴࡨࡷࡺࡲࡴࠨଔ")]
	xZAq402Jn5TLeMj1aS6mwdYt8 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: items = bPFto2wZdNYrClgBIEv60DJAzu[q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩ࡬ࡸࡪࡳࡳࠨକ")]
	except: return nbOFVEDkpT4BIR7Qq82yPmHeJU
	if items:
		for wDIU0SN9GBtzZPoihYnv2xjqQC,file in enumerate(items):
			path = file[t4txivgXSUWBOlCakQmNDjf(u"ࠪࡪ࡮ࡲࡥࠨଖ")]
			if ldJmEsIZY9A4pXStekwNoTV not in path: continue
			path = path.split(ldJmEsIZY9A4pXStekwNoTV)[vkIa3ijEQVsJGdWOXwK7bnue9ADR][vkIa3ijEQVsJGdWOXwK7bnue9ADR:]
			if path==cvU8LCyfWkogjSeF9lHphBdEZnzsmr: break
		count = bPFto2wZdNYrClgBIEv60DJAzu[qrjy8LuKVPNYdbSvzh(u"ࠫࡱ࡯࡭ࡪࡶࡶࠫଗ")][xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡺ࡯ࡵࡣ࡯ࠫଘ")]
		if wDIU0SN9GBtzZPoihYnv2xjqQC+vkIa3ijEQVsJGdWOXwK7bnue9ADR<count: xZAq402Jn5TLeMj1aS6mwdYt8 = items[wDIU0SN9GBtzZPoihYnv2xjqQC+vkIa3ijEQVsJGdWOXwK7bnue9ADR][IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࡦࡪ࡮ࡨࠫଙ")]
	return xZAq402Jn5TLeMj1aS6mwdYt8
def Xy1xTM6b4LChGw5dzS3ZgkIU():
	V5VsTuKOPYNQvkcX2 = RarSo2nTfwU0WEGK.executeJSONRPC(DJ6ugPjW9bX8I(u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠨࡩࡥࠤ࠽࠵࠱ࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡼࡩࡥࡧࡲࡴࡱࡧࡹࡦࡴ࠱ࡥࡺࡺ࡯ࡱ࡮ࡤࡽࡳ࡫ࡸࡵ࡫ࡷࡩࡲࠨࡽࡾࠩଚ"))
	eYvNqFMwxLgKb = SmbNGskjMx if UpQ56M0dO1N9xIvVegy(u"ࠨ࡝ࡠࠫଛ") in str(V5VsTuKOPYNQvkcX2) else Ag9l6cw3EBqP8HsQuGMizfOtr4
	return eYvNqFMwxLgKb
def UUlNOsvLb1(N5PmKQfLJg40y2wbi8TlZ):
	global cUzOMK82o05RpPAfVNqSI6vik3Wxb
	if cUzOMK82o05RpPAfVNqSI6vik3Wxb:
		if N5PmKQfLJg40y2wbi8TlZ==DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩࡶࡸࡴࡶࠧଜ"):
			kXSzZd2KeCsm4PEHig0YUhqJBwR = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࡦࡺࡹࡹࡥ࡫ࡤࡰࡴ࡭࡮ࡰࡥࡤࡲࡨ࡫࡬ࠨଝ") if o8MCS3IzmRXdVDB7xg2eiW5baZUn>cb3rmvAn4wa6lBPz2phOoYqX(u"࠴࠻࠳࠿࠹ୱ") else bYyKEjIuGQzoq3AR1(u"ࠫࡧࡻࡳࡺࡦ࡬ࡥࡱࡵࡧࠨଞ")
			RarSo2nTfwU0WEGK.executebuiltin(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠬࡊࡩࡢ࡮ࡲ࡫࠳ࡉ࡬ࡰࡵࡨࠬࠬଟ")+kXSzZd2KeCsm4PEHig0YUhqJBwR+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"࠭ࠩࠨଠ"))
			cUzOMK82o05RpPAfVNqSI6vik3Wxb = SmbNGskjMx
	else:
		if N5PmKQfLJg40y2wbi8TlZ==UpQ56M0dO1N9xIvVegy(u"ࠧࡴࡶࡤࡶࡹ࠭ଡ"):
			kXSzZd2KeCsm4PEHig0YUhqJBwR = qrjy8LuKVPNYdbSvzh(u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭ଢ") if o8MCS3IzmRXdVDB7xg2eiW5baZUn>yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠵࠼࠴࠹࠺୲") else bYyKEjIuGQzoq3AR1(u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭ଣ")
			RarSo2nTfwU0WEGK.executebuiltin(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬࠬତ")+kXSzZd2KeCsm4PEHig0YUhqJBwR+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠫ࠮࠭ଥ"))
			cUzOMK82o05RpPAfVNqSI6vik3Wxb = Ag9l6cw3EBqP8HsQuGMizfOtr4
	return
Mj7VG5l1XKDBOPiev3y,U2UpAZJogRrcLwzTBiWv5x9NOPF = None,None
mHhBGP1spJW4kfAvbj92qVZ = []
iidHGYjPEW4zU = DD98VLARlydeJU4uYk()
FtpGjIPv2H = iidHGYjPEW4zU.splitlines()[f4fTutDOEwUeIoPLRQ][-O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠷࠺୳"):]
QQ3hd2tR8s.F8e4uNA5OfTIHvkg6lCJt2BZ,QQ3hd2tR8s.ggSlJwTytkUHBA2dz,QQ3hd2tR8s.UXlu0f9Szq2MTcEeWrn,QQ3hd2tR8s.qq293Npd7C = Bi6UGMYAPubKoXJge23fIw59vqR8d([usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠬࡉࡔࡆ࠻ࡇࡗ࠶࠿ࡖࡖ࠲࡙ࡗ࡝࠭ଦ"),X1mRwt2YJKgCLu9a67(u"࠭ࡗࡔࡗࡕࡊ࡙࠷࠹ࡒࡖࡈࡊ࡟࡞ࠧଧ"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡗࡕ࡚ࡓ࡛ࡓࡖ࠷ࡋ࡜ࠬନ"),bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࡑࡗ࠵࠾ࡐࡕ࠱ࡺࡅࡘ࡚ࡲࡄ࡙ࠩ଩")])
oFOIC90bwDxWKLBZYAhmk = nbOFVEDkpT4BIR7Qq82yPmHeJU
QQ3hd2tR8s.resolveonly = SmbNGskjMx
VJsP3BOmAfS4nzh8FplUdXwo5W27q6 = SRlNvD1a03QzgVLxu9nWOPZe5mrwKt()
QQ3hd2tR8s.showDialogs = Ag9l6cw3EBqP8HsQuGMizfOtr4
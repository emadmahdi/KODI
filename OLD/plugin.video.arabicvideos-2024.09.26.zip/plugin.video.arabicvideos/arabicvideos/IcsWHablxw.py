# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'EGYBEST4'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_EB4_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['ايجي بست','اتصل بنا','ايجي بست الاصلي','ايجي بست الجديد','ايجي بست البديل','egybest','موقع ايجي بست']
def n1zxUlcAgR(mode,url,ohpwd6UumaecE3IWV8lAv0,text):
	if   mode==800: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==801: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==802: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==803: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==804: bPFto2wZdNYrClgBIEv60DJAzu = VVbAcyXe2o0h(url)
	elif mode==806: bPFto2wZdNYrClgBIEv60DJAzu = RG2K4b1gqI9ViYQX(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==809: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,809,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر',zKREXyTHfVSNL8ZFYs+'/trending',804,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST4-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('nav-categories(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('mainContent(.*?)<footer>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('mainTitle.*?href="(.*?)".*?title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801,nbOFVEDkpT4BIR7Qq82yPmHeJU,'mainmenu')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-menu(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.strip(S3X6GcaiExOPtb)
			if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def RG2K4b1gqI9ViYQX(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST4-SEASONS_EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('mainTitle.*?>(.*?)<(.*?)pageContent',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,HOsekxhQY6NrK1tcGu8BvVo7CLyUIP,items = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
		for name,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			if 'حلقات' in name: HOsekxhQY6NrK1tcGu8BvVo7CLyUIP = G4JHzTEp61
			if 'مواسم' in name: KXVHpZTa3BCSWlQYUut0PdDLc94Rzo = G4JHzTEp61
		if KXVHpZTa3BCSWlQYUut0PdDLc94Rzo and not type:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if len(items)>1:
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,806,X79kphTKa1xLP,'season')
		if HOsekxhQY6NrK1tcGu8BvVo7CLyUIP and len(items)<2:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',HOsekxhQY6NrK1tcGu8BvVo7CLyUIP,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if items:
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,803,X79kphTKa1xLP)
			else:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',HOsekxhQY6NrK1tcGu8BvVo7CLyUIP,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,803)
	return
def IGDobAKtj4kPF5V(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	HHrRx62syvkwiQuN5hzB0Up,start,nFE7RXAdxPUaktfcCDwZGsQhMzybmY,select,sxCOFvhZXQ8ja6Rwf42JuU = 0,0,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 'pagination' in type:
		K5NdlZDeB4qWCFgy0P3YSt7H,J27qXeRCpsgkEoT9Q0GYS6ct = url.split('?next=page&')
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Content-Type':'application/x-www-form-urlencoded'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',K5NdlZDeB4qWCFgy0P3YSt7H,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST4-TITLES-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = 'secContent'+UTvsQb4HpCP3Aeo2wDZG7X5V+'<footer>'
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST4-TITLES-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = UTvsQb4HpCP3Aeo2wDZG7X5V
	items,ii2tNgwPc0CZ6Lyh4A3fT,c2oNVv4ptmTlhgL9s = [],False,False
	if not type and '/collections' not in url:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('mainContent(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801,nbOFVEDkpT4BIR7Qq82yPmHeJU,'submenu')
				ii2tNgwPc0CZ6Lyh4A3fT = True
	if not ii2tNgwPc0CZ6Lyh4A3fT:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('secContent(.*?)mainContent',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?img="(.*?)".*?"title">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				X79kphTKa1xLP = X79kphTKa1xLP.strip(wwOnIucWJj)
				title = dCtxzeFX4GJVonm(title)
				if '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and type=='season': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,806,X79kphTKa1xLP,'season')
				elif '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,806,X79kphTKa1xLP)
				elif '/seasons/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801,X79kphTKa1xLP,'season')
				elif '/collections' in url: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801,X79kphTKa1xLP,'collections')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,803,X79kphTKa1xLP)
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('loadMoreParams = (.*?);',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			wqHptDJiLhz = dr1zfnatJxRHSF48jh0eODm5bGu('dict',G4JHzTEp61)
			sxCOFvhZXQ8ja6Rwf42JuU = wqHptDJiLhz['ajaxurl']
			M2RDC4XTQxmqHJ8cWNbA = int(wqHptDJiLhz['current_page'])+1
			DDUTIcaiqNkXz1R20Sj = int(wqHptDJiLhz['max_page'])
			ZZcsue03mB6PryfEGKkYdSpOQqFjNL = wqHptDJiLhz['posts'].replace('False','false').replace('True','true').replace('None','null')
			if M2RDC4XTQxmqHJ8cWNbA<DDUTIcaiqNkXz1R20Sj:
				J27qXeRCpsgkEoT9Q0GYS6ct = 'action=loadmore&query='+lcxFAteLQ1Pwu45Er2(ZZcsue03mB6PryfEGKkYdSpOQqFjNL,nbOFVEDkpT4BIR7Qq82yPmHeJU)+'&page='+str(M2RDC4XTQxmqHJ8cWNbA)
				plSscrVjkRviPwm = sxCOFvhZXQ8ja6Rwf42JuU+'?next=page&'+J27qXeRCpsgkEoT9Q0GYS6ct
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'جلب المزيد',plSscrVjkRviPwm,801,nbOFVEDkpT4BIR7Qq82yPmHeJU,'pagination_'+type)
		elif '?next=page&' in url:
			J27qXeRCpsgkEoT9Q0GYS6ct,yY1QxvbIU3p4jSnaVtmuPW = J27qXeRCpsgkEoT9Q0GYS6ct.rsplit('=',1)
			yY1QxvbIU3p4jSnaVtmuPW = int(yY1QxvbIU3p4jSnaVtmuPW)+1
			plSscrVjkRviPwm = K5NdlZDeB4qWCFgy0P3YSt7H+'?next=page&'+J27qXeRCpsgkEoT9Q0GYS6ct+'='+str(yY1QxvbIU3p4jSnaVtmuPW)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'جلب المزيد',plSscrVjkRviPwm,801,nbOFVEDkpT4BIR7Qq82yPmHeJU,'pagination_'+type)
	return
def VVbAcyXe2o0h(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST4-FILTERS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('sub_nav(.*?)secContent ',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('"current_opt">(.*?)<(.*?)</div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for name,G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
			if 'التصنيف' in name: continue
			name = name.strip(S3X6GcaiExOPtb)
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,XPL0O2VkI3w1C8enMaqi in items:
				title = name+':  '+XPL0O2VkI3w1C8enMaqi
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,801,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filter')
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST4-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('<td>التصنيف</td>.*?">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	NWtqFg91ZSKinvIwAc,jtl0KQXhgEzFPJx1V = [],[]
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('postEmbed.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		jtl0KQXhgEzFPJx1V.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
		NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__embed')
	IaYS6CrxVGb1mqiuLv = ScntgdOZCY74vNpXeW5jh8i.findall('vo_theme_dir.*?"(.*?)".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IaYS6CrxVGb1mqiuLv:
		sxCOFvhZXQ8ja6Rwf42JuU,lShZiBC3zc7yrx = IaYS6CrxVGb1mqiuLv[0]
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('postPlayer(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			mmK0X7OLtdVR6UqIEYBJuljo4ZM = ScntgdOZCY74vNpXeW5jh8i.findall('<li.*?id\,(.*?)\);">(.*?)</li>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for iImBzoXbxaChPWGKD2U8yRJprk9ft,name in mmK0X7OLtdVR6UqIEYBJuljo4ZM:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = sxCOFvhZXQ8ja6Rwf42JuU+'/temp/ajax/iframe.php?id='+lShZiBC3zc7yrx+'&video='+iImBzoXbxaChPWGKD2U8yRJprk9ft
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__watch')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pageContentDown(.*?)</table>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<tr>.*?<td>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</td>.*?href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in jtl0KQXhgEzFPJx1V:
				if '/?url=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/?url=')[1]
				jtl0KQXhgEzFPJx1V.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
				NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__download____'+uTKGhcXEIpmDf)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search: search = dR75Vq2gprfHmUcNhG()
	if not search: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/?s='+T871qPZzS4LkoMBa3Db9Q
	IGDobAKtj4kPF5V(url,'search')
	return
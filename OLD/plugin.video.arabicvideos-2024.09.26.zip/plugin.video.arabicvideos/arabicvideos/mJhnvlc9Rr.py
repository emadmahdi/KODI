# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'MYCIMA'
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_MCM_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['مصارعة حرة','wwe']
def n1zxUlcAgR(mode,url,text):
	if   mode==360: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==361: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==362: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==363: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url,text)
	elif mode==364: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'CATEGORIES___'+text)
	elif mode==365: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'FILTERS___'+text)
	elif mode==366: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==369: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text,url)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',zKREXyTHfVSNL8ZFYs,369,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',zKREXyTHfVSNL8ZFYs+'/AjaxCenter/RightBar',364)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',zKREXyTHfVSNL8ZFYs+'/AjaxCenter/RightBar',365)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-MENU-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="NavigationMenu"(.*?)class="ProductionsListButton"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('class="menu-item.*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title==nbOFVEDkpT4BIR7Qq82yPmHeJU: continue
			if any(XPL0O2VkI3w1C8enMaqi in title.lower() for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,366)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('hoverable activable(.*?)hoverable activable',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?url\((.*?)\).*?span>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,366,X79kphTKa1xLP)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Cvflxc4FMs37bmY(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if 'class="Slider--Grid"' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',url,361,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="list--Tabsui"(.*?)div',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?i>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,361)
	return
def IGDobAKtj4kPF5V(CHjGhAf3oe8w4XIQtL2cFDZb,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if '::' in CHjGhAf3oe8w4XIQtL2cFDZb:
		zb2QIaL7Y4h9g8lSck,url = CHjGhAf3oe8w4XIQtL2cFDZb.split('::')
		RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(zb2QIaL7Y4h9g8lSck,'url')
		url = RWZpkDLtY5Eyb46029MvAKmqBQd8o+url
	else: url,zb2QIaL7Y4h9g8lSck = CHjGhAf3oe8w4XIQtL2cFDZb,CHjGhAf3oe8w4XIQtL2cFDZb
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if type=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="Slider--Grid"(.*?)class="list--Tabsui"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='filters':
		eXpgPIbRv2ZMGwjm5 = [UTvsQb4HpCP3Aeo2wDZG7X5V.replace('\\/','/').replace('\\"','"')]
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="Grid--MycimaPosts"(.*?)</li></ul></div></div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('GridItem"><a href="(.*?)" title="(.*?)".*?url\((.*?)\)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
			if any(XPL0O2VkI3w1C8enMaqi in title.lower() for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			X79kphTKa1xLP = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(X79kphTKa1xLP)
			title = dCtxzeFX4GJVonm(title)
			title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			title = title.replace('مشاهدة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,363,X79kphTKa1xLP)
			elif 'حلقة' in title:
				BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) +حلقة +\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if BBuqr7CwzEIi9UL54n0AVoHXPlp: title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
				if title not in tWsVFQj47pw0L56rZfg:
					tWsVFQj47pw0L56rZfg.append(title)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,363,X79kphTKa1xLP)
			else:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,362,X79kphTKa1xLP)
		if type=='filters':
			M2RDC4XTQxmqHJ8cWNbA = ScntgdOZCY74vNpXeW5jh8i.findall('"more_button_page":(.*?),',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if M2RDC4XTQxmqHJ8cWNbA:
				count = M2RDC4XTQxmqHJ8cWNbA[0]
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+'/offset/'+count
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة أخرى',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,361,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
		elif type==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
				items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
					title = 'صفحة '+dCtxzeFX4GJVonm(title)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,361)
	return
def PXyn8J3WjhRgA(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	UTvsQb4HpCP3Aeo2wDZG7X5V = SxN0jnqr3LI(UTvsQb4HpCP3Aeo2wDZG7X5V)
	name = ScntgdOZCY74vNpXeW5jh8i.findall('itemprop="item" href=".*?/series/(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if name: name = name[-1].replace('-',S3X6GcaiExOPtb).strip('/')
	if 'موسم' in name and type==nbOFVEDkpT4BIR7Qq82yPmHeJU:
		name = name.split('موسم')[0]
		name = name.replace('مشاهدة',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
	elif 'حلقة' in name:
		name = name.split('حلقة')[0]
		name = name.replace('مشاهدة',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
	else: name = name
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="Seasons--Episodes"(.*?)</singlesection',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		if type==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if 'class' in title: continue
				if 'episode' in title: continue
				title = name+' - '+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,363,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'episodes')
		if len(LvJuOzMqk6WlP971eoGpUQ8)==0:
			eXBMHvPbDunL = ScntgdOZCY74vNpXeW5jh8i.findall('class="Episodes--Seasons--Episodes"(.*?)&&',G4JHzTEp61+'&&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXBMHvPbDunL: G4JHzTEp61 = eXBMHvPbDunL[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<episodeTitle>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				title = name+' - '+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,362)
	if len(LvJuOzMqk6WlP971eoGpUQ8)==0:
		title = ScntgdOZCY74vNpXeW5jh8i.findall('<title>(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if title: title = title[0].replace(' - ماي سيما',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('مشاهدة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else: title = 'ملف التشغيل'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,362)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	lPpY5fw3tOBcEye91Caun2FQZ = []
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('<span>التصنيف<.*?<a.*?">(.*?)<.*?">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh:
		DozYPsfmHBxWh = [DozYPsfmHBxWh[0][0],DozYPsfmHBxWh[0][1]]
		if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="WatchServersList"(.*?)class="WatchServersEmbed"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-url="(.*?)".*?strong>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if name=='سيرفر ماي سيما': name = 'mycima'
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__watch'
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="List--Download(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in items:
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			uTKGhcXEIpmDf = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d\d+',uTKGhcXEIpmDf,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if uTKGhcXEIpmDf: uTKGhcXEIpmDf = '____'+uTKGhcXEIpmDf[0]
			else: uTKGhcXEIpmDf = nbOFVEDkpT4BIR7Qq82yPmHeJU
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=mycima'+'__download'+uTKGhcXEIpmDf
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search,a3a98dOrWQ4cBbAIzC6epsu=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	lPpY5fw3tOBcEye91Caun2FQZ = ['/list','/','/list/series','/list/anime','/list/tv']
	QNscCWpA4EubS = ['الكل','الأفلام','المسلسلات','الانيمي و الكرتون','البرامج تليفزيونية']
	if showDialogs:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر النوع المطلوب:', QNscCWpA4EubS)
		if bCiGxXzDkH==-1: return
	else: bCiGxXzDkH = 0
	if a3a98dOrWQ4cBbAIzC6epsu==nbOFVEDkpT4BIR7Qq82yPmHeJU:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-SEARCH-1st')
		a3a98dOrWQ4cBbAIzC6epsu = cnPhVmgFxA.headers['Location']
		a3a98dOrWQ4cBbAIzC6epsu = a3a98dOrWQ4cBbAIzC6epsu.strip('/')
	plSscrVjkRviPwm = a3a98dOrWQ4cBbAIzC6epsu+'/search/'+search+lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	IGDobAKtj4kPF5V(plSscrVjkRviPwm)
	return
def bpRLN7ZqT5BiXKfMdI(CHjGhAf3oe8w4XIQtL2cFDZb,filter):
	if '??' in CHjGhAf3oe8w4XIQtL2cFDZb: url = CHjGhAf3oe8w4XIQtL2cFDZb.split('//getposts??')[0]
	else: url = CHjGhAf3oe8w4XIQtL2cFDZb
	filter = filter.replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='CATEGORIES':
		if Udh6nNR7sXA[0]+'==' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = Udh6nNR7sXA[0]
		for WoEZvMXa0K2suwgPl in range(len(Udh6nNR7sXA[0:-1])):
			if Udh6nNR7sXA[WoEZvMXa0K2suwgPl]+'==' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = Udh6nNR7sXA[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'==0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'==0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&&')+'___'+bhz0GBTNQdYxvnt.strip('&&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'//getposts??'+soAjtN3yd04Jzr
	elif type=='FILTERS':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'//getposts??'+RAf62IHC9L0OUl1oETijSgyxX5F
		jYzLtvxkH7R3msNZwhgeT90noEu5q = uuJH6gRYp415Vbscw9xOhelA8(plSscrVjkRviPwm,CHjGhAf3oe8w4XIQtL2cFDZb)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',jYzLtvxkH7R3msNZwhgeT90noEu5q,361,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',jYzLtvxkH7R3msNZwhgeT90noEu5q,361,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'MYCIMA-FILTERS_MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	UTvsQb4HpCP3Aeo2wDZG7X5V = UTvsQb4HpCP3Aeo2wDZG7X5V.replace('\\"','"').replace('\\/','/')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<mycima--filter(.*?)</mycima--filter>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5: return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('taxonomy="(.*?)".*?<span>(.*?)<(.*?)<filterbox',G4JHzTEp61+'<filterbox',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	dict = {}
	for TT4Yd6yIaJGxZtoR8mh2O7,name,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		name = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(name)
		if 'interest' in TT4Yd6yIaJGxZtoR8mh2O7: continue
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-term="(.*?)".*?<txt>(.*?)</txt>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if '==' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='CATEGORIES':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<=1:
				if TT4Yd6yIaJGxZtoR8mh2O7==Udh6nNR7sXA[-1]: IGDobAKtj4kPF5V(plSscrVjkRviPwm)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'CATEGORIES___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				jYzLtvxkH7R3msNZwhgeT90noEu5q = uuJH6gRYp415Vbscw9xOhelA8(plSscrVjkRviPwm,CHjGhAf3oe8w4XIQtL2cFDZb)
				if TT4Yd6yIaJGxZtoR8mh2O7==Udh6nNR7sXA[-1]:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',jYzLtvxkH7R3msNZwhgeT90noEu5q,361,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,364,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='FILTERS':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'==0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'==0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+name+': الجميع',plSscrVjkRviPwm,365,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK+'_FORGETRESULTS_')
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			name = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(name)
			PspiL81kMT4BwOIXo = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(PspiL81kMT4BwOIXo)
			if XPL0O2VkI3w1C8enMaqi=='r' or XPL0O2VkI3w1C8enMaqi=='nc-17': continue
			if any(XPL0O2VkI3w1C8enMaqi in PspiL81kMT4BwOIXo.lower() for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
			if 'http' in PspiL81kMT4BwOIXo: continue
			if 'الكل' in PspiL81kMT4BwOIXo: continue
			if 'n-a' in XPL0O2VkI3w1C8enMaqi: continue
			if PspiL81kMT4BwOIXo==nbOFVEDkpT4BIR7Qq82yPmHeJU: PspiL81kMT4BwOIXo = XPL0O2VkI3w1C8enMaqi
			TKgxmZYczq9oPUWni4ak0NM6 = PspiL81kMT4BwOIXo
			Y3Df741wvGOihEHF = ScntgdOZCY74vNpXeW5jh8i.findall('<name>(.*?)</name>',PspiL81kMT4BwOIXo,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if Y3Df741wvGOihEHF: TKgxmZYczq9oPUWni4ak0NM6 = Y3Df741wvGOihEHF[0]
			HDE69mkhQg2NaFpuUy5JRb = name+': '+TKgxmZYczq9oPUWni4ak0NM6
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = HDE69mkhQg2NaFpuUy5JRb
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'=='+TKgxmZYczq9oPUWni4ak0NM6
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&&'+TT4Yd6yIaJGxZtoR8mh2O7+'=='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			if type=='FILTERS':
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,url,365,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR+'_FORGETRESULTS_')
			elif type=='CATEGORIES' and Udh6nNR7sXA[-2]+'==' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
				zb2QIaL7Y4h9g8lSck = url+'//getposts??'+soAjtN3yd04Jzr
				jYzLtvxkH7R3msNZwhgeT90noEu5q = uuJH6gRYp415Vbscw9xOhelA8(zb2QIaL7Y4h9g8lSck,CHjGhAf3oe8w4XIQtL2cFDZb)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,jYzLtvxkH7R3msNZwhgeT90noEu5q,361,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+HDE69mkhQg2NaFpuUy5JRb,url,364,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
Udh6nNR7sXA = ['genre','release-year','nation']
PAV4cdOXGlj7WFbBnptZJ = ['mpaa','genre','release-year','category','Quality','interest','nation','language']
def uuJH6gRYp415Vbscw9xOhelA8(plSscrVjkRviPwm,zb2QIaL7Y4h9g8lSck):
	if '/AjaxCenter/RightBar' in plSscrVjkRviPwm: plSscrVjkRviPwm = plSscrVjkRviPwm.replace('/AjaxCenter/RightBar','/AjaxCenter/Filtering')
	plSscrVjkRviPwm = plSscrVjkRviPwm.replace('//getposts??','::/AjaxCenter/Filtering/')
	plSscrVjkRviPwm = plSscrVjkRviPwm.replace('==','/')
	plSscrVjkRviPwm = plSscrVjkRviPwm.replace('&&','/')
	return plSscrVjkRviPwm
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&&')
	brRAuE46JNZfie,OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = {},nbOFVEDkpT4BIR7Qq82yPmHeJU
	if '==' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('==')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	for key in PAV4cdOXGlj7WFbBnptZJ:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&&'+key+'=='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&&'+key+'=='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&&')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
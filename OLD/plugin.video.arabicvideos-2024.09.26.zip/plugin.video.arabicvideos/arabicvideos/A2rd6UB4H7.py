# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'RANDOMS'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_LST_'
Ll4EPoWi6abcN5 = 4
MPLxHeWptuU3NZ620 = 10
def n1zxUlcAgR(EYMmnJAyxV,url,J1rvN7I8eLXuS54mZ6lnUjg,ohpwd6UumaecE3IWV8lAv0,Nyb1swDcFkeGUdMEnh9itZ):
	try: Doj1K07b4tihOJq2uQEP = str(Nyb1swDcFkeGUdMEnh9itZ['folder'])
	except: Doj1K07b4tihOJq2uQEP = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if   EYMmnJAyxV==160: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif EYMmnJAyxV==161: bPFto2wZdNYrClgBIEv60DJAzu = ZIQ5zfLal3q9EXUGrvYsJD4NA1(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==162: bPFto2wZdNYrClgBIEv60DJAzu = z9mcy4KlXTROsNaErC0A(J1rvN7I8eLXuS54mZ6lnUjg,162)
	elif EYMmnJAyxV==163: bPFto2wZdNYrClgBIEv60DJAzu = z9mcy4KlXTROsNaErC0A(J1rvN7I8eLXuS54mZ6lnUjg,163)
	elif EYMmnJAyxV==164: bPFto2wZdNYrClgBIEv60DJAzu = KKVQRF4WHsGvhZ65tYTANoE7qgb(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==165: bPFto2wZdNYrClgBIEv60DJAzu = eMb5PhfnDEYLQoi1TRxH(url,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==166: bPFto2wZdNYrClgBIEv60DJAzu = InhRlxGVsyFKdT0uLQ(url,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==167: bPFto2wZdNYrClgBIEv60DJAzu = pHZ5volwh0J2Vsbx(url,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==168: bPFto2wZdNYrClgBIEv60DJAzu = i819mXEkARbPvj(url,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==761: bPFto2wZdNYrClgBIEv60DJAzu = KgdTiojMZlCQAD0B3RSrOywnsu()
	elif EYMmnJAyxV==762: bPFto2wZdNYrClgBIEv60DJAzu = XdPieHk5NwWVjlTc9sZmEag82A()
	elif EYMmnJAyxV==763: bPFto2wZdNYrClgBIEv60DJAzu = PE0gTZADYIGolaXkKUy14CJbz(Doj1K07b4tihOJq2uQEP,J1rvN7I8eLXuS54mZ6lnUjg,ohpwd6UumaecE3IWV8lAv0)
	elif EYMmnJAyxV==764: bPFto2wZdNYrClgBIEv60DJAzu = acfp0HyGxdiTPtMh27kZrW(Doj1K07b4tihOJq2uQEP,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==765: bPFto2wZdNYrClgBIEv60DJAzu = dLlYDbaGfv9PjksuEmIew(Doj1K07b4tihOJq2uQEP,J1rvN7I8eLXuS54mZ6lnUjg)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قنوات تلفزيون عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,161,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_LIVETV__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قسم عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,162,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_SITES__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,163,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_SITES__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات بحث عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,164,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_SITES__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات عشوائية من قسم',nbOFVEDkpT4BIR7Qq82yPmHeJU,763,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_SITES__RANDOM_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قنوات M3U عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,163,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_M3U__LIVE__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات M3U عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,163,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_M3U__VOD__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قسم قنوات M3U عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,162,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_M3U__LIVE__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قسم فيديو M3U عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,162,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_M3U__VOD__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات M3U بحث عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,164,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_M3U__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات M3U عشوائية من قسم',nbOFVEDkpT4BIR7Qq82yPmHeJU,765,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_M3U__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قنوات IPTV عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,163,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_IPTV__LIVE__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات IPTV عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,163,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_IPTV__VOD__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قسم قنوات IPTV عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,162,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_IPTV__LIVE__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','قسم فيديو IPTV عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,162,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_IPTV__VOD__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات IPTV بحث عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,164,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_IPTV__RANDOM__REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','فيديوهات IPTV عشوائية من قسم',nbOFVEDkpT4BIR7Qq82yPmHeJU,764,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_IPTV__RANDOM__REMEMBERRESULTS_')
	return
def KgdTiojMZlCQAD0B3RSrOywnsu():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_IPT_'+'فيديوهات جميع IPTV',nbOFVEDkpT4BIR7Qq82yPmHeJU,764)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
		TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_IP'+str(Doj1K07b4tihOJq2uQEP)+'_'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' فيديوهات مجلد '+rto0iz1Gk2xAmICHDhqR6FPnMK[Doj1K07b4tihOJq2uQEP],nbOFVEDkpT4BIR7Qq82yPmHeJU,764,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':Doj1K07b4tihOJq2uQEP})
	return
def XdPieHk5NwWVjlTc9sZmEag82A():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','_M3U_'+'فيديوهات جميع M3U',nbOFVEDkpT4BIR7Qq82yPmHeJU,765)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
		TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_MU'+str(Doj1K07b4tihOJq2uQEP)+'_'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' فيديوهات مجلد '+rto0iz1Gk2xAmICHDhqR6FPnMK[Doj1K07b4tihOJq2uQEP],nbOFVEDkpT4BIR7Qq82yPmHeJU,765,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':Doj1K07b4tihOJq2uQEP})
	return
def BV5QsMvFCdWXGy621lLz0TtxqJ(HMPtOcVoJiXCu8z0nesDWYkIl9ER):
	global ZSWln4AUDGRKY0pque,fmyL7DCRVPFEr
	UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	try:
		if 'IFILM' in HMPtOcVoJiXCu8z0nesDWYkIl9ER: UGqCc4PebSEBwON07ZpuF(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
		else: UGqCc4PebSEBwON07ZpuF()
		yNJcSsDrEHk2IBo9V = False
	except:
		ldsAFanjmVkh93ybXC()
		yNJcSsDrEHk2IBo9V = True
	HMPtOcVoJiXCu8z0nesDWYkIl9ER = wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	if yNJcSsDrEHk2IBo9V:
		SSVCGE0bOfW1w9u52yvBxocNeP(HMPtOcVoJiXCu8z0nesDWYkIl9ER,'فشل للأسف',lQMuw1PvVpAk=2000)
		ZSWln4AUDGRKY0pque += 1
		fmyL7DCRVPFEr += S3X6GcaiExOPtb+HMPtOcVoJiXCu8z0nesDWYkIl9ER
	else: SSVCGE0bOfW1w9u52yvBxocNeP(HMPtOcVoJiXCu8z0nesDWYkIl9ER,nbOFVEDkpT4BIR7Qq82yPmHeJU,lQMuw1PvVpAk=1000)
	return
def RuM0Xwo1mpE8QZNGS(jmMre9Ag5oX=True):
	global ZSWln4AUDGRKY0pque,fmyL7DCRVPFEr
	if not jmMre9Ag5oX:
		global T1tKzfJGbiuP4mkgHl3QrSNVn8
		bPFto2wZdNYrClgBIEv60DJAzu = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'dict','SECTIONS_SITES','SECTIONS_SITES_ALL')
		if bPFto2wZdNYrClgBIEv60DJAzu:
			T1tKzfJGbiuP4mkgHl3QrSNVn8 = bPFto2wZdNYrClgBIEv60DJAzu
			return
	oyNUHM3uQq = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','لكي تملئ هذه القائمة . البرنامج يحتاج أن يفحص جميع مواقع الفيديو التي في البرنامج لكي يستخرج منها فقط الأقسام الرئيسية . ثم يقوم البرنامج بخزن هذه الأقسام حتى لا تحتاج أن تملئها مرة أخرى . عملية ملئ جميع الأقسام تحتاج عادة أقل من 3 دقائق . هل تريد أن تجمع قائمة الأقسام الآن ؟')
	if oyNUHM3uQq!=1: return
	Zb4NIBy16VvWF(False,False,False)
	kkC6LPvZjgrKhc8VSdTlJWq0pui = LvJuOzMqk6WlP971eoGpUQ8
	ZSWln4AUDGRKY0pque,fmyL7DCRVPFEr,threads = 0,nbOFVEDkpT4BIR7Qq82yPmHeJU,{}
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER in GuTMSOtQEwpbx:
		lQMuw1PvVpAk.sleep(0.75)
		threads[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = eb6R0h1Fjl.Thread(target=BV5QsMvFCdWXGy621lLz0TtxqJ,args=(HMPtOcVoJiXCu8z0nesDWYkIl9ER,))
		threads[HMPtOcVoJiXCu8z0nesDWYkIl9ER].start()
		if ZSWln4AUDGRKY0pque>=MPLxHeWptuU3NZ620: break
	else:
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in list(threads.keys()): threads[HMPtOcVoJiXCu8z0nesDWYkIl9ER].join()
	LvJuOzMqk6WlP971eoGpUQ8[:] = kkC6LPvZjgrKhc8VSdTlJWq0pui
	if ZSWln4AUDGRKY0pque>=MPLxHeWptuU3NZ620: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','لديك مشكلة في '+str(ZSWln4AUDGRKY0pque)+' مواقع من مواقع البرنامج ... وسببها قد يكون عدم وجود إنترنيت في جهازك وهي:'+fmyL7DCRVPFEr)
	else:
		z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SECTIONS_SITES','SECTIONS_SITES_ALL',T1tKzfJGbiuP4mkgHl3QrSNVn8,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم جلب جميع الأقسام المتوفرة في البرنامج')
	Zb4NIBy16VvWF(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	R5VzflU0D2LQaSoKOskBuYtrXFC()
	return
def WA5iusOJpmFTE1hHrxZ2(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr):
	RRdkhxeG53A7ClaoBOzFr0c6I4bD = False
	PpoQT2OgadLG3sbY1 = LvJuOzMqk6WlP971eoGpUQ8
	LvJuOzMqk6WlP971eoGpUQ8[:] = []
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD and '_CREATENEW_' not in Hg9iNXSxJobPBr:
		bPFto2wZdNYrClgBIEv60DJAzu = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SECTIONS_IPTV','SECTIONS_IPTV_'+Doj1K07b4tihOJq2uQEP)
	elif '_LIVE_' not in Hg9iNXSxJobPBr or '_VOD_' not in Hg9iNXSxJobPBr:
		import FFiPRp8szx
		CtO9cFuULSm62PWToMlzN1 = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in Hg9iNXSxJobPBr:
			try: FFiPRp8szx.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'VOD_UNKNOWN_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـIPTV للفيديوهات',CtO9cFuULSm62PWToMlzN1)
			try: FFiPRp8szx.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'VOD_MOVIES_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـIPTV للفيديوهات',CtO9cFuULSm62PWToMlzN1)
			try: FFiPRp8szx.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'VOD_SERIES_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـIPTV للفيديوهات',CtO9cFuULSm62PWToMlzN1)
		if '_VOD_' not in Hg9iNXSxJobPBr:
			try: FFiPRp8szx.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'LIVE_UNKNOWN_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـIPTV للقنوات',CtO9cFuULSm62PWToMlzN1)
			try: FFiPRp8szx.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'LIVE_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـIPTV للقنوات',CtO9cFuULSm62PWToMlzN1)
		bPFto2wZdNYrClgBIEv60DJAzu = LvJuOzMqk6WlP971eoGpUQ8
		if RRdkhxeG53A7ClaoBOzFr0c6I4bD: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SECTIONS_IPTV','SECTIONS_IPTV_'+Doj1K07b4tihOJq2uQEP,bPFto2wZdNYrClgBIEv60DJAzu,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1
	return bPFto2wZdNYrClgBIEv60DJAzu
def kKGNdLeWQyVOwxS5CZ31lzs4RTi(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr):
	RRdkhxeG53A7ClaoBOzFr0c6I4bD = False
	PpoQT2OgadLG3sbY1 = LvJuOzMqk6WlP971eoGpUQ8
	LvJuOzMqk6WlP971eoGpUQ8[:] = []
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD and '_CREATENEW_' not in Hg9iNXSxJobPBr:
		bPFto2wZdNYrClgBIEv60DJAzu = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SECTIONS_M3U','SECTIONS_M3U_'+Doj1K07b4tihOJq2uQEP)
	elif '_LIVE_' not in Hg9iNXSxJobPBr or '_VOD_' not in Hg9iNXSxJobPBr:
		import EEdIMHGg4C
		CtO9cFuULSm62PWToMlzN1 = 'للأسف لديك مشكلة في هذا الموقع . ورسالة الخطأ كان فيها تفاصيل المشكلة . أذا المشكلة ليست حجب فجرب إرسال هذه المشكلة إلى المبرمج من قائمة خدمات البرنامج'
		if '_LIVE_' not in Hg9iNXSxJobPBr:
			try: EEdIMHGg4C.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'VOD_UNKNOWN_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـM3U للفيديوهات',CtO9cFuULSm62PWToMlzN1)
			try: EEdIMHGg4C.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'VOD_MOVIES_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـM3U للفيديوهات',CtO9cFuULSm62PWToMlzN1)
			try: EEdIMHGg4C.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'VOD_SERIES_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـM3U للفيديوهات',CtO9cFuULSm62PWToMlzN1)
		if '_VOD_' not in Hg9iNXSxJobPBr:
			try: EEdIMHGg4C.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'LIVE_UNKNOWN_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـM3U للقنوات',CtO9cFuULSm62PWToMlzN1)
			try: EEdIMHGg4C.ITqsrkfZpxUMCWVYKi9Qy(Doj1K07b4tihOJq2uQEP,'LIVE_GROUPED_SORTED',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Hg9iNXSxJobPBr+'_FORGETRESULTS__REMEMBERRESULTS_',False)
			except: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع ـM3U للقنوات',CtO9cFuULSm62PWToMlzN1)
		bPFto2wZdNYrClgBIEv60DJAzu = LvJuOzMqk6WlP971eoGpUQ8
		if RRdkhxeG53A7ClaoBOzFr0c6I4bD: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SECTIONS_M3U','SECTIONS_M3U_'+Doj1K07b4tihOJq2uQEP,bPFto2wZdNYrClgBIEv60DJAzu,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1
	return bPFto2wZdNYrClgBIEv60DJAzu
def PE0gTZADYIGolaXkKUy14CJbz(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr,ltrug2TFK5jLybRxOk6):
	if '_CREATENEW_' in Hg9iNXSxJobPBr and ltrug2TFK5jLybRxOk6==nbOFVEDkpT4BIR7Qq82yPmHeJU: RuM0Xwo1mpE8QZNGS(True)
	elif ltrug2TFK5jLybRxOk6: RuM0Xwo1mpE8QZNGS(False)
	VVSfNEFKTkc5G2X1IRjC = Hg9iNXSxJobPBr.replace('_CREATENEW_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if not ltrug2TFK5jLybRxOk6:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','تحديث هذه القائمة',nbOFVEDkpT4BIR7Qq82yPmHeJU,763,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_CREATENEW_'+VVSfNEFKTkc5G2X1IRjC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':Doj1K07b4tihOJq2uQEP})
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	VR3buw1nY8cUTpWge = ['أفلام','مسلسلات','مسرحيات','برامج','أطفال وكرتون','رمضان','أحدث-أخر','سلاسل','موسيقى','أشهر-أكثر','الآن','ضحك','رياضة','نيتفلكس','ممثلين','بث حي','دينية','سنوات','أخرى']
	bY8dgq9o0wQNLtD2 = ['افلام','movie','فيلم','فلم']
	fEIilJa9bK63uCGDLm8QxM = ['مسلسل','series']
	vvpwcQL8AkDfHWdbahsJy = ['مسارح','مسرحيات']
	Xsui0Hrwo6lah = ['برامج','show','تلفزيون','تليفزيون']
	phrPcW8Xnkd2lTA7I = ['انمي','كرتون','كارتون','kids','طفل','اطفال']
	ccXGVP8kzM7UNgQ6qDmijvsI02 = ['رمضان']
	f0GcyVKge7 = ['احدث','اخر','موخر','جديد','مضاف','حديث']
	yyZgNK1AtuT = ['سلاسل','سلسله']
	xxjaE2GkYMpOfIyBnQHP = ['اغاني','موسيقى','كليب','حفل','music']
	iCSuwFLehpB02 = ['اكثر','اشهر','مميزه','اعلى','مختاره','مختارات','اقوى']
	Rh3Plt0KeTrA = ['الان','حالي','مثبت','رائج']
	pOGuoFt9vjAz = ['ضحك','كوميدي']
	hDKbzE7HoiJs8aCqf4UnQrwydFXSm = ['رياضه','كوره','مصارعه','شوت','رياضة']
	ZcgVU8jE7e9J35NmyuD1 = ['نيتفلكس','netflix','نيتفليكس']
	RL6FrKWA13yxh58GCEUZ9Nb = ['ممثلين','اشخاص','نجوم']
	dsFVer3DMTj2iQANyPmvkYU7 = ['بث حي','live','قناه','قنوات']
	zFDO035eHNmXvR = ['دين','ادعيه','زيارات','لطميات','دعاء','قران','قصائد','رثاء','مرجعيه','اذان','اسلام','تواشيح','خطب','حوزوي','عتبات','مواليد','نواعي','عقائد','اناشيد']
	Vl0t3vLQwcSo = ['19','20','21','22','23','24','25','26']
	if not ltrug2TFK5jLybRxOk6:
		ltrug2TFK5jLybRxOk6 = 0
		for aMbCSjHrI8UOZ in VR3buw1nY8cUTpWge:
			ltrug2TFK5jLybRxOk6 += 1
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+aMbCSjHrI8UOZ,nbOFVEDkpT4BIR7Qq82yPmHeJU,763,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(ltrug2TFK5jLybRxOk6),VVSfNEFKTkc5G2X1IRjC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':Doj1K07b4tihOJq2uQEP})
	else:
		for xbfwC5hkXLvsJa8PReOS9AyU1z in sorted(list(T1tKzfJGbiuP4mkgHl3QrSNVn8.keys())):
			Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = xbfwC5hkXLvsJa8PReOS9AyU1z.lower()
			jGdXt7eADorwlv8pahNV95H6Tn2qKx = []
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in bY8dgq9o0wQNLtD2): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(1)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in fEIilJa9bK63uCGDLm8QxM): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(2)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in vvpwcQL8AkDfHWdbahsJy): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(3)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in Xsui0Hrwo6lah): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(4)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in phrPcW8Xnkd2lTA7I): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(5)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in ccXGVP8kzM7UNgQ6qDmijvsI02): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(6)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in f0GcyVKge7) and Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y not in ['اخرى']: jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(7)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in yyZgNK1AtuT): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(8)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in xxjaE2GkYMpOfIyBnQHP): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(9)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in iCSuwFLehpB02): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(10)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in Rh3Plt0KeTrA): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(11)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in pOGuoFt9vjAz): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(12)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in hDKbzE7HoiJs8aCqf4UnQrwydFXSm): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(13)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in ZcgVU8jE7e9J35NmyuD1): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(14)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in RL6FrKWA13yxh58GCEUZ9Nb): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(15)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in dsFVer3DMTj2iQANyPmvkYU7): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(16)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in zFDO035eHNmXvR): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(17)
			if any(XPL0O2VkI3w1C8enMaqi in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y for XPL0O2VkI3w1C8enMaqi in Vl0t3vLQwcSo): jGdXt7eADorwlv8pahNV95H6Tn2qKx.append(18)
			if not jGdXt7eADorwlv8pahNV95H6Tn2qKx: jGdXt7eADorwlv8pahNV95H6Tn2qKx = [19]
			for okt5ecqjYai7vu4shGJ1rflW23Q in jGdXt7eADorwlv8pahNV95H6Tn2qKx:
				if str(okt5ecqjYai7vu4shGJ1rflW23Q)==ltrug2TFK5jLybRxOk6:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+xbfwC5hkXLvsJa8PReOS9AyU1z,xbfwC5hkXLvsJa8PReOS9AyU1z,166,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,VVSfNEFKTkc5G2X1IRjC+'_REMEMBERRESULTS_')
	return
def acfp0HyGxdiTPtMh27kZrW(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr):
	RRdkhxeG53A7ClaoBOzFr0c6I4bD = False
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','تحديث هذه القائمة',nbOFVEDkpT4BIR7Qq82yPmHeJU,764,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_CREATENEW_',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':Doj1K07b4tihOJq2uQEP})
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	PpoQT2OgadLG3sbY1 = LvJuOzMqk6WlP971eoGpUQ8[:]
	import FFiPRp8szx
	if Doj1K07b4tihOJq2uQEP:
		if not FFiPRp8szx.a6KnDNd4JUIcSyf(Doj1K07b4tihOJq2uQEP,True): return
		CK1Jfvpimd0c = WA5iusOJpmFTE1hHrxZ2(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr)
		SeADMcUw2F3OYJdGiZIy6Lmk = sorted(CK1Jfvpimd0c,reverse=False,key=lambda key: key[1].lower())
	else:
		if not FFiPRp8szx.a6KnDNd4JUIcSyf(nbOFVEDkpT4BIR7Qq82yPmHeJU,True): return
		if RRdkhxeG53A7ClaoBOzFr0c6I4bD and '_CREATENEW_' not in Hg9iNXSxJobPBr:
			SeADMcUw2F3OYJdGiZIy6Lmk = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SECTIONS_IPTV','SECTIONS_IPTV_ALL')
		else:
			PxJ1Nv2dpnytGcI5e,SeADMcUw2F3OYJdGiZIy6Lmk,CK1Jfvpimd0c = [],[],[]
			for LNMrAaeP2JbxCoqZkTfpGjUE3D in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
				SeADMcUw2F3OYJdGiZIy6Lmk += WA5iusOJpmFTE1hHrxZ2(str(LNMrAaeP2JbxCoqZkTfpGjUE3D),Hg9iNXSxJobPBr)
			for type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in SeADMcUw2F3OYJdGiZIy6Lmk:
				if J1rvN7I8eLXuS54mZ6lnUjg not in PxJ1Nv2dpnytGcI5e:
					PxJ1Nv2dpnytGcI5e.append(J1rvN7I8eLXuS54mZ6lnUjg)
					y1niIpsNVeLjh7T = type,xbfwC5hkXLvsJa8PReOS9AyU1z,J1rvN7I8eLXuS54mZ6lnUjg,165,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,Hg9iNXSxJobPBr,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ
					CK1Jfvpimd0c.append(y1niIpsNVeLjh7T)
			SeADMcUw2F3OYJdGiZIy6Lmk = sorted(CK1Jfvpimd0c,reverse=False,key=lambda key: key[1].lower())
			if RRdkhxeG53A7ClaoBOzFr0c6I4bD: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SECTIONS_IPTV','SECTIONS_IPTV_ALL',SeADMcUw2F3OYJdGiZIy6Lmk,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1+SeADMcUw2F3OYJdGiZIy6Lmk
	ue186CEMORWhvq(False)
	return
def dLlYDbaGfv9PjksuEmIew(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr):
	RRdkhxeG53A7ClaoBOzFr0c6I4bD = False
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','تحديث هذه القائمة',nbOFVEDkpT4BIR7Qq82yPmHeJU,765,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_CREATENEW_',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':Doj1K07b4tihOJq2uQEP})
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	PpoQT2OgadLG3sbY1 = LvJuOzMqk6WlP971eoGpUQ8[:]
	import EEdIMHGg4C
	if Doj1K07b4tihOJq2uQEP:
		if not EEdIMHGg4C.a6KnDNd4JUIcSyf(Doj1K07b4tihOJq2uQEP,True): return
		CK1Jfvpimd0c = kKGNdLeWQyVOwxS5CZ31lzs4RTi(Doj1K07b4tihOJq2uQEP,Hg9iNXSxJobPBr)
		SeADMcUw2F3OYJdGiZIy6Lmk = sorted(CK1Jfvpimd0c,reverse=False,key=lambda key: key[1].lower())
	else:
		if not EEdIMHGg4C.a6KnDNd4JUIcSyf(nbOFVEDkpT4BIR7Qq82yPmHeJU,True): return
		if RRdkhxeG53A7ClaoBOzFr0c6I4bD and '_CREATENEW_' not in Hg9iNXSxJobPBr:
			SeADMcUw2F3OYJdGiZIy6Lmk = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SECTIONS_M3U','SECTIONS_M3U_ALL')
		else:
			PxJ1Nv2dpnytGcI5e,SeADMcUw2F3OYJdGiZIy6Lmk,CK1Jfvpimd0c = [],[],[]
			for LNMrAaeP2JbxCoqZkTfpGjUE3D in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
				SeADMcUw2F3OYJdGiZIy6Lmk += kKGNdLeWQyVOwxS5CZ31lzs4RTi(str(LNMrAaeP2JbxCoqZkTfpGjUE3D),Hg9iNXSxJobPBr)
			for type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in SeADMcUw2F3OYJdGiZIy6Lmk:
				if J1rvN7I8eLXuS54mZ6lnUjg not in PxJ1Nv2dpnytGcI5e:
					PxJ1Nv2dpnytGcI5e.append(J1rvN7I8eLXuS54mZ6lnUjg)
					y1niIpsNVeLjh7T = type,xbfwC5hkXLvsJa8PReOS9AyU1z,J1rvN7I8eLXuS54mZ6lnUjg,165,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,Hg9iNXSxJobPBr,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ
					CK1Jfvpimd0c.append(y1niIpsNVeLjh7T)
			SeADMcUw2F3OYJdGiZIy6Lmk = sorted(CK1Jfvpimd0c,reverse=False,key=lambda key: key[1].lower())
			if RRdkhxeG53A7ClaoBOzFr0c6I4bD: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SECTIONS_M3U','SECTIONS_M3U_ALL',SeADMcUw2F3OYJdGiZIy6Lmk,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1+SeADMcUw2F3OYJdGiZIy6Lmk
	ue186CEMORWhvq(False)
	return
def eMb5PhfnDEYLQoi1TRxH(group,Hg9iNXSxJobPBr):
	RRdkhxeG53A7ClaoBOzFr0c6I4bD = False
	bPFto2wZdNYrClgBIEv60DJAzu = []
	bHIR4ymEshnerZQ = '_IPTV_' if 'IPTV' in Hg9iNXSxJobPBr else '_M3U_'
	if RRdkhxeG53A7ClaoBOzFr0c6I4bD: bPFto2wZdNYrClgBIEv60DJAzu = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SECTIONS'+bHIR4ymEshnerZQ[:-1],group)
	if not bPFto2wZdNYrClgBIEv60DJAzu:
		for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			if RRdkhxeG53A7ClaoBOzFr0c6I4bD: bPFto2wZdNYrClgBIEv60DJAzu += r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','SECTIONS'+bHIR4ymEshnerZQ[:-1],'SECTIONS'+bHIR4ymEshnerZQ+str(Doj1K07b4tihOJq2uQEP))
			elif bHIR4ymEshnerZQ=='_IPTV_': bPFto2wZdNYrClgBIEv60DJAzu += WA5iusOJpmFTE1hHrxZ2(str(Doj1K07b4tihOJq2uQEP),'_CREATENEW_')
			elif bHIR4ymEshnerZQ=='_M3U_': bPFto2wZdNYrClgBIEv60DJAzu += kKGNdLeWQyVOwxS5CZ31lzs4RTi(str(Doj1K07b4tihOJq2uQEP),'_CREATENEW_')
		for type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in bPFto2wZdNYrClgBIEv60DJAzu:
			if J1rvN7I8eLXuS54mZ6lnUjg==group: QHAgKDUZvqTES8VMh(type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
		items,XhE8FpdTjG = [],[]
		for type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in LvJuOzMqk6WlP971eoGpUQ8:
			LilorgIj7wn8BuUvtcTf = type,xbfwC5hkXLvsJa8PReOS9AyU1z[4:],url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,nbOFVEDkpT4BIR7Qq82yPmHeJU
			if LilorgIj7wn8BuUvtcTf not in XhE8FpdTjG:
				XhE8FpdTjG.append(LilorgIj7wn8BuUvtcTf)
				xB2lOZNsPvFQDC4gMz = type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ
				items.append(xB2lOZNsPvFQDC4gMz)
		bPFto2wZdNYrClgBIEv60DJAzu = sorted(items,reverse=False,key=lambda key: key[1].lower()[5:])
		if RRdkhxeG53A7ClaoBOzFr0c6I4bD: z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'SECTIONS'+bHIR4ymEshnerZQ[:-1],group,bPFto2wZdNYrClgBIEv60DJAzu,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	if '_RANDOM_' in Hg9iNXSxJobPBr and len(bPFto2wZdNYrClgBIEv60DJAzu)>Ll4EPoWi6abcN5:
		LvJuOzMqk6WlP971eoGpUQ8[:] = []
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','['+eMypvI8XqHjYU02anWD9gsSrkt+group+c7gxFyUCGm+' :القسم]',group,165,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bHIR4ymEshnerZQ+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة الطلب العشوائي من نفس القسم',group,165,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,bHIR4ymEshnerZQ+'_RANDOM__FORGETRESULTS__REMEMBERRESULTS_')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		bPFto2wZdNYrClgBIEv60DJAzu = LvJuOzMqk6WlP971eoGpUQ8+eH7yw1hTGUROK2B4dcP0iEr.sample(bPFto2wZdNYrClgBIEv60DJAzu,Ll4EPoWi6abcN5)
	LvJuOzMqk6WlP971eoGpUQ8[:] = bPFto2wZdNYrClgBIEv60DJAzu
	ue186CEMORWhvq(False)
	return
def ZIQ5zfLal3q9EXUGrvYsJD4NA1(Hg9iNXSxJobPBr):
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة طلب قنوات عشوائية',nbOFVEDkpT4BIR7Qq82yPmHeJU,161,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS__LIVETV__RANDOM_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	akBHbUq27KouOLVhyrg = LvJuOzMqk6WlP971eoGpUQ8[:]
	LvJuOzMqk6WlP971eoGpUQ8[:] = []
	import DqbknNGvlo
	DqbknNGvlo.KwinXTzJv1N8yghA9UbI0HueGqa7R('0',False)
	DqbknNGvlo.KwinXTzJv1N8yghA9UbI0HueGqa7R('1',False)
	DqbknNGvlo.KwinXTzJv1N8yghA9UbI0HueGqa7R('2',False)
	if '_RANDOM_' in Hg9iNXSxJobPBr:
		LvJuOzMqk6WlP971eoGpUQ8[:] = ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8)
		if len(LvJuOzMqk6WlP971eoGpUQ8)>Ll4EPoWi6abcN5: LvJuOzMqk6WlP971eoGpUQ8[:] = eH7yw1hTGUROK2B4dcP0iEr.sample(LvJuOzMqk6WlP971eoGpUQ8,Ll4EPoWi6abcN5)
	LvJuOzMqk6WlP971eoGpUQ8[:] = akBHbUq27KouOLVhyrg+LvJuOzMqk6WlP971eoGpUQ8
	return
def KKVQRF4WHsGvhZ65tYTANoE7qgb(Hg9iNXSxJobPBr):
	Hg9iNXSxJobPBr = Hg9iNXSxJobPBr.replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
	url = 'https://www.bestrandoms.com/random-arabic-words'
	data = {'quantity':'50'}
	data = hS5pZyveLR0Ju4EksT2jQ9mrU(data)
	cnPhVmgFxA = t57SmWGkHCXd4yq(JzS2mVAKR9iCMwc0b5Pvx7h3GpIOl,'GET',url,data,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'RANDOMS-RANDOM_VIDEOS_FROM_WORDS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="content"(.*?)class="clearfix"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<span>(.*?)</span>.*?<span>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	Pr5iEIkWXYytABU,LL51BadhTk4uv = list(zip(*items))
	rt8vhCXWmi = []
	Fzd8Q1hbLge = [S3X6GcaiExOPtb,'"','`',',','.',':',';',"'",'-']
	b1L0Temj6olF8Uq2H = LL51BadhTk4uv+Pr5iEIkWXYytABU
	for wLvR5SaIrz in b1L0Temj6olF8Uq2H:
		if wLvR5SaIrz in LL51BadhTk4uv: I2IsL63K8cEFfaWyYOrU5zb9 = 2
		if wLvR5SaIrz in Pr5iEIkWXYytABU: I2IsL63K8cEFfaWyYOrU5zb9 = 4
		Tgz0aVnHGZPeymw5Rhv9B42W1dt7xb = [WoEZvMXa0K2suwgPl in wLvR5SaIrz for WoEZvMXa0K2suwgPl in Fzd8Q1hbLge]
		if any(Tgz0aVnHGZPeymw5Rhv9B42W1dt7xb):
			wX9P3dR07B5HynVa8 = Tgz0aVnHGZPeymw5Rhv9B42W1dt7xb.index(True)
			kFtAW6DU31HKv98Xam = Fzd8Q1hbLge[wX9P3dR07B5HynVa8]
			OBAWGqkemvD = nbOFVEDkpT4BIR7Qq82yPmHeJU
			if wLvR5SaIrz.count(kFtAW6DU31HKv98Xam)>1: MMuEXaSDz3bvAVQT1P65gf,Cyb9AeIkcYVG01JKX2HrsO,OBAWGqkemvD = wLvR5SaIrz.split(kFtAW6DU31HKv98Xam,2)
			else: MMuEXaSDz3bvAVQT1P65gf,Cyb9AeIkcYVG01JKX2HrsO = wLvR5SaIrz.split(kFtAW6DU31HKv98Xam,1)
			if len(MMuEXaSDz3bvAVQT1P65gf)>I2IsL63K8cEFfaWyYOrU5zb9: rt8vhCXWmi.append(MMuEXaSDz3bvAVQT1P65gf.lower())
			if len(Cyb9AeIkcYVG01JKX2HrsO)>I2IsL63K8cEFfaWyYOrU5zb9: rt8vhCXWmi.append(Cyb9AeIkcYVG01JKX2HrsO.lower())
			if len(OBAWGqkemvD)>I2IsL63K8cEFfaWyYOrU5zb9: rt8vhCXWmi.append(OBAWGqkemvD.lower())
		elif len(wLvR5SaIrz)>I2IsL63K8cEFfaWyYOrU5zb9: rt8vhCXWmi.append(wLvR5SaIrz.lower())
	for WoEZvMXa0K2suwgPl in range(9): eH7yw1hTGUROK2B4dcP0iEr.shuffle(rt8vhCXWmi)
	if '_SITES_' in Hg9iNXSxJobPBr:
		F2OJUpyCkL6b91V4ilSx8 = bdUDyYZK6lieXvtP
	elif '_IPTV_' in Hg9iNXSxJobPBr:
		F2OJUpyCkL6b91V4ilSx8 = ['IPTV']
		import FFiPRp8szx
		if not FFiPRp8szx.a6KnDNd4JUIcSyf(nbOFVEDkpT4BIR7Qq82yPmHeJU,True): return
	elif '_M3U_' in Hg9iNXSxJobPBr:
		F2OJUpyCkL6b91V4ilSx8 = ['M3U']
		import EEdIMHGg4C
		if not EEdIMHGg4C.a6KnDNd4JUIcSyf(nbOFVEDkpT4BIR7Qq82yPmHeJU,True): return
	count,CCeK5NWvj9sc6d0pwyfrBSDh2I7OFk = 0,0
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','[  ] :البحث عن',nbOFVEDkpT4BIR7Qq82yPmHeJU,164,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+Hg9iNXSxJobPBr)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة البحث العشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,164,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+Hg9iNXSxJobPBr)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	lWeqC6yRPJpbXUZs7 = LvJuOzMqk6WlP971eoGpUQ8[:]
	LvJuOzMqk6WlP971eoGpUQ8[:] = []
	FImBTjbCrG2tfvMZNHYVQ1x = []
	for wLvR5SaIrz in rt8vhCXWmi:
		Cyb9AeIkcYVG01JKX2HrsO = ScntgdOZCY74vNpXeW5jh8i.findall('[ \,\;\:\-\+\=\"\'\[\]\(\)\{\}\!\@'+'#'+'\$\%\^\&\*\_\<\>]',wLvR5SaIrz,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if Cyb9AeIkcYVG01JKX2HrsO: wLvR5SaIrz = wLvR5SaIrz.split(Cyb9AeIkcYVG01JKX2HrsO[0],1)[0]
		lJbPa3OjwkHtLhr1 = wLvR5SaIrz.replace('ّ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('َ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ً',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ُ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٌ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		lJbPa3OjwkHtLhr1 = lJbPa3OjwkHtLhr1.replace('ِ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٍ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ْ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('،',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ـ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if lJbPa3OjwkHtLhr1: FImBTjbCrG2tfvMZNHYVQ1x.append(lJbPa3OjwkHtLhr1)
	YR4QVKoJCEN7v5F6fxlhpdGwIt2nA = []
	for HT4fGXqv8hEcKsJ in range(0,20):
		search = eH7yw1hTGUROK2B4dcP0iEr.sample(FImBTjbCrG2tfvMZNHYVQ1x,1)[0]
		if search in YR4QVKoJCEN7v5F6fxlhpdGwIt2nA: continue
		YR4QVKoJCEN7v5F6fxlhpdGwIt2nA.append(search)
		HMPtOcVoJiXCu8z0nesDWYkIl9ER = eH7yw1hTGUROK2B4dcP0iEr.sample(F2OJUpyCkL6b91V4ilSx8,1)[0]
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Random Video Search   site:'+str(HMPtOcVoJiXCu8z0nesDWYkIl9ER)+'  search:'+search)
		UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
		Nwj2WURK7qbY6coiBdMDzuS(search+'_NODIALOGS_')
		if len(LvJuOzMqk6WlP971eoGpUQ8)>0: break
	search = search.replace('_MOD_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	lWeqC6yRPJpbXUZs7[0][1] = '['+eMypvI8XqHjYU02anWD9gsSrkt+search+c7gxFyUCGm+' :بحث عن]'
	LvJuOzMqk6WlP971eoGpUQ8[:] = ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8)
	if len(LvJuOzMqk6WlP971eoGpUQ8)>Ll4EPoWi6abcN5: LvJuOzMqk6WlP971eoGpUQ8[:] = eH7yw1hTGUROK2B4dcP0iEr.sample(LvJuOzMqk6WlP971eoGpUQ8,Ll4EPoWi6abcN5)
	LvJuOzMqk6WlP971eoGpUQ8[:] = lWeqC6yRPJpbXUZs7+LvJuOzMqk6WlP971eoGpUQ8
	return
def InhRlxGVsyFKdT0uLQ(q7nvcHhsJr1wRkXKMEjtIACZ6g2P,Hg9iNXSxJobPBr):
	q7nvcHhsJr1wRkXKMEjtIACZ6g2P = q7nvcHhsJr1wRkXKMEjtIACZ6g2P.replace('_MOD_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	Hg9iNXSxJobPBr = Hg9iNXSxJobPBr.replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	RuM0Xwo1mpE8QZNGS(False)
	if T1tKzfJGbiuP4mkgHl3QrSNVn8=={}: return
	if '_RANDOM_' in Hg9iNXSxJobPBr:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','['+eMypvI8XqHjYU02anWD9gsSrkt+q7nvcHhsJr1wRkXKMEjtIACZ6g2P+c7gxFyUCGm+' :القسم]',q7nvcHhsJr1wRkXKMEjtIACZ6g2P,166,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+Hg9iNXSxJobPBr)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة الطلب العشوائي من نفس القسم',q7nvcHhsJr1wRkXKMEjtIACZ6g2P,166,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+Hg9iNXSxJobPBr)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	for website in sorted(list(T1tKzfJGbiuP4mkgHl3QrSNVn8[q7nvcHhsJr1wRkXKMEjtIACZ6g2P].keys())):
		type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = T1tKzfJGbiuP4mkgHl3QrSNVn8[q7nvcHhsJr1wRkXKMEjtIACZ6g2P][website]
		if '_RANDOM_' in Hg9iNXSxJobPBr or len(T1tKzfJGbiuP4mkgHl3QrSNVn8[q7nvcHhsJr1wRkXKMEjtIACZ6g2P])==1:
			QHAgKDUZvqTES8VMh(type,nbOFVEDkpT4BIR7Qq82yPmHeJU,url,tWCYOJ19zpPNAawmf,nbOFVEDkpT4BIR7Qq82yPmHeJU,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			LvJuOzMqk6WlP971eoGpUQ8[:] = ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8)
			PpoQT2OgadLG3sbY1,SeADMcUw2F3OYJdGiZIy6Lmk = LvJuOzMqk6WlP971eoGpUQ8[:3],LvJuOzMqk6WlP971eoGpUQ8[3:]
			for WoEZvMXa0K2suwgPl in range(9): eH7yw1hTGUROK2B4dcP0iEr.shuffle(SeADMcUw2F3OYJdGiZIy6Lmk)
			if '_RANDOM_' in Hg9iNXSxJobPBr: LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1+SeADMcUw2F3OYJdGiZIy6Lmk[:Ll4EPoWi6abcN5]
			else: LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1+SeADMcUw2F3OYJdGiZIy6Lmk
		elif '_SITES_' in Hg9iNXSxJobPBr: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',website,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
	return
def z9mcy4KlXTROsNaErC0A(Hg9iNXSxJobPBr,EYMmnJAyxV):
	Hg9iNXSxJobPBr = Hg9iNXSxJobPBr.replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	xbfwC5hkXLvsJa8PReOS9AyU1z,J4zrN2XlHnEOfTuve1QUm0d7p = nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','['+eMypvI8XqHjYU02anWD9gsSrkt+xbfwC5hkXLvsJa8PReOS9AyU1z+c7gxFyUCGm+' :القسم]',nbOFVEDkpT4BIR7Qq82yPmHeJU,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+Hg9iNXSxJobPBr)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة طلب قسم عشوائي',nbOFVEDkpT4BIR7Qq82yPmHeJU,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+Hg9iNXSxJobPBr)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	PpoQT2OgadLG3sbY1 = LvJuOzMqk6WlP971eoGpUQ8[:]
	LvJuOzMqk6WlP971eoGpUQ8[:] = []
	bPFto2wZdNYrClgBIEv60DJAzu = []
	if '_SITES_' in Hg9iNXSxJobPBr:
		RuM0Xwo1mpE8QZNGS(False)
		if T1tKzfJGbiuP4mkgHl3QrSNVn8=={}: return
		umSy5WK1Uco3TMV = list(T1tKzfJGbiuP4mkgHl3QrSNVn8.keys())
		q7nvcHhsJr1wRkXKMEjtIACZ6g2P = eH7yw1hTGUROK2B4dcP0iEr.sample(umSy5WK1Uco3TMV,1)[0]
		rt8vhCXWmi = list(T1tKzfJGbiuP4mkgHl3QrSNVn8[q7nvcHhsJr1wRkXKMEjtIACZ6g2P].keys())
		website = eH7yw1hTGUROK2B4dcP0iEr.sample(rt8vhCXWmi,1)[0]
		type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = T1tKzfJGbiuP4mkgHl3QrSNVn8[q7nvcHhsJr1wRkXKMEjtIACZ6g2P][website]
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Random Category   website: '+website+'   name: '+xbfwC5hkXLvsJa8PReOS9AyU1z+'   url: '+url+'   mode: '+str(tWCYOJ19zpPNAawmf))
	elif '_IPTV_' in Hg9iNXSxJobPBr:
		import FFiPRp8szx
		if not FFiPRp8szx.a6KnDNd4JUIcSyf(nbOFVEDkpT4BIR7Qq82yPmHeJU,True): return
		for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			bPFto2wZdNYrClgBIEv60DJAzu += WA5iusOJpmFTE1hHrxZ2(str(Doj1K07b4tihOJq2uQEP),Hg9iNXSxJobPBr)
		if not bPFto2wZdNYrClgBIEv60DJAzu: return
		type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = eH7yw1hTGUROK2B4dcP0iEr.sample(bPFto2wZdNYrClgBIEv60DJAzu,1)[0]
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Random Category   name: '+xbfwC5hkXLvsJa8PReOS9AyU1z+'   url: '+url+'   mode: '+str(tWCYOJ19zpPNAawmf))
	elif '_M3U_' in Hg9iNXSxJobPBr:
		import EEdIMHGg4C
		if not EEdIMHGg4C.a6KnDNd4JUIcSyf(nbOFVEDkpT4BIR7Qq82yPmHeJU,True): return
		for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			bPFto2wZdNYrClgBIEv60DJAzu += kKGNdLeWQyVOwxS5CZ31lzs4RTi(str(Doj1K07b4tihOJq2uQEP),Hg9iNXSxJobPBr)
		if not bPFto2wZdNYrClgBIEv60DJAzu: return
		type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = eH7yw1hTGUROK2B4dcP0iEr.sample(bPFto2wZdNYrClgBIEv60DJAzu,1)[0]
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Random Category   name: '+xbfwC5hkXLvsJa8PReOS9AyU1z+'   url: '+url+'   mode: '+str(tWCYOJ19zpPNAawmf))
	R8QHaq31WDEieKjBY7 = xbfwC5hkXLvsJa8PReOS9AyU1z
	UUdC5PkuMVjyeaxl891r = []
	for WoEZvMXa0K2suwgPl in range(0,10):
		if WoEZvMXa0K2suwgPl>0: fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   Random Category   name: '+xbfwC5hkXLvsJa8PReOS9AyU1z+'   url: '+url+'   mode: '+str(tWCYOJ19zpPNAawmf))
		LvJuOzMqk6WlP971eoGpUQ8[:] = []
		if tWCYOJ19zpPNAawmf==234 and '__IPTVSeries__' in J1rvN7I8eLXuS54mZ6lnUjg: tWCYOJ19zpPNAawmf = 233
		if tWCYOJ19zpPNAawmf==714 and '__M3USeries__' in J1rvN7I8eLXuS54mZ6lnUjg: tWCYOJ19zpPNAawmf = 713
		if tWCYOJ19zpPNAawmf==144: tWCYOJ19zpPNAawmf = 291
		uiazRbmZ63Je21WGqn = QHAgKDUZvqTES8VMh(type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ)
		if '_IPTV_' in Hg9iNXSxJobPBr and tWCYOJ19zpPNAawmf==167: del LvJuOzMqk6WlP971eoGpUQ8[:3]
		if '_M3U_' in Hg9iNXSxJobPBr and tWCYOJ19zpPNAawmf==168: del LvJuOzMqk6WlP971eoGpUQ8[:3]
		J4zrN2XlHnEOfTuve1QUm0d7p[:] = ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8)
		if UUdC5PkuMVjyeaxl891r and YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'حلقة') in str(J4zrN2XlHnEOfTuve1QUm0d7p) or YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'حلقه') in str(J4zrN2XlHnEOfTuve1QUm0d7p):
			xbfwC5hkXLvsJa8PReOS9AyU1z = R8QHaq31WDEieKjBY7
			J4zrN2XlHnEOfTuve1QUm0d7p[:] = UUdC5PkuMVjyeaxl891r
			break
		R8QHaq31WDEieKjBY7 = xbfwC5hkXLvsJa8PReOS9AyU1z
		UUdC5PkuMVjyeaxl891r = J4zrN2XlHnEOfTuve1QUm0d7p
		if str(J4zrN2XlHnEOfTuve1QUm0d7p).count('video')>0: break
		if str(J4zrN2XlHnEOfTuve1QUm0d7p).count('live')>0: break
		if tWCYOJ19zpPNAawmf==233: break
		if tWCYOJ19zpPNAawmf==713: break
		if tWCYOJ19zpPNAawmf==291: break
		if J4zrN2XlHnEOfTuve1QUm0d7p: type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,tWCYOJ19zpPNAawmf,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = eH7yw1hTGUROK2B4dcP0iEr.sample(J4zrN2XlHnEOfTuve1QUm0d7p,1)[0]
	if not xbfwC5hkXLvsJa8PReOS9AyU1z: xbfwC5hkXLvsJa8PReOS9AyU1z = '....'
	elif xbfwC5hkXLvsJa8PReOS9AyU1z.count('_')>1: xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.split('_',2)[2]
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('UNKNOWN: ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	xbfwC5hkXLvsJa8PReOS9AyU1z = xbfwC5hkXLvsJa8PReOS9AyU1z.replace('_MOD_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	PpoQT2OgadLG3sbY1[0][1] = '['+eMypvI8XqHjYU02anWD9gsSrkt+xbfwC5hkXLvsJa8PReOS9AyU1z+c7gxFyUCGm+' :القسم]'
	for WoEZvMXa0K2suwgPl in range(9): eH7yw1hTGUROK2B4dcP0iEr.shuffle(J4zrN2XlHnEOfTuve1QUm0d7p)
	if '_RANDOM_' in Hg9iNXSxJobPBr: LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1+J4zrN2XlHnEOfTuve1QUm0d7p[:Ll4EPoWi6abcN5]
	else: LvJuOzMqk6WlP971eoGpUQ8[:] = PpoQT2OgadLG3sbY1+J4zrN2XlHnEOfTuve1QUm0d7p
	return
def pHZ5volwh0J2Vsbx(PmTiVkSbUx0HFGKXg8udNwhLQY7,LYtNbGJwdPiAn3kqE2):
	LYtNbGJwdPiAn3kqE2 = LYtNbGJwdPiAn3kqE2.replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	wwgI9uNP30OM4ZphKWseqDB = LYtNbGJwdPiAn3kqE2
	if '__IPTVSeries__' in LYtNbGJwdPiAn3kqE2:
		wwgI9uNP30OM4ZphKWseqDB = LYtNbGJwdPiAn3kqE2.split('__IPTVSeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in PmTiVkSbUx0HFGKXg8udNwhLQY7: type = ',VIDEOS: '
	elif 'LIVE' in PmTiVkSbUx0HFGKXg8udNwhLQY7: type = ',LIVE: '
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','['+eMypvI8XqHjYU02anWD9gsSrkt+type+wwgI9uNP30OM4ZphKWseqDB+c7gxFyUCGm+' :القسم]',PmTiVkSbUx0HFGKXg8udNwhLQY7,167,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+LYtNbGJwdPiAn3kqE2)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة الطلب العشوائي من نفس القسم',PmTiVkSbUx0HFGKXg8udNwhLQY7,167,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+LYtNbGJwdPiAn3kqE2)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	import FFiPRp8szx
	for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
		if '__IPTVSeries__' in LYtNbGJwdPiAn3kqE2: FFiPRp8szx.ITqsrkfZpxUMCWVYKi9Qy(str(Doj1K07b4tihOJq2uQEP),PmTiVkSbUx0HFGKXg8udNwhLQY7,LYtNbGJwdPiAn3kqE2,nbOFVEDkpT4BIR7Qq82yPmHeJU,False)
		else: FFiPRp8szx.KwinXTzJv1N8yghA9UbI0HueGqa7R(str(Doj1K07b4tihOJq2uQEP),PmTiVkSbUx0HFGKXg8udNwhLQY7,LYtNbGJwdPiAn3kqE2,nbOFVEDkpT4BIR7Qq82yPmHeJU,False)
	LvJuOzMqk6WlP971eoGpUQ8[:] = ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8)
	if len(LvJuOzMqk6WlP971eoGpUQ8)>(Ll4EPoWi6abcN5+3): LvJuOzMqk6WlP971eoGpUQ8[:] = LvJuOzMqk6WlP971eoGpUQ8[:3]+eH7yw1hTGUROK2B4dcP0iEr.sample(LvJuOzMqk6WlP971eoGpUQ8[3:],Ll4EPoWi6abcN5)
	return
def i819mXEkARbPvj(PmTiVkSbUx0HFGKXg8udNwhLQY7,LYtNbGJwdPiAn3kqE2):
	LYtNbGJwdPiAn3kqE2 = LYtNbGJwdPiAn3kqE2.replace('_FORGETRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	wwgI9uNP30OM4ZphKWseqDB = LYtNbGJwdPiAn3kqE2
	if '__M3USeries__' in LYtNbGJwdPiAn3kqE2:
		wwgI9uNP30OM4ZphKWseqDB = LYtNbGJwdPiAn3kqE2.split('__M3USeries__')[0]
		type = ',SERIES: '
	elif 'VOD' in PmTiVkSbUx0HFGKXg8udNwhLQY7: type = ',VIDEOS: '
	elif 'LIVE' in PmTiVkSbUx0HFGKXg8udNwhLQY7: type = ',LIVE: '
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','['+eMypvI8XqHjYU02anWD9gsSrkt+type+wwgI9uNP30OM4ZphKWseqDB+c7gxFyUCGm+' :القسم]',PmTiVkSbUx0HFGKXg8udNwhLQY7,168,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+LYtNbGJwdPiAn3kqE2)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','إعادة الطلب العشوائي من نفس القسم',PmTiVkSbUx0HFGKXg8udNwhLQY7,168,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_FORGETRESULTS__REMEMBERRESULTS_'+LYtNbGJwdPiAn3kqE2)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	import EEdIMHGg4C
	for Doj1K07b4tihOJq2uQEP in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
		if '__M3USeries__' in LYtNbGJwdPiAn3kqE2: EEdIMHGg4C.ITqsrkfZpxUMCWVYKi9Qy(str(Doj1K07b4tihOJq2uQEP),PmTiVkSbUx0HFGKXg8udNwhLQY7,LYtNbGJwdPiAn3kqE2,nbOFVEDkpT4BIR7Qq82yPmHeJU,False)
		else: EEdIMHGg4C.KwinXTzJv1N8yghA9UbI0HueGqa7R(str(Doj1K07b4tihOJq2uQEP),PmTiVkSbUx0HFGKXg8udNwhLQY7,LYtNbGJwdPiAn3kqE2,nbOFVEDkpT4BIR7Qq82yPmHeJU,False)
	LvJuOzMqk6WlP971eoGpUQ8[:] = ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8)
	if len(LvJuOzMqk6WlP971eoGpUQ8)>(Ll4EPoWi6abcN5+3): LvJuOzMqk6WlP971eoGpUQ8[:] = LvJuOzMqk6WlP971eoGpUQ8[:3]+eH7yw1hTGUROK2B4dcP0iEr.sample(LvJuOzMqk6WlP971eoGpUQ8[3:],Ll4EPoWi6abcN5)
	return
def ilfhEWePod3XLUDV(LvJuOzMqk6WlP971eoGpUQ8):
	J4zrN2XlHnEOfTuve1QUm0d7p = []
	for type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ in LvJuOzMqk6WlP971eoGpUQ8:
		if 'صفحة' in xbfwC5hkXLvsJa8PReOS9AyU1z or 'صفحه' in xbfwC5hkXLvsJa8PReOS9AyU1z or 'page' in xbfwC5hkXLvsJa8PReOS9AyU1z.lower(): continue
		J4zrN2XlHnEOfTuve1QUm0d7p.append([type,xbfwC5hkXLvsJa8PReOS9AyU1z,url,EYMmnJAyxV,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,J1rvN7I8eLXuS54mZ6lnUjg,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ])
	return J4zrN2XlHnEOfTuve1QUm0d7p
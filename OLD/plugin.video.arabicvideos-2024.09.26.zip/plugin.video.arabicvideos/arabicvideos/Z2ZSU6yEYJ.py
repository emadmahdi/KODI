# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
VGjzYJZykfEWxlQLeap = 'FAVORITES'
def z4CledbofIyhpZVjugFO(EYMmnJAyxV,YmroH2wlN1):
	if   EYMmnJAyxV==270: UmwA0cdOSg2s7vnKR8zYp4ohWqH = hraw5mCZRvLQxX1iH(YmroH2wlN1)
	else: UmwA0cdOSg2s7vnKR8zYp4ohWqH = False
	return UmwA0cdOSg2s7vnKR8zYp4ohWqH
def YOqPCEczglNJma4xWU3QebRXwA2(R0gbu46Cw9ZKhB5jsT8HAcGv,YmroH2wlN1,qq84DwbLkI2TQV6emS9):
	if not R0gbu46Cw9ZKhB5jsT8HAcGv: return
	if   qq84DwbLkI2TQV6emS9=='UP1'	: jnC4MqkN8wtaWFeVIrS7zo(YmroH2wlN1,True,vkIa3ijEQVsJGdWOXwK7bnue9ADR)
	elif qq84DwbLkI2TQV6emS9=='DOWN1'	: jnC4MqkN8wtaWFeVIrS7zo(YmroH2wlN1,False,vkIa3ijEQVsJGdWOXwK7bnue9ADR)
	elif qq84DwbLkI2TQV6emS9=='UP4'	: jnC4MqkN8wtaWFeVIrS7zo(YmroH2wlN1,True,WtDrnpJmwQ37Z2Ae68hu4BY5M1)
	elif qq84DwbLkI2TQV6emS9=='DOWN4'	: jnC4MqkN8wtaWFeVIrS7zo(YmroH2wlN1,False,WtDrnpJmwQ37Z2Ae68hu4BY5M1)
	elif qq84DwbLkI2TQV6emS9=='ADD1'	: gFhjXlyqC6uGTDxEbreBcWYOnRk8Z(YmroH2wlN1)
	elif qq84DwbLkI2TQV6emS9=='REMOVE1': RCDGNM0SlmZVw342Bst8uTkXbgLrdP(YmroH2wlN1)
	elif qq84DwbLkI2TQV6emS9=='DELETELIST': RW1F2ieq4TSXVoE86pH5chlsyLIrd(YmroH2wlN1)
	return
def hraw5mCZRvLQxX1iH(YmroH2wlN1):
	hMoSuPWCiGAJKw8HRfgTVa = X48cC9SbOl6v20AU7HgEF3i()
	if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()):
		try:
			kMKrEecAFghlQwGBn5Zyt = hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]
			if f4fTutDOEwUeIoPLRQ and YmroH2wlN1 in ['5','11','12','13']:
				for iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL in kMKrEecAFghlQwGBn5Zyt:
					if iiyAEbQ5f80=='video':
						Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',eMypvI8XqHjYU02anWD9gsSrkt+'تشغيل من الأعلى إلى الأسفل'+c7gxFyUCGm,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv)
						Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
						break
			for iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL in kMKrEecAFghlQwGBn5Zyt:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL)
		except:
			hMoSuPWCiGAJKw8HRfgTVa = LjfICzo9TkNMZ1PSaFW5vl3b0(g8FzaRfU7Zx9HeSBNtJ)
			kMKrEecAFghlQwGBn5Zyt = hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]
			for iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL in kMKrEecAFghlQwGBn5Zyt:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL)
	return
def gFhjXlyqC6uGTDxEbreBcWYOnRk8Z(YmroH2wlN1):
	iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	if YmroH2wlN1 in ['5','11','12','13'] and iiyAEbQ5f80!='video':
		aY7RFmnWc5uU9T3Q0Mxq4('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	lLORW1akG2FBgoyfd0C39pnVcj = iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL
	hMoSuPWCiGAJKw8HRfgTVa = X48cC9SbOl6v20AU7HgEF3i()
	gdlaVcOhj7xMp69ouXt = {}
	for hlXSLtu8doQak6IP5cRefs in list(hMoSuPWCiGAJKw8HRfgTVa.keys()):
		if hlXSLtu8doQak6IP5cRefs!=YmroH2wlN1: gdlaVcOhj7xMp69ouXt[hlXSLtu8doQak6IP5cRefs] = hMoSuPWCiGAJKw8HRfgTVa[hlXSLtu8doQak6IP5cRefs]
		else:
			if xbfwC5hkXLvsJa8PReOS9AyU1z and xbfwC5hkXLvsJa8PReOS9AyU1z!='..':
				Jpqtxi9mLj8hzBnf4Nb = hMoSuPWCiGAJKw8HRfgTVa[hlXSLtu8doQak6IP5cRefs]
				if lLORW1akG2FBgoyfd0C39pnVcj in Jpqtxi9mLj8hzBnf4Nb:
					aPA7QvshkJYH3T = Jpqtxi9mLj8hzBnf4Nb.index(lLORW1akG2FBgoyfd0C39pnVcj)
					del Jpqtxi9mLj8hzBnf4Nb[aPA7QvshkJYH3T]
				XXeysO6ZMNFKlaDT9zj = Jpqtxi9mLj8hzBnf4Nb+[lLORW1akG2FBgoyfd0C39pnVcj]
				gdlaVcOhj7xMp69ouXt[hlXSLtu8doQak6IP5cRefs] = XXeysO6ZMNFKlaDT9zj
			else: gdlaVcOhj7xMp69ouXt[hlXSLtu8doQak6IP5cRefs] = hMoSuPWCiGAJKw8HRfgTVa[hlXSLtu8doQak6IP5cRefs]
	if YmroH2wlN1 not in list(gdlaVcOhj7xMp69ouXt.keys()): gdlaVcOhj7xMp69ouXt[YmroH2wlN1] = [lLORW1akG2FBgoyfd0C39pnVcj]
	JgKdqyXf1S8mtsZ2YVATc = str(gdlaVcOhj7xMp69ouXt)
	if IZhXMprxvAHqBEFkg0: JgKdqyXf1S8mtsZ2YVATc = JgKdqyXf1S8mtsZ2YVATc.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	open(g8FzaRfU7Zx9HeSBNtJ,'wb').write(JgKdqyXf1S8mtsZ2YVATc)
	return
def RCDGNM0SlmZVw342Bst8uTkXbgLrdP(YmroH2wlN1):
	iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	lLORW1akG2FBgoyfd0C39pnVcj = iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL
	hMoSuPWCiGAJKw8HRfgTVa = X48cC9SbOl6v20AU7HgEF3i()
	if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()) and lLORW1akG2FBgoyfd0C39pnVcj in hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]:
		hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1].remove(lLORW1akG2FBgoyfd0C39pnVcj)
		if len(hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1])==f4fTutDOEwUeIoPLRQ: del hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]
		JgKdqyXf1S8mtsZ2YVATc = str(hMoSuPWCiGAJKw8HRfgTVa)
		if IZhXMprxvAHqBEFkg0: JgKdqyXf1S8mtsZ2YVATc = JgKdqyXf1S8mtsZ2YVATc.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open(g8FzaRfU7Zx9HeSBNtJ,'wb').write(JgKdqyXf1S8mtsZ2YVATc)
	return
def jnC4MqkN8wtaWFeVIrS7zo(YmroH2wlN1,ZZNKAzmf2EL0RGc,jAQoTYtDIa):
	iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	lLORW1akG2FBgoyfd0C39pnVcj = iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL
	hMoSuPWCiGAJKw8HRfgTVa = X48cC9SbOl6v20AU7HgEF3i()
	if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()):
		Jpqtxi9mLj8hzBnf4Nb = hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]
		if lLORW1akG2FBgoyfd0C39pnVcj not in Jpqtxi9mLj8hzBnf4Nb: return
		OKU0sgMz78HLlN4 = len(Jpqtxi9mLj8hzBnf4Nb)
		for uvOaDl7f60HCwBiVKzes24 in range(f4fTutDOEwUeIoPLRQ,jAQoTYtDIa):
			sIfkRl0UQJDyBWOK = Jpqtxi9mLj8hzBnf4Nb.index(lLORW1akG2FBgoyfd0C39pnVcj)
			if ZZNKAzmf2EL0RGc: hJutmDpXVECw6jo = sIfkRl0UQJDyBWOK-vkIa3ijEQVsJGdWOXwK7bnue9ADR
			else: hJutmDpXVECw6jo = sIfkRl0UQJDyBWOK+vkIa3ijEQVsJGdWOXwK7bnue9ADR
			if hJutmDpXVECw6jo>=OKU0sgMz78HLlN4: hJutmDpXVECw6jo = hJutmDpXVECw6jo-OKU0sgMz78HLlN4
			if hJutmDpXVECw6jo<f4fTutDOEwUeIoPLRQ: hJutmDpXVECw6jo = hJutmDpXVECw6jo+OKU0sgMz78HLlN4
			Jpqtxi9mLj8hzBnf4Nb.insert(hJutmDpXVECw6jo, Jpqtxi9mLj8hzBnf4Nb.pop(sIfkRl0UQJDyBWOK))
		hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1] = Jpqtxi9mLj8hzBnf4Nb
		JgKdqyXf1S8mtsZ2YVATc = str(hMoSuPWCiGAJKw8HRfgTVa)
		if IZhXMprxvAHqBEFkg0: JgKdqyXf1S8mtsZ2YVATc = JgKdqyXf1S8mtsZ2YVATc.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open(g8FzaRfU7Zx9HeSBNtJ,'wb').write(JgKdqyXf1S8mtsZ2YVATc)
	return
def HTRkyDb0YAvFI8dSf(YmroH2wlN1):
	if YmroH2wlN1 in ['1','2','3','4']: UYQp3mBMfV4CIaOkEdrzLuKSXvoHe,K9DFfzr4yvAtkdQ = 'مفضلة',YmroH2wlN1
	elif YmroH2wlN1 in ['5']: UYQp3mBMfV4CIaOkEdrzLuKSXvoHe,K9DFfzr4yvAtkdQ = 'تشغيل','1'
	elif YmroH2wlN1 in ['11']: UYQp3mBMfV4CIaOkEdrzLuKSXvoHe,K9DFfzr4yvAtkdQ = 'تشغيل','2'
	else: UYQp3mBMfV4CIaOkEdrzLuKSXvoHe,K9DFfzr4yvAtkdQ = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	uFDM1tYwQkO9p = UYQp3mBMfV4CIaOkEdrzLuKSXvoHe+S3X6GcaiExOPtb+K9DFfzr4yvAtkdQ
	return uFDM1tYwQkO9p
def RW1F2ieq4TSXVoE86pH5chlsyLIrd(YmroH2wlN1):
	uFDM1tYwQkO9p = HTRkyDb0YAvFI8dSf(YmroH2wlN1)
	JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+uFDM1tYwQkO9p+' ؟!')
	if JvOL5Wr9s6!=1: return
	hMoSuPWCiGAJKw8HRfgTVa = X48cC9SbOl6v20AU7HgEF3i()
	if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()):
		del hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]
		JgKdqyXf1S8mtsZ2YVATc = str(hMoSuPWCiGAJKw8HRfgTVa)
		if IZhXMprxvAHqBEFkg0: JgKdqyXf1S8mtsZ2YVATc = JgKdqyXf1S8mtsZ2YVATc.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open(g8FzaRfU7Zx9HeSBNtJ,'wb').write(JgKdqyXf1S8mtsZ2YVATc)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+uFDM1tYwQkO9p)
	return
def X48cC9SbOl6v20AU7HgEF3i():
	hMoSuPWCiGAJKw8HRfgTVa = {}
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(g8FzaRfU7Zx9HeSBNtJ):
		hltevc084HIKwqLiENn = open(g8FzaRfU7Zx9HeSBNtJ,'rb').read()
		if IZhXMprxvAHqBEFkg0: hltevc084HIKwqLiENn = hltevc084HIKwqLiENn.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		hMoSuPWCiGAJKw8HRfgTVa = dr1zfnatJxRHSF48jh0eODm5bGu('dict',hltevc084HIKwqLiENn)
	return hMoSuPWCiGAJKw8HRfgTVa
def SSFTAqtnY3Wf(hMoSuPWCiGAJKw8HRfgTVa,lLORW1akG2FBgoyfd0C39pnVcj,hYDtuSiNKJIHak2MvWRX):
	iiyAEbQ5f80,xbfwC5hkXLvsJa8PReOS9AyU1z,wNyZhHdvUeC3M,EYMmnJAyxV,gwLmtlCDM6uq0EnWoNUx,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,J1rvN7I8eLXuS54mZ6lnUjg,R0gbu46Cw9ZKhB5jsT8HAcGv,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL = lLORW1akG2FBgoyfd0C39pnVcj
	if not EYMmnJAyxV: iiyAEbQ5f80,EYMmnJAyxV = 'folder','260'
	QYfmo2pkycawHKvVsjWrXb60,YmroH2wlN1 = [],nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 'context=' in cvU8LCyfWkogjSeF9lHphBdEZnzsmr:
		QjFV2DniPbzUEh9SrdxwMNoK = ScntgdOZCY74vNpXeW5jh8i.findall('context=(\d+)',cvU8LCyfWkogjSeF9lHphBdEZnzsmr,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if QjFV2DniPbzUEh9SrdxwMNoK: YmroH2wlN1 = str(QjFV2DniPbzUEh9SrdxwMNoK[f4fTutDOEwUeIoPLRQ])
	if EYMmnJAyxV=='270':
		YmroH2wlN1 = R0gbu46Cw9ZKhB5jsT8HAcGv
		if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()):
			uFDM1tYwQkO9p = HTRkyDb0YAvFI8dSf(YmroH2wlN1)
			QYfmo2pkycawHKvVsjWrXb60.append(('مسح قائمة '+uFDM1tYwQkO9p,'RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_DELETELIST'+')'))
	else:
		if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()):
			count = len(hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1])
			if count>vkIa3ijEQVsJGdWOXwK7bnue9ADR: QYfmo2pkycawHKvVsjWrXb60.append(('تحريك 1 للأعلى','RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_UP1)'))
			if count>WtDrnpJmwQ37Z2Ae68hu4BY5M1: QYfmo2pkycawHKvVsjWrXb60.append(('تحريك 4 للأعلى','RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_UP4)'))
			if count>vkIa3ijEQVsJGdWOXwK7bnue9ADR: QYfmo2pkycawHKvVsjWrXb60.append(('تحريك 1 للأسفل','RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_DOWN1)'))
			if count>WtDrnpJmwQ37Z2Ae68hu4BY5M1: QYfmo2pkycawHKvVsjWrXb60.append(('تحريك 4 للأسفل','RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_DOWN4)'))
		for YmroH2wlN1 in ['1','2','3','4','5','11']:
			uFDM1tYwQkO9p = HTRkyDb0YAvFI8dSf(YmroH2wlN1)
			if YmroH2wlN1 in list(hMoSuPWCiGAJKw8HRfgTVa.keys()) and lLORW1akG2FBgoyfd0C39pnVcj in hMoSuPWCiGAJKw8HRfgTVa[YmroH2wlN1]:
				QYfmo2pkycawHKvVsjWrXb60.append(('مسح من '+uFDM1tYwQkO9p,'RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_REMOVE1)'))
			else: QYfmo2pkycawHKvVsjWrXb60.append(('إضافة ل'+uFDM1tYwQkO9p,'RunPlugin('+hYDtuSiNKJIHak2MvWRX+'&context='+YmroH2wlN1+'_ADD1)'))
	ainLY4tIy5esRKkP = []
	for NVxrBR7IlzDKiMJ1A69,T7GvLbeq29PkoB04KRSptQOs6C in QYfmo2pkycawHKvVsjWrXb60:
		NVxrBR7IlzDKiMJ1A69 = l5JG7XwbOfo8DznU+NVxrBR7IlzDKiMJ1A69+c7gxFyUCGm
		ainLY4tIy5esRKkP.append((NVxrBR7IlzDKiMJ1A69,T7GvLbeq29PkoB04KRSptQOs6C,))
	return ainLY4tIy5esRKkP
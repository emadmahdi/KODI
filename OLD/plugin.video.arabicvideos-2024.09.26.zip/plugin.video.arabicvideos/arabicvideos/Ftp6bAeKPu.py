# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'ALFATIMI'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_FTM_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
jC0Trpd6V7cuJeg = ['1239','1250','1245','20','1259','218','485','1238','1258','292']
WcN3S7tJ0AkbwxP = ['3030','628']
def n1zxUlcAgR(mode,url,text):
	if   mode==60: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==61: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==62: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==63: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==64: bPFto2wZdNYrClgBIEv60DJAzu = rylga4dD0NiKYGHRFUwPA5f8E(text)
	elif mode==69: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,69,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'ما يتم مشاهدته الان',zKREXyTHfVSNL8ZFYs,64,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'recent_viewed_vids')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الاكثر مشاهدة',zKREXyTHfVSNL8ZFYs,64,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'most_viewed_vids')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'اضيفت مؤخرا',zKREXyTHfVSNL8ZFYs,64,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'recently_added_vids')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فيديو عشوائي',zKREXyTHfVSNL8ZFYs,64,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'random_vids')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'افلام ومسلسلات',zKREXyTHfVSNL8ZFYs,61,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'-1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'البرامج الدينية',zKREXyTHfVSNL8ZFYs,61,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'-2')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'English Videos',zKREXyTHfVSNL8ZFYs,61,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'-3')
	return nbOFVEDkpT4BIR7Qq82yPmHeJU
def IGDobAKtj4kPF5V(url,jGdXt7eADorwlv8pahNV95H6Tn2qKx):
	okt5ecqjYai7vu4shGJ1rflW23Q = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if jGdXt7eADorwlv8pahNV95H6Tn2qKx not in ['-1','-2','-3']: okt5ecqjYai7vu4shGJ1rflW23Q = '?cat='+jGdXt7eADorwlv8pahNV95H6Tn2qKx
	plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/menu_level.php'+okt5ecqjYai7vu4shGJ1rflW23Q
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ALFATIMI-TITLES-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href=\'(.*?)\'.*?>(.*?)<.*?>(.*?)</span>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	Vx94od8056AqDcIEYUH,qv5R2JduMmjoEIcKQ3kt7WgX = False,False
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,count in items:
		title = dCtxzeFX4GJVonm(title)
		title = title.strip(S3X6GcaiExOPtb)
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		okt5ecqjYai7vu4shGJ1rflW23Q = ScntgdOZCY74vNpXeW5jh8i.findall('cat=(.*?)&',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
		if jGdXt7eADorwlv8pahNV95H6Tn2qKx==okt5ecqjYai7vu4shGJ1rflW23Q: Vx94od8056AqDcIEYUH = True
		elif Vx94od8056AqDcIEYUH 	or (jGdXt7eADorwlv8pahNV95H6Tn2qKx=='-1' and okt5ecqjYai7vu4shGJ1rflW23Q in jC0Trpd6V7cuJeg)  						or (jGdXt7eADorwlv8pahNV95H6Tn2qKx=='-2' and okt5ecqjYai7vu4shGJ1rflW23Q not in WcN3S7tJ0AkbwxP and okt5ecqjYai7vu4shGJ1rflW23Q not in jC0Trpd6V7cuJeg)  						or (jGdXt7eADorwlv8pahNV95H6Tn2qKx=='-3' and okt5ecqjYai7vu4shGJ1rflW23Q in WcN3S7tJ0AkbwxP):
							if count=='1': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,63)
							else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,61,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,okt5ecqjYai7vu4shGJ1rflW23Q)
							qv5R2JduMmjoEIcKQ3kt7WgX = True
	if not qv5R2JduMmjoEIcKQ3kt7WgX: PXyn8J3WjhRgA(url)
	return
def PXyn8J3WjhRgA(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALFATIMI-EPISODES-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pagination(.*?)id="footer',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('grid_view.*?src="(.*?)".*?title="(.*?)".*?<h2.*?href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for X79kphTKa1xLP,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		title = title.replace('Add',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('to Quicklist',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,63,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('(.*?)div',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61=eXpgPIbRv2ZMGwjm5[0]
	G4JHzTEp61=ScntgdOZCY74vNpXeW5jh8i.findall('pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	items=ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	plSscrVjkRviPwm = url.split('?')[0]
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,yY1QxvbIU3p4jSnaVtmuPW in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = plSscrVjkRviPwm + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = dCtxzeFX4GJVonm(yY1QxvbIU3p4jSnaVtmuPW)
		title = 'صفحة ' + title
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,62)
	return grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
def AOk1T6KwciHrWU2MYJzZnEN(url):
	if 'videos.php' in url: url = PXyn8J3WjhRgA(url)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,'ALFATIMI-PLAY-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('playlistfile:"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	url = items[0]
	if 'http' not in url: url = 'http:'+url
	brh5aWRxQzn6YL8UDNOyK9SFGo(url,QSJFrwB3dMiyH2mTPKD9a,'video')
	return
def rylga4dD0NiKYGHRFUwPA5f8E(jGdXt7eADorwlv8pahNV95H6Tn2qKx):
	iugaeRtZ5HFw7mJc9AdTbKlLV2 = { 'mode' : jGdXt7eADorwlv8pahNV95H6Tn2qKx }
	url = 'http://alfatimi.tv/ajax.php'
	headers = { 'Content-Type' : 'application/x-www-form-urlencoded' }
	data = hS5pZyveLR0Ju4EksT2jQ9mrU(iugaeRtZ5HFw7mJc9AdTbKlLV2)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,url,data,headers,True,'ALFATIMI-MOSTS-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?title="(.*?)".*?src="(.*?)".*?href',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
		title = title.strip(S3X6GcaiExOPtb)
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'http:'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,63,X79kphTKa1xLP)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs + '/search_result.php?query=' + T871qPZzS4LkoMBa3Db9Q
	PXyn8J3WjhRgA(url)
	return
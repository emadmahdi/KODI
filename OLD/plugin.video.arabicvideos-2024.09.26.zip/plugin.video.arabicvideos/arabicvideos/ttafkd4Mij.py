# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = flDSRbv57PnV3(u"ࠫࡈࡒࡅࡂࡐࡈࡖࠬࠀ")
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = I3cxjYaHhsrM7T4UX26klN(u"ࠬࡥࡃࡍࡐࡢࠫࠁ")
SSYEhFAoMnaUi = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iPlfQr1JR08,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠭ࡴࡦ࡯ࡳࠫࠂ"))
uiwaSOVtjFrzJDBsQNKLW80 = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iPlfQr1JR08,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࡱࡣࡦ࡯ࡦ࡭ࡥࡴࠩࠃ"))
ou7spgvDTRzkSwljVKEHA3qc = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(VRTXg24fPYirJ3,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪࠄ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩࡗ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭ࠅ"))
ZH6ncvJT407ulfpk1jMXyNxgihtorE = jXnZQgFiVG0SqJ4eyasY2fIE
ILlNW0UKgB8pYG6zHnb = usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠪ࠳ࡩࡧࡴࡢ࠱ࡶࡽࡸࡺࡥ࡮࠱ࡸࡷࡦ࡭ࡥࡴࡶࡤࡸࡸ࠭ࠆ")
D5raYRZWIUvGw1dpJC29AlnE = X60YQOADpkHBb31LiR5qUEKfM(u"ࠫ࠴ࡪࡡࡵࡣ࠲ࡷࡾࡹࡴࡦ࡯࠲ࡨࡷࡵࡰࡣࡱࡻࠫࠇ")
nnj6aJ5DpSiVGZq1PUYomk = paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠬ࠵ࡤࡢࡶࡤ࠳ࡹࡵ࡭ࡣࡵࡷࡳࡳ࡫ࡳࠨࠈ")
Nr9gC2pf5dmYRS6e83w7UhaqZXuQM0 = YayJj10OGl(u"࠭࠯ࡥࡣࡷࡥ࠴ࡲ࡯ࡨࡩࡨࡶࠬࠉ")
Z3knUgAuyV = Fo1SgXMsHk(u"ࠧ࠰ࡦࡤࡸࡦ࠵࡬ࡰࡩࠪࠊ")
sYIi1Rg2XqyZhN36EGowuVW = bnI4kmPtrW7yFEhljXOCq9(u"ࠨ࠱ࡧࡥࡹࡧ࠯ࡢࡰࡵࠫࠋ")
def n1zxUlcAgR(EYMmnJAyxV):
	if   EYMmnJAyxV==bnI4kmPtrW7yFEhljXOCq9(u"࠻࠹࠶ࡾ"): bPFto2wZdNYrClgBIEv60DJAzu = TTOipctw2QjY0DkoAZzMf()
	elif EYMmnJAyxV==xxtgfCnWOFlo0jTbU3PQI4Dq(u"࠼࠺࠱ࡿ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(SSYEhFAoMnaUi,Ag9l6cw3EBqP8HsQuGMizfOtr4,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==UpQ56M0dO1N9xIvVegy(u"࠽࠴࠳ࢀ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(uiwaSOVtjFrzJDBsQNKLW80,Ag9l6cw3EBqP8HsQuGMizfOtr4,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠷࠵࠵ࢁ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(ou7spgvDTRzkSwljVKEHA3qc,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==bnI4kmPtrW7yFEhljXOCq9(u"࠸࠶࠷ࢂ"): bPFto2wZdNYrClgBIEv60DJAzu = yyGkecq54Mi10RDNTXm8sLUrx(ZH6ncvJT407ulfpk1jMXyNxgihtorE,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==t4txivgXSUWBOlCakQmNDjf(u"࠹࠷࠹ࢃ"): bPFto2wZdNYrClgBIEv60DJAzu = NrZBLEmdYu1eSjC2y9hGJ(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==bYyKEjIuGQzoq3AR1(u"࠺࠹࠵ࢄ"): bPFto2wZdNYrClgBIEv60DJAzu = ssnMgwpAEN3qBjCQDlcKSx()
	elif EYMmnJAyxV==qrjy8LuKVPNYdbSvzh(u"࠻࠺࠷ࢅ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(ILlNW0UKgB8pYG6zHnb,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠼࠻࠲ࢆ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(D5raYRZWIUvGw1dpJC29AlnE,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==Fo1SgXMsHk(u"࠽࠵࠴ࢇ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(nnj6aJ5DpSiVGZq1PUYomk,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==IINBvuxkCSJrO1Q0UyngdLi(u"࠷࠶࠶࢈"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(Nr9gC2pf5dmYRS6e83w7UhaqZXuQM0,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==Fo1SgXMsHk(u"࠸࠷࠸ࢉ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(Z3knUgAuyV,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==wCUIOeyRdxF3PtJ6TKYog8Xb(u"࠹࠸࠺ࢊ"): bPFto2wZdNYrClgBIEv60DJAzu = bQaAGNXBYIgClLm15ui3JqU(sYIi1Rg2XqyZhN36EGowuVW,SmbNGskjMx,Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==fgv5U2eRVaQqSiuGD(u"࠺࠹࠼ࢋ"): bPFto2wZdNYrClgBIEv60DJAzu = Spxd1FBgbknMr4w8cyJ(Ag9l6cw3EBqP8HsQuGMizfOtr4)
	elif EYMmnJAyxV==l4DS8mnEjHhFMZ5YOe(u"࠻࠺࠾ࢌ"): bPFto2wZdNYrClgBIEv60DJAzu = IEjfMBwSoaXQPAb5N8yt()
	else: bPFto2wZdNYrClgBIEv60DJAzu = SmbNGskjMx
	return bPFto2wZdNYrClgBIEv60DJAzu
def TTOipctw2QjY0DkoAZzMf():
	dxmEa10toYPFhTcnuj,remoQTMHEDLWqd = t1bQvi3rLfWwmlZpY5o(SSYEhFAoMnaUi)
	GPXfJB6k3Ocnt,nOt5qxgsDNXFd9iKTA = t1bQvi3rLfWwmlZpY5o(uiwaSOVtjFrzJDBsQNKLW80)
	B3vCo6fVpu897GbJOymDMIYgdWet,FFMCP4VNSpIBjyAsvl1eUWtRQE = t1bQvi3rLfWwmlZpY5o(ou7spgvDTRzkSwljVKEHA3qc)
	sPdwASoFHx,gU9vG8ynsIcTZ56R1Pl = nHxt2Y5jIy4cWrZJ(ZH6ncvJT407ulfpk1jMXyNxgihtorE)
	sPdwASoFHx -= QlTuvPbSpnjygBVW(u"࠸࠼࠸࠷࠶ࢍ")
	gU9vG8ynsIcTZ56R1Pl -= q4izXt0sjIQSZcHVAf3EmKRbx(u"࠷ࢎ")
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz = q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠩࠣࠬࠬࠌ")+tN9qPBoiKw8G(dxmEa10toYPFhTcnuj)+bnI4kmPtrW7yFEhljXOCq9(u"ࠪࠤ࠲ࠦࠧࠍ")+str(remoQTMHEDLWqd)+bYyKEjIuGQzoq3AR1(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬࠎ")
	eT40LGftIOPZKAcsU26Mx = qrjy8LuKVPNYdbSvzh(u"ࠬࠦࠨࠨࠏ")+tN9qPBoiKw8G(GPXfJB6k3Ocnt)+bYyKEjIuGQzoq3AR1(u"࠭ࠠ࠮ࠢࠪࠐ")+str(nOt5qxgsDNXFd9iKTA)+wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨࠑ")
	jFupHXv5iTlkQsPwrB24n6YoRAJC = I3cxjYaHhsrM7T4UX26klN(u"ࠨࠢࠫࠫࠒ")+tN9qPBoiKw8G(B3vCo6fVpu897GbJOymDMIYgdWet)+QlTuvPbSpnjygBVW(u"ࠩࠣ࠱ࠥ࠭ࠓ")+str(FFMCP4VNSpIBjyAsvl1eUWtRQE)+DJ6ugPjW9bX8I(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫࠔ")
	zKlZmFX0JRjE = O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠫࠥ࠮ࠧࠕ")+tN9qPBoiKw8G(sPdwASoFHx)+IINBvuxkCSJrO1Q0UyngdLi(u"ࠬ࠯ࠧࠖ")
	OKU0sgMz78HLlN4 = dxmEa10toYPFhTcnuj+GPXfJB6k3Ocnt+B3vCo6fVpu897GbJOymDMIYgdWet+sPdwASoFHx
	EESRd0rNUVBQoX8F1 = remoQTMHEDLWqd+nOt5qxgsDNXFd9iKTA+FFMCP4VNSpIBjyAsvl1eUWtRQE+gU9vG8ynsIcTZ56R1Pl
	J1rvN7I8eLXuS54mZ6lnUjg = t4txivgXSUWBOlCakQmNDjf(u"࠭ࠠࠩࠩࠗ")+tN9qPBoiKw8G(OKU0sgMz78HLlN4)+paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠧࠡ࠯ࠣࠫ࠘")+str(EESRd0rNUVBQoX8F1)+z3sIGH8jmLYg(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠙")
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩ࡯࡭ࡳࡱࠧࠚ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+tM24jD1gO0(u"ุ้ࠪำࠠศๆฯ้๏฿ࠧࠛ")+J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,q4izXt0sjIQSZcHVAf3EmKRbx(u"࠷࠵࠷࢏"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(IINBvuxkCSJrO1Q0UyngdLi(u"ࠫࡱ࡯࡮࡬ࠩࠜ"),eMypvI8XqHjYU02anWD9gsSrkt+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠬࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࠫࠝ")+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,fgv5U2eRVaQqSiuGD(u"࠺࠻࠼࠽࢐"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(QlTuvPbSpnjygBVW(u"࠭࡬ࡪࡰ࡮ࠫࠞ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠧๆีะࠤฬ๊ๅๅใสฮࠥอไๆฦๅฮฮ࠭ࠟ")+UMjkHfeCxLXdyRFhJqINv6ouWSErlz,nbOFVEDkpT4BIR7Qq82yPmHeJU,qrjy8LuKVPNYdbSvzh(u"࠹࠷࠵࢑"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(fgv5U2eRVaQqSiuGD(u"ࠨ࡮࡬ࡲࡰ࠭ࠠ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+fsQukcZeJ8YbozTXKEvS7h306DCA(u"่ࠩืาࠦวๅ็็ๅฬะࠠศๆฺ่฿๎ืสࠩࠡ")+eT40LGftIOPZKAcsU26Mx,nbOFVEDkpT4BIR7Qq82yPmHeJU,QlTuvPbSpnjygBVW(u"࠺࠸࠷࢒"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(ulAxHwvzR9eTb5n(u"ࠪࡰ࡮ࡴ࡫ࠨࠢ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+cb3rmvAn4wa6lBPz2phOoYqX(u"ู๊ࠫอࠡษ็ูํืࠠศๆๅำ๏๋ษࠨࠣ")+jFupHXv5iTlkQsPwrB24n6YoRAJC,nbOFVEDkpT4BIR7Qq82yPmHeJU,IINBvuxkCSJrO1Q0UyngdLi(u"࠻࠹࠹࢓"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠬࡲࡩ࡯࡭ࠪࠤ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+X1mRwt2YJKgCLu9a67(u"࠭สโำํ฾๋ࠥไโุࠢ์ึࠦวๅวูหๆอสࠨࠥ")+zKlZmFX0JRjE,nbOFVEDkpT4BIR7Qq82yPmHeJU,yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠼࠺࠴࢔"))
	llnG7jiQBYKhAeovbT.setSetting(z3sIGH8jmLYg(u"ࠧࡢࡸ࠱ࡷࡹࡧࡴࡶࡵ࠱ࡶࡪ࡬ࡲࡦࡵ࡫ࠫࠦ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return
def ssnMgwpAEN3qBjCQDlcKSx():
	xpRblwFS32eWEVh = Ag9l6cw3EBqP8HsQuGMizfOtr4 if cb3rmvAn4wa6lBPz2phOoYqX(u"ࠨ࠱ࠪࠧ") in VRTXg24fPYirJ3 else SmbNGskjMx
	if not xpRblwFS32eWEVh:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࠨ"),O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"ࠪ฽๊๊๊สࠢอ๊฽๐แࠡษ็ะ์อาࠡ็อ์ๆืษࠡใๅ฻๊ࠥรอ้ีอࠥ๐่็ๅึࠤ࠳࠴้ࠠฮ๊หื้ࠠๅ์ึࠤ๊์ࠠ็๊฼ࠤ๏๎ๆไีࠪࠩ"))
		return
	FGnvJ1ZOyESbpuerf54w8U = llnG7jiQBYKhAeovbT.getSetting(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠫࡦࡼ࠮ࡴࡶࡤࡸࡺࡹ࠮ࡳࡧࡩࡶࡪࡹࡨࠨࠪ"))
	if not FGnvJ1ZOyESbpuerf54w8U: IEjfMBwSoaXQPAb5N8yt()
	dxmEa10toYPFhTcnuj,remoQTMHEDLWqd = t1bQvi3rLfWwmlZpY5o(ILlNW0UKgB8pYG6zHnb)
	GPXfJB6k3Ocnt,nOt5qxgsDNXFd9iKTA = t1bQvi3rLfWwmlZpY5o(D5raYRZWIUvGw1dpJC29AlnE)
	B3vCo6fVpu897GbJOymDMIYgdWet,FFMCP4VNSpIBjyAsvl1eUWtRQE = t1bQvi3rLfWwmlZpY5o(nnj6aJ5DpSiVGZq1PUYomk)
	sPdwASoFHx,gU9vG8ynsIcTZ56R1Pl = t1bQvi3rLfWwmlZpY5o(Nr9gC2pf5dmYRS6e83w7UhaqZXuQM0)
	BBlpLDs53Vnrwh,CBJRQvP3afkWhgXSDurbAeod7Vn1i = t1bQvi3rLfWwmlZpY5o(Z3knUgAuyV)
	BJerFjWA1uXI3s,XsETc64qMHpJRCIuOawtbDQed0 = t1bQvi3rLfWwmlZpY5o(sYIi1Rg2XqyZhN36EGowuVW)
	UMjkHfeCxLXdyRFhJqINv6ouWSErlz = yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࠦࠨࠨࠫ")+tN9qPBoiKw8G(dxmEa10toYPFhTcnuj)+IINBvuxkCSJrO1Q0UyngdLi(u"࠭ࠠ࠮ࠢࠪࠬ")+str(remoQTMHEDLWqd)+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧࠡࡨ࡬ࡰࡪࡹࠩࠨ࠭")
	eT40LGftIOPZKAcsU26Mx = z3sIGH8jmLYg(u"ࠨࠢࠫࠫ࠮")+tN9qPBoiKw8G(GPXfJB6k3Ocnt)+t4txivgXSUWBOlCakQmNDjf(u"ࠩࠣ࠱ࠥ࠭࠯")+str(nOt5qxgsDNXFd9iKTA)+I3cxjYaHhsrM7T4UX26klN(u"ࠪࠤ࡫࡯࡬ࡦࡵࠬࠫ࠰")
	jFupHXv5iTlkQsPwrB24n6YoRAJC = YayJj10OGl(u"ࠫࠥ࠮ࠧ࠱")+tN9qPBoiKw8G(B3vCo6fVpu897GbJOymDMIYgdWet)+flDSRbv57PnV3(u"ࠬࠦ࠭ࠡࠩ࠲")+str(FFMCP4VNSpIBjyAsvl1eUWtRQE)+O5OqHBgSVeRyN4xtjYnzuZpTLi9l(u"࠭ࠠࡧ࡫࡯ࡩࡸ࠯ࠧ࠳")
	zKlZmFX0JRjE = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠧࠡࠪࠪ࠴")+tN9qPBoiKw8G(sPdwASoFHx)+fgv5U2eRVaQqSiuGD(u"ࠨࠢ࠰ࠤࠬ࠵")+str(gU9vG8ynsIcTZ56R1Pl)+bYyKEjIuGQzoq3AR1(u"ࠩࠣࡪ࡮ࡲࡥࡴࠫࠪ࠶")
	FF5SCqafzt2 = SSvu1CZjTW7FcloNqD(u"ࠪࠤ࠭࠭࠷")+tN9qPBoiKw8G(BBlpLDs53Vnrwh)+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠫࠥ࠳ࠠࠨ࠸")+str(CBJRQvP3afkWhgXSDurbAeod7Vn1i)+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠬࠦࡦࡪ࡮ࡨࡷ࠮࠭࠹")
	wweCAH5QEmoudSDf27L1qcZlyW = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠭ࠠࠩࠩ࠺")+tN9qPBoiKw8G(BJerFjWA1uXI3s)+cb3rmvAn4wa6lBPz2phOoYqX(u"ࠧࠡ࠯ࠣࠫ࠻")+str(XsETc64qMHpJRCIuOawtbDQed0)+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠨࠢࡩ࡭ࡱ࡫ࡳࠪࠩ࠼")
	OKU0sgMz78HLlN4 = dxmEa10toYPFhTcnuj+GPXfJB6k3Ocnt+B3vCo6fVpu897GbJOymDMIYgdWet+sPdwASoFHx+BBlpLDs53Vnrwh+BJerFjWA1uXI3s
	EESRd0rNUVBQoX8F1 = remoQTMHEDLWqd+nOt5qxgsDNXFd9iKTA+FFMCP4VNSpIBjyAsvl1eUWtRQE+gU9vG8ynsIcTZ56R1Pl+CBJRQvP3afkWhgXSDurbAeod7Vn1i+XsETc64qMHpJRCIuOawtbDQed0
	J1rvN7I8eLXuS54mZ6lnUjg = QlTuvPbSpnjygBVW(u"ࠩࠣࠬࠬ࠽")+tN9qPBoiKw8G(OKU0sgMz78HLlN4)+bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠪࠤ࠲ࠦࠧ࠾")+str(EESRd0rNUVBQoX8F1)+X1mRwt2YJKgCLu9a67(u"ࠫࠥ࡬ࡩ࡭ࡧࡶ࠭ࠬ࠿")
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(SSvu1CZjTW7FcloNqD(u"ࠬࡲࡩ࡯࡭ࠪࡀ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"࠭ลฺูสลࠥืฮึหࠣๆึอมส๋ࠢ็ฯอศสࠩࡁ"),nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"࠽࠵࠹࢕"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(tM24jD1gO0(u"ࠧ࡭࡫ࡱ࡯ࠬࡂ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+QlTuvPbSpnjygBVW(u"ࠨ็ึัࠥอไอ็ํ฽ࠬࡃ")+J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"࠷࠶࠹࢖"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠩ࡯࡭ࡳࡱࠧࡄ"),eMypvI8XqHjYU02anWD9gsSrkt+l4DS8mnEjHhFMZ5YOe(u"ࠪࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡࠩࡅ")+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"࠺࠻࠼࠽ࢗ"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠫࡱ࡯࡮࡬ࠩࡆ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+xxtgfCnWOFlo0jTbU3PQI4Dq(u"๋ࠬำฮ่่ࠢๆอสࠡࡷࡶࡥ࡬࡫ࡳࡵࡣࡷࡷࠬࡇ")+UMjkHfeCxLXdyRFhJqINv6ouWSErlz,nbOFVEDkpT4BIR7Qq82yPmHeJU,SSvu1CZjTW7FcloNqD(u"࠹࠸࠵࢘"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(UpQ56M0dO1N9xIvVegy(u"࠭࡬ࡪࡰ࡮ࠫࡈ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+X60YQOADpkHBb31LiR5qUEKfM(u"ࠧๆีะࠤ๊๊แศฬࠣࡨࡷࡵࡰࡣࡱࡻࠫࡉ")+eT40LGftIOPZKAcsU26Mx,nbOFVEDkpT4BIR7Qq82yPmHeJU,bnI4kmPtrW7yFEhljXOCq9(u"࠺࠹࠷࢙"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(IINBvuxkCSJrO1Q0UyngdLi(u"ࠨ࡮࡬ࡲࡰ࠭ࡊ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+IINBvuxkCSJrO1Q0UyngdLi(u"่ࠩืาࠦๅๅใสฮࠥࡺ࡯࡮ࡤࡶࡸࡴࡴࡥࡴࠩࡋ")+jFupHXv5iTlkQsPwrB24n6YoRAJC,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"࠻࠺࠹࢚"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(z3sIGH8jmLYg(u"ࠪࡰ࡮ࡴ࡫ࠨࡌ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+IINBvuxkCSJrO1Q0UyngdLi(u"ู๊ࠫอࠡ็็ๅฬะࠠ࡭ࡱࡪ࡫ࡪࡸࠧࡍ")+zKlZmFX0JRjE,nbOFVEDkpT4BIR7Qq82yPmHeJU,tM24jD1gO0(u"࠼࠻࠴࢛"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(IINBvuxkCSJrO1Q0UyngdLi(u"ࠬࡲࡩ࡯࡭ࠪࡎ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+tM24jD1gO0(u"࠭ๅิฯ้้ࠣ็วหࠢ࡯ࡳ࡬࠭ࡏ")+FF5SCqafzt2,nbOFVEDkpT4BIR7Qq82yPmHeJU,I3cxjYaHhsrM7T4UX26klN(u"࠽࠵࠶࢜"))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj(z3sIGH8jmLYg(u"ࠧ࡭࡫ࡱ࡯ࠬࡐ"),TbufdXZL9Ml72WmGcpQ5FAgBYKqa+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ็ึั๋ࠥไโษอࠤࡦࡴࡲࠨࡑ")+wweCAH5QEmoudSDf27L1qcZlyW,nbOFVEDkpT4BIR7Qq82yPmHeJU,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠷࠶࠸࢝"))
	llnG7jiQBYKhAeovbT.setSetting(bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠩࡤࡺ࠳ࡹࡴࡢࡶࡸࡷ࠳ࡸࡥࡧࡴࡨࡷ࡭࠭ࡒ"),nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return
def IEjfMBwSoaXQPAb5N8yt():
	oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,z3sIGH8jmLYg(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡓ"),xxtgfCnWOFlo0jTbU3PQI4Dq(u"้้๊ࠫࠡ์฼้้ࠦวๅฬ้฼๏็ฺ่ࠠา็ࠥ࠴࠮ࠡสิ๊ฬ๋ฬࠡ฻่หิࠦศฮษฯอࠥหไ๊ࠢศ฽฼อมࠡำัูฮࠦวๅไิหฦฯ้ࠠษ็็ฯอศสࠢ็่๊๊แศฬࠣ์ฬ๊ๅอๆาหฯࠦวๅฬํࠤุ๎แࠡ์่ืาํวࠡษ็ฬึ์วๆฮࠣ࠲࠳ࠦ็ๅࠢอี๏ีࠠฦ฻ฺหฦࠦ็ั้ࠣห้ืฮึหࠣห้ศๆࠡมࠤࠫࡔ"))
	if oyNUHM3uQq==-IINBvuxkCSJrO1Q0UyngdLi(u"࠲࢞"): return
	if oyNUHM3uQq:
		import subprocess as zXDcYJZd2M6rHoqgfu9m
		try:
			zXDcYJZd2M6rHoqgfu9m.Popen(cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬࡹࡵࠨࡕ"))
			IKtUpwbfECVgkyT1v89Fs2d0JY3 = Ag9l6cw3EBqP8HsQuGMizfOtr4
		except: IKtUpwbfECVgkyT1v89Fs2d0JY3 = SmbNGskjMx
		if IKtUpwbfECVgkyT1v89Fs2d0JY3:
			CnWb8wIGEF = ILlNW0UKgB8pYG6zHnb+S3X6GcaiExOPtb+D5raYRZWIUvGw1dpJC29AlnE+S3X6GcaiExOPtb+nnj6aJ5DpSiVGZq1PUYomk+S3X6GcaiExOPtb+Nr9gC2pf5dmYRS6e83w7UhaqZXuQM0+S3X6GcaiExOPtb+Z3knUgAuyV+S3X6GcaiExOPtb+sYIi1Rg2XqyZhN36EGowuVW
			Dqjs6LCJASoHvUiMhx = zXDcYJZd2M6rHoqgfu9m.Popen(QlTuvPbSpnjygBVW(u"࠭ࡳࡶࠢ࠰ࡧࠥࠨࡣࡩ࡯ࡲࡨࠥ࠳ࡒࠡ࠲࠺࠻࠼ࠦࠧࡖ")+CnWb8wIGEF+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠧࠣࠩࡗ"),shell=Ag9l6cw3EBqP8HsQuGMizfOtr4,stdin=zXDcYJZd2M6rHoqgfu9m.PIPE,stdout=zXDcYJZd2M6rHoqgfu9m.PIPE,stderr=zXDcYJZd2M6rHoqgfu9m.PIPE)
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡘ"),usVCatpJzZGQ4gFiWX6803UALlkBOc(u"้ࠩะาะฺࠠ็็๎ฮࠦลฺูสลࠥอไาะุอ࡙ࠬ"))
			ue186CEMORWhvq(SmbNGskjMx)
		else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,l4DS8mnEjHhFMZ5YOe(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࡚࠭"),IINBvuxkCSJrO1Q0UyngdLi(u"ࠫ฾๋ไ๋หࠣษ฾฽วยࠢิาฺฯࠠศๆๅีฬวษ๊ࠡส่่ะวษหࠣฮาะวอࠢหี๋อๅอࠢࠣࡶࡴࡵࡴࠡࠢฦ์ࠥࠦࡳࡶࡲࡨࡶࡺࡹࡥࡳࠢࠣวํࠦࠠࡴࡷࠣࠤํา็ศิๆࠤ้อ๋๊ࠠฯำࠥ็๊่๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰࠱ࠤศ๎ࠠไ๊า๎ࠥเ๊าࠢๅหิืฺࠠๆ์ࠤฬูสฯัส้ࠥํะศࠢส่อืๆศ็ฯ࡛ࠫ"))
	return
def tN9qPBoiKw8G(OKU0sgMz78HLlN4):
	for BJou58vPwLqONbGtKTxsiASR1Cr in [wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡈࠧ࡜"),ulAxHwvzR9eTb5n(u"࠭ࡋࡃࠩ࡝"),Fo1SgXMsHk(u"ࠧࡎࡄࠪ࡞"),Fo1SgXMsHk(u"ࠨࡉࡅࠫ࡟"),fgv5U2eRVaQqSiuGD(u"ࠩࡗࡆࠬࡠ")]:
		if OKU0sgMz78HLlN4<DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"࠳࠳࠶࠹࢟"): break
		else: OKU0sgMz78HLlN4 /= CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠴࠴࠷࠺࠮࠱ࢠ")
	J1rvN7I8eLXuS54mZ6lnUjg = bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"ࠥࠩ࠸࠴࠱ࡧࠢࠨࡷࠧࡡ")%(OKU0sgMz78HLlN4,BJou58vPwLqONbGtKTxsiASR1Cr)
	return J1rvN7I8eLXuS54mZ6lnUjg
def t1bQvi3rLfWwmlZpY5o(JZavDB7KqkAzyEgX=YayJj10OGl(u"ࠫ࠳࠭ࡢ")):
	global bCWwDYFVg2iH3cTOBLA9oNG7Z,ooue6kTaYyWD9pE3dNRglQ72VG
	bCWwDYFVg2iH3cTOBLA9oNG7Z,ooue6kTaYyWD9pE3dNRglQ72VG = ulAxHwvzR9eTb5n(u"࠴ࢡ"),ulAxHwvzR9eTb5n(u"࠴ࢡ")
	def Q1IESt5dlamTwqvnP(JZavDB7KqkAzyEgX):
		global bCWwDYFVg2iH3cTOBLA9oNG7Z,ooue6kTaYyWD9pE3dNRglQ72VG
		if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(JZavDB7KqkAzyEgX):
			if X1mRwt2YJKgCLu9a67(u"࠵ࢢ") and wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠬࡹࡣࡢࡰࡧ࡭ࡷ࠭ࡣ") in dir(Yl6SPqWjpxcv9I4fL8ozNtRJUZi1):
				for gtjMpqb3FZCyYmQ in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.scandir(JZavDB7KqkAzyEgX):
					if gtjMpqb3FZCyYmQ.is_dir(follow_symlinks=SmbNGskjMx):
						Q1IESt5dlamTwqvnP(gtjMpqb3FZCyYmQ.path)
					elif gtjMpqb3FZCyYmQ.is_file(follow_symlinks=SmbNGskjMx):
						bCWwDYFVg2iH3cTOBLA9oNG7Z += gtjMpqb3FZCyYmQ.stat().st_size
						ooue6kTaYyWD9pE3dNRglQ72VG += qrjy8LuKVPNYdbSvzh(u"࠷ࢣ")
			else:
				for gtjMpqb3FZCyYmQ in Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.listdir(JZavDB7KqkAzyEgX):
					nPljHyg6DT39LSAmC = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.abspath(Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(JZavDB7KqkAzyEgX,gtjMpqb3FZCyYmQ))
					if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.isdir(nPljHyg6DT39LSAmC):
						Q1IESt5dlamTwqvnP(nPljHyg6DT39LSAmC)
					elif Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.isfile(nPljHyg6DT39LSAmC):
						OKU0sgMz78HLlN4,EESRd0rNUVBQoX8F1 = nHxt2Y5jIy4cWrZJ(nPljHyg6DT39LSAmC)
						bCWwDYFVg2iH3cTOBLA9oNG7Z += OKU0sgMz78HLlN4
						ooue6kTaYyWD9pE3dNRglQ72VG += EESRd0rNUVBQoX8F1
		return
	try: Q1IESt5dlamTwqvnP(JZavDB7KqkAzyEgX)
	except: pass
	return bCWwDYFVg2iH3cTOBLA9oNG7Z,ooue6kTaYyWD9pE3dNRglQ72VG
def RRykuN43DpMCEftVXIHFx5K(LgVW9Skyb3MNrq,showDialogs):
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,flDSRbv57PnV3(u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩࡤ"),LgVW9Skyb3MNrq+Fo1SgXMsHk(u"ࠧ࡝ࡰ࡟ࡲࠬࡥ")+eMypvI8XqHjYU02anWD9gsSrkt+usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠨ้็ࠤฯื๊ะ่ࠢืาࠦ็ัษࠣห้๋ไโࠢยࠥࠬࡦ")+c7gxFyUCGm)
		if oyNUHM3uQq!=YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"࠱ࢤ"): return
	ZHq8NLDk3p = SmbNGskjMx
	if Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(LgVW9Skyb3MNrq):
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(LgVW9Skyb3MNrq)
		except Exception as V7A9X8BvfTSLWE2HdstwGMcReN:
			if showDialogs: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡧ"),str(V7A9X8BvfTSLWE2HdstwGMcReN))
			ZHq8NLDk3p = Ag9l6cw3EBqP8HsQuGMizfOtr4
	if showDialogs and not ZHq8NLDk3p:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,t4txivgXSUWBOlCakQmNDjf(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡨ"),yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠫฯ๋ࠠศๆ่ืาࠦศ็ฮสัࠬࡩ"))
		ue186CEMORWhvq(SmbNGskjMx)
	return
def NrZBLEmdYu1eSjC2y9hGJ(showDialogs):
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,Fo1SgXMsHk(u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨࡪ"),eMypvI8XqHjYU02anWD9gsSrkt+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭็ๅࠢอี๏ีࠠๆีะࠫ࡫")+wwOnIucWJj+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠧๆฮ็ำࠥอไๆๆไหฯࠦวๅ็วๆฯฯࠠ࠯࠰ࠣ์๊าไะࠢส่๊๊แศฬࠣห้๋ึ฻ฺ๊อࠥ࠴࠮๊่ࠡะ้ีࠠศๆุ์ึࠦวๅไา๎๊ฯࠠ࠯࠰ࠣ์ฯ็ั๋฼้้ࠣ็ࠠึ๊ิࠤฬ๊ลืษไหฯ࠭࡬")+wwOnIucWJj+CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"ࠨมࠤࠥࠬ࡭")+c7gxFyUCGm)
		if oyNUHM3uQq!=flDSRbv57PnV3(u"࠲ࢥ"): return
	bQaAGNXBYIgClLm15ui3JqU(SSYEhFAoMnaUi,Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(uiwaSOVtjFrzJDBsQNKLW80,Ag9l6cw3EBqP8HsQuGMizfOtr4,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(ou7spgvDTRzkSwljVKEHA3qc,SmbNGskjMx,SmbNGskjMx)
	yyGkecq54Mi10RDNTXm8sLUrx(ZH6ncvJT407ulfpk1jMXyNxgihtorE,SmbNGskjMx)
	if showDialogs:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ࡮"),DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫ࡯"))
		ue186CEMORWhvq(SmbNGskjMx)
	return
def Spxd1FBgbknMr4w8cyJ(showDialogs):
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,I3cxjYaHhsrM7T4UX26klN(u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧࡰ"),eMypvI8XqHjYU02anWD9gsSrkt+l4DS8mnEjHhFMZ5YOe(u"ࠬํไࠡฬิ๎ิࠦๅิฯ้้ࠣ็วหࠩࡱ")+wwOnIucWJj+SSvu1CZjTW7FcloNqD(u"࠭ࡵࡴࡣࡪࡩࡸࡺࡡࡵࡵࠣ࠲࠳ࠦࡤࡳࡱࡳࡦࡴࡾࠠ࠯࠰ࠣࡸࡴࡳࡢࡴࡶࡲࡲࡪࡹࠠ࠯࠰ࠣࡰࡴ࡭ࡧࡦࡴࠣ࠲࠳ࠦ࡬ࡰࡩࠣ࠲࠳ࠦࡡ࡯ࡴࠪࡲ")+wwOnIucWJj+q4izXt0sjIQSZcHVAf3EmKRbx(u"ࠧࡀࠣࠤࠫࡳ")+c7gxFyUCGm)
		if oyNUHM3uQq!=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࠳ࢦ"): return
	bQaAGNXBYIgClLm15ui3JqU(ILlNW0UKgB8pYG6zHnb,SmbNGskjMx,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(D5raYRZWIUvGw1dpJC29AlnE,SmbNGskjMx,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(nnj6aJ5DpSiVGZq1PUYomk,SmbNGskjMx,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(Nr9gC2pf5dmYRS6e83w7UhaqZXuQM0,SmbNGskjMx,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(Z3knUgAuyV,SmbNGskjMx,SmbNGskjMx)
	bQaAGNXBYIgClLm15ui3JqU(sYIi1Rg2XqyZhN36EGowuVW,SmbNGskjMx,SmbNGskjMx)
	if showDialogs:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ulAxHwvzR9eTb5n(u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫࡴ"),UpQ56M0dO1N9xIvVegy(u"ࠩอ้ࠥอไๆีะࠤอ์ฬศฯࠪࡵ"))
		ue186CEMORWhvq(SmbNGskjMx)
	return
def yyGkecq54Mi10RDNTXm8sLUrx(rFHIDgtaQZAb4xn1WEqTvOcMo2,showDialogs):
	if showDialogs:
		oyNUHM3uQq = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ࡶ"),eMypvI8XqHjYU02anWD9gsSrkt+X1mRwt2YJKgCLu9a67(u"ࠫ์๊ࠠหำํำ๋ࠥำฮ่ࠢัฯ๎๊ศฬ้้ࠣ็ࠠึ๊ิࠤฬ๊ฬๅัࠣรࠦࠧࠧࡷ")+c7gxFyUCGm)
		if oyNUHM3uQq!=X60YQOADpkHBb31LiR5qUEKfM(u"࠴ࢧ"): return
	IgtL0mb7hnwEpYyuf6KUxXR = RhNFgjDTM1Zuakqx4K925EiLoAHUcz.connect(rFHIDgtaQZAb4xn1WEqTvOcMo2)
	IgtL0mb7hnwEpYyuf6KUxXR.text_factory = str
	yWESdJ2nUj31M8ONktxl4 = IgtL0mb7hnwEpYyuf6KUxXR.cursor()
	yWESdJ2nUj31M8ONktxl4.execute(QlTuvPbSpnjygBVW(u"ࠬࡊࡅࡍࡇࡗࡉࠥࡌࡒࡐࡏࠣࡴࡦࡺࡨ࠼ࠩࡸ"))
	yWESdJ2nUj31M8ONktxl4.execute(bnI4kmPtrW7yFEhljXOCq9(u"࠭ࡄࡆࡎࡈࡘࡊࠦࡆࡓࡑࡐࠤࡸ࡯ࡺࡦࡵ࠾ࠫࡹ"))
	yWESdJ2nUj31M8ONktxl4.execute(YayJj10OGl(u"ࠧࡅࡇࡏࡉ࡙ࡋࠠࡇࡔࡒࡑࠥࡺࡥࡹࡶࡸࡶࡪࡁࠧࡺ"))
	IgtL0mb7hnwEpYyuf6KUxXR.commit()
	yWESdJ2nUj31M8ONktxl4.execute(l4DS8mnEjHhFMZ5YOe(u"ࠨࡘࡄࡇ࡚࡛ࡍ࠼ࠩࡻ"))
	IgtL0mb7hnwEpYyuf6KUxXR.close()
	if showDialogs:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬࡼ"),YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪฮ๊ࠦวๅ็ึัࠥฮๆอษะࠫࡽ"))
		ue186CEMORWhvq(SmbNGskjMx)
	return
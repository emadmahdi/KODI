# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'SERIES4WATCH'
headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_SFW_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
def n1zxUlcAgR(mode,url,text):
	if   mode==210: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==211: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==212: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==213: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==214: bPFto2wZdNYrClgBIEv60DJAzu = q7qWG1fZSKs(url)
	elif mode==215: bPFto2wZdNYrClgBIEv60DJAzu = swAXdHnz04WiEvcLp9j(url)
	elif mode==218: bPFto2wZdNYrClgBIEv60DJAzu = y8dfMtPUxD1lCROwL97YsuWEk34S()
	elif mode==219: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def y8dfMtPUxD1lCROwL97YsuWEk34S():
	message = 'هذا الموقع تغير بالكامل ... وبحاجة الى اعادة برمجة من الصفر ... والمبرمج حاليا مشغول ويعاني من وعكة صحية ... ولهذا سوف يبقى الموقع مغلق الى ما شاء الله'
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','الموقع تغير بالكامل',message)
	return
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,219,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	url = zKREXyTHfVSNL8ZFYs+'/getpostsPin?type=one&data=pin&limit=25'
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',url,211)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('FiltersButtons(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-get="(.*?)".*?</i>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		url = zKREXyTHfVSNL8ZFYs+'/getposts?type=one&data='+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,211)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('navigation-menu(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	CZrI4vYju7a = ['مسلسلات انمي','الرئيسية']
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		title = title.strip(S3X6GcaiExOPtb)
		if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,211)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-TITLES-1st')
	if 'getposts' in url or '/search?s=' in url: G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('MediaGrid"(.*?)class="pagination"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		else: return
	items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	Zq6suEoHra8xBIJFSUAvWYb7 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6).strip('/')
		title = dCtxzeFX4GJVonm(title)
		title = title.strip(S3X6GcaiExOPtb)
		if '/film/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in Zq6suEoHra8xBIJFSUAvWYb7):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,212,X79kphTKa1xLP)
		elif '/episode/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'الحلقة' in title:
			BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if BBuqr7CwzEIi9UL54n0AVoHXPlp:
				title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
				if title not in tWsVFQj47pw0L56rZfg:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,213,X79kphTKa1xLP)
					tWsVFQj47pw0L56rZfg.append(title)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,213,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<a href=["\'](http.*?)["\'].*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dCtxzeFX4GJVonm(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			title = dCtxzeFX4GJVonm(title)
			title = title.replace('الصفحة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,211)
	return
def PXyn8J3WjhRgA(url):
	NNlnvX5Y9m3P2ZcKU,items,N3OCzkD7MEISKqTBJ = -1,[],[]
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-EPISODES-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('ti-list-numbered(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		ISmqngYzv6jrepWUx0l = nbOFVEDkpT4BIR7Qq82yPmHeJU.join(eXpgPIbRv2ZMGwjm5)
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',ISmqngYzv6jrepWUx0l,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items.append(url)
	items = set(items)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
		title = '_MOD_' + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-1].replace('-',S3X6GcaiExOPtb)
		AG0kLzo8e6wiV1DdSb = ScntgdOZCY74vNpXeW5jh8i.findall('الحلقة-(\d+)',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-1],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if AG0kLzo8e6wiV1DdSb: AG0kLzo8e6wiV1DdSb = AG0kLzo8e6wiV1DdSb[0]
		else: AG0kLzo8e6wiV1DdSb = '0'
		N3OCzkD7MEISKqTBJ.append([grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb])
	items = sorted(N3OCzkD7MEISKqTBJ, reverse=False, key=lambda key: int(key[2]))
	oBpGSTf4OhtnR5d = str(items).count('/season/')
	NNlnvX5Y9m3P2ZcKU = str(items).count('/episode/')
	if oBpGSTf4OhtnR5d>1 and NNlnvX5Y9m3P2ZcKU>0 and '/season/' not in url:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb in items:
			if '/season/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,213)
	else:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb in items:
			if '/season/' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,212)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	lPpY5fw3tOBcEye91Caun2FQZ = []
	LCjugSrWIBPDyFb4X1o9fAM = url.split('/')
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-PLAY-1st')
	if '/watch/' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		plSscrVjkRviPwm = url.replace(LCjugSrWIBPDyFb4X1o9fAM[3],'watch')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-PLAY-2nd')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="servers-list(.*?)</div>',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('data-embedd="(.*?)".*?server_image">\n(.*?)\n',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if items:
				id = ScntgdOZCY74vNpXeW5jh8i.findall('post_id=(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if id:
					vLrxHDuiN08ba5pRlmUtMAIyfZX = id[0]
					for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/?postid='+vLrxHDuiN08ba5pRlmUtMAIyfZX+'&serverid='+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
						lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			else:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('data-embedd=".*?(http.*?)("|&quot;)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uiazRbmZ63Je21WGqn in items:
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if '/download/' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		plSscrVjkRviPwm = url.replace(LCjugSrWIBPDyFb4X1o9fAM[3],'download')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-PLAY-3rd')
		id = ScntgdOZCY74vNpXeW5jh8i.findall('postId:"(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if id:
			vLrxHDuiN08ba5pRlmUtMAIyfZX = id[0]
			GcYwHSWoQ0Nq8KFfJDdvujZryM = { 'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU , 'X-Requested-With':'XMLHttpRequest' }
			plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs + '/ajaxCenter?_action=getdownloadlinks&postId='+vLrxHDuiN08ba5pRlmUtMAIyfZX
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SERIES4WATCH-PLAY-4th')
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<h3.*?(\d+)(.*?)</div>',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				for loKjdNbfgBHGYITLaZiPJV,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
					items = ScntgdOZCY74vNpXeW5jh8i.findall('<td>(.*?)<.*?href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					for name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
						lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__download'+'____'+loKjdNbfgBHGYITLaZiPJV)
			else:
				eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<h6(.*?)</table>',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = [fv4KNqjIBQT0UcHmlYSnrwOAWGV]
				for G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
					name = nbOFVEDkpT4BIR7Qq82yPmHeJU
					items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
						RWZpkDLtY5Eyb46029MvAKmqBQd8o = '&&' + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[2].lower() + '&&'
						RWZpkDLtY5Eyb46029MvAKmqBQd8o = RWZpkDLtY5Eyb46029MvAKmqBQd8o.replace('.com&&',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.co&&',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						RWZpkDLtY5Eyb46029MvAKmqBQd8o = RWZpkDLtY5Eyb46029MvAKmqBQd8o.replace('.net&&',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.org&&',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						RWZpkDLtY5Eyb46029MvAKmqBQd8o = RWZpkDLtY5Eyb46029MvAKmqBQd8o.replace('.live&&',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.online&&',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						RWZpkDLtY5Eyb46029MvAKmqBQd8o = RWZpkDLtY5Eyb46029MvAKmqBQd8o.replace('&&hd.',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('&&www.',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						RWZpkDLtY5Eyb46029MvAKmqBQd8o = RWZpkDLtY5Eyb46029MvAKmqBQd8o.replace('&&',nbOFVEDkpT4BIR7Qq82yPmHeJU)
						grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 + '?named=' + name + RWZpkDLtY5Eyb46029MvAKmqBQd8o + '__download'
						lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs + '/search?s='+search
	IGDobAKtj4kPF5V(url)
	return
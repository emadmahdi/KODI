# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'EGYNOW'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_EGN_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['عروض مصارعة','الكل','n/A','المزيد','قصة عشق']
def n1zxUlcAgR(mode,url,text):
	if   mode==430: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==431: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==432: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==433: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==434: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==435: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'SPECIFIED_FILTER___'+text)
	elif mode==436: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==437: bPFto2wZdNYrClgBIEv60DJAzu = fqzv6n2LTcEIAX4iNrJ1e8a(url)
	elif mode==439: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs+'/films',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = ScntgdOZCY74vNpXeW5jh8i.findall('"canonical" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO[0].strip('/')
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,'url')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,439,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,435)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,434)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المضاف حديثا',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,431)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'افلام اون لاين',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/films1',436)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات اون لاين',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/series-all1',436)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قائمة تفصيلية',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,437)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"SiteNavigation"(.*?)"Search"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if title in CZrI4vYju7a: continue
		if title=='الرئيسية': continue
		if 'اون لاين' in title: continue
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,431)
	return
def fqzv6n2LTcEIAX4iNrJ1e8a(website=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',website+'/films',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = ScntgdOZCY74vNpXeW5jh8i.findall('"canonical" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO[0].strip('/')
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,'url')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"ListDroped"(.*?)"SearchingMaster"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-tax="(.*?)" data-term="(.*?)" data-name="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for jGdXt7eADorwlv8pahNV95H6Tn2qKx,XPL0O2VkI3w1C8enMaqi,title in items:
		if title in CZrI4vYju7a: continue
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = website+'/explore/?'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'='+XPL0O2VkI3w1C8enMaqi
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,431)
	return
def Cvflxc4FMs37bmY(url):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-SUBMENU-1st')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',url,431)
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"titleSectionCon"(.*?)</div></div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-key="(.*?)".*?<em>(.*?)</em>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for it8kJjp6GIWLOEBfm3zl0H7Qr4ygq,title in items:
		if title in CZrI4vYju7a: continue
		plSscrVjkRviPwm = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Movies/Keys.php?key='+it8kJjp6GIWLOEBfm3zl0H7Qr4ygq
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,plSscrVjkRviPwm,431)
	return
def IGDobAKtj4kPF5V(url,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	items = []
	if '/Terms.php' in url or '/Get.php' in url or '/Keys.php' in url:
		plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-TITLES-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
	elif s0tfc7T2hwBM=='featured':
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-TITLES-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"MainSlider"(.*?)"MatchesTable"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('<a href="(.*?)" title="(.*?)".*?image: url\((.*?)\)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-TITLES-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"BlocksList"(.*?)"Paginate"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"BlocksList"(.*?)"titleSectionCon"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('<a href="(.*?)" title="(.*?)".*?data-image="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	tWsVFQj47pw0L56rZfg = []
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6).strip('/')
		title = dCtxzeFX4GJVonm(title)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,432,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp and 'الحلقة' in title:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,433,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		elif '/movseries/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,431,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,433,X79kphTKa1xLP)
	if s0tfc7T2hwBM!='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"Paginate"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dCtxzeFX4GJVonm(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				title = dCtxzeFX4GJVonm(title)
				if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,431)
		MMxJvY3pH2lFNGwBIrzEVdA = ScntgdOZCY74vNpXeW5jh8i.findall('showmore" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if MMxJvY3pH2lFNGwBIrzEVdA:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = MMxJvY3pH2lFNGwBIrzEVdA[0]
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مشاهدة المزيد',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,431)
	return
def PXyn8J3WjhRgA(url):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	IHV3wWCjYv4,b8Ior2kWzq1tc = [],[]
	if 'Episodes.php' in url:
		plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct = kJPjYVSCDE2(url)
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'X-Requested-With':'XMLHttpRequest','Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-EPISODES-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		b8Ior2kWzq1tc = [UTvsQb4HpCP3Aeo2wDZG7X5V]
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-EPISODES-2nd')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"SeasonsList"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"EpisodesList"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IHV3wWCjYv4:
		X79kphTKa1xLP = ScntgdOZCY74vNpXeW5jh8i.findall('"og:image" content="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		X79kphTKa1xLP = X79kphTKa1xLP[0]
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-id="(.*?)".*?data-season="(.*?)".*?">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for PSua7U3vIj9lwFpThsMHdiq2GEcV1N,k5CS2I6BrmsMxipnflAOTGFjXwH,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Episodes.php?'+'season='+k5CS2I6BrmsMxipnflAOTGFjXwH+'&post_id='+PSua7U3vIj9lwFpThsMHdiq2GEcV1N
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,433,X79kphTKa1xLP)
	elif b8Ior2kWzq1tc:
		X79kphTKa1xLP = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Thumb')
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)<em>(.*?)</em>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,BBuqr7CwzEIi9UL54n0AVoHXPlp in items:
			title = title+S3X6GcaiExOPtb+BBuqr7CwzEIi9UL54n0AVoHXPlp
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,432,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	plSscrVjkRviPwm = url+'/watch/'
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	lPpY5fw3tOBcEye91Caun2FQZ = []
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(plSscrVjkRviPwm,'url')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"container-servers"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		sahdZz9p8k0QGf156eSFEgPVb = ScntgdOZCY74vNpXeW5jh8i.findall('data-id="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if sahdZz9p8k0QGf156eSFEgPVb:
			sahdZz9p8k0QGf156eSFEgPVb = sahdZz9p8k0QGf156eSFEgPVb[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('data-server="(.*?)".*?<span>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for RWZpkDLtY5Eyb46029MvAKmqBQd8o,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/wp-content/themes/EgyNowByElshaikh/Ajaxt/Single/Server.php?server='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'&post_id='+sahdZz9p8k0QGf156eSFEgPVb+'?named='+title+'__watch'
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	cSjkilgqAFYw7UmP = ScntgdOZCY74vNpXeW5jh8i.findall('"container-iframe"><iframe src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if cSjkilgqAFYw7UmP:
		cSjkilgqAFYw7UmP = cSjkilgqAFYw7UmP[0].replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		title = Qi32bRtN18qvyWmaO7YKow9cXs(cSjkilgqAFYw7UmP,'name')
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = cSjkilgqAFYw7UmP+'?named='+title+'__embed'
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"container-download"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?span>(.*?)<.*?em>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,uTKGhcXEIpmDf in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if uTKGhcXEIpmDf!=nbOFVEDkpT4BIR7Qq82yPmHeJU: uTKGhcXEIpmDf = '____'+uTKGhcXEIpmDf
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'+uTKGhcXEIpmDf
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'%20')
	url = zKREXyTHfVSNL8ZFYs+'/?s='+search
	IGDobAKtj4kPF5V(url)
	return
def XCdegEMjq1uDz3whim(url):
	url = url.split('/smartemadfilter?')[0]
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYNOW-GET_FILTERS_BLOCKS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('("dropdown-button".*?)"SearchingMaster"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('"dropdown-button".*?<em>(.*?)</em>(.*?data-tax="(.*?)".*?</div>)',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return m8kVhKyAp7NCibFJ3sYO4EwMS
def Ubu4qfBDldYcI06(G4JHzTEp61):
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-term="(\d+)" data-name="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return items
def wwdcMz3HCWqi(url):
	jqDXgyUVZ2 = url.split('/smartemadfilter?')[0]
	ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	url = url.replace(jqDXgyUVZ2,ksHfTPuQMGB)
	url = url.replace('/smartemadfilter?','/explore/?')
	return url
def dd7OqD1xtKEh4vNMFmpy9ZkeC23r5Y(bhz0GBTNQdYxvnt,url):
	soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
	zb2QIaL7Y4h9g8lSck = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	zb2QIaL7Y4h9g8lSck = wwdcMz3HCWqi(zb2QIaL7Y4h9g8lSck)
	return zb2QIaL7Y4h9g8lSck
MMTo52yRJw30g6qZpPQsG = ['category','country','genre','release-year']
TkPVaeQ9EG = ['quality','release-year','genre','category','language','country']
def bpRLN7ZqT5BiXKfMdI(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if MMTo52yRJw30g6qZpPQsG[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[0]
		for WoEZvMXa0K2suwgPl in range(len(MMTo52yRJw30g6qZpPQsG[0:-1])):
			if MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	elif type=='ALL_ITEMS_FILTER':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'/smartemadfilter?'+RAf62IHC9L0OUl1oETijSgyxX5F
		plSscrVjkRviPwm = wwdcMz3HCWqi(plSscrVjkRviPwm)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',plSscrVjkRviPwm,431)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',plSscrVjkRviPwm,431)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	m8kVhKyAp7NCibFJ3sYO4EwMS = XCdegEMjq1uDz3whim(url)
	dict = {}
	for name,G4JHzTEp61,TT4Yd6yIaJGxZtoR8mh2O7 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		name = name.replace('--',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		items = Ubu4qfBDldYcI06(G4JHzTEp61)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='SPECIFIED_FILTER':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<2:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]:
					url = wwdcMz3HCWqi(url)
					IGDobAKtj4kPF5V(url)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'SPECIFIED_FILTER___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				plSscrVjkRviPwm = wwdcMz3HCWqi(plSscrVjkRviPwm)
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',plSscrVjkRviPwm,431)
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',plSscrVjkRviPwm,435,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='ALL_ITEMS_FILTER':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع :'+name,plSscrVjkRviPwm,434,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			if XPL0O2VkI3w1C8enMaqi=='196533': PspiL81kMT4BwOIXo = 'أفلام نيتفلكس'
			elif XPL0O2VkI3w1C8enMaqi=='196531': PspiL81kMT4BwOIXo = 'مسلسلات نيتفلكس'
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			title = PspiL81kMT4BwOIXo+' :'#+dict[TT4Yd6yIaJGxZtoR8mh2O7]['0']
			title = PspiL81kMT4BwOIXo+' :'+name
			if type=='ALL_ITEMS_FILTER': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,434,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='SPECIFIED_FILTER' and MMTo52yRJw30g6qZpPQsG[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				zb2QIaL7Y4h9g8lSck = dd7OqD1xtKEh4vNMFmpy9ZkeC23r5Y(bhz0GBTNQdYxvnt,url)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,431)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,435,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.replace('=&','=0&')
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for key in TkPVaeQ9EG:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all_filters': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('=0','=')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'EGYBESTVIP'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_EGV_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
def n1zxUlcAgR(mode,url,ohpwd6UumaecE3IWV8lAv0,text):
	if   mode==220: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==221: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==222: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==223: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==224: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url)
	elif mode==229: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,229,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBEST-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="i i-home"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,222)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="ba(.*?)<script',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,221)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if 'html' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
			if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.endswith('/'): Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,221)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def Cvflxc4FMs37bmY(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="rs_scroll"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,224)
	return
def bpRLN7ZqT5BiXKfMdI(url):
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',url,221)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-FILTERS_MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="sub_nav(.*?)id="movies',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".+?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,221)
	else: IGDobAKtj4kPF5V(url)
	return
def IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0='1'):
	if ohpwd6UumaecE3IWV8lAv0==nbOFVEDkpT4BIR7Qq82yPmHeJU: ohpwd6UumaecE3IWV8lAv0 = '1'
	if '/search' in url or '?' in url: plSscrVjkRviPwm = url + '&'
	else: plSscrVjkRviPwm = url + '?'
	plSscrVjkRviPwm = plSscrVjkRviPwm + 'page=' + ohpwd6UumaecE3IWV8lAv0
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('class="pda"(.*?)div',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[-1]
	elif '/series/' in url:
		eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('class="owl-carousel owl-carousel(.*?)div',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	else:
		eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('id="movies(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[-1]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		title = dCtxzeFX4GJVonm(title)
		if '/movie/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/episode' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.rstrip('/'),223,X79kphTKa1xLP)
		else:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,221,X79kphTKa1xLP)
	if len(items)>=16:
		YfqiS8P7LEoIaJh6Qectz = ['/movies','/tv','/search','/trending']
		ohpwd6UumaecE3IWV8lAv0 = int(ohpwd6UumaecE3IWV8lAv0)
		if any(XPL0O2VkI3w1C8enMaqi in url for XPL0O2VkI3w1C8enMaqi in YfqiS8P7LEoIaJh6Qectz):
			for xxUSZfA7LmlMz6 in range(0,1000,100):
				if int(ohpwd6UumaecE3IWV8lAv0/100)*100==xxUSZfA7LmlMz6:
					for WoEZvMXa0K2suwgPl in range(xxUSZfA7LmlMz6,xxUSZfA7LmlMz6+100,10):
						if int(ohpwd6UumaecE3IWV8lAv0/10)*10==WoEZvMXa0K2suwgPl:
							for PrXa7MsyK0 in range(WoEZvMXa0K2suwgPl,WoEZvMXa0K2suwgPl+10,1):
								if not ohpwd6UumaecE3IWV8lAv0==PrXa7MsyK0 and PrXa7MsyK0!=0:
									Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+str(PrXa7MsyK0),url,221,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(PrXa7MsyK0))
						elif WoEZvMXa0K2suwgPl!=0: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+str(WoEZvMXa0K2suwgPl),url,221,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(WoEZvMXa0K2suwgPl))
						else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+str(1),url,221,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(1))
				elif xxUSZfA7LmlMz6!=0: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+str(xxUSZfA7LmlMz6),url,221,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(xxUSZfA7LmlMz6))
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+str(1),url,221)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-PLAY-1st')
	DozYPsfmHBxWh = ScntgdOZCY74vNpXeW5jh8i.findall('<td>التصنيف</td>.*?">(.*?)<',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if DozYPsfmHBxWh and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,DozYPsfmHBxWh): return
	ibWVaumvdO0SF3,BZJE74zAYlvgmbIOdpw6tHkfc = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	odsheIRmT6jw,BfgHZtGFT2hOLIXC4UwSz0 = UTvsQb4HpCP3Aeo2wDZG7X5V,UTvsQb4HpCP3Aeo2wDZG7X5V
	qqiLAKkSawTYOsjIulmvye7gb3dM8 = ScntgdOZCY74vNpXeW5jh8i.findall('show_dl api" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if qqiLAKkSawTYOsjIulmvye7gb3dM8:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in qqiLAKkSawTYOsjIulmvye7gb3dM8:
			if '/watch/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: ibWVaumvdO0SF3 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			elif '/download/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: BZJE74zAYlvgmbIOdpw6tHkfc = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if ibWVaumvdO0SF3!=nbOFVEDkpT4BIR7Qq82yPmHeJU: odsheIRmT6jw = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,ibWVaumvdO0SF3,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-PLAY-2nd')
		if BZJE74zAYlvgmbIOdpw6tHkfc!=nbOFVEDkpT4BIR7Qq82yPmHeJU: BfgHZtGFT2hOLIXC4UwSz0 = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,BZJE74zAYlvgmbIOdpw6tHkfc,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-PLAY-3rd')
	V3mOFM9EKX6Hok1yIAgYh2uBjepdJ = ScntgdOZCY74vNpXeW5jh8i.findall('id="video".*?data-src="(.*?)"',odsheIRmT6jw,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if V3mOFM9EKX6Hok1yIAgYh2uBjepdJ:
		plSscrVjkRviPwm = V3mOFM9EKX6Hok1yIAgYh2uBjepdJ[0]
		if plSscrVjkRviPwm!=nbOFVEDkpT4BIR7Qq82yPmHeJU and 'uploaded.egybest.download' in plSscrVjkRviPwm and '/?id=_' not in plSscrVjkRviPwm:
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-PLAY-4th')
			F1Qp9rdm0VDnkRSZCI6TgGca7Y8j = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)" title="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if F1Qp9rdm0VDnkRSZCI6TgGca7Y8j:
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,uTKGhcXEIpmDf in F1Qp9rdm0VDnkRSZCI6TgGca7Y8j:
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=ed.egybest.do__watch__mp4__'+uTKGhcXEIpmDf)
			else:
				RWZpkDLtY5Eyb46029MvAKmqBQd8o = plSscrVjkRviPwm.split('/')[2]
				lPpY5fw3tOBcEye91Caun2FQZ.append(plSscrVjkRviPwm+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__watch')
		elif plSscrVjkRviPwm!=nbOFVEDkpT4BIR7Qq82yPmHeJU:
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = plSscrVjkRviPwm.split('/')[2]
			lPpY5fw3tOBcEye91Caun2FQZ.append(plSscrVjkRviPwm+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__watch')
	IJkb1dny6jZac = ScntgdOZCY74vNpXeW5jh8i.findall('<table class="dls_table(.*?)</table>',BfgHZtGFT2hOLIXC4UwSz0,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IJkb1dny6jZac:
		IJkb1dny6jZac = IJkb1dny6jZac[0]
		wHp2A7oIKjGuRN8ybks = ScntgdOZCY74vNpXeW5jh8i.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',IJkb1dny6jZac,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if wHp2A7oIKjGuRN8ybks:
			for uTKGhcXEIpmDf,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in wHp2A7oIKjGuRN8ybks:
				if 'myegyvip' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.count('/')>=2:
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[2]
					lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__download__mp4__'+uTKGhcXEIpmDf)
	SeADMcUw2F3OYJdGiZIy6Lmk = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in lPpY5fw3tOBcEye91Caun2FQZ:
		SeADMcUw2F3OYJdGiZIy6Lmk.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(SeADMcUw2F3OYJdGiZIy6Lmk,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'+')
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(pOLDXnFW5V6cTw7ikm,zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'EGYBESTVIP-SEARCH-1st')
	ffiueHIMq6oQxRpyO1ShacVGL4Pg = ScntgdOZCY74vNpXeW5jh8i.findall('name="_token" value="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if ffiueHIMq6oQxRpyO1ShacVGL4Pg:
		url = zKREXyTHfVSNL8ZFYs+'/search?_token='+ffiueHIMq6oQxRpyO1ShacVGL4Pg[0]+'&q='+T871qPZzS4LkoMBa3Db9Q
		IGDobAKtj4kPF5V(url)
	return
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'SHAHID4U'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_SH4_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
headers = {'User-Agent':MdwGcQOsmlV6vKI73THrUY4(True)}
CZrI4vYju7a = ['عروض مصارعة','الكل','افلام','javascript','مصارعة حرة']
def n1zxUlcAgR(mode,url,text):
	if   mode==110: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==111: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==112: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==113: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url,True)
	elif mode==114: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'FULL_FILTER___'+text)
	elif mode==115: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'DEFINED_FILTER___'+text)
	elif mode==116: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url,False)
	elif mode==119: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(cnPhVmgFxA.url,'url')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,119,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,115)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,114)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,111,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('simple-filter(.*?)adv-filter',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'موقع شاهد فوريو','البرنامج لم يستطيع إيجاد عنوان الموقع أو تصميم الموقع تغير')
		return
	else:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('location = \'(.*?)\'.*?src="(.*?)".*?<h3>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for filter,X79kphTKa1xLP,title in items:
			url = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+filter
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,111,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,filter)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="dropdown"(.*?)<script>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			if title in CZrI4vYju7a: continue
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if 'netflix' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: title = 'نيتفلكس'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,111)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url,it8kJjp6GIWLOEBfm3zl0H7Qr4ygq=nbOFVEDkpT4BIR7Qq82yPmHeJU,cnPhVmgFxA=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not cnPhVmgFxA: cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5,items,tWsVFQj47pw0L56rZfg = [],[],[]
	if it8kJjp6GIWLOEBfm3zl0H7Qr4ygq=='featured': eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('glide__slides(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('shows-container(.*?)pagination',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5: return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?url\((.*?)\).*?"title">(.*?)</h4>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if 'WWE' in title: continue
		if 'javascript' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = SxN0jnqr3LI(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6).strip('/')
		title = dCtxzeFX4GJVonm(title)
		title = title.strip(S3X6GcaiExOPtb)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if '/film/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or 'فيلم' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,112,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp and 'الحلقة' in title and '/list' not in url:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,113,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		elif '/actor/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,111,X79kphTKa1xLP)
		elif '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and '/list' not in url:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'/list'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,111,X79kphTKa1xLP)
		elif '/list' in url and 'حلقة' in title:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,112,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,113,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		if it8kJjp6GIWLOEBfm3zl0H7Qr4ygq!='search': items = ScntgdOZCY74vNpXeW5jh8i.findall('(updateQuery).*?>(.+?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		else: items = ScntgdOZCY74vNpXeW5jh8i.findall('<li>.*?href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if 'page=' in url: url = url.split('page=',1)[0][:-1]
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			title = title.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(FKuOXLZA8PYBc7,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			title = title.strip(S3X6GcaiExOPtb)
			if it8kJjp6GIWLOEBfm3zl0H7Qr4ygq!='search':
				if '?' in url: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+'&page='+title
				else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+'?page='+title
			title = dCtxzeFX4GJVonm(title)
			if title: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,111,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,it8kJjp6GIWLOEBfm3zl0H7Qr4ygq)
	return
def PXyn8J3WjhRgA(url,nQSy9mflRpCb80kU4V1):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('items d-flex(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if len(eXpgPIbRv2ZMGwjm5)>1:
		if '/season/' in eXpgPIbRv2ZMGwjm5[0]: KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,HOsekxhQY6NrK1tcGu8BvVo7CLyUIP = eXpgPIbRv2ZMGwjm5[0],eXpgPIbRv2ZMGwjm5[1]
		else: KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,HOsekxhQY6NrK1tcGu8BvVo7CLyUIP = eXpgPIbRv2ZMGwjm5[1],eXpgPIbRv2ZMGwjm5[0]
	else: KXVHpZTa3BCSWlQYUut0PdDLc94Rzo,HOsekxhQY6NrK1tcGu8BvVo7CLyUIP = eXpgPIbRv2ZMGwjm5[0],eXpgPIbRv2ZMGwjm5[0]
	for HT4fGXqv8hEcKsJ in range(2):
		if nQSy9mflRpCb80kU4V1: mode,type,G4JHzTEp61 = 116,'folder',KXVHpZTa3BCSWlQYUut0PdDLc94Rzo
		else: mode,type,G4JHzTEp61 = 112,'video',HOsekxhQY6NrK1tcGu8BvVo7CLyUIP
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?span.*?">(.*?)<.*?span.*?">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if nQSy9mflRpCb80kU4V1 and len(items)<2:
			nQSy9mflRpCb80kU4V1 = False
			continue
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,TKgxmZYczq9oPUWni4ak0NM6,HDE69mkhQg2NaFpuUy5JRb in items:
			title = TKgxmZYczq9oPUWni4ak0NM6+S3X6GcaiExOPtb+HDE69mkhQg2NaFpuUy5JRb
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj(type,TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,mode)
		break
	if not items and '/episodes' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		McZrvSBqofYKz6Jj5g4axuIR2VGA = ScntgdOZCY74vNpXeW5jh8i.findall('class="breadcrumb"(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if McZrvSBqofYKz6Jj5g4axuIR2VGA:
			G4JHzTEp61 = McZrvSBqofYKz6Jj5g4axuIR2VGA[0]
			rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if len(rU02bCJFWZDfVuhtMgBOyQi5P)>2:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = rU02bCJFWZDfVuhtMgBOyQi5P[2]+'list'
				IGDobAKtj4kPF5V(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="actions(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5: return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	p4mVljC0ZYW = '/watch/' in G4JHzTEp61
	download = '/download/' in G4JHzTEp61
	if   p4mVljC0ZYW and not download: yydDgTsXkaM2ftYLuQhJrA,QjbGEv8Htsme4q = rU02bCJFWZDfVuhtMgBOyQi5P[0],nbOFVEDkpT4BIR7Qq82yPmHeJU
	elif not p4mVljC0ZYW and download: yydDgTsXkaM2ftYLuQhJrA,QjbGEv8Htsme4q = nbOFVEDkpT4BIR7Qq82yPmHeJU,rU02bCJFWZDfVuhtMgBOyQi5P[0]
	elif p4mVljC0ZYW and download: yydDgTsXkaM2ftYLuQhJrA,QjbGEv8Htsme4q = rU02bCJFWZDfVuhtMgBOyQi5P[0],rU02bCJFWZDfVuhtMgBOyQi5P[1]
	else: yydDgTsXkaM2ftYLuQhJrA,QjbGEv8Htsme4q = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	lPpY5fw3tOBcEye91Caun2FQZ = []
	if p4mVljC0ZYW:
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',yydDgTsXkaM2ftYLuQhJrA,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-PLAY-2nd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('let servers(.*?)player',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		if b8Ior2kWzq1tc:
			eXBMHvPbDunL = b8Ior2kWzq1tc[0]
			XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('"name":"(.*?)".*?"url":"(.*?)"',eXBMHvPbDunL,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in XhE8FpdTjG:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('\\/','/')
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if download:
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',QjbGEv8Htsme4q,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-PLAY-3rd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content
		b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"servers"(.*?)info-container',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if b8Ior2kWzq1tc:
			eXBMHvPbDunL = b8Ior2kWzq1tc[0]
			XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<span>(.*?)<.*?</i>.*?<span>(.*?)<',eXBMHvPbDunL,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,uTKGhcXEIpmDf in XhE8FpdTjG:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__download'+'____'+uTKGhcXEIpmDf
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/search?s='+search
	IGDobAKtj4kPF5V(url,'search')
	return
def XCdegEMjq1uDz3whim(url):
	url = url.split('/smartemadfilter?')[0]
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHAHID4U-GET_FILTERS_BLOCKS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	m8kVhKyAp7NCibFJ3sYO4EwMS = []
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('adv-filter(.*?)shows-container',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('''updateQuery\('(.*?)'.*?value.*?>(.*?)<(.*?)</select''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		b2o6IZgK0h9TkNjqXdpAHB,QlL1JM5odKm9ZrEWwfesuP4jq,ISmqngYzv6jrepWUx0l = zip(*m8kVhKyAp7NCibFJ3sYO4EwMS)
		m8kVhKyAp7NCibFJ3sYO4EwMS = zip(QlL1JM5odKm9ZrEWwfesuP4jq,b2o6IZgK0h9TkNjqXdpAHB,ISmqngYzv6jrepWUx0l)
	return m8kVhKyAp7NCibFJ3sYO4EwMS
def Ubu4qfBDldYcI06(G4JHzTEp61):
	items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)".*?>\s*(.*?)\s*<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	return items
def fcTiZpgPJwr(url):
	if '/smartemadfilter?' not in url: url = url+'/smartemadfilter?'
	jqDXgyUVZ2 = url.split('/smartemadfilter?')[0]
	ksHfTPuQMGB = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	url = url.replace(jqDXgyUVZ2,ksHfTPuQMGB)
	url = url.replace('/smartemadfilter?','/?')
	return url
xxLBlqUiovf95hGV = ['quality','year','genre','category']
MNx58jZdRO = ['category','genre','year']
def bpRLN7ZqT5BiXKfMdI(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='DEFINED_FILTER':
		if MNx58jZdRO[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MNx58jZdRO[0]
		for WoEZvMXa0K2suwgPl in range(len(MNx58jZdRO[0:-1])):
			if MNx58jZdRO[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MNx58jZdRO[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
	elif type=='FULL_FILTER':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'/smartemadfilter?'+RAf62IHC9L0OUl1oETijSgyxX5F
		zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',zb2QIaL7Y4h9g8lSck,111)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',zb2QIaL7Y4h9g8lSck,111)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	m8kVhKyAp7NCibFJ3sYO4EwMS = XCdegEMjq1uDz3whim(url)
	dict = {}
	for name,TT4Yd6yIaJGxZtoR8mh2O7,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		name = name.replace('كل ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		items = Ubu4qfBDldYcI06(G4JHzTEp61)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='DEFINED_FILTER':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<2:
				if TT4Yd6yIaJGxZtoR8mh2O7==MNx58jZdRO[-1]:
					zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
					IGDobAKtj4kPF5V(zb2QIaL7Y4h9g8lSck)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'DEFINED_FILTER___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				if TT4Yd6yIaJGxZtoR8mh2O7==MNx58jZdRO[-1]:
					zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',zb2QIaL7Y4h9g8lSck,111)
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع',plSscrVjkRviPwm,115,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='FULL_FILTER':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع :'+name,plSscrVjkRviPwm,114,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			if XPL0O2VkI3w1C8enMaqi=='196533': PspiL81kMT4BwOIXo = 'أفلام نيتفلكس'
			elif XPL0O2VkI3w1C8enMaqi=='196531': PspiL81kMT4BwOIXo = 'مسلسلات نيتفلكس'
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			title = PspiL81kMT4BwOIXo+' :'#+dict[TT4Yd6yIaJGxZtoR8mh2O7]['0']
			title = PspiL81kMT4BwOIXo+' :'+name
			if type=='FULL_FILTER': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,114,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='DEFINED_FILTER' and MNx58jZdRO[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
				plSscrVjkRviPwm = url+'/smartemadfilter?'+soAjtN3yd04Jzr
				zb2QIaL7Y4h9g8lSck = fcTiZpgPJwr(plSscrVjkRviPwm)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,111)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,115,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.replace('=&','=0&')
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	for key in xxLBlqUiovf95hGV:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('=0','=')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'YOUTUBE'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_YUT_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
kdc64za875qyMQpbRVglnes = 0
def n1zxUlcAgR(mode,url,text,type,ohpwd6UumaecE3IWV8lAv0,name,nnu5vdh1IscOA8J):
	if	 mode==140: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==141: bPFto2wZdNYrClgBIEv60DJAzu = GWPwBTUKdflEtq89RD(url,name,nnu5vdh1IscOA8J)
	elif mode==143: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url,type)
	elif mode==144: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0,text)
	elif mode==145: bPFto2wZdNYrClgBIEv60DJAzu = wRSTtYUveNo(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==147: bPFto2wZdNYrClgBIEv60DJAzu = zzfe089Mt5kqul2C()
	elif mode==148: bPFto2wZdNYrClgBIEv60DJAzu = JfljCxUqmu()
	elif mode==149: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	if 0:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قائمة 1',zKREXyTHfVSNL8ZFYs+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قائمة 2',zKREXyTHfVSNL8ZFYs+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'شخص',zKREXyTHfVSNL8ZFYs+'/user/TCNofficial',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'موقع',zKREXyTHfVSNL8ZFYs+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'حساب',zKREXyTHfVSNL8ZFYs+'/@TheSocialCTV',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'العاب',zKREXyTHfVSNL8ZFYs+'/gaming',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'افلام',zKREXyTHfVSNL8ZFYs+'/feed/storefront',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مختارات',zKREXyTHfVSNL8ZFYs+'/feed/guide_builder',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'قصيرة',zKREXyTHfVSNL8ZFYs+'/shorts',144,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'تصفح',zKREXyTHfVSNL8ZFYs+'/youtubei/v1/guide?key=',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'رئيسية',zKREXyTHfVSNL8ZFYs+nbOFVEDkpT4BIR7Qq82yPmHeJU,144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'رائج',zKREXyTHfVSNL8ZFYs+'/feed/trending?bp=',144)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,149,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الرائجة',zKREXyTHfVSNL8ZFYs+'/feed/trending',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'التصفح',zKREXyTHfVSNL8ZFYs+'/youtubei/v1/guide?key=',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'القصيرة',zKREXyTHfVSNL8ZFYs+'/shorts',144,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مختارات يوتيوب',zKREXyTHfVSNL8ZFYs+'/feed/guide_builder',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مختارات البرنامج',nbOFVEDkpT4BIR7Qq82yPmHeJU,290)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: قنوات عربية',nbOFVEDkpT4BIR7Qq82yPmHeJU,147)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: قنوات أجنبية',nbOFVEDkpT4BIR7Qq82yPmHeJU,148)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: افلام عربية',zKREXyTHfVSNL8ZFYs+'/results?search_query=فيلم',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: افلام اجنبية',zKREXyTHfVSNL8ZFYs+'/results?search_query=movie',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسرحيات عربية',zKREXyTHfVSNL8ZFYs+'/results?search_query=مسرحية',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسلسلات عربية',zKREXyTHfVSNL8ZFYs+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسلسلات اجنبية',zKREXyTHfVSNL8ZFYs+'/results?search_query=series&sp=EgIQAw==',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: مسلسلات كارتون',zKREXyTHfVSNL8ZFYs+'/results?search_query=كارتون&sp=EgIQAw==',144)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث: خطبة المرجعية',zKREXyTHfVSNL8ZFYs+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def GWPwBTUKdflEtq89RD(url,name,nnu5vdh1IscOA8J):
	name = d7Pcqxem9LyM6WEiIpv(name)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'CHNL:  '+name,url,144,nnu5vdh1IscOA8J)
	return
def zzfe089Mt5kqul2C():
	IGDobAKtj4kPF5V(zKREXyTHfVSNL8ZFYs+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def JfljCxUqmu():
	IGDobAKtj4kPF5V(zKREXyTHfVSNL8ZFYs+'/results?search_query=tv&sp=EgJAAQ==')
	return
def AOk1T6KwciHrWU2MYJzZnEN(url,type):
	url = url.split('&',1)[0]
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY([url],QSJFrwB3dMiyH2mTPKD9a,type,url)
	return
def ssWAbuDlX2i5Q(UXidK9mQzk,url,wX9P3dR07B5HynVa8):
	level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = wX9P3dR07B5HynVa8.split('::')
	SbBfnz637O5kX,ZdPWNnLb0yvDIASse64tGKXoOkC = [],[]
	if '/youtubei/v1/browse' in url: SbBfnz637O5kX.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: SbBfnz637O5kX.append("yccc['onResponseReceivedCommands']")
	SbBfnz637O5kX.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': SbBfnz637O5kX.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	SbBfnz637O5kX.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	SbBfnz637O5kX.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	SbBfnz637O5kX.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	SbBfnz637O5kX.append("yccc['entries']")
	SbBfnz637O5kX.append("yccc['items'][3]['guideSectionRenderer']['items']")
	bygLAPSXYruwZNa0TD,EyKH0FRqsm7hC,W9piKG1OB0levN4k8ZdwUMIEqs = l7Gyq9AQvCdueZIcn38kjPLxbX(UXidK9mQzk,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
	if level=='1' and bygLAPSXYruwZNa0TD:
		if len(EyKH0FRqsm7hC)>1 and 'search_query' not in url:
			for WVosY6eP9At75ldUGJ1jKiT in range(len(EyKH0FRqsm7hC)):
				qYO29i51ST4MDlxweQbt = str(WVosY6eP9At75ldUGJ1jKiT)
				SbBfnz637O5kX = []
				SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['reloadContinuationItemsCommand']['continuationItems']")
				SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['command']")
				SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]")
				EJNf2kglaiQHnFGe531Iq,xB2lOZNsPvFQDC4gMz,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(EyKH0FRqsm7hC,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
				if EJNf2kglaiQHnFGe531Iq: ZdPWNnLb0yvDIASse64tGKXoOkC.append([xB2lOZNsPvFQDC4gMz,url,'2::'+qYO29i51ST4MDlxweQbt+'::0::0'])
			SbBfnz637O5kX.append("yccc['continuationEndpoint']")
			EJNf2kglaiQHnFGe531Iq,xB2lOZNsPvFQDC4gMz,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(UXidK9mQzk,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
			if EJNf2kglaiQHnFGe531Iq and ZdPWNnLb0yvDIASse64tGKXoOkC and 'continuationCommand' in list(xB2lOZNsPvFQDC4gMz.keys()):
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/my_main_page_shorts_link'
				ZdPWNnLb0yvDIASse64tGKXoOkC.append([xB2lOZNsPvFQDC4gMz,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'1::0::0::0'])
	return EyKH0FRqsm7hC,bygLAPSXYruwZNa0TD,ZdPWNnLb0yvDIASse64tGKXoOkC,W9piKG1OB0levN4k8ZdwUMIEqs
def kE8vId9qejSDA5XBgWJLyQToti6xmH(UXidK9mQzk,EyKH0FRqsm7hC,url,wX9P3dR07B5HynVa8):
	level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = wX9P3dR07B5HynVa8.split('::')
	SbBfnz637O5kX,AiQJjm4rYtop5B1vzwM = [],[]
	SbBfnz637O5kX.append("yddd[0]['itemSectionRenderer']['contents']")
	SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['reloadContinuationItemsCommand']['continuationItems']")
	SbBfnz637O5kX.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: SbBfnz637O5kX.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: SbBfnz637O5kX.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	SbBfnz637O5kX.append("yddd["+qYO29i51ST4MDlxweQbt+"]")
	tcNEe17CgkpM,rrxp7jS1UN5y4mZt,Nxo3yAf8VqpKc5IrUDWjLaHlmO6 = l7Gyq9AQvCdueZIcn38kjPLxbX(EyKH0FRqsm7hC,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
	if level=='2' and tcNEe17CgkpM:
		if len(rrxp7jS1UN5y4mZt)>1:
			for WVosY6eP9At75ldUGJ1jKiT in range(len(rrxp7jS1UN5y4mZt)):
				hHRBjdtPMwWJ5caVZ = str(WVosY6eP9At75ldUGJ1jKiT)
				SbBfnz637O5kX = []
				SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['richSectionRenderer']['content']")
				SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]")
				SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['richItemRenderer']['content']")
				SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]")
				EJNf2kglaiQHnFGe531Iq,xB2lOZNsPvFQDC4gMz,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(rrxp7jS1UN5y4mZt,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
				if EJNf2kglaiQHnFGe531Iq: AiQJjm4rYtop5B1vzwM.append([xB2lOZNsPvFQDC4gMz,url,'3::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::0'])
			SbBfnz637O5kX.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			SbBfnz637O5kX.append("yddd[1]")
			EJNf2kglaiQHnFGe531Iq,xB2lOZNsPvFQDC4gMz,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(EyKH0FRqsm7hC,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
			if EJNf2kglaiQHnFGe531Iq and AiQJjm4rYtop5B1vzwM and 'continuationItemRenderer' in list(xB2lOZNsPvFQDC4gMz.keys()):
				AiQJjm4rYtop5B1vzwM.append([xB2lOZNsPvFQDC4gMz,url,'3::0::0::0'])
	return rrxp7jS1UN5y4mZt,tcNEe17CgkpM,AiQJjm4rYtop5B1vzwM,Nxo3yAf8VqpKc5IrUDWjLaHlmO6
def gk8ezRm1oXW7xwSTrB(UXidK9mQzk,rrxp7jS1UN5y4mZt,url,wX9P3dR07B5HynVa8):
	level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = wX9P3dR07B5HynVa8.split('::')
	SbBfnz637O5kX,jUADRntig1QVhf4deW = [],[]
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	SbBfnz637O5kX.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	SbBfnz637O5kX.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	SbBfnz637O5kX.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['reelShelfRenderer']['items']")
	SbBfnz637O5kX.append("yeee["+hHRBjdtPMwWJ5caVZ+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	SbBfnz637O5kX.append("yeee")
	Iack8Z0CqsyrRLO9DVgEpXNth,CCMujsplAh1kZGf,b7OVmTau4Z35zkpFsXqJ = l7Gyq9AQvCdueZIcn38kjPLxbX(rrxp7jS1UN5y4mZt,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
	if level=='3' and Iack8Z0CqsyrRLO9DVgEpXNth:
		if len(CCMujsplAh1kZGf)>0:
			for WVosY6eP9At75ldUGJ1jKiT in range(len(CCMujsplAh1kZGf)):
				Cr2oVlJOMFRyekdZTWX4fL = str(WVosY6eP9At75ldUGJ1jKiT)
				SbBfnz637O5kX = []
				SbBfnz637O5kX.append("yfff["+Cr2oVlJOMFRyekdZTWX4fL+"]['richItemRenderer']['content']")
				SbBfnz637O5kX.append("yfff["+Cr2oVlJOMFRyekdZTWX4fL+"]['gameCardRenderer']['game']")
				SbBfnz637O5kX.append("yfff["+Cr2oVlJOMFRyekdZTWX4fL+"]['itemSectionRenderer']['contents'][0]")
				SbBfnz637O5kX.append("yfff["+Cr2oVlJOMFRyekdZTWX4fL+"]")
				SbBfnz637O5kX.append("yfff")
				EJNf2kglaiQHnFGe531Iq,xB2lOZNsPvFQDC4gMz,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(CCMujsplAh1kZGf,nbOFVEDkpT4BIR7Qq82yPmHeJU,SbBfnz637O5kX)
				if EJNf2kglaiQHnFGe531Iq: jUADRntig1QVhf4deW.append([xB2lOZNsPvFQDC4gMz,url,'4::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL])
	return CCMujsplAh1kZGf,Iack8Z0CqsyrRLO9DVgEpXNth,jUADRntig1QVhf4deW,b7OVmTau4Z35zkpFsXqJ
def l7Gyq9AQvCdueZIcn38kjPLxbX(HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc,YlkdsaZ8W3juChR0E56GQobcT):
	UXidK9mQzk,OOajAkVTFvBQESqLmURc = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	EyKH0FRqsm7hC,OOajAkVTFvBQESqLmURc = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	rrxp7jS1UN5y4mZt,OOajAkVTFvBQESqLmURc = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	CCMujsplAh1kZGf,OOajAkVTFvBQESqLmURc = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV = HYxdW1nBCSGI,OOajAkVTFvBQESqLmURc
	count = len(YlkdsaZ8W3juChR0E56GQobcT)
	for HT4fGXqv8hEcKsJ in range(count):
		try:
			bbKnskEMiJed9cOCDh1f = eval(YlkdsaZ8W3juChR0E56GQobcT[HT4fGXqv8hEcKsJ])
			return True,bbKnskEMiJed9cOCDh1f,HT4fGXqv8hEcKsJ+1
		except: pass
	return False,nbOFVEDkpT4BIR7Qq82yPmHeJU,0
def IGDobAKtj4kPF5V(url,wX9P3dR07B5HynVa8=nbOFVEDkpT4BIR7Qq82yPmHeJU,data=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	ZdPWNnLb0yvDIASse64tGKXoOkC,AiQJjm4rYtop5B1vzwM,jUADRntig1QVhf4deW = [],[],[]
	if '::' not in wX9P3dR07B5HynVa8: wX9P3dR07B5HynVa8 = '1::0::0::0'
	level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = wX9P3dR07B5HynVa8.split('::')
	if level=='4': level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = '1',qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL
	data = data.replace('_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	UTvsQb4HpCP3Aeo2wDZG7X5V,UXidK9mQzk,J27qXeRCpsgkEoT9Q0GYS6ct = kkNFuBV2aTgK(url,data)
	wX9P3dR07B5HynVa8 = level+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
	if level in ['1','2','3']:
		EyKH0FRqsm7hC,bygLAPSXYruwZNa0TD,ZdPWNnLb0yvDIASse64tGKXoOkC,W9piKG1OB0levN4k8ZdwUMIEqs = ssWAbuDlX2i5Q(UXidK9mQzk,url,wX9P3dR07B5HynVa8)
		if not bygLAPSXYruwZNa0TD: return
		remoQTMHEDLWqd = len(ZdPWNnLb0yvDIASse64tGKXoOkC)
		if remoQTMHEDLWqd<2:
			if level=='1': level = '2'
			ZdPWNnLb0yvDIASse64tGKXoOkC = []
	wX9P3dR07B5HynVa8 = level+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
	if level in ['2','3']:
		rrxp7jS1UN5y4mZt,tcNEe17CgkpM,AiQJjm4rYtop5B1vzwM,Nxo3yAf8VqpKc5IrUDWjLaHlmO6 = kE8vId9qejSDA5XBgWJLyQToti6xmH(UXidK9mQzk,EyKH0FRqsm7hC,url,wX9P3dR07B5HynVa8)
		if not tcNEe17CgkpM: return
		nOt5qxgsDNXFd9iKTA = len(AiQJjm4rYtop5B1vzwM)
		if nOt5qxgsDNXFd9iKTA<2:
			if level=='2': level = '3'
			AiQJjm4rYtop5B1vzwM = []
	wX9P3dR07B5HynVa8 = level+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
	if level in ['3']:
		CCMujsplAh1kZGf,Iack8Z0CqsyrRLO9DVgEpXNth,jUADRntig1QVhf4deW,b7OVmTau4Z35zkpFsXqJ = gk8ezRm1oXW7xwSTrB(UXidK9mQzk,rrxp7jS1UN5y4mZt,url,wX9P3dR07B5HynVa8)
		if not Iack8Z0CqsyrRLO9DVgEpXNth: return
		FFMCP4VNSpIBjyAsvl1eUWtRQE = len(jUADRntig1QVhf4deW)
	for xB2lOZNsPvFQDC4gMz,url,wX9P3dR07B5HynVa8 in ZdPWNnLb0yvDIASse64tGKXoOkC+AiQJjm4rYtop5B1vzwM+jUADRntig1QVhf4deW:
		tQHRqT0iljUbMNeka = eygV2sIhK6ZMdk1z4EGltH(xB2lOZNsPvFQDC4gMz,url,wX9P3dR07B5HynVa8)
	return
def eygV2sIhK6ZMdk1z4EGltH(xB2lOZNsPvFQDC4gMz,url=nbOFVEDkpT4BIR7Qq82yPmHeJU,wX9P3dR07B5HynVa8=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if '::' in wX9P3dR07B5HynVa8: level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = wX9P3dR07B5HynVa8.split('::')
	else: level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = '1','0','0','0'
	EJNf2kglaiQHnFGe531Iq,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty,PuHKO59UzVnrNAX = Xi1MKn8wOuV5RA6jc2pf7gbdY9z(xB2lOZNsPvFQDC4gMz)
	wjSstJ9KD8IhAgrzcyiuP = '/videos?' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/streams?' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/playlists?' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	pL90NVf3ZXjUW7PlydQgI8Oz = '/channels?' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/shorts?' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	if wjSstJ9KD8IhAgrzcyiuP or pL90NVf3ZXjUW7PlydQgI8Oz: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
	wjSstJ9KD8IhAgrzcyiuP = 'watch?v=' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and '/playlist?list=' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	pL90NVf3ZXjUW7PlydQgI8Oz = '/gaming' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6  and '/feed/storefront' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	if wX9P3dR07B5HynVa8[0:5]=='3::0::' and wjSstJ9KD8IhAgrzcyiuP and pL90NVf3ZXjUW7PlydQgI8Oz: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		level,qYO29i51ST4MDlxweQbt,hHRBjdtPMwWJ5caVZ,Cr2oVlJOMFRyekdZTWX4fL = '1','0','0','0'
		wX9P3dR07B5HynVa8 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	J27qXeRCpsgkEoT9Q0GYS6ct = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if '/youtubei/v1/browse' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/youtubei/v1/search' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/my_main_page_shorts_link' in url:
		data = llnG7jiQBYKhAeovbT.getSetting('av.youtube.data')
		if data.count(':::')==4:
			mRJf2ElN8AYHIXCskSUruxgjFc,key,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,eDv42iKLNCb5uoA07wHfW,ffiueHIMq6oQxRpyO1ShacVGL4Pg = data.split(':::')
			J27qXeRCpsgkEoT9Q0GYS6ct = mRJf2ElN8AYHIXCskSUruxgjFc+':::'+key+':::'+Rc4dwqYitn9msyAEuokSKf5HrUTGDv+':::'+eDv42iKLNCb5uoA07wHfW+':::'+PuHKO59UzVnrNAX
			if '/my_main_page_shorts_link' in url and not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
			else: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?key='+key
	if not title:
		global kdc64za875qyMQpbRVglnes
		kdc64za875qyMQpbRVglnes += 1
		title = 'فيديوهات '+str(kdc64za875qyMQpbRVglnes)
		wX9P3dR07B5HynVa8 = '3'+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
	if not EJNf2kglaiQHnFGe531Iq: return False
	elif 'searchPyvRenderer' in str(xB2lOZNsPvFQDC4gMz): return False
	elif '/about' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return False
	elif '/community' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: return False
	elif 'continuationItemRenderer' in list(xB2lOZNsPvFQDC4gMz.keys()) or 'continuationCommand' in list(xB2lOZNsPvFQDC4gMz.keys()):
		if int(level)>1: level = str(int(level)-1)
		wX9P3dR07B5HynVa8 = level+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+':: '+'صفحة أخرى',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8,J27qXeRCpsgkEoT9Q0GYS6ct)
	elif '/search' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		title = ':: '+title
		wX9P3dR07B5HynVa8 = '3'+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
		url = url.replace('/search',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,145,nbOFVEDkpT4BIR7Qq82yPmHeJU,wX9P3dR07B5HynVa8,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		wX9P3dR07B5HynVa8 = '3'+'::'+qYO29i51ST4MDlxweQbt+'::'+hHRBjdtPMwWJ5caVZ+'::'+Cr2oVlJOMFRyekdZTWX4fL
		title = ':: '+title
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8,J27qXeRCpsgkEoT9Q0GYS6ct)
	elif '/browse' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and url==zKREXyTHfVSNL8ZFYs:
		title = ':: '+title
		wX9P3dR07B5HynVa8 = '2::0::0::0'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8,J27qXeRCpsgkEoT9Q0GYS6ct)
	elif not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'horizontalMovieListRenderer' in str(xB2lOZNsPvFQDC4gMz):
		title = ':: '+title
		wX9P3dR07B5HynVa8 = '3::0::0::0'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8)
	elif 'messageRenderer' in str(xB2lOZNsPvFQDC4gMz):
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	elif YhPe4rVdaFqX1MDRKf:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+YhPe4rVdaFqX1MDRKf+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,143,X79kphTKa1xLP)
	elif '/playlist?list=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('&playnext=1',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'LIST'+count+':  '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8)
	elif '/shorts/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&list=',1)[0]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,143,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr)
	elif '/watch?v=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		if '&list=' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and count:
			L72HwzvcCsoeGm5i4T08r13QPdfu9K = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&list=',1)[1]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/playlist?list='+L72HwzvcCsoeGm5i4T08r13QPdfu9K
			wX9P3dR07B5HynVa8 = '1::0::0::0'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'LIST'+count+':  '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8)
		else:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('&list=',1)[0]
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,143,X79kphTKa1xLP,H07WdckxAoZF1fn4LNMOTP65eEtr)
	elif '/channel/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or '/c/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or ('/@' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.count('/')==3):
		if n7neb9KTv10FcU:
			title = title.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode('raw_unicode_escape')
			title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'CHNL'+count+':  '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8)
	elif '/user/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'USER'+count+':  '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8)
	else:
		if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url
		title = ':: '+title
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,144,X79kphTKa1xLP,wX9P3dR07B5HynVa8,J27qXeRCpsgkEoT9Q0GYS6ct)
	return True
def Xi1MKn8wOuV5RA6jc2pf7gbdY9z(xB2lOZNsPvFQDC4gMz):
	EJNf2kglaiQHnFGe531Iq,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty,ffiueHIMq6oQxRpyO1ShacVGL4Pg = False,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not isinstance(xB2lOZNsPvFQDC4gMz,dict): return EJNf2kglaiQHnFGe531Iq,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty,ffiueHIMq6oQxRpyO1ShacVGL4Pg
	for WbRD4Px5tfheHCOwUm1EaFc8szvL in list(xB2lOZNsPvFQDC4gMz.keys()):
		bNd38Genk0lfcV = xB2lOZNsPvFQDC4gMz[WbRD4Px5tfheHCOwUm1EaFc8szvL]
		if isinstance(bNd38Genk0lfcV,dict): break
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	SbBfnz637O5kX.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	SbBfnz637O5kX.append("yrender['header']['richListHeaderRenderer']['title']")
	SbBfnz637O5kX.append("yrender['headline']['simpleText']")
	SbBfnz637O5kX.append("yrender['unplayableText']['simpleText']")
	SbBfnz637O5kX.append("yrender['formattedTitle']['simpleText']")
	SbBfnz637O5kX.append("yrender['title']['simpleText']")
	SbBfnz637O5kX.append("yrender['title']['runs'][0]['text']")
	SbBfnz637O5kX.append("yrender['text']['simpleText']")
	SbBfnz637O5kX.append("yrender['text']['runs'][0]['text']")
	SbBfnz637O5kX.append("yrender['title']['content']")
	SbBfnz637O5kX.append("yrender['title']")
	SbBfnz637O5kX.append("item['title']")
	SbBfnz637O5kX.append("item['reelWatchEndpoint']['videoId']")
	EJNf2kglaiQHnFGe531Iq,title,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	SbBfnz637O5kX.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	SbBfnz637O5kX.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	SbBfnz637O5kX.append("item['commandMetadata']['webCommandMetadata']['url']")
	EJNf2kglaiQHnFGe531Iq,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("yrender['thumbnail']['thumbnails'][0]['url']")
	SbBfnz637O5kX.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	SbBfnz637O5kX.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	EJNf2kglaiQHnFGe531Iq,X79kphTKa1xLP,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	SbBfnz637O5kX.append("yrender['videoCountShortText']['simpleText']")
	SbBfnz637O5kX.append("yrender['videoCountText']['runs'][0]['text']")
	SbBfnz637O5kX.append("yrender['videoCount']")
	EJNf2kglaiQHnFGe531Iq,count,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	SbBfnz637O5kX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	SbBfnz637O5kX.append("yrender['lengthText']['simpleText']")
	SbBfnz637O5kX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	SbBfnz637O5kX.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	EJNf2kglaiQHnFGe531Iq,H07WdckxAoZF1fn4LNMOTP65eEtr,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV,SbBfnz637O5kX)
	SbBfnz637O5kX = []
	SbBfnz637O5kX.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	SbBfnz637O5kX.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	EJNf2kglaiQHnFGe531Iq,ffiueHIMq6oQxRpyO1ShacVGL4Pg,AG0kLzo8e6wiV1DdSb = l7Gyq9AQvCdueZIcn38kjPLxbX(xB2lOZNsPvFQDC4gMz,bNd38Genk0lfcV,SbBfnz637O5kX)
	if 'LIVE' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf = nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE:  '
	if 'مباشر' in H07WdckxAoZF1fn4LNMOTP65eEtr: H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf = nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE:  '
	if 'badges' in list(bNd38Genk0lfcV.keys()):
		yyizNFhWGqgbrufA5UtLDZCa = str(bNd38Genk0lfcV['badges'])
		if 'Free with Ads' in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$:  '
		if 'LIVE' in yyizNFhWGqgbrufA5UtLDZCa: YhPe4rVdaFqX1MDRKf = 'LIVE:  '
		if 'Buy' in yyizNFhWGqgbrufA5UtLDZCa or 'Rent' in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$$:  '
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'مباشر') in yyizNFhWGqgbrufA5UtLDZCa: YhPe4rVdaFqX1MDRKf = 'LIVE:  '
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'شراء') in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$$:  '
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'استئجار') in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$$:  '
		if YUSRdPDwbvE02uZ17oyH4jszLkgV9(u'إعلانات') in yyizNFhWGqgbrufA5UtLDZCa: CoGin4IdJQKeq7k2jLrxMty = '$:  '
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
	X79kphTKa1xLP = X79kphTKa1xLP.split('?')[0]
	if  X79kphTKa1xLP and 'http' not in X79kphTKa1xLP: X79kphTKa1xLP = 'https:'+X79kphTKa1xLP
	title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
	if CoGin4IdJQKeq7k2jLrxMty: title = CoGin4IdJQKeq7k2jLrxMty+title
	H07WdckxAoZF1fn4LNMOTP65eEtr = H07WdckxAoZF1fn4LNMOTP65eEtr.replace(',',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	count = count.replace(',',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	count = ScntgdOZCY74vNpXeW5jh8i.findall('\d+',count)
	if count: count = count[0]
	else: count = nbOFVEDkpT4BIR7Qq82yPmHeJU
	return True,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,H07WdckxAoZF1fn4LNMOTP65eEtr,YhPe4rVdaFqX1MDRKf,CoGin4IdJQKeq7k2jLrxMty,ffiueHIMq6oQxRpyO1ShacVGL4Pg
def kkNFuBV2aTgK(url,data=nbOFVEDkpT4BIR7Qq82yPmHeJU,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if s0tfc7T2hwBM==nbOFVEDkpT4BIR7Qq82yPmHeJU: s0tfc7T2hwBM = 'ytInitialData'
	VLs4zv8ycboXT0UG7rk2fAj = MdwGcQOsmlV6vKI73THrUY4()
	GcYwHSWoQ0Nq8KFfJDdvujZryM = {'User-Agent':VLs4zv8ycboXT0UG7rk2fAj,'Cookie':'PREF=hl=ar'}
	global llnG7jiQBYKhAeovbT
	if not data: data = llnG7jiQBYKhAeovbT.getSetting('av.youtube.data')
	if data.count(':::')==4: mRJf2ElN8AYHIXCskSUruxgjFc,key,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,eDv42iKLNCb5uoA07wHfW,ffiueHIMq6oQxRpyO1ShacVGL4Pg = data.split(':::')
	else: mRJf2ElN8AYHIXCskSUruxgjFc,key,Rc4dwqYitn9msyAEuokSKf5HrUTGDv,eDv42iKLNCb5uoA07wHfW,ffiueHIMq6oQxRpyO1ShacVGL4Pg = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	J27qXeRCpsgkEoT9Q0GYS6ct = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":Rc4dwqYitn9msyAEuokSKf5HrUTGDv}}}
	if url==zKREXyTHfVSNL8ZFYs+'/shorts' or '/my_main_page_shorts_link' in url:
		url = zKREXyTHfVSNL8ZFYs+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		J27qXeRCpsgkEoT9Q0GYS6ct['sequenceParams'] = mRJf2ElN8AYHIXCskSUruxgjFc
		J27qXeRCpsgkEoT9Q0GYS6ct = str(J27qXeRCpsgkEoT9Q0GYS6ct)
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',url,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = zKREXyTHfVSNL8ZFYs+'/youtubei/v1/guide?key='+key
		J27qXeRCpsgkEoT9Q0GYS6ct = str(J27qXeRCpsgkEoT9Q0GYS6ct)
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',url,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and mRJf2ElN8AYHIXCskSUruxgjFc:
		J27qXeRCpsgkEoT9Q0GYS6ct['continuation'] = ffiueHIMq6oQxRpyO1ShacVGL4Pg
		J27qXeRCpsgkEoT9Q0GYS6ct['context']['client']['visitorData'] = mRJf2ElN8AYHIXCskSUruxgjFc
		J27qXeRCpsgkEoT9Q0GYS6ct = str(J27qXeRCpsgkEoT9Q0GYS6ct)
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'POST',url,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and eDv42iKLNCb5uoA07wHfW:
		GcYwHSWoQ0Nq8KFfJDdvujZryM.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':Rc4dwqYitn9msyAEuokSKf5HrUTGDv})
		GcYwHSWoQ0Nq8KFfJDdvujZryM.update({'Cookie':'VISITOR_INFO1_LIVE='+eDv42iKLNCb5uoA07wHfW})
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'YOUTUBE-GET_PAGE_DATA-6th')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall('"innertubeApiKey".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if EwNgXqHTSJK6sR9LWrBU3Zh8v: key = EwNgXqHTSJK6sR9LWrBU3Zh8v[0]
	EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall('"cver".*?"value".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if EwNgXqHTSJK6sR9LWrBU3Zh8v: Rc4dwqYitn9msyAEuokSKf5HrUTGDv = EwNgXqHTSJK6sR9LWrBU3Zh8v[0]
	EwNgXqHTSJK6sR9LWrBU3Zh8v = ScntgdOZCY74vNpXeW5jh8i.findall('"visitorData".*?"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.I)
	if EwNgXqHTSJK6sR9LWrBU3Zh8v: mRJf2ElN8AYHIXCskSUruxgjFc = EwNgXqHTSJK6sR9LWrBU3Zh8v[0]
	cookies = cnPhVmgFxA.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): eDv42iKLNCb5uoA07wHfW = cookies['VISITOR_INFO1_LIVE']
	zBk0VHdLqXOQ = mRJf2ElN8AYHIXCskSUruxgjFc+':::'+key+':::'+Rc4dwqYitn9msyAEuokSKf5HrUTGDv+':::'+eDv42iKLNCb5uoA07wHfW+':::'+ffiueHIMq6oQxRpyO1ShacVGL4Pg
	if s0tfc7T2hwBM=='ytInitialData' and 'ytInitialData' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		lSU9XknmAEaZbTWwFBOd = ScntgdOZCY74vNpXeW5jh8i.findall('window\["ytInitialData"\] = ({.*?});',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not lSU9XknmAEaZbTWwFBOd: lSU9XknmAEaZbTWwFBOd = ScntgdOZCY74vNpXeW5jh8i.findall('var ytInitialData = ({.*?});',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		NNxwchK4sgA3aMJilkvqoSL8 = dr1zfnatJxRHSF48jh0eODm5bGu('str',lSU9XknmAEaZbTWwFBOd[0])
	elif s0tfc7T2hwBM=='ytInitialGuideData' and 'ytInitialGuideData' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		lSU9XknmAEaZbTWwFBOd = ScntgdOZCY74vNpXeW5jh8i.findall('var ytInitialGuideData = ({.*?});',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		NNxwchK4sgA3aMJilkvqoSL8 = dr1zfnatJxRHSF48jh0eODm5bGu('str',lSU9XknmAEaZbTWwFBOd[0])
	elif '</script>' not in UTvsQb4HpCP3Aeo2wDZG7X5V: NNxwchK4sgA3aMJilkvqoSL8 = dr1zfnatJxRHSF48jh0eODm5bGu('str',UTvsQb4HpCP3Aeo2wDZG7X5V)
	else: NNxwchK4sgA3aMJilkvqoSL8 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if 0:
		UXidK9mQzk = str(NNxwchK4sgA3aMJilkvqoSL8)
		if IZhXMprxvAHqBEFkg0: UXidK9mQzk = UXidK9mQzk.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open('S:\\0000emad.dat','wb').write(UXidK9mQzk)
	llnG7jiQBYKhAeovbT.setSetting('av.youtube.data',zBk0VHdLqXOQ)
	return UTvsQb4HpCP3Aeo2wDZG7X5V,NNxwchK4sgA3aMJilkvqoSL8,zBk0VHdLqXOQ
def wRSTtYUveNo(url,wX9P3dR07B5HynVa8):
	search = dR75Vq2gprfHmUcNhG()
	if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	plSscrVjkRviPwm = url+'/search?query='+search
	IGDobAKtj4kPF5V(plSscrVjkRviPwm,wX9P3dR07B5HynVa8)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in YE1hqa60dGTRDZ8NVBM: DXl4MTxz2qmPKjcIdtF1QhJ3f = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in YE1hqa60dGTRDZ8NVBM: DXl4MTxz2qmPKjcIdtF1QhJ3f = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in YE1hqa60dGTRDZ8NVBM: DXl4MTxz2qmPKjcIdtF1QhJ3f = '&sp=EgIQAg%253D%253D'
		else: DXl4MTxz2qmPKjcIdtF1QhJ3f = nbOFVEDkpT4BIR7Qq82yPmHeJU
		zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm+DXl4MTxz2qmPKjcIdtF1QhJ3f
	else:
		K0V6AHEvXReQN7gWt,wznIbY9hAdH3JZ5xUcK78fTP,HDE69mkhQg2NaFpuUy5JRb = [],[],nbOFVEDkpT4BIR7Qq82yPmHeJU
		BBnuEtgQbG6F8PXDsyf = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		Ho4YD0TMti9 = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		s1sB4jyXQcmTU6JG7VA5gZFEx = nnRXQH90qeOtABkJzGr('اختر البحث المناسب',BBnuEtgQbG6F8PXDsyf)
		if s1sB4jyXQcmTU6JG7VA5gZFEx == -1: return
		HHCEQhew4TXiqAUg3NtIS = Ho4YD0TMti9[s1sB4jyXQcmTU6JG7VA5gZFEx]
		UTvsQb4HpCP3Aeo2wDZG7X5V,qPR12SideET5Ljab,data = kkNFuBV2aTgK(plSscrVjkRviPwm+HHCEQhew4TXiqAUg3NtIS)
		if qPR12SideET5Ljab:
			try:
				Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6 = qPR12SideET5Ljab['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for SSCcG1ewzQU in range(len(Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6)):
					group = Ty7Zbg4ic15NzLPWr3IOUmJKSpFMk6[SSCcG1ewzQU]['searchFilterGroupRenderer']['filters']
					for YA6iT3jH91EDPxFtg in range(len(group)):
						bNd38Genk0lfcV = group[YA6iT3jH91EDPxFtg]['searchFilterRenderer']
						if 'navigationEndpoint' in list(bNd38Genk0lfcV.keys()):
							grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = bNd38Genk0lfcV['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('\u0026','&')
							title = bNd38Genk0lfcV['tooltip']
							title = title.replace('البحث عن ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								HDE69mkhQg2NaFpuUy5JRb = title
								f7Je8XzEqNpgHL9m4OURdAQ1 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								HDE69mkhQg2NaFpuUy5JRb = title
								f7Je8XzEqNpgHL9m4OURdAQ1 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
							if 'Sort by' in title: continue
							K0V6AHEvXReQN7gWt.append(eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title))
							wznIbY9hAdH3JZ5xUcK78fTP.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			except: pass
		if not HDE69mkhQg2NaFpuUy5JRb: v26IUydjlKYgR7w = nbOFVEDkpT4BIR7Qq82yPmHeJU
		else:
			K0V6AHEvXReQN7gWt = ['بدون فلتر',HDE69mkhQg2NaFpuUy5JRb]+K0V6AHEvXReQN7gWt
			wznIbY9hAdH3JZ5xUcK78fTP = [nbOFVEDkpT4BIR7Qq82yPmHeJU,f7Je8XzEqNpgHL9m4OURdAQ1]+wznIbY9hAdH3JZ5xUcK78fTP
			wh762VyY9WNxQkno3qjXI41deZE = nnRXQH90qeOtABkJzGr('موقع يوتيوب - اختر الفلتر',K0V6AHEvXReQN7gWt)
			if wh762VyY9WNxQkno3qjXI41deZE == -1: return
			v26IUydjlKYgR7w = wznIbY9hAdH3JZ5xUcK78fTP[wh762VyY9WNxQkno3qjXI41deZE]
		if v26IUydjlKYgR7w: zb2QIaL7Y4h9g8lSck = zKREXyTHfVSNL8ZFYs+v26IUydjlKYgR7w
		elif HHCEQhew4TXiqAUg3NtIS: zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm+HHCEQhew4TXiqAUg3NtIS
		else: zb2QIaL7Y4h9g8lSck = plSscrVjkRviPwm
	IGDobAKtj4kPF5V(zb2QIaL7Y4h9g8lSck)
	return
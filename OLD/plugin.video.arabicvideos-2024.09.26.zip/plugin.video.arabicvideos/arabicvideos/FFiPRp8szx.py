# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
VGjzYJZykfEWxlQLeap = 'IPTV'
PPZDQo6RAG3a0Ot1Ydc5Fwz = '_IPT_'
GUf84z2bdKlc7PpywoNrDVg = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_ARCHIVED_GROUPED_SORTED','LIVE_EPG_GROUPED_SORTED','LIVE_TIMESHIFT_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
def z4CledbofIyhpZVjugFO(EYMmnJAyxV,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,iiyAEbQ5f80,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL):
	global PPZDQo6RAG3a0Ot1Ydc5Fwz
	try:
		gYJAT1vW0Uqm76G = str(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL['folder'])
		PPZDQo6RAG3a0Ot1Ydc5Fwz = '_IP'+gYJAT1vW0Uqm76G+'_'
	except: gYJAT1vW0Uqm76G = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if   EYMmnJAyxV==230: UmwA0cdOSg2s7vnKR8zYp4ohWqH = K8dEcSDisO2zXLVl39CTRU1()
	elif EYMmnJAyxV==231: UmwA0cdOSg2s7vnKR8zYp4ohWqH = E0PNDIAiaYkKRpx(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==232: UmwA0cdOSg2s7vnKR8zYp4ohWqH = V8YhRNmegG(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==233: UmwA0cdOSg2s7vnKR8zYp4ohWqH = ITqsrkfZpxUMCWVYKi9Qy(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	elif EYMmnJAyxV==234: UmwA0cdOSg2s7vnKR8zYp4ohWqH = KwinXTzJv1N8yghA9UbI0HueGqa7R(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	elif EYMmnJAyxV==235: UmwA0cdOSg2s7vnKR8zYp4ohWqH = AOk1T6KwciHrWU2MYJzZnEN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,iiyAEbQ5f80)
	elif EYMmnJAyxV==236: UmwA0cdOSg2s7vnKR8zYp4ohWqH = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,True)
	elif EYMmnJAyxV==237: UmwA0cdOSg2s7vnKR8zYp4ohWqH = jjIfEhLyl2wu9UGrcFe(gYJAT1vW0Uqm76G,True)
	elif EYMmnJAyxV==238: UmwA0cdOSg2s7vnKR8zYp4ohWqH = kC4fo85D9AW6EPIKi1LyTugdN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==239: UmwA0cdOSg2s7vnKR8zYp4ohWqH = CCLlhnQdcKiA(J1rvN7I8eLXuS54mZ6lnUjg,gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	elif EYMmnJAyxV==280: UmwA0cdOSg2s7vnKR8zYp4ohWqH = hraw5mCZRvLQxX1iH(gYJAT1vW0Uqm76G,True)
	elif EYMmnJAyxV==281: UmwA0cdOSg2s7vnKR8zYp4ohWqH = eL6JlI0X94nyamjOAhu3U1BDgic(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==282: UmwA0cdOSg2s7vnKR8zYp4ohWqH = xu91PRNQyqg7DTMUrOXphEYB6(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==283: UmwA0cdOSg2s7vnKR8zYp4ohWqH = ZHuG4LETX5jcK1tBgbzehNxUakFq(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==285: UmwA0cdOSg2s7vnKR8zYp4ohWqH = RQ30OIxnSVbmetkKu5P7z(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==286: UmwA0cdOSg2s7vnKR8zYp4ohWqH = sAkcixqeBNVbZIPdSo(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==289: UmwA0cdOSg2s7vnKR8zYp4ohWqH = Cndl86Apt9owz(J1rvN7I8eLXuS54mZ6lnUjg,gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	else: UmwA0cdOSg2s7vnKR8zYp4ohWqH = False
	return UmwA0cdOSg2s7vnKR8zYp4ohWqH
def K8dEcSDisO2zXLVl39CTRU1():
	for gYJAT1vW0Uqm76G in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
		PPZDQo6RAG3a0Ot1Ydc5Fwz = '_IP'+str(gYJAT1vW0Uqm76G)+'_'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قائمة مجلد '+rto0iz1Gk2xAmICHDhqR6FPnMK[gYJAT1vW0Uqm76G],nbOFVEDkpT4BIR7Qq82yPmHeJU,280,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	return
def hraw5mCZRvLQxX1iH(gYJAT1vW0Uqm76G=nbOFVEDkpT4BIR7Qq82yPmHeJU,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if gYJAT1vW0Uqm76G:
		c4sHM5DbmLC = {'folder':gYJAT1vW0Uqm76G}
		DnWF2omGyk4EpQP81q9uviZs = nbOFVEDkpT4BIR7Qq82yPmHeJU
	else:
		c4sHM5DbmLC = nbOFVEDkpT4BIR7Qq82yPmHeJU
		DnWF2omGyk4EpQP81q9uviZs = nbOFVEDkpT4BIR7Qq82yPmHeJU
	ayOS4QxTbDtLclVeJFpA3XohK1m76W = a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep)
	if not ayOS4QxTbDtLclVeJFpA3XohK1m76W:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+l5JG7XwbOfo8DznU+' إضافة أو تغيير اشتراك'+DnWF2omGyk4EpQP81q9uviZs+' '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,231,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+l5JG7XwbOfo8DznU+' جلب ملفات'+DnWF2omGyk4EpQP81q9uviZs+' '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,232,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	else:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'بحث في الملفات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,289,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات بدون جلب ملفات','XTREAM_LIVE_GROUPS',285,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة من القسم'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_FROM_GROUP_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة من الاسم'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_FROM_NAME_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_ORIGINAL_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مجهولة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_UNKNOWN_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مجهولة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_UNKNOWN_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أفلام بدون جلب ملفات','XTREAM_VOD_GROUPS',285,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أفلام مصنفة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'VOD_MOVIES_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أفلام مصنفة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'VOD_MOVIES_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'مسلسلات بدون جلب ملفات','XTREAM_SERIES_GROUPS',285,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'مسلسلات مصنفة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'VOD_SERIES_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'مسلسلات مصنفة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'VOD_SERIES_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'VOD_ORIGINAL_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مصنفة من القسم'+DnWF2omGyk4EpQP81q9uviZs,'VOD_FROM_GROUP_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مصنفة من الاسم'+DnWF2omGyk4EpQP81q9uviZs,'VOD_FROM_NAME_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مجهولة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'VOD_UNKNOWN_GROUPED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مجهولة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'VOD_UNKNOWN_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'برامج القنوات (جدول فقط)'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_EPG_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أرشيف القنوات للأيام الماضية'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_TIMESHIFT_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أرشيف برامج القنوات للأيام الماضية'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_ARCHIVED_GROUPED_SORTED',233,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'إضافة أو تغيير اشتراك'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,231,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'جلب ملفات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,232,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'مسح ملفات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,237,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فحص اشتراك'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,236,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'عدد فيديوهات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,281,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'Referer تغيير'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,286,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'User-Agent تغيير'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,283,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'استخدم السيرفر الأسرع'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,282,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	return
def YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	yyThwHJRP2SI1Y0knGEdAzZMDcLo,ceHxw7y6CKdv39X0N1Gr = False,nbOFVEDkpT4BIR7Qq82yPmHeJU
	VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G)
	if BarI1m9u06gVdhyCjGYWXbUv==nbOFVEDkpT4BIR7Qq82yPmHeJU: return False,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	YeRr5GFOCqn9ufVy = Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G)
	if fPY3NmaF1d0W2b:
		BTxl2eLIqSzUk = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',fPY3NmaF1d0W2b,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IPTV-CHECK_ACCOUNT-1st')
		oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
		if BTxl2eLIqSzUk.succeeded:
			a601NOifzA8ye43JnCFwqxYmWSv,ppd79g2rKSQnOLY,E1xw7TApYqVS,veHW9rfmONgzc67AjlyDYdno83E,DF4i2jqhc1YHn3rPKzS6UxwLGo = 0,0,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
			try:
				wa6j19u4KBdp = dr1zfnatJxRHSF48jh0eODm5bGu('dict',oHQzKutsWeALwSEXc8a)
				ceHxw7y6CKdv39X0N1Gr = wa6j19u4KBdp['user_info']['status']
				yyThwHJRP2SI1Y0knGEdAzZMDcLo = True
				E1xw7TApYqVS = wa6j19u4KBdp['server_info']['time_now']
			except: pass
			if E1xw7TApYqVS:
				try:
					U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.strptime(E1xw7TApYqVS,'%Y.%m.%d %H:%M:%S')
					a601NOifzA8ye43JnCFwqxYmWSv = int(lQMuw1PvVpAk.mktime(U6SJ0tY7eRboijnWvA3lFVPwQk8D2N))
					ppd79g2rKSQnOLY = int(sqeRK2tVw8-a601NOifzA8ye43JnCFwqxYmWSv)
					ppd79g2rKSQnOLY = int((ppd79g2rKSQnOLY+900)/1800)*1800
				except: pass
				try:
					U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(int(wa6j19u4KBdp['user_info']['created_at']))
					veHW9rfmONgzc67AjlyDYdno83E = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M:%S',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
				except: pass
				try:
					U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(int(wa6j19u4KBdp['user_info']['exp_date']))
					DF4i2jqhc1YHn3rPKzS6UxwLGo = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M:%S',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
				except: pass
			llnG7jiQBYKhAeovbT.setSetting('av.iptv.timestamp_'+gYJAT1vW0Uqm76G,str(sqeRK2tVw8))
			llnG7jiQBYKhAeovbT.setSetting('av.iptv.timediff_'+gYJAT1vW0Uqm76G,str(ppd79g2rKSQnOLY))
			try:
				vjYi7m9MxnsdWXTeRVB6Z30t5O = '"server_info":'+oHQzKutsWeALwSEXc8a.split('"server_info":')[1]
				vjYi7m9MxnsdWXTeRVB6Z30t5O = vjYi7m9MxnsdWXTeRVB6Z30t5O.replace(':',': ').replace(',',', ').replace('}}','}')
				RiWp7Kt0DFh9bgcfPZBnJOVSE1sxzU = ScntgdOZCY74vNpXeW5jh8i.findall('"url": "(.*?)", "port": "(.*?)"',vjYi7m9MxnsdWXTeRVB6Z30t5O,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = RiWp7Kt0DFh9bgcfPZBnJOVSE1sxzU[0]
			except: yyThwHJRP2SI1Y0knGEdAzZMDcLo = False
			if yyThwHJRP2SI1Y0knGEdAzZMDcLo and O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
				max = wa6j19u4KBdp['user_info']['max_connections']
				tbT58jZHfYU9i1ena = wa6j19u4KBdp['user_info']['active_cons']
				OGitkVUogKIEwc1pXA7qdYLvNbB = wa6j19u4KBdp['user_info']['is_trial']
				UES13IuBRwzxOg = fPY3NmaF1d0W2b.split('?',1)
				CtO9cFuULSm62PWToMlzN1 = 'URL:  '+eMypvI8XqHjYU02anWD9gsSrkt+fPY3NmaF1d0W2b+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\n\nStatus:  '+eMypvI8XqHjYU02anWD9gsSrkt+ceHxw7y6CKdv39X0N1Gr+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nTrial:    '+eMypvI8XqHjYU02anWD9gsSrkt+str(OGitkVUogKIEwc1pXA7qdYLvNbB=='1')+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nCreated  At:  '+eMypvI8XqHjYU02anWD9gsSrkt+veHW9rfmONgzc67AjlyDYdno83E+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nExpiry Date:  '+eMypvI8XqHjYU02anWD9gsSrkt+DF4i2jqhc1YHn3rPKzS6UxwLGo+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nConnections   ( Active / Maximum ) :  '+eMypvI8XqHjYU02anWD9gsSrkt+tbT58jZHfYU9i1ena+' / '+max+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nAllowed Outputs:   '+eMypvI8XqHjYU02anWD9gsSrkt+" , ".join(wa6j19u4KBdp['user_info']['allowed_output_formats'])+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\n\n'+vjYi7m9MxnsdWXTeRVB6Z30t5O
				if ceHxw7y6CKdv39X0N1Gr=='Active': zU4taVvj6x12('الاشتراك يعمل بدون مشاكل',CtO9cFuULSm62PWToMlzN1)
				else: zU4taVvj6x12('يبدو أن هناك مشكلة في الاشتراك',CtO9cFuULSm62PWToMlzN1)
	if fPY3NmaF1d0W2b and yyThwHJRP2SI1Y0knGEdAzZMDcLo and ceHxw7y6CKdv39X0N1Gr=='Active':
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,'.\tChecking IPTV URL   [ IPTV account is OK ]   [ '+fPY3NmaF1d0W2b+' ]')
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv = True
	else:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,'Checking IPTV URL   [ Does not work ]   [ '+fPY3NmaF1d0W2b+' ]')
		if O3asTXHd4Jm2KCQRUwvbtE8fuDAep: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv = False
	return aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX
def KwinXTzJv1N8yghA9UbI0HueGqa7R(gYJAT1vW0Uqm76G,GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG,GGyLnP8egKaM9Oxr,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
	AABDgbaTdl5ShcJWKGCeP1st0N7Ip = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list',GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG)
	gIqD4ESsoTy5AV73uY = int(GGyLnP8egKaM9Oxr)*100
	ggA7LcUQRr = gIqD4ESsoTy5AV73uY-100
	for R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in AABDgbaTdl5ShcJWKGCeP1st0N7Ip[ggA7LcUQRr:gIqD4ESsoTy5AV73uY]:
		ii8MX4g6Jpmzy0rh7u = ('GROUPED' in GIplj3KhV8dc or GIplj3KhV8dc=='ALL')
		JfYeiqVQ1F7ZWp9 = ('GROUPED' not in GIplj3KhV8dc and GIplj3KhV8dc!='ALL')
		if ii8MX4g6Jpmzy0rh7u or JfYeiqVQ1F7ZWp9:
			if   'ARCHIVED'  in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,238,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARCHIVED',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
			elif 'EPG' 		 in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,238,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FULL_EPG',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
			elif 'TIMESHIFT' in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,238,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TIMESHIFT',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
			elif 'LIVE' 	 in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['live',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,235,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,R0gbu46Cw9ZKhB5jsT8HAcGv,{'folder':gYJAT1vW0Uqm76G}])
			else: LvJuOzMqk6WlP971eoGpUQ8.append(['video',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,235,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
	WWXzI34UZEqYhf25uxJwLVo = len(AABDgbaTdl5ShcJWKGCeP1st0N7Ip)
	E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,234,WWXzI34UZEqYhf25uxJwLVo,IWFYt6Pq9NRk5JD3OG)
	return
def yrlUp0qAiT4wJNcHtWEhC8VbxGn(BDmSaXN05hsoRTzO6):
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+'هذه القائمة إما فارغة أو غير موجودة',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+'أو الخدمة غير موجودة في اشتراكك',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+'أو رابط IPTVـ الذي أنت أضفته غير صحيح',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	return
def ITqsrkfZpxUMCWVYKi9Qy(gYJAT1vW0Uqm76G,GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG,GGyLnP8egKaM9Oxr,RxBINUEMFPfsD3nrZoQ=nbOFVEDkpT4BIR7Qq82yPmHeJU,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	BDmSaXN05hsoRTzO6 = PPZDQo6RAG3a0Ot1Ydc5Fwz
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return False
	if '__SERIES__' in IWFYt6Pq9NRk5JD3OG: kJPeLjd2XE,JJiXBPu73g0QKCA2dGqxomphUMLW5 = IWFYt6Pq9NRk5JD3OG.split('__SERIES__')
	else: kJPeLjd2XE,JJiXBPu73g0QKCA2dGqxomphUMLW5 = IWFYt6Pq9NRk5JD3OG,nbOFVEDkpT4BIR7Qq82yPmHeJU
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
	AEFhLqn2BYR1IQ = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list',GIplj3KhV8dc,'__GROUPS__')
	if not AEFhLqn2BYR1IQ: return False
	SxtuIkQyVZEr = []
	for q4qfsInUtRDYlXdvTMe02xPNC,ayoEi7YNWD in AEFhLqn2BYR1IQ:
		if RxBINUEMFPfsD3nrZoQ:
			if '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: BDmSaXN05hsoRTzO6 = 'SERIES'
			elif '!!__UNKNOWN__!!' in q4qfsInUtRDYlXdvTMe02xPNC: BDmSaXN05hsoRTzO6 = 'UNKNOWN'
			elif 'LIVE' in GIplj3KhV8dc: BDmSaXN05hsoRTzO6 = 'LIVE'
			else: BDmSaXN05hsoRTzO6 = 'VIDEOS'
			BDmSaXN05hsoRTzO6 = ','+eMypvI8XqHjYU02anWD9gsSrkt+BDmSaXN05hsoRTzO6+': '+c7gxFyUCGm
		if '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: b2VJoUNBzi4OYdF,pPFrIbNGX8sSMTQt6HWaEwu4eqO = q4qfsInUtRDYlXdvTMe02xPNC.split('__SERIES__')
		else: b2VJoUNBzi4OYdF,pPFrIbNGX8sSMTQt6HWaEwu4eqO = q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU
		if not IWFYt6Pq9NRk5JD3OG:
			if b2VJoUNBzi4OYdF in SxtuIkQyVZEr: continue
			SxtuIkQyVZEr.append(b2VJoUNBzi4OYdF)
			if 'RANDOM' in RxBINUEMFPfsD3nrZoQ: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+b2VJoUNBzi4OYdF,GIplj3KhV8dc,167,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			elif '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+b2VJoUNBzi4OYdF,GIplj3KhV8dc,233,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+b2VJoUNBzi4OYdF,GIplj3KhV8dc,234,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
		elif '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC and b2VJoUNBzi4OYdF==kJPeLjd2XE:
			if pPFrIbNGX8sSMTQt6HWaEwu4eqO in SxtuIkQyVZEr: continue
			SxtuIkQyVZEr.append(pPFrIbNGX8sSMTQt6HWaEwu4eqO)
			if 'RANDOM' in RxBINUEMFPfsD3nrZoQ: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+pPFrIbNGX8sSMTQt6HWaEwu4eqO,GIplj3KhV8dc,167,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+pPFrIbNGX8sSMTQt6HWaEwu4eqO,GIplj3KhV8dc,234,ayoEi7YNWD,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	LvJuOzMqk6WlP971eoGpUQ8[:] = sorted(LvJuOzMqk6WlP971eoGpUQ8,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[1].lower())
	if not RxBINUEMFPfsD3nrZoQ:
		gIqD4ESsoTy5AV73uY = int(GGyLnP8egKaM9Oxr)*100
		ggA7LcUQRr = gIqD4ESsoTy5AV73uY-100
		WWXzI34UZEqYhf25uxJwLVo = len(LvJuOzMqk6WlP971eoGpUQ8)
		LvJuOzMqk6WlP971eoGpUQ8[:] = LvJuOzMqk6WlP971eoGpUQ8[ggA7LcUQRr:gIqD4ESsoTy5AV73uY]
		E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,233,WWXzI34UZEqYhf25uxJwLVo,IWFYt6Pq9NRk5JD3OG)
	return True
def kC4fo85D9AW6EPIKi1LyTugdN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,k0nHCSW52Kdqx4PO1BVDiF):
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,True): return
	YeRr5GFOCqn9ufVy = Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G)
	a601NOifzA8ye43JnCFwqxYmWSv = llnG7jiQBYKhAeovbT.getSetting('av.iptv.timestamp_'+gYJAT1vW0Uqm76G)
	if not a601NOifzA8ye43JnCFwqxYmWSv or sqeRK2tVw8-int(a601NOifzA8ye43JnCFwqxYmWSv)>24*wfVkBtgLUIM3N6Ozy2i5pxlT:
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,False)
		if not aBStCuH2RG4fOZJp19XAbKkI5xe7Nv: return
	ppd79g2rKSQnOLY = int(llnG7jiQBYKhAeovbT.getSetting('av.iptv.timediff_'+gYJAT1vW0Uqm76G))
	o0TYhleWOM = llnG7jiQBYKhAeovbT.getSetting('av.iptv.server_'+gYJAT1vW0Uqm76G)
	BarI1m9u06gVdhyCjGYWXbUv = llnG7jiQBYKhAeovbT.getSetting('av.iptv.username_'+gYJAT1vW0Uqm76G)
	MLkvbSEfXz = llnG7jiQBYKhAeovbT.getSetting('av.iptv.password_'+gYJAT1vW0Uqm76G)
	RRsTHyuLaFSJrpkMzGco6NWVKhd = wNyZhHdvUeC3M.split('/')
	AAYEoBlQns5 = RRsTHyuLaFSJrpkMzGco6NWVKhd[-1].replace('.ts',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.m3u8',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if k0nHCSW52Kdqx4PO1BVDiF=='SHORT_EPG': kWXFQVIwxB3limsKy4cgfUMYbtj = 'get_short_epg'
	else: kWXFQVIwxB3limsKy4cgfUMYbtj = 'get_simple_data_table'
	fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G)
	if not BarI1m9u06gVdhyCjGYWXbUv: return
	zaIqTnRdcDg8YQGZeSPbUX = fPY3NmaF1d0W2b+'&action='+kWXFQVIwxB3limsKy4cgfUMYbtj+'&stream_id='+AAYEoBlQns5
	oHQzKutsWeALwSEXc8a = kPVgovOiMwCdNfESc1QLmK3B8526D(zDoPOYNsJg2id1HLnx5bpf,zaIqTnRdcDg8YQGZeSPbUX,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IPTV-EPG_ITEMS-2nd')
	rr1xyGZiXBbDnswoQOfk0zN87 = dr1zfnatJxRHSF48jh0eODm5bGu('dict',oHQzKutsWeALwSEXc8a)
	kS1rJepN0jl29fQACPqFhyZdzKRb = rr1xyGZiXBbDnswoQOfk0zN87['epg_listings']
	c2HW19hO85y = []
	if k0nHCSW52Kdqx4PO1BVDiF in ['ARCHIVED','TIMESHIFT']:
		for wa6j19u4KBdp in kS1rJepN0jl29fQACPqFhyZdzKRb:
			if wa6j19u4KBdp['has_archive']==1:
				c2HW19hO85y.append(wa6j19u4KBdp)
				if k0nHCSW52Kdqx4PO1BVDiF in ['TIMESHIFT']: break
		if not c2HW19hO85y: return
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+eMypvI8XqHjYU02anWD9gsSrkt+'الملفات الأولي بهذه القائمة قد لا تعمل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		if k0nHCSW52Kdqx4PO1BVDiF in ['TIMESHIFT']:
			nAktrezULFdcYlpOujK9W7f0qQs = 2
			UTm5bfW3g2GsQSw98xHLeE1KJyDI = nAktrezULFdcYlpOujK9W7f0qQs*wfVkBtgLUIM3N6Ozy2i5pxlT
			c2HW19hO85y = []
			GsC8wyQ2S0Mcd49kKfOIEojqFlrv = int(int(wa6j19u4KBdp['start_timestamp'])/UTm5bfW3g2GsQSw98xHLeE1KJyDI)*UTm5bfW3g2GsQSw98xHLeE1KJyDI
			yyNo1iZvxM5YTw7BP6K = sqeRK2tVw8+UTm5bfW3g2GsQSw98xHLeE1KJyDI
			tHNkelqBfUima9 = int((yyNo1iZvxM5YTw7BP6K-GsC8wyQ2S0Mcd49kKfOIEojqFlrv)/wfVkBtgLUIM3N6Ozy2i5pxlT)
			for EESRd0rNUVBQoX8F1 in range(tHNkelqBfUima9):
				if EESRd0rNUVBQoX8F1>=6:
					if EESRd0rNUVBQoX8F1%nAktrezULFdcYlpOujK9W7f0qQs!=0: continue
					vQgYUMCXexcZrWbHjBlL1FkqP = UTm5bfW3g2GsQSw98xHLeE1KJyDI
				else: vQgYUMCXexcZrWbHjBlL1FkqP = UTm5bfW3g2GsQSw98xHLeE1KJyDI//2
				SLduBNkwpAEqQDKr4mj = GsC8wyQ2S0Mcd49kKfOIEojqFlrv+EESRd0rNUVBQoX8F1*wfVkBtgLUIM3N6Ozy2i5pxlT
				wa6j19u4KBdp = {}
				wa6j19u4KBdp['title'] = nbOFVEDkpT4BIR7Qq82yPmHeJU
				U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(SLduBNkwpAEqQDKr4mj-ppd79g2rKSQnOLY-wfVkBtgLUIM3N6Ozy2i5pxlT)
				wa6j19u4KBdp['start'] = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M:%S',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
				wa6j19u4KBdp['start_timestamp'] = str(SLduBNkwpAEqQDKr4mj)
				wa6j19u4KBdp['stop_timestamp'] = str(SLduBNkwpAEqQDKr4mj+vQgYUMCXexcZrWbHjBlL1FkqP)
				c2HW19hO85y.append(wa6j19u4KBdp)
	elif k0nHCSW52Kdqx4PO1BVDiF in ['SHORT_EPG','FULL_EPG']: c2HW19hO85y = kS1rJepN0jl29fQACPqFhyZdzKRb
	if k0nHCSW52Kdqx4PO1BVDiF=='FULL_EPG' and len(c2HW19hO85y)>0:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+eMypvI8XqHjYU02anWD9gsSrkt+'هذه قائمة برامج القنوات (جدول فقط)ـ'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Eihjk8bvNDTl4HKysaV = []
	ayoEi7YNWD = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Icon')
	for wa6j19u4KBdp in c2HW19hO85y:
		GdbFDygsZ6HopImiSTY53 = Y7goyGlxwNaP1XcWU6e.b64decode(wa6j19u4KBdp['title'])
		if IZhXMprxvAHqBEFkg0: GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		SLduBNkwpAEqQDKr4mj = int(wa6j19u4KBdp['start_timestamp'])
		SQb6TkXINJ5hsxtZACvu = int(wa6j19u4KBdp['stop_timestamp'])
		SkMYHbEx567vuqU9jGf3 = str(int((SQb6TkXINJ5hsxtZACvu-SLduBNkwpAEqQDKr4mj+59)/60))
		dVDOF3Ef1TqxHzXJwuRZjg = wa6j19u4KBdp['start'].replace(S3X6GcaiExOPtb,':')
		U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(SLduBNkwpAEqQDKr4mj-wfVkBtgLUIM3N6Ozy2i5pxlT)
		Mk93VFXluZJyW = lQMuw1PvVpAk.strftime('%H:%M',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
		kqgJfoEeKUj45 = lQMuw1PvVpAk.strftime('%a',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
		if k0nHCSW52Kdqx4PO1BVDiF=='SHORT_EPG': GdbFDygsZ6HopImiSTY53 = l5JG7XwbOfo8DznU+Mk93VFXluZJyW+' ـ '+GdbFDygsZ6HopImiSTY53+c7gxFyUCGm
		elif k0nHCSW52Kdqx4PO1BVDiF=='TIMESHIFT': GdbFDygsZ6HopImiSTY53 = kqgJfoEeKUj45+S3X6GcaiExOPtb+Mk93VFXluZJyW+' ('+SkMYHbEx567vuqU9jGf3+'min)'
		else: GdbFDygsZ6HopImiSTY53 = kqgJfoEeKUj45+S3X6GcaiExOPtb+Mk93VFXluZJyW+' ('+SkMYHbEx567vuqU9jGf3+'min)   '+GdbFDygsZ6HopImiSTY53+' ـ'
		if k0nHCSW52Kdqx4PO1BVDiF in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			YYPztCbNZITr0QHiWpAJmM76K = o0TYhleWOM+'/timeshift/'+BarI1m9u06gVdhyCjGYWXbUv+'/'+MLkvbSEfXz+'/'+SkMYHbEx567vuqU9jGf3+'/'+dVDOF3Ef1TqxHzXJwuRZjg+'/'+AAYEoBlQns5+'.m3u8'
			if k0nHCSW52Kdqx4PO1BVDiF=='FULL_EPG': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,YYPztCbNZITr0QHiWpAJmM76K,9999,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,YYPztCbNZITr0QHiWpAJmM76K,235,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
		Eihjk8bvNDTl4HKysaV.append(GdbFDygsZ6HopImiSTY53)
	if k0nHCSW52Kdqx4PO1BVDiF=='SHORT_EPG' and Eihjk8bvNDTl4HKysaV: rxAoL8pD5USRBImHC47W = unWTBJIFERUQqx0NS5DOjgP(Eihjk8bvNDTl4HKysaV)
	return Eihjk8bvNDTl4HKysaV
def xu91PRNQyqg7DTMUrOXphEYB6(gYJAT1vW0Uqm76G):
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,True): return
	o0TYhleWOM,oiqWL8T6cU,LrZiukpn2v = nbOFVEDkpT4BIR7Qq82yPmHeJU,0,0
	aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,False)
	if aBStCuH2RG4fOZJp19XAbKkI5xe7Nv:
		hg6ELCjF7UDlyxrBTb0nJZ4cum = PNFTZx6gr4ycq(VLlfzHGkZQ0ModFbWq4D)
		oiqWL8T6cU = PPwLpT7XsB(hg6ELCjF7UDlyxrBTb0nJZ4cum[0],int(pwO2bxAaRDIFX))
		nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'LIVE_GROUPED')
		HNicWMGkpKj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list','LIVE_GROUPED')
		AABDgbaTdl5ShcJWKGCeP1st0N7Ip = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list','LIVE_GROUPED',HNicWMGkpKj[1])
		wNyZhHdvUeC3M = AABDgbaTdl5ShcJWKGCeP1st0N7Ip[0][2]
		iayfxuFeTloLW1cmBHSDh5r7R3Eq0 = ScntgdOZCY74vNpXeW5jh8i.findall('://(.*?)/',wNyZhHdvUeC3M,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		iayfxuFeTloLW1cmBHSDh5r7R3Eq0 = iayfxuFeTloLW1cmBHSDh5r7R3Eq0[0]
		if ':' in iayfxuFeTloLW1cmBHSDh5r7R3Eq0: DDnW1cXvgS4J60Nx8lKtr2VdAfRY,Y89RSPgZpbQN4wco2TlLqUhWnX = iayfxuFeTloLW1cmBHSDh5r7R3Eq0.split(':')
		else: DDnW1cXvgS4J60Nx8lKtr2VdAfRY,Y89RSPgZpbQN4wco2TlLqUhWnX = iayfxuFeTloLW1cmBHSDh5r7R3Eq0,'80'
		jjb8HaTF3LrECv52kmU = PNFTZx6gr4ycq(DDnW1cXvgS4J60Nx8lKtr2VdAfRY)
		LrZiukpn2v = PPwLpT7XsB(jjb8HaTF3LrECv52kmU[0],int(Y89RSPgZpbQN4wco2TlLqUhWnX))
	if oiqWL8T6cU and LrZiukpn2v:
		CtO9cFuULSm62PWToMlzN1 = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		CtO9cFuULSm62PWToMlzN1 += '\n\n'+'وقت ضائع في السيرفر الأصلي'+wwOnIucWJj+str(int(LrZiukpn2v*1000))+' ملي ثانية'
		CtO9cFuULSm62PWToMlzN1 += '\n\n'+'وقت ضائع في السيرفر البديل'+wwOnIucWJj+str(int(oiqWL8T6cU*1000))+' ملي ثانية'
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',CtO9cFuULSm62PWToMlzN1)
		if JvOL5Wr9s6==1 and oiqWL8T6cU<LrZiukpn2v: o0TYhleWOM = VLlfzHGkZQ0ModFbWq4D+':'+pwO2bxAaRDIFX
	else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	llnG7jiQBYKhAeovbT.setSetting('av.iptv.server_'+gYJAT1vW0Uqm76G,o0TYhleWOM)
	return
def AOk1T6KwciHrWU2MYJzZnEN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,iiyAEbQ5f80):
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.iptv.useragent_'+gYJAT1vW0Uqm76G)
	kYFoe7P0tzCaZ = llnG7jiQBYKhAeovbT.getSetting('av.iptv.referer_'+gYJAT1vW0Uqm76G)
	if ltDKzevu94swOC0YqBPMR76 or kYFoe7P0tzCaZ:
		wNyZhHdvUeC3M += '|'
		if ltDKzevu94swOC0YqBPMR76: wNyZhHdvUeC3M += '&User-Agent='+ltDKzevu94swOC0YqBPMR76
		if kYFoe7P0tzCaZ: wNyZhHdvUeC3M += '&Referer='+kYFoe7P0tzCaZ
		wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace('|&','|')
	Jjr50NMtLvxVbyRkz86eqI1nwE = llnG7jiQBYKhAeovbT.getSetting('av.iptv.server_'+gYJAT1vW0Uqm76G)
	if Jjr50NMtLvxVbyRkz86eqI1nwE:
		xdl9XzfU8tiEDm3wkV4 = ScntgdOZCY74vNpXeW5jh8i.findall('://(.*?)/',wNyZhHdvUeC3M,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace(xdl9XzfU8tiEDm3wkV4[0],Jjr50NMtLvxVbyRkz86eqI1nwE)
	brh5aWRxQzn6YL8UDNOyK9SFGo(wNyZhHdvUeC3M,VGjzYJZykfEWxlQLeap,iiyAEbQ5f80)
	return
def ZHuG4LETX5jcK1tBgbzehNxUakFq(gYJAT1vW0Uqm76G):
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـUser-Agent خاص')
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.iptv.useragent_'+gYJAT1vW0Uqm76G)
	rhcetwI14l = ttiZs4bKHFvugJj5z('center','استخدام الأصلي','تعديل القديم',ltDKzevu94swOC0YqBPMR76,'هذا هو ـUser-Agent المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if rhcetwI14l==1: ltDKzevu94swOC0YqBPMR76 = dR75Vq2gprfHmUcNhG('أكتب ـIPTV User-Agent جديد',ltDKzevu94swOC0YqBPMR76,True)
	else: ltDKzevu94swOC0YqBPMR76 = 'Unknown'
	if ltDKzevu94swOC0YqBPMR76==S3X6GcaiExOPtb:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ltDKzevu94swOC0YqBPMR76,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if rhcetwI14l!=1:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإلغاء')
		return
	llnG7jiQBYKhAeovbT.setSetting('av.iptv.useragent_'+gYJAT1vW0Uqm76G,ltDKzevu94swOC0YqBPMR76)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def sAkcixqeBNVbZIPdSo(gYJAT1vW0Uqm76G):
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـIPTV أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـIPTV تحتاج ـReferer خاص')
	kYFoe7P0tzCaZ = llnG7jiQBYKhAeovbT.getSetting('av.iptv.referer_'+gYJAT1vW0Uqm76G)
	rhcetwI14l = ttiZs4bKHFvugJj5z('center','استخدام الأصلي','تعديل القديم',kYFoe7P0tzCaZ,'هذا هو ـReferer المستخدم حاليا مع ـIPTV الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـIPTV ؟!')
	if rhcetwI14l==1: kYFoe7P0tzCaZ = dR75Vq2gprfHmUcNhG('أكتب ـIPTV Referer جديد',kYFoe7P0tzCaZ,True)
	else: kYFoe7P0tzCaZ = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if kYFoe7P0tzCaZ==S3X6GcaiExOPtb:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,kYFoe7P0tzCaZ,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if rhcetwI14l!=1:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإلغاء')
		return
	llnG7jiQBYKhAeovbT.setSetting('av.iptv.referer_'+gYJAT1vW0Uqm76G,kYFoe7P0tzCaZ)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G,KUi1tJaIgOd9So5LvPeVc4jfA=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not KUi1tJaIgOd9So5LvPeVc4jfA: KUi1tJaIgOd9So5LvPeVc4jfA = llnG7jiQBYKhAeovbT.getSetting('av.iptv.url_'+gYJAT1vW0Uqm76G)
	o0TYhleWOM = Qi32bRtN18qvyWmaO7YKow9cXs(KUi1tJaIgOd9So5LvPeVc4jfA,'url')
	BarI1m9u06gVdhyCjGYWXbUv = ScntgdOZCY74vNpXeW5jh8i.findall('username=(.*?)&',KUi1tJaIgOd9So5LvPeVc4jfA+'&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	MLkvbSEfXz = ScntgdOZCY74vNpXeW5jh8i.findall('password=(.*?)&',KUi1tJaIgOd9So5LvPeVc4jfA+'&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not BarI1m9u06gVdhyCjGYWXbUv or not MLkvbSEfXz:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'فحص اشتراك ـIPTV','رابط اشتراك ـIPTV الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـIPTV وقم بإضافة رابط ـIPTV جديد أو قم بإصلاح الرابط القديم')
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	BarI1m9u06gVdhyCjGYWXbUv = BarI1m9u06gVdhyCjGYWXbUv[0]
	MLkvbSEfXz = MLkvbSEfXz[0]
	fPY3NmaF1d0W2b = o0TYhleWOM+'/player_api.php?username='+BarI1m9u06gVdhyCjGYWXbUv+'&password='+MLkvbSEfXz
	PEQBv9wdpSXqYRjK6I = o0TYhleWOM+'/get.php?username='+BarI1m9u06gVdhyCjGYWXbUv+'&password='+MLkvbSEfXz+'&type=m3u_plus'
	return fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz
def TWUofuz7I4JdSbesw6V(gYJAT1vW0Uqm76G,XSs23UuGCgOPATm7hY=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	fvV4HSZqTK3LYzJ15BD = XSs23UuGCgOPATm7hY.replace('/','_').replace(':','_').replace('.','_')
	fvV4HSZqTK3LYzJ15BD = fvV4HSZqTK3LYzJ15BD.replace('?','_').replace('=','_').replace('&','_')
	fvV4HSZqTK3LYzJ15BD = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,fvV4HSZqTK3LYzJ15BD).strip('.m3u')+'.m3u'
	return fvV4HSZqTK3LYzJ15BD
def E0PNDIAiaYkKRpx(gYJAT1vW0Uqm76G):
	slKUaoGTVYnP = llnG7jiQBYKhAeovbT.getSetting('av.iptv.url_'+gYJAT1vW0Uqm76G)
	vYqAshPKQrVDB = True
	if slKUaoGTVYnP:
		rhcetwI14l = YuqCtbB0XfT6rGUwS5z79VDk3del2E('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',eMypvI8XqHjYU02anWD9gsSrkt+slKUaoGTVYnP+c7gxFyUCGm+'\n\n هذا هو رابط ـIPTV المسجل في البرنامج ... هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if rhcetwI14l==-1: return
		elif rhcetwI14l==0: slKUaoGTVYnP = nbOFVEDkpT4BIR7Qq82yPmHeJU
		elif rhcetwI14l==2:
			rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if rhcetwI14l in [-1,0]: return
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح الرابط')
			vYqAshPKQrVDB = False
			BlMVpQzksqZSg = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if vYqAshPKQrVDB:
		BlMVpQzksqZSg = dR75Vq2gprfHmUcNhG('اكتب رابط ـIPTV كاملا',slKUaoGTVYnP)
		BlMVpQzksqZSg = BlMVpQzksqZSg.strip(S3X6GcaiExOPtb)
		if not BlMVpQzksqZSg:
			rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if rhcetwI14l in [-1,0]: return
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح الرابط')
	else:
		fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G,BlMVpQzksqZSg)
		if not BarI1m9u06gVdhyCjGYWXbUv: return
		CtO9cFuULSm62PWToMlzN1 = 'هذه المعلومات تم أخذها من رابط ـIPTV الذي انت كتبته . هل تريد استخدامها ؟!\n'
		CtO9cFuULSm62PWToMlzN1 += wwOnIucWJj+l5JG7XwbOfo8DznU+o0TYhleWOM+c7gxFyUCGm+'عنوان السيرفر: '
		CtO9cFuULSm62PWToMlzN1 += wwOnIucWJj+l5JG7XwbOfo8DznU+BarI1m9u06gVdhyCjGYWXbUv+c7gxFyUCGm+'اسم المستخدم: '
		CtO9cFuULSm62PWToMlzN1 += wwOnIucWJj+l5JG7XwbOfo8DznU+UrhaCqx2ptm3RLBcKk41JlzPgN++'كلمة السر: '
		rhcetwI14l = ttiZs4bKHFvugJj5z('right',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'الرابط الجديد هو:',eMypvI8XqHjYU02anWD9gsSrkt+BlMVpQzksqZSg+c7gxFyUCGm+'\n\n'+CtO9cFuULSm62PWToMlzN1)
		if rhcetwI14l!=1:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإلغاء')
			return
	llnG7jiQBYKhAeovbT.setSetting('av.iptv.url_'+gYJAT1vW0Uqm76G,BlMVpQzksqZSg)
	llnG7jiQBYKhAeovbT.setSetting('av.iptv.timestamp_'+gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	llnG7jiQBYKhAeovbT.setSetting('av.iptv.timediff_'+gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.iptv.useragent_'+gYJAT1vW0Uqm76G)
	if not ltDKzevu94swOC0YqBPMR76: llnG7jiQBYKhAeovbT.setSetting('av.iptv.useragent_'+gYJAT1vW0Uqm76G,'Unknown')
	cT6ZLwh20d5e = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,BlMVpQzksqZSg+'\n\nتم تغير رابط اشتراك ـIPTV إلى هذا الرابط الجديد ... هل تريد فحص هذا الرابط الآن ؟')
	if cT6ZLwh20d5e==1: aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,True)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def H3HmDXTyWzoMi1gk(rrfWsKPq4nzR0V7jFoNBHQe,EQ6L70JxAk,jWK8ehlA0gJQqSrp1ZBndN3DwI,TSPhMOnV81Y7J0QC4Xd,lloWqNHwL5SjQcCI8ePFyB,f3phHmTd9wsvxGjD7SbJkIiRFB,PEQBv9wdpSXqYRjK6I):
	AABDgbaTdl5ShcJWKGCeP1st0N7Ip,YBxbVzcRSI8 = [],[]
	x6whricml7NXBujdVETZ2H = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		if f3phHmTd9wsvxGjD7SbJkIiRFB%473==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,40+int(10*f3phHmTd9wsvxGjD7SbJkIiRFB/lloWqNHwL5SjQcCI8ePFyB),'قراءة الفيديوهات','الفيديو رقم:-',str(f3phHmTd9wsvxGjD7SbJkIiRFB)+' / '+str(lloWqNHwL5SjQcCI8ePFyB))
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return None,None,None
		wNyZhHdvUeC3M = ScntgdOZCY74vNpXeW5jh8i.findall('^(.*?)\n+((http|https|rtmp).*?)$',k38Vi6PpwFNB7Aus1KErSLJaOdDvM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if wNyZhHdvUeC3M:
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM,wNyZhHdvUeC3M,RQg7AUDOp6MJtWwdba3VFYZ1XHokE = wNyZhHdvUeC3M[0]
			wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else:
			YBxbVzcRSI8.append({'line':k38Vi6PpwFNB7Aus1KErSLJaOdDvM})
			continue
		ttm1ZRWeuMF4icE,R0gbu46Cw9ZKhB5jsT8HAcGv,q4qfsInUtRDYlXdvTMe02xPNC,GdbFDygsZ6HopImiSTY53,iiyAEbQ5f80,bb6JVCAYrB1FR = {},nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,False
		try:
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM,GdbFDygsZ6HopImiSTY53 = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.rsplit('",',1)
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM = k38Vi6PpwFNB7Aus1KErSLJaOdDvM+'"'
		except:
			try: k38Vi6PpwFNB7Aus1KErSLJaOdDvM,GdbFDygsZ6HopImiSTY53 = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.rsplit('1,',1)
			except: GdbFDygsZ6HopImiSTY53 = nbOFVEDkpT4BIR7Qq82yPmHeJU
		ttm1ZRWeuMF4icE['url'] = wNyZhHdvUeC3M
		csoJfz47HYjmwT = ScntgdOZCY74vNpXeW5jh8i.findall(' (.*?)="(.*?)"',k38Vi6PpwFNB7Aus1KErSLJaOdDvM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for dvhs8lngSEQTyr4a7YwjkFVcWope,ggMUCPqpYinc in csoJfz47HYjmwT:
			dvhs8lngSEQTyr4a7YwjkFVcWope = dvhs8lngSEQTyr4a7YwjkFVcWope.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			ttm1ZRWeuMF4icE[dvhs8lngSEQTyr4a7YwjkFVcWope] = ggMUCPqpYinc.strip(S3X6GcaiExOPtb)
		nH6pKdQl7eZFzW8mghOPVv5 = list(ttm1ZRWeuMF4icE.keys())
		if not GdbFDygsZ6HopImiSTY53:
			if 'name' in nH6pKdQl7eZFzW8mghOPVv5 and ttm1ZRWeuMF4icE['name']: GdbFDygsZ6HopImiSTY53 = ttm1ZRWeuMF4icE['name']
		ttm1ZRWeuMF4icE['title'] = GdbFDygsZ6HopImiSTY53.strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		if 'logo' in nH6pKdQl7eZFzW8mghOPVv5:
			ttm1ZRWeuMF4icE['img'] = ttm1ZRWeuMF4icE['logo']
			del ttm1ZRWeuMF4icE['logo']
		else: ttm1ZRWeuMF4icE['img'] = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if 'group' in nH6pKdQl7eZFzW8mghOPVv5 and ttm1ZRWeuMF4icE['group']: q4qfsInUtRDYlXdvTMe02xPNC = ttm1ZRWeuMF4icE['group']
		if any(XPL0O2VkI3w1C8enMaqi in wNyZhHdvUeC3M.lower() for XPL0O2VkI3w1C8enMaqi in x6whricml7NXBujdVETZ2H):
			bb6JVCAYrB1FR = True if 'm3u' not in wNyZhHdvUeC3M else False
		if bb6JVCAYrB1FR or '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC or '__MOVIES__' in q4qfsInUtRDYlXdvTMe02xPNC:
			iiyAEbQ5f80 = 'VOD'
			if '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: iiyAEbQ5f80 = iiyAEbQ5f80+'_SERIES'
			elif '__MOVIES__' in q4qfsInUtRDYlXdvTMe02xPNC: iiyAEbQ5f80 = iiyAEbQ5f80+'_MOVIES'
			else: iiyAEbQ5f80 = iiyAEbQ5f80+'_UNKNOWN'
			q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.replace('__SERIES__',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('__MOVIES__',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else:
			iiyAEbQ5f80 = 'LIVE'
			if GdbFDygsZ6HopImiSTY53 in EQ6L70JxAk: R0gbu46Cw9ZKhB5jsT8HAcGv = R0gbu46Cw9ZKhB5jsT8HAcGv+'_EPG'
			if GdbFDygsZ6HopImiSTY53 in jWK8ehlA0gJQqSrp1ZBndN3DwI: R0gbu46Cw9ZKhB5jsT8HAcGv = R0gbu46Cw9ZKhB5jsT8HAcGv+'_ARCHIVED'
			if not q4qfsInUtRDYlXdvTMe02xPNC: iiyAEbQ5f80 = iiyAEbQ5f80+'_UNKNOWN'
			else: iiyAEbQ5f80 = iiyAEbQ5f80+R0gbu46Cw9ZKhB5jsT8HAcGv
		q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		if 'LIVE_UNKNOWN' in iiyAEbQ5f80: q4qfsInUtRDYlXdvTMe02xPNC = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in iiyAEbQ5f80: q4qfsInUtRDYlXdvTMe02xPNC = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in iiyAEbQ5f80:
			OZ1h4rAMcaPeuIKWgL6DU = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) [Ss]\d+ +[Ee]\d+',ttm1ZRWeuMF4icE['title'],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if OZ1h4rAMcaPeuIKWgL6DU: OZ1h4rAMcaPeuIKWgL6DU = OZ1h4rAMcaPeuIKWgL6DU[0]
			else: OZ1h4rAMcaPeuIKWgL6DU = '!!__UNKNOWN_SERIES__!!'
			q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC+'__SERIES__'+OZ1h4rAMcaPeuIKWgL6DU
		if 'id' in nH6pKdQl7eZFzW8mghOPVv5: del ttm1ZRWeuMF4icE['id']
		if 'ID' in nH6pKdQl7eZFzW8mghOPVv5: del ttm1ZRWeuMF4icE['ID']
		if 'name' in nH6pKdQl7eZFzW8mghOPVv5: del ttm1ZRWeuMF4icE['name']
		GdbFDygsZ6HopImiSTY53 = ttm1ZRWeuMF4icE['title']
		GdbFDygsZ6HopImiSTY53 = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(GdbFDygsZ6HopImiSTY53)
		GdbFDygsZ6HopImiSTY53 = qRWV6CJBFbYOhDZt(GdbFDygsZ6HopImiSTY53)
		iRyWwxdCcsUL0D31OH,q4qfsInUtRDYlXdvTMe02xPNC = dcRe6Ag30VTIZ9SW5Nm(q4qfsInUtRDYlXdvTMe02xPNC)
		gjwb3coX1MxOqhNIalmYzu,GdbFDygsZ6HopImiSTY53 = dcRe6Ag30VTIZ9SW5Nm(GdbFDygsZ6HopImiSTY53)
		ttm1ZRWeuMF4icE['type'] = iiyAEbQ5f80
		ttm1ZRWeuMF4icE['context'] = R0gbu46Cw9ZKhB5jsT8HAcGv
		ttm1ZRWeuMF4icE['group'] = q4qfsInUtRDYlXdvTMe02xPNC.upper()
		ttm1ZRWeuMF4icE['title'] = GdbFDygsZ6HopImiSTY53.upper()
		ttm1ZRWeuMF4icE['country'] = gjwb3coX1MxOqhNIalmYzu.upper()
		ttm1ZRWeuMF4icE['language'] = iRyWwxdCcsUL0D31OH.upper()
		AABDgbaTdl5ShcJWKGCeP1st0N7Ip.append(ttm1ZRWeuMF4icE)
		f3phHmTd9wsvxGjD7SbJkIiRFB += 1
	return AABDgbaTdl5ShcJWKGCeP1st0N7Ip,f3phHmTd9wsvxGjD7SbJkIiRFB,YBxbVzcRSI8
def qRWV6CJBFbYOhDZt(GdbFDygsZ6HopImiSTY53):
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('||','|').replace('___',':').replace('--','-')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('[[','[').replace(']]',']')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('((','(').replace('))',')')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('<<','<').replace('>>','>')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.strip(S3X6GcaiExOPtb)
	return GdbFDygsZ6HopImiSTY53
def Uzwpo7NtJxq2IrA(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,TSPhMOnV81Y7J0QC4Xd):
	GGzFWiTteIQranCwU03pHqgmLukMh9 = {}
	for jiDqcXSOhBL in GUf84z2bdKlc7PpywoNrDVg: GGzFWiTteIQranCwU03pHqgmLukMh9[jiDqcXSOhBL] = []
	lloWqNHwL5SjQcCI8ePFyB = len(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s)
	psbxE5gjQHIiOV7Bm = str(lloWqNHwL5SjQcCI8ePFyB)
	f3phHmTd9wsvxGjD7SbJkIiRFB = 0
	YBxbVzcRSI8 = []
	for ttm1ZRWeuMF4icE in zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s:
		if f3phHmTd9wsvxGjD7SbJkIiRFB%873==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,50+int(5*f3phHmTd9wsvxGjD7SbJkIiRFB/lloWqNHwL5SjQcCI8ePFyB),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(f3phHmTd9wsvxGjD7SbJkIiRFB)+' / '+psbxE5gjQHIiOV7Bm)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return None,None
		q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD = ttm1ZRWeuMF4icE['group'],ttm1ZRWeuMF4icE['context'],ttm1ZRWeuMF4icE['title'],ttm1ZRWeuMF4icE['url'],ttm1ZRWeuMF4icE['img']
		gjwb3coX1MxOqhNIalmYzu,iRyWwxdCcsUL0D31OH,jiDqcXSOhBL = ttm1ZRWeuMF4icE['country'],ttm1ZRWeuMF4icE['language'],ttm1ZRWeuMF4icE['type']
		Eyltg9NqSwCT = (q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		PNXRkvwjtuo19iW3IxYzBJ = False
		if 'LIVE' in jiDqcXSOhBL:
			if 'UNKNOWN' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_UNKNOWN_GROUPED'].append(Eyltg9NqSwCT)
			elif 'LIVE' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_GROUPED'].append(Eyltg9NqSwCT)
			else: PNXRkvwjtuo19iW3IxYzBJ = True
			GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_ORIGINAL_GROUPED'].append(Eyltg9NqSwCT)
		elif 'VOD' in jiDqcXSOhBL:
			if 'UNKNOWN' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_UNKNOWN_GROUPED'].append(Eyltg9NqSwCT)
			elif 'MOVIES' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_MOVIES_GROUPED'].append(Eyltg9NqSwCT)
			elif 'SERIES' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_SERIES_GROUPED'].append(Eyltg9NqSwCT)
			else: PNXRkvwjtuo19iW3IxYzBJ = True
			GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_ORIGINAL_GROUPED'].append(Eyltg9NqSwCT)
		else: PNXRkvwjtuo19iW3IxYzBJ = True
		if PNXRkvwjtuo19iW3IxYzBJ: YBxbVzcRSI8.append(ttm1ZRWeuMF4icE)
		f3phHmTd9wsvxGjD7SbJkIiRFB += 1
	OKJk3Z7ubTAioR2reaMyPCQt = sorted(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope['title'].lower())
	del zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s
	psbxE5gjQHIiOV7Bm = str(lloWqNHwL5SjQcCI8ePFyB)
	f3phHmTd9wsvxGjD7SbJkIiRFB = 0
	for ttm1ZRWeuMF4icE in OKJk3Z7ubTAioR2reaMyPCQt:
		f3phHmTd9wsvxGjD7SbJkIiRFB += 1
		if f3phHmTd9wsvxGjD7SbJkIiRFB%873==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,55+int(5*f3phHmTd9wsvxGjD7SbJkIiRFB/lloWqNHwL5SjQcCI8ePFyB),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(f3phHmTd9wsvxGjD7SbJkIiRFB)+' / '+psbxE5gjQHIiOV7Bm)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return None,None
		jiDqcXSOhBL = ttm1ZRWeuMF4icE['type']
		q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD = ttm1ZRWeuMF4icE['group'],ttm1ZRWeuMF4icE['context'],ttm1ZRWeuMF4icE['title'],ttm1ZRWeuMF4icE['url'],ttm1ZRWeuMF4icE['img']
		gjwb3coX1MxOqhNIalmYzu,iRyWwxdCcsUL0D31OH = ttm1ZRWeuMF4icE['country'],ttm1ZRWeuMF4icE['language']
		nv6HSBaWR2TIcufe3hXbw = (q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv+'_TIMESHIFT',GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		Eyltg9NqSwCT = (q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		M7l2mTHyfhVF1gcDYrWOt = (gjwb3coX1MxOqhNIalmYzu,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		M1MGfVbmzuEWI5Zwv4J2kyxcQ8qYd = (iRyWwxdCcsUL0D31OH,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		if 'LIVE' in jiDqcXSOhBL:
			if 'UNKNOWN' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_UNKNOWN_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			else: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			if 'EPG'		in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_EPG_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			if 'ARCHIVED'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_ARCHIVED_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			if 'ARCHIVED'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_TIMESHIFT_GROUPED_SORTED'].append(nv6HSBaWR2TIcufe3hXbw)
			GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_FROM_NAME_SORTED'].append(M7l2mTHyfhVF1gcDYrWOt)
			GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_FROM_GROUP_SORTED'].append(M1MGfVbmzuEWI5Zwv4J2kyxcQ8qYd)
		elif 'VOD' in jiDqcXSOhBL:
			if   'UNKNOWN'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_UNKNOWN_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			elif 'MOVIES'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_MOVIES_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			elif 'SERIES'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_SERIES_GROUPED_SORTED'].append(Eyltg9NqSwCT)
			GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_FROM_NAME_SORTED'].append(M7l2mTHyfhVF1gcDYrWOt)
			GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_FROM_GROUP_SORTED'].append(M1MGfVbmzuEWI5Zwv4J2kyxcQ8qYd)
	return GGzFWiTteIQranCwU03pHqgmLukMh9,YBxbVzcRSI8
def dcRe6Ag30VTIZ9SW5Nm(GdbFDygsZ6HopImiSTY53):
	if len(GdbFDygsZ6HopImiSTY53)<3: return GdbFDygsZ6HopImiSTY53,GdbFDygsZ6HopImiSTY53
	oGhrR2kuUM5PIEgbyxHLaAqVecOZ,vvEo6gUjRliKq = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	DDBgLAUmNnJtuijT652 = GdbFDygsZ6HopImiSTY53
	D71DvSYLd3wNUGReB2EmZqPktulz = GdbFDygsZ6HopImiSTY53[:1]
	UijQyX2xbMqr4Gdf3ZaS5IwEB0mv6 = GdbFDygsZ6HopImiSTY53[1:]
	if   D71DvSYLd3wNUGReB2EmZqPktulz=='(': vvEo6gUjRliKq = ')'
	elif D71DvSYLd3wNUGReB2EmZqPktulz=='[': vvEo6gUjRliKq = ']'
	elif D71DvSYLd3wNUGReB2EmZqPktulz=='<': vvEo6gUjRliKq = '>'
	elif D71DvSYLd3wNUGReB2EmZqPktulz=='|': vvEo6gUjRliKq = '|'
	if vvEo6gUjRliKq and (vvEo6gUjRliKq in UijQyX2xbMqr4Gdf3ZaS5IwEB0mv6):
		HpuKsJNxB0SDqRzgdCakPZ,VydXkKzn3qoTt9YAuSRc4ajMEW0 = UijQyX2xbMqr4Gdf3ZaS5IwEB0mv6.split(vvEo6gUjRliKq,1)
		oGhrR2kuUM5PIEgbyxHLaAqVecOZ = HpuKsJNxB0SDqRzgdCakPZ
		DDBgLAUmNnJtuijT652 = D71DvSYLd3wNUGReB2EmZqPktulz+HpuKsJNxB0SDqRzgdCakPZ+vvEo6gUjRliKq+S3X6GcaiExOPtb+VydXkKzn3qoTt9YAuSRc4ajMEW0
	elif GdbFDygsZ6HopImiSTY53.count('|')>=2:
		HpuKsJNxB0SDqRzgdCakPZ,VydXkKzn3qoTt9YAuSRc4ajMEW0 = GdbFDygsZ6HopImiSTY53.split('|',1)
		oGhrR2kuUM5PIEgbyxHLaAqVecOZ = HpuKsJNxB0SDqRzgdCakPZ
		DDBgLAUmNnJtuijT652 = HpuKsJNxB0SDqRzgdCakPZ+' |'+VydXkKzn3qoTt9YAuSRc4ajMEW0
	else:
		vvEo6gUjRliKq = ScntgdOZCY74vNpXeW5jh8i.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not vvEo6gUjRliKq: vvEo6gUjRliKq = ScntgdOZCY74vNpXeW5jh8i.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not vvEo6gUjRliKq: vvEo6gUjRliKq = ScntgdOZCY74vNpXeW5jh8i.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if vvEo6gUjRliKq:
			HpuKsJNxB0SDqRzgdCakPZ,VydXkKzn3qoTt9YAuSRc4ajMEW0 = GdbFDygsZ6HopImiSTY53.split(vvEo6gUjRliKq[0],1)
			oGhrR2kuUM5PIEgbyxHLaAqVecOZ = HpuKsJNxB0SDqRzgdCakPZ
			DDBgLAUmNnJtuijT652 = HpuKsJNxB0SDqRzgdCakPZ+S3X6GcaiExOPtb+vvEo6gUjRliKq[0]+S3X6GcaiExOPtb+VydXkKzn3qoTt9YAuSRc4ajMEW0
	DDBgLAUmNnJtuijT652 = DDBgLAUmNnJtuijT652.replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	oGhrR2kuUM5PIEgbyxHLaAqVecOZ = oGhrR2kuUM5PIEgbyxHLaAqVecOZ.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	if not oGhrR2kuUM5PIEgbyxHLaAqVecOZ: oGhrR2kuUM5PIEgbyxHLaAqVecOZ = '!!__UNKNOWN__!!'
	oGhrR2kuUM5PIEgbyxHLaAqVecOZ = oGhrR2kuUM5PIEgbyxHLaAqVecOZ.strip(S3X6GcaiExOPtb)
	DDBgLAUmNnJtuijT652 = DDBgLAUmNnJtuijT652.strip(S3X6GcaiExOPtb)
	return oGhrR2kuUM5PIEgbyxHLaAqVecOZ,DDBgLAUmNnJtuijT652
def Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G):
	YeRr5GFOCqn9ufVy = {}
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.iptv.useragent_'+gYJAT1vW0Uqm76G)
	if ltDKzevu94swOC0YqBPMR76: YeRr5GFOCqn9ufVy['User-Agent'] = ltDKzevu94swOC0YqBPMR76
	kYFoe7P0tzCaZ = llnG7jiQBYKhAeovbT.getSetting('av.iptv.referer_'+gYJAT1vW0Uqm76G)
	if kYFoe7P0tzCaZ: YeRr5GFOCqn9ufVy['Referer'] = kYFoe7P0tzCaZ
	return YeRr5GFOCqn9ufVy
def V8YhRNmegG(gYJAT1vW0Uqm76G):
	global TSPhMOnV81Y7J0QC4Xd,GGzFWiTteIQranCwU03pHqgmLukMh9,QQFPbVlYHgoq01jB4AR,mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs,wNG8sMaEZkFdDvYLTbnmP
	fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G)
	if not BarI1m9u06gVdhyCjGYWXbUv: return
	YeRr5GFOCqn9ufVy = Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G)
	JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','جلب ملفات ـIPTV جديدة قد تحتاج عدة دقائق . هل تريد أن تجلب الملفات الآن ؟')
	if JvOL5Wr9s6!=1: return
	fvV4HSZqTK3LYzJ15BD = xxMHi17GvS2mdltQNozjIn8RgVBr.replace('___','_'+gYJAT1vW0Uqm76G)
	if 1:
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,False)
		if not aBStCuH2RG4fOZJp19XAbKkI5xe7Nv:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','فشل بسحب ملفات ـIPTV . أحتمال رابط ـIPTV غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـIPTV الموجودة بهذا البرنامج')
			if not PEQBv9wdpSXqYRjK6I: fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(VGjzYJZykfEWxlQLeap)+'   No IPTV URL found to download IPTV files')
			else: fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(VGjzYJZykfEWxlQLeap)+'   Failed to download IPTV files')
			return
		D1sJBj274KYWL = OZq0bRFsaGe98NJxmW6tPiv(PEQBv9wdpSXqYRjK6I,YeRr5GFOCqn9ufVy,True)
		if not D1sJBj274KYWL: return
		open(fvV4HSZqTK3LYzJ15BD,'wb').write(D1sJBj274KYWL)
	else: D1sJBj274KYWL = open(fvV4HSZqTK3LYzJ15BD,'rb').read()
	if IZhXMprxvAHqBEFkg0 and D1sJBj274KYWL: D1sJBj274KYWL = D1sJBj274KYWL.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	TSPhMOnV81Y7J0QC4Xd = LMSZwD0IRAziTh()
	TSPhMOnV81Y7J0QC4Xd.create('جلب ملفات ـIPTV جديدة',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,15,'تنظيف الملف الرئيسي',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	D1sJBj274KYWL = D1sJBj274KYWL.replace('"tvg-','" tvg-')
	D1sJBj274KYWL = D1sJBj274KYWL.replace('َ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ً',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ُ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٌ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	D1sJBj274KYWL = D1sJBj274KYWL.replace('ّ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ِ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٍ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ْ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	D1sJBj274KYWL = D1sJBj274KYWL.replace('group-title=','group=').replace('tvg-',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	jWK8ehlA0gJQqSrp1ZBndN3DwI,EQ6L70JxAk = [],[]
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,20,'جلب الملفات الثانوية','الملف رقم:-','1 / 3')
	if TSPhMOnV81Y7J0QC4Xd.iscanceled():
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_series_categories'
	BTxl2eLIqSzUk = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',wNyZhHdvUeC3M,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IPTV-CREATE_STREAMS-1st')
	oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
	oHQzKutsWeALwSEXc8a = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(oHQzKutsWeALwSEXc8a)
	uGxXfFvcAtrC07oV8 = ScntgdOZCY74vNpXeW5jh8i.findall('category_name":"(.*?)"',oHQzKutsWeALwSEXc8a,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	del oHQzKutsWeALwSEXc8a
	for q4qfsInUtRDYlXdvTMe02xPNC in uGxXfFvcAtrC07oV8:
		q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.replace('\/','/')
		if n7neb9KTv10FcU: q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode(zSafwK0sDXdMN5JReniIQmrZxp)
		D1sJBj274KYWL = D1sJBj274KYWL.replace('group="'+q4qfsInUtRDYlXdvTMe02xPNC+'"','group="__SERIES__'+q4qfsInUtRDYlXdvTMe02xPNC+'"')
	del uGxXfFvcAtrC07oV8
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,25,'جلب الملفات الثانوية','الملف رقم:-','2 / 3')
	if TSPhMOnV81Y7J0QC4Xd.iscanceled():
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_vod_categories'
	BTxl2eLIqSzUk = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',wNyZhHdvUeC3M,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IPTV-CREATE_STREAMS-2nd')
	oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
	oHQzKutsWeALwSEXc8a = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(oHQzKutsWeALwSEXc8a)
	ookHNryag3wRCBW9KT8FuOqdbSi2 = ScntgdOZCY74vNpXeW5jh8i.findall('category_name":"(.*?)"',oHQzKutsWeALwSEXc8a,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	del oHQzKutsWeALwSEXc8a
	for q4qfsInUtRDYlXdvTMe02xPNC in ookHNryag3wRCBW9KT8FuOqdbSi2:
		q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.replace('\/','/')
		if n7neb9KTv10FcU: q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode(zSafwK0sDXdMN5JReniIQmrZxp)
		D1sJBj274KYWL = D1sJBj274KYWL.replace('group="'+q4qfsInUtRDYlXdvTMe02xPNC+'"','group="__MOVIES__'+q4qfsInUtRDYlXdvTMe02xPNC+'"')
	del ookHNryag3wRCBW9KT8FuOqdbSi2
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,30,'جلب الملفات الثانوية','الملف رقم:-','3 / 3')
	if TSPhMOnV81Y7J0QC4Xd.iscanceled():
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_live_streams'
	BTxl2eLIqSzUk = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',wNyZhHdvUeC3M,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IPTV-CREATE_STREAMS-3rd')
	oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
	oHQzKutsWeALwSEXc8a = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(oHQzKutsWeALwSEXc8a)
	wvVCq1SJPraHMK2k9ZQnxB = ScntgdOZCY74vNpXeW5jh8i.findall('"name":"(.*?)".*?"tv_archive":(.*?),',oHQzKutsWeALwSEXc8a,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for xbfwC5hkXLvsJa8PReOS9AyU1z,oUE3zsBHjhQNDRf5Gar in wvVCq1SJPraHMK2k9ZQnxB:
		if oUE3zsBHjhQNDRf5Gar=='1': jWK8ehlA0gJQqSrp1ZBndN3DwI.append(xbfwC5hkXLvsJa8PReOS9AyU1z)
	del wvVCq1SJPraHMK2k9ZQnxB
	CP36uovZlr2kRQhXx1WL7say49 = ScntgdOZCY74vNpXeW5jh8i.findall('"name":"(.*?)".*?"epg_channel_id":(.*?),',oHQzKutsWeALwSEXc8a,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	del oHQzKutsWeALwSEXc8a
	for xbfwC5hkXLvsJa8PReOS9AyU1z,ZczqHrI1M6tL4KmdaTOi8bQ in CP36uovZlr2kRQhXx1WL7say49:
		if ZczqHrI1M6tL4KmdaTOi8bQ!='null': EQ6L70JxAk.append(xbfwC5hkXLvsJa8PReOS9AyU1z)
	del CP36uovZlr2kRQhXx1WL7say49
	D1sJBj274KYWL = D1sJBj274KYWL.replace(FKuOXLZA8PYBc7,wwOnIucWJj)
	rrfWsKPq4nzR0V7jFoNBHQe = ScntgdOZCY74vNpXeW5jh8i.findall('NF:(.+?)'+'#'+'EXTI',D1sJBj274KYWL+'\n+'+'#'+'EXTINF:',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not rrfWsKPq4nzR0V7jFoNBHQe:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(VGjzYJZykfEWxlQLeap)+'   Folder:'+gYJAT1vW0Uqm76G+'   No video links found in IPTV file')
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','رابط ـIPTV الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـIPTV غير صحيح'+wwOnIucWJj+l5JG7XwbOfo8DznU+'مجلد رقم '+gYJAT1vW0Uqm76G)
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	d1daHcStye3mbCMl = []
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		GsAZKprYCPdRMTOkEQgi53oWuFL = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.lower()
		if 'adult' in GsAZKprYCPdRMTOkEQgi53oWuFL: continue
		if 'xxx' in GsAZKprYCPdRMTOkEQgi53oWuFL: continue
		d1daHcStye3mbCMl.append(k38Vi6PpwFNB7Aus1KErSLJaOdDvM)
	rrfWsKPq4nzR0V7jFoNBHQe = d1daHcStye3mbCMl
	del d1daHcStye3mbCMl
	COkrtZg31VXpJNuschG8Y = 1024*1024
	ZZzsWx8leaiqKH5Pn7FQG2CT = 1+len(D1sJBj274KYWL)//COkrtZg31VXpJNuschG8Y//10
	del D1sJBj274KYWL
	CCLaKyTxzWtjMYEuNqn = len(rrfWsKPq4nzR0V7jFoNBHQe)
	ccLAbE39mBj2DInki8yU1TJhMR = LuHJknFyP3VhQNGfr1iwYg5v0X(rrfWsKPq4nzR0V7jFoNBHQe,ZZzsWx8leaiqKH5Pn7FQG2CT)
	del rrfWsKPq4nzR0V7jFoNBHQe
	for uvOaDl7f60HCwBiVKzes24 in range(ZZzsWx8leaiqKH5Pn7FQG2CT):
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,35+int(5*uvOaDl7f60HCwBiVKzes24/ZZzsWx8leaiqKH5Pn7FQG2CT),'تقطيع الملف الرئيسي','الجزء رقم:-',str(uvOaDl7f60HCwBiVKzes24+1)+' / '+str(ZZzsWx8leaiqKH5Pn7FQG2CT))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		w1YKkBmWtLRVGobu6v7S4x = str(ccLAbE39mBj2DInki8yU1TJhMR[uvOaDl7f60HCwBiVKzes24])
		if IZhXMprxvAHqBEFkg0: w1YKkBmWtLRVGobu6v7S4x = w1YKkBmWtLRVGobu6v7S4x.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open(fvV4HSZqTK3LYzJ15BD+'.00'+str(uvOaDl7f60HCwBiVKzes24),'wb').write(w1YKkBmWtLRVGobu6v7S4x)
	del ccLAbE39mBj2DInki8yU1TJhMR,w1YKkBmWtLRVGobu6v7S4x
	KQzZbvohDksR4Cg,zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,f3phHmTd9wsvxGjD7SbJkIiRFB = [],[],0
	for uvOaDl7f60HCwBiVKzes24 in range(ZZzsWx8leaiqKH5Pn7FQG2CT):
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		w1YKkBmWtLRVGobu6v7S4x = open(fvV4HSZqTK3LYzJ15BD+'.00'+str(uvOaDl7f60HCwBiVKzes24),'rb').read()
		lQMuw1PvVpAk.sleep(1)
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(fvV4HSZqTK3LYzJ15BD+'.00'+str(uvOaDl7f60HCwBiVKzes24))
		except: pass
		if IZhXMprxvAHqBEFkg0: w1YKkBmWtLRVGobu6v7S4x = w1YKkBmWtLRVGobu6v7S4x.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		d0OahBfrtQA42Upqyx9NbELYsKZTg = dr1zfnatJxRHSF48jh0eODm5bGu('list',w1YKkBmWtLRVGobu6v7S4x)
		del w1YKkBmWtLRVGobu6v7S4x
		AABDgbaTdl5ShcJWKGCeP1st0N7Ip,f3phHmTd9wsvxGjD7SbJkIiRFB,YBxbVzcRSI8 = H3HmDXTyWzoMi1gk(d0OahBfrtQA42Upqyx9NbELYsKZTg,EQ6L70JxAk,jWK8ehlA0gJQqSrp1ZBndN3DwI,TSPhMOnV81Y7J0QC4Xd,CCLaKyTxzWtjMYEuNqn,f3phHmTd9wsvxGjD7SbJkIiRFB,PEQBv9wdpSXqYRjK6I)
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		if not AABDgbaTdl5ShcJWKGCeP1st0N7Ip:
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s += AABDgbaTdl5ShcJWKGCeP1st0N7Ip
		KQzZbvohDksR4Cg += YBxbVzcRSI8
	del d0OahBfrtQA42Upqyx9NbELYsKZTg,AABDgbaTdl5ShcJWKGCeP1st0N7Ip
	GGzFWiTteIQranCwU03pHqgmLukMh9,YBxbVzcRSI8 = Uzwpo7NtJxq2IrA(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,TSPhMOnV81Y7J0QC4Xd)
	if TSPhMOnV81Y7J0QC4Xd.iscanceled():
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	KQzZbvohDksR4Cg += YBxbVzcRSI8
	del zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,YBxbVzcRSI8
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs = {},{},{},0,0
	KyZX2T4iaj = list(GGzFWiTteIQranCwU03pHqgmLukMh9.keys())
	wNG8sMaEZkFdDvYLTbnmP = len(KyZX2T4iaj)*3
	if 1:
		EERBxagV8muspkbzSvi = {}
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc] = eb6R0h1Fjl.Thread(target=ODxdYocVLi8Npl1vmEC0stnF,args=(GIplj3KhV8dc,))
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].start()
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].join()
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
	else:
		for GIplj3KhV8dc in KyZX2T4iaj:
			ODxdYocVLi8Npl1vmEC0stnF(GIplj3KhV8dc)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return
	jjIfEhLyl2wu9UGrcFe(gYJAT1vW0Uqm76G,False)
	KyZX2T4iaj = list(mpLu72Ngo05iSZe9B8MfdyHIRrbckY.keys())
	QQFPbVlYHgoq01jB4AR = 0
	if 1:
		EERBxagV8muspkbzSvi = {}
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc] = eb6R0h1Fjl.Thread(target=ggDeKCqEvYdGSMxOb,args=(gYJAT1vW0Uqm76G,GIplj3KhV8dc))
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].start()
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].join()
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
	else:
		for GIplj3KhV8dc in KyZX2T4iaj:
			ggDeKCqEvYdGSMxOb(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return
	uvOaDl7f60HCwBiVKzes24 = 0
	WOQgRtJDouEx0njbyacF = len(KQzZbvohDksR4Cg)
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'IGNORED')
	for ufxmkS69YGXogyvWl in KQzZbvohDksR4Cg:
		if uvOaDl7f60HCwBiVKzes24%27==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,95+int(5*uvOaDl7f60HCwBiVKzes24//WOQgRtJDouEx0njbyacF),'تخزين المهملة','الفيديو رقم:-',str(uvOaDl7f60HCwBiVKzes24)+' / '+str(WOQgRtJDouEx0njbyacF))
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'IGNORED',str(ufxmkS69YGXogyvWl),nbOFVEDkpT4BIR7Qq82yPmHeJU,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
		uvOaDl7f60HCwBiVKzes24 += 1
	z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'IGNORED','__COUNT__',str(WOQgRtJDouEx0njbyacF),p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'DUMMY','__DUMMY__','1',p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	TSPhMOnV81Y7J0QC4Xd.close()
	lQMuw1PvVpAk.sleep(1)
	aYRULC8dGNTo0eAmFcjW7 = eL6JlI0X94nyamjOAhu3U1BDgic(gYJAT1vW0Uqm76G,False)
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج',l5JG7XwbOfo8DznU+'تم جلب ملفات ـIPTV جديدة'+c7gxFyUCGm+'\n\n'+aYRULC8dGNTo0eAmFcjW7)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	kYaRIGV5T7Zvfbq3WKpmQwJiBg(False)
	ue186CEMORWhvq(False)
	return
def ODxdYocVLi8Npl1vmEC0stnF(GIplj3KhV8dc):
	global TSPhMOnV81Y7J0QC4Xd,GGzFWiTteIQranCwU03pHqgmLukMh9,QQFPbVlYHgoq01jB4AR,mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs,wNG8sMaEZkFdDvYLTbnmP
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc] = {}
	Ru3NyaKDq2YG6STV,hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = {},[]
	yoBXj8AKERtsSYIUmPrnGc37dFi = len(GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc])
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc]['__COUNT__'] = yoBXj8AKERtsSYIUmPrnGc37dFi
	if yoBXj8AKERtsSYIUmPrnGc37dFi>0:
		H0qCfYcWhi,YhJjdcN7kA0iR3rlgI261vB4bE,P3na1yCjSMk,ZKphALGOFVzoi59HJxcW,DD9NdGbpRmqCn = zip(*GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc])
		del YhJjdcN7kA0iR3rlgI261vB4bE,P3na1yCjSMk,ZKphALGOFVzoi59HJxcW
		rK7um1MVit = list(set(H0qCfYcWhi))
		for q4qfsInUtRDYlXdvTMe02xPNC in rK7um1MVit:
			Ru3NyaKDq2YG6STV[q4qfsInUtRDYlXdvTMe02xPNC] = nbOFVEDkpT4BIR7Qq82yPmHeJU
			mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc][q4qfsInUtRDYlXdvTMe02xPNC] = []
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,60+int(15*XPhNf1tAcH32oiBs//wNG8sMaEZkFdDvYLTbnmP),'تصنيع القوائم','الجزء رقم:-',str(XPhNf1tAcH32oiBs)+' / '+str(wNG8sMaEZkFdDvYLTbnmP))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
		XPhNf1tAcH32oiBs += 1
		LIH2VQTDdNK8F1e = len(rK7um1MVit)
		del rK7um1MVit
		hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = list(set(zip(H0qCfYcWhi,DD9NdGbpRmqCn)))
		del H0qCfYcWhi,DD9NdGbpRmqCn
		for q4qfsInUtRDYlXdvTMe02xPNC,gwLmtlCDM6uq0EnWoNUx in hGAZxNk0jCEVboMLmXUtpO8lDK7H1T:
			if not Ru3NyaKDq2YG6STV[q4qfsInUtRDYlXdvTMe02xPNC] and gwLmtlCDM6uq0EnWoNUx: Ru3NyaKDq2YG6STV[q4qfsInUtRDYlXdvTMe02xPNC] = gwLmtlCDM6uq0EnWoNUx
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,60+int(15*XPhNf1tAcH32oiBs//wNG8sMaEZkFdDvYLTbnmP),'تصنيع القوائم','الجزء رقم:-',str(XPhNf1tAcH32oiBs)+' / '+str(wNG8sMaEZkFdDvYLTbnmP))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
		XPhNf1tAcH32oiBs += 1
		ih7xlHqCEf0s = list(Ru3NyaKDq2YG6STV.keys())
		QSBTVJnY5pAlFdEhMiyzH4GN = list(Ru3NyaKDq2YG6STV.values())
		del Ru3NyaKDq2YG6STV
		hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = list(zip(ih7xlHqCEf0s,QSBTVJnY5pAlFdEhMiyzH4GN))
		del ih7xlHqCEf0s,QSBTVJnY5pAlFdEhMiyzH4GN
		hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = sorted(hGAZxNk0jCEVboMLmXUtpO8lDK7H1T)
	else: XPhNf1tAcH32oiBs += 2
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc]['__GROUPS__'] = hGAZxNk0jCEVboMLmXUtpO8lDK7H1T
	del hGAZxNk0jCEVboMLmXUtpO8lDK7H1T
	for q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc]:
		mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc][q4qfsInUtRDYlXdvTMe02xPNC].append((R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD))
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,60+int(15*XPhNf1tAcH32oiBs//wNG8sMaEZkFdDvYLTbnmP),'تصنيع القوائم','الجزء رقم:-',str(XPhNf1tAcH32oiBs)+' / '+str(wNG8sMaEZkFdDvYLTbnmP))
	if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
	XPhNf1tAcH32oiBs += 1
	del GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc]
	HNicWMGkpKj[GIplj3KhV8dc] = list(mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc].keys())
	STZLyQr47Wl5up[GIplj3KhV8dc] = len(HNicWMGkpKj[GIplj3KhV8dc])
	zdFt6xPkcXMG += STZLyQr47Wl5up[GIplj3KhV8dc]
	return
def ggDeKCqEvYdGSMxOb(gYJAT1vW0Uqm76G,GIplj3KhV8dc):
	global TSPhMOnV81Y7J0QC4Xd,GGzFWiTteIQranCwU03pHqgmLukMh9,QQFPbVlYHgoq01jB4AR,mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs,wNG8sMaEZkFdDvYLTbnmP
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
	for f3phHmTd9wsvxGjD7SbJkIiRFB in range(1+STZLyQr47Wl5up[GIplj3KhV8dc]//273):
		LXj7f1gKQ9GVprHevm6bZaq3NAz5 = []
		TuBmbRMoOas8PketF = HNicWMGkpKj[GIplj3KhV8dc][0:273]
		for q4qfsInUtRDYlXdvTMe02xPNC in TuBmbRMoOas8PketF:
			LXj7f1gKQ9GVprHevm6bZaq3NAz5.append(mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc][q4qfsInUtRDYlXdvTMe02xPNC])
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,GIplj3KhV8dc,TuBmbRMoOas8PketF,LXj7f1gKQ9GVprHevm6bZaq3NAz5,p2CSGfkREb6TuDtas9yFPrU1e3NWL7,True)
		QQFPbVlYHgoq01jB4AR += len(TuBmbRMoOas8PketF)
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,75+int(20*QQFPbVlYHgoq01jB4AR//zdFt6xPkcXMG),'تخزين القوائم','القائمة رقم:-',str(QQFPbVlYHgoq01jB4AR)+' / '+str(zdFt6xPkcXMG))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
		del HNicWMGkpKj[GIplj3KhV8dc][0:273]
	del mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc],HNicWMGkpKj[GIplj3KhV8dc],STZLyQr47Wl5up[GIplj3KhV8dc]
	return
def eL6JlI0X94nyamjOAhu3U1BDgic(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	d5VIrOEM2YB0bapqyKuoULxztH = 'رسالة من المبرمج'
	R61bxdlGBQL = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'LIVE_ORIGINAL_GROUPED')
	KHD5rTSRQLMuBAchv2YW = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'VOD_ORIGINAL_GROUPED')
	WOQgRtJDouEx0njbyacF = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','IGNORED','__COUNT__')
	lyjmRYxDo52Zs7vLgIVEAt = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','LIVE_ORIGINAL_GROUPED','__COUNT__')
	vvjYEtHTpnwFM7h9aXVeq0briByK = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(KHD5rTSRQLMuBAchv2YW,'int','VOD_ORIGINAL_GROUPED','__COUNT__')
	EEFyB9Vb5QLCUexSMzD1vT3ncfX = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','LIVE_GROUPED','__COUNT__')
	rrP4w1Ing7MvxGRdDAoTe = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','LIVE_UNKNOWN_GROUPED','__COUNT__')
	uuZkPLKWR6HdIeOmxy5jF34T80pfq = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','VOD_MOVIES_GROUPED','__COUNT__')
	iwmonTO1PbYylpK7 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(KHD5rTSRQLMuBAchv2YW,'int','VOD_SERIES_GROUPED','__COUNT__')
	VpYDoAxWe2dwQh6UJHyqrBuG1vl4 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','VOD_UNKNOWN_GROUPED','__COUNT__')
	HNicWMGkpKj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(KHD5rTSRQLMuBAchv2YW,'list','VOD_SERIES_GROUPED','__GROUPS__')
	HFkBmoSulMJd8P2cIT = []
	for q4qfsInUtRDYlXdvTMe02xPNC,ayoEi7YNWD in HNicWMGkpKj:
		LPD5TGbrIfQqkl6tyKw7j = q4qfsInUtRDYlXdvTMe02xPNC.split('__SERIES__')[1]
		HFkBmoSulMJd8P2cIT.append(LPD5TGbrIfQqkl6tyKw7j)
	IzqrSWJaFAcYLC = len(HFkBmoSulMJd8P2cIT)
	WWXzI34UZEqYhf25uxJwLVo = int(uuZkPLKWR6HdIeOmxy5jF34T80pfq)+int(iwmonTO1PbYylpK7)+int(VpYDoAxWe2dwQh6UJHyqrBuG1vl4)+int(rrP4w1Ing7MvxGRdDAoTe)+int(EEFyB9Vb5QLCUexSMzD1vT3ncfX)
	aYRULC8dGNTo0eAmFcjW7 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	aYRULC8dGNTo0eAmFcjW7 += 'قنوات: '+str(EEFyB9Vb5QLCUexSMzD1vT3ncfX)
	aYRULC8dGNTo0eAmFcjW7 += '   .   أفلام: '+str(uuZkPLKWR6HdIeOmxy5jF34T80pfq)
	aYRULC8dGNTo0eAmFcjW7 += '\nمسلسلات: '+str(IzqrSWJaFAcYLC)
	aYRULC8dGNTo0eAmFcjW7 += '   .   حلقات: '+str(iwmonTO1PbYylpK7)
	aYRULC8dGNTo0eAmFcjW7 += '\nقنوات مجهولة: '+str(rrP4w1Ing7MvxGRdDAoTe)
	aYRULC8dGNTo0eAmFcjW7 += '   .   فيدوهات مجهولة: '+str(VpYDoAxWe2dwQh6UJHyqrBuG1vl4)
	aYRULC8dGNTo0eAmFcjW7 += '\nمجموع القنوات: '+str(lyjmRYxDo52Zs7vLgIVEAt)
	aYRULC8dGNTo0eAmFcjW7 += '   .   مجموع الفيديوهات: '+str(vvjYEtHTpnwFM7h9aXVeq0briByK)
	aYRULC8dGNTo0eAmFcjW7 += '\n\nمجموع المضافة: '+str(WWXzI34UZEqYhf25uxJwLVo)
	aYRULC8dGNTo0eAmFcjW7 += '   .   مجموع المهملة: '+str(WOQgRtJDouEx0njbyacF)
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep: aY7RFmnWc5uU9T3Q0Mxq4('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,d5VIrOEM2YB0bapqyKuoULxztH,aYRULC8dGNTo0eAmFcjW7)
	II7uWs8plOi9AjmCH3NR = aYRULC8dGNTo0eAmFcjW7.replace('\n\n',wwOnIucWJj)
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,'.\tCounts of IPTV videos   Folder: '+gYJAT1vW0Uqm76G+wwOnIucWJj+II7uWs8plOi9AjmCH3NR)
	return aYRULC8dGNTo0eAmFcjW7
def jjIfEhLyl2wu9UGrcFe(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'مسح ملفات ـIPTV','تستطيع في أي وقت الدخول إلى قائمة ـIPTV وجلب ملفات ـIPTV جديدة .. هل تريد الآن مسح الملفات القديمة المخزنة في البرنامج ؟!')
		if JvOL5Wr9s6!=1: return
		nTOU6Iu7oFf = xxMHi17GvS2mdltQNozjIn8RgVBr.replace('___','_'+gYJAT1vW0Uqm76G)
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(nTOU6Iu7oFf)
		except: pass
	nTOU6Iu7oFf = Eh67dFOcRbgCMl.replace('___','_'+gYJAT1vW0Uqm76G)
	try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(nTOU6Iu7oFf)
	except: pass
	nTOU6Iu7oFf = IIUtvdg9HxyNPckQCD5KZfRuF6el1.replace('___','_'+gYJAT1vW0Uqm76G)
	try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(nTOU6Iu7oFf)
	except: pass
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'SECTIONS_IPTV','SECTIONS_IPTV_'+gYJAT1vW0Uqm76G)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'SECTIONS_IPTV','SECTIONS_IPTV_ALL')
	kYaRIGV5T7Zvfbq3WKpmQwJiBg(False)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح جميع ملفات ـIPTV')
		ue186CEMORWhvq(False)
	return
def a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G=nbOFVEDkpT4BIR7Qq82yPmHeJU,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if gYJAT1vW0Uqm76G:
		nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(str(gYJAT1vW0Uqm76G),'DUMMY')
		RQg7AUDOp6MJtWwdba3VFYZ1XHokE = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'str','DUMMY','__DUMMY__')
		if RQg7AUDOp6MJtWwdba3VFYZ1XHokE: return True
	else:
		gYJAT1vW0Uqm76G = '1'
		for DnWF2omGyk4EpQP81q9uviZs in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(str(DnWF2omGyk4EpQP81q9uviZs),'DUMMY')
			RQg7AUDOp6MJtWwdba3VFYZ1XHokE = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'str','DUMMY','__DUMMY__')
			if RQg7AUDOp6MJtWwdba3VFYZ1XHokE: return True
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج اشتراك IPTV مدفوع من شركة IPTV .. ونوع الرابط المطلوب هو  m3u .. وهذا مثال لتوضيح شكل الرابط المطلوب في هذا البرنامج  '+eMypvI8XqHjYU02anWD9gsSrkt+' \n\nhttp://xyz.xyz/get.php?username=xyz&password=xyz&type=m3u_plus '+c7gxFyUCGm)
		d5VIrOEM2YB0bapqyKuoULxztH = 'إضافة وتغيير رابط '+rto0iz1Gk2xAmICHDhqR6FPnMK[1]+' (مجلد '+rto0iz1Gk2xAmICHDhqR6FPnMK[int(gYJAT1vW0Uqm76G)]+')'
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,d5VIrOEM2YB0bapqyKuoULxztH,'لإضافة رابط IPTV .. أولا أفتح قائمة IPTV .. وثانيا أنقر على إضافة رابط أو اشتراك ـIPTV .. وثالثا أنقر على جلب ملفات ـIPTV \n\n هل تريد إضافة أو تغيير رابط IPTV الآن ؟!')
		if JvOL5Wr9s6==1: E0PNDIAiaYkKRpx(gYJAT1vW0Uqm76G)
	return False
def CCLlhnQdcKiA(REapuWow7yZ4KPInfHMY0Q6rF1D9X,gYJAT1vW0Uqm76G=nbOFVEDkpT4BIR7Qq82yPmHeJU,GIplj3KhV8dc=nbOFVEDkpT4BIR7Qq82yPmHeJU,GGyLnP8egKaM9Oxr=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,Hg9iNXSxJobPBr,O3asTXHd4Jm2KCQRUwvbtE8fuDAep = hKjNwk3Bfpa48Om7JQz(REapuWow7yZ4KPInfHMY0Q6rF1D9X)
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ:
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = dR75Vq2gprfHmUcNhG()
		if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ: return
	PPlpIDTx9QgskwLEKG = [nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not GIplj3KhV8dc:
		if not O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
			if   '_IPTV-LIVE_' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[1]
			elif '_IPTV-MOVIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[2]
			elif '_IPTV-SERIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[3]
			else: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[0]
		else:
			uZCt5mQhcLIspfaDEjYSdlRUby9k = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			CH74LFlzUW3gkcxe2P = nnRXQH90qeOtABkJzGr('أختر البحث المناسب', uZCt5mQhcLIspfaDEjYSdlRUby9k)
			if CH74LFlzUW3gkcxe2P==-1: return
			GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[CH74LFlzUW3gkcxe2P]
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+'_NODIALOGS_'
	if gYJAT1vW0Uqm76G: Cndl86Apt9owz(B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,gYJAT1vW0Uqm76G,GIplj3KhV8dc,GGyLnP8egKaM9Oxr)
	else:
		for gYJAT1vW0Uqm76G in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			Cndl86Apt9owz(B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,str(gYJAT1vW0Uqm76G),GIplj3KhV8dc,GGyLnP8egKaM9Oxr)
		LvJuOzMqk6WlP971eoGpUQ8[:] = sorted(LvJuOzMqk6WlP971eoGpUQ8,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[1].lower())
	return
def Cndl86Apt9owz(REapuWow7yZ4KPInfHMY0Q6rF1D9X,gYJAT1vW0Uqm76G,GIplj3KhV8dc=nbOFVEDkpT4BIR7Qq82yPmHeJU,GGyLnP8egKaM9Oxr=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,Hg9iNXSxJobPBr,O3asTXHd4Jm2KCQRUwvbtE8fuDAep = hKjNwk3Bfpa48Om7JQz(REapuWow7yZ4KPInfHMY0Q6rF1D9X)
	if not gYJAT1vW0Uqm76G: return
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ:
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = dR75Vq2gprfHmUcNhG()
		if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ: return
	PPlpIDTx9QgskwLEKG = [nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not GIplj3KhV8dc:
		if not O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
			if   '_IPTV-LIVE_' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[1]
			elif '_IPTV-MOVIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[2]
			elif '_IPTV-SERIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[3]
			else: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[0]
		else:
			uZCt5mQhcLIspfaDEjYSdlRUby9k = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			CH74LFlzUW3gkcxe2P = nnRXQH90qeOtABkJzGr('أختر البحث المناسب', uZCt5mQhcLIspfaDEjYSdlRUby9k)
			if CH74LFlzUW3gkcxe2P==-1: return
			GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[CH74LFlzUW3gkcxe2P]
	ifhaDezHjto9nguTb1FNdk6 = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ.lower()
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'SEARCH')
	UmwA0cdOSg2s7vnKR8zYp4ohWqH = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list','SEARCH',(GIplj3KhV8dc,ifhaDezHjto9nguTb1FNdk6))
	if not UmwA0cdOSg2s7vnKR8zYp4ohWqH:
		lQ29zeOVXw,ssAvE2pguQBDtMfHLO = [],[]
		if not GIplj3KhV8dc: IAq1bUPgkdlWhYQ = [1,2,3,4,5]
		else: IAq1bUPgkdlWhYQ = [PPlpIDTx9QgskwLEKG.index(GIplj3KhV8dc)]
		for uvOaDl7f60HCwBiVKzes24 in IAq1bUPgkdlWhYQ:
			nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24])
			if uvOaDl7f60HCwBiVKzes24!=3:
				AABDgbaTdl5ShcJWKGCeP1st0N7Ip = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'dict',PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24])
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip['__COUNT__']
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip['__GROUPS__']
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip['__SEQUENCED_COLUMNS__']
				HNicWMGkpKj = list(AABDgbaTdl5ShcJWKGCeP1st0N7Ip.keys())
				for q4qfsInUtRDYlXdvTMe02xPNC in HNicWMGkpKj:
					for R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in AABDgbaTdl5ShcJWKGCeP1st0N7Ip[q4qfsInUtRDYlXdvTMe02xPNC]:
						if ifhaDezHjto9nguTb1FNdk6 in GdbFDygsZ6HopImiSTY53.lower(): ssAvE2pguQBDtMfHLO.append((GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD))
					del AABDgbaTdl5ShcJWKGCeP1st0N7Ip[q4qfsInUtRDYlXdvTMe02xPNC]
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip
			else: HNicWMGkpKj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list',PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24],'__GROUPS__')
			for q4qfsInUtRDYlXdvTMe02xPNC in HNicWMGkpKj:
				try: q4qfsInUtRDYlXdvTMe02xPNC,ayoEi7YNWD = q4qfsInUtRDYlXdvTMe02xPNC
				except: ayoEi7YNWD = nbOFVEDkpT4BIR7Qq82yPmHeJU
				if ifhaDezHjto9nguTb1FNdk6 in q4qfsInUtRDYlXdvTMe02xPNC.lower():
					if uvOaDl7f60HCwBiVKzes24!=3: gghz95uYRpMPZjB2HqnfF73 = q4qfsInUtRDYlXdvTMe02xPNC
					else:
						b2VJoUNBzi4OYdF,pPFrIbNGX8sSMTQt6HWaEwu4eqO = q4qfsInUtRDYlXdvTMe02xPNC.split('__SERIES__')
						if ifhaDezHjto9nguTb1FNdk6 in b2VJoUNBzi4OYdF.lower(): gghz95uYRpMPZjB2HqnfF73 = b2VJoUNBzi4OYdF
						else: gghz95uYRpMPZjB2HqnfF73 = pPFrIbNGX8sSMTQt6HWaEwu4eqO
					lQ29zeOVXw.append((q4qfsInUtRDYlXdvTMe02xPNC,gghz95uYRpMPZjB2HqnfF73,PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24],ayoEi7YNWD))
			del HNicWMGkpKj
		lQ29zeOVXw = set(lQ29zeOVXw)
		ssAvE2pguQBDtMfHLO = set(ssAvE2pguQBDtMfHLO)
		lQ29zeOVXw = sorted(lQ29zeOVXw,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[1])
		ssAvE2pguQBDtMfHLO = sorted(ssAvE2pguQBDtMfHLO,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[0])
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'SEARCH',(GIplj3KhV8dc,ifhaDezHjto9nguTb1FNdk6),(lQ29zeOVXw,ssAvE2pguQBDtMfHLO),p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	else: lQ29zeOVXw,ssAvE2pguQBDtMfHLO = UmwA0cdOSg2s7vnKR8zYp4ohWqH
	HNicWMGkpKj = len(lQ29zeOVXw)
	iiAzsFfwVUb5NMEpQgc = len(ssAvE2pguQBDtMfHLO)
	jwQ1lvmx6hFoet7N5OViJITA4GdZ0c = int(GGyLnP8egKaM9Oxr)
	ntXZPTIdsE = max(0,(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c-1)*100)
	UkzBlVnPmK7YZwbS9XRJ3y = max(0,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c*100)
	kcoQwFqjBKMHmy = max(0,ntXZPTIdsE-HNicWMGkpKj)
	wJIyBq3KCLaikUhu6TW18VY9tjNxfv = max(0,UkzBlVnPmK7YZwbS9XRJ3y-HNicWMGkpKj)
	for q4qfsInUtRDYlXdvTMe02xPNC,gghz95uYRpMPZjB2HqnfF73,t1tNgfOleUy5XABvxzSDmRaq7w2G,ayoEi7YNWD in lQ29zeOVXw[ntXZPTIdsE:UkzBlVnPmK7YZwbS9XRJ3y]:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+gghz95uYRpMPZjB2HqnfF73,t1tNgfOleUy5XABvxzSDmRaq7w2G,234,ayoEi7YNWD,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	del lQ29zeOVXw
	for GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in ssAvE2pguQBDtMfHLO[kcoQwFqjBKMHmy:wJIyBq3KCLaikUhu6TW18VY9tjNxfv]:
		Lbo2sDymGU8Mc0dgjnhBOvIXWNJEP = JoEms64VZ1ldaf9NYBgcKCFL(wNyZhHdvUeC3M)
		iiyAEbQ5f80 = 'live'
		if '.mkv' in Lbo2sDymGU8Mc0dgjnhBOvIXWNJEP or 'VOD' in GIplj3KhV8dc: iiyAEbQ5f80 = 'video'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,235,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	del ssAvE2pguQBDtMfHLO
	E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,239,HNicWMGkpKj+iiAzsFfwVUb5NMEpQgc,B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+'_NODIALOGS_')
	return
def E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,EYMmnJAyxV,WWXzI34UZEqYhf25uxJwLVo,J1rvN7I8eLXuS54mZ6lnUjg):
	if GGyLnP8egKaM9Oxr!='1': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'صفحة '+str(1),GIplj3KhV8dc,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(1),J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	if not WWXzI34UZEqYhf25uxJwLVo: WWXzI34UZEqYhf25uxJwLVo = 0
	F4qYux1pl7BNG0feJRbOSPhKc9CV5A = int(WWXzI34UZEqYhf25uxJwLVo/100)+1
	for jwQ1lvmx6hFoet7N5OViJITA4GdZ0c in range(2,F4qYux1pl7BNG0feJRbOSPhKc9CV5A):
		ii8MX4g6Jpmzy0rh7u = (jwQ1lvmx6hFoet7N5OViJITA4GdZ0c%10==0 or int(GGyLnP8egKaM9Oxr)-4<jwQ1lvmx6hFoet7N5OViJITA4GdZ0c<int(GGyLnP8egKaM9Oxr)+4)
		JfYeiqVQ1F7ZWp9 = (ii8MX4g6Jpmzy0rh7u and int(GGyLnP8egKaM9Oxr)-40<jwQ1lvmx6hFoet7N5OViJITA4GdZ0c<int(GGyLnP8egKaM9Oxr)+40)
		if str(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)!=GGyLnP8egKaM9Oxr and (jwQ1lvmx6hFoet7N5OViJITA4GdZ0c%100==0 or JfYeiqVQ1F7ZWp9):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'صفحة '+str(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c),GIplj3KhV8dc,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c),J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	if str(F4qYux1pl7BNG0feJRbOSPhKc9CV5A)!=GGyLnP8egKaM9Oxr: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أخر صفحة '+str(F4qYux1pl7BNG0feJRbOSPhKc9CV5A),GIplj3KhV8dc,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(F4qYux1pl7BNG0feJRbOSPhKc9CV5A),J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	return
def JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc):
	if 'SERIES' in GIplj3KhV8dc or 'VOD_ORIGINAL' in GIplj3KhV8dc: nHXBLNq37CIjZvQDw = IIUtvdg9HxyNPckQCD5KZfRuF6el1
	else: nHXBLNq37CIjZvQDw = Eh67dFOcRbgCMl
	nHXBLNq37CIjZvQDw = nHXBLNq37CIjZvQDw.replace('___','_'+gYJAT1vW0Uqm76G)
	return nHXBLNq37CIjZvQDw
def RQ30OIxnSVbmetkKu5P7z(gYJAT1vW0Uqm76G,GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG):
	fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G)
	if not BarI1m9u06gVdhyCjGYWXbUv: return
	YeRr5GFOCqn9ufVy = Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G)
	if   GIplj3KhV8dc=='XTREAM_LIVE_GROUPS': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_live_categories'
	elif GIplj3KhV8dc=='XTREAM_VOD_GROUPS': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_vod_categories'
	elif GIplj3KhV8dc=='XTREAM_SERIES_GROUPS': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_series_categories'
	elif GIplj3KhV8dc=='XTREAM_LIVE_ITEMS': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_live_streams&category_id='+IWFYt6Pq9NRk5JD3OG
	elif GIplj3KhV8dc=='XTREAM_VOD_ITEMS': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_vod_streams&category_id='+IWFYt6Pq9NRk5JD3OG
	elif GIplj3KhV8dc=='XTREAM_SERIES_ITEMS': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_series&category_id='+IWFYt6Pq9NRk5JD3OG
	elif GIplj3KhV8dc=='XTREAM_EPISODES': wNyZhHdvUeC3M = fPY3NmaF1d0W2b+'&action=get_series_info&series_id='+IWFYt6Pq9NRk5JD3OG
	else: return
	BTxl2eLIqSzUk = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',wNyZhHdvUeC3M,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IPTV-XTREAM_MENUS-1st')
	oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
	if n7neb9KTv10FcU: oHQzKutsWeALwSEXc8a = oHQzKutsWeALwSEXc8a.decode(zSafwK0sDXdMN5JReniIQmrZxp).encode(zSafwK0sDXdMN5JReniIQmrZxp)
	hSjwWYR3vpCFfnUEPaGZc = dr1zfnatJxRHSF48jh0eODm5bGu('list',oHQzKutsWeALwSEXc8a)
	if 'GROUPS' in GIplj3KhV8dc:
		GIplj3KhV8dc = GIplj3KhV8dc.replace('_GROUPS','_ITEMS')
		hSjwWYR3vpCFfnUEPaGZc = sorted(hSjwWYR3vpCFfnUEPaGZc,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope['category_name'].lower())
		for q4qfsInUtRDYlXdvTMe02xPNC in hSjwWYR3vpCFfnUEPaGZc:
			diZGcVFrYSI3Nej1TBKQDAaWL6k = q4qfsInUtRDYlXdvTMe02xPNC['category_id']
			GdbFDygsZ6HopImiSTY53 = q4qfsInUtRDYlXdvTMe02xPNC['category_name']
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,GIplj3KhV8dc,285,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(diZGcVFrYSI3Nej1TBKQDAaWL6k),nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	elif GIplj3KhV8dc=='XTREAM_SERIES_ITEMS':
		hSjwWYR3vpCFfnUEPaGZc = sorted(hSjwWYR3vpCFfnUEPaGZc,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope['name'].lower())
		for HnjdrRitSAxJO in hSjwWYR3vpCFfnUEPaGZc:
			GdbFDygsZ6HopImiSTY53 = HnjdrRitSAxJO['name']
			gwLmtlCDM6uq0EnWoNUx = HnjdrRitSAxJO['cover']
			diZGcVFrYSI3Nej1TBKQDAaWL6k = HnjdrRitSAxJO['series_id']
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,'XTREAM_EPISODES',285,gwLmtlCDM6uq0EnWoNUx,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(diZGcVFrYSI3Nej1TBKQDAaWL6k),nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	elif GIplj3KhV8dc=='XTREAM_EPISODES':
		gwLmtlCDM6uq0EnWoNUx = hSjwWYR3vpCFfnUEPaGZc['info']['cover']
		xbfwC5hkXLvsJa8PReOS9AyU1z = hSjwWYR3vpCFfnUEPaGZc['info']['name']
		yx1q53ZDps = hSjwWYR3vpCFfnUEPaGZc['episodes']
		for aa45XPWrsGeUTn6Mi0YHhucg in yx1q53ZDps:
			vqVXJZsko5U8StTnY96ywpiCgHad = yx1q53ZDps[aa45XPWrsGeUTn6Mi0YHhucg]
			for xOQ5C4qMYZNea96rzuPAK3V1HtL in vqVXJZsko5U8StTnY96ywpiCgHad:
				GdbFDygsZ6HopImiSTY53 = xOQ5C4qMYZNea96rzuPAK3V1HtL['title']
				QjFV2DniPbzUEh9SrdxwMNoK = ScntgdOZCY74vNpXeW5jh8i.findall('\d+.(S\d+E\d+)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if QjFV2DniPbzUEh9SrdxwMNoK: GdbFDygsZ6HopImiSTY53 = xbfwC5hkXLvsJa8PReOS9AyU1z+S3X6GcaiExOPtb+QjFV2DniPbzUEh9SrdxwMNoK[0]
				diZGcVFrYSI3Nej1TBKQDAaWL6k = xOQ5C4qMYZNea96rzuPAK3V1HtL['id']
				HHMfu7wkvaPYD = xOQ5C4qMYZNea96rzuPAK3V1HtL['container_extension']
				wNyZhHdvUeC3M = fPY3NmaF1d0W2b.split('/player_api.php')[0]+'/series/'+BarI1m9u06gVdhyCjGYWXbUv+'/'+MLkvbSEfXz+'/'+str(diZGcVFrYSI3Nej1TBKQDAaWL6k)+'.'+HHMfu7wkvaPYD
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,235,gwLmtlCDM6uq0EnWoNUx,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	elif 'ITEMS' in GIplj3KhV8dc:
		iiyAEbQ5f80 = 'live' if 'LIVE' in GIplj3KhV8dc else 'video'
		hSjwWYR3vpCFfnUEPaGZc = sorted(hSjwWYR3vpCFfnUEPaGZc,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope['name'].lower())
		for I4hKnYyUaQldSsOi37xEJmMC6 in hSjwWYR3vpCFfnUEPaGZc:
			GdbFDygsZ6HopImiSTY53 = I4hKnYyUaQldSsOi37xEJmMC6['name']
			gwLmtlCDM6uq0EnWoNUx = I4hKnYyUaQldSsOi37xEJmMC6['stream_icon']
			diZGcVFrYSI3Nej1TBKQDAaWL6k = I4hKnYyUaQldSsOi37xEJmMC6['stream_id']
			try:
				HHMfu7wkvaPYD = I4hKnYyUaQldSsOi37xEJmMC6['container_extension']
				if HHMfu7wkvaPYD: HHMfu7wkvaPYD = '.'+HHMfu7wkvaPYD
			except: HHMfu7wkvaPYD = nbOFVEDkpT4BIR7Qq82yPmHeJU
			if I4hKnYyUaQldSsOi37xEJmMC6['stream_type']=='live': jiDqcXSOhBL,bgj8L5UlSPnO9X3N = nbOFVEDkpT4BIR7Qq82yPmHeJU,'live'
			elif I4hKnYyUaQldSsOi37xEJmMC6['stream_type']=='movie': jiDqcXSOhBL,bgj8L5UlSPnO9X3N = 'movie/','video'
			wNyZhHdvUeC3M = fPY3NmaF1d0W2b.split('/player_api.php')[0]+'/'+jiDqcXSOhBL+BarI1m9u06gVdhyCjGYWXbUv+'/'+MLkvbSEfXz+'/'+str(diZGcVFrYSI3Nej1TBKQDAaWL6k)+HHMfu7wkvaPYD
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,235,gwLmtlCDM6uq0EnWoNUx,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	return
def G9nYDmlrhKk(gYJAT1vW0Uqm76G):
	H0HP8jx7JYMbp5BSLGKi9f = llnG7jiQBYKhAeovbT.getSetting('av.language.provider')
	aUpbQVqwl0 = llnG7jiQBYKhAeovbT.getSetting('av.language.code')
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'MENUS_CACHE_'+H0HP8jx7JYMbp5BSLGKi9f+'_'+aUpbQVqwl0,'%_IP'+gYJAT1vW0Uqm76G+'_%')
	return
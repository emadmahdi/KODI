# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'SHOOFMAX'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_SHM_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
C07t1e38mH2LEMzny4vX9riOblaBF = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][1]
wjWfPaeBKlAs0 = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][2]
def n1zxUlcAgR(mode,url,text):
	if   mode==50: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==51: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==52: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==53: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==55: bPFto2wZdNYrClgBIEv60DJAzu = WId17m3tD8jJc0FRYGQbOgqx()
	elif mode==56: bPFto2wZdNYrClgBIEv60DJAzu = FgpREZd8cHDVbPK0M52si1m()
	elif mode==57: bPFto2wZdNYrClgBIEv60DJAzu = VVbAcyXe2o0h(url,1)
	elif mode==58: bPFto2wZdNYrClgBIEv60DJAzu = VVbAcyXe2o0h(url,2)
	elif mode==59: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,59,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المسلسلات',nbOFVEDkpT4BIR7Qq82yPmHeJU,56)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الافلام',nbOFVEDkpT4BIR7Qq82yPmHeJU,55)
	return nbOFVEDkpT4BIR7Qq82yPmHeJU
def WId17m3tD8jJc0FRYGQbOgqx():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أفلام مرتبة بسنة الإنتاج',zKREXyTHfVSNL8ZFYs+'/movie/1/yop',57)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أفلام مرتبة بالأفضل تقييم',zKREXyTHfVSNL8ZFYs+'/movie/1/review',57)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أفلام مرتبة بالأكثر مشاهدة',zKREXyTHfVSNL8ZFYs+'/movie/1/views',57)
	return
def FgpREZd8cHDVbPK0M52si1m():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات مرتبة بسنة الإنتاج',zKREXyTHfVSNL8ZFYs+'/series/1/yop',57)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات مرتبة بالأفضل تقييم',zKREXyTHfVSNL8ZFYs+'/series/1/review',57)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات مرتبة بالأكثر مشاهدة',zKREXyTHfVSNL8ZFYs+'/series/1/views',57)
	return
def IGDobAKtj4kPF5V(url):
	if '?' in url:
		LCjugSrWIBPDyFb4X1o9fAM = url.split('?')
		url = LCjugSrWIBPDyFb4X1o9fAM[0]
		filter = '?' + lcxFAteLQ1Pwu45Er2(LCjugSrWIBPDyFb4X1o9fAM[1],'=&:/%')
	else: filter = nbOFVEDkpT4BIR7Qq82yPmHeJU
	type,ohpwd6UumaecE3IWV8lAv0,sort = url.split('/')[-3:]
	if sort in ['yop','review','views']:
		if type=='movie': gg8S4FihUQy0V26='فيلم'
		elif type=='series': gg8S4FihUQy0V26='مسلسل'
		url = zKREXyTHfVSNL8ZFYs + '/genre/filter/' + lcxFAteLQ1Pwu45Er2(gg8S4FihUQy0V26) + '/' + ohpwd6UumaecE3IWV8lAv0 + '/' + sort + filter
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHOOFMAX-TITLES-1st')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"pid":(.*?),.*?"ptitle":"(.*?)".+?"pepisodes":(.*?),"presbase":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Nct612JRyeKvnW=0
		for id,title,OtXcDCpRaiWIK2,X79kphTKa1xLP in items:
			Nct612JRyeKvnW += 1
			X79kphTKa1xLP = wjWfPaeBKlAs0 + '/v2/img/program/main/' + X79kphTKa1xLP + '-2.jpg'
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + '/program/' + id
			if type=='movie': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,53,X79kphTKa1xLP)
			if type=='series': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسل '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?ep='+OtXcDCpRaiWIK2+'='+title+'='+X79kphTKa1xLP,52,X79kphTKa1xLP)
	else:
		if type=='movie': gg8S4FihUQy0V26='movies'
		elif type=='series': gg8S4FihUQy0V26='series'
		url = C07t1e38mH2LEMzny4vX9riOblaBF + '/json/selected/' + sort + '-' + gg8S4FihUQy0V26 + '-WW.json'
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHOOFMAX-TITLES-2nd')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"ref":(.*?),"ep":(.*?),"base":"(.*?)","title":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Nct612JRyeKvnW=0
		for id,OtXcDCpRaiWIK2,X79kphTKa1xLP,title in items:
			Nct612JRyeKvnW += 1
			X79kphTKa1xLP = C07t1e38mH2LEMzny4vX9riOblaBF + '/img/program/' + X79kphTKa1xLP + '-2.jpg'
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs + '/program/' + id
			if type=='movie': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,53,X79kphTKa1xLP)
			elif type=='series': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسل '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?ep='+OtXcDCpRaiWIK2+'='+title+'='+X79kphTKa1xLP,52,X79kphTKa1xLP)
	title='صفحة '
	if Nct612JRyeKvnW==16:
		for nhEPv1MDkF in range(1,13) :
			if not ohpwd6UumaecE3IWV8lAv0==str(nhEPv1MDkF):
				url = zKREXyTHfVSNL8ZFYs+'/genre/filter/'+type+'/'+str(nhEPv1MDkF)+'/'+sort+filter
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title+str(nhEPv1MDkF),url,51)
	return
def PXyn8J3WjhRgA(url):
	LCjugSrWIBPDyFb4X1o9fAM = url.split('=')
	OtXcDCpRaiWIK2 = int(LCjugSrWIBPDyFb4X1o9fAM[1])
	name = SxN0jnqr3LI(LCjugSrWIBPDyFb4X1o9fAM[2])
	name = name.replace('_MOD_مسلسل ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	X79kphTKa1xLP = LCjugSrWIBPDyFb4X1o9fAM[3]
	url = url.split('?')[0]
	if OtXcDCpRaiWIK2==0:
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHOOFMAX-EPISODES-1st')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<select(.*?)</select>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('option value="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		OtXcDCpRaiWIK2 = int(items[-1])
	for BBuqr7CwzEIi9UL54n0AVoHXPlp in range(OtXcDCpRaiWIK2,0,-1):
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url + '?ep=' + str(BBuqr7CwzEIi9UL54n0AVoHXPlp)
		title = '_MOD_مسلسل '+name+' - الحلقة '+str(BBuqr7CwzEIi9UL54n0AVoHXPlp)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,53,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHOOFMAX-PLAY-1st')
	Zmwb0sIXPS5 = ScntgdOZCY74vNpXeW5jh8i.findall('متوفر على شوف ماكس بعد.*?moment\("(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if Zmwb0sIXPS5:
		lQMuw1PvVpAk = Zmwb0sIXPS5[1].replace('T',R4PgzXibOn3f1SxmldrWw8acs2p)
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من الموقع الأصلي','هذا الفيديو سيكون متوفر على شوف ماكس بعد هذا الوقت'+wwOnIucWJj+lQMuw1PvVpAk)
		return
	Cl7xZeq3zE8ngTfDbBLioFk5tQ,hXltiU7B4Q8gwnm = [],[]
	pdlv1MXYcKmyjSTJ8wiQbV3 = ScntgdOZCY74vNpXeW5jh8i.findall('var origin_link = "(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	PFqxYMIH7GeWB = ScntgdOZCY74vNpXeW5jh8i.findall('var backup_origin_link = "(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('hls: (.*?)_link\+"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for RWZpkDLtY5Eyb46029MvAKmqBQd8o,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P:
		if 'backup' in RWZpkDLtY5Eyb46029MvAKmqBQd8o:
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = 'backup server'
			url = PFqxYMIH7GeWB + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		else:
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = 'main server'
			url = pdlv1MXYcKmyjSTJ8wiQbV3 + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		if '.m3u8' in url:
			Cl7xZeq3zE8ngTfDbBLioFk5tQ.append(url)
			hXltiU7B4Q8gwnm.append('m3u8  '+RWZpkDLtY5Eyb46029MvAKmqBQd8o)
	rU02bCJFWZDfVuhtMgBOyQi5P = ScntgdOZCY74vNpXeW5jh8i.findall('mp4:.*?_link.*?\t(.*?)_link\+"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	rU02bCJFWZDfVuhtMgBOyQi5P += ScntgdOZCY74vNpXeW5jh8i.findall('mp4:.*?\t(.*?)_link\+"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for RWZpkDLtY5Eyb46029MvAKmqBQd8o,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in rU02bCJFWZDfVuhtMgBOyQi5P:
		filename = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-1]
		filename = filename.replace('fallback',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		filename = filename.replace('.mp4',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		filename = filename.replace('-',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if 'backup' in RWZpkDLtY5Eyb46029MvAKmqBQd8o:
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = 'backup server'
			url = PFqxYMIH7GeWB + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		else:
			RWZpkDLtY5Eyb46029MvAKmqBQd8o = 'main server'
			url = pdlv1MXYcKmyjSTJ8wiQbV3 + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Cl7xZeq3zE8ngTfDbBLioFk5tQ.append(url)
		hXltiU7B4Q8gwnm.append('mp4  '+RWZpkDLtY5Eyb46029MvAKmqBQd8o+BhmzEC6OGD7FXZig9Tp5A+filename)
	bCiGxXzDkH = nnRXQH90qeOtABkJzGr('Select Video Quality:', hXltiU7B4Q8gwnm)
	if bCiGxXzDkH == -1 : return
	url = Cl7xZeq3zE8ngTfDbBLioFk5tQ[bCiGxXzDkH]
	brh5aWRxQzn6YL8UDNOyK9SFGo(url,QSJFrwB3dMiyH2mTPKD9a,'video')
	return
def VVbAcyXe2o0h(url,type):
	if 'series' in url: plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs + '/genre/مسلسل'
	else: plSscrVjkRviPwm = zKREXyTHfVSNL8ZFYs + '/genre/فيلم'
	plSscrVjkRviPwm = lcxFAteLQ1Pwu45Er2(plSscrVjkRviPwm)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHOOFMAX-FILTERS-1st')
	if type==1: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('subgenre(.*?)div',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type==2: eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('country(.*?)div',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('option value="(.*?)">(.*?)</option',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if type==1:
		for Ul02qgcYkE7Xs5VxA8Fhv6urWSBdN,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url+'?subgenre='+Ul02qgcYkE7Xs5VxA8Fhv6urWSBdN,58)
	elif type==2:
		url,Ul02qgcYkE7Xs5VxA8Fhv6urWSBdN = url.split('?')
		for OORJ1AnN4w,title in items:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url+'?country='+OORJ1AnN4w+'&'+Ul02qgcYkE7Xs5VxA8Fhv6urWSBdN,51)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search: search = dR75Vq2gprfHmUcNhG()
	if not search: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'%20')
	url = zKREXyTHfVSNL8ZFYs+'/search?q='+T871qPZzS4LkoMBa3Db9Q
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHOOFMAX-SEARCH-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('general-body(.*?)search-bottom-padding',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<span>(.*?)</span>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			url = zKREXyTHfVSNL8ZFYs + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			if '/program/' in url:
				if '?ep=' in url:
					title = '_MOD_مسلسل '+title
					url = url.replace('?ep=1','?ep=0')
					url = url+'='+lcxFAteLQ1Pwu45Er2(title)+'='+X79kphTKa1xLP
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,52,X79kphTKa1xLP)
				else:
					title = '_MOD_فيلم '+title
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,53,X79kphTKa1xLP)
	return
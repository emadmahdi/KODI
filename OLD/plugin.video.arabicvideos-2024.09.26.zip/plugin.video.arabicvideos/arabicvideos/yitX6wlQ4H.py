# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'KARBALATV'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_KRB_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
def n1zxUlcAgR(mode,url,text):
	if   mode==320: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==321: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==322: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==329: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,329,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs+'/video.php',nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'KARBALATV-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="icono-plus"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if title=='المكتبة المرئية': continue
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,321)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'KARBALATV-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="container"(.*?)class="footer',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?url\((.*?)\).*?pd5">(.*?)<.*?<h3.*?">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?<p.*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,count,title in items:
		count = count.replace('عدد ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(S3X6GcaiExOPtb,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('/',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		X79kphTKa1xLP = X79kphTKa1xLP.replace("'",nbOFVEDkpT4BIR7Qq82yPmHeJU)
		if '.php' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = 'video.php'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		X79kphTKa1xLP = zKREXyTHfVSNL8ZFYs+X79kphTKa1xLP
		title = title.strip(S3X6GcaiExOPtb)
		title = title+' ('+count+')'
		if 'video.php' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,321,X79kphTKa1xLP)
		elif 'watch.php' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,322,X79kphTKa1xLP)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination(.*?)class="footer',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/video.php'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,321)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'KARBALATV-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<video.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
	brh5aWRxQzn6YL8UDNOyK9SFGo(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,QSJFrwB3dMiyH2mTPKD9a,'video')
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/search.php?q='+search
	IGDobAKtj4kPF5V(url)
	return
# -*- coding: utf-8 -*-
import sys as Jg3GROZ80HzMpAfL2DQ4mdYhuW
GcBsfFmQnUAOHL = Jg3GROZ80HzMpAfL2DQ4mdYhuW.version_info [0] == 2
fxaugIi0pNC1EJr24dVQFoyLGzjMq = 2048
R05bmXlzLTfpKWnwrYhcN1 = 7
def dWT9VD10UN7HYps6CjBx2Kre5 (jrOGPFdn4U6u):
	global F1BMNoYgfy
	QQsWxAEoudwaMNOU6DmC8Ing3rKPi = ord (jrOGPFdn4U6u [-1])
	jEXqBebAQOLGI4MD0 = jrOGPFdn4U6u [:-1]
	XlHnMNGgEj81LOYUk2xzJsc = QQsWxAEoudwaMNOU6DmC8Ing3rKPi % len (jEXqBebAQOLGI4MD0)
	xXf6UYW8MOigL1TvwuQNz = jEXqBebAQOLGI4MD0 [:XlHnMNGgEj81LOYUk2xzJsc] + jEXqBebAQOLGI4MD0 [XlHnMNGgEj81LOYUk2xzJsc:]
	if GcBsfFmQnUAOHL:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = unicode () .join ([unichr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	else:
		GPBQqXyhTl97s0Dd1bAiRSOfnMFw = str () .join ([chr (ord (tt49OvGhJZHfoMQEI3cep2KdPB) - fxaugIi0pNC1EJr24dVQFoyLGzjMq - (tKhCEQwvpkG9da75YHjRLSO8 + QQsWxAEoudwaMNOU6DmC8Ing3rKPi) % R05bmXlzLTfpKWnwrYhcN1) for tKhCEQwvpkG9da75YHjRLSO8, tt49OvGhJZHfoMQEI3cep2KdPB in enumerate (xXf6UYW8MOigL1TvwuQNz)])
	return eval (GPBQqXyhTl97s0Dd1bAiRSOfnMFw)
UpQ56M0dO1N9xIvVegy,CHoDl0dwRYtmuxqjsIBhfLVXvWz,I3cxjYaHhsrM7T4UX26klN=dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5,dWT9VD10UN7HYps6CjBx2Kre5
X60YQOADpkHBb31LiR5qUEKfM,l4DS8mnEjHhFMZ5YOe,cb3rmvAn4wa6lBPz2phOoYqX=I3cxjYaHhsrM7T4UX26klN,CHoDl0dwRYtmuxqjsIBhfLVXvWz,UpQ56M0dO1N9xIvVegy
tM24jD1gO0,bYyKEjIuGQzoq3AR1,bX31T2x0lnuUf8yq5B4QcjSMmEtJ6=cb3rmvAn4wa6lBPz2phOoYqX,l4DS8mnEjHhFMZ5YOe,X60YQOADpkHBb31LiR5qUEKfM
QlTuvPbSpnjygBVW,t4txivgXSUWBOlCakQmNDjf,ulAxHwvzR9eTb5n=bX31T2x0lnuUf8yq5B4QcjSMmEtJ6,bYyKEjIuGQzoq3AR1,tM24jD1gO0
YqeFVBiHnv5Tj3rao4EdQyK1txzpk,qrjy8LuKVPNYdbSvzh,fsQukcZeJ8YbozTXKEvS7h306DCA=ulAxHwvzR9eTb5n,t4txivgXSUWBOlCakQmNDjf,QlTuvPbSpnjygBVW
wCUIOeyRdxF3PtJ6TKYog8Xb,xxtgfCnWOFlo0jTbU3PQI4Dq,YayJj10OGl=fsQukcZeJ8YbozTXKEvS7h306DCA,qrjy8LuKVPNYdbSvzh,YqeFVBiHnv5Tj3rao4EdQyK1txzpk
paRsBdn3iSc8KC6NtGmqeWQVYOUEg,usVCatpJzZGQ4gFiWX6803UALlkBOc,Fo1SgXMsHk=YayJj10OGl,xxtgfCnWOFlo0jTbU3PQI4Dq,wCUIOeyRdxF3PtJ6TKYog8Xb
O5OqHBgSVeRyN4xtjYnzuZpTLi9l,bnI4kmPtrW7yFEhljXOCq9,flDSRbv57PnV3=Fo1SgXMsHk,usVCatpJzZGQ4gFiWX6803UALlkBOc,paRsBdn3iSc8KC6NtGmqeWQVYOUEg
yHC3RfStdgELTPBsFM9ZjoDkqrp16U,fgv5U2eRVaQqSiuGD,SSvu1CZjTW7FcloNqD=flDSRbv57PnV3,bnI4kmPtrW7yFEhljXOCq9,O5OqHBgSVeRyN4xtjYnzuZpTLi9l
DOyBeuj4bU7r5mAGEdHTKCpq2zaog3,DJ6ugPjW9bX8I,X1mRwt2YJKgCLu9a67=SSvu1CZjTW7FcloNqD,fgv5U2eRVaQqSiuGD,yHC3RfStdgELTPBsFM9ZjoDkqrp16U
IINBvuxkCSJrO1Q0UyngdLi,q4izXt0sjIQSZcHVAf3EmKRbx,z3sIGH8jmLYg=X1mRwt2YJKgCLu9a67,DJ6ugPjW9bX8I,DOyBeuj4bU7r5mAGEdHTKCpq2zaog3
from vYfmi4wEP5 import *
QSJFrwB3dMiyH2mTPKD9a = qrjy8LuKVPNYdbSvzh(u"ࠬࡏࡎࡊࡖࠪ൫")
FnTa4o9zXmR1Zv5lsc3JhB = SSvu1CZjTW7FcloNqD(u"࠭࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂ࠭൬")
vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ = Xo39wTgh20UdCuxn7qOepyVsYmtPNE(cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
yotXRvP4md3Vrnhq9lBH1F = int(xv42oTYCQusGHzjMc3n01Zq)
NNntz8hA93kG6WqEDb1OUoeFm2fg = RarSo2nTfwU0WEGK.getInfoLabel(Fo1SgXMsHk(u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨ൭"))
NNntz8hA93kG6WqEDb1OUoeFm2fg = NNntz8hA93kG6WqEDb1OUoeFm2fg.replace(AQJdiEVCZaDfh4,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(dVMZJNUoPLOSp47lkeh6T0W31Gj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
if yotXRvP4md3Vrnhq9lBH1F==z3sIGH8jmLYg(u"࠵࠺࠵ඓ"): QmwRDUBFt4qkxYISz5n8Eh = DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩ൮")+JeVILUu027qW+yHC3RfStdgELTPBsFM9ZjoDkqrp16U(u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩ൯")+NZXC8zME6TFkOi0bpKVHLwfJydD4Ue+xxtgfCnWOFlo0jTbU3PQI4Dq(u"ࠪࠤࡢ࠭൰")
else:
	u6TgGr1StQ4ZqzsvFIe9VE8M = SxN0jnqr3LI(cvU8LCyfWkogjSeF9lHphBdEZnzsmr).replace(eMypvI8XqHjYU02anWD9gsSrkt,nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(l5JG7XwbOfo8DznU,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	u6TgGr1StQ4ZqzsvFIe9VE8M = u6TgGr1StQ4ZqzsvFIe9VE8M.replace(c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
	u6TgGr1StQ4ZqzsvFIe9VE8M = u6TgGr1StQ4ZqzsvFIe9VE8M.replace(R4PgzXibOn3f1SxmldrWw8acs2p,S3X6GcaiExOPtb).replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	QmwRDUBFt4qkxYISz5n8Eh = wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠫࠥࠦࠠࡍࡣࡥࡩࡱࡀࠠ࡜ࠢࠪ൱")+NNntz8hA93kG6WqEDb1OUoeFm2fg+Fo1SgXMsHk(u"ࠬࠦ࡝ࠡࠢࠣࡑࡴࡪࡥ࠻ࠢ࡞ࠤࠬ൲")+xv42oTYCQusGHzjMc3n01Zq+Fo1SgXMsHk(u"࠭ࠠ࡞ࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭൳")+u6TgGr1StQ4ZqzsvFIe9VE8M+z3sIGH8jmLYg(u"ࠧࠡ࡟ࠪ൴")
fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,FnTa4o9zXmR1Zv5lsc3JhB+wwOnIucWJj+Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+QmwRDUBFt4qkxYISz5n8Eh)
if flDSRbv57PnV3(u"ࠨࡡࠪ൵") in p8pRVmk1Jg03PjfMonTFyvLCax: jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko = p8pRVmk1Jg03PjfMonTFyvLCax.split(SSvu1CZjTW7FcloNqD(u"ࠩࡢࠫ൶"),t4txivgXSUWBOlCakQmNDjf(u"࠵ඔ"))
else: jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko = p8pRVmk1Jg03PjfMonTFyvLCax,nbOFVEDkpT4BIR7Qq82yPmHeJU
fnZbzLvOBJm9krHujVw1oc3lYPq5,vf9s4ClmTE08AGndQV = SmbNGskjMx,nbOFVEDkpT4BIR7Qq82yPmHeJU
if jopJxNuhKylA7 in [tM24jD1gO0(u"ࠪ࠵ࠬ൷"),bnI4kmPtrW7yFEhljXOCq9(u"ࠫ࠷࠭൸"),cb3rmvAn4wa6lBPz2phOoYqX(u"ࠬ࠹ࠧ൹"),q4izXt0sjIQSZcHVAf3EmKRbx(u"࠭࠴ࠨൺ"),I3cxjYaHhsrM7T4UX26klN(u"ࠧ࠶ࠩൻ"),X1mRwt2YJKgCLu9a67(u"ࠨ࠳࠴ࠫർ"),DJ6ugPjW9bX8I(u"ࠩ࠴࠶ࠬൽ"),wCUIOeyRdxF3PtJ6TKYog8Xb(u"ࠪ࠵࠸࠭ൾ")] and (usVCatpJzZGQ4gFiWX6803UALlkBOc(u"ࠫࡆࡊࡄࠨൿ") in ZcBfxUiVw9yeSzv8sGh34EW2QMko or t4txivgXSUWBOlCakQmNDjf(u"ࠬࡘࡅࡎࡑ࡙ࡉࠬ඀") in ZcBfxUiVw9yeSzv8sGh34EW2QMko or CHoDl0dwRYtmuxqjsIBhfLVXvWz(u"࠭ࡕࡑࠩඁ") in ZcBfxUiVw9yeSzv8sGh34EW2QMko or l4DS8mnEjHhFMZ5YOe(u"ࠧࡅࡑ࡚ࡒࠬං") in ZcBfxUiVw9yeSzv8sGh34EW2QMko):
	from Z2ZSU6yEYJ import YOqPCEczglNJma4xWU3QebRXwA2
	YOqPCEczglNJma4xWU3QebRXwA2(p8pRVmk1Jg03PjfMonTFyvLCax,jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko)
	llnG7jiQBYKhAeovbT.setSetting(z3sIGH8jmLYg(u"ࠨࡣࡹ࠲ࡸࡺࡡࡵࡷࡶ࠲ࡷ࡫ࡦࡳࡧࡶ࡬ࠬඃ"),cvU8LCyfWkogjSeF9lHphBdEZnzsmr)
	fnZbzLvOBJm9krHujVw1oc3lYPq5 = Ag9l6cw3EBqP8HsQuGMizfOtr4
elif not QQpBeZUlAbNKHfkCDLcqWYzv5 and yotXRvP4md3Vrnhq9lBH1F in [usVCatpJzZGQ4gFiWX6803UALlkBOc(u"࠷࠹࠵ඕ"),Fo1SgXMsHk(u"࠽࠱࠶ඖ")]:
	Doj1K07b4tihOJq2uQEP = str(Nyb1swDcFkeGUdMEnh9itZ[IINBvuxkCSJrO1Q0UyngdLi(u"ࠩࡩࡳࡱࡪࡥࡳࠩ඄")])
	QSJFrwB3dMiyH2mTPKD9a = YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠪࡍࡕ࡚ࡖࠨඅ") if yotXRvP4md3Vrnhq9lBH1F==Fo1SgXMsHk(u"࠲࠴࠷඗") else DJ6ugPjW9bX8I(u"ࠫࡒ࠹ࡕࠨආ")
	NZiDm7j4LV0lIABFzd = QSJFrwB3dMiyH2mTPKD9a.lower()
	VLs4zv8ycboXT0UG7rk2fAj = llnG7jiQBYKhAeovbT.getSetting(X60YQOADpkHBb31LiR5qUEKfM(u"ࠬࡧࡶ࠯ࠩඇ")+NZiDm7j4LV0lIABFzd+X1mRwt2YJKgCLu9a67(u"࠭࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࡢࠫඈ")+Doj1K07b4tihOJq2uQEP)
	JygZr6tXVAOGqPoF = llnG7jiQBYKhAeovbT.getSetting(IINBvuxkCSJrO1Q0UyngdLi(u"ࠧࡢࡸ࠱ࠫඉ")+NZiDm7j4LV0lIABFzd+DOyBeuj4bU7r5mAGEdHTKCpq2zaog3(u"ࠨ࠰ࡵࡩ࡫࡫ࡲࡦࡴࡢࠫඊ")+Doj1K07b4tihOJq2uQEP)
	if VLs4zv8ycboXT0UG7rk2fAj or JygZr6tXVAOGqPoF:
		qxZiT6WJ7sX += YqeFVBiHnv5Tj3rao4EdQyK1txzpk(u"ࠩࡿࠫඋ")
		if VLs4zv8ycboXT0UG7rk2fAj: qxZiT6WJ7sX += bX31T2x0lnuUf8yq5B4QcjSMmEtJ6(u"࡚ࠪࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠩඌ")+VLs4zv8ycboXT0UG7rk2fAj
		if JygZr6tXVAOGqPoF: qxZiT6WJ7sX += l4DS8mnEjHhFMZ5YOe(u"ࠫࠫࡘࡥࡧࡧࡵࡩࡷࡃࠧඍ")+JygZr6tXVAOGqPoF
		qxZiT6WJ7sX = qxZiT6WJ7sX.replace(qrjy8LuKVPNYdbSvzh(u"ࠬࢂࠦࠨඎ"),YayJj10OGl(u"࠭ࡼࠨඏ"))
	IX6oaStOE0FC = llnG7jiQBYKhAeovbT.getSetting(qrjy8LuKVPNYdbSvzh(u"ࠧࡢࡸ࠱ࠫඐ")+NZiDm7j4LV0lIABFzd+fsQukcZeJ8YbozTXKEvS7h306DCA(u"ࠨ࠰ࡶࡩࡷࡼࡥࡳࡡࠪඑ")+Doj1K07b4tihOJq2uQEP)
	if IX6oaStOE0FC:
		FZBotRmCzcN4Pku = ScntgdOZCY74vNpXeW5jh8i.findall(paRsBdn3iSc8KC6NtGmqeWQVYOUEg(u"ࠩ࠽࠳࠴࠮࠮ࠫࡁࠬ࠳ࠬඒ"),qxZiT6WJ7sX,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		qxZiT6WJ7sX = qxZiT6WJ7sX.replace(FZBotRmCzcN4Pku[f4fTutDOEwUeIoPLRQ],IX6oaStOE0FC)
	brh5aWRxQzn6YL8UDNOyK9SFGo(qxZiT6WJ7sX,QSJFrwB3dMiyH2mTPKD9a,vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG)
else:
	import RpSbDv2A79
	try: RpSbDv2A79.AAMHj7rFgDiz6oeaBmy0vfQI4x(vBfOEdTrMP3HnQ2lbwVZtoe4hXDLSG,hXFjqduwKEt2TDC,qxZiT6WJ7sX,xv42oTYCQusGHzjMc3n01Zq,nnu5vdh1IscOA8J,ohpwd6UumaecE3IWV8lAv0,om2lqtcZ5y4j,p8pRVmk1Jg03PjfMonTFyvLCax,Nyb1swDcFkeGUdMEnh9itZ,yotXRvP4md3Vrnhq9lBH1F,jopJxNuhKylA7,ZcBfxUiVw9yeSzv8sGh34EW2QMko,NNntz8hA93kG6WqEDb1OUoeFm2fg)
	except Exception as FfrbtQYZoXdWM3Lu6nKU5g0RP4: vf9s4ClmTE08AGndQV = R63P9q5uQMWwtdo81jYg7NZ.format_exc()
	fnZbzLvOBJm9krHujVw1oc3lYPq5 = RpSbDv2A79.fnZbzLvOBJm9krHujVw1oc3lYPq5
DI8EKCHQ4spn5iJLZO0f7Syzbdwhr(fnZbzLvOBJm9krHujVw1oc3lYPq5,vf9s4ClmTE08AGndQV)
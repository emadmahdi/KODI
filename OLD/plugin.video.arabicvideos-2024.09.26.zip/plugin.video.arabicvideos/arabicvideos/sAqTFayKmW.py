# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'IFILM'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_IFL_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
C07t1e38mH2LEMzny4vX9riOblaBF = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][1]
wjWfPaeBKlAs0 = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][2]
U5JYWlngLrotq7XahZs4Gd = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][3]
def n1zxUlcAgR(mode,url,ohpwd6UumaecE3IWV8lAv0,text):
	if   mode==20: bPFto2wZdNYrClgBIEv60DJAzu = QlfXJDdoZPFL2Sc()
	elif mode==21: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0(url)
	elif mode==22: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==23: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url,ohpwd6UumaecE3IWV8lAv0)
	elif mode==24: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url,text)
	elif mode==25: bPFto2wZdNYrClgBIEv60DJAzu = h0WevrZX7bAixDyfGBu64kOaqQRVsH(url)
	elif mode==27: bPFto2wZdNYrClgBIEv60DJAzu = dsFVer3DMTj2iQANyPmvkYU7(url)
	elif mode==28: bPFto2wZdNYrClgBIEv60DJAzu = hjg8KbnO9TIsxR5()
	elif mode==29: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def QlfXJDdoZPFL2Sc():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'عربي',zKREXyTHfVSNL8ZFYs,21,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'English',C07t1e38mH2LEMzny4vX9riOblaBF,21,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فارسى',wjWfPaeBKlAs0,21,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فارسى 2',U5JYWlngLrotq7XahZs4Gd,21,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	return
def hjg8KbnO9TIsxR5():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'عربي',zKREXyTHfVSNL8ZFYs,27)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'English',C07t1e38mH2LEMzny4vX9riOblaBF,27)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فارسى',wjWfPaeBKlAs0,27)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فارسى 2',U5JYWlngLrotq7XahZs4Gd,27)
	return
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0(qmkfr0ROtxc):
	QSJFrwB3dMiyH2mTPKD9a = qmkfr0ROtxc
	if qmkfr0ROtxc=='IFILM-ARABIC': qmkfr0ROtxc = zKREXyTHfVSNL8ZFYs
	elif qmkfr0ROtxc=='IFILM-ENGLISH': qmkfr0ROtxc = C07t1e38mH2LEMzny4vX9riOblaBF
	else: QSJFrwB3dMiyH2mTPKD9a = nbOFVEDkpT4BIR7Qq82yPmHeJU
	v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(qmkfr0ROtxc)
	if v7vZOgAQb30LNJljTKuS8Czc16=='ar' or QSJFrwB3dMiyH2mTPKD9a=='IFILM-ARABIC':
		yyEelwL6NWJ0TaqFbc = 'بحث في الموقع'
		Y3Df741wvGOihEHF = 'مسلسلات - حالية'
		Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'مسلسلات - أحدث'
		o3oe5HBg7LUt = 'مسلسلات - أبجدي'
		aCzpsODZEBm2vy7Lt = 'بث حي آي فيلم'
		A2ezuNYtrLw = 'أفلام'
		Hs0c2eObzSuFiVoRjlnwh1ZPYGaC = 'موسيقى'
		IOgUp4AR1zPQXtaSL0De83uibns = 'برامج'
	elif v7vZOgAQb30LNJljTKuS8Czc16=='en' or QSJFrwB3dMiyH2mTPKD9a=='IFILM-ENGLISH':
		yyEelwL6NWJ0TaqFbc = 'Search in site'
		Y3Df741wvGOihEHF = 'Series - Current'
		Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'Series - Latest'
		o3oe5HBg7LUt = 'Series - Alphabet'
		aCzpsODZEBm2vy7Lt = 'Live iFilm channel'
		A2ezuNYtrLw = 'Movies'
		Hs0c2eObzSuFiVoRjlnwh1ZPYGaC = 'Music'
		IOgUp4AR1zPQXtaSL0De83uibns = 'Shows'
	elif v7vZOgAQb30LNJljTKuS8Czc16 in ['fa','fa2']:
		yyEelwL6NWJ0TaqFbc = 'جستجو در سایت'
		Y3Df741wvGOihEHF = 'سريال - جاری'
		Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = 'سريال - آخرین'
		o3oe5HBg7LUt = 'سريال - الفبا'
		aCzpsODZEBm2vy7Lt = 'پخش زنده اي فيلم'
		A2ezuNYtrLw = 'فيلم'
		Hs0c2eObzSuFiVoRjlnwh1ZPYGaC = 'موسيقى'
		IOgUp4AR1zPQXtaSL0De83uibns = 'برنامه ها'
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+yyEelwL6NWJ0TaqFbc,qmkfr0ROtxc,29,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('live',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+aCzpsODZEBm2vy7Lt,qmkfr0ROtxc,27)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	XHr9mRzgEVcM26KOdYTBWf4Lxa = ['Series','Program','Music']
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,qmkfr0ROtxc+'/home',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-MENU-1st')
	eXpgPIbRv2ZMGwjm5=ScntgdOZCY74vNpXeW5jh8i.findall('button-menu(.*?)/Contact',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if any(XPL0O2VkI3w1C8enMaqi in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 for XPL0O2VkI3w1C8enMaqi in XHr9mRzgEVcM26KOdYTBWf4Lxa):
				url = qmkfr0ROtxc+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				if 'Series' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Y3Df741wvGOihEHF,url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,'100')
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y,url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+o3oe5HBg7LUt,url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,'201')
				elif 'Film' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+A2ezuNYtrLw,url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,'100')
				elif 'Music' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Hs0c2eObzSuFiVoRjlnwh1ZPYGaC,url,25,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
				elif 'Program' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+IOgUp4AR1zPQXtaSL0De83uibns,url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def h0WevrZX7bAixDyfGBu64kOaqQRVsH(url):
	qmkfr0ROtxc = jKu3YTmEe8h9yO1Hzftd6N5Is(url)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-MUSIC_MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('Music-tools-header(.*?)Music-body',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	title = ScntgdOZCY74vNpXeW5jh8i.findall('<p>(.*?)</p>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)[0]
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = qmkfr0ROtxc + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,23,nbOFVEDkpT4BIR7Qq82yPmHeJU,'101')
	return
def IGDobAKtj4kPF5V(url,ohpwd6UumaecE3IWV8lAv0):
	qmkfr0ROtxc = jKu3YTmEe8h9yO1Hzftd6N5Is(url)
	v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(url)
	type = url.split('/')[-1]
	J28Jix67oCtgTqUZehj4fcpB = str(int(ohpwd6UumaecE3IWV8lAv0)//100)
	ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)%100)
	if type=='Series' and ohpwd6UumaecE3IWV8lAv0=='0':
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-TITLES-1st')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('serial-body(.*?)class="row',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src=(.*?)>.*?h3>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			title = dCtxzeFX4GJVonm(title)
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = qmkfr0ROtxc + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			X79kphTKa1xLP = qmkfr0ROtxc + lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,23,X79kphTKa1xLP,J28Jix67oCtgTqUZehj4fcpB+'01')
	Nct612JRyeKvnW=0
	if type=='Series': jGdXt7eADorwlv8pahNV95H6Tn2qKx='3'
	if type=='Film': jGdXt7eADorwlv8pahNV95H6Tn2qKx='5'
	if type=='Program': jGdXt7eADorwlv8pahNV95H6Tn2qKx='7'
	if type in ['Series','Program','Film'] and ohpwd6UumaecE3IWV8lAv0!='0':
		plSscrVjkRviPwm = qmkfr0ROtxc+'/Home/PageingItem?category='+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'&page='+ohpwd6UumaecE3IWV8lAv0+'&size=30&orderby='+J28Jix67oCtgTqUZehj4fcpB
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-TITLES-2nd')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('"Id":(.*?),"Title":(.*?),.+?"ImageAddress_S":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for id,title,X79kphTKa1xLP in items:
			title = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(title)
			title = title.replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			title = title.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
			Nct612JRyeKvnW += 1
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = qmkfr0ROtxc + '/' + type + '/Content/' + id
			X79kphTKa1xLP = qmkfr0ROtxc + lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
			if type=='Film': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,24,X79kphTKa1xLP,J28Jix67oCtgTqUZehj4fcpB+'01')
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,23,X79kphTKa1xLP,J28Jix67oCtgTqUZehj4fcpB+'01')
	if type=='Music':
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,qmkfr0ROtxc+'/Music/Index?page='+ohpwd6UumaecE3IWV8lAv0,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-TITLES-3rd')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('pagination-demo(.*?)pagination-demo',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?<h3>(.*?)</h3>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
			Nct612JRyeKvnW += 1
			X79kphTKa1xLP = qmkfr0ROtxc + X79kphTKa1xLP
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = qmkfr0ROtxc + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,23,X79kphTKa1xLP,'101')
	if Nct612JRyeKvnW>20:
		title='صفحة '
		if v7vZOgAQb30LNJljTKuS8Czc16=='en': title = 'Page '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa': title = 'صفحه '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa2': title = 'صفحه '
		for nhEPv1MDkF in range(1,11) :
			if not ohpwd6UumaecE3IWV8lAv0==str(nhEPv1MDkF):
				hmbr4tCsaZ1vYWGyTHxQMJ = '0'+str(nhEPv1MDkF)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title+str(nhEPv1MDkF),url,22,nbOFVEDkpT4BIR7Qq82yPmHeJU,J28Jix67oCtgTqUZehj4fcpB+hmbr4tCsaZ1vYWGyTHxQMJ[-2:])
	return
def PXyn8J3WjhRgA(url,ohpwd6UumaecE3IWV8lAv0):
	if not ohpwd6UumaecE3IWV8lAv0: ohpwd6UumaecE3IWV8lAv0 = 0
	qmkfr0ROtxc = jKu3YTmEe8h9yO1Hzftd6N5Is(url)
	bHoRBqDl31pavfGw = jKu3YTmEe8h9yO1Hzftd6N5Is(url)
	v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(url)
	LCjugSrWIBPDyFb4X1o9fAM = url.split('/')
	id,type = LCjugSrWIBPDyFb4X1o9fAM[-1],LCjugSrWIBPDyFb4X1o9fAM[3]
	J28Jix67oCtgTqUZehj4fcpB = str(int(ohpwd6UumaecE3IWV8lAv0)//100)
	ohpwd6UumaecE3IWV8lAv0 = str(int(ohpwd6UumaecE3IWV8lAv0)%100)
	Nct612JRyeKvnW = 0
	if type=='Series':
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-EPISODES-1st')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('Comment_panel_Item.*?p>(.*?)<i.+?var inter_ = (.*?);.*?src="(.*?)\'.*?data-url="(.*?)\'',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		title = ' - الحلقة '
		if v7vZOgAQb30LNJljTKuS8Czc16=='en': title = ' - Episode '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa': title = ' - قسمت '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa2': title = ' - قسمت '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa': GkTumDNO8FSInxo6K95L4t0 = nbOFVEDkpT4BIR7Qq82yPmHeJU
		else: GkTumDNO8FSInxo6K95L4t0 = v7vZOgAQb30LNJljTKuS8Czc16
		F0y5MDg9jxI = ScntgdOZCY74vNpXeW5jh8i.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for name,count,X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
			for BBuqr7CwzEIi9UL54n0AVoHXPlp in range(int(count),0,-1):
				MlGU649YAoysF3TWJfp857xL0CSO = X79kphTKa1xLP + GkTumDNO8FSInxo6K95L4t0 + id + '/' + str(BBuqr7CwzEIi9UL54n0AVoHXPlp) + '.png'
				Y3Df741wvGOihEHF = name + title + str(BBuqr7CwzEIi9UL54n0AVoHXPlp)
				Y3Df741wvGOihEHF = dCtxzeFX4GJVonm(Y3Df741wvGOihEHF)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Y3Df741wvGOihEHF,url,24,MlGU649YAoysF3TWJfp857xL0CSO,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(BBuqr7CwzEIi9UL54n0AVoHXPlp))
	elif type=='Program':
		plSscrVjkRviPwm = qmkfr0ROtxc+'/Home/PageingAttachmentItem?id='+str(id)+'&page='+ohpwd6UumaecE3IWV8lAv0+'&size=30&orderby=1'
		UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-EPISODES-2nd')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('Episode":(.*?),.*?ImageAddress_S":"(.*?)".*?VideoAddress":"(.*?)".*?Discription":"(.*?)".*?Caption":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		title = ' - الحلقة '
		if v7vZOgAQb30LNJljTKuS8Czc16=='en': title = ' - Episode '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa': title = ' - قسمت '
		if v7vZOgAQb30LNJljTKuS8Czc16=='fa2': title = ' - قسمت '
		for BBuqr7CwzEIi9UL54n0AVoHXPlp,X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,muFtRn6PxlZ8rXMakU41ec2vgN,name in items:
			Nct612JRyeKvnW += 1
			MlGU649YAoysF3TWJfp857xL0CSO = bHoRBqDl31pavfGw + lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
			name = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(name)
			Y3Df741wvGOihEHF = name + title + str(BBuqr7CwzEIi9UL54n0AVoHXPlp)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Y3Df741wvGOihEHF,plSscrVjkRviPwm,24,MlGU649YAoysF3TWJfp857xL0CSO,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(Nct612JRyeKvnW))
	elif type=='Music':
		if 'Content' in url and 'category' not in url:
			plSscrVjkRviPwm = qmkfr0ROtxc+'/Music/GetTracksBy?id='+str(id)+'&page='+ohpwd6UumaecE3IWV8lAv0+'&size=30&type=0'
			UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-EPISODES-3rd')
			items = ScntgdOZCY74vNpXeW5jh8i.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name,title in items:
				Nct612JRyeKvnW += 1
				MlGU649YAoysF3TWJfp857xL0CSO = bHoRBqDl31pavfGw + lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
				Y3Df741wvGOihEHF = name + ' - ' + title
				Y3Df741wvGOihEHF = Y3Df741wvGOihEHF.strip(S3X6GcaiExOPtb)
				Y3Df741wvGOihEHF = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(Y3Df741wvGOihEHF)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Y3Df741wvGOihEHF,plSscrVjkRviPwm,24,MlGU649YAoysF3TWJfp857xL0CSO,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(Nct612JRyeKvnW))
		elif 'Clips' in url:
			plSscrVjkRviPwm = qmkfr0ROtxc+'/Music/GetTracksBy?id=0&page='+ohpwd6UumaecE3IWV8lAv0+'&size=30&type=15'
			UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-EPISODES-4th')
			items = ScntgdOZCY74vNpXeW5jh8i.findall('ImageAddress_S":"(.*?)".*?Caption":"(.*?)".*?VideoAddress":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for X79kphTKa1xLP,title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
				Nct612JRyeKvnW += 1
				MlGU649YAoysF3TWJfp857xL0CSO = bHoRBqDl31pavfGw + lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
				Y3Df741wvGOihEHF = title.strip(S3X6GcaiExOPtb)
				Y3Df741wvGOihEHF = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(Y3Df741wvGOihEHF)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Y3Df741wvGOihEHF,plSscrVjkRviPwm,24,MlGU649YAoysF3TWJfp857xL0CSO,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(Nct612JRyeKvnW))
		elif 'category' in url:
			if 'category=6' in url:
				plSscrVjkRviPwm = qmkfr0ROtxc+'/Music/GetTracksBy?id=0&page='+ohpwd6UumaecE3IWV8lAv0+'&size=30&type=6'
				UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-EPISODES-5th')
			elif 'category=4' in url:
				plSscrVjkRviPwm = qmkfr0ROtxc+'/Music/GetTracksBy?id=0&page='+ohpwd6UumaecE3IWV8lAv0+'&size=30&type=4'
				UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-EPISODES-6th')
			items = ScntgdOZCY74vNpXeW5jh8i.findall('ImageAddress_S":"(.*?)".*?VoiceAddress":"(.*?)".*?Caption":"(.*?)","Title":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name,title in items:
				Nct612JRyeKvnW += 1
				MlGU649YAoysF3TWJfp857xL0CSO = bHoRBqDl31pavfGw + lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
				Y3Df741wvGOihEHF = name + ' - ' + title
				Y3Df741wvGOihEHF = Y3Df741wvGOihEHF.strip(S3X6GcaiExOPtb)
				Y3Df741wvGOihEHF = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(Y3Df741wvGOihEHF)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+Y3Df741wvGOihEHF,plSscrVjkRviPwm,24,MlGU649YAoysF3TWJfp857xL0CSO,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(Nct612JRyeKvnW))
	if type=='Music' or type=='Program':
		if Nct612JRyeKvnW>25:
			title='صفحة '
			if v7vZOgAQb30LNJljTKuS8Czc16=='en': title = ' Page '
			if v7vZOgAQb30LNJljTKuS8Czc16=='fa': title = ' صفحه '
			if v7vZOgAQb30LNJljTKuS8Czc16=='fa2': title = ' صفحه '
			for nhEPv1MDkF in range(1,11):
				if not ohpwd6UumaecE3IWV8lAv0==str(nhEPv1MDkF):
					hmbr4tCsaZ1vYWGyTHxQMJ = '0'+str(nhEPv1MDkF)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title+str(nhEPv1MDkF),url,23,nbOFVEDkpT4BIR7Qq82yPmHeJU,J28Jix67oCtgTqUZehj4fcpB+hmbr4tCsaZ1vYWGyTHxQMJ[-2:])
	return
def AOk1T6KwciHrWU2MYJzZnEN(url,BBuqr7CwzEIi9UL54n0AVoHXPlp):
	bHoRBqDl31pavfGw = jKu3YTmEe8h9yO1Hzftd6N5Is(url)
	bbKoeBcirVfzwAqZdQUFDSX,lPpY5fw3tOBcEye91Caun2FQZ = [],[]
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-PLAY-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-video="(.*?)(\'.*?\'_)(.*?)">',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(url)
		LCjugSrWIBPDyFb4X1o9fAM = url.split('/')
		id,type = LCjugSrWIBPDyFb4X1o9fAM[-1],LCjugSrWIBPDyFb4X1o9fAM[3]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[0][0]+v7vZOgAQb30LNJljTKuS8Czc16+id+'/,'+BBuqr7CwzEIi9UL54n0AVoHXPlp+','+BBuqr7CwzEIi9UL54n0AVoHXPlp+'_'+items[0][2]
		bbKoeBcirVfzwAqZdQUFDSX.append('m3u8')
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('data-url="(http.*?)(\'.*?\')(\..*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(url)
		LCjugSrWIBPDyFb4X1o9fAM = url.split('/')
		id,type = LCjugSrWIBPDyFb4X1o9fAM[-1],LCjugSrWIBPDyFb4X1o9fAM[3]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[0][0]+v7vZOgAQb30LNJljTKuS8Czc16+id+'/'+BBuqr7CwzEIi9UL54n0AVoHXPlp+items[0][2]
		bbKoeBcirVfzwAqZdQUFDSX.append('mp4 url')
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.replace('//','/')
		bbKoeBcirVfzwAqZdQUFDSX.append('mp4 src')
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('VideoAddress":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[int(BBuqr7CwzEIi9UL54n0AVoHXPlp)-1]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = bHoRBqDl31pavfGw+lcxFAteLQ1Pwu45Er2(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		bbKoeBcirVfzwAqZdQUFDSX.append('mp4 address')
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('VoiceAddress":"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = items[int(BBuqr7CwzEIi9UL54n0AVoHXPlp)-1]
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = bHoRBqDl31pavfGw+lcxFAteLQ1Pwu45Er2(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		bbKoeBcirVfzwAqZdQUFDSX.append('mp3 address')
		lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if len(lPpY5fw3tOBcEye91Caun2FQZ)==1: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = lPpY5fw3tOBcEye91Caun2FQZ[0]
	else:
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الفيديو المناسب:', bbKoeBcirVfzwAqZdQUFDSX)
		if bCiGxXzDkH == -1 : return
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = lPpY5fw3tOBcEye91Caun2FQZ[bCiGxXzDkH]
	brh5aWRxQzn6YL8UDNOyK9SFGo(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,QSJFrwB3dMiyH2mTPKD9a,'video')
	return
def jKu3YTmEe8h9yO1Hzftd6N5Is(url):
	if zKREXyTHfVSNL8ZFYs in url: HMPtOcVoJiXCu8z0nesDWYkIl9ER = zKREXyTHfVSNL8ZFYs
	elif C07t1e38mH2LEMzny4vX9riOblaBF in url: HMPtOcVoJiXCu8z0nesDWYkIl9ER = C07t1e38mH2LEMzny4vX9riOblaBF
	elif wjWfPaeBKlAs0 in url: HMPtOcVoJiXCu8z0nesDWYkIl9ER = wjWfPaeBKlAs0
	elif U5JYWlngLrotq7XahZs4Gd in url: HMPtOcVoJiXCu8z0nesDWYkIl9ER = U5JYWlngLrotq7XahZs4Gd
	else: HMPtOcVoJiXCu8z0nesDWYkIl9ER = nbOFVEDkpT4BIR7Qq82yPmHeJU
	return HMPtOcVoJiXCu8z0nesDWYkIl9ER
def jFqKYCy7R5VvMkZOnwm(url):
	if   zKREXyTHfVSNL8ZFYs in url: v7vZOgAQb30LNJljTKuS8Czc16 = 'ar'
	elif C07t1e38mH2LEMzny4vX9riOblaBF in url: v7vZOgAQb30LNJljTKuS8Czc16 = 'en'
	elif wjWfPaeBKlAs0 in url: v7vZOgAQb30LNJljTKuS8Czc16 = 'fa'
	elif U5JYWlngLrotq7XahZs4Gd in url: v7vZOgAQb30LNJljTKuS8Czc16 = 'fa2'
	else: v7vZOgAQb30LNJljTKuS8Czc16 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	return v7vZOgAQb30LNJljTKuS8Czc16
def dsFVer3DMTj2iQANyPmvkYU7(url):
	v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(url)
	plSscrVjkRviPwm = url + '/Home/Live'
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-LIVE-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	items = ScntgdOZCY74vNpXeW5jh8i.findall('source src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	zb2QIaL7Y4h9g8lSck = items[0]
	brh5aWRxQzn6YL8UDNOyK9SFGo(zb2QIaL7Y4h9g8lSck,QSJFrwB3dMiyH2mTPKD9a,'live')
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
	T871qPZzS4LkoMBa3Db9Q = search.replace(S3X6GcaiExOPtb,'+')
	if showDialogs:
		YVJIBXijPLpFstGk1awgfdlZhcNyK = [ zKREXyTHfVSNL8ZFYs , C07t1e38mH2LEMzny4vX9riOblaBF , wjWfPaeBKlAs0 , U5JYWlngLrotq7XahZs4Gd ]
		QNscCWpA4EubS = [ 'عربي' , 'English' , 'فارسى' , 'فارسى 2' ]
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر اللغة المناسبة:', QNscCWpA4EubS)
		if bCiGxXzDkH == -1 : return
		website = YVJIBXijPLpFstGk1awgfdlZhcNyK[bCiGxXzDkH]
	else:
		if '_IFILM-ARABIC_' in YE1hqa60dGTRDZ8NVBM: website = zKREXyTHfVSNL8ZFYs
		elif '_IFILM-ENGLISH_' in YE1hqa60dGTRDZ8NVBM: website = C07t1e38mH2LEMzny4vX9riOblaBF
		else: website = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if not website: return
	v7vZOgAQb30LNJljTKuS8Czc16 = jFqKYCy7R5VvMkZOnwm(website)
	plSscrVjkRviPwm = website + "/Home/Search?searchstring=" + T871qPZzS4LkoMBa3Db9Q
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(RRYx6sACloVPr3td95Ej,plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'IFILM-SEARCH-1st')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('"ImageAddress_S":"(.*?)".*?"CategoryId":(.*?),"Id":(.*?),"Title":"(.*?)",',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if items:
		for X79kphTKa1xLP,jGdXt7eADorwlv8pahNV95H6Tn2qKx,id,title in items:
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx in ['3','7']:
				title = title.replace('\\',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				title = title.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				if jGdXt7eADorwlv8pahNV95H6Tn2qKx=='3':
					type = 'Series'
					if v7vZOgAQb30LNJljTKuS8Czc16=='ar': name = 'مسلسل : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='en': name = 'Series : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='fa': name = 'سريال ها : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='fa2': name = 'سريال ها : '
				elif jGdXt7eADorwlv8pahNV95H6Tn2qKx=='5':
					type = 'Film'
					if v7vZOgAQb30LNJljTKuS8Czc16=='ar': name = 'فيلم : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='en': name = 'Movie : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='fa': name = 'فيلم : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='fa2': name = 'فلم ها : '
				elif jGdXt7eADorwlv8pahNV95H6Tn2qKx=='7':
					type = 'Program'
					if v7vZOgAQb30LNJljTKuS8Czc16=='ar': name = 'برنامج : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='en': name = 'Program : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='fa': name = 'برنامه ها : '
					elif v7vZOgAQb30LNJljTKuS8Czc16=='fa2': name = 'برنامه ها : '
				title = name + title
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = website + '/' + type + '/Content/' + id
				X79kphTKa1xLP = lcxFAteLQ1Pwu45Er2(X79kphTKa1xLP)
				X79kphTKa1xLP = website+X79kphTKa1xLP
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,23,X79kphTKa1xLP,'101')
	return
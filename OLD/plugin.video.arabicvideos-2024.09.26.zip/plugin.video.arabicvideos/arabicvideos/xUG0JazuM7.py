# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'GOOGLESEARCH'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_GOS_'
def n1zxUlcAgR(EYMmnJAyxV,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg):
	if   EYMmnJAyxV==1010: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif EYMmnJAyxV==1011: bPFto2wZdNYrClgBIEv60DJAzu = VV6mrA0tSLc48pblsH(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==1012: bPFto2wZdNYrClgBIEv60DJAzu = cleHsx8EF61a0OzG2dIRZBuYK3XP9(wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==1013: bPFto2wZdNYrClgBIEv60DJAzu = A9vlaj5oR0YXTJuFIyEBV()
	elif EYMmnJAyxV==1014: bPFto2wZdNYrClgBIEv60DJAzu = i9eb2apZj8JYBDTnmQ(wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==1015: bPFto2wZdNYrClgBIEv60DJAzu = o3rLl0nM8dTYE1yqt7mI2GhsH(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==1016: bPFto2wZdNYrClgBIEv60DJAzu = MIouCk6vzpSxwQ150B(J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==1018: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(J1rvN7I8eLXuS54mZ6lnUjg,-rXKp4uqLMW3v)
	elif EYMmnJAyxV==1019: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(J1rvN7I8eLXuS54mZ6lnUjg)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','بحث جوجل جديد',nbOFVEDkpT4BIR7Qq82yPmHeJU,1019)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','كيف يعمل بحث جوجل','',1013)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'==== كلمات البحث المخزنة ===='+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	WW1Gr4pauClz = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if WW1Gr4pauClz:
		WW1Gr4pauClz = WW1Gr4pauClz['__SEQUENCED_COLUMNS__']
		for B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ in reversed(WW1Gr4pauClz):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,nbOFVEDkpT4BIR7Qq82yPmHeJU,1019,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search,ww6WCqZx5lMsmejY3nLPN8QpX0SItv=rXKp4uqLMW3v):
	if not search:
		search = dR75Vq2gprfHmUcNhG()
		if not search: return
		search = search.lower()
	KYPwjRcdHJ0 = search.replace(TbufdXZL9Ml72WmGcpQ5FAgBYKqa,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	MGvJcUlHLtwyA = []
	if ww6WCqZx5lMsmejY3nLPN8QpX0SItv>0: MGvJcUlHLtwyA = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GOOGLESEARCH_RESULTS',KYPwjRcdHJ0)
	if not MGvJcUlHLtwyA or ww6WCqZx5lMsmejY3nLPN8QpX0SItv<0:
		viyf6ZdzgucTxj1HXUnVMo2hwa8F = o6rSM5bDY3sHjkz7eqURnf9(search,ww6WCqZx5lMsmejY3nLPN8QpX0SItv)
		uLdJvjq0tBNAkHOTbPizro9EnKl,rM0sZzc8WwHoPtFOV = [],[]
		for xB2lOZNsPvFQDC4gMz in viyf6ZdzgucTxj1HXUnVMo2hwa8F:
			name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER = xB2lOZNsPvFQDC4gMz
			if name==HMPtOcVoJiXCu8z0nesDWYkIl9ER: rM0sZzc8WwHoPtFOV.append(xB2lOZNsPvFQDC4gMz)
			else: uLdJvjq0tBNAkHOTbPizro9EnKl.append(xB2lOZNsPvFQDC4gMz)
		import H2VSdwTvpr
		if ww6WCqZx5lMsmejY3nLPN8QpX0SItv>=0: H2VSdwTvpr.kXdKqMmtEf2bcZPi(KYPwjRcdHJ0,'_GOOGLE',True)
		z0ht1Nk9DRHx7PAan(SOEM49TbV0zuQ,'GOOGLESEARCH_RESULTS',KYPwjRcdHJ0,[uLdJvjq0tBNAkHOTbPizro9EnKl,rM0sZzc8WwHoPtFOV],rXKp4uqLMW3v)
		if ww6WCqZx5lMsmejY3nLPN8QpX0SItv<0:
			uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_DETAILED_GOOGLE',KYPwjRcdHJ0)
			H2VSdwTvpr.kXdKqMmtEf2bcZPi(KYPwjRcdHJ0,'_GOOGLE',False)
			uoxvtFlSXEPnf(SOEM49TbV0zuQ,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+KYPwjRcdHJ0+"')")
			aY7RFmnWc5uU9T3Q0Mxq4('','','رسالة من المبرمج','تم عمل بحث جوجل جديد')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','بحث منفرد لمواقع جوجل',nbOFVEDkpT4BIR7Qq82yPmHeJU,1011,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','نتائج البحث مفصلة - '+KYPwjRcdHJ0,'opened_sites_google',1012,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','نتائج البحث مقسمة - '+KYPwjRcdHJ0,'listed_sites_google',1012,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder','مواقع جوجل - '+KYPwjRcdHJ0,'',1016,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','إعادة بحث جوجل - '+KYPwjRcdHJ0,'',1018,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,KYPwjRcdHJ0)
	return
def MIouCk6vzpSxwQ150B(KYPwjRcdHJ0):
	uLdJvjq0tBNAkHOTbPizro9EnKl,rM0sZzc8WwHoPtFOV = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GOOGLESEARCH_RESULTS',KYPwjRcdHJ0)
	uLdJvjq0tBNAkHOTbPizro9EnKl = sorted(uLdJvjq0tBNAkHOTbPizro9EnKl,reverse=SmbNGskjMx,key=lambda key: key[f4fTutDOEwUeIoPLRQ])
	MGvJcUlHLtwyA = {}
	for name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER in uLdJvjq0tBNAkHOTbPizro9EnKl: MGvJcUlHLtwyA[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER
	UUAmxeZhpHJFELQ21t = list(MGvJcUlHLtwyA.keys())
	import H2VSdwTvpr
	UOdI3NWsq7Z = H2VSdwTvpr.krz9nKbhoxfVJc(UUAmxeZhpHJFELQ21t)
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER in UOdI3NWsq7Z:
		if 'tuple' in str(type(HMPtOcVoJiXCu8z0nesDWYkIl9ER)):
			LvJuOzMqk6WlP971eoGpUQ8.append(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			continue
		name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER = MGvJcUlHLtwyA[HMPtOcVoJiXCu8z0nesDWYkIl9ER]
		UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',fxUgL78lj13rQ4W6wZOE+name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1014,Sr94NI8BKclw7AxoDLy2X,'',HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+'مواقع بجوجل غير موجودة بالبرنامج'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,1015)
	rM0sZzc8WwHoPtFOV = sorted(rM0sZzc8WwHoPtFOV,reverse=SmbNGskjMx,key=lambda key: key[f4fTutDOEwUeIoPLRQ])
	for name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER in rM0sZzc8WwHoPtFOV:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link','_GOS_'+eMypvI8XqHjYU02anWD9gsSrkt+name+S3X6GcaiExOPtb+c7gxFyUCGm,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1015,Sr94NI8BKclw7AxoDLy2X,'',HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	return
def cleHsx8EF61a0OzG2dIRZBuYK3XP9(EYsUAzvhI6FwSM9uiGm2c,KYPwjRcdHJ0):
	MGvJcUlHLtwyA = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GOOGLESEARCH_RESULTS',KYPwjRcdHJ0)
	if not MGvJcUlHLtwyA: return
	uLdJvjq0tBNAkHOTbPizro9EnKl,rM0sZzc8WwHoPtFOV = MGvJcUlHLtwyA
	gov1nGqkaLu5AB8RF69,ml26ej7FfWuXiORbEJL95k1aVDcg3t = [],{}
	for name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER in uLdJvjq0tBNAkHOTbPizro9EnKl:
		gov1nGqkaLu5AB8RF69.append(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
		ml26ej7FfWuXiORbEJL95k1aVDcg3t[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = LLyzljQvk02FDtCiNJWac18p(title)
	import H2VSdwTvpr
	H2VSdwTvpr.IvrgPGo8Be(KYPwjRcdHJ0,EYsUAzvhI6FwSM9uiGm2c,nbOFVEDkpT4BIR7Qq82yPmHeJU,gov1nGqkaLu5AB8RF69,ml26ej7FfWuXiORbEJL95k1aVDcg3t)
	return
def VV6mrA0tSLc48pblsH(search):
	MGvJcUlHLtwyA = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(SOEM49TbV0zuQ,'list','GOOGLESEARCH_RESULTS',search)
	if not MGvJcUlHLtwyA: return
	uLdJvjq0tBNAkHOTbPizro9EnKl,rM0sZzc8WwHoPtFOV = MGvJcUlHLtwyA
	uLdJvjq0tBNAkHOTbPizro9EnKl = sorted(uLdJvjq0tBNAkHOTbPizro9EnKl,reverse=SmbNGskjMx,key=lambda key: key[f4fTutDOEwUeIoPLRQ])
	MGvJcUlHLtwyA = {}
	for name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER in uLdJvjq0tBNAkHOTbPizro9EnKl:
		MGvJcUlHLtwyA[HMPtOcVoJiXCu8z0nesDWYkIl9ER] = name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER
	UUAmxeZhpHJFELQ21t = list(MGvJcUlHLtwyA.keys())
	import H2VSdwTvpr
	UOdI3NWsq7Z = H2VSdwTvpr.krz9nKbhoxfVJc(UUAmxeZhpHJFELQ21t)
	for HMPtOcVoJiXCu8z0nesDWYkIl9ER in UOdI3NWsq7Z:
		if 'tuple' in str(type(HMPtOcVoJiXCu8z0nesDWYkIl9ER)):
			LvJuOzMqk6WlP971eoGpUQ8.append(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			continue
		name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER = MGvJcUlHLtwyA[HMPtOcVoJiXCu8z0nesDWYkIl9ER]
		UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
		title = LLyzljQvk02FDtCiNJWac18p(title)
		name = name+' - '+search
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',fxUgL78lj13rQ4W6wZOE+name,HMPtOcVoJiXCu8z0nesDWYkIl9ER,548,Sr94NI8BKclw7AxoDLy2X,'',title)
	return
def LLyzljQvk02FDtCiNJWac18p(title):
	BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة)',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	HDE69mkhQg2NaFpuUy5JRb = BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0] if BBuqr7CwzEIi9UL54n0AVoHXPlp else title
	HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	HDE69mkhQg2NaFpuUy5JRb = HDE69mkhQg2NaFpuUy5JRb.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return HDE69mkhQg2NaFpuUy5JRb
def o6rSM5bDY3sHjkz7eqURnf9(search,ww6WCqZx5lMsmejY3nLPN8QpX0SItv):
	search = search.replace(S3X6GcaiExOPtb,'%20')
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&num=100&start=0&q='+search
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	cnPhVmgFxA = t57SmWGkHCXd4yq(ww6WCqZx5lMsmejY3nLPN8QpX0SItv,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'GOOGLESEARCH-SEARCH-1st')
	bKSYmN0jZ1X9rvAkGe,Q4QSdnciRl = [],[]
	if not cnPhVmgFxA.succeeded: return bKSYmN0jZ1X9rvAkGe
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	GuHeR7p5xPVW2T3A6JNSihcFLsQ = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(yi4Em23SQL9GNOBzXcshRV7wg6IUM0,'googlesearch')
	if not Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(GuHeR7p5xPVW2T3A6JNSihcFLsQ):
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.makedirs(GuHeR7p5xPVW2T3A6JNSihcFLsQ)
		except: pass
	ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for G4JHzTEp61 in ISmqngYzv6jrepWUx0l:
		G4JHzTEp61 = dr1zfnatJxRHSF48jh0eODm5bGu('list',G4JHzTEp61)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = G4JHzTEp61[17]
		title,text,name,nnu5vdh1IscOA8J = G4JHzTEp61[31][0:4]
		name = name.strip(' ')
		if not name: name = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
		name = JABPVj6TrWOU29Xvmo(name)
		if 'http://' in nnu5vdh1IscOA8J or 'https://' in nnu5vdh1IscOA8J: Sr94NI8BKclw7AxoDLy2X = nnu5vdh1IscOA8J
		elif 'data:image/' in nnu5vdh1IscOA8J and ';base64,' in nnu5vdh1IscOA8J:
			IduZfAUry2J40vC = ScntgdOZCY74vNpXeW5jh8i.findall('data:image/(\w+);base64,',nnu5vdh1IscOA8J)
			IduZfAUry2J40vC = IduZfAUry2J40vC[0]
			Sr94NI8BKclw7AxoDLy2X = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(GuHeR7p5xPVW2T3A6JNSihcFLsQ,name+'.'+IduZfAUry2J40vC)
			if not Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.exists(Sr94NI8BKclw7AxoDLy2X):
				nnu5vdh1IscOA8J = nnu5vdh1IscOA8J.replace('\\u003d','=')
				nnu5vdh1IscOA8J = nnu5vdh1IscOA8J.replace('data:image/'+IduZfAUry2J40vC+';base64,','')
				NuMkXZ7qSRpPgcLoz = Y7goyGlxwNaP1XcWU6e.b64decode(nnu5vdh1IscOA8J)
				open(Sr94NI8BKclw7AxoDLy2X,'wb').write(NuMkXZ7qSRpPgcLoz)
		else: Sr94NI8BKclw7AxoDLy2X = ''
		HMPtOcVoJiXCu8z0nesDWYkIl9ER = oQSuLmyg3BY5Eep2dDVCs(name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if HMPtOcVoJiXCu8z0nesDWYkIl9ER not in Q4QSdnciRl:
			Q4QSdnciRl.append(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			name = wKYA6dfHyq3VgrZNbG5psjBRz0kXa(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
			bKSYmN0jZ1X9rvAkGe.append([name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,text,Sr94NI8BKclw7AxoDLy2X,HMPtOcVoJiXCu8z0nesDWYkIl9ER])
	return bKSYmN0jZ1X9rvAkGe
def i9eb2apZj8JYBDTnmQ(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,HMPtOcVoJiXCu8z0nesDWYkIl9ER):
	UGqCc4PebSEBwON07ZpuF,Nwj2WURK7qbY6coiBdMDzuS,fxUgL78lj13rQ4W6wZOE = E7EJquG62gmK5QDUlH4ySw(HMPtOcVoJiXCu8z0nesDWYkIl9ER)
	if fxUgL78lj13rQ4W6wZOE: UGqCc4PebSEBwON07ZpuF()
	else: o3rLl0nM8dTYE1yqt7mI2GhsH()
	return
def A9vlaj5oR0YXTJuFIyEBV():
	aY7RFmnWc5uU9T3Q0Mxq4('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def o3rLl0nM8dTYE1yqt7mI2GhsH(HMPtOcVoJiXCu8z0nesDWYkIl9ER=''):
	aY7RFmnWc5uU9T3Q0Mxq4('','',HMPtOcVoJiXCu8z0nesDWYkIl9ER,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def oQSuLmyg3BY5Eep2dDVCs(name,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6):
	v9RGwn1rpAbOU2m3dHaS4lJB = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	,'برس3تيج'		:''
	}
	Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = name.lower()
	yi6wOauQ3Sb1JUBt4 = ''
	for key in list(v9RGwn1rpAbOU2m3dHaS4lJB.keys()):
		if key.lower() in Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y: yi6wOauQ3Sb1JUBt4 = v9RGwn1rpAbOU2m3dHaS4lJB[key]
	if not yi6wOauQ3Sb1JUBt4:
		f7Je8XzEqNpgHL9m4OURdAQ1 = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'url')
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in list(sCSyOla9hrcE.keys()):
			SYPvo97s4dl2UuJ3WpXFehDganIzkN = Qi32bRtN18qvyWmaO7YKow9cXs(sCSyOla9hrcE[HMPtOcVoJiXCu8z0nesDWYkIl9ER][0],'url')
			if f7Je8XzEqNpgHL9m4OURdAQ1==SYPvo97s4dl2UuJ3WpXFehDganIzkN: yi6wOauQ3Sb1JUBt4 = HMPtOcVoJiXCu8z0nesDWYkIl9ER
	if not yi6wOauQ3Sb1JUBt4:
		Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
		for HMPtOcVoJiXCu8z0nesDWYkIl9ER in list(sCSyOla9hrcE.keys()):
			o3oe5HBg7LUt = Qi32bRtN18qvyWmaO7YKow9cXs(sCSyOla9hrcE[HMPtOcVoJiXCu8z0nesDWYkIl9ER][0],'name')
			if Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y==o3oe5HBg7LUt: yi6wOauQ3Sb1JUBt4 = HMPtOcVoJiXCu8z0nesDWYkIl9ER
	if not yi6wOauQ3Sb1JUBt4: yi6wOauQ3Sb1JUBt4 = name
	yi6wOauQ3Sb1JUBt4 = yi6wOauQ3Sb1JUBt4.upper()
	return yi6wOauQ3Sb1JUBt4
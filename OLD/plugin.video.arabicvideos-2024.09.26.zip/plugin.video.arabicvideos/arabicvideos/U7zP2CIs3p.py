# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'FUNONTV'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_FNT_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = {'Referer':zKREXyTHfVSNL8ZFYs}
def n1zxUlcAgR(mode,url,text):
	if   mode==1070: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==1071: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==1072: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==1073: bPFto2wZdNYrClgBIEv60DJAzu = XZPY6JeohB9ODmRrgIxvuA(url,text)
	elif mode==1074: bPFto2wZdNYrClgBIEv60DJAzu = Cvflxc4FMs37bmY(url)
	elif mode==1079: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',zKREXyTHfVSNL8ZFYs,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FUNONTV-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,1079,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('''["']navslide-wrap["'](.*?)</ul>''',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</i>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
			if title in CZrI4vYju7a: continue
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1074)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('/category.php">(.*?)"navslide-divider"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('''["']dropdown-menu["'](.*?)</ul>''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for eXBMHvPbDunL in eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = G4JHzTEp61.replace(eXBMHvPbDunL,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if not title: continue
		if title in CZrI4vYju7a: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1074)
	return
def Cvflxc4FMs37bmY(url):
	mOPpf9i5VxCwq3dHhZeGnWbal8,XhE8FpdTjG = [],[]
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FUNONTV-SUBMENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"caret"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if IHV3wWCjYv4 and '.php' in str(IHV3wWCjYv4):
		G4JHzTEp61 = IHV3wWCjYv4[0]
		G4JHzTEp61 = G4JHzTEp61.replace('"presentation"','</ul>')
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not eXpgPIbRv2ZMGwjm5: eXpgPIbRv2ZMGwjm5 = [(nbOFVEDkpT4BIR7Qq82yPmHeJU,G4JHzTEp61)]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' فرز أو فلتر أو ترتيب '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		for WBVx7UzjEQPnhy0owDHtmdGgl,G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			mOPpf9i5VxCwq3dHhZeGnWbal8 = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if WBVx7UzjEQPnhy0owDHtmdGgl: WBVx7UzjEQPnhy0owDHtmdGgl = WBVx7UzjEQPnhy0owDHtmdGgl+': '
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in mOPpf9i5VxCwq3dHhZeGnWbal8:
				title = WBVx7UzjEQPnhy0owDHtmdGgl+title
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1071)
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"list-inline"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if 1 or len(XhE8FpdTjG)<30:
			if mOPpf9i5VxCwq3dHhZeGnWbal8: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG:
				if title in CZrI4vYju7a: continue
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1071,'','','series')
	if not IHV3wWCjYv4 and not b8Ior2kWzq1tc: IGDobAKtj4kPF5V(url)
	return
def IGDobAKtj4kPF5V(url,s0tfc7T2hwBM=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if s0tfc7T2hwBM=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		GcYwHSWoQ0Nq8KFfJDdvujZryM = headers.copy()
		GcYwHSWoQ0Nq8KFfJDdvujZryM['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',url,data,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FUNONTV-TITLES-1st')
	else:
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FUNONTV-TITLES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	G4JHzTEp61,items = nbOFVEDkpT4BIR7Qq82yPmHeJU,[]
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	if s0tfc7T2hwBM=='ajax-search':
		G4JHzTEp61 = UTvsQb4HpCP3Aeo2wDZG7X5V
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in XhE8FpdTjG: items.append((nbOFVEDkpT4BIR7Qq82yPmHeJU,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title))
	elif s0tfc7T2hwBM=='featured':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pm-carousel_featured"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	elif s0tfc7T2hwBM=='new_episodes':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"row pm-ul-browse-videos(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	elif s0tfc7T2hwBM=='new_movies':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"row pm-ul-browse-videos(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if len(eXpgPIbRv2ZMGwjm5)>1: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[1]
	elif s0tfc7T2hwBM=='featured_series':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pm-grid"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5: G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if G4JHzTEp61 and not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('''"thumbnail".*?<a href=["'](.*?)["'].*?title=["'](.*?)["'].*?data-echo=["'](.*?)["']''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items: return
	tWsVFQj47pw0L56rZfg = []
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
		X79kphTKa1xLP += '|Referer='+zKREXyTHfVSNL8ZFYs
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
		title = dCtxzeFX4GJVonm(title)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة).\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1072,X79kphTKa1xLP)
		elif s0tfc7T2hwBM in ['new_episodes','series']:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1072,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp:
			title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1073,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1073,X79kphTKa1xLP)
	if 1:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pagination(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6=='#': continue
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
				title = dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1071)
	return
def XZPY6JeohB9ODmRrgIxvuA(url,W58zOLpMh2ZTrcEemS70AUy):
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FUNONTV-EPISODES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	IHV3wWCjYv4 = ScntgdOZCY74vNpXeW5jh8i.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	nnu5vdh1IscOA8J = ScntgdOZCY74vNpXeW5jh8i.findall('"image" content="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	X79kphTKa1xLP = nnu5vdh1IscOA8J[0] if nnu5vdh1IscOA8J else nbOFVEDkpT4BIR7Qq82yPmHeJU
	X79kphTKa1xLP += '|Referer='+zKREXyTHfVSNL8ZFYs
	items = []
	ee9RfPxQdhHY1qbt0Om8ianC673W = False
	if IHV3wWCjYv4 and not W58zOLpMh2ZTrcEemS70AUy:
		G4JHzTEp61 = IHV3wWCjYv4[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for W58zOLpMh2ZTrcEemS70AUy,title in items:
			W58zOLpMh2ZTrcEemS70AUy = W58zOLpMh2ZTrcEemS70AUy.strip('#')
			if len(items)>1: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,1073,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,W58zOLpMh2ZTrcEemS70AUy)
			else: ee9RfPxQdhHY1qbt0Om8ianC673W = True
	else: ee9RfPxQdhHY1qbt0Om8ianC673W = True
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('id="'+W58zOLpMh2ZTrcEemS70AUy+'"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not b8Ior2kWzq1tc:
		b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('SeasonsEpisodesMain(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if b8Ior2kWzq1tc:
			G4JHzTEp61 = b8Ior2kWzq1tc[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)" title="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('./')
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1072,X79kphTKa1xLP)
	elif b8Ior2kWzq1tc and ee9RfPxQdhHY1qbt0Om8ianC673W:
		G4JHzTEp61 = b8Ior2kWzq1tc[0]
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if XhE8FpdTjG:
			LPGRaENriMYjlZX,J84JjGnvuROh = zip(*XhE8FpdTjG)
			oQmDSpdY0qHIxt1n3yJT2whE = [X79kphTKa1xLP]*len(XhE8FpdTjG)
			items = zip(J84JjGnvuROh,LPGRaENriMYjlZX,oQmDSpdY0qHIxt1n3yJT2whE)
		if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,X79kphTKa1xLP in items:
			X79kphTKa1xLP += '|Referer='+zKREXyTHfVSNL8ZFYs
			if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
			title = title.replace('</em><span>',S3X6GcaiExOPtb)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,1072,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	NWtqFg91ZSKinvIwAc,vdYMP3fDSnxzeEgXmqpcua = [],[]
	UTvsQb4HpCP3Aeo2wDZG7X5V = ''
	if 'post=' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('id="player".*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
		PSua7U3vIj9lwFpThsMHdiq2GEcV1N = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('post=')[1]
		PSua7U3vIj9lwFpThsMHdiq2GEcV1N = Y7goyGlxwNaP1XcWU6e.b64decode(PSua7U3vIj9lwFpThsMHdiq2GEcV1N)
		if IZhXMprxvAHqBEFkg0: PSua7U3vIj9lwFpThsMHdiq2GEcV1N = PSua7U3vIj9lwFpThsMHdiq2GEcV1N.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		PSua7U3vIj9lwFpThsMHdiq2GEcV1N = dr1zfnatJxRHSF48jh0eODm5bGu('dict',PSua7U3vIj9lwFpThsMHdiq2GEcV1N)
		rU02bCJFWZDfVuhtMgBOyQi5P = PSua7U3vIj9lwFpThsMHdiq2GEcV1N['servers']
		bdW70uQAIF = list(rU02bCJFWZDfVuhtMgBOyQi5P.keys())
		rU02bCJFWZDfVuhtMgBOyQi5P = list(rU02bCJFWZDfVuhtMgBOyQi5P.values())
		pgIxQdT5lkmt = zip(bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P)
		for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in pgIxQdT5lkmt:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	else:
		plSscrVjkRviPwm = url.replace('watch.php','view.php')
		plSscrVjkRviPwm,vLrxHDuiN08ba5pRlmUtMAIyfZX = plSscrVjkRviPwm.split('?vid=')
		J27qXeRCpsgkEoT9Q0GYS6ct = 'ur='+vLrxHDuiN08ba5pRlmUtMAIyfZX+'&action=0&submit=submit'
		GcYwHSWoQ0Nq8KFfJDdvujZryM = {'Content-Type':'application/x-www-form-urlencoded'}
		cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'POST',plSscrVjkRviPwm,J27qXeRCpsgkEoT9Q0GYS6ct,GcYwHSWoQ0Nq8KFfJDdvujZryM,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FUNONTV-PLAY2-1st')
		UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
		if 0:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('"embedURL" href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
				if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in vdYMP3fDSnxzeEgXmqpcua:
					vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__embed'
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if 1:
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"embeding"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if eXpgPIbRv2ZMGwjm5:
				G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
				items = ScntgdOZCY74vNpXeW5jh8i.findall('data-embed="(.*?)".*?</span>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
					if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in vdYMP3fDSnxzeEgXmqpcua: continue
					vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+title+'__watch'
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
		if 0:
			plSscrVjkRviPwm = url.replace('watch.php','downloads.php')
			cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,False,'FUNONTV-PLAY-2nd')
			UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
			eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"pm-download"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
				items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<strong>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if not items: items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<span>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
					if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in vdYMP3fDSnxzeEgXmqpcua: continue
					vdYMP3fDSnxzeEgXmqpcua.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
					RWZpkDLtY5Eyb46029MvAKmqBQd8o = Qi32bRtN18qvyWmaO7YKow9cXs(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,'name')
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'__download'
					NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(NWtqFg91ZSKinvIwAc,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	url = zKREXyTHfVSNL8ZFYs+'/search.php?keywords='+search
	IGDobAKtj4kPF5V(url,'search')
	return
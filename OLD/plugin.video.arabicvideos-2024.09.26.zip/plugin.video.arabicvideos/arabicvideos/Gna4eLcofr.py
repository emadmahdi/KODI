# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'SHIAVOICE'
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_SHV_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
headers = {'User-Agent':None}
def n1zxUlcAgR(mode,url,text):
	if   mode==310: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==311: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==312: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==313: bPFto2wZdNYrClgBIEv60DJAzu = tujaCYFZxkwiHn(url)
	elif mode==314: bPFto2wZdNYrClgBIEv60DJAzu = f0GcyVKge7(text)
	elif mode==319: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,319,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHIAVOICE-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('id="menulinks"(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<h5>(.*?)</h5>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
	for wDIU0SN9GBtzZPoihYnv2xjqQC in range(len(items)):
		title = items[wDIU0SN9GBtzZPoihYnv2xjqQC].strip(S3X6GcaiExOPtb)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zKREXyTHfVSNL8ZFYs,314,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(wDIU0SN9GBtzZPoihYnv2xjqQC+1))
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مقاطع شهر',zKREXyTHfVSNL8ZFYs,314,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'0')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<B>(.*?)</B>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,311)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def f0GcyVKge7(wDIU0SN9GBtzZPoihYnv2xjqQC):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHIAVOICE-LATEST-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	if wDIU0SN9GBtzZPoihYnv2xjqQC=='0':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="tab-content"(.*?)</table>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?title="(.*?)".*?</i>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			title = title.strip(S3X6GcaiExOPtb)
			name = name.strip(S3X6GcaiExOPtb)
			title = title+' ('+name+')'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,312)
	elif wDIU0SN9GBtzZPoihYnv2xjqQC in ['1','2','3']:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(<h5>.*?)<div class="col-lg',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		vAVo1YmHZWD3xsiTtbB5X = int(wDIU0SN9GBtzZPoihYnv2xjqQC)-1
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[vAVo1YmHZWD3xsiTtbB5X]
		if wDIU0SN9GBtzZPoihYnv2xjqQC=='1': items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?</i>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		else: items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?<strong>(.*?)<.*?href=".*?">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title,name in items:
			X79kphTKa1xLP = zKREXyTHfVSNL8ZFYs+'/'+X79kphTKa1xLP
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			title = title.strip(S3X6GcaiExOPtb)
			name = name.strip(S3X6GcaiExOPtb)
			title = title+' ('+name+')'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,311,X79kphTKa1xLP)
	elif wDIU0SN9GBtzZPoihYnv2xjqQC in ['4','5','6']:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('(<h5>.*?)</table>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		wDIU0SN9GBtzZPoihYnv2xjqQC = int(wDIU0SN9GBtzZPoihYnv2xjqQC)-4
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[wDIU0SN9GBtzZPoihYnv2xjqQC]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?href="(.*?)".*?title="(.*?)".*?<strong.*?>(.*?)</strong>.*?-cell">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,Y3Df741wvGOihEHF,title,Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y in items:
			X79kphTKa1xLP = zKREXyTHfVSNL8ZFYs+'/'+X79kphTKa1xLP
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			title = title.strip(S3X6GcaiExOPtb)
			Y3Df741wvGOihEHF = Y3Df741wvGOihEHF.strip(S3X6GcaiExOPtb)
			Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y = Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y.strip(S3X6GcaiExOPtb)
			if Y3Df741wvGOihEHF: name = Y3Df741wvGOihEHF
			else: name = Rg2cNKP4nVJxLOCUHFMwaDtA60u1Y
			title = title+' ('+name+')'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,312,X79kphTKa1xLP)
	return
def IGDobAKtj4kPF5V(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHIAVOICE-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('ibox-heading"(.*?)class="float-right',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	if 'catsum-mobile' in G4JHzTEp61:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('src="(.*?)".*?href="(.*?)".*?<strong>(.*?)</strong>.*?catsum-mobile">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if items:
			for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,count in items:
				X79kphTKa1xLP = zKREXyTHfVSNL8ZFYs+'/'+X79kphTKa1xLP
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				count = count.replace(' الصوتية: ',':')
				title = title.strip(S3X6GcaiExOPtb)
				title = title+' ('+count+')'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,311,X79kphTKa1xLP)
	else:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('" href="(.*?)".*?</i>(.*?)</a>.*?">(.*?)<.*?<span.*?<span.*?<span.*?">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,ujCfABWzdV9MrgbY0iPD63Jtw,H07WdckxAoZF1fn4LNMOTP65eEtr in items:
			if title==nbOFVEDkpT4BIR7Qq82yPmHeJU or ujCfABWzdV9MrgbY0iPD63Jtw==nbOFVEDkpT4BIR7Qq82yPmHeJU: continue
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
			title = title+' ('+H07WdckxAoZF1fn4LNMOTP65eEtr+')'
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,312)
	if not items: PXyn8J3WjhRgA(UTvsQb4HpCP3Aeo2wDZG7X5V)
	return
def PXyn8J3WjhRgA(UTvsQb4HpCP3Aeo2wDZG7X5V):
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="ibox-content"(.*?)class="pagination',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)".*?</i>(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<.*?cell">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,name,count,H07WdckxAoZF1fn4LNMOTP65eEtr in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = title.strip(S3X6GcaiExOPtb)
		name = name.strip(S3X6GcaiExOPtb)
		title = title+' ('+name+')'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,312,nbOFVEDkpT4BIR7Qq82yPmHeJU,H07WdckxAoZF1fn4LNMOTP65eEtr)
	return
def tujaCYFZxkwiHn(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHIAVOICE-SEARCH_ITEMS-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="ibox-content p-1"(.*?)class="ibox-content"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5:
		IGDobAKtj4kPF5V(url)
		return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?<strong>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/'+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = title.strip(S3X6GcaiExOPtb)
		if '/play-' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,312)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,311)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHIAVOICE-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<audio.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<video.*?src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
	brh5aWRxQzn6YL8UDNOyK9SFGo(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,QSJFrwB3dMiyH2mTPKD9a,'video')
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	aNpr5IVSxLwsRCbmWvH8P = ['&t=a','&t=c','&t=s']
	if showDialogs:
		TYZyGNCuzHAUsmaSE2V0Lk89rKh = ['قارئ','إصدار / مجلد','مقطع الصوتي']
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('موقع صوت الشيعة - أختر البحث', TYZyGNCuzHAUsmaSE2V0Lk89rKh)
		if bCiGxXzDkH == -1: return
	elif '_SHIAVOICE-PERSONS_' in YE1hqa60dGTRDZ8NVBM: bCiGxXzDkH = 0
	elif '_SHIAVOICE-ALBUMS_' in YE1hqa60dGTRDZ8NVBM: bCiGxXzDkH = 1
	elif '_SHIAVOICE-AUDIOS_' in YE1hqa60dGTRDZ8NVBM: bCiGxXzDkH = 2
	else: return
	type = aNpr5IVSxLwsRCbmWvH8P[bCiGxXzDkH]
	url = zKREXyTHfVSNL8ZFYs+'/search.php?q='+search+type
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'SHIAVOICE-SEARCH-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="ibox-content"(.*?)class="ibox-content"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		if bCiGxXzDkH in [0,1]:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?src="(.*?)".*?href=".*?">(.*?)<.*?">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title,name in items:
				title = title.strip(S3X6GcaiExOPtb)
				name = name.strip(S3X6GcaiExOPtb)
				title = title+' ('+name+')'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,313,X79kphTKa1xLP)
		elif bCiGxXzDkH==2:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)".*?</i>(.*?)</a></td><td>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,name in items:
				title = title.strip(S3X6GcaiExOPtb)
				name = name.strip(S3X6GcaiExOPtb)
				title = title+' ('+name+')'
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,312)
	return
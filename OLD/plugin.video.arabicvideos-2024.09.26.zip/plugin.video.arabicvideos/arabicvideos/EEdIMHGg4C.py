# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
VGjzYJZykfEWxlQLeap = 'M3U'
PPZDQo6RAG3a0Ot1Ydc5Fwz = '_M3U_'
GUf84z2bdKlc7PpywoNrDVg = [
		 'IGNORED'
		,'LIVE_UNKNOWN_GROUPED','LIVE_UNKNOWN_GROUPED_SORTED'
		,'VOD_UNKNOWN_GROUPED','VOD_UNKNOWN_GROUPED_SORTED'
		,'LIVE_GROUPED','LIVE_GROUPED_SORTED'
		,'LIVE_ORIGINAL_GROUPED','LIVE_FROM_GROUP_SORTED','LIVE_FROM_NAME_SORTED'
		,'VOD_MOVIES_GROUPED','VOD_MOVIES_GROUPED_SORTED'
		,'VOD_SERIES_GROUPED','VOD_SERIES_GROUPED_SORTED'
		,'VOD_ORIGINAL_GROUPED','VOD_FROM_GROUP_SORTED','VOD_FROM_NAME_SORTED'
		]
s9uG4cZBdagX1SF5q2P = 4
def z4CledbofIyhpZVjugFO(EYMmnJAyxV,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,iiyAEbQ5f80,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c,RmjbIZdCFEMzkDNHaAqe7hoSBO5lL):
	global PPZDQo6RAG3a0Ot1Ydc5Fwz
	try:
		gYJAT1vW0Uqm76G = str(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL['folder'])
		PPZDQo6RAG3a0Ot1Ydc5Fwz = '_MU'+gYJAT1vW0Uqm76G+'_'
	except: gYJAT1vW0Uqm76G = nbOFVEDkpT4BIR7Qq82yPmHeJU
	try: atKPpEV8Oi7bxMq5FoYGe = str(RmjbIZdCFEMzkDNHaAqe7hoSBO5lL['sequence'])
	except: atKPpEV8Oi7bxMq5FoYGe = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if   EYMmnJAyxV==710: UmwA0cdOSg2s7vnKR8zYp4ohWqH = K8dEcSDisO2zXLVl39CTRU1()
	elif EYMmnJAyxV==711: UmwA0cdOSg2s7vnKR8zYp4ohWqH = E0PNDIAiaYkKRpx(gYJAT1vW0Uqm76G,atKPpEV8Oi7bxMq5FoYGe)
	elif EYMmnJAyxV==712: UmwA0cdOSg2s7vnKR8zYp4ohWqH = CvZgpnA1PF2YS9JeN6(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==713: UmwA0cdOSg2s7vnKR8zYp4ohWqH = ITqsrkfZpxUMCWVYKi9Qy(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	elif EYMmnJAyxV==714: UmwA0cdOSg2s7vnKR8zYp4ohWqH = KwinXTzJv1N8yghA9UbI0HueGqa7R(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	elif EYMmnJAyxV==715: UmwA0cdOSg2s7vnKR8zYp4ohWqH = AOk1T6KwciHrWU2MYJzZnEN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,iiyAEbQ5f80)
	elif EYMmnJAyxV==716: UmwA0cdOSg2s7vnKR8zYp4ohWqH = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,True)
	elif EYMmnJAyxV==717: UmwA0cdOSg2s7vnKR8zYp4ohWqH = CSLw0gKhVD(gYJAT1vW0Uqm76G,True)
	elif EYMmnJAyxV==718: UmwA0cdOSg2s7vnKR8zYp4ohWqH = kC4fo85D9AW6EPIKi1LyTugdN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,J1rvN7I8eLXuS54mZ6lnUjg)
	elif EYMmnJAyxV==719: UmwA0cdOSg2s7vnKR8zYp4ohWqH = CCLlhnQdcKiA(J1rvN7I8eLXuS54mZ6lnUjg,gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	elif EYMmnJAyxV==720: UmwA0cdOSg2s7vnKR8zYp4ohWqH = hraw5mCZRvLQxX1iH(gYJAT1vW0Uqm76G,True)
	elif EYMmnJAyxV==721: UmwA0cdOSg2s7vnKR8zYp4ohWqH = EvN7ufpcI6VkKLRWBaQnbH0rtw91(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==722: UmwA0cdOSg2s7vnKR8zYp4ohWqH = xu91PRNQyqg7DTMUrOXphEYB6(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==723: UmwA0cdOSg2s7vnKR8zYp4ohWqH = ZHuG4LETX5jcK1tBgbzehNxUakFq(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==726: UmwA0cdOSg2s7vnKR8zYp4ohWqH = sAkcixqeBNVbZIPdSo(gYJAT1vW0Uqm76G)
	elif EYMmnJAyxV==729: UmwA0cdOSg2s7vnKR8zYp4ohWqH = Cndl86Apt9owz(J1rvN7I8eLXuS54mZ6lnUjg,gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)
	else: UmwA0cdOSg2s7vnKR8zYp4ohWqH = False
	return UmwA0cdOSg2s7vnKR8zYp4ohWqH
def K8dEcSDisO2zXLVl39CTRU1():
	for gYJAT1vW0Uqm76G in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
		PPZDQo6RAG3a0Ot1Ydc5Fwz = '_MU'+str(gYJAT1vW0Uqm76G)+'_'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قائمة مجلد '+rto0iz1Gk2xAmICHDhqR6FPnMK[gYJAT1vW0Uqm76G],nbOFVEDkpT4BIR7Qq82yPmHeJU,720,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	return
def hraw5mCZRvLQxX1iH(gYJAT1vW0Uqm76G=nbOFVEDkpT4BIR7Qq82yPmHeJU,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if gYJAT1vW0Uqm76G:
		c4sHM5DbmLC = {'folder':gYJAT1vW0Uqm76G}
		DnWF2omGyk4EpQP81q9uviZs = nbOFVEDkpT4BIR7Qq82yPmHeJU
	else:
		c4sHM5DbmLC = nbOFVEDkpT4BIR7Qq82yPmHeJU
		DnWF2omGyk4EpQP81q9uviZs = nbOFVEDkpT4BIR7Qq82yPmHeJU
	ayOS4QxTbDtLclVeJFpA3XohK1m76W = a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep)
	if not ayOS4QxTbDtLclVeJFpA3XohK1m76W:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+l5JG7XwbOfo8DznU+' إضافة وتغيير رابط'+DnWF2omGyk4EpQP81q9uviZs+S3X6GcaiExOPtb+rto0iz1Gk2xAmICHDhqR6FPnMK[1]+' '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,711,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G,'sequence':1})
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+l5JG7XwbOfo8DznU+' جلب ملفات'+DnWF2omGyk4EpQP81q9uviZs+' '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,712,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	else:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'بحث في الملفات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,729,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_',nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_GROUPED_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة من القسم'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_FROM_GROUP_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة من الاسم'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_FROM_NAME_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مصنفة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_GROUPED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_ORIGINAL_GROUPED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مجهولة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_UNKNOWN_GROUPED_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'قنوات مجهولة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'LIVE_UNKNOWN_GROUPED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'VOD_ORIGINAL_GROUPED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مصنفة القسم'+DnWF2omGyk4EpQP81q9uviZs,'VOD_FROM_GROUP_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مصنفة من الاسم'+DnWF2omGyk4EpQP81q9uviZs,'VOD_FROM_NAME_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مجهولة بلا ترتيب'+DnWF2omGyk4EpQP81q9uviZs,'VOD_UNKNOWN_GROUPED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'فيديوهات مجهولة مرتبة'+DnWF2omGyk4EpQP81q9uviZs,'VOD_UNKNOWN_GROUPED_SORTED',713,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	for UUfw8Ld24pDl5xbHRhe in range(1,s9uG4cZBdagX1SF5q2P+1):
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'إضافة وتغيير رابط'+DnWF2omGyk4EpQP81q9uviZs+S3X6GcaiExOPtb+rto0iz1Gk2xAmICHDhqR6FPnMK[UUfw8Ld24pDl5xbHRhe],nbOFVEDkpT4BIR7Qq82yPmHeJU,711,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G,'sequence':UUfw8Ld24pDl5xbHRhe})
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'جلب ملفات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,712,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'مسح ملفات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,717,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'عدد فيديوهات'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,721,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'Referer تغيير'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,726,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+'User-Agent تغيير'+DnWF2omGyk4EpQP81q9uviZs,nbOFVEDkpT4BIR7Qq82yPmHeJU,723,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,c4sHM5DbmLC)
	return
def YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	yyThwHJRP2SI1Y0knGEdAzZMDcLo,ceHxw7y6CKdv39X0N1Gr = False,nbOFVEDkpT4BIR7Qq82yPmHeJU
	VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G)
	if BarI1m9u06gVdhyCjGYWXbUv==nbOFVEDkpT4BIR7Qq82yPmHeJU: return False,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	YeRr5GFOCqn9ufVy = Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G)
	if fPY3NmaF1d0W2b:
		BTxl2eLIqSzUk = t57SmWGkHCXd4yq(zDoPOYNsJg2id1HLnx5bpf,'GET',fPY3NmaF1d0W2b,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,False,nbOFVEDkpT4BIR7Qq82yPmHeJU,'M3U-CHECK_ACCOUNT-1st')
		oHQzKutsWeALwSEXc8a = BTxl2eLIqSzUk.content
		if BTxl2eLIqSzUk.succeeded:
			a601NOifzA8ye43JnCFwqxYmWSv,ppd79g2rKSQnOLY,E1xw7TApYqVS,veHW9rfmONgzc67AjlyDYdno83E,DF4i2jqhc1YHn3rPKzS6UxwLGo = 0,0,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
			try:
				wa6j19u4KBdp = dr1zfnatJxRHSF48jh0eODm5bGu('dict',oHQzKutsWeALwSEXc8a)
				ceHxw7y6CKdv39X0N1Gr = wa6j19u4KBdp['user_info']['status']
				yyThwHJRP2SI1Y0knGEdAzZMDcLo = True
				E1xw7TApYqVS = wa6j19u4KBdp['server_info']['time_now']
			except: pass
			if E1xw7TApYqVS:
				try:
					U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.strptime(E1xw7TApYqVS,'%Y.%m.%d %H:%M:%S')
					a601NOifzA8ye43JnCFwqxYmWSv = int(lQMuw1PvVpAk.mktime(U6SJ0tY7eRboijnWvA3lFVPwQk8D2N))
					ppd79g2rKSQnOLY = int(sqeRK2tVw8-a601NOifzA8ye43JnCFwqxYmWSv)
					ppd79g2rKSQnOLY = int((ppd79g2rKSQnOLY+900)/1800)*1800
				except: pass
				try:
					U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(int(wa6j19u4KBdp['user_info']['created_at']))
					veHW9rfmONgzc67AjlyDYdno83E = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M:%S',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
				except: pass
				try:
					U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(int(wa6j19u4KBdp['user_info']['exp_date']))
					DF4i2jqhc1YHn3rPKzS6UxwLGo = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M:%S',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
				except: pass
			llnG7jiQBYKhAeovbT.setSetting('av.m3u.timestamp_'+gYJAT1vW0Uqm76G,str(sqeRK2tVw8))
			llnG7jiQBYKhAeovbT.setSetting('av.m3u.timediff_'+gYJAT1vW0Uqm76G,str(ppd79g2rKSQnOLY))
			try:
				vjYi7m9MxnsdWXTeRVB6Z30t5O = '"server_info":'+oHQzKutsWeALwSEXc8a.split('"server_info":')[1]
				vjYi7m9MxnsdWXTeRVB6Z30t5O = vjYi7m9MxnsdWXTeRVB6Z30t5O.replace(':',': ').replace(',',', ').replace('}}','}')
				RiWp7Kt0DFh9bgcfPZBnJOVSE1sxzU = ScntgdOZCY74vNpXeW5jh8i.findall('"url": "(.*?)", "port": "(.*?)"',vjYi7m9MxnsdWXTeRVB6Z30t5O,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = RiWp7Kt0DFh9bgcfPZBnJOVSE1sxzU[0]
			except: yyThwHJRP2SI1Y0knGEdAzZMDcLo = False
			if yyThwHJRP2SI1Y0knGEdAzZMDcLo and O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
				max = wa6j19u4KBdp['user_info']['max_connections']
				tbT58jZHfYU9i1ena = wa6j19u4KBdp['user_info']['active_cons']
				OGitkVUogKIEwc1pXA7qdYLvNbB = wa6j19u4KBdp['user_info']['is_trial']
				UES13IuBRwzxOg = fPY3NmaF1d0W2b.split('?',1)
				CtO9cFuULSm62PWToMlzN1 = 'URL:  '+eMypvI8XqHjYU02anWD9gsSrkt+fPY3NmaF1d0W2b+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\n\nStatus:  '+eMypvI8XqHjYU02anWD9gsSrkt+ceHxw7y6CKdv39X0N1Gr+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nTrial:    '+eMypvI8XqHjYU02anWD9gsSrkt+str(OGitkVUogKIEwc1pXA7qdYLvNbB=='1')+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nCreated  At:  '+eMypvI8XqHjYU02anWD9gsSrkt+veHW9rfmONgzc67AjlyDYdno83E+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nExpiry Date:  '+eMypvI8XqHjYU02anWD9gsSrkt+DF4i2jqhc1YHn3rPKzS6UxwLGo+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nConnections   ( Active / Maximum ) :  '+eMypvI8XqHjYU02anWD9gsSrkt+tbT58jZHfYU9i1ena+' / '+max+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\nAllowed Outputs:   '+eMypvI8XqHjYU02anWD9gsSrkt+" , ".join(wa6j19u4KBdp['user_info']['allowed_output_formats'])+c7gxFyUCGm
				CtO9cFuULSm62PWToMlzN1 += '\n\n'+vjYi7m9MxnsdWXTeRVB6Z30t5O
				if ceHxw7y6CKdv39X0N1Gr=='Active': zU4taVvj6x12('الاشتراك يعمل بدون مشاكل',CtO9cFuULSm62PWToMlzN1)
				else: zU4taVvj6x12('يبدو أن هناك مشكلة في الاشتراك',CtO9cFuULSm62PWToMlzN1)
	if fPY3NmaF1d0W2b and yyThwHJRP2SI1Y0knGEdAzZMDcLo and ceHxw7y6CKdv39X0N1Gr=='Active':
		fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,'.\tChecking M3U URL   [ M3U account is OK ]   [ '+fPY3NmaF1d0W2b+' ]')
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv = True
	else:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,'Checking M3U URL   [ Does not work ]   [ '+fPY3NmaF1d0W2b+' ]')
		if O3asTXHd4Jm2KCQRUwvbtE8fuDAep: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'فحص اشتراك ـM3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv = False
	return aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX
def KwinXTzJv1N8yghA9UbI0HueGqa7R(gYJAT1vW0Uqm76G,GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG,GGyLnP8egKaM9Oxr,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
	AABDgbaTdl5ShcJWKGCeP1st0N7Ip = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list',GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG)
	gIqD4ESsoTy5AV73uY = int(GGyLnP8egKaM9Oxr)*100
	ggA7LcUQRr = gIqD4ESsoTy5AV73uY-100
	for R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in AABDgbaTdl5ShcJWKGCeP1st0N7Ip[ggA7LcUQRr:gIqD4ESsoTy5AV73uY]:
		ii8MX4g6Jpmzy0rh7u = ('GROUPED' in GIplj3KhV8dc or GIplj3KhV8dc=='ALL')
		JfYeiqVQ1F7ZWp9 = ('GROUPED' not in GIplj3KhV8dc and GIplj3KhV8dc!='ALL')
		if ii8MX4g6Jpmzy0rh7u or JfYeiqVQ1F7ZWp9:
			if   'ARCHIVED'  in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,718,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARCHIVED',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
			elif 'EPG' 		 in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,718,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FULL_EPG',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
			elif 'TIMESHIFT' in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,718,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,'TIMESHIFT',nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
			elif 'LIVE' 	 in GIplj3KhV8dc: LvJuOzMqk6WlP971eoGpUQ8.append(['live',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,715,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,R0gbu46Cw9ZKhB5jsT8HAcGv,{'folder':gYJAT1vW0Uqm76G}])
			else: LvJuOzMqk6WlP971eoGpUQ8.append(['video',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,715,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G}])
	WWXzI34UZEqYhf25uxJwLVo = len(AABDgbaTdl5ShcJWKGCeP1st0N7Ip)
	E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,714,WWXzI34UZEqYhf25uxJwLVo,IWFYt6Pq9NRk5JD3OG)
	return
def yrlUp0qAiT4wJNcHtWEhC8VbxGn(BDmSaXN05hsoRTzO6):
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+'هذه القائمة إما فارغة أو غير موجودة',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+'أو الخدمة غير موجودة في اشتراكك',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+'أو رابط M3U الذي أنت أضفته غير صحيح',nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	return
def ITqsrkfZpxUMCWVYKi9Qy(gYJAT1vW0Uqm76G,GIplj3KhV8dc,IWFYt6Pq9NRk5JD3OG,GGyLnP8egKaM9Oxr,RxBINUEMFPfsD3nrZoQ=nbOFVEDkpT4BIR7Qq82yPmHeJU,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	BDmSaXN05hsoRTzO6 = PPZDQo6RAG3a0Ot1Ydc5Fwz
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return False
	if '__SERIES__' in IWFYt6Pq9NRk5JD3OG: kJPeLjd2XE,JJiXBPu73g0QKCA2dGqxomphUMLW5 = IWFYt6Pq9NRk5JD3OG.split('__SERIES__')
	else: kJPeLjd2XE,JJiXBPu73g0QKCA2dGqxomphUMLW5 = IWFYt6Pq9NRk5JD3OG,nbOFVEDkpT4BIR7Qq82yPmHeJU
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
	AEFhLqn2BYR1IQ = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list',GIplj3KhV8dc,'__GROUPS__')
	if not AEFhLqn2BYR1IQ: return False
	SxtuIkQyVZEr = []
	for q4qfsInUtRDYlXdvTMe02xPNC,ayoEi7YNWD in AEFhLqn2BYR1IQ:
		if '===== ===== =====' in q4qfsInUtRDYlXdvTMe02xPNC:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',BDmSaXN05hsoRTzO6+q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
			continue
		if RxBINUEMFPfsD3nrZoQ:
			if '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: BDmSaXN05hsoRTzO6 = 'SERIES'
			elif '!!__UNKNOWN__!!' in q4qfsInUtRDYlXdvTMe02xPNC: BDmSaXN05hsoRTzO6 = 'UNKNOWN'
			elif 'LIVE' in GIplj3KhV8dc: BDmSaXN05hsoRTzO6 = 'LIVE'
			else: BDmSaXN05hsoRTzO6 = 'VIDEOS'
			BDmSaXN05hsoRTzO6 = ','+eMypvI8XqHjYU02anWD9gsSrkt+BDmSaXN05hsoRTzO6+': '+c7gxFyUCGm
		if '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: b2VJoUNBzi4OYdF,pPFrIbNGX8sSMTQt6HWaEwu4eqO = q4qfsInUtRDYlXdvTMe02xPNC.split('__SERIES__')
		else: b2VJoUNBzi4OYdF,pPFrIbNGX8sSMTQt6HWaEwu4eqO = q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU
		if not IWFYt6Pq9NRk5JD3OG:
			if b2VJoUNBzi4OYdF in SxtuIkQyVZEr: continue
			SxtuIkQyVZEr.append(b2VJoUNBzi4OYdF)
			if 'RANDOM' in RxBINUEMFPfsD3nrZoQ: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+b2VJoUNBzi4OYdF,GIplj3KhV8dc,168,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			elif '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+b2VJoUNBzi4OYdF,GIplj3KhV8dc,713,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+b2VJoUNBzi4OYdF,GIplj3KhV8dc,714,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
		elif '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC and b2VJoUNBzi4OYdF==kJPeLjd2XE:
			if pPFrIbNGX8sSMTQt6HWaEwu4eqO in SxtuIkQyVZEr: continue
			SxtuIkQyVZEr.append(pPFrIbNGX8sSMTQt6HWaEwu4eqO)
			if 'RANDOM' in RxBINUEMFPfsD3nrZoQ: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+pPFrIbNGX8sSMTQt6HWaEwu4eqO,GIplj3KhV8dc,168,nbOFVEDkpT4BIR7Qq82yPmHeJU,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',BDmSaXN05hsoRTzO6+pPFrIbNGX8sSMTQt6HWaEwu4eqO,GIplj3KhV8dc,714,ayoEi7YNWD,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	LvJuOzMqk6WlP971eoGpUQ8[:] = sorted(LvJuOzMqk6WlP971eoGpUQ8,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[1].lower())
	if not RxBINUEMFPfsD3nrZoQ:
		gIqD4ESsoTy5AV73uY = int(GGyLnP8egKaM9Oxr)*100
		ggA7LcUQRr = gIqD4ESsoTy5AV73uY-100
		WWXzI34UZEqYhf25uxJwLVo = len(LvJuOzMqk6WlP971eoGpUQ8)
		LvJuOzMqk6WlP971eoGpUQ8[:] = LvJuOzMqk6WlP971eoGpUQ8[ggA7LcUQRr:gIqD4ESsoTy5AV73uY]
		E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,713,WWXzI34UZEqYhf25uxJwLVo,IWFYt6Pq9NRk5JD3OG)
	return True
def kC4fo85D9AW6EPIKi1LyTugdN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,k0nHCSW52Kdqx4PO1BVDiF):
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,True): return
	YeRr5GFOCqn9ufVy = Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G)
	a601NOifzA8ye43JnCFwqxYmWSv = llnG7jiQBYKhAeovbT.getSetting('av.m3u.timestamp_'+gYJAT1vW0Uqm76G)
	if not a601NOifzA8ye43JnCFwqxYmWSv or sqeRK2tVw8-int(a601NOifzA8ye43JnCFwqxYmWSv)>24*wfVkBtgLUIM3N6Ozy2i5pxlT:
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,False)
		if not aBStCuH2RG4fOZJp19XAbKkI5xe7Nv: return
	ppd79g2rKSQnOLY = int(llnG7jiQBYKhAeovbT.getSetting('av.m3u.timediff_'+gYJAT1vW0Uqm76G))
	o0TYhleWOM = llnG7jiQBYKhAeovbT.getSetting('av.m3u.server_'+gYJAT1vW0Uqm76G)
	BarI1m9u06gVdhyCjGYWXbUv = llnG7jiQBYKhAeovbT.getSetting('av.m3u.username_'+gYJAT1vW0Uqm76G)
	MLkvbSEfXz = llnG7jiQBYKhAeovbT.getSetting('av.m3u.password_'+gYJAT1vW0Uqm76G)
	RRsTHyuLaFSJrpkMzGco6NWVKhd = wNyZhHdvUeC3M.split('/')
	AAYEoBlQns5 = RRsTHyuLaFSJrpkMzGco6NWVKhd[-1].replace('.ts',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('.m3u8',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if k0nHCSW52Kdqx4PO1BVDiF=='SHORT_EPG': kWXFQVIwxB3limsKy4cgfUMYbtj = 'get_short_epg'
	else: kWXFQVIwxB3limsKy4cgfUMYbtj = 'get_simple_data_table'
	fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz = y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G)
	if not BarI1m9u06gVdhyCjGYWXbUv: return
	zaIqTnRdcDg8YQGZeSPbUX = fPY3NmaF1d0W2b+'&action='+kWXFQVIwxB3limsKy4cgfUMYbtj+'&stream_id='+AAYEoBlQns5
	oHQzKutsWeALwSEXc8a = kPVgovOiMwCdNfESc1QLmK3B8526D(zDoPOYNsJg2id1HLnx5bpf,zaIqTnRdcDg8YQGZeSPbUX,nbOFVEDkpT4BIR7Qq82yPmHeJU,YeRr5GFOCqn9ufVy,nbOFVEDkpT4BIR7Qq82yPmHeJU,'M3U-EPG_ITEMS-2nd')
	rr1xyGZiXBbDnswoQOfk0zN87 = dr1zfnatJxRHSF48jh0eODm5bGu('dict',oHQzKutsWeALwSEXc8a)
	kS1rJepN0jl29fQACPqFhyZdzKRb = rr1xyGZiXBbDnswoQOfk0zN87['epg_listings']
	c2HW19hO85y = []
	if k0nHCSW52Kdqx4PO1BVDiF in ['ARCHIVED','TIMESHIFT']:
		for wa6j19u4KBdp in kS1rJepN0jl29fQACPqFhyZdzKRb:
			if wa6j19u4KBdp['has_archive']==1:
				c2HW19hO85y.append(wa6j19u4KBdp)
				if k0nHCSW52Kdqx4PO1BVDiF in ['TIMESHIFT']: break
		if not c2HW19hO85y: return
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+eMypvI8XqHjYU02anWD9gsSrkt+'الملفات الأولي بهذه القائمة قد لا تعمل'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
		if k0nHCSW52Kdqx4PO1BVDiF in ['TIMESHIFT']:
			nAktrezULFdcYlpOujK9W7f0qQs = 2
			UTm5bfW3g2GsQSw98xHLeE1KJyDI = nAktrezULFdcYlpOujK9W7f0qQs*wfVkBtgLUIM3N6Ozy2i5pxlT
			c2HW19hO85y = []
			GsC8wyQ2S0Mcd49kKfOIEojqFlrv = int(int(wa6j19u4KBdp['start_timestamp'])/UTm5bfW3g2GsQSw98xHLeE1KJyDI)*UTm5bfW3g2GsQSw98xHLeE1KJyDI
			yyNo1iZvxM5YTw7BP6K = sqeRK2tVw8+UTm5bfW3g2GsQSw98xHLeE1KJyDI
			tHNkelqBfUima9 = int((yyNo1iZvxM5YTw7BP6K-GsC8wyQ2S0Mcd49kKfOIEojqFlrv)/wfVkBtgLUIM3N6Ozy2i5pxlT)
			for EESRd0rNUVBQoX8F1 in range(tHNkelqBfUima9):
				if EESRd0rNUVBQoX8F1>=6:
					if EESRd0rNUVBQoX8F1%nAktrezULFdcYlpOujK9W7f0qQs!=0: continue
					vQgYUMCXexcZrWbHjBlL1FkqP = UTm5bfW3g2GsQSw98xHLeE1KJyDI
				else: vQgYUMCXexcZrWbHjBlL1FkqP = UTm5bfW3g2GsQSw98xHLeE1KJyDI//2
				SLduBNkwpAEqQDKr4mj = GsC8wyQ2S0Mcd49kKfOIEojqFlrv+EESRd0rNUVBQoX8F1*wfVkBtgLUIM3N6Ozy2i5pxlT
				wa6j19u4KBdp = {}
				wa6j19u4KBdp['title'] = nbOFVEDkpT4BIR7Qq82yPmHeJU
				U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(SLduBNkwpAEqQDKr4mj-ppd79g2rKSQnOLY-wfVkBtgLUIM3N6Ozy2i5pxlT)
				wa6j19u4KBdp['start'] = lQMuw1PvVpAk.strftime('%Y.%m.%d %H:%M:%S',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
				wa6j19u4KBdp['start_timestamp'] = str(SLduBNkwpAEqQDKr4mj)
				wa6j19u4KBdp['stop_timestamp'] = str(SLduBNkwpAEqQDKr4mj+vQgYUMCXexcZrWbHjBlL1FkqP)
				c2HW19hO85y.append(wa6j19u4KBdp)
	elif k0nHCSW52Kdqx4PO1BVDiF in ['SHORT_EPG','FULL_EPG']: c2HW19hO85y = kS1rJepN0jl29fQACPqFhyZdzKRb
	if k0nHCSW52Kdqx4PO1BVDiF=='FULL_EPG' and len(c2HW19hO85y)>0:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+eMypvI8XqHjYU02anWD9gsSrkt+'هذه قائمة برامج القنوات (جدول فقط)ـ'+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Eihjk8bvNDTl4HKysaV = []
	ayoEi7YNWD = RarSo2nTfwU0WEGK.getInfoLabel('ListItem.Icon')
	for wa6j19u4KBdp in c2HW19hO85y:
		GdbFDygsZ6HopImiSTY53 = Y7goyGlxwNaP1XcWU6e.b64decode(wa6j19u4KBdp['title'])
		if IZhXMprxvAHqBEFkg0: GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		SLduBNkwpAEqQDKr4mj = int(wa6j19u4KBdp['start_timestamp'])
		SQb6TkXINJ5hsxtZACvu = int(wa6j19u4KBdp['stop_timestamp'])
		SkMYHbEx567vuqU9jGf3 = str(int((SQb6TkXINJ5hsxtZACvu-SLduBNkwpAEqQDKr4mj+59)/60))
		dVDOF3Ef1TqxHzXJwuRZjg = wa6j19u4KBdp['start'].replace(S3X6GcaiExOPtb,':')
		U6SJ0tY7eRboijnWvA3lFVPwQk8D2N = lQMuw1PvVpAk.localtime(SLduBNkwpAEqQDKr4mj-wfVkBtgLUIM3N6Ozy2i5pxlT)
		Mk93VFXluZJyW = lQMuw1PvVpAk.strftime('%H:%M',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
		kqgJfoEeKUj45 = lQMuw1PvVpAk.strftime('%a',U6SJ0tY7eRboijnWvA3lFVPwQk8D2N)
		if k0nHCSW52Kdqx4PO1BVDiF=='SHORT_EPG': GdbFDygsZ6HopImiSTY53 = l5JG7XwbOfo8DznU+Mk93VFXluZJyW+' ـ '+GdbFDygsZ6HopImiSTY53+c7gxFyUCGm
		elif k0nHCSW52Kdqx4PO1BVDiF=='TIMESHIFT': GdbFDygsZ6HopImiSTY53 = kqgJfoEeKUj45+S3X6GcaiExOPtb+Mk93VFXluZJyW+' ('+SkMYHbEx567vuqU9jGf3+'min)'
		else: GdbFDygsZ6HopImiSTY53 = kqgJfoEeKUj45+S3X6GcaiExOPtb+Mk93VFXluZJyW+' ('+SkMYHbEx567vuqU9jGf3+'min)   '+GdbFDygsZ6HopImiSTY53+' ـ'
		if k0nHCSW52Kdqx4PO1BVDiF in ['ARCHIVED','FULL_EPG','TIMESHIFT']:
			YYPztCbNZITr0QHiWpAJmM76K = o0TYhleWOM+'/timeshift/'+BarI1m9u06gVdhyCjGYWXbUv+'/'+MLkvbSEfXz+'/'+SkMYHbEx567vuqU9jGf3+'/'+dVDOF3Ef1TqxHzXJwuRZjg+'/'+AAYEoBlQns5+'.m3u8'
			if k0nHCSW52Kdqx4PO1BVDiF=='FULL_EPG': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,YYPztCbNZITr0QHiWpAJmM76K,9999,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,YYPztCbNZITr0QHiWpAJmM76K,715,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
		Eihjk8bvNDTl4HKysaV.append(GdbFDygsZ6HopImiSTY53)
	if k0nHCSW52Kdqx4PO1BVDiF=='SHORT_EPG' and Eihjk8bvNDTl4HKysaV: rxAoL8pD5USRBImHC47W = unWTBJIFERUQqx0NS5DOjgP(Eihjk8bvNDTl4HKysaV)
	return Eihjk8bvNDTl4HKysaV
def xu91PRNQyqg7DTMUrOXphEYB6(gYJAT1vW0Uqm76G):
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,True): return
	o0TYhleWOM,oiqWL8T6cU,LrZiukpn2v = nbOFVEDkpT4BIR7Qq82yPmHeJU,0,0
	aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = YJ2CSXjQi7cDfzxRZuOFoNUs6E9(gYJAT1vW0Uqm76G,False)
	if aBStCuH2RG4fOZJp19XAbKkI5xe7Nv:
		hg6ELCjF7UDlyxrBTb0nJZ4cum = PNFTZx6gr4ycq(VLlfzHGkZQ0ModFbWq4D)
		oiqWL8T6cU = PPwLpT7XsB(hg6ELCjF7UDlyxrBTb0nJZ4cum[0],int(pwO2bxAaRDIFX))
		nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'LIVE_GROUPED')
		HNicWMGkpKj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list','LIVE_GROUPED')
		AABDgbaTdl5ShcJWKGCeP1st0N7Ip = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list','LIVE_GROUPED',HNicWMGkpKj[1])
		wNyZhHdvUeC3M = AABDgbaTdl5ShcJWKGCeP1st0N7Ip[0][2]
		iayfxuFeTloLW1cmBHSDh5r7R3Eq0 = ScntgdOZCY74vNpXeW5jh8i.findall('://(.*?)/',wNyZhHdvUeC3M,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		iayfxuFeTloLW1cmBHSDh5r7R3Eq0 = iayfxuFeTloLW1cmBHSDh5r7R3Eq0[0]
		if ':' in iayfxuFeTloLW1cmBHSDh5r7R3Eq0: DDnW1cXvgS4J60Nx8lKtr2VdAfRY,Y89RSPgZpbQN4wco2TlLqUhWnX = iayfxuFeTloLW1cmBHSDh5r7R3Eq0.split(':')
		else: DDnW1cXvgS4J60Nx8lKtr2VdAfRY,Y89RSPgZpbQN4wco2TlLqUhWnX = iayfxuFeTloLW1cmBHSDh5r7R3Eq0,'80'
		jjb8HaTF3LrECv52kmU = PNFTZx6gr4ycq(DDnW1cXvgS4J60Nx8lKtr2VdAfRY)
		LrZiukpn2v = PPwLpT7XsB(jjb8HaTF3LrECv52kmU[0],int(Y89RSPgZpbQN4wco2TlLqUhWnX))
	if oiqWL8T6cU and LrZiukpn2v:
		CtO9cFuULSm62PWToMlzN1 = 'هل تريد استخدام السيرفر الأصلي أم السيرفر الأسرع ؟!!'
		CtO9cFuULSm62PWToMlzN1 += '\n\n'+'وقت ضائع في السيرفر الأصلي'+wwOnIucWJj+str(int(LrZiukpn2v*1000))+' ملي ثانية'
		CtO9cFuULSm62PWToMlzN1 += '\n\n'+'وقت ضائع في السيرفر البديل'+wwOnIucWJj+str(int(oiqWL8T6cU*1000))+' ملي ثانية'
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center','السيرفر الأصلي','السيرفر الأسرع','رسالة من المبرمج',CtO9cFuULSm62PWToMlzN1)
		if JvOL5Wr9s6==1 and oiqWL8T6cU<LrZiukpn2v: o0TYhleWOM = VLlfzHGkZQ0ModFbWq4D+':'+pwO2bxAaRDIFX
	else: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','البرنامج لم يجد السيرفر البديل')
	llnG7jiQBYKhAeovbT.setSetting('av.m3u.server_'+gYJAT1vW0Uqm76G,o0TYhleWOM)
	return
def AOk1T6KwciHrWU2MYJzZnEN(gYJAT1vW0Uqm76G,wNyZhHdvUeC3M,iiyAEbQ5f80):
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G)
	kYFoe7P0tzCaZ = llnG7jiQBYKhAeovbT.getSetting('av.m3u.referer_'+gYJAT1vW0Uqm76G)
	if ltDKzevu94swOC0YqBPMR76 or kYFoe7P0tzCaZ:
		wNyZhHdvUeC3M += '|'
		if ltDKzevu94swOC0YqBPMR76: wNyZhHdvUeC3M += '&User-Agent='+ltDKzevu94swOC0YqBPMR76
		if kYFoe7P0tzCaZ: wNyZhHdvUeC3M += '&Referer='+kYFoe7P0tzCaZ
		wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace('|&','|')
	brh5aWRxQzn6YL8UDNOyK9SFGo(wNyZhHdvUeC3M,VGjzYJZykfEWxlQLeap,iiyAEbQ5f80)
	return
def ZHuG4LETX5jcK1tBgbzehNxUakFq(gYJAT1vW0Uqm76G):
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـUser-Agent خاص')
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G)
	rhcetwI14l = ttiZs4bKHFvugJj5z('center','استخدام الأصلي','تعديل القديم',ltDKzevu94swOC0YqBPMR76,'هذا هو ـUser-Agent المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if rhcetwI14l==1: ltDKzevu94swOC0YqBPMR76 = dR75Vq2gprfHmUcNhG('أكتب ـM3U User-Agent جديد',ltDKzevu94swOC0YqBPMR76,True)
	else: ltDKzevu94swOC0YqBPMR76 = 'Unknown'
	if ltDKzevu94swOC0YqBPMR76==S3X6GcaiExOPtb:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,ltDKzevu94swOC0YqBPMR76,'هل تريد استخدام هذا ـUser-Agent بدلا من  القديم ؟')
	if rhcetwI14l!=1:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإلغاء')
		return
	llnG7jiQBYKhAeovbT.setSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G,ltDKzevu94swOC0YqBPMR76)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def sAkcixqeBNVbZIPdSo(gYJAT1vW0Uqm76G):
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تحذير مهم وهام جدا . يرجى عدم تغييره إذا كنت لا تعرف ما هو .  وعدم تغييره إلا عند الضرورة القصوى . الحاجة لهذا التغيير هي فقط إذا طلبت منك شركة ـM3U أن تعمل هذا التغيير . وفقط عندما تستخدم خدمة ـM3U تحتاج ـReferer خاص')
	kYFoe7P0tzCaZ = llnG7jiQBYKhAeovbT.getSetting('av.m3u.referer_'+gYJAT1vW0Uqm76G)
	rhcetwI14l = ttiZs4bKHFvugJj5z('center','استخدام الأصلي','تعديل القديم',kYFoe7P0tzCaZ,'هذا هو ـReferer المستخدم حاليا مع ـM3U الذي في هذا البرنامج . هل تريد تعديله أم تريد إعادته إلى وضعية التثبيت الأصلي والتي تقريبا تناسب جميع شركات ـM3U ؟!')
	if rhcetwI14l==1: kYFoe7P0tzCaZ = dR75Vq2gprfHmUcNhG('أكتب ـM3U Referer جديد',kYFoe7P0tzCaZ,True)
	else: kYFoe7P0tzCaZ = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if kYFoe7P0tzCaZ==S3X6GcaiExOPtb:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','غير مسموح أستخدام فراغ لوحده أو عدة فراغات لوحدها ... يجب إما تركه فارغ تماما أو إضافة حرف أو أي شي آخر معها')
		return
	rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,kYFoe7P0tzCaZ,'هل تريد استخدام هذا ـReferer بدلا من  القديم ؟')
	if rhcetwI14l!=1:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإلغاء')
		return
	llnG7jiQBYKhAeovbT.setSetting('av.m3u.referer_'+gYJAT1vW0Uqm76G,kYFoe7P0tzCaZ)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def y0ZnJTWC1jtmK(gYJAT1vW0Uqm76G,n0kjDVCQ6LtIb=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not IzvacY6rXBPS45H0toduNAls: IzvacY6rXBPS45H0toduNAls = llnG7jiQBYKhAeovbT.getSetting('av.m3u.url_'+gYJAT1vW0Uqm76G)
	o0TYhleWOM = Qi32bRtN18qvyWmaO7YKow9cXs(IzvacY6rXBPS45H0toduNAls,'url')
	BarI1m9u06gVdhyCjGYWXbUv = ScntgdOZCY74vNpXeW5jh8i.findall('username=(.*?)&',IzvacY6rXBPS45H0toduNAls+'&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	MLkvbSEfXz = ScntgdOZCY74vNpXeW5jh8i.findall('password=(.*?)&',IzvacY6rXBPS45H0toduNAls+'&',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not BarI1m9u06gVdhyCjGYWXbUv or not MLkvbSEfXz:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'فحص اشتراك M3U','رابط اشتراك ـM3U الذي قمت انت بإضافته إلى البرنامج لا يعمل أو الرابط غير موجود في البرنامج . أذهب إلى قائمة اشتراك ـM3U وقم بإضافة رابط ـM3U جديد أو قم بإصلاح الرابط القديم')
		return nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	BarI1m9u06gVdhyCjGYWXbUv = BarI1m9u06gVdhyCjGYWXbUv[0]
	MLkvbSEfXz = MLkvbSEfXz[0]
	fPY3NmaF1d0W2b = o0TYhleWOM+'/player_api.php?username='+BarI1m9u06gVdhyCjGYWXbUv+'&password='+MLkvbSEfXz
	PEQBv9wdpSXqYRjK6I = o0TYhleWOM+'/get.php?username='+BarI1m9u06gVdhyCjGYWXbUv+'&password='+MLkvbSEfXz+'&type=m3u_plus'
	return fPY3NmaF1d0W2b,PEQBv9wdpSXqYRjK6I,o0TYhleWOM,BarI1m9u06gVdhyCjGYWXbUv,MLkvbSEfXz
def TWUofuz7I4JdSbesw6V(gYJAT1vW0Uqm76G,XSs23UuGCgOPATm7hY=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	fvV4HSZqTK3LYzJ15BD = XSs23UuGCgOPATm7hY.replace('/','_').replace(':','_').replace('.','_')
	fvV4HSZqTK3LYzJ15BD = fvV4HSZqTK3LYzJ15BD.replace('?','_').replace('=','_').replace('&','_')
	fvV4HSZqTK3LYzJ15BD = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,fvV4HSZqTK3LYzJ15BD).strip('.m3u')+'.m3u'
	return fvV4HSZqTK3LYzJ15BD
def E0PNDIAiaYkKRpx(gYJAT1vW0Uqm76G,atKPpEV8Oi7bxMq5FoYGe):
	slKUaoGTVYnP = llnG7jiQBYKhAeovbT.getSetting('av.m3u.url_'+gYJAT1vW0Uqm76G+'_'+atKPpEV8Oi7bxMq5FoYGe)
	vYqAshPKQrVDB = True
	if slKUaoGTVYnP:
		rhcetwI14l = YuqCtbB0XfT6rGUwS5z79VDk3del2E('center','كتابة جديد','تعديل القديم','مسح القديم','الرابط الحالي هو:',eMypvI8XqHjYU02anWD9gsSrkt+slKUaoGTVYnP+c7gxFyUCGm+'\n\n هذا هو رابط M3U المسجل في البرنامج .. هل تريد تعديله أم تريد كتابة رابط جديد ؟!')
		if rhcetwI14l==-1: return
		elif rhcetwI14l==0: slKUaoGTVYnP = nbOFVEDkpT4BIR7Qq82yPmHeJU
		elif rhcetwI14l==2:
			rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if rhcetwI14l in [-1,0]: return
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح الرابط')
			vYqAshPKQrVDB = False
			BlMVpQzksqZSg = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if vYqAshPKQrVDB:
		BlMVpQzksqZSg = dR75Vq2gprfHmUcNhG('اكتب رابط M3U كاملا',slKUaoGTVYnP)
		BlMVpQzksqZSg = BlMVpQzksqZSg.strip(S3X6GcaiExOPtb)
		if not BlMVpQzksqZSg:
			rhcetwI14l = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','لقد قمت بإدخال رابط فارغ .. هل تريد مسح الرابط المسجل في البرنامج ؟!')
			if rhcetwI14l in [-1,0]: return
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح الرابط')
		else:
			CtO9cFuULSm62PWToMlzN1 = 'هذه المعلومات تم أخذها من رابط ـM3U الذي انت كتبته . هل تريد استخدامها ؟!\n'
			rhcetwI14l = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'الرابط الجديد هو:',eMypvI8XqHjYU02anWD9gsSrkt+BlMVpQzksqZSg+c7gxFyUCGm+'\n\n'+CtO9cFuULSm62PWToMlzN1)
			if rhcetwI14l!=1:
				aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم الإلغاء')
				return
	llnG7jiQBYKhAeovbT.setSetting('av.m3u.url_'+gYJAT1vW0Uqm76G+'_'+atKPpEV8Oi7bxMq5FoYGe,BlMVpQzksqZSg)
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G)
	if not ltDKzevu94swOC0YqBPMR76: llnG7jiQBYKhAeovbT.setSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G,'Unknown')
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def H3HmDXTyWzoMi1gk(rrfWsKPq4nzR0V7jFoNBHQe,EQ6L70JxAk,jWK8ehlA0gJQqSrp1ZBndN3DwI,TSPhMOnV81Y7J0QC4Xd,lloWqNHwL5SjQcCI8ePFyB,f3phHmTd9wsvxGjD7SbJkIiRFB,PEQBv9wdpSXqYRjK6I):
	AABDgbaTdl5ShcJWKGCeP1st0N7Ip,YBxbVzcRSI8 = [],[]
	x6whricml7NXBujdVETZ2H = ['.avi','.mp4','.mkv','.mp3','.webm','.aac']
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		if f3phHmTd9wsvxGjD7SbJkIiRFB%473==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,40+int(10*f3phHmTd9wsvxGjD7SbJkIiRFB/lloWqNHwL5SjQcCI8ePFyB),'قراءة الفيديوهات','الفيديو رقم:-',str(f3phHmTd9wsvxGjD7SbJkIiRFB)+' / '+str(lloWqNHwL5SjQcCI8ePFyB))
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return None,None,None
		wNyZhHdvUeC3M = ScntgdOZCY74vNpXeW5jh8i.findall('^(.*?)\n+((http|https|rtmp).*?)$',k38Vi6PpwFNB7Aus1KErSLJaOdDvM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if wNyZhHdvUeC3M:
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM,wNyZhHdvUeC3M,RQg7AUDOp6MJtWwdba3VFYZ1XHokE = wNyZhHdvUeC3M[0]
			wNyZhHdvUeC3M = wNyZhHdvUeC3M.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else:
			YBxbVzcRSI8.append({'line':k38Vi6PpwFNB7Aus1KErSLJaOdDvM})
			continue
		ttm1ZRWeuMF4icE,R0gbu46Cw9ZKhB5jsT8HAcGv,q4qfsInUtRDYlXdvTMe02xPNC,GdbFDygsZ6HopImiSTY53,iiyAEbQ5f80,bb6JVCAYrB1FR = {},nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,False
		try:
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM,GdbFDygsZ6HopImiSTY53 = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.rsplit('",',1)
			k38Vi6PpwFNB7Aus1KErSLJaOdDvM = k38Vi6PpwFNB7Aus1KErSLJaOdDvM+'"'
		except:
			try: k38Vi6PpwFNB7Aus1KErSLJaOdDvM,GdbFDygsZ6HopImiSTY53 = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.rsplit('1,',1)
			except: GdbFDygsZ6HopImiSTY53 = nbOFVEDkpT4BIR7Qq82yPmHeJU
		ttm1ZRWeuMF4icE['url'] = wNyZhHdvUeC3M
		csoJfz47HYjmwT = ScntgdOZCY74vNpXeW5jh8i.findall(' (.*?)="(.*?)"',k38Vi6PpwFNB7Aus1KErSLJaOdDvM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for dvhs8lngSEQTyr4a7YwjkFVcWope,ggMUCPqpYinc in csoJfz47HYjmwT:
			dvhs8lngSEQTyr4a7YwjkFVcWope = dvhs8lngSEQTyr4a7YwjkFVcWope.replace('"',nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
			ttm1ZRWeuMF4icE[dvhs8lngSEQTyr4a7YwjkFVcWope] = ggMUCPqpYinc.strip(S3X6GcaiExOPtb)
		nH6pKdQl7eZFzW8mghOPVv5 = list(ttm1ZRWeuMF4icE.keys())
		if not GdbFDygsZ6HopImiSTY53:
			if 'name' in nH6pKdQl7eZFzW8mghOPVv5 and ttm1ZRWeuMF4icE['name']: GdbFDygsZ6HopImiSTY53 = ttm1ZRWeuMF4icE['name']
		ttm1ZRWeuMF4icE['title'] = GdbFDygsZ6HopImiSTY53.strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		if 'logo' in nH6pKdQl7eZFzW8mghOPVv5:
			ttm1ZRWeuMF4icE['img'] = ttm1ZRWeuMF4icE['logo']
			del ttm1ZRWeuMF4icE['logo']
		else: ttm1ZRWeuMF4icE['img'] = nbOFVEDkpT4BIR7Qq82yPmHeJU
		if 'group' in nH6pKdQl7eZFzW8mghOPVv5 and ttm1ZRWeuMF4icE['group']: q4qfsInUtRDYlXdvTMe02xPNC = ttm1ZRWeuMF4icE['group']
		if any(XPL0O2VkI3w1C8enMaqi in wNyZhHdvUeC3M.lower() for XPL0O2VkI3w1C8enMaqi in x6whricml7NXBujdVETZ2H):
			bb6JVCAYrB1FR = True if 'm3u' not in wNyZhHdvUeC3M else False
		if bb6JVCAYrB1FR or '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC or '__MOVIES__' in q4qfsInUtRDYlXdvTMe02xPNC:
			iiyAEbQ5f80 = 'VOD'
			if '__SERIES__' in q4qfsInUtRDYlXdvTMe02xPNC: iiyAEbQ5f80 = iiyAEbQ5f80+'_SERIES'
			elif '__MOVIES__' in q4qfsInUtRDYlXdvTMe02xPNC: iiyAEbQ5f80 = iiyAEbQ5f80+'_MOVIES'
			else: iiyAEbQ5f80 = iiyAEbQ5f80+'_UNKNOWN'
			q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.replace('__SERIES__',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('__MOVIES__',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		else:
			iiyAEbQ5f80 = 'LIVE'
			if GdbFDygsZ6HopImiSTY53 in EQ6L70JxAk: R0gbu46Cw9ZKhB5jsT8HAcGv = R0gbu46Cw9ZKhB5jsT8HAcGv+'_EPG'
			if GdbFDygsZ6HopImiSTY53 in jWK8ehlA0gJQqSrp1ZBndN3DwI: R0gbu46Cw9ZKhB5jsT8HAcGv = R0gbu46Cw9ZKhB5jsT8HAcGv+'_ARCHIVED'
			if not q4qfsInUtRDYlXdvTMe02xPNC: iiyAEbQ5f80 = iiyAEbQ5f80+'_UNKNOWN'
			else: iiyAEbQ5f80 = iiyAEbQ5f80+R0gbu46Cw9ZKhB5jsT8HAcGv
		q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC.strip(S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
		if 'LIVE_UNKNOWN' in iiyAEbQ5f80: q4qfsInUtRDYlXdvTMe02xPNC = '!!__UNKNOWN_LIVE__!!'
		elif 'VOD_UNKNOWN' in iiyAEbQ5f80: q4qfsInUtRDYlXdvTMe02xPNC = '!!__UNKNOWN_VOD__!!'
		elif 'VOD_SERIES' in iiyAEbQ5f80:
			OZ1h4rAMcaPeuIKWgL6DU = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) [Ss]\d+ +[Ee]\d+',ttm1ZRWeuMF4icE['title'],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if OZ1h4rAMcaPeuIKWgL6DU: OZ1h4rAMcaPeuIKWgL6DU = OZ1h4rAMcaPeuIKWgL6DU[0]
			else: OZ1h4rAMcaPeuIKWgL6DU = '!!__UNKNOWN_SERIES__!!'
			q4qfsInUtRDYlXdvTMe02xPNC = q4qfsInUtRDYlXdvTMe02xPNC+'__SERIES__'+OZ1h4rAMcaPeuIKWgL6DU
		if 'id' in nH6pKdQl7eZFzW8mghOPVv5: del ttm1ZRWeuMF4icE['id']
		if 'ID' in nH6pKdQl7eZFzW8mghOPVv5: del ttm1ZRWeuMF4icE['ID']
		if 'name' in nH6pKdQl7eZFzW8mghOPVv5: del ttm1ZRWeuMF4icE['name']
		GdbFDygsZ6HopImiSTY53 = ttm1ZRWeuMF4icE['title']
		GdbFDygsZ6HopImiSTY53 = eX7uYOJc6C5Q0ApLjUoEmdVgv1S9bk(GdbFDygsZ6HopImiSTY53)
		GdbFDygsZ6HopImiSTY53 = qRWV6CJBFbYOhDZt(GdbFDygsZ6HopImiSTY53)
		iRyWwxdCcsUL0D31OH,q4qfsInUtRDYlXdvTMe02xPNC = dcRe6Ag30VTIZ9SW5Nm(q4qfsInUtRDYlXdvTMe02xPNC)
		gjwb3coX1MxOqhNIalmYzu,GdbFDygsZ6HopImiSTY53 = dcRe6Ag30VTIZ9SW5Nm(GdbFDygsZ6HopImiSTY53)
		ttm1ZRWeuMF4icE['type'] = iiyAEbQ5f80
		ttm1ZRWeuMF4icE['context'] = R0gbu46Cw9ZKhB5jsT8HAcGv
		ttm1ZRWeuMF4icE['group'] = q4qfsInUtRDYlXdvTMe02xPNC.upper()
		ttm1ZRWeuMF4icE['title'] = GdbFDygsZ6HopImiSTY53.upper()
		ttm1ZRWeuMF4icE['country'] = gjwb3coX1MxOqhNIalmYzu.upper()
		ttm1ZRWeuMF4icE['language'] = iRyWwxdCcsUL0D31OH.upper()
		AABDgbaTdl5ShcJWKGCeP1st0N7Ip.append(ttm1ZRWeuMF4icE)
		f3phHmTd9wsvxGjD7SbJkIiRFB += 1
	return AABDgbaTdl5ShcJWKGCeP1st0N7Ip,f3phHmTd9wsvxGjD7SbJkIiRFB,YBxbVzcRSI8
def qRWV6CJBFbYOhDZt(GdbFDygsZ6HopImiSTY53):
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('||','|').replace('___',':').replace('--','-')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('[[','[').replace(']]',']')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('((','(').replace('))',')')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.replace('<<','<').replace('>>','>')
	GdbFDygsZ6HopImiSTY53 = GdbFDygsZ6HopImiSTY53.strip(S3X6GcaiExOPtb)
	return GdbFDygsZ6HopImiSTY53
def Uzwpo7NtJxq2IrA(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,TSPhMOnV81Y7J0QC4Xd,atKPpEV8Oi7bxMq5FoYGe):
	GGzFWiTteIQranCwU03pHqgmLukMh9 = {}
	for jiDqcXSOhBL in GUf84z2bdKlc7PpywoNrDVg: GGzFWiTteIQranCwU03pHqgmLukMh9[jiDqcXSOhBL+'_'+atKPpEV8Oi7bxMq5FoYGe] = []
	lloWqNHwL5SjQcCI8ePFyB = len(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s)
	psbxE5gjQHIiOV7Bm = str(lloWqNHwL5SjQcCI8ePFyB)
	f3phHmTd9wsvxGjD7SbJkIiRFB = 0
	YBxbVzcRSI8 = []
	for ttm1ZRWeuMF4icE in zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s:
		if f3phHmTd9wsvxGjD7SbJkIiRFB%873==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,50+int(5*f3phHmTd9wsvxGjD7SbJkIiRFB/lloWqNHwL5SjQcCI8ePFyB),'تصنيف الفيديوهات الغير مرتبة','الفيديو رقم:-',str(f3phHmTd9wsvxGjD7SbJkIiRFB)+' / '+psbxE5gjQHIiOV7Bm)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return None,None
		q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD = ttm1ZRWeuMF4icE['group'],ttm1ZRWeuMF4icE['context'],ttm1ZRWeuMF4icE['title'],ttm1ZRWeuMF4icE['url'],ttm1ZRWeuMF4icE['img']
		gjwb3coX1MxOqhNIalmYzu,iRyWwxdCcsUL0D31OH,jiDqcXSOhBL = ttm1ZRWeuMF4icE['country'],ttm1ZRWeuMF4icE['language'],ttm1ZRWeuMF4icE['type']
		Eyltg9NqSwCT = (q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		PNXRkvwjtuo19iW3IxYzBJ = False
		if 'LIVE' in jiDqcXSOhBL:
			if 'UNKNOWN' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_UNKNOWN_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			elif 'LIVE' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			else: PNXRkvwjtuo19iW3IxYzBJ = True
			GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_ORIGINAL_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
		elif 'VOD' in jiDqcXSOhBL:
			if 'UNKNOWN' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_UNKNOWN_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			elif 'MOVIES' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_MOVIES_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			elif 'SERIES' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_SERIES_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			else: PNXRkvwjtuo19iW3IxYzBJ = True
			GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_ORIGINAL_GROUPED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
		else: PNXRkvwjtuo19iW3IxYzBJ = True
		if PNXRkvwjtuo19iW3IxYzBJ: YBxbVzcRSI8.append(ttm1ZRWeuMF4icE)
		f3phHmTd9wsvxGjD7SbJkIiRFB += 1
	OKJk3Z7ubTAioR2reaMyPCQt = sorted(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope['title'].lower())
	del zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s
	psbxE5gjQHIiOV7Bm = str(lloWqNHwL5SjQcCI8ePFyB)
	f3phHmTd9wsvxGjD7SbJkIiRFB = 0
	for ttm1ZRWeuMF4icE in OKJk3Z7ubTAioR2reaMyPCQt:
		f3phHmTd9wsvxGjD7SbJkIiRFB += 1
		if f3phHmTd9wsvxGjD7SbJkIiRFB%873==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,55+int(5*f3phHmTd9wsvxGjD7SbJkIiRFB/lloWqNHwL5SjQcCI8ePFyB),'تصنيف الفيديوهات المرتبة','الفيديو رقم:-',str(f3phHmTd9wsvxGjD7SbJkIiRFB)+' / '+psbxE5gjQHIiOV7Bm)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return None,None
		jiDqcXSOhBL = ttm1ZRWeuMF4icE['type']
		q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD = ttm1ZRWeuMF4icE['group'],ttm1ZRWeuMF4icE['context'],ttm1ZRWeuMF4icE['title'],ttm1ZRWeuMF4icE['url'],ttm1ZRWeuMF4icE['img']
		gjwb3coX1MxOqhNIalmYzu,iRyWwxdCcsUL0D31OH = ttm1ZRWeuMF4icE['country'],ttm1ZRWeuMF4icE['language']
		nv6HSBaWR2TIcufe3hXbw = (q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv+'_TIMESHIFT',GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		Eyltg9NqSwCT = (q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		M7l2mTHyfhVF1gcDYrWOt = (gjwb3coX1MxOqhNIalmYzu,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		M1MGfVbmzuEWI5Zwv4J2kyxcQ8qYd = (iRyWwxdCcsUL0D31OH,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD)
		if 'LIVE' in jiDqcXSOhBL:
			if 'UNKNOWN' in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_UNKNOWN_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			else: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			if 'EPG'		in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_EPG_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			if 'ARCHIVED'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_ARCHIVED_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			if 'ARCHIVED'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_TIMESHIFT_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(nv6HSBaWR2TIcufe3hXbw)
			GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_FROM_NAME_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(M7l2mTHyfhVF1gcDYrWOt)
			GGzFWiTteIQranCwU03pHqgmLukMh9['LIVE_FROM_GROUP_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(M1MGfVbmzuEWI5Zwv4J2kyxcQ8qYd)
		elif 'VOD' in jiDqcXSOhBL:
			if   'UNKNOWN'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_UNKNOWN_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			elif 'MOVIES'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_MOVIES_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			elif 'SERIES'	in jiDqcXSOhBL: GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_SERIES_GROUPED_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(Eyltg9NqSwCT)
			GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_FROM_NAME_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(M7l2mTHyfhVF1gcDYrWOt)
			GGzFWiTteIQranCwU03pHqgmLukMh9['VOD_FROM_GROUP_SORTED_'+atKPpEV8Oi7bxMq5FoYGe].append(M1MGfVbmzuEWI5Zwv4J2kyxcQ8qYd)
	return GGzFWiTteIQranCwU03pHqgmLukMh9,YBxbVzcRSI8
def dcRe6Ag30VTIZ9SW5Nm(GdbFDygsZ6HopImiSTY53):
	if len(GdbFDygsZ6HopImiSTY53)<3: return GdbFDygsZ6HopImiSTY53,GdbFDygsZ6HopImiSTY53
	oGhrR2kuUM5PIEgbyxHLaAqVecOZ,vvEo6gUjRliKq = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	DDBgLAUmNnJtuijT652 = GdbFDygsZ6HopImiSTY53
	D71DvSYLd3wNUGReB2EmZqPktulz = GdbFDygsZ6HopImiSTY53[:1]
	UijQyX2xbMqr4Gdf3ZaS5IwEB0mv6 = GdbFDygsZ6HopImiSTY53[1:]
	if   D71DvSYLd3wNUGReB2EmZqPktulz=='(': vvEo6gUjRliKq = ')'
	elif D71DvSYLd3wNUGReB2EmZqPktulz=='[': vvEo6gUjRliKq = ']'
	elif D71DvSYLd3wNUGReB2EmZqPktulz=='<': vvEo6gUjRliKq = '>'
	elif D71DvSYLd3wNUGReB2EmZqPktulz=='|': vvEo6gUjRliKq = '|'
	if vvEo6gUjRliKq and (vvEo6gUjRliKq in UijQyX2xbMqr4Gdf3ZaS5IwEB0mv6):
		HpuKsJNxB0SDqRzgdCakPZ,VydXkKzn3qoTt9YAuSRc4ajMEW0 = UijQyX2xbMqr4Gdf3ZaS5IwEB0mv6.split(vvEo6gUjRliKq,1)
		oGhrR2kuUM5PIEgbyxHLaAqVecOZ = HpuKsJNxB0SDqRzgdCakPZ
		DDBgLAUmNnJtuijT652 = D71DvSYLd3wNUGReB2EmZqPktulz+HpuKsJNxB0SDqRzgdCakPZ+vvEo6gUjRliKq+S3X6GcaiExOPtb+VydXkKzn3qoTt9YAuSRc4ajMEW0
	elif GdbFDygsZ6HopImiSTY53.count('|')>=2:
		HpuKsJNxB0SDqRzgdCakPZ,VydXkKzn3qoTt9YAuSRc4ajMEW0 = GdbFDygsZ6HopImiSTY53.split('|',1)
		oGhrR2kuUM5PIEgbyxHLaAqVecOZ = HpuKsJNxB0SDqRzgdCakPZ
		DDBgLAUmNnJtuijT652 = HpuKsJNxB0SDqRzgdCakPZ+' |'+VydXkKzn3qoTt9YAuSRc4ajMEW0
	else:
		vvEo6gUjRliKq = ScntgdOZCY74vNpXeW5jh8i.findall('^\w{2}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not vvEo6gUjRliKq: vvEo6gUjRliKq = ScntgdOZCY74vNpXeW5jh8i.findall('^\w{3}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if not vvEo6gUjRliKq: vvEo6gUjRliKq = ScntgdOZCY74vNpXeW5jh8i.findall('^\w{4}( |\:|\-|\||\]|\)|'+'#'+'|\.|\,|\$|\'|\!|\@|\%|\&|\*|\^)',GdbFDygsZ6HopImiSTY53,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if vvEo6gUjRliKq:
			HpuKsJNxB0SDqRzgdCakPZ,VydXkKzn3qoTt9YAuSRc4ajMEW0 = GdbFDygsZ6HopImiSTY53.split(vvEo6gUjRliKq[0],1)
			oGhrR2kuUM5PIEgbyxHLaAqVecOZ = HpuKsJNxB0SDqRzgdCakPZ
			DDBgLAUmNnJtuijT652 = HpuKsJNxB0SDqRzgdCakPZ+S3X6GcaiExOPtb+vvEo6gUjRliKq[0]+S3X6GcaiExOPtb+VydXkKzn3qoTt9YAuSRc4ajMEW0
	DDBgLAUmNnJtuijT652 = DDBgLAUmNnJtuijT652.replace(PCnucez1ITGQbklj7SoqNtw0O8,S3X6GcaiExOPtb).replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	oGhrR2kuUM5PIEgbyxHLaAqVecOZ = oGhrR2kuUM5PIEgbyxHLaAqVecOZ.replace(BhmzEC6OGD7FXZig9Tp5A,S3X6GcaiExOPtb)
	if not oGhrR2kuUM5PIEgbyxHLaAqVecOZ: oGhrR2kuUM5PIEgbyxHLaAqVecOZ = '!!__UNKNOWN__!!'
	oGhrR2kuUM5PIEgbyxHLaAqVecOZ = oGhrR2kuUM5PIEgbyxHLaAqVecOZ.strip(S3X6GcaiExOPtb)
	DDBgLAUmNnJtuijT652 = DDBgLAUmNnJtuijT652.strip(S3X6GcaiExOPtb)
	return oGhrR2kuUM5PIEgbyxHLaAqVecOZ,DDBgLAUmNnJtuijT652
def Yo2D4HlRpaGcS3kBFLC6z(gYJAT1vW0Uqm76G):
	YeRr5GFOCqn9ufVy = {}
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G)
	if ltDKzevu94swOC0YqBPMR76: YeRr5GFOCqn9ufVy['User-Agent'] = ltDKzevu94swOC0YqBPMR76
	kYFoe7P0tzCaZ = llnG7jiQBYKhAeovbT.getSetting('av.m3u.referer_'+gYJAT1vW0Uqm76G)
	if kYFoe7P0tzCaZ: YeRr5GFOCqn9ufVy['Referer'] = kYFoe7P0tzCaZ
	return YeRr5GFOCqn9ufVy
def V8YhRNmegG(gYJAT1vW0Uqm76G,atKPpEV8Oi7bxMq5FoYGe):
	global TSPhMOnV81Y7J0QC4Xd,GGzFWiTteIQranCwU03pHqgmLukMh9,QQFPbVlYHgoq01jB4AR,mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs,wNG8sMaEZkFdDvYLTbnmP
	PEQBv9wdpSXqYRjK6I = llnG7jiQBYKhAeovbT.getSetting('av.m3u.url_'+gYJAT1vW0Uqm76G+'_'+atKPpEV8Oi7bxMq5FoYGe)
	ltDKzevu94swOC0YqBPMR76 = llnG7jiQBYKhAeovbT.getSetting('av.m3u.useragent_'+gYJAT1vW0Uqm76G)
	YeRr5GFOCqn9ufVy = {'User-Agent':ltDKzevu94swOC0YqBPMR76}
	fvV4HSZqTK3LYzJ15BD = mEbtRoNBzaGf1KAuLUW6n4Sh3C.replace('___','_'+gYJAT1vW0Uqm76G+'_'+atKPpEV8Oi7bxMq5FoYGe)
	if 1:
		aBStCuH2RG4fOZJp19XAbKkI5xe7Nv,VLlfzHGkZQ0ModFbWq4D,pwO2bxAaRDIFX = True,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
		if not aBStCuH2RG4fOZJp19XAbKkI5xe7Nv:
			aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','فشل بسحب ملفات ـM3U . أحتمال رابط ـM3U غير صحيح أو قديم أو لا يعمل .. علما أن هذه الخدمة تحتاج اشتراك مدفوع وصحيح ويجب أن تضيف رابط الاشتراك بنفسك للبرنامج باستخدام قائمة ـM3U الموجودة بهذا البرنامج')
			if not PEQBv9wdpSXqYRjK6I: fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(QSJFrwB3dMiyH2mTPKD9a)+'   No M3U URL found to download M3U files')
			else: fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(VGjzYJZykfEWxlQLeap)+'   Failed to download M3U files')
			return
		D1sJBj274KYWL = OZq0bRFsaGe98NJxmW6tPiv(PEQBv9wdpSXqYRjK6I,YeRr5GFOCqn9ufVy,True)
		if not D1sJBj274KYWL: return
		open(fvV4HSZqTK3LYzJ15BD,'wb').write(D1sJBj274KYWL)
	else: D1sJBj274KYWL = open(fvV4HSZqTK3LYzJ15BD,'rb').read()
	if IZhXMprxvAHqBEFkg0 and D1sJBj274KYWL: D1sJBj274KYWL = D1sJBj274KYWL.decode(zSafwK0sDXdMN5JReniIQmrZxp)
	TSPhMOnV81Y7J0QC4Xd = LMSZwD0IRAziTh()
	TSPhMOnV81Y7J0QC4Xd.create('جلب ملفات M3U جديدة',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,15,'تنظيف الملف الرئيسي',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	D1sJBj274KYWL = D1sJBj274KYWL.replace('"tvg-','" tvg-')
	D1sJBj274KYWL = D1sJBj274KYWL.replace('َ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ً',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ُ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٌ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	D1sJBj274KYWL = D1sJBj274KYWL.replace('ّ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ِ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ٍ',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace('ْ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	D1sJBj274KYWL = D1sJBj274KYWL.replace('group-title=','group=').replace('tvg-',nbOFVEDkpT4BIR7Qq82yPmHeJU)
	jWK8ehlA0gJQqSrp1ZBndN3DwI,EQ6L70JxAk = [],[]
	D1sJBj274KYWL = D1sJBj274KYWL.replace(FKuOXLZA8PYBc7,wwOnIucWJj)
	rrfWsKPq4nzR0V7jFoNBHQe = ScntgdOZCY74vNpXeW5jh8i.findall('NF:(.+?)'+'#'+'EXTI',D1sJBj274KYWL+'\n+'+'#'+'EXTINF:',ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not rrfWsKPq4nzR0V7jFoNBHQe:
		fGBlEmQTwiAJt7rCYIxyau3jRh(xzmAtigc7C6LJF5X,Jks3bWlGDVr2RLKy8Y6f9(VGjzYJZykfEWxlQLeap)+'   Folder:'+gYJAT1vW0Uqm76G+'  Sequence:'+atKPpEV8Oi7bxMq5FoYGe+'   No video links found in M3U file')
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','رابط ـM3U الذي أنت أضفته لا توجد فيه فيديوهات .. احتمال رابط ـM3U غير صحيح'+wwOnIucWJj+l5JG7XwbOfo8DznU+'مجلد رقم '+gYJAT1vW0Uqm76G+'      رابط رقم '+atKPpEV8Oi7bxMq5FoYGe+c7gxFyUCGm)
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	d1daHcStye3mbCMl = []
	for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
		GsAZKprYCPdRMTOkEQgi53oWuFL = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.lower()
		if 'adult' in GsAZKprYCPdRMTOkEQgi53oWuFL: continue
		if 'xxx' in GsAZKprYCPdRMTOkEQgi53oWuFL: continue
		d1daHcStye3mbCMl.append(k38Vi6PpwFNB7Aus1KErSLJaOdDvM)
	rrfWsKPq4nzR0V7jFoNBHQe = d1daHcStye3mbCMl
	del d1daHcStye3mbCMl
	if 'iptv-org' in PEQBv9wdpSXqYRjK6I:
		d1daHcStye3mbCMl,ccLAbE39mBj2DInki8yU1TJhMR = [],[]
		for k38Vi6PpwFNB7Aus1KErSLJaOdDvM in rrfWsKPq4nzR0V7jFoNBHQe:
			HNicWMGkpKj = ScntgdOZCY74vNpXeW5jh8i.findall('group="(.*?)"',k38Vi6PpwFNB7Aus1KErSLJaOdDvM,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if HNicWMGkpKj:
				HNicWMGkpKj = HNicWMGkpKj[0]
				rK7um1MVit = HNicWMGkpKj.split(';')
				if 'region' in PEQBv9wdpSXqYRjK6I: TsVym12x9OYrzZUfwKbHG = '1_'
				elif 'category' in PEQBv9wdpSXqYRjK6I: TsVym12x9OYrzZUfwKbHG = '2_'
				elif 'language' in PEQBv9wdpSXqYRjK6I: TsVym12x9OYrzZUfwKbHG = '3_'
				elif 'country' in PEQBv9wdpSXqYRjK6I: TsVym12x9OYrzZUfwKbHG = '4_'
				else: TsVym12x9OYrzZUfwKbHG = '5_'
				pgrUmO8yuSEshoN5MC = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.replace('group="'+HNicWMGkpKj+'"','group="'+TsVym12x9OYrzZUfwKbHG+'~'+eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm+'"')
				d1daHcStye3mbCMl.append(pgrUmO8yuSEshoN5MC)
				for q4qfsInUtRDYlXdvTMe02xPNC in rK7um1MVit:
					pgrUmO8yuSEshoN5MC = k38Vi6PpwFNB7Aus1KErSLJaOdDvM.replace('group="'+HNicWMGkpKj+'"','group="'+TsVym12x9OYrzZUfwKbHG+q4qfsInUtRDYlXdvTMe02xPNC+'"')
					d1daHcStye3mbCMl.append(pgrUmO8yuSEshoN5MC)
			else: d1daHcStye3mbCMl.append(k38Vi6PpwFNB7Aus1KErSLJaOdDvM)
		rrfWsKPq4nzR0V7jFoNBHQe = d1daHcStye3mbCMl
		del d1daHcStye3mbCMl,ccLAbE39mBj2DInki8yU1TJhMR
	COkrtZg31VXpJNuschG8Y = 1024*1024
	ZZzsWx8leaiqKH5Pn7FQG2CT = 1+len(D1sJBj274KYWL)//COkrtZg31VXpJNuschG8Y//10
	del D1sJBj274KYWL
	CCLaKyTxzWtjMYEuNqn = len(rrfWsKPq4nzR0V7jFoNBHQe)
	ccLAbE39mBj2DInki8yU1TJhMR = LuHJknFyP3VhQNGfr1iwYg5v0X(rrfWsKPq4nzR0V7jFoNBHQe,ZZzsWx8leaiqKH5Pn7FQG2CT)
	del rrfWsKPq4nzR0V7jFoNBHQe
	for uvOaDl7f60HCwBiVKzes24 in range(ZZzsWx8leaiqKH5Pn7FQG2CT):
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,35+int(5*uvOaDl7f60HCwBiVKzes24/ZZzsWx8leaiqKH5Pn7FQG2CT),'تقطيع الملف الرئيسي','الجزء رقم:-',str(uvOaDl7f60HCwBiVKzes24+1)+' / '+str(ZZzsWx8leaiqKH5Pn7FQG2CT))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		w1YKkBmWtLRVGobu6v7S4x = str(ccLAbE39mBj2DInki8yU1TJhMR[uvOaDl7f60HCwBiVKzes24])
		if IZhXMprxvAHqBEFkg0: w1YKkBmWtLRVGobu6v7S4x = w1YKkBmWtLRVGobu6v7S4x.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		open(fvV4HSZqTK3LYzJ15BD+'.00'+str(uvOaDl7f60HCwBiVKzes24),'wb').write(w1YKkBmWtLRVGobu6v7S4x)
	del ccLAbE39mBj2DInki8yU1TJhMR,w1YKkBmWtLRVGobu6v7S4x
	KQzZbvohDksR4Cg,zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,f3phHmTd9wsvxGjD7SbJkIiRFB = [],[],0
	for uvOaDl7f60HCwBiVKzes24 in range(ZZzsWx8leaiqKH5Pn7FQG2CT):
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		w1YKkBmWtLRVGobu6v7S4x = open(fvV4HSZqTK3LYzJ15BD+'.00'+str(uvOaDl7f60HCwBiVKzes24),'rb').read()
		lQMuw1PvVpAk.sleep(1)
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(fvV4HSZqTK3LYzJ15BD+'.00'+str(uvOaDl7f60HCwBiVKzes24))
		except: pass
		if IZhXMprxvAHqBEFkg0: w1YKkBmWtLRVGobu6v7S4x = w1YKkBmWtLRVGobu6v7S4x.decode(zSafwK0sDXdMN5JReniIQmrZxp)
		d0OahBfrtQA42Upqyx9NbELYsKZTg = dr1zfnatJxRHSF48jh0eODm5bGu('list',w1YKkBmWtLRVGobu6v7S4x)
		del w1YKkBmWtLRVGobu6v7S4x
		AABDgbaTdl5ShcJWKGCeP1st0N7Ip,f3phHmTd9wsvxGjD7SbJkIiRFB,YBxbVzcRSI8 = H3HmDXTyWzoMi1gk(d0OahBfrtQA42Upqyx9NbELYsKZTg,EQ6L70JxAk,jWK8ehlA0gJQqSrp1ZBndN3DwI,TSPhMOnV81Y7J0QC4Xd,CCLaKyTxzWtjMYEuNqn,f3phHmTd9wsvxGjD7SbJkIiRFB,PEQBv9wdpSXqYRjK6I)
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		if not AABDgbaTdl5ShcJWKGCeP1st0N7Ip:
			TSPhMOnV81Y7J0QC4Xd.close()
			return
		zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s += AABDgbaTdl5ShcJWKGCeP1st0N7Ip
		KQzZbvohDksR4Cg += YBxbVzcRSI8
	del d0OahBfrtQA42Upqyx9NbELYsKZTg,AABDgbaTdl5ShcJWKGCeP1st0N7Ip
	GGzFWiTteIQranCwU03pHqgmLukMh9,YBxbVzcRSI8 = Uzwpo7NtJxq2IrA(zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,TSPhMOnV81Y7J0QC4Xd,atKPpEV8Oi7bxMq5FoYGe)
	if TSPhMOnV81Y7J0QC4Xd.iscanceled():
		TSPhMOnV81Y7J0QC4Xd.close()
		return
	KQzZbvohDksR4Cg += YBxbVzcRSI8
	del zCwuTqjEBvZ40xoP7gUWeDX2S8KV1s,YBxbVzcRSI8
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs = {},{},{},0,0
	KyZX2T4iaj = list(GGzFWiTteIQranCwU03pHqgmLukMh9.keys())
	wNG8sMaEZkFdDvYLTbnmP = len(KyZX2T4iaj)*3
	if 1:
		EERBxagV8muspkbzSvi = {}
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc] = eb6R0h1Fjl.Thread(target=ODxdYocVLi8Npl1vmEC0stnF,args=(GIplj3KhV8dc,))
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].start()
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].join()
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
	else:
		for GIplj3KhV8dc in KyZX2T4iaj:
			ODxdYocVLi8Npl1vmEC0stnF(GIplj3KhV8dc)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return
	jjIfEhLyl2wu9UGrcFe(gYJAT1vW0Uqm76G,atKPpEV8Oi7bxMq5FoYGe,False)
	KyZX2T4iaj = list(mpLu72Ngo05iSZe9B8MfdyHIRrbckY.keys())
	QQFPbVlYHgoq01jB4AR = 0
	if 1:
		EERBxagV8muspkbzSvi = {}
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc] = eb6R0h1Fjl.Thread(target=ggDeKCqEvYdGSMxOb,args=(gYJAT1vW0Uqm76G,GIplj3KhV8dc))
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].start()
		for GIplj3KhV8dc in KyZX2T4iaj:
			EERBxagV8muspkbzSvi[GIplj3KhV8dc].join()
		if TSPhMOnV81Y7J0QC4Xd.iscanceled():
			TSPhMOnV81Y7J0QC4Xd.close()
			return
	else:
		for GIplj3KhV8dc in KyZX2T4iaj:
			ggDeKCqEvYdGSMxOb(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return
	uvOaDl7f60HCwBiVKzes24 = 0
	WOQgRtJDouEx0njbyacF = len(KQzZbvohDksR4Cg)
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'IGNORED')
	for ufxmkS69YGXogyvWl in KQzZbvohDksR4Cg:
		if uvOaDl7f60HCwBiVKzes24%27==0:
			a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,95+int(5*uvOaDl7f60HCwBiVKzes24//WOQgRtJDouEx0njbyacF),'تخزين المهملة','الفيديو رقم:-',str(uvOaDl7f60HCwBiVKzes24)+' / '+str(WOQgRtJDouEx0njbyacF))
			if TSPhMOnV81Y7J0QC4Xd.iscanceled():
				TSPhMOnV81Y7J0QC4Xd.close()
				return
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'IGNORED_'+atKPpEV8Oi7bxMq5FoYGe,str(ufxmkS69YGXogyvWl),nbOFVEDkpT4BIR7Qq82yPmHeJU,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
		uvOaDl7f60HCwBiVKzes24 += 1
	z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'IGNORED_'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__',str(WOQgRtJDouEx0njbyacF),p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	TSPhMOnV81Y7J0QC4Xd.close()
	lQMuw1PvVpAk.sleep(1)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	return
def ODxdYocVLi8Npl1vmEC0stnF(GIplj3KhV8dc):
	global TSPhMOnV81Y7J0QC4Xd,GGzFWiTteIQranCwU03pHqgmLukMh9,QQFPbVlYHgoq01jB4AR,mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs,wNG8sMaEZkFdDvYLTbnmP
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc] = {}
	Ru3NyaKDq2YG6STV,hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = {},[]
	yoBXj8AKERtsSYIUmPrnGc37dFi = len(GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc])
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc]['__COUNT__'] = yoBXj8AKERtsSYIUmPrnGc37dFi
	if yoBXj8AKERtsSYIUmPrnGc37dFi>0:
		H0qCfYcWhi,YhJjdcN7kA0iR3rlgI261vB4bE,P3na1yCjSMk,ZKphALGOFVzoi59HJxcW,DD9NdGbpRmqCn = zip(*GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc])
		del YhJjdcN7kA0iR3rlgI261vB4bE,P3na1yCjSMk,ZKphALGOFVzoi59HJxcW
		rK7um1MVit = list(set(H0qCfYcWhi))
		for q4qfsInUtRDYlXdvTMe02xPNC in rK7um1MVit:
			Ru3NyaKDq2YG6STV[q4qfsInUtRDYlXdvTMe02xPNC] = nbOFVEDkpT4BIR7Qq82yPmHeJU
			mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc][q4qfsInUtRDYlXdvTMe02xPNC] = []
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,60+int(15*XPhNf1tAcH32oiBs//wNG8sMaEZkFdDvYLTbnmP),'تصنيع القوائم','الجزء رقم:-',str(XPhNf1tAcH32oiBs)+' / '+str(wNG8sMaEZkFdDvYLTbnmP))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
		XPhNf1tAcH32oiBs += 1
		LIH2VQTDdNK8F1e = len(rK7um1MVit)
		del rK7um1MVit
		hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = list(set(zip(H0qCfYcWhi,DD9NdGbpRmqCn)))
		del H0qCfYcWhi,DD9NdGbpRmqCn
		for q4qfsInUtRDYlXdvTMe02xPNC,gwLmtlCDM6uq0EnWoNUx in hGAZxNk0jCEVboMLmXUtpO8lDK7H1T:
			if not Ru3NyaKDq2YG6STV[q4qfsInUtRDYlXdvTMe02xPNC] and gwLmtlCDM6uq0EnWoNUx: Ru3NyaKDq2YG6STV[q4qfsInUtRDYlXdvTMe02xPNC] = gwLmtlCDM6uq0EnWoNUx
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,60+int(15*XPhNf1tAcH32oiBs//wNG8sMaEZkFdDvYLTbnmP),'تصنيع القوائم','الجزء رقم:-',str(XPhNf1tAcH32oiBs)+' / '+str(wNG8sMaEZkFdDvYLTbnmP))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
		XPhNf1tAcH32oiBs += 1
		ih7xlHqCEf0s = list(Ru3NyaKDq2YG6STV.keys())
		QSBTVJnY5pAlFdEhMiyzH4GN = list(Ru3NyaKDq2YG6STV.values())
		del Ru3NyaKDq2YG6STV
		hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = list(zip(ih7xlHqCEf0s,QSBTVJnY5pAlFdEhMiyzH4GN))
		del ih7xlHqCEf0s,QSBTVJnY5pAlFdEhMiyzH4GN
		hGAZxNk0jCEVboMLmXUtpO8lDK7H1T = sorted(hGAZxNk0jCEVboMLmXUtpO8lDK7H1T)
	else: XPhNf1tAcH32oiBs += 2
	mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc]['__GROUPS__'] = hGAZxNk0jCEVboMLmXUtpO8lDK7H1T
	del hGAZxNk0jCEVboMLmXUtpO8lDK7H1T
	for q4qfsInUtRDYlXdvTMe02xPNC,R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc]:
		mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc][q4qfsInUtRDYlXdvTMe02xPNC].append((R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD))
	a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,60+int(15*XPhNf1tAcH32oiBs//wNG8sMaEZkFdDvYLTbnmP),'تصنيع القوائم','الجزء رقم:-',str(XPhNf1tAcH32oiBs)+' / '+str(wNG8sMaEZkFdDvYLTbnmP))
	if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
	XPhNf1tAcH32oiBs += 1
	del GGzFWiTteIQranCwU03pHqgmLukMh9[GIplj3KhV8dc]
	HNicWMGkpKj[GIplj3KhV8dc] = list(mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc].keys())
	STZLyQr47Wl5up[GIplj3KhV8dc] = len(HNicWMGkpKj[GIplj3KhV8dc])
	zdFt6xPkcXMG += STZLyQr47Wl5up[GIplj3KhV8dc]
	return
def ggDeKCqEvYdGSMxOb(gYJAT1vW0Uqm76G,GIplj3KhV8dc):
	global TSPhMOnV81Y7J0QC4Xd,GGzFWiTteIQranCwU03pHqgmLukMh9,QQFPbVlYHgoq01jB4AR,mpLu72Ngo05iSZe9B8MfdyHIRrbckY,STZLyQr47Wl5up,HNicWMGkpKj,zdFt6xPkcXMG,XPhNf1tAcH32oiBs,wNG8sMaEZkFdDvYLTbnmP
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc)
	for f3phHmTd9wsvxGjD7SbJkIiRFB in range(1+STZLyQr47Wl5up[GIplj3KhV8dc]//273):
		LXj7f1gKQ9GVprHevm6bZaq3NAz5 = []
		TuBmbRMoOas8PketF = HNicWMGkpKj[GIplj3KhV8dc][0:273]
		for q4qfsInUtRDYlXdvTMe02xPNC in TuBmbRMoOas8PketF:
			LXj7f1gKQ9GVprHevm6bZaq3NAz5.append(mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc][q4qfsInUtRDYlXdvTMe02xPNC])
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,GIplj3KhV8dc,TuBmbRMoOas8PketF,LXj7f1gKQ9GVprHevm6bZaq3NAz5,p2CSGfkREb6TuDtas9yFPrU1e3NWL7,True)
		QQFPbVlYHgoq01jB4AR += len(TuBmbRMoOas8PketF)
		a46aOmKBsRw7W3MyCvurG5TqFt2fQI(TSPhMOnV81Y7J0QC4Xd,75+int(20*QQFPbVlYHgoq01jB4AR//zdFt6xPkcXMG),'تخزين القوائم','القائمة رقم:-',str(QQFPbVlYHgoq01jB4AR)+' / '+str(zdFt6xPkcXMG))
		if TSPhMOnV81Y7J0QC4Xd.iscanceled(): return
		del HNicWMGkpKj[GIplj3KhV8dc][0:273]
	del mpLu72Ngo05iSZe9B8MfdyHIRrbckY[GIplj3KhV8dc],HNicWMGkpKj[GIplj3KhV8dc],STZLyQr47Wl5up[GIplj3KhV8dc]
	return
def eL6JlI0X94nyamjOAhu3U1BDgic(gYJAT1vW0Uqm76G,atKPpEV8Oi7bxMq5FoYGe,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	d5VIrOEM2YB0bapqyKuoULxztH = 'عدد فيديوهات جميع الروابط'
	R61bxdlGBQL = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'LIVE_ORIGINAL_GROUPED')
	KHD5rTSRQLMuBAchv2YW = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'VOD_ORIGINAL_GROUPED')
	if atKPpEV8Oi7bxMq5FoYGe:
		d5VIrOEM2YB0bapqyKuoULxztH = 'عدد فيديوهات رابط '+rto0iz1Gk2xAmICHDhqR6FPnMK[int(atKPpEV8Oi7bxMq5FoYGe)]
		atKPpEV8Oi7bxMq5FoYGe = '_'+atKPpEV8Oi7bxMq5FoYGe
	WOQgRtJDouEx0njbyacF = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','IGNORED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	lyjmRYxDo52Zs7vLgIVEAt = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','LIVE_ORIGINAL_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	vvjYEtHTpnwFM7h9aXVeq0briByK = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(KHD5rTSRQLMuBAchv2YW,'int','VOD_ORIGINAL_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	EEFyB9Vb5QLCUexSMzD1vT3ncfX = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','LIVE_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	rrP4w1Ing7MvxGRdDAoTe = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','LIVE_UNKNOWN_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	uuZkPLKWR6HdIeOmxy5jF34T80pfq = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','VOD_MOVIES_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	iwmonTO1PbYylpK7 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(KHD5rTSRQLMuBAchv2YW,'int','VOD_SERIES_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	VpYDoAxWe2dwQh6UJHyqrBuG1vl4 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(R61bxdlGBQL,'int','VOD_UNKNOWN_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__COUNT__')
	HNicWMGkpKj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(KHD5rTSRQLMuBAchv2YW,'list','VOD_SERIES_GROUPED'+atKPpEV8Oi7bxMq5FoYGe,'__GROUPS__')
	HFkBmoSulMJd8P2cIT = []
	for q4qfsInUtRDYlXdvTMe02xPNC,ayoEi7YNWD in HNicWMGkpKj:
		LPD5TGbrIfQqkl6tyKw7j = q4qfsInUtRDYlXdvTMe02xPNC.split('__SERIES__')[1]
		HFkBmoSulMJd8P2cIT.append(LPD5TGbrIfQqkl6tyKw7j)
	IzqrSWJaFAcYLC = len(HFkBmoSulMJd8P2cIT)
	WWXzI34UZEqYhf25uxJwLVo = int(uuZkPLKWR6HdIeOmxy5jF34T80pfq)+int(iwmonTO1PbYylpK7)+int(VpYDoAxWe2dwQh6UJHyqrBuG1vl4)+int(rrP4w1Ing7MvxGRdDAoTe)+int(EEFyB9Vb5QLCUexSMzD1vT3ncfX)
	aYRULC8dGNTo0eAmFcjW7 = nbOFVEDkpT4BIR7Qq82yPmHeJU
	aYRULC8dGNTo0eAmFcjW7 += 'قنوات: '+str(EEFyB9Vb5QLCUexSMzD1vT3ncfX)
	aYRULC8dGNTo0eAmFcjW7 += '   .   أفلام: '+str(uuZkPLKWR6HdIeOmxy5jF34T80pfq)
	aYRULC8dGNTo0eAmFcjW7 += '\nمسلسلات: '+str(IzqrSWJaFAcYLC)
	aYRULC8dGNTo0eAmFcjW7 += '   .   حلقات: '+str(iwmonTO1PbYylpK7)
	aYRULC8dGNTo0eAmFcjW7 += '\nقنوات مجهولة: '+str(rrP4w1Ing7MvxGRdDAoTe)
	aYRULC8dGNTo0eAmFcjW7 += '   .   فيدوهات مجهولة: '+str(VpYDoAxWe2dwQh6UJHyqrBuG1vl4)
	aYRULC8dGNTo0eAmFcjW7 += '\nمجموع القنوات: '+str(lyjmRYxDo52Zs7vLgIVEAt)
	aYRULC8dGNTo0eAmFcjW7 += '   .   مجموع الفيديوهات: '+str(vvjYEtHTpnwFM7h9aXVeq0briByK)
	aYRULC8dGNTo0eAmFcjW7 += '\n\nمجموع المضافة: '+str(WWXzI34UZEqYhf25uxJwLVo)
	aYRULC8dGNTo0eAmFcjW7 += '   .   مجموع المهملة: '+str(WOQgRtJDouEx0njbyacF)
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep: aY7RFmnWc5uU9T3Q0Mxq4('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,d5VIrOEM2YB0bapqyKuoULxztH,aYRULC8dGNTo0eAmFcjW7)
	II7uWs8plOi9AjmCH3NR = aYRULC8dGNTo0eAmFcjW7.replace('\n\n',wwOnIucWJj)
	if not atKPpEV8Oi7bxMq5FoYGe: atKPpEV8Oi7bxMq5FoYGe = 'All'
	else: atKPpEV8Oi7bxMq5FoYGe = atKPpEV8Oi7bxMq5FoYGe[1]
	fGBlEmQTwiAJt7rCYIxyau3jRh(IISwOZ2BxkPv3yM,'.\tCounts of M3U videos   Folder: '+gYJAT1vW0Uqm76G+'   Sequence: '+atKPpEV8Oi7bxMq5FoYGe+wwOnIucWJj+II7uWs8plOi9AjmCH3NR)
	return aYRULC8dGNTo0eAmFcjW7
def jjIfEhLyl2wu9UGrcFe(gYJAT1vW0Uqm76G,atKPpEV8Oi7bxMq5FoYGe,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'مسح ملفات M3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if JvOL5Wr9s6!=1: return
		nTOU6Iu7oFf = mEbtRoNBzaGf1KAuLUW6n4Sh3C.replace('___','_'+gYJAT1vW0Uqm76G+'_'+atKPpEV8Oi7bxMq5FoYGe)
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(nTOU6Iu7oFf)
		except: pass
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if atKPpEV8Oi7bxMq5FoYGe:
		fZKzr47sNFSQRvd1 = []
		for bgj8L5UlSPnO9X3N in GUf84z2bdKlc7PpywoNrDVg:
			fZKzr47sNFSQRvd1.append(bgj8L5UlSPnO9X3N+'_'+atKPpEV8Oi7bxMq5FoYGe)
		uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,'LINK_'+atKPpEV8Oi7bxMq5FoYGe)
	else:
		fZKzr47sNFSQRvd1 = GUf84z2bdKlc7PpywoNrDVg
		uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,'DUMMY')
		uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,'GROUPS')
		uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,'ITEMS')
		uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,'SEARCH')
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'SECTIONS_M3U','SECTIONS_M3U_'+gYJAT1vW0Uqm76G)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	for GIplj3KhV8dc in fZKzr47sNFSQRvd1:
		uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,GIplj3KhV8dc)
	kYaRIGV5T7Zvfbq3WKpmQwJiBg(False)
	G9nYDmlrhKk(gYJAT1vW0Uqm76G)
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep: aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
	return
def a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G=nbOFVEDkpT4BIR7Qq82yPmHeJU,O3asTXHd4Jm2KCQRUwvbtE8fuDAep=True):
	if gYJAT1vW0Uqm76G:
		nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(str(gYJAT1vW0Uqm76G),'DUMMY')
		RQg7AUDOp6MJtWwdba3VFYZ1XHokE = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'str','DUMMY','__DUMMY__')
		if RQg7AUDOp6MJtWwdba3VFYZ1XHokE: return True
	else:
		gYJAT1vW0Uqm76G = '1'
		for DnWF2omGyk4EpQP81q9uviZs in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(str(DnWF2omGyk4EpQP81q9uviZs),'DUMMY')
			RQg7AUDOp6MJtWwdba3VFYZ1XHokE = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'str','DUMMY','__DUMMY__')
			if RQg7AUDOp6MJtWwdba3VFYZ1XHokE: return True
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		HNZbL5OAew = 'https://iptv-org.github.io/iptv/index.region.m3u'
		Onpr5oVSDGa = 'https://iptv-org.github.io/iptv/index.category.m3u'
		LLpuNAJdRqE8Z0 = 'https://iptv-org.github.io/iptv/index.language.m3u'
		TIkv4VAQ9qeSjsZC3zL = 'https://iptv-org.github.io/iptv/index.country.m3u'
		S1vw6nOKbqsx2lW = HNZbL5OAew+wwOnIucWJj+Onpr5oVSDGa+wwOnIucWJj+LLpuNAJdRqE8Z0+wwOnIucWJj+TIkv4VAQ9qeSjsZC3zL
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','هذا الجزء من البرنامج يحتاج رابط فيديوهات نوعه M3U ومتوفر في الإنترنت مجانا وأيضا ممكن شراءه من الشركات المختصة . الموقع أدناه فيه روابط مجانية وهي ليست ملك المبرمج (صاحب هذا البرنامج) . ولا علاقة للمبرمج بمحتوياتها . والمبرمج لا يتحمل أي مسؤولية بسبب استخدام أي روابط مجانية أو غير مجانية\n'+eMypvI8XqHjYU02anWD9gsSrkt+'http://github.com/iptv-org/iptv'+c7gxFyUCGm+'\nالروابط أدناه مجانية ومأخوذة من الموقع أعلاه هل تريد استخدامها\n '+eMypvI8XqHjYU02anWD9gsSrkt+S1vw6nOKbqsx2lW+c7gxFyUCGm,profile='confirm_mediumfont')
		if JvOL5Wr9s6==1:
			llnG7jiQBYKhAeovbT.setSetting('av.m3u.url_'+str(gYJAT1vW0Uqm76G)+'_1',HNZbL5OAew)
			llnG7jiQBYKhAeovbT.setSetting('av.m3u.url_'+str(gYJAT1vW0Uqm76G)+'_2',Onpr5oVSDGa)
			llnG7jiQBYKhAeovbT.setSetting('av.m3u.url_'+str(gYJAT1vW0Uqm76G)+'_3',LLpuNAJdRqE8Z0)
			llnG7jiQBYKhAeovbT.setSetting('av.m3u.url_'+str(gYJAT1vW0Uqm76G)+'_4',TIkv4VAQ9qeSjsZC3zL)
			JvOL5Wr9s6 = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','للاستفادة من روابط M3U التي أنت أضفتها للبرنامج .. أنت بحاجة إلى جلب ملفات هذه الروابط الجديدة .. هل تريد الآن جلب ملفات روابط M3U التي أنت أضفتها للبرنامج ؟!')
			if JvOL5Wr9s6==1:
				BzNsVHn2fjki = CvZgpnA1PF2YS9JeN6(gYJAT1vW0Uqm76G)
				return BzNsVHn2fjki
		else:
			d5VIrOEM2YB0bapqyKuoULxztH = 'إضافة وتغيير رابط '+rto0iz1Gk2xAmICHDhqR6FPnMK[1]+' (مجلد '+rto0iz1Gk2xAmICHDhqR6FPnMK[int(gYJAT1vW0Uqm76G)]+')'
			JvOL5Wr9s6 = ttiZs4bKHFvugJj5z(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,d5VIrOEM2YB0bapqyKuoULxztH,'لإضافة رابط M3U .. أولا أفتح قائمة M3U .. وثانيا أنقر على إضافة رابط أو اشتراك M3U .. وثالثا أنقر على جلب ملفات ـM3U \n\n هل تريد إضافة أو تغيير رابط M3U الآن ؟!')
			if JvOL5Wr9s6==1: E0PNDIAiaYkKRpx(gYJAT1vW0Uqm76G,'1')
	return False
def CCLlhnQdcKiA(REapuWow7yZ4KPInfHMY0Q6rF1D9X,gYJAT1vW0Uqm76G=nbOFVEDkpT4BIR7Qq82yPmHeJU,GIplj3KhV8dc=nbOFVEDkpT4BIR7Qq82yPmHeJU,GGyLnP8egKaM9Oxr=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,Hg9iNXSxJobPBr,O3asTXHd4Jm2KCQRUwvbtE8fuDAep = hKjNwk3Bfpa48Om7JQz(REapuWow7yZ4KPInfHMY0Q6rF1D9X)
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ:
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = dR75Vq2gprfHmUcNhG()
		if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ: return
	PPlpIDTx9QgskwLEKG = [nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not GIplj3KhV8dc:
		if not O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
			if   '_M3U-LIVE_' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[1]
			elif '_M3U-MOVIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[2]
			elif '_M3U-SERIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[3]
			else: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[0]
		else:
			uZCt5mQhcLIspfaDEjYSdlRUby9k = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			CH74LFlzUW3gkcxe2P = nnRXQH90qeOtABkJzGr('أختر البحث المناسب', uZCt5mQhcLIspfaDEjYSdlRUby9k)
			if CH74LFlzUW3gkcxe2P==-1: return
			GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[CH74LFlzUW3gkcxe2P]
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+'_NODIALOGS_'
	if gYJAT1vW0Uqm76G: Cndl86Apt9owz(B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,gYJAT1vW0Uqm76G,GIplj3KhV8dc,GGyLnP8egKaM9Oxr)
	else:
		for gYJAT1vW0Uqm76G in range(1,ll3QVqcTKFM8vygt9GAoJRDWe+1):
			Cndl86Apt9owz(B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,str(gYJAT1vW0Uqm76G),GIplj3KhV8dc,GGyLnP8egKaM9Oxr)
		LvJuOzMqk6WlP971eoGpUQ8[:] = sorted(LvJuOzMqk6WlP971eoGpUQ8,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[1].lower())
	return
def Cndl86Apt9owz(REapuWow7yZ4KPInfHMY0Q6rF1D9X,gYJAT1vW0Uqm76G,GIplj3KhV8dc=nbOFVEDkpT4BIR7Qq82yPmHeJU,GGyLnP8egKaM9Oxr=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ,Hg9iNXSxJobPBr,O3asTXHd4Jm2KCQRUwvbtE8fuDAep = hKjNwk3Bfpa48Om7JQz(REapuWow7yZ4KPInfHMY0Q6rF1D9X)
	if not gYJAT1vW0Uqm76G: return
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep): return
	if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ:
		B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ = dR75Vq2gprfHmUcNhG()
		if not B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ: return
	PPlpIDTx9QgskwLEKG = [nbOFVEDkpT4BIR7Qq82yPmHeJU,'LIVE_GROUPED_SORTED','VOD_MOVIES_GROUPED_SORTED','VOD_SERIES_GROUPED_SORTED','VOD_UNKNOWN_GROUPED_SORTED','LIVE_UNKNOWN_GROUPED_SORTED']
	if not GIplj3KhV8dc:
		if not O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
			if   '_M3U-LIVE_' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[1]
			elif '_M3U-MOVIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[2]
			elif '_M3U-SERIES' in Hg9iNXSxJobPBr: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[3]
			else: GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[0]
		else:
			uZCt5mQhcLIspfaDEjYSdlRUby9k = ['الكل','قنوات','أفلام','مسلسلات','فيديوهات مجهولة','قنوات مجهولة']
			CH74LFlzUW3gkcxe2P = nnRXQH90qeOtABkJzGr('أختر البحث المناسب', uZCt5mQhcLIspfaDEjYSdlRUby9k)
			if CH74LFlzUW3gkcxe2P==-1: return
			GIplj3KhV8dc = PPlpIDTx9QgskwLEKG[CH74LFlzUW3gkcxe2P]
	ifhaDezHjto9nguTb1FNdk6 = B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ.lower()
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,'SEARCH')
	UmwA0cdOSg2s7vnKR8zYp4ohWqH = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list','SEARCH',(GIplj3KhV8dc,ifhaDezHjto9nguTb1FNdk6))
	if not UmwA0cdOSg2s7vnKR8zYp4ohWqH:
		lQ29zeOVXw,ssAvE2pguQBDtMfHLO = [],[]
		if not GIplj3KhV8dc: IAq1bUPgkdlWhYQ = [1,2,3,4,5]
		else: IAq1bUPgkdlWhYQ = [PPlpIDTx9QgskwLEKG.index(GIplj3KhV8dc)]
		for uvOaDl7f60HCwBiVKzes24 in IAq1bUPgkdlWhYQ:
			if uvOaDl7f60HCwBiVKzes24!=3:
				AABDgbaTdl5ShcJWKGCeP1st0N7Ip = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'dict',PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24])
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip['__COUNT__']
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip['__GROUPS__']
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip['__SEQUENCED_COLUMNS__']
				HNicWMGkpKj = list(AABDgbaTdl5ShcJWKGCeP1st0N7Ip.keys())
				for q4qfsInUtRDYlXdvTMe02xPNC in HNicWMGkpKj:
					for R0gbu46Cw9ZKhB5jsT8HAcGv,GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in AABDgbaTdl5ShcJWKGCeP1st0N7Ip[q4qfsInUtRDYlXdvTMe02xPNC]:
						if ifhaDezHjto9nguTb1FNdk6 in GdbFDygsZ6HopImiSTY53.lower(): ssAvE2pguQBDtMfHLO.append((GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD))
					del AABDgbaTdl5ShcJWKGCeP1st0N7Ip[q4qfsInUtRDYlXdvTMe02xPNC]
				del AABDgbaTdl5ShcJWKGCeP1st0N7Ip
			else: HNicWMGkpKj = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'list',PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24],'__GROUPS__')
			for q4qfsInUtRDYlXdvTMe02xPNC in HNicWMGkpKj:
				try: q4qfsInUtRDYlXdvTMe02xPNC,ayoEi7YNWD = q4qfsInUtRDYlXdvTMe02xPNC
				except: ayoEi7YNWD = nbOFVEDkpT4BIR7Qq82yPmHeJU
				if ifhaDezHjto9nguTb1FNdk6 in q4qfsInUtRDYlXdvTMe02xPNC.lower():
					if uvOaDl7f60HCwBiVKzes24!=3: gghz95uYRpMPZjB2HqnfF73 = q4qfsInUtRDYlXdvTMe02xPNC
					else:
						b2VJoUNBzi4OYdF,pPFrIbNGX8sSMTQt6HWaEwu4eqO = q4qfsInUtRDYlXdvTMe02xPNC.split('__SERIES__')
						if ifhaDezHjto9nguTb1FNdk6 in b2VJoUNBzi4OYdF.lower(): gghz95uYRpMPZjB2HqnfF73 = b2VJoUNBzi4OYdF
						else: gghz95uYRpMPZjB2HqnfF73 = pPFrIbNGX8sSMTQt6HWaEwu4eqO
					lQ29zeOVXw.append((q4qfsInUtRDYlXdvTMe02xPNC,gghz95uYRpMPZjB2HqnfF73,PPlpIDTx9QgskwLEKG[uvOaDl7f60HCwBiVKzes24],ayoEi7YNWD))
			del HNicWMGkpKj
		lQ29zeOVXw = set(lQ29zeOVXw)
		ssAvE2pguQBDtMfHLO = set(ssAvE2pguQBDtMfHLO)
		lQ29zeOVXw = sorted(lQ29zeOVXw,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[1])
		ssAvE2pguQBDtMfHLO = sorted(ssAvE2pguQBDtMfHLO,reverse=False,key=lambda dvhs8lngSEQTyr4a7YwjkFVcWope: dvhs8lngSEQTyr4a7YwjkFVcWope[0])
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'SEARCH',(GIplj3KhV8dc,ifhaDezHjto9nguTb1FNdk6),(lQ29zeOVXw,ssAvE2pguQBDtMfHLO),p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	else: lQ29zeOVXw,ssAvE2pguQBDtMfHLO = UmwA0cdOSg2s7vnKR8zYp4ohWqH
	HNicWMGkpKj = len(lQ29zeOVXw)
	iiAzsFfwVUb5NMEpQgc = len(ssAvE2pguQBDtMfHLO)
	jwQ1lvmx6hFoet7N5OViJITA4GdZ0c = int(GGyLnP8egKaM9Oxr)
	ntXZPTIdsE = max(0,(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c-1)*100)
	UkzBlVnPmK7YZwbS9XRJ3y = max(0,jwQ1lvmx6hFoet7N5OViJITA4GdZ0c*100)
	kcoQwFqjBKMHmy = max(0,ntXZPTIdsE-HNicWMGkpKj)
	wJIyBq3KCLaikUhu6TW18VY9tjNxfv = max(0,UkzBlVnPmK7YZwbS9XRJ3y-HNicWMGkpKj)
	for q4qfsInUtRDYlXdvTMe02xPNC,gghz95uYRpMPZjB2HqnfF73,t1tNgfOleUy5XABvxzSDmRaq7w2G,ayoEi7YNWD in lQ29zeOVXw[ntXZPTIdsE:UkzBlVnPmK7YZwbS9XRJ3y]:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+gghz95uYRpMPZjB2HqnfF73,t1tNgfOleUy5XABvxzSDmRaq7w2G,714,ayoEi7YNWD,'1',q4qfsInUtRDYlXdvTMe02xPNC,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	del lQ29zeOVXw
	for GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,ayoEi7YNWD in ssAvE2pguQBDtMfHLO[kcoQwFqjBKMHmy:wJIyBq3KCLaikUhu6TW18VY9tjNxfv]:
		Lbo2sDymGU8Mc0dgjnhBOvIXWNJEP = JoEms64VZ1ldaf9NYBgcKCFL(wNyZhHdvUeC3M)
		iiyAEbQ5f80 = 'live'
		if '.mkv' in Lbo2sDymGU8Mc0dgjnhBOvIXWNJEP or 'VOD' in GIplj3KhV8dc: iiyAEbQ5f80 = 'video'
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj(iiyAEbQ5f80,PPZDQo6RAG3a0Ot1Ydc5Fwz+GdbFDygsZ6HopImiSTY53,wNyZhHdvUeC3M,715,ayoEi7YNWD,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	del ssAvE2pguQBDtMfHLO
	E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,719,HNicWMGkpKj+iiAzsFfwVUb5NMEpQgc,B5HmfI7Fd1vKeGUlV4itwnJaPAuNjQ+'_NODIALOGS_')
	return
def E5n326fs9o8Z0ibU(gYJAT1vW0Uqm76G,GGyLnP8egKaM9Oxr,GIplj3KhV8dc,EYMmnJAyxV,WWXzI34UZEqYhf25uxJwLVo,J1rvN7I8eLXuS54mZ6lnUjg):
	if not GGyLnP8egKaM9Oxr: GGyLnP8egKaM9Oxr = '1'
	if GGyLnP8egKaM9Oxr!='1': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'صفحة '+str(1),GIplj3KhV8dc,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(1),J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	if not WWXzI34UZEqYhf25uxJwLVo: WWXzI34UZEqYhf25uxJwLVo = 0
	F4qYux1pl7BNG0feJRbOSPhKc9CV5A = int(WWXzI34UZEqYhf25uxJwLVo/100)+1
	for jwQ1lvmx6hFoet7N5OViJITA4GdZ0c in range(2,F4qYux1pl7BNG0feJRbOSPhKc9CV5A):
		ii8MX4g6Jpmzy0rh7u = (jwQ1lvmx6hFoet7N5OViJITA4GdZ0c%10==0 or int(GGyLnP8egKaM9Oxr)-4<jwQ1lvmx6hFoet7N5OViJITA4GdZ0c<int(GGyLnP8egKaM9Oxr)+4)
		JfYeiqVQ1F7ZWp9 = (ii8MX4g6Jpmzy0rh7u and int(GGyLnP8egKaM9Oxr)-40<jwQ1lvmx6hFoet7N5OViJITA4GdZ0c<int(GGyLnP8egKaM9Oxr)+40)
		if str(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c)!=GGyLnP8egKaM9Oxr and (jwQ1lvmx6hFoet7N5OViJITA4GdZ0c%100==0 or JfYeiqVQ1F7ZWp9):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'صفحة '+str(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c),GIplj3KhV8dc,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(jwQ1lvmx6hFoet7N5OViJITA4GdZ0c),J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	if str(F4qYux1pl7BNG0feJRbOSPhKc9CV5A)!=GGyLnP8egKaM9Oxr: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',PPZDQo6RAG3a0Ot1Ydc5Fwz+'أخر صفحة '+str(F4qYux1pl7BNG0feJRbOSPhKc9CV5A),GIplj3KhV8dc,EYMmnJAyxV,nbOFVEDkpT4BIR7Qq82yPmHeJU,str(F4qYux1pl7BNG0feJRbOSPhKc9CV5A),J1rvN7I8eLXuS54mZ6lnUjg,nbOFVEDkpT4BIR7Qq82yPmHeJU,{'folder':gYJAT1vW0Uqm76G})
	return
def JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,GIplj3KhV8dc):
	nHXBLNq37CIjZvQDw = x3x6InJLgoyuNW2jOe5tzXKAhdYCmE.replace('___','_'+gYJAT1vW0Uqm76G)
	return nHXBLNq37CIjZvQDw
def CvZgpnA1PF2YS9JeN6(gYJAT1vW0Uqm76G):
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','جلب ملفات M3U جديدة قد تحتاج عدة دقائق .. هل تريد أن تجلب الملفات الآن ؟!')
	if JvOL5Wr9s6!=1: return False
	CSLw0gKhVD(gYJAT1vW0Uqm76G,False)
	H6oc32lZNiOzUvPVCpyu4s1wab5 = [0]
	for UUfw8Ld24pDl5xbHRhe in range(1,s9uG4cZBdagX1SF5q2P+1):
		XSs23UuGCgOPATm7hY = llnG7jiQBYKhAeovbT.getSetting('av.m3u.url_'+gYJAT1vW0Uqm76G+'_'+str(UUfw8Ld24pDl5xbHRhe))
		if XSs23UuGCgOPATm7hY: V8YhRNmegG(gYJAT1vW0Uqm76G,str(UUfw8Ld24pDl5xbHRhe))
		H6oc32lZNiOzUvPVCpyu4s1wab5.append(0)
	for GIplj3KhV8dc in GUf84z2bdKlc7PpywoNrDVg:
		Zz5n3A6Usdw9Fm,ksuGDKc8Qr46dHLfzhNe05BX23mC,b8EvfiHmKsQgce0Dy3uzXhW9R,VvpOYjItEq1BN,Ru3NyaKDq2YG6STV = 0,{},[],[],[]
		for UUfw8Ld24pDl5xbHRhe in range(1,s9uG4cZBdagX1SF5q2P+1):
			t1tNgfOleUy5XABvxzSDmRaq7w2G = GIplj3KhV8dc+'_'+str(UUfw8Ld24pDl5xbHRhe)
			GGzFWiTteIQranCwU03pHqgmLukMh9 = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'dict',t1tNgfOleUy5XABvxzSDmRaq7w2G)
			try:
				nLlOP7dBr8S6pXfwx = GGzFWiTteIQranCwU03pHqgmLukMh9['__GROUPS__']
				EESRd0rNUVBQoX8F1 = GGzFWiTteIQranCwU03pHqgmLukMh9['__COUNT__']
			except: nLlOP7dBr8S6pXfwx,EESRd0rNUVBQoX8F1 = [],'0'
			for zDZv0H4IjP in nLlOP7dBr8S6pXfwx:
				q4qfsInUtRDYlXdvTMe02xPNC,gwLmtlCDM6uq0EnWoNUx = zDZv0H4IjP
				AABDgbaTdl5ShcJWKGCeP1st0N7Ip = GGzFWiTteIQranCwU03pHqgmLukMh9[q4qfsInUtRDYlXdvTMe02xPNC]
				if q4qfsInUtRDYlXdvTMe02xPNC not in VvpOYjItEq1BN:
					VvpOYjItEq1BN.append(q4qfsInUtRDYlXdvTMe02xPNC)
					Ru3NyaKDq2YG6STV.append(zDZv0H4IjP)
					ksuGDKc8Qr46dHLfzhNe05BX23mC[q4qfsInUtRDYlXdvTMe02xPNC] = []
				ksuGDKc8Qr46dHLfzhNe05BX23mC[q4qfsInUtRDYlXdvTMe02xPNC] += AABDgbaTdl5ShcJWKGCeP1st0N7Ip
			uoxvtFlSXEPnf(nHXBLNq37CIjZvQDw,t1tNgfOleUy5XABvxzSDmRaq7w2G)
			z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,t1tNgfOleUy5XABvxzSDmRaq7w2G,'__COUNT__',EESRd0rNUVBQoX8F1,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
			H6oc32lZNiOzUvPVCpyu4s1wab5[UUfw8Ld24pDl5xbHRhe] += int(EESRd0rNUVBQoX8F1)
		for q4qfsInUtRDYlXdvTMe02xPNC in VvpOYjItEq1BN:
			AABDgbaTdl5ShcJWKGCeP1st0N7Ip = list(set(ksuGDKc8Qr46dHLfzhNe05BX23mC[q4qfsInUtRDYlXdvTMe02xPNC]))
			if 'SORTED' in GIplj3KhV8dc: AABDgbaTdl5ShcJWKGCeP1st0N7Ip = sorted(AABDgbaTdl5ShcJWKGCeP1st0N7Ip,reverse=False,key=lambda key: key[1].lower())
			Zz5n3A6Usdw9Fm += len(AABDgbaTdl5ShcJWKGCeP1st0N7Ip)
			b8EvfiHmKsQgce0Dy3uzXhW9R.append(AABDgbaTdl5ShcJWKGCeP1st0N7Ip)
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,GIplj3KhV8dc,'__COUNT__',str(Zz5n3A6Usdw9Fm),p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,GIplj3KhV8dc,'__GROUPS__',Ru3NyaKDq2YG6STV,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
		z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,GIplj3KhV8dc,VvpOYjItEq1BN,b8EvfiHmKsQgce0Dy3uzXhW9R,p2CSGfkREb6TuDtas9yFPrU1e3NWL7,True)
	hHpWI5SMZaq8X9Az2G0 = False
	for UUfw8Ld24pDl5xbHRhe in range(1,s9uG4cZBdagX1SF5q2P+1):
		if int(H6oc32lZNiOzUvPVCpyu4s1wab5[UUfw8Ld24pDl5xbHRhe])>0:
			XSs23UuGCgOPATm7hY = llnG7jiQBYKhAeovbT.getSetting('av.m3u.url_'+gYJAT1vW0Uqm76G+'_'+str(UUfw8Ld24pDl5xbHRhe))
			z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'LINK_'+str(UUfw8Ld24pDl5xbHRhe),'__LINK__',XSs23UuGCgOPATm7hY,p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
			hHpWI5SMZaq8X9Az2G0 = True
	z0ht1Nk9DRHx7PAan(nHXBLNq37CIjZvQDw,'DUMMY','__DUMMY__','DUMMY',p2CSGfkREb6TuDtas9yFPrU1e3NWL7)
	if not hHpWI5SMZaq8X9Az2G0:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','فشل بسحب ملفات M3U .. أحتمال روابط M3U التي أنت أضفتها للبرنامج غير صحيحة .. علما أن هذه الخدمة تحتاج منك أن تضيف الرابط بنفسك للبرنامج باستخدام قائمة M3U الموجودة في هذا البرنامج')
		return False
	aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم جلب ملفات M3U جديدة')
	EvN7ufpcI6VkKLRWBaQnbH0rtw91(gYJAT1vW0Uqm76G)
	kYaRIGV5T7Zvfbq3WKpmQwJiBg(False)
	ue186CEMORWhvq(False)
	return True
def EvN7ufpcI6VkKLRWBaQnbH0rtw91(gYJAT1vW0Uqm76G):
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	if not a6KnDNd4JUIcSyf(gYJAT1vW0Uqm76G,True): return
	for UUfw8Ld24pDl5xbHRhe in range(1,s9uG4cZBdagX1SF5q2P+1):
		XSs23UuGCgOPATm7hY = r9spYyBuMzwIe2W4gHQUvqGOCX0hPV(nHXBLNq37CIjZvQDw,'str','LINK_'+str(UUfw8Ld24pDl5xbHRhe),'__LINK__')
		if XSs23UuGCgOPATm7hY: aYRULC8dGNTo0eAmFcjW7 = eL6JlI0X94nyamjOAhu3U1BDgic(gYJAT1vW0Uqm76G,str(UUfw8Ld24pDl5xbHRhe))
	eL6JlI0X94nyamjOAhu3U1BDgic(gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	return
def CSLw0gKhVD(gYJAT1vW0Uqm76G,O3asTXHd4Jm2KCQRUwvbtE8fuDAep):
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		JvOL5Wr9s6 = ttiZs4bKHFvugJj5z('center',nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'مسح ملفات ـM3U','هل تريد مسح الملفات القديمة المخزنة في البرنامج ؟! \n\n علما انك تستطيع في أي وقت الدخول إلى قائمة M3U وجلب ملفات M3U جديدة')
		if JvOL5Wr9s6!=1: return
	nHXBLNq37CIjZvQDw = JiOUEI0FmNg4kPyt6deRY1CV(gYJAT1vW0Uqm76G,nbOFVEDkpT4BIR7Qq82yPmHeJU)
	try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(nHXBLNq37CIjZvQDw)
	except: pass
	for UUfw8Ld24pDl5xbHRhe in range(1,s9uG4cZBdagX1SF5q2P+1):
		OT2twr6bkIVevaGfSPM1 = mEbtRoNBzaGf1KAuLUW6n4Sh3C.replace('___','_'+gYJAT1vW0Uqm76G+'_'+str(UUfw8Ld24pDl5xbHRhe))
		zgG208JL5DKjZhlxTYiy = Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.path.join(iy1kK0BAJVLazhHpnZEqrYt9dOfW,OT2twr6bkIVevaGfSPM1)
		try: Yl6SPqWjpxcv9I4fL8ozNtRJUZi1.remove(zgG208JL5DKjZhlxTYiy)
		except: pass
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'SECTIONS_M3U','SECTIONS_M3U_'+gYJAT1vW0Uqm76G)
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'SECTIONS_M3U','SECTIONS_M3U_ALL')
	if O3asTXHd4Jm2KCQRUwvbtE8fuDAep:
		aY7RFmnWc5uU9T3Q0Mxq4(nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'رسالة من المبرمج','تم مسح جميع ملفات ـM3U')
		ue186CEMORWhvq(False)
	return
def G9nYDmlrhKk(gYJAT1vW0Uqm76G):
	H0HP8jx7JYMbp5BSLGKi9f = llnG7jiQBYKhAeovbT.getSetting('av.language.provider')
	aUpbQVqwl0 = llnG7jiQBYKhAeovbT.getSetting('av.language.code')
	uoxvtFlSXEPnf(SOEM49TbV0zuQ,'MENUS_CACHE_'+H0HP8jx7JYMbp5BSLGKi9f+'_'+aUpbQVqwl0,'%_MU'+gYJAT1vW0Uqm76G+'_%')
	return
mxLp3tBO7rR = {
		 'AF':'Afghanistan'
		,'AL':'Albania'
		,'DZ':'Algeria'
		,'AS':'American Samoa'
		,'AD':'Andorra'
		,'AO':'Angola'
		,'AI':'Anguilla'
		,'AQ':'Antarctica'
		,'AG':'Antigua and Barbuda'
		,'AR':'Argentina'
		,'AM':'Armenia'
		,'AW':'Aruba'
		,'AU':'Australia'
		,'AT':'Austria'
		,'AZ':'Azerbaijan'
		,'BS':'Bahamas'
		,'BH':'Bahrain'
		,'BD':'Bangladesh'
		,'BB':'Barbados'
		,'BY':'Belarus'
		,'BE':'Belgium'
		,'BZ':'Belize'
		,'BJ':'Benin'
		,'BM':'Bermuda'
		,'BT':'Bhutan'
		,'BO':'Bolivia'
		,'BQ':'Bonaire'
		,'BA':'Bosnia and Herzegovina'
		,'BW':'Botswana'
		,'BV':'Bouvet Island'
		,'BR':'Brazil'
		,'IO':'British Indian Ocean Territory'
		,'VG':'British Virgin Islands'
		,'BN':'Brunei'
		,'BG':'Bulgaria'
		,'BF':'Burkina Faso'
		,'BI':'Burundi'
		,'KH':'Cambodia'
		,'CM':'Cameroon'
		,'CA':'Canada'
		,'CV':'Cape Verde'
		,'KY':'Cayman Islands'
		,'CF':'Central African Republic'
		,'TD':'Chad'
		,'CL':'Chile'
		,'CN':'China'
		,'CX':'Christmas Island'
		,'CC':'Cocos (Keeling) Islands'
		,'CO':'Colombia'
		,'KM':'Comoros'
		,'CK':'Cook Islands'
		,'CR':'Costa Rica'
		,'HR':'Croatia'
		,'CU':'Cuba'
		,'CW':'Curacao'
		,'CY':'Cyprus'
		,'CZ':'Czech Republic'
		,'CD':'Democratic Republic of the Congo'
		,'DK':'Denmark'
		,'DJ':'Djibouti'
		,'DM':'Dominica'
		,'DO':'Dominican Republic'
		,'TL':'East Timor'
		,'EC':'Ecuador'
		,'EG':'Egypt'
		,'SV':'El Salvador'
		,'GQ':'Equatorial Guinea'
		,'ER':'Eritrea'
		,'EE':'Estonia'
		,'ET':'Ethiopia'
		,'FK':'Falkland Islands'
		,'FO':'Faroe Islands'
		,'FJ':'Fiji'
		,'FI':'Finland'
		,'FR':'France'
		,'GF':'French Guiana'
		,'PF':'French Polynesia'
		,'TF':'French Southern Territories'
		,'GA':'Gabon'
		,'GM':'Gambia'
		,'GE':'Georgia'
		,'DE':'Germany'
		,'GH':'Ghana'
		,'GI':'Gibraltar'
		,'GR':'Greece'
		,'GL':'Greenland'
		,'GD':'Grenada'
		,'GP':'Guadeloupe'
		,'GU':'Guam'
		,'GT':'Guatemala'
		,'GG':'Guernsey'
		,'GN':'Guinea'
		,'GW':'Guinea-Bissau'
		,'GY':'Guyana'
		,'HT':'Haiti'
		,'HM':'Heard Island and McDonald Islands'
		,'HN':'Honduras'
		,'HK':'Hong Kong'
		,'HU':'Hungary'
		,'IS':'Iceland'
		,'IN':'India'
		,'ID':'Indonesia'
		,'IR':'Iran'
		,'IQ':'Iraq'
		,'IE':'Ireland'
		,'IM':'Isle of Man'
		,'IL':'Israel'
		,'IT':'Italy'
		,'CI':'Ivory Coast'
		,'JM':'Jamaica'
		,'JP':'Japan'
		,'JE':'Jersey'
		,'JO':'Jordan'
		,'KZ':'Kazakhstan'
		,'KE':'Kenya'
		,'KI':'Kiribati'
		,'XK':'Kosovo'
		,'KW':'Kuwait'
		,'KG':'Kyrgyzstan'
		,'LA':'Laos'
		,'LV':'Latvia'
		,'LB':'Lebanon'
		,'LS':'Lesotho'
		,'LR':'Liberia'
		,'LY':'Libya'
		,'LI':'Liechtenstein'
		,'LT':'Lithuania'
		,'LU':'Luxembourg'
		,'MO':'Macao'
		,'MG':'Madagascar'
		,'MW':'Malawi'
		,'MY':'Malaysia'
		,'MV':'Maldives'
		,'ML':'Mali'
		,'MT':'Malta'
		,'MH':'Marshall Islands'
		,'MQ':'Martinique'
		,'MR':'Mauritania'
		,'MU':'Mauritius'
		,'YT':'Mayotte'
		,'MX':'Mexico'
		,'FM':'Micronesia'
		,'MD':'Moldova'
		,'MC':'Monaco'
		,'MN':'Mongolia'
		,'ME':'Montenegro'
		,'MS':'Montserrat'
		,'MA':'Morocco'
		,'MZ':'Mozambique'
		,'MM':'Myanmar (Burma)'
		,'NA':'Namibia'
		,'NR':'Nauru'
		,'NP':'Nepal'
		,'NL':'Netherlands'
		,'NC':'New Caledonia'
		,'NZ':'New Zealand'
		,'NI':'Nicaragua'
		,'NE':'Niger'
		,'NG':'Nigeria'
		,'NU':'Niue'
		,'NF':'Norfolk Island'
		,'KP':'North Korea'
		,'MK':'North Macedonia'
		,'MP':'Northern Mariana Islands'
		,'NO':'Norway'
		,'OM':'Oman'
		,'PK':'Pakistan'
		,'PW':'Palau'
		,'PS':'Palestine'
		,'PA':'Panama'
		,'PG':'Papua New Guinea'
		,'PY':'Paraguay'
		,'PE':'Peru'
		,'PH':'Philippines'
		,'PN':'Pitcairn Islands'
		,'PL':'Poland'
		,'PT':'Portugal'
		,'PR':'Puerto Rico'
		,'QA':'Qatar'
		,'CG':'Republic of the Congo'
		,'RO':'Romania'
		,'RU':'Russia'
		,'RW':'Rwanda'
		,'RE':'Réunion'
		,'BL':'Saint Barthélemy'
		,'SH':'Saint Helena'
		,'KN':'Saint Kitts and Nevis'
		,'LC':'Saint Lucia'
		,'MF':'Saint Martin'
		,'PM':'Saint Pierre and Miquelon'
		,'VC':'Saint Vincent and the Grenadines'
		,'WS':'Samoa'
		,'SM':'San Marino'
		,'SA':'Saudi Arabia'
		,'SN':'Senegal'
		,'RS':'Serbia'
		,'SC':'Seychelles'
		,'SL':'Sierra Leone'
		,'SG':'Singapore'
		,'SX':'Sint Maarten'
		,'SK':'Slovakia'
		,'SI':'Slovenia'
		,'SB':'Solomon Islands'
		,'SO':'Somalia'
		,'ZA':'South Africa'
		,'GS':'South Georgia and the South Sandwich Islands'
		,'KR':'South Korea'
		,'SS':'South Sudan'
		,'ES':'Spain'
		,'LK':'Sri Lanka'
		,'SD':'Sudan'
		,'SR':'Suriname'
		,'SJ':'Svalbard and Jan Mayen'
		,'SZ':'Swaziland'
		,'SE':'Sweden'
		,'CH':'Switzerland'
		,'SY':'Syria'
		,'ST':'São Tomé and Príncipe'
		,'TW':'Taiwan'
		,'TJ':'Tajikistan'
		,'TZ':'Tanzania'
		,'TH':'Thailand'
		,'TG':'Togo'
		,'TK':'Tokelau'
		,'TO':'Tonga'
		,'TT':'Trinidad and Tobago'
		,'TN':'Tunisia'
		,'TR':'Turkey'
		,'TM':'Turkmenistan'
		,'TC':'Turks and Caicos Islands'
		,'TV':'Tuvalu'
		,'UM':'U.S. Minor Outlying Islands'
		,'VI':'U.S. Virgin Islands'
		,'UG':'Uganda'
		,'UA':'Ukraine'
		,'AE':'United Arab Emirates'
		,'UK':'United Kingdom'
		,'US':'United States'
		,'UY':'Uruguay'
		,'UZ':'Uzbekistan'
		,'VU':'Vanuatu'
		,'VA':'Vatican City'
		,'VE':'Venezuela'
		,'VN':'Vietnam'
		,'WF':'Wallis and Futuna'
		,'EH':'Western Sahara'
		,'YE':'Yemen'
		,'ZM':'Zambia'
		,'ZW':'Zimbabwe'
		,'AX':'Åland'
		}
# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'FASELHD2'
headers = {'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU}
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_FH2_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['wwe']
def n1zxUlcAgR(mode,url,text):
	if   mode==590: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==591: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url,text)
	elif mode==592: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==593: bPFto2wZdNYrClgBIEv60DJAzu = RG2K4b1gqI9ViYQX(url,text)
	elif mode==599: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = zKREXyTHfVSNL8ZFYs
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD2-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,599,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'المميزة',R0mG4duvNLUHqgT8X7yZ6zBxk3CiO,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured1')
	items = ScntgdOZCY74vNpXeW5jh8i.findall('<strong>(.*?)</strong>.*?href="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details1')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('main-menu"(.*?)header-social',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		FDmSKut6Meh9yRqY4 = ScntgdOZCY74vNpXeW5jh8i.findall('<li (.*?)</li>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for XHr9mRzgEVcM26KOdYTBWf4Lxa in FDmSKut6Meh9yRqY4:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',XHr9mRzgEVcM26KOdYTBWf4Lxa,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details2')
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD2-TITLES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	sT358iwjuHpn0DvgY = 0
	b8Ior2kWzq1tc = ScntgdOZCY74vNpXeW5jh8i.findall('"archive-slider(.*?)<h4>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if b8Ior2kWzq1tc: eXBMHvPbDunL = b8Ior2kWzq1tc[0]
	else: eXBMHvPbDunL = nbOFVEDkpT4BIR7Qq82yPmHeJU
	if type=='featured1':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('"slider-carousel"(.*?)</container>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall(' src="(.*?)".*?"slider-title">(.*?)<.*?<a href="(.*?)"',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		LYsTUSXwFZk2E53,bdW70uQAIF,rU02bCJFWZDfVuhtMgBOyQi5P = zip(*items)
		items = zip(rU02bCJFWZDfVuhtMgBOyQi5P,LYsTUSXwFZk2E53,bdW70uQAIF)
	elif type=='featured2':
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',eXBMHvPbDunL,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='filters':
		eXpgPIbRv2ZMGwjm5 = [UTvsQb4HpCP3Aeo2wDZG7X5V.replace('\\/','/').replace('\\"','"')]
	elif type=='details2' and 'href' in eXBMHvPbDunL:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<h4>(.*?)</h4>(.*?)</container>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مميزة',url,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'featured2')
		title = eXpgPIbRv2ZMGwjm5[0][0]
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details3')
		return
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<h4>(.*?)</h4>(.*?)</container>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		title,G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3.*?>(.*?)</h3>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	m3m9xLbAungWHTjG0N7V = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية','حلقة']
	tWsVFQj47pw0L56rZfg = []
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
		if any(XPL0O2VkI3w1C8enMaqi in title.lower() for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a): continue
		title = title.strip(S3X6GcaiExOPtb)
		title = dCtxzeFX4GJVonm(title)
		BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) (الحلقة|حلقة).\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if '/movseries/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,591,X79kphTKa1xLP)
		elif BBuqr7CwzEIi9UL54n0AVoHXPlp and type==nbOFVEDkpT4BIR7Qq82yPmHeJU:
			title = '_MOD_'+BBuqr7CwzEIi9UL54n0AVoHXPlp[0][0]
			if title not in tWsVFQj47pw0L56rZfg:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,593,X79kphTKa1xLP)
				tWsVFQj47pw0L56rZfg.append(title)
		elif any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in m3m9xLbAungWHTjG0N7V):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,592,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,593,X79kphTKa1xLP)
	if type=='filters':
		M2RDC4XTQxmqHJ8cWNbA = ScntgdOZCY74vNpXeW5jh8i.findall('"more_button_page":(.*?),',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if M2RDC4XTQxmqHJ8cWNbA:
			count = M2RDC4XTQxmqHJ8cWNbA[0]
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url+'/offset/'+count
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة أخرى',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'filters')
	elif 'details' in type:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)">(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = 'صفحة '+dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,591,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'details4')
	return
def RG2K4b1gqI9ViYQX(url,type=nbOFVEDkpT4BIR7Qq82yPmHeJU):
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD2-SEASONS_EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	KXVHpZTa3BCSWlQYUut0PdDLc94Rzo = False
	if not type:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<seasons(.*?)</seasons>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?image:url\((.*?)\).*?<h3>(.*?)</h3>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if len(items)>1:
				R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = Qi32bRtN18qvyWmaO7YKow9cXs(url,'url')
				KXVHpZTa3BCSWlQYUut0PdDLc94Rzo = True
				for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,X79kphTKa1xLP,title in items:
					title = dCtxzeFX4GJVonm(title)
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,593,X79kphTKa1xLP,nbOFVEDkpT4BIR7Qq82yPmHeJU,'episodes')
	if type=='episodes' or not KXVHpZTa3BCSWlQYUut0PdDLc94Rzo:
		nnu5vdh1IscOA8J = ScntgdOZCY74vNpXeW5jh8i.findall('<bkز*?image:url\((.*?)\)"></bk>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if nnu5vdh1IscOA8J: X79kphTKa1xLP = nnu5vdh1IscOA8J[0]
		else: X79kphTKa1xLP = nbOFVEDkpT4BIR7Qq82yPmHeJU
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<all-episodes(.*?)</all-episodes>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)</a>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				title = title.strip(S3X6GcaiExOPtb)
				title = dCtxzeFX4GJVonm(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,592,X79kphTKa1xLP)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	NWtqFg91ZSKinvIwAc,rMU1A3KVhge,MOi17hVvIujyezmL = [],[],[]
	cnPhVmgFxA = t57SmWGkHCXd4yq(pOLDXnFW5V6cTw7ikm,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'FASELHD2-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXwj0EFQN4no89Gr5VhiYOsCvt = ScntgdOZCY74vNpXeW5jh8i.findall('العمر :.*?<strong">(.*?)</strong>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXwj0EFQN4no89Gr5VhiYOsCvt and hVa7QF14igDIG820eXfd(QSJFrwB3dMiyH2mTPKD9a,url,eXwj0EFQN4no89Gr5VhiYOsCvt): return
	grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = ScntgdOZCY74vNpXeW5jh8i.findall('<iframe src="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6[0]
		NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named=__embed')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<slice-title(.*?)</ul>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-url="(.*?)".*?</i>(.*?)</li>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
			name = name.strip(S3X6GcaiExOPtb)
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__watch')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<downloads(.*?)</downloads>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?</div>(.*?)</div>',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name in items:
			NWtqFg91ZSKinvIwAc.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__download')
	for clCgpAiNx2TMzBoKbrFHfkXjUDG0 in NWtqFg91ZSKinvIwAc:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name = clCgpAiNx2TMzBoKbrFHfkXjUDG0.split('?named')
		if grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 not in rMU1A3KVhge:
			rMU1A3KVhge.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
			MOi17hVvIujyezmL.append(clCgpAiNx2TMzBoKbrFHfkXjUDG0)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(MOi17hVvIujyezmL,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	R0mG4duvNLUHqgT8X7yZ6zBxk3CiO = zKREXyTHfVSNL8ZFYs
	url = R0mG4duvNLUHqgT8X7yZ6zBxk3CiO+'/?s='+search
	IGDobAKtj4kPF5V(url,'details5')
	return
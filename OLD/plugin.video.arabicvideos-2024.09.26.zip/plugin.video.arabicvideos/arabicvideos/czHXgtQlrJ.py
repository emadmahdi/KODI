# -*- coding: utf-8 -*-
from RpSbDv2A79 import *
QSJFrwB3dMiyH2mTPKD9a = 'ARBLIONZ'
headers = { 'User-Agent' : nbOFVEDkpT4BIR7Qq82yPmHeJU }
TbufdXZL9Ml72WmGcpQ5FAgBYKqa = '_ARL_'
zKREXyTHfVSNL8ZFYs = sCSyOla9hrcE[QSJFrwB3dMiyH2mTPKD9a][0]
CZrI4vYju7a = ['عروض المصارعة','الكل','الرئيسية','العاب','برامج كمبيوتر','موبايل و جوال','القسم الاسلامي']
def n1zxUlcAgR(mode,url,text):
	if   mode==200: bPFto2wZdNYrClgBIEv60DJAzu = kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0()
	elif mode==201: bPFto2wZdNYrClgBIEv60DJAzu = IGDobAKtj4kPF5V(url)
	elif mode==202: bPFto2wZdNYrClgBIEv60DJAzu = AOk1T6KwciHrWU2MYJzZnEN(url)
	elif mode==203: bPFto2wZdNYrClgBIEv60DJAzu = PXyn8J3WjhRgA(url)
	elif mode==204: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'FILTERS___'+text)
	elif mode==205: bPFto2wZdNYrClgBIEv60DJAzu = bpRLN7ZqT5BiXKfMdI(url,'CATEGORIES___'+text)
	elif mode==209: bPFto2wZdNYrClgBIEv60DJAzu = cvZoNw4F0fRjYaMuP5CVrE(text)
	else: bPFto2wZdNYrClgBIEv60DJAzu = False
	return bPFto2wZdNYrClgBIEv60DJAzu
def kdyB8X2JD4cnsWuGNfaQZTSVoLr1F0():
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'بحث في الموقع',nbOFVEDkpT4BIR7Qq82yPmHeJU,209,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,'_REMEMBERRESULTS_')
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر محدد',zKREXyTHfVSNL8ZFYs,205)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'فلتر كامل',zKREXyTHfVSNL8ZFYs,204)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مميزة',zKREXyTHfVSNL8ZFYs+'??trending',201)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أفلام مميزة',zKREXyTHfVSNL8ZFYs+'??trending_movies',201)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'مسلسلات مميزة',zKREXyTHfVSNL8ZFYs+'??trending_series',201)
	Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الصفحة الرئيسية',zKREXyTHfVSNL8ZFYs+'??mainpage',201)
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARBLIONZ-MENU-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('categories-tabs(.*?)MainRow',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('data-get="(.*?)".*?<h3>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for filter,title in items:
			grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+'/ajax/home/more?filter='+filter
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,201)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('navigation-menu(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if 'http' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = zKREXyTHfVSNL8ZFYs+grwO1UeqkvQBf4tmz0jTx3lEKZWbF6
		title = title.strip(S3X6GcaiExOPtb)
		if not any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in CZrI4vYju7a):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',QSJFrwB3dMiyH2mTPKD9a+'_SCRIPT_'+TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,201)
	return UTvsQb4HpCP3Aeo2wDZG7X5V
def IGDobAKtj4kPF5V(url):
	if '??' in url: url,type = url.split('??')
	else: type = nbOFVEDkpT4BIR7Qq82yPmHeJU
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARBLIONZ-TITLES-2nd')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	if 'getposts' in url: eXpgPIbRv2ZMGwjm5 = [UTvsQb4HpCP3Aeo2wDZG7X5V]
	elif type=='trending':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('MasterSlider(.*?)</div>\n *</div>\n *</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='trending_movies':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('Slider_1(.*?)</div>.</div>.</div>.</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='trending_series':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('Slider_2(.*?)</div>.</div>.</div>.</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	elif type=='111mainpage':
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="container page-content"(.*?)class="tabs"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	else:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('page-content(.*?)main-footer',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not eXpgPIbRv2ZMGwjm5: return
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	Zq6suEoHra8xBIJFSUAvWYb7 = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
	items = ScntgdOZCY74vNpXeW5jh8i.findall('content-box".*?src="(.*?)".*?href="(.*?)".*?<h3>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not items:
		items = ScntgdOZCY74vNpXeW5jh8i.findall('SliderItem".*?href="(.*?)".*?image: url\((.*?)\).*?<h2>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		rU02bCJFWZDfVuhtMgBOyQi5P,LYsTUSXwFZk2E53,bdW70uQAIF = zip(*items)
		items = zip(LYsTUSXwFZk2E53,rU02bCJFWZDfVuhtMgBOyQi5P,bdW70uQAIF)
	tWsVFQj47pw0L56rZfg = []
	for X79kphTKa1xLP,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
		if '/series/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6: continue
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
		title = dCtxzeFX4GJVonm(title)
		title = title.strip(S3X6GcaiExOPtb)
		if '/film/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 or any(XPL0O2VkI3w1C8enMaqi in title for XPL0O2VkI3w1C8enMaqi in Zq6suEoHra8xBIJFSUAvWYb7):
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,202,X79kphTKa1xLP)
		elif '/episode/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 and 'الحلقة' in title:
			BBuqr7CwzEIi9UL54n0AVoHXPlp = ScntgdOZCY74vNpXeW5jh8i.findall('(.*?) الحلقة \d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if BBuqr7CwzEIi9UL54n0AVoHXPlp:
				title = '_MOD_' + BBuqr7CwzEIi9UL54n0AVoHXPlp[0]
				if title not in tWsVFQj47pw0L56rZfg:
					Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,203,X79kphTKa1xLP)
					tWsVFQj47pw0L56rZfg.append(title)
		elif '/pack/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'/films',201,X79kphTKa1xLP)
		else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,203,X79kphTKa1xLP)
	if type in [nbOFVEDkpT4BIR7Qq82yPmHeJU,'mainpage']:
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('class="pagination(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if eXpgPIbRv2ZMGwjm5:
			G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href=["\'](http.*?)["\'].*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = dCtxzeFX4GJVonm(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
				title = dCtxzeFX4GJVonm(title)
				title = title.replace('الصفحة ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
				if 'search?s=' in url:
					ZZkIjB3Tfe0PYipqlvwN2 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('page=')[1]
					wLMW4cmbayDnGJ9gU = url.split('page=')[1]
					grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = url.replace('page='+wLMW4cmbayDnGJ9gU,'page='+ZZkIjB3Tfe0PYipqlvwN2)
				if title!=nbOFVEDkpT4BIR7Qq82yPmHeJU: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'صفحة '+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,201)
	return
def PXyn8J3WjhRgA(url):
	NNlnvX5Y9m3P2ZcKU,items,N3OCzkD7MEISKqTBJ = -1,[],[]
	cnPhVmgFxA = t57SmWGkHCXd4yq(RRYx6sACloVPr3td95Ej,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARBLIONZ-EPISODES-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('ti-list-numbered(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if eXpgPIbRv2ZMGwjm5:
		N3OCzkD7MEISKqTBJ = []
		ISmqngYzv6jrepWUx0l = nbOFVEDkpT4BIR7Qq82yPmHeJU.join(eXpgPIbRv2ZMGwjm5)
		items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',ISmqngYzv6jrepWUx0l,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	items.append(url)
	items = set(items)
	for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 in items:
		grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.strip('/')
		title = '_MOD_' + grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-1].replace('-',S3X6GcaiExOPtb)
		AG0kLzo8e6wiV1DdSb = ScntgdOZCY74vNpXeW5jh8i.findall('الحلقة-(\d+)',grwO1UeqkvQBf4tmz0jTx3lEKZWbF6.split('/')[-1],ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if AG0kLzo8e6wiV1DdSb: AG0kLzo8e6wiV1DdSb = AG0kLzo8e6wiV1DdSb[0]
		else: AG0kLzo8e6wiV1DdSb = '0'
		N3OCzkD7MEISKqTBJ.append([grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb])
	items = sorted(N3OCzkD7MEISKqTBJ, reverse=False, key=lambda key: int(key[2]))
	oBpGSTf4OhtnR5d = str(items).count('/season/')
	NNlnvX5Y9m3P2ZcKU = str(items).count('/episode/')
	if oBpGSTf4OhtnR5d>1 and NNlnvX5Y9m3P2ZcKU>0 and '/season/' not in url:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb in items:
			if '/season/' in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,203)
	else:
		for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,title,AG0kLzo8e6wiV1DdSb in items:
			if '/season/' not in grwO1UeqkvQBf4tmz0jTx3lEKZWbF6:
				title = SxN0jnqr3LI(title)
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('video',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,202)
	return
def AOk1T6KwciHrWU2MYJzZnEN(url):
	lPpY5fw3tOBcEye91Caun2FQZ = []
	LCjugSrWIBPDyFb4X1o9fAM = url.split('/')
	a3a98dOrWQ4cBbAIzC6epsu = zKREXyTHfVSNL8ZFYs
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',url,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,True,'ARBLIONZ-PLAY-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	id = ScntgdOZCY74vNpXeW5jh8i.findall('postId:"(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not id: id = ScntgdOZCY74vNpXeW5jh8i.findall('post_id=(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if not id: id = ScntgdOZCY74vNpXeW5jh8i.findall('post-id="(.*?)"',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if id: id = id[0]
	if '/watch/' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		plSscrVjkRviPwm = url.replace(LCjugSrWIBPDyFb4X1o9fAM[3],'watch')
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,True,'ARBLIONZ-PLAY-2nd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		mOPpf9i5VxCwq3dHhZeGnWbal8 = ScntgdOZCY74vNpXeW5jh8i.findall('data-embedd="(.*?)".*?alt="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		XhE8FpdTjG = ScntgdOZCY74vNpXeW5jh8i.findall('data-embedd=".*?(http.*?)("|&quot;)',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		EceQP0ZjBhzLS = ScntgdOZCY74vNpXeW5jh8i.findall('src=&quot;(.*?)&quot;.*?>(.*?)<',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		UDALMR1aYPnckQ0mCK = ScntgdOZCY74vNpXeW5jh8i.findall('data-embedd="(.*?)">\n*.*?server_image">\n(.*?)\n',fv4KNqjIBQT0UcHmlYSnrwOAWGV)
		SOsQ7Llaye4ur5nV09g = ScntgdOZCY74vNpXeW5jh8i.findall('src=&quot;(.*?)&quot;.*?alt="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		HuUtMD8dsnpZ3jvh94KIJXoFG = ScntgdOZCY74vNpXeW5jh8i.findall('server="(.*?)".*?<span>(.*?)<',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
		items = mOPpf9i5VxCwq3dHhZeGnWbal8+XhE8FpdTjG+EceQP0ZjBhzLS+UDALMR1aYPnckQ0mCK+SOsQ7Llaye4ur5nV09g+HuUtMD8dsnpZ3jvh94KIJXoFG
		if not items:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('<span>(.*?)</span>.*?src="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL|ScntgdOZCY74vNpXeW5jh8i.IGNORECASE)
			items = [(LGrjQCh8dyHPJE1oNOp,c6tmKg5E8hnRS4LUArqzZBYCINJT) for c6tmKg5E8hnRS4LUArqzZBYCINJT,LGrjQCh8dyHPJE1oNOp in items]
		for RWZpkDLtY5Eyb46029MvAKmqBQd8o,title in items:
			if '.png' in RWZpkDLtY5Eyb46029MvAKmqBQd8o: continue
			if '.jpg' in RWZpkDLtY5Eyb46029MvAKmqBQd8o: continue
			if '&quot;' in RWZpkDLtY5Eyb46029MvAKmqBQd8o: continue
			uTKGhcXEIpmDf = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if uTKGhcXEIpmDf:
				uTKGhcXEIpmDf = uTKGhcXEIpmDf[0]
				if uTKGhcXEIpmDf in title: title = title.replace(uTKGhcXEIpmDf+'p',nbOFVEDkpT4BIR7Qq82yPmHeJU).replace(uTKGhcXEIpmDf,nbOFVEDkpT4BIR7Qq82yPmHeJU).strip(S3X6GcaiExOPtb)
				uTKGhcXEIpmDf = '____'+uTKGhcXEIpmDf
			else: uTKGhcXEIpmDf = nbOFVEDkpT4BIR7Qq82yPmHeJU
			if RWZpkDLtY5Eyb46029MvAKmqBQd8o.isdigit():
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = a3a98dOrWQ4cBbAIzC6epsu+'/?postid='+id+'&serverid='+RWZpkDLtY5Eyb46029MvAKmqBQd8o+'?named='+title+'__watch'+uTKGhcXEIpmDf
			else:
				if 'http' not in RWZpkDLtY5Eyb46029MvAKmqBQd8o: RWZpkDLtY5Eyb46029MvAKmqBQd8o = 'http:'+RWZpkDLtY5Eyb46029MvAKmqBQd8o
				uTKGhcXEIpmDf = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d\d+',title,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				if uTKGhcXEIpmDf: uTKGhcXEIpmDf = '____'+uTKGhcXEIpmDf[0]
				else: uTKGhcXEIpmDf = nbOFVEDkpT4BIR7Qq82yPmHeJU
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = RWZpkDLtY5Eyb46029MvAKmqBQd8o+'?named=__watch'+uTKGhcXEIpmDf
			lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	if 'DownloadNow' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		GcYwHSWoQ0Nq8KFfJDdvujZryM = { 'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8' }
		plSscrVjkRviPwm = url+'/download'
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARBLIONZ-PLAY-3rd')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('<ul class="download-items(.*?)</ul>',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		for G4JHzTEp61 in eXpgPIbRv2ZMGwjm5:
			items = ScntgdOZCY74vNpXeW5jh8i.findall('href="(http.*?)".*?<span>(.*?)<.*?<p>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for grwO1UeqkvQBf4tmz0jTx3lEKZWbF6,name,uTKGhcXEIpmDf in items:
				grwO1UeqkvQBf4tmz0jTx3lEKZWbF6 = grwO1UeqkvQBf4tmz0jTx3lEKZWbF6+'?named='+name+'__download'+'____'+uTKGhcXEIpmDf
				lPpY5fw3tOBcEye91Caun2FQZ.append(grwO1UeqkvQBf4tmz0jTx3lEKZWbF6)
	elif '/download/' in UTvsQb4HpCP3Aeo2wDZG7X5V:
		GcYwHSWoQ0Nq8KFfJDdvujZryM = { 'User-Agent':nbOFVEDkpT4BIR7Qq82yPmHeJU , 'X-Requested-With':'XMLHttpRequest' }
		plSscrVjkRviPwm = a3a98dOrWQ4cBbAIzC6epsu + '/ajaxCenter?_action=getdownloadlinks&postId='+id
		cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',plSscrVjkRviPwm,nbOFVEDkpT4BIR7Qq82yPmHeJU,GcYwHSWoQ0Nq8KFfJDdvujZryM,True,True,'ARBLIONZ-PLAY-4th')
		fv4KNqjIBQT0UcHmlYSnrwOAWGV = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
		if 'download-btns' in fv4KNqjIBQT0UcHmlYSnrwOAWGV:
			EceQP0ZjBhzLS = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			for zb2QIaL7Y4h9g8lSck in EceQP0ZjBhzLS:
				if '/page/' not in zb2QIaL7Y4h9g8lSck and 'http' in zb2QIaL7Y4h9g8lSck:
					zb2QIaL7Y4h9g8lSck = zb2QIaL7Y4h9g8lSck+'?named=__download'
					lPpY5fw3tOBcEye91Caun2FQZ.append(zb2QIaL7Y4h9g8lSck)
				elif '/page/' in zb2QIaL7Y4h9g8lSck:
					uTKGhcXEIpmDf = nbOFVEDkpT4BIR7Qq82yPmHeJU
					cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zb2QIaL7Y4h9g8lSck,nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,True,'ARBLIONZ-PLAY-5th')
					EOTUuoLlxDVFHj = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
					ISmqngYzv6jrepWUx0l = ScntgdOZCY74vNpXeW5jh8i.findall('(<strong>.*?)-----',EOTUuoLlxDVFHj,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					for Jmbr2WF9Dt8iX5IYQhuloRp1E in ISmqngYzv6jrepWUx0l:
						pPub3f1a9ydNOtUWJZY4QhESCRo = nbOFVEDkpT4BIR7Qq82yPmHeJU
						UDALMR1aYPnckQ0mCK = ScntgdOZCY74vNpXeW5jh8i.findall('<strong>(.*?)</strong>',Jmbr2WF9Dt8iX5IYQhuloRp1E,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						for aWsr2HSgpC49jmxOdNQBKkRwLZTM1 in UDALMR1aYPnckQ0mCK:
							xB2lOZNsPvFQDC4gMz = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d\d+',aWsr2HSgpC49jmxOdNQBKkRwLZTM1,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
							if xB2lOZNsPvFQDC4gMz:
								uTKGhcXEIpmDf = '____'+xB2lOZNsPvFQDC4gMz[0]
								break
						for aWsr2HSgpC49jmxOdNQBKkRwLZTM1 in reversed(UDALMR1aYPnckQ0mCK):
							xB2lOZNsPvFQDC4gMz = ScntgdOZCY74vNpXeW5jh8i.findall('\w\w+',aWsr2HSgpC49jmxOdNQBKkRwLZTM1,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
							if xB2lOZNsPvFQDC4gMz:
								pPub3f1a9ydNOtUWJZY4QhESCRo = xB2lOZNsPvFQDC4gMz[0]
								break
						SOsQ7Llaye4ur5nV09g = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)"',Jmbr2WF9Dt8iX5IYQhuloRp1E,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						for C9pz3cVaO8bJAI in SOsQ7Llaye4ur5nV09g:
							C9pz3cVaO8bJAI = C9pz3cVaO8bJAI+'?named='+pPub3f1a9ydNOtUWJZY4QhESCRo+'__download'+uTKGhcXEIpmDf
							lPpY5fw3tOBcEye91Caun2FQZ.append(C9pz3cVaO8bJAI)
		elif 'slow-motion' in fv4KNqjIBQT0UcHmlYSnrwOAWGV:
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = fv4KNqjIBQT0UcHmlYSnrwOAWGV.replace('<h6 ','==END== ==START==')+'==END=='
			fv4KNqjIBQT0UcHmlYSnrwOAWGV = fv4KNqjIBQT0UcHmlYSnrwOAWGV.replace('<h3 ','==END== ==START==')+'==END=='
			ppvIJhrKZPSYM3m1qaHBU = ScntgdOZCY74vNpXeW5jh8i.findall('==START==(.*?)==END==',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
			if ppvIJhrKZPSYM3m1qaHBU:
				for Jmbr2WF9Dt8iX5IYQhuloRp1E in ppvIJhrKZPSYM3m1qaHBU:
					if 'href=' not in Jmbr2WF9Dt8iX5IYQhuloRp1E: continue
					M48fsyAaSclkhRVWKIw1ipqxNB = nbOFVEDkpT4BIR7Qq82yPmHeJU
					UDALMR1aYPnckQ0mCK = ScntgdOZCY74vNpXeW5jh8i.findall('slow-motion">(.*?)<',Jmbr2WF9Dt8iX5IYQhuloRp1E,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					for aWsr2HSgpC49jmxOdNQBKkRwLZTM1 in UDALMR1aYPnckQ0mCK:
						xB2lOZNsPvFQDC4gMz = ScntgdOZCY74vNpXeW5jh8i.findall('\d\d\d+',aWsr2HSgpC49jmxOdNQBKkRwLZTM1,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						if xB2lOZNsPvFQDC4gMz:
							M48fsyAaSclkhRVWKIw1ipqxNB = '____'+xB2lOZNsPvFQDC4gMz[0]
							break
					UDALMR1aYPnckQ0mCK = ScntgdOZCY74vNpXeW5jh8i.findall('<td>(.*?)</td>.*?href="(http.*?)"',Jmbr2WF9Dt8iX5IYQhuloRp1E,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
					if UDALMR1aYPnckQ0mCK:
						for pPub3f1a9ydNOtUWJZY4QhESCRo,wx9qKZ7TVArpioQJm4lM2 in UDALMR1aYPnckQ0mCK:
							wx9qKZ7TVArpioQJm4lM2 = wx9qKZ7TVArpioQJm4lM2+'?named='+pPub3f1a9ydNOtUWJZY4QhESCRo+'__download'+M48fsyAaSclkhRVWKIw1ipqxNB
							lPpY5fw3tOBcEye91Caun2FQZ.append(wx9qKZ7TVArpioQJm4lM2)
					else:
						UDALMR1aYPnckQ0mCK = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?http.*?)".*?name">(.*?)<',Jmbr2WF9Dt8iX5IYQhuloRp1E,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
						for wx9qKZ7TVArpioQJm4lM2,pPub3f1a9ydNOtUWJZY4QhESCRo in UDALMR1aYPnckQ0mCK:
							wx9qKZ7TVArpioQJm4lM2 = wx9qKZ7TVArpioQJm4lM2.strip(S3X6GcaiExOPtb)+'?named='+pPub3f1a9ydNOtUWJZY4QhESCRo+'__download'+M48fsyAaSclkhRVWKIw1ipqxNB
							lPpY5fw3tOBcEye91Caun2FQZ.append(wx9qKZ7TVArpioQJm4lM2)
			else:
				UDALMR1aYPnckQ0mCK = ScntgdOZCY74vNpXeW5jh8i.findall('href="(.*?)".*?>(\w+)<',fv4KNqjIBQT0UcHmlYSnrwOAWGV,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
				for wx9qKZ7TVArpioQJm4lM2,pPub3f1a9ydNOtUWJZY4QhESCRo in UDALMR1aYPnckQ0mCK:
					wx9qKZ7TVArpioQJm4lM2 = wx9qKZ7TVArpioQJm4lM2.strip(S3X6GcaiExOPtb)+'?named='+pPub3f1a9ydNOtUWJZY4QhESCRo+'__download'
					lPpY5fw3tOBcEye91Caun2FQZ.append(wx9qKZ7TVArpioQJm4lM2)
	import gdVOXAx7tm
	gdVOXAx7tm.ooRpOJtyIaY(lPpY5fw3tOBcEye91Caun2FQZ,QSJFrwB3dMiyH2mTPKD9a,'video',url)
	return
def cvZoNw4F0fRjYaMuP5CVrE(search):
	search,YE1hqa60dGTRDZ8NVBM,showDialogs = hKjNwk3Bfpa48Om7JQz(search)
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: search = dR75Vq2gprfHmUcNhG()
	if search==nbOFVEDkpT4BIR7Qq82yPmHeJU: return
	search = search.replace(S3X6GcaiExOPtb,'+')
	cnPhVmgFxA = t57SmWGkHCXd4yq(mmfpkVtUDjaq86eAuFzE0oxP,'GET',zKREXyTHfVSNL8ZFYs+'/alz',nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,True,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARBLIONZ-SEARCH-1st')
	UTvsQb4HpCP3Aeo2wDZG7X5V = cnPhVmgFxA.content.encode(zSafwK0sDXdMN5JReniIQmrZxp)
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('chevron-select(.*?)</div>',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	if showDialogs and eXpgPIbRv2ZMGwjm5:
		G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
		items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)".*?>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		K5BAv0lgMsab86R,oVlyqSBwU3tWGDLKE91u8AMQkCa = [],[]
		for jGdXt7eADorwlv8pahNV95H6Tn2qKx,title in items:
			K5BAv0lgMsab86R.append(jGdXt7eADorwlv8pahNV95H6Tn2qKx)
			oVlyqSBwU3tWGDLKE91u8AMQkCa.append(title)
		bCiGxXzDkH = nnRXQH90qeOtABkJzGr('اختر الفلتر المناسب:', oVlyqSBwU3tWGDLKE91u8AMQkCa)
		if bCiGxXzDkH == -1 : return
		jGdXt7eADorwlv8pahNV95H6Tn2qKx = K5BAv0lgMsab86R[bCiGxXzDkH]
	else: jGdXt7eADorwlv8pahNV95H6Tn2qKx = nbOFVEDkpT4BIR7Qq82yPmHeJU
	url = zKREXyTHfVSNL8ZFYs + '/search?s='+search+'&category='+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'&page=1'
	IGDobAKtj4kPF5V(url)
	return
def bpRLN7ZqT5BiXKfMdI(url,filter):
	MMTo52yRJw30g6qZpPQsG = ['category','release-year','genre','Quality']
	if '?' in url: url = url.split('/getposts?')[0]
	type,filter = filter.split('___',1)
	if filter==nbOFVEDkpT4BIR7Qq82yPmHeJU: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU
	else: uuGXw3jKE8mkBIRp1V,RAf62IHC9L0OUl1oETijSgyxX5F = filter.split('___')
	if type=='CATEGORIES':
		if MMTo52yRJw30g6qZpPQsG[0]+'=' not in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[0]
		for WoEZvMXa0K2suwgPl in range(len(MMTo52yRJw30g6qZpPQsG[0:-1])):
			if MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl]+'=' in uuGXw3jKE8mkBIRp1V: jGdXt7eADorwlv8pahNV95H6Tn2qKx = MMTo52yRJw30g6qZpPQsG[WoEZvMXa0K2suwgPl+1]
		EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+jGdXt7eADorwlv8pahNV95H6Tn2qKx+'=0'
		DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT.strip('&')+'___'+bhz0GBTNQdYxvnt.strip('&')
		soAjtN3yd04Jzr = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		plSscrVjkRviPwm = url+'/getposts?'+soAjtN3yd04Jzr
	elif type=='FILTERS':
		wx3SYEkWmyl = BvsNfECRhmo(uuGXw3jKE8mkBIRp1V,'modified_values')
		wx3SYEkWmyl = SxN0jnqr3LI(wx3SYEkWmyl)
		if RAf62IHC9L0OUl1oETijSgyxX5F!=nbOFVEDkpT4BIR7Qq82yPmHeJU: RAf62IHC9L0OUl1oETijSgyxX5F = BvsNfECRhmo(RAf62IHC9L0OUl1oETijSgyxX5F,'modified_filters')
		if RAf62IHC9L0OUl1oETijSgyxX5F==nbOFVEDkpT4BIR7Qq82yPmHeJU: plSscrVjkRviPwm = url
		else: plSscrVjkRviPwm = url+'/getposts?'+RAf62IHC9L0OUl1oETijSgyxX5F
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'أظهار قائمة الفيديو التي تم اختيارها ',plSscrVjkRviPwm,201)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+' [[   '+wx3SYEkWmyl+'   ]]',plSscrVjkRviPwm,201)
		Wbmahg7dTR3qBJSvo09tfyFXH4YEj('link',eMypvI8XqHjYU02anWD9gsSrkt+' ===== ===== ===== '+c7gxFyUCGm,nbOFVEDkpT4BIR7Qq82yPmHeJU,9999)
	UTvsQb4HpCP3Aeo2wDZG7X5V = YmL4rcEjZIBU0wdC8Fv6qWPk(mmfpkVtUDjaq86eAuFzE0oxP,url+'/alz',nbOFVEDkpT4BIR7Qq82yPmHeJU,headers,nbOFVEDkpT4BIR7Qq82yPmHeJU,'ARBLIONZ-FILTERS_MENU-1st')
	eXpgPIbRv2ZMGwjm5 = ScntgdOZCY74vNpXeW5jh8i.findall('AjaxFilteringData(.*?)FilterWord',UTvsQb4HpCP3Aeo2wDZG7X5V,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	G4JHzTEp61 = eXpgPIbRv2ZMGwjm5[0]
	m8kVhKyAp7NCibFJ3sYO4EwMS = ScntgdOZCY74vNpXeW5jh8i.findall('</i>(.*?)<.*?data-forTax="(.*?)"(.*?)<h2',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
	dict = {}
	for name,TT4Yd6yIaJGxZtoR8mh2O7,G4JHzTEp61 in m8kVhKyAp7NCibFJ3sYO4EwMS:
		name = name.replace('اختيار ',nbOFVEDkpT4BIR7Qq82yPmHeJU)
		name = name.replace('سنة الإنتاج','السنة')
		items = ScntgdOZCY74vNpXeW5jh8i.findall('value="(.*?)".*?</div>(.*?)<',G4JHzTEp61,ScntgdOZCY74vNpXeW5jh8i.DOTALL)
		if '=' not in plSscrVjkRviPwm: plSscrVjkRviPwm = url
		if type=='CATEGORIES':
			if jGdXt7eADorwlv8pahNV95H6Tn2qKx!=TT4Yd6yIaJGxZtoR8mh2O7: continue
			elif len(items)<=1:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: IGDobAKtj4kPF5V(plSscrVjkRviPwm)
				else: bpRLN7ZqT5BiXKfMdI(plSscrVjkRviPwm,'CATEGORIES___'+DD4bmFxP1wkzWZGY9NjM5RsBK)
				return
			else:
				if TT4Yd6yIaJGxZtoR8mh2O7==MMTo52yRJw30g6qZpPQsG[-1]: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',plSscrVjkRviPwm,201)
				else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع ',plSscrVjkRviPwm,205,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		elif type=='FILTERS':
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'=0'
			DD4bmFxP1wkzWZGY9NjM5RsBK = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+'الجميع :'+name,plSscrVjkRviPwm,204,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,DD4bmFxP1wkzWZGY9NjM5RsBK)
		dict[TT4Yd6yIaJGxZtoR8mh2O7] = {}
		for XPL0O2VkI3w1C8enMaqi,PspiL81kMT4BwOIXo in items:
			PspiL81kMT4BwOIXo = PspiL81kMT4BwOIXo.replace(wwOnIucWJj,nbOFVEDkpT4BIR7Qq82yPmHeJU)
			if PspiL81kMT4BwOIXo in CZrI4vYju7a: continue
			dict[TT4Yd6yIaJGxZtoR8mh2O7][XPL0O2VkI3w1C8enMaqi] = PspiL81kMT4BwOIXo
			EqyQzL5KlAT = uuGXw3jKE8mkBIRp1V+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+PspiL81kMT4BwOIXo
			bhz0GBTNQdYxvnt = RAf62IHC9L0OUl1oETijSgyxX5F+'&'+TT4Yd6yIaJGxZtoR8mh2O7+'='+XPL0O2VkI3w1C8enMaqi
			XaxZd0lwYR = EqyQzL5KlAT+'___'+bhz0GBTNQdYxvnt
			title = PspiL81kMT4BwOIXo+' :'#+dict[TT4Yd6yIaJGxZtoR8mh2O7]['0']
			title = PspiL81kMT4BwOIXo+' :'+name
			if type=='FILTERS': Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,204,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
			elif type=='CATEGORIES' and MMTo52yRJw30g6qZpPQsG[-2]+'=' in uuGXw3jKE8mkBIRp1V:
				soAjtN3yd04Jzr = BvsNfECRhmo(bhz0GBTNQdYxvnt,'modified_filters')
				zb2QIaL7Y4h9g8lSck = url+'/getposts?'+soAjtN3yd04Jzr
				Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,zb2QIaL7Y4h9g8lSck,201)
			else: Wbmahg7dTR3qBJSvo09tfyFXH4YEj('folder',TbufdXZL9Ml72WmGcpQ5FAgBYKqa+title,url,205,nbOFVEDkpT4BIR7Qq82yPmHeJU,nbOFVEDkpT4BIR7Qq82yPmHeJU,XaxZd0lwYR)
	return
def BvsNfECRhmo(c2oNVv4ptmTlhgL9s,mode):
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.replace('=&','=0&')
	c2oNVv4ptmTlhgL9s = c2oNVv4ptmTlhgL9s.strip('&')
	brRAuE46JNZfie = {}
	if '=' in c2oNVv4ptmTlhgL9s:
		items = c2oNVv4ptmTlhgL9s.split('&')
		for xB2lOZNsPvFQDC4gMz in items:
			rm5wboALRxF2tlGd,XPL0O2VkI3w1C8enMaqi = xB2lOZNsPvFQDC4gMz.split('=')
			brRAuE46JNZfie[rm5wboALRxF2tlGd] = XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = nbOFVEDkpT4BIR7Qq82yPmHeJU
	TkPVaeQ9EG = ['category','release-year','genre','Quality']
	for key in TkPVaeQ9EG:
		if key in list(brRAuE46JNZfie.keys()): XPL0O2VkI3w1C8enMaqi = brRAuE46JNZfie[key]
		else: XPL0O2VkI3w1C8enMaqi = '0'
		if '%' not in XPL0O2VkI3w1C8enMaqi: XPL0O2VkI3w1C8enMaqi = lcxFAteLQ1Pwu45Er2(XPL0O2VkI3w1C8enMaqi)
		if mode=='modified_values' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+' + '+XPL0O2VkI3w1C8enMaqi
		elif mode=='modified_filters' and XPL0O2VkI3w1C8enMaqi!='0': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
		elif mode=='all': OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt+'&'+key+'='+XPL0O2VkI3w1C8enMaqi
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip(' + ')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.strip('&')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('=0','=')
	OToMpLKJVSPsZzfch4yEB1Q8wNlnbt = OToMpLKJVSPsZzfch4yEB1Q8wNlnbt.replace('Quality','quality')
	return OToMpLKJVSPsZzfch4yEB1Q8wNlnbt
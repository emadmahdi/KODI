# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'LODYNET'
K2l9rLfvoXxyZ4NYapO = '_LDN_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الرئيسية','استفسارتكم و الطلبات']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==450: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==451: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==452: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==453: OmsWt89dSA5HyCZ4wL = b2sn91A0exviPqhl65L7BQFr(url)
	elif mode==454: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==459: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LODYNET-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(BOI3t1w8qfHAb0Kl4oMye7haEWS,'url')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,459,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مثبتات لودي نت',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,451,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'المضاف حديثا',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,451,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'latest')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"MainMenu"(.*?)"SiteSlider"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if bigdh7fpZYl4aT2keV=='#': continue
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,451)
	return
def HAsKeZdTbqjPI1WY(url,H1yrgtivdZBUk2NOGx4LncKFSYCWX=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	items = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LODYNET-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if H1yrgtivdZBUk2NOGx4LncKFSYCWX=='featured':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"SiteSlider"(.*?)"waves"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif H1yrgtivdZBUk2NOGx4LncKFSYCWX=='latest':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"RecentPosts"(.*?)"pagination"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif '"ActorsList"' in FGRX4myP68S:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"ActorsList"(.*?)"text/javascript"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"(.*?)"ActorName">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif H1yrgtivdZBUk2NOGx4LncKFSYCWX in ['0','1','2']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"Section"(.*?)</li></ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[int(H1yrgtivdZBUk2NOGx4LncKFSYCWX)]
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"BlocksArea"(.*?)"text/javascript"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if not items: items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?data-src="(.*?)".*?<h2>(.*?)</h2>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','حلقة','الفيلم']
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if '"ActorsList"' in FGRX4myP68S and 'src=' in POjaBmHqzpsx1IYw7kQM4R:
			POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('src="(.*?)"',POjaBmHqzpsx1IYw7kQM4R,EcQxOa3RJm86WjTKA.DOTALL)
			POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0]
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV).strip('/')
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) حلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if not RrzpbE3t9woCk7MXS0GvNdi1BcV: RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if set(title.split()) & set(mmO39lwp0LFUrVT) and 'مسلسل' not in title:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,452,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'حلقة' in title:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,453,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/category/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,451,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,453,POjaBmHqzpsx1IYw7kQM4R)
	if H1yrgtivdZBUk2NOGx4LncKFSYCWX in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,'latest']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,451)
	return
def b2sn91A0exviPqhl65L7BQFr(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LODYNET-SEASONS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"CategorySubLinks"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G and 'href=' in str(y4IYUHTpSs8DXEfajQLvWb0g1G):
		title = EcQxOa3RJm86WjTKA.findall('<title>(.*?)-',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		title = title[0].strip(ksJdoFWhxTz8Y2N7bOZE)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,454)
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,454)
	else: eQgbVPaIBvTn8fsjJRt241(url)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LODYNET-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"EpisodesList"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('"og:image" content="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0] if POjaBmHqzpsx1IYw7kQM4R else fy8iFgEkrO12NR9TWBI35sjY6qHvV
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,452,POjaBmHqzpsx1IYw7kQM4R)
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,454)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,CXTL7NPUAE = [],[]
	YLKFRH6sSIrznXBg = url.replace('/movies/','/watch_movies/')
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.replace('/episodes/','/watch_episodes/')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LODYNET-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('<iframe src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
			CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
			A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__embed'
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"ServersList"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('data-embed="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if bigdh7fpZYl4aT2keV in CXTL7NPUAE: continue
			CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"DownloadLinks"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,name in items:
			if bigdh7fpZYl4aT2keV in CXTL7NPUAE: continue
			CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
			name = IVcCL3aAfU9wS7kWev1g2XBjZRJ(name)
			OOnVxtP0TNWsci6HrEGqBm9boKF7g = EcQxOa3RJm86WjTKA.findall('\d\d\d+',name,EcQxOa3RJm86WjTKA.DOTALL)
			if OOnVxtP0TNWsci6HrEGqBm9boKF7g:
				OOnVxtP0TNWsci6HrEGqBm9boKF7g = '____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g[0]
				name = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			else: OOnVxtP0TNWsci6HrEGqBm9boKF7g = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__download'+OOnVxtP0TNWsci6HrEGqBm9boKF7g
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search/'+search
	HAsKeZdTbqjPI1WY(url)
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
headers = { 'User-Agent' : fy8iFgEkrO12NR9TWBI35sjY6qHvV }
BfWYUAnyg6eONLjiuE = 'AKOAM'
K2l9rLfvoXxyZ4NYapO = '_AKO_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
ekIucSvHfrZOXqD7 = ['فيلم','كليب','العرض الاسبوعي','مسرحية','مسرحيه','اغنية','اعلان','لقاء']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==70: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==71: OmsWt89dSA5HyCZ4wL = C4B2gISwPdtL0nRrZ(url)
	elif mode==72: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==73: OmsWt89dSA5HyCZ4wL = SOnXP9KJ6mEoW(url)
	elif mode==74: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==79: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,79,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'سلسلة افلام',fy8iFgEkrO12NR9TWBI35sjY6qHvV,79,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'سلسلة افلام')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'سلاسل منوعة',fy8iFgEkrO12NR9TWBI35sjY6qHvV,79,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'سلسلة')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الكتب و الابحاث','الكورسات التعليمية','الألعاب','البرامج','الاجهزة اللوحية','الصور و الخلفيات','المصارعة الحرة']
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAM-MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="partions"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title not in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o:
				OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,71)
	return FGRX4myP68S
def C4B2gISwPdtL0nRrZ(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAM-CATEGORIES-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('sect_parts(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,72)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'جميع الفروع',url,72)
	else: HAsKeZdTbqjPI1WY(url,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	return
def HAsKeZdTbqjPI1WY(url,type):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKOAM-TITLES-1st')
	items = []
	if type=='featured':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('section_title featured_title(.*?)subjects-crousel',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"><div class="subject_box.*?src="(.*?)".*?<h3.*?>(.*?)</h3>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='search':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('akoam_result(.*?)<script',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?background-image: url\((.*?)\).*?<h1>(.*?)</h1>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	elif type=='more':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('section_title more_title(.*?)footer_bottom_services',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('navigation(.*?)<script',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not items and z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('div class="subject_box.*?href="(.*?)".*?src="(.*?)".*?<h3.*?>(.*?)</h3>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if 'توضيح هام' in title: continue
		title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if any(value in title for value in ekIucSvHfrZOXqD7): OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,73,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,73,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall("</li><li >.*?href='(.*?)'>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,72,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,type)
	return
def tzg4uErZxBkh2U6T9Y8Lj3cnW1Jb(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKOAM-SECTIONS-2nd')
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('"href","(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[1]
	return YLKFRH6sSIrznXBg
def SOnXP9KJ6mEoW(url):
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,'AKOAM-SECTIONS-1st')
	SCRYk0MdJgcGsI2uZ6ahU3vqBo4fEi = EcQxOa3RJm86WjTKA.findall('"(https*://akwam.net/\w+.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	zIX0HfJO3piETRAQLejYld27FB = EcQxOa3RJm86WjTKA.findall('"(https*://underurl.com/\w+.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if SCRYk0MdJgcGsI2uZ6ahU3vqBo4fEi or zIX0HfJO3piETRAQLejYld27FB:
		if SCRYk0MdJgcGsI2uZ6ahU3vqBo4fEi: MYWwFs7XA2 = SCRYk0MdJgcGsI2uZ6ahU3vqBo4fEi[0]
		elif zIX0HfJO3piETRAQLejYld27FB: MYWwFs7XA2 = tzg4uErZxBkh2U6T9Y8Lj3cnW1Jb(zIX0HfJO3piETRAQLejYld27FB[0])
		MYWwFs7XA2 = U2Z7CVFftTmLeK3nzEbQPGga(MYWwFs7XA2)
		import tt9rH5O0wE
		if '/series/' in MYWwFs7XA2 or '/shows/' in MYWwFs7XA2: tt9rH5O0wE.eQgbVPaIBvTn8fsjJRt241(MYWwFs7XA2)
		else: tt9rH5O0wE.rr7SfotkneX85Klup(MYWwFs7XA2)
		return
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('محتوى الفيلم.*?>.*?(\w*?)\W*?<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	items = EcQxOa3RJm86WjTKA.findall('<br />\n<a href="(.*?)".*?<span style="color:.*?">(.*?)</span>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,73)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="sub_title".*?<h1.*?>(.*?)</h1>.*?class="main_img".*?src="(.*?)".*?ad-300-250(.*?)ako-feedback',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D:
		a6rVSjDMF87KyYINcuOP1l40Hbp('خطأ خارجي','لا يوجد ملف فيديو')
		return
	name,POjaBmHqzpsx1IYw7kQM4R,wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	name = name.strip(ksJdoFWhxTz8Y2N7bOZE)
	if 'sub_epsiode_title' in wlJ6d8hEvpoMNSCmU:
		items = EcQxOa3RJm86WjTKA.findall('sub_epsiode_title">(.*?)</h2>.*?sub_file_title.*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	else:
		d9TzUGtPQxZaEWJoL6ul = EcQxOa3RJm86WjTKA.findall('sub_file_title\'>(.*?) - <i>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		items = []
		for filename in d9TzUGtPQxZaEWJoL6ul:
			items.append( ('رابط التشغيل',filename) )
	if not items: items = [ ('رابط التشغيل',fy8iFgEkrO12NR9TWBI35sjY6qHvV) ]
	count = 0
	WFlpmsYGKNy,KTnGeFXz9i = [],[]
	size = len(items)
	for title,filename in items:
		BIbU1q2NrFX = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		if ' - ' in filename: filename = filename.split(' - ')[0]
		else: filename = 'dummy.zip'
		if '.' in filename: BIbU1q2NrFX = filename.split('.')[-1]
		title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
		WFlpmsYGKNy.append(title)
		KTnGeFXz9i.append(count)
		count += 1
	if size>0:
		if any(value in name for value in ekIucSvHfrZOXqD7):
			if size==1:
				yNqzFDjKM0SrO = 0
			else:
				yNqzFDjKM0SrO = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('اختر الفيديو المناسب:', WFlpmsYGKNy)
				if yNqzFDjKM0SrO == -1: return
			rr7SfotkneX85Klup(url+'?section='+str(1+KTnGeFXz9i[size-yNqzFDjKM0SrO-1]))
		else:
			for pk6YWixXFSrDLKCnlN39w in reversed(range(size)):
				title = name + ' - ' + WFlpmsYGKNy[pk6YWixXFSrDLKCnlN39w]
				title = title.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
				bigdh7fpZYl4aT2keV = url + '?section='+str(size-pk6YWixXFSrDLKCnlN39w)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,74,POjaBmHqzpsx1IYw7kQM4R)
	else:
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+'الرابط ليس فيديو',fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	YLKFRH6sSIrznXBg,RrzpbE3t9woCk7MXS0GvNdi1BcV = url.split('?section=')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,True,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'AKOAM-PLAY_AKOAM-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('ad-300-250.*?ad-300-250(.*?)ako-feedback',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j = z6PX2p7diaskQElBOvMRNcHwqG5D[0].replace("'direct_link_box",'"direct_link_box epsoide_box')
	Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j = Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j + 'direct_link_box'
	VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('epsoide_box(.*?)direct_link_box',Z8mPo7yQLdXJvOrzD1CkBUVHgqWp4j,EcQxOa3RJm86WjTKA.DOTALL)
	RrzpbE3t9woCk7MXS0GvNdi1BcV = len(VuGmoESTAfXlv5tD76PW1Masq0peB)-int(RrzpbE3t9woCk7MXS0GvNdi1BcV)
	wlJ6d8hEvpoMNSCmU = VuGmoESTAfXlv5tD76PW1Masq0peB[RrzpbE3t9woCk7MXS0GvNdi1BcV]
	hFzEyHWOoRxG = []
	K1QiplCIf7WLZMgeVruAy = {'1423075862':'dailymotion','1477487601':'estream','1505328404':'streamango',
		'1423080015':'flashx','1458117295':'openload','1423079306':'vimple','1430052371':'ok.ru',
		'1477488213':'thevid','1558278006':'uqload','1477487990':'vidtodo'}
	items = EcQxOa3RJm86WjTKA.findall("class='download_btn.*?href='(.*?)'",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV in items:
		hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named=________akoam')
	items = EcQxOa3RJm86WjTKA.findall('background-image: url\((.*?)\).*?href=\'(.*?)\'',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for tdjrnWBA1hDwlSf4,bigdh7fpZYl4aT2keV in items:
		tdjrnWBA1hDwlSf4 = tdjrnWBA1hDwlSf4.split('/')[-1]
		tdjrnWBA1hDwlSf4 = tdjrnWBA1hDwlSf4.split('.')[0]
		if tdjrnWBA1hDwlSf4 in K1QiplCIf7WLZMgeVruAy:
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+K1QiplCIf7WLZMgeVruAy[tdjrnWBA1hDwlSf4]+'________akoam')
		else: hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+tdjrnWBA1hDwlSf4+'________akoam')
	if not hFzEyHWOoRxG:
		message = EcQxOa3RJm86WjTKA.findall('sub-no-file.*?\n(.*?)\n',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if message: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من الموقع الاصلي',message[0])
	else:
		import TT24gHhkWI
		TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'%20')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS + '/search/'+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,'search')
	return
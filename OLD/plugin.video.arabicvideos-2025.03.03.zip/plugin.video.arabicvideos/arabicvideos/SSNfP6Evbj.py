# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'CIMACLUP'
K2l9rLfvoXxyZ4NYapO = '_CMC_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['موقع نتفليكس']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==490: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==491: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==492: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==493: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==494: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==499: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text,url)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMACLUP-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ[0].strip('/')
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,'url')
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"filter AjaxifyFilter"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('data-filter="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/wp-content/themes/old/filter/'+bigdh7fpZYl4aT2keV+'.php'
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,491)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'أفلام',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/category/افلام-movies-filme/foreign-hd-افلام-اجنبى-2',494,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'مسلسلات',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/category/مسلسلات/مسلسلات-اجنبى',494,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="navigation-menu"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if bigdh7fpZYl4aT2keV=='/': continue
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+bigdh7fpZYl4aT2keV
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,491)
	return FGRX4myP68S
def vloIZHenE7imycDM2tPQ(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMACLUP-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"filter"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,491)
	return
def HAsKeZdTbqjPI1WY(url,H1yrgtivdZBUk2NOGx4LncKFSYCWX=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	items = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMACLUP-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	wlJ6d8hEvpoMNSCmU = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if '.php' in url: wlJ6d8hEvpoMNSCmU = FGRX4myP68S
	elif '?s=' in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"blocks(.*?)"manifest"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"Blocks(.*?)"manifest"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if not wlJ6d8hEvpoMNSCmU: return
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','أغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) حلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if not RrzpbE3t9woCk7MXS0GvNdi1BcV: RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if not RrzpbE3t9woCk7MXS0GvNdi1BcV or any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,492,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'حلقة' in title:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,493,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,493,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<li><a href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			title = title.replace('الصفحة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,491)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMACLUP-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	YLKFRH6sSIrznXBg = EcQxOa3RJm86WjTKA.findall('"ButtonsBarCo".*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if YLKFRH6sSIrznXBg:
		YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg[0]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMACLUP-EPISODES-2nd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('"img-responsive" src="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if POjaBmHqzpsx1IYw7kQM4R: POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0]
	else: POjaBmHqzpsx1IYw7kQM4R = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Thumb')
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"filter"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"Blocks(.*?)class="pagination"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G and '/series/' not in url:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,493,POjaBmHqzpsx1IYw7kQM4R)
	elif UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?image\:url\((.*?)\).*?"boxtitle">(.*?)</div>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,492,POjaBmHqzpsx1IYw7kQM4R)
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				title = title.replace('الصفحة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,491)
	return
def rr7SfotkneX85Klup(url):
	YLKFRH6sSIrznXBg = url.strip('/')+'/?view=1'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMACLUP-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	XoSyx7p6dqZ1CF8 = []
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	zVd04D3liIfSUhNRnKgF = EcQxOa3RJm86WjTKA.findall("data: 'q=(.*?)&",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	zVd04D3liIfSUhNRnKgF = zVd04D3liIfSUhNRnKgF[0]
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"serversList"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('data-server="(.*?)">(.*?)</li>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for AKVqfPYHXlnjz2hrF3ykG,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/wp-content/themes/old/servers/server.php?q='+zVd04D3liIfSUhNRnKgF+'&i='+AKVqfPYHXlnjz2hrF3ykG+'?named='+title+'__watch'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"embedServer".*?SRC="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if bigdh7fpZYl4aT2keV:
		title = 'مفضل'
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]+'?named=__embed__'+title
		XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"downloadsList"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<td>(.*?)</td>.*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for title,bigdh7fpZYl4aT2keV in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if 'anavidz' in bigdh7fpZYl4aT2keV: D4DQ6k0oS39GKbZrthnsTB = '__خاص'
			else: D4DQ6k0oS39GKbZrthnsTB = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download'+D4DQ6k0oS39GKbZrthnsTB
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search,VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ: VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = BOI3t1w8qfHAb0Kl4oMye7haEWS
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not search: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/index.php?s='+search
	HAsKeZdTbqjPI1WY(url)
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'EGYBEST2'
K2l9rLfvoXxyZ4NYapO = '_EB2_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['المصارعة الحرة','ايجي بيست','عروض المصارعة','egybest','ايجي بست البديل','ايجى بست الجديد']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,jmI9qRnVJo2a3tpcH8gfYkP,text):
	if   mode==780: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==781: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==782: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==783: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==784: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'FULL_FILTER___'+text)
	elif mode==785: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'DEFINED_FILTER___'+text)
	elif mode==786: OmsWt89dSA5HyCZ4wL = VNPHFcK5wvfL67Roir0Y(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==789: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,789,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST2-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('list-pages(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)</span>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,781)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-article(.*?)social-box',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('main-title.*?">(.*?)<.*?href="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for title,bigdh7fpZYl4aT2keV in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'mainmenu')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-menu(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if any(value in title for value in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o): continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,781)
	return
def VNPHFcK5wvfL67Roir0Y(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST2-SEASONS_EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-article".*?">(.*?)<(.*?)article',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		CSX1FDkQOU,jbpHA8eDFYwlT,items = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
		for name,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			if 'حلقات' in name: jbpHA8eDFYwlT = wlJ6d8hEvpoMNSCmU
			if 'مواسم' in name: CSX1FDkQOU = wlJ6d8hEvpoMNSCmU
		if CSX1FDkQOU and not type:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?data-src="(.*?)".*?"title">(.*?)<',CSX1FDkQOU,EcQxOa3RJm86WjTKA.DOTALL)
			if len(items)>1:
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,786,POjaBmHqzpsx1IYw7kQM4R,'season')
		if jbpHA8eDFYwlT and len(items)<2:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?data-src="(.*?)".*?title="(.*?)"',jbpHA8eDFYwlT,EcQxOa3RJm86WjTKA.DOTALL)
			if items:
				for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,783,POjaBmHqzpsx1IYw7kQM4R)
			else:
				items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)<',jbpHA8eDFYwlT,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in items:
					OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,783)
		else: HAsKeZdTbqjPI1WY(url,'episodes')
	return
def HAsKeZdTbqjPI1WY(url,type=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if 'pagination' in type or 'filter' in type:
		YLKFRH6sSIrznXBg,data = url.split('?separator&')
		headers = {'Content-Type':'application/x-www-form-urlencoded'}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',YLKFRH6sSIrznXBg,data,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST2-TITLES-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		FGRX4myP68S = 'blocks'+FGRX4myP68S+'article'
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST2-TITLES-2nd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items,FFvZ6iAMxpBE,p9UP6wGlC1BF7fN2 = [],False,False
	if not type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-content(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'submenu')
				FFvZ6iAMxpBE = True
	if not type:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('all-taxes(.*?)"load"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D and type!='filter':
			if FFvZ6iAMxpBE: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',url,785,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',url,784,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			p9UP6wGlC1BF7fN2 = True
	if (not FFvZ6iAMxpBE and not p9UP6wGlC1BF7fN2) or type=='episodes':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('blocks(.*?)article',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?src="(.*?)".*?class="title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.strip(C0qrknitpM4Z)
				bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
				if '/selary/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,786,POjaBmHqzpsx1IYw7kQM4R)
				elif type=='episodes' or 'pagination' in type: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,783,POjaBmHqzpsx1IYw7kQM4R)
				elif 'حلقة' in title:
					RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
					if RrzpbE3t9woCk7MXS0GvNdi1BcV:
						title = '_MOD_'+RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
						if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
							OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,786,POjaBmHqzpsx1IYw7kQM4R)
							cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
				elif 'مسلسل' in bigdh7fpZYl4aT2keV and 'حلقة' not in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,786,POjaBmHqzpsx1IYw7kQM4R)
				elif 'موسم' in bigdh7fpZYl4aT2keV and 'حلقة' not in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,786,POjaBmHqzpsx1IYw7kQM4R)
				else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,783,POjaBmHqzpsx1IYw7kQM4R)
		if 'search' in type: z4O1GBfKgIn3W6byE = 12
		else: z4O1GBfKgIn3W6byE = 16
		data = EcQxOa3RJm86WjTKA.findall('class="(load-more.*?) .*?data-(.*?)="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if len(items)==z4O1GBfKgIn3W6byE and (data or 'pagination' in type):
			if data:
				offset = z4O1GBfKgIn3W6byE
				WWb2t4zoZspJfK,name,value = data[0]
				WWb2t4zoZspJfK = WWb2t4zoZspJfK.replace('load','get').replace('-','_').replace('"',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			else:
				data = EcQxOa3RJm86WjTKA.findall('action=(.*?)&offset=(.*?)&(.*?)=(.*?)$',url,EcQxOa3RJm86WjTKA.DOTALL)
				if data: WWb2t4zoZspJfK,offset,name,value = data[0]
				offset = int(offset)+z4O1GBfKgIn3W6byE
			data = 'action='+WWb2t4zoZspJfK+'&offset='+str(offset)+'&'+name+'='+value
			url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-admin/admin-ajax.php?separator&'+data
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المزيد',url,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'pagination_'+type)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST2-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	hFzEyHWOoRxG,jQkdt6rvnxW8 = [],[]
	items = EcQxOa3RJm86WjTKA.findall('server-item.*?data-code="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for DdTIjWBhMuf6Gyz8mO2XaK7P9LoS3 in items:
		GGiqyfV7QnhIbzDBoZ = JNfHYgOdP9aR.b64decode(DdTIjWBhMuf6Gyz8mO2XaK7P9LoS3)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: GGiqyfV7QnhIbzDBoZ = GGiqyfV7QnhIbzDBoZ.decode(Tk9eH2qw6Brsuhj)
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('src="(.*?)"',GGiqyfV7QnhIbzDBoZ,EcQxOa3RJm86WjTKA.DOTALL)
		if bigdh7fpZYl4aT2keV:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			if bigdh7fpZYl4aT2keV not in jQkdt6rvnxW8:
				jQkdt6rvnxW8.append(bigdh7fpZYl4aT2keV)
				A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__watch')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="downloads(.*?)</section>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('<div>[ a-zA-Z]*(\d{3,4})[ a-zA-Z]*</div>.*?href=".*?download=(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for OOnVxtP0TNWsci6HrEGqBm9boKF7g,S6x23cneZY4OwamzrRBTQHos in items:
			bigdh7fpZYl4aT2keV = JNfHYgOdP9aR.b64decode(S6x23cneZY4OwamzrRBTQHos)
			if jTDWgftK7NEmx0JAkOn2aRIvweq: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.decode(Tk9eH2qw6Brsuhj)
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
			if bigdh7fpZYl4aT2keV not in jQkdt6rvnxW8:
				jQkdt6rvnxW8.append(bigdh7fpZYl4aT2keV)
				A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
				hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__download____'+OOnVxtP0TNWsci6HrEGqBm9boKF7g)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if not search: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'-')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/find/?q='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
	HAsKeZdTbqjPI1WY(url,'search')
	return
def dfqB809Vbp6nyMRcmHvwZ(url):
	url = url.split('/smartemadfilter?')[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST2-GET_FILTERS_BLOCKS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	W1A4L5P0Zc8wHnUGjVexElz = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('main-article(.*?)article',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('data-tax="(.*?)".*?<span>(.*?)<(.*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		i6m2Skc3nesTYu7QjPJWbxlay,ny5fseD6KMzR8m3vSE,VuGmoESTAfXlv5tD76PW1Masq0peB = zip(*W1A4L5P0Zc8wHnUGjVexElz)
		W1A4L5P0Zc8wHnUGjVexElz = zip(ny5fseD6KMzR8m3vSE,i6m2Skc3nesTYu7QjPJWbxlay,VuGmoESTAfXlv5tD76PW1Masq0peB)
	return W1A4L5P0Zc8wHnUGjVexElz
def XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU):
	items = EcQxOa3RJm86WjTKA.findall('value="(.*?)">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return items
def rCk5v93oAu1dgc8tzlOB4(url):
	if '/smartemadfilter' not in url: YLKFRH6sSIrznXBg,SlzErbh12BCt = url,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: YLKFRH6sSIrznXBg,SlzErbh12BCt = url.split('/smartemadfilter')
	MYWwFs7XA2,T4X6dIfHYUWhOrvLajEw = lNyxXsMAcYHBUDh4dJbfTWR(SlzErbh12BCt)
	bbTrK0zPUoJCwLyu = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for key in list(T4X6dIfHYUWhOrvLajEw.keys()):
		bbTrK0zPUoJCwLyu += '&args%5B'+key+'%5D='+T4X6dIfHYUWhOrvLajEw[key]
	hL4w3zgankZR75698QCyi = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/wp-admin/admin-ajax.php?separator&action=get_filterd_blocks'+bbTrK0zPUoJCwLyu
	return hL4w3zgankZR75698QCyi
gFxHyVTwqu3CBirYP8 = ['release-year','language','genre','nation','category','quality','resolution']
ddWq05NVRP = ['release-year','language','genre']
def F4ehkvPDxXU(url,filter):
	url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='DEFINED_FILTER':
		if ddWq05NVRP[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ddWq05NVRP[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ddWq05NVRP[0:-1])):
			if ddWq05NVRP[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ddWq05NVRP[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='FULL_FILTER':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		if not QlOXcH07nRVPAZub8pD356xMvdk4: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+QlOXcH07nRVPAZub8pD356xMvdk4
		MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',MYWwFs7XA2,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',MYWwFs7XA2,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	W1A4L5P0Zc8wHnUGjVexElz = dfqB809Vbp6nyMRcmHvwZ(url)
	dict = {}
	for name,jLA9nhxoZbG,wlJ6d8hEvpoMNSCmU in W1A4L5P0Zc8wHnUGjVexElz:
		name = name.replace('كل ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		items = XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='DEFINED_FILTER':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<2:
				if jLA9nhxoZbG==ddWq05NVRP[-1]:
					MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
					HAsKeZdTbqjPI1WY(MYWwFs7XA2,'filter')
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'DEFINED_FILTER___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				if jLA9nhxoZbG==ddWq05NVRP[-1]:
					MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع ',MYWwFs7XA2,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع ',YLKFRH6sSIrznXBg,785,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='FULL_FILTER':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع :'+name,YLKFRH6sSIrznXBg,784,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if not value: continue
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'#+dict[jLA9nhxoZbG]['0']
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'+name
			if type=='FULL_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,784,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='DEFINED_FILTER' and ddWq05NVRP[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'modified_filters')
				YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
				MYWwFs7XA2 = rCk5v93oAu1dgc8tzlOB4(YLKFRH6sSIrznXBg)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,781,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			elif type=='DEFINED_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,785,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.replace('=&','=0&')
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for key in gFxHyVTwqu3CBirYP8:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.replace('=0','=')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
﻿# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH,Hx4QNEMhZLfBVyKlcuednr):
	if Hx4QNEMhZLfBVyKlcuednr==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	if hO3D6GVPY2qENv8bZWH==1:
		JgqxhebYEvdOi2 = nn19vN7ifGslVJODZWzCSudBK8.getCurrentWindowDialogId()
		IZEyPUqTXniB9x3fcCV7NYlpLA4g = nn19vN7ifGslVJODZWzCSudBK8.Window(JgqxhebYEvdOi2)
		Hx4QNEMhZLfBVyKlcuednr = RRS3fV9tw8o5WGdQanhEH2(Hx4QNEMhZLfBVyKlcuednr)
		IZEyPUqTXniB9x3fcCV7NYlpLA4g.getControl(311).setLabel(Hx4QNEMhZLfBVyKlcuednr)
	if hO3D6GVPY2qENv8bZWH==0:
		ZJqDh4ByGPQn13tlzMOTLCNdcugx='X'
		if jTDWgftK7NEmx0JAkOn2aRIvweq: oHC4yceb8Y3a6 = isinstance(Hx4QNEMhZLfBVyKlcuednr,str)
		else: oHC4yceb8Y3a6 = isinstance(Hx4QNEMhZLfBVyKlcuednr,unicode)
		if oHC4yceb8Y3a6==True: ZJqDh4ByGPQn13tlzMOTLCNdcugx='U'
		CS42MJcr01tFIK=str(type(Hx4QNEMhZLfBVyKlcuednr))+ksJdoFWhxTz8Y2N7bOZE+Hx4QNEMhZLfBVyKlcuednr+ksJdoFWhxTz8Y2N7bOZE+ZJqDh4ByGPQn13tlzMOTLCNdcugx+ksJdoFWhxTz8Y2N7bOZE
		for pk6YWixXFSrDLKCnlN39w in range(0,len(Hx4QNEMhZLfBVyKlcuednr),1):
			CS42MJcr01tFIK += hex(ord(Hx4QNEMhZLfBVyKlcuednr[pk6YWixXFSrDLKCnlN39w])).replace('0x',fy8iFgEkrO12NR9TWBI35sjY6qHvV)+ksJdoFWhxTz8Y2N7bOZE
		Hx4QNEMhZLfBVyKlcuednr = RRS3fV9tw8o5WGdQanhEH2(Hx4QNEMhZLfBVyKlcuednr)
		ZJqDh4ByGPQn13tlzMOTLCNdcugx='X'
		if jTDWgftK7NEmx0JAkOn2aRIvweq: oHC4yceb8Y3a6 = isinstance(Hx4QNEMhZLfBVyKlcuednr, str)
		else: oHC4yceb8Y3a6 = isinstance(Hx4QNEMhZLfBVyKlcuednr, unicode)
		if oHC4yceb8Y3a6==True: ZJqDh4ByGPQn13tlzMOTLCNdcugx='U'
		ApZQBXlYvwTyWtF=str(type(Hx4QNEMhZLfBVyKlcuednr))+ksJdoFWhxTz8Y2N7bOZE+Hx4QNEMhZLfBVyKlcuednr+ksJdoFWhxTz8Y2N7bOZE+ZJqDh4ByGPQn13tlzMOTLCNdcugx+ksJdoFWhxTz8Y2N7bOZE
		for pk6YWixXFSrDLKCnlN39w in range(0,len(Hx4QNEMhZLfBVyKlcuednr),1):
			ApZQBXlYvwTyWtF += hex(ord(Hx4QNEMhZLfBVyKlcuednr[pk6YWixXFSrDLKCnlN39w])).replace('0x',fy8iFgEkrO12NR9TWBI35sjY6qHvV)+ksJdoFWhxTz8Y2N7bOZE
	return
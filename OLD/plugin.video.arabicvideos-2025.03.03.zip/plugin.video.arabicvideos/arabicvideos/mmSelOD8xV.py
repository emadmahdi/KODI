# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'CIMA4U'
headers = {'User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
K2l9rLfvoXxyZ4NYapO = '_C4U_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['مصارعة حرة','اخري','اخرى','الرئيسية','بدون إختيار','افلام','مسلسلات']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==420: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==421: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==422: OmsWt89dSA5HyCZ4wL = b2sn91A0exviPqhl65L7BQFr(url)
	elif mode==423: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==424: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'ALL_ITEMS_FILTER___'+text)
	elif mode==425: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url,'SPECIFIED_FILTER___'+text)
	elif mode==426: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==427: OmsWt89dSA5HyCZ4wL = mmLIAh1vCkycfjVGMT5XQ(url)
	elif mode==429: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = EcQxOa3RJm86WjTKA.findall('href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ[0].strip('/')
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,'url')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,429,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر محدد',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,425)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'فلتر كامل',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,424)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+'الرئيسية',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,421)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('NavigationMenu(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="*(.*?)"*>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if '/actors' in bigdh7fpZYl4aT2keV: title = 'أفلام النجوم'
		elif '/netflix' in bigdh7fpZYl4aT2keV: title = 'أفلام ومسلسلات نيتفلكس'
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,421)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'قائمة تفصيلية',VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ,427)
	return
def mmLIAh1vCkycfjVGMT5XQ(website=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('FilteringTitle(.*?)PageTitle',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('data-tax="*(.*?)"* data-id="*(.*?)[">]*<a href="*(.*?)[">]+.*?</div>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for fnogyzNA30JCPMYqHTavG7ZKp,id,bigdh7fpZYl4aT2keV,title in items:
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if 'netflix-movies' in bigdh7fpZYl4aT2keV: title = 'أفلام نيتفلكس'
		elif 'series-netflix' in bigdh7fpZYl4aT2keV: title = 'مسلسلات نيتفلكس'
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,421,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fnogyzNA30JCPMYqHTavG7ZKp+'|'+id)
	return
def HAsKeZdTbqjPI1WY(url,H1yrgtivdZBUk2NOGx4LncKFSYCWX=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if '/HomepageLoader/' in url: url = url.strip('/')+'/mpaa/family/'
	items = []
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	if not H1yrgtivdZBUk2NOGx4LncKFSYCWX or '|' in H1yrgtivdZBUk2NOGx4LncKFSYCWX:
		if '|' not in H1yrgtivdZBUk2NOGx4LncKFSYCWX: k8f1ct2vaPHNbEMId = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		else: k8f1ct2vaPHNbEMId = '/archive/'+H1yrgtivdZBUk2NOGx4LncKFSYCWX
		Q2l3BGZqfz7kjepvxwdWirF0DsRoC = False
		if 'PinSlider' in FGRX4myP68S:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'المميزة',url,421,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'featured')
			Q2l3BGZqfz7kjepvxwdWirF0DsRoC = True
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('PageTitle(.*?)PageContent',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			OOCx0SzAcisQIJGM6DZkopvB3 = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('data-tab="(.*?)".*?<span>(.*?)<',OOCx0SzAcisQIJGM6DZkopvB3,EcQxOa3RJm86WjTKA.DOTALL)
			for TiQO5rbdPRM6,D4DQ6k0oS39GKbZrthnsTB in w7gedkFbJvcqu0fzW43NpyUP:
				R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/ajaxcenter/action/HomepageLoader/tab/'+TiQO5rbdPRM6+k8f1ct2vaPHNbEMId+'/'
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+D4DQ6k0oS39GKbZrthnsTB,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,421)
				Q2l3BGZqfz7kjepvxwdWirF0DsRoC = True
		if Q2l3BGZqfz7kjepvxwdWirF0DsRoC: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	if H1yrgtivdZBUk2NOGx4LncKFSYCWX=='featured':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('PinSlider(.*?)MultiFilter',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('PinSlider(.*?)PageTitle',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		else: wlJ6d8hEvpoMNSCmU = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	elif '/HomepageLoader/' in url or '/searchcenter/' in url:
		wlJ6d8hEvpoMNSCmU = FGRX4myP68S
	elif '/filter/' in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('PageContent(.*?)class="*pagination"*',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif '/actors' in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('PageContent(.*?)class="*pagination"*',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="*(.*?)[">]+.*?image:url\((.*?)\).*?ActorName">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('Cima4uBlocks(.*?)</li></ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		else: wlJ6d8hEvpoMNSCmU = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if not items: items = EcQxOa3RJm86WjTKA.findall('class="*MovieBlock"*.*?href="*(.*?)[">]+.*?image:url\((.*?)\).*?image.*?BoxTitleInfo.*?</div></div>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if not items: items = EcQxOa3RJm86WjTKA.findall('class="MovieBlock".*?href="(.*?)".*?data-image="(.*?)".*?alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		if not title: continue
		if '?news=' in bigdh7fpZYl4aT2keV: continue
		title = title.replace('مشاهدة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) حلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if RrzpbE3t9woCk7MXS0GvNdi1BcV and 'حلقة' in title:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,422,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/actor/' in bigdh7fpZYl4aT2keV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,421,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,422,POjaBmHqzpsx1IYw7kQM4R)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('pagination(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D and H1yrgtivdZBUk2NOGx4LncKFSYCWX!='featured':
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href=[\'\"](.*?)[\'\"]>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
			title = title.replace('الصفحة ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,421)
	jFlCHGZzvXw5E = EcQxOa3RJm86WjTKA.findall('</li><a href="(.*?)".*?>(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if jFlCHGZzvXw5E:
		bigdh7fpZYl4aT2keV,title = jFlCHGZzvXw5E[0]
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,421)
	return
def b2sn91A0exviPqhl65L7BQFr(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-SEASONS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="WatchNow".*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		url = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-SEASONS-2nd')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('SeasonsSections(.*?)</div></div></div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if '/tag/' in url or '/actor' in url:
		HAsKeZdTbqjPI1WY(url)
	elif z6PX2p7diaskQElBOvMRNcHwqG5D:
		POjaBmHqzpsx1IYw7kQM4R = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Thumb')
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall("href='(.*?)'>(.*?)<",wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		zhsV1MT9E2BjOw7dq0Fvmu = ['مسلسل','موسم','برنامج','حلقة']
		for bigdh7fpZYl4aT2keV,title in items:
			if any(value in title for value in zhsV1MT9E2BjOw7dq0Fvmu):
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,423,POjaBmHqzpsx1IYw7kQM4R)
			else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,426,POjaBmHqzpsx1IYw7kQM4R)
	else: eQgbVPaIBvTn8fsjJRt241(url)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	POjaBmHqzpsx1IYw7kQM4R = EcQxOa3RJm86WjTKA.findall('"background-image:url\((.*?)\)',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if POjaBmHqzpsx1IYw7kQM4R: POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R[0]
	else: POjaBmHqzpsx1IYw7kQM4R = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	IpngyHN0hFoXLsZuEw7T1mzeAxCc = EcQxOa3RJm86WjTKA.findall('EpisodesSection(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if IpngyHN0hFoXLsZuEw7T1mzeAxCc:
		wlJ6d8hEvpoMNSCmU = IpngyHN0hFoXLsZuEw7T1mzeAxCc[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"><em>(.*?)<.*?<span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,RrzpbE3t9woCk7MXS0GvNdi1BcV in items:
			title = title+ksJdoFWhxTz8Y2N7bOZE+RrzpbE3t9woCk7MXS0GvNdi1BcV
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,426,POjaBmHqzpsx1IYw7kQM4R)
	else: OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+'رابط التشغيل',url,426,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	rHu4wJ5Ko1qRmUI7pbB = E6ECvznP9m5sWFMu.url
	if gZlSEJaXO9F461AL3sR7rWNpqf: rHu4wJ5Ko1qRmUI7pbB = rHu4wJ5Ko1qRmUI7pbB.encode(Tk9eH2qw6Brsuhj)
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(rHu4wJ5Ko1qRmUI7pbB,'url')
	XoSyx7p6dqZ1CF8 = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('WatchSection(.*?)</div></div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('data-link="(.*?)".*? />(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for cTUQ5iedtAwZgpqhHI3NsoLWaP,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if 'myvid' in title.lower(): title = 'خاص '+title
			bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/structure/server.php?id='+cTUQ5iedtAwZgpqhHI3NsoLWaP+'?named='+title+'__watch'
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('DownloadServers(.*?)</div></div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*? />(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			title = title.strip(ksJdoFWhxTz8Y2N7bOZE)
			if 'myvid' in title.lower(): D4DQ6k0oS39GKbZrthnsTB = '__خاص'
			else: D4DQ6k0oS39GKbZrthnsTB = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__download'+D4DQ6k0oS39GKbZrthnsTB
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/Search?q='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
def dfqB809Vbp6nyMRcmHvwZ(url):
	if 'smartemadfilter' not in url: url = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	else: url = url.split('/smartemadfilter?')[0]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'CIMA4U-GET_FILTERS_BLOCKS-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('MultiFilter(.*?)PageTitle',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	W1A4L5P0Zc8wHnUGjVexElz = EcQxOa3RJm86WjTKA.findall('Hoverable.*?<span>(.*?)</span>.*?"all".*?(data-tax="(.*?)".*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return W1A4L5P0Zc8wHnUGjVexElz
def XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU):
	items = EcQxOa3RJm86WjTKA.findall('data-id="(.*?)".*?</div>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	return items
def U3Kb7B2Nd5VO1agDkxMsn9C4(url):
	uHyjkzgiAsGW5ZIb9U6TlV = url.split('/smartemadfilter?')[0]
	EW6mPCkSQRzH3Yw8ITFpc4nv5M = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	url = url.replace(uHyjkzgiAsGW5ZIb9U6TlV,EW6mPCkSQRzH3Yw8ITFpc4nv5M)
	url = url.replace('/smartemadfilter?','/ajaxcenter/action/HomepageLoader/')
	url = url.replace('=','/').replace('&','/')
	url = url+'/'
	return url
ffJIco45MG9kFntgWDwqyR = ['category','types','release-year']
nohzWuNjPvp0MA = ['Quality','release-year','types','category']
def F4ehkvPDxXU(url,filter):
	if '?' in url: url = url.split('/smartemadfilter?')[0]
	type,filter = filter.split('___',1)
	if filter==fy8iFgEkrO12NR9TWBI35sjY6qHvV: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	else: NnQ1hEsTV7Zaz3HKdfu,QlOXcH07nRVPAZub8pD356xMvdk4 = filter.split('___')
	if type=='SPECIFIED_FILTER':
		if '/category/' in url:
			global ffJIco45MG9kFntgWDwqyR
			ffJIco45MG9kFntgWDwqyR = ffJIco45MG9kFntgWDwqyR[1:]
		if ffJIco45MG9kFntgWDwqyR[0]+'=' not in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[0]
		for pk6YWixXFSrDLKCnlN39w in range(len(ffJIco45MG9kFntgWDwqyR[0:-1])):
			if ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w]+'=' in NnQ1hEsTV7Zaz3HKdfu: fnogyzNA30JCPMYqHTavG7ZKp = ffJIco45MG9kFntgWDwqyR[pk6YWixXFSrDLKCnlN39w+1]
		z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+fnogyzNA30JCPMYqHTavG7ZKp+'=0'
		HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb.strip('&')+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq.strip('&')
		F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
	elif type=='ALL_ITEMS_FILTER':
		QUFL2gEBMn63qlsmI7W = nKT1QuLoXPc8CjyV(NnQ1hEsTV7Zaz3HKdfu,'modified_values')
		QUFL2gEBMn63qlsmI7W = U2Z7CVFftTmLeK3nzEbQPGga(QUFL2gEBMn63qlsmI7W)
		if QlOXcH07nRVPAZub8pD356xMvdk4!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: QlOXcH07nRVPAZub8pD356xMvdk4 = nKT1QuLoXPc8CjyV(QlOXcH07nRVPAZub8pD356xMvdk4,'modified_filters')
		if QlOXcH07nRVPAZub8pD356xMvdk4==fy8iFgEkrO12NR9TWBI35sjY6qHvV: YLKFRH6sSIrznXBg = url
		else: YLKFRH6sSIrznXBg = url+'/smartemadfilter?'+QlOXcH07nRVPAZub8pD356xMvdk4
		YLKFRH6sSIrznXBg = U3Kb7B2Nd5VO1agDkxMsn9C4(YLKFRH6sSIrznXBg)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'أظهار قائمة الفيديو التي تم اختيارها ',YLKFRH6sSIrznXBg,421,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+' [[   '+QUFL2gEBMn63qlsmI7W+'   ]]',YLKFRH6sSIrznXBg,421,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	W1A4L5P0Zc8wHnUGjVexElz = dfqB809Vbp6nyMRcmHvwZ(url)
	dict = {}
	for name,wlJ6d8hEvpoMNSCmU,jLA9nhxoZbG in W1A4L5P0Zc8wHnUGjVexElz:
		if '/category/' in url and jLA9nhxoZbG=='category': continue
		name = name.replace('--',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		items = XkO6QiU8yILWlfg(wlJ6d8hEvpoMNSCmU)
		if '=' not in YLKFRH6sSIrznXBg: YLKFRH6sSIrznXBg = url
		if type=='SPECIFIED_FILTER':
			if fnogyzNA30JCPMYqHTavG7ZKp!=jLA9nhxoZbG: continue
			elif len(items)<2:
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]:
					url = U3Kb7B2Nd5VO1agDkxMsn9C4(url)
					HAsKeZdTbqjPI1WY(url)
				else: F4ehkvPDxXU(YLKFRH6sSIrznXBg,'SPECIFIED_FILTER___'+HfvJenZmN3O8rPcshLux2EyzDWpQCb)
				return
			else:
				YLKFRH6sSIrznXBg = U3Kb7B2Nd5VO1agDkxMsn9C4(YLKFRH6sSIrznXBg)
				if jLA9nhxoZbG==ffJIco45MG9kFntgWDwqyR[-1]: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,421,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',YLKFRH6sSIrznXBg,425,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		elif type=='ALL_ITEMS_FILTER':
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'=0'
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'=0'
			HfvJenZmN3O8rPcshLux2EyzDWpQCb = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع :'+name,YLKFRH6sSIrznXBg,424,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,HfvJenZmN3O8rPcshLux2EyzDWpQCb)
		dict[jLA9nhxoZbG] = {}
		for value,srR9AuG6Pf8powqU4ixL5Ecl in items:
			if value=='196533': srR9AuG6Pf8powqU4ixL5Ecl = 'أفلام نيتفلكس'
			elif value=='196531': srR9AuG6Pf8powqU4ixL5Ecl = 'مسلسلات نيتفلكس'
			if srR9AuG6Pf8powqU4ixL5Ecl in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			dict[jLA9nhxoZbG][value] = srR9AuG6Pf8powqU4ixL5Ecl
			z7VI1OaUPqs4lXxb = NnQ1hEsTV7Zaz3HKdfu+'&'+jLA9nhxoZbG+'='+srR9AuG6Pf8powqU4ixL5Ecl
			ybEUMsLp4zBVPnuAYI0cCdowekDq = QlOXcH07nRVPAZub8pD356xMvdk4+'&'+jLA9nhxoZbG+'='+value
			QdzUcX2iR5 = z7VI1OaUPqs4lXxb+'___'+ybEUMsLp4zBVPnuAYI0cCdowekDq
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'#+dict[jLA9nhxoZbG]['0']
			title = srR9AuG6Pf8powqU4ixL5Ecl+' :'+name
			if type=='ALL_ITEMS_FILTER': OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,424,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
			elif type=='SPECIFIED_FILTER' and ffJIco45MG9kFntgWDwqyR[-2]+'=' in NnQ1hEsTV7Zaz3HKdfu:
				F231lsuCKnaSMdQ48W6PoL = nKT1QuLoXPc8CjyV(ybEUMsLp4zBVPnuAYI0cCdowekDq,'modified_filters')
				MYWwFs7XA2 = url+'/smartemadfilter?'+F231lsuCKnaSMdQ48W6PoL
				MYWwFs7XA2 = U3Kb7B2Nd5VO1agDkxMsn9C4(MYWwFs7XA2)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,MYWwFs7XA2,421,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'filter')
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,425,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,QdzUcX2iR5)
	return
def nKT1QuLoXPc8CjyV(p9UP6wGlC1BF7fN2,mode):
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.replace('=&','=0&')
	p9UP6wGlC1BF7fN2 = p9UP6wGlC1BF7fN2.strip('&')
	vpLWbVm35iM0l2TzYIN7 = {}
	if '=' in p9UP6wGlC1BF7fN2:
		items = p9UP6wGlC1BF7fN2.split('&')
		for j25T6eKhaMk3 in items:
			XJRx6urSNaOM5AfZdDsgQBYGt,value = j25T6eKhaMk3.split('=')
			vpLWbVm35iM0l2TzYIN7[XJRx6urSNaOM5AfZdDsgQBYGt] = value
	MKJaIb2sDSr4VCQGTqyX3nkWL = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for key in nohzWuNjPvp0MA:
		if key in list(vpLWbVm35iM0l2TzYIN7.keys()): value = vpLWbVm35iM0l2TzYIN7[key]
		else: value = '0'
		if '%' not in value: value = DVX5GWhnIxYlSd9rEuetjk40UJ(value)
		if mode=='modified_values' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+' + '+value
		elif mode=='modified_filters' and value!='0': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
		elif mode=='all': MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL+'&'+key+'='+value
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip(' + ')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.strip('&')
	MKJaIb2sDSr4VCQGTqyX3nkWL = MKJaIb2sDSr4VCQGTqyX3nkWL.replace('=0','=')
	return MKJaIb2sDSr4VCQGTqyX3nkWL
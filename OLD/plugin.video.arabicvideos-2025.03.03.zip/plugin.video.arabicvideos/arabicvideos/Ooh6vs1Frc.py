# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'FUNONTV'
K2l9rLfvoXxyZ4NYapO = '_FNT_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['الصفحة الرئيسية','Sign in','تسجيل','افلام للكبار فقط']
headers = {'Referer':BOI3t1w8qfHAb0Kl4oMye7haEWS}
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==1070: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==1071: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==1072: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==1073: OmsWt89dSA5HyCZ4wL = bv4IDSyw6zuC3pR1lYd75(url,text)
	elif mode==1074: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==1079: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FUNONTV-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,1079,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('''["']navslide-wrap["'](.*?)</ul>''',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1074)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('/category.php">(.*?)"navslide-divider"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('''["']dropdown-menu["'](.*?)</ul>''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for OOCx0SzAcisQIJGM6DZkopvB3 in z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace(OOCx0SzAcisQIJGM6DZkopvB3,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if not title: continue
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		if title=='جديد الأفلام': title = 'المضاف حديثا'
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1074)
	return
def vloIZHenE7imycDM2tPQ(url):
	EYm3kBo9Lyfh10S,w7gedkFbJvcqu0fzW43NpyUP = [],[]
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FUNONTV-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"caret"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G and '.php' in str(y4IYUHTpSs8DXEfajQLvWb0g1G):
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('"presentation"','</ul>')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = [(fy8iFgEkrO12NR9TWBI35sjY6qHvV,wlJ6d8hEvpoMNSCmU)]
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' فرز أو فلتر أو ترتيب '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		for YuhpOMqmK35QwARXj6do,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			EYm3kBo9Lyfh10S = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if YuhpOMqmK35QwARXj6do: YuhpOMqmK35QwARXj6do = YuhpOMqmK35QwARXj6do+': '
			for bigdh7fpZYl4aT2keV,title in EYm3kBo9Lyfh10S:
				title = YuhpOMqmK35QwARXj6do+title
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1071)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"list-inline"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if 1 or len(w7gedkFbJvcqu0fzW43NpyUP)<30:
			if EYm3kBo9Lyfh10S: OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			for bigdh7fpZYl4aT2keV,title in w7gedkFbJvcqu0fzW43NpyUP:
				if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1071,'','','series')
	if not y4IYUHTpSs8DXEfajQLvWb0g1G and not UgbWFLzrCA5RMo7tjwNmdyc68khBGn: HAsKeZdTbqjPI1WY(url)
	return
def HAsKeZdTbqjPI1WY(url,Bc7G3ur2Tw5QK1fPSkyJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if Bc7G3ur2Tw5QK1fPSkyJ=='ajax-search':
		url,search = url.split('?',1)
		data = 'queryString='+search
		naBFTDfp6lmKjeOywg87IAcb = headers.copy()
		naBFTDfp6lmKjeOywg87IAcb['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',url,data,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FUNONTV-TITLES-1st')
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FUNONTV-TITLES-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	wlJ6d8hEvpoMNSCmU,items = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	if Bc7G3ur2Tw5QK1fPSkyJ=='ajax-search':
		wlJ6d8hEvpoMNSCmU = FGRX4myP68S
		w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in w7gedkFbJvcqu0fzW43NpyUP: items.append((fy8iFgEkrO12NR9TWBI35sjY6qHvV,bigdh7fpZYl4aT2keV,title))
	elif Bc7G3ur2Tw5QK1fPSkyJ=='featured':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pm-carousel_featured"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif Bc7G3ur2Tw5QK1fPSkyJ=='new_episodes':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"row pm-ul-browse-videos(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	elif Bc7G3ur2Tw5QK1fPSkyJ=='new_movies':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"row pm-ul-browse-videos(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if len(z6PX2p7diaskQElBOvMRNcHwqG5D)>1: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[1]
	elif Bc7G3ur2Tw5QK1fPSkyJ=='featured_series':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"home-series-list"(.*?)</div>[\t|\n]*</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pm-grid"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if wlJ6d8hEvpoMNSCmU and not items: items = EcQxOa3RJm86WjTKA.findall('''"thumbnail".*?<a href=["'](.*?)["'].*?title=["'](.*?)["'].*?data-echo=["'](.*?)["']''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if not items: return
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
		POjaBmHqzpsx1IYw7kQM4R += '|Referer='+BOI3t1w8qfHAb0Kl4oMye7haEWS
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة).\d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1072,POjaBmHqzpsx1IYw7kQM4R)
		elif Bc7G3ur2Tw5QK1fPSkyJ in ['new_episodes','series']:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1072,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1073,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1073,POjaBmHqzpsx1IYw7kQM4R)
	if 1:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if bigdh7fpZYl4aT2keV=='#': continue
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,1071)
	return
def bv4IDSyw6zuC3pR1lYd75(url,LLMYeXiaVDT9HAnUz87FOv):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FUNONTV-EPISODES-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"SeasonsBox"(.*?)"SeasonsEpisodesMain',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	mmEsSwOKazXLV1MT = EcQxOa3RJm86WjTKA.findall('"image" content="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	POjaBmHqzpsx1IYw7kQM4R = mmEsSwOKazXLV1MT[0] if mmEsSwOKazXLV1MT else fy8iFgEkrO12NR9TWBI35sjY6qHvV
	POjaBmHqzpsx1IYw7kQM4R += '|Referer='+BOI3t1w8qfHAb0Kl4oMye7haEWS
	items = []
	LNrR4g0f1KPVGsU76QqE = False
	if y4IYUHTpSs8DXEfajQLvWb0g1G and not LLMYeXiaVDT9HAnUz87FOv:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('''onclick=".*?openCity\(event, '(.*?)'\)".*?>(.*?)</button>''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for LLMYeXiaVDT9HAnUz87FOv,title in items:
			LLMYeXiaVDT9HAnUz87FOv = LLMYeXiaVDT9HAnUz87FOv.strip('#')
			if len(items)>1: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,1073,POjaBmHqzpsx1IYw7kQM4R,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLMYeXiaVDT9HAnUz87FOv)
			else: LNrR4g0f1KPVGsU76QqE = True
	else: LNrR4g0f1KPVGsU76QqE = True
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('id="'+LLMYeXiaVDT9HAnUz87FOv+'"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('SeasonsEpisodesMain(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
			wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('./')
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1072,POjaBmHqzpsx1IYw7kQM4R)
	elif UgbWFLzrCA5RMo7tjwNmdyc68khBGn and LNrR4g0f1KPVGsU76QqE:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		w7gedkFbJvcqu0fzW43NpyUP = EcQxOa3RJm86WjTKA.findall('''title=['"](.*?)['"].*?href=["'](.*?)["'].*?''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if w7gedkFbJvcqu0fzW43NpyUP:
			mTv2jaJRnUAXMh9bBc3dPEuy,K8tVL49PNmDUS1 = zip(*w7gedkFbJvcqu0fzW43NpyUP)
			WLHQjObyotUCZVe05 = [POjaBmHqzpsx1IYw7kQM4R]*len(w7gedkFbJvcqu0fzW43NpyUP)
			items = zip(K8tVL49PNmDUS1,mTv2jaJRnUAXMh9bBc3dPEuy,WLHQjObyotUCZVe05)
		if not items: items = EcQxOa3RJm86WjTKA.findall('"thumbnail".*?href="(.*?)" title="(.*?)".*?src="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
			POjaBmHqzpsx1IYw7kQM4R += '|Referer='+BOI3t1w8qfHAb0Kl4oMye7haEWS
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
			title = title.replace('</em><span>',ksJdoFWhxTz8Y2N7bOZE)
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,1072,POjaBmHqzpsx1IYw7kQM4R)
	return
def rr7SfotkneX85Klup(url):
	hFzEyHWOoRxG,CXTL7NPUAE = [],[]
	FGRX4myP68S = ''
	if 'post=' in FGRX4myP68S:
		bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('id="player".*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
		JA3FuzlcgjrGP = bigdh7fpZYl4aT2keV.split('post=')[1]
		JA3FuzlcgjrGP = JNfHYgOdP9aR.b64decode(JA3FuzlcgjrGP)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: JA3FuzlcgjrGP = JA3FuzlcgjrGP.decode(Tk9eH2qw6Brsuhj)
		JA3FuzlcgjrGP = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',JA3FuzlcgjrGP)
		zzECVswWcGAIXhrQlZ7jMokugnv = JA3FuzlcgjrGP['servers']
		p7Gkego0m6a8 = list(zzECVswWcGAIXhrQlZ7jMokugnv.keys())
		zzECVswWcGAIXhrQlZ7jMokugnv = list(zzECVswWcGAIXhrQlZ7jMokugnv.values())
		fCv8TGZdqry = zip(p7Gkego0m6a8,zzECVswWcGAIXhrQlZ7jMokugnv)
		for title,bigdh7fpZYl4aT2keV in fCv8TGZdqry:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
			hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	else:
		YLKFRH6sSIrznXBg = url.replace('watch.php','view.php')
		YLKFRH6sSIrznXBg,aiuh0XlPswEK = YLKFRH6sSIrznXBg.split('?vid=')
		gWBLDSlZGwqxHT = 'ur='+aiuh0XlPswEK+'&action=0&submit=submit'
		naBFTDfp6lmKjeOywg87IAcb = {'Content-Type':'application/x-www-form-urlencoded'}
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'POST',YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'FUNONTV-PLAY2-1st')
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		if 0:
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"embedURL" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if bigdh7fpZYl4aT2keV:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
				if bigdh7fpZYl4aT2keV not in CXTL7NPUAE:
					CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
					A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
					bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__embed'
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
		if 1:
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"embeding"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			if z6PX2p7diaskQElBOvMRNcHwqG5D:
				wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
				items = EcQxOa3RJm86WjTKA.findall('data-embed="(.*?)".*?</span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in items:
					if bigdh7fpZYl4aT2keV in CXTL7NPUAE: continue
					CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
					bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
		if 0:
			YLKFRH6sSIrznXBg = url.replace('watch.php','downloads.php')
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,False,'FUNONTV-PLAY-2nd')
			FGRX4myP68S = E6ECvznP9m5sWFMu.content
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pm-download"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			for wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
				items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<strong>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				if not items: items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
				for bigdh7fpZYl4aT2keV,title in items:
					if bigdh7fpZYl4aT2keV in CXTL7NPUAE: continue
					CXTL7NPUAE.append(bigdh7fpZYl4aT2keV)
					A8ECQ0qwTRzPifOGW76FK35uUvhe = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
					bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__download'
					hFzEyHWOoRxG.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(hFzEyHWOoRxG,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search.php?keywords='+search
	HAsKeZdTbqjPI1WY(url,'search')
	return
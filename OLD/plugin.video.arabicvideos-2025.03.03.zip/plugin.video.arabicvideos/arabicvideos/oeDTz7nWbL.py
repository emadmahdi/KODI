# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'SHAHIDNEWS'
K2l9rLfvoXxyZ4NYapO = '_SHN_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['قنوات فضائية','فارسكو','Show more']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==580: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==581: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==582: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==583: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url,text)
	elif mode==584: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==589: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHIDNEWS-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,589,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('/category.php">(.*?)"navslide-divider"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall("'dropdown-menu'(.*?)</ul>",FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	for OOCx0SzAcisQIJGM6DZkopvB3 in z6PX2p7diaskQElBOvMRNcHwqG5D: wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace(OOCx0SzAcisQIJGM6DZkopvB3,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
		OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,584)
	return
def vloIZHenE7imycDM2tPQ(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHIDNEWS-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('"caret"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if y4IYUHTpSs8DXEfajQLvWb0g1G:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		wlJ6d8hEvpoMNSCmU = wlJ6d8hEvpoMNSCmU.replace('"presentation"','</ul>')
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"dropdown-header">(.*?)</li>(.*?)</ul>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = [(fy8iFgEkrO12NR9TWBI35sjY6qHvV,wlJ6d8hEvpoMNSCmU)]
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' فرز أو فلتر أو ترتيب '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		for YuhpOMqmK35QwARXj6do,wlJ6d8hEvpoMNSCmU in z6PX2p7diaskQElBOvMRNcHwqG5D:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			if YuhpOMqmK35QwARXj6do: YuhpOMqmK35QwARXj6do = YuhpOMqmK35QwARXj6do+': '
			for bigdh7fpZYl4aT2keV,title in items:
				title = YuhpOMqmK35QwARXj6do+title
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,581)
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('"pm-category-subcats"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if len(items)<30:
			OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
			for bigdh7fpZYl4aT2keV,title in items:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,581)
	if not y4IYUHTpSs8DXEfajQLvWb0g1G and not UgbWFLzrCA5RMo7tjwNmdyc68khBGn: HAsKeZdTbqjPI1WY(url)
	return
def HAsKeZdTbqjPI1WY(url,Bc7G3ur2Tw5QK1fPSkyJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHIDNEWS-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	items = []
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('(data-echo=".*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"BlocksList"(.*?)"titleSectionCon"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="pm-grid"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('id="pm-related"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if not z6PX2p7diaskQElBOvMRNcHwqG5D: return
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	if not items: items = EcQxOa3RJm86WjTKA.findall('data-echo="(.*?)".*?href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	if not items: items = EcQxOa3RJm86WjTKA.findall('src="(.*?)".*?href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
	mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم','مسرحية']
	for POjaBmHqzpsx1IYw7kQM4R,bigdh7fpZYl4aT2keV,title in items:
		bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV).strip('/')
		if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
		if 'http' not in POjaBmHqzpsx1IYw7kQM4R: POjaBmHqzpsx1IYw7kQM4R = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+POjaBmHqzpsx1IYw7kQM4R.strip('/')
		RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
		if any(value in title for value in mmO39lwp0LFUrVT):
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,582,POjaBmHqzpsx1IYw7kQM4R)
		elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'الحلقة' in title:
			title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
			if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,583,POjaBmHqzpsx1IYw7kQM4R)
				cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
		elif '/movseries/' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,581,POjaBmHqzpsx1IYw7kQM4R)
		else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,583,POjaBmHqzpsx1IYw7kQM4R)
	if Bc7G3ur2Tw5QK1fPSkyJ not in ['featured_movies','featured_series']:
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if bigdh7fpZYl4aT2keV=='#': continue
				bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,581)
		jFlCHGZzvXw5E = EcQxOa3RJm86WjTKA.findall('showmore" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if jFlCHGZzvXw5E:
			bigdh7fpZYl4aT2keV = jFlCHGZzvXw5E[0]
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مشاهدة المزيد',bigdh7fpZYl4aT2keV,581)
	return
def eQgbVPaIBvTn8fsjJRt241(url,LLMYeXiaVDT9HAnUz87FOv):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHIDNEWS-EPISODES-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	y4IYUHTpSs8DXEfajQLvWb0g1G = EcQxOa3RJm86WjTKA.findall('nav-seasons"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	items = []
	LNrR4g0f1KPVGsU76QqE = False
	if y4IYUHTpSs8DXEfajQLvWb0g1G and not LLMYeXiaVDT9HAnUz87FOv:
		wlJ6d8hEvpoMNSCmU = y4IYUHTpSs8DXEfajQLvWb0g1G[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for LLMYeXiaVDT9HAnUz87FOv,title in items:
			LLMYeXiaVDT9HAnUz87FOv = LLMYeXiaVDT9HAnUz87FOv.strip('#')
			if len(items)>1: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,583,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,LLMYeXiaVDT9HAnUz87FOv)
			else: LNrR4g0f1KPVGsU76QqE = True
	else: LNrR4g0f1KPVGsU76QqE = True
	UgbWFLzrCA5RMo7tjwNmdyc68khBGn = EcQxOa3RJm86WjTKA.findall('id="'+LLMYeXiaVDT9HAnUz87FOv+'"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if UgbWFLzrCA5RMo7tjwNmdyc68khBGn and LNrR4g0f1KPVGsU76QqE:
		wlJ6d8hEvpoMNSCmU = UgbWFLzrCA5RMo7tjwNmdyc68khBGn[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?">(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for bigdh7fpZYl4aT2keV,title in items:
				bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,582)
		else:
			items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?title="(.*?)".*?image:url\((.*?)\)',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title,POjaBmHqzpsx1IYw7kQM4R in items:
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ+'/'+bigdh7fpZYl4aT2keV.strip('/')
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,582)
	return
def rr7SfotkneX85Klup(url):
	VlOnK9LaZ5iGWURthuC0gBIQT3SfvJ = VbHeOuU1ilzSp2ZRXwBD(url,'url')
	XoSyx7p6dqZ1CF8 = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHIDNEWS-PLAY-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('"Playerholder".*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
	if bigdh7fpZYl4aT2keV and 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
	WOLdCoumeN0h8w3EFVtkzilI2 = bigdh7fpZYl4aT2keV.split('hash=')[1]
	V5VDwKLAYM3 = WOLdCoumeN0h8w3EFVtkzilI2.split('__')
	dysn67D1UGz4OJVPNQaS9Lu,zzECVswWcGAIXhrQlZ7jMokugnv,title = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for E5Ewm9VTIQ6Yp2fvCdAgkFRe in V5VDwKLAYM3:
		TCEXrBSJqA4 = ((4-len(E5Ewm9VTIQ6Yp2fvCdAgkFRe)%4)%4)*'='
		try:
			E5Ewm9VTIQ6Yp2fvCdAgkFRe = JNfHYgOdP9aR.b64decode(E5Ewm9VTIQ6Yp2fvCdAgkFRe+TCEXrBSJqA4)
			if jTDWgftK7NEmx0JAkOn2aRIvweq: E5Ewm9VTIQ6Yp2fvCdAgkFRe = E5Ewm9VTIQ6Yp2fvCdAgkFRe.decode(Tk9eH2qw6Brsuhj)
		except: pass
		dysn67D1UGz4OJVPNQaS9Lu += E5Ewm9VTIQ6Yp2fvCdAgkFRe
	dysn67D1UGz4OJVPNQaS9Lu = dysn67D1UGz4OJVPNQaS9Lu.replace(' = ',' => ')
	kLWeOGRzKmTHf07Vs = dysn67D1UGz4OJVPNQaS9Lu.splitlines()
	for bigdh7fpZYl4aT2keV in kLWeOGRzKmTHf07Vs:
		if '://' in bigdh7fpZYl4aT2keV: zzECVswWcGAIXhrQlZ7jMokugnv.append(bigdh7fpZYl4aT2keV)
	for bigdh7fpZYl4aT2keV in zzECVswWcGAIXhrQlZ7jMokugnv:
		if ' => ' in bigdh7fpZYl4aT2keV: title,bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split(' => ')
		elif 'http' in bigdh7fpZYl4aT2keV:
			title,bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('http')
			bigdh7fpZYl4aT2keV = 'http'+bigdh7fpZYl4aT2keV
		else: continue
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.strip(' ')
		if not title: title = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
		if len(zzECVswWcGAIXhrQlZ7jMokugnv)>BkM54Kr7Qbqn:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+title+'__watch'
			XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
		else:
			E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',bigdh7fpZYl4aT2keV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'SHAHIDNEWS-PLAY-2nd')
			FGRX4myP68S = E6ECvznP9m5sWFMu.content
			z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('aplr-icon-share(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			UUr86Suzdfl13PxiTweEMZyCjHcs7p = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?button">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for R9b8gUvoB4wOfkTIjlEsZrM5LtinpS,D4DQ6k0oS39GKbZrthnsTB in UUr86Suzdfl13PxiTweEMZyCjHcs7p:
				R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = R9b8gUvoB4wOfkTIjlEsZrM5LtinpS+'?named='+D4DQ6k0oS39GKbZrthnsTB+'__watch'
				XoSyx7p6dqZ1CF8.append(R9b8gUvoB4wOfkTIjlEsZrM5LtinpS)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search.php?keywords='+search
	HAsKeZdTbqjPI1WY(url)
	return
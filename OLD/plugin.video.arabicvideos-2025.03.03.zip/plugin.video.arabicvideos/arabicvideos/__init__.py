# -*- coding: utf-8 -*-
import sys as CfgZ0zWP5XBpoGQwLUY
D5DpyO2wPg7oL = CfgZ0zWP5XBpoGQwLUY.version_info [0] == 2
ccK5HIyfUgvOdQpWSXZtaBJ = 2048
W8WuBTGQg1Zwqy5F6xSe = 7
def zmQcCUZlPKBITW5bqx1 (rR5FPU8VhJQ):
	global Jfz4wMWSZb0BYV
	EEr5teuZbc = ord (rR5FPU8VhJQ [-1])
	ZZd5W9FVUhzu31NQyComxv = rR5FPU8VhJQ [:-1]
	sJYFyd6mZHev1IXEaMj0b = EEr5teuZbc % len (ZZd5W9FVUhzu31NQyComxv)
	qPJ7pUnt5rcm6NMaFYLSkHsGxI = ZZd5W9FVUhzu31NQyComxv [:sJYFyd6mZHev1IXEaMj0b] + ZZd5W9FVUhzu31NQyComxv [sJYFyd6mZHev1IXEaMj0b:]
	if D5DpyO2wPg7oL:
		Vv1b9fdEckNepm7 = unicode () .join ([unichr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	else:
		Vv1b9fdEckNepm7 = str () .join ([chr (ord (QdqoKlFn4yZUOJp1xYrNTaBSmt69hc) - ccK5HIyfUgvOdQpWSXZtaBJ - (hrazDC5q4oB + EEr5teuZbc) % W8WuBTGQg1Zwqy5F6xSe) for hrazDC5q4oB, QdqoKlFn4yZUOJp1xYrNTaBSmt69hc in enumerate (qPJ7pUnt5rcm6NMaFYLSkHsGxI)])
	return eval (Vv1b9fdEckNepm7)
V3z5t4JAqyXk2fLsW1juoZ0BEp6,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,wdftVMyzF17cYETHu=zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1,zmQcCUZlPKBITW5bqx1
Hr25gta6XcqO,FmYoGejTnwKME7d9zPc,Dco0w1e5VM3YP7hLXTHBS8GtaCrO9=wdftVMyzF17cYETHu,C4Z5l2WILvaMHjpEoGAKP3RbNk08ye,V3z5t4JAqyXk2fLsW1juoZ0BEp6
KfHAW8VGbrxi,aOQTKXFL54Nl60Zhp3MbE,jL5CrsRwebpyDVXUc1EQP=Dco0w1e5VM3YP7hLXTHBS8GtaCrO9,FmYoGejTnwKME7d9zPc,Hr25gta6XcqO
oRJAfwD957WkUyBM1Ehu8m,vU6DxuzPwMpg,I18uSKaWhgTBeYUPD4sr=jL5CrsRwebpyDVXUc1EQP,aOQTKXFL54Nl60Zhp3MbE,KfHAW8VGbrxi
o1INZ3ViQqS0Uw5z6kMjbv,s5WMHyQN4mpie,N6NGJ4vpmidqMCh7yo=I18uSKaWhgTBeYUPD4sr,vU6DxuzPwMpg,oRJAfwD957WkUyBM1Ehu8m
Gcw2nelTR864XCVruO3mAFqI5a,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,OO9YiAQHGrLo0qpW2M3jDeXd1kx=N6NGJ4vpmidqMCh7yo,s5WMHyQN4mpie,o1INZ3ViQqS0Uw5z6kMjbv
O3OVuapf0YFjbm5oUQDg,sJw9QWiq1Kr0xfeVRI,SnhLjmfeJC=OO9YiAQHGrLo0qpW2M3jDeXd1kx,wwJvW0Fcma5fIqKSrGNkpHMoLhCT7,Gcw2nelTR864XCVruO3mAFqI5a
QjAINyUC7MDRq5d8e4vl9,AAbvaXV2DQzfNHdm4U3tT,ggjO5CrKVRPITaesWkxD=SnhLjmfeJC,sJw9QWiq1Kr0xfeVRI,O3OVuapf0YFjbm5oUQDg
FgXzMs0YSDt,uulNDCPyef78,EQxFuqjw95WvaMm8Hnlt47XVihJ=ggjO5CrKVRPITaesWkxD,AAbvaXV2DQzfNHdm4U3tT,QjAINyUC7MDRq5d8e4vl9
ssynAg0zhSkoCpOMDV9,sIzDXlTHYUC5L3xZGnr,PlpyFa9QMKXxOD1cvHzmI=EQxFuqjw95WvaMm8Hnlt47XVihJ,uulNDCPyef78,FgXzMs0YSDt
CsDcLqQUVK4YBvHFW1,EE1jeHnIoad,LYIgTBeSmZWotDh4bnyQkvM50siu=PlpyFa9QMKXxOD1cvHzmI,sIzDXlTHYUC5L3xZGnr,ssynAg0zhSkoCpOMDV9
from PuEbpwSj7y import *
BfWYUAnyg6eONLjiuE = jL5CrsRwebpyDVXUc1EQP(u"ࠩࡌࡒࡎ࡚ࠧᅘ")
FXqs58aHYW = wdftVMyzF17cYETHu(u"ࠪࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠣࡁࡂࡃ࠽࠾ࠢࡀࡁࡂࡃ࠽ࠡ࠿ࡀࡁࡂࡃࠠ࠾࠿ࡀࡁࡂࠦ࠽࠾࠿ࡀࡁࠥࡃ࠽࠾࠿ࡀࠤࡂࡃ࠽࠾࠿ࠪᅙ")
ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = OBw7zQog2DrJlPRZ(LVXc6WJ3eAoz5hgnyrut1)
XsDQkAWCEMaxHV28w1iO = int(mmocwN1frQJ5ST3xa)
ffWgMXo20Hb5xurkdNqa = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel(sJw9QWiq1Kr0xfeVRI(u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠬᅚ"))
ffWgMXo20Hb5xurkdNqa = ffWgMXo20Hb5xurkdNqa.replace(fROdS5FWnqVN3aurX9bZx,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(ghA8DEI1uiecHS6,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
if XsDQkAWCEMaxHV28w1iO==CsDcLqQUVK4YBvHFW1(u"࠲࠷࠲ᆀ"): WCTwu5QtgSNf = sJw9QWiq1Kr0xfeVRI(u"ࠬࠦࠠࠡࡘࡨࡶࡸ࡯࡯࡯࠼ࠣ࡟ࠥ࠭ᅛ")+KoxvjArhL1TdInDmN9s+sJw9QWiq1Kr0xfeVRI(u"࠭ࠠ࡞ࠢࠣࠤࡐࡵࡤࡪ࠼ࠣ࡟ࠥ࠭ᅜ")+dxpe1RLMQHSazAFU+oRJAfwD957WkUyBM1Ehu8m(u"ࠧࠡ࡟ࠪᅝ")
else:
	xwcW8vAEUYh = U2Z7CVFftTmLeK3nzEbQPGga(LVXc6WJ3eAoz5hgnyrut1).replace(n0nFOd4yR97fQzNLSW,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(WydpaVx5YmLoCiIgA34eEBlb,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	xwcW8vAEUYh = xwcW8vAEUYh.replace(T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV).strip(ksJdoFWhxTz8Y2N7bOZE)
	xwcW8vAEUYh = xwcW8vAEUYh.replace(zz5wETpjWKMNb6JiLRndGhV9,ksJdoFWhxTz8Y2N7bOZE).replace(yU7COAbsNJ916v5L0oew2n,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE)
	WCTwu5QtgSNf = ssynAg0zhSkoCpOMDV9(u"ࠨࠢࠣࠤࡑࡧࡢࡦ࡮࠽ࠤࡠࠦࠧᅞ")+ffWgMXo20Hb5xurkdNqa+oRJAfwD957WkUyBM1Ehu8m(u"ࠩࠣࡡࠥࠦࠠࡎࡱࡧࡩ࠿࡛ࠦࠡࠩᅟ")+mmocwN1frQJ5ST3xa+N6NGJ4vpmidqMCh7yo(u"ࠪࠤࡢࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪᅠ")+xwcW8vAEUYh+QjAINyUC7MDRq5d8e4vl9(u"ࠫࠥࡣࠧᅡ")
Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,FXqs58aHYW+C0qrknitpM4Z+BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+WCTwu5QtgSNf)
if C4Z5l2WILvaMHjpEoGAKP3RbNk08ye(u"ࠬࡥࠧᅢ") in vBs70HtgMbzd6n3NwUpxe: YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY = vBs70HtgMbzd6n3NwUpxe.split(s5WMHyQN4mpie(u"࠭࡟ࠨᅣ"),BkM54Kr7Qbqn)
else: YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY = vBs70HtgMbzd6n3NwUpxe,fy8iFgEkrO12NR9TWBI35sjY6qHvV
I4t9qonjrm.g503yRKdMjBLnGw2E4SuOvVH9t,Okwr0yDIL1oVF9AlWRbduUtnzp = LhFAGlQ19zr,fy8iFgEkrO12NR9TWBI35sjY6qHvV
if YadnQGoc0KNA8tiyrBx5ebCf2wPLM in [ssynAg0zhSkoCpOMDV9(u"ࠧ࠲ࠩᅤ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠨ࠴ࠪᅥ"),LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠩ࠶ࠫᅦ"),uulNDCPyef78(u"ࠪ࠸ࠬᅧ"),aOQTKXFL54Nl60Zhp3MbE(u"ࠫ࠺࠭ᅨ"),PlpyFa9QMKXxOD1cvHzmI(u"ࠬ࠷࠱ࠨᅩ"),sJw9QWiq1Kr0xfeVRI(u"࠭࠱࠳ࠩᅪ"),EE1jeHnIoad(u"ࠧ࠲࠵ࠪᅫ")] and (Dco0w1e5VM3YP7hLXTHBS8GtaCrO9(u"ࠨࡃࡇࡈࠬᅬ") in bfGhu9m4HyY or FgXzMs0YSDt(u"ࠩࡕࡉࡒࡕࡖࡆࠩᅭ") in bfGhu9m4HyY or CsDcLqQUVK4YBvHFW1(u"࡙ࠪࡕ࠭ᅮ") in bfGhu9m4HyY or wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠫࡉࡕࡗࡏࠩᅯ") in bfGhu9m4HyY):
	from kxdqilYRPe import UUV61NDj9xlkwbHqiYJzZ7BAWO
	UUV61NDj9xlkwbHqiYJzZ7BAWO(vBs70HtgMbzd6n3NwUpxe,YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY)
	OdiZIyCfDUsW3JBGR2VAb.setSetting(CsDcLqQUVK4YBvHFW1(u"ࠬࡧࡶ࠯ࡵࡷࡥࡹࡻࡳ࠯ࡴࡨࡪࡷ࡫ࡳࡩࠩᅰ"),LVXc6WJ3eAoz5hgnyrut1)
	I4t9qonjrm.g503yRKdMjBLnGw2E4SuOvVH9t = EsCplGc5N4mBuYW0RVQt6b
elif not VrXZUMQwAoOIg1D8Bjk4s2hfC7EGPv and XsDQkAWCEMaxHV28w1iO in [PlpyFa9QMKXxOD1cvHzmI(u"࠳࠵࠸ᆁ"),I18uSKaWhgTBeYUPD4sr(u"࠹࠴࠹ᆂ")]:
	FAVmIEYX4o3xJ8cdh = str(Q1q840Lz62ZxYGCEaRbjtuAFS7siW[jL5CrsRwebpyDVXUc1EQP(u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅱ")])
	BfWYUAnyg6eONLjiuE = N6NGJ4vpmidqMCh7yo(u"ࠧࡊࡒࡗ࡚ࠬᅲ") if XsDQkAWCEMaxHV28w1iO==sIzDXlTHYUC5L3xZGnr(u"࠵࠷࠺ᆃ") else wwJvW0Fcma5fIqKSrGNkpHMoLhCT7(u"ࠨࡏ࠶࡙ࠬᅳ")
	ckKO3tHmNWVMT = BfWYUAnyg6eONLjiuE.lower()
	ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = OdiZIyCfDUsW3JBGR2VAb.getSetting(FmYoGejTnwKME7d9zPc(u"ࠩࡤࡺ࠳࠭ᅴ")+ckKO3tHmNWVMT+EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠪ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺ࡟ࠨᅵ")+FAVmIEYX4o3xJ8cdh)
	V6gGYKEO8UqQZ = OdiZIyCfDUsW3JBGR2VAb.getSetting(N6NGJ4vpmidqMCh7yo(u"ࠫࡦࡼ࠮ࠨᅶ")+ckKO3tHmNWVMT+V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠬ࠴ࡲࡦࡨࡨࡶࡪࡸ࡟ࠨᅷ")+FAVmIEYX4o3xJ8cdh)
	if ll7qCX4wJ5kQonVW6KtcMuZGSvDEs or V6gGYKEO8UqQZ:
		zzekZcWL1sBgnoxN8f3vdQ0r += O3OVuapf0YFjbm5oUQDg(u"࠭ࡼࠨᅸ")
		if ll7qCX4wJ5kQonVW6KtcMuZGSvDEs: zzekZcWL1sBgnoxN8f3vdQ0r += V3z5t4JAqyXk2fLsW1juoZ0BEp6(u"ࠧࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᅹ")+ll7qCX4wJ5kQonVW6KtcMuZGSvDEs
		if V6gGYKEO8UqQZ: zzekZcWL1sBgnoxN8f3vdQ0r += vU6DxuzPwMpg(u"ࠨࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫᅺ")+V6gGYKEO8UqQZ
		zzekZcWL1sBgnoxN8f3vdQ0r = zzekZcWL1sBgnoxN8f3vdQ0r.replace(EQxFuqjw95WvaMm8Hnlt47XVihJ(u"ࠩࡿࠪࠬᅻ"),Gcw2nelTR864XCVruO3mAFqI5a(u"ࠪࢀࠬᅼ"))
	AD28PkbBSER4gwY = OdiZIyCfDUsW3JBGR2VAb.getSetting(LYIgTBeSmZWotDh4bnyQkvM50siu(u"ࠫࡦࡼ࠮ࠨᅽ")+ckKO3tHmNWVMT+wdftVMyzF17cYETHu(u"ࠬ࠴ࡳࡦࡴࡹࡩࡷࡥࠧᅾ")+FAVmIEYX4o3xJ8cdh)
	if AD28PkbBSER4gwY:
		aNiWFXsftZQonx1TE = EcQxOa3RJm86WjTKA.findall(sIzDXlTHYUC5L3xZGnr(u"࠭࠺࠰࠱ࠫ࠲࠯ࡅࠩ࠰ࠩᅿ"),zzekZcWL1sBgnoxN8f3vdQ0r,EcQxOa3RJm86WjTKA.DOTALL)
		zzekZcWL1sBgnoxN8f3vdQ0r = zzekZcWL1sBgnoxN8f3vdQ0r.replace(aNiWFXsftZQonx1TE[D2D96X5NGamBhrFwvL8VEbqiSfZIl],AD28PkbBSER4gwY)
	E7HR1ZcMuzUs9XCVrNGJYi(zzekZcWL1sBgnoxN8f3vdQ0r,BfWYUAnyg6eONLjiuE,ZJqDh4ByGPQn13tlzMOTLCNdcugx)
else:
	import i8zOgXMb2I
	try: i8zOgXMb2I.DWPvwMbjUs71TlHAezRtSkdNGZFu(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW,XsDQkAWCEMaxHV28w1iO,YadnQGoc0KNA8tiyrBx5ebCf2wPLM,bfGhu9m4HyY,ffWgMXo20Hb5xurkdNqa)
	except Exception as RLJCuTQqVA46r8Sx: Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
ROYhZ6jAF7435ulQBC(I4t9qonjrm.g503yRKdMjBLnGw2E4SuOvVH9t,Okwr0yDIL1oVF9AlWRbduUtnzp)
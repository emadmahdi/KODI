# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'GOOGLESEARCH'
K2l9rLfvoXxyZ4NYapO = '_GOS_'
def ugbnmWCrLpG9Av0xzocFaB5ew(hO3D6GVPY2qENv8bZWH,eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q):
	if   hO3D6GVPY2qENv8bZWH==1010: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif hO3D6GVPY2qENv8bZWH==1011: OmsWt89dSA5HyCZ4wL = UQmHfJZiDNKBrEXvc9nYesAj6(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==1012: OmsWt89dSA5HyCZ4wL = ybU7ERQfYJHa5GhFenBgcV9Skxv(eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==1013: OmsWt89dSA5HyCZ4wL = bw2ZeBlUQ3cms4FMoN()
	elif hO3D6GVPY2qENv8bZWH==1014: OmsWt89dSA5HyCZ4wL = po5jU9mbVI87QhyglLGaRfqZs0EM(eEncXMVB2rNg4JObl3utYfj,YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==1015: OmsWt89dSA5HyCZ4wL = rrw3IzNS2GxO4vhkly5DcC8X6bY(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==1016: OmsWt89dSA5HyCZ4wL = HG8xznrBmiybO429N71C(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==1018: OmsWt89dSA5HyCZ4wL = uLbRSYonqImkPNh5raA3GE(YMaiHbnIThsP7q)
	elif hO3D6GVPY2qENv8bZWH==1019: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(YMaiHbnIThsP7q,False)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder','بحث جوجل جديد',fy8iFgEkrO12NR9TWBI35sjY6qHvV,1019)
	OZD1l4pAMzeH('link','كيف يعمل بحث جوجل','',1013)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'==== كلمات البحث المخزنة ===='+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r = rIhXWK91vRuC(jUCABmLYMf0G,'dict','GLOBALSEARCH_SPLITTED_GOOGLE')
	if jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r:
		jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r = jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r['__SEQUENCED_COLUMNS__']
		for qO85TbiBND0g6G3Iktu7fomVCc in reversed(jdK6AMWnSaTyeYhfP3oJ9lBmkzL8r):
			OZD1l4pAMzeH('folder',qO85TbiBND0g6G3Iktu7fomVCc,fy8iFgEkrO12NR9TWBI35sjY6qHvV,1019,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,qO85TbiBND0g6G3Iktu7fomVCc)
	return
def uLbRSYonqImkPNh5raA3GE(search):
	dPTs3joJiGpzfcWFvQZAa(search,True)
	ejX7kGtQ4hcYUHW9b31vriuZLM6Sp(LhFAGlQ19zr)
	return
def dPTs3joJiGpzfcWFvQZAa(search,Cdaq1HcsvQTPfLZu56=False):
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	EfJc6xmorP9siHGZplU02yK7 = search.replace(K2l9rLfvoXxyZ4NYapO,fy8iFgEkrO12NR9TWBI35sjY6qHvV).lower()
	R4ai78UeEblIWvD9,eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = [],[],[]
	if not Cdaq1HcsvQTPfLZu56:
		R4ai78UeEblIWvD9 = rIhXWK91vRuC(jUCABmLYMf0G,'list','GOOGLESEARCH_RESULTS',EfJc6xmorP9siHGZplU02yK7)
		if R4ai78UeEblIWvD9: eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = R4ai78UeEblIWvD9
	if Cdaq1HcsvQTPfLZu56 or not R4ai78UeEblIWvD9:
		import msb3A1OhNH
		msb3A1OhNH.hUzb59PciOQrJIE0K1SfBN2(EfJc6xmorP9siHGZplU02yK7,'_GOOGLE',True)
		JreRndzAXwNOiL5y = qdIGA4sOXnrUPmepWR(EfJc6xmorP9siHGZplU02yK7)
		for j25T6eKhaMk3 in JreRndzAXwNOiL5y:
			name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl = j25T6eKhaMk3
			if C0C4kdG53sPAbNq8OBMpitLThHl in cFTiOCdrXfgnKx0vh948jU7pSEb: eHVUIM37dszJPwaSNrEm6nB1x.append(j25T6eKhaMk3)
			else: Yy9uUixZVIrLvCFWJEhw48c7QdD.append(j25T6eKhaMk3)
		eHVUIM37dszJPwaSNrEm6nB1x = sorted(eHVUIM37dszJPwaSNrEm6nB1x,reverse=LhFAGlQ19zr,key=lambda key: key[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
		Yy9uUixZVIrLvCFWJEhw48c7QdD = sorted(Yy9uUixZVIrLvCFWJEhw48c7QdD,reverse=LhFAGlQ19zr,key=lambda key: key[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
		tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'GOOGLESEARCH_RESULTS',EfJc6xmorP9siHGZplU02yK7,[eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD],JJtWv7V436NPCf)
		gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_DETAILED_GOOGLE',EfJc6xmorP9siHGZplU02yK7)
		msb3A1OhNH.hUzb59PciOQrJIE0K1SfBN2(EfJc6xmorP9siHGZplU02yK7,'_GOOGLE',False)
		gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'GLOBALSEARCH_DIVIDED_GOOGLE',"%, '"+EfJc6xmorP9siHGZplU02yK7+"')")
		if eHVUIM37dszJPwaSNrEm6nB1x: GOnZYxartRwkPqMJFub('','','رسالة من المبرمج','تم عمل بحث جوجل جديد وتم إيجاد\n\n'+str(len(eHVUIM37dszJPwaSNrEm6nB1x))+'  مواقع')
		else: eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = B6tOvVhAZp4JqbHjTn(EfJc6xmorP9siHGZplU02yK7,LhFAGlQ19zr)
	OZD1l4pAMzeH('link','بحث جماعي لمواقع جوجل','search_sites_google',1012,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('folder','بحث منفرد لمواقع جوجل',fy8iFgEkrO12NR9TWBI35sjY6qHvV,1011,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder','نتائج البحث مفصلة - '+EfJc6xmorP9siHGZplU02yK7,'opened_sites_google',1012,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('folder','نتائج البحث مقسمة - '+EfJc6xmorP9siHGZplU02yK7,'listed_sites_google',1012,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder','مواقع جوجل ('+str(len(eHVUIM37dszJPwaSNrEm6nB1x))+') - '+EfJc6xmorP9siHGZplU02yK7,'',1016,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,EfJc6xmorP9siHGZplU02yK7)
	OZD1l4pAMzeH('link','إعادة بحث جوجل - '+EfJc6xmorP9siHGZplU02yK7,'',1018,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,search)
	return
def HG8xznrBmiybO429N71C(EfJc6xmorP9siHGZplU02yK7):
	eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = B6tOvVhAZp4JqbHjTn(EfJc6xmorP9siHGZplU02yK7)
	if not eHVUIM37dszJPwaSNrEm6nB1x and not Yy9uUixZVIrLvCFWJEhw48c7QdD: return
	HHMVTAnXoGbr570el6Zx = {}
	for name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl in eHVUIM37dszJPwaSNrEm6nB1x: HHMVTAnXoGbr570el6Zx[C0C4kdG53sPAbNq8OBMpitLThHl] = name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl
	chLTgNepKwFlz6yMC39Z04En = list(HHMVTAnXoGbr570el6Zx.keys())
	import msb3A1OhNH
	i16TLa304fgPrcmnzHFtCA5JSQ2YW = msb3A1OhNH.wwC9IiN8t2epu3xHlaAPkVWjYzy(chLTgNepKwFlz6yMC39Z04En)
	for C0C4kdG53sPAbNq8OBMpitLThHl in i16TLa304fgPrcmnzHFtCA5JSQ2YW:
		if 'tuple' in str(type(C0C4kdG53sPAbNq8OBMpitLThHl)):
			I4t9qonjrm.menuItemsLIST.append(C0C4kdG53sPAbNq8OBMpitLThHl)
			continue
		name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl = HHMVTAnXoGbr570el6Zx[C0C4kdG53sPAbNq8OBMpitLThHl]
		i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
		OZD1l4pAMzeH('folder',rk0648WzSs7byUiKvRo5I1nBYPTMd+name,bigdh7fpZYl4aT2keV,1014,f4n3qFe57xMbu9d,'',C0C4kdG53sPAbNq8OBMpitLThHl)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+'مواقع بجوجل غير موجودة بالبرنامج'+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,1015)
	Yy9uUixZVIrLvCFWJEhw48c7QdD = sorted(Yy9uUixZVIrLvCFWJEhw48c7QdD,reverse=LhFAGlQ19zr,key=lambda key: key[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
	for name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl in Yy9uUixZVIrLvCFWJEhw48c7QdD:
		OZD1l4pAMzeH('link','_GOS_'+name,bigdh7fpZYl4aT2keV,1015,f4n3qFe57xMbu9d,'',C0C4kdG53sPAbNq8OBMpitLThHl)
	return
def B6tOvVhAZp4JqbHjTn(EfJc6xmorP9siHGZplU02yK7,cEUT5Sw9lIChs08bze6jikQNFBL=EsCplGc5N4mBuYW0RVQt6b):
	eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = [],[]
	if cEUT5Sw9lIChs08bze6jikQNFBL:
		R4ai78UeEblIWvD9 = rIhXWK91vRuC(jUCABmLYMf0G,'list','GOOGLESEARCH_RESULTS',EfJc6xmorP9siHGZplU02yK7)
		if R4ai78UeEblIWvD9: eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = R4ai78UeEblIWvD9
	if not eHVUIM37dszJPwaSNrEm6nB1x and not Yy9uUixZVIrLvCFWJEhw48c7QdD: GOnZYxartRwkPqMJFub('','','رسالة من المبرمج','للأسف جوجل لم يجد مواقع فيها طلبك')
	return eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD
def ybU7ERQfYJHa5GhFenBgcV9Skxv(HW24rguPyVTMBmicF,EfJc6xmorP9siHGZplU02yK7):
	eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = B6tOvVhAZp4JqbHjTn(EfJc6xmorP9siHGZplU02yK7)
	if not eHVUIM37dszJPwaSNrEm6nB1x and not Yy9uUixZVIrLvCFWJEhw48c7QdD: return
	WWBVxlcgz1aJ2UQCPe7suZ6RSH,LLgxIKuv39AlV = [],{}
	for name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl in eHVUIM37dszJPwaSNrEm6nB1x:
		WWBVxlcgz1aJ2UQCPe7suZ6RSH.append(C0C4kdG53sPAbNq8OBMpitLThHl)
		LLgxIKuv39AlV[C0C4kdG53sPAbNq8OBMpitLThHl] = JUdm3AWToEN4(text)
	import msb3A1OhNH
	msb3A1OhNH.a6bynuDzsFWd0ZVYvXpiJCrhN(EfJc6xmorP9siHGZplU02yK7,HW24rguPyVTMBmicF,fy8iFgEkrO12NR9TWBI35sjY6qHvV,WWBVxlcgz1aJ2UQCPe7suZ6RSH,LLgxIKuv39AlV)
	return
def UQmHfJZiDNKBrEXvc9nYesAj6(EfJc6xmorP9siHGZplU02yK7):
	eHVUIM37dszJPwaSNrEm6nB1x,Yy9uUixZVIrLvCFWJEhw48c7QdD = B6tOvVhAZp4JqbHjTn(EfJc6xmorP9siHGZplU02yK7)
	if not eHVUIM37dszJPwaSNrEm6nB1x and not Yy9uUixZVIrLvCFWJEhw48c7QdD: return
	HHMVTAnXoGbr570el6Zx = {}
	for name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl in eHVUIM37dszJPwaSNrEm6nB1x:
		HHMVTAnXoGbr570el6Zx[C0C4kdG53sPAbNq8OBMpitLThHl] = name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl
	chLTgNepKwFlz6yMC39Z04En = list(HHMVTAnXoGbr570el6Zx.keys())
	import msb3A1OhNH
	i16TLa304fgPrcmnzHFtCA5JSQ2YW = msb3A1OhNH.wwC9IiN8t2epu3xHlaAPkVWjYzy(chLTgNepKwFlz6yMC39Z04En)
	for C0C4kdG53sPAbNq8OBMpitLThHl in i16TLa304fgPrcmnzHFtCA5JSQ2YW:
		if 'tuple' in str(type(C0C4kdG53sPAbNq8OBMpitLThHl)):
			I4t9qonjrm.menuItemsLIST.append(C0C4kdG53sPAbNq8OBMpitLThHl)
			continue
		name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl = HHMVTAnXoGbr570el6Zx[C0C4kdG53sPAbNq8OBMpitLThHl]
		i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
		text = JUdm3AWToEN4(text)
		name = name+' - '+EfJc6xmorP9siHGZplU02yK7
		OZD1l4pAMzeH('folder',rk0648WzSs7byUiKvRo5I1nBYPTMd+name,C0C4kdG53sPAbNq8OBMpitLThHl,548,f4n3qFe57xMbu9d,'',text)
	return
def JUdm3AWToEN4(title):
	RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) (الحلقة|حلقة)',title,EcQxOa3RJm86WjTKA.DOTALL)
	D4DQ6k0oS39GKbZrthnsTB = RrzpbE3t9woCk7MXS0GvNdi1BcV[0][0] if RrzpbE3t9woCk7MXS0GvNdi1BcV else title
	D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.replace('مشاهدة اونلاين، فيديو، الإعلان، صور - السينما.كوم','').replace('- ‎عرب سيد - Arabseed','')
	D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.replace('- وى سيما wecima ماى سيما mycima - وي سيما','').replace('- فيديو Dailymotion','')
	D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.replace('الموسم','').replace('الموقع','').replace('- شوف نت','').replace('موسم','').replace('HD','')
	D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.replace('مشاهدة','').replace('نتائج البحث:','').replace('اونلاين','').replace('- سيما فور بي','')
	D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.replace('موقع','').replace('| اكوام','').replace('','').replace('','').replace('','').replace('','')
	D4DQ6k0oS39GKbZrthnsTB = D4DQ6k0oS39GKbZrthnsTB.strip(' ').replace('    ',' ').replace('   ',' ').replace('  ',' ').replace('  ',' ')
	return D4DQ6k0oS39GKbZrthnsTB
def qdIGA4sOXnrUPmepWR(search):
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0'}
	url = 'https://www.google.com/search?hl=en&filter=1&imgSize=small&safe=active&q=-youtube+-instagram+-facebook+-tiktok+-elcinema+'+search
	YLKFRH6sSIrznXBg = url+'&start=0&num=100&tbm=vid&udm=7'
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'GOOGLESEARCH-SEARCH-1st')
	if not E6ECvznP9m5sWFMu.succeeded: return []
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	YJUjFni2ukpERzflDHPKmI81h3x0ds = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(P8F6NtJD5ridLmglTbWpzMo4,'googlesearch')
	if not HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(YJUjFni2ukpERzflDHPKmI81h3x0ds):
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.makedirs(YJUjFni2ukpERzflDHPKmI81h3x0ds)
		except: pass
	items = []
	VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('jsname="UWckNb" href="(.*?)".*?<span.*?>(.*?).*?aria-label="(.*?)".*?src="(.*?)".*?class="cuFRh">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if VuGmoESTAfXlv5tD76PW1Masq0peB:
		for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
			bigdh7fpZYl4aT2keV,title,text,mmEsSwOKazXLV1MT,name = wlJ6d8hEvpoMNSCmU
			mmEsSwOKazXLV1MT = ''
			items.append([bigdh7fpZYl4aT2keV,title,text,name,mmEsSwOKazXLV1MT])
	else:
		YLKFRH6sSIrznXBg = url+'&start=0&num=200'
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'GET::SCRAPERS',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,headers,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'GOOGLESEARCH-SEARCH-2nd')
		if not E6ECvznP9m5sWFMu.succeeded: return []
		FGRX4myP68S = E6ECvznP9m5sWFMu.content
		VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('(\[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,".*?\]\])',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not VuGmoESTAfXlv5tD76PW1Masq0peB: VuGmoESTAfXlv5tD76PW1Masq0peB = EcQxOa3RJm86WjTKA.findall('(\[None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,".*?\]\])',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for wlJ6d8hEvpoMNSCmU in VuGmoESTAfXlv5tD76PW1Masq0peB:
			wlJ6d8hEvpoMNSCmU = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('list',wlJ6d8hEvpoMNSCmU)
			if len(wlJ6d8hEvpoMNSCmU)>17:
				bigdh7fpZYl4aT2keV = wlJ6d8hEvpoMNSCmU[17]
				title,text,name,mmEsSwOKazXLV1MT = wlJ6d8hEvpoMNSCmU[31][0:4]
				items.append([bigdh7fpZYl4aT2keV,title,text,name,mmEsSwOKazXLV1MT])
	GCJfgA4DS6QM,NYQfsgMun1AqKR54FGOxpw = [],[]
	for j25T6eKhaMk3 in items:
		bigdh7fpZYl4aT2keV,title,text,name,mmEsSwOKazXLV1MT = j25T6eKhaMk3
		name = name.strip(' ')
		if not name: name = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
		name = KaUrpGJVDF470YloiwbH69tqmXyuOT(name)
		if 'http://' in mmEsSwOKazXLV1MT or 'https://' in mmEsSwOKazXLV1MT: f4n3qFe57xMbu9d = mmEsSwOKazXLV1MT
		elif 'data:image/' in mmEsSwOKazXLV1MT and ';base64,' in mmEsSwOKazXLV1MT:
			zz12kjsep9iBa8X = EcQxOa3RJm86WjTKA.findall('data:image/(\w+);base64,',mmEsSwOKazXLV1MT)
			zz12kjsep9iBa8X = zz12kjsep9iBa8X[0]
			f4n3qFe57xMbu9d = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(YJUjFni2ukpERzflDHPKmI81h3x0ds,name+'.'+zz12kjsep9iBa8X)
			if not HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(f4n3qFe57xMbu9d):
				mmEsSwOKazXLV1MT = mmEsSwOKazXLV1MT.replace('\\u003d','=')
				mmEsSwOKazXLV1MT = mmEsSwOKazXLV1MT.replace('data:image/'+zz12kjsep9iBa8X+';base64,','')
				SLAmQc90djGyrHlJ8I = JNfHYgOdP9aR.b64decode(mmEsSwOKazXLV1MT)
				open(f4n3qFe57xMbu9d,'wb').write(SLAmQc90djGyrHlJ8I)
		else: f4n3qFe57xMbu9d = ''
		C0C4kdG53sPAbNq8OBMpitLThHl = XsCbpPaF2AnGOSQUBzmjc10IurVfM(name,bigdh7fpZYl4aT2keV)
		if C0C4kdG53sPAbNq8OBMpitLThHl not in NYQfsgMun1AqKR54FGOxpw:
			NYQfsgMun1AqKR54FGOxpw.append(C0C4kdG53sPAbNq8OBMpitLThHl)
			name = eJYnofQG4mc8aFiN(C0C4kdG53sPAbNq8OBMpitLThHl)
			GCJfgA4DS6QM.append([name,bigdh7fpZYl4aT2keV,title,text,f4n3qFe57xMbu9d,C0C4kdG53sPAbNq8OBMpitLThHl])
	return GCJfgA4DS6QM
def po5jU9mbVI87QhyglLGaRfqZs0EM(bigdh7fpZYl4aT2keV,C0C4kdG53sPAbNq8OBMpitLThHl):
	i4YeIfAFjZkScx5RXLNGd96V,DDmgX24QRqwcVnez8GyP,rk0648WzSs7byUiKvRo5I1nBYPTMd = vjM9sANcTkUJViCD4PpBza0lH(C0C4kdG53sPAbNq8OBMpitLThHl)
	if rk0648WzSs7byUiKvRo5I1nBYPTMd: i4YeIfAFjZkScx5RXLNGd96V()
	else: rrw3IzNS2GxO4vhkly5DcC8X6bY()
	return
def bw2ZeBlUQ3cms4FMoN():
	GOnZYxartRwkPqMJFub('','','رسالة من المبرمج','هذا البحث يستخدم ذكاء وشمولية وسرعة محرك بحث جوجل .. ونتائج هذا البحث هي أسماء مواقع الإنترنت التي موجودة في هذا البرنامج والتي فيها الفيديوهات المطلوبة\n\nهذا البحث يحتاج كلمات بحث عادية جدا بدون أي مراعاة لدقة الكلمات أو تفاصيل الفيديوهات أو حتى إملاء الكلمات\n\nهذا البحث يستطيع أيضا أن يفحص محتويات المواقع التي وجدها جوجل إذا كانت هذه المواقع موجودة بهذا البرنامج')
	return
def rrw3IzNS2GxO4vhkly5DcC8X6bY(C0C4kdG53sPAbNq8OBMpitLThHl=''):
	GOnZYxartRwkPqMJFub('','',C0C4kdG53sPAbNq8OBMpitLThHl,'هذا الموقع غير موجود في البرنامج .. أو أسم الموقع مختلف وغير مطابق للاسم المستخدم في البرنامج')
	return
def XsCbpPaF2AnGOSQUBzmjc10IurVfM(name,bigdh7fpZYl4aT2keV):
	T0fNB9DFe3nhV = {
	 'فشار فيديو مشاهدة افلام ومسلسلات اون لاين'	:'FUSHARVIDEO'
	,'وى سيما wecima ماى سيما mycima'			:'WECIMA1'
	,'شبكتي تي في - SHABAKATY TV'				:'SHABAKATY'
	,'اكوام  شبكة اكوام AKWAM'					:'AKWAM'
	,'سيما كلوب  CIMACLUB'						:'CIMACLUB'
	,'سيما فري CIMAFREE':'CIMAFREE'
	,'هلا سيما'			:'HALACIMA'
	,'لاروزا'			:'LAROZA'
	,'برستيج'			:'BRSTEJ'
	,'كرمالك TV'		:'KIRMALK'
	,'سيما فور بي'		:'CIMA4P'
	,'اهواك تي في'		:'AHWAK'
	,'CIMA CLUB'		:'CIMACLUB'
	,'اكوام'			:'AKWAM'
	,'وي سيما'			:'WECIMA1'
	,'سيما ناو'			:'CIMANOW'
	,'سيما لايت'			:'CIMALIGHT'
	,'موقع ماي سيما'	:'CIMALIGHT'
	,'عرب سيد'			:'ARABSEED'
	,'فيديو ياقوت'		:'YAQOT'
	,'المصطبة TV'		:'ALMSTBA'
	,'دراما كافيه'		:'DRAMACAFE'
	,'سيما 400'			:'CIMA400'
	,'فيديو تكات'		:'TIKAAT'
	,'السينما.كوم'		:'ELCINEMA'
	,'فوستا'			:'FOSTA'
	,'سيما عبدو'		:'CIMAABDO'
	,'فاصل إعلاني'		:'FASELHD1'
	,'مسلسلات تايم'		:'SERIESTIME'
	,'شوف نت'			:'SHOOFNET'
	}
	z6FysMQJTa2IWYdrDx7BjObwN3fE = name.lower()
	s9qgDT8oclCrdXK6EUO = ''
	for key in list(T0fNB9DFe3nhV.keys()):
		if key.lower() in z6FysMQJTa2IWYdrDx7BjObwN3fE: s9qgDT8oclCrdXK6EUO = T0fNB9DFe3nhV[key]
	if not s9qgDT8oclCrdXK6EUO:
		R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'url')
		for C0C4kdG53sPAbNq8OBMpitLThHl in list(I4t9qonjrm.SITESURLS.keys()):
			WW1zbyCXmnLRQot3JEvkF = VbHeOuU1ilzSp2ZRXwBD(I4t9qonjrm.SITESURLS[C0C4kdG53sPAbNq8OBMpitLThHl][0],'url')
			if R9b8gUvoB4wOfkTIjlEsZrM5LtinpS==WW1zbyCXmnLRQot3JEvkF: s9qgDT8oclCrdXK6EUO = C0C4kdG53sPAbNq8OBMpitLThHl
	if not s9qgDT8oclCrdXK6EUO:
		z6FysMQJTa2IWYdrDx7BjObwN3fE = VbHeOuU1ilzSp2ZRXwBD(bigdh7fpZYl4aT2keV,'name')
		for C0C4kdG53sPAbNq8OBMpitLThHl in list(I4t9qonjrm.SITESURLS.keys()):
			dkn5TQhEapj91JfCziZ7Aby = VbHeOuU1ilzSp2ZRXwBD(I4t9qonjrm.SITESURLS[C0C4kdG53sPAbNq8OBMpitLThHl][0],'name')
			if z6FysMQJTa2IWYdrDx7BjObwN3fE==dkn5TQhEapj91JfCziZ7Aby: s9qgDT8oclCrdXK6EUO = C0C4kdG53sPAbNq8OBMpitLThHl
	if not s9qgDT8oclCrdXK6EUO: s9qgDT8oclCrdXK6EUO = name
	s9qgDT8oclCrdXK6EUO = s9qgDT8oclCrdXK6EUO.upper()
	return s9qgDT8oclCrdXK6EUO
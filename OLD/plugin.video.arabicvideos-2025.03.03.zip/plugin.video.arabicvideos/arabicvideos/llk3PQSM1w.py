# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
x5TvLsPECHUoaqg1Dl3GwJj = 'EXCLUDES'
def MM4p0UZ2PC8WSE7eX3J9lLDyw(z36flodJVD9jWxip14Rh,pGUJS6AQVcYfbgTPa8qZL4izHClhD0):
	pGUJS6AQVcYfbgTPa8qZL4izHClhD0 = pGUJS6AQVcYfbgTPa8qZL4izHClhD0.replace(n0nFOd4yR97fQzNLSW,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(' '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV)[BkM54Kr7Qbqn:]
	JY8ipjd0ATVmWSDXOE = EcQxOa3RJm86WjTKA.findall('[a-zA-Z]',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
	if 'بحث IPTV - ' in z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace('بحث IPTV - ',ghA8DEI1uiecHS6+'بحث IPTV - '+ghA8DEI1uiecHS6)
	elif ' IPTV' in z36flodJVD9jWxip14Rh and pGUJS6AQVcYfbgTPa8qZL4izHClhD0=='IPT': z36flodJVD9jWxip14Rh = ghA8DEI1uiecHS6+z36flodJVD9jWxip14Rh
	elif 'بحث M3U - ' in z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace('بحث M3U - ',ghA8DEI1uiecHS6+'بحث M3U - '+ghA8DEI1uiecHS6)
	elif ' M3U' in z36flodJVD9jWxip14Rh and pGUJS6AQVcYfbgTPa8qZL4izHClhD0=='M3U': z36flodJVD9jWxip14Rh = ghA8DEI1uiecHS6+z36flodJVD9jWxip14Rh
	elif 'بحث ' in z36flodJVD9jWxip14Rh and ' - ' in z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = ghA8DEI1uiecHS6+z36flodJVD9jWxip14Rh
	elif not JY8ipjd0ATVmWSDXOE:
		Ukog5bT9pOItjPxGvyH = EcQxOa3RJm86WjTKA.findall('^( *?)(.*?)( *?)$',z36flodJVD9jWxip14Rh)
		ohKtmNCVYA01,X2BeSQktLPHZhIRm60qx,xg9uE1cKQ8foIALJe = Ukog5bT9pOItjPxGvyH[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		ki4CYg1jAJ3nQprD08u2bzfMU = EcQxOa3RJm86WjTKA.findall('^([!-~])',X2BeSQktLPHZhIRm60qx)
		if ki4CYg1jAJ3nQprD08u2bzfMU: z36flodJVD9jWxip14Rh = ohKtmNCVYA01+fROdS5FWnqVN3aurX9bZx+X2BeSQktLPHZhIRm60qx+xg9uE1cKQ8foIALJe
		else: z36flodJVD9jWxip14Rh = xg9uE1cKQ8foIALJe+ghA8DEI1uiecHS6+X2BeSQktLPHZhIRm60qx+ohKtmNCVYA01
	else:
		import bidi.algorithm as n5nhyxsWuCGNpLR
		if BkM54Kr7Qbqn:
			hxsWPI7YLGDAt = z36flodJVD9jWxip14Rh
			iiD5KYRZ1mS7kNIT4OjCW = n5nhyxsWuCGNpLR.get_display(z36flodJVD9jWxip14Rh,base_dir='L')
			if gZlSEJaXO9F461AL3sR7rWNpqf: hxsWPI7YLGDAt = hxsWPI7YLGDAt.decode(Tk9eH2qw6Brsuhj)
			if gZlSEJaXO9F461AL3sR7rWNpqf: iiD5KYRZ1mS7kNIT4OjCW = iiD5KYRZ1mS7kNIT4OjCW.decode(Tk9eH2qw6Brsuhj)
			PPlThibv5yQxCWHDOGAo = hxsWPI7YLGDAt.split(ksJdoFWhxTz8Y2N7bOZE)
			ein3ECMD6xqtsOGTKHNpVBZ = iiD5KYRZ1mS7kNIT4OjCW.split(ksJdoFWhxTz8Y2N7bOZE)
			M1aBE9Yn6T3ZhqD8zWCbxkiX0ONue,nnoJVeP1MKAysINY3ETjkdD0H,CCl5HIZyqQYBAi74GPuWFfcb3J,nKuxry10CBPHhtYTGoEiLkWVM = [],[],fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
			u2EJZstNWf4azgXTcjmYi7n = zip(PPlThibv5yQxCWHDOGAo,ein3ECMD6xqtsOGTKHNpVBZ)
			for P7ohicyd0aB8IlUmKn,A3pC9VSePF in u2EJZstNWf4azgXTcjmYi7n:
				if P7ohicyd0aB8IlUmKn==A3pC9VSePF==fy8iFgEkrO12NR9TWBI35sjY6qHvV and nKuxry10CBPHhtYTGoEiLkWVM:
					CCl5HIZyqQYBAi74GPuWFfcb3J += ksJdoFWhxTz8Y2N7bOZE
					continue
				if P7ohicyd0aB8IlUmKn==A3pC9VSePF:
					xatZNunFzSW0C9krgL3DpdMqoQj7A5 = 'EN'
					if nKuxry10CBPHhtYTGoEiLkWVM==xatZNunFzSW0C9krgL3DpdMqoQj7A5: CCl5HIZyqQYBAi74GPuWFfcb3J += ksJdoFWhxTz8Y2N7bOZE+P7ohicyd0aB8IlUmKn
					elif P7ohicyd0aB8IlUmKn:
						if CCl5HIZyqQYBAi74GPuWFfcb3J:
							nnoJVeP1MKAysINY3ETjkdD0H.append(CCl5HIZyqQYBAi74GPuWFfcb3J)
							M1aBE9Yn6T3ZhqD8zWCbxkiX0ONue.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						CCl5HIZyqQYBAi74GPuWFfcb3J = P7ohicyd0aB8IlUmKn
				else:
					xatZNunFzSW0C9krgL3DpdMqoQj7A5 = 'AR'
					if nKuxry10CBPHhtYTGoEiLkWVM==xatZNunFzSW0C9krgL3DpdMqoQj7A5: CCl5HIZyqQYBAi74GPuWFfcb3J += ksJdoFWhxTz8Y2N7bOZE+P7ohicyd0aB8IlUmKn
					elif P7ohicyd0aB8IlUmKn:
						if CCl5HIZyqQYBAi74GPuWFfcb3J:
							M1aBE9Yn6T3ZhqD8zWCbxkiX0ONue.append(CCl5HIZyqQYBAi74GPuWFfcb3J)
							nnoJVeP1MKAysINY3ETjkdD0H.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						CCl5HIZyqQYBAi74GPuWFfcb3J = P7ohicyd0aB8IlUmKn
				nKuxry10CBPHhtYTGoEiLkWVM = xatZNunFzSW0C9krgL3DpdMqoQj7A5
			if xatZNunFzSW0C9krgL3DpdMqoQj7A5=='EN':
				M1aBE9Yn6T3ZhqD8zWCbxkiX0ONue.append(CCl5HIZyqQYBAi74GPuWFfcb3J)
				nnoJVeP1MKAysINY3ETjkdD0H.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			else:
				nnoJVeP1MKAysINY3ETjkdD0H.append(CCl5HIZyqQYBAi74GPuWFfcb3J)
				M1aBE9Yn6T3ZhqD8zWCbxkiX0ONue.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			POK8Tm3JYCG5UezIgyarBi = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			u2EJZstNWf4azgXTcjmYi7n = zip(M1aBE9Yn6T3ZhqD8zWCbxkiX0ONue,nnoJVeP1MKAysINY3ETjkdD0H)
			import bidi.mirror as LuESneQVWICZzKJt7gAp2Y
			for PPr7A3cUuNTijyW4lLhpgVJ,dQJx6W8gOUbXmPctrYjNzeoV in u2EJZstNWf4azgXTcjmYi7n:
				if PPr7A3cUuNTijyW4lLhpgVJ: POK8Tm3JYCG5UezIgyarBi += ksJdoFWhxTz8Y2N7bOZE+PPr7A3cUuNTijyW4lLhpgVJ
				else:
					ki4CYg1jAJ3nQprD08u2bzfMU = EcQxOa3RJm86WjTKA.findall('([!-~]) *$',dQJx6W8gOUbXmPctrYjNzeoV)
					if ki4CYg1jAJ3nQprD08u2bzfMU:
						ki4CYg1jAJ3nQprD08u2bzfMU = ki4CYg1jAJ3nQprD08u2bzfMU[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
						try:
							P6sDjH9befI1yEq0i = LuESneQVWICZzKJt7gAp2Y.MIRRORED[ki4CYg1jAJ3nQprD08u2bzfMU]
							Ukog5bT9pOItjPxGvyH = EcQxOa3RJm86WjTKA.findall('^( *?)(.*?)( *?)$',dQJx6W8gOUbXmPctrYjNzeoV)
							if Ukog5bT9pOItjPxGvyH: ohKtmNCVYA01,dQJx6W8gOUbXmPctrYjNzeoV,xg9uE1cKQ8foIALJe = Ukog5bT9pOItjPxGvyH[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
							dQJx6W8gOUbXmPctrYjNzeoV = ohKtmNCVYA01+P6sDjH9befI1yEq0i+dQJx6W8gOUbXmPctrYjNzeoV[:-BkM54Kr7Qbqn]+xg9uE1cKQ8foIALJe
						except: pass
					POK8Tm3JYCG5UezIgyarBi += ksJdoFWhxTz8Y2N7bOZE+dQJx6W8gOUbXmPctrYjNzeoV
			z36flodJVD9jWxip14Rh = POK8Tm3JYCG5UezIgyarBi[BkM54Kr7Qbqn:]
			if gZlSEJaXO9F461AL3sR7rWNpqf: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.encode(Tk9eH2qw6Brsuhj)
		else:
			if gZlSEJaXO9F461AL3sR7rWNpqf: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.decode(Tk9eH2qw6Brsuhj)
			z36flodJVD9jWxip14Rh = n5nhyxsWuCGNpLR.get_display(z36flodJVD9jWxip14Rh)
			hxsWPI7YLGDAt,iiD5KYRZ1mS7kNIT4OjCW = z36flodJVD9jWxip14Rh,z36flodJVD9jWxip14Rh
			if 1:
				nKuxry10CBPHhtYTGoEiLkWVM,sAtizNlqSLcGVwUPHhe = fy8iFgEkrO12NR9TWBI35sjY6qHvV,[]
				OogTqQR479Pp = z36flodJVD9jWxip14Rh.split(ksJdoFWhxTz8Y2N7bOZE)
				for rpTF1AvXuItZQqU8CnMRSDV in OogTqQR479Pp:
					if not rpTF1AvXuItZQqU8CnMRSDV:
						if sAtizNlqSLcGVwUPHhe: sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn] += ksJdoFWhxTz8Y2N7bOZE
						else: sAtizNlqSLcGVwUPHhe.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
						continue
					HTb3y7n6ZcNmICWESVxJUaDQ = EcQxOa3RJm86WjTKA.findall('[!-~]',rpTF1AvXuItZQqU8CnMRSDV[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
					if HTb3y7n6ZcNmICWESVxJUaDQ==nKuxry10CBPHhtYTGoEiLkWVM and sAtizNlqSLcGVwUPHhe: sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn] += ksJdoFWhxTz8Y2N7bOZE+rpTF1AvXuItZQqU8CnMRSDV
					else:
						if sAtizNlqSLcGVwUPHhe:
							VJKEkAjX3BtpIZ0TQdLU = EcQxOa3RJm86WjTKA.findall('[^!-~]',sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn])
							if VJKEkAjX3BtpIZ0TQdLU:
								sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn] = n5nhyxsWuCGNpLR.get_display(sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn])
								fR0NaKLlZBejw7txAY8qs = EcQxOa3RJm86WjTKA.findall('^ +',sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn])
								if fR0NaKLlZBejw7txAY8qs: sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn] = sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn].lstrip(ksJdoFWhxTz8Y2N7bOZE)+fR0NaKLlZBejw7txAY8qs[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
						sAtizNlqSLcGVwUPHhe.append(rpTF1AvXuItZQqU8CnMRSDV)
					nKuxry10CBPHhtYTGoEiLkWVM = HTb3y7n6ZcNmICWESVxJUaDQ
				if sAtizNlqSLcGVwUPHhe: sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn] = n5nhyxsWuCGNpLR.get_display(sAtizNlqSLcGVwUPHhe[-BkM54Kr7Qbqn])
				z36flodJVD9jWxip14Rh = ksJdoFWhxTz8Y2N7bOZE.join(sAtizNlqSLcGVwUPHhe)
			if gZlSEJaXO9F461AL3sR7rWNpqf: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.encode(Tk9eH2qw6Brsuhj)
	return z36flodJVD9jWxip14Rh
def N1QgS5v3HFrtaB(peZN2cHsq8EP1zALXCyd,lYhXftLe5N,Ri846oIWDHYyBdMTthCJ):
	ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,OwcS5YqjIFTkE2MfRzKl6P,vW5LOzFNuyR,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW = peZN2cHsq8EP1zALXCyd
	hO3D6GVPY2qENv8bZWH = int(hO3D6GVPY2qENv8bZWH)
	H3fqx2PWtC5uprocXazLn = EcQxOa3RJm86WjTKA.findall('(_(\d\d\.\d\d)_(\d\d\:\d\d)_)',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
	if H3fqx2PWtC5uprocXazLn:
		H3fqx2PWtC5uprocXazLn,SGNDZYxUkemt9RbnA8,nb9kABMTvaiOJs = H3fqx2PWtC5uprocXazLn[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(H3fqx2PWtC5uprocXazLn,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	aIb8mOvT2E1rF = z36flodJVD9jWxip14Rh
	pGUJS6AQVcYfbgTPa8qZL4izHClhD0 = EcQxOa3RJm86WjTKA.findall('^_(\w\w\w)_(.*?)$',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
	if pGUJS6AQVcYfbgTPa8qZL4izHClhD0:
		pGUJS6AQVcYfbgTPa8qZL4izHClhD0,z36flodJVD9jWxip14Rh = pGUJS6AQVcYfbgTPa8qZL4izHClhD0[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		Amqt8FH2RdOX0Yxv = '_MOD_' in z36flodJVD9jWxip14Rh
		ZXOQjgueim57H6p1NrCsTyzA = ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder'
		if Amqt8FH2RdOX0Yxv and ZXOQjgueim57H6p1NrCsTyzA: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra = ';'
		elif Amqt8FH2RdOX0Yxv and not ZXOQjgueim57H6p1NrCsTyzA: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra = gTMA6jrcU03JNv1
		elif not Amqt8FH2RdOX0Yxv and ZXOQjgueim57H6p1NrCsTyzA: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra = ','
		elif not Amqt8FH2RdOX0Yxv and not ZXOQjgueim57H6p1NrCsTyzA: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra = ksJdoFWhxTz8Y2N7bOZE
		z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace('_MOD_',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		pGUJS6AQVcYfbgTPa8qZL4izHClhD0 = FlBmLp1DQjxu0yRz3ePkAVU9iZTcra+n0nFOd4yR97fQzNLSW+pGUJS6AQVcYfbgTPa8qZL4izHClhD0+' '+T7ASIp1ZYwio9HQ8cObJK
	else: pGUJS6AQVcYfbgTPa8qZL4izHClhD0 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if H3fqx2PWtC5uprocXazLn:
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			H3fqx2PWtC5uprocXazLn = WydpaVx5YmLoCiIgA34eEBlb+SGNDZYxUkemt9RbnA8+ksJdoFWhxTz8Y2N7bOZE+nb9kABMTvaiOJs+T7ASIp1ZYwio9HQ8cObJK
			if pGUJS6AQVcYfbgTPa8qZL4izHClhD0: z36flodJVD9jWxip14Rh = H3fqx2PWtC5uprocXazLn+ksJdoFWhxTz8Y2N7bOZE+ghA8DEI1uiecHS6+pGUJS6AQVcYfbgTPa8qZL4izHClhD0+z36flodJVD9jWxip14Rh
			else: z36flodJVD9jWxip14Rh = H3fqx2PWtC5uprocXazLn+ghA8DEI1uiecHS6+z36flodJVD9jWxip14Rh+ksJdoFWhxTz8Y2N7bOZE
		elif jTDWgftK7NEmx0JAkOn2aRIvweq:
			if pGUJS6AQVcYfbgTPa8qZL4izHClhD0:
				H3fqx2PWtC5uprocXazLn = WydpaVx5YmLoCiIgA34eEBlb+SGNDZYxUkemt9RbnA8+ksJdoFWhxTz8Y2N7bOZE+nb9kABMTvaiOJs+T7ASIp1ZYwio9HQ8cObJK
				z36flodJVD9jWxip14Rh = H3fqx2PWtC5uprocXazLn+ksJdoFWhxTz8Y2N7bOZE+pGUJS6AQVcYfbgTPa8qZL4izHClhD0+z36flodJVD9jWxip14Rh
			else:
				H3fqx2PWtC5uprocXazLn = WydpaVx5YmLoCiIgA34eEBlb+nb9kABMTvaiOJs+ksJdoFWhxTz8Y2N7bOZE+SGNDZYxUkemt9RbnA8+T7ASIp1ZYwio9HQ8cObJK
				z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh+ksJdoFWhxTz8Y2N7bOZE+ghA8DEI1uiecHS6+H3fqx2PWtC5uprocXazLn
	elif pGUJS6AQVcYfbgTPa8qZL4izHClhD0:
		z36flodJVD9jWxip14Rh = MM4p0UZ2PC8WSE7eX3J9lLDyw(z36flodJVD9jWxip14Rh,pGUJS6AQVcYfbgTPa8qZL4izHClhD0)
		z36flodJVD9jWxip14Rh = pGUJS6AQVcYfbgTPa8qZL4izHClhD0+z36flodJVD9jWxip14Rh
	peZN2cHsq8EP1zALXCyd = ppi24CwDdH3YzVIK8BUyLluQJEMW,aIb8mOvT2E1rF,eEncXMVB2rNg4JObl3utYfj,str(hO3D6GVPY2qENv8bZWH),R87NZgODb1jyuxBAScelVivtP2,OwcS5YqjIFTkE2MfRzKl6P,vW5LOzFNuyR,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW
	GbYXlcFtpk = {'type':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'mode':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'url':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'text':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'page':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'name':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'image':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'context':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'infodict':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
	if jTDWgftK7NEmx0JAkOn2aRIvweq: aIb8mOvT2E1rF = aIb8mOvT2E1rF.encode(Tk9eH2qw6Brsuhj,'ignore').decode(Tk9eH2qw6Brsuhj)
	GbYXlcFtpk['name'] = DVX5GWhnIxYlSd9rEuetjk40UJ(aIb8mOvT2E1rF)
	GbYXlcFtpk['type'] = ppi24CwDdH3YzVIK8BUyLluQJEMW.strip(ksJdoFWhxTz8Y2N7bOZE)
	GbYXlcFtpk['mode'] = str(hO3D6GVPY2qENv8bZWH).strip(ksJdoFWhxTz8Y2N7bOZE)
	if ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder' and OwcS5YqjIFTkE2MfRzKl6P: GbYXlcFtpk['page'] = DVX5GWhnIxYlSd9rEuetjk40UJ(OwcS5YqjIFTkE2MfRzKl6P.strip(ksJdoFWhxTz8Y2N7bOZE))
	if R5gQk0ZcerYx3B: GbYXlcFtpk['context'] = R5gQk0ZcerYx3B.strip(ksJdoFWhxTz8Y2N7bOZE)
	if vW5LOzFNuyR: GbYXlcFtpk['text'] = DVX5GWhnIxYlSd9rEuetjk40UJ(vW5LOzFNuyR.strip(ksJdoFWhxTz8Y2N7bOZE))
	if R87NZgODb1jyuxBAScelVivtP2: GbYXlcFtpk['image'] = DVX5GWhnIxYlSd9rEuetjk40UJ(R87NZgODb1jyuxBAScelVivtP2.strip(ksJdoFWhxTz8Y2N7bOZE))
	if IYUEhjmyOzv40iCgxeN8JDPW:
		IYUEhjmyOzv40iCgxeN8JDPW = str(IYUEhjmyOzv40iCgxeN8JDPW)
		GbYXlcFtpk['infodict'] = DVX5GWhnIxYlSd9rEuetjk40UJ(IYUEhjmyOzv40iCgxeN8JDPW.strip(ksJdoFWhxTz8Y2N7bOZE))
		IYUEhjmyOzv40iCgxeN8JDPW = eval(IYUEhjmyOzv40iCgxeN8JDPW)
	else: IYUEhjmyOzv40iCgxeN8JDPW = {}
	if eEncXMVB2rNg4JObl3utYfj: GbYXlcFtpk['url'] = DVX5GWhnIxYlSd9rEuetjk40UJ(eEncXMVB2rNg4JObl3utYfj.strip(ksJdoFWhxTz8Y2N7bOZE))
	AZrBg7fstVLDoGq = {'name':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'context_menu':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'plot':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'stars':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'image':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'type':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'isFolder':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'newpath':fy8iFgEkrO12NR9TWBI35sjY6qHvV,'duration':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
	FsISHh9ygNpt7cwZ0Azmj8iQPa = []
	riOKvW35nX6fZHc = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'/?type='+GbYXlcFtpk['type']+'&mode='+GbYXlcFtpk['mode']
	if GbYXlcFtpk['page']: riOKvW35nX6fZHc += '&page='+GbYXlcFtpk['page']
	if GbYXlcFtpk['name']: riOKvW35nX6fZHc += '&name='+GbYXlcFtpk['name']
	if GbYXlcFtpk['text']: riOKvW35nX6fZHc += '&text='+GbYXlcFtpk['text']
	if GbYXlcFtpk['infodict']: riOKvW35nX6fZHc += '&infodict='+GbYXlcFtpk['infodict']
	if GbYXlcFtpk['image']: riOKvW35nX6fZHc += '&image='+GbYXlcFtpk['image']
	if GbYXlcFtpk['url']: riOKvW35nX6fZHc += '&url='+GbYXlcFtpk['url']
	if hO3D6GVPY2qENv8bZWH!=265: AZrBg7fstVLDoGq['favorites'] = EsCplGc5N4mBuYW0RVQt6b
	else: AZrBg7fstVLDoGq['favorites'] = LhFAGlQ19zr
	if GbYXlcFtpk['context']: riOKvW35nX6fZHc += '&context='+GbYXlcFtpk['context']
	if hO3D6GVPY2qENv8bZWH in [235,238] and ppi24CwDdH3YzVIK8BUyLluQJEMW=='live' and 'EPG' in R5gQk0ZcerYx3B:
		xCuHgsR8AbfoK5SY9zLrwTyEQaP = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'?mode=238&text=SHORT_EPG&url='+eEncXMVB2rNg4JObl3utYfj
		YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'البرامج القادمة'+T7ASIp1ZYwio9HQ8cObJK
		kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
		FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if hO3D6GVPY2qENv8bZWH==265:
		gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq = lYhXftLe5N(vW5LOzFNuyR,EsCplGc5N4mBuYW0RVQt6b)
		if gDb5wsPxWQJjVL8oXSIT2uF1rNUtZq>D2D96X5NGamBhrFwvL8VEbqiSfZIl:
			xCuHgsR8AbfoK5SY9zLrwTyEQaP = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'?mode=266&text='+vW5LOzFNuyR
			YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'مسح قائمة آخر 50 '+eJYnofQG4mc8aFiN(vW5LOzFNuyR)+T7ASIp1ZYwio9HQ8cObJK
			kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
			FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if ppi24CwDdH3YzVIK8BUyLluQJEMW=='video' and hO3D6GVPY2qENv8bZWH!=331:
		xCuHgsR8AbfoK5SY9zLrwTyEQaP = riOKvW35nX6fZHc+'&context=6_DOWNLOAD'
		YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'تحميل ملف الفيديو'+T7ASIp1ZYwio9HQ8cObJK
		kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
		FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if hO3D6GVPY2qENv8bZWH==331:
		xCuHgsR8AbfoK5SY9zLrwTyEQaP = riOKvW35nX6fZHc+'&context=6_DELETE'
		YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'حذف ملف الفيديو'+T7ASIp1ZYwio9HQ8cObJK
		kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
		FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder' and hO3D6GVPY2qENv8bZWH==540:
		IVgLvXmtbf9HWwCzZAca31JB = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_SPLITTED_ALL')
		if IVgLvXmtbf9HWwCzZAca31JB:
			xCuHgsR8AbfoK5SY9zLrwTyEQaP = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'?context=7'
			YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'مسح كلمات بحث المواقع'+T7ASIp1ZYwio9HQ8cObJK
			kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
			FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder' and hO3D6GVPY2qENv8bZWH==1010:
		IVgLvXmtbf9HWwCzZAca31JB = rIhXWK91vRuC(jUCABmLYMf0G,'list','GLOBALSEARCH_SPLITTED_GOOGLE')
		if IVgLvXmtbf9HWwCzZAca31JB:
			xCuHgsR8AbfoK5SY9zLrwTyEQaP = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'?context=10'
			YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'مسح كلمات بحث جوجل'+T7ASIp1ZYwio9HQ8cObJK
			kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
			FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	zAenblRWspXqxoy = [9990,9999,teaC5j4HuGDqpwcmUzJ,7,100,151,159,176,196,199,230,239,260,261,262,263,264,265,267,270,290,330,341,346,348,501,505,510,540,710,719,761,762,1010,1022]
	if hO3D6GVPY2qENv8bZWH not in zAenblRWspXqxoy:
		xCuHgsR8AbfoK5SY9zLrwTyEQaP = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'?context=8&mode=260'
		YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'القائمة الرئيسية'+T7ASIp1ZYwio9HQ8cObJK
		kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
		FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	Zj6VWrhEk0U5AC2vGupf = hO3D6GVPY2qENv8bZWH-hO3D6GVPY2qENv8bZWH%10
	if hO3D6GVPY2qENv8bZWH%10:
		if Zj6VWrhEk0U5AC2vGupf==280: Zj6VWrhEk0U5AC2vGupf = 230
		if Zj6VWrhEk0U5AC2vGupf==410: Zj6VWrhEk0U5AC2vGupf = 400
		if Zj6VWrhEk0U5AC2vGupf==520: Zj6VWrhEk0U5AC2vGupf = 510
		if Zj6VWrhEk0U5AC2vGupf not in Aa4EeTLwW15foql63y:
			xCuHgsR8AbfoK5SY9zLrwTyEQaP = 'plugin://'+SZvQ0Jre4BHyGVFxoPYM2IU6+'?context=8&mode='+str(Zj6VWrhEk0U5AC2vGupf)
			YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'قائمة الموقع'+T7ASIp1ZYwio9HQ8cObJK
			kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
			FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	xCuHgsR8AbfoK5SY9zLrwTyEQaP = riOKvW35nX6fZHc+'&context=9'
	YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'تحديث القائمة'+T7ASIp1ZYwio9HQ8cObJK
	kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
	FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if ppi24CwDdH3YzVIK8BUyLluQJEMW in ['video','live']:
		xCuHgsR8AbfoK5SY9zLrwTyEQaP = riOKvW35nX6fZHc+'&context=18'
		YkG06ORanP = WydpaVx5YmLoCiIgA34eEBlb+'إظهار قوائم الجودة'+T7ASIp1ZYwio9HQ8cObJK
		kA52sO0vqmuNI9ixZY7Ra = (YkG06ORanP,'RunPlugin('+xCuHgsR8AbfoK5SY9zLrwTyEQaP+')')
		FsISHh9ygNpt7cwZ0Azmj8iQPa.append(kA52sO0vqmuNI9ixZY7Ra)
	if ppi24CwDdH3YzVIK8BUyLluQJEMW in ['link','video','live']: lvnKExAVBt3FCXL4aygYkPjr671q = LhFAGlQ19zr
	elif ppi24CwDdH3YzVIK8BUyLluQJEMW=='folder': lvnKExAVBt3FCXL4aygYkPjr671q = EsCplGc5N4mBuYW0RVQt6b
	AZrBg7fstVLDoGq['name'] = z36flodJVD9jWxip14Rh
	AZrBg7fstVLDoGq['context_menu'] = FsISHh9ygNpt7cwZ0Azmj8iQPa
	if 'plot' in list(IYUEhjmyOzv40iCgxeN8JDPW.keys()): AZrBg7fstVLDoGq['plot'] = IYUEhjmyOzv40iCgxeN8JDPW['plot']
	if 'stars' in list(IYUEhjmyOzv40iCgxeN8JDPW.keys()): AZrBg7fstVLDoGq['stars'] = IYUEhjmyOzv40iCgxeN8JDPW['stars']
	if R87NZgODb1jyuxBAScelVivtP2: AZrBg7fstVLDoGq['image'] = R87NZgODb1jyuxBAScelVivtP2
	if ppi24CwDdH3YzVIK8BUyLluQJEMW=='video' and OwcS5YqjIFTkE2MfRzKl6P:
		WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA = EcQxOa3RJm86WjTKA.findall('[\d:]+',OwcS5YqjIFTkE2MfRzKl6P,EcQxOa3RJm86WjTKA.DOTALL)
		if WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA:
			WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA = '0:0:0:0:0:'+WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			wwufxh1HS5oreOgtW,xk0wvLpV4cXWCGA3,LLNqmKMvdUgER5AbzT2ZkDHitywY71,bwR2KIx6o4v,CdnceDQTSuh = WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA.rsplit(':',vD4Fh6ictZ7wME)
			jyIcfa23oz46Lx = int(xk0wvLpV4cXWCGA3)*24*tpCSLxQO2swRuedhYbVB1Evri5k+int(LLNqmKMvdUgER5AbzT2ZkDHitywY71)*tpCSLxQO2swRuedhYbVB1Evri5k+int(bwR2KIx6o4v)*60+int(CdnceDQTSuh)
			AZrBg7fstVLDoGq['duration'] = jyIcfa23oz46Lx
	AZrBg7fstVLDoGq['type'] = ppi24CwDdH3YzVIK8BUyLluQJEMW
	AZrBg7fstVLDoGq['isFolder'] = lvnKExAVBt3FCXL4aygYkPjr671q
	AZrBg7fstVLDoGq['newpath'] = riOKvW35nX6fZHc
	AZrBg7fstVLDoGq['menuItem'] = peZN2cHsq8EP1zALXCyd
	AZrBg7fstVLDoGq['mode'] = hO3D6GVPY2qENv8bZWH
	return AZrBg7fstVLDoGq
def CCiE567eoLhA4Vq(lYhXftLe5N):
	w1FmDY8eAXBTgLbzVnd6xiRW7E,yNGUJ2kYzPnhDLi = [],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	from kxdqilYRPe import QDKyWZIiCJRrB,YzSRtv7Zuk1oEf
	Ri846oIWDHYyBdMTthCJ = QDKyWZIiCJRrB()
	gYT79cyvtiJkrDNOH = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.refresh')
	if LVXc6WJ3eAoz5hgnyrut1 and (not gYT79cyvtiJkrDNOH or gYT79cyvtiJkrDNOH=='REFRESH_CACHE'): gYT79cyvtiJkrDNOH = rIhXWK91vRuC(jUCABmLYMf0G,'str','FOLDERS_SORT',LVXc6WJ3eAoz5hgnyrut1)
	if gYT79cyvtiJkrDNOH:
		if   '_PERM' in gYT79cyvtiJkrDNOH: yNGUJ2kYzPnhDLi = 'دائمي'
		elif '_TEMP' in gYT79cyvtiJkrDNOH: yNGUJ2kYzPnhDLi = 'مؤقت'
		if   '_REVERSED_' in gYT79cyvtiJkrDNOH: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'عكسي' ; I4t9qonjrm.menuItemsLIST[:] = reversed(I4t9qonjrm.menuItemsLIST)
		elif '_ASCENDED_' in gYT79cyvtiJkrDNOH: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'تصاعدي' ; I4t9qonjrm.menuItemsLIST[:] = sorted(I4t9qonjrm.menuItemsLIST,reverse=LhFAGlQ19zr,key=lambda key:key[BkM54Kr7Qbqn])
		elif '_DESCENDED_' in gYT79cyvtiJkrDNOH: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'تنازلي' ; I4t9qonjrm.menuItemsLIST[:] = sorted(I4t9qonjrm.menuItemsLIST,reverse=EsCplGc5N4mBuYW0RVQt6b,key=lambda key:key[BkM54Kr7Qbqn])
		elif '_RANDOMIZED_' in gYT79cyvtiJkrDNOH: z6FysMQJTa2IWYdrDx7BjObwN3fE = 'عشوائي' ; yiTBYwps2mCrb4jGPux0cIJ.shuffle(I4t9qonjrm.menuItemsLIST)
	name = 'ترتيب '+z6FysMQJTa2IWYdrDx7BjObwN3fE+ksJdoFWhxTz8Y2N7bOZE+yNGUJ2kYzPnhDLi if yNGUJ2kYzPnhDLi else 'بدون ترتيب (أصلي)'
	name = WydpaVx5YmLoCiIgA34eEBlb+name+T7ASIp1ZYwio9HQ8cObJK
	if gYT79cyvtiJkrDNOH in sqfx3MXEol: OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.refresh',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW = OBw7zQog2DrJlPRZ(LVXc6WJ3eAoz5hgnyrut1)
	hO3D6GVPY2qENv8bZWH = int(mmocwN1frQJ5ST3xa)
	Zj6VWrhEk0U5AC2vGupf = hO3D6GVPY2qENv8bZWH-hO3D6GVPY2qENv8bZWH%10
	if hO3D6GVPY2qENv8bZWH%10 and Zj6VWrhEk0U5AC2vGupf not in Aa4EeTLwW15foql63y and len(I4t9qonjrm.menuItemsLIST)>1:
		I4t9qonjrm.menuItemsLIST[:] = [('link',name,'',533,'','',LVXc6WJ3eAoz5hgnyrut1,'','')]+I4t9qonjrm.menuItemsLIST
	for peZN2cHsq8EP1zALXCyd in I4t9qonjrm.menuItemsLIST:
		AZrBg7fstVLDoGq = N1QgS5v3HFrtaB(peZN2cHsq8EP1zALXCyd,lYhXftLe5N,Ri846oIWDHYyBdMTthCJ)
		if AZrBg7fstVLDoGq['favorites']:
			JtnhvYIRPHea0rUfqX2swpZkGgMO = YzSRtv7Zuk1oEf(Ri846oIWDHYyBdMTthCJ,AZrBg7fstVLDoGq['menuItem'],AZrBg7fstVLDoGq['newpath'])
			AZrBg7fstVLDoGq['context_menu'] = JtnhvYIRPHea0rUfqX2swpZkGgMO+AZrBg7fstVLDoGq['context_menu']
		w1FmDY8eAXBTgLbzVnd6xiRW7E.append(AZrBg7fstVLDoGq)
	return w1FmDY8eAXBTgLbzVnd6xiRW7E
def nQTWFEhflD(LZhBxTSy4qP7zKIbGw):
	FlBmLp1DQjxu0yRz3ePkAVU9iZTcra,pg4PH630dC2iD, = [],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
		if not gSUZXf3r57Bzeq: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		else: break
	LZhBxTSy4qP7zKIbGw = LZhBxTSy4qP7zKIbGw[len(FlBmLp1DQjxu0yRz3ePkAVU9iZTcra):]
	YMaiHbnIThsP7q = '\n\n\n\n'.join(LZhBxTSy4qP7zKIbGw)
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('===== ===== =====','000001')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(n0nFOd4yR97fQzNLSW,'000002')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(WydpaVx5YmLoCiIgA34eEBlb,'000003')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(T7ASIp1ZYwio9HQ8cObJK,'000004')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[RIGHT]','000005')
	gLoUCe7WqVp = 100000
	ohvXcCPplKMuqEa = {}
	VO4SF36agt9s02ydIwx7oENThz = EcQxOa3RJm86WjTKA.findall('http.*?[\r\n ]',YMaiHbnIThsP7q,EcQxOa3RJm86WjTKA.DOTALL)
	for zy7D6UmpKj1aScOBkowQ2E5uNlLI3T in VO4SF36agt9s02ydIwx7oENThz:
		gLoUCe7WqVp += BkM54Kr7Qbqn
		YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(zy7D6UmpKj1aScOBkowQ2E5uNlLI3T,str(gLoUCe7WqVp))
		ohvXcCPplKMuqEa[str(gLoUCe7WqVp)] = zy7D6UmpKj1aScOBkowQ2E5uNlLI3T
	for uYA2DJg3vyzpo8IHnVjZ47s in range(D2D96X5NGamBhrFwvL8VEbqiSfZIl,len(YMaiHbnIThsP7q),4800):
		BgREGuFdv7XLH5e4NVhsMTop9 = YMaiHbnIThsP7q[uYA2DJg3vyzpo8IHnVjZ47s:uYA2DJg3vyzpo8IHnVjZ47s+4800]
		B9BCJXUkFHPIxvr2s0Of5LA = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.code')
		eEncXMVB2rNg4JObl3utYfj = 'https://translator-api.glosbe.com/translateByLangDetect?sourceLang=ar&targetLang='+B9BCJXUkFHPIxvr2s0Of5LA
		LUvCxj6fMlnyEcDAahbgpH = {'Content-Type':'text/plain'}
		PywLZVsnFOgRk62eH5J3GoNKYp = BgREGuFdv7XLH5e4NVhsMTop9.encode(Tk9eH2qw6Brsuhj)
		I7jcKisuTt = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'POST',eEncXMVB2rNg4JObl3utYfj,PywLZVsnFOgRk62eH5J3GoNKYp,LUvCxj6fMlnyEcDAahbgpH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIBRARY-GLOSBE_TRANSLATE-1st')
		if I7jcKisuTt.succeeded:
			bbrCVFXl1YBE8n7 = I7jcKisuTt.content
			X9JvqeR7U62wVaPWLi4 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('str',bbrCVFXl1YBE8n7)
			if X9JvqeR7U62wVaPWLi4:
				X9JvqeR7U62wVaPWLi4 = X9JvqeR7U62wVaPWLi4['translation']
				X9JvqeR7U62wVaPWLi4 = XXcPiylRDh6IapYA25rwO8u(X9JvqeR7U62wVaPWLi4)
				for JhvuCHVREPNqU8bomeTcpOzFrw in range(len(X9JvqeR7U62wVaPWLi4)):
					pg4PH630dC2iD += X9JvqeR7U62wVaPWLi4[JhvuCHVREPNqU8bomeTcpOzFrw][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000001','===== ===== =====')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000002',n0nFOd4yR97fQzNLSW)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000003',WydpaVx5YmLoCiIgA34eEBlb)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000004',T7ASIp1ZYwio9HQ8cObJK)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000005','[RIGHT]')
	for gLoUCe7WqVp in list(ohvXcCPplKMuqEa.keys()):
		zy7D6UmpKj1aScOBkowQ2E5uNlLI3T = ohvXcCPplKMuqEa[gLoUCe7WqVp]
		pg4PH630dC2iD = pg4PH630dC2iD.replace(gLoUCe7WqVp,zy7D6UmpKj1aScOBkowQ2E5uNlLI3T)
	pg4PH630dC2iD = pg4PH630dC2iD.split('\n\n\n\n')
	return FlBmLp1DQjxu0yRz3ePkAVU9iZTcra+pg4PH630dC2iD
def xxfavW3c0IOTUsoPy(LZhBxTSy4qP7zKIbGw):
	FlBmLp1DQjxu0yRz3ePkAVU9iZTcra,pg4PH630dC2iD, = [],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
		if not gSUZXf3r57Bzeq: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		else: break
	LZhBxTSy4qP7zKIbGw = LZhBxTSy4qP7zKIbGw[len(FlBmLp1DQjxu0yRz3ePkAVU9iZTcra):]
	YMaiHbnIThsP7q = '\\n\\n\\n\\n'.join(LZhBxTSy4qP7zKIbGw)
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('كلا','no')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('استمرار','continue')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('===== ===== =====','000001')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(n0nFOd4yR97fQzNLSW,'000002')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(WydpaVx5YmLoCiIgA34eEBlb,'000003')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(T7ASIp1ZYwio9HQ8cObJK,'000004')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[RIGHT]','000005')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[CENTER]','000006')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[RTL]','000007')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace("'","\\\\\\'")
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('"','\\\\\\"')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(C0qrknitpM4Z,'\\n')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(FFkml6ZbgXD,'\\\\r')
	for uYA2DJg3vyzpo8IHnVjZ47s in range(D2D96X5NGamBhrFwvL8VEbqiSfZIl,len(YMaiHbnIThsP7q),4800):
		BgREGuFdv7XLH5e4NVhsMTop9 = YMaiHbnIThsP7q[uYA2DJg3vyzpo8IHnVjZ47s:uYA2DJg3vyzpo8IHnVjZ47s+4800]
		eEncXMVB2rNg4JObl3utYfj = 'https://translate.google.com/_/TranslateWebserverUi/data/batchexecute'
		LUvCxj6fMlnyEcDAahbgpH = {'Content-Type':'application/x-www-form-urlencoded'}
		B9BCJXUkFHPIxvr2s0Of5LA = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.code')
		PywLZVsnFOgRk62eH5J3GoNKYp = 'f.req='+DVX5GWhnIxYlSd9rEuetjk40UJ('[[["MkEWBc","[[\\"'+BgREGuFdv7XLH5e4NVhsMTop9+'\\",\\"ar\\",\\"'+B9BCJXUkFHPIxvr2s0Of5LA+'\\",1],[]]",null,"generic"]]]',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		PywLZVsnFOgRk62eH5J3GoNKYp = PywLZVsnFOgRk62eH5J3GoNKYp.replace('%5Cn','%5C%5Cn')
		I7jcKisuTt = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'POST',eEncXMVB2rNg4JObl3utYfj,PywLZVsnFOgRk62eH5J3GoNKYp,LUvCxj6fMlnyEcDAahbgpH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIBRARY-GOOGLE_TRANSLATE-1st')
		if I7jcKisuTt.succeeded:
			bbrCVFXl1YBE8n7 = I7jcKisuTt.content
			bbrCVFXl1YBE8n7 = bbrCVFXl1YBE8n7.split(C0qrknitpM4Z)[-BkM54Kr7Qbqn]
			X9JvqeR7U62wVaPWLi4 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('str',bbrCVFXl1YBE8n7)[D2D96X5NGamBhrFwvL8VEbqiSfZIl][teaC5j4HuGDqpwcmUzJ]
			if X9JvqeR7U62wVaPWLi4:
				X9JvqeR7U62wVaPWLi4 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('str',X9JvqeR7U62wVaPWLi4)[BkM54Kr7Qbqn][D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl][hvkue2LYgiOGrtcmxszl4S8MWdnF]
				X9JvqeR7U62wVaPWLi4 = XXcPiylRDh6IapYA25rwO8u(X9JvqeR7U62wVaPWLi4)
				for JhvuCHVREPNqU8bomeTcpOzFrw in range(len(X9JvqeR7U62wVaPWLi4)):
					pg4PH630dC2iD += X9JvqeR7U62wVaPWLi4[JhvuCHVREPNqU8bomeTcpOzFrw][D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	pg4PH630dC2iD = pg4PH630dC2iD.replace('00000','0000').replace('0000','000')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0001','===== ===== =====')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0002',n0nFOd4yR97fQzNLSW)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0003',WydpaVx5YmLoCiIgA34eEBlb)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0004',T7ASIp1ZYwio9HQ8cObJK)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0005','[RIGHT]')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0006','[CENTER]')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0007','[RTL]')
	pg4PH630dC2iD = pg4PH630dC2iD.split('\n\n\n\n')
	return FlBmLp1DQjxu0yRz3ePkAVU9iZTcra+pg4PH630dC2iD
def qNjRY3SmQ2gvU(LZhBxTSy4qP7zKIbGw):
	FlBmLp1DQjxu0yRz3ePkAVU9iZTcra,HcZa2Poy0XDVN3TvG = [],[]
	for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
		if not gSUZXf3r57Bzeq: FlBmLp1DQjxu0yRz3ePkAVU9iZTcra.append(fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		else: break
	LZhBxTSy4qP7zKIbGw = LZhBxTSy4qP7zKIbGw[len(FlBmLp1DQjxu0yRz3ePkAVU9iZTcra):]
	YMaiHbnIThsP7q = '\n\n\n\n'.join(LZhBxTSy4qP7zKIbGw)
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('كلا','no')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('استمرار','continue')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('أدناه','below')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(n0nFOd4yR97fQzNLSW,'00001')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(WydpaVx5YmLoCiIgA34eEBlb,'00002')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(T7ASIp1ZYwio9HQ8cObJK,'00003')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('=====','00004')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(',','00005')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[RTL]','00009')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[CENTER]','0000A')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(FFkml6ZbgXD,'0000B')
	LZhBxTSy4qP7zKIbGw = YMaiHbnIThsP7q.split(C0qrknitpM4Z)
	YMaiHbnIThsP7q,pg4PH630dC2iD = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
		if len(YMaiHbnIThsP7q+gSUZXf3r57Bzeq)<1800: YMaiHbnIThsP7q += C0qrknitpM4Z+gSUZXf3r57Bzeq
		else:
			HcZa2Poy0XDVN3TvG.append(YMaiHbnIThsP7q)
			YMaiHbnIThsP7q = gSUZXf3r57Bzeq
	HcZa2Poy0XDVN3TvG.append(YMaiHbnIThsP7q)
	for gSUZXf3r57Bzeq in HcZa2Poy0XDVN3TvG:
		LUvCxj6fMlnyEcDAahbgpH = {'Content-Type':'application/json','User-Agent':fy8iFgEkrO12NR9TWBI35sjY6qHvV}
		eEncXMVB2rNg4JObl3utYfj = 'https://api.reverso.net/translate/v1/translation'
		B9BCJXUkFHPIxvr2s0Of5LA = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.code')
		PywLZVsnFOgRk62eH5J3GoNKYp = {"format":"text","from":"ara","to":B9BCJXUkFHPIxvr2s0Of5LA,"input":gSUZXf3r57Bzeq,"options":{"sentenceSplitter":EsCplGc5N4mBuYW0RVQt6b,"origin":"translation.web","contextResults":LhFAGlQ19zr,"languageDetection":LhFAGlQ19zr}}
		PywLZVsnFOgRk62eH5J3GoNKYp = Qra2CWgebk.dumps(PywLZVsnFOgRk62eH5J3GoNKYp)
		I7jcKisuTt = TBPcjsyOYoM82pm(oWMrx7zvedHY0UiS48XbOqVTJ,'POST',eEncXMVB2rNg4JObl3utYfj,PywLZVsnFOgRk62eH5J3GoNKYp,LUvCxj6fMlnyEcDAahbgpH,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIBRARY-REVERSO_TRANSLATE-1st')
		if I7jcKisuTt.succeeded:
			bbrCVFXl1YBE8n7 = I7jcKisuTt.content
			bbrCVFXl1YBE8n7 = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',bbrCVFXl1YBE8n7)
			pg4PH630dC2iD += C0qrknitpM4Z+fy8iFgEkrO12NR9TWBI35sjY6qHvV.join(bbrCVFXl1YBE8n7['translation'])
	pg4PH630dC2iD = pg4PH630dC2iD[teaC5j4HuGDqpwcmUzJ:]
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000000','00000').replace('00000','0000').replace('0000','000')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0001',n0nFOd4yR97fQzNLSW)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0002',WydpaVx5YmLoCiIgA34eEBlb)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0003',T7ASIp1ZYwio9HQ8cObJK)
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0004','=====')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0005',',')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('0009','[RTL]')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000A','[CENTER]')
	pg4PH630dC2iD = pg4PH630dC2iD.replace('000B',FFkml6ZbgXD)
	pg4PH630dC2iD = pg4PH630dC2iD.split('\n\n\n\n')
	return FlBmLp1DQjxu0yRz3ePkAVU9iZTcra+pg4PH630dC2iD
def IVLwJP9fsAklSmWKOa(LZhBxTSy4qP7zKIbGw):
	nnQqRHLtEG7JgFcASpXfUBx3zOm = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.translate')
	if not nnQqRHLtEG7JgFcASpXfUBx3zOm or not LZhBxTSy4qP7zKIbGw: return LZhBxTSy4qP7zKIbGw
	hymL4GSEtnpD = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.provider')
	B9BCJXUkFHPIxvr2s0Of5LA = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.code')
	ssZ5aeI1XOKk3VBMdEjCDfW4n692cF = B9BCJXUkFHPIxvr2s0Of5LA+'__'+str(LZhBxTSy4qP7zKIbGw)
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.language.translate',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	pg4PH630dC2iD = rIhXWK91vRuC(jUCABmLYMf0G,'list','TRANSLATE_'+hymL4GSEtnpD,ssZ5aeI1XOKk3VBMdEjCDfW4n692cF)
	if not pg4PH630dC2iD:
		if hymL4GSEtnpD=='GOOGLE': pg4PH630dC2iD = xxfavW3c0IOTUsoPy(LZhBxTSy4qP7zKIbGw)
		elif hymL4GSEtnpD=='REVERSO': pg4PH630dC2iD = qNjRY3SmQ2gvU(LZhBxTSy4qP7zKIbGw)
		elif hymL4GSEtnpD=='GLOSBE': pg4PH630dC2iD = nQTWFEhflD(LZhBxTSy4qP7zKIbGw)
		if len(LZhBxTSy4qP7zKIbGw)==len(pg4PH630dC2iD):
			tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'TRANSLATE_'+hymL4GSEtnpD,ssZ5aeI1XOKk3VBMdEjCDfW4n692cF,pg4PH630dC2iD,JJtWv7V436NPCf)
		else:
			pg4PH630dC2iD = LZhBxTSy4qP7zKIbGw
			a6rVSjDMF87KyYINcuOP1l40Hbp('الترجمة فشلت','Translation Failed')
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.language.translate','1')
	return pg4PH630dC2iD
def KKxbu3MCGsd2YE8p(peZN2cHsq8EP1zALXCyd,w1FmDY8eAXBTgLbzVnd6xiRW7E,PDe9Y0d4kKrAX5HSChOumGZFVqU8,Ip2njyFr9ZbOHaNP,YOlndMWkJ7UAbpi):
	ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW = peZN2cHsq8EP1zALXCyd
	Zjm4wN0lHpiSkByG3 = []
	nnQqRHLtEG7JgFcASpXfUBx3zOm = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.translate')
	if nnQqRHLtEG7JgFcASpXfUBx3zOm:
		KtZ46yIkplaVYW0v7c9C2TBiOHER,EymHzh4FcU2tBvDpAlok1gZbWIaTe,rrcGLCoyM4NX5kKQWFI = [],[],[]
		if not Zjm4wN0lHpiSkByG3:
			for AZrBg7fstVLDoGq in w1FmDY8eAXBTgLbzVnd6xiRW7E:
				z36flodJVD9jWxip14Rh = AZrBg7fstVLDoGq['name'].replace(ghA8DEI1uiecHS6,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(fROdS5FWnqVN3aurX9bZx,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				H3fqx2PWtC5uprocXazLn = EcQxOa3RJm86WjTKA.findall('^(\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\]) (.*?)$',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
				if H3fqx2PWtC5uprocXazLn:
					FlBmLp1DQjxu0yRz3ePkAVU9iZTcra,SGNDZYxUkemt9RbnA8,nb9kABMTvaiOJs,SPZYnlFURbovKjtBNe,z36flodJVD9jWxip14Rh = H3fqx2PWtC5uprocXazLn[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
					H3fqx2PWtC5uprocXazLn = FlBmLp1DQjxu0yRz3ePkAVU9iZTcra+SGNDZYxUkemt9RbnA8+ksJdoFWhxTz8Y2N7bOZE+nb9kABMTvaiOJs+SPZYnlFURbovKjtBNe+ksJdoFWhxTz8Y2N7bOZE
				else:
					H3fqx2PWtC5uprocXazLn = EcQxOa3RJm86WjTKA.findall('^(.*?) (\[COLOR FFFFFF00\])(\d\d.\d\d) (\d\d.\d\d)(\[/COLOR\])$',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
					if H3fqx2PWtC5uprocXazLn:
						z36flodJVD9jWxip14Rh,FlBmLp1DQjxu0yRz3ePkAVU9iZTcra,nb9kABMTvaiOJs,SGNDZYxUkemt9RbnA8,SPZYnlFURbovKjtBNe = H3fqx2PWtC5uprocXazLn[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
						H3fqx2PWtC5uprocXazLn = FlBmLp1DQjxu0yRz3ePkAVU9iZTcra+SGNDZYxUkemt9RbnA8+ksJdoFWhxTz8Y2N7bOZE+nb9kABMTvaiOJs+SPZYnlFURbovKjtBNe+ksJdoFWhxTz8Y2N7bOZE
					else: H3fqx2PWtC5uprocXazLn = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				pGUJS6AQVcYfbgTPa8qZL4izHClhD0 = EcQxOa3RJm86WjTKA.findall('^(.\[COLOR FFF08C1F\]\w\w\w \[/COLOR\])(.*?)$',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
				if pGUJS6AQVcYfbgTPa8qZL4izHClhD0: pGUJS6AQVcYfbgTPa8qZL4izHClhD0,z36flodJVD9jWxip14Rh = pGUJS6AQVcYfbgTPa8qZL4izHClhD0[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
				else: pGUJS6AQVcYfbgTPa8qZL4izHClhD0 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
				KtZ46yIkplaVYW0v7c9C2TBiOHER.append(H3fqx2PWtC5uprocXazLn+pGUJS6AQVcYfbgTPa8qZL4izHClhD0)
				EymHzh4FcU2tBvDpAlok1gZbWIaTe.append(z36flodJVD9jWxip14Rh)
			rrcGLCoyM4NX5kKQWFI = IVLwJP9fsAklSmWKOa(EymHzh4FcU2tBvDpAlok1gZbWIaTe)
			if rrcGLCoyM4NX5kKQWFI:
				for uYA2DJg3vyzpo8IHnVjZ47s in range(len(w1FmDY8eAXBTgLbzVnd6xiRW7E)):
					AZrBg7fstVLDoGq = w1FmDY8eAXBTgLbzVnd6xiRW7E[uYA2DJg3vyzpo8IHnVjZ47s]
					AZrBg7fstVLDoGq['name'] = KtZ46yIkplaVYW0v7c9C2TBiOHER[uYA2DJg3vyzpo8IHnVjZ47s]+rrcGLCoyM4NX5kKQWFI[uYA2DJg3vyzpo8IHnVjZ47s]
					Zjm4wN0lHpiSkByG3.append(AZrBg7fstVLDoGq)
	if Zjm4wN0lHpiSkByG3: w1FmDY8eAXBTgLbzVnd6xiRW7E = Zjm4wN0lHpiSkByG3
	SKxTLvhEJZDraq3eyfXHbGgpcYNlu,OacXWfh5goeLPrCsldtpFu1zR8HTUw,RPtpekJgG3B8Fq7axHmNu4Of0Y = [],D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
	JLQBNqS3MsVlPpfKAveER = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.menusimages')
	FiW9SAPx7J0ym1ED = JLQBNqS3MsVlPpfKAveER!='STOP'
	wEoaOpCBAklNhuZK21zS = []
	if FiW9SAPx7J0ym1ED:
		sEkR0OpMcrbKNqgDYu6 = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(P8F6NtJD5ridLmglTbWpzMo4,hO3D6GVPY2qENv8bZWH)
		try: wEoaOpCBAklNhuZK21zS = HoxKENAey2MdTt9kDUrVnWGLS0CPa.listdir(sEkR0OpMcrbKNqgDYu6)
		except:
			if not HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(sEkR0OpMcrbKNqgDYu6):
				try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.makedirs(sEkR0OpMcrbKNqgDYu6)
				except: pass
	IbEgYMJ9dFe24sQc = KyxQE4ih9vj6maAdInWLHoSrzp7DBG('menu_item')
	xeP6LdoJtC7cBYq2H = wEoaOpCBAklNhuZK21zS
	if gZlSEJaXO9F461AL3sR7rWNpqf and CfgZ0zWP5XBpoGQwLUY.platform=='win32':
		xeP6LdoJtC7cBYq2H = []
		for WT5zs4HlCXYRPSDLg1M in wEoaOpCBAklNhuZK21zS:
			WT5zs4HlCXYRPSDLg1M = WT5zs4HlCXYRPSDLg1M.decode('windows-1256').encode(Tk9eH2qw6Brsuhj)
			xeP6LdoJtC7cBYq2H.append(WT5zs4HlCXYRPSDLg1M)
	for AZrBg7fstVLDoGq in w1FmDY8eAXBTgLbzVnd6xiRW7E:
		z36flodJVD9jWxip14Rh = AZrBg7fstVLDoGq['name']
		if jTDWgftK7NEmx0JAkOn2aRIvweq: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.encode(Tk9eH2qw6Brsuhj,'ignore').decode(Tk9eH2qw6Brsuhj)
		FsISHh9ygNpt7cwZ0Azmj8iQPa = AZrBg7fstVLDoGq['context_menu']
		O4xgPbJlS8k5H1QCfXMTpIe9c3A = AZrBg7fstVLDoGq['plot']
		BWKE6APrGNpt0IJ1CmFaO45e79o = AZrBg7fstVLDoGq['stars']
		R87NZgODb1jyuxBAScelVivtP2 = AZrBg7fstVLDoGq['image']
		ppi24CwDdH3YzVIK8BUyLluQJEMW = AZrBg7fstVLDoGq['type']
		WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA = AZrBg7fstVLDoGq['duration']
		lvnKExAVBt3FCXL4aygYkPjr671q = AZrBg7fstVLDoGq['isFolder']
		riOKvW35nX6fZHc = AZrBg7fstVLDoGq['newpath']
		WAnCsgODVJawLrbt07PYIvmjBHRUuQ = nn19vN7ifGslVJODZWzCSudBK8.ListItem(z36flodJVD9jWxip14Rh)
		WAnCsgODVJawLrbt07PYIvmjBHRUuQ.addContextMenuItems(FsISHh9ygNpt7cwZ0Azmj8iQPa)
		WP45EOoSs9e1mRQpiNcKMhG8L = LhFAGlQ19zr if FiW9SAPx7J0ym1ED else EsCplGc5N4mBuYW0RVQt6b
		if R87NZgODb1jyuxBAScelVivtP2:
			WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setArt({'icon':R87NZgODb1jyuxBAScelVivtP2,'thumb':R87NZgODb1jyuxBAScelVivtP2,'fanart':R87NZgODb1jyuxBAScelVivtP2,'banner':R87NZgODb1jyuxBAScelVivtP2,'clearart':R87NZgODb1jyuxBAScelVivtP2,'poster':R87NZgODb1jyuxBAScelVivtP2,'clearlogo':R87NZgODb1jyuxBAScelVivtP2,'landscape':R87NZgODb1jyuxBAScelVivtP2})
			WP45EOoSs9e1mRQpiNcKMhG8L = LhFAGlQ19zr
		elif not WP45EOoSs9e1mRQpiNcKMhG8L:
			WP45EOoSs9e1mRQpiNcKMhG8L = EsCplGc5N4mBuYW0RVQt6b
			z36flodJVD9jWxip14Rh = bNHEp28wg51k(LhFAGlQ19zr,z36flodJVD9jWxip14Rh)
			z36flodJVD9jWxip14Rh = KaUrpGJVDF470YloiwbH69tqmXyuOT(z36flodJVD9jWxip14Rh)
			TTpv6E1LbSU = z36flodJVD9jWxip14Rh+'.png'
			LNnExIRBDFhTiHX2kpYCcV68w = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.join(sEkR0OpMcrbKNqgDYu6,TTpv6E1LbSU)
			if TTpv6E1LbSU in xeP6LdoJtC7cBYq2H:
				WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setArt({'icon':LNnExIRBDFhTiHX2kpYCcV68w,'thumb':LNnExIRBDFhTiHX2kpYCcV68w,'fanart':LNnExIRBDFhTiHX2kpYCcV68w,'banner':LNnExIRBDFhTiHX2kpYCcV68w,'clearart':LNnExIRBDFhTiHX2kpYCcV68w,'poster':LNnExIRBDFhTiHX2kpYCcV68w,'clearlogo':LNnExIRBDFhTiHX2kpYCcV68w,'landscape':LNnExIRBDFhTiHX2kpYCcV68w})
				WP45EOoSs9e1mRQpiNcKMhG8L = LhFAGlQ19zr
			elif OacXWfh5goeLPrCsldtpFu1zR8HTUw<40 and RPtpekJgG3B8Fq7axHmNu4Of0Y<=XW57OCeGnFTLQbaqdrD9zM:
				try:
					VRmNPTxY8wAzWGr1BS3oq0O = LQCAJ7wTov4OPGWsk(IbEgYMJ9dFe24sQc,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,z36flodJVD9jWxip14Rh,'menu_item','center',LhFAGlQ19zr,LNnExIRBDFhTiHX2kpYCcV68w)
					WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setArt({'icon':LNnExIRBDFhTiHX2kpYCcV68w,'thumb':LNnExIRBDFhTiHX2kpYCcV68w,'fanart':LNnExIRBDFhTiHX2kpYCcV68w,'banner':LNnExIRBDFhTiHX2kpYCcV68w,'clearart':LNnExIRBDFhTiHX2kpYCcV68w,'poster':LNnExIRBDFhTiHX2kpYCcV68w,'clearlogo':LNnExIRBDFhTiHX2kpYCcV68w,'landscape':LNnExIRBDFhTiHX2kpYCcV68w})
					OacXWfh5goeLPrCsldtpFu1zR8HTUw += BkM54Kr7Qbqn
					WP45EOoSs9e1mRQpiNcKMhG8L = LhFAGlQ19zr
					xeP6LdoJtC7cBYq2H.append(TTpv6E1LbSU)
					if OacXWfh5goeLPrCsldtpFu1zR8HTUw==hvkue2LYgiOGrtcmxszl4S8MWdnF: a6rVSjDMF87KyYINcuOP1l40Hbp('إضافة الكتابة لصور القائمة','انتظار',uUqrNPcXKBoQ0slv=500)
				except: RPtpekJgG3B8Fq7axHmNu4Of0Y += BkM54Kr7Qbqn
		if WP45EOoSs9e1mRQpiNcKMhG8L:
			WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setArt({'icon':iZQGOpLhl4f,'thumb':iZQGOpLhl4f,'fanart':iZQGOpLhl4f,'banner':iZQGOpLhl4f,'clearart':iZQGOpLhl4f,'poster':iZQGOpLhl4f,'clearlogo':iZQGOpLhl4f,'landscape':iZQGOpLhl4f})
		if FpjKBIUaEwbmLkxANfs<20:
			if O4xgPbJlS8k5H1QCfXMTpIe9c3A: WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setInfo('video',{'Plot':O4xgPbJlS8k5H1QCfXMTpIe9c3A,'PlotOutline':O4xgPbJlS8k5H1QCfXMTpIe9c3A})
			if BWKE6APrGNpt0IJ1CmFaO45e79o: WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setInfo('video',{'Rating':BWKE6APrGNpt0IJ1CmFaO45e79o})
			if not R87NZgODb1jyuxBAScelVivtP2:
				WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setInfo('video',{'Title':z36flodJVD9jWxip14Rh})
			if ppi24CwDdH3YzVIK8BUyLluQJEMW=='video':
				WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setInfo('video',{'mediatype':'tvshow'})
				if WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA: WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setInfo('video',{'duration':WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA})
				WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setProperty('IsPlayable','true')
		else:
			iBCR7YKAXErp365MyeD8ohZljbaV4 = WAnCsgODVJawLrbt07PYIvmjBHRUuQ.getVideoInfoTag()
			if BWKE6APrGNpt0IJ1CmFaO45e79o: iBCR7YKAXErp365MyeD8ohZljbaV4.setRating(float(BWKE6APrGNpt0IJ1CmFaO45e79o))
			if not R87NZgODb1jyuxBAScelVivtP2:
				iBCR7YKAXErp365MyeD8ohZljbaV4.setTitle(z36flodJVD9jWxip14Rh)
			if ppi24CwDdH3YzVIK8BUyLluQJEMW=='video':
				iBCR7YKAXErp365MyeD8ohZljbaV4.setMediaType('tvshow')
				if WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA: iBCR7YKAXErp365MyeD8ohZljbaV4.setDuration(WmDIuqRL3riSEo8U6Z2fwVvBeyjPQA)
				WAnCsgODVJawLrbt07PYIvmjBHRUuQ.setProperty('IsPlayable','true')
		SKxTLvhEJZDraq3eyfXHbGgpcYNlu.append((riOKvW35nX6fZHc,WAnCsgODVJawLrbt07PYIvmjBHRUuQ,lvnKExAVBt3FCXL4aygYkPjr671q))
	ySNqmb2Ih3.setContent(oqnaT0F83OCGAY5jute6rJ2U,'tvshows')
	d0v4D7xMX8hugja = ySNqmb2Ih3.addDirectoryItems(oqnaT0F83OCGAY5jute6rJ2U,SKxTLvhEJZDraq3eyfXHbGgpcYNlu)
	ySNqmb2Ih3.endOfDirectory(oqnaT0F83OCGAY5jute6rJ2U,PDe9Y0d4kKrAX5HSChOumGZFVqU8,Ip2njyFr9ZbOHaNP,YOlndMWkJ7UAbpi)
	return d0v4D7xMX8hugja
def OZD1l4pAMzeH(ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2=fy8iFgEkrO12NR9TWBI35sjY6qHvV,yy7dsVqg23CI5tbjXlwWmOe=fy8iFgEkrO12NR9TWBI35sjY6qHvV,YMaiHbnIThsP7q=fy8iFgEkrO12NR9TWBI35sjY6qHvV,R5gQk0ZcerYx3B=fy8iFgEkrO12NR9TWBI35sjY6qHvV,IYUEhjmyOzv40iCgxeN8JDPW={}):
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('\t',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	eEncXMVB2rNg4JObl3utYfj = eEncXMVB2rNg4JObl3utYfj.replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace('\t',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	if '_SCRIPT_' in z36flodJVD9jWxip14Rh:
		x5TvLsPECHUoaqg1Dl3GwJj,z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.split('_SCRIPT_',BkM54Kr7Qbqn)
		if x5TvLsPECHUoaqg1Dl3GwJj not in list(I4t9qonjrm.menuItemsDICT.keys()): I4t9qonjrm.menuItemsDICT[x5TvLsPECHUoaqg1Dl3GwJj] = []
		I4t9qonjrm.menuItemsDICT[x5TvLsPECHUoaqg1Dl3GwJj].append([ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW])
	I4t9qonjrm.menuItemsLIST.append([ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW])
	return
def IVcCL3aAfU9wS7kWev1g2XBjZRJ(UUHB6V42eshEyz):
	if jTDWgftK7NEmx0JAkOn2aRIvweq: from html import unescape as _fJRipdgcwExUFmC109ZNLah
	else:
		from HTMLParser import HTMLParser as Ul8f7eM4jOYW
		_fJRipdgcwExUFmC109ZNLah = Ul8f7eM4jOYW().unescape
	if '&' in UUHB6V42eshEyz and ';' in UUHB6V42eshEyz:
		if gZlSEJaXO9F461AL3sR7rWNpqf: UUHB6V42eshEyz = UUHB6V42eshEyz.decode(Tk9eH2qw6Brsuhj)
		UUHB6V42eshEyz = _fJRipdgcwExUFmC109ZNLah(UUHB6V42eshEyz)
		if gZlSEJaXO9F461AL3sR7rWNpqf: UUHB6V42eshEyz = UUHB6V42eshEyz.encode(Tk9eH2qw6Brsuhj)
	return UUHB6V42eshEyz
def XXcPiylRDh6IapYA25rwO8u(UUHB6V42eshEyz):
	if '\\u' in UUHB6V42eshEyz:
		if gZlSEJaXO9F461AL3sR7rWNpqf: UUHB6V42eshEyz = UUHB6V42eshEyz.decode('unicode_escape','ignore').encode(Tk9eH2qw6Brsuhj)
		elif jTDWgftK7NEmx0JAkOn2aRIvweq: UUHB6V42eshEyz = UUHB6V42eshEyz.encode(Tk9eH2qw6Brsuhj).decode('unicode_escape','ignore')
	return UUHB6V42eshEyz
def TatKxLsejrR2oud(PPYsGnihBt7CNro6HQ3v,QFEGdmaCnsfZLzO4N7r2Bv,yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,faOeL3m2uJHx6oqZyW9Qik,YMaiHbnIThsP7q,uDFLvOcQfI1R9dizXyqZ7lB,q38Y7FSHrJmfiv1PA0Ook,BCO0yTNa4Ipos8MmjWEAd357,HCJcypWV9M7flmkoQOUtu):
	wq45N8UxAv10s = HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.dirname(HCJcypWV9M7flmkoQOUtu)
	if not HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(wq45N8UxAv10s):
		try: HoxKENAey2MdTt9kDUrVnWGLS0CPa.makedirs(wq45N8UxAv10s)
		except: pass
	k5RvmQhHqMG62UnPXFIVLd0zsSBAW1 = KyxQE4ih9vj6maAdInWLHoSrzp7DBG(uDFLvOcQfI1R9dizXyqZ7lB)
	VRmNPTxY8wAzWGr1BS3oq0O = LQCAJ7wTov4OPGWsk(k5RvmQhHqMG62UnPXFIVLd0zsSBAW1,PPYsGnihBt7CNro6HQ3v,QFEGdmaCnsfZLzO4N7r2Bv,yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,faOeL3m2uJHx6oqZyW9Qik,YMaiHbnIThsP7q,uDFLvOcQfI1R9dizXyqZ7lB,q38Y7FSHrJmfiv1PA0Ook,BCO0yTNa4Ipos8MmjWEAd357,HCJcypWV9M7flmkoQOUtu)
	return VRmNPTxY8wAzWGr1BS3oq0O
def KyxQE4ih9vj6maAdInWLHoSrzp7DBG(uDFLvOcQfI1R9dizXyqZ7lB):
	GK3cZCvrW2sVfEtpi5aqmM = hvkue2LYgiOGrtcmxszl4S8MWdnF
	Vqfyaeb3CIT1pdvzu = 20
	UoAetCn0SyOxhl = 20
	T4tEJRhe5N8V6F = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	UUh23ru8qEYPkRWtVSem = 'center'
	JREBywWaz7gUep1qXSrt269msPI = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	hHkvKZM57DwxTizjXUBFnoqY = 19
	uumedOv5rqk = 30
	hq5XE063rZkV = 8
	Iwq1VrCJWDodzPtb7 = EsCplGc5N4mBuYW0RVQt6b
	FFpC9QeS2hEIGT = 375
	kGjptdqgIfyU5H1AnNVZi9lavX0 = 410
	as1uNxfUwmTF9D4qEI7M5kWgbliOL = 50
	ulNVg6WiFHMQCrnqzjT75OBYw3S4b = 280
	kEbs6eFwA5qrm1njKvDHUd = 28
	Kb6DVFdMrXZ2IoRH = hvkue2LYgiOGrtcmxszl4S8MWdnF
	WOSpvB3KurUC71458EMzAdDb = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	AXSPB0L1FM5urnjvhRCsigq = 31
	QQpGRq1mDgCa9ZScFPO = [36,32,28]
	from PIL import ImageDraw as pVB317Nv06HPyi8OFRkJElYo,ImageFont as SeQkx1wz6Ty7nAv,Image as VfeG4QI1uNXFMDpjrWgn
	if 'notification' in uDFLvOcQfI1R9dizXyqZ7lB:
		if uDFLvOcQfI1R9dizXyqZ7lB=='notification_regular':
			j3er2yN6AFBzsi50Zcn1Eth = 117
			UUh23ru8qEYPkRWtVSem = 'left'
			Iwq1VrCJWDodzPtb7 = LhFAGlQ19zr
		elif uDFLvOcQfI1R9dizXyqZ7lB=='notification_auto':
			j3er2yN6AFBzsi50Zcn1Eth = 'UPPER'
			UUh23ru8qEYPkRWtVSem = 'right'
			T4tEJRhe5N8V6F = 10
		oF7GtNRWbfImnAjMx06Qr = 720
		QQpGRq1mDgCa9ZScFPO = [33,33,33]
		UoAetCn0SyOxhl = 20
		Vqfyaeb3CIT1pdvzu = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		uumedOv5rqk = 20
		hHkvKZM57DwxTizjXUBFnoqY = 35
	elif uDFLvOcQfI1R9dizXyqZ7lB=='menu_item':
		QQpGRq1mDgCa9ZScFPO,oF7GtNRWbfImnAjMx06Qr,j3er2yN6AFBzsi50Zcn1Eth = [28,28,28],200,250
		JREBywWaz7gUep1qXSrt269msPI,uumedOv5rqk,hHkvKZM57DwxTizjXUBFnoqY, = D2D96X5NGamBhrFwvL8VEbqiSfZIl,-12,-30
		Vqfyaeb3CIT1pdvzu = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		q4IpnHLQ2BFlioX8TtSj = VfeG4QI1uNXFMDpjrWgn.open(iZQGOpLhl4f)
		mo02jitrApPkFT1uyn6wxKz3SNa = VfeG4QI1uNXFMDpjrWgn.new('RGBA',(oF7GtNRWbfImnAjMx06Qr,j3er2yN6AFBzsi50Zcn1Eth),(255,D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl,255))
	elif uDFLvOcQfI1R9dizXyqZ7lB=='confirm_smallfont': QQpGRq1mDgCa9ZScFPO,j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = [28,24,20],500,900
	elif uDFLvOcQfI1R9dizXyqZ7lB=='confirm_mediumfont': QQpGRq1mDgCa9ZScFPO,j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = [32,28,24],500,900
	elif uDFLvOcQfI1R9dizXyqZ7lB=='confirm_bigfont': QQpGRq1mDgCa9ZScFPO,j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = [36,32,28],500,900
	elif uDFLvOcQfI1R9dizXyqZ7lB=='textview_bigfont': j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = 740,1270
	elif uDFLvOcQfI1R9dizXyqZ7lB=='textview_bigfont_long': j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = 'UPPER',1270
	elif uDFLvOcQfI1R9dizXyqZ7lB=='textview_smallfont': QQpGRq1mDgCa9ZScFPO,j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = [28,23,18],740,1270
	elif uDFLvOcQfI1R9dizXyqZ7lB=='textview_smallfont_long': QQpGRq1mDgCa9ZScFPO,j3er2yN6AFBzsi50Zcn1Eth,oF7GtNRWbfImnAjMx06Qr = [28,23,18],'UPPER',1270
	HHGoEJSL5Xe1hNyW7t,rrD8RSM6VOcyECaG,ne6IqTRKNjD2EfpZGHlmXJg = QQpGRq1mDgCa9ZScFPO
	ee3CKRw6LMjJ0GB5mlNXozq = SeQkx1wz6Ty7nAv.truetype(nBM8FATasf6jo,size=HHGoEJSL5Xe1hNyW7t)
	dK7H25NZhit1 = SeQkx1wz6Ty7nAv.truetype(nBM8FATasf6jo,size=rrD8RSM6VOcyECaG)
	nntsd3Ac7HxR = SeQkx1wz6Ty7nAv.truetype(nBM8FATasf6jo,size=ne6IqTRKNjD2EfpZGHlmXJg)
	d5QSBFcHUTaMN = oF7GtNRWbfImnAjMx06Qr-uumedOv5rqk*teaC5j4HuGDqpwcmUzJ
	J3ZvTbghtsO1SYD4nLUacq0pjQ = VfeG4QI1uNXFMDpjrWgn.new('RGBA',(d5QSBFcHUTaMN,100),(255,255,255,D2D96X5NGamBhrFwvL8VEbqiSfZIl))
	MU7wbrgSopOkZvYhGXC = pVB317Nv06HPyi8OFRkJElYo.Draw(J3ZvTbghtsO1SYD4nLUacq0pjQ)
	Gz648biYNDoe,wEYurxGKOCI5l3NW2cSsAbz98 = MU7wbrgSopOkZvYhGXC.textsize('HHH BBB 888 000',font=ee3CKRw6LMjJ0GB5mlNXozq)
	zZe92X8cbFl5jC4TIogP0dHYkS,cOLbK1mG528TptJ = MU7wbrgSopOkZvYhGXC.textsize('HHH BBB 888 000',font=dK7H25NZhit1)
	MH0e5SGyvo3RwnYkuCr4 = {'delete_harakat':LhFAGlQ19zr,'support_ligatures':EsCplGc5N4mBuYW0RVQt6b,'ARABIC LIGATURE ALLAH':LhFAGlQ19zr}
	from arabic_reshaper import ArabicReshaper as BBXrmw59KEQCZcdtSN4IbvnOYW
	ogb8V7AmLipDvnR = BBXrmw59KEQCZcdtSN4IbvnOYW(configuration=MH0e5SGyvo3RwnYkuCr4)
	k5RvmQhHqMG62UnPXFIVLd0zsSBAW1 = {}
	NTlQij7AoUh3dL8Kpu5HfO0DSC = locals()
	for ZYo1OtjRwCc2eAlK in NTlQij7AoUh3dL8Kpu5HfO0DSC: k5RvmQhHqMG62UnPXFIVLd0zsSBAW1[ZYo1OtjRwCc2eAlK] = NTlQij7AoUh3dL8Kpu5HfO0DSC[ZYo1OtjRwCc2eAlK]
	return k5RvmQhHqMG62UnPXFIVLd0zsSBAW1
def LQCAJ7wTov4OPGWsk(k5RvmQhHqMG62UnPXFIVLd0zsSBAW1,PPYsGnihBt7CNro6HQ3v,QFEGdmaCnsfZLzO4N7r2Bv,yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,faOeL3m2uJHx6oqZyW9Qik,YMaiHbnIThsP7q,uDFLvOcQfI1R9dizXyqZ7lB,q38Y7FSHrJmfiv1PA0Ook,BCO0yTNa4Ipos8MmjWEAd357,HCJcypWV9M7flmkoQOUtu):
	for ZYo1OtjRwCc2eAlK in k5RvmQhHqMG62UnPXFIVLd0zsSBAW1: globals()[ZYo1OtjRwCc2eAlK] = k5RvmQhHqMG62UnPXFIVLd0zsSBAW1[ZYo1OtjRwCc2eAlK]
	global kEbs6eFwA5qrm1njKvDHUd,Kb6DVFdMrXZ2IoRH
	if uDFLvOcQfI1R9dizXyqZ7lB!='menu_item':
		nnQqRHLtEG7JgFcASpXfUBx3zOm = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.translate')
		if nnQqRHLtEG7JgFcASpXfUBx3zOm:
			if PPYsGnihBt7CNro6HQ3v=='نعم  Yes': PPYsGnihBt7CNro6HQ3v = 'Yes'
			elif PPYsGnihBt7CNro6HQ3v=='كلا  No': PPYsGnihBt7CNro6HQ3v = 'No'
			if QFEGdmaCnsfZLzO4N7r2Bv=='نعم  Yes': QFEGdmaCnsfZLzO4N7r2Bv = 'Yes'
			elif QFEGdmaCnsfZLzO4N7r2Bv=='كلا  No': QFEGdmaCnsfZLzO4N7r2Bv = 'No'
			if yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f=='نعم  Yes': yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f = 'Yes'
			elif yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f=='كلا  No': yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f = 'No'
			J5eBhfvXYF20DAOqs7L8l3KaR1 = IVLwJP9fsAklSmWKOa([PPYsGnihBt7CNro6HQ3v,QFEGdmaCnsfZLzO4N7r2Bv,yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,faOeL3m2uJHx6oqZyW9Qik,YMaiHbnIThsP7q])
			if J5eBhfvXYF20DAOqs7L8l3KaR1: PPYsGnihBt7CNro6HQ3v,QFEGdmaCnsfZLzO4N7r2Bv,yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,faOeL3m2uJHx6oqZyW9Qik,YMaiHbnIThsP7q = J5eBhfvXYF20DAOqs7L8l3KaR1
	if gZlSEJaXO9F461AL3sR7rWNpqf:
		YMaiHbnIThsP7q = YMaiHbnIThsP7q.decode(Tk9eH2qw6Brsuhj)
		faOeL3m2uJHx6oqZyW9Qik = faOeL3m2uJHx6oqZyW9Qik.decode(Tk9eH2qw6Brsuhj)
		PPYsGnihBt7CNro6HQ3v = PPYsGnihBt7CNro6HQ3v.decode(Tk9eH2qw6Brsuhj)
		QFEGdmaCnsfZLzO4N7r2Bv = QFEGdmaCnsfZLzO4N7r2Bv.decode(Tk9eH2qw6Brsuhj)
		yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f = yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f.decode(Tk9eH2qw6Brsuhj)
	SA1xDH5L2ZWdfYnJ = faOeL3m2uJHx6oqZyW9Qik.count(C0qrknitpM4Z)+BkM54Kr7Qbqn
	jZqgJKOEa8spFhH35CBVwr = Vqfyaeb3CIT1pdvzu+SA1xDH5L2ZWdfYnJ*(wEYurxGKOCI5l3NW2cSsAbz98+T4tEJRhe5N8V6F)-T4tEJRhe5N8V6F
	if YMaiHbnIThsP7q:
		o4ZNyKCBSVqtEMc2djFrLg = cOLbK1mG528TptJ+hq5XE063rZkV
		p9mPWB12JDxClHYUv = ogb8V7AmLipDvnR.reshape(YMaiHbnIThsP7q)
		if Iwq1VrCJWDodzPtb7:
			FF1b7XxzRK5MEyeOwYA = j6tevVDqrT0ONcmh3uHlU72A91(MU7wbrgSopOkZvYhGXC,dK7H25NZhit1,p9mPWB12JDxClHYUv,rrD8RSM6VOcyECaG,d5QSBFcHUTaMN,o4ZNyKCBSVqtEMc2djFrLg)
			dAHcTxhCnWgObSztPpQ6al = x2cf7vHnGXz4Wj6DZpFVUL(FF1b7XxzRK5MEyeOwYA)
			sOZLEnpQjI53ve916z8wi4PmhKC = dAHcTxhCnWgObSztPpQ6al.count(C0qrknitpM4Z)+BkM54Kr7Qbqn
			GGqdvWNKcULSE7lZenaC6A1FTzs4 = hHkvKZM57DwxTizjXUBFnoqY+sOZLEnpQjI53ve916z8wi4PmhKC*o4ZNyKCBSVqtEMc2djFrLg-hq5XE063rZkV
		else:
			GGqdvWNKcULSE7lZenaC6A1FTzs4 = hHkvKZM57DwxTizjXUBFnoqY+cOLbK1mG528TptJ
			dAHcTxhCnWgObSztPpQ6al = p9mPWB12JDxClHYUv.split(C0qrknitpM4Z)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			FF1b7XxzRK5MEyeOwYA = p9mPWB12JDxClHYUv.split(C0qrknitpM4Z)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
	else: GGqdvWNKcULSE7lZenaC6A1FTzs4 = hHkvKZM57DwxTizjXUBFnoqY
	yw0GsnoW9htPzde6fISMu2NjCHv = WOSpvB3KurUC71458EMzAdDb+AXSPB0L1FM5urnjvhRCsigq
	if BCO0yTNa4Ipos8MmjWEAd357:
		XvTFrbOqSA4zjZkQaYg01M58i = kGjptdqgIfyU5H1AnNVZi9lavX0-FFpC9QeS2hEIGT
		yw0GsnoW9htPzde6fISMu2NjCHv += XvTFrbOqSA4zjZkQaYg01M58i
	else: XvTFrbOqSA4zjZkQaYg01M58i = D2D96X5NGamBhrFwvL8VEbqiSfZIl
	if PPYsGnihBt7CNro6HQ3v or QFEGdmaCnsfZLzO4N7r2Bv or yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f: yw0GsnoW9htPzde6fISMu2NjCHv += as1uNxfUwmTF9D4qEI7M5kWgbliOL
	VRmNPTxY8wAzWGr1BS3oq0O = j3er2yN6AFBzsi50Zcn1Eth if j3er2yN6AFBzsi50Zcn1Eth!='UPPER' else jZqgJKOEa8spFhH35CBVwr+GGqdvWNKcULSE7lZenaC6A1FTzs4+yw0GsnoW9htPzde6fISMu2NjCHv
	J3ZvTbghtsO1SYD4nLUacq0pjQ = VfeG4QI1uNXFMDpjrWgn.new('RGBA',(oF7GtNRWbfImnAjMx06Qr,VRmNPTxY8wAzWGr1BS3oq0O),(255,255,255,D2D96X5NGamBhrFwvL8VEbqiSfZIl))
	cJfEmzjwRqVIC35ls2b = pVB317Nv06HPyi8OFRkJElYo.Draw(J3ZvTbghtsO1SYD4nLUacq0pjQ)
	GGYEQ45RUmjS2TzH = VRmNPTxY8wAzWGr1BS3oq0O-jZqgJKOEa8spFhH35CBVwr-yw0GsnoW9htPzde6fISMu2NjCHv-hHkvKZM57DwxTizjXUBFnoqY
	if not QFEGdmaCnsfZLzO4N7r2Bv and PPYsGnihBt7CNro6HQ3v and yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f:
		kEbs6eFwA5qrm1njKvDHUd += 105
		Kb6DVFdMrXZ2IoRH -= 110
	import bidi.algorithm as n5nhyxsWuCGNpLR
	if faOeL3m2uJHx6oqZyW9Qik:
		QuCcpSz9gDr7hai2 = Vqfyaeb3CIT1pdvzu
		faOeL3m2uJHx6oqZyW9Qik = n5nhyxsWuCGNpLR.get_display(ogb8V7AmLipDvnR.reshape(faOeL3m2uJHx6oqZyW9Qik))
		LZhBxTSy4qP7zKIbGw = faOeL3m2uJHx6oqZyW9Qik.splitlines()
		for gSUZXf3r57Bzeq in LZhBxTSy4qP7zKIbGw:
			if gSUZXf3r57Bzeq:
				R9fGZknCX4Srq3,vxSG7WzaUyEMV3bc = cJfEmzjwRqVIC35ls2b.textsize(gSUZXf3r57Bzeq,font=ee3CKRw6LMjJ0GB5mlNXozq)
				if UUh23ru8qEYPkRWtVSem=='center': h1gSWfQk8BxopwK7Y50IRE = GK3cZCvrW2sVfEtpi5aqmM+(oF7GtNRWbfImnAjMx06Qr-R9fGZknCX4Srq3)/teaC5j4HuGDqpwcmUzJ
				elif UUh23ru8qEYPkRWtVSem=='right': h1gSWfQk8BxopwK7Y50IRE = GK3cZCvrW2sVfEtpi5aqmM+oF7GtNRWbfImnAjMx06Qr-R9fGZknCX4Srq3-UoAetCn0SyOxhl
				elif UUh23ru8qEYPkRWtVSem=='left': h1gSWfQk8BxopwK7Y50IRE = GK3cZCvrW2sVfEtpi5aqmM+UoAetCn0SyOxhl
				cJfEmzjwRqVIC35ls2b.text((h1gSWfQk8BxopwK7Y50IRE,QuCcpSz9gDr7hai2),gSUZXf3r57Bzeq,font=ee3CKRw6LMjJ0GB5mlNXozq,fill='yellow')
			QuCcpSz9gDr7hai2 += HHGoEJSL5Xe1hNyW7t+T4tEJRhe5N8V6F
	if PPYsGnihBt7CNro6HQ3v or QFEGdmaCnsfZLzO4N7r2Bv or yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f:
		hATKwnoNqWMfz7ctU4vRIYL5 = jZqgJKOEa8spFhH35CBVwr+GGYEQ45RUmjS2TzH+hHkvKZM57DwxTizjXUBFnoqY+XvTFrbOqSA4zjZkQaYg01M58i+WOSpvB3KurUC71458EMzAdDb
		if PPYsGnihBt7CNro6HQ3v:
			PPYsGnihBt7CNro6HQ3v = n5nhyxsWuCGNpLR.get_display(ogb8V7AmLipDvnR.reshape(PPYsGnihBt7CNro6HQ3v))
			oxP6njKhiV,opaOYq4cUflykQ2WN07d9ME = cJfEmzjwRqVIC35ls2b.textsize(PPYsGnihBt7CNro6HQ3v,font=nntsd3Ac7HxR)
			ZVbFx4HEALX2ij = kEbs6eFwA5qrm1njKvDHUd+D2D96X5NGamBhrFwvL8VEbqiSfZIl*(Kb6DVFdMrXZ2IoRH+ulNVg6WiFHMQCrnqzjT75OBYw3S4b)+(ulNVg6WiFHMQCrnqzjT75OBYw3S4b-oxP6njKhiV)/teaC5j4HuGDqpwcmUzJ
			cJfEmzjwRqVIC35ls2b.text((ZVbFx4HEALX2ij,hATKwnoNqWMfz7ctU4vRIYL5),PPYsGnihBt7CNro6HQ3v,font=nntsd3Ac7HxR,fill='yellow')
		if QFEGdmaCnsfZLzO4N7r2Bv:
			QFEGdmaCnsfZLzO4N7r2Bv = n5nhyxsWuCGNpLR.get_display(ogb8V7AmLipDvnR.reshape(QFEGdmaCnsfZLzO4N7r2Bv))
			VjlN34CWJQhRxkcvPHmpO1Ugd,qr82SBzVDFIJeEYPgWATcNKMvx6km0 = cJfEmzjwRqVIC35ls2b.textsize(QFEGdmaCnsfZLzO4N7r2Bv,font=nntsd3Ac7HxR)
			TyluVizJrOjxPW5dkhs1BGpc0E68M = kEbs6eFwA5qrm1njKvDHUd+BkM54Kr7Qbqn*(Kb6DVFdMrXZ2IoRH+ulNVg6WiFHMQCrnqzjT75OBYw3S4b)+(ulNVg6WiFHMQCrnqzjT75OBYw3S4b-VjlN34CWJQhRxkcvPHmpO1Ugd)/teaC5j4HuGDqpwcmUzJ
			cJfEmzjwRqVIC35ls2b.text((TyluVizJrOjxPW5dkhs1BGpc0E68M,hATKwnoNqWMfz7ctU4vRIYL5),QFEGdmaCnsfZLzO4N7r2Bv,font=nntsd3Ac7HxR,fill='yellow')
		if yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f:
			yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f = n5nhyxsWuCGNpLR.get_display(ogb8V7AmLipDvnR.reshape(yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f))
			zpdnGCuqxh,d5MPybHL4W = cJfEmzjwRqVIC35ls2b.textsize(yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,font=nntsd3Ac7HxR)
			ppHsARSVDTvfxn9N5WqmP2dZaLi = kEbs6eFwA5qrm1njKvDHUd+teaC5j4HuGDqpwcmUzJ*(Kb6DVFdMrXZ2IoRH+ulNVg6WiFHMQCrnqzjT75OBYw3S4b)+(ulNVg6WiFHMQCrnqzjT75OBYw3S4b-zpdnGCuqxh)/teaC5j4HuGDqpwcmUzJ
			cJfEmzjwRqVIC35ls2b.text((ppHsARSVDTvfxn9N5WqmP2dZaLi,hATKwnoNqWMfz7ctU4vRIYL5),yyQ4RTGNOX0aCp8vcqei6AdJtVFw7f,font=nntsd3Ac7HxR,fill='yellow')
	if YMaiHbnIThsP7q:
		siyNGxHez7Dq4u,HpXLiYmUMh = [],[]
		FF1b7XxzRK5MEyeOwYA = XF1bDyNkBtjoagmJYP2OflG(FF1b7XxzRK5MEyeOwYA)
		CkqzjOVXLU = FF1b7XxzRK5MEyeOwYA.split('_sss__newline_')
		for mg4yactZWPAbID in CkqzjOVXLU:
			BadiUc72kyHGj = q38Y7FSHrJmfiv1PA0Ook
			if   '_sss__lineleft_' in mg4yactZWPAbID: BadiUc72kyHGj = 'left'
			elif '_sss__lineright_' in mg4yactZWPAbID: BadiUc72kyHGj = 'right'
			elif '_sss__linecenter_' in mg4yactZWPAbID: BadiUc72kyHGj = 'center'
			NW5wP0f4yFgrx2 = mg4yactZWPAbID
			TIx8VFBhifCM1zP = EcQxOa3RJm86WjTKA.findall('_sss__.*?_',mg4yactZWPAbID,EcQxOa3RJm86WjTKA.DOTALL)
			for euKgoVvDHxISNMO5yPn8FcRfQ46L in TIx8VFBhifCM1zP: NW5wP0f4yFgrx2 = NW5wP0f4yFgrx2.replace(euKgoVvDHxISNMO5yPn8FcRfQ46L,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			if NW5wP0f4yFgrx2==fy8iFgEkrO12NR9TWBI35sjY6qHvV: R9fGZknCX4Srq3,vxSG7WzaUyEMV3bc = D2D96X5NGamBhrFwvL8VEbqiSfZIl,o4ZNyKCBSVqtEMc2djFrLg
			else: R9fGZknCX4Srq3,vxSG7WzaUyEMV3bc = cJfEmzjwRqVIC35ls2b.textsize(NW5wP0f4yFgrx2,font=dK7H25NZhit1)
			if   BadiUc72kyHGj=='left': Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi = JREBywWaz7gUep1qXSrt269msPI+uumedOv5rqk
			elif BadiUc72kyHGj=='right': Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi = JREBywWaz7gUep1qXSrt269msPI+uumedOv5rqk+d5QSBFcHUTaMN-R9fGZknCX4Srq3
			elif BadiUc72kyHGj=='center': Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi = JREBywWaz7gUep1qXSrt269msPI+uumedOv5rqk+(d5QSBFcHUTaMN-R9fGZknCX4Srq3)/teaC5j4HuGDqpwcmUzJ
			if Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi<uumedOv5rqk: Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi = JREBywWaz7gUep1qXSrt269msPI+uumedOv5rqk
			siyNGxHez7Dq4u.append(Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi)
			HpXLiYmUMh.append(R9fGZknCX4Srq3)
		Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi = siyNGxHez7Dq4u[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		OCQbtrkV5Te49yDsluNRw = FF1b7XxzRK5MEyeOwYA.split('_sss_')
		X5eNUhPGEKuDOxvci = (255,255,255,255)
		orHvjKeYd3ql2J8FuC1ZMn5WbX7mf = X5eNUhPGEKuDOxvci
		haDc3VPXzrUQJolwiSvLfk9RApj56,Io7F1gdw4avfq5HRU0JKQrNVTPbE = D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl
		Lmw9VRFKglHWCQB = LhFAGlQ19zr
		jMr0L6OHtmKhpBliC = D2D96X5NGamBhrFwvL8VEbqiSfZIl
		ayWTh8GrLYO = jZqgJKOEa8spFhH35CBVwr+hHkvKZM57DwxTizjXUBFnoqY/teaC5j4HuGDqpwcmUzJ
		if GGqdvWNKcULSE7lZenaC6A1FTzs4<(GGYEQ45RUmjS2TzH+hHkvKZM57DwxTizjXUBFnoqY):
			Vn2OD7N18FWjcTRzuaZ = (GGYEQ45RUmjS2TzH+hHkvKZM57DwxTizjXUBFnoqY-GGqdvWNKcULSE7lZenaC6A1FTzs4)/teaC5j4HuGDqpwcmUzJ
			ayWTh8GrLYO = jZqgJKOEa8spFhH35CBVwr+hHkvKZM57DwxTizjXUBFnoqY+Vn2OD7N18FWjcTRzuaZ-cOLbK1mG528TptJ/teaC5j4HuGDqpwcmUzJ
		for gSUZXf3r57Bzeq in OCQbtrkV5Te49yDsluNRw:
			if not gSUZXf3r57Bzeq or (gSUZXf3r57Bzeq and ord(gSUZXf3r57Bzeq[D2D96X5NGamBhrFwvL8VEbqiSfZIl])==65279): continue
			ungbxWAUhYXzJKjirdfB5OH7y = gSUZXf3r57Bzeq.split('_newline_',BkM54Kr7Qbqn)
			bExC38tGewpXmTlia70VfQuy = gSUZXf3r57Bzeq.split('_newcolor',BkM54Kr7Qbqn)
			mul7f0hN26ydPjepgko3UCwQWc = gSUZXf3r57Bzeq.split('_endcolor_',BkM54Kr7Qbqn)
			UxZsBLGngHQq = gSUZXf3r57Bzeq.split('_linertl_',BkM54Kr7Qbqn)
			itmh3BaZbpODnL0KH4IvW5Ulkq = gSUZXf3r57Bzeq.split('_lineleft_',BkM54Kr7Qbqn)
			zQoiOYj1pNEHw79VvhB2euGMdZLU = gSUZXf3r57Bzeq.split('_lineright_',BkM54Kr7Qbqn)
			PCI8wvKQgOrz0ZA4 = gSUZXf3r57Bzeq.split('_linecenter_',BkM54Kr7Qbqn)
			if len(ungbxWAUhYXzJKjirdfB5OH7y)>BkM54Kr7Qbqn:
				jMr0L6OHtmKhpBliC += BkM54Kr7Qbqn
				gSUZXf3r57Bzeq = ungbxWAUhYXzJKjirdfB5OH7y[BkM54Kr7Qbqn]
				haDc3VPXzrUQJolwiSvLfk9RApj56 = D2D96X5NGamBhrFwvL8VEbqiSfZIl
				Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi = siyNGxHez7Dq4u[jMr0L6OHtmKhpBliC]
				Io7F1gdw4avfq5HRU0JKQrNVTPbE += o4ZNyKCBSVqtEMc2djFrLg
				Lmw9VRFKglHWCQB = LhFAGlQ19zr
			elif len(bExC38tGewpXmTlia70VfQuy)>BkM54Kr7Qbqn:
				gSUZXf3r57Bzeq = bExC38tGewpXmTlia70VfQuy[BkM54Kr7Qbqn]
				orHvjKeYd3ql2J8FuC1ZMn5WbX7mf = gSUZXf3r57Bzeq[D2D96X5NGamBhrFwvL8VEbqiSfZIl:8]
				orHvjKeYd3ql2J8FuC1ZMn5WbX7mf = '#'+orHvjKeYd3ql2J8FuC1ZMn5WbX7mf[teaC5j4HuGDqpwcmUzJ:]
				gSUZXf3r57Bzeq = gSUZXf3r57Bzeq[9:]
			elif len(mul7f0hN26ydPjepgko3UCwQWc)>BkM54Kr7Qbqn:
				gSUZXf3r57Bzeq = mul7f0hN26ydPjepgko3UCwQWc[BkM54Kr7Qbqn]
				orHvjKeYd3ql2J8FuC1ZMn5WbX7mf = X5eNUhPGEKuDOxvci
			elif len(UxZsBLGngHQq)>BkM54Kr7Qbqn:
				gSUZXf3r57Bzeq = UxZsBLGngHQq[BkM54Kr7Qbqn]
				Lmw9VRFKglHWCQB = EsCplGc5N4mBuYW0RVQt6b
				haDc3VPXzrUQJolwiSvLfk9RApj56 = HpXLiYmUMh[jMr0L6OHtmKhpBliC]
			elif len(itmh3BaZbpODnL0KH4IvW5Ulkq)>1: gSUZXf3r57Bzeq = itmh3BaZbpODnL0KH4IvW5Ulkq[BkM54Kr7Qbqn]
			elif len(zQoiOYj1pNEHw79VvhB2euGMdZLU)>1: gSUZXf3r57Bzeq = zQoiOYj1pNEHw79VvhB2euGMdZLU[BkM54Kr7Qbqn]
			elif len(PCI8wvKQgOrz0ZA4)>1: gSUZXf3r57Bzeq = PCI8wvKQgOrz0ZA4[BkM54Kr7Qbqn]
			if gSUZXf3r57Bzeq:
				swQdbPe1UYu2CNMnZSo0H43FAtkVJT = ayWTh8GrLYO+Io7F1gdw4avfq5HRU0JKQrNVTPbE
				gSUZXf3r57Bzeq = n5nhyxsWuCGNpLR.get_display(gSUZXf3r57Bzeq)
				R9fGZknCX4Srq3,vxSG7WzaUyEMV3bc = cJfEmzjwRqVIC35ls2b.textsize(gSUZXf3r57Bzeq,font=dK7H25NZhit1)
				if Lmw9VRFKglHWCQB: haDc3VPXzrUQJolwiSvLfk9RApj56 -= R9fGZknCX4Srq3
				Pa2KqsbeI0pnSAV4fFU = Qf8ayhjT7xeGo1SwXsREIDFLnNU4zi+haDc3VPXzrUQJolwiSvLfk9RApj56
				cJfEmzjwRqVIC35ls2b.text((Pa2KqsbeI0pnSAV4fFU,swQdbPe1UYu2CNMnZSo0H43FAtkVJT),gSUZXf3r57Bzeq,font=dK7H25NZhit1,fill=orHvjKeYd3ql2J8FuC1ZMn5WbX7mf)
				if uDFLvOcQfI1R9dizXyqZ7lB=='menu_item': cJfEmzjwRqVIC35ls2b.text((Pa2KqsbeI0pnSAV4fFU+BkM54Kr7Qbqn,swQdbPe1UYu2CNMnZSo0H43FAtkVJT+BkM54Kr7Qbqn),gSUZXf3r57Bzeq,font=dK7H25NZhit1,fill=orHvjKeYd3ql2J8FuC1ZMn5WbX7mf)
				if not Lmw9VRFKglHWCQB: haDc3VPXzrUQJolwiSvLfk9RApj56 += R9fGZknCX4Srq3
				if swQdbPe1UYu2CNMnZSo0H43FAtkVJT>GGYEQ45RUmjS2TzH+o4ZNyKCBSVqtEMc2djFrLg: break
	if uDFLvOcQfI1R9dizXyqZ7lB=='menu_item':
		r7kp6NfqgaDO = q4IpnHLQ2BFlioX8TtSj.copy()
		uUqrNPcXKBoQ0slv.sleep(0.05)
		r7kp6NfqgaDO.paste(mo02jitrApPkFT1uyn6wxKz3SNa,(D2D96X5NGamBhrFwvL8VEbqiSfZIl,D2D96X5NGamBhrFwvL8VEbqiSfZIl),mask=J3ZvTbghtsO1SYD4nLUacq0pjQ)
	else: r7kp6NfqgaDO = J3ZvTbghtsO1SYD4nLUacq0pjQ
	if gZlSEJaXO9F461AL3sR7rWNpqf: HCJcypWV9M7flmkoQOUtu = HCJcypWV9M7flmkoQOUtu.decode(Tk9eH2qw6Brsuhj)
	try: r7kp6NfqgaDO.save(HCJcypWV9M7flmkoQOUtu)
	except UnicodeError:
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			HCJcypWV9M7flmkoQOUtu = HCJcypWV9M7flmkoQOUtu.encode(Tk9eH2qw6Brsuhj)
			r7kp6NfqgaDO.save(HCJcypWV9M7flmkoQOUtu)
	return VRmNPTxY8wAzWGr1BS3oq0O
def j6tevVDqrT0ONcmh3uHlU72A91(MU7wbrgSopOkZvYhGXC,dK7H25NZhit1,zMcLbhIXv2,qeQTv50pDGuOVmy,d5QSBFcHUTaMN,wPrTIz9G4ARKN6jEbqicmlak7):
	tt0aP9fmX2lOEGpsZjMdFHCDT,Q5QDz0hexvikNTKEy,SJVzDW0k1tqeYgTf3AZNI = fy8iFgEkrO12NR9TWBI35sjY6qHvV,D2D96X5NGamBhrFwvL8VEbqiSfZIl,15000
	zMcLbhIXv2 = zMcLbhIXv2.replace('[COLOR ','[COLOR:::')
	XPkQy7tFHSpZf23cvAV = d5QSBFcHUTaMN-qeQTv50pDGuOVmy*teaC5j4HuGDqpwcmUzJ
	for LLNDIRf1JQbXlGr9 in zMcLbhIXv2.splitlines():
		Q5QDz0hexvikNTKEy += wPrTIz9G4ARKN6jEbqicmlak7
		Roe0sNhMAFafjt1O62UW,p5VSHhWNOsgtJCk32fem6aD = D2D96X5NGamBhrFwvL8VEbqiSfZIl,fy8iFgEkrO12NR9TWBI35sjY6qHvV
		for rpTF1AvXuItZQqU8CnMRSDV in LLNDIRf1JQbXlGr9.split(ksJdoFWhxTz8Y2N7bOZE):
			mmSj5AptTPZ = x2cf7vHnGXz4Wj6DZpFVUL(ksJdoFWhxTz8Y2N7bOZE+rpTF1AvXuItZQqU8CnMRSDV)
			MYDWEvtx7kgyU3Vh9o6PusjK,tofK8Zmy3TUYbN9Engj7 = MU7wbrgSopOkZvYhGXC.textsize(mmSj5AptTPZ,font=dK7H25NZhit1)
			if Roe0sNhMAFafjt1O62UW+MYDWEvtx7kgyU3Vh9o6PusjK<XPkQy7tFHSpZf23cvAV:
				if not p5VSHhWNOsgtJCk32fem6aD: p5VSHhWNOsgtJCk32fem6aD += rpTF1AvXuItZQqU8CnMRSDV
				else: p5VSHhWNOsgtJCk32fem6aD += ksJdoFWhxTz8Y2N7bOZE+rpTF1AvXuItZQqU8CnMRSDV
				Roe0sNhMAFafjt1O62UW += MYDWEvtx7kgyU3Vh9o6PusjK
			else:
				if MYDWEvtx7kgyU3Vh9o6PusjK<XPkQy7tFHSpZf23cvAV:
					p5VSHhWNOsgtJCk32fem6aD += '\n '+rpTF1AvXuItZQqU8CnMRSDV
					Q5QDz0hexvikNTKEy += wPrTIz9G4ARKN6jEbqicmlak7
					Roe0sNhMAFafjt1O62UW = MYDWEvtx7kgyU3Vh9o6PusjK
				else:
					while MYDWEvtx7kgyU3Vh9o6PusjK>XPkQy7tFHSpZf23cvAV:
						for uYA2DJg3vyzpo8IHnVjZ47s in range(BkM54Kr7Qbqn,len(ksJdoFWhxTz8Y2N7bOZE+rpTF1AvXuItZQqU8CnMRSDV),BkM54Kr7Qbqn):
							AAHgDmI27P = ksJdoFWhxTz8Y2N7bOZE+rpTF1AvXuItZQqU8CnMRSDV[:uYA2DJg3vyzpo8IHnVjZ47s]
							tGeMaprEQvRDmFXuczYhgSA3qJiI45 = rpTF1AvXuItZQqU8CnMRSDV[uYA2DJg3vyzpo8IHnVjZ47s:]
							Hw1gXEZxcznf9lQm = x2cf7vHnGXz4Wj6DZpFVUL(AAHgDmI27P)
							Rx4H0V6KOBPcEqten71z8rkGLIWmy,pdWC3XZbMAB94FevkusQyqSc = MU7wbrgSopOkZvYhGXC.textsize(Hw1gXEZxcznf9lQm,font=dK7H25NZhit1)
							if Roe0sNhMAFafjt1O62UW+Rx4H0V6KOBPcEqten71z8rkGLIWmy>XPkQy7tFHSpZf23cvAV:
								EeGstfjCbng6 = MYDWEvtx7kgyU3Vh9o6PusjK-Rx4H0V6KOBPcEqten71z8rkGLIWmy
								p5VSHhWNOsgtJCk32fem6aD += AAHgDmI27P+C0qrknitpM4Z
								Q5QDz0hexvikNTKEy += wPrTIz9G4ARKN6jEbqicmlak7
								MYDWEvtx7kgyU3Vh9o6PusjK = EeGstfjCbng6
								if EeGstfjCbng6>XPkQy7tFHSpZf23cvAV:
									Roe0sNhMAFafjt1O62UW = D2D96X5NGamBhrFwvL8VEbqiSfZIl
									rpTF1AvXuItZQqU8CnMRSDV = tGeMaprEQvRDmFXuczYhgSA3qJiI45
								else:
									Roe0sNhMAFafjt1O62UW = EeGstfjCbng6
									p5VSHhWNOsgtJCk32fem6aD += tGeMaprEQvRDmFXuczYhgSA3qJiI45
								break
				if Q5QDz0hexvikNTKEy>SJVzDW0k1tqeYgTf3AZNI: break
		tt0aP9fmX2lOEGpsZjMdFHCDT += C0qrknitpM4Z+p5VSHhWNOsgtJCk32fem6aD
		if Q5QDz0hexvikNTKEy>SJVzDW0k1tqeYgTf3AZNI: break
	tt0aP9fmX2lOEGpsZjMdFHCDT = tt0aP9fmX2lOEGpsZjMdFHCDT[BkM54Kr7Qbqn:]
	tt0aP9fmX2lOEGpsZjMdFHCDT = tt0aP9fmX2lOEGpsZjMdFHCDT.replace('[COLOR:::','[COLOR ')
	return tt0aP9fmX2lOEGpsZjMdFHCDT
def x2cf7vHnGXz4Wj6DZpFVUL(rpTF1AvXuItZQqU8CnMRSDV):
	if '[' in rpTF1AvXuItZQqU8CnMRSDV and ']' in rpTF1AvXuItZQqU8CnMRSDV:
		TIx8VFBhifCM1zP = [T7ASIp1ZYwio9HQ8cObJK,'[/RTL]','[/LEFT]','[/RIGHT]','[/CENTER]','[RTL]','[LEFT]','[RIGHT]','[CENTER]']
		GGKYvQ59fSLrUWnp0J37bXOMCg = EcQxOa3RJm86WjTKA.findall('\[COLOR .*?\]',rpTF1AvXuItZQqU8CnMRSDV,EcQxOa3RJm86WjTKA.DOTALL)
		piJDwC6kuR01leTb3m9SyNUG8BEP = EcQxOa3RJm86WjTKA.findall('\[COLOR:::.*?\]',rpTF1AvXuItZQqU8CnMRSDV,EcQxOa3RJm86WjTKA.DOTALL)
		SSROBoWLAjb7Jh0gXetkvy = TIx8VFBhifCM1zP+GGKYvQ59fSLrUWnp0J37bXOMCg+piJDwC6kuR01leTb3m9SyNUG8BEP
		for euKgoVvDHxISNMO5yPn8FcRfQ46L in SSROBoWLAjb7Jh0gXetkvy: rpTF1AvXuItZQqU8CnMRSDV = rpTF1AvXuItZQqU8CnMRSDV.replace(euKgoVvDHxISNMO5yPn8FcRfQ46L,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	return rpTF1AvXuItZQqU8CnMRSDV
def XF1bDyNkBtjoagmJYP2OflG(YMaiHbnIThsP7q):
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(C0qrknitpM4Z,'_sss__newline_')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[RTL]','_sss__linertl_')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[LEFT]','_sss__lineleft_')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[RIGHT]','_sss__lineright_')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[CENTER]','_sss__linecenter_')
	YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace(T7ASIp1ZYwio9HQ8cObJK,'_sss__endcolor_')
	nVzMeGOE9x4uYU5w16o8vfWX = EcQxOa3RJm86WjTKA.findall('\[COLOR (.*?)\]',YMaiHbnIThsP7q,EcQxOa3RJm86WjTKA.DOTALL)
	for rrXnpQ8otATJIZldCyDO in nVzMeGOE9x4uYU5w16o8vfWX: YMaiHbnIThsP7q = YMaiHbnIThsP7q.replace('[COLOR '+rrXnpQ8otATJIZldCyDO+']','_sss__newcolor'+rrXnpQ8otATJIZldCyDO+'_')
	return YMaiHbnIThsP7q
def bNHEp28wg51k(ffEcjwJQ1MptFTlAqUrsHyoxP67I05,z36flodJVD9jWxip14Rh=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if not z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = bEWpDHXjCBqd7aOiN6UG5k.getInfoLabel('ListItem.Label')
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(zz5wETpjWKMNb6JiLRndGhV9,ksJdoFWhxTz8Y2N7bOZE).replace(yU7COAbsNJ916v5L0oew2n,ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).strip(ksJdoFWhxTz8Y2N7bOZE)
	if ffEcjwJQ1MptFTlAqUrsHyoxP67I05: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace('[COLOR ',fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(']',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	else: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(WydpaVx5YmLoCiIgA34eEBlb,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(n0nFOd4yR97fQzNLSW,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(ISYP5dC9xevhz0lJoV67cNfXM,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(wRebsz18p0FJ5BlDuU,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(C0qrknitpM4Z,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(FFkml6ZbgXD,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.replace(ghA8DEI1uiecHS6,fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace(fROdS5FWnqVN3aurX9bZx,fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	a5zfYBVl3TjtWhdSQOiLgZAvGN = EcQxOa3RJm86WjTKA.findall('\d\d:\d\d ',z36flodJVD9jWxip14Rh,EcQxOa3RJm86WjTKA.DOTALL)
	if a5zfYBVl3TjtWhdSQOiLgZAvGN: z36flodJVD9jWxip14Rh = z36flodJVD9jWxip14Rh.split(a5zfYBVl3TjtWhdSQOiLgZAvGN[D2D96X5NGamBhrFwvL8VEbqiSfZIl],BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
	if not z36flodJVD9jWxip14Rh: z36flodJVD9jWxip14Rh = 'Main Menu'
	return z36flodJVD9jWxip14Rh
def KaUrpGJVDF470YloiwbH69tqmXyuOT(ZYvoT3WE7aCg5s):
	BBdRpQu41gCKeNqIvZX8 = fy8iFgEkrO12NR9TWBI35sjY6qHvV.join(uYA2DJg3vyzpo8IHnVjZ47s for uYA2DJg3vyzpo8IHnVjZ47s in ZYvoT3WE7aCg5s if uYA2DJg3vyzpo8IHnVjZ47s not in '\/":*?<>|'+gTMA6jrcU03JNv1)
	return BBdRpQu41gCKeNqIvZX8
def wgGqOiUQuT(yy7dsVqg23CI5tbjXlwWmOe):
	PywLZVsnFOgRk62eH5J3GoNKYp = EcQxOa3RJm86WjTKA.findall("adilbo_HTML_encoder(.*?)/g.....(.*?)\)",yy7dsVqg23CI5tbjXlwWmOe,EcQxOa3RJm86WjTKA.S)
	if PywLZVsnFOgRk62eH5J3GoNKYp:
		ypzZCqoAWr51f7vFSwdthXK8Bm2,EESCizau3AoBKQr89v0 = PywLZVsnFOgRk62eH5J3GoNKYp[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		ypzZCqoAWr51f7vFSwdthXK8Bm2 = EcQxOa3RJm86WjTKA.findall("=[\r\n\s\t]+'(.*?)';", ypzZCqoAWr51f7vFSwdthXK8Bm2, EcQxOa3RJm86WjTKA.S)[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
		if ypzZCqoAWr51f7vFSwdthXK8Bm2 and EESCizau3AoBKQr89v0:
			xxZPmO6DCTuQYX8UBd = ypzZCqoAWr51f7vFSwdthXK8Bm2.replace("'",fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace("+",fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace("\n",fy8iFgEkrO12NR9TWBI35sjY6qHvV).replace("\r",fy8iFgEkrO12NR9TWBI35sjY6qHvV)
			OViebs6zhpDcFf5xR7a = xxZPmO6DCTuQYX8UBd.split('.')
			yy7dsVqg23CI5tbjXlwWmOe = fy8iFgEkrO12NR9TWBI35sjY6qHvV
			for Q9N8EhmTZVPi5sHdIzn in OViebs6zhpDcFf5xR7a:
				O8xSEyvCqkJ = JNfHYgOdP9aR.b64decode(Q9N8EhmTZVPi5sHdIzn+'==').decode(Tk9eH2qw6Brsuhj)
				jymLD7Vw3KFztbJOeUBYgHI4GRS1 = EcQxOa3RJm86WjTKA.findall('\d+', O8xSEyvCqkJ, EcQxOa3RJm86WjTKA.S)
				if jymLD7Vw3KFztbJOeUBYgHI4GRS1:
					LGMjz1mJpctol36webkWvSKE2Q7PD = int(jymLD7Vw3KFztbJOeUBYgHI4GRS1[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
					LGMjz1mJpctol36webkWvSKE2Q7PD += int(EESCizau3AoBKQr89v0)
					yy7dsVqg23CI5tbjXlwWmOe = yy7dsVqg23CI5tbjXlwWmOe + chr(LGMjz1mJpctol36webkWvSKE2Q7PD)
			if jTDWgftK7NEmx0JAkOn2aRIvweq: yy7dsVqg23CI5tbjXlwWmOe = yy7dsVqg23CI5tbjXlwWmOe.encode('iso-8859-1').decode(Tk9eH2qw6Brsuhj)
	return yy7dsVqg23CI5tbjXlwWmOe
def TBPcjsyOYoM82pm(NfMYGx1L4SW8FnC2uOzkP,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4=fy8iFgEkrO12NR9TWBI35sjY6qHvV,ds7kBa05cXn8oy9gAxmNKvV3TIp4=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if '::' in iXYEGvtThUqFPJ4pHLZSnNRr29Ako: iXYEGvtThUqFPJ4pHLZSnNRr29Ako,ZJqDh4ByGPQn13tlzMOTLCNdcugx = iXYEGvtThUqFPJ4pHLZSnNRr29Ako.split('::')
	else: iXYEGvtThUqFPJ4pHLZSnNRr29Ako,ZJqDh4ByGPQn13tlzMOTLCNdcugx = iXYEGvtThUqFPJ4pHLZSnNRr29Ako,''
	YLKFRH6sSIrznXBg,aNqQDLfOzTK6,Ne7jpQSVGgR,AhqmcZCJOQ2jBsfEizgSaoXGT6b = tQy9PbSu2EB4HVIa0n(zzekZcWL1sBgnoxN8f3vdQ0r)
	try: T6TNE0jSrRQ12ik8PDn4XheZV7uC = GAwfpnzSiJEcHtQjDul1LsPN2YT0x9.copy()
	except: T6TNE0jSrRQ12ik8PDn4XheZV7uC = GAwfpnzSiJEcHtQjDul1LsPN2YT0x9
	Uuqa3wD8CR1G6 = iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,O6N8nhyYTD12KRApqkLzVi,T6TNE0jSrRQ12ik8PDn4XheZV7uC,dvFPH1zieGquOp9X7xf
	if NfMYGx1L4SW8FnC2uOzkP<D2D96X5NGamBhrFwvL8VEbqiSfZIl:
		gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'OPENURL_REQUESTS',Uuqa3wD8CR1G6)
		NfMYGx1L4SW8FnC2uOzkP = -NfMYGx1L4SW8FnC2uOzkP
	if NfMYGx1L4SW8FnC2uOzkP>D2D96X5NGamBhrFwvL8VEbqiSfZIl:
		ND4YsIrucC = rIhXWK91vRuC(jUCABmLYMf0G,'response','OPENURL_REQUESTS',Uuqa3wD8CR1G6)
		if ND4YsIrucC.succeeded:
			JfDOEvKRb1otY6kWZGXqnV('REQUESTS  READ_CACHE',YLKFRH6sSIrznXBg,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,mE7D5fBQZOKJdhtVUkHaIgRWpx,iXYEGvtThUqFPJ4pHLZSnNRr29Ako)
			return ND4YsIrucC
	if ZJqDh4ByGPQn13tlzMOTLCNdcugx=='SCRAPERS': ND4YsIrucC = QfvdwXOyPiLgZ2D95VJoarn8c17zp(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx)
	else: ND4YsIrucC = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4,ds7kBa05cXn8oy9gAxmNKvV3TIp4)
	if ND4YsIrucC.succeeded:
		if 'CIMANOW' in mE7D5fBQZOKJdhtVUkHaIgRWpx: ND4YsIrucC.content = wgGqOiUQuT(ND4YsIrucC.content)
		if ND4YsIrucC.scrape: NfMYGx1L4SW8FnC2uOzkP = rrux12tcwQl5
		if NfMYGx1L4SW8FnC2uOzkP and ND4YsIrucC.content: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'OPENURL_REQUESTS',Uuqa3wD8CR1G6,ND4YsIrucC,NfMYGx1L4SW8FnC2uOzkP)
	return ND4YsIrucC
def vQwHgmU3AeZG7a(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,data,headers,allow_redirects,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4,ds7kBa05cXn8oy9gAxmNKvV3TIp4):
	if data==fy8iFgEkrO12NR9TWBI35sjY6qHvV: data = {}
	if headers==fy8iFgEkrO12NR9TWBI35sjY6qHvV: headers = {}
	Rs8EfockW2DUHiMbjlXVLPT47mwKrI = EsCplGc5N4mBuYW0RVQt6b if allow_redirects in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b] else LhFAGlQ19zr
	RRn6elHkAQU9XT3NtISJyLKM = EsCplGc5N4mBuYW0RVQt6b if showDialogs in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b] else LhFAGlQ19zr
	DakRpOqGKwvdMBYIxNAu3t40sP68z = EsCplGc5N4mBuYW0RVQt6b if XTvQLmPSpkysbtg6wO3z4 in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b] else LhFAGlQ19zr
	ZT5DCmxQvJguarzes = EsCplGc5N4mBuYW0RVQt6b if ds7kBa05cXn8oy9gAxmNKvV3TIp4 in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,EsCplGc5N4mBuYW0RVQt6b] else LhFAGlQ19zr
	gWBLDSlZGwqxHT = data
	naBFTDfp6lmKjeOywg87IAcb = headers
	RRn6elHkAQU9XT3NtISJyLKM = RRn6elHkAQU9XT3NtISJyLKM if I4t9qonjrm.ALLOW_SHOWDIALOGS_FIX==zA8Ry1KDvmr3w4B5xeP else I4t9qonjrm.ALLOW_SHOWDIALOGS_FIX
	DakRpOqGKwvdMBYIxNAu3t40sP68z = DakRpOqGKwvdMBYIxNAu3t40sP68z if I4t9qonjrm.ALLOW_DNS_FIX==zA8Ry1KDvmr3w4B5xeP else I4t9qonjrm.ALLOW_DNS_FIX
	ZT5DCmxQvJguarzes = ZT5DCmxQvJguarzes if I4t9qonjrm.ALLOW_PROXY_FIX==zA8Ry1KDvmr3w4B5xeP else I4t9qonjrm.ALLOW_PROXY_FIX
	if mE7D5fBQZOKJdhtVUkHaIgRWpx=='SERVICES-INSTALL_OLD_RELEASE-1st': naBFTDfp6lmKjeOywg87IAcb = {}
	else:
		yyxkP2FWHhu = list(naBFTDfp6lmKjeOywg87IAcb.keys())
		if 'Referer' not in yyxkP2FWHhu: naBFTDfp6lmKjeOywg87IAcb['Referer'] = 'http'
		if 'User-Agent' not in yyxkP2FWHhu: naBFTDfp6lmKjeOywg87IAcb['User-Agent'] = j4lUV5BzHDI6EN(EsCplGc5N4mBuYW0RVQt6b)
	return iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,DakRpOqGKwvdMBYIxNAu3t40sP68z,ZT5DCmxQvJguarzes
def FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4=fy8iFgEkrO12NR9TWBI35sjY6qHvV,ds7kBa05cXn8oy9gAxmNKvV3TIp4=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	kJemADzFKdl = vQwHgmU3AeZG7a(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,showDialogs,mE7D5fBQZOKJdhtVUkHaIgRWpx,XTvQLmPSpkysbtg6wO3z4,ds7kBa05cXn8oy9gAxmNKvV3TIp4)
	iXYEGvtThUqFPJ4pHLZSnNRr29Ako,zzekZcWL1sBgnoxN8f3vdQ0r,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,DakRpOqGKwvdMBYIxNAu3t40sP68z,ZT5DCmxQvJguarzes = kJemADzFKdl
	YLKFRH6sSIrznXBg,aNqQDLfOzTK6,Ne7jpQSVGgR,AhqmcZCJOQ2jBsfEizgSaoXGT6b = tQy9PbSu2EB4HVIa0n(zzekZcWL1sBgnoxN8f3vdQ0r)
	DcM0yofjWm3SzQC4BNiE85bgkF2 = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.dns')
	DZ4Xco30UIJB7KR = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.usedns')
	l7K2Xo9Rei3 = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.useproxy')
	RXPS5CrAb01cmJB7T2ZgnQpUK8l = ['scrapeops','scraperapi','scrapingant','scrapingrobot','scrapeup','scrape.do']
	uxljY2sQRn3N = EsCplGc5N4mBuYW0RVQt6b if any(value in zzekZcWL1sBgnoxN8f3vdQ0r for value in RXPS5CrAb01cmJB7T2ZgnQpUK8l) else LhFAGlQ19zr
	if '&url=' in YLKFRH6sSIrznXBg and uxljY2sQRn3N: pnDIMwiZhNO0e13XsyvQkH6 = YLKFRH6sSIrznXBg.rsplit('&url=',BkM54Kr7Qbqn)[BkM54Kr7Qbqn]
	else: pnDIMwiZhNO0e13XsyvQkH6 = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	ohgREcS57numBMsKvjPwyIepHL8 = I4t9qonjrm.SITESURLS['PYTHON']
	Q7jgtBXcG2SIaVvLerwOlPs = YLKFRH6sSIrznXBg in ohgREcS57numBMsKvjPwyIepHL8 or pnDIMwiZhNO0e13XsyvQkH6 in ohgREcS57numBMsKvjPwyIepHL8
	PHelmI1S9ycJE3pWOBDaQFi4z = I4t9qonjrm.SITESURLS['REPOS']
	nP3JU2hxWbuv08CVfOFHLqRt = YLKFRH6sSIrznXBg in PHelmI1S9ycJE3pWOBDaQFi4z or pnDIMwiZhNO0e13XsyvQkH6 in PHelmI1S9ycJE3pWOBDaQFi4z
	EgwSKLMrlNDHdxpb42etR7q = Q7jgtBXcG2SIaVvLerwOlPs or nP3JU2hxWbuv08CVfOFHLqRt
	JY4kahAZ0IHUFqm = LhFAGlQ19zr
	ZZCT7O263xrsIt8VLlE1Yg = EsCplGc5N4mBuYW0RVQt6b
	TrjCvY67iP2mFy1c305uJ4e9kNpwbD = aNqQDLfOzTK6==None and Ne7jpQSVGgR==None and not uxljY2sQRn3N
	if TrjCvY67iP2mFy1c305uJ4e9kNpwbD and EgwSKLMrlNDHdxpb42etR7q:
		if Q7jgtBXcG2SIaVvLerwOlPs:
			qqEIwDF6fj7MAiGTg2H4bcptl8oeuO = ohgREcS57numBMsKvjPwyIepHL8.index(YLKFRH6sSIrznXBg)
			mmVtOjhJdG6P = I4t9qonjrm.SITESURLS['PYTHON_BKP1'][qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			crXa7PyQCWYfEFq1UvbJdz3AxNH4gI = I4t9qonjrm.SITESURLS['PYTHON_BKP2'][qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			MWw9kdTu0XE3czjgVB2t8p = I4t9qonjrm.SITESURLS['PYTHON_BKP3'][qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			WWb2t4zoZspJfK = I4t9qonjrm.api_python_actions[qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			if WWb2t4zoZspJfK=='LISTPLAY': DakRpOqGKwvdMBYIxNAu3t40sP68z,ZT5DCmxQvJguarzes,ZZCT7O263xrsIt8VLlE1Yg = LhFAGlQ19zr,LhFAGlQ19zr,LhFAGlQ19zr
			elif WWb2t4zoZspJfK=='CAPTCHA': JY4kahAZ0IHUFqm = EsCplGc5N4mBuYW0RVQt6b
		elif nP3JU2hxWbuv08CVfOFHLqRt:
			qqEIwDF6fj7MAiGTg2H4bcptl8oeuO = PHelmI1S9ycJE3pWOBDaQFi4z.index(YLKFRH6sSIrznXBg)
			mmVtOjhJdG6P = I4t9qonjrm.SITESURLS['REPOS_BKP1'][qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			crXa7PyQCWYfEFq1UvbJdz3AxNH4gI = I4t9qonjrm.SITESURLS['REPOS_BKP2'][qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			MWw9kdTu0XE3czjgVB2t8p = I4t9qonjrm.SITESURLS['REPOS_BKP3'][qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
			WWb2t4zoZspJfK = I4t9qonjrm.api_repos_actions[qqEIwDF6fj7MAiGTg2H4bcptl8oeuO]
	if Ne7jpQSVGgR==fy8iFgEkrO12NR9TWBI35sjY6qHvV: Ne7jpQSVGgR = DcM0yofjWm3SzQC4BNiE85bgkF2
	elif Ne7jpQSVGgR==None and DZ4Xco30UIJB7KR in ['AUTO','ACCEPTED'] and DakRpOqGKwvdMBYIxNAu3t40sP68z: Ne7jpQSVGgR = DcM0yofjWm3SzQC4BNiE85bgkF2
	if Q7jgtBXcG2SIaVvLerwOlPs or nP3JU2hxWbuv08CVfOFHLqRt: TqNMvyzBUxolbKhdcRku2L74F8e = 15
	elif uxljY2sQRn3N: TqNMvyzBUxolbKhdcRku2L74F8e = 60
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx in UUSxo7uMnZIWd0kcyi1Gz: TqNMvyzBUxolbKhdcRku2L74F8e = 10
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx=='LIBRARY-REVERSO_TRANSLATE-1st': TqNMvyzBUxolbKhdcRku2L74F8e = 20
	elif mE7D5fBQZOKJdhtVUkHaIgRWpx=='LIBRARY-GOOGLE_TRANSLATE-1st': TqNMvyzBUxolbKhdcRku2L74F8e = 20
	elif 'RESOLVERS-AKWAM' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 70
	elif 'SHOFHA' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 75
	elif 'CIMA4U' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 25
	elif 'AHWAK' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 20
	elif 'CIMALIGHT' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 20
	elif 'CIMACLUBWORK' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 30
	elif 'AKOAM' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 25
	elif 'AKWAM' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 30
	elif 'FASELHD1' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 20
	elif 'EGYBEST3' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 60
	elif 'HALACIMA' in mE7D5fBQZOKJdhtVUkHaIgRWpx: TqNMvyzBUxolbKhdcRku2L74F8e = 40
	else: TqNMvyzBUxolbKhdcRku2L74F8e = 15
	sQIVcwjArGOSWgun8ipaCtfyX = (aNqQDLfOzTK6!=None)
	u9AOrepU3lXLKIRbYtZCE42G = (Ne7jpQSVGgR!=None and DZ4Xco30UIJB7KR!='STOP')
	if sQIVcwjArGOSWgun8ipaCtfyX and not uxljY2sQRn3N: a6rVSjDMF87KyYINcuOP1l40Hbp('تفعيل بروكسي رقم',aNqQDLfOzTK6)
	elif u9AOrepU3lXLKIRbYtZCE42G: a6rVSjDMF87KyYINcuOP1l40Hbp('تفعيل DNS رقم',Ne7jpQSVGgR)
	if sQIVcwjArGOSWgun8ipaCtfyX:
		PN5tzsvxSBd2iUg = {"http":aNqQDLfOzTK6,"https":aNqQDLfOzTK6}
		LLKC9g7dPQeiMhInNlpqUzb = aNqQDLfOzTK6
	else: PN5tzsvxSBd2iUg,LLKC9g7dPQeiMhInNlpqUzb = {},fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if u9AOrepU3lXLKIRbYtZCE42G:
		import urllib3.util.connection as MmQWjxS8uFLeJvT2c7w
		jMbz5AJR2IkYCfVQpat8UT1HXl = VvNhnQ7H0lqzc(MmQWjxS8uFLeJvT2c7w,DcM0yofjWm3SzQC4BNiE85bgkF2,EsCplGc5N4mBuYW0RVQt6b)
	YGWvu4nytwR2VE8m,buOAHlCgTQfIWP3t7qRw8pms6Z0xYj,g7ew6IPUbjnCiX39ksDqcmR5FdHx01,cqWAon5JfexB3CgVYSHGpMi,qtdXhB0FlY3VyREAnsp1P7O4NfM,VVedkFzmJr,verify = Rs8EfockW2DUHiMbjlXVLPT47mwKrI,mE7D5fBQZOKJdhtVUkHaIgRWpx,iXYEGvtThUqFPJ4pHLZSnNRr29Ako,LhFAGlQ19zr,LhFAGlQ19zr,LhFAGlQ19zr,AhqmcZCJOQ2jBsfEizgSaoXGT6b
	if JY4kahAZ0IHUFqm: qtdXhB0FlY3VyREAnsp1P7O4NfM = EsCplGc5N4mBuYW0RVQt6b
	if EgwSKLMrlNDHdxpb42etR7q or Rs8EfockW2DUHiMbjlXVLPT47mwKrI: YGWvu4nytwR2VE8m = LhFAGlQ19zr
	if Q7jgtBXcG2SIaVvLerwOlPs: g7ew6IPUbjnCiX39ksDqcmR5FdHx01 = 'POST'
	Wsv5B14O6xFLqJ,iLXSma92HFtwhBKU = -BkM54Kr7Qbqn,'Unknown Error'
	yPI4XMVtup = LhFAGlQ19zr
	if not I4t9qonjrm.FORWARDS_HOSTNAMES: I4t9qonjrm.FORWARDS_HOSTNAMES = rIhXWK91vRuC(jUCABmLYMf0G,'dict','MISC_TEMP','FORWARDS')
	k9kiGtnYp7jNvUWbVg = []
	while YLKFRH6sSIrznXBg not in k9kiGtnYp7jNvUWbVg and YLKFRH6sSIrznXBg in list(I4t9qonjrm.FORWARDS_HOSTNAMES.keys()):
		k9kiGtnYp7jNvUWbVg.append(YLKFRH6sSIrznXBg)
		YLKFRH6sSIrznXBg = I4t9qonjrm.FORWARDS_HOSTNAMES[YLKFRH6sSIrznXBg]
	import requests as dgMhO3f7oA
	for b3b24XZTV7gW9mhcqLoCnftO in range(9):
		ddecO3Tb9U5k = LhFAGlQ19zr
		if b3b24XZTV7gW9mhcqLoCnftO: buOAHlCgTQfIWP3t7qRw8pms6Z0xYj = 'LIBRARY-OPENURL_REQUESTS-1st'
		if uxljY2sQRn3N or not sQIVcwjArGOSWgun8ipaCtfyX: JfDOEvKRb1otY6kWZGXqnV('REQUESTS\tOPEN_URL',YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,buOAHlCgTQfIWP3t7qRw8pms6Z0xYj,g7ew6IPUbjnCiX39ksDqcmR5FdHx01)
		try: ND4YsIrucC.close()
		except: pass
		MYWwFs7XA2 = YLKFRH6sSIrznXBg
		try:
			ND4YsIrucC = dgMhO3f7oA.request(g7ew6IPUbjnCiX39ksDqcmR5FdHx01,YLKFRH6sSIrznXBg,data=gWBLDSlZGwqxHT,headers=naBFTDfp6lmKjeOywg87IAcb,verify=verify,allow_redirects=YGWvu4nytwR2VE8m,timeout=TqNMvyzBUxolbKhdcRku2L74F8e,proxies=PN5tzsvxSBd2iUg)
			if 300<=ND4YsIrucC.status_code<=399:
				if not cqWAon5JfexB3CgVYSHGpMi:
					I1qDPQzy4WwuBRjZlC6pKF8GtO = list(ND4YsIrucC.headers.keys())
					if 'Location' in I1qDPQzy4WwuBRjZlC6pKF8GtO: YLKFRH6sSIrznXBg = ND4YsIrucC.headers['Location']
					elif 'location' in I1qDPQzy4WwuBRjZlC6pKF8GtO: YLKFRH6sSIrznXBg = ND4YsIrucC.headers['location']
					else: cqWAon5JfexB3CgVYSHGpMi = EsCplGc5N4mBuYW0RVQt6b
					if not cqWAon5JfexB3CgVYSHGpMi: YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg.encode('latin-1','ignore').decode(Tk9eH2qw6Brsuhj,'ignore')
					if EgwSKLMrlNDHdxpb42etR7q and ND4YsIrucC.status_code==307:
						YGWvu4nytwR2VE8m = Rs8EfockW2DUHiMbjlXVLPT47mwKrI
						g7ew6IPUbjnCiX39ksDqcmR5FdHx01 = iXYEGvtThUqFPJ4pHLZSnNRr29Ako
						cqWAon5JfexB3CgVYSHGpMi = EsCplGc5N4mBuYW0RVQt6b
						GoT5MSAklEKWcQY7xbvO2D
				if not cqWAon5JfexB3CgVYSHGpMi or Rs8EfockW2DUHiMbjlXVLPT47mwKrI:
					if 'http' not in YLKFRH6sSIrznXBg:
						i5AjLYP2FMsJZDSwhQzEqmy = VbHeOuU1ilzSp2ZRXwBD(MYWwFs7XA2,'url')
						YLKFRH6sSIrznXBg = i5AjLYP2FMsJZDSwhQzEqmy+'/'+YLKFRH6sSIrznXBg.lstrip('/')
				if YLKFRH6sSIrznXBg!=MYWwFs7XA2:
					I4t9qonjrm.FORWARDS_HOSTNAMES[MYWwFs7XA2] = YLKFRH6sSIrznXBg
					yPI4XMVtup = EsCplGc5N4mBuYW0RVQt6b
				if not cqWAon5JfexB3CgVYSHGpMi and Rs8EfockW2DUHiMbjlXVLPT47mwKrI:
					if ml1bXR85BJyhPAVvQY(YLKFRH6sSIrznXBg): GoT5MSAklEKWcQY7xbvO2D
					else: continue
			elif 550<=ND4YsIrucC.status_code<=599:
				ND4YsIrucC.reason = ND4YsIrucC.content
				qtdXhB0FlY3VyREAnsp1P7O4NfM = EsCplGc5N4mBuYW0RVQt6b
			MYWwFs7XA2 = ND4YsIrucC.url
			Wsv5B14O6xFLqJ = ND4YsIrucC.status_code
			iLXSma92HFtwhBKU = ND4YsIrucC.reason
			ND4YsIrucC.raise_for_status()
			ddecO3Tb9U5k = EsCplGc5N4mBuYW0RVQt6b
		except dgMhO3f7oA.exceptions.HTTPError as NYtXLZDyeiqPSgGO:
			pass
		except dgMhO3f7oA.exceptions.Timeout as NYtXLZDyeiqPSgGO:
			if gZlSEJaXO9F461AL3sR7rWNpqf: iLXSma92HFtwhBKU = str(NYtXLZDyeiqPSgGO.message).split(': ')[BkM54Kr7Qbqn]
			else: iLXSma92HFtwhBKU = str(NYtXLZDyeiqPSgGO).split(': ')[BkM54Kr7Qbqn]
		except dgMhO3f7oA.exceptions.ConnectionError as NYtXLZDyeiqPSgGO:
			try: RLJCuTQqVA46r8Sx = NYtXLZDyeiqPSgGO.message[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			except: RLJCuTQqVA46r8Sx = str(NYtXLZDyeiqPSgGO)
			u5u0RaFmXTYe = EcQxOa3RJm86WjTKA.findall("\[Errno (\d+)\] (.*?)'",RLJCuTQqVA46r8Sx)
			if not u5u0RaFmXTYe: u5u0RaFmXTYe = EcQxOa3RJm86WjTKA.findall(", error\((\d+), '(.*?)'",RLJCuTQqVA46r8Sx)
			if not u5u0RaFmXTYe:
				hlC5rGd8LyUV3P1jkAwIfJOB = EcQxOa3RJm86WjTKA.findall(": (.*?):.*?(\d+):",RLJCuTQqVA46r8Sx)
				if hlC5rGd8LyUV3P1jkAwIfJOB: u5u0RaFmXTYe = [hlC5rGd8LyUV3P1jkAwIfJOB[D2D96X5NGamBhrFwvL8VEbqiSfZIl][BkM54Kr7Qbqn],hlC5rGd8LyUV3P1jkAwIfJOB[D2D96X5NGamBhrFwvL8VEbqiSfZIl][D2D96X5NGamBhrFwvL8VEbqiSfZIl]]
			if not u5u0RaFmXTYe: u5u0RaFmXTYe = EcQxOa3RJm86WjTKA.findall(":(\d+): (.*?)'",RLJCuTQqVA46r8Sx)
			if not u5u0RaFmXTYe: u5u0RaFmXTYe = EcQxOa3RJm86WjTKA.findall(" (\d+)] (.*?)'",RLJCuTQqVA46r8Sx)
			try: Wsv5B14O6xFLqJ,iLXSma92HFtwhBKU = u5u0RaFmXTYe[D2D96X5NGamBhrFwvL8VEbqiSfZIl]
			except: Wsv5B14O6xFLqJ,iLXSma92HFtwhBKU = -teaC5j4HuGDqpwcmUzJ,RLJCuTQqVA46r8Sx
		except dgMhO3f7oA.exceptions.RequestException as NYtXLZDyeiqPSgGO:
			if gZlSEJaXO9F461AL3sR7rWNpqf: iLXSma92HFtwhBKU = NYtXLZDyeiqPSgGO.message
			else: iLXSma92HFtwhBKU = str(NYtXLZDyeiqPSgGO)
		except:
			try: Wsv5B14O6xFLqJ = ND4YsIrucC.status_code
			except: pass
			try: iLXSma92HFtwhBKU = ND4YsIrucC.reason
			except: pass
		iLXSma92HFtwhBKU = str(iLXSma92HFtwhBKU)
		Clc8sIj97ZrThF(h0fvMZUqg9SCaOYBQ,'OPENURL_REQUESTS\tRESPONSE  Code: [ '+str(Wsv5B14O6xFLqJ)+' ]   Reason: [ '+iLXSma92HFtwhBKU+' ]   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
		if TrjCvY67iP2mFy1c305uJ4e9kNpwbD and EgwSKLMrlNDHdxpb42etR7q and not qtdXhB0FlY3VyREAnsp1P7O4NfM and Wsv5B14O6xFLqJ!=200:
			if YLKFRH6sSIrznXBg not in [mmVtOjhJdG6P,crXa7PyQCWYfEFq1UvbJdz3AxNH4gI,MWw9kdTu0XE3czjgVB2t8p]: YLKFRH6sSIrznXBg,qtdXhB0FlY3VyREAnsp1P7O4NfM = mmVtOjhJdG6P,LhFAGlQ19zr
			elif YLKFRH6sSIrznXBg==mmVtOjhJdG6P: YLKFRH6sSIrznXBg,qtdXhB0FlY3VyREAnsp1P7O4NfM = crXa7PyQCWYfEFq1UvbJdz3AxNH4gI,LhFAGlQ19zr
			elif YLKFRH6sSIrznXBg==crXa7PyQCWYfEFq1UvbJdz3AxNH4gI: YLKFRH6sSIrznXBg,qtdXhB0FlY3VyREAnsp1P7O4NfM = MWw9kdTu0XE3czjgVB2t8p,EsCplGc5N4mBuYW0RVQt6b
			continue
		break
	Wsv5B14O6xFLqJ = int(Wsv5B14O6xFLqJ)
	if not ddecO3Tb9U5k:
		WTaECdm2NlD4zVwIY5vg7OiyhB = gn6Rhp5VIDGUAbvYL(I4t9qonjrm.DNS_SERVERS[teaC5j4HuGDqpwcmUzJ],53)
		if WTaECdm2NlD4zVwIY5vg7OiyhB==-BkM54Kr7Qbqn:
			Clc8sIj97ZrThF(P3PazFblmtN,'OPENURL_REQUESTS   DISCONNECTED   The device is not connected to the internet !!   ')
			GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','للأسف جهازك غير مربوط بالإنترنت .. أو غير قادر أن يستخدم الإنترنت .. أو إعدادات جهازك غير صحيحة \n\n لحل المشكلة تأكد أن جهازك مربوط بطريقة صحيحة بالإنترنت وفيه الإنترنت تعمل بصورة جيدة')
			n9grXGiQYD2wl8UjSRe3HcKhE()
			return ND4YsIrucC
	if not ddecO3Tb9U5k and k9kiGtnYp7jNvUWbVg:
		for url in k9kiGtnYp7jNvUWbVg:
			if url in list(I4t9qonjrm.FORWARDS_HOSTNAMES.keys()):
				del I4t9qonjrm.FORWARDS_HOSTNAMES[url]
				yPI4XMVtup = EsCplGc5N4mBuYW0RVQt6b
	if yPI4XMVtup:
		tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'MISC_TEMP','FORWARDS',I4t9qonjrm.FORWARDS_HOSTNAMES,rrux12tcwQl5)
		I4t9qonjrm.FORWARDS_HOSTNAMES = {}
	if Ne7jpQSVGgR!=None and DZ4Xco30UIJB7KR!='STOP': MmQWjxS8uFLeJvT2c7w.create_connection = jMbz5AJR2IkYCfVQpat8UT1HXl
	if DZ4Xco30UIJB7KR=='ALWAYS' and DakRpOqGKwvdMBYIxNAu3t40sP68z: Ne7jpQSVGgR = None
	if not ddecO3Tb9U5k and aNqQDLfOzTK6==None and mE7D5fBQZOKJdhtVUkHaIgRWpx not in UUSxo7uMnZIWd0kcyi1Gz:
		Okwr0yDIL1oVF9AlWRbduUtnzp = NFtwAhXgZB9u.format_exc()
		if Okwr0yDIL1oVF9AlWRbduUtnzp!='NoneType: None\n': CfgZ0zWP5XBpoGQwLUY.stderr.write(Okwr0yDIL1oVF9AlWRbduUtnzp)
	JOB9NFKAlRSW8eyTQDPaG7 = coFM7huzDdQ2()
	if uxljY2sQRn3N: MYWwFs7XA2 = pnDIMwiZhNO0e13XsyvQkH6
	if not MYWwFs7XA2: MYWwFs7XA2 = YLKFRH6sSIrznXBg
	JOB9NFKAlRSW8eyTQDPaG7.url = MYWwFs7XA2
	JOB9NFKAlRSW8eyTQDPaG7.scrape = uxljY2sQRn3N
	try: aqGuWAjH1VdhzTwQPFrL6x5is9Bm = ND4YsIrucC.content
	except: aqGuWAjH1VdhzTwQPFrL6x5is9Bm = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	try: fVyzUAKh6sbjE = ND4YsIrucC.headers
	except: fVyzUAKh6sbjE = {}
	try: bbrcf4uQGCKiVSmzsJptn6g1OvLd = ND4YsIrucC.cookies.get_dict()
	except: bbrcf4uQGCKiVSmzsJptn6g1OvLd = {}
	try: ND4YsIrucC.close()
	except: pass
	if jTDWgftK7NEmx0JAkOn2aRIvweq:
		try: aqGuWAjH1VdhzTwQPFrL6x5is9Bm = aqGuWAjH1VdhzTwQPFrL6x5is9Bm.decode(Tk9eH2qw6Brsuhj)
		except: pass
	JOB9NFKAlRSW8eyTQDPaG7.code = Wsv5B14O6xFLqJ
	JOB9NFKAlRSW8eyTQDPaG7.reason = iLXSma92HFtwhBKU
	JOB9NFKAlRSW8eyTQDPaG7.content = aqGuWAjH1VdhzTwQPFrL6x5is9Bm
	JOB9NFKAlRSW8eyTQDPaG7.headers = fVyzUAKh6sbjE
	JOB9NFKAlRSW8eyTQDPaG7.cookies = bbrcf4uQGCKiVSmzsJptn6g1OvLd
	JOB9NFKAlRSW8eyTQDPaG7.succeeded = ddecO3Tb9U5k
	JOB9NFKAlRSW8eyTQDPaG7.scrapernumber = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	JOB9NFKAlRSW8eyTQDPaG7.scraperserver = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	JOB9NFKAlRSW8eyTQDPaG7.scraperurl = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if gZlSEJaXO9F461AL3sR7rWNpqf or isinstance(JOB9NFKAlRSW8eyTQDPaG7.content,str): BBGqwbCtDZh4FkLzI3uQ8vl5NHs = JOB9NFKAlRSW8eyTQDPaG7.content.lower()
	else: BBGqwbCtDZh4FkLzI3uQ8vl5NHs = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	f1KUbrwHDVWCgTLvaAelE = ('cloudflare' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs or 'google' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs) and BBGqwbCtDZh4FkLzI3uQ8vl5NHs.count('recaptcha')>teaC5j4HuGDqpwcmUzJ and 'FASELHD1' not in mE7D5fBQZOKJdhtVUkHaIgRWpx and 'recaptcha-token' not in BBGqwbCtDZh4FkLzI3uQ8vl5NHs and not uxljY2sQRn3N
	if Wsv5B14O6xFLqJ==200 and f1KUbrwHDVWCgTLvaAelE: JOB9NFKAlRSW8eyTQDPaG7.succeeded = LhFAGlQ19zr
	if JOB9NFKAlRSW8eyTQDPaG7.succeeded and TrjCvY67iP2mFy1c305uJ4e9kNpwbD and EgwSKLMrlNDHdxpb42etR7q:
		rZT2XOwMtxjeNnI3v = 'CAPTCHA'+gWBLDSlZGwqxHT['job'].upper().replace('GET',fy8iFgEkrO12NR9TWBI35sjY6qHvV) if JY4kahAZ0IHUFqm else WWb2t4zoZspJfK
		frSuovzeY8hZD(rZT2XOwMtxjeNnI3v)
	if not JOB9NFKAlRSW8eyTQDPaG7.succeeded and TrjCvY67iP2mFy1c305uJ4e9kNpwbD:
		d4UPnf0xymp5uoAe1EFNklW = ('cloudflare' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs and 'ray id: ' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs)
		CzOo98UKMaGgV7jXyNJq = ('5 sec' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs and 'browser' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs)
		sMnZPlBEio = (Wsv5B14O6xFLqJ in [403] and 'error code: 1020' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs)
		J8JagWbIl5VuRYBDyMUOjPxir = ('_cf_chl_' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs and 'challenge-' in BBGqwbCtDZh4FkLzI3uQ8vl5NHs)
		if   f1KUbrwHDVWCgTLvaAelE: iLXSma92HFtwhBKU = 'Blocked by recaptcha'
		elif d4UPnf0xymp5uoAe1EFNklW: iLXSma92HFtwhBKU = 'Blocked by cloudflare'
		elif CzOo98UKMaGgV7jXyNJq: iLXSma92HFtwhBKU = 'Blocked by 5 seconds browser check'
		elif sMnZPlBEio: iLXSma92HFtwhBKU = 'Blocked by cloudflare access denied'
		elif J8JagWbIl5VuRYBDyMUOjPxir: iLXSma92HFtwhBKU = 'Blocked by cloudflare security check'
		else: iLXSma92HFtwhBKU = str(iLXSma92HFtwhBKU)
		if mE7D5fBQZOKJdhtVUkHaIgRWpx in MMXLBYhFx4vuUOSEaHqDNs: pass
		elif mE7D5fBQZOKJdhtVUkHaIgRWpx in UUSxo7uMnZIWd0kcyi1Gz:
			Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'  Direct connection failed   Code: [ '+str(Wsv5B14O6xFLqJ)+' ]   Reason: [ '+iLXSma92HFtwhBKU+' ]   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+YLKFRH6sSIrznXBg+' ]')
		else: Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Direct connection failed   Code: [ '+str(Wsv5B14O6xFLqJ)+' ]   Reason: [ '+iLXSma92HFtwhBKU+' ]   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+YLKFRH6sSIrznXBg+' ]')
		WUuS0xI3pO7RPtFbk6YTm2wd = pnDIMwiZhNO0e13XsyvQkH6 if uxljY2sQRn3N else U2Z7CVFftTmLeK3nzEbQPGga(YLKFRH6sSIrznXBg)
		if gZlSEJaXO9F461AL3sR7rWNpqf and isinstance(WUuS0xI3pO7RPtFbk6YTm2wd,unicode): WUuS0xI3pO7RPtFbk6YTm2wd = WUuS0xI3pO7RPtFbk6YTm2wd.encode(Tk9eH2qw6Brsuhj)
		if EgwSKLMrlNDHdxpb42etR7q: WUuS0xI3pO7RPtFbk6YTm2wd = WUuS0xI3pO7RPtFbk6YTm2wd.split('/')[-BkM54Kr7Qbqn]
		APhQ2SOzVYEwviWFXMnrqtgByLd94 = str(iLXSma92HFtwhBKU)+'\n( '+WUuS0xI3pO7RPtFbk6YTm2wd+' )'
		if Wsv5B14O6xFLqJ in [-BkM54Kr7Qbqn,-teaC5j4HuGDqpwcmUzJ] or f1KUbrwHDVWCgTLvaAelE or d4UPnf0xymp5uoAe1EFNklW or CzOo98UKMaGgV7jXyNJq or sMnZPlBEio or J8JagWbIl5VuRYBDyMUOjPxir:
			JOB9NFKAlRSW8eyTQDPaG7.code = -XW57OCeGnFTLQbaqdrD9zM
			JOB9NFKAlRSW8eyTQDPaG7.reason = iLXSma92HFtwhBKU
			if ZT5DCmxQvJguarzes:
				UWCLiFA6Yx2jEcDay = QfvdwXOyPiLgZ2D95VJoarn8c17zp(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,Rs8EfockW2DUHiMbjlXVLPT47mwKrI,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx,Wsv5B14O6xFLqJ,iLXSma92HFtwhBKU)
				if UWCLiFA6Yx2jEcDay.succeeded: return UWCLiFA6Yx2jEcDay
		Scj7zgGFVA83otMpwUkxhm0BLN1 = EsCplGc5N4mBuYW0RVQt6b
		if (DZ4Xco30UIJB7KR=='ASK' or l7K2Xo9Rei3=='ASK') and (DakRpOqGKwvdMBYIxNAu3t40sP68z or ZT5DCmxQvJguarzes):
			Scj7zgGFVA83otMpwUkxhm0BLN1 = ppWjXFHqhOrlMzRf2N7vL6(Wsv5B14O6xFLqJ,APhQ2SOzVYEwviWFXMnrqtgByLd94,mE7D5fBQZOKJdhtVUkHaIgRWpx,RRn6elHkAQU9XT3NtISJyLKM)
			if Scj7zgGFVA83otMpwUkxhm0BLN1 and DZ4Xco30UIJB7KR=='ASK': DZ4Xco30UIJB7KR = 'ACCEPTED'
			else: DZ4Xco30UIJB7KR = 'REJECTED'
			if Scj7zgGFVA83otMpwUkxhm0BLN1 and l7K2Xo9Rei3=='ASK': l7K2Xo9Rei3 = 'ACCEPTED'
			else: l7K2Xo9Rei3 = 'REJECTED'
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.usedns',DZ4Xco30UIJB7KR)
			OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.useproxy',l7K2Xo9Rei3)
		if Scj7zgGFVA83otMpwUkxhm0BLN1:
			if Wsv5B14O6xFLqJ==8 and 'https' in YLKFRH6sSIrznXBg and ZZCT7O263xrsIt8VLlE1Yg:
				if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('تفعيل فحص شهادة التشفير SSL','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
				MYWwFs7XA2 = YLKFRH6sSIrznXBg+'||NoVerifySSL'
				xmsOVkodWQ9ECanvR073l8 = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,MYWwFs7XA2,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,RRn6elHkAQU9XT3NtISJyLKM,'LIBRARY-OPENURL_REQUESTS-2nd')
				if xmsOVkodWQ9ECanvR073l8.succeeded:
					JOB9NFKAlRSW8eyTQDPaG7 = xmsOVkodWQ9ECanvR073l8
					Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Succeeded using SSL:   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
					if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('نجاح باستخدام SSL','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
				else:
					Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Failed using SSL:   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
					if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('فشل باستخدام SSL','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
			if not JOB9NFKAlRSW8eyTQDPaG7.succeeded and l7K2Xo9Rei3 in ['AUTO','ACCEPTED'] and ZT5DCmxQvJguarzes:
				if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('تفعيل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
				xmsOVkodWQ9ECanvR073l8 = T6TLaoxJnD0RlOZhiXGk7U1y3SK2(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,YLKFRH6sSIrznXBg,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,RRn6elHkAQU9XT3NtISJyLKM,mE7D5fBQZOKJdhtVUkHaIgRWpx)
				if xmsOVkodWQ9ECanvR073l8.succeeded:
					JOB9NFKAlRSW8eyTQDPaG7 = xmsOVkodWQ9ECanvR073l8
					Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Proxies succeeded:   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
					if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('نجاح سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
				else:
					Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   Proxies failed:   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
					if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('فشل سيرفرات بروكسي','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
			if not JOB9NFKAlRSW8eyTQDPaG7.succeeded and DZ4Xco30UIJB7KR in ['AUTO','ACCEPTED'] and DakRpOqGKwvdMBYIxNAu3t40sP68z:
				if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('تفعيل سيرفر DNS','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
				MYWwFs7XA2 = YLKFRH6sSIrznXBg+'||MyDNSUrl='
				xmsOVkodWQ9ECanvR073l8 = FlxDpgfQcuSWvGwtyC5d(iXYEGvtThUqFPJ4pHLZSnNRr29Ako,MYWwFs7XA2,O6N8nhyYTD12KRApqkLzVi,GAwfpnzSiJEcHtQjDul1LsPN2YT0x9,dvFPH1zieGquOp9X7xf,RRn6elHkAQU9XT3NtISJyLKM,'LIBRARY-OPENURL_REQUESTS-4th')
				if xmsOVkodWQ9ECanvR073l8.succeeded:
					JOB9NFKAlRSW8eyTQDPaG7 = xmsOVkodWQ9ECanvR073l8
					Clc8sIj97ZrThF(wVhZ6bfkpSre95EFu,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   DNS succeeded:   DNS: [ '+DcM0yofjWm3SzQC4BNiE85bgkF2+' ]   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
					if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('نجاح سيرفر DNS','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
				else:
					Clc8sIj97ZrThF(P3PazFblmtN,BaQzADt45VUslp1(BfWYUAnyg6eONLjiuE)+'   DNS failed:   DNS: [ '+DcM0yofjWm3SzQC4BNiE85bgkF2+' ]   Source: [ '+mE7D5fBQZOKJdhtVUkHaIgRWpx+' ]   URL: [ '+zzekZcWL1sBgnoxN8f3vdQ0r+' ]')
					if RRn6elHkAQU9XT3NtISJyLKM: a6rVSjDMF87KyYINcuOP1l40Hbp('فشل سيرفر DNS','لإصلاح مشكلة الإنترنيت',uUqrNPcXKBoQ0slv=2000)
		if l7K2Xo9Rei3=='REJECTED' or DZ4Xco30UIJB7KR=='REJECTED': RRn6elHkAQU9XT3NtISJyLKM = LhFAGlQ19zr
		if not JOB9NFKAlRSW8eyTQDPaG7.succeeded:
			if RRn6elHkAQU9XT3NtISJyLKM: Tlnfx1FoiQUXh6dGueYL2mIsB7KM = ppWjXFHqhOrlMzRf2N7vL6(Wsv5B14O6xFLqJ,APhQ2SOzVYEwviWFXMnrqtgByLd94,mE7D5fBQZOKJdhtVUkHaIgRWpx,RRn6elHkAQU9XT3NtISJyLKM)
			if Wsv5B14O6xFLqJ!=200 and mE7D5fBQZOKJdhtVUkHaIgRWpx not in u0HZLYVePBUomvS and 'RESOLVERS-' not in mE7D5fBQZOKJdhtVUkHaIgRWpx: tWSpoXNe2rBfca()
	if OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.usedns') not in ['AUTO','STOP','ASK']: OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.usedns','ASK')
	if OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.useproxy') not in ['AUTO','STOP','ASK']: OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.useproxy','ASK')
	return JOB9NFKAlRSW8eyTQDPaG7
def RKYsragFJfoQlEU1Mj5HPAnIDTS(vUTCBmuRD025KJ):
	PWUoXkKCxqn1vRtNJsSdp0lBa,RdvzsjKYupa0yB5I3MUCAqmtZPO = fy8iFgEkrO12NR9TWBI35sjY6qHvV,LhFAGlQ19zr
	if vUTCBmuRD025KJ: PWUoXkKCxqn1vRtNJsSdp0lBa = rIhXWK91vRuC(jUCABmLYMf0G,'str','MISC_TEMP','EXTRAPYTHONCODE')
	if not PWUoXkKCxqn1vRtNJsSdp0lBa:
		zzekZcWL1sBgnoxN8f3vdQ0r = I4t9qonjrm.SITESURLS['PYTHON'][9]
		CfKjoYXSy1vwIBM4l9UDzb = {'user':I4t9qonjrm.AV_CLIENT_IDS,'version':KoxvjArhL1TdInDmN9s}
		PWUoXkKCxqn1vRtNJsSdp0lBa = LLJ9RNzFxShH('POST',zzekZcWL1sBgnoxN8f3vdQ0r,CfKjoYXSy1vwIBM4l9UDzb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIBRARY-EXTRA_PYTHON_CODE-1st')
		frSuovzeY8hZD(I4t9qonjrm.api_python_actions[9])
		if PWUoXkKCxqn1vRtNJsSdp0lBa: tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'MISC_TEMP','EXTRAPYTHONCODE',PWUoXkKCxqn1vRtNJsSdp0lBa,zz2tnLhI1QHV7GwFCrv5)
		RdvzsjKYupa0yB5I3MUCAqmtZPO = EsCplGc5N4mBuYW0RVQt6b
	if PWUoXkKCxqn1vRtNJsSdp0lBa:
		NEW_SITESURLS,NEW_BADSCRAPERS,NEW_BADWEBSITES,NEW_BADCOMMONIDS = {},[],{},[]
		exec(PWUoXkKCxqn1vRtNJsSdp0lBa,globals(),locals())
		I4t9qonjrm.SITESURLS.update(NEW_SITESURLS)
		I4t9qonjrm.BADSCRAPERS = list(set(I4t9qonjrm.BADSCRAPERS+NEW_BADSCRAPERS))
		I4t9qonjrm.BADCOMMONIDS = list(set(I4t9qonjrm.BADCOMMONIDS+NEW_BADCOMMONIDS))
		if KoxvjArhL1TdInDmN9s in list(NEW_BADWEBSITES.keys()): I4t9qonjrm.BADWEBSITES += NEW_BADWEBSITES[KoxvjArhL1TdInDmN9s]
	return RdvzsjKYupa0yB5I3MUCAqmtZPO
def R1Nd6hUaBrtXDnwGxHv30QqA7MF(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW,XsDQkAWCEMaxHV28w1iO,ffWgMXo20Hb5xurkdNqa,ddecO3Tb9U5k,fgVdURyLzPjI,fSRzdU79pPieXuFngrAwE5BovZa):
	NXyHofabZAMSQJCG8 = int(XsDQkAWCEMaxHV28w1iO%10)
	IeGPS8lnjLpR3JKVsOMyhHA9vd = int(XsDQkAWCEMaxHV28w1iO/10)
	dO2WUXLbsnI4w = ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Q1q840Lz62ZxYGCEaRbjtuAFS7siW
	eJGmNyAD8O4n3 = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.menuscache')
	if not eJGmNyAD8O4n3: OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.menuscache','AUTO')
	gYT79cyvtiJkrDNOH = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.status.refresh')
	DDVFlXjdHQsc5nfigO1wPReZSU46 = zrVdcHAuj5Yak2iNQ08EMbwXCZ(ffWgMXo20Hb5xurkdNqa)
	p1xByFhzKZjw8 = [D2D96X5NGamBhrFwvL8VEbqiSfZIl,15,17,19,26,34,50,53]
	SOrmncIxv5VaGh7 = IeGPS8lnjLpR3JKVsOMyhHA9vd not in p1xByFhzKZjw8
	cYyOKSJCrxF80Ip21hMR56sQH = IeGPS8lnjLpR3JKVsOMyhHA9vd in [23,28,71,72]
	DO3uvet6x87mz = XsDQkAWCEMaxHV28w1iO in [265,270]
	cINfX4hoOEB3mzwGVkR5J0v97PxM6 = (SOrmncIxv5VaGh7 or cYyOKSJCrxF80Ip21hMR56sQH) and not DO3uvet6x87mz
	Tinxo5XtmkLIwP = (gYT79cyvtiJkrDNOH or not vBs70HtgMbzd6n3NwUpxe) and gYT79cyvtiJkrDNOH not in ['REFRESH_CACHE']+sqfx3MXEol
	aT3gf8RBNbJC9U = 'type=' in gYT79cyvtiJkrDNOH
	RlWcOjbe4Z = XsDQkAWCEMaxHV28w1iO in [161,162,163,164,165,166,167,168,761,762,763,764,765]
	dPTs3joJiGpzfcWFvQZAa = NXyHofabZAMSQJCG8==9 or XsDQkAWCEMaxHV28w1iO in [145,516,523,45]
	nf8moxb1PWaM3 = not RlWcOjbe4Z
	YOxp6zB0diIk4SC2toZbP = not dPTs3joJiGpzfcWFvQZAa
	RB6up1NIY3yP9U = DDVFlXjdHQsc5nfigO1wPReZSU46 in [fy8iFgEkrO12NR9TWBI35sjY6qHvV,'..']
	tw9sneiXWkY = RB6up1NIY3yP9U or nf8moxb1PWaM3
	VdZE8moGkLwpgn4FrXWU7SR9fxKi = RB6up1NIY3yP9U or YOxp6zB0diIk4SC2toZbP or aT3gf8RBNbJC9U
	kkhsUEtN1rI4PaeXiVgS = XsDQkAWCEMaxHV28w1iO not in [260,261,265,270,330,540,1010]
	if eJGmNyAD8O4n3=='STOP': eKhpCsuJyxiN2rLTWRmG68z = dPTs3joJiGpzfcWFvQZAa or RlWcOjbe4Z
	else: eKhpCsuJyxiN2rLTWRmG68z = EsCplGc5N4mBuYW0RVQt6b
	JLV7ReqYCH4KMa0B = IeGPS8lnjLpR3JKVsOMyhHA9vd in [74,75,108]
	Q5KeuFW1fGjMUNIA0d = XsDQkAWCEMaxHV28w1iO in [280,720]
	p0oHmwOTbz9SuU1a3JN5k = not JLV7ReqYCH4KMa0B and not Q5KeuFW1fGjMUNIA0d
	MqFm5kTRVJ9NcoQlGCY0AW8wbS = tw9sneiXWkY and VdZE8moGkLwpgn4FrXWU7SR9fxKi and kkhsUEtN1rI4PaeXiVgS and eKhpCsuJyxiN2rLTWRmG68z and p0oHmwOTbz9SuU1a3JN5k
	urNS19b7OdGgfW2Ipql36KLFQD = kkhsUEtN1rI4PaeXiVgS and eKhpCsuJyxiN2rLTWRmG68z and p0oHmwOTbz9SuU1a3JN5k
	I9JxgXfkoRy2FL6M5VO = urNS19b7OdGgfW2Ipql36KLFQD
	D4nbjOcvH0RsW3 = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.provider')
	nGtrZ31ym5 = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.language.code')
	JVgroCaZ8cKm6PyWk = LhFAGlQ19zr
	if Tinxo5XtmkLIwP and MqFm5kTRVJ9NcoQlGCY0AW8wbS:
		OOZEpmK56arPzeQlix8GqFL9ko = rIhXWK91vRuC(jUCABmLYMf0G,'list','MENUS_CACHE_'+D4nbjOcvH0RsW3+'_'+nGtrZ31ym5,dO2WUXLbsnI4w)
		if OOZEpmK56arPzeQlix8GqFL9ko:
			Clc8sIj97ZrThF(fy8iFgEkrO12NR9TWBI35sjY6qHvV,'.\tMENUS_CACHE_'+D4nbjOcvH0RsW3+'_'+nGtrZ31ym5+'   Loading menu from cache')
			if aT3gf8RBNbJC9U:
				VTS0ZvXgu4wWAjG9mNltM = []
				from ZJYHCK5167 import ebc0OIJdzPhDw
				from kxdqilYRPe import QDKyWZIiCJRrB,YzSRtv7Zuk1oEf
				BotG7sd8X5f3TJUENyxD9S = ebc0OIJdzPhDw
				ycXpYOMsTHbrqvNGWaoIl3KgJ = QDKyWZIiCJRrB()
				ww2KpJ3oBO4bM = gYT79cyvtiJkrDNOH
				MG5H4kQzA28x,LZg6ue98rGbfd2YoHU,bbiTzdsmeaKpv,ItnLfM2haGO4Rg1XqC,UDF0NMh4oLGVtxcBWHd,JAKyuqDM4YBHXm5RehL,I5hvYDyztNBClLjQG1ei9,ZZ5a4jJyqDKgIkwNv1ET,jlLQ42TniGNH6s = OBw7zQog2DrJlPRZ(ww2KpJ3oBO4bM)
				hqK2dF8HBG = MG5H4kQzA28x,LZg6ue98rGbfd2YoHU,bbiTzdsmeaKpv,ItnLfM2haGO4Rg1XqC,UDF0NMh4oLGVtxcBWHd,JAKyuqDM4YBHXm5RehL,I5hvYDyztNBClLjQG1ei9,fy8iFgEkrO12NR9TWBI35sjY6qHvV,jlLQ42TniGNH6s
				for fHnugaK5vXdpNV7LO28hG1oRPBET4 in OOZEpmK56arPzeQlix8GqFL9ko:
					bf73uMpeklVQTBFay5tmA = fHnugaK5vXdpNV7LO28hG1oRPBET4['menuItem']
					if bf73uMpeklVQTBFay5tmA==hqK2dF8HBG or fHnugaK5vXdpNV7LO28hG1oRPBET4['mode'] in [265,270]:
						fHnugaK5vXdpNV7LO28hG1oRPBET4 = N1QgS5v3HFrtaB(bf73uMpeklVQTBFay5tmA,BotG7sd8X5f3TJUENyxD9S,ycXpYOMsTHbrqvNGWaoIl3KgJ)
						if fHnugaK5vXdpNV7LO28hG1oRPBET4['favorites']:
							EUQ4c7jT6ZhPMWRFmX1OdAsrBzpygt = YzSRtv7Zuk1oEf(ycXpYOMsTHbrqvNGWaoIl3KgJ,bf73uMpeklVQTBFay5tmA,fHnugaK5vXdpNV7LO28hG1oRPBET4['newpath'])
							fHnugaK5vXdpNV7LO28hG1oRPBET4['context_menu'] = EUQ4c7jT6ZhPMWRFmX1OdAsrBzpygt+fHnugaK5vXdpNV7LO28hG1oRPBET4['context_menu']
					VTS0ZvXgu4wWAjG9mNltM.append(fHnugaK5vXdpNV7LO28hG1oRPBET4)
				OdiZIyCfDUsW3JBGR2VAb.setSetting('av.status.refresh',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
				if ZJqDh4ByGPQn13tlzMOTLCNdcugx=='folder': tekGV6ob7fqlFjAL4Z(jUCABmLYMf0G,'MENUS_CACHE_'+D4nbjOcvH0RsW3+'_'+nGtrZ31ym5,dO2WUXLbsnI4w,VTS0ZvXgu4wWAjG9mNltM,CQOaFUrZJHwKRxIj4yXEYs5V)
			else: VTS0ZvXgu4wWAjG9mNltM = OOZEpmK56arPzeQlix8GqFL9ko
			if ZJqDh4ByGPQn13tlzMOTLCNdcugx=='folder' and DDVFlXjdHQsc5nfigO1wPReZSU46!='..' and cINfX4hoOEB3mzwGVkR5J0v97PxM6: l6ZKMsbVcHhp5rmQ34wG()
			JVgroCaZ8cKm6PyWk = KKxbu3MCGsd2YE8p(dO2WUXLbsnI4w,VTS0ZvXgu4wWAjG9mNltM,ddecO3Tb9U5k,fgVdURyLzPjI,fSRzdU79pPieXuFngrAwE5BovZa)
	elif ZJqDh4ByGPQn13tlzMOTLCNdcugx=='folder' and gYT79cyvtiJkrDNOH not in ['REFRESH_CACHE']+sqfx3MXEol and urNS19b7OdGgfW2Ipql36KLFQD:
		gKY2bmAhjzv1qCDpZ876tudHSPwV(jUCABmLYMf0G,'MENUS_CACHE_'+D4nbjOcvH0RsW3+'_'+nGtrZ31ym5,dO2WUXLbsnI4w)
	return JVgroCaZ8cKm6PyWk,gYT79cyvtiJkrDNOH,dO2WUXLbsnI4w,DDVFlXjdHQsc5nfigO1wPReZSU46,cINfX4hoOEB3mzwGVkR5J0v97PxM6,I9JxgXfkoRy2FL6M5VO,D4nbjOcvH0RsW3,nGtrZ31ym5
def KYAmF1b4205(ZJqDh4ByGPQn13tlzMOTLCNdcugx,ekV6UX5gBZsaLHvOMCPF,zzekZcWL1sBgnoxN8f3vdQ0r,mmocwN1frQJ5ST3xa,mmEsSwOKazXLV1MT,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O,vBs70HtgMbzd6n3NwUpxe,Q1q840Lz62ZxYGCEaRbjtuAFS7siW):
	XsDQkAWCEMaxHV28w1iO = int(mmocwN1frQJ5ST3xa)
	IeGPS8lnjLpR3JKVsOMyhHA9vd = int(XsDQkAWCEMaxHV28w1iO//10)
	if   IeGPS8lnjLpR3JKVsOMyhHA9vd==D2D96X5NGamBhrFwvL8VEbqiSfZIl:  from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==BkM54Kr7Qbqn:  from WwGcIojiqf 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==teaC5j4HuGDqpwcmUzJ:  from dEaSvCNWkB 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==XW57OCeGnFTLQbaqdrD9zM:  from aXW3FT7Gys 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==vD4Fh6ictZ7wME:  from unGyMKi4Ya 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,jmI9qRnVJo2a3tpcH8gfYkP)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==hvkue2LYgiOGrtcmxszl4S8MWdnF:  from v0NFe2JTub 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==6:  from XbagVBnzq4 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==7:  from eSXLR24o65 			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==8:  from MMarx62L4F 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==9:  from jNQZuahVSF		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==10: from wwrEgQvVxo 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==11: from drEPv43i0T 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==12: from MhgF6jcSCt 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==13: from bgrumjKSZo		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==14: from jSZ4ngtBFd 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP,ekV6UX5gBZsaLHvOMCPF,mmEsSwOKazXLV1MT)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==15: from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==16: from RlWcOjbe4Z		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==17: from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==18: from YNPmaRFUxH		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==19: from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==20: from Q0QDmxKipe		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==21: from CLOU4duzvl	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==22: from ZZJOksFf51		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==23: from z1qJk2AYoC			import fIaUG2SkWZHyeqP6oluzAN; OmsWt89dSA5HyCZ4wL = fIaUG2SkWZHyeqP6oluzAN(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==24: from tt9rH5O0wE 			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==25: from oTXYuAvz7q 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==26: from ZJYHCK5167 			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==27: from kxdqilYRPe		import fIaUG2SkWZHyeqP6oluzAN; OmsWt89dSA5HyCZ4wL = fIaUG2SkWZHyeqP6oluzAN(XsDQkAWCEMaxHV28w1iO,vBs70HtgMbzd6n3NwUpxe)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==28: from z1qJk2AYoC			import fIaUG2SkWZHyeqP6oluzAN; OmsWt89dSA5HyCZ4wL = fIaUG2SkWZHyeqP6oluzAN(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==29: from MMVdNiZ5gA	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==30: from SfjApdRFxq		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==31: from Av9W2yqQtT		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==32: from yy5BVlcQmu		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==33: from efSANHxoW6		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==34: from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==35: from yyT9dmoRwD		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==36: from p1rgUFG2s4			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==37: from JoD7l3kPLf			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==38: from s8f9q7bOx1 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==39: from XgkoxRdncr		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==40: from PcY8Ww2NmX	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==41: from PcY8Ww2NmX	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==42: from mmSelOD8xV			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==43: from MMD01SrpIK			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==44: from PxuUJ34h6n		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==45: from Z74q9TrC3X		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==46: from UUnxtcWRAf			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==47: from N7YIE4aUZM		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==48: from eURCisO6mN		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==49: from SSNfP6Evbj		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==50: from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==51: from kqRjFsIy5N 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==52: from kqRjFsIy5N 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==53: from ZJYHCK5167 			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==54: from msb3A1OhNH	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,jmI9qRnVJo2a3tpcH8gfYkP)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==55: from YYIUphus1F 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==56: from M1QUuVxPJE		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==57: from VTjvHm9N02		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==58: from oeDTz7nWbL		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==59: from q2H0ZY87Lf		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==60: from VfveLDZA7i			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==61: from LLaFARNgnT			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==62: from s72wqgSmtX		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==63: from BnMcQ5YWox	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==64: from FrSp3B1LEY			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==65: from NsDQMntudz			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==66: from UtYwATChLf			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==67: from llQyzAJViv		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==68: from FhfewgiORp		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==69: from xRILDwOGAa		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==70: from PcJQBUOKfk			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==71: from ucJU0YkpTS			import fIaUG2SkWZHyeqP6oluzAN; OmsWt89dSA5HyCZ4wL = fIaUG2SkWZHyeqP6oluzAN(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==72: from ucJU0YkpTS			import fIaUG2SkWZHyeqP6oluzAN; OmsWt89dSA5HyCZ4wL = fIaUG2SkWZHyeqP6oluzAN(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,ZJqDh4ByGPQn13tlzMOTLCNdcugx,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==73: from R2Ev5bt8kG	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==74: from DjGB7Vn05Q		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==75: from DjGB7Vn05Q		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==76: from RlWcOjbe4Z		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O,jmI9qRnVJo2a3tpcH8gfYkP,Q1q840Lz62ZxYGCEaRbjtuAFS7siW)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==77: from TdGAwqzt94 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==78: from nnHoTMO4Ui 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==79: from xEU5ZyWqcL 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==80: from vahkltGD8L 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==81: from X0YoR9bDWk 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==82: from rzahyA67v3		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,jmI9qRnVJo2a3tpcH8gfYkP,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==83: from uFC7nAD9my		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==84: from J2WoEqGOnM		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==85: from HHlA2yfPdD		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==86: from ppCYXoGzWg		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==87: from wbiB4Ysr26			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==88: from QQiAkKHd5G			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==89: from II0CON7vn9		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==90: from iKmjAO6Wtf	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==91: from fYaBHwnA56		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==92: from kkqxZpmnFj		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==93: from H0WuYz7U69		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==94: from x4xLUBI9Yk			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==95: from FfADpHney9			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==96: from G9FzbdXtPL		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==97: from FNT0fsBqI5		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==98: from JdF7fAMgCH		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==99: from OZAsF1R5Im		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==100: from jj2WXmTKkx		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==101: from rqOfYMzdDH	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==102: from XbdWsnBA9G 		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==103: from Qb1t8OU3jw	import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==104: from z0wisEYa6v		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==105: from OvPzhuR1mE			import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==106: from B7CE13FNJ2		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==107: from Ooh6vs1Frc		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO,zzekZcWL1sBgnoxN8f3vdQ0r,YQDmGRx3CWc2HX9V0wa4O)
	elif IeGPS8lnjLpR3JKVsOMyhHA9vd==108: from DjGB7Vn05Q		import ugbnmWCrLpG9Av0xzocFaB5ew	; OmsWt89dSA5HyCZ4wL = ugbnmWCrLpG9Av0xzocFaB5ew(XsDQkAWCEMaxHV28w1iO)
	else: OmsWt89dSA5HyCZ4wL = None
	return OmsWt89dSA5HyCZ4wL
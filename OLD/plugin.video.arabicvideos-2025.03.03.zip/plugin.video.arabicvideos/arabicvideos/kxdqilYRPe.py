# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
x5TvLsPECHUoaqg1Dl3GwJj = 'FAVORITES'
def fIaUG2SkWZHyeqP6oluzAN(hO3D6GVPY2qENv8bZWH,jQL6sOUpHzC7Vmi):
	if   hO3D6GVPY2qENv8bZWH==270: J5eBhfvXYF20DAOqs7L8l3KaR1 = O1NaXREkVqLJtKy0H86vzSmiP(jQL6sOUpHzC7Vmi)
	else: J5eBhfvXYF20DAOqs7L8l3KaR1 = False
	return J5eBhfvXYF20DAOqs7L8l3KaR1
def UUV61NDj9xlkwbHqiYJzZ7BAWO(R5gQk0ZcerYx3B,jQL6sOUpHzC7Vmi,KE9FP3Xx2R4GlDV70vwL6Zze):
	if not R5gQk0ZcerYx3B: return
	if   KE9FP3Xx2R4GlDV70vwL6Zze=='UP1'	: A5rCxsRiye8T3f(jQL6sOUpHzC7Vmi,True,BkM54Kr7Qbqn)
	elif KE9FP3Xx2R4GlDV70vwL6Zze=='DOWN1'	: A5rCxsRiye8T3f(jQL6sOUpHzC7Vmi,False,BkM54Kr7Qbqn)
	elif KE9FP3Xx2R4GlDV70vwL6Zze=='UP4'	: A5rCxsRiye8T3f(jQL6sOUpHzC7Vmi,True,vD4Fh6ictZ7wME)
	elif KE9FP3Xx2R4GlDV70vwL6Zze=='DOWN4'	: A5rCxsRiye8T3f(jQL6sOUpHzC7Vmi,False,vD4Fh6ictZ7wME)
	elif KE9FP3Xx2R4GlDV70vwL6Zze=='ADD1'	: ZPd9SVhLOw2z1REUkNpytK(jQL6sOUpHzC7Vmi)
	elif KE9FP3Xx2R4GlDV70vwL6Zze=='REMOVE1': fEKCeTwMp1kGmDlgNvQ(jQL6sOUpHzC7Vmi)
	elif KE9FP3Xx2R4GlDV70vwL6Zze=='DELETELIST': xIuOMogzFvtCw4pX(jQL6sOUpHzC7Vmi)
	return
def O1NaXREkVqLJtKy0H86vzSmiP(jQL6sOUpHzC7Vmi):
	GZB1itySUPpYc7zxw6DQr = QDKyWZIiCJRrB()
	if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()):
		try:
			QWXjOmP0qVbAc6oHKM = GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]
			if D2D96X5NGamBhrFwvL8VEbqiSfZIl and jQL6sOUpHzC7Vmi in ['5','11','12','13']:
				for ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW in QWXjOmP0qVbAc6oHKM:
					if ppi24CwDdH3YzVIK8BUyLluQJEMW=='video':
						OZD1l4pAMzeH('video',n0nFOd4yR97fQzNLSW+'تشغيل من الأعلى إلى الأسفل'+T7ASIp1ZYwio9HQ8cObJK,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B)
						OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
						break
			for ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW in QWXjOmP0qVbAc6oHKM:
				OZD1l4pAMzeH(ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW)
		except:
			GZB1itySUPpYc7zxw6DQr = mJE8eLQqtMC9Io6sfHnBKjiDzPwvy(mmFzNZYEJpdqUro7sKMj6W2)
			QWXjOmP0qVbAc6oHKM = GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]
			for ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW in QWXjOmP0qVbAc6oHKM:
				OZD1l4pAMzeH(ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW)
	return
def ZPd9SVhLOw2z1REUkNpytK(jQL6sOUpHzC7Vmi):
	ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW = OBw7zQog2DrJlPRZ(LVXc6WJ3eAoz5hgnyrut1)
	if jQL6sOUpHzC7Vmi in ['5','11','12','13'] and ppi24CwDdH3YzVIK8BUyLluQJEMW!='video':
		GOnZYxartRwkPqMJFub('','','رسالة من المبرمج','هذا العنصر ليس ملف فيديو .. قوائم التشغيل فائدتها تشغيل الفيديوهات خلف بعضها أوتوماتيكيا .. ولهذا قوائم التشغيل يجب أن تحتوي على فيديوهات فقط')
		return
	peZN2cHsq8EP1zALXCyd = ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,IYUEhjmyOzv40iCgxeN8JDPW
	GZB1itySUPpYc7zxw6DQr = QDKyWZIiCJRrB()
	hcnpjTIWYGRbF7 = {}
	for i4eNmBknXpKajyhD9 in list(GZB1itySUPpYc7zxw6DQr.keys()):
		if i4eNmBknXpKajyhD9!=jQL6sOUpHzC7Vmi: hcnpjTIWYGRbF7[i4eNmBknXpKajyhD9] = GZB1itySUPpYc7zxw6DQr[i4eNmBknXpKajyhD9]
		else:
			if z36flodJVD9jWxip14Rh and z36flodJVD9jWxip14Rh!='..':
				ggTDqaM8dyHvr = GZB1itySUPpYc7zxw6DQr[i4eNmBknXpKajyhD9]
				if peZN2cHsq8EP1zALXCyd in ggTDqaM8dyHvr:
					SV8i6HoXJ1xNfcpKyZEBRAL = ggTDqaM8dyHvr.index(peZN2cHsq8EP1zALXCyd)
					del ggTDqaM8dyHvr[SV8i6HoXJ1xNfcpKyZEBRAL]
				vTlBI5ZnbGPCzys6g48AhtSwmDO2u = ggTDqaM8dyHvr+[peZN2cHsq8EP1zALXCyd]
				hcnpjTIWYGRbF7[i4eNmBknXpKajyhD9] = vTlBI5ZnbGPCzys6g48AhtSwmDO2u
			else: hcnpjTIWYGRbF7[i4eNmBknXpKajyhD9] = GZB1itySUPpYc7zxw6DQr[i4eNmBknXpKajyhD9]
	if jQL6sOUpHzC7Vmi not in list(hcnpjTIWYGRbF7.keys()): hcnpjTIWYGRbF7[jQL6sOUpHzC7Vmi] = [peZN2cHsq8EP1zALXCyd]
	UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = str(hcnpjTIWYGRbF7)
	if jTDWgftK7NEmx0JAkOn2aRIvweq: UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p.encode(Tk9eH2qw6Brsuhj)
	open(mmFzNZYEJpdqUro7sKMj6W2,'wb').write(UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p)
	return
def fEKCeTwMp1kGmDlgNvQ(jQL6sOUpHzC7Vmi):
	ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW = OBw7zQog2DrJlPRZ(LVXc6WJ3eAoz5hgnyrut1)
	peZN2cHsq8EP1zALXCyd = ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,IYUEhjmyOzv40iCgxeN8JDPW
	GZB1itySUPpYc7zxw6DQr = QDKyWZIiCJRrB()
	if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()) and peZN2cHsq8EP1zALXCyd in GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]:
		GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi].remove(peZN2cHsq8EP1zALXCyd)
		if len(GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi])==D2D96X5NGamBhrFwvL8VEbqiSfZIl: del GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]
		UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = str(GZB1itySUPpYc7zxw6DQr)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p.encode(Tk9eH2qw6Brsuhj)
		open(mmFzNZYEJpdqUro7sKMj6W2,'wb').write(UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p)
	return
def A5rCxsRiye8T3f(jQL6sOUpHzC7Vmi,LLYgNWGUk7MI1sh5bHT0t6neKdV,A2KpPryqDJvigfFdcTCRnZYL9):
	ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW = OBw7zQog2DrJlPRZ(LVXc6WJ3eAoz5hgnyrut1)
	peZN2cHsq8EP1zALXCyd = ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,fy8iFgEkrO12NR9TWBI35sjY6qHvV,IYUEhjmyOzv40iCgxeN8JDPW
	GZB1itySUPpYc7zxw6DQr = QDKyWZIiCJRrB()
	if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()):
		ggTDqaM8dyHvr = GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]
		if peZN2cHsq8EP1zALXCyd not in ggTDqaM8dyHvr: return
		M06JC7gNv2OmV3ebp8D1IF9ha = len(ggTDqaM8dyHvr)
		for uYA2DJg3vyzpo8IHnVjZ47s in range(D2D96X5NGamBhrFwvL8VEbqiSfZIl,A2KpPryqDJvigfFdcTCRnZYL9):
			YWa5PcRiXMkKQEUdj = ggTDqaM8dyHvr.index(peZN2cHsq8EP1zALXCyd)
			if LLYgNWGUk7MI1sh5bHT0t6neKdV: CS4GuAFzO0bQ6qwrZVx8pfTNU2 = YWa5PcRiXMkKQEUdj-BkM54Kr7Qbqn
			else: CS4GuAFzO0bQ6qwrZVx8pfTNU2 = YWa5PcRiXMkKQEUdj+BkM54Kr7Qbqn
			if CS4GuAFzO0bQ6qwrZVx8pfTNU2>=M06JC7gNv2OmV3ebp8D1IF9ha: CS4GuAFzO0bQ6qwrZVx8pfTNU2 = CS4GuAFzO0bQ6qwrZVx8pfTNU2-M06JC7gNv2OmV3ebp8D1IF9ha
			if CS4GuAFzO0bQ6qwrZVx8pfTNU2<D2D96X5NGamBhrFwvL8VEbqiSfZIl: CS4GuAFzO0bQ6qwrZVx8pfTNU2 = CS4GuAFzO0bQ6qwrZVx8pfTNU2+M06JC7gNv2OmV3ebp8D1IF9ha
			ggTDqaM8dyHvr.insert(CS4GuAFzO0bQ6qwrZVx8pfTNU2, ggTDqaM8dyHvr.pop(YWa5PcRiXMkKQEUdj))
		GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi] = ggTDqaM8dyHvr
		UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = str(GZB1itySUPpYc7zxw6DQr)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p.encode(Tk9eH2qw6Brsuhj)
		open(mmFzNZYEJpdqUro7sKMj6W2,'wb').write(UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p)
	return
def ySlHTG0b9MK18imF6PLxUc4zDJYs3B(jQL6sOUpHzC7Vmi):
	if jQL6sOUpHzC7Vmi in ['1','2','3','4']: ThJB7o9qV2MmUEiZjn,H0FYowXM9BLp3R = 'مفضلة',jQL6sOUpHzC7Vmi
	elif jQL6sOUpHzC7Vmi in ['5']: ThJB7o9qV2MmUEiZjn,H0FYowXM9BLp3R = 'تشغيل','1'
	elif jQL6sOUpHzC7Vmi in ['11']: ThJB7o9qV2MmUEiZjn,H0FYowXM9BLp3R = 'تشغيل','2'
	else: ThJB7o9qV2MmUEiZjn,H0FYowXM9BLp3R = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	WZwcy7OVN6IPtXC0p = ThJB7o9qV2MmUEiZjn+ksJdoFWhxTz8Y2N7bOZE+H0FYowXM9BLp3R
	return WZwcy7OVN6IPtXC0p
def xIuOMogzFvtCw4pX(jQL6sOUpHzC7Vmi):
	WZwcy7OVN6IPtXC0p = ySlHTG0b9MK18imF6PLxUc4zDJYs3B(jQL6sOUpHzC7Vmi)
	P2xUVGmQ3TY1OXK46 = vv7siKgM9IfbCjPNqxXD('center',fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','هل تريد فعلا مسح جميع محتويات قائمة '+WZwcy7OVN6IPtXC0p+' ؟!')
	if P2xUVGmQ3TY1OXK46!=1: return
	GZB1itySUPpYc7zxw6DQr = QDKyWZIiCJRrB()
	if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()):
		del GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]
		UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = str(GZB1itySUPpYc7zxw6DQr)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p = UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p.encode(Tk9eH2qw6Brsuhj)
		open(mmFzNZYEJpdqUro7sKMj6W2,'wb').write(UdqmhWJzDi0gAc2aKRBXkTVNyn5l8p)
		GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'رسالة من المبرمج','تم مسح جميع محتويات قائمة '+WZwcy7OVN6IPtXC0p)
	return
def QDKyWZIiCJRrB():
	GZB1itySUPpYc7zxw6DQr = {}
	if HoxKENAey2MdTt9kDUrVnWGLS0CPa.path.exists(mmFzNZYEJpdqUro7sKMj6W2):
		ReSkhXz6mVnsoO7FCPNDyJ = open(mmFzNZYEJpdqUro7sKMj6W2,'rb').read()
		if jTDWgftK7NEmx0JAkOn2aRIvweq: ReSkhXz6mVnsoO7FCPNDyJ = ReSkhXz6mVnsoO7FCPNDyJ.decode(Tk9eH2qw6Brsuhj)
		GZB1itySUPpYc7zxw6DQr = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('dict',ReSkhXz6mVnsoO7FCPNDyJ)
	return GZB1itySUPpYc7zxw6DQr
def YzSRtv7Zuk1oEf(GZB1itySUPpYc7zxw6DQr,peZN2cHsq8EP1zALXCyd,TiS8XYvRLbs):
	ppi24CwDdH3YzVIK8BUyLluQJEMW,z36flodJVD9jWxip14Rh,eEncXMVB2rNg4JObl3utYfj,hO3D6GVPY2qENv8bZWH,R87NZgODb1jyuxBAScelVivtP2,yy7dsVqg23CI5tbjXlwWmOe,YMaiHbnIThsP7q,R5gQk0ZcerYx3B,IYUEhjmyOzv40iCgxeN8JDPW = peZN2cHsq8EP1zALXCyd
	if not hO3D6GVPY2qENv8bZWH: ppi24CwDdH3YzVIK8BUyLluQJEMW,hO3D6GVPY2qENv8bZWH = 'folder','260'
	oygKIhqbiAGev8M3mupY,jQL6sOUpHzC7Vmi = [],fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if 'context=' in LVXc6WJ3eAoz5hgnyrut1:
		a5zfYBVl3TjtWhdSQOiLgZAvGN = EcQxOa3RJm86WjTKA.findall('context=(\d+)',LVXc6WJ3eAoz5hgnyrut1,EcQxOa3RJm86WjTKA.DOTALL)
		if a5zfYBVl3TjtWhdSQOiLgZAvGN: jQL6sOUpHzC7Vmi = str(a5zfYBVl3TjtWhdSQOiLgZAvGN[D2D96X5NGamBhrFwvL8VEbqiSfZIl])
	if hO3D6GVPY2qENv8bZWH=='270':
		jQL6sOUpHzC7Vmi = R5gQk0ZcerYx3B
		if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()):
			WZwcy7OVN6IPtXC0p = ySlHTG0b9MK18imF6PLxUc4zDJYs3B(jQL6sOUpHzC7Vmi)
			oygKIhqbiAGev8M3mupY.append(('مسح قائمة '+WZwcy7OVN6IPtXC0p,'RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_DELETELIST'+')'))
	else:
		if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()):
			count = len(GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi])
			if count>BkM54Kr7Qbqn: oygKIhqbiAGev8M3mupY.append(('تحريك 1 للأعلى','RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_UP1)'))
			if count>vD4Fh6ictZ7wME: oygKIhqbiAGev8M3mupY.append(('تحريك 4 للأعلى','RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_UP4)'))
			if count>BkM54Kr7Qbqn: oygKIhqbiAGev8M3mupY.append(('تحريك 1 للأسفل','RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_DOWN1)'))
			if count>vD4Fh6ictZ7wME: oygKIhqbiAGev8M3mupY.append(('تحريك 4 للأسفل','RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_DOWN4)'))
		for jQL6sOUpHzC7Vmi in ['1','2','3','4','5','11']:
			WZwcy7OVN6IPtXC0p = ySlHTG0b9MK18imF6PLxUc4zDJYs3B(jQL6sOUpHzC7Vmi)
			if jQL6sOUpHzC7Vmi in list(GZB1itySUPpYc7zxw6DQr.keys()) and peZN2cHsq8EP1zALXCyd in GZB1itySUPpYc7zxw6DQr[jQL6sOUpHzC7Vmi]:
				oygKIhqbiAGev8M3mupY.append(('مسح من '+WZwcy7OVN6IPtXC0p,'RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_REMOVE1)'))
			else: oygKIhqbiAGev8M3mupY.append(('إضافة ل'+WZwcy7OVN6IPtXC0p,'RunPlugin('+TiS8XYvRLbs+'&context='+jQL6sOUpHzC7Vmi+'_ADD1)'))
	Xmeqs0kKTbYBIV6WMtrnwiv8 = []
	for WWmZXtpGPE9rUcdI,CCxNvOtG5FXbiBPTe9Y0aIJ7w in oygKIhqbiAGev8M3mupY:
		WWmZXtpGPE9rUcdI = WydpaVx5YmLoCiIgA34eEBlb+WWmZXtpGPE9rUcdI+T7ASIp1ZYwio9HQ8cObJK
		Xmeqs0kKTbYBIV6WMtrnwiv8.append((WWmZXtpGPE9rUcdI,CCxNvOtG5FXbiBPTe9Y0aIJ7w,))
	return Xmeqs0kKTbYBIV6WMtrnwiv8
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'TVFUN'
K2l9rLfvoXxyZ4NYapO = '_TVF_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
R35TPtuBHk9bDSJ8zlsZIrgA4vd2o = ['بث مباشر']
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text):
	if   mode==460: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==461: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,text)
	elif mode==462: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==463: OmsWt89dSA5HyCZ4wL = eQgbVPaIBvTn8fsjJRt241(url)
	elif mode==469: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'TVFUN-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,469,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"menu-btn"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?<span>(.*?)</span>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if title=='الرئيسية': title = 'جديد حلقات تيفي فان'
			if title in R35TPtuBHk9bDSJ8zlsZIrgA4vd2o: continue
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,461)
	return
def HAsKeZdTbqjPI1WY(url,H1yrgtivdZBUk2NOGx4LncKFSYCWX=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	items = []
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'TVFUN-TITLES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="head-title"(.*?)id="footer"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		cmDaLEqWlT7GhonIdX5k1zHQjSiupe = []
		mmO39lwp0LFUrVT = ['مشاهدة','فيلم','اغنية','كليب','اعلان','هداف','مباراة','عرض','مهرجان','البوم']
		for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
			title = '_MOD_'+title.replace('<br>',ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).strip(ksJdoFWhxTz8Y2N7bOZE)
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			bigdh7fpZYl4aT2keV = U2Z7CVFftTmLeK3nzEbQPGga(bigdh7fpZYl4aT2keV)
			RrzpbE3t9woCk7MXS0GvNdi1BcV = EcQxOa3RJm86WjTKA.findall('(.*?) الحلقة \d+',title,EcQxOa3RJm86WjTKA.DOTALL)
			if any(value in title for value in mmO39lwp0LFUrVT):
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,462,POjaBmHqzpsx1IYw7kQM4R)
			elif RrzpbE3t9woCk7MXS0GvNdi1BcV and 'الحلقة' in title:
				title = '_MOD_' + RrzpbE3t9woCk7MXS0GvNdi1BcV[0]
				if title not in cmDaLEqWlT7GhonIdX5k1zHQjSiupe:
					OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,463,POjaBmHqzpsx1IYw7kQM4R)
					cmDaLEqWlT7GhonIdX5k1zHQjSiupe.append(title)
			else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,463,POjaBmHqzpsx1IYw7kQM4R)
	if H1yrgtivdZBUk2NOGx4LncKFSYCWX!='latest':
		z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if z6PX2p7diaskQElBOvMRNcHwqG5D:
			wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
			items = EcQxOa3RJm86WjTKA.findall('<a href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.strip(ksJdoFWhxTz8Y2N7bOZE)
				if bigdh7fpZYl4aT2keV=="": continue
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
				if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,461)
	return
def eQgbVPaIBvTn8fsjJRt241(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'TVFUN-EPISODES-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="head-title"(.*?)id="footer"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('class="thumb.*?href="(.*?)".*?src="(.*?)" alt="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		if items:
			for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
				title = '_MOD_'+title.replace('<br>',ksJdoFWhxTz8Y2N7bOZE).replace(OOiSqkBcMPptI,ksJdoFWhxTz8Y2N7bOZE).strip(ksJdoFWhxTz8Y2N7bOZE)
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,462,POjaBmHqzpsx1IYw7kQM4R)
		else:
			items = EcQxOa3RJm86WjTKA.findall('class="episode.*?href="(.*?)" title="(.*?)"',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
			for bigdh7fpZYl4aT2keV,title in items:
				if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
				OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,462)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('"pagination"(.*?)</ul>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.strip(ksJdoFWhxTz8Y2N7bOZE)
			if bigdh7fpZYl4aT2keV=="": continue
			if 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if title!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+title,bigdh7fpZYl4aT2keV,463)
	return
def rr7SfotkneX85Klup(url):
	XoSyx7p6dqZ1CF8 = []
	YLKFRH6sSIrznXBg = url.replace('/video/','/watch/')
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(CQOaFUrZJHwKRxIj4yXEYs5V,'GET',YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'TVFUN-PLAY-2nd')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('VideoServers"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		zzECVswWcGAIXhrQlZ7jMokugnv = EcQxOa3RJm86WjTKA.findall('''setVideo\('(.*?)'\).*?">(.*?)<''',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for AApFXTgazQ7leUroY5R,name in zzECVswWcGAIXhrQlZ7jMokugnv:
			AApFXTgazQ7leUroY5R = AApFXTgazQ7leUroY5R[2:]
			if gZlSEJaXO9F461AL3sR7rWNpqf: AApFXTgazQ7leUroY5R = AApFXTgazQ7leUroY5R.decode(Tk9eH2qw6Brsuhj)
			AApFXTgazQ7leUroY5R = JNfHYgOdP9aR.b64decode(AApFXTgazQ7leUroY5R)
			if jTDWgftK7NEmx0JAkOn2aRIvweq: AApFXTgazQ7leUroY5R = AApFXTgazQ7leUroY5R.decode(Tk9eH2qw6Brsuhj)
			bigdh7fpZYl4aT2keV = EcQxOa3RJm86WjTKA.findall('src="(.*?)"',AApFXTgazQ7leUroY5R,EcQxOa3RJm86WjTKA.DOTALL)
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV[0]
			if 'http' not in bigdh7fpZYl4aT2keV:
				if '//' in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = 'http:'+bigdh7fpZYl4aT2keV
				else: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
			if bigdh7fpZYl4aT2keV not in XoSyx7p6dqZ1CF8:
				bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?named='+name+'__watch'
				XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(XoSyx7p6dqZ1CF8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not search: return
	if ksJdoFWhxTz8Y2N7bOZE in search:
		if showDialogs: GOnZYxartRwkPqMJFub(fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'TVFUN موقع تيفي فان','للأسف البحث في هذا الموقع لا يعمل عند طلب أكثر من كلمة واحدة ... يرجى البحث عن كلمة واحدة فقط')
		return
	url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/q/'+search+'/'
	HAsKeZdTbqjPI1WY(url)
	return
# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'YOUTUBE'
K2l9rLfvoXxyZ4NYapO = '_YUT_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
zWJltqIOTLMoQFEBem5nbjxukhf7d1 = 0
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,text,type,jmI9qRnVJo2a3tpcH8gfYkP,name,mmEsSwOKazXLV1MT):
	if	 mode==140: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==141: OmsWt89dSA5HyCZ4wL = MHjL2oftS8r(url,name,mmEsSwOKazXLV1MT)
	elif mode==143: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url,type)
	elif mode==144: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP,text)
	elif mode==145: OmsWt89dSA5HyCZ4wL = zVfXFv9taUlmOjiZR0WPqBDNLdpHy(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==147: OmsWt89dSA5HyCZ4wL = qtfODGihKQwg3yPIY()
	elif mode==148: OmsWt89dSA5HyCZ4wL = SSPws4p8Em()
	elif mode==149: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	if 0:
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'قائمة 1',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/playlist?list=PLDJPKWWTSFaaGNjpDcPUsWZJVePmAYk_E&pp=iAQB',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'قائمة 2',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/playlist?list=PLAj5Gs8FH8ZnUbF0RV-7G3BoqIyZA4uSA',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'شخص',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/user/TCNofficial',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'موقع',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/channel/UCq59aGNsq9bbhwVTq1Utvgw',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'حساب',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/@TheSocialCTV',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'العاب',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/gaming',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'افلام',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/feed/storefront',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مختارات',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/feed/guide_builder',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'قصيرة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/shorts',144,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'تصفح',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/youtubei/v1/guide?key=',144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'رئيسية',BOI3t1w8qfHAb0Kl4oMye7haEWS+fy8iFgEkrO12NR9TWBI35sjY6qHvV,144)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'رائج',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/feed/trending?bp=',144)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,149,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الرائجة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/feed/trending',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'التصفح',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/youtubei/v1/guide?key=',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'القصيرة',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/shorts',144,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مختارات يوتيوب',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/feed/guide_builder',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'مختارات البرنامج',fy8iFgEkrO12NR9TWBI35sjY6qHvV,290)
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: قنوات عربية',fy8iFgEkrO12NR9TWBI35sjY6qHvV,147)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: قنوات أجنبية',fy8iFgEkrO12NR9TWBI35sjY6qHvV,148)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: افلام عربية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=فيلم',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: افلام اجنبية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=movie',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: مسرحيات عربية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=مسرحية',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: مسلسلات عربية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=مسلسل&sp=EgIQAw==',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: مسلسلات اجنبية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=series&sp=EgIQAw==',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: مسلسلات كارتون',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=كارتون&sp=EgIQAw==',144)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث: خطبة المرجعية',BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=قناة+كربلاء+الفضائية+خطبة+الجمعة&sp=CAISAhAB',144)
	return
def MHjL2oftS8r(url,name,mmEsSwOKazXLV1MT):
	name = zrVdcHAuj5Yak2iNQ08EMbwXCZ(name)
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'CHNL:  '+name,url,144,mmEsSwOKazXLV1MT)
	return
def qtfODGihKQwg3yPIY():
	HAsKeZdTbqjPI1WY(BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=قناة+بث&sp=EgJAAQ==')
	return
def SSPws4p8Em():
	HAsKeZdTbqjPI1WY(BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query=tv&sp=EgJAAQ==')
	return
def rr7SfotkneX85Klup(url,type):
	url = url.split('&',1)[0]
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4([url],BfWYUAnyg6eONLjiuE,type,url)
	return
def INJT7Pe5y18C6rRkuLG4cbAWj3nM(qqeLJw2BMasQ4UtGorD,url,KKb4FNO1DIREh):
	level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = KKb4FNO1DIREh.split('::')
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM,RRtEBV3SAHadUq5JLW = [],[]
	if '/youtubei/v1/browse' in url: Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['onResponseReceivedActions']")
	if '/youtubei/v1/search' in url: Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['onResponseReceivedCommands']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	if level=='1': Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['contents']['twoColumnBrowseResultsRenderer']['tabs']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['entries']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['items'][3]['guideSectionRenderer']['items']")
	AoyPzbisawk8dfDRqFEg,cQHqgIMZL6vAWr8OEl0m,MnkPsAOLctx = D76jyVYI2tg(qqeLJw2BMasQ4UtGorD,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	if level=='1' and AoyPzbisawk8dfDRqFEg:
		if len(cQHqgIMZL6vAWr8OEl0m)>1 and 'search_query' not in url:
			for X6HcPU541ZJN2Rk in range(len(cQHqgIMZL6vAWr8OEl0m)):
				hxUVtH09a58mjPvGL3AOdKCykqTcr = str(X6HcPU541ZJN2Rk)
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['reloadContinuationItemsCommand']['continuationItems']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['command']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]")
				ddecO3Tb9U5k,j25T6eKhaMk3,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(cQHqgIMZL6vAWr8OEl0m,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
				if ddecO3Tb9U5k: RRtEBV3SAHadUq5JLW.append([j25T6eKhaMk3,url,'2::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::0::0'])
			Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yccc['continuationEndpoint']")
			ddecO3Tb9U5k,j25T6eKhaMk3,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(qqeLJw2BMasQ4UtGorD,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
			if ddecO3Tb9U5k and RRtEBV3SAHadUq5JLW and 'continuationCommand' in list(j25T6eKhaMk3.keys()):
				bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/my_main_page_shorts_link'
				RRtEBV3SAHadUq5JLW.append([j25T6eKhaMk3,bigdh7fpZYl4aT2keV,'1::0::0::0'])
	return cQHqgIMZL6vAWr8OEl0m,AoyPzbisawk8dfDRqFEg,RRtEBV3SAHadUq5JLW,MnkPsAOLctx
def CxfUtILvSjAKmhNQkRlp5(qqeLJw2BMasQ4UtGorD,cQHqgIMZL6vAWr8OEl0m,url,KKb4FNO1DIREh):
	level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = KKb4FNO1DIREh.split('::')
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM,KMBczaFmsdg = [],[]
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd[0]['itemSectionRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['reloadContinuationItemsCommand']['continuationItems']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd[1]['reloadContinuationItemsCommand']['continuationItems']")
	if '/youtubei/v1/browse' in url: Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd[0]['appendContinuationItemsAction']['continuationItems']")
	elif '/youtubei/v1/search' in url: Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][0]['itemSectionRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['tabRenderer']['content']['sectionListRenderer']['contents']")
	if '/videos' in url or ('/shorts' in url and '/shorts/' not in url):
		Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['tabRenderer']['content']['richGridRenderer']['header']['feedFilterChipBarRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['tabRenderer']['content']['richGridRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['expandableTabRenderer']['content']['sectionListRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd["+hxUVtH09a58mjPvGL3AOdKCykqTcr+"]")
	HyKTpcu89bFSVRmhY7P,HxGqLVXKSg43UNovCOQYaklFu78s,i2iVuxBGJItoSA4DUbjTg = D76jyVYI2tg(cQHqgIMZL6vAWr8OEl0m,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	if level=='2' and HyKTpcu89bFSVRmhY7P:
		if len(HxGqLVXKSg43UNovCOQYaklFu78s)>1:
			for X6HcPU541ZJN2Rk in range(len(HxGqLVXKSg43UNovCOQYaklFu78s)):
				PWmtnrKqk0wa2 = str(X6HcPU541ZJN2Rk)
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['richSectionRenderer']['content']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['header']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['richItemRenderer']['content']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]")
				ddecO3Tb9U5k,j25T6eKhaMk3,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(HxGqLVXKSg43UNovCOQYaklFu78s,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
				if ddecO3Tb9U5k: KMBczaFmsdg.append([j25T6eKhaMk3,url,'3::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::0'])
			Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd[0]['appendContinuationItemsAction']['continuationItems'][1]")
			Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yddd[1]")
			ddecO3Tb9U5k,j25T6eKhaMk3,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(cQHqgIMZL6vAWr8OEl0m,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
			if ddecO3Tb9U5k and KMBczaFmsdg and 'continuationItemRenderer' in list(j25T6eKhaMk3.keys()):
				KMBczaFmsdg.append([j25T6eKhaMk3,url,'3::0::0::0'])
	return HxGqLVXKSg43UNovCOQYaklFu78s,HyKTpcu89bFSVRmhY7P,KMBczaFmsdg,i2iVuxBGJItoSA4DUbjTg
def c3ymDI8OJq(qqeLJw2BMasQ4UtGorD,HxGqLVXKSg43UNovCOQYaklFu78s,url,KKb4FNO1DIREh):
	level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = KKb4FNO1DIREh.split('::')
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM,SfIAeCsW0cP4QrEku = [],[]
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['shelfRenderer']['content']['verticalListRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalMovieListRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['reelShelfRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['horizontalListRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['expandedShelfContentsRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['horizontalCardListRenderer']['cards']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee[0]['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']['gridRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee[0]['itemSectionRenderer']['contents'][0]['gridRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee[0]['itemSectionRenderer']['contents'][0]['playlistVideoListRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['reelShelfRenderer']['items']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee["+PWmtnrKqk0wa2+"]['richSectionRenderer']['content']['richShelfRenderer']['contents']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yeee")
	bEf9C7V3wsvLFrzuDja4mYQgM,mYa62ODX1fbvwAdrFPG,K728KSFTkhHtVqnJXjwBg = D76jyVYI2tg(HxGqLVXKSg43UNovCOQYaklFu78s,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	if level=='3' and bEf9C7V3wsvLFrzuDja4mYQgM:
		if len(mYa62ODX1fbvwAdrFPG)>0:
			for X6HcPU541ZJN2Rk in range(len(mYa62ODX1fbvwAdrFPG)):
				KDEjWcJwPaQBpTebRYlHsIrmh906 = str(X6HcPU541ZJN2Rk)
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yfff["+KDEjWcJwPaQBpTebRYlHsIrmh906+"]['richItemRenderer']['content']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yfff["+KDEjWcJwPaQBpTebRYlHsIrmh906+"]['gameCardRenderer']['game']")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yfff["+KDEjWcJwPaQBpTebRYlHsIrmh906+"]['itemSectionRenderer']['contents'][0]")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yfff["+KDEjWcJwPaQBpTebRYlHsIrmh906+"]")
				Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yfff")
				ddecO3Tb9U5k,j25T6eKhaMk3,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(mYa62ODX1fbvwAdrFPG,fy8iFgEkrO12NR9TWBI35sjY6qHvV,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
				if ddecO3Tb9U5k: SfIAeCsW0cP4QrEku.append([j25T6eKhaMk3,url,'4::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906])
	return mYa62ODX1fbvwAdrFPG,bEf9C7V3wsvLFrzuDja4mYQgM,SfIAeCsW0cP4QrEku,K728KSFTkhHtVqnJXjwBg
def D76jyVYI2tg(co5Qjlkev7zdPm,UwDjzXMGId87,skDvGhAQdf4W1P0CZYrl):
	qqeLJw2BMasQ4UtGorD,UwDjzXMGId87 = co5Qjlkev7zdPm,UwDjzXMGId87
	cQHqgIMZL6vAWr8OEl0m,UwDjzXMGId87 = co5Qjlkev7zdPm,UwDjzXMGId87
	HxGqLVXKSg43UNovCOQYaklFu78s,UwDjzXMGId87 = co5Qjlkev7zdPm,UwDjzXMGId87
	mYa62ODX1fbvwAdrFPG,UwDjzXMGId87 = co5Qjlkev7zdPm,UwDjzXMGId87
	j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO = co5Qjlkev7zdPm,UwDjzXMGId87
	count = len(skDvGhAQdf4W1P0CZYrl)
	for b3b24XZTV7gW9mhcqLoCnftO in range(count):
		try:
			CrKe9blRyO12DvnF = eval(skDvGhAQdf4W1P0CZYrl[b3b24XZTV7gW9mhcqLoCnftO])
			return True,CrKe9blRyO12DvnF,b3b24XZTV7gW9mhcqLoCnftO+1
		except: pass
	return False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,0
def HAsKeZdTbqjPI1WY(url,KKb4FNO1DIREh=fy8iFgEkrO12NR9TWBI35sjY6qHvV,data=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	RRtEBV3SAHadUq5JLW,KMBczaFmsdg,SfIAeCsW0cP4QrEku = [],[],[]
	if '::' not in KKb4FNO1DIREh: KKb4FNO1DIREh = '1::0::0::0'
	level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = KKb4FNO1DIREh.split('::')
	if level=='4': level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = '1',hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906
	data = data.replace('_REMEMBERRESULTS_',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	FGRX4myP68S,qqeLJw2BMasQ4UtGorD,gWBLDSlZGwqxHT = LJWPUsBHmAVRYC(url,data)
	KKb4FNO1DIREh = level+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
	if level in ['1','2','3']:
		cQHqgIMZL6vAWr8OEl0m,AoyPzbisawk8dfDRqFEg,RRtEBV3SAHadUq5JLW,MnkPsAOLctx = INJT7Pe5y18C6rRkuLG4cbAWj3nM(qqeLJw2BMasQ4UtGorD,url,KKb4FNO1DIREh)
		if not AoyPzbisawk8dfDRqFEg: return
		mOj9NtcpaZbFh = len(RRtEBV3SAHadUq5JLW)
		if mOj9NtcpaZbFh<2:
			if level=='1': level = '2'
			RRtEBV3SAHadUq5JLW = []
	KKb4FNO1DIREh = level+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
	if level in ['2','3']:
		HxGqLVXKSg43UNovCOQYaklFu78s,HyKTpcu89bFSVRmhY7P,KMBczaFmsdg,i2iVuxBGJItoSA4DUbjTg = CxfUtILvSjAKmhNQkRlp5(qqeLJw2BMasQ4UtGorD,cQHqgIMZL6vAWr8OEl0m,url,KKb4FNO1DIREh)
		if not HyKTpcu89bFSVRmhY7P: return
		RRazcum7LbQlVr = len(KMBczaFmsdg)
		if RRazcum7LbQlVr<2:
			if level=='2': level = '3'
			KMBczaFmsdg = []
	KKb4FNO1DIREh = level+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
	if level in ['3']:
		mYa62ODX1fbvwAdrFPG,bEf9C7V3wsvLFrzuDja4mYQgM,SfIAeCsW0cP4QrEku,K728KSFTkhHtVqnJXjwBg = c3ymDI8OJq(qqeLJw2BMasQ4UtGorD,HxGqLVXKSg43UNovCOQYaklFu78s,url,KKb4FNO1DIREh)
		if not bEf9C7V3wsvLFrzuDja4mYQgM: return
		EfdpGJU0yNcSbAKVtTLj = len(SfIAeCsW0cP4QrEku)
	for j25T6eKhaMk3,url,KKb4FNO1DIREh in RRtEBV3SAHadUq5JLW+KMBczaFmsdg+SfIAeCsW0cP4QrEku:
		ooysU7CDBeL3Apinrm = SiYsGFkef5Vmzb1(j25T6eKhaMk3,url,KKb4FNO1DIREh)
	return
def SiYsGFkef5Vmzb1(j25T6eKhaMk3,url=fy8iFgEkrO12NR9TWBI35sjY6qHvV,KKb4FNO1DIREh=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if '::' in KKb4FNO1DIREh: level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = KKb4FNO1DIREh.split('::')
	else: level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = '1','0','0','0'
	ddecO3Tb9U5k,title,bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,count,rQ0jN7XkZPE1AYU,N7ydZj0Ext2eF4HTJWmkaq3XcwgD,A2kTwJ6oEgtPUXueviz,Ql9GjsetX8hbWyivnuONDRfL0wqA = cOwWTUZIvtlFhkEgom72Gx8e(j25T6eKhaMk3)
	f1KUbrwHDVWCgTLvaAelE = '/videos?' in bigdh7fpZYl4aT2keV or '/streams?' in bigdh7fpZYl4aT2keV or '/playlists?' in bigdh7fpZYl4aT2keV
	d4UPnf0xymp5uoAe1EFNklW = '/channels?' in bigdh7fpZYl4aT2keV or '/shorts?' in bigdh7fpZYl4aT2keV
	if f1KUbrwHDVWCgTLvaAelE or d4UPnf0xymp5uoAe1EFNklW: bigdh7fpZYl4aT2keV = url
	f1KUbrwHDVWCgTLvaAelE = 'watch?v=' not in bigdh7fpZYl4aT2keV and '/playlist?list=' not in bigdh7fpZYl4aT2keV
	d4UPnf0xymp5uoAe1EFNklW = '/gaming' not in bigdh7fpZYl4aT2keV  and '/feed/storefront' not in bigdh7fpZYl4aT2keV
	if KKb4FNO1DIREh[0:5]=='3::0::' and f1KUbrwHDVWCgTLvaAelE and d4UPnf0xymp5uoAe1EFNklW: bigdh7fpZYl4aT2keV = url
	if '/youtubei/v1/guide?key=' in url or '/gaming' in bigdh7fpZYl4aT2keV:
		level,hxUVtH09a58mjPvGL3AOdKCykqTcr,PWmtnrKqk0wa2,KDEjWcJwPaQBpTebRYlHsIrmh906 = '1','0','0','0'
		KKb4FNO1DIREh = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	gWBLDSlZGwqxHT = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if '/youtubei/v1/browse' in bigdh7fpZYl4aT2keV or '/youtubei/v1/search' in bigdh7fpZYl4aT2keV or '/my_main_page_shorts_link' in url:
		data = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.youtube.data')
		if data.count(':::')==4:
			vXpUr18ekh,key,g4G0lU8YAsCM6zJ2VWZvxSBajf,GcEzuAdmtO430,eDi4j5Usrp = data.split(':::')
			gWBLDSlZGwqxHT = vXpUr18ekh+':::'+key+':::'+g4G0lU8YAsCM6zJ2VWZvxSBajf+':::'+GcEzuAdmtO430+':::'+Ql9GjsetX8hbWyivnuONDRfL0wqA
			if '/my_main_page_shorts_link' in url and not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = url
			else: bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV+'?key='+key
	if not title:
		global zWJltqIOTLMoQFEBem5nbjxukhf7d1
		zWJltqIOTLMoQFEBem5nbjxukhf7d1 += 1
		title = 'فيديوهات '+str(zWJltqIOTLMoQFEBem5nbjxukhf7d1)
		KKb4FNO1DIREh = '3'+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
	if not ddecO3Tb9U5k: return False
	elif 'searchPyvRenderer' in str(j25T6eKhaMk3): return False
	elif '/about' in bigdh7fpZYl4aT2keV: return False
	elif '/community' in bigdh7fpZYl4aT2keV: return False
	elif 'continuationItemRenderer' in list(j25T6eKhaMk3.keys()) or 'continuationCommand' in list(j25T6eKhaMk3.keys()):
		if int(level)>1: level = str(int(level)-1)
		KKb4FNO1DIREh = level+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+':: '+'صفحة أخرى',bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh,gWBLDSlZGwqxHT)
	elif '/search' in bigdh7fpZYl4aT2keV:
		title = ':: '+title
		KKb4FNO1DIREh = '3'+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
		url = url.replace('/search',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,145,fy8iFgEkrO12NR9TWBI35sjY6qHvV,KKb4FNO1DIREh,'_REMEMBERRESULTS_')
	elif 'search_query' in url and not bigdh7fpZYl4aT2keV:
		KKb4FNO1DIREh = '3'+'::'+hxUVtH09a58mjPvGL3AOdKCykqTcr+'::'+PWmtnrKqk0wa2+'::'+KDEjWcJwPaQBpTebRYlHsIrmh906
		title = ':: '+title
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh,gWBLDSlZGwqxHT)
	elif '/browse' in bigdh7fpZYl4aT2keV and url==BOI3t1w8qfHAb0Kl4oMye7haEWS:
		title = ':: '+title
		KKb4FNO1DIREh = '2::0::0::0'
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh,gWBLDSlZGwqxHT)
	elif not bigdh7fpZYl4aT2keV and 'horizontalMovieListRenderer' in str(j25T6eKhaMk3):
		title = ':: '+title
		KKb4FNO1DIREh = '3::0::0::0'
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,url,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh)
	elif 'messageRenderer' in str(j25T6eKhaMk3):
		OZD1l4pAMzeH('link',K2l9rLfvoXxyZ4NYapO+title,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	elif N7ydZj0Ext2eF4HTJWmkaq3XcwgD:
		OZD1l4pAMzeH('live',K2l9rLfvoXxyZ4NYapO+N7ydZj0Ext2eF4HTJWmkaq3XcwgD+title,bigdh7fpZYl4aT2keV,143,POjaBmHqzpsx1IYw7kQM4R)
	elif '/playlist?list=' in bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('&playnext=1',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'LIST'+count+':  '+title,bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh)
	elif '/shorts/' in bigdh7fpZYl4aT2keV:
		bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('&list=',1)[0]
		OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,143,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
	elif '/watch?v=' in bigdh7fpZYl4aT2keV:
		if '&list=' in bigdh7fpZYl4aT2keV and count:
			Hnpc31XUT6GLvEz4o78qRydD = bigdh7fpZYl4aT2keV.split('&list=',1)[1]
			bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/playlist?list='+Hnpc31XUT6GLvEz4o78qRydD
			KKb4FNO1DIREh = '1::0::0::0'
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'LIST'+count+':  '+title,bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh)
		else:
			bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.split('&list=',1)[0]
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,143,POjaBmHqzpsx1IYw7kQM4R,rQ0jN7XkZPE1AYU)
	elif '/channel/' in bigdh7fpZYl4aT2keV or '/c/' in bigdh7fpZYl4aT2keV or ('/@' in bigdh7fpZYl4aT2keV and bigdh7fpZYl4aT2keV.count('/')==3):
		if gZlSEJaXO9F461AL3sR7rWNpqf:
			title = title.decode(Tk9eH2qw6Brsuhj).encode('raw_unicode_escape')
			title = XXcPiylRDh6IapYA25rwO8u(title)
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'CHNL'+count+':  '+title,bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh)
	elif '/user/' in bigdh7fpZYl4aT2keV:
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'USER'+count+':  '+title,bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh)
	else:
		if not bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = url
		title = ':: '+title
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,144,POjaBmHqzpsx1IYw7kQM4R,KKb4FNO1DIREh,gWBLDSlZGwqxHT)
	return True
def cOwWTUZIvtlFhkEgom72Gx8e(j25T6eKhaMk3):
	ddecO3Tb9U5k,title,bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,count,rQ0jN7XkZPE1AYU,N7ydZj0Ext2eF4HTJWmkaq3XcwgD,A2kTwJ6oEgtPUXueviz,eDi4j5Usrp = False,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if not isinstance(j25T6eKhaMk3,dict): return ddecO3Tb9U5k,title,bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,count,rQ0jN7XkZPE1AYU,N7ydZj0Ext2eF4HTJWmkaq3XcwgD,A2kTwJ6oEgtPUXueviz,eDi4j5Usrp
	for EEhWqs7R2QHT in list(j25T6eKhaMk3.keys()):
		dGqoH6yQTxvzg9MCESsmDb3PO = j25T6eKhaMk3[EEhWqs7R2QHT]
		if isinstance(dGqoH6yQTxvzg9MCESsmDb3PO,dict): break
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['header']['playlistHeaderRenderer']['title']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['header']['richListHeaderRenderer']['title']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['header']['richListHeaderRenderer']['title']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['headline']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['unplayableText']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['formattedTitle']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['title']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['title']['runs'][0]['text']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['text']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['text']['runs'][0]['text']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['title']['content']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['title']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("item['title']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("item['reelWatchEndpoint']['videoId']")
	ddecO3Tb9U5k,title,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['title']['runs'][0]['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['continuationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['navigationEndpoint']['commandMetadata']['webCommandMetadata']['apiUrl']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("item['endpoint']['commandMetadata']['webCommandMetadata']['url']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("item['commandMetadata']['webCommandMetadata']['url']")
	ddecO3Tb9U5k,bigdh7fpZYl4aT2keV,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnail']['thumbnails'][0]['url']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnails'][0]['thumbnails'][0]['url']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("item['reelWatchEndpoint']['thumbnail']['thumbnails'][0]['url']")
	ddecO3Tb9U5k,POjaBmHqzpsx1IYw7kQM4R,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayBottomPanelRenderer']['text']['runs'][0]['text']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['videoCountShortText']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['videoCountText']['runs'][0]['text']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['videoCount']")
	ddecO3Tb9U5k,count,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['runs'][0]['text']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['text']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['lengthText']['simpleText']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['icon']['iconType']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['thumbnailOverlays'][0]['thumbnailOverlayTimeStatusRenderer']['style']")
	ddecO3Tb9U5k,rQ0jN7XkZPE1AYU,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM = []
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['navigationEndpoint']['continuationCommand']['token']")
	Vnrdyp910tCmH4ko8gfIXcZGOvKqiM.append("yrender['continuationEndpoint']['continuationCommand']['token']")
	ddecO3Tb9U5k,eDi4j5Usrp,hdmfg3T7CarEeB6lyYGN4kxw = D76jyVYI2tg(j25T6eKhaMk3,dGqoH6yQTxvzg9MCESsmDb3PO,Vnrdyp910tCmH4ko8gfIXcZGOvKqiM)
	if 'LIVE' in rQ0jN7XkZPE1AYU: rQ0jN7XkZPE1AYU,N7ydZj0Ext2eF4HTJWmkaq3XcwgD = fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVE:  '
	if 'مباشر' in rQ0jN7XkZPE1AYU: rQ0jN7XkZPE1AYU,N7ydZj0Ext2eF4HTJWmkaq3XcwgD = fy8iFgEkrO12NR9TWBI35sjY6qHvV,'LIVE:  '
	if 'badges' in list(dGqoH6yQTxvzg9MCESsmDb3PO.keys()):
		IiESm41g9utALz6Cjo2BaDcRysh = str(dGqoH6yQTxvzg9MCESsmDb3PO['badges'])
		if 'Free with Ads' in IiESm41g9utALz6Cjo2BaDcRysh: A2kTwJ6oEgtPUXueviz = '$:  '
		if 'LIVE' in IiESm41g9utALz6Cjo2BaDcRysh: N7ydZj0Ext2eF4HTJWmkaq3XcwgD = 'LIVE:  '
		if 'Buy' in IiESm41g9utALz6Cjo2BaDcRysh or 'Rent' in IiESm41g9utALz6Cjo2BaDcRysh: A2kTwJ6oEgtPUXueviz = '$$:  '
		if bL7jBNOF9MK(u'مباشر') in IiESm41g9utALz6Cjo2BaDcRysh: N7ydZj0Ext2eF4HTJWmkaq3XcwgD = 'LIVE:  '
		if bL7jBNOF9MK(u'شراء') in IiESm41g9utALz6Cjo2BaDcRysh: A2kTwJ6oEgtPUXueviz = '$$:  '
		if bL7jBNOF9MK(u'استئجار') in IiESm41g9utALz6Cjo2BaDcRysh: A2kTwJ6oEgtPUXueviz = '$$:  '
		if bL7jBNOF9MK(u'إعلانات') in IiESm41g9utALz6Cjo2BaDcRysh: A2kTwJ6oEgtPUXueviz = '$:  '
	bigdh7fpZYl4aT2keV = XXcPiylRDh6IapYA25rwO8u(bigdh7fpZYl4aT2keV)
	if bigdh7fpZYl4aT2keV and 'http' not in bigdh7fpZYl4aT2keV: bigdh7fpZYl4aT2keV = BOI3t1w8qfHAb0Kl4oMye7haEWS+bigdh7fpZYl4aT2keV
	POjaBmHqzpsx1IYw7kQM4R = POjaBmHqzpsx1IYw7kQM4R.split('?')[0]
	if  POjaBmHqzpsx1IYw7kQM4R and 'http' not in POjaBmHqzpsx1IYw7kQM4R: POjaBmHqzpsx1IYw7kQM4R = 'https:'+POjaBmHqzpsx1IYw7kQM4R
	title = XXcPiylRDh6IapYA25rwO8u(title)
	if A2kTwJ6oEgtPUXueviz: title = A2kTwJ6oEgtPUXueviz+title
	rQ0jN7XkZPE1AYU = rQ0jN7XkZPE1AYU.replace(',',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	count = count.replace(',',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
	count = EcQxOa3RJm86WjTKA.findall('\d+',count)
	if count: count = count[0]
	else: count = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	return True,title,bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,count,rQ0jN7XkZPE1AYU,N7ydZj0Ext2eF4HTJWmkaq3XcwgD,A2kTwJ6oEgtPUXueviz,eDi4j5Usrp
def LJWPUsBHmAVRYC(url,data=fy8iFgEkrO12NR9TWBI35sjY6qHvV,Bc7G3ur2Tw5QK1fPSkyJ=fy8iFgEkrO12NR9TWBI35sjY6qHvV):
	if Bc7G3ur2Tw5QK1fPSkyJ==fy8iFgEkrO12NR9TWBI35sjY6qHvV: Bc7G3ur2Tw5QK1fPSkyJ = 'ytInitialData'
	ll7qCX4wJ5kQonVW6KtcMuZGSvDEs = j4lUV5BzHDI6EN()
	naBFTDfp6lmKjeOywg87IAcb = {'User-Agent':ll7qCX4wJ5kQonVW6KtcMuZGSvDEs,'Cookie':'PREF=hl=ar'}
	global OdiZIyCfDUsW3JBGR2VAb
	if not data: data = OdiZIyCfDUsW3JBGR2VAb.getSetting('av.youtube.data')
	if data.count(':::')==4: vXpUr18ekh,key,g4G0lU8YAsCM6zJ2VWZvxSBajf,GcEzuAdmtO430,eDi4j5Usrp = data.split(':::')
	else: vXpUr18ekh,key,g4G0lU8YAsCM6zJ2VWZvxSBajf,GcEzuAdmtO430,eDi4j5Usrp = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	gWBLDSlZGwqxHT = {"context":{"client":{"hl":"ar","clientName":"WEB","clientVersion":g4G0lU8YAsCM6zJ2VWZvxSBajf}}}
	if url==BOI3t1w8qfHAb0Kl4oMye7haEWS+'/shorts' or '/my_main_page_shorts_link' in url:
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/youtubei/v1/reel/reel_watch_sequence'+'?key='+key
		gWBLDSlZGwqxHT['sequenceParams'] = vXpUr18ekh
		gWBLDSlZGwqxHT = str(gWBLDSlZGwqxHT)
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',url,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,True,True,'YOUTUBE-GET_PAGE_DATA-1st')
	elif '/guide?key=' in url:
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/youtubei/v1/guide?key='+key
		gWBLDSlZGwqxHT = str(gWBLDSlZGwqxHT)
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',url,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,True,True,'YOUTUBE-GET_PAGE_DATA-3rd')
	elif 'key=' in url and vXpUr18ekh:
		gWBLDSlZGwqxHT['continuation'] = eDi4j5Usrp
		gWBLDSlZGwqxHT['context']['client']['visitorData'] = vXpUr18ekh
		gWBLDSlZGwqxHT = str(gWBLDSlZGwqxHT)
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'POST',url,gWBLDSlZGwqxHT,naBFTDfp6lmKjeOywg87IAcb,True,True,'YOUTUBE-GET_PAGE_DATA-4th')
	elif 'ctoken=' in url and GcEzuAdmtO430:
		naBFTDfp6lmKjeOywg87IAcb.update({'X-YouTube-Client-Name':'1','X-YouTube-Client-Version':g4G0lU8YAsCM6zJ2VWZvxSBajf})
		naBFTDfp6lmKjeOywg87IAcb.update({'Cookie':'VISITOR_INFO1_LIVE='+GcEzuAdmtO430})
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'YOUTUBE-GET_PAGE_DATA-5th')
	else:
		E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(d9vcuo3Hy7RhAk2,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,naBFTDfp6lmKjeOywg87IAcb,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'YOUTUBE-GET_PAGE_DATA-6th')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	vY3c0hwATVGP7dn8bHCig6 = EcQxOa3RJm86WjTKA.findall('"innertubeApiKey".*?"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.I)
	if vY3c0hwATVGP7dn8bHCig6: key = vY3c0hwATVGP7dn8bHCig6[0]
	vY3c0hwATVGP7dn8bHCig6 = EcQxOa3RJm86WjTKA.findall('"cver".*?"value".*?"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.I)
	if vY3c0hwATVGP7dn8bHCig6: g4G0lU8YAsCM6zJ2VWZvxSBajf = vY3c0hwATVGP7dn8bHCig6[0]
	vY3c0hwATVGP7dn8bHCig6 = EcQxOa3RJm86WjTKA.findall('"visitorData".*?"(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL|EcQxOa3RJm86WjTKA.I)
	if vY3c0hwATVGP7dn8bHCig6: vXpUr18ekh = vY3c0hwATVGP7dn8bHCig6[0]
	cookies = E6ECvznP9m5sWFMu.cookies
	if 'VISITOR_INFO1_LIVE' in list(cookies.keys()): GcEzuAdmtO430 = cookies['VISITOR_INFO1_LIVE']
	LLd3n6b1OUJPCVYvtc2yMSp5 = vXpUr18ekh+':::'+key+':::'+g4G0lU8YAsCM6zJ2VWZvxSBajf+':::'+GcEzuAdmtO430+':::'+eDi4j5Usrp
	if Bc7G3ur2Tw5QK1fPSkyJ=='ytInitialData' and 'ytInitialData' in FGRX4myP68S:
		NKjzyqH9tfRlQZ53ge2Ok6ap = EcQxOa3RJm86WjTKA.findall('window\["ytInitialData"\] = ({.*?});',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		if not NKjzyqH9tfRlQZ53ge2Ok6ap: NKjzyqH9tfRlQZ53ge2Ok6ap = EcQxOa3RJm86WjTKA.findall('var ytInitialData = ({.*?});',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		EFkJ0Rv41ysKanIjSxezZ8LMQHbhGP = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('str',NKjzyqH9tfRlQZ53ge2Ok6ap[0])
	elif Bc7G3ur2Tw5QK1fPSkyJ=='ytInitialGuideData' and 'ytInitialGuideData' in FGRX4myP68S:
		NKjzyqH9tfRlQZ53ge2Ok6ap = EcQxOa3RJm86WjTKA.findall('var ytInitialGuideData = ({.*?});',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		EFkJ0Rv41ysKanIjSxezZ8LMQHbhGP = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('str',NKjzyqH9tfRlQZ53ge2Ok6ap[0])
	elif '</script>' not in FGRX4myP68S: EFkJ0Rv41ysKanIjSxezZ8LMQHbhGP = LB7TcZnGYdfw5lWU1RH3Oztu9PyA('str',FGRX4myP68S)
	else: EFkJ0Rv41ysKanIjSxezZ8LMQHbhGP = fy8iFgEkrO12NR9TWBI35sjY6qHvV
	if 0:
		qqeLJw2BMasQ4UtGorD = str(EFkJ0Rv41ysKanIjSxezZ8LMQHbhGP)
		if jTDWgftK7NEmx0JAkOn2aRIvweq: qqeLJw2BMasQ4UtGorD = qqeLJw2BMasQ4UtGorD.encode(Tk9eH2qw6Brsuhj)
		open('S:\\0000emad.dat','wb').write(qqeLJw2BMasQ4UtGorD)
	OdiZIyCfDUsW3JBGR2VAb.setSetting('av.youtube.data',LLd3n6b1OUJPCVYvtc2yMSp5)
	return FGRX4myP68S,EFkJ0Rv41ysKanIjSxezZ8LMQHbhGP,LLd3n6b1OUJPCVYvtc2yMSp5
def zVfXFv9taUlmOjiZR0WPqBDNLdpHy(url,KKb4FNO1DIREh):
	search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if not search: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	YLKFRH6sSIrznXBg = url+'/search?query='+search
	HAsKeZdTbqjPI1WY(YLKFRH6sSIrznXBg,KKb4FNO1DIREh)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if not search:
		search = GFYl1tsoOkHC0Ajeur8JQiMx()
		if not search: return
	search = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	YLKFRH6sSIrznXBg = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/results?search_query='+search
	if not showDialogs:
		if '_YOUTUBE-VIDEOS_' in yJWh5lC4wcNrRi3nFa: UrDK87R9su = '&sp=EgIQAQ%253D%253D'
		elif '_YOUTUBE-PLAYLISTS_' in yJWh5lC4wcNrRi3nFa: UrDK87R9su = '&sp=EgIQAw%253D%253D'
		elif '_YOUTUBE-CHANNELS_' in yJWh5lC4wcNrRi3nFa: UrDK87R9su = '&sp=EgIQAg%253D%253D'
		else: UrDK87R9su = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		MYWwFs7XA2 = YLKFRH6sSIrznXBg+UrDK87R9su
	else:
		DXAmMNZHfJ2z7YduQvEjwhRknxp6L,ONtX67xIh9KikwTm20dPDcyoH,D4DQ6k0oS39GKbZrthnsTB = [],[],fy8iFgEkrO12NR9TWBI35sjY6qHvV
		TMF3eqQZW8lAKfI = ['فيديوهات مرتبة بالصلة','فيديوهات مرتبة بالتاريخ','فيديوهات مرتبة بعدد المشاهدات','فيديوهات مرتبة بالتقييم','(جيد للمسلسلات) قوائم تشغيل','قنوات','بث حي']
		L8EatSpUzVde2k6ox7qvb1s4Hu = ['&sp=CAASAhAB','&sp=CAISAhAB','&sp=CAMSAhAB','&sp=CAESAhAB','&sp=EgIQAw==','&sp=EgIQAg==','&sp=EgJAAQ==']
		xvmA2s4f3bQY0TkjO891 = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('اختر البحث المناسب',TMF3eqQZW8lAKfI)
		if xvmA2s4f3bQY0TkjO891 == -1: return
		O0HClwySfRNn5iKugqZjPzXrAh2B = L8EatSpUzVde2k6ox7qvb1s4Hu[xvmA2s4f3bQY0TkjO891]
		FGRX4myP68S,kRJ1Vcs2N9,data = LJWPUsBHmAVRYC(YLKFRH6sSIrznXBg+O0HClwySfRNn5iKugqZjPzXrAh2B)
		if kRJ1Vcs2N9:
			try:
				tDzBPWiUEAhnX5CyGKYLq = kRJ1Vcs2N9['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['subMenu']['searchSubMenuRenderer']['groups']
				for Qi8e2zD3UZaduMWcYhTXPyt in range(len(tDzBPWiUEAhnX5CyGKYLq)):
					group = tDzBPWiUEAhnX5CyGKYLq[Qi8e2zD3UZaduMWcYhTXPyt]['searchFilterGroupRenderer']['filters']
					for E89HIycZgPbi0C7SmhYAt in range(len(group)):
						dGqoH6yQTxvzg9MCESsmDb3PO = group[E89HIycZgPbi0C7SmhYAt]['searchFilterRenderer']
						if 'navigationEndpoint' in list(dGqoH6yQTxvzg9MCESsmDb3PO.keys()):
							bigdh7fpZYl4aT2keV = dGqoH6yQTxvzg9MCESsmDb3PO['navigationEndpoint']['commandMetadata']['webCommandMetadata']['url']
							bigdh7fpZYl4aT2keV = bigdh7fpZYl4aT2keV.replace('\u0026','&')
							title = dGqoH6yQTxvzg9MCESsmDb3PO['tooltip']
							title = title.replace('البحث عن ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
							if 'إزالة الفلتر' in title: continue
							if 'قائمة تشغيل' in title:
								title = 'جيد للمسلسلات '+title
								D4DQ6k0oS39GKbZrthnsTB = title
								R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = bigdh7fpZYl4aT2keV
							if 'ترتيب حسب' in title: continue
							title = title.replace('Search for ',fy8iFgEkrO12NR9TWBI35sjY6qHvV)
							if 'Remove' in title: continue
							if 'Playlist' in title:
								title = 'جيد للمسلسلات '+title
								D4DQ6k0oS39GKbZrthnsTB = title
								R9b8gUvoB4wOfkTIjlEsZrM5LtinpS = bigdh7fpZYl4aT2keV
							if 'Sort by' in title: continue
							DXAmMNZHfJ2z7YduQvEjwhRknxp6L.append(XXcPiylRDh6IapYA25rwO8u(title))
							ONtX67xIh9KikwTm20dPDcyoH.append(bigdh7fpZYl4aT2keV)
			except: pass
		if not D4DQ6k0oS39GKbZrthnsTB: Bu8ElsnM1SQa60oFJwYLxrR5KbP = fy8iFgEkrO12NR9TWBI35sjY6qHvV
		else:
			DXAmMNZHfJ2z7YduQvEjwhRknxp6L = ['بدون فلتر',D4DQ6k0oS39GKbZrthnsTB]+DXAmMNZHfJ2z7YduQvEjwhRknxp6L
			ONtX67xIh9KikwTm20dPDcyoH = [fy8iFgEkrO12NR9TWBI35sjY6qHvV,R9b8gUvoB4wOfkTIjlEsZrM5LtinpS]+ONtX67xIh9KikwTm20dPDcyoH
			xIZf5dzWCg6LPwGORTVHAJXptN3S = qYUPXpmOCTk9byoAGKieDQZ8u41J3S('موقع يوتيوب - اختر الفلتر',DXAmMNZHfJ2z7YduQvEjwhRknxp6L)
			if xIZf5dzWCg6LPwGORTVHAJXptN3S == -1: return
			Bu8ElsnM1SQa60oFJwYLxrR5KbP = ONtX67xIh9KikwTm20dPDcyoH[xIZf5dzWCg6LPwGORTVHAJXptN3S]
		if Bu8ElsnM1SQa60oFJwYLxrR5KbP: MYWwFs7XA2 = BOI3t1w8qfHAb0Kl4oMye7haEWS+Bu8ElsnM1SQa60oFJwYLxrR5KbP
		elif O0HClwySfRNn5iKugqZjPzXrAh2B: MYWwFs7XA2 = YLKFRH6sSIrznXBg+O0HClwySfRNn5iKugqZjPzXrAh2B
		else: MYWwFs7XA2 = YLKFRH6sSIrznXBg
	HAsKeZdTbqjPI1WY(MYWwFs7XA2)
	return
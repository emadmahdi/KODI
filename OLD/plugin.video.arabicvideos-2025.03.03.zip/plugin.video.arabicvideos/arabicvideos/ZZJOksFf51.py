# -*- coding: utf-8 -*-
from i8zOgXMb2I import *
BfWYUAnyg6eONLjiuE = 'EGYBESTVIP'
K2l9rLfvoXxyZ4NYapO = '_EGV_'
BOI3t1w8qfHAb0Kl4oMye7haEWS = I4t9qonjrm.SITESURLS[BfWYUAnyg6eONLjiuE][0]
def ugbnmWCrLpG9Av0xzocFaB5ew(mode,url,jmI9qRnVJo2a3tpcH8gfYkP,text):
	if   mode==220: OmsWt89dSA5HyCZ4wL = UeOqpYGBXiJdAatwDboErxZLyh0M()
	elif mode==221: OmsWt89dSA5HyCZ4wL = HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP)
	elif mode==222: OmsWt89dSA5HyCZ4wL = vloIZHenE7imycDM2tPQ(url)
	elif mode==223: OmsWt89dSA5HyCZ4wL = rr7SfotkneX85Klup(url)
	elif mode==224: OmsWt89dSA5HyCZ4wL = F4ehkvPDxXU(url)
	elif mode==229: OmsWt89dSA5HyCZ4wL = dPTs3joJiGpzfcWFvQZAa(text)
	else: OmsWt89dSA5HyCZ4wL = False
	return OmsWt89dSA5HyCZ4wL
def UeOqpYGBXiJdAatwDboErxZLyh0M():
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'بحث في الموقع',fy8iFgEkrO12NR9TWBI35sjY6qHvV,229,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'_REMEMBERRESULTS_')
	OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBEST-MENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="i i-home"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)"(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if '</i>' in title: title = title.split('</i>')[1]
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,222)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="ba(.*?)<script',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('pda bdb"><strong>(.*?)<.*?href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		for title,bigdh7fpZYl4aT2keV in items:
			OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,221)
		OZD1l4pAMzeH('link',n0nFOd4yR97fQzNLSW+' ===== ===== ===== '+T7ASIp1ZYwio9HQ8cObJK,fy8iFgEkrO12NR9TWBI35sjY6qHvV,9999)
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if 'html' not in bigdh7fpZYl4aT2keV: continue
			if not bigdh7fpZYl4aT2keV.endswith('/'): OZD1l4pAMzeH('folder',BfWYUAnyg6eONLjiuE+'_SCRIPT_'+K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,221)
	return FGRX4myP68S
def vloIZHenE7imycDM2tPQ(url):
	E6ECvznP9m5sWFMu = TBPcjsyOYoM82pm(rrux12tcwQl5,'GET',url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-SUBMENU-1st')
	FGRX4myP68S = E6ECvznP9m5sWFMu.content
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="rs_scroll"(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".*?</i>(.*?)</a>',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,title in items:
		OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,224)
	return
def F4ehkvPDxXU(url):
	OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'الجميع',url,221)
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-FILTERS_MENU-1st')
	z6PX2p7diaskQElBOvMRNcHwqG5D = EcQxOa3RJm86WjTKA.findall('class="sub_nav(.*?)id="movies',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if z6PX2p7diaskQElBOvMRNcHwqG5D:
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
		items = EcQxOa3RJm86WjTKA.findall('href="(.*?)".+?>(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
		for bigdh7fpZYl4aT2keV,title in items:
			if bigdh7fpZYl4aT2keV=='#': name = title
			else:
				title = title + '  :  ' + 'فلتر ' + name
				OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,221)
	else: HAsKeZdTbqjPI1WY(url)
	return
def HAsKeZdTbqjPI1WY(url,jmI9qRnVJo2a3tpcH8gfYkP='1'):
	if jmI9qRnVJo2a3tpcH8gfYkP==fy8iFgEkrO12NR9TWBI35sjY6qHvV: jmI9qRnVJo2a3tpcH8gfYkP = '1'
	if '/search' in url or '?' in url: YLKFRH6sSIrznXBg = url + '&'
	else: YLKFRH6sSIrznXBg = url + '?'
	YLKFRH6sSIrznXBg = YLKFRH6sSIrznXBg + 'page=' + jmI9qRnVJo2a3tpcH8gfYkP
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(CQOaFUrZJHwKRxIj4yXEYs5V,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-TITLES-1st')
	if '/season' in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('class="pda"(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[-1]
	elif '/series/' in url:
		z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('class="owl-carousel owl-carousel(.*?)div',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[0]
	else:
		z6PX2p7diaskQElBOvMRNcHwqG5D=EcQxOa3RJm86WjTKA.findall('id="movies(.*?)</div>',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
		wlJ6d8hEvpoMNSCmU = z6PX2p7diaskQElBOvMRNcHwqG5D[-1]
	items = EcQxOa3RJm86WjTKA.findall('<a href="(.*?)".*?src="(.*?)".*?title">(.*?)<',wlJ6d8hEvpoMNSCmU,EcQxOa3RJm86WjTKA.DOTALL)
	for bigdh7fpZYl4aT2keV,POjaBmHqzpsx1IYw7kQM4R,title in items:
		title = IVcCL3aAfU9wS7kWev1g2XBjZRJ(title)
		if '/movie/' in bigdh7fpZYl4aT2keV or '/episode' in bigdh7fpZYl4aT2keV:
			OZD1l4pAMzeH('video',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV.rstrip('/'),223,POjaBmHqzpsx1IYw7kQM4R)
		else:
			OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+title,bigdh7fpZYl4aT2keV,221,POjaBmHqzpsx1IYw7kQM4R)
	if len(items)>=16:
		CFKfJaM0YBSy9UOm6huR = ['/movies','/tv','/search','/trending']
		jmI9qRnVJo2a3tpcH8gfYkP = int(jmI9qRnVJo2a3tpcH8gfYkP)
		if any(value in url for value in CFKfJaM0YBSy9UOm6huR):
			for KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk in range(0,1000,100):
				if int(jmI9qRnVJo2a3tpcH8gfYkP/100)*100==KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk:
					for pk6YWixXFSrDLKCnlN39w in range(KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk,KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk+100,10):
						if int(jmI9qRnVJo2a3tpcH8gfYkP/10)*10==pk6YWixXFSrDLKCnlN39w:
							for PK4ZaDWHlivtVdBMoexgzyUTf in range(pk6YWixXFSrDLKCnlN39w,pk6YWixXFSrDLKCnlN39w+10,1):
								if not jmI9qRnVJo2a3tpcH8gfYkP==PK4ZaDWHlivtVdBMoexgzyUTf and PK4ZaDWHlivtVdBMoexgzyUTf!=0:
									OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+str(PK4ZaDWHlivtVdBMoexgzyUTf),url,221,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(PK4ZaDWHlivtVdBMoexgzyUTf))
						elif pk6YWixXFSrDLKCnlN39w!=0: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+str(pk6YWixXFSrDLKCnlN39w),url,221,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(pk6YWixXFSrDLKCnlN39w))
						else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+str(1),url,221,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(1))
				elif KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk!=0: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+str(KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk),url,221,fy8iFgEkrO12NR9TWBI35sjY6qHvV,str(KYFW0Cq4HP7TXAnO2a1mL3g9s8yVk))
				else: OZD1l4pAMzeH('folder',K2l9rLfvoXxyZ4NYapO+'صفحة '+str(1),url,221)
	return
def rr7SfotkneX85Klup(url):
	WFlpmsYGKNy,XoSyx7p6dqZ1CF8 = [],[]
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,url,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-PLAY-1st')
	uuigJsvIZQ3tprnhxG = EcQxOa3RJm86WjTKA.findall('<td>التصنيف</td>.*?">(.*?)<',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if uuigJsvIZQ3tprnhxG and SYJvigbI3fts(BfWYUAnyg6eONLjiuE,url,uuigJsvIZQ3tprnhxG): return
	HtbGfuVNYUsOqvB379PQ8XDS1,NN4AdqXOiRp1gfzns6lHmhG8Ctw = fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV
	K7wlTZDEGHM2OA8mbQs936viJ,vviyogl3V7T = FGRX4myP68S,FGRX4myP68S
	yKdWvZFBhgX3rnECixe8tG2O1f = EcQxOa3RJm86WjTKA.findall('show_dl api" href="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if yKdWvZFBhgX3rnECixe8tG2O1f:
		for bigdh7fpZYl4aT2keV in yKdWvZFBhgX3rnECixe8tG2O1f:
			if '/watch/' in bigdh7fpZYl4aT2keV: HtbGfuVNYUsOqvB379PQ8XDS1 = bigdh7fpZYl4aT2keV
			elif '/download/' in bigdh7fpZYl4aT2keV: NN4AdqXOiRp1gfzns6lHmhG8Ctw = bigdh7fpZYl4aT2keV
		if HtbGfuVNYUsOqvB379PQ8XDS1!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: K7wlTZDEGHM2OA8mbQs936viJ = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,HtbGfuVNYUsOqvB379PQ8XDS1,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-PLAY-2nd')
		if NN4AdqXOiRp1gfzns6lHmhG8Ctw!=fy8iFgEkrO12NR9TWBI35sjY6qHvV: vviyogl3V7T = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,NN4AdqXOiRp1gfzns6lHmhG8Ctw,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-PLAY-3rd')
	wP3IAEYybfjSGD4 = EcQxOa3RJm86WjTKA.findall('id="video".*?data-src="(.*?)"',K7wlTZDEGHM2OA8mbQs936viJ,EcQxOa3RJm86WjTKA.DOTALL)
	if wP3IAEYybfjSGD4:
		YLKFRH6sSIrznXBg = wP3IAEYybfjSGD4[0]
		if YLKFRH6sSIrznXBg!=fy8iFgEkrO12NR9TWBI35sjY6qHvV and 'uploaded.egybest.download' in YLKFRH6sSIrznXBg and '/?id=_' not in YLKFRH6sSIrznXBg:
			soEymUvkt19PQXVjzKau6x5 = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(rrux12tcwQl5,YLKFRH6sSIrznXBg,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-PLAY-4th')
			hUqVyRMHZ5AodnptL = EcQxOa3RJm86WjTKA.findall('source src="(.*?)" title="(.*?)"',soEymUvkt19PQXVjzKau6x5,EcQxOa3RJm86WjTKA.DOTALL)
			if hUqVyRMHZ5AodnptL:
				for bigdh7fpZYl4aT2keV,OOnVxtP0TNWsci6HrEGqBm9boKF7g in hUqVyRMHZ5AodnptL:
					XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV+'?named=ed.egybest.do__watch__mp4__'+OOnVxtP0TNWsci6HrEGqBm9boKF7g)
			else:
				A8ECQ0qwTRzPifOGW76FK35uUvhe = YLKFRH6sSIrznXBg.split('/')[2]
				XoSyx7p6dqZ1CF8.append(YLKFRH6sSIrznXBg+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__watch')
		elif YLKFRH6sSIrznXBg!=fy8iFgEkrO12NR9TWBI35sjY6qHvV:
			A8ECQ0qwTRzPifOGW76FK35uUvhe = YLKFRH6sSIrznXBg.split('/')[2]
			XoSyx7p6dqZ1CF8.append(YLKFRH6sSIrznXBg+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__watch')
	aKoMdk6XDL9ZF5VqH = EcQxOa3RJm86WjTKA.findall('<table class="dls_table(.*?)</table>',vviyogl3V7T,EcQxOa3RJm86WjTKA.DOTALL)
	if aKoMdk6XDL9ZF5VqH:
		aKoMdk6XDL9ZF5VqH = aKoMdk6XDL9ZF5VqH[0]
		XOUI6HyEK1BFRZjn = EcQxOa3RJm86WjTKA.findall('<td>.*?<td>(.*?)<.*?href="(.*?)"',aKoMdk6XDL9ZF5VqH,EcQxOa3RJm86WjTKA.DOTALL)
		if XOUI6HyEK1BFRZjn:
			for OOnVxtP0TNWsci6HrEGqBm9boKF7g,bigdh7fpZYl4aT2keV in XOUI6HyEK1BFRZjn:
				if 'myegyvip' not in bigdh7fpZYl4aT2keV: continue
				if bigdh7fpZYl4aT2keV.count('/')>=2:
					A8ECQ0qwTRzPifOGW76FK35uUvhe = bigdh7fpZYl4aT2keV.split('/')[2]
					XoSyx7p6dqZ1CF8.append(bigdh7fpZYl4aT2keV+'?named='+A8ECQ0qwTRzPifOGW76FK35uUvhe+'__download__mp4__'+OOnVxtP0TNWsci6HrEGqBm9boKF7g)
	VB3NKdsqvfAJYEWljanku8 = []
	for bigdh7fpZYl4aT2keV in XoSyx7p6dqZ1CF8:
		VB3NKdsqvfAJYEWljanku8.append(bigdh7fpZYl4aT2keV)
	import TT24gHhkWI
	TT24gHhkWI.F7ulLTJzOt6krWZa4(VB3NKdsqvfAJYEWljanku8,BfWYUAnyg6eONLjiuE,'video',url)
	return
def dPTs3joJiGpzfcWFvQZAa(search):
	search,yJWh5lC4wcNrRi3nFa,showDialogs = VVLsBWDuZCfakNtYAFMHd6yiGqxTe(search)
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: search = GFYl1tsoOkHC0Ajeur8JQiMx()
	if search==fy8iFgEkrO12NR9TWBI35sjY6qHvV: return
	CE6HW2phYix9XvVdfqe1ObQIFl5mMj = search.replace(ksJdoFWhxTz8Y2N7bOZE,'+')
	FGRX4myP68S = OOFpNQ6zry2ZL0E7tjSDwhAJ5quUg(d9vcuo3Hy7RhAk2,BOI3t1w8qfHAb0Kl4oMye7haEWS,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,fy8iFgEkrO12NR9TWBI35sjY6qHvV,'EGYBESTVIP-SEARCH-1st')
	eDi4j5Usrp = EcQxOa3RJm86WjTKA.findall('name="_token" value="(.*?)"',FGRX4myP68S,EcQxOa3RJm86WjTKA.DOTALL)
	if eDi4j5Usrp:
		url = BOI3t1w8qfHAb0Kl4oMye7haEWS+'/search?_token='+eDi4j5Usrp[0]+'&q='+CE6HW2phYix9XvVdfqe1ObQIFl5mMj
		HAsKeZdTbqjPI1WY(url)
	return